package gmxclone;

import java.io.File;
import java.util.*;

public class Main {
    private static final String VERSION = "2027.0-dev-20260414-24ac8ab-unknown";
    private static final String HASH = "24ac8abecd15814143951f211394c29bdfc42e13";

    private static final String[][] COMMANDS = {
        {"anaeig", "Analyze eigenvectors/normal modes"},
        {"analyze", "Analyze data sets"},
        {"angle", "Calculate distributions and correlations for angles and dihedrals"},
        {"awh", "Extract data from an accelerated weight histogram (AWH) run"},
        {"bar", "Calculate free energy difference estimates through Bennett's acceptance ratio"},
        {"bundle", "Analyze bundles of axes, e.g., helices"},
        {"check", "Check and compare files"},
        {"chi", "Calculate everything you want to know about chi and other dihedrals"},
        {"cluster", "Cluster structures"},
        {"clustsize", "Calculate size distributions of atomic clusters"},
        {"confrms", "Fit two structures and calculates the RMSD"},
        {"convert-tpr", "Make a modified run-input file"},
        {"convert-trj", "Converts between different trajectory types"},
        {"covar", "Calculate and diagonalize the covariance matrix"},
        {"current", "Calculate dielectric constants and current autocorrelation function"},
        {"density", "Calculate the density of the system"},
        {"densmap", "Calculate 2D planar or axial-radial density maps"},
        {"densorder", "Calculate surface fluctuations"},
        {"dielectric", "Calculate frequency dependent dielectric constants"},
        {"dipoles", "Compute the total dipole plus fluctuations"},
        {"disre", "Analyze distance restraints"},
        {"distance", "Calculate distances between pairs of positions"},
        {"dos", "Analyze density of states and properties based on that"},
        {"dssp", "Calculate protein secondary structure via DSSP algorithm"},
        {"dump", "Make binary files human readable"},
        {"dyecoupl", "Extract dye dynamics from trajectories"},
        {"editconf", "Convert and manipulates structure files"},
        {"eneconv", "Convert energy files"},
        {"enemat", "Extract an energy matrix from an energy file"},
        {"energy", "Writes energies to xvg files and display averages"},
        {"extract-cluster", "Allows extracting frames corresponding to clusters from trajectory"},
        {"filter", "Frequency filter trajectories, useful for making smooth movies"},
        {"freevolume", "Calculate free volume"},
        {"gangle", "Calculate angles"},
        {"genconf", "Multiply a conformation in 'random' orientations"},
        {"genion", "Generate monoatomic ions on energetically favorable positions"},
        {"genrestr", "Generate position restraints or distance restraints for index groups"},
        {"grompp", "Make a run input file"},
        {"gyrate", "Calculate radius of gyration of a molecule"},
        {"gyrate-legacy", "Calculate the radius of gyration"},
        {"h2order", "Compute the orientation of water molecules"},
        {"hbond", "Compute and analyze hydrogen bonds."},
        {"hbond-legacy", "Compute and analyze hydrogen bonds"},
        {"helix", "Calculate basic properties of alpha helices"},
        {"helixorient", "Calculate local pitch/bending/rotation/orientation inside helices"},
        {"help", "Print help information"},
        {"hydorder", "Compute tetrahedrality parameters around a given atom"},
        {"insert-molecules", "Insert molecules into existing vacancies"},
        {"lie", "Estimate free energy from linear combinations"},
        {"make_edi", "Generate input files for essential dynamics sampling"},
        {"make_ndx", "Make index files"},
        {"mdmat", "Calculate residue contact maps"},
        {"mdrun", "Perform a simulation, do a normal mode analysis or an energy minimization"},
        {"mindist", "Calculate the minimum distance between two groups"},
        {"mk_angndx", "Generate index files for 'gmx angle'"},
        {"msd", "Compute mean squared displacements"},
        {"nmeig", "Diagonalize the Hessian for normal mode analysis"},
        {"nmens", "Generate an ensemble of structures from the normal modes"},
        {"nmr", "Analyze nuclear magnetic resonance properties from an energy file"},
        {"nmtraj", "Generate a virtual oscillating trajectory from an eigenvector"},
        {"nonbonded-benchmark", "Benchmarking tool for the non-bonded pair kernels."},
        {"order", "Compute the order parameter per atom for carbon tails"},
        {"pairdist", "Calculate pairwise distances between groups of positions"},
        {"pdb2gmx", "Convert coordinate files to topology and FF-compliant coordinate files"},
        {"pme_error", "Estimate the error of using PME with a given input file"},
        {"polystat", "Calculate static properties of polymers"},
        {"potential", "Calculate the electrostatic potential across the box"},
        {"principal", "Calculate principal axes of inertia for a group of atoms"},
        {"rama", "Compute Ramachandran plots"},
        {"rdf", "Calculate radial distribution functions"},
        {"report-methods", "Write short summary about the simulation setup to a text file and/or to the standard output."},
        {"rms", "Calculate RMSDs with a reference structure and RMSD matrices"},
        {"rmsdist", "Calculate atom pair distances averaged with power -2, -3 or -6"},
        {"rmsf", "Calculate atomic fluctuations"},
        {"rotacf", "Calculate the rotational correlation function for molecules"},
        {"rotmat", "Plot the rotation matrix for fitting to a reference structure"},
        {"saltbr", "Compute salt bridges"},
        {"sans-legacy", "Compute small angle neutron scattering spectra"},
        {"sasa", "Compute solvent accessible surface area"},
        {"saxs-legacy", "Compute small angle X-ray scattering spectra"},
        {"scattering", "Calculate small angle scattering profiles for SANS or SAXS"},
        {"select", "Print general information about selections"},
        {"sham", "Compute free energies or other histograms from histograms"},
        {"sigeps", "Convert c6/12 or c6/cn combinations to and from sigma/epsilon"},
        {"solvate", "Solvate a system"},
        {"sorient", "Analyze solvent orientation around solutes"},
        {"spatial", "Calculate the spatial distribution function"},
        {"spol", "Analyze solvent dipole orientation and polarization around solutes"},
        {"tcaf", "Calculate viscosities of liquids"},
        {"traj", "Plot x, v, f, box, temperature and rotational energy from trajectories"},
        {"trajectory", "Print coordinates, velocities, and/or forces for selections"},
        {"trjcat", "Concatenate trajectory files"},
        {"trjconv", "Convert and manipulates trajectory files"},
        {"trjorder", "Order molecules according to their distance to a group"},
        {"tune_pme", "Time mdrun as a function of PME ranks to optimize settings"},
        {"vanhove", "Compute Van Hove displacement and correlation functions"},
        {"velacc", "Calculate velocity autocorrelation functions"},
        {"wham", "Perform weighted histogram analysis after umbrella sampling"},
        {"wheel", "Plot helical wheels"},
        {"x2top", "Generate a primitive topology from coordinates"},
        {"xpm2ps", "Convert XPM (XPixelMap) matrices to postscript or XPM"}
    };

    private static final Set<String> COMMAND_NAMES = new HashSet<>();
    static {
        for (String[] c : COMMANDS) {
            COMMAND_NAMES.add(c[0]);
        }
    }

    public static void main(String[] args) {
        int code = run(args);
        if (code != 0) {
            System.exit(code);
        }
    }

    private static int run(String[] args) {
        boolean quiet = false;
        boolean copyright = false;
        List<String> rest = new ArrayList<>();
        boolean commandSeen = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if ("-quiet".equals(a)) {
                quiet = true;
            } else if ("-copyright".equals(a)) {
                copyright = true;
            } else if ("-nice".equals(a)) {
                if (i + 1 < args.length) i++;
            } else if (a.startsWith("--") || (!commandSeen && a.startsWith("-") && !isCommonOption(a))) {
                startup("executable", args, false);
                fatal("executable", "src/gromacs/commandline/cmdlineparser.cpp (line 271)",
                      "void gmx::CommandLineParser::parse(int*, char**)",
                      "Invalid command-line options\n    Unknown command-line option " + a);
                return 1;
            } else {
                if (!a.startsWith("-")) commandSeen = true;
                rest.add(a);
            }
        }

        if (copyright) {
            printCopyright();
        }

        if (rest.isEmpty() || "-h".equals(rest.get(0)) || "-version".equals(rest.get(0)) || "-noversion".equals(rest.get(0))) {
            if ("-version".equals(rest.get(0))) {
                startup("executable", args, false);
                printVersion();
                return 0;
            }
            if (!quiet) {
                startup("executable", args, false);
                quote();
            }
            printRootHelp();
            return 0;
        }

        String cmd = rest.get(0);
        if ("help".equals(cmd)) {
            if (!quiet) {
                startup("gmx help", args, true);
            }
            if (rest.size() == 1) {
                if (!quiet) quote();
                printRootHelp();
            } else if ("commands".equals(rest.get(1))) {
                printCommands();
            } else if ("selections".equals(rest.get(1))) {
                if (!quiet) quote();
                printSelections();
            } else if (COMMAND_NAMES.contains(rest.get(1))) {
                printCommandHelp(rest.get(1));
            } else {
                fatal("gmx help", "src/gromacs/onlinehelp/helpmanager.cpp (line 190)",
                      "void gmx::HelpManager::Impl::enterTopic(const char*)",
                      "No help topic '" + rest.get(1) + "' is available.");
                return 1;
            }
            return 0;
        }

        if (!COMMAND_NAMES.contains(cmd)) {
            startup("executable", args, false);
            fatal("executable", "src/gromacs/commandline/cmdlinemodulemanager.cpp (line 389)",
                  "gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)",
                  "'" + cmd + "' is not a GROMACS command.");
            return 1;
        }

        if (rest.contains("-h")) {
            if (!quiet) startup("gmx " + cmd, args, true);
            printCommandHelp(cmd);
            return 0;
        }

        if (!quiet) startup("gmx " + cmd, args, true);
        if ("mdrun".equals(cmd)) {
            fatal("gmx mdrun", "src/gromacs/options/options.cpp (line 184)",
                  "void gmx::internal::OptionSectionImpl::finish()",
                  "Invalid input values\n  In option s\n    Required option was not provided, and the default file 'topol' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .tpr");
        } else if ("grompp".equals(cmd)) {
            fatal("gmx grompp", "src/gromacs/options/options.cpp (line 184)",
                  "void gmx::internal::OptionSectionImpl::finish()",
                  "Invalid input values\n  In option c\n    Required option was not provided, and the default file 'conf' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .gro, .g96, .pdb, .brk, .ent, .esp, .tpr\n  In option f\n    Required option was not provided, and the default file 'grompp' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .mdp\n  In option p\n    Required option was not provided, and the default file 'topol' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .top");
        } else {
            fatal("gmx " + cmd, "src/gromacs/options/options.cpp (line 184)",
                  "void gmx::internal::OptionSectionImpl::finish()",
                  "Invalid input values\n  Required input file was not provided, and no suitable default file exists.");
        }
        return 1;
    }

    private static boolean isCommonOption(String option) {
        return Arrays.asList("-h", "-version", "-noversion", "-quiet", "-noquiet",
                             "-copyright", "-nocopyright", "-backup", "-nobackup",
                             "-nice").contains(option);
    }

    private static void startup(String program, String[] args, boolean gmxProgram) {
        String wd = System.getProperty("user.dir");
        System.out.printf("%8s:-) GROMACS - %s, %s (-:%n%n", "", program, VERSION);
        System.out.println("Executable:   " + wd + File.separator + "./executable");
        System.out.println("Data prefix:  /usr/local/gromacs");
        System.out.println("Working dir:  " + wd);
        System.out.println("Command line:");
        System.out.print("  executable");
        for (String a : args) {
            System.out.print(" " + a);
        }
        System.out.println("\n");
    }

    private static void quote() {
        System.out.println("GROMACS reminds you: \"It Just Tastes Better\" (Burger King)\n");
    }

    private static void printRootHelp() {
        System.out.println("SYNOPSIS\n");
        System.out.println("gmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]");
        System.out.println("    [-[no]backup]\n");
        System.out.println("OPTIONS\n");
        System.out.println("Other options:\n");
        System.out.println(" -[no]h                     (no)");
        System.out.println("           Print help and quit");
        System.out.println(" -[no]quiet                 (no)");
        System.out.println("           Do not print common startup info or quotes");
        System.out.println(" -[no]version               (no)");
        System.out.println("           Print extended version information and quit");
        System.out.println(" -[no]copyright             (no)");
        System.out.println("           Print copyright information on startup");
        System.out.println(" -nice   <int>              (19)");
        System.out.println("           Set the nicelevel (default depends on command)");
        System.out.println(" -[no]backup                (yes)");
        System.out.println("           Write backups if output files exist\n");
        System.out.println("Additional help is available on the following topics:");
        System.out.println("    commands    List of available commands");
        System.out.println("    selections  Selection syntax and usage");
        System.out.println("To access the help, use 'gmx help <topic>'.");
        System.out.println("For help on a command, use 'gmx help <command>'.");
    }

    private static void printVersion() {
        System.out.println("GROMACS version:     " + VERSION);
        System.out.println("GIT SHA1 hash:       " + HASH);
        System.out.println("Branched from:       unknown");
        System.out.println("Precision:           mixed");
        System.out.println("Memory model:        64 bit");
        System.out.println("MPI library:         thread_mpi");
        System.out.println("MPI version:         built in");
        System.out.println("OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)");
        System.out.println("GPU support:         disabled");
        System.out.println("SIMD instructions:   None");
        System.out.println("CPU FFT library:     fftw-3.3.10");
        System.out.println("GPU FFT library:     none");
        System.out.println("Multi-GPU FFT:       none");
        System.out.println("RDTSCP:              enabled");
        System.out.println("TNG support:         enabled");
        System.out.println("Hwloc support:       disabled");
        System.out.println("Tracing support:     disabled");
        System.out.println("Colvars support:     enabled (version 2025-10-13)");
        System.out.println("CP2K support:        disabled");
        System.out.println("Torch support:       disabled");
        System.out.println("Plumed support:      enabled");
        System.out.println("C compiler:          /usr/bin/cc GNU 11.4.0");
        System.out.println("C compiler flags:    -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wno-unused -Wunused-value -Wunused-parameter -Wextra -Wno-sign-compare -Wpointer-arith -Wpedantic -Wundef -Werror=stringop-truncation -Wshadow -Wno-missing-field-initializers -O3 -DNDEBUG");
        System.out.println("C++ compiler:        /usr/bin/c++ GNU 11.4.0");
        System.out.println("C++ compiler flags:  -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wextra -Wpointer-arith -Wmissing-declarations -Wpedantic -Wundef -Wstringop-truncation -Wshadow -Wno-missing-field-initializers -Wno-stringop-truncation -Wno-cast-function-type-strict SHELL:-fopenmp -O3 -DNDEBUG");
        System.out.println("BLAS library:        Internal");
        System.out.println("LAPACK library:      Internal\n");
    }

    private static void printCopyright() {
        System.out.println("       :-) GROMACS - executable, " + VERSION + " (-:\n");
        System.out.println("Copyright 1991-2027 The GROMACS Authors.");
        System.out.println("GROMACS is free software; you can redistribute it and/or modify it");
        System.out.println("under the terms of the GNU Lesser General Public License");
        System.out.println("as published by the Free Software Foundation; either version 2.1");
        System.out.println("of the License, or (at your option) any later version.\n");
        System.out.println("                         Current GROMACS contributors:");
        System.out.println("       Mark Abraham           Andrey Alekseenko           Brian Andrews       ");
        System.out.println("        Paul Bauer              Cathrine Bergh              Hugh Bird         ");
        System.out.println("      Eliane Briand               Ania Brown                Yiqi Chen         ");
        System.out.println("\n                  Coordinated by the GROMACS project leaders:");
        System.out.println("                           Berk Hess and Erik Lindahl\n");
    }

    private static void printCommands() {
        System.out.println("LIST OF AVAILABLE COMMANDS\n");
        System.out.println("Usage: gmx [<options>] <command> [<args>]\n");
        System.out.println("Available commands:");
        for (String[] c : COMMANDS) {
            String desc = c[1];
            if (desc.length() <= 55) {
                System.out.printf("    %-20s %s%n", c[0], desc);
            } else {
                System.out.printf("    %-20s %s%n", c[0], desc.substring(0, 55));
                System.out.printf("                         %s%n", desc.substring(55).trim());
            }
        }
        System.out.println("For help on a command, use 'gmx help <command>'.");
    }

    private static void printSelections() {
        System.out.println("SELECTION SYNTAX AND USAGE\n");
        System.out.println("Selections are used to select atoms/molecules/residues for analysis. In");
        System.out.println("contrast to traditional index files, selections can be dynamic, i.e., select");
        System.out.println("different atoms for different trajectory frames. The GROMACS manual contains a");
        System.out.println("short introductory section to selections in the Analysis chapter, including");
        System.out.println("suggestions on how to get familiar with selections if you are new to the");
        System.out.println("concept. The subtopics listed below provide more details on the technical and");
        System.out.println("syntactic aspects of selections.\n");
        System.out.println("Each analysis tool requires a different number of selections and the");
        System.out.println("selections are interpreted differently. The general idea is still the same:");
        System.out.println("each selection evaluates to a set of positions, where a position can be an");
        System.out.println("atom position or center-of-mass or center-of-geometry of a set of atoms.\n");
        System.out.println("Available subtopics:");
        System.out.println("    arithmetic   Arithmetic expressions in selections");
        System.out.println("    cmdline      Specifying selections from command line");
        System.out.println("    evaluation   Selection evaluation and optimization");
        System.out.println("    examples     Selection examples");
        System.out.println("    keywords     Selection keywords");
        System.out.println("    limitations  Selection limitations");
        System.out.println("    positions    Specifying positions in selections");
        System.out.println("    syntax       Selection syntax");
    }

    private static void printCommandHelp(String cmd) {
        if ("mdrun".equals(cmd)) {
            System.out.println("SYNOPSIS\n");
            System.out.println("gmx mdrun [-s [<.tpr>]] [-cpi [<.cpt>]] [-table [<.xvg>]] [-tablep [<.xvg>]]");
            System.out.println("          [-tableb [<.xvg> [...]]] [-rerun [<.xtc/.trr/...>]] [-ei [<.edi>]]");
            System.out.println("          [-deffnm <string>] [-xvg <enum>] [-dd <vector>] [-nt <int>]");
            System.out.println("          [-ntmpi <int>] [-ntomp <int>] [-[no]v] [-nsteps <int>]\n");
            System.out.println("DESCRIPTION\n");
            System.out.println("gmx mdrun is the main computational chemistry engine within GROMACS.");
            System.out.println("Obviously, it performs Molecular Dynamics simulations, but it can also perform");
            System.out.println("Stochastic Dynamics, Energy Minimization, test particle insertion or");
            System.out.println("(re)calculation of energies. Normal mode analysis is another option.\n");
            System.out.println("OPTIONS\n\nOptions to specify input files:\n");
            System.out.println(" -s      [<.tpr>]           (topol.tpr)");
            System.out.println("           Portable xdr run input file");
            System.out.println(" -cpi    [<.cpt>]           (state.cpt)      (Opt.)");
            System.out.println("           Checkpoint file\n");
            System.out.println("Options to specify output files:\n");
            System.out.println(" -o      [<.trr/.cpt/...>]  (traj.trr)");
            System.out.println("           Full precision trajectory: trr cpt tng h5md");
            System.out.println(" -x      [<.xtc/.tng>]      (traj_comp.xtc)  (Opt.)");
            System.out.println("           Compressed trajectory (tng format or portable xdr format)");
            System.out.println(" -c      [<.gro/.g96/...>]  (confout.gro)");
            System.out.println("           Structure file: gro g96 pdb brk ent esp");
            System.out.println(" -e      [<.edr>]           (ener.edr)");
            System.out.println("           Energy file\n");
            System.out.println("Other options:\n");
            System.out.println(" -deffnm <string>");
            System.out.println("           Set the default filename for all file options");
            System.out.println(" -nt     <int>              (0)");
            System.out.println("           Total number of threads to start (0 is guess)");
            System.out.println(" -[no]v                     (no)");
            System.out.println("           Be loud and noisy");
        } else if ("pdb2gmx".equals(cmd)) {
            System.out.println("SYNOPSIS\n");
            System.out.println("gmx pdb2gmx [-f [<.gro/.g96/...>]] [-o [<.gro/.g96/...>]] [-p [<.top>]]");
            System.out.println("            [-i [<.itp>]] [-n [<.ndx>]] [-q [<.gro/.g96/...>]]");
            System.out.println("            [-chainsep <enum>] [-merge <enum>] [-ff <string>] [-water <enum>]\n");
            System.out.println("DESCRIPTION\n");
            System.out.println("gmx pdb2gmx reads a .pdb (or .gro) file, reads some database files, adds");
            System.out.println("hydrogens to the molecules and generates coordinates in GROMACS (GROMOS), or");
            System.out.println("optionally .pdb, format and a topology in GROMACS format.\n");
            System.out.println("OPTIONS\n\nOptions to specify input files:\n");
            System.out.println(" -f      [<.gro/.g96/...>]  (protein.pdb)");
            System.out.println("           Structure file: gro g96 pdb brk ent esp tpr\n");
            System.out.println("Options to specify output files:\n");
            System.out.println(" -o      [<.gro/.g96/...>]  (conf.gro)");
            System.out.println("           Structure file: gro g96 pdb brk ent esp");
            System.out.println(" -p      [<.top>]           (topol.top)");
            System.out.println("           Topology file\n");
            System.out.println("Other options:\n");
            System.out.println(" -ff     <string>           (select)");
            System.out.println("           Force field, interactive by default. Use -h for information.");
            System.out.println(" -water  <enum>             (select)");
            System.out.println("           Water model to use: select, none, opc, opc3, spc, spce, tip3p,");
            System.out.println("           tip4p, tip4pew, tip5p, tips3p");
        } else if ("grompp".equals(cmd)) {
            System.out.println("SYNOPSIS\n");
            System.out.println("gmx grompp [-f [<.mdp>]] [-c [<.gro/.g96/...>]] [-r [<.gro/.g96/...>]]");
            System.out.println("           [-p [<.top>]] [-n [<.ndx>]] [-o [<.tpr>]] [-po [<.mdp>]]\n");
            System.out.println("DESCRIPTION\n");
            System.out.println("gmx grompp (the gromacs preprocessor) reads a molecular topology file,");
            System.out.println("checks the validity of the file, expands the topology from a molecular");
            System.out.println("description to an atomic description, and creates a run input file.\n");
            System.out.println("OPTIONS\n\nOptions to specify input files:\n");
            System.out.println(" -f      [<.mdp>]           (grompp.mdp)");
            System.out.println("           grompp input file with MD parameters");
            System.out.println(" -c      [<.gro/.g96/...>]  (conf.gro)");
            System.out.println("           Structure file: gro g96 pdb brk ent esp tpr");
            System.out.println(" -p      [<.top>]           (topol.top)");
            System.out.println("           Topology file\n");
            System.out.println("Options to specify output files:\n");
            System.out.println(" -o      [<.tpr>]           (topol.tpr)");
            System.out.println("           Portable xdr run input file");
        } else {
            String desc = "GROMACS command";
            for (String[] c : COMMANDS) if (c[0].equals(cmd)) desc = c[1];
            System.out.println("SYNOPSIS\n");
            System.out.println("gmx " + cmd + " [<options>]\n");
            System.out.println("DESCRIPTION\n");
            System.out.println("gmx " + cmd + " - " + desc + ".\n");
            System.out.println("OPTIONS\n\nOther options:\n");
            System.out.println(" -[no]h                     (no)");
            System.out.println("           Print help and quit");
            System.out.println(" -nice   <int>              (19)");
            System.out.println("           Set the nicelevel");
        }
    }

    private static void fatal(String program, String source, String function, String message) {
        System.out.println("-------------------------------------------------------");
        System.out.println("Program:     " + program + ", version " + VERSION);
        System.out.println("Source file: " + source);
        System.out.println("Function:    " + function + "\n");
        System.out.println("Error in user input:");
        System.out.println(message + "\n");
        System.out.println("For more information and tips for troubleshooting, please check the GROMACS");
        System.out.println("website at https://manual.gromacs.org/current/user-guide/run-time-errors.html");
        System.out.println("-------------------------------------------------------");
    }
}
