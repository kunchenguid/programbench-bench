import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class MiniPHP {
    static final String VERSION = "PHP 8.6.0-dev (cli) (built: Apr 17 2026 20:00:58) (NTS)\n"
            + "Copyright (c) The PHP Group\n"
            + "Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies\n"
            + "    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies\n";
    static final String HELP = "Usage: executable [options] [-f] <file> [--] [args...]\n"
            + "   executable [options] -r <code> [--] [args...]\n"
            + "   executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]\n"
            + "   executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]\n"
            + "   executable [options] -S <addr>:<port> [-t docroot] [router]\n"
            + "   executable [options] -- [args...]\n"
            + "   executable [options] -a\n\n"
            + "  -a               Run as interactive shell (requires readline extension)\n"
            + "  -c <path>|<file> Look for php.ini file in this directory\n"
            + "  -n               No configuration (ini) files will be used\n"
            + "  -d foo[=bar]     Define INI entry foo with value 'bar'\n"
            + "  -e               Generate extended information for debugger/profiler\n"
            + "  -f <file>        Parse and execute <file>.\n"
            + "  -h               This help\n"
            + "  -i               PHP information\n"
            + "  -l               Syntax check only (lint)\n"
            + "  -m               Show compiled in modules\n"
            + "  -r <code>        Run PHP <code> without using script tags <?..?>\n"
            + "  -B <begin_code>  Run PHP <begin_code> before processing input lines\n"
            + "  -R <code>        Run PHP <code> for every input line\n"
            + "  -F <file>        Parse and execute <file> for every input line\n"
            + "  -E <end_code>    Run PHP <end_code> after processing all input lines\n"
            + "  -H               Hide any passed arguments from external tools.\n"
            + "  -S <addr>:<port> Run with built-in web server.\n"
            + "  -t <docroot>     Specify document root <docroot> for built-in web server.\n"
            + "  -s               Output HTML syntax highlighted source.\n"
            + "  -v               Version number\n"
            + "  -w               Output source with stripped comments and whitespace.\n\n"
            + "  args...          Arguments passed to script. Use -- args when first argument\n"
            + "                   starts with - or script is read from stdin\n\n"
            + "  --ini            Show configuration file names\n"
            + "  --ini=diff       Show INI entries that differ from the built-in default\n\n"
            + "  --rf <name>      Show information about function <name>.\n"
            + "  --rc <name>      Show information about class <name>.\n"
            + "  --re <name>      Show information about extension <name>.\n"
            + "  --rz <name>      Show information about Zend extension <name>.\n"
            + "  --ri <name>      Show configuration for extension <name>.\n\n"
            + "  --repeat <count> Repeat script execution <count> times.\n"
            + "                   For internal purposes only.\n";

    public static void main(String[] args) {
        try {
            new MiniPHP().run(args);
        } catch (Exit e) {
            System.exit(e.code);
        } catch (Throwable t) {
            System.err.println("Fatal error: " + t.getMessage());
            System.exit(255);
        }
    }

    void run(String[] args) throws Exception {
        List<String> a = new ArrayList<>(Arrays.asList(args));
        if (a.isEmpty()) {
            execute(readAll(System.in), true, null, Collections.emptyList());
            return;
        }
        String begin = null, repeat = null, end = null, eachFile = null, file = null, code = null;
        boolean lint = false, strip = false, highlight = false;
        List<String> scriptArgs = new ArrayList<>();
        for (int i = 0; i < a.size(); i++) {
            String s = a.get(i);
            if (s.equals("--")) { scriptArgs.addAll(a.subList(i + 1, a.size())); break; }
            if (!s.startsWith("-") || s.equals("-")) { file = s.equals("-") ? null : s; scriptArgs.addAll(a.subList(i + 1, a.size())); break; }
            switch (s) {
                case "-h": case "--help": case "-?": System.out.print(HELP); return;
                case "-v": System.out.print(VERSION); return;
                case "-m": modules(); return;
                case "--ini": ini(); return;
                case "--ini=diff": return;
                case "-i": phpinfo(); return;
                case "-q": case "-n": case "-e": case "-H": break;
                case "-l": lint = true; break;
                case "-s": highlight = true; break;
                case "-w": strip = true; break;
                case "-a": System.out.print("Interactive shell\n\nphp > "); return;
                case "-c": case "-d": case "-t": case "--repeat": if (i + 1 < a.size()) i++; break;
                case "-S": if (i + 1 < a.size()) i++; System.err.println("PHP built-in server is not implemented in this reimplementation."); throw new Exit(1);
                case "-f": if (++i < a.size()) file = a.get(i); break;
                case "-r": if (++i < a.size()) code = a.get(i); break;
                case "-B": if (++i < a.size()) begin = a.get(i); break;
                case "-R": if (++i < a.size()) repeat = a.get(i); break;
                case "-F": if (++i < a.size()) eachFile = a.get(i); break;
                case "-E": if (++i < a.size()) end = a.get(i); break;
                default:
                    if (s.startsWith("-d") || s.startsWith("-c")) break;
                    if (s.equals("--rf") && i + 1 < a.size()) { System.out.println("Function [ <internal> function " + a.get(++i) + " ] {\n}\n"); return; }
                    if (s.equals("--rc") && i + 1 < a.size()) { System.out.println("Class [ <internal> class " + a.get(++i) + " ] {\n}\n"); return; }
                    if ((s.equals("--re") || s.equals("--ri") || s.equals("--rz")) && i + 1 < a.size()) { System.out.println(a.get(++i)); return; }
                    System.err.println("Error in argument " + (i + 1) + ", char 2: no argument for option " + s);
                    System.err.println("Usage: executable [options] [-f] <file> [--] [args...]");
                    throw new Exit(1);
            }
        }
        if (repeat != null || eachFile != null) { filter(begin, repeat, eachFile, end); return; }
        String source = code != null ? code : file != null ? Files.readString(Path.of(file)) : readAll(System.in);
        if (lint) { lint(source, code == null, file == null ? "Standard input code" : file); return; }
        if (strip) { System.out.print(source); return; }
        if (highlight) { System.out.print("<pre><code style=\"color: #000000\">" + html(source) + "</code></pre>"); return; }
        execute(source, code == null, file, scriptArgs);
    }

    void modules() {
        System.out.print("[PHP Modules]\nCore\ndate\nhash\njson\nlexbor\npcre\nrandom\nReflection\nSPL\nstandard\nuri\nZend OPcache\n\n[Zend Modules]\nZend OPcache\n");
    }
    void ini() { System.out.print("Configuration File (php.ini) Path: \"/usr/local/lib\"\nLoaded Configuration File:         (none)\nScan for additional .ini files in: (none)\nAdditional .ini files parsed:      (none)\n"); }
    void phpinfo() { System.out.print("phpinfo()\nPHP Version => 8.6.0-dev\nSystem => Linux\nBuild Date => Apr 17 2026 20:00:58\nConfigure Command => './configure'\nServer API => Command Line Interface\n"); }
    void filter(String begin, String repeat, String eachFile, String end) throws Exception {
        Env env = new Env();
        if (begin != null) new Parser(begin).program().exec(env);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String line; int nr = 0;
        while ((line = br.readLine()) != null) {
            nr++; env.set("$argn", Val.str(line)); env.set("$argi", Val.num(nr));
            String c = repeat != null ? repeat : Files.readString(Path.of(eachFile));
            new Parser(c).program().exec(env);
        }
        if (end != null) new Parser(end).program().exec(env);
    }
    void lint(String src, boolean tags, String name) {
        try { if (tags) compileTemplate(src); else new Parser(src).program(); System.out.println("No syntax errors detected in " + name); }
        catch (RuntimeException e) { System.err.println("Parse error: " + e.getMessage()); throw new Exit(255); }
    }
    void execute(String src, boolean tags, String file, List<String> args) {
        Env env = new Env();
        if (file != null) env.set("$argv", arrFromArgs(file, args));
        env.set("$argc", Val.num(args.size() + (file == null ? 0 : 1)));
        Block p = tags ? compileTemplate(src) : new Parser(src).program();
        try { p.exec(env); } catch (Return r) { if (r.value != null) System.out.print(fmt(r.value)); }
    }
    static Val arrFromArgs(String file, List<String> args) {
        Val a = Val.arr(); a.put(0, Val.str(file)); for (int i=0;i<args.size();i++) a.put(i+1, Val.str(args.get(i))); return a;
    }
    static Block compileTemplate(String src) {
        List<Stmt> out = new ArrayList<>(); int p = 0;
        while (p < src.length()) {
            int st = src.indexOf("<?", p);
            if (st < 0) { if (p < src.length()) out.add(new EchoLit(src.substring(p))); break; }
            if (st > p) out.add(new EchoLit(src.substring(p, st)));
            int codeStart = st + 2; if (src.startsWith("php", codeStart)) codeStart += 3; if (codeStart < src.length() && Character.isWhitespace(src.charAt(codeStart))) codeStart++;
            int en = src.indexOf("?>", codeStart);
            String code = en < 0 ? src.substring(codeStart) : src.substring(codeStart, en);
            out.add(new Parser(code).program());
            p = en < 0 ? src.length() : en + 2;
            if (p < src.length() && src.charAt(p) == '\r') p++;
            if (p < src.length() && src.charAt(p) == '\n') p++;
        }
        return new Block(out);
    }
    static String readAll(InputStream in) throws IOException { return new String(in.readAllBytes(), StandardCharsets.UTF_8); }
    static String html(String s) { return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"); }

    interface Stmt { void exec(Env e); }
    interface Expr { Val eval(Env e); }
    static class Block implements Stmt { List<Stmt> s; Block(List<Stmt> s){this.s=s;} public void exec(Env e){ for(Stmt x:s)x.exec(e); } }
    static class EchoLit implements Stmt { String s; EchoLit(String s){this.s=s;} public void exec(Env e){System.out.print(s);} }
    static class Echo implements Stmt { List<Expr> xs; Echo(List<Expr>x){xs=x;} public void exec(Env e){ for(Expr x:xs) System.out.print(fmt(x.eval(e))); } }
    static class ExprStmt implements Stmt { Expr x; ExprStmt(Expr x){this.x=x;} public void exec(Env e){x.eval(e);} }
    static class If implements Stmt { Expr c; Stmt t,f; If(Expr c,Stmt t,Stmt f){this.c=c;this.t=t;this.f=f;} public void exec(Env e){ if(truth(c.eval(e)))t.exec(e); else if(f!=null)f.exec(e);} }
    static class While implements Stmt { Expr c; Stmt b; While(Expr c,Stmt b){this.c=c;this.b=b;} public void exec(Env e){ while(truth(c.eval(e))) try{b.exec(e);}catch(Cont z){}catch(Break z){break;} } }
    static class For implements Stmt { Expr a,b,c; Stmt s; For(Expr a,Expr b,Expr c,Stmt s){this.a=a;this.b=b;this.c=c;this.s=s;} public void exec(Env e){ if(a!=null)a.eval(e); while(b==null||truth(b.eval(e))){ try{s.exec(e);}catch(Cont z){}catch(Break z){break;} if(c!=null)c.eval(e);} } }
    static class Foreach implements Stmt { Expr arr; String k,v; Stmt b; Foreach(Expr a,String k,String v,Stmt b){arr=a;this.k=k;this.v=v;this.b=b;} public void exec(Env e){ Val x=arr.eval(e); for(Map.Entry<Object,Val> en:x.map.entrySet()){ if(k!=null)e.set(k, keyVal(en.getKey())); e.set(v,en.getValue()); try{b.exec(e);}catch(Cont z){}catch(Break z){break;} } } }
    static class BreakS implements Stmt { public void exec(Env e){throw new Break();} } static class ContS implements Stmt{public void exec(Env e){throw new Cont();}}
    static class ReturnS implements Stmt { Expr x; ReturnS(Expr x){this.x=x;} public void exec(Env e){throw new Return(x==null?Val.nil():x.eval(e));} }
    static class FuncS implements Stmt { String n; List<String> ps; Stmt b; FuncS(String n,List<String>p,Stmt b){this.n=n;ps=p;this.b=b;} public void exec(Env e){e.funcs.put(n.toLowerCase(Locale.ROOT),this);} }

    static class Lit implements Expr { Val v; Lit(Val v){this.v=v;} public Val eval(Env e){return v;} }
    static class Interp implements Expr { String s; Interp(String s){this.s=s;} public Val eval(Env e){StringBuffer out=new StringBuffer(); java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\$[A-Za-z_][A-Za-z0-9_]*").matcher(s); while(m.find())m.appendReplacement(out, java.util.regex.Matcher.quoteReplacement(str(e.get(m.group())))); m.appendTail(out); return Val.str(out.toString());} }
    static class Var implements Expr { String n; Var(String n){this.n=n;} public Val eval(Env e){return e.get(n);} }
    static class Assign implements Expr { Expr l,r; String op; Assign(Expr l,String op,Expr r){this.l=l;this.op=op;this.r=r;} public Val eval(Env e){Val rv=r.eval(e); if(l instanceof Var){String n=((Var)l).n; if(op.equals("=")) return e.set(n,rv); Val nv=bin(op.substring(0,1),e.get(n),rv); return e.set(n,nv);} if(l instanceof Index){((Index)l).set(e,rv); return rv;} return rv;} }
    static class Unary implements Expr { String op; Expr x; Unary(String o,Expr x){op=o;this.x=x;} public Val eval(Env e){ if(op.equals("!"))return Val.bool(!truth(x.eval(e))); if(op.equals("-"))return Val.num(-num(x.eval(e))); if(op.equals("++")&&x instanceof Var){String n=((Var)x).n; return e.set(n,Val.num(num(e.get(n))+1));} if(op.equals("--")&&x instanceof Var){String n=((Var)x).n; return e.set(n,Val.num(num(e.get(n))-1));} return x.eval(e);} }
    static class Post implements Expr { Expr x; String op; Post(Expr x,String o){this.x=x;op=o;} public Val eval(Env e){ if(x instanceof Var){String n=((Var)x).n; Val old=e.get(n); e.set(n,Val.num(num(old)+(op.equals("++")?1:-1))); return old;} return x.eval(e);} }
    static class Bin implements Expr { String op; Expr a,b; Bin(String o,Expr a,Expr b){op=o;this.a=a;this.b=b;} public Val eval(Env e){ if(op.equals("&&"))return Val.bool(truth(a.eval(e))&&truth(b.eval(e))); if(op.equals("||"))return Val.bool(truth(a.eval(e))||truth(b.eval(e))); return bin(op,a.eval(e),b.eval(e)); } }
    static class Index implements Expr { Expr a,i; Index(Expr a,Expr i){this.a=a;this.i=i;} public Val eval(Env e){Val x=a.eval(e); Object k=key(i.eval(e)); return x.map.getOrDefault(k,Val.nil());} void set(Env e,Val v){Val x=a.eval(e); if(x.type!=Type.ARR){x=Val.arr(); if(a instanceof Var)e.set(((Var)a).n,x);} Object k=i==null?x.nextKey():key(i.eval(e)); x.put(k,v);} }
    static class ArrayExpr implements Expr { List<Expr> keys, vals; ArrayExpr(List<Expr>k,List<Expr>v){keys=k;vals=v;} public Val eval(Env e){Val a=Val.arr(); for(int n=0;n<vals.size();n++){Object k=keys.get(n)==null?a.nextKey():key(keys.get(n).eval(e)); a.put(k,vals.get(n).eval(e));} return a;} }
    static class Tern implements Expr { Expr c,a,b; Tern(Expr c,Expr a,Expr b){this.c=c;this.a=a;this.b=b;} public Val eval(Env e){return truth(c.eval(e))?a.eval(e):b.eval(e);} }
    static class Call implements Expr { String n; List<Expr> as; Call(String n,List<Expr>a){this.n=n;as=a;} public Val eval(Env e){return call(e,n,as);} }

    static Val call(Env e, String name, List<Expr> as) {
        String n = name.toLowerCase(Locale.ROOT);
        List<Val> v = new ArrayList<>(); for(Expr x:as) v.add(x.eval(e));
        switch(n) {
            case "count": case "sizeof": return Val.num(v.isEmpty()?0:v.get(0).map.size());
            case "strlen": return Val.num(v.isEmpty()?0:str(v.get(0)).length());
            case "strtoupper": return Val.str(str(v.get(0)).toUpperCase(Locale.ROOT));
            case "strtolower": return Val.str(str(v.get(0)).toLowerCase(Locale.ROOT));
            case "trim": return Val.str(str(v.get(0)).trim());
            case "substr": {String s=str(v.get(0)); int st=(int)num(v.get(1)); int len=v.size()>2?(int)num(v.get(2)):s.length()-st; if(st<0)st=s.length()+st; return Val.str(s.substring(Math.max(0,st), Math.min(s.length(), Math.max(0,st)+Math.max(0,len))));}
            case "strpos": {int p=str(v.get(0)).indexOf(str(v.get(1))); return p<0?Val.bool(false):Val.num(p);}
            case "str_replace": return Val.str(str(v.get(2)).replace(str(v.get(0)), str(v.get(1))));
            case "explode": {Val a=Val.arr(); String[] parts=str(v.get(1)).split(java.util.regex.Pattern.quote(str(v.get(0))),-1); for(int i=0;i<parts.length;i++)a.put(i,Val.str(parts[i])); return a;}
            case "implode": case "join": {String sep=v.size()>1?str(v.get(0)):""; Val arr=v.size()>1?v.get(1):v.get(0); List<String> ss=new ArrayList<>(); for(Val x:arr.map.values())ss.add(str(x)); return Val.str(String.join(sep,ss));}
            case "array_sum": {double s=0; for(Val x:v.get(0).map.values())s+=num(x); return Val.num(s);}
            case "range": {Val a=Val.arr(); int lo=(int)num(v.get(0)), hi=(int)num(v.get(1)), step=lo<=hi?1:-1; for(int i=lo; step>0?i<=hi:i>=hi; i+=step)a.put(a.nextKey(),Val.num(i)); return a;}
            case "isset": return Val.bool(!v.isEmpty() && v.get(0).type!=Type.NULL);
            case "empty": return Val.bool(v.isEmpty() || !truth(v.get(0)));
            case "var_dump": for(Val x:v) dump(x,0); return Val.nil();
            case "print_r": if(!v.isEmpty()) printR(v.get(0),0); return Val.bool(true);
            case "json_encode": return Val.str(json(v.get(0)));
            case "abs": return Val.num(Math.abs(num(v.get(0))));
            case "max": {double m=-Double.MAX_VALUE; for(Val x:v)m=Math.max(m,num(x)); return Val.num(m);}
            case "min": {double m=Double.MAX_VALUE; for(Val x:v)m=Math.min(m,num(x)); return Val.num(m);}
            case "floor": return Val.num(Math.floor(num(v.get(0))));
            case "ceil": return Val.num(Math.ceil(num(v.get(0))));
            case "round": return Val.num(Math.round(num(v.get(0))));
            case "is_array": return Val.bool(!v.isEmpty()&&v.get(0).type==Type.ARR);
            case "is_string": return Val.bool(!v.isEmpty()&&v.get(0).type==Type.STR);
            case "is_numeric": return Val.bool(!v.isEmpty()&&str(v.get(0)).matches("-?\\d+(\\.\\d+)?"));
            case "intval": return Val.num((long)num(v.get(0)));
            case "floatval": return Val.num(num(v.get(0)));
            case "strval": return Val.str(str(v.get(0)));
            case "file_get_contents": try { String path=str(v.get(0)); return Val.str(path.equals("php://stdin")?readAll(System.in):Files.readString(Path.of(path))); } catch(Exception ex) { return Val.bool(false); }
            case "file": try { Val a=Val.arr(); List<String> lines=Files.readAllLines(Path.of(str(v.get(0)))); for(String line:lines)a.put(a.nextKey(),Val.str(line+"\n")); return a; } catch(Exception ex) { return Val.bool(false); }
        }
        FuncS f=e.funcs.get(n); if(f!=null){Env c=new Env(e); for(int i=0;i<f.ps.size();i++)c.set(f.ps.get(i), i<v.size()?v.get(i):Val.nil()); try{f.b.exec(c);}catch(Return r){return r.value;} return Val.nil();}
        return Val.nil();
    }

    static class Parser {
        List<Tok> t; int p=0; Parser(String s){t=new Lex(s).scan();}
        Block program(){List<Stmt>s=new ArrayList<>(); while(!peek("EOF")){ if(match(";"))continue; s.add(stmt()); } return new Block(s);}
        Stmt stmt(){
            if(match("{")){List<Stmt>s=new ArrayList<>(); while(!match("}"))s.add(stmt()); return new Block(s);}
            if(match("echo")){List<Expr>x=new ArrayList<>(); do{x.add(expr());}while(match(",")); semi(); return new Echo(x);}
            if(match("print")){Expr x=expr(); semi(); return new Echo(List.of(x));}
            if(match("if")){need("("); Expr c=expr(); need(")"); Stmt th=stmt(); Stmt el=null; if(match("elseif")){need("("); Expr ec=expr(); need(")"); el=new If(ec,stmt(),match("else")?stmt():null);} else if(match("else")) el=stmt(); return new If(c,th,el);}
            if(match("while")){need("("); Expr c=expr(); need(")"); return new While(c,stmt());}
            if(match("for")){need("("); Expr a=peek(";")?null:expr(); need(";"); Expr b=peek(";")?null:expr(); need(";"); Expr c=peek(")")?null:expr(); need(")"); return new For(a,b,c,stmt());}
            if(match("foreach")){need("("); Expr ar=expr(); need("as"); String k=null,v; String first=var(); if(match("=>")){k=first; v=var();} else v=first; need(")"); return new Foreach(ar,k,v,stmt());}
            if(match("function")){String n=id(); need("("); List<String>ps=new ArrayList<>(); if(!peek(")")) do{ps.add(var());}while(match(",")); need(")"); return new FuncS(n,ps,stmt());}
            if(match("return")){Expr x=peek(";")?null:expr(); semi(); return new ReturnS(x);}
            if(match("break")){semi(); return new BreakS();} if(match("continue")){semi(); return new ContS();}
            Expr x=expr(); semi(); return new ExprStmt(x);
        }
        Expr expr(){return assign();}
        Expr assign(){Expr x=tern(); if(match("=")||match("+=")||match("-=")||match(".=")||match("*=")||match("/=")){String o=prev().s; return new Assign(x,o,assign());} return x;}
        Expr tern(){Expr x=or(); if(match("?")){Expr a=expr(); need(":"); Expr b=expr(); return new Tern(x,a,b);} return x;}
        Expr or(){Expr x=and(); while(match("||")||match("or"))x=new Bin(prev().s,x,and()); return x;}
        Expr and(){Expr x=eq(); while(match("&&")||match("and"))x=new Bin(prev().s,x,eq()); return x;}
        Expr eq(){Expr x=cmp(); while(match("==")||match("!=")||match("===")||match("!=="))x=new Bin(prev().s,x,cmp()); return x;}
        Expr cmp(){Expr x=add(); while(match("<")||match(">")||match("<=")||match(">="))x=new Bin(prev().s,x,add()); return x;}
        Expr add(){Expr x=mul(); while(match("+")||match("-")||match("."))x=new Bin(prev().s,x,mul()); return x;}
        Expr mul(){Expr x=un(); while(match("*")||match("/")||match("%"))x=new Bin(prev().s,x,un()); return x;}
        Expr un(){ if(match("!")||match("-")||match("++")||match("--"))return new Unary(prev().s,un()); return post();}
        Expr post(){Expr x=prim(); while(true){ if(match("[")){Expr i=peek("]")?null:expr(); need("]"); x=new Index(x,i);} else if(match("++")||match("--"))x=new Post(x,prev().s); else break;} return x;}
        Expr prim(){
            if(match("(")){Expr x=expr(); need(")"); return x;}
            if(match("[")) return array("]");
            if(match("array")){need("("); return array(")");}
            if(match("true"))return new Lit(Val.bool(true)); if(match("false"))return new Lit(Val.bool(false)); if(match("null"))return new Lit(Val.nil());
            if(peekType("NUM"))return new Lit(Val.num(Double.parseDouble(next().s)));
            if(peekType("STR"))return new Lit(Val.str(next().s));
            if(peekType("ISTR"))return new Interp(next().s);
            if(peekType("VAR"))return new Var(next().s);
            String n=id(); if(match("(")){List<Expr>a=new ArrayList<>(); if(!peek(")"))do{a.add(expr());}while(match(",")); need(")"); return new Call(n,a);} return new Lit(Val.str(n));
        }
        Expr array(String end){List<Expr>k=new ArrayList<>(),v=new ArrayList<>(); if(!peek(end)) do{Expr a=expr(); if(match("=>")){k.add(a); v.add(expr());} else {k.add(null); v.add(a);} }while(match(",")); need(end); return new ArrayExpr(k,v);}
        void semi(){match(";");} boolean match(String s){if(peek(s)){p++;return true;}return false;} boolean peek(String s){return t.get(p).s.equalsIgnoreCase(s);} boolean peekType(String s){return t.get(p).type.equals(s);} Tok next(){return t.get(p++);} Tok prev(){return t.get(p-1);} void need(String s){if(!match(s))throw new RuntimeException("unexpected token '"+t.get(p).s+"', expecting '"+s+"'");} String id(){if(!peekType("ID"))throw new RuntimeException("unexpected token "+t.get(p).s);return next().s;} String var(){if(!peekType("VAR"))throw new RuntimeException("expected variable");return next().s;}
    }

    static class Lex { String s; int p; Lex(String s){this.s=s;} List<Tok> scan(){List<Tok> r=new ArrayList<>(); while(p<s.length()){char c=s.charAt(p); if(Character.isWhitespace(c)){p++;continue;} if(c=='/'&&p+1<s.length()&&s.charAt(p+1)=='/'){while(p<s.length()&&s.charAt(p)!='\n')p++;continue;} if(c=='#'){while(p<s.length()&&s.charAt(p)!='\n')p++;continue;} if(c=='/'&&p+1<s.length()&&s.charAt(p+1)=='*'){p+=2; while(p+1<s.length()&&!(s.charAt(p)=='*'&&s.charAt(p+1)=='/'))p++; p+=Math.min(2,s.length()-p); continue;} if(c=='$'){int st=p++; while(p<s.length()&&(Character.isLetterOrDigit(s.charAt(p))||s.charAt(p)=='_'))p++; r.add(new Tok("VAR",s.substring(st,p))); continue;} if(Character.isDigit(c)){int st=p++; while(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'))p++; r.add(new Tok("NUM",s.substring(st,p))); continue;} if(c=='\''||c=='"'){String val=string(c); r.add(new Tok(c=='"'&&val.contains("$")?"ISTR":"STR",val)); continue;} if(Character.isLetter(c)||c=='_'){int st=p++; while(p<s.length()&&(Character.isLetterOrDigit(s.charAt(p))||s.charAt(p)=='_'))p++; r.add(new Tok("ID",s.substring(st,p))); continue;} String two=p+1<s.length()?s.substring(p,p+2):""; String three=p+2<s.length()?s.substring(p,p+3):""; if(Set.of("===","!==").contains(three)){r.add(new Tok("SYM",three));p+=3;continue;} if(Set.of("==","!=","<=",">=","&&","||","++","--","=>","+=","-=","*=","/=",".=").contains(two)){r.add(new Tok("SYM",two));p+=2;continue;} r.add(new Tok("SYM",""+c)); p++; } r.add(new Tok("EOF","EOF")); return r;} String string(char q){p++; StringBuilder b=new StringBuilder(); while(p<s.length()&&s.charAt(p)!=q){char c=s.charAt(p++); if(c=='\\'&&p<s.length()){char n=s.charAt(p++); switch(n){case 'n':b.append('\n');break;case 't':b.append('\t');break;case 'r':b.append('\r');break;default:b.append(n);} } else b.append(c);} if(p<s.length())p++; return b.toString();} }
    static class Tok { String type,s; Tok(String t,String s){type=t;this.s=s;} }

    enum Type {NULL, NUM, STR, BOOL, ARR}
    static class Val { Type type; double n; String s; boolean b; LinkedHashMap<Object,Val> map=new LinkedHashMap<>(); static Val nil(){Val v=new Val();v.type=Type.NULL;return v;} static Val num(double n){Val v=new Val();v.type=Type.NUM;v.n=n;return v;} static Val str(String s){Val v=new Val();v.type=Type.STR;v.s=s;return v;} static Val bool(boolean b){Val v=new Val();v.type=Type.BOOL;v.b=b;return v;} static Val arr(){Val v=new Val();v.type=Type.ARR;return v;} void put(Object k,Val v){map.put(k,v);} int nextKey(){int m=0; for(Object k:map.keySet())if(k instanceof Integer)m=Math.max(m,(Integer)k+1); return m;} }
    static class Env { Map<String,Val> vars=new HashMap<>(); Map<String,FuncS> funcs; Env(){funcs=new HashMap<>();} Env(Env p){funcs=p.funcs;} Val get(String n){return vars.getOrDefault(n,Val.nil());} Val set(String n,Val v){vars.put(n,v);return v;} }
    static Val bin(String op, Val a, Val b){ switch(op){case ".":return Val.str(str(a)+str(b)); case "+":return Val.num(num(a)+num(b)); case "-":return Val.num(num(a)-num(b)); case "*":return Val.num(num(a)*num(b)); case "/":return Val.num(num(a)/num(b)); case "%":return Val.num(num(a)%num(b)); case "==":case "===":return Val.bool(str(a).equals(str(b))); case "!=":case "!==":return Val.bool(!str(a).equals(str(b))); case "<":return Val.bool(num(a)<num(b)); case ">":return Val.bool(num(a)>num(b)); case "<=":return Val.bool(num(a)<=num(b)); case ">=":return Val.bool(num(a)>=num(b)); default:return Val.nil();} }
    static double num(Val v){ if(v.type==Type.NUM)return v.n; if(v.type==Type.BOOL)return v.b?1:0; if(v.type==Type.STR)try{return Double.parseDouble(v.s.trim().isEmpty()?"0":v.s.trim());}catch(Exception e){return 0;} return 0; }
    static String str(Val v){ switch(v.type){case NULL:return ""; case BOOL:return v.b?"1":""; case NUM:return fmt(v); case ARR:return "Array"; default:return v.s;} }
    static String fmt(Val v){ if(v.type==Type.NUM){ if(Math.rint(v.n)==v.n)return String.valueOf((long)v.n); return String.valueOf(v.n);} return str(v); }
    static boolean truth(Val v){ if(v.type==Type.NULL)return false; if(v.type==Type.BOOL)return v.b; if(v.type==Type.NUM)return v.n!=0; if(v.type==Type.STR)return !v.s.isEmpty()&&!v.s.equals("0"); return !v.map.isEmpty(); }
    static Object key(Val v){ if(v.type==Type.NUM)return (int)v.n; return str(v); } static Val keyVal(Object k){return k instanceof Integer?Val.num((Integer)k):Val.str(String.valueOf(k));}
    static void dump(Val v,int ind){String pad=" ".repeat(ind); switch(v.type){case NULL:System.out.println("NULL");break; case BOOL:System.out.println("bool("+(v.b?"true":"false")+")");break; case NUM:System.out.println((Math.rint(v.n)==v.n?"int("+((long)v.n)+")":"float("+v.n+")"));break; case STR:System.out.println("string("+v.s.length()+") \""+v.s+"\"");break; case ARR:System.out.println("array("+v.map.size()+") {"); for(var e:v.map.entrySet()){System.out.println(pad+"  ["+e.getKey()+"]=>"); dump(e.getValue(),ind+2);} System.out.println(pad+"}");}}
    static void printR(Val v,int ind){ if(v.type!=Type.ARR){System.out.print(fmt(v)); return;} String pad=" ".repeat(ind); System.out.println("Array"); System.out.println(pad+"("); for(var e:v.map.entrySet()){System.out.print(pad+"    ["+e.getKey()+"] => "); if(e.getValue().type==Type.ARR){printR(e.getValue(),ind+4);} else System.out.println(fmt(e.getValue()));} System.out.println(pad+")");}
    static String json(Val v){ switch(v.type){case NULL:return "null"; case BOOL:return v.b?"true":"false"; case NUM:return fmt(v); case STR:return "\""+v.s.replace("\\","\\\\").replace("\"","\\\"")+"\""; case ARR: List<String> ss=new ArrayList<>(); boolean list=true; int i=0; for(Object k:v.map.keySet())if(!(k instanceof Integer)||((Integer)k)!=i++)list=false; for(var e:v.map.entrySet())ss.add((list?"":json(Val.str(String.valueOf(e.getKey())))+":")+json(e.getValue())); return (list?"[":"{")+String.join(",",ss)+(list?"]":"}"); default:return "null";} }
    static class Exit extends RuntimeException { int code; Exit(int c){code=c;} } static class Return extends RuntimeException{Val value;Return(Val v){value=v;}} static class Break extends RuntimeException{} static class Cont extends RuntimeException{}
}
