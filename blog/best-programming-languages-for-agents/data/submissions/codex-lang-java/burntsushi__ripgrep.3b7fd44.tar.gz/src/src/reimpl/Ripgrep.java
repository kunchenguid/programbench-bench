package reimpl;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.regex.*;

public class Ripgrep {
    static class Opt {
        List<String> patterns = new ArrayList<>(), paths = new ArrayList<>(), globs = new ArrayList<>();
        boolean fixed, ignoreCase, smartCase, invert, lineRegexp, wordRegexp, hidden, noIgnore, text;
        boolean lineNumber, noLineNumber, withFilename, noFilename, count, countMatches, listMatches, listWithout;
        boolean onlyMatching, quiet, files, typeList, version, helpShort, helpLong, includeZero, column, vimgrep;
        boolean json, passthru, trim, nullSep, follow, sortPath, sortReverse, unrestrictedSeen;
        int after = 0, before = 0, maxCount = -1, maxDepth = Integer.MAX_VALUE, maxColumns = 0;
        String replace = null, sep = ":", ctxSep = "--";
        Set<String> typeInclude = new LinkedHashSet<>(), typeExclude = new LinkedHashSet<>();
    }

    static class FileResult {
        Path path; String display; List<LineMatch> lines = new ArrayList<>();
        int matchLines, matchCount; boolean binary;
    }
    static class LineMatch {
        int no; String text; List<int[]> spans;
        LineMatch(int n, String t, List<int[]> s) { no=n; text=t; spans=s; }
    }

    public static void main(String[] args) {
        int code;
        try { code = new Ripgrep().run(args); }
        catch (BrokenPipeException e) { code = 0; }
        catch (Exception e) { System.err.println("rg: " + e.getMessage()); code = 2; }
        System.exit(code);
    }

    int run(String[] args) throws Exception {
        Opt o = parse(args);
        if (o.version) { version(); return 0; }
        if (o.helpShort || o.helpLong) { help(o.helpLong); return 0; }
        if (o.typeList) { typeList(); return 0; }
        if (o.files) {
            List<Path> files = collect(o.paths.isEmpty()? List.of(".") : o.paths, o);
            for (Path p: files) printPath(display(p), o);
            return files.isEmpty()?1:0;
        }
        if (o.patterns.isEmpty()) {
            System.err.println("rg: ripgrep requires at least one pattern to execute a search");
            return 2;
        }
        if (o.smartCase) {
            boolean upper=false; for (String p:o.patterns) for(char c:p.toCharArray()) if(Character.isUpperCase(c)) upper=true;
            if (!upper) o.ignoreCase = true;
        }
        Pattern pat = compilePattern(o);
        List<Path> inputs;
        boolean stdin = o.paths.size() == 1 && o.paths.get(0).equals("-");
        if (o.paths.isEmpty()) inputs = collect(List.of("."), o);
        else inputs = collect(o.paths, o);
        boolean recursiveOrMulti = o.withFilename || (!o.noFilename && (inputs.size() > 1 || anyDirectory(o.paths.isEmpty()?List.of("."):o.paths)));
        boolean any = false;
        if (stdin) {
            FileResult r = searchReader("<stdin>", new InputStreamReader(System.in, StandardCharsets.UTF_8), pat, o);
            any |= r.matchLines > 0;
            emit(r, o, false);
        } else {
            for (Path p: inputs) {
                if (o.quiet && any) break;
                FileResult r = searchFile(p, pat, o);
                if (r == null) continue;
                if (r.matchLines > 0) any = true;
                emit(r, o, recursiveOrMulti);
            }
        }
        return any ? 0 : 1;
    }

    Opt parse(String[] args) throws IOException {
        Opt o = new Opt();
        boolean positional = false, sawPatternFlag = false;
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            if (positional || !a.startsWith("-") || a.equals("-")) {
                if (!sawPatternFlag && o.patterns.isEmpty() && !o.files && !o.typeList) o.patterns.add(a); else o.paths.add(a);
                continue;
            }
            if (a.equals("--")) { positional=true; continue; }
            String val = null;
            int eq = a.indexOf('=');
            String name = eq>=0 ? a.substring(0,eq) : a;
            if (eq>=0) val = a.substring(eq+1);
            switch (name) {
                case "--help": o.helpLong=true; break; case "-h": o.helpShort=true; break;
                case "--version": case "-V": o.version=true; break; case "--type-list": o.typeList=true; break;
                case "--files": o.files=true; break; case "--regexp": case "-e": o.patterns.add(val!=null?val:req(args,++i,a)); sawPatternFlag=true; break;
                case "--file": case "-f": readPatterns(o, val!=null?val:req(args,++i,a)); sawPatternFlag=true; break;
                case "--glob": case "-g": o.globs.add(val!=null?val:req(args,++i,a)); break;
                case "--ignore-case": o.ignoreCase=true; break; case "--case-sensitive": o.ignoreCase=false; o.smartCase=false; break;
                case "--smart-case": o.smartCase=true; break; case "--fixed-strings": o.fixed=true; break;
                case "--invert-match": o.invert=true; break; case "--line-regexp": o.lineRegexp=true; break; case "--word-regexp": o.wordRegexp=true; break;
                case "--hidden": case "-.": o.hidden=true; break; case "--no-ignore": o.noIgnore=true; break; case "--text": case "--binary": o.text=true; break;
                case "--line-number": o.lineNumber=true; break; case "--no-line-number": o.noLineNumber=true; break;
                case "--with-filename": o.withFilename=true; break; case "--no-filename": o.noFilename=true; break;
                case "--count": o.count=true; break; case "--count-matches": o.countMatches=true; break;
                case "--files-with-matches": o.listMatches=true; break; case "--files-without-match": o.listWithout=true; break;
                case "--only-matching": o.onlyMatching=true; break; case "--quiet": o.quiet=true; break;
                case "--include-zero": o.includeZero=true; break; case "--column": o.column=true; break; case "--vimgrep": o.vimgrep=true; o.withFilename=true; o.lineNumber=true; o.column=true; break;
                case "--json": o.json=true; break; case "--passthru": case "--passthrough": o.passthru=true; break;
                case "--trim": o.trim=true; break; case "--null": o.nullSep=true; break; case "--follow": o.follow=true; break;
                case "--sort": o.sortPath = "path".equals(val!=null?val:req(args,++i,a)); break;
                case "--sortr": o.sortPath = "path".equals(val!=null?val:req(args,++i,a)); o.sortReverse=true; break;
                case "--sort-files": o.sortPath=true; break;
                case "--replace": case "-r": o.replace=val!=null?val:req(args,++i,a); break;
                case "--after-context": case "-A": o.after=num(val!=null?val:req(args,++i,a)); break;
                case "--before-context": case "-B": o.before=num(val!=null?val:req(args,++i,a)); break;
                case "--context": case "-C": o.after=o.before=num(val!=null?val:req(args,++i,a)); break;
                case "--max-count": case "-m": o.maxCount=num(val!=null?val:req(args,++i,a)); break;
                case "--max-depth": case "-d": o.maxDepth=num(val!=null?val:req(args,++i,a)); break;
                case "--max-columns": case "-M": o.maxColumns=num(val!=null?val:req(args,++i,a)); break;
                case "--type": case "-t": o.typeInclude.add(val!=null?val:req(args,++i,a)); break;
                case "--type-not": case "-T": o.typeExclude.add(val!=null?val:req(args,++i,a)); break;
                case "--pcre2-version": System.err.println("PCRE2 is not available in this build of ripgrep."); System.exit(2); break;
                default:
                    if (a.startsWith("--")) { if (takesIgnoredValue(name) && val==null) i++; break; }
                    i = parseShort(a, args, i, o);
            }
        }
        return o;
    }

    int parseShort(String a, String[] args, int i, Opt o) throws IOException {
        for (int j=1;j<a.length();j++) {
            char c=a.charAt(j); String rest=a.substring(j+1);
            switch(c) {
                case 'i': o.ignoreCase=true; break; case 's': o.ignoreCase=false; o.smartCase=false; break;
                case 'S': o.smartCase=true; break; case 'F': o.fixed=true; break; case 'v': o.invert=true; break;
                case 'x': o.lineRegexp=true; break; case 'w': o.wordRegexp=true; break; case 'a': o.text=true; break;
                case 'n': o.lineNumber=true; break; case 'N': o.noLineNumber=true; break; case 'H': o.withFilename=true; break; case 'I': o.noFilename=true; break;
                case 'c': o.count=true; break; case 'l': o.listMatches=true; break; case 'o': o.onlyMatching=true; break;
                case 'q': o.quiet=true; break; case '0': o.nullSep=true; break; case 'L': o.follow=true; break;
                case 'p': o.lineNumber=true; break; case 'u': if(!o.unrestrictedSeen){o.noIgnore=true;o.unrestrictedSeen=true;} else if(!o.hidden) o.hidden=true; else o.text=true; break;
                case 'e': o.patterns.add(!rest.isEmpty()?rest:req(args,++i,a)); return i;
                case 'f': readPatterns(o, !rest.isEmpty()?rest:req(args,++i,a)); return i;
                case 'g': o.globs.add(!rest.isEmpty()?rest:req(args,++i,a)); return i;
                case 'A': o.after=num(!rest.isEmpty()?rest:req(args,++i,a)); return i;
                case 'B': o.before=num(!rest.isEmpty()?rest:req(args,++i,a)); return i;
                case 'C': o.after=o.before=num(!rest.isEmpty()?rest:req(args,++i,a)); return i;
                case 'm': o.maxCount=num(!rest.isEmpty()?rest:req(args,++i,a)); return i;
                case 'd': o.maxDepth=num(!rest.isEmpty()?rest:req(args,++i,a)); return i;
                case 'M': o.maxColumns=num(!rest.isEmpty()?rest:req(args,++i,a)); return i;
                case 't': o.typeInclude.add(!rest.isEmpty()?rest:req(args,++i,a)); return i;
                case 'T': o.typeExclude.add(!rest.isEmpty()?rest:req(args,++i,a)); return i;
                default: break;
            }
        }
        return i;
    }

    Pattern compilePattern(Opt o) {
        List<String> ps = new ArrayList<>();
        for (String p:o.patterns) {
            if (o.fixed) p = Pattern.quote(p);
            if (o.wordRegexp) p = "(?<![\\p{Alnum}_])(?:" + p + ")(?![\\p{Alnum}_])";
            if (o.lineRegexp) p = "^(?:" + p + ")$";
            ps.add(p);
        }
        int flags = Pattern.MULTILINE;
        if (o.ignoreCase) flags |= Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
        return Pattern.compile(String.join("|", ps), flags);
    }

    List<Path> collect(List<String> roots, Opt o) throws IOException {
        List<Path> out = new ArrayList<>();
        for (String s: roots) {
            Path p=Paths.get(s);
            if (Files.isDirectory(p)) {
                final Path root=p; Set<String> ignores = loadIgnores(root, o);
                Files.walkFileTree(root, o.follow?EnumSet.of(FileVisitOption.FOLLOW_LINKS):EnumSet.noneOf(FileVisitOption.class), o.maxDepth, new SimpleFileVisitor<>() {
                    public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                        if (!dir.equals(root) && skipPath(root, dir, true, o, ignores)) return FileVisitResult.SKIP_SUBTREE;
                        return FileVisitResult.CONTINUE;
                    }
                    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                        if (!skipPath(root, file, false, o, ignores)) out.add(file);
                        return FileVisitResult.CONTINUE;
                    }
                    public FileVisitResult visitFileFailed(Path file, IOException exc) { return FileVisitResult.CONTINUE; }
                });
            } else if (Files.exists(p)) out.add(p);
        }
        if (o.sortPath) out.sort(Comparator.comparing(Ripgrep::display));
        if (o.sortReverse) Collections.reverse(out);
        return out;
    }

    boolean skipPath(Path root, Path p, boolean dir, Opt o, Set<String> ignores) {
        String name = p.getFileName()==null?"" : p.getFileName().toString();
        if (!o.hidden && name.startsWith(".")) return true;
        String rel = root.relativize(p).toString().replace('\\','/');
        if (!o.noIgnore && matchesIgnore(rel, name, ignores)) return true;
        if (!o.globs.isEmpty() && !matchesGlobs(rel, name, o.globs)) return true;
        if (!dir && !typeOK(p, o)) return true;
        return false;
    }

    Set<String> loadIgnores(Path root, Opt o) {
        Set<String> set = new LinkedHashSet<>();
        if (o.noIgnore) return set;
        for (String f: List.of(".ignore",".rgignore",".gitignore")) {
            Path ip=root.resolve(f);
            if (Files.isRegularFile(ip)) try {
                for (String line: Files.readAllLines(ip)) {
                    line=line.trim(); if(!line.isEmpty() && !line.startsWith("#")) set.add(line);
                }
            } catch(IOException ignored){}
        }
        set.add(".git/"); return set;
    }

    FileResult searchFile(Path p, Pattern pat, Opt o) {
        try {
            if (!o.text && isBinary(p)) return null;
            return searchReader(display(p), Files.newBufferedReader(p, StandardCharsets.UTF_8), pat, o);
        } catch (MalformedInputException e) {
            try { return searchReader(display(p), Files.newBufferedReader(p, StandardCharsets.ISO_8859_1), pat, o); }
            catch(Exception ignored) { return null; }
        } catch(Exception e) { if(!o.quiet) System.err.println("rg: " + p + ": " + e.getMessage()); return null; }
    }

    FileResult searchReader(String display, Reader reader, Pattern pat, Opt o) throws IOException {
        FileResult r = new FileResult(); r.display=display; int no=0, matchedLines=0;
        try (BufferedReader br = new BufferedReader(reader)) {
            String line;
            while ((line=br.readLine())!=null) {
                no++; String original=line; Matcher m=pat.matcher(line); List<int[]> spans = new ArrayList<>();
                while (m.find()) { if (m.start()==m.end()) { if (m.end()<line.length()) m.region(m.end()+1, line.length()); continue; } spans.add(new int[]{m.start(),m.end()}); }
                boolean hit = !spans.isEmpty(); if (o.invert) hit = !hit;
                if (o.passthru) hit = true;
                if (hit) {
                    if (!o.passthru || !spans.isEmpty()) { matchedLines++; r.matchCount += o.invert ? 1 : Math.max(1, spans.size()); }
                    if (o.trim) original = original.stripLeading();
                    r.lines.add(new LineMatch(no, original, spans));
                    if (o.maxCount >= 0 && matchedLines >= o.maxCount) break;
                }
            }
        }
        r.matchLines = matchedLines;
        return r;
    }

    void emit(FileResult r, Opt o, boolean showFile) throws BrokenPipeException {
        if (o.quiet) return;
        boolean has = r.matchLines > 0;
        if (o.listMatches) { if (has) printPath(r.display, o); return; }
        if (o.listWithout) { if (!has) printPath(r.display, o); return; }
        if (o.count || o.countMatches) {
            if (has || o.includeZero) {
                String s = Integer.toString(o.countMatches || o.onlyMatching ? r.matchCount : r.matchLines);
                if (showFile) s = r.display + ":" + s;
                println(s);
            }
            return;
        }
        if (o.json) { emitJson(r); return; }
        for (LineMatch lm: r.lines) {
            if (o.onlyMatching && !o.invert && !lm.spans.isEmpty()) {
                for (int[] sp: lm.spans) {
                    String text = lm.text.substring(sp[0], sp[1]);
                    if (o.replace != null) text = replaceOne(text, o.replace);
                    printLinePrefix(r.display, lm.no, sp[0]+1, showFile, o);
                    println(text);
                }
            } else {
                String text = lm.text;
                if (o.replace != null && !o.invert) text = compilePatternForReplace(o).matcher(text).replaceAll(massageReplacement(o.replace));
                printLinePrefix(r.display, lm.no, lm.spans.isEmpty()?1:lm.spans.get(0)[0]+1, showFile, o);
                println(text);
            }
        }
    }

    Pattern compilePatternForReplace(Opt o) { return compilePattern(o); }
    String replaceOne(String s, String repl) { return s.replaceAll(".*", massageReplacement(repl)); }
    String massageReplacement(String r) { return r.replace("$$", "\\$").replaceAll("\\$(\\d+)", "\\\\$$1"); }
    void printLinePrefix(String file, int line, int col, boolean showFile, Opt o) throws BrokenPipeException {
        StringBuilder sb=new StringBuilder();
        if (showFile) sb.append(file).append(':');
        if (o.lineNumber && !o.noLineNumber) sb.append(line).append(':');
        if (o.column) sb.append(col).append(':');
        print(sb.toString());
    }
    void printPath(String p, Opt o) throws BrokenPipeException { print(p); print(o.nullSep ? "\0" : "\n"); }
    static void print(String s) throws BrokenPipeException { try { System.out.print(s); } catch(Exception e){ throw new BrokenPipeException(); } }
    static void println(String s) throws BrokenPipeException { print(s); print("\n"); }

    void emitJson(FileResult r) throws BrokenPipeException {
        if (r.matchLines==0) return;
        println("{\"type\":\"begin\",\"data\":{\"path\":{\"text\":\""+js(r.display)+"\"}}}");
        for (LineMatch lm:r.lines) println("{\"type\":\"match\",\"data\":{\"path\":{\"text\":\""+js(r.display)+"\"},\"lines\":{\"text\":\""+js(lm.text+"\\n")+"\"},\"line_number\":"+lm.no+"}}");
        println("{\"type\":\"end\",\"data\":{\"path\":{\"text\":\""+js(r.display)+"\"},\"stats\":{\"matches\":"+r.matchCount+",\"matched_lines\":"+r.matchLines+"}}}");
    }

    static boolean isBinary(Path p) {
        try (InputStream in=Files.newInputStream(p)) { byte[] b=in.readNBytes(8192); for(byte x:b) if(x==0) return true; }
        catch(IOException ignored){} return false;
    }
    static boolean hasReadableStdin() { return false; }
    static boolean anyDirectory(List<String> ps) { for(String s:ps) if(Files.isDirectory(Paths.get(s))) return true; return false; }
    static String display(Path p) { String s=p.toString().replace('\\','/'); return s.equals(".")?".":(s.startsWith("./")?s.substring(2):s); }
    static String req(String[] a,int i,String opt){ if(i>=a.length) throw new IllegalArgumentException(opt+" requires a value"); return a[i]; }
    static int num(String s){ try{return Integer.parseInt(s.replaceAll("[^0-9].*$",""));}catch(Exception e){return 0;} }
    static void readPatterns(Opt o,String file) throws IOException { List<String> ls=file.equals("-")?new BufferedReader(new InputStreamReader(System.in)).lines().toList():Files.readAllLines(Paths.get(file)); o.patterns.addAll(ls); }
    static boolean takesIgnoredValue(String name){ return Set.of("--color","--colors","--engine","--encoding","--pre","--pre-glob","--threads","--path-separator","--context-separator","--field-context-separator","--field-match-separator","--type-add","--type-clear","--max-filesize","--ignore-file","--generate","--hostname-bin","--hyperlink-format","--dfa-size-limit","--regex-size-limit").contains(name); }
    static boolean matchesGlobs(String rel,String name,List<String> globs){ boolean inc=false, anyInc=false; for(String g:globs){ boolean neg=g.startsWith("!"); if(neg)g=g.substring(1); boolean m=glob(g,rel)||glob(g,name); if(!neg) anyInc=true; if(m && neg) return false; if(m) inc=true; } return !anyInc || inc; }
    static boolean matchesIgnore(String rel,String name,Set<String> ignores){ for(String g:ignores){ boolean dir=g.endsWith("/"); if(dir)g=g.substring(0,g.length()-1); if(glob(g,rel)||glob(g,name)||rel.startsWith(g+"/")) return true; } return false; }
    static boolean glob(String g,String s){ StringBuilder r=new StringBuilder(); for(int i=0;i<g.length();i++){ char c=g.charAt(i); if(c=='*') r.append(".*"); else if(c=='?') r.append('.'); else if(".[]{}()+-^$|\\".indexOf(c)>=0) r.append('\\').append(c); else r.append(c);} return Pattern.compile(r.toString()).matcher(s).matches(); }
    static boolean typeOK(Path p, Opt o){ String n=p.getFileName().toString().toLowerCase(); if(!o.typeInclude.isEmpty()){ boolean ok=false; for(String t:o.typeInclude) if(typeMatch(n,t)) ok=true; if(!ok)return false;} for(String t:o.typeExclude) if(typeMatch(n,t)) return false; return true; }
    static boolean typeMatch(String n,String t){ return switch(t){ case "java" -> n.endsWith(".java"); case "rust","rs" -> n.endsWith(".rs"); case "py","python" -> n.endsWith(".py"); case "js","javascript" -> n.endsWith(".js")||n.endsWith(".jsx"); case "ts","typescript" -> n.endsWith(".ts")||n.endsWith(".tsx"); case "c" -> n.endsWith(".c")||n.endsWith(".h"); case "cpp","cxx" -> n.endsWith(".cc")||n.endsWith(".cpp")||n.endsWith(".cxx")||n.endsWith(".hpp"); case "md","markdown" -> n.endsWith(".md")||n.endsWith(".markdown"); case "json" -> n.endsWith(".json"); case "toml" -> n.endsWith(".toml"); case "html" -> n.endsWith(".html")||n.endsWith(".htm"); default -> false; }; }
    static String js(String s){ return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t"); }
    void version(){ System.out.println("ripgrep 14.1.1 (rev 719e15af5e)\n\nfeatures:-pcre2\nsimd(compile):+SSE2,-SSSE3,-AVX2\nsimd(runtime):+SSE2,+SSSE3,+AVX2\n\nPCRE2 is not available in this build of ripgrep."); }
    void help(boolean longHelp){ System.out.println("ripgrep 14.1.1 (rev 719e15af5e)\nAndrew Gallant <jamslam@gmail.com>\n\nripgrep (rg) recursively searches the current directory for lines matching\na regex pattern. By default, ripgrep will respect gitignore rules and\nautomatically skip hidden files/directories and binary files.\n\nUSAGE:\n  rg [OPTIONS] PATTERN [PATH ...]\n  rg [OPTIONS] --files [PATH ...]\n  rg [OPTIONS] --type-list\n\nCommon options: -e/--regexp, -f/--file, -i, -S, -F, -w, -x, -v, -n, -H, -I,\n-c, --count-matches, -l, --files-without-match, -o, -g, -t, -T, -u, --hidden,\n--no-ignore, --files, --type-list, -h/--help, -V/--version"); }
    void typeList(){ String[] lines={"ada: *.adb, *.ads","agda: *.agda, *.lagda","asm: *.S, *.asm, *.s","c: *.[chH], *.[chH].in","cpp: *.C, *.cc, *.cpp, *.cxx, *.h, *.hpp, *.hxx","css: *.css","go: *.go","html: *.htm, *.html","java: *.java","js: *.js, *.jsx","json: *.json","markdown: *.markdown, *.md, *.mdown, *.mkdn","py: *.py","rust: *.rs","toml: *.toml","ts: *.ts, *.tsx","xml: *.xml","yaml: *.yaml, *.yml"}; for(String l:lines) System.out.println(l); }
    static class BrokenPipeException extends Exception {}
}
