import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

public class BrotliTool {
    private static final String VERSION = "brotli 1.2.0";
    private static final String DEFAULT_SUFFIX = ".br";

    static class Options {
        boolean stdout;
        boolean decompress;
        boolean force;
        boolean remove;
        boolean test;
        boolean verbose;
        boolean noCopyStat;
        boolean squash;
        boolean concatenated;
        String output;
        String suffix = DEFAULT_SUFFIX;
        int quality = 11;
        int lgwin = 24;
        String dictionary;
        byte[] comment;
        List<String> files = new ArrayList<>();
    }

    public static void main(String[] args) {
        int rc;
        try {
            rc = run(args);
        } catch (CliException e) {
            System.err.println(e.getMessage());
            rc = 1;
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            rc = 1;
        }
        if (rc != 0) System.exit(rc);
    }

    private static int run(String[] args) throws Exception {
        Options opt = parse(args);
        if (opt.files.isEmpty()) opt.files.add("-");
        if (opt.output != null && opt.files.size() != 1) {
            throw new CliException("can not specify output file with multiple input files");
        }
        if (opt.test) {
            opt.decompress = true;
            opt.stdout = true;
        }

        boolean ok = true;
        for (String file : opt.files) {
            try {
                processOne(opt, file);
            } catch (CliException e) {
                System.err.println(e.getMessage());
                ok = false;
            }
        }
        return ok ? 0 : 1;
    }

    private static Options parse(String[] args) throws CliException {
        Options o = new Options();
        boolean filesOnly = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (filesOnly) {
                o.files.add(a);
                continue;
            }
            if (a.equals("--")) {
                filesOnly = true;
                continue;
            }
            if (!a.startsWith("-") || a.equals("-")) {
                o.files.add(a);
                continue;
            }
            if (a.equals("--help") || a.equals("-h")) {
                printHelp();
                System.exit(0);
            }
            if (a.equals("--version") || a.equals("-V")) {
                System.out.println(VERSION);
                System.exit(0);
            }
            if (a.startsWith("--")) {
                String name = a;
                String value = null;
                int eq = a.indexOf('=');
                if (eq >= 0) {
                    name = a.substring(0, eq);
                    value = a.substring(eq + 1);
                }
                switch (name) {
                    case "--stdout": setOnce(o.stdout, "write to standard output already set"); o.stdout = true; break;
                    case "--decompress": setOnce(o.decompress, "decompress already set"); o.decompress = true; break;
                    case "--force": o.force = true; break;
                    case "--rm": o.remove = true; break;
                    case "--keep": o.remove = false; break;
                    case "--no-copy-stat": o.noCopyStat = true; break;
                    case "--squash": o.squash = true; break;
                    case "--test": o.test = true; break;
                    case "--verbose": o.verbose = true; break;
                    case "--concatenated": o.concatenated = true; break;
                    case "--best": o.quality = 11; break;
                    case "--output": o.output = needValue(args, ++i, value, "--output"); break;
                    case "--quality": o.quality = parseInt(needValue(args, ++i, value, "--quality"), "quality"); break;
                    case "--lgwin": o.lgwin = parseInt(needValue(args, ++i, value, "--lgwin"), "lgwin"); break;
                    case "--large_window": o.lgwin = parseInt(needValue(args, ++i, value, "--large_window"), "large_window"); break;
                    case "--suffix": o.suffix = needValue(args, ++i, value, "--suffix"); break;
                    case "--dictionary": o.dictionary = needValue(args, ++i, value, "--dictionary"); break;
                    case "--comment": o.comment = decodeComment(needValue(args, ++i, value, "--comment")); break;
                    default: throw new CliException("unknown option [" + a + "]");
                }
                if (eq >= 0) i--;
            } else {
                i = parseShort(args, i, o);
            }
        }
        if (o.quality < 0 || o.quality > 11) throw new CliException("quality must be in range [0..11]");
        if (!(o.lgwin == 0 || (o.lgwin >= 10 && o.lgwin <= 30))) throw new CliException("lgwin must be 0 or in range [10..30]");
        return o;
    }

    private static int parseShort(String[] args, int i, Options o) throws CliException {
        String a = args[i];
        for (int p = 1; p < a.length(); p++) {
            char c = a.charAt(p);
            if (c >= '0' && c <= '9') {
                o.quality = c - '0';
                continue;
            }
            switch (c) {
                case 'c': setOnce(o.stdout, "write to standard output already set"); o.stdout = true; break;
                case 'd': o.decompress = true; break;
                case 'f': o.force = true; break;
                case 'h': printHelp(); System.exit(0); break;
                case 'j': o.remove = true; break;
                case 'k': o.remove = false; break;
                case 'n': o.noCopyStat = true; break;
                case 's': o.squash = true; break;
                case 't': o.test = true; break;
                case 'v': o.verbose = true; break;
                case 'K': o.concatenated = true; break;
                case 'V': System.out.println(VERSION); System.exit(0); break;
                case 'Z': o.quality = 11; break;
                case 'o': o.output = shortValue(args, i, p, "-o"); return (p + 1 < a.length()) ? i : i + 1;
                case 'q': o.quality = parseInt(shortValue(args, i, p, "-q"), "quality"); return (p + 1 < a.length()) ? i : i + 1;
                case 'w': o.lgwin = parseInt(shortValue(args, i, p, "-w"), "lgwin"); return (p + 1 < a.length()) ? i : i + 1;
                case 'C': o.comment = decodeComment(shortValue(args, i, p, "-C")); return (p + 1 < a.length()) ? i : i + 1;
                case 'D': o.dictionary = shortValue(args, i, p, "-D"); return (p + 1 < a.length()) ? i : i + 1;
                case 'S': o.suffix = shortValue(args, i, p, "-S"); return (p + 1 < a.length()) ? i : i + 1;
                default: throw new CliException("unknown option [" + c + "]");
            }
        }
        return i;
    }

    private static void processOne(Options opt, String file) throws Exception {
        byte[] input;
        Path inPath = null;
        if (file.equals("-")) {
            input = readAll(System.in);
        } else {
            inPath = Path.of(file);
            input = Files.readAllBytes(inPath);
        }

        byte[] output;
        if (opt.decompress) {
            output = StoredBrotli.decode(input, displayName(file));
            if (opt.comment != null) {
                // Stored streams generated here do not carry comments; accept empty comments only.
                if (opt.comment.length != 0) throw new CliException("corrupt input [" + displayName(file) + "]");
            }
        } else {
            output = StoredBrotli.encode(input);
        }

        if (opt.test) {
            if (opt.verbose && !file.equals("-")) System.err.println(file + ": OK");
            return;
        }

        if (opt.stdout || file.equals("-")) {
            System.out.write(output);
            System.out.flush();
        } else {
            Path out = outputPath(opt, inPath);
            if (Files.exists(out) && !opt.force) throw new CliException(out + " already exists");
            if (opt.force) Files.deleteIfExists(out);
            Files.write(out, output);
            if (opt.squash && !opt.decompress && output.length > input.length) {
                Files.deleteIfExists(out);
                return;
            }
            if (!opt.noCopyStat && inPath != null) {
                try {
                    Files.setLastModifiedTime(out, Files.getLastModifiedTime(inPath));
                } catch (IOException ignored) {
                }
            }
            if (opt.remove && inPath != null) Files.deleteIfExists(inPath);
            if (opt.verbose) System.err.println(file + ": " + input.length + " -> " + output.length);
        }
    }

    private static Path outputPath(Options opt, Path in) throws CliException {
        if (opt.output != null) return Path.of(opt.output);
        String s = in.toString();
        if (opt.decompress) {
            if (!s.endsWith(opt.suffix)) throw new CliException("empty output file name");
            return Path.of(s.substring(0, s.length() - opt.suffix.length()));
        }
        return Path.of(s + opt.suffix);
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    private static String needValue(String[] args, int i, String inline, String option) throws CliException {
        if (inline != null) return inline;
        if (i >= args.length) throw new CliException("expected parameter for argument " + option);
        return args[i];
    }

    private static String shortValue(String[] args, int i, int p, String option) throws CliException {
        String a = args[i];
        if (p + 1 < a.length()) return a.substring(p + 1);
        if (i + 1 >= args.length) throw new CliException("expected parameter for argument " + option);
        return args[i + 1];
    }

    private static int parseInt(String s, String name) throws CliException {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            throw new CliException("invalid " + name + " value [" + s + "]");
        }
    }

    private static byte[] decodeComment(String s) throws CliException {
        try {
            byte[] b = Base64.getDecoder().decode(s);
            if (b.length > 80) throw new CliException("comment too long");
            return b;
        } catch (IllegalArgumentException e) {
            throw new CliException("invalid base64 comment");
        }
    }

    private static void setOnce(boolean set, String msg) throws CliException {
        if (set) throw new CliException(msg);
    }

    private static String displayName(String file) {
        return file.equals("-") ? "con" : file;
    }

    private static void printHelp() {
        System.out.print("Usage: executable [OPTION]... [FILE]...\n" +
                "Options:\n" +
                "  -#                          compression level (0-9)\n" +
                "  -c, --stdout                write on standard output\n" +
                "  -d, --decompress            decompress\n" +
                "  -f, --force                 force output file overwrite\n" +
                "  -h, --help                  display this help and exit\n" +
                "  -j, --rm                    remove source file(s)\n" +
                "  -s, --squash                remove destination file if larger than source\n" +
                "  -k, --keep                  keep source file(s) (default)\n" +
                "  -n, --no-copy-stat          do not copy source file(s) attributes\n" +
                "  -o FILE, --output=FILE      output file (only if 1 input file)\n" +
                "  -q NUM, --quality=NUM       compression level (0-11)\n" +
                "  -t, --test                  test compressed file integrity\n" +
                "  -v, --verbose               verbose mode\n" +
                "  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)\n" +
                "                              window size = 2**NUM - 16\n" +
                "                              0 lets compressor choose the optimal value\n" +
                "  --large_window=NUM          use incompatible large-window brotli\n" +
                "                              bitstream with window size (0, 10-30)\n" +
                "                              WARNING: this format is not compatible\n" +
                "                              with brotli RFC 7932 and may not be\n" +
                "                              decodable with regular brotli decoders\n" +
                "  -C B64, --comment=B64       set comment; argument is base64-decoded first;\n" +
                "                              (maximal decoded length: 80)\n" +
                "                              when decoding: check stream comment;\n" +
                "                              when encoding: embed comment (fingerprint)\n" +
                "  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary\n" +
                "  -K, --concatenated          allows concatenated brotli streams as input\n" +
                "  -S SUF, --suffix=SUF        output file suffix (default:'.br')\n" +
                "  -V, --version               display version and exit\n" +
                "  -Z, --best                  use best compression level (11) (default)\n" +
                "Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.\n" +
                "With no FILE, or when FILE is -, read standard input.\n" +
                "All arguments after '--' are treated as files.\n");
    }

    static class CliException extends Exception {
        CliException(String message) {
            super(message);
        }
    }

    static class StoredBrotli {
        static byte[] encode(byte[] input) throws IOException {
            ByteArrayOutputStream out = new ByteArrayOutputStream(input.length + input.length / 65536 * 3 + 8);
            int pos = 0;
            if (input.length == 0) {
                out.write(0x3f);
                return out.toByteArray();
            }
            while (pos < input.length) {
                int len = Math.min(65536, input.length - pos);
                writeStoredHeader(out, len);
                out.write(input, pos, len);
                pos += len;
            }
            out.write(0x03);
            return out.toByteArray();
        }

        private static void writeStoredHeader(OutputStream out, int len) throws IOException {
            int v = len - 1;
            out.write(0x03 | ((v & 1) << 7));
            int half = v >>> 1;
            out.write(half & 0xff);
            int hi = (half >>> 8) & 0x7f;
            out.write(0x80 | hi);
        }

        static byte[] decode(byte[] data, String name) throws CliException, IOException {
            if (data.length == 1 && (data[0] & 0xff) == 0x3f) return new byte[0];
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            int p = 0;
            while (p < data.length) {
                int b0 = data[p++] & 0xff;
                if (b0 == 0x03 && p == data.length) return out.toByteArray();
                int tag = b0 & 0x7f;
                if (!((tag == 0x03) || (tag == 0x0f)) || p + 1 >= data.length) throw corrupt(name);
                int b1 = data[p++] & 0xff;
                int b2 = data[p++] & 0xff;
                if ((b2 & 0x80) == 0) throw corrupt(name);
                int half = b1 | ((b2 & 0x7f) << 8);
                int len = (half << 1) + (((b0 & 0x80) != 0) ? 2 : 1);
                if (len < 0 || p + len > data.length) throw corrupt(name);
                out.write(data, p, len);
                p += len;
            }
            throw corrupt(name);
        }

        private static CliException corrupt(String name) {
            return new CliException("corrupt input [" + name + "]");
        }
    }
}
