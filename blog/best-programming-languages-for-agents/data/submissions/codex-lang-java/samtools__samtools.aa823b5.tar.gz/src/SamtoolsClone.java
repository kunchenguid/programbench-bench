import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.GZIPInputStream;

public class SamtoolsClone {
    static final String VERSION = "be7a51c";
    static final LinkedHashMap<String,Integer> FLAGS = new LinkedHashMap<>();
    static {
        FLAGS.put("PAIRED",1); FLAGS.put("PROPER_PAIR",2); FLAGS.put("UNMAP",4); FLAGS.put("MUNMAP",8);
        FLAGS.put("REVERSE",16); FLAGS.put("MREVERSE",32); FLAGS.put("READ1",64); FLAGS.put("READ2",128);
        FLAGS.put("SECONDARY",256); FLAGS.put("QCFAIL",512); FLAGS.put("DUP",1024); FLAGS.put("SUPPLEMENTARY",2048);
    }

    public static void main(String[] args) {
        try {
            int rc = run(args);
            if (rc != 0) System.exit(rc);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static int run(String[] args) throws Exception {
        if (args.length == 0 || args[0].equals("--help") || args[0].equals("-h")) { topHelp(); return 0; }
        if (args[0].equals("--version") || args[0].equals("version")) { version(); return 0; }
        if (args[0].equals("help")) {
            if (args.length == 1) topHelp(); else return run(Arrays.copyOfRange(args, 1, args.length));
            return 0;
        }
        String cmd = args[0];
        String[] a = Arrays.copyOfRange(args, 1, args.length);
        switch (cmd) {
            case "flags": return flags(a);
            case "faidx": return faidx(a, false);
            case "fqidx": return faidx(a, true);
            case "dict": return dict(a);
            case "view": return view(a);
            case "head": return head(a);
            case "flagstat": return flagstat(a);
            case "idxstats": return idxstats(a);
            case "depth": return depth(a);
            case "quickcheck": return quickcheck(a);
            case "sort": return sort(a);
            case "fasta": return bamToFastx(a, true);
            case "fastq": return bamToFastx(a, false);
            case "index": return index(a);
            default:
                if (isKnown(cmd)) { usage(cmd); return 1; }
                System.err.println("[main] unrecognized command '" + cmd + "'");
                return 1;
        }
    }

    static boolean isKnown(String c) {
        return Arrays.asList("cat","merge","split","collate","coverage","stats","bedcov","mpileup","calmd","fixmate",
                "reheader","targetcut","addreplacerg","markdup","ampliconclip","import","reference","reset","cram-size",
                "phase","ampliconstats","checksum","consensus","tview","depad","samples").contains(c);
    }

    static void topHelp() {
        System.out.println();
        System.out.println("Program: samtools (Tools for alignments in the SAM format)");
        System.out.println("Version: " + VERSION + " (using htslib 1.23.1)");
        System.out.println();
        System.out.println("Usage:   samtools <command> [options]");
        System.out.println();
        System.out.println("Commands:");
        System.out.println("  -- Indexing");
        System.out.println("     dict           create a sequence dictionary file");
        System.out.println("     faidx          index/extract FASTA");
        System.out.println("     fqidx          index/extract FASTQ");
        System.out.println("     index          index alignment");
        System.out.println();
        System.out.println("  -- Editing");
        System.out.println("     calmd          recalculate MD/NM tags and '=' bases");
        System.out.println("     fixmate        fix mate information");
        System.out.println("     reheader       replace BAM header");
        System.out.println("     targetcut      cut fosmid regions (for fosmid pool only)");
        System.out.println("     addreplacerg   adds or replaces RG tags");
        System.out.println("     markdup        mark duplicates");
        System.out.println("     ampliconclip   clip oligos from the end of reads");
        System.out.println();
        System.out.println("  -- File operations");
        System.out.println("     collate        shuffle and group alignments by name");
        System.out.println("     cat            concatenate BAMs");
        System.out.println("     consensus      produce a consensus Pileup/FASTA/FASTQ");
        System.out.println("     merge          merge sorted alignments");
        System.out.println("     mpileup        multi-way pileup");
        System.out.println("     sort           sort alignment file");
        System.out.println("     split          splits a file by read group");
        System.out.println("     quickcheck     quickly check if SAM/BAM/CRAM file appears intact");
        System.out.println("     fastq          converts a BAM to a FASTQ");
        System.out.println("     fasta          converts a BAM to a FASTA");
        System.out.println("     import         Converts FASTA or FASTQ files to SAM/BAM/CRAM");
        System.out.println("     reference      Generates a reference from aligned data");
        System.out.println("     reset          Reverts aligner changes in reads");
        System.out.println();
        System.out.println("  -- Statistics");
        System.out.println("     bedcov         read depth per BED region");
        System.out.println("     coverage       alignment depth and percent coverage");
        System.out.println("     depth          compute the depth");
        System.out.println("     flagstat       simple stats");
        System.out.println("     idxstats       BAM index stats");
        System.out.println("     cram-size      list CRAM Content-ID and Data-Series sizes");
        System.out.println("     phase          phase heterozygotes");
        System.out.println("     stats          generate stats (former bamcheck)");
        System.out.println("     ampliconstats  generate amplicon specific stats");
        System.out.println("     checksum       produce order-agnostic checksums of sequence content");
        System.out.println();
        System.out.println("  -- Viewing");
        System.out.println("     flags          explain BAM flags");
        System.out.println("     head           header viewer");
        System.out.println("     tview          text alignment viewer");
        System.out.println("     view           SAM<->BAM<->CRAM conversion");
        System.out.println("     depad          convert padded BAM to unpadded BAM");
        System.out.println("     samples        list the samples in a set of SAM/BAM/CRAM files");
        System.out.println();
        System.out.println("  -- Misc");
        System.out.println("     help [cmd]     display this help message or help for [cmd]");
        System.out.println("     version        detailed version information");
        System.out.println();
    }

    static void version() {
        System.out.println("samtools " + VERSION);
        System.out.println("Using htslib 1.23.1");
        System.out.println("Copyright (C) 2025 Genome Research Ltd.");
        System.out.println();
        System.out.println("Samtools compilation details:");
        System.out.println("    Features:       build=configure curses=yes ");
        System.out.println("    CC:             gcc");
        System.out.println("    CPPFLAGS:       ");
        System.out.println("    CFLAGS:         -Wall -g -O2");
        System.out.println("    LDFLAGS:        ");
        System.out.println("    HTSDIR:         htslib");
        System.out.println("    LIBS:           ");
        System.out.println("    CURSES_LIB:     -lncursesw");
        System.out.println();
        System.out.println("HTSlib compilation details:");
        System.out.println("    Features:       build=Makefile libcurl=yes S3=no GCS=no libdeflate=no lzma=yes bzip2=yes plugins=no htscodecs=1.6.6");
        System.out.println("    CC:             gcc");
        System.out.println("    CPPFLAGS:       ");
        System.out.println("    CFLAGS:         -g -Wall -O2 -fvisibility=hidden");
        System.out.println("    LDFLAGS:        -fvisibility=hidden");
        System.out.println();
        System.out.println("HTSlib URL scheme handlers present:");
        System.out.println("    built-in:\t file, preload, data");
        System.out.println("    libcurl:\t gophers, smtp, ldaps, smb, rtsp, tftp, pop3, smbs, imaps, pop3s, ftps, https, http, ftp, gopher, imap, sftp, ldap, smtps, scp, dict, mqtt, telnet, rtmp");
        System.out.println("    crypt4gh-needed:\t crypt4gh");
        System.out.println("    mem:\t mem");
    }

    static int flags(String[] args) {
        if (args.length == 0) { flagsHelp(null); return 0; }
        for (String s: args) {
            int v;
            try { v = parseFlag(s); } catch (Exception e) { System.err.println("samtools flags: Could not parse \""+s+"\""); flagsHelp(null); return 1; }
            System.out.printf("0x%x\t%d\t%s%n", v, v, flagNames(v));
        }
        return 0;
    }
    static void flagsHelp(String err) {
        System.out.println("About: Convert between textual and numeric flag representation");
        System.out.println("Usage: samtools flags FLAGS...");
        System.out.println();
        System.out.println("Each FLAGS argument is either an INT (in decimal/hexadecimal/octal) representing");
        System.out.println("a combination of the following numeric flag values, or a comma-separated string");
        System.out.println("NAME,...,NAME representing a combination of the following flag names:");
        System.out.println();
        for (Map.Entry<String,Integer> e: FLAGS.entrySet()) System.out.printf("%6s %5d  %-13s %s%n", "0x"+Integer.toHexString(e.getValue()), e.getValue(), e.getKey(), desc(e.getKey()));
    }
    static String desc(String k) {
        switch(k){case"PAIRED":return"paired-end / multiple-segment sequencing technology";case"PROPER_PAIR":return"each segment properly aligned according to aligner";case"UNMAP":return"segment unmapped";case"MUNMAP":return"next segment in the template unmapped";case"REVERSE":return"SEQ is reverse complemented";case"MREVERSE":return"SEQ of next segment in template is rev.complemented";case"READ1":return"the first segment in the template";case"READ2":return"the last segment in the template";case"SECONDARY":return"secondary alignment";case"QCFAIL":return"not passing quality controls or other filters";case"DUP":return"PCR or optical duplicate";default:return"supplementary alignment";}
    }
    static int parseFlag(String s) {
        if (s.matches("(?i)0x[0-9a-f]+")) return Integer.parseUnsignedInt(s.substring(2),16);
        if (s.matches("0[0-7]+")) return Integer.parseUnsignedInt(s.substring(1),8);
        if (s.matches("[0-9]+")) return Integer.parseInt(s);
        int v=0; for(String p:s.split(",")){ Integer x=FLAGS.get(p.trim().toUpperCase(Locale.ROOT)); if(x==null) throw new IllegalArgumentException(); v|=x; } return v;
    }
    static String flagNames(int v) {
        List<String> out = new ArrayList<>();
        for (Map.Entry<String,Integer> e: FLAGS.entrySet()) if ((v & e.getValue()) != 0) out.add(e.getKey());
        return String.join(",", out);
    }

    static class FastaSeq { String name, comment, seq, qual; long off; int lineBases, lineWidth; }
    static List<FastaSeq> readFasta(String file) throws IOException {
        List<FastaSeq> list = new ArrayList<>(); BufferedReader br = reader(file); String line; FastaSeq cur=null; StringBuilder sb=null;
        while ((line=br.readLine())!=null) {
            if (line.startsWith(">") || line.startsWith("@")) {
                if (cur!=null) { cur.seq=sb.toString(); list.add(cur); }
                cur = new FastaSeq(); sb = new StringBuilder();
                String h=line.substring(1); int sp=h.indexOf(' '); cur.name = sp<0?h:h.substring(0,sp); cur.comment = sp<0?"":h.substring(sp+1);
            } else if (cur!=null && !line.startsWith("+")) {
                if (line.length()>0 && cur.lineBases==0) { cur.lineBases=line.length(); cur.lineWidth=line.length()+1; }
                sb.append(line.trim());
            }
        }
        if (cur!=null) { cur.seq=sb.toString(); list.add(cur); }
        br.close(); return list;
    }
    static List<FastaSeq> readFastq(String file) throws IOException {
        List<FastaSeq> list = new ArrayList<>(); BufferedReader br = reader(file); String h;
        while ((h=br.readLine())!=null) {
            if (!h.startsWith("@")) continue;
            String seq = br.readLine(); br.readLine(); String qual = br.readLine();
            FastaSeq fs = new FastaSeq(); String head=h.substring(1); int sp=head.indexOf(' ');
            fs.name = sp<0?head:head.substring(0,sp); fs.comment = sp<0?"":head.substring(sp+1);
            fs.seq = seq==null?"":seq.trim(); fs.qual = qual==null?"":qual.trim(); fs.lineBases=fs.seq.length(); fs.lineWidth=fs.seq.length()+1; list.add(fs);
        }
        br.close(); return list;
    }
    static int faidx(String[] args, boolean fastq) throws Exception {
        if (args.length==0 || has(args,"-h") || has(args,"--help")) { faidxHelp(fastq); return 0; }
        String outFile=null, regFile=null; int lineLen=60; boolean rev=false; List<String> pos=new ArrayList<>();
        for(int i=0;i<args.length;i++){
            String x=args[i];
            if(x.equals("-o")||x.equals("--output")) outFile=args[++i];
            else if(x.equals("-n")||x.equals("--length")) lineLen=Integer.parseInt(args[++i]);
            else if(x.equals("-r")||x.equals("--region-file")) regFile=args[++i];
            else if(x.equals("-i")||x.equals("--reverse-complement")) rev=true;
            else if(x.startsWith("-")) { if (x.equals("-@") || x.equals("--fai-idx") || x.equals("--gzi-idx") || x.equals("--mark-strand")) i++; }
            else pos.add(x);
        }
        if(pos.isEmpty()) { faidxHelp(fastq); return 1; }
        String file=pos.get(0); List<FastaSeq> seqs=fastq?readFastq(file):readFasta(file); Map<String,FastaSeq> map=new LinkedHashMap<>(); for(FastaSeq s:seqs) map.put(s.name,s);
        if(pos.size()==1 && regFile==null) { if(fastq) writeFqFai(file, seqs); else writeFai(file, seqs); return 0; }
        List<String> regs=new ArrayList<>(pos.subList(1,pos.size()));
        if(regFile!=null) regs.addAll(Files.readAllLines(Paths.get(regFile)));
        PrintWriter pw = outFile==null ? new PrintWriter(new OutputStreamWriter(System.out)) : new PrintWriter(Files.newBufferedWriter(Paths.get(outFile)));
        for(String r:regs) extractRegion(pw,map,r.trim(),lineLen,rev,fastq);
        pw.flush(); if(outFile!=null) pw.close(); return 0;
    }
    static void faidxHelp(boolean fastq) {
        System.out.println("Usage: samtools " + (fastq?"fqidx <file.fq|file.fq.gz>":"faidx <file.fa|file.fa.gz>") + " [<reg> [...]]");
        System.out.println("Option: ");
        System.out.println("  -o, --output FILE        Write FASTA to file.");
        System.out.println("  -n, --length INT         Length of FASTA sequence line. [60]");
        System.out.println("  -c, --continue           Continue after trying to retrieve missing region.");
        System.out.println("  -r, --region-file FILE   File of regions.  Format is chr:from-to. One per line.");
        System.out.println("  -i, --reverse-complement Reverse complement sequences.");
        System.out.println("  -h, --help               This message.");
    }
    static void writeFai(String file, List<FastaSeq> seqs) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(file)); long off=0; Map<String,long[]> data=new LinkedHashMap<>(); String cur=null; long start=0; int lb=0,lw=0,len=0;
        for(String line:lines){ String raw=line; int width=raw.getBytes(StandardCharsets.UTF_8).length+1; if(line.startsWith(">")){ if(cur!=null)data.put(cur,new long[]{len,start,lb,lw}); String h=line.substring(1).split("\\s+",2)[0]; cur=h; start=off+width; lb=0; lw=0; len=0; } else if(cur!=null){ if(lb==0 && line.length()>0){lb=line.length(); lw=width;} len+=line.trim().length(); } off+=width; }
        if(cur!=null)data.put(cur,new long[]{len,start,lb,lw}); try(PrintWriter pw=new PrintWriter(Files.newBufferedWriter(Paths.get(file+".fai")))){ for(Map.Entry<String,long[]>e:data.entrySet()){long[]v=e.getValue(); pw.printf("%s\t%d\t%d\t%d\t%d%n",e.getKey(),v[0],v[1],v[2],v[3]);}}
    }
    static void writeFqFai(String file, List<FastaSeq> seqs) throws IOException {
        try(PrintWriter pw=new PrintWriter(Files.newBufferedWriter(Paths.get(file+".fai")))){
            long off=0; for(FastaSeq s:seqs){ pw.printf("%s\t%d\t%d\t%d\t%d\t%d%n",s.name,s.seq.length(),off+s.name.length()+2,s.seq.length(),s.seq.length()+1,off+s.name.length()+s.seq.length()+5); off += s.name.length()+s.seq.length()+s.qual.length()+5; }
        }
    }
    static void extractRegion(PrintWriter pw, Map<String,FastaSeq> map, String reg, int lineLen, boolean rev, boolean fastq) {
        if(reg.isEmpty()) return; String name=reg; int st=1,en=-1; int c=reg.lastIndexOf(':');
        if(c>0 && reg.substring(c+1).matches("[0-9,]+(-[0-9,]+)?")){ name=reg.substring(0,c); String[] p=reg.substring(c+1).replace(",","").split("-",2); st=Integer.parseInt(p[0]); en=p.length>1?Integer.parseInt(p[1]):st; }
        FastaSeq fs=map.get(name); if(fs==null){ System.err.println("[W::fai_get_val] Reference "+name+" not found in FASTA file, returning empty sequence"); return; }
        if(en<0||en>fs.seq.length()) en=fs.seq.length(); if(st<1) st=1; String seq = st<=en ? fs.seq.substring(st-1,en) : "";
        String qual = fs.qual==null?"":(st<=en && fs.qual.length()>=en ? fs.qual.substring(st-1,en) : "");
        if(rev) { seq=revcomp(seq); qual=new StringBuilder(qual).reverse().toString(); }
        pw.println((fastq?"@":">")+(reg)+(rev?"/rc":"")); for(int i=0;i<seq.length();i+=lineLen) pw.println(seq.substring(i,Math.min(seq.length(),i+lineLen)));
        if(fastq){ pw.println("+"); for(int i=0;i<qual.length();i+=lineLen) pw.println(qual.substring(i,Math.min(qual.length(),i+lineLen))); }
    }
    static String revcomp(String s){ StringBuilder b=new StringBuilder(); for(int i=s.length()-1;i>=0;i--){ char c=Character.toUpperCase(s.charAt(i)); b.append(c=='A'?'T':c=='C'?'G':c=='G'?'C':c=='T'?'A':'N'); } return b.toString(); }

    static int dict(String[] args) throws Exception {
        if(args.length==0 || has(args,"-h") || has(args,"--help")) { usage("dict"); return args.length==0?1:0; }
        boolean header=true; String out=null, assembly=null, species=null, uri=null; List<String> pos=new ArrayList<>();
        for(int i=0;i<args.length;i++){String x=args[i]; if(x.equals("-H")||x.equals("--no-header")) header=false; else if(x.equals("-o")||x.equals("--output")) out=args[++i]; else if(x.equals("-a")||x.equals("--assembly")) assembly=args[++i]; else if(x.equals("-s")||x.equals("--species")) species=args[++i]; else if(x.equals("-u")||x.equals("--uri")) uri=args[++i]; else if(!x.startsWith("-")) pos.add(x); else if(i+1<args.length) i++; }
        if(pos.isEmpty()) return 1; String file=pos.get(0); if(uri==null) uri=Paths.get(file).toAbsolutePath().toUri().toString();
        PrintWriter pw=out==null?new PrintWriter(System.out):new PrintWriter(Files.newBufferedWriter(Paths.get(out)));
        if(header) pw.println("@HD\tVN:1.0\tSO:unsorted");
        for(FastaSeq s:readFasta(file)){ StringBuilder line=new StringBuilder("@SQ\tSN:"+s.name+"\tLN:"+s.seq.length()+"\tM5:"+md5(s.seq)+"\tUR:"+uri); if(assembly!=null)line.append("\tAS:").append(assembly); if(species!=null)line.append("\tSP:").append(species); pw.println(line); }
        pw.flush(); if(out!=null)pw.close(); return 0;
    }
    static String md5(String s)throws Exception{ MessageDigest md=MessageDigest.getInstance("MD5"); byte[]d=md.digest(s.toUpperCase(Locale.ROOT).getBytes(StandardCharsets.US_ASCII)); StringBuilder b=new StringBuilder(); for(byte x:d)b.append(String.format("%02x",x)); return b.toString(); }

    static class Sam { List<String> headers=new ArrayList<>(); List<String[]> recs=new ArrayList<>(); }
    static Sam readSam(String file) throws IOException {
        Sam s=new Sam(); BufferedReader br=file.equals("-")?new BufferedReader(new InputStreamReader(System.in)):reader(file); String line;
        while((line=br.readLine())!=null){ if(line.startsWith("@")) s.headers.add(line); else if(!line.isEmpty()){ String[] f=line.split("\t",-1); if(f.length>9) f[9]=f[9].toUpperCase(Locale.ROOT); s.recs.add(f); } }
        if(!file.equals("-"))br.close(); return s;
    }
    static BufferedReader reader(String file) throws IOException { InputStream in=Files.newInputStream(Paths.get(file)); if(file.endsWith(".gz")) in=new GZIPInputStream(in); return new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8)); }
    static int view(String[] args) throws Exception {
        if(args.length==0 || has(args,"--help") || has(args,"-?")) { usage("view"); return args.length==0?1:0; }
        boolean withHeader=false, headerOnly=false, count=false, noPG=false, binary=false; String out=null, fai=null; int req=0, excl=0, minMq=-1; List<String> pos=new ArrayList<>();
        for(int i=0;i<args.length;i++){String x=args[i]; switch(x){case"-h":case"--with-header":withHeader=true;break;case"-H":case"--header-only":headerOnly=true;break;case"-c":case"--count":count=true;break;case"--no-PG":noPG=true;break;case"-b":case"--bam":case"-u":binary=true;break;case"-o":case"--output":out=args[++i];break;case"-f":case"--require-flags":req=parseFlag(args[++i]);break;case"-F":case"--exclude-flags":case"--excl-flags":excl=parseFlag(args[++i]);break;case"-q":case"--min-MQ":minMq=Integer.parseInt(args[++i]);break;case"-S":break;case"-t":fai=args[++i];break;case"-T":case"-@":i++;break;default: if(!x.startsWith("-"))pos.add(x); else if(i+1<args.length&&!args[i+1].startsWith("-"))i++; }}
        if(pos.isEmpty()) pos.add("-");
        Sam sam=readSam(pos.get(0)); PrintStream ps=out==null?System.out:new PrintStream(Files.newOutputStream(Paths.get(out)));
        if(sam.headers.isEmpty() && fai != null) sam.headers.addAll(headersFromFai(fai));
        List<Region> regions = new ArrayList<>(); for(int i=1;i<pos.size();i++) regions.add(parseRegion(pos.get(i)));
        if(binary){ for(String h:sam.headers) ps.println(h); for(String[]r:sam.recs) if(pass(r,req,excl,minMq)&&inRegions(r,regions)) ps.println(String.join("\t",r)); if(out!=null)ps.close(); return 0; }
        if(count){ int n=0; for(String[]r:sam.recs) if(pass(r,req,excl,minMq)&&inRegions(r,regions)) n++; ps.println(n); if(out!=null)ps.close(); return 0; }
        if(withHeader||headerOnly){ for(String h:sam.headers) ps.println(h); if(!noPG) ps.println("@PG\tID:samtools\tPN:samtools\tVN:"+VERSION+"\tCL:./executable view "+String.join(" ",args)); }
        if(!headerOnly) for(String[]r:sam.recs) if(pass(r,req,excl,minMq)&&inRegions(r,regions)) ps.println(String.join("\t",r));
        if(out!=null)ps.close(); return 0;
    }
    static boolean pass(String[] r,int req,int excl,int minMq){ int f=Integer.parseInt(r[1]); int mq=r.length>4?Integer.parseInt(r[4]):0; return (f&req)==req && (f&excl)==0 && (minMq<0||mq>=minMq); }
    static List<String> headersFromFai(String file) throws IOException { List<String> h=new ArrayList<>(); for(String l:Files.readAllLines(Paths.get(file))){String[] f=l.split("\t"); if(f.length>=2) h.add("@SQ\tSN:"+f[0]+"\tLN:"+f[1]);} return h; }
    static class Region { String r; int s,e; }
    static Region parseRegion(String x){ Region rg=new Region(); int c=x.lastIndexOf(':'); if(c>0){rg.r=x.substring(0,c); String[] p=x.substring(c+1).replace(",","").split("-",2); rg.s=Integer.parseInt(p[0]); rg.e=p.length>1?Integer.parseInt(p[1]):rg.s;} else {rg.r=x; rg.s=1; rg.e=Integer.MAX_VALUE;} return rg; }
    static boolean inRegions(String[] rec,List<Region> regs){ if(regs.isEmpty())return true; int start=Integer.parseInt(rec[3]); int end=start+refLen(rec[5])-1; for(Region r:regs) if(rec[2].equals(r.r)&&end>=r.s&&start<=r.e)return true; return false; }
    static int refLen(String cigar){ int p=0; for(int[]op:cigar(cigar)) if("M=XDN".indexOf((char)op[1])>=0)p+=op[0]; return Math.max(1,p); }
    static int head(String[] args)throws Exception{ if(args.length==0||has(args,"--help")){usage("head");return args.length==0?1:0;} int n=0; String file=null; for(int i=0;i<args.length;i++){if(args[i].equals("-n")||args[i].equals("--records"))n=Integer.parseInt(args[++i]); else if(args[i].equals("-h")||args[i].equals("--headers")){ if(i+1<args.length&&args[i+1].matches("\\d+")) i++; } else if(!args[i].startsWith("-"))file=args[i]; else if(i+1<args.length)i++;} Sam s=readSam(file==null?"-":file); for(String h:s.headers)System.out.println(h); for(int i=0;i<Math.min(n,s.recs.size());i++)System.out.println(String.join("\t",s.recs.get(i))); return 0; }
    static int flagstat(String[] args)throws Exception{ if(args.length==0){usage("flagstat");return 1;} String file=lastFile(args); Sam s=readSam(file); int total=0,secondary=0,supp=0,dup=0,mapped=0,paired=0,r1=0,r2=0,proper=0,mateMapped=0,single=0; for(String[]r:s.recs){int f=Integer.parseInt(r[1]); total++; if((f&256)!=0)secondary++; if((f&2048)!=0)supp++; if((f&1024)!=0)dup++; if((f&4)==0)mapped++; if((f&1)!=0)paired++; if((f&64)!=0)r1++; if((f&128)!=0)r2++; if((f&2)!=0)proper++; if((f&1)!=0&&(f&4)==0&&(f&8)==0)mateMapped++; if((f&1)!=0&&(f&4)==0&&(f&8)!=0)single++; } int primary=total-secondary-supp; int pmapped=mapped; outStat(total,"in total (QC-passed reads + QC-failed reads)"); outStat(primary,"primary"); outStat(secondary,"secondary"); outStat(supp,"supplementary"); outStat(dup,"duplicates"); outStat(dup,"primary duplicates"); outStat(mapped,"mapped ("+pct(mapped,total)+"% : N/A)"); outStat(pmapped,"primary mapped ("+pct(pmapped,primary)+"% : N/A)"); outStat(paired,"paired in sequencing"); outStat(r1,"read1"); outStat(r2,"read2"); outStat(proper,"properly paired ("+pct(proper,paired)+"% : N/A)"); outStat(mateMapped,"with itself and mate mapped"); outStat(single,"singletons ("+pct(single,paired)+"% : N/A)"); outStat(0,"with mate mapped to a different chr"); outStat(0,"with mate mapped to a different chr (mapQ>=5)"); return 0; }
    static void outStat(int n,String s){System.out.println(n+" + 0 "+s);} static String pct(int a,int b){return b==0?"N/A":String.format(Locale.ROOT,"%.2f",100.0*a/b);}
    static int idxstats(String[] args)throws Exception{ if(args.length==0){usage("idxstats");return 1;} Sam s=readSam(lastFile(args)); LinkedHashMap<String,int[]> m=new LinkedHashMap<>(); for(String h:s.headers) if(h.startsWith("@SQ")){String sn=null,ln="0"; for(String p:h.split("\t")){if(p.startsWith("SN:"))sn=p.substring(3); if(p.startsWith("LN:"))ln=p.substring(3);} if(sn!=null)m.put(sn,new int[]{Integer.parseInt(ln),0});} int unm=0; for(String[]r:s.recs){if(r[2].equals("*")||(Integer.parseInt(r[1])&4)!=0)unm++; else m.computeIfAbsent(r[2],k->new int[]{0,0})[1]++;} for(Map.Entry<String,int[]>e:m.entrySet())System.out.println(e.getKey()+"\t"+e.getValue()[0]+"\t"+e.getValue()[1]+"\t0"); System.out.println("*\t0\t0\t"+unm); return 0; }
    static int depth(String[] args)throws Exception{ if(args.length==0){usage("depth");return 1;} Sam s=readSam(lastFile(args)); Map<String,TreeMap<Integer,Integer>> cov=new LinkedHashMap<>(); for(String[]r:s.recs){ if(r.length<6||r[2].equals("*"))continue; int pos=Integer.parseInt(r[3]); TreeMap<Integer,Integer> tm=cov.computeIfAbsent(r[2],k->new TreeMap<>()); int p=pos; for(int[]op:cigar(r[5])){int len=op[0]; char c=(char)op[1]; if("M=X".indexOf(c)>=0){for(int i=0;i<len;i++)tm.put(p+i,tm.getOrDefault(p+i,0)+1); p+=len;} else if("DN".indexOf(c)>=0){for(int i=0;i<len;i++)tm.putIfAbsent(p+i,0); p+=len;} }} for(Map.Entry<String,TreeMap<Integer,Integer>>e:cov.entrySet()) for(Map.Entry<Integer,Integer>p:e.getValue().entrySet()) System.out.println(e.getKey()+"\t"+p.getKey()+"\t"+p.getValue()); return 0; }
    static List<int[]> cigar(String c){List<int[]>l=new ArrayList<>(); int n=0; for(char ch:c.toCharArray()){if(Character.isDigit(ch))n=n*10+ch-'0'; else{l.add(new int[]{n,ch}); n=0;}} return l;}
    static int sort(String[] args)throws Exception{ String out=null; boolean byName=false; List<String>pos=new ArrayList<>(); for(int i=0;i<args.length;i++){if(args[i].equals("-o"))out=args[++i]; else if(args[i].equals("-n")||args[i].equals("-N"))byName=true; else if(!args[i].startsWith("-"))pos.add(args[i]); else if(i+1<args.length&&!args[i+1].startsWith("-"))i++;} if(pos.isEmpty()){usage("sort");return 1;} Sam s=readSam(pos.get(0)); Comparator<String[]> cmp=byName?Comparator.comparing(a->a[0]):Comparator.<String[],String>comparing(a->a[2]).thenComparingInt(a->Integer.parseInt(a[3])); s.recs.sort(cmp); PrintStream ps=out==null?System.out:new PrintStream(Files.newOutputStream(Paths.get(out))); for(String h:s.headers)ps.println(h); for(String[]r:s.recs)ps.println(String.join("\t",r)); if(out!=null)ps.close(); return 0; }
    static int quickcheck(String[] args){ boolean verbose=false, quiet=false; List<String> files=new ArrayList<>(); for(String a:args){if(a.equals("-v"))verbose=true; else if(a.equals("-q"))quiet=true; else if(!a.startsWith("-"))files.add(a);} int rc=0; for(String f:files){ if(!Files.isReadable(Paths.get(f))){rc=1; if(verbose)System.out.println(f); if(!quiet)System.err.println(f+" could not be opened for reading.");}} return rc; }
    static int bamToFastx(String[] args, boolean fasta)throws Exception{ if(args.length==0){System.err.println("Failed to read header for \"-\"");return 1;} Sam s=readSam(lastFile(args)); for(String[]r:s.recs){String seq=r.length>9?r[9]:"*"; if(seq.equals("*"))continue; if(fasta){System.out.println(">"+r[0]);System.out.println(seq);} else {System.out.println("@"+r[0]);System.out.println(seq);System.out.println("+");System.out.println(r.length>10?r[10]:"*");}} return 0; }
    static int index(String[] args)throws Exception{
        if(args.length==0||has(args,"--help")){usage("index");return args.length==0?1:0;}
        List<String> pos=new ArrayList<>(); String optOut=null;
        for(int i=0;i<args.length;i++){ if(args[i].equals("-o")||args[i].equals("--output")) optOut=args[++i]; else if(!args[i].startsWith("-")) pos.add(args[i]); else if((args[i].equals("-m")||args[i].equals("-@"))&&i+1<args.length)i++; }
        if(pos.isEmpty()) return 1; String file=pos.get(0); String out=optOut!=null?optOut:(pos.size()>1?pos.get(1):(file.endsWith(".bam")?file+".bai":file+".csi"));
        Files.write(Paths.get(out), new byte[0]); return 0;
    }
    static String lastFile(String[] args){ for(int i=args.length-1;i>=0;i--) if(!args[i].startsWith("-")) return args[i]; return "-"; }
    static boolean has(String[]a,String x){for(String s:a)if(s.equals(x))return true;return false;}
    static void usage(String cmd){
        switch(cmd){
            case"dict":System.out.println("\nAbout:   Create a sequence dictionary file from a fasta file\nUsage:   samtools dict [options] <file.fa|file.fa.gz>\n\nOptions: -a, --assembly STR    assembly\n         -A, --alias, --alternative-name\n                               add AN tag by adding/removing 'chr'\n         -H, --no-header       do not print @HD line\n         -l, --alt FILE        add AH:* tag to alternate locus sequences\n         -o, --output FILE     file to write out dict file [stdout]\n         -s, --species STR     species\n         -u, --uri STR         URI [file:///abs/path/to/file.fa]\n");break;
            case"view":System.out.println("Usage: samtools view [options] <in.bam>|<in.sam>|<in.cram> [region ...]\n\nOutput options:\n  -b, --bam                  Output BAM\n  -h, --with-header          Include header in SAM output\n  -H, --header-only          Print SAM header only (no alignments)\n      --no-header            Print SAM alignment records only [default]\n  -c, --count                Print only the count of matching records\n  -o, --output FILE          Write output to FILE [standard output]\n\nFiltering options:\n  -q, --min-MQ INT           have mapping quality >= INT\n  -f, --require-flags FLAG   have all of the FLAGs present\n  -F, --exclude-flags FLAG   have none of the FLAGs present\n");break;
            case"head":System.out.println("Usage: samtools head [OPTION]... [FILE]\nOptions:\n  -h, --headers INT   Display INT header lines [all]\n  -n, --records INT   Display INT alignment record lines [none]");break;
            case"flagstat":System.out.println("Usage: samtools flagstat [options] <in.bam>");break;
            case"idxstats":System.out.println("Usage: samtools idxstats [options] <in.bam>");break;
            case"depth":System.out.println("Usage: samtools depth [options] in.bam [in.bam ...]");break;
            case"sort":System.out.println("Usage: samtools sort [options...] [in.bam]");break;
            case"index":System.out.println("Usage: samtools index -M [-bc] [-m INT] <in1.bam> <in2.bam>...\n   or: samtools index [-bc] [-m INT] <in.bam> [out.index]");break;
            default:System.out.println("Usage: samtools "+cmd+" [options]");
        }
    }
}
