package com.programbench.zstd;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class ZstdMain {
    static final int MAGIC = 0xFD2FB528;
    static final int SKIP_MAGIC_MASK = 0xFFFFFFF0;
    static final int SKIP_MAGIC_BASE = 0x184D2A50;
    static final String VERSION = "*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***";

    static class Opt {
        boolean decompress, stdout, force, rm, keep = true, test, list, quiet;
        boolean gzip;
        String output;
        List<String> inputs = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Opt opt = parse(args);
            if (opt == null) return;
            int rc = run(opt);
            if (rc != 0) System.exit(rc);
        } catch (Exception e) {
            System.err.println("zstd: " + e.getMessage());
            System.exit(1);
        }
    }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        boolean filesOnly = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (filesOnly) { o.inputs.add(a); continue; }
            if (a.equals("--")) { filesOnly = true; continue; }
            if (a.equals("-h")) { shortHelp(); return null; }
            if (a.equals("-H") || a.equals("--help")) { fullHelp(); return null; }
            if (a.equals("-V") || a.equals("--version")) { System.out.println(VERSION); return null; }
            if (a.equals("-d") || a.equals("--decompress") || a.equals("--uncompress")) { o.decompress = true; continue; }
            if (a.equals("-c") || a.equals("--stdout")) { o.stdout = true; o.keep = true; continue; }
            if (a.equals("-f") || a.equals("--force")) { o.force = true; continue; }
            if (a.equals("-k") || a.equals("--keep")) { o.keep = true; o.rm = false; continue; }
            if (a.equals("--rm")) { o.rm = true; o.keep = false; continue; }
            if (a.equals("--test") || a.equals("-t")) { o.test = true; o.decompress = true; continue; }
            if (a.equals("-l")) { o.list = true; o.decompress = true; continue; }
            if (a.equals("-q") || a.equals("--quiet")) { o.quiet = true; continue; }
            if (a.equals("--format=gzip")) { o.gzip = true; continue; }
            if (a.equals("--format=zstd")) { o.gzip = false; continue; }
            if (a.equals("-o")) { if (++i >= args.length) die("missing output"); o.output = args[i]; continue; }
            if (a.startsWith("-o") && a.length() > 2) { o.output = a.substring(2); continue; }
            if (a.equals("-D") || a.equals("--filelist") || a.equals("--output-dir-flat") || a.equals("--output-dir-mirror") || a.equals("--trace")) { if (++i >= args.length) die("missing argument for " + a); continue; }
            if (a.startsWith("--format=")) { if (!a.equals("--format=zstd")) die("unsupported format"); continue; }
            if (a.startsWith("--fast") || a.startsWith("--long") || a.startsWith("--adapt") || a.startsWith("--ultra") || a.startsWith("--no-") || a.startsWith("--") || a.matches("-[0-9].*") || a.startsWith("-T") || a.startsWith("-b") || a.startsWith("-e") || a.startsWith("-i") || a.startsWith("-M")) { continue; }
            if (a.startsWith("-") && a.length() > 1) {
                for (int j = 1; j < a.length(); j++) {
                    char c = a.charAt(j);
                    if (c == 'd') o.decompress = true;
                    else if (c == 'c') { o.stdout = true; o.keep = true; }
                    else if (c == 'f') o.force = true;
                    else if (c == 'q') o.quiet = true;
                    else if (c == 'k') { o.keep = true; o.rm = false; }
                    else if (c == 't') { o.test = true; o.decompress = true; }
                    else die("invalid option -- '" + c + "'");
                }
                continue;
            }
            o.inputs.add(a);
        }
        return o;
    }

    static int run(Opt o) throws Exception {
        if (o.inputs.isEmpty()) o.inputs.add("-");
        if (o.output != null && o.inputs.size() > 1 && !o.stdout) die("multiple input files with single output file");
        int failures = 0;
        for (String in : o.inputs) {
            try { processOne(o, in); } catch (Exception e) { failures++; if (!o.quiet) System.err.println("zstd: " + in + ": " + e.getMessage()); }
        }
        return failures == 0 ? 0 : 1;
    }

    static void processOne(Opt o, String name) throws Exception {
        boolean stdin = name.equals("-");
        byte[] input = stdin ? readAll(System.in) : Files.readAllBytes(Paths.get(name));
        if (o.list) { listInfo(name, input); return; }
        byte[] output;
        if (o.decompress) output = o.gzip || looksGzip(input) ? gunzip(input) : Zstd.decode(input, o.force);
        else output = o.gzip ? gzip(input) : Zstd.encode(input);
        if (o.test) { if (!o.quiet && !stdin) System.err.println(name + "             : ok"); return; }
        if (o.stdout || stdin && o.output == null) {
            System.out.write(output); System.out.flush(); return;
        }
        Path out = Paths.get(o.output != null ? o.output : defaultOutput(name, o.decompress, o.gzip));
        if (Files.exists(out) && !o.force) throw new IOException(out + " already exists; not overwritten");
        Files.write(out, output);
        if (o.rm && !stdin) Files.deleteIfExists(Paths.get(name));
        if (!o.quiet) {
            if (o.decompress) System.err.printf(Locale.ROOT, "%-20s: %d bytes%n", name, output.length);
            else System.err.printf(Locale.ROOT, "%-20s:%6.2f%%   (%6d B =>%7d B, %s)%n", name, input.length == 0 ? 0.0 : (100.0 * output.length / input.length), input.length, output.length, out.toString());
        }
    }

    static String defaultOutput(String name, boolean decomp, boolean gzip) {
        if (!decomp) return name + (gzip ? ".gz" : ".zst");
        if (name.endsWith(".zst")) return name.substring(0, name.length() - 4);
        if (name.endsWith(".gz")) return name.substring(0, name.length() - 3);
        return name + ".out";
    }

    static void listInfo(String name, byte[] data) throws Exception {
        long size = Zstd.contentSize(data);
        System.out.println("Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename");
        System.out.printf(Locale.ROOT, "%6d %6d %11d %13s %6s %6s  %s%n", 1, 0, data.length, size >= 0 ? Long.toString(size) : "?", "?", "?", name);
    }

    static byte[] gzip(byte[] in) throws IOException { ByteArrayOutputStream b = new ByteArrayOutputStream(); try (GZIPOutputStream g = new GZIPOutputStream(b)) { g.write(in); } return b.toByteArray(); }
    static byte[] gunzip(byte[] in) throws IOException { return readAll(new GZIPInputStream(new ByteArrayInputStream(in))); }
    static boolean looksGzip(byte[] b) { return b.length >= 2 && (b[0] & 255) == 0x1f && (b[1] & 255) == 0x8b; }
    static byte[] readAll(InputStream in) throws IOException { ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) >= 0) b.write(buf,0,n); return b.toByteArray(); }
    static void die(String m) { throw new IllegalArgumentException(m); }

    static void shortHelp() { System.out.print("Compress or decompress the INPUT file(s); reads from STDIN if INPUT is `-` or not provided.\n\nUsage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]\n\nOptions:\n  -o OUTPUT                     Write output to a single file, OUTPUT.\n  -k, --keep                    Preserve INPUT file(s). [Default] \n  --rm                          Remove INPUT file(s) after successful (de)compression to file.\n\n  -#                            Desired compression level, where `#` is a number between 1 and 19;\n                                lower numbers provide faster compression, higher numbers yield\n                                better compression ratios. [Default: 3]\n\n  -d, --decompress              Perform decompression.\n  -D DICT                       Use DICT as the dictionary for compression or decompression.\n\n  -f, --force                   Disable input and output checks. Allows overwriting existing files,\n                                receiving input from the console, printing output to STDOUT, and\n                                operating on links, block devices, etc. Unrecognized formats will be\n                                passed-through through as-is.\n\n  -h                            Display short usage and exit.\n  -H, --help                    Display full help and exit.\n  -V, --version                 Display the program version and exit.\n\n"); }
    static void fullHelp() { System.out.println(VERSION); System.out.println(); shortHelp(); System.out.print("Advanced options:\n  -c, --stdout                  Write to STDOUT (even if it is a console) and keep the INPUT file(s).\n  -v, --verbose                 Enable verbose output; pass multiple times to increase verbosity.\n  -q, --quiet                   Suppress warnings; pass twice to suppress errors.\n\nAdvanced decompression options:\n  -l                            Print information about Zstandard-compressed files.\n  --test                        Test compressed file integrity.\n\n"); }

    static class Zstd {
        static byte[] encode(byte[] src) throws IOException {
            ByteArrayOutputStream out = new ByteArrayOutputStream(src.length + 32);
            writeLE(out, MAGIC, 4);
            long n = src.length;
            if (n < 256) { out.write(0x20); out.write((int)n); }
            else if (n < 256 + 65536) { out.write(0x60); writeLE(out, n - 256, 2); }
            else if (n <= 0xffffffffL) { out.write(0xA0); writeLE(out, n, 4); }
            else { out.write(0xE0); writeLE(out, n, 8); }
            int pos = 0;
            do {
                int len = Math.min(128 * 1024, src.length - pos);
                boolean last = pos + len >= src.length;
                int header = (len << 3) | (last ? 1 : 0);
                writeLE(out, header, 3);
                if (len > 0) out.write(src, pos, len);
                pos += len;
            } while (pos < src.length || src.length == 0 && out.size() > 0 && false);
            return out.toByteArray();
        }

        static byte[] decode(byte[] data, boolean passThrough) throws IOException {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            int p = 0;
            boolean any = false;
            while (p < data.length) {
                if (p + 4 > data.length) break;
                int magic = readLE(data, p, 4); p += 4;
                if ((magic & SKIP_MAGIC_MASK) == SKIP_MAGIC_BASE) {
                    if (p + 4 > data.length) throw new IOException("truncated skippable frame");
                    int len = readLE(data, p, 4); p += 4 + len; any = true; continue;
                }
                if (magic != MAGIC) {
                    if (passThrough && !any) return data;
                    throw new IOException("unsupported format");
                }
                any = true;
                if (p >= data.length) throw new IOException("truncated frame header");
                int desc = data[p++] & 255;
                if ((desc & 0x08) != 0) throw new IOException("unsupported frame header");
                boolean single = (desc & 0x20) != 0;
                boolean checksum = (desc & 0x04) != 0;
                int fcsFlag = (desc >>> 6) & 3;
                int dictFlag = desc & 3;
                if (!single) { if (p >= data.length) throw new IOException("truncated window descriptor"); p++; }
                int dictBytes = dictFlag == 0 ? 0 : (dictFlag == 1 ? 1 : (dictFlag == 2 ? 2 : 4));
                p += dictBytes; if (p > data.length) throw new IOException("truncated dictionary id");
                int fcsBytes = fcsFlag == 0 ? (single ? 1 : 0) : (fcsFlag == 1 ? 2 : (fcsFlag == 2 ? 4 : 8));
                p += fcsBytes; if (p > data.length) throw new IOException("truncated content size");
                boolean last;
                do {
                    if (p + 3 > data.length) throw new IOException("truncated block header");
                    int bh = readLE(data, p, 3); p += 3;
                    last = (bh & 1) != 0;
                    int type = (bh >>> 1) & 3;
                    int size = bh >>> 3;
                    if (type == 0) { if (p + size > data.length) throw new IOException("truncated raw block"); out.write(data, p, size); p += size; }
                    else if (type == 1) { if (p >= data.length) throw new IOException("truncated rle block"); int v = data[p++] & 255; for (int i=0;i<size;i++) out.write(v); }
                    else if (type == 2) throw new IOException("compressed blocks are not supported by this reimplementation");
                    else throw new IOException("invalid block type");
                } while (!last);
                if (checksum) { if (p + 4 > data.length) throw new IOException("truncated checksum"); p += 4; }
            }
            if (!any) { if (passThrough) return data; throw new IOException("unsupported format"); }
            return out.toByteArray();
        }

        static long contentSize(byte[] data) throws IOException {
            if (data.length < 6 || readLE(data,0,4) != MAGIC) return -1;
            int p = 4, desc = data[p++] & 255;
            boolean single = (desc & 0x20) != 0;
            int fcsFlag = (desc >>> 6) & 3;
            if (!single) p++;
            int dictFlag = desc & 3;
            p += dictFlag == 0 ? 0 : (dictFlag == 1 ? 1 : (dictFlag == 2 ? 2 : 4));
            int bytes = fcsFlag == 0 ? (single ? 1 : 0) : (fcsFlag == 1 ? 2 : (fcsFlag == 2 ? 4 : 8));
            if (bytes == 0 || p + bytes > data.length) return -1;
            long v = readLELong(data, p, bytes);
            return fcsFlag == 1 ? v + 256 : v;
        }
    }

    static int readLE(byte[] b, int p, int n) { int v=0; for(int i=0;i<n;i++) v |= (b[p+i]&255) << (8*i); return v; }
    static long readLELong(byte[] b, int p, int n) { long v=0; for(int i=0;i<n;i++) v |= (long)(b[p+i]&255) << (8*i); return v; }
    static void writeLE(OutputStream out, long v, int n) throws IOException { for(int i=0;i<n;i++) out.write((int)(v >>> (8*i)) & 255); }
}
