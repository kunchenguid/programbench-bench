import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.regex.*;

public class CtagsClone {
    static final String VERSION = "Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team";
    static class Opt {
        String tagFile = "tags", output = "u-ctags", langForce = null, excmd = "pattern", filterTerm = null;
        boolean toStdout = false, recurse = false, append = false, xref = false, json = false, printLang = false;
        boolean help = false, version = false, license = false, filter = false, listLang = false, listFeat = false, listFormats = false;
        boolean listKinds = false, machinable = false, header = true, sort = true, format1 = false, quiet = false, totals = false;
        String listKindsLang = "all";
        List<String> files = new ArrayList<>(), excludes = new ArrayList<>(), listFiles = new ArrayList<>();
    }
    static class Tag {
        String name, path, line, kindLetter, kindName, scope, scopeKind, typeref;
        int lineNo; boolean fileScope;
        Tag(String n,String p,String l,int no,String kl,String kn){name=n;path=p;line=l;lineNo=no;kindLetter=kl;kindName=kn;}
    }
    interface Parser { void parse(Path file, String rel, List<String> lines, List<Tag> out); }

    public static void main(String[] args) {
        try {
            Opt opt = parseArgs(args);
            if (opt.help) { printHelp(); return; }
            if (opt.version) { printVersion(); return; }
            if (opt.license) { printLicense(); return; }
            if (opt.listFeat) { printFeatures(opt); return; }
            if (opt.listFormats) { printFormats(); return; }
            if (opt.listLang) { printLanguages(); return; }
            if (opt.listKinds) { printKinds(opt.listKindsLang); return; }
            List<String> inputs = collectInputs(opt);
            if (opt.printLang) { for (String f: inputs) System.out.println(f + ": " + languageFor(Paths.get(f), opt)); return; }
            List<Tag> tags = new ArrayList<>();
            for (String f: inputs) parseOne(Paths.get(f), opt, tags);
            if (opt.sort) tags.sort(Comparator.comparing((Tag t)->t.name).thenComparing(t->t.path).thenComparingInt(CtagsClone::kindRank).thenComparingInt(t->t.lineNo));
            writeTags(opt, tags);
        } catch (Exit e) {
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("executable: " + e.getMessage());
            System.exit(1);
        }
    }

    static class Exit extends RuntimeException { int code; Exit(int c){code=c;} }
    static Opt parseArgs(String[] args) throws IOException {
        Opt o = new Opt();
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            if (a.equals("--help")||a.equals("-?")||a.equals("--help-full")) o.help=true;
            else if (a.startsWith("--version")) o.version=true;
            else if (a.equals("--license")) o.license=true;
            else if (a.equals("--list-languages")) o.listLang=true;
            else if (a.equals("--list-features")) o.listFeat=true;
            else if (a.equals("--list-output-formats")) o.listFormats=true;
            else if (a.startsWith("--list-kinds")) { o.listKinds=true; int p=a.indexOf('='); if(p>=0)o.listKindsLang=a.substring(p+1); else if(i+1<args.length&&!args[i+1].startsWith("-"))o.listKindsLang=args[++i]; }
            else if (a.startsWith("--machinable")) o.machinable=!a.endsWith("=no");
            else if (a.startsWith("--with-list-header")) o.header=!a.endsWith("=no");
            else if (a.equals("-R")||a.equals("--recurse")||a.equals("--recurse=yes")) o.recurse=true;
            else if (a.equals("--recurse=no")) o.recurse=false;
            else if (a.equals("-a")||a.equals("--append")||a.equals("--append=yes")) o.append=true;
            else if (a.equals("--append=no")) o.append=false;
            else if (a.equals("-x")) { o.xref=true; o.toStdout=true; o.output="xref"; }
            else if (a.equals("-e")) { o.output="etags"; o.tagFile="TAGS"; }
            else if (a.equals("-u")||a.equals("--sort=no")) o.sort=false;
            else if (a.equals("--sort=yes")) o.sort=true;
            else if (a.equals("-n")||a.equals("--excmd=number")) o.excmd="number";
            else if (a.equals("-N")||a.equals("--excmd=pattern")) o.excmd="pattern";
            else if (a.equals("--format=1")) o.format1=true;
            else if (a.equals("--format=2")) o.format1=false;
            else if (a.equals("--print-language")) o.printLang=true;
            else if (a.equals("--quiet")||a.equals("--quiet=yes")) o.quiet=true;
            else if (a.startsWith("--totals")) o.totals=true;
            else if (a.equals("--filter")||a.equals("--filter=yes")) { o.filter=true; o.toStdout=true; }
            else if (a.equals("--filter=no")) o.filter=false;
            else if (a.startsWith("--filter-terminator=")) o.filterTerm=a.substring(20);
            else if (a.equals("-f")||a.equals("-o")) { if(++i>=args.length) die("Option " + a + " requires an argument"); setTagFile(o,args[i]); }
            else if (a.startsWith("-f") && a.length()>2) setTagFile(o,a.substring(2));
            else if (a.startsWith("--output-format=")) { o.output=a.substring(16); o.json=o.output.equals("json"); if(o.json)o.toStdout=true; }
            else if (a.startsWith("--language-force=")) o.langForce=a.substring(17);
            else if (a.equals("-L")) { if(++i>=args.length) die("Option -L requires an argument"); o.listFiles.add(args[i]); }
            else if (a.startsWith("-L") && a.length()>2) o.listFiles.add(a.substring(2));
            else if (a.startsWith("--exclude=")) o.excludes.add(a.substring(10));
            else if (a.startsWith("--")) { System.err.println("executable: Unknown option: " + a); throw new Exit(1); }
            else o.files.add(a);
        }
        return o;
    }
    static void setTagFile(Opt o,String v){ o.tagFile=v; if(v.equals("-")) o.toStdout=true; }
    static void die(String m){ System.err.println("executable: " + m); throw new Exit(1); }
    static int kindRank(Tag t){ return t.kindLetter.equals("m") && t.scope != null && t.name.equals(t.scope.substring(t.scope.lastIndexOf('.')+1)) ? 0 : t.kindLetter.equals("c") ? 1 : 2; }

    static List<String> collectInputs(Opt o) throws IOException {
        List<String> r = new ArrayList<>(o.files);
        for (String lf: o.listFiles) {
            BufferedReader br = lf.equals("-") ? new BufferedReader(new InputStreamReader(System.in)) : Files.newBufferedReader(Paths.get(lf));
            String s; while((s=br.readLine())!=null) if(!s.isEmpty()) r.add(s); if(!lf.equals("-")) br.close();
        }
        if (o.filter && r.isEmpty()) {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String s; while((s=br.readLine())!=null) if(!s.isEmpty()) r.add(s);
        }
        if (r.isEmpty() && !o.filter) r.add(".");
        List<String> expanded = new ArrayList<>();
        for (String f: r) {
            Path p=Paths.get(f);
            if (Files.isDirectory(p) && o.recurse) {
                Files.walkFileTree(p, new SimpleFileVisitor<>() {
                    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) { if(!excluded(file,o)) expanded.add(file.toString()); return FileVisitResult.CONTINUE; }
                });
            } else if (!Files.isDirectory(p) && !excluded(p,o)) expanded.add(f);
        }
        return expanded;
    }
    static boolean excluded(Path p, Opt o) {
        String s=p.toString(), n=p.getFileName()==null?s:p.getFileName().toString();
        for(String e:o.excludes) if(glob(e,n)||glob(e,s)) return true;
        return false;
    }
    static boolean glob(String pat,String s){ String q=Pattern.quote(pat).replace("*","\\E.*\\Q").replace("?","\\E.\\Q"); return s.matches(q); }

    static void parseOne(Path file, Opt o, List<Tag> out) throws IOException {
        if (!Files.exists(file) || Files.isDirectory(file)) return;
        List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        String lang = languageFor(file,o);
        Parser p = parser(lang);
        p.parse(file, file.toString(), lines, out);
    }
    static String languageFor(Path f, Opt o) {
        if (o.langForce!=null && !o.langForce.equalsIgnoreCase("auto")) return normLang(o.langForce);
        String n=f.getFileName()==null?f.toString():f.getFileName().toString(), l=n.toLowerCase(Locale.ROOT);
        if (l.endsWith(".c")||l.endsWith(".h")) return "C";
        if (l.endsWith(".cc")||l.endsWith(".cpp")||l.endsWith(".cxx")||l.endsWith(".hpp")||l.endsWith(".hh")) return "C++";
        if (l.endsWith(".java")) return "Java";
        if (l.endsWith(".py")||l.equals("sconstruct")||l.equals("sconscript")) return "Python";
        if (l.endsWith(".js")||l.endsWith(".mjs")||l.endsWith(".cjs")) return "JavaScript";
        if (l.endsWith(".ts")||l.endsWith(".tsx")) return "TypeScript";
        if (l.endsWith(".go")) return "Go";
        if (l.endsWith(".rs")) return "Rust";
        if (l.endsWith(".rb")||l.equals("rakefile")||l.endsWith(".gemspec")) return "Ruby";
        if (l.endsWith(".php")) return "PHP";
        if (l.endsWith(".sh")||l.endsWith(".bash")||l.endsWith(".zsh")) return "Sh";
        if (l.equals("makefile")||l.endsWith(".mk")) return "Make";
        if (l.endsWith(".html")||l.endsWith(".htm")) return "HTML";
        if (l.endsWith(".css")) return "CSS";
        return "Unknown";
    }
    static String normLang(String s){ if(s.equalsIgnoreCase("c++"))return"C++"; return s.substring(0,1).toUpperCase()+s.substring(1); }
    static Parser parser(String l) {
        if(l.equals("C")||l.equals("C++")) return CtagsClone::parseC;
        if(l.equals("Java")) return CtagsClone::parseJava;
        if(l.equals("Python")) return CtagsClone::parsePython;
        if(l.equals("JavaScript")||l.equals("TypeScript")) return CtagsClone::parseJS;
        if(l.equals("Go")) return CtagsClone::parseGo;
        if(l.equals("Rust")) return CtagsClone::parseRust;
        if(l.equals("Ruby")) return CtagsClone::parseRuby;
        if(l.equals("PHP")) return CtagsClone::parsePHP;
        if(l.equals("Sh")) return CtagsClone::parseSh;
        if(l.equals("Make")) return CtagsClone::parseMake;
        if(l.equals("HTML")) return CtagsClone::parseHTML;
        if(l.equals("CSS")) return CtagsClone::parseCSS;
        return CtagsClone::parseGeneric;
    }

    static void add(List<Tag> out,String n,String path,String line,int no,String kl,String kn){ if(n!=null&&!n.isEmpty()) out.add(new Tag(n,path,line,no,kl,kn)); }
    static String trimComment(String s){ return s.replaceAll("//.*$","").replaceAll("/\\*.*?\\*/",""); }
    static String escPattern(String s){ return s.replace("\\","\\\\").replace("/","\\/").replace("$","\\$"); }

    static void parseC(Path f,String path,List<String> lines,List<Tag> out){
        Pattern def=Pattern.compile("^\\s*#\\s*define\\s+([A-Za-z_]\\w*)");
        Pattern td=Pattern.compile("^\\s*typedef\\s+(struct|union|enum)?\\s*([A-Za-z_]\\w*)?.*\\b([A-Za-z_]\\w*)\\s*;");
        Pattern su=Pattern.compile("^\\s*(?:typedef\\s+)?(struct|union|enum)\\s+([A-Za-z_]\\w*)");
        Pattern fun=Pattern.compile("^\\s*(?:static\\s+|extern\\s+|inline\\s+|const\\s+|unsigned\\s+|signed\\s+|long\\s+|short\\s+|\\*|[A-Za-z_]\\w*\\s+)+([A-Za-z_]\\w*)\\s*\\([^;]*\\)\\s*(?:\\{|$)");
        Pattern var=Pattern.compile("^\\s*(?:static\\s+|extern\\s+|const\\s+|unsigned\\s+|signed\\s+|long\\s+|short\\s+|volatile\\s+)*(?:[A-Za-z_]\\w*|char|int|void|float|double|size_t)\\s+\\*?\\s*([A-Za-z_]\\w*)\\s*(?:=|;|\\[)");
        String scope=null, sk=null; int depth=0;
        for(int i=0;i<lines.size();i++){ String line=lines.get(i), s=trimComment(line); Matcher m;
            if((m=def.matcher(s)).find()){ Tag t=new Tag(m.group(1),path,line.contains("(")?line:line.replaceFirst("(#\\s*define\\s+\\w+).*","$1 "),i+1,"d","macro"); t.fileScope=true; out.add(t); }
            if((m=su.matcher(s)).find()){ String k=m.group(1), name=m.group(2); Tag t=new Tag(name,path,line,i+1,k.equals("enum")?"g":k.equals("union")?"u":"s",k.equals("enum")?"enum":k); t.fileScope=true; out.add(t); if(s.contains("{")){scope=name;sk=k;}}
            if(s.trim().startsWith("typedef") && (m=td.matcher(s)).find()){ String base=m.group(2), name=m.group(3); Tag t=new Tag(name,path,line,i+1,"t","typedef"); t.fileScope=true; if(m.group(1)!=null)t.typeref=m.group(1)+":"+(base!=null?base:name); out.add(t); }
            if(scope!=null && (sk.equals("struct")||sk.equals("union"))) { Matcher mm=Pattern.compile("\\b(?:int|char|long|short|float|double|size_t)\\s+\\*?\\s*([A-Za-z_]\\w*)\\b").matcher(s); while(mm.find()){String n=mm.group(1); Tag t=new Tag(n,path,line,i+1,"m","member");t.scope=scope;t.scopeKind=sk;t.typeref="typename:"+s.replaceAll("^\\s*(?:typedef\\s+)?(?:struct|union)\\s+\\w+\\s*\\{\\s*","").replaceAll("\\s+.*","");t.fileScope=true;out.add(t);}}
            if((m=fun.matcher(s)).find()){ String n=m.group(1); if(!Set.of("if","for","while","switch","return").contains(n)){ Tag t=new Tag(n,path,line,i+1,"f","function"); if(s.trim().startsWith("static"))t.fileScope=true; t.typeref="typename:"+s.trim().replaceAll("\\s*\\**\\s*"+Pattern.quote(n)+"\\s*\\(.*","").replaceAll("^(static|extern|inline)\\s+",""); out.add(t);} }
            else if(scope==null && (m=var.matcher(s)).find()){ Tag t=new Tag(m.group(1),path,line,i+1,"v","variable"); t.typeref="typename:"+s.trim().replaceAll("\\s*\\**\\s*"+Pattern.quote(m.group(1))+".*","").replaceAll("^(static|extern|const|volatile)\\s+",""); out.add(t); }
            for(char c:s.toCharArray()){ if(c=='{')depth++; else if(c=='}'){depth--; if(depth<=0){scope=null;sk=null;depth=0;}} }
        }
    }

    static void parseJava(Path f,String path,List<String> lines,List<Tag> out){
        Deque<String> scopes=new ArrayDeque<>(), kinds=new ArrayDeque<>(); Deque<Integer> depths=new ArrayDeque<>(); int depth=0;
        Pattern pkg=Pattern.compile("^\\s*package\\s+([\\w.]+)\\s*;");
        Pattern type=Pattern.compile("\\b(class|interface|enum|@interface)\\s+([A-Za-z_]\\w*)");
        Pattern meth=Pattern.compile("(?:public|private|protected|static|final|native|synchronized|abstract|\\s)+[\\w<>\\[\\].?,]+\\s+([A-Za-z_]\\w*)\\s*\\([^;]*\\)");
        Pattern field=Pattern.compile("^\\s*(?:public|private|protected|static|final|transient|volatile|\\s)*(?:[\\w<>\\[\\].?,]+)\\s+([A-Za-z_]\\w*)\\s*(?:=|;)");
        for(int i=0;i<lines.size();i++){String line=lines.get(i), s=line.replaceAll("//.*$",""); Matcher m;
            if((m=pkg.matcher(s)).find()) add(out,m.group(1),path,line,i+1,"p","package");
            String tempScope = scopes.isEmpty()?null:String.join(".",reverse(scopes)), tempKind = kinds.peek();
            if((m=type.matcher(s)).find()){String k=m.group(1), n=m.group(2); Tag t=new Tag(n,path,line,i+1,k.equals("interface")||k.equals("@interface")?"i":k.equals("enum")?"g":"c",k.equals("@interface")?"interface":k); if(tempScope!=null){t.scope=tempScope;t.scopeKind=tempKind;} out.add(t); if(k.equals("enum")) enumConstants(out,path,line,i+1,n); String nk=k.equals("enum")?"enum":k.equals("interface")||k.equals("@interface")?"interface":"class"; tempScope=(tempScope==null?n:tempScope+"."+n); tempKind=nk; int nd=depth+count(s,'{')-count(s,'}'); if(nd>depth){scopes.push(n); kinds.push(nk); depths.push(nd);} }
            String leaf = tempScope==null?null:tempScope.substring(tempScope.lastIndexOf('.')+1);
            if(leaf!=null && (m=Pattern.compile("\\b"+Pattern.quote(leaf)+"\\s*\\(").matcher(s)).find()){Tag t=new Tag(leaf,path,line,i+1,"m","method");t.scope=tempScope;t.scopeKind=tempKind;out.add(t);}
            else if((m=meth.matcher(s)).find()){Tag t=new Tag(m.group(1),path,line,i+1,"m","method"); if(tempScope!=null){t.scope=tempScope;t.scopeKind=tempKind;} out.add(t);}
            else if(tempScope!=null && (m=field.matcher(s)).find() && !s.contains("(")){Tag t=new Tag(m.group(1),path,line,i+1,"f","field");t.scope=tempScope;t.scopeKind=tempKind;t.fileScope=s.contains("private");out.add(t);}
            depth += count(s,'{')-count(s,'}');
            while(!depths.isEmpty() && depth < depths.peek()){depths.pop();scopes.pop();kinds.pop();}
        }
    }
    static List<String> reverse(Deque<String>d){ List<String> l=new ArrayList<>(d); Collections.reverse(l); return l; }
    static int count(String s,char c){int n=0;for(char x:s.toCharArray())if(x==c)n++;return n;}
    static void enumConstants(List<Tag> out,String path,String line,int no,String en){int a=line.indexOf('{'),b=line.indexOf('}'); if(a>=0&&b>a){for(String p:line.substring(a+1,b).split(",")){String n=p.trim().replaceAll("\\(.*",""); if(n.matches("[A-Z_][A-Za-z0-9_]*")){Tag t=new Tag(n,path,line,no,"e","enumConstant");t.scope=en;t.scopeKind="enum";t.fileScope=true;out.add(t);}}}}

    static void parsePython(Path f,String path,List<String> lines,List<Tag> out){
        Deque<String> cls=new ArrayDeque<>(); Deque<Integer> ind=new ArrayDeque<>();
        Pattern c=Pattern.compile("^(\\s*)class\\s+([A-Za-z_]\\w*)"), fn=Pattern.compile("^(\\s*)(?:async\\s+)?def\\s+([A-Za-z_]\\w*)"), var=Pattern.compile("^(\\s*)([A-Z_a-z]\\w*)\\s*=");
        for(int i=0;i<lines.size();i++){String line=lines.get(i); if(line.trim().isEmpty()||line.trim().startsWith("#"))continue; int sp=line.length()-line.stripLeading().length(); while(!ind.isEmpty()&&sp<=ind.peek()){ind.pop();cls.pop();} Matcher m;
            if((m=c.matcher(line)).find()){Tag t=new Tag(m.group(2),path,line,i+1,"c","class");out.add(t);cls.push(m.group(2));ind.push(sp);}
            else if((m=fn.matcher(line)).find()){Tag t=new Tag(m.group(2),path,line,i+1,cls.isEmpty()?"f":"m",cls.isEmpty()?"function":"member"); if(!cls.isEmpty()){t.scope=cls.peek();t.scopeKind="class";} out.add(t);}
            else if((m=var.matcher(line)).find()){Tag t=new Tag(m.group(2),path,line,i+1,"v","variable"); if(!cls.isEmpty()){t.scope=cls.peek();t.scopeKind="class";} out.add(t);}
        }
    }
    static void parseJS(Path f,String path,List<String> lines,List<Tag> out){
        String cls=null; int depth=0; Pattern cl=Pattern.compile("\\bclass\\s+([A-Za-z_$][\\w$]*)"), fun=Pattern.compile("\\bfunction\\s+([A-Za-z_$][\\w$]*)\\s*\\("), var=Pattern.compile("\\b(var|let|const)\\s+([A-Za-z_$][\\w$]*)"), meth=Pattern.compile("^\\s*(?:static\\s+)?([A-Za-z_$][\\w$]*)\\s*\\("), exp=Pattern.compile("\\bexports\\.([A-Za-z_$][\\w$]*)\\s*=\\s*function");
        for(int i=0;i<lines.size();i++){String line=lines.get(i),s=line.replaceAll("//.*$","");Matcher m;
            if((m=cl.matcher(s)).find()){Tag t=new Tag(m.group(1),path,line,i+1,"c","class");out.add(t);cls=m.group(1);}
            if((m=var.matcher(s)).find()){String k=m.group(1),n=m.group(2);Tag t=new Tag(n,path,line,i+1,k.equals("const")?"C":"v",k.equals("const")?"constant":"variable");out.add(t);}
            if((m=fun.matcher(s)).find()) add(out,m.group(1),path,line,i+1,"f","function");
            if((m=exp.matcher(s)).find()){Tag t=new Tag(m.group(1),path,line,i+1,"f","function");t.scope="exports";t.scopeKind="variable";out.add(t);}
            if(cls!=null && (m=meth.matcher(s)).find()){String n=m.group(1); if(!Set.of("if","for","while","switch","function").contains(n)){Tag t=new Tag(n,path,line,i+1,"m","method");t.scope=cls;t.scopeKind="class";out.add(t);}}
            depth+=count(s,'{')-count(s,'}'); if(depth<=0)cls=null;
        }
    }
    static void parseGo(Path f,String p,List<String> lines,List<Tag> out){ Pattern fn=Pattern.compile("^\\s*func\\s+(?:\\([^)]*\\)\\s*)?([A-Za-z_]\\w*)\\s*\\("), ty=Pattern.compile("^\\s*type\\s+([A-Za-z_]\\w*)\\s+(struct|interface|\\w+)"), v=Pattern.compile("^\\s*(?:var|const)\\s+([A-Za-z_]\\w*)"); for(int i=0;i<lines.size();i++){Matcher m;if((m=fn.matcher(lines.get(i))).find())add(out,m.group(1),p,lines.get(i),i+1,"f","function"); if((m=ty.matcher(lines.get(i))).find())add(out,m.group(1),p,lines.get(i),i+1,m.group(2).equals("struct")?"s":"t",m.group(2).equals("struct")?"struct":"typedef"); if((m=v.matcher(lines.get(i))).find())add(out,m.group(1),p,lines.get(i),i+1,"v","variable");}}
    static void parseRust(Path f,String p,List<String> l,List<Tag> o){Pattern q=Pattern.compile("^\\s*(?:pub\\s+)?(fn|struct|enum|trait|mod|const|static)\\s+([A-Za-z_]\\w*)");for(int i=0;i<l.size();i++){Matcher m=q.matcher(l.get(i));if(m.find()){String k=m.group(1);add(o,m.group(2),p,l.get(i),i+1,k.equals("fn")?"f":k.substring(0,1),k.equals("fn")?"function":k);}}}
    static void parseRuby(Path f,String p,List<String> l,List<Tag> o){Pattern c=Pattern.compile("^\\s*(class|module)\\s+([A-Za-z_:]\\w*)"), d=Pattern.compile("^\\s*def\\s+(?:self\\.)?([A-Za-z_]\\w*[!?=]?)");for(int i=0;i<l.size();i++){Matcher m;if((m=c.matcher(l.get(i))).find())add(o,m.group(2),p,l.get(i),i+1,m.group(1).equals("class")?"c":"m",m.group(1));if((m=d.matcher(l.get(i))).find())add(o,m.group(1),p,l.get(i),i+1,"f","method");}}
    static void parsePHP(Path f,String p,List<String> l,List<Tag> o){Pattern q=Pattern.compile("\\b(class|interface|trait|function)\\s+([A-Za-z_]\\w*)");for(int i=0;i<l.size();i++){Matcher m=q.matcher(l.get(i));while(m.find()){String k=m.group(1);add(o,m.group(2),p,l.get(i),i+1,k.equals("function")?"f":k.substring(0,1),k.equals("function")?"function":k);}}}
    static void parseSh(Path f,String p,List<String> l,List<Tag> o){Pattern a=Pattern.compile("^\\s*([A-Za-z_]\\w*)\\s*\\(\\)"), b=Pattern.compile("^\\s*function\\s+([A-Za-z_]\\w*)");for(int i=0;i<l.size();i++){Matcher m=a.matcher(l.get(i));if(m.find())add(o,m.group(1),p,l.get(i),i+1,"f","function");m=b.matcher(l.get(i));if(m.find())add(o,m.group(1),p,l.get(i),i+1,"f","function");}}
    static void parseMake(Path f,String p,List<String> l,List<Tag> o){Pattern q=Pattern.compile("^([A-Za-z0-9_.%/-]+)\\s*:");for(int i=0;i<l.size();i++){Matcher m=q.matcher(l.get(i));if(m.find()&&!m.group(1).contains("="))add(o,m.group(1),p,l.get(i),i+1,"t","target");}}
    static void parseHTML(Path f,String p,List<String> l,List<Tag> o){Pattern q=Pattern.compile("id=[\"']([^\"']+)[\"']");for(int i=0;i<l.size();i++){Matcher m=q.matcher(l.get(i));while(m.find())add(o,m.group(1),p,l.get(i),i+1,"i","id");}}
    static void parseCSS(Path f,String p,List<String> l,List<Tag> o){Pattern q=Pattern.compile("^\\s*([.#][A-Za-z_][\\w-]*)\\s*\\{");for(int i=0;i<l.size();i++){Matcher m=q.matcher(l.get(i));if(m.find())add(o,m.group(1),p,l.get(i),i+1,m.group(1).startsWith(".")?"c":"i",m.group(1).startsWith(".")?"class":"id");}}
    static void parseGeneric(Path f,String p,List<String> l,List<Tag> o){ for(int i=0;i<l.size();i++){Matcher m=Pattern.compile("\\b(function|class|def)\\s+([A-Za-z_]\\w*)").matcher(l.get(i)); if(m.find())add(o,m.group(2),p,l.get(i),i+1,m.group(1).equals("class")?"c":"f",m.group(1).equals("class")?"class":"function");}}

    static void writeTags(Opt o,List<Tag> tags) throws IOException {
        Writer w = o.toStdout ? new OutputStreamWriter(System.out) : Files.newBufferedWriter(Paths.get(o.tagFile), StandardCharsets.UTF_8, o.append?StandardOpenOption.CREATE:StandardOpenOption.CREATE, o.append?StandardOpenOption.APPEND:StandardOpenOption.TRUNCATE_EXISTING);
        if(o.xref){ for(Tag t:tags) w.write(String.format("%-16s %-12s %4d %-16s %s%n",t.name,t.kindName,t.lineNo,t.path,t.line.trim())); }
        else if(o.json){ for(Tag t:tags) w.write(json(t)+"\n"); }
        else {
            if(!o.toStdout && !o.append) pseudo(w,o);
            for(Tag t:tags) w.write(tagLine(t,o)+"\n");
        }
        w.flush(); if(!o.toStdout) w.close();
    }
    static String tagLine(Tag t,Opt o){String ex=o.excmd.equals("number")?String.valueOf(t.lineNo):"/^"+escPattern(t.line)+(t.kindLetter.equals("d")&&t.line.endsWith(" ")?"/":"$/"); String s=t.name+"\t"+t.path+"\t"+ex+(o.format1?"":";\""); if(!o.format1){s+="\t"+t.kindLetter; if(t.scope!=null)s+="\t"+t.scopeKind+":"+t.scope; if(t.typeref!=null)s+="\ttyperef:"+t.typeref; if(t.fileScope)s+="\tfile:";} return s;}
    static String json(Tag t){StringBuilder b=new StringBuilder("{\"_type\": \"tag\", \"name\": \""+je(t.name)+"\", \"path\": \""+je(t.path)+"\", \"pattern\": \"/^"+je(escPattern(t.line))+"$/\""); if(t.fileScope)b.append(", \"file\": true"); b.append(", \"kind\": \"").append(je(t.kindName)).append("\""); if(t.scope!=null)b.append(", \"scope\": \"").append(je(t.scope)).append("\", \"scopeKind\": \"").append(je(t.scopeKind)).append("\""); return b.append("}").toString();}
    static String je(String s){return s.replace("\\","\\\\").replace("\"","\\\"");}
    static void pseudo(Writer w,Opt o)throws IOException{w.write("!_TAG_FILE_FORMAT\t2\t/extended format; --format=1 will not append ;\" to lines/\n!_TAG_FILE_SORTED\t"+(o.sort?"1":"0")+"\t/0=unsorted, 1=sorted, 2=foldcase/\n!_TAG_OUTPUT_MODE\tu-ctags\t/u-ctags or e-ctags/\n!_TAG_OUTPUT_VERSION\t1.1\t/current.age/\n!_TAG_PROGRAM_NAME\tUniversal Ctags\t/Derived from Exuberant Ctags/\n!_TAG_PROGRAM_URL\thttps://ctags.io/\t/official site/\n!_TAG_PROGRAM_VERSION\t6.2.0\t/d922013/\n");}

    static void printVersion(){ printVersionHeader(); }
    static void printVersionHeader(){System.out.println(VERSION+"\nUniversal Ctags is derived from Exuberant Ctags.\nExuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert\n  Compiled: Apr 20 2026, 16:52:56\n  URL: https://ctags.io/\n  Output version: 1.1\n  Optional compiled features: +wildcards, +regex, +iconv, +option-directory, +xpath, +json, +interactive, +sandbox, +yaml, +packcc, +optscript");}
    static void printHelp(){printVersionHeader();System.out.println("\nUsage: executable [options] [file(s)]\n\nInput/Output Options\n  --exclude=<pattern>\n  --filter[=(yes|no)]\n  --recurse[=(yes|no)]\n  -R   Equivalent to --recurse.\n  -L <file>\n  -f <tagfile>\n  -o   Alternative for -f.\n\nOutput Format Options\n  --format=(1|2)\n  --output-format=(u-ctags|e-ctags|etags|xref|json)\n  -x   Print a tabular cross reference file to standard output.\n  --sort=(yes|no|foldcase)\n  -n   Equivalent to --excmd=number.\n  -N   Equivalent to --excmd=pattern.\n\nLanguage Selection and Mapping Options\n  --language-force=(<language>|auto)\n\nListing Options\n  --list-features\n  --list-kinds[=(<language>|all)]\n  --list-languages\n  --list-output-formats\n\nMiscellaneous Options\n  --help\n  --license\n  --print-language\n  --version[=<language>]");}
    static void printLicense(){printVersionHeader();System.out.println("\nThis program is free software; you can redistribute it and/or\nmodify it under the terms of the GNU General Public License\nas published by the Free Software Foundation; either version 2of the License, or (at your option) any later version.\n\nThis program is distributed in the hope that it will be useful,\nbut WITHOUT ANY WARRANTY; without even the implied warranty of\nMERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.");}
    static void printFeatures(Opt o){ if(o.header)System.out.println("#NAME             DESCRIPTION"); for(String s:List.of("iconv","interactive","json","option-directory","optscript","packcc","regex","sandbox","wildcards","xpath","yaml"))System.out.printf("%-17s %s%n",s,"can use "+s); }
    static void printFormats(){System.out.println("#OFORMAT DEFAULT AVAILABLE NULLTAG \ne-ctags       no       yes      no \netags         no       yes      no \njson          no       yes     yes \nu-ctags      yes       yes      no \nxref          no       yes     yes "); }
    static void printLanguages(){String[] l={"Abaqus","Abc","Ada","AnsiblePlaybook","Ant","Asciidoc","Asm","Asp","Autoconf","Automake","Awk","Basic","C","C#","C++","CSS","Ctags","Go","HTML","Java","JavaScript","JSON","Make","PHP","Python","Ruby","Rust","Sh","TypeScript","Unknown"}; for(String s:l)System.out.println(s);}
    static void printKinds(String lang){String l=lang.toLowerCase(Locale.ROOT); if(l.equals("java"))System.out.print("a  annotation declarations\nc  classes\ne  enum constants\nf  fields\ng  enum types\ni  interfaces\nm  methods\np  packages\n"); else if(l.equals("c")||l.equals("c++"))System.out.print("d  macro definitions\ne  enumerators (values inside an enumeration)\nf  function definitions\ng  enumeration names\nm  struct, and union members\ns  structure names\nt  typedefs\nu  union names\nv  variable definitions\n"); else if(l.equals("python"))System.out.print("c  classes\nf  functions\nm  class members\nv  variables\n"); else System.out.print("c  classes\nf  functions\nm  members\nv  variables\n");}
}
