import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.regex.*;

public class Dirble {
    static final String VERSION = "Dirble 1.4.2 (commit d520c82, build 2026-04-17)";
    static class Opt {
        List<String> uris = new ArrayList<>();
        String uriFile, wordlist, verb = "get", jsonFile, xmlFile, outputFile, outputAll;
        List<String> prefixes = new ArrayList<>(), extensions = new ArrayList<>(), cookies = new ArrayList<>(), headers = new ArrayList<>();
        List<int[]> hideLengths = new ArrayList<>();
        Set<Integer> blacklist = new HashSet<>(), whitelist = new HashSet<>();
        boolean noColor, silent, disableValidator, extSub, forceExt, showHtaccess, scanListable, scrapeListable, noProxy;
        int timeout = 5, maxDepth = 10, throttle = 0;
        String username, password, userAgent;
    }
    static class Result {
        String url, redirect = "";
        int code, size;
        boolean dir, listable, fromListable;
        String line() {
            String p = listable ? "L" : (dir ? "D" : "+");
            return p + " " + url + " (CODE:" + code + "|SIZE:" + size + (redirect.isEmpty() ? "" : "|DEST:" + redirect) + ")";
        }
    }

    public static void main(String[] args) {
        try {
            Opt o = parse(args);
            if (o == null) return;
            if (o.uriFile != null) for (String s : readLines(o.uriFile)) if (!s.isBlank()) o.uris.add(s.trim());
            if (o.uris.isEmpty()) { printHelp(); return; }
            if (o.wordlist == null) {
                Path p = Paths.get("dirble_wordlist.txt");
                if (!Files.exists(p)) {
                    Path near = executableDir().resolve("dirble_wordlist.txt");
                    if (Files.exists(near)) p = near;
                }
                if (!Files.exists(p)) { System.err.println("[ERROR] Unable to find default wordlist"); System.exit(1); }
                o.wordlist = p.toString();
            }
            List<String> words = readLines(o.wordlist);
            List<Result> all = new ArrayList<>();
            HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(o.timeout)).followRedirects(HttpClient.Redirect.NEVER).build();
            for (String raw : o.uris) {
                String base = normalizeBase(raw);
                Set<Integer> notFound = new HashSet<>();
                if (!o.disableValidator) {
                    Result nf = request(client, o, joinUrl(base, "__dirble_not_found_" + System.nanoTime()));
                    if (nf != null) {
                        notFound.add(nf.code);
                        if (!o.silent) System.out.println("[INFO] Detected nonexistent paths for " + ensureSlash(base) + " are (CODE:" + nf.code + ")");
                    }
                }
                scanBase(client, o, words, base, notFound, all, 0);
            }
            all.sort(Comparator.comparing((Result r) -> r.url).thenComparingInt(r -> r.code));
            writeReports(o, all);
        } catch (CliError e) {
            System.err.println(e.getMessage());
            System.err.println();
            System.err.println("For more information, try '--help'.");
            System.exit(2);
        } catch (Exception e) {
            System.err.println("[ERROR] " + e.getMessage());
            System.exit(1);
        }
    }

    static class CliError extends Exception { CliError(String m) { super(m); } }

    static Opt parse(String[] args) throws CliError {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "--help": printHelp(); return null;
                case "-V": case "--version": System.out.println(VERSION); return null;
                case "-u": case "--uri": case "--url": o.uris.add(val(args, ++i, a)); break;
                case "-U": case "--uri-file": case "--url-file": o.uriFile = val(args, ++i, a); break;
                case "--verb": o.verb = val(args, ++i, a).toLowerCase(Locale.ROOT); if (!List.of("get","head","post").contains(o.verb)) throw new CliError("error: invalid value '" + o.verb + "' for '--verb <http_verb>'\n  [possible values: get, head, post]"); break;
                case "-w": case "--wordlist": o.wordlist = val(args, ++i, a); break;
                case "-p": case "--prefixes": addCsv(o.prefixes, val(args, ++i, a)); break;
                case "-P": case "--prefix-file": o.prefixes.addAll(readLinesNoThrow(val(args, ++i, a))); break;
                case "-x": case "--extensions": addCsv(o.extensions, val(args, ++i, a)); break;
                case "-X": case "--extension-file": o.extensions.addAll(readLinesNoThrow(val(args, ++i, a))); break;
                case "--ext-sub": o.extSub = true; break;
                case "-f": case "--force-extension": o.forceExt = true; break;
                case "-k": case "--ignore-cert": break;
                case "--show-htaccess": o.showHtaccess = true; break;
                case "--timeout": o.timeout = parseInt(val(args, ++i, a), a); break;
                case "--max-errors": ++i; break;
                case "--json-file": case "--oJ": o.jsonFile = val(args, ++i, a); break;
                case "--no-color": o.noColor = true; break;
                case "-o": case "--output-file": case "--oN": o.outputFile = val(args, ++i, a); break;
                case "--xml-file": case "--oX": o.xmlFile = val(args, ++i, a); break;
                case "--hide-lengths": addLengths(o.hideLengths, val(args, ++i, a)); break;
                case "--output-all": case "--oA": o.outputAll = val(args, ++i, a); break;
                case "--burp": case "--proxy": if (a.equals("--proxy")) ++i; break;
                case "--no-proxy": o.noProxy = true; break;
                case "-t": case "--max-threads": ++i; break;
                case "-T": case "--wordlist-split": ++i; break;
                case "-z": case "--throttle": o.throttle = parseInt(val(args, ++i, a), a); break;
                case "--username": o.username = val(args, ++i, a); break;
                case "--password": o.password = val(args, ++i, a); break;
                case "-l": case "--scan-listable": o.scanListable = true; break;
                case "--max-recursion-depth": o.maxDepth = parseInt(val(args, ++i, a), a); break;
                case "-r": case "--disable-recursion": o.maxDepth = 0; break;
                case "--scrape-listable": o.scrapeListable = true; break;
                case "-a": case "--user-agent": o.userAgent = val(args, ++i, a); break;
                case "-c": case "--cookie": o.cookies.add(val(args, ++i, a)); break;
                case "-H": case "--header": o.headers.add(val(args, ++i, a)); break;
                case "-S": case "--silent": o.silent = true; break;
                case "-v": case "--verbose": break;
                case "-B": case "--code-blacklist": addCodes(o.blacklist, val(args, ++i, a)); break;
                case "--disable-validator": o.disableValidator = true; break;
                case "-W": case "--code-whitelist": addCodes(o.whitelist, val(args, ++i, a)); o.disableValidator = true; break;
                case "--scan-401": case "--scan-403": break;
                default:
                    if (a.startsWith("-")) throw new CliError("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>");
                    o.uris.add(a);
            }
        }
        return o;
    }

    static void scanBase(HttpClient client, Opt o, List<String> words, String base, Set<Integer> nf, List<Result> all, int depth) {
        for (String path : expand(words, o)) {
            if (path.isBlank() || path.startsWith("#")) continue;
            if (o.throttle > 0) try { Thread.sleep(o.throttle); } catch (InterruptedException ignored) {}
            Result r = request(client, o, joinUrl(base, path));
            if (r == null || hide(o, r, nf)) continue;
            all.add(r);
            if (!o.silent) System.out.println(r.line());
            if (depth < o.maxDepth && r.dir && (r.code == 200 || r.code == 401 || r.code == 403)) {
                scanBase(client, o, words, ensureSlash(r.url), nf, all, depth + 1);
            }
            if (o.scrapeListable && r.listable) {
                for (String link : scrapeLinks(r.url, client, o)) {
                    Result sr = request(client, o, link);
                    if (sr != null && !hide(o, sr, nf)) { sr.fromListable = true; all.add(sr); if (!o.silent) System.out.println(sr.line()); }
                }
            }
        }
    }

    static List<String> expand(List<String> words, Opt o) {
        List<String> out = new ArrayList<>();
        List<String> exts = o.extensions.isEmpty() ? List.of("") : o.extensions;
        List<String> prefs = o.prefixes.isEmpty() ? List.of("") : o.prefixes;
        List<String> cleaned = new ArrayList<>();
        for (String w0 : words) {
            String w = w0.trim();
            if (!w.isEmpty() && !w.startsWith("#")) cleaned.add(w);
        }
        Collections.sort(cleaned);
        for (String p : prefs) {
            if (!o.forceExt) {
                for (String w : cleaned) {
                    if (o.extSub && w.contains("%EXT%")) out.add(p + w.replace("%EXT%", ""));
                    else out.add(p + w.replaceAll("/+$", ""));
                }
            }
            for (String e : exts) {
                if (e.isEmpty() && !o.forceExt) continue;
                for (String w : cleaned) {
                    if (o.extSub) {
                        if (w.contains("%EXT%")) out.add(p + w.replace("%EXT%", e));
                    } else {
                        out.add(p + w.replaceAll("/+$", "") + e);
                    }
                }
            }
        }
        return out;
    }

    static Result request(HttpClient client, Opt o, String url) {
        try {
            HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(o.timeout));
            String method = o.verb.toUpperCase(Locale.ROOT);
            if (method.equals("POST")) b.POST(HttpRequest.BodyPublishers.noBody());
            else if (method.equals("HEAD")) b.method("HEAD", HttpRequest.BodyPublishers.noBody());
            else b.GET();
            if (o.userAgent != null) b.header("User-Agent", o.userAgent);
            if (!o.cookies.isEmpty()) b.header("Cookie", String.join("; ", o.cookies));
            for (String h : o.headers) {
                int c = h.indexOf(':');
                if (c >= 0) b.header(h.substring(0, c).trim(), h.substring(c + 1).trim());
                else if (h.endsWith(";")) b.header(h.substring(0, h.length() - 1), "");
            }
            if (o.username != null || o.password != null || userInfo(url) != null) {
                String up = (o.username != null ? o.username : "") + ":" + (o.password != null ? o.password : "");
                String ui = userInfo(url);
                if (ui != null) up = ui;
                b.header("Authorization", "Basic " + Base64.getEncoder().encodeToString(up.getBytes(StandardCharsets.UTF_8)));
            }
            HttpResponse<byte[]> resp = client.send(b.build(), HttpResponse.BodyHandlers.ofByteArray());
            Result r = new Result();
            r.url = stripUserInfo(url);
            r.code = resp.statusCode();
            r.size = resp.body() == null ? 0 : resp.body().length;
            Optional<String> cl = resp.headers().firstValue("content-length");
            if (cl.isPresent()) try { r.size = Integer.parseInt(cl.get()); } catch (NumberFormatException ignored) {}
            r.redirect = resp.headers().firstValue("location").map(x -> absolutize(url, x)).orElse("");
            r.dir = r.url.endsWith("/");
            String body = resp.body() == null ? "" : new String(resp.body(), StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
            r.listable = r.dir && r.code == 200 && (body.contains("index of") || body.contains("<title>index"));
            return r;
        } catch (Exception e) {
            if (!o.silent) System.err.println("Curl error after requesting " + stripUserInfo(url) + " : " + e.getMessage());
            return null;
        }
    }

    static boolean hide(Opt o, Result r, Set<Integer> nf) {
        if (!o.whitelist.isEmpty() && !o.whitelist.contains(r.code)) return true;
        if (o.blacklist.contains(r.code)) return true;
        if (!o.disableValidator && nf.contains(r.code)) return true;
        if (!o.showHtaccess && r.url.contains(".ht") && r.code == 403) return true;
        for (int[] range : o.hideLengths) if (r.size >= range[0] && r.size <= range[1]) return true;
        return false;
    }

    static void writeReports(Opt o, List<Result> all) throws IOException {
        if (o.outputAll != null) { o.outputFile = o.outputAll + ".txt"; o.jsonFile = o.outputAll + ".json"; o.xmlFile = o.outputAll + ".xml"; }
        if (o.outputFile != null) {
            StringBuilder sb = new StringBuilder();
            String target = o.uris.isEmpty() ? "" : o.uris.get(0);
            sb.append("Dirble Scan Report for ").append(ensureSlash(normalizeBase(target))).append(":\n");
            for (Result r : all) sb.append(r.line()).append("\n");
            Files.writeString(Paths.get(o.outputFile), sb.toString());
        }
        if (o.jsonFile != null) {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < all.size(); i++) {
                Result r = all.get(i);
                if (i > 0) sb.append(",\n");
                sb.append("{\"url\":\"").append(js(r.url)).append("\",\"code\":").append(r.code).append(",\"size\":").append(r.size)
                  .append(",\"is_directory\":").append(r.dir).append(",\"is_listable\":").append(r.listable)
                  .append(",\"redirect_url\":\"").append(js(r.redirect)).append("\",\"found_from_listable\":").append(r.fromListable).append("}");
            }
            sb.append("]");
            Files.writeString(Paths.get(o.jsonFile), sb.toString());
        }
        if (o.xmlFile != null) {
            StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<dirble_scan>\n");
            for (Result r : all) sb.append("<path url=\"").append(xml(r.url)).append("\" code=\"").append(r.code).append("\" content_len=\"").append(r.size)
              .append("\" is_directory=\"").append(r.dir).append("\" is_listable=\"").append(r.listable).append("\" redirect_url=\"").append(xml(r.redirect))
              .append("\" found_from_listable=\"").append(r.fromListable).append("\"/>\n");
            sb.append("</dirble_scan>");
            Files.writeString(Paths.get(o.xmlFile), sb.toString());
        }
    }

    static List<String> scrapeLinks(String base, HttpClient c, Opt o) {
        try {
            Opt oo = o; Result ignored;
            HttpRequest req = HttpRequest.newBuilder(URI.create(base)).timeout(Duration.ofSeconds(o.timeout)).GET().build();
            String body = c.send(req, HttpResponse.BodyHandlers.ofString()).body();
            Matcher m = Pattern.compile("(?i)href=[\"']?([^\"' >]+)").matcher(body);
            List<String> links = new ArrayList<>();
            while (m.find()) {
                String h = m.group(1);
                if (!h.startsWith("?") && !h.startsWith("#") && !h.equals("../")) links.add(absolutize(base, h));
            }
            return links;
        } catch (Exception e) { return List.of(); }
    }

    static String val(String[] a, int i, String opt) throws CliError { if (i >= a.length) throw new CliError("error: a value is required for '" + opt + "'"); return a[i]; }
    static int parseInt(String s, String opt) throws CliError { try { return Integer.parseInt(s); } catch(Exception e) { throw new CliError("error: invalid value '" + s + "' for '" + opt + "'"); } }
    static void addCsv(List<String> l, String s) { for (String p : s.split(",")) if (!p.isBlank()) l.add(p.trim()); }
    static void addCodes(Set<Integer> s, String v) { for (String p : v.split(",")) if (!p.isBlank()) try { s.add(Integer.parseInt(p.trim())); } catch(Exception ignored) {} }
    static void addLengths(List<int[]> l, String v) { for (String p : v.split(",")) { String[] x=p.split("-",2); try { int a=Integer.parseInt(x[0].trim()); int b=x.length>1?Integer.parseInt(x[1].trim()):a; l.add(new int[]{a,b}); } catch(Exception ignored){} } }
    static List<String> readLines(String f) throws IOException { return Files.readAllLines(Paths.get(f)); }
    static List<String> readLinesNoThrow(String f) { try { return readLines(f); } catch(Exception e) { return List.of(); } }
    static String normalizeBase(String u) { if (!u.matches("(?i)^[a-z][a-z0-9+.-]*://.*")) u = "http://" + u; return u.replaceAll("/+$", ""); }
    static String ensureSlash(String u) { return u.endsWith("/") ? u : u + "/"; }
    static String joinUrl(String b, String p) { while (p.startsWith("/")) p = p.substring(1); return ensureSlash(b) + p; }
    static String absolutize(String base, String loc) { try { return URI.create(base).resolve(loc).toString(); } catch(Exception e) { return loc; } }
    static String userInfo(String u) { try { return URI.create(u).getUserInfo(); } catch(Exception e) { return null; } }
    static String stripUserInfo(String u) { try { URI x=URI.create(u); if (x.getUserInfo()==null) return u; return new URI(x.getScheme(), null, x.getHost(), x.getPort(), x.getPath(), x.getQuery(), x.getFragment()).toString(); } catch(Exception e) { return u; } }
    static Path executableDir() { try { return Paths.get(Dirble.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getParent(); } catch(Exception e) { return Paths.get("."); } }
    static String js(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }
    static String xml(String s) { return s.replace("&","&amp;").replace("\"","&quot;").replace("<","&lt;").replace(">","&gt;"); }

    static void printHelp() {
        System.out.println("Fast directory scanning and scraping tool\n\nUsage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>\n\nArguments:\n  [uri]\n          The URI of the host to scan, optionally supports basic auth with\n          http://user:pass@host:port\n\nOptions:\n  -u, --uri <uri>\n          Additional hosts to scan [aliases: url]\n  -U, --uri-file <uri-file>\n          The filename of a file containing a list of URIs to scan - cookies and\n          headers set will be applied to all URIs [aliases: url-file]\n      --verb <http_verb>\n          Specify which HTTP verb to use\n           [default: get] [possible values: get, head, post]\n  -w, --wordlist <wordlist>\n          Sets which wordlist to use, defaults to dirble_wordlist.txt in the same\n          folder as the executable\n  -p, --prefixes <prefixes>...\n          Provides comma separated prefixes to extend queries with\n  -P, --prefix-file <prefix-file>\n          The name of a file containing extensions to extend queries with, one\n          per line\n  -x, --extensions <extensions>...\n          Provides comma separated extensions to extend queries with\n  -X, --extension-file <extension-file>\n          The name of a file containing extensions to extend queries with, one\n          per line\n      --ext-sub\n          Indicates whether the string \"%EXT%\" in a wordlist file should be \n          substituted with the current extension\n  -f, --force-extension\n          Only scan with provided extensions\n  -k, --ignore-cert\n          Ignore the certificate validity for HTTPS\n      --show-htaccess\n          Enable display of items containing .ht when they return 403 responses\n      --timeout <timeout>\n          Maximum time to wait for a response before giving up, given in seconds\n           [default: 5]\n      --max-errors <max_errors>\n          The number of consecutive errors a thread can have before it exits,\n          set to 0 to disable [default: 5]\n      --json-file <json_file>\n          Sets a file to write JSON output to [aliases: oJ]\n      --no-color\n          Disable coloring of terminal output\n  -o, --output-file <output_file>\n          Sets the file to write the report to [aliases: oN]\n      --xml-file <xml_file>\n          Sets a file to write XML output to [aliases: oX]\n      --hide-lengths <length_blacklist>...\n          Specify length ranges to hide, e.g. --hide-lengths 348,500-700\n      --output-all <output_all>\n          Stores all output types respectively as .txt, .json and .xml [aliases: oA]\n      --burp\n          Sets the proxy to use the default burp proxy values\n          (http://localhost:8080)\n      --no-proxy\n          Disables proxy use even if there is a system proxy\n      --proxy <proxy>\n          The proxy address to use, including type and port, can also include a\n          username and password in the form \n          \"http://username:password@proxy_url:proxy_port\"\n  -t, --max-threads <max-threads>\n          Sets the maximum number of request threads that will be spawned [default: 10]\n  -T, --wordlist-split <wordlist_split>\n          The number of threads to run for each folder/extension combo [default: 3]\n  -z, --throttle <milliseconds>\n          Time each thread will wait between requests, given in milliseconds\n      --username <username>\n          Sets the username to authenticate with\n      --password <password>\n          Sets the password to authenticate with\n  -l, --scan-listable\n          Scan listable directories\n      --max-recursion-depth <max_recursion_depth>\n          Sets the maximum directory depth to recurse to, 0 will disable\n          recursion\n  -r, --disable-recursion\n          Disable discovered subdirectory scanning\n      --scrape-listable\n          Enable scraping of listable directories for urls, often produces large\n          amounts of output\n  -a, --user-agent <user_agent>\n          Set the user-agent provided with requests, by default it isn't set\n  -c, --cookie <cookie>\n          Provide a cookie in the form \"name=value\", can be used multiple times\n  -H, --header <header>\n          Provide an arbitrary header in the form \"header:value\" - headers with\n          no value must end in a semicolon\n  -S, --silent\n          Don't output information during the scan, only output the report at\n          the end.\n  -v, --verbose...\n          Increase the verbosity level. Use twice for full verbosity.\n  -B, --code-blacklist <code_blacklist>...\n          Provide a comma separated list of response codes to not show in output\n      --disable-validator\n          Disable automatic detection of not found codes\n  -W, --code-whitelist <code_whitelist>...\n          Provide a comma separated list of response codes to show in output,\n          also disables detection of not found codes\n      --scan-401\n          Scan folders even if they return 401 - Unauthorized frequently\n      --scan-403\n          Scan folders if they return 403 - Forbidden frequently\n  -h, --help\n          Print help\n  -V, --version\n          Print version\n\nOUTPUT FORMAT:\n    + [url] - File\n    D [url] - Directory\n    L [url] - Listable Directory\n\nEXAMPLE USE:\n    - Run against a website using the default dirble_wordlist.txt from the\n      current directory:\n        dirble [address]\n\n    - Run with a different wordlist and including .php and .html extensions:\n        dirble [address] -w example_wordlist.txt -x .php,.html\n\n    - With listable directory scraping enabled:\n        dirble [address] --scrape-listable\n\n    - Providing a list of extensions and a list of URIs:\n        dirble [address] -X wordlists/web.lst -U uri-list.txt\n\n    - Providing multiple hosts to scan via command line:\n        dirble [address] -u [address] -u [address]");
    }
}
