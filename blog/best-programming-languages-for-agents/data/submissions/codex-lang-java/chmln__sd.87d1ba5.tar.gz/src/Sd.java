import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Sd {
    private static final String VERSION = "sd 1.0.0";

    static class Config {
        boolean preview = false;
        boolean fixed = false;
        int max = 0;
        String flags = "";
        String find;
        String replace;
        List<String> files = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Config cfg = parse(args);
            if (cfg == null) {
                return;
            }
            Pattern pattern = buildPattern(cfg);
            if (cfg.files.isEmpty()) {
                String input = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
                System.out.print(replaceAll(input, pattern, cfg));
            } else {
                boolean many = cfg.files.size() > 1;
                for (String file : cfg.files) {
                    Path p = Path.of(file);
                    String input = Files.readString(p, StandardCharsets.UTF_8);
                    String output = replaceAll(input, pattern, cfg);
                    if (cfg.preview) {
                        if (many) {
                            System.out.println("----- FILE " + file + " -----");
                        }
                        System.out.print(output);
                    } else {
                        Files.writeString(p, output, StandardCharsets.UTF_8);
                    }
                }
            }
        } catch (CliException e) {
            System.err.println(e.getMessage());
            System.exit(e.code);
        } catch (PatternSyntaxException e) {
            System.err.println("error: invalid regex " + e.getDescription());
            System.exit(1);
        } catch (IOException e) {
            System.err.println("error: " + e.getMessage());
            System.exit(1);
        }
    }

    private static Config parse(String[] args) throws CliException {
        Config cfg = new Config();
        List<String> positional = new ArrayList<>();
        boolean endOptions = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (!endOptions && a.equals("--")) {
                endOptions = true;
                continue;
            }
            if (!endOptions && a.startsWith("-") && !a.equals("-")) {
                if (a.startsWith("-") && !a.startsWith("--") && a.length() > 2) {
                    for (int j = 1; j < a.length(); j++) {
                        char opt = a.charAt(j);
                        if (opt == 'p') {
                            cfg.preview = true;
                        } else if (opt == 'F') {
                            cfg.fixed = true;
                        } else if (opt == 'n') {
                            String value = a.substring(j + 1);
                            if (value.isEmpty()) {
                                if (++i >= args.length) {
                                    throw new CliException("error: a value is required for '-n <LIMIT>' but none was supplied", 2);
                                }
                                value = args[i];
                            }
                            cfg.max = parseLimit(value);
                            break;
                        } else if (opt == 'f') {
                            String value = a.substring(j + 1);
                            if (value.isEmpty()) {
                                if (++i >= args.length) {
                                    throw new CliException("error: a value is required for '-f <FLAGS>' but none was supplied", 2);
                                }
                                value = args[i];
                            }
                            cfg.flags += value;
                            break;
                        } else if (opt == 'h') {
                            printShortHelp();
                            return null;
                        } else if (opt == 'V') {
                            System.out.println(VERSION);
                            return null;
                        } else {
                            throw new CliException("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.", 2);
                        }
                    }
                    continue;
                }
                switch (a) {
                    case "-h":
                        printShortHelp();
                        return null;
                    case "--help":
                        printLongHelp();
                        return null;
                    case "-V":
                    case "--version":
                        System.out.println(VERSION);
                        return null;
                    case "-p":
                    case "--preview":
                        cfg.preview = true;
                        break;
                    case "-F":
                    case "--fixed-strings":
                        cfg.fixed = true;
                        break;
                    case "-n":
                    case "--max-replacements":
                        if (++i >= args.length) {
                            throw new CliException("error: a value is required for '" + a + " <LIMIT>' but none was supplied", 2);
                        }
                        cfg.max = parseLimit(args[i]);
                        break;
                    case "-f":
                    case "--flags":
                        if (++i >= args.length) {
                            throw new CliException("error: a value is required for '" + a + " <FLAGS>' but none was supplied", 2);
                        }
                        cfg.flags += args[i];
                        break;
                    default:
                        if (a.startsWith("--max-replacements=")) {
                            cfg.max = parseLimit(a.substring(a.indexOf('=') + 1));
                        } else if (a.startsWith("--flags=")) {
                            cfg.flags += a.substring(a.indexOf('=') + 1);
                        } else {
                            throw new CliException("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.", 2);
                        }
                }
            } else {
                positional.add(a);
            }
        }
        if (positional.size() < 2) {
            String missing = positional.isEmpty() ? "  <FIND>\n  <REPLACE_WITH>" : "  <REPLACE_WITH>";
            throw new CliException("error: the following required arguments were not provided:\n" + missing + "\n\nUsage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.", 2);
        }
        cfg.find = positional.get(0);
        cfg.replace = positional.get(1);
        for (int i = 2; i < positional.size(); i++) {
            cfg.files.add(positional.get(i));
        }
        return cfg;
    }

    private static int parseLimit(String value) throws CliException {
        try {
            int n = Integer.parseInt(value);
            if (n < 0) {
                throw new NumberFormatException();
            }
            return n;
        } catch (NumberFormatException e) {
            throw new CliException("error: invalid value '" + value + "' for '--max-replacements <LIMIT>': invalid digit found in string\n\nFor more information, try '--help'.", 2);
        }
    }

    private static Pattern buildPattern(Config cfg) {
        boolean multiline = true;
        for (char c : cfg.flags.toCharArray()) {
            if (c == 'm') multiline = true;
            if (c == 'e') multiline = false;
        }
        if (!cfg.fixed) {
            validateRustRegexSubset(cfg.find);
        }
        String regex = cfg.fixed ? Pattern.quote(cfg.find) : translateRegex(cfg.find, multiline);
        if (!cfg.fixed && cfg.flags.indexOf('w') >= 0) {
            regex = "\\b(?:" + regex + ")\\b";
        }
        int flags = 0;
        for (char c : cfg.flags.toCharArray()) {
            if (c == 'i') flags |= Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
            if (c == 'c') flags &= ~(Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            if (c == 's') flags |= Pattern.DOTALL;
        }
        if (multiline) flags |= Pattern.MULTILINE;
        return Pattern.compile(regex, flags);
    }

    private static void validateRustRegexSubset(String regex) {
        boolean escaped = false;
        boolean inClass = false;
        for (int i = 0; i < regex.length(); i++) {
            char c = regex.charAt(i);
            if (escaped) {
                if (Character.isDigit(c) && c != '0') {
                    throw new PatternSyntaxException("backreferences are not supported", regex, i - 1);
                }
                escaped = false;
                continue;
            }
            if (c == '\\') {
                escaped = true;
                continue;
            }
            if (c == '[') {
                inClass = true;
            } else if (c == ']' && inClass) {
                inClass = false;
            } else if (!inClass && c == '(' && i + 2 < regex.length() && regex.charAt(i + 1) == '?') {
                char n = regex.charAt(i + 2);
                if (n == '=' || n == '!' || (n == '<' && i + 3 < regex.length() && (regex.charAt(i + 3) == '=' || regex.charAt(i + 3) == '!'))) {
                    throw new PatternSyntaxException("look-around, including look-ahead and look-behind, is not supported", regex, i);
                }
            }
        }
    }

    private static String translateRegex(String regex, boolean multiline) {
        String named = regex.replaceAll("\\(\\?P<([A-Za-z][A-Za-z0-9_]*)>", "(?<$1>");
        if (!multiline || named.indexOf('^') < 0) {
            return named;
        }
        StringBuilder out = new StringBuilder();
        boolean escaped = false;
        boolean inClass = false;
        for (int i = 0; i < named.length(); i++) {
            char c = named.charAt(i);
            if (escaped) {
                out.append(c);
                escaped = false;
                continue;
            }
            if (c == '\\') {
                out.append(c);
                escaped = true;
                continue;
            }
            if (c == '[') {
                inClass = true;
                out.append(c);
            } else if (c == ']' && inClass) {
                inClass = false;
                out.append(c);
            } else if (c == '^' && !inClass) {
                out.append("(?:^|(?<=\\n)\\z)");
            } else {
                out.append(c);
            }
        }
        return out.toString();
    }

    private static String replaceAll(String input, Pattern pattern, Config cfg) {
        Matcher m = pattern.matcher(input);
        StringBuffer out = new StringBuffer();
        int count = 0;
        Set<String> names = groupNames(pattern.pattern());
        while (m.find()) {
            if (cfg.max > 0 && count >= cfg.max) {
                break;
            }
            String repl = cfg.fixed ? cfg.replace : expandReplacement(cfg.replace, m, names);
            m.appendReplacement(out, Matcher.quoteReplacement(repl));
            count++;
        }
        m.appendTail(out);
        return out.toString();
    }

    private static Set<String> groupNames(String regex) {
        Set<String> names = new HashSet<>();
        Matcher m = Pattern.compile("\\(\\?<([A-Za-z][A-Za-z0-9_]*)>").matcher(regex);
        while (m.find()) {
            names.add(m.group(1));
        }
        return names;
    }

    private static String expandReplacement(String replacement, Matcher match, Set<String> names) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < replacement.length(); i++) {
            char c = replacement.charAt(i);
            if (c != '$') {
                out.append(c);
                continue;
            }
            if (i + 1 >= replacement.length()) {
                out.append('$');
                continue;
            }
            char n = replacement.charAt(i + 1);
            if (n == '$') {
                out.append('$');
                i++;
            } else if (n == '{') {
                int end = replacement.indexOf('}', i + 2);
                if (end < 0) {
                    out.append('$');
                } else {
                    String name = replacement.substring(i + 2, end);
                    out.append(groupValue(match, names, name));
                    i = end;
                }
            } else if (Character.isDigit(n)) {
                int j = i + 1;
                while (j < replacement.length() && Character.isDigit(replacement.charAt(j))) j++;
                String digits = replacement.substring(i + 1, j);
                out.append(groupValue(match, Integer.parseInt(digits)));
                i = j - 1;
            } else if (isNameStart(n)) {
                int j = i + 1;
                while (j < replacement.length() && isNamePart(replacement.charAt(j))) j++;
                String name = replacement.substring(i + 1, j);
                out.append(groupValue(match, names, name));
                i = j - 1;
            } else {
                out.append('$');
            }
        }
        return out.toString();
    }

    private static boolean isNameStart(char c) {
        return Character.isLetter(c) || c == '_';
    }

    private static boolean isNamePart(char c) {
        return Character.isLetterOrDigit(c) || c == '_';
    }

    private static String groupValue(Matcher m, int index) {
        try {
            if (index <= m.groupCount()) {
                String value = m.group(index);
                return value == null ? "" : value;
            }
        } catch (RuntimeException ignored) {
        }
        return "";
    }

    private static String groupValue(Matcher m, Set<String> names, String name) {
        if (!names.contains(name)) {
            return "";
        }
        try {
            String value = m.group(name);
            return value == null ? "" : value;
        } catch (RuntimeException e) {
            return "";
        }
    }

    private static void printShortHelp() {
        System.out.println("sd v1.0.0");
        System.out.println("An intuitive find & replace CLI");
        System.out.println();
        System.out.println("Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -p, --preview                   Display changes in a human reviewable format");
        System.out.println("  -F, --fixed-strings             Treat FIND and REPLACE_WITH args as literal strings");
        System.out.println("  -n, --max-replacements <LIMIT>  Limit replacements per file [default: 0]");
        System.out.println("  -f, --flags <FLAGS>             Regex flags");
        System.out.println("  -h, --help                      Print help");
        System.out.println("  -V, --version                   Print version");
    }

    private static void printLongHelp() {
        System.out.println("sd v1.0.0");
        System.out.println("An intuitive find & replace CLI");
        System.out.println();
        System.out.println("Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...");
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  <FIND>");
        System.out.println("          The regexp or string (if using `-F`) to search for");
        System.out.println();
        System.out.println("  <REPLACE_WITH>");
        System.out.println("          What to replace each match with. Unless in string mode, you may use captured values like");
        System.out.println("          $1, $2, etc");
        System.out.println();
        System.out.println("  [FILES]...");
        System.out.println("          The path to file(s). This is optional - sd can also read from STDIN.");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -p, --preview");
        System.out.println("          Display changes in a human reviewable format (the specifics of the format are likely to");
        System.out.println("          change in the future)");
        System.out.println();
        System.out.println("  -F, --fixed-strings");
        System.out.println("          Treat FIND and REPLACE_WITH args as literal strings");
        System.out.println();
        System.out.println("  -n, --max-replacements <LIMIT>");
        System.out.println("          Limit the number of replacements that can occur per file. 0 indicates unlimited");
        System.out.println("          replacements");
        System.out.println();
        System.out.println("          [default: 0]");
        System.out.println();
        System.out.println("  -f, --flags <FLAGS>");
        System.out.println("          Regex flags. May be combined (like `-f mc`).");
        System.out.println();
        System.out.println("          c - case-sensitive");
        System.out.println();
        System.out.println("          e - disable multi-line matching");
        System.out.println();
        System.out.println("          i - case-insensitive");
        System.out.println();
        System.out.println("          m - multi-line matching");
        System.out.println();
        System.out.println("          s - make `.` match newlines");
        System.out.println();
        System.out.println("          w - match full words only");
        System.out.println();
        System.out.println("  -h, --help");
        System.out.println("          Print help (see a summary with '-h')");
        System.out.println();
        System.out.println("  -V, --version");
        System.out.println("          Print version");
    }

    static class CliException extends Exception {
        final int code;
        CliException(String message, int code) {
            super(message);
            this.code = code;
        }
    }
}
