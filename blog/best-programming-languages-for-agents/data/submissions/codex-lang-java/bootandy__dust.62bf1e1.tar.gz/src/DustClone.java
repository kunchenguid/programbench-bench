import java.io.BufferedInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class DustClone {
    static class Opt {
        int depth = Integer.MAX_VALUE;
        int lines = 0;
        boolean fullPaths, apparent, reverse, noBars, barsRight, screenReader;
        boolean skipTotal, fileCount, ignoreHidden, onlyDir, onlyFile, json;
        boolean dereference, printErrors, fileTypes;
        String output = "default";
        long minSize = Long.MIN_VALUE;
        Character fileTimeMode = null;
        final List<String> paths = new ArrayList<>();
        final Set<String> ignores = new HashSet<>();
        final List<Pattern> exclude = new ArrayList<>();
        final List<Pattern> include = new ArrayList<>();
        final List<String> collapse = new ArrayList<>();
    }

    static class Node {
        Path path;
        String name;
        boolean dir;
        long size;
        int files;
        long time;
        int depth;
        final List<Node> children = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Opt opt = parse(args);
            if (opt == null) return;
            if (opt.paths.isEmpty()) opt.paths.add(".");
            List<Node> roots = new ArrayList<>();
            for (String p : opt.paths) {
                Path path = Paths.get(p);
                if (!Files.exists(path, opt.dereference ? new LinkOption[]{} : new LinkOption[]{LinkOption.NOFOLLOW_LINKS})) {
                    System.err.println("\r \rNo such file or directory: " + p);
                    System.exit(1);
                }
                Node n = scan(path, opt, 0);
                if (n != null) roots.add(n);
            }
            if (opt.fileTypes) {
                roots = groupTypes(roots);
            }
            if (opt.json) {
                if (roots.size() == 1) System.out.println("\r \r" + toJson(roots.get(0), opt));
                else {
                    System.out.print("\r \r[");
                    for (int i = 0; i < roots.size(); i++) {
                        if (i > 0) System.out.print(",");
                        System.out.print(toJson(roots.get(i), opt));
                    }
                    System.out.println("]");
                }
                return;
            }
            print(roots, opt);
        } catch (IllegalArgumentException ex) {
            System.err.println("error: " + ex.getMessage());
            System.err.println();
            System.err.println("Usage: executable [OPTIONS] [PATH]...");
            System.err.println();
            System.err.println("For more information, try '--help'.");
            System.exit(2);
        } catch (Exception ex) {
            System.err.println(ex.getMessage() == null ? ex.toString() : ex.getMessage());
            System.exit(1);
        }
    }

    static Opt parse(String[] args) throws IOException {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) {
                while (++i < args.length) o.paths.add(args[i]);
                break;
            }
            if (a.equals("-h") || a.equals("--help")) {
                help(a.equals("--help"));
                return null;
            }
            if (a.equals("-V") || a.equals("--version")) {
                System.out.println("Dust 1.2.3");
                return null;
            }
            if (!a.startsWith("-") || a.equals("-")) {
                o.paths.add(a);
                continue;
            }
            String val = null;
            String key = a;
            int eq = a.indexOf('=');
            if (eq > 0) {
                key = a.substring(0, eq);
                val = a.substring(eq + 1);
            }
            switch (key) {
                case "-d": case "--depth": o.depth = Integer.parseInt(value(args, ++i, val, key)); break;
                case "-T": case "--threads": case "-S": case "--stack-size": value(args, ++i, val, key); break;
                case "--config": applyConfig(o, Paths.get(value(args, ++i, val, key))); break;
                case "-n": case "--number-of-lines": o.lines = Integer.parseInt(value(args, ++i, val, key)); break;
                case "-p": case "--full-paths": o.fullPaths = true; break;
                case "-X": case "--ignore-directory": o.ignores.add(value(args, ++i, val, key)); break;
                case "-I": case "--ignore-all-in-file":
                    for (String line : Files.readAllLines(Paths.get(value(args, ++i, val, key)))) if (!line.isEmpty()) o.exclude.add(Pattern.compile(line));
                    break;
                case "-L": case "--dereference-links": o.dereference = true; break;
                case "-x": case "--limit-filesystem": break;
                case "-s": case "--apparent-size": o.apparent = true; break;
                case "-r": case "--reverse": o.reverse = true; break;
                case "-c": case "--no-colors": case "-C": case "--force-colors": case "-P": case "--no-progress": break;
                case "-b": case "--no-percent-bars": o.noBars = true; break;
                case "-B": case "--bars-on-right": o.barsRight = true; break;
                case "-z": case "--min-size": o.minSize = parseSize(value(args, ++i, val, key)); break;
                case "-R": case "--screen-reader": o.screenReader = true; o.noBars = true; break;
                case "--skip-total": o.skipTotal = true; break;
                case "-f": case "--filecount": o.fileCount = true; break;
                case "-i": case "--ignore-hidden": o.ignoreHidden = true; break;
                case "-v": case "--invert-filter": o.exclude.add(Pattern.compile(value(args, ++i, val, key))); break;
                case "-e": case "--filter": o.include.add(Pattern.compile(value(args, ++i, val, key))); break;
                case "-t": case "--file-types": o.fileTypes = true; break;
                case "-w": case "--terminal-width": value(args, ++i, val, key); break;
                case "--print-errors": o.printErrors = true; break;
                case "-D": case "--only-dir": o.onlyDir = true; break;
                case "-F": case "--only-file": o.onlyFile = true; break;
                case "-o": case "--output-format": o.output = value(args, ++i, val, key).toLowerCase(Locale.ROOT); break;
                case "-j": case "--output-json": o.json = true; break;
                case "-M": case "--mtime": case "-A": case "--atime": case "-y": case "--ctime": value(args, ++i, val, key); break;
                case "-m": case "--filetime": o.fileTimeMode = value(args, ++i, val, key).charAt(0); break;
                case "--files-from": readPathFile(o, value(args, ++i, val, key), false); break;
                case "--files0-from": readPathFile(o, value(args, ++i, val, key), true); break;
                case "--collapse": o.collapse.add(value(args, ++i, val, key)); break;
                default:
                    if (a.startsWith("-") && a.length() > 2 && !a.startsWith("--")) {
                        String rest = a.substring(1);
                        for (char ch : rest.toCharArray()) {
                            switch (ch) {
                                case 'p': o.fullPaths = true; break;
                                case 's': o.apparent = true; break;
                                case 'r': o.reverse = true; break;
                                case 'c': case 'C': case 'P': break;
                                case 'b': o.noBars = true; break;
                                case 'B': o.barsRight = true; break;
                                case 'R': o.screenReader = true; o.noBars = true; break;
                                case 'f': o.fileCount = true; break;
                                case 'i': o.ignoreHidden = true; break;
                                case 't': o.fileTypes = true; break;
                                case 'D': o.onlyDir = true; break;
                                case 'F': o.onlyFile = true; break;
                                case 'j': o.json = true; break;
                                default: throw new IllegalArgumentException("unexpected argument '-" + ch + "' found");
                            }
                        }
                    } else {
                        throw new IllegalArgumentException("unexpected argument '" + a + "' found");
                    }
            }
        }
        return o;
    }

    static String value(String[] args, int idx, String val, String opt) {
        if (val != null) return val;
        if (idx >= args.length) throw new IllegalArgumentException("a value is required for '" + opt + "'");
        return args[idx];
    }

    static void readPathFile(Opt o, String file, boolean nul) throws IOException {
        byte[] data;
        if (file.equals("-")) data = new BufferedInputStream(System.in).readAllBytes();
        else data = Files.readAllBytes(Paths.get(file));
        String s = new String(data, StandardCharsets.UTF_8);
        if (nul) {
            for (String p : s.split("\0", -1)) if (!p.isEmpty()) o.paths.add(p);
        } else {
            for (String p : s.split("\\R")) if (!p.isEmpty()) o.paths.add(p);
        }
    }

    static void applyConfig(Opt o, Path file) throws IOException {
        for (String raw : Files.readAllLines(file)) {
            String line = raw.split("#", 2)[0].trim();
            if (line.isEmpty() || !line.contains("=")) continue;
            String[] parts = line.split("=", 2);
            String key = parts[0].trim();
            String value = parts[1].trim().replaceAll("^\"|\"$", "");
            boolean b = value.equalsIgnoreCase("true");
            switch (key) {
                case "reverse": o.reverse = b; break;
                case "display-full-paths": case "full-paths": o.fullPaths = b; break;
                case "display-apparent-size": case "apparent-size": o.apparent = b; break;
                case "no-colors": break;
                case "no-bars": case "no-percent-bars": o.noBars = b; break;
                case "skip-total": o.skipTotal = b; break;
                case "ignore-hidden": o.ignoreHidden = b; break;
                case "output-format": o.output = value.toLowerCase(Locale.ROOT); break;
                case "number-of-lines": o.lines = Integer.parseInt(value.trim()); break;
                case "depth": o.depth = Integer.parseInt(value.trim()); break;
            }
        }
    }

    static Node scan(Path path, Opt opt, int depth) {
        try {
            String base = path.getFileName() == null ? path.toString() : path.getFileName().toString();
            if (opt.ignoreHidden && base.startsWith(".") && depth > 0) return null;
            if (opt.ignores.contains(base) || opt.ignores.contains(path.toString())) return null;
            String sp = path.toString();
            for (Pattern p : opt.exclude) if (p.matcher(sp).find()) return null;
            if (!opt.include.isEmpty()) {
                boolean ok = false;
                for (Pattern p : opt.include) if (p.matcher(sp).find()) { ok = true; break; }
                if (!ok && !Files.isDirectory(path, linkOpts(opt))) return null;
            }
            BasicFileAttributes at = Files.readAttributes(path, BasicFileAttributes.class, linkOpts(opt));
            Node n = new Node();
            n.path = path;
            n.name = nameFor(path, opt);
            n.dir = at.isDirectory();
            n.depth = depth;
            n.time = at.lastModifiedTime().toMillis();
            long own = opt.apparent ? at.size() : blocks(path, at);
            if (n.dir) {
                n.size = own;
                if (!isCollapsed(path, opt)) {
                    try (var ds = Files.list(path)) {
                        List<Path> kids = ds.sorted(Comparator.comparing(p -> p.getFileName().toString())).toList();
                        for (Path c : kids) {
                            Node child = scan(c, opt, depth + 1);
                            if (child != null) {
                                n.children.add(child);
                                n.size += child.size;
                                n.files += child.dir ? child.files : 1;
                                n.time = Math.max(n.time, child.time);
                            }
                        }
                    }
                }
            } else {
                n.size = own;
                n.files = 1;
            }
            if (opt.fileTimeMode != null) n.size = n.time / 1000;
            if (opt.fileCount) n.size = n.files;
            if (opt.minSize != Long.MIN_VALUE && n.size < opt.minSize && depth > 0) return null;
            n.children.sort(Comparator.comparingLong((Node c) -> c.size).thenComparing(c -> c.name));
            return n;
        } catch (IOException | RuntimeException ex) {
            if (opt.printErrors) System.err.println(path + ": " + ex.getMessage());
            return null;
        }
    }

    static LinkOption[] linkOpts(Opt opt) {
        return opt.dereference ? new LinkOption[]{} : new LinkOption[]{LinkOption.NOFOLLOW_LINKS};
    }

    static boolean isCollapsed(Path p, Opt opt) {
        String n = p.getFileName() == null ? p.toString() : p.getFileName().toString();
        return opt.collapse.contains(n) || opt.collapse.contains(p.toString());
    }

    static long blocks(Path p, BasicFileAttributes at) {
        if (at.isSymbolicLink() || Files.isSymbolicLink(p)) return 0;
        try {
            Object b = Files.getAttribute(p, "unix:blocks", LinkOption.NOFOLLOW_LINKS);
            if (b instanceof Number) return ((Number) b).longValue() * 512L;
        } catch (Exception ignored) {}
        if (at.isDirectory()) return 4096;
        long s = at.size();
        if (s == 0) return 0;
        return ((s + 4095) / 4096) * 4096;
    }

    static String nameFor(Path p, Opt opt) {
        if (opt.fullPaths) return p.toString();
        Path fn = p.getFileName();
        return fn == null ? p.toString() : fn.toString();
    }

    static void print(List<Node> roots, Opt opt) {
        List<Node> rows = new ArrayList<>();
        for (Node r : roots) collectRows(r, rows, opt);
        if (opt.skipTotal && !rows.isEmpty()) rows.remove(rows.size() - 1);
        if (opt.lines > 0 && rows.size() > opt.lines) rows = new ArrayList<>(rows.subList(rows.size() - opt.lines, rows.size()));
        long total = roots.stream().mapToLong(r -> r.size).max().orElse(0);
        int width = rows.stream().mapToInt(n -> formatSize(n.size, opt).length()).max().orElse(1);
        if (opt.reverse) {
            rows.clear();
            for (Node r : roots) collectPre(r, rows, opt);
            if (opt.skipTotal && !rows.isEmpty()) rows.remove(0);
            if (opt.lines > 0 && rows.size() > opt.lines) rows = new ArrayList<>(rows.subList(0, opt.lines));
        }
        for (Node n : rows) {
            if (opt.screenReader) {
                System.out.printf("%-" + pathWidth(rows, opt) + "s %2d %" + width + "s", n.name, n.depth, formatSize(n.size, opt));
                System.out.print(" " + pct(n.size, total));
                System.out.println();
                continue;
            }
            String size = String.format("%" + width + "s", formatSize(n.size, opt));
            String tree = tree(n, opt);
            if (opt.noBars) {
                System.out.println(size + " " + tree);
            } else if (opt.barsRight) {
                System.out.println(size + " " + tree + " " + pct(n.size, total) + " " + bar(n.size, total, 20));
            } else {
                System.out.printf("%s %-20s │%-50s│ %4s%n", size, tree, bar(n.size, total, 50), pct(n.size, total));
            }
        }
    }

    static int pathWidth(List<Node> rows, Opt opt) {
        return rows.stream().mapToInt(n -> n.name.length()).max().orElse(1);
    }

    static void collectRows(Node n, List<Node> out, Opt opt) {
        if (opt.reverse) { collectPre(n, out, opt); return; }
        for (Node c : n.children) collectRows(c, out, opt);
        if (show(n, opt)) out.add(n);
    }

    static void collectPre(Node n, List<Node> out, Opt opt) {
        if (show(n, opt)) out.add(n);
        List<Node> kids = new ArrayList<>(n.children);
        kids.sort(Comparator.comparingLong((Node c) -> c.size).reversed().thenComparing(c -> c.name));
        for (Node c : kids) collectPre(c, out, opt);
    }

    static boolean show(Node n, Opt opt) {
        if (opt.onlyDir && !n.dir) return false;
        if (opt.onlyFile && n.dir && n.depth > 0 && !n.children.isEmpty()) return false;
        return n.depth <= opt.depth || n.children.isEmpty();
    }

    static String tree(Node n, Opt opt) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n.depth; i++) sb.append("  ");
        boolean hasKids = !n.children.isEmpty();
        if (opt.reverse) sb.append(n.depth == 0 ? (hasKids ? "└─┬ " : "└── ") : (hasKids ? "├─┬ " : "├── "));
        else sb.append(n.depth == 0 ? "┌─┴ " : (hasKids ? "├─┴ " : "┌── "));
        sb.append(n.name);
        return sb.toString();
    }

    static String pct(long size, long total) {
        long p = total <= 0 ? 0 : Math.round((size * 100.0) / total);
        return String.format("%3d%%", p);
    }

    static String bar(long size, long total, int w) {
        int n = total <= 0 ? 0 : (int)Math.round((size * 1.0 / total) * w);
        if (n < 0) n = 0;
        if (n > w) n = w;
        return "█".repeat(n) + "░".repeat(Math.max(0, w - n));
    }

    static String formatSize(long s, Opt opt) {
        if (opt.fileCount) return Long.toString(s);
        String f = opt.output;
        if (f.equals("b")) return s + "B";
        long base = (f.equals("si") || f.endsWith("b")) ? 1000 : 1024;
        switch (f) {
            case "k": return (s / 1024) + "K";
            case "m": return (s / (1024 * 1024)) + "M";
            case "g": return (s / (1024L * 1024 * 1024)) + "G";
            case "t": return (s / (1024L * 1024 * 1024 * 1024)) + "T";
            case "kb": return (s / 1000) + "K";
            case "mb": return (s / (1000 * 1000)) + "M";
            case "gb": return (s / (1000L * 1000 * 1000)) + "G";
            case "tb": return (s / (1000L * 1000 * 1000 * 1000)) + "T";
            case "si": return human(s, 1000, new String[]{"B","K","M","G","T"});
            default: return human(s, 1024, new String[]{"B","K","M","G","T"});
        }
    }

    static String human(long s, long base, String[] units) {
        double v = s;
        int u = 0;
        while (Math.abs(v) >= base && u < units.length - 1) { v /= base; u++; }
        if (u == 0) return s + units[u];
        if (v < 10) return String.format(Locale.ROOT, "%.1f%s", v, units[u]);
        return String.format(Locale.ROOT, "%.0f%s", v, units[u]);
    }

    static long parseSize(String raw) {
        String s = raw.trim().toLowerCase(Locale.ROOT);
        long mult = 1;
        if (s.endsWith("kib")) { mult = 1024; s = s.substring(0, s.length() - 3); }
        else if (s.endsWith("mib")) { mult = 1024L * 1024; s = s.substring(0, s.length() - 3); }
        else if (s.endsWith("gib")) { mult = 1024L * 1024 * 1024; s = s.substring(0, s.length() - 3); }
        else if (s.endsWith("kb") || s.endsWith("k")) { mult = 1000; s = s.replaceAll("kb?$", ""); }
        else if (s.endsWith("mb") || s.endsWith("m")) { mult = 1000L * 1000; s = s.replaceAll("mb?$", ""); }
        else if (s.endsWith("gb") || s.endsWith("g")) { mult = 1000L * 1000 * 1000; s = s.replaceAll("gb?$", ""); }
        return (long)(Double.parseDouble(s) * mult);
    }

    static String toJson(Node n, Opt opt) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"size\":\"").append(escape(formatSize(n.size, opt))).append("\",\"name\":\"").append(escape(n.path.toString())).append("\",\"children\":[");
        List<Node> kids = new ArrayList<>(n.children);
        kids.sort(Comparator.comparingLong((Node c) -> c.size).reversed().thenComparing(c -> c.name));
        for (int i = 0; i < kids.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(toJson(kids.get(i), opt));
        }
        sb.append("]}");
        return sb.toString();
    }

    static String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    static List<Node> groupTypes(List<Node> roots) {
        java.util.Map<String, Node> map = new java.util.HashMap<>();
        for (Node r : roots) gatherTypes(r, map);
        Node root = new Node();
        root.name = "(total)";
        root.path = Paths.get("(total)");
        root.dir = true;
        root.children.addAll(map.values());
        root.children.sort(Comparator.comparingLong((Node n) -> n.size).thenComparing(n -> n.name));
        for (Node n : root.children) { root.size += n.size; root.files += n.files; }
        return List.of(root);
    }

    static void gatherTypes(Node n, java.util.Map<String, Node> map) {
        if (!n.dir) {
            String name = n.path.getFileName() == null ? n.path.toString() : n.path.getFileName().toString();
            int i = name.lastIndexOf('.');
            String ext = i >= 0 ? name.substring(i) : "(no extension)";
            Node g = map.computeIfAbsent(ext, k -> { Node x = new Node(); x.name = k; x.path = Paths.get(k); return x; });
            g.size += n.size; g.files++;
        }
        for (Node c : n.children) gatherTypes(c, map);
    }

    static void help(boolean longHelp) {
        System.out.println("Like du but more intuitive");
        System.out.println();
        System.out.println("Usage: executable [OPTIONS] [PATH]...");
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  [PATH]...  Input files or directories");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -d, --depth <DEPTH>              Depth to show");
        System.out.println("  -T, --threads <THREADS>          Number of threads to use");
        System.out.println("      --config <FILE>              Specify a config file to use");
        System.out.println("  -n, --number-of-lines <NUMBER>   Number of lines of output to show. (Default is terminal_height - 10)");
        System.out.println("  -p, --full-paths                 Subdirectories will not have their path shortened");
        System.out.println("  -X, --ignore-directory <PATH>    Exclude any file or directory with this path");
        System.out.println("  -I, --ignore-all-in-file <FILE>  Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter");
        System.out.println("  -L, --dereference-links          dereference sym links - Treat sym links as directories and go into them");
        System.out.println("  -x, --limit-filesystem           Only count the files and directories on the same filesystem as the supplied directory");
        System.out.println("  -s, --apparent-size              Use file length instead of blocks");
        System.out.println("  -r, --reverse                    Print tree upside down (biggest highest)");
        System.out.println("  -c, --no-colors                  No colors will be printed (Useful for commands like: watch)");
        System.out.println("  -C, --force-colors               Force colors print");
        System.out.println("  -b, --no-percent-bars            No percent bars or percentages will be displayed");
        System.out.println("  -B, --bars-on-right              percent bars moved to right side of screen");
        System.out.println("  -z, --min-size <MIN_SIZE>        Minimum size file to include in output");
        System.out.println("  -R, --screen-reader              For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)");
        System.out.println("      --skip-total                 No total row will be displayed");
        System.out.println("  -f, --filecount                  Directory 'size' is number of child files instead of disk size");
        System.out.println("  -i, --ignore-hidden              Do not display hidden files");
        System.out.println("  -v, --invert-filter <REGEX>      Exclude filepaths matching this regex. To ignore png files type: -v \"\\.png$\"");
        System.out.println("  -e, --filter <REGEX>             Only include filepaths matching this regex. For png files type: -e \"\\.png$\"");
        System.out.println("  -t, --file-types                 show only these file types");
        System.out.println("  -w, --terminal-width <WIDTH>     Specify width of output overriding the auto detection of terminal width");
        System.out.println("  -P, --no-progress                Disable the progress indication");
        System.out.println("      --print-errors               Print path with errors");
        System.out.println("  -D, --only-dir                   Only directories will be displayed");
        System.out.println("  -F, --only-file                  Only files will be displayed. (Finds your largest files)");
        System.out.println("  -o, --output-format <FORMAT>     Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size [possible values: si, b, k, m, g, t, kb, mb, gb, tb]");
        System.out.println("  -S, --stack-size <STACK_SIZE>    Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)");
        System.out.println("  -j, --output-json                Output the directory tree as json to the current directory");
        System.out.println("  -M, --mtime <MTIME>              +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (-infinity, curr-(n+1)), n => [curr-(n+1), curr-n), and -n => (curr-n, +infinity)");
        System.out.println("  -A, --atime <ATIME>              just like -mtime, but based on file access time");
        System.out.println("  -y, --ctime <CTIME>              just like -mtime, but based on file change time");
        System.out.println("      --files0-from <FILES0_FROM>  Read NUL-terminated paths from FILE (use `-` for stdin)");
        System.out.println("      --files-from <FILES_FROM>    Read newline-terminated paths from FILE (use `-` for stdin)");
        System.out.println("      --collapse <COLLAPSE>        Keep these directories collapsed");
        System.out.println("  -m, --filetime <FILETIME>        Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time [possible values: a, c, m]");
        System.out.println("  -h, --help                       Print help (see more with '--help')");
        System.out.println("  -V, --version                    Print version");
    }
}
