package com.programbench.caesiumclone;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class Main {
    private static final String HELP_LONG = """
A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...
          Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality

      --lossless
          Use lossless compression (may increase file size for some formats)

      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)

      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)

      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)

      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image

      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image

      --no-upscale
          Prevents upscaling of the image when resizing

  -o, --output <OUTPUT>
          Output directory path

      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)

      --format <FORMAT>
          Convert to the selected output format or keep the original
          
          [default: original]
          [possible values: jpeg, png, gif, webp, tiff, original]

      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression
          
          [default: 3]

      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files
          
          [default: auto]
          [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]

      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)

      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)

  -e, --exif
          Keep EXIF metadata during compression

      --keep-dates
          Preserve original file timestamps

      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag

      --suffix <SUFFIX>
          Add suffix to output filenames

  -R, --recursive
          Scan subfolders recursively when input is a directory

  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)

  -d, --dry-run
          Simulate compression without writing files

      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors)
          
          [default: 0]

  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files

          Possible values:
          - all:    Always overwrite existing files
          - never:  Never overwrite existing files
          - bigger: Overwrite only if the existing file is bigger
          
          [default: all]

      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes

  -Q, --quiet
          Suppress all output

      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all
          
          [default: 1]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
""";

    private static final String HELP_SHORT = """
A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...  Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality
      --lossless
          Use lossless compression (may increase file size for some formats)
      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)
      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)
      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)
      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image
      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image
      --no-upscale
          Prevents upscaling of the image when resizing
  -o, --output <OUTPUT>
          Output directory path
      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)
      --format <FORMAT>
          Convert to the selected output format or keep the original [default: original] [possible values: jpeg, png, gif, webp, tiff, original]
      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression [default: 3]
      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files [default: auto] [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]
      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)
      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)
  -e, --exif
          Keep EXIF metadata during compression
      --keep-dates
          Preserve original file timestamps
      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag
      --suffix <SUFFIX>
          Add suffix to output filenames
  -R, --recursive
          Scan subfolders recursively when input is a directory
  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)
  -d, --dry-run
          Simulate compression without writing files
      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors) [default: 0]
  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files [default: all] [possible values: all, never, bigger]
      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes
  -Q, --quiet
          Suppress all output
      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all [default: 1]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
""";

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        try {
            Config cfg = parse(args);
            if (cfg.helpLong) {
                System.out.print(HELP_LONG);
                return;
            }
            if (cfg.helpShort) {
                System.out.print(HELP_SHORT);
                return;
            }
            if (cfg.version) {
                System.out.println("caesiumclt 1.3.0");
                return;
            }
            validate(cfg);
            run(cfg);
        } catch (CliException e) {
            System.err.println(e.getMessage());
            System.exit(2);
        } catch (Exception e) {
            System.err.println("error: " + e.getMessage());
            System.exit(1);
        }
    }

    private static Config parse(String[] args) throws CliException {
        Config c = new Config();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "--help" -> c.helpLong = true;
                case "-h" -> c.helpShort = true;
                case "-V", "--version" -> c.version = true;
                case "-q", "--quality" -> {
                    String v = value(args, ++i, a);
                    c.quality = parseInt(v, "quality");
                    if (c.quality < 0 || c.quality > 100) {
                        throw new CliException("error: invalid value '" + v + "' for '--quality <QUALITY>': Quality must be between 0 and 100, but got " + v + "\n\nFor more information, try '--help'.");
                    }
                }
                case "--lossless" -> c.lossless = true;
                case "--max-size" -> {
                    String v = value(args, ++i, a);
                    c.maxSize = parseSize(v, "--max-size <MAX_SIZE>");
                }
                case "--width" -> c.width = positiveInt(value(args, ++i, a), "--width <WIDTH>");
                case "--height" -> c.height = positiveInt(value(args, ++i, a), "--height <HEIGHT>");
                case "--long-edge" -> c.longEdge = positiveInt(value(args, ++i, a), "--long-edge <LONG_EDGE>");
                case "--short-edge" -> c.shortEdge = positiveInt(value(args, ++i, a), "--short-edge <SHORT_EDGE>");
                case "--no-upscale" -> c.noUpscale = true;
                case "-o", "--output" -> c.output = Path.of(value(args, ++i, a));
                case "--same-folder-as-input" -> c.sameFolder = true;
                case "--format" -> {
                    c.format = value(args, ++i, a).toLowerCase(Locale.ROOT);
                    if (!List.of("jpeg", "png", "gif", "webp", "tiff", "original").contains(c.format)) {
                        throw new CliException("error: invalid value '" + c.format + "' for '--format <FORMAT>'\n  [possible values: jpeg, png, gif, webp, tiff, original]\n\nFor more information, try '--help'.");
                    }
                }
                case "--png-opt-level" -> {
                    String v = value(args, ++i, a);
                    c.pngOpt = parseInt(v, "png");
                    if (c.pngOpt < 0 || c.pngOpt > 6) {
                        throw new CliException("error: invalid value '" + v + "' for '--png-opt-level <PNG_OPT_LEVEL>': PNG optimization level must be between 0 and 6, but got " + v + "\n\nFor more information, try '--help'.");
                    }
                }
                case "--jpeg-chroma-subsampling" -> {
                    c.chroma = value(args, ++i, a);
                    if (!List.of("4:4:4", "4:2:2", "4:2:0", "4:1:1", "auto").contains(c.chroma)) {
                        throw new CliException("error: invalid value '" + c.chroma + "' for '--jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>'\n  [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]\n\nFor more information, try '--help'.");
                    }
                }
                case "--jpeg-baseline" -> c.jpegBaseline = true;
                case "--zopfli" -> c.zopfli = true;
                case "-e", "--exif" -> c.exif = true;
                case "--keep-dates" -> c.keepDates = true;
                case "--strip-icc" -> c.stripIcc = true;
                case "--suffix" -> c.suffix = value(args, ++i, a);
                case "-R", "--recursive" -> c.recursive = true;
                case "-S", "--keep-structure" -> c.keepStructure = true;
                case "-d", "--dry-run" -> c.dryRun = true;
                case "--threads" -> c.threads = nonNegativeInt(value(args, ++i, a), "--threads <THREADS>");
                case "-O", "--overwrite" -> {
                    c.overwrite = value(args, ++i, a);
                    if (!List.of("all", "never", "bigger").contains(c.overwrite)) {
                        throw new CliException("error: invalid value '" + c.overwrite + "' for '--overwrite <OVERWRITE>'\n  [possible values: all, never, bigger]\n\nFor more information, try '--help'.");
                    }
                }
                case "--min-savings" -> c.minSavings = parseSavings(value(args, ++i, a));
                case "-Q", "--quiet" -> c.quiet = true;
                case "--verbose" -> c.verbose = nonNegativeInt(value(args, ++i, a), "--verbose <VERBOSE>");
                default -> {
                    if (a.startsWith("-")) {
                        throw new CliException("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n\nFor more information, try '--help'.");
                    }
                    c.inputs.add(Path.of(a));
                }
            }
        }
        if (c.quiet) c.verbose = 0;
        return c;
    }

    private static void validate(Config c) throws CliException {
        int modes = (c.quality != null ? 1 : 0) + (c.lossless ? 1 : 0) + (c.maxSize != null ? 1 : 0);
        if (modes == 0) missing("<--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>", c);
        if (modes > 1) {
            String first = c.quality != null ? "--quality <QUALITY>" : c.maxSize != null ? "--max-size <MAX_SIZE>" : "--lossless";
            String second = c.lossless && !first.equals("--lossless") ? "--lossless" : c.maxSize != null && !first.startsWith("--max-size") ? "--max-size <MAX_SIZE>" : "--quality <QUALITY>";
            throw new CliException("error: the argument '" + first + "' cannot be used with '" + second + "'\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...\n\nFor more information, try '--help'.");
        }
        if (c.output == null && !c.sameFolder) missing("<--output <OUTPUT>|--same-folder-as-input>", c);
        if (c.output != null && c.sameFolder) {
            throw new CliException("error: the argument '--output <OUTPUT>' cannot be used with '--same-folder-as-input'\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...\n\nFor more information, try '--help'.");
        }
        if (c.keepStructure && !c.recursive) {
            throw new CliException("error: the following required argument was not provided: --recursive\n\nFor more information, try '--help'.");
        }
        if (c.width != null && c.longEdge != null) conflict("--width <WIDTH>", "--long-edge <LONG_EDGE>");
        if (c.width != null && c.shortEdge != null) conflict("--width <WIDTH>", "--short-edge <SHORT_EDGE>");
        if (c.height != null && c.longEdge != null) conflict("--height <HEIGHT>", "--long-edge <LONG_EDGE>");
        if (c.height != null && c.shortEdge != null) conflict("--height <HEIGHT>", "--short-edge <SHORT_EDGE>");
        if (c.longEdge != null && c.shortEdge != null) conflict("--long-edge <LONG_EDGE>", "--short-edge <SHORT_EDGE>");
    }

    private static void run(Config c) throws IOException {
        List<Job> jobs = collect(c);
        if (jobs.isEmpty()) {
            if (c.verbose > 0) System.out.println("No files to compress");
            return;
        }
        long original = 0, compressed = 0;
        int success = 0, skipped = 0, errors = 0;
        for (Job j : jobs) {
            original += Files.size(j.input);
            Result r;
            try {
                r = process(c, j);
            } catch (Exception e) {
                errors++;
                if (c.verbose >= 2) System.out.println("Error: " + j.input + ": " + e.getMessage());
                continue;
            }
            if (r.skipped) skipped++; else success++;
            compressed += r.size;
        }
        if (c.verbose > 0) {
            System.out.printf("Compressed %d files (%d success, %d skipped, %d errors)%n", jobs.size(), success, skipped, errors);
            long diff = compressed - original;
            double pct = original == 0 ? 0 : (diff * 100.0 / original);
            String sign = diff > 0 ? "+" : "-";
            System.out.printf("%s -> %s [%s%s | %s%.2f%%]%n", human(original), human(compressed), sign, human(Math.abs(diff)), sign, Math.abs(pct));
        }
    }

    private static List<Job> collect(Config c) throws IOException {
        List<Job> out = new ArrayList<>();
        for (Path input : c.inputs) {
            if (Files.isDirectory(input)) {
                if (c.recursive) {
                    Files.walkFileTree(input, new SimpleFileVisitor<>() {
                        @Override
                        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                            if (isImage(file)) out.add(new Job(file, input));
                            return FileVisitResult.CONTINUE;
                        }
                    });
                } else {
                    try (var s = Files.list(input)) {
                        s.filter(Files::isRegularFile).filter(Main::isImage).forEach(p -> out.add(new Job(p, input)));
                    }
                }
            } else if (Files.isRegularFile(input) && isImage(input)) {
                out.add(new Job(input, input.getParent() == null ? Path.of(".") : input.getParent()));
            }
        }
        return out;
    }

    private static Result process(Config c, Job j) throws IOException {
        Path dest = destination(c, j);
        long originalSize = Files.size(j.input);
        if (Files.exists(dest)) {
            if (c.overwrite.equals("never")) return new Result(true, Files.size(dest));
            if (c.overwrite.equals("bigger") && Files.size(dest) <= originalSize) return new Result(true, Files.size(dest));
        }
        if (c.dryRun) return new Result(false, estimateSize(c, j.input));
        Files.createDirectories(dest.getParent() == null ? Path.of(".") : dest.getParent());
        Path tmp = Files.createTempFile(dest.getParent(), ".caesiumclone-", ".tmp");
        boolean wrote = false;
        try {
            if (canCopyLossless(c)) {
                Files.copy(j.input, tmp, StandardCopyOption.REPLACE_EXISTING);
                wrote = true;
            } else {
                wrote = writeImage(c, j.input, tmp, outputFormat(c, j.input));
            }
            if (!wrote) Files.copy(j.input, tmp, StandardCopyOption.REPLACE_EXISTING);
            long newSize = Files.size(tmp);
            if (c.minSavings != null && !meetsSavings(c.minSavings, originalSize, newSize)) {
                Files.deleteIfExists(tmp);
                return new Result(true, Files.exists(dest) ? Files.size(dest) : originalSize);
            }
            Files.move(tmp, dest, StandardCopyOption.REPLACE_EXISTING);
            if (c.keepDates) {
                FileTime t = Files.getLastModifiedTime(j.input);
                Files.setLastModifiedTime(dest, t);
            }
            return new Result(false, Files.size(dest));
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    private static long estimateSize(Config c, Path input) throws IOException {
        if (canCopyLossless(c)) return Files.size(input);
        Path tmp = Files.createTempFile("caesiumclone-dry-", ".tmp");
        try {
            if (!writeImage(c, input, tmp, outputFormat(c, input))) return Files.size(input);
            return Files.size(tmp);
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    private static boolean canCopyLossless(Config c) {
        return c.lossless
                && c.format.equals("original")
                && c.width == null
                && c.height == null
                && c.longEdge == null
                && c.shortEdge == null;
    }

    private static boolean writeImage(Config c, Path input, Path output, String fmt) throws IOException {
        BufferedImage image = ImageIO.read(input.toFile());
        if (image == null) return false;
        image = resize(c, image);
        String writerFmt = fmt.equals("jpg") ? "jpeg" : fmt;
        Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName(writerFmt);
        if (!writers.hasNext()) return false;
        ImageWriter writer = writers.next();
        try (ImageOutputStream ios = ImageIO.createImageOutputStream(output.toFile())) {
            writer.setOutput(ios);
            ImageWriteParam param = writer.getDefaultWriteParam();
            if ((writerFmt.equals("jpeg") || writerFmt.equals("jpg")) && param.canWriteCompressed()) {
                param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
                float q = c.lossless ? 0.92f : c.quality != null ? c.quality / 100.0f : 0.75f;
                if (c.maxSize != null) q = Math.max(0.05f, Math.min(0.85f, c.maxSize / (float)Math.max(1, Files.size(input))));
                param.setCompressionQuality(Math.max(0f, Math.min(1f, q)));
            } else if (param.canWriteCompressed()) {
                param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
                String[] types = param.getCompressionTypes();
                if (types != null && types.length > 0) param.setCompressionType(types[0]);
                if (c.quality != null) param.setCompressionQuality(Math.max(0f, Math.min(1f, c.quality / 100.0f)));
            }
            if ((writerFmt.equals("jpeg") || writerFmt.equals("jpg")) && image.getType() != BufferedImage.TYPE_INT_RGB) {
                BufferedImage rgb = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
                Graphics2D g = rgb.createGraphics();
                g.drawImage(image, 0, 0, java.awt.Color.WHITE, null);
                g.dispose();
                image = rgb;
            }
            writer.write(null, new IIOImage(image, null, null), param);
            return true;
        } finally {
            writer.dispose();
        }
    }

    private static BufferedImage resize(Config c, BufferedImage img) {
        int w = img.getWidth();
        int h = img.getHeight();
        int nw = w, nh = h;
        if (c.width != null && c.height != null) {
            nw = c.width; nh = c.height;
        } else if (c.width != null) {
            nw = c.width; nh = Math.max(1, (int)Math.round(h * (c.width / (double)w)));
        } else if (c.height != null) {
            nh = c.height; nw = Math.max(1, (int)Math.round(w * (c.height / (double)h)));
        } else if (c.longEdge != null) {
            double scale = c.longEdge / (double)Math.max(w, h);
            nw = Math.max(1, (int)Math.round(w * scale));
            nh = Math.max(1, (int)Math.round(h * scale));
        } else if (c.shortEdge != null) {
            double scale = c.shortEdge / (double)Math.min(w, h);
            nw = Math.max(1, (int)Math.round(w * scale));
            nh = Math.max(1, (int)Math.round(h * scale));
        }
        if (c.noUpscale && (nw > w || nh > h)) {
            nw = w; nh = h;
        }
        if (nw == w && nh == h) return img;
        BufferedImage out = new BufferedImage(nw, nh, img.getTransparency() == BufferedImage.OPAQUE ? BufferedImage.TYPE_INT_RGB : BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawImage(img, 0, 0, nw, nh, null);
        g.dispose();
        return out;
    }

    private static Path destination(Config c, Job j) {
        Path base = c.sameFolder ? (j.input.getParent() == null ? Path.of(".") : j.input.getParent()) : c.output;
        if (c.keepStructure && !c.sameFolder) {
            Path rel = j.root.relativize(j.input).getParent();
            if (rel != null) base = base.resolve(rel);
        }
        String name = j.input.getFileName().toString();
        int dot = name.lastIndexOf('.');
        String stem = dot > 0 ? name.substring(0, dot) : name;
        String ext = extensionFor(c, j.input, dot > 0 ? name.substring(dot + 1) : "");
        return base.resolve(stem + c.suffix + (ext.isEmpty() ? "" : "." + ext));
    }

    private static String outputFormat(Config c, Path input) {
        String f = c.format.equals("original") ? ext(input).toLowerCase(Locale.ROOT) : c.format;
        if (f.equals("jpg")) return "jpeg";
        if (f.equals("tif")) return "tiff";
        return f;
    }

    private static String extensionFor(Config c, Path input, String original) {
        if (c.format.equals("original")) return original;
        return switch (c.format) {
            case "jpeg" -> "jpg";
            case "tiff" -> "tif";
            default -> c.format;
        };
    }

    private static boolean isImage(Path p) {
        return List.of("jpg", "jpeg", "png", "gif", "webp", "tif", "tiff").contains(ext(p).toLowerCase(Locale.ROOT));
    }

    private static String ext(Path p) {
        String n = p.getFileName().toString();
        int dot = n.lastIndexOf('.');
        return dot >= 0 ? n.substring(dot + 1) : "";
    }

    private static void missing(String arg, Config c) throws CliException {
        String both = c.output == null && !c.sameFolder && c.quality == null && !c.lossless && c.maxSize == null
                ? "  <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>\n  <--output <OUTPUT>|--same-folder-as-input>"
                : "  " + arg;
        throw new CliException("error: the following required arguments were not provided:\n" + both + "\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n\nFor more information, try '--help'.");
    }

    private static void conflict(String a, String b) throws CliException {
        throw new CliException("error: the argument '" + a + "' cannot be used with '" + b + "'\n\nUsage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n\nFor more information, try '--help'.");
    }

    private static String value(String[] args, int i, String opt) throws CliException {
        if (i >= args.length || args[i].startsWith("-")) {
            throw new CliException("error: a value is required for '" + opt + "' but none was supplied\n\nFor more information, try '--help'.");
        }
        return args[i];
    }

    private static int parseInt(String v, String name) throws CliException {
        try {
            return Integer.parseInt(v);
        } catch (NumberFormatException e) {
            throw new CliException("error: invalid value '" + v + "' for " + name + "\n\nFor more information, try '--help'.");
        }
    }

    private static int positiveInt(String v, String opt) throws CliException {
        int n = parseInt(v, opt);
        if (n == 0) throw new CliException("error: invalid value '0' for '" + opt + "': value must be greater than 0\n\nFor more information, try '--help'.");
        return n;
    }

    private static int nonNegativeInt(String v, String opt) throws CliException {
        int n = parseInt(v, opt);
        if (n < 0) throw new CliException("error: invalid value '" + v + "' for '" + opt + "': value must be greater than or equal to 0\n\nFor more information, try '--help'.");
        return n;
    }

    private static long parseSize(String s, String opt) throws CliException {
        try {
            return sizeValue(s);
        } catch (NumberFormatException e) {
            throw new CliException("error: invalid value '" + s + "' for '" + opt + "': Invalid size format: '" + s + "'. Use percentage (e.g., '10%'), size with unit (e.g., '100KB', '1MB'), or plain number as bytes\n\nFor more information, try '--help'.");
        }
    }

    private static Savings parseSavings(String s) throws CliException {
        try {
            if (s.endsWith("%")) return new Savings(Double.parseDouble(s.substring(0, s.length() - 1)), true);
            return new Savings(sizeValue(s), false);
        } catch (NumberFormatException e) {
            throw new CliException("error: invalid value '" + s + "' for '--min-savings <MIN_SAVINGS>': Invalid size format: '" + s + "'. Use percentage (e.g., '10%'), size with unit (e.g., '100KB', '1MB'), or plain number as bytes\n\nFor more information, try '--help'.");
        }
    }

    private static long sizeValue(String s) {
        String u = s.trim().toUpperCase(Locale.ROOT);
        double mult = 1;
        if (u.endsWith("KIB")) { mult = 1024; u = u.substring(0, u.length() - 3); }
        else if (u.endsWith("MIB")) { mult = 1024 * 1024; u = u.substring(0, u.length() - 3); }
        else if (u.endsWith("GIB")) { mult = 1024d * 1024 * 1024; u = u.substring(0, u.length() - 3); }
        else if (u.endsWith("KB")) { mult = 1000; u = u.substring(0, u.length() - 2); }
        else if (u.endsWith("MB")) { mult = 1000 * 1000; u = u.substring(0, u.length() - 2); }
        else if (u.endsWith("GB")) { mult = 1000d * 1000 * 1000; u = u.substring(0, u.length() - 2); }
        else if (u.endsWith("B")) { u = u.substring(0, u.length() - 1); }
        return (long)Math.floor(Double.parseDouble(u) * mult);
    }

    private static boolean meetsSavings(Savings s, long oldSize, long newSize) {
        long saved = oldSize - newSize;
        if (s.percent) return oldSize > 0 && (saved * 100.0 / oldSize) >= s.amount;
        return saved >= s.amount;
    }

    private static String human(long bytes) {
        double b = bytes;
        String[] units = {"B", "KiB", "MiB", "GiB"};
        int i = 0;
        while (Math.abs(b) >= 1024 && i < units.length - 1) {
            b /= 1024.0;
            i++;
        }
        if (i == 0) return "-0 B".equals(new DecimalFormat("0").format(b) + " B") ? "0 B" : new DecimalFormat("0").format(b) + " B";
        return new DecimalFormat("0.0").format(b) + " " + units[i];
    }

    private static class Config {
        boolean helpLong, helpShort, version, lossless, sameFolder, noUpscale, jpegBaseline, zopfli, exif, keepDates, stripIcc, recursive, keepStructure, dryRun, quiet;
        Integer quality, width, height, longEdge, shortEdge;
        Long maxSize;
        Path output;
        String format = "original", chroma = "auto", suffix = "", overwrite = "all";
        int pngOpt = 3, threads = 0, verbose = 1;
        Savings minSavings;
        List<Path> inputs = new ArrayList<>();
    }

    private record Job(Path input, Path root) {}
    private record Result(boolean skipped, long size) {}
    private record Savings(double amount, boolean percent) {}
    private static class CliException extends Exception {
        CliException(String msg) { super(msg); }
    }
}
