import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class GoCritic {
    static class Checker {
        final String name;
        final String tags;
        final String doc;
        Checker(String n, String t, String d) { name=n; tags=t; doc=d; }
    }

    static final String VERSION = "v0.0.0-SNAPSHOT";
    static final String DEFAULT_ENABLE = "appendAssign,argOrder,assignOp,badCall,badCond,captLocal,caseOrder,codegenComment,commentFormatting,defaultCaseOrder,deprecatedComment,dupArg,dupBranchBody,dupCase,dupSubExpr,elseif,exitAfterDefer,flagDeref,flagName,ifElseChain,mapKey,newDeref,offBy1,regexpMust,singleCaseSwitch,sloppyLen,sloppyTypeAssert,switchTrue,typeSwitchVar,underef,unlambda,unslice,valSwap,wrapperFunc";
    static final Map<String, Checker> CHECKERS = new LinkedHashMap<>();
    static {
        add("appendAssign","diagnostic","Detects suspicious append result assignments.\n\nNon-compliant code:\np.positives = append(p.negatives, x)\np.negatives = append(p.negatives, y)\n\nCompliant code:\np.positives = append(p.positives, x)\np.negatives = append(p.negatives, y)");
        add("appendCombine","performance","Detects append chains that can be combined into a single append call.");
        add("argOrder","diagnostic","Detects suspicious arguments order.\n\nNon-compliant code:\nstrings.HasPrefix(\"#\", userpass)\n\nCompliant code:\nstrings.HasPrefix(userpass, \"#\")");
        add("assignOp","style","Detects assignments that can be simplified by using assignment operators.\n\nNon-compliant code:\nx = x * 2\n\nCompliant code:\nx *= 2");
        add("badCall","diagnostic","Detects suspicious function calls.");
        add("badCond","diagnostic","Detects suspicious condition expressions.");
        add("badLock","diagnostic experimental","Detects suspicious lock usage.");
        add("badRegexp","diagnostic experimental","Detects malformed regexp patterns.");
        add("badSorting","diagnostic experimental","Detects suspicious sort.Slice usages.");
        add("badSyncOnceFunc","diagnostic experimental","Detects suspicious sync.OnceFunc usages.");
        add("boolExprSimplify","style experimental","Detects boolean expressions that can be simplified.");
        add("builtinShadow","style opinionated","Detects shadowing of predeclared identifiers.");
        add("builtinShadowDecl","diagnostic experimental","Detects declarations that shadow builtins in unsafe contexts.");
        add("captLocal","style","Detects capitalized names for local variables.");
        add("caseOrder","diagnostic","Detects erroneous case order inside switch statements.");
        add("codegenComment","diagnostic","Detects malformed code generation comments.");
        add("commentFormatting","style","Detects comments with non-idiomatic formatting.");
        add("commentedOutCode","diagnostic experimental","Detects commented-out code.");
        add("commentedOutImport","style experimental","Detects commented-out imports.");
        add("defaultCaseOrder","style","Detects default case not in the recommended position.");
        add("deferInLoop","diagnostic experimental","Detects defer statements inside loops.");
        add("deferUnlambda","style experimental","Detects defer calls wrapped into needless function literals.");
        add("deprecatedComment","diagnostic","Detects malformed 'deprecated' doc-comments.\n\nNon-compliant code:\n// deprecated, use FuncNew instead\nfunc FuncOld() int\n\nCompliant code:\n// Deprecated: use FuncNew instead\nfunc FuncOld() int");
        add("docStub","style experimental","Detects documentation comments that are stubs.");
        add("dupArg","diagnostic","Detects suspicious duplicated arguments.");
        add("dupBranchBody","diagnostic","Detects duplicated branch bodies.");
        add("dupCase","diagnostic","Detects duplicated case clauses.");
        add("dupImport","style experimental","Detects duplicated imports.");
        add("dupOption","diagnostic experimental","Detects duplicated options.");
        add("dupSubExpr","diagnostic","Detects suspicious duplicated sub-expressions.");
        add("dynamicFmtString","diagnostic experimental","Detects dynamic format strings.");
        add("elseif","style","Detects else with nested if statement that can be replaced with else-if.\n\nNon-compliant code:\nif cond1 {\n} else {\n\tif x := cond2; x {\n\t}\n}\n\nCompliant code:\nif cond1 {\n} else if x := cond2; x {\n}\n\nChecker parameters:\n  -@elseif.skipBalanced bool\n    \twhether to skip balanced if-else pairs (default true)");
        add("emptyDecl","diagnostic experimental","Detects empty declarations.");
        add("emptyFallthrough","style experimental","Detects fallthrough into empty cases.");
        add("emptyStringTest","style experimental","Detects len(s) comparisons that can use s == \"\".");
        add("equalFold","performance experimental","Detects string case conversion before comparison.");
        add("evalOrder","diagnostic experimental","Detects code that depends on evaluation order.");
        add("exitAfterDefer","diagnostic","Detects os.Exit calls after defer statements.");
        add("exposedSyncMutex","style experimental","Detects exposed sync.Mutex fields.");
        add("externalErrorReassign","diagnostic experimental","Detects reassignment of external error variables.");
        add("filepathJoin","diagnostic experimental","Detects filepath.Join mistakes.");
        add("flagDeref","diagnostic","Detects immediate dereference of flag package results.");
        add("flagName","diagnostic","Detects suspicious flag names.");
        add("hexLiteral","style experimental","Detects hex literals that can be improved.");
        add("httpNoBody","style experimental","Detects nil bodies where http.NoBody is preferred.");
        add("hugeParam","performance","Detects huge function parameters.");
        add("ifElseChain","style","Detects repeated if-else chains that can be switch statements.");
        add("importShadow","style opinionated","Detects variable names that shadow imported packages.");
        add("indexAlloc","performance","Detects strings.Index calls that allocate.");
        add("initClause","style opinionated experimental","Detects if/switch init clauses that can be simplified.");
        add("mapKey","diagnostic","Detects suspicious map keys.");
        add("methodExprCall","style experimental","Detects method expression calls that can be simplified.");
        add("nestingReduce","style opinionated experimental","Detects deeply nested code that can be reduced.");
        add("newDeref","style","Detects immediate dereference of new(T).");
        add("nilValReturn","diagnostic experimental","Detects returning nil values where non-nil expected.");
        add("octalLiteral","style experimental opinionated","Detects old-style octal literals.");
        add("offBy1","diagnostic","Detects off-by-one errors in index expressions.");
        add("paramTypeCombine","style opinionated","Detects adjacent parameters with the same type.");
        add("preferDecodeRune","performance experimental","Detects rune decoding patterns that can use utf8.DecodeRune.");
        add("preferFilepathJoin","style experimental","Detects path.Join where filepath.Join is preferred.");
        add("preferFprint","performance experimental","Detects fmt.Sprint passed to io.WriteString.");
        add("preferStringWriter","performance experimental","Detects Write([]byte(string)) patterns.");
        add("preferWriteByte","performance experimental opinionated","Detects single-byte writes that can use WriteByte.");
        add("ptrToRefParam","style opinionated experimental","Detects pointer parameters that could be references.");
        add("rangeAppendAll","diagnostic experimental","Detects append of all range values.");
        add("rangeExprCopy","performance","Detects expensive range expression copies.");
        add("rangeValCopy","performance","Detects expensive range value copies.");
        add("redundantSprint","style experimental","Detects redundant fmt.Sprint calls.");
        add("regexpMust","style","Detects `regexp.Compile*` that can be replaced with `regexp.MustCompile*`.\n\nNon-compliant code:\nre, _ := regexp.Compile(\"const pattern\")\n\nCompliant code:\nre := regexp.MustCompile(\"const pattern\")");
        add("regexpPattern","diagnostic experimental","Detects suspicious regexp patterns.");
        add("regexpSimplify","style experimental opinionated","Detects regexps that can be simplified.");
        add("returnAfterHttpError","diagnostic experimental","Detects missing return after http.Error.");
        add("ruleguard","style experimental","Runs dynamic ruleguard rules.");
        add("singleCaseSwitch","style","Detects switch statements with a single case.");
        add("sliceClear","performance experimental","Detects loops that can use clear.");
        add("sloppyLen","diagnostic","Detects usage of `len` when result is obvious or doesn't make sense.\n\nNon-compliant code:\nlen(arr) <= 0\n\nCompliant code:\nlen(arr) == 0");
        add("sloppyReassign","diagnostic experimental","Detects suspicious reassignments.");
        add("sloppyTypeAssert","diagnostic","Detects unchecked type assertions assigned to blank identifiers.");
        add("sortSlice","diagnostic experimental","Detects sort.Slice mistakes.");
        add("sprintfQuotedString","diagnostic experimental","Detects fmt.Sprintf with quoted string formats.");
        add("sqlQuery","diagnostic experimental","Detects suspicious SQL query construction.");
        add("stringConcatSimplify","style experimental","Detects string concatenations that can be simplified.");
        add("stringXbytes","performance","Detects needless string/[]byte conversions.");
        add("stringsCompare","style experimental","Detects strings.Compare uses that can be simplified.");
        add("switchTrue","style","Detects switch true statements that can be simplified.");
        add("syncMapLoadAndDelete","diagnostic experimental","Detects Load followed by Delete on sync.Map.");
        add("timeExprSimplify","style experimental","Detects time expressions that can be simplified.");
        add("todoCommentWithoutDetail","style opinionated experimental","Detects TODO comments without detail.");
        add("tooManyResultsChecker","style opinionated experimental","Detects functions with too many return values.");
        add("truncateCmp","diagnostic experimental","Detects comparisons after integer truncation.");
        add("typeAssertChain","style experimental","Detects chained type assertions.");
        add("typeDefFirst","style experimental","Detects type definitions that should be grouped first.");
        add("typeSwitchVar","style","Detects type switches that can use the assigned variable.");
        add("typeUnparen","style opinionated","Detects unnecessary parentheses in type expressions.");
        add("uncheckedInlineErr","diagnostic experimental","Detects unchecked inline errors.");
        add("underef","style","Detects redundant pointer dereferences.");
        add("unlabelStmt","style experimental","Detects unnecessary labels.");
        add("unlambda","style","Detects function literals that can be replaced by a function reference.");
        add("unnamedResult","style opinionated experimental","Detects unnamed result parameters.");
        add("unnecessaryBlock","style opinionated experimental","Detects unnecessary statement blocks.");
        add("unnecessaryDefer","diagnostic experimental","Detects defer statements that are unnecessary.");
        add("unslice","style","Detects slice expressions that can be simplified to sliced expression itself.\n\nNon-compliant code:\ncopy(b[:], values...)\n\nCompliant code:\ncopy(b, values...)");
        add("valSwap","style","Detects value swapping code that are not using parallel assignment.\n\nNon-compliant code:\n*tmp = *x; *x = *y; *y = *tmp\n\nCompliant code:\n*x, *y = *y, *x");
        add("weakCond","diagnostic experimental","Detects weak conditions.");
        add("whyNoLint","style experimental","Detects nolint directives without explanations.");
        add("wrapperFunc","style","Detects function calls that can be replaced with convenience wrappers.\n\nNon-compliant code:\nwg.Add(-1)\n\nCompliant code:\nwg.Done()");
        add("yodaStyleExpr","style experimental","Detects Yoda-style expressions.");
        add("zeroByteRepeat","performance","Detects bytes.Repeat with zero byte.");
    }

    static void add(String n, String t, String d) { CHECKERS.put(n, new Checker(n,t,d)); }

    public static void main(String[] args) {
        int code = new GoCritic().run(args);
        if (code != 0) System.exit(code);
    }

    int run(String[] args) {
        if (args.length == 0) { System.err.println("no args provided"); return 1; }
        switch (args[0]) {
            case "help": printHelp(); return 0;
            case "version": System.out.println("go-critic version: " + VERSION); return 0;
            case "doc": return doc(Arrays.copyOfRange(args,1,args.length));
            case "check": return check(Arrays.copyOfRange(args,1,args.length));
            case "--help":
                System.err.println("\"--help\" unknown command, did you mean \"help\"?");
                System.err.println("Run \"go-critic help\" for usage.\n");
                System.err.println("no such command \"--help\"");
                return 1;
            default:
                System.err.println("\"" + args[0] + "\" unknown command, did you mean \"doc\"?");
                System.err.println("Run \"go-critic help\" for usage.\n");
                System.err.println("no such command \"" + args[0] + "\"");
                return 1;
        }
    }

    void printHelp() {
        System.out.println("Usage:\n\n    go-critic <command> [arguments...]\n\nThe commands are:\n");
        System.out.println("    check             run linter over specified targets");
        System.out.println("    doc               get installed checkers documentation");
        System.out.println("    help              shows help message");
        System.out.println("    version           shows version of the application\n");
        System.out.println("Version: " + VERSION);
    }

    int doc(String[] args) {
        if (args.length == 1 && args[0].equals("-help")) {
            System.err.println("Usage of go-critic:");
            System.err.println("flag: help requested");
            return 1;
        }
        if (args.length > 1) { System.err.println("expected 0 or 1 positional arguments"); return 1; }
        if (args.length == 0) {
            for (Checker c: CHECKERS.values()) System.out.println(c.name + " [" + c.tags + "]");
            return 0;
        }
        Checker c = CHECKERS.get(args[0]);
        if (c == null) { System.err.println("checker with name \""+args[0]+"\" not found"); return 1; }
        System.out.println(c.name + " checker documentation");
        System.out.println("URL: https://github.com/go-critic/go-critic/checkers");
        System.out.println("Tags: [" + c.tags + "]\n");
        System.out.println(c.doc);
        return 0;
    }

    int check(String[] args) {
        Set<String> enabled = new LinkedHashSet<>(Arrays.asList(DEFAULT_ENABLE.split(",")));
        int exitCode = 1;
        List<String> targets = new ArrayList<>();
        boolean enableAll = false;
        for (int i=0; i<args.length; i++) {
            String a = args[i];
            if (a.equals("-help") || a.equals("--help")) { printCheckUsage(); System.err.println("parse args: flag: help requested"); return 1; }
            if (a.equals("-enableAll")) { enableAll = true; continue; }
            if (a.equals("-v") || a.equals("-checkGenerated") || a.equals("-checkTests") || a.equals("-shorterErrLocation") || a.startsWith("-@")) {
                if (a.startsWith("-@") && !a.contains("=") && i+1 < args.length && !args[i+1].startsWith("-")) i++;
                continue;
            }
            if (a.equals("-enable") || a.equals("-disable") || a.equals("-exitCode") || a.equals("-concurrency") || a.equals("-go") || a.equals("-cpuprofile") || a.equals("-memprofile")) {
                if (i+1 >= args.length) { System.err.println("parse args: flag needs an argument: " + a); return 1; }
                String val = args[++i];
                if (a.equals("-enable")) enabled = expand(val);
                else if (a.equals("-disable")) enabled.removeAll(expand(val));
                else if (a.equals("-exitCode")) try { exitCode = Integer.parseInt(val); } catch (NumberFormatException e) { exitCode = 1; }
                continue;
            }
            if (a.startsWith("-enable=")) { enabled = expand(a.substring(8)); continue; }
            if (a.startsWith("-disable=")) { enabled.removeAll(expand(a.substring(9))); continue; }
            if (a.startsWith("-exitCode=")) { try { exitCode = Integer.parseInt(a.substring(10)); } catch(Exception ignored){} continue; }
            if (a.startsWith("-")) {
                System.err.println("flag provided but not defined: " + a);
                printCheckUsage();
                System.err.println("parse args: flag provided but not defined: " + a);
                return 1;
            }
            targets.add(a);
        }
        if (enableAll) enabled = new LinkedHashSet<>(CHECKERS.keySet());
        if (targets.isEmpty()) {
            System.err.println("load packages: err: go command required, not found: exec: \"go\": executable file not found in $PATH: stderr: ");
            return 1;
        }
        List<Path> files = new ArrayList<>();
        for (String t: targets) collect(Paths.get(t), files);
        if (files.isEmpty()) {
            System.err.println("load packages: err: go command required, not found: exec: \"go\": executable file not found in $PATH: stderr: ");
            return 1;
        }
        int issues = 0;
        for (Path p: files) try { issues += lint(p, enabled); } catch (IOException e) { System.err.println(e.getMessage()); return 1; }
        return issues == 0 ? 0 : exitCode;
    }

    Set<String> expand(String spec) {
        Set<String> r = new LinkedHashSet<>();
        for (String raw: spec.split(",")) {
            String s = raw.trim();
            if (s.isEmpty()) continue;
            if (s.equals("#diagnostic") || s.equals("#style") || s.equals("#performance") || s.equals("#experimental") || s.equals("#opinionated") || s.equals("#security")) {
                String tag = s.substring(1);
                for (Checker c: CHECKERS.values()) if (Arrays.asList(c.tags.split(" ")).contains(tag)) r.add(c.name);
            } else if (CHECKERS.containsKey(s)) r.add(s);
        }
        return r;
    }

    void collect(Path p, List<Path> out) {
        try {
            if (Files.isRegularFile(p) && p.toString().endsWith(".go")) out.add(p);
            else if (Files.isDirectory(p)) try (var s = Files.walk(p)) { s.filter(x -> Files.isRegularFile(x) && x.toString().endsWith(".go")).forEach(out::add); }
            else if (p.toString().endsWith("/...")) {
                Path base = Paths.get(p.toString().substring(0, p.toString().length()-4));
                if (Files.isDirectory(base)) try (var s = Files.walk(base)) { s.filter(x -> Files.isRegularFile(x) && x.toString().endsWith(".go")).forEach(out::add); }
            }
        } catch (IOException ignored) {}
    }

    int lint(Path p, Set<String> enabled) throws IOException {
        List<String> lines = Files.readAllLines(p, StandardCharsets.UTF_8);
        int n = 0;
        for (int i=0; i<lines.size(); i++) {
            String line = lines.get(i);
            String trim = line.trim();
            if (enabled.contains("assignOp")) {
                Matcher m = Pattern.compile("\\b([A-Za-z_]\\w*)\\s*=\\s*\\1\\s*([+\\-*/%&|^])\\s*[^=].*").matcher(trim);
                if (m.matches()) { diag(p,i+1,line.indexOf("=")+1,"assignOp","replace assignment with " + m.group(2) + "="); n++; }
            }
            if (enabled.contains("unslice") && Pattern.compile("\\b(copy|append)\\s*\\([^,()]+\\[:\\]").matcher(trim).find()) { diag(p,i+1,line.indexOf("[:")+1,"unslice","could simplify sliced expression"); n++; }
            if (enabled.contains("regexpMust") && trim.contains("regexp.Compile") && trim.contains("\"") && (trim.contains(", _ :=")||trim.contains(", _ =")||trim.contains("_, _"))) { diag(p,i+1,line.indexOf("regexp.Compile")+1,"regexpMust","use regexp.MustCompile for constant regexp"); n++; }
            if (enabled.contains("wrapperFunc") && trim.matches(".*\\.Add\\s*\\(\\s*-1\\s*\\).*")) { diag(p,i+1,line.indexOf(".Add")+1,"wrapperFunc","can use Done() instead of Add(-1)"); n++; }
            if (enabled.contains("sloppyLen") && Pattern.compile("len\\s*\\([^)]*\\)\\s*(<=\\s*0|>\\s*0)").matcher(trim).find()) { diag(p,i+1,line.indexOf("len")+1,"sloppyLen","len comparison can be simplified"); n++; }
            if (enabled.contains("elseif") && trim.equals("} else {") && i+1 < lines.size() && lines.get(i+1).trim().startsWith("if ")) { diag(p,i+1,line.indexOf("else")+1,"elseif","can replace 'else { if cond { } }' with 'else if cond { }'"); n++; }
            if (enabled.contains("deprecatedComment") && trim.toLowerCase(Locale.ROOT).startsWith("// deprecated") && !trim.startsWith("// Deprecated:")) { diag(p,i+1,line.indexOf("//")+1,"deprecatedComment","the proper format is '// Deprecated: ...'"); n++; }
            if (enabled.contains("switchTrue") && trim.matches("switch\\s+true\\s*\\{.*")) { diag(p,i+1,line.indexOf("switch")+1,"switchTrue","replace switch true with switch"); n++; }
            if (enabled.contains("appendAssign")) {
                Matcher m = Pattern.compile("(.+)\\s*=\\s*append\\s*\\(([^,]+),.*").matcher(trim);
                if (m.matches() && !m.group(1).trim().equals(m.group(2).trim())) { diag(p,i+1,line.indexOf("append")+1,"appendAssign","append result not assigned to the same slice"); n++; }
            }
            if (enabled.contains("argOrder") && Pattern.compile("strings\\.Has(Prefix|Suffix)\\s*\\(\\s*\"[^\"]*\"\\s*,").matcher(trim).find()) { diag(p,i+1,line.indexOf("strings.Has")+1,"argOrder","suspicious argument order"); n++; }
        }
        return n;
    }

    void diag(Path p, int line, int col, String checker, String msg) {
        System.out.printf("%s:%d:%d: %s: %s%n", p.toString(), line, Math.max(1,col), checker, msg);
    }

    void printCheckUsage() {
        System.err.println("Usage of go-critic:");
        String[] lines = {
            "  -@captLocal.paramsOnly\n    \twhether to restrict checker to params only (default true)",
            "  -@commentedOutCode.minLength int\n    \tmin length of the comment that triggers a warning (default 15)",
            "  -@elseif.skipBalanced\n    \twhether to skip balanced if-else pairs (default true)",
            "  -@hugeParam.sizeThreshold int\n    \tsize in bytes that makes the warning trigger (default 80)",
            "  -@ifElseChain.minThreshold int\n    \tmin number of if-else blocks that makes the warning trigger (default 2)",
            "  -@nestingReduce.bodyWidth int\n    \tmin number of statements inside a branch to trigger a warning (default 5)",
            "  -@rangeExprCopy.sizeThreshold int\n    \tsize in bytes that makes the warning trigger (default 512)",
            "  -@rangeExprCopy.skipTestFuncs\n    \twhether to check test functions (default true)",
            "  -@rangeValCopy.sizeThreshold int\n    \tsize in bytes that makes the warning trigger (default 128)",
            "  -@rangeValCopy.skipTestFuncs\n    \twhether to check test functions (default true)",
            "  -@ruleguard.debug string\n    \tenable debug for the specified named rules group",
            "  -@ruleguard.disable string\n    \tcomma-separated list of disabled groups or skip empty to enable everything",
            "  -@ruleguard.enable string\n    \tcomma-separated list of enabled groups or skip empty to enable everything (default \"<all>\")",
            "  -@ruleguard.failOn string\n    \tDetermines the behavior when an error occurs while parsing ruleguard files.",
            "  -@ruleguard.failOnError\n    \tdeprecated, use failOn param; if set to true, identical to failOn='all', otherwise failOn=''",
            "  -@ruleguard.rules string\n    \tcomma-separated list of gorule file paths. Glob patterns such as 'rules-*.go' may be specified",
            "  -@tooManyResultsChecker.maxResults int\n    \tmaximum number of results (default 5)",
            "  -@truncateCmp.skipArchDependent\n    \twhether to skip int/uint/uintptr types (default true)",
            "  -@underef.skipRecvDeref\n    \twhether to skip (*x).method() calls where x is a pointer receiver (default true)",
            "  -@unnamedResult.checkExported\n    \twhether to check exported functions",
            "  -checkGenerated\n    \twhether to check generated files",
            "  -checkTests\n    \twhether to check test files (default true)",
            "  -concurrency int\n    \thow many concurrent checkers to run (default is runtime.GOMAXPROCS(0)) (default 14)",
            "  -cpuprofile string\n    \twrite CPU profile to the specified file",
            "  -disable string\n    \tcomma-separated list of checkers to be disabled. Can include #tags",
            "  -enable string\n    \tcomma-separated list of enabled checkers. Can include #tags (default \"" + DEFAULT_ENABLE + "\")",
            "  -enableAll\n    \tidentical to -enable with all checkers listed. If true, -enable is ignored",
            "  -exitCode int\n    \texit code to be used when lint issues are found (default 1)",
            "  -go string\n    \tselect the Go version to target. Leave as string for the latest",
            "  -memprofile string\n    \twrite memory profile to the specified file",
            "  -shorterErrLocation\n    \twhether to replace error location prefix with $GOROOT and $GOPATH (default true)",
            "  -v\twhether to print output useful during linter debugging"
        };
        for (String l: lines) System.err.println(l);
    }
}
