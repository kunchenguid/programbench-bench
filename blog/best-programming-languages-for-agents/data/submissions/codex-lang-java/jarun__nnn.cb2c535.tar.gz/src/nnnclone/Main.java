package nnnclone;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

public final class Main {
    private static final String VERSION = "5.2";
    private static final String OPTS_WITH_ARGS = "bFlpPstT";
    private static final String VALID_OPTS = "aAbBcCdDeEfFghHiJKlNnoOpPQrRsStTuUVxz0";

    private Main() {
    }

    public static void main(String[] args) {
        String prog = System.getProperty("nnn.prog", "nnn");
        RunConfig cfg = new RunConfig();

        int parseResult = parseArgs(args, prog, cfg);
        if (parseResult != Integer.MIN_VALUE) {
            System.exit(parseResult);
        }

        if (cfg.showVersion) {
            System.out.println(VERSION);
            return;
        }
        if (cfg.showHelp) {
            printUsage(System.out);
            return;
        }

        int rc = runBrowser(cfg);
        System.exit(rc);
    }

    private static int parseArgs(String[] args, String prog, RunConfig cfg) {
        boolean endOptions = false;
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (endOptions || !arg.startsWith("-") || "-".equals(arg)) {
                cfg.paths.add(arg);
                continue;
            }
            if ("--".equals(arg)) {
                endOptions = true;
                continue;
            }

            for (int pos = 1; pos < arg.length(); pos++) {
                char opt = arg.charAt(pos);
                if (VALID_OPTS.indexOf(opt) < 0) {
                    System.err.printf("%s: invalid option -- '%c'%n", prog, opt);
                    printUsage(System.err);
                    return 1;
                }

                if (OPTS_WITH_ARGS.indexOf(opt) >= 0) {
                    String value;
                    if (pos + 1 < arg.length()) {
                        value = arg.substring(pos + 1);
                        pos = arg.length();
                    } else if (i + 1 < args.length) {
                        value = args[++i];
                    } else {
                        System.err.printf("%s: option requires an argument -- '%c'%n", prog, opt);
                        printUsage(System.err);
                        return 1;
                    }
                    applyArgOption(opt, value, cfg);
                    break;
                }

                if (opt == 'V') {
                    cfg.showVersion = true;
                } else if (opt == 'h') {
                    cfg.showHelp = true;
                } else if (opt == 'H') {
                    cfg.showHidden = true;
                } else if (opt == '0') {
                    cfg.nullSeparator = true;
                } else if (opt == 'd') {
                    cfg.detailMode = true;
                }
            }
        }
        return Integer.MIN_VALUE;
    }

    private static void applyArgOption(char opt, String value, RunConfig cfg) {
        switch (opt) {
            case 'F':
                cfg.fifoMode = value;
                break;
            case 'p':
                cfg.picker = true;
                cfg.selectionFile = value;
                break;
            case 'T':
                cfg.sortOrder = value.isEmpty() ? '\0' : value.charAt(0);
                break;
            case 'b':
            case 'P':
            case 's':
                break;
            case 'l':
            case 't':
                parseIgnoredInt(value);
                break;
            default:
                break;
        }
    }

    private static int parseIgnoredInt(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    private static int runBrowser(RunConfig cfg) {
        Path path = cfg.paths.isEmpty() ? Paths.get(".") : Paths.get(cfg.paths.get(cfg.paths.size() - 1));
        if (Files.isRegularFile(path)) {
            path = path.toAbsolutePath().getParent();
            if (path == null) {
                path = Paths.get(".");
            }
        }

        List<Path> entries = listEntries(path, cfg);
        String term = System.getenv("TERM");
        boolean termLooksUsable = term != null && !term.isBlank() && !"unknown".equals(term);

        if (!termLooksUsable) {
            System.out.println("0 entries");
            return 1;
        }

        emitEnterAltScreen();
        try {
            draw(path, entries, cfg);
            waitForQuit();
        } finally {
            emitLeaveAltScreen();
        }
        return 0;
    }

    private static List<Path> listEntries(Path path, RunConfig cfg) {
        List<Path> out = new ArrayList<>();
        if (!Files.isDirectory(path)) {
            return out;
        }
        try (Stream<Path> stream = Files.list(path)) {
            stream.filter(p -> cfg.showHidden || !p.getFileName().toString().startsWith("."))
                    .sorted(entryComparator(cfg))
                    .forEach(out::add);
        } catch (IOException ignored) {
            return new ArrayList<>();
        }
        return out;
    }

    private static Comparator<Path> entryComparator(RunConfig cfg) {
        Comparator<Path> byName = Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT));
        if (cfg.sortOrder == 's') {
            return Comparator.comparingLong(Main::sizeOf).thenComparing(byName);
        }
        if (cfg.sortOrder == 't') {
            return Comparator.comparingLong(Main::mtimeOf).reversed().thenComparing(byName);
        }
        return byName;
    }

    private static long sizeOf(Path path) {
        try {
            return Files.size(path);
        } catch (IOException ignored) {
            return 0L;
        }
    }

    private static long mtimeOf(Path path) {
        try {
            return Files.getLastModifiedTime(path).toMillis();
        } catch (IOException ignored) {
            return 0L;
        }
    }

    private static void draw(Path path, List<Path> entries, RunConfig cfg) {
        String abs = path.toAbsolutePath().normalize().toString();
        System.out.print("\033[2J\033[H");
        System.out.println(abs);
        if (entries.isEmpty()) {
            System.out.println("0 entries");
            return;
        }
        int count = Math.min(entries.size(), 40);
        for (int i = 0; i < count; i++) {
            Path p = entries.get(i);
            String name = p.getFileName().toString();
            if (Files.isDirectory(p)) {
                name += "/";
            }
            if (cfg.detailMode) {
                System.out.printf(Locale.ROOT, "%10d  %s%n", sizeOf(p), name);
            } else {
                System.out.println(name);
            }
        }
    }

    private static void waitForQuit() {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            long deadline = System.currentTimeMillis() + 1500L;
            while (System.currentTimeMillis() < deadline) {
                if (reader.ready()) {
                    int c = reader.read();
                    if (c < 0 || c == 'q' || c == 'Q' || c == 27) {
                        return;
                    }
                } else {
                    Thread.sleep(25L);
                }
            }
        } catch (IOException | InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    private static void emitEnterAltScreen() {
        System.out.print("\033[?1049h\033[?25l");
    }

    private static void emitLeaveAltScreen() {
        System.out.print("\033[?25h\033[?1049l");
        System.out.flush();
    }

    private static void printUsage(Appendable out) {
        try {
            out.append("usage: nnn [OPTIONS] [PATH]\n\n")
                    .append("The unorthodox terminal file manager.\n\n")
                    .append("positional args:\n")
                    .append("  PATH   start dir/file [default: .]\n\n")
                    .append("optional args:\n")
                    .append(" -a      auto NNN_FIFO\n")
                    .append(" -A      no dir auto-enter during filter\n")
                    .append(" -b key  open bookmark key (trumps -s/S)\n")
                    .append(" -B      use bsdtar for archives\n")
                    .append(" -c      cli-only NNN_OPENER (trumps -e)\n")
                    .append(" -C      8-color scheme\n")
                    .append(" -d      detail mode\n")
                    .append(" -D      dirs in context color\n")
                    .append(" -e      text in $VISUAL/$EDITOR/vi\n")
                    .append(" -E      internal edits in EDITOR\n")
                    .append(" -f      use history file\n")
                    .append(" -F val  fifo mode [0:preview 1:explore]\n")
                    .append(" -g      regex filters\n")
                    .append(" -H      show hidden files\n")
                    .append(" -i      show current file info\n")
                    .append(" -J      no auto-advance on selection\n")
                    .append(" -K      detect key collision and exit\n")
                    .append(" -l val  set scroll lines\n")
                    .append(" -n      type-to-nav mode\n")
                    .append(" -N      use native prompt\n")
                    .append(" -o      open files only on Enter\n")
                    .append(" -p file selection file [-:stdout]\n")
                    .append(" -P key  run plugin key\n")
                    .append(" -Q      no quit confirmation\n")
                    .append(" -r      use advcpmv patched cp, mv\n")
                    .append(" -R      no rollover at edges\n")
                    .append(" -s name load session by name\n")
                    .append(" -S      persistent session\n")
                    .append(" -t secs timeout to lock\n")
                    .append(" -T key  sort order [a/d/e/r/s/t/v]\n")
                    .append(" -u      use selection (no prompt)\n")
                    .append(" -U      show user and group\n")
                    .append(" -V      show version\n")
                    .append(" -x      notis, selection sync, xterm title\n")
                    .append(" -z      in order fuzzy filters\n")
                    .append(" -0      null separator in picker mode\n")
                    .append(" -h      show help\n\n")
                    .append("v5.2\n")
                    .append("BSD 2-Clause\n")
                    .append("https://github.com/jarun/nnn\n");
        } catch (IOException ignored) {
            // PrintStream append does not throw in practice.
        }
    }

    private static final class RunConfig {
        boolean showHelp;
        boolean showVersion;
        boolean showHidden;
        boolean detailMode;
        boolean picker;
        boolean nullSeparator;
        String fifoMode;
        String selectionFile;
        char sortOrder;
        final List<String> paths = new ArrayList<>();
    }
}
