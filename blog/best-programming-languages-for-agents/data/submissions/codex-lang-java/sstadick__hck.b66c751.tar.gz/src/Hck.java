import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;

public class Hck {
    static class Opt {
        String output = null, delim = "\\s+", outDelim = "\t", fields = null, exclude = null;
        boolean literal = false, useInputDelim = false, headerRegex = false, tryDecompress = false, tryCompress = false;
        boolean crlf = false;
        List<String> headerFields = new ArrayList<>(), excludeHeaders = new ArrayList<>(), inputs = new ArrayList<>();
    }

    interface Selector { void add(int n, List<Integer> out); }

    public static void main(String[] args) {
        try {
            Opt opt = parse(args);
            if (opt == null) return;
            if (opt.useInputDelim && opt.literal && "\t".equals(opt.outDelim)) opt.outDelim = opt.delim;
            run(opt);
        } catch (Usage u) {
            System.err.println(u.getMessage());
            System.exit(u.code);
        } catch (Exception e) {
            System.err.println("[2026-05-31T00:00:00Z ERROR hck] " + (e.getMessage() == null ? e.toString() : e.getMessage()));
            System.exit(1);
        }
    }

    static class Usage extends Exception {
        int code;
        Usage(String s, int c) { super(s); code = c; }
    }

    static Opt parse(String[] args) throws Usage {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if ("--help".equals(a)) { System.out.print(HELP_LONG); return null; }
            if ("-h".equals(a)) { System.out.print(HELP_SHORT); return null; }
            if ("--version".equals(a) || "-V".equals(a)) { System.out.println("hck git:23bebe8-modified"); return null; }
            if ("--delimiter".equals(a) || "-d".equals(a)) o.delim = need(args, ++i, a);
            else if (a.startsWith("-d") && a.length() > 2) o.delim = a.substring(2);
            else if ("--output-delimiter".equals(a) || "-D".equals(a)) o.outDelim = need(args, ++i, a);
            else if (a.startsWith("-D") && a.length() > 2) o.outDelim = a.substring(2);
            else if ("--output".equals(a) || "-o".equals(a)) o.output = need(args, ++i, a);
            else if (a.startsWith("-o") && a.length() > 2) o.output = a.substring(2);
            else if ("--fields".equals(a) || "-f".equals(a)) { if (o.fields != null) multi("fields"); o.fields = need(args, ++i, a); }
            else if (a.startsWith("-f") && a.length() > 2) { if (o.fields != null) multi("fields"); o.fields = a.substring(2); }
            else if ("--exclude".equals(a) || "-e".equals(a)) { if (o.exclude != null) multi("exclude"); o.exclude = need(args, ++i, a); }
            else if (a.startsWith("-e") && a.length() > 2) { if (o.exclude != null) multi("exclude"); o.exclude = a.substring(2); }
            else if ("--header-field".equals(a) || "-F".equals(a)) o.headerFields.add(need(args, ++i, a));
            else if (a.startsWith("-F") && a.length() > 2) o.headerFields.add(a.substring(2));
            else if ("--exclude-header".equals(a) || "-E".equals(a)) o.excludeHeaders.add(need(args, ++i, a));
            else if (a.startsWith("-E") && a.length() > 2) o.excludeHeaders.add(a.substring(2));
            else if ("--delim-is-literal".equals(a) || "-L".equals(a)) o.literal = true;
            else if ("--use-input-delim".equals(a) || "-I".equals(a)) o.useInputDelim = true;
            else if ("--header-is-regex".equals(a) || "-r".equals(a)) o.headerRegex = true;
            else if ("--try-decompress".equals(a) || "-z".equals(a)) o.tryDecompress = true;
            else if ("--try-compress".equals(a) || "-Z".equals(a)) o.tryCompress = true;
            else if ("--compression-threads".equals(a) || "-t".equals(a) || "--compression-level".equals(a) || "-l".equals(a)) { need(args, ++i, a); }
            else if (a.startsWith("-t") && a.length() > 2 || a.startsWith("-l") && a.length() > 2) { }
            else if ("--no-mmap".equals(a)) { }
            else if ("--crlf".equals(a)) o.crlf = true;
            else if (a.startsWith("-")) throw new Usage("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.", 2);
            else o.inputs.add(a);
        }
        return o;
    }

    static void multi(String name) throws Usage {
        throw new Usage("error: the argument '--" + name + " <" + name.toUpperCase().replace('-', '_') + ">' cannot be used multiple times\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.", 2);
    }
    static String need(String[] a, int i, String opt) throws Usage {
        if (i >= a.length) throw new Usage("error: a value is required for '" + opt + "' but none was supplied", 2);
        return a[i];
    }

    static void run(Opt o) throws Exception {
        OutputStream base = o.output == null ? System.out : Files.newOutputStream(Paths.get(o.output));
        if (o.tryCompress) base = new GZIPOutputStream(base);
        BufferedWriter out = new BufferedWriter(new OutputStreamWriter(base, StandardCharsets.UTF_8));
        if (o.inputs.isEmpty()) process(new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8)), o, out);
        else for (String f : o.inputs) {
            InputStream in = Files.newInputStream(Paths.get(f));
            if (o.tryDecompress && f.endsWith(".gz")) in = new GZIPInputStream(in);
            process(new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)), o, out);
        }
        if (o.tryCompress || o.output != null) out.close();
        else out.flush();
    }

    static void process(BufferedReader br, Opt o, BufferedWriter out) throws Exception {
        List<Selector> fields = parseSelectors(o.fields);
        List<Selector> excludes = parseSelectors(o.exclude);
        String line;
        boolean first = true;
        List<Integer> headerOrder = null, headerExclude = Collections.emptyList();
        while ((line = br.readLine()) != null) {
            String[] parts = split(line, o);
            if (first && (!o.headerFields.isEmpty() || !o.excludeHeaders.isEmpty())) {
                headerOrder = headerIndexes(parts, o.headerFields, o.headerRegex, true);
                headerExclude = headerIndexes(parts, o.excludeHeaders, o.headerRegex, false);
                if (!o.headerFields.isEmpty() && headerOrder.isEmpty()) throw new Exception("No headers matched");
            }
            List<Integer> order = new ArrayList<>();
            if (headerOrder != null) order.addAll(headerOrder);
            if (fields.isEmpty() && (headerOrder == null || o.headerFields.isEmpty())) addRange(1, parts.length, parts.length, order);
            else for (Selector s : fields) s.add(parts.length, order);
            Set<Integer> ex = new HashSet<>();
            for (Selector s : excludes) { List<Integer> t = new ArrayList<>(); s.add(parts.length, t); ex.addAll(t); }
            ex.addAll(headerExclude);
            List<String> vals = new ArrayList<>();
            Set<Integer> seen = new HashSet<>();
            for (int idx : order) if (idx >= 1 && idx <= parts.length && !ex.contains(idx) && seen.add(idx)) vals.add(parts[idx - 1]);
            out.write(String.join(o.outDelim, vals));
            out.write('\n');
            first = false;
        }
    }

    static String[] split(String line, Opt o) {
        if (o.literal) return line.split(Pattern.quote(o.delim), -1);
        return Pattern.compile(o.delim).split(line, -1);
    }

    static List<Integer> headerIndexes(String[] parts, List<String> pats, boolean regex, boolean keepGroups) {
        List<Integer> res = new ArrayList<>();
        for (String p : pats) {
            Pattern pat = regex ? Pattern.compile(p) : null;
            for (int i = 0; i < parts.length; i++) {
                boolean m = regex ? pat.matcher(parts[i]).find() : parts[i].equals(p);
                if (m) res.add(i + 1);
            }
        }
        return res;
    }

    static List<Selector> parseSelectors(String spec) throws Exception {
        List<Selector> out = new ArrayList<>();
        if (spec == null || spec.isEmpty()) return out;
        for (String raw : spec.split(",")) {
            String s = raw.trim();
            if (s.isEmpty()) continue;
            int dash = s.indexOf('-');
            if (dash < 0) {
                int n = pos(s);
                out.add((len, list) -> addRange(n, n, len, list));
            } else {
                String a = s.substring(0, dash), b = s.substring(dash + 1);
                int lo = a.isEmpty() ? 1 : pos(a);
                Integer hi = b.isEmpty() ? null : pos(b);
                if (hi != null && hi < lo) throw new Exception("High end of range less than low end of range: " + s);
                out.add((len, list) -> addRange(lo, hi == null ? len : hi, len, list));
            }
        }
        return out;
    }

    static int pos(String s) throws Exception {
        int n;
        try { n = Integer.parseInt(s); } catch (NumberFormatException e) { throw new Exception("invalid digit found in string"); }
        if (n < 1) throw new Exception("Fields and positions are numbered from 1: " + n);
        return n;
    }
    static void addRange(int lo, int hi, int len, List<Integer> list) {
        for (int i = lo; i <= hi && i <= len; i++) list.add(i);
    }

    static final String HELP_SHORT = "* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`\n\nUsage: executable [OPTIONS] [INPUT]...\n\nArguments:\n  [INPUT]...  Input files to parse, defaults to stdin\n\nOptions:\n  -o, --output <OUTPUT>\n          Output file to write to, defaults to stdout\n  -d, --delimiter <DELIMITER>\n          Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag [default: \\s+]\n  -L, --delim-is-literal\n          Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters\n  -I, --use-input-delim\n          Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set\n  -D, --output-delimiter <OUTPUT_DELIMITER>\n          Delimiter string to use on outputs [default: \"\\t\"]\n  -f, --fields <FIELDS>\n          Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive\n  -e, --exclude <EXCLUDE>\n          Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`\n  -E, --exclude-header <EXCLUDE_HEADER>\n          Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex\n  -F, --header-field <HEADER_FIELD>\n          A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex\n  -r, --header-is-regex\n          Treat the header_fields as regexs instead of string literals\n  -z, --try-decompress\n          Try to find the correct decompression method based on the file extensions\n  -Z, --try-compress\n          Try to gzip compress the output\n  -t, --compression-threads <COMPRESSION_THREADS>\n          Threads to use for compression, 0 will result in `hck` staying single threaded [default: 4]\n  -l, --compression-level <COMPRESSION_LEVEL>\n          Compression level [default: 6]\n      --no-mmap\n          Disallow the possibility of using mmap\n      --crlf\n          Support CRLF newlines\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version\n";
    static final String HELP_LONG = HELP_SHORT;
}
