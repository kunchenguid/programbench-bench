import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class MlrLite {
  enum Format { DKVP, CSV, TSV, PPRINT, JSON, JSONL, NIDX }
  static class Config {
    Format in = Format.DKVP, out = Format.DKVP;
    boolean implicitHeader=false, headerlessOut=false, quoteAll=false;
    List<String> fromFiles = new ArrayList<>();
  }
  static class Command {
    String verb; List<String> args = new ArrayList<>();
    Command(String v){verb=v;}
  }
  static class State {
    Config cfg = new Config();
    List<Command> cmds = new ArrayList<>();
    List<String> files = new ArrayList<>();
  }
  static class Rec extends LinkedHashMap<String,String> {
    Rec copy(){ Rec r=new Rec(); r.putAll(this); return r; }
  }

  public static void main(String[] args) throws Exception {
    try {
      int rc = run(args);
      if (rc != 0) System.exit(rc);
    } catch (BrokenPipeException bp) {
      System.exit(0);
    } catch (Exception e) {
      System.err.println("mlr: "+e.getMessage());
      System.exit(1);
    }
  }

  static int run(String[] argv) throws Exception {
    if (argv.length==0 || has(argv,"--help") || has(argv,"-h")) { usage(); return 0; }
    if (argv.length==1 && (argv[0].equals("--version") || argv[0].equals("version"))) {
      if (argv[0].equals("--version")) System.out.println("mlr 6.16.0");
      else System.out.println("mlr version 6.16.0 for linux/amd64/go1.24.0");
      return 0;
    }
    if (argv.length>=1 && argv[0].equals("help")) { help(argv); return 0; }
    State st = parseArgs(argv);
    if (st.cmds.isEmpty()) st.cmds.add(new Command("cat"));
    List<String> inputs = new ArrayList<>();
    inputs.addAll(st.cfg.fromFiles); inputs.addAll(st.files);
    List<Rec> recs = readAll(st.cfg, inputs);
    for (Command c: st.cmds) recs = apply(c, recs);
    writeAll(st.cfg, recs);
    return 0;
  }

  static boolean has(String[] a, String s){ for(String x:a) if(x.equals(s)) return true; return false; }
  static void usage(){
    System.out.println("Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}\n");
    System.out.println("If zero file names are provided, standard input is read, e.g.");
    System.out.println("  mlr --csv sort -f shape example.csv\n");
    System.out.println("Output of one verb may be chained as input to another using \"then\", e.g.");
    System.out.println("  mlr --csv stats1 -a min,mean,max -f quantity then sort -f color example.csv\n");
    System.out.println("Please see 'mlr help topics' for more information.");
    System.out.println("Please also see https://miller.readthedocs.io");
  }
  static void help(String[] argv) {
    if (argv.length>=2 && argv[1].equals("list-verbs")) {
      String[] verbs = {"cat","check","count","count-distinct","cut","filter","group-by","head","label","nothing","put","rename","reorder","sort","stats1","tac","tail","top","uniq"};
      for(String v:verbs) System.out.println(v);
    } else if (argv.length>=2 && argv[1].equals("basic-examples")) {
      System.out.println("mlr --icsv --opprint cat example.csv");
      System.out.println("mlr --icsv --opprint sort -f shape example.csv");
      System.out.println("mlr --icsv --opprint sort -f shape -nr index example.csv");
      System.out.println("mlr --icsv --opprint cut -f flag,shape example.csv");
      System.out.println("mlr --csv filter '$color == \"red\"' example.csv");
      System.out.println("mlr --icsv --ojson put '$ratio = $quantity / $rate' example.csv");
    } else {
      System.out.println("Type 'mlr help {topic}' for any of the following:");
      System.out.println("Essentials:\n  mlr help topics\n  mlr help basic-examples\n  mlr help file-formats");
      System.out.println("Verbs:\n  mlr help list-verbs\n  mlr help usage-verbs\n  mlr help verb");
    }
  }

  static State parseArgs(String[] argv) {
    State st=new State();
    Set<String> verbs = new HashSet<>(Arrays.asList("cat","cut","sort","filter","put","stats1","count","head","tail","tac","uniq","group-by","rename","reorder","label","nothing","top","count-distinct","check"));
    int i=0; Command cur=null; boolean seenVerb=false;
    while(i<argv.length){
      String a=argv[i];
      if (a.equals("then")) { cur=null; seenVerb=false; i++; continue; }
      if (!seenVerb && verbs.contains(a)) { cur=new Command(a); st.cmds.add(cur); seenVerb=true; i++; continue; }
      if (!seenVerb && a.startsWith("-")) {
        i = parseGlobal(st.cfg, argv, i);
      } else if (seenVerb) {
        if (looksLikeFile(a) && (cur==null || !optionNeedsValue(prev(argv,i)))) st.files.add(a);
        else cur.args.add(a);
        i++;
      } else { st.files.add(a); i++; }
    }
    return st;
  }
  static String prev(String[] a,int i){return i>0?a[i-1]:"";}
  static boolean optionNeedsValue(String p){return Arrays.asList("-f","-g","-a","-n","-r","-e","--from","-i","-o").contains(p);}
  static boolean looksLikeFile(String s){ return !s.startsWith("-") && (Files.exists(Paths.get(s)) || s.matches(".*\\.[A-Za-z0-9_.-]+")); }
  static int parseGlobal(Config c, String[] a, int i) {
    String x=a[i];
    switch(x){
      case "--csv": case "-c": case "--c2c": c.in=Format.CSV; c.out=Format.CSV; return i+1;
      case "--tsv": case "-t": case "--t2t": c.in=Format.TSV; c.out=Format.TSV; return i+1;
      case "--dkvp": case "--d2d": c.in=Format.DKVP; c.out=Format.DKVP; return i+1;
      case "--json": case "-j": case "--j2j": c.in=Format.JSON; c.out=Format.JSON; return i+1;
      case "--jsonl": case "--l2l": c.in=Format.JSONL; c.out=Format.JSONL; return i+1;
      case "--nidx": case "--n2n": c.in=Format.NIDX; c.out=Format.NIDX; return i+1;
      case "--pprint": case "--p2p": c.in=Format.PPRINT; c.out=Format.PPRINT; return i+1;
      case "--icsv": c.in=Format.CSV; return i+1; case "--ocsv": c.out=Format.CSV; return i+1;
      case "--itsv": c.in=Format.TSV; return i+1; case "--otsv": c.out=Format.TSV; return i+1;
      case "--idkvp": c.in=Format.DKVP; return i+1; case "--odkvp": c.out=Format.DKVP; return i+1;
      case "--ijson": c.in=Format.JSON; return i+1; case "--ojson": c.out=Format.JSON; return i+1;
      case "--ijsonl": c.in=Format.JSONL; return i+1; case "--ojsonl": c.out=Format.JSONL; return i+1;
      case "--inidx": c.in=Format.NIDX; return i+1; case "--onidx": c.out=Format.NIDX; return i+1;
      case "--ipprint": c.in=Format.PPRINT; return i+1; case "--opprint": c.out=Format.PPRINT; return i+1;
      case "--implicit-csv-header": case "--headerless-csv-input": case "--hi": c.implicitHeader=true; return i+1;
      case "--headerless-csv-output": case "--ho": c.headerlessOut=true; return i+1;
      case "-N": c.implicitHeader=true; c.headerlessOut=true; return i+1;
      case "--quote-all": c.quoteAll=true; return i+1;
      case "--from": if(i+1<a.length) c.fromFiles.add(a[i+1]); return i+2;
      case "-i": if(i+1<a.length) c.in=parseFormat(a[i+1]); return i+2;
      case "-o": if(i+1<a.length) c.out=parseFormat(a[i+1]); return i+2;
      default: return i+1;
    }
  }
  static Format parseFormat(String s){
    switch(s){case"csv":return Format.CSV;case"tsv":return Format.TSV;case"dkvp":return Format.DKVP;case"json":return Format.JSON;case"jsonl":return Format.JSONL;case"pprint":return Format.PPRINT;case"nidx":return Format.NIDX;default:return Format.DKVP;}
  }

  static List<Rec> readAll(Config cfg, List<String> files) throws IOException {
    List<String> lines=new ArrayList<>();
    if(files.isEmpty()) readLines(new BufferedReader(new InputStreamReader(System.in,StandardCharsets.UTF_8)), lines);
    else for(String f:files) readLines(Files.newBufferedReader(Paths.get(f),StandardCharsets.UTF_8), lines);
    return parseRecords(cfg, lines);
  }
  static void readLines(BufferedReader br, List<String> out) throws IOException { try(br){String l; while((l=br.readLine())!=null) out.add(l);} }
  static List<Rec> parseRecords(Config cfg, List<String> lines) {
    switch(cfg.in){
      case CSV: return parseDelimited(lines, ',', cfg.implicitHeader);
      case TSV: return parseDelimited(lines, '\t', cfg.implicitHeader);
      case NIDX: return parseNidx(lines);
      case PPRINT: return parsePprint(lines);
      case JSON: case JSONL: return parseJson(lines);
      default: return parseDkvp(lines);
    }
  }
  static List<Rec> parseDkvp(List<String> lines){
    List<Rec> rs=new ArrayList<>();
    for(String line:lines){ if(line.isEmpty()) continue; Rec r=new Rec(); int pos=1; for(String p: splitSimple(line, ',')){ int eq=p.indexOf('='); if(eq>=0) r.put(p.substring(0,eq), p.substring(eq+1)); else r.put(String.valueOf(pos), p); pos++; } rs.add(r); }
    return rs;
  }
  static List<Rec> parseNidx(List<String> lines){ List<Rec> rs=new ArrayList<>(); for(String l:lines){ if(l.isEmpty())continue; Rec r=new Rec(); String[] ps=l.trim().split("\\s+"); for(int i=0;i<ps.length;i++) r.put(""+(i+1),ps[i]); rs.add(r);} return rs; }
  static List<Rec> parseDelimited(List<String> lines, char sep, boolean implicit){
    List<Rec> rs=new ArrayList<>(); if(lines.isEmpty()) return rs; List<String> hdr; int start;
    if(implicit){ hdr=null; start=0; } else { hdr=parseCsvLine(lines.get(0),sep); start=1; }
    for(int li=start;li<lines.size();li++){ String line=lines.get(li); if(line.isEmpty()) continue; List<String> vals=parseCsvLine(line,sep); Rec r=new Rec(); for(int i=0;i<vals.size();i++){ String k=implicit?String.valueOf(i+1):(i<hdr.size()?hdr.get(i):String.valueOf(i+1)); r.put(k, vals.get(i)); } if(!implicit && hdr!=null) for(String h:hdr) r.putIfAbsent(h,""); rs.add(r); }
    return rs;
  }
  static List<String> parseCsvLine(String s, char sep){
    List<String> out=new ArrayList<>(); StringBuilder b=new StringBuilder(); boolean q=false;
    for(int i=0;i<s.length();i++){ char c=s.charAt(i); if(q){ if(c=='"'){ if(i+1<s.length()&&s.charAt(i+1)=='"'){b.append('"');i++;} else q=false;} else b.append(c); } else { if(c=='"') q=true; else if(c==sep){out.add(b.toString());b.setLength(0);} else b.append(c);} }
    out.add(b.toString()); return out;
  }
  static List<Rec> parsePprint(List<String> lines){ return parseDelimitedWhitespace(lines); }
  static List<Rec> parseDelimitedWhitespace(List<String> lines){
    List<Rec> rs=new ArrayList<>(); if(lines.isEmpty())return rs; String[] hdr=lines.get(0).trim().split("\\s+");
    for(int i=1;i<lines.size();i++){ if(lines.get(i).trim().isEmpty())continue; String[] vals=lines.get(i).trim().split("\\s+"); Rec r=new Rec(); for(int j=0;j<hdr.length;j++) r.put(hdr[j], j<vals.length?vals[j]:""); rs.add(r);} return rs;
  }
  static List<Rec> parseJson(List<String> lines) {
    String s=String.join("\n",lines).trim(); List<Rec> rs=new ArrayList<>(); if(s.isEmpty()) return rs;
    Matcher obj=Pattern.compile("\\{([^{}]*)\\}",Pattern.DOTALL).matcher(s);
    while(obj.find()){ Rec r=new Rec(); Matcher kv=Pattern.compile("\"([^\"]+)\"\\s*:\\s*(\"(?:\\\\.|[^\"])*\"|[-+0-9.eE]+|true|false|null)").matcher(obj.group(1)); while(kv.find()){ String v=kv.group(2); if(v.startsWith("\"")) v=unescape(v.substring(1,v.length()-1)); r.put(kv.group(1), v); } if(!r.isEmpty())rs.add(r); }
    return rs;
  }
  static List<String> splitSimple(String s, char sep){ List<String> r=new ArrayList<>(); int st=0; for(int i=0;i<s.length();i++) if(s.charAt(i)==sep){r.add(s.substring(st,i));st=i+1;} r.add(s.substring(st)); return r; }

  static List<Rec> apply(Command c, List<Rec> in) {
    switch(c.verb){
      case "cat": case "check": return in;
      case "nothing": return new ArrayList<>();
      case "cut": return cut(c.args,in);
      case "sort": return sort(c.args,in);
      case "filter": return filter(c.args,in);
      case "put": return put(c.args,in);
      case "stats1": return stats1(c.args,in);
      case "count": return count(c.args,in);
      case "head": return headtail(c.args,in,true);
      case "tail": return headtail(c.args,in,false);
      case "tac": List<Rec> r=new ArrayList<>(in); Collections.reverse(r); return r;
      case "uniq": return uniq(c.args,in);
      case "group-by": return groupBy(c.args,in);
      case "rename": return rename(c.args,in);
      case "reorder": return reorder(c.args,in);
      case "label": return label(c.args,in);
      case "top": return top(c.args,in);
      case "count-distinct": return countDistinct(c.args,in);
      default: return in;
    }
  }
  static List<String> optList(List<String>a,String opt){ for(int i=0;i<a.size()-1;i++) if(a.get(i).equals(opt)) return Arrays.asList(a.get(i+1).split(",")); return new ArrayList<>(); }
  static int optInt(List<String>a,String opt,int d){ for(int i=0;i<a.size()-1;i++) if(a.get(i).equals(opt)) try{return Integer.parseInt(a.get(i+1));}catch(Exception e){} return d; }
  static List<Rec> cut(List<String>a,List<Rec>in){ List<String> fs=optList(a,"-f"); boolean x=a.contains("-x")||a.contains("--complement"); List<Rec> out=new ArrayList<>(); for(Rec r:in){Rec n=new Rec(); if(x){for(String k:r.keySet())if(!fs.contains(k))n.put(k,r.get(k));}else for(String f:fs) if(r.containsKey(f)) n.put(f,r.get(f)); out.add(n);} return out; }
  static class SortKey { String f; boolean numeric, reverse; SortKey(String f, boolean n, boolean r){this.f=f;numeric=n;reverse=r;} }
  static List<Rec> sort(List<String>a,List<Rec>in){ List<SortKey> keys=new ArrayList<>(); boolean globalReverse=false; for(int i=0;i<a.size();i++){String x=a.get(i); if((x.equals("-f")||x.equals("-n")||x.equals("-nr"))&&i+1<a.size()){ boolean n=!x.equals("-f"), rev=x.equals("-nr"); for(String f:a.get(++i).split(",")) keys.add(new SortKey(f,n,rev)); } else if(x.equals("-r")) globalReverse=true; }
    final boolean grev=globalReverse; final List<SortKey> fkeys=new ArrayList<>(keys);
    List<Rec> out=new ArrayList<>(in); out.sort((r1,r2)->{ for(SortKey k:fkeys){ int cmp; if(k.numeric) cmp=Double.compare(num(r1.get(k.f)),num(r2.get(k.f))); else cmp=String.valueOf(r1.getOrDefault(k.f,"")).compareTo(String.valueOf(r2.getOrDefault(k.f,""))); if(cmp!=0) return (k.reverse^grev)?-cmp:cmp;} return 0;}); return out; }
  static List<Rec> filter(List<String>a,List<Rec>in){ String expr=String.join(" ",a); List<Rec> out=new ArrayList<>(); for(Rec r:in) if(evalBool(expr,r)) out.add(r); return out; }
  static List<Rec> put(List<String>a,List<Rec>in){ String s=String.join(" ",a); List<String> stmts=splitSimple(s,';'); List<Rec> out=new ArrayList<>(); for(Rec r:in){Rec n=r.copy(); for(String st:stmts){int eq=st.indexOf('='); if(eq>0){String lhs=st.substring(0,eq).trim(); if(lhs.startsWith("$")) lhs=lhs.substring(1); Object v=evalValue(st.substring(eq+1).trim(),n); n.put(lhs, fmt(v));}} out.add(n);} return out; }
  static List<Rec> count(List<String>a,List<Rec>in){ List<String> gs=optList(a,"-g"); LinkedHashMap<String,Integer> m=new LinkedHashMap<>(); LinkedHashMap<String,Rec> gr=new LinkedHashMap<>(); for(Rec r:in){String key=key(r,gs); m.put(key,m.getOrDefault(key,0)+1); gr.putIfAbsent(key, groupRec(r,gs));} List<Rec> out=new ArrayList<>(); if(gs.isEmpty()){Rec r=new Rec();r.put("count",""+in.size());out.add(r);} else for(String k:m.keySet()){Rec r=gr.get(k).copy();r.put("count",""+m.get(k));out.add(r);} return out; }
  static List<Rec> stats1(List<String>a,List<Rec>in){ List<String> acc=optList(a,"-a"), fs=optList(a,"-f"), gs=optList(a,"-g"); if(acc.isEmpty()) acc=Arrays.asList("count"); LinkedHashMap<String,List<Rec>> groups=new LinkedHashMap<>(); LinkedHashMap<String,Rec> grecs=new LinkedHashMap<>(); for(Rec r:in){String k=key(r,gs); groups.computeIfAbsent(k,z->new ArrayList<>()).add(r); grecs.putIfAbsent(k,groupRec(r,gs));} List<Rec> out=new ArrayList<>(); for(String k:groups.keySet()){Rec o=grecs.get(k).copy(); List<Rec> rows=groups.get(k); for(String f:fs){ for(String ac:acc){ List<Double> vs=new ArrayList<>(); for(Rec r:rows) if(r.containsKey(f)) vs.add(num(r.get(f))); String name=f+"_"+ac; if(ac.equals("count")) o.put(name,""+vs.size()); else if(!vs.isEmpty()){ if(ac.equals("sum")) o.put(name,fmt(sum(vs))); else if(ac.equals("mean")) o.put(name,fmt(sum(vs)/vs.size())); else if(ac.equals("min")) o.put(name,fmt(Collections.min(vs))); else if(ac.equals("max")) o.put(name,fmt(Collections.max(vs))); } } } out.add(o);} return out; }
  static List<Rec> headtail(List<String>a,List<Rec>in,boolean head){ int n=optInt(a,"-n",10); if(n>in.size())n=in.size(); return new ArrayList<>(head?in.subList(0,n):in.subList(in.size()-n,in.size())); }
  static List<Rec> uniq(List<String>a,List<Rec>in){ LinkedHashSet<String> seen=new LinkedHashSet<>(); List<Rec> out=new ArrayList<>(); for(Rec r:in){String k=r.toString(); if(seen.add(k))out.add(r);} return out; }
  static List<Rec> groupBy(List<String>a,List<Rec>in){ List<String> fs=optList(a,"-f"); List<Rec> out=new ArrayList<>(); LinkedHashSet<String> seen=new LinkedHashSet<>(); for(Rec r:in){String k=key(r,fs); if(seen.add(k)) out.add(groupRec(r,fs));} return out; }
  static List<Rec> rename(List<String>a,List<Rec>in){ List<String> ps=optList(a,"-f"); Map<String,String> map=new HashMap<>(); for(String p:ps){String[] q=p.split(",",2); if(q.length==2)map.put(q[0],q[1]);} List<Rec> out=new ArrayList<>(); for(Rec r:in){Rec n=new Rec(); for(String k:r.keySet()) n.put(map.getOrDefault(k,k),r.get(k)); out.add(n);} return out; }
  static List<Rec> reorder(List<String>a,List<Rec>in){ List<String> fs=optList(a,"-f"); List<Rec> out=new ArrayList<>(); for(Rec r:in){Rec n=new Rec(); for(String f:fs) if(r.containsKey(f))n.put(f,r.get(f)); for(String k:r.keySet()) if(!n.containsKey(k))n.put(k,r.get(k)); out.add(n);} return out; }
  static List<Rec> label(List<String>a,List<Rec>in){ List<String> names=new ArrayList<>(); for(String x:a) names.addAll(Arrays.asList(x.split(","))); List<Rec> out=new ArrayList<>(); for(Rec r:in){Rec n=new Rec(); int i=0; for(String k:r.keySet()) n.put(i<names.size()?names.get(i++):k,r.get(k)); out.add(n);} return out; }
  static List<Rec> top(List<String>a,List<Rec>in){ List<Rec>s=sort(Arrays.asList("-nr", optList(a,"-f").isEmpty()?"":optList(a,"-f").get(0)),in); return headtail(a,s,true); }
  static List<Rec> countDistinct(List<String>a,List<Rec>in){ return count(a, groupBy(a,in)); }
  static Rec groupRec(Rec r,List<String>gs){ Rec g=new Rec(); for(String f:gs) g.put(f,r.getOrDefault(f,"")); return g; }
  static String key(Rec r,List<String>fs){ StringBuilder b=new StringBuilder(); for(String f:fs)b.append(r.getOrDefault(f,"")).append('\u0001'); return b.toString(); }

  static boolean evalBool(String e, Rec r){ e=e.trim(); String[] ops={"==","!=",">=","<=",">","<"," =~ "," !=~ "}; for(String op:ops){ int p=e.indexOf(op.trim()); if(p>0){Object l=evalValue(e.substring(0,p).trim(),r), rr=evalValue(e.substring(p+op.trim().length()).trim(),r); int cmp=Double.isNaN(asNum(l))||Double.isNaN(asNum(rr))?String.valueOf(l).compareTo(String.valueOf(rr)):Double.compare(asNum(l),asNum(rr)); switch(op.trim()){case"==":return String.valueOf(l).equals(String.valueOf(rr));case"!=":return !String.valueOf(l).equals(String.valueOf(rr));case">":return cmp>0;case"<":return cmp<0;case">=":return cmp>=0;case"<=":return cmp<=0;case"=~":return Pattern.compile(String.valueOf(rr)).matcher(String.valueOf(l)).find();case"!=~":return !Pattern.compile(String.valueOf(rr)).matcher(String.valueOf(l)).find();}}} return truth(evalValue(e,r)); }
  static Object evalValue(String e, Rec r){ e=e.trim(); if(e.startsWith("\"")&&e.endsWith("\"")) return unescape(e.substring(1,e.length()-1)); if(e.startsWith("'")&&e.endsWith("'")) return e.substring(1,e.length()-1); if(e.matches("\\$[A-Za-z0-9_.]+")) return r.getOrDefault(e.substring(1),""); try{return Double.parseDouble(e);}catch(Exception ex){} return evalArith(e,r); }
  static Object evalArith(String e, Rec r){ List<String> toks=tokenize(e); if(toks.isEmpty())return ""; double val=parseExpr(new int[]{0},toks,r); return val; }
  static List<String> tokenize(String s){ List<String> t=new ArrayList<>(); Matcher m=Pattern.compile("\\$[A-Za-z0-9_.]+|[-+*/()]|[-+]?[0-9]+(?:\\.[0-9]+)?(?:[eE][-+]?[0-9]+)?").matcher(s); while(m.find())t.add(m.group()); return t; }
  static double parseExpr(int[]i,List<String>t,Rec r){ double v=parseTerm(i,t,r); while(i[0]<t.size()&&(t.get(i[0]).equals("+")||t.get(i[0]).equals("-"))){String op=t.get(i[0]++); double w=parseTerm(i,t,r); v=op.equals("+")?v+w:v-w;} return v; }
  static double parseTerm(int[]i,List<String>t,Rec r){ double v=parseFactor(i,t,r); while(i[0]<t.size()&&(t.get(i[0]).equals("*")||t.get(i[0]).equals("/"))){String op=t.get(i[0]++); double w=parseFactor(i,t,r); v=op.equals("*")?v*w:v/w;} return v; }
  static double parseFactor(int[]i,List<String>t,Rec r){ if(i[0]>=t.size())return 0; String x=t.get(i[0]++); if(x.equals("(")){double v=parseExpr(i,t,r); if(i[0]<t.size())i[0]++; return v;} if(x.equals("-"))return -parseFactor(i,t,r); if(x.startsWith("$"))return num(r.get(x.substring(1))); return num(x); }
  static boolean truth(Object o){ String s=String.valueOf(o); return !(s.isEmpty()||s.equals("false")||s.equals("0")); }
  static double asNum(Object o){ try{return Double.parseDouble(String.valueOf(o));}catch(Exception e){return Double.NaN;} }
  static double num(String s){ try{return Double.parseDouble(s);}catch(Exception e){return 0;} }
  static double sum(List<Double>vs){ double s=0; for(double v:vs)s+=v; return s; }
  static String fmt(Object o){ if(o instanceof Double){ double d=(Double)o; if(Math.rint(d)==d && Math.abs(d)<9e15) return String.valueOf((long)d); return Double.toString(d);} return String.valueOf(o); }

  static void writeAll(Config cfg, List<Rec> rs) throws IOException {
    switch(cfg.out){ case CSV: writeDelim(rs,',',cfg); break; case TSV: writeDelim(rs,'\t',cfg); break; case PPRINT: writePprint(rs); break; case JSON: writeJson(rs,false); break; case JSONL: writeJson(rs,true); break; case NIDX: writeNidx(rs); break; default: writeDkvp(rs); }
  }
  static List<String> unionKeys(List<Rec>rs){ LinkedHashSet<String> ks=new LinkedHashSet<>(); for(Rec r:rs)ks.addAll(r.keySet()); return new ArrayList<>(ks); }
  static void writeDelim(List<Rec>rs,char sep,Config cfg){ if(rs.isEmpty())return; List<String> ks=unionKeys(rs); if(!cfg.headerlessOut) System.out.println(joinEsc(ks,sep,cfg)); for(Rec r:rs){List<String> vs=new ArrayList<>(); for(String k:ks)vs.add(r.getOrDefault(k,"")); System.out.println(joinEsc(vs,sep,cfg));} }
  static String joinEsc(List<String>xs,char sep,Config cfg){ List<String> out=new ArrayList<>(); for(String s:xs)out.add(csvEsc(s,sep,cfg.quoteAll)); return String.join(String.valueOf(sep),out); }
  static String csvEsc(String s,char sep,boolean qa){ boolean q=qa||s.indexOf(sep)>=0||s.contains("\"")||s.contains("\n")||s.contains("\r"); return q?"\""+s.replace("\"","\"\"")+"\"":s; }
  static void writeDkvp(List<Rec>rs){ for(Rec r:rs){List<String> ps=new ArrayList<>(); for(String k:r.keySet())ps.add(k+"="+r.get(k)); System.out.println(String.join(",",ps));} }
  static void writeNidx(List<Rec>rs){ for(Rec r:rs) System.out.println(String.join(" ",r.values())); }
  static void writePprint(List<Rec>rs){ if(rs.isEmpty())return; List<String> ks=unionKeys(rs); int[] w=new int[ks.size()]; for(int i=0;i<ks.size();i++)w[i]=ks.get(i).length(); for(Rec r:rs)for(int i=0;i<ks.size();i++)w[i]=Math.max(w[i],r.getOrDefault(ks.get(i),"").length()); printCols(ks,w); for(Rec r:rs){List<String> vs=new ArrayList<>(); for(String k:ks)vs.add(r.getOrDefault(k,"")); printCols(vs,w);} }
  static void printCols(List<String>xs,int[]w){ StringBuilder b=new StringBuilder(); for(int i=0;i<xs.size();i++){ if(i>0)b.append(' '); b.append(xs.get(i)); if(i<xs.size()-1) for(int j=xs.get(i).length();j<w[i];j++) b.append(' ');} System.out.println(b); }
  static void writeJson(List<Rec>rs, boolean lines){ if(!lines)System.out.println("["); for(int i=0;i<rs.size();i++){ String obj=lines?jsonObjCompact(rs.get(i)):jsonObj(rs.get(i),""); if(lines)System.out.println(obj); else {System.out.println(obj+(i<rs.size()-1?",":""));} } if(!lines)System.out.println("]"); }
  static String jsonObj(Rec r,String ind){ StringBuilder b=new StringBuilder(); b.append(ind).append("{"); int i=0; for(String k:r.keySet()){ if(i++>0)b.append(","); if(ind.isEmpty()) b.append("\n  "); else b.append("\n").append(ind).append("  "); b.append("\"").append(esc(k)).append("\": "); String v=r.get(k); if(isNum(v)||v.equals("true")||v.equals("false")||v.equals("null")) b.append(v); else b.append("\"").append(esc(v)).append("\""); } b.append("\n").append(ind).append("}"); return b.toString(); }
  static String jsonObjCompact(Rec r){ StringBuilder b=new StringBuilder("{"); int i=0; for(String k:r.keySet()){ if(i++>0)b.append(","); b.append("\"").append(esc(k)).append("\": "); String v=r.get(k); if(isNum(v)||v.equals("true")||v.equals("false")||v.equals("null")) b.append(v); else b.append("\"").append(esc(v)).append("\""); } return b.append("}").toString(); }
  static boolean isNum(String s){ return s.matches("[-+]?(?:[0-9]+\\.?[0-9]*|\\.[0-9]+)(?:[eE][-+]?[0-9]+)?"); }
  static String esc(String s){ return s.replace("\\","\\\\").replace("\"","\\\""); }
  static String unescape(String s){ return s.replace("\\\"","\"").replace("\\\\","\\"); }
}

class BrokenPipeException extends IOException {}
