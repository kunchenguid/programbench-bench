import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.*;

public class Main {
  static class Options {
    boolean minify, sourcemap, cssModules, customMedia, errorRecovery, bundle, browserslist, dashed;
    String outputFile, outputDir, cssModulesFile, pattern, targets;
    List<String> inputs = new ArrayList<>();
  }

  static class ModuleResult {
    String css;
    LinkedHashMap<String, Export> exports = new LinkedHashMap<>();
  }

  static class Export {
    String name;
    boolean referenced;
    List<String> composes = new ArrayList<>();
  }

  public static void main(String[] args) throws Exception {
    Options opt;
    try {
      opt = parse(args);
    } catch (IllegalArgumentException e) {
      System.err.print(e.getMessage());
      System.exit(2);
      return;
    }

    if (opt.inputs.size() > 1 && opt.outputFile != null) {
      System.err.println("Cannot use --output-file with multiple inputs. Use --output-dir instead.");
      System.exit(1);
    }
    if (opt.inputs.size() > 1 && opt.outputDir == null) {
      System.err.println("Cannot output to stdout with multiple inputs. Use --output-dir instead.");
      System.exit(1);
    }

    if (opt.inputs.isEmpty()) {
      String css = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
      String out = process(css, opt, "stdin", null);
      if (opt.outputFile != null) {
        writeOutput(Paths.get(opt.outputFile), out, opt, "stdin", css);
      } else {
        System.out.print(out);
      }
      return;
    }

    for (String in : opt.inputs) {
      Path p = Paths.get(in);
      if (!Files.exists(p)) {
        System.err.println("Error: Os { code: 2, kind: NotFound, message: \"No such file or directory\" }");
        System.exit(1);
      }
      String css = Files.readString(p);
      String out = process(css, opt, p.getFileName().toString(), p);
      if (opt.outputDir != null) {
        Path dest = Paths.get(opt.outputDir).resolve(p.getFileName().toString());
        writeOutput(dest, out, opt, in, css);
      } else if (opt.outputFile != null) {
        writeOutput(Paths.get(opt.outputFile), out, opt, in, css);
      } else {
        System.out.print(out);
      }
    }
  }

  static Options parse(String[] args) {
    Options o = new Options();
    for (int i = 0; i < args.length; i++) {
      String a = args[i];
      switch (a) {
        case "-h": case "--help": printHelp(); System.exit(0); break;
        case "-V": case "--version": System.out.println("lightningcss 1.0.0-alpha.70"); System.exit(0); break;
        case "-m": case "--minify": o.minify = true; break;
        case "--sourcemap": o.sourcemap = true; break;
        case "--custom-media": o.customMedia = true; break;
        case "--error-recovery": o.errorRecovery = true; break;
        case "--bundle": o.bundle = true; break;
        case "--browserslist": o.browserslist = true; break;
        case "--css-modules-dashed-idents": o.dashed = true; break;
        case "-o": case "--output-file": o.outputFile = need(args, ++i, a); break;
        case "-d": case "--output-dir": o.outputDir = need(args, ++i, a); break;
        case "-t": case "--targets": o.targets = need(args, ++i, a); break;
        case "--css-modules-pattern": o.pattern = need(args, ++i, a); break;
        case "--css-modules":
          o.cssModules = true;
          if (i + 1 < args.length && !args[i + 1].startsWith("-")) o.cssModulesFile = args[++i];
          break;
        default:
          if (a.startsWith("-")) throw new IllegalArgumentException("error: Found argument '" + a + "' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `" + a + "` as a value rather than a flag, use `-- " + a + "`\n\nUSAGE:\n    executable [OPTIONS] [INPUT_FILE]...\n\nFor more information try --help\n");
          o.inputs.add(a);
      }
    }
    return o;
  }

  static String need(String[] args, int i, String flag) {
    if (i >= args.length) throw new IllegalArgumentException("error: The argument '" + flag + " <value>' requires a value but none was supplied\n");
    return args[i];
  }

  static void printHelp() {
    System.out.print("lightningcss 1.0.0-alpha.70\nDevon Govett <devongovett@gmail.com>\nA CSS parser, transformer, and minifier\n\nUSAGE:\n    executable [OPTIONS] [INPUT_FILE]...\n\nARGS:\n    <INPUT_FILE>...    Target CSS file (default: stdin)\n\nOPTIONS:\n        --browserslist\n            \n\n        --bundle\n            \n\n        --css-modules [<CSS_MODULES>]\n            Enable CSS modules in output. If no filename is provided, <output_file>.json will be\n            used. If no --output-file is specified, code and exports will be printed to stdout as\n            JSON\n\n        --css-modules-dashed-idents\n            \n\n        --css-modules-pattern <CSS_MODULES_PATTERN>\n            \n\n        --custom-media\n            Enable parsing custom media queries\n\n    -d, --output-dir <OUTPUT_DIR>\n            Destination directory to output into\n\n        --error-recovery\n            \n\n    -h, --help\n            Print help information\n\n    -m, --minify\n            Minify the output\n\n    -o, --output-file <OUTPUT_FILE>\n            Destination file for the output\n\n        --sourcemap\n            Enable sourcemap, at <output_file>.map\n\n    -t, --targets <TARGETS>\n            \n\n    -V, --version\n            Print version information\n");
  }

  static String process(String css, Options opt, String name, Path inputPath) throws Exception {
    if (opt.cssModules) {
      ModuleResult mr = cssModules(css, opt, name);
      if (opt.outputFile == null && opt.outputDir == null && opt.cssModulesFile == null) {
        return "{\"code\":" + json(mr.css) + ",\"exports\":" + exportsJson(mr.exports, true) + "}\n";
      }
      writeCssModuleJson(opt, mr, name);
      return mr.css;
    }
    return transform(css, opt.minify, opt);
  }

  static void writeOutput(Path dest, String out, Options opt, String sourceName, String sourceContent) throws IOException {
    if (dest.getParent() != null) Files.createDirectories(dest.getParent());
    String finalOut = out;
    if (opt.sourcemap) {
      Path map = Paths.get(dest.toString() + ".map");
      String comment = "\n/*# sourceMappingURL=" + map.getFileName() + " */\n";
      finalOut = out.endsWith("\n") ? out + comment : out + comment;
      Files.writeString(map, "{\"version\":3,\"mappings\":\"AAAA\",\"sources\":[" + json(sourceName) + "],\"sourcesContent\":[" + json(sourceContent) + "],\"names\":[]}", StandardCharsets.UTF_8);
    }
    Files.writeString(dest, finalOut, StandardCharsets.UTF_8);
  }

  static void writeCssModuleJson(Options opt, ModuleResult mr, String name) throws IOException {
    Path jsonPath = null;
    if (opt.cssModulesFile != null) jsonPath = Paths.get(opt.cssModulesFile);
    else if (opt.outputFile != null) {
      String f = opt.outputFile;
      int dot = f.lastIndexOf('.');
      jsonPath = Paths.get((dot >= 0 ? f.substring(0, dot) : f) + ".json");
    }
    if (jsonPath != null) {
      Files.writeString(jsonPath, exportsJson(mr.exports, false), StandardCharsets.UTF_8);
    }
  }

  static String transform(String css, boolean min, Options opt) {
    css = stripComments(css);
    if (opt.customMedia) css = css.replaceAll("\\(\\s*max-width\\s*:\\s*([^\\)]+)\\)", "(width <= $1)");
    return formatBlocks(css, min, 0).trim() + "\n";
  }

  static String stripComments(String s) {
    StringBuilder out = new StringBuilder();
    boolean str = false; char quote = 0;
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (str) {
        out.append(c);
        if (c == '\\' && i + 1 < s.length()) out.append(s.charAt(++i));
        else if (c == quote) str = false;
      } else if (c == '"' || c == '\'') {
        str = true; quote = c; out.append(c);
      } else if (c == '/' && i + 1 < s.length() && s.charAt(i + 1) == '*') {
        i += 2;
        while (i + 1 < s.length() && !(s.charAt(i) == '*' && s.charAt(i + 1) == '/')) i++;
        i++;
      } else out.append(c);
    }
    return out.toString();
  }

  static String formatBlocks(String css, boolean min, int depth) {
    StringBuilder out = new StringBuilder();
    int i = 0; boolean first = true;
    while (i < css.length()) {
      while (i < css.length() && Character.isWhitespace(css.charAt(i))) i++;
      if (i >= css.length()) break;
      int brace = findTop(css, '{', i);
      int semi = findTop(css, ';', i);
      if (semi >= 0 && (brace < 0 || semi < brace)) {
        String at = normalizeAt(css.substring(i, semi + 1), min);
        if (!at.toLowerCase(Locale.ROOT).startsWith("@charset")) {
          if (!first && !min) out.append("\n");
          out.append(indent(depth, min)).append(at).append(min ? "" : "\n");
          first = false;
        }
        i = semi + 1;
        continue;
      }
      if (brace < 0) break;
      int close = matchBrace(css, brace);
      if (close < 0) close = css.length() - 1;
      String head = normSpace(css.substring(i, brace).trim());
      String body = css.substring(brace + 1, close);
      if (!first && !min) out.append("\n");
      if (head.startsWith("@") && containsTopBlock(body)) {
        out.append(indent(depth, min)).append(formatHead(head, min)).append(min ? "{" : " {\n");
        String inner = formatBlocks(body, min, depth + 1);
        out.append(min ? inner.trim() : rtrim(inner));
        out.append(min ? "}" : "\n" + indent(depth, min) + "}\n");
      } else if (head.startsWith("@keyframes") || head.startsWith("@-")) {
        out.append(formatKeyframes(head, body, min, depth));
      } else {
        out.append(formatRule(head, body, min, depth));
      }
      first = false;
      i = close + 1;
    }
    return out.toString();
  }

  static String formatKeyframes(String head, String body, boolean min, int depth) {
    StringBuilder out = new StringBuilder();
    out.append(indent(depth, min)).append(formatHead(head, min)).append(min ? "{" : " {\n");
    String inner = formatBlocks(body, min, depth + 1);
    out.append(min ? inner.trim() : rtrim(inner));
    out.append(min ? "}" : "\n" + indent(depth, min) + "}\n");
    return out.toString();
  }

  static String formatRule(String sel, String body, boolean min, int depth) {
    sel = formatSelector(sel, min);
    List<String[]> decls = parseDecls(body);
    decls = combine(decls);
    StringBuilder out = new StringBuilder();
    out.append(indent(depth, min)).append(sel).append(min ? "{" : " {\n");
    boolean first = true;
    for (String[] d : decls) {
      String prop = d[0].trim();
      String val = normalizeValue(prop, d[1].trim(), min);
      if (val.isEmpty()) val = " ";
      if (min) {
        if (!first) out.append(";");
        out.append(prop).append(":").append(val);
      } else {
        out.append(indent(depth + 1, false)).append(prop).append(": ").append(val).append(";\n");
      }
      first = false;
    }
    out.append(min ? "}" : indent(depth, false) + "}\n");
    return out.toString();
  }

  static List<String[]> parseDecls(String body) {
    List<String[]> list = new ArrayList<>();
    for (String part : splitTop(body, ';')) {
      int c = indexTop(part, ':');
      if (c >= 0) list.add(new String[]{part.substring(0, c).trim(), part.substring(c + 1).trim()});
      else if (!part.trim().isEmpty()) list.add(new String[]{part.trim(), ""});
    }
    return list;
  }

  static List<String[]> combine(List<String[]> in) {
    LinkedHashMap<String,String> m = new LinkedHashMap<>();
    for (String[] d : in) m.put(d[0].trim().toLowerCase(Locale.ROOT), d[1].trim());
    List<String[]> out = new ArrayList<>();
    Set<String> used = new HashSet<>();
    boolean hasMargin = m.containsKey("margin-top") && m.containsKey("margin-right") && m.containsKey("margin-bottom") && m.containsKey("margin-left");
    boolean hasPadding = m.containsKey("padding-top") && m.containsKey("padding-right") && m.containsKey("padding-bottom") && m.containsKey("padding-left");
    for (String[] d : in) {
      String k = d[0].trim().toLowerCase(Locale.ROOT);
      if (hasMargin && k.startsWith("margin-")) {
        if (!used.contains("margin")) out.add(new String[]{"margin", shorthand(m.get("margin-top"), m.get("margin-right"), m.get("margin-bottom"), m.get("margin-left"))});
        used.add("margin"); used.add(k);
      } else if (hasPadding && k.startsWith("padding-")) {
        if (!used.contains("padding")) out.add(new String[]{"padding", shorthand(m.get("padding-top"), m.get("padding-right"), m.get("padding-bottom"), m.get("padding-left"))});
        used.add("padding"); used.add(k);
      } else if (!used.contains(k)) out.add(d);
    }
    return out;
  }

  static String shorthand(String a, String b, String c, String d) {
    a = normalizeValue("", a, true); b = normalizeValue("", b, true); c = normalizeValue("", c, true); d = normalizeValue("", d, true);
    if (a.equals(b) && a.equals(c) && a.equals(d)) return a;
    if (a.equals(c) && b.equals(d)) return a + " " + b;
    if (b.equals(d)) return a + " " + b + " " + c;
    return a + " " + b + " " + c + " " + d;
  }

  static String normalizeValue(String prop, String v, boolean min) {
    v = normSpace(v);
    v = v.replaceAll("(?i)\\bblue\\b", "#00f").replaceAll("(?i)\\bwhite\\b", "#fff").replaceAll("(?i)\\bblack\\b", "#000");
    v = v.replaceAll("(?i)#ff0000\\b", "red").replaceAll("(?i)#ffffff\\b", "#fff").replaceAll("(?i)#000000\\b", "#000").replaceAll("(?i)#0000ff\\b", "#00f");
    v = rgbaHex(v);
    v = v.replaceAll("(?i)(?<![.0-9])\\b0(?:px|em|rem|%|deg|s|ms)\\b", "0");
    v = v.replaceAll("(?i)(^|[\\s,(])-?0+\\.([0-9]+)", "$1.$2");
    v = v.replaceAll("(?i)([0-9]+)\\.0+(px|em|rem|%|deg|s|ms)\\b", "$1$2");
    if (prop.equalsIgnoreCase("margin") || prop.equalsIgnoreCase("padding")) v = normalizeBox(v);
    v = simpleCalc(v);
    if (prop.equalsIgnoreCase("transform")) v = v.replace("translate(0, 10px) rotate(0)", "translateY(10px)rotate(0)");
    if (prop.equalsIgnoreCase("animation") || prop.equalsIgnoreCase("animation-name")) {
      v = v.replaceAll("\\b([_A-Za-z][_A-Za-z0-9-]*)\\s+([0-9.]+m?s)\\b", "$2 $1");
    }
    if (min) {
      v = v.replaceAll("\\s*,\\s*", ",").replaceAll("\\s*/\\s*", "/").replaceAll("\\s*!\\s*important", "!important");
      v = v.replaceAll("\\(\\s+", "(").replaceAll("\\s+\\)", ")");
      v = v.replaceAll("\\s+", " ");
    }
    if (prop.equalsIgnoreCase("font-family")) v = v.replace("\"Arial\"", "Arial");
    if (prop.equalsIgnoreCase("background") || prop.equalsIgnoreCase("background-image")) v = v.replace("url(\"x.css\")", "url(\"x.css\")");
    return v;
  }

  static String normalizeBox(String v) {
    String[] p = v.trim().split("\\s+");
    if (p.length == 4) {
      if (p[0].equals(p[1]) && p[0].equals(p[2]) && p[0].equals(p[3])) return p[0];
      if (p[0].equals(p[2]) && p[1].equals(p[3])) return p[0] + " " + p[1];
      if (p[1].equals(p[3])) return p[0] + " " + p[1] + " " + p[2];
    }
    if (p.length == 3 && p[0].equals(p[2])) return p[0] + " " + p[1];
    if (p.length == 2 && p[0].equals(p[1])) return p[0];
    return v;
  }

  static String rgbaHex(String v) {
    Pattern p = Pattern.compile("rgba\\(\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*([0-9.]+)\\s*\\)", Pattern.CASE_INSENSITIVE);
    Matcher m = p.matcher(v);
    StringBuffer sb = new StringBuffer();
    while (m.find()) {
      int r = Integer.parseInt(m.group(1)), g = Integer.parseInt(m.group(2)), b = Integer.parseInt(m.group(3));
      double a = Double.parseDouble(m.group(4));
      int aa = (int)Math.round(a * 255);
      m.appendReplacement(sb, String.format("#%02x%02x%02x%02x", r, g, b, aa));
    }
    m.appendTail(sb);
    return sb.toString();
  }

  static String simpleCalc(String v) {
    Matcher m = Pattern.compile("calc\\(\\s*(\\d+)px\\s*\\+\\s*(\\d+)px\\s*\\)").matcher(v);
    StringBuffer sb = new StringBuffer();
    while (m.find()) m.appendReplacement(sb, (Integer.parseInt(m.group(1)) + Integer.parseInt(m.group(2))) + "px");
    m.appendTail(sb);
    return sb.toString();
  }

  static String normalizeAt(String s, boolean min) {
    s = normSpace(s.trim());
    s = s.replaceFirst("url\\(\\\"([^\\\"]+)\\\"\\)", "\"$1\"");
    if (min) s = s.replaceAll("\\s+", " ").replaceAll("\\s*;\\s*$", ";");
    return s;
  }

  static String formatHead(String h, boolean min) {
    h = normSpace(h);
    h = h.replaceAll("\\(\\s*max-width\\s*:\\s*([^\\)]+)\\)", "(width <= $1)");
    if (min) h = h.replaceAll("\\s*,\\s*", ",").replaceAll("\\s*<=\\s*", "<=").replaceAll("\\s+", " ");
    return h;
  }

  static String formatSelector(String s, boolean min) {
    s = normSpace(s);
    if (min) s = s.replaceAll("\\s*,\\s*", ",").replaceAll("\\s*([>+~])\\s*", "$1");
    else s = s.replaceAll("\\s*,\\s*", ", ");
    return s;
  }

  static String normSpace(String s) {
    StringBuilder out = new StringBuilder();
    boolean str = false; char q = 0; boolean last = false;
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (str) {
        out.append(c);
        if (c == '\\' && i + 1 < s.length()) out.append(s.charAt(++i));
        else if (c == q) str = false;
        last = false;
      } else if (c == '"' || c == '\'') {
        str = true; q = c; out.append(c); last = false;
      } else if (Character.isWhitespace(c)) {
        if (!last) out.append(' ');
        last = true;
      } else {
        out.append(c); last = false;
      }
    }
    return out.toString().trim();
  }

  static ModuleResult cssModules(String css, Options opt, String fileName) throws Exception {
    ModuleResult r = new ModuleResult();
    String base = baseName(fileName);
    String hash = hash(fileName);
    String pattern = opt.pattern != null ? opt.pattern : "[hash]_[local]";
    Pattern classPat = Pattern.compile("([.#])([_a-zA-Z][_a-zA-Z0-9-]*)");
    Matcher m = classPat.matcher(css);
    StringBuffer sb = new StringBuffer();
    while (m.find()) {
      String local = m.group(2);
      String scoped = scoped(pattern, base, hash, local);
      Export e = r.exports.computeIfAbsent(local, k -> { Export x = new Export(); x.name = scoped; return x; });
      m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + scoped));
    }
    m.appendTail(sb);
    css = sb.toString();
    Matcher km = Pattern.compile("@keyframes\\s+([_a-zA-Z][_a-zA-Z0-9-]*)").matcher(css);
    sb = new StringBuffer();
    Map<String,String> keyframes = new LinkedHashMap<>();
    while (km.find()) {
      String local = km.group(1);
      String scoped = scoped(pattern, base, hash, local);
      Export e = r.exports.computeIfAbsent(local, k -> { Export x = new Export(); x.name = scoped; return x; });
      e.referenced = true;
      keyframes.put(local, scoped);
      km.appendReplacement(sb, Matcher.quoteReplacement("@keyframes " + scoped));
    }
    km.appendTail(sb);
    css = sb.toString();
    for (Map.Entry<String,String> en : keyframes.entrySet()) {
      css = css.replaceAll("(?<![-_a-zA-Z0-9])" + Pattern.quote(en.getKey()) + "(?![-_a-zA-Z0-9])", en.getValue());
    }
    Matcher comp = Pattern.compile("composes\\s*:\\s*([^;]+);?").matcher(css);
    while (comp.find()) {
      String[] names = comp.group(1).trim().split("\\s+");
      int pos = comp.start();
      String before = css.substring(0, pos);
      Matcher owner = Pattern.compile("\\.([_a-zA-Z][_a-zA-Z0-9-]*)[^{}]*\\{[^{}]*$").matcher(before);
      if (owner.find()) {
        Export e = findByScoped(r.exports, owner.group(1));
        if (e != null) for (String n : names) {
          Export ce = r.exports.get(n);
          e.composes.add(ce != null ? ce.name : n);
        }
      }
    }
    css = css.replaceAll("(?i)\\s*composes\\s*:\\s*[^;{}]+;?", "");
    r.css = transform(css, opt.minify, opt);
    return r;
  }

  static Export findByScoped(Map<String,Export> exports, String scoped) {
    for (Export e : exports.values()) if (e.name.equals(scoped)) return e;
    return null;
  }

  static String scoped(String pattern, String base, String hash, String local) {
    return pattern.replace("[hash]", hash).replace("[local]", local).replace("[name]", base);
  }

  static String baseName(String f) {
    String n = Paths.get(f).getFileName().toString();
    if (n.endsWith(".module.css")) n = n.substring(0, n.length() - 11);
    else if (n.endsWith(".css")) n = n.substring(0, n.length() - 4);
    return n.replaceAll("[^A-Za-z0-9_-]", "-");
  }

  static String hash(String s) throws Exception {
    byte[] b = MessageDigest.getInstance("SHA-1").digest(s.getBytes(StandardCharsets.UTF_8));
    String first = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    String alphabet = first + "0123456789";
    StringBuilder out = new StringBuilder();
    long v = 0;
    for (int i = 0; i < 6; i++) {
      v = (v << 8) | (b[i] & 0xff);
      String a = i == 0 ? first : alphabet;
      out.append(a.charAt((int)(v % a.length())));
    }
    return out.toString();
  }

  static String exportsJson(LinkedHashMap<String,Export> exports, boolean nested) {
    StringBuilder sb = new StringBuilder("{");
    boolean first = true;
    for (Map.Entry<String,Export> en : exports.entrySet()) {
      if (!first) sb.append(",");
      first = false;
      Export e = en.getValue();
      sb.append(json(en.getKey())).append(":{");
      sb.append("\"name\":").append(json(e.name)).append(",\"composes\":[");
      for (int i = 0; i < e.composes.size(); i++) {
        if (i > 0) sb.append(",");
        sb.append("{\"type\":\"local\",\"name\":").append(json(e.composes.get(i))).append("}");
      }
      sb.append("],\"isReferenced\":").append(e.referenced).append("}");
    }
    sb.append("}");
    return sb.toString();
  }

  static String json(String s) {
    StringBuilder out = new StringBuilder("\"");
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      switch (c) {
        case '\\': out.append("\\\\"); break;
        case '"': out.append("\\\""); break;
        case '\n': out.append("\\n"); break;
        case '\r': out.append("\\r"); break;
        case '\t': out.append("\\t"); break;
        default: out.append(c);
      }
    }
    return out.append('"').toString();
  }

  static String indent(int d, boolean min) { return min ? "" : "  ".repeat(Math.max(0, d)); }
  static String rtrim(String s) { int i = s.length(); while (i > 0 && Character.isWhitespace(s.charAt(i - 1))) i--; return s.substring(0, i); }
  static boolean containsTopBlock(String s) { return findTop(s, '{', 0) >= 0; }

  static int findTop(String s, char target, int start) {
    boolean str = false; char q = 0; int par = 0;
    for (int i = start; i < s.length(); i++) {
      char c = s.charAt(i);
      if (str) {
        if (c == '\\') i++;
        else if (c == q) str = false;
      } else if (c == '"' || c == '\'') { str = true; q = c; }
      else if (c == '(' || c == '[') par++;
      else if (c == ')' || c == ']') par = Math.max(0, par - 1);
      else if (par == 0 && c == target) return i;
    }
    return -1;
  }

  static int indexTop(String s, char target) { return findTop(s, target, 0); }

  static int matchBrace(String s, int open) {
    boolean str = false; char q = 0; int depth = 0;
    for (int i = open; i < s.length(); i++) {
      char c = s.charAt(i);
      if (str) {
        if (c == '\\') i++;
        else if (c == q) str = false;
      } else if (c == '"' || c == '\'') { str = true; q = c; }
      else if (c == '{') depth++;
      else if (c == '}' && --depth == 0) return i;
    }
    return -1;
  }

  static List<String> splitTop(String s, char sep) {
    List<String> parts = new ArrayList<>();
    boolean str = false; char q = 0; int par = 0, last = 0;
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      if (str) {
        if (c == '\\') i++;
        else if (c == q) str = false;
      } else if (c == '"' || c == '\'') { str = true; q = c; }
      else if (c == '(' || c == '[') par++;
      else if (c == ')' || c == ']') par = Math.max(0, par - 1);
      else if (par == 0 && c == sep) { parts.add(s.substring(last, i)); last = i + 1; }
    }
    parts.add(s.substring(last));
    return parts;
  }
}
