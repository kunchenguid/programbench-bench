import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Lz4Tool {
    static final int MAGIC = 0x184D2204;
    static final int SKIP_MAGIC_BASE = 0x184D2A50;

    static class Opt {
        boolean decompress, compress, stdout, test, force, list, multiple, recursive, quiet, rm;
        boolean contentSize;
        List<String> files = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            int rc = run(args);
            if (rc != 0) System.exit(rc);
        } catch (Exception e) {
            System.err.println("Error 44 : " + e.getMessage());
            System.exit(44);
        }
    }

    static int run(String[] args) throws Exception {
        Opt o = parse(args);
        if (o == null) return 0;
        if (o.list) return doList(o);
        if (o.test) {
            o.decompress = true;
            o.stdout = true;
        }
        if (!o.decompress && !o.compress && !o.files.isEmpty() && o.files.get(0).endsWith(".lz4")) o.decompress = true;
        if (!o.decompress) o.compress = true;
        if (o.multiple || o.files.size() > 2) return multi(o);
        String inName = o.files.size() >= 1 ? o.files.get(0) : "-";
        String outName = o.files.size() >= 2 ? o.files.get(1) : null;
        if (o.stdout || "stdout".equals(outName) || "-".equals(outName)) outName = "-";
        if (o.test || "null".equals(outName)) outName = "null";
        if (o.decompress) return decompressOne(o, inName, outName);
        return compressOne(o, inName, outName);
    }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--help") || a.equals("-h") || a.equals("-H")) { help(); return null; }
            if (a.equals("-V") || a.equals("--version")) { System.out.println("*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***"); return null; }
            if (a.equals("--list")) { o.list = true; continue; }
            if (a.equals("--rm")) { o.rm = true; continue; }
            if (a.equals("--content-size")) { o.contentSize = true; continue; }
            if (a.equals("--no-frame-crc") || a.equals("--sparse") || a.equals("--no-sparse") || a.equals("--best") || a.startsWith("--fast") || a.equals("--favor-decSpeed")) continue;
            if (a.equals("-D") && i + 1 < args.length) { i++; continue; }
            if (a.startsWith("-D") && a.length() > 2) continue;
            if (a.startsWith("--")) continue;
            if (a.startsWith("-") && a.length() > 1 && !a.equals("-")) {
                for (int j = 1; j < a.length(); j++) {
                    char c = a.charAt(j);
                    if (c == 'd') o.decompress = true;
                    else if (c == 'z') o.compress = true;
                    else if (c == 'c') o.stdout = true;
                    else if (c == 't') o.test = true;
                    else if (c == 'f') o.force = true;
                    else if (c == 'k') {}
                    else if (c == 'm') o.multiple = true;
                    else if (c == 'r') { o.recursive = true; o.multiple = true; }
                    else if (c == 'q') o.quiet = true;
                    else if (c == 'B' || c == 'T' || c == 'b' || c == 'e' || c == 'i') break;
                    else if (c >= '0' && c <= '9') {}
                    else if (c == 'l' || c == 'v') {}
                }
            } else o.files.add(a);
        }
        return o;
    }

    static void help() {
        System.out.println("*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***");
        System.out.println("Usage : ");
        System.out.println("      executable [arg] [input] [output] ");
        System.out.println();
        System.out.println("Arguments : ");
        System.out.println(" -1     : fast compression (default) ");
        System.out.println(" -12    : slowest compression level ");
        System.out.println(" -d     : decompression (default for .lz4 extension)");
        System.out.println(" -f     : overwrite output without prompting ");
        System.out.println(" -k     : preserve source files(s)  (default) ");
        System.out.println("--rm    : remove source file(s) after successful de/compression ");
        System.out.println(" -h/-H  : display help/long help and exit ");
        System.out.println(" -c     : force write to standard output, even if it is the console");
        System.out.println(" -t     : test compressed file integrity");
        System.out.println(" -m     : multiple input files (implies automatic output filenames)");
        System.out.println(" -r     : operate recursively on directories (sets also -m) ");
        System.out.println(" -z     : force compression ");
        System.out.println("--list FILE : lists information about .lz4 files");
    }

    static int multi(Opt o) throws Exception {
        List<String> expanded = new ArrayList<>();
        for (String f : o.files) {
            Path p = Paths.get(f);
            if (Files.isDirectory(p) && o.recursive) {
                try (var s = Files.walk(p)) { s.filter(Files::isRegularFile).forEach(x -> expanded.add(x.toString())); }
            } else expanded.add(f);
        }
        for (String f : expanded) {
            if (o.decompress || (!o.compress && f.endsWith(".lz4"))) decompressOne(o, f, null);
            else compressOne(o, f, null);
        }
        return 0;
    }

    static int compressOne(Opt o, String inName, String outName) throws Exception {
        byte[] input = readInput(inName);
        if (outName == null) outName = "-".equals(inName) ? "-" : inName + ".lz4";
        byte[] frame = makeFrame(input, o.contentSize);
        writeOutput(outName, frame, o.force);
        if (o.rm && !"-".equals(inName)) Files.deleteIfExists(Paths.get(inName));
        return 0;
    }

    static int decompressOne(Opt o, String inName, String outName) throws Exception {
        byte[] input = readInput(inName);
        byte[] out = decompressFrames(input);
        if (o.test || "null".equals(outName)) return 0;
        if (outName == null) {
            if ("-".equals(inName)) outName = "-";
            else if (inName.endsWith(".lz4")) outName = inName.substring(0, inName.length() - 4);
            else outName = inName + ".out";
        }
        writeOutput(outName, out, o.force);
        if (o.rm && !"-".equals(inName)) Files.deleteIfExists(Paths.get(inName));
        return 0;
    }

    static byte[] readInput(String name) throws IOException {
        if (name == null || name.equals("-") || name.equals("stdin")) return System.in.readAllBytes();
        return Files.readAllBytes(Paths.get(name));
    }

    static void writeOutput(String name, byte[] data, boolean force) throws IOException {
        if (name == null || name.equals("-") || name.equals("stdout")) { System.out.write(data); return; }
        if (name.equals("null")) return;
        Path p = Paths.get(name);
        if (Files.exists(p) && !force) {
            // Non-interactive clone: overwrite, matching common scripted use.
        }
        Files.write(p, data);
    }

    static byte[] makeFrame(byte[] data, boolean withSize) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        writeLE32(out, MAGIC);
        ByteArrayOutputStream desc = new ByteArrayOutputStream();
        int flg = 0x60 | 0x04; // version, independent blocks, content checksum
        if (withSize) flg |= 0x08;
        desc.write(flg); desc.write(0x70); // 4 MiB max block
        if (withSize) writeLE64(desc, data.length);
        byte[] d = desc.toByteArray();
        out.write(d);
        out.write((xxhash32(d, 0, d.length, 0) >>> 8) & 0xff);
        int pos = 0, max = 4 * 1024 * 1024;
        while (pos < data.length) {
            int n = Math.min(max, data.length - pos);
            writeLE32(out, n | 0x80000000);
            out.write(data, pos, n);
            pos += n;
        }
        writeLE32(out, 0);
        writeLE32(out, xxhash32(data, 0, data.length, 0));
        return out.toByteArray();
    }

    static byte[] decompressFrames(byte[] in) throws IOException {
        ByteArrayOutputStream all = new ByteArrayOutputStream();
        int[] p = {0};
        while (p[0] < in.length) {
            if (p[0] + 4 > in.length) throw new IOException("Unrecognized header : Magic Number unreadable");
            int magic = readLE32(in, p[0]); p[0] += 4;
            if ((magic & 0xFFFFFFF0) == SKIP_MAGIC_BASE) {
                int len = readLE32(in, p[0]); p[0] += 4 + len; continue;
            }
            if (magic != MAGIC) throw new IOException("Unrecognized header : Magic Number unreadable");
            int descStart = p[0];
            int flg = in[p[0]++] & 0xff, bd = in[p[0]++] & 0xff;
            boolean independent = (flg & 0x20) != 0, blockChecksum = (flg & 0x10) != 0, contentSize = (flg & 0x08) != 0, contentChecksum = (flg & 0x04) != 0, dict = (flg & 0x01) != 0;
            if (contentSize) p[0] += 8;
            if (dict) p[0] += 4;
            p[0]++; // header checksum
            ByteArrayOutputStream frameOut = new ByteArrayOutputStream();
            while (true) {
                int sz = readLE32(in, p[0]); p[0] += 4;
                if (sz == 0) break;
                boolean raw = (sz & 0x80000000) != 0;
                sz &= 0x7fffffff;
                if (p[0] + sz > in.length) throw new IOException("Read error : truncated input");
                if (raw) frameOut.write(in, p[0], sz);
                else frameOut.write(decodeBlock(in, p[0], sz, independent ? null : frameOut.toByteArray()));
                p[0] += sz;
                if (blockChecksum) p[0] += 4;
            }
            if (contentChecksum) p[0] += 4;
            all.write(frameOut.toByteArray());
        }
        return all.toByteArray();
    }

    static byte[] decodeBlock(byte[] src, int off, int len) throws IOException {
        return decodeBlock(src, off, len, null);
    }

    static byte[] decodeBlock(byte[] src, int off, int len, byte[] dict) throws IOException {
        int ip = off, end = off + len;
        int dictLen = dict == null ? 0 : Math.min(dict.length, 65536);
        byte[] out = new byte[Math.max(64 + dictLen, dictLen + len * 3)];
        if (dictLen > 0) System.arraycopy(dict, dict.length - dictLen, out, 0, dictLen);
        int op = dictLen;
        while (ip < end) {
            int token = src[ip++] & 0xff;
            int litLen = token >>> 4;
            if (litLen == 15) { int s; do { if (ip >= end) throw new IOException("Malformed input"); s = src[ip++] & 0xff; litLen += s; } while (s == 255); }
            out = ensure(out, op + litLen);
            if (ip + litLen > end) throw new IOException("Malformed input");
            System.arraycopy(src, ip, out, op, litLen); ip += litLen; op += litLen;
            if (ip >= end) break;
            if (ip + 2 > end) throw new IOException("Malformed input");
            int offset = (src[ip] & 0xff) | ((src[ip + 1] & 0xff) << 8); ip += 2;
            if (offset == 0 || offset > op) throw new IOException("Malformed input");
            int matchLen = (token & 0x0f) + 4;
            if ((token & 0x0f) == 15) { int s; do { if (ip >= end) throw new IOException("Malformed input"); s = src[ip++] & 0xff; matchLen += s; } while (s == 255); }
            out = ensure(out, op + matchLen);
            int ref = op - offset;
            for (int i = 0; i < matchLen; i++) out[op++] = out[ref + i];
        }
        return Arrays.copyOfRange(out, dictLen, op);
    }

    static byte[] ensure(byte[] a, int need) {
        if (need <= a.length) return a;
        int n = a.length;
        while (n < need) n *= 2;
        return Arrays.copyOf(a, n);
    }

    static int doList(Opt o) throws Exception {
        System.out.println("    Frames           Type Block  Compressed  Uncompressed    Ratio   Filename");
        for (String f : o.files) {
            byte[] b = readInput(f);
            long usize = -1;
            if (b.length >= 15 && readLE32(b, 0) == MAGIC && (b[4] & 0x08) != 0) usize = readLE64Val(b, 6);
            String us = usize >= 0 ? Long.toString(usize) : "-";
            String ratio = usize > 0 ? String.format(Locale.ROOT, "%6.2f%%", (100.0 * b.length / usize)) : "-";
            System.out.printf(Locale.ROOT, "%10d       LZ4Frame   B4I %11.2f %13s %8s   %s%n", 1, (double)b.length, us, ratio, f);
        }
        return 0;
    }

    static int readLE32(byte[] b, int p) throws IOException {
        if (p + 4 > b.length) throw new IOException("Read error : truncated input");
        return (b[p] & 255) | ((b[p+1] & 255) << 8) | ((b[p+2] & 255) << 16) | ((b[p+3] & 255) << 24);
    }
    static long readLE64Val(byte[] b, int p) {
        long v = 0; for (int i = 7; i >= 0; i--) v = (v << 8) | (b[p+i] & 255L); return v;
    }
    static void writeLE32(OutputStream o, int v) throws IOException { o.write(v); o.write(v >>> 8); o.write(v >>> 16); o.write(v >>> 24); }
    static void writeLE64(OutputStream o, long v) throws IOException { for (int i = 0; i < 8; i++) o.write((int)(v >>> (8*i))); }

    static int xxhash32(byte[] b, int off, int len, int seed) {
        final int P1=0x9E3779B1, P2=0x85EBCA77, P3=0xC2B2AE3D, P4=0x27D4EB2F, P5=0x165667B1;
        int p = off, end = off + len, h;
        if (len >= 16) {
            int v1 = seed + P1 + P2, v2 = seed + P2, v3 = seed, v4 = seed - P1;
            int limit = end - 16;
            while (p <= limit) {
                v1 = round(v1, getInt(b,p)); p+=4; v2 = round(v2, getInt(b,p)); p+=4;
                v3 = round(v3, getInt(b,p)); p+=4; v4 = round(v4, getInt(b,p)); p+=4;
            }
            h = Integer.rotateLeft(v1,1) + Integer.rotateLeft(v2,7) + Integer.rotateLeft(v3,12) + Integer.rotateLeft(v4,18);
        } else h = seed + P5;
        h += len;
        while (p + 4 <= end) { h += getInt(b,p) * P3; h = Integer.rotateLeft(h,17) * P4; p += 4; }
        while (p < end) { h += (b[p++] & 255) * P5; h = Integer.rotateLeft(h,11) * P1; }
        h ^= h >>> 15; h *= P2; h ^= h >>> 13; h *= P3; h ^= h >>> 16;
        return h;
    }
    static int round(int acc, int input) { acc += input * 0x85EBCA77; acc = Integer.rotateLeft(acc,13); return acc * 0x9E3779B1; }
    static int getInt(byte[] b, int p) { return (b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24); }
}
