package cheat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Cheat {
    static final String VERSION = "5.1.0";

    static class CheatPath {
        String name;
        Path path;
        List<String> tags = new ArrayList<>();
        boolean readonly;
    }

    static class Config {
        Path configPath;
        String editor = "EDITOR_PATH";
        String pager = "/usr/bin/pager";
        boolean colorize = false;
        List<CheatPath> paths = new ArrayList<>();
    }

    static class Sheet {
        String title;
        Path file;
        CheatPath cheatPath;
        List<String> tags;
        String body;
    }

    static class Opts {
        boolean all, brief, colorize, directories, help, init, list, regex, tags, update, version, conf;
        String completion, edit, path, rm, search, tag;
        List<String> args = new ArrayList<>();
    }

    public static void main(String[] args) {
        int code;
        try {
            code = new Cheat().run(args);
        } catch (AppException e) {
            System.out.println(e.getMessage());
            code = e.code;
        } catch (Exception e) {
            System.out.println(e.getMessage() == null ? e.toString() : e.getMessage());
            code = 1;
        }
        System.exit(code);
    }

    int run(String[] argv) throws Exception {
        Opts o = parse(argv);
        if (o.help) {
            printHelp();
            return 0;
        }
        if (o.version) {
            System.out.println(VERSION);
            return 0;
        }
        if (o.init) {
            System.out.print(defaultConfig());
            return 0;
        }
        if (o.completion != null) {
            printCompletion(o.completion);
            return 0;
        }

        Config cfg = loadConfigOrPrompt();
        addDirectoryScopedPath(cfg);

        if (o.conf) {
            System.out.println(cfg.configPath);
            return 0;
        }
        if (o.directories) {
            printDirectories(filterPaths(cfg.paths, o.path));
            return 0;
        }
        if (o.update) {
            updatePaths(filterPaths(cfg.paths, o.path));
            return 0;
        }
        if (o.edit != null) {
            editSheet(cfg, o);
            return 0;
        }
        if (o.rm != null) {
            removeSheet(cfg, o);
            return 0;
        }

        List<Sheet> sheets = discover(cfg, o);
        if (o.tags) {
            printTags(sheets);
            return 0;
        }
        if (o.list || o.brief) {
            String titleFilter = o.args.isEmpty() ? null : o.args.get(0);
            List<Sheet> filtered = new ArrayList<>();
            for (Sheet s : sheets) {
                if (titleFilter == null || s.title.contains(titleFilter)) filtered.add(s);
            }
            printList(filtered, !o.brief);
            return 0;
        }
        if (o.search != null) {
            printSearch(sheets, o.search, o.regex);
            return 0;
        }

        if (o.args.isEmpty()) {
            printHelp();
            return 0;
        }
        return viewSheet(sheets, o.args.get(0), o.all);
    }

    Opts parse(String[] argv) throws AppException {
        Opts o = new Opts();
        for (int i = 0; i < argv.length; i++) {
            String a = argv[i];
            if (!a.startsWith("-") || a.equals("-")) {
                o.args.add(a);
                continue;
            }
            String value = null;
            String flag = a;
            int eq = a.indexOf('=');
            if (eq >= 0) {
                flag = a.substring(0, eq);
                value = a.substring(eq + 1);
            }
            switch (flag) {
                case "-a": case "--all": o.all = true; break;
                case "-b": case "--brief": o.brief = true; break;
                case "-c": case "--colorize": o.colorize = true; break;
                case "-d": case "--directories": o.directories = true; break;
                case "-h": case "--help": o.help = true; break;
                case "--init": o.init = true; break;
                case "-l": case "--list": o.list = true; break;
                case "-r": case "--regex": o.regex = true; break;
                case "-T": case "--tags": o.tags = true; break;
                case "-u": case "--update": o.update = true; break;
                case "-v": case "--version": o.version = true; break;
                case "--conf": o.conf = true; break;
                case "--completion": o.completion = value != null ? value : next(argv, ++i, flag); break;
                case "-e": case "--edit": o.edit = value != null ? value : next(argv, ++i, flag); break;
                case "-p": case "--path": o.path = value != null ? value : next(argv, ++i, flag); break;
                case "--rm": o.rm = value != null ? value : next(argv, ++i, flag); break;
                case "-s": case "--search": o.search = value != null ? value : next(argv, ++i, flag); break;
                case "-t": case "--tag": o.tag = value != null ? value : next(argv, ++i, flag); break;
                default: throw new AppException("unknown flag: " + flag, 1);
            }
        }
        return o;
    }

    String next(String[] argv, int i, String flag) throws AppException {
        if (i >= argv.length) throw new AppException("flag needs an argument: " + flag, 1);
        return argv[i];
    }

    Config loadConfigOrPrompt() throws IOException, AppException {
        Optional<Path> p = findConfig();
        if (p.isEmpty()) {
            System.out.print("A config file was not found. Would you like to create one now? [Y/n]: ");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String line = br.readLine();
            if (line == null) throw new AppException("failed to create config: failed to prompt: EOF", 1);
            if (line.trim().isEmpty() || line.toLowerCase(Locale.ROOT).startsWith("y")) {
                Path target = defaultConfigPath();
                Files.createDirectories(target.getParent());
                Files.writeString(target, defaultConfig(), StandardCharsets.UTF_8);
                p = Optional.of(target);
            } else {
                throw new AppException("config file is required", 1);
            }
        }
        return parseConfig(p.get());
    }

    Optional<Path> findConfig() {
        String env = System.getenv("CHEAT_CONFIG_PATH");
        if (env != null && !env.isBlank()) {
            Path p = expand(env);
            return Files.exists(p) ? Optional.of(p) : Optional.empty();
        }
        List<Path> c = new ArrayList<>();
        String xdg = System.getenv("XDG_CONFIG_HOME");
        if (xdg != null && !xdg.isBlank()) c.add(expand(xdg).resolve("cheat/conf.yml"));
        String home = System.getenv("HOME");
        if (home != null && !home.isBlank()) {
            c.add(expand(home).resolve(".config/cheat/conf.yml"));
            c.add(expand(home).resolve(".cheat/conf.yml"));
        }
        c.add(Paths.get("/etc/cheat/conf.yml"));
        for (Path p : c) if (Files.exists(p)) return Optional.of(p);
        return Optional.empty();
    }

    Path defaultConfigPath() {
        String home = System.getenv().getOrDefault("HOME", ".");
        return expand(home).resolve(".config/cheat/conf.yml");
    }

    Config parseConfig(Path file) throws IOException {
        Config cfg = new Config();
        cfg.configPath = file.toAbsolutePath().normalize();
        List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        CheatPath current = null;
        for (String raw : lines) {
            String noComment = stripComment(raw);
            String t = noComment.trim();
            if (t.isEmpty() || t.equals("---")) continue;
            if (t.startsWith("editor:")) cfg.editor = val(t);
            else if (t.startsWith("pager:")) cfg.pager = val(t);
            else if (t.startsWith("colorize:")) cfg.colorize = Boolean.parseBoolean(val(t));
            else if (t.startsWith("- name:")) {
                current = new CheatPath();
                current.name = val(t.substring(1).trim());
                cfg.paths.add(current);
            } else if (current != null && t.startsWith("path:")) current.path = expand(val(t));
            else if (current != null && t.startsWith("tags:")) current.tags = parseList(val(t));
            else if (current != null && t.startsWith("readonly:")) current.readonly = Boolean.parseBoolean(val(t));
        }
        return cfg;
    }

    String stripComment(String s) {
        boolean quote = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\'') quote = !quote;
            if (c == '#' && !quote) return s.substring(0, i);
        }
        return s;
    }

    String val(String s) {
        int idx = s.indexOf(':');
        String v = idx >= 0 ? s.substring(idx + 1).trim() : s.trim();
        if ((v.startsWith("\"") && v.endsWith("\"")) || (v.startsWith("'") && v.endsWith("'"))) {
            v = v.substring(1, v.length() - 1);
        }
        return v;
    }

    List<String> parseList(String v) {
        List<String> out = new ArrayList<>();
        v = v.trim();
        if (v.startsWith("[") && v.endsWith("]")) v = v.substring(1, v.length() - 1);
        for (String p : v.split(",")) {
            String x = p.trim();
            if (!x.isEmpty()) out.add(unquote(x));
        }
        return out;
    }

    String unquote(String x) {
        if ((x.startsWith("\"") && x.endsWith("\"")) || (x.startsWith("'") && x.endsWith("'"))) {
            return x.substring(1, x.length() - 1);
        }
        return x;
    }

    Path expand(String s) {
        if (s.startsWith("~/")) {
            String home = System.getenv().getOrDefault("HOME", ".");
            return Paths.get(home).resolve(s.substring(2)).toAbsolutePath().normalize();
        }
        return Paths.get(s).toAbsolutePath().normalize();
    }

    void addDirectoryScopedPath(Config cfg) {
        Path cur = Paths.get("").toAbsolutePath().normalize();
        while (cur != null) {
            Path c = cur.resolve(".cheat");
            if (Files.isDirectory(c)) {
                CheatPath cp = new CheatPath();
                cp.name = ".cheat";
                cp.path = c;
                cp.tags.add(".cheat");
                cp.readonly = false;
                cfg.paths.add(cp);
                return;
            }
            cur = cur.getParent();
        }
    }

    List<CheatPath> filterPaths(List<CheatPath> paths, String name) {
        if (name == null) return paths;
        List<CheatPath> out = new ArrayList<>();
        for (CheatPath p : paths) if (name.equals(p.name)) out.add(p);
        return out;
    }

    List<Sheet> discover(Config cfg, Opts o) throws IOException {
        List<Sheet> out = new ArrayList<>();
        for (CheatPath cp : filterPaths(cfg.paths, o.path)) {
            if (cp.path == null) continue;
            List<Path> roots = expandGlob(cp.path);
            for (Path root : roots) {
                if (!Files.isDirectory(root)) continue;
                Files.walkFileTree(root, new SimpleFileVisitor<>() {
                    @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                        if (file.getFileName().toString().startsWith(".")) return FileVisitResult.CONTINUE;
                        Sheet s = readSheet(root, cp, file);
                        if (o.tag == null || s.tags.contains(o.tag)) out.add(s);
                        return FileVisitResult.CONTINUE;
                    }
                });
            }
        }
        out.sort(Comparator.comparing((Sheet s) -> s.title).thenComparing(s -> s.file.toString()));
        return out;
    }

    List<Path> expandGlob(Path p) throws IOException {
        String text = p.toString();
        if (!text.contains("*")) return List.of(p);
        int star = text.indexOf('*');
        int slash = text.substring(0, star).lastIndexOf('/');
        Path base = slash <= 0 ? Paths.get("/") : Paths.get(text.substring(0, slash));
        String regex = Pattern.quote(text).replace("\\*\\*", ".*").replace("\\*", "[^/]*");
        Pattern pat = Pattern.compile(regex);
        List<Path> out = new ArrayList<>();
        if (!Files.isDirectory(base)) return out;
        Files.walkFileTree(base, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                if (pat.matcher(dir.toString()).matches()) out.add(dir);
                return FileVisitResult.CONTINUE;
            }
        });
        return out;
    }

    Sheet readSheet(Path root, CheatPath cp, Path file) throws IOException {
        Sheet s = new Sheet();
        s.file = file.toAbsolutePath().normalize();
        s.cheatPath = cp;
        s.title = root.relativize(file).toString().replace('\\', '/');
        String text = Files.readString(file, StandardCharsets.UTF_8);
        LinkedHashSet<String> tags = new LinkedHashSet<>();
        tags.addAll(cp.tags);
        if (text.startsWith("---")) {
            int end = text.indexOf("\n---", 3);
            if (end >= 0) {
                String fm = text.substring(3, end);
                for (String line : fm.split("\\R")) {
                    String t = stripComment(line).trim();
                    if (t.startsWith("tags:")) tags.addAll(parseList(val(t)));
                }
                int bodyStart = text.indexOf('\n', end + 1);
                text = bodyStart >= 0 ? text.substring(bodyStart + 1) : "";
            }
        }
        TreeSet<String> sorted = new TreeSet<>(tags);
        s.tags = new ArrayList<>(sorted);
        s.body = text;
        return s;
    }

    void printDirectories(List<CheatPath> paths) {
        int width = 0;
        for (CheatPath p : paths) width = Math.max(width, p.name == null ? 0 : p.name.length());
        for (CheatPath p : paths) {
            System.out.printf("%s:%" + (width - p.name.length() + 1) + "s%s%n", p.name, "", p.path);
        }
    }

    void printTags(List<Sheet> sheets) {
        TreeSet<String> tags = new TreeSet<>();
        for (Sheet s : sheets) tags.addAll(s.tags);
        for (String t : tags) System.out.println(t);
    }

    void printList(List<Sheet> sheets, boolean withFile) {
        int titleW = "title:".length();
        int fileW = "file:".length();
        for (Sheet s : sheets) {
            titleW = Math.max(titleW, s.title.length());
            fileW = Math.max(fileW, s.file.toString().length());
        }
        if (withFile) {
            System.out.printf("%-" + titleW + "s %-" + fileW + "s tags:%n", "title:", "file:");
            for (Sheet s : sheets) System.out.printf("%-" + titleW + "s %-" + fileW + "s %s%n", s.title, s.file, String.join(",", s.tags));
        } else {
            System.out.printf("%-" + titleW + "s tags:%n", "title:");
            for (Sheet s : sheets) System.out.printf("%-" + titleW + "s %s%n", s.title, String.join(",", s.tags));
        }
    }

    int viewSheet(List<Sheet> sheets, String title, boolean all) {
        List<Sheet> matches = new ArrayList<>();
        for (Sheet s : sheets) if (s.title.equals(title)) matches.add(s);
        if (matches.isEmpty()) {
            System.out.println("No cheatsheet found for '" + title + "'.");
            return 2;
        }
        if (!all) {
            Sheet last = matches.get(matches.size() - 1);
            System.out.print(last.body);
            return 0;
        }
        for (int i = 0; i < matches.size(); i++) {
            Sheet s = matches.get(i);
            System.out.println(s.title + " (" + s.cheatPath.name + ")");
            for (String line : trimTrailingNewline(s.body).split("\\R", -1)) {
                if (!line.isEmpty()) System.out.println("\t" + line);
                else System.out.println();
            }
            if (i < matches.size() - 1) System.out.println();
        }
        return 0;
    }

    void printSearch(List<Sheet> sheets, String phrase, boolean regex) {
        Pattern p = null;
        String lower = phrase.toLowerCase(Locale.ROOT);
        if (regex) {
            try { p = Pattern.compile(phrase); }
            catch (PatternSyntaxException e) { throw new AppException("invalid regex: " + e.getMessage(), 1); }
        }
        boolean first = true;
        for (Sheet s : sheets) {
            boolean hit = regex ? p.matcher(s.body).find() : s.body.toLowerCase(Locale.ROOT).contains(lower);
            if (!hit) continue;
            if (!first) System.out.println();
            first = false;
            System.out.println(s.title + " (" + s.cheatPath.name + ")");
            String[] lines = trimTrailingNewline(s.body).split("\\R", -1);
            for (int i = 0; i < lines.length; i++) {
                System.out.print("\t" + lines[i]);
                if (i < lines.length - 1) System.out.println();
            }
        }
    }

    String trimTrailingNewline(String s) {
        while (s.endsWith("\n") || s.endsWith("\r")) s = s.substring(0, s.length() - 1);
        return s;
    }

    void editSheet(Config cfg, Opts o) throws Exception {
        CheatPath cp = chooseWritePath(cfg, o.path);
        if (cp == null) throw new AppException("no writable cheatpath found", 1);
        Path target = cp.path.resolve(o.edit).normalize();
        Files.createDirectories(target.getParent());
        if (!Files.exists(target)) Files.writeString(target, "", StandardCharsets.UTF_8);
        String editor = System.getenv("VISUAL");
        if (editor == null || editor.isBlank()) editor = System.getenv("EDITOR");
        if (editor == null || editor.isBlank()) editor = cfg.editor;
        if (editor == null || editor.isBlank() || editor.equals("EDITOR_PATH")) return;
        List<String> cmd = new ArrayList<>();
        Collections.addAll(cmd, editor.split("\\s+"));
        cmd.add(target.toString());
        Process p = new ProcessBuilder(cmd).inheritIO().start();
        int code = p.waitFor();
        if (code != 0) throw new AppException("editor exited with status " + code, 1);
    }

    CheatPath chooseWritePath(Config cfg, String name) {
        List<CheatPath> cps = filterPaths(cfg.paths, name);
        for (int i = cps.size() - 1; i >= 0; i--) {
            CheatPath cp = cps.get(i);
            if (!cp.readonly && cp.path != null) return cp;
        }
        return null;
    }

    void removeSheet(Config cfg, Opts o) throws IOException {
        for (int i = cfg.paths.size() - 1; i >= 0; i--) {
            CheatPath cp = cfg.paths.get(i);
            if (o.path != null && !o.path.equals(cp.name)) continue;
            Path p = cp.path.resolve(o.rm).normalize();
            if (Files.exists(p) && !cp.readonly) {
                Files.delete(p);
                return;
            }
        }
    }

    void updatePaths(List<CheatPath> paths) throws Exception {
        for (CheatPath cp : paths) {
            if (cp.path == null || !Files.isDirectory(cp.path.resolve(".git"))) continue;
            Process p = new ProcessBuilder("git", "-C", cp.path.toString(), "pull", "--ff-only").inheritIO().start();
            int code = p.waitFor();
            if (code != 0) throw new AppException("failed to update " + cp.name, 1);
        }
    }

    void printCompletion(String shell) {
        if (!List.of("bash", "zsh", "fish", "powershell").contains(shell)) {
            throw new AppException("unsupported shell: " + shell + " (valid: bash, zsh, fish, powershell)", 1);
        }
        if (shell.equals("fish")) {
            System.out.println("complete -c cheat -f -a '(__fish_complete_path)'");
        } else if (shell.equals("powershell")) {
            System.out.println("Register-ArgumentCompleter -CommandName cheat -ScriptBlock { param($wordToComplete) }");
        } else if (shell.equals("zsh")) {
            System.out.println("#compdef cheat\n_arguments '*:cheatsheet:_files'");
        } else {
            System.out.println("# bash completion V2 for cheat                                -*- shell-script -*-");
            System.out.println("complete -o default -F _cheat cheat");
            System.out.println("_cheat() { COMPREPLY=(); }");
        }
    }

    String defaultConfig() {
        String home = System.getenv().getOrDefault("HOME", "/home/agent");
        return "---\n" +
            "# The editor to use with 'cheat -e <sheet>'. Overridden by $VISUAL or $EDITOR.\n" +
            "editor: EDITOR_PATH\n\n" +
            "# Should 'cheat' always colorize output?\ncolorize: false\n\n" +
            "# Which 'chroma' colorscheme should be applied to the output?\n# Options are available here:\n#   https://github.com/alecthomas/chroma/tree/master/styles\nstyle: monokai\n\n" +
            "# Which 'chroma' \"formatter\" should be applied?\n# One of: \"terminal\", \"terminal256\", \"terminal16m\"\nformatter: terminal256\n\n" +
            "# Through which pager should output be piped?\n# 'less -FRX' is recommended on Unix systems\n# 'more' is recommended on Windows\npager: /usr/bin/pager\n\n" +
            "# The paths at which cheatsheets are available. Tags associated with a cheatpath\n# are automatically attached to all cheatsheets residing on that path.\n#\n" +
            "# Whenever cheatsheets share the same title (like 'tar'), the most local\n# cheatsheets (those which come later in this file) take precedence over the\n# less local sheets. This allows you to create your own \"overides\" for\n# \"upstream\" cheatsheets.\n#\n" +
            "# But what if you want to view the \"upstream\" cheatsheets instead of your own?\n# Cheatsheets may be filtered by 'tags' in combination with the '--tag' flag.\n# \n" +
            "# Example: 'cheat tar --tag=community' will display the 'tar' cheatsheet that\n# is tagged as 'community' rather than your own.\n#\n" +
            "# Paths that come earlier are considered to be the most \"global\", and paths\n# that come later are considered to be the most \"local\". The most \"local\" paths\n# take precedence.\n#\n" +
            "# See: https://github.com/cheat/cheat/blob/master/doc/cheat.1.md#cheatpaths\ncheatpaths:\n\n" +
            "  # Cheatsheets that are tagged \"personal\" are stored here by default:\n" +
            "  - name: personal\n    path: " + home + "/.config/cheat/cheatsheets/personal\n    tags: [ personal ]\n    readonly: false\n\n" +
            "  # Cheatsheets that are tagged \"work\" are stored here by default:\n" +
            "  - name: work\n    path: " + home + "/.config/cheat/cheatsheets/work\n    tags: [ work ]\n    readonly: false\n\n" +
            "  # Community cheatsheets (https://github.com/cheat/cheatsheets):\n" +
            "  # To install: git clone https://github.com/cheat/cheatsheets " + home + "/.config/cheat/cheatsheets/community\n" +
            "  #- name: community\n  #  path: " + home + "/.config/cheat/cheatsheets/community\n  #  tags: [ community ]\n  #  readonly: true\n\n" +
            "  # You can also use glob patterns to automatically load cheatsheets from all\n  # directories that match.\n  #\n" +
            "  # Example: overload cheatsheets for projects under ~/src/github.com/example/*/\n" +
            "  #- name: example-projects\n  #  path: ~/src/github.com/example/**/.cheat\n  #  tags: [ example ]\n  #  readonly: true\n";
    }

    void printHelp() {
        System.out.print("cheat allows you to create and view interactive cheatsheets on the\n" +
            "command-line. It was designed to help remind *nix system administrators of\n" +
            "options for commands that they use frequently, but not frequently enough to\n" +
            "remember.\n\n" +
            "Usage:\n  cheat [cheatsheet] [flags]\n\n" +
            "Examples:\n  To initialize a config file:\n    mkdir -p ~/.config/cheat && cheat --init > ~/.config/cheat/conf.yml\n\n" +
            "  To view the tar cheatsheet:\n    cheat tar\n\n" +
            "  To edit (or create) the foo cheatsheet:\n    cheat -e foo\n\n" +
            "  To edit (or create) the foo/bar cheatsheet on the \"work\" cheatpath:\n    cheat -p work -e foo/bar\n\n" +
            "  To view all cheatsheet directories:\n    cheat -d\n\n" +
            "  To list all available cheatsheets:\n    cheat -l\n\n" +
            "  To briefly list all cheatsheets whose titles match \"apt\":\n    cheat -b apt\n\n" +
            "  To list all tags in use:\n    cheat -T\n\n" +
            "  To list available cheatsheets that are tagged as \"personal\":\n    cheat -l -t personal\n\n" +
            "  To search for \"ssh\" among all cheatsheets, and colorize matches:\n    cheat -c -s ssh\n\n" +
            "  To search (by regex) for cheatsheets that contain an IP address:\n    cheat -c -r -s '(?:[0-9]{1,3}\\.){3}[0-9]{1,3}'\n\n" +
            "  To remove (delete) the foo/bar cheatsheet:\n    cheat --rm foo/bar\n\n" +
            "  To update all git-backed cheatpaths:\n    cheat --update\n\n" +
            "  To view the configuration file path:\n    cheat --conf\n\n" +
            "  To generate shell completions (bash, zsh, fish, powershell):\n    cheat --completion bash\n\n" +
            "Flags:\n" +
            "  -a, --all                Search among all cheatpaths\n" +
            "  -b, --brief              List cheatsheets without file paths\n" +
            "  -c, --colorize           Colorize output\n" +
            "      --completion shell   Generate shell completion script (shell: bash, zsh, fish, powershell)\n" +
            "      --conf               Display the config file path\n" +
            "  -d, --directories        List cheatsheet directories\n" +
            "  -e, --edit cheatsheet    Edit cheatsheet\n" +
            "  -h, --help               help for cheat\n" +
            "      --init               Write a default config file to stdout\n" +
            "  -l, --list               List cheatsheets\n" +
            "  -p, --path name          Return only sheets found on cheatpath name\n" +
            "  -r, --regex              Treat search <phrase> as a regex\n" +
            "      --rm cheatsheet      Remove (delete) cheatsheet\n" +
            "  -s, --search phrase      Search cheatsheets for phrase\n" +
            "  -t, --tag tag            Return only sheets matching tag\n" +
            "  -T, --tags               List all tags in use\n" +
            "  -u, --update             Update git-backed cheatpaths\n" +
            "  -v, --version            Print the version number\n");
    }

    static class AppException extends RuntimeException {
        final int code;
        AppException(String msg, int code) { super(msg); this.code = code; }
    }
}
