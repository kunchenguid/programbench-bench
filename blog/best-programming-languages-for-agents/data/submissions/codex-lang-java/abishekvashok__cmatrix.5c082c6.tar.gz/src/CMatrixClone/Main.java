import java.io.IOException;
import java.util.Locale;
import java.util.Random;

public class Main {
    private static final String HELP =
            " Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]\n" +
            " -a: Asynchronous scroll\n" +
            " -b: Bold characters on\n" +
            " -B: All bold characters (overrides -b)\n" +
            " -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts\n" +
            " -f: Force the linux $TERM type to be on\n" +
            " -l: Linux mode (uses matrix console font)\n" +
            " -L: Lock mode (can be closed from another terminal)\n" +
            " -o: Use old-style scrolling\n" +
            " -h: Print usage and exit\n" +
            " -n: No bold characters (overrides -b and -B, default)\n" +
            " -s: \"Screensaver\" mode, exits on first keystroke\n" +
            " -x: X window mode, use if your xterm is using mtx.pcf\n" +
            " -V: Print version information and exit\n" +
            " -M [message]: Prints your message in the center of the screen. Overrides -L's default message.\n" +
            " -u delay (0 - 10, default 4): Screen update delay\n" +
            " -C [color]: Use this color for matrix (default green)\n" +
            " -r: rainbow mode\n" +
            " -m: lambda mode\n" +
            " -k: Characters change while scrolling. (Works without -o opt.)\n" +
            " -t [tty]: Set tty to use\n";

    private static final String VERSION =
            " CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)\n" +
            "Email: abishekvashok@gmail.com\n" +
            "Web: https://github.com/abishekvashok/cmatrix\n";

    private static final char[] NORMAL_CHARS =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*+-=<>?:;".toCharArray();
    private static final char[] JAPANESE_LIKE =
            "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789".toCharArray();

    static class Options {
        boolean async;
        boolean bold;
        boolean allBold;
        boolean screensaver;
        boolean rainbow;
        boolean lambda;
        boolean change;
        boolean japanese;
        boolean oldStyle;
        boolean lock;
        int delay = 4;
        String color = "green";
        String message;
    }

    public static void main(String[] args) throws Exception {
        Options opt = new Options();
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (!arg.startsWith("-") || arg.equals("-")) {
                printHelp();
                return;
            }
            if (arg.equals("--help")) {
                printHelp();
                return;
            }
            if (arg.equals("--version")) {
                printHelp();
                return;
            }
            for (int p = 1; p < arg.length(); p++) {
                char c = arg.charAt(p);
                switch (c) {
                    case 'a': opt.async = true; break;
                    case 'b': opt.bold = true; opt.allBold = false; break;
                    case 'B': opt.allBold = true; opt.bold = false; break;
                    case 'c': opt.japanese = true; break;
                    case 'f': break;
                    case 'l': break;
                    case 'L': opt.lock = true; if (opt.message == null) opt.message = "Computer locked."; break;
                    case 'o': opt.oldStyle = true; break;
                    case 'h':
                    case '?':
                        printHelp();
                        return;
                    case 'n': opt.bold = false; opt.allBold = false; break;
                    case 's': opt.screensaver = true; break;
                    case 'x': break;
                    case 'V':
                        System.out.print(VERSION);
                        return;
                    case 'r': opt.rainbow = true; break;
                    case 'm': opt.lambda = true; break;
                    case 'k': opt.change = true; break;
                    case 'u':
                        if (p != arg.length() - 1 || i + 1 >= args.length) {
                            printHelp();
                            return;
                        }
                        i++;
                        try {
                            opt.delay = Integer.parseInt(args[i]);
                        } catch (NumberFormatException e) {
                            printHelp();
                            return;
                        }
                        p = arg.length();
                        break;
                    case 'C':
                        if (p != arg.length() - 1 || i + 1 >= args.length) {
                            printHelp();
                            return;
                        }
                        i++;
                        opt.color = args[i].toLowerCase(Locale.ROOT);
                        if (colorCode(opt.color) < 0) {
                            System.out.println(" Invalid color selection");
                            System.out.println(" Valid colors are green, red, blue, white, yellow, cyan, magenta and black.");
                            return;
                        }
                        p = arg.length();
                        break;
                    case 'M':
                        if (p != arg.length() - 1 || i + 1 >= args.length) {
                            printHelp();
                            return;
                        }
                        opt.message = args[++i];
                        p = arg.length();
                        break;
                    case 't':
                        if (p != arg.length() - 1 || i + 1 >= args.length) {
                            printHelp();
                            return;
                        }
                        i++;
                        p = arg.length();
                        break;
                    default:
                        printHelp();
                        return;
                }
            }
        }

        String term = System.getenv("TERM");
        if (term == null || term.isEmpty() || term.equals("unknown")) {
            System.err.println("Error opening terminal: unknown.");
            return;
        }
        runMatrix(opt);
    }

    private static void printHelp() {
        System.out.print(HELP);
    }

    private static int colorCode(String color) {
        switch (color) {
            case "black": return 30;
            case "red": return 31;
            case "green": return 32;
            case "yellow": return 33;
            case "blue": return 34;
            case "magenta": return 35;
            case "cyan": return 36;
            case "white": return 37;
            default: return -1;
        }
    }

    private static void runMatrix(Options opt) throws IOException, InterruptedException {
        int cols = parseIntEnv("COLUMNS", 80);
        int rows = parseIntEnv("LINES", 24);
        cols = Math.max(20, Math.min(240, cols));
        rows = Math.max(10, Math.min(80, rows));
        Random rnd = new Random();
        int[] head = new int[cols];
        int[] len = new int[cols];
        int[] speed = new int[cols];
        for (int c = 0; c < cols; c++) {
            head[c] = -rnd.nextInt(rows * 2);
            len[c] = 3 + rnd.nextInt(Math.max(4, rows / 2));
            speed[c] = 1 + rnd.nextInt(3);
        }

        Runtime.getRuntime().addShutdownHook(new Thread(Main::restoreTerminal));
        System.out.print("\033[?1049h\033[?25l\033[H\033[2J");
        System.out.flush();

        long frame = 0;
        while (true) {
            if (System.in.available() > 0) {
                int ch = System.in.read();
                if (opt.screensaver || ch == 'q' || ch == 'Q') {
                    break;
                }
                handleKey(opt, ch);
            }
            drawFrame(opt, rnd, rows, cols, head, len, speed, frame++);
            int sleep = Math.max(5, 110 - Math.max(0, Math.min(10, opt.delay)) * 10);
            Thread.sleep(sleep);
        }
        restoreTerminal();
    }

    private static void drawFrame(Options opt, Random rnd, int rows, int cols, int[] head, int[] len, int[] speed, long frame) {
        StringBuilder out = new StringBuilder(rows * cols + rows * 30);
        out.append("\033[H");
        char[] chars = opt.japanese ? JAPANESE_LIKE : NORMAL_CHARS;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int h = head[c];
                int tail = h - len[c];
                if (r <= h && r >= tail) {
                    int code = opt.rainbow ? 31 + Math.floorMod(c + r + (int) frame, 7) : colorCode(opt.color);
                    if (code == 38) code = 37;
                    if (opt.allBold || (opt.bold && rnd.nextInt(8) == 0) || r == h) out.append("\033[1m");
                    out.append("\033[").append(code).append('m');
                    char ch = opt.lambda ? 'λ' : chars[rnd.nextInt(chars.length)];
                    if (!opt.change && r != h) {
                        ch = chars[Math.floorMod((c * 31 + r * 17), chars.length)];
                    }
                    out.append(ch);
                    out.append("\033[0m");
                } else {
                    out.append(' ');
                }
            }
            if (r == rows / 2 && opt.message != null && !opt.message.isEmpty()) {
                int start = Math.max(0, (cols - opt.message.length()) / 2);
                int pos = out.length() - cols + start;
                if (pos >= 0 && pos + opt.message.length() <= out.length()) {
                    out.replace(pos, pos + Math.min(opt.message.length(), cols - start), opt.message.substring(0, Math.min(opt.message.length(), cols - start)));
                }
            }
            out.append('\n');
        }
        for (int c = 0; c < cols; c++) {
            boolean move = opt.async ? frame % speed[c] == 0 : true;
            if (move) head[c]++;
            if (head[c] - len[c] > rows) {
                head[c] = -rnd.nextInt(rows);
                len[c] = 3 + rnd.nextInt(Math.max(4, rows / 2));
                speed[c] = 1 + rnd.nextInt(3);
            }
        }
        System.out.print(out);
        System.out.flush();
    }

    private static void handleKey(Options opt, int ch) {
        if (ch >= '0' && ch <= '9') opt.delay = ch - '0';
        else if (ch == 'a') opt.async = !opt.async;
        else if (ch == 'b') { opt.bold = true; opt.allBold = false; }
        else if (ch == 'B') { opt.allBold = true; opt.bold = false; }
        else if (ch == 'n') { opt.bold = false; opt.allBold = false; }
        else if (ch == '!') opt.color = "red";
        else if (ch == '@') opt.color = "green";
        else if (ch == '#') opt.color = "yellow";
        else if (ch == '$') opt.color = "blue";
        else if (ch == '%') opt.color = "magenta";
        else if (ch == '^') opt.color = "cyan";
        else if (ch == '&') opt.color = "white";
        else if (ch == ')') opt.color = "black";
    }

    private static int parseIntEnv(String name, int fallback) {
        try {
            String value = System.getenv(name);
            return value == null ? fallback : Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static void restoreTerminal() {
        System.out.print("\033[0m\033[?25h\033[?1049l");
        System.out.flush();
    }
}
