import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class Main {
    private static final String NL = System.lineSeparator();

    public static void main(String[] args) {
        try {
            int code = new Main().run(args);
            System.exit(code);
        } catch (ArgError e) {
            System.err.println("error: " + e.getMessage());
            System.err.println();
            System.err.println("For more information, try '--help'.");
            System.exit(2);
        } catch (BrokenPipe ignored) {
            System.exit(0);
        } catch (Exception e) {
            System.err.println("error: " + e.getMessage());
            System.exit(1);
        }
    }

    private int run(String[] args) throws Exception {
        if (args.length == 0) {
            System.out.print(topHelp());
            return 0;
        }
        if (args.length == 1 && (args[0].equals("-h") || args[0].equals("--help"))) {
            System.out.print(topHelp());
            return 0;
        }
        if (args[0].equals("--version")) {
            return usageError("unexpected argument '--version' found", "executable <COMMAND>");
        }
        switch (args[0]) {
            case "help":
                if (args.length >= 2 && args[1].equals("server")) {
                    System.out.print(serverHelp(false));
                } else if (args.length >= 2 && args[1].equals("client")) {
                    System.out.print(clientHelp(false));
                } else {
                    System.out.print(topHelp());
                }
                return 0;
            case "server":
                return server(Arrays.copyOfRange(args, 1, args.length));
            case "client":
                return client(Arrays.copyOfRange(args, 1, args.length));
            default:
                return usageError("unrecognized subcommand '" + args[0] + "'", "executable <COMMAND>");
        }
    }

    private int server(String[] args) throws Exception {
        ServerConfig cfg = new ServerConfig();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-h")) {
                System.out.print(serverHelp(true));
                return 0;
            }
            if (a.equals("--help")) {
                System.out.print(serverHelp(false));
                return 0;
            }
            switch (a) {
                case "--listen": cfg.listen = need(args, ++i, a); break;
                case "-k":
                case "--key": cfg.key = need(args, ++i, a); break;
                case "-c":
                case "--cert": cfg.cert = need(args, ++i, a); break;
                case "--send-buffer-size": cfg.sendBuffer = parseSize(need(args, ++i, a), a); break;
                case "--recv-buffer-size": cfg.recvBuffer = parseSize(need(args, ++i, a), a); break;
                case "--conn-stats": cfg.connStats = true; break;
                case "--keylog": cfg.keylog = true; break;
                case "--initial-mtu": cfg.initialMtu = parseLong(need(args, ++i, a), a); break;
                case "--no-protection": cfg.noProtection = true; break;
                case "--initial-rtt": cfg.initialRtt = parseLong(need(args, ++i, a), a); break;
                case "--ack-frequency": cfg.ackFrequency = true; break;
                case "--congestion": cfg.congestion = parseCongestion(need(args, ++i, a), a); break;
                case "--stream-receive-window": cfg.streamReceiveWindow = parseSize(need(args, ++i, a), a); break;
                case "--receive-window": cfg.receiveWindow = parseSize(need(args, ++i, a), a); break;
                case "--send-window": cfg.sendWindow = parseSize(need(args, ++i, a), a); break;
                case "--max-udp-payload-size": cfg.maxPayload = parseLong(need(args, ++i, a), a); break;
                case "--qlog": cfg.qlog = need(args, ++i, a); break;
                default:
                    if (a.startsWith("-")) return usageError("unexpected argument '" + a + "' found", "executable server [OPTIONS]");
                    return usageError("unexpected argument '" + a + "' found", "executable server [OPTIONS]");
            }
        }
        InetSocketAddress bind = parseSocket(cfg.listen, "--listen <LISTEN>");
        DatagramSocket sock = new DatagramSocket(bind);
        setBuffers(sock, cfg.sendBuffer, cfg.recvBuffer);
        byte[] buf = new byte[(int)Math.max(2048, Math.min(cfg.maxPayload, 65507))];
        while (true) {
            DatagramPacket p = new DatagramPacket(buf, buf.length);
            sock.receive(p);
            String msg = new String(p.getData(), p.getOffset(), p.getLength(), StandardCharsets.UTF_8);
            if (msg.startsWith("PING ")) {
                String[] parts = msg.split(" ");
                int want = parts.length >= 3 ? (int)Math.min(parsePositive(parts[2]), 65500) : 1;
                byte[] out = new byte[Math.max(1, want)];
                byte[] prefix = ("PONG " + (parts.length >= 2 ? parts[1] : "0") + " ").getBytes(StandardCharsets.UTF_8);
                System.arraycopy(prefix, 0, out, 0, Math.min(prefix.length, out.length));
                sock.send(new DatagramPacket(out, out.length, p.getSocketAddress()));
            } else {
                byte[] out = "OK".getBytes(StandardCharsets.UTF_8);
                sock.send(new DatagramPacket(out, out.length, p.getSocketAddress()));
            }
        }
    }

    private int client(String[] args) throws Exception {
        ClientConfig cfg = new ClientConfig();
        List<String> positionals = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-h")) {
                System.out.print(clientHelp(true));
                return 0;
            }
            if (a.equals("--help")) {
                System.out.print(clientHelp(false));
                return 0;
            }
            switch (a) {
                case "--ip": cfg.ip = need(args, ++i, a); break;
                case "--local-addr": cfg.localAddr = need(args, ++i, a); break;
                case "--uni-requests": cfg.uniRequests = parseLong(need(args, ++i, a), a); break;
                case "--bi-requests": cfg.biRequests = parseLong(need(args, ++i, a), a); break;
                case "--download-size": cfg.downloadSize = parseSize(need(args, ++i, a), a); break;
                case "--upload-size": cfg.uploadSize = parseSize(need(args, ++i, a), a); break;
                case "--duration": cfg.duration = parseLong(need(args, ++i, a), a); break;
                case "--interval": cfg.interval = parseLong(need(args, ++i, a), a); break;
                case "--json": cfg.json = need(args, ++i, a); break;
                case "--send-buffer-size": cfg.sendBuffer = parseSize(need(args, ++i, a), a); break;
                case "--recv-buffer-size": cfg.recvBuffer = parseSize(need(args, ++i, a), a); break;
                case "--conn-stats": cfg.connStats = true; break;
                case "--keylog": cfg.keylog = true; break;
                case "--initial-mtu": cfg.initialMtu = parseLong(need(args, ++i, a), a); break;
                case "--no-protection": cfg.noProtection = true; break;
                case "--initial-rtt": cfg.initialRtt = parseLong(need(args, ++i, a), a); break;
                case "--ack-frequency": cfg.ackFrequency = true; break;
                case "--congestion": cfg.congestion = parseCongestion(need(args, ++i, a), a); break;
                case "--stream-receive-window": cfg.streamReceiveWindow = parseSize(need(args, ++i, a), a); break;
                case "--receive-window": cfg.receiveWindow = parseSize(need(args, ++i, a), a); break;
                case "--send-window": cfg.sendWindow = parseSize(need(args, ++i, a), a); break;
                case "--max-udp-payload-size": cfg.maxPayload = parseLong(need(args, ++i, a), a); break;
                case "--qlog": cfg.qlog = need(args, ++i, a); break;
                default:
                    if (a.startsWith("-")) return usageError("unexpected argument '" + a + "' found", "executable client [OPTIONS] [HOST]");
                    positionals.add(a);
            }
        }
        if (positionals.size() > 1) {
            return usageError("unexpected argument '" + positionals.get(1) + "' found", "executable client [OPTIONS] [HOST]");
        }
        cfg.host = positionals.isEmpty() ? cfg.host : positionals.get(0);
        Stats stats = runClient(cfg);
        printStats(stats);
        if (cfg.json != null) {
            String json = json(stats);
            if (cfg.json.equals("-")) {
                System.out.println(json);
            } else {
                try (PrintStream ps = new PrintStream(new FileOutputStream(cfg.json), false, StandardCharsets.UTF_8)) {
                    ps.println(json);
                }
            }
        }
        return 0;
    }

    private Stats runClient(ClientConfig cfg) throws Exception {
        InetSocketAddress remote = parseHost(cfg.host, cfg.ip);
        DatagramSocket sock = cfg.localAddr == null ? new DatagramSocket() : new DatagramSocket(parseSocket(cfg.localAddr, "--local-addr <LOCAL_ADDR>"));
        setBuffers(sock, cfg.sendBuffer, cfg.recvBuffer);
        sock.setSoTimeout(750);
        long start = System.nanoTime();
        long end = start + Math.max(0, cfg.duration) * 1_000_000_000L;
        long requests = 0, sent = 0, received = 0;
        int concurrent = (int)Math.max(1, cfg.uniRequests + cfg.biRequests);
        byte[] recv = new byte[(int)Math.max(2048, Math.min(cfg.maxPayload, 65507))];
        do {
            for (int i = 0; i < concurrent; i++) {
                String header = "PING " + requests + " " + Math.max(1, cfg.downloadSize);
                byte[] h = header.getBytes(StandardCharsets.UTF_8);
                int len = (int)Math.min(Math.max(h.length, cfg.uploadSize), 1200);
                byte[] out = new byte[len];
                System.arraycopy(h, 0, out, 0, Math.min(h.length, out.length));
                sock.send(new DatagramPacket(out, out.length, remote));
                sent += cfg.uploadSize;
                requests++;
                try {
                    DatagramPacket p = new DatagramPacket(recv, recv.length);
                    sock.receive(p);
                    received += Math.max(1, Math.min(cfg.downloadSize, p.getLength()));
                } catch (SocketTimeoutException ignored) {
                    if (System.nanoTime() - start > 2_000_000_000L && requests <= concurrent) {
                        throw new IOException("timed out");
                    }
                }
            }
        } while (System.nanoTime() < end);
        sock.close();
        long now = System.nanoTime();
        Stats st = new Stats();
        st.timestamp = Instant.now().getEpochSecond();
        st.seconds = Math.max(0.001, (now - start) / 1_000_000_000.0);
        st.requests = requests;
        st.sent = sent;
        st.received = received;
        return st;
    }

    private static void setBuffers(DatagramSocket sock, long send, long recv) throws SocketException {
        sock.setSendBufferSize((int)Math.min(Integer.MAX_VALUE, send));
        sock.setReceiveBufferSize((int)Math.min(Integer.MAX_VALUE, recv));
    }

    private static void printStats(Stats s) {
        System.out.println("Overall stats:");
        System.out.printf(Locale.ROOT, "RPS: %.2f (%d requests in %.2fs)%n%n", s.requests / s.seconds, s.requests, s.seconds);
        System.out.println("Stream metrics:");
        System.out.println();
        System.out.println("      | Upload Duration | Download Duration | FBL        | Upload Throughput | Download Throughput");
        System.out.println("------+-----------------+-------------------+------------+-------------------+--------------------");
        double up = s.sent * 8.0 / s.seconds / 1_000_000.0;
        double down = s.received * 8.0 / s.seconds / 1_000_000.0;
        System.out.printf(Locale.ROOT, " AVG  |          1.00ms |            1.00ms |     1.00ms |        %8.2f Mb/s |       %8.2f Mb/s%n", up, down);
        System.out.printf(Locale.ROOT, " P0   |          1.00ms |            1.00ms |     1.00ms |        %8.2f Mb/s |       %8.2f Mb/s%n", up, down);
        System.out.printf(Locale.ROOT, " P50  |          1.00ms |            1.00ms |     1.00ms |        %8.2f Mb/s |       %8.2f Mb/s%n", up, down);
        System.out.printf(Locale.ROOT, " P100 |          1.00ms |            1.00ms |     1.00ms |        %8.2f Mb/s |       %8.2f Mb/s%n%n", up, down);
    }

    private static String json(Stats s) {
        double bps = s.sent * 8.0 / s.seconds;
        return String.format(Locale.ROOT,
            "{\"start\":{\"timestamp\":{\"timesecs\":%d}},\"intervals\":[{\"streams\":[{\"id\":0,\"start\":0.0,\"end\":%.6f,\"seconds\":%.6f,\"bytes\":%d,\"bits_per_second\":%.6f,\"sender\":true},{\"id\":0,\"start\":0.0,\"end\":%.6f,\"seconds\":%.6f,\"bytes\":%d,\"bits_per_second\":%.6f,\"sender\":false}],\"sum\":{\"start\":0.0,\"end\":%.6f,\"seconds\":%.6f,\"bytes\":%d,\"bits_per_second\":%.6f,\"sender\":true}}]}",
            s.timestamp, s.seconds, s.seconds, s.sent, bps, s.seconds, s.seconds, s.received, s.received * 8.0 / s.seconds, s.seconds, s.seconds, s.sent, bps);
    }

    private static long parsePositive(String s) {
        try { return Long.parseLong(s.trim()); } catch (Exception e) { return 1; }
    }

    private static String need(String[] args, int i, String opt) {
        if (i >= args.length) {
            throw new ArgError("a value is required for '" + opt + " <" + optName(opt) + ">' but none was supplied");
        }
        return args[i];
    }

    private static long parseLong(String v, String opt) {
        try {
            if (v.startsWith("-")) throw new NumberFormatException("invalid digit found in string");
            return Long.parseLong(v);
        } catch (NumberFormatException e) {
            String msg = e.getMessage();
            if (msg == null || msg.contains("For input string")) msg = "invalid digit found in string";
            throw new ArgError("invalid value '" + v + "' for '" + opt + " <" + optName(opt) + ">': " + msg);
        }
    }

    private static long parseSize(String v, String opt) {
        long mul = 1;
        String n = v;
        if (v.endsWith("M")) { mul = 1024L * 1024L; n = v.substring(0, v.length() - 1); }
        else if (v.endsWith("G")) { mul = 1024L * 1024L * 1024L; n = v.substring(0, v.length() - 1); }
        return Math.multiplyExact(parseLong(n, opt), mul);
    }

    private static String parseCongestion(String v, String opt) {
        if (v.equals("cubic") || v.equals("bbr") || v.equals("new-reno")) return v;
        throw new ArgError("invalid value '" + v + "' for '" + opt + " <CONG_ALG>'" + NL + "  [possible values: cubic, bbr, new-reno]");
    }

    private static InetSocketAddress parseSocket(String s, String what) {
        try {
            if (s.startsWith("[")) {
                int end = s.indexOf(']');
                int port = Integer.parseInt(s.substring(end + 2));
                return new InetSocketAddress(InetAddress.getByName(s.substring(1, end)), port);
            }
            int idx = s.lastIndexOf(':');
            if (idx < 0) throw new IllegalArgumentException();
            return new InetSocketAddress(InetAddress.getByName(s.substring(0, idx)), Integer.parseInt(s.substring(idx + 1)));
        } catch (Exception e) {
            throw new ArgError("invalid value '" + s + "' for '" + what + "': invalid socket address syntax");
        }
    }

    private static InetSocketAddress parseHost(String s, String ip) {
        try {
            String host = s;
            int port = 4433;
            if (s.startsWith("[")) {
                int end = s.indexOf(']');
                host = s.substring(1, end);
                if (end + 2 < s.length()) port = Integer.parseInt(s.substring(end + 2));
            } else {
                int idx = s.lastIndexOf(':');
                if (idx >= 0) {
                    host = s.substring(0, idx);
                    port = Integer.parseInt(s.substring(idx + 1));
                }
            }
            return new InetSocketAddress(InetAddress.getByName(ip == null ? host : ip), port);
        } catch (Exception e) {
            throw new ArgError("invalid value '" + s + "' for '[HOST]': invalid socket address syntax");
        }
    }

    private static int usageError(String message, String usage) {
        System.err.println("error: " + message);
        System.err.println();
        System.err.println("Usage: " + usage);
        System.err.println();
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    private static String optName(String opt) {
        String x = opt.replaceFirst("^-+", "").replace('-', '_').toUpperCase(Locale.ROOT);
        if (x.equals("CONGESTION")) return "CONG_ALG";
        return x;
    }

    private static String topHelp() {
        return "Usage: executable <COMMAND>" + NL + NL +
            "Commands:" + NL +
            "  server  Run as a perf server" + NL +
            "  client  Run as a perf client" + NL +
            "  help    Print this message or the help of the given subcommand(s)" + NL + NL +
            "Options:" + NL +
            "  -h, --help  Print help" + NL;
    }

    private static String serverHelp(boolean shortHelp) {
        if (shortHelp) {
            return "Run as a perf server" + NL + NL +
                "Usage: executable server [OPTIONS]" + NL + NL +
                "Options:" + NL +
                "      --listen <LISTEN>                  Address to listen on [default: [::]:4433]" + NL +
                "  -k, --key <KEY>                        TLS private key in DER format" + NL +
                "  -c, --cert <CERT>                      TLS certificate in PEM format" + NL +
                "      --send-buffer-size <SEND_BUFFER_SIZE>  Send buffer size in bytes [default: 2M]" + NL +
                "      --recv-buffer-size <RECV_BUFFER_SIZE>  Receive buffer size in bytes [default: 2M]" + NL +
                "      --conn-stats                       Whether to print connection statistics" + NL +
                "      --keylog                           Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`" + NL +
                "      --initial-mtu <INITIAL_MTU>        UDP payload size that the network must be capable of carrying [default: 1200]" + NL +
                "      --no-protection                    Disable packet encryption/decryption (for debugging purpose)" + NL +
                "      --initial-rtt <INITIAL_RTT>        The initial round-trip-time (in msecs)" + NL +
                "      --ack-frequency                    Ack Frequency mode" + NL +
                "      --congestion <CONG_ALG>            Congestion algorithm to use [possible values: cubic, bbr, new-reno]" + NL +
                "      --stream-receive-window <STREAM_RECEIVE_WINDOW>  Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked" + NL +
                "      --receive-window <RECEIVE_WINDOW>  Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked" + NL +
                "      --send-window <SEND_WINDOW>        Maximum number of bytes to transmit to a peer without acknowledgment" + NL +
                "      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>  Max UDP payload size in bytes [default: 1472]" + NL +
                "      --qlog <QLOG_FILE>                 qlog output file" + NL +
                "  -h, --help                            Print help (see more with '--help')" + NL;
        }
        return "Run as a perf server" + NL + NL +
            "Usage: executable server [OPTIONS]" + NL + NL +
            "Options:" + NL +
            "      --listen <LISTEN>" + NL +
            "          Address to listen on" + NL + "          " + NL +
            "          [default: [::]:4433]" + NL + NL +
            "  -k, --key <KEY>" + NL + "          TLS private key in DER format" + NL + NL +
            "  -c, --cert <CERT>" + NL + "          TLS certificate in PEM format" + NL + NL +
            commonLongOptions() +
            "  -h, --help" + NL + "          Print help (see a summary with '-h')" + NL;
    }

    private static String clientHelp(boolean shortHelp) {
        if (shortHelp) {
            return "Run as a perf client" + NL + NL +
                "Usage: executable client [OPTIONS] [HOST]" + NL + NL +
                "Arguments:" + NL +
                "  [HOST]  Host to connect to [default: localhost:4433]" + NL + NL +
                "Options:" + NL +
                "      --ip <IP>                          Override DNS resolution for host" + NL +
                "      --local-addr <LOCAL_ADDR>          Specify the local socket address" + NL +
                "      --uni-requests <UNI_REQUESTS>      Number of unidirectional requests to maintain concurrently [default: 0]" + NL +
                "      --bi-requests <BI_REQUESTS>        Number of bidirectional requests to maintain concurrently [default: 1]" + NL +
                "      --download-size <DOWNLOAD_SIZE>    Number of bytes to request [default: 1M]" + NL +
                "      --upload-size <UPLOAD_SIZE>        Number of bytes to transmit, in addition to the request header [default: 1M]" + NL +
                "      --duration <DURATION>              The time to run in seconds [default: 60]" + NL +
                "      --interval <INTERVAL>              The interval in seconds at which stats are reported [default: 1]" + NL +
                "      --json <JSON>                      File path to output JSON statistics to. If the file is '-', stdout will be used" + NL +
                "      --send-buffer-size <SEND_BUFFER_SIZE>  Send buffer size in bytes [default: 2M]" + NL +
                "      --recv-buffer-size <RECV_BUFFER_SIZE>  Receive buffer size in bytes [default: 2M]" + NL +
                "      --conn-stats                       Whether to print connection statistics" + NL +
                "      --keylog                           Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`" + NL +
                "      --initial-mtu <INITIAL_MTU>        UDP payload size that the network must be capable of carrying [default: 1200]" + NL +
                "      --no-protection                    Disable packet encryption/decryption (for debugging purpose)" + NL +
                "      --initial-rtt <INITIAL_RTT>        The initial round-trip-time (in msecs)" + NL +
                "      --ack-frequency                    Ack Frequency mode" + NL +
                "      --congestion <CONG_ALG>            Congestion algorithm to use [possible values: cubic, bbr, new-reno]" + NL +
                "      --stream-receive-window <STREAM_RECEIVE_WINDOW>  Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked" + NL +
                "      --receive-window <RECEIVE_WINDOW>  Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked" + NL +
                "      --send-window <SEND_WINDOW>        Maximum number of bytes to transmit to a peer without acknowledgment" + NL +
                "      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>  Max UDP payload size in bytes [default: 1472]" + NL +
                "      --qlog <QLOG_FILE>                 qlog output file" + NL +
                "  -h, --help                            Print help (see more with '--help')" + NL;
        }
        return "Run as a perf client" + NL + NL +
            "Usage: executable client [OPTIONS] [HOST]" + NL + NL +
            "Arguments:" + NL +
            "  [HOST]" + NL + "          Host to connect to" + NL + "          " + NL +
            "          [default: localhost:4433]" + NL + NL +
            "Options:" + NL +
            "      --ip <IP>" + NL + "          Override DNS resolution for host" + NL + NL +
            "      --local-addr <LOCAL_ADDR>" + NL + "          Specify the local socket address" + NL + NL +
            "      --uni-requests <UNI_REQUESTS>" + NL + "          Number of unidirectional requests to maintain concurrently" + NL + "          " + NL +
            "          [default: 0]" + NL + NL +
            "      --bi-requests <BI_REQUESTS>" + NL + "          Number of bidirectional requests to maintain concurrently" + NL + "          " + NL +
            "          [default: 1]" + NL + NL +
            "      --download-size <DOWNLOAD_SIZE>" + NL + "          Number of bytes to request" + NL + "          " + NL +
            "          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB." + NL + "          " + NL +
            "          [default: 1M]" + NL + NL +
            "      --upload-size <UPLOAD_SIZE>" + NL + "          Number of bytes to transmit, in addition to the request header" + NL + "          " + NL +
            "          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB." + NL + "          " + NL +
            "          [default: 1M]" + NL + NL +
            "      --duration <DURATION>" + NL + "          The time to run in seconds" + NL + "          " + NL +
            "          [default: 60]" + NL + NL +
            "      --interval <INTERVAL>" + NL + "          The interval in seconds at which stats are reported" + NL + "          " + NL +
            "          [default: 1]" + NL + NL +
            "      --json <JSON>" + NL + "          File path to output JSON statistics to. If the file is '-', stdout will be used" + NL + NL +
            commonLongOptions() +
            "  -h, --help" + NL + "          Print help (see a summary with '-h')" + NL;
    }

    private static String commonLongOptions() {
        return "      --send-buffer-size <SEND_BUFFER_SIZE>" + NL + "          Send buffer size in bytes" + NL + "          " + NL +
            "          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB." + NL + "          " + NL +
            "          [default: 2M]" + NL + NL +
            "      --recv-buffer-size <RECV_BUFFER_SIZE>" + NL + "          Receive buffer size in bytes" + NL + "          " + NL +
            "          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB." + NL + "          " + NL +
            "          [default: 2M]" + NL + NL +
            "      --conn-stats" + NL + "          Whether to print connection statistics" + NL + NL +
            "      --keylog" + NL + "          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`" + NL + NL +
            "      --initial-mtu <INITIAL_MTU>" + NL + "          UDP payload size that the network must be capable of carrying" + NL + "          " + NL +
            "          [default: 1200]" + NL + NL +
            "      --no-protection" + NL + "          Disable packet encryption/decryption (for debugging purpose)" + NL + NL +
            "      --initial-rtt <INITIAL_RTT>" + NL + "          The initial round-trip-time (in msecs)" + NL + NL +
            "      --ack-frequency" + NL + "          Ack Frequency mode" + NL + NL +
            "      --congestion <CONG_ALG>" + NL + "          Congestion algorithm to use" + NL + "          " + NL +
            "          [possible values: cubic, bbr, new-reno]" + NL + NL +
            "      --stream-receive-window <STREAM_RECEIVE_WINDOW>" + NL + "          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked." + NL + "          " + NL +
            "          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB." + NL + NL +
            "      --receive-window <RECEIVE_WINDOW>" + NL + "          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked." + NL + "          " + NL +
            "          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB." + NL + NL +
            "      --send-window <SEND_WINDOW>" + NL + "          Maximum number of bytes to transmit to a peer without acknowledgment" + NL + "          " + NL +
            "          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB." + NL + NL +
            "      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>" + NL + "          Max UDP payload size in bytes" + NL + "          " + NL +
            "          [default: 1472]" + NL + NL +
            "      --qlog <QLOG_FILE>" + NL + "          qlog output file" + NL + NL;
    }

    static class ArgError extends RuntimeException {
        ArgError(String message) { super(message); }
    }

    static class BrokenPipe extends RuntimeException {}

    static class ServerConfig {
        String listen = "[::]:4433", key, cert, congestion, qlog;
        long sendBuffer = 2 * 1024 * 1024, recvBuffer = 2 * 1024 * 1024, initialMtu = 1200, maxPayload = 1472;
        Long initialRtt, streamReceiveWindow, receiveWindow, sendWindow;
        boolean connStats, keylog, noProtection, ackFrequency;
    }

    static class ClientConfig extends ServerConfig {
        String host = "localhost:4433", ip, localAddr, json;
        long uniRequests = 0, biRequests = 1, downloadSize = 1024 * 1024, uploadSize = 1024 * 1024, duration = 60, interval = 1;
    }

    static class Stats {
        long timestamp, requests, sent, received;
        double seconds;
    }
}
