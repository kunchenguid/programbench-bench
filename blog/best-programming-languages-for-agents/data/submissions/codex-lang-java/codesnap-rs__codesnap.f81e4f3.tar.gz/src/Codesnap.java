import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.List;

public class Codesnap {
    static class Opts {
        String fromFile, fromCode, fromImage, output, range, language, filePath, watermark, title;
        String codeFont = "monospaced", bg = "#171923", lineNumberColor = "#495162";
        String borderColor = "#ffffff30", highlightColor = "#ffffff10", addColor = "#2ecc7130", delColor = "#ff6b6b30";
        boolean fromClipboard, silent, skip, hasLineNumber, hasBorder, relativeHighlightRange;
        boolean hasBreadcrumbs = false;
        String breadcrumbsSeparator = "/";
        String type = "image";
        int startLineNumber = 1;
        List<Integer> addLines = new ArrayList<>(), delLines = new ArrayList<>();
        String highlightRange;
        List<String> execute = new ArrayList<>();
        String config;
    }

    public static void main(String[] args) {
        try {
            Opts o = parse(args);
            if (o == null) return;
            if (o.output == null) {
                clapError("the following required arguments were not provided:\n  --output <OUTPUT>\n\nUsage: codesnap --output <OUTPUT>\n\nFor more information, try '--help'.");
                System.exit(2);
            }
            run(o);
        } catch (CliException e) {
            if (e.clap) {
                clapError(e.getMessage());
                System.exit(2);
            }
            log("ERROR", "31", e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            log("ERROR", "31", e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static void run(Opts o) throws Exception {
        String code = readCode(o);
        if (code == null || code.isEmpty()) throw new CliException("No code snippet provided", false);
        code = applyRange(code, o.range);

        if ("ascii".equals(o.type)) {
            if (!"clipboard".equals(o.output)) {
                ensureConfig(o);
                log("WARN", "33", "ASCII snapshot only supports copying to clipboard");
                return;
            }
            throw new CliException("Unknown error while interacting with the clipboard: X11 server connection timed out because it was unreachable", false);
        }
        if ("clipboard".equals(o.output)) {
            throw new CliException("Unknown error while interacting with the clipboard: X11 server connection timed out because it was unreachable", false);
        }
        Path out = Paths.get(o.output);
        if (Files.isDirectory(out)) throw new CliException("Unsupported output format", false);
        String lower = out.getFileName().toString().toLowerCase(Locale.ROOT);
        ensureParent(out);
        ensureConfig(o);
        if (lower.endsWith(".svg")) writeSvg(out, code, o);
        else if (lower.endsWith(".png")) writePng(out, code, o);
        else if (lower.endsWith(".html") || lower.endsWith(".htm")) writeHtml(out, code, o);
        else throw new CliException("Unsupported output format", false);
        if (!o.silent) log("SUCCESS", "32", "Snapshot saved to " + o.output + " successful!");
    }

    static String readCode(Opts o) throws Exception {
        if (o.fromFile != null) {
            try {
                return Files.readString(Paths.get(o.fromFile));
            } catch (NoSuchFileException e) {
                throw new CliException("No such file or directory (os error 2)", false);
            }
        }
        if (o.fromCode != null) return o.fromCode.replace("\\n", "\n");
        if (!o.execute.isEmpty()) {
            if (o.skip) return String.join(" ", o.execute);
            ProcessBuilder pb = new ProcessBuilder(o.execute);
            pb.redirectErrorStream(true);
            Process p = pb.start();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try (InputStream in = p.getInputStream()) { in.transferTo(baos); }
            p.waitFor();
            return baos.toString(StandardCharsets.UTF_8);
        }
        if (o.fromImage != null) return o.fromImage;
        return null;
    }

    static void ensureConfig(Opts o) {
        if (o.silent) return;
        try {
            Path p = Paths.get(System.getProperty("user.home"), ".config", "codesnap", "config.json");
            if (!Files.exists(p)) {
                Files.createDirectories(p.getParent());
                Files.writeString(p, "{\n  \"theme\": \"default\"\n}\n");
                log("INFO", "34", "Automated created config file at \"" + p + "\"");
            }
        } catch (IOException ignored) {}
    }

    static String applyRange(String code, String range) {
        if (range == null || range.isEmpty()) return code;
        String[] lines = code.split("\\R", -1);
        if (lines.length > 0 && lines[lines.length - 1].isEmpty()) lines = Arrays.copyOf(lines, lines.length - 1);
        int start = 1, end = lines.length;
        try {
            if (range.contains(":")) {
                String[] p = range.split(":", -1);
                if (!p[0].isEmpty()) start = Integer.parseInt(p[0]);
                if (p.length > 1 && !p[1].isEmpty()) end = Integer.parseInt(p[1]);
            } else {
                start = end = Integer.parseInt(range);
            }
        } catch (NumberFormatException ignored) { return code; }
        start = Math.max(1, start);
        end = Math.min(lines.length, end);
        if (start > end) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = start; i <= end; i++) {
            if (i > start) sb.append('\n');
            sb.append(lines[i - 1]);
        }
        return sb.toString();
    }

    static void writeSvg(Path out, String code, Opts o) throws IOException {
        String[] lines = splitLines(code);
        int max = 1;
        for (String l : lines) max = Math.max(max, l.length());
        int lineH = 24, pad = 36, gutter = o.hasLineNumber ? 54 : 0;
        int titleH = o.title != null ? 34 : 0;
        int crumbH = o.hasBreadcrumbs ? 28 : 0;
        int width = Math.max(360, pad * 2 + gutter + max * 10);
        int height = Math.max(160, pad * 2 + titleH + crumbH + lines.length * lineH + (o.watermark != null ? 34 : 0));
        StringBuilder s = new StringBuilder();
        s.append("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"").append(width).append("\" height=\"").append(height).append("\" viewBox=\"0 0 ").append(width).append(' ').append(height).append("\">");
        s.append("<rect width=\"100%\" height=\"100%\" fill=\"").append(xml(color(o.bg, "#171923"))).append("\"/>");
        s.append("<rect x=\"18\" y=\"18\" width=\"").append(width - 36).append("\" height=\"").append(height - 36).append("\" rx=\"10\" fill=\"#0f111a\"");
        if (o.hasBorder) s.append(" stroke=\"").append(xml(color(o.borderColor, "#ffffff30"))).append("\"");
        s.append("/>");
        int y = 50;
        if (o.title != null) {
            s.append(text(36, y, o.title, "#e6edf3", 18, "bold"));
            y += titleH;
        }
        if (o.hasBreadcrumbs) {
            String crumb = o.fromFile != null ? o.fromFile.replace("/", o.breadcrumbsSeparator) : (o.filePath != null ? o.filePath : "");
            s.append(text(36, y, crumb, "#8b949e", 14, "normal"));
            y += crumbH;
        }
        Set<Integer> add = new HashSet<>(o.addLines), del = new HashSet<>(o.delLines), hi = parseRangeSet(o.highlightRange);
        for (int i = 0; i < lines.length; i++) {
            int ly = y + i * lineH;
            int one = i + 1;
            if (hi.contains(one)) s.append("<rect x=\"28\" y=\"").append(ly - 17).append("\" width=\"").append(width - 56).append("\" height=\"24\" fill=\"").append(xml(color(o.highlightColor, "#ffffff10"))).append("\"/>");
            if (add.contains(one)) s.append("<rect x=\"28\" y=\"").append(ly - 17).append("\" width=\"").append(width - 56).append("\" height=\"24\" fill=\"").append(xml(color(o.addColor, "#2ecc7130"))).append("\"/>");
            if (del.contains(one)) s.append("<rect x=\"28\" y=\"").append(ly - 17).append("\" width=\"").append(width - 56).append("\" height=\"24\" fill=\"").append(xml(color(o.delColor, "#ff6b6b30"))).append("\"/>");
            if (o.hasLineNumber) s.append(text(42, ly, String.valueOf(o.startLineNumber + i), o.lineNumberColor, 15, "normal"));
            s.append(text(36 + gutter, ly, lines[i], "#d6deeb", 15, "normal"));
        }
        if (o.watermark != null) s.append(text(width - 36 - o.watermark.length() * 8, height - 28, o.watermark, "#8b949e", 13, "normal"));
        s.append("</svg>");
        Files.writeString(out, s.toString(), StandardCharsets.UTF_8);
    }

    static void writeHtml(Path out, String code, Opts o) throws IOException {
        String html = "<!doctype html><html><head><meta charset=\"utf-8\"><title>CodeSnap</title><style>body{margin:0;background:" + xml(color(o.bg, "#171923")) + ";font-family:system-ui}.window{margin:32px;padding:28px;border-radius:10px;background:#0f111a;color:#d6deeb;box-shadow:0 20px 60px #0008}pre{font:15px/1.55 monospace;white-space:pre-wrap}</style></head><body><div class=\"window\">" +
                (o.title == null ? "" : "<h3>" + xml(o.title) + "</h3>") + "<pre>" + xml(code) + "</pre>" + (o.watermark == null ? "" : "<small>" + xml(o.watermark) + "</small>") + "</div></body></html>";
        Files.writeString(out, html, StandardCharsets.UTF_8);
    }

    static void writePng(Path out, String code, Opts o) throws IOException {
        String[] lines = splitLines(code);
        int max = 1;
        for (String l : lines) max = Math.max(max, l.length());
        int width = Math.max(360, 90 + max * 9);
        int height = Math.max(160, 80 + lines.length * 22 + (o.title != null ? 30 : 0));
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(parseAwt(color(o.bg, "#171923")));
        g.fillRect(0, 0, width, height);
        g.setColor(parseAwt("#0f111a"));
        g.fillRoundRect(18, 18, width - 36, height - 36, 14, 14);
        g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 15));
        g.setColor(parseAwt("#d6deeb"));
        int y = 54;
        if (o.title != null) { g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18)); g.drawString(o.title, 36, y); y += 32; g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 15)); }
        for (int i = 0; i < lines.length; i++) {
            if (o.hasLineNumber) {
                g.setColor(parseAwt("#6b7280"));
                g.drawString(String.valueOf(o.startLineNumber + i), 42, y);
                g.setColor(parseAwt("#d6deeb"));
                g.drawString(lines[i], 92, y);
            } else g.drawString(lines[i], 36, y);
            y += 22;
        }
        if (o.watermark != null) { g.setColor(parseAwt("#8b949e")); g.drawString(o.watermark, 36, height - 28); }
        g.dispose();
        ImageIO.write(img, "PNG", out.toFile());
    }

    static Opts parse(String[] args) {
        Opts o = new Opts();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": printHelp(false); return null;
                case "--help": printHelp(true); return null;
                case "-V": case "--version": System.out.println("codesnap-cli 0.13.1"); return null;
                case "-f": case "--from-file": o.fromFile = need(args, ++i, a); break;
                case "-c": case "--from-code": o.fromCode = optional(args, i + 1) ? args[++i] : ""; break;
                case "-i": case "--from-image": o.fromImage = optional(args, i + 1) ? args[++i] : ""; break;
                case "--from-clipboard": o.fromClipboard = true; break;
                case "-o": case "--output": o.output = need(args, ++i, a); break;
                case "--silent": o.silent = true; break;
                case "-e": case "--execute":
                    while (i + 1 < args.length && !args[i + 1].startsWith("-")) o.execute.add(args[++i]);
                    break;
                case "--skip": o.skip = true; break;
                case "--range": o.range = need(args, ++i, a); break;
                case "--code-font-family": o.codeFont = need(args, ++i, a); break;
                case "--code-theme": need(args, ++i, a); break;
                case "--has-line-number": o.hasLineNumber = true; break;
                case "--has-breadcrumbs": o.hasBreadcrumbs = Boolean.parseBoolean(need(args, ++i, a)); break;
                case "--breadcrumbs-separator": o.breadcrumbsSeparator = need(args, ++i, a); break;
                case "--breadcrumbs-font-family": need(args, ++i, a); break;
                case "--breadcrumbs-color": need(args, ++i, a); break;
                case "--start-line-number": o.startLineNumber = intVal(need(args, ++i, a), 1); break;
                case "--line-number-color": o.lineNumberColor = need(args, ++i, a); break;
                case "-d": case "--delete-line": o.delLines.add(intVal(need(args, ++i, a), 0)); break;
                case "-a": case "--add-line": o.addLines.add(intVal(need(args, ++i, a), 0)); break;
                case "--highlight-range": o.highlightRange = need(args, ++i, a); break;
                case "--relative-highlight-range": o.relativeHighlightRange = true; break;
                case "--highlight-range-color": o.highlightColor = need(args, ++i, a); break;
                case "--raw-highlight-lines": need(args, ++i, a); break;
                case "--add-line-color": o.addColor = need(args, ++i, a); break;
                case "--delete-line-color": o.delColor = need(args, ++i, a); break;
                case "-l": case "--language": o.language = need(args, ++i, a); break;
                case "--file-path": o.filePath = need(args, ++i, a); break;
                case "-w": case "--watermark": o.watermark = need(args, ++i, a); break;
                case "--watermark-font-family": need(args, ++i, a); break;
                case "--watermark-color": need(args, ++i, a); break;
                case "--shadow-radius": need(args, ++i, a); break;
                case "--shadow-color": need(args, ++i, a); break;
                case "--mac-window-bar": need(args, ++i, a); break;
                case "--title": o.title = need(args, ++i, a); break;
                case "--margin-x": need(args, ++i, a); break;
                case "--margin-y": need(args, ++i, a); break;
                case "--scale-factor": need(args, ++i, a); break;
                case "--title-font-family": need(args, ++i, a); break;
                case "--title-color": need(args, ++i, a); break;
                case "--background": o.bg = need(args, ++i, a); break;
                case "--type": o.type = need(args, ++i, a); if (!o.type.equals("ascii") && !o.type.equals("image")) throw new CliException("invalid value '" + o.type + "'", true); break;
                case "--has-border": o.hasBorder = true; break;
                case "--border-color": o.borderColor = need(args, ++i, a); break;
                case "--config": o.config = need(args, ++i, a); break;
                default:
                    if (a.startsWith("-")) throw new CliException("unexpected argument '" + a + "' found\n\nUsage: codesnap --output <OUTPUT>\n\nFor more information, try '--help'.", true);
            }
        }
        return o;
    }

    static String need(String[] args, int i, String opt) {
        if (i >= args.length) throw new CliException("a value is required for '" + opt + "' but none was supplied", true);
        return args[i];
    }
    static boolean optional(String[] args, int i) { return i < args.length && !args[i].startsWith("-"); }
    static int intVal(String s, int d) { try { return Integer.parseInt(s); } catch (Exception e) { return d; } }
    static void ensureParent(Path p) throws IOException { Path par = p.toAbsolutePath().getParent(); if (par != null) Files.createDirectories(par); }
    static String[] splitLines(String c) { String[] l = c.split("\\R", -1); return (l.length > 0 && l[l.length - 1].isEmpty()) ? Arrays.copyOf(l, l.length - 1) : l; }
    static String text(int x, int y, String t, String fill, int size, String weight) { return "<text x=\"" + x + "\" y=\"" + y + "\" fill=\"" + xml(color(fill, fill)) + "\" font-family=\"monospace\" font-size=\"" + size + "\" font-weight=\"" + weight + "\">" + xml(t) + "</text>"; }
    static Set<Integer> parseRangeSet(String r) { Set<Integer> s = new HashSet<>(); if (r == null) return s; String c = applyRangeNumbers(r); for (String p : c.split(",")) if (!p.isBlank()) s.add(intVal(p.trim(), 0)); return s; }
    static String applyRangeNumbers(String r) {
        if (!r.contains(":")) return r;
        String[] p = r.split(":", -1); int a = p[0].isEmpty()?1:intVal(p[0],1), b = p.length>1&&!p[1].isEmpty()?intVal(p[1],a):a;
        StringBuilder sb = new StringBuilder(); for (int i=a;i<=b;i++){ if (sb.length()>0) sb.append(','); sb.append(i);} return sb.toString();
    }
    static String xml(String s) { return s == null ? "" : s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }
    static String color(String s, String d) { return s == null || s.isBlank() ? d : s; }
    static Color parseAwt(String c) {
        try {
            if (c.startsWith("#")) {
                String h = c.substring(1);
                if (h.length() >= 6) return new Color(Integer.parseInt(h.substring(0,2),16), Integer.parseInt(h.substring(2,4),16), Integer.parseInt(h.substring(4,6),16));
            }
        } catch (Exception ignored) {}
        return new Color(23,25,35);
    }
    static void log(String level, String color, String msg) { System.out.println("\u001B[" + color + "m[" + level + "]\u001B[0m " + msg); }
    static void clapError(String msg) { System.out.println("error: " + msg); }

    static void printHelp(boolean full) {
        String body = "CLI tools for generating beautiful code snapshots\n\n" +
                "Usage: codesnap [OPTIONS] --output <OUTPUT>\n\n" +
                "Options:\n" +
                "  -f, --from-file <FROM_FILE>\n          Path to the file to snapshot\n" +
                "  -c, --from-code [<Code>]\n          Code snippet for snapshot\n" +
                "  -i, --from-image [<Image>]\n          \n" +
                "      --from-clipboard\n          \n" +
                "  -o, --output <OUTPUT>\n          Output path for the snapshot. Available value:\n" +
                "  --silent\n          \n" +
                "  -e, --execute <EXECUTE>...\n          Executing a command and taking the output as the code snippet\n" +
                "      --skip\n          Skip run the command to get output, just take the command as the input\n" +
                "      --range <RANGE>\n          You can set the range of the code snippet to display\n" +
                "      --code-font-family <CODE_FONT_FAMILY>\n          Font family for the code snippet\n" +
                "      --code-theme <CODE_THEME>\n          Code theme for the code snippet\n" +
                "      --has-breadcrumbs <HAS_BREADCRUMBS>\n          Breadcrumbs is a useful and unique feature in CodeSnap [default: false] [possible values: true, false]\n" +
                "      --has-line-number\n          \n" +
                "      --breadcrumbs-separator <BREADCRUMBS_SEPARATOR>\n          Breadcrumbs separator is the character to separate the path in breadcrumbs Default is `/`\n" +
                "      --start-line-number <START_LINE_NUMBER>\n          Set start line number to display line numbers\n" +
                "      --line-number-color <LINE_NUMBER_COLOR>\n          Line number font color [default: #495162]\n" +
                "  -d, --delete-line <DELETE_LINE>...\n          Delete lines will be marked with a red line\n" +
                "  -a, --add-line <ADD_LINE>...\n          New lines will be marked with a green line\n" +
                "      --highlight-range <HIGHLIGHT_RANGE>\n          Convenient version of `--raw-highlight-lines` option\n" +
                "  -l, --language <LANGUAGE>\n          Set the language of the code snippet\n" +
                "      --file-path <FILE_PATH>\n          Used to detect the language of the code snippet\n" +
                "  -w, --watermark <WATERMARK>\n          Set watermark for the code snippet\n" +
                "      --has-border\n          Display window border\n" +
                "      --title <TITLE>\n          Set title of the window\n" +
                "      --background <BACKGROUND>\n          Set background color of the snapshot\n" +
                "      --type <TYPE>\n          [default: image] [possible values: ascii, image]\n" +
                "      --config <CONFIG>\n          \n" +
                "  -h, --help\n          Print help (see " + (full ? "a summary with '-h'" : "more with '--help'") + ")\n" +
                "  -V, --version\n          Print version";
        System.out.println(body);
    }

    static class CliException extends RuntimeException {
        final boolean clap;
        CliException(String m, boolean clap) { super(m); this.clap = clap; }
    }
}
