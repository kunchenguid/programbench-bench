import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Main {
    static final String VERSION = "0.2.7";
    static final String FOOTER = "<div>Powered by <a href=\"https://github.com/rochacbruno/marmite\">Marmite</a> | <small><a href=\"https://creativecommons.org/licenses/by-nc-sa/4.0/\">CC-BY_NC-SA</a></small></div>";

    public static void main(String[] args) {
        try {
            int code = new Main().run(args);
            if (code != 0) System.exit(code);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] args) throws Exception {
        if (args.length == 0) return missing(null);
        Options opt = parse(args);
        if (opt.help) { printHelp(); return 0; }
        if (opt.version) { System.out.println("marmite " + VERSION); return 0; }
        if (opt.input == null) return missing(opt.primaryFlag);
        Path input = Paths.get(opt.input).toAbsolutePath().normalize();
        Path output = opt.output == null ? input.resolve("site") : Paths.get(opt.output).toAbsolutePath().normalize();
        if (opt.generateConfig) { writeConfig(input.resolve(opt.config)); return 0; }
        if (opt.initSite) { initSite(input); return 0; }
        if (opt.initTemplates) { initTemplates(input); return 0; }
        if (opt.startTheme != null) { initTheme(input.resolve(opt.startTheme)); return 0; }
        if (opt.newTitle != null) { createNew(input, opt); return 0; }
        if (opt.shortcodes) { printShortcodes(); return 0; }
        Site site = buildSite(input, output, opt);
        if (opt.showUrls) { System.out.print(site.urlsJson()); return 0; }
        if (opt.serve) serve(output, opt.bind);
        return 0;
    }

    Options parse(String[] args) {
        List<String> expanded = new ArrayList<>();
        for (String arg : args) {
            if (arg.startsWith("--") && arg.contains("=")) {
                int eq = arg.indexOf('=');
                expanded.add(arg.substring(0, eq));
                expanded.add(arg.substring(eq + 1));
            } else {
                expanded.add(arg);
            }
        }
        args = expanded.toArray(new String[0]);
        Options o = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "--help": o.help = true; break;
                case "-V": case "--version": o.version = true; break;
                case "-w": case "--watch": o.watch = true; o.primaryFlag = "--watch"; break;
                case "--serve": o.serve = true; o.primaryFlag = "--serve"; break;
                case "--bind": o.bind = req(args, ++i, a); break;
                case "-c": case "--config": o.config = req(args, ++i, a); break;
                case "--init-templates": o.initTemplates = true; o.primaryFlag = "--init-templates"; break;
                case "--start-theme": o.startTheme = req(args, ++i, a); break;
                case "--set-theme": o.setTheme = req(args, ++i, a); break;
                case "--generate-config": o.generateConfig = true; o.primaryFlag = "--generate-config"; break;
                case "--init-site": o.initSite = true; o.primaryFlag = "--init-site"; break;
                case "--force": o.force = true; break;
                case "--shortcodes": o.shortcodes = true; o.primaryFlag = "--shortcodes"; break;
                case "--show-urls": o.showUrls = true; o.primaryFlag = "--show-urls"; break;
                case "--new": o.newTitle = req(args, ++i, a); o.primaryFlag = "--new"; break;
                case "-e": o.edit = true; break;
                case "-p": o.newPage = true; break;
                case "-t": o.newTags = req(args, ++i, a); break;
                case "-v": case "-vv": case "-vvv": case "-vvvv": break;
                default:
                    if (a.startsWith("--name")) o.name = value(args, a, ++i);
                    else if (a.startsWith("--tagline")) o.tagline = value(args, a, ++i);
                    else if (a.startsWith("--url")) o.url = value(args, a, ++i);
                    else if (a.startsWith("--https")) o.https = value(args, a, ++i);
                    else if (a.startsWith("--footer")) o.footer = value(args, a, ++i);
                    else if (a.startsWith("--language")) o.language = value(args, a, ++i);
                    else if (a.startsWith("--pagination")) o.pagination = value(args, a, ++i);
                    else if (a.startsWith("--enable-search")) o.enableSearch = value(args, a, ++i);
                    else if (a.startsWith("--enable-related-content")) o.enableRelated = value(args, a, ++i);
                    else if (a.startsWith("--content-path")) o.contentPath = value(args, a, ++i);
                    else if (a.startsWith("--templates-path")) o.templatesPath = value(args, a, ++i);
                    else if (a.startsWith("--static-path")) o.staticPath = value(args, a, ++i);
                    else if (a.startsWith("--media-path")) o.mediaPath = value(args, a, ++i);
                    else if (a.startsWith("--default-date-format")) o.dateFormat = value(args, a, ++i);
                    else if (a.startsWith("--colorscheme")) o.colorscheme = value(args, a, ++i);
                    else if (a.startsWith("--toc")) o.toc = value(args, a, ++i);
                    else if (a.startsWith("--json-feed")) o.jsonFeed = value(args, a, ++i);
                    else if (a.startsWith("--show-next-prev-links")) o.nextPrev = value(args, a, ++i);
                    else if (a.startsWith("--publish-md")) o.publishMd = value(args, a, ++i);
                    else if (a.startsWith("--source-repository")) o.sourceRepository = value(args, a, ++i);
                    else if (a.startsWith("--image-provider")) o.imageProvider = value(args, a, ++i);
                    else if (a.startsWith("--theme")) o.theme = value(args, a, ++i);
                    else if (a.startsWith("--build-sitemap")) o.buildSitemap = value(args, a, ++i);
                    else if (a.startsWith("--publish-urls-json")) o.publishUrlsJson = value(args, a, ++i);
                    else if (a.startsWith("--enable-shortcodes")) o.enableShortcodes = value(args, a, ++i);
                    else if (a.startsWith("--shortcode-pattern")) o.shortcodePattern = value(args, a, ++i);
                    else if (a.startsWith("--skip-image-resize")) o.skipImageResize = value(args, a, ++i);
                    else if (a.startsWith("-")) throw new IllegalArgumentException("unexpected argument '" + a + "'");
                    else if (o.input == null) o.input = a;
                    else if (o.output == null) o.output = a;
                    break;
            }
        }
        return o;
    }

    String value(String[] args, String a, int idx) {
        int eq = a.indexOf('=');
        if (eq >= 0) return a.substring(eq + 1);
        return req(args, idx, a);
    }

    String req(String[] args, int i, String opt) {
        if (i >= args.length) throw new IllegalArgumentException("a value is required for '" + opt + "'");
        return args[i];
    }

    int missing(String flag) {
        System.err.println("error: the following required arguments were not provided:");
        System.err.println("  <INPUT_FOLDER>");
        System.err.println();
        String f = flag == null ? "" : flag + " ";
        System.err.println("Usage: executable " + f + "<INPUT_FOLDER> [OUTPUT_FOLDER]");
        System.err.println();
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    void printHelp() {
        System.out.println("Marmite is the easiest static site generator.\n");
        System.out.println("Usage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]\n");
        System.out.println("Arguments:");
        System.out.println("  <INPUT_FOLDER>   Input folder containing markdown files");
        System.out.println("  [OUTPUT_FOLDER]  Output folder to generate the site [default: `input_folder/site`]\n");
        System.out.println("Options:");
        System.out.println("  -v, --verbose...          Verbosity level (0-4)");
        System.out.println("  -w, --watch               Detect changes and rebuild the site automatically");
        System.out.println("      --serve               Serve the site with a built-in HTTP server");
        System.out.println("      --bind <BIND>         Address to bind the server [default: 0.0.0.0:8000]");
        System.out.println("  -c, --config <CONFIG>     Path to custom configuration file [default: marmite.yaml]");
        System.out.println("      --init-templates      Initialize templates in the project");
        System.out.println("      --start-theme <NAME>  Initialize a theme with templates and static assets");
        System.out.println("      --set-theme <PATH>    Download and set a theme from a remote URL or local folder");
        System.out.println("      --generate-config     Generate the configuration file");
        System.out.println("      --init-site           Init a new site with sample content and default configuration");
        System.out.println("      --force               Force the rebuild of the site even if no changes detected");
        System.out.println("      --shortcodes          List all available shortcodes");
        System.out.println("      --show-urls           Show all site URLs organized by content type");
        System.out.println("      --new <NEW>           Create a new post with the given title");
        System.out.println("  -e                        Edit the file in the default editor");
        System.out.println("  -p                        Set the new content as a page");
        System.out.println("  -t <TAGS>                 Set the tags for the new content");
        System.out.println("      --name <NAME>         Site name [default: \"Home\" or value from config file]");
        System.out.println("      --tagline <TAGLINE>   Site tagline");
        System.out.println("      --url <URL>           Site url");
        System.out.println("      --enable-search <BOOL> Enable search");
        System.out.println("      --json-feed <BOOL>    Generate JSON Feed");
        System.out.println("      --publish-md <BOOL>   Publish markdown source files alongside HTML");
        System.out.println("  -h, --help                Print help");
        System.out.println("  -V, --version             Print version");
    }

    Site buildSite(Path input, Path output, Options opt) throws IOException {
        Config cfg = loadConfig(input.resolve(opt.config));
        cfg.apply(opt);
        Path contentRoot = input.resolve(cfg.contentPath);
        if (!Files.isDirectory(contentRoot)) contentRoot = input;
        deleteDir(output);
        Files.createDirectories(output);
        createStatic(output);
        copyInputStatic(input.resolve(cfg.staticPath), output.resolve("static"));
        List<Content> all = new ArrayList<>();
        Path root = contentRoot;
        if (Files.exists(root)) {
            Files.walk(root).filter(p -> Files.isRegularFile(p) && p.toString().endsWith(".md")).forEach(p -> {
                String name = p.getFileName().toString();
                if (name.startsWith("_")) return;
                try { all.add(readContent(root, p, cfg)); } catch (IOException e) { throw new UncheckedIOException(e); }
            });
        }
        all.sort(Comparator.comparing((Content c) -> c.date == null ? LocalDate.MIN : c.date).reversed().thenComparing(c -> c.title));
        List<Content> posts = all.stream().filter(c -> !c.page).collect(Collectors.toList());
        List<Content> pages = all.stream().filter(c -> c.page).collect(Collectors.toList());
        for (Content c : all) write(output.resolve(c.url.substring(1)), pageHtml(cfg, c));
        if (cfg.publishMd) for (Content c : all) Files.copy(c.source, output.resolve(c.source.getFileName()), StandardCopyOption.REPLACE_EXISTING);
        Site site = new Site(cfg, posts, pages);
        writeList(output, cfg, "index", cfg.name.equals("Home") ? "Welcome to Marmite" : cfg.name, posts, true, site.urls.misc, cfg.pagination);
        writeList(output, cfg, "pages", "Pages", pages, false, site.urls.pages, cfg.pagination);
        writeGroups(output, cfg, "tags", "Tags", site.tagMap(), "tag", "Posts tagged with '$name'", site.urls.tags, site.urls.pagination);
        writeGroups(output, cfg, "authors", "Authors", site.authorMap(), "author", "Content by '$name'", site.urls.authors, site.urls.pagination);
        writeGroups(output, cfg, "series", "Series", site.seriesMap(), "series", "$name", site.urls.series, site.urls.pagination);
        writeGroups(output, cfg, "streams", "Streams", site.streamMap(), "", "$name", site.urls.streams, site.urls.pagination);
        writeGroups(output, cfg, "archive", "Archive", site.archiveMap(), "archive", "Posts from '$name'", site.urls.archives, site.urls.pagination);
        write(output.resolve("404.html"), simplePage(cfg, "Page not found", "<article><h1>Page not found</h1><div class=\"content-html e-content\">Page not found :/</div></article>"));
        if (cfg.buildSitemap) write(output.resolve("sitemap.xml"), sitemap(site));
        if (cfg.publishUrlsJson) write(output.resolve("urls.json"), site.urlsJson());
        write(output.resolve("marmite.json"), site.marmiteJson());
        write(output.resolve("robots.txt"), "User-agent: *\nAllow: /\nSitemap: /sitemap.xml\n");
        if (cfg.jsonFeed) writeFeed(output, cfg, "index", posts);
        return site;
    }

    Content readContent(Path root, Path file, Config cfg) throws IOException {
        String raw = Files.readString(file);
        Map<String, String> fm = new LinkedHashMap<>();
        if (raw.startsWith("---\n")) {
            int end = raw.indexOf("\n---", 4);
            if (end >= 0) {
                parseYaml(raw.substring(4, end)).forEach(fm::put);
                raw = raw.substring(end + 4).replaceFirst("^\\R", "");
            }
        }
        String firstHeading = firstHeading(raw);
        String filename = file.getFileName().toString().replaceFirst("\\.md$", "");
        Matcher dm = Pattern.compile("^(\\d{4})-(\\d{2})-(\\d{2})(?:[-_].*)?$").matcher(filename);
        LocalDate date = null;
        if (fm.containsKey("date")) date = parseDate(fm.get("date"));
        else if (dm.matches()) date = LocalDate.of(Integer.parseInt(dm.group(1)), Integer.parseInt(dm.group(2)), Integer.parseInt(dm.group(3)));
        String title = fm.getOrDefault("title", firstHeading != null ? firstHeading : titleCase(filename.replaceFirst("^\\d{4}-\\d{2}-\\d{2}[-_]?", "")));
        boolean page = bool(fm.get("page"), date == null);
        String stream = clean(fm.getOrDefault("stream", ""));
        String slug = slug(fm.getOrDefault("slug", title));
        String url = "/" + (!page && !stream.isEmpty() ? slug(stream) + "-" : "") + slug + ".html";
        String body = raw;
        if (firstHeading != null && !fm.containsKey("title")) body = body.replaceFirst("(?s)^\\s*#\\s+.*?\\R+", "");
        Content c = new Content();
        c.source = file; c.title = title; c.raw = raw; c.body = body; c.html = markdown(body);
        c.description = clean(fm.getOrDefault("description", excerpt(body)));
        c.date = date; c.page = page; c.url = url; c.slug = slug;
        c.tags = list(fm.get("tags")); c.authors = list(fm.get("authors"));
        c.stream = stream; c.series = clean(fm.getOrDefault("series", ""));
        return c;
    }

    LocalDate parseDate(String s) {
        s = s.trim().replace("'", "").replace("\"", "");
        if (s.length() >= 10) s = s.substring(0, 10);
        return LocalDate.parse(s);
    }

    String firstHeading(String raw) {
        for (String line : raw.split("\\R")) if (line.startsWith("# ")) return line.substring(2).trim();
        return null;
    }

    String markdown(String md) {
        StringBuilder out = new StringBuilder();
        List<String> para = new ArrayList<>();
        boolean inCode = false, inList = false;
        String codeLang = "";
        for (String line : md.split("\\R", -1)) {
            if (line.startsWith("```")) {
                flushPara(out, para);
                if (inCode) { out.append("</code></pre>\n"); inCode = false; }
                else { codeLang = esc(line.substring(3).trim()); out.append("<pre><code"); if (!codeLang.isEmpty()) out.append(" class=\"language-").append(codeLang).append("\""); out.append(">"); inCode = true; }
                continue;
            }
            if (inCode) { out.append(esc(line)).append("\n"); continue; }
            if (line.trim().isEmpty()) { flushPara(out, para); if (inList) { out.append("</ul>\n"); inList = false; } continue; }
            if (line.startsWith("#")) {
                flushPara(out, para); if (inList) { out.append("</ul>\n"); inList = false; }
                int n = 0; while (n < line.length() && line.charAt(n) == '#') n++;
                if (n > 0 && n <= 6 && line.length() > n && line.charAt(n) == ' ') out.append("<h").append(n).append(">").append(inline(line.substring(n + 1).trim())).append("</h").append(n).append(">\n");
                continue;
            }
            if (line.startsWith("- ") || line.startsWith("* ")) {
                flushPara(out, para); if (!inList) { out.append("<ul>\n"); inList = true; }
                out.append("<li>").append(inline(line.substring(2).trim())).append("</li>\n"); continue;
            }
            para.add(line);
        }
        flushPara(out, para); if (inList) out.append("</ul>\n");
        return out.toString();
    }

    void flushPara(StringBuilder out, List<String> para) {
        if (!para.isEmpty()) { out.append("<p>").append(inline(String.join("\n", para))).append("</p>\n"); para.clear(); }
    }

    String inline(String s) {
        s = esc(s);
        s = s.replaceAll("`([^`]+)`", "<code>$1</code>");
        s = s.replaceAll("!\\[([^]]*)]\\(([^)]+)\\)", "<img src=\"$2\" alt=\"$1\">");
        s = s.replaceAll("\\[([^]]+)]\\(([^)]+)\\)", "<a href=\"$2\">$1</a>");
        s = s.replaceAll("\\*\\*([^*]+)\\*\\*", "<strong>$1</strong>");
        s = s.replaceAll("\\*([^*]+)\\*", "<em>$1</em>");
        return s;
    }

    void writeList(Path out, Config cfg, String base, String title, List<Content> items, boolean posts, List<String> urlBucket, int perPage) throws IOException {
        urlBucket.add("/" + base + ".html");
        write(out.resolve(base + ".html"), listHtml(cfg, title, items));
        if (items.isEmpty() && posts) return;
        int pages = Math.max(1, (items.size() + perPage - 1) / perPage);
        for (int i = 1; i <= pages; i++) {
            int from = Math.min((i - 1) * perPage, items.size()), to = Math.min(i * perPage, items.size());
            String name = base + "-" + i;
            write(out.resolve(name + ".html"), listHtml(cfg, title + " - " + i, items.subList(from, to)));
        }
    }

    void writeGroups(Path out, Config cfg, String indexName, String title, Map<String, List<Content>> groups, String prefix, String itemTitle, List<String> bucket, List<String> pagBucket) throws IOException {
        StringBuilder body = new StringBuilder("<div class=\"list-title\"><article><strong> " + esc(title) + " </strong></article></div><article class=\"group-details h-feed\">\n");
        for (Map.Entry<String, List<Content>> e : groups.entrySet()) {
            String slug = slug(e.getKey());
            String page = (prefix.isEmpty() ? slug : prefix + "-" + slug) + ".html";
            body.append("<details open><summary role=\"button\" class=\"outline contrast ").append(indexName).append("-group-title\">").append(esc(e.getKey())).append(" <sup>").append(e.getValue().size()).append("</sup></summary><ul>\n");
            for (Content c : e.getValue()) body.append("<li class=\"h-entry\"><a href=\"").append(c.url).append("\" class=\"u-url p-name\">").append(esc(c.title)).append("</a>").append(c.date == null ? "" : " <small><time class=\"dt-published\" datetime=\"" + c.date + "T00:00:00+00:00\">" + c.date + "</time></small>").append("</li>\n");
            body.append("<li><a href=\"/").append(page).append("\">more &rarr;</a></li></ul></details>\n");
            bucket.add("/" + page);
            write(out.resolve(page), listHtml(cfg, itemTitle.replace("$name", e.getKey()), e.getValue()));
            String pag = page.replace(".html", "-1.html");
            pagBucket.add("/" + pag);
            write(out.resolve(pag), listHtml(cfg, itemTitle.replace("$name", e.getKey()) + " - 1", e.getValue()));
            if (!prefix.isEmpty() || indexName.equals("archive")) writeFeed(out, cfg, page.replace(".html", ""), e.getValue());
        }
        body.append("</article>");
        bucket.add("/" + indexName + ".html");
        write(out.resolve(indexName + ".html"), simplePage(cfg, title, body.toString()));
    }

    String pageHtml(Config cfg, Content c) {
        StringBuilder body = new StringBuilder();
        body.append("<article class=\"h-entry\"><data class=\"p-name\" value=\"").append(attr(c.title)).append("\"></data><a class=\"u-url\" href=\"").append(c.url).append("\" style=\"display: none;\"></a>");
        body.append("<div class=\"content-title\" id=\"title\"><h1>").append(esc(c.title)).append("</h1>");
        if (c.date != null) body.append("<span class=\"content-date\"><small>").append(formatDate(c.date)).append("</small></span>");
        body.append("</div><div class=\"content-html e-content\">").append(c.html).append("</div>");
        if (!c.tags.isEmpty()) { body.append("<footer class=\"data-tags-footer\"><ul class=\"content-tags overflow-auto\">"); for (String t : c.tags) body.append("<li><a href=\"/tag-").append(slug(t)).append(".html\" class=\"p-category\">").append(esc(t)).append("</a></li>"); body.append("</ul></footer>"); }
        body.append("</article>");
        return simplePage(cfg, c.title, body.toString());
    }

    String listHtml(Config cfg, String title, List<Content> items) {
        StringBuilder body = new StringBuilder();
        body.append("<div class=\"list-title\"><article><strong> ").append(esc(title)).append(" </strong></article></div><div class=\"content-list h-feed\"><h1 class=\"p-name\" style=\"display: none;\">").append(esc(title)).append("</h1><div class=\"left\">\n");
        if (items.isEmpty()) body.append("<article class=\"content-list-item left\"><h2 class=\"content-title\">No content found</h2><p class=\"content-excerpt\">Add some markdown content and generate the site. &rarr; <a target=\"_blank\" href=\"https://marmite.blog/getting-started.html\">Getting Started</a></p></article>");
        for (Content c : items) {
            body.append("<article class=\"content-list-item h-entry\"><h2 class=\"p-name\" style=\"display: none;\">").append(esc(c.title)).append("</h2><a class=\"u-url\" href=\"").append(c.url).append("\" style=\"display: none;\"></a>");
            if (c.date != null) body.append("<time class=\"dt-published\" datetime=\"").append(c.date).append("T00:00:00+00:00\" style=\"display: none;\">").append(formatDate(c.date)).append("</time>");
            body.append("<div class=\"content-title-wrapper\"><h2 class=\"content-title\"><a href=\"").append(c.url).append("\">").append(esc(c.title)).append("</a></h2></div><p class=\"content-excerpt p-summary\">").append(esc(c.description)).append(" <a class=\"secondary\" href=\"").append(c.url).append("\">read more &rarr;</a></p>");
            if (!c.tags.isEmpty() || c.date != null) {
                body.append("<footer class=\"data-tags-footer\">");
                if (c.date != null) body.append("<span class=\"content-date\"><a class=\"secondary\" href=\"").append(c.url).append("\">").append(formatDate(c.date)).append("</a></span>");
                body.append("<ul class=\"content-tags overflow-auto\">"); for (String t : c.tags) body.append("<li><a href=\"/tag-").append(slug(t)).append(".html\" class=\"p-category\">").append(esc(t)).append("</a></li>"); body.append("</ul></footer>");
            }
            body.append("</article>\n");
        }
        body.append("</div></div>");
        return simplePage(cfg, title, body.toString());
    }

    String simplePage(Config cfg, String title, String body) {
        return "<!DOCTYPE html>\n<html lang=\"" + esc(cfg.language) + "\">\n<head>\n<meta charset=\"UTF-8\">\n<link rel=\"icon\" type=\"image/x-icon\" href=\"/static/favicon.ico\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<meta name=\"color-scheme\" content=\"light dark\" />\n<meta name=\"generator\" content=\"Marmite\" />\n<meta property=\"og:title\" content=\"" + attr(cfg.name) + "\">\n<meta property=\"og:description\" content=\"" + attr(cfg.tagline) + "\">\n<meta property=\"og:site_name\" content=\"" + attr(cfg.name) + "\">\n<title>" + esc(title) + (title.equals(cfg.name) ? "" : " | " + esc(cfg.name)) + "</title>\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/static/pico.min.css\">\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/static/marmite.css\">\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/static/custom.css\">\n<link rel=\"alternate\" type=\"application/rss+xml\" title=\"index\" href=\"/index.rss\">\n" + (cfg.jsonFeed ? "<link rel=\"alternate\" type=\"application/feed+json\" title=\"JSON Feed\" href=\"/index.json\">\n" : "") + "</head>\n<body><main class=\"container\"><header class=\"header-content\"><nav class=\"header-nav\"><ul class=\"header-name\"><li><hgroup class=\"h-card\"><h2><a href=\"/\" class=\"contrast p-name u-url\">" + esc(cfg.name) + "</a></h2>" + (cfg.tagline.isEmpty() ? "" : "<p class=\"p-note\">" + esc(cfg.tagline) + "</p>") + "</hgroup></li></ul><ul class=\"header-menu\" id=\"header-menu\"><li><a class=\"menu-item secondary\" href=\"/tags.html\">Tags</a></li><li><a class=\"menu-item secondary\" href=\"/archive.html\">Archive</a></li><li><a class=\"menu-item secondary\" href=\"/authors.html\">Authors</a></li>" + (cfg.enableSearch ? "<li><a href=\"#\" id=\"search-toggle\" class=\"secondary\" title=\"Search (Ctrl + Shift + F)\"><span class=\"search-txt\">Search</span></a></li>" : "") + "</ul></nav></header><section class=\"main-content\">" + body + "</section><footer class=\"footer-content grid\">" + cfg.footer + "</footer></main><script src=\"/static/marmite.js\"></script><script src=\"/static/custom.js\"></script>" + (cfg.enableSearch ? "<script type=\"module\" src=\"/static/search.js\"></script>" : "") + "</body></html>\n";
    }

    void writeFeed(Path out, Config cfg, String name, List<Content> items) throws IOException {
        String rss = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><rss version=\"2.0\"><channel><title>" + esc(cfg.name) + "</title><description>" + esc(cfg.tagline) + "</description>" + items.stream().map(c -> "<item><title>" + esc(c.title) + "</title><link>" + c.url + "</link><description>" + esc(c.description) + "</description></item>").collect(Collectors.joining()) + "</channel></rss>\n";
        write(out.resolve(name + ".rss"), rss);
        if (cfg.jsonFeed) {
            String json = "{\n  \"version\": \"https://jsonfeed.org/version/1\",\n  \"title\": \"" + json(cfg.name) + "\",\n  \"home_page_url\": \"" + json(cfg.url) + "\",\n  \"description\": \"" + json(cfg.tagline) + "\",\n  \"items\": [" + items.stream().map(c -> "{\"id\":\"" + json(c.url) + "\",\"url\":\"" + json(c.url) + "\",\"title\":\"" + json(c.title) + "\",\"summary\":\"" + json(c.description) + "\"}").collect(Collectors.joining(",")) + "]\n}\n";
            write(out.resolve(name + ".json"), json);
        }
    }

    String sitemap(Site site) {
        List<String> urls = new ArrayList<>();
        site.posts.forEach(c -> urls.add(c.url)); site.pages.forEach(c -> urls.add(c.url));
        urls.addAll(site.urls.pages); urls.addAll(site.urls.posts); urls.addAll(site.urls.misc);
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n" + urls.stream().distinct().map(u -> "  <url>\n    <loc>" + esc(u) + "</loc>\n  </url>\n").collect(Collectors.joining()) + "</urlset>";
    }

    void createNew(Path input, Options opt) throws IOException {
        Files.createDirectories(input);
        String stamp = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss").withZone(ZoneOffset.UTC).format(Instant.now());
        String name = (opt.newPage ? slug(opt.newTitle) : stamp + "-" + slug(opt.newTitle)) + ".md";
        StringBuilder s = new StringBuilder();
        if (opt.newTags != null && !opt.newTags.isEmpty()) s.append("---\ntags: ").append(opt.newTags).append("\n---\n");
        s.append("# ").append(opt.newTitle).append("\n\n");
        Path p = input.resolve(name);
        write(p, s.toString());
        System.out.println(p);
    }

    void initSite(Path dir) throws IOException {
        writeConfig(dir.resolve("marmite.yaml"));
        Path c = dir.resolve("content"); Files.createDirectories(c);
        write(c.resolve(LocalDate.now(ZoneOffset.UTC) + "-welcome.md"), "# Welcome to Marmite\n\nThis is your first post!\n\n## Edit this content\n\nedit on `content/{date}-welcome.md`\n");
        write(c.resolve("about.md"), "# About\n\nHi, edit `about.md` to change this content.\n");
        write(c.resolve("_404.md"), "# Not Found");
        write(c.resolve("_hero.md"), "##### Welcome to Marmite\n\nMarmite is a static site generator written in Rust.\n");
        write(c.resolve("_announce.md"), "Give us a &star; on [github]");
        write(c.resolve("_comments.md"), "##### Comments\n");
        write(c.resolve("_markdown_header.md"), "<!-- Content Injected to every content markdown header -->");
        write(c.resolve("_markdown_footer.md"), "<!-- Content Injected to every content markdown footer -->");
        write(c.resolve("_references.md"), "[github]: https://github.com/rochacbruno/marmite");
        write(dir.resolve("custom.css"), "");
        write(dir.resolve("custom.js"), "");
        System.out.println("Site initialized in " + dir);
    }

    void initTemplates(Path dir) throws IOException {
        Path t = dir.resolve("templates"); Files.createDirectories(t);
        write(t.resolve("base.html"), "<!DOCTYPE html><html><head><title>{{ title }}</title></head><body>{{ content }}</body></html>\n");
        write(t.resolve("content.html"), "<article>{{ content }}</article>\n");
        System.out.println("Templates initialized in " + t);
    }

    void initTheme(Path dir) throws IOException {
        Files.createDirectories(dir.resolve("templates")); Files.createDirectories(dir.resolve("static"));
        write(dir.resolve("templates/base.html"), "<!DOCTYPE html><html><body>{{ content }}</body></html>\n");
        write(dir.resolve("static/custom.css"), "");
        System.out.println("Theme initialized in " + dir);
    }

    void writeConfig(Path file) throws IOException {
        Files.createDirectories(file.getParent());
        write(file, defaultConfig());
        System.out.println("Config file generated: " + file);
    }

    String defaultConfig() {
        return "name: Home\n" +
                "tagline: ''\nurl: ''\nhttps: null\nfooter: " + FOOTER + "\nlanguage: ''\npagination: 10\npages_title: Pages\ntags_title: Tags\ntags_content_title: Posts tagged with '$tag'\narchives_title: Archive\narchives_content_title: Posts from '$year'\nstreams_title: Streams\nstreams_content_title: Posts from '$stream'\nseries_title: Series\nseries_content_title: Posts from '$series' series\ndefault_author: ''\nauthors_title: Authors\nenable_search: false\nenable_related_content: false\nsearch_title: ''\ncontent_path: content\nsite_path: ''\ntemplates_path: templates\nstatic_path: static\nmedia_path: media\ncard_image: ''\nbanner_image: ''\nlogo_image: ''\ndefault_date_format: '%b %e, %Y'\nmenu:\n- - Tags\n  - tags.html\n- - Archive\n  - archive.html\n- - Authors\n  - authors.html\nextra: null\nauthors: {}\nstreams: {}\nseries: {}\ntoc: false\njson_feed: false\nshow_next_prev_links: true\npublish_md: false\nsource_repository: null\nimage_provider: null\nmarkdown_parser: null\ntheme: null\nfile_mapping: []\nenable_shortcodes: true\nshortcode_pattern: null\nbuild_sitemap: true\npublish_urls_json: true\ngallery_path: gallery\ngallery_create_thumbnails: true\ngallery_thumb_size: 50\nskip_image_resize: false\n";
    }

    void printShortcodes() {
        System.out.println("Shortcodes:");
        System.out.println("Enabled: true");
        System.out.println("Pattern: <!-- \\.(\\w+)(?:\\s+([^-][\\s\\S]*?))?\\s*-->\n");
        System.out.println("Reusable blocks of content that can be used in your markdown files.");
        System.out.println("================");
        System.out.println("Examples based on your configuration:");
        System.out.println("  <!-- .posts -->\n  <!-- .posts param=value -->\n  <!-- .series -->\n  <!-- .series param=value -->\n  <!-- .socials -->\n");
        System.out.println("Available shortcodes:");
        for (String s : List.of("authors", "card", "gallery", "pages", "posts", "series", "socials", "spotify", "streams", "tags", "toc", "youtube")) System.out.println("  - " + s);
    }

    void serve(Path root, String bind) throws IOException {
        String[] hp = bind.split(":");
        String host = hp.length > 1 ? hp[0] : "0.0.0.0";
        int port = Integer.parseInt(hp.length > 1 ? hp[1] : hp[0]);
        HttpServer server = HttpServer.create(new InetSocketAddress(host, port), 0);
        server.createContext("/", ex -> {
            String path = ex.getRequestURI().getPath().equals("/") ? "/index.html" : ex.getRequestURI().getPath();
            Path p = root.resolve(path.substring(1)).normalize();
            if (!p.startsWith(root) || !Files.exists(p)) { ex.sendResponseHeaders(404, 0); ex.close(); return; }
            byte[] b = Files.readAllBytes(p); ex.sendResponseHeaders(200, b.length); ex.getResponseBody().write(b); ex.close();
        });
        server.start();
        System.out.println("Serving " + root + " at http://" + bind);
        try { Thread.currentThread().join(); } catch (InterruptedException ignored) {}
    }

    Config loadConfig(Path p) throws IOException {
        Config c = new Config();
        if (Files.exists(p)) parseYaml(Files.readString(p)).forEach((k, v) -> {
            switch (k) {
                case "name": c.name = clean(v); break; case "tagline": c.tagline = clean(v); break; case "url": c.url = clean(v); break; case "footer": c.footer = clean(v); break; case "language": c.language = clean(v); break; case "pagination": c.pagination = parseInt(v, c.pagination); break; case "enable_search": c.enableSearch = bool(v, c.enableSearch); break; case "json_feed": c.jsonFeed = bool(v, c.jsonFeed); break; case "publish_md": c.publishMd = bool(v, c.publishMd); break; case "content_path": c.contentPath = clean(v); break; case "static_path": c.staticPath = clean(v); break; case "build_sitemap": c.buildSitemap = bool(v, c.buildSitemap); break; case "publish_urls_json": c.publishUrlsJson = bool(v, c.publishUrlsJson); break;
            }
        });
        if (c.language.isEmpty()) c.language = "en";
        return c;
    }

    static Map<String, String> parseYaml(String text) {
        Map<String, String> m = new LinkedHashMap<>();
        for (String line : text.split("\\R")) {
            if (line.trim().isEmpty() || line.trim().startsWith("#") || line.startsWith(" ") || line.startsWith("-")) continue;
            int idx = line.indexOf(':');
            if (idx > 0) m.put(line.substring(0, idx).trim(), clean(line.substring(idx + 1).trim()));
        }
        return m;
    }

    static List<String> list(String v) {
        if (v == null || clean(v).isEmpty() || clean(v).equals("[]")) return new ArrayList<>();
        v = clean(v); if (v.startsWith("[") && v.endsWith("]")) v = v.substring(1, v.length() - 1);
        return Arrays.stream(v.split(",")).map(Main::clean).filter(s -> !s.isEmpty()).collect(Collectors.toCollection(ArrayList::new));
    }

    static String clean(String s) {
        if (s == null) return "";
        s = s.trim();
        if ((s.startsWith("'") && s.endsWith("'")) || (s.startsWith("\"") && s.endsWith("\""))) s = s.substring(1, s.length() - 1);
        return s;
    }

    static boolean bool(String s, boolean def) { if (s == null) return def; s = clean(s).toLowerCase(Locale.ROOT); return s.equals("true") || s.equals("yes") || s.equals("1"); }
    static int parseInt(String s, int def) { try { return Integer.parseInt(clean(s)); } catch (Exception e) { return def; } }
    static String excerpt(String md) { return md.replaceAll("(?m)^#+\\s*", "").replaceAll("[*_`#>-]", "").replaceAll("\\[([^]]+)]\\([^)]+\\)", "$1").trim(); }
    static String titleCase(String s) { return Arrays.stream(s.replace('-', ' ').replace('_', ' ').split("\\s+")).filter(x -> !x.isEmpty()).map(x -> x.substring(0,1).toUpperCase(Locale.ROOT) + x.substring(1)).collect(Collectors.joining(" ")); }
    static String slug(String s) { String r = clean(s).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-").replaceAll("^-+|-+$", ""); return r.isEmpty() ? "untitled" : r; }
    static String formatDate(LocalDate d) { return d.format(DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.ENGLISH)); }
    static String esc(String s) { return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }
    static String attr(String s) { return esc(s).replace("\"", "&quot;"); }
    static String json(String s) { return (s == null ? "" : s).replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n"); }

    static void write(Path p, String s) throws IOException { Files.createDirectories(p.getParent()); Files.writeString(p, s, StandardCharsets.UTF_8); }
    static void deleteDir(Path p) throws IOException { if (!Files.exists(p)) return; Files.walkFileTree(p, new SimpleFileVisitor<>() { public FileVisitResult visitFile(Path f, BasicFileAttributes a) throws IOException { Files.delete(f); return FileVisitResult.CONTINUE; } public FileVisitResult postVisitDirectory(Path d, IOException e) throws IOException { Files.delete(d); return FileVisitResult.CONTINUE; }}); }
    static void createStatic(Path out) throws IOException { Path s = out.resolve("static"); Files.createDirectories(s); write(s.resolve("marmite.css"), "body{font-family:sans-serif}.container{max-width:960px;margin:auto}.content-tags{display:flex;gap:.5rem;list-style:none;padding:0}\n"); write(s.resolve("pico.min.css"), ""); write(s.resolve("custom.css"), ""); write(s.resolve("marmite.js"), ""); write(s.resolve("custom.js"), ""); write(s.resolve("search.js"), ""); write(s.resolve("robots.txt"), "User-agent: *\nAllow: /\n"); Files.write(s.resolve("favicon.ico"), new byte[]{0}); Files.write(s.resolve("logo.png"), new byte[]{0}); Files.write(s.resolve("avatar-placeholder.png"), new byte[]{0}); Files.write(s.resolve("Atkinson-Hyperlegible-Regular-102.woff"), new byte[]{0}); }
    static void copyInputStatic(Path from, Path to) throws IOException { if (!Files.isDirectory(from)) return; Files.walk(from).forEach(p -> { try { Path rel = from.relativize(p), dest = to.resolve(rel); if (Files.isDirectory(p)) Files.createDirectories(dest); else Files.copy(p, dest, StandardCopyOption.REPLACE_EXISTING); } catch (IOException e) { throw new UncheckedIOException(e); } }); }

    static class Options {
        String input, output, config = "marmite.yaml", bind = "0.0.0.0:8000", primaryFlag, newTitle, newTags, startTheme, setTheme;
        boolean help, version, watch, serve, initTemplates, generateConfig, initSite, force, shortcodes, showUrls, edit, newPage;
        String name, tagline, url, https, footer, language, pagination, enableSearch, enableRelated, contentPath, templatesPath, staticPath, mediaPath, dateFormat, colorscheme, toc, jsonFeed, nextPrev, publishMd, sourceRepository, imageProvider, theme, buildSitemap, publishUrlsJson, enableShortcodes, shortcodePattern, skipImageResize;
    }

    static class Config {
        String name = "Home", tagline = "", url = "", footer = FOOTER, language = "en", contentPath = "content", staticPath = "static";
        int pagination = 10; boolean enableSearch = false, jsonFeed = false, publishMd = false, buildSitemap = true, publishUrlsJson = true;
        void apply(Options o) {
            if (o.name != null) name = clean(o.name); if (o.tagline != null) tagline = clean(o.tagline); if (o.url != null) url = clean(o.url); if (o.footer != null) footer = clean(o.footer); if (o.language != null) language = clean(o.language); if (o.pagination != null) pagination = parseInt(o.pagination, pagination); if (o.enableSearch != null) enableSearch = bool(o.enableSearch, enableSearch); if (o.jsonFeed != null) jsonFeed = bool(o.jsonFeed, jsonFeed); if (o.publishMd != null) publishMd = bool(o.publishMd, publishMd); if (o.contentPath != null) contentPath = clean(o.contentPath); if (o.staticPath != null) staticPath = clean(o.staticPath); if (o.buildSitemap != null) buildSitemap = bool(o.buildSitemap, buildSitemap); if (o.publishUrlsJson != null) publishUrlsJson = bool(o.publishUrlsJson, publishUrlsJson);
        }
    }

    static class Content {
        Path source; String title, raw, body, html, description, url, slug, stream = "", series = ""; LocalDate date; boolean page; List<String> tags = new ArrayList<>(), authors = new ArrayList<>();
    }

    static class Urls {
        List<String> posts = new ArrayList<>(), pages = new ArrayList<>(), tags = new ArrayList<>(), authors = new ArrayList<>(), series = new ArrayList<>(), streams = new ArrayList<>(), archives = new ArrayList<>(), feeds = new ArrayList<>(), pagination = new ArrayList<>(), fileMappings = new ArrayList<>(), misc = new ArrayList<>();
    }

    static class Site {
        Config cfg; List<Content> posts, pages; Urls urls = new Urls();
        Site(Config cfg, List<Content> posts, List<Content> pages) { this.cfg = cfg; this.posts = posts; this.pages = pages; posts.forEach(c -> urls.posts.add(c.url)); pages.forEach(c -> urls.pages.add(c.url)); }
        Map<String, List<Content>> tagMap() { Map<String, List<Content>> m = new TreeMap<>(); for (Content c : posts) for (String t : c.tags) m.computeIfAbsent(t, k -> new ArrayList<>()).add(c); return m; }
        Map<String, List<Content>> authorMap() { Map<String, List<Content>> m = new TreeMap<>(); for (Content c : posts) for (String a : c.authors) m.computeIfAbsent(a, k -> new ArrayList<>()).add(c); return m; }
        Map<String, List<Content>> seriesMap() { Map<String, List<Content>> m = new TreeMap<>(); for (Content c : posts) if (!c.series.isEmpty()) m.computeIfAbsent(c.series, k -> new ArrayList<>()).add(c); return m; }
        Map<String, List<Content>> streamMap() { Map<String, List<Content>> m = new TreeMap<>(); for (Content c : posts) if (!c.stream.isEmpty()) m.computeIfAbsent(c.stream, k -> new ArrayList<>()).add(c); return m; }
        Map<String, List<Content>> archiveMap() { Map<String, List<Content>> m = new TreeMap<>(Comparator.reverseOrder()); for (Content c : posts) if (c.date != null) m.computeIfAbsent(String.valueOf(c.date.getYear()), k -> new ArrayList<>()).add(c); return m; }
        String urlsJson() {
            if (cfg.jsonFeed) { urls.feeds.add("/index.rss"); urls.feeds.add("/index.json"); }
            return "{\n" + arr("posts", urls.posts) + ",\n" + arr("pages", urls.pages) + ",\n" + arr("tags", urls.tags) + ",\n" + arr("authors", urls.authors) + ",\n" + arr("series", urls.series) + ",\n" + arr("streams", urls.streams) + ",\n" + arr("archives", urls.archives) + ",\n" + arr("feeds", urls.feeds) + ",\n" + arr("pagination", urls.pagination) + ",\n" + arr("file_mappings", urls.fileMappings) + ",\n" + arr("misc", urls.misc) + ",\n  \"summary\": {\n    \"posts\": " + urls.posts.size() + ",\n    \"pages\": " + urls.pages.size() + ",\n    \"tags\": " + urls.tags.size() + ",\n    \"authors\": " + urls.authors.size() + ",\n    \"series\": " + urls.series.size() + ",\n    \"streams\": " + urls.streams.size() + ",\n    \"archives\": " + urls.archives.size() + ",\n    \"feeds\": " + urls.feeds.size() + ",\n    \"pagination\": " + urls.pagination.size() + ",\n    \"file_mappings\": 0,\n    \"misc\": " + urls.misc.size() + ",\n    \"total\": " + (urls.posts.size()+urls.pages.size()+urls.tags.size()+urls.authors.size()+urls.series.size()+urls.streams.size()+urls.archives.size()+urls.feeds.size()+urls.pagination.size()+urls.misc.size()) + ",\n    \"meta\": {\"url\": \"" + json(cfg.url) + "\", \"absolute_urls\": " + (!cfg.url.isEmpty()) + "}\n  }\n}\n";
        }
        String marmiteJson() { return "{\n  \"marmite_version\": \"" + VERSION + "\",\n  \"posts\": " + posts.size() + ",\n  \"pages\": " + pages.size() + ",\n  \"generated_at\": \"" + LocalDateTime.now(ZoneOffset.UTC) + " +00:00\",\n  \"timestamp\": " + Instant.now().getEpochSecond() + ",\n  \"config\": {\"name\": \"" + json(cfg.name) + "\", \"tagline\": \"" + json(cfg.tagline) + "\", \"url\": \"" + json(cfg.url) + "\", \"language\": \"" + json(cfg.language) + "\", \"pagination\": " + cfg.pagination + ", \"enable_search\": " + cfg.enableSearch + ", \"json_feed\": " + cfg.jsonFeed + ", \"publish_md\": " + cfg.publishMd + "}\n}\n"; }
        String arr(String name, List<String> vals) { return "  \"" + name + "\": [" + vals.stream().distinct().map(v -> "\n    \"" + json(v) + "\"").collect(Collectors.joining(",")) + (vals.isEmpty() ? "" : "\n  ") + "]"; }
    }
}
