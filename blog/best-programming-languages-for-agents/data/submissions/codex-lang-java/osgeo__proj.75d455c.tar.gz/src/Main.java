import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Main {
    static final String REL = "Rel. 9.9.0, September 15th, 2026";
    static final double DEG = Math.PI / 180.0, RAD = 180.0 / Math.PI;

    static class Ellipsoid {
        double a = 6378137.0, b = 6356752.314245179, e2 = 0.0066943799901413165, e = Math.sqrt(e2);
        void sphere(double r) { a = b = r; e2 = e = 0; }
        void setAB(double aa, double bb) { a = aa; b = bb; e2 = Math.max(0, 1 - (b*b)/(a*a)); e = Math.sqrt(e2); }
    }
    static class Opts {
        Map<String,String> p = new HashMap<>();
        boolean inv, echo, reverseIn, reverseOut;
        String fmt = "%.2f";
        List<String> files = new ArrayList<>();
    }
    static class Point { double x, y; Point(double x, double y){this.x=x;this.y=y;} }
    interface Proj { Point fwd(double lon, double lat); Point inv(double x, double y); }

    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println(REL);
            System.err.println("usage: executable [-bdeEfiIlmorsStTvVwW [args]] [+opt[=arg] ...] [file ...]");
            return;
        }
        Opts o = parse(args);
        if (o == null) return;
        String proj = o.p.getOrDefault("proj", "");
        if (proj.isEmpty()) die("projection initialization failure\ncause: Unknown error (code 2)");
        if (proj.equals("latlong") || proj.equals("longlat") || proj.equals("lonlat"))
            die("can't initialize operations that produce angular output coordinates");
        Ellipsoid el = ellipsoid(o.p);
        Proj pr = projection(proj, o.p, el);
        if (pr == null) die("projection initialization failure\ncause: Unknown error (code 2)");
        if (o.files.isEmpty()) process(new BufferedReader(new InputStreamReader(System.in)), o, pr);
        else for (String f : o.files) process(Files.newBufferedReader(Paths.get(f)), o, pr);
    }

    static Opts parse(String[] args) {
        Opts o = new Opts();
        for (int i=0;i<args.length;i++) {
            String a = args[i];
            if (a.startsWith("--")) { System.err.println(REL+"\n<executable>: \ninvalid option: --\nprogram abnormally terminated"); return null; }
            if (a.startsWith("+")) {
                String s = a.substring(1); int eq = s.indexOf('=');
                o.p.put(eq < 0 ? s : s.substring(0, eq), eq < 0 ? "true" : s.substring(eq+1));
            } else if (a.startsWith("-") && a.length() > 1) {
                if (a.equals("-I")) o.inv = true;
                else if (a.equals("-E")) o.echo = true;
                else if (a.equals("-r")) o.reverseIn = true;
                else if (a.equals("-s")) o.reverseOut = true;
                else if (a.startsWith("-f")) {
                    if (a.length() > 2) o.fmt = a.substring(2);
                    else if (++i < args.length) o.fmt = args[i];
                    else { System.err.println(REL+"\n<executable>: \nmissing argument for -f\nprogram abnormally terminated"); return null; }
                } else if (a.equals("-l") || a.equals("-lp")) { listProj(); return null; }
                else if (a.equals("-le")) { listEllps(); return null; }
                else if (a.equals("-lu")) { listUnits(); return null; }
                else if (a.startsWith("-w") || a.startsWith("-W") || a.equals("-m") || a.equals("-e")) {
                    if ((a.equals("-m") || a.equals("-e")) && i+1 < args.length) i++;
                } else {
                    String bad = a.length() > 2 ? a.substring(1,3) : a;
                    System.err.println(REL+"\n<executable>: \ninvalid option: "+bad+"\nprogram abnormally terminated"); return null;
                }
            } else o.files.add(a);
        }
        return o;
    }

    static void process(BufferedReader br, Opts o, Proj pr) throws IOException {
        String line;
        while ((line = br.readLine()) != null) {
            if (line.startsWith("#")) { System.out.println(line); continue; }
            int start = 0; while (start < line.length() && Character.isWhitespace(line.charAt(start))) start++;
            String restLine = line.substring(start);
            String[] tok = restLine.trim().isEmpty() ? new String[0] : restLine.trim().split("\\s+", 3);
            double a = tok.length > 0 ? parseAngle(tok[0]) : 0, b = tok.length > 1 ? parseAngle(tok[1]) : 0;
            String tail = tok.length > 2 ? " " + tok[2] : "";
            if (o.reverseIn) { double t=a; a=b; b=t; }
            Point r = o.inv ? pr.inv(a, b) : pr.fwd(a * DEG, b * DEG);
            String left, right;
            if (o.inv) { left = fmtLon(r.x); right = fmtLat(r.y); }
            else { left = format(o.fmt, r.x); right = format(o.fmt, r.y); }
            if (o.reverseOut) { String t=left; left=right; right=t; }
            if (o.echo) System.out.print((tok.length>0?tok[0]:"") + (tok.length>1?" "+tok[1]:"") + "\t");
            System.out.println(left + "\t" + right + tail);
        }
    }

    static double parseAngle(String s) {
        try { return Double.parseDouble(s); } catch (Exception ignored) {}
        int sign = (s.contains("W") || s.contains("S") || s.startsWith("-")) ? -1 : 1;
        s = s.replaceAll("[NSEWnsew]", "").replace('-', ' ').trim();
        double deg=0,min=0,sec=0;
        String[] p = s.split("[dD'\":]+");
        try { if (p.length>0 && !p[0].isEmpty()) deg=Double.parseDouble(p[0].trim()); if (p.length>1) min=Double.parseDouble(p[1]); if (p.length>2) sec=Double.parseDouble(p[2]); } catch(Exception e) { return 0; }
        return sign * (Math.abs(deg) + min/60.0 + sec/3600.0);
    }
    static String fmtLon(double v) { return trim(Math.abs(v)) + "d" + (v < -1e-12 ? "W" : "E"); }
    static String fmtLat(double v) { return trim(Math.abs(v)) + "d" + (v < -1e-12 ? "S" : "N"); }
    static String trim(double v) {
        if (Math.abs(v - Math.rint(v)) < 1e-7) return String.format(Locale.US, "%.0f", v);
        return String.format(Locale.US, "%.9f", v).replaceAll("0+$","").replaceAll("\\.$","");
    }
    static String format(String fmt, double v) {
        try { return String.format(Locale.US, fmt, v); } catch(Exception e) { return String.format(Locale.US, "%.2f", v); }
    }
    static double val(Map<String,String> p, String k, double d) { try { return Double.parseDouble(p.get(k)); } catch(Exception e){ return d; } }
    static double aval(Map<String,String> p, String k, double d) { return val(p, k, d) * DEG; }

    static Ellipsoid ellipsoid(Map<String,String> p) {
        Ellipsoid e = new Ellipsoid();
        if (p.containsKey("R")) e.sphere(val(p,"R",6378137));
        if (p.containsKey("a")) {
            double a = val(p,"a",6378137), b = p.containsKey("b") ? val(p,"b",a) : a;
            if (p.containsKey("rf")) b = a * (1 - 1 / val(p,"rf",298.257223563));
            e.setAB(a,b);
        }
        String ellps = p.getOrDefault("ellps", p.getOrDefault("datum", ""));
        if (ellps.equalsIgnoreCase("sphere")) e.sphere(6370997);
        return e;
    }

    static Proj projection(String name, Map<String,String> p, Ellipsoid e) {
        double lon0=aval(p,"lon_0",0), lat0=aval(p,"lat_0",0), x0=val(p,"x_0",0), y0=val(p,"y_0",0), k0=val(p,"k", val(p,"k_0",1));
        switch(name) {
            case "merc": return merc(p,e,lon0,x0,y0,k0);
            case "webmerc": return sphMerc(6378137, lon0, x0, y0, k0);
            case "eqc": case "plate_carree": return eqc(e, lon0, aval(p,"lat_ts",0), x0, y0);
            case "utm": {
                int z=(int)val(p,"zone",31); double l0=(z*6-183)*DEG; double yy = p.containsKey("south") ? 10000000 : 0;
                return tmerc(e,0,l0,500000,yy,0.9996);
            }
            case "tmerc": case "etmerc": return tmerc(e,lat0,lon0,x0,y0,k0);
            case "lcc": return lcc(e, lat0, lon0, aval(p,"lat_1",lat0*RAD), aval(p,"lat_2",lat0*RAD), x0,y0,k0);
            case "aea": return aea(e, lat0, lon0, aval(p,"lat_1",lat0*RAD), aval(p,"lat_2",lat0*RAD), x0,y0,k0);
            case "laea": return az(e.a, lat0, lon0, x0,y0,k0, "laea");
            case "aeqd": return az(e.a, lat0, lon0, x0,y0,k0, "aeqd");
            case "ortho": return az(e.a, lat0, lon0, x0,y0,k0, "ortho");
            case "stere": return az(e.a, lat0, lon0, x0,y0,k0, "stere");
            case "sinu": return simple(e.a, lon0,x0,y0,0);
            case "moll": return simple(e.a, lon0,x0,y0,1);
            case "robin": return simple(e.a, lon0,x0,y0,2);
            case "vandg": return simple(e.a, lon0,x0,y0,3);
            default: return null;
        }
    }

    static Proj sphMerc(double R, double lon0, double x0, double y0, double k) {
        return new Proj(){ public Point fwd(double lon,double lat){ return new Point(x0+R*k*norm(lon-lon0), y0+R*k*Math.log(Math.tan(Math.PI/4+lat/2))); }
            public Point inv(double x,double y){ return new Point((lon0+(x-x0)/(R*k))*RAD, (2*Math.atan(Math.exp((y-y0)/(R*k)))-Math.PI/2)*RAD); }};
    }
    static Proj merc(Map<String,String> p, Ellipsoid e, double lon0, double x0, double y0, double k) {
        if (e.e2 == 0) return sphMerc(e.a,lon0,x0,y0,k);
        return new Proj(){ public Point fwd(double lon,double lat){ double s=Math.sin(lat); double y=Math.log(Math.tan(Math.PI/4+lat/2)*Math.pow((1-e.e*s)/(1+e.e*s), e.e/2)); return new Point(x0+e.a*k*norm(lon-lon0), y0+e.a*k*y); }
            public Point inv(double x,double y){ double ts=Math.exp(-(y-y0)/(e.a*k)); double phi=Math.PI/2-2*Math.atan(ts); for(int i=0;i<8;i++){double es=e.e*Math.sin(phi); phi=Math.PI/2-2*Math.atan(ts*Math.pow((1-es)/(1+es),e.e/2));} return new Point((lon0+(x-x0)/(e.a*k))*RAD, phi*RAD); }};
    }
    static Proj eqc(Ellipsoid e, double lon0, double latTs, double x0, double y0) {
        double c = e.e2 == 0 ? Math.cos(latTs) : Math.cos(latTs) / Math.sqrt(1 - e.e2 * Math.sin(latTs) * Math.sin(latTs));
        return new Proj(){
            public Point fwd(double lon,double lat){ return new Point(x0+e.a*c*norm(lon-lon0), y0+(e.e2==0?e.a*lat:merid(e,lat))); }
            public Point inv(double x,double y){ double lat=(y-y0)/e.a; for(int i=0;i<8 && e.e2!=0;i++){ double m=merid(e,lat)-(y-y0); double dm=e.a*(1-e.e2)/Math.pow(1-e.e2*Math.sin(lat)*Math.sin(lat),1.5); lat-=m/dm; } return new Point((lon0+(x-x0)/(e.a*c))*RAD, lat*RAD); }
        };
    }
    static Proj tmerc(Ellipsoid e, double lat0, double lon0, double x0, double y0, double k0) {
        return new Proj(){ public Point fwd(double lon,double lat){ double ep2=e.e2/(1-e.e2), N=e.a/Math.sqrt(1-e.e2*Math.sin(lat)*Math.sin(lat)), T=Math.pow(Math.tan(lat),2), C=ep2*Math.pow(Math.cos(lat),2), A=norm(lon-lon0)*Math.cos(lat); double M=merid(e,lat)-merid(e,lat0); double x=x0+k0*N*(A+(1-T+C)*Math.pow(A,3)/6+(5-18*T+T*T+72*C-58*ep2)*Math.pow(A,5)/120); double y=y0+k0*(M+N*Math.tan(lat)*(A*A/2+(5-T+9*C+4*C*C)*Math.pow(A,4)/24+(61-58*T+T*T+600*C-330*ep2)*Math.pow(A,6)/720)); return new Point(x,y);}
            public Point inv(double x,double y){ double ep2=e.e2/(1-e.e2), M=(y-y0)/k0+merid(e,lat0), mu=M/(e.a*(1-e.e2/4-3*e.e2*e.e2/64-5*Math.pow(e.e2,3)/256)); double e1=(1-Math.sqrt(1-e.e2))/(1+Math.sqrt(1-e.e2)); double fp=mu+(3*e1/2-27*Math.pow(e1,3)/32)*Math.sin(2*mu)+(21*e1*e1/16-55*Math.pow(e1,4)/32)*Math.sin(4*mu)+(151*Math.pow(e1,3)/96)*Math.sin(6*mu); double C1=ep2*Math.pow(Math.cos(fp),2), T1=Math.pow(Math.tan(fp),2), N1=e.a/Math.sqrt(1-e.e2*Math.sin(fp)*Math.sin(fp)), R1=e.a*(1-e.e2)/Math.pow(1-e.e2*Math.sin(fp)*Math.sin(fp),1.5), D=(x-x0)/(N1*k0); double lat=fp-(N1*Math.tan(fp)/R1)*(D*D/2-(5+3*T1+10*C1-4*C1*C1-9*ep2)*Math.pow(D,4)/24+(61+90*T1+298*C1+45*T1*T1-252*ep2-3*C1*C1)*Math.pow(D,6)/720); double lon=lon0+(D-(1+2*T1+C1)*Math.pow(D,3)/6+(5-2*C1+28*T1-3*C1*C1+8*ep2+24*T1*T1)*Math.pow(D,5)/120)/Math.cos(fp); return new Point(lon*RAD,lat*RAD);} };
    }
    static double merid(Ellipsoid e,double p){double n=e.e2; return e.a*((1-n/4-3*n*n/64-5*n*n*n/256)*p-(3*n/8+3*n*n/32+45*n*n*n/1024)*Math.sin(2*p)+(15*n*n/256+45*n*n*n/1024)*Math.sin(4*p)-(35*n*n*n/3072)*Math.sin(6*p));}
    static Proj lcc(Ellipsoid e,double lat0,double lon0,double lat1,double lat2,double x0,double y0,double k){ if(Math.abs(lat1+lat2)<1e-12) return null; double n=Math.abs(lat1-lat2)<1e-12?Math.sin(lat1):Math.log(Math.cos(lat1)/Math.cos(lat2))/Math.log(Math.tan(Math.PI/4+lat2/2)/Math.tan(Math.PI/4+lat1/2)); double F=Math.cos(lat1)*Math.pow(Math.tan(Math.PI/4+lat1/2),n)/n; double r0=e.a*k*F/Math.pow(Math.tan(Math.PI/4+lat0/2),n); return new Proj(){public Point fwd(double lon,double lat){double r=e.a*k*F/Math.pow(Math.tan(Math.PI/4+lat/2),n), th=n*norm(lon-lon0); return new Point(x0+r*Math.sin(th), y0+r0-r*Math.cos(th));} public Point inv(double x,double y){double dx=x-x0, dy=r0-(y-y0), r=Math.copySign(Math.hypot(dx,dy),n), th=Math.atan2(dx,dy); double lat=2*Math.atan(Math.pow(e.a*k*F/r,1/n))-Math.PI/2; return new Point((lon0+th/n)*RAD,lat*RAD);}}; }
    static Proj aea(Ellipsoid e,double lat0,double lon0,double lat1,double lat2,double x0,double y0,double k){ if(Math.abs(lat1+lat2)<1e-12) return null; double m1=ms(e,lat1), q1=qs(e,lat1), q2=qs(e,lat2), q0=qs(e,lat0); double n=Math.abs(lat1-lat2)<1e-12?Math.sin(lat1):(m1*m1-ms(e,lat2)*ms(e,lat2))/(q2-q1); double C=m1*m1+n*q1, r0=e.a*k*Math.sqrt(Math.max(0,C-n*q0))/n; return new Proj(){public Point fwd(double lon,double lat){double r=e.a*k*Math.sqrt(Math.max(0,C-n*qs(e,lat)))/n, th=n*norm(lon-lon0); return new Point(x0+r*Math.sin(th), y0+r0-r*Math.cos(th));} public Point inv(double x,double y){double dx=x-x0, dy=r0-(y-y0), r=Math.copySign(Math.hypot(dx,dy),n), q=(C-(r*n/(e.a*k))*(r*n/(e.a*k)))/n, lat=asinQ(e,q); double lon=lon0+Math.atan2(dx,dy)/n; return new Point(lon*RAD,lat*RAD);}}; }
    static double ms(Ellipsoid e,double p){return Math.cos(p)/Math.sqrt(1-e.e2*Math.sin(p)*Math.sin(p));}
    static double qs(Ellipsoid e,double p){ if(e.e2==0)return 2*Math.sin(p); double s=Math.sin(p); return (1-e.e2)*(s/(1-e.e2*s*s)-Math.log((1-e.e*s)/(1+e.e*s))/(2*e.e));}
    static double asinQ(Ellipsoid e,double q){ if(e.e2==0)return Math.asin(q/2); double p=Math.asin(q/2); for(int i=0;i<8;i++){double f=qs(e,p)-q; double d=2*(1-e.e2)*Math.cos(p)/Math.pow(1-e.e2*Math.sin(p)*Math.sin(p),2); p-=f/d;} return p; }
    static Proj az(double R,double lat0,double lon0,double x0,double y0,double k,String type){ return new Proj(){public Point fwd(double lon,double lat){double d=norm(lon-lon0), sp=Math.sin(lat0)*Math.sin(lat)+Math.cos(lat0)*Math.cos(lat)*Math.cos(d); double c=Math.acos(Math.max(-1,Math.min(1,sp))); double kk; if(type.equals("ortho")) kk=1; else if(type.equals("laea")) kk=Math.sqrt(2/(1+sp)); else if(type.equals("stere")) kk=2/(1+sp); else kk=c==0?1:c/Math.sin(c); double x=R*k*kk*Math.cos(lat)*Math.sin(d), y=R*k*kk*(Math.cos(lat0)*Math.sin(lat)-Math.sin(lat0)*Math.cos(lat)*Math.cos(d)); return new Point(x0+x,y0+y);} public Point inv(double x,double y){double X=(x-x0)/(R*k),Y=(y-y0)/(R*k),rho=Math.hypot(X,Y),c=type.equals("stere")?2*Math.atan(rho/2):(type.equals("laea")?2*Math.asin(rho/2):rho); if(type.equals("ortho")) c=Math.asin(Math.min(1,rho)); double lat=Math.asin(Math.cos(c)*Math.sin(lat0)+(rho==0?0:Y*Math.sin(c)*Math.cos(lat0)/rho)); double lon=lon0+Math.atan2(X*Math.sin(c),rho*Math.cos(lat0)*Math.cos(c)-Y*Math.sin(lat0)*Math.sin(c)); return new Point(lon*RAD,lat*RAD);}}; }
    static Proj simple(double R,double lon0,double x0,double y0,int type){ return new Proj(){public Point fwd(double lon,double lat){double l=norm(lon-lon0), x,y; if(type==0){x=R*l*Math.cos(lat);y=R*lat;} else if(type==1){double th=lat; for(int i=0;i<10;i++) th-=(2*th+Math.sin(2*th)-Math.PI*Math.sin(lat))/(2+2*Math.cos(2*th)); x=R*2*Math.sqrt(2)/Math.PI*l*Math.cos(th); y=R*Math.sqrt(2)*Math.sin(th);} else if(type==2){x=R*l*Math.cos(lat)*0.8487;y=R*lat*0.965;} else {x=R*l*(1-Math.abs(lat)/Math.PI*0.15);y=R*lat*1.10;} return new Point(x0+x,y0+y);} public Point inv(double x,double y){return new Point(lon0*RAD+(x-x0)/R*RAD,(y-y0)/R*RAD);}}; }
    static double norm(double x){ while(x>Math.PI)x-=2*Math.PI; while(x<-Math.PI)x+=2*Math.PI; return x; }

    static void die(String msg){ System.err.println(REL+"\n<executable>: \n"+msg+"\nprogram abnormally terminated"); System.exit(1); }
    static void listProj(){ String[] s={"adams_hemi : Adams Hemisphere in a Square","aea : Albers Equal Area","aeqd : Azimuthal Equidistant","laea : Lambert Azimuthal Equal Area","lcc : Lambert Conformal Conic","merc : Mercator","tmerc : Transverse Mercator","utm : Universal Transverse Mercator (UTM)","webmerc : Web Mercator / Pseudo Mercator","eqc : Equidistant Cylindrical (Plate Carree)","lonlat : Lat/long (Geodetic)"}; for(String x:s)System.out.println(x); }
    static void listEllps(){ System.out.println("    WGS84 a=6378137.0      rf=298.257223563 WGS 84"); System.out.println("   sphere a=6370997.0      b=6370997.0      Normal Sphere (r=6370997)"); System.out.println("    GRS80 a=6378137.0      rf=298.257222101 GRS 1980(IUGG, 1980)"); }
    static void listUnits(){ System.out.println("           m 1                    metre"); System.out.println("          km 1000                 kilometre"); System.out.println("          ft 0.3048               foot"); System.out.println("       us-ft 0.304800609601219    US survey foot"); }
}
