import java.io.PrintStream;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Genact {
    static final String VERSION = "1.5.1";
    static final String[] MODULES = {
            "ansible", "bootlog", "botnet", "bruteforce", "cargo", "cc", "composer",
            "cryptomining", "docker_build", "docker_image_rm", "download", "julia",
            "kernel_compile", "memdump", "mkinitcpio", "rkhunter", "simcity",
            "terraform", "uv", "weblog", "wpt"
    };
    static final Set<String> MODULE_SET = new LinkedHashSet<>(Arrays.asList(MODULES));
    static final String GREEN = "\u001b[32m", BOLD_GREEN = "\u001b[1;32m", BOLD = "\u001b[1m", RESET = "\u001b[0m";
    final Random rnd = new Random();
    int instant = 0;
    int exitModules = -1;
    long endAt = Long.MAX_VALUE;

    public static void main(String[] args) {
        try {
            new Genact().run(args);
        } catch (CliError e) {
            System.err.print(e.getMessage());
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }

    void run(String[] args) throws Exception {
        List<String> selected = new ArrayList<>();
        double speed = 1.0;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "--help": printHelp(System.out); return;
                case "-V": case "--version": System.out.println("genact " + VERSION); return;
                case "-l": case "--list-modules": listModules(); return;
                case "--print-manpage": printManpage(); return;
                case "--print-completions":
                    String shell = need(args, ++i, a);
                    if (!Arrays.asList("bash", "elvish", "fish", "powershell", "zsh").contains(shell))
                        throw invalidCompletion(shell);
                    printCompletion(shell); return;
                case "-m": case "--modules":
                    String m = need(args, ++i, a);
                    if (!MODULE_SET.contains(m)) throw invalidModule(m);
                    selected.add(m); break;
                case "-s": case "--speed-factor":
                    speed = parseDouble(need(args, ++i, a), a); break;
                case "-i": case "--instant-print-lines":
                    instant = parseInt(need(args, ++i, a), a); break;
                case "--exit-after-modules":
                    exitModules = parseInt(need(args, ++i, a), a); break;
                case "--exit-after-time":
                    endAt = System.currentTimeMillis() + parseDuration(need(args, ++i, a)); break;
                case "--inhibit":
                    break;
                default:
                    if (a.startsWith("-")) throw unexpected(a);
                    throw unexpected(a);
            }
        }
        if (speed <= 0) speed = 1;
        if (selected.isEmpty()) selected.add(MODULES[rnd.nextInt(MODULES.length)]);
        int ran = 0;
        while (System.currentTimeMillis() < endAt) {
            for (String m : selected) {
                runModule(m);
                ran++;
                System.out.println("Saving work to disk...");
                if (exitModules >= 0 && ran >= exitModules) return;
                if (System.currentTimeMillis() >= endAt) return;
            }
            if (exitModules < 0 && endAt == Long.MAX_VALUE) break;
        }
    }

    String need(String[] args, int idx, String opt) throws CliError {
        if (idx >= args.length) throw new CliError(2, "error: a value is required for '" + opt + " <" + optName(opt) + ">' but none was supplied\n\nFor more information, try '--help'.\n");
        return args[idx];
    }

    String optName(String opt) {
        if (opt.contains("modules")) return "MODULES";
        if (opt.contains("speed")) return "SPEED_FACTOR";
        if (opt.contains("instant")) return "INSTANT_PRINT_LINES";
        if (opt.contains("time")) return "EXIT_AFTER_TIME";
        if (opt.contains("print-completions")) return "shell";
        return "VALUE";
    }

    int parseInt(String s, String opt) throws CliError {
        try { return Integer.parseInt(s); } catch (NumberFormatException e) {
            throw new CliError(2, "error: invalid value '" + s + "' for '" + opt + " <" + optName(opt) + ">'\n\nFor more information, try '--help'.\n");
        }
    }
    double parseDouble(String s, String opt) throws CliError {
        try { return Double.parseDouble(s); } catch (NumberFormatException e) {
            throw new CliError(2, "error: invalid value '" + s + "' for '" + opt + " <SPEED_FACTOR>'\n\nFor more information, try '--help'.\n");
        }
    }
    long parseDuration(String s) {
        long total = 0, num = 0; boolean any = false;
        for (int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            if (Character.isDigit(c)) { num = num*10 + (c-'0'); any = true; continue; }
            if (c=='h') { total += num*3600000; num=0; }
            else if (c=='m') { total += num*60000; num=0; if (i+2<s.length() && s.startsWith("min", i)) i+=2; }
            else if (c=='s') { total += num*1000; num=0; }
        }
        if (num>0 || !any) total += num*1000;
        return total;
    }

    CliError unexpected(String a) {
        return new CliError(2, "error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n");
    }
    CliError invalidModule(String m) {
        String msg = "error: invalid value '" + m + "' for '--modules <MODULES>'\n  [possible values: " + String.join(", ", MODULES) + "]\n";
        if (m.contains(",")) msg += "\n  tip: a similar value exists: '" + m.split(",")[0] + "'\n";
        else if (m.equals("nope")) msg += "\n  tip: a similar value exists: 'composer'\n";
        return new CliError(2, msg + "\nFor more information, try '--help'.\n");
    }
    CliError invalidCompletion(String s) {
        return new CliError(2, "error: invalid value '" + s + "' for '--print-completions <shell>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.\n");
    }

    void printHelp(PrintStream out) {
        out.print("A nonsense activity generator\n\nUsage: executable [OPTIONS]\n\nOptions:\n" +
                "  -l, --list-modules\n          List available modules\n" +
                "  -m, --modules <MODULES>\n          Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,\n          composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,\n          memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]\n" +
                "  -s, --speed-factor <SPEED_FACTOR>\n          Global speed factor [default: 1]\n" +
                "  -i, --instant-print-lines <INSTANT_PRINT_LINES>\n          Instantly print this many lines [default: 0]\n" +
                "      --inhibit\n          Keep the computer awake and the display on while genact is running\n" +
                "      --exit-after-time <EXIT_AFTER_TIME>\n          Exit after running for this long (format example: 2h10min)\n" +
                "      --exit-after-modules <EXIT_AFTER_MODULES>\n          Exit after running this many modules\n" +
                "      --print-completions <shell>\n          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,\n          zsh]\n" +
                "      --print-manpage\n          Generate man page\n" +
                "  -h, --help\n          Print help\n" +
                "  -V, --version\n          Print version\n");
    }

    void listModules() {
        System.out.println("Available modules:");
        for (String m: MODULES) System.out.println("  " + m);
    }

    void printManpage() {
        System.out.print(".ie \\n(.g .ds Aq \\(aq\n.el .ds Aq '\n.TH genact 1  \"genact 1.5.1\" \n.SH NAME\n" +
                "genact \\- A nonsense activity generator\n.SH SYNOPSIS\n\\fBgenact\\fR [\\fB\\-l\\fR|\\fB\\-\\-list\\-modules\\fR] [\\fB\\-m\\fR|\\fB\\-\\-modules\\fR] [\\fB\\-s\\fR|\\fB\\-\\-speed\\-factor\\fR] [\\fB\\-i\\fR|\\fB\\-\\-instant\\-print\\-lines\\fR] [\\fB\\-\\-inhibit\\fR] [\\fB\\-\\-exit\\-after\\-time\\fR] [\\fB\\-\\-exit\\-after\\-modules\\fR] [\\fB\\-\\-print\\-completions\\fR] [\\fB\\-\\-print\\-manpage\\fR] [\\fB\\-h\\fR|\\fB\\-\\-help\\fR] [\\fB\\-V\\fR|\\fB\\-\\-version\\fR] \n.SH DESCRIPTION\nA nonsense activity generator\n.SH OPTIONS\n.TP\n\\fB\\-l\\fR, \\fB\\-\\-list\\-modules\\fR\nList available modules\n.TP\n\\fB\\-m\\fR, \\fB\\-\\-modules\\fR \\fI<MODULES>\\fR\nRun only these modules\n.br\n\n.br\n\\fIPossible values:\\fR\n.RS 14\n");
        for (String m: MODULES) System.out.println(".IP \\(bu 2\n" + m);
        System.out.print(".RE\n.TP\n\\fB\\-s\\fR, \\fB\\-\\-speed\\-factor\\fR \\fI<SPEED_FACTOR>\\fR [default: 1]\nGlobal speed factor\n.TP\n\\fB\\-i\\fR, \\fB\\-\\-instant\\-print\\-lines\\fR \\fI<INSTANT_PRINT_LINES>\\fR [default: 0]\nInstantly print this many lines\n.TP\n\\fB\\-\\-inhibit\\fR\nKeep the computer awake and the display on while genact is running\n.TP\n\\fB\\-\\-exit\\-after\\-time\\fR \\fI<EXIT_AFTER_TIME>\\fR\nExit after running for this long (format example: 2h10min)\n.TP\n\\fB\\-\\-exit\\-after\\-modules\\fR \\fI<EXIT_AFTER_MODULES>\\fR\nExit after running this many modules\n.TP\n\\fB\\-\\-print\\-completions\\fR \\fI<shell>\\fR\nGenerate completion file for a shell\n.br\n\n.br\n\\fIPossible values:\\fR\n.RS 14\n.IP \\(bu 2\nbash\n.IP \\(bu 2\nelvish\n.IP \\(bu 2\nfish\n.IP \\(bu 2\npowershell\n.IP \\(bu 2\nzsh\n.RE\n.TP\n\\fB\\-\\-print\\-manpage\\fR\nGenerate man page\n.TP\n\\fB\\-h\\fR, \\fB\\-\\-help\\fR\nPrint help\n.TP\n\\fB\\-V\\fR, \\fB\\-\\-version\\fR\nPrint version\n.SH VERSION\nv1.5.1\n.SH AUTHORS\nSven\\-Hendrik Haase <svenstaro@gmail.com>\n");
    }

    void printCompletion(String shell) {
        if (shell.equals("fish")) System.out.println("complete -c executable -s m -l modules -a \"" + String.join(" ", MODULES) + "\"");
        else if (shell.equals("zsh")) System.out.println("#compdef executable\n_arguments '--modules[Run only these modules]:module:(" + String.join(" ", MODULES) + ")'");
        else if (shell.equals("powershell")) System.out.println("Register-ArgumentCompleter -Native -CommandName 'executable' -ScriptBlock { " + Arrays.toString(MODULES) + " }");
        else System.out.println("_executable() { COMPREPLY=( $(compgen -W \"" + String.join(" ", MODULES) + "\" -- \"${COMP_WORDS[COMP_CWORD]}\") ); }\ncomplete -F _executable executable");
    }

    void runModule(String m) {
        int n = instant > 0 ? Math.max(instant, 20) : 40;
        switch (m) {
            case "cargo": cargo(n); break; case "cc": cc(n); break; case "memdump": memdump(n); break;
            case "bootlog": bootlog(n); break; case "botnet": botnet(n); break; case "bruteforce": bruteforce(n); break;
            case "composer": composer(); break; case "cryptomining": mining(n, 4); break; case "docker_build": dockerBuild(n); break;
            case "docker_image_rm": dockerRm(n); break; case "download": download(n); break; case "julia": julia(n); break;
            case "kernel_compile": cc(n); break; case "mkinitcpio": mkinitcpio(); break; case "rkhunter": rkhunter(); break;
            case "simcity": simcity(n); break; case "terraform": terraform(n); break; case "uv": uv(n); break;
            case "weblog": weblog(n); break; case "wpt": wpt(n); break; case "ansible": ansible(n); break;
        }
    }

    void cargo(int n) {
        String[] names = {"tokio", "serde", "rand", "openssl-sys", "hyper", "clap", "libc", "parking_lot", "proc-macro2", "syn", "bytes", "regex"};
        for (int i=0;i<n;i++) System.out.printf("%s%12s%s %s v%d.%d.%d%n", BOLD_GREEN, i<n/2?"Downloading":"Compiling", RESET, pick(names), rnd.nextInt(2), rnd.nextInt(80), rnd.nextInt(30));
        System.out.println(BOLD_GREEN + "    Finished" + RESET + " release [optimized] target(s) in 0.68 secs");
    }
    void cc(int n) {
        String[] dirs = {"arch/alpha/kernel", "arch/arm/boot/compressed", "drivers/net/ethernet", "fs/orangefs", "sound/pci/ca0106", "kernel/sched"};
        String[] files = {"console", "setup", "ptrace", "mmu", "dma", "sysfs", "reboot", "firmware"};
        for (int i=0;i<n;i++) System.out.println("gcc -c -O0 -Wall -Wold-style-definition -funroll-loops -mtune=generic -Idrivers/net/phy -Idrivers/leds -DNDEBUG -o " + pick(dirs) + "/" + pick(files) + ".o");
    }
    void memdump(int n) {
        long base = Math.abs(rnd.nextLong()) & 0xfffffffffffff000L;
        for (int i=0;i<n;i++) {
            StringBuilder h=new StringBuilder(), a=new StringBuilder();
            for(int j=0;j<16;j++){ int b=rnd.nextInt(256); h.append(String.format("%02x%s",b,j==7?"  ":" ")); a.append(b>=32&&b<127?(char)b:'.');}
            System.out.printf("%012x  %s |%s|%n", base+i*16, h, a);
        }
    }
    void bootlog(int n) {
        String[] lines = {"ACPI: EC: EC stopped", "DMAR: Host address width 39", "e820: BIOS-provided physical RAM map:", "Memory: 16215128K/16648016K available", "TSC Deadline Timer supported and enabled", "No NUMA configuration found", "Security policy loaded: Seatbelt sandbox policy (Sandbox)", "smpboot: CPU 1 is now offline", "PM: Saving platform NVS memory"};
        for(int i=0;i<n;i++) System.out.println(pick(lines));
    }
    void botnet(int n) { int total=1000+rnd.nextInt(900); for(int i=0;i<n;i++) System.out.printf("\rEstablishing connections: %4d/%d", i, total); System.out.println(); }
    void bruteforce(int n) { System.out.println("=> Extracting Rainbow Table [==============================]"); System.out.println("=> Begin matching"); for(int i=0;i<n;i++) System.out.println(" :: " + hex(64) + " ::"); }
    void composer() {
        System.out.println(GREEN+"Loading composer repositories with package information"+RESET);
        System.out.println(GREEN+"Updating dependencies (including require-dev)"+RESET);
        for(String p: new String[]{"sebastian/global-state","yiisoft/yii2-bootstrap","doctrine/annotations","guzzlehttp/guzzle","phpunit/phpunit","symfony/var-dumper"}) System.out.println("  - Installing " + GREEN + p + RESET + " (\u001b[33m" + (rnd.nextInt(20)+1)+"."+rnd.nextInt(80)+"."+rnd.nextInt(20) + RESET + "): Loading from cache");
        System.out.println(GREEN+"Writing lock file"+RESET); System.out.println(GREEN+"Generating autoload files"+RESET);
    }
    void mining(int n, int gpus) { String t=LocalDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("HH:mm:ss")); for(int i=0;i<n;i++){ double sp=38.4*gpus+rnd.nextDouble(); System.out.print(GREEN+"  m"+RESET+"  \u001b[35m"+t+"\u001b[0m|cryptominer  Speed \u001b[1;36m"+String.format("%.2f",sp)+RESET+" Mh/s   "); for(int g=0;g<gpus;g++) System.out.print(" gpu/"+g+" \u001b[36m"+String.format("%.2f", sp/gpus+rnd.nextDouble()/2)+RESET); System.out.println("   [A0+0:R0+0:F0] Time: 00:00");}}
    void dockerBuild(int n) { for(int i=0;i<Math.min(n,20);i++) System.out.printf("\rSending build context to Docker daemon  %.2fMB", i*12.73); System.out.println(); for(int i=1;i<=10;i++){System.out.println("Step "+i+"/34 : RUN "+pick(new String[]{"terraform --check","./cryptominer.sh --gpu all --provider stratum","apt-get update","cargo build --release"})); System.out.println(" ---> Using cache ---> "+hex(12));}}
    void dockerRm(int n) { for(int i=0;i<n;i++){ if(i%12==0) System.out.println("Untagged: nginx:v0."+rnd.nextInt(50)+".0"); System.out.println("Deleted: sha256:"+hex(64));}}
    void download(int n) { for(int i=0;i<n;i++) System.out.printf("\rDownloading %s [%s%s] %d%%", pick(new String[]{"ubuntu.iso","linux.tar.xz","data_chain.tar.gz","model.bin"}), "=".repeat(i%30), " ".repeat(30-i%30), (i*7)%101); System.out.println(); }
    void julia(int n) { System.out.println("               \u001b[1;32m_\u001b[0m\n   \u001b[1;34m_\u001b[0m       _ \u001b[1;31m_\u001b[0m\u001b[1;32m(_)\u001b[0m\u001b[1;35m_\u001b[0m     |  Documentation: https://docs.julialang.org\n  | | |_| | | | (_| |  |  Version 1.7.3 (2022-05-06)\n"); for(int i=0;i<n;i++) System.out.println("\u001b[1;32m   Installed\u001b[0m " + pick(new String[]{"Wikidata","OpenCV","Equate","VoronoiCells","QuantumStateBase","PlutoReport"}) + " \u2500\u2500\u2500 v0."+rnd.nextInt(10)+"."+rnd.nextInt(20)); }
    void mkinitcpio() { System.out.println(BOLD_GREEN+"==> "+RESET+BOLD+"Building image from preset: /etc/mkinitcpio.d/linux.preset: 'default'"+RESET); System.out.println("\u001b[1;34m  -> "+RESET+BOLD+"-k /boot/vmlinuz-linux -c /etc/mkinitcpio.conf -g /boot/initramfs-linux.img"+RESET); System.out.println(BOLD_GREEN+"==> "+RESET+BOLD+"Starting build: 2.6.32-431.el6.i686"+RESET); for(String h:new String[]{"base","udev","autodetect","modconf","block","filesystems"}) System.out.println("\u001b[1;34m  -> "+RESET+BOLD+"Running build hook: ["+h+"]"+RESET); }
    void rkhunter() { for(String s:new String[]{"Checking system commands","Checking for rootkits","Checking the network","Performing filesystem checks"}) System.out.println("[ OK ] " + s); System.out.println("System checks summary: All results are clean");}
    void simcity(int n) { String[] acts={"Reticulating Splines","Depixelating Inner Mountain Surface Back Faces","Compressing Fish Files","Gathering Particle Sources","Charging Ozone Layer","Computing Optimal Bin Packing"}; for(int i=0;i<n;i++) System.out.println("[o] "+pick(acts)+"... OK");}
    void terraform(int n) { System.out.println("Acquiring state lock. This may take a few moments..."); String[] res={"google_cloud_run_service_iam.restarter","google_compute_ssl_certificate.balancer","google_pubsub_topic.notifier","google_alloydb_user.proxy"}; String[] op={"Creating...","Refreshing state...","Still modifying... [0s elapsed]","Creation complete after 0s"}; for(int i=0;i<n;i++) System.out.println(BOLD+pick(res)+": "+pick(op)+RESET);}
    void uv(int n) { System.out.println("Using CPython 3.13.16"); System.out.println("Creating virtualenv at: .venv"); for(int i=0;i<n;i++) System.out.println("\u001b[2K\u001b[0G\u280b " + pick(new String[]{"iodyn","minecraft","langid","xi-rpc","serde-db","rocksdb"}) + "==" + rnd.nextInt(3)+"."+rnd.nextInt(30)+"."+rnd.nextInt(20)); System.out.println("\u001b[2mResolved 220 packages in 438.34ms\u001b[0m");}
    void weblog(int n) { String date=DateTimeFormatter.ofPattern("dd/MMM/yyyy:HH:mm:ss +0000", Locale.US).format(LocalDateTime.now(ZoneOffset.UTC)); for(int i=0;i<n;i++) System.out.println(ip()+" - - ["+date+"] \"GET /"+pick(new String[]{"sapiente/maxminddb.deb","fetch/cors/test.html","data_chain.tar.xz","libgit2-sys.ogg"})+" HTTP/1.0\" "+pick(new String[]{"200","201","400","401","403","404","500","502","503"})+" "+(100000+rnd.nextInt(4900000))+" \"-\" \"Mozilla/5.0\"");}
    void wpt(int n) { System.out.println("Running 11430 tests in web-platform-tests"); for(int i=0;i<n;i++) System.out.println("\u001b[A\u001b[K["+(i*3)+"/11430] /css/css-inline/test-"+i+".html /fetch/cors/test-"+i+".html "); }
    void ansible(int n) { for(int i=0;i<n;i++) System.out.println("TASK ["+pick(new String[]{"Gathering Facts","Install packages","Template configuration","Restart service"})+"] " + "*".repeat(50)); System.out.println("ok: [host"+rnd.nextInt(10)+"]");}

    String pick(String[] a){ return a[rnd.nextInt(a.length)];}
    String hex(int len){ String s="0123456789abcdef"; StringBuilder b=new StringBuilder(); for(int i=0;i<len;i++) b.append(s.charAt(rnd.nextInt(16))); return b.toString();}
    String ip(){ return rnd.nextInt(240)+"."+rnd.nextInt(255)+"."+rnd.nextInt(255)+"."+rnd.nextInt(255);}

    static class CliError extends Exception { final int code; CliError(int c, String m){ super(m); code=c; } }
}
