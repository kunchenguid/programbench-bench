import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Stream;

public class BrootClone {
    static class Opt {
        boolean hidden, onlyFolders, sizes, permissions, dates, trimRoot, noTree;
        boolean sortBySize, sortByDate, sortByTypeDirsFirst, sortByTypeDirsLast, noSort;
        boolean whale, showRootFs, gitStatus;
        int maxDepth = Integer.MAX_VALUE;
        int height = 0;
        String cmd, outcmd, writeDefaultConf, printShellFunction, setInstallState, color = "auto";
        Path root = Paths.get(".").toAbsolutePath().normalize();
    }

    static final String VERSION = "broot 1.54.0";

    public static void main(String[] args) {
        try {
            int code = run(args);
            if (code != 0) System.exit(code);
        } catch (ArgError e) {
            System.err.println(e.getMessage());
            System.exit(2);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    static int run(String[] args) throws Exception {
        Opt o = parse(args);
        if (o.printShellFunction != null) return printShellFunction(o.printShellFunction);
        if (o.writeDefaultConf != null) {
            copyDefaultConf(Paths.get(o.writeDefaultConf));
            return 0;
        }
        if (o.setInstallState != null) return 0;
        if (o.outcmd != null && o.cmd != null && (o.cmd.contains(":cd") || o.cmd.equals("cd"))) {
            Files.writeString(Paths.get(o.outcmd), "cd " + shellQuote(o.root.toString()) + "\n");
            return 0;
        }
        if (o.cmd != null && isPrintTree(o.cmd)) {
            printTree(o, System.out);
            return 0;
        }
        if (o.cmd != null && (o.cmd.equals(":q") || o.cmd.equals("q") || o.cmd.equals(":quit"))) return 0;
        printTree(o, System.out);
        return 0;
    }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        List<String> positionals = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) {
                for (int j = i + 1; j < args.length; j++) positionals.add(args[j]);
                break;
            }
            String val = null;
            int eq = a.indexOf('=');
            if (a.startsWith("--") && eq > 0) {
                val = a.substring(eq + 1);
                a = a.substring(0, eq);
            }
            switch (a) {
                case "--help" -> { printHelp(); System.exit(0); }
                case "--version" -> { System.out.println(VERSION); System.exit(0); }
                case "-d", "--dates" -> o.dates = true;
                case "-D", "--no-dates" -> o.dates = false;
                case "-f", "--only-folders" -> o.onlyFolders = true;
                case "-F", "--no-only-folders" -> o.onlyFolders = false;
                case "-h", "--hidden" -> o.hidden = true;
                case "-H", "--no-hidden" -> o.hidden = false;
                case "-p", "--permissions" -> o.permissions = true;
                case "-P", "--no-permissions" -> o.permissions = false;
                case "-s", "--sizes" -> o.sizes = true;
                case "-S", "--no-sizes" -> o.sizes = false;
                case "-t", "--trim-root" -> o.trimRoot = true;
                case "-T", "--no-trim-root" -> o.trimRoot = false;
                case "-w", "--whale-spotting" -> { o.whale = true; o.hidden = true; o.sortBySize = true; }
                case "-W", "--no-whale-spotting" -> { o.whale = false; o.hidden = false; o.noSort = true; }
                case "-g", "--show-git-info", "-G", "--no-show-git-info", "-i", "--git-ignored", "-I", "--no-git-ignored", "--tree" -> {}
                case "--git-status" -> { o.gitStatus = true; o.hidden = true; }
                case "--show-root-fs" -> o.showRootFs = true;
                case "--no-tree" -> o.noTree = true;
                case "--no-sort" -> o.noSort = true;
                case "--sort-by-size" -> o.sortBySize = true;
                case "--sort-by-date" -> o.sortByDate = true;
                case "--sort-by-type", "--sort-by-type-dirs-first" -> o.sortByTypeDirsFirst = true;
                case "--sort-by-type-dirs-last" -> o.sortByTypeDirsLast = true;
                case "--sort-by-count" -> {}
                case "-c", "--cmd" -> o.cmd = (val != null ? val : value(a, null, args, ++i));
                case "--outcmd" -> o.outcmd = (val != null ? val : value(a, null, args, ++i));
                case "--verb-output" -> { String ignored = (val != null ? val : value(a, null, args, ++i)); }
                case "--color" -> {
                    o.color = (val != null ? val : value(a, null, args, ++i));
                    if (!List.of("auto", "yes", "no").contains(o.color)) throw new ArgError("error: invalid value '" + o.color + "' for '--color <color>'\n  [possible values: auto, yes, no]");
                }
                case "--conf" -> { String ignored = (val != null ? val : value(a, null, args, ++i)); }
                case "--height" -> o.height = parseInt((val != null ? val : value(a, null, args, ++i)), "--height <height>");
                case "--max-depth" -> o.maxDepth = parseInt((val != null ? val : value(a, null, args, ++i)), "--max-depth <MAX_DEPTH>");
                case "--install" -> { printInstallNote(); System.exit(0); }
                case "--set-install-state" -> o.setInstallState = (val != null ? val : value(a, null, args, ++i));
                case "--print-shell-function" -> o.printShellFunction = (val != null ? val : value(a, null, args, ++i));
                case "--write-default-conf" -> o.writeDefaultConf = (val != null ? val : value(a, null, args, ++i));
                case "--listen", "--send" -> { String ignored = (val != null ? val : value(a, null, args, ++i)); }
                case "--listen-auto", "--get-root" -> {}
                default -> {
                    if (a.startsWith("-") && a.length() > 2 && !a.startsWith("--")) {
                        for (int k = 1; k < a.length(); k++) applyShort(o, a.charAt(k));
                    } else if (a.startsWith("-")) {
                        throw new ArgError("error: unexpected argument '" + a + "' found\n\n  tip: to pass '" + a + "' as a value, use '-- " + a + "'\n\nUsage: executable [OPTIONS] [ROOT]");
                    } else positionals.add(a);
                }
            }
        }
        if (!positionals.isEmpty()) o.root = Paths.get(positionals.get(positionals.size() - 1)).toAbsolutePath().normalize();
        return o;
    }

    static void applyShort(Opt o, char c) {
        switch (c) {
            case 'd' -> o.dates = true; case 'D' -> o.dates = false;
            case 'f' -> o.onlyFolders = true; case 'F' -> o.onlyFolders = false;
            case 'h' -> o.hidden = true; case 'H' -> o.hidden = false;
            case 'p' -> o.permissions = true; case 'P' -> o.permissions = false;
            case 's' -> o.sizes = true; case 'S' -> o.sizes = false;
            case 't' -> o.trimRoot = true; case 'T' -> o.trimRoot = false;
            case 'w' -> { o.hidden = true; o.sortBySize = true; }
            default -> throw new ArgError("error: unexpected argument '-" + c + "' found");
        }
    }

    static String value(String opt, String inline, String[] args, int idx) {
        if (inline != null) return inline;
        if (idx >= args.length) throw new ArgError("error: a value is required for '" + opt + " <value>' but none was supplied");
        return args[idx];
    }

    static int parseInt(String s, String name) {
        try { return Integer.parseInt(s); }
        catch (NumberFormatException e) { throw new ArgError("error: invalid value '" + s + "' for '" + name + "': invalid digit found in string"); }
    }

    static boolean isPrintTree(String cmd) {
        for (String part : cmd.split(";")) {
            String p = part.trim();
            if (p.equals(":pt") || p.equals("pt") || p.equals(":print_tree") || p.equals("print_tree")) return true;
        }
        return false;
    }

    static void printTree(Opt o, PrintStream out) throws IOException {
        Path root = o.root;
        if (!Files.exists(root)) throw new IOException("No such file or directory: " + root);
        if (o.showRootFs) out.println("/");
        if (!o.trimRoot) out.println(root.toString());
        if (Files.isDirectory(root)) {
            List<Path> children = listChildren(root, o);
            for (int i = 0; i < children.size(); i++) printNode(children.get(i), "", i == children.size() - 1, 1, o, out);
        }
    }

    static void printNode(Path p, String prefix, boolean last, int depth, Opt o, PrintStream out) throws IOException {
        if (depth > o.maxDepth) return;
        String branch = o.noTree ? "" : prefix + (last ? "└──" : "├──");
        out.println(branch + decorate(p, o));
        if (Files.isDirectory(p) && depth < o.maxDepth && !o.noTree) {
            List<Path> children = listChildren(p, o);
            String np = prefix + (last ? "   " : "│  ");
            for (int i = 0; i < children.size(); i++) printNode(children.get(i), np, i == children.size() - 1, depth + 1, o, out);
        }
    }

    static List<Path> listChildren(Path dir, Opt o) throws IOException {
        try (Stream<Path> s = Files.list(dir)) {
            List<Path> list = new ArrayList<>();
            s.forEach(p -> {
                String n = p.getFileName().toString();
                if (!o.hidden && n.startsWith(".")) return;
                if (o.onlyFolders && !Files.isDirectory(p)) return;
                list.add(p);
            });
            if (!o.noSort) list.sort(comparator(o));
            return list;
        }
    }

    static Comparator<Path> comparator(Opt o) {
        Comparator<Path> byName = Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT));
        if (o.sortBySize) return Comparator.<Path>comparingLong(BrootClone::sizeQuiet).reversed().thenComparing(byName);
        if (o.sortByDate) return Comparator.<Path>comparingLong(BrootClone::mtimeQuiet).reversed().thenComparing(byName);
        if (o.sortByTypeDirsFirst) return Comparator.<Path>comparingInt(p -> Files.isDirectory(p) ? 0 : 1).thenComparing(byName);
        if (o.sortByTypeDirsLast) return Comparator.<Path>comparingInt(p -> Files.isDirectory(p) ? 1 : 0).thenComparing(byName);
        return byName;
    }

    static String decorate(Path p, Opt o) {
        List<String> parts = new ArrayList<>();
        if (o.permissions) parts.add(perms(p));
        if (o.sizes) parts.add(human(sizeQuiet(p)));
        if (o.dates) parts.add(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(mtimeQuiet(p))));
        parts.add(p.getFileName().toString());
        return String.join(" ", parts);
    }

    static long sizeQuiet(Path p) {
        try {
            if (Files.isDirectory(p)) {
                final long[] sum = {0};
                try (Stream<Path> walk = Files.walk(p)) {
                    walk.filter(Files::isRegularFile).forEach(x -> { try { sum[0] += Files.size(x); } catch (IOException ignored) {} });
                }
                return sum[0];
            }
            return Files.size(p);
        } catch (IOException e) { return 0; }
    }

    static long mtimeQuiet(Path p) {
        try { return Files.getLastModifiedTime(p).toMillis(); } catch (IOException e) { return 0; }
    }

    static String perms(Path p) {
        try {
            Set<PosixFilePermission> ps = Files.getPosixFilePermissions(p);
            return (Files.isDirectory(p) ? "d" : "-") + PosixFilePermissions.toString(ps);
        } catch (Exception e) {
            return Files.isDirectory(p) ? "drwxr-xr-x" : "-rw-r--r--";
        }
    }

    static String human(long n) {
        if (n < 1000) return n + " B";
        String[] u = {"K", "M", "G", "T"};
        double v = n;
        int i = -1;
        do { v /= 1000.0; i++; } while (v >= 1000 && i < u.length - 1);
        return String.format(Locale.ROOT, v >= 10 ? "%.0f %s" : "%.1f %s", v, u[i]);
    }

    static void printHelp() {
        System.out.println("broot 1.54.0\n");
        System.out.println("broot lets you explore file hierarchies with a tree-like view, manipulate and preview files, launch actions, and define your own shortcuts.\n");
        System.out.println("Usage: broot [options] [ROOT]\n");
        System.out.println("Options:");
        System.out.println("  --help                         Print help information");
        System.out.println("  --version                      print the version");
        System.out.println("  --conf <paths>                 Semicolon separated paths to specific config files");
        System.out.println("  -d, --dates                    Show the last modified date of files and directories");
        System.out.println("  -f, --only-folders             Only show folders");
        System.out.println("  --max-depth <MAX_DEPTH>        Only show trees up to a certain depth");
        System.out.println("  -h, --hidden                   Show hidden files");
        System.out.println("  -p, --permissions              Show permissions");
        System.out.println("  -s, --sizes                    Show the size of files and directories");
        System.out.println("  --sort-by-size                 Sort by size");
        System.out.println("  --sort-by-date                 Sort by date");
        System.out.println("  --sort-by-type                 Sort by type, directories first");
        System.out.println("  -w, --whale-spotting           Sort by size, show ignored and hidden files");
        System.out.println("  -t, --trim-root                Trim the root too");
        System.out.println("  --outcmd <path>                Where to write the produced cmd (if any)");
        System.out.println("  -c, --cmd <cmd>                Semicolon separated commands to execute");
        System.out.println("  --color <color>                Possible values: auto, yes, no");
        System.out.println("  --height <height>              Height for file export");
        System.out.println("  --print-shell-function <shell> Print to stdout the br function for a given shell");
        System.out.println("  --write-default-conf <path>    Write default conf files in given directory");
    }

    static int printShellFunction(String shell) {
        switch (shell) {
            case "bash", "zsh" -> System.out.print("""

# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `cd`,
# have no useful effect if executed in a subshell.
function br {
    local cmd cmd_file code
    cmd_file=$(mktemp)
    if broot --outcmd "$cmd_file" "$@"; then
        cmd=$(<"$cmd_file")
        command rm -f "$cmd_file"
        eval "$cmd"
    else
        code=$?
        command rm -f "$cmd_file"
        return "$code"
    fi
}

""");
            case "fish" -> System.out.print("""

# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `cd`,
# have no useful effect if executed in a subshell.
function br --wraps=broot
    set -l cmd_file (mktemp)
    if broot --outcmd $cmd_file $argv
        source $cmd_file
        rm -f $cmd_file
    else
        set -l code $status
        rm -f $cmd_file
        return $code
    end
end

""");
            case "nushell" -> System.out.print("""
# Launch broot
export def --env br [file?: path] {
    let cmd_file = (mktemp)
    broot --outcmd $cmd_file $file
    source $cmd_file
    rm -f $cmd_file
}
""");
            default -> {
                System.err.println("Unknown shell: " + shell);
                return 1;
            }
        }
        return 0;
    }

    static void copyDefaultConf(Path dest) throws IOException {
        Path src = Paths.get("resources/default-conf");
        if (!Files.exists(src)) {
            Files.createDirectories(dest);
            Files.writeString(dest.resolve("conf.hjson"), "# default broot configuration\n");
            Files.writeString(dest.resolve("verbs.hjson"), "# default broot verbs\n");
        } else {
            try (Stream<Path> walk = Files.walk(src)) {
                for (Path p : walk.toList()) {
                    Path rel = src.relativize(p);
                    Path target = dest.resolve(rel.toString());
                    if (Files.isDirectory(p)) Files.createDirectories(target);
                    else {
                        Files.createDirectories(target.getParent());
                        Files.copy(p, target, StandardCopyOption.REPLACE_EXISTING);
                    }
                }
            }
        }
        System.out.println("New Configuration files written in \"" + dest + "\".");
        System.out.println("You should have a look at them: their comments will help you configure broot.");
        System.out.println("You should especially set up your favourite editor in verbs.hjson.");
    }

    static void printInstallNote() {
        System.out.println("The br function has been successfully installed.");
    }

    static String shellQuote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    static class ArgError extends RuntimeException {
        ArgError(String m) { super(m); }
    }
}
