import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.*;

@SuppressWarnings({"unchecked","rawtypes"})
public class MiniLua {
  static final Object NIL = new Object(){ public String toString(){return "nil";}};
  static class Ret extends RuntimeException { final List<Object> v; Ret(List<Object> v){this.v=v;} }
  static class Brk extends RuntimeException {}
  interface Fn { List<Object> call(List<Object> a); }
  static class LuaFn implements Fn {
    final List<String> params; final boolean vararg; final List<Stmt> body; final Env env;
    LuaFn(List<String> p, boolean va, List<Stmt> b, Env e){params=p;vararg=va;body=b;env=e;}
    public List<Object> call(List<Object> a){
      Env n=new Env(env);
      for(int i=0;i<params.size();i++) n.define(params.get(i), i<a.size()?a.get(i):NIL);
      List<Object> va=new ArrayList<>(); for(int i=params.size();i<a.size();i++) va.add(a.get(i));
      n.define("...", va);
      try { for(Stmt s:body) s.exec(n); } catch(Ret r){ return r.v; }
      return list();
    }
  }
  static class Env {
    final Env parent; final Map<String,Object> m=new HashMap<>();
    Env(Env p){parent=p;}
    Object get(String k){ if(m.containsKey(k)) return m.get(k); return parent==null?NIL:parent.get(k); }
    void define(String k,Object v){ m.put(k,v==null?NIL:v); }
    void set(String k,Object v){ if(m.containsKey(k)||parent==null)m.put(k,v==null?NIL:v); else parent.set(k,v); }
  }
  static class Table {
    final LinkedHashMap<Object,Object> m=new LinkedHashMap<>();
    int auto=1;
    Object get(Object k){ Object v=m.get(key(k)); return v==null?NIL:v; }
    void set(Object k,Object v){ k=key(k); if(v==NIL)m.remove(k); else m.put(k,v); }
    void add(Object v){ set((double)auto++, v); }
    int len(){ int n=0; while(true){ Object v=m.get((double)(n+1)); if(v==null) return n; n++; } }
    public String toString(){ return "table: 0x"+Integer.toHexString(System.identityHashCode(this));}
  }
  static Object key(Object k){ if(k instanceof Double){ double d=(Double)k; if(d==(long)d) return (double)(long)d; } return k; }
  interface Expr { List<Object> eval(Env e); }
  interface Stmt { void exec(Env e); }
  static List<Object> list(Object...v){ return new ArrayList<>(Arrays.asList(v)); }
  static Object first(List<Object> v){ return v.isEmpty()?NIL:v.get(0); }
  static boolean truth(Object v){ return v!=NIL && !(v instanceof Boolean && !((Boolean)v)); }
  static double num(Object v){ if(v instanceof Number) return ((Number)v).doubleValue(); if(v instanceof String) try{return Double.parseDouble((String)v);}catch(Exception e){} throw err("attempt to perform arithmetic on a "+type(v)+" value"); }
  static String str(Object v){ if(v==NIL) return "nil"; if(v instanceof Boolean) return v.toString(); if(v instanceof Double){ double d=(Double)v; if(d==(long)d) return Long.toString((long)d); return Double.toString(d); } return v.toString(); }
  static RuntimeException err(String s){ return new RuntimeException(s); }
  static String type(Object v){ if(v==NIL)return"nil"; if(v instanceof String)return"string"; if(v instanceof Double)return"number"; if(v instanceof Boolean)return"boolean"; if(v instanceof Table)return"table"; if(v instanceof Fn)return"function"; return"userdata"; }

  enum TT{ID,NUM,STR,SYM,EOF}
  static class Tok{TT t;String s;Tok(TT t,String s){this.t=t;this.s=s;}}
  static class Lex{
    String x; int p; Tok hold;
    Lex(String x){this.x=x;}
    Tok peek(){ if(hold==null) hold=next0(); return hold; }
    Tok next(){ Tok r=peek(); hold=null; return r; }
    boolean eat(String s){ Tok t=peek(); if((t.t==TT.STR||t.t==TT.NUM)&&!s.equals(t.s)) return false; if((t.t==TT.STR||t.t==TT.NUM)) return false; if(t.s.equals(s)){next();return true;} return false; }
    Tok next0(){
      while(p<x.length()){
        char c=x.charAt(p);
        if(Character.isWhitespace(c)){p++;continue;}
        if(c=='-'&&p+1<x.length()&&x.charAt(p+1)=='-'){ p+=2; if(p<x.length()&&x.charAt(p)=='['&&p+1<x.length()&&x.charAt(p+1)=='['){p+=2; int q=x.indexOf("]]",p); p=q<0?x.length():q+2;} else while(p<x.length()&&x.charAt(p)!='\n')p++; continue; }
        break;
      }
      if(p>=x.length()) return new Tok(TT.EOF,"<eof>");
      char c=x.charAt(p);
      if(Character.isLetter(c)||c=='_'){ int q=p++; while(p<x.length()&&(Character.isLetterOrDigit(x.charAt(p))||x.charAt(p)=='_'))p++; return new Tok(TT.ID,x.substring(q,p));}
      if(Character.isDigit(c)||(c=='.'&&p+1<x.length()&&Character.isDigit(x.charAt(p+1)))){ int q=p++; while(p<x.length()){ char n=x.charAt(p); if(Character.isDigit(n)||n=='.'||(n>='a'&&n<='f')||(n>='A'&&n<='F')||n=='x'||n=='X'){p++; continue;} if((n=='+'||n=='-')&&p>q&&(x.charAt(p-1)=='e'||x.charAt(p-1)=='E')){p++; continue;} break;} return new Tok(TT.NUM,x.substring(q,p));}
      if(c=='\''||c=='"'){ char quote=c; p++; StringBuilder b=new StringBuilder(); while(p<x.length()&&x.charAt(p)!=quote){ c=x.charAt(p++); if(c=='\\'&&p<x.length()){ char n=x.charAt(p++); switch(n){case'n':b.append('\n');break;case't':b.append('\t');break;case'r':b.append('\r');break;case'\\':b.append('\\');break;case'"':b.append('"');break;case'\'':b.append('\'');break;default:b.append(n);} } else b.append(c);} if(p<x.length())p++; return new Tok(TT.STR,b.toString());}
      if(c=='['&&p+1<x.length()&&x.charAt(p+1)=='['){p+=2; int q=x.indexOf("]]",p); String s=q<0?x.substring(p):x.substring(p,q); p=q<0?x.length():q+2; return new Tok(TT.STR,s);}
      String[] ops={"...","==","~=","<=",">=",".."}; for(String o:ops) if(x.startsWith(o,p)){p+=o.length();return new Tok(TT.SYM,o);}
      p++; return new Tok(TT.SYM,Character.toString(c));
    }
  }
  static class Parser{
    Lex l; Parser(String s){l=new Lex(s);}
    List<Stmt> block(String...ends){ List<String> es=Arrays.asList(ends); List<Stmt>b=new ArrayList<>(); while(l.peek().t!=TT.EOF&&!es.contains(l.peek().s)){ if(l.eat(";"))continue; b.add(stmt()); } return b; }
    Stmt stmt(){
      Tok t=l.peek();
      if(l.eat("local")){ if(l.eat("function")){String n=id(); LuaFnExpr fe=funcBody(); return e->e.define(n, first(fe.eval(e)));} List<String> ns=names(); List<Expr> vs=new ArrayList<>(); if(l.eat("="))vs=explist(); final List<Expr> fvs=vs; return e->{List<Object> vals=evalList(fvs,e); for(int i=0;i<ns.size();i++)e.define(ns.get(i), i<vals.size()?vals.get(i):NIL);};}
      if(l.eat("function")){ Expr v=new Var(id()); while(l.eat(".")){String n=id(); v=new Index(v, env->list(n));} LuaFnExpr fe=funcBody(); Expr fv=v; return e->assign(fv,e,first(fe.eval(e))); }
      if(l.eat("return")){ List<Expr> ex=new ArrayList<>(); if(!isEnd(l.peek().s)) ex=explist(); List<Expr> fx=ex; return e->{throw new Ret(evalList(fx,e));};}
      if(l.eat("break")) return e->{throw new Brk();};
      if(l.eat("do")){ List<Stmt>b=block("end"); need("end"); return e->{Env n=new Env(e); for(Stmt s:b)s.exec(n);};}
      if(l.eat("while")){ Expr c=expr(); need("do"); List<Stmt>b=block("end"); need("end"); return e->{while(truth(first(c.eval(e))))try{for(Stmt s:b)s.exec(e);}catch(Brk br){break;}};}
      if(l.eat("repeat")){ List<Stmt>b=block("until"); need("until"); Expr c=expr(); return e->{do{try{for(Stmt s:b)s.exec(e);}catch(Brk br){break;}}while(!truth(first(c.eval(e))));};}
      if(l.eat("if")){ Expr c=expr(); need("then"); List<Stmt> tb=block("elseif","else","end"); List<Expr> cs=new ArrayList<>(); List<List<Stmt>> bs=new ArrayList<>(); cs.add(c); bs.add(tb); while(l.eat("elseif")){cs.add(expr()); need("then"); bs.add(block("elseif","else","end"));} List<Stmt> eb=null; if(l.eat("else")) eb=block("end"); need("end"); List<Stmt> feb=eb; return e->{for(int i=0;i<cs.size();i++) if(truth(first(cs.get(i).eval(e)))){for(Stmt s:bs.get(i))s.exec(e);return;} if(feb!=null)for(Stmt s:feb)s.exec(e);};}
      if(l.eat("for")){ String n=id(); if(l.eat("=")){ Expr a=expr(); need(","); Expr b=expr(); Expr step=l.eat(",")?expr():e->list(1.0); need("do"); List<Stmt> body=block("end"); need("end"); return e->{double st=num(first(step.eval(e))); for(double i=num(first(a.eval(e))); st>=0?i<=num(first(b.eval(e))):i>=num(first(b.eval(e))); i+=st){Env ne=new Env(e); ne.define(n,i); try{for(Stmt s:body)s.exec(ne);}catch(Brk br){break;}}};} else {List<String> ns=new ArrayList<>(); ns.add(n); while(l.eat(","))ns.add(id()); need("in"); List<Expr> it=explist(); need("do"); List<Stmt> body=block("end"); need("end"); return e->{Object src=first(it.get(0).eval(e)); Iterable<List<Object>> iter=iter(src); for(List<Object> vals:iter){Env ne=new Env(e); for(int i=0;i<ns.size();i++)ne.define(ns.get(i),i<vals.size()?vals.get(i):NIL); try{for(Stmt s:body)s.exec(ne);}catch(Brk br){break;}}};}}
      Expr v=prefix(); if(l.peek().s.equals("=")||l.peek().s.equals(",")){ List<Expr> vars=new ArrayList<>(); vars.add(v); while(l.eat(",")) vars.add(var()); need("="); List<Expr> vals=explist(); return e->{List<Object> vv=evalList(vals,e); for(int i=0;i<vars.size();i++) assign(vars.get(i),e,i<vv.size()?vv.get(i):NIL);};}
      return e->v.eval(e);
    }
    boolean isEnd(String s){return s.equals("end")||s.equals("else")||s.equals("elseif")||s.equals("until")||s.equals("<eof>");}
    List<String> names(){ List<String> r=new ArrayList<>(); r.add(id()); while(l.eat(","))r.add(id()); return r; }
    String id(){ Tok t=l.next(); if(t.t!=TT.ID) throw err("expected identifier near '"+t.s+"'"); return t.s; }
    void need(String s){ if(!l.eat(s)) throw err("'"+s+"' expected near '"+l.peek().s+"'"); }
    Expr var(){ return prefix(); }
    LuaFnExpr funcBody(){ need("("); List<String> ps=new ArrayList<>(); boolean va=false; if(!l.eat(")")){ if(l.eat("..."))va=true; else {ps.add(id()); while(l.eat(",")){ if(l.eat("...")){va=true;break;} ps.add(id()); }} need(")"); } List<Stmt>b=block("end"); need("end"); return new LuaFnExpr(ps,va,b); }
    List<Expr> explist(){ List<Expr> r=new ArrayList<>(); r.add(expr()); while(l.eat(","))r.add(expr()); return r; }
    List<Object> evalList(List<Expr> es,Env e){ List<Object> r=new ArrayList<>(); for(int i=0;i<es.size();i++){ List<Object> v=es.get(i).eval(e); if(i==es.size()-1)r.addAll(v); else r.add(first(v)); } return r; }
    Expr expr(){ return bin(0); }
    int prec(String o){ switch(o){case"or":return 1;case"and":return 2;case"==":case"~=":case"<":case">":case"<=":case">=":return 3;case"..":return 4;case"+":case"-":return 5;case"*":case"/":case"%":return 6;case"^":return 8;} return -1;}
    Expr bin(int min){ Expr a=unary(); while(true){String o=l.peek().s; int p=prec(o); if(p<min)break; l.next(); Expr b=bin((o.equals("^")||o.equals(".."))?p:p+1); a=new Bin(a,o,b);} return a; }
    Expr unary(){ if(l.eat("not"))return new Un("not",unary()); if(l.eat("-"))return new Un("-",unary()); if(l.eat("#"))return new Un("#",unary()); return prefix(); }
    Expr prefix(){ Expr e=primary(); while(true){ if(l.eat(".")){String n=id(); e=new Index(e, env->list(n));} else if(l.eat("[")){Expr k=expr(); need("]"); e=new Index(e,k);} else if(l.eat(":")){String n=id(); e=call(e,n);} else if(l.peek().s.equals("(")||l.peek().t==TT.STR||l.peek().s.equals("{")) e=call(e,null); else break;} return e; }
    Expr call(Expr f,String method){ List<Expr>a=new ArrayList<>(); if(l.eat("(")){ if(!l.eat(")")){a=explist(); need(")");}} else if(l.peek().t==TT.STR){String s=l.next().s; a.add(e->list(s));} else a.add(table()); return new Call(f,method,a); }
    Expr primary(){ Tok t=l.next(); if(t.t==TT.NUM){double d=t.s.startsWith("0x")||t.s.startsWith("0X")?Long.parseLong(t.s.substring(2),16):Double.parseDouble(t.s); return e->list(d);} if(t.t==TT.STR)return e->list(t.s); if(t.s.equals("nil"))return e->list(NIL); if(t.s.equals("true"))return e->list(true); if(t.s.equals("false"))return e->list(false); if(t.s.equals("..."))return e->{Object v=e.get("..."); return v instanceof List?(List<Object>)v:list(NIL);}; if(t.s.equals("function"))return funcBody(); if(t.s.equals("{")){l.hold=t; return table();} if(t.s.equals("(")){Expr e=expr(); need(")"); return e;} if(t.t==TT.ID)return new Var(t.s); throw err("unexpected symbol near '"+t.s+"'");}
    Expr table(){ need("{"); List<Object[]> fs=new ArrayList<>(); if(!l.eat("}")){ do{ if(l.eat("[")){Expr k=expr(); need("]"); need("="); Expr v=expr(); fs.add(new Object[]{k,v}); } else if(l.peek().t==TT.ID){ Tok id=l.next(); if(l.eat("=")){Expr v=expr(); fs.add(new Object[]{(Expr)(e->list(id.s)),v});} else { l.hold=id; fs.add(new Object[]{null,expr()}); }} else fs.add(new Object[]{null,expr()}); }while(l.eat(",")||l.eat(";")); need("}"); } return e->{Table t=new Table(); for(Object[] f:fs){Object v=first(((Expr)f[1]).eval(e)); if(f[0]==null)t.add(v); else t.set(first(((Expr)f[0]).eval(e)),v);} return list(t);};}
  }
  static class Var implements Expr{String n;Var(String n){this.n=n;}public List<Object> eval(Env e){return list(e.get(n));}}
  static class Index implements Expr{Expr t,k;Index(Expr t,Expr k){this.t=t;this.k=k;}public List<Object> eval(Env e){Object o=first(t.eval(e)); if(o instanceof Table)return list(((Table)o).get(first(k.eval(e)))); if(o instanceof String && first(k.eval(e)).equals("len"))return list((double)((String)o).length()); return list(NIL);}}
  static class Call implements Expr{Expr f;String m;List<Expr>a;Call(Expr f,String m,List<Expr>a){this.f=f;this.m=m;this.a=a;}public List<Object> eval(Env e){Object fn; List<Object> args=new ArrayList<>(); if(m!=null){Object self=first(f.eval(e)); args.add(self); if(self instanceof Table)fn=((Table)self).get(m); else if(self instanceof String){Object st=e.get("string"); fn=st instanceof Table?((Table)st).get(m):NIL;} else fn=NIL;} else fn=first(f.eval(e)); for(int i=0;i<a.size();i++){List<Object> v=a.get(i).eval(e); if(i==a.size()-1)args.addAll(v); else args.add(first(v));} if(fn instanceof Fn)return ((Fn)fn).call(args); throw err("attempt to call a "+type(fn)+" value");}}
  static class LuaFnExpr implements Expr{List<String>p;boolean va;List<Stmt>b;LuaFnExpr(List<String>p,boolean va,List<Stmt>b){this.p=p;this.va=va;this.b=b;}public List<Object> eval(Env e){return list(new LuaFn(p,va,b,e));}}
  static class Un implements Expr{String o;Expr x;Un(String o,Expr x){this.o=o;this.x=x;}public List<Object> eval(Env e){Object v=first(x.eval(e)); switch(o){case"not":return list(!truth(v));case"-":return list(-num(v));case"#":return list(v instanceof String?(double)((String)v).length():v instanceof Table?(double)((Table)v).len():0.0);}return list(NIL);}}
  static class Bin implements Expr{Expr a,b;String o;Bin(Expr a,String o,Expr b){this.a=a;this.o=o;this.b=b;}public List<Object> eval(Env e){Object x=first(a.eval(e)); if(o.equals("and"))return truth(x)?b.eval(e):list(x); if(o.equals("or"))return truth(x)?list(x):b.eval(e); Object y=first(b.eval(e)); switch(o){case"+":return list(num(x)+num(y));case"-":return list(num(x)-num(y));case"*":return list(num(x)*num(y));case"/":return list(num(x)/num(y));case"%":return list(num(x)%num(y));case"^":return list(Math.pow(num(x),num(y)));case"..":return list(str(x)+str(y));case"==":return list(eq(x,y));case"~=":return list(!eq(x,y));case"<":return list(cmp(x,y)<0);case">":return list(cmp(x,y)>0);case"<=":return list(cmp(x,y)<=0);case">=":return list(cmp(x,y)>=0);}return list(NIL);}}
  static boolean eq(Object a,Object b){ if(a==NIL&&b==NIL)return true; if(a instanceof Double&&b instanceof Double)return ((Double)a).doubleValue()==((Double)b).doubleValue(); return Objects.equals(a,b);}
  static int cmp(Object a,Object b){ if(a instanceof Number||b instanceof Number)return Double.compare(num(a),num(b)); return str(a).compareTo(str(b));}
  static void assign(Expr v,Env e,Object val){ if(v instanceof Var)e.set(((Var)v).n,val); else if(v instanceof Index){Index i=(Index)v; Object t=first(i.t.eval(e)); if(t instanceof Table)((Table)t).set(first(i.k.eval(e)),val); else throw err("attempt to index a "+type(t)+" value");} else throw err("syntax error");}
  static Iterable<List<Object>> iter(Object src){ List<List<Object>> out=new ArrayList<>(); if(src instanceof Table){ for(Map.Entry<Object,Object> en:((Table)src).m.entrySet()) out.add(list(en.getKey(),en.getValue())); } return out; }

  static Env base(String[] args){
    Env e=new Env(null);
    e.define("_VERSION","Lua 5.1");
    Table arg=new Table(); for(int i=0;i<args.length;i++)arg.set((double)i,args[i]); e.define("arg",arg);
    e.define("print",(Fn)a->{ for(int i=0;i<a.size();i++){ if(i>0)System.out.print("\t"); System.out.print(str(a.get(i))); } System.out.println(); return list();});
    e.define("type",(Fn)a->list(type(a.isEmpty()?NIL:a.get(0))));
    e.define("tostring",(Fn)a->list(str(a.isEmpty()?NIL:a.get(0))));
    e.define("tonumber",(Fn)a->{ if(a.isEmpty())return list(NIL); try{return list(Double.parseDouble(str(a.get(0))));}catch(Exception ex){return list(NIL);}});
    e.define("assert",(Fn)a->{ if(a.isEmpty()||!truth(a.get(0))) throw err(a.size()>1?str(a.get(1)):"assertion failed!"); return a;});
    e.define("error",(Fn)a->{ throw err(a.isEmpty()?"":str(a.get(0)));});
    e.define("pairs",(Fn)a->list(a.isEmpty()?NIL:a.get(0)));
    e.define("ipairs",(Fn)a->list(a.isEmpty()?NIL:a.get(0)));
    e.define("next",(Fn)a->{ if(a.isEmpty()||!(a.get(0) instanceof Table))return list(NIL); Table t=(Table)a.get(0); Object prev=a.size()>1?a.get(1):NIL; boolean take=prev==NIL; for(Map.Entry<Object,Object> en:t.m.entrySet()){ if(take)return list(en.getKey(),en.getValue()); if(eq(en.getKey(),prev))take=true;} return list(NIL);});
    e.define("unpack",(Fn)a->{ if(a.isEmpty()||!(a.get(0) instanceof Table))return list(); Table t=(Table)a.get(0); int i=a.size()>1?(int)num(a.get(1)):1, j=a.size()>2?(int)num(a.get(2)):t.len(); List<Object> r=new ArrayList<>(); for(;i<=j;i++)r.add(t.get((double)i)); return r;});
    e.define("select",(Fn)a->{ if(a.isEmpty())return list(); if(str(a.get(0)).equals("#"))return list((double)Math.max(0,a.size()-1)); int n=(int)num(a.get(0)); List<Object> r=new ArrayList<>(); for(int i=Math.max(1,n);i<a.size();i++)r.add(a.get(i)); return r;});
    e.define("pcall",(Fn)a->{ if(a.isEmpty()||!(a.get(0) instanceof Fn))return list(false,"attempt to call a "+type(a.isEmpty()?NIL:a.get(0))+" value"); try{return prepend(true,((Fn)a.get(0)).call(a.subList(1,a.size())));}catch(Exception ex){return list(false,ex.getMessage());}});
    e.define("rawequal",(Fn)a->list(a.size()>1&&eq(a.get(0),a.get(1))));
    e.define("rawget",(Fn)a->list(a.get(0) instanceof Table?((Table)a.get(0)).get(a.get(1)):NIL));
    e.define("rawset",(Fn)a->{ if(a.get(0) instanceof Table)((Table)a.get(0)).set(a.get(1),a.size()>2?a.get(2):NIL); return list(a.get(0));});
    e.define("getmetatable",(Fn)a->list(NIL)); e.define("setmetatable",(Fn)a->list(a.isEmpty()?NIL:a.get(0)));
    e.define("loadstring",(Fn)a->{String code=a.isEmpty()?"":str(a.get(0)); return list((Fn)aa->{run(code,e); return list();});});
    e.define("dofile",(Fn)a->{try{run(Files.readString(Path.of(str(a.get(0)))),e);return list();}catch(IOException ex){throw err(ex.getMessage());}});
    e.define("require",(Fn)a->list(true));
    Table jit=new Table(); jit.set("version","LuaJIT 2.1.1772570160"); jit.set("version_num",2.011772570160E11); e.define("jit",jit);
    Table math=new Table(); math.set("pi",Math.PI); math.set("abs",(Fn)a->list(Math.abs(num(a.get(0))))); math.set("floor",(Fn)a->list(Math.floor(num(a.get(0))))); math.set("ceil",(Fn)a->list(Math.ceil(num(a.get(0))))); math.set("sqrt",(Fn)a->list(Math.sqrt(num(a.get(0))))); math.set("sin",(Fn)a->list(Math.sin(num(a.get(0))))); math.set("cos",(Fn)a->list(Math.cos(num(a.get(0))))); math.set("max",(Fn)a->{double m=-Double.MAX_VALUE; for(Object v:a)m=Math.max(m,num(v)); return list(m);}); math.set("min",(Fn)a->{double m=Double.MAX_VALUE; for(Object v:a)m=Math.min(m,num(v)); return list(m);}); e.define("math",math);
    Table string=new Table(); string.set("len",(Fn)a->list((double)str(a.get(0)).length())); string.set("sub",(Fn)a->{String s=str(a.get(0)); int st=(int)num(a.get(1)); int en=a.size()>2?(int)num(a.get(2)):s.length(); if(st<0)st=s.length()+st+1; if(en<0)en=s.length()+en+1; st=Math.max(1,st); en=Math.min(s.length(),en); return list(st>en?"":s.substring(st-1,en));}); string.set("upper",(Fn)a->list(str(a.get(0)).toUpperCase())); string.set("lower",(Fn)a->list(str(a.get(0)).toLowerCase())); string.set("rep",(Fn)a->{StringBuilder sb=new StringBuilder(); for(int i=0;i<(int)num(a.get(1));i++)sb.append(str(a.get(0))); return list(sb.toString());}); string.set("reverse",(Fn)a->list(new StringBuilder(str(a.get(0))).reverse().toString())); string.set("find",(Fn)a->{String s=str(a.get(0)), pat=str(a.get(1)); int idx=s.indexOf(pat); return idx<0?list(NIL):list((double)idx+1,(double)(idx+pat.length()));}); string.set("match",(Fn)a->{String s=str(a.get(0)), pat=str(a.get(1)); int idx=s.indexOf(pat); return idx<0?list(NIL):list(pat);}); string.set("format",(Fn)a->{Object[] ar=new Object[Math.max(0,a.size()-1)]; for(int i=1;i<a.size();i++)ar[i-1]=a.get(i) instanceof Double&&((Double)a.get(i))%1==0?((Double)a.get(i)).longValue():a.get(i); return list(String.format(str(a.get(0)),ar));}); e.define("string",string);
    Table table=new Table(); table.set("insert",(Fn)a->{Table t=(Table)a.get(0); if(a.size()==2)t.add(a.get(1)); else t.set(a.get(1),a.get(2)); return list();}); table.set("concat",(Fn)a->{Table t=(Table)a.get(0); String sep=a.size()>1?str(a.get(1)):""; StringBuilder sb=new StringBuilder(); for(int i=1;i<=t.len();i++){ if(i>1)sb.append(sep); sb.append(str(t.get((double)i)));} return list(sb.toString());}); e.define("table",table);
    Table io=new Table(); io.set("write",(Fn)a->{for(Object v:a)System.out.print(str(v)); return list(true);}); io.set("read",(Fn)a->{try{BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); return list(br.readLine());}catch(IOException ex){return list(NIL);}}); e.define("io",io);
    Table os=new Table(); os.set("clock",(Fn)a->list(System.nanoTime()/1.0e9)); os.set("time",(Fn)a->list((double)(System.currentTimeMillis()/1000))); os.set("exit",(Fn)a->{System.exit(a.isEmpty()?0:(int)num(a.get(0))); return list();}); e.define("os",os);
    return e;
  }
  static List<Object> prepend(Object x,List<Object> xs){List<Object> r=new ArrayList<>(); r.add(x); r.addAll(xs); return r;}
  static void run(String code, Env e){ new Parser(code).block().forEach(s->s.exec(e)); }
  static void help(){ System.out.print("usage: ./executable [options]... [script [args]...].\nAvailable options are:\n  -e chunk  Execute string 'chunk'.\n  -l name   Require library 'name'.\n  -b ...    Save or list bytecode.\n  -j cmd    Perform LuaJIT control command.\n  -O[opt]   Control LuaJIT optimizations.\n  -i        Enter interactive mode after executing 'script'.\n  -v        Show version information.\n  -E        Ignore environment variables.\n  --        Stop handling options.\n  -         Execute stdin and stop handling options.\n"); }
  public static void main(String[] av) throws Exception{
    List<String> chunks=new ArrayList<>(); String script=null; List<String> sargs=new ArrayList<>(); boolean ver=false;
    for(int i=0;i<av.length;i++){String a=av[i]; if(a.equals("--help")){help();return;} if(a.equals("-v")){ver=true;continue;} if(a.equals("-e")){chunks.add(av[++i]);continue;} if(a.startsWith("-e")&&a.length()>2){chunks.add(a.substring(2));continue;} if(a.equals("-l")){i++;continue;} if(a.startsWith("-l")&&a.length()>2)continue; if(a.equals("-E")||a.startsWith("-O")||a.startsWith("-j"))continue; if(a.equals("-b")){System.err.println("./executable: unknown luaJIT command or jit.* modules not installed");return;} if(a.equals("--")){ if(++i<av.length){script=av[i]; for(i++;i<av.length;i++)sargs.add(av[i]);} break;} if(a.equals("-")){script="-"; for(i++;i<av.length;i++)sargs.add(av[i]); break;} if(a.startsWith("-")){System.err.println("./executable: unknown option '"+a+"'"); return;} script=a; for(i++;i<av.length;i++)sargs.add(av[i]); break; }
    if(ver) System.out.println("LuaJIT 2.1.1772570160 -- Copyright (C) 2005-2026 Mike Pall. https://luajit.org/");
    Env e=base(sargs.toArray(new String[0]));
    try{ for(String c:chunks)run(c,e); if(script!=null){String code=script.equals("-")?new String(System.in.readAllBytes()):Files.readString(Path.of(script)); run(code,e);} else if(chunks.isEmpty()&&!ver){help();} }
    catch(Exception ex){ System.err.println("./executable: "+ex.getMessage()); System.exit(1); }
  }
}
