package ethabi;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class Main {
    static final String VERSION = "18.0.0";

    public static void main(String[] args) {
        try {
            int rc = new Main().run(args);
            if (rc != 0) System.exit(rc);
        } catch (Exception e) {
            System.err.println("Error: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
            System.exit(1);
        }
    }

    int run(String[] args) throws Exception {
        if (args.length == 0 || isHelp(args[0])) {
            helpRoot();
            return 0;
        }
        if ("--version".equals(args[0]) || "-V".equals(args[0])) {
            System.out.println("ethabi-cli " + VERSION);
            return 0;
        }
        if ("help".equals(args[0])) {
            return run(Arrays.copyOfRange(args, 1, args.length));
        }
        if ("encode".equals(args[0])) return encode(Arrays.copyOfRange(args, 1, args.length));
        if ("decode".equals(args[0])) return decode(Arrays.copyOfRange(args, 1, args.length));
        throw new IllegalArgumentException("Unknown command");
    }

    int encode(String[] args) throws Exception {
        if (args.length == 0 || isHelp(args[0])) { helpEncode(); return 0; }
        if ("function".equals(args[0])) return encodeFunction(Arrays.copyOfRange(args, 1, args.length));
        if ("params".equals(args[0])) return encodeParams(Arrays.copyOfRange(args, 1, args.length));
        if ("help".equals(args[0])) return encode(Arrays.copyOfRange(args, 1, args.length));
        throw new IllegalArgumentException("Unknown encode command");
    }

    int decode(String[] args) throws Exception {
        if (args.length == 0 || isHelp(args[0])) { helpDecode(); return 0; }
        if ("function".equals(args[0])) return decodeFunction(Arrays.copyOfRange(args, 1, args.length));
        if ("params".equals(args[0])) return decodeParams(Arrays.copyOfRange(args, 1, args.length));
        if ("log".equals(args[0])) return decodeLog(Arrays.copyOfRange(args, 1, args.length));
        if ("help".equals(args[0])) return decode(Arrays.copyOfRange(args, 1, args.length));
        throw new IllegalArgumentException("Unknown decode command");
    }

    int encodeParams(String[] args) {
        boolean lenient = false;
        List<AbiType> types = new ArrayList<>();
        List<String> vals = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            if ("-l".equals(args[i]) || "--lenient".equals(args[i])) lenient = true;
            else if (isHelp(args[i])) { helpEncodeParams(); return 0; }
            else if ("-v".equals(args[i])) {
                if (i + 2 >= args.length) throw new IllegalArgumentException("Invalid params");
                types.add(AbiType.parse(args[++i]));
                vals.add(args[++i]);
            } else throw new IllegalArgumentException("Invalid argument " + args[i]);
        }
        List<Object> values = new ArrayList<>();
        for (int i = 0; i < types.size(); i++) values.add(parseValue(types.get(i), vals.get(i), lenient));
        System.out.println(hex(Abi.encode(types, values)));
        return 0;
    }

    int decodeParams(String[] args) {
        List<AbiType> types = new ArrayList<>();
        String data = null;
        for (int i = 0; i < args.length; i++) {
            if (isHelp(args[i])) { helpDecodeParams(); return 0; }
            else if ("-t".equals(args[i])) {
                if (++i >= args.length) throw new IllegalArgumentException("Invalid type");
                types.add(AbiType.parse(args[i]));
            } else data = args[i];
        }
        if (data == null) throw new IllegalArgumentException("Missing data");
        byte[] bytes = parseHex(data);
        List<Object> vals = Abi.decode(types, bytes, 0);
        for (int i = 0; i < types.size(); i++) {
            System.out.println(types.get(i).canonical() + " " + format(types.get(i), vals.get(i)));
        }
        return 0;
    }

    int encodeFunction(String[] args) throws Exception {
        boolean lenient = false;
        List<String> params = new ArrayList<>();
        List<String> pos = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            if ("-l".equals(args[i]) || "--lenient".equals(args[i])) lenient = true;
            else if (isHelp(args[i])) { helpEncodeFunction(); return 0; }
            else if ("-p".equals(args[i])) {
                if (++i >= args.length) throw new IllegalArgumentException("Invalid params");
                params.add(args[i]);
            } else pos.add(args[i]);
        }
        if (pos.size() < 2) throw new IllegalArgumentException("Missing arguments");
        AbiItem fn = findItem(loadAbi(pos.get(0)), "function", pos.get(1));
        if (fn == null) throw new IllegalArgumentException("Function not found");
        if (params.size() != fn.inputs.size()) throw new IllegalArgumentException("Invalid data");
        List<Object> vals = new ArrayList<>();
        for (int i = 0; i < fn.inputs.size(); i++) vals.add(parseValue(fn.inputs.get(i).type, params.get(i), lenient));
        byte[] selector = Arrays.copyOf(Keccak.keccak256(fn.signature().getBytes(StandardCharsets.UTF_8)), 4);
        System.out.println(hex(concat(selector, Abi.encode(types(fn.inputs), vals))));
        return 0;
    }

    int decodeFunction(String[] args) throws Exception {
        if (args.length > 0 && isHelp(args[0])) { helpDecodeFunction(); return 0; }
        if (args.length < 3) throw new IllegalArgumentException("Missing arguments");
        AbiItem fn = findItem(loadAbi(args[0]), "function", args[1]);
        if (fn == null) throw new IllegalArgumentException("Function not found");
        byte[] data = parseHex(args[2]);
        List<Param> outs = fn.outputs;
        List<Object> vals = Abi.decode(types(outs), data, 0);
        for (int i = 0; i < outs.size(); i++) {
            String name = outs.get(i).name == null || outs.get(i).name.isEmpty() ? outs.get(i).type.canonical() : outs.get(i).name;
            System.out.println(name + " " + format(outs.get(i).type, vals.get(i)));
        }
        return 0;
    }

    int decodeLog(String[] args) throws Exception {
        List<String> topics = new ArrayList<>();
        List<String> pos = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            if (isHelp(args[i])) { helpDecodeLog(); return 0; }
            else if ("-l".equals(args[i])) {
                if (++i >= args.length) throw new IllegalArgumentException("Invalid topic");
                topics.add(args[i]);
            } else pos.add(args[i]);
        }
        if (pos.size() < 3) throw new IllegalArgumentException("Missing arguments");
        AbiItem ev = findItem(loadAbi(pos.get(0)), "event", pos.get(1));
        if (ev == null) throw new IllegalArgumentException("Event not found");
        int topicIndex = 0;
        if (!ev.anonymous) topicIndex = 1;
        List<Param> dataParams = new ArrayList<>();
        for (Param p : ev.inputs) if (!p.indexed) dataParams.add(p);
        List<Object> dataVals = Abi.decode(types(dataParams), parseHex(pos.get(2)), 0);
        int dataIndex = 0;
        for (Param p : ev.inputs) {
            Object v;
            if (p.indexed) {
                if (topicIndex >= topics.size()) throw new IllegalArgumentException("Invalid data");
                byte[] tb = parseHex(topics.get(topicIndex++));
                v = p.type.isDynamic() ? tb : Abi.decodeOne(p.type, tb, 0, 0);
            } else {
                v = dataVals.get(dataIndex++);
            }
            System.out.println((p.name == null || p.name.isEmpty() ? p.type.canonical() : p.name) + " " + format(p.type, v));
        }
        return 0;
    }

    static boolean isHelp(String s) { return "-h".equals(s) || "--help".equals(s); }

    static List<AbiType> types(List<Param> ps) {
        List<AbiType> out = new ArrayList<>();
        for (Param p : ps) out.add(p.type);
        return out;
    }

    static Object parseValue(AbiType type, String s, boolean lenient) {
        if (type.array) {
            String inner = s.trim();
            if (!inner.startsWith("[") || !inner.endsWith("]")) throw new IllegalArgumentException("Invalid data");
            inner = inner.substring(1, inner.length() - 1).trim();
            List<Object> vals = new ArrayList<>();
            if (!inner.isEmpty()) {
                for (String part : splitTop(inner)) vals.add(parseValue(type.elem, stripQuotes(part.trim()), lenient));
            }
            if (type.arrayLen >= 0 && vals.size() != type.arrayLen) throw new IllegalArgumentException("Invalid data");
            return vals;
        }
        String base = type.base;
        if ("bool".equals(base)) return s.equals("true") || s.equals("1");
        if (base.startsWith("uint") || base.startsWith("int")) return parseInteger(s, lenient);
        if ("address".equals(base)) {
            byte[] b = parseHex(strip0x(s));
            if (b.length != 20) throw new IllegalArgumentException("Invalid data");
            return b;
        }
        if ("string".equals(base)) return s;
        if ("bytes".equals(base)) return parseHex(strip0x(s));
        if (base.startsWith("bytes")) {
            int n = Integer.parseInt(base.substring(5));
            byte[] b = parseHex(strip0x(s));
            if (lenient && b.length <= n) return b;
            if (b.length != n) throw new IllegalArgumentException("Invalid data");
            return b;
        }
        throw new IllegalArgumentException("Unsupported type " + base);
    }

    static BigInteger parseInteger(String s, boolean lenient) {
        String x = strip0x(s);
        if (x.isEmpty()) return BigInteger.ZERO;
        return new BigInteger(x, lenient ? 10 : 16);
    }

    static String format(AbiType type, Object v) {
        if (type.array) {
            @SuppressWarnings("unchecked") List<Object> xs = (List<Object>) v;
            List<String> parts = new ArrayList<>();
            for (Object o : xs) parts.add(format(type.elem, o));
            return "[" + String.join(",", parts) + "]";
        }
        if ("bool".equals(type.base)) return ((Boolean) v) ? "true" : "false";
        if (type.base.startsWith("uint") || type.base.startsWith("int")) return ((BigInteger) v).toString(16);
        if ("address".equals(type.base) || "bytes".equals(type.base) || type.base.startsWith("bytes")) return hex((byte[]) v);
        if ("string".equals(type.base)) return (String) v;
        return String.valueOf(v);
    }

    static List<String> splitTop(String s) {
        List<String> out = new ArrayList<>();
        int depth = 0, start = 0;
        boolean quote = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\'') quote = !quote;
            else if (!quote && c == '[') depth++;
            else if (!quote && c == ']') depth--;
            else if (!quote && depth == 0 && c == ',') {
                out.add(s.substring(start, i));
                start = i + 1;
            }
        }
        out.add(s.substring(start));
        return out;
    }

    static String stripQuotes(String s) {
        if (s.length() >= 2 && ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'")))) return s.substring(1, s.length() - 1);
        return s;
    }

    static String strip0x(String s) {
        return s.startsWith("0x") || s.startsWith("0X") ? s.substring(2) : s;
    }

    static byte[] parseHex(String s) {
        String x = strip0x(s).trim();
        if ((x.length() & 1) == 1) throw new IllegalArgumentException("Hex parsing error: Odd number of digits\n\nCaused by:\n    Odd number of digits");
        byte[] out = new byte[x.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(x.substring(i * 2, i * 2 + 2), 16);
        return out;
    }

    static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte value : b) sb.append(String.format("%02x", value & 0xff));
        return sb.toString();
    }

    static byte[] concat(byte[]... arrs) {
        int n = 0; for (byte[] a : arrs) n += a.length;
        byte[] out = new byte[n]; int p = 0;
        for (byte[] a : arrs) { System.arraycopy(a, 0, out, p, a.length); p += a.length; }
        return out;
    }

    static List<AbiItem> loadAbi(String file) throws IOException {
        Object root = new Json(Files.readString(Path.of(file))).parse();
        List<AbiItem> items = new ArrayList<>();
        if (!(root instanceof List<?> list)) return items;
        for (Object o : list) {
            if (!(o instanceof Map<?, ?> m)) continue;
            AbiItem it = new AbiItem();
            it.type = str(m.get("type"));
            it.name = str(m.get("name"));
            it.anonymous = Boolean.TRUE.equals(m.get("anonymous"));
            it.inputs = params(m.get("inputs"));
            it.outputs = params(m.get("outputs"));
            items.add(it);
        }
        return items;
    }

    static List<Param> params(Object o) {
        List<Param> ps = new ArrayList<>();
        if (!(o instanceof List<?> list)) return ps;
        for (Object x : list) if (x instanceof Map<?, ?> m) {
            Param p = new Param();
            p.name = str(m.get("name"));
            p.type = AbiType.parse(str(m.get("type")));
            p.indexed = Boolean.TRUE.equals(m.get("indexed"));
            ps.add(p);
        }
        return ps;
    }

    static String str(Object o) { return o == null ? "" : o.toString(); }

    static AbiItem findItem(List<AbiItem> items, String type, String spec) {
        String name = spec;
        String sig = null;
        if (spec.contains("(")) {
            sig = spec;
            name = spec.substring(0, spec.indexOf('('));
        }
        for (AbiItem it : items) {
            if (!type.equals(it.type)) continue;
            if (sig != null) {
                if (it.signature().equals(sig)) return it;
            } else if (name.equals(it.name)) return it;
        }
        return null;
    }

    static void helpRoot() { System.out.println("ethabi-cli " + VERSION + "\nEthereum ABI coder\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    decode    Decode ABI call result\n    encode    Encode ABI call\n    help      Prints this message or the help of the given subcommand(s)"); }
    static void helpEncode() { System.out.println("executable-encode " + VERSION + "\nEncode ABI call\n\nUSAGE:\n    executable encode <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    help        Prints this message or the help of the given subcommand(s)\n    params      Specify types of input params inline"); }
    static void helpDecode() { System.out.println("executable-decode " + VERSION + "\nDecode ABI call result\n\nUSAGE:\n    executable decode <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    help        Prints this message or the help of the given subcommand(s)\n    log         Decode event log\n    params      Specify types of input params inline"); }
    static void helpEncodeFunction() { System.out.println("executable-encode-function " + VERSION + "\nLoad function from JSON ABI file\n\nUSAGE:\n    executable encode function [FLAGS] [OPTIONS] <abi-path> <function-name-or-signature>\n\nFLAGS:\n    -h, --help       Prints help information\n    -l, --lenient    Allow short representation of input params\n    -V, --version    Prints version information\n\nOPTIONS:\n    -p <params>...        \n\nARGS:\n    <abi-path>                      \n    <function-name-or-signature>    "); }
    static void helpEncodeParams() { System.out.println("executable-encode-params " + VERSION + "\nSpecify types of input params inline\n\nUSAGE:\n    executable encode params [FLAGS] [OPTIONS]\n\nFLAGS:\n    -h, --help       \n            Prints help information\n\n    -l, --lenient    \n            Allow short representation of input params (numbers are in decimal form)\n\n    -V, --version    \n            Prints version information\n\n\nOPTIONS:\n    -v <type-or-param> <type-or-param>        \n            Pairs of types directly followed by params in the form:\n            \n            -v <type1> <param1> -v <type2> <param2> ..."); }
    static void helpDecodeFunction() { System.out.println("executable-decode-function " + VERSION + "\nLoad function from JSON ABI file\n\nUSAGE:\n    executable decode function <abi-path> <function-name-or-signature> <data>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <abi-path>                      \n    <function-name-or-signature>    \n    <data>                          "); }
    static void helpDecodeParams() { System.out.println("executable-decode-params " + VERSION + "\nSpecify types of input params inline\n\nUSAGE:\n    executable decode params [OPTIONS] <data>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -t <type>...        \n\nARGS:\n    <data>    "); }
    static void helpDecodeLog() { System.out.println("executable-decode-log " + VERSION + "\nDecode event log\n\nUSAGE:\n    executable decode log [OPTIONS] <abi-path> <event-name-or-signature> <data>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -l <topic>...        \n\nARGS:\n    <abi-path>                   \n    <event-name-or-signature>    \n    <data>                       "); }

    static class AbiItem {
        String type, name;
        boolean anonymous;
        List<Param> inputs = new ArrayList<>(), outputs = new ArrayList<>();
        String signature() {
            List<String> ts = new ArrayList<>();
            for (Param p : inputs) ts.add(p.type.canonical());
            return name + "(" + String.join(",", ts) + ")";
        }
    }

    static class Param {
        String name;
        AbiType type;
        boolean indexed;
    }

    static class AbiType {
        String base;
        boolean array;
        int arrayLen = -1;
        AbiType elem;

        static AbiType parse(String s) {
            s = s.trim();
            int idx = s.lastIndexOf('[');
            if (idx >= 0 && s.endsWith("]")) {
                AbiType t = new AbiType();
                t.array = true;
                String len = s.substring(idx + 1, s.length() - 1);
                t.arrayLen = len.isEmpty() ? -1 : Integer.parseInt(len);
                t.elem = parse(s.substring(0, idx));
                return t;
            }
            AbiType t = new AbiType();
            if ("uint".equals(s)) s = "uint256";
            if ("int".equals(s)) s = "int256";
            t.base = s;
            return t;
        }

        String canonical() {
            if (array) return elem.canonical() + "[" + (arrayLen < 0 ? "" : arrayLen) + "]";
            return base;
        }

        boolean isDynamic() {
            if (array) return arrayLen < 0 || elem.isDynamic();
            return "string".equals(base) || "bytes".equals(base);
        }
    }

    static class Abi {
        static byte[] encode(List<AbiType> types, List<Object> values) {
            List<byte[]> heads = new ArrayList<>();
            List<byte[]> tails = new ArrayList<>();
            int headSize = 32 * types.size();
            int tailSize = 0;
            for (int i = 0; i < types.size(); i++) {
                AbiType t = types.get(i);
                Object v = values.get(i);
                if (t.isDynamic()) {
                    heads.add(word(BigInteger.valueOf(headSize + tailSize)));
                    byte[] enc = encodeValue(t, v);
                    tails.add(enc);
                    tailSize += enc.length;
                } else {
                    heads.add(encodeValue(t, v));
                }
            }
            return concat(concatList(heads), concatList(tails));
        }

        static byte[] encodeValue(AbiType t, Object v) {
            if (t.array) {
                @SuppressWarnings("unchecked") List<Object> xs = (List<Object>) v;
                List<AbiType> ts = new ArrayList<>();
                for (int i = 0; i < xs.size(); i++) ts.add(t.elem);
                byte[] body = encode(ts, xs);
                return t.arrayLen < 0 ? concat(word(BigInteger.valueOf(xs.size())), body) : body;
            }
            String b = t.base;
            if ("bool".equals(b)) return word(Boolean.TRUE.equals(v) ? BigInteger.ONE : BigInteger.ZERO);
            if (b.startsWith("uint")) return word((BigInteger) v);
            if (b.startsWith("int")) return signedWord((BigInteger) v);
            if ("address".equals(b)) return leftPad((byte[]) v, 32);
            if ("string".equals(b)) return encodeDynamic(((String) v).getBytes(StandardCharsets.UTF_8));
            if ("bytes".equals(b)) return encodeDynamic((byte[]) v);
            if (b.startsWith("bytes")) return rightPad((byte[]) v, 32);
            throw new IllegalArgumentException("Unsupported type " + b);
        }

        static byte[] encodeDynamic(byte[] raw) {
            return concat(word(BigInteger.valueOf(raw.length)), rightPad(raw, ((raw.length + 31) / 32) * 32));
        }

        static List<Object> decode(List<AbiType> types, byte[] data, int base) {
            List<Object> out = new ArrayList<>();
            for (int i = 0; i < types.size(); i++) out.add(decodeOne(types.get(i), data, base, base + 32 * i));
            return out;
        }

        static Object decodeOne(AbiType t, byte[] data, int base, int pos) {
            if (t.isDynamic()) {
                int off = wordInt(data, pos);
                return decodeAt(t, data, base + off);
            }
            return decodeAt(t, data, pos);
        }

        static Object decodeAt(AbiType t, byte[] data, int pos) {
            if (t.array) {
                int len = t.arrayLen;
                int start = pos;
                if (len < 0) { len = wordInt(data, pos); start += 32; }
                List<AbiType> ts = new ArrayList<>();
                for (int i = 0; i < len; i++) ts.add(t.elem);
                return decode(ts, data, start);
            }
            byte[] w = slice(data, pos, 32);
            String b = t.base;
            if ("bool".equals(b)) return new BigInteger(1, w).signum() != 0;
            if (b.startsWith("uint")) return new BigInteger(1, w);
            if (b.startsWith("int")) return new BigInteger(w);
            if ("address".equals(b)) return slice(w, 12, 20);
            if ("string".equals(b)) {
                int len = wordInt(data, pos);
                return new String(slice(data, pos + 32, len), StandardCharsets.UTF_8);
            }
            if ("bytes".equals(b)) {
                int len = wordInt(data, pos);
                return slice(data, pos + 32, len);
            }
            if (b.startsWith("bytes")) return slice(w, 0, Integer.parseInt(b.substring(5)));
            throw new IllegalArgumentException("Unsupported type " + b);
        }

        static int wordInt(byte[] data, int pos) {
            return new BigInteger(1, slice(data, pos, 32)).intValue();
        }

        static byte[] concatList(List<byte[]> xs) {
            return concat(xs.toArray(new byte[0][]));
        }

        static byte[] word(BigInteger n) {
            return leftPad(n.toByteArray(), 32);
        }

        static byte[] signedWord(BigInteger n) {
            byte[] in = n.toByteArray();
            byte[] out = new byte[32];
            if (n.signum() < 0) Arrays.fill(out, (byte) 0xff);
            int copy = Math.min(in.length, 32);
            System.arraycopy(in, in.length - copy, out, 32 - copy, copy);
            return out;
        }

        static byte[] leftPad(byte[] in, int n) {
            byte[] out = new byte[n];
            int copy = Math.min(in.length, n);
            System.arraycopy(in, in.length - copy, out, n - copy, copy);
            return out;
        }

        static byte[] rightPad(byte[] in, int n) {
            byte[] out = new byte[n];
            System.arraycopy(in, 0, out, 0, Math.min(in.length, n));
            return out;
        }

        static byte[] slice(byte[] data, int pos, int len) {
            if (pos < 0 || pos + len > data.length) throw new IllegalArgumentException("Invalid data");
            return Arrays.copyOfRange(data, pos, pos + len);
        }
    }

    static class Json {
        final String s; int p;
        Json(String s) { this.s = s; }
        Object parse() { skip(); return val(); }
        Object val() {
            skip();
            char c = s.charAt(p);
            if (c == '"') return string();
            if (c == '{') return obj();
            if (c == '[') return arr();
            if (s.startsWith("true", p)) { p += 4; return Boolean.TRUE; }
            if (s.startsWith("false", p)) { p += 5; return Boolean.FALSE; }
            if (s.startsWith("null", p)) { p += 4; return null; }
            int st = p;
            while (p < s.length() && "-0123456789".indexOf(s.charAt(p)) >= 0) p++;
            return s.substring(st, p);
        }
        Map<String,Object> obj() {
            Map<String,Object> m = new LinkedHashMap<>(); p++; skip();
            while (p < s.length() && s.charAt(p) != '}') {
                String k = string(); skip(); p++; Object v = val(); m.put(k, v); skip();
                if (s.charAt(p) == ',') { p++; skip(); }
            }
            p++; return m;
        }
        List<Object> arr() {
            List<Object> a = new ArrayList<>(); p++; skip();
            while (p < s.length() && s.charAt(p) != ']') {
                a.add(val()); skip();
                if (s.charAt(p) == ',') { p++; skip(); }
            }
            p++; return a;
        }
        String string() {
            StringBuilder b = new StringBuilder(); p++;
            while (p < s.length()) {
                char c = s.charAt(p++);
                if (c == '"') break;
                if (c == '\\') {
                    char e = s.charAt(p++);
                    if (e == 'n') b.append('\n'); else if (e == 't') b.append('\t'); else if (e == 'r') b.append('\r'); else b.append(e);
                } else b.append(c);
            }
            return b.toString();
        }
        void skip() { while (p < s.length() && Character.isWhitespace(s.charAt(p))) p++; }
    }

    static class Keccak {
        static final long[] RC = {
            0x0000000000000001L,0x0000000000008082L,0x800000000000808aL,0x8000000080008000L,
            0x000000000000808bL,0x0000000080000001L,0x8000000080008081L,0x8000000000008009L,
            0x000000000000008aL,0x0000000000000088L,0x0000000080008009L,0x000000008000000aL,
            0x000000008000808bL,0x800000000000008bL,0x8000000000008089L,0x8000000000008003L,
            0x8000000000008002L,0x8000000000000080L,0x000000000000800aL,0x800000008000000aL,
            0x8000000080008081L,0x8000000000008080L,0x0000000080000001L,0x8000000080008008L};
        static final int[] R = {0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14};
        static byte[] keccak256(byte[] msg) {
            long[] st = new long[25];
            int rate = 136, off = 0;
            while (off + rate <= msg.length) {
                absorb(st, msg, off, rate); permute(st); off += rate;
            }
            byte[] block = new byte[rate];
            System.arraycopy(msg, off, block, 0, msg.length - off);
            block[msg.length - off] = 0x01;
            block[rate - 1] |= (byte) 0x80;
            absorb(st, block, 0, rate); permute(st);
            byte[] out = new byte[32];
            for (int i = 0; i < 32; i++) out[i] = (byte) ((st[i / 8] >>> (8 * (i % 8))) & 0xff);
            return out;
        }
        static void absorb(long[] st, byte[] b, int off, int rate) {
            for (int i = 0; i < rate / 8; i++) {
                long v = 0;
                for (int j = 0; j < 8; j++) v |= (long)(b[off + i * 8 + j] & 0xff) << (8 * j);
                st[i] ^= v;
            }
        }
        static void permute(long[] a) {
            long[] b = new long[25], c = new long[5], d = new long[5];
            for (int round = 0; round < 24; round++) {
                for (int x = 0; x < 5; x++) c[x] = a[x] ^ a[x+5] ^ a[x+10] ^ a[x+15] ^ a[x+20];
                for (int x = 0; x < 5; x++) d[x] = c[(x+4)%5] ^ Long.rotateLeft(c[(x+1)%5], 1);
                for (int x = 0; x < 5; x++) for (int y = 0; y < 5; y++) a[x+5*y] ^= d[x];
                for (int x = 0; x < 5; x++) for (int y = 0; y < 5; y++) {
                    int idx = x + 5*y;
                    int nx = y;
                    int ny = (2*x + 3*y) % 5;
                    b[nx + 5*ny] = Long.rotateLeft(a[idx], R[idx]);
                }
                for (int x = 0; x < 5; x++) for (int y = 0; y < 5; y++) a[x+5*y] = b[x+5*y] ^ ((~b[((x+1)%5)+5*y]) & b[((x+2)%5)+5*y]);
                a[0] ^= RC[round];
            }
        }
    }
}
