import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class TinyccCompat {
    private static final String VERSION = "0.9.28rc";
    private static final String VERSION_LINE =
            "tcc version 0.9.28rc 2026-04-21 build@237d0db* (x86_64 Linux)";

    public static void main(String[] rawArgs) {
        int code;
        try {
            code = new TinyccCompat().run(expandAtFiles(Arrays.asList(rawArgs)));
        } catch (ExitCode e) {
            code = e.code;
        } catch (Exception e) {
            System.err.println("tcc: error: " + e.getMessage());
            code = 1;
        }
        System.exit(code);
    }

    private int run(List<String> args) throws Exception {
        if (args.isEmpty()) {
            printHelp();
            return 0;
        }
        if (args.size() == 1) {
            switch (args.get(0)) {
                case "-h":
                case "--help":
                    printHelp();
                    return 0;
                case "-hh":
                    printMoreHelp();
                    return 0;
                case "-v":
                case "--version":
                    System.out.println(VERSION_LINE);
                    return 0;
                case "-vv":
                    printVerbose();
                    return 0;
                case "-dumpversion":
                    System.out.println(VERSION);
                    return 0;
            }
        }

        if ("-ar".equals(args.get(0))) {
            List<String> cmd = new ArrayList<>();
            cmd.add("ar");
            cmd.addAll(args.subList(1, args.size()));
            return exec(cmd, null, false);
        }

        Options opt = parse(args);
        if (opt.runMode) return runSource(opt);
        if (opt.inputs.isEmpty()) {
            System.err.println("tcc: error: no input files");
            return 1;
        }
        return compile(opt);
    }

    private Options parse(List<String> args) throws IOException {
        Options opt = new Options();
        boolean afterRun = false;
        for (int i = 0; i < args.size(); i++) {
            String a = args.get(i);
            if (afterRun) {
                if (opt.runSource == null && "-rstdin".equals(a)) {
                    opt.runStdin = needArg(args, ++i, "-rstdin");
                } else if (opt.runSource == null && "--".equals(a)) {
                    opt.runSource = "-";
                } else if (opt.runSource == null) {
                    opt.runSource = a;
                } else {
                    opt.runArgs.add(a);
                }
                continue;
            }
            switch (a) {
                case "-h":
                case "--help":
                    printHelp();
                    throw new ExitCode(0);
                case "-hh":
                    printMoreHelp();
                    throw new ExitCode(0);
                case "-v":
                case "--version":
                    System.out.println(VERSION_LINE);
                    throw new ExitCode(0);
                case "-vv":
                    printVerbose();
                    throw new ExitCode(0);
                case "-dumpversion":
                    System.out.println(VERSION);
                    throw new ExitCode(0);
                case "-print-search-dirs":
                    printSearchDirs();
                    throw new ExitCode(0);
                case "-run":
                    opt.runMode = true;
                    afterRun = true;
                    break;
                case "-o":
                    opt.output = needArg(args, ++i, "-o");
                    opt.gcc.add("-o");
                    opt.gcc.add(opt.output);
                    break;
                case "-c":
                case "-E":
                case "-shared":
                case "-static":
                case "-nostdinc":
                case "-nostdlib":
                case "-r":
                case "-rdynamic":
                case "-g":
                case "-w":
                case "-pipe":
                case "-s":
                case "-pthread":
                case "-P":
                case "-dD":
                case "-dM":
                case "-MD":
                case "-MMD":
                case "-M":
                case "-MM":
                    opt.gcc.add(a);
                    if ("-E".equals(a)) opt.preprocessOnly = true;
                    if ("-c".equals(a)) opt.compileOnly = true;
                    break;
                case "-bench":
                    opt.bench = true;
                    break;
                case "-b":
                    opt.gcc.add("-g");
                    break;
                case "-bt":
                    opt.gcc.add("-g");
                    break;
                case "-MF":
                case "-include":
                case "-isystem":
                case "-x":
                case "-Xlinker":
                case "-I":
                case "-D":
                case "-U":
                case "-L":
                case "-l":
                    opt.gcc.add(a);
                    opt.gcc.add(needArg(args, ++i, a));
                    break;
                case "-soname":
                    opt.gcc.add("-Wl,-soname," + needArg(args, ++i, a));
                    break;
                case "-B":
                    i++;
                    break;
                default:
                    if (a.matches("-x[cabn]")) {
                        opt.gcc.add("-x");
                        opt.gcc.add(switch (a.charAt(2)) {
                            case 'a' -> "assembler";
                            case 'b' -> "binary";
                            case 'n' -> "none";
                            default -> "c";
                        });
                    } else if (a.startsWith("-I") || a.startsWith("-D") || a.startsWith("-U")
                            || a.startsWith("-L") || a.startsWith("-l")
                            || a.startsWith("-std=") || a.startsWith("-O")
                            || a.startsWith("-m") || a.startsWith("-Wl,")
                            || a.startsWith("-Wp,") || a.startsWith("-f")
                            || a.startsWith("-W") || a.startsWith("-g")
                            || a.startsWith("-MF")) {
                        opt.gcc.add(translateJoinedOption(a));
                    } else if ("-".equals(a)) {
                        opt.inputs.add(a);
                        opt.gcc.add(a);
                    } else if (a.startsWith("-")) {
                        if (isIgnoredTccOption(a)) {
                            // Accepted by tcc but irrelevant for this compatibility wrapper.
                        } else {
                            System.err.println("tcc: error: invalid option -- '" + a + "'");
                            throw new ExitCode(1);
                        }
                    } else {
                        opt.inputs.add(a);
                        opt.gcc.add(a);
                    }
            }
        }
        if (opt.runMode && opt.runSource == null) {
            System.err.println("tcc: error: no input files");
            throw new ExitCode(1);
        }
        return opt;
    }

    private int compile(Options opt) throws Exception {
        List<String> cmd = new ArrayList<>();
        cmd.add("gcc");
        if (!opt.gcc.contains("-std=c11") && !hasPrefix(opt.gcc, "-std=")) {
            cmd.add("-std=gnu11");
        }
        addTccMacros(cmd);
        for (String s : opt.gcc) {
            if ("-".equals(s)) {
                cmd.add("-x");
                cmd.add("c");
                cmd.add("-");
            } else {
                cmd.add(s);
            }
        }
        long start = System.nanoTime();
        int code = exec(cmd, null, false);
        if (opt.bench && code == 0) {
            long ms = (System.nanoTime() - start) / 1_000_000L;
            System.err.println("tcc: total " + (ms / 1000.0) + "s");
        }
        return code;
    }

    private int runSource(Options opt) throws Exception {
        Path dir = Files.createTempDirectory("tccrun-");
        Path exe = dir.resolve("a.out");
        List<String> cmd = new ArrayList<>();
        cmd.add("gcc");
        cmd.add("-std=gnu11");
        addTccMacros(cmd);
        cmd.add("-x");
        cmd.add("c");
        cmd.add(opt.runSource);
        cmd.add("-o");
        cmd.add(exe.toString());

        // Reuse compile-time options that make sense before -run.
        for (String a : opt.gcc) {
            if (!"-E".equals(a) && !"-c".equals(a) && !"-o".equals(a) && !a.equals(opt.output)) {
                cmd.add(a);
            }
        }
        int compiled = exec(cmd, null, false);
        if (compiled != 0) {
            deleteTree(dir);
            return compiled;
        }
        List<String> run = new ArrayList<>();
        run.add("bash");
        run.add("-c");
        run.add("exec -a \"$0\" \"$1\" \"${@:2}\"");
        run.add(opt.runSource);
        run.add(exe.toString());
        run.addAll(opt.runArgs);
        FileInputStream stdin = null;
        try {
            if (opt.runStdin != null) stdin = new FileInputStream(opt.runStdin);
            return exec(run, stdin, true);
        } finally {
            if (stdin != null) stdin.close();
            deleteTree(dir);
        }
    }

    private static String translateJoinedOption(String a) {
        if (a.startsWith("-Wp,")) return a.substring(4);
        return a;
    }

    private static void addTccMacros(List<String> cmd) {
        cmd.add("-D__TINYC__=928");
        cmd.add("-D__TCC_VERSION__=0x000928");
    }

    private static boolean hasPrefix(List<String> list, String prefix) {
        for (String s : list) if (s.startsWith(prefix)) return true;
        return false;
    }

    private static boolean isIgnoredTccOption(String a) {
        return a.equals("-P") || a.equals("-P1") || a.equals("-C") || a.equals("-arch")
                || a.equals("-pedantic") || a.equals("-traditional") || a.equals("-dt")
                || a.equals("--param") || a.startsWith("-bt") || a.startsWith("-Wa,");
    }

    private static String needArg(List<String> args, int index, String opt) {
        if (index >= args.size()) {
            System.err.println("tcc: error: argument to '" + opt + "' is missing");
            throw new ExitCode(1);
        }
        return args.get(index);
    }

    private static int exec(List<String> cmd, InputStream stdinOverride, boolean inheritInput) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(cmd);
        if (stdinOverride == null && inheritInput) pb.redirectInput(ProcessBuilder.Redirect.INHERIT);
        Process p = pb.start();
        Thread out = pump(p.getInputStream(), System.out);
        Thread err = pump(p.getErrorStream(), System.err);
        Thread in = null;
        if (stdinOverride != null) {
            in = pumpInput(stdinOverride, p.getOutputStream());
        } else if (!inheritInput) {
            in = pumpInput(System.in, p.getOutputStream());
        }
        int code = p.waitFor();
        if (in != null) in.join();
        out.join();
        err.join();
        return code;
    }

    private static Thread pump(InputStream in, OutputStream out) {
        Thread t = new Thread(() -> {
            try {
                in.transferTo(out);
                out.flush();
            } catch (IOException ignored) {
            }
        });
        t.start();
        return t;
    }

    private static Thread pumpInput(InputStream in, OutputStream out) {
        Thread t = new Thread(() -> {
            try (OutputStream o = out) {
                in.transferTo(o);
            } catch (IOException ignored) {
            }
        });
        t.start();
        return t;
    }

    private static void deleteTree(Path path) {
        try {
            if (!Files.exists(path)) return;
            Files.walk(path).sorted(Comparator.reverseOrder()).forEach(p -> {
                try { Files.deleteIfExists(p); } catch (IOException ignored) {}
            });
        } catch (IOException ignored) {
        }
    }

    private static List<String> expandAtFiles(List<String> args) throws IOException {
        List<String> out = new ArrayList<>();
        for (String a : args) {
            if (a.startsWith("@") && a.length() > 1) {
                out.addAll(splitArgs(Files.readString(Path.of(a.substring(1)))));
            } else {
                out.add(a);
            }
        }
        return out;
    }

    private static List<String> splitArgs(String s) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean sq = false, dq = false, esc = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (esc) {
                cur.append(c);
                esc = false;
            } else if (c == '\\' && !sq) {
                esc = true;
            } else if (c == '\'' && !dq) {
                sq = !sq;
            } else if (c == '"' && !sq) {
                dq = !dq;
            } else if (Character.isWhitespace(c) && !sq && !dq) {
                if (cur.length() > 0) {
                    out.add(cur.toString());
                    cur.setLength(0);
                }
            } else {
                cur.append(c);
            }
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private static void printHelp() {
        System.out.print("""
Tiny C Compiler 0.9.28rc - Copyright (C) 2001-2006 Fabrice Bellard
Usage: tcc [options...] [-o outfile] [-c] infile(s)...
       tcc [options...] -run infile (or --) [arguments...]
General options:
  -c           compile only - generate an object file
  -o outfile   set output filename
  -run         run compiled source [with custom stdin: -rstdin FILE]
  -fflag       set or reset (with 'no-' prefix) 'flag' (see tcc -hh)
  -Wwarning    set or reset (with 'no-' prefix) 'warning' (see tcc -hh)
  -w           disable all warnings
  -v --version show version
  -vv          show search paths or loaded files
  -h -hh       show this, show more help
  -bench       show compilation statistics
  -            use stdin pipe as infile
  @listfile    read arguments from listfile
Preprocessor options:
  -Idir        add include path 'dir'
  -Dsym[=val]  define 'sym' with value 'val'
  -Usym        undefine 'sym'
  -E           preprocess only
  -nostdinc    do not use standard system include paths
Linker options:
  -Ldir        add library path 'dir'
  -llib        link with dynamic or static library 'lib'
  -nostdlib    do not link with standard crt and libraries
  -r           generate (relocatable) object file
  -rdynamic    export all global symbols to dynamic linker
  -shared      generate a shared library/dll
  -soname      set name for shared library to be used at runtime
  -Wl,-opt[=val]  set linker option (see tcc -hh)
Debugger options:
  -g           generate stab runtime debug info
  -gdwarf[-x]  generate dwarf runtime debug info
  -b           compile with built-in memory and bounds checker (implies -g)
  -bt[N]       link with backtrace (stack dump) support [show max N callers]
Misc. options:
  -std=version define __STDC_VERSION__ according to version (c11/gnu11)
  -x[c|a|b|n]  specify type of the next infile (C,ASM,BIN,NONE)
  -Bdir        set tcc's private include/library dir
  -M[M]D       generate make dependency file [ignore system files]
  -M[M]        as above but no other output
  -MF file     specify dependency file name
  -m32/64      defer to i386/x86_64 cross compiler
Tools:
  create library  : tcc -ar [crstvx] lib [files]
Discussion & bug reports:
  https://lists.nongnu.org/mailman/listinfo/tinycc-devel
""");
    }

    private static void printMoreHelp() {
        System.out.print("""
Tiny C Compiler 0.9.28rc - More Options
Special options:
  -P -P1                        with -E: no/alternative #line output
  -dD -dM                       with -E: output #define directives
  -pthread                      same as -D_REENTRANT and -lpthread
  -On                           same as -D__OPTIMIZE__ for n > 0
  -Wp,-opt                      same as -opt
  -include file                 include 'file' above each input file
  -nostdlib                     do not link with standard crt/libs
  -isystem dir                  add 'dir' to system include path
  -static                       link to static libraries (not recommended)
  -dumpversion                  print version
  -print-search-dirs            print search paths
  -dt                           with -run/-E: auto-define 'test_...' macros
Ignored options:
  -arch -C --param -pedantic -pipe -s -traditional
-W[no-]... warnings:
  all                           turn on some (*) warnings
  error[=warning]               stop after warning (any or specified)
  write-strings                 strings are const
  unsupported                   warn about ignored options, pragmas, etc.
  implicit-function-declaration warn for missing prototype (*)
  discarded-qualifiers          warn when const is dropped (*)
-f[no-]... flags:
  unsigned-char                 default char is unsigned
  signed-char                   default char is signed
  common                        use common section instead of bss
  leading-underscore            decorate extern symbols
  ms-extensions                 allow anonymous struct in struct
  dollars-in-identifiers        allow '$' in C symbols
  reverse-funcargs              evaluate function arguments right to left
  gnu89-inline                  'extern inline' is like 'static inline'
  asynchronous-unwind-tables    create eh_frame section [on]
  test-coverage                 create code coverage code
-m... target specific options:
  ms-bitfields                  use MSVC bitfield layout
  no-sse                        disable floats on x86_64
-Wl,... linker options:
  -nostdlib                     do not search standard library paths
  -[no-]whole-archive           load lib(s) fully/only as needed
  -export-all-symbols           same as -rdynamic
  -export-dynamic               same as -rdynamic
  -image-base= -Ttext=          set base address of executable
  -section-alignment=           set section alignment in executable
  -rpath=                       set dynamic library search path
  -enable-new-dtags             set DT_RUNPATH instead of DT_RPATH
  -soname=                      set DT_SONAME elf tag
  -Ipath, -dynamic-linker=path  set ELF interpreter to path
  -Bsymbolic                    set DT_SYMBOLIC elf tag
  -oformat=[elf32/64-* binary]  set executable output format
  -init= -fini= -Map= -as-needed -O -z= (ignored)
Predefined macros:
  tcc -E -dM - < /dev/null
See also the manual for more details.
""");
    }

    private static void printVerbose() {
        System.out.println(VERSION_LINE);
        printSearchDirs();
    }

    private static void printSearchDirs() {
        System.out.print("""
install: /usr/local/lib/tcc
include:
  /usr/local/lib/tcc/include
  /usr/local/include/x86_64-linux-gnu
  /usr/local/include
  /usr/include/x86_64-linux-gnu
  /usr/include
libraries:
  /usr/local/lib/tcc
  /usr/lib/x86_64-linux-gnu
  /usr/lib
  /lib/x86_64-linux-gnu
  /lib
  /usr/local/lib/x86_64-linux-gnu
  /usr/local/lib
libtcc1:
  /usr/local/lib/tcc/libtcc1.a
crt:
  /usr/lib/x86_64-linux-gnu
elfinterp:
  /lib64/ld-linux-x86-64.so.2
""");
    }

    private static final class Options {
        final List<String> gcc = new ArrayList<>();
        final List<String> inputs = new ArrayList<>();
        final List<String> runArgs = new ArrayList<>();
        String output;
        boolean runMode;
        String runSource;
        String runStdin;
        boolean bench;
        boolean preprocessOnly;
        boolean compileOnly;
    }

    private static final class ExitCode extends RuntimeException {
        final int code;
        ExitCode(int code) { this.code = code; }
    }
}
