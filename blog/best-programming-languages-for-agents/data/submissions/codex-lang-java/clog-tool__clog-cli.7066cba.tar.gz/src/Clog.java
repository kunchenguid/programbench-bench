import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.*;

public class Clog {
    static class Opt {
        String repository, from, to = "HEAD", format = "markdown", gitDir, workTree, subtitle, outfile, config = ".clog.toml", infile, setversion, linkStyle = "github", changelog;
        boolean major, minor, patch, fromLatestTag, help, version;
    }
    static class Commit {
        String hash, shortHash, type, scope, subject, body;
        List<Integer> issues = new ArrayList<>();
        boolean breaking;
    }
    static final LinkedHashMap<String, List<String>> DEFAULT_SECTIONS = new LinkedHashMap<>();
    static {
        DEFAULT_SECTIONS.put("Breaking Changes", Arrays.asList("breaking"));
        DEFAULT_SECTIONS.put("Features", Arrays.asList("feat", "feature"));
        DEFAULT_SECTIONS.put("Bug Fixes", Arrays.asList("fix", "bugfix"));
        DEFAULT_SECTIONS.put("Performance", Arrays.asList("perf"));
        DEFAULT_SECTIONS.put("Documentation", Arrays.asList("docs", "doc"));
    }

    public static void main(String[] args) {
        long start = System.currentTimeMillis();
        try {
            Opt opt = parse(args);
            if (opt.help) { printHelp(); return; }
            if (opt.version) { System.out.println("clog 0.10.0"); return; }
            Config cfg = readConfig(opt.config);
            applyConfig(opt, cfg);
            String text = generate(opt, cfg);
            String destination = opt.changelog != null ? opt.changelog : opt.outfile;
            if (destination != null) {
                String prior = "";
                if (opt.changelog != null && Files.exists(Path.of(destination))) prior = Files.readString(Path.of(destination));
                else if (opt.infile != null && Files.exists(Path.of(opt.infile))) prior = Files.readString(Path.of(opt.infile));
                Files.writeString(Path.of(destination), text + prior, StandardCharsets.UTF_8);
                System.out.println("changelog written. (took " + Math.max(1, System.currentTimeMillis() - start) + " ms)");
            } else {
                if (opt.infile != null && Files.exists(Path.of(opt.infile))) text += Files.readString(Path.of(opt.infile));
                System.out.print(text);
                System.out.println("changelog written. (took " + Math.max(1, System.currentTimeMillis() - start) + " ms)");
            }
        } catch (CliError e) {
            System.err.println(e.getMessage());
            System.exit(e.status);
        } catch (Exception e) {
            System.err.println("\u001b[1;31merror:\u001b[0m " + (e.getMessage() == null ? "fatal I/O error with output file" : e.getMessage()));
            System.exit(1);
        }
    }

    static class CliError extends Exception { int status; CliError(String m, int s){ super(m); status=s; } }
    static class Config {
        Map<String,String> clog = new HashMap<>();
        LinkedHashMap<String,List<String>> sections = new LinkedHashMap<>();
    }

    static Opt parse(String[] args) throws CliError {
        Opt o = new Opt();
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            switch(a) {
                case "-h": case "--help": o.help=true; break;
                case "-V": case "--version": o.version=true; break;
                case "-r": case "--repository": o.repository=need(args,++i,a); break;
                case "-f": case "--from": o.from=need(args,++i,a); break;
                case "-t": case "--to": o.to=need(args,++i,a); break;
                case "-T": case "--format": o.format=need(args,++i,a); break;
                case "-g": case "--git-dir": o.gitDir=need(args,++i,a); break;
                case "-w": case "--work-tree": o.workTree=need(args,++i,a); break;
                case "-s": case "--subtitle": o.subtitle=need(args,++i,a); break;
                case "-o": case "--outfile": o.outfile=need(args,++i,a); break;
                case "-c": case "--config": o.config=need(args,++i,a); break;
                case "-i": case "--infile": o.infile=need(args,++i,a); break;
                case "-l": case "--link-style": o.linkStyle=need(args,++i,a); break;
                case "-C": case "--changelog": o.changelog=need(args,++i,a); break;
                case "--setversion": o.setversion=need(args,++i,a); break;
                case "-M": case "--major": o.major=true; break;
                case "-m": case "--minor": o.minor=true; break;
                case "-p": case "--patch": o.patch=true; break;
                case "-F": case "--from-latest-tag": o.fromLatestTag=true; break;
                default:
                    if (a.startsWith("-")) throw new CliError("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.", 2);
                    throw new CliError("error: unexpected argument '" + a + "' found", 2);
            }
        }
        if (!o.format.equals("markdown") && !o.format.equals("json")) throw new CliError("error: invalid value '" + o.format + "' for '--format <STR>'", 2);
        return o;
    }
    static String need(String[] a,int i,String flag) throws CliError { if(i>=a.length) throw new CliError("error: a value is required for '" + flag + "'",2); return a[i]; }

    static Config readConfig(String path) throws IOException {
        Config c = new Config();
        Path p = Path.of(path);
        if (!Files.exists(p)) throw new IOException("fatal I/O error with output file");
        String section = "";
        for (String raw: Files.readAllLines(p)) {
            String line = raw.replaceFirst("#.*$", "").trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("[") && line.endsWith("]")) { section = line.substring(1,line.length()-1).trim(); continue; }
            int eq = line.indexOf('=');
            if (eq < 0) continue;
            String key = line.substring(0,eq).trim();
            String val = line.substring(eq+1).trim();
            if (section.equals("clog")) c.clog.put(key, unquote(val));
            if (section.equals("sections")) c.sections.put(unquote(key), parseList(val));
        }
        return c;
    }
    static String unquote(String s){ s=s.trim(); if((s.startsWith("\"")&&s.endsWith("\""))||(s.startsWith("'")&&s.endsWith("'"))) return s.substring(1,s.length()-1); return s; }
    static List<String> parseList(String v) {
        v=v.trim(); List<String> out=new ArrayList<>();
        if (v.startsWith("[") && v.endsWith("]")) {
            for (String part: v.substring(1,v.length()-1).split(",")) if(!part.trim().isEmpty()) out.add(unquote(part.trim()).toLowerCase(Locale.ROOT));
        } else out.add(unquote(v).toLowerCase(Locale.ROOT));
        return out;
    }
    static void applyConfig(Opt o, Config c) {
        if (o.repository==null) o.repository=c.clog.get("repository");
        if (c.clog.containsKey("from-latest-tag")) o.fromLatestTag |= c.clog.get("from-latest-tag").equalsIgnoreCase("true");
        if (c.clog.containsKey("link-style") && o.linkStyle.equals("github")) o.linkStyle=c.clog.get("link-style");
        if (c.clog.containsKey("changelog") && o.changelog==null) o.changelog=c.clog.get("changelog");
        if (c.clog.containsKey("from") && o.from==null) o.from=c.clog.get("from");
        if (c.clog.containsKey("to") && o.to.equals("HEAD")) o.to=c.clog.get("to");
    }

    static String generate(Opt o, Config cfg) throws Exception {
        if (o.fromLatestTag && o.from == null) o.from = latestTag(o);
        String version = version(o);
        List<Commit> commits = commits(o);
        LinkedHashMap<String,List<String>> sections = cfg.sections.isEmpty()?DEFAULT_SECTIONS:cfg.sections;
        LinkedHashMap<String,List<Commit>> grouped = group(commits, sections);
        if (o.format.equals("json")) return json(version, o, grouped);
        return markdown(version, o, grouped);
    }
    static String version(Opt o) throws Exception {
        if (o.setversion != null) return o.setversion;
        if (o.major||o.minor||o.patch) {
            String base = latestVersionFromChangelog(o);
            if (base == null) throw new CliError("\u001b[1;31merror:\u001b[0m Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.", 1);
            boolean v = base.startsWith("v"); String[] p = base.replaceFirst("^v","").split("\\.");
            int maj=Integer.parseInt(p[0]), min=Integer.parseInt(p[1]), pat=Integer.parseInt(p[2]);
            if(o.major){maj++;min=0;pat=0;} else if(o.minor){min++;pat=0;} else pat++;
            return (v?"v":"")+maj+"."+min+"."+pat;
        }
        return "";
    }
    static String latestVersionFromChangelog(Opt o) throws IOException {
        List<String> files = new ArrayList<>();
        if (o.infile!=null) files.add(o.infile);
        if (o.changelog!=null) files.add(o.changelog);
        files.add("changelog.md"); files.add("CHANGELOG.md");
        Pattern p=Pattern.compile("<a name=\"([^\"]+)\"|^#{2,3}\\s+v?([0-9]+\\.[0-9]+\\.[0-9]+)");
        for(String f:files) if(Files.exists(Path.of(f))) for(String line:Files.readAllLines(Path.of(f))) {
            Matcher m=p.matcher(line); if(m.find()) { String v=m.group(1)!=null?m.group(1):m.group(2); if(v!=null && v.matches("v?\\d+\\.\\d+\\.\\d+")) return v; }
        }
        return null;
    }
    static String latestTag(Opt o) {
        try { return runGit(o, "describe","--tags","--abbrev=0").trim(); } catch(Exception e){ return null; }
    }

    static List<Commit> commits(Opt o) throws Exception {
        List<String> cmd = new ArrayList<>();
        cmd.add("log"); cmd.add("--reverse"); cmd.add("--format=%H%x1f%s%x1f%B%x1e");
        String range = o.from==null ? o.to : o.from + ".." + o.to;
        if (range != null && !range.isEmpty()) cmd.add(range);
        String out = runGit(o, cmd.toArray(new String[0]));
        List<Commit> list = new ArrayList<>();
        for (String rec: out.split("\\x1e")) {
            rec=rec.trim(); if(rec.isEmpty()) continue;
            String[] parts=rec.split("\\x1f",3); if(parts.length<2) continue;
            Commit c=new Commit(); c.hash=parts[0].trim(); c.shortHash=c.hash.length()>7?c.hash.substring(0,7):c.hash; String subject=parts[1].trim(); c.body=parts.length>2?parts[2]:"";
            Matcher m=Pattern.compile("^([A-Za-z][A-Za-z0-9_-]*)(?:\\(([^)]*)\\))?!?:\\s*(.+)$").matcher(subject);
            if(!m.find()) continue;
            c.type=m.group(1).toLowerCase(Locale.ROOT); c.scope=m.group(2); c.subject=m.group(3).trim();
            c.breaking = subject.contains("!:") || c.body.contains("BREAKING CHANGE");
            Matcher im=Pattern.compile("(?i)(?:close[sd]?|fix(?:e[sd])?|resolve[sd]?)\\s+#(\\d+)").matcher(subject+"\n"+c.body);
            while(im.find()) c.issues.add(Integer.parseInt(im.group(1)));
            list.add(c);
        }
        return list;
    }
    static LinkedHashMap<String,List<Commit>> group(List<Commit> commits, LinkedHashMap<String,List<String>> defs) {
        LinkedHashMap<String,List<Commit>> out=new LinkedHashMap<>();
        for(String k:defs.keySet()) out.put(k,new ArrayList<>());
        for(Commit c:commits) {
            if(c.breaking && out.containsKey("Breaking Changes")) out.get("Breaking Changes").add(c);
            for(Map.Entry<String,List<String>> e:defs.entrySet()) if(e.getValue().contains(c.type)) { out.get(e.getKey()).add(c); break; }
        }
        out.entrySet().removeIf(e -> e.getValue().isEmpty());
        return out;
    }
    static String markdown(String version, Opt o, LinkedHashMap<String,List<Commit>> grouped) {
        String date=LocalDate.now().toString();
        boolean patchHeader = o.patch && !o.major && !o.minor && version.matches("v?\\d+\\.\\d+\\.\\d+");
        StringBuilder sb=new StringBuilder();
        sb.append("<a name=\"").append(version).append("\"></a>\n");
        sb.append(patchHeader?"### ":"## ").append(version).append(" ");
        sb.append(o.subtitle==null?"":o.subtitle).append(" (").append(date).append(")\n\n");
        for (Map.Entry<String,List<Commit>> e: grouped.entrySet()) {
            sb.append("\n#### ").append(e.getKey()).append("\n\n");
            for (Commit c:e.getValue()) {
                sb.append("* ");
                if(c.scope!=null && !c.scope.isEmpty()) sb.append("**").append(esc(c.scope)).append("**: ");
                sb.append(esc(c.subject)).append(" ");
                List<String> links=new ArrayList<>(); links.add("[" + c.shortHash + "](" + commitUrl(o,c.hash) + ")");
                for(Integer n:c.issues) links.add("closes [#"+n+"]("+issueUrl(o,n)+")");
                sb.append("(").append(String.join(", ", links)).append(")\n");
            }
            sb.append("\n");
        }
        sb.append("\n\n");
        return sb.toString();
    }
    static String json(String version, Opt o, LinkedHashMap<String,List<Commit>> grouped) {
        StringBuilder sb=new StringBuilder();
        sb.append("{\"header\":{\"version\":").append(version.isEmpty()?"None":"Some(\""+j(version)+"\")")
          .append(",\"patch_version\":").append(o.patch && !o.major && !o.minor)
          .append(",\"subtitle\":").append(o.subtitle==null?"null":"\""+j(o.subtitle)+"\"")
          .append(",\"date\":\"").append(LocalDate.now()).append("\"},\"sections\":");
        if(grouped.isEmpty()) sb.append("null}");
        else {
            sb.append("["); boolean firstS=true;
            for(var e:grouped.entrySet()) { if(!firstS) sb.append(","); firstS=false; sb.append("{\"title\":\"").append(j(e.getKey())).append("\",\"commits\":["); boolean fc=true;
                for(Commit c:e.getValue()){ if(!fc) sb.append(","); fc=false; sb.append("{\"hash\":\"").append(c.hash).append("\",\"subject\":\"").append(j(c.subject)).append("\",\"scope\":").append(c.scope==null?"null":"\""+j(c.scope)+"\"").append("}"); }
                sb.append("]}");
            }
            sb.append("]}");
        }
        return sb.toString();
    }
    static String esc(String s){ return s==null?"":s; } static String j(String s){ return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n"); }
    static String commitUrl(Opt o,String h){ if(o.repository==null||o.repository.isEmpty()) return h; String sep=o.linkStyle.equals("stash")?"/commits/":"/commit/"; return trimGit(o.repository)+sep+h; }
    static String issueUrl(Opt o,int n){ if(o.repository==null||o.repository.isEmpty()) return "#"+n; return trimGit(o.repository)+"/issues/"+n; }
    static String trimGit(String r){ return r.endsWith(".git")?r.substring(0,r.length()-4):r; }
    static String runGit(Opt o, String... args) throws Exception {
        List<String> cmd=new ArrayList<>(); cmd.add("git");
        if(o.gitDir!=null){cmd.add("--git-dir");cmd.add(o.gitDir);} if(o.workTree!=null){cmd.add("--work-tree");cmd.add(o.workTree);}
        cmd.addAll(Arrays.asList(args));
        ProcessBuilder pb=new ProcessBuilder(cmd); pb.redirectErrorStream(true);
        Process p=pb.start(); byte[] data=p.getInputStream().readAllBytes(); int code=p.waitFor();
        String s=new String(data,StandardCharsets.UTF_8); if(code!=0) throw new IOException(s.trim().isEmpty()?"git failed":s.trim()); return s;
    }
    static void printHelp() {
        System.out.println("a conventional changelog for the rest of us\n\nUsage: executable [OPTIONS]\n\nOptions:\n  -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,\n                          e.g. https://github.com/thoughtram/clog)\n  -f, --from <COMMIT>     e.g. 12a8546\n  -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible\n                          values: markdown, json]\n  -M, --major             Increment major version by one (Sets minor and patch to 0)\n  -g, --git-dir <PATH>    Local .git directory (defaults to \"$(pwd)/.git\")\n  -w, --work-tree <PATH>  Local working tree of the git project (defaults to \"$(pwd)\")\n  -m, --minor             Increment minor version by one (Sets patch to 0)\n  -p, --patch             Increment patch version by one\n  -s, --subtitle <STR>    \n  -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]\n  -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)\n  -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]\n  -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with\n                          --outfile)\n      --setversion <VER>  e.g. 1.0.1\n  -F, --from-latest-tag   use latest tag as start (instead of --from)\n  -l, --link-style <STR>  The style of repository link to generate [default: github] [possible\n                          values: github, gitlab, stash, cgit]\n  -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the\n                          same file for both --infile and --outfile and should not be used in\n                          conjunction with either)\n  -h, --help              Print help\n  -V, --version           Print version\n\n\nIf your .git directory is a child of your project directory (most common, such as /myproject/.git)\nAND not in the current working directory (i.e you need to use --work-tree or --git-dir) you only\nneed to specify either the --work-tree (i.e. /myproject) OR --git-dir (i.e. /myproject/.git), you\ndon't need to use both.\n\nIf using the --config to specify a clog configuration TOML file NOT in the current working directory\n(meaning you need to use --work-tree or --git-dir) AND the TOML file is inside your project\ndirectory (i.e. /myproject/.clog.toml) you do not need to use --work-tree or --git-dir.");
    }
}
