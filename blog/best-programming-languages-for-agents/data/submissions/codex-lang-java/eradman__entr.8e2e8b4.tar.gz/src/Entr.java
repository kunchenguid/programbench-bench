import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Entr {
    private static final String RELEASE = "5.7";
    private static volatile boolean interrupted = false;
    private static Process runningChild = null;

    static class Options {
        int clear = 0;
        int dir = 0;
        int x = 0;
        boolean all = false;
        boolean nonInteractive = false;
        boolean postpone = false;
        boolean restart = false;
        boolean shell = false;
        boolean exitAfter = false;
        List<String> command = new ArrayList<>();
    }

    static class Snapshot {
        final boolean exists;
        final boolean regular;
        final long modified;
        final long size;

        Snapshot(Path p) {
            this.exists = Files.exists(p);
            this.regular = Files.isRegularFile(p);
            long m = 0;
            long s = 0;
            if (exists) {
                try {
                    m = Files.getLastModifiedTime(p).toMillis();
                } catch (IOException ignored) {
                }
                try {
                    if (regular) s = Files.size(p);
                } catch (IOException ignored) {
                }
            }
            this.modified = m;
            this.size = s;
        }

        boolean changed(Snapshot other) {
            return exists != other.exists || regular != other.regular ||
                    modified != other.modified || size != other.size;
        }
    }

    public static void main(String[] args) {
        int status;
        try {
            status = run(args);
        } catch (Exception e) {
            System.err.println("executable: " + e.getMessage());
            status = 1;
        }
        System.exit(status);
    }

    private static int run(String[] args) throws Exception {
        Options opt = parse(args);
        if (opt == null) return 1;
        if (opt.command.isEmpty()) {
            usage();
            return 1;
        }
        if (opt.shell && opt.command.size() != 1) {
            System.err.println("executable: -s requires commands to be formatted as a single argument");
            return 1;
        }

        if (!opt.nonInteractive && System.console() == null) {
            System.err.println("executable: unable to get terminal attributes, use '-n' to run non-interactively");
            return 1;
        }

        List<String> input = readInput();
        LinkedHashMap<String, Path> files = new LinkedHashMap<>();
        for (String line : input) {
            if (line.isEmpty()) continue;
            Path p = Paths.get(line);
            if (!Files.exists(p)) {
                System.err.println("executable: unable to stat '" + line + "'");
                continue;
            }
            if (Files.isRegularFile(p) || Files.isDirectory(p)) {
                files.putIfAbsent(line, p);
            }
        }
        if (files.isEmpty()) {
            System.err.println("executable: No regular files to watch");
            return 1;
        }

        List<String> names = new ArrayList<>(files.keySet());
        List<Path> paths = new ArrayList<>(files.values());
        Runtime.getRuntime().addShutdownHook(new Thread(Entr::terminateChild));

        if (opt.x > 0) ensureStatusScript();

        Map<Path, Snapshot> snapshots = new HashMap<>();
        for (Path p : paths) snapshots.put(p, new Snapshot(p));
        Map<Path, Set<String>> dirSnapshots = directorySnapshots(paths, opt.dir);

        String defaultTrigger = names.get(0);
        if (!opt.postpone) {
            int code = execute(opt, defaultTrigger, true);
            if (opt.exitAfter && !opt.restart) return code;
            if (opt.restart && opt.exitAfter && code != Integer.MIN_VALUE) return code;
        }

        while (!interrupted) {
            Thread.sleep(100);
            String trigger = null;
            boolean directoryAltered = false;

            for (int i = 0; i < paths.size(); i++) {
                Path p = paths.get(i);
                Snapshot old = snapshots.get(p);
                Snapshot now = new Snapshot(p);
                if (old == null || old.changed(now)) {
                    snapshots.put(p, now);
                    if (trigger == null) trigger = names.get(i);
                }
            }

            Map<Path, Set<String>> nowDirs = directorySnapshots(paths, opt.dir);
            for (Map.Entry<Path, Set<String>> entry : nowDirs.entrySet()) {
                Set<String> old = dirSnapshots.get(entry.getKey());
                if (old != null && !old.equals(entry.getValue())) {
                    directoryAltered = true;
                    if (trigger == null) trigger = entry.getKey().toString();
                    break;
                }
            }
            dirSnapshots = nowDirs;

            if (trigger != null) {
                int code = execute(opt, trigger, false);
                if (directoryAltered) {
                    System.err.println("executable: directory altered");
                    return 2;
                }
                if (opt.exitAfter && !opt.restart) return code;
                if (!opt.all) {
                    for (Path p : paths) snapshots.put(p, new Snapshot(p));
                    dirSnapshots = directorySnapshots(paths, opt.dir);
                }
            }
        }

        terminateChild();
        return 130;
    }

    private static Options parse(String[] args) {
        Options opt = new Options();
        int i = 0;
        for (; i < args.length; i++) {
            String a = args[i];
            if (!a.startsWith("-") || a.equals("-")) break;
            if (a.equals("--")) {
                i++;
                break;
            }
            for (int j = 1; j < a.length(); j++) {
                char c = a.charAt(j);
                switch (c) {
                    case 'a': opt.all = true; break;
                    case 'c': opt.clear++; break;
                    case 'd': opt.dir++; break;
                    case 'n': opt.nonInteractive = true; break;
                    case 'p': opt.postpone = true; break;
                    case 'r': opt.restart = true; break;
                    case 's': opt.shell = true; break;
                    case 'x': opt.x++; break;
                    case 'z': opt.exitAfter = true; break;
                    case 'h':
                        help();
                        return null;
                    default:
                        System.err.println("./executable: invalid option -- '" + c + "'");
                        usage();
                        return null;
                }
            }
        }
        opt.command.addAll(Arrays.asList(args).subList(i, args.length));
        return opt;
    }

    private static List<String> readInput() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        List<String> lines = new ArrayList<>();
        String line;
        while ((line = br.readLine()) != null) lines.add(line);
        return lines;
    }

    private static Map<Path, Set<String>> directorySnapshots(List<Path> paths, int dirMode) {
        if (dirMode <= 0) return Collections.emptyMap();
        Map<Path, Set<String>> result = new HashMap<>();
        for (Path p : paths) {
            Path d = Files.isDirectory(p) ? p : p.getParent();
            if (d == null) d = Paths.get(".");
            result.put(d, listDirectory(d, dirMode >= 2));
        }
        return result;
    }

    private static Set<String> listDirectory(Path dir, boolean includeDotFiles) {
        Set<String> names = new HashSet<>();
        try (var stream = Files.list(dir)) {
            stream.forEach(p -> {
                String n = p.getFileName().toString();
                if (includeDotFiles || !n.startsWith(".")) names.add(n);
            });
        } catch (IOException ignored) {
        }
        return names;
    }

    private static int execute(Options opt, String trigger, boolean initial) throws Exception {
        if (opt.restart) {
            terminateChild();
            startChild(opt, trigger);
            if (opt.exitAfter) return waitChild();
            return Integer.MIN_VALUE;
        }
        if (opt.clear > 0) {
            System.out.print("\033[2J");
            if (opt.clear > 1) System.out.print("\033[3J");
            System.out.print("\033[H");
            System.out.flush();
        }
        Process p = buildProcess(opt, trigger).start();
        pipe(p.getInputStream(), System.out);
        pipe(p.getErrorStream(), System.err);
        return p.waitFor();
    }

    private static void startChild(Options opt, String trigger) throws IOException {
        if (opt.clear > 0) {
            System.out.print("\033[2J");
            if (opt.clear > 1) System.out.print("\033[3J");
            System.out.print("\033[H");
            System.out.flush();
        }
        runningChild = buildProcess(opt, trigger).start();
        pipe(runningChild.getInputStream(), System.out);
        pipe(runningChild.getErrorStream(), System.err);
    }

    private static int waitChild() throws InterruptedException {
        if (runningChild == null) return 0;
        int code = runningChild.waitFor();
        runningChild = null;
        return code;
    }

    private static ProcessBuilder buildProcess(Options opt, String trigger) {
        List<String> cmd = new ArrayList<>();
        if (opt.shell) {
            String shell = System.getenv().getOrDefault("SHELL", "/bin/sh");
            cmd.add(shell);
            cmd.add("-c");
            cmd.add(opt.command.get(0));
            cmd.add(trigger);
        } else {
            for (String s : opt.command) cmd.add(s.equals("/_") ? trigger : s);
        }
        ProcessBuilder pb = new ProcessBuilder(cmd);
        Map<String, String> env = pb.environment();
        env.putIfAbsent("PAGER", "/bin/cat");
        return pb;
    }

    private static void pipe(java.io.InputStream in, java.io.PrintStream out) {
        Thread t = new Thread(() -> {
            try {
                in.transferTo(out);
                out.flush();
            } catch (IOException ignored) {
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private static void terminateChild() {
        Process p = runningChild;
        if (p == null || !p.isAlive()) {
            runningChild = null;
            return;
        }
        p.destroy();
        try {
            if (!p.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)) {
                p.destroyForcibly();
                p.waitFor();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        runningChild = null;
    }

    private static void ensureStatusScript() {
        String path = System.getenv("ENTR_STATUS_SCRIPT");
        if (path == null || path.isEmpty()) {
            String home = System.getenv("HOME");
            if (home == null || home.isEmpty()) return;
            path = home + "/.entr/status.awk";
        }
        Path p = Paths.get(path);
        if (Files.exists(p)) return;
        try {
            Files.createDirectories(p.getParent());
            Files.writeString(p, "{ print }\n");
        } catch (IOException ignored) {
        }
    }

    private static void usage() {
        System.err.println("release: " + RELEASE);
        System.err.println("usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames");
        System.err.println("hint: use -h to display option summary");
    }

    private static void help() {
        System.err.println("release: " + RELEASE);
        System.err.println("usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames");
        System.err.println("summary:");
        System.err.println("    -a  Do not consolidate events");
        System.err.println("    -c  Clear screen before execution");
        System.err.println("    -d  Track files added or removed from directories");
        System.err.println("    -n  Non-interactive mode");
        System.err.println("    -p  Wait for first event");
        System.err.println("    -r  Run as a background process, use signal to restart");
        System.err.println("    -s  Evaluate using a shell");
        System.err.println("    -x  Format exit status");
        System.err.println("    -z  Exit after the utility completes");
        System.err.println("docs:");
        System.err.println("    man entr");
    }
}
