import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Chamber {
    static final String[] COMMANDS = {
        "completion    Generate the autocompletion script for the specified shell",
        "delete        Delete a secret, including all versions",
        "env           Print the secrets from the parameter store in a format to export as environment variables",
        "exec          Executes a command with secrets loaded into the environment",
        "export        Exports parameters in the specified format",
        "find          Find the given secret across all services",
        "help          Help about any command",
        "history       View the history of a secret",
        "import        import secrets from json or yaml",
        "list          List the secrets set for a service",
        "list-services List services",
        "read          Read a specific secret from the parameter store",
        "tag           work with tags on secrets",
        "version       print version",
        "write         write a secret"
    };

    static class Opts {
        String backend = getenv("CHAMBER_SECRET_BACKEND", "ssm");
        int retries = parseIntEnv("CHAMBER_RETRIES", 10);
    }

    public static void main(String[] argv) {
        try {
            int code = new Chamber().run(argv);
            System.exit(code);
        } catch (UserError e) {
            System.err.println("Error: " + e.getMessage());
            if (e.usage != null) System.err.print(e.usage);
            System.exit(1);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] argv) throws Exception {
        ArrayList<String> args = new ArrayList<>(Arrays.asList(argv));
        Opts opts = parseGlobal(args);
        if (args.isEmpty()) { rootHelp(System.out); return 0; }
        String cmd = args.remove(0);
        if (cmd.equals("help")) {
            if (args.isEmpty()) rootHelp(System.out);
            else help(args);
            return 0;
        }
        if (cmd.equals("--help") || cmd.equals("-h")) { rootHelp(System.out); return 0; }
        switch (cmd) {
            case "version": if (hasHelp(args)) { commandHelp("version", System.out); return 0; } System.out.println("chamber dev"); return 0;
            case "list": return list(opts, args);
            case "list-services": return listServices(opts, args);
            case "read": return read(opts, args);
            case "write": return write(opts, args);
            case "delete": return del(opts, args);
            case "env": return env(opts, args);
            case "exec": return exec(opts, args);
            case "export": return export(opts, args);
            case "import": return imp(opts, args);
            case "find": return find(opts, args);
            case "history": return history(opts, args);
            case "tag": return tag(opts, args);
            case "completion": return completion(args);
            default: throw new UserError("unknown command \"" + cmd + "\" for \"chamber\"\nRun 'chamber --help' for usage.");
        }
    }

    Opts parseGlobal(ArrayList<String> args) {
        Opts o = new Opts();
        for (int i = 0; i < args.size();) {
            String a = args.get(i);
            if (a.equals("--")) break;
            if (a.equals("-b") || a.equals("--backend")) { needVal(args, i, a); o.backend = normBackend(args.remove(i+1)); args.remove(i); continue; }
            if (a.startsWith("--backend=")) { o.backend = normBackend(a.substring(10)); args.remove(i); continue; }
            if (a.equals("--backend-s3-bucket") || a.equals("--kms-key-alias") || a.equals("--retry-mode")) { needVal(args, i, a); args.remove(i+1); args.remove(i); continue; }
            if (a.startsWith("--backend-s3-bucket=") || a.startsWith("--kms-key-alias=") || a.startsWith("--retry-mode=") || a.equals("--verbose")) { args.remove(i); continue; }
            if (a.equals("-r") || a.equals("--retries")) {
                needVal(args, i, a);
                String v = args.get(i+1);
                try { o.retries = Integer.parseInt(v); } catch (NumberFormatException e) {
                    throw new UserError("invalid argument \"" + v + "\" for \"-r, --retries\" flag: strconv.ParseInt: parsing \"" + v + "\": invalid syntax");
                }
                args.remove(i+1); args.remove(i); continue;
            }
            if (a.startsWith("--retries=")) {
                String v = a.substring(10);
                try { o.retries = Integer.parseInt(v); } catch (NumberFormatException e) {
                    throw new UserError("invalid argument \"" + v + "\" for \"-r, --retries\" flag: strconv.ParseInt: parsing \"" + v + "\": invalid syntax");
                }
                args.remove(i); continue;
            }
            i++;
        }
        return o;
    }

    static String normBackend(String b) {
        String x = b.toLowerCase(Locale.ROOT);
        if (Arrays.asList("null","ssm","secretsmanager","s3","s3-kms").contains(x)) return x;
        throw new UserError("Failed to get secret store: invalid backend `" + b.toUpperCase(Locale.ROOT) + "`");
    }
    static void needVal(ArrayList<String> args, int i, String flag) { if (i+1 >= args.size()) throw new UserError("flag needs an argument: " + flag); }
    static boolean hasHelp(List<String> a) { return a.contains("--help") || a.contains("-h"); }
    static String getenv(String k, String d) { String v = System.getenv(k); return v == null || v.isEmpty() ? d : v; }
    static int parseIntEnv(String k, int d) { try { return Integer.parseInt(getenv(k, ""+d)); } catch(Exception e) { return d; } }
    void ensureNull(Opts o) { if (!o.backend.equals("null")) throw new UserError("Failed to get secret store: invalid backend `" + o.backend.toUpperCase(Locale.ROOT) + "`"); }

    int list(Opts o, ArrayList<String> a) { if (hasHelp(a)) { commandHelp("list", System.out); return 0; } ensureNull(o); boolean exp = a.remove("-e") | a.remove("--expand"); removeFlags(a, "-t","--time","-u","--user","-v","--version"); exact(a,1,"list"); System.out.println(exp ? "Key\tVersion\t\tLastModified\tUser\tValue" : "Key\tVersion\t\tLastModified\tUser"); return 0; }
    int listServices(Opts o, ArrayList<String> a) { if (hasHelp(a)) { commandHelp("list-services", System.out); return 0; } ensureNull(o); boolean s = a.remove("-s") | a.remove("--secrets"); if (a.size() > 1) throw usage("accepts at most 1 arg(s), received " + a.size(), "list-services"); if (!s) System.out.println("Service"); return 0; }
    int read(Opts o, ArrayList<String> a) { if (hasHelp(a)) { commandHelp("read", System.out); return 0; } stripValueFlags(a, "-v","--version"); a.remove("-q"); a.remove("--quiet"); exact(a,2,"read"); ensureNull(o); throw new UserError("Failed to read: Not implemented for Null Store"); }
    int write(Opts o, ArrayList<String> a) throws IOException { if (hasHelp(a)) { commandHelp("write", System.out); return 0; } stripValueFlags(a, "-t","--tags"); a.remove("-s"); a.remove("--singleline"); a.remove("--skip-unchanged"); a.remove("--"); exact(a,3,"write"); ensureNull(o); if (a.get(2).equals("-")) System.in.readAllBytes(); throw new UserError("Write is not implemented for Null Store"); }
    int del(Opts o, ArrayList<String> a) { if (hasHelp(a)) { commandHelp("delete", System.out); return 0; } a.remove("--exact-key"); exact(a,2,"delete"); ensureNull(o); throw new UserError("Not implemented for Null Store"); }
    int env(Opts o, ArrayList<String> a) { if (hasHelp(a)) { commandHelp("env", System.out); return 0; } removeFlags(a, "-p","--preserve-case","-e","--escape-strings"); exact(a,1,"env"); ensureNull(o); return 0; }
    int export(Opts o, ArrayList<String> a) throws IOException { if (hasHelp(a)) { commandHelp("export", System.out); return 0; } String fmt="json", out=null; for(int i=0;i<a.size();) { String x=a.get(i); if(x.equals("-f")||x.equals("--format")){fmt=a.get(i+1); a.remove(i+1); a.remove(i);} else if(x.startsWith("--format=")){fmt=x.substring(9); a.remove(i);} else if(x.equals("-o")||x.equals("--output-file")){out=a.get(i+1); a.remove(i+1); a.remove(i);} else if(x.startsWith("--output-file=")){out=x.substring(14); a.remove(i);} else i++; } if(a.isEmpty()) throw usage("requires at least 1 arg(s), only received 0","export"); ensureNull(o); String s; switch(fmt){case"json":s="{}\n";break;case"yaml":case"java-properties":case"dotenv":case"tfvars":s="";break;case"csv":s="Service,Key,Value\n";break;case"tsv":s="Service\tKey\tValue\n";break;default:throw new UserError("Unable to export parameters: Unsupported export format: "+fmt);} if(out!=null&&!out.isEmpty()) Files.writeString(Path.of(out),s); else System.out.print(s); return 0; }
    int imp(Opts o, ArrayList<String> a) throws IOException { if (hasHelp(a)) { commandHelp("import", System.out); return 0; } a.remove("--normalize-keys"); exact(a,2,"import"); ensureNull(o); if (a.get(1).equals("-")) System.in.readAllBytes(); throw new UserError("Failed to write secret: Write is not implemented for Null Store"); }
    int find(Opts o, ArrayList<String> a) { if (hasHelp(a)) { commandHelp("find", System.out); return 0; } a.remove("-v"); a.remove("--by-value"); exact(a,1,"find"); ensureNull(o); System.out.println("Service"); return 0; }
    int history(Opts o, ArrayList<String> a) { if (hasHelp(a)) { commandHelp("history", System.out); return 0; } exact(a,2,"history"); ensureNull(o); System.out.println("Event\tVersion\t\tDate\tUser"); return 0; }
    int tag(Opts o, ArrayList<String> a) { if (a.isEmpty() || hasHelp(a)) { tagHelp(System.out); return 0; } String sub=a.remove(0); if (hasHelp(a)) { tagSubHelp(sub,System.out); return 0; } ensureNull(o); if(sub.equals("read")) { exact(a,2,"tag read"); throw new UserError("Failed to read tags: Not implemented for Null Store"); } if(sub.equals("write")) { a.remove("--delete-other-tags"); if(a.size()<3) throw usage("requires at least 3 arg(s), only received "+a.size(),"tag write"); throw new UserError("Failed to write tags: Not implemented for Null Store"); } if(sub.equals("delete")) { if(a.size()<3) throw usage("requires at least 3 arg(s), only received "+a.size(),"tag delete"); throw new UserError("Failed to delete tags: Not implemented for Null Store"); } throw new UserError("unknown command \""+sub+"\" for \"chamber tag\""); }

    int exec(Opts o, ArrayList<String> a) throws Exception {
        if (hasHelp(a)) { commandHelp("exec", System.out); return 0; }
        boolean pristine=false, strict=false; String strictVal="chamberme";
        for(int i=0;i<a.size();) { String x=a.get(i); if(x.equals("--pristine")){pristine=true;a.remove(i);} else if(x.equals("--strict")){strict=true;a.remove(i);} else if(x.equals("--strict-value")){strictVal=a.get(i+1);a.remove(i+1);a.remove(i);} else if(x.startsWith("--strict-value=")){strictVal=x.substring(15);a.remove(i);} else i++; }
        ensureNull(o);
        int sep=a.indexOf("--"); if(sep<0 || sep==a.size()-1) throw usage("requires at least 2 arg(s), only received "+a.size(),"exec");
        List<String> cmd = new ArrayList<>(a.subList(sep+1,a.size()));
        if(strict) for(Map.Entry<String,String> e: System.getenv().entrySet()) if(e.getValue().equals(strictVal)) throw new UserError("parent env was expecting "+e.getKey()+"="+strictVal+", but was not in store");
        ProcessBuilder pb = new ProcessBuilder(cmd); if(pristine) pb.environment().clear(); pb.inheritIO(); Process p=pb.start(); return p.waitFor();
    }
    int completion(ArrayList<String> a) { if (a.isEmpty() || hasHelp(a)) { completionHelp(System.out); return 0; } String sh=a.get(0); if (a.size()>1 && hasHelp(a)) { completionSubHelp(sh,System.out); return 0; } if (Arrays.asList("bash","zsh","fish","powershell").contains(sh)) { System.out.println("# "+sh+" completion for chamber"); return 0; } throw new UserError("unknown command \""+sh+"\" for \"chamber completion\""); }

    void exact(List<String> a, int n, String cmd) { if(a.size()!=n) throw usage("accepts "+n+" arg(s), received "+a.size(), cmd); }
    UserError usage(String msg, String cmd) { return new UserError(msg, helpText(cmd)); }
    void removeFlags(ArrayList<String>a,String...fs){ Set<String>s=new HashSet<>(Arrays.asList(fs)); a.removeIf(s::contains); }
    void stripValueFlags(ArrayList<String>a,String...fs){ Set<String>s=new HashSet<>(Arrays.asList(fs)); for(int i=0;i<a.size();) if(s.contains(a.get(i))){ if(i+1<a.size())a.remove(i+1); a.remove(i);} else if(a.get(i).startsWith("--")&&a.get(i).contains("=")&&s.contains(a.get(i).substring(0,a.get(i).indexOf('=')))) a.remove(i); else i++; }

    static class UserError extends RuntimeException { String usage; UserError(String m){super(m);} UserError(String m,String u){super(m);usage=u;} }

    void help(List<String> a){ String c=a.get(0); if(c.equals("tag"))tagHelp(System.out); else if(c.equals("completion"))completionHelp(System.out); else commandHelp(c,System.out); }
    void rootHelp(PrintStream p){ p.print("CLI for storing secrets\n\nUsage:\n  chamber [command]\n\nAvailable Commands:\n"); for(String c:COMMANDS)p.println("  "+c); p.print("\nFlags:\n"+globalFlags()+"\nUse \"chamber [command] --help\" for more information about a command.\n"); }
    String globalFlags(){ return "  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND\n                                   \tnull: no-op\n                                   \tssm: SSM Parameter Store\n                                   \tsecretsmanager: Secrets Manager\n                                   \ts3: S3; requires --backend-s3-bucket\n                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default \"ssm\")\n      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET\n  -h, --help                       help for chamber\n      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default \"alias/parameter_store_key\")\n  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)\n      --retry-mode string          For SSM, the model used to retry requests\n                                    \t standard\n                                    \t adaptive (default \"standard\")\n      --verbose                    Print more information to STDERR\n"; }
    void commandHelp(String c, PrintStream p){ p.print(helpText(c)); }

    String globalFlagsCmd(){ return globalFlags().replace("  -h, --help                       help for chamber\n", ""); }
    String helpText(String c){ String d="",u="",f="  -h, --help   help for "+(c.contains(" ")?c.substring(c.indexOf(' ')+1):c)+"\n"; switch(c){case"version":d="print version";u="chamber version [flags]";break;case"list":d="List the secrets set for a service";u="chamber list <service> [flags]";f="  -e, --expand    Expand parameter list with values\n  -h, --help      help for list\n  -t, --time      Sort by modified time\n  -u, --user      Sort by user\n  -v, --version   Sort by version\n";break;case"list-services":d="List services";u="chamber list-services <service> [flags]";f="  -h, --help      help for list-services\n  -s, --secrets   Include secret names in the list\n";break;case"read":d="Read a specific secret from the parameter store";u="chamber read <service> <key> [flags]";f="  -h, --help          help for read\n  -q, --quiet         Only print the secret\n  -v, --version int   The version number of the secret. Defaults to latest. (default -1)\n";break;case"write":d="write a secret";u="chamber write <service> <key> [--] <value|-> [flags]";f="  -h, --help                  help for write\n  -s, --singleline            Insert single line parameter (end with \\n)\n      --skip-unchanged        Skip writing secret if value is unchanged\n  -t, --tags stringToString   Add tags to the secret; new secrets only (default [])\n";break;case"delete":d="Delete a secret, including all versions";u="chamber delete <service> <key> [flags]";f="      --exact-key   Prevent normalization of the provided key in order to delete any keys that match the exact provided casing.\n  -h, --help        help for delete\n";break;case"env":d="Print the secrets from the parameter store in a format to export as environment variables";u="chamber env <service> [flags]";f="  -p, --preserve-case    preserve variable name case\n  -e, --escape-strings   escape special characters in values\n  -h, --help             help for env\n";break;case"exec":d="Executes a command with secrets loaded into the environment";u="chamber exec <service...> -- <command> [<arg...>] [flags]";f="  -h, --help                  help for exec\n      --pristine              only use variables retrieved from the backend; do not inherit existing environment variables\n      --strict                enable strict mode:\n                              only inject secrets for which there is a corresponding env var with value\n                              <strict-value>, and fail if there are any env vars with that value missing\n                              from secrets\n      --strict-value string   value to expect in --strict mode (default \"chamberme\")\n";break;case"export":d="Exports parameters in the specified format";u="chamber export <service...> [flags]";f="  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default \"json\")\n  -o, --output-file string   Output file (default is standard output)\n  -h, --help                 help for export\n";break;case"import":d="import secrets from json or yaml";u="chamber import <service> <file|-> [flags]";f="  -h, --help                           help for import\n      --normalize-keys chamber write   Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source.\n";break;case"find":d="Find the given secret across all services";u="chamber find <secret name> [flags]";f="  -v, --by-value   Find parameters by value\n  -h, --help       help for find\n";break;case"history":d="View the history of a secret";u="chamber history <service> <key> [flags]";break;default:d=c;u="chamber "+c+" [flags]";} return d+"\n\nUsage:\n  "+u+"\n\nFlags:\n"+f+"\nGlobal Flags:\n"+globalFlags(); }
    void tagHelp(PrintStream p){ p.print("work with tags on secrets\n\nUsage:\n  chamber tag [command]\n\nAvailable Commands:\n  delete      Delete tags for a specific secret\n  read        Read tags for a specific secret\n  write       Write tags for a specific secret\n\nFlags:\n  -h, --help   help for tag\n\nGlobal Flags:\n"+globalFlags()+"\nUse \"chamber tag [command] --help\" for more information about a command.\n"); }
    void tagSubHelp(String s, PrintStream p){ String d=s.equals("write")?"Write tags for a specific secret":s.equals("delete")?"Delete tags for a specific secret":"Read tags for a specific secret"; String u=s.equals("write")?"chamber tag write <service> <key> <tag>... [flags]":s.equals("delete")?"chamber tag delete <service> <key> <tag key>... [flags]":"chamber tag read <service> <key> [flags]"; String f=s.equals("write")?"      --delete-other-tags   Delete tags not specified in the command\n  -h, --help                help for write\n":"  -h, --help   help for "+s+"\n"; p.print(d+"\n\nUsage:\n  "+u+"\n\nFlags:\n"+f+"\nGlobal Flags:\n"+globalFlags()); }
    void completionHelp(PrintStream p){ p.print("Generate the autocompletion script for chamber for the specified shell.\nSee each sub-command's help for details on how to use the generated script.\n\nUsage:\n  chamber completion [command]\n\nAvailable Commands:\n  bash        Generate the autocompletion script for bash\n  fish        Generate the autocompletion script for fish\n  powershell  Generate the autocompletion script for powershell\n  zsh         Generate the autocompletion script for zsh\n\nFlags:\n  -h, --help   help for completion\n\nGlobal Flags:\n"+globalFlags()+"\nUse \"chamber completion [command] --help\" for more information about a command.\n"); }
    void completionSubHelp(String s, PrintStream p){ p.print("Generate the autocompletion script for the "+s+" shell.\n\nUsage:\n  chamber completion "+s+(s.equals("bash")?"":" [flags]")+"\n\nFlags:\n  -h, --help              help for "+s+"\n      --no-descriptions   disable completion descriptions\n\nGlobal Flags:\n"+globalFlags()); }
}
