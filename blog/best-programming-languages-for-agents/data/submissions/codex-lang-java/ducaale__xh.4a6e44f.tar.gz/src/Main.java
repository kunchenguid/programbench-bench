import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;

public class Main {
    static final String VERSION = "0.25.3";

    static class Opts {
        boolean json = true, form = false, multipart = false, offline = false, curl = false, curlLong = false;
        boolean ignoreStdin = false, headersOnly = false, bodyOnly = false, verbose = false, quiet = false;
        boolean https = false, follow = false;
        boolean explicitMethod = false;
        String print = null, raw = null, output = null, auth = null, authType = "basic", method = null, url = null;
        int timeout = 0;
        List<String> items = new ArrayList<>();
        Map<String,String> headers = new LinkedHashMap<>();
        List<String[]> queries = new ArrayList<>();
        List<String[]> fields = new ArrayList<>();
        List<String[]> literalFields = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            int code = run(args);
            System.exit(code);
        } catch (Usage e) {
            System.err.print(e.getMessage());
            System.exit(2);
        } catch (Exception e) {
            System.err.println("executable: error: " + e.getMessage());
            System.exit(1);
        }
    }

    static int run(String[] args) throws Exception {
        if (args.length == 0) throw new Usage("error: the following required arguments were not provided:\n  <[METHOD] URL>\n\nUsage: executable <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.\n");
        if (args.length == 1 && (args[0].equals("--version") || args[0].equals("-V"))) {
            System.out.println("xh " + VERSION);
            System.out.println("-native-tls +rustls");
            return 0;
        }
        if (args.length == 1 && (args[0].equals("--help") || args[0].equals("-h"))) { printHelp(false); return 0; }
        if (args.length == 1 && args[0].equals("help")) { printHelp(true); return 0; }

        Opts o = parse(args);
        parseItems(o);
        boolean stdinBody = !o.ignoreStdin && System.console() == null;
        byte[] stdin = new byte[0];
        if (stdinBody) stdin = System.in.readAllBytes();
        if (stdinBody && hasBodyItems(o)) throw new Usage("executable: error: Request body (from stdin) and request data (key=value) cannot be mixed. Pass --ignore-stdin to ignore standard input.\n");

        if (o.method == null) o.method = (stdinBody || o.raw != null || hasBodyItems(o)) ? "POST" : "GET";
        o.method = o.method.toUpperCase(Locale.ROOT);
        URI uri = normalizeUrl(o.url, o.https);
        uri = withQuery(uri, o.queries);
        byte[] body = buildBody(o, stdinBody ? stdin : null);
        LinkedHashMap<String,String> headers = defaultHeaders(o, uri, body);

        if (o.offline) {
            System.out.print(renderRequest(o.method, uri, headers, body));
            return 0;
        }
        if (o.curl || o.curlLong) {
            System.out.println(renderCurl(o, uri, body));
            return 0;
        }
        return send(o, uri, headers, body);
    }

    static Opts parse(String[] args) throws Usage {
        Opts o = new Opts();
        List<String> pos = new ArrayList<>();
        for (int i=0;i<args.length;i++) {
            String a = args[i];
            if (a.startsWith("--raw=")) { o.raw = a.substring(6); continue; }
            if (a.startsWith("--pretty=")) {
                String v = a.substring(9);
                if (!List.of("all","colors","format","none").contains(v)) throw new Usage("error: invalid value '"+v+"' for '--pretty <STYLE>'\n  [possible values: all, colors, format, none]\n\nFor more information, try '--help'.\n");
                continue;
            }
            if (a.startsWith("--print=")) { o.print = a.substring(8); continue; }
            if (a.startsWith("--output=")) { o.output = a.substring(9); continue; }
            if (a.startsWith("--auth=")) { o.auth = a.substring(7); continue; }
            if (a.startsWith("--auth-type=")) { o.authType = a.substring(12); continue; }
            if (a.startsWith("--timeout=")) { try { o.timeout = (int)Double.parseDouble(a.substring(10)); } catch(NumberFormatException e){ o.timeout=0; } continue; }
            switch (a) {
                case "-j": case "--json": o.json=true; o.form=o.multipart=false; break;
                case "-f": case "--form": o.form=true; o.json=o.multipart=false; break;
                case "--multipart": o.multipart=true; o.form=true; o.json=false; break;
                case "--offline": o.offline=true; break;
                case "--curl": o.curl=true; break;
                case "--curl-long": o.curlLong=true; o.curl=true; break;
                case "-I": case "--ignore-stdin": o.ignoreStdin=true; break;
                case "-h": case "--headers": o.headersOnly=true; o.print="h"; break;
                case "-b": case "--body": o.bodyOnly=true; o.print="b"; break;
                case "-v": case "--verbose": o.verbose=true; o.print="HhBb"; break;
                case "-q": case "--quiet": o.quiet=true; break;
                case "-V": case "--version":
                    System.out.println("xh " + VERSION);
                    System.out.println("-native-tls +rustls");
                    System.exit(0);
                    break;
                case "--https": o.https=true; break;
                case "-F": case "--follow": o.follow=true; break;
                case "--raw": o.raw = need(args, ++i, a); break;
                case "-p": case "--print": o.print = need(args, ++i, a); break;
                case "-o": case "--output": o.output = need(args, ++i, a); break;
                case "-a": case "--auth": o.auth = need(args, ++i, a); break;
                case "-A": case "--auth-type": o.authType = need(args, ++i, a); break;
                case "--timeout": try { o.timeout = (int)Double.parseDouble(need(args, ++i, a)); } catch(NumberFormatException e){ o.timeout=0; } break;
                case "--pretty": {
                    String v = need(args, ++i, a);
                    if (!List.of("all","colors","format","none").contains(v)) throw new Usage("error: invalid value '"+v+"' for '--pretty <STYLE>'\n  [possible values: all, colors, format, none]\n\nFor more information, try '--help'.\n");
                    break;
                }
                case "--generate": {
                    String v = need(args, ++i, a);
                    if (v.equals("man")) { printMan(); System.exit(0); }
                    break;
                }
                default:
                    if (a.startsWith("--no-")) break;
                    if (a.startsWith("--")) throw new Usage("error: unexpected argument '"+a+"' found\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.\n");
                    pos.add(a);
            }
        }
        if (pos.isEmpty()) throw new Usage("error: the following required arguments were not provided:\n  <[METHOD] URL>\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.\n");
        if (pos.size() == 1) {
            if (looksMethod(pos.get(0))) throw new Usage("error: Missing <URL>\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.\n");
            o.url = pos.get(0);
        } else {
            if (looksMethod(pos.get(0))) { o.method = pos.get(0); o.explicitMethod = true; o.url = pos.get(1); o.items.addAll(pos.subList(2,pos.size())); }
            else { o.url = pos.get(0); o.items.addAll(pos.subList(1,pos.size())); }
        }
        return o;
    }

    static String need(String[] args, int i, String opt) throws Usage {
        if (i >= args.length) throw new Usage("error: a value is required for '"+opt+"'\n");
        return args[i];
    }
    static boolean looksMethod(String s) { return s.matches("[A-Za-z]+") && !s.contains(".") && !s.contains(":") && !s.contains("/"); }

    static void parseItems(Opts o) throws IOException {
        for (String item: o.items) {
            int idx;
            if ((idx = unescIndex(item, "==")) >= 0) o.queries.add(new String[]{unesc(item.substring(0,idx)), readVal(unesc(item.substring(idx+2)))});
            else if ((idx = unescIndex(item, ":=")) >= 0) o.literalFields.add(new String[]{unesc(item.substring(0,idx)), readVal(unesc(item.substring(idx+2)))});
            else if ((idx = unescIndex(item, "=")) >= 0) o.fields.add(new String[]{unesc(item.substring(0,idx)), readVal(unesc(item.substring(idx+1)))});
            else if (item.endsWith(";")) o.headers.put(titleHeader(unesc(item.substring(0,item.length()-1))), "");
            else if ((idx = unescIndex(item, ":")) >= 0) o.headers.put(titleHeader(unesc(item.substring(0,idx))), readVal(unesc(item.substring(idx+1))));
        }
    }

    static int unescIndex(String s, String sep) {
        for (int i=0;i<=s.length()-sep.length();i++) if (s.startsWith(sep,i) && (i==0 || s.charAt(i-1)!='\\')) return i;
        return -1;
    }
    static String unesc(String s) { return s.replace("\\:",":").replace("\\=","=").replace("\\@","@"); }
    static String readVal(String v) throws IOException {
        if (v.startsWith("@") && v.length()>1) return Files.readString(Path.of(v.substring(1))).trim();
        return v;
    }
    static boolean hasBodyItems(Opts o) { return o.raw != null || !o.fields.isEmpty() || !o.literalFields.isEmpty(); }

    static byte[] buildBody(Opts o, byte[] stdin) {
        if (o.raw != null) return o.raw.getBytes(StandardCharsets.UTF_8);
        if (stdin != null) return stdin;
        if (!hasBodyItems(o)) return null;
        String s;
        if (o.form) {
            List<String> parts = new ArrayList<>();
            for (String[] f:o.fields) parts.add(enc(f[0])+"="+enc(f[1]));
            for (String[] f:o.literalFields) parts.add(enc(f[0])+"="+enc(f[1]));
            s = String.join("&", parts);
        } else {
            List<String> parts = new ArrayList<>();
            for (String[] f:o.fields) parts.add("\""+jsonEsc(f[0])+"\":\""+jsonEsc(f[1])+"\"");
            for (String[] f:o.literalFields) parts.add("\""+jsonEsc(f[0])+"\":"+f[1]);
            s = "{" + String.join(",", parts) + "}";
        }
        return s.getBytes(StandardCharsets.UTF_8);
    }

    static LinkedHashMap<String,String> defaultHeaders(Opts o, URI uri, byte[] body) {
        LinkedHashMap<String,String> h = new LinkedHashMap<>();
        h.put("Accept-Encoding","gzip, deflate, br, zstd");
        h.put("User-Agent","xh/"+VERSION);
        h.put("Connection","keep-alive");
        if (body != null || hasBodyItems(o) || o.raw != null) {
            if (o.form) {
                h.put("Content-Type", "application/x-www-form-urlencoded");
                h.put("Accept","*/*");
            } else {
                h.put("Accept","application/json, */*;q=0.5");
                h.put("Content-Type", "application/json");
            }
            h.put("Content-Length", String.valueOf(body == null ? 0 : body.length));
        } else h.put("Accept","*/*");
        for (var e:o.headers.entrySet()) {
            if (e.getValue().isEmpty() && !e.getKey().endsWith(";")) h.remove(e.getKey());
            h.put(e.getKey(), e.getValue());
        }
        String host = uri.getHost();
        if (uri.getPort() != -1) host += ":" + uri.getPort();
        h.put("Host", host);
        if (o.auth != null) {
            if (o.authType.equals("bearer")) h.put("Authorization", "Bearer " + o.auth);
            else h.put("Authorization", "Basic " + Base64.getEncoder().encodeToString(o.auth.getBytes(StandardCharsets.UTF_8)));
        }
        return h;
    }

    static URI normalizeUrl(String raw, boolean https) throws URISyntaxException {
        String s = raw;
        if (s.startsWith("://")) s = s.substring(3);
        if (s.startsWith(":")) s = "localhost" + s;
        if (!s.matches("^[A-Za-z][A-Za-z0-9+.-]*://.*")) s = (https ? "https://" : "http://") + s;
        URI u = new URI(s);
        String path = u.getRawPath();
        if (path == null || path.isEmpty()) path = "/";
        return new URI(u.getScheme(), u.getRawAuthority(), path, u.getRawQuery(), u.getRawFragment());
    }

    static URI withQuery(URI u, List<String[]> qs) throws URISyntaxException {
        if (qs.isEmpty()) return u;
        List<String> parts = new ArrayList<>();
        if (u.getRawQuery()!=null && !u.getRawQuery().isEmpty()) parts.add(u.getRawQuery());
        for (String[] q:qs) parts.add(enc(q[0])+"="+enc(q[1]));
        return new URI(u.getScheme(), u.getRawAuthority(), u.getRawPath(), String.join("&", parts), u.getRawFragment());
    }

    static String renderRequest(String method, URI uri, LinkedHashMap<String,String> headers, byte[] body) {
        String target = uri.getRawPath();
        if (target == null || target.isEmpty()) target = "/";
        if (uri.getRawQuery()!=null) target += "?" + uri.getRawQuery();
        StringBuilder sb = new StringBuilder();
        sb.append(method).append(" ").append(target).append(" HTTP/1.1\n");
        for (var e:headers.entrySet()) sb.append(e.getKey()).append(": ").append(e.getValue()).append("\n");
        sb.append("\n");
        if (body != null && body.length > 0) sb.append(new String(body, StandardCharsets.UTF_8)).append("\n");
        return sb.toString();
    }

    static String renderCurl(Opts o, URI uri, byte[] body) {
        List<String> p = new ArrayList<>();
        p.add("curl");
        if (o.explicitMethod || (o.method != null && !o.method.equals("GET") && !(body != null && o.method.equals("POST")))) {
            p.add(o.curlLong ? "--request" : "-X"); p.add(o.method);
        }
        p.add(shellUrl(uri.toString()));
        if (o.auth != null) {
            if (o.authType.equals("bearer")) { p.add("--oauth2-bearer"); p.add(shell(o.auth)); }
            else { p.add(o.curlLong?"--basic":"--basic"); p.add(o.curlLong?"--user":"--user"); p.add(shell(o.auth)); }
        }
        for (var e:o.headers.entrySet()) { p.add(o.curlLong?"--header":"-H"); p.add(shell(e.getKey().toLowerCase(Locale.ROOT)+": "+e.getValue())); }
        if (body != null && body.length > 0) {
            if (!o.form) {
                p.add(o.curlLong?"--header":"-H"); p.add(shell("content-type: application/json"));
                p.add(o.curlLong?"--header":"-H"); p.add(shell("accept: application/json, */*;q=0.5"));
                p.add(o.curlLong?"--data":"-d"); p.add(shell(new String(body, StandardCharsets.UTF_8)));
            } else {
                for (String[] f:o.fields) { p.add("--data-urlencode"); p.add(shell(f[0]+"="+f[1])); }
            }
        }
        return String.join(" ", p);
    }

    static int send(Opts o, URI uri, LinkedHashMap<String,String> headers, byte[] body) throws Exception {
        HttpClient client = HttpClient.newBuilder().followRedirects(o.follow ? HttpClient.Redirect.NORMAL : HttpClient.Redirect.NEVER).connectTimeout(Duration.ofSeconds(o.timeout>0?o.timeout:30)).build();
        HttpRequest.Builder b = HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(o.timeout>0?o.timeout:60));
        for (var e:headers.entrySet()) if (!e.getKey().equalsIgnoreCase("Host") && !e.getKey().equalsIgnoreCase("Content-Length") && !e.getKey().equalsIgnoreCase("Connection")) b.header(e.getKey(), e.getValue());
        b.method(o.method, body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofByteArray(body));
        if (o.verbose || (o.print != null && o.print.contains("H"))) System.out.print(renderRequest(o.method, uri, headers, body));
        HttpResponse<byte[]> r = client.send(b.build(), HttpResponse.BodyHandlers.ofByteArray());
        if (o.quiet) return statusCode(r.statusCode());
        String respHead = "HTTP/1.1 " + r.statusCode() + "\n";
        for (var e:r.headers().map().entrySet()) for (String v:e.getValue()) respHead += titleHeader(e.getKey()) + ": " + v + "\n";
        respHead += "\n";
        byte[] rb = r.body();
        String rs = new String(rb, StandardCharsets.UTF_8);
        String pr = o.print == null ? "b" : o.print;
        if (o.headersOnly) pr = "h";
        if (o.bodyOnly) pr = "b";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        if (pr.contains("h")) out.write(respHead.getBytes(StandardCharsets.UTF_8));
        if (pr.contains("b")) out.write(rs.getBytes(StandardCharsets.UTF_8));
        if (o.output != null) Files.write(Path.of(o.output), out.toByteArray()); else System.out.write(out.toByteArray());
        return statusCode(r.statusCode());
    }

    static int statusCode(int s) { if (s>=500) return 5; if (s>=400) return 4; if (s>=300) return 3; return 0; }
    static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+","%20"); }
    static String jsonEsc(String s) { return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n"); }
    static String shell(String s) { return s.matches("[A-Za-z0-9_./:=?&%-]+") ? s : "'" + s.replace("'","'\\''") + "'"; }
    static String shellUrl(String s) { return (s.contains("?") || s.contains("&")) ? "'" + s.replace("'","'\\''") + "'" : shell(s); }
    static String titleHeader(String s) {
        String[] parts = s.split("-", -1); StringBuilder b = new StringBuilder();
        for (int i=0;i<parts.length;i++) { if (i>0)b.append("-"); if(parts[i].isEmpty())continue; b.append(parts[i].substring(0,1).toUpperCase(Locale.ROOT)).append(parts[i].substring(1).toLowerCase(Locale.ROOT)); }
        return b.toString();
    }

    static void printHelp(boolean longHelp) {
        System.out.println("xh is a friendly and fast tool for sending HTTP requests" + (longHelp ? "." : ""));
        System.out.println();
        System.out.println("Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...");
        System.out.println();
        System.out.println("Arguments:\n  <[METHOD] URL>     The request URL, preceded by an optional HTTP method\n  [REQUEST_ITEM]...  Optional key-value pairs to be included in the request.");
        System.out.println();
        System.out.println("Options:\n  -j, --json\n          (default) Serialize data items from the command line as a JSON object\n  -f, --form\n          Serialize data items from the command line as form fields\n      --multipart\n          Like --form, but force a multipart/form-data request even without files\n      --raw <RAW>\n          Pass raw request data without extra processing\n      --pretty <STYLE>\n          Controls output processing [possible values: all, colors, format, none]\n  -p, --print <FORMAT>\n          String specifying what the output should contain\n  -h, --headers\n          Print only the response headers. Shortcut for --print=h\n  -b, --body\n          Print only the response body. Shortcut for --print=b\n  -v, --verbose...\n          Print the whole request as well as the response\n      --offline\n          Construct HTTP requests without sending them anywhere\n  -I, --ignore-stdin\n          Do not attempt to read stdin\n      --curl\n          Print a translation to a curl command\n      --curl-long\n          Use the long versions of curl's flags\n      --generate <KIND>\n          Generate shell completions or man pages\n      --help\n          Print help\n  -V, --version\n          Print version\n\nEach option can be reset with a --no-OPTION argument.\n\nRun \"xh help\" for more complete documentation.");
    }
    static void printMan() {
        System.out.println(".TH XH 1 2026-05-28 0.25.3 \"User Commands\"\n.SH NAME\nxh \\- Friendly and fast tool for sending HTTP requests");
    }
    static class Usage extends Exception { Usage(String m) { super(m); } }
}
