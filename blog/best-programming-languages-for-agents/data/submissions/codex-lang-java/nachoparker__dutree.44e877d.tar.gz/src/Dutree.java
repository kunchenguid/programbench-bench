import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

public class Dutree {
    static class Opts {
        int depth = Integer.MAX_VALUE;
        long aggr = 1024L * 1024L;
        boolean usage, bytes, filesOnly, noHidden, ascii, help, version;
        List<String> excludes = new ArrayList<>();
        List<String> paths = new ArrayList<>();
    }

    static class Node {
        String name;
        Path path;
        boolean dir;
        long size;
        List<Node> children = new ArrayList<>();
        Node(String name, Path path, boolean dir) { this.name = name; this.path = path; this.dir = dir; }
    }

    public static void main(String[] args) {
        Opts o;
        try { o = parse(args); }
        catch (IllegalArgumentException e) { System.err.println(e.getMessage()); System.exit(1); return; }
        if (o.help) { printHelp(); return; }
        if (o.version) { System.out.println("dutree version 0.2.18"); return; }
        if (o.paths.isEmpty()) o.paths.add(".");

        List<Node> roots = new ArrayList<>();
        for (String s : o.paths) {
            Path p = Paths.get(s);
            if (!Files.exists(p, LinkOption.NOFOLLOW_LINKS)) {
                System.err.println("path " + s + " doesn't exist");
                System.exit(1); return;
            }
            try { roots.add(scan(p, o)); }
            catch (IOException e) { System.err.println(e.getMessage()); System.exit(1); return; }
        }
        Node root;
        if (roots.size() == 1) root = roots.get(0);
        else {
            root = new Node("<collection>", null, true);
            root.children.addAll(roots);
            long sum = 0; for (Node n : roots) sum += n.size; root.size = sum;
            sort(root.children);
        }
        System.out.println("[ " + root.name + " " + fmtSize(root.size, o.bytes) + " ]");
        List<Node> shown = displayedChildren(root, o);
        long rootBase = maxSize(shown);
        for (int i = 0; i < shown.size(); i++) printNode(shown.get(i), "", i == shown.size() - 1, root.size, rootBase, 1, o);
    }

    static Opts parse(String[] args) {
        Opts o = new Opts();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-h") || a.equals("--help")) o.help = true;
            else if (a.equals("-v") || a.equals("--version")) o.version = true;
            else if (a.equals("-s") || a.equals("--summary")) { o.depth = 1; o.aggr = 1024L * 1024L; }
            else if (a.equals("-u") || a.equals("--usage")) o.usage = true;
            else if (a.equals("-b") || a.equals("--bytes")) o.bytes = true;
            else if (a.equals("-f") || a.equals("--files-only")) o.filesOnly = true;
            else if (a.equals("-H") || a.equals("--no-hidden")) o.noHidden = true;
            else if (a.equals("-A") || a.equals("--ascii")) o.ascii = true;
            else if (a.equals("-x") || a.equals("--exclude")) {
                if (i + 1 >= args.length) throw new IllegalArgumentException("missing argument for " + a);
                o.excludes.add(args[++i]);
            } else if (a.startsWith("--exclude=")) o.excludes.add(a.substring(10));
            else if (a.equals("-d") || a.equals("--depth")) {
                if (a.equals("-d") && i + 1 < args.length && isNumber(args[i + 1])) o.depth = Integer.parseInt(args[++i]);
            } else if (a.startsWith("-d") && a.length() > 2) o.depth = Integer.parseInt(a.substring(2));
            else if (a.startsWith("--depth=")) o.depth = Integer.parseInt(a.substring(8));
            else if (a.equals("-a") || a.equals("--aggr")) {
                if (i + 1 >= args.length) throw new IllegalArgumentException("missing argument for " + a);
                o.aggr = parseSize(args[++i]);
            } else if (a.startsWith("-a") && a.length() > 2) o.aggr = parseSize(a.substring(2));
            else if (a.startsWith("--aggr=")) o.aggr = parseSize(a.substring(7));
            else if (a.startsWith("-")) throw new IllegalArgumentException("unknown option " + a);
            else o.paths.add(a);
        }
        return o;
    }

    static boolean isNumber(String s) { return s.matches("[0-9]+"); }
    static long parseSize(String s) {
        if (s == null || s.isEmpty()) throw new IllegalArgumentException("invalid argument ''");
        char last = s.charAt(s.length() - 1);
        long mul = 1;
        String num = s;
        if (last == 'K' || last == 'k') { mul = 1024L; num = s.substring(0, s.length() - 1); }
        else if (last == 'M' || last == 'm') { mul = 1024L * 1024L; num = s.substring(0, s.length() - 1); }
        else if (last == 'G' || last == 'g') { mul = 1024L * 1024L * 1024L; num = s.substring(0, s.length() - 1); }
        try { return Long.parseLong(num) * mul; }
        catch (NumberFormatException e) { throw new IllegalArgumentException("invalid argument '" + s + "'"); }
    }

    static Node scan(Path p, Opts o) throws IOException {
        boolean isDir = Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS);
        Node n = new Node(displayName(p), p, isDir);
        n.size = entrySize(p, o.usage);
        if (isDir && !o.filesOnly) {
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(p)) {
                for (Path c : ds) {
                    String nm = c.getFileName().toString();
                    if (skip(nm, o)) continue;
                    try {
                        Node child = scan(c, o);
                        n.children.add(child);
                        n.size += child.size;
                    } catch (IOException ignored) { }
                }
            }
            sort(n.children);
        }
        return n;
    }

    static String displayName(Path p) {
        Path fn = p.getFileName();
        if (fn != null) return fn.toString();
        return p.toString();
    }
    static boolean skip(String nm, Opts o) {
        if (o.noHidden && nm.startsWith(".")) return true;
        for (String x : o.excludes) if (nm.equals(x)) return true;
        return false;
    }
    static long entrySize(Path p, boolean usage) throws IOException {
        if (usage) {
            Long v = statBlocks(p);
            if (v != null) return v;
        }
        return Files.readAttributes(p, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS).size();
    }
    static Long statBlocks(Path p) {
        try {
            Process pr = new ProcessBuilder("stat", "-c", "%b %B", p.toString()).redirectErrorStream(true).start();
            byte[] data = pr.getInputStream().readAllBytes();
            if (pr.waitFor() == 0) {
                String[] parts = new String(data).trim().split("\\s+");
                return Long.parseLong(parts[0]) * Long.parseLong(parts[1]);
            }
        } catch (Exception ignored) { }
        return null;
    }
    static long maxSize(List<Node> xs) {
        long m = 0;
        for (Node n : xs) if (n.size > m) m = n.size;
        return m;
    }
    static void sort(List<Node> xs) {
        xs.sort((a,b) -> {
            int c = Long.compare(b.size, a.size);
            if (c != 0) return c;
            return b.name.compareTo(a.name);
        });
    }

    static List<Node> displayedChildren(Node n, Opts o) {
        if (n.children.isEmpty()) return Collections.emptyList();
        List<Node> out = new ArrayList<>();
        long ag = 0;
        for (Node c : n.children) {
            if (c.size < o.aggr) ag += c.size;
            else out.add(c);
        }
        if (ag > 0) { Node a = new Node("<aggregated>", null, false); a.size = ag; out.add(a); }
        sort(out);
        return out;
    }

    static void printNode(Node n, String prefix, boolean last, long parentSize, long barBase, int level, Opts o) {
        String branch = last ? "└─ " : "├─ ";
        int pct = parentSize <= 0 ? 0 : (int)((n.size * 100L) / parentSize);
        System.out.println(prefix + branch + lineBody(n.name, n.size, pct, barBase, prefix.length(), o));
        if (n.children.isEmpty() || level >= o.depth) return;
        List<Node> kids = displayedChildren(n, o);
        long childBase = maxSize(kids);
        String nextPrefix = prefix + (last ? "   " : "│  ");
        for (int i = 0; i < kids.size(); i++) printNode(kids.get(i), nextPrefix, i == kids.size() - 1, n.size, childBase, level + 1, o);
    }

    static String lineBody(String name, long size, int pct, long parentSize, int prefixLen, Opts o) {
        String nm = name.length() > 22 ? name.substring(0, 22) : name;
        String bar = bar(size, parentSize, o.ascii);
        String pipe = "│";
        int nameWidth = Math.max(1, 22 - prefixLen);
        return String.format(Locale.ROOT, "%-" + nameWidth + "s %s %s%s %3d%% %13s", nm, pipe, bar, pipe, pct, fmtSize(size, o.bytes));
    }
    static String bar(long size, long parent, boolean ascii) {
        int len = parent <= 0 ? 0 : (int)((size * 32L) / parent);
        if (size > 0 && len == 0) len = 0;
        if (len > 32) len = 32;
        if (len > 0 && len < 32) len--;
        char ch = ascii ? '#' : '█';
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 32 - len; i++) sb.append(' ');
        for (int i = 0; i < len; i++) sb.append(ch);
        return sb.toString();
    }
    static String fmtSize(long b, boolean bytes) {
        if (bytes) return b + " B";
        if (b < 1024) return b + " B";
        double v = b / 1024.0;
        if (v < 1024) return String.format(Locale.ROOT, "%.2f KiB", v);
        v /= 1024.0;
        if (v < 1024) return String.format(Locale.ROOT, "%.2f MiB", v);
        v /= 1024.0;
        return String.format(Locale.ROOT, "%.2f GiB", v);
    }

    static void printHelp() {
        System.out.println("Usage: ./executable [options] <path> [<path>..]\n");
        System.out.println("Options:");
        System.out.println("    -d, --depth [DEPTH] show directories up to depth N (def 1)");
        System.out.println("    -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)");
        System.out.println("    -s, --summary       equivalent to -da, or -d1 -a1M");
        System.out.println("    -u, --usage         report real disk usage instead of file size");
        System.out.println("    -b, --bytes         print sizes in bytes");
        System.out.println("    -f, --files-only    skip directories for a fast local overview");
        System.out.println("    -x, --exclude NAME  exclude matching files or directories");
        System.out.println("    -H, --no-hidden     exclude hidden files");
        System.out.println("    -A, --ascii         ASCII characters only, no colors");
        System.out.println("    -h, --help          show help");
        System.out.println("    -v, --version       print version number");
    }
}
