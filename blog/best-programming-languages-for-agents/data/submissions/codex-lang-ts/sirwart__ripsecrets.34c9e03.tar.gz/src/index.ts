import * as fs from "fs";
import * as path from "path";
import { spawnSync } from "child_process";

type Options = {
  strictIgnore: boolean;
  onlyMatching: boolean;
  installPreCommit: boolean;
  additional: string[];
  sources: string[];
};

const VERSION = "ripsecrets 0.1.11";

const SHORT_HELP = `A command-line tool to prevent committing secret keys into your source code

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...  Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install \`ripsecrets\` as a pre-commit hook automatically in git directory provided
      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit
      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line
      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version`;

const LONG_HELP = `ripsecrets searches files and directories recursively for secret API keys.
It's primarily designed to be used as a pre-commit to prevent committing
secrets into version control.

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...
          Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install \`ripsecrets\` as a pre-commit hook automatically in git directory provided

      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit

      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line

      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const DEFAULT_PATTERN =
  String.raw`([A-Za-z]+://\S{3,50}:(\S{8,50})@[\dA-Za-z#%&+./:=?_~-]+|\beyJ[\dA-Za-z=_-]+(?:\.[\dA-Za-z=_-]{3,}){1,4}|(?:gh[oprsu]|github_pat)_[\dA-Za-z_]{36}|glpat-[\dA-Za-z_=-]{20,22}|[rs]k_live_[\dA-Za-z]{24,247}|sq0i[a-z]{2}-[\dA-Za-z_-]{22,43}|sq0c[a-z]{2}-[\dA-Za-z_-]{40,50}|EAAA[\dA-Za-z+=-]{60}|AccountKey=[\d+/=A-Za-z]{88}|AIzaSy[\dA-Za-z_-]{33}|npm_[\dA-Za-z]{36}|//.+/:_authToken=[\dA-Za-z_-]+|xox[aboprs]-(?:\d+-)+[\da-z]+|<master>\{[\dA-Za-z]+\\}</master>|https://hooks\.slack\.com/services/T[\dA-Za-z_]+/B[\dA-Za-z_]+/[\dA-Za-z_]+|SG\.[\dA-Za-z_-]{22}\.[\dA-Za-z_-]{43}|(?:AC|SK)[\da-z]{32}|[\da-f]{32}-us\d{1,2}|s-s4t2(?:af|ud)-[\da-f]{64}|PuTTY-User-Key-File-2|AGE-SECRET-KEY-1[\dA-Z]{58}|-{5}BEGIN DSA PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN EC PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN OPENSSH PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN PGP PRIVATE KEY BLOCK-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN RSA PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|-{5}BEGIN SSH2 ENCRYPTED PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)|(?:(?:key|token|secret|password)\w*["']?]?\s*(?:[:=]|:=|=>|<-|>)\s*[\t "'\`]?([\w+./=~\-\\\`^]{15,90})(?:[\t\n "'\`]|</|$)))`;

function main(): void {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed === "exit") return;
  if (!parsed) process.exit(2);

  if (parsed.installPreCommit) {
    process.exit(installPreCommit(parsed.sources[0] || "."));
  }

  const regexes: { re: RegExp; filterGroup: boolean }[] = [];
  try {
    regexes.push({ re: new RegExp(DEFAULT_PATTERN, "gi"), filterGroup: true });
    for (const p of parsed.additional) regexes.push({ re: new RegExp(p, "g"), filterGroup: true });
  } catch (e: any) {
    console.error("Error: " + (e?.message || String(e)));
    process.exit(2);
  }

  const roots = parsed.sources.length ? parsed.sources : ["."];
  const ignore = loadIgnore(process.cwd());
  let found = false;
  for (const src of roots) {
    for (const file of collect(src, ignore, parsed.strictIgnore || roots.length === 0, roots.length > 0)) {
      if (scanFile(file.path, file.display, file.size, regexes, parsed.onlyMatching, ignore.secrets)) found = true;
    }
  }
  process.exit(found ? 1 : 0);
}

function parseArgs(args: string[]): Options | "exit" | null {
  const opts: Options = { strictIgnore: false, onlyMatching: false, installPreCommit: false, additional: [], sources: [] };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-V" || a === "--version") {
      console.log(VERSION);
      return "exit";
    } else if (a === "-h") {
      console.log(SHORT_HELP);
      return "exit";
    } else if (a === "--help") {
      console.log(LONG_HELP);
      return "exit";
    } else if (a === "--strict-ignore") {
      opts.strictIgnore = true;
    } else if (a === "--only-matching") {
      opts.onlyMatching = true;
    } else if (a === "--install-pre-commit") {
      opts.installPreCommit = true;
    } else if (a === "--additional-pattern") {
      if (i + 1 >= args.length) {
        console.error("error: a value is required for '--additional-pattern <ADDITIONAL_PATTERNS>' but none was supplied");
        return null;
      }
      opts.additional.push(args[++i]);
    } else if (a.startsWith("--additional-pattern=")) {
      opts.additional.push(a.slice("--additional-pattern=".length));
    } else if (a.startsWith("-")) {
      console.error(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [Source files]...\n\nFor more information, try '--help'.`);
      return null;
    } else {
      opts.sources.push(a);
    }
  }
  return opts;
}

function installPreCommit(src: string): number {
  let repo = src;
  const res = spawnSync("git", ["-C", src, "rev-parse", "--git-dir"], { encoding: "utf8" });
  if (res.status !== 0) {
    console.error("Error: .git directory not found");
    return 2;
  }
  repo = path.resolve(src, res.stdout.trim());
  fs.mkdirSync(path.join(repo, "hooks"), { recursive: true });
  const hook = path.join(repo, "hooks", "pre-commit");
  fs.writeFileSync(hook, "ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n");
  fs.chmodSync(hook, 0o744);
  return 0;
}

type IgnoreData = { patterns: string[]; secrets: Set<string> };

function loadIgnore(cwd: string): IgnoreData {
  const out: IgnoreData = { patterns: [], secrets: new Set() };
  const file = path.join(cwd, ".secretsignore");
  if (!fs.existsSync(file)) return out;
  let inSecrets = false;
  for (const raw of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    if (line === "[secrets]") {
      inSecrets = true;
      continue;
    }
    if (inSecrets) out.secrets.add(line);
    else out.patterns.push(line);
  }
  return out;
}

function isIgnored(display: string, ignore: IgnoreData): boolean {
  const p = display.replace(/^\.\//, "");
  for (const pat of ignore.patterns) {
    if (pat.endsWith("/")) {
      const d = pat.slice(0, -1);
      if (p === d || p.startsWith(d + "/")) return true;
    } else if (pat.startsWith("*.")) {
      if (p.endsWith(pat.slice(1))) return true;
    } else if (!pat.includes("/")) {
      if (path.basename(p) === pat) return true;
    } else if (p === pat || p.startsWith(pat + "/")) {
      return true;
    }
  }
  return false;
}

type FileEntry = { path: string; display: string; size: number };

function collect(src: string, ignore: IgnoreData, strict: boolean, explicit: boolean): FileEntry[] {
  const results: FileEntry[] = [];
  let st: any;
  try {
    st = fs.lstatSync(src);
  } catch (e: any) {
    console.error(`${src}: ${e.code === "ENOENT" ? "No such file or directory" : e.message} (os error ${e.errno ? Math.abs(e.errno) : 2})`);
    return results;
  }
  const walk = (p: string, disp: string, isRoot: boolean) => {
    const bypassRootIgnore = explicit && isRoot && !strict;
    if (!bypassRootIgnore && isIgnored(disp, ignore)) return;
    let s: any;
    try {
      s = fs.lstatSync(p);
    } catch {
      return;
    }
    if (s.isSymbolicLink()) return;
    if (s.isDirectory()) {
      let entries: string[] = [];
      try {
        entries = fs.readdirSync(p).sort();
      } catch (e: any) {
        console.error(`${disp}: ${e.message}`);
        return;
      }
      for (const ent of entries) {
        if (ent === ".git") continue;
        const childDisplay = disp === "." ? `./${ent}` : `${disp.replace(/\/$/, "")}/${ent}`;
        walk(path.join(p, ent), childDisplay, false);
      }
    } else if (s.isFile()) {
      results.push({ path: p, display: disp, size: s.size });
    }
  };
  if (st.isDirectory()) {
    walk(src, normalizeDisplay(src), true);
  } else {
    if (!strict || !isIgnored(normalizeDisplay(src), ignore)) results.push({ path: src, display: normalizeDisplay(src), size: st.size });
  }
  return results;
}

function normalizeDisplay(p: string): string {
  return p.split(path.sep).join("/");
}

function scanFile(file: string, display: string, initialSize: number, regexes: { re: RegExp; filterGroup: boolean }[], only: boolean, ignoredSecrets: Set<string>): boolean {
  let text: string;
  try {
    if (initialSize === 0) return false;
    const buf = fs.readFileSync(file);
    if (buf.includes(0)) return false;
    text = buf.toString("utf8");
  } catch (e: any) {
    console.error(`${display}: ${e.code === "EACCES" ? "Permission denied" : e.message} (os error ${e.errno ? Math.abs(e.errno) : 13})`);
    return false;
  }
  let found = false;
  const lines = text.split(/\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].replace(/\r$/, "");
    let lineFound = false;
    for (const { re, filterGroup } of regexes) {
      re.lastIndex = 0;
      let m: RegExpExecArray | null;
      while ((m = re.exec(line)) !== null) {
        const group = firstGroup(m);
        const value = group || m[0];
        if (group && filterGroup && !isRandomEnough(value)) continue;
        if (ignoredSecrets.has(value)) continue;
        console.log(`${display}:${i + 1}:${only ? value : line}`);
        found = true;
        lineFound = true;
        break;
      }
      if (lineFound && !only) break;
    }
  }
  return found;
}

function firstGroup(m: RegExpExecArray): string | undefined {
  let wholeMatchGroup: string | undefined;
  for (let i = 1; i < m.length; i++) {
    if (!m[i]) continue;
    if (m[i] === m[0]) wholeMatchGroup = m[i];
    else return m[i];
  }
  if (m.length === 2) return wholeMatchGroup;
  return undefined;
}

function isRandomEnough(s: string): boolean {
  if (s.length < 15) return false;
  const unique = new Set(s).size;
  const hasDigit = /\d/.test(s);
  const hasUpper = /[A-Z]/.test(s);
  const hasLower = /[a-z]/.test(s);
  const hasSymbol = /[+./=~_\-\\`^]/.test(s);
  if (!(hasDigit || hasUpper || hasSymbol)) return false;
  if (unique < 8) return false;
  return entropy(s) >= 2.8;
}

function entropy(s: string): number {
  const counts = new Map<string, number>();
  for (const ch of s) counts.set(ch, (counts.get(ch) || 0) + 1);
  let e = 0;
  for (const n of counts.values()) {
    const p = n / s.length;
    e -= p * Math.log2(p);
  }
  return e;
}

main();
