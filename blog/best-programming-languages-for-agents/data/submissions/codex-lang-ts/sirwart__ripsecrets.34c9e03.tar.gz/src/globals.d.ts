declare const require: any;
declare const process: any;
declare module "fs" {
  const value: any;
  export = value;
}
declare module "path" {
  const value: any;
  export = value;
}
declare module "child_process" {
  export const spawnSync: any;
}
