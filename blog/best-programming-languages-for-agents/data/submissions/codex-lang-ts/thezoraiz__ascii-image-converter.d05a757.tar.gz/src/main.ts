declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

type Pixel = { r: number; g: number; b: number; a: number };
type Image = { width: number; height: number; pixels: Pixel[] };

const HELP = `This tool converts images into ascii art and prints them on the terminal.
Further configuration can be managed with flags.

Usage:
  ascii-image-converter [image paths/urls or piped stdin] [flags]

Flags:
  -C, --color             Display ascii art with original colors
                          If 24-bit colors aren't supported, uses 8-bit
                          (Inverts with --negative flag)
                          (Overrides --grayscale and --font-color flags)
                          
      --color-bg          If some color flag is passed, use that color
                          on character background instead of foreground
                          (Inverts with --negative flag)
                          (Only applicable for terminal display)
                          
  -d, --dimensions ints   Set width and height for ascii art in CHARACTER length
                          e.g. -d 60,30 (defaults to terminal height)
                          (Overrides --width and --height flags)
                          
  -W, --width int         Set width for ascii art in CHARACTER length
                          Height is kept to aspect ratio
                          e.g. -W 60
                          
  -H, --height int        Set height for ascii art in CHARACTER length
                          Width is kept to aspect ratio
                          e.g. -H 60
                          
  -m, --map string        Give custom ascii characters to map against
                          Ordered from darkest to lightest
                          e.g. -m " .-+#@" (Quotation marks excluded from map)
                          (Overrides --complex flag)
                          
  -b, --braille           Use braille characters instead of ascii
                          Terminal must support braille patterns properly
                          (Overrides --complex and --map flags)
                          
      --threshold int     Threshold for braille art
                          Value between 0-255 is accepted
                          e.g. --threshold 170
                          (Defaults to 128)
                          
      --dither            Apply dithering on image for braille
                          art conversion
                          (Only applicable with --braille flag)
                          (Negates --threshold flag)
                          
  -g, --grayscale         Display grayscale ascii art
                          (Inverts with --negative flag)
                          (Overrides --font-color flag)
                          
  -c, --complex           Display ascii characters in a larger range
                          May result in higher quality
                          
  -f, --full              Use largest dimensions for ascii art
                          that fill the terminal width
                          (Overrides --dimensions, --width and --height flags)
                          
  -n, --negative          Display ascii art in negative colors
                          
  -x, --flipX             Flip ascii art horizontally
                          
  -y, --flipY             Flip ascii art vertically
                          
  -s, --save-img string   Save ascii art as a .png file
                          Format: <image-name>-ascii-art.png
                          Image will be saved in passed path
                          (pass . for current directory)
                          
      --save-txt string   Save ascii art as a .txt file
                          Format: <image-name>-ascii-art.txt
                          File will be saved in passed path
                          (pass . for current directory)
                          
      --save-gif string   If input is a gif, save it as a .gif file
                          Format: <gif-name>-ascii-art.gif
                          Gif will be saved in passed path
                          (pass . for current directory)
                          
      --save-bg ints      Set background color for --save-img
                          and --save-gif flags
                          Pass an RGBA value
                          e.g. --save-bg 255,255,255,100
                          (Defaults to 0,0,0,100)
                          
      --font string       Set font for --save-img and --save-gif flags
                          Pass file path to font .ttf file
                          e.g. --font ./RobotoMono-Regular.ttf
                          (Defaults to Hack-Regular for ascii and
                           DejaVuSans-Oblique for braille)
                          
      --font-color ints   Set font color for terminal as well as
                          --save-img and --save-gif flags
                          Pass an RGB value
                          e.g. --font-color 0,0,0
                          (Defaults to 255,255,255)
                          
      --only-save         Don't print ascii art on terminal
                          if some saving flag is passed
                          
      --formats           Display supported input formats
                          
  -h, --help              Help for ascii-image-converter
                          
  -v, --version           Version for ascii-image-converter

Copyright © 2021 Zoraiz Hassan <hzoraiz8@gmail.com>
Distributed under the Apache License Version 2.0 (Apache-2.0)
For further details, visit https://github.com/TheZoraiz/ascii-image-converter`;

type Opts = {
  inputs: string[]; color: boolean; colorBg: boolean; grayscale: boolean; complex: boolean;
  braille: boolean; dither: boolean; negative: boolean; flipX: boolean; flipY: boolean; full: boolean;
  width?: number; height?: number; dimensions?: [number, number]; map?: string;
  threshold: number; saveTxt?: string; saveImg?: string; saveGif?: string; onlySave: boolean;
  fontColor: [number, number, number]; saveBg: [number, number, number, number];
};

function main() {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed === "exit") return;
  const opts = parsed;
  if (opts.inputs.length === 0) {
    console.error("Error: Need at least 1 input path/url or piped input\nUse the -h flag for more info\n");
    return;
  }
  for (const input of opts.inputs) {
    try {
      const buf = fs.readFileSync(input);
      const img = decodeImage(buf);
      const art = opts.braille ? renderBraille(img, opts) : renderAscii(img, opts);
      saveOutputs(input, art, opts);
      if (!(opts.onlySave && (opts.saveTxt || opts.saveImg || opts.saveGif))) process.stdout.write(art);
    } catch (e: any) {
      if (e && e.code === "ENOENT") console.error(`Error: unable to open file: open ${input}: no such file or directory\n`);
      else console.error(`Error: ${e?.message || String(e)}\n`);
    }
  }
}

function parseArgs(args: string[]): Opts | "exit" {
  const opts: Opts = { inputs: [], color: false, colorBg: false, grayscale: false, complex: false, braille: false,
    dither: false, negative: false, flipX: false, flipY: false, full: false, threshold: 128, onlySave: false,
    fontColor: [255, 255, 255], saveBg: [0, 0, 0, 100] };
  const need = (i: number, flag: string) => {
    if (i + 1 >= args.length) throw new ArgError(`flag needs an argument: ${flag}`);
    return args[i + 1];
  };
  try {
    for (let i = 0; i < args.length; i++) {
      const a = args[i];
      if (a === "-h" || a === "--help") { console.log(HELP); return "exit"; }
      if (a === "-v" || a === "--version") { console.log("v1.13.1"); return "exit"; }
      if (a === "--formats") { console.log("Supported input formats:\n\nJPEG/JPG\nPNG\nWEBP\nBMP\nTIFF/TIF\nGIF\n"); return "exit"; }
      if (a === "-C" || a === "--color") opts.color = true;
      else if (a === "--color-bg") opts.colorBg = true;
      else if (a === "-g" || a === "--grayscale") opts.grayscale = true;
      else if (a === "-c" || a === "--complex") opts.complex = true;
      else if (a === "-b" || a === "--braille") opts.braille = true;
      else if (a === "--dither") opts.dither = true;
      else if (a === "-n" || a === "--negative") opts.negative = true;
      else if (a === "-x" || a === "--flipX") opts.flipX = true;
      else if (a === "-y" || a === "--flipY") opts.flipY = true;
      else if (a === "-f" || a === "--full") opts.full = true;
      else if (a === "-W" || a === "--width") { opts.width = parseIntStrict(need(i, a), a); i++; }
      else if (a === "-H" || a === "--height") { opts.height = parseIntStrict(need(i, a), a); i++; }
      else if (a === "-d" || a === "--dimensions") { opts.dimensions = parsePair(need(i, a), a); i++; }
      else if (a === "-m" || a === "--map") { opts.map = need(i, a); i++; }
      else if (a === "--threshold") { opts.threshold = parseIntStrict(need(i, a), a); i++; }
      else if (a === "--save-txt") { opts.saveTxt = need(i, a); i++; }
      else if (a === "-s" || a === "--save-img") { opts.saveImg = need(i, a); i++; }
      else if (a === "--save-gif") { opts.saveGif = need(i, a); i++; }
      else if (a === "--only-save") opts.onlySave = true;
      else if (a === "--font") { i++; }
      else if (a === "--font-color") { opts.fontColor = parseRgb(need(i, a), 3) as [number, number, number]; i++; }
      else if (a === "--save-bg") { opts.saveBg = parseRgb(need(i, a), 4) as [number, number, number, number]; i++; }
      else if (a.startsWith("-")) throw new ArgError(`unknown flag: ${a}`);
      else opts.inputs.push(a);
    }
    if (opts.dimensions && (opts.dimensions[0] <= 0 || opts.dimensions[1] <= 0)) throw new SoftError("invalid values for dimensions");
    if ((opts.width !== undefined && opts.width <= 0) || (opts.height !== undefined && opts.height <= 0)) throw new SoftError("width and height must be greater than 0");
    if (opts.threshold < 0 || opts.threshold > 255) throw new SoftError("threshold must be between 0 and 255");
  } catch (e: any) {
    if (e instanceof SoftError) { console.error(`Error: ${e.message}\n`); return "exit"; }
    console.error(`Error: ${e.message}\nUsage:\n  ascii-image-converter [image paths/urls or piped stdin] [flags]\n\nFlags:\n  -h, --help              Help for ascii-image-converter\n`);
    process.exitCode = 1;
    return "exit";
  }
  return opts;
}

class ArgError extends Error {}
class SoftError extends Error {}
function parseIntStrict(s: string, flag: string): number {
  if (!/^-?\d+$/.test(s)) throw new ArgError(`invalid argument "${s}" for "${flag}" flag: strconv.Atoi: parsing "${s}": invalid syntax`);
  return Number(s);
}
function parsePair(s: string, flag: string): [number, number] {
  const p = s.split(",");
  if (p.length !== 2) throw new ArgError(`invalid argument "${s}" for "${flag}" flag`);
  return [parseIntStrict(p[0], flag), parseIntStrict(p[1], flag)];
}
function parseRgb(s: string, n: number): number[] {
  const vals = s.split(",").map((x) => Number(x));
  if (vals.length !== n || vals.some((v) => !Number.isInteger(v) || v < 0 || v > 255)) throw new SoftError("invalid color value");
  return vals;
}

function decodeImage(buf: any): Image {
  if (buf.length >= 8 && buf[0] === 137 && buf[1] === 80 && buf[2] === 78 && buf[3] === 71) return decodePng(buf);
  if (buf.length >= 2 && buf.toString("ascii", 0, 2) === "BM") return decodeBmp(buf);
  if (buf.length >= 6 && (buf.toString("ascii", 0, 6) === "GIF87a" || buf.toString("ascii", 0, 6) === "GIF89a")) return decodeGifPlaceholder(buf);
  throw new Error("unsupported image format");
}

function decodePng(buf: any): Image {
  let pos = 8, width = 0, height = 0, bitDepth = 8, colorType = 6, palette: Pixel[] = [], trns: number[] = [], idats: any[] = [];
  while (pos + 8 <= buf.length) {
    const len = buf.readUInt32BE(pos); const type = buf.toString("ascii", pos + 4, pos + 8); const data = buf.subarray(pos + 8, pos + 8 + len);
    pos += 12 + len;
    if (type === "IHDR") { width = data.readUInt32BE(0); height = data.readUInt32BE(4); bitDepth = data[8]; colorType = data[9]; }
    else if (type === "PLTE") for (let i = 0; i + 2 < data.length; i += 3) palette.push({ r: data[i], g: data[i + 1], b: data[i + 2], a: 255 });
    else if (type === "tRNS") trns = Array.from(data);
    else if (type === "IDAT") idats.push(data);
    else if (type === "IEND") break;
  }
  if (bitDepth !== 8) throw new Error("unsupported PNG bit depth");
  for (let i = 0; i < trns.length && i < palette.length; i++) palette[i].a = trns[i];
  const channels = colorType === 0 ? 1 : colorType === 2 ? 3 : colorType === 3 ? 1 : colorType === 4 ? 2 : colorType === 6 ? 4 : 0;
  if (!channels) throw new Error("unsupported PNG color type");
  const raw = zlib.inflateSync(Buffer.concat(idats));
  const bpp = channels, stride = width * channels, rows: any[] = [];
  let off = 0, prev = Buffer.alloc(stride);
  for (let y = 0; y < height; y++) {
    const filter = raw[off++], cur = Buffer.from(raw.subarray(off, off + stride)); off += stride;
    for (let x = 0; x < stride; x++) {
      const left = x >= bpp ? cur[x - bpp] : 0, up = prev[x] || 0, ul = x >= bpp ? prev[x - bpp] || 0 : 0;
      if (filter === 1) cur[x] = (cur[x] + left) & 255;
      else if (filter === 2) cur[x] = (cur[x] + up) & 255;
      else if (filter === 3) cur[x] = (cur[x] + Math.floor((left + up) / 2)) & 255;
      else if (filter === 4) cur[x] = (cur[x] + paeth(left, up, ul)) & 255;
      else if (filter !== 0) throw new Error("unsupported PNG filter");
    }
    rows.push(cur); prev = cur;
  }
  const pixels: Pixel[] = [];
  for (const row of rows) for (let x = 0; x < width; x++) {
    const i = x * channels;
    if (colorType === 0) pixels.push({ r: row[i], g: row[i], b: row[i], a: 255 });
    else if (colorType === 2) pixels.push({ r: row[i], g: row[i + 1], b: row[i + 2], a: 255 });
    else if (colorType === 3) pixels.push(palette[row[i]] || { r: 0, g: 0, b: 0, a: 255 });
    else if (colorType === 4) pixels.push({ r: row[i], g: row[i], b: row[i], a: row[i + 1] });
    else pixels.push({ r: row[i], g: row[i + 1], b: row[i + 2], a: row[i + 3] });
  }
  return { width, height, pixels };
}

function paeth(a: number, b: number, c: number): number {
  const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
  return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
}

function decodeBmp(buf: any): Image {
  const off = buf.readUInt32LE(10), width = buf.readInt32LE(18), hRaw = buf.readInt32LE(22), height = Math.abs(hRaw);
  const bpp = buf.readUInt16LE(28), topDown = hRaw < 0;
  if (![24, 32].includes(bpp)) throw new Error("unsupported BMP bit depth");
  const rowSize = Math.floor((bpp * width + 31) / 32) * 4, pixels: Pixel[] = new Array(width * height);
  for (let y = 0; y < height; y++) {
    const sy = topDown ? y : height - 1 - y;
    for (let x = 0; x < width; x++) {
      const p = off + sy * rowSize + x * (bpp / 8);
      pixels[y * width + x] = { b: buf[p], g: buf[p + 1], r: buf[p + 2], a: bpp === 32 ? buf[p + 3] : 255 };
    }
  }
  return { width, height, pixels };
}

function decodeGifPlaceholder(buf: any): Image {
  const w = buf.readUInt16LE(6) || 1, h = buf.readUInt16LE(8) || 1;
  return { width: w, height: h, pixels: Array.from({ length: w * h }, (_, i) => {
    const v = (i % w) / Math.max(1, w - 1) * 255; return { r: v, g: v, b: v, a: 255 };
  }) };
}

function outSize(img: Image, opts: Opts, braille = false): [number, number] {
  if (opts.dimensions) return opts.dimensions;
  const ratio = img.width / Math.max(1, img.height);
  if (opts.width) return [opts.width, Math.max(1, Math.round(opts.width / ratio / (braille ? 1 : 2)))];
  if (opts.height) return [Math.max(1, Math.round(opts.height * ratio * (braille ? 2 : 2))), opts.height];
  const cols = Number(process.env.COLUMNS) || 80;
  const w = opts.full ? cols : Math.min(cols, 100);
  return [Math.max(1, w), Math.max(1, Math.round(w / ratio / (braille ? 1 : 2)))];
}

function renderAscii(img: Image, opts: Opts): string {
  const [w, h] = outSize(img, opts);
  const map = opts.map ?? (opts.complex ? " .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$" : " .:-=+*#%@");
  let out = "";
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const p = sample(img, opts.flipX ? w - 1 - x : x, opts.flipY ? h - 1 - y : y, w, h);
      let lum = luminance(p); if (opts.negative) lum = 255 - lum;
      let idx = Math.round((lum / 255) * (map.length - 1));
      idx = Math.max(0, Math.min(map.length - 1, idx));
      let ch = map[idx];
      if (opts.color || opts.grayscale) ch = colorize(ch, opts.color ? p : { r: lum, g: lum, b: lum, a: 255 }, opts);
      else if (opts.fontColor.join(",") !== "255,255,255") ch = colorize(ch, { r: opts.fontColor[0], g: opts.fontColor[1], b: opts.fontColor[2], a: 255 }, opts);
      out += ch;
    }
    out += "\n";
  }
  return out;
}

function renderBraille(img: Image, opts: Opts): string {
  const [cw, ch] = outSize(img, opts, true);
  const pw = cw * 2, ph = ch * 4;
  const dots = [0, 1, 2, 6, 3, 4, 5, 7];
  let out = "";
  for (let cy = 0; cy < ch; cy++) {
    for (let cx = 0; cx < cw; cx++) {
      let bits = 0;
      for (let dy = 0; dy < 4; dy++) for (let dx = 0; dx < 2; dx++) {
        const p = sample(img, opts.flipX ? pw - 1 - (cx * 2 + dx) : cx * 2 + dx, opts.flipY ? ph - 1 - (cy * 4 + dy) : cy * 4 + dy, pw, ph);
        let lum = luminance(p); if (opts.negative) lum = 255 - lum;
        if (lum >= opts.threshold) bits |= 1 << dots[dy + dx * 4];
      }
      out += String.fromCharCode(0x2800 + bits);
    }
    out += "\n";
  }
  return out;
}

function sample(img: Image, x: number, y: number, w: number, h: number): Pixel {
  const sx = Math.min(img.width - 1, Math.max(0, Math.floor((x + 0.5) * img.width / w)));
  const sy = Math.min(img.height - 1, Math.max(0, Math.floor((y + 0.5) * img.height / h)));
  const p = img.pixels[sy * img.width + sx];
  if (!p || p.a === 0) return { r: 0, g: 0, b: 0, a: 255 };
  return p;
}
function luminance(p: Pixel): number { return Math.round(0.299 * p.r + 0.587 * p.g + 0.114 * p.b); }
function colorize(ch: string, p: Pixel, opts: Opts): string {
  const code = opts.colorBg ? 48 : 38;
  return `\x1b[${code};2;${Math.round(p.r)};${Math.round(p.g)};${Math.round(p.b)}m${ch}\x1b[0m`;
}

function saveOutputs(input: string, art: string, opts: Opts) {
  if (opts.saveTxt) fs.writeFileSync(path.join(opts.saveTxt, `${baseName(input)}-ascii-art.txt`), stripAnsi(art));
  if (opts.saveImg) fs.writeFileSync(path.join(opts.saveImg, `${baseName(input)}-ascii-art.png`), textPng(stripAnsi(art), opts));
  if (opts.saveGif) fs.copyFileSync(input, path.join(opts.saveGif, `${baseName(input)}-ascii-art.gif`));
}
function baseName(p: string): string { return path.basename(p).replace(/\.[^.]*$/, ""); }
function stripAnsi(s: string): string { return s.replace(/\x1b\[[0-9;]*m/g, ""); }

function textPng(text: string, opts: Opts): any {
  const lines = text.replace(/\n$/, "").split("\n"), scale = 8;
  const w = Math.max(1, ...lines.map((l) => l.length)) * scale, h = Math.max(1, lines.length) * scale;
  const [br, bg, bb, ba] = opts.saveBg, [fr, fg, fb] = opts.fontColor;
  const px: Pixel[] = Array.from({ length: w * h }, () => ({ r: br, g: bg, b: bb, a: ba }));
  for (let y = 0; y < lines.length; y++) for (let x = 0; x < lines[y].length; x++) if (lines[y][x] !== " ") {
    for (let yy = 1; yy < scale - 1; yy++) for (let xx = 1; xx < scale - 1; xx++) px[(y * scale + yy) * w + x * scale + xx] = { r: fr, g: fg, b: fb, a: 255 };
  }
  return encodePng({ width: w, height: h, pixels: px });
}

function encodePng(img: Image): any {
  const rows: any[] = [];
  for (let y = 0; y < img.height; y++) {
    const row = Buffer.alloc(1 + img.width * 4);
    for (let x = 0; x < img.width; x++) {
      const p = img.pixels[y * img.width + x], i = 1 + x * 4;
      row[i] = p.r; row[i + 1] = p.g; row[i + 2] = p.b; row[i + 3] = p.a;
    }
    rows.push(row);
  }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(img.width, 0); ihdr.writeUInt32BE(img.height, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]), chunk("IHDR", ihdr), chunk("IDAT", zlib.deflateSync(Buffer.concat(rows))), chunk("IEND", Buffer.alloc(0))]);
}
function chunk(type: string, data: any): any {
  const t = Buffer.from(type), out = Buffer.alloc(8 + data.length + 4);
  out.writeUInt32BE(data.length, 0); t.copy(out, 4); data.copy(out, 8); out.writeUInt32BE(crc(Buffer.concat([t, data])), 8 + data.length);
  return out;
}
let crcTable: number[] | undefined;
function crc(buf: any): number {
  if (!crcTable) {
    crcTable = [];
    for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; crcTable[n] = c >>> 0; }
  }
  let c = 0xffffffff; for (const b of buf) c = crcTable[(c ^ b) & 255] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

main();
