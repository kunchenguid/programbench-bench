import * as fs from "fs";
import * as path from "path";
import { spawnSync } from "child_process";

type RetInfo = { errors: boolean[]; sig: string };
type FuncKey = string;
type Pkg = {
  ImportPath: string;
  Dir: string;
  GoFiles?: string[];
  CgoFiles?: string[];
  TestGoFiles?: string[];
  XTestGoFiles?: string[];
  IgnoredGoFiles?: string[];
  DepOnly?: boolean;
  Name?: string;
  Error?: { Err?: string };
};

type Options = {
  asserts: boolean;
  blank: boolean;
  abspath: boolean;
  exclude?: string;
  excludeonly: boolean;
  ignoregenerated: boolean;
  ignoretests: boolean;
  ignorepkg: Set<string>;
  ignore: { pkg: string; re: RegExp }[];
  mod?: string;
  tags: string[];
  verbose: boolean;
};

const usage = `Usage of ./executable:
  -abspath
    \tprint absolute paths to files
  -asserts
    \tif true, check for ignored type assertion results
  -blank
    \tif true, check for errors assigned to blank identifier
  -exclude string
    \tPath to a file containing a list of functions to exclude from checking
  -excludeonly
    \tUse only excludes from -exclude file
  -ignore value
    \t[deprecated] comma-separated list of pairs of the form pkg:regex
    \t            the regex is used to ignore names within pkg.
  -ignoregenerated
    \tif true, checking of files with generated code is disabled
  -ignorepkg string
    \tcomma-separated list of package paths to ignore
  -ignoretests
    \tif true, checking of _test.go files is disabled
  -mod string
    \tmodule download mode to use: readonly or vendor. See 'go help modules' for more.
  -tags value
    \tcomma or space-separated list of build tags to include
  -verbose
    \tproduce more verbose logging
`;

function dieFlag(msg: string): void {
  process.stderr.write(msg + "\n" + usage);
  process.exit(2);
}

function parseArgs(argv: string[]): { opts: Options; pkgs: string[] } {
  const opts: Options = {
    asserts: false, blank: false, abspath: false, excludeonly: false,
    ignoregenerated: false, ignoretests: false, ignorepkg: new Set(),
    ignore: [], tags: [], verbose: false,
  };
  const pkgs: string[] = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "-help" || a === "--help") {
      process.stdout.write(usage);
      process.exit(0);
    }
    if (!a.startsWith("-") || a === "-") {
      pkgs.push(a);
      continue;
    }
    const [flag, inline] = a.includes("=") ? a.split(/=(.*)/s, 2) : [a, undefined];
    const name = flag.replace(/^-+/, "");
    const bools = new Set(["asserts", "blank", "abspath", "excludeonly", "ignoregenerated", "ignoretests", "verbose"]);
    const strings = new Set(["exclude", "ignorepkg", "mod", "tags", "ignore"]);
    if (bools.has(name)) {
      const val = inline;
      (opts as any)[name] = val == null ? true : val !== "false";
    } else if (strings.has(name)) {
      let val = inline;
      if (val == null) {
        i++;
        if (i >= argv.length) dieFlag(`flag needs an argument: -${name}`);
        val = argv[i];
      }
      if (name === "ignorepkg") {
        for (const p of val.split(",").map(s => s.trim()).filter(Boolean)) opts.ignorepkg.add(p);
      } else if (name === "tags") {
        opts.tags.push(...val.split(/[,\s]+/).filter(Boolean));
      } else if (name === "ignore") {
        parseIgnore(val, opts);
      } else {
        (opts as any)[name] = val;
      }
    } else {
      dieFlag(`flag provided but not defined: -${name}`);
    }
  }
  if (pkgs.length === 0) pkgs.push(".");
  return { opts, pkgs };
}

function parseIgnore(s: string, opts: Options) {
  for (const part of s.split(",").filter(Boolean)) {
    const idx = part.indexOf(":");
    const pkg = idx >= 0 ? part.slice(0, idx) : "";
    const pat = idx >= 0 ? part.slice(idx + 1) : part;
    try { opts.ignore.push({ pkg, re: new RegExp(pat) }); } catch {}
  }
}

function goEnv(): NodeJS.ProcessEnv {
  const env = { ...process.env };
  const candidates = [
    "/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.22.0.linux-amd64/bin",
    "/usr/local/go/bin",
  ];
  const extra = candidates.filter(d => fs.existsSync(path.join(d, "go")));
  env.PATH = [...extra, env.PATH || ""].join(":");
  return env;
}

function runGoList(pkgs: string[], opts: Options): Pkg[] {
  const args = ["list", "-json", "-deps"];
  if (opts.mod) args.push("-mod", opts.mod);
  if (opts.tags.length) args.push("-tags", opts.tags.join(","));
  args.push(...pkgs);
  const r = spawnSync("go", args, { encoding: "utf8", env: goEnv(), cwd: process.cwd(), maxBuffer: 64 * 1024 * 1024 });
  if (r.status !== 0) {
    process.stderr.write(`error: failed to check packages: err: ${r.error ? r.error.message : `exit status ${r.status}`}: stderr: ${r.stderr || ""}\n`);
    process.exit(2);
  }
  const objs = parseJSONStream(r.stdout);
  const bad = objs.find(p => p.Error);
  if (bad) {
    process.stderr.write(`error: failed to check packages: ${bad.Error?.Err || "package error"}\n`);
    process.exit(2);
  }
  return objs;
}

function parseJSONStream(s: string): Pkg[] {
  const out: Pkg[] = [];
  let depth = 0, start = -1, inStr = false, esc = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (inStr) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === "\"") inStr = false;
    } else if (ch === "\"") inStr = true;
    else if (ch === "{") { if (depth++ === 0) start = i; }
    else if (ch === "}" && --depth === 0 && start >= 0) out.push(JSON.parse(s.slice(start, i + 1)));
  }
  return out;
}

function removeComments(s: string): string {
  return s.replace(/\/\*[\s\S]*?\*\//g, m => "\n".repeat((m.match(/\n/g) || []).length))
          .replace(/\/\/.*$/gm, "");
}

function splitTop(s: string): string[] {
  const out: string[] = [];
  let depth = 0, start = 0, str = "";
  for (let i = 0; i < s.length; i++) {
    const ch = s[i], prev = s[i - 1];
    if (str) { if (ch === str && prev !== "\\") str = ""; continue; }
    if (ch === "\"" || ch === "`" || ch === "'") { str = ch; continue; }
    if (ch === "(" || ch === "[" || ch === "{") depth++;
    else if (ch === ")" || ch === "]" || ch === "}") depth--;
    else if (ch === "," && depth === 0) { out.push(s.slice(start, i).trim()); start = i + 1; }
  }
  out.push(s.slice(start).trim());
  return out.filter(Boolean);
}

function parseReturns(sigTail: string): boolean[] {
  let t = sigTail.trim();
  if (!t) return [];
  if (t.startsWith("(")) {
    const end = matching(t, 0, "(", ")");
    if (end < 0) return [];
    t = t.slice(1, end);
    return splitTop(t).map(part => /\berror\b/.test(part));
  }
  const first = t.split(/\s+/)[0];
  return [first === "error" || /\berror\b/.test(t)];
}

function matching(s: string, pos: number, open: string, close: string): number {
  let d = 0, str = "";
  for (let i = pos; i < s.length; i++) {
    const ch = s[i], prev = s[i - 1];
    if (str) { if (ch === str && prev !== "\\") str = ""; continue; }
    if (ch === "\"" || ch === "`" || ch === "'") { str = ch; continue; }
    if (ch === open) d++;
    else if (ch === close && --d === 0) return i;
  }
  return -1;
}

function receiverType(recv: string): string {
  return recv.replace(/[()]/g, " ").replace(/\*/g, "").trim().split(/\s+/).pop() || "";
}

function parseFunctions(file: string): Map<FuncKey, RetInfo> {
  const raw = fs.readFileSync(file, "utf8");
  const s = removeComments(raw);
  const map = new Map<FuncKey, RetInfo>();
  const re = /\bfunc\b/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s))) {
    let i = re.lastIndex;
    while (/\s/.test(s[i] || "")) i++;
    let recv = "";
    if (s[i] === "(") {
      const e = matching(s, i, "(", ")");
      if (e < 0) continue;
      recv = s.slice(i + 1, e);
      i = e + 1;
      while (/\s/.test(s[i] || "")) i++;
    }
    const nm = /^[A-Za-z_]\w*/.exec(s.slice(i));
    if (!nm) continue;
    const name = nm[0];
    i += name.length;
    while (/\s/.test(s[i] || "")) i++;
    if (s[i] !== "(") continue;
    const pe = matching(s, i, "(", ")");
    if (pe < 0) continue;
    const tailStart = pe + 1;
    let j = tailStart;
    while (j < s.length && s[j] !== "{" && s[j] !== "\n") j++;
    const tail = s.slice(tailStart, j);
    const errors = parseReturns(tail);
    if (errors.some(Boolean)) {
      const key = recv ? `${receiverType(recv)}.${name}` : name;
      map.set(key, { errors, sig: key });
    }
    re.lastIndex = j;
  }
  return map;
}

function parseImports(file: string): Map<string, string> {
  const s = removeComments(fs.readFileSync(file, "utf8"));
  const out = new Map<string, string>();
  const add = (alias: string | undefined, imp: string) => {
    const base = imp.split("/").pop() || imp;
    const a = alias && alias !== "_" ? alias : base;
    if (a !== ".") out.set(a, imp);
  };
  const one = /\bimport\s+(?:(\w+|\.)\s+)?\"([^\"]+)\"/g;
  let m: RegExpExecArray | null;
  while ((m = one.exec(s))) add(m[1], m[2]);
  const block = /\bimport\s*\(([\s\S]*?)\)/g;
  while ((m = block.exec(s))) {
    for (const line of m[1].split("\n")) {
      const mm = /^\s*(?:(\w+|\.)\s+)?\"([^\"]+)\"/.exec(line);
      if (mm) add(mm[1], mm[2]);
    }
  }
  return out;
}

function generated(file: string): boolean {
  const head = fs.readFileSync(file, "utf8").slice(0, 2048);
  return /Code generated .* DO NOT EDIT\./.test(head);
}

function loadExcludes(opts: Options): Set<string> {
  const s = new Set<string>();
  if (!opts.excludeonly) s.add("fmt.*");
  if (opts.exclude) {
    try {
      for (const line of fs.readFileSync(opts.exclude, "utf8").split(/\r?\n/)) {
        const t = line.trim();
        if (t && !t.startsWith("//")) s.add(t);
      }
    } catch (e: any) {
      process.stderr.write(`error: ${e.message}\n`);
      process.exit(2);
    }
  }
  return s;
}

function ignored(full: string, name: string, pkgPath: string, opts: Options, excludes: Set<string>): boolean {
  if (opts.ignorepkg.has(pkgPath)) return true;
  if (excludes.has(full) || excludes.has(`${pkgPath}.${name}`) || excludes.has(`${pkgPath}.*`)) return true;
  if (full.startsWith("fmt.") && excludes.has("fmt.*")) return true;
  for (const ig of opts.ignore) {
    if ((ig.pkg === "" || ig.pkg === pkgPath) && ig.re.test(name)) return true;
  }
  return false;
}

function main() {
  const { opts, pkgs } = parseArgs(process.argv.slice(2));
  const packages = runGoList(pkgs, opts);
  const targets = packages.filter(p => !p.DepOnly);
  const pkgFuncs = new Map<string, Map<string, RetInfo>>();
  for (const p of packages) {
    const mm = new Map<string, RetInfo>();
    for (const f of [...(p.GoFiles || []), ...(p.CgoFiles || [])]) {
      const fm = parseFunctions(path.join(p.Dir, f));
      for (const [k, v] of fm) mm.set(k, v);
    }
    pkgFuncs.set(p.ImportPath, mm);
  }
  const excludes = loadExcludes(opts);
  const findings: string[] = [];
  for (const p of targets) {
    if (opts.verbose) process.stderr.write(`checking ${p.ImportPath}\n`);
    let files = [...(p.GoFiles || []), ...(p.CgoFiles || [])];
    if (!opts.ignoretests) files = files.concat(p.TestGoFiles || [], p.XTestGoFiles || []);
    for (const fn of files) {
      const file = path.join(p.Dir, fn);
      if (opts.ignoregenerated && generated(file)) continue;
      scanFile(file, p, pkgFuncs, opts, excludes, findings);
    }
  }
  if (findings.length) {
    process.stdout.write(findings.join("\n") + "\n");
    process.exit(1);
  }
}

function scanFile(file: string, p: Pkg, pkgFuncs: Map<string, Map<string, RetInfo>>, opts: Options, excludes: Set<string>, findings: string[]) {
  const imports = parseImports(file);
  const lines = fs.readFileSync(file, "utf8").split(/\r?\n/);
  const rel = opts.abspath ? file : path.relative(process.cwd(), file) || path.basename(file);
  for (let li = 0; li < lines.length; li++) {
    const line = lines[li];
    const clean = removeComments(line);
    if (!clean.trim()) continue;
    if (opts.asserts) scanAssertions(clean, line, li + 1, rel, opts.blank, findings);
    const assign = assignment(clean);
    if (assign) {
      if (!opts.blank) continue;
      const lhs = splitTop(assign.lhs.replace(/^\s*var\s+/, "").trim());
      for (const call of calls(assign.rhs, assign.offset)) {
        const info = resolveCall(call.name, p, imports, pkgFuncs);
        if (!info || ignored(info.full, info.name, info.pkg, opts, excludes)) continue;
        let badCol = 0;
        info.ret.errors.forEach((isErr, idx) => {
          if (isErr && (lhs[idx] || "").trim() === "_") {
            badCol = lhsColumn(assign.lhs, idx);
          }
        });
        if (badCol) findings.push(format(rel, li + 1, badCol, line));
      }
    } else {
      for (const call of calls(clean, 0)) {
        const info = resolveCall(call.name, p, imports, pkgFuncs);
        if (!info || ignored(info.full, info.name, info.pkg, opts, excludes)) continue;
        findings.push(format(rel, li + 1, call.parenCol, line, opts.blank ? undefined : info.display));
      }
    }
  }
}

function lhsColumn(lhsText: string, partIndex: number): number {
  let depth = 0, part = 0;
  for (let i = 0; i < lhsText.length; i++) {
    const ch = lhsText[i];
    if (ch === "(" || ch === "[" || ch === "{") depth++;
    else if (ch === ")" || ch === "]" || ch === "}") depth--;
    else if (ch === "," && depth === 0) part++;
    else if (ch === "_" && part === partIndex) return i + 1;
  }
  return 1;
}

function assignment(s: string): { lhs: string; rhs: string; offset: number } | null {
  const m = /(.*?)(:=|=)(.*)/.exec(s);
  if (!m) return null;
  if (/[=!<>:]$/.test(m[1].trim())) return null;
  return { lhs: m[1], rhs: m[3], offset: m[1].length + m[2].length };
}

function calls(s: string, offset: number): { name: string; parenCol: number }[] {
  const out: { name: string; parenCol: number }[] = [];
  const re = /((?:[A-Za-z_]\w*\.){0,3}[A-Za-z_]\w*)\s*\(/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s))) {
    const before = s.slice(Math.max(0, m.index - 8), m.index);
    if (/\b(func|if|for|switch|return|range)\s*$/.test(before)) continue;
    const name = m[1];
    if (["if", "for", "switch", "func", "return"].includes(name)) continue;
    const paren = offset + m.index + m[0].lastIndexOf("(") + 1;
    out.push({ name, parenCol: paren });
  }
  return out;
}

function resolveCall(name: string, p: Pkg, imports: Map<string, string>, pkgFuncs: Map<string, Map<string, RetInfo>>):
  { ret: RetInfo; full: string; name: string; pkg: string; display?: string } | null {
  const parts = name.split(".");
  if (parts.length === 1) {
    const ret = pkgFuncs.get(p.ImportPath)?.get(parts[0]);
    return ret ? { ret, full: parts[0], name: parts[0], pkg: p.ImportPath } : null;
  }
  const alias = parts[0];
  const imp = imports.get(alias);
  if (imp && parts.length === 2) {
    const ret = pkgFuncs.get(imp)?.get(parts[1]) || stdFunc(imp, parts[1]);
    return ret ? { ret, full: `${alias}.${parts[1]}`, name: parts[1], pkg: imp, display: `${alias}.${parts[1]}` } : null;
  }
  if (imp && parts.length >= 3) {
    const method = parts[parts.length - 1];
    const type = stdExprType(parts.slice(0, -1).join("."));
    const key = type ? `${type.replace(/^\*/, "")}.${method}` : method;
    const ret = (type ? pkgFuncs.get(imp)?.get(key) : undefined) || stdMethod(imp, type || "", method);
    const dispType = type && type.startsWith("*") ? `(*${imp}.${type.slice(1)})` : type ? `(${imp}.${type})` : imp;
    return ret ? { ret, full: type ? `(${type}).${method}` : `${imp}.${method}`, name: method, pkg: imp, display: type ? `${dispType}.${method}` : `${imp}.${method}` } : null;
  }
  return null;
}

function stdExprType(expr: string): string | null {
  if (expr === "os.Stdout" || expr === "os.Stderr" || expr === "os.Stdin") return "*File";
  return null;
}

function stdFunc(pkg: string, name: string): RetInfo | null {
  const known: Record<string, string[]> = {
    "os": ["Chdir", "Chmod", "Chown", "Chtimes", "Mkdir", "MkdirAll", "Remove", "RemoveAll", "Rename", "Symlink", "Truncate", "WriteFile"],
    "io": ["Copy", "CopyBuffer", "CopyN", "ReadAll", "ReadFull", "ReadAtLeast"],
    "strconv": ["Atoi", "ParseBool", "ParseFloat", "ParseInt", "ParseUint"],
    "encoding/json": ["Marshal", "MarshalIndent", "Unmarshal"],
    "encoding/xml": ["Marshal", "MarshalIndent", "Unmarshal"],
  };
  if (known[pkg]?.includes(name)) return { errors: name.startsWith("Parse") || name === "Atoi" || name === "ReadAll" || name.startsWith("Marshal") ? [false, true] : [false, true], sig: `${pkg}.${name}` };
  return null;
}

function stdMethod(pkg: string, typ: string, method: string): RetInfo | null {
  if (pkg === "os" && typ === "*File" && ["Write", "WriteString", "Read", "Close", "Sync", "Chdir", "Chmod", "Chown", "Truncate"].includes(method)) {
    return { errors: method === "Close" || method === "Sync" || method === "Chdir" || method === "Chmod" || method === "Chown" || method === "Truncate" ? [true] : [false, true], sig: "(*os.File)." + method };
  }
  return null;
}

function scanAssertions(clean: string, orig: string, lineNo: number, rel: string, blank: boolean, findings: string[]) {
  const re = /\.\s*\(\s*[^)]+\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(clean))) {
    const prefix = clean.slice(0, m.index);
    const asn = assignment(clean);
    if (asn) {
      const lhs = splitTop(asn.lhs.replace(/^\s*var\s+/, "").trim());
      if (lhs.length >= 2) continue;
      if (!blank && lhs[0]?.trim() === "_") continue;
    }
    let start = m.index - 1;
    while (start >= 0 && /[A-Za-z0-9_\]\)]/.test(clean[start])) start--;
    findings.push(format(rel, lineNo, start + 2, orig));
  }
}

function format(file: string, line: number, col: number, text: string, display?: string): string {
  return `${file}:${line}:${col}:\t${display ? display + "\t" : ""}${text.trim()}`;
}

main();
