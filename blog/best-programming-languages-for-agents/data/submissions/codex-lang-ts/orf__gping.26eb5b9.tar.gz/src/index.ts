declare const process: any;
declare function require(name: string): any;

const { spawnSync } = require("child_process");

const VERSION = `gping 1.20.1
commit_hash: d67d2aeb
build_time: 2026-04-17 19:59:37 +00:00
build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu`;

const HELP = `Ping, but with a graph.

Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...

Arguments:
  [HOSTS_OR_COMMANDS]...  Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1

Options:
      --cmd
          Graph the execution time for a list of commands rather than pinging hosts
  -n, --watch-interval <WATCH_INTERVAL>
          Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5
  -b, --buffer <BUFFER>
          Determines the number of seconds to display in the graph [default: 30]
  -4
          Resolve ping targets to IPv4 address
  -6
          Resolve ping targets to IPv6 address
  -i, --interface <INTERFACE>
          Interface to use when pinging
  -s, --simple-graphics
          
      --vertical-margin <VERTICAL_MARGIN>
          Vertical margin around the graph (top and bottom) [default: 1]
      --horizontal-margin <HORIZONTAL_MARGIN>
          Horizontal margin around the graph (left and right) [default: 0]
  -c, --color <color>
          Assign color to a graph entry.
          
          This option can be defined more than once as a comma separated string, and the
          order which the colors are provided will be matched against the hosts or
          commands passed to gping.
          
          Hexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the
          following color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',
          'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',
          'light-blue', 'light-magenta', 'light-cyan', and 'white'
      --clear
          Clear the graph from the terminal after closing the program
      --ping-args [<PING_ARGS>...]
          Extra arguments to pass to \`ping\`. These are platform dependent
  -h, --help
          Print help
  -V, --version
          Print version`;

type Opts = {
  cmd: boolean;
  watch?: number;
  buffer: number;
  ipv4: boolean;
  ipv6: boolean;
  iface?: string;
  simple: boolean;
  clear: boolean;
  vmargin: number;
  hmargin: number;
  colors: string[];
  pingArgs: string[];
  targets: string[];
};

const colorNames = new Set([
  "black", "red", "green", "yellow", "blue", "magenta", "cyan", "gray",
  "dark-gray", "light-red", "light-green", "light-yellow", "light-blue",
  "light-magenta", "light-cyan", "white",
]);

function eprintln(s = ""): void {
  process.stderr.write(s + "\n");
}

function failCli(msg: string, usage?: string): never {
  eprintln(`error: ${msg}`);
  if (usage) eprintln(`\nUsage: ${usage}`);
  eprintln("\nFor more information, try '--help'.");
  process.exit(2);
  throw new Error("unreachable");
}

function parseFloatOption(flag: string, value: string): number {
  if (value === undefined || value === "") {
    failCli(`a value is required for '${flag}' but none was supplied`);
  }
  const n = Number(value);
  if (!Number.isFinite(n)) {
    failCli(`invalid value '${value}' for '${flag}': invalid float literal`);
  }
  return n;
}

function parseIntOption(flag: string, value: string): number {
  if (value === undefined || value === "") {
    failCli(`a value is required for '${flag}' but none was supplied`);
  }
  if (!/^-?\d+$/.test(value)) {
    failCli(`invalid value '${value}' for '${flag}': invalid digit found in string`);
  }
  return Number(value);
}

function validateColor(c: string): void {
  if (colorNames.has(c)) return;
  if (/^#[0-9a-fA-F]{6}$/.test(c)) return;
  eprintln(`Error: Invalid color code: \`${c}\`\n`);
  eprintln("Caused by:");
  eprintln("    Failed to parse Colors");
  process.exit(1);
}

function expandCloudTarget(t: string): string {
  if (t.startsWith("aws:")) {
    const region = t.slice(4);
    if (region) return `ec2.${region}.amazonaws.com`;
  }
  return t;
}

function parseArgs(argv: string[]): Opts {
  const opts: Opts = {
    cmd: false,
    buffer: 30,
    ipv4: false,
    ipv6: false,
    simple: false,
    clear: false,
    vmargin: 1,
    hmargin: 0,
    colors: [],
    pingArgs: [],
    targets: [],
  };

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") {
      opts.targets.push(...argv.slice(i + 1));
      break;
    } else if (a === "-h" || a === "--help") {
      process.stdout.write(HELP + "\n");
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      process.stdout.write(VERSION + "\n");
      process.exit(0);
    } else if (a === "--cmd") opts.cmd = true;
    else if (a === "-4") opts.ipv4 = true;
    else if (a === "-6") opts.ipv6 = true;
    else if (a === "-s" || a === "--simple-graphics") opts.simple = true;
    else if (a === "--clear") opts.clear = true;
    else if (a === "-n" || a === "--watch-interval") {
      if (i + 1 >= argv.length) failCli("a value is required for '--watch-interval <WATCH_INTERVAL>' but none was supplied");
      opts.watch = parseFloatOption("--watch-interval <WATCH_INTERVAL>", argv[++i]);
    } else if (a === "-b" || a === "--buffer") {
      if (i + 1 >= argv.length) failCli("a value is required for '--buffer <BUFFER>' but none was supplied");
      opts.buffer = parseFloatOption("--buffer <BUFFER>", argv[++i]);
    } else if (a === "-i" || a === "--interface") {
      if (i + 1 >= argv.length) failCli("a value is required for '--interface <INTERFACE>' but none was supplied");
      opts.iface = argv[++i];
    } else if (a === "--vertical-margin") {
      if (i + 1 >= argv.length) failCli("a value is required for '--vertical-margin <VERTICAL_MARGIN>' but none was supplied");
      opts.vmargin = parseIntOption("--vertical-margin <VERTICAL_MARGIN>", argv[++i]);
    } else if (a === "--horizontal-margin") {
      if (i + 1 >= argv.length) failCli("a value is required for '--horizontal-margin <HORIZONTAL_MARGIN>' but none was supplied");
      opts.hmargin = parseIntOption("--horizontal-margin <HORIZONTAL_MARGIN>", argv[++i]);
    } else if (a === "-c" || a === "--color") {
      if (i + 1 >= argv.length) failCli("a value is required for '--color <color>' but none was supplied");
      const parts = argv[++i].split(",").filter(Boolean);
      parts.forEach(validateColor);
      opts.colors.push(...parts);
    } else if (a === "--ping-args") {
      let j = i + 1;
      while (j < argv.length) {
        opts.pingArgs.push(argv[j]);
        j++;
      }
      break;
    } else if (a.startsWith("--")) {
      failCli(`unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'`, "executable [OPTIONS] [HOSTS_OR_COMMANDS]...");
    } else if (a.startsWith("-") && a.length > 1) {
      failCli(`unexpected argument '${a}' found`, "executable [OPTIONS] [HOSTS_OR_COMMANDS]...");
    } else {
      opts.targets.push(a);
    }
  }

  if (opts.ipv4 && opts.ipv6) {
    const usage = opts.targets.length ? "executable -4 <HOSTS_OR_COMMANDS>..." : "executable -4 [HOSTS_OR_COMMANDS]...";
    failCli("the argument '-4' cannot be used with '-6'", usage);
  }
  return opts;
}

function requireTarget(opts: Opts): void {
  if (opts.targets.length === 0) {
    eprintln("Error: At least one host or command must be given (i.e gping google.com). Use --help for a full list of arguments.");
    process.exit(opts.cmd ? 1 : 2);
  }
}

function checkTerminal(): void {
  if (!process.stdout.isTTY) {
    eprintln("Error: No such device or address (os error 6)");
    process.exit(1);
  }
}

function detectPing(): void {
  const result = spawnSync("ping", ["-V"], { encoding: "utf8" });
  if (result.error && result.error.code === "ENOENT") {
    eprintln("Error: Could not detect ping. Stderr: []");
    eprintln("Stdout: []");
    process.exit(1);
  }
}

function ansiColor(c: string | undefined): string {
  const basic: Record<string, number> = {
    black: 30, red: 31, green: 32, yellow: 33, blue: 34, magenta: 35,
    cyan: 36, gray: 37, "dark-gray": 90, "light-red": 91, "light-green": 92,
    "light-yellow": 93, "light-blue": 94, "light-magenta": 95,
    "light-cyan": 96, white: 97,
  };
  if (!c) return "\x1b[39m";
  if (basic[c]) return `\x1b[${basic[c]}m`;
  const m = /^#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/.exec(c);
  if (m) return `\x1b[38;2;${parseInt(m[1], 16)};${parseInt(m[2], 16)};${parseInt(m[3], 16)}m`;
  return "\x1b[39m";
}

function runCommand(command: string): number {
  const start = Date.now();
  spawnSync(command, { shell: true, stdio: "ignore" });
  return Date.now() - start;
}

function runPing(target: string, opts: Opts): number | undefined {
  const args = ["-c", "1"];
  if (opts.ipv4) args.push("-4");
  if (opts.ipv6) args.push("-6");
  if (opts.iface) args.push("-I", opts.iface);
  args.push(...opts.pingArgs, expandCloudTarget(target));
  const start = Date.now();
  const r = spawnSync("ping", args, { encoding: "utf8" });
  if (r.status !== 0) return undefined;
  const text = `${r.stdout || ""}\n${r.stderr || ""}`;
  const m = /time[=<]([0-9.]+)\s*ms/.exec(text);
  return m ? Number(m[1]) : Date.now() - start;
}

function render(labels: string[], values: (number | undefined)[], opts: Opts): void {
  const width = Math.max(20, (process.stdout.columns || 80) - 1);
  const maxLabel = Math.min(28, Math.max(...labels.map((l) => l.length), 1));
  process.stdout.write("\x1b[2J\x1b[H\x1b[39m\x1b[49m\x1b[0m\x1b[?25l");
  for (let i = 0; i < opts.vmargin; i++) process.stdout.write("\n");
  for (let i = 0; i < labels.length; i++) {
    const color = ansiColor(opts.colors[i]);
    const v = values[i];
    const label = labels[i].slice(0, maxLabel).padEnd(maxLabel, " ");
    const text = v === undefined ? "timeout" : `${v.toFixed(v < 10 ? 2 : 1)} ms`;
    const barLen = v === undefined ? 0 : Math.min(width - maxLabel - 16, Math.max(1, Math.round(v / 5)));
    const char = opts.simple ? "." : "⣿";
    process.stdout.write(" ".repeat(Math.max(0, opts.hmargin)));
    process.stdout.write(`${color}${label}\x1b[39m ${char.repeat(Math.max(0, barLen))} ${text}\n`);
  }
}

function main(): void {
  const opts = parseArgs(process.argv.slice(2));
  requireTarget(opts);

  if (!opts.cmd) detectPing();
  checkTerminal();

  const interval = Math.max(20, Math.round((opts.watch ?? (opts.cmd ? 0.5 : 0.2)) * 1000));
  const labels = opts.targets.slice();
  let last: (number | undefined)[] = labels.map(() => undefined);

  const cleanup = () => {
    process.stdout.write("\x1b[39m\x1b[49m\x1b[0m\x1b[?25h");
    if (opts.clear) process.stdout.write("\x1b[2J\x1b[H");
    process.exit(0);
  };
  process.on("SIGINT", cleanup);
  process.on("SIGTERM", cleanup);

  const tick = () => {
    last = labels.map((label) => opts.cmd ? runCommand(label) : runPing(label, opts));
    render(labels, last, opts);
  };
  tick();
  setInterval(tick, interval);
}

main();
