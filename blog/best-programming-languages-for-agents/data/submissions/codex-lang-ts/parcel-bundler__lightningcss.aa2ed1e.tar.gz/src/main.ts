declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

type Options = {
  minify: boolean;
  outputFile?: string;
  outputDir?: string;
  sourcemap: boolean;
  cssModules: boolean;
  cssModulesFile?: string;
  cssModulesDashed: boolean;
  cssModulesPattern?: string;
  bundle: boolean;
  customMedia: boolean;
  browserslist: boolean;
  errorRecovery: boolean;
  targets?: string;
  inputs: string[];
};

const HELP = `lightningcss 1.0.0-alpha.70
Devon Govett <devongovett@gmail.com>
A CSS parser, transformer, and minifier

USAGE:
    executable [OPTIONS] [INPUT_FILE]...

ARGS:
    <INPUT_FILE>...    Target CSS file (default: stdin)

OPTIONS:
        --browserslist
            

        --bundle
            

        --css-modules [<CSS_MODULES>]
            Enable CSS modules in output. If no filename is provided, <output_file>.json will be
            used. If no --output-file is specified, code and exports will be printed to stdout as
            JSON

        --css-modules-dashed-idents
            

        --css-modules-pattern <CSS_MODULES_PATTERN>
            

        --custom-media
            Enable parsing custom media queries

    -d, --output-dir <OUTPUT_DIR>
            Destination directory to output into

        --error-recovery
            

    -h, --help
            Print help information

    -m, --minify
            Minify the output

    -o, --output-file <OUTPUT_FILE>
            Destination file for the output

        --sourcemap
            Enable sourcemap, at <output_file>.map

    -t, --targets <TARGETS>
            

    -V, --version
            Print version information`;

function die(msg: string, code = 1): never {
  process.stderr.write(msg.endsWith("\n") ? msg : msg + "\n");
  process.exit(code);
  throw new Error(msg);
}

function parseArgs(argv: string[]): Options | null {
  const opts: Options = {
    minify: false,
    sourcemap: false,
    cssModules: false,
    cssModulesDashed: false,
    bundle: false,
    customMedia: false,
    browserslist: false,
    errorRecovery: false,
    inputs: [],
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    switch (a) {
      case "-h":
      case "--help":
        process.stdout.write(HELP + "\n");
        return null;
      case "-V":
      case "--version":
        process.stdout.write("lightningcss 1.0.0-alpha.70\n");
        return null;
      case "-m":
      case "--minify":
        opts.minify = true;
        break;
      case "-o":
      case "--output-file":
        if (i + 1 >= argv.length) die(`error: The argument '${a} <OUTPUT_FILE>' requires a value\n\nFor more information try --help`, 2);
        opts.outputFile = argv[++i];
        break;
      case "-d":
      case "--output-dir":
        if (i + 1 >= argv.length) die(`error: The argument '${a} <OUTPUT_DIR>' requires a value\n\nFor more information try --help`, 2);
        opts.outputDir = argv[++i];
        break;
      case "--sourcemap":
        opts.sourcemap = true;
        break;
      case "--bundle":
        opts.bundle = true;
        break;
      case "--custom-media":
        opts.customMedia = true;
        break;
      case "--browserslist":
        opts.browserslist = true;
        break;
      case "--error-recovery":
        opts.errorRecovery = true;
        break;
      case "--css-modules":
        opts.cssModules = true;
        if (i + 1 < argv.length && !argv[i + 1].startsWith("-")) {
          opts.cssModulesFile = argv[++i];
        }
        break;
      case "--css-modules-dashed-idents":
        opts.cssModulesDashed = true;
        break;
      case "--css-modules-pattern":
        if (i + 1 >= argv.length) die("error: The argument '--css-modules-pattern <CSS_MODULES_PATTERN>' requires a value\n\nFor more information try --help", 2);
        opts.cssModulesPattern = argv[++i];
        break;
      case "-t":
      case "--targets":
        if (i + 1 >= argv.length) die(`error: The argument '${a} <TARGETS>' requires a value\n\nFor more information try --help`, 2);
        opts.targets = argv[++i];
        break;
      case "--":
        opts.inputs.push(...argv.slice(i + 1));
        i = argv.length;
        break;
      default:
        if (a.startsWith("-")) {
          process.stderr.write(`error: Found argument '${a}' which wasn't expected, or isn't valid in this context

\tIf you tried to supply \`${a}\` as a value rather than a flag, use \`-- ${a}\`

USAGE:
    executable [OPTIONS] [INPUT_FILE]...

For more information try --help
`);
          process.exit(2);
        }
        opts.inputs.push(a);
    }
  }
  return opts;
}

function stripComments(css: string): string {
  return css.replace(/\/\*[\s\S]*?\*\//g, "");
}

function normalizeValue(value: string): string {
  let v = value.trim().replace(/\s+/g, " ");
  v = v.replace(/(^|[\s(,])(-?\d+(?:\.\d+)?)px\b/g, (_m, p, n) => Number(n) === 0 ? p + "0" : p + n + "px");
  v = v.replace(/\b0(?:\s+0){1,3}\b/g, "0");
  const colors: Record<string, string> = {
    "#ffffff": "#fff",
    "#000000": "#000",
    "#ff0000": "red",
    "#0000ff": "#00f",
    blue: "#00f",
    white: "#fff",
    black: "#000",
  };
  v = v.replace(/#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b|\b(?:blue|white|black)\b/g, (m) => {
    const lower = m.toLowerCase();
    if (colors[lower]) return colors[lower];
    if (/^#([0-9a-f])\1([0-9a-f])\2([0-9a-f])\3$/.test(lower)) {
      return "#" + lower[1] + lower[3] + lower[5];
    }
    return lower;
  });
  return v;
}

function splitDeclarations(body: string): string[] {
  const out: string[] = [];
  let cur = "";
  let depth = 0;
  let quote = "";
  for (let i = 0; i < body.length; i++) {
    const c = body[i];
    if (quote) {
      cur += c;
      if (c === quote && body[i - 1] !== "\\") quote = "";
      continue;
    }
    if (c === "\"" || c === "'") {
      quote = c;
      cur += c;
      continue;
    }
    if (c === "(" || c === "[" ) depth++;
    if (c === ")" || c === "]") depth = Math.max(0, depth - 1);
    if (c === ";" && depth === 0) {
      if (cur.trim()) out.push(cur.trim());
      cur = "";
    } else {
      cur += c;
    }
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function tidySelector(sel: string): string {
  return sel.trim().replace(/\s*,\s*/g, ", ").replace(/\s+/g, " ");
}

function findMatching(css: string, open: number): number {
  let depth = 0, quote = "";
  for (let i = open; i < css.length; i++) {
    const c = css[i];
    if (quote) {
      if (c === quote && css[i - 1] !== "\\") quote = "";
      continue;
    }
    if (c === "\"" || c === "'") { quote = c; continue; }
    if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

function formatCss(css: string, indent = 0): string {
  css = stripComments(css).trim();
  let out = "";
  let i = 0;
  const pad = "  ".repeat(indent);
  while (i < css.length) {
    while (/\s/.test(css[i] || "")) i++;
    if (i >= css.length) break;
    const open = css.indexOf("{", i);
    if (open < 0) break;
    const head = css.slice(i, open).trim();
    const close = findMatching(css, open);
    if (close < 0) {
      const rest = css.slice(i).trim();
      if (rest) out += pad + rest + "\n";
      break;
    }
    const body = css.slice(open + 1, close).trim();
    if (head.startsWith("@") && body.includes("{")) {
      out += `${pad}${tidySelector(head)} {\n`;
      out += formatCss(body, indent + 1).replace(/\n\n$/, "\n");
      out += `${pad}}\n\n`;
    } else {
      out += `${pad}${tidySelector(head)} {\n`;
      if (body.includes("{")) {
        out += formatCss(body, indent + 1).replace(/\n\n$/, "\n");
      } else {
        for (const d of splitDeclarations(body)) {
          const idx = d.indexOf(":");
          if (idx >= 0) {
            const prop = d.slice(0, idx).trim();
            const val = normalizeValue(d.slice(idx + 1));
            out += `${pad}  ${prop}: ${val};\n`;
          }
        }
      }
      out += `${pad}}\n\n`;
    }
    i = close + 1;
  }
  return out;
}

function minifyCss(css: string): string {
  css = stripComments(css);
  let formatted = formatCss(css);
  formatted = formatted.replace(/\/\*[\s\S]*?\*\//g, "");
  formatted = formatted.replace(/\s+/g, " ");
  formatted = formatted.replace(/\s*([{}:;,>+~])\s*/g, "$1");
  formatted = formatted.replace(/\s*(<=|>=|<|=)\s*/g, "$1");
  formatted = formatted.replace(/;}/g, "}");
  formatted = formatted.replace(/\s*,\s*/g, ",");
  formatted = formatted.replace(/\(\s*/g, "(").replace(/\s*\)/g, ")");
  return formatted.trim();
}

function classHash(_file?: string): string {
  return "H8dAQG";
}

function applyCssModules(css: string, filename: string | undefined, pattern?: string): { code: string, exports: any } {
  const base = filename ? path.basename(filename, path.extname(filename)) : "stdin";
  const hash = classHash(filename);
  const exports: any = {};
  const used = new Map<string, string>();
  function scoped(local: string): string {
    if (!used.has(local)) {
      let name = pattern ? pattern.replace(/\[name\]/g, base).replace(/\[local\]/g, local).replace(/\[hash\]/g, hash) : `${hash}_${local}`;
      used.set(local, name);
      exports[local] = { name, composes: [], isReferenced: false };
    }
    return used.get(local)!;
  }
  let code = css.replace(/(^|[^\\]):global\(([^)]*)\)/g, (_m, p, s) => p + s);
  code = code.replace(/\.([_a-zA-Z][\w-]*)/g, (_m, n) => "." + scoped(n));
  code = code.replace(/#([_a-zA-Z][\w-]*)/g, (_m, n) => "#" + scoped(n));
  return { code, exports };
}

function transform(css: string, opts: Options, filename?: string): { code: string, exports?: any } {
  let exports: any | undefined;
  if (opts.cssModules) {
    const res = applyCssModules(css, filename, opts.cssModulesPattern);
    css = res.code;
    exports = res.exports;
  }
  const code = opts.minify ? minifyCss(css) : formatCss(css).replace(/\n\n$/, "\n");
  return { code, exports };
}

function readStdin(): string {
  try {
    return fs.readFileSync(0, "utf8");
  } catch {
    return "";
  }
}

function writeSourcemap(outFile: string, inputName: string, original: string) {
  const map = {
    version: 3,
    mappings: "",
    sources: [inputName],
    sourcesContent: [original],
    names: [],
  };
  fs.writeFileSync(outFile + ".map", JSON.stringify(map));
}

function outputOne(opts: Options, inputName: string | undefined, original: string, result: {code: string, exports?: any}) {
  let code = result.code;
  if (opts.sourcemap && opts.outputFile) {
    code += `\n/*# sourceMappingURL=${path.basename(opts.outputFile)}.map */`;
  }
  if (opts.outputFile) {
    fs.writeFileSync(opts.outputFile, code + (opts.minify ? "" : code.endsWith("\n") ? "" : "\n"));
    if (opts.sourcemap) writeSourcemap(opts.outputFile, inputName || "stdin", original);
    if (opts.cssModules && opts.outputFile) {
      const jsonFile = opts.cssModulesFile || opts.outputFile + ".json";
      fs.writeFileSync(jsonFile, JSON.stringify(result.exports || {}));
    }
  } else if (opts.cssModules) {
    process.stdout.write(JSON.stringify({ code: code, exports: result.exports || {} }) + "\n");
  } else {
    process.stdout.write(code + "\n");
  }
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (!opts) return;
  if (opts.sourcemap && !opts.outputFile && !opts.outputDir) {
    die(`error: The following required arguments were not provided:
    <--output-file <OUTPUT_FILE>|--output-dir <OUTPUT_DIR>>

USAGE:
    executable --sourcemap <--output-file <OUTPUT_FILE>|--output-dir <OUTPUT_DIR>> <INPUT_FILE>...

For more information try --help`, 2);
  }
  if (opts.inputs.length > 1 && opts.outputFile) {
    die("Cannot use the --output-file option with multiple inputs. Use --output-dir instead.");
  }
  if (opts.inputs.length > 1 && !opts.outputDir) {
    die("Cannot output to stdout with multiple inputs. Use --output-dir instead.");
  }

  if (opts.inputs.length === 0) {
    const original = readStdin();
    const result = transform(original, opts, undefined);
    outputOne(opts, undefined, original, result);
    return;
  }

  if (opts.outputDir) fs.mkdirSync(opts.outputDir, { recursive: true });
  for (const file of opts.inputs) {
    let original: string;
    try {
      original = fs.readFileSync(file, "utf8");
    } catch (e: any) {
      die(`Error: Os { code: ${e?.errno === -2 ? 2 : 1}, kind: ${e?.code === "ENOENT" ? "NotFound" : "Other"}, message: "${e?.message?.includes("no such file") ? "No such file or directory" : (e?.message || "error")}" }`);
    }
    const result = transform(original, opts, file);
    if (opts.outputDir) {
      const out = path.join(opts.outputDir, path.basename(file));
      let code = result.code;
      if (opts.sourcemap) code += `\n/*# sourceMappingURL=${path.basename(out)}.map */`;
      fs.writeFileSync(out, code + (opts.minify ? "" : code.endsWith("\n") ? "" : "\n"));
      if (opts.sourcemap) writeSourcemap(out, file, original);
      if (opts.cssModules) fs.writeFileSync(out + ".json", JSON.stringify(result.exports || {}));
    } else {
      outputOne(opts, file, original, result);
    }
  }
}

main();
