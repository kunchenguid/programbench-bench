declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");

const VERSION = "bat 0.26.1 (610b77c)";

const SHORT_HELP = `A cat(1) clone with wings.

Usage: bat [OPTIONS] [FILE]...
       bat <COMMAND>

Arguments:
  [FILE]...  File(s) to print / concatenate. Use '-' for standard input.

Options:
  -A, --show-all
          Show non-printable characters (space, tab, newline, ..).
      --nonprintable-notation <notation>
          Set notation for non-printable characters.
      --binary <behavior>
          How to treat binary content. (default: no-printing)
  -p, --plain...
          Show plain style (alias for '--style=plain').
  -l, --language <language>
          Set the language for syntax highlighting.
      --fallback-syntax <fallback-syntax>
          Set a fallback language for undetected syntaxes. [aliases: --fallback-language]
  -H, --highlight-line <N:M>
          Highlight lines N through M.
      --file-name <name>
          Specify the name to display for a file.
  -d, --diff
          Only show lines that have been added/removed/modified.
      --tabs <T>
          Set the tab width to T spaces.
      --wrap <mode>
          Specify the text-wrapping mode (*auto*, never, character, word).
  -S, --chop-long-lines
          Truncate all lines longer than screen width. Alias for '--wrap=never'.
  -n, --number
          Show line numbers (alias for '--style=numbers').
      --color <when>
          When to use colors (*auto*, never, always).
      --italic-text <when>
          Use italics in output (always, *never*)
      --decorations <when>
          When to show the decorations (*auto*, never, always).
      --paging <when>
          Specify when to use the pager, or use \`-P\` to disable (*auto*, never, always).
  -m, --map-syntax <glob:syntax>
          Use the specified syntax for files matching the glob pattern ('*.cpp:C++').
      --theme <theme>
          Set the color theme for syntax highlighting.
      --theme-light <theme>
          Sets the color theme for syntax highlighting used for light backgrounds.
      --theme-dark <theme>
          Sets the color theme for syntax highlighting used for dark backgrounds.
      --list-themes
          Display all supported highlighting themes.
  -s, --squeeze-blank
          Squeeze consecutive empty lines.
      --style <components>
          Comma-separated list of style elements to display (*default*, auto, full, plain, changes,
          header, header-filename, header-filesize, grid, rule, numbers, snip).
  -r, --line-range <N:M>
          Only print the lines from N to M.
  -L, --list-languages
          Display all supported languages.
  -u, --unbuffered
          Enable unbuffered input reading for streaming use cases.
      --completion <SHELL>
          Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]
  -E, --quiet-empty
          Produce no output when the input is empty.
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
`;

const LONG_HELP = `A cat(1) clone with syntax highlighting and Git integration.

Usage: bat [OPTIONS] [FILE]...
       bat <COMMAND>

Arguments:
  [FILE]...
          File(s) to print / concatenate. Use a dash ('-') or no argument at all to read from
          standard input.

Options:
  -A, --show-all
          Show non-printable characters like space, tab or newline. This option can also be used to
          print binary files. Use '--tabs' to control the width of the tab-placeholders.

      --nonprintable-notation <notation>
          Set notation for non-printable characters.
          
          Possible values:
            * unicode (␇, ␊, ␀, ..)
            * caret   (^G, ^J, ^@, ..)

      --binary <behavior>
          How to treat binary content. (default: no-printing)
          
          Possible values:
            * no-printing: do not print any binary content
            * as-text: treat binary content as normal text

  -p, --plain...
          Only show plain style, no decorations. This is an alias for '--style=plain'. When '-p' is
          used twice ('-pp'), it also disables automatic paging (alias for '--style=plain
          --paging=never').

  -l, --language <language>
          Explicitly set the language for syntax highlighting. Use '--list-languages' to show all
          supported language names and file extensions.

      --fallback-syntax <fallback-syntax>
          Set a fallback language for syntax highlighting when auto-detection fails.

  -H, --highlight-line <N:M>
          Highlight the specified line ranges with a different background color.

      --file-name <name>
          Specify the name to display for a file.

  -d, --diff
          Only show lines that have been added/removed/modified with respect to the Git index.

      --diff-context <N>
          Include N lines of context around added/removed/modified lines when using '--diff'.

      --tabs <T>
          Set the tab width to T spaces. Use a width of 0 to pass tabs through directly

      --wrap <mode>
          Specify the text-wrapping mode (*auto*, never, character, word).

  -S, --chop-long-lines
          Truncate all lines longer than screen width. Alias for '--wrap=never'.

      --terminal-width <width>
          Explicitly set the width of the terminal instead of determining it automatically.

  -n, --number
          Only show line numbers, no other decorations. This is an alias for '--style=numbers'

      --color <when>
          Specify when to use colored output. Possible values: *auto*, never, always.

      --italic-text <when>
          Specify when to use ANSI sequences for italic text in the output. Possible values: always,
          *never*.

      --decorations <when>
          Specify when to use the decorations that have been specified via '--style'.

  -f, --force-colorization
          Alias for '--decorations=always --color=always'.

      --paging <when>
          Specify when to use the pager. Possible values: *auto*, never, always.

      --pager <command>
          Determine which pager is used.

  -m, --map-syntax <glob:syntax>
          Map a glob pattern to an existing syntax name.

      --ignored-suffix <ignored-suffix>
          Ignore extension.

      --theme <theme>
          Set the theme for syntax highlighting.

      --theme-light <theme>
          Sets the theme name for syntax highlighting used when the terminal uses a light
          background.

      --theme-dark <theme>
          Sets the theme name for syntax highlighting used when the terminal uses a dark background.

      --list-themes
          Display a list of supported themes for syntax highlighting.

  -s, --squeeze-blank
          Squeeze consecutive empty lines into a single empty line.

      --squeeze-limit <squeeze-limit>
          Set the maximum number of consecutive empty lines to be printed.

      --strip-ansi <when>
          Specify when to strip ANSI escape sequences from the input.

      --style <components>
          Configure which elements (line numbers, file headers, grid borders, Git modifications, ..)
          to display in addition to the file contents.

  -r, --line-range <N:M>
          Only print the specified range of lines for each file.

  -L, --list-languages
          Display a list of supported languages for syntax highlighting.

  -u, --unbuffered
          Enable unbuffered input reading.

      --completion <SHELL>
          Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]

      --diagnostic
          Show diagnostic information for bug reports.

  -E, --quiet-empty
          When this flag is set, bat will produce no output at all when the input is empty.

      --acknowledgements
          Show acknowledgements.

      --set-terminal-title
          Sets terminal title to filenames when using a pager.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

You can use 'bat cache' to customize syntaxes and themes. See 'bat cache --help' for more
information
`;

const THEMES = [
  "1337", "Catppuccin Frappe", "Catppuccin Latte", "Catppuccin Macchiato",
  "Catppuccin Mocha", "Coldark-Cold", "Coldark-Dark", "DarkNeon", "Dracula",
  "GitHub", "Monokai Extended", "Monokai Extended Bright", "Monokai Extended Light",
  "Monokai Extended Origin", "Nord", "OneHalfDark", "OneHalfLight",
  "Solarized (dark)", "Solarized (light)", "Sublime Snazzy", "TwoDark",
  "Visual Studio Dark+", "ansi", "base16", "base16-256", "gruvbox-dark",
  "gruvbox-light", "zenburn",
];

const LANGUAGES = [
  "ActionScript:as", "Ada:adb,ads,gpr", "Apache Conf:envvars,htaccess,HTACCESS,htgroups,HTGROUPS,htpasswd,HTPASSWD,.htaccess,.HTACCESS,httpd.conf",
  "AppleScript:applescript,script editor", "ARM Assembly:s,S", "AsciiDoc (Asciidoctor):adoc,ad,asciidoc",
  "AWK:awk", "Batch File:bat,cmd", "BibTeX:bib", "Bourne Again Shell (bash):sh,bash,zsh,ash,.bashrc,.profile,PKGBUILD",
  "C:c", "C#:cs,csx", "C++:cpp,cc,cp,cxx,c++,h,hh,hpp,hxx,h++,inl,ipp,*.h",
  "Cabal:cabal", "Clojure:clj,cljc,cljs,edn", "CMake:CMakeLists.txt,cmake",
  "CoffeeScript:coffee,Cakefile,cson", "Command Help:cmd-help,help", "CSS:css",
  "D:d,di", "Dart:dart", "Diff:diff,patch,*.debdiff", "Dockerfile:Dockerfile,dockerfile,Containerfile",
  "DotENV:.env,.env.dist,.env.local,.env.sample,.env.example,.envrc", "Elixir:ex,exs",
  "Erlang:erl,hrl,Emakefile,emakefile,escript", "Fish:fish", "Fortran (Modern):f90,F90,f95,F95",
  "Git Attributes:attributes,gitattributes,.gitattributes", "Git Commit:COMMIT_EDITMSG,MERGE_MSG,TAG_EDITMSG",
  "Git Config:gitconfig,.gitconfig,.gitmodules", "Git Ignore:exclude,gitignore,.gitignore,.gcloudignore,.?*ignore",
  "Go:go", "Gomod:go.mod,go.work", "Gosum:go.sum", "GraphQL:graphql,graphqls,gql",
  "Groovy:groovy,gvy,gradle,Jenkinsfile", "Haskell:hs", "Highlight non-printables:show-nonprintable",
  "HTML:html,htm,shtml,xhtml", "INI:ini,INI,inf,INF,reg,REG,cfg,CFG,.editorconfig",
  "Java:java,bsh", "JavaScript (Babel):js,mjs,jsx,babel,es6,cjs,*.pac",
  "JQ:jq", "JSON:json,ipynb,*.jsonl,*.jsonc,*.jsonld,*.geojson,*.ndjson",
  "Julia:jl", "Kotlin:kt,kts", "LaTeX:tex,ltx", "Less:less,css.less",
  "Lua:lua,*.nse", "Makefile:make,GNUmakefile,makefile,Makefile,mak,mk",
  "Markdown:md,mdown,markdown,markdn", "Nim:nim,nims", "Nix:nix", "Objective-C:m,h",
  "OCaml:ml,mli", "Org Mode:org", "Pascal:pas,pascal", "Perl:pl,pm,pod,t,PL",
  "PHP:php,php3,php4,php5,php7,phps,phpt,phtml", "Plain Text:txt", "PowerShell:ps1,psm1,psd1",
  "Protocol Buffer:proto", "Python:py,py3,pyw,pyi,SConstruct,SConscript,wscript",
  "R:r,R,Rprofile", "Ruby:rb,rbx,rjs,Rakefile,Gemfile,gemspec", "Rust:rs",
  "Scala:scala,sbt", "SCSS:scss", "SQL:sql,ddl,dml", "Swift:swift", "TOML:toml,Cargo.lock",
  "TypeScript:ts,tsx", "TypeScriptReact:tsx", "XML:xml,xsd,xsl,xslt,svg", "YAML:yaml,yml",
];

interface Opts {
  files: string[];
  number: boolean;
  plain: boolean;
  showAll: boolean;
  notation: "unicode" | "caret";
  squeeze: boolean;
  quietEmpty: boolean;
  lineRanges: string[];
  tabs: number;
  style?: string;
  decorations: "auto" | "always" | "never";
  color: "auto" | "always" | "never";
  fileName?: string;
  terminalWidth: number;
  wrap: string;
}

function die(msg: string, code = 2): never {
  process.stderr.write(msg + "\n");
  process.exit(code);
  throw new Error(msg);
}

function needValue(args: string[], i: number, opt: string): [string, number] {
  if (i + 1 >= args.length) die(`error: a value is required for '${opt} <${opt.replace(/^--?/, "")}>' but none was supplied\n`);
  return [args[i + 1], i + 1];
}

function parseArgs(args: string[]): Opts {
  const opts: Opts = {
    files: [], number: false, plain: false, showAll: false, notation: "unicode",
    squeeze: false, quietEmpty: false, lineRanges: [], tabs: 4, decorations: "auto",
    color: "auto", terminalWidth: Number(process.env.COLUMNS || "80") || 80, wrap: "auto",
  };
  if (process.env.BAT_STYLE) applyStyle(opts, process.env.BAT_STYLE);
  const valueOpts = new Set(["--language", "--fallback-syntax", "--fallback-language", "--highlight-line", "--file-name", "--diff-context", "--tabs", "--wrap", "--terminal-width", "--color", "--italic-text", "--decorations", "--paging", "--pager", "--map-syntax", "--ignored-suffix", "--theme", "--theme-light", "--theme-dark", "--squeeze-limit", "--strip-ansi", "--style", "--line-range", "--completion", "--binary", "--nonprintable-notation"]);
  for (let i = 0; i < args.length; i++) {
    let a = args[i];
    if (a === "--") {
      opts.files.push(...args.slice(i + 1));
      break;
    }
    if (a === "cache") {
      process.stdout.write("bat cache 0.26.1\n\nUsage: bat cache [OPTIONS] [COMMAND]\n\nCommands:\n  --build      Build cache\n  --clear      Clear cache\n  --help       Print help\n");
      process.exit(0);
    }
    if (a === "-h") { process.stdout.write(SHORT_HELP); process.exit(0); }
    if (a === "--help") { process.stdout.write(LONG_HELP); process.exit(0); }
    if (a === "-V" || a === "--version") { process.stdout.write(VERSION + "\n"); process.exit(0); }
    if (a === "-L" || a === "--list-languages") { process.stdout.write(LANGUAGES.join("\n") + "\n"); process.exit(0); }
    if (a === "--list-themes") { process.stdout.write(THEMES.join("\n") + "\n"); process.exit(0); }
    if (a === "--diagnostic") {
      process.stdout.write(`#### Software version\n\nbat 0.26.1 (610b77c)\n\n#### Operating system\n\n${process.platform}\n`);
      process.exit(0);
    }
    if (a === "--config-file") {
      process.stdout.write(path.join(process.env.HOME || ".", ".config", "bat", "config") + "\n");
      process.exit(0);
    }
    if (a === "--config-dir") {
      process.stdout.write(path.join(process.env.HOME || ".", ".config", "bat") + "\n");
      process.exit(0);
    }
    if (a === "--generate-config-file") {
      const p = path.join(process.env.HOME || ".", ".config", "bat", "config");
      fs.mkdirSync(path.dirname(p), { recursive: true });
      if (!fs.existsSync(p)) fs.writeFileSync(p, "# This is bat's configuration file.\n");
      process.stdout.write(`Success! Config file written to ${p}\n`);
      process.exit(0);
    }
    if (a === "--acknowledgements") {
      process.stdout.write("bat uses syntect, clap, serde, git2, and other open source projects.\n");
      process.exit(0);
    }
    if (a.startsWith("--")) {
      let val: string | undefined;
      const eq = a.indexOf("=");
      if (eq >= 0) {
        val = a.slice(eq + 1);
        a = a.slice(0, eq);
      }
      if (a === "--plain") opts.plain = true;
      else if (a === "--number") opts.number = true;
      else if (a === "--show-all") opts.showAll = true;
      else if (a === "--squeeze-blank") opts.squeeze = true;
      else if (a === "--quiet-empty") opts.quietEmpty = true;
      else if (a === "--diff") { /* accepted */ }
      else if (a === "--force-colorization") { opts.decorations = "always"; opts.color = "always"; }
      else if (a === "--chop-long-lines") opts.wrap = "never";
      else if (valueOpts.has(a)) {
        if (val === undefined) [val, i] = needValue(args, i, a);
        if (a === "--line-range") opts.lineRanges.push(val);
        else if (a === "--style") { opts.style = val; applyStyle(opts, val); }
        else if (a === "--tabs") opts.tabs = Math.max(0, parseInt(val, 10) || 0);
        else if (a === "--nonprintable-notation") opts.notation = val === "caret" ? "caret" : "unicode";
        else if (a === "--decorations" && (val === "always" || val === "never" || val === "auto")) opts.decorations = val;
        else if (a === "--color" && (val === "always" || val === "never" || val === "auto")) opts.color = val;
        else if (a === "--file-name") opts.fileName = val;
        else if (a === "--terminal-width") opts.terminalWidth = parseTerminalWidth(val, opts.terminalWidth);
        else if (a === "--wrap") opts.wrap = val;
      } else {
        die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [FILE]...`);
      }
    } else if (a.startsWith("-") && a !== "-") {
      for (let j = 1; j < a.length; j++) {
        const ch = a[j];
        if (ch === "p") opts.plain = true;
        else if (ch === "n") opts.number = true;
        else if (ch === "A") opts.showAll = true;
        else if (ch === "s") opts.squeeze = true;
        else if (ch === "E") opts.quietEmpty = true;
        else if (ch === "d" || ch === "u" || ch === "f" || ch === "P" || ch === "S") {
          if (ch === "f") { opts.decorations = "always"; opts.color = "always"; }
          if (ch === "S") opts.wrap = "never";
        } else if ("lrHm".includes(ch)) {
          let val = a.slice(j + 1);
          if (!val) [val, i] = needValue(args, i, "-" + ch);
          if (ch === "r") opts.lineRanges.push(val);
          if (ch === "l" || ch === "H" || ch === "m") { /* accepted */ }
          break;
        } else if (ch === "L") { process.stdout.write(LANGUAGES.join("\n") + "\n"); process.exit(0); }
        else if (ch === "V") { process.stdout.write(VERSION + "\n"); process.exit(0); }
        else if (ch === "h") { process.stdout.write(SHORT_HELP); process.exit(0); }
        else die(`error: unexpected argument '-${ch}' found\n\nUsage: executable [OPTIONS] [FILE]...`);
      }
    } else {
      opts.files.push(a);
    }
  }
  return opts;
}

function parseTerminalWidth(v: string, cur: number): number {
  if (/^[+-]\d+$/.test(v)) return Math.max(1, cur + parseInt(v, 10));
  const n = parseInt(v, 10);
  return n > 0 ? n : cur;
}

function applyStyle(opts: Opts, style: string) {
  const valid = new Set(["default", "full", "auto", "plain", "changes", "header", "header-filename", "header-filesize", "grid", "rule", "numbers", "snip"]);
  const parts = style.split(",").filter(Boolean);
  for (const raw of parts) {
    const p = raw.replace(/^[+-]/, "");
    if (!valid.has(p)) die(`error: invalid value '${style}' for '--style <components>': Unknown style '${p}'`);
  }
  if (parts.includes("plain")) { opts.plain = true; opts.number = false; }
  if (parts.includes("numbers")) opts.number = true;
}

function splitLines(text: string): { lines: string[]; hadFinalNewline: boolean } {
  const hadFinalNewline = text.endsWith("\n");
  if (hadFinalNewline) text = text.slice(0, -1);
  const lines = text.length ? text.split("\n") : [];
  return { lines, hadFinalNewline };
}

function selectRanges(lines: string[], specs: string[]): string[] {
  if (specs.length === 0) return lines;
  const out: string[] = [];
  const seen = new Set<number>();
  for (const spec of specs) {
    let start = 1, end = lines.length;
    let m;
    if ((m = spec.match(/^(-?\d+):$/))) {
      const n = parseInt(m[1], 10);
      start = n < 0 ? lines.length + n + 1 : n;
    } else if ((m = spec.match(/^:(\d+)$/))) {
      end = parseInt(m[1], 10);
    } else if ((m = spec.match(/^(\d+):\+(\d+)$/))) {
      start = parseInt(m[1], 10); end = start + parseInt(m[2], 10);
    } else if ((m = spec.match(/^(\d+)::(\d+)$/))) {
      const center = parseInt(m[1], 10), ctx = parseInt(m[2], 10);
      start = center - ctx; end = center + ctx;
    } else if ((m = spec.match(/^(\d+):(\d+):(\d+)$/))) {
      start = parseInt(m[1], 10) - parseInt(m[3], 10);
      end = parseInt(m[2], 10) + parseInt(m[3], 10);
    } else if ((m = spec.match(/^(\d+):(\d+)$/))) {
      start = parseInt(m[1], 10); end = parseInt(m[2], 10);
    } else if ((m = spec.match(/^(\d+)$/))) {
      start = end = parseInt(m[1], 10);
    }
    start = Math.max(1, start); end = Math.min(lines.length, end);
    for (let i = start; i <= end; i++) if (!seen.has(i)) { seen.add(i); out.push(lines[i - 1]); }
  }
  return out;
}

function squeeze(lines: string[]): string[] {
  const out: string[] = [];
  let blank = 0;
  for (const l of lines) {
    if (l === "") {
      blank++;
      if (blank <= 1) out.push(l);
    } else {
      blank = 0;
      out.push(l);
    }
  }
  return out;
}

function visibleLine(line: string, opts: Opts): string {
  if (!opts.showAll) return line;
  let out = "";
  for (const ch of line) {
    const code = ch.charCodeAt(0);
    if (ch === " ") out += "·";
    else if (ch === "\t") out += "├" + "─".repeat(Math.max(1, opts.tabs - 3)) + "┤";
    else if (code === 0) out += opts.notation === "caret" ? "^@" : "␀";
    else if (code < 32) out += opts.notation === "caret" ? "^" + String.fromCharCode(code + 64) : String.fromCharCode(0x2400 + code);
    else if (code === 127) out += opts.notation === "caret" ? "^?" : "␡";
    else out += ch;
  }
  out += opts.notation === "caret" ? "^J" : "␊";
  return out;
}

function render(text: string, opts: Opts, displayName?: string): string {
  let { lines, hadFinalNewline } = splitLines(text.replace(/\r\n/g, "\n"));
  lines = selectRanges(lines, opts.lineRanges);
  if (opts.squeeze) lines = squeeze(lines);
  if (opts.quietEmpty && lines.length === 0) return "";
  if (opts.wrap === "never") {
    const width = opts.terminalWidth;
    lines = lines.map(l => l.length > width ? l.slice(0, width) : l);
  }
  const decorated = opts.decorations === "always" && !opts.plain;
  const numbered = opts.number && !opts.plain;
  const width = String(Math.max(lines.length, 1)).length;
  let out = "";
  if (decorated) {
    const rule = "─────" + "┬" + "─".repeat(Math.max(1, opts.terminalWidth - 6));
    out += rule + "\n";
    if (displayName) out += "     │ File: " + displayName + "\n" + "─────" + "┼" + "─".repeat(Math.max(1, opts.terminalWidth - 6)) + "\n";
  }
  for (let i = 0; i < lines.length; i++) {
    let line = visibleLine(lines[i], opts);
    if (numbered || decorated) line = String(i + 1).padStart(Math.max(4, width + 2), " ") + (decorated ? " │ " : " ") + line;
    out += line + "\n";
  }
  if (!opts.showAll && !hadFinalNewline && out.endsWith("\n")) out = out.slice(0, -1);
  if (decorated) out += "─────" + "┴" + "─".repeat(Math.max(1, opts.terminalWidth - 6)) + "\n";
  return out;
}

function readStdin(): string {
  try { return fs.readFileSync(0).toString("utf8"); } catch { return ""; }
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const files = opts.files.length ? opts.files : ["-"];
  let exitCode = 0;
  for (const f of files) {
    try {
      let text: string;
      let name: string | undefined = opts.fileName;
      if (f === "-") {
        text = readStdin();
        if (!name) name = undefined;
      } else {
        text = fs.readFileSync(f).toString("utf8");
        if (!name) name = f;
      }
      process.stdout.write(render(text, opts, name));
    } catch (e: any) {
      exitCode = 1;
      const msg = e && e.code === "EACCES" ? "Permission denied" : e && e.code === "ENOENT" ? "No such file or directory" : (e.message || "error");
      process.stderr.write(`\x1b[31m[bat error]\x1b[0m: '${f}': ${msg}${e && e.errno ? ` (os error ${Math.abs(e.errno)})` : ""}\n`);
    }
  }
  process.exit(exitCode);
}

main();
