declare const require: any;
declare const process: any;

const fs = require("fs");

type Options = {
  preview: boolean;
  fixed: boolean;
  max: number;
  flags: string;
  find?: string;
  replacement?: string;
  files: string[];
};

const HELP_LONG = `sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>
          The regexp or string (if using \`-F\`) to search for

  <REPLACE_WITH>
          What to replace each match with. Unless in string mode, you may use captured values like
          $1, $2, etc

  [FILES]...
          The path to file(s). This is optional - sd can also read from STDIN.
          
          Note: sd modifies files in-place by default. See documentation for examples.

Options:
  -p, --preview
          Display changes in a human reviewable format (the specifics of the format are likely to
          change in the future)

  -F, --fixed-strings
          Treat FIND and REPLACE_WITH args as literal strings

  -n, --max-replacements <LIMIT>
          Limit the number of replacements that can occur per file. 0 indicates unlimited
          replacements
          
          [default: 0]

  -f, --flags <FLAGS>
          Regex flags. May be combined (like \`-f mc\`).
          
          c - case-sensitive
          
          e - disable multi-line matching
          
          i - case-insensitive
          
          m - multi-line matching
          
          s - make \`.\` match newlines
          
          w - match full words only

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
`;

const HELP_SHORT = `sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>          The regexp or string (if using \`-F\`) to search for
  <REPLACE_WITH>  What to replace each match with. Unless in string mode, you may use captured
                  values like $1, $2, etc
  [FILES]...      The path to file(s). This is optional - sd can also read from STDIN

Options:
  -p, --preview                   Display changes in a human reviewable format (the specifics of the
                                  format are likely to change in the future)
  -F, --fixed-strings             Treat FIND and REPLACE_WITH args as literal strings
  -n, --max-replacements <LIMIT>  Limit the number of replacements that can occur per file. 0
                                  indicates unlimited replacements [default: 0]
  -f, --flags <FLAGS>             Regex flags. May be combined (like \`-f mc\`).
  -h, --help                      Print help (see more with '--help')
  -V, --version                   Print version
`;

function die(message: string, code = 1): never {
  process.stderr.write(message.endsWith("\n") ? message : message + "\n");
  process.exit(code);
  throw new Error("unreachable");
}

function usageError(message: string): never {
  die(`error: ${message}\n\nUsage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.`, 2);
}

function parseArgs(argv: string[]): Options {
  const opts: Options = { preview: false, fixed: false, max: 0, flags: "", files: [] };
  const positionals: string[] = [];
  let endOptions = false;

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (!endOptions && arg === "--") {
      endOptions = true;
      continue;
    }
    if (!endOptions && (arg === "--help" || arg === "-h")) {
      process.stdout.write(arg === "-h" ? HELP_SHORT : HELP_LONG);
      process.exit(0);
    }
    if (!endOptions && (arg === "--version" || arg === "-V")) {
      process.stdout.write("sd 1.0.0\n");
      process.exit(0);
    }
    if (!endOptions && (arg === "--preview" || arg === "-p")) {
      opts.preview = true;
      continue;
    }
    if (!endOptions && (arg === "--fixed-strings" || arg === "-F")) {
      opts.fixed = true;
      continue;
    }
    if (!endOptions && (arg === "--max-replacements" || arg === "-n")) {
      const value = argv[++i];
      if (value === undefined) usageError("a value is required for '--max-replacements <LIMIT>' but none was supplied");
      opts.max = parseLimit(value);
      continue;
    }
    if (!endOptions && arg.startsWith("--max-replacements=")) {
      opts.max = parseLimit(arg.slice("--max-replacements=".length));
      continue;
    }
    if (!endOptions && (arg === "--flags" || arg === "-f")) {
      const value = argv[++i];
      if (value === undefined) usageError("a value is required for '--flags <FLAGS>' but none was supplied");
      opts.flags += value;
      continue;
    }
    if (!endOptions && arg.startsWith("--flags=")) {
      opts.flags += arg.slice("--flags=".length);
      continue;
    }
    if (!endOptions && arg.startsWith("-") && arg !== "-") {
      usageError(`unexpected argument '${arg}' found\n\n  tip: to pass '${arg}' as a value, use '-- ${arg}'`);
    }
    positionals.push(arg);
  }

  if (positionals.length < 2) {
    die(`error: the following required arguments were not provided:
  <FIND>
  <REPLACE_WITH>

Usage: executable <FIND> <REPLACE_WITH> [FILES]...

For more information, try '--help'.`, 2);
  }

  opts.find = positionals[0];
  opts.replacement = positionals[1];
  opts.files = positionals.slice(2);
  return opts;
}

function parseLimit(value: string): number {
  if (!/^\d+$/.test(value)) {
    die(`error: invalid value '${value}' for '--max-replacements <LIMIT>': invalid digit found in string

For more information, try '--help'.`, 2);
  }
  return Number(value);
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function translatePattern(pattern: string): string {
  return pattern.replace(/\(\?P<([A-Za-z_][A-Za-z0-9_]*)>/g, "(?<$1>");
}

function makeRegex(opts: Options): RegExp {
  let source = opts.fixed ? escapeRegExp(opts.find!) : translatePattern(opts.find!);
  if (!opts.fixed && opts.flags.includes("w")) {
    source = `\\b(?:${source})\\b`;
  }

  let caseInsensitive = false;
  for (const ch of opts.flags) {
    if (ch === "i") caseInsensitive = true;
    if (ch === "c") caseInsensitive = false;
  }

  let flags = "g";
  if (caseInsensitive) flags += "i";
  if (!opts.flags.includes("e")) flags += "m";
  if (opts.flags.includes("s")) flags += "s";

  try {
    return new RegExp(source, flags);
  } catch (err: any) {
    die(`error: invalid regex ${err && err.message ? err.message : String(err)}`);
  }
}

function replacementError(template: string, start: number, end: number): never {
  const token = template.slice(start, end);
  die(`error: The numbered capture group \`${token}\` in the replacement text is ambiguous.
hint: Use curly braces to disambiguate it \`\${${token.slice(1)}}${template.slice(end, end + 1)}\`.
${template}
${" ".repeat(start)}${"^".repeat(Math.max(1, end - start))}`);
}

function expandReplacement(template: string, match: string, captures: any[], groups: Record<string, string> | undefined): string {
  let out = "";
  for (let i = 0; i < template.length; i++) {
    const ch = template[i];
    if (ch !== "$") {
      out += ch;
      continue;
    }
    const next = template[i + 1];
    if (next === "$") {
      out += "$";
      i++;
      continue;
    }
    if (next === "{") {
      const close = template.indexOf("}", i + 2);
      if (close >= 0) {
        const name = template.slice(i + 2, close);
        out += captureValue(name, match, captures, groups);
        i = close;
        continue;
      }
    }
    if (next && /[0-9]/.test(next)) {
      let j = i + 1;
      while (j < template.length && /[0-9]/.test(template[j])) j++;
      if (j < template.length && /[A-Za-z_]/.test(template[j])) replacementError(template, i, j + 1);
      out += captureValue(template.slice(i + 1, j), match, captures, groups);
      i = j - 1;
      continue;
    }
    if (next && /[A-Za-z_]/.test(next)) {
      let j = i + 1;
      while (j < template.length && /[A-Za-z0-9_]/.test(template[j])) j++;
      out += captureValue(template.slice(i + 1, j), match, captures, groups);
      i = j - 1;
      continue;
    }
    out += "$";
  }
  return out;
}

function captureValue(name: string, match: string, captures: any[], groups: Record<string, string> | undefined): string {
  if (/^\d+$/.test(name)) {
    const idx = Number(name);
    if (idx === 0) return match;
    return captures[idx - 1] ?? "";
  }
  return (groups && groups[name]) ?? "";
}

function replaceContent(input: string, opts: Options, regex: RegExp): string {
  let count = 0;
  return input.replace(regex, (...args: any[]) => {
    if (opts.max > 0 && count >= opts.max) return args[0];
    count++;
    if (opts.fixed) return opts.replacement!;

    const match = args[0];
    let groups: Record<string, string> | undefined;
    if (typeof args[args.length - 1] === "object") {
      groups = args[args.length - 1];
    }
    const captures = args.slice(1, typeof args[args.length - 1] === "object" ? -3 : -2);
    return expandReplacement(opts.replacement!, match, captures, groups);
  });
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const regex = makeRegex(opts);

  if (opts.files.length === 0) {
    const input = fs.readFileSync(0, "utf8");
    process.stdout.write(replaceContent(input, opts, regex));
    return;
  }

  const multiple = opts.files.length > 1;
  for (const file of opts.files) {
    let input: string;
    try {
      input = fs.readFileSync(file, "utf8");
    } catch {
      die(`error: invalid path: ${file}`);
    }
    const output = replaceContent(input, opts, regex);
    if (opts.preview) {
      if (multiple) process.stdout.write(`----- FILE ${file} -----\n`);
      process.stdout.write(output);
      if (!output.endsWith("\n")) process.stdout.write("\n");
    } else {
      fs.writeFileSync(file, output);
    }
  }
}

main();
