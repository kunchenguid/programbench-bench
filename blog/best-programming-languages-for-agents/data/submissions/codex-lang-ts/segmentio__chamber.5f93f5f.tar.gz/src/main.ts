declare const process: any;
declare function require(name: string): any;

const { spawnSync } = require("child_process");
const fs = require("fs");

type Parsed = { args: string[]; flags: Record<string, any> };

const globalHelp = `CLI for storing secrets

Usage:
  chamber [command]

Available Commands:
  completion    Generate the autocompletion script for the specified shell
  delete        Delete a secret, including all versions
  env           Print the secrets from the parameter store in a format to export as environment variables
  exec          Executes a command with secrets loaded into the environment
  export        Exports parameters in the specified format
  find          Find the given secret across all services
  help          Help about any command
  history       View the history of a secret
  import        import secrets from json or yaml
  list          List the secrets set for a service
  list-services List services
  read          Read a specific secret from the parameter store
  tag           work with tags on secrets
  version       print version
  write         write a secret

Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
  -h, --help                       help for chamber
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                    standard
                                    adaptive (default "standard")
      --verbose                    Print more information to STDERR

Use "chamber [command] --help" for more information about a command.`;

const globalFlags = `
Global Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                    standard
                                    adaptive (default "standard")
      --verbose                    Print more information to STDERR`;

const helps: Record<string, string> = {
  version: `print version

Usage:
  chamber version [flags]

Flags:
  -h, --help   help for version
${globalFlags}`,
  list: `List the secrets set for a service

Usage:
  chamber list <service> [flags]

Flags:
  -e, --expand    Expand parameter list with values
  -h, --help      help for list
  -t, --time      Sort by modified time
  -u, --user      Sort by user
  -v, --version   Sort by version
${globalFlags}`,
  read: `Read a specific secret from the parameter store

Usage:
  chamber read <service> <key> [flags]

Flags:
  -h, --help          help for read
  -q, --quiet         Only print the secret
  -v, --version int   The version number of the secret. Defaults to latest. (default -1)
${globalFlags}`,
  write: `write a secret

Usage:
  chamber write <service> <key> [--] <value|-> [flags]

Flags:
  -h, --help                  help for write
  -s, --singleline            Insert single line parameter (end with \\n)
      --skip-unchanged        Skip writing secret if value is unchanged
  -t, --tags stringToString   Add tags to the secret; new secrets only (default [])
${globalFlags}`,
  delete: `Delete a secret, including all versions

Usage:
  chamber delete <service> <key> [flags]

Flags:
      --exact-key   Prevent normalization of the provided key in order to delete any keys that match the exact provided casing.
  -h, --help        help for delete
${globalFlags}`,
  env: `Print the secrets from the parameter store in a format to export as environment variables

Usage:
  chamber env <service> [flags]

Flags:
  -p, --preserve-case    preserve variable name case
  -e, --escape-strings   escape special characters in values
  -h, --help             help for env
${globalFlags}`,
  exec: `Executes a command with secrets loaded into the environment

Usage:
  chamber exec <service...> -- <command> [<arg...>] [flags]

Examples:

Given a secret store like this:

\t$ echo '{"db_username": "root", "db_password": "hunter22"}' | chamber import - 

--strict will fail with unfilled env vars

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme EXTRA=chamberme chamber exec --strict service exec -- env
\tchamber: extra unfilled env var EXTRA
\texit 1

--pristine takes effect after checking for --strict values

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme chamber exec --strict --pristine service exec -- env
\tDB_USERNAME=root
\tDB_PASSWORD=hunter22


Flags:
  -h, --help                  help for exec
      --pristine              only use variables retrieved from the backend; do not inherit existing environment variables
      --strict                enable strict mode:
                              only inject secrets for which there is a corresponding env var with value
                              <strict-value>, and fail if there are any env vars with that value missing
                              from secrets
      --strict-value string   value to expect in --strict mode (default "chamberme")
${globalFlags}`,
  export: `Exports parameters in the specified format

Usage:
  chamber export <service...> [flags]

Flags:
  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default "json")
  -o, --output-file string   Output file (default is standard output)
  -h, --help                 help for export
${globalFlags}`,
  find: `Find the given secret across all services

Usage:
  chamber find <secret name> [flags]

Flags:
  -v, --by-value   Find parameters by value
  -h, --help       help for find
${globalFlags}`,
  history: `View the history of a secret

Usage:
  chamber history <service> <key> [flags]

Flags:
  -h, --help   help for history
${globalFlags}`,
  import: `import secrets from json or yaml

Usage:
  chamber import <service> <file|-> [flags]

Flags:
  -h, --help                           help for import
      --normalize-keys chamber write   Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source.
${globalFlags}`,
  "list-services": `List services

Usage:
  chamber list-services <service> [flags]

Flags:
  -h, --help      help for list-services
  -s, --secrets   Include secret names in the list
${globalFlags}`,
  tag: `work with tags on secrets

Usage:
  chamber tag [command]

Available Commands:
  delete      Delete tags for a specific secret
  read        Read tags for a specific secret
  write       Write tags for a specific secret

Flags:
  -h, --help   help for tag
${globalFlags}

Use "chamber tag [command] --help" for more information about a command.`,
  completion: `Generate the autocompletion script for chamber for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  chamber completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion
${globalFlags}

Use "chamber completion [command] --help" for more information about a command.`
};

const tagHelps: Record<string, string> = {
  read: `Read tags for a specific secret

Usage:
  chamber tag read <service> <key> [flags]

Flags:
  -h, --help   help for read
${globalFlags}`,
  write: `Write tags for a specific secret

Usage:
  chamber tag write <service> <key> <tag>... [flags]

Flags:
      --delete-other-tags   Delete tags not specified in the command
  -h, --help                help for write
${globalFlags}`,
  delete: `Delete tags for a specific secret

Usage:
  chamber tag delete <service> <key> <tag key>... [flags]

Flags:
  -h, --help   help for delete
${globalFlags}`
};

function completionHelp(shell: string): string {
  const cap = shell === "powershell" ? "powershell" : `the ${shell} shell`;
  let body = `Generate the autocompletion script for ${cap}.\n\n`;
  if (shell === "bash") body += `This script depends on the 'bash-completion' package.\nIf it is not installed already, you can install it via your OS's package manager.\n\nTo load completions in your current shell session:\n\n\tsource <(chamber completion bash)\n\nTo load completions for every new session, execute once:\n\n#### Linux:\n\n\tchamber completion bash > /etc/bash_completion.d/chamber\n\n#### macOS:\n\n\tchamber completion bash > $(brew --prefix)/etc/bash_completion.d/chamber\n\nYou will need to start a new shell for this setup to take effect.\n\nUsage:\n  chamber completion bash\n\nFlags:\n  -h, --help              help for bash\n      --no-descriptions   disable completion descriptions\n${globalFlags}`;
  else if (shell === "zsh") body += `If shell completion is not already enabled in your environment you will need\nto enable it.  You can execute the following once:\n\n\techo "autoload -U compinit; compinit" >> ~/.zshrc\n\nTo load completions in your current shell session:\n\n\tsource <(chamber completion zsh)\n\nTo load completions for every new session, execute once:\n\n#### Linux:\n\n\tchamber completion zsh > "\${fpath[1]}/_chamber"\n\n#### macOS:\n\n\tchamber completion zsh > $(brew --prefix)/share/zsh/site-functions/_chamber\n\nYou will need to start a new shell for this setup to take effect.\n\nUsage:\n  chamber completion zsh [flags]\n\nFlags:\n  -h, --help              help for zsh\n      --no-descriptions   disable completion descriptions\n${globalFlags}`;
  else if (shell === "fish") body += `To load completions in your current shell session:\n\n\tchamber completion fish | source\n\nTo load completions for every new session, execute once:\n\n\tchamber completion fish > ~/.config/fish/completions/chamber.fish\n\nYou will need to start a new shell for this setup to take effect.\n\nUsage:\n  chamber completion fish [flags]\n\nFlags:\n  -h, --help              help for fish\n      --no-descriptions   disable completion descriptions\n${globalFlags}`;
  else body += `To load completions in your current shell session:\n\n\tchamber completion powershell | Out-String | Invoke-Expression\n\nTo load completions for every new session, add the output of the above command\nto your powershell profile.\n\nUsage:\n  chamber completion powershell [flags]\n\nFlags:\n  -h, --help              help for powershell\n      --no-descriptions   disable completion descriptions\n${globalFlags}`;
  return body;
}

function out(s = "") { process.stdout.write(s + "\n"); }
function err(s = "") { process.stderr.write(s + "\n"); }
function fail(msg: string, code = 1) { err("Error: " + msg); process.exit(code); }

function parse(argv: string[]): Parsed {
  const flags: Record<string, any> = {};
  const args: string[] = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") { args.push(...argv.slice(i)); break; }
    if (a === "-h" || a === "--help") flags.help = true;
    else if (a === "-b" || a === "--backend") flags.backend = argv[++i] || "";
    else if (a.startsWith("--backend=")) flags.backend = a.slice(10);
    else if (a === "-r" || a === "--retries" || a === "--retry-mode" || a === "--backend-s3-bucket" || a === "--kms-key-alias" || a === "--strict-value" || a === "-f" || a === "--format" || a === "-o" || a === "--output-file" || a === "-t" || a === "--tags" || a === "-v" || a === "--version") {
      const name = a.replace(/^--?/, "");
      flags[name] = argv[++i] || "";
    } else if (["-e","--expand","--verbose","-q","--quiet","-s","--singleline","--skip-unchanged","--exact-key","-p","--preserve-case","--escape-strings","--pristine","--strict","--by-value","--secrets","--delete-other-tags","--normalize-keys","--no-descriptions","-u","--user"].includes(a)) {
      flags[a.replace(/^--?/, "")] = true;
    } else if (a.startsWith("-")) {
      if (a.includes("e")) flags.e = flags.expand = true;
      if (a.includes("t")) flags.t = true;
      if (a.includes("u")) flags.u = true;
      if (a.includes("v")) flags.v = true;
      if (a.includes("q")) flags.q = true;
      if (a.includes("s")) flags.s = true;
      if (a.includes("p")) flags.p = true;
    } else args.push(a);
  }
  return { args, flags };
}

function splitLeadingGlobals(argv: string[]): { leading: string[]; rest: string[] } {
  const leading: string[] = [];
  let i = 0;
  const takesValue = new Set(["-b", "--backend", "-r", "--retries", "--retry-mode", "--backend-s3-bucket", "--kms-key-alias"]);
  while (i < argv.length) {
    const a = argv[i];
    if (a === "--") break;
    if (a === "--verbose" || a === "-h" || a === "--help") {
      leading.push(a); i++; continue;
    }
    if (takesValue.has(a)) {
      leading.push(a);
      if (i + 1 < argv.length) leading.push(argv[i + 1]);
      i += 2; continue;
    }
    if (a.startsWith("--backend=") || a.startsWith("--retry-mode=") || a.startsWith("--retries=")) {
      leading.push(a); i++; continue;
    }
    break;
  }
  return { leading, rest: argv.slice(i) };
}

function backend(flags: Record<string, any>): string {
  return String(flags.backend || process.env.CHAMBER_SECRET_BACKEND || "ssm").toLowerCase();
}

function ensureBackend(flags: Record<string, any>) {
  const b = backend(flags);
  if (!["null", "ssm", "secretsmanager", "s3", "s3-kms"].includes(b)) fail(`Failed to get secret store: invalid backend \`${b.toUpperCase()}\``);
  return b;
}

function withUsage(cmd: string, msg: string) {
  err("Error: " + msg);
  err(helps[cmd]);
  process.exit(1);
}

function requireN(cmd: string, args: string[], n: number) {
  if (args.length !== n) withUsage(cmd, `accepts ${n} arg(s), received ${args.length}`);
}

function emptyStoreOrAws(flags: Record<string, any>) {
  const b = ensureBackend(flags);
  if (b !== "null") fail("operation requires AWS credentials or a configured backend");
}

function writeOutput(flags: Record<string, any>, text: string) {
  const file = flags["output-file"] || flags.o;
  if (file) fs.writeFileSync(file, text);
  else process.stdout.write(text);
}

function completion(shell: string) {
  if (!shell) { out(helps.completion); return; }
  if (["bash","zsh","fish","powershell"].includes(shell)) {
    out(`# ${shell} completion for chamber`);
    out(`# generated by chamber`);
    return;
  }
  fail(`unknown command "${shell}" for "chamber completion"`);
}

function main() {
  const rawArgv = process.argv.slice(2);
  const split = splitLeadingGlobals(rawArgv);
  const argv = split.rest;
  if (argv.length === 0 || argv[0] === "--help" || argv[0] === "-h") { out(globalHelp); return; }
  let cmd = argv[0];
  if (cmd === "help") {
    const h = argv[1] ? helps[argv[1]] || (argv[1] === "tag" ? helps.tag : "") : globalHelp;
    if (h) out(h); else fail(`unknown help topic "${argv[1]}"`);
    return;
  }
  if (cmd.startsWith("-")) fail(`unknown flag: ${cmd}`);
  const p = parse([...split.leading, ...argv.slice(1)]);
  if (p.flags.help) {
    if (cmd === "tag" && p.args[0] && tagHelps[p.args[0]]) out(tagHelps[p.args[0]]);
    else if (cmd === "completion" && p.args[0] && ["bash","zsh","fish","powershell"].includes(p.args[0])) out(completionHelp(p.args[0]));
    else if (helps[cmd]) out(helps[cmd]);
    else fail(`unknown command "${cmd}" for "chamber"`);
    return;
  }
  switch (cmd) {
    case "version": out("chamber dev"); return;
    case "list": {
      requireN("list", p.args, 1); emptyStoreOrAws(p.flags);
      out((p.flags.e || p.flags.expand) ? "Key\tVersion\t\tLastModified\tUser\tValue" : "Key\tVersion\t\tLastModified\tUser");
      return;
    }
    case "read": requireN("read", p.args, 2); emptyStoreOrAws(p.flags); fail("Failed to read: Not implemented for Null Store");
    case "write": {
      if (p.args.length !== 3) withUsage("write", `accepts 3 arg(s), received ${p.args.length}`);
      emptyStoreOrAws(p.flags); fail("Write is not implemented for Null Store");
    }
    case "delete": requireN("delete", p.args, 2); emptyStoreOrAws(p.flags); fail("Not implemented for Null Store");
    case "env": requireN("env", p.args, 1); emptyStoreOrAws(p.flags); return;
    case "export": {
      if (p.args.length < 1) withUsage("export", "requires at least 1 arg(s), only received 0");
      emptyStoreOrAws(p.flags);
      const f = p.flags.format || p.flags.f || "json";
      let text = "";
      if (f === "json" || f === "yaml") text = "{}\n";
      else if (["java-properties","csv","tsv","dotenv","tfvars"].includes(f)) text = "";
      else { err(`Error: Unable to export parameters: Unsupported export format: ${f}`); process.exit(1); }
      writeOutput(p.flags, text);
      return;
    }
    case "find": requireN("find", p.args, 1); emptyStoreOrAws(p.flags); out("Service"); return;
    case "history": requireN("history", p.args, 2); emptyStoreOrAws(p.flags); out("Event\tVersion\t\tDate\tUser"); return;
    case "list-services": {
      if (p.args.length > 1) withUsage("list-services", `accepts at most 1 arg(s), received ${p.args.length}`);
      emptyStoreOrAws(p.flags); out(p.flags.secrets || p.flags.s ? "Service\tKey" : "Service"); return;
    }
    case "import": {
      requireN("import", p.args, 2); emptyStoreOrAws(p.flags);
      if (p.args[1] === "-") try { fs.readFileSync(0, "utf8"); } catch {}
      fail("Failed to write secret: Write is not implemented for Null Store");
    }
    case "exec": {
      const idx = p.args.indexOf("--");
      if (idx < 0) withUsage("exec", "please separate services and command with '--'. See usage");
      const command = p.args[idx + 1];
      if (!command) withUsage("exec", "please provide command to execute");
      emptyStoreOrAws(p.flags);
      if (p.flags.strict) {
        const val = p.flags["strict-value"] || "chamberme";
        for (const [k, v] of Object.entries(process.env)) {
          if (v === val) fail(`parent env was expecting ${k}=${val}, but was not in store`);
        }
      }
      const env = p.flags.pristine ? {} : process.env;
      const res = spawnSync(command, p.args.slice(idx + 2), { stdio: "inherit", env, shell: false });
      if (res.error) fail(res.error.message);
      process.exit(res.status == null ? 1 : res.status);
    }
    case "tag": {
      const sub = p.args[0];
      if (!sub) { out(helps.tag); return; }
      const rest = p.args.slice(1);
      emptyStoreOrAws(p.flags);
      if (sub === "read") { if (rest.length !== 2) err(tagHelps.read); fail("Failed to read tags: Not implemented for Null Store"); }
      if (sub === "write") { if (rest.length < 3) err(tagHelps.write); fail("Failed to write tags: Not implemented for Null Store"); }
      if (sub === "delete") { if (rest.length < 3) err(tagHelps.delete); fail("Failed to delete tags: Not implemented for Null Store"); }
      fail(`unknown command "${sub}" for "chamber tag"`);
    }
    case "completion": completion(p.args[0]); return;
    default:
      err(`Error: unknown command "${cmd}" for "chamber"`);
      err(`Run 'chamber --help' for usage.`);
      process.exit(1);
  }
}

main();
