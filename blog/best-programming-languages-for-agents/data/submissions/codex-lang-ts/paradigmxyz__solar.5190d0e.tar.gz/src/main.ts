declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");

const VERSION = "0.1.8";
const EVM_VALUES = [
  "homestead", "tangerineWhistle", "spuriousDragon", "byzantium",
  "constantinople", "petersburg", "istanbul", "berlin", "london", "paris",
  "shanghai", "cancun", "prague", "osaka",
];
const STOPS = ["parsing", "lowering", "analysis"];
const COLORS = ["auto", "always", "never"];
const ERROR_FORMATS = ["human", "json", "rustc-json"];
const HUMAN_FORMATS = ["ascii", "unicode", "short"];

type AbiParam = { name: string; type: string; internalType: string; indexed?: boolean };
type AbiItem = any;
type ContractOut = { abi?: AbiItem[]; hashes?: Record<string, string> };

function fullHelp(): string {
  return `Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...
          Files to compile, or import remappings.
          
          \`-\` specifies standard input.
          
          Import remappings are specified as \`[context:]prefix=path\`. See <https://docs.soliditylang.org/en/latest/path-resolution.html#import-remapping>.

Options:
  -j, --threads <THREADS>
          Number of threads to use. Zero specifies the number of logical cores
          
          [default: 4]
          [aliases: --jobs]

      --evm-version <EVM_VERSION>
          EVM version
          
          [default: prague]
          [possible values: ${EVM_VALUES.join(", ")}]

      --stop-after <STOP_AFTER>
          Stop execution after the given compiler stage
          
          [possible values: ${STOPS.join(", ")}]

      --out-dir <OUT_DIR>
          Directory to write output files

      --emit <EMIT>
          Comma separated list of types of output for the compiler to emit
          
          [possible values: abi, hashes]

  -Z <FLAG>
          Unstable flags. WARNING: these are completely unstable, and may change at any time.
          
          See \`-Zhelp\` for more details.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Input options:
      --base-path <BASE_PATH>
          Use the given path as the root of the source tree

  -I, --include-path <INCLUDE_PATH>
          Directory to search for files.
          
          Can be used multiple times.

      --allow-paths <ALLOW_PATHS>
          Allow a given path for imports

Display options:
      --color <COLOR>
          Coloring
          
          [default: auto]
          [possible values: auto, always, never]

  -v, --verbose
          Use verbose output

      --pretty-json
          Pretty-print JSON output.
          
          Does not include errors. See \`--pretty-json-err\`.

      --pretty-json-err
          Pretty-print error JSON output

      --error-format <ERROR_FORMAT>
          How errors and other messages are produced
          
          [default: human]
          [possible values: human, json, rustc-json]

      --error-format-human <VALUE>
          Human-readable error message style
          
          [default: unicode]
          [possible values: ascii, unicode, short]

      --diagnostic-width <WIDTH>
          Terminal width for error message formatting

      --no-warnings
          Whether to disable warnings
`;
}

function shortHelp(): string {
  return `Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Files to compile, or import remappings

Options:
  -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]
      --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: ${EVM_VALUES.join(", ")}]
      --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: ${STOPS.join(", ")}]
      --out-dir <OUT_DIR>          Directory to write output files
      --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]
  -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version

Input options:
      --base-path <BASE_PATH>        Use the given path as the root of the source tree
  -I, --include-path <INCLUDE_PATH>  Directory to search for files
      --allow-paths <ALLOW_PATHS>    Allow a given path for imports

Display options:
      --color <COLOR>                Coloring [default: auto] [possible values: auto, always, never]
  -v, --verbose                      Use verbose output
      --pretty-json                  Pretty-print JSON output
      --pretty-json-err              Pretty-print error JSON output
      --error-format <ERROR_FORMAT>  How errors and other messages are produced [default: human] [possible values: human, json, rustc-json]
      --error-format-human <VALUE>   Human-readable error message style [default: unicode] [possible values: ascii, unicode, short]
      --diagnostic-width <WIDTH>     Terminal width for error message formatting
      --no-warnings                  Whether to disable warnings
`;
}

function zHelp(): string {
  return `error: List of all unstable flags.
WARNING: these are completely unstable, and may change at any time!

Options:
      -Zui-testing
          Enables UI testing mode

      -Ztrack-diagnostics
          Prints a note for every diagnostic that is emitted with the creation and emission location.
          
          This is enabled by default on debug builds.

      -Zparse-yul
          Enables parsing Yul files for testing

      -Zno-resolve-imports
          Disables import resolution

      -Zdump=<KIND[=PATHS...]>
          Print additional information about the compiler's internal state.
          
          Valid kinds are \`ast\` and \`hir\`.

      -Zast-stats
          Print AST stats

      -Zspan-visitor
          Run the span visitor after parsing

      -Zprint-max-storage-sizes
          Print contracts' max storage sizes

      -Ztypeck
          Type check the program. WIP

      -Zhelp
          Print help

Usage: solar [OPTIONS] [INPUT]...

For more information, try '--help'.
`;
}

function version(): string {
  return `solar Version: 0.1.8
Commit SHA: 8f228ae9f0bd90ad4ec81fb1ef4fbba29748b8d5
Build Timestamp: 2026-04-17T19:59:51.519973035Z
Build Features: mimalloc,tracing
Build Profile: release
`;
}

function dieCli(msg: string, extra = ""): void {
  process.stderr.write(`error: ${msg}\n${extra}\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function parseArgs(argv: string[]) {
  const opts: any = { emit: [] as string[], inputs: [] as string[], pretty: false, errFmt: "human", outDir: "" };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const take = (name: string) => {
      if (i + 1 >= argv.length) dieCli(`a value is required for '${name} <${name.replace(/^--?/, "").toUpperCase()}>' but none was supplied`);
      return argv[++i];
    };
    if (a === "--") { opts.inputs.push(...argv.slice(i + 1)); break; }
    else if (a === "-h") { process.stdout.write(shortHelp()); process.exit(0); }
    else if (a === "--help") { process.stdout.write(fullHelp()); process.exit(0); }
    else if (a === "-V" || a === "--version") { process.stdout.write(version()); process.exit(0); }
    else if (a === "-Zhelp" || (a === "-Z" && argv[i + 1] === "help")) { process.stderr.write(zHelp()); process.exit(0); }
    else if (a === "-Z") { i++; }
    else if (a.startsWith("-Z")) {}
    else if (a === "-") opts.inputs.push(a);
    else if (a === "-j" || a === "--threads" || a === "--jobs" || a === "--base-path" || a === "--allow-paths" || a === "--diagnostic-width") { take(a); }
    else if (a === "-I" || a === "--include-path") { take(a); }
    else if (a === "--out-dir") { opts.outDir = take(a); }
    else if (a === "--pretty-json") opts.pretty = true;
    else if (a === "--pretty-json-err") opts.prettyErr = true;
    else if (a === "--no-warnings" || a === "-v" || a === "--verbose") {}
    else if (a === "--emit") {
      const v = take(a);
      for (const e of v.split(",")) {
        if (e !== "abi" && e !== "hashes") dieCli(`invalid value '${e}' for '--emit <EMIT>'`, "  [possible values: abi, hashes]\n");
        if (!opts.emit.includes(e)) opts.emit.push(e);
      }
    } else if (a === "--evm-version") {
      const v = take(a);
      if (!EVM_VALUES.includes(v)) dieCli(`invalid value '${v}' for '--evm-version <EVM_VERSION>'`, `  [possible values: ${EVM_VALUES.join(", ")}]\n`);
    } else if (a === "--stop-after") {
      const v = take(a);
      if (!STOPS.includes(v)) dieCli(`invalid value '${v}' for '--stop-after <STOP_AFTER>'`, `  [possible values: ${STOPS.join(", ")}]\n`);
      opts.stopAfter = v;
    } else if (a === "--color") {
      const v = take(a);
      if (!COLORS.includes(v)) dieCli(`invalid value '${v}' for '--color <COLOR>'`, `  [possible values: ${COLORS.join(", ")}]\n`);
    } else if (a === "--error-format") {
      const v = take(a);
      if (!ERROR_FORMATS.includes(v)) dieCli(`invalid value '${v}' for '--error-format <ERROR_FORMAT>'`, `  [possible values: ${ERROR_FORMATS.join(", ")}]\n`);
      opts.errFmt = v;
    } else if (a === "--error-format-human") {
      const v = take(a);
      if (!HUMAN_FORMATS.includes(v)) dieCli(`invalid value '${v}' for '--error-format-human <VALUE>'`, `  [possible values: ${HUMAN_FORMATS.join(", ")}]\n`);
    } else if (a.startsWith("-")) {
      dieCli(`unexpected argument '${a}' found`, `\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [INPUT]...\n`);
    } else opts.inputs.push(a);
  }
  return opts;
}

function stripComments(s: string): string {
  return s.replace(/\/\*[\s\S]*?\*\//g, m => " ".repeat(m.length)).replace(/\/\/.*$/gm, m => " ".repeat(m.length));
}

function findMatching(s: string, open: number, l = "{", r = "}"): number {
  let d = 0, str = "";
  for (let i = open; i < s.length; i++) {
    const c = s[i], p = s[i - 1];
    if (str) { if (c === str && p !== "\\") str = ""; continue; }
    if (c === "\"" || c === "'") { str = c; continue; }
    if (c === l) d++;
    else if (c === r && --d === 0) return i;
  }
  return -1;
}

function splitTop(s: string, sep = ","): string[] {
  const out: string[] = [];
  let d = 0, last = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === "(" || c === "[" || c === "{") d++;
    else if (c === ")" || c === "]" || c === "}") d--;
    else if (c === sep && d === 0) { out.push(s.slice(last, i).trim()); last = i + 1; }
  }
  const tail = s.slice(last).trim();
  if (tail) out.push(tail);
  return out;
}

function canonicalType(t: string): string {
  let x = t.trim().replace(/\s+/g, " ");
  x = x.replace(/\b(memory|calldata|storage|payable|indexed)\b/g, "").replace(/\s+/g, " ").trim();
  x = x.replace(/\buint\b/g, "uint256").replace(/\bint\b/g, "int256");
  x = x.replace(/\s*\[\s*\]/g, "[]").replace(/\s*\[\s*([0-9]+)\s*\]/g, "[$1]");
  x = x.replace(/\s+/g, "");
  return x;
}

function internalType(t: string): string {
  let x = t.trim().replace(/\b(memory|calldata|storage|indexed)\b/g, "").replace(/\s+/g, " ").trim();
  x = x.replace(/\buint\b/g, "uint256").replace(/\bint\b/g, "int256");
  x = x.replace(/\s*\[\s*\]/g, "[]").replace(/\s*\[\s*([0-9]+)\s*\]/g, "[$1]");
  return x;
}

const paramMods = new Set(["memory", "calldata", "storage", "indexed"]);
function parseParams(s: string, eventMode = false): AbiParam[] {
  if (!s.trim()) return [];
  return splitTop(s).map((p) => {
    const toks = p.trim().split(/\s+/).filter(Boolean);
    let indexed = false;
    const core: string[] = [];
    for (const tok of toks) {
      if (tok === "indexed") { indexed = true; continue; }
      core.push(tok);
    }
    let name = "";
    if (core.length > 1 && /^[A-Za-z_$][\w$]*$/.test(core[core.length - 1]) && !paramMods.has(core[core.length - 1])) {
      name = core.pop() || "";
    }
    const raw = core.join(" ");
    const obj: AbiParam = eventMode
      ? ({ name, type: canonicalType(raw), indexed, internalType: internalType(raw) } as AbiParam)
      : { name, type: canonicalType(raw), internalType: internalType(raw) };
    return obj;
  });
}

function topLevelStatements(body: string): string[] {
  const out: string[] = [];
  let dParen = 0, dBrace = 0, start = 0;
  for (let i = 0; i < body.length; i++) {
    const c = body[i];
    if (c === "(") dParen++;
    else if (c === ")") dParen--;
    else if (c === "{") {
      if (dBrace === 0 && dParen === 0) {
        out.push(body.slice(start, i).trim());
        const end = findMatching(body, i);
        i = end < 0 ? body.length : end;
        start = i + 1;
        continue;
      }
      dBrace++;
    } else if (c === "}") dBrace--;
    else if (c === ";" && dParen === 0 && dBrace === 0) {
      out.push(body.slice(start, i).trim());
      start = i + 1;
    }
  }
  return out.filter(Boolean);
}

function stateMut(stmt: string): string {
  if (/\bpayable\b/.test(stmt)) return "payable";
  if (/\bview\b/.test(stmt)) return "view";
  if (/\bpure\b/.test(stmt)) return "pure";
  return "nonpayable";
}

function parseReturns(rest: string): AbiParam[] {
  const m = /\breturns\s*\(/.exec(rest);
  if (!m) return [];
  const open = (m.index || 0) + m[0].lastIndexOf("(");
  const close = findMatching(rest, open, "(", ")");
  return parseParams(rest.slice(open + 1, close));
}

function parseVar(stmt: string): AbiItem | null {
  if (!/\bpublic\b/.test(stmt)) return null;
  const clean = stmt.trim().startsWith("mapping") ? stmt.trim() : stmt.replace(/=.*$/, "").trim();
  const map = /mapping\s*\(([\s\S]*?)=>\s*([\s\S]*?)\)\s+(?:[A-Za-z_][\w]*\s+)*public(?:\s+[A-Za-z_][\w]*)*\s+([A-Za-z_$][\w$]*)$/.exec(clean);
  if (map) {
    const key = parseParams(map[1].trim())[0] || { name: "", type: canonicalType(map[1]), internalType: internalType(map[1]) };
    key.name = "";
    return { type: "function", name: map[3], inputs: [key], outputs: [{ name: "", type: canonicalType(map[2]), internalType: internalType(map[2]) }], stateMutability: "view" };
  }
  const toks = clean.split(/\s+/).filter(t => !["public", "private", "internal", "external", "constant", "immutable", "override"].includes(t));
  if (toks.length < 2) return null;
  const name = toks[toks.length - 1];
  if (!/^[A-Za-z_$][\w$]*$/.test(name)) return null;
  const typ = toks.slice(0, -1).join(" ");
  let inputs: AbiParam[] = [];
  let outType = typ;
  const arr = typ.match(/^(.*)\[[0-9]*\]$/);
  if (arr) {
    inputs = [{ name: "", type: "uint256", internalType: "uint256" }];
    outType = arr[1];
  }
  return { type: "function", name, inputs, outputs: [{ name: "", type: canonicalType(outType), internalType: internalType(outType) }], stateMutability: "view" };
}

function parseContract(file: string, name: string, body: string): AbiItem[] {
  const abi: AbiItem[] = [];
  for (const stmt of topLevelStatements(body)) {
    let m;
    if ((m = /^constructor\s*\(([\s\S]*)\)([\s\S]*)$/.exec(stmt))) {
      abi.push({ type: "constructor", inputs: parseParams(m[1]), stateMutability: stateMut(m[2]) });
    } else if ((m = /^event\s+([A-Za-z_$][\w$]*)\s*\(([\s\S]*)\)([\s\S]*)$/.exec(stmt))) {
      abi.push({ type: "event", name: m[1], inputs: parseParams(m[2], true), anonymous: /\banonymous\b/.test(m[3]) });
    } else if ((m = /^error\s+([A-Za-z_$][\w$]*)\s*\(([\s\S]*)\)/.exec(stmt))) {
      abi.push({ type: "error", name: m[1], inputs: parseParams(m[2]) });
    } else if ((m = /^function\s+([A-Za-z_$][\w$]*)\s*\(([\s\S]*?)\)([\s\S]*)$/.exec(stmt))) {
      if (/\b(private|internal)\b/.test(m[3])) continue;
      abi.push({ type: "function", name: m[1], inputs: parseParams(m[2]), outputs: parseReturns(m[3]), stateMutability: stateMut(m[3]) });
    } else if ((m = /^fallback\s*\(([\s\S]*?)\)?([\s\S]*)$/.exec(stmt))) {
      abi.push({ type: "fallback", stateMutability: stateMut(m[2] || stmt) });
    } else if ((m = /^receive\s*\(\s*\)([\s\S]*)$/.exec(stmt))) {
      abi.push({ type: "receive", stateMutability: stateMut(m[1]) });
    } else {
      const v = parseVar(stmt);
      if (v) abi.push(v);
    }
  }
  return abi.sort((a, b) => {
    const rank: any = { constructor: 0, error: 1, event: 2, fallback: 3, function: 4, receive: 5 };
    const r = rank[a.type] - rank[b.type];
    if (r) return r;
    return String(a.name || "").localeCompare(String(b.name || ""));
  });
}

function parseSource(file: string, src: string): Record<string, AbiItem[]> {
  const s = stripComments(src);
  const out: Record<string, AbiItem[]> = {};
  const re = /\b(?:abstract\s+)?(?:contract|interface|library)\s+([A-Za-z_$][\w$]*)[^{;]*\{/g;
  let m;
  while ((m = re.exec(s))) {
    const open = re.lastIndex - 1;
    const close = findMatching(s, open);
    if (close < 0) continue;
    out[`${file}:${m[1]}`] = parseContract(file, m[1], s.slice(open + 1, close));
    re.lastIndex = close + 1;
  }
  return Object.fromEntries(Object.entries(out).sort(([a], [b]) => a.localeCompare(b)));
}

function selectorSig(item: AbiItem): string {
  return `${item.name}(${(item.inputs || []).map((p: AbiParam) => p.type).join(",")})`;
}

function build(inputs: string[], emits: string[], errFmt: string): any {
  if (!inputs.length) {
    process.stdout.write(shortHelp());
    process.exit(2);
  }
  const contracts: Record<string, ContractOut> = {};
  for (const input of inputs) {
    if (input.includes("=") && !fs.existsSync(input)) continue;
    let content = "";
    let label = input;
    if (input === "-") {
      content = fs.readFileSync(0, "utf8");
      label = "<stdin>";
    } else {
      if (!fs.existsSync(input)) diagnostic(`file ${input} not found`, errFmt, null, true);
      content = fs.readFileSync(input, "utf8");
    }
    const parsed = parseSource(label, content);
    for (const [key, abi] of Object.entries(parsed)) {
      const o: ContractOut = {};
      if (emits.includes("abi")) o.abi = abi;
      if (emits.includes("hashes")) {
        const hashes: Record<string, string> = {};
        for (const item of abi) if (item.type === "function") {
          const sig = selectorSig(item);
          hashes[sig] = keccak256(Buffer.from(sig, "utf8")).slice(0, 4).toString("hex");
        }
        o.hashes = Object.fromEntries(Object.entries(hashes).sort(([a], [b]) => a.localeCompare(b)));
      }
      contracts[key] = o;
    }
  }
  return { contracts, version: VERSION };
}

function diagnostic(message: string, fmt: string, loc: any = null, abort = false): void {
  const formatted = `error: ${message}\n\n`;
  if (fmt === "json") {
    process.stderr.write(JSON.stringify({ sourceLocation: loc, secondarySourceLocations: [], type: "Exception", component: "general", severity: "error", errorCode: null, message, formattedMessage: formatted }) + "\n");
  } else if (fmt === "rustc-json") {
    process.stderr.write(JSON.stringify({ "$message_type": "diagnostic", message, code: null, level: "error", spans: [], children: [], rendered: formatted }) + "\n");
  } else {
    process.stderr.write(formatted);
  }
  if (abort) {
    const msg = "aborting due to 1 previous error";
    if (fmt === "human") process.stderr.write(`error: ${msg}\n\n`);
    else diagnostic(msg, fmt, null, false);
    process.exit(1);
  }
  process.exit(1);
}

const RC = [
  0x0000000000000001n, 0x0000000000008082n, 0x800000000000808an, 0x8000000080008000n,
  0x000000000000808bn, 0x0000000080000001n, 0x8000000080008081n, 0x8000000000008009n,
  0x000000000000008an, 0x0000000000000088n, 0x0000000080008009n, 0x000000008000000an,
  0x000000008000808bn, 0x800000000000008bn, 0x8000000000008089n, 0x8000000000008003n,
  0x8000000000008002n, 0x8000000000000080n, 0x000000000000800an, 0x800000008000000an,
  0x8000000080008081n, 0x8000000000008080n, 0x0000000080000001n, 0x8000000080008008n,
];
const ROT = [
  0, 1, 62, 28, 27, 36, 44, 6, 55, 20, 3, 10, 43, 25, 39, 41, 45, 15, 21, 8, 18, 2, 61, 56, 14,
];
const PI = [
  0, 10, 20, 5, 15, 16, 1, 11, 21, 6, 7, 17, 2, 12, 22, 23, 8, 18, 3, 13, 14, 24, 9, 19, 4,
];
const MASK = (1n << 64n) - 1n;
function rol(x: bigint, n: number): bigint {
  if (n === 0) return x & MASK;
  return ((x << BigInt(n)) | (x >> BigInt(64 - n))) & MASK;
}
function keccakF(a: bigint[]) {
  for (let round = 0; round < 24; round++) {
    const c: bigint[] = Array(5).fill(0n), d: bigint[] = Array(5).fill(0n);
    for (let x = 0; x < 5; x++) c[x] = a[x] ^ a[x + 5] ^ a[x + 10] ^ a[x + 15] ^ a[x + 20];
    for (let x = 0; x < 5; x++) d[x] = c[(x + 4) % 5] ^ rol(c[(x + 1) % 5], 1);
    for (let i = 0; i < 25; i += 5) for (let x = 0; x < 5; x++) a[i + x] = (a[i + x] ^ d[x]) & MASK;
    const b: bigint[] = Array(25).fill(0n);
    for (let i = 0; i < 25; i++) b[PI[i]] = rol(a[i], ROT[i]);
    for (let y = 0; y < 25; y += 5) for (let x = 0; x < 5; x++) a[y + x] = (b[y + x] ^ ((~b[y + ((x + 1) % 5)]) & b[y + ((x + 2) % 5)])) & MASK;
    a[0] = (a[0] ^ RC[round]) & MASK;
  }
}
function keccak256(data: any): any {
  const rate = 136;
  const a: bigint[] = Array(25).fill(0n);
  const bytes: number[] = Array.from(data as number[]);
  bytes.push(0x01);
  while ((bytes.length % rate) !== rate - 1) bytes.push(0);
  bytes.push(0x80);
  for (let off = 0; off < bytes.length; off += rate) {
    for (let i = 0; i < rate / 8; i++) {
      let v = 0n;
      for (let j = 0; j < 8; j++) v |= BigInt(bytes[off + i * 8 + j]) << BigInt(8 * j);
      a[i] ^= v;
    }
    keccakF(a);
  }
  const out: number[] = [];
  for (let i = 0; out.length < 32; i++) for (let j = 0; j < 8 && out.length < 32; j++) out.push(Number((a[i] >> BigInt(8 * j)) & 0xffn));
  return Buffer.from(out);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const emits = opts.emit.length ? opts.emit : [];
  if (opts.stopAfter && !emits.length) process.exit(0);
  const result = build(opts.inputs, emits, opts.errFmt);
  if (!emits.length) process.exit(0);
  const text = JSON.stringify(result, null, opts.pretty ? 2 : 0);
  if (opts.outDir) {
    fs.mkdirSync(opts.outDir, { recursive: true });
    fs.writeFileSync(path.join(opts.outDir, "combined.json"), text);
  } else {
    process.stdout.write(text);
  }
}

main();
