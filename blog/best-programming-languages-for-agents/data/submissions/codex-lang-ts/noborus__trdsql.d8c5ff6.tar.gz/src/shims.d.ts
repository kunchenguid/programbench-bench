declare const process: any;
declare function require(name: string): any;
