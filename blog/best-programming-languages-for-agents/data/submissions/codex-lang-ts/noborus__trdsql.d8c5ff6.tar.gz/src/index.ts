const fs = require("fs");
const path = require("path");

type Row = Record<string, any>;

interface Options {
  inputFormat?: string;
  outputFormat: string;
  inputDelimiter: string;
  outputDelimiter: string;
  quote: string;
  inputHeader: boolean;
  outputHeader: boolean;
  allQuotes: boolean;
  crlf: boolean;
  tableFile?: string;
  queryFile?: string;
  outFile?: string;
  skip: number;
  limitRead: number;
  rowNumber: boolean;
  inputNull?: string;
  outputNull?: string;
  analyze?: string;
  analyzeOnly?: string;
  version: boolean;
  help: boolean;
  dblist: boolean;
  jq?: string;
}

const HELP = `trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.

Usage
\ttrdsql [OPTIONS] [SQL(SELECT...)]

Options:
  -A string           analyze the file but only suggest SQL.
  -a string           analyze the file and suggest SQL.
  -config string      configuration file location.
  -db string          specify db name of the setting.
  -dblist             display db information.
  -debug              debug print.
  -driver string      database driver.  [ mysql | postgres | sqlite3 | sqlite3_ext ]
  -dsn string         database driver specific data source name.
  -help               display usage information.
  -q string           read query from the specified file.
  -t string           read table name from the specified file.
  -version            display version information.

Input Formats:
  -icsv               CSV format for input.
  -ig                 guess format from extension. (default "true")
  -ijson              JSON format for input.
  -iltsv              LTSV format for input.
  -itbln              TBLN format for input.
  -itext              text format for input.
  -iwidth             width specification format for input.
  -iyaml              YAML format for input.

Input options:
  -id string          field delimiter for input. (default ",")
  -ih                 the first line is interpreted as column names(CSV only).
  -ijq string         jq expression string for input(JSON/JSONL only).
  -ilr int            limited number of rows to read. (default 0)
  -inull value        value(string) to convert to null on input.
  -inum               add row number column.
  -ir int             number of rows to preread. (default 1)
  -is int             skip header row. (default 0)

Output Formats:
  -oat                ASCII Table format for output.
  -ocsv               CSV format for output.
  -ojson              JSON format for output.
  -ojsonl             JSON lines format for output.
  -oltsv              LTSV format for output.
  -omd                Markdown format for output.
  -oraw               Raw format for output.
  -otbln              TBLN format for output.
  -ovf                Vertical format for output.
  -oyaml              YAML format for output.

Output options:
  -oaq                enclose all fields in quotes for output.
  -ocrlf              use CRLF for output. End each output line with '\\r\\n' instead of '\\n'.
  -od string          field delimiter for output. (default ",")
  -oh                 output column name as header.
  -onowrap            do not wrap long lines(at/md only).
  -onull value        value(string) to convert from null on output.
  -oq string          quote character for output. (default "\\"")
  -out string         output file name.
  -out-without-guess  output without guessing (when using -out).
  -oz string          output compression format. [ gz | bz2 | zstd | lz4 | xz ]

Examples:
  $ trdsql "SELECT c1,c2 FROM test.csv"
  $ trdsql -oltsv "SELECT c1,c2 FROM test.json::.items"
  $ cat test.csv | trdsql -icsv -oltsv "SELECT c1,c2 FROM -"`;

function parseArgs(argv: string[]): { opts: Options; sql?: string } {
  const opts: Options = {
    outputFormat: "csv",
    inputDelimiter: ",",
    outputDelimiter: ",",
    quote: "\"",
    inputHeader: false,
    outputHeader: false,
    allQuotes: false,
    crlf: false,
    skip: 0,
    limitRead: 0,
    rowNumber: false,
    version: false,
    help: false,
    dblist: false,
  };
  const rest: string[] = [];
  const needVal = new Set(["-A","-a","-config","-db","-driver","-dsn","-q","-t","-id","-ijq","-ilr","-inull","-ir","-is","-od","-onull","-oq","-out","-oz"]);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith("-") || a === "-") { rest.push(a); continue; }
    const v = needVal.has(a) ? argv[++i] : undefined;
    switch (a) {
      case "-help": case "--help": opts.help = true; break;
      case "-version": case "--version": opts.version = true; break;
      case "-dblist": opts.dblist = true; break;
      case "-q": opts.queryFile = v; break;
      case "-t": opts.tableFile = v; break;
      case "-a": opts.analyze = v; break;
      case "-A": opts.analyzeOnly = v; break;
      case "-icsv": opts.inputFormat = "csv"; break;
      case "-ijson": opts.inputFormat = "json"; break;
      case "-iltsv": opts.inputFormat = "ltsv"; break;
      case "-iyaml": opts.inputFormat = "yaml"; break;
      case "-itbln": opts.inputFormat = "tbln"; break;
      case "-itext": opts.inputFormat = "text"; break;
      case "-iwidth": opts.inputFormat = "text"; break;
      case "-id": opts.inputDelimiter = v ?? ","; break;
      case "-ih": opts.inputHeader = true; break;
      case "-ijq": opts.jq = v; break;
      case "-ilr": opts.limitRead = parseInt(v || "0", 10) || 0; break;
      case "-inull": opts.inputNull = v; break;
      case "-inum": opts.rowNumber = true; break;
      case "-is": opts.skip = parseInt(v || "0", 10) || 0; break;
      case "-ocsv": opts.outputFormat = "csv"; break;
      case "-ojson": opts.outputFormat = "json"; break;
      case "-ojsonl": opts.outputFormat = "jsonl"; break;
      case "-oltsv": opts.outputFormat = "ltsv"; break;
      case "-omd": opts.outputFormat = "md"; break;
      case "-oat": opts.outputFormat = "at"; break;
      case "-oraw": opts.outputFormat = "raw"; break;
      case "-otbln": opts.outputFormat = "tbln"; break;
      case "-ovf": opts.outputFormat = "vf"; break;
      case "-oyaml": opts.outputFormat = "yaml"; break;
      case "-oaq": opts.allQuotes = true; break;
      case "-ocrlf": opts.crlf = true; break;
      case "-od": opts.outputDelimiter = v ?? ","; break;
      case "-oh": opts.outputHeader = true; break;
      case "-oq": opts.quote = v ?? "\""; break;
      case "-onull": opts.outputNull = v; break;
      case "-out": opts.outFile = v; break;
      default:
        if (a === "-ig" || a === "-onowrap" || a === "-out-without-guess" || a === "-debug") break;
        if (needVal.has(a)) break;
        rest.push(a);
    }
  }
  let sql = rest.join(" ");
  if (opts.queryFile) sql = fs.readFileSync(opts.queryFile, "utf8").trim();
  return { opts, sql: sql || undefined };
}

function splitCsvLine(line: string, delim: string): string[] {
  const out: string[] = [];
  let cur = "", inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === "\"") {
      if (inQ && line[i + 1] === "\"") { cur += "\""; i++; }
      else inQ = !inQ;
    } else if (!inQ && line.startsWith(delim, i)) {
      out.push(cur); cur = ""; i += delim.length - 1;
    } else cur += ch;
  }
  out.push(cur);
  return out;
}

function rowsFromCsv(text: string, opts: Options): { rows: Row[]; columns: string[] } {
  let lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  if (opts.skip) lines = lines.slice(opts.skip);
  if (opts.limitRead) lines = lines.slice(0, opts.limitRead + (opts.inputHeader ? 1 : 0));
  if (lines.length === 0) return { rows: [], columns: [] };
  const first = splitCsvLine(lines[0], opts.inputDelimiter);
  const columns = opts.inputHeader ? first : first.map((_, i) => `c${i + 1}`);
  const data = opts.inputHeader ? lines.slice(1) : lines;
  const rows = data.map((line, idx) => {
    const vals = splitCsvLine(line, opts.inputDelimiter);
    const r: Row = {};
    columns.forEach((c, i) => r[c] = convertIn(vals[i] ?? "", opts));
    if (opts.rowNumber) return { c1: String(idx + 1), ...shiftCols(r, columns) };
    return r;
  });
  return { rows, columns: opts.rowNumber ? ["c1", ...columns] : columns };
}

function shiftCols(r: Row, columns: string[]): Row {
  const o: Row = {};
  columns.forEach(c => o[c] = r[c]);
  return o;
}

function convertIn(v: any, opts: Options): any {
  if (opts.inputNull !== undefined && v === opts.inputNull) return null;
  return v;
}

function flattenJson(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (data && typeof data === "object") {
    const keys = Object.keys(data);
    if (keys.length === 1 && Array.isArray(data[keys[0]])) return data[keys[0]];
    return [data];
  }
  return [{ c1: data }];
}

function rowsFromJson(text: string, opts: Options): { rows: Row[]; columns: string[] } {
  text = text.trim();
  let arr: any[];
  try { arr = flattenJson(JSON.parse(text)); }
  catch {
    arr = text.split(/\r?\n/).filter(Boolean).flatMap((l: string) => flattenJson(JSON.parse(l)));
  }
  if (opts.jq && opts.jq.startsWith(".")) {
    const key = opts.jq.replace(/^\./, "").replace(/^\[\]\.?/, "");
    if (key) arr = arr.flatMap(x => flattenJson(x?.[key]));
  }
  if (opts.limitRead) arr = arr.slice(0, opts.limitRead);
  const columns: string[] = [];
  const rows = arr.map((item: any) => {
    if (!item || typeof item !== "object" || Array.isArray(item)) item = { c1: item };
    const r: Row = {};
    Object.keys(item).forEach(k => {
      if (!columns.includes(k)) columns.push(k);
      const v = item[k];
      r[k] = v === null || v === undefined ? null : (typeof v === "object" ? v : String(v));
    });
    return r;
  });
  return { rows, columns };
}

function rowsFromLtsv(text: string, opts: Options): { rows: Row[]; columns: string[] } {
  const columns: string[] = [];
  let lines = text.replace(/\r\n/g, "\n").split("\n").filter(Boolean);
  if (opts.skip) lines = lines.slice(opts.skip);
  if (opts.limitRead) lines = lines.slice(0, opts.limitRead);
  const rows = lines.map(line => {
    const r: Row = {};
    line.split("\t").forEach(part => {
      const p = part.indexOf(":");
      const k = p >= 0 ? part.slice(0, p) : `c${Object.keys(r).length + 1}`;
      const v = p >= 0 ? part.slice(p + 1) : part;
      if (!columns.includes(k)) columns.push(k);
      r[k] = convertIn(v, opts);
    });
    return r;
  });
  return { rows, columns };
}

function rowsFromYaml(text: string, opts: Options): { rows: Row[]; columns: string[] } {
  const rows: Row[] = [];
  let cur: Row | null = null;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    let s = line;
    if (s.startsWith("- ")) { if (cur) rows.push(cur); cur = {}; s = s.slice(2); }
    if (!cur) cur = {};
    const m = s.match(/^([^:]+):\s*(.*)$/);
    if (m) cur[m[1].trim()] = m[2].replace(/^['"]|['"]$/g, "");
  }
  if (cur) rows.push(cur);
  const columns = Array.from(new Set(rows.flatMap(r => Object.keys(r))));
  if (opts.limitRead) return { rows: rows.slice(0, opts.limitRead), columns };
  return { rows, columns };
}

function loadTable(file: string, opts: Options): { rows: Row[]; columns: string[] } {
  const text = file === "-" ? fs.readFileSync(0, "utf8") : fs.readFileSync(file, "utf8");
  let fmt = opts.inputFormat;
  const clean = file.split("::")[0];
  if (!fmt) {
    const ext = path.extname(clean).toLowerCase();
    if (ext === ".json" || ext === ".jsonl") fmt = "json";
    else if (ext === ".ltsv") fmt = "ltsv";
    else if (ext === ".yaml" || ext === ".yml") fmt = "yaml";
    else fmt = "csv";
  }
  if (fmt === "json") return rowsFromJson(text, opts);
  if (fmt === "ltsv") return rowsFromLtsv(text, opts);
  if (fmt === "yaml") return rowsFromYaml(text, opts);
  if (fmt === "text" || fmt === "tbln") {
    const lines = text.split(/\r?\n/).filter(Boolean);
    return { rows: lines.map(l => ({ c1: l })), columns: ["c1"] };
  }
  return rowsFromCsv(text, opts);
}

function parseSql(sql: string): any {
  sql = sql.trim().replace(/;$/, "");
  const m = sql.match(/^select\s+([\s\S]+?)\s+from\s+(`[^`]+`|"[^"]+"|'[^']+'|[^\s]+)([\s\S]*)$/i);
  if (!m) return null;
  let rest = m[3] || "";
  const grab = (kw: string, stop: string[]) => {
    const re = new RegExp("\\s+" + kw + "\\s+([\\s\\S]*?)(?=" + stop.map(s => "\\s+" + s + "\\s+").join("|") + "|$)", "i");
    const mm = rest.match(re);
    return mm ? mm[1].trim() : undefined;
  };
  return {
    select: m[1].trim(),
    file: unquote(m[2].trim()),
    where: grab("where", ["group by", "order by", "limit"]),
    groupBy: grab("group by", ["order by", "limit"]),
    orderBy: grab("order by", ["limit"]),
    limit: (() => { const x = grab("limit", []); return x ? parseInt(x, 10) : undefined; })(),
  };
}

function unquote(s: string): string {
  if ((s[0] === "`" && s.endsWith("`")) || (s[0] === "\"" && s.endsWith("\"")) || (s[0] === "'" && s.endsWith("'"))) return s.slice(1, -1);
  return s;
}

function splitSelect(s: string): string[] {
  const out: string[] = []; let cur = "", depth = 0, q = "";
  for (const ch of s) {
    if (q) { cur += ch; if (ch === q) q = ""; continue; }
    if (ch === "'" || ch === "\"") { q = ch; cur += ch; continue; }
    if (ch === "(") depth++; else if (ch === ")") depth--;
    if (ch === "," && depth === 0) { out.push(cur.trim()); cur = ""; } else cur += ch;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function val(row: Row, expr: string): any {
  expr = expr.trim();
  if ((expr[0] === "'" && expr.endsWith("'")) || (expr[0] === "\"" && expr.endsWith("\""))) return expr.slice(1, -1);
  if (/^-?\d+(\.\d+)?$/.test(expr)) return Number(expr);
  return row[unquote(expr)] ?? "";
}

function cmp(a: any, op: string, b: any): boolean {
  const na = Number(a), nb = Number(b);
  const num = a !== "" && b !== "" && !Number.isNaN(na) && !Number.isNaN(nb);
  const x: any = num ? na : String(a), y: any = num ? nb : String(b);
  if (op === "=" || op === "==") return x == y;
  if (op === "!=" || op === "<>") return x != y;
  if (op === ">") return x > y;
  if (op === "<") return x < y;
  if (op === ">=") return x >= y;
  if (op === "<=") return x <= y;
  return false;
}

function evalWhere(row: Row, where?: string): boolean {
  if (!where) return true;
  const orParts = where.split(/\s+or\s+/i);
  return orParts.some(or => or.split(/\s+and\s+/i).every(part => {
    const like = part.match(/^\s*(\S+)\s+like\s+(.+?)\s*$/i);
    if (like) {
      const pattern = String(val(row, like[2])).replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/%/g, ".*").replace(/_/g, ".");
      return new RegExp("^" + pattern + "$").test(String(val(row, like[1])));
    }
    const m = part.match(/^\s*(\S+)\s*(>=|<=|<>|!=|=|>|<)\s*(.+?)\s*$/);
    if (!m) return true;
    return cmp(val(row, m[1]), m[2], val(row, m[3]));
  }));
}

function project(rows: Row[], columns: string[], select: string, groupBy?: string): { rows: Row[]; columns: string[] } {
  let distinct = false;
  select = select.replace(/^distinct\s+/i, () => { distinct = true; return ""; });
  const items = splitSelect(select);
  if (items.length === 1 && items[0] === "*") return { rows, columns };
  const hasAgg = items.some(i => /\b(count|sum|avg|min|max)\s*\(/i.test(i));
  if (hasAgg && !groupBy) {
    const r: Row = {};
    const outCols: string[] = [];
    for (const item of items) {
      const { expr, alias } = aliasOf(item);
      const col = alias || expr;
      outCols.push(col);
      const mm = expr.match(/^(count|sum|avg|min|max)\s*\(\s*([\*\w]+)\s*\)$/i);
      if (!mm) { r[col] = rows[0] ? val(rows[0], expr) : ""; continue; }
      const fn = mm[1].toLowerCase(), c = mm[2];
      const vals = c === "*" ? rows.map(() => 1) : rows.map(x => x[c]).filter(x => x !== null && x !== undefined && x !== "");
      const nums = vals.map(Number).filter(x => !Number.isNaN(x));
      if (fn === "count") r[col] = String(vals.length);
      if (fn === "sum") r[col] = String(nums.reduce((a, b) => a + b, 0));
      if (fn === "avg") r[col] = String(nums.reduce((a, b) => a + b, 0) / (nums.length || 1));
      if (fn === "min") r[col] = String(vals.sort((a:any,b:any)=>Number(a)-Number(b))[0] ?? "");
      if (fn === "max") r[col] = String(vals.sort((a:any,b:any)=>Number(b)-Number(a))[0] ?? "");
    }
    return { rows: [r], columns: outCols };
  }
  if (groupBy) {
    const g = groupBy.trim();
    const groups = new Map<string, Row[]>();
    rows.forEach(r => { const k = String(r[g]); groups.set(k, [...(groups.get(k) || []), r]); });
    rows = Array.from(groups.values()).map(rs => ({ ...rs[0], __group: rs }));
  }
  const outCols: string[] = [];
  let outRows = rows.map(row => {
    const r: Row = {};
    for (const item of items) {
      const { expr, alias } = aliasOf(item);
      const col = alias || expr.replace(/^.*\./, "");
      if (!outCols.includes(col)) outCols.push(col);
      const mm = expr.match(/^(count|sum|avg|min|max)\s*\(\s*([\*\w]+)\s*\)$/i);
      if (mm && row.__group) {
        const vals = mm[2] === "*" ? row.__group.map(() => 1) : row.__group.map((x:Row) => x[mm[2]]);
        r[col] = String(vals.length);
      } else r[col] = val(row, expr.replace(/^.*\./, ""));
    }
    return r;
  });
  if (distinct) {
    const seen = new Set<string>();
    outRows = outRows.filter(r => { const k = JSON.stringify(r); if (seen.has(k)) return false; seen.add(k); return true; });
  }
  return { rows: outRows, columns: outCols };
}

function aliasOf(item: string): { expr: string; alias?: string } {
  const m = item.match(/^(.+?)\s+as\s+(\w+)$/i) || item.match(/^(.+?)\s+(\w+)$/i);
  return m ? { expr: m[1].trim(), alias: m[2].trim() } : { expr: item.trim() };
}

function runSql(sql: string, opts: Options): { rows: Row[]; columns: string[] } {
  const p = parseSql(sql);
  if (!p) throw new Error("unsupported SQL");
  let { rows, columns } = loadTable(p.file, opts);
  rows = rows.filter(r => evalWhere(r, p.where));
  if (p.orderBy) {
    const parts = p.orderBy.split(/\s*,\s*/).map((x: string) => x.trim());
    rows.sort((a, b) => {
      for (const part of parts) {
        const mm = part.match(/^(\S+)(?:\s+(asc|desc))?$/i);
        if (!mm) continue;
        const av = val(a, mm[1]), bv = val(b, mm[1]);
        const c = cmp(av, "<", bv) ? -1 : cmp(av, ">", bv) ? 1 : 0;
        if (c) return /desc/i.test(mm[2] || "") ? -c : c;
      }
      return 0;
    });
  }
  let res = project(rows, columns, p.select, p.groupBy);
  if (p.limit !== undefined) res.rows = res.rows.slice(0, p.limit);
  return res;
}

function csvEscape(v: any, opts: Options): string {
  if (v === null || v === undefined) return opts.outputNull ?? "";
  let s = String(v);
  const q = opts.quote;
  const need = opts.allQuotes || s.includes(opts.outputDelimiter) || s.includes("\n") || s.includes("\r") || s.includes(q);
  s = s.split(q).join(q + q);
  return need ? q + s + q : s;
}

function format(rows: Row[], columns: string[], opts: Options): string {
  const nl = opts.crlf ? "\r\n" : "\n";
  const cell = (r: Row, c: string) => {
    const v = r[c];
    if (v === null || v === undefined) return opts.outputNull ?? "";
    return typeof v === "object" ? JSON.stringify(v) : String(v);
  };
  if (opts.outputFormat === "json") return JSON.stringify(rows.map(r => Object.fromEntries(columns.map(c => [c, r[c] ?? null]))), null, 2) + nl;
  if (opts.outputFormat === "jsonl") return rows.map(r => JSON.stringify(Object.fromEntries(columns.map(c => [c, r[c] ?? null])))).join(nl) + (rows.length ? nl : "");
  if (opts.outputFormat === "ltsv") return rows.map(r => columns.map(c => `${c}:${cell(r,c)}`).join("\t")).join(nl) + (rows.length ? nl : "");
  if (opts.outputFormat === "raw") return rows.map(r => columns.map(c => cell(r,c)).join(opts.outputDelimiter)).join(nl) + (rows.length ? nl : "");
  if (opts.outputFormat === "tbln") return rows.map(r => columns.map(c => cell(r,c)).join(" ")).join(nl) + (rows.length ? nl : "");
  if (opts.outputFormat === "yaml") return rows.map(r => "- " + columns.map((c,i) => `${i ? "\n  " : ""}${c}: ${cell(r,c)}`).join("")).join(nl) + (rows.length ? nl : "");
  if (opts.outputFormat === "md" || opts.outputFormat === "at") return tableFormat(rows, columns, opts.outputFormat === "at", nl);
  if (opts.outputFormat === "vf") return rows.map((r, i) => `*************************** ${i + 1}. row ***************************${nl}` + columns.map(c => `${c}: ${cell(r,c)}`).join(nl)).join(nl) + (rows.length ? nl : "");
  const lines: string[] = [];
  if (opts.outputHeader) lines.push(columns.map(c => csvEscape(c, opts)).join(opts.outputDelimiter));
  rows.forEach(r => lines.push(columns.map(c => csvEscape(cell(r,c), opts)).join(opts.outputDelimiter)));
  return lines.join(nl) + (lines.length ? nl : "");
}

function tableFormat(rows: Row[], columns: string[], ascii: boolean, nl: string): string {
  const vals = rows.map(r => columns.map(c => r[c] === null || r[c] === undefined ? "" : String(r[c])));
  const widths = columns.map((c, i) => Math.max(c.length, ...vals.map(v => v[i].length)));
  const isNum = (s: string) => /^-?\d+(\.\d+)?$/.test(s);
  const pad = (s: string, w: number) => isNum(s) ? " ".repeat(w - s.length) + s : s + " ".repeat(w - s.length);
  const row = (xs: string[]) => "| " + xs.map((x, i) => pad(x, widths[i])).join(" | ") + " |";
  const sep = ascii ? "+" + widths.map(w => "-".repeat(w + 2)).join("+") + "+" : "|" + widths.map(w => "-".repeat(w + 2)).join("|") + "|";
  const lines = ascii ? [sep, row(columns), sep, ...vals.map(row), sep] : [row(columns), sep, ...vals.map(row)];
  return lines.join(nl) + nl;
}

function analyze(file: string, opts: Options): string {
  const { rows, columns } = loadTable(file, opts);
  const ext = (opts.inputFormat || path.extname(file).replace(".", "") || "CSV").toUpperCase();
  const cols = columns.length ? columns : ["c1"];
  const first = rows[0] || {};
  let s = `The table name is ${file}.\nThe file type is ${ext === "LTSV" ? "LTSV" : ext === "JSON" ? "JSON" : "CSV"}.\n\nData types:\n`;
  s += tableFormat(cols.map(c => ({ "column name": c, type: "text" })), ["column name", "type"], true, "\n") + "\nData samples:\n";
  s += tableFormat([Object.fromEntries(cols.map(c => [c, first[c] ?? ""]))], cols, true, "\n") + "\nExamples:\n";
  s += `./executable "SELECT ${cols.join(", ")} FROM ${file}"\n`;
  if (cols[0]) s += `./executable "SELECT ${cols.join(", ")} FROM ${file} WHERE ${cols[0]} = '${first[cols[0]] ?? ""}'"\n`;
  s += `./executable "SELECT ${cols[0]}, count(${cols[0]}) FROM ${file} GROUP BY ${cols[0]}"\n`;
  s += `./executable "SELECT ${cols.join(", ")} FROM ${file} ORDER BY ${cols[0]} LIMIT 10"\n`;
  return s;
}

function main() {
  const { opts, sql } = parseArgs(process.argv.slice(2));
  try {
    if (opts.help) { process.stdout.write(HELP + "\n"); return; }
    if (opts.version) { process.stdout.write("trdsql version devel\n"); return; }
    if (opts.dblist) return;
    if (opts.analyze || opts.analyzeOnly) { process.stdout.write(analyze(opts.analyze || opts.analyzeOnly!, opts)); return; }
    let result: { rows: Row[]; columns: string[] };
    if (opts.tableFile && !sql) result = loadTable(opts.tableFile, opts);
    else result = runSql(sql || `select * from ${opts.tableFile || "-"}`, opts);
    const out = format(result.rows, result.columns, opts);
    if (opts.outFile) fs.writeFileSync(opts.outFile, out); else process.stdout.write(out);
  } catch (e: any) {
    const msg = e && e.code === "ENOENT" ? `export: no such table: ${e.path}` : e.message;
    console.error(new Date().toISOString().replace("T", " ").slice(0, 19).replace(/-/g, "/") + " " + msg);
    process.exit(1);
  }
}

main();
