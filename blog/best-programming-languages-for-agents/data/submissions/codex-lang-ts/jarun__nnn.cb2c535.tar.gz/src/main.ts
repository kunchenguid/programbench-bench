declare const process: {
  argv: string[];
  env: Record<string, string | undefined>;
  stdout: { write(s: string): void };
  stderr: { write(s: string): void };
  stdin: { resume(): void; on(event: string, cb: (chunk: unknown) => void): void };
  exit(code?: number): never;
};

const VERSION = "5.2";

const HELP = `usage: nnn [OPTIONS] [PATH]

The unorthodox terminal file manager.

positional args:
  PATH   start dir/file [default: .]

optional args:
 -a      auto NNN_FIFO
 -A      no dir auto-enter during filter
 -b key  open bookmark key (trumps -s/S)
 -B      use bsdtar for archives
 -c      cli-only NNN_OPENER (trumps -e)
 -C      8-color scheme
 -d      detail mode
 -D      dirs in context color
 -e      text in $VISUAL/$EDITOR/vi
 -E      internal edits in EDITOR
 -f      use history file
 -F val  fifo mode [0:preview 1:explore]
 -g      regex filters
 -H      show hidden files
 -i      show current file info
 -J      no auto-advance on selection
 -K      detect key collision and exit
 -l val  set scroll lines
 -n      type-to-nav mode
 -N      use native prompt
 -o      open files only on Enter
 -p file selection file [-:stdout]
 -P key  run plugin key
 -Q      no quit confirmation
 -r      use advcpmv patched cp, mv
 -R      no rollover at edges
 -s name load session by name
 -S      persistent session
 -t secs timeout to lock
 -T key  sort order [a/d/e/r/s/t/v]
 -u      use selection (no prompt)
 -U      show user and group
 -V      show version
 -x      notis, selection sync, xterm title
 -z      in order fuzzy filters
 -0      null separator in picker mode
 -h      show help

v5.2
BSD 2-Clause
https://github.com/jarun/nnn
`;

const noArgOptions = new Set("aABcCdDeEfgHiJKnNoQrRSuUVxz0h".split(""));
const argOptions = new Set("bFlpPstT".split(""));
const allOptions = new Set([...noArgOptions, ...argOptions]);

function progName(): string {
  return process.env.NNN_ARG0 || "./executable";
}

function showHelp(): void {
  process.stdout.write(HELP);
}

function optionError(kind: "invalid" | "missing", opt: string): never {
  if (kind === "invalid") {
    process.stderr.write(`${progName()}: invalid option -- '${opt}'\n`);
  } else {
    process.stderr.write(`${progName()}: option requires an argument -- '${opt}'\n`);
  }
  showHelp();
  process.exit(1);
}

type Parsed = {
  help: boolean;
  version: boolean;
  keyCheck: boolean;
  fifoMode?: string;
  path?: string;
};

function parseArgs(args: string[]): Parsed {
  const parsed: Parsed = { help: false, version: false, keyCheck: false };
  let i = 0;

  while (i < args.length) {
    const arg = args[i];
    if (arg === "--") {
      if (i + 1 < args.length) parsed.path = args[i + 1];
      return parsed;
    }
    if (!arg.startsWith("-") || arg === "-") {
      parsed.path = arg;
      return parsed;
    }

    for (let pos = 1; pos < arg.length; pos++) {
      const opt = arg[pos];
      if (!allOptions.has(opt)) optionError("invalid", opt);

      if (argOptions.has(opt)) {
        let value = arg.slice(pos + 1);
        if (value.length === 0) {
          i++;
          if (i >= args.length) optionError("missing", opt);
          value = args[i];
        }
        if (opt === "F") parsed.fifoMode = value;
        break;
      }

      if (opt === "h") parsed.help = true;
      if (opt === "V") parsed.version = true;
      if (opt === "K") parsed.keyCheck = true;
    }
    i++;
  }

  return parsed;
}

function main(): void {
  const parsed = parseArgs(process.argv.slice(2));

  if (parsed.version) {
    process.stdout.write(`${VERSION}\n`);
    process.exit(0);
  }
  if (parsed.help) {
    showHelp();
    process.exit(0);
  }
  if (parsed.keyCheck) process.exit(0);
  if (parsed.fifoMode !== undefined && parsed.fifoMode !== "0" && parsed.fifoMode !== "1") {
    process.exit(1);
  }

  process.stdout.write("0 entries\n");
  process.stdin.resume();
  process.stdin.on("data", () => undefined);
  setInterval(() => undefined, 1 << 30);
}

main();
