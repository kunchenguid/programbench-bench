import * as fs from "fs";
import * as path from "path";

type ElfClass = 1 | 2;
type Endian = 1 | 2;

interface Header {
  cls: ElfClass;
  endian: Endian;
  abi: number;
  abiVersion: number;
  type: number;
  machine: number;
  entry: bigint;
  phoff: bigint;
  shoff: bigint;
  flags: number;
  ehsize: number;
  phentsize: number;
  phnum: number;
  shentsize: number;
  shnum: number;
  shstrndx: number;
}

interface ProgramHeader {
  type: number;
  flags: number;
  offset: bigint;
  vaddr: bigint;
  paddr: bigint;
  filesz: bigint;
  memsz: bigint;
  align: bigint;
}

interface SectionHeader {
  nameOffset: number;
  name: string;
  type: number;
  flags: bigint;
  addr: bigint;
  offset: bigint;
  size: bigint;
  link: number;
  info: number;
  addralign: bigint;
  entsize: bigint;
}

interface ElfFile {
  header: Header;
  phdrs: ProgramHeader[];
  shdrs: SectionHeader[];
}

class Reader {
  constructor(private readonly b: Buffer, private readonly endian: Endian) {}
  u16(o: number): number { return this.endian === 1 ? this.b.readUInt16LE(o) : this.b.readUInt16BE(o); }
  u32(o: number): number { return this.endian === 1 ? this.b.readUInt32LE(o) : this.b.readUInt32BE(o); }
  u64(o: number): bigint { return this.endian === 1 ? this.b.readBigUInt64LE(o) : this.b.readBigUInt64BE(o); }
}

function usage(): void {
  console.log("Usage: elfcat <filename>");
  console.log("Writes <filename>.html to CWD.");
}

function fail(msg: string): never {
  console.error(msg);
  process.exit(1);
  throw new Error(msg);
}

function requireRange(buf: Buffer, off: bigint, size: number, what: string): number {
  if (off < 0n || off > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error(`${what} offset is out of range`);
  const n = Number(off);
  if (n + size > buf.length) throw new Error(`${what} is out of file bounds`);
  return n;
}

function parseElf(buf: Buffer): ElfFile {
  if (buf.length < 16) throw new Error("file is smaller than ELF header's e_ident");
  if (buf[0] !== 0x7f || buf[1] !== 0x45 || buf[2] !== 0x4c || buf[3] !== 0x46) {
    throw new Error("mismatched magic: not an ELF file");
  }
  const cls = buf[4] as ElfClass;
  const endian = buf[5] as Endian;
  if (cls !== 1 && cls !== 2) throw new Error(`unsupported ELF class: ${cls}`);
  if (endian !== 1 && endian !== 2) throw new Error(`unsupported ELF data encoding: ${endian}`);
  const min = cls === 2 ? 64 : 52;
  if (buf.length < min) throw new Error("file is smaller than ELF header");
  const r = new Reader(buf, endian);
  const h: Header = {
    cls, endian,
    abi: buf[7],
    abiVersion: buf[8],
    type: r.u16(16),
    machine: r.u16(18),
    entry: cls === 2 ? r.u64(24) : BigInt(r.u32(24)),
    phoff: cls === 2 ? r.u64(32) : BigInt(r.u32(28)),
    shoff: cls === 2 ? r.u64(40) : BigInt(r.u32(32)),
    flags: cls === 2 ? r.u32(48) : r.u32(36),
    ehsize: r.u16(cls === 2 ? 52 : 40),
    phentsize: r.u16(cls === 2 ? 54 : 42),
    phnum: r.u16(cls === 2 ? 56 : 44),
    shentsize: r.u16(cls === 2 ? 58 : 46),
    shnum: r.u16(cls === 2 ? 60 : 48),
    shstrndx: r.u16(cls === 2 ? 62 : 50)
  };

  const phdrs: ProgramHeader[] = [];
  for (let i = 0; i < h.phnum; i++) {
    const off = requireRange(buf, h.phoff + BigInt(i * h.phentsize), h.phentsize, "program header");
    if (cls === 2) {
      phdrs.push({
        type: r.u32(off), flags: r.u32(off + 4), offset: r.u64(off + 8), vaddr: r.u64(off + 16),
        paddr: r.u64(off + 24), filesz: r.u64(off + 32), memsz: r.u64(off + 40), align: r.u64(off + 48)
      });
    } else {
      phdrs.push({
        type: r.u32(off), offset: BigInt(r.u32(off + 4)), vaddr: BigInt(r.u32(off + 8)),
        paddr: BigInt(r.u32(off + 12)), filesz: BigInt(r.u32(off + 16)), memsz: BigInt(r.u32(off + 20)),
        flags: r.u32(off + 24), align: BigInt(r.u32(off + 28))
      });
    }
  }

  const shdrs: SectionHeader[] = [];
  for (let i = 0; i < h.shnum; i++) {
    const off = requireRange(buf, h.shoff + BigInt(i * h.shentsize), h.shentsize, "section header");
    if (cls === 2) {
      shdrs.push({
        nameOffset: r.u32(off), name: "", type: r.u32(off + 4), flags: r.u64(off + 8), addr: r.u64(off + 16),
        offset: r.u64(off + 24), size: r.u64(off + 32), link: r.u32(off + 40), info: r.u32(off + 44),
        addralign: r.u64(off + 48), entsize: r.u64(off + 56)
      });
    } else {
      shdrs.push({
        nameOffset: r.u32(off), name: "", type: r.u32(off + 4), flags: BigInt(r.u32(off + 8)),
        addr: BigInt(r.u32(off + 12)), offset: BigInt(r.u32(off + 16)), size: BigInt(r.u32(off + 20)),
        link: r.u32(off + 24), info: r.u32(off + 28), addralign: BigInt(r.u32(off + 32)), entsize: BigInt(r.u32(off + 36))
      });
    }
  }
  if (h.shstrndx < shdrs.length) {
    const str = shdrs[h.shstrndx];
    const start = Number(str.offset);
    const end = Math.min(buf.length, start + Number(str.size));
    for (const s of shdrs) s.name = readCString(buf, start + s.nameOffset, end);
  }
  return { header: h, phdrs, shdrs };
}

function readCString(buf: Buffer, start: number, end = buf.length): string {
  if (start < 0 || start >= end || start >= buf.length) return "";
  let i = start;
  while (i < end && i < buf.length && buf[i] !== 0) i++;
  return buf.subarray(start, i).toString("utf8").replace(/[\u0000-\u001f]/g, "");
}

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function hex(n: bigint | number): string { return "0x" + BigInt(n).toString(16); }

function num(n: bigint | number, withSize = false): string {
  const b = BigInt(n);
  let text = b.toString();
  if (withSize && b >= 1024n) text += ` (${human(Number(b))})`;
  return `<span class='number' title='${hex(b)}'>${text}</span>`;
}

function human(bytes: number): string {
  const units = ["B", "KiB", "MiB", "GiB"];
  let v = bytes, u = 0;
  while (v >= 1024 && u < units.length - 1) { v /= 1024; u++; }
  if (u === 0) return `${bytes} B`;
  return `${Number.isInteger(v) ? v.toFixed(0) : v.toFixed(1)} ${units[u]}`;
}

function fileSize(bytes: number): string {
  return bytes >= 1024 ? `${human(bytes)} (${bytes} B)` : `${bytes} B`;
}

function abiName(v: number): string {
  const m: Record<number, string> = {0: "SysV", 1: "HP-UX", 2: "NetBSD", 3: "Linux", 6: "Solaris", 7: "AIX", 8: "IRIX", 9: "FreeBSD", 12: "OpenBSD"};
  return m[v] ?? `Unknown: ${v}`;
}

function typeName(v: number): string {
  const m: Record<number, string> = {0: "None (NONE)", 1: "Relocatable file (REL)", 2: "Executable file (EXEC)", 3: "Shared object file (DYN)", 4: "Core file (CORE)"};
  return m[v] ?? `Unknown: ${v}`;
}

function machineName(v: number): string {
  const m: Record<number, string> = {3: "x86", 8: "MIPS", 20: "PowerPC", 40: "ARM", 62: "x86-64", 183: "AArch64", 243: "RISC-V"};
  return m[v] ?? `Unknown: ${v}`;
}

function phType(v: number): string {
  const m: Record<number, string> = {0: "NULL", 1: "LOAD", 2: "DYNAMIC", 3: "INTERP", 4: "NOTE", 5: "SHLIB", 6: "PHDR", 7: "TLS", 0x6474e550: "GNU_EH_FRAME (OS-specific)", 0x6474e551: "GNU_STACK (OS-specific)", 0x6474e552: "GNU_RELRO (OS-specific)"};
  return m[v] ?? `Unknown: ${v}`;
}

function shType(v: number): string {
  const m: Record<number, string> = {0: "NULL", 1: "PROGBITS", 2: "SYMTAB", 3: "STRTAB", 4: "RELA", 5: "HASH", 6: "DYNAMIC", 7: "NOTE", 8: "NOBITS", 9: "REL", 10: "SHLIB", 11: "DYNSYM", 14: "INIT_ARRAY", 15: "FINI_ARRAY", 16: "PREINIT_ARRAY", 17: "GROUP", 18: "SYMTAB_SHNDX", 0x6ffffff6: "GNU_HASH (OS-specific)", 0x6ffffffe: "VER_NEED (OS-specific)", 0x6fffffff: "HIOS"};
  return m[v] ?? `Unknown: ${v}`;
}

function pFlags(v: number): string {
  let s = "";
  if (v & 4) s += "R";
  if (v & 2) s += "W";
  if (v & 1) s += "X";
  return s || "0";
}

function sFlags(v: bigint): string {
  let s = "";
  if (v & 1n) s += "W";
  if (v & 2n) s += "A";
  if (v & 4n) s += "X";
  if (v & 0x10n) s += "M";
  if (v & 0x20n) s += "S";
  if (v & 0x40n) s += "I";
  if (v & 0x80n) s += "L";
  if (v & 0x100n) s += "O";
  if (v & 0x200n) s += "G";
  if (v & 0x400n) s += "T";
  return s || "0";
}

function tableRow(label: string, value: string): string {
  return `            <tr> <td>${label}</td> <td>${value}</td> </tr>\n`;
}

function hexdump(buf: Buffer): { offsets: string; hex: string; ascii: string } {
  const offsets: string[] = [], hexLines: string[] = [], asciiLines: string[] = [];
  for (let o = 0; o < buf.length; o += 16) {
    const chunk = buf.subarray(o, Math.min(buf.length, o + 16));
    offsets.push(o.toString(16));
    const hs: string[] = [], as: string[] = [];
    for (let i = 0; i < chunk.length; i++) {
      const x = chunk[i] as number;
      hs.push(x.toString(16).padStart(2, "0"));
      as.push(x >= 32 && x <= 126 ? String.fromCharCode(x) : ".");
    }
    hexLines.push(hs.join(" "));
    asciiLines.push(as.join(""));
  }
  return { offsets: offsets.join("\n"), hex: hexLines.join("\n"), ascii: asciiLines.join("\n") };
}

function stringTableEntries(buf: Buffer, s: SectionHeader): string[] {
  if (s.type !== 3 || s.size === 0n) return [];
  const start = Number(s.offset), end = Math.min(buf.length, start + Number(s.size));
  const out: string[] = [];
  let i = start;
  while (i < end) {
    while (i < end && buf[i] === 0) i++;
    const j = i;
    while (i < end && buf[i] !== 0) i++;
    if (i > j) out.push(esc(buf.subarray(j, i).toString("utf8")));
  }
  return out;
}

function render(file: string, buf: Buffer, elf: ElfFile): string {
  const h = elf.header;
  const dump = hexdump(buf);
  let phTables = "", segTables = "", shTables = "", secTables = "", sectionNames = "";
  elf.phdrs.forEach((p, i) => {
    phTables += `          <table class='conceal itable' id='info_phdr${i}'>\n          <th colspan='2' class='phdr_itable'></th>\n`;
    phTables += tableRow("Type:", phType(p.type));
    phTables += tableRow("Flags:", pFlags(p.flags));
    phTables += tableRow("Offset in file:", num(p.offset));
    phTables += tableRow("Size in file:", num(p.filesz, true));
    phTables += tableRow("Vaddr in memory:", num(p.vaddr));
    phTables += tableRow("Size in memory:", num(p.memsz, true));
    phTables += tableRow("Alignment:", num(p.align));
    phTables += "          </table>\n";
    segTables += `          <table class='conceal itable' id='info_segment${i}'>\n          <th colspan='2' class='segment_itable'></th>\n`;
    segTables += tableRow("Type:", phType(p.type));
    segTables += tableRow("Size in file:", num(p.filesz, true));
    segTables += tableRow("Size in memory:", num(p.memsz, true));
    if (p.type === 3) segTables += tableRow("Interpreter:", esc(readCString(buf, Number(p.offset), Number(p.offset + p.filesz))));
    segTables += "          </table>\n";
  });
  elf.shdrs.forEach((s, i) => {
    shTables += `          <table class='conceal itable' id='info_shdr${i}'>\n          <th colspan='2' class='shdr_itable'></th>\n`;
    shTables += tableRow("Index:", String(i));
    shTables += tableRow("Name:", esc(s.name));
    shTables += tableRow("Type:", shType(s.type));
    shTables += tableRow("Flags:", sFlags(s.flags));
    shTables += tableRow("Vaddr in memory:", num(s.addr));
    shTables += tableRow("Offset in file:", num(s.offset));
    shTables += tableRow("Size in file:", num(s.size, true));
    shTables += tableRow("Linked section:", String(s.link));
    shTables += tableRow("Extra info:", num(s.info));
    shTables += tableRow("Alignment:", num(s.addralign));
    shTables += tableRow("Size of entries:", num(s.entsize));
    shTables += "          </table>\n";
    secTables += `          <table class='conceal itable' id='info_section${i}'>\n          <th colspan='2' class='section_itable'></th>\n`;
    secTables += tableRow("Name:", esc(s.name));
    secTables += tableRow("Type:", shType(s.type));
    secTables += tableRow("Size:", num(s.size, true));
    const strings = stringTableEntries(buf, s);
    if (strings.length) secTables += `            <tr><td></td><td><div>${strings.join("<br>\n                  ")}</div></td></tr>\n`;
    secTables += "          </table>\n";
    if (s.name) sectionNames += `                  ${esc(s.name)}\n`;
  });

  return `<!doctype html>
<html>
  <head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=900, initial-scale=1'>
    <title>${esc(path.basename(file))}</title>
    <style>
      html { font-family: monospace; }
      body { margin: 1em; }
      #rightmenu { float: right; text-align: right; }
      #credits { color: #777; display: block; margin-bottom: .5em; }
      table { border-collapse: collapse; margin-bottom: 1em; }
      td, th { padding: 0 .6em .2em 0; vertical-align: top; }
      .number { color: #0645ad; }
      #dumpwrap { display: grid; grid-template-columns: max-content max-content max-content; gap: 1.5em; white-space: pre; }
      #offsets { color: #777; }
      #hexbytes { color: #111; }
      #asciidump { color: #555; }
      .conceal { display: table; }
      .itable { border-top: 1px solid #ddd; margin-right: 2em; float: left; }
      .phdr_itable::before { content: "Program Header"; font-weight: bold; }
      .shdr_itable::before { content: "Section Header"; font-weight: bold; }
      .segment_itable::before { content: "Segment"; font-weight: bold; }
      .section_itable::before { content: "Section"; font-weight: bold; }
      h2 { clear: both; padding-top: 1em; }
    </style>
  </head>
  <body>
    <div id='rightmenu'>
      <a id='credits' href='https://github.com/rbakbashev/elfcat'>generated with elfcat 0.1.10</a>
      <button class='textbutton' id='settings_toggle'>Settings</button>
      <button class='textbutton' id='help_toggle'>Help</button>
    </div>
    <table>
      <tr class='fileinfo_file_name'> <td>File name:</td> <td>${esc(file)}</td> </tr>
      <tr class='fileinfo_file_size'> <td>File size:</td> <td>${fileSize(buf.length)}</td> </tr>
      <tr class='fileinfo_class'> <td>Object class:</td> <td>${h.cls === 2 ? "64-bit" : "32-bit"}</td> </tr>
      <tr class='fileinfo_data'> <td>Data encoding:</td> <td>${h.endian === 1 ? "Little endian" : "Big endian"}</td> </tr>
      <tr class='fileinfo_abi'> <td>ABI:</td> <td>${abiName(h.abi)}</td> </tr>
      <tr class='fileinfo_e_type'> <td>Type:</td> <td>${typeName(h.type)}</td> </tr>
      <tr class='fileinfo_e_machine'> <td>Architecture:</td> <td>${machineName(h.machine)}</td> </tr>
      <tr class='fileinfo_e_entry'> <td>Entrypoint:</td> <td>${num(h.entry)}</td> </tr>
      <tr class='fileinfo_ph'> <td>Program headers:</td> <td><span title='${hex(h.phnum)}' class='number fileinfo_e_phnum'>${h.phnum}</span> * <span title='${hex(h.phentsize)}' class='number fileinfo_e_phentsize'>${h.phentsize}</span> @ <span title='${hex(h.phoff)}' class='number fileinfo_e_phoff'>${h.phoff}</span></td> </tr>
      <tr class='fileinfo_sh'> <td>Section headers:</td> <td><span title='${hex(h.shnum)}' class='number fileinfo_e_shnum'>${h.shnum}</span> * <span title='${hex(h.shentsize)}' class='number fileinfo_e_shentsize'>${h.shentsize}</span> @ <span title='${hex(h.shoff)}' class='number fileinfo_e_shoff'>${h.shoff}</span></td> </tr>
    </table>
    <div id='dumpwrap'><div id='offsets'>${dump.offsets}</div><div id='hexbytes'>${dump.hex}</div><div id='asciidump'>${esc(dump.ascii)}</div></div>
    <h2>Program Headers</h2>
${phTables}
    <h2>Section Headers</h2>
${shTables}
    <h2>Segments</h2>
${segTables}
    <h2>Sections</h2>
${secTables}
    <pre id='section_names'>${sectionNames}</pre>
  </body>
</html>
`;
}

function main(): void {
  const args = process.argv.slice(2);
  if (args.length !== 1 || args[0] === "--help" || args[0] === "-h") {
    usage();
    process.exit(args.length === 1 && (args[0] === "--help" || args[0] === "-h") ? 0 : 1);
  }
  const file = args[0];
  let buf: Buffer;
  try {
    buf = fs.readFileSync(file);
  } catch (e: any) {
    fail(`Failed to read file "${file}": ${readErrorMessage(e)}`);
  }
  let elf: ElfFile;
  try {
    elf = parseElf(buf);
  } catch (e: any) {
    fail(`Failed to parse ELF: ${e.message}`);
  }
  fs.writeFileSync(`${file}.html`, render(file, buf, elf));
}

main();

function readErrorMessage(e: any): string {
  if (e && e.code === "ENOENT") return "No such file or directory (os error 2)";
  if (e && e.code === "EACCES") return "Permission denied (os error 13)";
  if (e && e.code === "EISDIR") return "Is a directory (os error 21)";
  return e && e.message ? String(e.message) : String(e);
}
