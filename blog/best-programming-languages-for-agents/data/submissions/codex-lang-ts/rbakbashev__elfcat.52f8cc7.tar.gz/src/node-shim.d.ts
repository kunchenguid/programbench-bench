declare module "fs" {
  export function readFileSync(path: string): Buffer;
  export function writeFileSync(path: string, data: string | Buffer): void;
}

declare module "path" {
  export function basename(path: string): string;
}

declare const process: {
  argv: string[];
  exit(code?: number): never;
};

declare const console: {
  log(...args: any[]): void;
  error(...args: any[]): void;
};

type Buffer = any;
