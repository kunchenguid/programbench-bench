declare const process: any;
declare function require(name: string): any;

const fs = require("fs");
const path = require("path");
const os = require("os");
const childProcess = require("child_process");

const VERSION = "v1.13.0";
const HELP = `
  walk v1.13.0

  Usage: walk [path]

    arrows, hjkl  Move cursor
    enter         Enter directory
    backspace     Exit directory
    space         Toggle preview
    esc, q        Exit with cd
    ctrl+c        Exit without cd
    /             Fuzzy search
    d, delete     Delete file or dir
    y             Copy to clipboard
    .             Hide hidden files
    ?             Show help

  Flags:

    --icons        display icons
    --dir-only     show dirs only
    --hide-hidden  hide hidden files
    --preview      display preview
    --with-border  preview with border
    --fuzzy        fuzzy mode

`;

type Entry = {
  name: string;
  full: string;
  isDir: boolean;
  isFile: boolean;
  isLink: boolean;
  size: number;
  mode: number;
  mtime: Date;
};

type State = {
  cwd: string;
  cursor: number;
  hideHidden: boolean;
  dirOnly: boolean;
  icons: boolean;
  preview: boolean;
  withBorder: boolean;
  fuzzy: boolean;
  query: string;
  searchMode: boolean;
  showHelp: boolean;
  entries: Entry[];
  message: string;
};

function main() {
  const args = process.argv.slice(2);
  if (args.includes("--version")) {
    process.stdout.write(VERSION + "\n");
    process.exit(0);
  }
  if (args.includes("--help") || args.includes("-h")) {
    process.stderr.write(HELP);
    process.exit(1);
  }

  const opts = {
    icons: false,
    dirOnly: false,
    hideHidden: false,
    preview: false,
    withBorder: false,
    fuzzy: false,
  };
  const paths: string[] = [];
  for (const arg of args) {
    if (arg === "--icons") opts.icons = true;
    else if (arg === "--dir-only") opts.dirOnly = true;
    else if (arg === "--hide-hidden") opts.hideHidden = true;
    else if (arg === "--preview") opts.preview = true;
    else if (arg === "--with-border") opts.withBorder = true;
    else if (arg === "--fuzzy") opts.fuzzy = true;
    else paths.push(arg);
  }

  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    process.stderr.write("panic: could not open a new TTY: open /dev/tty: no such device or address\n\n");
    process.stderr.write("goroutine 1 [running]:\nmain.main()\n\t/workspace/main.go:135 +0x87d\n");
    process.exit(2);
  }

  const start = path.resolve(paths[0] || process.cwd());
  const state: State = {
    cwd: start,
    cursor: 0,
    hideHidden: opts.hideHidden,
    dirOnly: opts.dirOnly,
    icons: opts.icons,
    preview: opts.preview,
    withBorder: opts.withBorder,
    fuzzy: opts.fuzzy,
    query: "",
    searchMode: opts.fuzzy,
    showHelp: false,
    entries: [],
    message: "",
  };

  setupTerminal();
  const cleanup = (printPath: boolean, code: number) => {
    restoreTerminal();
    if (printPath) process.stdout.write(state.cwd + "\n");
    process.exit(code);
  };

  process.on("SIGINT", () => cleanup(false, 130));
  refresh(state);
  render(state);

  process.stdin.on("data", (chunk: any) => {
    const bytes: number[] = Array.from(chunk.values() as Iterable<number>);
    for (let i = 0; i < bytes.length; i++) {
      const b = bytes[i];
      if (b === 3) cleanup(false, 130);
      else if (b === 27) {
        const next1 = bytes[i + 1], next2 = bytes[i + 2];
        if (next1 === 91 && next2 === 65) { move(state, -1); i += 2; }
        else if (next1 === 91 && next2 === 66) { move(state, 1); i += 2; }
        else if (next1 === 91 && next2 === 72) { state.cursor = 0; i += 2; }
        else if (next1 === 91 && next2 === 70) { state.cursor = Math.max(0, state.entries.length - 1); i += 2; }
        else if (next1 === 91 && next2 === 51 && bytes[i + 3] === 126) { removeCurrent(state); i += 3; }
        else cleanup(true, 0);
      } else if (b === 113) cleanup(true, 0);
      else if (b === 106) move(state, 1);
      else if (b === 107) move(state, -1);
      else if (b === 103) state.cursor = 0;
      else if (b === 71) state.cursor = Math.max(0, state.entries.length - 1);
      else if (b === 104 || b === 127 || b === 8) goUp(state);
      else if (b === 108 || b === 13 || b === 10) enter(state);
      else if (b === 32) state.preview = !state.preview;
      else if (b === 46) { state.hideHidden = !state.hideHidden; state.cursor = 0; refresh(state); }
      else if (b === 47) { state.searchMode = true; state.query = ""; }
      else if (b === 63) state.showHelp = !state.showHelp;
      else if (b === 100) removeCurrent(state);
      else if (b === 121) yank(state);
      else if (state.searchMode && b === 127) { state.query = state.query.slice(0, -1); refresh(state); }
      else if (state.searchMode && b >= 32 && b <= 126) { state.query += String.fromCharCode(b); refresh(state); }
    }
    clampCursor(state);
    render(state);
  });
}

function setupTerminal() {
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdout.write("\x1b[?25l\x1b[?2004h");
}

function restoreTerminal() {
  try { process.stdin.setRawMode(false); } catch (_) {}
  process.stdout.write("\x1b[2K\r\x1b[?2004l\x1b[?25h\x1b[?1002l\x1b[?1003l\x1b[?1006l");
}

function refresh(state: State) {
  state.entries = readEntries(state);
  clampCursor(state);
}

function readEntries(state: State): Entry[] {
  let names: string[] = [];
  try {
    names = fs.readdirSync(state.cwd);
    state.message = "";
  } catch (err: any) {
    state.message = err && err.message ? err.message : String(err);
    return [];
  }

  const query = state.query.toLowerCase();
  const entries: Entry[] = [];
  for (const name of names) {
    if (state.hideHidden && name.startsWith(".")) continue;
    if (query && !fuzzyMatch(name.toLowerCase(), query)) continue;
    const full = path.join(state.cwd, name);
    let st: any;
    let lst: any;
    try {
      lst = fs.lstatSync(full);
      st = lst.isSymbolicLink() ? fs.statSync(full) : lst;
    } catch (_) {
      st = lst;
    }
    if (!st) continue;
    const isDir = !!st.isDirectory && st.isDirectory();
    if (state.dirOnly && !isDir) continue;
    entries.push({
      name,
      full,
      isDir,
      isFile: !!st.isFile && st.isFile(),
      isLink: !!lst?.isSymbolicLink && lst.isSymbolicLink(),
      size: Number(st.size || 0),
      mode: Number(st.mode || 0),
      mtime: st.mtime || new Date(),
    });
  }
  entries.sort((a, b) => a.name.localeCompare(b.name));
  return entries;
}

function fuzzyMatch(value: string, query: string): boolean {
  let pos = 0;
  for (const ch of query) {
    pos = value.indexOf(ch, pos);
    if (pos === -1) return false;
    pos++;
  }
  return true;
}

function clampCursor(state: State) {
  if (state.cursor < 0) state.cursor = 0;
  if (state.cursor >= state.entries.length) state.cursor = Math.max(0, state.entries.length - 1);
}

function move(state: State, delta: number) {
  if (!state.entries.length) return;
  state.cursor = Math.max(0, Math.min(state.entries.length - 1, state.cursor + delta));
}

function current(state: State): Entry | undefined {
  return state.entries[state.cursor];
}

function enter(state: State) {
  const ent = current(state);
  if (!ent) return;
  if (ent.isDir) {
    state.cwd = ent.full;
    state.cursor = 0;
    state.query = "";
    state.searchMode = state.fuzzy;
    refresh(state);
  } else {
    openFile(ent.full);
  }
}

function goUp(state: State) {
  const parent = path.dirname(state.cwd);
  if (parent !== state.cwd) {
    state.cwd = parent;
    state.cursor = 0;
    state.query = "";
    refresh(state);
  }
}

function openFile(file: string) {
  const editor = process.env.WALK_EDITOR || process.env.EDITOR;
  if (!editor) return;
  restoreTerminal();
  try {
    childProcess.spawnSync(editor, [file], { stdio: "inherit", shell: true });
  } finally {
    setupTerminal();
  }
}

function removeCurrent(state: State) {
  const ent = current(state);
  if (!ent) return;
  const cmd = process.env.WALK_REMOVE_CMD;
  try {
    if (cmd) childProcess.spawnSync(cmd, [ent.full], { stdio: "ignore", shell: true });
    else fs.rmSync(ent.full, { recursive: true, force: true });
    state.message = "removed " + ent.name;
    refresh(state);
  } catch (err: any) {
    state.message = err?.message || String(err);
  }
}

function yank(state: State) {
  state.message = state.cwd;
  const tools = process.platform === "darwin" ? ["pbcopy"] : ["xclip", "xsel", "wl-copy"];
  for (const tool of tools) {
    try {
      const p = childProcess.spawnSync(tool, [], { input: state.cwd, stdio: ["pipe", "ignore", "ignore"] });
      if (p.status === 0) return;
    } catch (_) {}
  }
}

function iconFor(ent: Entry): string {
  if (ent.isDir) return " ";
  if ((ent.mode & 0o111) !== 0) return " ";
  const ext = path.extname(ent.name).toLowerCase();
  if (ext === ".md") return " ";
  if (ext === ".json") return " ";
  if (ext === ".js" || ext === ".mjs") return " ";
  if (ext === ".ts") return " ";
  if (ext === ".go") return " ";
  if (ext === ".rs") return " ";
  if (ext === ".py") return " ";
  if ([".png", ".jpg", ".jpeg", ".gif", ".webp"].includes(ext)) return " ";
  return " ";
}

function render(state: State) {
  const columns = process.stdout.columns || 80;
  const rows = process.stdout.rows || 24;
  const leftWidth = state.preview ? Math.max(20, Math.floor(columns * 0.45)) : columns;
  const visibleRows = Math.max(1, rows - 1);
  const start = Math.max(0, Math.min(state.cursor - Math.floor(visibleRows / 2), Math.max(0, state.entries.length - visibleRows)));
  const lines: string[] = [];
  lines.push(trunc(state.cwd + (state.searchMode ? " /" + state.query : ""), leftWidth));

  if (state.showHelp) {
    for (const line of HELP.trimEnd().split("\n")) lines.push(trunc(line, leftWidth));
  } else if (state.message && state.entries.length === 0) {
    const boxWidth = Math.min(columns - 2, Math.max(10, state.message.length + 2));
    lines.push("╭" + "─".repeat(boxWidth) + "╮");
    lines.push("│ " + trunc(state.message, boxWidth - 2).padEnd(boxWidth - 2) + " │");
    lines.push("╰" + "─".repeat(boxWidth) + "╯");
  } else {
    for (let i = start; i < Math.min(state.entries.length, start + visibleRows - 1); i++) {
      const ent = state.entries[i];
      const name = (state.icons ? iconFor(ent) : "") + ent.name + (ent.isDir ? "/" : "");
      lines.push(trunc(name, leftWidth));
    }
  }

  if (state.preview) addPreview(state, lines, leftWidth, columns, visibleRows);

  process.stdout.write("\r");
  for (let i = 0; i < visibleRows; i++) {
    const line = lines[i] || "";
    process.stdout.write(trunc(line, columns) + "\x1b[K");
    if (i < visibleRows - 1) process.stdout.write("\n");
  }
  process.stdout.write(`\x1b[${visibleRows - 1}A`);
}

function addPreview(state: State, lines: string[], leftWidth: number, columns: number, visibleRows: number) {
  const ent = current(state);
  const rightWidth = Math.max(10, columns - leftWidth - 1);
  const preview = buildPreview(ent, rightWidth, visibleRows);
  for (let i = 0; i < visibleRows; i++) {
    const left = (lines[i] || "").padEnd(leftWidth).slice(0, leftWidth);
    const right = preview[i] || "";
    lines[i] = left + " " + trunc(right, rightWidth);
  }
}

function buildPreview(ent: Entry | undefined, width: number, height: number): string[] {
  if (!ent) return [];
  if (ent.isDir) {
    try {
      return fs.readdirSync(ent.full).slice(0, height).map((n: string) => n);
    } catch (err: any) {
      return [err?.message || String(err)];
    }
  }
  if (!ent.isFile || ent.size > 1024 * 1024) return [`${humanSize(ent.size)} ${modeString(ent.mode)}`];
  try {
    const text = fs.readFileSync(ent.full, "utf8").replace(/\t/g, "    ");
    return text.split(/\r?\n/).slice(0, height).map((s: string) => s.replace(/[^\x20-\x7e]/g, "."));
  } catch (_) {
    return [`${humanSize(ent.size)} ${modeString(ent.mode)}`];
  }
}

function trunc(s: string, n: number): string {
  if (n <= 0) return "";
  return s.length > n ? s.slice(0, Math.max(0, n - 1)) : s;
}

function humanSize(size: number): string {
  const units = ["B", "K", "M", "G", "T"];
  let n = size;
  let u = 0;
  while (n >= 1024 && u < units.length - 1) { n /= 1024; u++; }
  return (u === 0 ? String(n) : n.toFixed(1)) + units[u];
}

function modeString(mode: number): string {
  const bits = ["r", "w", "x"];
  let out = (mode & 0o040000) ? "d" : "-";
  for (let shift = 6; shift >= 0; shift -= 3) {
    for (let i = 0; i < 3; i++) out += (mode & (1 << (shift + 2 - i))) ? bits[i] : "-";
  }
  return out;
}

main();
