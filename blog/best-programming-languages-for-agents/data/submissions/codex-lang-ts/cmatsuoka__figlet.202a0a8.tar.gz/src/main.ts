declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

type Glyph = string[];

interface Font {
  hardblank: string;
  height: number;
  oldLayout: number;
  fullLayout: number | null;
  printDirection: number;
  glyphs: Map<number, Glyph>;
  name: string;
}

interface Options {
  fontDir: string;
  fontName: string;
  width: number;
  justify: "left" | "center" | "right" | "auto";
  direction: "ltr" | "rtl" | "auto";
  layout: "font" | "smush" | "kern" | "full" | "overlap";
  explicitMode: number | null;
  paragraph: boolean;
  deutsch: boolean;
  info: number;
}

const VERSION_TEXT =
  "FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,\n" +
  "Christiaan Keet and Claudio Matsuoka\n" +
  "Internet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012\n\n" +
  "FIGlet, along with the various FIGlet fonts and documentation, may be\n" +
  "freely copied and distributed.\n\n" +
  "If you use FIGlet, please send an e-mail message to <info@figlet.org>.\n\n" +
  "The latest version of FIGlet is available from the web site,\n" +
  "\thttp://www.figlet.org/\n";

const USAGE =
  "Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]\n" +
  "              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]\n" +
  "              [ -C controlfile ] [ -I infocode ] [ message ]";

function main() {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed.error) {
    process.stderr.write(parsed.error + "\n" + USAGE + "\n");
    process.exit(1);
  }
  const opt = parsed.options!;
  if (opt.info >= 0) {
    printInfo(opt);
    return;
  }

  let input: string;
  if (parsed.messageParts!.length > 0) {
    input = parsed.messageParts!.join(" ");
  } else {
    input = fs.readFileSync(0, "utf8");
  }
  input = input.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  if (opt.paragraph) input = paragraphize(input);
  if (opt.deutsch) input = deutschMap(input);

  let font: Font;
  try {
    font = loadFont(opt.fontDir, opt.fontName);
  } catch {
    process.stderr.write(`executable: ${opt.fontName}: Unable to open font file\n`);
    process.exit(1);
  }

  const out = renderText(input, font, opt);
  process.stdout.write(out);
}

function defaultFontDir(): string {
  if (fs.existsSync(path.join(process.cwd(), "fonts"))) return "fonts";
  return "/usr/local/share/figlet";
}

function parseArgs(args: string[]): { options?: Options; messageParts?: string[]; error?: string } {
  const opt: Options = {
    fontDir: defaultFontDir(),
    fontName: "standard",
    width: 80,
    justify: "auto",
    direction: "auto",
    layout: "font",
    explicitMode: null,
    paragraph: false,
    deutsch: false,
    info: -1,
  };
  const msg: string[] = [];
  const needValue = new Set(["d", "f", "m", "w", "C", "I"]);
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") {
      msg.push(...args.slice(i + 1));
      break;
    }
    if (!a.startsWith("-") || a === "-") {
      msg.push(...args.slice(i));
      break;
    }
    let j = 1;
    while (j < a.length) {
      const ch = a[j++];
      let val: string | null = null;
      if (needValue.has(ch)) {
        if (j < a.length) {
          val = a.slice(j);
          j = a.length;
        } else {
          i++;
          if (i >= args.length) return { error: `./executable: option requires an argument -- '${ch}'` };
          val = args[i];
        }
      }
      switch (ch) {
        case "d": opt.fontDir = val!; break;
        case "f": opt.fontName = stripFontSuffix(val!); break;
        case "m": {
          const n = parseInt(val!, 10);
          opt.explicitMode = isNaN(n) ? 0 : n;
          if (n === -1) opt.layout = "full";
          else if (n === 0) opt.layout = "kern";
          else if (n === -2) opt.layout = "font";
          else opt.layout = "smush";
          break;
        }
        case "w": opt.width = Math.max(1, parseInt(val!, 10) || 80); break;
        case "I": opt.info = parseInt(val!, 10); if (isNaN(opt.info)) opt.info = 0; break;
        case "C": break;
        case "N": break;
        case "c": opt.justify = "center"; break;
        case "l": opt.justify = "left"; break;
        case "r": opt.justify = "right"; break;
        case "x": opt.justify = "auto"; break;
        case "L": opt.direction = "ltr"; break;
        case "R": opt.direction = "rtl"; break;
        case "X": opt.direction = "auto"; break;
        case "p": opt.paragraph = true; break;
        case "n": opt.paragraph = false; break;
        case "D": opt.deutsch = true; break;
        case "E": opt.deutsch = false; break;
        case "s": opt.layout = "font"; break;
        case "S": opt.layout = "smush"; break;
        case "k": opt.layout = "kern"; break;
        case "W": opt.layout = "full"; break;
        case "o": opt.layout = "overlap"; break;
        case "t":
          opt.width = parseInt(process.env.COLUMNS || "", 10) || opt.width;
          break;
        case "v": opt.info = 0; break;
        default:
          return { error: `./executable: invalid option -- '${ch}'` };
      }
    }
  }
  return { options: opt, messageParts: msg };
}

function stripFontSuffix(s: string): string {
  return s.replace(/\.(flf|tlf)$/i, "");
}

function printInfo(opt: Options) {
  switch (opt.info) {
    case 0: process.stdout.write(VERSION_TEXT + "\n" + USAGE + "\n"); break;
    case 1: process.stdout.write("20205\n"); break;
    case 2: process.stdout.write(opt.fontDir + "\n"); break;
    case 3: process.stdout.write(opt.fontName + "\n"); break;
    case 4: process.stdout.write(String(opt.width) + "\n"); break;
    case 5: process.stdout.write("flf2 tlf2\n"); break;
    default: break;
  }
}

function resolveFontPath(dir: string, name: string): string {
  const candidates: string[] = [];
  if (name.includes("/") || name.startsWith(".")) {
    candidates.push(name, `${name}.flf`, `${name}.tlf`);
  } else {
    candidates.push(path.join(dir, name), path.join(dir, `${name}.flf`), path.join(dir, `${name}.tlf`),
      name, `${name}.flf`, `${name}.tlf`);
  }
  for (const c of candidates) if (fs.existsSync(c)) return c;
  throw new Error("missing font");
}

function loadFont(dir: string, name: string): Font {
  const file = resolveFontPath(dir, name);
  const raw = fs.readFileSync(file, "utf8").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = raw.split("\n");
  const header = lines[0];
  if (!header.startsWith("flf2a") && !header.startsWith("tlf2a")) throw new Error("bad font");
  const hardblank = header.charAt(5);
  const parts = header.slice(6).trim().split(/\s+/).map((x: string) => parseInt(x, 10));
  const height = parts[0];
  const oldLayout = parts[3] ?? 0;
  const commentLines = parts[4] ?? 0;
  const printDirection = parts[5] ?? 0;
  const fullLayout = parts.length >= 7 ? parts[6] : null;
  let idx = 1 + commentLines;
  const glyphs = new Map<number, Glyph>();
  for (let code = 32; code <= 126; code++) {
    glyphs.set(code, readGlyph(lines, idx, height));
    idx += height;
  }
  const extraOrder = [196, 214, 220, 228, 246, 252, 223];
  for (const code of extraOrder) {
    if (idx + height <= lines.length) {
      glyphs.set(code, readGlyph(lines, idx, height));
      idx += height;
    }
  }
  while (idx < lines.length) {
    const tag = lines[idx++].trim();
    if (!tag) continue;
    const m = tag.match(/^(-?\d+|0x[0-9a-fA-F]+)/);
    if (!m || idx + height > lines.length) break;
    const code = m[1].startsWith("0x") ? parseInt(m[1], 16) : parseInt(m[1], 10);
    glyphs.set(code, readGlyph(lines, idx, height));
    idx += height;
  }
  return { hardblank, height, oldLayout, fullLayout, printDirection, glyphs, name };
}

function readGlyph(lines: string[], idx: number, height: number): Glyph {
  const raw = lines.slice(idx, idx + height);
  const end = raw[height - 1]?.slice(-1) || "@";
  return raw.map((line) => {
    let s = line;
    while (s.endsWith(end)) s = s.slice(0, -1);
    return s;
  });
}

function paragraphize(s: string): string {
  let out = "";
  for (let i = 0; i < s.length; i++) {
    if (s[i] === "\n" && i > 0 && s[i - 1] !== "\n" && s[i + 1] && s[i + 1] !== " " && s[i + 1] !== "\n") out += " ";
    else out += s[i];
  }
  return out;
}

function deutschMap(s: string): string {
  const map: Record<string, string> = { "[": "Ä", "\\": "Ö", "]": "Ü", "{": "ä", "|": "ö", "}": "ü", "~": "ß" };
  return Array.from(s).map((c) => map[c] || c).join("");
}

function getDirection(font: Font, opt: Options): "ltr" | "rtl" {
  if (opt.direction !== "auto") return opt.direction;
  return font.printDirection === 1 ? "rtl" : "ltr";
}

function getJustify(dir: "ltr" | "rtl", opt: Options): "left" | "center" | "right" {
  if (opt.justify !== "auto") return opt.justify;
  return dir === "rtl" ? "right" : "left";
}

function layoutMode(font: Font, opt: Options): { type: "full" | "kern" | "smush" | "overlap"; mode: number } {
  if (opt.layout === "full") return { type: "full", mode: 0 };
  if (opt.layout === "kern") return { type: "kern", mode: 0 };
  if (opt.layout === "overlap") return { type: "overlap", mode: 0 };
  if (opt.layout === "smush") return { type: "smush", mode: opt.explicitMode && opt.explicitMode > 0 ? opt.explicitMode : ((font.fullLayout ?? font.oldLayout) || 63) };
  const fl = font.fullLayout;
  if (fl !== null) {
    const horiz = fl & 63;
    if ((fl & 128) !== 0 || horiz > 0) return { type: "smush", mode: horiz || 63 };
    if ((fl & 64) !== 0) return { type: "kern", mode: 0 };
    return { type: "full", mode: 0 };
  }
  if (font.oldLayout < 0) return { type: "full", mode: 0 };
  if (font.oldLayout === 0) return { type: "kern", mode: 0 };
  return { type: "smush", mode: font.oldLayout };
}

function renderText(input: string, font: Font, opt: Options): string {
  const dir = getDirection(font, opt);
  const just = getJustify(dir, opt);
  const physical = input.endsWith("\n") ? input.slice(0, -1) : input;
  const logicalLines = physical.split("\n");
  const rendered: string[] = [];
  for (const line of logicalLines) {
    const parts = renderLogicalLine(line, font, opt, dir);
    for (const block of parts) {
      const width = Math.max(...block.map((r) => visibleLen(r)), 0);
      for (const r of block) rendered.push(justifyLine(r, width, opt.width, just).replaceAll(font.hardblank, " "));
    }
  }
  return rendered.join("\n") + (rendered.length ? "\n" : "");
}

function renderLogicalLine(line: string, font: Font, opt: Options, dir: "ltr" | "rtl"): string[][] {
  const chars = Array.from(line);
  if (dir === "rtl") chars.reverse();
  const blocks: string[][] = [];
  let cur = blank(font.height);
  let curWidth = 0;
  for (const ch of chars) {
    const glyph = glyphFor(font, ch);
    if (opt.width === 1 && ch !== " ") {
      if (curWidth > 0) blocks.push(cur);
      blocks.push(glyph);
      cur = blank(font.height);
      curWidth = 0;
      continue;
    }
    const next = appendGlyph(cur, glyph, font, opt);
    const nextWidth = Math.max(...next.map((r) => visibleLen(r)), 0);
    if (curWidth > 0 && nextWidth > opt.width && ch === " ") {
      blocks.push(cur);
      cur = blank(font.height);
      curWidth = 0;
    } else {
      cur = next;
      curWidth = nextWidth;
    }
  }
  blocks.push(cur);
  return blocks;
}

function blank(h: number): string[] {
  return Array.from({ length: h }, () => "");
}

function glyphFor(font: Font, ch: string): Glyph {
  const cp = ch.codePointAt(0) || 32;
  return font.glyphs.get(cp) || font.glyphs.get(0) || font.glyphs.get(63) || blank(font.height);
}

function appendGlyph(left: string[], right: Glyph, font: Font, opt: Options): string[] {
  const mode = layoutMode(font, opt);
  if (left.every((r) => r.length === 0)) return right.slice();
  const leftWidth = Math.max(...left.map((r) => r.length));
  const normLeft = left.map((r) => r.padEnd(leftWidth, " "));
  const max = Math.min(leftWidth, Math.max(...right.map((r) => r.length)));
  let best = 0;
  if (mode.type === "smush" || mode.type === "overlap") {
    for (let o = 1; o <= max; o++) {
      if (canOverlap(normLeft, right, o, font, { type: "kern", mode: 0 })) best = o;
      else break;
    }
    if (best < max && canOverlap(normLeft, right, best + 1, font, mode)) best++;
  } else {
    for (let o = 1; o <= max; o++) {
      if (canOverlap(normLeft, right, o, font, mode)) best = o;
      else break;
    }
  }
  return mergeOverlap(normLeft, right, best, font, mode);
}

function canOverlap(left: string[], right: Glyph, overlap: number, font: Font, mode: { type: string; mode: number }): boolean {
  if (mode.type === "full") return false;
  for (let r = 0; r < left.length; r++) {
    const l = left[r];
    const rr = right[r] || "";
    for (let i = 0; i < overlap; i++) {
      const a = charAt(l, l.length - overlap + i);
      const b = charAt(rr, i);
      if (a !== " " && b !== " ") {
        if (mode.type === "kern") return false;
        if (mode.type === "overlap") continue;
        if (smush(a, b, font, mode.mode) === null) return false;
      }
    }
  }
  return true;
}

function mergeOverlap(left: string[], right: Glyph, overlap: number, font: Font, mode: { type: string; mode: number }): string[] {
  const out: string[] = [];
  for (let r = 0; r < left.length; r++) {
    const l = left[r];
    const rr = right[r] || "";
    if (overlap === 0) {
      out.push(l + rr);
      continue;
    }
    let row = l.slice(0, Math.max(0, l.length - overlap));
    for (let i = 0; i < overlap; i++) {
      const a = charAt(l, l.length - overlap + i);
      const b = charAt(rr, i);
      if (a === " ") row += b;
      else if (b === " ") row += a;
      else if (mode.type === "overlap") row += b;
      else row += smush(a, b, font, mode.mode) ?? b;
    }
    row += rr.slice(overlap);
    out.push(row);
  }
  return out;
}

function charAt(s: string, i: number): string {
  return i < 0 || i >= s.length ? " " : s[i];
}

function smush(a: string, b: string, font: Font, mode: number): string | null {
  if (a === " ") return b;
  if (b === " ") return a;
  if (a === font.hardblank && b === font.hardblank) return (mode & 32) ? font.hardblank : null;
  if (a === font.hardblank || b === font.hardblank) return null;
  if ((mode & 1) && a === b) return a;
  if ((mode & 2) && "|/\\[]{}()<>".includes(a) && "|/\\[]{}()<>".includes(b)) {
    const order = ["|", "/\\", "[]", "{}", "()", "<>"];
    const ia = order.findIndex((g) => g.includes(a));
    const ib = order.findIndex((g) => g.includes(b));
    if (ia >= 0 && ib >= 0 && ia !== ib) return ia < ib ? b : a;
  }
  if ((mode & 4)) {
    const pairs: Record<string, string> = { "[]": "|", "][": "|", "{}": "|", "}{": "|", "()": "|", ")(": "|", "<>": "|", "><": "|" };
    if (pairs[a + b]) return pairs[a + b];
  }
  if ((mode & 8) && a === "/" && b === "\\") return "|";
  if ((mode & 8) && a === "\\" && b === "/") return "Y";
  if ((mode & 8) && a === ">" && b === "<") return "X";
  if ((mode & 16) && a === font.hardblank && b === font.hardblank) return font.hardblank;
  return null;
}

function visibleLen(s: string): number {
  return s.length;
}

function justifyLine(s: string, realWidth: number, width: number, just: "left" | "center" | "right"): string {
  if (width <= realWidth) return s;
  const pad = width - realWidth;
  if (just === "right") return " ".repeat(pad) + s;
  if (just === "center") return " ".repeat(Math.floor(pad / 2)) + s;
  return s;
}

main();
