declare const require: any;
declare const process: any;

const fs = require("fs");
const http = require("http");
const https = require("https");

type PathPart = string | number;
type Statement = { path: PathPart[]; value: any; text: string };

const HELP = `Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable

Usage:
  gron [OPTIONS] [FILE|URL|-]

Options:
  -u, --ungron     Reverse the operation (turn assignments back into JSON)
  -v, --values     Print just the values of provided assignments
  -c, --colorize   Colorize output (default on tty)
  -m, --monochrome Monochrome (don't colorize output)
  -s, --stream     Treat each line of input as a separate JSON object
  -k, --insecure   Disable certificate validation
  -x, --proxy      Set proxy configuration
      --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.
  -j, --json       Represent gron data as JSON stream
      --no-sort    Don't sort output (faster)
      --version    Print version information

Exit Codes:
  0\tOK
  1\tFailed to open file
  2\tFailed to read input
  3\tFailed to form statements
  4\tFailed to fetch URL
  5\tFailed to parse statements
  6\tFailed to encode JSON

Examples:
  gron /tmp/apiresponse.json
  gron http://jsonplaceholder.typicode.com/users/1 
  curl -s http://jsonplaceholder.typicode.com/users/1 | gron
  gron http://jsonplaceholder.typicode.com/users/1 | grep company | gron --ungron`;

function die(msg: string, code: number): never {
  process.stderr.write(msg + "\n");
  process.exit(code);
  throw new Error(msg);
}

function parseArgs(argv: string[]) {
  const opts: any = { ungron: false, values: false, json: false, stream: false, noSort: false };
  const files: string[] = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-u" || a === "--ungron") opts.ungron = true;
    else if (a === "-v" || a === "--values") opts.values = true;
    else if (a === "-j" || a === "--json") opts.json = true;
    else if (a === "-s" || a === "--stream") opts.stream = true;
    else if (a === "--no-sort") opts.noSort = true;
    else if (a === "-c" || a === "--colorize" || a === "-m" || a === "--monochrome" || a === "-k" || a === "--insecure") {
      /* accepted but not needed for non-tty test output */
    } else if (a === "-x" || a === "--proxy" || a === "--noproxy") {
      i++;
    } else if (a === "--version") {
      console.log("gron version dev");
      process.exit(0);
    } else if (a === "-h" || a === "--help") {
      console.log(HELP);
      process.exit(0);
    } else if (a.startsWith("-") && a !== "-") {
      process.stderr.write(`flag provided but not defined: ${a.replace(/^-+/, "-")}\n`);
      console.log(HELP);
      process.exit(2);
    } else {
      files.push(a);
    }
  }
  if (files.length > 1) {
    process.stderr.write(HELP + "\n");
    process.exit(2);
  }
  return { opts, file: files[0] || "-" };
}

function readStdin(): string {
  try {
    return fs.readFileSync(0, "utf8");
  } catch (e: any) {
    die(`failed to read input: ${e.message}`, 2);
  }
}

function fetchUrl(url: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith("https:") ? https : http;
    const req = lib.get(url, (res: any) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        fetchUrl(new URL(res.headers.location, url).toString()).then(resolve, reject);
        return;
      }
      if (res.statusCode < 200 || res.statusCode >= 300) {
        reject(new Error(`bad status: ${res.statusCode}`));
        return;
      }
      let data = "";
      res.setEncoding("utf8");
      res.on("data", (c: string) => data += c);
      res.on("end", () => resolve(data));
    });
    req.on("error", reject);
  });
}

async function readInput(file: string): Promise<string> {
  if (file === "-") return readStdin();
  if (/^https?:\/\//.test(file)) {
    try {
      return await fetchUrl(file);
    } catch (e: any) {
      die(`failed to fetch URL: ${e.message}`, 4);
    }
  }
  try {
    return fs.readFileSync(file, "utf8");
  } catch (e: any) {
    die(`open ${file}: ${e.message.split(": ").pop() || e.message}`, 1);
  }
}

function encode(v: any): string {
  return JSON.stringify(v);
}

function isContainer(v: any): boolean {
  return v !== null && typeof v === "object";
}

function isIdent(k: string): boolean {
  if (k === "" || /^(break|case|catch|class|const|continue|debugger|default|delete|do|else|export|extends|finally|for|function|if|import|in|instanceof|let|new|null|return|super|switch|this|throw|true|try|typeof|undefined|var|void|while|with|yield|false)$/.test(k)) return false;
  return /^[$_\p{L}][$_\p{L}\p{N}]*$/u.test(k);
}

function pathString(path: PathPart[]): string {
  let out = "json";
  for (const p of path) {
    if (typeof p === "number") out += `[${p}]`;
    else if (isIdent(p)) out += `.${p}`;
    else out += `[${encode(p)}]`;
  }
  return out;
}

function flatten(value: any, path: PathPart[] = [], out: Statement[] = []): Statement[] {
  const statementValue = isContainer(value) ? (Array.isArray(value) ? [] : {}) : value;
  const text = `${pathString(path)} = ${encode(statementValue)};`;
  out.push({ path: path.slice(), value: statementValue, text });
  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i++) flatten(value[i], path.concat(i), out);
  } else if (value !== null && typeof value === "object") {
    for (const key of Object.keys(value)) flatten(value[key], path.concat(key), out);
  }
  return out;
}

function parseJsonInput(input: string, stream: boolean): any {
  try {
    if (stream) {
      const arr: any[] = [];
      for (const line of input.split(/\r?\n/)) {
        if (line.length === 0) continue;
        arr.push(JSON.parse(line));
      }
      return arr;
    }
    return JSON.parse(input);
  } catch (e: any) {
    die(`failed to form statements: ${e.message}`, 3);
  }
}

function emitGron(root: any, asJson: boolean, noSort: boolean) {
  let statements = flatten(root);
  if (!noSort) statements = statements.sort((a, b) => a.text < b.text ? -1 : a.text > b.text ? 1 : 0);
  for (const st of statements) {
    if (asJson) console.log(encode([st.path, st.value]));
    else console.log(st.text);
  }
}

function parsePath(s: string): PathPart[] | null {
  if (!s.startsWith("json")) return null;
  const path: PathPart[] = [];
  let i = 4;
  while (i < s.length) {
    if (s[i] === ".") {
      i++;
      const start = i;
      while (i < s.length && /[$_\p{L}\p{N}]/u.test(s[i])) i++;
      if (i === start) return null;
      path.push(s.slice(start, i));
    } else if (s[i] === "[") {
      i++;
      if (s[i] === "\"") {
        let esc = false, j = i + 1;
        for (; j < s.length; j++) {
          const ch = s[j];
          if (esc) esc = false;
          else if (ch === "\\") esc = true;
          else if (ch === "\"") break;
        }
        if (j >= s.length || s[j + 1] !== "]") return null;
        try {
          path.push(JSON.parse(s.slice(i, j + 1)));
        } catch {
          return null;
        }
        i = j + 2;
      } else {
        const start = i;
        while (i < s.length && /[0-9]/.test(s[i])) i++;
        if (i === start || s[i] !== "]") return null;
        path.push(Number(s.slice(start, i)));
        i++;
      }
    } else {
      return null;
    }
  }
  return path;
}

function parseAssignments(input: string, asJson: boolean): Statement[] {
  const lines = input.split(/\r?\n/).filter(l => l.length > 0);
  const out: Statement[] = [];
  for (const line of lines) {
    if (asJson) {
      let pair: any;
      try {
        pair = JSON.parse(line);
      } catch {
        continue;
      }
      if (Array.isArray(pair) && pair.length === 2 && Array.isArray(pair[0])) {
        out.push({ path: pair[0], value: pair[1], text: line });
      }
      continue;
    }
    if (!line.endsWith(";")) die(`ungron failed for \`${line}\`: statement has no value`, 5);
    const eq = line.indexOf("=");
    if (eq < 0) die(`ungron failed for \`${line}\`: invalid statement`, 5);
    const left = line.slice(0, eq).trim();
    const rawValue = line.slice(eq + 1, -1).trim();
    const path = parsePath(left);
    if (!path) die(`ungron failed for \`${line}\`: invalid statement`, 5);
    let value: any;
    try {
      value = JSON.parse(rawValue);
    } catch {
      die(`ungron failed for \`${line}\`: invalid value \`${rawValue}\``, 5);
    }
    out.push({ path, value, text: line });
  }
  if (out.length === 0) die("no statements were parsed", 5);
  return out;
}

function setPath(rootBox: { value: any }, path: PathPart[], value: any) {
  if (path.length === 0) {
    rootBox.value = cloneContainerAware(value);
    return;
  }
  if (rootBox.value === undefined || rootBox.value === null || typeof rootBox.value !== "object") {
    rootBox.value = typeof path[0] === "number" ? [] : {};
  }
  let cur = rootBox.value;
  for (let i = 0; i < path.length; i++) {
    const p = path[i];
    const last = i === path.length - 1;
    if (last) {
      cur[p as any] = cloneContainerAware(value);
    } else {
      const next = path[i + 1];
      if (cur[p as any] === undefined || cur[p as any] === null || typeof cur[p as any] !== "object") {
        cur[p as any] = typeof next === "number" ? [] : {};
      }
      cur = cur[p as any];
    }
  }
}

function cloneContainerAware(v: any): any {
  if (v === null || typeof v !== "object") return v;
  return JSON.parse(JSON.stringify(v));
}

function fillArrayHoles(v: any): any {
  if (Array.isArray(v)) {
    for (let i = 0; i < v.length; i++) {
      if (!(i in v)) v[i] = null;
      else v[i] = fillArrayHoles(v[i]);
    }
  } else if (v !== null && typeof v === "object") {
    for (const k of Object.keys(v)) v[k] = fillArrayHoles(v[k]);
  }
  return v;
}

function sortObjectKeys(v: any): any {
  if (Array.isArray(v)) return v.map(sortObjectKeys);
  if (v !== null && typeof v === "object") {
    const out: any = {};
    for (const k of Object.keys(v).sort()) out[k] = sortObjectKeys(v[k]);
    return out;
  }
  return v;
}

function ungron(input: string, asJson: boolean) {
  const statements = parseAssignments(input, asJson);
  const box: { value: any } = { value: undefined };
  for (const st of statements) setPath(box, st.path, st.value);
  const root = sortObjectKeys(fillArrayHoles(box.value === undefined ? {} : box.value));
  try {
    console.log(JSON.stringify(root, null, 2));
  } catch (e: any) {
    die(`failed to encode JSON: ${e.message}`, 6);
  }
}

function values(input: string) {
  const statements = parseAssignments(input, false);
  for (const st of statements) {
    if (!isContainer(st.value)) console.log(String(st.value));
  }
}

async function main() {
  const { opts, file } = parseArgs(process.argv.slice(2));
  const input = await readInput(file);
  if (opts.ungron) ungron(input, opts.json);
  else if (opts.values && !opts.json) values(input);
  else if (opts.values && opts.json) return;
  else emitGron(parseJsonInput(input, opts.stream), opts.json, opts.noSort);
}

main().catch((e: any) => die(e.message || String(e), 2));
