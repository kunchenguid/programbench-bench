// @ts-nocheck
import * as fs from "fs";
import * as path from "path";
import { spawn } from "child_process";

const VERSION = "handlr 0.6.4";

type Desktop = {
  id: string;
  file: string;
  name: string;
  exec: string;
  mimes: string[];
};

type MimeApps = {
  sections: Map<string, Map<string, string[]>>;
};

function out(s = "") {
  process.stdout.write(s + "\n");
}

function err(s = "") {
  process.stderr.write(s + "\n");
}

function configHome(): string {
  return process.env.XDG_CONFIG_HOME || path.join(process.env.HOME || "", ".config");
}

function dataHomes(): string[] {
  const dirs = [process.env.XDG_DATA_HOME || path.join(process.env.HOME || "", ".local", "share")];
  const xdg = process.env.XDG_DATA_DIRS || "/usr/local/share:/usr/share";
  for (const d of xdg.split(":")) if (d) dirs.push(d);
  return dirs;
}

function mimeappsPath(): string {
  return path.join(configHome(), "mimeapps.list");
}

function ensureConfig() {
  const ch = configHome();
  fs.mkdirSync(path.join(ch, "handlr"), { recursive: true });
  const hp = path.join(ch, "handlr", "handlr.toml");
  if (!fs.existsSync(hp)) {
    fs.writeFileSync(hp, "enable_selector = false\nselector = \"rofi -dmenu -i -p 'Open With: '\"\n");
  }
  const mp = mimeappsPath();
  if (!fs.existsSync(mp)) {
    fs.writeFileSync(mp, "[Added Associations]\n\n[Default Applications]\n");
  }
}

function readMimeApps(): MimeApps {
  ensureConfig();
  const sections = new Map<string, Map<string, string[]>>();
  let current = "";
  for (const raw of fs.readFileSync(mimeappsPath(), "utf8").split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const m = /^\[(.*)\]$/.exec(line);
    if (m) {
      current = m[1];
      if (!sections.has(current)) sections.set(current, new Map());
      continue;
    }
    const eq = line.indexOf("=");
    if (eq >= 0 && current) {
      const k = line.slice(0, eq);
      const vals = line.slice(eq + 1).split(";").filter(Boolean);
      sections.get(current)!.set(k, vals);
    }
  }
  if (!sections.has("Added Associations")) sections.set("Added Associations", new Map());
  if (!sections.has("Default Applications")) sections.set("Default Applications", new Map());
  return { sections };
}

function writeMimeApps(apps: MimeApps) {
  const added = apps.sections.get("Added Associations") || new Map();
  const defs = apps.sections.get("Default Applications") || new Map();
  const lines: string[] = ["[Added Associations]"];
  for (const [k, v] of added) lines.push(`${k}=${v.join(";")};`);
  lines.push("", "[Default Applications]");
  for (const [k, v] of defs) lines.push(`${k}=${v.join(";")};`);
  fs.writeFileSync(mimeappsPath(), lines.join("\n"));
}

function parseDesktopFile(file: string, id: string): Desktop | null {
  let inEntry = false;
  const kv = new Map<string, string>();
  try {
    for (const raw of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith("#")) continue;
      const sec = /^\[(.*)\]$/.exec(line);
      if (sec) {
        inEntry = sec[1] === "Desktop Entry";
        continue;
      }
      if (!inEntry) continue;
      const eq = line.indexOf("=");
      if (eq > 0) kv.set(line.slice(0, eq), line.slice(eq + 1));
    }
  } catch {
    return null;
  }
  if ((kv.get("Type") || "Application") !== "Application") return null;
  return {
    id,
    file,
    name: kv.get("Name") || id,
    exec: kv.get("Exec") || "",
    mimes: (kv.get("MimeType") || "").split(";").filter(Boolean),
  };
}

function walkDesktop(dir: string, root: string, acc: Desktop[]) {
  let entries: fs.Dirent[];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walkDesktop(p, root, acc);
    else if (e.isFile() && e.name.endsWith(".desktop")) {
      const rel = path.relative(root, p).split(path.sep).join("-");
      const d = parseDesktopFile(p, rel);
      if (d) acc.push(d);
    }
  }
}

function desktops(): Desktop[] {
  const all: Desktop[] = [];
  for (const d of dataHomes()) walkDesktop(path.join(d, "applications"), path.join(d, "applications"), all);
  return all;
}

function desktopById(id: string): Desktop | undefined {
  return desktops().find((d) => d.id === id || path.basename(d.file) === id);
}

function systemHandlers(mime: string): string[] {
  const ids: string[] = [];
  for (const d of desktops()) {
    if (d.mimes.includes(mime) && !ids.includes(d.id)) ids.push(d.id);
  }
  ids.sort();
  return ids;
}

function parseMime(arg: string): string {
  if (arg.startsWith(".")) throw new Error(`could not figure out the mime type of '${arg}'`);
  const slash = arg.indexOf("/");
  if (slash < 0) throw new Error("mime parse error: a slash (/) was missing between the type and subtype");
  const bad = /[^A-Za-z0-9!#$&^_.+\-*\/]/.exec(arg);
  if (bad) {
    const code = bad[0].charCodeAt(0).toString(16).toUpperCase().padStart(2, "0");
    throw new Error(`mime parse error: an invalid token was encountered, ${code} at position ${bad.index}`);
  }
  if (slash === 0 || slash === arg.length - 1) throw new Error("mime parse error: an invalid token was encountered");
  return arg;
}

function invalidValue(name: string, msg: string): never {
  err(`error: Invalid value for '<${name}>': ${msg}`);
  err("");
  err("For more information try --help");
  process.exit(2);
}

function required(sub: string, arg: string): never {
  err("error: The following required arguments were not provided:");
  err(`    <${arg}>`);
  err("");
  err(`USAGE:`);
  err(`    executable ${sub} ${usageTail(sub)}`);
  err("");
  err("For more information try --help");
  process.exit(2);
}

function usageTail(sub: string): string {
  switch (sub) {
    case "get": return "[FLAGS] <mime>";
    case "set": return "<mime> <handler>";
    case "add": return "<mime> <handler>";
    case "unset": return "<mime>";
    case "launch": return "<mime> [args]...";
    case "open": return "<paths>...";
    case "list": return "[FLAGS]";
  }
  return "<SUBCOMMAND>";
}

function help(sub?: string) {
  if (!sub) {
    out(`${VERSION}

USAGE:
    executable <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    list      List default apps and the associated handlers
    open      Open a path/URL with its default handler
    set       Set the default handler for mime/extension
    unset     Unset the default handler for mime/extension
    launch    Launch the handler for specified extension/mime with optional arguments
    get       Get handler for this mime/extension
    add       Add a handler for given mime/extension Note that the first handler is the default`);
    return;
  }
  const desc: Record<string, string> = {
    list: "List default apps and the associated handlers",
    open: "Open a path/URL with its default handler",
    set: "Set the default handler for mime/extension",
    unset: "Unset the default handler for mime/extension",
    launch: "Launch the handler for specified extension/mime with optional arguments",
    get: "Get handler for this mime/extension",
    add: "Add a handler for given mime/extension Note that the first handler is the default",
  };
  out(`executable-${sub} 
${desc[sub]}

USAGE:
    executable ${sub} ${usageTail(sub)}
`);
  if (sub === "get") out(`ARGS:
    <mime>    

FLAGS:
        --json       
    -h, --help       Prints help information
    -V, --version    Prints version information`);
  else if (sub === "list") out(`FLAGS:
    -a, --all        
    -h, --help       Prints help information
    -V, --version    Prints version information`);
  else {
    const args = sub === "set" || sub === "add" ? "    <mime>       \n    <handler>    " :
      sub === "launch" ? "    <mime>       \n    <args>...    " :
      sub === "open" ? "    <paths>...    " : "    <mime>    ";
    out(`ARGS:
${args}

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information`);
  }
}

function table(rows: string[][]): string {
  const cols = rows.reduce((m, r) => Math.max(m, r.length), 1);
  const widths = Array(cols).fill(0);
  const data = rows.length ? rows : [[""]];
  for (const r of data) for (let i = 0; i < cols; i++) widths[i] = Math.max(widths[i], (r[i] || "").length);
  const top = "┌" + widths.map((w) => "─".repeat(w + 2)).join("┬") + "┐";
  const bot = "└" + widths.map((w) => "─".repeat(w + 2)).join("┴") + "┘";
  const body = data.map((r) => "│" + widths.map((w, i) => " " + (r[i] || "").padEnd(w) + " ").join("│") + "│");
  return [top, ...body, bot].join("\n");
}

function getHandlers(mime: string): string[] {
  const apps = readMimeApps();
  const defs = apps.sections.get("Default Applications")?.get(mime) || [];
  if (defs.length) return defs;
  return systemHandlers(mime);
}

function cleanExec(execLine: string): string {
  return execLine.split(/\s+/).filter((p) => !/^%[fFuU]$/.test(p)).join(" ").trim();
}

function cmdGet(args: string[]) {
  const json = args.includes("--json");
  args = args.filter((a) => a !== "--json");
  if (!args[0]) required("get", "mime");
  let mime: string;
  try { mime = parseMime(args[0]); } catch (e: any) { invalidValue("mime", e.message); }
  const h = getHandlers(mime)[0];
  if (!h) process.exit(1);
  if (!json) out(h);
  else {
    const d = desktopById(h);
    out(JSON.stringify({ handler: h, name: d?.name || h, cmd: cleanExec(d?.exec || "") }));
  }
}

function checkHandler(handler: string): Desktop {
  const d = desktopById(handler);
  if (!d) invalidValue("handler", `no handlers found for '${handler}'`);
  return d;
}

function cmdSetAdd(sub: "set" | "add", args: string[]) {
  if (!args[0]) required(sub, "mime");
  if (!args[1]) required(sub, "handler");
  let mime: string;
  try { mime = parseMime(args[0]); } catch (e: any) { invalidValue("mime", e.message); }
  checkHandler(args[1]);
  const apps = readMimeApps();
  const defs = apps.sections.get("Default Applications")!;
  if (sub === "set") defs.set(mime, [args[1]]);
  else defs.set(mime, [...(defs.get(mime) || []), args[1]]);
  writeMimeApps(apps);
}

function cmdUnset(args: string[]) {
  if (!args[0]) required("unset", "mime");
  let mime: string;
  try { mime = parseMime(args[0]); } catch (e: any) { invalidValue("mime", e.message); }
  const apps = readMimeApps();
  apps.sections.get("Default Applications")!.delete(mime);
  writeMimeApps(apps);
}

function cmdList(args: string[]) {
  const all = args.includes("--all") || args.includes("-a");
  const apps = readMimeApps();
  const defs = apps.sections.get("Default Applications") || new Map();
  const defaultRows = [...defs.entries()].map(([k, v]) => [k, v.join(", ")]);
  if (!all) {
    out(table(defaultRows));
    return;
  }
  out("Default Apps");
  out(table(defaultRows));
  out("System Apps");
  const byMime = new Map<string, string[]>();
  for (const d of desktops()) for (const m of d.mimes) {
    if (!byMime.has(m)) byMime.set(m, []);
    byMime.get(m)!.push(d.id);
  }
  const rows = [...byMime.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => [k, [...new Set(v)].sort().join(", ")]);
  out(table(rows));
}

function splitExec(s: string): string[] {
  const out: string[] = [];
  let cur = "", quote = "";
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (quote) {
      if (c === quote) quote = "";
      else if (c === "\\" && i + 1 < s.length) cur += s[++i];
      else cur += c;
    } else if (c === "'" || c === "\"") quote = c;
    else if (/\s/.test(c)) {
      if (cur) { out.push(cur); cur = ""; }
    } else if (c === "\\" && i + 1 < s.length) cur += s[++i];
    else cur += c;
  }
  if (cur) out.push(cur);
  return out;
}

function launchDesktop(d: Desktop, args: string[]) {
  const words = splitExec(d.exec).filter((w) => !["%i", "%c", "%k"].includes(w));
  const hasField = words.some((w) => /%[fFuU]/.test(w));
  const runs: string[][] = [];
  if (hasField && words.some((w) => /%[fu]/.test(w))) {
    for (const a of args.length ? args : [""]) runs.push(words.map((w) => w.replace(/%[fu]/g, a).replace(/%[FU]/g, args.join(" "))));
  } else {
    const r = words.map((w) => w.replace(/%[FU]/g, args.join(" ")).replace(/%%/g, "%"));
    if (!hasField) r.push(...args);
    runs.push(r);
  }
  for (const r of runs) {
    if (!r.length) continue;
    const child = spawn(r[0], r.slice(1), { detached: true, stdio: "ignore" });
    child.unref();
  }
}

function mimeForPath(p: string): string | null {
  if (/^[A-Za-z][A-Za-z0-9+.-]*:/.test(p)) {
    const scheme = p.slice(0, p.indexOf(":"));
    return `x-scheme-handler/${scheme}`;
  }
  const ext = path.extname(p).toLowerCase();
  const map: Record<string, string> = {
    ".txt": "text/plain", ".md": "text/plain", ".vim": "text/plain", ".ui": "application/xml",
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".pdf": "application/pdf",
    ".mp3": "audio/mp3", ".ogg": "audio/ogg", ".html": "text/html", ".htm": "text/html",
  };
  return map[ext] || null;
}

function cmdLaunch(args: string[]) {
  if (!args[0]) required("launch", "mime");
  let mime: string;
  try { mime = parseMime(args[0]); } catch (e: any) { invalidValue("mime", e.message); }
  const h = getHandlers(mime)[0];
  if (!h) process.exit(1);
  const d = desktopById(h);
  if (!d) process.exit(1);
  const rest = args.slice(1).filter((a, i) => !(i === 0 && a === "--"));
  launchDesktop(d, rest);
}

function cmdOpen(args: string[]) {
  if (!args[0]) required("open", "paths");
  let ok = true;
  for (const p of args) {
    const mime = mimeForPath(p);
    if (!mime) { ok = false; continue; }
    const h = getHandlers(mime)[0];
    const d = h ? desktopById(h) : undefined;
    if (!d) { ok = false; continue; }
    launchDesktop(d, [p]);
  }
  if (!ok) process.exit(1);
}

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0 || args[0] === "-h" || args[0] === "--help") return help();
  if (args[0] === "-V" || args[0] === "--version") return out(VERSION);
  const sub = args[0];
  const rest = args.slice(1);
  if (rest.includes("-h") || rest.includes("--help")) return help(sub);
  if (rest.includes("-V") || rest.includes("--version")) return out(VERSION);
  switch (sub) {
    case "list": return cmdList(rest);
    case "get": return cmdGet(rest);
    case "set": return cmdSetAdd("set", rest);
    case "add": return cmdSetAdd("add", rest);
    case "unset": return cmdUnset(rest);
    case "launch": return cmdLaunch(rest);
    case "open": return cmdOpen(rest);
    default:
      err(`error: Found argument '${sub}' which wasn't expected, or isn't valid in this context`);
      err("");
      err(`If you tried to supply \`${sub}\` as a PATTERN use \`-- ${sub}\``);
      err("");
      err("USAGE:");
      err("    executable <SUBCOMMAND>");
      err("");
      err("For more information try --help");
      process.exit(2);
  }
}

main();
