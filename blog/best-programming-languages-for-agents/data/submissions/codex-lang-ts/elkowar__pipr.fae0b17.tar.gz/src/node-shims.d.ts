declare const process: any;
declare module "node:fs" {
  const fs: any;
  export default fs;
}
declare module "node:child_process" {
  export function spawnSync(...args: any[]): any;
}
