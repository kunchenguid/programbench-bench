import fs from "node:fs";
import { spawnSync } from "node:child_process";

const helpText = `Usage: ./executable [options]

Options:
    -d, --default TEXT  text inserted into the textfield on startup
    -o, --out-file FILE write final command to file
        --in-file FILE  read initial command from file
        --config-reference 
                        print out the default configuration file
    -r, --raw-mode      keep linebreaks in finished command when closing
        --no-isolation  disable isolation. This will run the commands directly
                        on your system, without protection. Take care.
    -h, --help          print this help menu
`;

const configReference = `
#  ____  _
# |  _ \\(_)_ __  _ __       .________.
# | |_) | | '_ \\| '__|      |________|
# |  __/| | |_) | |          |_    -|
# |_|   |_| .__/|_|     xX  xXx___x_|
#         |_|
#
# A commandline utility by
# Leon Kowarschick

# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.
# finish_hook = "xclip -selection clipboard -in"

# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.
paranoid_history_mode_default = false

autoeval_mode_default = true

history_size = 500
cmdlist_always_show_preview = false
cmd_timeout_millis = 2000

highlighting_enabled = true

eval_environment = ["bash", "-c"]

# Snippets can be used to quickly insert common bits of shell
# use || (two pipes) where you want your cursor to be after insertion
[snippets]
s = " | sed -r 's/||//g'"

[help_viewers]
'm' = "man ??"
'h' = "?? --help | less"

[output_viewers]
'l' = "less"
`;

type Options = {
  defaultText?: string;
  outFile?: string;
  inFile?: string;
  configReference: boolean;
  rawMode: boolean;
  noIsolation: boolean;
  help: boolean;
};

function fail(message: string): never {
  console.error(`./executable: ${message}`);
  process.exit(1);
  throw new Error(message);
}

function parseArgs(argv: string[]): Options {
  const opts: Options = {
    configReference: false,
    rawMode: false,
    noIsolation: false,
    help: false,
  };

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    const needValue = (name: string): string => {
      const value = argv[++i];
      if (value === undefined) fail(`Argument to option '${name}' missing`);
      return value;
    };

    if (arg === "-h" || arg === "--help") opts.help = true;
    else if (arg === "--config-reference") opts.configReference = true;
    else if (arg === "-r" || arg === "--raw-mode") opts.rawMode = true;
    else if (arg === "--no-isolation") opts.noIsolation = true;
    else if (arg === "-d" || arg === "--default") opts.defaultText = needValue("default");
    else if (arg === "-o" || arg === "--out-file") opts.outFile = needValue("out-file");
    else if (arg === "--in-file") opts.inFile = needValue("in-file");
    else if (arg.startsWith("--")) fail(`Unrecognized option: '${arg.slice(2)}'`);
    else if (arg.startsWith("-") && arg.length > 1) fail(`Unrecognized option: '${arg.slice(1)}'`);
  }

  return opts;
}

function hasBwrap(): boolean {
  return spawnSync("bash", ["-lc", "command -v bwrap >/dev/null 2>&1"]).status === 0;
}

function initialCommand(opts: Options): string {
  if (opts.inFile) {
    try {
      return fs.readFileSync(opts.inFile, "utf8");
    } catch {
      return opts.defaultText ?? "";
    }
  }
  return opts.defaultText ?? "";
}

function finish(command: string, opts: Options, code = 0): never {
  const finalCommand = opts.rawMode ? command : command.replace(/\n/g, " ");
  if (opts.outFile) fs.writeFileSync(opts.outFile, finalCommand);
  process.stdout.write("\x1b[?1049l");
  process.exit(code);
  throw new Error("exited");
}

function render(command: string, output: string, status: string): void {
  const cols = Math.max(40, process.stdout.columns || 80);
  const rows = Math.max(10, process.stdout.rows || 24);
  const divider = "-".repeat(cols);
  const lines = [
    "Pipr",
    divider,
    command,
    divider,
    status,
    ...output.split(/\r?\n/).slice(0, rows - 7),
    divider,
    "Enter: evaluate  Ctrl-D/Esc: finish  Ctrl-C: abort",
  ];
  process.stdout.write("\x1b[H\x1b[2J" + lines.slice(0, rows).join("\r\n"));
}

function evaluate(command: string): string {
  if (!command.trim()) return "";
  const child = spawnSync("bash", ["-c", command], {
    encoding: "utf8",
    timeout: 2000,
    maxBuffer: 1024 * 1024,
  });
  let text = "";
  if (child.stdout) text += child.stdout;
  if (child.stderr) text += child.stderr;
  if (child.error && child.error.name === "Error") text += `${child.error.message}\n`;
  if (child.status !== 0 && child.status !== null) text += `[exit ${child.status}]\n`;
  if (child.signal) text += `[signal ${child.signal}]\n`;
  return text;
}

function runInteractive(opts: Options): void {
  let command = initialCommand(opts);
  let output = "";
  let status = "";

  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    process.stdout.write("\x1b[?1049h");
    console.error("Error: No such device or address (os error 6)");
    process.exit(1);
  }

  process.stdout.write("\x1b[?1049h");
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.setEncoding("utf8");
  render(command, output, status);

  const cleanupAbort = () => {
    process.stdin.setRawMode(false);
    process.stdout.write("\x1b[?1049l");
    process.exit(130);
  };
  process.on("SIGINT", cleanupAbort);

  process.stdin.on("data", (chunk: string) => {
    for (const ch of chunk) {
      if (ch === "\u0003") cleanupAbort();
      else if (ch === "\u0004" || ch === "\u001b") {
        process.stdin.setRawMode(false);
        finish(command, opts);
      } else if (ch === "\r" || ch === "\n") {
        status = "Running...";
        render(command, output, status);
        output = evaluate(command);
        status = "Done";
      } else if (ch === "\u007f" || ch === "\b") {
        command = command.slice(0, -1);
      } else if (ch >= " ") {
        command += ch;
      }
    }
    render(command, output, status);
  });
}

function main(): void {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) {
    process.stdout.write(helpText);
    return;
  }
  if (opts.configReference) {
    process.stdout.write(configReference);
    return;
  }
  if (!opts.noIsolation && !hasBwrap()) {
    console.log("bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode");
    process.exit(1);
  }
  runInteractive(opts);
}

main();
