declare const require: any;
declare const process: any;

const { existsSync, readFileSync } = require("fs");
const { spawnSync } = require("child_process");
const os = require("os");
const path = require("path");

const VERSION = "0.4.2";

function usage(binary: string): string {
  return `nsh ${VERSION}
A command-line shell that focuses on performance and productivity.

USAGE:
    ${binary} [FLAGS] [OPTIONS] [FILE]

FLAGS:
    -h, --help       Prints help information
    -l, --login      Behave like a login shell
        --norc       Don't load nshrc
        --version    Print the version

OPTIONS:
    -c <command>        The command to be executed

ARGS:
    <FILE>    The file to be executed`;
}

function shortUsage(binary: string, mode: "general" | "command" = "general"): string {
  if (mode === "command") {
    return `USAGE:
    ${binary} -c <command>

For more information try --help`;
  }
  return `USAGE:
    ${binary} [FLAGS] [OPTIONS] [FILE]

For more information try --help`;
}

function printUnexpected(binary: string, arg: string): void {
  console.error(`error: Found argument '${arg}' which wasn't expected, or isn't valid in this context\n`);
  console.error(shortUsage(binary));
  process.exit(1);
}

interface ParsedArgs {
  noRc: boolean;
  command?: string;
  file?: string;
}

function parseArgs(argv: string[], binary: string): ParsedArgs {
  const result: ParsedArgs = { noRc: false };
  let sawFile = false;

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "-h" || arg === "--help") {
      console.log(usage(binary));
      process.exit(0);
    }
    if (arg === "--version") {
      console.log(VERSION);
      process.exit(0);
    }
    if (arg === "-l" || arg === "--login") {
      continue;
    }
    if (arg === "--norc") {
      result.noRc = true;
      continue;
    }
    if (arg === "-c") {
      if (i + 1 >= argv.length) {
        console.error("error: The argument '-c <command>' requires a value but none was supplied\n");
        console.error(shortUsage(binary, "command"));
        process.exit(1);
      }
      result.command = argv[++i];
      return result;
    }
    if (arg.startsWith("-")) {
      printUnexpected(binary, arg);
    }
    if (result.command !== undefined || sawFile) {
      printUnexpected(binary, arg);
    }
    result.file = arg;
    sawFile = true;
  }
  return result;
}

function rcFile(): string | undefined {
  const xdg = process.env.XDG_CONFIG_HOME;
  if (xdg) {
    const xdgRc = path.join(xdg, "nsh", "nshrc");
    if (existsSync(xdgRc)) return xdgRc;
  }
  const home = process.env.HOME || os.homedir();
  const homeRc = path.join(home, ".nshrc");
  return existsSync(homeRc) ? homeRc : undefined;
}

function rewriteOrOr(input: string): string {
  let out = "";
  let single = false;
  let double = false;
  let backtick = false;
  let escaped = false;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    const next = input[i + 1];
    if (escaped) {
      out += ch;
      escaped = false;
      continue;
    }
    if (ch === "\\" && !single) {
      out += ch;
      escaped = true;
      continue;
    }
    if (ch === "'" && !double && !backtick) single = !single;
    else if (ch === '"' && !single && !backtick) double = !double;
    else if (ch === "`" && !single && !double) backtick = !backtick;

    if (!single && !double && !backtick && ch === "|" && next === "|") {
      out += ";";
      i++;
      continue;
    }
    out += ch;
  }
  return out;
}

function bashQuote(value: string): string {
  return `'${value.replace(/'/g, `'\\''`)}'`;
}

function buildScript(userScript: string, noRc: boolean): string {
  const lines = [
    "shopt -s expand_aliases",
    "command_not_found_handle() { printf 'nsh: command not found `%s\\'\\''\\n' \"$1\" >&2; return 1; }",
  ];
  if (!noRc) {
    const rc = rcFile();
    if (rc) lines.push(`source ${bashQuote(rc)}`);
  }
  lines.push(rewriteOrOr(userScript));
  return lines.join("\n");
}

function runScript(script: string, noRc: boolean): void {
  const child = spawnSync("/bin/bash", ["-c", buildScript(script, noRc)], {
    stdio: "inherit",
    env: process.env,
  });
  if (child.signal) {
    process.kill(process.pid, child.signal);
  }
  process.exit(child.status ?? 1);
}

function runInteractive(noRc: boolean): void {
  const child = spawnSync("/bin/bash", noRc ? ["--norc"] : [], {
    stdio: "inherit",
    env: process.env,
  });
  if (child.signal) process.kill(process.pid, child.signal);
  process.exit(child.status ?? 0);
}

function main(): void {
  const binary = "executable";
  const parsed = parseArgs(process.argv.slice(2), binary);
  if (parsed.command !== undefined) {
    runScript(parsed.command, parsed.noRc);
  }
  if (parsed.file !== undefined) {
    const content = readFileSync(parsed.file, "utf8");
    runScript(content, parsed.noRc);
  }
  runInteractive(parsed.noRc);
}

main();
