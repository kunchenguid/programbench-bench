#!/usr/bin/env node

declare function require(name: string): any;
declare const process: any;

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

type Vars = Map<string, string>;
type Rule = { name: string; vars: Vars };
type Edge = {
  outputs: string[];
  implicitOutputs: string[];
  rule: string;
  inputs: string[];
  implicit: string[];
  orderOnly: string[];
  vars: Vars;
  line: number;
};
type Manifest = {
  vars: Vars;
  rules: Map<string, Rule>;
  edges: Edge[];
  defaults: string[];
  edgeByOut: Map<string, Edge>;
};

const VERSION = "1.14.0.git";

function usage(): string {
  return `usage: ninja [options] [targets...]

if targets are unspecified, builds the 'default' target (see manual).

options:
  --version      print ninja version ("${VERSION}")
  -v, --verbose  show all command lines while building
  --quiet        don't show progress status, just command output

  -C DIR   change to DIR before doing anything else
  -f FILE  specify input build file [default=build.ninja]

  -j N     run N jobs in parallel (0 means infinity) [default=6 on this system]
  -k N     keep going until N jobs fail (0 means infinity) [default=1]
  -l N     do not start new jobs if the load average is greater than N
  -n       dry run (don't run commands but act like they succeeded)

  -d MODE  enable debugging (use '-d list' to list modes)
  -t TOOL  run a subtool (use '-t list' to list subtools)
    terminates toplevel options; further flags are passed to the tool
  -w FLAG  adjust warnings (use '-w list' to list warnings)
`;
}

function die(msg: string): void {
  console.error(`ninja: error: ${msg}`);
  process.exit(1);
}

function lexWords(s: string): string[] {
  const out: string[] = [];
  let cur = "";
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === "$") {
      const n = s[++i] ?? "";
      if (n === " " || n === ":" || n === "$" || n === "\n") cur += n;
      else {
        cur += "$" + n;
      }
    } else if (/\s/.test(c)) {
      if (cur) {
        out.push(cur);
        cur = "";
      }
    } else cur += c;
  }
  if (cur) out.push(cur);
  return out;
}

function joinContinuations(text: string): string[] {
  const raw = text.replace(/\r\n/g, "\n").split("\n");
  const lines: string[] = [];
  for (let i = 0; i < raw.length; i++) {
    let line = raw[i];
    while (line.endsWith("$") && !line.endsWith("$$") && i + 1 < raw.length) {
      line = line.slice(0, -1) + raw[++i].replace(/^\s+/, "");
    }
    lines.push(line);
  }
  return lines;
}

function expand(str: string, scopes: Vars[]): string {
  let res = "";
  for (let i = 0; i < str.length; i++) {
    const c = str[i];
    if (c !== "$") {
      res += c;
      continue;
    }
    const n = str[++i];
    if (n === undefined) break;
    if (n === "$") res += "$";
    else if (n === " ") res += " ";
    else if (n === ":") res += ":";
    else if (n === "\n") {}
    else if (n === "{") {
      const end = str.indexOf("}", i + 1);
      if (end < 0) res += "${";
      else {
        const key = str.slice(i + 1, end);
        res += lookup(key, scopes);
        i = end;
      }
    } else if (/[A-Za-z0-9_-]/.test(n)) {
      let j = i;
      while (j + 1 < str.length && /[A-Za-z0-9_-]/.test(str[j + 1])) j++;
      res += lookup(str.slice(i, j + 1), scopes);
      i = j;
    } else res += n;
  }
  return res;
}

function lookup(k: string, scopes: Vars[]): string {
  for (const s of scopes) if (s.has(k)) return s.get(k)!;
  return "";
}

function parseFile(file: string, manifest: Manifest, baseScopes: Vars[] = [manifest.vars]) {
  let text: string;
  try {
    text = fs.readFileSync(file, "utf8");
  } catch (e: any) {
    die(`loading '${file}': ${e.code === "ENOENT" ? "No such file or directory" : e.message}`);
  }
  const dir = path.dirname(file);
  const lines = joinContinuations(text);
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    if (/^\s/.test(raw)) die(`${file}:${i + 1}: unexpected indent`);
    if (line.startsWith("rule ")) {
      const name = line.slice(5).trim();
      const vars: Vars = new Map();
      while (i + 1 < lines.length && /^\s+/.test(lines[i + 1])) {
        const sub = lines[++i].trim();
        const eq = sub.indexOf("=");
        if (eq >= 0) vars.set(sub.slice(0, eq).trim(), sub.slice(eq + 1).trim());
      }
      manifest.rules.set(name, { name, vars });
      continue;
    }
    if (line.startsWith("build ")) {
      let rest = line.slice(6);
      const colon = findColon(rest);
      if (colon < 0) die(`${file}:${i + 1}: expected ':' in build statement`);
      const outsPart = rest.slice(0, colon).trim();
      rest = rest.slice(colon + 1).trim();
      const tokens = lexWords(rest);
      if (!tokens.length) die(`${file}:${i + 1}: expected build command name`);
      const rule = tokens.shift()!;
      const outsT = lexWords(outsPart);
      const outputs: string[] = [];
      const implicitOutputs: string[] = [];
      let outImp = false;
      for (const t of outsT) {
        if (t === "|") outImp = true;
        else (outImp ? implicitOutputs : outputs).push(expand(t, baseScopes));
      }
      const inputs: string[] = [], implicit: string[] = [], orderOnly: string[] = [];
      let mode: "in" | "imp" | "order" = "in";
      for (const t of tokens) {
        if (t === "|") mode = "imp";
        else if (t === "||") mode = "order";
        else (mode === "in" ? inputs : mode === "imp" ? implicit : orderOnly).push(expand(t, baseScopes));
      }
      const vars: Vars = new Map();
      while (i + 1 < lines.length && /^\s+/.test(lines[i + 1])) {
        const sub = lines[++i].trim();
        const eq = sub.indexOf("=");
        if (eq >= 0) vars.set(sub.slice(0, eq).trim(), sub.slice(eq + 1).trim());
      }
      const e: Edge = { outputs, implicitOutputs, rule, inputs, implicit, orderOnly, vars, line: i + 1 };
      manifest.edges.push(e);
      for (const o of [...outputs, ...implicitOutputs]) manifest.edgeByOut.set(o, e);
      continue;
    }
    if (line.startsWith("default ")) {
      manifest.defaults.push(...lexWords(line.slice(8)).map(t => expand(t, baseScopes)));
      continue;
    }
    if (line.startsWith("include ") || line.startsWith("subninja ")) {
      const inc = expand(line.replace(/^(include|subninja)\s+/, ""), baseScopes);
      parseFile(path.resolve(dir, inc), manifest, baseScopes);
      continue;
    }
    if (line.startsWith("pool ")) {
      while (i + 1 < lines.length && /^\s+/.test(lines[i + 1])) i++;
      continue;
    }
    const eq = line.indexOf("=");
    if (eq >= 0) {
      manifest.vars.set(line.slice(0, eq).trim(), line.slice(eq + 1).trim());
      continue;
    }
    if (line.startsWith("ninja_required_version")) continue;
    die(`${file}:${i + 1}: unknown build file statement`);
  }
}

function findColon(s: string): number {
  for (let i = 0; i < s.length; i++) {
    if (s[i] === "$") i++;
    else if (s[i] === ":") return i;
  }
  return -1;
}

function loadManifest(file: string): Manifest {
  const m: Manifest = { vars: new Map(), rules: new Map(), edges: [], defaults: [], edgeByOut: new Map() };
  m.rules.set("phony", { name: "phony", vars: new Map([["command", ""]]) });
  parseFile(file, m);
  return m;
}

function edgeVars(m: Manifest, e: Edge): Vars[] {
  const special: Vars = new Map();
  special.set("in", e.inputs.join(" "));
  special.set("in_newline", e.inputs.join("\n"));
  special.set("out", e.outputs.join(" "));
  const rule = m.rules.get(e.rule);
  return [special, e.vars, rule?.vars ?? new Map(), m.vars];
}

function getVar(m: Manifest, e: Edge, name: string): string {
  return expand(lookup(name, edgeVars(m, e).slice(1)), edgeVars(m, e));
}

function commandOf(m: Manifest, e: Edge): string {
  return getVar(m, e, "command");
}

function descOf(m: Manifest, e: Edge): string {
  const d = getVar(m, e, "description");
  return d || commandOf(m, e);
}

function statTime(p: string): number | null {
  try { return fs.statSync(p).mtimeMs; } catch { return null; }
}

function needsBuild(m: Manifest, e: Edge): boolean {
  if (e.rule === "phony") return false;
  const outs = e.outputs.map(statTime);
  if (outs.some(x => x === null)) return true;
  const oldestOut = Math.min(...outs as number[]);
  for (const inp of [...e.inputs, ...e.implicit]) {
    const t = statTime(inp);
    if (t === null) {
      if (!m.edgeByOut.has(inp)) return true;
    } else if (t > oldestOut) return true;
  }
  return false;
}

function topo(m: Manifest, targets: string[]): Edge[] {
  const order: Edge[] = [];
  const seen = new Set<Edge>();
  const visiting = new Set<Edge>();
  const visitTarget = (t: string) => {
    const e = m.edgeByOut.get(t);
    if (!e) return;
    visit(e);
  };
  const visit = (e: Edge) => {
    if (seen.has(e)) return;
    if (visiting.has(e)) die("dependency cycle");
    visiting.add(e);
    for (const i of [...e.inputs, ...e.implicit, ...e.orderOnly]) visitTarget(i);
    visiting.delete(e);
    seen.add(e);
    order.push(e);
  };
  for (const t of targets) visitTarget(t);
  return order;
}

function defaultTargets(m: Manifest): string[] {
  if (m.defaults.length) return m.defaults;
  return m.edges.length ? m.edges[0].outputs : [];
}

function runBuild(m: Manifest, targets: string[], opts: any): number {
  const requested = targets.length ? targets : defaultTargets(m);
  for (const t of requested) {
    if (!m.edgeByOut.has(t) && statTime(t) === null) die(`unknown target '${t}'`);
  }
  const all = topo(m, requested);
  for (const e of all) {
    for (const i of [...e.inputs, ...e.implicit]) {
      if (!m.edgeByOut.has(i) && statTime(i) === null) {
        die(`'${i}', needed by '${e.outputs[0]}', missing and no known rule to make it`);
      }
    }
  }
  const todo = all.filter(e => opts.dryRun || needsBuild(m, e));
  if (!todo.length) {
    if (!opts.quiet) console.log("ninja: no work to do.");
    return 0;
  }
  let n = 0;
  for (const e of todo) {
    n++;
    const cmd = commandOf(m, e);
    if (!cmd) continue;
    if (!opts.quiet) console.log(`[${n}/${todo.length}] ${opts.verbose ? cmd : descOf(m, e)}`);
    if (opts.dryRun) continue;
    const rspfile = getVar(m, e, "rspfile");
    if (rspfile) {
      const content = getVar(m, e, "rspfile_content");
      fs.writeFileSync(rspfile, content);
    }
    const r = spawnSync(cmd, { shell: true, stdio: "inherit" });
    if (rspfile) try { fs.unlinkSync(rspfile); } catch {}
    if ((r.status ?? 1) !== 0) return r.status ?? 1;
    const depfile = getVar(m, e, "depfile");
    if (depfile) try { fs.unlinkSync(depfile); } catch {}
  }
  return 0;
}

function clean(m: Manifest, args: string[]): number {
  let count = 0;
  const targets = args.filter(a => !a.startsWith("-"));
  const edges = targets.length ? topo(m, targets) : m.edges;
  for (const e of edges) {
    for (const o of [...e.outputs, ...e.implicitOutputs]) {
      try { fs.unlinkSync(o); count++; } catch {}
    }
  }
  console.log(`Cleaning... ${count} files.`);
  return 0;
}

function subtool(m: Manifest, tool: string, args: string[]): number {
  if (tool === "list") {
    console.log(`ninja subtools:
     browse  browse dependency graph in a web browser
      clean  clean built files
   commands  list all commands required to rebuild given targets
     inputs  list all inputs required to rebuild given targets
multi-inputs  print one or more sets of inputs required to build targets
       deps  show dependencies stored in the deps log
missingdeps  check deps log dependencies on generated files
      graph  output graphviz dot file for targets
      query  show inputs/outputs for a path
    targets  list targets by their rule or depth in the DAG
     compdb  dump JSON compilation database to stdout
compdb-targets  dump JSON compilation database for a given list of targets to stdout
  recompact  recompacts ninja-internal data structures
     restat  restats all outputs in the build log
      rules  list all rules
  cleandead  clean built files that are no longer produced by the manifest`);
    return 0;
  }
  if (tool === "rules") {
    for (const r of m.rules.keys()) console.log(r);
    return 0;
  }
  if (tool === "targets") {
    const mode = args[0];
    if (mode === "all") {
      for (const e of m.edges) for (const o of e.outputs) console.log(`${o}: ${e.rule}`);
    } else if (mode === "rule" && args[1]) {
      for (const e of m.edges) if (e.rule === args[1]) for (const o of e.outputs) console.log(o);
    } else {
      for (const e of m.edges) for (const o of e.outputs) console.log(`${o}: ${e.rule}`);
    }
    return 0;
  }
  if (tool === "commands") {
    for (const e of topo(m, args.length ? args : defaultTargets(m))) {
      const c = commandOf(m, e);
      if (c) console.log(c);
    }
    return 0;
  }
  if (tool === "inputs") {
    const s = new Set<string>();
    for (const e of topo(m, args.length ? args : defaultTargets(m))) for (const i of e.inputs) if (!m.edgeByOut.has(i)) s.add(i);
    for (const x of [...s].sort()) console.log(x);
    return 0;
  }
  if (tool === "query") {
    for (const q of args) {
      const e = m.edgeByOut.get(q);
      console.log(`${q}:`);
      if (e) {
        console.log(`  input: ${e.rule}`);
        for (const i of [...e.inputs, ...e.implicit, ...e.orderOnly]) console.log(`    ${i}`);
      } else console.log("  input: unknown");
      console.log("  outputs:");
      for (const oe of m.edges) if ([...oe.inputs, ...oe.implicit, ...oe.orderOnly].includes(q)) for (const o of oe.outputs) console.log(`    ${o}`);
    }
    return 0;
  }
  if (tool === "graph") {
    console.log("digraph ninja {");
    console.log('rankdir="LR"');
    let id = 0;
    const ids = new Map<string, string>();
    const nid = (s: string) => ids.get(s) || (ids.set(s, `n${id++}`), ids.get(s)!);
    for (const e of topo(m, args.length ? args : defaultTargets(m))) {
      const rid = nid(`rule:${e.outputs[0]}`);
      console.log(`"${rid}" [label="${esc(e.rule)}", shape=ellipse]`);
      for (const o of e.outputs) console.log(`"${rid}" -> "${nid(o)}"; "${nid(o)}" [label="${esc(o)}"]`);
      for (const i of e.inputs) console.log(`"${nid(i)}" -> "${rid}" [arrowhead=none]; "${nid(i)}" [label="${esc(i)}"]`);
    }
    console.log("}");
    return 0;
  }
  if (tool === "compdb" || tool === "compdb-targets") {
    let edges = m.edges;
    if (tool === "compdb") {
      const rules = new Set(args);
      if (rules.size) edges = edges.filter(e => rules.has(e.rule));
    } else if (args.length) edges = topo(m, args);
    const arr = edges.filter(e => commandOf(m, e)).map(e => ({
      directory: process.cwd(),
      command: commandOf(m, e),
      file: e.inputs[0] || "",
      output: e.outputs[0] || ""
    }));
    console.log(JSON.stringify(arr, null, 2));
    return 0;
  }
  if (tool === "clean" || tool === "cleandead") return clean(m, args);
  if (["deps", "missingdeps", "recompact", "restat"].includes(tool)) return 0;
  die(`unknown tool '${tool}'`);
}

function esc(s: string): string { return s.replace(/\\/g, "\\\\").replace(/"/g, '\\"'); }

function main() {
  const args = process.argv.slice(2);
  let file = "build.ninja", tool: string | null = null;
  const opts: any = { dryRun: false, verbose: false, quiet: false };
  const targets: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--help" || a === "-h") { process.stdout.write(usage()); process.exit(1); }
    else if (a === "--version") { console.log(VERSION); return; }
    else if (a === "-v" || a === "--verbose") opts.verbose = true;
    else if (a === "--quiet") opts.quiet = true;
    else if (a === "-n") opts.dryRun = true;
    else if (a === "-C") process.chdir(args[++i]);
    else if (a.startsWith("-C") && a.length > 2) process.chdir(a.slice(2));
    else if (a === "-f") file = args[++i];
    else if (a.startsWith("-f") && a.length > 2) file = a.slice(2);
    else if (["-j", "-k", "-l", "-d", "-w"].includes(a)) i++;
    else if (/^-[jkl]/.test(a) || /^-[dw]/.test(a)) {}
    else if (a === "-t") { tool = args[++i]; targets.push(...args.slice(i + 1)); break; }
    else if (a.startsWith("-t") && a.length > 2) { tool = a.slice(2); targets.push(...args.slice(i + 1)); break; }
    else if (a.startsWith("-")) die(`unknown option '${a}'`);
    else targets.push(a);
  }
  const m = loadManifest(file);
  const code = tool ? subtool(m, tool, targets) : runBuild(m, targets, opts);
  process.exit(code);
}

main();
