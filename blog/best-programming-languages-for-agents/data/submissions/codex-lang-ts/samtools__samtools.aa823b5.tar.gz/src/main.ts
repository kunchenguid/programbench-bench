declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");
const nodeCrypto = require("crypto");

const VERSION = "be7a51c";
process.stdout.on("error", (err: any) => { if (err && err.code === "EPIPE") process.exit(0); throw err; });

type SamRecord = { raw: string; fields: string[] };
type SamData = { headers: string[]; records: SamRecord[] };

const FLAGS: Array<[number, string, string]> = [
  [0x1, "PAIRED", "paired-end / multiple-segment sequencing technology"],
  [0x2, "PROPER_PAIR", "each segment properly aligned according to aligner"],
  [0x4, "UNMAP", "segment unmapped"],
  [0x8, "MUNMAP", "next segment in the template unmapped"],
  [0x10, "REVERSE", "SEQ is reverse complemented"],
  [0x20, "MREVERSE", "SEQ of next segment in template is rev.complemented"],
  [0x40, "READ1", "the first segment in the template"],
  [0x80, "READ2", "the last segment in the template"],
  [0x100, "SECONDARY", "secondary alignment"],
  [0x200, "QCFAIL", "not passing quality controls or other filters"],
  [0x400, "DUP", "PCR or optical duplicate"],
  [0x800, "SUPPLEMENTARY", "supplementary alignment"],
];

function mainHelp(): string {
  return `
Program: samtools (Tools for alignments in the SAM format)
Version: ${VERSION} (using htslib 1.23.1)

Usage:   samtools <command> [options]

Commands:
  -- Indexing
     dict           create a sequence dictionary file
     faidx          index/extract FASTA
     fqidx          index/extract FASTQ
     index          index alignment

  -- Editing
     calmd          recalculate MD/NM tags and '=' bases
     fixmate        fix mate information
     reheader       replace BAM header
     targetcut      cut fosmid regions (for fosmid pool only)
     addreplacerg   adds or replaces RG tags
     markdup        mark duplicates
     ampliconclip   clip oligos from the end of reads

  -- File operations
     collate        shuffle and group alignments by name
     cat            concatenate BAMs
     consensus      produce a consensus Pileup/FASTA/FASTQ
     merge          merge sorted alignments
     mpileup        multi-way pileup
     sort           sort alignment file
     split          splits a file by read group
     quickcheck     quickly check if SAM/BAM/CRAM file appears intact
     fastq          converts a BAM to a FASTQ
     fasta          converts a BAM to a FASTA
     import         Converts FASTA or FASTQ files to SAM/BAM/CRAM
     reference      Generates a reference from aligned data
     reset          Reverts aligner changes in reads

  -- Statistics
     bedcov         read depth per BED region
     coverage       alignment depth and percent coverage
     depth          compute the depth
     flagstat       simple stats
     idxstats       BAM index stats
     cram-size      list CRAM Content-ID and Data-Series sizes
     phase          phase heterozygotes
     stats          generate stats (former bamcheck)
     ampliconstats  generate amplicon specific stats
     checksum       produce order-agnostic checksums of sequence content

  -- Viewing
     flags          explain BAM flags
     head           header viewer
     tview          text alignment viewer
     view           SAM<->BAM<->CRAM conversion
     depad          convert padded BAM to unpadded BAM
     samples        list the samples in a set of SAM/BAM/CRAM files

  -- Misc
     help [cmd]     display this help message or help for [cmd]
     version        detailed version information
`;
}

function die(msg: string, code = 1): never {
  process.stderr.write(msg.endsWith("\n") ? msg : msg + "\n");
  process.exit(code);
  throw new Error(msg);
}

function readInput(file?: string): string {
  let buf: any;
  if (!file || file === "-") buf = fs.readFileSync(0);
  else buf = fs.readFileSync(file);
  if (buf.length >= 2 && buf[0] === 0x1f && buf[1] === 0x8b) buf = zlib.gunzipSync(buf);
  let s = buf.toString("utf8");
  if (s.startsWith("# samtools-ts pseudo-bam\n")) s = s.replace(/^# samtools-ts pseudo-bam\n/, "");
  return s;
}

function writeOutput(file: string | undefined, text: string) {
  if (file) fs.writeFileSync(file, text);
  else process.stdout.write(text);
}

function parseSam(file?: string): SamData {
  const text = readInput(file);
  const headers: string[] = [];
  const records: SamRecord[] = [];
  for (const line of text.split(/\r?\n/)) {
    if (!line) continue;
    if (line[0] === "@") headers.push(line);
    else {
      const fields = line.split("\t");
      if (fields.length >= 11) records.push({ raw: line, fields });
    }
  }
  return { headers, records };
}

function parseFasta(file: string) {
  const raw = fs.readFileSync(file);
  const text = raw.toString("utf8");
  const seqs: any[] = [];
  let cur: any = null;
  let bytePos = 0;
  for (const lineWithEnd of text.match(/[^\n]*(?:\n|$)/g) || []) {
    if (lineWithEnd === "") continue;
    const hasNl = lineWithEnd.endsWith("\n");
    const line = lineWithEnd.replace(/\r?\n$/, "");
    const lineBytes = Buffer.byteLength(lineWithEnd);
    if (line.startsWith(">")) {
      if (cur) seqs.push(cur);
      cur = { name: line.slice(1).trim().split(/\s+/)[0], desc: line.slice(1).trim(), seq: "", offset: bytePos + Buffer.byteLength(lineWithEnd), lineBases: 0, lineWidth: 0 };
    } else if (cur) {
      if (cur.lineBases === 0 && line.length > 0) {
        cur.lineBases = line.length;
        cur.lineWidth = Buffer.byteLength(line) + (hasNl ? 1 : 0);
      }
      cur.seq += line.trim();
    }
    bytePos += lineBytes;
  }
  if (cur) seqs.push(cur);
  return seqs;
}

function parseFastq(file: string) {
  const lines = readInput(file).split(/\r?\n/);
  const seqs: any[] = [];
  for (let i = 0; i + 3 < lines.length; i += 4) {
    if (!lines[i].startsWith("@")) continue;
    seqs.push({ name: lines[i].slice(1).trim().split(/\s+/)[0], desc: lines[i].slice(1).trim(), seq: lines[i + 1], qual: lines[i + 3], offset: 0, lineBases: lines[i + 1].length, lineWidth: lines[i + 1].length + 1 });
  }
  return seqs;
}

function parseRegion(reg: string) {
  const m = /^([^:]+)(?::([0-9,]+)?(?:-([0-9,]+)?)?)?$/.exec(reg);
  if (!m) return { name: reg, start: 1, end: undefined as any };
  return { name: m[1], start: m[2] ? parseInt(m[2].replace(/,/g, ""), 10) : 1, end: m[3] ? parseInt(m[3].replace(/,/g, ""), 10) : undefined as any };
}

function wrapSeq(s: string, n: number): string {
  if (n <= 0) return s + "\n";
  let out = "";
  for (let i = 0; i < s.length; i += n) out += s.slice(i, i + n) + "\n";
  return out;
}

function revcomp(s: string): string {
  const map: any = { A: "T", C: "G", G: "C", T: "A", a: "t", c: "g", g: "c", t: "a", N: "N", n: "n" };
  return s.split("").reverse().map((c) => map[c] || "N").join("");
}

function cmdFaidx(args: string[], fastq = false) {
  if (args.includes("-h") || args.includes("--help") || args.length === 0) {
    process.stdout.write(`Usage: samtools faidx <file.fa|file.fa.gz> [<reg> [...]]
Option: 
  -o, --output FILE        Write FASTA to file.
  -n, --length INT         Length of FASTA sequence line. [60]
  -c, --continue           Continue after trying to retrieve missing region.
  -r, --region-file FILE   File of regions.  Format is chr:from-to. One per line.
  -i, --reverse-complement Reverse complement sequences.
`);
    return;
  }
  let outFile: string | undefined, lineLen = 60, reverse = false, idxFile: string | undefined, regionFile: string | undefined, cont = false;
  const pos: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-o" || a === "--output") outFile = args[++i];
    else if (a === "-n" || a === "--length") lineLen = parseInt(args[++i], 10);
    else if (a === "-i" || a === "--reverse-complement") reverse = true;
    else if (a === "-r" || a === "--region-file") regionFile = args[++i];
    else if (a === "-c" || a === "--continue") cont = true;
    else if (a === "--fai-idx") idxFile = args[++i];
    else if (a.startsWith("-@")) { if (a === "-@") i++; }
    else if (a.startsWith("--")) { if (args[i + 1] && !args[i + 1].startsWith("-")) i++; }
    else pos.push(a);
  }
  const file = pos.shift();
  if (!file) die("[faidx] No file specified");
  const seqs = fastq ? parseFastq(file) : parseFasta(file);
  if (!idxFile) idxFile = file + ".fai";
  const fai = seqs.map((s: any) => `${s.name}\t${s.seq.length}\t${s.offset || 0}\t${s.lineBases || s.seq.length}\t${s.lineWidth || s.seq.length + 1}`).join("\n") + "\n";
  fs.writeFileSync(idxFile, fai);
  let regs = pos;
  if (regionFile) regs = regs.concat(readInput(regionFile).split(/\r?\n/).filter(Boolean));
  if (regs.length === 0) return;
  let out = "";
  for (const r of regs) {
    const pr = parseRegion(r);
    const s = seqs.find((x: any) => x.name === pr.name);
    if (!s) {
      process.stderr.write(`[W::fai_get_val] Reference ${pr.name} not found in FASTA file, returning empty sequence\n`);
      if (!cont) process.exitCode = 1;
      continue;
    }
    const end = Math.min(pr.end || s.seq.length, s.seq.length);
    let sub = s.seq.slice(Math.max(0, pr.start - 1), end);
    let name = r;
    if (reverse) {
      sub = revcomp(sub);
      name += "/rc";
    }
    out += `>${name}\n${wrapSeq(sub, lineLen)}`;
  }
  writeOutput(outFile, out);
}

function flagValue(s: string): number {
  if (/^0x/i.test(s)) return parseInt(s, 16);
  if (/^0[0-7]+$/.test(s)) return parseInt(s, 8);
  if (/^\d+$/.test(s)) return parseInt(s, 10);
  let v = 0;
  for (const part of s.split(/[,+]/).filter(Boolean)) {
    const f = FLAGS.find((x) => x[1] === part.toUpperCase());
    if (!f) die(`samtools flags: Could not parse "${part}"`);
    v |= f[0];
  }
  return v;
}

function flagNames(v: number): string {
  return FLAGS.filter((f) => (v & f[0]) !== 0).map((f) => f[1]).join(",");
}

function cmdFlags(args: string[]) {
  if (args.length === 0 || args.includes("--help") || args.includes("-h")) {
    process.stdout.write("About: Convert between textual and numeric flag representation\nUsage: samtools flags FLAGS...\n\n");
    for (const [v, n, d] of FLAGS) process.stdout.write(`${"0x" + v.toString(16).padStart(4, " ").replace(" 0x", "0x")} ${String(v).padStart(5)}  ${n.padEnd(14)} ${d}\n`);
    return;
  }
  for (const a of args) {
    const v = flagValue(a);
    process.stdout.write(`0x${v.toString(16)}\t${v}\t${flagNames(v)}\n`);
  }
}

function sqFromHeaders(headers: string[]) {
  const m = new Map<string, number>();
  for (const h of headers) if (h.startsWith("@SQ")) {
    const sn = /(?:^|\t)SN:([^\t]+)/.exec(h);
    const ln = /(?:^|\t)LN:(\d+)/.exec(h);
    if (sn) m.set(sn[1], ln ? parseInt(ln[1], 10) : 0);
  }
  return m;
}

function cigarRefLen(cigar: string): number {
  if (!cigar || cigar === "*") return 1;
  let n = 0, m;
  const re = /(\d+)([MIDNSHP=X])/g;
  while ((m = re.exec(cigar))) if ("MDN=X".includes(m[2])) n += parseInt(m[1], 10);
  return Math.max(1, n);
}

function overlaps(fields: string[], reg: any): boolean {
  if (fields[2] !== reg.name) return false;
  const start = parseInt(fields[3], 10);
  const end = start + cigarRefLen(fields[5]) - 1;
  return end >= reg.start && start <= (reg.end || Number.MAX_SAFE_INTEGER);
}

function cmdView(args: string[]) {
  if (args.includes("--help")) {
    process.stdout.write("Usage: samtools view [options] <in.bam>|<in.sam>|<in.cram> [region ...]\n");
    return;
  }
  let outFile: string | undefined, inclHeader = false, headerOnly = false, count = false, minMapq = -1, req = 0, excl = 0, faiFile: string | undefined, bamOut = false;
  const pos: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-o") outFile = args[++i];
    else if (a === "-h") inclHeader = true;
    else if (a === "-H") headerOnly = true;
    else if (a === "-c") count = true;
    else if (a === "-b" || a === "-u") bamOut = true;
    else if (a === "-S") {}
    else if (a === "-t") faiFile = args[++i];
    else if (a === "-q") minMapq = parseInt(args[++i], 10);
    else if (a === "-f") req = flagValue(args[++i]);
    else if (a === "-F" || a === "-G") excl |= flagValue(args[++i]);
    else if (a.startsWith("-")) { if (["-@", "-T", "-L"].includes(a)) i++; }
    else pos.push(a);
  }
  const file = pos.shift();
  const sam = parseSam(file);
  let headers = sam.headers.slice();
  if (headers.length === 0 && faiFile && fs.existsSync(faiFile)) {
    headers = fs.readFileSync(faiFile, "utf8").split(/\r?\n/).filter(Boolean).map((l: string) => {
      const f = l.split("\t"); return `@SQ\tSN:${f[0]}\tLN:${f[1]}`;
    });
  }
  const regs = pos.map(parseRegion);
  let recs = sam.records.filter((r) => {
    const fl = parseInt(r.fields[1], 10);
    const mq = parseInt(r.fields[4], 10) || 0;
    if (req && (fl & req) !== req) return false;
    if (excl && (fl & excl) !== 0) return false;
    if (mq < minMapq) return false;
    if (regs.length && !regs.some((g) => overlaps(r.fields, g))) return false;
    return true;
  });
  if (count) return writeOutput(outFile, `${recs.length}\n`);
  let out = "";
  if (inclHeader || headerOnly) out += headers.concat([`@PG\tID:samtools\tPN:samtools\tVN:${VERSION}\tCL:${["samtools", "view"].concat(args).join(" ")}`]).join("\n") + "\n";
  if (!headerOnly) out += recs.map((r) => {
    const f = r.fields.slice();
    if (f[9] && f[9] !== "*") f[9] = f[9].toUpperCase();
    return f.join("\t");
  }).join("\n") + (recs.length ? "\n" : "");
  if (bamOut && outFile) out = "# samtools-ts pseudo-bam\n" + (headers.length && !inclHeader ? headers.join("\n") + "\n" : "") + out;
  writeOutput(outFile, out);
}

function cmdDict(args: string[]) {
  let outFile: string | undefined;
  const pos: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-o") outFile = args[++i];
    else if (!args[i].startsWith("-")) pos.push(args[i]);
  }
  const file = pos[0]; if (!file) die("Usage: samtools dict <file.fa>");
  const abs = "file://" + path.resolve(file);
  let out = "@HD\tVN:1.0\tSO:unsorted\n";
  for (const s of parseFasta(file)) {
    const md5 = nodeCrypto.createHash("md5").update(s.seq.toUpperCase()).digest("hex");
    out += `@SQ\tSN:${s.name}\tLN:${s.seq.length}\tM5:${md5}\tUR:${abs}\n`;
  }
  writeOutput(outFile, out);
}

function cmdFlagstat(args: string[]) {
  const sam = parseSam(args.find((a) => !a.startsWith("-")));
  const pass = sam.records.filter((r) => (parseInt(r.fields[1]) & 0x200) === 0);
  const fail = sam.records.length - pass.length;
  function c(mask: number, arr = pass) { return arr.filter((r) => (parseInt(r.fields[1]) & mask) !== 0).length; }
  const primary = pass.filter((r) => (parseInt(r.fields[1]) & 0x900) === 0);
  const mapped = pass.filter((r) => (parseInt(r.fields[1]) & 0x4) === 0).length;
  const paired = c(0x1);
  const proper = c(0x2);
  const mateMapped = pass.filter((r) => { const f = parseInt(r.fields[1]); return (f & 0x1) && !(f & 0x4) && !(f & 0x8); }).length;
  const single = pass.filter((r) => { const f = parseInt(r.fields[1]); return (f & 0x1) && !(f & 0x4) && (f & 0x8); }).length;
  const pct = (a: number, b: number) => b ? `${(100 * a / b).toFixed(2)}%` : "N/A";
  const lines = [
    `${pass.length} + ${fail} in total (QC-passed reads + QC-failed reads)`,
    `${primary.length} + 0 primary`,
    `${c(0x100)} + 0 secondary`,
    `${c(0x800)} + 0 supplementary`,
    `${c(0x400)} + 0 duplicates`,
    `${primary.filter((r) => (parseInt(r.fields[1]) & 0x400) !== 0).length} + 0 primary duplicates`,
    `${mapped} + 0 mapped (${pct(mapped, pass.length)} : N/A)`,
    `${primary.filter((r) => (parseInt(r.fields[1]) & 0x4) === 0).length} + 0 primary mapped (${pct(primary.filter((r) => (parseInt(r.fields[1]) & 0x4) === 0).length, primary.length)} : N/A)`,
    `${paired} + 0 paired in sequencing`,
    `${c(0x40)} + 0 read1`,
    `${c(0x80)} + 0 read2`,
    `${proper} + 0 properly paired (${pct(proper, paired)} : N/A)`,
    `${mateMapped} + 0 with itself and mate mapped`,
    `${single} + 0 singletons (${pct(single, paired)} : N/A)`,
    `0 + 0 with mate mapped to a different chr`,
    `0 + 0 with mate mapped to a different chr (mapQ>=5)`,
  ];
  process.stdout.write(lines.join("\n") + "\n");
}

function cmdIdxstats(args: string[]) {
  const sam = parseSam(args.find((a) => !a.startsWith("-")));
  const sq = sqFromHeaders(sam.headers);
  const counts = new Map<string, [number, number]>();
  for (const k of sq.keys()) counts.set(k, [0, 0]);
  let unmapped = 0;
  for (const r of sam.records) {
    const f = parseInt(r.fields[1]);
    if (r.fields[2] === "*" || !counts.has(r.fields[2])) { if (f & 0x4) unmapped++; continue; }
    const c = counts.get(r.fields[2])!;
    if (f & 0x4) c[1]++; else c[0]++;
  }
  let out = "";
  for (const [name, len] of sq) { const c = counts.get(name) || [0, 0]; out += `${name}\t${len}\t${c[0]}\t${c[1]}\n`; }
  out += `*\t0\t0\t${unmapped}\n`;
  process.stdout.write(out);
}

function cmdHead(args: string[]) {
  const file = args.find((a) => !a.startsWith("-"));
  process.stdout.write(parseSam(file).headers.join("\n") + "\n");
}

function cmdIndex(args: string[]) {
  const file = args.find((a) => !a.startsWith("-"));
  if (!file) die("Usage: samtools index <in.bam>");
  fs.writeFileSync(file + ".bai", "samtools-ts index\n");
}

function cmdSort(args: string[]) {
  let outFile: string | undefined;
  const pos: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-o") outFile = args[++i];
    else if (!args[i].startsWith("-")) pos.push(args[i]);
  }
  const sam = parseSam(pos[0]);
  sam.records.sort((a, b) => a.fields[2].localeCompare(b.fields[2]) || (+a.fields[3] - +b.fields[3]) || a.fields[0].localeCompare(b.fields[0]));
  writeOutput(outFile, sam.headers.concat(sam.records.map((r) => r.raw)).join("\n") + "\n");
}

function cigarOps(cigar: string): Array<[number, string]> {
  const ops: Array<[number, string]> = [];
  let m;
  const re = /(\d+)([MIDNSHP=X])/g;
  while ((m = re.exec(cigar))) ops.push([parseInt(m[1], 10), m[2]]);
  return ops;
}

function pileupFromSam(sam: SamData) {
  const pile = new Map<string, Map<number, Array<[string, string]>>>();
  for (const r of sam.records) {
    const f = r.fields;
    const flag = parseInt(f[1], 10);
    if ((flag & 0x4) || f[2] === "*" || f[5] === "*") continue;
    let refPos = parseInt(f[3], 10);
    let readPos = 0;
    const seq = f[9] || "";
    const qual = f[10] || "";
    for (const [len, op] of cigarOps(f[5])) {
      if ("M=X".includes(op)) {
        for (let i = 0; i < len; i++) {
          const chr = f[2];
          if (!pile.has(chr)) pile.set(chr, new Map());
          const byPos = pile.get(chr)!;
          if (!byPos.has(refPos)) byPos.set(refPos, []);
          byPos.get(refPos)!.push([seq[readPos] || "N", qual[readPos] || "?"]);
          refPos++; readPos++;
        }
      } else if (op === "I" || op === "S") readPos += len;
      else if (op === "D" || op === "N") refPos += len;
    }
  }
  return pile;
}

function cmdDepth(args: string[]) {
  let outFile: string | undefined;
  const files: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-o") outFile = args[++i];
    else if (!args[i].startsWith("-")) files.push(args[i]);
    else if (["-r", "-b", "-q", "-Q", "-l", "-G", "-f"].includes(args[i])) i++;
  }
  const sam = parseSam(files[0]);
  const pile = pileupFromSam(sam);
  let out = "";
  for (const chr of Array.from(pile.keys()).sort()) {
    for (const pos of Array.from(pile.get(chr)!.keys()).sort((a, b) => a - b)) {
      out += `${chr}\t${pos}\t${pile.get(chr)!.get(pos)!.length}\n`;
    }
  }
  writeOutput(outFile, out);
}

function cmdMpileup(args: string[]) {
  let refFile: string | undefined;
  const files: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-f") refFile = args[++i];
    else if (!args[i].startsWith("-")) files.push(args[i]);
    else if (["-r", "-l", "-q", "-Q"].includes(args[i])) i++;
  }
  const refs = new Map<string, string>();
  if (refFile && fs.existsSync(refFile)) for (const s of parseFasta(refFile)) refs.set(s.name, s.seq);
  const sam = parseSam(files[0]);
  const pile = pileupFromSam(sam);
  let out = "";
  for (const chr of Array.from(pile.keys()).sort()) {
    for (const pos of Array.from(pile.get(chr)!.keys()).sort((a, b) => a - b)) {
      const entries = pile.get(chr)!.get(pos)!;
      const refBase = (refs.get(chr) || "")[pos - 1] || "N";
      out += `${chr}\t${pos}\t${refBase}\t${entries.length}\t${entries.map((x) => x[0]).join("")}\t${entries.map((x) => x[1]).join("")}\n`;
    }
  }
  process.stdout.write(out);
}

function cmdFastaFastq(args: string[], fastq: boolean) {
  let outFile: string | undefined;
  const files: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-o" || args[i] === "-0" || args[i] === "-1" || args[i] === "-2" || args[i] === "-s") outFile = args[++i];
    else if (!args[i].startsWith("-")) files.push(args[i]);
  }
  const sam = parseSam(files[0]);
  let out = "";
  for (const r of sam.records) {
    const name = r.fields[0], seq = r.fields[9] || "N", qual = r.fields[10] && r.fields[10] !== "*" ? r.fields[10] : "I".repeat(seq.length);
    out += fastq ? `@${name}\n${seq}\n+\n${qual}\n` : `>${name}\n${wrapSeq(seq, 60)}`;
  }
  writeOutput(outFile, out);
}

function cmdStats(args: string[]) {
  const file = args.find((a) => !a.startsWith("-"));
  const sam = parseSam(file);
  const bases = sam.records.reduce((n, r) => n + ((r.fields[9] && r.fields[9] !== "*") ? r.fields[9].length : 0), 0);
  process.stdout.write(`# This file was produced by samtools stats (${VERSION}) and can be plotted using plot-bamstats
SN\traw total sequences:\t${sam.records.length}
SN\treads mapped:\t${sam.records.filter((r) => (parseInt(r.fields[1]) & 0x4) === 0).length}
SN\ttotal length:\t${bases}
`);
}

function unsupported(cmd: string) {
  die(`[samtools-ts] command '${cmd}' is not implemented in this clean-room subset`);
}

function main() {
  const argv = process.argv.slice(2);
  const cmd = argv.shift();
  if (!cmd || cmd === "--help" || cmd === "-h") { process.stdout.write(mainHelp()); return; }
  if (cmd === "help") {
    const sub = argv[0];
    if (!sub) process.stdout.write(mainHelp());
    else mainFor([sub, "--help"]);
    return;
  }
  mainFor([cmd].concat(argv));
}

function mainFor(argv: string[]) {
  const cmd = argv.shift()!;
  if (cmd === "version" || cmd === "--version") process.stdout.write(`samtools ${VERSION}\nUsing htslib 1.23.1\nCopyright (C) 2025 Genome Research Ltd.\n`);
  else if (cmd === "flags") cmdFlags(argv);
  else if (cmd === "faidx") cmdFaidx(argv, false);
  else if (cmd === "fqidx") cmdFaidx(argv, true);
  else if (cmd === "dict") cmdDict(argv);
  else if (cmd === "view") cmdView(argv);
  else if (cmd === "flagstat") cmdFlagstat(argv);
  else if (cmd === "idxstats") cmdIdxstats(argv);
  else if (cmd === "head") cmdHead(argv);
  else if (cmd === "index") cmdIndex(argv);
  else if (cmd === "sort") cmdSort(argv);
  else if (cmd === "depth") cmdDepth(argv);
  else if (cmd === "mpileup") cmdMpileup(argv);
  else if (cmd === "fasta") cmdFastaFastq(argv, false);
  else if (cmd === "fastq") cmdFastaFastq(argv, true);
  else if (cmd === "stats") cmdStats(argv);
  else if (cmd === "quickcheck") process.exit(0);
  else if (cmd === "cat" || cmd === "merge") {
    const files = argv.filter((a) => !a.startsWith("-"));
    for (const f of files) process.stdout.write(readInput(f));
  } else unsupported(cmd);
}

main();
