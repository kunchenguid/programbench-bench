import * as fs from 'fs';
import * as path from 'path';
import * as zlib from 'zlib';

type Mode = 'compress' | 'decompress' | 'test';

interface Options {
  mode: Mode;
  stdout: boolean;
  force: boolean;
  remove: boolean;
  copyStat: boolean;
  output?: string;
  quality: number;
  qualitySet: boolean;
  lgwin: number;
  largeWindow?: number;
  comment?: Buffer;
  dictionary?: Buffer;
  concatenated: boolean;
  suffix: string;
  verbose: boolean;
  files: string[];
}

const HELP = `Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.
`;

function fail(message: string, showHelp = false): void {
  if (showHelp) process.stdout.write(HELP);
  if (message) process.stderr.write(message + '\n');
  process.exit(1);
}

function parseIntStrict(s: string): number | undefined {
  if (!/^-?\d+$/.test(s)) return undefined;
  return Number(s);
}

function decodeB64(s: string): Buffer {
  return Buffer.from(s, 'base64');
}

function parseArgs(argv: string[]): Options {
  const opt: Options = {
    mode: 'compress',
    stdout: false,
    force: false,
    remove: false,
    copyStat: true,
    quality: 11,
    qualitySet: false,
    lgwin: 0,
    concatenated: false,
    suffix: '.br',
    verbose: false,
    files: [],
  };

  let afterDashDash = false;
  const needValue = (args: string[], i: number, optName: string): [string, number] => {
    if (i + 1 >= args.length) fail('', true);
    return [args[i + 1], i + 1];
  };
  const setMode = (m: Mode, desc: string) => {
    if (opt.mode !== 'compress') fail(`command already set when parsing ${desc}`, true);
    opt.mode = m;
  };
  const setQuality = (n: number, raw: string) => {
    if (opt.qualitySet) fail('quality already set', true);
    if (!Number.isInteger(n) || n < 0 || n > 11) fail(`error parsing quality value [${raw}]`, true);
    opt.quality = n;
    opt.qualitySet = true;
  };
  const setLgwin = (n: number, raw: string) => {
    if (!Number.isInteger(n)) fail(`error parsing lgwin value [${raw}]`, true);
    if (n !== 0 && n < 10) fail(`lgwin parameter (${n}) smaller than the minimum (10)`, true);
    if (n > 24) fail(`lgwin parameter (${n}) larger than the maximum (24)`, true);
    opt.lgwin = n;
  };
  const setOutput = (v: string) => {
    if (opt.stdout) fail('write to standard output already set (--output)');
    opt.output = v;
  };
  const setStdout = () => {
    if (opt.output) fail('write to standard output already set (--output)');
    opt.stdout = true;
  };

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (afterDashDash) {
      opt.files.push(a);
      continue;
    }
    if (a === '--') {
      afterDashDash = true;
      continue;
    }
    if (a === '-' || !a.startsWith('-')) {
      opt.files.push(a);
      continue;
    }
    if (a.startsWith('--')) {
      const eq = a.indexOf('=');
      const name = eq >= 0 ? a.slice(2, eq) : a.slice(2);
      let value = eq >= 0 ? a.slice(eq + 1) : undefined;
      const requireEq = new Set(['quality', 'lgwin', 'large_window', 'comment', 'dictionary', 'output', 'suffix']);
      if (value === undefined && requireEq.has(name)) {
        [value, i] = needValue(argv, i, '--' + name);
      } else if (value === undefined && !['stdout', 'decompress', 'force', 'help', 'rm', 'keep', 'no-copy-stat', 'test', 'verbose', 'concatenated', 'version', 'best', 'squash'].includes(name)) {
        fail(`must pass the parameter as --${name}=value`, true);
      }
      switch (name) {
        case 'stdout': setStdout(); break;
        case 'decompress': setMode('decompress', '--decompress'); break;
        case 'force': opt.force = true; break;
        case 'help': process.stdout.write(HELP); process.exit(0);
        case 'rm': opt.remove = true; break;
        case 'keep': opt.remove = false; break;
        case 'no-copy-stat': opt.copyStat = false; break;
        case 'output': setOutput(value!); break;
        case 'quality': {
          const n = parseIntStrict(value!);
          setQuality(n as number, value!);
          break;
        }
        case 'test': setMode('test', '--test'); opt.stdout = true; break;
        case 'verbose':
          if (opt.verbose) fail('argument --verbose / -v already set', true);
          opt.verbose = true;
          break;
        case 'lgwin': {
          const n = parseIntStrict(value!);
          setLgwin(n as number, value!);
          break;
        }
        case 'large_window': {
          const n = parseIntStrict(value!);
          if (!Number.isInteger(n) || n! < 0 || n! > 30) fail(`error parsing large_window value [${value}]`, true);
          opt.largeWindow = n!;
          break;
        }
        case 'comment':
          opt.comment = decodeB64(value!);
          if (opt.comment.length > 80) fail('comment too long', true);
          break;
        case 'dictionary':
          try { opt.dictionary = fs.readFileSync(value!); }
          catch { fail(`failed to open dictionary file [${value}]: No such file or directory`); }
          break;
        case 'concatenated': opt.concatenated = true; break;
        case 'suffix': opt.suffix = value!; break;
        case 'version': process.stdout.write('brotli 1.2.0\n'); process.exit(0);
        case 'best': setQuality(11, '11'); break;
        case 'squash': break;
        default: fail(`must pass the parameter as --${name}=value`, true);
      }
      continue;
    }

    for (let p = 1; p < a.length; p++) {
      const ch = a[p];
      const rest = a.slice(p + 1);
      const takeAttachedOrNext = (name: string): string => {
        if (rest.length > 0) {
          p = a.length;
          return rest;
        }
        if (i + 1 >= argv.length) fail('', true);
        i++;
        p = a.length;
        return argv[i];
      };
      if (/[0-9]/.test(ch)) {
        setQuality(Number(ch), ch);
      } else if (ch === 'c') setStdout();
      else if (ch === 'd') setMode('decompress', '-d');
      else if (ch === 'f') opt.force = true;
      else if (ch === 'h') { process.stdout.write(HELP); process.exit(0); }
      else if (ch === 'j') opt.remove = true;
      else if (ch === 's') { /* squash: accepted, best-effort ignored */ }
      else if (ch === 'k') opt.remove = false;
      else if (ch === 'n') opt.copyStat = false;
      else if (ch === 'o') setOutput(takeAttachedOrNext('-o'));
      else if (ch === 'q') {
        const v = takeAttachedOrNext('-q');
        const n = parseIntStrict(v);
        setQuality(n as number, v);
      } else if (ch === 't') { setMode('test', '-t'); opt.stdout = true; }
      else if (ch === 'v') {
        if (opt.verbose) fail('argument --verbose / -v already set', true);
        opt.verbose = true;
      } else if (ch === 'w') {
        const v = takeAttachedOrNext('-w');
        const n = parseIntStrict(v);
        setLgwin(n as number, v);
      } else if (ch === 'C') {
        const v = takeAttachedOrNext('-C');
        opt.comment = decodeB64(v);
        if (opt.comment.length > 80) fail('comment too long', true);
      } else if (ch === 'D') {
        const v = takeAttachedOrNext('-D');
        try { opt.dictionary = fs.readFileSync(v); }
        catch { fail(`failed to open dictionary file [${v}]: No such file or directory`); }
      } else if (ch === 'K') opt.concatenated = true;
      else if (ch === 'S') opt.suffix = takeAttachedOrNext('-S');
      else if (ch === 'V') { process.stdout.write('brotli 1.2.0\n'); process.exit(0); }
      else if (ch === 'Z') setQuality(11, '11');
      else fail(`unknown option [-${ch}]`, true);
    }
  }
  if (opt.output && opt.files.length > 1) fail(`failed to open output file [${opt.output}]: File exists`);
  return opt;
}

function readInput(file: string): Buffer {
  if (file === '-') return fs.readFileSync(0);
  try {
    return fs.readFileSync(file);
  } catch (e: any) {
    const reason = e && e.code === 'ENOENT' ? 'No such file or directory' : (e.message || 'Unknown error');
    fail(`failed to open input file [${file}]: ${reason}`);
  }
}

function writeOutput(file: string, data: Buffer, force: boolean, copyFrom?: string, copyStat = true) {
  if (!force && fs.existsSync(file)) fail(`failed to open output file [${file}]: File exists`);
  fs.writeFileSync(file, data);
  if (copyFrom && copyStat) {
    try {
      const st = fs.statSync(copyFrom);
      fs.chmodSync(file, st.mode & 0o777);
      fs.utimesSync(file, st.atime, st.mtime);
    } catch {}
  }
}

function outputName(file: string, opt: Options): string {
  if (opt.output) return opt.output;
  if (opt.mode === 'compress') return file + opt.suffix;
  if (!file.endsWith(opt.suffix)) fail(`input file [${file}] suffix mismatch`);
  return file.slice(0, -opt.suffix.length);
}

function brotliCompress(data: Buffer, opt: Options): Buffer {
  const params: Record<number, number> = {
    [zlib.constants.BROTLI_PARAM_QUALITY]: opt.quality,
    [zlib.constants.BROTLI_PARAM_LGWIN]: opt.lgwin,
  };
  if (opt.largeWindow !== undefined) {
    params[zlib.constants.BROTLI_PARAM_LGWIN] = opt.largeWindow;
    params[zlib.constants.BROTLI_PARAM_LARGE_WINDOW] = 1;
  }
  const options: any = { params };
  if (opt.dictionary) (options as any).dictionary = opt.dictionary;
  return zlib.brotliCompressSync(data, options);
}

function brotliDecompress(data: Buffer, opt: Options): Buffer {
  const options: any = {};
  if (opt.dictionary) (options as any).dictionary = opt.dictionary;
  return zlib.brotliDecompressSync(data, options);
}

function fmtBytes(n: number): string {
  return `${n} B`;
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  const files = opt.files.length === 0 ? ['-'] : opt.files;
  let exitCode = 0;
  for (const file of files) {
    try {
      const input = readInput(file);
      let output: Buffer;
      if (opt.mode === 'compress') {
        output = brotliCompress(input, opt);
      } else {
        try {
          output = brotliDecompress(input, opt);
        } catch {
          fail(`corrupt input [${file}]`);
        }
      }
      if (opt.mode === 'test') {
        continue;
      }
      if (opt.stdout || file === '-') {
        process.stdout.write(output);
      } else {
        const out = outputName(file, opt);
        writeOutput(out, output, opt.force, file, opt.copyStat);
        if (opt.remove) {
          try { fs.unlinkSync(file); } catch {}
        }
        if (opt.verbose) {
          const verb = opt.mode === 'compress' ? 'Compressed' : 'Decompressed';
          process.stderr.write(`${verb} [${file}]: ${fmtBytes(input.length)} -> ${fmtBytes(output.length)} in 0.01 sec\n`);
        }
      }
    } catch (e: any) {
      if (e && e.__handled) exitCode = 1;
      else throw e;
    }
  }
  process.exit(exitCode);
}

main();
