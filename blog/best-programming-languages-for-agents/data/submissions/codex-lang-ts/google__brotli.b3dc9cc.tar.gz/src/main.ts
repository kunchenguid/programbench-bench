#!/usr/bin/env node
declare function require(name: string): any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");

const HELP = `Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.`;

type Options = {
  stdout: boolean;
  decompress: boolean;
  force: boolean;
  remove: boolean;
  keep: boolean;
  test: boolean;
  verbose: number;
  output?: string;
  suffix: string;
  files: string[];
};

function die(message: string, showHelp = false): void {
  process.stderr.write(message + "\n");
  if (showHelp) process.stderr.write(HELP + "\n");
  process.exit(1);
}

function parseNum(value: string, name: string, min: number, max: number): number {
  if (!/^-?\d+$/.test(value)) die(`error parsing ${name} value [${value}]`, name === "quality");
  const n = Number(value);
  if (n < min || n > max) die(`error parsing ${name} value [${value}]`);
  return n;
}

function parseArgs(argv: string[]): Options {
  const opt: Options = {
    stdout: false,
    decompress: false,
    force: false,
    remove: false,
    keep: true,
    test: false,
    verbose: 0,
    suffix: ".br",
    files: [],
  };
  let endOptions = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (endOptions || a === "-" || !a.startsWith("-")) {
      opt.files.push(a);
      continue;
    }
    if (a === "--") {
      endOptions = true;
      continue;
    }
    if (a === "-h" || a === "--help") {
      process.stdout.write(HELP + "\n");
      process.exit(0);
    }
    if (a === "-V" || a === "--version") {
      process.stdout.write("brotli 1.2.0\n");
      process.exit(0);
    }
    if (a.startsWith("--")) {
      const eq = a.indexOf("=");
      const name = eq >= 0 ? a.slice(2, eq) : a.slice(2);
      const value = eq >= 0 ? a.slice(eq + 1) : undefined;
      const need = (): string => {
        if (value !== undefined) return value;
        if (i + 1 >= argv.length) die(`expected parameter for argument [${a}]`);
        return argv[++i];
      };
      switch (name) {
        case "stdout": opt.stdout = true; break;
        case "decompress": opt.decompress = true; break;
        case "force": opt.force = true; break;
        case "rm": opt.remove = true; opt.keep = false; break;
        case "keep": opt.keep = true; opt.remove = false; break;
        case "test": opt.test = true; opt.decompress = true; opt.stdout = true; break;
        case "verbose": opt.verbose++; break;
        case "no-copy-stat": break;
        case "best": parseNum("11", "quality", 0, 11); break;
        case "quality": parseNum(need(), "quality", 0, 11); break;
        case "lgwin": parseNum(need(), "lgwin", 0, 24); break;
        case "large_window": parseNum(need(), "large_window", 0, 30); break;
        case "output": opt.output = need(); break;
        case "suffix": opt.suffix = need(); break;
        case "comment": Buffer.from(need(), "base64"); break;
        case "dictionary": fs.readFileSync(need()); break;
        case "concatenated": break;
        default:
          if (value === undefined) die(`must pass the parameter as --${name}=value`, true);
          die(`unknown option [${a}]`, true);
      }
      continue;
    }
    for (let j = 1; j < a.length; j++) {
      const ch = a[j];
      const rest = a.slice(j + 1);
      const needShort = (): string => {
        if (rest.length > 0) {
          j = a.length;
          return rest;
        }
        if (i + 1 >= argv.length) die(`expected parameter for argument [-${ch}]`);
        return argv[++i];
      };
      if (/[0-9]/.test(ch)) { parseNum(ch, "quality", 0, 9); continue; }
      switch (ch) {
        case "c": opt.stdout = true; break;
        case "d": opt.decompress = true; break;
        case "f": opt.force = true; break;
        case "h": process.stdout.write(HELP + "\n"); process.exit(0);
        case "j": opt.remove = true; opt.keep = false; break;
        case "s": break;
        case "k": opt.keep = true; opt.remove = false; break;
        case "n": break;
        case "t": opt.test = true; opt.decompress = true; opt.stdout = true; break;
        case "v": opt.verbose++; break;
        case "Z": parseNum("11", "quality", 0, 11); break;
        case "V": process.stdout.write("brotli 1.2.0\n"); process.exit(0);
        case "q": parseNum(needShort(), "quality", 0, 11); break;
        case "w": parseNum(needShort(), "lgwin", 0, 24); break;
        case "o": opt.output = needShort(); break;
        case "S": opt.suffix = needShort(); break;
        case "C": Buffer.from(needShort(), "base64"); break;
        case "D": fs.readFileSync(needShort()); break;
        case "K": break;
        default: die(`unknown option [-${ch}]`, true);
      }
    }
  }
  if (opt.files.length === 0) opt.files.push("-");
  if (opt.output && opt.files.length !== 1) die("argument --output can be used only with 1 input file");
  return opt;
}

function brotliStore(data: any): any {
  if (data.length === 0) return Buffer.from([0x3f]);
  const n = data.length;
  const l = n - 1;
  let header: any;
  if (n <= 65536) {
    header = Buffer.from([
      0x03 | ((l & 1) << 7),
      (l >> 1) & 0xff,
      0x80 | ((l >> 9) & 0x7f),
    ]);
  } else if (n <= 1 << 20) {
    header = Buffer.from([
      0x23 | ((l & 1) << 7),
      (l >> 1) & 0xff,
      (l >> 9) & 0xff,
      0x08 | ((l >> 17) & 0x07),
    ]);
  } else {
    const chunks: any[] = [];
    for (let off = 0; off < data.length; off += 1 << 20) {
      chunks.push(brotliStore(data.subarray(off, Math.min(data.length, off + (1 << 20)))));
    }
    return Buffer.concat(chunks);
  }
  return Buffer.concat([header, data, Buffer.from([0x03])]);
}

function brotliUnstore(input: any): any {
  const parts: any[] = [];
  let offset = 0;
  while (offset < input.length) {
    const parsed = brotliUnstoreOne(input.subarray(offset));
    parts.push(parsed.data);
    offset += parsed.used;
  }
  return Buffer.concat(parts);
}

function brotliUnstoreOne(input: any): { data: any; used: number } {
  if (input.length >= 1 && (input[0] === 0x3f || input[0] === 0x33)) return { data: Buffer.alloc(0), used: 1 };
  if (input.length < 4) throw new Error("corrupt input");
  const b0 = input[0];
  let n: number;
  let h: number;
  if ((b0 & 0x7f) === 0x03) {
    h = 3;
    const l = ((b0 >> 7) & 1) | (input[1] << 1) | ((input[2] & 0x7f) << 9);
    if ((input[2] & 0x80) === 0) throw new Error("corrupt input");
    n = l + 1;
  } else if ((b0 & 0x7f) === 0x23) {
    h = 4;
    const l = ((b0 >> 7) & 1) | (input[1] << 1) | (input[2] << 9) | ((input[3] & 0x07) << 17);
    if ((input[3] & 0x08) === 0) throw new Error("corrupt input");
    n = l + 1;
  } else {
    throw new Error("corrupt input");
  }
  if (input.length < h + n + 1 || input[h + n] !== 0x03) throw new Error("corrupt input");
  return { data: input.subarray(h, h + n), used: h + n + 1 };
}

function readInput(file: string): any {
  return file === "-" ? fs.readFileSync(0) : fs.readFileSync(file);
}

function outputName(input: string, opt: Options): string | undefined {
  if (opt.stdout || input === "-") return undefined;
  if (opt.output) return opt.output;
  if (opt.decompress) {
    return input.endsWith(opt.suffix) ? input.slice(0, -opt.suffix.length) : input + ".out";
  }
  return input + opt.suffix;
}

function writeOutput(out: string | undefined, data: any, input: string, opt: Options): void {
  if (!out) {
    if (!opt.test) fs.writeFileSync(1, data);
    return;
  }
  if (!opt.force && fs.existsSync(out)) die(`failed to open output file [${out}]: File exists`);
  fs.writeFileSync(out, data);
  try {
    if (input !== "-") {
      const st = fs.statSync(input);
      fs.chmodSync(out, st.mode);
    }
  } catch {}
}

function main(): void {
  const opt = parseArgs(process.argv.slice(2));
  for (const file of opt.files) {
    try {
      const input = readInput(file);
      const result = opt.decompress ? brotliUnstore(input) : brotliStore(input);
      const out = outputName(file, opt);
      writeOutput(out, result, file, opt);
      if (opt.remove && file !== "-") fs.unlinkSync(file);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (msg.includes("ENOENT")) die(`failed to open input file [${file}]: No such file or directory`);
      if (msg === "corrupt input") die(`corrupt input [${file}]`);
      die(msg);
    }
  }
}

main();
