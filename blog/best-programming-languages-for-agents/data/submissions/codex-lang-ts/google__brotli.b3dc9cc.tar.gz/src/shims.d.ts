declare const process: any;
declare const Buffer: any;
type Buffer = any;

declare module 'fs' {
  const fs: any;
  export = fs;
}

declare module 'path' {
  const path: any;
  export = path;
}

declare module 'zlib' {
  const zlib: any;
  export = zlib;
}
