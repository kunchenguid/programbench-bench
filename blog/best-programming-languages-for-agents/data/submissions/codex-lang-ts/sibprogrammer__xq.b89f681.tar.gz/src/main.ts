declare const require: any;
declare const process: any;

const fs = require("fs");

type NodeKind = "element" | "text" | "comment" | "pi" | "doctype" | "cdata";

interface XNode {
  kind: NodeKind;
  name?: string;
  attrs?: Record<string, string>;
  children?: XNode[];
  text?: string;
  selfClosing?: boolean;
}

interface Options {
  attr?: string;
  color: boolean;
  compact: boolean;
  depth: number;
  extract?: string;
  html: boolean;
  inPlace: boolean;
  indent: number;
  json: boolean;
  node: boolean;
  query?: string;
  tab: boolean;
  xpath?: string;
  file?: string;
}

const VERSION = "xq version 1.4.0";
const VOID_HTML = new Set([
  "area", "base", "br", "col", "embed", "hr", "img", "input", "link",
  "meta", "param", "source", "track", "wbr",
]);

function help(): string {
  return `Command-line XML and HTML beautifier and content extractor

Usage:
  xq [flags]

Flags:
  -a, --attr string      Extract an attribute value instead of node content for provided CSS query
  -c, --color            Force colorful output
      --compact          Compact JSON output (no indentation)
  -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)
  -e, --extract string   Extract a single node from XML
  -h, --help             Print this help message
  -m, --html             Use HTML formatter
  -i, --in-place         Format file in place
      --indent int       Use the given number of spaces for indentation (default 2)
  -j, --json             Output the result as JSON
      --no-color         Disable colorful output
  -n, --node             Return the node content instead of text
  -q, --query string     Extract the node(s) using CSS selector
      --tab              Use tabs for indentation
  -v, --version          Print version information
  -x, --xpath string     Extract the node(s) from XML
`;
}

function parseArgs(argv: string[]): Options {
  const o: Options = { color: false, compact: false, depth: -1, html: false, inPlace: false, indent: 2, json: false, node: false, tab: false };
  const need = (i: number, flag: string) => {
    if (i + 1 >= argv.length) throw new Error(`flag needs an argument: ${flag}`);
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") { process.stdout.write(help()); process.exit(0); }
    else if (a === "-v" || a === "--version") { process.stdout.write(VERSION + "\n"); process.exit(0); }
    else if (a === "-a" || a === "--attr") o.attr = need(i++, a);
    else if (a === "-c" || a === "--color") o.color = true;
    else if (a === "--no-color") o.color = false;
    else if (a === "--compact") o.compact = true;
    else if (a === "-d" || a === "--depth") o.depth = parseInt(need(i++, a), 10);
    else if (a === "-e" || a === "--extract") o.extract = need(i++, a);
    else if (a === "-m" || a === "--html") o.html = true;
    else if (a === "-i" || a === "--in-place") o.inPlace = true;
    else if (a === "--indent") o.indent = parseInt(need(i++, a), 10);
    else if (a === "-j" || a === "--json") o.json = true;
    else if (a === "-n" || a === "--node") o.node = true;
    else if (a === "-q" || a === "--query") o.query = need(i++, a);
    else if (a === "--tab") o.tab = true;
    else if (a === "-x" || a === "--xpath") o.xpath = need(i++, a);
    else if (a.startsWith("-")) throw new Error(`unknown flag: ${a}`);
    else if (!o.file) o.file = a;
  }
  if (!Number.isFinite(o.indent) || o.indent < 0) o.indent = 2;
  return o;
}

function decodeEntities(s: string): string {
  return s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"").replace(/&apos;/g, "'").replace(/&amp;/g, "&");
}

function encodeText(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function encodeAttr(s: string): string {
  return encodeText(s).replace(/"/g, "&quot;");
}

function parseAttrs(raw: string): { name: string; attrs: Record<string, string> } {
  const m = raw.trim().match(/^([^\s/>]+)/);
  const name = m ? m[1] : "";
  const attrs: Record<string, string> = {};
  const rest = raw.trim().slice(name.length);
  const re = /([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>/]+)))?/g;
  let x: RegExpExecArray | null;
  while ((x = re.exec(rest))) attrs[x[1]] = decodeEntities(x[2] ?? x[3] ?? x[4] ?? "");
  return { name, attrs };
}

function parseDocument(input: string, html: boolean): XNode {
  const root: XNode = { kind: "element", name: "__root__", attrs: {}, children: [] };
  const stack: XNode[] = [root];
  let i = 0;
  while (i < input.length) {
    const lt = input.indexOf("<", i);
    if (lt < 0) {
      addText(input.slice(i));
      break;
    }
    addText(input.slice(i, lt));
    if (input.startsWith("<!--", lt)) {
      const end = input.indexOf("-->", lt + 4);
      if (end < 0) throw new Error("XML syntax error on line 1: unexpected EOF");
      stack[stack.length - 1].children!.push({ kind: "comment", text: input.slice(lt + 4, end) });
      i = end + 3;
    } else if (input.startsWith("<![CDATA[", lt)) {
      const end = input.indexOf("]]>", lt + 9);
      if (end < 0) throw new Error("XML syntax error on line 1: unexpected EOF");
      stack[stack.length - 1].children!.push({ kind: "cdata", text: input.slice(lt + 9, end) });
      i = end + 3;
    } else if (input.startsWith("<?", lt)) {
      const end = input.indexOf("?>", lt + 2);
      if (end < 0) throw new Error("XML syntax error on line 1: unexpected EOF");
      stack[stack.length - 1].children!.push({ kind: "pi", text: input.slice(lt + 2, end).trim() });
      i = end + 2;
    } else if (input.startsWith("<!", lt)) {
      const end = input.indexOf(">", lt + 2);
      if (end < 0) throw new Error("XML syntax error on line 1: unexpected EOF");
      stack[stack.length - 1].children!.push({ kind: "doctype", text: input.slice(lt + 2, end).trim() });
      i = end + 1;
    } else if (input.startsWith("</", lt)) {
      const end = input.indexOf(">", lt + 2);
      if (end < 0) throw new Error("XML syntax error on line 1: unexpected EOF");
      const name = input.slice(lt + 2, end).trim().split(/\s+/)[0].toLowerCase();
      let idx = stack.length - 1;
      while (idx > 0 && (stack[idx].name || "").toLowerCase() !== name) idx--;
      if (idx > 0) stack.length = idx;
      i = end + 1;
    } else {
      const end = input.indexOf(">", lt + 1);
      if (end < 0) throw new Error("XML syntax error on line 1: unexpected EOF");
      let raw = input.slice(lt + 1, end);
      const self = /\/\s*$/.test(raw);
      if (self) raw = raw.replace(/\/\s*$/, "");
      const { name, attrs } = parseAttrs(raw);
      const node: XNode = { kind: "element", name, attrs, children: [], selfClosing: self || (html && VOID_HTML.has(name.toLowerCase())) };
      stack[stack.length - 1].children!.push(node);
      if (!self && !(html && VOID_HTML.has(name.toLowerCase()))) stack.push(node);
      i = end + 1;
    }
  }
  if (stack.length > 1 && !html) throw new Error("XML syntax error on line 1: unexpected EOF");
  return root;

  function addText(t: string) {
    if (t.length) stack[stack.length - 1].children!.push({ kind: "text", text: decodeEntities(t) });
  }
}

function unit(o: Options): string {
  return o.tab ? "\t" : " ".repeat(o.indent);
}

function attrs(n: XNode): string {
  const entries = Object.entries(n.attrs || {});
  return entries.length ? " " + entries.map(([k, v]) => `${k}="${encodeAttr(v)}"`).join(" ") : "";
}

function isBlankText(n: XNode): boolean {
  return n.kind === "text" && (n.text || "").trim() === "";
}

function significantChildren(n: XNode): XNode[] {
  return (n.children || []).filter(c => !isBlankText(c));
}

function textOf(n: XNode): string {
  if (n.kind === "text" || n.kind === "cdata") return (n.text || "").trim();
  if (!n.children) return "";
  return n.children.map(textOf).filter(Boolean).join(" ").replace(/\s+/g, " ").trim();
}

function serialize(n: XNode, o: Options, level = 0): string {
  if (n.kind === "text") return encodeText((n.text || "").trim());
  if (n.kind === "comment") return `${unit(o).repeat(level)}<!--${n.text || ""}-->`;
  if (n.kind === "pi") return `${unit(o).repeat(level)}<?${n.text || ""}?>`;
  if (n.kind === "doctype") return `${unit(o).repeat(level)}<!${n.text || ""}>`;
  if (n.kind === "cdata") return `${unit(o).repeat(level)}<![CDATA[${n.text || ""}]]>`;
  const pad = unit(o).repeat(level);
  const children = significantChildren(n);
  const open = `<${n.name}${attrs(n)}>`;
  const close = `</${n.name}>`;
  if (children.length === 0) {
    if (o.html && !n.selfClosing) return `${pad}<${n.name}${attrs(n)}></${n.name}>`;
    return `${pad}<${n.name}${attrs(n)}/>`;
  }
  if (children.length === 1 && (children[0].kind === "text" || children[0].kind === "cdata")) {
    return `${pad}${open}${children[0].kind === "cdata" ? `<![CDATA[${children[0].text || ""}]]>` : serialize(children[0], o, 0)}${close}`;
  }
  const lines = [`${pad}${open}`];
  let start = 0;
  if (children[0]?.kind === "text" || children[0]?.kind === "cdata") {
    const t = (children[0].text || "").trim();
    if (t) lines[0] += children[0].kind === "cdata" ? `<![CDATA[${children[0].text || ""}]]>` : encodeText(t);
    start = 1;
  }
  for (const c of children.slice(start)) {
    if (c.kind === "text") {
      const t = (c.text || "").trim();
      if (t) lines.push(`${unit(o).repeat(level + 1)}${encodeText(t)}`);
    } else if (c.kind === "cdata") {
      lines.push(serialize(c, o, level + 1));
    } else {
      lines.push(serialize(c, o, level + 1));
    }
  }
  lines.push(`${pad}${close}`);
  return lines.join("\n");
}

function formatDoc(doc: XNode, o: Options): string {
  return significantChildren(doc).map(c => c.kind === "element" ? serialize(c, o, 0) : serialize(c, o, 0)).join("\n");
}

function colorize(s: string): string {
  return s.replace(/(<\/?)([A-Za-z0-9:_-]+)((?:\s+[^<>]*?)?)(\/?>)/g, (_m, p, name, at, end) => {
    const attr = String(at).replace(/([A-Za-z_:][-A-Za-z0-9_:.]*)(="[^"]*")/g, (_a, k, v) => `${k}\x1b[32m${v}\x1b[0m`);
    return `\x1b[33m${p}${name}\x1b[0m${attr}\x1b[33m${end}\x1b[0m`;
  });
}

function elementChildren(n: XNode): XNode[] {
  return (n.children || []).filter(c => c.kind === "element");
}

function descendants(n: XNode): XNode[] {
  const out: XNode[] = [];
  for (const c of n.children || []) {
    if (c.kind === "element") {
      out.push(c);
      out.push(...descendants(c));
    }
  }
  return out;
}

function xpath(doc: XNode, expr: string): Array<XNode | string> {
  expr = expr.trim();
  if (!expr) return [];
  const attrMatch = expr.match(/^(.*)\/@([^/]+)$/);
  const attrName = attrMatch?.[2];
  if (attrMatch) expr = attrMatch[1] || "/";
  let nodes: XNode[] = [];
  if (expr.startsWith("//")) {
    const parts = expr.slice(2).split("/").filter(Boolean);
    nodes = selectNodes(descendants(doc), parts[0], true);
    for (const p of parts.slice(1)) nodes = selectNodes(nodes.flatMap(elementChildren), p, true);
  } else {
    const parts = expr.replace(/^\/+/, "").split("/").filter(Boolean);
    nodes = [doc];
    for (const p of parts) {
      if (p === ".") continue;
      nodes = selectNodes(nodes.flatMap(elementChildren), p, true);
    }
  }
  if (attrName) return nodes.map(n => (n.attrs || {})[attrName]).filter(v => v !== undefined);
  return nodes;
}

function matchName(n: XNode, sel: string): boolean {
  const name = sel.replace(/\[.*\]$/, "").trim();
  return name === "*" || n.name === name;
}

function selectNodes(nodes: XNode[], step: string, allowIndex: boolean): XNode[] {
  const pred = step.match(/^([^\[]+|\*)\[(.+)\]$/);
  const name = pred ? pred[1] : step;
  let out = nodes.filter(n => matchName(n, name));
  if (!pred) return out;
  const p = pred[2].trim();
  const idx = p.match(/^\d+$/);
  if (idx && allowIndex) return out.slice(Math.max(0, parseInt(p, 10) - 1), parseInt(p, 10));
  const am = p.match(/^@([^=\s]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\]]+))$/);
  if (am) {
    const key = am[1], val = am[2] ?? am[3] ?? am[4] ?? "";
    out = out.filter(n => (n.attrs || {})[key] === val);
  }
  return out;
}

interface SimpleSel { tag?: string; id?: string; cls?: string; attr?: [string, string?]; }

function parseSimpleSel(s: string): SimpleSel {
  const out: SimpleSel = {};
  let rest = s.trim();
  const am = rest.match(/\[([^=\]]+)(?:=(["']?)(.*?)\2)?\]/);
  if (am) { out.attr = [am[1], am[3]]; rest = rest.replace(am[0], ""); }
  const im = rest.match(/#([A-Za-z0-9_-]+)/);
  if (im) { out.id = im[1]; rest = rest.replace(im[0], ""); }
  const cm = rest.match(/\.([A-Za-z0-9_-]+)/);
  if (cm) { out.cls = cm[1]; rest = rest.replace(cm[0], ""); }
  rest = rest.trim();
  if (rest && rest !== "*") out.tag = rest.toLowerCase();
  return out;
}

function matchesCss(n: XNode, s: SimpleSel): boolean {
  if (n.kind !== "element") return false;
  const a = n.attrs || {};
  if (s.tag && (n.name || "").toLowerCase() !== s.tag) return false;
  if (s.id && a.id !== s.id) return false;
  if (s.cls && !(a.class || "").split(/\s+/).includes(s.cls)) return false;
  if (s.attr) {
    if (!(s.attr[0] in a)) return false;
    if (s.attr[1] !== undefined && a[s.attr[0]] !== s.attr[1]) return false;
  }
  return true;
}

function cssQuery(doc: XNode, q: string): XNode[] {
  if (q.includes(",")) {
    const seen = new Set<XNode>();
    const all: XNode[] = [];
    for (const part of q.split(",")) {
      for (const n of cssQuery(doc, part.trim())) if (!seen.has(n)) { seen.add(n); all.push(n); }
    }
    return all;
  }
  const tokens = q.replace(/\s*>\s*/g, " > ").trim().split(/\s+/).filter(Boolean);
  let current: XNode[] = [doc];
  let direct = false;
  for (const t of tokens) {
    if (t === ">") { direct = true; continue; }
    const sel = parseSimpleSel(t);
    const pool = current.flatMap(n => direct ? elementChildren(n) : descendants(n));
    current = pool.filter(n => matchesCss(n, sel));
    direct = false;
  }
  return current;
}

function toJsonValue(n: XNode, depth: number, maxDepth: number): any {
  const ch = significantChildren(n);
  if (maxDepth >= 0 && depth >= maxDepth) return textOf(n);
  const hasAttrs = Object.keys(n.attrs || {}).length > 0;
  const elems = ch.filter(c => c.kind === "element");
  const texts = ch.filter(c => c.kind === "text").map(c => (c.text || "").trim()).filter(Boolean);
  if (!hasAttrs && elems.length === 0) return texts.join(" ");
  const obj: Record<string, any> = {};
  if (texts.length) obj["#text"] = texts.join(" ");
  for (const [k, v] of Object.entries(n.attrs || {})) obj[`@${k}`] = v;
  for (const e of elems) {
    const val = toJsonValue(e, depth + 1, maxDepth);
    if (Object.prototype.hasOwnProperty.call(obj, e.name!)) {
      if (!Array.isArray(obj[e.name!])) obj[e.name!] = [obj[e.name!]];
      obj[e.name!].push(val);
    } else obj[e.name!] = val;
  }
  return obj;
}

function jsonDoc(doc: XNode, o: Options): string {
  const obj: Record<string, any> = {};
  for (const e of elementChildren(doc)) obj[e.name!] = toJsonValue(e, 0, o.depth);
  if (o.compact) return JSON.stringify(obj).replace(/:/g, ": ").replace(/,/g, ",");
  return JSON.stringify(obj, null, 2);
}

function run() {
  let opts: Options;
  try { opts = parseArgs(process.argv.slice(2)); }
  catch (e: any) { process.stderr.write(`Error: ${e.message}\n`); process.exit(1); return; }
  let input = "";
  try {
    input = opts.file ? fs.readFileSync(opts.file, "utf8") : fs.readFileSync(0, "utf8");
  } catch (e: any) {
    process.stderr.write(`Error: ${e.message}\n`);
    process.exit(1);
  }
  try {
    const doc = parseDocument(input, opts.html);
    let out: string;
    if (opts.json) out = jsonDoc(doc, opts);
    else if (opts.query) {
      const nodes = cssQuery(doc, opts.query);
      if (opts.attr) out = nodes.map(n => (n.attrs || {})[opts.attr!] || "").join("\n");
      else if (opts.node) out = nodes.map(n => serialize(n, opts, 0)).join("\n");
      else out = nodes.map(textOf).join("\n");
    } else if (opts.xpath || opts.extract) {
      const vals = xpath(doc, opts.xpath || opts.extract || "");
      const chosen = opts.extract ? vals.slice(0, 1) : vals;
      out = chosen.map(v => typeof v === "string" ? v : (opts.node ? serialize(v, opts, 0) : textOf(v))).join("\n");
    } else {
      out = formatDoc(doc, opts);
      if (opts.color) out = colorize(out);
    }
    if (opts.inPlace && opts.file) fs.writeFileSync(opts.file, out);
    else process.stdout.write(out + (out.endsWith("\n") || out === "" ? "" : "\n"));
  } catch (e: any) {
    process.stderr.write(`Error: ${e.message}\n`);
    process.exit(1);
  }
}

run();
