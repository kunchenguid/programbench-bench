declare const require: any;
declare const process: any;

const fs = require("fs");

const HELP = `Shellharden: The corrective bash syntax highlighter.

Usage:
\tshellharden [options] [files]
\tcat files | shellharden [options] ''

Shellharden is a syntax highlighter and a tool to semi-automate the rewriting
of scripts to ShellCheck conformance, mainly focused on quoting.

The default mode of operation is like \`cat\`, but with syntax highlighting in
foreground colors and suggestive changes in background colors.

Options:
\t--suggest         Output a colored diff suggesting changes.
\t--syntax          Output syntax highlighting with ANSI colors.
\t--syntax-suggest  Diff with syntax highlighting (default mode).
\t--transform       Output suggested changes.
\t--check           No output; exit with 2 if changes are suggested.
\t--replace         Replace file contents with suggested changes.
\t--                Don't treat further arguments as options.
\t-h|--help         Show help text.
\t--version         Show version.

The changes suggested by Shellharden inhibits word splitting and indirect
pathname expansion. This will make your script ShellCheck compliant in terms of
quoting. Whether your script will work afterwards is a different question:
If your script was using those features on purpose, it obviously won't anymore!

Every script is possible to write without using word splitting or indirect
pathname expansion, but it may involve doing things differently.
See the accompanying file how_to_do_things_safely_in_bash.md or online:
https://github.com/anordal/shellharden/blob/master/how_to_do_things_safely_in_bash.md
`;

type Mode = "syntax-suggest" | "syntax" | "suggest" | "transform" | "check" | "replace";

function isNameStart(c: string): boolean { return /[A-Za-z_]/.test(c); }
function isName(c: string): boolean { return /[A-Za-z0-9_]/.test(c); }
function isSpace(c: string): boolean { return c === " " || c === "\t" || c === "\r" || c === "\n"; }
function isSpecialParam(c: string): boolean { return c === "?" || c === "$" || c === "!" || c === "#"; }

function matching(s: string, start: number, open: string, close: string): number {
  let depth = 1, sq = false, dq = false, esc = false;
  for (let i = start + open.length; i < s.length; i++) {
    const c = s[i];
    if (esc) { esc = false; continue; }
    if (c === "\\") { esc = true; continue; }
    if (!dq && c === "'") { sq = !sq; continue; }
    if (!sq && c === "\"") { dq = !dq; continue; }
    if (!sq && !dq && s.startsWith(open, i)) { depth++; i += open.length - 1; continue; }
    if (!sq && !dq && s.startsWith(close, i)) {
      depth--;
      if (depth === 0) return i;
      i += close.length - 1;
    }
  }
  return -1;
}

function matchingBacktick(s: string, start: number): number {
  let esc = false;
  for (let i = start + 1; i < s.length; i++) {
    const c = s[i];
    if (esc) { esc = false; continue; }
    if (c === "\\") { esc = true; continue; }
    if (c === "`") return i;
  }
  return -1;
}

interface Expansion { raw: string; body: string; end: number; simple: boolean; arrayAll: boolean; length: boolean; special: boolean; positional: boolean; }

function parseExpansion(s: string, i: number): Expansion | null {
  if (s[i] !== "$") return null;
  if (s.startsWith("$(", i)) {
    const e = matching(s, i, "$(", ")");
    if (e < 0) return null;
    return { raw: s.slice(i, e + 1), body: s.slice(i + 2, e), end: e + 1, simple: false, arrayAll: false, length: false, special: false, positional: false };
  }
  const n = s[i + 1] || "";
  if (n === "{") {
    const e = matching(s, i + 1, "{", "}");
    if (e < 0) return null;
    const body = s.slice(i + 2, e);
    const length = body.startsWith("#");
    const arrayAll = /\[@\]$/.test(body);
    const simple = /^[A-Za-z_][A-Za-z0-9_]*$/.test(body) || /^[0-9]$/.test(body);
    return { raw: s.slice(i, e + 1), body, end: e + 1, simple, arrayAll, length, special: false, positional: /^[0-9]$/.test(body) };
  }
  if (isSpecialParam(n)) {
    return { raw: s.slice(i, i + 2), body: n, end: i + 2, simple: true, arrayAll: false, length: false, special: true, positional: false };
  }
  if (/[0-9]/.test(n)) {
    let j = i + 2;
    while (/[0-9]/.test(s[j] || "")) j++;
    if (j > i + 2) throw new Error("syntactic-pitfall");
    return { raw: s.slice(i, i + 2), body: n, end: i + 2, simple: true, arrayAll: false, length: false, special: false, positional: true };
  }
  if (isNameStart(n)) {
    let j = i + 2;
    while (isName(s[j] || "")) j++;
    return { raw: s.slice(i, j), body: s.slice(i + 1, j), end: j, simple: true, arrayAll: false, length: false, special: false, positional: false };
  }
  return null;
}

function stripSimpleBraces(exp: Expansion): string {
  if (exp.raw.startsWith("${") && exp.simple && /^[A-Za-z_][A-Za-z0-9_]*$/.test(exp.body)) return "$" + exp.body;
  return exp.raw;
}

function splitWords(line: string): { text: string; start: number; end: number }[] {
  const out: { text: string; start: number; end: number }[] = [];
  let i = 0;
  while (i < line.length) {
    while (i < line.length && (isSpace(line[i]) || ";|&".includes(line[i]))) i++;
    if (i >= line.length || line[i] === "#") break;
    const start = i;
    let sq = false, dq = false, esc = false;
    for (; i < line.length; i++) {
      const c = line[i];
      if (esc) { esc = false; continue; }
      if (c === "\\") { esc = true; continue; }
      if (!dq && c === "'") { sq = !sq; continue; }
      if (!sq && c === "\"") { dq = !dq; continue; }
      if (!sq && !dq && (isSpace(c) || ";|&".includes(c) || c === "#")) break;
    }
    out.push({ text: line.slice(start, i), start, end: i });
  }
  return out;
}

function isAssignmentWord(w: string): boolean {
  return /^[A-Za-z_][A-Za-z0-9_]*(\+)?=/.test(w);
}

function assignmentProtected(words: { text: string; start: number; end: number }[], idx: number): boolean {
  const w = words[idx].text;
  if (!isAssignmentWord(w)) return false;
  if (/^[A-Za-z_][A-Za-z0-9_]*(\+)?=\(/.test(w)) return false;
  if (idx === 0) return true;
  const first = words[0]?.text;
  if (["export", "readonly", "local", "declare", "typeset"].includes(first)) return true;
  for (let j = 0; j < idx; j++) if (!isAssignmentWord(words[j].text)) return false;
  return true;
}

function transformDoubleQuoted(content: string): string {
  let out = "";
  for (let i = 0; i < content.length;) {
    if (content[i] === "`") {
      const e = matchingBacktick(content, i);
      if (e >= 0) { out += "$(" + content.slice(i + 1, e) + ")"; i = e + 1; continue; }
    }
    if (content[i] === "$") {
      const exp = parseExpansion(content, i);
      if (exp) { out += stripSimpleBraces(exp); i = exp.end; continue; }
    }
    out += content[i++];
  }
  return out;
}

function transformWord(word: string, opts: { protectAssignment?: boolean; forIn?: boolean; caseHead?: boolean }): string {
  if (opts.protectAssignment || opts.caseHead) return word;
  let out = "";
  for (let i = 0; i < word.length;) {
    const c = word[i];
    if (c === "'") {
      const e = word.indexOf("'", i + 1);
      if (e < 0) { out += word.slice(i); break; }
      out += word.slice(i, e + 1); i = e + 1; continue;
    }
    if (c === "\"") {
      let e = i + 1, esc = false;
      for (; e < word.length; e++) {
        if (esc) { esc = false; continue; }
        if (word[e] === "\\") { esc = true; continue; }
        if (word[e] === "\"") break;
      }
      if (e >= word.length) { out += word.slice(i); break; }
      out += "\"" + transformDoubleQuoted(word.slice(i + 1, e)) + "\"";
      i = e + 1; continue;
    }
    if (c === "`") {
      const e = matchingBacktick(word, i);
      if (e >= 0) { out += "\"$(" + word.slice(i + 1, e) + ")\""; i = e + 1; continue; }
    }
    if (c === "$") {
      const exp = parseExpansion(word, i);
      if (exp) {
        if (exp.special || exp.length) { out += exp.raw; i = exp.end; continue; }
        let raw = stripSimpleBraces(exp);
        if (opts.forIn && exp.simple && !exp.arrayAll) raw = "${" + exp.body + "[@]}";
        const before = word[i - 1] || "";
        const after = word[exp.end] || "";
        if (after === "\"") {
          let e = exp.end + 1, esc = false;
          for (; e < word.length; e++) {
            if (esc) { esc = false; continue; }
            if (word[e] === "\\") { esc = true; continue; }
            if (word[e] === "\"") break;
          }
          const lit = e < word.length ? transformDoubleQuoted(word.slice(exp.end + 1, e)) : "";
          const needBraces = !exp.raw.startsWith("${") && /^[A-Za-z_][A-Za-z0-9_]*$/.test(exp.body) && lit.length > 0 && isName(lit[0]);
          if (needBraces) raw = "${" + exp.body + "}";
          out += "\"" + raw + lit + "\"";
          i = e < word.length ? e + 1 : exp.end + 1;
          continue;
        }
        if (before === "\"") {
          out += raw;
        } else {
          const needBraces = !exp.raw.startsWith("${") && /^[A-Za-z_][A-Za-z0-9_]*$/.test(exp.body) && isName(after);
          if (needBraces) raw = "${" + exp.body + "}";
          out += "\"" + raw + "\"";
        }
        i = exp.end; continue;
      }
    }
    out += c; i++;
  }
  return out;
}

function transformLine(line: string): string {
  if (/^\s*#/.test(line) || line.trim() === "") return line;
  const words = splitWords(line);
  if (words.length === 0) return line;
  const protectedRanges: [number, number][] = [];
  const openDb = line.indexOf("[[");
  const closeDb = openDb >= 0 ? line.indexOf("]]", openDb + 2) : -1;
  if (openDb >= 0 && closeDb >= 0) protectedRanges.push([openDb, closeDb + 2]);
  const caseIdx = words.findIndex(w => w.text === "case");
  const caseIn = words.findIndex((w, idx) => idx > caseIdx && w.text === "in");
  const caseVarRange = caseIdx >= 0 && caseIn > caseIdx && caseIdx + 1 < words.length ? [words[caseIdx + 1].start, words[caseIdx + 1].end] as [number, number] : null;
  const replacements: { start: number; end: number; text: string }[] = [];
  for (let wi = 0; wi < words.length; wi++) {
    const w = words[wi];
    if (protectedRanges.some(([a, b]) => w.start >= a && w.end <= b)) continue;
    const prev = words[wi - 1]?.text;
    const forIn = prev === "in" && words.some(x => x.text === "for");
    const caseHead = !!caseVarRange && w.start === caseVarRange[0] && w.end === caseVarRange[1];
    const nw = transformWord(w.text, { protectAssignment: assignmentProtected(words, wi), forIn, caseHead });
    if (nw !== w.text) replacements.push({ start: w.start, end: w.end, text: nw });
  }
  let out = "", pos = 0;
  for (const r of replacements) { out += line.slice(pos, r.start) + r.text; pos = r.end; }
  out += line.slice(pos);
  return out;
}

function transformText(text: string): string {
  const keep = text.endsWith("\n");
  const lines = text.split(/\n/);
  if (keep) lines.pop();
  const out = lines.map(transformLine).join("\n");
  return out + (keep ? "\n" : "");
}

function colorize(text: string, suggest: boolean): string {
  const tr = transformText(text);
  if (suggest) {
    let out = "";
    for (let i = 0, j = 0; i < text.length || j < tr.length;) {
      if (text[i] === tr[j]) { out += text[i] || ""; i++; j++; continue; }
      out += "\x1b[0;42m";
      while (j < tr.length && tr[j] !== text[i]) out += tr[j++];
      out += "\x1b[m";
      if (i < text.length && text[i] !== tr[j]) i++;
    }
    return out;
  }
  return text.replace(/^([ \t]*#.*)$/gm, "\x1b[0;1;3;38;2;120;144;96m$1\x1b[m")
    .replace(/(\$\{?[A-Za-z_0-9#?!$][A-Za-z0-9_@\[\]#]*\}?)/g, "\x1b[0;38;2;63;127;207m$1\x1b[m");
}

function unsupported(path: string, text: string): never {
  const m = text.match(/\$[0-9][0-9]+/);
  if (m && m.index !== undefined) {
    const line = text.slice(0, m.index).split("\n").length;
    const lineText = text.split("\n")[line - 1];
    process.stderr.write(`${path}: Unsupported syntax: Syntactic pitfall\n${lineText}\n${" ".repeat(m.index - text.lastIndexOf("\n", m.index) - 1)}^^^\nThis does not mean what it looks like. You may be forgiven to think that the full string of numerals is the variable name. Only the fist is.\n\nTry this and be shocked: f() { echo "$9" "$10"; }; f a b c d e f g h i j\n\nHere is where braces should be used to disambiguate, e.g. "\${10}" vs "\${1}0".\n\nSyntactic pitfalls are deemed too dangerous to fix automatically\n(the purpose of Shellharden is to fix vulnerable code - code that mostly does what it looks like, as opposed to code that never does what it looks like):\n* Fixing what it does would be 100% subtle and might slip through code review unnoticed.\n* Fixing its look would make a likely bug look intentional.\n`);
    process.exit(1);
  }
  throw new Error("unsupported");
}

function readStdin(): string {
  return fs.readFileSync(0, "utf8");
}

function main() {
  const args = process.argv.slice(2);
  let mode: Mode = "syntax-suggest";
  const files: string[] = [];
  let endOpts = false;
  for (const a of args) {
    if (!endOpts && a === "--") { endOpts = true; continue; }
    if (!endOpts && a.startsWith("-") && a !== "") {
      if (a === "-h" || a === "--help") { process.stdout.write(HELP); return; }
      if (a === "--version") { process.stdout.write("4.3.1\n"); return; }
      if (["--suggest", "--syntax", "--syntax-suggest", "--transform", "--check", "--replace"].includes(a)) {
        mode = a.slice(2) as Mode; continue;
      }
      process.stderr.write(`${a}: No such option.\n`); process.exit(3);
    }
    files.push(a);
  }
  if (files.length === 0) files.push("");
  let anyChanged = false;
  let exitCode = 0;
  for (const f of files) {
    let text = "";
    try { text = f === "" ? readStdin() : fs.readFileSync(f, "utf8"); }
    catch (e: any) {
      if (e && e.code === "ENOENT") process.stderr.write(`${f}: No such file or directory (os error 2)\n`);
      else process.stderr.write(`${f}: ${e.message}\n`);
      exitCode = 1; continue;
    }
    if (/\$[0-9][0-9]+/.test(text)) unsupported(f || "stdin", text);
    const tr = transformText(text);
    const changed = tr !== text;
    anyChanged = anyChanged || changed;
    if (mode === "check") continue;
    if (mode === "replace") {
      if (f === "") { process.stderr.write(": Cannot replace stdin.\n"); exitCode = 1; }
      else fs.writeFileSync(f, tr);
      continue;
    }
    if (mode === "transform") process.stdout.write(tr);
    else if (mode === "syntax") process.stdout.write(colorize(text, false));
    else if (mode === "suggest") process.stdout.write(colorize(text, true));
    else process.stdout.write(colorize(text, true));
  }
  if (mode === "check" && anyChanged) process.exit(2);
  process.exit(exitCode);
}

main();
