declare const process: {
  argv: string[];
  exit(code?: number): never;
};

declare module "fs" {
  export type Stats = {
    isDirectory(): boolean;
  };
  export function lstatSync(path: string): Stats;
  export function readdirSync(path: string): string[];
  export function existsSync(path: string): boolean;
  export function copyFileSync(source: string, target: string): void;
  export function renameSync(source: string, target: string): void;
  export function writeFileSync(path: string, data: string): void;
  export function readFileSync(path: string, encoding: string): string;
}

declare module "path" {
  export function basename(path: string): string;
  export function dirname(path: string): string;
  export function join(...parts: string[]): string;
}
