import * as fs from "fs";
import * as path from "path";

type Op = { source: string; target: string };

type CommonOptions = {
  dryRun: boolean;
  force: boolean;
  backup: boolean;
  silent: boolean;
  dump: boolean;
  noDump: boolean;
  dumpPrefix: string;
  color: string;
};

type RegexOptions = CommonOptions & {
  replaceLimit: number;
  transform?: "upper" | "lower" | "ascii";
  includeDirs: boolean;
  recursive: boolean;
  maxDepth?: number;
  hidden: boolean;
};

const VERSION = "rnr 0.5.1";

function printTopHelp(): void {
  console.log(`RnR is a command-line tool to rename multiple files and directories that
supports regular expressions


Usage: executable <COMMAND>

Commands:
  regex      Rename files and directories using a regular expression
  from-file  Read operations from a dump file
  to-ascii   Replace file name UTF-8 chars with ASCII chars representation
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version`);
}

function printRegexHelp(): void {
  console.log(`Rename files and directories using a regular expression

Usage: executable regex [OPTIONS] <EXPRESSION> <REPLACEMENT> <PATH(S)>...

Arguments:
  <EXPRESSION>   Expression to match (can be a regex)
  <REPLACEMENT>  Expression replacement (use single quotes for capture groups)
  <PATH(S)>...   Target paths

Options:
  -n, --dry-run
          Only show what would be done (default mode)
  -f, --force
          Make actual changes to files
  -b, --backup
          Generate file backups before renaming
  -s, --silent
          Do not print any information
      --color <COLOR>
          Set color output mode [default: auto] [possible values: always, never, auto]
      --dump
          Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>
          Set the dump file prefix [default: rnr-]
      --no-dump
          Do not dump operations into a file
  -l, --replace-limit <LIMIT>
          Limit of replacements, all matches if set to 0
  -t, --replace-transform <REPLACE_TRANSFORM>
          Apply a transformation to replacements including captured groups [possible values: upper, lower, ascii]
  -D, --include-dirs
          Rename matching directories
  -r, --recursive
          Recursive mode
  -d, --max-depth <LEVEL>
          Set max depth in recursive mode
  -x, --hidden
          Include hidden files and directories
  -h, --help
          Print help`);
}

function printFromFileHelp(): void {
  console.log(`Read operations from a dump file

Usage: executable from-file [OPTIONS] <DUMPFILE>

Arguments:
  <DUMPFILE>  

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -u, --undo                       Undo the operations from the dump file
  -h, --help                       Print help`);
}

function printAsciiHelp(): void {
  console.log(`Replace file name UTF-8 chars with ASCII chars representation

Usage: executable to-ascii [OPTIONS] <PATH(S)>...

Arguments:
  <PATH(S)>...  Target paths

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -D, --include-dirs               Rename matching directories
  -r, --recursive                  Recursive mode
  -d, --max-depth <LEVEL>          Set max depth in recursive mode
  -x, --hidden                     Include hidden files and directories
  -h, --help                       Print help`);
}

function die(message: string, code = 1): never {
  console.error(message);
  process.exit(code);
  throw new Error(message);
}

function commonDefaults(): CommonOptions {
  return { dryRun: true, force: false, backup: false, silent: false, dump: false, noDump: false, dumpPrefix: "rnr-", color: "auto" };
}

function parseCommon(args: string[], extra: (arg: string, i: number) => number | undefined): { options: CommonOptions; rest: string[]; undo: boolean } {
  const options = commonDefaults();
  let undo = false;
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-n" || a === "--dry-run") options.dryRun = true;
    else if (a === "-f" || a === "--force") { options.force = true; options.dryRun = false; }
    else if (a === "-b" || a === "--backup") options.backup = true;
    else if (a === "-s" || a === "--silent") options.silent = true;
    else if (a === "--dump") options.dump = true;
    else if (a === "--no-dump") options.noDump = true;
    else if (a === "--dump-prefix") options.dumpPrefix = args[++i] ?? die("error: a value is required for '--dump-prefix <DUMP_PREFIX>'", 2);
    else if (a === "--color") options.color = args[++i] ?? die("error: a value is required for '--color <COLOR>'", 2);
    else if (a === "-u" || a === "--undo") undo = true;
    else if (a === "-h" || a === "--help") rest.push(a);
    else {
      const ni = extra(a, i);
      if (ni !== undefined) i = ni;
      else rest.push(a);
    }
  }
  if (options.dump && options.noDump) {
    console.error("error: the argument '--no-dump' cannot be used with '--dump'\n");
    console.error("Usage: executable regex --no-dump <EXPRESSION> <REPLACEMENT> <PATH(S)>...\n");
    console.error("For more information, try '--help'.");
    process.exit(2);
  }
  return { options, rest, undo };
}

function parseRegexOptions(args: string[]): { options: RegexOptions; rest: string[] } {
  const specific = { replaceLimit: 0, includeDirs: false, recursive: false, hidden: false } as Omit<RegexOptions, keyof CommonOptions>;
  const parsed = parseCommon(args, (a, i) => {
    if (a === "-l" || a === "--replace-limit") { specific.replaceLimit = Number(args[++i] ?? "0"); return i; }
    if (a === "-t" || a === "--replace-transform") {
      const v = args[++i] as "upper" | "lower" | "ascii" | undefined;
      if (v !== "upper" && v !== "lower" && v !== "ascii") die(`error: invalid value '${v}' for '--replace-transform <REPLACE_TRANSFORM>'`, 2);
      specific.transform = v;
      return i;
    }
    if (a === "-D" || a === "--include-dirs") { specific.includeDirs = true; return i; }
    if (a === "-r" || a === "--recursive") { specific.recursive = true; return i; }
    if (a === "-d" || a === "--max-depth") { specific.maxDepth = Number(args[++i] ?? "0"); return i; }
    if (a === "-x" || a === "--hidden") { specific.hidden = true; return i; }
    return undefined;
  });
  return { options: { ...parsed.options, ...specific }, rest: parsed.rest };
}

function ascii(s: string): string {
  const map: Record<string, string> = {
    "ß": "ss", "Æ": "AE", "æ": "ae", "Œ": "OE", "œ": "oe", "Ø": "O", "ø": "o", "Ð": "D", "ð": "d",
    "Þ": "Th", "þ": "th", "Ł": "L", "ł": "l", "Đ": "D", "đ": "d", "İ": "I", "ı": "i", "Ñ": "N", "ñ": "n",
    "Ç": "C", "ç": "c"
  };
  let out = "";
  for (const ch of s.normalize("NFD")) {
    if (/[\u0300-\u036f]/u.test(ch)) continue;
    out += map[ch] ?? (ch.charCodeAt(0) < 128 ? ch : "");
  }
  return out;
}

function replaceName(name: string, expression: string, replacement: string, opts: RegexOptions): string {
  const flags = opts.replaceLimit === 1 ? "" : "g";
  const re = new RegExp(expression, flags);
  let count = 0;
  return name.replace(re, (...m: unknown[]) => {
    if (opts.replaceLimit > 0 && count >= opts.replaceLimit) return String(m[0]);
    count++;
    const groups = m.slice(1, -2).map(String);
    let r = replacement.replace(/\$(\d+)/g, (_all, n) => groups[Number(n) - 1] ?? "");
    if (opts.transform === "upper") r = r.toUpperCase();
    else if (opts.transform === "lower") r = r.toLowerCase();
    else if (opts.transform === "ascii") r = ascii(r);
    return r;
  });
}

function isHiddenName(p: string): boolean {
  const b = path.basename(p);
  return b !== "." && b !== ".." && b.startsWith(".");
}

function collectTargets(inputs: string[], opts: Pick<RegexOptions, "recursive" | "includeDirs" | "hidden" | "maxDepth">): string[] {
  const result: string[] = [];
  const walk = (p: string, depth: number): void => {
    let st: fs.Stats;
    try { st = fs.lstatSync(p); } catch { return; }
    if (!opts.hidden && isHiddenName(p)) return;
    if (st.isDirectory()) {
      if (opts.recursive && (opts.maxDepth === undefined || depth < opts.maxDepth)) {
        let names: string[] = [];
        try { names = fs.readdirSync(p); } catch { names = []; }
        for (const n of names) walk(path.join(p, n), depth + 1);
      }
      if (opts.includeDirs) result.push(p);
    } else {
      result.push(p);
    }
  };
  for (const p of inputs) walk(p, 0);
  return result;
}

function planRegex(expr: string, repl: string, inputs: string[], opts: RegexOptions): Op[] {
  const paths = collectTargets(inputs, opts);
  const ops: Op[] = [];
  for (const p of paths) {
    const dir = path.dirname(p);
    const base = path.basename(p);
    const nb = replaceName(base, expr, repl, opts);
    if (nb !== base) ops.push({ source: p, target: path.join(dir, nb) });
  }
  return ops;
}

function planAscii(inputs: string[], opts: RegexOptions): Op[] {
  const paths = collectTargets(inputs, opts);
  const ops: Op[] = [];
  for (const p of paths) {
    const dir = path.dirname(p);
    const base = path.basename(p);
    const nb = ascii(base);
    if (nb && nb !== base) ops.push({ source: p, target: path.join(dir, nb) });
  }
  return ops;
}

function showAndApply(ops: Op[], opts: CommonOptions): void {
  if (!opts.silent && opts.dryRun) console.log("This is a DRY-RUN");
  for (const op of ops) {
    if (!opts.dryRun) {
      if (fs.existsSync(op.target)) die(`Error: Conflict with existing path ${op.source} -> ${op.target}`);
      if (opts.backup) {
        const backup = `${op.source}.bk`;
        fs.copyFileSync(op.source, backup);
        if (!opts.silent) console.log(`Info:  Backup created - ${op.source} -> ${backup}`);
      }
      fs.renameSync(op.source, op.target);
    }
    if (!opts.silent) console.log(`${op.source} -> ${op.target}`);
  }
  if (ops.length && !opts.noDump && (!opts.dryRun || opts.dump)) writeDump(ops, opts.dumpPrefix);
}

function stamp(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

function writeDump(ops: Op[], prefix: string): void {
  const now = stamp();
  const date = `${now.slice(0, 10)} ${now.slice(11, 13)}:${now.slice(13, 15)}:${now.slice(15, 17)}`;
  const file = `${prefix}${now}.json`;
  fs.writeFileSync(file, JSON.stringify({ date, operations: ops }, null, 2));
}

function runRegex(args: string[]): void {
  if (args.includes("-h") || args.includes("--help")) { printRegexHelp(); return; }
  const { options, rest } = parseRegexOptions(args);
  if (rest.length < 3) die("error: the following required arguments were not provided", 2);
  let ops: Op[] = [];
  try {
    // Validate early so the error resembles the original.
    new RegExp(rest[0]);
    ops = planRegex(rest[0], rest[1], rest.slice(2), options);
  } catch (e) {
    console.error("Error: Bad expression provided\n");
    console.error(String(e instanceof Error ? e.message : e));
    process.exit(1);
  }
  showAndApply(ops, options);
}

function parseAsciiOptions(args: string[]): { options: RegexOptions; rest: string[] } {
  const withExpr = parseRegexOptions(args);
  return withExpr;
}

function runAscii(args: string[]): void {
  if (args.includes("-h") || args.includes("--help")) { printAsciiHelp(); return; }
  const { options, rest } = parseAsciiOptions(args);
  if (rest.length < 1) die("error: the following required arguments were not provided", 2);
  showAndApply(planAscii(rest, options), options);
}

function runFromFile(args: string[]): void {
  if (args.includes("-h") || args.includes("--help")) { printFromFileHelp(); return; }
  const parsed = parseCommon(args, () => undefined);
  const rest = parsed.rest;
  if (rest.length < 1) die("error: the following required arguments were not provided", 2);
  const data = JSON.parse(fs.readFileSync(rest[0], "utf8")) as { operations: Op[] };
  let ops = data.operations || [];
  if (parsed.undo) ops = ops.map((op) => ({ source: op.target, target: op.source }));
  showAndApply(ops, parsed.options);
}

function main(): void {
  const args = process.argv.slice(2);
  const cmd = args[0];
  if (!cmd || cmd === "-h" || cmd === "--help") { printTopHelp(); return; }
  if (cmd === "-V" || cmd === "--version") { console.log(VERSION); return; }
  if (cmd === "help") {
    const sub = args[1];
    if (!sub) { printTopHelp(); return; }
    if (sub === "regex") printRegexHelp();
    else if (sub === "from-file") printFromFileHelp();
    else if (sub === "to-ascii") printAsciiHelp();
    else die(`error: unrecognized subcommand '${sub}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.`, 2);
    return;
  }
  if (cmd === "regex") runRegex(args.slice(1));
  else if (cmd === "to-ascii") runAscii(args.slice(1));
  else if (cmd === "from-file") runFromFile(args.slice(1));
  else die(`error: unrecognized subcommand '${cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.`, 2);
}

main();
