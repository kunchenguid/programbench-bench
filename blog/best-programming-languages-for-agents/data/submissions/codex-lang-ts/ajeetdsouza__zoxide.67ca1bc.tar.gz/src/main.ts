declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");
const cp = require("child_process");

type Entry = { path: string; score: number; time: number };

const VERSION = "0.9.9";
const AUTHORS = "Ajeet D'Souza <98ajeet@gmail.com>";
const PROJECT_URL = "https://github.com/ajeetdsouza/zoxide";
const ENVS = [
  "_ZO_DATA_DIR          Path for zoxide data files",
  "_ZO_ECHO              Print the matched directory before navigating to it when set to 1",
  "_ZO_EXCLUDE_DIRS      List of directory globs to be excluded",
  "_ZO_FZF_OPTS          Custom flags to pass to fzf",
  "_ZO_MAXAGE            Maximum total age after which entries start getting deleted",
  "_ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths",
];

function out(s = "") { process.stdout.write(s + "\n"); }
function err(s = "") { process.stderr.write(s + "\n"); }
function die(message: string, code = 1): never { err(`zoxide: ${message}`); process.exit(code); throw new Error(message); }

function envBlock(): string {
  return "\nEnvironment variables:\n" + ENVS.map((e) => `  ${e}`).join("\n");
}

function topHelp(): string {
  return `zoxide ${VERSION}
${AUTHORS}
${PROJECT_URL}

A smarter cd command for your terminal

Usage:
  executable <COMMAND>

Commands:
  add     Add a new directory or increment its rank
  edit    Edit the database
  import  Import entries from another application
  init    Generate shell configuration
  query   Search for a directory in the database
  remove  Remove a directory from the database

Options:
  -h, --help     Print help
  -V, --version  Print version${envBlock()}`;
}

const subHelps: Record<string, string> = {
  add: `zoxide-add ${VERSION}
${AUTHORS}
${PROJECT_URL}

Add a new directory or increment its rank

Usage:
  executable add [OPTIONS] <PATHS>...

Arguments:
  <PATHS>...  

Options:
  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't
  -h, --help           Print help
  -V, --version        Print version${envBlock()}`,
  edit: `zoxide-edit ${VERSION}
${AUTHORS}
${PROJECT_URL}

Edit the database

Usage:
  executable edit

Options:
  -h, --help     Print help
  -V, --version  Print version${envBlock()}`,
  import: `zoxide-import ${VERSION}
${AUTHORS}
${PROJECT_URL}

Import entries from another application

Usage:
  executable import [OPTIONS] --from <FROM> <PATH>

Arguments:
  <PATH>  

Options:
      --from <FROM>  Application to import from [possible values: autojump, z]
      --merge        Merge into existing database
  -h, --help         Print help
  -V, --version      Print version${envBlock()}`,
  init: `zoxide-init ${VERSION}
${AUTHORS}
${PROJECT_URL}

Generate shell configuration

Usage:
  executable init [OPTIONS] <SHELL>

Arguments:
  <SHELL>  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]

Options:
      --no-cmd       Prevents zoxide from defining the \`z\` and \`zi\` commands
      --cmd <CMD>    Changes the prefix of the \`z\` and \`zi\` commands [default: z]
      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]
  -h, --help         Print help
  -V, --version      Print version${envBlock()}`,
  query: `zoxide-query ${VERSION}
${AUTHORS}
${PROJECT_URL}

Search for a directory in the database

Usage:
  executable query [OPTIONS] [KEYWORDS]...

Arguments:
  [KEYWORDS]...  

Options:
  -a, --all              Show unavailable directories
  -i, --interactive      Use interactive selection
  -l, --list             List all matching directories
  -s, --score            Print score with results
      --exclude <path>   Exclude the current directory
      --base-dir <path>  Only search within this directory
  -h, --help             Print help
  -V, --version          Print version${envBlock()}`,
  remove: `zoxide-remove ${VERSION}
${AUTHORS}
${PROJECT_URL}

Remove a directory from the database

Usage:
  executable remove [PATHS]...

Arguments:
  [PATHS]...  

Options:
  -h, --help     Print help
  -V, --version  Print version${envBlock()}`,
};

function dataDir(): string {
  if (process.env._ZO_DATA_DIR) return process.env._ZO_DATA_DIR;
  const xdg = process.env.XDG_DATA_HOME;
  const home = process.env.HOME || ".";
  return xdg ? path.join(xdg, "zoxide") : path.join(home, ".local", "share", "zoxide");
}
function dbPath(): string { return path.join(dataDir(), "db.zo"); }

function readDb(): Entry[] {
  const file = dbPath();
  if (!fs.existsSync(file)) return [];
  const b = fs.readFileSync(file);
  if (b.length < 12) return [];
  let off = 0;
  const version = b.readUInt32LE(off); off += 4;
  if (version !== 3) return [];
  const n = Number(b.readBigUInt64LE(off)); off += 8;
  const entries: Entry[] = [];
  for (let i = 0; i < n && off + 8 <= b.length; i++) {
    const len = Number(b.readBigUInt64LE(off)); off += 8;
    if (off + len + 16 > b.length) break;
    const p = b.subarray(off, off + len).toString("utf8"); off += len;
    const score = b.readDoubleLE(off); off += 8;
    const time = Number(b.readBigInt64LE(off)); off += 8;
    entries.push({ path: p, score, time });
  }
  return entries;
}

function writeDb(entries: Entry[]) {
  fs.mkdirSync(dataDir(), { recursive: true });
  const parts: any[] = [];
  const head = Buffer.alloc(12);
  head.writeUInt32LE(3, 0);
  head.writeBigUInt64LE(BigInt(entries.length), 4);
  parts.push(head);
  for (const e of entries) {
    const p = Buffer.from(e.path, "utf8");
    const rec = Buffer.alloc(8 + p.length + 16);
    rec.writeBigUInt64LE(BigInt(p.length), 0);
    p.copy(rec, 8);
    rec.writeDoubleLE(e.score, 8 + p.length);
    rec.writeBigInt64LE(BigInt(Math.floor(e.time)), 16 + p.length);
    parts.push(rec);
  }
  fs.writeFileSync(dbPath(), Buffer.concat(parts));
}

function canonical(p: string): string {
  let q = p;
  if (q.startsWith("~")) q = path.join(process.env.HOME || "", q.slice(1));
  q = path.resolve(q);
  if (process.env._ZO_RESOLVE_SYMLINKS === "1") {
    try { q = fs.realpathSync(q); } catch {}
  }
  return q;
}

function globToRe(g: string): RegExp {
  const esc = g.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
  return new RegExp(`^${esc}$`);
}

function excluded(p: string): boolean {
  const raw = process.env._ZO_EXCLUDE_DIRS ?? (process.env.HOME || "");
  if (!raw) return false;
  return raw.split(":").filter(Boolean).some((g) => globToRe(canonical(g)).test(p));
}

function ageDb(entries: Entry[]): Entry[] {
  const maxAge = Number(process.env._ZO_MAXAGE || "10000");
  if (!Number.isFinite(maxAge) || maxAge <= 0) return entries;
  const total = entries.reduce((s, e) => s + e.score, 0);
  if (total <= maxAge) return entries;
  const factor = 0.9 * maxAge / total;
  return entries.map((e) => ({ ...e, score: e.score * factor })).filter((e) => e.score >= 1);
}

function frecency(e: Entry): number {
  const age = Math.max(0, Date.now() / 1000 - e.time);
  let mul = 0.25;
  if (age < 3600) mul = 4;
  else if (age < 86400) mul = 2;
  else if (age < 604800) mul = 0.5;
  return e.score * mul;
}

function parseOpts(args: string[], command = "") {
  const opts: any = { rest: [] as string[] };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") { opts.rest.push(...args.slice(i + 1)); break; }
    if (a === "-h" || a === "--help") opts.help = true;
    else if (a === "-V" || a === "--version") opts.version = true;
    else if (a === "-s" || a === "--score") {
      if (command === "add" && args[i + 1] && !args[i + 1].startsWith("-")) opts.scoreValue = args[++i];
      else opts.scoreFlag = true;
    } else if (a.startsWith("--score=")) opts.scoreValue = a.slice(8);
    else if (a === "-a" || a === "--all") opts.all = true;
    else if (a === "-i" || a === "--interactive") opts.interactive = true;
    else if (a === "-l" || a === "--list") opts.list = true;
    else if (a === "--merge") opts.merge = true;
    else if (a === "--no-cmd") opts.noCmd = true;
    else if (a === "--exclude" || a === "--base-dir" || a === "--from" || a === "--cmd" || a === "--hook") {
      opts[a.slice(2).replace("-", "_")] = args[++i];
    } else if (a.startsWith("--exclude=")) opts.exclude = a.slice(10);
    else if (a.startsWith("--base-dir=")) opts.base_dir = a.slice(11);
    else if (a.startsWith("--from=")) opts.from = a.slice(7);
    else if (a.startsWith("--cmd=")) opts.cmd = a.slice(6);
    else if (a.startsWith("--hook=")) opts.hook = a.slice(7);
    else opts.rest.push(a);
  }
  return opts;
}

function cmdAdd(args: string[]) {
  const o = parseOpts(args, "add");
  if (o.help) return out(subHelps.add);
  if (o.version) return out(`zoxide-add ${VERSION}`);
  if (!o.rest.length) {
    err("error: the following required arguments were not provided:\n  <PATHS>...\n\nUsage: executable add <PATHS>...\n\nFor more information, try '--help'.");
    process.exit(2);
  }
  const inc = o.scoreValue !== undefined ? Number(o.scoreValue) : 1;
  let db = readDb();
  const now = Math.floor(Date.now() / 1000);
  for (const raw of o.rest) {
    const p = canonical(raw);
    if (!fs.existsSync(p) || !fs.statSync(p).isDirectory()) die(`not a directory: ${raw}`);
    if (excluded(p)) continue;
    const found = db.find((e) => e.path === p);
    if (found) { found.score += inc; found.time = now; }
    else db.push({ path: p, score: inc, time: now });
  }
  db = ageDb(db);
  writeDb(db);
}

function keywordMatch(p: string, kws: string[]): boolean {
  if (kws.length === 1 && !kws[0].includes("/")) {
    return path.basename(p).toLowerCase().includes(kws[0].toLowerCase());
  }
  const s = p.toLowerCase();
  let pos = 0;
  for (const kwRaw of kws) {
    const kw = kwRaw.toLowerCase();
    if (kw.startsWith("/") && kw !== "/") return false;
    if (kw.endsWith("/")) {
      const stem = kw.slice(0, -1);
      const re = new RegExp(`(^|/)${stem.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}[^/]*/`);
      const m = re.exec(s.slice(pos));
      if (!m) return false;
      pos += (m.index || 0) + m[0].length;
    } else {
      const idx = s.indexOf(kw, pos);
      if (idx < 0) return false;
      pos = idx + kw.length;
    }
  }
  return true;
}

function filtered(o: any): Entry[] {
  const base = o.base_dir ? canonical(o.base_dir) : "";
  const ex = o.exclude ? canonical(o.exclude) : "";
  return readDb().filter((e) => {
    if (!o.all && (!fs.existsSync(e.path) || !fs.statSync(e.path).isDirectory())) return false;
    if (base && !(e.path === base || e.path.startsWith(base.endsWith("/") ? base : base + "/"))) return false;
    if (ex && e.path === ex) return false;
    return keywordMatch(e.path, o.rest);
  }).sort((a, b) => {
    const d = frecency(b) - frecency(a);
    if (Math.abs(d) > 1e-9) return d;
    return b.path.localeCompare(a.path);
  });
}

function fmtScore(n: number): string {
  const x = n * 10;
  const f = Math.floor(x);
  const frac = x - f;
  let rounded: number;
  if (Math.abs(frac - 0.5) < 1e-9) rounded = (f % 2 === 0) ? f : f + 1;
  else rounded = Math.round(x);
  return (rounded / 10).toFixed(1).padStart(6, " ");
}

function cmdQuery(args: string[]) {
  const o = parseOpts(args, "query");
  if (o.help) return out(subHelps.query);
  if (o.version) return out(`zoxide-query ${VERSION}`);
  let matches = filtered(o);
  if (o.interactive) {
    const input = matches.map((e) => `${fmtScore(frecency(e))} ${e.path}`).join("\n");
    try {
      const res = cp.execFileSync("fzf", [...(process.env._ZO_FZF_OPTS || "").split(/\s+/).filter(Boolean), "--no-sort"], { input, encoding: "utf8" }).trim();
      const m = res.match(/^\s*\S+\s+(.*)$/);
      if (m) return out(m[1]);
    } catch { process.exit(1); }
  }
  if (!matches.length) die("no match found");
  if (o.list) {
    for (const e of matches) out(o.scoreFlag ? `${fmtScore(frecency(e))} ${e.path}` : e.path);
  } else {
    const e = matches[0];
    out(o.scoreFlag ? `${fmtScore(frecency(e))} ${e.path}` : e.path);
  }
}

function cmdRemove(args: string[]) {
  const o = parseOpts(args, "remove");
  if (o.help) return out(subHelps.remove);
  if (o.version) return out(`zoxide-remove ${VERSION}`);
  if (!o.rest.length) return;
  const set = new Set(o.rest.map(canonical));
  writeDb(readDb().filter((e) => !set.has(e.path)));
}

function cmdImport(args: string[]) {
  const o = parseOpts(args, "import");
  if (o.help) return out(subHelps.import);
  if (o.version) return out(`zoxide-import ${VERSION}`);
  if (!o.from || !o.rest[0]) {
    err("error: the following required arguments were not provided:\n  --from <FROM>\n  <PATH>\n\nFor more information, try '--help'.");
    process.exit(2);
  }
  const file = o.rest[0];
  let text = "";
  try { text = fs.readFileSync(file, "utf8"); }
  catch { die(`could not open database for importing: ${file}\n\nCaused by:\n    No such file or directory (os error 2)`); }
  const db = o.merge ? readDb() : [];
  const addEntry = (p: string, score: number, time = Math.floor(Date.now() / 1000)) => {
    p = canonical(p);
    if (!fs.existsSync(p) || !fs.statSync(p).isDirectory()) return;
    const e = db.find((x) => x.path === p);
    if (e) { e.score += score; e.time = Math.max(e.time, time); }
    else db.push({ path: p, score, time });
  };
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim()) continue;
    if (o.from === "z") {
      const parts = line.split("|");
      if (parts.length >= 2) addEntry(parts[0], Number(parts[1]) || 1, Number(parts[2]) || Math.floor(Date.now() / 1000));
    } else if (o.from === "autojump") {
      const m = line.match(/^\s*([0-9.]+)\s+(.+)$/);
      if (m) addEntry(m[2], 0.05);
    } else die(`unknown import source: ${o.from}`);
  }
  writeDb(ageDb(db));
}

function cmdEdit(args: string[]) {
  const o = parseOpts(args, "edit");
  if (o.help) return out(subHelps.edit);
  if (o.version) return out(`zoxide-edit ${VERSION}`);
  const editor = process.env.EDITOR || process.env.VISUAL;
  if (editor) cp.spawnSync(editor, [dbPath()], { stdio: "inherit", shell: true });
}

function initTemplate(shell: string, cmd = "z", hook = "pwd", noCmd = false): string {
  const zi = `${cmd}i`;
  if (shell === "bash" || shell === "zsh" || shell === "posix") {
    const fn = shell === "posix" ? "" : "function ";
    const open = shell === "posix" ? "()" : "()";
    let s = `# shellcheck shell=${shell === "posix" ? "sh" : "bash"}\n\n__zoxide_pwd() {\n    \\builtin pwd -L 2>/dev/null || \\command pwd -L\n}\n\n__zoxide_cd() {\n    \\builtin cd -- \"$@\"\n}\n\n`;
    if (hook !== "none") s += `__zoxide_hook() {\n    \\command zoxide add -- \"$(__zoxide_pwd)\"\n}\n`;
    s += `\n${fn}__zoxide_z${open} {\n    if [ \"$#\" -eq 0 ]; then\n        __zoxide_cd ~\n    elif [ \"$#\" -eq 1 ] && { [ -d \"$1\" ] || [ \"$1\" = '-' ]; }; then\n        __zoxide_cd \"$1\"\n    else\n        __zoxide_result=\"$(\\command zoxide query --exclude \"$(__zoxide_pwd)\" -- \"$@\")\" && __zoxide_cd \"$__zoxide_result\"\n    fi\n}\n\n${fn}__zoxide_zi${open} {\n    __zoxide_result=\"$(\\command zoxide query --interactive -- \"$@\")\" && __zoxide_cd \"$__zoxide_result\"\n}\n`;
    if (!noCmd) s += `\n${cmd}() { __zoxide_z "$@"; }\n${zi}() { __zoxide_zi "$@"; }\n`;
    return s;
  }
  if (shell === "fish") {
    return `function __zoxide_pwd\n    builtin pwd -L\nend\nfunction __zoxide_z\n    set -l result (command zoxide query --exclude (__zoxide_pwd) -- $argv); and cd $result\nend\nfunction __zoxide_zi\n    set -l result (command zoxide query --interactive -- $argv); and cd $result\nend\n${noCmd ? "" : `alias ${cmd}=__zoxide_z\nalias ${zi}=__zoxide_zi\n`}`;
  }
  if (shell === "powershell") {
    return `function global:__zoxide_z { $result = zoxide query --exclude $pwd @args; if ($?) { Set-Location $result } }\nfunction global:__zoxide_zi { $result = zoxide query --interactive @args; if ($?) { Set-Location $result } }\n${noCmd ? "" : `Set-Alias -Name ${cmd} -Value __zoxide_z\nSet-Alias -Name ${zi} -Value __zoxide_zi\n`}`;
  }
  if (shell === "nushell") return `# Code generated by zoxide. DO NOT EDIT.\ndef --env --wrapped __zoxide_z [...rest: string] { cd (^zoxide query --exclude $env.PWD -- ...$rest | str trim) }\ndef --env --wrapped __zoxide_zi [...rest: string] { cd (^zoxide query --interactive -- ...$rest | str trim) }\n${noCmd ? "" : `alias ${cmd} = __zoxide_z\nalias ${zi} = __zoxide_zi\n`}`;
  if (shell === "tcsh") {
    let s = "alias __zoxide_z 'set r = \"`zoxide query -- \\!*`\"; cd \"$r\"'\n";
    if (!noCmd) s += `alias ${cmd} __zoxide_z\nalias ${zi} 'set r = "\`zoxide query --interactive -- \\!*\`"; cd "$r"'\n`;
    return s;
  }
  if (shell === "elvish") return `fn __zoxide_z {|@rest| var p = (zoxide query -- $@rest); cd $p }\nfn __zoxide_zi {|@rest| var p = (zoxide query --interactive -- $@rest); cd $p }\n`;
  if (shell === "xonsh") return `def __zoxide_z(args):\n    import subprocess, os\n    p = subprocess.check_output(['zoxide','query','--'] + args).decode().strip()\n    os.chdir(p)\n`;
  return "";
}

function cmdInit(args: string[]) {
  const o = parseOpts(args, "init");
  if (o.help) return out(subHelps.init);
  if (o.version) return out(`zoxide-init ${VERSION}`);
  const shell = o.rest[0];
  const shells = ["bash", "elvish", "fish", "nushell", "posix", "powershell", "tcsh", "xonsh", "zsh"];
  if (!shell) { err("error: the following required arguments were not provided:\n  <SHELL>\n\nFor more information, try '--help'."); process.exit(2); }
  if (!shells.includes(shell)) { err(`error: invalid value '${shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nFor more information, try '--help'.`); process.exit(2); }
  out(initTemplate(shell, o.cmd || "z", o.hook || "pwd", !!o.noCmd).replace(/\n$/, ""));
}

function main() {
  const args = process.argv.slice(2);
  if (!args.length || args[0] === "-h" || args[0] === "--help") return out(topHelp());
  if (args[0] === "-V" || args[0] === "--version") return out(`zoxide ${VERSION}`);
  const [cmd, ...rest] = args;
  if (cmd === "add") return cmdAdd(rest);
  if (cmd === "query") return cmdQuery(rest);
  if (cmd === "remove") return cmdRemove(rest);
  if (cmd === "import") return cmdImport(rest);
  if (cmd === "init") return cmdInit(rest);
  if (cmd === "edit") return cmdEdit(rest);
  err(`error: unrecognized subcommand '${cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.`);
  process.exit(2);
}

main();
