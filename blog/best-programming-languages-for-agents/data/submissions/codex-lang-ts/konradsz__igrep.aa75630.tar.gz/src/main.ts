declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

const VERSION = "igrep 1.3.0";

const EDITORS = [
  "vim", "neovim", "nvim", "nano", "code", "vscode", "code-insiders",
  "emacs", "emacsclient", "hx", "helix", "subl", "sublime-text", "micro",
  "intellij", "goland", "pycharm", "less", "fresh",
];

const THEMES = ["light", "dark"];
const VIEWERS = ["none", "vertical", "horizontal"];
const SORTS = ["path", "modified", "created", "accessed"];

const HELP = `Interactive Grep

Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

Arguments:
  <PATTERN>   Regular expression used for searching
  [PATHS]...  Files or directories to search. Directories are searched recursively. If not specified, searching starts from current directory

Options:
      --editor <EDITOR>
          Text editor used to open selected match [possible values: vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh]
      --custom-command <CUSTOM_COMMAND>
          Custom command used to open selected match. Must contain {file_name} and {line_number} tokens [env: IGREP_CUSTOM_EDITOR=]
      --theme <THEME>
          UI color theme [default: dark] [possible values: light, dark]
  -i, --ignore-case
          Searches case insensitively
  -S, --smart-case
          Searches case insensitively if the pattern is all lowercase. Search case sensitively otherwise
  -., --hidden
          Search hidden files and directories. By default, hidden files and directories are skipped
  -L, --follow
          Follow symbolic links while traversing directories
  -w, --word-regexp
          Only show matches surrounded by word boundaries
  -F, --fixed-strings
          Exact matches with no regex. Useful when searching for a string full of delimiters
  -U, --multiline
          Search with pattern contains newline character ('\\n')
  -g, --glob <GLOB>
          Include files and directories for searching that match the given glob. Multiple globs may be provided
      --type-list
          Show all supported file types and their corresponding globs
  -t, --type <TYPE_MATCHING>
          Only search files matching TYPE. Multiple types may be provided
  -T, --type-not <TYPE_NOT>
          Do not search files matching TYPE-NOT. Multiple types-not may be provided
      --context-viewer <CONTEXT_VIEWER>
          Context viewer position at startup [default: none] [possible values: none, vertical, horizontal]
      --sort <SORT_BY>
          Sort results, see ripgrep for details [possible values: path, modified, created, accessed]
      --sortr <SORT_BY_REVERSE>
          Sort results reverse, see ripgrep for details [possible values: path, modified, created, accessed]
  -h, --help
          Print help
  -V, --version
          Print version
`;

const TYPE_LIST = `ada: *.adb, *.ads
agda: *.agda, *.lagda
aidl: *.aidl
alire: alire.toml
amake: *.bp, *.mk
asciidoc: *.adoc, *.asc, *.asciidoc
asm: *.S, *.asm, *.s
asp: *.ascx, *.ascx.cs, *.ascx.vb, *.asp, *.aspx, *.aspx.cs, *.aspx.vb
ats: *.ats, *.dats, *.hats, *.sats
avro: *.avdl, *.avpr, *.avsc
awk: *.awk
bat: *.bat
batch: *.bat
bazel: *.BUILD, *.bazel, *.bazelrc, *.bzl, BUILD, MODULE.bazel, WORKSPACE, WORKSPACE.bazel
bitbake: *.bb, *.bbappend, *.bbclass, *.conf, *.inc
brotli: *.br
buildstream: *.bst
bzip2: *.bz2, *.tbz2
c: *.[chH], *.[chH].in, *.cats
cabal: *.cabal
candid: *.did
carp: *.carp
cbor: *.cbor
ceylon: *.ceylon
clojure: *.clj, *.cljc, *.cljs, *.cljx
cmake: *.cmake, CMakeLists.txt
cmd: *.bat, *.cmd
cml: *.cml
coffeescript: *.coffee
config: *.cfg, *.conf, *.config, *.ini
coq: *.v
cpp: *.[ChH], *.[ChH].in, *.[ch]pp, *.[ch]pp.in, *.[ch]xx, *.[ch]xx.in, *.cc, *.cc.in, *.hh, *.hh.in, *.inl
creole: *.creole
crystal: *.cr, *.ecr, Projectfile, shard.yml
cs: *.cs
csharp: *.cs
cshtml: *.cshtml
csproj: *.csproj
css: *.css, *.scss
csv: *.csv
cuda: *.cu, *.cuh
cython: *.pxd, *.pxi, *.pyx
d: *.d
dart: *.dart
devicetree: *.dts, *.dtsi
dhall: *.dhall
diff: *.diff, *.patch
dita: *.dita, *.ditamap, *.ditaval
docker: *Dockerfile*
dockercompose: docker-compose.*.yml, docker-compose.yml
dts: *.dts, *.dtsi
dvc: *.dvc, Dvcfile
ebuild: *.ebuild, *.eclass
edn: *.edn
elisp: *.el
elixir: *.eex, *.ex, *.exs, *.heex, *.leex, *.livemd
elm: *.elm
erb: *.erb
erlang: *.erl, *.hrl
fennel: *.fnl
fidl: *.fidl
fish: *.fish
flatbuffers: *.fbs
fortran: *.F, *.F77, *.F90, *.F95, *.f, *.f77, *.f90, *.f95, *.pfo
fsharp: *.fs, *.fsi, *.fsx
fut: *.fut
gap: *.g, *.gap, *.gd, *.gi, *.tst
gn: *.gn, *.gni
go: *.go
gprbuild: *.gpr
gradle: *.gradle, *.gradle.kts, gradle-wrapper.*, gradle.properties, gradlew, gradlew.bat
graphql: *.graphql, *.graphqls
groovy: *.gradle, *.groovy
gzip: *.gz, *.tgz
h: *.h, *.hh, *.hpp
haml: *.haml
hare: *.ha
haskell: *.c2hs, *.cpphs, *.hs, *.hsc, *.lhs
hbs: *.hbs
hs: *.hs, *.lhs
html: *.ejs, *.htm, *.html
hy: *.hy
idris: *.idr, *.lidr
janet: *.janet
java: *.java, *.jsp, *.jspx, *.properties
jinja: *.j2, *.jinja, *.jinja2
jl: *.jl
js: *.cjs, *.js, *.jsx, *.mjs, *.vue
json: *.json, *.sarif, composer.lock
jsonl: *.jsonl
julia: *.jl
jupyter: *.ipynb, *.jpynb
k: *.k
kotlin: *.kt, *.kts
lean: *.lean
less: *.less
license: *[.-]LICEN[CS]E*, AGPL-*[0-9]*, APACHE-*[0-9]*, BSD-*[0-9]*, CC-BY-*, COPYING, COPYING[.-]*, COPYRIGHT, COPYRIGHT[.-]*, EULA, EULA[.-]*, GFDL-*[0-9]*, GNU-*[0-9]*, GPL-*[0-9]*, LGPL-*[0-9]*, LICEN[CS]E, LICEN[CS]E[.-]*, MIT-*[0-9]*, MPL-*[0-9]*, NOTICE, NOTICE[.-]*, OFL-*[0-9]*, PATENTS, PATENTS[.-]*, UNLICEN[CS]E, UNLICEN[CS]E[.-]*, agpl[.-]*, gpl[.-]*, lgpl[.-]*, licen[cs]e, licen[cs]e.*
lilypond: *.ily, *.ly
lisp: *.el, *.jl, *.lisp, *.lsp, *.sc, *.scm
lock: *.lock, package-lock.json
log: *.log
lua: *.lua
lz4: *.lz4
lzma: *.lzma
m4: *.ac, *.m4
make: *.mak, *.mk, [Gg][Nn][Uu]makefile, [Gg][Nn][Uu]makefile.am, [Gg][Nn][Uu]makefile.in, [Mm]akefile, [Mm]akefile.am, [Mm]akefile.in
mako: *.mako, *.mao
man: *.[0-9][cEFMmpSx], *.[0-9lnpx]
markdown: *.markdown, *.md, *.mdown, *.mdwn, *.mdx, *.mkd, *.mkdn
matlab: *.m
md: *.markdown, *.md, *.mdown, *.mdwn, *.mdx, *.mkd, *.mkdn
meson: meson.build, meson.options, meson_options.txt
minified: *.min.css, *.min.html, *.min.js
mint: *.mint
mk: mkfile
ml: *.ml
motoko: *.mo
msbuild: *.csproj, *.fsproj, *.proj, *.props, *.sln, *.targets, *.vcxproj
nim: *.nim, *.nimble, *.nimf, *.nims
nix: *.nix
objc: *.h, *.m
objcpp: *.h, *.mm
ocaml: *.ml, *.mli, *.mll, *.mly
org: *.org, *.org_archive
pants: BUILD
pascal: *.dpr, *.inc, *.lpr, *.pas, *.pp
pdf: *.pdf
perl: *.PL, *.perl, *.pl, *.plh, *.plx, *.pm, *.t
php: *.php, *.php3, *.php4, *.php5, *.php7, *.php8, *.pht, *.phtml
po: *.po
pod: *.pod
postscript: *.eps, *.ps
prolog: *.P, *.pl, *.pro, *.prolog
protobuf: *.proto
ps: *.cdxml, *.ps1, *.ps1xml, *.psd1, *.psm1
puppet: *.epp, *.erb, *.pp, *.rb
purs: *.purs
py: *.py, *.pyi
python: *.py, *.pyi
qmake: *.prf, *.pri, *.pro
qml: *.qml
r: *.R, *.Rmd, *.Rnw, *.r
racket: *.rkt
raku: *.p6, *.pl6, *.pm6, *.raku, *.rakudoc, *.rakumod, *.rakutest
rdoc: *.rdoc
readme: *README, README*
reasonml: *.re, *.rei
red: *.r, *.red, *.reds
rescript: *.res, *.resi
robot: *.robot
rst: *.rst
ruby: *.gemspec, *.rb, *.rbw, .irbrc, Gemfile, Rakefile, config.ru
rust: *.rs
sass: *.sass, *.scss
scala: *.sbt, *.scala
sh: *.bash, *.bashrc, *.csh, *.cshrc, *.ksh, *.kshrc, *.sh, *.tcsh, *.zsh, .bash_login, .bash_logout, .bash_profile, .bashrc, .cshrc, .kshrc, .login, .logout, .profile, .tcshrc, .zlogin, .zlogout, .zprofile, .zshenv, .zshrc, bash_login, bash_logout, bash_profile, bashrc, profile, zlogin, zlogout, zprofile, zshenv, zshrc
slim: *.skim, *.slim, *.slime
smarty: *.tpl
sml: *.sig, *.sml
solidity: *.sol
soy: *.soy
spark: *.spark
spec: *.spec
sql: *.psql, *.sql
stylus: *.styl
sv: *.h, *.sv, *.svh, *.v, *.vg
svg: *.svg
swift: *.swift
swig: *.def, *.i
systemd: *.automount, *.conf, *.device, *.link, *.mount, *.path, *.scope, *.service, *.slice, *.socket, *.swap, *.target, *.timer
taskpaper: *.taskpaper
tcl: *.tcl
tex: *.bib, *.cls, *.dtx, *.ins, *.ltx, *.sty, *.tex
texinfo: *.texi
textile: *.textile
tf: *.auto.tfvars, *.auto.tfvars.json, *.terraform.lock.hcl, *.terraformrc, *.tf, *.tf.json, *.tfrc, terraform.rc, terraform.tfvars, terraform.tfvars.json
thrift: *.thrift
toml: *.toml, Cargo.lock
ts: *.cts, *.mts, *.ts, *.tsx
twig: *.twig
txt: *.txt
typescript: *.cts, *.mts, *.ts, *.tsx
typoscript: *.ts, *.typoscript
usd: *.usd, *.usda, *.usdc
v: *.v, *.vsh
vala: *.vala
vb: *.vb
vcl: *.vcl
verilog: *.sv, *.svh, *.v, *.vh
vhdl: *.vhd, *.vhdl
vim: *.vim, .gvimrc, .vimrc, _gvimrc, _vimrc, gvimrc, vimrc
vimscript: *.vim, .gvimrc, .vimrc, _gvimrc, _vimrc, gvimrc, vimrc
webidl: *.idl, *.webidl, *.widl
wiki: *.mediawiki, *.wiki
xml: *.dtd, *.rng, *.sch, *.xhtml, *.xjb, *.xml, *.xml.dist, *.xsd, *.xsl, *.xslt
xz: *.txz, *.xz
yacc: *.y
yaml: *.yaml, *.yml
yang: *.yang
z: *.Z
zig: *.zig
zsh: *.zsh, .zlogin, .zlogout, .zprofile, .zshenv, .zshrc, zlogin, zlogout, zprofile, zshenv, zshrc
zstd: *.zst, *.zstd
`;

function out(s: string) {
  process.stdout.write(s.endsWith("\n") ? s : s + "\n");
}

function err(s: string) {
  process.stderr.write(s.endsWith("\n") ? s : s + "\n");
}

function exitError(message: string, code = 2) {
  err(message);
  process.exit(code);
}

function valueError(option: string, value: string, possible: string[]) {
  exitError(`error: invalid value '${value}' for '${option}'
  [possible values: ${possible.join(", ")}]

For more information, try '--help'.`);
}

function requiredValue(opt: string) {
  exitError(`error: a value is required for '${opt}' but none was supplied

For more information, try '--help'.`);
}

function hasOnce(s: string, token: string): boolean {
  return s.indexOf(token) !== -1 && s.indexOf(token) === s.lastIndexOf(token);
}

function validateCustom(command: string) {
  if (!hasOnce(command, "{line_number}")) {
    exitError(`Error: Incorrect editor command: '${command}'

Caused by:
    Expected one occurrence of '{line_number}'.`, 1);
  }
  if (!hasOnce(command, "{file_name}")) {
    exitError(`Error: Incorrect editor command: '${command}'

Caused by:
    Expected one occurrence of '{file_name}'.`, 1);
  }
}

type Opts = {
  typeList: boolean;
  pattern?: string;
  paths: string[];
  ignoreCase: boolean;
  smartCase: boolean;
  fixed: boolean;
  word: boolean;
  hidden: boolean;
  follow: boolean;
  globs: string[];
};

function parse(argv: string[]): Opts {
  if (process.env.IGREP_CUSTOM_EDITOR) validateCustom(process.env.IGREP_CUSTOM_EDITOR);
  const opts: Opts = {
    typeList: false, paths: [], ignoreCase: false, smartCase: false,
    fixed: false, word: false, hidden: false, follow: false, globs: [],
  };
  const positionals: string[] = [];

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = () => {
      if (i + 1 >= argv.length) requiredValue(a);
      return argv[++i];
    };
    if (a === "--") {
      positionals.push(...argv.slice(i + 1));
      break;
    } else if (a === "-h" || a === "--help") {
      out(HELP);
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      out(VERSION);
      process.exit(0);
    } else if (a === "--type-list") {
      opts.typeList = true;
    } else if (a === "-i" || a === "--ignore-case") {
      opts.ignoreCase = true;
    } else if (a === "-S" || a === "--smart-case") {
      opts.smartCase = true;
    } else if (a === "-F" || a === "--fixed-strings") {
      opts.fixed = true;
    } else if (a === "-w" || a === "--word-regexp") {
      opts.word = true;
    } else if (a === "-." || a === "--hidden") {
      opts.hidden = true;
    } else if (a === "-L" || a === "--follow") {
      opts.follow = true;
    } else if (a === "-U" || a === "--multiline") {
      // Accepted for compatibility. JavaScript RegExp already supports multiline text.
    } else if (a === "-g" || a === "--glob") {
      opts.globs.push(next());
    } else if (a === "-t" || a === "--type" || a === "-T" || a === "--type-not") {
      next();
    } else if (a === "--editor") {
      const v = next();
      if (!EDITORS.includes(v)) valueError("--editor <EDITOR>", v, EDITORS);
    } else if (a === "--theme") {
      const v = next();
      if (!THEMES.includes(v)) valueError("--theme <THEME>", v, THEMES);
    } else if (a === "--context-viewer") {
      const v = next();
      if (!VIEWERS.includes(v)) valueError("--context-viewer <CONTEXT_VIEWER>", v, VIEWERS);
    } else if (a === "--sort") {
      const v = next();
      if (!SORTS.includes(v)) valueError("--sort <SORT_BY>", v, SORTS);
    } else if (a === "--sortr") {
      const v = next();
      if (!SORTS.includes(v)) valueError("--sortr <SORT_BY_REVERSE>", v, SORTS);
    } else if (a === "--custom-command") {
      validateCustom(next());
    } else if (a.startsWith("--editor=")) {
      const v = a.slice(9);
      if (!EDITORS.includes(v)) valueError("--editor <EDITOR>", v, EDITORS);
    } else if (a.startsWith("--theme=")) {
      const v = a.slice(8);
      if (!THEMES.includes(v)) valueError("--theme <THEME>", v, THEMES);
    } else if (a.startsWith("--context-viewer=")) {
      const v = a.slice(17);
      if (!VIEWERS.includes(v)) valueError("--context-viewer <CONTEXT_VIEWER>", v, VIEWERS);
    } else if (a.startsWith("--custom-command=")) {
      validateCustom(a.slice(17));
    } else if (a.startsWith("--glob=")) {
      opts.globs.push(a.slice(7));
    } else if (a.startsWith("--type=") || a.startsWith("--type-not=")) {
      // Accepted for compatibility; the lightweight searcher does not need the value in non-TTY mode.
    } else if (a.startsWith("--sort=")) {
      const v = a.slice(7);
      if (!SORTS.includes(v)) valueError("--sort <SORT_BY>", v, SORTS);
    } else if (a.startsWith("--sortr=")) {
      const v = a.slice(8);
      if (!SORTS.includes(v)) valueError("--sortr <SORT_BY_REVERSE>", v, SORTS);
    } else if (a.startsWith("--")) {
      exitError(`error: unexpected argument '${a}' found

  tip: to pass '${a}' as a value, use '-- ${a}'

Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

For more information, try '--help'.`);
    } else if (a.startsWith("-") && a !== "-") {
      for (const ch of a.slice(1)) {
        if (ch === "i") opts.ignoreCase = true;
        else if (ch === "S") opts.smartCase = true;
        else if (ch === "F") opts.fixed = true;
        else if (ch === "w") opts.word = true;
        else if (ch === ".") opts.hidden = true;
        else if (ch === "L") opts.follow = true;
        else if (ch === "U") {}
        else exitError(`error: unexpected argument '-${ch}' found

Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

For more information, try '--help'.`);
      }
    } else {
      positionals.push(a);
    }
  }

  if (opts.typeList) return opts;

  if (positionals.length === 0) {
    exitError(`error: the following required arguments were not provided:
  --type-list
  <PATTERN>

Usage: executable --type-list <PATTERN> [PATHS]...

For more information, try '--help'.`);
  }
  opts.pattern = positionals[0];
  opts.paths = positionals.slice(1);
  return opts;
}

function isHiddenName(p: string): boolean {
  return path.basename(p).startsWith(".");
}

function walk(p: string, opts: Opts, acc: string[]) {
  let st;
  try {
    st = fs.statSync(p);
  } catch {
    return;
  }
  if (!opts.hidden && isHiddenName(p) && path.basename(p) !== ".") return;
  if (st.isDirectory()) {
    for (const ent of fs.readdirSync(p)) walk(path.join(p, ent), opts, acc);
  } else if (st.isFile()) {
    acc.push(p);
  }
}

function globOk(file: string, globs: string[]) {
  if (globs.length === 0) return true;
  return globs.some(g => {
    if (g.startsWith("*.")) return file.endsWith(g.slice(1));
    if (g.includes("*")) {
      const re = new RegExp("^" + g.split("*").map((x: string) => x.replace(/[.+?^${}()|[\]\\]/g, "\\$&")).join(".*") + "$");
      return re.test(path.basename(file)) || re.test(file);
    }
    return file === g || path.basename(file) === g;
  });
}

function search(opts: Opts) {
  // The original interactive program errors this way in the non-TTY cleanroom.
  // Preserve that externally visible behavior, but allow useful output if a TTY is available.
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    exitError("Error: Resource temporarily unavailable (os error 11)", 1);
  }
  const roots = opts.paths.length ? opts.paths : ["."];
  const files: string[] = [];
  for (const p of roots) walk(p, opts, files);
  const flags = opts.ignoreCase || (opts.smartCase && opts.pattern === opts.pattern!.toLowerCase()) ? "i" : "";
  const needle = opts.fixed ? opts.pattern!.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") : opts.pattern!;
  const bounded = opts.word ? `\\b(?:${needle})\\b` : needle;
  let re: RegExp;
  try {
    re = new RegExp(bounded, flags);
  } catch (e: any) {
    exitError(`Error: ${e.message}`, 1);
  }
  for (const file of files.filter(f => globOk(f, opts.globs))) {
    let text = "";
    try { text = fs.readFileSync(file, "utf8"); } catch { continue; }
    const lines = text.split(/\r?\n/);
    lines.forEach((line: string, idx: number) => {
      if (re.test(line)) out(`${file}:${idx + 1}:${line}`);
    });
  }
}

const opts = parse(process.argv.slice(2));
if (opts.typeList) {
  out(TYPE_LIST);
  process.exit(0);
}
search(opts);
