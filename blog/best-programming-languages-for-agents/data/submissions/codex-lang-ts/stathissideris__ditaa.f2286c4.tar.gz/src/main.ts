declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const HELP = `usage: java -jar ditaa.jar <INPFILE> [OUTFILE] [-A] [-b <BACKGROUND>] [-d]
       [-E] [-e <ENCODING>] [-h] [--help] [-o] [-r] [-S] [-s <SCALE>]
       [--svg] [--svg-font-url <FONT>] [-T] [-t <TABS>] [-v] [-W]
 -A,--no-antialias              Turns anti-aliasing off.
 -b,--background <BACKGROUND>   The background colour of the image. The
                                format should be a six-digit hexadecimal
                                number (as in HTML, FF0000 for red). Pass
                                an eight-digit hex to define transparency.
                                This is overridden by --transparent.
 -d,--debug                     Renders the debug grid over the resulting
                                image.
 -E,--no-separation             Prevents the separation of common edges of
                                shapes.
 -e,--encoding <ENCODING>       The encoding of the input file.
 -h,--html                      In this case the input is an HTML file.
                                The contents of the <pre
                                class="textdiagram"> tags are rendered as
                                diagrams and saved in the images directory
                                and a new HTML file is produced with the
                                appropriate <img> tags.
    --help                      Prints usage help.
 -o,--overwrite                 If the filename of the destination image
                                already exists, an alternative name is
                                chosen. If the overwrite option is
                                selected, the image file is instead
                                overwriten.
 -r,--round-corners             Causes all corners to be rendered as round
                                corners.
 -S,--no-shadows                Turns off the drop-shadow effect.
 -s,--scale <SCALE>             A natural number that determines the size
                                of the rendered image. The units are
                                fractions of the default size (2.5 renders
                                1.5 times bigger than the default).
    --svg                       Write an SVG image as destination file.
    --svg-font-url <FONT>       SVG font URL.
 -T,--transparent               Causes the diagram to be rendered on a
                                transparent background. Overrides
                                --background.
 -t,--tabs <TABS>               Tabs are normally interpreted as 8 spaces
                                but it is possible to change that using
                                this option. It is not advisable to use
                                tabs in your diagrams.
 -v,--verbose                   Makes ditaa more verbose.
 -W,--fixed-slope               Makes sides of parallelograms and
                                trapezoids fixed slope instead of fixed
                                width.`;

type Opts = { svg:boolean; html:boolean; overwrite:boolean; transparent:boolean; background:string; scale:number; tabs:number; shadows:boolean; round:boolean; debug:boolean; verbose:boolean; encoding:string; svgFontUrl?:string; flags:string[]; input?:string; output?:string };
type Shape = {x1:number;y1:number;x2:number;y2:number; tag:string; color:string; dashed:boolean};
type LineSeg = {x1:number;y1:number;x2:number;y2:number; dashed:boolean};
type Arrow = {x:number;y:number;dir:string};

function parseArgs(argv:string[]): Opts {
  const o: Opts = {svg:false,html:false,overwrite:false,transparent:false,background:'ffffff',scale:1,tabs:8,shadows:true,round:false,debug:false,verbose:false,encoding:'utf8',flags:[]};
  const positional:string[]=[];
  for(let i=0;i<argv.length;i++){
    const a=argv[i];
    if(a==='--help'){ console.log(HELP); process.exit(0); }
    else if(a==='--svg'){ o.svg=true; o.flags.push('svg'); }
    else if(a==='--svg-font-url'){ o.svgFontUrl=argv[++i]||''; o.flags.push('svg-font-url'); }
    else if(a==='-h'||a==='--html'){ o.html=true; o.flags.push('html'); }
    else if(a==='-o'||a==='--overwrite'){ o.overwrite=true; o.flags.push('overwrite'); }
    else if(a==='-T'||a==='--transparent'){ o.transparent=true; o.flags.push('transparent'); }
    else if(a==='-S'||a==='--no-shadows'){ o.shadows=false; o.flags.push('no-shadows'); }
    else if(a==='-r'||a==='--round-corners'){ o.round=true; o.flags.push('round-corners'); }
    else if(a==='-d'||a==='--debug'){ o.debug=true; o.flags.push('debug'); }
    else if(a==='-v'||a==='--verbose'){ o.verbose=true; o.flags.push('verbose'); }
    else if(a==='-A'||a==='--no-antialias'){ o.flags.push('no-antialias'); }
    else if(a==='-E'||a==='--no-separation'){ o.flags.push('no-separation'); }
    else if(a==='-W'||a==='--fixed-slope'){ o.flags.push('fixed-slope'); }
    else if(a==='-b'||a==='--background'){ o.background=(argv[++i]||'ffffff').replace(/^#/,'').toLowerCase(); o.flags.push('background'); }
    else if(a==='-s'||a==='--scale'){ o.scale=parseFloat(argv[++i]||'1')||1; o.flags.push('scale'); }
    else if(a==='-t'||a==='--tabs'){ o.tabs=parseInt(argv[++i]||'8',10)||8; o.flags.push('tabs'); }
    else if(a==='-e'||a==='--encoding'){ o.encoding=argv[++i]||'utf8'; o.flags.push('encoding'); }
    else if(a.startsWith('-')) { /* commons-cli tolerated unknowns poorly; keep quiet */ }
    else positional.push(a);
  }
  o.input=positional[0]; o.output=positional[1];
  return o;
}

function banner(o:Opts){
  console.error('\nditaa version 0.11, Copyright (C) 2004--2017  Efstathios (Stathis) Sideris\n');
  console.error('Running with options:');
  for(const f of o.flags) console.error(f);
}
function esc(s:string){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function cdata(s:string){return s.replace(/]]>/g,']]]]><![CDATA[>');}
function expandTabs(s:string,n:number){return s.replace(/\t/g,' '.repeat(n));}
function getGrid(text:string,o:Opts){
  const lines=text.replace(/\r\n/g,'\n').replace(/\r/g,'\n').split('\n').map(l=>expandTabs(l,o.tabs));
  if(lines.length && lines[lines.length-1]==='') lines.pop();
  const max=Math.max(0,...lines.map(l=>l.length));
  return lines.map(l=>l.padEnd(max,' '));
}
function gx(c:number, scale=1){return (25+c*10)*scale;}
function gy(r:number, scale=1){return (35+r*14)*scale;}
function width(cols:number,o:Opts){return Math.ceil((cols*10+40)*o.scale);}
function height(rows:number,o:Opts){return Math.ceil((rows*14+56)*o.scale);}
function isH(ch:string){return ch==='-'||ch==='='||ch==='+'||ch==='<'||ch==='>'||ch==='*';}
function isV(ch:string){return ch==='|'||ch===':'||ch==='+'||ch==='^'||ch==='v'||ch==='*';}
const colorMap:any={RED:'ff9999',GRE:'99ff99',BLU:'9999ff',PNK:'ff99ff',YEL:'ffff99',BLK:'000000'};

function findShapes(g:string[]):Shape[]{
  const rows=g.length, cols=rows?g[0].length:0, shapes:Shape[]=[];
  const seen=new Set<string>();
  for(let r1=0;r1<rows;r1++) for(let c1=0;c1<cols;c1++) if(g[r1][c1]==='+'){
    for(let c2=c1+2;c2<cols;c2++) if(g[r1][c2]==='+' && clearH(g,r1,c1,c2)){
      for(let r2=r1+2;r2<rows;r2++) if(g[r2][c1]==='+'&&g[r2][c2]==='+'&&clearH(g,r2,c1,c2)&&clearV(g,c1,r1,r2)&&clearV(g,c2,r1,r2)){
        const key=`${c1},${r1},${c2},${r2}`;
        if(seen.has(key)) continue;
        // Prefer maximal rectangles: skip if contained in an existing bigger shape with same top-left or bottom-right.
        let tag='', color='white';
        const inside=g.slice(r1+1,r2).map(x=>x.slice(c1+1,c2)).join('\n');
        const tm=inside.match(/\{(d|s|o|mo|c|tr|io)\}/); if(tm) tag=tm[1];
        const cm=inside.match(/c(RED|GRE|BLU|PNK|YEL|BLK)/); if(cm) color='#'+colorMap[cm[1]];
        const dashed = g[r1].slice(c1,c2+1).includes('=') || g[r2].slice(c1,c2+1).includes('=') || hasColon(g,c1,r1,r2) || hasColon(g,c2,r1,r2);
        shapes.push({x1:c1,y1:r1,x2:c2,y2:r2,tag,color,dashed}); seen.add(key);
        break;
      }
    }
  }
  // Remove shapes strictly containing a smaller shape only when they share many borders? Keep all otherwise.
  return shapes.filter((s,i)=>!shapes.some((t,j)=>j!==i && s.x1>=t.x1&&s.y1>=t.y1&&s.x2<=t.x2&&s.y2<=t.y2 && (t.x2-t.x1)*(t.y2-t.y1)<(s.x2-s.x1)*(s.y2-s.y1)));
}
function clearH(g:string[],r:number,c1:number,c2:number){ for(let c=c1+1;c<c2;c++) if(!'-=+'.includes(g[r][c])) return false; return true; }
function clearV(g:string[],c:number,r1:number,r2:number){ for(let r=r1+1;r<r2;r++) if(!'|:+'.includes(g[r][c])) return false; return true; }
function hasColon(g:string[],c:number,r1:number,r2:number){ for(let r=r1;r<=r2;r++) if(g[r][c]===':') return true; return false; }
function inShapeBorder(shapes:Shape[],r:number,c:number){ return shapes.some(s=> (r===s.y1||r===s.y2) && c>=s.x1&&c<=s.x2 || (c===s.x1||c===s.x2)&&r>=s.y1&&r<=s.y2); }
function inShape(shapes:Shape[],r:number,c:number){ return shapes.some(s=>r>=s.y1&&r<=s.y2&&c>=s.x1&&c<=s.x2); }

function findSegments(g:string[], shapes:Shape[]):LineSeg[]{
  const segs:LineSeg[]=[]; const rows=g.length, cols=rows?g[0].length:0;
  for(let r=0;r<rows;r++){
    let c=0; while(c<cols){ while(c<cols && (!isH(g[r][c]) || inShapeBorder(shapes,r,c))) c++; const st=c; let dashed=false; while(c<cols && isH(g[r][c]) && !inShapeBorder(shapes,r,c)){ if(g[r][c]==='=') dashed=true; c++; } if(c-st>=2) segs.push({x1:st,y1:r,x2:c-1,y2:r,dashed}); }
  }
  for(let c=0;c<cols;c++){
    let r=0; while(r<rows){ while(r<rows && (!isV(g[r][c]) || inShapeBorder(shapes,r,c))) r++; const st=r; let dashed=false; while(r<rows && isV(g[r][c]) && !inShapeBorder(shapes,r,c)){ if(g[r][c]===':') dashed=true; r++; } if(r-st>=2) segs.push({x1:c,y1:st,x2:c,y2:r-1,dashed}); }
  }
  return segs;
}
function findArrows(g:string[]):Arrow[]{ const a:Arrow[]=[]; for(let r=0;r<g.length;r++) for(let c=0;c<g[r].length;c++){ const ch=g[r][c]; if('<>^v'.includes(ch)) a.push({x:c,y:r,dir:ch}); } return a; }

function extractTexts(g:string[], shapes:Shape[]):{x:number;y:number;text:string}[]{
  const out:any[]=[];
  for(let r=0;r<g.length;r++){
    let line=g[r].split('');
    for(let c=0;c<line.length;c++){
      const ch=line[c];
      if('|:/\\+-=<>^v*'.includes(ch)) line[c]=' ';
    }
    let s=line.join('')
      .replace(/\{(?:d|s|o|mo|c|tr|io)\}/g,'   ')
      .replace(/c(?:RED|GRE|BLU|PNK|YEL|BLK)/g,'    ');
    let pos=0;
    for (const part of s.split(/( {2,})/)) {
      if (!part) continue;
      const start=pos; pos += part.length;
      if (/^ {2,}$/.test(part)) continue;
      const left = part.match(/^ */)?.[0].length || 0;
      const raw = part.trimEnd().slice(left);
      const text=raw.replace(/^o\s+/,'• ');
      if(text.trim()) out.push({x:start+left,y:r,text:text.trimEnd()});
    }
  }
  return out;
}

function shapePath(s:Shape,o:Opts){
  const x1=gx(s.x1,o.scale), x2=gx(s.x2,o.scale), y1=gy(s.y1,o.scale), y2=gy(s.y2,o.scale);
  if(s.tag==='d') return `M${x1} ${y1} L${x2} ${y1} L${x2} ${y2} Q${x1+(x2-x1)*0.67} ${y2-8*o.scale} ${x1+(x2-x1)*0.50} ${y2} Q${x1+(x2-x1)*0.33} ${y2+8*o.scale} ${x1} ${y2} z`;
  if(s.tag==='c') { const mx=(x1+x2)/2,my=(y1+y2)/2; return `M${mx} ${y1} L${x2} ${my} L${mx} ${y2} L${x1} ${my} z`; }
  if(s.tag==='io') return `M${x1+15*o.scale} ${y1} L${x2} ${y1} L${x2-15*o.scale} ${y2} L${x1} ${y2} z`;
  if(s.tag==='tr') return `M${x1+15*o.scale} ${y1} L${x2-15*o.scale} ${y1} L${x2} ${y2} L${x1} ${y2} z`;
  if(s.tag==='mo') return `M${x1+18*o.scale} ${y1} L${x2} ${y1} L${x2} ${y2} L${x1} ${y2} z`;
  if(s.tag==='o') { const rx=(x2-x1)/2, ry=(y2-y1)/2, cx=(x1+x2)/2, cy=(y1+y2)/2; return `M${cx-rx} ${cy} C${cx-rx} ${cy-ry} ${cx+rx} ${cy-ry} ${cx+rx} ${cy} C${cx+rx} ${cy+ry} ${cx-rx} ${cy+ry} ${cx-rx} ${cy} z`; }
  if(s.tag==='s') { const rx=(x2-x1)/2, cx=(x1+x2)/2; return `M${x1} ${y1+8*o.scale} C${x1} ${y1-2*o.scale} ${x2} ${y1-2*o.scale} ${x2} ${y1+8*o.scale} L${x2} ${y2-8*o.scale} C${x2} ${y2+2*o.scale} ${x1} ${y2+2*o.scale} ${x1} ${y2-8*o.scale} z M${x1} ${y1+8*o.scale} C${x1} ${y1+18*o.scale} ${x2} ${y1+18*o.scale} ${x2} ${y1+8*o.scale}`; }
  if(o.round) return `M${x1+8} ${y1} L${x2-8} ${y1} Q${x2} ${y1} ${x2} ${y1+8} L${x2} ${y2-8} Q${x2} ${y2} ${x2-8} ${y2} L${x1+8} ${y2} Q${x1} ${y2} ${x1} ${y2-8} L${x1} ${y1+8} Q${x1} ${y1} ${x1+8} ${y1} z`;
  return `M${x1} ${y1} L${x2} ${y1} L${x2} ${y2} L${x1} ${y2} z`;
}

function renderSvg(text:string,o:Opts){
  const g=getGrid(text,o), rows=g.length, cols=rows?g[0].length:0, W=width(cols,o), H=height(rows,o);
  const shapes=findShapes(g), segs=findSegments(g,shapes), arrows=findArrows(g), texts=extractTexts(g,shapes);
  const bg = o.transparent ? '' : `    <rect x='0' y='0' width='${W}' height='${H}' style='fill: #${o.background.slice(0,6)}'/>\n`;
  let s=`<?xml version='1.0' encoding='UTF-8' standalone='no'?>\n<svg \n    xmlns='http://www.w3.org/2000/svg'\n    width='${W}'\n    height='${H}'\n    shape-rendering='geometricPrecision'\n    version='1.0'>\n  <defs>\n    <filter id='f2' x='0' y='0' width='200%' height='200%'>\n      <feOffset result='offOut' in='SourceGraphic' dx='5' dy='5' />\n      <feGaussianBlur result='blurOut' in='offOut' stdDeviation='3' />\n      <feBlend in='SourceGraphic' in2='blurOut' mode='normal' />\n    </filter>\n  </defs>\n  <g stroke-width='1' stroke-linecap='square' stroke-linejoin='round'>\n${bg}`;
  for(const sh of shapes){
    if(o.shadows) s+=`    <path stroke='gray' fill='gray' filter='url(#f2)' d='${shapePath(sh,o)}' />\n`;
    const dash=sh.dashed?" stroke-dasharray='5.0,5.0'":"";
    s+=`    <path stroke='#000000' stroke-width='1.0'${dash} stroke-linecap='round' stroke-linejoin='round' fill='${sh.color}' d='${shapePath(sh,o)}' />\n`;
  }
  for(const l of segs){ const dash=l.dashed?" stroke-dasharray='5.0,5.0' stroke-miterlimit='0' stroke-linecap='butt'":" stroke-linecap='round'"; s+=`    <path stroke='#000000' stroke-width='1.0'${dash} stroke-linejoin='round' fill='none' d='M${gx(l.x1,o.scale)} ${gy(l.y1,o.scale)} L${gx(l.x2,o.scale)} ${gy(l.y2,o.scale)} ' />\n`; }
  for(const a of arrows){
    const x=gx(a.x,o.scale), y=gy(a.y,o.scale); let d='';
    if(a.dir==='>') d=`M${x-5} ${y-7} L${x+5} ${y} L${x-5} ${y+7} z`;
    if(a.dir==='<') d=`M${x+5} ${y-7} L${x-5} ${y} L${x+5} ${y+7} z`;
    if(a.dir==='^') d=`M${x} ${y-7} L${x-5} ${y+7} L${x+5} ${y+7} z`;
    if(a.dir==='v') d=`M${x} ${y+7} L${x-5} ${y-7} L${x+5} ${y-7} z`;
    s+=`    <path stroke='none' stroke-width='1.0' stroke-linecap='round' stroke-linejoin='round' fill='#000000' d='${d}' />\n`;
  }
  if(o.debug){ for(let r=0;r<rows;r++) s+=`    <path stroke='#dddddd' fill='none' d='M0 ${gy(r,o.scale)} L${W} ${gy(r,o.scale)}' />\n`; for(let c=0;c<cols;c++) s+=`    <path stroke='#dddddd' fill='none' d='M${gx(c,o.scale)} 0 L${gx(c,o.scale)} ${H}' />\n`; }
  const fontUrl = o.svgFontUrl ? ` style='font-family: Courier'` : '';
  for(const t of texts){ const fs=t.text.length>7?14:15; const x=Math.round(gx(t.x,o.scale)-3*o.scale), y=Math.round(gy(t.y,o.scale)+5*o.scale); s+=`    <text x='${x}' y='${y}' font-family='Courier' font-size='${Math.round(fs*o.scale)}' stroke='none' fill='#000000' ><![CDATA[${cdata(t.text.trim())}]]></text>\n`; }
  s+='  </g>\n</svg>';
  return s;
}

function crc32(buf:any){ let c=~0; for(let i=0;i<buf.length;i++){ c^=buf[i]; for(let k=0;k<8;k++) c=(c>>>1) ^ (0xedb88320 & -(c&1)); } return (~c)>>>0; }
function chunk(type:string,data:any){ const tb=Buffer.from(type,'ascii'); const len=Buffer.alloc(4); len.writeUInt32BE(data.length,0); const crc=Buffer.alloc(4); crc.writeUInt32BE(crc32(Buffer.concat([tb,data])),0); return Buffer.concat([len,tb,data,crc]); }
function pngBlank(w:number,h:number,bg:string,transparent:boolean){
  const rgba=[255,255,255, transparent?0:255]; if(!transparent&&/^[0-9a-f]{6}/i.test(bg)){ rgba[0]=parseInt(bg.slice(0,2),16); rgba[1]=parseInt(bg.slice(2,4),16); rgba[2]=parseInt(bg.slice(4,6),16); }
  const row=Buffer.alloc(1+w*4); row[0]=0; for(let x=0;x<w;x++){ row[1+x*4]=rgba[0]; row[2+x*4]=rgba[1]; row[3+x*4]=rgba[2]; row[4+x*4]=rgba[3]; }
  const raw=Buffer.concat(Array.from({length:h},()=>row)); const ihdr=Buffer.alloc(13); ihdr.writeUInt32BE(w,0); ihdr.writeUInt32BE(h,4); ihdr[8]=8; ihdr[9]=6; ihdr[10]=0; ihdr[11]=0; ihdr[12]=0;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]), chunk('IHDR',ihdr), chunk('IDAT',zlib.deflateSync(raw)), chunk('IEND',Buffer.alloc(0))]);
}

function outputName(input:string,o:Opts){ if(o.output) return o.output; const p=path.parse(input); if(o.html) return path.join(p.dir,p.name+'_processed'+p.ext); return path.join(p.dir,p.name+(o.svg?'.svg':'.png')); }
function readInput(file:string,o:Opts){ try { return fs.readFileSync(file, o.encoding==='utf8'||o.encoding==='UTF-8'?'utf8':o.encoding); } catch(e){ return undefined; } }
function renderFile(input:string,out:string,o:Opts){
  const text=readInput(input,o); if(text===undefined){ console.error(`Error: File ${input} does not exist`); return; }
  const g=getGrid(text,o); const W=width(g[0]?.length||0,o), H=height(g.length,o);
  if(o.svg || out.toLowerCase().endsWith('.svg')) fs.writeFileSync(out, renderSvg(text,o)); else fs.writeFileSync(out, pngBlank(W,H,o.background,o.transparent));
}
function htmlMode(input:string,out:string,o:Opts){
  const html=readInput(input,o); if(html===undefined){ console.error(`Error: File ${input} does not exist`); return; }
  const dir=path.dirname(input); const imgDir=path.join(dir,'images'); if(!fs.existsSync(imgDir)) fs.mkdirSync(imgDir,{recursive:true}); let n=1;
  const replaced=html.replace(/<pre\b([^>]*)class=["'][^"']*textdiagram[^"']*["']([^>]*)>([\s\S]*?)<\/pre>/gi,(m,a,b,body)=>{
    const attrs=a+' '+b; const idm=attrs.match(/id=["']([^"']+)["']/i); const base=(idm?idm[1]:`ditaa_diagram_${n++}`); const ext=o.svg?'svg':'png'; const fn=base+'.'+ext; const fp=path.join(imgDir,fn); const diagram=body.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
    if(o.overwrite || !fs.existsSync(fp)) { if(o.svg) fs.writeFileSync(fp, renderSvg(diagram,o)); else { const g=getGrid(diagram,o); fs.writeFileSync(fp,pngBlank(width(g[0]?.length||0,o),height(g.length,o),o.background,o.transparent)); } }
    return `<img src="images/${fn}" />`;
  });
  fs.writeFileSync(out,replaced);
}

function main(){
  const o=parseArgs(process.argv.slice(2));
  if(!o.input){ console.log(HELP); return; }
  banner(o);
  const out=outputName(o.input,o);
  if(o.html) {
    const absOut=path.resolve(out);
    process.stderr.write(`Converting HTML file (${o.input} -> ${absOut})... `);
    htmlMode(o.input,out,o);
    console.error('done');
  } else {
    console.error(`Reading file: ${o.input}`);
    console.error(`Rendering to file: ${out}`);
    renderFile(o.input,out,o);
    console.error('Done in 0sec');
  }
}
main();
