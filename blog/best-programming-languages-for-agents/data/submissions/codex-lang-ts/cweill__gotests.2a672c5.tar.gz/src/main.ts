import * as fs from "fs";
import * as path from "path";

type Param = { name: string; type: string; variadic?: boolean };
type Result = { name: string; type: string; raw: string };
type Fn = {
  name: string;
  receiverName?: string;
  receiverType?: string;
  receiverBase?: string;
  receiverPointer?: boolean;
  typeParams: Map<string, string>;
  callTypeParams: Map<string, string>;
  params: Param[];
  results: Result[];
};

type Opts = {
  all: boolean; exported: boolean; only?: string; excl?: string; write: boolean;
  named: boolean; nosubtests: boolean; parallel: boolean; inputs: boolean;
  useGoCmp: boolean; version: boolean; template?: string; templateDir?: string;
};

const versionText = `gotests v0.0.0-20260303205902-f3b63d74369a
Go version: go1.24.5
Git commit: f3b63d74369a8c405a9a3990a656a278a4f9096f
Build time: 2026-03-03T20:59:02Z`;

function usage(): string {
  return `Usage of ./executable:
  -ai
\tgenerate test cases using AI (requires Ollama)
  -ai-endpoint string
\tOllama API endpoint (default "http://localhost:11434")
  -ai-max-cases int
\tmaximum number of test cases to generate with AI (default 10)
  -ai-min-cases int
\tminimum number of test cases to generate with AI (default 3)
  -ai-model string
\tAI model to use for test generation (default "qwen2.5-coder:0.5b")
  -all
\tgenerate tests for all functions and methods
  -excl string
\tregexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all
  -exported
\tgenerate tests for exported functions and methods. Takes precedence over -only and -all
  -i\tprint test inputs in error messages
  -named
\tswitch table tests from using slice to map (with test name for the key)
  -nosubtests
\tdisable generating tests using the Go 1.7 subtests feature
  -only string
\tregexp. generate tests for functions and methods that match only. Takes precedence over -all
  -parallel
\tenable generating parallel subtests using the Go 1.7 feature
  -template string
\toptional. Specify custom test code templates, e.g. testify. This can also be set via environment variable GOTESTS_TEMPLATE
  -template_dir string
\toptional. Path to a directory containing custom test code templates. Takes precedence over -template. This can also be set via environment variable GOTESTS_TEMPLATE_DIR
  -template_params string
\tread external parameters to template by json with stdin
  -template_params_file string
\tread external parameters to template by json with file
  -use_go_cmp
\tuse cmp.Equal (google/go-cmp) instead of reflect.DeepEqual
  -version
\tprint version information and exit
  -w\twrite output to (test) files instead of stdout`;
}

function parseArgs(argv: string[]): { opts: Opts; paths: string[] } {
  const opts: Opts = { all: false, exported: false, write: false, named: false, nosubtests: false, parallel: false, inputs: false, useGoCmp: false, version: false };
  const paths: string[] = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const need = () => argv[++i] ?? "";
    if (a === "--help" || a === "-h") { console.log(usage()); process.exit(0); }
    else if (a === "-version") opts.version = true;
    else if (a === "-all") opts.all = true;
    else if (a === "-exported") opts.exported = true;
    else if (a === "-w") opts.write = true;
    else if (a === "-named") opts.named = true;
    else if (a === "-nosubtests") opts.nosubtests = true;
    else if (a === "-parallel") opts.parallel = true;
    else if (a === "-i") opts.inputs = true;
    else if (a === "-use_go_cmp") opts.useGoCmp = true;
    else if (a === "-only") opts.only = need();
    else if (a === "-excl") opts.excl = need();
    else if (a === "-template" || a === "-ai-model" || a === "-ai-endpoint" || a === "-ai-min-cases" || a === "-ai-max-cases" || a === "-template_dir" || a === "-template_params" || a === "-template_params_file") need();
    else if (a === "-ai") { /* ignored */ }
    else if (a.startsWith("-")) { console.error(`flag provided but not defined: ${a}`); console.error(usage()); process.exit(2); }
    else paths.push(a);
  }
  return { opts, paths };
}

function stripComments(s: string): string {
  return s.replace(/\/\*[\s\S]*?\*\//g, m => " ".repeat(m.length)).replace(/\/\/.*$/gm, "");
}

function splitTop(s: string, sep = ","): string[] {
  const out: string[] = [];
  let cur = "", depth = 0;
  for (const ch of s) {
    if ("([{".includes(ch)) depth++;
    if (")] }".includes(ch)) depth = Math.max(0, depth - 1);
    if (ch === sep && depth === 0) { if (cur.trim()) out.push(cur.trim()); cur = ""; }
    else cur += ch;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function concrete(t: string, typeParams: Map<string, string>): string {
  let out = t.trim();
  for (const [name, con] of typeParams.entries()) {
    const repl = con === "comparable" ? "string" : con === "any" ? "int" : con.replace(/^~/, "").split("|")[0].trim() || "int";
    out = out.replace(new RegExp(`\\b${name}\\b`, "g"), repl);
  }
  return out;
}

function parseTypeParams(raw: string | undefined): Map<string, string> {
  const map = new Map<string, string>();
  if (!raw) return map;
  for (const part of splitTop(raw.slice(1, -1))) {
    const bits = part.trim().split(/\s+/);
    if (bits.length >= 2) map.set(bits[0], bits.slice(1).join(" "));
  }
  return map;
}

function parseParams(raw: string, typeParams: Map<string, string>): Param[] {
  const res: Param[] = [];
  let pending: string[] = [];
  const parts = splitTop(raw);
  for (let idx = 0; idx < parts.length; idx++) {
    const p = parts[idx];
    const words = p.trim().split(/\s+/);
    if (!p.trim()) continue;
    const nextHasType = idx + 1 < parts.length && parts[idx + 1].trim().split(/\s+/).length >= 2;
    if (words.length === 1 && /^[A-Za-z_]\w*$/.test(words[0]) && nextHasType && !/^(int|int8|int16|int32|int64|uint|uint8|uint16|uint32|uint64|uintptr|string|bool|byte|rune|float32|float64|complex64|complex128|error|any)$/.test(words[0])) {
      pending.push(words[0]);
    } else if (words.length === 1 || /^[*\[\]<~]|^map\[|^chan\b|^func\(/.test(words[0])) {
      const typ0 = concrete(p.replace(/^\.\.\./, "[]"), typeParams);
      const names = pending.length ? pending.splice(0) : [`arg${res.length}`];
      for (const n of names) res.push({ name: n, type: typ0 });
    } else {
      const typeRaw = words.slice(-1)[0];
      const names = pending.splice(0).concat(words.slice(0, -1).join(" ").split(/\s*,\s*/).filter(Boolean));
      const variadic = typeRaw.startsWith("...");
      const typ = concrete(variadic ? "[]" + typeRaw.slice(3) : typeRaw, typeParams);
      for (const n of names) res.push({ name: n, type: typ, variadic });
    }
  }
  return res;
}

function parseResults(raw: string, typeParams: Map<string, string>): Result[] {
  raw = raw.trim();
  if (!raw) return [];
  if (raw.startsWith("(") && raw.endsWith(")")) raw = raw.slice(1, -1);
  const out: Result[] = [];
  for (const part of splitTop(raw)) {
    const words = part.trim().split(/\s+/);
    if (words.length >= 2 && /^[A-Za-z_]\w*$/.test(words[0])) {
      const rt = words.slice(1).join(" ");
      out.push({ name: words[0], type: concrete(rt, typeParams), raw: rt });
    } else out.push({ name: "", type: concrete(part.trim(), typeParams), raw: part.trim() });
  }
  return out;
}

function parseReceiver(raw: string | undefined, typeParams: Map<string, string>): Partial<Fn> {
  if (!raw) return {};
  const parts = raw.trim().split(/\s+/);
  const name = parts.length > 1 ? parts[0] : "r";
  let typ = parts.length > 1 ? parts.slice(1).join(" ") : parts[0];
  const pointer = typ.startsWith("*");
  typ = concrete(typ, typeParams);
  const baseMatch = typ.replace(/^\*/, "").match(/^([A-Za-z_]\w*)/);
  return { receiverName: name, receiverType: typ, receiverBase: baseMatch ? baseMatch[1] : typ.replace(/^\*/, ""), receiverPointer: pointer };
}

function parseFile(text: string): { pkg: string; imports: string[]; funcs: Fn[] } {
  const pkg = (text.match(/^\s*package\s+([A-Za-z_]\w*)/m) || [])[1] || "main";
  const imports: string[] = [];
  const impBlock = text.match(/import\s*\(([\s\S]*?)\)/m);
  if (impBlock) for (const m of impBlock[1].matchAll(/"([^"]+)"/g)) imports.push(m[1]);
  for (const m of text.matchAll(/import\s+(?:(?:[._A-Za-z]\w*)\s+)?"([^"]+)"/g)) imports.push(m[1]);
  const clean = stripComments(text);
  const typeDecls = new Map<string, Map<string, string>>();
  for (const m of clean.matchAll(/type\s+([A-Za-z_]\w*)\s*(\[[^\]]+\])/g)) typeDecls.set(m[1], parseTypeParams(m[2]));
  const funcs: Fn[] = [];
  const re = /func\s+(?:\(([^)]*)\)\s*)?([A-Za-z_]\w*)(\[[^\]]+\])?\s*\(([^)]*)\)\s*([^{\n]*(?:\([^{}]*\))?)\s*\{/g;
  for (const m of clean.matchAll(re)) {
    let typeParams = parseTypeParams(m[3]);
    const callTypeParams = new Map(typeParams);
    if (m[1]) {
      const bm = m[1].match(/\*?\s*([A-Za-z_]\w*)\s*\[/);
      if (bm && typeDecls.has(bm[1])) typeParams = new Map([...typeParams, ...typeDecls.get(bm[1])!.entries()]);
    }
    const fn: Fn = { name: m[2], typeParams, callTypeParams, params: parseParams(m[4], typeParams), results: parseResults((m[5] || "").trim(), typeParams) };
    Object.assign(fn, parseReceiver(m[1], typeParams));
    funcs.push(fn);
  }
  return { pkg, imports: Array.from(new Set(imports)), funcs };
}

const isExported = (s: string) => /^[A-Z]/.test(s);
const deepTypeName = (t: string) => /^(?:\[\]|\*|map\[|interface\b|func\b|chan\b)/.test(t) || /^[A-Z]\w*(?:\[|$)/.test(t);
const deepResult = (fn: Fn, r: Result) => deepTypeName(r.type) || fn.typeParams.has(r.raw);
const isErr = (r: Result) => r.type === "error";

function wantName(r: Result, idx: number, nonErrIdx: number): string {
  if (isErr(r)) return "wantErr";
  if (r.name) return "want" + r.name[0].toUpperCase() + r.name.slice(1);
  return nonErrIdx === 0 ? "want" : `want${nonErrIdx}`;
}

function align(fields: { name: string; type: string }[]): string[] {
  const w = fields.reduce((n, f) => Math.max(n, f.name.length), 0);
  return fields.map(f => `\t\t${f.name}${" ".repeat(Math.max(1, w - f.name.length + 1))}${f.type}`);
}

function callName(fn: Fn): string {
  let s = fn.name;
  if (fn.callTypeParams.size) s += `[${Array.from(fn.callTypeParams.values()).map(v => v === "comparable" ? "string" : v === "any" ? "int" : v.replace(/^~/, "").split("|")[0].trim() || "int").join(", ")}]`;
  return s;
}

function genFunction(fn: Fn, opts: Opts): string {
  const lines: string[] = [];
  const testName = testNameFor(fn);
  lines.push(`func ${testName}(t *testing.T) {`);
  if (opts.parallel) lines.push("\tt.Parallel()");
  if (fn.params.length) {
    lines.push("\ttype args struct {");
    lines.push(...align(fn.params.map(p => ({ name: p.name, type: p.type }))));
    lines.push("\t}");
  }
  const fields: { name: string; type: string }[] = [];
  if (!opts.named) fields.push({ name: "name", type: "string" });
  if (fn.receiverBase) fields.push({ name: fn.receiverName || "r", type: fn.receiverType || fn.receiverBase });
  if (fn.params.length) fields.push({ name: "args", type: "args" });
  let nonErr = 0;
  for (const r of fn.results) {
    fields.push({ name: wantName(r, fields.length, nonErr), type: isErr(r) ? "bool" : r.type });
    if (!isErr(r)) nonErr++;
  }
  lines.push(opts.named ? "\ttests := map[string]struct {" : "\ttests := []struct {");
  lines.push(...align(fields));
  lines.push("\t}{");
  lines.push("\t\t// TODO: Add test cases.");
  lines.push("\t}");
  const loop = opts.named ? "for name, tt := range tests {" : "for _, tt := range tests {";
  lines.push(`\t${loop}`);
  const body = genBody(fn, opts);
  if (opts.nosubtests) {
    lines.push(...body.map(l => "\t\t" + l));
  } else {
    lines.push(opts.named ? "\t\tt.Run(name, func(t *testing.T) {" : "\t\tt.Run(tt.name, func(t *testing.T) {");
    if (opts.parallel) lines.push("\t\t\tt.Parallel()");
    lines.push(...body.map(l => "\t\t\t" + l));
    lines.push("\t\t})");
  }
  lines.push("\t}");
  lines.push("}");
  return lines.join("\n");
}

function genBody(fn: Fn, opts: Opts): string[] {
  const lines: string[] = [];
  if (fn.receiverBase) {
    const typ = fn.receiverType || fn.receiverBase;
    const val = typ.startsWith("*") ? `&${typ.slice(1)}{}` : `${typ}{}`;
    lines.push(`${fn.receiverName || "r"} := ${val}`);
  }
  const args = fn.params.map(p => `tt.args.${p.name}${p.variadic ? "..." : ""}`).join(", ");
  const callee = fn.receiverBase ? `${fn.receiverName || "r"}.${callName(fn)}` : callName(fn);
  const call = `${callee}(${args})`;
  const errs = fn.results.map((r, i) => ({ r, i })).filter(x => isErr(x.r));
  const values: string[] = [];
  let nonErrValue = 0;
  for (const r of fn.results) {
    if (isErr(r)) values.push("err");
    else if (r.name) values.push("got" + r.name[0].toUpperCase() + r.name.slice(1));
    else values.push(nonErrValue === 0 ? "got" : `got${nonErrValue}`);
    if (!isErr(r)) nonErrValue++;
  }
  if (fn.results.length === 0) { lines.push(call); return lines; }
  if (fn.results.length === 1 && isErr(fn.results[0])) {
    lines.push(`if err := ${call}; (err != nil) != tt.wantErr {`);
    lines.push(`\tt.Errorf(${errMsg(fn, opts, `error = %v, wantErr %v`)}, ${errArgs(opts)}err, tt.wantErr)`);
    lines.push("}");
    return lines;
  }
  if (fn.results.length === 1) {
    const cmp = compareExpr(fn, fn.results[0], "got", "tt.want", opts);
    lines.push(`if got := ${call}; ${cmp.cond} {`);
    lines.push(`\tt.Errorf(${cmp.msg}, ${cmp.args})`);
    lines.push("}");
    return lines;
  }
  lines.push(`${values.join(", ")} := ${call}`);
  if (errs.length) {
    lines.push("if (err != nil) != tt.wantErr {");
    lines.push(`\t${opts.nosubtests ? "t.Errorf" : "t.Fatalf"}(${errMsg(fn, opts, `error = %v, wantErr %v`)}, ${errArgs(opts)}err, tt.wantErr)`);
    if (opts.nosubtests) lines.push("\tcontinue");
    lines.push("}");
    lines.push("if tt.wantErr {");
    lines.push("\treturn");
    lines.push("}");
  }
  let nonErr = 0;
  for (let i = 0; i < fn.results.length; i++) {
    const r = fn.results[i];
    if (isErr(r)) continue;
    const wn = wantName(r, i, nonErr);
    const got = values[i];
    const cmp = compareExpr(fn, r, got, `tt.${wn}`, opts, fn.results.filter(x => !isErr(x)).length > 1 ? got : undefined);
    lines.push(`if ${cmp.cond} {`);
    lines.push(`\tt.Errorf(${cmp.msg}, ${cmp.args})`);
    lines.push("}");
    nonErr++;
  }
  return lines;
}

function errMsg(fn: Fn, opts: Opts, tail: string): string {
  const prefix = opts.nosubtests ? `"%q. ${display(fn)}() ${tail}"` : `"${display(fn)}() ${tail}"`;
  return prefix;
}

function errArgs(opts: Opts): string {
  return opts.nosubtests ? "tt.name, " : "";
}

function display(fn: Fn): string {
  if (!fn.receiverBase) return fn.name;
  const gen = fn.typeParams.size ? "[T]" : "";
  return `${fn.receiverBase}${gen}.${fn.name}`;
}

function compareExpr(fn: Fn, r: Result, got: string, want: string, opts: Opts, label?: string): { cond: string; msg: string; args: string } {
  const name = display(fn);
  const lbl = label ? ` ${label}` : "";
  const input = opts.inputs ? `, input = %v` : "";
  const base = opts.nosubtests ? `%q. ${name}()${lbl}${input} = %v, want %v` : `${name}()${lbl}${input} = %v, want %v`;
  const pfxArgs = opts.nosubtests ? "tt.name, " : "";
  const inputArgs = opts.inputs ? "tt.args, " : "";
  if (opts.useGoCmp && deepResult(fn, r)) return { cond: `!cmp.Equal(${want}, ${got})`, msg: `"${base}\\ndiff=%s"`, args: `${pfxArgs}${inputArgs}${got}, ${want}, cmp.Diff(${want}, ${got})` };
  if (deepResult(fn, r)) return { cond: `!reflect.DeepEqual(${got}, ${want})`, msg: `"${base}"`, args: `${pfxArgs}${inputArgs}${got}, ${want}` };
  return { cond: `${got} != ${want}`, msg: `"${base}"`, args: `${pfxArgs}${inputArgs}${got}, ${want}` };
}

function generate(parsed: { pkg: string; imports: string[]; funcs: Fn[] }, opts: Opts): string {
  let funcs = parsed.funcs.filter(fn => {
    const full = fn.receiverBase ? `${fn.receiverBase}.${fn.name}` : fn.name;
    if (opts.excl) return !new RegExp(opts.excl).test(full) && !new RegExp(opts.excl).test(fn.name);
    if (opts.exported) return isExported(fn.name);
    if (opts.only) return new RegExp(opts.only).test(full) || new RegExp(opts.only).test(fn.name);
    return opts.all;
  });
  const usesDeep = funcs.some(fn => fn.results.some(r => !isErr(r) && deepResult(fn, r)));
  const imports = new Set(parsed.imports);
  if (usesDeep && !opts.useGoCmp) imports.add("reflect");
  imports.add("testing");
  if (usesDeep && opts.useGoCmp) imports.add("github.com/google/go-cmp/cmp");
  const out: string[] = [`package ${parsed.pkg}`, ""];
  const imps = Array.from(imports);
  if (imps.length === 1) out.push(`import "${imps[0]}"`, "");
  else if (imps.length) {
    out.push("import (");
    for (const imp of imps) {
      if (imp === "github.com/google/go-cmp/cmp" && imps.length > 1) out.push("");
      out.push(`\t"${imp}"`);
    }
    out.push(")", "");
  }
  out.push(...funcs.map(f => genFunction(f, opts)).join("\n\n").split("\n"));
  return out.join("\n") + "\n";
}

function testNameFor(fn: Fn): string {
  if (fn.receiverBase) return `Test${fn.receiverBase}_${fn.name}`;
  return isExported(fn.name) ? `Test${fn.name}` : `Test_${fn.name}`;
}

function collect(pathsIn: string[]): string[] {
  const files: string[] = [];
  const walk = (d: string) => {
    for (const ent of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, ent.name);
      if (ent.isDirectory()) walk(p);
      else if (ent.isFile() && ent.name.endsWith(".go") && !ent.name.endsWith("_test.go")) files.push(p);
    }
  };
  for (const p0 of pathsIn) {
    if (p0.endsWith("/...")) walk(p0.slice(0, -4) || ".");
    else if (fs.existsSync(p0) && fs.statSync(p0).isDirectory()) {
      for (const ent of fs.readdirSync(p0)) if (ent.endsWith(".go") && !ent.endsWith("_test.go")) files.push(path.join(p0, ent));
    } else files.push(p0);
  }
  return files;
}

function main() {
  const { opts, paths } = parseArgs(process.argv.slice(2));
  if (opts.version) { console.log(versionText); return; }
  if (!opts.all && !opts.exported && !opts.only && !opts.excl) { console.log("Please specify either the -only, -excl, -exported, or -all flag"); return; }
  if (paths.length === 0) { console.log("Please specify a path"); return; }
  for (const file of collect(paths)) {
    const parsed = parseFile(fs.readFileSync(file, "utf8"));
    const code = generate(parsed, opts);
    for (const fn of parsed.funcs) {
      const name = testNameFor(fn);
      const full = fn.receiverBase ? `${fn.receiverBase}.${fn.name}` : fn.name;
      const selected = opts.excl ? !(new RegExp(opts.excl).test(full) || new RegExp(opts.excl).test(fn.name)) : opts.exported ? isExported(fn.name) : opts.only ? (new RegExp(opts.only).test(full) || new RegExp(opts.only).test(fn.name)) : opts.all;
      if (selected) console.log(`Generated ${name}`);
    }
    if (opts.write) {
      const target = file.replace(/\.go$/, "_test.go");
      fs.writeFileSync(target, code);
    } else process.stdout.write(code);
  }
}

main();
