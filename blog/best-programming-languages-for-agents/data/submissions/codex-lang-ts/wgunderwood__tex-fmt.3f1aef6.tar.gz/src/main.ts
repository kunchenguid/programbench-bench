import * as fs from 'fs';
import * as path from 'path';
import { execSync } from 'child_process';

type Verbosity = 'trace'|'info'|'warn'|'error';
interface Config {
  check:boolean; print:boolean; failOnChange:boolean; recursive:boolean;
  wrap:boolean; wraplen:number; wrapmin:number; tabsize:number; tabchar:'space'|'tab'; stdin:boolean;
  config?:string; noconfig:boolean; verbosity:Verbosity;
  lists:string[]; verbatims:string[]; noIndentEnvs:string[]; wrapChars:string[]; files:string[];
}
const defaultCfg = ():Config => ({check:false,print:false,failOnChange:false,recursive:false,wrap:true,wraplen:80,wrapmin:70,tabsize:2,tabchar:'space',stdin:false,noconfig:false,verbosity:'warn',lists:['itemize','enumerate','description','inlineroman','inventory'],verbatims:['verbatim','Verbatim','lstlisting','minted','comment'],noIndentEnvs:['document'],wrapChars:[],files:[]});

const HELP = `tex-fmt 0.5.6\n\nLaTeX formatter written in Rust\n\nUsage: executable [OPTIONS] [files]...\n\nArguments:\n  [files]...  List of files to be formatted\n\nOptions:\n  -c, --check               Check formatting, do not modify files\n  -p, --print               Print to stdout, do not modify files\n  -f, --fail-on-change      Format files and return non-zero exit code if files are modified\n  -n, --nowrap              Do not wrap long lines\n  -l, --wraplen <N>         Line length for wrapping [default: 80]\n  -t, --tabsize <N>         Number of characters to use as tab size [default: 2]\n      --usetabs             Use tabs instead of spaces for indentation\n  -s, --stdin               Process stdin as a single file, output to stdout\n      --config <PATH>       Path to config file\n      --noconfig            Do not read any config file\n  -v, --verbose             Show info messages\n  -q, --quiet               Hide warning messages\n      --trace               Show trace messages\n      --completion <SHELL>  Generate shell completion script [possible values: bash, elvish, fish, powershell, zsh]\n      --man                 Generate man page\n      --args                Print arguments passed to tex-fmt and exit\n  -r, --recursive           Recursively search for files to format\n  -h, --help                Print help\n  -V, --version             Print version`;
const MAN = `.ie \\n(.g .ds Aq \\(aq\n.el .ds Aq '\n.TH tex-fmt 1  "tex-fmt 0.5.6" \n.SH NAME\ntex\\-fmt \\- LaTeX formatter written in Rust\n.SH SYNOPSIS\n\\fBtex\\-fmt\\fR [OPTIONS] [\\fIfiles\\fR] \n.SH DESCRIPTION\nLaTeX formatter written in Rust\n.SH VERSION\nv0.5.6\n.SH AUTHORS\nWilliam George Underwood, wg.underwood13@gmail.com`;

function dieCli(msg:string):never { console.error(msg); process.exit(2); throw new Error(msg); }
function error(file:string,msg:string){ console.error(`ERROR: tex-fmt ${file}: ${msg}. `); }
function needVal(args:string[], i:number, opt:string):string { if(i+1>=args.length) dieCli(`error: a value is required for '${opt} <N>' but none was supplied\n\nFor more information, try '--help'.`); return args[i+1]; }
function parseNum(s:string,opt:string):number { if(!/^\d+$/.test(s)) dieCli(`error: invalid value '${s}' for '${opt} <N>': invalid digit found in string\n\nFor more information, try '--help'.`); return parseInt(s,10); }

function parseArgs(argv:string[]):Config&{completion?:string, man?:boolean, argsFlag?:boolean, help?:boolean, version?:boolean} {
  const c:any = defaultCfg(); const cliSet = new Set<string>();
  for(let i=0;i<argv.length;i++){
    const a=argv[i];
    if(a==='--'){ c.files.push(...argv.slice(i+1)); break; }
    if(a==='-c'||a==='--check'){c.check=true; cliSet.add('check');}
    else if(a==='-p'||a==='--print'){c.print=true; cliSet.add('print');}
    else if(a==='-f'||a==='--fail-on-change'){c.failOnChange=true; cliSet.add('failOnChange');}
    else if(a==='-r'||a==='--recursive'){c.recursive=true;}
    else if(a==='-n'||a==='--nowrap'){c.wrap=false; cliSet.add('wrap');}
    else if(a==='-s'||a==='--stdin'){c.stdin=true; cliSet.add('stdin');}
    else if(a==='--usetabs'){c.tabchar='tab'; cliSet.add('tabchar');}
    else if(a==='-v'||a==='--verbose'){c.verbosity='info'; cliSet.add('verbosity');}
    else if(a==='-q'||a==='--quiet'){c.verbosity='error'; cliSet.add('verbosity');}
    else if(a==='--trace'){c.verbosity='trace'; cliSet.add('verbosity');}
    else if(a==='--noconfig'){c.noconfig=true;}
    else if(a==='-h'||a==='--help'){c.help=true;}
    else if(a==='-V'||a==='--version'){c.version=true;}
    else if(a==='--args'){c.argsFlag=true;}
    else if(a==='--man'){c.man=true;}
    else if(a==='--completion'){ const v=needVal(argv,i,a); i++; if(!['bash','elvish','fish','powershell','zsh'].includes(v)) dieCli(`error: invalid value '${v}' for '--completion <SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\n  tip: a similar value exists: 'bash'\n\nFor more information, try '--help'.`); c.completion=v; }
    else if(a==='--config'){ c.config=needVal(argv,i,a); i++; }
    else if(a==='-l'||a==='--wraplen'){ c.wraplen=parseNum(needVal(argv,i,a), '--wraplen'); c.wrapmin=Math.max(0,c.wraplen-10); cliSet.add('wraplen'); i++; }
    else if(a==='-t'||a==='--tabsize'){ c.tabsize=parseNum(needVal(argv,i,a), '--tabsize'); cliSet.add('tabsize'); i++; }
    else if(a.startsWith('-')) dieCli(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [files]...\n\nFor more information, try '--help'.`);
    else c.files.push(a);
  }
  const before = {...c, files:[...c.files]};
  if(!c.noconfig && !c.help && !c.version && !c.man && !c.completion) applyConfig(c, cliSet, before.config);
  return c;
}

function findConfig(explicit?:string):string|undefined{
  if(explicit) return explicit;
  const cwd=process.cwd(); const local=path.join(cwd,'tex-fmt.toml'); if(fs.existsSync(local)) return local;
  try { const root=execSync('git rev-parse --show-toplevel',{stdio:['ignore','pipe','ignore'],encoding:'utf8'}).trim(); const f=path.join(root,'tex-fmt.toml'); if(fs.existsSync(f)) return f; } catch {}
  const home=process.env.HOME; if(home){ const f=path.join(home,'.config','tex-fmt','tex-fmt.toml'); if(fs.existsSync(f)) return f; }
  return undefined;
}
function parseArray(v:string):string[]{ const m=v.match(/^\[(.*)\]$/s); if(!m) return []; const out:string[]=[]; const re=/"([^"]*)"|'([^']*)'/g; let mm; while((mm=re.exec(m[1]))) out.push(mm[1]??mm[2]); return out; }
function applyConfig(c:Config, cliSet:Set<string>, explicit?:string){ const f=findConfig(explicit); if(!f) return; c.config=f; let txt=''; try{txt=fs.readFileSync(f,'utf8');}catch{return;} for(const raw of txt.split(/\r?\n/)){ const line=raw.replace(/#.*$/,'').trim(); if(!line.includes('=')) continue; const [k0,...rest]=line.split('='); const k=k0.trim(); const v=rest.join('=').trim(); const bool=v==='true'; const num=parseInt(v,10); const str=(v.match(/^"(.*)"$/)||v.match(/^'(.*)'$/))?.[1];
    const set=(key:keyof Config,val:any)=>{ if(!cliSet.has(key as string)) (c as any)[key]=val; };
    if(k==='check') set('check',bool); else if(k==='print') set('print',bool); else if(k==='fail-on-change') set('failOnChange',bool); else if(k==='wrap') set('wrap',bool); else if(k==='wraplen'&&!isNaN(num)){set('wraplen',num); if(!cliSet.has('wraplen')) c.wrapmin=Math.max(0,num-10);} else if(k==='wrapmin'&&!isNaN(num)) set('wrapmin',num); else if(k==='tabsize'&&!isNaN(num)) set('tabsize',num); else if(k==='tabchar'&&(str==='space'||str==='tab')) set('tabchar',str); else if(k==='stdin') set('stdin',bool); else if(k==='lists') c.lists=[...defaultCfg().lists,...parseArray(v)]; else if(k==='verbatims') c.verbatims=[...defaultCfg().verbatims,...parseArray(v)]; else if(k==='no-indent-envs') c.noIndentEnvs=[...parseArray(v), ...defaultCfg().noIndentEnvs.filter(x=>!parseArray(v).includes(x))]; else if(k==='wrap-chars') c.wrapChars=parseArray(v); else if(k==='verbosity'&&str) set('verbosity',str as any);
  }}

function stripComment(s:string):string { let esc=false; for(let i=0;i<s.length;i++){ const ch=s[i]; if(ch==='%'&&!esc) return s.slice(0,i); esc=ch==='\\'&&!esc; if(ch!=='\\') esc=false; } return s; }
function leadingClose(s:string):boolean { return /^(\\end\b|\\\]|\\\)|\}|\]|\)|\\right\b)/.test(s); }
function lineOpens(s:string,c:Config):number { const code=stripComment(s); let n=0; const env=code.match(/\\begin\s*\{([^}]+)\}/); if(env && !c.noIndentEnvs.includes(env[1])) n++; if(/^\\\[$/.test(code.trim())||/^\\\($/.test(code.trim())) n++; const opens=(code.match(/[\{\[\(]/g)||[]).length; const closes=(code.match(/[\}\]\)]/g)||[]).length; n += Math.max(0, opens-closes); return n; }
function lineCloses(s:string,c:Config):number { const code=stripComment(s).trim(); const env=code.match(/^\\end\s*\{([^}]+)\}/); if(env) return c.noIndentEnvs.includes(env[1]) ? 0 : 1; if(/^\\\]$/.test(code)||/^\\\)$/.test(code)) return 1; if(/^(\}|\]|\)|\\right\b)/.test(code)) return 1; return 0; }
function isVerbatimBegin(t:string,c:Config):string|undefined { const m=t.match(/^\\begin\s*\{([^}]+)\}/); return m&&c.verbatims.includes(m[1])?m[1]:undefined; }
function isVerbatimEnd(t:string,env:string):boolean { return new RegExp('^\\\\end\\s*\\{'+env.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\}').test(t); }
function indentUnit(c:Config):string { return c.tabchar==='tab' ? '\t'.repeat(c.tabsize) : ' '.repeat(c.tabsize); }
function wrapLine(line:string, c:Config, baseIndent:string):string[]{
  if(!c.wrap || line.length<=c.wraplen || /^\s*%/.test(line) || /^\s*\\(begin|end)\b/.test(line)) return [line];
  const indent=line.match(/^\s*/)?.[0]||''; const content=line.trim(); if(content.length===0) return [line];
  const out:string[]=[]; let cur=content; const contIndent=indent||baseIndent;
  const target=Math.max(10,c.wrapmin-indent.length); const hard=Math.max(target,c.wraplen-indent.length);
  while((indent+cur).length>c.wraplen){
    const words=cur.split(/\s+/); let acc=''; let used=0;
    while(used<words.length){ const cand=acc?acc+' '+words[used]:words[used]; if(cand.length>=target && acc) break; if(cand.length>hard && acc) break; acc=cand; used++; if(cand.length>=target) break; }
    if(!acc || used===0 || used>=words.length) break;
    out.push(indent+acc); cur=words.slice(used).join(' ');
  }
  out.push(contIndent+cur); return out;
}

function format(input:string,c:Config):string{
  const hadFinal=input.endsWith('\n'); const lines=input.replace(/\r\n/g,'\n').replace(/\r/g,'\n').split('\n'); if(hadFinal) lines.pop();
  let level=0; let inVerb:string|undefined; let off=false; let listStack:number[]=[]; let inItem=false; const unit=indentUnit(c); const out:string[]=[];
  for(const raw of lines){ const trimmed=raw.trim();
    if(off){ out.push(raw); if(trimmed.includes('% tex-fmt: on')) off=false; continue; }
    if(trimmed.includes('% tex-fmt: off')){ out.push(trimmed); off=true; continue; }
    if(trimmed.includes('% tex-fmt: skip')){ out.push(raw); continue; }
    if(inVerb){ out.push(raw); if(isVerbatimEnd(trimmed,inVerb)) inVerb=undefined; continue; }
    if(trimmed===''){ out.push(''); continue; }
    const vb=isVerbatimBegin(trimmed,c); const envBegin=trimmed.match(/^\\begin\s*\{([^}]+)\}/); const envEnd=trimmed.match(/^\\end\s*\{([^}]+)\}/);
    if(envEnd && c.lists.includes(envEnd[1])) { listStack.pop(); inItem=false; }
    let eff=Math.max(0,level-lineCloses(trimmed,c));
    let itemLine=/^\\item(\b|\[)/.test(trimmed);
    if(itemLine) inItem=true;
    let extra = (inItem && !itemLine && listStack.length>0) ? 1 : 0;
    const formatted = unit.repeat(eff+extra)+trimmed;
    for(const wl of wrapLine(formatted,c,unit.repeat(eff+extra))) out.push(wl);
    if(vb) inVerb=vb;
    if(envBegin && c.lists.includes(envBegin[1])) { listStack.push(eff); inItem=false; }
    level=Math.max(0,eff+lineOpens(trimmed,c));
  }
  return out.join('\n')+(hadFinal?'\n':'');
}

function argsDump(c:Config){ const pad=(s:string)=>s.padEnd(24,' '); console.log('tex-fmt'); console.log(`  ${pad('check:')} ${c.check}`); console.log(`  ${pad('print:')} ${c.print}`); console.log(`  ${pad('fail-on-change:')} ${c.failOnChange}`); console.log(`  ${pad('wrap:')} ${c.wrap}`); console.log(`  ${pad('wraplen:')} ${c.wraplen}`); console.log(`  ${pad('wrapmin:')} ${c.wrapmin}`); console.log(`  ${pad('tabsize:')} ${c.tabsize}`); console.log(`  ${pad('tabchar:')} ${c.tabchar}`); console.log(`  ${pad('stdin:')} ${c.stdin}`); console.log(`  ${pad('config:')} ${c.config?`Some("${c.config}")`:'None'}`); console.log(`  ${pad('verbosity:')} ${c.verbosity}`); const list=(name:string,arr:string[])=>{ console.log(`  ${pad(name+':')} ${arr[0]??''}`); for(const x of arr.slice(1)) console.log(`                           ${x}`); }; list('lists',c.lists); list('verbatims',c.verbatims); list('no-indent-envs',c.noIndentEnvs); list('wrap-chars',c.wrapChars); console.log(`  ${pad('files:')} ${c.files.join(' ')}`); }
function completion(shell:string){ if(shell==='bash') console.log('_tex-fmt() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n}\ncomplete -F _tex-fmt tex-fmt'); else console.log(`# ${shell} completion for tex-fmt`); }
function collectRecursive(startFiles:string[]):string[]{ const roots=startFiles.length?startFiles:['.']; const exts=new Set(['.tex','.bib','.cls','.sty']); const out:string[]=[]; function walk(p:string){ let st; try{st=fs.statSync(p);}catch{return;} if(st.isDirectory()){ const base=path.basename(p); if(base==='.git'||base==='node_modules'||base==='target'||base==='dist') return; for(const e of fs.readdirSync(p)) walk(path.join(p,e)); } else if(st.isFile()&&exts.has(path.extname(p))) out.push(p.startsWith('.')?p:'./'+p.replace(/^\.\//,'')); } for(const r of roots) walk(r); return out.sort(); }
function processFile(file:string,c:Config):boolean{ let s:string; try{s=fs.readFileSync(file,'utf8');}catch{error(file,'Could not open file'); return false;} const f=format(s,c); if(c.check){ if(f!==s){error(file,'Incorrect formatting'); return false;} return true;} if(c.print){ process.stdout.write(f); return true;} if(f!==s){ fs.writeFileSync(file,f); return !c.failOnChange; } return true; }

function main(){ const c=parseArgs(process.argv.slice(2)); if((c as any).help){console.log(HELP);return;} if((c as any).version){console.log('tex-fmt 0.5.6');return;} if((c as any).man){console.log(MAN);return;} if((c as any).completion){completion((c as any).completion);return;} if((c as any).argsFlag){argsDump(c);return;}
  if(c.stdin){ const input=fs.readFileSync(0,'utf8'); process.stdout.write(format(input,c)); return; }
  const files=c.recursive?collectRecursive(c.files):c.files; if(files.length===0){error('','No files specified. Provide filenames, or pass --recursive or --stdin'); process.exit(1);} let ok=true; for(const f of files) if(!processFile(f,c)) ok=false; if(!ok) process.exit(1); }
main();
