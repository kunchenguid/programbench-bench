declare var process: any;
declare module 'fs' { const x: any; export = x; }
declare module 'path' { const x: any; export = x; }
declare module 'child_process' { export function execSync(cmd: string, opts?: any): any; }
