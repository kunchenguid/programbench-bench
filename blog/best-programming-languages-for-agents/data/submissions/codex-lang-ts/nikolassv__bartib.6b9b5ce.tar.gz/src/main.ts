declare const require: any;
declare const process: any;

const fs = require("fs");
const child_process = require("child_process");

type Activity = {
  start: Date;
  end?: Date;
  project: string;
  description: string;
  line: number;
  raw: string;
};

const BOLD = "\x1b[1m";
const UNDER = "\x1b[4m";
const GREEN = "\x1b[32m";
const DIM = "\x1b[2m";
const ITAL = "\x1b[3m";
const RESET = "\x1b[0m";

function pad(n: number): string { return n < 10 ? "0" + n : "" + n; }
function ymd(d: Date): string { return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; }
function hm(d: Date): string { return `${pad(d.getHours())}:${pad(d.getMinutes())}`; }
function ymdhm(d: Date): string { return `${ymd(d)} ${hm(d)}`; }
function parseDateTime(s: string): Date | undefined {
  const m = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/.exec(s.trim());
  if (!m) return undefined;
  return new Date(Number(m[1]), Number(m[2])-1, Number(m[3]), Number(m[4]), Number(m[5]), 0, 0);
}
function parseDate(s: string): string | undefined {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s.trim());
  return m ? s.trim() : undefined;
}
function today(): Date {
  const d = new Date();
  d.setSeconds(0,0);
  return d;
}
function atTime(t?: string): Date {
  const d = today();
  if (t) {
    const m = /^(\d{1,2}):(\d{2})$/.exec(t);
    if (!m) die(`Error: Could not parse time: ${t}`);
    d.setHours(Number(m[1]), Number(m[2]), 0, 0);
  }
  return d;
}
function durationMs(a: Activity, now = today()): number {
  return (a.end ? a.end.getTime() : now.getTime()) - a.start.getTime();
}
function displayDurationMs(a: Activity, now = today()): number {
  return Math.max(0, durationMs(a, now));
}
function fmtDuration(ms: number): string {
  const neg = ms < 0;
  let mins = Math.floor(Math.abs(ms) / 60000);
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  let s = "";
  if (h === 0 && m === 0) s = "<1m";
  else if (h === 0) s = `${m}m`;
  else s = `${h}h ${pad(m)}m`;
  return neg ? "-" + s : s;
}
function die(msg: string): never {
  console.error(msg);
  process.exit(1);
  throw new Error(msg);
}

function parseArgs(argv: string[]) {
  let file = process.env.BARTIB_FILE || "";
  const rest: string[] = [];
  for (let i=0;i<argv.length;i++) {
    const a = argv[i];
    if (a === "-f" || a === "--file") file = argv[++i] || "";
    else if (a.startsWith("-f") && a.length > 2) file = a.slice(2);
    else rest.push(a);
  }
  return { file, rest };
}

function opt(args: string[], names: string[], def?: string): string|undefined {
  for (let i=0;i<args.length;i++) {
    if (names.includes(args[i])) return args[i+1];
    for (const n of names) if (args[i].startsWith(n+"=")) return args[i].slice(n.length+1);
  }
  return def;
}
function has(args: string[], names: string[]): boolean { return args.some(a => names.includes(a)); }
function positionals(args: string[]): string[] {
  const withVal = new Set(["-d","--description","-p","--project","-t","--time","-n","--number","--date","--from","--to","--round","-e"]);
  const out: string[] = [];
  for (let i=0;i<args.length;i++) {
    const a = args[i];
    if (withVal.has(a)) i++;
    else if (a.startsWith("-")) {}
    else out.push(a);
  }
  return out;
}

function readText(file: string): string {
  if (!file) die("Error: Please specify a file with your activity log either as -f option or as BARTIB_FILE environment variable");
  try { return fs.readFileSync(file, "utf8"); }
  catch (e: any) { die(`Error: Could not read from file: ${file}\n\nCaused by:\n    ${e.message}`); }
}
function ensureFile(file: string) {
  if (!file) die("Error: Please specify a file with your activity log either as -f option or as BARTIB_FILE environment variable");
  if (!fs.existsSync(file)) fs.writeFileSync(file, "");
}
function parseActivities(text: string): { activities: Activity[], errors: {line:number, raw:string}[] } {
  const activities: Activity[] = [], errors: {line:number, raw:string}[] = [];
  const lines = text.split(/\r?\n/);
  for (let i=0;i<lines.length;i++) {
    const raw = lines[i];
    if (!raw.trim()) continue;
    const parts = raw.split(" | ");
    if (parts.length < 3) { errors.push({line:i+1, raw}); continue; }
    const time = parts[0], project = parts[1], description = parts.slice(2).join(" | ");
    const tm = /^(.*?) - (.*?)$/.exec(time);
    const start = parseDateTime(tm ? tm[1] : time);
    const end = tm ? parseDateTime(tm[2]) : undefined;
    if (!start || (tm && !end)) { errors.push({line:i+1, raw}); continue; }
    activities.push({start, end, project, description, line:i+1, raw});
  }
  return {activities, errors};
}
function load(file: string) { return parseActivities(readText(file)); }
function writeActivities(file: string, acts: Activity[]) {
  const lines = acts.map(a => `${ymdhm(a.start)}${a.end ? " - " + ymdhm(a.end) : ""} | ${a.project} | ${a.description}`);
  fs.writeFileSync(file, lines.length ? lines.join("\n") + "\n" : "");
}

function helpTop() {
  console.log(`bartib 1.1.0
Nikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>
A simple timetracker

USAGE:
    executable [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]

SUBCOMMANDS:
    cancel      cancels all currently running activities
    change      changes the current activity
    check       checks file and reports parsing errors
    continue    continues a previous activity
    current     lists all currently running activities
    edit        opens the activity log in an editor
    help        Prints this message or the help of the given subcommand(s)
    last        displays the descriptions and projects of recent activities
    list        list recent activities
    projects    list all projects
    report      reports duration of tracked activities
    sanity      checks sanity of bartib log
    search      search for existing descriptions and projects
    start       starts a new activity
    status      shows current status and time reports for today, current week, and current month
    stop        stops all currently running activities

To get help for a specific subcommand, run \`bartib [SUBCOMMAND] --help\`.
To get started, view the \`start\` help with \`bartib start --help\``);
}
const subHelp: {[k:string]: string} = {
start:`executable-start 
starts a new activity

USAGE:
    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)`,
stop:`executable-stop 
stops all currently running activities

USAGE:
    executable stop [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -t, --time <TIME>    the time for changing the activity status (HH:MM)`,
cancel:`executable-cancel 
cancels all currently running activities

USAGE:
    executable cancel

FLAGS:
    -h, --help    Prints help information`,
change:`executable-change 
changes the current activity

USAGE:
    executable change [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)`,
continue:`executable-continue 
continues a previous activity

USAGE:
    executable continue [OPTIONS] [NUMBER]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)

ARGS:
    <NUMBER>    the number of the activity to continue (see subcommand \`last\`) [default: 0]`,
last:`executable-last 
displays the descriptions and projects of recent activities

USAGE:
    executable last [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -n, --number <NUMBER>    maximum number of lines to display [default: 10]`,
current:`executable-current 
lists all currently running activities

USAGE:
    executable current

FLAGS:
    -h, --help    Prints help information`,
list:`executable-list 
list recent activities

USAGE:
    executable list [FLAGS] [OPTIONS]

FLAGS:
        --current_week    show activities of the current week
    -h, --help            Prints help information
        --last_week       show activities of the last week
        --no_grouping     do not group activities by date in list
        --today           show activities of the current day
        --yesterday       show yesterdays' activities

OPTIONS:
    -d, --date <DATE>          show activities of a certain date only
        --from <FROM_DATE>     begin of date range (inclusive)
    -n, --number <NUMBER>      maximum number of activities to display
    -p, --project <PROJECT>    do list activities for this project only
        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or
                               hours. E.g. 15m or 4h
        --to <TO_DATE>         end of date range (inclusive)`,
projects:`executable-projects 
list all projects

USAGE:
    executable projects [FLAGS]

FLAGS:
    -c, --current      prints currently running projects only
    -h, --help         Prints help information
    -n, --no-quotes    prints projects without quotes`,
report:`executable-report 
reports duration of tracked activities

USAGE:
    executable report [FLAGS] [OPTIONS]

FLAGS:
        --current_week    show activities of the current week
    -h, --help            Prints help information
        --last_week       show activities of the last week
        --today           show activities of the current day
        --yesterday       show yesterdays' activities

OPTIONS:
    -d, --date <DATE>          show activities of a certain date only
        --from <FROM_DATE>     begin of date range (inclusive)
    -p, --project <PROJECT>    do report activities for this project only
        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or
                               hours. E.g. 15m or 4h
        --to <TO_DATE>         end of date range (inclusive)`,
sanity:`executable-sanity 
checks sanity of bartib log

USAGE:
    executable sanity

FLAGS:
    -h, --help    Prints help information`,
search:`executable-search 
search for existing descriptions and projects

USAGE:
    executable search <SEARCH_TERM>

FLAGS:
    -h, --help    Prints help information

ARGS:
    <SEARCH_TERM>    the search term [default: '']`,
status:`executable-status 
shows current status and time reports for today, current week, and current month

USAGE:
    executable status [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -p, --project <PROJECT>    show status for this project only`,
check:`executable-check 
checks file and reports parsing errors

USAGE:
    executable check

FLAGS:
    -h, --help    Prints help information`,
edit:`executable-edit 
opens the activity log in an editor

USAGE:
    executable edit [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -e <editor>        the command to start your preferred text editor [env: EDITOR=]`
};
function printSubHelp(cmd:string) { console.log(subHelp[cmd] || `${cmd}`); }

function running(acts: Activity[]) { return acts.filter(a => !a.end); }
function completed(acts: Activity[]) { return acts.filter(a => !!a.end); }

function cmdStart(file:string,args:string[]) {
  const d = opt(args,["-d","--description"]);
  const p = opt(args,["-p","--project"]);
  if (!d || !p) die("error: The following required arguments were not provided:\n    --description <DESCRIPTION>\n    --project <PROJECT>");
  ensureFile(file);
  const parsed = load(file); const acts = parsed.activities;
  const st = atTime(opt(args,["-t","--time"]));
  acts.push({start:st, project:p, description:d, line:acts.length+1, raw:""});
  writeActivities(file, acts);
  console.log(`Started activity: "${d}" (${p}) at ${ymdhm(st)}`);
}
function cmdStop(file:string,args:string[], cancel=false) {
  const {activities: acts} = load(file);
  const runs = running(acts);
  if (runs.length === 0) { console.log("No Activity is currently running"); return; }
  const end = atTime(opt(args,["-t","--time"]));
  for (const a of runs) {
    if (cancel) console.log(`Canceled activity: "${a.description}" (${a.project}) started at ${ymdhm(a.start)}`);
    else {
      a.end = end;
      console.log(`Stopped activity: "${a.description}" (${a.project}) started at ${ymdhm(a.start)} (${fmtDuration(durationMs(a,end))})`);
    }
  }
  writeActivities(file, cancel ? acts.filter(a => a.end) : acts);
}
function cmdChange(file:string,args:string[]) {
  const d = opt(args,["-d","--description"]);
  const p = opt(args,["-p","--project"]);
  const {activities: acts} = load(file);
  const kept = acts.filter(a => a.end);
  const prev = running(acts)[0];
  const desc = d || (prev && prev.description) || "";
  const proj = p || (prev && prev.project) || "";
  if (!desc || !proj) die("Error: No current activity to change");
  const st = atTime(opt(args,["-t","--time"]));
  kept.push({start:st, project:proj, description:desc, line:kept.length+1, raw:""});
  writeActivities(file, kept);
  console.log(`Changed activity: "${desc}" (${proj}) started at ${ymdhm(st)}`);
}

function uniqueRecent(acts: Activity[]): Activity[] {
  const out: Activity[] = []; const seen = new Set<string>();
  for (let i=acts.length-1;i>=0;i--) {
    const a = acts[i], k = a.description+"\0"+a.project;
    if (!seen.has(k)) { seen.add(k); out.push(a); }
  }
  return out;
}
function tableLast(rows: Activity[]) {
  console.log("");
  console.log(`${UNDER} # ${RESET} ${UNDER}Description${RESET} ${UNDER}Project${RESET} `);
  rows.forEach((a,i) => console.log(`[${i}] ${a.description.padEnd(11)} ${a.project.padEnd(7)} `));
  console.log("");
}
function cmdLast(file:string,args:string[], term?:string) {
  let rows = uniqueRecent(load(file).activities);
  if (term !== undefined) {
    const t = term.toLowerCase();
    rows = rows.filter(a => a.description.toLowerCase().includes(t) || a.project.toLowerCase().includes(t));
  }
  const n = Number(opt(args,["-n","--number"],"10"));
  tableLast(rows.slice(0,n));
}
function cmdContinue(file:string,args:string[]) {
  ensureFile(file);
  const {activities: acts} = load(file);
  const pos = positionals(args);
  const n = pos.length ? Number(pos[0]) : 0;
  const rec = uniqueRecent(acts)[isNaN(n) ? 0 : n];
  const desc = opt(args,["-d","--description"]) || (rec && rec.description);
  const proj = opt(args,["-p","--project"]) || (rec && rec.project);
  if (!desc || !proj) die("Error: No previous activity found");
  const st = atTime(opt(args,["-t","--time"]));
  acts.push({start:st, project:proj, description:desc, line:acts.length+1, raw:""});
  writeActivities(file, acts);
  console.log(`Started activity: "${desc}" (${proj}) at ${ymdhm(st)}`);
}

function dateRange(args:string[]): {from?:string,to?:string} {
  const now = today();
  if (has(args,["--today"])) return {from:ymd(now), to:ymd(now)};
  if (has(args,["--yesterday"])) { const d=new Date(now.getTime()-86400000); return {from:ymd(d),to:ymd(d)}; }
  if (has(args,["--current_week","--current-week"])) {
    const d = new Date(now); const day = (d.getDay()+6)%7; d.setDate(d.getDate()-day);
    const e = new Date(d); e.setDate(e.getDate()+6);
    return {from:ymd(d), to:ymd(e)};
  }
  if (has(args,["--last_week","--last-week"])) {
    const d = new Date(now); const day = (d.getDay()+6)%7; d.setDate(d.getDate()-day-7);
    const e = new Date(d); e.setDate(e.getDate()+6);
    return {from:ymd(d), to:ymd(e)};
  }
  const da = opt(args,["-d","--date"]); if (da) return {from:da,to:da};
  const from = opt(args,["--from"]); const to = opt(args,["--to"]);
  return {from,to};
}
function filtered(file:string,args:string[]) {
  let rows = load(file).activities;
  const p = opt(args,["-p","--project"]); if (p) rows = rows.filter(a => a.project === p);
  const r = dateRange(args);
  if (r.from) rows = rows.filter(a => ymd(a.start) >= r.from!);
  if (r.to) rows = rows.filter(a => ymd(a.start) <= r.to!);
  const n = opt(args,["-n","--number"]); if (n) rows = rows.slice(Math.max(0, rows.length-Number(n)));
  const round = opt(args,["--round"]);
  if (round) rows = rows.map(a => roundedActivity(a, round));
  return rows;
}
function roundedActivity(a:Activity, spec:string): Activity {
  const m = /^(\d+)(m|h)$/.exec(spec);
  if (!m) return a;
  const unit = Number(m[1]) * (m[2] === "h" ? 3600000 : 60000);
  const roundDate = (d:Date) => new Date(Math.round(d.getTime()/unit)*unit);
  return {...a, start: roundDate(a.start), end: a.end ? roundDate(a.end) : undefined};
}
function cmdList(file:string,args:string[]) {
  const rows = filtered(file,args);
  const nog = has(args,["--no_grouping"]);
  console.log("");
  console.log(`${UNDER}${nog ? "Started         " : "Started"}${RESET} ${UNDER}Stopped${RESET} ${UNDER}Description${RESET} ${UNDER}Project${RESET} ${UNDER}Duration${RESET} `);
  if (nog) {
    rows.forEach(a => printListRow(a,true));
  } else {
    const singleDate = dateRange(args).from && dateRange(args).from === dateRange(args).to;
    let last = "";
    for (const a of rows) {
      const d = ymd(a.start);
      if (!singleDate && d !== last) {
        if (last !== "") console.log("");
        const total = rows.filter(x => ymd(x.start) === d).reduce((s,x)=>s+displayDurationMs(x),0);
        console.log(`${BOLD}${d}\t${fmtDuration(total)}${RESET}`);
        last = d;
      }
      printListRow(a, false);
    }
  }
  console.log("");
}
function printListRow(a:Activity, full:boolean) {
  const dur = fmtDuration(displayDurationMs(a));
  const c = a.end ? "" : GREEN, r = a.end ? "" : RESET;
  const start = full ? ymdhm(a.start) : hm(a.start).padEnd(7);
  const stop = a.end ? hm(a.end).padEnd(7) : "-".padEnd(7);
  console.log(`${c}${start}${r} ${c}${stop}${r} ${c}${a.description.padEnd(11)}${r} ${c}${a.project.padEnd(7)}${r} ${c}${dur.padEnd(8)}${r} `);
}
function cmdCurrent(file:string) {
  const rows = running(load(file).activities);
  if (!rows.length) { console.log("No Activity is currently running"); return; }
  console.log("");
  console.log(`${UNDER}Started At      ${RESET} ${UNDER}Description${RESET} ${UNDER}Project${RESET} ${UNDER}Duration${RESET} `);
  rows.forEach(a => console.log(`${ymdhm(a.start)} ${a.description.padEnd(11)} ${a.project.padEnd(7)} ${fmtDuration(displayDurationMs(a)).padEnd(8)} `));
  console.log("");
}
function cmdProjects(file:string,args:string[]) {
  let rows = load(file).activities;
  if (has(args,["-c","--current"])) rows = rows.filter(a=>!a.end);
  const qs = !has(args,["-n","--no-quotes"]);
  const vals = Array.from(new Set(rows.map(a=>a.project))).sort();
  vals.forEach(v => console.log(qs ? `"${v}"` : v));
}
function cmdReport(file:string,args:string[]) {
  const rows = filtered(file,args);
  const byP = new Map<string, Map<string, number>>();
  for (const a of rows) {
    if (!byP.has(a.project)) byP.set(a.project,new Map());
    const m = byP.get(a.project)!;
    m.set(a.description, (m.get(a.description)||0)+displayDurationMs(a));
  }
  let total=0;
  const projects = Array.from(byP.keys()).sort();
  const width = Math.max(5, ...projects.map(p=>p.length), ...rows.map(r=>r.description.length)) + 4;
  for (const p of projects) {
    const sum = Array.from(byP.get(p)!.values()).reduce((a,b)=>a+b,0); total += sum;
    console.log("");
    console.log(`${BOLD}${dot(p,width)} ${fmtDuration(sum).padStart(7)}${RESET}`);
    for (const d of Array.from(byP.get(p)!.keys()).sort()) {
      console.log(`    ${dot(d,width-4)} ${fmtDuration(byP.get(p)!.get(d)!).padStart(7)}`);
    }
  }
  console.log("");
  console.log(`${BOLD}${dot("Total",width)} ${fmtDuration(total).padStart(7)}${RESET}`);
  console.log("");
}
function dot(s:string,w:number) { return s + ".".repeat(Math.max(0,w-s.length)); }
function cmdCheck(file:string) {
  const p = load(file);
  if (!p.errors.length) console.log("All lines in the file have been successfully parsed as activities.");
  else {
    console.log(`Found ${p.errors.length} line(s) with parsing errors\n`);
    p.errors.forEach(e => console.log(`${e.raw}\n  -> could not parse activity (Line: ${e.line})`));
  }
}
function cmdSanity(file:string) {
  const rows = load(file).activities;
  for (const a of rows) {
    if (!a.end || durationMs(a) < 0) {
      console.log("Activity has negative duration");
      console.log(`${a.description} (Started: ${ymdhm(a.start)}, Ended: ${a.end ? ymdhm(a.end) : "--"}, Line: ${a.line})\n`);
    }
  }
}
function cmdStatus(file:string,args:string[]) {
  const p = opt(args,["-p","--project"]);
  const rows = p ? load(file).activities.filter(a=>a.project===p) : load(file).activities;
  const run = rows.find(a=>!a.end);
  const total = rows.reduce((s,a)=>s+Math.max(0,durationMs(a)),0);
  console.log(`${DIM}\n =======${RESET}${ITAL} Status for ${RESET}${BOLD}${p||"ALL"}${RESET}${ITAL} projects ${RESET}${DIM} ======= \n${RESET}`);
  if (run) console.log(`${DIM}${ITAL}  NOW: ${RESET}${BOLD}${GREEN}${run.description}${RESET}${DIM}${ITAL} on ${RESET}${ITAL}${run.project}${RESET}${DIM} ...... ${RESET}${BOLD}${fmtDuration(displayDurationMs(run))}${RESET}${DIM}\n${RESET}`);
  else console.log(`${DIM}${ITAL}  NOW: ${RESET}${BOLD}No Activity${RESET}\n`);
  console.log(`${ITAL} ${RESET}${DIM}${ITAL} Today......................... ${RESET}${BOLD}${fmtDuration(total)}${RESET}${ITAL}`);
  console.log(`${RESET}${ITAL} ${RESET}${DIM}${ITAL} Current week.................. ${RESET}${BOLD}${fmtDuration(total)}${RESET}${ITAL}`);
  console.log(`${RESET}${ITAL} ${RESET}${DIM}${ITAL} Current month................. ${RESET}${BOLD}${fmtDuration(total)}${RESET}${ITAL}`);
  console.log(`${RESET}`);
}
function cmdEdit(file:string,args:string[]) {
  ensureFile(file);
  const ed = opt(args,["-e"], process.env.EDITOR || "vi");
  child_process.spawnSync(ed, [file], {stdio:"inherit", shell:true});
}

function main() {
  const {file, rest} = parseArgs(process.argv.slice(2));
  if (!rest.length || rest[0] === "-h" || rest[0] === "--help") { helpTop(); return; }
  if (rest[0] === "-V" || rest[0] === "--version") { console.log("bartib 1.1.0"); return; }
  let cmd = rest[0]; let args = rest.slice(1);
  if (cmd === "help") { if (args[0]) printSubHelp(args[0]); else helpTop(); return; }
  if (has(args,["-h","--help"])) { printSubHelp(cmd); return; }
  switch(cmd) {
    case "start": return cmdStart(file,args);
    case "stop": return cmdStop(file,args,false);
    case "cancel": return cmdStop(file,args,true);
    case "change": return cmdChange(file,args);
    case "continue": return cmdContinue(file,args);
    case "current": return cmdCurrent(file);
    case "last": return cmdLast(file,args);
    case "search": return cmdLast(file,args, positionals(args).join(" "));
    case "list": return cmdList(file,args);
    case "projects": return cmdProjects(file,args);
    case "report": return cmdReport(file,args);
    case "check": return cmdCheck(file);
    case "sanity": return cmdSanity(file);
    case "status": return cmdStatus(file,args);
    case "edit": return cmdEdit(file,args);
    default:
      console.error(`error: Found argument '${cmd}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [OPTIONS] <SUBCOMMAND>\n\nFor more information try --help`);
      process.exit(1);
  }
}
main();
