declare const process: any;
declare function require(name: string): any;
declare const Buffer: any;

const fs = require("fs");
const childProcess = require("child_process");

type Options = {
  filter: string | null;
  query: string;
  printQuery: boolean;
  expect: boolean;
  read0: boolean;
  print0: boolean;
  noSort: boolean;
  exact: boolean;
  extended: boolean;
  caseMode: "smart" | "ignore" | "respect";
  delimiter: string | null;
  nth: string | null;
  withNth: string | null;
  acceptNth: string | null;
  tail: number | null;
  tac: boolean;
  disabled: boolean;
  scheme: "default" | "path" | "history";
  tiebreak: string[];
  headerLines: number;
  select1: boolean;
  exit0: boolean;
  ansi: boolean;
};

type Item = {
  text: string;
  original: string;
  index: number;
  searchText: string;
};

type Match = Item & {
  score: number;
  begin: number;
  end: number;
  positions: number[];
};

const helpText = `fzf is an interactive filter program for any kind of list.

It implements a "fuzzy" matching algorithm, so you can quickly type in patterns
with omitted characters and still get the results you want.

Project URL: https://github.com/junegunn/fzf
Author: Junegunn Choi <junegunn.c@gmail.com>

* See man page for more information: fzf --man

Usage: fzf [options]

  SEARCH
    -e, --exact              Enable exact-match
    +x, --no-extended        Disable extended-search mode
    -i, --ignore-case        Case-insensitive match
    +i, --no-ignore-case     Case-sensitive match
        --smart-case         Smart-case match (default)
    --scheme=SCHEME          Scoring scheme [default|path|history]
    -n, --nth=N[,..]         Comma-separated list of field index expressions
    --with-nth=N[,..]        Transform the presentation of each line
    --accept-nth=N[,..]      Define which fields to print on accept
    -d, --delimiter=STR      Field delimiter regex (default: AWK-style)
    +s, --no-sort            Do not sort the result
    --literal                Do not normalize latin script letters
    --tail=NUM               Maximum number of items to keep in memory
    --disabled               Do not perform search
    --tiebreak=CRI[,..]      Sort criteria [length|chunk|pathname|begin|end|index]

  INPUT/OUTPUT
    --read0                  Read input delimited by ASCII NUL characters
    --print0                 Print output delimited by ASCII NUL characters
    --ansi                   Enable processing of ANSI color codes
    --sync                   Synchronous search for multi-staged filtering

  SCRIPTING
    -q, --query=STR          Start the finder with the given query
    -1, --select-1           Automatically select the only match
    -0, --exit-0             Exit immediately when there's no match
    -f, --filter=STR         Print matches for the initial query and exit
    --print-query            Print query as the first line
    --expect=KEYS            Comma-separated list of keys to complete fzf

  SHELL INTEGRATION
    --bash                   Print script to set up Bash shell integration
    --zsh                    Print script to set up Zsh shell integration
    --fish                   Print script to set up Fish shell integration

  HELP
    --version                Display version information and exit
    --help                   Show this message
    --man                    Show man page
`;

function die(message: string): never {
  process.stderr.write(message + "\n");
  process.exit(2);
  throw new Error(message);
}

function takeArg(args: string[], i: number, name: string): [string, number] {
  if (i + 1 >= args.length) die(`missing argument for ${name}`);
  return [args[i + 1], i + 1];
}

function splitDefaultOpts(s: string): string[] {
  const out: string[] = [];
  let cur = "";
  let quote = "";
  let esc = false;
  for (const ch of s) {
    if (esc) { cur += ch; esc = false; continue; }
    if (ch === "\\") { esc = true; continue; }
    if (quote) {
      if (ch === quote) quote = "";
      else cur += ch;
      continue;
    }
    if (ch === "'" || ch === `"`) { quote = ch; continue; }
    if (/\s/.test(ch)) {
      if (cur) { out.push(cur); cur = ""; }
    } else cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

function readDefaultArgs(): string[] {
  const args: string[] = [];
  const file = process.env.FZF_DEFAULT_OPTS_FILE;
  if (file) {
    try { args.push(...splitDefaultOpts(fs.readFileSync(file, "utf8"))); } catch {}
  }
  if (process.env.FZF_DEFAULT_OPTS) args.push(...splitDefaultOpts(process.env.FZF_DEFAULT_OPTS));
  return args;
}

function parseArgs(argv: string[]): Options {
  const opts: Options = {
    filter: null, query: "", printQuery: false, expect: false,
    read0: false, print0: false, noSort: false, exact: false, extended: true,
    caseMode: "smart", delimiter: null, nth: null, withNth: null, acceptNth: null,
    tail: null, tac: false, disabled: false, scheme: "default", tiebreak: ["length", "index"],
    headerLines: 0, select1: false, exit0: false, ansi: false,
  };
  const args = [...readDefaultArgs(), ...argv];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    let v: string;
    if (a === "--help" || a === "-h") { process.stdout.write(helpText); process.exit(0); }
    if (a === "--version") { process.stdout.write("0.68.0 (5676da4a)\n"); process.exit(0); }
    if (a === "--man") { process.stdout.write(manText()); process.exit(0); }
    if (a === "--bash") { process.stdout.write("# fzf shell integration for bash\n"); process.exit(0); }
    if (a === "--zsh") { process.stdout.write("# fzf shell integration for zsh\n"); process.exit(0); }
    if (a === "--fish") { process.stdout.write("# fzf shell integration for fish\n"); process.exit(0); }
    if (a === "-f" || a === "--filter") { [v, i] = takeArg(args, i, a); opts.filter = v; opts.query = v; continue; }
    if (a.startsWith("--filter=")) { opts.filter = a.slice(9); opts.query = opts.filter; continue; }
    if (a === "-q" || a === "--query") { [v, i] = takeArg(args, i, a); opts.query = v; continue; }
    if (a.startsWith("--query=")) { opts.query = a.slice(8); continue; }
    if (a === "-e" || a === "--exact") { opts.exact = true; continue; }
    if (a === "-i" || a === "--ignore-case") { opts.caseMode = "ignore"; continue; }
    if (a === "+i" || a === "--no-ignore-case") { opts.caseMode = "respect"; continue; }
    if (a === "--smart-case") { opts.caseMode = "smart"; continue; }
    if (a === "+x" || a === "--no-extended") { opts.extended = false; continue; }
    if (a === "-x" || a === "--extended") { opts.extended = true; continue; }
    if (a === "+s" || a === "--no-sort") { opts.noSort = true; continue; }
    if (a === "--read0") { opts.read0 = true; continue; }
    if (a === "--print0") { opts.print0 = true; continue; }
    if (a === "--ansi") { opts.ansi = true; continue; }
    if (a === "--print-query") { opts.printQuery = true; continue; }
    if (a === "-1" || a === "--select-1") { opts.select1 = true; continue; }
    if (a === "-0" || a === "--exit-0") { opts.exit0 = true; continue; }
    if (a.startsWith("--expect=")) { opts.expect = a.slice(9) !== ""; continue; }
    if (a === "--expect") { [v, i] = takeArg(args, i, a); opts.expect = v !== ""; continue; }
    if (a === "--no-expect") { opts.expect = false; continue; }
    if (a === "-d" || a === "--delimiter") { [v, i] = takeArg(args, i, a); opts.delimiter = v; continue; }
    if (a.startsWith("--delimiter=")) { opts.delimiter = a.slice(12); continue; }
    if (a === "-n" || a === "--nth") { [v, i] = takeArg(args, i, a); validateExprList(v); opts.nth = v; continue; }
    if (a.startsWith("--nth=")) { v = a.slice(6); validateExprList(v); opts.nth = v; continue; }
    if (a === "--with-nth") { [v, i] = takeArg(args, i, a); opts.withNth = v; continue; }
    if (a.startsWith("--with-nth=")) { opts.withNth = a.slice(11); continue; }
    if (a === "--accept-nth") { [v, i] = takeArg(args, i, a); opts.acceptNth = v; continue; }
    if (a.startsWith("--accept-nth=")) { opts.acceptNth = a.slice(13); continue; }
    if (a === "--tail") { [v, i] = takeArg(args, i, a); opts.tail = parseNum(v, "tail"); continue; }
    if (a.startsWith("--tail=")) { opts.tail = parseNum(a.slice(7), "tail"); continue; }
    if (a === "--tac") { opts.tac = true; continue; }
    if (a === "--disabled") { opts.disabled = true; continue; }
    if (a === "--scheme") { [v, i] = takeArg(args, i, a); opts.scheme = parseScheme(v); continue; }
    if (a.startsWith("--scheme=")) { opts.scheme = parseScheme(a.slice(9)); continue; }
    if (a === "--tiebreak") { [v, i] = takeArg(args, i, a); opts.tiebreak = parseTiebreak(v); continue; }
    if (a.startsWith("--tiebreak=")) { opts.tiebreak = parseTiebreak(a.slice(11)); continue; }
    if (a === "--header-lines") { [v, i] = takeArg(args, i, a); opts.headerLines = Math.max(0, parseNum(v, "header-lines")); continue; }
    if (a.startsWith("--header-lines=")) { opts.headerLines = Math.max(0, parseNum(a.slice(15), "header-lines")); continue; }
    if (isIgnoredOption(a)) {
      if (takesMandatoryIgnoredValue(a) && !a.includes("=") && i + 1 < args.length) i++;
      continue;
    }
    if (a.startsWith("-") || a.startsWith("+")) die(`unknown option: ${a}`);
  }
  if (opts.scheme === "path") opts.tiebreak = ["pathname", "length", "index"];
  if (opts.scheme === "history") opts.tiebreak = ["index"];
  return opts;
}

function parseNum(s: string, name: string): number {
  if (!/^-?\d+$/.test(s)) die(`invalid ${name}: ${s}`);
  return parseInt(s, 10);
}

function parseScheme(s: string): "default" | "path" | "history" {
  if (s === "default" || s === "path" || s === "history") return s;
  die(`invalid scoring scheme: ${s} (expected: default|path|history)`);
}

function parseTiebreak(s: string): string[] {
  const allowed = new Set(["length", "chunk", "pathname", "begin", "end", "index"]);
  const vals = s.split(",").filter(Boolean);
  for (const v of vals) if (!allowed.has(v)) die(`invalid sort criterion: ${v}`);
  if (!vals.includes("index")) vals.push("index");
  return vals;
}

function isIgnoredOption(a: string): boolean {
  const names = [
    "--sync","--literal","--no-color","--no-bold","--height","--min-height","--tmux",
    "--layout","--reverse","--margin","--padding","--border","--border-label","--border-label-pos",
    "--multi","-m","+m","--no-multi","--highlight-line","--cycle","--wrap","--wrap-sign",
    "--no-multi-line","--raw","--track","--gap","--gap-line","--freeze-left","--freeze-right",
    "--keep-right","--scroll-off","--no-hscroll","--hscroll-off","--jump-labels","--gutter",
    "--gutter-raw","--pointer","--marker","--marker-multi-line","--ellipsis","--tabstop",
    "--scrollbar","--no-scrollbar","--list-border","--list-label","--list-label-pos","--no-input",
    "--prompt","--info","--info-command","--separator","--no-separator","--ghost","--filepath-word",
    "--input-border","--input-label","--input-label-pos","--preview","--preview-window",
    "--preview-border","--preview-label","--preview-label-pos","--header","--header-first",
    "--header-border","--header-lines-border","--header-label","--header-label-pos","--footer",
    "--footer-border","--footer-label","--footer-label-pos","--bind","--with-shell","--listen",
    "--listen-unsafe","--walker","--walker-root","--walker-skip","--history","--history-size",
    "--no-clear","--no-mouse","--no-unicode","--ambidouble",
    "--algo","--no-tty-default","--tty-default","--style","--color","--black"
  ];
  const base = a.includes("=") ? a.slice(0, a.indexOf("=")) : a;
  return names.includes(base);
}

function takesMandatoryIgnoredValue(a: string): boolean {
  const base = a.includes("=") ? a.slice(0, a.indexOf("=")) : a;
  return new Set([
    "--height","--min-height","--tmux","--layout","--margin","--padding","--border-label",
    "--border-label-pos","--wrap-sign","--gap","--gap-line","--freeze-left","--freeze-right",
    "--scroll-off","--hscroll-off","--jump-labels","--gutter","--gutter-raw","--pointer",
    "--marker","--marker-multi-line","--ellipsis","--tabstop","--list-label","--list-label-pos",
    "--prompt","--info","--info-command","--separator","--ghost","--input-label",
    "--input-label-pos","--preview","--preview-window","--preview-label","--preview-label-pos",
    "--header","--header-label","--header-label-pos","--footer","--footer-label",
    "--footer-label-pos","--bind","--with-shell","--walker","--walker-root","--walker-skip",
    "--history","--history-size","--algo","--tty-default","--style","--color"
  ]).has(base);
}

function validateExprList(list: string) {
  for (const p of list.split(",")) {
    if (!p) continue;
    if (p.includes("..")) {
      const [a, b] = p.split("..");
      if ((a && !validIndex(a)) || (b && !validIndex(b))) die(`invalid format: ${p}`);
    } else if (!validIndex(p)) die(`invalid format: ${p}`);
  }
}

function validIndex(s: string): boolean {
  return /^-?\d+$/.test(s) && parseInt(s, 10) !== 0;
}

function splitInput(buf: any, read0: boolean): string[] {
  const sep = read0 ? "\0" : "\n";
  let text = buf.toString("utf8");
  if (text.endsWith(sep)) text = text.slice(0, -sep.length);
  if (text === "") return [];
  return text.split(sep);
}

function stripAnsi(s: string): string {
  return s.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "");
}

function makeDelimiter(delim: string | null): RegExp | null {
  if (!delim) return null;
  try { return new RegExp(delim); } catch { return new RegExp(escapeRegex(delim)); }
}

function splitFields(line: string, delim: string | null): string[] {
  if (!delim) return line.trim().split(/[ \t]+/).filter((_, i, a) => !(i === 0 && a[i] === ""));
  return line.split(makeDelimiter(delim)!);
}

function fieldIndex(n: number, len: number): number {
  return n > 0 ? n - 1 : len + n;
}

function evalExpr(expr: string, line: string, delim: string | null, strip = false): string {
  const fields = splitFields(line, delim);
  let res: string[] = [];
  if (expr.includes("..")) {
    const [as, bs] = expr.split("..");
    let a = as ? fieldIndex(parseInt(as, 10), fields.length) : 0;
    let b = bs ? fieldIndex(parseInt(bs, 10), fields.length) : fields.length - 1;
    a = Math.max(0, a); b = Math.min(fields.length - 1, b);
    if (a <= b) res = fields.slice(a, b + 1);
  } else {
    const ix = fieldIndex(parseInt(expr, 10), fields.length);
    if (ix >= 0 && ix < fields.length) res = [fields[ix]];
  }
  const joiner = delim ? delim.replace(/\\/g, "") : " ";
  const out = res.join(joiner);
  return strip ? out.trim() : out;
}

function transform(spec: string | null, line: string, delim: string | null, ordinal: number): string {
  if (!spec) return line;
  if (spec.includes("{")) {
    return spec.replace(/\{([^}]+)\}/g, (_m, expr) => expr === "n" ? String(ordinal) : evalExpr(expr, line, delim, true));
  }
  return spec.split(",").map(e => evalExpr(e, line, delim, false)).filter(s => s.length > 0).join(delim ? delim.replace(/\\/g, "") : " ");
}

function applyNth(spec: string | null, line: string, delim: string | null): string {
  if (!spec) return line;
  return spec.split(",").map(e => evalExpr(e, line, delim, false)).join(" ");
}

function normalizeCase(s: string, query: string, mode: Options["caseMode"]): string {
  if (mode === "ignore") return s.toLowerCase();
  if (mode === "respect") return s;
  return /[A-Z]/.test(query) ? s : s.toLowerCase();
}

type Term = { raw: string; neg: boolean; kind: "fuzzy" | "exact" | "prefix" | "suffix" | "equal"; text: string };

function parseGroups(query: string, exactDefault: boolean, extended: boolean): Term[][] {
  if (query === "") return [[]];
  if (!extended) return [[{ raw: query, neg: false, kind: exactDefault ? "exact" : "fuzzy", text: query }]];
  const words = splitQuery(query);
  const groups: Term[][] = [[]];
  for (const w of words) {
    if (w === "|") { groups.push([]); continue; }
    let s = w, neg = false;
    if (s.startsWith("!")) { neg = true; s = s.slice(1); }
    let quoted = false;
    if (s.startsWith("'")) { quoted = true; s = s.slice(1); }
    let kind: Term["kind"] = exactDefault ? "exact" : "fuzzy";
    if (neg && !quoted) kind = "exact";
    if (quoted) kind = exactDefault ? "fuzzy" : "exact";
    if (s.startsWith("^") && s.endsWith("$") && s.length > 1) { kind = "equal"; s = s.slice(1, -1); }
    else if (s.startsWith("^")) { kind = "prefix"; s = s.slice(1); }
    else if (s.endsWith("$")) { kind = "suffix"; s = s.slice(0, -1); }
    groups[groups.length - 1].push({ raw: w, neg, kind, text: s });
  }
  return groups;
}

function splitQuery(q: string): string[] {
  const out: string[] = [];
  let cur = "";
  let esc = false;
  for (const ch of q) {
    if (esc) { cur += ch; esc = false; continue; }
    if (ch === "\\") { esc = true; continue; }
    if (/\s/.test(ch)) { if (cur) { out.push(cur); cur = ""; } }
    else cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

function matchTerm(term: Term, text: string, query: string, mode: Options["caseMode"]): { ok: boolean; score: number; begin: number; end: number; positions: number[] } {
  const hay = normalizeCase(text, query, mode);
  const needle = normalizeCase(term.text, query, mode);
  if (needle === "") return { ok: true, score: 0, begin: 0, end: -1, positions: [] };
  let ix = -1;
  if (term.kind === "exact") ix = hay.indexOf(needle);
  else if (term.kind === "prefix") ix = hay.startsWith(needle) ? 0 : -1;
  else if (term.kind === "suffix") ix = hay.endsWith(needle) ? hay.length - needle.length : -1;
  else if (term.kind === "equal") ix = hay === needle ? 0 : -1;
  if (term.kind !== "fuzzy") {
    const ok = ix >= 0;
    return { ok, score: ok ? 1000 - ix - text.length / 100 : 0, begin: ix, end: ok ? ix + needle.length - 1 : -1, positions: ok ? range(ix, ix + needle.length) : [] };
  }
  return fuzzyScore(hay, needle);
}

function fuzzyScore(hay: string, needle: string) {
  const pos: number[] = [];
  let start = -1, last = -1, score = 0;
  for (const ch of needle) {
    const ix = hay.indexOf(ch, last + 1);
    if (ix < 0) return { ok: false, score: 0, begin: -1, end: -1, positions: [] };
    if (start < 0) start = ix;
    if (ix === last + 1) score += 15;
    if (ix === 0 || /[\/_\-\s.:]/.test(hay[ix - 1] || "")) score += 8;
    score += 10;
    pos.push(ix);
    last = ix;
  }
  const span = last - start + 1;
  score += 1000 - span * 4 - start * 2 - hay.length / 100;
  return { ok: true, score, begin: start, end: last, positions: pos };
}

function range(a: number, b: number): number[] {
  const r: number[] = [];
  for (let i = a; i < b; i++) r.push(i);
  return r;
}

function matchItem(item: Item, query: string, opts: Options): Match | null {
  if ((opts.disabled && opts.filter === null) || query === "") return { ...item, score: 0, begin: 0, end: 0, positions: [] };
  const groups = parseGroups(query, opts.exact, opts.extended);
  let best: Match | null = null;
  for (const group of groups) {
    let score = 0, begin = 1e9, end = -1;
    let positions: number[] = [];
    let okGroup = true;
    for (const term of group) {
      const m = matchTerm(term, item.searchText, query, opts.caseMode);
      const ok = term.neg ? !m.ok : m.ok;
      if (!ok) { okGroup = false; break; }
      if (!term.neg) {
        score += m.score; begin = Math.min(begin, m.begin); end = Math.max(end, m.end);
        positions = positions.concat(m.positions);
      }
    }
    if (okGroup) {
      const m = { ...item, score, begin: begin === 1e9 ? 0 : begin, end, positions };
      if (!best || m.score > best.score) best = m;
    }
  }
  return best;
}

function compareMatches(a: Match, b: Match, opts: Options): number {
  if (b.score !== a.score) return b.score - a.score;
  for (const t of opts.tiebreak) {
    let d = 0;
    if (t === "length") d = a.text.length - b.text.length;
    else if (t === "begin") d = a.begin - b.begin;
    else if (t === "end") d = b.end - a.end;
    else if (t === "index") d = a.index - b.index;
    else if (t === "pathname") d = pathNameRank(a) - pathNameRank(b);
    else if (t === "chunk") d = chunkLen(a) - chunkLen(b);
    if (d !== 0) return d;
  }
  return a.index - b.index;
}

function pathNameRank(m: Match): number {
  const slash = Math.max(m.text.lastIndexOf("/"), m.text.lastIndexOf("\\"));
  return m.begin >= slash ? 0 : 1;
}

function chunkLen(m: Match): number {
  const s = m.searchText;
  let l = m.begin, r = m.end;
  while (l > 0 && !/\s/.test(s[l - 1])) l--;
  while (r + 1 < s.length && !/\s/.test(s[r + 1])) r++;
  return r - l + 1;
}

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function manText(): string {
  return `fzf(1)                      fzf - a command-line fuzzy finder

NAME
       fzf - a command-line fuzzy finder

SYNOPSIS
       fzf [options]

DESCRIPTION
       fzf is an interactive filter program for any kind of list.

       This reimplementation supports the documented non-interactive filtering
       interface including --filter, --query, --nth, --with-nth, --accept-nth,
       --read0, --print0, --tail, --tac, and common search modes.
`;
}

function readStdin(): any {
  try { return fs.readFileSync(0); } catch { return Buffer.alloc(0); }
}

function fallbackInput(): string[] {
  const cmd = process.env.FZF_DEFAULT_COMMAND;
  if (!cmd) return [];
  try {
    return childProcess.execSync(cmd, { encoding: "utf8", shell: process.env.SHELL || "sh" }).replace(/\n$/, "").split("\n").filter((s: string) => s.length);
  } catch {
    return [];
  }
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const buf = readStdin();
  let lines = buf.length ? splitInput(buf, opts.read0) : fallbackInput();
  if (opts.headerLines > 0) lines = lines.slice(opts.headerLines);
  if (opts.tail !== null && opts.tail >= 0 && lines.length > opts.tail) lines = lines.slice(lines.length - opts.tail);
  if (opts.tac) lines.reverse();

  const items: Item[] = lines.map((line, i) => {
    const source = opts.ansi ? stripAnsi(line) : line;
    const visible = transform(opts.withNth, source, opts.delimiter, i);
    const searchBase = applyNth(opts.nth, visible, opts.delimiter);
    return { text: visible, original: line, index: i, searchText: searchBase };
  });

  const query = opts.filter !== null ? opts.filter : opts.query;
  let matches = items.map(it => matchItem(it, query, opts)).filter((m): m is Match => !!m);
  if (!opts.noSort) matches.sort((a, b) => compareMatches(a, b, opts));

  const sep = opts.print0 ? "\0" : "\n";
  const out: string[] = [];
  if (opts.printQuery) out.push(query);
  if (opts.expect && opts.filter === null) out.push("");
  for (const m of matches) {
    const source = opts.ansi ? stripAnsi(m.original) : m.original;
    const base = opts.acceptNth ? transform(opts.acceptNth, source, opts.delimiter, m.index) : source;
    out.push(base);
  }
  if (out.length > 0) process.stdout.write(out.join(sep) + sep);
  process.exit(matches.length > 0 || query === "" ? 0 : 1);
}

main();
