declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

type Format = "metric" | "binary" | "bytes" | "gb" | "gib" | "mb" | "mib";

interface Options {
  format: Format;
  apparent: boolean;
  countHardLinks: boolean;
  stayOnFilesystem: boolean;
  ignoreDirs: string[];
  command: "main" | "aggregate" | "interactive" | "completions" | "help";
  stats: boolean;
  noSort: boolean;
  noTotal: boolean;
  inputs: string[];
  shell?: string;
}

interface Entry {
  path: string;
  display: string;
  bytes: number;
  isDir: boolean;
  errors: number;
}

interface WalkState {
  seen: Set<string>;
  rootDev?: number;
  entriesTraversed: number;
  smallest: number | null;
  largest: number;
}

const GREEN = "\x1b[32m";
const CYAN = "\x1b[36m";
const RESET = "\x1b[39m";

const LONG_HELP = `A tool to learn about disk usage, fast!

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

Commands:
  interactive  Launch the terminal user interface [aliases: i]
  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [INPUT]...
          One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -t, --threads <THREADS>
          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread
          
          [default: 0]

  -f, --format <FORMAT>
          The format with which to print byte counts
          
          [default: binary]
          [possible values: metric, binary, bytes, gb, gib, mb, mib]

  -A, --apparent-size
          Display apparent size instead of disk usage

  -l, --count-hard-links
          Count hard-linked files each time they are seen

  -x, --stay-on-filesystem
          If set, we will not cross filesystems or traverse mount points

  -i, --ignore-dirs <IGNORE_DIRS>
          One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path.
          
          Hence, they will only be ignored if they are eventually reached as part of the traversal.
          
          [default: /proc /dev /sys /run]

      --log-file <LOG_FILE>
          Write a log file with debug information, including panics

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const SHORT_HELP = `A tool to learn about disk usage, fast!

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

Commands:
  interactive  Launch the terminal user interface [aliases: i]
  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -t, --threads <THREADS>          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread [default: 0]
  -f, --format <FORMAT>            The format with which to print byte counts [default: binary] [possible values: metric, binary, bytes, gb, gib, mb, mib]
  -A, --apparent-size              Display apparent size instead of disk usage
  -l, --count-hard-links           Count hard-linked files each time they are seen
  -x, --stay-on-filesystem         If set, we will not cross filesystems or traverse mount points
  -i, --ignore-dirs <IGNORE_DIRS>  One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path [default: /proc /dev /sys /run]
      --log-file <LOG_FILE>        Write a log file with debug information, including panics
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version`;

const AGG_HELP = `Aggregate the consumed space of one or more directories or files

Usage: executable aggregate [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
      --stats     If set, print additional statistics about the file traversal to stderr
      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending
      --no-total  If set, no total column will be computed for multiple inputs
  -h, --help      Print help`;

const INT_HELP = `Launch the terminal user interface

Usage: executable interactive [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -e, --no-entry-check  Do not check entries for presence when listing a directory to avoid slugging performance on slow filesystems
  -h, --help            Print help`;

const COMP_HELP = `Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate a completions-script for [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help  Print help`;

function main(): void {
  const opts = parse(process.argv.slice(2));
  if (opts.command === "help") {
    printHelp(opts.inputs[0], false);
    return;
  }
  if (opts.command === "completions") {
    if (!opts.shell) {
      console.error("error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: dua completions <SHELL>\n\nFor more information, try '--help'.");
      process.exit(2);
    }
    console.log(completion(opts.shell));
    return;
  }
  if (opts.command === "interactive") {
    runReport(opts);
    return;
  }
  runReport(opts);
}

function parse(args: string[]): Options {
  const opts: Options = {
    format: "binary",
    apparent: false,
    countHardLinks: false,
    stayOnFilesystem: false,
    ignoreDirs: ["/proc", "/dev", "/sys", "/run"],
    command: "main",
    stats: false,
    noSort: false,
    noTotal: false,
    inputs: [],
  };
  let positional = false;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (!positional && a === "--") {
      positional = true;
      continue;
    }
    if (!positional && (a === "help")) {
      opts.command = "help";
      opts.inputs = args.slice(i + 1);
      return opts;
    }
    if (!positional && (a === "aggregate" || a === "a")) {
      opts.command = "aggregate";
      continue;
    }
    if (!positional && (a === "interactive" || a === "i")) {
      opts.command = "interactive";
      continue;
    }
    if (!positional && a === "completions") {
      opts.command = "completions";
      if (args[i + 1] === "-h" || args[i + 1] === "--help") {
        console.log(COMP_HELP);
        process.exit(0);
      }
      opts.shell = args[i + 1];
      return opts;
    }
    if (!positional && (a === "--help")) {
      printHelp(opts.command === "main" ? undefined : opts.command, false);
      process.exit(0);
    }
    if (!positional && a === "-h") {
      printHelp(opts.command === "main" ? undefined : opts.command, true);
      process.exit(0);
    }
    if (!positional && (a === "-V" || a === "--version")) {
      console.log("dua 2.32.2");
      process.exit(0);
    }
    if (!positional && (a === "-A" || a === "--apparent-size")) {
      opts.apparent = true;
      continue;
    }
    if (!positional && (a === "-l" || a === "--count-hard-links")) {
      opts.countHardLinks = true;
      continue;
    }
    if (!positional && (a === "-x" || a === "--stay-on-filesystem")) {
      opts.stayOnFilesystem = true;
      continue;
    }
    if (!positional && (a === "--stats")) {
      opts.stats = true;
      continue;
    }
    if (!positional && (a === "--no-sort")) {
      opts.noSort = true;
      continue;
    }
    if (!positional && (a === "--no-total")) {
      opts.noTotal = true;
      continue;
    }
    if (!positional && (a === "-e" || a === "--no-entry-check")) continue;
    if (!positional && (a === "-t" || a === "--threads" || a === "-i" || a === "--ignore-dirs" || a === "--log-file")) {
      if (a === "-i" || a === "--ignore-dirs") opts.ignoreDirs.push(args[i + 1]);
      i++;
      continue;
    }
    if (!positional && (a === "-f" || a === "--format")) {
      const val = args[++i] as Format;
      validateFormat(val);
      opts.format = val;
      continue;
    }
    if (!positional && a.startsWith("--format=")) {
      const val = a.substring("--format=".length) as Format;
      validateFormat(val);
      opts.format = val;
      continue;
    }
    if (!positional && a.startsWith("-")) {
      console.error(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...\n\nFor more information, try '--help'.`);
      process.exit(2);
    }
    opts.inputs.push(a);
  }
  return opts;
}

function validateFormat(v: string): void {
  if (!["metric", "binary", "bytes", "gb", "gib", "mb", "mib"].includes(v)) {
    console.error(`error: invalid value '${v}' for '--format <FORMAT>'\n  [possible values: metric, binary, bytes, gb, gib, mb, mib]\n\nFor more information, try '--help'.`);
    process.exit(2);
  }
}

function printHelp(topic?: string, short = false): void {
  if (topic === "aggregate" || topic === "a") console.log(AGG_HELP);
  else if (topic === "interactive" || topic === "i") console.log(INT_HELP);
  else if (topic === "completions") console.log(COMP_HELP);
  else console.log(short ? SHORT_HELP : LONG_HELP);
}

function runReport(opts: Options): void {
  const state: WalkState = { seen: new Set(), entriesTraversed: 0, smallest: null, largest: 0 };
  let roots = opts.inputs.length ? opts.inputs : fs.readdirSync(".").filter((n: string) => !isSymlinkRoot(n)).map((n: string) => n);
  let entries: Entry[] = [];
  let exitCode = 0;
  if (roots.length === 1) {
    const root = roots[0];
    let st: any | null = null;
    try { st = fs.lstatSync(root); } catch {}
    if (st && st.isDirectory()) {
      try {
        const names = fs.readdirSync(root).filter((n: string) => !isSymlinkRoot(path.join(root, n)));
        entries = names.map((n: string) => {
          const p = path.join(root, n);
          const e = measureEntry(p, n, opts, state, false);
          if (e.errors) exitCode = 1;
          return e;
        });
      } catch {
        entries = [missingEntry(root)];
        exitCode = 1;
      }
    } else {
      const e = measureEntry(root, root, opts, state, true);
      if (e.errors) exitCode = 1;
      entries = [e];
    }
  } else {
    entries = roots.map((r) => {
      const e = measureEntry(r, r, opts, state, true);
      if (e.errors) exitCode = 1;
      return e;
    });
  }
  if (!opts.noSort) entries.sort((a, b) => a.bytes - b.bytes || a.display.localeCompare(b.display));
  for (const e of entries) printEntry(e, opts);
  if (entries.length > 1 && !opts.noTotal) {
    printLine(formatBytes(entries.reduce((s, e) => s + e.bytes, 0), opts.format, opts.apparent), "total", false, 0);
  }
  if (opts.stats) {
    const smallest = state.smallest === null ? 0 : state.smallest;
    console.error(`Statistics { entries_traversed: ${state.entriesTraversed}, smallest_file_in_bytes: ${smallest}, largest_file_in_bytes: ${state.largest} }`);
  }
  process.exit(exitCode);
}

function isSymlinkRoot(p: string): boolean {
  try { return fs.lstatSync(p).isSymbolicLink(); } catch { return false; }
}

function missingEntry(p: string): Entry {
  return { path: p, display: p, bytes: 0, isDir: true, errors: 1 };
}

function measureEntry(p: string, display: string, opts: Options, state: WalkState, isRoot: boolean): Entry {
  try {
    const st = fs.lstatSync(p);
    const isDir = st.isDirectory();
    const bytes = measurePath(p, st, opts, state, isRoot);
    return { path: p, display, bytes, isDir, errors: 0 };
  } catch {
    return missingEntry(display);
  }
}

function measurePath(p: string, st: any, opts: Options, state: WalkState, isRoot: boolean): number {
  state.entriesTraversed++;
  const isDir = st.isDirectory();
  const key = `${st.dev}:${st.ino}`;
  if (!opts.countHardLinks && !isDir && st.nlink > 1) {
    if (state.seen.has(key)) return 0;
    state.seen.add(key);
  }
  if (opts.stayOnFilesystem && state.rootDev === undefined) state.rootDev = st.dev;
  let own = opts.apparent ? Number(st.size) : Number(st.blocks || 0) * 512;
  if (st.isSymbolicLink() && !opts.apparent) own = 0;
  if (!isDir) {
    state.smallest = state.smallest === null ? own : Math.min(state.smallest, own);
    state.largest = Math.max(state.largest, own);
    return own;
  }
  let total = own;
  let names: string[];
  try { names = fs.readdirSync(p); } catch { return total; }
  for (const n of names) {
    const child = path.join(p, n);
    let cst: any;
    try { cst = fs.lstatSync(child); } catch { continue; }
    if (cst.isSymbolicLink()) continue;
    if (cst.isDirectory()) {
      const abs = path.resolve(child);
      if (!isRoot && opts.ignoreDirs.includes(abs)) continue;
      if (opts.stayOnFilesystem && state.rootDev !== undefined && cst.dev !== state.rootDev) continue;
    }
    total += measurePath(child, cst, opts, state, false);
  }
  return total;
}

function printEntry(e: Entry, opts: Options): void {
  printLine(formatBytes(e.bytes, opts.format, opts.apparent), e.display, e.isDir, e.errors);
}

function printLine(size: string, name: string, isDir: boolean, errors: number): void {
  const n = isDir ? `${CYAN}${name}${RESET}` : name;
  const err = errors ? `  <${errors} IO Error>` : "";
  console.log(`${GREEN}${size}${RESET} ${n}${err}`);
}

function formatBytes(bytes: number, fmt: Format, apparent = false): string {
  if (fmt === "bytes") return `${String(Math.round(bytes)).padStart(10)} b`;
  if (fmt === "gb") return `${(bytes / 1_000_000_000).toFixed(2).padStart(7)} GB`;
  if (fmt === "gib") return `${(bytes / 1073741824).toFixed(2).padStart(6)} GiB`;
  if (fmt === "mb") return `${(bytes / 1_000_000).toFixed(2).padStart(7)} MB`;
  if (fmt === "mib") return `${(bytes / 1048576).toFixed(2).padStart(6)} MiB`;
  const base = fmt === "metric" ? 1000 : 1024;
  const units = fmt === "metric" ? [" B", "KB", "MB", "GB", "TB"] : ["  B", "KiB", "MiB", "GiB", "TiB"];
  if (bytes === 0) return fmt === "metric" ? "      0  B" : "      0   B";
  if (fmt === "binary" && apparent && bytes < 10_000) return `${String(bytes).padStart(7)}   B`;
  let value = bytes;
  let idx = 0;
  while (value >= base && idx < units.length - 1) {
    value /= base;
    idx++;
  }
  if (idx === 0) return `${String(bytes).padStart(7)} ${units[0]}`;
  return `${value.toFixed(2).padStart(7)} ${units[idx]}`;
}

function completion(shell: string): string {
  if (!["bash", "elvish", "fish", "powershell", "zsh"].includes(shell)) {
    console.error(`error: invalid value '${shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.`);
    process.exit(2);
  }
  if (shell === "fish") {
    return `# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_dua_global_optspecs
\tstring join \\n t/threads= f/format= A/apparent-size l/count-hard-links x/stay-on-filesystem i/ignore-dirs= log-file= h/help V/version
end

complete -c dua -s t -l threads -d 'The amount of threads to use' -r
complete -c dua -s f -l format -d 'The format with which to print byte counts' -r -f -a "metric binary bytes gb gib mb mib"
complete -c dua -s A -l apparent-size -d 'Display apparent size instead of disk usage'
complete -c dua -s l -l count-hard-links -d 'Count hard-linked files each time they are seen'
complete -c dua -s x -l stay-on-filesystem -d 'If set, we will not cross filesystems or traverse mount points'
complete -c dua -n "__fish_use_subcommand" -a "interactive aggregate completions help"`;
  }
  if (shell === "bash") {
    return `_dua() {
    local cur
    COMPREPLY=()
    cur="\${COMP_WORDS[COMP_CWORD]}"
    COMPREPLY=( $(compgen -W "-t --threads -f --format -A --apparent-size -l --count-hard-links -x --stay-on-filesystem -i --ignore-dirs --log-file -h --help -V --version interactive aggregate completions help" -- "$cur") )
}
complete -F _dua dua`;
  }
  if (shell === "zsh") return `#compdef dua\n_arguments '*:: :->dua'`;
  if (shell === "powershell") return `Register-ArgumentCompleter -Native -CommandName 'dua' -ScriptBlock { param($wordToComplete) @('interactive','aggregate','completions','help') }`;
  return `edit:completion:arg-completer[dua] = {|@words| put interactive aggregate completions help }`;
}

main();
