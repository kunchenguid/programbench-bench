declare function require(name: string): any;
declare const process: any;

const { spawnSync } = require('child_process');

const METHODS = new Set(['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS','TRACE','CONNECT']);
const TAKES_VALUE = new Set(['-A','--user-agent','-b','--cookie','-c','--cookie-jar','-d','--data','--data-raw','--data-binary','--data-ascii','--data-urlencode','-F','--form','-H','--header','-I','-K','--config','-o','--output','-O','-u','--user','-X','--request','--connect-timeout','--max-time','--proxy','-x','--cacert','--capath','--cert','--key','--resolve','--connect-to','--interface','--limit-rate','--retry','--url']);

interface Parsed {
  curlMode: boolean;
  pretty: boolean;
  curlBefore: string[];
  curlAfter: string[];
  method?: string;
  url?: string;
  headers: string[];
  query: [string,string][];
  body: Record<string, any>;
  hasBody: boolean;
  passthroughOnly: boolean;
}

function usage(): string {
  return `Usage: ./executable [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]`;
}

function categoryHelp(): string {
  return `${usage()}
Invalid category provided, here is a list of all categories:

 auth        Different types of authentication methods
 connection  Low level networking operations
 curl        The command line tool itself
 dns         General DNS options
 file        FILE protocol options
 ftp         FTP protocol options
 http        HTTP and HTTPS protocol options
 imap        IMAP protocol options
 misc        Options that don't fit into any other category
 output      Filesystem output
 pop3        POP3 protocol options
 post        HTTP Post specific options
 proxy       All options related to proxies
 scp         SCP protocol options
 sftp        SFTP protocol options
 smtp        SMTP protocol options
 ssh         SSH protocol options
 telnet      TELNET protocol options
 tftp        TFTP protocol options
 tls         All TLS/SSL related options
 upload      All options for uploads
 verbose     Options related to any kind of command line output of curl
`;
}

function runCurl(args: string[], input?: string) {
  const r = spawnSync('curl', args, { input: input ?? '', encoding: 'utf8' });
  if (r.stdout) process.stdout.write(r.stdout);
  if (r.stderr) process.stderr.write(r.stderr);
  process.exit(typeof r.status === 'number' ? r.status : 1);
}

function shellQuote(s: string): string {
  if (s.length === 0) return '""';
  if (/^[A-Za-z0-9_@%+=:,./?&{}\[\]~-]+$/.test(s)) return s;
  return '"' + s.replace(/(["\\$`])/g, '\\$1') + '"';
}

function parseJsonish(s: string): any {
  try { return JSON.parse(s); } catch {}
  return s;
}

function stableJson(obj: Record<string, any>): string {
  const keys = Object.keys(obj).sort();
  const out: Record<string, any> = {};
  for (const k of keys) out[k] = obj[k];
  return JSON.stringify(out);
}

function isUrl(s: string): boolean {
  return /^[a-z][a-z0-9+.-]*:\/\//i.test(s) || /^localhost(?::|\/|$)/.test(s) || /^127\.0\.0\.1(?::|\/|$)/.test(s) || /^\[?::1\]?/.test(s);
}

function appendQuery(url: string, pairs: [string,string][]): string {
  if (!pairs.length) return url;
  const qs = pairs.map(([k,v]) => `${encodeURIComponent(k).replace(/%20/g,'+')}=${encodeURIComponent(v).replace(/%20/g,'+')}`).join('&');
  return url + (url.includes('?') ? '&' : '?') + qs;
}

function parse(argv: string[]): Parsed {
  const p: Parsed = { curlMode:false, pretty:false, curlBefore:[], curlAfter:[], headers:[], query:[], body:{}, hasBody:false, passthroughOnly:false };
  let i = 0;
  while (i < argv.length) {
    const a = argv[i];
    if (a === '--curl') { p.curlMode = true; i++; continue; }
    if (a === '--pretty') { p.pretty = true; i++; continue; }
    if (a === '--version') { p.passthroughOnly = true; p.curlBefore.push('--version'); i++; continue; }
    if (a === '--help' || a === '--manual') { p.passthroughOnly = true; p.curlBefore.push(a); if (i+1 < argv.length) p.curlBefore.push(...argv.slice(i+1)); break; }
    if (!p.url && a.startsWith('-')) {
      p.curlBefore.push(a);
      if (!a.includes('=') && TAKES_VALUE.has(a) && i + 1 < argv.length) { p.curlBefore.push(argv[++i]); }
      i++; continue;
    }
    if (!p.method && !p.url && METHODS.has(a.toUpperCase()) && i + 1 < argv.length) { p.method = a.toUpperCase(); i++; continue; }
    if (!p.url) { p.url = a; i++; continue; }
    if (a.includes('==')) {
      const idx = a.indexOf('=='); p.query.push([a.slice(0, idx), a.slice(idx + 2)]);
    } else if (a.includes(':=')) {
      const idx = a.indexOf(':='); p.body[a.slice(0, idx)] = parseJsonish(a.slice(idx + 2)); p.hasBody = true;
    } else if (a.includes('=') && !a.startsWith('-')) {
      const idx = a.indexOf('='); p.body[a.slice(0, idx)] = a.slice(idx + 1); p.hasBody = true;
    } else if (a.includes(':') && !isUrl(a)) {
      p.headers.push(a);
    } else {
      p.curlAfter.push(a);
    }
    i++;
  }
  return p;
}

function build(p: Parsed): { args: string[], finalUrl?: string, stdin: string } {
  if (!p.url) return { args: p.curlBefore.concat(p.curlAfter), stdin: '' };
  const finalUrl = appendQuery(p.url, p.query);
  const args: string[] = [];
  args.push(...p.curlBefore);
  if (p.method) args.push('-X', p.method);
  for (const h of p.headers) args.push('-H', h);
  let stdin = '';
  if (p.hasBody) {
    args.push('-d', stableJson(p.body));
  }
  args.push(finalUrl);
  args.push(...p.curlAfter);
  args.push('-s', '-S');
  if (!p.hasBody) { args.push('-d@-'); stdin = ''; }
  args.push('-H', 'Content-Type: application/json', '-H', 'Accept: application/json, */*');
  return { args, finalUrl, stdin };
}

const argv = process.argv.slice(2);
if (argv.length === 0) {
  process.stderr.write(usage() + '\n');
  runCurl(['--help']);
}
if (argv.length === 1 && argv[0] === '--help') {
  process.stdout.write(categoryHelp());
  process.exit(0);
}
const parsed = parse(argv);
if (parsed.passthroughOnly) runCurl(parsed.curlBefore.concat(parsed.curlAfter));
if (!parsed.url) {
  process.stderr.write(usage() + '\n');
  process.exit(2);
}
const built = build(parsed);
if (built.finalUrl) process.stderr.write(built.finalUrl + '\n');
if (parsed.curlMode) {
  const shown = built.args.map((a: string, i: number) => (i > 0 && built.args[i-1] === '-d' && a.startsWith('{')) ? a : shellQuote(a));
  process.stdout.write('curl ' + shown.join(' ') + '\n');
  process.exit(0);
}

if (parsed.pretty) {
  const args = built.args.slice();
  const insert = Math.max(0, args.length - 6);
  args.splice(insert, 0, '-i');
  const r = spawnSync('curl', args, { input: built.stdin, encoding: 'utf8' });
  if (r.stderr) process.stderr.write('\x1b[31m' + r.stderr + '\x1b[0m');
  const raw = r.stdout || '';
  const split = raw.indexOf('\r\n\r\n') >= 0 ? raw.indexOf('\r\n\r\n') + 4 : raw.indexOf('\n\n') + 2;
  let body = raw;
  if (split > 1) {
    const head = raw.slice(0, split);
    body = raw.slice(split);
    process.stderr.write(head);
  }
  try { process.stdout.write(JSON.stringify(JSON.parse(body), null, 4) + '\n'); }
  catch { process.stdout.write(body); }
  process.exit(typeof r.status === 'number' ? r.status : 1);
}

runCurl(built.args, built.stdin);
