declare var require: any;
declare var process: any;
const fs = require('fs');
const pathMod = require('path');
declare var Buffer: any;
const nodeCrypto = require('crypto');

const ARCHIVE = ['7z','bz2','bzip2','gz','gzip','lz','rar','tar','xz','zip'];
const AUDIO = ['aac','aiff','amr','flac','gsm','m4a','m4b','m4p','mp3','ogg','wav','wma'];
const BOOK = ['azw3','chm','djv','djvu','epub','fb2','mobi','pdf'];
const DOC = ['accdb','doc','docm','docx','dot','dotm','dotx','mdb','odp','ods','odt','pdf','potm','potx','ppt','pptm','pptx','rtf','xlm','xls','xlsm','xlsx','xlt','xltm','xltx','xps'];
const FONT = ['eot','fon','otc','otf','ttc','ttf','woff','woff2'];
const IMAGE = ['bmp','exr','gif','heic','jpeg','jpg','jxl','png','psb','psd','svg','tga','tiff','webp'];
const SOURCE = ['asm','awk','bas','c','cc','ceylon','clj','coffee','cpp','cs','d','dart','elm','erl','go','gradle','groovy','h','hh','hpp','java','jl','js','jsp','jsx','kt','kts','lua','nim','pas','php','pl','pm','py','rb','rs','scala','sol','swift','tcl','ts','tsx','vala','vb','zig'];
const VIDEO = ['3gp','avi','flv','m4p','m4v','mkv','mov','mp4','mpeg','mpg','webm','wmv'];
const BOOL_COLS = new Set(['is_dir','is_file','is_symlink','is_pipe','is_fifo','is_char','is_character','is_block','is_socket','is_hidden','is_empty','is_shebang','is_binary','is_text','is_archive','is_audio','is_book','is_doc','is_font','is_image','is_source','is_video','user_read','user_write','user_exec','user_all','user_rwx','group_read','group_write','group_exec','group_all','group_rwx','other_read','other_write','other_exec','other_all','other_rwx','suid','is_suid','sgid','is_sgid','sticky','is_sticky','has_xattrs','has_extattrs','has_acl','has_default_acl','has_capabilities','has_caps']);

function help() {
  console.log('fselect \x1b[33m0.10.0\x1b[0m');
  console.log('Find files with SQL-like queries.');
  console.log('\x1b[4;36mhttps://github.com/jhspetersson/fselect\x1b[0m');
  console.log('');
  console.log('Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]');
}
function stripFlags(args:string[]) { return args.filter(a => !['--nocolor','--no-color','--no-errors','--us-dates'].includes(a)); }
function tokenize(s:string):string[] {
  const out:string[]=[]; let cur=''; let q='';
  for (let i=0;i<s.length;i++) { const c=s[i];
    if (q) { if (c===q) { out.push(cur); cur=''; q=''; } else if (c==='\\' && i+1<s.length) cur+=s[++i]; else cur+=c; continue; }
    if (c==='\''||c==='"'||c==='`') { if (cur) { out.push(cur); cur=''; } q=c; continue; }
    if (/\s/.test(c)) { if (cur) { out.push(cur); cur=''; } continue; }
    if (',(){}'.includes(c)) { if (cur) { out.push(cur); cur=''; } out.push(c==='{'?'(':c==='}'?')':c); continue; }
    if ('<>!=~'.includes(c)) { if (cur) { out.push(cur); cur=''; } let op=c; while (i+1<s.length && '<>!=~'.includes(s[i+1])) op+=s[++i]; out.push(op); continue; }
    cur+=c;
  }
  if (cur) out.push(cur); return out;
}
function findTop(tokens:string[], word:string, start=0) { let d=0; word=word.toLowerCase(); for(let i=start;i<tokens.length;i++){ const t=tokens[i].toLowerCase(); if(t==='(')d++; else if(t===')')d--; else if(d===0&&t===word)return i;} return -1; }
function splitComma(tokens:string[]) { const parts:string[][]=[]; let cur:string[]=[]; let d=0; for(const t of tokens){ if(t==='(')d++; if(t===')')d--; if(t===','&&d===0){parts.push(cur);cur=[];} else cur.push(t);} if(cur.length)parts.push(cur); return parts; }
function splitColumns(tokens:string[]) {
  const byComma = splitComma(tokens);
  if (byComma.length > 1) return byComma;
  const parts:string[][]=[]; let cur:string[]=[]; let d=0;
  for (const t of tokens) {
    if (d===0 && cur.length && t!==')' && t!=='(') { parts.push(cur); cur=[]; }
    cur.push(t);
    if (t==='(') d++;
    else if (t===')') d--;
  }
  if (cur.length) parts.push(cur);
  return parts;
}
function parseQuery(args:string[]) {
  let q = stripFlags(args).join(' ').trim(); if(/^select\s+/i.test(q)) q=q.replace(/^select\s+/i,'');
  const tokens=tokenize(q); let into='tabs'; let limit:any=null, offset=0;
  let end=tokens.length; const intoI=findTop(tokens,'into'); if(intoI>=0){ into=(tokens[intoI+1]||'tabs').toLowerCase(); end=intoI; }
  const limI=findTop(tokens,'limit'); if(limI>=0 && limI<end){ limit=parseInt(tokens[limI+1]||'0',10); end=Math.min(end,limI); }
  const offI=findTop(tokens,'offset'); if(offI>=0 && offI<end){ offset=parseInt(tokens[offI+1]||'0',10); end=Math.min(end,offI); }
  const ordI=findTop(tokens,'order'); if(ordI>=0 && ordI<end){ end=ordI; }
  const grpI=findTop(tokens,'group'); if(grpI>=0 && grpI<end){ end=grpI; }
  const whereI=findTop(tokens,'where'); if(whereI>=0 && whereI<end){ end=whereI; }
  const fromI=findTop(tokens,'from');
  const colEnd = fromI>=0?fromI:end;
  const columns = splitColumns(tokens.slice(0,colEnd)).map(x=>parseExpr(x)).filter(Boolean);
  let roots:any[]=[{p:'.', max:null, min:0, symlinks:false}];
  if(fromI>=0){ const rEnd = whereI>=0?whereI:Math.min(...[ordI,grpI,limI,offI,intoI].filter(x=>x>=0).concat([tokens.length])); roots=parseRoots(tokens.slice(fromI+1,rEnd)); }
  const where = whereI>=0 ? tokens.slice(whereI+1, Math.min(...[ordI,grpI,limI,offI,intoI].filter(x=>x>=0&&x>whereI).concat([tokens.length]))) : [];
  let group:any[]=[]; if(grpI>=0){ let gs=grpI+1; if((tokens[gs]||'').toLowerCase()==='by')gs++; const gEnd=Math.min(...[ordI,limI,offI,intoI].filter(x=>x>=0&&x>grpI).concat([tokens.length])); group=splitComma(tokens.slice(gs,gEnd)).map(parseExpr); }
  let order:any[]=[]; if(ordI>=0){ let os=ordI+1; if((tokens[os]||'').toLowerCase()==='by')os++; const oEnd=Math.min(...[limI,offI,intoI].filter(x=>x>=0&&x>ordI).concat([tokens.length])); order=splitComma(tokens.slice(os,oEnd)).map(p=>({expr:parseExpr(p.filter(x=>!['asc','desc'].includes(x.toLowerCase()))), desc:p.some(x=>x.toLowerCase()==='desc')})); }
  return {columns: columns.length?columns:[parseExpr(['path'])], roots, where, group, order, limit, offset, into};
}
function parseRoots(tokens:string[]) { const roots:any[]=[]; for(const part of splitComma(tokens)){ let pTokens:string[]=[]; let opt:any={max:null,min:0,symlinks:false}; for(let i=0;i<part.length;i++){ const t=part[i].toLowerCase(); if(['mindepth','maxdepth','depth'].includes(t)){ const n=parseInt(part[++i]||'0',10); if(t==='mindepth')opt.min=n; else opt.max=n; } else if(['symlinks','sym'].includes(t)) opt.symlinks=true; else if(['archives','arc','gitignore','git','nogitignore','nogit','hgignore','hg','dockerignore','docker','dfs','bfs','regexp','rx'].includes(t)) { } else if(t==='as') { i++; } else pTokens.push(part[i]); } roots.push({p:pTokens.join(' ')||'.',...opt}); } return roots.length?roots:[{p:'.',max:null,min:0,symlinks:false}]; }
function parseExpr(tokens:string[]):any { if(!tokens.length)return null;
  if(tokens.length>=3 && tokens[1]==='(' && tokens[tokens.length-1]===')') return {type:'func',name:tokens[0].toLowerCase(),args:splitComma(tokens.slice(2,-1)).map(parseExpr)};
  if(tokens.length>=3){ let idx=-1,d=0; for(let j=0;j<tokens.length;j++){ if(tokens[j]==='(')d++; else if(tokens[j]===')')d--; else if(d===0&&['+','-','*','/','%'].includes(tokens[j])){idx=j;break;} } if(idx>0)return {type:'bin',op:tokens[idx],left:parseExpr(tokens.slice(0,idx)),right:parseExpr(tokens.slice(idx+1))}; }
  if(tokens.length===1){ const t=tokens[0]; if(/^-?\d+(\.\d+)?$/.test(t))return{type:'num',v:Number(t)}; return{type:'atom',v:t}; }
  return {type:'atom',v:tokens.join(' ')}; }
function walk(root:any):any[] { const base=pathMod.resolve(root.p); const res:any[]=[]; let q:[string,number][]=[[base,0]]; while(q.length){ const [p,depth]=q.shift()!; let lst:any, st:any; try{ lst=fs.lstatSync(p); st=root.symlinks?fs.statSync(p): (lst.isSymbolicLink()?fs.statSync(p):lst); }catch(e){continue;} if(depth>0 && depth>=root.min)res.push(makeRec(p,base,lst,st)); if(st.isDirectory() && (root.max===null||depth<root.max)){ let names:string[]=[]; try{const d=fs.opendirSync(p); let ent; while((ent=d.readSync())!==null) names.push(ent.name); d.closeSync();}catch(e){} for(const n of names) q.push([pathMod.join(p,n),depth+1]); } } return res; }
function makeRec(p:string,base:string,lst:any,st:any){ const rel=pathMod.relative(base,p)||pathMod.basename(p); return {p,base,rel:rel.split(pathMod.sep).join('/'), lst, st}; }
function modeString(r:any){ const m=r.lst.mode, type=r.lst.isDirectory()?'d':r.lst.isSymbolicLink()?'l':r.lst.isFIFO&&r.lst.isFIFO()?'p':r.lst.isSocket&&r.lst.isSocket()?'s':r.lst.isCharacterDevice&&r.lst.isCharacterDevice()?'c':r.lst.isBlockDevice&&r.lst.isBlockDevice()?'b':'-'; const bits=[[0o400,'r'],[0o200,'w'],[0o100,'x'],[0o040,'r'],[0o020,'w'],[0o010,'x'],[0o004,'r'],[0o002,'w'],[0o001,'x']]; let s=type+bits.map(([b,c]:any)=>(m&b)?c:'-').join(''); if(m&0o4000)s=s.slice(0,3)+(m&0o100?'s':'S')+s.slice(4); if(m&0o2000)s=s.slice(0,6)+(m&0o010?'s':'S')+s.slice(7); if(m&0o1000)s=s.slice(0,9)+(m&0o001?'t':'T'); return s; }
function dateFmt(d:Date){ const pad=(n:number)=>String(n).padStart(2,'0'); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`; }
function human(n:number){ if(n<1024)return `${n}B`; const units=['K','M','G','T']; let x=n; let u='B'; for(const unit of units){ x/=1024; u=unit; if(x<1024)break;} return `${Math.round(x*10)/10}${u}`; }
function extOf(name:string){ const b=pathMod.basename(name); const i=b.lastIndexOf('.'); return i>0?b.slice(i+1):''; }
function fileText(r:any){ try{return fs.readFileSync(r.p);}catch(e){return Buffer.alloc(0);} }
function hash(r:any, alg:string){ try{return nodeCrypto.createHash(alg).update(fs.readFileSync(r.p)).digest('hex');}catch(e){return '';} }
const passwd = (()=>{try{const m:any={}; for(const l of fs.readFileSync('/etc/passwd','utf8').split('\n')){const p=l.split(':'); if(p.length>2)m[p[2]]=p[0];} return m;}catch(e){return {};}})();
const groupf = (()=>{try{const m:any={}; for(const l of fs.readFileSync('/etc/group','utf8').split('\n')){const p=l.split(':'); if(p.length>2)m[p[2]]=p[0];} return m;}catch(e){return {};}})();
function col(r:any, name:string):any { const n=name.toLowerCase(); const bn=pathMod.basename(r.rel); const ext=extOf(bn); const stem=ext?bn.slice(0,-ext.length-1):bn; const mode=r.lst.mode; const inList=(a:string[])=>a.includes(ext.toLowerCase());
  switch(n){ case 'name':return bn; case 'filename':case 'fname':return stem; case 'ext':case 'extension':return ext; case 'path':return r.rel; case 'abspath':try{return fs.realpathSync(r.p);}catch(e){return pathMod.resolve(r.p);} case 'dir':case 'directory':case 'dirname':return pathMod.dirname(r.rel)==='.'?'':pathMod.dirname(r.rel).split(pathMod.sep).join('/'); case 'absdir':return pathMod.dirname(pathMod.resolve(r.p)); case 'size':return r.st.size; case 'fsize':case 'hsize':return human(r.st.size); case 'uid':return r.lst.uid; case 'gid':return r.lst.gid; case 'user':return passwd[r.lst.uid]||String(r.lst.uid); case 'group':return groupf[r.lst.gid]||String(r.lst.gid); case 'accessed':return dateFmt(r.st.atime); case 'modified':return dateFmt(r.st.mtime); case 'created':return dateFmt(r.st.birthtime); case 'atime':return Math.floor(r.st.atimeMs/1000); case 'mtime':return Math.floor(r.st.mtimeMs/1000); case 'ctime':return Math.floor(r.st.ctimeMs/1000); case 'device':return r.st.dev; case 'rdev':return r.st.rdev; case 'inode':return r.st.ino; case 'blocks':return (r.st.blocks||0)*2; case 'hardlinks':return r.st.nlink; case 'mode':return modeString(r); case 'is_dir':return r.lst.isDirectory(); case 'is_file':return r.lst.isFile(); case 'is_symlink':return r.lst.isSymbolicLink(); case 'is_pipe':case 'is_fifo':return r.lst.isFIFO&&r.lst.isFIFO(); case 'is_char':case 'is_character':return r.lst.isCharacterDevice&&r.lst.isCharacterDevice(); case 'is_block':return r.lst.isBlockDevice&&r.lst.isBlockDevice(); case 'is_socket':return r.lst.isSocket&&r.lst.isSocket(); case 'is_hidden':return bn.startsWith('.'); case 'is_empty': if(r.st.isDirectory()){try{return fs.readdirSync(r.p).length===0;}catch(e){return false;}} return r.st.size===0; case 'is_shebang': { const b=fileText(r); return b.length>=2&&b[0]===35&&b[1]===33;} case 'is_binary': { const b=fileText(r); return b.includes(0);} case 'is_text': { const b=fileText(r); return !b.includes(0);} case 'is_archive':return inList(ARCHIVE); case 'is_audio':return inList(AUDIO); case 'is_book':return inList(BOOK); case 'is_doc':return inList(DOC); case 'is_font':return inList(FONT); case 'is_image':return inList(IMAGE); case 'is_source':return inList(SOURCE); case 'is_video':return inList(VIDEO); case 'mime':return mime(ext); case 'line_count':try{return fs.readFileSync(r.p,'utf8').split('\n').length-1;}catch(e){return '';} case 'sha1':return hash(r,'sha1'); case 'sha2_256':case 'sha256':return hash(r,'sha256'); case 'sha2_512':case 'sha512':return hash(r,'sha512'); case 'sha3_512':case 'sha3':try{return hash(r,'sha3-512');}catch(e){return '';} case 'user_read':return !!(mode&0o400); case 'user_write':return !!(mode&0o200); case 'user_exec':return !!(mode&0o100); case 'user_all':case 'user_rwx':return (mode&0o700)===0o700; case 'group_read':return !!(mode&0o040); case 'group_write':return !!(mode&0o020); case 'group_exec':return !!(mode&0o010); case 'group_all':case 'group_rwx':return (mode&0o070)===0o070; case 'other_read':return !!(mode&0o004); case 'other_write':return !!(mode&0o002); case 'other_exec':return !!(mode&0o001); case 'other_all':case 'other_rwx':return (mode&0o007)===0o007; case 'suid':case 'is_suid':return !!(mode&0o4000); case 'sgid':case 'is_sgid':return !!(mode&0o2000); case 'sticky':case 'is_sticky':return !!(mode&0o1000); case 'has_xattrs':case 'has_extattrs':case 'has_acl':case 'has_default_acl':case 'has_capabilities':case 'has_caps':return false; case 'xattr_count':return 0; default:return undefined; }
}
function mime(e:string){ e=e.toLowerCase(); const m:any={txt:'text/plain',md:'text/markdown',html:'text/html',htm:'text/html',json:'application/json',js:'application/javascript',ts:'application/typescript',css:'text/css',csv:'text/csv',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',svg:'image/svg+xml',pdf:'application/pdf',zip:'application/zip',gz:'application/gzip',mp3:'audio/mpeg',mp4:'video/mp4'}; return m[e]||''; }
function evalExpr(e:any,r:any,rows?:any[]):any { if(!e)return ''; if(e.type==='num')return e.v; if(e.type==='atom'){ const v=e.v; if(v==='*')return '*'; if(['true','false'].includes(String(v).toLowerCase()))return String(v).toLowerCase()==='true'; if(/^today$/i.test(v))return new Date().toISOString().slice(0,10); const cv=col(r,v); return cv===undefined?v:cv; } if(e.type==='bin'){ const a=Number(evalExpr(e.left,r)), b=Number(evalExpr(e.right,r)); if(e.op==='+')return a+b; if(e.op==='-')return a-b; if(e.op==='*')return a*b; if(e.op==='/')return b?a/b:''; if(e.op==='%')return a%b; } if(e.type==='func'){ const n=e.name; const vals=e.args.map((x:any)=>evalExpr(x,r,rows)); const s=(x:any)=>String(x); if(['lower','lowercase','lcase'].includes(n))return s(vals[0]).toLowerCase(); if(['upper','uppercase','ucase'].includes(n))return s(vals[0]).toUpperCase(); if(['length','len'].includes(n))return s(vals[0]).length; if(n==='concat')return vals.map(s).join(''); if(n==='concat_ws')return vals.slice(1).map(s).join(s(vals[0])); if(n==='trim')return s(vals[0]).trim(); if(n==='ltrim')return s(vals[0]).trimStart(); if(n==='rtrim')return s(vals[0]).trimEnd(); if(n==='replace')return s(vals[0]).split(s(vals[1])).join(s(vals[2]||'')); if(['substr','substring'].includes(n))return s(vals[0]).substr(Number(vals[1])-1, vals[2]===undefined?undefined:Number(vals[2])); if(n==='format_size'||n==='format_filesize')return human(Number(vals[0])); if(n==='bin')return Number(vals[0]).toString(2); if(n==='hex')return Number(vals[0]).toString(16); if(n==='oct')return Number(vals[0]).toString(8); if(n==='abs')return Math.abs(Number(vals[0])); if(['pow','power'].includes(n))return Math.pow(Number(vals[0]),Number(vals[1])); if(n==='sqrt')return Math.sqrt(Number(vals[0])); if(n==='floor')return Math.floor(Number(vals[0])); if(['ceil','ceiling'].includes(n))return Math.ceil(Number(vals[0])); if(n==='round')return vals[1]!==undefined?Number(Number(vals[0]).toFixed(Number(vals[1]))):Math.round(Number(vals[0])); if(n==='pi')return Math.PI; if(['current_uid'].includes(n))return process.getuid?process.getuid():''; if(['current_gid'].includes(n))return process.getgid?process.getgid():''; if(n==='current_user')return passwd[process.getuid?process.getuid():-1]||''; if(n==='current_group')return groupf[process.getgid?process.getgid():-1]||''; if(['count','min','max','sum','avg'].includes(n) && rows){ const arg=e.args[0]; if(n==='count')return rows.length; const ns=rows.map(rr=>Number(evalExpr(arg,rr))).filter(x=>!isNaN(x)); if(n==='min')return Math.min(...ns); if(n==='max')return Math.max(...ns); if(n==='sum')return ns.reduce((a,b)=>a+b,0); if(n==='avg')return ns.length?Math.floor(ns.reduce((a,b)=>a+b,0)/ns.length):''; } } return ''; }
function cmpVal(a:any,b:any){ const na=Number(a), nb=Number(b); if(!isNaN(na)&&!isNaN(nb)) return na-nb; return String(a).localeCompare(String(b)); }
function globToRe(p:string){ return new RegExp('^'+p.replace(/[.+^${}()|[\]\\]/g,'\\$&').replace(/\*/g,'.*').replace(/\?/g,'.')+'$'); }
function likeToRe(p:string){ return new RegExp('^'+p.replace(/[.+^${}()|[\]\\]/g,'\\$&').replace(/%/g,'.*').replace(/_/g,'.')+'$'); }
function lit(tok:string){ if(/^-?\d+(\.\d+)?([kmg]b?|b)?$/i.test(tok)){ const m=tok.match(/^(-?\d+(?:\.\d+)?)([kmg]b?|b)?$/i); let n=Number(m[1]); const u=(m[2]||'').toLowerCase(); if(u[0]==='k')n*=1024; if(u[0]==='m')n*=1024*1024; if(u[0]==='g')n*=1024*1024*1024; return n; } if(['true','false'].includes(tok.toLowerCase()))return tok.toLowerCase()==='true'; return tok; }
function evalWhere(tokens:string[],r:any):boolean { if(!tokens.length)return true; let i=0; function primary():boolean{ if(tokens[i]==='('){ i++; const v=or(); if(tokens[i]===')')i++; return v; } const left=tokens[i++]; const op=(tokens[i]||'').toLowerCase(); if(!op || ['and','or',')'].includes(op)){ return !!col(r,left); } i++; if(op==='between'){ const a=lit(tokens[i++]); if((tokens[i]||'').toLowerCase()==='and')i++; const b=lit(tokens[i++]); const v:any=col(r,left); return cmpVal(v,a)>=0&&cmpVal(v,b)<=0; } const v:any=col(r,left); if(op==='in'){ const vals:any[]=[]; if(tokens[i]==='(')i++; while(i<tokens.length&&tokens[i]!==')'){ if(tokens[i]!==',') vals.push(lit(tokens[i])); i++; } if(tokens[i]===')')i++; return vals.some(x=>String(x)===String(v)); } let right=lit(tokens[i++]||''); if(['=','==','eq'].includes(op)){ if(typeof right==='string'&&/[*?]/.test(right))return globToRe(right).test(String(v)); return String(v)==String(right); } if(['===','eeq'].includes(op))return String(v)===String(right); if(['!=','<>','ne'].includes(op)){ if(typeof right==='string'&&/[*?]/.test(right))return !globToRe(right).test(String(v)); return String(v)!=String(right); } if(['!==','ene'].includes(op))return String(v)!==String(right); if(['>','gt'].includes(op))return cmpVal(v,right)>0; if(['>=','gte','ge'].includes(op))return cmpVal(v,right)>=0; if(['<','lt'].includes(op))return cmpVal(v,right)<0; if(['<=','lte','le'].includes(op))return cmpVal(v,right)<=0; if(['~=','=~','regexp','rx'].includes(op))return new RegExp(String(right)).test(String(v)); if(['!=~','!~=','notrx'].includes(op))return !new RegExp(String(right)).test(String(v)); if(op==='like')return likeToRe(String(right)).test(String(v)); if(op==='notlike')return !likeToRe(String(right)).test(String(v)); return false; }
  function and():boolean{ let v=primary(); while((tokens[i]||'').toLowerCase()==='and'){i++; v=primary()&&v;} return v; } function or():boolean{ let v=and(); while((tokens[i]||'').toLowerCase()==='or'){i++; v=and()||v;} return v; } return or(); }
function title(e:any){ if(e.type==='atom'){ const map:any={name:'Name',filename:'Filename',fname:'Fname',ext:'Ext',extension:'Extension',path:'Path',abspath:'Abspath',dir:'Dir',directory:'Directory',dirname:'Dirname',absdir:'Absdir',size:'Size',fsize:'Fsize',hsize:'Hsize'}; return map[e.v.toLowerCase()]||e.v; } if(e.type==='func')return e.name.toUpperCase(); return 'Value'; }
function main(){ const args=process.argv.slice(2); if(args.length===0 || args.some((a:string)=>['--help','-h','--version','-V'].includes(a))){help(); return;} if(args.includes('-i')||args.includes('--interactive')){ help(); return; }
  const q=parseQuery(args); let rows:any[]=[]; for(const root of q.roots) rows=rows.concat(walk(root)); rows=rows.filter(r=>evalWhere(q.where,r));
  if(q.order.length) rows.sort((a,b)=>{ for(const o of q.order){ let c=0; if(o.expr.type==='atom' && /^\d+$/.test(o.expr.v)){ const idx=Number(o.expr.v)-1; c=cmpVal(evalExpr(q.columns[idx],a),evalExpr(q.columns[idx],b)); } else c=cmpVal(evalExpr(o.expr,a),evalExpr(o.expr,b)); if(c)return o.desc?-c:c; } return 0; });
  rows=rows.slice(q.offset, q.limit===null?undefined:q.offset+q.limit); const aggregate=q.columns.some((c:any)=>c.type==='func'&&['count','min','max','sum','avg'].includes(c.name)); let outRows:any[];
  if (q.group.length) {
    const groups:any = {};
    for (const r of rows) {
      const k = q.group.map((g:any)=>String(evalExpr(g,r,rows))).join('\u0001');
      if (!groups[k]) groups[k] = [];
      groups[k].push(r);
    }
    outRows = Object.keys(groups).map(k => q.columns.map((c:any)=>evalExpr(c, groups[k][0]||{}, groups[k])));
  } else {
    outRows=aggregate?[q.columns.map((c:any)=>evalExpr(c,rows[0]||{},rows))]:rows.map(r=>q.columns.map((c:any)=>evalExpr(c,r,rows)));
  }
  if(q.into==='json'){ const keys=q.columns.map(title); console.log(JSON.stringify(outRows.map(vals=>{const o:any={}; vals.forEach((v:any,i:number)=>o[keys[i]]=String(v)); return o;}))); }
  else if(q.into==='csv'){ for(const vals of outRows) console.log(vals.map((v:any)=>String(v).includes(',')?'"'+String(v).replace(/"/g,'""')+'"':String(v)).join(',')); }
  else if(q.into==='lines'){ for(const vals of outRows) for(const v of vals) console.log(String(v)); }
  else if(q.into==='list'){ process.stdout.write(outRows.map(v=>v.join('\t')).join('\0')+(outRows.length?'\0':'')); }
  else if(q.into==='html'){ console.log('<table>'); for(const vals of outRows) console.log('<tr>'+vals.map((v:any)=>'<td>'+String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</td>').join('')+'</tr>'); console.log('</table>'); }
  else { for(const vals of outRows) console.log(vals.map((v:any)=>String(v)).join('\t')); }
}
try{main();}catch(e:any){ console.error(e&&e.message?e.message:String(e)); process.exit(1); }
