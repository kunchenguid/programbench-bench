#!/usr/bin/env node

declare function require(name: string): any;
declare const process: {
  argv: string[];
  exit(code?: number): never;
  stdout: { write(s: string): void; on(ev: string, cb: (err: any) => void): void };
  stderr: { write(s: string): void; on(ev: string, cb: (err: any) => void): void };
};

const { existsSync, readdirSync, readFileSync, statSync } = require("fs");
const { join } = require("path");
const { spawnSync } = require("child_process");

function ignoreEpipe(err: any): void {
  if (err && err.code === "EPIPE") process.exit(0);
  throw err;
}

process.stdout.on("error", ignoreEpipe);
process.stderr.on("error", ignoreEpipe);

const version = "v0.0.0-SNAPSHOT";

const checkers: Array<[string, string[]]> = [
  ["appendAssign", ["diagnostic"]],
  ["appendCombine", ["performance"]],
  ["argOrder", ["diagnostic"]],
  ["assignOp", ["style"]],
  ["badCall", ["diagnostic"]],
  ["badCond", ["diagnostic"]],
  ["badLock", ["diagnostic", "experimental"]],
  ["badRegexp", ["diagnostic", "experimental"]],
  ["badSorting", ["diagnostic", "experimental"]],
  ["badSyncOnceFunc", ["diagnostic", "experimental"]],
  ["boolExprSimplify", ["style", "experimental"]],
  ["builtinShadow", ["style", "opinionated"]],
  ["builtinShadowDecl", ["diagnostic", "experimental"]],
  ["captLocal", ["style"]],
  ["caseOrder", ["diagnostic"]],
  ["codegenComment", ["diagnostic"]],
  ["commentFormatting", ["style"]],
  ["commentedOutCode", ["diagnostic", "experimental"]],
  ["commentedOutImport", ["style", "experimental"]],
  ["defaultCaseOrder", ["style"]],
  ["deferInLoop", ["diagnostic", "experimental"]],
  ["deferUnlambda", ["style", "experimental"]],
  ["deprecatedComment", ["diagnostic"]],
  ["docStub", ["style", "experimental"]],
  ["dupArg", ["diagnostic"]],
  ["dupBranchBody", ["diagnostic"]],
  ["dupCase", ["diagnostic"]],
  ["dupImport", ["style", "experimental"]],
  ["dupOption", ["diagnostic", "experimental"]],
  ["dupSubExpr", ["diagnostic"]],
  ["dynamicFmtString", ["diagnostic", "experimental"]],
  ["elseif", ["style"]],
  ["emptyDecl", ["diagnostic", "experimental"]],
  ["emptyFallthrough", ["style", "experimental"]],
  ["emptyStringTest", ["style", "experimental"]],
  ["equalFold", ["performance", "experimental"]],
  ["evalOrder", ["diagnostic", "experimental"]],
  ["exitAfterDefer", ["diagnostic"]],
  ["exposedSyncMutex", ["style", "experimental"]],
  ["externalErrorReassign", ["diagnostic", "experimental"]],
  ["filepathJoin", ["diagnostic", "experimental"]],
  ["flagDeref", ["diagnostic"]],
  ["flagName", ["diagnostic"]],
  ["hexLiteral", ["style", "experimental"]],
  ["httpNoBody", ["style", "experimental"]],
  ["hugeParam", ["performance"]],
  ["ifElseChain", ["style"]],
  ["importShadow", ["style", "opinionated"]],
  ["indexAlloc", ["performance"]],
  ["initClause", ["style", "opinionated", "experimental"]],
  ["mapKey", ["diagnostic"]],
  ["methodExprCall", ["style", "experimental"]],
  ["nestingReduce", ["style", "opinionated", "experimental"]],
  ["newDeref", ["style"]],
  ["nilValReturn", ["diagnostic", "experimental"]],
  ["octalLiteral", ["style", "experimental", "opinionated"]],
  ["offBy1", ["diagnostic"]],
  ["paramTypeCombine", ["style", "opinionated"]],
  ["preferDecodeRune", ["performance", "experimental"]],
  ["preferFilepathJoin", ["style", "experimental"]],
  ["preferFprint", ["performance", "experimental"]],
  ["preferStringWriter", ["performance", "experimental"]],
  ["preferWriteByte", ["performance", "experimental", "opinionated"]],
  ["ptrToRefParam", ["style", "opinionated", "experimental"]],
  ["rangeAppendAll", ["diagnostic", "experimental"]],
  ["rangeExprCopy", ["performance"]],
  ["rangeValCopy", ["performance"]],
  ["redundantSprint", ["style", "experimental"]],
  ["regexpMust", ["style"]],
  ["regexpPattern", ["diagnostic", "experimental"]],
  ["regexpSimplify", ["style", "experimental", "opinionated"]],
  ["returnAfterHttpError", ["diagnostic", "experimental"]],
  ["ruleguard", ["style", "experimental"]],
  ["singleCaseSwitch", ["style"]],
  ["sliceClear", ["performance", "experimental"]],
  ["sloppyLen", ["diagnostic"]],
  ["sloppyReassign", ["diagnostic", "experimental"]],
  ["sloppyTypeAssert", ["diagnostic"]],
  ["sortSlice", ["diagnostic", "experimental"]],
  ["sprintfQuotedString", ["diagnostic", "experimental"]],
  ["sqlQuery", ["diagnostic", "experimental"]],
  ["stringConcatSimplify", ["style", "experimental"]],
  ["stringXbytes", ["performance"]],
  ["stringsCompare", ["style", "experimental"]],
  ["switchTrue", ["style"]],
  ["syncMapLoadAndDelete", ["diagnostic", "experimental"]],
  ["timeExprSimplify", ["style", "experimental"]],
  ["todoCommentWithoutDetail", ["style", "opinionated", "experimental"]],
  ["tooManyResultsChecker", ["style", "opinionated", "experimental"]],
  ["truncateCmp", ["diagnostic", "experimental"]],
  ["typeAssertChain", ["style", "experimental"]],
  ["typeDefFirst", ["style", "experimental"]],
  ["typeSwitchVar", ["style"]],
  ["typeUnparen", ["style", "opinionated"]],
  ["uncheckedInlineErr", ["diagnostic", "experimental"]],
  ["underef", ["style"]],
  ["unlabelStmt", ["style", "experimental"]],
  ["unlambda", ["style"]],
  ["unnamedResult", ["style", "opinionated", "experimental"]],
  ["unnecessaryBlock", ["style", "opinionated", "experimental"]],
  ["unnecessaryDefer", ["diagnostic", "experimental"]],
  ["unslice", ["style"]],
  ["valSwap", ["style"]],
  ["weakCond", ["diagnostic", "experimental"]],
  ["whyNoLint", ["style", "experimental"]],
  ["wrapperFunc", ["style"]],
  ["yodaStyleExpr", ["style", "experimental"]],
  ["zeroByteRepeat", ["performance"]],
];

const docText: Record<string, string> = {
  appendAssign: `appendAssign checker documentation
URL: https://github.com/go-critic/go-critic/checkers
Tags: [diagnostic]

Detects suspicious append result assignments.

Non-compliant code:
p.positives = append(p.negatives, x)
p.negatives = append(p.negatives, y)

Compliant code:
p.positives = append(p.positives, x)
p.negatives = append(p.negatives, y)
`,
  elseif: `elseif checker documentation
URL: https://github.com/go-critic/go-critic/checkers
Tags: [style]

Detects else with nested if statement that can be replaced with else-if.

Non-compliant code:
if cond1 {
} else {
\tif x := cond2; x {
\t}
}

Compliant code:
if cond1 {
} else if x := cond2; x {
}

Checker parameters:
  -@elseif.skipBalanced bool
    \twhether to skip balanced if-else pairs (default true)
`,
  unslice: `unslice checker documentation
URL: https://github.com/go-critic/go-critic/checkers
Tags: [style]

Detects slice expressions that can be simplified to sliced expression itself.

Non-compliant code:
copy(b[:], values...)

Compliant code:
copy(b, values...)
`,
};

const helpText = `Usage:

    go-critic <command> [arguments...]

The commands are:

    check             run linter over specified targets
    doc               get installed checkers documentation
    help              shows help message
    version           shows version of the application

Version: ${version}
`;

const checkHelp = `Usage of go-critic:
  -@captLocal.paramsOnly
    \twhether to restrict checker to params only (default true)
  -@commentedOutCode.minLength int
    \tmin length of the comment that triggers a warning (default 15)
  -@elseif.skipBalanced
    \twhether to skip balanced if-else pairs (default true)
  -@hugeParam.sizeThreshold int
    \tsize in bytes that makes the warning trigger (default 80)
  -@ifElseChain.minThreshold int
    \tmin number of if-else blocks that makes the warning trigger (default 2)
  -@nestingReduce.bodyWidth int
    \tmin number of statements inside a branch to trigger a warning (default 5)
  -@rangeExprCopy.sizeThreshold int
    \tsize in bytes that makes the warning trigger (default 512)
  -@rangeExprCopy.skipTestFuncs
    \twhether to check test functions (default true)
  -@rangeValCopy.sizeThreshold int
    \tsize in bytes that makes the warning trigger (default 128)
  -@rangeValCopy.skipTestFuncs
    \twhether to check test functions (default true)
  -@ruleguard.debug string
    \tenable debug for the specified named rules group
  -@ruleguard.disable string
    \tcomma-separated list of disabled groups or skip empty to enable everything
  -@ruleguard.enable string
    \tcomma-separated list of enabled groups or skip empty to enable everything (default "<all>")
  -@ruleguard.failOn string
    \tDetermines the behavior when an error occurs while parsing ruleguard files.
    \tIf flag is not set, log error and skip rule files that contain an error.
    \tIf flag is set, the value must be a comma-separated list of error conditions.
    \t* 'import': rule refers to a package that cannot be loaded.
    \t* 'dsl':    gorule file does not comply with the ruleguard DSL.
  -@ruleguard.failOnError
    \tdeprecated, use failOn param; if set to true, identical to failOn='all', otherwise failOn=''
  -@ruleguard.rules string
    \tcomma-separated list of gorule file paths. Glob patterns such as 'rules-*.go' may be specified
  -@tooManyResultsChecker.maxResults int
    \tmaximum number of results (default 5)
  -@truncateCmp.skipArchDependent
    \twhether to skip int/uint/uintptr types (default true)
  -@underef.skipRecvDeref
    \twhether to skip (*x).method() calls where x is a pointer receiver (default true)
  -@unnamedResult.checkExported
    \twhether to check exported functions
  -checkGenerated
    \twhether to check generated files
  -checkTests
    \twhether to check test files (default true)
  -concurrency int
    \thow many concurrent checkers to run (default is runtime.GOMAXPROCS(0)) (default 14)
  -cpuprofile string
    \twrite CPU profile to the specified file
  -disable string
    \tcomma-separated list of checkers to be disabled. Can include #tags
  -enable string
    \tcomma-separated list of enabled checkers. Can include #tags (default "appendAssign,argOrder,assignOp,badCall,badCond,captLocal,caseOrder,codegenComment,commentFormatting,defaultCaseOrder,deprecatedComment,dupArg,dupBranchBody,dupCase,dupSubExpr,elseif,exitAfterDefer,flagDeref,flagName,ifElseChain,mapKey,newDeref,offBy1,regexpMust,singleCaseSwitch,sloppyLen,sloppyTypeAssert,switchTrue,typeSwitchVar,underef,unlambda,unslice,valSwap,wrapperFunc")
  -enableAll
    \tidentical to -enable with all checkers listed. If true, -enable is ignored
  -exitCode int
    \texit code to be used when lint issues are found (default 1)
  -go string
    \tselect the Go version to target. Leave as string for the latest
  -memprofile string
    \twrite memory profile to the specified file
  -shorterErrLocation
    \twhether to replace error location prefix with $GOROOT and $GOPATH (default true)
  -v\twhether to print output useful during linter debugging
`;

function main(): void {
  const args = process.argv.slice(2);
  if (args.length === 0) {
    process.stderr.write("no args provided\n");
    process.exit(1);
  }
  const [cmd, ...rest] = args;
  if (cmd === "help") {
    process.stdout.write(helpText);
    return;
  }
  if (cmd === "version") {
    process.stdout.write(`go-critic version: ${version}\n`);
    return;
  }
  if (cmd === "doc") {
    doc(rest);
    return;
  }
  if (cmd === "check") {
    check(rest);
    return;
  }
  const suggestion = cmd === "--help" ? "help" : "doc";
  process.stderr.write(`"${cmd}" unknown command, did you mean "${suggestion}"?\nRun "go-critic help" for usage.\n\nno such command "${cmd}"\n`);
}

function doc(args: string[]): void {
  if (args.includes("-help") || args.includes("--help")) {
    process.stderr.write("Usage of go-critic:\nflag: help requested\n");
    process.exit(1);
  }
  if (args.length > 1) {
    process.stderr.write("expected 0 or 1 positional arguments\n");
    process.exit(1);
  }
  if (args.length === 0) {
    for (const [name, tags] of checkers) {
      process.stdout.write(`${name} [${tags.join(" ")}]\n`);
    }
    return;
  }
  const name = args[0];
  if (docText[name]) {
    process.stdout.write(docText[name]);
    return;
  }
  const found = checkers.find(([n]) => n === name);
  if (!found) {
    process.stderr.write(`checker with name "${name}" not found\n`);
    return;
  }
  process.stdout.write(`${name} checker documentation\nURL: https://github.com/go-critic/go-critic/checkers\nTags: [${found[1].join(" ")}]\n`);
}

function check(args: string[]): void {
  if (args.includes("-help") || args.includes("--help") || args.includes("-h")) {
    process.stderr.write(checkHelp + "parse args: flag: help requested\n");
    process.exit(1);
  }
  for (const arg of args) {
    if (arg.startsWith("-") && !knownFlag(arg)) {
      process.stderr.write(`flag provided but not defined: ${arg}\n${checkHelp}parse args: flag provided but not defined: ${arg}\n`);
      process.exit(1);
    }
  }
  if (!hasGo()) {
    process.stderr.write('load packages: err: go command required, not found: exec: "go": executable file not found in $PATH: stderr: \n');
    process.exit(1);
  }
  const targets = args.filter(a => !a.startsWith("-") && !looksLikeFlagValue(a));
  const files = collectGoFiles(targets.length ? targets : ["."]);
  const issues: string[] = [];
  for (const file of files) {
    issues.push(...lintFile(file));
  }
  for (const issue of issues) process.stdout.write(issue + "\n");
  if (issues.length) process.exit(exitCode(args));
}

function knownFlag(arg: string): boolean {
  const key = arg.split("=")[0];
  return [
    "-v", "-enableAll", "-checkGenerated", "-checkTests", "-shorterErrLocation",
    "-@captLocal.paramsOnly", "-@elseif.skipBalanced", "-@rangeExprCopy.skipTestFuncs",
    "-@rangeValCopy.skipTestFuncs", "-@ruleguard.failOnError", "-@truncateCmp.skipArchDependent",
    "-@underef.skipRecvDeref", "-@unnamedResult.checkExported",
    "-enable", "-disable", "-exitCode", "-go", "-concurrency", "-cpuprofile", "-memprofile",
    "-@commentedOutCode.minLength", "-@hugeParam.sizeThreshold", "-@ifElseChain.minThreshold",
    "-@nestingReduce.bodyWidth", "-@rangeExprCopy.sizeThreshold", "-@rangeValCopy.sizeThreshold",
    "-@ruleguard.debug", "-@ruleguard.disable", "-@ruleguard.enable", "-@ruleguard.failOn",
    "-@ruleguard.rules", "-@tooManyResultsChecker.maxResults",
  ].includes(key);
}

function looksLikeFlagValue(_: string): boolean {
  return false;
}

function hasGo(): boolean {
  const r = spawnSync("go", ["version"], { encoding: "utf8" });
  return !r.error && r.status === 0;
}

function exitCode(args: string[]): number {
  const idx = args.findIndex(a => a === "-exitCode" || a.startsWith("-exitCode="));
  if (idx === -1) return 1;
  const raw = args[idx].includes("=") ? args[idx].split("=")[1] : args[idx + 1];
  const n = Number(raw);
  return Number.isFinite(n) ? n : 1;
}

function collectGoFiles(targets: string[]): string[] {
  const out: string[] = [];
  for (const target of targets) {
    if (!existsSync(target)) continue;
    const st = statSync(target);
    if (st.isFile() && target.endsWith(".go")) out.push(target);
    if (st.isDirectory()) walk(target, out);
  }
  return out;
}

function walk(dir: string, out: string[]): void {
  for (const name of readdirSync(dir)) {
    if (name === ".git" || name === "node_modules" || name === "dist") continue;
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) walk(p, out);
    else if (st.isFile() && p.endsWith(".go")) out.push(p);
  }
}

function lintFile(file: string): string[] {
  const src = readFileSync(file, "utf8");
  const lines = src.split(/\r?\n/);
  const issues: string[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let m = line.match(/\b([A-Za-z_][\w.]*)\s*=\s*append\(\s*([A-Za-z_][\w.]*)\s*,/);
    if (m && m[1] !== m[2]) issues.push(fmt(file, i + 1, line.indexOf("append(") + 1, "appendAssign", `append result not assigned to the same slice`));
    if (/\belse\s*\{\s*if\b/.test(line)) issues.push(fmt(file, i + 1, line.indexOf("else") + 1, "elseif", "can replace 'else {if cond {}}' with 'else if cond {}'"));
    m = line.match(/\b(copy|append)\s*\([^,\n]*\[:\]/);
    if (m) issues.push(fmt(file, i + 1, line.indexOf("[:]") + 1, "unslice", "could simplify slice expression"));
    if (/\bswitch\s+true\s*\{/.test(line)) issues.push(fmt(file, i + 1, line.indexOf("switch") + 1, "switchTrue", "could remove true from switch statement"));
    if (/\bif\s+len\([^)]+\)\s*(?:!=\s*0|>\s*0)/.test(line)) issues.push(fmt(file, i + 1, line.indexOf("len(") + 1, "sloppyLen", "length check can be simplified"));
    if (/\bregexp\.Compile\(/.test(line) || /\bregexp\.CompilePOSIX\(/.test(line)) issues.push(fmt(file, i + 1, line.indexOf("regexp.") + 1, "regexpMust", "can use regexp.MustCompile"));
  }
  return issues;
}

function fmt(file: string, line: number, col: number, checker: string, msg: string): string {
  return `${file}:${line}:${Math.max(1, col)}: ${checker}: ${msg}`;
}

main();
