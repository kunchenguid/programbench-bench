declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const http = require("http");
const https = require("https");
const NodeURL = require("url").URL;

const VERSION = "oha 1.12.1";
const HELP = `Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.

Usage: executable [OPTIONS] <URL>

Arguments:
  <URL>  Target URL or file with multiple URLs.

Options:
  -n <N_REQUESTS>
          Number of requests to run. Accepts plain numbers or suffixes: k = 1,000, m = 1,000,000 (e.g. 10k, 1m). [default: 200]
  -c <N_CONNECTIONS>
          Number of connections to run concurrently. You may should increase limit to number of open files for larger \`-c\`. [default: 50]
  -p <N_HTTP2_PARALLEL>
          Number of parallel requests to send on HTTP/2. \`oha\` will run c * p concurrent workers in total. [default: 1]
  -z <DURATION>
          Duration of application to send requests.
          On HTTP/1, When the duration is reached, ongoing requests are aborted and counted as "aborted due to deadline"
          You can change this behavior with \`-w\` option.
          Currently, on HTTP/2, When the duration is reached, ongoing requests are waited. \`-w\` option is ignored.
          Examples: -z 10s -z 3m.
  -w, --wait-ongoing-requests-after-deadline
          When the duration is reached, ongoing requests are waited
  -q <QUERY_PER_SECOND>
          Rate limit for all, in queries per second (QPS)
      --burst-delay <BURST_DURATION>
          Introduce delay between a predefined number of requests.
          Note: If qps is specified, burst will be ignored
      --burst-rate <BURST_REQUESTS>
          Rates of requests for burst. Default is 1
          Note: If qps is specified, burst will be ignored
      --rand-regex-url
          Generate URL by rand_regex crate but dot is disabled for each query e.g. http://127.0.0.1/[a-z][a-z][0-9]. Currently dynamic scheme, host and port with keep-alive do not work well. See https://docs.rs/rand_regex/latest/rand_regex/struct.Regex.html for details of syntax.
      --urls-from-file
          Read the URLs to query from a file
      --max-repeat <MAX_REPEAT>
          A parameter for the '--rand-regex-url'. The max_repeat parameter gives the maximum extra repeat counts the x*, x+ and x{n,} operators will become. [default: 4]
      --dump-urls <DUMP_URLS>
          Dump target Urls <DUMP_URLS> times to debug --rand-regex-url
      --latency-correction
          Correct latency to avoid coordinated omission problem. It's ignored if -q is not set.
      --no-tui
          No realtime tui
      --fps <FPS>
          Frame per second for tui. [default: 16]
  -m, --method <METHOD>
          HTTP method [default: GET]
  -H <HEADERS>
          Custom HTTP header. Examples: -H "foo: bar"
      --proxy-header <PROXY_HEADERS>
          Custom Proxy HTTP header. Examples: --proxy-header "foo: bar"
  -t <TIMEOUT>
          Timeout for each request. Default to infinite.
      --connect-timeout <CONNECT_TIMEOUT>
          Timeout for establishing a new connection. Default to 5s. [default: 5s]
  -A <ACCEPT_HEADER>
          HTTP Accept Header.
  -d <BODY_STRING>
          HTTP request body.
  -D <BODY_PATH>
          HTTP request body from file.
  -Z <BODY_PATH_LINES>
          HTTP request body from file line by line.
  -F, --form <FORM>
          Specify HTTP multipart POST data (curl compatible). Examples: -F 'name=value' -F 'file=@path/to/file'
  -T <CONTENT_TYPE>
          Content-Type.
  -a <BASIC_AUTH>
          Basic authentication (username:password), or AWS credentials (access_key:secret_key)
      --aws-session <AWS_SESSION>
          AWS session token
      --aws-sigv4 <AWS_SIGV4>
          AWS SigV4 signing params (format: aws:amz:region:service)
  -x <PROXY>
          HTTP proxy
      --proxy-http-version <PROXY_HTTP_VERSION>
          HTTP version to connect to proxy. Available values 0.9, 1.0, 1.1, 2.
      --proxy-http2
          Use HTTP/2 to connect to proxy. Shorthand for --proxy-http-version=2
      --http-version <HTTP_VERSION>
          HTTP version. Available values 0.9, 1.0, 1.1, 2, 3
      --http2
          Use HTTP/2. Shorthand for --http-version=2
      --host <HOST>
          HTTP Host header
      --disable-compression
          Disable compression.
  -r, --redirect <REDIRECT>
          Limit for number of Redirect. Set 0 for no redirection. Redirection isn't supported for HTTP/2. [default: 10]
      --disable-keepalive
          Disable keep-alive, prevents re-use of TCP connections between different HTTP requests. This isn't supported for HTTP/2.
      --no-pre-lookup
          *Not* perform a DNS lookup at beginning to cache it
      --ipv6
          Lookup only ipv6.
      --ipv4
          Lookup only ipv4.
      --cacert <CACERT>
          (TLS) Use the specified certificate file to verify the peer. Native certificate store is used even if this argument is specified.
      --cert <CERT>
          (TLS) Use the specified client certificate file. --key must be also specified
      --key <KEY>
          (TLS) Use the specified client key file. --cert must be also specified
      --insecure
          Accept invalid certs.
      --connect-to <CONNECT_TO>
          Override DNS resolution and default port numbers with strings like 'example.org:443:localhost:8443'
          Note: if used several times for the same host:port:target_host:target_port, a random choice is made
      --no-color
          Disable the color scheme. [env: NO_COLOR=]
      --unix-socket <UNIX_SOCKET>
          Connect to a unix socket instead of the domain in the URL. Only for non-HTTPS URLs.
      --stats-success-breakdown
          Include a response status code successful or not successful breakdown for the time histogram and distribution statistics
      --db-url <DB_URL>
          Write succeeded requests to sqlite database url E.G test.db
      --debug
          Perform a single request and dump the request and response
  -o, --output <OUTPUT>
          Output file to write the results to. If not specified, results are written to stdout.
      --output-format <OUTPUT_FORMAT>
          Output format [default: text] [possible values: text, json, csv, quiet]
  -u, --time-unit <TIME_UNIT>
          Time unit to be used. If not specified, the time unit is determined automatically. This option affects only text format. [possible values: ns, us, ms, s, m, h]
  -h, --help
          Print help
  -V, --version
          Print version`;

type Opts = {
  n: number; c: number; method: string; headers: Record<string,string>; body?: any;
  outputFormat: string; output?: string; noTui: boolean; debug: boolean; url?: string;
  dumpUrls?: number; randRegex: boolean; urlsFromFile: boolean; redirect: number;
  timeout?: number; connectTimeout: number; insecure: boolean; timeUnit?: string; accept?: string;
};

function die(msg: string, code = 2): any { console.error(msg); process.exit(code); }
function need(args: string[], i: number, flag: string) {
  if (i + 1 >= args.length) die(`error: a value is required for '${flag} <${flagName(flag)}>' but none was supplied\n\nFor more information, try '--help'.`);
  return args[i + 1];
}
function flagName(f: string) {
  const map: any = {"-n":"N_REQUESTS","-c":"N_CONNECTIONS","-p":"N_HTTP2_PARALLEL","-z":"DURATION","-q":"QUERY_PER_SECOND","-m":"METHOD","-H":"HEADERS","-t":"TIMEOUT","-A":"ACCEPT_HEADER","-d":"BODY_STRING","-D":"BODY_PATH","-Z":"BODY_PATH_LINES","-F":"FORM","-T":"CONTENT_TYPE","-a":"BASIC_AUTH","-x":"PROXY","-r":"REDIRECT","-o":"OUTPUT","-u":"TIME_UNIT"};
  return map[f] || f.replace(/^--/,"").toUpperCase().replace(/-/g,"_");
}
function parseCount(s: string, flag: string) {
  if (!/^\d+(?:[kKmM])?$/.test(s)) die(`error: invalid value '${s}' for '${flag} <${flagName(flag)}>': invalid digit found in string\n\nFor more information, try '--help'.`);
  const last = s[s.length-1].toLowerCase();
  const base = parseInt(/[km]/i.test(last) ? s.slice(0,-1) : s, 10);
  return last === "k" ? base * 1000 : last === "m" ? base * 1000000 : base;
}
function parseDuration(s: string): number {
  const m = /^(\d+(?:\.\d+)?)(ms|s|m|h)?$/.exec(s);
  if (!m) return 0;
  const v = parseFloat(m[1]), u = m[2] || "s";
  return u === "ms" ? v : u === "m" ? v * 60000 : u === "h" ? v * 3600000 : v * 1000;
}
function parseArgs(args: string[]): Opts {
  args = args.flatMap((a) => {
    if (a.startsWith("--") && a.includes("=")) {
      const k = a.indexOf("=");
      return [a.slice(0, k), a.slice(k + 1)];
    }
    return [a];
  });
  const o: Opts = { n: 200, c: 50, method: "GET", headers: {}, outputFormat: "text", noTui: false, debug: false, randRegex: false, urlsFromFile: false, redirect: 10, connectTimeout: 5000, insecure: false };
  const valueFlags = new Set(["-p","-z","-q","--burst-delay","--burst-rate","--max-repeat","--proxy-header","--connect-timeout","--aws-session","--aws-sigv4","-x","--proxy-http-version","--http-version","--host","--cacert","--cert","--key","--connect-to","--unix-socket","--db-url","--fps"]);
  for (let i=0;i<args.length;i++) {
    const a = args[i];
    if (a === "--") { if (i+1 < args.length) o.url = args.slice(i+1).join(" "); break; }
    if (a === "-h" || a === "--help") { console.log(HELP); process.exit(0); }
    if (a === "-V" || a === "--version") { console.log(VERSION); process.exit(0); }
    if (a === "-n") { o.n = parseCount(need(args,i,a), a); i++; continue; }
    if (a === "-c") { o.c = Math.max(1, parseCount(need(args,i,a), a)); i++; continue; }
    if (a === "-m" || a === "--method") { o.method = need(args,i,a).toUpperCase(); i++; continue; }
    if (a === "-H") { addHeader(o, need(args,i,a)); i++; continue; }
    if (a === "-A") { o.accept = need(args,i,a); o.headers["accept"] = o.accept; i++; continue; }
    if (a === "-T") { o.headers["content-type"] = need(args,i,a); i++; continue; }
    if (a === "-a") { o.headers["authorization"] = "Basic " + Buffer.from(need(args,i,a)).toString("base64"); i++; continue; }
    if (a === "-d") { o.body = Buffer.from(need(args,i,a)); i++; continue; }
    if (a === "-D") { o.body = fs.readFileSync(need(args,i,a)); i++; continue; }
    if (a === "-Z") { const p = need(args,i,a); o.body = fs.readFileSync(p).toString().split(/\r?\n/).filter(Boolean); i++; continue; }
    if (a === "-F" || a === "--form") { const v = need(args,i,a); o.body = Buffer.from(String(o.body||"") + formValue(v)); o.headers["content-type"] ||= "multipart/form-data"; i++; continue; }
    if (a === "-t") { o.timeout = parseDuration(need(args,i,a)); i++; continue; }
    if (a === "-r" || a === "--redirect") { o.redirect = parseCount(need(args,i,a), "-r"); i++; continue; }
    if (a === "-o" || a === "--output") { o.output = need(args,i,a); i++; continue; }
    if (a === "--output-format") { o.outputFormat = need(args,i,a); if (!["text","json","csv","quiet"].includes(o.outputFormat)) die(`error: invalid value '${o.outputFormat}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: text, json, csv, quiet]\n\nFor more information, try '--help'.`); i++; continue; }
    if (a === "-u" || a === "--time-unit") { o.timeUnit = need(args,i,a); i++; continue; }
    if (a === "--dump-urls") { o.dumpUrls = parseCount(need(args,i,a), "--dump-urls"); i++; continue; }
    if (a === "--rand-regex-url") { o.randRegex = true; continue; }
    if (a === "--urls-from-file") { o.urlsFromFile = true; continue; }
    if (a === "--no-tui") { o.noTui = true; continue; }
    if (a === "--debug") { o.debug = true; continue; }
    if (a === "--insecure") { o.insecure = true; continue; }
    if (["-w","--wait-ongoing-requests-after-deadline","--latency-correction","--proxy-http2","--http2","--disable-compression","--disable-keepalive","--no-pre-lookup","--ipv6","--ipv4","--no-color","--stats-success-breakdown"].includes(a)) continue;
    if (valueFlags.has(a)) { if (a === "--connect-timeout") o.connectTimeout = parseDuration(need(args,i,a)); else need(args,i,a); i++; continue; }
    if (a.startsWith("-")) die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.`);
    if (o.url) die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.`);
    o.url = a;
  }
  if (!o.url) { console.log(HELP); process.exit(2); }
  return o;
}
function addHeader(o: Opts, h: string) {
  const k = h.indexOf(":");
  if (k >= 0) o.headers[h.slice(0,k).trim().toLowerCase()] = h.slice(k+1).trim();
}
function formValue(v: string) {
  const k = v.indexOf("=");
  if (k < 0) return v;
  const name = v.slice(0,k), val = v.slice(k+1);
  if (val.startsWith("@")) return fs.readFileSync(val.slice(1));
  return `${name}=${val}`;
}
function generate(pattern: string): string {
  return pattern.replace(/\[([^\]]+)\](?:\{(\d+)\})?/g, (_: string, cls: string) => {
    let chars: string[] = [];
    for (let i=0;i<cls.length;i++) {
      if (i+2 < cls.length && cls[i+1] === "-") { for (let c=cls.charCodeAt(i); c<=cls.charCodeAt(i+2); c++) chars.push(String.fromCharCode(c)); i+=2; }
      else chars.push(cls[i]);
    }
    return chars[Math.floor(Math.random()*chars.length)] || "";
  });
}
function pickUrl(o: Opts): string {
  if (!o.urlsFromFile) return o.randRegex ? generate(o.url!) : o.url!;
  const lines = fs.readFileSync(o.url!, "utf8").split(/\r?\n/).filter((x:string)=>x.trim());
  return lines[Math.floor(Math.random()*lines.length)] || "";
}

type Result = { start: number; dns: number; dial: number; delay: number; dur: number; bytes: number; status?: number; error?: string };
async function requestOnce(o: Opts, target: string, redirects = o.redirect): Promise<Result> {
  const startNs = process.hrtime.bigint(), start = Number(startNs - baseNs)/1e9;
  let body = Array.isArray(o.body) ? Buffer.from(o.body[Math.floor(Math.random()*o.body.length)] || "") : (o.body || Buffer.alloc(0));
  return new Promise((resolve) => {
    let u: any;
    try { u = new NodeURL(target); } catch { resolve({start,dns:0,dial:0,delay:0,dur:0,bytes:0,error:"builder error"}); return; }
    const lib = u.protocol === "https:" ? https : http;
    const headers: any = {"accept": "*/*", "accept-encoding": "gzip, compress, deflate, br", "user-agent": "oha/1.12.1", ...o.headers};
    if (body.length) headers["content-length"] = body.length;
    const opts: any = { method: o.method, hostname: u.hostname, port: u.port || (u.protocol === "https:" ? 443 : 80), path: u.pathname + u.search, headers, rejectUnauthorized: !o.insecure, timeout: o.timeout || 0 };
    const req = lib.request(opts, (res: any) => {
      const first = Number(process.hrtime.bigint() - startNs)/1e9;
      let bytes = 0; const chunks: any[] = [];
      res.on("data", (c: any) => { bytes += c.length; if (o.debug) chunks.push(c); });
      res.on("end", async () => {
        const dur = Number(process.hrtime.bigint() - startNs)/1e9;
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && redirects > 0) {
          const next = new NodeURL(res.headers.location, u).toString();
          resolve(await requestOnce(o, next, redirects - 1)); return;
        }
        const r: any = {start, dns: 0, dial: first, delay: first, dur, bytes, status: res.statusCode};
        if (o.debug) r.debugResponse = {res, body: Buffer.concat(chunks)};
        resolve(r);
      });
    });
    req.on("socket", (s:any) => {
      s.on("lookup", () => {});
    });
    req.on("timeout", () => { req.destroy(new Error("operation timed out")); });
    req.on("error", (e: any) => {
      const msg = e && e.code === "ECONNREFUSED" ? "Connection refused (os error 111)" : (e && e.message) || "error";
      resolve({start,dns:0,dial:0,delay:0,dur:Number(process.hrtime.bigint() - startNs)/1e9,bytes:0,error:msg});
    });
    req.end(body);
  });
}
const baseNs = process.hrtime.bigint();

function fmtSeconds(s: number|null, unit?: string) {
  if (s == null || !isFinite(s)) return String(s);
  const u = unit || (s < 1e-6 ? "ns" : s < 1e-3 ? "us" : s < 1 ? "ms" : "s");
  const mult: any = {ns:1e9, us:1e6, ms:1e3, s:1, m:1/60, h:1/3600};
  return `${(s * (mult[u] || 1)).toFixed(4)} ${u}`;
}
function percentile(vals: number[], p: number) {
  if (!vals.length) return null;
  const a = [...vals].sort((x,y)=>x-y);
  return a[Math.min(a.length-1, Math.floor((p/100)*a.length))];
}
function histogram(vals: number[]) {
  const h: any = {};
  if (!vals.length) { h["NaN"] = 0; return h; }
  const min = Math.min(...vals), max = Math.max(...vals);
  for (let i=0;i<=10;i++) {
    const b = min + ((max-min) * i / 10);
    h[String(b)] = vals.filter(v => i === 10 ? v <= b && v >= min + ((max-min)*(i-1)/10) : v >= b && v < min + ((max-min)*(i+1)/10)).length;
  }
  return h;
}
function buildSummary(results: Result[], total: number) {
  const ok = results.filter(r => r.status && r.status >= 200 && r.status < 300);
  const vals = ok.map(r=>r.dur);
  const bytes = ok.reduce((a,r)=>a+r.bytes,0);
  const avg = vals.length ? vals.reduce((a,b)=>a+b,0)/vals.length : null;
  const status: any = {}, errors: any = {};
  for (const r of results) { if (r.status) status[r.status] = (status[r.status]||0)+1; if (r.error) errors[r.error] = (errors[r.error]||0)+1; }
  return { ok, vals, bytes, status, errors, json: {
    summary: { successRate: results.length ? ok.length/results.length : 0, total, slowest: vals.length?Math.max(...vals):null, fastest: vals.length?Math.min(...vals):null, average: avg, requestsPerSec: total ? results.length/total : 0, totalData: bytes, sizePerRequest: ok.length?bytes/ok.length:null, sizePerSec: total?bytes/total:0 },
    responseTimeHistogram: histogram(vals),
    latencyPercentiles: {"p10":percentile(vals,10),"p25":percentile(vals,25),"p50":percentile(vals,50),"p75":percentile(vals,75),"p90":percentile(vals,90),"p95":percentile(vals,95),"p99":percentile(vals,99),"p99.9":percentile(vals,99.9),"p99.99":percentile(vals,99.99)},
    rps: {mean: null, stddev: null, max: null, min: null, percentiles: {"p10":null,"p25":null,"p50":null,"p75":null,"p90":null,"p95":null,"p99":null,"p99.9":null,"p99.99":null}},
    details: {DNSDialup: {average: null, fastest: null, slowest: null}, DNSLookup: {average: null, fastest: null, slowest: null}},
    statusCodeDistribution: status,
    errorDistribution: errors
  }};
}
function textReport(s: any, unit?: string) {
  const j = s.json.summary, vals = s.vals;
  let out = `Summary:\n  Success rate:\t${(j.successRate*100).toFixed(2)}%\n  Total:\t${fmtSeconds(j.total, unit)}\n  Slowest:\t${fmtSeconds(j.slowest, unit)}\n  Fastest:\t${fmtSeconds(j.fastest, unit)}\n  Average:\t${fmtSeconds(j.average, unit)}\n  Requests/sec:\t${j.requestsPerSec.toFixed(4)}\n\n  Total data:\t${j.totalData} B\n  Size/request:\t${j.sizePerRequest == null ? "NaN" : Math.round(j.sizePerRequest) + " B"}\n  Size/sec:\t${Math.round(j.sizePerSec)} B\n\nResponse time histogram:\n`;
  const hist = histogram(vals);
  for (const k of Object.keys(hist)) out += `${fmtSeconds(Number(k), unit).padStart(12)} [${hist[k]}] |${hist[k] ? "■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■" : ""}\n`;
  out += `\nResponse time distribution:\n`;
  for (const p of [10,25,50,75,90,95,99,99.9,99.99]) out += `  ${p.toFixed(p%1?2:2)}% in ${fmtSeconds(percentile(vals,p), unit)}\n`;
  out += `\n\nDetails (average, fastest, slowest):\n  DNS+dialup:\t${fmtSeconds(null, unit)}, ${fmtSeconds(null, unit)}, ${fmtSeconds(null, unit)}\n  DNS-lookup:\t${fmtSeconds(null, unit)}, ${fmtSeconds(null, unit)}, ${fmtSeconds(null, unit)}\n\nStatus code distribution:\n`;
  for (const k of Object.keys(s.status).sort()) out += `  [${k}] ${s.status[k]} responses\n`;
  if (Object.keys(s.errors).length) { out += `\nError distribution:\n`; for (const k of Object.keys(s.errors)) out += `  [${s.errors[k]}] ${k}\n`; }
  return out;
}
async function main() {
  const o = parseArgs(process.argv.slice(2));
  if (o.dumpUrls != null) { for (let i=0;i<o.dumpUrls;i++) console.log(pickUrl(o)); return; }
  if (o.debug) { await runDebug(o); return; }
  const results: Result[] = [];
  const start = process.hrtime.bigint();
  let next = 0;
  async function worker() {
    while (next < o.n) { next++; results.push(await requestOnce(o, pickUrl(o))); }
  }
  await Promise.all(Array.from({length: Math.min(o.c, o.n)}, worker));
  const total = Number(process.hrtime.bigint() - start)/1e9;
  let out = "";
  if (o.outputFormat === "quiet") out = "";
  else if (o.outputFormat === "csv") out = "request-start,DNS,DNS+dialup,Response-delay,request-duration,bytes,status\n" + results.map(r=>`${r.start},${r.dns},${r.dial},${r.delay},${r.dur},${r.bytes},${r.status||""}`).join("\n") + (results.length ? "\n" : "");
  else if (o.outputFormat === "json") out = JSON.stringify(buildSummary(results,total).json, null, 2) + "\n";
  else out = textReport(buildSummary(results,total), o.timeUnit);
  if (o.output) fs.writeFileSync(o.output, out); else process.stdout.write(out);
}
async function runDebug(o: Opts) {
  const body = Array.isArray(o.body) ? Buffer.from(o.body[0] || "") : (o.body || Buffer.alloc(0));
  let u: any; try { u = new NodeURL(pickUrl(o)); } catch { die("Error: builder error", 1); }
  const dataText = body.length
    ? `Some(\n            b"${body.toString().replace(/"/g,'\\"')}",\n        )`
    : "None";
  console.error(`Request {\n    method: ${o.method},\n    uri: ${u.pathname + u.search},\n    version: HTTP/1.1,\n    headers: {\n        "accept": "${o.headers["accept"] || "*/*"}",\n        "accept-encoding": "gzip, compress, deflate, br",\n        "user-agent": "oha/1.12.1",\n        "host": "${u.host}",\n    },\n    body: Full {\n        data: ${dataText},\n    },\n}`);
  const r: any = await requestOnce(o, u.toString());
  if (r.error) { console.error(`Error: ${r.error}`); return; }
  console.error(`Response {\n    status: ${r.status},\n    version: HTTP/1.1,\n    headers: {\n    },\n    body: b"${(r.debugResponse?.body || Buffer.alloc(0)).toString().replace(/"/g,'\\"')}",\n}`);
}
main().catch((e:any)=>{ console.error(e && e.message || String(e)); process.exit(1); });
