declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");
const os = require("os");
const cp = require("child_process");

const VERSION_HELP = `# felix v2.16.1
A simple TUI file manager with vim-like keymapping.

## Usage
\`fx\` => Show items in the current directory.
\`fx <directory path>\` => Show items in the path.
Both relative and absolute path available.

## Options
\`--help\` | \`-h\`   => Print help.
\`--log\`  | \`-l\`   => Launch the app, automatically generating a log file.
\`--init\`          => Returns a shell script that can be sourcedfor
                     for shell integration.

## Manual
j / <Down>         :Go down.
k / <Up>           :Go up.
<C-d>              :Go down 1/2 page.
<C-u>>             :Go up 1/2 page.
h / <Left>         :Go to the parent directory if exists.
l / <Right> / <CR> :Open item or change directory.
gg                 :Go to the top.
G                  :Go to the bottom.
z<CR>              :Go to the home directory.
z {keyword}<CR>    :Jump to a directory that matches the keyword.
                    (zoxide required)
<C-o>              :Jump backward.
<C-i>              :Jump forward.
i{file name}<CR>   :Create a new empty file.
I{dir name}<CR>    :Create a new empty directory.
o                  :Open item in a new window.
e                  :Unpack archive/compressed file.
dd                 :Delete and yank item.
yy                 :Yank item.
p                  :Put yanked item(s) from register zero
                    in the current directory.
:reg               :Show registers. To hide it, press v.
"ayy               :Yank item to register a.
"add               :Delete and yank item to register a.
"Ayy               :Append item to register a.
"Add               :Delete and append item to register a.
"ap                :Put item(s) from register a.
V                  :Switch to the linewise visual mode.
  - y              :In the visual mode, yank selected item(s).
  - d              :In the visual mode, delete and yank selected item(s).
  - "ay            :In the visual mode, yank items to register a.
  - "ad            :In the visual mode, delete and yank items to register a.
  - "Ay            :In the visual mode, append items to register a.
  - "Ad            :In the visual mode, delete and append items to register a.
  - c              :Rename selected items in default editor.
u                  :Undo put/delete/rename.
<C-r>              :Redo put/delete/rename.
v                  :Toggle whether to show the preview.
s                  :Toggle between vertical / horizontal split in the preview mode.
<Alt-j>
 / <Alt-<Down>>    :Scroll down the preview text.
<Alt-k> 
 / <Alt-<Up>>      :Scroll up the preview text.
<BS>               :Toggle whether to show hidden items.
t                  :Toggle the sort order (name <-> modified time).
c                  :Switch to the rename mode.
/{keyword}         :Search items by a keyword.
n                  :Go forward to the item that matches the keyword.
N                  :Go backward to the item that matches the keyword.
:                  :Switch to the command line.
  - <C-r>a         :In the command line, paste item name in register a.
:cd<CR>            :Go to the home directory.
:cd {path}<CR>     :Go to the path.
:e<CR>             :Reload the current directory.
:config<CR>        :Go to the directory that contains the config file if exists.
:trash<CR>         :Go to the trash directory.
:empty<CR>         :Empty the trash directory.
:h<CR>             :Show help.
:q<CR>             :Exit.
:{command}         :Execute a command e.g. :zip test *.md
<Esc>              :Return to the normal mode.
<C-h>              :Works as Backspace after \`i\`, \`I\`, \`c\`, \`/\`, \`:\` and \`z\`.
ZZ                 :Exit without cd to last working directory
                    (if \`match_vim_exit_behavior\` is \`false\`).
ZQ                 :cd into the last working directory and exit
                    (if shell setting is ready and \`match_vim_exit_behavior is \`false\`).

## Preview feature
By default, text files and directories can be previewed.
To preview images, you need to install chafa (>= v1.10.0).
Please see https://hpjansson.org/chafa/

## Configuration

*Both \`config.yaml\` and \`config.yml\` work.*

### Linux
config file    : $XDG_CONFIG_HOME/felix/config.yaml(config.yml)
trash directory: $XDG_DATA_HOME/felix/trash
log files      : $XDG_DATA_HOME/felix/log

### macOS
On macOS, felix looks for the config file in the following locations:

1. \`$HOME/Library/Application Support/felix/config.yaml(config.yml)\`
2. \`$HOME/.config/felix/config.yaml\`

trash directory: $HOME/Library/Application Support/felix/trash
log files      : $HOME/Library/Application Support/felix/log

### Windows
config file     : $PROFILE\\\\AppData\\\\Roaming\\\\felix\\\\config.yaml(config.yml)
trash directory : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\trash
log files       : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\log

For more details, visit https://github.com/kyoheiu/felix
`;

const INIT_SNIPPET = `# To be eval'ed in the calling shell
  eval "$(
    if [ -n "$XDG_RUNTIME_DIR" ]; then
      runtime_dir="$XDG_RUNTIME_DIR/felix"
    elif [ -n "$TMPDIR" ]; then
      runtime_dir="$TMPDIR/felix"
    else
      runtime_dir=/tmp/felix
    fi

    mkdir -p "$runtime_dir"

    # Clean up leftover LWD files
    find "$runtime_dir" -type f -and -mmin +1 -delete

    cat << EOF
fx() {
  local RUNTIME_DIR="$runtime_dir"
  SHELL_PID=\\$\\$ command fx "\\$@"

  if [ -f "\\$RUNTIME_DIR/\\$\\$" ]; then
    cd "\\$(cat "\\$RUNTIME_DIR/\\$\\$")"
    rm "\\$RUNTIME_DIR/\\$\\$"
  fi
}
EOF
  )"
`;

type Entry = { name: string; full: string; isDir: boolean; mtime: number };

function dataHome(): string {
  if (process.env.XDG_DATA_HOME) return process.env.XDG_DATA_HOME;
  if (process.platform === "darwin") return path.join(os.homedir(), "Library", "Application Support");
  return path.join(os.homedir(), ".local", "share");
}

function configHome(): string {
  if (process.env.XDG_CONFIG_HOME) return process.env.XDG_CONFIG_HOME;
  return path.join(os.homedir(), ".config");
}

function felixData(...parts: string[]): string {
  return path.join(dataHome(), "felix", ...parts);
}

function pad(n: number): string { return String(n).padStart(2, "0"); }

function makeLog(): void {
  const dir = felixData("log");
  fs.mkdirSync(dir, { recursive: true });
  const d = new Date();
  const name = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}-${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}.log`;
  fs.writeFileSync(path.join(dir, name), `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())} [INFO] ===START===\n`);
}

function invalidPath(p: string): void {
  process.stdout.write("\n");
  process.stderr.write(`Invalid path: ${p}\n\`fx -h\` shows help.\n`);
}

function notDir(): void {
  process.stderr.write("Path should be directory.\n`fx -h` shows help.\n");
}

function copyRecursive(src: string, dst: string): void {
  const st = fs.lstatSync(src);
  if (st.isDirectory()) {
    fs.mkdirSync(dst, { recursive: true });
    for (const child of fs.readdirSync(src)) copyRecursive(path.join(src, child), path.join(dst, child));
  } else {
    fs.copyFileSync(src, dst);
  }
}

function uniqueDest(dir: string, base: string): string {
  let dest = path.join(dir, base);
  if (!fs.existsSync(dest)) return dest;
  const ext = path.extname(base);
  const stem = base.slice(0, base.length - ext.length);
  for (let i = 1; ; i++) {
    dest = path.join(dir, `${stem}_${i}${ext}`);
    if (!fs.existsSync(dest)) return dest;
  }
}

class App {
  cwd: string;
  cursor = 0;
  showHidden = false;
  sortTime = false;
  mode: "normal" | "cmd" | "inputFile" | "inputDir" | "search" | "rename" = "normal";
  buffer = "";
  status = "";
  pending = "";
  yank: string[] = [];
  search = "";
  entries: Entry[] = [];
  histBack: string[] = [];
  histForward: string[] = [];
  done = false;

  constructor(cwd: string) { this.cwd = cwd; this.refresh(); }

  refresh(): void {
    let names: string[] = [];
    try { names = fs.readdirSync(this.cwd); } catch (e: any) { this.status = String(e.message || e); }
    if (!this.showHidden) names = names.filter(n => !n.startsWith("."));
    this.entries = names.map(name => {
      const full = path.join(this.cwd, name);
      let st: any;
      try { st = fs.lstatSync(full); } catch { st = { isDirectory: () => false, mtimeMs: 0 }; }
      return { name, full, isDir: st.isDirectory(), mtime: st.mtimeMs || 0 };
    });
    this.entries.sort((a, b) => {
      if (this.sortTime && b.mtime !== a.mtime) return b.mtime - a.mtime;
      if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    if (this.cursor >= this.entries.length) this.cursor = Math.max(0, this.entries.length - 1);
  }

  render(): void {
    const rows = process.stdout.rows || 24;
    const cols = process.stdout.columns || 80;
    let out = "\x1b[?25l\x1b[H\x1b[2J";
    out += `felix ${this.cwd}\n`;
    out += `${this.entries.length} item(s)${this.showHidden ? " | hidden" : ""}${this.sortTime ? " | mtime" : ""}\n`;
    const max = Math.max(1, rows - 5);
    const start = Math.max(0, Math.min(this.cursor - Math.floor(max / 2), Math.max(0, this.entries.length - max)));
    for (let i = start; i < Math.min(this.entries.length, start + max); i++) {
      const e = this.entries[i];
      const mark = i === this.cursor ? ">" : " ";
      const suffix = e.isDir ? "/" : "";
      out += `${mark} ${e.name}${suffix}\n`.slice(0, cols);
    }
    while (out.split("\n").length < rows - 1) out += "\n";
    const prompt = this.mode === "cmd" ? `:${this.buffer}` :
      this.mode === "inputFile" ? `i${this.buffer}` :
      this.mode === "inputDir" ? `I${this.buffer}` :
      this.mode === "search" ? `/${this.buffer}` :
      this.mode === "rename" ? `c${this.buffer}` : this.status;
    out += prompt.slice(0, cols) + "\x1b[K";
    process.stdout.write(out);
  }

  selected(): Entry | undefined { return this.entries[this.cursor]; }
  move(n: number): void { this.cursor = Math.max(0, Math.min(this.entries.length - 1, this.cursor + n)); }
  cd(dir: string, record = true): void {
    const next = path.resolve(this.cwd, dir);
    if (!fs.existsSync(next)) { this.status = `Invalid path: ${dir}`; return; }
    if (!fs.statSync(next).isDirectory()) { this.status = "Path should be directory."; return; }
    if (record) { this.histBack.push(this.cwd); this.histForward = []; }
    this.cwd = next; this.cursor = 0; this.refresh();
  }
  open(): void {
    const e = this.selected(); if (!e) return;
    if (e.isDir) this.cd(e.full);
    else this.status = e.name;
  }
  currentPaths(): string[] { const e = this.selected(); return e ? [e.full] : []; }
  deleteSelected(): void {
    const e = this.selected(); if (!e) return;
    this.yank = [e.full];
    const trash = felixData("trash");
    fs.mkdirSync(trash, { recursive: true });
    try { fs.renameSync(e.full, uniqueDest(trash, e.name)); this.status = `${e.name} moved to trash`; }
    catch (err: any) { this.status = String(err.message || err); }
    this.refresh();
  }
  put(): void {
    for (const src of this.yank) {
      if (fs.existsSync(src)) copyRecursive(src, uniqueDest(this.cwd, path.basename(src)));
      else {
        const trashFile = path.join(felixData("trash"), path.basename(src));
        if (fs.existsSync(trashFile)) copyRecursive(trashFile, uniqueDest(this.cwd, path.basename(src)));
      }
    }
    this.status = "put"; this.refresh();
  }
  unpack(): void {
    const e = this.selected(); if (!e) return;
    const q = (s: string) => JSON.stringify(s);
    const f = e.full;
    let cmd = "";
    if (/\.tar\.gz$|\.tgz$/.test(f)) cmd = `tar xzf ${q(f)} -C ${q(this.cwd)}`;
    else if (/\.tar\.xz$/.test(f)) cmd = `tar xJf ${q(f)} -C ${q(this.cwd)}`;
    else if (/\.tar\.zst$/.test(f)) cmd = `tar --zstd -xf ${q(f)} -C ${q(this.cwd)}`;
    else if (/\.tar$/.test(f)) cmd = `tar xf ${q(f)} -C ${q(this.cwd)}`;
    else if (/\.zip$/.test(f)) cmd = `unzip -o ${q(f)} -d ${q(this.cwd)}`;
    else if (/\.gz$/.test(f)) cmd = `gzip -dk ${q(f)}`;
    else { this.status = "Unsupported archive"; return; }
    try { cp.execSync(cmd, { stdio: "ignore" }); this.status = "unpacked"; }
    catch (err: any) { this.status = "unpack failed"; }
    this.refresh();
  }
  command(cmd: string): void {
    const trimmed = cmd.trim();
    if (trimmed === "q") { this.done = true; return; }
    if (trimmed === "h") { this.status = "help"; process.stdout.write("\x1b[H\x1b[2J" + VERSION_HELP); return; }
    if (trimmed === "e") { this.refresh(); this.status = "reloaded"; return; }
    if (trimmed === "cd") { this.cd(os.homedir()); return; }
    if (trimmed.startsWith("cd ")) { this.cd(trimmed.slice(3).trim()); return; }
    if (trimmed === "trash") { this.cd(felixData("trash")); return; }
    if (trimmed === "empty") { fs.rmSync(felixData("trash"), { recursive: true, force: true }); fs.mkdirSync(felixData("trash"), { recursive: true }); this.refresh(); return; }
    if (trimmed === "config") { this.cd(path.join(configHome(), "felix")); return; }
    if (trimmed === "reg") { this.status = this.yank.map(path.basename).join(" "); return; }
    if (trimmed) {
      try { cp.execSync(trimmed, { cwd: this.cwd, stdio: "inherit", shell: "/bin/bash" }); this.status = "done"; }
      catch { this.status = "command failed"; }
      this.refresh();
    }
  }
  finishInput(): void {
    const b = this.buffer; this.buffer = "";
    if (this.mode === "inputFile" && b) { fs.closeSync(fs.openSync(path.join(this.cwd, b), "a")); this.refresh(); }
    else if (this.mode === "inputDir" && b) { fs.mkdirSync(path.join(this.cwd, b), { recursive: true }); this.refresh(); }
    else if (this.mode === "search") { this.search = b; this.find(1); }
    else if (this.mode === "rename" && b) {
      const e = this.selected(); if (e) { fs.renameSync(e.full, path.join(this.cwd, b)); this.refresh(); }
    } else if (this.mode === "cmd") this.command(b);
    this.mode = "normal";
  }
  find(dir: number): void {
    if (!this.search || !this.entries.length) return;
    for (let step = 1; step <= this.entries.length; step++) {
      const i = (this.cursor + dir * step + this.entries.length) % this.entries.length;
      if (this.entries[i].name.includes(this.search)) { this.cursor = i; return; }
    }
  }
  key(s: string): void {
    if (this.mode !== "normal") {
      if (s === "\r" || s === "\n") { this.finishInput(); return; }
      if (s === "\x1b") { this.mode = "normal"; this.buffer = ""; return; }
      if (s === "\x7f" || s === "\x08") { this.buffer = this.buffer.slice(0, -1); return; }
      if (s >= " ") this.buffer += s;
      return;
    }
    if (s === "\x1b[A" || s === "k") this.move(-1);
    else if (s === "\x1b[B" || s === "j") this.move(1);
    else if (s === "\x04") this.move(Math.floor((process.stdout.rows || 24) / 2));
    else if (s === "\x15") this.move(-Math.floor((process.stdout.rows || 24) / 2));
    else if (s === "\x1b[D" || s === "h") this.cd("..");
    else if (s === "\x1b[C" || s === "\r" || s === "\n" || s === "l") this.open();
    else if (s === "G") this.cursor = Math.max(0, this.entries.length - 1);
    else if (s === "g" && this.pending === "g") { this.cursor = 0; this.pending = ""; }
    else if (s === "y" && this.pending === "y") { this.yank = this.currentPaths(); this.status = "yanked"; this.pending = ""; }
    else if (s === "d" && this.pending === "d") { this.deleteSelected(); this.pending = ""; }
    else if (s === "Z" && (this.pending === "Z" || this.pending === "")) { if (this.pending === "Z") this.done = true; else this.pending = "Z"; }
    else if (s === "Q" && this.pending === "Z") this.done = true;
    else if (s === "g" || s === "y" || s === "d") this.pending = s;
    else if (s === "p") this.put();
    else if (s === "e") this.unpack();
    else if (s === "i") { this.mode = "inputFile"; this.buffer = ""; }
    else if (s === "I") { this.mode = "inputDir"; this.buffer = ""; }
    else if (s === "c") { this.mode = "rename"; this.buffer = this.selected()?.name || ""; }
    else if (s === "/") { this.mode = "search"; this.buffer = ""; }
    else if (s === "n") this.find(1);
    else if (s === "N") this.find(-1);
    else if (s === ":") { this.mode = "cmd"; this.buffer = ""; }
    else if (s === "\x7f") { this.showHidden = !this.showHidden; this.refresh(); }
    else if (s === "t") { this.sortTime = !this.sortTime; this.refresh(); }
    else if (s === "\x0f" && this.histBack.length) { this.histForward.push(this.cwd); this.cwd = this.histBack.pop(); this.refresh(); }
    else if (s === "\x09" && this.histForward.length) { this.histBack.push(this.cwd); this.cwd = this.histForward.pop(); this.refresh(); }
    else if (s === "z") this.pending = "z";
    else if ((s === "\r" || s === "\n") && this.pending === "z") { this.cd(os.homedir()); this.pending = ""; }
    else this.pending = "";
  }
}

function runTui(start: string): void {
  const cols = process.stdout.columns || 0;
  const rows = process.stdout.rows || 0;
  if (!process.stdout.isTTY || !process.stdin.isTTY || !cols || !rows) {
    process.stderr.write("Error: Cannot detect terminal size\n");
    return;
  }
  if (cols < 80 || rows < 20) { process.stderr.write("Error: Too small window size\n"); return; }
  const app = new App(start);
  const cleanup = () => {
    try { process.stdin.setRawMode(false); } catch {}
    process.stdout.write("\x1b[?25h\x1b[0m\x1b[H\x1b[2J");
  };
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.setEncoding("utf8");
  app.render();
  process.stdin.on("data", (chunk: string) => {
    if (chunk === "\x03") { app.done = true; }
    else {
      const parts = chunk.match(/\x1b\[[A-D]|[\s\S]/g) || [];
      for (const p of parts) app.key(p);
    }
    if (app.done) { cleanup(); process.exit(0); }
    else app.render();
  });
}

function main(): void {
  const args = process.argv.slice(2);
  if (args[0] === "--help" || args[0] === "-h") { process.stdout.write(VERSION_HELP); return; }
  if (args[0] === "--init" && args.length === 1) { process.stdout.write(INIT_SNIPPET); return; }
  if (args.length > 1 && args[0] !== "--log" && args[0] !== "-l") { process.stdout.write(VERSION_HELP); return; }
  let log = false;
  if (args[0] === "--log" || args[0] === "-l") { log = true; args.shift(); }
  if (args.length > 1) { process.stdout.write(VERSION_HELP); return; }
  if (log) makeLog();
  const target = args.length ? args[0] : ".";
  if (!fs.existsSync(target)) { invalidPath(target); return; }
  let st: any;
  try { st = fs.statSync(target); } catch { invalidPath(target); return; }
  if (!st.isDirectory()) { notDir(); return; }
  runTui(path.resolve(target));
}

main();
