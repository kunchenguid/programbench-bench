declare const process: any;
declare function require(name: string): any;

const fs = require("fs");
const path = require("path");

type Entry = { ip: string; host: string };
type Profile = { name: string; status: "on" | "off"; entries: Entry[] };
type Hosts = { baseText: string; defaults: Entry[]; profiles: Profile[] };
type Opts = {
  hostFile: string;
  out: string;
  quiet: boolean;
  raw: boolean;
  columns: string[];
  noColor: boolean;
};

const HEADER = [
  "##################################################################",
  "# Content under this line is handled by hostctl. DO NOT EDIT.",
  "##################################################################",
].join("\n");

function main() {
  const parsed = parseArgs(process.argv.slice(2));
  const opts = parsed.opts;
  const args = parsed.args;
  if (parsed.version || args[0] === "version") return console.log("hostctl version dev");
  if (parsed.help || args.length === 0) return printHelp(args);

  try {
    dispatch(args, opts);
  } catch (e: any) {
    error(e && e.message ? e.message : String(e));
  }
}

function parseArgs(argv: string[]) {
  const opts: Opts = {
    hostFile: "/etc/hosts",
    out: "table",
    quiet: false,
    raw: false,
    columns: [],
    noColor: false,
  };
  const args: string[] = [];
  let help = false, version = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = () => argv[++i] ?? "";
    if (a === "-h" || a === "--help") help = true;
    else if (a === "-v" || a === "--version") version = true;
    else if (a === "-q" || a === "--quiet") opts.quiet = true;
    else if (a === "--raw") { opts.raw = true; opts.out = "raw"; }
    else if (a === "--no-color") opts.noColor = true;
    else if (a === "--host-file") opts.hostFile = next();
    else if (a.startsWith("--host-file=")) opts.hostFile = a.slice(12);
    else if (a === "-o" || a === "--out") opts.out = next();
    else if (a.startsWith("--out=")) opts.out = a.slice(6);
    else if (a === "-c" || a === "--column") opts.columns = next().split(",").filter(Boolean);
    else if (a.startsWith("--column=")) opts.columns = a.slice(9).split(",").filter(Boolean);
    else args.push(a);
  }
  if (opts.raw) opts.out = "raw";
  return { opts, args, help, version };
}

function dispatch(args: string[], opts: Opts) {
  const cmd = args[0];
  if (cmd === "help") return printHelp(args.slice(1));
  if (cmd === "list") return cmdList(args.slice(1), opts);
  if (cmd === "status") return cmdStatus(args.slice(1), opts);
  if (cmd === "add") return cmdAdd(args.slice(1), opts);
  if (cmd === "replace") return cmdReplace(args.slice(1), opts);
  if (cmd === "enable") return cmdSetStatus(args.slice(1), opts, "on");
  if (cmd === "disable") return cmdSetStatus(args.slice(1), opts, "off");
  if (cmd === "toggle") return cmdToggle(args.slice(1), opts);
  if (cmd === "remove" || cmd === "rm") return cmdRemove(args.slice(1), opts);
  if (cmd === "backup") return cmdBackup(args.slice(1), opts);
  if (cmd === "restore") return cmdRestore(args.slice(1), opts);
  if (cmd === "sync") return cmdSync(args.slice(1), opts);
  error(`unknown command "${cmd}" for "hostctl"`);
}

function readHosts(file: string): Hosts {
  const text = fs.existsSync(file) ? fs.readFileSync(file, "utf8") : "";
  const idx = text.indexOf(HEADER);
  const baseText = idx >= 0 ? trimManagedPrefix(text.slice(0, idx)) : text;
  const managed = idx >= 0 ? text.slice(idx + HEADER.length) : "";
  const defaults = parseDefaultEntries(baseText);
  const profiles: Profile[] = [];
  let cur: Profile | null = null;
  for (const raw of managed.split(/\r?\n/)) {
    const m = raw.match(/^# profile\.(on|off) (.+)$/);
    if (m) {
      cur = { name: m[2], status: m[1] as any, entries: [] };
      profiles.push(cur);
      continue;
    }
    if (/^# end\s*$/.test(raw)) { cur = null; continue; }
    if (!cur) continue;
    let line = raw;
    if (cur.status === "off") line = line.replace(/^#\s?/, "");
    const e = parseEntry(line);
    if (e) cur.entries.push(e);
  }
  return { baseText, defaults, profiles };
}

function trimManagedPrefix(s: string) {
  return s.replace(/\s+$/g, "") + "\n";
}

function parseDefaultEntries(text: string): Entry[] {
  const out: Entry[] = [];
  for (const line of text.split(/\r?\n/)) {
    const e = parseEntry(line);
    if (e) out.push(e);
  }
  return out;
}

function parseEntry(line: string): Entry | null {
  const cleaned = line.replace(/\s+#.*$/, "").trim();
  if (!cleaned || cleaned.startsWith("#")) return null;
  const parts = cleaned.split(/\s+/);
  if (parts.length < 2) return null;
  return { ip: parts[0], host: parts[1] };
}

function parseEntriesFromFile(file: string): Entry[] {
  const text = fs.readFileSync(file, "utf8");
  const out: Entry[] = [];
  for (const line of text.split(/\r?\n/)) {
    const cleaned = line.replace(/\s+#.*$/, "").trim();
    if (!cleaned || cleaned.startsWith("#")) continue;
    const parts = cleaned.split(/\s+/);
    if (parts.length < 2) continue;
    for (const host of parts.slice(1)) out.push({ ip: parts[0], host });
  }
  return out;
}

function writeHosts(file: string, h: Hosts) {
  let text = h.baseText.replace(/\s+$/g, "");
  if (text) text += "\n\n";
  text += HEADER + "\n";
  for (const p of h.profiles) {
    text += `\n# profile.${p.status} ${p.name}\n`;
    for (const e of p.entries) {
      text += p.status === "off" ? `# ${e.ip} ${e.host}\n` : `${e.ip} ${e.host}\n`;
    }
    text += "# end\n";
  }
  fs.writeFileSync(file, text);
}

function findProfile(h: Hosts, name: string) {
  return h.profiles.find(p => p.name === name);
}

function cmdAdd(args: string[], opts: Opts) {
  if (args[0] === "domains" || args[0] === "domain") return cmdAddDomains(args.slice(1), opts);
  let from = "";
  const names: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-f" || args[i] === "--from") from = args[++i] ?? "";
    else if (args[i].startsWith("--from=")) from = args[i].slice(7);
    else if (args[i] === "-w" || args[i] === "--wait") i++;
    else names.push(args[i]);
  }
  if (!names[0]) error("missing profile name");
  info(opts);
  const entries = parseEntriesFromFile(from);
  const h = readHosts(opts.hostFile);
  for (const name of names) upsertProfile(h, name, entries, false);
  writeHosts(opts.hostFile, h);
  outputRows(profileRows(h, names), opts);
}

function cmdReplace(args: string[], opts: Opts) {
  let from = "";
  const names: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-f" || args[i] === "--from") from = args[++i] ?? "";
    else if (args[i].startsWith("--from=")) from = args[i].slice(7);
    else names.push(args[i]);
  }
  if (!names[0]) error("missing profile name");
  info(opts);
  const entries = parseEntriesFromFile(from);
  const h = readHosts(opts.hostFile);
  upsertProfile(h, names[0], entries, true);
  writeHosts(opts.hostFile, h);
  outputRows(profileRows(h, [names[0]]), opts);
}

function upsertProfile(h: Hosts, name: string, entries: Entry[], replace: boolean) {
  let p = findProfile(h, name);
  if (!p) {
    p = { name, status: "on", entries: [] };
    h.profiles.push(p);
  }
  p.status = "on";
  p.entries = replace ? [...entries] : p.entries.concat(entries);
}

function cmdAddDomains(args: string[], opts: Opts) {
  let ip = "127.0.0.1";
  const vals: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--ip") ip = args[++i] ?? ip;
    else if (args[i].startsWith("--ip=")) ip = args[i].slice(5);
    else vals.push(args[i]);
  }
  if (!vals[0]) error("missing profile name");
  if (vals.length < 2) error("missing domain name");
  info(opts);
  const h = readHosts(opts.hostFile);
  const domains = vals.slice(1);
  upsertProfile(h, vals[0], domains.map(host => ({ ip, host })), false);
  writeHosts(opts.hostFile, h);
  success(opts, `Domains '${domains.join(", ")}' added.`);
  outputRows(profileRows(h, [vals[0]]), opts);
}

function cmdRemove(args: string[], opts: Opts) {
  if (args[0] === "domains" || args[0] === "domain") return cmdRemoveDomains(args.slice(1), opts);
  const all = args.includes("--all");
  const names = args.filter(a => a !== "--all");
  info(opts);
  const h = readHosts(opts.hostFile);
  if (all) {
    if (!h.profiles.length) error("there are no profiles");
    h.profiles = [];
    writeHosts(opts.hostFile, h);
    outputRows(allRows(readHosts(opts.hostFile), true), opts);
    return;
  }
  if (!names[0]) error("missing profile name");
  for (const n of names) if (!findProfile(h, n)) error("unknown profile name");
  h.profiles = h.profiles.filter(p => !names.includes(p.name));
  writeHosts(opts.hostFile, h);
  success(opts, `Profile(s) '${names.join(", ")}' removed.`);
}

function cmdRemoveDomains(args: string[], opts: Opts) {
  if (!args[0]) error("missing profile name");
  if (args.length < 2) error("missing domain name");
  info(opts);
  const h = readHosts(opts.hostFile);
  const p = findProfile(h, args[0]);
  if (!p) error("unknown profile name");
  const domains = args.slice(1);
  p.entries = p.entries.filter(e => !domains.includes(e.host));
  writeHosts(opts.hostFile, h);
  success(opts, `Domains '${domains.join(", ")}' removed.`);
  outputRows(profileRows(h, [args[0]]), opts);
}

function cmdSetStatus(args: string[], opts: Opts, status: "on" | "off") {
  let all = false, only = false;
  const names: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--all") all = true;
    else if (args[i] === "--only") only = true;
    else if (args[i] === "-w" || args[i] === "--wait") i++;
    else names.push(args[i]);
  }
  info(opts);
  const h = readHosts(opts.hostFile);
  if (all) {
    if (!h.profiles.length) error("there are no profiles");
    for (const p of h.profiles) p.status = status;
    writeHosts(opts.hostFile, h);
    outputRows(allRows(h, true), opts);
    return;
  }
  if (!names[0]) error("missing profile name");
  for (const n of names) if (!findProfile(h, n)) error("unknown profile name");
  if (only) {
    for (const p of h.profiles) p.status = status === "on" ? "off" : "on";
  }
  for (const n of names) findProfile(h, n)!.status = status;
  writeHosts(opts.hostFile, h);
  outputRows(profileRows(h, names), opts);
}

function cmdToggle(args: string[], opts: Opts) {
  const names = args.filter((a, i) => !(a === "-w" || a === "--wait" || args[i - 1] === "-w" || args[i - 1] === "--wait"));
  if (!names[0]) error("missing profile name");
  info(opts);
  const h = readHosts(opts.hostFile);
  for (const n of names) {
    const p = findProfile(h, n);
    if (!p) error("unknown profile name");
    p.status = p.status === "on" ? "off" : "on";
  }
  writeHosts(opts.hostFile, h);
  outputRows(profileRows(h, names), opts);
}

function cmdList(args: string[], opts: Opts) {
  let mode = "all";
  if (args[0] === "enabled" || args[0] === "on") { mode = "enabled"; args = args.slice(1); }
  else if (args[0] === "disabled" || args[0] === "off") { mode = "disabled"; args = args.slice(1); }
  info(opts);
  const h = readHosts(opts.hostFile);
  let rows = allRows(h, true);
  if (mode === "enabled") rows = rows.filter(r => r.Status === "on");
  if (mode === "disabled") rows = rows.filter(r => r.Status === "off" || r.Profile === "default");
  if (args.length) rows = rows.filter(r => args.includes(r.Profile));
  outputRows(rows, opts);
}

function cmdStatus(args: string[], opts: Opts) {
  info(opts);
  const h = readHosts(opts.hostFile);
  let rows = h.profiles.map(p => ({ Profile: p.name, Status: p.status, IP: "", Host: "" }));
  if (args.length) rows = rows.filter(r => args.includes(r.Profile));
  outputRows(rows, opts, ["Profile", "Status"]);
}

function cmdBackup(args: string[], opts: Opts) {
  let dest = "/workspace";
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--path") dest = args[++i] ?? dest;
    else if (args[i].startsWith("--path=")) dest = args[i].slice(7);
  }
  info(opts);
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  const target = path.join(dest, path.basename(opts.hostFile) + "." + date);
  fs.copyFileSync(opts.hostFile, target);
  success(opts, `Backup '${target}' created.`);
  outputRows(allRows(readHosts(opts.hostFile), true), opts);
}

function cmdRestore(args: string[], opts: Opts) {
  let from = "";
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--from") from = args[++i] ?? "";
    else if (args[i].startsWith("--from=")) from = args[i].slice(7);
  }
  info(opts);
  fs.copyFileSync(from, opts.hostFile);
  success(opts, `File '${from}' restored.`);
  outputRows(allRows(readHosts(opts.hostFile), true), opts);
}

function cmdSync(args: string[], opts: Opts) {
  if (!args[0]) return printHelp(["sync"]);
  const profile = args[1];
  if (!profile) error("missing profile name");
  info(opts);
  const h = readHosts(opts.hostFile);
  upsertProfile(h, profile, [], true);
  writeHosts(opts.hostFile, h);
  outputRows(profileRows(h, [profile]), opts);
}

function allRows(h: Hosts, includeDefault: boolean) {
  const rows: any[] = [];
  if (includeDefault) for (const e of h.defaults) rows.push({ Profile: "default", Status: "on", IP: e.ip, Host: e.host });
  for (const p of h.profiles) for (const e of p.entries) rows.push({ Profile: p.name, Status: p.status, IP: e.ip, Host: e.host });
  return rows;
}

function profileRows(h: Hosts, names: string[]) {
  const rows: any[] = [];
  for (const p of h.profiles) {
    if (!names.includes(p.name)) continue;
    for (const e of p.entries) rows.push({ Profile: p.name, Status: p.status, IP: e.ip, Host: e.host });
  }
  return rows;
}

function outputRows(rows: any[], opts: Opts, defaultCols = ["Profile", "Status", "IP", "Host"]) {
  if (opts.quiet) return;
  const cols = (opts.columns.length ? opts.columns.map(normCol) : defaultCols).filter(Boolean);
  if (opts.out === "json") {
    console.log(JSON.stringify(rows));
    return;
  }
  if (!rows.length) {
    if (opts.out !== "json") console.log("");
    return;
  }
  if (opts.out === "raw") return printRaw(rows, cols);
  if (opts.out === "markdown") return printMarkdown(rows, cols);
  printTable(rows, cols);
}

function normCol(c: string) {
  const low = c.toLowerCase();
  if (low === "profile") return "Profile";
  if (low === "status") return "Status";
  if (low === "ip") return "IP";
  if (low === "host" || low === "domain") return "Host";
  return c;
}

function label(c: string) { return c === "Host" ? "DOMAIN" : c.toUpperCase(); }
function value(row: any, c: string) { return String(row[c] ?? ""); }

function widths(rows: any[], cols: string[]) {
  return cols.map(c => Math.max(label(c).length, ...rows.map(r => value(r, c).length)));
}

function printRaw(rows: any[], cols: string[]) {
  const w = widths(rows, cols);
  console.log(cols.map((c, i) => label(c).padEnd(w[i])).join("\t"));
  for (const r of rows) console.log(cols.map((c, i) => value(r, c).padEnd(w[i])).join("\t") + "\t");
}

function printMarkdown(rows: any[], cols: string[]) {
  const w = widths(rows, cols);
  const row = (vals: string[]) => "| " + vals.map((v, i) => v.padEnd(w[i])).join(" | ") + " |";
  console.log("| " + cols.map((c, i) => center(label(c), w[i])).join(" | ") + " |");
  console.log("|" + w.map(n => "-".repeat(n + 2)).join("|") + "|");
  let last = "";
  for (const r of rows) {
    if (last && r.Profile !== last) console.log("|" + w.map(n => "-".repeat(n + 2)).join("|") + "|");
    console.log(row(cols.map(c => value(r, c))));
    last = r.Profile;
  }
}

function printTable(rows: any[], cols: string[]) {
  const w = widths(rows, cols);
  const border = "+" + w.map(n => "-".repeat(n + 2)).join("+") + "+";
  const row = (vals: string[]) => "| " + vals.map((v, i) => v.padEnd(w[i])).join(" | ") + " |";
  console.log(border);
  console.log("| " + cols.map((c, i) => center(label(c), w[i])).join(" | ") + " |");
  console.log(border);
  let last = "";
  for (const r of rows) {
    if (last && r.Profile !== last) console.log(border);
    console.log(row(cols.map(c => value(r, c))));
    last = r.Profile;
  }
  console.log(border);
}

function center(s: string, width: number) {
  const left = Math.floor((width - s.length) / 2);
  const right = width - s.length - left;
  return " ".repeat(left) + s + " ".repeat(right);
}

function info(opts: Opts) {
  if (!opts.quiet && opts.out !== "json") console.log(`[ℹ] Using hosts file: ${opts.hostFile}\n`);
}
function success(opts: Opts, msg: string) {
  if (!opts.quiet && opts.out !== "json") console.log(`[✔] ${msg}\n`);
}
function error(msg: string): never {
  console.error(`[✖] error: ${msg}`);
  process.exit(1);
  throw new Error(msg);
}

function printHelp(args: string[]) {
  const topic = Array.isArray(args) ? args.join(" ") : "";
  if (topic.startsWith("add domains")) {
    console.log(`\nSet content in your hosts file.\nIf the profile already exists it will be added to it.\n\nUsage:\n  hostctl add domains [profile] [domains] [flags]\n\nAliases:\n  domains, domain [profile] [domains] [flags]\n\nFlags:\n  -h, --help        help for domains\n      --ip string   domains ip (default "127.0.0.1")`);
    return;
  }
  if (topic === "add") {
    console.log(`\nReads from a file and set content to a profile in your hosts file.\nIf the profile already exists it will be added to it.\n\nUsage:\n  hostctl add [profiles] [flags]\n  hostctl add [command]\n\nAvailable Commands:\n  domains     Add content in your hosts file.\n\nFlags:\n  -f, --from string     file to read\n  -h, --help            help for add\n  -w, --wait duration   Enables a profile for a specific amount of time. (example: 5m, 1h) (default -1ns)`);
    return;
  }
  if (topic === "sync") {
    console.log(`\nReads IPs and names from some local system and sync it with a profile in your hosts file.\n\nUsage:\n  hostctl sync [command]\n\nAvailable Commands:\n  docker         Sync your Docker containers IPs with a profile.\n  docker-compose Sync your docker-compose containers IPs with a profile.`);
    return;
  }
  console.log(`
hostctl is a CLI tool to manage your hosts file with ease.
You can have multiple profiles, enable/disable exactly what
you need each time with a simple interface.

Usage:
  hostctl [command]

Available Commands:
  add         Add content to a profile in your hosts file.
  backup      Creates a backup copy of your hosts file
  disable     Disable a profile from your hosts file.
  enable      Enable a profile on your hosts file.
  help        Help about any command
  list        Shows a detailed list of profiles on your hosts file.
  remove      Remove a profile from your hosts file.
  replace     Replace content to a profile in your hosts file.
  restore     Restore hosts file content from a backup file.
  status      Shows a list of profile names and statuses on your hosts file.
  sync        Sync some system IPs with a profile.
  toggle      Change status of a profile on your hosts file.

Flags:
  -c, --column strings     Column names to show on lists. comma separated
  -h, --help               help for hostctl
      --host-file string   Hosts file path (default "/etc/hosts")
      --no-color           force colorless output
  -o, --out string         Output type (table|raw|markdown|json) (default "table")
  -q, --quiet              Run command without output
      --raw                Output without borders (same as -o raw)
  -v, --version            version for hostctl

Use "hostctl [command] --help" for more information about a command.`);
}

main();
