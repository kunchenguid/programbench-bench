const fs = require("fs");

type Json = any;

const ESC = "\x1b[";
const reset = `${ESC}0m`;
const bold = (s: string) => `${ESC}1m${s}${reset}`;
const dim = (s: string) => `${ESC}2m${s}${reset}`;
const rgb = (r: number, g: number, b: number, s: string) => `${ESC}38;2;${r};${g};${b}m${s}${reset}`;
const styleLevel = (level: string) => {
  const l = level.toUpperCase();
  const padded = fixed(l, 5).toUpperCase();
  if (["INFO", "20"].includes(l)) return `${ESC}1;32m${padded}${reset}`;
  if (["WARN", "30", "40"].includes(l)) return `${ESC}1;33m${padded}${reset}`;
  if (["WARNING"].includes(l)) return `${ESC}1;35m${padded}${reset}`;
  if (["ERROR", "ERR", "50"].includes(l)) return `${ESC}1;31m${padded}${reset}`;
  if (["DEBUG", "10"].includes(l)) return `${ESC}1;34m${padded}${reset}`;
  return `${ESC}1;35m${padded}${reset}`;
};
const minSize = (s: string, n: number) => s.length >= n ? s : s.padStart(n, " ");

interface Opts {
  input: string;
  additional: string[];
  excluded: string[];
  dumpAll: boolean;
  prefix: boolean;
  substitute: boolean;
  contextKey: string;
  placeholderFormat: string;
  messageKeys: string[];
  timeKeys: string[];
  levelKeys: string[];
  mapLevel: Record<string, string>;
  filter?: string;
  noImplicitFilterReturn: boolean;
  printLua: boolean;
  configFile?: string;
  mainLineFormat?: string;
  additionalValueFormat?: string;
}

const defaults = (): Opts => ({
  input: "-",
  additional: [],
  excluded: [],
  dumpAll: false,
  prefix: false,
  substitute: false,
  contextKey: "context",
  placeholderFormat: "{key}",
  messageKeys: ["short_message", "msg", "message"],
  timeKeys: ["timestamp", "time", "@timestamp"],
  levelKeys: ["level", "severity", "log.level", "loglevel"],
  mapLevel: {},
  noImplicitFilterReturn: false,
  printLua: false,
});

function help() {
  console.log(`json log viewer

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]

Options:
  -a, --additional-value <additional-value>
          adds additional values
      --config-file <config-file>
          configuration file to load
  -m, --message-key <message-key>
          Adds an additional key to detect the message in the log entry. The first matching key will be assigned to \`fblog_message\`.
      --print-lua
          Prints lua init expressions. Used for fblog debugging.
  -t, --time-key <time-key>
          Adds an additional key to detect the time in the log entry. The first matching key will be assigned to \`fblog_timestamp\`.
  -l, --level-key <level-key>
          Adds an additional key to detect the level in the log entry. The first matching key will be assigned to \`fblog_level\`.
      --map-level <from=to>
          Rewrite the log level from one value to another.
  -d, --dump-all
          dumps all values
  -x, --excluded-value <excluded-value>
          Excludes values (--dump-all is enabled implicitly)
  -p, --with-prefix
          consider all text before opening curly brace as prefix
  -f, --filter <filter>
          lua expression to filter log entries. \`message ~= nil and string.find(message, "text.*") ~= nil\`
      --no-implicit-filter-return-statement
          if you pass a filter expression 'return' is automatically prepended. Pass this switch to disable the implicit return.
      --main-line-format <main-line-format>
          Formats the main fblog output. All log values can be used. fblog provides sanitized variables starting with \`fblog_\`.
      --additional-value-format <additional-value-format>
          Formats the additional value fblog output.
  -s, --substitute
          Enable substitution of placeholders in the log messages with their corresponding values from the context.
  -c, --context-key <context-key>
          Use this key as the source of substitutions for the message. Value can either be an array ({1}) or an object ({key}).
  -F, --placeholder-format <placeholder-format>
          The format that should be used for substituting values in the message, where the key is the literal word \`key\`. Example: [[key]] or \${key}.
  -h, --help
          Print help
  -V, --version
          Print version`);
}

function parseArgs(argv: string[]): Opts {
  const o = defaults();
  const need = (i: number, name: string) => {
    if (i + 1 >= argv.length) die(`error: a value is required for '${name}' but none was supplied`);
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") { help(); process.exit(0); }
    else if (a === "-V" || a === "--version") { console.log("fblog 4.17.0"); process.exit(0); }
    else if (a === "-a" || a === "--additional-value") o.additional.push(need(i++, a));
    else if (a.startsWith("--additional-value=")) o.additional.push(a.slice(19));
    else if (a === "--config-file") o.configFile = need(i++, a);
    else if (a === "-m" || a === "--message-key") o.messageKeys.unshift(need(i++, a));
    else if (a === "-t" || a === "--time-key") o.timeKeys.unshift(need(i++, a));
    else if (a === "-l" || a === "--level-key") o.levelKeys.unshift(need(i++, a));
    else if (a === "--map-level") addMap(o, need(i++, a));
    else if (a === "-d" || a === "--dump-all") o.dumpAll = true;
    else if (a === "-x" || a === "--excluded-value") { o.excluded.push(need(i++, a)); o.dumpAll = true; }
    else if (a === "-p" || a === "--with-prefix") o.prefix = true;
    else if (a === "-f" || a === "--filter") o.filter = need(i++, a);
    else if (a === "--no-implicit-filter-return-statement") o.noImplicitFilterReturn = true;
    else if (a === "--main-line-format") o.mainLineFormat = need(i++, a);
    else if (a === "--additional-value-format") o.additionalValueFormat = need(i++, a);
    else if (a === "-s" || a === "--substitute") o.substitute = true;
    else if (a === "-c" || a === "--context-key") o.contextKey = need(i++, a);
    else if (a === "-F" || a === "--placeholder-format") o.placeholderFormat = need(i++, a);
    else if (a === "--print-lua") o.printLua = true;
    else if (a.startsWith("-")) die(`error: unexpected argument '${a}' found`);
    else o.input = a;
  }
  loadConfig(o);
  return o;
}

function addMap(o: Opts, spec: string) {
  const idx = spec.indexOf("=");
  if (idx >= 0) o.mapLevel[spec.slice(0, idx)] = spec.slice(idx + 1);
}

function die(msg: string): never {
  console.error(msg);
  process.exit(2);
  throw new Error(msg);
}

function loadConfig(o: Opts) {
  const file = o.configFile || (fs.existsSync("fblog.toml") ? "fblog.toml" : "");
  if (!file) return;
  try {
    const txt = fs.readFileSync(file, "utf8");
    const arr = (name: string) => {
      const m = txt.match(new RegExp(`^\\s*${name}\\s*=\\s*\\[([^\\]]*)\\]`, "m"));
      if (!m) return undefined;
      return [...m[1].matchAll(/"([^"]*)"/g)].map((x: any) => x[1]);
    };
    const str = (name: string) => {
      const m = txt.match(new RegExp(`^\\s*${name}\\s*=\\s*"([^"]*)"`, "m"));
      return m ? m[1] : undefined;
    };
    o.messageKeys = arr("message_keys") || o.messageKeys;
    o.timeKeys = arr("time_keys") || o.timeKeys;
    o.levelKeys = arr("level_keys") || o.levelKeys;
    o.mainLineFormat = str("main_line_format") || o.mainLineFormat;
    o.additionalValueFormat = str("additional_value_format") || o.additionalValueFormat;
    const lm = txt.split(/\[level_map\]/)[1] || "";
    for (const line of lm.split(/\r?\n/)) {
      const m = line.match(/^\s*"?([^"\s=]+)"?\s*=\s*"([^"]*)"/);
      if (m) o.mapLevel[m[1]] = m[2];
    }
  } catch (e: any) {
    die(`error: could not read config file: ${e.message}`);
  }
}

function fixed(s: string, n: number) {
  if (s.length > n) return s.slice(0, n);
  return s.padStart(n, " ");
}

function displayScalar(v: any): string {
  if (typeof v === "string") return v;
  if (typeof v === "number") return String(v);
  if (typeof v === "boolean") return String(v);
  if (v === null || v === undefined) return "null";
  return JSON.stringify(v);
}

function pretty(v: any): string {
  if (typeof v === "string") return `${ESC}1;33m${v}${reset}`;
  if (typeof v === "number") return `${ESC}1;36m${v}${reset}`;
  if (typeof v === "boolean") return `${ESC}1;${v ? 32 : 31}m${v}${reset}`;
  if (Array.isArray(v)) return dim("[") + v.map(pretty).join(dim(", ")) + dim("]");
  if (v && typeof v === "object") {
    const keys = Object.keys(v).sort();
    return dim("{") + keys.map(k => `${ESC}35m${k}${reset}${dim(": ")}${pretty(v[k])}`).join(dim(", ")) + dim("}");
  }
  return `${ESC}1;31m${String(v)}${reset}`;
}

function getPath(obj: any, path: string): any {
  const parts = path.split(/\s*>\s*/).filter(Boolean);
  let cur = obj;
  for (const part0 of parts) {
    let rest = part0;
    const m = rest.match(/^([^\[]+)/);
    if (m) {
      cur = cur?.[m[1]];
      rest = rest.slice(m[1].length);
    }
    for (const idx of rest.matchAll(/\[(\d+)\]/g)) cur = cur?.[Number(idx[1])];
  }
  return cur;
}

function flatten(obj: any, prefix = "", arrayDepth = 0): [string, any, boolean?][] {
  if (Array.isArray(obj)) {
    const out: [string, any, boolean?][] = [];
    obj.forEach((v, i) => {
      const idx = arrayDepth > 0 ? i + 1 : i;
      const p = `${prefix}[${idx}]`;
      if (v && typeof v === "object") out.push(...flatten(v, p, arrayDepth + 1)); else out.push([p, v, true]);
    });
    return out;
  }
  if (obj && typeof obj === "object") {
    const out: [string, any, boolean?][] = [];
    const base = arrayDepth > 1 ? `${prefix}[1]` : prefix;
    for (const k of Object.keys(obj).sort()) {
      const p = base ? `${base} > ${k}` : k;
      const v = obj[k];
      if (v && typeof v === "object") out.push(...flatten(v, p, 0)); else out.push([p, v, false]);
    }
    return out;
  }
  return [[prefix, obj]];
}

function findKey(obj: any, keys: string[]): any {
  for (const k of keys) {
    const v = getPath(obj, k);
    if (v !== undefined) return v;
  }
  return undefined;
}

function normalizeTime(v: any): string {
  if (v === undefined) return "";
  if (typeof v === "number" || (typeof v === "string" && /^\d{12,}$/.test(v))) {
    const d = new Date(Number(v));
    if (!isNaN(d.getTime())) return d.toISOString().replace(/\.\d{3}Z$/, "");
  }
  let s = String(v);
  if (/^\d{4}-\d\d-\d\dT/.test(s)) s = s.replace(/\.\d+/, "").replace(/Z$/, "").replace(/[+-]\d\d:\d\d$/, "");
  if (/^[A-Z][a-z]{2} [A-Z][a-z]{2} /.test(s)) {
    const parts = s.split(/\s+/);
    if (parts.length >= 4) return `${parts[0]} ${parts[1]} ${parts[2]} ${parts[3]}`;
  }
  return s;
}

function fallback(line: string) {
  console.log(`${ESC}1;38;2;255;135;22m??? >${reset} ${line}`);
}

function parseLine(line: string, prefixMode: boolean): { obj?: any, prefix?: string } {
  let text = line;
  let prefix = "";
  if (prefixMode) {
    const idx = line.indexOf("{");
    if (idx > 0) { prefix = line.slice(0, idx).trimEnd(); text = line.slice(idx); }
  }
  try { return { obj: JSON.parse(text), prefix }; } catch { return {}; }
}

function substitute(message: string, ctx: any, fmt: string): string {
  if (!ctx || typeof message !== "string") return message;
  const marker = fmt || "{key}";
  const [pre, post] = marker.split("key");
  const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re = new RegExp(`${esc(pre || "")}([^${esc((post || "}").charAt(0))}]+)${esc(post || "")}`, "g");
  return message.replace(re, (whole, key) => {
    const v = Array.isArray(ctx) ? ctx[Number(key)] : ctx[key];
    return v === undefined ? dim(pre || "{") + `${ESC}1;31m${key}${reset}` + dim(post || "}") : pretty(v);
  });
}

function evalFilter(expr: string | undefined, obj: any, vars: Record<string, any>): boolean {
  if (!expr) return true;
  let e = expr.trim().replace(/^return\s+/, "");
  e = e.replace(/\bnil\b/g, "null").replace(/\band\b/g, "&&").replace(/\bor\b/g, "||").replace(/~=/g, "!=");
  e = e.replace(/string\.find\(([^,]+),\s*"([^"]*)"\)\s*~=\s*null/g, "(RegExp($2).test(String($1)))");
  e = e.replace(/string\.find\(([^,]+),\s*"([^"]*)"\)/g, "(RegExp($2).test(String($1)) ? 1 : null)");
  const names = new Set([...Object.keys(vars), ...Object.keys(obj)]);
  const vals: any[] = [];
  const args: string[] = [];
  for (const n of names) if (/^[A-Za-z_]\w*$/.test(n)) { args.push(n); vals.push(vars[n] ?? obj[n]); }
  try { return !!Function(...args, `return (${e});`)(...vals); } catch { return true; }
}

function renderFormat(fmt: string, vars: Record<string, any>): string {
  return fmt.replace(/{{\s*([^{}]+?)\s*}}/g, (_, token) => {
    const t = String(token).trim();
    const last = t.split(/\s+/).pop() || "";
    return vars[last] !== undefined ? displayScalar(vars[last]) : "";
  });
}

function processObj(obj: any, prefix: string, o: Opts) {
  let msg = findKey(obj, o.messageKeys);
  let level = findKey(obj, o.levelKeys);
  let ts = findKey(obj, o.timeKeys);
  if (level === undefined) level = "unknown";
  level = String(o.mapLevel[String(level)] ?? level);
  const vars: Record<string, any> = {
    message: msg, level, timestamp: ts, fblog_message: msg, fblog_level: level,
    fblog_timestamp: normalizeTime(ts), fblog_prefix: prefix,
  };
  for (const [k, v] of flatten(obj)) vars[k.replace(/[^A-Za-z0-9_]/g, "_")] = v;
  if (!evalFilter(o.filter, obj, vars)) return;
  let message = msg === undefined ? "" : displayScalar(msg);
  if (o.substitute) message = substitute(message, getPath(obj, o.contextKey), o.placeholderFormat);
  if (o.mainLineFormat) {
    console.log(renderFormat(o.mainLineFormat, { ...vars, fblog_message: message }));
  } else {
    const prefixText = prefix ? ` ${bold(`${ESC}36m${prefix}${reset}`)}` : "";
    console.log(`${bold(fixed(normalizeTime(ts), 19))} ${styleLevel(level)}:${prefixText} ${message}`);
  }
  const rows: [string, any, boolean?][] = [];
  for (const a of o.additional) rows.push([a, getPath(obj, a), false]);
  if (o.dumpAll) {
    const excluded = new Set(o.excluded);
    for (const [k, v, q] of flatten(obj)) if (!excluded.has(k) && !rows.some(r => r[0] === k)) rows.push([k, v, q]);
  }
  for (const [k, v, q] of rows) {
    if (v === undefined) continue;
    const val = q && typeof v === "string" ? JSON.stringify(v) : displayScalar(v);
    if (o.additionalValueFormat) console.log(renderFormat(o.additionalValueFormat, { key: k, value: val }));
    else console.log(`${bold(rgb(150, 150, 150, minSize(k, 25)))}: ${val}`);
  }
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.printLua) {
    console.log("-- fblog lua helpers unavailable in this TypeScript build");
    return;
  }
  let input = "";
  try {
    input = opts.input === "-" ? fs.readFileSync(0, "utf8") : fs.readFileSync(opts.input, "utf8");
  } catch (e: any) {
    console.error(`Error: ${e.message}`);
    process.exit(1);
  }
  for (const raw of input.split(/\r?\n/)) {
    if (raw.length === 0) continue;
    const { obj, prefix } = parseLine(raw, opts.prefix);
    if (obj === undefined) fallback(raw); else processObj(obj, prefix || "", opts);
  }
}

main();
