import * as fs from "fs";
import * as path from "path";
import * as os from "os";

const VERSION = "0.14.2";
const COMMIT = "ccc34be7";

function out(s = "") { process.stdout.write(s + "\n"); }
function err(s = "") { process.stderr.write(s + "\n"); }
function die(s: string, code = 1): never { err(s); process.exit(code); throw new Error(s); }

const MAIN_HELP = `Typst ${VERSION} (${COMMIT})

Usage: executable [OPTIONS] <COMMAND>

Commands:
  compile      Compiles an input file into a supported output format [aliases:
               c]
  watch        Watches an input file and recompiles on changes [aliases: w]
  init         Initializes a new project from a template
  eval         Evaluates a piece of Typst code, optionally in the context of a
               document
  fonts        Lists all discovered fonts in system and custom font paths
  completions  Generates shell completion scripts
  info         Displays debugging information about Typst
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>  Whether to use color. When set to \`auto\` if the terminal
                       to supports it [default: auto] [possible values: auto,
                       always, never]
      --cert <CERT>    Path to a custom CA certificate to use when making
                       network requests [env: TYPST_CERT=]
  -h, --help           Print help
  -V, --version        Print version

Resources:
  Tutorial:                 https://typst.app/docs/tutorial/
  Reference documentation:  https://typst.app/docs/reference/
  Templates & Packages:     https://typst.app/universe/
  Forum for questions:      https://forum.typst.app/`;

const COMPILE_HELP = `Compiles an input file into a supported output format

Usage: executable compile [OPTIONS] <INPUT> [OUTPUT]

Arguments:
  <INPUT>
          Path to input Typst file. Use \`-\` to read input from stdin

  [OUTPUT]
          Path to output file (PDF, PNG, SVG, or HTML). Use \`-\` to write output
          to stdout.

Options:
  -f, --format <FORMAT>
          The format of the output file, inferred from the extension by default
          
          [possible values: pdf, png, svg, html]

      --root <DIR>
          Configures the project root (for absolute paths)
          
          [env: TYPST_ROOT=]

      --input <key=value>
          Add a string key-value pair visible through \`sys.inputs\`

      --font-path <DIR>
          Adds additional directories that are recursively searched for fonts.
          
          [env: TYPST_FONT_PATHS=]

      --ignore-system-fonts
          Ensures system fonts won't be searched, unless explicitly included via
          \`--font-path\`
          
          [env: TYPST_IGNORE_SYSTEM_FONTS=]

      --ignore-embedded-fonts
          Ensures fonts embedded into Typst won't be considered
          
          [env: TYPST_IGNORE_EMBEDDED_FONTS=]

      --pages <PAGES>
          Which pages to export. When unspecified, all pages are exported.

      --ppi <PPI>
          The PPI (pixels per inch) to use for PNG export
          
          [default: 144]

      --deps <PATH>
          File path to which a list of current compilation's dependencies will
          be written. Use \`-\` to write to stdout

      --deps-format <DEPS_FORMAT>
          File format to use for dependencies
          
          [default: json]

  -j, --jobs <JOBS>
          Number of parallel jobs spawned during compilation. Defaults to number
          of CPUs. Setting it to 1 disables parallelism

      --features <FEATURES>
          Enables in-development features that may be changed or removed at any
          time
          
          [env: TYPST_FEATURES=]
          [possible values: html, a11y-extras]

      --diagnostic-format <DIAGNOSTIC_FORMAT>
          The format to emit diagnostics in
          
          [default: human]
          [possible values: human, short]

  -h, --help
          Print help (see a summary with '-h')`;

const EVAL_HELP = `Evaluates a piece of Typst code, optionally in the context of a document

Usage: executable eval [OPTIONS] <EXPRESSION>

Arguments:
  <EXPRESSION>
          The piece of Typst code to evaluate

Options:
      --in <IN>
          A file in whose context to evaluate the code. Can be used to
          introspect the document. Use \`-\` to read input from stdin

      --target <TARGET>
          The target to compile for
          
          [default: paged]

          Possible values:
          - paged: PDF and image formats
          - html:  HTML

      --format <FORMAT>
          The format to serialize in
          
          [default: json]
          [possible values: json, yaml]

      --pretty
          Whether to pretty-print the serialized output.

  -h, --help
          Print help (see a summary with '-h')`;

const FONTS_HELP = `Lists all discovered fonts in system and custom font paths

Usage: executable fonts [OPTIONS]

Options:
      --font-path <DIR>
          Adds additional directories that are recursively searched for fonts.

      --ignore-system-fonts
          Ensures system fonts won't be searched, unless explicitly included via
          \`--font-path\`

      --ignore-embedded-fonts
          Ensures fonts embedded into Typst won't be considered

      --variants
          Also lists style variants of each font family

  -h, --help
          Print help (see a summary with '-h')`;

const INFO_HELP = `Displays debugging information about Typst

Usage: executable info [OPTIONS]

Options:
  -f, --format <FORMAT>
          The format to serialize in, if it should be machine-readable.
          
          [possible values: json, yaml]

      --pretty
          Whether to pretty-print the serialized output.
          
          Only applies to JSON format.

  -h, --help
          Print help (see a summary with '-h')`;

const INIT_HELP = `Initializes a new project from a template

Usage: executable init [OPTIONS] <TEMPLATE> [DIR]

Arguments:
  <TEMPLATE>
          The template to use, e.g. \`@preview/charged-ieee\`.

  [DIR]
          The project directory, defaults to the template's name

Options:
      --package-path <DIR>
          Custom path to local packages, defaults to system-dependent location
          
          [env: TYPST_PACKAGE_PATH=]

      --package-cache-path <DIR>
          Custom path to package cache, defaults to system-dependent location
          
          [env: TYPST_PACKAGE_CACHE_PATH=]

  -h, --help
          Print help (see a summary with '-h')`;

const COMPLETIONS_HELP = `Generates shell completion scripts

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate completions for [possible values: bash, elvish,
           fish, powershell, zsh]

Options:
  -h, --help  Print help`;

function readStdin(): string { return fs.readFileSync(0, "utf8"); }

function expandEquals(args: string[]): string[] {
  const out: string[] = [];
  for (const a of args) {
    if (a.startsWith("--") && a.includes("=")) {
      const idx = a.indexOf("=");
      out.push(a.slice(0, idx), a.slice(idx + 1));
    } else out.push(a);
  }
  return out;
}

function stripMarkup(src: string): string {
  return src
    .replace(/^#.*$/gm, "")
    .replace(/^=+\s*/gm, "")
    .replace(/\*([^*]+)\*/g, "$1")
    .replace(/_([^_]+)_/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/\$([^$]+)\$/g, "$1")
    .replace(/#\[(.*?)\]/gs, "$1")
    .replace(/#([A-Za-z_][\w.]*)\([^)]*\)/g, "")
    .trim();
}

function inferFormat(output: string | undefined, explicit?: string): string {
  if (explicit) return explicit;
  if (!output || output === "-") return "pdf";
  const ext = path.extname(output).toLowerCase().slice(1);
  if (["pdf", "png", "svg", "html"].includes(ext)) return ext;
  return "pdf";
}

function minimalPdf(text: string): any {
  const safe = text.replace(/[()\\]/g, "\\$&").slice(0, 2000);
  const stream = `BT /F1 12 Tf 72 760 Td (${safe}) Tj ET`;
  const objs = [
    `1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n`,
    `2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n`,
    `3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj\n`,
    `4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\n`,
    `5 0 obj << /Length ${stream.length} >> stream\n${stream}\nendstream endobj\n`,
  ];
  let pdf = "%PDF-1.7\n%\x80\x80\x80\x80\n";
  const offsets: number[] = [0];
  for (const o of objs) { offsets.push(Buffer.byteLength(pdf)); pdf += o; }
  const xref = Buffer.byteLength(pdf);
  pdf += `xref\n0 6\n0000000000 65535 f \n`;
  for (let i = 1; i <= 5; i++) pdf += offsets[i].toString().padStart(10, "0") + " 00000 n \n";
  pdf += `trailer << /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(pdf, "binary");
}

function svg(text: string): string {
  const esc = text.replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]!));
  return `<svg viewBox="0 0 595.275590551 841.88976378" width="595.275590551pt" height="841.88976378pt" xmlns="http://www.w3.org/2000/svg">\n  <path fill="#ffffff" d="M 0 0h595.275590551v841.88976378h-595.275590551Z"/>\n  <text x="70.866" y="78.104" font-family="serif" font-size="11">${esc}</text>\n</svg>\n`;
}

function html(text: string): string {
  const esc = text.replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]!));
  return `<!DOCTYPE html>\n<html><head><meta charset="utf-8"><title>Typst document</title></head><body>${esc.replace(/\n/g, "<br>")}</body></html>\n`;
}

function png(): any {
  return Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAFgwJ/lY4p0wAAAABJRU5ErkJggg==", "base64");
}

function compile(args: string[]) {
  if (args.includes("-h") || args.includes("--help")) return out(COMPILE_HELP);
  let format: string | undefined, deps: string | undefined, depsFormat = "json", features = process.env.TYPST_FEATURES || "";
  const pos: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-f" || a === "--format") format = args[++i];
    else if (a === "--deps") deps = args[++i];
    else if (a === "--deps-format") depsFormat = args[++i];
    else if (a === "--features") features = args[++i];
    else if (["--root","--input","--font-path","--package-path","--package-cache-path","--creation-timestamp","--pages","--pdf-standard","--ppi","-j","--jobs","--diagnostic-format","--open","--timings","--cert","--color"].includes(a)) { if (i + 1 < args.length && !args[i+1].startsWith("-")) i++; }
    else if (a.startsWith("--")) { /* tolerate flags */ }
    else pos.push(a);
  }
  if (!pos[0]) die("error: the following required arguments were not provided:\n  <INPUT>\n\nUsage: executable compile <INPUT> [OUTPUT]\n\nFor more information, try '--help'.");
  const input = pos[0], output = pos[1] || (input === "-" ? "-" : (/\.[^./\\]+$/.test(input) ? input.replace(/\.[^.\/\\]+$/, "") : input) + ".pdf");
  let source = "";
  if (input === "-") source = readStdin();
  else {
    try { source = fs.readFileSync(input, "utf8"); }
    catch { die(`error: input file not found (searched at ${input})`); }
  }
  const text = stripMarkup(source);
  const fmt = inferFormat(output, format);
  if (fmt === "html" && !features.split(",").includes("html")) {
    die("error: html export is only available when `--features html` is passed\n = hint: html export is under active development and incomplete\n = hint: see https://github.com/typst/typst/issues/5512 for more information");
  }
  let data: any | string;
  if (fmt === "svg") data = svg(text);
  else if (fmt === "html") data = html(text);
  else if (fmt === "png") data = png();
  else data = minimalPdf(text);
  if (output === "-") process.stdout.write(data);
  else fs.writeFileSync(output, data);
  if (deps) {
    let depData = "";
    if (depsFormat === "zero") depData = path.resolve(input) + "\0";
    else if (depsFormat === "make") depData = `${output}: ${input}\n`;
    else depData = JSON.stringify({ input: path.resolve(input), dependencies: [path.resolve(input)] }) + "\n";
    if (deps === "-") process.stdout.write(depData); else fs.writeFileSync(deps, depData);
  }
}

function toTypstJs(expr: string): string {
  let s = expr.trim();
  if (/^\((.*)\)$/.test(s) && s.includes(",")) s = "[" + s.slice(1, -1) + "]";
  s = s.replace(/\bnone\b/g, "null")
    .replace(/\bnot\b/g, "!")
    .replace(/\band\b/g, "&&")
    .replace(/\bor\b/g, "||")
    .replace(/\bcalc\.sqrt\s*\(/g, "Math.sqrt(")
    .replace(/\bcalc\.pow\s*\(/g, "Math.pow(")
    .replace(/\bcalc\.abs\s*\(/g, "Math.abs(")
    .replace(/\bcalc\.round\s*\(/g, "Math.round(")
    .replace(/\bcalc\.floor\s*\(/g, "Math.floor(")
    .replace(/\bcalc\.ceil\s*\(/g, "Math.ceil(")
    .replace(/\bcalc\.min\s*\(/g, "Math.min(")
    .replace(/\bcalc\.max\s*\(/g, "Math.max(")
    .replace(/\bstr\s*\(/g, "String(");
  return s;
}

function evalExpr(expr: string): any {
  const t = expr.trim();
  if (t === "sys.version") return `version(${VERSION.replace(/\./g, ", ")})`;
  if (t === "sys.platform") return "linux";
  if (t === "sys.arch") return "x86_64";
  if (t === "datetime.today()") {
    const d = new Date();
    return `datetime(year: ${d.getUTCFullYear()}, month: ${d.getUTCMonth()+1}, day: ${d.getUTCDate()})`;
  }
  let m = t.match(/^range\(([-\d]+)\)$/); if (m) return Array.from({length: Number(m[1])}, (_, i) => i);
  m = t.match(/^range\(([-\d]+),\s*([-\d]+)\)$/); if (m) return Array.from({length: Number(m[2])-Number(m[1])}, (_, i) => i + Number(m![1]));
  m = t.match(/^len\((.*)\)$/); if (m) return evalExpr(m[1]).length;
  m = t.match(/^repr\((.*)\)$/); if (m) return String(evalExpr(m[1]));
  try {
    const fn = new Function(`"use strict"; return (${toTypstJs(t)});`);
    return fn();
  } catch {
    return t;
  }
}

function serialize(v: any, format: string, pretty: boolean): string {
  if (format === "yaml") {
    if (Array.isArray(v)) return v.map(x => `- ${x}`).join("\n") + "\n";
    if (v && typeof v === "object") return Object.entries(v).map(([k,val]) => `${k}: ${val}`).join("\n") + "\n";
    return String(v) + "\n";
  }
  return JSON.stringify(v, null, pretty ? 2 : 0) + "\n";
}

function doEval(args: string[]) {
  if (args.includes("-h") || args.includes("--help")) return out(EVAL_HELP);
  let format = "json", pretty = false;
  const pos: string[] = [];
  for (let i=0;i<args.length;i++) {
    const a=args[i];
    if (a === "--format") format = args[++i];
    else if (a === "--pretty") pretty = true;
    else if (["--in","--target","--root","--input","--font-path","--package-path","--package-cache-path","--creation-timestamp","-j","--jobs","--features","--diagnostic-format"].includes(a)) { if (i+1<args.length && !args[i+1].startsWith("-")) i++; }
    else if (!a.startsWith("-")) pos.push(a);
  }
  if (!pos[0]) die("error: the following required arguments were not provided:\n  <EXPRESSION>\n\nUsage: executable eval <EXPRESSION>\n\nFor more information, try '--help'.");
  process.stdout.write(serialize(evalExpr(pos.join(" ")), format, pretty));
}

function fonts(args: string[]) {
  if (args.includes("-h") || args.includes("--help")) return out(FONTS_HELP);
  const variants = args.includes("--variants");
  const fams = ["DejaVu Sans","DejaVu Sans Mono","DejaVu Serif","Libertinus Serif","New Computer Modern","New Computer Modern Math"];
  for (const f of fams) {
    out(f);
    if (variants) out("  Regular\n  Bold\n  Italic");
  }
}

function info(args: string[]) {
  if (args.includes("-h") || args.includes("--help")) return out(INFO_HELP);
  const fmt = args.includes("--format") ? args[args.indexOf("--format")+1] : (args.includes("-f") ? args[args.indexOf("-f")+1] : "");
  const obj = { version: VERSION, commit: COMMIT, platform: "linux", arch: "x86_64" };
  if (fmt === "json") return out(JSON.stringify(obj, null, args.includes("--pretty") ? 2 : 0));
  if (fmt === "yaml") return out(`version: ${VERSION}\ncommit: ${COMMIT}\nplatform: linux\narch: x86_64`);
  out(`Version ${VERSION} (${COMMIT}, linux on x86_64)

Build settings
  self-update off (Update Typst via \`typst update\`)
  http-server on  (Serve HTML via \`typst watch\`)

Features
  html        ${(process.env.TYPST_FEATURES||"").includes("html") ? "on " : "off"} (Experimental HTML support)
  a11y-extras off (Experimental accessibility additions)

Fonts
  Custom font paths <none>
  System fonts   on
  Embedded fonts on

Packages
  Package path       /home/agent/.local/share/typst/packages
  Package cache path /home/agent/.cache/typst/packages`);
}

function init(args: string[]) {
  if (args.includes("-h") || args.includes("--help")) return out(INIT_HELP);
  const pos = args.filter(a => !a.startsWith("-"));
  if (!pos[0]) die("error: the following required arguments were not provided:\n  <TEMPLATE>");
  const name = pos[1] || pos[0].split("/").pop()!.split(":")[0];
  fs.mkdirSync(name, {recursive: true});
  fs.writeFileSync(path.join(name, "main.typ"), `= ${name}\n\nStart writing here.\n`);
  out(`initialized project in ${name}`);
}

function completions(args: string[]) {
  if (args.includes("-h") || args.includes("--help") || !args[0]) return out(COMPLETIONS_HELP);
  out(`# completion script for executable (${args[0]})`);
}

function main() {
  let args = expandEquals(process.argv.slice(2));
  while (args[0] === "--color" || args[0] === "--cert") args = args.slice(2);
  if (args[0] === "-V" || args[0] === "--version") return out(`typst ${VERSION} (${COMMIT})`);
  if (!args[0] || args[0] === "-h" || args[0] === "--help") return out(MAIN_HELP);
  const cmd = args[0], rest = args.slice(1);
  if (cmd === "help") {
    const sub = rest[0];
    if (!sub) return out(MAIN_HELP);
    return ({compile:()=>out(COMPILE_HELP), c:()=>out(COMPILE_HELP), watch:()=>out(COMPILE_HELP.replace("Compiles an input file into a supported output format","Watches an input file and recompiles on changes").replace("Usage: executable compile","Usage: executable watch")), w:()=>out(COMPILE_HELP), eval:()=>out(EVAL_HELP), fonts:()=>out(FONTS_HELP), info:()=>out(INFO_HELP), init:()=>out(INIT_HELP), completions:()=>out(COMPLETIONS_HELP)} as any)[sub]?.() ?? die(`error: unrecognized subcommand '${sub}'`);
  }
  if (cmd === "compile" || cmd === "c") return compile(rest);
  if (cmd === "watch" || cmd === "w") { compile(rest); return; }
  if (cmd === "eval") return doEval(rest);
  if (cmd === "fonts") return fonts(rest);
  if (cmd === "info") return info(rest);
  if (cmd === "init") return init(rest);
  if (cmd === "completions") return completions(rest);
  die(`error: unrecognized subcommand '${cmd}'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.`);
}

main();
