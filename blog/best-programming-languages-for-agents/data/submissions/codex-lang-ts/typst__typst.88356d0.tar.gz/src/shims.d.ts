declare var process: any;
declare var Buffer: any;
declare function require(name: string): any;
declare module "fs";
declare module "path";
declare module "os";
