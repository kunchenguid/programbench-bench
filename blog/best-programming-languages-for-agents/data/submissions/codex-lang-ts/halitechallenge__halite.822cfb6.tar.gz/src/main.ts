declare const require: any;
declare const process: any;

const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
type ChildProcessWithoutNullStreams = any;

type Cell = { owner: number; strength: number; production: number };
type Move = { loc: number; dir: number };

const VERSION = "1.2";
const DIRS = [
  [0, 0],
  [0, -1],
  [1, 0],
  [0, 1],
  [-1, 0],
];

class RNG {
  private state: number;
  constructor(seed: number) {
    this.state = (seed >>> 0) || 1;
  }
  next(): number {
    let x = this.state;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    this.state = x >>> 0;
    return this.state / 0xffffffff;
  }
  int(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }
}

class Bot {
  proc: ChildProcessWithoutNullStreams;
  buffer = "";
  lines: string[] = [];
  waiters: Array<(line: string | null) => void> = [];
  name = "";
  alive = true;
  timedOut = false;

  constructor(public id: number, public command: string) {
    this.proc = spawn(command, { shell: true, stdio: "pipe" });
    this.proc.stdout.setEncoding("utf8");
    this.proc.stdout.on("data", (chunk: string) => this.onData(chunk));
    this.proc.on("exit", () => {
      this.alive = false;
      while (this.waiters.length) this.waiters.shift()!(null);
    });
    this.proc.stdin.on("error", () => undefined);
  }

  private onData(chunk: string): void {
    this.buffer += chunk;
    for (;;) {
      const idx = this.buffer.indexOf("\n");
      if (idx < 0) break;
      const line = this.buffer.slice(0, idx).replace(/\r$/, "");
      this.buffer = this.buffer.slice(idx + 1);
      const waiter = this.waiters.shift();
      if (waiter) waiter(line);
      else this.lines.push(line);
    }
  }

  send(line: string): void {
    if (!this.proc.killed && this.proc.stdin.writable) {
      this.proc.stdin.write(line + "\n");
    }
  }

  readLine(ms: number, ignoreTimeouts: boolean): Promise<string | null> {
    if (this.lines.length) return Promise.resolve(this.lines.shift()!);
    if (!this.alive) return Promise.resolve(null);
    return new Promise((resolve) => {
      let done = false;
      let timer: any;
      const finish = (line: string | null) => {
        if (done) return;
        done = true;
        if (timer) clearTimeout(timer);
        resolve(line);
      };
      this.waiters.push(finish);
      if (!ignoreTimeouts) {
        timer = setTimeout(() => {
          const idx = this.waiters.indexOf(finish);
          if (idx >= 0) this.waiters.splice(idx, 1);
          this.timedOut = true;
          finish(null);
        }, ms);
      }
    });
  }

  close(): void {
    try { this.proc.kill(); } catch {}
  }
}

function help(): string {
  return `
USAGE: 

   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                 string containing two space-seprated positive integers>]
                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                 [-h] <Array of strings> ...


Where: 

   -i <path to directory>,  --replaydirectory <path to directory>
     The path to directory for replay output.

   -s <positive integer>,  --seed <positive integer>
     The seed for the map generator.

   -d <a string containing two space-seprated positive integers>, 
      --dimensions <a string containing two space-seprated positive
      integers>
     The dimensions of the map.

   -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>
     Create a map that will accommodate n players [SINGLE PLAYER MODE
     ONLY].

   -r,  --noreplay
     Turns off the replay generation.

   -t,  --timeout
     Causes game environment to ignore timeouts (give all bots infinite
     time).

   -o,  --override
     Overrides player-sent names using cmd args [SERVER ONLY].

   -q,  --quiet
     Runs game in quiet mode, producing machine-parsable output.

   --,  --ignore_rest
     Ignores the rest of the labeled arguments following this flag.

   --version
     Displays version information and exits.

   -h,  --help
     Displays usage information and exits.

   <Array of strings>  (accepted multiple times)
     Start commands for bots.


   Halite Game Environment
`;
}

function parseArgs(argv: string[]) {
  const opts = {
    replayDir: ".",
    seed: Math.floor(Date.now() / 1000),
    width: 40,
    height: 40,
    nplayers: 0,
    noreplay: false,
    timeout: false,
    override: false,
    quiet: false,
    commands: [] as string[],
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const need = () => argv[++i] ?? "";
    if (a === "-h" || a === "--help") {
      process.stdout.write(help());
      process.exit(0);
    } else if (a === "--version") {
      console.log(`\n./executable  version: ${VERSION}\n`);
      process.exit(0);
    } else if (a === "-i" || a === "--replaydirectory") {
      opts.replayDir = need();
    } else if (a === "-s" || a === "--seed") {
      const s = Number(need());
      if (!Number.isInteger(s) || s <= 0) parseError(a, "Couldn't read argument value");
      opts.seed = s;
    } else if (a === "-d" || a === "--dimensions") {
      const raw = need();
      const m = raw.trim().match(/^(\d+)\s+(\d+)$/);
      if (!m) parseError("-d (--dimensions)", `Couldn't read argument value from string '${raw}'`);
      opts.width = Number(m[1]);
      opts.height = Number(m[2]);
    } else if (a === "-n" || a === "--nplayers") {
      const n = Number(need());
      if (!Number.isInteger(n) || n < 1 || n > 6) parseError("-n (--nplayers)", "Value must be in {1,2,3,4,5,6}");
      opts.nplayers = n;
    } else if (a === "-r" || a === "--noreplay") opts.noreplay = true;
    else if (a === "-t" || a === "--timeout") opts.timeout = true;
    else if (a === "-o" || a === "--override") opts.override = true;
    else if (a === "-q" || a === "--quiet") opts.quiet = true;
    else if (a === "--") {
      opts.commands.push(...argv.slice(i + 1));
      break;
    } else if (a.startsWith("-")) parseError(a, "Unknown argument");
    else opts.commands.push(a);
  }
  if (opts.commands.length === 0) {
    console.error("Please provide the launch command string for at least one bot.");
    console.error("Use the --help flag for usage details.");
    process.exit(1);
  }
  if (opts.commands.length > 6) opts.commands = opts.commands.slice(0, 6);
  if (opts.nplayers && opts.commands.length === 1) {
    // Single-player map generation can reserve starts for extra players, but
    // only the launched bot participates in the game.
  }
  return opts;
}

function parseError(arg: string, msg: string): never {
  console.error(`PARSE ERROR: Argument: ${arg}`);
  console.error(`             ${msg}\n`);
  console.error("Brief USAGE: ");
  console.error("   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a");
  console.error("                 string containing two space-seprated positive integers>]");
  console.error("                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]");
  console.error("                 [-h] <Array of strings> ...\n");
  console.error("For complete USAGE and HELP type: ");
  console.error("   ./executable --help\n");
  process.exit(1);
  throw new Error("unreachable");
}

function loc(x: number, y: number, w: number, h: number): number {
  const xx = ((x % w) + w) % w;
  const yy = ((y % h) + h) % h;
  return yy * w + xx;
}

function makeMap(w: number, h: number, seed: number, players: number): Cell[] {
  const rng = new RNG(seed);
  const map: Cell[] = [];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const cx = Math.min(x, w - 1 - x);
      const cy = Math.min(y, h - 1 - y);
      const wave = Math.abs(Math.sin((cx + 3) * 1.7 + (cy + 5) * 0.9 + seed));
      const production = Math.max(1, Math.min(15, Math.floor(1 + wave * 7 + rng.int(0, 3))));
      const strength = Math.max(0, Math.min(255, Math.floor(18 + production * rng.int(6, 16) + rng.int(0, 35))));
      map.push({ owner: 0, strength, production });
    }
  }
  const starts = startingLocations(w, h, players);
  for (let p = 1; p <= players; p++) {
    const [sx, sy] = starts[p - 1];
    const c = map[loc(sx, sy, w, h)];
    c.owner = p;
    c.strength = 100;
    c.production = Math.max(c.production, 3);
  }
  return map;
}

function startingLocations(w: number, h: number, players: number): Array<[number, number]> {
  const base: Array<[number, number]> = [
    [Math.floor(w / 2), Math.floor(h / 2)],
    [Math.floor(w / 4), Math.floor(h / 2)],
    [Math.floor((3 * w) / 4), Math.floor(h / 2)],
    [Math.floor(w / 2), Math.floor(h / 4)],
    [Math.floor(w / 2), Math.floor((3 * h) / 4)],
    [Math.floor(w / 4), Math.floor(h / 4)],
  ];
  if (players === 2) return [[Math.floor(w / 4), Math.floor(h / 2)], [Math.floor((3 * w) / 4), Math.floor(h / 2)]];
  return base.slice(0, players);
}

function productionLine(map: Cell[]): string {
  return map.map((c) => c.production).join(" ") + " ";
}

function mapLine(map: Cell[]): string {
  const parts: number[] = [];
  let i = 0;
  while (i < map.length) {
    const owner = map[i].owner;
    let count = 1;
    while (i + count < map.length && map[i + count].owner === owner) count++;
    parts.push(count, owner);
    i += count;
  }
  for (const c of map) parts.push(c.strength);
  return parts.join(" ") + " ";
}

function parseMoves(line: string, player: number, map: Cell[]): Move[] {
  const nums = line.trim().split(/\s+/).filter(Boolean).map(Number);
  const moves: Move[] = [];
  const seen = new Set<number>();
  for (let i = 0; i + 1 < nums.length; i += 2) {
    const l = nums[i], d = nums[i + 1];
    if (!Number.isInteger(l) || !Number.isInteger(d) || l < 0 || l >= map.length || d < 0 || d > 4) continue;
    if (map[l].owner !== player || seen.has(l)) continue;
    seen.add(l);
    moves.push({ loc: l, dir: d });
  }
  for (let l = 0; l < map.length; l++) {
    if (map[l].owner === player && !seen.has(l)) moves.push({ loc: l, dir: 0 });
  }
  return moves;
}

function step(map: Cell[], w: number, h: number, allMoves: Map<number, Move[]>): Cell[] {
  const incoming: Array<Map<number, number>> = Array.from({ length: map.length }, () => new Map());
  const moved = new Set<number>();
  for (const [player, moves] of allMoves) {
    for (const m of moves) {
      const x = m.loc % w, y = Math.floor(m.loc / w);
      const [dx, dy] = DIRS[m.dir] || DIRS[0];
      const to = loc(x + dx, y + dy, w, h);
      const amount = map[m.loc].owner === player ? map[m.loc].strength : 0;
      if (amount <= 0) continue;
      moved.add(m.loc);
      incoming[to].set(player, (incoming[to].get(player) || 0) + amount);
    }
  }
  for (let i = 0; i < map.length; i++) {
    if (!moved.has(i) && map[i].owner > 0 && map[i].strength > 0) {
      incoming[i].set(map[i].owner, (incoming[i].get(map[i].owner) || 0) + map[i].strength);
    }
    if (map[i].owner === 0 && map[i].strength > 0) {
      incoming[i].set(0, (incoming[i].get(0) || 0) + map[i].strength);
    }
  }
  const next = map.map((c) => ({ ...c, owner: 0, strength: 0 }));
  for (let i = 0; i < map.length; i++) {
    const groups = [...incoming[i].entries()].map(([owner, strength]) => ({ owner, strength }));
    if (groups.length === 0) {
      next[i].owner = 0;
      next[i].strength = 0;
      continue;
    }
    groups.sort((a, b) => b.strength - a.strength);
    const winner = groups[0];
    const opposition = groups.slice(1).reduce((s, g) => s + g.strength, 0);
    if (winner.strength > opposition) {
      next[i].owner = winner.owner;
      next[i].strength = Math.min(255, winner.strength - opposition);
    } else {
      next[i].owner = 0;
      next[i].strength = Math.min(255, opposition - winner.strength);
    }
  }
  for (let i = 0; i < next.length; i++) {
    if (next[i].owner > 0) {
      const stayed = allMoves.get(next[i].owner)?.some((m) => m.loc === i && m.dir === 0);
      if (stayed) next[i].strength = Math.min(255, next[i].strength + next[i].production);
    }
  }
  return next;
}

function alivePlayers(map: Cell[], n: number): Set<number> {
  const s = new Set<number>();
  for (const c of map) if (c.owner > 0 && c.owner <= n) s.add(c.owner);
  return s;
}

function maxTurns(w: number, h: number): number {
  return Math.min(500, Math.floor(Math.sqrt(w * h) * 10));
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  const playerSlots = opts.nplayers || opts.commands.length;
  let map = makeMap(opts.width, opts.height, opts.seed, playerSlots);
  const turns = maxTurns(opts.width, opts.height);
  const frames: number[][][][] = [];
  const pushFrame = () => {
    const frame: number[][][] = [];
    for (let y = 0; y < opts.height; y++) {
      const row: number[][] = [];
      for (let x = 0; x < opts.width; x++) {
        const c = map[loc(x, y, opts.width, opts.height)];
        row.push([c.owner, c.strength]);
      }
      frame.push(row);
    }
    frames.push(frame);
  };

  for (const c of opts.commands) console.log(c);
  console.log(`${opts.width} ${opts.height}`);

  const bots = opts.commands.map((cmd, i) => new Bot(i + 1, cmd));
  for (const bot of bots) {
    bot.send(String(bot.id));
    bot.send(`${opts.width} ${opts.height} `);
    bot.send(productionLine(map));
    bot.send(mapLine(map));
  }
  for (const bot of bots) {
    const name = await bot.readLine(15000, opts.timeout);
    bot.name = opts.override ? bot.command : (name && name.trim() ? name.trim().slice(0, 64) : bot.command);
    if (!opts.quiet) console.log(`Init Message received from player ${bot.id}, ${bot.name}.`);
  }

  const lastAlive = new Map<number, number>();
  bots.forEach((b) => lastAlive.set(b.id, 0));
  pushFrame();
  for (let turn = 1; turn <= turns; turn++) {
    if (!opts.quiet) console.log(`Turn ${turn}`);
    for (const bot of bots) if (bot.alive) bot.send(mapLine(map));
    const allMoves = new Map<number, Move[]>();
    for (const bot of bots) {
      if (!bot.alive) continue;
      const line = await bot.readLine(1000, opts.timeout);
      if (line === null) {
        bot.alive = false;
        if (!opts.quiet) console.log(`Bot #${bot.id} timeout or error (Unix) 0`);
        continue;
      }
      allMoves.set(bot.id, parseMoves(line, bot.id, map));
    }
    map = step(map, opts.width, opts.height, allMoves);
    const alive = alivePlayers(map, bots.length);
    for (const p of alive) lastAlive.set(p, turn);
    pushFrame();
    if (alive.size <= 1 && bots.length > 1) break;
  }

  const totals = bots.map((b) => {
    let cells = 0, strength = 0;
    for (const c of map) if (c.owner === b.id) { cells++; strength += c.strength; }
    return { bot: b, cells, strength, last: lastAlive.get(b.id) || 0 };
  });
  totals.sort((a, b) => (b.last - a.last) || (b.cells - a.cells) || (b.strength - a.strength) || (a.bot.id - b.bot.id));
  const rank = new Map<number, number>();
  totals.forEach((t, i) => rank.set(t.bot.id, i + 1));

  if (!opts.noreplay) {
    fs.mkdirSync(opts.replayDir, { recursive: true });
    const replayName = `${opts.seed}-${bots.length}.hlt`;
    const replayPath = path.join(opts.replayDir, replayName);
    const replay = {
      frames,
      productions: Array.from({ length: opts.height }, (_, y) => Array.from({ length: opts.width }, (_, x) => map[loc(x, y, opts.width, opts.height)].production)),
      width: opts.width,
      height: opts.height,
      player_names: bots.map((b) => b.name),
    };
    fs.writeFileSync(replayPath, JSON.stringify(replay));
    if (opts.quiet) console.log(replayPath);
  }

  for (const b of bots) {
    const r = rank.get(b.id) || bots.length;
    const last = lastAlive.get(b.id) || 0;
    if (opts.quiet) console.log(`${b.id} ${r} ${last || turns}`);
    else console.log(`Player #${b.id}, ${b.name}, came in rank #${r} and was last alive on frame #${last || turns}!`);
  }
  if (opts.quiet) {
    console.log(bots.map((b) => b.name).join(" "));
    console.log(" status:");
  }
  bots.forEach((b) => b.close());
}

main().catch((err) => {
  console.error(err && err.stack ? err.stack : String(err));
  process.exit(1);
});
