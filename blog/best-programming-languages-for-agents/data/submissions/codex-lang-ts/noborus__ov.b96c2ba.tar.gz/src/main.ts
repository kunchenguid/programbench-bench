declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");

const HELP = `ov is a feature rich pager(such as more/less).
It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).

Usage:
  ov [flags] [FILE]...

Flags:
Short   Long                                    Purpose
  -l, --align                                   align the output columns for better readability
  -C, --alternate-rows                          alternately change the line color
      --caption string                          custom caption
  -i, --case-sensitive                          case-sensitive in search
  -d, --column-delimiter character              column delimiter character (default ",")
  -c, --column-mode                             column mode
      --column-rainbow                          column mode to rainbow
      --column-width                            column mode for width
      --completion string                       generate completion script [bash|zsh|fish|powershell]
      --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)
      --converter string                        converter [es|raw|align] (default "es")
      --debug                                   debug mode
      --disable-column-cycle                    disable column cycling
      --disable-mouse                           disable mouse support
  -e, --exec                                    command execution result instead of file
  -X, --exit-write                              output the current screen when exiting
  -a, --exit-write-after int                    number after the current lines when exiting
  -b, --exit-write-before int                   number before the current lines when exiting
      --filter string                           filter search pattern
  -A, --follow-all                              follow multiple files and show the most recently updated one
  -f, --follow-mode                             monitor file and display new content as it is written
      --follow-name                             follow mode to monitor by file name
      --follow-section                          section-by-section follow mode
      --force-screen                            display screen even when redirecting output
  -H, --header int                              number of header lines to be displayed constantly
  -Y, --header-column int                       number of columns to display as a vertical header
  -h, --help                                    help for ov
      --help-key                                display key bind information
      --hide-other-section                      hide other section
      --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default "10%")
      --incsearch[=true|false]                  incremental search (default true)
  -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']
  -n, --line-number                             line number mode
      --list-view-modes                         list available view modes defined in the configuration file
      --memory-limit int                        number of chunks to limit in memory (default -1)
      --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)
  -M, --multi-color strings                     comma separated words(regexp) to color .e.g. "ERROR,WARNING"
      --non-match-filter string                 filter non match search pattern
      --notify-eof int                          notify at the end of the file
      --pattern string                          search pattern
  -p, --plain                                   disable original decoration
  -F, --quit-if-one-screen                      quit if the output fits on one screen
  -r, --raw                                     raw escape sequences without processing
      --regexp-search                           regular expression search
      --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)
      --section-delimiter regexp                regexp for section delimiter .e.g. "^#"
      --section-header                          enable section-delimiter line as Header
      --section-header-num int                  number of section header lines (default 1)
      --section-start int                       section start position
      --set-terminal-title                      set terminal title
      --skip-extract                            skip extracting compressed files
      --skip-lines int                          skip the number of lines
      --smart-case-sensitive                    smart case-sensitive in search
      --status-line[=true|false]                status line (default true)
  -x, --tab-width int                           tab stop width (default 8)
  -v, --version                                 display version information
  -y, --vertical-header int                     number of characters to display as a vertical header
  -m, --view-mode string                        apply predefined settings for a specific mode
  -T, --watch seconds                           watch mode interval(seconds)
  -w, --wrap[=true|false]                       wrap mode (default true)
`;

const HELP_KEY = `ov is a feature rich pager
 Key                            Action

\tGeneral
 [Escape], [q]                  * quit
 [ctrl+c]                       * cancel
 [Q]                            * output screen and quit
 [ctrl+q]                       * set output screen and quit
 [alt+shift+F8]                 * set output original screen and quit
 [ctrl+z]                       * suspend
 [alt+v]                        * edit current document
 [h], [ctrl+F1], [ctrl+alt+c]   * display help screen
 [ctrl+F2], [ctrl+alt+e]        * display log screen
 [ctrl+l]                       * screen sync
 [ctrl+f]                       * follow mode toggle
 [ctrl+a]                       * follow all mode toggle
 [ctrl+F8], [ctrl+alt+r]        * enable/disable mouse
 [S]                            * save buffer to file

\tMoving
 [Enter], [Down], [ctrl+n]      * forward by one line
 [Up], [ctrl+p]                 * backward by one line
 [Home]                         * go to top of document
 [End]                          * go to end of document
 [PageDown], [ctrl+v]           * forward by page
 [PageUp], [ctrl+b]             * backward by page
 [ctrl+d]                       * forward a half page
 [ctrl+u]                       * backward a half page
 [left]                         * scroll left
 [right]                        * scroll right
 [ctrl+left]                    * scroll left half screen
 [ctrl+right]                   * scroll right half screen
 [alt+left]                     * scroll left specified width
 [alt+right]                    * scroll right specified width
 [shift+Home]                   * go to beginning of line
 [shift+End]                    * go to end of line
 [g]                            * go to line(input number or \`.n\` or \`n%\` allowed)
 [,]                            * go to mark number(input number allowed)

\tSidebar
 [alt+h]                        * show/hide help in sidebar
 [alt+m]                        * show mark list in sidebar
 [alt+l]                        * show document list in sidebar
 [shift+Up]                     * scroll up in sidebar
 [shift+Down]                   * scroll down in sidebar
 [shift+Left]                   * scroll left in sidebar
 [shift+Right]                  * scroll right in sidebar

\tMove document
 []]                            * next document
 [[]                            * previous document
 [ctrl+k]                       * close current document
 [K]                            * close all filtered documents

\tMark position
 [m]                            * mark current position
 [M]                            * remove mark current position
 [ctrl+delete]                  * remove all mark
 [>]                            * move to next marked position
 [<]                            * move to previous marked position
 [*]                            * mark by pattern mode

\tSearch
 [/]                            * forward search mode
 [?]                            * backward search mode
 [n]                            * repeat forward search
 [N]                            * repeat backward search
 [&]                            * filter search mode

\tChange display
 [w], [W]                       * wrap/nowrap toggle
 [c]                            * column mode toggle
 [alt+o]                        * column width toggle
 [ctrl+r]                       * column rainbow toggle
 [C]                            * alternate rows of style toggle
 [G]                            * line number toggle
 [ctrl+e]                       * original decoration toggle(plain)
 [alt+f]                        * align columns
 [alt+r]                        * raw output
 [alt+shift+F9]                 * ruler toggle
 [ctrl+F10]                     * status line toggle

\tChange Display with Input
 [p], [P]                       * view mode selection
 [d]                            * column delimiter string
 [H]                            * number of header lines
 [ctrl+s]                       * number of skip lines
 [t]                            * TAB width
 [.]                            * multi color highlight
 [j]                            * jump target(\`.n\` or \`n%\` or \`section\` allowed)
 [alt+t]                        * convert type selection
 [y]                            * number of vertical header
 [Y]                            * number of header column

\tColumn operation
 [F]                            * header column fixed toggle
 [s]                            * shrink column toggle(align mode only)
 [alt+a]                        * right align column toggle(align mode only)

\tSection operation
 [alt+d]                        * section delimiter regular expression
 [ctrl+F3], [alt+s]             * section start position
 [space]                        * next section
 [^]                            * previous section
 [9]                            * last section
 [F2]                           * follow section mode toggle
 [F7]                           * number of section header lines
 [alt+-]                        * hide "other" section toggle

\tClose and reload
 [ctrl+F9], [ctrl+alt+s]        * close file
 [F5], [ctrl+alt+l]             * reload file
 [F4], [ctrl+alt+w]             * watch mode
 [ctrl+w]                       * set watch interval

\tKey binding when typing
 [alt+c]                        * case-sensitive toggle
 [alt+s]                        * smart case-sensitive toggle
 [alt+r]                        * regular expression search toggle
 [alt+i]                        * incremental search toggle
`;

const longArg = new Set([
  "caption", "column-delimiter", "completion", "config", "converter",
  "exit-write-after", "exit-write-before", "filter", "header",
  "header-column", "hscroll-width", "jump-target", "memory-limit",
  "memory-limit-file", "multi-color", "non-match-filter", "notify-eof",
  "pattern", "ruler", "section-delimiter", "section-header-num",
  "section-start", "skip-lines", "tab-width", "vertical-header",
  "view-mode", "watch"
]);

const longBool = new Set([
  "align", "alternate-rows", "case-sensitive", "column-mode",
  "column-rainbow", "column-width", "debug", "disable-column-cycle",
  "disable-mouse", "exec", "exit-write", "follow-all", "follow-mode",
  "follow-name", "follow-section", "force-screen", "help", "help-key",
  "hide-other-section", "incsearch", "line-number", "list-view-modes",
  "plain", "quit-if-one-screen", "raw", "regexp-search", "section-header",
  "set-terminal-title", "skip-extract", "smart-case-sensitive",
  "status-line", "version", "wrap"
]);

const shortArg: Record<string, string> = {
  a: "exit-write-after", b: "exit-write-before", d: "column-delimiter",
  H: "header", j: "jump-target", M: "multi-color", T: "watch",
  x: "tab-width", y: "vertical-header", Y: "header-column", m: "view-mode"
};
const shortBool = new Set(["l", "C", "i", "c", "e", "X", "A", "f", "h", "n", "p", "F", "r", "v", "w"]);

function fail(message: string) {
  process.stdout.write(`Error: ${message}\n`);
  process.exit(1);
}

function completion(shell: string) {
  if (!["bash", "zsh", "fish", "powershell"].includes(shell)) {
    fail("requires one of the arguments bash/zsh/fish/powershell");
  }
  if (shell === "zsh") {
    process.stdout.write(`#compdef ov\ncompdef _ov ov\n\n# zsh completion for ov                                   -*- shell-script -*-\n\n__ov_debug()\n{\n    local file="$BASH_COMP_DEBUG_FILE"\n    if [[ -n \${file} ]]; then\n        echo "$*" >> "\${file}"\n    fi\n}\n`);
  } else if (shell === "fish") {
    process.stdout.write(`# fish completion for ov                                   -*- shell-script -*-\n\nfunction __ov_debug\n    set -l file "$BASH_COMP_DEBUG_FILE"\n    if test -n "$file"\n        echo "$argv" >> $file\n    end\nend\n\nfunction __ov_perform_completion\n    __ov_debug "Starting __ov_perform_completion"\nend\n`);
  } else if (shell === "powershell") {
    process.stdout.write(`# powershell completion for ov                                   -*- shell-script -*-\n\nfunction __ov_debug {\n    if ($env:BASH_COMP_DEBUG_FILE) {\n        "$args" | Out-File -Append -FilePath "$env:BASH_COMP_DEBUG_FILE"\n    }\n}\n`);
  } else {
    process.stdout.write(`# bash completion for ov                                   -*- shell-script -*-\n\n__ov_debug()\n{\n    if [[ -n \${BASH_COMP_DEBUG_FILE:-} ]]; then\n        echo "$*" >> "\${BASH_COMP_DEBUG_FILE}"\n    fi\n}\n\n__ov_init_completion()\n{\n    COMPREPLY=()\n    _get_comp_words_by_ref "$@" cur prev words cword\n}\n`);
  }
}

function readMaybeConfig(path: string) {
  try {
    fs.accessSync(path, fs.constants.R_OK);
  } catch (e: any) {
    process.stdout.write(`failed to read config file: open ${path}: no such file or directory\n`);
  }
}

function outputFile(path: string): boolean {
  try {
    const data = fs.readFileSync(path);
    process.stdout.write(data);
    return true;
  } catch (e: any) {
    process.stdout.write(`Error: open ${path}: no such file or directory\n`);
    return false;
  }
}

function main() {
  const args = process.argv.slice(2);
  if (args[0] === "__complete" || args[0] === "__completeNoDesc") {
    const last = args.length ? args[args.length - 1] : "";
    const candidates = [
      "--align", "--alternate-rows", "--caption", "--case-sensitive",
      "--column-delimiter", "--column-mode", "--completion", "--config",
      "--debug", "--exec", "--filter", "--follow-mode", "--header",
      "--help", "--help-key", "--line-number", "--list-view-modes",
      "--pattern", "--plain", "--raw", "--version", "--view-mode", "--wrap"
    ];
    for (const c of candidates) {
      if (!last || c.startsWith(last)) process.stdout.write(`${c}\n`);
    }
    process.stdout.write(":4\n");
    return;
  }
  const files: string[] = [];
  let wantHelp = false, wantHelpKey = false, wantVersion = false, listModes = false;
  let completionShell: string | undefined;
  let hadMissingFile = false;

  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") {
      files.push(...args.slice(i + 1));
      break;
    }
    if (a.startsWith("--") && a.length > 2) {
      const raw = a.slice(2);
      const eq = raw.indexOf("=");
      const name = eq >= 0 ? raw.slice(0, eq) : raw;
      let value = eq >= 0 ? raw.slice(eq + 1) : undefined;
      if (longArg.has(name)) {
        if (value === undefined) {
          if (i + 1 >= args.length) fail(`flag needs an argument: --${name}`);
          value = args[++i];
        }
        if (name === "completion") completionShell = value;
        if (name === "config") readMaybeConfig(value);
      } else if (longBool.has(name)) {
        if (name === "help") wantHelp = true;
        else if (name === "help-key") wantHelpKey = true;
        else if (name === "version") wantVersion = true;
        else if (name === "list-view-modes") listModes = true;
      } else {
        fail(`unknown flag: --${name}`);
      }
      continue;
    }
    if (a.startsWith("-") && a !== "-") {
      const flag = a.slice(1, 2);
      if (shortArg[flag]) {
        let value = a.length > 2 ? a.slice(2) : undefined;
        if (value === undefined) {
          if (i + 1 >= args.length) fail(`flag needs an argument: '${flag}' in -${flag}`);
          value = args[++i];
        }
      } else if (shortBool.has(flag)) {
        if (flag === "h") wantHelp = true;
        if (flag === "v") wantVersion = true;
      } else {
        fail(`unknown shorthand flag: '${flag}' in -${flag}`);
      }
      continue;
    }
    files.push(a);
  }

  if (wantHelp) {
    process.stdout.write(HELP);
    return;
  }
  if (wantHelpKey) {
    process.stdout.write(HELP_KEY);
    return;
  }
  if (wantVersion) {
    process.stdout.write("ov version dev rev:HEAD\n");
    return;
  }
  if (completionShell !== undefined) {
    completion(completionShell);
    return;
  }
  if (listModes) {
    process.stdout.write("general\n");
    return;
  }

  if (files.length === 0) {
    if (!process.stdin.isTTY) {
      const buf = fs.readFileSync(0);
      if (buf.length) process.stdout.write(buf);
    }
    return;
  }
  for (const f of files) {
    if (!outputFile(f)) hadMissingFile = true;
  }
  if (hadMissingFile) process.exit(1);
}

main();
