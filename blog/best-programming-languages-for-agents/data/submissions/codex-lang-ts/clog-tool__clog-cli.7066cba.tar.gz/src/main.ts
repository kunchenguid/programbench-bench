declare const require: any;
declare const process: any;

const { execFileSync } = require("child_process");
const fs = require("fs");
const path = require("path");

type Opts = {
  repository?: string;
  from?: string;
  to: string;
  format: "markdown" | "json";
  major: boolean;
  minor: boolean;
  patch: boolean;
  gitDir?: string;
  workTree?: string;
  subtitle?: string;
  outfile?: string;
  config: string;
  infile?: string;
  setversion?: string;
  fromLatestTag: boolean;
  linkStyle: "github" | "gitlab" | "stash" | "cgit";
  changelog?: string;
};

type Commit = {
  hash: string;
  short: string;
  subject: string;
  body: string;
};

type Entry = {
  type: string;
  scope?: string;
  text: string;
  commit: Commit;
  closes: string[];
  breaking: boolean;
};

const sectionTitles: Record<string, string> = {
  feat: "Features",
  feature: "Features",
  fix: "Bug Fixes",
  bugfix: "Bug Fixes",
  perf: "Performance",
  docs: "Documentation",
  doc: "Documentation",
  style: "Style Fixes",
  refactor: "Refactoring",
  test: "Tests",
  tests: "Tests",
  chore: "Chores",
  build: "Build",
  ci: "Continuous Integration",
};

const sectionOrder = [
  "Breaking Changes",
  "Features",
  "Bug Fixes",
  "Performance",
  "Documentation",
  "Style Fixes",
  "Refactoring",
  "Tests",
  "Build",
  "Continuous Integration",
  "Chores",
];

function printHelp(): void {
  process.stdout.write(`a conventional changelog for the rest of us

Usage: executable [OPTIONS]

Options:
  -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,
                          e.g. https://github.com/thoughtram/clog)
  -f, --from <COMMIT>     e.g. 12a8546
  -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible
                          values: markdown, json]
  -M, --major             Increment major version by one (Sets minor and patch to 0)
  -g, --git-dir <PATH>    Local .git directory (defaults to "$(pwd)/.git")
  -w, --work-tree <PATH>  Local working tree of the git project (defaults to "$(pwd)")
  -m, --minor             Increment minor version by one (Sets patch to 0)
  -p, --patch             Increment patch version by one
  -s, --subtitle <STR>    
  -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]
  -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)
  -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]
  -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with
                          --outfile)
      --setversion <VER>  e.g. 1.0.1
  -F, --from-latest-tag   use latest tag as start (instead of --from)
  -l, --link-style <STR>  The style of repository link to generate [default: github] [possible
                          values: github, gitlab, stash, cgit]
  -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the
                          same file for both --infile and --outfile and should not be used in
                          conjunction with either)
  -h, --help              Print help
  -V, --version           Print version
`);
}

function needValue(args: string[], i: number, flag: string): string {
  const v = args[i + 1];
  if (!v || v.startsWith("-")) {
    die(`error: a value is required for '${flag}'`, 2, false);
  }
  return v;
}

function parseArgs(argv: string[]): Opts {
  const opts: Opts = {
    to: "HEAD",
    format: "markdown",
    major: false,
    minor: false,
    patch: false,
    config: ".clog.toml",
    fromLatestTag: false,
    linkStyle: "github",
  };

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = () => needValue(argv, i++, a);
    switch (a) {
      case "-h":
      case "--help":
        printHelp();
        process.exit(0);
      case "-V":
      case "--version":
        console.log("clog 0.10.0");
        process.exit(0);
      case "-r":
      case "--repository":
        opts.repository = next();
        break;
      case "-f":
      case "--from":
        opts.from = next();
        break;
      case "-T":
      case "--format": {
        const v = next();
        if (v !== "markdown" && v !== "json") die(`error: invalid value '${v}' for '--format <STR>'`, 2, false);
        opts.format = v;
        break;
      }
      case "-M":
      case "--major":
        opts.major = true;
        break;
      case "-m":
      case "--minor":
        opts.minor = true;
        break;
      case "-p":
      case "--patch":
        opts.patch = true;
        break;
      case "-g":
      case "--git-dir":
        opts.gitDir = next();
        break;
      case "-w":
      case "--work-tree":
        opts.workTree = next();
        break;
      case "-s":
      case "--subtitle":
        opts.subtitle = next();
        break;
      case "-t":
      case "--to":
        opts.to = next();
        break;
      case "-o":
      case "--outfile":
        opts.outfile = next();
        break;
      case "-c":
      case "--config":
        opts.config = next();
        break;
      case "-i":
      case "--infile":
        opts.infile = next();
        break;
      case "--setversion":
        opts.setversion = next();
        break;
      case "-F":
      case "--from-latest-tag":
        opts.fromLatestTag = true;
        break;
      case "-l":
      case "--link-style": {
        const v = next();
        if (!["github", "gitlab", "stash", "cgit"].includes(v)) die(`error: invalid value '${v}' for '--link-style <STR>'`, 2, false);
        opts.linkStyle = v as Opts["linkStyle"];
        break;
      }
      case "-C":
      case "--changelog":
        opts.changelog = next();
        break;
      default:
        if (a.startsWith("-")) {
          process.stderr.write(`error: unexpected argument '${a}' found

Usage: executable [OPTIONS]

For more information, try '--help'.
`);
          process.exit(2);
        }
        die(`error: unexpected argument '${a}' found`, 2, false);
    }
  }

  return opts;
}

function die(msg: string, code = 1, red = true): never {
  if (red) {
    process.stderr.write(`\x1b[1;31merror:\x1b[0m ${msg}\n`);
  } else {
    process.stderr.write(`${msg}\n`);
  }
  process.exit(code);
  throw new Error(msg);
}

function readConfig(opts: Opts): void {
  const cfgPath = path.resolve(process.cwd(), opts.config);
  if (!fs.existsSync(cfgPath)) return;
  const text = fs.readFileSync(cfgPath, "utf8");
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.replace(/#.*/, "").trim();
    const m = /^([A-Za-z0-9_.-]+)\s*=\s*(.+)$/.exec(line);
    if (!m) continue;
    const key = m[1];
    let val = m[2].trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (!opts.repository && key === "repository") opts.repository = val;
    if (!opts.from && key === "from") opts.from = val;
    if (key === "from-latest-tag" && val === "true" && !opts.from) opts.fromLatestTag = true;
    if (!opts.subtitle && key === "subtitle") opts.subtitle = val;
    if (key === "link-style" && ["github", "gitlab", "stash", "cgit"].includes(val)) opts.linkStyle = val as Opts["linkStyle"];
    if (!opts.changelog && key === "changelog") opts.changelog = val;
  }
}

function gitArgs(opts: Opts, extra: string[]): string[] {
  const args: string[] = [];
  const workTree = opts.workTree || (opts.gitDir ? path.dirname(path.resolve(opts.gitDir)) : undefined);
  const gitDir = opts.gitDir || (opts.workTree ? path.join(path.resolve(opts.workTree), ".git") : undefined);
  if (gitDir) args.push(`--git-dir=${gitDir}`);
  if (workTree) args.push(`--work-tree=${workTree}`);
  return args.concat(extra);
}

function git(opts: Opts, extra: string[]): string {
  try {
    return execFileSync("git", gitArgs(opts, extra), { cwd: opts.workTree || process.cwd(), encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });
  } catch {
    return "";
  }
}

function latestTag(opts: Opts): string | undefined {
  const out = git(opts, ["describe", "--tags", "--abbrev=0", opts.to]).trim();
  return out || undefined;
}

function getCommits(opts: Opts): Commit[] {
  const from = opts.fromLatestTag ? latestTag(opts) : opts.from;
  const range = from ? `${from}..${opts.to}` : opts.to;
  const fmt = "%H%x1f%h%x1f%s%x1f%b%x1e";
  const out = git(opts, ["log", "--reverse", `--format=${fmt}`, range]);
  if (!out) return [];
  return out.split("\x1e").filter(Boolean).map((chunk) => {
    const [hash = "", short = "", subject = "", body = ""] = chunk.replace(/^\n/, "").split("\x1f");
    return { hash: hash.trim(), short: short.trim(), subject: subject.trim(), body: body.trim() };
  });
}

function parseEntry(commit: Commit): Entry | undefined {
  const m = /^([A-Za-z]+)(?:\(([^)]*)\))?(!)?:\s*(.+)$/.exec(commit.subject);
  if (!m) return undefined;
  const type = m[1].toLowerCase();
  if (!sectionTitles[type]) return undefined;
  const breaking = Boolean(m[3]) || /BREAKING[ -]CHANGE:/i.test(commit.body);
  const closes = Array.from(commit.body.matchAll(/\b(?:close[sd]?|fix(?:e[sd])?|resolve[sd]?)\s+#(\d+)/gi)).map((x) => x[1]);
  return { type, scope: m[2] || undefined, text: m[4], commit, closes, breaking };
}

function currentVersionFromTag(opts: Opts): string | undefined {
  const tag = latestTag(opts);
  if (!tag) return undefined;
  const m = /v?(\d+\.\d+\.\d+)/.exec(tag);
  return m?.[1];
}

function bump(v: string, opts: Opts): string {
  const m = /^v?(\d+)\.(\d+)\.(\d+)$/.exec(v);
  if (!m) die("Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.");
  let major = Number(m[1]), minor = Number(m[2]), patch = Number(m[3]);
  if (opts.major) { major++; minor = 0; patch = 0; }
  else if (opts.minor) { minor++; patch = 0; }
  else if (opts.patch) { patch++; }
  return `${major}.${minor}.${patch}`;
}

function outputVersion(opts: Opts): string | undefined {
  if (opts.setversion) return opts.setversion;
  if (opts.major || opts.minor || opts.patch) {
    const base = currentVersionFromTag(opts);
    if (!base) die("Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.");
    return bump(base, opts);
  }
  return undefined;
}

function commitUrl(repo: string | undefined, style: Opts["linkStyle"], hash: string): string | undefined {
  if (!repo) return undefined;
  const r = repo.replace(/\.git$/, "").replace(/\/$/, "");
  if (style === "stash") return `${r}/commits/${hash}`;
  if (style === "cgit") return `${r}/commit/?id=${hash}`;
  return `${r}/commit/${hash}`;
}

function issueUrl(repo: string | undefined, style: Opts["linkStyle"], n: string): string | undefined {
  if (!repo) return undefined;
  const r = repo.replace(/\.git$/, "").replace(/\/$/, "");
  if (style === "stash") return `${r}/browse?focusedCommentId=${n}`;
  if (style === "cgit") return `${r}/issues/${n}`;
  return `${r}/issues/${n}`;
}

function renderEntry(e: Entry, opts: Opts): string {
  const scope = e.scope ? `**${e.scope}**: ` : "";
  const cUrl = commitUrl(opts.repository, opts.linkStyle, e.commit.hash);
  const commitPart = cUrl ? `[${e.commit.short}](${cUrl})` : e.commit.short;
  const issueParts = e.closes.map((n) => {
    const url = issueUrl(opts.repository, opts.linkStyle, n);
    return url ? `closes [#${n}](${url})` : `closes #${n}`;
  });
  const refs = [commitPart].concat(issueParts).join(", ");
  return `* ${scope}${e.text} (${refs})`;
}

function groupEntries(entries: Entry[]): Map<string, Entry[]> {
  const groups = new Map<string, Entry[]>();
  for (const e of entries) {
    if (e.breaking) {
      if (!groups.has("Breaking Changes")) groups.set("Breaking Changes", []);
      groups.get("Breaking Changes")!.push(e);
    }
    const title = sectionTitles[e.type];
    if (!groups.has(title)) groups.set(title, []);
    groups.get(title)!.push(e);
  }
  return groups;
}

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

function renderMarkdown(version: string | undefined, opts: Opts, entries: Entry[]): string {
  const v = version || "";
  const subtitle = opts.subtitle || "";
  let out = `<a name="${v}"></a>\n## ${v} ${subtitle} (${today()})\n\n`;
  const groups = groupEntries(entries);
  for (const name of sectionOrder) {
    const xs = groups.get(name);
    if (!xs || xs.length === 0) continue;
    out += `#### ${name}\n\n`;
    for (const e of xs) out += `${renderEntry(e, opts)}\n`;
    out += "\n";
  }
  out += "\n";
  return out;
}

function renderJson(version: string | undefined, opts: Opts, entries: Entry[]): string {
  const groups = groupEntries(entries);
  const sections: Record<string, unknown[]> = {};
  for (const name of sectionOrder) {
    const xs = groups.get(name);
    if (!xs || xs.length === 0) continue;
    sections[name] = xs.map((e) => ({
      scope: e.scope ?? null,
      message: e.text,
      commit: e.commit.short,
      hash: e.commit.hash,
      closes: e.closes,
    }));
  }
  if (entries.length === 0) {
    return `{"header":{"version":${version ? JSON.stringify(version) : "None"},"patch_version":false,"subtitle":${opts.subtitle ? JSON.stringify(opts.subtitle) : "null"},"date":"${today()}"},"sections":null}`;
  }
  return JSON.stringify({
    header: { version: version ?? null, patch_version: false, subtitle: opts.subtitle ?? null, date: today() },
    sections,
  });
}

function main(): void {
  const start = Date.now();
  const opts = parseArgs(process.argv.slice(2));
  readConfig(opts);
  if (opts.changelog) {
    opts.infile = opts.changelog;
    opts.outfile = opts.changelog;
  }
  const version = outputVersion(opts);
  const entries = getCommits(opts).map(parseEntry).filter((x): x is Entry => Boolean(x));
  let output = opts.format === "json" ? renderJson(version, opts, entries) : renderMarkdown(version, opts, entries);
  const infile = opts.infile;
  if (infile && fs.existsSync(infile)) output += fs.readFileSync(infile, "utf8");
  if (opts.outfile) {
    fs.writeFileSync(opts.outfile, output);
  } else {
    process.stdout.write(output);
  }
  process.stdout.write(`changelog written. (took ${Math.max(0, Date.now() - start)} ms)\n`);
}

main();
