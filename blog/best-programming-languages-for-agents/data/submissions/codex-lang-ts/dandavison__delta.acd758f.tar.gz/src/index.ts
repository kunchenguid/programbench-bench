import { readFileSync, existsSync } from "fs";
import { spawnSync } from "child_process";

type Options = {
  colorOnly: boolean;
  color: "always" | "never" | "auto";
  sideBySide: boolean;
  lineNumbers: boolean;
  keepMarkers: boolean;
  width: number;
  paging: string;
  minusFile?: string;
  plusFile?: string;
};

const VERSION = "delta 0.18.2";
const HELP_TEXT = readFileSync("full-help.txt", "utf8").trimEnd();
const RESET = "\x1b[0m";
const BLUE = "\x1b[34m";
const RED_BG = "\x1b[48;5;52m";
const GREEN_BG = "\x1b[48;5;22m";
const RED_FG = "\x1b[31m";
const GREEN_FG = "\x1b[32m";
const DIM = "\x1b[2m";

process.stdout.on("error", err => {
  if (err && err.code === "EPIPE") process.exit(0);
  throw err;
});

const valueOptions = new Set([
  "--blame-code-style", "--blame-format", "--blame-palette", "--blame-separator-format",
  "--blame-separator-style", "--blame-timestamp-format", "--blame-timestamp-output-format",
  "--config", "--commit-decoration-style", "--commit-regex", "--commit-style",
  "--default-language", "--detect-dark-light", "--diff-args", "-@", "--diff-stat-align-width",
  "--features", "--file-added-label", "--file-copied-label", "--file-decoration-style",
  "--file-modified-label", "--file-removed-label", "--file-renamed-label", "--file-style",
  "--grep-context-line-style", "--grep-file-style", "--grep-line-number-style",
  "--grep-match-line-style", "--grep-match-word-style", "--hunk-header-decoration-style",
  "--hunk-header-file-style", "--hunk-header-line-number-style", "--hunk-header-style",
  "--hyperlinks-commit-link-format", "--hyperlinks-file-link-format", "--line-numbers-left-format",
  "--line-numbers-left-style", "--line-numbers-minus-style", "--line-numbers-plus-style",
  "--line-numbers-right-format", "--line-numbers-right-style", "--line-numbers-zero-style",
  "--map-styles", "--max-line-distance", "--max-line-length", "--minus-emph-style",
  "--minus-empty-line-marker-style", "--minus-non-emph-style", "--minus-style",
  "--navigate-regex", "--pager", "--paging", "--plus-emph-style",
  "--plus-empty-line-marker-style", "--plus-non-emph-style", "--plus-style",
  "--right-arrow", "--side-by-side-separator-style", "--syntax-theme", "--tabs",
  "--theme", "--true-color", "--width", "--word-diff-regex", "--wrap-max-lines",
  "--wrap-right-percent", "--wrap-right-symbol", "--wrap-left-symbol"
]);

function parseArgs(argv: string[]): { opts: Options; commands: Set<string> } {
  const opts: Options = {
    colorOnly: false,
    color: "auto",
    sideBySide: false,
    lineNumbers: false,
    keepMarkers: false,
    width: Number(process.env.COLUMNS || "80") || 80,
    paging: "never"
  };
  const commands = new Set<string>();
  const positional: string[] = [];

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--") {
      positional.push(...argv.slice(i + 1));
      break;
    }
    if (arg === "-h" || arg === "--help") commands.add("help");
    else if (arg === "-V" || arg === "--version") commands.add("version");
    else if (arg === "--list-languages") commands.add("languages");
    else if (arg === "--show-syntax-themes") commands.add("themes");
    else if (arg === "--generate-completion") commands.add("completion");
    else if (arg === "--color-only") opts.colorOnly = true;
    else if (arg === "--side-by-side" || arg === "-s") opts.sideBySide = true;
    else if (arg === "--line-numbers" || arg === "-n") opts.lineNumbers = true;
    else if (arg === "--keep-plus-minus-markers") opts.keepMarkers = true;
    else if (arg === "--no-gitconfig" || arg === "--dark" || arg === "--light" || arg === "--navigate") {
      // Accepted configuration flags.
    } else if (arg.startsWith("--color=")) {
      const value = arg.slice("--color=".length);
      if (value === "always" || value === "never" || value === "auto") opts.color = value;
    } else if (arg.startsWith("--width=")) {
      opts.width = Number(arg.slice("--width=".length)) || opts.width;
    } else if (arg === "--width" && argv[i + 1]) {
      opts.width = Number(argv[++i]) || opts.width;
    } else if (arg.startsWith("--paging=")) {
      opts.paging = arg.slice("--paging=".length);
    } else if (arg === "--paging" && argv[i + 1]) {
      opts.paging = argv[++i];
    } else if (arg.startsWith("-") && arg.includes("=")) {
      // Most delta options are style/config values. Accept them for gitconfig compatibility.
    } else if (valueOptions.has(arg)) {
      i++;
    } else if (arg.startsWith("-")) {
      // Boolean option unknown to this reimplementation. Accept rather than breaking pager use.
    } else {
      positional.push(arg);
    }
  }
  opts.minusFile = positional[0];
  opts.plusFile = positional[1];
  return { opts, commands };
}

function useColor(opts: Options): boolean {
  if (opts.color === "never") return false;
  if (opts.color === "always") return true;
  return process.env.NO_COLOR !== "1" && process.env.TERM !== "dumb";
}

function c(text: string, code: string, enabled: boolean): string {
  return enabled ? `${code}${text}${RESET}` : text;
}

function readStdin(): Promise<string> {
  return new Promise(resolve => {
    let data = "";
    process.stdin.setEncoding("utf8");
    process.stdin.on("data", chunk => { data += chunk; });
    process.stdin.on("end", () => resolve(data));
    process.stdin.resume();
  });
}

function unifiedDiff(a: string, b: string): string {
  if (!existsSync(a) || !existsSync(b)) {
    const missing = !existsSync(a) ? a : b;
    process.stderr.write(`No such file or directory: ${missing}\n`);
    process.exit(2);
  }
  const diff = spawnSync("diff", ["-u", a, b], { encoding: "utf8" });
  if (diff.error) {
    const left = readFileSync(a, "utf8").split(/\n/);
    const right = readFileSync(b, "utf8").split(/\n/);
    return fallbackDiff(a, b, left, right);
  }
  return diff.stdout || diff.stderr;
}

function fallbackDiff(a: string, b: string, left: string[], right: string[]): string {
  const out = [`--- ${a}`, `+++ ${b}`, `@@ -1,${left.length} +1,${right.length} @@`];
  const max = Math.max(left.length, right.length);
  for (let i = 0; i < max; i++) {
    if (left[i] === right[i]) out.push(` ${left[i] ?? ""}`);
    else {
      if (i < left.length) out.push(`-${left[i]}`);
      if (i < right.length) out.push(`+${right[i]}`);
    }
  }
  return out.join("\n") + "\n";
}

function displayName(path: string): string {
  return path.replace(/^a\//, "").replace(/^b\//, "").replace(/^---\s+/, "").replace(/^\+\+\+\s+/, "");
}

function isDiffLike(input: string): boolean {
  return /(^|\n)(diff --git |--- |\+\+\+ |@@ )/.test(input);
}

function formatColorOnly(input: string, opts: Options): string {
  const color = useColor(opts);
  return input.split(/(\n)/).map(part => {
    if (part === "\n") return part;
    if (part.startsWith("+") && !part.startsWith("+++")) return c(part, GREEN_BG, color);
    if (part.startsWith("-") && !part.startsWith("---")) return c(part, RED_BG, color);
    if (part.startsWith("@@")) return c(part, BLUE, color);
    return part;
  }).join("");
}

function formatNormal(input: string, opts: Options): string {
  if (!isDiffLike(input)) return input;
  if (opts.sideBySide) return formatSideBySide(input, opts);

  const color = useColor(opts);
  const out: string[] = [];
  let currentFile = "";
  let oldPath = "";
  let newPath = "";
  let emittedFile = false;
  let oldLine = 0;
  let newLine = 0;

  for (const raw of input.split(/\n/)) {
    if (raw === "" && out.length === 0) continue;
    if (raw.startsWith("diff --git ")) {
      const m = /^diff --git a\/(.+?) b\/(.+)$/.exec(raw);
      currentFile = m ? (m[1] === m[2] ? m[2] : `${m[1]} -> ${m[2]}`) : raw.slice(11);
      emittedFile = false;
      continue;
    }
    if (raw.startsWith("--- ")) {
      oldPath = displayName(raw.slice(4).trim());
      continue;
    }
    if (raw.startsWith("+++ ")) {
      newPath = displayName(raw.slice(4).trim());
      if (!currentFile) currentFile = oldPath === newPath ? newPath : `${oldPath} -> ${newPath}`;
      continue;
    }
    if (raw.startsWith("index ") || raw.startsWith("new file mode") || raw.startsWith("deleted file mode")) {
      continue;
    }
    if (raw.startsWith("@@")) {
      if (!emittedFile) {
        out.push("");
        out.push(c(currentFile || newPath || oldPath, BLUE, color));
        out.push(c("─".repeat(Math.max(3, Math.min(opts.width, 80))), BLUE, color));
        emittedFile = true;
      }
      const nums = /@@ -(\d+)(?:,\d+)? \+(\d+)/.exec(raw);
      oldLine = nums ? Number(nums[1]) : 0;
      newLine = nums ? Number(nums[2]) : 0;
      out.push(c(raw, BLUE, color));
      continue;
    }
    if (raw.startsWith("-") && !raw.startsWith("---")) {
      out.push(withLine(opts, oldLine++, "", c(renderPayload(raw, "-", opts), RED_BG, color)));
      continue;
    }
    if (raw.startsWith("+") && !raw.startsWith("+++")) {
      out.push(withLine(opts, "", newLine++, c(renderPayload(raw, "+", opts), GREEN_BG, color)));
      continue;
    }
    if (raw.startsWith(" ")) {
      out.push(withLine(opts, oldLine++, newLine++, raw.slice(1)));
      continue;
    }
    if (raw.startsWith("\\ No newline")) {
      out.push(c(raw, DIM, color));
      continue;
    }
    if (raw.trim() !== "") out.push(raw);
  }
  return out.join("\n") + (input.endsWith("\n") ? "\n" : "");
}

function renderPayload(raw: string, marker: string, opts: Options): string {
  return opts.keepMarkers ? raw : raw.slice(marker.length);
}

function withLine(opts: Options, oldLine: number | "", newLine: number | "", text: string): string {
  if (!opts.lineNumbers) return text;
  const left = oldLine === "" ? "    " : String(oldLine).padStart(4);
  const right = newLine === "" ? "    " : String(newLine).padStart(4);
  return `${left} ${right} │ ${text}`;
}

function formatSideBySide(input: string, opts: Options): string {
  const color = useColor(opts);
  const leftWidth = Math.max(20, Math.floor((opts.width - 5) / 2));
  const rightWidth = leftWidth;
  const rows: string[] = [];
  let pendingMinus: string | null = null;

  for (const raw of input.split(/\n/)) {
    if (raw.startsWith("diff --git ") || raw.startsWith("--- ") || raw.startsWith("+++ ") || raw.startsWith("index ")) continue;
    if (raw.startsWith("@@")) {
      rows.push(c(raw, BLUE, color));
      continue;
    }
    if (raw.startsWith("-") && !raw.startsWith("---")) {
      if (pendingMinus !== null) rows.push(row(c(pendingMinus, RED_BG, color), "", leftWidth, rightWidth));
      pendingMinus = raw.slice(1);
      continue;
    }
    if (raw.startsWith("+") && !raw.startsWith("+++")) {
      rows.push(row(pendingMinus === null ? "" : c(pendingMinus, RED_BG, color), c(raw.slice(1), GREEN_BG, color), leftWidth, rightWidth));
      pendingMinus = null;
      continue;
    }
    if (pendingMinus !== null) {
      rows.push(row(c(pendingMinus, RED_BG, color), "", leftWidth, rightWidth));
      pendingMinus = null;
    }
    if (raw.startsWith(" ")) rows.push(row(raw.slice(1), raw.slice(1), leftWidth, rightWidth));
  }
  if (pendingMinus !== null) rows.push(row(c(pendingMinus, RED_BG, color), "", leftWidth, rightWidth));
  return rows.join("\n") + "\n";
}

function row(left: string, right: string, lw: number, rw: number): string {
  return `${visiblePad(trunc(left, lw), lw)} │ ${trunc(right, rw)}`;
}

function trunc(s: string, n: number): string {
  const plain = stripAnsi(s);
  if (plain.length <= n) return s;
  return plain.slice(0, Math.max(0, n - 1)) + "…";
}

function visiblePad(s: string, n: number): string {
  return s + " ".repeat(Math.max(0, n - stripAnsi(s).length));
}

function stripAnsi(s: string): string {
  return s.replace(/\x1b\[[0-9;]*m/g, "");
}

function printLanguages(): void {
  const green = useColor({ color: "auto" } as Options) ? GREEN_FG : "";
  const reset = green ? RESET : "";
  const rows = [
    ["ActionScript", "as"],
    ["Ada", "adb, ads, gpr"],
    ["Bourne Again Shell (bash)", "sh, bash, zsh"],
    ["C", "c, h"],
    ["C++", "cpp, cc, cxx, hpp"],
    ["CSS", "css"],
    ["Diff", "diff, patch"],
    ["Go", "go"],
    ["HTML", "html, htm"],
    ["Java", "java"],
    ["JavaScript", "js, jsx, mjs"],
    ["JSON", "json"],
    ["Markdown", "md, markdown"],
    ["Python", "py, pyw"],
    ["Rust", "rs"],
    ["TypeScript", "ts, tsx"],
    ["YAML", "yml, yaml"]
  ];
  for (const [name, exts] of rows) {
    process.stdout.write(`${name.padEnd(25)} ${exts.split(", ").map(e => `${green}${e}${reset}`).join(", ")}\n`);
  }
}

function printThemes(): void {
  const themes = ["1337", "ansi", "base16", "Dracula", "GitHub", "Monokai Extended", "Nord", "OneHalfDark", "Solarized (dark)", "Solarized (light)", "TwoDark"];
  for (const theme of themes) process.stdout.write(`${theme}\n`);
}

async function main(): Promise<void> {
  const { opts, commands } = parseArgs(process.argv.slice(2));
  if (commands.has("help")) {
    process.stdout.write(HELP_TEXT + "\n");
    return;
  }
  if (commands.has("version")) {
    process.stdout.write(`${VERSION}\n`);
    return;
  }
  if (commands.has("languages")) {
    printLanguages();
    return;
  }
  if (commands.has("themes")) {
    printThemes();
    return;
  }
  if (commands.has("completion")) {
    process.stdout.write("# shell completion generation is not available in this reimplementation\n");
    return;
  }

  let input: string;
  if (opts.minusFile && opts.plusFile) input = unifiedDiff(opts.minusFile, opts.plusFile);
  else input = await readStdin();

  process.stdout.write(opts.colorOnly ? formatColorOnly(input, opts) : formatNormal(input, opts));
}

main().catch(err => {
  process.stderr.write(`${err instanceof Error ? err.message : String(err)}\n`);
  process.exit(1);
});
