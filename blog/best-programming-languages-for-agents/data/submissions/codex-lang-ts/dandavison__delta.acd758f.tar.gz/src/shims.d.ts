declare const process: {
  argv: string[];
  env: Record<string, string | undefined>;
  stdin: {
    setEncoding(encoding: string): void;
    on(event: "data", cb: (chunk: string) => void): void;
    on(event: "end", cb: () => void): void;
    resume(): void;
    isTTY?: boolean;
  };
  stdout: { write(s: string): void; isTTY?: boolean; on(event: "error", cb: (err: { code?: string }) => void): void };
  stderr: { write(s: string): void };
  exit(code?: number): never;
};

declare module "fs" {
  export function readFileSync(path: string, encoding: BufferEncoding): string;
  export function existsSync(path: string): boolean;
}

declare module "child_process" {
  export function spawnSync(command: string, args?: string[], options?: { encoding?: BufferEncoding }): {
    status: number | null;
    stdout: string;
    stderr: string;
    error?: Error;
  };
}

type BufferEncoding = "utf8";
