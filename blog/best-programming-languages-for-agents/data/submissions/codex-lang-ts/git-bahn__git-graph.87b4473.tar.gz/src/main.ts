declare const require: any;
declare const process: any;

const { execFileSync } = require("child_process");
const fs = require("fs");
const path = require("path");

type Opts = {
  path: string;
  model?: string;
  max?: number;
  format: string;
  reverse: boolean;
  local: boolean;
  svg: boolean;
  style: string;
  noColor: boolean;
  command?: string;
  commandArgs: string[];
};

type Commit = {
  hash: string;
  short: string;
  parents: string[];
  parentsShort: string[];
  refs: string[];
  subject: string;
  body: string;
  rawBody: string;
  authorName: string;
  authorEmail: string;
  authorDate: string;
  authorShortDate: string;
  committerName: string;
  committerEmail: string;
  committerDate: string;
  committerShortDate: string;
};

const VERSION = "git-graph 0.7.0";

const LONG_HELP = `Structured Git graphs for your branching model.
    https://github.com/mlange-42/git-graph

EXAMPES:
    git-graph                   -> Show graph
    git-graph --style round     -> Show graph in a different style
    git-graph --model <model>   -> Show graph using a certain <model>
    git-graph model --list      -> List available branching models
    git-graph model             -> Show repo's current branching models
    git-graph model <model>     -> Permanently set model <model> for this repo

Usage: executable [OPTIONS] [COMMAND]

Commands:
  model  Prints or permanently sets the branching model for a repository.
  help   Print this message or the help of the given subcommand(s)

Options:
  -p, --path <path>
          Open repository from this path or above. Default '.'

      --skip-repo-owner-validation
          Skip owner validation for the repository.
          This will turn off libgit2's owner validation, which may increase security risks.
          Please do not disable this validation for repositories you do not trust.

  -m, --model <model>
          Branching model. Available presets are [simple|git-flow|none].
          Default: git-flow. 
          Permanently set the model for a repository with
          > git-graph model <model>

  -n, --max-count <n>
          Maximum number of commits

      --color <color>
          Specify when colors should be used. One of [auto|always|never].
          Default: auto.

      --no-color
          Print without colors. Missing color support should be detected
          automatically (e.g. when piping to a file).
          Overrides option '--color'

  -w, --wrap [<wrap>...]
          Line wrapping for formatted commit text. Default: 'auto 0 8'
          Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
          Examples:
              git-graph --wrap auto
              git-graph --wrap auto 0 8
              git-graph --wrap none
              git-graph --wrap 80
              git-graph --wrap 80 0 8
          'auto' uses the terminal's width if on a terminal.

  -f, --format <format>
          Commit format. One of [oneline|short|medium|full|"<string>"].
            (First character can be used as abbreviation, e.g. '-f m')
          Formatting placeholders for "<string>":
              %n    newline
              %H    commit hash
              %h    abbreviated commit hash
              %P    parent commit hashes
              %p    abbreviated parent commit hashes
              %d    refs (branches, tags)
              %s    commit summary
              %b    commit message body
              %B    raw body (subject and body)
              %an   author name
              %ae   author email
              %ad   author date
              %as   author date in short format 'YYYY-MM-DD'
              %cn   committer name
              %ce   committer email
              %cd   committer date
              %cs   committer date in short format 'YYYY-MM-DD'
              
              If you add a + (plus sign) after % of a placeholder,
                 a line-feed is inserted immediately before the expansion if
                 and only if the placeholder expands to a non-empty string.
              If you add a - (minus sign) after % of a placeholder, all
                 consecutive line-feeds immediately preceding the expansion are
                 deleted if and only if the placeholder expands to an empty string.
              If you add a ' ' (space) after % of a placeholder, a space is
                 inserted immediately before the expansion if and only if
                 the placeholder expands to a non-empty string.
          
              See also the respective git help: https://git-scm.com/docs/pretty-formats
          

  -r, --reverse
          Reverse the order of commits.

  -l, --local
          Show only local branches, no remotes.

      --svg
          Render graph as SVG instead of text-based.

  -d, --debug
          Additional debug output and graphics.

  -S, --sparse
          Print a less compact graph: merge lines point to target lines
          rather than merge commits.

  -s, --style <style>
          Output style. One of [normal/thin|round|bold|double|ascii].
            (First character can be used as abbreviation, e.g. '-s r')

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const SHORT_HELP = `Structured Git graphs for your branching model.
    https://github.com/mlange-42/git-graph

EXAMPES:
    git-graph                   -> Show graph
    git-graph --style round     -> Show graph in a different style
    git-graph --model <model>   -> Show graph using a certain <model>
    git-graph model --list      -> List available branching models
    git-graph model             -> Show repo's current branching models
    git-graph model <model>     -> Permanently set model <model> for this repo

Usage: executable [OPTIONS] [COMMAND]

Commands:
  model  Prints or permanently sets the branching model for a repository.
  help   Print this message or the help of the given subcommand(s)

Options:
  -p, --path <path>                 Open repository from this path or above. Default '.'
      --skip-repo-owner-validation  Skip owner validation for the repository.
                                    This will turn off libgit2's owner validation, which may increase security risks.
                                    Please do not disable this validation for repositories you do not trust.
  -m, --model <model>               Branching model. Available presets are [simple|git-flow|none].
                                    Default: git-flow. 
                                    Permanently set the model for a repository with
                                    > git-graph model <model>
  -n, --max-count <n>               Maximum number of commits
      --color <color>               Specify when colors should be used. One of [auto|always|never].
                                    Default: auto.
      --no-color                    Print without colors. Missing color support should be detected
                                    automatically (e.g. when piping to a file).
                                    Overrides option '--color'
  -w, --wrap [<wrap>...]            Line wrapping for formatted commit text. Default: 'auto 0 8'
                                    Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
                                    For examples, consult 'git-graph --help'
  -f, --format <format>             Commit format. One of [oneline|short|medium|full|"<string>"].
                                      (First character can be used as abbreviation, e.g. '-f m')
                                    Default: oneline.
                                    For placeholders supported in "<string>", consult 'git-graph --help'
  -r, --reverse                     Reverse the order of commits.
  -l, --local                       Show only local branches, no remotes.
      --svg                         Render graph as SVG instead of text-based.
  -d, --debug                       Additional debug output and graphics.
  -S, --sparse                      Print a less compact graph: merge lines point to target lines
                                    rather than merge commits.
  -s, --style <style>               Output style. One of [normal/thin|round|bold|double|ascii].
                                      (First character can be used as abbreviation, e.g. '-s r')
  -h, --help                        Print help (see more with '--help')
  -V, --version                     Print version`;

const MODEL_HELP = `Prints or permanently sets the branching model for a repository.

Usage: executable model [OPTIONS] [model]

Arguments:
  [model]  The branching model to be used. Available presets are [simple|git-flow|none].
           When not given, prints the currently set model.

Options:
  -l, --list  List all available branching models.
  -h, --help  Print help`;

function die(message: string, code = 1): never {
  console.error(message);
  process.exit(code);
  throw new Error(message);
}

function runGit(repo: string, args: string[], opts: { allowFail?: boolean } = {}): string {
  try {
    return execFileSync("git", ["-C", repo, ...args], { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });
  } catch (e: any) {
    if (opts.allowFail) return "";
    throw e;
  }
}

function parseArgs(argv: string[]): Opts {
  const opts: Opts = { path: ".", format: "oneline", reverse: false, local: false, svg: false, style: "normal", noColor: false, commandArgs: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const take = () => argv[++i] ?? die(`error: a value is required for '${a}'`, 2);
    if (a === "model" || a === "help") {
      opts.command = a;
      opts.commandArgs = argv.slice(i + 1);
      break;
    } else if (a === "-h") {
      console.log(SHORT_HELP);
      process.exit(0);
    } else if (a === "--help") {
      console.log(LONG_HELP);
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      console.log(VERSION);
      process.exit(0);
    } else if (a === "-p" || a === "--path") opts.path = take();
    else if (a === "-m" || a === "--model") opts.model = take();
    else if (a === "-n" || a === "--max-count") opts.max = Number(take());
    else if (a === "-f" || a === "--format") opts.format = take();
    else if (a === "-s" || a === "--style") opts.style = normalizeStyle(take());
    else if (a === "--color") i++;
    else if (a === "--no-color") opts.noColor = true;
    else if (a === "-r" || a === "--reverse") opts.reverse = true;
    else if (a === "-l" || a === "--local") opts.local = true;
    else if (a === "--svg") opts.svg = true;
    else if (a === "-w" || a === "--wrap") {
      while (argv[i + 1] && !argv[i + 1].startsWith("-")) i++;
    } else if (a === "-d" || a === "--debug" || a === "-S" || a === "--sparse" || a === "--skip-repo-owner-validation") {
      // Accepted for compatibility.
    } else if (a.startsWith("-")) {
      die(`error: unexpected argument '${a}' found`, 2);
    }
  }
  return opts;
}

function normalizeStyle(s: string): string {
  if (s === "t" || s === "thin" || s === "n" || s === "normal") return "normal";
  if (s === "a" || s === "ascii") return "ascii";
  if (s === "r" || s === "round") return "round";
  if (s === "b" || s === "bold") return "bold";
  if (s === "d" || s === "double") return "double";
  return s;
}

function findRepo(start: string): string {
  try {
    return execFileSync("git", ["-C", start, "rev-parse", "--show-toplevel"], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim();
  } catch {
    die(`ERROR: could not find repository at '${start}'\n       Navigate into a repository before running git-graph, or use option --path`);
  }
}

function modelFile(repo: string): string {
  return path.join(repo, ".git", "git-graph.toml");
}

function validModel(m: string): boolean {
  return ["none", "simple", "git-flow"].includes(m);
}

function handleModel(repo: string, args: string[]): void {
  if (args.includes("-h") || args.includes("--help")) {
    console.log(MODEL_HELP);
    return;
  }
  if (args.includes("-l") || args.includes("--list")) {
    console.log("none\nsimple\ngit-flow");
    return;
  }
  const model = args.find((a) => !a.startsWith("-"));
  const file = modelFile(repo);
  if (!model) {
    if (!fs.existsSync(file)) {
      console.log("No branching model set");
      return;
    }
    const m = fs.readFileSync(file, "utf8").match(/model\s*=\s*"([^"]+)"/);
    console.log(m ? m[1] : "No branching model set");
    return;
  }
  if (!validModel(model)) {
    die(`ERROR: No branching model named '${model}' found in /home/agent/.config/git-graph/models\n       Available models are: none, simple, git-flow`);
  }
  fs.writeFileSync(file, `model = "${model}"\n`);
  console.log(`Branching model set to '${model}'`);
}

function getRefs(repo: string, local: boolean): Map<string, string[]> {
  const map = new Map<string, string[]>();
  const refs = ["refs/heads", "refs/tags"];
  if (!local) refs.push("refs/remotes");
  const out = runGit(repo, ["for-each-ref", ...refs, "--format=%(objectname)%09%(refname:short)"], { allowFail: true });
  for (const line of out.split(/\r?\n/)) {
    if (!line.trim()) continue;
    const [hash, name0] = line.split("\t");
    let name = name0;
    if (!name || name.endsWith("/HEAD")) continue;
    if (name.includes(" -> ")) continue;
    const arr = map.get(hash) ?? [];
    arr.push(name);
    map.set(hash, arr);
  }
  return map;
}

function headBranch(repo: string): string {
  return runGit(repo, ["symbolic-ref", "--quiet", "--short", "HEAD"], { allowFail: true }).trim();
}

function loadCommits(repo: string, opts: Opts): Commit[] {
  const refMap = getRefs(repo, opts.local);
  const head = headBranch(repo);
  const rangeArgs = opts.local ? ["--branches", "--tags"] : ["--all"];
  const logArgs = ["log", "--date-order", ...rangeArgs, "--format=%H"];
  if (opts.max && opts.max > 0) logArgs.splice(1, 0, `--max-count=${opts.max}`);
  let hashes = runGit(repo, logArgs, { allowFail: true }).split(/\r?\n/).filter(Boolean);
  if (hashes.length === 0) hashes = runGit(repo, ["log", "--date-order", "--format=%H"], { allowFail: true }).split(/\r?\n/).filter(Boolean);
  if (opts.reverse) hashes.reverse();
  return hashes.map((hash) => {
    const raw = runGit(repo, ["show", "-s", "--date=default", "--format=%H%x1f%h%x1f%P%x1f%p%x1f%s%x1f%b%x1f%B%x1f%an%x1f%ae%x1f%ad%x1f%as%x1f%cn%x1f%ce%x1f%cd%x1f%cs", hash]);
    const parts = raw.split("\x1f");
    const refs = refMap.get(hash) ?? [];
    refs.sort((a, b) => refRank(a, head) - refRank(b, head) || a.localeCompare(b));
    if (head && refs.includes(head)) refs[refs.indexOf(head)] = `HEAD -> ${head}`;
    return {
      hash: parts[0].trim(),
      short: parts[1],
      parents: parts[2] ? parts[2].trim().split(/\s+/).filter(Boolean) : [],
      parentsShort: parts[3] ? parts[3].trim().split(/\s+/).filter(Boolean) : [],
      refs,
      subject: parts[4] ?? "",
      body: (parts[5] ?? "").replace(/\n+$/, ""),
      rawBody: (parts[6] ?? "").replace(/\n+$/, ""),
      authorName: parts[7] ?? "",
      authorEmail: parts[8] ?? "",
      authorDate: parts[9] ?? "",
      authorShortDate: parts[10] ?? "",
      committerName: parts[11] ?? "",
      committerEmail: parts[12] ?? "",
      committerDate: parts[13] ?? "",
      committerShortDate: (parts[14] ?? "").trim(),
    };
  });
}

function refRank(ref: string, head: string): number {
  if (ref === head) return 0;
  if (ref === "master" || ref === "main" || ref === "trunk") return 1;
  if (ref.startsWith("tag:") || ref.startsWith("tags/")) return 9;
  if (ref.startsWith("origin/")) return 5;
  return 3;
}

function refsText(c: Commit): string {
  return c.refs.length ? ` (${c.refs.join(", ")})` : "";
}

function formatCommit(c: Commit, fmt: string): string {
  const f = fmt === "o" ? "oneline" : fmt === "s" ? "short" : fmt === "m" ? "medium" : fmt === "f" ? "full" : fmt;
  if (f === "oneline") return `${c.short}${refsText(c)} ${c.subject}`;
  const merge = c.parentsShort.length > 1 ? `Merge: ${c.parentsShort.join(" ")}\n` : "";
  if (f === "short") return `commit ${c.hash}${refsText(c)}\n${merge}Author: ${c.authorName} <${c.authorEmail}>\n\n    ${c.subject}\n`;
  if (f === "medium") return `commit ${c.hash}${refsText(c)}\n${merge}Author: ${c.authorName} <${c.authorEmail}>\nDate:   ${c.authorDate}\n\n    ${c.subject}${c.body ? "\n\n" + indentBody(c.body) : ""}\n`;
  if (f === "full") return `commit ${c.hash}${refsText(c)}\n${merge}Author: ${c.authorName} <${c.authorEmail}>\nCommit: ${c.committerName} <${c.committerEmail}>\nDate:   ${c.authorDate}\n\n    ${c.subject}${c.body ? "\n\n" + indentBody(c.body) : ""}\n`;
  return expandFormat(c, fmt);
}

function indentBody(body: string): string {
  return body.split("\n").map((l) => (l ? `    ${l}` : "")).join("\n");
}

function expandFormat(c: Commit, fmt: string): string {
  const values: Record<string, string> = {
    H: c.hash, h: c.short, P: c.parents.join(" "), p: c.parentsShort.join(" "), d: refsText(c), s: c.subject,
    b: c.body, B: c.rawBody, an: c.authorName, ae: c.authorEmail, ad: c.authorDate, as: c.authorShortDate,
    cn: c.committerName, ce: c.committerEmail, cd: c.committerDate, cs: c.committerShortDate,
  };
  let out = "";
  for (let i = 0; i < fmt.length; i++) {
    if (fmt[i] !== "%") { out += fmt[i]; continue; }
    let mod = "";
    if (["+","-"," "].includes(fmt[i + 1])) mod = fmt[++i];
    let key = "";
    if (fmt[i + 1] === "n") { key = "n"; i++; }
    else {
      const two = fmt.slice(i + 1, i + 3);
      if (values[two] !== undefined) { key = two; i += 2; }
      else { key = fmt[++i]; }
    }
    let val = key === "n" ? "\n" : (values[key] ?? `%${mod}${key}`);
    if (mod === "+" && val) val = "\n" + val;
    if (mod === " " && val) val = " " + val;
    if (mod === "-" && !val) out = out.replace(/\n+$/, "");
    out += val;
  }
  return out;
}

type GraphEntry = { prefix: string; commit?: Commit };

function graphEntries(commits: Commit[], style: string, model: string): GraphEntry[] {
  const byHash = new Map(commits.map((c) => [c.hash, c]));
  const active: string[] = [];
  const entries: GraphEntry[] = [];
  for (const c of commits) {
    let idx = active.indexOf(c.hash);
    if (idx < 0) {
      idx = active.length;
      active.push(c.hash);
    }
    const parentsInSet = c.parents.filter((p) => byHash.has(p));
    const mergeNode = c.parents.length > 1;
    const mergeConnect = parentsInSet.length > 1;
    let cells: string[] = [];
    for (let i = 0; i < active.length; i++) cells.push(i === idx ? nodeChar(style, mergeNode) : vertChar(style));
    if (mergeConnect) {
      if (idx === 0) {
        const rest = active.length > 1 ? " " + active.slice(1).map(() => vertChar(style)).join(" ") : "";
        entries.push({ prefix: `${nodeChar(style, true)}${leftArrow(style)}${topRight(style)}${rest}  `, commit: c });
      } else {
        if (idx + 1 >= cells.length) cells.push(topRight(style));
        else cells[idx + 1] = topRight(style);
        cells[idx] = nodeChar(style, true) + leftArrow(style);
        entries.push({ prefix: cells.join(" ") + "  ", commit: c });
      }
    } else {
      entries.push({ prefix: cells.join(" ") + "  ", commit: c });
    }
    if (parentsInSet.length === 0) {
      active.splice(idx, 1);
    } else {
      const firstParent = parentsInSet[0];
      const existingParent = active.indexOf(firstParent);
      if (!mergeConnect && idx > 0 && existingParent >= 0 && existingParent !== idx) {
        entries.push({ prefix: joinLine(active.length, existingParent, idx, style, model) + "  " });
        active.splice(idx, 1);
        continue;
      }
      active[idx] = firstParent;
      for (let j = 1; j < parentsInSet.length; j++) {
        if (!active.includes(parentsInSet[j])) active.splice(idx + j, 0, parentsInSet[j]);
      }
    }
  }
  return entries;
}

function joinLine(length: number, target: number, source: number, style: string, model: string): string {
  if (model === "none") {
    return Array.from({ length }, (_, i) => i === target ? bottomLeft(style) : i === source ? vertChar(style) : dashChar(style)).join(dashChar(style));
  }
  return Array.from({ length }, (_, i) => i === target ? teeRight(style) : i === source ? bottomRight(style) : dashChar(style)).join(dashChar(style));
}

function nodeChar(style: string, merge: boolean): string {
  if (style === "ascii") return merge ? "o" : "*";
  return merge ? "○" : "●";
}
function vertChar(style: string): string { return style === "ascii" ? "|" : style === "double" ? "║" : style === "bold" ? "┃" : "│"; }
function dashChar(style: string): string { return style === "ascii" ? "-" : style === "double" ? "═" : style === "bold" ? "━" : "─"; }
function topRight(style: string): string { return style === "ascii" ? "." : style === "round" ? "╮" : style === "double" ? "╗" : style === "bold" ? "┓" : "┐"; }
function bottomRight(style: string): string { return style === "ascii" ? "'" : style === "round" ? "╯" : style === "double" ? "╝" : style === "bold" ? "┛" : "┘"; }
function bottomLeft(style: string): string { return style === "ascii" ? "'" : style === "round" ? "╰" : style === "double" ? "╚" : style === "bold" ? "┗" : "└"; }
function teeRight(style: string): string { return style === "ascii" ? "|" : style === "double" ? "╠" : style === "bold" ? "┣" : "├"; }
function leftArrow(style: string): string { return style === "ascii" ? "<" : "<"; }

function renderText(commits: Commit[], opts: Opts, model: string): string {
  const entries = graphEntries(commits, opts.style, model);
  const lines: string[] = [];
  for (const entry of entries) {
    const pref = entry.prefix;
    const c = entry.commit;
    if (!c) {
      lines.push(" " + pref);
      continue;
    }
    const text = formatCommit(c, opts.format);
    const parts = text.split("\n");
    lines.push(" " + pref + parts[0]);
    const cont = continuationPrefix(pref, opts.style);
    for (let i = 1; i < parts.length; i++) {
      if (i === parts.length - 1 && parts[i] === "") continue;
      lines.push(" " + cont + parts[i]);
    }
  }
  return lines.join("\n") + (lines.length ? "\n" : "");
}

function continuationPrefix(pref: string, style: string): string {
  return pref.replace(/[●○*o<┐╮┓╗.]/g, vertChar(style)).replace(/[─━═-]/g, " ");
}

function renderSvg(commits: Commit[]): string {
  const h = Math.max(30, commits.length * 30);
  const circles = commits.map((c, i) => {
    const y = 15 + i * 15;
    const fill = c.parents.length > 1 ? "white" : "blue";
    return `<circle cx="15" cy="${y}" fill="${fill}" r="4" stroke="blue" stroke-width="1"/>`;
  }).join("\n");
  return `<svg height="${h}" viewBox="0 0 30 ${h}" width="30" xmlns="http://www.w3.org/2000/svg">\n<line stroke="blue" stroke-width="1" x1="15" x2="15" y1="15" y2="${Math.max(15, commits.length * 15)}"/>\n${circles}\n</svg>\n`;
}

function main(): void {
  const opts = parseArgs(process.argv.slice(2));
  const repo = findRepo(opts.path);
  if (opts.command === "help") {
    if (opts.commandArgs[0] === "model") console.log(MODEL_HELP);
    else console.log(LONG_HELP);
    return;
  }
  if (opts.command === "model") {
    handleModel(repo, opts.commandArgs);
    return;
  }
  const model = opts.model ?? readModel(repo) ?? "git-flow";
  if (!validModel(model)) {
    die(`ERROR: No branching model named '${model}' found in /home/agent/.config/git-graph/models\n       Available models are: none, simple, git-flow`);
  }
  const commits = loadCommits(repo, opts);
  process.stdout.write(opts.svg ? renderSvg(commits) : renderText(commits, opts, model));
}

function readModel(repo: string): string | undefined {
  const file = modelFile(repo);
  if (!fs.existsSync(file)) return undefined;
  const m = fs.readFileSync(file, "utf8").match(/model\s*=\s*"([^"]+)"/);
  return m?.[1];
}

main();
