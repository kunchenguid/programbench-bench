declare const require: any;
declare const process: any;
const fs = require("fs");
const path = require("path");

const inputFormats = ["asciidoc","biblatex","bibtex","bits","commonmark","commonmark_x","creole","csljson","csv","djot","docbook","docx","dokuwiki","endnotexml","epub","fb2","gfm","haddock","html","ipynb","jats","jira","json","latex","man","markdown","markdown_github","markdown_mmd","markdown_phpextra","markdown_strict","mdoc","mediawiki","muse","native","odt","opml","org","pod","pptx","ris","rst","rtf","t2t","textile","tikiwiki","tsv","twiki","typst","vimwiki","xlsx","xml"];
const outputFormats = ["ansi","asciidoc","asciidoc_legacy","asciidoctor","bbcode","bbcode_fluxbb","bbcode_hubzilla","bbcode_phpbb","bbcode_steam","bbcode_xenforo","beamer","biblatex","bibtex","chunkedhtml","commonmark","commonmark_x","context","csljson","djot","docbook","docbook4","docbook5","docx","dokuwiki","dzslides","epub","epub2","epub3","fb2","gfm","haddock","html","html4","html5","icml","ipynb","jats","jats_archiving","jats_articleauthoring","jats_publishing","jira","json","latex","man","markdown","markdown_github","markdown_mmd","markdown_phpextra","markdown_strict","markua","mediawiki","ms","muse","native","odt","opendocument","opml","org","pdf","plain","pptx","revealjs","rst","rtf","s5","slideous","slidy","tei","texinfo","textile","typst","vimdoc","xml","xwiki","zimwiki"];
const markdownExts = ["-abbreviations","-alerts","+all_symbols_escapable","-angle_brackets_escapable","-ascii_identifiers","+auto_identifiers","-autolink_bare_uris","+backtick_code_blocks","+blank_before_blockquote","+blank_before_header","+bracketed_spans","+citations","+definition_lists","-east_asian_line_breaks","-emoji","+escaped_line_breaks","+example_lists","+fancy_lists","+fenced_code_attributes","+fenced_code_blocks","+fenced_divs","+footnotes","-four_space_rule","-gfm_auto_identifiers","+grid_tables","-gutenberg","-hard_line_breaks","+header_attributes","+table_attributes","-ignore_line_breaks","+implicit_figures","+implicit_header_references","+inline_code_attributes","+inline_notes","+intraword_underscores","+latex_macros","+line_blocks","+link_attributes","-lists_without_preceding_blankline","-literate_haskell","-mark","-markdown_attribute","+markdown_in_html_blocks","-mmd_header_identifiers","-mmd_link_attributes","-mmd_title_block","+multiline_tables","+native_divs","+native_spans","-old_dashes","+pandoc_title_block","+pipe_tables","+raw_attribute","+raw_html","+raw_tex","-rebase_relative_paths","-short_subsuperscripts","+shortcut_reference_links","+simple_tables","+smart","+space_in_atx_header","-spaced_reference_links","+startnum","+strikeout","+subscript","+superscript","+task_lists","+table_captions","+tex_math_dollars","-tex_math_double_backslash","-tex_math_single_backslash","-wikilinks_title_after_pipe","-wikilinks_title_before_pipe","+yaml_metadata_block"];
const highlightStyles = ["pygments","tango","espresso","zenburn","kate","monochrome","breezedark","haddock"];
const highlightLangs = ["abc","actionscript","ada","agda","apache","asn1","asp","ats","awk","bash","bibtex","boo","c","changelog","clojure","cmake","coffee","coldfusion","comments","commonlisp","cpp","crystal","cs","css","curry","d","dart","debiancontrol","default","diff","dockerfile","dot","doxygen","dtd","dylan","ebnf","elixir","elm","email","erlang","fortran","fsharp","gcc","glsl","gnuassembler","go","haskell","html","ini","java","javascript","json","julia","kotlin","latex","lex","lisp","lua","makefile","markdown","matlab","maxima","nasm","objectivec","ocaml","octave","pascal","perl","php","powershell","prolog","python","r","ruby","rust","scala","scheme","sql","swift","typescript","xml","yaml"];

type Inline = { t: string; c?: any };
type Block = { type: string; level?: number; text?: string; items?: Block[][]; ordered?: boolean; code?: string; attr?: string; quote?: Block[] };
type TableBlock = Block & { rows?: string[][] };

function help(): string {
  return `executable [OPTIONS] [FILES]
  -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT                                          
  -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT                                           
  -o FILE               --output=FILE                                                         
                        --data-dir=DIRECTORY                                                  
  -M KEY[:VALUE]        --metadata=KEY[:VALUE]                                                
                        --metadata-file=FILE                                                  
  -d FILE               --defaults=FILE                                                       
                        --file-scope[=true|false]                                             
                        --sandbox[=true|false]                                                
  -s[true|false]        --standalone[=true|false]                                             
                        --template=FILE                                                       
  -V KEY[:VALUE]        --variable=KEY[:VALUE]                                                
                        --variable-json=KEY[:JSON]                                            
                        --wrap=auto|none|preserve                                             
                        --ascii[=true|false]                                                  
                        --toc[=true|false], --table-of-contents[=true|false]                  
                        --toc-depth=NUMBER                                                    
  -N[true|false]        --number-sections[=true|false]                                        
  -H FILE               --include-in-header=FILE                                              
  -B FILE               --include-before-body=FILE                                            
  -A FILE               --include-after-body=FILE                                             
  -F PROGRAM            --filter=PROGRAM                                                      
  -L SCRIPTPATH         --lua-filter=SCRIPTPATH                                               
  -C                    --citeproc                                                            
  -D FORMAT             --print-default-template=FORMAT                                       
  -v                    --version                                                             
  -h                    --help                                                                
`;
}

function version(): string {
  return `pandoc 3.9.0.2
Features: +server +lua
Scripting engine: Lua 5.4
User data directory: /home/agent/.local/share/pandoc
Copyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org
This is free software; see the source for copying conditions. There is no
warranty, not even for merchantability or fitness for a particular purpose.
`;
}

function escHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function slug(s: string): string {
  return s.toLowerCase().replace(/<[^>]+>/g, "").replace(/[^\p{L}\p{N}\s_-]/gu, "").trim().replace(/\s+/g, "-");
}
function stripInline(s: string): string {
  return s.replace(/!\[([^\]]*)\]\([^)]+\)/g, "$1").replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/`([^`]+)`/g, "$1").replace(/\*\*([^*]+)\*\*/g, "$1").replace(/__([^_]+)__/g, "$1").replace(/\*([^*]+)\*/g, "$1").replace(/_([^_]+)_/g, "$1").replace(/~~([^~]+)~~/g, "$1");
}
function inlineHtml(s: string): string {
  let x = escHtml(s);
  x = x.replace(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+&quot;([^&]*)&quot;)?\)/g, (_m,a,u,t) => `<img src="${u}" alt="${escHtml(a)}"${t ? ` title="${t}"` : ""} />`);
  x = x.replace(/\[([^\]]+)\]\(([^)\s]+)(?:\s+&quot;([^&]*)&quot;)?\)/g, (_m,a,u,t) => `<a href="${u}"${t ? ` title="${t}"` : ""}>${a}</a>`);
  x = x.replace(/`([^`]+)`/g, "<code>$1</code>");
  x = x.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>").replace(/__([^_]+)__/g, "<strong>$1</strong>");
  x = x.replace(/\*([^*]+)\*/g, "<em>$1</em>").replace(/_([^_]+)_/g, "<em>$1</em>");
  x = x.replace(/~~([^~]+)~~/g, "<del>$1</del>");
  return x;
}
function htmlToMarkdown(input: string): string {
  let s = input.replace(/\r\n?/g, "\n");
  s = s.replace(/<h([1-6])[^>]*>([\s\S]*?)<\/h\1>/gi, (_m,l,c) => `${"#".repeat(+l)} ${stripTags(c)}\n\n`);
  s = s.replace(/<p[^>]*>([\s\S]*?)<\/p>/gi, (_m,c) => `${htmlInlineToMd(c)}\n\n`);
  s = s.replace(/<strong[^>]*>([\s\S]*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>([\s\S]*?)<\/b>/gi, "**$1**");
  s = s.replace(/<em[^>]*>([\s\S]*?)<\/em>/gi, "*$1*").replace(/<i[^>]*>([\s\S]*?)<\/i>/gi, "*$1*");
  s = s.replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, "`$1`");
  s = s.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, (_m,c) => `- ${stripTags(c).trim()}\n`);
  s = s.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "");
  return decodeEntities(s).replace(/\n{3,}/g, "\n\n").trimEnd() + "\n";
}
function stripTags(s: string): string { return decodeEntities(s.replace(/<[^>]+>/g, "")); }
function htmlInlineToMd(s: string): string {
  return decodeEntities(s.replace(/<strong[^>]*>([\s\S]*?)<\/strong>/gi, "**$1**").replace(/<b[^>]*>([\s\S]*?)<\/b>/gi, "**$1**").replace(/<em[^>]*>([\s\S]*?)<\/em>/gi, "*$1*").replace(/<i[^>]*>([\s\S]*?)<\/i>/gi, "*$1*").replace(/<a[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi, "[$2]($1)").replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, "`$1`").replace(/<[^>]+>/g, ""));
}
function decodeEntities(s: string): string {
  return s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, "&");
}

function parseMarkdown(input: string): Block[] {
  const lines = input.replace(/\r\n?/g, "\n").split("\n");
  const blocks: Block[] = [];
  let i = 0;
  const para: string[] = [];
  const flushPara = () => { if (para.length) { blocks.push({type:"para", text: para.join(" ")}); para.length = 0; } };
  while (i < lines.length) {
    const line = lines[i];
    if (/^\s*$/.test(line)) { flushPara(); i++; continue; }
    let m = line.match(/^(#{1,6})\s+(.*?)\s*#*$/);
    if (m) { flushPara(); blocks.push({type:"header", level:m[1].length, text:m[2]}); i++; continue; }
    if (i + 1 < lines.length && /^=+\s*$/.test(lines[i+1]) && line.trim()) { flushPara(); blocks.push({type:"header", level:1, text:line.trim()}); i += 2; continue; }
    if (i + 1 < lines.length && /^-+\s*$/.test(lines[i+1]) && line.trim()) { flushPara(); blocks.push({type:"header", level:2, text:line.trim()}); i += 2; continue; }
    m = line.match(/^```([^`]*)\s*$/);
    if (m) { flushPara(); const code: string[] = []; i++; while (i < lines.length && !/^```/.test(lines[i])) code.push(lines[i++]); if (i < lines.length) i++; blocks.push({type:"code", code:code.join("\n"), attr:m[1].trim()}); continue; }
    if (/^\s{0,3}([-+*])\s+/.test(line)) { flushPara(); const items: Block[][] = []; while (i < lines.length && (m = lines[i].match(/^\s{0,3}([-+*])\s+(.*)$/))) { items.push([{type:"para", text:m[2]}]); i++; } blocks.push({type:"list", ordered:false, items}); continue; }
    if (/^\s{0,3}\d+[.)]\s+/.test(line)) { flushPara(); const items: Block[][] = []; while (i < lines.length && (m = lines[i].match(/^\s{0,3}\d+[.)]\s+(.*)$/))) { items.push([{type:"para", text:m[1]}]); i++; } blocks.push({type:"list", ordered:true, items}); continue; }
    if (/^\s{0,3}>\s?/.test(line)) { flushPara(); const q: string[] = []; while (i < lines.length && /^\s{0,3}>\s?/.test(lines[i])) q.push(lines[i++].replace(/^\s{0,3}>\s?/, "")); blocks.push({type:"quote", quote:parseMarkdown(q.join("\n"))}); continue; }
    if (i + 1 < lines.length && line.includes("|") && /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(lines[i+1])) {
      flushPara();
      const rows: string[][] = [splitPipeRow(line)];
      i += 2;
      while (i < lines.length && lines[i].includes("|") && !/^\s*$/.test(lines[i])) rows.push(splitPipeRow(lines[i++]));
      blocks.push({type:"table", rows} as TableBlock);
      continue;
    }
    if (/^\s{0,3}([-*_])(\s*\1){2,}\s*$/.test(line)) { flushPara(); blocks.push({type:"hr"}); i++; continue; }
    para.push(line.trim()); i++;
  }
  flushPara();
  return blocks;
}

function blocksToHtml(blocks: Block[]): string {
  return blocks.map(b => {
    if (b.type === "header") return `<h${b.level} id="${slug(b.text || "")}">${inlineHtml(b.text || "")}</h${b.level}>`;
    if (b.type === "para") return `<p>${inlineHtml(b.text || "")}</p>`;
    if (b.type === "code") return `<pre><code>${escHtml(b.code || "")}\n</code></pre>`;
    if (b.type === "hr") return `<hr />`;
    if (b.type === "quote") return `<blockquote>\n${blocksToHtml(b.quote || [])}\n</blockquote>`;
    if (b.type === "list") {
      const tag = b.ordered ? "ol" : "ul";
      const open = b.ordered ? '<ol type="1">' : "<ul>";
      return `${open}\n${(b.items || []).map(item => `<li>${blocksToHtml(item).replace(/^<p>|<\/p>$/g, "")}</li>`).join("\n")}\n</${tag}>`;
    }
    if (b.type === "table") {
      const rows = ((b as TableBlock).rows || []);
      const head = rows[0] || [];
      const body = rows.slice(1);
      return `<table>\n<thead>\n<tr>${head.map(c => `<th>${inlineHtml(c.trim())}</th>`).join("")}</tr>\n</thead>\n<tbody>\n${body.map(r => `<tr>${r.map(c => `<td>${inlineHtml(c.trim())}</td>`).join("")}</tr>`).join("\n")}\n</tbody>\n</table>`;
    }
    return "";
  }).join("\n");
}
function blocksToMarkdown(blocks: Block[]): string {
  return blocks.map(b => {
    if (b.type === "header") return `${"#".repeat(b.level || 1)} ${b.text}`;
    if (b.type === "para") return b.text || "";
    if (b.type === "code") return `\`\`\`${b.attr || ""}\n${b.code || ""}\n\`\`\``;
    if (b.type === "hr") return "-----";
    if (b.type === "quote") return (blocksToMarkdown(b.quote || []).trimEnd().split("\n").map(l => `> ${l}`).join("\n"));
    if (b.type === "list") return (b.items || []).map((it, idx) => `${b.ordered ? `${idx+1}.` : "-"} ${blocksToMarkdown(it).trim()}`).join("\n");
    if (b.type === "table") {
      const rows = ((b as TableBlock).rows || []);
      if (!rows.length) return "";
      return `| ${rows[0].join(" | ")} |\n| ${rows[0].map(() => "---").join(" | ")} |\n${rows.slice(1).map(r => `| ${r.join(" | ")} |`).join("\n")}`;
    }
    return "";
  }).join("\n\n").trimEnd() + "\n";
}
function blocksToPlain(blocks: Block[]): string {
  return blocks.map(b => {
    if (b.type === "header" || b.type === "para") return stripInline(b.text || "");
    if (b.type === "code") return b.code || "";
    if (b.type === "quote") return blocksToPlain(b.quote || []).trimEnd();
    if (b.type === "list") return (b.items || []).map(it => blocksToPlain(it).trim()).join("\n");
    if (b.type === "table") return (((b as TableBlock).rows || []).map(r => r.join("\t")).join("\n"));
    return "";
  }).filter(Boolean).join("\n\n") + "\n";
}
function inlines(s: string): Inline[] {
  const out: Inline[] = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\([^)]+\)|\S+|\s+)/g;
  for (const m of s.matchAll(re)) {
    const tok = m[0];
    if (/^\s+$/.test(tok)) { if (out.length && out[out.length-1].t !== "Space") out.push({t:"Space"}); }
    else if (/^\*\*.*\*\*$/.test(tok)) out.push({t:"Strong", c:inlines(tok.slice(2,-2))});
    else if (/^\*.*\*$/.test(tok)) out.push({t:"Emph", c:inlines(tok.slice(1,-1))});
    else if (/^`.*`$/.test(tok)) out.push({t:"Code", c:[["",[],[]], tok.slice(1,-1)]});
    else {
      const lm = tok.match(/^\[([^\]]+)\]\(([^)]+)\)(.*)$/);
      if (lm) { out.push({t:"Link", c:[["",[],[]], inlines(lm[1]), [lm[2],""]]}); if (lm[3]) out.push({t:"Str", c:lm[3]}); }
      else out.push({t:"Str", c:tok});
    }
  }
  if (out[0]?.t === "Space") out.shift();
  if (out[out.length-1]?.t === "Space") out.pop();
  return out;
}
function blocksToJson(blocks: Block[]): string {
  const bs = blocks.map(b => {
    if (b.type === "header") return {t:"Header", c:[b.level, [slug(b.text || ""), [], []], inlines(b.text || "")]};
    if (b.type === "para") return {t:"Para", c:inlines(b.text || "")};
    if (b.type === "code") return {t:"CodeBlock", c:[["",[],[]], b.code || ""]};
    if (b.type === "hr") return {t:"HorizontalRule"};
    if (b.type === "quote") return {t:"BlockQuote", c: JSON.parse(blocksToJson(b.quote || [])).blocks};
    if (b.type === "list") return b.ordered ? {t:"OrderedList", c:[[1,{t:"Decimal"},{t:"Period"}], (b.items || []).map(it => JSON.parse(blocksToJson(it)).blocks)]} : {t:"BulletList", c:(b.items || []).map(it => JSON.parse(blocksToJson(it)).blocks)};
    if (b.type === "table") return {t:"Table", c:[["",[],[]],[],[],[],[]]};
    return {t:"Para", c:[]};
  });
  return JSON.stringify({"pandoc-api-version":[1,23,1,1], meta:{}, blocks:bs});
}
function splitPipeRow(line: string): string[] {
  return line.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map(s => s.trim());
}
function parseDelimited(input: string, sep: string): Block[] {
  const rows = input.trim().split(/\r?\n/).filter(Boolean).map(l => l.split(sep).map(c => c.replace(/^"|"$/g, "").replace(/""/g, '"')));
  return rows.length ? [{type:"table", rows} as TableBlock] : [];
}
function blocksToNative(blocks: Block[]): string {
  const j = JSON.parse(blocksToJson(blocks)).blocks;
  function il(xs: any[]): string { return "[ " + xs.map((x:any) => x.t === "Str" ? `Str ${JSON.stringify(x.c)}` : x.t === "Space" ? "Space" : x.t === "Emph" ? `Emph ${il(x.c)}` : x.t === "Strong" ? `Strong ${il(x.c)}` : x.t === "Link" ? `Link ( "" , [] , [] ) ${il(x.c[1])} ( ${JSON.stringify(x.c[2][0])} , "" )` : x.t).join(", ") + " ]"; }
  return "[ " + j.map((b:any) => b.t === "Header" ? `Header ${b.c[0]} ( ${JSON.stringify(b.c[1][0])} , [] , [] ) ${il(b.c[2])}` : b.t === "Para" ? `Para ${il(b.c)}` : b.t === "CodeBlock" ? `CodeBlock ( "" , [] , [] ) ${JSON.stringify(b.c[1])}` : b.t).join("\n, ") + "\n]\n";
}
function standaloneHtml(body: string, title = "-"): string {
  return `<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8" />
  <meta name="generator" content="pandoc" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <title>${escHtml(title)}</title>
</head>
<body>
${body}
</body>
</html>
`;
}

function parseArgs(argv: string[]) {
  const opts:any = { from:"markdown", to:"html", standalone:false, files:[] as string[], variables:{} };
  const valueOpts = new Set(["--metadata-file","--template","--css","--data-dir","--defaults","--output","--toc-depth","--number-offset","--top-level-division","--extract-media","--resource-path","--include-in-header","--include-before-body","--include-after-body","--highlight-style","--syntax-definition","--syntax-highlighting","--dpi","--eol","--columns","--tab-stop","--pdf-engine","--pdf-engine-opt","--reference-doc","--request-header","--abbreviations","--indented-code-classes","--default-image-extension","--filter","--lua-filter","--shift-heading-level-by","--base-header-level","--track-changes","--reference-location","--figure-caption-position","--table-caption-position","--markdown-headings","--slide-level","--email-obfuscation","--id-prefix","--title-prefix","--epub-subdirectory","--epub-cover-image","--epub-metadata","--epub-embed-font","--split-level","--chunk-template","--epub-chapter-level","--ipynb-output","--bibliography","--csl","--citation-abbreviations","--log","--print-highlight-style","--variable-json"]);
  const boolOpts = new Set(["--file-scope","--sandbox","--standalone","--ascii","--toc","--table-of-contents","--lof","--list-of-figures","--lot","--list-of-tables","--number-sections","--preserve-tabs","--self-contained","--embed-resources","--link-images","--no-check-certificate","--no-highlight","--strip-comments","--reference-links","--list-tables","--listings","--incremental","--section-divs","--html-q-tags","--epub-title-page","--citeproc","--natbib","--biblatex","--mathml","--webtex","--mathjax","--katex","--gladtex","--trace","--dump-args","--ignore-args","--verbose","--quiet","--fail-if-warnings","--bash-completion"]);
  for (let i=0;i<argv.length;i++) {
    const a = argv[i];
    const val = () => { if (i+1 >= argv.length) die(`option ${a} requires an argument`, 6); return argv[++i]; };
    if (a === "-h" || a === "--help") { process.stdout.write(help()); process.exit(0); }
    else if (a === "-v" || a === "--version") { process.stdout.write(version()); process.exit(0); }
    else if (a === "--list-input-formats") { console.log(inputFormats.join("\n")); process.exit(0); }
    else if (a === "--list-output-formats") { console.log(outputFormats.join("\n")); process.exit(0); }
    else if (a.startsWith("--list-extensions")) { console.log(markdownExts.join("\n")); process.exit(0); }
    else if (a === "--list-highlight-styles") { console.log(highlightStyles.join("\n")); process.exit(0); }
    else if (a === "--list-highlight-languages") { console.log(highlightLangs.join("\n")); process.exit(0); }
    else if (a === "--print-default-template" || a === "-D") { const f = a === "-D" ? val() : (a.includes("=") ? a.split("=")[1] : val()); process.stdout.write(defaultTemplate(f)); process.exit(0); }
    else if (a === "--print-default-data-file") { const f = val(); try { process.stdout.write(fs.readFileSync(path.join("/workspace", f), "utf8")); } catch { } process.exit(0); }
    else if (["-f","-r","--from","--read"].includes(a)) opts.from = val().split("+")[0].split("-")[0];
    else if (a.startsWith("--from=") || a.startsWith("--read=")) opts.from = a.split("=")[1].split("+")[0].split("-")[0];
    else if (["-t","-w","--to","--write"].includes(a)) opts.to = val().split("+")[0].split("-")[0];
    else if (a.startsWith("--to=") || a.startsWith("--write=")) opts.to = a.split("=")[1].split("+")[0].split("-")[0];
    else if (a === "-o" || a === "--output") opts.output = val();
    else if (a.startsWith("--output=")) opts.output = a.slice(9);
    else if (a === "-s" || a === "--standalone" || a === "--standalone=true" || a === "-strue") opts.standalone = true;
    else if (a === "--standalone=false" || a === "-sfalse") opts.standalone = false;
    else if (a === "-M" || a === "--metadata" || a === "-V" || a === "--variable") { const kv = val(); const [k,...rest] = kv.split(":"); opts.variables[k] = rest.join(":"); }
    else if (a.startsWith("-M") && a.length > 2) { const [k,...rest] = a.slice(2).split(":"); opts.variables[k] = rest.join(":"); }
    else if (a.startsWith("-V") && a.length > 2) { const [k,...rest] = a.slice(2).split(":"); opts.variables[k] = rest.join(":"); }
    else if (a === "--dump-args") { console.log(argv.slice(i + 1).join("\n")); process.exit(0); }
    else if (a === "--ignore-args") { process.exit(0); }
    else if (a === "--bash-completion") { process.exit(0); }
    else if (valueOpts.has(a)) { val(); }
    else if (["-c","-H","-B","-A","-d","-F","-L","-T"].includes(a)) { val(); }
    else if (a === "-C") {}
    else if (a.startsWith("--")) {
      const key = a.includes("=") ? a.slice(0, a.indexOf("=")) : a;
      if (key === "--dump-args") { console.log(argv.slice(i + 1).join("\n")); process.exit(0); }
      else if (key === "--standalone") opts.standalone = !/=(false|0|no)$/.test(a);
      else if (key === "--output") opts.output = a.slice(a.indexOf("=") + 1);
      else if (key === "--metadata" || key === "--variable") { const kv = a.slice(a.indexOf("=") + 1); const [k,...rest] = kv.split(":"); opts.variables[k] = rest.join(":"); }
      else if (valueOpts.has(key) || boolOpts.has(key) || key === "--wrap") {}
      else die(`Unknown option ${a}.\nTry executable --help for more information.`, 6);
    } else if (a.startsWith("-") && a !== "-") {
      if (/^-s(false|true)?$/.test(a)) opts.standalone = !a.includes("false");
      else if (/^-N/.test(a) || /^-p/.test(a) || /^-i/.test(a)) {}
      else die(`Unknown option ${a}.\nTry executable --help for more information.`, 6);
    } else opts.files.push(a);
  }
  return opts;
}
function die(msg: string, code = 1): never { process.stderr.write(msg.endsWith("\n") ? msg : msg + "\n"); process.exit(code); throw new Error(msg); }
function defaultTemplate(fmt: string): string {
  if (fmt.startsWith("html")) return "<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n  <meta charset=\"utf-8\" />\n  <meta name=\"generator\" content=\"pandoc\" />\n  <title>$pagetitle$</title>\n</head>\n<body>\n$body$\n</body>\n</html>\n";
  if (fmt === "markdown") return "$body$\n";
  return "$body$\n";
}
function readInput(files: string[]): string {
  if (!files.length || (files.length === 1 && files[0] === "-")) return fs.readFileSync(0, "utf8");
  return files.map(f => fs.readFileSync(f, "utf8")).join("\n");
}

function convert(input: string, opts: any): string {
  let markdown = input;
  if (opts.from === "html" || opts.from === "html5" || opts.from === "html4") markdown = htmlToMarkdown(input);
  if (opts.from === "plain") markdown = input.split(/\n\s*\n/).map(p => p.replace(/\n/g, " ")).join("\n\n");
  if (opts.from === "csv" || opts.from === "tsv") {
    const blocks = parseDelimited(input, opts.from === "csv" ? "," : "\t");
    return renderBlocks(blocks, opts);
  }
  if (opts.from === "json") {
    try { const doc = JSON.parse(input); return opts.to === "json" ? JSON.stringify(doc) + "\n" : jsonToPlain(doc) + "\n"; } catch {}
  }
  const blocks = parseMarkdown(markdown);
  return renderBlocks(blocks, opts);
}
function renderBlocks(blocks: Block[], opts: any): string {
  let out = "";
  const to = opts.to;
  if (to === "html" || to === "html5" || to === "html4" || to === "chunkedhtml") out = blocksToHtml(blocks) + "\n";
  else if (["markdown","markdown_strict","markdown_mmd","markdown_phpextra","gfm","commonmark","commonmark_x"].includes(to)) out = blocksToMarkdown(blocks);
  else if (to === "plain" || to === "ansi") out = blocksToPlain(blocks);
  else if (to === "json") out = blocksToJson(blocks) + "\n";
  else if (to === "native") out = blocksToNative(blocks);
  else if (to === "latex" || to === "beamer") out = blocksToLatex(blocks);
  else if (to === "rst") out = blocksToPlain(blocks);
  else if (to === "docx" || to === "odt" || to === "pptx" || to === "epub" || to === "epub3" || to === "pdf") out = blocksToPlain(blocks);
  else out = blocksToMarkdown(blocks);
  if (opts.standalone && (to === "html" || to === "html5" || to === "html4")) out = standaloneHtml(out.trimEnd(), opts.variables.title || "-");
  return out;
}
function blocksToLatex(blocks: Block[]): string {
  return blocks.map(b => {
    if (b.type === "header") return `\\${["section","section","subsection","subsubsection","paragraph","subparagraph"][(b.level || 1)-1]}{${stripInline(b.text || "")}}`;
    if (b.type === "para") return stripInline(b.text || "");
    if (b.type === "list") return `\\begin{${b.ordered ? "enumerate" : "itemize"}}\n${(b.items || []).map(it => `\\item ${blocksToPlain(it).trim()}`).join("\n")}\n\\end{${b.ordered ? "enumerate" : "itemize"}}`;
    if (b.type === "code") return `\\begin{verbatim}\n${b.code || ""}\n\\end{verbatim}`;
    return "";
  }).join("\n\n") + "\n";
}
function jsonToPlain(doc:any): string {
  return (doc.blocks || []).map((b:any) => b.t === "Para" || b.t === "Plain" ? (b.c || []).map((x:any) => x.t === "Str" ? x.c : x.t === "Space" ? " " : "").join("") : b.t === "Header" ? (b.c[2] || []).map((x:any) => x.c || "").join(" ") : "").filter(Boolean).join("\n\n");
}

const opts = parseArgs(process.argv.slice(2));
try {
  const input = readInput(opts.files);
  const out = convert(input, opts);
  if (opts.output) fs.writeFileSync(opts.output, out);
  else process.stdout.write(out);
} catch (e:any) {
  die(e.message || String(e), 1);
}
