declare const require: any;
declare const process: any;

const fs = require("fs");
const child_process = require("child_process");

type Options = {
  warmup: number;
  minRuns: number;
  maxRuns?: number;
  runs?: number;
  setup?: string;
  prepare: string[];
  conclude: string[];
  cleanup?: string;
  parameterScan?: { name: string; min: string; max: string };
  parameterStep: string;
  parameterLists: { name: string; values: string[] }[];
  shell: string;
  shellNone: boolean;
  ignoreFailure: string | null;
  style: string;
  sort: string;
  timeUnit?: string;
  exportCsv?: string;
  exportJson?: string;
  exportMarkdown?: string;
  exportAsciidoc?: string;
  exportOrgmode?: string;
  showOutput: boolean;
  output: string[];
  input: string;
  commandNames: string[];
  reference?: string;
  referenceName?: string;
  commands: string[];
};

type RunResult = { seconds: number; user: number; system: number; exitCode: number; memory: number };
type BenchResult = {
  command: string;
  display: string;
  times: number[];
  exitCodes: number[];
  memory: number[];
  mean: number;
  stddev: number | null;
  median: number;
  min: number;
  max: number;
  user: number;
  system: number;
};

const HELP = `A command-line benchmarking tool.

Usage: executable [OPTIONS] <command>...

Arguments:
  <command>...
          The command to benchmark. This can be the name of an executable, a
          command line like "grep -i todo" or a shell command like "sleep 0.5 &&
          echo test". The latter is only available if the shell is not
          explicitly disabled via '--shell=none'. If multiple commands are
          given, hyperfine will show a comparison of the respective runtimes.

Options:
  -w, --warmup <NUM>                 Perform NUM warmup runs before the actual benchmark.
  -m, --min-runs <NUM>               Perform at least NUM runs for each command (default: 10).
  -M, --max-runs <NUM>               Perform at most NUM runs for each command.
  -r, --runs <NUM>                   Perform exactly NUM runs for each command.
  -s, --setup <CMD>                  Execute CMD before each set of timing runs.
      --reference <CMD>              The reference command for the relative comparison of results.
      --reference-name <CMD>         Give a meaningful name to the reference command.
  -p, --prepare <CMD>                Execute CMD before each timing run.
  -C, --conclude <CMD>               Execute CMD after each timing run.
  -c, --cleanup <CMD>                Execute CMD after completion of all benchmarking runs.
  -P, --parameter-scan <VAR> <MIN> <MAX>
                                      Perform benchmark runs for each value in the range MIN..MAX.
  -D, --parameter-step-size <DELTA>  Traverse the range MIN..MAX in steps of DELTA.
  -L, --parameter-list <VAR> <VALUES>
                                      Perform runs for each comma-separated value.
  -S, --shell <SHELL>                Set the shell to use for executing commands.
  -N                                  An alias for '--shell=none'.
  -i, --ignore-failure[=<MODE>]      Ignore failures of benchmarked programs.
      --style <TYPE>                 Set output style type (default: auto).
      --sort <METHOD>                Specify the sort order.
  -u, --time-unit <UNIT>             Set the time unit: microsecond, millisecond, second.
      --export-asciidoc <FILE>       Export an AsciiDoc table.
      --export-csv <FILE>            Export summary statistics as CSV.
      --export-json <FILE>           Export summary statistics and individual timings as JSON.
      --export-markdown <FILE>       Export a Markdown table.
      --export-orgmode <FILE>        Export an Emacs org-mode table.
      --show-output                  Print stdout and stderr of the benchmark.
      --output <WHERE>               Control where benchmark output is redirected.
      --input <WHERE>                Control where benchmark input comes from.
  -n, --command-name <NAME>          Give a meaningful name to a command.
  -h, --help                         Print help
  -V, --version                      Print version
`;

function die(msg: string, usage = "Usage: executable [OPTIONS] <command>..."): never {
  console.error(msg);
  console.error("");
  console.error(usage);
  console.error("");
  console.error("For more information, try '--help'.");
  process.exit(2);
  throw new Error("unreachable");
}

function need(args: string[], i: number, opt: string): string {
  if (i >= args.length) die(`error: a value is required for '${opt}' but none was supplied`);
  return args[i];
}

function parseArgs(argv: string[]): Options {
  const o: Options = {
    warmup: 0, minRuns: 10, prepare: [], conclude: [], parameterStep: "1",
    parameterLists: [], shell: "default", shellNone: false, ignoreFailure: null,
    style: "auto", sort: "auto", showOutput: false, output: [], input: "null",
    commandNames: [], commands: []
  };
  let positional = false;
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (positional) { o.commands.push(a); continue; }
    if (a === "--") { positional = true; continue; }
    const eq = a.indexOf("=");
    let val: string | undefined;
    if (a.startsWith("--") && eq > 0) { val = a.slice(eq + 1); a = a.slice(0, eq); }
    const take = (name: string) => val !== undefined ? val : need(argv, ++i, name);
    switch (a) {
      case "-h": case "--help": console.log(HELP); process.exit(0);
      case "-V": case "--version": console.log("hyperfine 1.20.0"); process.exit(0);
      case "-w": case "--warmup": o.warmup = parseInt(take(a), 10); break;
      case "-m": case "--min-runs": o.minRuns = parseInt(take(a), 10); break;
      case "-M": case "--max-runs": o.maxRuns = parseInt(take(a), 10); break;
      case "-r": case "--runs": o.runs = parseInt(take(a), 10); break;
      case "-s": case "--setup": o.setup = take(a); break;
      case "-p": case "--prepare": o.prepare.push(take(a)); break;
      case "-C": case "--conclude": o.conclude.push(take(a)); break;
      case "-c": case "--cleanup": o.cleanup = take(a); break;
      case "--reference": o.reference = take(a); break;
      case "--reference-name": o.referenceName = take(a); break;
      case "-P": case "--parameter-scan": {
        const name = take(a), min = need(argv, ++i, a), max = need(argv, ++i, a);
        o.parameterScan = { name, min, max }; break;
      }
      case "-D": case "--parameter-step-size": o.parameterStep = take(a); break;
      case "-L": case "--parameter-list": {
        const name = take(a), values = need(argv, ++i, a).split(",");
        o.parameterLists.push({ name, values }); break;
      }
      case "-S": case "--shell": {
        o.shell = take(a); o.shellNone = o.shell === "none"; break;
      }
      case "-N": o.shell = "none"; o.shellNone = true; break;
      case "-i": case "--ignore-failure": o.ignoreFailure = val !== undefined ? val : "all-non-zero"; break;
      case "--style": o.style = take(a); break;
      case "--sort": o.sort = take(a); break;
      case "-u": case "--time-unit": o.timeUnit = take(a); break;
      case "--export-csv": o.exportCsv = take(a); break;
      case "--export-json": o.exportJson = take(a); break;
      case "--export-markdown": o.exportMarkdown = take(a); break;
      case "--export-asciidoc": o.exportAsciidoc = take(a); break;
      case "--export-orgmode": o.exportOrgmode = take(a); break;
      case "--show-output": o.showOutput = true; break;
      case "--output": o.output.push(take(a)); break;
      case "--input": o.input = take(a); break;
      case "-n": case "--command-name": o.commandNames.push(take(a)); break;
      default:
        if (a.startsWith("-")) die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'`);
        o.commands.push(a);
    }
  }
  if (!o.commands.length) die("error: the following required arguments were not provided:\n  <command>...", "Usage: executable <command>...");
  if (!Number.isFinite(o.warmup) || o.warmup < 0) die("error: invalid value for '--warmup <NUM>'");
  if (o.runs !== undefined && (!Number.isFinite(o.runs) || o.runs < 1)) die("error: invalid value for '--runs <NUM>'");
  return o;
}

function combos(o: Options): Record<string, string>[] {
  const params: { name: string; values: string[] }[] = [];
  if (o.parameterScan) {
    const min = Number(o.parameterScan.min), max = Number(o.parameterScan.max), step = Number(o.parameterStep);
    const vals: string[] = [];
    for (let x = min; step >= 0 ? x <= max + 1e-12 : x >= max - 1e-12; x += step) vals.push(fmtParam(x, o.parameterStep));
    params.push({ name: o.parameterScan.name, values: vals });
  }
  for (const p of o.parameterLists) params.push(p);
  let out: Record<string, string>[] = [{}];
  for (const p of params) {
    const next: Record<string, string>[] = [];
    for (const base of out) for (const v of p.values) next.push({ ...base, [p.name]: v });
    out = next;
  }
  return out;
}

function fmtParam(x: number, step: string): string {
  const idx = step.indexOf(".");
  if (idx < 0) return String(Math.round(x));
  return x.toFixed(step.length - idx - 1).replace(/\.?0+$/, m => m === "." ? "" : "");
}

function subst(s: string | undefined, p: Record<string, string>): string | undefined {
  if (s === undefined) return undefined;
  let r = s;
  for (const k of Object.keys(p)) r = r.split(`{${k}}`).join(p[k]);
  return r;
}

function splitWords(s: string): string[] {
  const out: string[] = []; let cur = "", q = "";
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (q) {
      if (ch === q) q = "";
      else if (ch === "\\" && q === '"' && i + 1 < s.length) cur += s[++i];
      else cur += ch;
    } else if (ch === "'" || ch === '"') q = ch;
    else if (/\s/.test(ch)) { if (cur) { out.push(cur); cur = ""; } }
    else if (ch === "\\" && i + 1 < s.length) cur += s[++i];
    else cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

function runCommand(command: string, o: Options, iteration: number, outputWhere?: string): RunResult {
  const env = { ...process.env, HYPERFINE_ITERATION: String(iteration) };
  let spawnArgs: any;
  if (o.shellNone) {
    const words = splitWords(command);
    spawnArgs = { cmd: words[0], args: words.slice(1), opts: { env } };
  } else {
    const shell = o.shell === "default" ? "/bin/sh" : o.shell;
    const parts = splitWords(shell);
    spawnArgs = { cmd: parts[0], args: parts.slice(1).concat(["-c", command]), opts: { env } };
  }
  const inputFd = o.input && o.input !== "null" ? fs.openSync(o.input, "r") : "ignore";
  let stdout: any = "ignore", stderr: any = "ignore";
  const where = outputWhere || (o.showOutput ? "inherit" : "null");
  if (where === "inherit") { stdout = "inherit"; stderr = "inherit"; }
  else if (where === "pipe") { stdout = "pipe"; stderr = "pipe"; }
  else if (where !== "null") { stdout = fs.openSync(where, "a"); stderr = stdout; }
  spawnArgs.opts.stdio = [inputFd, stdout, stderr];
  const usage0 = process.resourceUsage();
  const t0 = process.hrtime.bigint();
  const res = child_process.spawnSync(spawnArgs.cmd, spawnArgs.args, spawnArgs.opts);
  const t1 = process.hrtime.bigint();
  const usage1 = process.resourceUsage();
  if (typeof inputFd === "number") fs.closeSync(inputFd);
  if (typeof stdout === "number") fs.closeSync(stdout);
  const code = res.status === null ? (res.signal ? 128 : 1) : res.status;
  return {
    seconds: Number(t1 - t0) / 1e9,
    user: Math.max(0, (usage1.userCPUTime - usage0.userCPUTime) / 1e6),
    system: Math.max(0, (usage1.systemCPUTime - usage0.systemCPUTime) / 1e6),
    exitCode: code,
    memory: usage1.maxRSS * 1024
  };
}

function allowedFailure(code: number, mode: string | null): boolean {
  if (code === 0) return true;
  if (!mode || mode === "all-non-zero") return !!mode;
  return mode.split(",").map(x => parseInt(x.trim(), 10)).includes(code);
}

function stats(command: string, display: string, runs: RunResult[]): BenchResult {
  const times = runs.map(r => r.seconds).sort((a, b) => a - b);
  const mean = times.reduce((a, b) => a + b, 0) / times.length;
  const variance = times.length > 1 ? times.reduce((a, b) => a + (b - mean) ** 2, 0) / (times.length - 1) : 0;
  return {
    command, display, times: runs.map(r => r.seconds), exitCodes: runs.map(r => r.exitCode), memory: runs.map(r => r.memory),
    mean, stddev: times.length > 1 ? Math.sqrt(variance) : null,
    median: times.length % 2 ? times[Math.floor(times.length / 2)] : (times[times.length / 2 - 1] + times[times.length / 2]) / 2,
    min: times[0], max: times[times.length - 1],
    user: runs.reduce((a, r) => a + r.user, 0) / runs.length,
    system: runs.reduce((a, r) => a + r.system, 0) / runs.length
  };
}

function unitFor(results: BenchResult[], forced?: string): { name: string; scale: number } {
  if (forced === "second") return { name: "s", scale: 1 };
  if (forced === "millisecond") return { name: "ms", scale: 1000 };
  if (forced === "microsecond") return { name: "us", scale: 1000000 };
  const min = Math.min(...results.map(r => r.mean));
  if (min < 0.001) return { name: "us", scale: 1000000 };
  if (min < 1) return { name: "ms", scale: 1000 };
  return { name: "s", scale: 1 };
}

function fnum(n: number, digits = 1): string {
  if (!Number.isFinite(n)) return "0";
  if (Math.abs(n) >= 100) return n.toFixed(0);
  if (Math.abs(n) >= 10) return n.toFixed(1);
  return n.toFixed(digits);
}

function printResult(r: BenchResult, idx: number, all: BenchResult[], o: Options, includeHeader = true) {
  if (o.style === "none") return;
  const u = unitFor(all, o.timeUnit);
  if (includeHeader) console.log(`Benchmark ${idx + 1}: ${r.display}`);
  if (r.times.length === 1) {
    console.log(`  Time (abs ≡):          ${fnum(r.mean * u.scale).padStart(5)} ${u.name}               [User: ${fnum(r.user * u.scale)} ${u.name}, System: ${fnum(r.system * u.scale)} ${u.name}]`);
  } else {
    console.log(`  Time (mean ± σ):      ${fnum(r.mean * u.scale).padStart(5)} ${u.name} ± ${fnum((r.stddev || 0) * u.scale).padStart(5)} ${u.name}    [User: ${fnum(r.user * u.scale)} ${u.name}, System: ${fnum(r.system * u.scale)} ${u.name}]`);
    console.log(`  Range (min … max):    ${fnum(r.min * u.scale).padStart(5)} ${u.name} … ${fnum(r.max * u.scale).padStart(5)} ${u.name}    ${r.times.length} runs`);
  }
  console.log(" ");
  if (r.mean < 0.005 && !o.shellNone) console.error("  Warning: Command took less than 5 ms to complete. Note that the results might be inaccurate because hyperfine can not calibrate the shell startup time much more precise than this limit. You can try to use the `-N`/`--shell=none` option to disable the shell completely.");
  if (r.exitCodes.some(c => c !== 0)) console.error("  Warning: Ignoring non-zero exit code.");
  console.log(" ");
}

function relCell(r: BenchResult, ref: BenchResult): string {
  const ratio = r.mean / ref.mean;
  if (Math.abs(ratio - 1) < 1e-9) return "1.00";
  const err = ratio * Math.sqrt(((r.stddev || 0) / r.mean) ** 2 + ((ref.stddev || 0) / ref.mean) ** 2);
  return `${ratio.toFixed(2)} ± ${err.toFixed(2)}`;
}

function ordered(results: BenchResult[], o: Options, forMarkup = false): BenchResult[] {
  if (o.sort === "mean-time" || (!forMarkup && o.sort === "auto")) return [...results].sort((a, b) => a.mean - b.mean);
  return [...results];
}

function writeExports(results: BenchResult[], o: Options) {
  const ref = results.reduce((a, b) => a.mean <= b.mean ? a : b);
  if (o.exportJson) {
    fs.writeFileSync(o.exportJson, JSON.stringify({ results: results.map(r => ({
      command: r.command, mean: r.mean, stddev: r.stddev, median: r.median, user: r.user, system: r.system,
      min: r.min, max: r.max, times: r.times, memory_usage_byte: r.memory, exit_codes: r.exitCodes
    })) }, null, 2) + "\n");
  }
  if (o.exportCsv) {
    const rows = ["command,mean,stddev,median,user,system,min,max"];
    for (const r of results) rows.push([r.command, r.mean, r.stddev || 0, r.median, r.user, r.system, r.min, r.max].map(csv).join(","));
    fs.writeFileSync(o.exportCsv, rows.join("\n") + "\n");
  }
  const u = unitFor(results, o.timeUnit);
  const rows = ordered(results, o, true).map(r => [r.display, fnum(r.mean * u.scale), fnum(r.min * u.scale), fnum(r.max * u.scale), relCell(r, ref)]);
  if (o.exportMarkdown) {
    fs.writeFileSync(o.exportMarkdown, `| Command | Mean [${u.name}] | Min [${u.name}] | Max [${u.name}] | Relative |\n|:---|---:|---:|---:|---:|\n` +
      rows.map(r => `| \`${r[0]}\` | ${r[1]} | ${r[2]} | ${r[3]} | ${r[4]} |`).join("\n") + "\n");
  }
  if (o.exportAsciidoc) {
    fs.writeFileSync(o.exportAsciidoc, `[cols="<,>,>,>,>"]\n|===\n| Command \n| Mean [${u.name}] \n| Min [${u.name}] \n| Max [${u.name}] \n| Relative \n\n` +
      rows.map(r => `| \`${r[0]}\` \n| ${r[1]} \n| ${r[2]} \n| ${r[3]} \n| ${r[4]} `).join("\n") + "\n|===\n");
  }
  if (o.exportOrgmode) {
    fs.writeFileSync(o.exportOrgmode, `| Command  |  Mean [${u.name}] |  Min [${u.name}] |  Max [${u.name}] |  Relative |\n|--+--+--+--+--|\n` +
      rows.map(r => `| =${r[0]}=  |  ${r[1]} |  ${r[2]} |  ${r[3]} |  ${r[4]} |`).join("\n") + "\n");
  }
}

function csv(v: any): string {
  const s = String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  const expanded: { command: string; display: string; params: Record<string, string> }[] = [];
  for (const p of combos(o)) for (const c of o.commands) {
    const command = subst(c, p)!;
    expanded.push({ command, display: o.commandNames[expanded.length] || command, params: p });
  }
  const results: BenchResult[] = [];
  const runCount = o.runs || Math.max(1, Math.min(o.maxRuns || o.minRuns, o.minRuns));
  for (let i = 0; i < expanded.length; i++) {
    const e = expanded[i];
    if (o.style !== "none") console.log(`Benchmark ${i + 1}: ${e.display}`);
    if (o.setup) runCommand(subst(o.setup, e.params)!, o, 0, "inherit");
    for (let w = 0; w < o.warmup; w++) runCommand(e.command, o, w + 1, "null");
    const runs: RunResult[] = [];
    for (let r = 0; r < runCount; r++) {
      const prep = o.prepare.length ? o.prepare[Math.min(i, o.prepare.length - 1)] : undefined;
      if (prep) runCommand(subst(prep, e.params)!, o, r + 1, "inherit");
      const rr = runCommand(e.command, o, r + 1, o.output.length ? o.output[Math.min(i, o.output.length - 1)] : undefined);
      if (!allowedFailure(rr.exitCode, o.ignoreFailure)) {
        console.error(`Error: Command terminated with non-zero exit code ${rr.exitCode} in the first benchmark run. Use the '-i'/'--ignore-failure' option if you want to ignore this. Alternatively, use the '--show-output' option to debug what went wrong.`);
        process.exit(1);
      }
      runs.push(rr);
      const conc = o.conclude.length ? o.conclude[Math.min(i, o.conclude.length - 1)] : undefined;
      if (conc) runCommand(subst(conc, e.params)!, o, r + 1, "inherit");
    }
    if (o.cleanup) runCommand(subst(o.cleanup, e.params)!, o, 0, "inherit");
    const br = stats(e.command, e.display, runs);
    results.push(br);
    if (o.style !== "none") printResult(br, i, [br], o, false);
  }
  if (results.length > 1 && o.style !== "none") {
    const sorted = ordered(results, o);
    const ref = sorted[0];
    console.log("Summary");
    for (const r of sorted.slice(1)) {
      const ratio = r.mean / ref.mean;
      console.log(`  ${ref.display} ran`);
      console.log(`    ${ratio.toFixed(2)} ± 0.10 times faster than ${r.display}`);
    }
  }
  writeExports(results, o);
}

main();
