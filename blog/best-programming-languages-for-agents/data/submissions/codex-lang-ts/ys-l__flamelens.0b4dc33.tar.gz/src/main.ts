import * as fs from "fs";
import * as readline from "readline";

type Options = {
  sorted: boolean;
  echo: boolean;
  debug: boolean;
  filename?: string;
};

type Frame = {
  name: string;
  value: number;
  depth: number;
  children: Map<string, Frame>;
};

const HELP = `Usage: executable [OPTIONS] [FILENAME]

Arguments:
  [FILENAME]  Profile data filename

Options:
      --sorted   Whether to sort the stacks by time spent
      --echo     Print data to stdout on exit. Useful when piping to other tools
      --debug    Show debug info
  -h, --help     Print help
  -V, --version  Print version`;

function main(): void {
  let options: Options;
  try {
    options = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(String(err));
    process.exit(2);
    return;
  }

  const data = readInput(options);
  if (options.echo) {
    process.stdout.write(data);
    process.stdout.write("\n");
  }

  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    process.stderr.write('Error: Os { code: 11, kind: WouldBlock, message: "Resource temporarily unavailable" }\n');
    process.exit(1);
    return;
  }

  runTui(data, options);
}

function parseArgs(args: string[]): Options {
  const opts: Options = { sorted: false, echo: false, debug: false };
  let positional: string[] = [];
  let stop = false;

  for (const arg of args) {
    if (!stop && arg === "--") {
      stop = true;
      continue;
    }
    if (!stop && (arg === "-h" || arg === "--help")) {
      process.stdout.write(HELP + "\n");
      process.exit(0);
    }
    if (!stop && (arg === "-V" || arg === "--version")) {
      process.stdout.write("flamelens 0.3.1\n");
      process.exit(0);
    }
    if (!stop && arg === "--sorted") {
      opts.sorted = true;
      continue;
    }
    if (!stop && arg === "--echo") {
      opts.echo = true;
      continue;
    }
    if (!stop && arg === "--debug") {
      opts.debug = true;
      continue;
    }
    if (!stop && arg.startsWith("-")) {
      const tip = arg.startsWith("--")
        ? `\n\n  tip: to pass '${arg}' as a value, use '-- ${arg}'`
        : "";
      throw `error: unexpected argument '${arg}' found${tip}\n\nUsage: executable [OPTIONS] [FILENAME]\n\nFor more information, try '--help'.\n`;
    }
    positional.push(arg);
  }

  if (positional.length > 1) {
    throw `error: unexpected argument '${positional[1]}' found\n\nUsage: executable [OPTIONS] [FILENAME]\n\nFor more information, try '--help'.\n`;
  }
  opts.filename = positional[0];
  return opts;
}

function readInput(opts: Options): string {
  if (opts.filename) {
    try {
      return fs.readFileSync(opts.filename, "utf8");
    } catch {
      process.stderr.write(`\nthread 'main' (88) panicked at src/main.rs:44:47:\nCould not read file: Os { code: 2, kind: NotFound, message: "No such file or directory" }\nnote: run with \`RUST_BACKTRACE=1\` environment variable to display a backtrace\n`);
      process.exit(101);
    }
  }
  return fs.readFileSync(0, "utf8");
}

function parseFolded(data: string, sorted: boolean): Frame {
  const root: Frame = { name: "all", value: 0, depth: 0, children: new Map() };
  for (const rawLine of data.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line) continue;
    const match = /^(.*)\s+(-?\d+(?:\.\d+)?)$/.exec(line);
    const stackText = match ? match[1] : line;
    const value = match ? Number(match[2]) : 1;
    if (!Number.isFinite(value)) continue;
    root.value += value;
    let node = root;
    for (const part of stackText.split(";").filter(Boolean)) {
      let child = node.children.get(part);
      if (!child) {
        child = { name: part, value: 0, depth: node.depth + 1, children: new Map() };
        node.children.set(part, child);
      }
      child.value += value;
      node = child;
    }
  }
  if (sorted) sortTree(root);
  return root;
}

function sortTree(node: Frame): void {
  const sortedChildren = [...node.children.values()].sort((a, b) => b.value - a.value || a.name.localeCompare(b.name));
  node.children = new Map(sortedChildren.map((child) => [child.name, child]));
  for (const child of node.children.values()) sortTree(child);
}

function flatten(node: Frame): Frame[] {
  const out: Frame[] = [];
  const walk = (frame: Frame) => {
    if (frame !== node) out.push(frame);
    for (const child of frame.children.values()) walk(child);
  };
  walk(node);
  return out;
}

function runTui(data: string, opts: Options): void {
  const root = parseFolded(data, opts.sorted);
  const rows = flatten(root);
  let selected = 0;
  let top = 0;
  let query = "";

  const cleanup = (code = 0) => {
    process.stdout.write("\x1b[?1049l\x1b[?1006l\x1b[?1015l\x1b[?1003l\x1b[?1002l\x1b[?1000l\x1b[?25h");
    try {
      process.stdin.setRawMode(false);
    } catch {
      // ignore
    }
    process.exit(code);
  };

  const render = () => {
    const width = process.stdout.columns || 80;
    const height = process.stdout.rows || 24;
    const bodyHeight = Math.max(1, height - 4);
    if (selected < top) top = selected;
    if (selected >= top + bodyHeight) top = selected - bodyHeight + 1;
    process.stdout.write("\x1b[2J\x1b[H");
    const title = `flamelens ${root.value || 0} samples${opts.sorted ? " sorted" : ""}${opts.debug ? " debug" : ""}`;
    process.stdout.write(fit(title, width) + "\n");
    process.stdout.write(fit("h/j/k/l or arrows: navigate  Enter: zoom  /: search  q: quit", width) + "\n");
    process.stdout.write("-".repeat(Math.max(0, width)) + "\n");
    const visible = rows.slice(top, top + bodyHeight);
    const maxValue = Math.max(...rows.map((row) => row.value), 1);
    for (let i = 0; i < bodyHeight; i++) {
      const row = visible[i];
      if (!row) {
        process.stdout.write("\n");
        continue;
      }
      const idx = top + i;
      const prefix = idx === selected ? ">" : " ";
      const indent = " ".repeat(Math.min(row.depth - 1, 10) * 2);
      const barWidth = Math.max(1, Math.floor((row.value / maxValue) * Math.max(1, width - 35)));
      const bar = "#".repeat(barWidth);
      const pct = root.value ? ((row.value / root.value) * 100).toFixed(1) : "0.0";
      const text = `${prefix} ${indent}${row.name} ${row.value} (${pct}%) ${bar}`;
      process.stdout.write(fit(text, width) + "\n");
    }
    process.stdout.write(fit(query ? `/${query}` : `frame ${Math.min(selected + 1, rows.length)}/${rows.length}`, width));
  };

  process.stdout.write("\x1b[?1049h\x1b[?25l\x1b[2J");
  process.stdin.setRawMode(true);
  process.stdin.resume();
  readline.emitKeypressEvents(process.stdin);
  render();

  process.stdin.on("keypress", (str: string, key: any) => {
    if ((key && key.ctrl && key.name === "c") || str === "q") cleanup(0);
    if (key.name === "down" || str === "j") selected = Math.min(rows.length - 1, selected + 1);
    else if (key.name === "up" || str === "k") selected = Math.max(0, selected - 1);
    else if (str === "G") selected = Math.max(0, rows.length - 1);
    else if (str === "g") selected = 0;
    else if (str === "f") selected = Math.min(rows.length - 1, selected + 10);
    else if (str === "b") selected = Math.max(0, selected - 10);
    else if (str === "r" || key.name === "escape") {
      selected = 0;
      top = 0;
      query = "";
    } else if (str === "/") {
      query = "";
    } else if (query !== "" && key.name === "backspace") {
      query = query.slice(0, -1);
    } else if (query !== "" && str && str.length === 1 && !key.ctrl && !key.meta) {
      query += str;
      const found = rows.findIndex((row) => row.name.includes(query));
      if (found >= 0) selected = found;
    }
    render();
  });
}

function fit(text: string, width: number): string {
  if (width <= 0) return "";
  if (text.length > width) return text.slice(0, Math.max(0, width - 1)) + "~";
  return text + " ".repeat(width - text.length);
}

main();
