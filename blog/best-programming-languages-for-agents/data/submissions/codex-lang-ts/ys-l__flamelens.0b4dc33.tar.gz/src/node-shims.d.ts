declare const process: any;
declare module "fs" {
  export function readFileSync(path: string | number, encoding: string): string;
}
declare module "readline" {
  export function emitKeypressEvents(stream: any): void;
}
