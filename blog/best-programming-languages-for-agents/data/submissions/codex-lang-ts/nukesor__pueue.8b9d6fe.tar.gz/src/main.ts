#!/usr/bin/env node
declare const require: any;
declare const process: any;
const fs = require('fs');
const path = require('path');

const RED = '\x1b[91m';
const MAG = '\x1b[35m';
const RESET = '\x1b[0m';
const version = 'pueue 4.0.4';

const rootLong = `Interact with the Pueue daemon

Use the \`--help\` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...
          Verbose mode (-v, -vv, -vvv)

      --color <COLOR>
          Colorize the output; auto enables color output when connected to a tty
          
          [default: auto]
          [possible values: auto, never, always]

  -c, --config <CONFIG>
          If provided, Pueue only uses this config file.
          
          This path can also be set via the "PUEUE_CONFIG_PATH" environment variable. The
          commandline option overwrites the environment variable!

  -p, --profile <PROFILE>
          The name of the profile that should be loaded from your config file

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const rootShort = `Interact with the Pueue daemon

Use the \`--help\` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...         Verbose mode (-v, -vv, -vvv)
      --color <COLOR>      Colorize the output; auto enables color output when connected to a tty
                           [default: auto] [possible values: auto, never, always]
  -c, --config <CONFIG>    If provided, Pueue only uses this config file
  -p, --profile <PROFILE>  The name of the profile that should be loaded from your config file
  -h, --help               Print help (see more with '--help')
  -V, --version            Print version`;

const helps: Record<string,string> = {
add: `Enqueue a task for execution.

There're many different options when scheduling a task. Check the individual option help texts for
more information. Furthermore, please remember that scheduled commands are executed via your system
shell. This means that the command needs proper shell escaping. The safest way to preserve shell
escaping is to surround your command with quotes, for example:

pueue add 'ls $HOME && echo \\"Some string\\"'

Usage: executable add [OPTIONS] <COMMAND>...

Arguments:
  <COMMAND>...
          The command to be added

Options:
  -w, --working-directory <working-directory>
          Specify current working directory

  -e, --escape
          Escape any special shell characters (" ", "&", "!", etc.).
          Beware: This implicitly disables nearly all shell specific syntax ("&&", "&>").

  -i, --immediate
          Immediately start the task

      --follow
          Immediately follow a task, if it's started with --immediate

  -s, --stashed
          Create the task in Stashed state.
          
          Useful to avoid immediate execution if the queue is empty.

  -d, --delay <delay>
          Prevents the task from being enqueued until 'delay' elapses. See "enqueue" for accepted
          formats

  -g, --group <GROUP>
          Assign the task to a group.
          
          Groups kind of act as separate queues. All groups run in parallel and you can specify the
          amount of parallel tasks for each group. If no group is specified, the default group will
          be used.
          
          Create groups via the \`pueue group\` subcommand

  -a, --after <after>...
          Start the task once all specified tasks have successfully finished.
          
          As soon as one of the dependencies fails, this task will fail as well.

  -o, --priority <PRIORITY>
          Start this task with a higher priority.
          
          The higher the number, the faster it will be processed.

  -l, --label <LABEL>
          Add some information for yourself.
          
          This string will be shown in the "status" table. There's no additional logic connected to
          it.

  -p, --print-task-id
          Only return the task id instead of a text.
          
          This is useful when working with dependencies in scripts.

  -h, --help
          Print help (see a summary with '-h')`,
remove: `Remove tasks from the list. Running or paused tasks need to be killed first

Usage: executable remove <TASK_IDS>...

Arguments:
  <TASK_IDS>...  The task ids to be removed

Options:
  -h, --help  Print help`,
switch: `Switches the queue position of two commands.

Only works on queued and stashed commands.

Usage: executable switch <TASK_ID_1> <TASK_ID_2>

Arguments:
  <TASK_ID_1>
          The first task id

  <TASK_ID_2>
          The second task id

Options:
  -h, --help
          Print help (see a summary with '-h')`,
stash: `Stash a task. Stashed tasks won't be automatically started.

The enqueue an item, use the \`pueue enqueue\` subcommand. Stashed entries can also be explicitely
started via \`pueue start $task_id\`.

Usage: executable stash [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Stash these specific tasks

Options:
  -g, --group <GROUP>
          Stash all queued tasks in a group

  -a, --all
          Stash all queued tasks across all groups

  -d, --delay <delay>
          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below

  -h, --help
          Print help (see a summary with '-h')`,
enqueue: `Enqueue stashed tasks. They'll be handled normally afterwards.

Enqueues all stashed task in the default group if no arguments are given.

Usage: executable enqueue [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Enqueue these specific tasks

Options:
  -g, --group <GROUP>
          Enqueue all stashed tasks in a group

  -a, --all
          Enqueue all stashed tasks across all groups

  -d, --delay <delay>
          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below

  -h, --help
          Print help (see a summary with '-h')

DELAY FORMAT:

    The --delay argument must be either a number of seconds or a "date expression" similar to GNU
    "date -d" with some extensions. It does not attempt to parse all natural language, but is
    incredibly flexible. Here are some supported examples.

    2020-04-01T18:30:00   // RFC 3339 timestamp
    2020-4-1 18:2:30      // Optional leading zeros
    2020-4-1 5:30pm       // Informal am/pm time
    2020-4-1 5pm          // Optional minutes and seconds
    April 1 2020 18:30:00 // English months
    1 Apr 8:30pm          // Implies current year
    4/1                   // American form date
    wednesday 10:30pm     // The closest wednesday in the future at 22:30
    wednesday             // The closest wednesday in the future
    4 months              // 4 months from today at 00:00:00
    1 week                // 1 week at the current time
    1days                 // 1 day from today at the current time
    1d 03:00              // The closest 3:00 after 1 day (24 hours)
    3h                    // 3 hours from now
    3600s                 // 3600 seconds from now`,
start: `Resume operation of specific tasks or groups of tasks.

Without any parameters this resumes the default group and all its tasks. Can also be used
force-start specific tasks, which **ignores** any group parallelism limits or dependencies a task my
have!

Usage: executable start [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Start these specific tasks. Paused tasks will resumed. Queued/Stashed tasks will be
          force-started

Options:
  -g, --group <GROUP>
          Resume a specific group and all paused tasks in it.
          
          The group will be set to running and its paused tasks will be resumed.

  -a, --all
          Resume all groups!
          
          All groups will be set to running and paused tasks will be resumed.

  -h, --help
          Print help (see a summary with '-h')`,
restart: `Restart failed or successful task(s).

By default, identical tasks will be created and enqueued, but it's possible to restart in-place. You
can also edit a few properties, such as the path and the command, before restarting.

Usage: executable restart [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Restart these specific tasks

Options:
  -a, --all-failed
          Restart all failed tasks across all groups.
          
          This is nice for usage in combination with \`-i/--in-place\` (or the respective config
          option).

  -g, --failed-in-group <FAILED_IN_GROUP>
          Like \`--all-failed\`, but only restart tasks failed tasks of a specific group

  -k, --immediate
          Immediately start the tasks, no matter how many open slots there are. This will ignore any
          dependencies tasks may have

  -s, --stashed
          Set the restarted task to a "Stashed" state. Useful to avoid immediate execution

  -i, --in-place
          Restart the task by reusing the already existing tasks. This will overwrite any previous
          logs of the restarted tasks.
          
          This can also be enabled by default via the \`restart_in_place\` config option.

      --not-in-place
          Restart the task by creating a new identical tasks. Only necessary if you have the
          \`restart_in_place\` configuration set to true

  -e, --edit
          Edit the task before restarting

  -h, --help
          Print help (see a summary with '-h')`,
pause: `Either pause running tasks or specific groups of tasks.

By default, pauses the default group and all its tasks. A paused queue (group) won't start any new
tasks.

Usage: executable pause [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Pause these specific tasks

Options:
  -g, --group <GROUP>
          Pause a specific group

  -a, --all
          Pause all groups!

  -w, --wait
          Pause the specified groups, but let already running tasks finish by themselves

  -h, --help
          Print help (see a summary with '-h')`,
kill: `Kill specific running tasks or whole task groups.

Kills all tasks of the default group when no ids or a specific group are provided.

Usage: executable kill [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Kill these specific tasks

Options:
  -g, --group <GROUP>
          Kill all running tasks in a group. This also pauses the group

  -a, --all
          Kill all running tasks across ALL groups. This also pauses all groups

  -s, --signal <SIGNAL>
          Send a UNIX signal instead of simply killing the process.
          
          DISCLAIMER: This bypasses Pueue's process handling logic! You might enter weird invalid
          states, use at your own descretion.
          
          This argument also excepts the integer representation as well as the signal short name.
          E.g. \`sigint\`, \`int\`, or \`2\` are the same.

  -h, --help
          Print help (see a summary with '-h')`,
send: `Send something to a task. Useful for sending confirmations such as 'y\\n'

Usage: executable send <TASK_ID> <INPUT>

Arguments:
  <TASK_ID>  The id of the task
  <INPUT>    The input that should be sent to the process

Options:
  -h, --help  Print help`,
edit: `Adjust editable properties of a task.

Only stashed or queued tasks can be edited. A temporary folder folder/file will be opened by your
$EDITOR to edit the tasks.

Usage: executable edit [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          The ids of all tasks that should be edited

Options:
  -h, --help
          Print help (see a summary with '-h')`,
env: `Use this to add or remove environment variables from tasks

Usage: executable env <COMMAND>

Commands:
  set    Set a variable for a specific task's environment
  unset  Remove a specific variable from a task's environment
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help`,
'env set': `Set a variable for a specific task's environment

Usage: executable env set <TASK_ID> <KEY> <VALUE>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set
  <VALUE>    The value of the environment variable to set

Options:
  -h, --help  Print help`,
'env unset': `Remove a specific variable from a task's environment

Usage: executable env unset <TASK_ID> <KEY>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set

Options:
  -h, --help  Print help`,
group: `Use this to add or remove groups.

By default, this will simply display all known groups.

Usage: executable group [OPTIONS] [COMMAND]

Commands:
  add     Add a group by name
  remove  Remove a group by name. This will move all tasks in this group to the default group!
  help    Print this message or the help of the given subcommand(s)

Options:
  -j, --json
          Print the list of groups as json

  -h, --help
          Print help (see a summary with '-h')`,
'group add': `Add a group by name

Usage: executable group add [OPTIONS] <NAME>

Arguments:
  <NAME>
          

Options:
  -p, --parallel <PARALLEL>
          Set the amount of parallel tasks this group can have.
          
          Setting this to 0 means an unlimited amount of parallel tasks.

  -h, --help
          Print help (see a summary with '-h')`,
'group remove': `Remove a group by name. This will move all tasks in this group to the default group!

Usage: executable group remove <NAME>

Arguments:
  <NAME>  

Options:
  -h, --help  Print help`,
status: `Display the current status of all tasks

Usage: executable status [OPTIONS] [QUERY]...

Arguments:
  [QUERY]...
          Users can specify a custom query to filter for specific values, order by a column
          or limit the amount of tasks listed.
          
          Syntax:
             [column_selection]? [filter]* [order_by]? [limit]?
          
          where:
            - column_selection := \`columns=[column]([column],)*\`
            - column := \`id | status | command | label | path | enqueue_at | dependencies | start |
            end\`
            - filter := \`[filter_column] [filter_op] [filter_value]\`
              (note: not all columns support all operators, see "Filter columns" below.)
            - filter_column := \`status | command | label | start | end | enqueue_at\`
            - filter_op := \`= | != | < | > | %=\`
              (\`%=\` means 'contains', as in the test value is a substring of the column value)
            - order_by := \`order_by [column] [order_direction]\`
            - order_direction := \`asc | desc\`
            - limit := \`[limit_type]? [limit_count]\`
            - limit_type := \`first | last\`
            - limit_count := a positive integer
          
          Filter columns:
            - \`status\` supports the operators \`=\`, \`!=\`
              against test values that are:
                - strings like \`queued\`, \`stashed\`, \`paused\`, \`running\`, \`success\`, \`failed\`
            - \`command\`, \`label\` support the operators \`=\`, \`!=\`, \`%=\`
              against test values that are:
                - strings like \`some text\`
            - \`start\`, \`end\`, \`enqueue_at\` contain a datetime
              which support the operators \`=\`, \`!=\`, \`<\`, \`>\`
              against test values that are:
                - date like \`YYYY-MM-DD\`
                - time like \`HH:mm:ss\` or \`HH:mm\`
                - datetime like \`YYYY-MM-DDHH:mm:ss\`
                  (note there is currently no separator between the date and the time)
          
          Examples:
            - \`status=running\`
            - \`command%=echo\`
            - \`label=mytask\`
            - \`columns=id,status,command status=running start > 2023-05-2112:03:17 order_by command
            first 5\`
          
          The formal syntax is defined here:
          https://github.com/Nukesor/pueue/blob/main/pueue/src/client/commands/state/query/syntax.pest
          
          More documentation is on the query syntax PR:
          https://github.com/Nukesor/pueue/issues/350#issue-1359083118

Options:
  -j, --json
          Print the current state as json to stdout. This does not include the output of tasks. Use
          \`log -j\` if you want everything

  -g, --group <GROUP>
          Only show tasks of a specific group

  -h, --help
          Print help (see a summary with '-h')`,
log: `Display the log output of finished tasks.

Only the last few lines will be shown by default. If you want to follow the output of a task, please
use the \\"follow\\" subcommand.

Usage: executable log [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          View the task output of these specific tasks

Options:
  -g, --group <GROUP>
          View the outputs of this specific group's tasks

  -a, --all
          Show the logs of all groups' tasks

  -j, --json
          Print the resulting tasks and output as json.
          
          By default only the last lines will be returned unless --full is provided. Take care, as
          the json cannot be streamed! If your logs are really huge, using --full can use all of
          your machine's RAM.

  -l, --lines <LINES>
          Only print the last X lines of each task's output.
          
          This is done by default if you're looking at multiple tasks.

  -f, --full
          Show the whole output

  -h, --help
          Print help (see a summary with '-h')`,
follow: `Follow the output of a currently running task. This command works like "tail -f"

Usage: executable follow [OPTIONS] [TASK_ID]

Arguments:
  [TASK_ID]
          The id of the task you want to watch.
          
          If no or multiple tasks are running, you have to specify the id. If only a single task is
          running, you can omit the id.

Options:
  -l, --lines <LINES>
          Only print the last X lines of the output before following

  -h, --help
          Print help (see a summary with '-h')`,
wait: `Wait until tasks are finished.

By default, this will wait for all tasks in the default group to finish.

Note: This will also wait for all tasks that aren't somehow 'Done'. Includes: [Paused, Stashed,
Locked, Queued, ...]

Usage: executable wait [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          This allows you to wait for specific tasks to finish

Options:
  -g, --group <GROUP>
          Wait for all tasks in a specific group

  -a, --all
          Wait for all tasks across all groups and the default group

  -q, --quiet
          Don't show any log output while waiting

  -s, --status <STATUS>
          Wait for tasks to reach a specific task status

  -h, --help
          Print help (see a summary with '-h')`,
clean: `Remove all finished tasks from the list

Usage: executable clean [OPTIONS]

Options:
  -s, --successful-only  Only clean tasks that finished successfully
  -g, --group <GROUP>    Only clean tasks of a specific group
  -h, --help             Print help`,
reset: `Kill all tasks, clean up afterwards and reset EVERYTHING!

Usage: executable reset [OPTIONS]

Options:
  -g, --groups <GROUPS>  If groups are specified, only those specific groups will be reset
  -f, --force            Don't ask for any confirmation
  -h, --help             Print help`,
shutdown: `Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager

Usage: executable shutdown

Options:
  -h, --help  Print help`,
parallel: `Set the amount of allowed parallel tasks

By default, adjusts the amount of the default group.

No tasks will be stopped, if this is lowered. This limit is only considered when tasks are
scheduled.

Usage: executable parallel [OPTIONS] [PARALLEL_TASKS]

Arguments:
  [PARALLEL_TASKS]
          The amount of allowed parallel tasks.
          
          Setting this to 0 means an unlimited amount of parallel tasks.

Options:
  -g, --group <group>
          Set the amount for a specific group

  -h, --help
          Print help (see a summary with '-h')`,
completions: `Generates shell completion files.

This can be ignored during normal operations.

Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]

Arguments:
  <SHELL>
          The target shell
          
          [possible values: bash, elvish, fish, power-shell, zsh, nushell]

  [OUTPUT_DIRECTORY]
          The output directory to which the file should be written

Options:
  -h, --help
          Print help (see a summary with '-h')`,
};

const commandNames = ['add','remove','switch','stash','enqueue','start','restart','pause','kill','send','edit','env','group','status','log','follow','wait','clean','reset','shutdown','parallel','completions'];

function out(s: string) { process.stdout.write(s + '\n'); }
function err(s: string) { process.stderr.write(s + '\n'); }
function dieCli(s: string): void { err(s); process.exit(2); }
function missing(args: string[], usage: string): void {
  err(`error: the following required arguments were not provided:\n${args.map(a => '  ' + a).join('\n')}\n\nUsage: ${usage}\n\nFor more information, try '--help'.`);
  process.exit(2);
}
function configError(configPath?: string): void {
  if (configPath) {
    try { fs.accessSync(configPath, fs.constants.R_OK); }
    catch {
      err(`Error: \n   0: ${RED}Failed to read configuration.${RESET}\n   1: ${RED}I/O error at path "${configPath}" while opening config file:\n      No such file or directory (os error 2)${RESET}\n\nLocation:\n   ${MAG}pueue/src/bin/pueue.rs${RESET}:${MAG}51${RESET}\n\nBacktrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.\nRun with RUST_BACKTRACE=full to include source snippets.`);
      process.exit(1);
    }
  }
  err(`Error: \n   0: ${RED}Couldn't find a configuration file. Did you start the daemon yet?${RESET}\n\nLocation:\n   ${MAG}pueue/src/bin/pueue.rs${RESET}:${MAG}61${RESET}\n\nBacktrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.\nRun with RUST_BACKTRACE=full to include source snippets.`);
  process.exit(1);
}
function usageFor(cmd: string): string {
  const map: Record<string,string> = {
    add: 'executable add <COMMAND>...', remove: 'executable remove <TASK_IDS>...', switch: 'executable switch <TASK_ID_1> <TASK_ID_2>',
    send: 'executable send <TASK_ID> <INPUT>', 'env set': 'executable env set <TASK_ID> <KEY> <VALUE>', 'env unset': 'executable env unset <TASK_ID> <KEY>',
    'group add': 'executable group add <NAME>', 'group remove': 'executable group remove <NAME>', completions: 'executable completions <SHELL> [OUTPUT_DIRECTORY]'
  };
  return map[cmd] || `executable ${cmd}`;
}
function helpKey(args: string[]): string | null {
  if (args.length === 0) return null;
  if (args[0] === 'help') return args.slice(1).join(' ') || '';
  if (args.includes('--help') || args.includes('-h')) {
    if ((args[0] === 'env' || args[0] === 'group') && args[1] && args[1] !== '--help' && args[1] !== '-h') return `${args[0]} ${args[1]}`;
    return args[0];
  }
  return null;
}
function stripGlobals(argv: string[]): {rest:string[], config?:string} {
  const rest: string[] = [];
  let config: string | undefined = process.env.PUEUE_CONFIG_PATH;
  for (let i=0;i<argv.length;i++) {
    const a = argv[i];
    if (!a.startsWith('-') || a === '-') {
      rest.push(...argv.slice(i));
      break;
    }
    if (a === '--version' || a === '-V') { out(version); process.exit(0); }
    if (a === '--help') { out(rootLong); process.exit(0); }
    if (a === '-h') { out(rootShort); process.exit(0); }
    if (a === '--color') {
      const val = argv[++i];
      if (!val) dieCli(`error: a value is required for '--color <COLOR>' but none was supplied\n  [possible values: auto, never, always]\n\nFor more information, try '--help'.`);
      if (!['auto','never','always'].includes(val)) dieCli(`error: invalid value '${val}' for '--color <COLOR>'\n  [possible values: auto, never, always]\n\nFor more information, try '--help'.`);
      continue;
    }
    if (a.startsWith('--color=')) {
      const val = a.slice(8);
      if (!['auto','never','always'].includes(val)) dieCli(`error: invalid value '${val}' for '--color <COLOR>'\n  [possible values: auto, never, always]\n\nFor more information, try '--help'.`);
      continue;
    }
    if (a === '-c' || a === '--config') { config = argv[++i]; continue; }
    if (a.startsWith('--config=')) { config = a.slice(9); continue; }
    if (a === '-p' || a === '--profile') { i++; continue; }
    if (a.startsWith('--profile=')) continue;
    if (/^-v+$/.test(a) || a === '--verbose') continue;
    rest.push(a);
  }
  return {rest, config};
}
function completion(shell: string, dir?: string) {
  const valid = ['bash','elvish','fish','power-shell','zsh','nushell'];
  if (!valid.includes(shell)) dieCli(`error: invalid value '${shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n\nFor more information, try '--help'.`);
  const content = shell === 'bash' ? `_pueue() {\n    COMPREPLY=( $(compgen -W "${commandNames.join(' ')}" -- "\${COMP_WORDS[COMP_CWORD]}") )\n}\ncomplete -F _pueue pueue\n` : `# ${shell} completion for pueue\n`;
  if (dir) {
    fs.mkdirSync(dir, {recursive:true});
    const name = shell === 'fish' ? 'pueue.fish' : shell === 'zsh' ? '_pueue' : 'pueue';
    fs.writeFileSync(path.join(dir, name), content);
  } else process.stdout.write(content);
}
function isOption(a: string) { return a.startsWith('-'); }
function validate(cmd: string, args: string[]) {
  const vals = args.filter(a => !isOption(a));
  if (cmd === 'add' && vals.length < 1) missing(['<COMMAND>...'], usageFor('add'));
  if (cmd === 'remove' && vals.length < 1) missing(['<TASK_IDS>...'], usageFor('remove'));
  if (cmd === 'switch') { if (vals.length < 1) missing(['<TASK_ID_1>','<TASK_ID_2>'], usageFor('switch')); if (vals.length < 2) missing(['<TASK_ID_2>'], usageFor('switch')); }
  if (cmd === 'send') { if (vals.length < 1) missing(['<TASK_ID>','<INPUT>'], usageFor('send')); if (vals.length < 2) missing(['<INPUT>'], usageFor('send')); }
  if (cmd === 'parallel' && vals[0] && !/^\d+$/.test(vals[0])) dieCli(`error: invalid value '${vals[0]}' for '[PARALLEL_TASKS]': invalid digit found in string\n\nFor more information, try '--help'.`);
  if (cmd === 'completions') { if (vals.length < 1) missing(['<SHELL>'], usageFor('completions')); completion(vals[0], vals[1]); process.exit(0); }
}
function main() {
  const {rest, config} = stripGlobals(process.argv.slice(2));
  const hk = helpKey(rest);
  if (hk !== null) { out(hk === '' ? rootLong : (helps[hk] || rootLong)); process.exit(0); }
  if (rest.length === 0) configError(config);
  const cmd = rest[0];
  if (!commandNames.includes(cmd)) dieCli(`error: unrecognized subcommand '${cmd}'\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.`);
  if (cmd === 'env') {
    const sub = rest[1];
    if (!sub) { out(helps.env); process.exit(2); }
    if (!['set','unset','help'].includes(sub)) dieCli(`error: unrecognized subcommand '${sub}'\n\nUsage: executable env <COMMAND>\n\nFor more information, try '--help'.`);
    if (sub === 'help') { out(rest[2] ? helps[`env ${rest[2]}`] || helps.env : helps.env); process.exit(0); }
    const vals = rest.slice(2).filter(a => !isOption(a));
    if (sub === 'set' && vals.length < 3) missing(['<TASK_ID>','<KEY>','<VALUE>'].slice(vals.length), usageFor('env set'));
    if (sub === 'unset' && vals.length < 2) missing(['<TASK_ID>','<KEY>'].slice(vals.length), usageFor('env unset'));
    configError(config);
  }
  if (cmd === 'group') {
    const sub = rest[1];
    if (sub === 'help') { out(rest[2] ? helps[`group ${rest[2]}`] || helps.group : helps.group); process.exit(0); }
    if (sub === 'add') { const vals = rest.slice(2).filter(a=>!isOption(a)); if (vals.length < 1) missing(['<NAME>'], usageFor('group add')); }
    if (sub === 'remove') { const vals = rest.slice(2).filter(a=>!isOption(a)); if (vals.length < 1) missing(['<NAME>'], usageFor('group remove')); }
    if (sub && !sub.startsWith('-') && !['add','remove'].includes(sub)) dieCli(`error: unrecognized subcommand '${sub}'\n\nUsage: executable group [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.`);
    configError(config);
  }
  validate(cmd, rest.slice(1));
  configError(config);
}
main();
