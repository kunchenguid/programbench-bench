declare const require: any;
declare const process: any;
declare const Buffer: any;
const fs = require("fs");
const zlib = require("zlib");

type Opts = {
  output?: string;
  delimiter: string;
  literal: boolean;
  useInputDelim: boolean;
  outDelim: string;
  fields?: string;
  exclude?: string;
  headerFields: string[];
  excludeHeaders: string[];
  headerRegex: boolean;
  decompress: boolean;
  compress: boolean;
  crlf: boolean;
  inputs: string[];
};

const HELP_SHORT = `* \`delimiter\` is a regex by default and a fixed substring with \`-L\` * \`header-fields\` allows for specifying a literal or a regex to match header names to select columns * both \`header-fields\` and \`fields\` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with \`-D\`

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Input files to parse, defaults to stdin

Options:
  -o, --output <OUTPUT>
          Output file to write to, defaults to stdout
  -d, --delimiter <DELIMITER>
          Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the \`-L\` flag [default: \\s+]
  -L, --delim-is-literal
          Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters
  -I, --use-input-delim
          Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set
  -D, --output-delimiter <OUTPUT_DELIMITER>
          Delimiter string to use on outputs [default: "\\t"]
  -f, --fields <FIELDS>
          Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive
  -e, --exclude <EXCLUDE>
          Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over \`fields\`
  -E, --exclude-header <EXCLUDE_HEADER>
          Headers to exclude from the output, ex: '^badfield.*$\`. This is a string literal by default. Add the \`-r\` flag to treat as a regex
  -F, --header-field <HEADER_FIELD>
          A string literal or regex to select headers, ex: '^is_.*$\`. This is a string literal by default. add the \`-r\` flag to treat it as a regex
  -r, --header-is-regex
          Treat the header_fields as regexs instead of string literals
  -z, --try-decompress
          Try to find the correct decompression method based on the file extensions
  -Z, --try-compress
          Try to gzip compress the output
  -t, --compression-threads <COMPRESSION_THREADS>
          Threads to use for compression, 0 will result in \`hck\` staying single threaded [default: 4]
  -l, --compression-level <COMPRESSION_LEVEL>
          Compression level [default: 6]
      --no-mmap
          Disallow the possibility of using mmap
      --crlf
          Support CRLF newlines
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
`;

function version() {
  console.log("hck git:23bebe8-modified");
}

function die(msg: string, code = 1): void {
  console.error(`[2026-05-31T15:37:00Z ERROR hck] ${msg}`);
  process.exit(code);
}

function parseArgs(argv: string[]): Opts {
  const o: Opts = {
    delimiter: "\\s+",
    literal: false,
    useInputDelim: false,
    outDelim: "\t",
    headerFields: [],
    excludeHeaders: [],
    headerRegex: false,
    decompress: false,
    compress: false,
    crlf: false,
    inputs: [],
  };
  let outDelimSet = false;
  const need = (i: number, a: string) => {
    if (i + 1 >= argv.length) {
      console.error(`error: a value is required for '${a}' but none was supplied`);
      process.exit(2);
    }
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") {
      o.inputs.push(...argv.slice(i + 1));
      break;
    } else if (a === "-h" || a === "--help") {
      process.stdout.write(HELP_SHORT);
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      version();
      process.exit(0);
    } else if (a === "-o" || a === "--output") {
      o.output = need(i, a); i++;
    } else if (a.startsWith("--output=")) {
      o.output = a.slice(9);
    } else if (a === "-d" || a === "--delimiter") {
      o.delimiter = need(i, a); i++;
    } else if (a.startsWith("-d") && a.length > 2) {
      o.delimiter = a.slice(2);
    } else if (a.startsWith("--delimiter=")) {
      o.delimiter = a.slice(12);
    } else if (a === "-D" || a === "--output-delimiter") {
      o.outDelim = need(i, a); outDelimSet = true; i++;
    } else if (a.startsWith("-D") && a.length > 2) {
      o.outDelim = a.slice(2); outDelimSet = true;
    } else if (a.startsWith("--output-delimiter=")) {
      o.outDelim = a.slice(19); outDelimSet = true;
    } else if (a === "-f" || a === "--fields") {
      o.fields = need(i, a); i++;
    } else if (a.startsWith("-f") && a.length > 2) {
      o.fields = a.slice(2);
    } else if (a.startsWith("--fields=")) {
      o.fields = a.slice(9);
    } else if (a === "-e" || a === "--exclude") {
      o.exclude = need(i, a); i++;
    } else if (a.startsWith("-e") && a.length > 2) {
      o.exclude = a.slice(2);
    } else if (a.startsWith("--exclude=")) {
      o.exclude = a.slice(10);
    } else if (a === "-F" || a === "--header-field") {
      o.headerFields.push(need(i, a)); i++;
    } else if (a.startsWith("-F") && a.length > 2) {
      o.headerFields.push(a.slice(2));
    } else if (a.startsWith("--header-field=")) {
      o.headerFields.push(a.slice(15));
    } else if (a === "-E" || a === "--exclude-header") {
      o.excludeHeaders.push(need(i, a)); i++;
    } else if (a.startsWith("-E") && a.length > 2) {
      o.excludeHeaders.push(a.slice(2));
    } else if (a.startsWith("--exclude-header=")) {
      o.excludeHeaders.push(a.slice(17));
    } else if (a === "-L" || a === "--delim-is-literal") {
      o.literal = true;
    } else if (a.startsWith("-L") && a.length > 2) {
      o.literal = true;
      const rest = "-" + a.slice(2);
      if (rest === "-I") {
        o.useInputDelim = true;
      } else if (rest === "-r") {
        o.headerRegex = true;
      } else if (rest === "-z") {
        o.decompress = true;
      } else if (rest === "-Z") {
        o.compress = true;
      } else if (rest.startsWith("-d") && rest.length > 2) {
        o.delimiter = rest.slice(2);
      } else if (rest.startsWith("-D") && rest.length > 2) {
        o.outDelim = rest.slice(2); outDelimSet = true;
      } else if (rest.startsWith("-f") && rest.length > 2) {
        o.fields = rest.slice(2);
      } else if (rest.startsWith("-e") && rest.length > 2) {
        o.exclude = rest.slice(2);
      } else if (rest.startsWith("-F") && rest.length > 2) {
        o.headerFields.push(rest.slice(2));
      } else if (rest.startsWith("-E") && rest.length > 2) {
        o.excludeHeaders.push(rest.slice(2));
      } else {
        console.error(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.`);
        process.exit(2);
      }
    } else if (a === "-I" || a === "--use-input-delim") {
      o.useInputDelim = true;
    } else if (a.startsWith("-I") && a.length > 2) {
      o.useInputDelim = true;
      const rest = "-" + a.slice(2);
      if (rest.startsWith("-d") && rest.length > 2) o.delimiter = rest.slice(2);
      else if (rest.startsWith("-D") && rest.length > 2) { o.outDelim = rest.slice(2); outDelimSet = true; }
      else { console.error(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.`); process.exit(2); }
    } else if (a === "-r" || a === "--header-is-regex") {
      o.headerRegex = true;
    } else if (a.startsWith("-r") && a.length > 2) {
      o.headerRegex = true;
      const rest = "-" + a.slice(2);
      if (rest.startsWith("-F") && rest.length > 2) o.headerFields.push(rest.slice(2));
      else if (rest.startsWith("-E") && rest.length > 2) o.excludeHeaders.push(rest.slice(2));
      else { console.error(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.`); process.exit(2); }
    } else if (a === "-z" || a === "--try-decompress") {
      o.decompress = true;
    } else if (a === "-Z" || a === "--try-compress") {
      o.compress = true;
    } else if (a === "--crlf") {
      o.crlf = true;
    } else if (a === "--no-mmap") {
      // Accepted for compatibility; this implementation does not mmap.
    } else if (a === "-t" || a === "--compression-threads" || a === "-l" || a === "--compression-level") {
      need(i, a); i++;
    } else if ((a.startsWith("-t") || a.startsWith("-l")) && a.length > 2) {
      // ignored
    } else if (a.startsWith("-")) {
      console.error(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.`);
      process.exit(2);
    } else {
      o.inputs.push(a);
    }
  }
  if (o.useInputDelim && o.literal && !outDelimSet) o.outDelim = o.delimiter;
  return o;
}

function parseRanges(spec: string, width: number): number[] {
  const out: number[] = [];
  const seen = new Set<number>();
  for (const raw of spec.split(",")) {
    const part = raw.trim();
    if (!part) continue;
    let lo: number, hi: number;
    if (/^\d+$/.test(part)) {
      lo = hi = Number(part);
    } else {
      const m = part.match(/^(\d*)-(\d*)$/);
      if (!m) die(`Failed to parse field: ${part}`);
      lo = m[1] ? Number(m[1]) : 1;
      hi = m[2] ? Number(m[2]) : width;
      if (!m[1] && !m[2]) { lo = 1; hi = width; }
    }
    if (lo < 1) die(`Fields and positions are numbered from 1: ${lo}`);
    if (hi < lo) die(`High end of range less than low end of range: ${part}`);
    for (let n = lo; n <= hi; n++) {
      const idx = n - 1;
      if (idx < width && !seen.has(idx)) {
        seen.add(idx);
        out.push(idx);
      }
    }
  }
  return out;
}

function splitLine(line: string, o: Opts): string[] {
  if (o.literal) {
    if (o.delimiter === "") return [line];
    return line.split(o.delimiter);
  }
  try {
    return line.split(new RegExp(o.delimiter, "g"));
  } catch {
    return line.split(o.delimiter);
  }
}

function matcher(pattern: string, regex: boolean): (s: string) => boolean {
  if (!regex) return (s) => s === pattern;
  const re = new RegExp(pattern);
  return (s) => re.test(s);
}

function uniquePush(arr: number[], seen: Set<number>, idx: number, width: number) {
  if (idx >= 0 && idx < width && !seen.has(idx)) {
    seen.add(idx);
    arr.push(idx);
  }
}

function selectedIndexes(cols: string[], o: Opts, headerIndexes?: number[]): number[] {
  const width = cols.length;
  const seen = new Set<number>();
  const idxs: number[] = [];
  if (o.fields) {
    for (const idx of parseRanges(o.fields, width)) uniquePush(idxs, seen, idx, width);
  }
  if (headerIndexes && headerIndexes.length) {
    for (const idx of headerIndexes) uniquePush(idxs, seen, idx, width);
  }
  if (!headerIndexes?.length && !o.fields) {
    for (let i = 0; i < width; i++) idxs.push(i);
  }
  let exclude = new Set<number>();
  if (o.exclude) {
    exclude = new Set(parseRanges(o.exclude, width));
  }
  return idxs.filter((i) => !exclude.has(i));
}

function headerSelections(headers: string[], o: Opts): { include: number[]; exclude: Set<number> } {
  const include: number[] = [];
  const seen = new Set<number>();
  for (const pat of o.headerFields) {
    const is = matcher(pat, o.headerRegex);
    headers.forEach((h, i) => { if (is(h)) uniquePush(include, seen, i, headers.length); });
  }
  const exclude = new Set<number>();
  for (const pat of o.excludeHeaders) {
    const is = matcher(pat, o.headerRegex);
    headers.forEach((h, i) => { if (is(h)) exclude.add(i); });
  }
  if (o.headerFields.length && include.length === 0) die("No headers matched");
  return { include, exclude };
}

function readInput(path: string | undefined, o: Opts): any {
  if (!path) return fs.readFileSync(0);
  const b = fs.readFileSync(path);
  if (o.decompress && /\.(gz|gzip)$/i.test(path)) return zlib.gunzipSync(b);
  return b;
}

function processText(text: string, o: Opts): string {
  const lineEnd = o.crlf ? "\r\n" : "\n";
  const hadFinalNl = o.crlf ? text.endsWith("\r\n") : text.endsWith("\n");
  if (hadFinalNl) text = text.slice(0, -lineEnd.length);
  if (text.length === 0) return "";
  const lines = o.crlf ? text.split("\r\n") : text.split("\n");
  let headerInclude: number[] | undefined;
  let headerExclude = new Set<number>();
  if (o.headerFields.length || o.excludeHeaders.length) {
    const headerCols = splitLine(lines[0], o);
    const sel = headerSelections(headerCols, o);
    headerInclude = sel.include;
    headerExclude = sel.exclude;
  }
  const out: string[] = [];
  for (const line of lines) {
    const cols = splitLine(line, o);
    let idxs = selectedIndexes(cols, o, headerInclude);
    if (headerExclude.size) idxs = idxs.filter((i) => !headerExclude.has(i));
    out.push(idxs.map((i) => cols[i] ?? "").join(o.outDelim));
  }
  return out.join(lineEnd) + (hadFinalNl ? lineEnd : "");
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  let output = "";
  if (opts.inputs.length === 0) {
    output = processText(readInput(undefined, opts).toString("utf8"), opts);
  } else {
    for (const p of opts.inputs) output += processText(readInput(p, opts).toString("utf8"), opts);
  }
  let buf = Buffer.from(output, "utf8");
  if (opts.compress) buf = zlib.gzipSync(buf);
  if (opts.output) fs.writeFileSync(opts.output, buf);
  else fs.writeSync(1, buf);
}

main();
