declare const require: any;
declare const process: any;
declare const __dirname: string;

const fs = require("fs");
const path = require("path");
const childProcess = require("child_process");

const VERSION =
  "commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1";

function helpText(): string {
  return `executable

  Usage:
    executable [git-arg]

  Positional Variables: 
    git-arg   Panel to focus upon opening lazygit. Accepted values (based on git terminology): status, branch, log, stash. Ignored if --filter arg is passed.
  Flags: 
    -h --help               Displays help with available flag, subcommand, and positional value parameters.
    -p --path               Path of git repo. (equivalent to --work-tree=<path> --git-dir=<path>/.git/)
    -f --filter             Path to filter on in \`git log -- <path>\`. When in filter mode, the commits, reflog, and stash are filtered based on the given path, and some operations are restricted
    -v --version            Print the current version
    -d --debug              Run in debug mode with logging (see --logs flag below). Use the LOG_LEVEL env var to set the log level (debug/info/warn/error)
    -l --logs               Tail lazygit logs (intended to be used when \`lazygit --debug\` is called in a separate terminal tab)
       --profile            Start the profiler and serve it on http port 6060. See CONTRIBUTING.md for more info.
    -c --config             Print the default config
    -cd --print-config-dir   Print the config directory
    -ucd --use-config-dir     override default config directory with provided directory
    -w --work-tree          equivalent of the --work-tree git argument
    -g --git-dir            equivalent of the --git-dir git argument
    -ucf --use-config-file    Comma separated list to custom config file(s)
    -sm --screen-mode        The initial screen-mode, which determines the size of the focused panel. Valid options: 'normal' (default), 'half', 'full'
`;
}

type Parsed = {
  configDir?: string;
  positional: string[];
  actions: Set<string>;
};

const flagAliases: Record<string, string> = {
  h: "help",
  help: "help",
  v: "version",
  version: "version",
  c: "config",
  config: "config",
  cd: "print-config-dir",
  "print-config-dir": "print-config-dir",
  d: "debug",
  debug: "debug",
  l: "logs",
  logs: "logs",
  profile: "profile",
  p: "path",
  path: "path",
  f: "filter",
  filter: "filter",
  ucd: "use-config-dir",
  "use-config-dir": "use-config-dir",
  w: "work-tree",
  "work-tree": "work-tree",
  g: "git-dir",
  "git-dir": "git-dir",
  ucf: "use-config-file",
  "use-config-file": "use-config-file",
  sm: "screen-mode",
  "screen-mode": "screen-mode",
};

const flagsRequiringValue = new Set([
  "path",
  "filter",
  "use-config-dir",
  "work-tree",
  "git-dir",
  "use-config-file",
  "screen-mode",
]);

function printHelpError(message: string): never {
  process.stdout.write(helpText() + "\n" + message + "\n");
  process.exit(2);
  throw new Error(message);
}

function parseArgs(args: string[]): Parsed {
  const parsed: Parsed = { positional: [], actions: new Set() };
  for (let index = 0; index < args.length; index++) {
    const raw = args[index];
    if (raw === "--") {
      parsed.positional.push(...args.slice(index + 1));
      break;
    }
    if (!raw.startsWith("-") || raw === "-") {
      parsed.positional.push(raw);
      continue;
    }

    const prefixLength = raw.startsWith("--") ? 2 : 1;
    const withoutDash = raw.slice(prefixLength);
    const eqIndex = withoutDash.indexOf("=");
    const name = eqIndex >= 0 ? withoutDash.slice(0, eqIndex) : withoutDash;
    const valueFromEquals = eqIndex >= 0 ? withoutDash.slice(eqIndex + 1) : undefined;
    const canonical = flagAliases[name];
    if (!canonical) {
      if (valueFromEquals === undefined && index + 1 >= args.length) {
        printHelpError(`Expected a following arg for flag ${name}, but it did not exist.`);
      }
      printHelpError(`Unknown flag: ${name}`);
    }

    if (flagsRequiringValue.has(canonical)) {
      let value = valueFromEquals;
      if (value === undefined) {
        if (index + 1 >= args.length) {
          printHelpError(`Expected a following arg for flag ${name}, but it did not exist.`);
        }
        value = args[++index];
      }
      if (canonical === "use-config-dir") {
        parsed.configDir = value;
      }
      continue;
    }

    if (valueFromEquals !== undefined) {
      printHelpError(`Unexpected argument: ${valueFromEquals}`);
    }
    parsed.actions.add(canonical);
  }
  return parsed;
}

function defaultConfigDir(): string {
  if (process.env.XDG_CONFIG_HOME) {
    return path.join(process.env.XDG_CONFIG_HOME, "lazygit");
  }
  const home = process.env.HOME || "";
  return path.join(home, ".config", "lazygit");
}

function readDefaultConfig(): string {
  return fs.readFileSync(path.join(__dirname, "default_config.yml"), "utf8");
}

function timestamp(): string {
  const now = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${now.getFullYear()}/${pad(now.getMonth() + 1)}/${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
}

function startupError(): never {
  const reason = process.env.TERM
    ? "*fs.PathError open /dev/tty: no such device or address"
    : "*fmt.wrapError terminal entry not found: term not set";
  process.stderr.write(`${timestamp()} An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues

${reason}
/workspace/pkg/app/app.go:55 (0xc91c3f)
/workspace/pkg/app/entry_point.go:177 (0xc93eb6)
/workspace/main.go:23 (0xc95258)
`);
  process.exit(1);
  throw new Error("startup failed");
}

function tailLogs(): void {
  const dir = defaultConfigDir();
  const candidates = [
    path.join(dir, "development.log"),
    path.join(dir, "lazygit.log"),
  ];
  for (const file of candidates) {
    if (fs.existsSync(file)) {
      const child = childProcess.spawn("tail", ["-f", file], { stdio: "inherit" });
      child.on("exit", (code: number | null) => process.exit(code ?? 0));
      return;
    }
  }
  process.stderr.write(`No log file found in ${dir}\n`);
  process.exit(1);
}

function main(): void {
  const parsed = parseArgs(process.argv.slice(2));

  if (parsed.actions.has("help")) {
    process.stdout.write(helpText());
    return;
  }
  if (parsed.actions.has("version")) {
    process.stdout.write(VERSION + "\n");
    return;
  }
  if (parsed.actions.has("config")) {
    process.stdout.write(readDefaultConfig());
    return;
  }
  if (parsed.actions.has("print-config-dir")) {
    process.stdout.write((parsed.configDir || defaultConfigDir()) + "\n");
    return;
  }
  if (parsed.actions.has("logs")) {
    tailLogs();
  }

  if (parsed.positional.length > 1) {
    printHelpError(`Unexpected argument: ${parsed.positional[1]}`);
  }
  if (parsed.positional.length === 1 && !["status", "branch", "log", "stash"].includes(parsed.positional[0])) {
    process.stderr.write(`${timestamp()} Invalid git arg value: '${parsed.positional[0]}'. Must be one of the following values: status, branch, log, stash. e.g. 'lazygit status'. See 'lazygit --help'.\n`);
    process.exit(1);
  }

  startupError();
}

main();
