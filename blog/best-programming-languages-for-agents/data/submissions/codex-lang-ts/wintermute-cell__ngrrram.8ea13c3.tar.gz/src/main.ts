declare const require: any;
declare const process: any;

const fs = require("fs");

type Options = {
  n: string;
  top: number;
  combi: number;
  rep: number;
  wpm: number;
  acc: number;
  emuIn: string;
  emuOut: string;
  showOrtho: boolean;
  nokb: boolean;
  cat: boolean;
};

const HELP = `Usage: executable [OPTIONS]

Options:
  -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]
  -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]
  -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]
  -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]
  -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]
  -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]
      --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
      --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
      --show-ortho        show keyboard in ortholinear format
      --nokb              pass this flag to disable the keyboard layout display.
      --cat               the most important flag. don't practice alone.
  -h, --help              Print help`;

const CLAP_USAGE =
  "Usage: executable <--n <2|3|4|w|file>|--top <1-200>|--combi <1-200>|--rep <number>|--wpm <number>|--acc <0-100>|--emu-in <layout>|--emu-out <layout>|--show-ortho|--nokb|--cat>";

const BIGRAMS = [
  "th", "he", "in", "er", "an", "re", "on", "at", "en", "nd", "ti", "es", "or", "te", "of",
  "ed", "is", "it", "al", "ar", "st", "to", "nt", "ng", "se", "ha", "as", "ou", "io", "le",
  "ve", "co", "me", "de", "hi", "ri", "ro", "ic", "ne", "ea", "ra", "ce", "li", "ch", "ll",
  "be", "ma", "si", "om", "ur", "ca", "el", "ta", "la", "ns", "di", "fo", "ho", "pe", "ec",
  "pr", "no", "ct", "us", "ac", "ot", "il", "tr", "ly", "nc", "et", "ut", "ss", "so", "rs",
  "un", "lo", "wa", "ge", "ie", "wh", "ee", "wi", "em", "ad", "ol", "rt", "po", "we", "na",
  "ul", "ni", "ts", "mo", "ow", "pa", "im", "mi", "ai", "sh"
];

const TRIGRAMS = [
  "the", "and", "ing", "ion", "ent", "her", "tha", "nth", "int", "ere", "tio", "ter", "est", "ers",
  "ati", "hat", "ate", "all", "eth", "hes", "ver", "his", "oft", "ith", "fth", "sth", "oth", "res",
  "ont", "rea", "ons", "nce", "men", "con", "ted", "pro", "for", "are", "not", "but", "had", "you",
  "was", "one", "our", "out", "who", "get", "she", "can", "has", "him", "com", "ght", "ill", "ain"
];

const TETRAGRAMS = [
  "tion", "ther", "that", "with", "ment", "ions", "this", "here", "from", "ould", "ting", "have",
  "ight", "were", "hich", "whic", "atio", "ever", "ough", "ance", "they", "will", "been", "their",
  "said", "each", "when", "more", "them", "some", "what", "into", "time", "only", "than", "over"
];

const WORDS = [
  "the", "of", "and", "to", "in", "a", "is", "that", "for", "it", "as", "was", "with", "be", "by",
  "on", "not", "he", "i", "this", "are", "or", "his", "from", "at", "which", "but", "have", "an",
  "had", "they", "you", "were", "their", "one", "all", "we", "can", "her", "has", "there", "been",
  "if", "more", "when", "will", "would", "who", "so", "no"
];

const LAYOUTS: Record<string, string[]> = {
  qwerty: ["qwertyuiop", "asdfghjkl", "zxcvbnm"],
  qwertz: ["qwertzuiop", "asdfghjkl", "yxcvbnm"],
  azerty: ["azertyuiop", "qsdfghjklm", "wxcvbn"],
  dvorak: ["',.pyfgcrl", "aoeuidhtns", ";qjkxbmwvz"],
  colemak: ["qwfpgjluy", "arstdhneio", "zxcvbkm"],
  colemakdh: ["qwfpbjluy", "arstgmneio", "zxcdvkh"]
};

function clapError(message: string, usage?: string): never {
  process.stderr.write(`error: ${message}\n\n`);
  if (usage) process.stderr.write(`${usage}\n\n`);
  process.stderr.write("For more information, try '--help'.\n");
  process.exit(2);
  throw new Error(message);
}

function customError(message: string): never {
  process.stderr.write(`${message}\n`);
  process.exit(1);
  throw new Error(message);
}

function parseIntValue(flag: string, shown: string, raw: string): number {
  if (!/^[+-]?\d+$/.test(raw)) {
    clapError(`invalid value '${raw}' for '${flag} ${shown}': invalid digit found in string`);
  }
  return Number(raw);
}

function takeValue(args: string[], idx: number, flag: string, shown: string): string {
  const value = args[idx + 1];
  if (value === undefined || value.startsWith("-")) {
    clapError(`a value is required for '${flag} ${shown}' but none was supplied`);
  }
  return value;
}

function parseArgs(args: string[]): Options {
  const opt: Options = { n: "2", top: 50, combi: 2, rep: 3, wpm: 40, acc: 94, emuIn: "", emuOut: "", showOrtho: false, nokb: false, cat: false };
  const seen = new Set<string>();
  const mark = (name: string, shown: string) => {
    if (seen.has(name)) clapError(`the argument '${shown}' cannot be used multiple times`, "Usage: executable [OPTIONS]");
    seen.add(name);
  };

  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") {
      process.stdout.write(HELP + "\n");
      process.exit(0);
    }
    if (a.startsWith("--help=")) {
      clapError(`unexpected value '${a.slice(7)}' for '--help' found; no more were expected`, "Usage: executable --help");
    }
    switch (a) {
      case "-n":
      case "--n": {
        mark("n", "--n <2|3|4|w|file>");
        opt.n = takeValue(args, i, "--n", "<2|3|4|w|file>");
        i++;
        break;
      }
      case "-t":
      case "--top": {
        mark("top", "--top <1-200>");
        opt.top = parseIntValue("--top", "<1-200>", takeValue(args, i, "--top", "<1-200>"));
        i++;
        break;
      }
      case "-c":
      case "--combi": {
        mark("combi", "--combi <1-200>");
        opt.combi = parseIntValue("--combi", "<1-200>", takeValue(args, i, "--combi", "<1-200>"));
        i++;
        break;
      }
      case "-r":
      case "--rep": {
        mark("rep", "--rep <number>");
        opt.rep = parseIntValue("--rep", "<number>", takeValue(args, i, "--rep", "<number>"));
        i++;
        break;
      }
      case "-w":
      case "--wpm": {
        mark("wpm", "--wpm <number>");
        opt.wpm = parseIntValue("--wpm", "<number>", takeValue(args, i, "--wpm", "<number>"));
        i++;
        break;
      }
      case "-a":
      case "--acc": {
        mark("acc", "--acc <0-100>");
        opt.acc = parseIntValue("--acc", "<0-100>", takeValue(args, i, "--acc", "<0-100>"));
        i++;
        break;
      }
      case "--emu-in":
        mark("emu-in", "--emu-in <layout>");
        opt.emuIn = takeValue(args, i, "--emu-in", "<layout>");
        i++;
        break;
      case "--emu-out":
        mark("emu-out", "--emu-out <layout>");
        opt.emuOut = takeValue(args, i, "--emu-out", "<layout>");
        i++;
        break;
      case "--show-ortho":
        mark("show-ortho", "--show-ortho");
        opt.showOrtho = true;
        break;
      case "--nokb":
        mark("nokb", "--nokb");
        opt.nokb = true;
        break;
      case "--cat":
        mark("cat", "--cat");
        opt.cat = true;
        break;
      default:
        if (a.startsWith("-")) {
          const tip = a === "--unknown" ? "\n\n  tip: a similar argument exists: '--n'" : "";
          clapError(`unexpected argument '${a}' found${tip}`, CLAP_USAGE);
        }
        clapError(`unexpected argument '${a}' found`, CLAP_USAGE);
    }
  }
  return opt;
}

function validate(opt: Options) {
  if (opt.top < 1 || opt.top > 200) customError("Invalid argument for top. Use a number between 1 and 200.");
  if (opt.combi < 1 || opt.combi > 200) customError("Invalid argument for combi. Use a number between 1 and 200.");
  if (opt.acc < 0 || opt.acc > 100) customError("Invalid argument for acc. Use a number between 0 and 100.");
  if ((opt.emuIn && !opt.emuOut) || (!opt.emuIn && opt.emuOut)) customError("You need to specify both emu_in and emu_out.");
  if (opt.rep < 1) opt.rep = 1;
  if (opt.wpm < 0) opt.wpm = 0;
}

function getPool(n: string): string[] {
  if (n === "2") return BIGRAMS;
  if (n === "3") return TRIGRAMS;
  if (n === "4") return TETRAGRAMS;
  if (n === "w") return WORDS;
  if (!fs.existsSync(n)) customError(`File not found: ${n}`);
  const txt = fs.readFileSync(n, "utf8");
  return txt.split(/[,\r\n]+/).map((s: string) => s.trim()).filter(Boolean);
}

function chooseLesson(pool: string[], opt: Options): string[] {
  const top = pool.slice(0, Math.min(opt.top, pool.length));
  const out: string[] = [];
  const combi = Math.min(opt.combi, top.length);
  for (let i = 0; i < combi; i++) {
    const idx = (Date.now() + i * 17 + Math.floor(Math.random() * top.length)) % top.length;
    out.push(top[idx]);
  }
  const lesson: string[] = [];
  for (let r = 0; r < opt.rep; r++) {
    for (const item of out) lesson.push(item);
  }
  return lesson;
}

function emulate(text: string, opt: Options): string {
  if (!opt.emuIn || !opt.emuOut) return text;
  const input = LAYOUTS[opt.emuIn];
  const output = LAYOUTS[opt.emuOut];
  if (!input || !output) return text;
  const map = new Map<string, string>();
  input.join("").split("").forEach((ch, i) => map.set(ch, output.join("")[i] || ch));
  return text.split("").map(ch => map.get(ch.toLowerCase()) || ch).join("");
}

function keyboard(opt: Options): string {
  const rows = LAYOUTS[opt.emuOut || "qwerty"] || LAYOUTS.qwerty;
  if (opt.showOrtho) {
    return rows.map(r => r.split("").map(k => `[${k}]`).join(" ")).join("\n");
  }
  return rows.map((r, i) => " ".repeat(i * 2) + r.split("").map(k => `[${k}]`).join(" ")).join("\n");
}

function render(target: string, typed: string, opt: Options, final = false) {
  const clear = "\x1b[2J\x1b[H";
  const correct = typed.split("").filter((c, i) => c === target[i]).length;
  const total = Math.max(typed.length, 1);
  const acc = Math.floor((correct / total) * 100);
  const elapsed = startTime ? Math.max((Date.now() - startTime) / 60000, 1 / 60000) : 0;
  const wpm = startTime ? Math.floor((typed.length / 5) / elapsed) : 0;
  let body = clear;
  body += "ngrrram\n\n";
  body += target + "\n";
  body += typed + "\n\n";
  body += `WPM: ${wpm} / ${opt.wpm}    ACC: ${acc}% / ${opt.acc}%\n`;
  if (!opt.nokb) body += "\n" + keyboard(opt) + "\n";
  if (opt.cat) body += "\n /\\_/\\\\\n( o.o )\n > ^ <\n";
  if (final) body += "\nLesson finished. Press q or Ctrl-C to quit.\n";
  else body += "\nType the text above. Press Esc or Ctrl-C to quit.\n";
  process.stdout.write(body);
}

let startTime = 0;

function runInteractive(opt: Options) {
  const pool = getPool(opt.n);
  const lesson = chooseLesson(pool, opt).map(x => emulate(x, opt)).join(" ");

  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    process.stdout.write("\x1b[?1049h");
    process.stderr.write('Error: Os { code: 6, kind: Uncategorized, message: "No such device or address" }\n');
    process.exit(1);
  }

  process.stdout.write("\x1b[?1049h\x1b[?25l");
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.setEncoding("utf8");
  let typed = "";
  render(lesson, typed, opt);

  const cleanup = (code = 0) => {
    try { process.stdin.setRawMode(false); } catch {}
    process.stdout.write("\x1b[?25h\x1b[?1049l");
    process.exit(code);
  };
  process.on("SIGINT", () => cleanup(0));
  process.stdin.on("data", (chunk: string) => {
    for (const ch of chunk) {
      if (ch === "\u0003" || ch === "\u001b" || ch === "q" && typed.length >= lesson.length) cleanup(0);
      if (typed.length >= lesson.length) continue;
      if (!startTime && ch.length === 1 && ch >= " ") startTime = Date.now();
      if (ch === "\u007f" || ch === "\b") typed = typed.slice(0, -1);
      else if (ch === "\r" || ch === "\n") typed += " ";
      else if (ch >= " ") typed += ch;
      render(lesson, typed, opt, typed.length >= lesson.length);
    }
  });
}

const opt = parseArgs(process.argv.slice(2));
validate(opt);
runInteractive(opt);
