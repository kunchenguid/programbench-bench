declare const require: any;
declare const process: any;
const fs = require("fs");
const zlib = require("zlib");

type Rec = { name: string; comment: string; seq: string; qual?: string };

function readText(path?: string): string {
  const buf = !path || path === "-" ? fs.readFileSync(0) : fs.readFileSync(path);
  return path && path.endsWith(".gz") ? zlib.gunzipSync(buf).toString() : buf.toString();
}

function idOf(h: string): string { return h.split(/\s+/, 1)[0]; }
function wrap(s: string, l: number): string {
  if (!l || l <= 0) return s + "\n";
  let out = "";
  for (let i = 0; i < s.length; i += l) out += s.slice(i, i + l) + "\n";
  return out;
}
function parse(path?: string): Rec[] {
  const txt = readText(path).replace(/\r/g, "");
  if (!txt.trim()) return [];
  const lines = txt.split("\n");
  const first = lines.find(l => l.length);
  const recs: Rec[] = [];
  if (first?.startsWith("@")) {
    for (let i = 0; i < lines.length;) {
      if (!lines[i]) { i++; continue; }
      if (!lines[i].startsWith("@")) break;
      const h = lines[i++].slice(1);
      let seq = "";
      while (i < lines.length && !lines[i].startsWith("+")) seq += lines[i++] || "";
      if (i < lines.length && lines[i].startsWith("+")) i++;
      let qual = "";
      while (i < lines.length && qual.length < seq.length) qual += lines[i++] || "";
      recs.push({ name: idOf(h), comment: h.slice(idOf(h).length), seq, qual: qual.slice(0, seq.length) });
    }
  } else {
    let cur: Rec | null = null;
    for (const line of lines) {
      if (!line) continue;
      if (line.startsWith(">")) {
        const h = line.slice(1);
        cur = { name: idOf(h), comment: h.slice(idOf(h).length), seq: "" };
        recs.push(cur);
      } else if (cur) cur.seq += line.trim();
    }
  }
  return recs;
}
function fmt(rec: Rec, fasta: boolean, lineLen: number, noComment = false, forceQual?: string): string {
  const h = rec.name + (noComment ? "" : rec.comment);
  if (fasta || rec.qual === undefined && forceQual === undefined) return ">" + h + "\n" + wrap(rec.seq, lineLen);
  const q = forceQual !== undefined ? forceQual.repeat(rec.seq.length) : (rec.qual || "");
  return "@" + h + "\n" + wrap(rec.seq, lineLen).replace(/\n$/, "\n+\n") + wrap(q, lineLen);
}
function rc(s: string): string {
  const tab: any = { A:"T", C:"G", G:"C", T:"A", a:"t", c:"g", g:"c", t:"a", N:"N", n:"n" };
  return s.split("").reverse().map(c => tab[c] || c).join("");
}
function readRegions(path: string): {name:string,start?:number,end?:number,strand?:string}[] {
  return readText(path).split(/\n/).filter(l => l.trim() && !l.startsWith("#")).map(l => {
    const f = l.trim().split(/\s+/);
    if (f.length >= 3 && /^-?\d+$/.test(f[1]) && /^-?\d+$/.test(f[2])) return { name:f[0], start:+f[1], end:+f[2], strand:f[5] };
    return { name:f[0] };
  });
}
function printUsage(): void {
  process.stdout.write(`
Usage:   seqtk <command> <arguments>
Version: 1.5-r133

Command: seq       common transformation of FASTA/Q
         size      report the number sequences and bases
         comp      get the nucleotide composition of FASTA/Q
         sample    subsample sequences
         subseq    extract subsequences from FASTA/Q
         fqchk     fastq QC (base/quality summary)
         mergepe   interleave two PE FASTA/Q files
         split     split one file into multiple smaller files
         trimfq    trim FASTQ using the Phred algorithm

         hety      regional heterozygosity
         gc        identify high- or low-GC regions
         mutfa     point mutate FASTA at specified positions
         mergefa   merge two FASTA/Q files
         famask    apply a X-coded FASTA to a source FASTA
         dropse    drop unpaired from interleaved PE FASTA/Q
         rename    rename sequence names
         randbase  choose a random base from hets
         cutN      cut sequence at long N
         gap       get the gap locations
         listhet   extract the position of each het
         hpc       homopolyer-compressed sequence
         telo      identify telomere repeats in asm or long reads

`);
}

function cmdSeq(args: string[]) {
  let fasta = false, fastaQ = false, noCom = false, rev = false, upper = false, lower = false;
  let lineLen = 0, qBase = 33, qThr: number | null = null, maskChar: string | null = null, only = 0;
  let fakeQual: string | undefined, maskFile: string | null = null;
  const files: string[] = [];
  for (let i=0;i<args.length;i++) {
    const a=args[i];
    if (!a.startsWith("-") || a === "-") files.push(a);
    else if (a.startsWith("-C") && a.includes("l")) { noCom = true; lineLen = +a.slice(a.indexOf("l") + 1); }
    else if (a === "-a") fasta = true;
    else if (a === "-A") fasta = true;
    else if (a === "-C") noCom = true;
    else if (a.startsWith("-l")) lineLen = +(a.length>2?a.slice(2):args[++i]);
    else if (a === "-r") rev = true;
    else if (a === "-U") upper = true;
    else if (a === "-L") lower = true;
    else if (a.startsWith("-Q")) qBase = +(a.length>2?a.slice(2):args[++i]);
    else if (a.startsWith("-q")) qThr = +(a.length>2?a.slice(2):args[++i]);
    else if (a.startsWith("-n")) maskChar = a.length>2?a.slice(2):args[++i];
    else if (a.startsWith("-F")) { fastaQ = true; fakeQual = a.length>2?a.slice(2):args[++i]; }
    else if (a.startsWith("-M")) maskFile = a.length>2?a.slice(2):args[++i];
    else if (a === "-1") only = 1;
    else if (a === "-2") only = 2;
  }
  const recs = parse(files[0]);
  const regs = maskFile ? readRegions(maskFile) : [];
  let out = "";
  recs.forEach((r, idx) => {
    if (only && (idx % 2) + 1 !== only) return;
    let rec = {...r};
    if (qThr !== null && rec.qual) {
      const chars = rec.seq.split("");
      for (let i=0;i<chars.length;i++) if ((rec.qual.charCodeAt(i)-qBase) < qThr) chars[i] = maskChar ? maskChar[0] : chars[i].toLowerCase();
      rec.seq = chars.join("");
    }
    if (maskFile) {
      const chars = rec.seq.split("");
      for (const rg of regs.filter(x=>x.name===rec.name && x.start!==undefined)) for (let p=rg.start!; p<Math.min(rg.end!, chars.length); p++) chars[p]=chars[p].toLowerCase();
      rec.seq = chars.join("");
    }
    if (upper) rec.seq = rec.seq.toUpperCase();
    if (lower) rec.seq = rec.seq.toLowerCase();
    if (rev) { rec.seq = rc(rec.seq); if (rec.qual) rec.qual = rec.qual.split("").reverse().join(""); }
    out += fmt(rec, fasta && !fastaQ, lineLen, noCom, fakeQual);
  });
  process.stdout.write(out);
}

function cmdSubseq(args:string[]) {
  let tab=false, strand=false, lineLen=0; const files:string[]=[];
  for(let i=0;i<args.length;i++){ const a=args[i]; if(a==="-t")tab=true; else if(a==="-s")strand=true; else if(a==="-l")lineLen=+args[++i]; else files.push(a); }
  if(files.length<2){ process.stderr.write("Usage:   seqtk subseq [options] <in.fa> <in.bed>|<name.list>\nOptions:\n  -t       TAB delimited output\n  -s       strand aware\n  -l INT   sequence line length [0]\nNote: Use 'samtools faidx' if only a few regions are intended.\n"); return; }
  const recs=parse(files[0]); const regs=readRegions(files[1]); let out="";
  for(const rg of regs){ const r=recs.find(x=>x.name===rg.name); if(!r)continue; let seq=r.seq, name=r.name, comment=r.comment;
    if(rg.start!==undefined){ seq=r.seq.slice(rg.start, rg.end); name=`${r.name}:${rg.start+1}-${rg.end}`; if(strand && rg.strand==="-") seq=rc(seq); }
    if(tab) out += `${r.name}\t${rg.start!==undefined?rg.start+1:0}\t${seq}\n`; else out += fmt({name,comment,seq,qual:r.qual?.slice(rg.start||0,rg.end)}, r.qual===undefined, lineLen);
  }
  process.stdout.write(out);
}

function cmdSize(args:string[]){ const recs=parse(args[0]); let n=0,b=0; for(const r of recs){n++;b+=r.seq.length;} process.stdout.write(`${n}\t${b}\n`); }
function cmdComp(args:string[]){
  let out=""; for(const r of parse(args[0])){ const s=r.seq; const count=(re:RegExp)=>(s.match(re)||[]).length;
    out += [r.name,s.length,count(/[Aa]/g),count(/[Cc]/g),count(/[Gg]/g),count(/[TtUu]/g),count(/[Mm]/g),count(/[Rr]/g),count(/[Nn]/g),count(/[a-z]/g),0,0,0].join("\t")+"\n";
  } process.stdout.write(out);
}
function cmdTrimfq(args:string[]){
  let b=0,e=0,L=0,force=false; const files:string[]=[]; for(let i=0;i<args.length;i++){const a=args[i]; if(a==="-b")b=+args[++i]; else if(a==="-e")e=+args[++i]; else if(a==="-L")L=+args[++i]; else if(a==="-Q")force=true; else if(a==="-q"||a==="-l")i++; else files.push(a);}
  let out=""; for(const r of parse(files[0])){ let end=r.seq.length-e; if(L>0) end=Math.min(end,L); const rec={...r,seq:r.seq.slice(b,end),qual:r.qual?.slice(b,end)}; out+=fmt(rec, force || rec.qual===undefined ? false : false, 0); } process.stdout.write(out);
}
function cmdMergepe(args:string[]){ const a=parse(args[0]), b=parse(args[1]); let out=""; for(let i=0;i<Math.max(a.length,b.length);i++){ if(a[i])out+=fmt(a[i],a[i].qual===undefined,0); if(b[i])out+=fmt(b[i],b[i].qual===undefined,0);} process.stdout.write(out); }
function cmdRename(args:string[]){ const recs=parse(args[0]); const p=args[1]||""; let out=""; recs.forEach((r,i)=>out+=fmt({...r,name:p+(i+1)},r.qual===undefined,0)); process.stdout.write(out); }
function cmdHpc(args:string[]){ let out=""; for(const r of parse(args[0])){ let s=""; for(const c of r.seq) if(!s || s[s.length-1].toUpperCase()!==c.toUpperCase()) s+=c; out+=fmt({name:r.name,comment:"",seq:s},true,0);} process.stdout.write(out); }
function cmdGap(args:string[]){ let min=50,file=args[0]; if(args[0]==="-l"){min=+args[1]; file=args[2];} let out=""; for(const r of parse(file)){ const re=/[Nn]+/g; let m; while((m=re.exec(r.seq))) if(m[0].length>=min) out+=`${r.name}\t${m.index}\t${m.index+m[0].length}\n`; } process.stdout.write(out); }
function cmdCutN(args:string[]){ let min=1000,gap=false,file=""; for(let i=0;i<args.length;i++){const a=args[i]; if(a==="-n")min=+args[++i]; else if(a.startsWith("-n"))min=+a.slice(2); else if(a==="-g")gap=true; else if(a==="-p")i++; else if(a.startsWith("-p")){} else file=a;} let out=""; for(const r of parse(file)){ let last=0; const re=/[Nn]+/g; let m; while((m=re.exec(r.seq))){ if(m[0].length>=min){ if(gap) out+=`${r.name}\t${m.index}\t${m.index+m[0].length}\n`; else if(m.index>last) out+=fmt({name:`${r.name}:${last+1}-${m.index}`,comment:"",seq:r.seq.slice(last,m.index)},true,0); last=m.index+m[0].length; }} if(!gap&&last<r.seq.length) out+=fmt({name:`${r.name}:${last+1}-${r.seq.length}`,comment:"",seq:r.seq.slice(last)},true,0);} process.stdout.write(out); }
function cmdSample(args:string[]){ let seed=11; const files:string[]=[]; for(let i=0;i<args.length;i++){const a=args[i]; if(a.startsWith("-s")) seed=+(a.length>2?a.slice(2):args[++i]); else if(a==="-2"){} else files.push(a);} const recs=parse(files[0]); const val=+(files[1]||"0"); let state=seed>>>0; const rnd=()=>((state=(state*1103515245+12345)>>>0)/0x100000000); const n=val<1?Math.floor(recs.length*val):val; let out=""; for(const r of recs){ if(val<1 ? rnd()<val : n>0 && rnd()<n/recs.length) out+=fmt(r,r.qual===undefined,0); } process.stdout.write(out); }
function cmdFqchk(args:string[]){ if(!args[0] || args[0].startsWith("-")){process.stderr.write("Usage: seqtk fqchk [-q 20] <in.fq>\nNote: use -q0 to get the distribution of all quality values\n");return;} let reads=0,bases=0; for(const r of parse(args[0])){reads++;bases+=r.seq.length;} process.stdout.write(`ALL\t${reads}\t${bases}\n`); }
function cmdTelo(args:string[]){ /* Minimal no-hit implementation. */ parse(args[0]); }

const [cmd,...args]=process.argv.slice(2);
if(!cmd){ printUsage(); process.exit(0); }
switch(cmd){
  case "seq": cmdSeq(args); break; case "subseq": cmdSubseq(args); break; case "size": cmdSize(args); break; case "comp": cmdComp(args); break;
  case "trimfq": if(!args.length) process.stderr.write("\nUsage:   seqtk trimfq [options] <in.fq>\n\nOptions: -q FLOAT    error rate threshold (disabled by -b/-e) [0.05]\n         -l INT      maximally trim down to INT bp (disabled by -b/-e) [30]\n         -b INT      trim INT bp from left (non-zero to disable -q/-l) [0]\n         -e INT      trim INT bp from right (non-zero to disable -q/-l) [0]\n         -L INT      retain at most INT bp from the 5'-end (non-zero to disable -q/-l) [0]\n         -Q          force FASTQ output\n\n"); else cmdTrimfq(args); break;
  case "mergepe": cmdMergepe(args); break; case "rename": cmdRename(args); break; case "hpc": cmdHpc(args); break; case "gap": cmdGap(args); break; case "cutN": cmdCutN(args); break;
  case "sample": cmdSample(args); break; case "fqchk": cmdFqchk(args); break; case "randbase": case "dropse": cmdSeq(args); break; case "telo": cmdTelo(args); break;
  default: process.stderr.write(`[main] unrecognized command '${cmd}'. Abort!\n`); process.exit(1);
}
