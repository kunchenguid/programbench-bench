declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");
const childProcess = require("child_process");

type ScriptEntry = {
  command: string;
  description?: string;
  tags?: string[];
};

type Config = {
  scripts: Record<string, ScriptEntry>;
  defaults: Record<string, any>;
};

const VERSION = "pier 0.1.6";

function out(s = "") {
  process.stdout.write(s + "\n");
}

function err(s = "") {
  process.stderr.write(s + "\n");
}

function exitError(message: string): never {
  err("error: " + message);
  process.exit(1);
  throw new Error(message);
}

function unquote(v: string): string {
  v = v.trim();
  if ((v.startsWith("'") && v.endsWith("'")) || (v.startsWith('"') && v.endsWith('"'))) {
    const body = v.slice(1, -1);
    if (v[0] === '"') {
      return body.replace(/\\n/g, "\n").replace(/\\"/g, '"').replace(/\\\\/g, "\\");
    }
    return body.replace(/\\'/g, "'");
  }
  return v;
}

function quote(v: string): string {
  return "'" + String(v).replace(/\\/g, "\\\\").replace(/'/g, "\\'") + "'";
}

function parseArray(v: string): string[] {
  const body = v.trim().replace(/^\[/, "").replace(/\]$/, "").trim();
  if (!body) return [];
  const res: string[] = [];
  let cur = "";
  let q = "";
  for (let i = 0; i < body.length; i++) {
    const ch = body[i];
    if (q) {
      cur += ch;
      if (ch === q && body[i - 1] !== "\\") q = "";
    } else if (ch === "'" || ch === '"') {
      q = ch;
      cur += ch;
    } else if (ch === ",") {
      res.push(unquote(cur));
      cur = "";
    } else {
      cur += ch;
    }
  }
  if (cur.trim()) res.push(unquote(cur));
  return res;
}

function parseConfig(file: string): Config {
  let text = "";
  try {
    text = fs.readFileSync(file, "utf8");
  } catch (e: any) {
    exitError(`Unable to read config from file ${file}: ${e.message} `);
  }
  const cfg: Config = { scripts: {}, defaults: {} };
  let section = "";
  let alias = "";
  for (const raw of text.split(/\r?\n/)) {
    let line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const sec = line.match(/^\[(.+)]$/);
    if (sec) {
      section = sec[1];
      alias = "";
      if (section.startsWith("scripts.")) {
        alias = section.slice("scripts.".length);
        if (!cfg.scripts[alias]) cfg.scripts[alias] = { command: "" };
      }
      continue;
    }
    const eq = line.indexOf("=");
    if (eq < 0) continue;
    const key = line.slice(0, eq).trim();
    const val = line.slice(eq + 1).trim();
    if (section.startsWith("scripts.") && alias) {
      const ent = cfg.scripts[alias];
      if (key === "command") ent.command = unquote(val);
      else if (key === "description") ent.description = unquote(val);
      else if (key === "tags") ent.tags = parseArray(val);
    } else if (section === "default") {
      cfg.defaults[key] = /^\d+$/.test(val) ? Number(val) : unquote(val);
    }
  }
  return cfg;
}

function writeConfig(file: string, cfg: Config) {
  const aliases = Object.keys(cfg.scripts).sort();
  let text = "";
  if (aliases.length === 0) text += "[scripts]\n\n";
  for (const a of aliases) {
    const s = cfg.scripts[a];
    text += `[scripts.${a}]\n`;
    text += `command = ${quote(s.command || "")}\n`;
    if (s.description) text += `description = ${quote(s.description)}\n`;
    if (s.tags && s.tags.length) text += `tags = [${s.tags.map(quote).join(", ")}]\n`;
    text += "\n";
  }
  text += "[default]\n";
  for (const k of Object.keys(cfg.defaults || {}).sort()) {
    const v = cfg.defaults[k];
    text += `${k} = ${typeof v === "number" ? v : quote(String(v))}\n`;
  }
  fs.writeFileSync(file, text);
}

function defaultConfigPath(): string | null {
  const env = process.env;
  if (env.PIER_CONFIG_PATH) return env.PIER_CONFIG_PATH;
  const cwdPier = path.join(process.cwd(), "pier.toml");
  if (fs.existsSync(cwdPier)) return cwdPier;
  const xdg = env.XDG_CONFIG_HOME;
  const checks = [];
  if (xdg) {
    checks.push(path.join(xdg, "pier", "config.toml"));
    checks.push(path.join(xdg, "pier", "config"));
    checks.push(path.join(xdg, "pier.toml"));
  }
  if (env.HOME) {
    checks.push(path.join(env.HOME, ".pier.toml"));
    checks.push(path.join(env.HOME, ".pier"));
  }
  return checks.find((p: string) => fs.existsSync(p)) || null;
}

function getConfigPath(global: Parsed): string {
  const cf = global.options["config-file"] || global.options.c;
  if (cf) return cf;
  const p = defaultConfigPath();
  if (!p) exitError("No default config file found. See help for more info.");
  return p;
}

type Parsed = { flags: Set<string>; options: Record<string, string>; positionals: string[] };

function parseArgs(args: string[], spec: Record<string, string | boolean>): Parsed {
  const flags = new Set<string>();
  const options: Record<string, string> = {};
  const positionals: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") {
      positionals.push(...args.slice(i + 1));
      break;
    }
    if (a.startsWith("--")) {
      const name = a.slice(2);
      const kind = spec[name];
      if (kind === "value" || kind === "multi") {
        if (i + 1 >= args.length) exitError(`The argument '--${name} <${name}>' requires a value but none was supplied`);
        if (kind === "multi") options[name] = options[name] ? options[name] + "," + args[++i] : args[++i];
        else options[name] = args[++i];
      } else {
        flags.add(name);
      }
    } else if (a.startsWith("-") && a.length > 1) {
      const chars = a.slice(1).split("");
      for (let j = 0; j < chars.length; j++) {
        const c = chars[j];
        const kind = spec[c];
        if (kind === "value" || kind === "multi") {
          if (j !== chars.length - 1) exitError(`Found argument '${a}' which wasn't expected, or isn't valid in this context`);
          if (i + 1 >= args.length) exitError(`The argument '-${c} <${c}>' requires a value but none was supplied`);
          if (kind === "multi") options[c] = options[c] ? options[c] + "," + args[++i] : args[++i];
          else options[c] = args[++i];
        } else flags.add(c);
      }
    } else {
      positionals.push(a);
    }
  }
  return { flags, options, positionals };
}

function parseGlobalArgs(args: string[]): Parsed {
  const flags = new Set<string>();
  const options: Record<string, string> = {};
  const positionals: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-c" || a === "--config-file") {
      if (i + 1 >= args.length) exitError(`The argument '${a}' requires a value but none was supplied`);
      options[a === "-c" ? "c" : "config-file"] = args[++i];
    } else if (a === "-h" || a === "--help") {
      flags.add(a === "-h" ? "h" : "help");
    } else if (a === "-V" || a === "--version") {
      flags.add(a === "-V" ? "V" : "version");
    } else if (a === "-v" || a === "--verbose") {
      flags.add(a === "-v" ? "v" : "verbose");
    } else {
      positionals.push(...args.slice(i));
      break;
    }
  }
  return { flags, options, positionals };
}

function hasScripts(cfg: Config) {
  return Object.keys(cfg.scripts).length > 0;
}

function needScripts(cfg: Config) {
  if (!hasScripts(cfg)) exitError("No scripts exist. Would you like to add a new script?");
}

function needAlias(cfg: Config, alias: string): ScriptEntry {
  needScripts(cfg);
  const s = cfg.scripts[alias];
  if (!s) exitError(`AliasNotFound: No script found by alias ${alias}`);
  return s;
}

function runScript(cfg: Config, alias: string, args: string[]) {
  const s = needAlias(cfg, alias);
  const r = childProcess.spawnSync("/bin/sh", ["-c", s.command, alias, ...args], { stdio: "inherit" });
  if (r.error) exitError(r.error.message);
  process.exit(r.status == null ? 0 : r.status);
}

function printHelp(command?: string) {
  if (!command) {
    out(`${VERSION}
Benjamin Scholtz, Isak Johansson
A simple script management CLI

USAGE:
    executable [FLAGS] [OPTIONS] <alias> [args]...
    executable [FLAGS] [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information
    -v, --verbose    The level of verbosity

OPTIONS:
    -c, --config-file <path>    Sets a custom config file.

SUBCOMMANDS:
    add            Add a new script to config.
    config-init    alias: init - Add a config file.
    copy           alias: cp - Copy existing alias to the new one
    edit           Edit a script matching alias.
    list           alias: ls - List scripts
    move           alias: mv, rename - Move/rename existing alias to the new one
    remove         alias: rm - Remove a script matching alias.
    run            Run a script matching alias.
    show           Show a script matching alias.`);
    return;
  }
  const m: Record<string, string> = {
    add: `executable-add 0.1.6\nAdd a new script to config.\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]`,
    list: `executable-list 0.1.6\nalias: ls - List scripts\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]`,
    run: `executable-run 0.1.6\nRun a script matching alias.\n\nUSAGE:\n    executable run <alias> [args]...`,
    show: `executable-show 0.1.6\nShow a script matching alias.\n\nUSAGE:\n    executable show <alias>`,
    remove: `executable-remove 0.1.6\nalias: rm - Remove a script matching alias.\n\nUSAGE:\n    executable remove <alias>`,
    copy: `executable-copy 0.1.6\nalias: cp - Copy existing alias to the new one\n\nUSAGE:\n    executable copy <from-alias> <to-alias>`,
    move: `executable-move 0.1.6\nalias: mv, rename - Move/rename existing alias to the new one\n\nUSAGE:\n    executable move [FLAGS] <from-alias> <to-alias>`,
    "config-init": `executable-config-init 0.1.6\nalias: init - Add a config file.\n\nUSAGE:\n    executable config-init`,
  };
  out(m[command] || "");
}

function list(cfg: Config, p: Parsed) {
  needScripts(cfg);
  const tagFilter = (p.options.t || p.options.tag || "").split(",").filter(Boolean);
  let aliases = Object.keys(cfg.scripts).sort().filter(a => {
    if (!tagFilter.length) return true;
    const tags = cfg.scripts[a].tags || [];
    return tagFilter.every(t => tags.includes(t));
  });
  if (p.flags.has("q") || p.flags.has("list_aliases")) {
    aliases.forEach(out);
    return;
  }
  const widthOpt = p.options.c || p.options["cmd-width"] || cfg.defaults.cmd_width || cfg.defaults.cmdWidth;
  const width = p.flags.has("l") || p.flags.has("cmd_full") ? 0 : Number(widthOpt || 0);
  const rows = aliases.map(a => {
    const s = cfg.scripts[a];
    let cmd = s.command || "";
    if (width && cmd.length > width) cmd = cmd.slice(0, width);
    return [a, (s.tags || []).join(","), cmd, s.description || ""];
  });
  const heads = ["Alias", "Tags", "Command", "Description"];
  const lens = heads.map((h, i) => Math.max(h.length, ...rows.map(r => r[i].length)));
  const fmt = (r: string[]) => "⋮ " + r.map((x, i) => x.padEnd(lens[i])).join(" ⋮ ") + " ⋮";
  const sep = "≖".repeat(fmt(heads).length);
  out(sep);
  out(fmt(heads));
  out(sep);
  rows.forEach(r => out(fmt(r)));
  out(sep);
}

function commandAdd(cfgFile: string, args: string[]) {
  const p = parseArgs(args, { a: "value", alias: "value", d: "value", description: "value", t: "multi", tag: "multi", f: true, force: true, h: true, help: true, V: true, version: true });
  if (p.flags.has("h") || p.flags.has("help")) return printHelp("add");
  if (p.flags.has("V") || p.flags.has("version")) return out(VERSION);
  const alias = p.options.a || p.options.alias;
  if (!alias) exitError("The following required arguments were not provided:\n    --alias <alias>");
  const command = p.positionals.join(" ");
  if (!command) exitError("EditorError: Failed when trying to get input from editor Failed to open `vi` as a text editor or editor was terminated with errors.");
  const cfg = parseConfig(cfgFile);
  if (cfg.scripts[alias] && !(p.flags.has("f") || p.flags.has("force"))) exitError(`AliasAlreadyExists:  ${alias}`);
  cfg.scripts[alias] = { command };
  const desc = p.options.d || p.options.description;
  if (desc) cfg.scripts[alias].description = desc;
  const tags = p.options.t || p.options.tag;
  if (tags) cfg.scripts[alias].tags = tags.split(",");
  writeConfig(cfgFile, cfg);
  out(`Added ${alias}`);
}

function commandInit() {
  const xdg = process.env.XDG_CONFIG_HOME || (process.env.HOME ? path.join(process.env.HOME, ".config") : "");
  const file = path.join(xdg, "pier", "config.toml");
  try {
    fs.writeFileSync(file, "[scripts.hello-pier]\ncommand = 'echo Hello, Pier!'\ndescription = 'This is an example command.'\n\n[default]\n");
  } catch (e: any) {
    exitError(`Failed to create directory. ${e.message}`);
  }
  out("Added hello-pier");
}

function main() {
  const raw = process.argv.slice(2);
  const global = parseGlobalArgs(raw);
  if (global.flags.has("V") || global.flags.has("version")) return out(VERSION);
  if (global.flags.has("h") || global.flags.has("help") || raw.length === 0) return printHelp();
  const pos = global.positionals;
  const sub = pos[0];
  const aliases: Record<string, string> = { ls: "list", rm: "remove", cp: "copy", mv: "move", rename: "move", init: "config-init" };
  const cmd = aliases[sub] || sub;
  const rest = pos.slice(1);
  if (["add", "list", "run", "show", "remove", "copy", "move", "edit", "config-init"].includes(cmd)) {
    if (cmd === "config-init") {
      if (rest.includes("-h") || rest.includes("--help")) return printHelp("config-init");
      if (rest.includes("-V") || rest.includes("--version")) return out(VERSION);
      return commandInit();
    }
    const cfgFile = getConfigPath(global);
    if (cmd === "add") return commandAdd(cfgFile, rest);
    const cfg = parseConfig(cfgFile);
    if (cmd === "list") {
      const lp = parseArgs(rest, { q: true, list_aliases: true, l: true, cmd_full: true, c: "value", "cmd-width": "value", t: "multi", tag: "multi", h: true, help: true, V: true, version: true });
      if (lp.flags.has("h") || lp.flags.has("help")) return printHelp("list");
      if (lp.flags.has("V") || lp.flags.has("version")) return out(VERSION);
      return list(cfg, lp);
    }
    if (rest.includes("-h") || rest.includes("--help")) return printHelp(cmd);
    if (rest.includes("-V") || rest.includes("--version")) return out(VERSION);
    if (cmd === "run") return runScript(cfg, rest[0], rest.slice(1));
    if (cmd === "show") return out(needAlias(cfg, rest[0]).command);
    if (cmd === "remove") {
      needAlias(cfg, rest[0]);
      delete cfg.scripts[rest[0]];
      writeConfig(cfgFile, cfg);
      return out(`Removed ${rest[0]}`);
    }
    if (cmd === "copy") {
      const from = rest[0], to = rest[1];
      const s = needAlias(cfg, from);
      if (cfg.scripts[to]) exitError(`AliasAlreadyExists:  ${to}`);
      cfg.scripts[to] = JSON.parse(JSON.stringify(s));
      writeConfig(cfgFile, cfg);
      return out(`Copy from alias ${from} to new alias ${to}`);
    }
    if (cmd === "move") {
      const p = parseArgs(rest, { f: true, force: true });
      const from = p.positionals[0], to = p.positionals[1];
      const s = needAlias(cfg, from);
      if (cfg.scripts[to] && !(p.flags.has("f") || p.flags.has("force"))) exitError(`AliasAlreadyExists:  ${to}`);
      delete cfg.scripts[from];
      cfg.scripts[to] = s;
      writeConfig(cfgFile, cfg);
      return out(`Move from alias ${from} to new alias ${to}`);
    }
    if (cmd === "edit") exitError("EditorError: Failed when trying to get input from editor Failed to open `vi` as a text editor or editor was terminated with errors.");
  }
  const cfg = parseConfig(getConfigPath(global));
  runScript(cfg, sub, rest);
}

main();
