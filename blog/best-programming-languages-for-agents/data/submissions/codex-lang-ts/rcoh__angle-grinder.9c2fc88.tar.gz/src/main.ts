declare const process: any;
declare const require: any;

const fs = require("fs");

type Row = { raw: string; fields: Record<string, any> };

function usage(long = false) {
  if (long) {
    console.log(`Usage: executable [OPTIONS] [QUERY]

Arguments:
  [QUERY]
          The query

Options:
  -f, --file <FILE>
          Optionally reads from a file instead of Stdin

  -m, --format <FORMAT>
          DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output

  -o, --output <OUTPUT>
          Set output format. Options: 
          - \`json\`,
          - \`logfmt\`
          - \`format=<rust format string>\` (eg. -o format='{src} => {dst}'
          - \`legacy\` The original output format, auto aligning [k=v]

  -a, --alias-dir <ALIAS_DIR>
          Specifies an alternative directory to use for aliases. Defaults to \`.agrind-aliases\` in all parent directories.

      --no-alias
          Disables aliases

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

For more details + docs, see https://github.com/rcoh/angle-grinder`);
  } else {
    console.log(`Usage: executable [OPTIONS] [QUERY]

Arguments:
  [QUERY]  The query

Options:
  -f, --file <FILE>            Optionally reads from a file instead of Stdin
  -m, --format <FORMAT>        DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output
  -o, --output <OUTPUT>        Set output format. One of (json|legacy|format=<rust fmt str>|logfmt)
  -a, --alias-dir <ALIAS_DIR>  Specifies an alternative directory to use for aliases. Defaults to \`.agrind-aliases\` in all parent directories.
      --no-alias               Disables aliases
  -h, --help                   Print help (see more with '--help')
  -V, --version                Print version

For more details + docs, see https://github.com/rcoh/angle-grinder`);
  }
}

function splitTop(s: string, sep: string): string[] {
  const out: string[] = [];
  let q: string | null = null, depth = 0, start = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q) { if (c === "\\" && i + 1 < s.length) i++; else if (c === q) q = null; continue; }
    if (c === '"' || c === "'") { q = c; continue; }
    if (c === "(" || c === "[" || c === "{") depth++;
    else if (c === ")" || c === "]" || c === "}") depth--;
    else if (depth === 0 && s.slice(i, i + sep.length) === sep && !(sep === "|" && (s[i - 1] === "|" || s[i + 1] === "|"))) {
      out.push(s.slice(start, i).trim()); start = i + sep.length; i += sep.length - 1;
    }
  }
  out.push(s.slice(start).trim());
  return out.filter(x => x.length);
}

function unquote(s: string): string {
  s = s.trim();
  if ((s[0] === '"' && s[s.length - 1] === '"') || (s[0] === "'" && s[s.length - 1] === "'")) {
    return s.slice(1, -1).replace(/\\"/g, '"').replace(/\\n/g, "\n").replace(/\\t/g, "\t");
  }
  return s;
}

function auto(v: any): any {
  if (typeof v !== "string") return v;
  if (v === "null" || v === "None") return null;
  if (v === "true") return true;
  if (v === "false") return false;
  if (/^-?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?$/i.test(v) && !/^0\d+/.test(v)) return Number(v);
  return v;
}

function getPath(obj: any, path: string): any {
  path = path.trim();
  if (!path || path === "_raw" || path === "raw") return obj.raw ?? obj.fields?._raw;
  let cur = obj.fields ? obj.fields : obj;
  const parts: (string|number)[] = [];
  let i = 0;
  while (i < path.length) {
    if (path[i] === "[") {
      if (path[i + 1] === '"' || path[i + 1] === "'") {
        const q = path[i + 1]; let j = i + 2, val = "";
        while (j < path.length && path[j] !== q) { val += path[j++]; }
        parts.push(val); i = path.indexOf("]", j) + 1 || path.length;
      } else {
        let j = path.indexOf("]", i); parts.push(Number(path.slice(i + 1, j))); i = j + 1;
      }
    } else if (path[i] === ".") i++;
    else {
      let j = i;
      while (j < path.length && /[A-Za-z0-9_$-]/.test(path[j])) j++;
      parts.push(path.slice(i, j)); i = j;
    }
  }
  for (const p of parts) {
    if (cur == null) return null;
    if (typeof p === "number") {
      if (!Array.isArray(cur)) return null;
      cur = cur[p < 0 ? cur.length + p : p];
    } else cur = cur[p];
  }
  return cur === undefined ? null : cur;
}

function setPath(fields: Record<string, any>, name: string, val: any) {
  fields[name.trim()] = val;
}

function valString(v: any): string {
  if (v === null || v === undefined) return "None";
  if (Array.isArray(v)) return "[" + v.map(valString).join(", ") + "]";
  if (typeof v === "object") return "{" + Object.entries(v).map(([k, x]) => `${k}:${valString(x)}`).join(", ") + "}";
  if (typeof v === "number" && Number.isFinite(v)) return Number.isInteger(v) ? String(v) : String(Math.round(v * 100) / 100);
  return String(v);
}

function tokenizeExpr(s: string): string[] {
  const re = /\s*(=>|==|!=|<>|<=|>=|&&|\|\||[()+\-*/!,<>]|\["[^"]+"\]|"(?:\\.|[^"])*"|'(?:\\.|[^'])*'|-?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?|[A-Za-z_][A-Za-z0-9_.$\[\]-]*)/gy;
  const out: string[] = []; let m: RegExpExecArray | null;
  while ((m = re.exec(s)) !== null) out.push(m[1]);
  return out;
}

function evalExpr(expr: string, row: Row): any {
  const t = tokenizeExpr(expr); let p = 0;
  const peek = (): string | undefined => t[p];
  function eat(): string | undefined;
  function eat(x: string): boolean;
  function eat(x?: string): any { return x ? (t[p] === x ? (p++, true) : false) : t[p++]; }
  function primary(): any {
    const x = eat();
    if (x === undefined) return null;
    if (x === "(") { const v = or(); eat(")"); return v; }
    if (x === "!" || x.toLowerCase() === "not") return !truth(primary());
    if (x[0] === '"' || x[0] === "'") return unquote(x);
    if (/^-?(?:\d+\.?\d*|\.\d+)/.test(x)) return Number(x);
    if (peek() === "(") {
      eat("("); const args: any[] = [];
      if (peek() !== ")") do { args.push(or()); } while (eat(","));
      eat(")"); return callFunc(x, args);
    }
    return getPath(row, x);
  }
  function unary(): any { if (eat("-")) return -Number(unary()); return primary(); }
  function mul(): any { let v = unary(); while (peek() === "*" || peek() === "/") { const op = eat(); const r = unary(); v = op === "*" ? Number(v) * Number(r) : Number(v) / Number(r); } return v; }
  function add(): any { let v = mul(); while (peek() === "+" || peek() === "-") { const op = eat(); const r = mul(); if (op === "+" && (typeof v === "string" || typeof r === "string")) v = valString(v) + valString(r); else v = op === "+" ? Number(v) + Number(r) : Number(v) - Number(r); } return v; }
  function cmp(): any { let v = add(); while (["==","!=","<>","<=",">=","<",">"].includes(peek())) { const op = eat(); const r = add(); if (op === "==") v = looseEq(v, r); else if (op === "!=" || op === "<>") v = !looseEq(v, r); else { const a:any = coerceCmp(v), b:any = coerceCmp(r); v = op === "<=" ? a <= b : op === ">=" ? a >= b : op === "<" ? a < b : a > b; } } return v; }
  function and(): any { let v = cmp(); while (peek()?.toLowerCase() === "and" || peek() === "&&") { eat(); v = truth(v) ? cmp() : (cmp(), false); } return v; }
  function or(): any { let v = and(); while (peek()?.toLowerCase() === "or" || peek() === "||") { eat(); v = truth(v) ? (and(), true) : and(); } return v; }
  return or();
}

function coerceCmp(v: any): any { return typeof v === "string" && !isNaN(Number(v)) ? Number(v) : v; }
function looseEq(a: any, b: any): boolean { return a == b; }
function truth(v: any): boolean { return !!v && v !== "false" && v !== "0"; }

function callFunc(name: string, args: any[]): any {
  const n = name.toLowerCase();
  if (n === "if") return truth(args[0]) ? args[1] : args[2];
  if (n === "concat") return args.map(valString).join("");
  if (n === "contains") return valString(args[0]).includes(valString(args[1]));
  if (n === "length") return valString(args[0]).length;
  if (n === "num") return Number(args[0]);
  if (n === "parsehex") return parseInt(String(args[0]), 16);
  if (n === "substring") return valString(args[0]).substring(Number(args[1]), args[2] == null ? undefined : Number(args[2]));
  if (n === "tolowercase") return valString(args[0]).toLowerCase();
  if (n === "touppercase") return valString(args[0]).toUpperCase();
  if (n === "isnull") return args[0] == null;
  if (n === "isempty") return args[0] == null || args[0] === "";
  if (n === "isblank") return args[0] == null || /^\s*$/.test(String(args[0]));
  if (n === "isnumeric") return args[0] !== null && args[0] !== "" && !isNaN(Number(args[0]));
  if (n === "parsedate") return new Date(String(args[0]));
  if (n === "now") return new Date();
  const math: any = { abs:Math.abs, acos:Math.acos, asin:Math.asin, atan:Math.atan, atan2:Math.atan2, cbrt:Math.cbrt, ceil:Math.ceil, cos:Math.cos, cosh:Math.cosh, exp:Math.exp, expm1:Math.expm1, floor:Math.floor, hypot:Math.hypot, log:Math.log, log10:Math.log10, log1p:Math.log1p, round:Math.round, sin:Math.sin, sinh:Math.sinh, sqrt:Math.sqrt, tan:Math.tan, tanh:Math.tanh, todegrees:(x:number)=>x*180/Math.PI, toradians:(x:number)=>x*Math.PI/180 };
  if (math[n]) return math[n](...args.map(Number));
  return null;
}

function matchFilter(line: string, f: string): boolean {
  f = f.trim(); if (!f || f === "*") return true;
  const toks = tokenizeFilter(f); let p = 0;
  function prim(): boolean {
    const x = toks[p++];
    if (x === "(") { const v = expr(); p++; return v; }
    if (x?.toUpperCase() === "NOT") return !prim();
    if (!x) return true;
    if (x[0] === '"') return line.includes(unquote(x));
    const pat = "^" + x.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + "$";
    return new RegExp(pat, "i").test(line) || new RegExp(x.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*"), "i").test(line);
  }
  function term(): boolean { let v = prim(); while (toks[p]?.toUpperCase() === "AND") { p++; const r = prim(); v = v && r; } return v; }
  function expr(): boolean { let v = term(); while (toks[p]?.toUpperCase() === "OR") { p++; const r = term(); v = v || r; } return v; }
  return expr();
}
function tokenizeFilter(s: string): string[] {
  const out: string[] = []; let i = 0;
  while (i < s.length) {
    if (/\s/.test(s[i])) { i++; continue; }
    if (s[i] === "(" || s[i] === ")") { out.push(s[i++]); continue; }
    if (s[i] === '"') { let j = i + 1; while (j < s.length && s[j] !== '"') j++; out.push(s.slice(i, j + 1)); i = j + 1; continue; }
    let j = i; while (j < s.length && !/\s|[()]/.test(s[j])) j++; out.push(s.slice(i, j)); i = j;
  }
  return out;
}

function parseLogfmt(s: string): Record<string, any> | null {
  const o: Record<string, any> = {}; const re = /(?:^|\s)([A-Za-z0-9_.-]+)(?:=("(?:\\.|[^"])*"|[^\s]*))?/g; let m, any = false;
  while ((m = re.exec(s)) !== null) { any = true; o[m[1]] = m[2] === undefined ? null : auto(unquote(m[2])); }
  return any ? o : null;
}

function parsePattern(input: string, pattern: string): string[] | null {
  const parts = pattern.split("*");
  let pos = 0; const vals: string[] = [];
  for (let i = 0; i < parts.length; i++) {
    let lit = parts[i].replace(/\s+/g, " ");
    if (lit) {
      const idx = input.indexOf(lit, pos);
      if (idx < 0) return null;
      if (i > 0) vals.push(input.slice(pos, idx).trim());
      pos = idx + lit.length;
    } else if (i === parts.length - 1) vals.push(input.slice(pos).trim());
  }
  if (parts[parts.length - 1] !== "") vals.push(input.slice(pos).trim());
  const stars = pattern.split("*").length - 1;
  return vals.slice(0, stars);
}

function compileRegex(reText: string): RegExp {
  return new RegExp(reText.replace(/\(\?P<([A-Za-z_][A-Za-z0-9_]*)>/g, "(?<$1>"));
}

function applyOp(rows: Row[], op: string): { rows: Row[]; aggregate?: boolean } {
  op = op.trim();
  if (!op) return { rows };
  let m: RegExpMatchArray | null;
  if (op === "json" || (m = op.match(/^json\s+from\s+(.+)$/i))) {
    const field = m ? m[1].trim() : null;
    return { rows: rows.flatMap(r => { try { const obj = JSON.parse(field ? valString(getPath(r, field)) : r.raw); return [{ raw: r.raw, fields: { ...r.fields, ...obj } }]; } catch { return []; } }) };
  }
  if (op === "logfmt" || (m = op.match(/^logfmt\s+from\s+(.+)$/i))) {
    const field = m ? m[1].trim() : null;
    return { rows: rows.flatMap(r => { const obj = parseLogfmt(field ? valString(getPath(r, field)) : r.raw); return obj ? [{ raw: r.raw, fields: { ...r.fields, ...obj } }] : []; }) };
  }
  if ((m = op.match(/^parse\s+regex\s+(".*?"|'.*?')(?:\s+from\s+(\S+))?(.*)$/i))) {
    const re = compileRegex(unquote(m[1])), field = m[2], nodrop = /nodrop/i.test(m[3] || "");
    return { rows: rows.flatMap(r => { const mm = re.exec(field ? valString(getPath(r, field)) : r.raw); if (!mm) return nodrop ? [r] : []; return [{ raw: r.raw, fields: { ...r.fields, ...(mm.groups || {}) } }]; }) };
  }
  if ((m = op.match(/^parse\s+(".*?"|'.*?')(?:\s+from\s+(\S+))?\s+as\s+(.+?)(?:\s+(nodrop|noconvert).*)?$/i))) {
    const pat = unquote(m[1]), field = m[2], names = splitTop(m[3].replace(/\s+(nodrop|noconvert).*$/i, ""), ","), noconvert = /noconvert/i.test(op), nodrop = /nodrop/i.test(op);
    return { rows: rows.flatMap(r => { const vals = parsePattern(field ? valString(getPath(r, field)) : r.raw, pat); if (!vals) return nodrop ? [r] : []; const f = { ...r.fields }; names.forEach((n, i) => setPath(f, n, noconvert ? vals[i] : auto(vals[i] ?? ""))); return [{ raw: r.raw, fields: f }]; }) };
  }
  if ((m = op.match(/^split(?:\(([^)]+)\))?(?:\s+on\s+(".*?"|'.*?'|\S+))?(?:\s+as\s+(\S+))?$/i))) {
    const inf = m[1]?.trim(), sep = m[2] ? unquote(m[2]) : ",", out = m[3] || inf || "_split";
    return { rows: rows.map(r => { const source = inf ? valString(getPath(r, inf)) : r.raw; return { raw: r.raw, fields: { ...r.fields, [out]: splitRespectQuotes(source, sep).map(x => auto(x.trim().replace(/^"|"$/g, ""))) } }; }) };
  }
  if ((m = op.match(/^fields(?:\s+(only|except|\+|-))?\s+(.+)$/i))) {
    const mode = (m[1] || "+").toLowerCase(), names = splitTop(m[2], ",");
    return { rows: rows.map(r => { const f: Record<string, any> = {}; if (mode === "except" || mode === "-") { Object.assign(f, r.fields); for (const n of names) delete f[n]; } else for (const n of names) { const v = getPath(r, n); if (v !== null) f[n.replace(/^\["|"\]$/g, "")] = v; } return { raw: r.raw, fields: f }; }) };
  }
  if ((m = op.match(/^where\s+(.+)$/i))) return { rows: rows.filter(r => truth(evalExpr(m![1], r))) };
  if ((m = op.match(/^limit\s+(-?\d+)$/i))) { const n = Number(m[1]); return { rows: n >= 0 ? rows.slice(0, n) : rows.slice(n) }; }
  if ((m = op.match(/^sort\s+by\s+(.+?)(?:\s+(asc|desc))?$/i))) {
    const exprs = splitTop(m[1], ","), desc = (m[2] || "").toLowerCase() === "desc";
    rows.sort((a, b) => { for (const e of exprs) { const av = evalExpr(e, a), bv = evalExpr(e, b); if (av < bv) return desc ? 1 : -1; if (av > bv) return desc ? -1 : 1; } return 0; });
    return { rows };
  }
  if ((m = op.match(/^timeslice\((.+)\)\s+(\d+)(ns|us|ms|s|m|h|d|w)(?:\s+as\s+(\S+))?$/i))) {
    const mult:any = { ns:1e-6, us:1e-3, ms:1, s:1000, m:60000, h:3600000, d:86400000, w:604800000 };
    const dur = Number(m[2]) * mult[m[3]], name = m[4] || "_timeslice";
    return { rows: rows.map(r => { const d = new Date(evalExpr(m![1], r)); const t = Math.floor(d.getTime() / dur) * dur; return { raw:r.raw, fields:{...r.fields, [name]: new Date(t).toISOString()} }; }) };
  }
  if (isAggregate(op)) return { rows: aggregate(rows, op), aggregate: true };
  if ((m = op.match(/^(.+)\s+as\s+([A-Za-z_][A-Za-z0-9_.-]*)$/i))) return { rows: rows.map(r => ({ raw: r.raw, fields: { ...r.fields, [m![2]]: evalExpr(m![1], r) } })) };
  return { rows };
}

function splitRespectQuotes(s: string, sep: string): string[] {
  if (sep === "") return [...s];
  const out: string[] = []; let cur = "", q: string | null = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q) {
      if (c === q) q = null; else cur += c;
      continue;
    }
    if (c === '"' || c === "'") { q = c; continue; }
    if (s.slice(i, i + sep.length) === sep) {
      if (!(sep === " " && cur === "")) out.push(cur);
      cur = ""; i += sep.length - 1;
      continue;
    }
    cur += c;
  }
  if (!(sep === " " && cur === "")) out.push(cur);
  return out;
}

function loadAliases(dirArg: string | null): Record<string, string> {
  const dirs: string[] = [];
  if (dirArg) dirs.push(dirArg);
  else {
    let d = process.cwd();
    while (true) {
      dirs.push(d + "/.agrind-aliases");
      const nd = require("path").dirname(d);
      if (nd === d) break; d = nd;
    }
  }
  const aliases: Record<string, string> = {};
  for (const d of dirs) {
    if (!fs.existsSync(d)) continue;
    for (const f of fs.readdirSync(d)) {
      const p = d + "/" + f;
      if (!fs.statSync(p).isFile()) continue;
      const txt = fs.readFileSync(p, "utf8");
      const km = txt.match(/keyword\s*=\s*"([^"]+)"/);
      const tm = txt.match(/template\s*=\s*"""([\s\S]*?)"""/) || txt.match(/template\s*=\s*"([^"]*)"/);
      if (km && tm) aliases[km[1]] = tm[1].trim();
    }
  }
  return aliases;
}

function isAggregate(op: string): boolean {
  return /(^|,\s*)(count(?:\(|\b)|sum\(|average\(|avg\(|min\(|max\(|p(?:ct)?\d+\(|count_distinct\(|total\()/i.test(op);
}

function aggregate(rows: Row[], op: string): Row[] {
  const byParts = op.match(/^(.*?)(?:\s+by\s+(.+))?$/i)!;
  const specs = splitTop(byParts[1], ",");
  const keys = byParts[2] ? splitTop(byParts[2], ",") : [];
  const groups = new Map<string, { keyVals:any[]; rows:Row[] }>();
  for (const r of rows) {
    const kv = keys.map(k => evalExpr(k, r));
    const id = JSON.stringify(kv);
    if (!groups.has(id)) groups.set(id, { keyVals: kv, rows: [] });
    groups.get(id)!.rows.push(r);
  }
  if (groups.size === 0 && keys.length === 0) groups.set("[]", { keyVals: [], rows: [] });
  const out: Row[] = [];
  for (const g of groups.values()) {
    const f: Record<string, any> = {};
    keys.forEach((k, i) => f[keyName(k)] = g.keyVals[i]);
    for (const spec0 of specs) {
      const sm = spec0.match(/^(.+?)(?:\s+as\s+([A-Za-z_][A-Za-z0-9_-]*))?$/i)!;
      const spec = sm[1].trim(), alias = sm[2];
      let name = alias, val: any = null, m: RegExpMatchArray | null;
      if ((m = spec.match(/^count(?:\((.*)\))?$/i))) { name ||= "_count"; val = m[1] ? g.rows.filter(r => truth(evalExpr(m![1], r))).length : g.rows.length; }
      else if ((m = spec.match(/^sum\((.*)\)$/i))) { name ||= "_sum"; val = nums(g.rows, m[1]).reduce((a,b)=>a+b,0); }
      else if ((m = spec.match(/^(?:average|avg)\((.*)\)$/i))) { name ||= "_average"; const ns = nums(g.rows, m[1]); val = ns.length ? ns.reduce((a,b)=>a+b,0)/ns.length : null; }
      else if ((m = spec.match(/^min\((.*)\)$/i))) { name ||= "_min"; const ns = nums(g.rows, m[1]); val = ns.length ? Math.min(...ns) : null; }
      else if ((m = spec.match(/^max\((.*)\)$/i))) { name ||= "_max"; const ns = nums(g.rows, m[1]); val = ns.length ? Math.max(...ns) : null; }
      else if ((m = spec.match(/^p(?:ct)?(\d+)\((.*)\)$/i))) { name ||= `p${m[1]}`; const ns = nums(g.rows, m[2]).sort((a,b)=>a-b); val = ns.length ? ns[Math.floor((Number(m[1]) / 100) * (ns.length - 1))] : null; }
      else if ((m = spec.match(/^count_distinct\((.*)\)$/i))) { name ||= "_count_distinct"; val = new Set(g.rows.map(r => JSON.stringify(evalExpr(m![1], r)))).size; }
      else if ((m = spec.match(/^total\((.*)\)$/i))) { name ||= "_total"; val = nums(g.rows, m[1]).reduce((a,b)=>a+b,0); }
      if (name) f[name] = val;
    }
    out.push({ raw: "", fields: f });
  }
  return out;
}

function keyName(k: string): string {
  k = k.trim();
  const mm = k.match(/^[A-Za-z_][A-Za-z0-9_.\[\]-]*$/);
  return mm ? k.split(".")[0].replace(/\[.*\]/, "") : k;
}
function nums(rows: Row[], expr: string): number[] { return rows.map(r => Number(evalExpr(expr, r))).filter(n => !isNaN(n)); }

function render(rows: Row[], output: string, aggregate: boolean) {
  if (output === "json") {
    if (aggregate) console.log(JSON.stringify(rows.map(r => r.fields)));
    else for (const r of rows) console.log(JSON.stringify(r.fields));
    return;
  }
  if (output === "logfmt") { for (const r of rows) console.log(Object.keys(r.fields).sort().map(k => `${k}=${quoteLogfmt(r.fields[k])}`).join(" ")); return; }
  if (output.startsWith("format=")) { const fmt = output.slice(7); for (const r of rows) console.log(fmt.replace(/\{([^}]+)\}/g, (_, k) => valString(getPath(r, k)))); return; }
  if (aggregate) table(rows.map(r => r.fields)); else legacyRows(rows);
}

function quoteLogfmt(v: any): string {
  if (v == null) return "";
  const s = valString(v);
  return /\s|=|"/.test(s) ? JSON.stringify(s) : s;
}
function legacyRows(rows: Row[]) {
  const keys = Array.from(new Set(rows.flatMap(r => Object.keys(r.fields).sort()))).sort();
  const widths = keys.map(k => Math.max(...rows.map(r => r.fields[k] === undefined ? 0 : `[${k}=${valString(r.fields[k])}]`.length)) + 8);
  for (const r of rows) {
    if (!Object.keys(r.fields).length) { console.log(r.raw); continue; }
    const parts = keys.filter(k => r.fields[k] !== undefined).map(k => `[${k}=${valString(r.fields[k])}]`);
    const idxs = keys.map((k, i) => r.fields[k] !== undefined ? i : -1).filter(i => i >= 0);
    console.log(parts.map((p, j) => j === parts.length - 1 ? p : p.padEnd(widths[idxs[j]])).join(""));
  }
}
function table(rows: Record<string, any>[]) {
  const cols = Array.from(new Set(rows.flatMap(r => Object.keys(r))));
  const widths = cols.map(c => Math.max(c.length, ...rows.map(r => fmtCell(r[c]).length)) + 8);
  console.log(cols.map((c, i) => c.padEnd(widths[i])).join("").trimEnd());
  console.log("-".repeat(Math.max(14, widths.reduce((a,b)=>a+b,0))));
  for (const r of rows) console.log(cols.map((c, i) => fmtCell(r[c]).padEnd(widths[i])).join("").trimEnd());
}
function fmtCell(v: any): string { return typeof v === "number" && !Number.isInteger(v) ? v.toFixed(2) : valString(v); }

function main() {
  const args = process.argv.slice(2); let file: string | null = null, output = "legacy", query: string | null = null, aliasDir: string | null = null, noAlias = false;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--help") return usage(true);
    if (a === "-h") return usage(false);
    if (a === "--version" || a === "-V") { console.log("ag 0.19.6"); return; }
    if (a === "-f" || a === "--file") file = args[++i];
    else if (a === "-o" || a === "--output") output = args[++i];
    else if (a.startsWith("--output=")) output = a.slice(9);
    else if (a === "-m" || a === "--format") output = "format=" + args[++i];
    else if (a === "-a" || a === "--alias-dir") aliasDir = args[++i];
    else if (a === "--no-alias") noAlias = true;
    else query = a;
  }
  const input = file ? fs.readFileSync(file, "utf8") : fs.readFileSync(0, "utf8");
  query ||= "*";
  let parts = splitTop(query, "|");
  if (!noAlias) {
    const aliases = loadAliases(aliasDir);
    parts = parts.flatMap((p, idx) => idx > 0 && aliases[p.trim()] ? splitTop(aliases[p.trim()], "|") : [p]);
  }
  const filter = parts.shift() || "*";
  let rows: Row[] = input.replace(/\n$/, "").split(/\n/).filter((_,i,a)=>!(a.length===1&&a[0]==="")).filter(l => matchFilter(l, filter)).map(raw => ({ raw, fields: {} }));
  let aggregate = false;
  for (const op of parts) { const res = applyOp(rows, op); rows = res.rows; aggregate ||= !!res.aggregate; }
  render(rows, output, aggregate);
}

try { main(); } catch (e: any) { console.error(String(e?.message || e)); process.exit(1); }
