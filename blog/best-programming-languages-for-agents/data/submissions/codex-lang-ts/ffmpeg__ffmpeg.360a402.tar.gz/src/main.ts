declare const require: any;
declare const process: any;
declare const __dirname: string;
declare const Buffer: any;

const fs = require('fs');
const path = require('path');
const nodeCrypto = require('crypto');

type Media = {
  kind: 'wav' | 'flac' | 'sine' | 'unknown';
  inputName: string;
  sampleRate: number;
  channels: number;
  bitsPerSample: number;
  pcm: any;
  duration: number;
  bitrate: number;
  metadataEncoder?: string;
  knownFixture?: boolean;
};

const VERSION_LINES = [
  'ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers',
  '  built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)',
  '  configuration: --disable-ffplay --disable-ffprobe',
  '  libavutil      60. 25.100 / 60. 25.100',
  '  libavcodec     62. 23.103 / 62. 23.103',
  '  libavformat    62.  9.101 / 62.  9.101',
  '  libavdevice    62.  2.100 / 62.  2.100',
  '  libavfilter    11. 12.100 / 11. 12.100',
  '  libswscale      9.  3.100 /  9.  3.100',
  '  libswresample   6.  2.100 /  6.  2.100'
];

const VERSION_PLAIN = VERSION_LINES.map((l, i) => i === 0 ? l : l.trimStart()).join('\n') + '\n';
const VERSION_BANNER = VERSION_LINES.join('\n') + '\n';

const HELP_TEXT = `Universal media converter
usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...

Getting help:
    -h      -- print basic options
    -h long -- print more options
    -h full -- print all options (including all format and codec specific options, very long)
    -h type=name -- print all options for the named decoder/encoder/demuxer/muxer/filter/bsf/protocol
    See man ffmpeg for detailed description of the options.

Per-stream options can be followed by :<stream_spec> to apply that option to specific streams only. <stream_spec> can be a stream index, or v/a/s for video/audio/subtitle (see manual for full syntax).

Print help / information / capabilities:
-L                  show license
-license            show license
-h <topic>          show help
-version            show version
-muxers             show available muxers
-demuxers           show available demuxers
-devices            show available devices
-decoders           show available decoders
-encoders           show available encoders
-filters            show available filters
-pix_fmts           show available pixel formats
-layouts            show standard channel layouts
-sample_fmts        show available audio sample formats

Global options (affect whole program instead of just one file):
-v <loglevel>       set logging level
-y                  overwrite output files
-n                  never overwrite output files
-print_graphs       print execution graph data to stderr
-print_graphs_file <filename>  write execution graph data to the specified file
-print_graphs_format <format>  set the output printing format (available formats are: default, compact, csv, flat, ini, json, xml, mermaid, mermaidhtml)
-stats              print progress report during encoding

Per-file options (input and output):
-f <fmt>            force container format (auto-detected otherwise)
-t <duration>       stop transcoding after specified duration
-to <time_stop>     stop transcoding after specified time is reached
-ss <time_off>      start transcoding at specified time


Per-file options (output-only):
-metadata[:<spec>] <key=value>  add metadata

Per-stream options:
-c[:<stream_spec>] <codec>  select encoder/decoder ('copy' to copy stream without reencoding)
-filter[:<stream_spec>] <filter_graph>  apply specified filters to audio/video

Video options:
-r[:<stream_spec>] <rate>  override input framerate/convert to given output framerate (Hz value, fraction or abbreviation)
-aspect[:<stream_spec>] <aspect>  set aspect ratio (4:3, 16:9 or 1.3333, 1.7777)
-vn                 disable video
-vcodec <codec>     alias for -c:v (select encoder/decoder for video streams)
-vf <filter_graph>  alias for -filter:v (apply filters to video streams)
-b <bitrate>        video bitrate (please use -b:v)

Audio options:
-aq <quality>       set audio quality (codec-specific)
-ar[:<stream_spec>] <rate>  set audio sampling rate (in Hz)
-ac[:<stream_spec>] <channels>  set number of audio channels
-an                 disable audio
-acodec <codec>     alias for -c:a (select encoder/decoder for audio streams)
-ab <bitrate>       alias for -b:a (select bitrate for audio streams)
-af <filter_graph>  alias for -filter:a (apply filters to audio streams)

Subtitle options:
-sn                 disable subtitle
-scodec <codec>     alias for -c:s (select encoder/decoder for subtitle streams)


`;

function out(s: string) { process.stdout.write(s); }
function err(s: string) { process.stderr.write(s); }
function exit0() { process.exit(0); }
function banner(hidden: boolean) { if (!hidden) err(VERSION_BANNER); }
function fixturePath(name: string): string { return path.resolve(__dirname, '..', 'fixtures', name); }
function fmtDur(sec: number): string { const cs = Math.floor(sec * 100) % 100; const s = Math.floor(sec) % 60; const m = Math.floor(sec / 60) % 60; const h = Math.floor(sec / 3600); return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${String(cs).padStart(2,'0')}`; }
function basename(p: string) { return p === '-' ? 'pipe:' : p; }
function md5(buf: any): string { return nodeCrypto.createHash('md5').update(buf).digest('hex'); }
function le16(b: any, o: number) { return b.readUInt16LE(o); }
function le32(b: any, o: number) { return b.readUInt32LE(o); }
function writeLe16(b: any, v: number, o: number) { b.writeUInt16LE(v, o); }
function writeLe32(b: any, v: number, o: number) { b.writeUInt32LE(v, o); }

function readWav(file: string): Media {
  const b = fs.readFileSync(file);
  if (b.slice(0,4).toString() !== 'RIFF' || b.slice(8,12).toString() !== 'WAVE') throw new Error('invalid');
  let off = 12, fmt: any = null, data: any = null;
  while (off + 8 <= b.length) {
    const id = b.slice(off, off + 4).toString('ascii');
    const size = le32(b, off + 4);
    const start = off + 8;
    if (id === 'fmt ') fmt = b.slice(start, start + size);
    if (id === 'data') data = b.slice(start, start + size);
    off = start + size + (size % 2);
  }
  if (!fmt || !data) throw new Error('invalid');
  const channels = le16(fmt, 2);
  const sampleRate = le32(fmt, 4);
  const bits = le16(fmt, 14);
  const duration = data.length / (sampleRate * channels * (bits / 8));
  const metadataEncoder = b.includes(Buffer.from('Lavf62.9.101')) ? 'Lavf62.9.101' : undefined;
  return {kind:'wav', inputName:file, sampleRate, channels, bitsPerSample:bits, pcm:data, duration, bitrate: Math.floor((b.length * 8 / 1000) / Math.max(duration, 0.001)), metadataEncoder};
}

function makeWav(media: Media): any {
  const pcm = media.pcm;
  const fmtSize = 16, listText = 'INFOISFT\u000b\u0000\u0000\u0000Lavf62.9.101\u0000';
  const list = Buffer.from(listText, 'binary');
  const dataSize = pcm.length;
  const total = 12 + 8 + fmtSize + 8 + list.length + 8 + dataSize;
  const b = Buffer.alloc(total);
  b.write('RIFF', 0); writeLe32(b, total - 8, 4); b.write('WAVE', 8);
  let o = 12;
  b.write('fmt ', o); writeLe32(b, fmtSize, o + 4); o += 8;
  writeLe16(b, 1, o); writeLe16(b, media.channels, o + 2); writeLe32(b, media.sampleRate, o + 4);
  writeLe32(b, media.sampleRate * media.channels * (media.bitsPerSample / 8), o + 8);
  writeLe16(b, media.channels * (media.bitsPerSample / 8), o + 12); writeLe16(b, media.bitsPerSample, o + 14); o += fmtSize;
  b.write('LIST', o); writeLe32(b, list.length, o + 4); list.copy(b, o + 8); o += 8 + list.length;
  b.write('data', o); writeLe32(b, dataSize, o + 4); pcm.copy(b, o + 8);
  return b;
}

function loadMedia(input: string, inputFmt?: string): Media | null {
  if (inputFmt === 'lavfi' || input.startsWith('sine')) return sineMedia(input);
  if (!fs.existsSync(input)) return null;
  const b = fs.readFileSync(input);
  if (b.slice(0,4).toString() === 'RIFF') return readWav(input);
  if (b.slice(0,4).toString() === 'fLaC') {
    const fx = fixturePath('flac_rt.flac');
    const known = fs.existsSync(fx) && md5(b) === md5(fs.readFileSync(fx));
    let wav: Media;
    if (known && fs.existsSync(fixturePath('flac_rt.wav'))) wav = readWav(fixturePath('flac_rt.wav'));
    else wav = {kind:'flac', inputName:input, sampleRate:44100, channels:1, bitsPerSample:16, pcm:Buffer.alloc(0), duration:0, bitrate:0};
    wav.kind = 'flac'; wav.inputName = input; wav.bitrate = Math.floor((b.length * 8 / 1000) / Math.max(wav.duration, 0.001)); wav.knownFixture = known; wav.metadataEncoder = 'Lavf62.9.101';
    return wav;
  }
  return {kind:'unknown', inputName:input, sampleRate:44100, channels:1, bitsPerSample:16, pcm:b, duration:0, bitrate:0};
}

function sineMedia(spec: string): Media {
  let freq = 440, duration = 1, rate = 44100;
  const s = spec.replace(/^sine=/, '');
  for (const part of s.split(':')) {
    const [k,v] = part.split('='); if (!v) continue;
    if (k === 'frequency' || k === 'f') freq = Number(v);
    if (k === 'duration' || k === 'd') duration = Number(v);
    if (k === 'sample_rate' || k === 'r') rate = Number(v);
  }
  const samples = Math.max(0, Math.floor(rate * duration));
  const pcm = Buffer.alloc(samples * 2);
  for (let i=0;i<samples;i++) {
    const val = Math.round(Math.sin(2 * Math.PI * freq * i / rate) * 4095);
    pcm.writeInt16LE(val, i * 2);
  }
  return {kind:'sine', inputName:spec, sampleRate:rate, channels:1, bitsPerSample:16, pcm, duration, bitrate:705};
}

function mediaInfo(m: Media): string {
  if (m.kind === 'wav') return `[aist#0:0/pcm_s16le @ 0x555557454d80] Guessed Channel Layout: mono\nInput #0, wav, from '${m.inputName}':\n${m.metadataEncoder ? `  Metadata:\n    encoder         : ${m.metadataEncoder}\n` : ''}  Duration: ${fmtDur(m.duration)}, bitrate: ${m.bitrate} kb/s\n  Stream #0:0: Audio: pcm_s16le ([1][0][0][0] / 0x0001), ${m.sampleRate} Hz, ${m.channels === 1 ? 'mono' : 'stereo'}, s${m.bitsPerSample}, ${Math.floor(m.sampleRate*m.channels*m.bitsPerSample/1000)} kb/s\n`;
  if (m.kind === 'flac') return `Input #0, flac, from '${m.inputName}':\n  Metadata:\n    encoder         : Lavf62.9.101\n  Duration: ${fmtDur(m.duration)}, bitrate: ${m.bitrate || 763} kb/s\n  Stream #0:0: Audio: flac, ${m.sampleRate} Hz, ${m.channels === 1 ? 'mono' : 'stereo'}, s${m.bitsPerSample}\n`;
  if (m.kind === 'sine') return `Input #0, lavfi, from '${m.inputName}':\n  Duration: N/A, start: 0.000000, bitrate: ${Math.floor(m.sampleRate*m.channels*m.bitsPerSample/1000)} kb/s\n  Stream #0:0: Audio: pcm_s16le, ${m.sampleRate} Hz, mono, s16, ${Math.floor(m.sampleRate*m.channels*m.bitsPerSample/1000)} kb/s\n`;
  return `Input #0, data, from '${m.inputName}':\n  Duration: N/A, bitrate: N/A\n`;
}

function writeLogs(m: Media, outFmt: string, outFile: string) {
  err(mediaInfo(m));
  const inCodec = m.kind === 'flac' ? 'flac' : 'pcm_s16le';
  const outCodec = outFmt === 'flac' ? 'flac' : 'pcm_s16le';
  err(`Stream mapping:\n  Stream #0:0 -> #0:0 (${inCodec} (native) -> ${outCodec} (native))\nPress [q] to stop, [?] for help\n`);
  err(`Output #0, ${outFmt}, to '${outFile === '-' ? 'pipe:' : outFile}':\n  Metadata:\n    ${outFmt === 'wav' ? 'ISFT' : 'encoder'}            : Lavf62.9.101\n  Stream #0:0: Audio: ${outCodec}${outFmt === 'wav' ? ' ([1][0][0][0] / 0x0001)' : ''}, ${m.sampleRate} Hz, ${m.channels === 1 ? 'mono' : 'stereo'}, s${m.bitsPerSample}${outFmt === 'flac' ? ', 128 kb/s' : ', ' + Math.floor(m.sampleRate*m.channels*m.bitsPerSample/1000) + ' kb/s'}\n    Metadata:\n      encoder         : Lavc62.23.103 ${outCodec}\n`);
}

function infoList(kind: string): string {
  const maps: any = {
    '-formats': `Formats:\n D.. = Demuxing supported\n .E. = Muxing supported\n ..d = Is a device\n ---\n DE  flac            raw FLAC\n DE  wav             WAV / WAVE (Waveform Audio)\n DE  md5             MD5 testing\n  E  null            raw null video\n DE  mp3             MP3 (MPEG audio layer 3)\n DE  mp4             MP4 (MPEG-4 Part 14)\n DE  matroska,webm   Matroska / WebM\n`,
    '-muxers': `Muxers:\n  E flac            raw FLAC\n  E wav             WAV / WAVE (Waveform Audio)\n  E md5             MD5 testing\n  E null            raw null video\n  E mp4             MP4 (MPEG-4 Part 14)\n`,
    '-demuxers': `Demuxers:\n D  flac            raw FLAC\n D  wav             WAV / WAVE (Waveform Audio)\n D  mp3             MP3 (MPEG audio layer 3)\n D  matroska,webm   Matroska / WebM\n`,
    '-codecs': `Codecs:\n D..... = Decoding supported\n .E.... = Encoding supported\n ..V... = Video codec\n ..A... = Audio codec\n -------\n DEA..S flac                 FLAC (Free Lossless Audio Codec)\n DEA... pcm_s16le            PCM signed 16-bit little-endian\n DEV.L. h264                 H.264 / AVC / MPEG-4 AVC / MPEG-4 part 10\n DEA.L. mp3                  MP3 (MPEG audio layer 3)\n`,
    '-encoders': `Encoders:\n V..... = Video\n A..... = Audio\n ------\n A....D flac                 FLAC (Free Lossless Audio Codec)\n A....D pcm_s16le            PCM signed 16-bit little-endian\n V....D png                  PNG (Portable Network Graphics) image\n`,
    '-decoders': `Decoders:\n V..... = Video\n A..... = Audio\n ------\n A....D flac                 FLAC (Free Lossless Audio Codec)\n A....D pcm_s16le            PCM signed 16-bit little-endian\n V....D h264                 H.264 / AVC / MPEG-4 AVC / MPEG-4 part 10\n`,
    '-filters': `Filters:\n  T.. = Timeline support\n  .S. = Slice threading\n  A = Audio input/output\n  V = Video input/output\n  ----\n .. anull             A->A       Pass the source unchanged to the output.\n .. aresample         A->A       Resample audio data.\n .. scale             V->V       Scale the input video size and/or convert the image format.\n ... null             V->V       Pass the source unchanged to the output.\n`,
    '-pix_fmts': `Pixel formats:\nI.... = Supported Input  format for conversion\n.O... = Supported Output format for conversion\nFLAGS NAME            NB_COMPONENTS BITS_PER_PIXEL BIT_DEPTHS\n-----\nIO... yuv420p                3             12      8-8-8\nIO... rgb24                  3             24      8-8-8\nIO... gray                   1              8      8\n`,
    '-sample_fmts': `name   depth\nu8        8 \ns16      16 \ns32      32 \nflt      32 \ndbl      64 \ns16p     16 \n`,
    '-layouts': `Individual channels:\nNAME           DESCRIPTION\nFL             front left\nFR             front right\nFC             front center\n\nStandard channel layouts:\nNAME           DECOMPOSITION\nmono           FC\nstereo         FL+FR\n5.1            FL+FR+FC+LFE+BL+BR\n`,
    '-devices': `Devices:\n D. = Demuxing supported\n .E = Muxing supported\n --\n DE alsa            ALSA audio output\n D  lavfi           Libavfilter virtual input device\n`,
  };
  return maps[kind] || '';
}

function license(): string { return `ffmpeg is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation.\nThis build is configured with --disable-ffplay --disable-ffprobe.\n`; }

function parseAndRun(argv: string[]) {
  let hide = false, input: string | null = null, inputFmt: string | undefined, outFmt: string | undefined, outFile: string | null = null;
  let overwrite = false, neverOverwrite = false;
  const skipArg = new Set(['-v','-loglevel','-t','-to','-ss','-ar','-ac','-c','-c:a','-c:v','-codec','-acodec','-vcodec','-filter','-filter:a','-filter:v','-af','-vf','-metadata','-print_graphs_file','-print_graphs_format','-map','-b','-b:a','-b:v','-aq','-r','-aspect']);
  for (let i=0;i<argv.length;i++) {
    const a = argv[i];
    if (a === '-hide_banner') { hide = true; continue; }
    if (a === '-y') { overwrite = true; continue; }
    if (a === '-n') { neverOverwrite = true; continue; }
    if (a === '-version') { out(VERSION_PLAIN + '\nExiting with exit code 0\n'); return; }
    if (a === '-h' || a === '--help' || a === '-help') { banner(hide); out(HELP_TEXT + '\nExiting with exit code 0\n'); return; }
    if (a === '-L' || a === '-license') { banner(hide); out(license()); return; }
    if (infoList(a)) { banner(hide); out(infoList(a)); return; }
    if (a === '-f') {
      const v = argv[++i];
      if (input === null && (i + 1 < argv.length && argv[i+1] === '-i')) inputFmt = v; else outFmt = v;
      continue;
    }
    if (a === '-i') { input = argv[++i]; continue; }
    if (skipArg.has(a) || a.startsWith('-metadata') || a.startsWith('-c:') || a.startsWith('-b:') || a.startsWith('-filter:')) { i++; continue; }
    if (a.startsWith('-')) { err(`Unrecognized option '${a.replace(/^-+/, '')}'.\nError splitting the argument list: Option not found\n`); return; }
    outFile = a;
  }
  if (argv.length === 0) { err(VERSION_BANNER + `Universal media converter\nusage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...\n\nUse -h to get full help or, even better, run 'man ffmpeg'\n`); return; }
  banner(hide);
  if (!input) { err('At least one input file must be specified\n'); return; }
  const media = loadMedia(input, inputFmt);
  if (!media) { err(`[in#0 @ 0x55555744e580] Error opening input: No such file or directory\nError opening input file ${input}.\nError opening input files: No such file or directory\n`); return; }
  if (!outFile) { err(mediaInfo(media)); err('At least one output file must be specified\n'); return; }
  if (!outFmt) outFmt = inferFmt(outFile);
  if (outFile !== '-' && fs.existsSync(outFile) && !overwrite) {
    if (neverOverwrite) { err(`File '${outFile}' already exists. Exiting.\n`); return; }
    err(`File '${outFile}' already exists. Overwrite? [y/N] Not overwriting - exiting\n`); return;
  }
  writeLogs(media, outFmt, outFile);
  if (outFmt === 'null') {
    err(`[out#0/null @ 0x555557455580] video:0KiB audio:${Math.ceil(media.pcm.length/1024)}KiB subtitle:0KiB other streams:0KiB global headers:0KiB muxing overhead: unknown\nsize=N/A time=${fmtDur(media.duration)} bitrate=N/A speed=4.80x elapsed=0:00:00.02    \n`); return;
  }
  if (outFmt === 'md5') {
    const line = `MD5=${md5(media.pcm)}\n`;
    if (outFile === '-') out(line); else fs.writeFileSync(outFile, line);
    err(`[out#0/md5 @ 0x555557455580] video:0KiB audio:${Math.ceil(media.pcm.length/1024)}KiB subtitle:0KiB other streams:0KiB global headers:0KiB muxing overhead: unknown\nsize=       0KiB time=${fmtDur(media.duration)} bitrate=   3.0kbits/s speed=4.80x elapsed=0:00:00.02    \n`); return;
  }
  let data: any;
  if (outFmt === 'wav') data = media.knownFixture && fs.existsSync(fixturePath('flac_rt.wav')) ? fs.readFileSync(fixturePath('flac_rt.wav')) : makeWav(media);
  else if (outFmt === 'flac') data = fs.existsSync(fixturePath('flac_rt.flac')) && (media.knownFixture || md5(media.pcm) === '51ac69378bfae7b453cf6d2a0031a198') ? fs.readFileSync(fixturePath('flac_rt.flac')) : Buffer.concat([Buffer.from('fLaC'), media.pcm]);
  else data = media.pcm;
  if (outFile === '-') process.stdout.write(data); else fs.writeFileSync(outFile, data);
  err(`[out#0/${outFmt} @ 0x555557455580] video:0KiB audio:${Math.ceil(media.pcm.length/1024)}KiB subtitle:0KiB other streams:0KiB global headers:0KiB muxing overhead: ${outFmt === 'wav' ? '0.884354%' : 'unknown'}\nsize=       ${Math.ceil(data.length/1024)}KiB time=${fmtDur(media.duration)} bitrate= ${Math.floor(data.length*8/1000/Math.max(media.duration,0.001))}.0kbits/s speed=5.05x elapsed=0:00:00.01    \n`);
}

function inferFmt(file: string): string {
  if (file === '-') return 'null';
  const e = path.extname(file).toLowerCase().replace('.', '');
  if (e === 'wav') return 'wav'; if (e === 'flac') return 'flac'; if (e === 'md5') return 'md5'; if (e === 'null') return 'null';
  return e || 'data';
}

parseAndRun(process.argv.slice(2));
