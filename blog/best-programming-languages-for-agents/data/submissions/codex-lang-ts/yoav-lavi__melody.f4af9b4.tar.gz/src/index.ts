declare const require: any;
declare const process: any;
const fs = require("fs");

type NodePart = { regex: string; atom: boolean };

class MelodyError extends Error {
  constructor(message: string, public pos = 0) {
    super(message);
  }
}

class Parser {
  private pos = 0;
  private vars = new Map<string, string>();

  constructor(private src: string) {}

  parse(): string {
    const out = this.parseSequence(undefined);
    this.skip();
    if (!this.eof()) this.fail("expected EOI");
    return out;
  }

  private parseSequence(end: string | undefined): string {
    let out = "";
    while (true) {
      this.skip();
      if (this.eof()) {
        if (end) this.fail(`expected ${end}`);
        break;
      }
      if (end && this.peek() === end) {
        this.pos++;
        break;
      }
      if (this.peek() === ";") {
        this.pos++;
        continue;
      }
      out += this.parseStatement().regex;
      this.skip();
      if (this.peek() === ";") this.pos++;
    }
    return out;
  }

  private parseStatement(): NodePart {
    this.skip();
    const save = this.pos;
    const decl = this.tryVariableDeclaration();
    if (decl) return decl;
    this.pos = save;
    return this.parseQuantifiedOrAtom();
  }

  private parseQuantifiedOrAtom(): NodePart {
    this.skip();
    const start = this.pos;
    let suffix: string | null = null;
    const word = this.readWord();
    if (word === "some") suffix = "+";
    else if (word === "any") suffix = "*";
    else if (word === "option") suffix = "?";
    else if (word === "over") {
      this.skip();
      const n = this.readNumber();
      if (n == null) this.fail("expected amount");
      suffix = `{${n + 1},}`;
    } else if (word && /^\d+$/.test(word)) {
      const n = Number(word);
      this.skip();
      if (this.matchWord("to")) {
        this.skip();
        const m = this.readNumber();
        if (m == null) this.fail("expected amount");
        suffix = `{${n},${m}}`;
      } else {
        suffix = `{${n}}`;
      }
    } else {
      this.pos = start;
    }
    if (suffix !== null) {
      this.skip();
      if (!this.matchWord("of")) this.fail("expected of");
      const atom = this.parseAtom();
      return { regex: this.asQuantifiable(atom) + suffix, atom: true };
    }
    return this.parseAtom();
  }

  private parseAtom(): NodePart {
    this.skip();
    if (this.peek() === "\"") return this.parseLiteral();
    if (this.peek() === "`") return this.parseRaw();
    if (this.peek() === "<") return this.parseSymbol(false);
    if (this.matchWord("not")) {
      this.skip();
      if (this.matchWord("ahead")) return { regex: `(?!${this.parseBlockAlternation(false)})`, atom: true };
      if (this.matchWord("behind")) return { regex: `(?<!${this.parseBlockAlternation(false)})`, atom: true };
      if (this.peek() === "<") return this.parseSymbol(true);
      this.fail("expected amount, class_content, or assertion_type");
    }
    if (this.matchWord("match")) return { regex: `(?:${this.parseBlockAlternation(false)})`, atom: true };
    if (this.matchWord("either")) return { regex: `(?:${this.parseBlockAlternation(true)})`, atom: true };
    if (this.matchWord("capture")) {
      this.skip();
      const save = this.pos;
      const name = this.readIdentifier();
      this.skip();
      if (this.peek() !== "{") {
        this.pos = save;
        return { regex: `(${this.parseBlockAlternation(false)})`, atom: true };
      }
      return { regex: `(?<${name}>${this.parseBlockAlternation(false)})`, atom: true };
    }
    if (this.matchWord("ahead")) return { regex: `(?=${this.parseBlockAlternation(false)})`, atom: true };
    if (this.matchWord("behind")) return { regex: `(?<=${this.parseBlockAlternation(false)})`, atom: true };
    const ident = this.tryVariableInvocation();
    if (ident != null) return { regex: ident, atom: false };
    this.fail("expected root");
  }

  private tryVariableDeclaration(): NodePart | null {
    if (this.peek() !== "@") return null;
    this.pos++;
    const name = this.readIdentifier();
    if (!name) return null;
    this.skip();
    if (this.peek() !== "=") return null;
    this.pos++;
    const value = this.parseQuantifiedOrAtom().regex;
    this.vars.set(name, value);
    return { regex: "", atom: true };
  }

  private tryVariableInvocation(): string | null {
    if (this.peek() !== "@") return null;
    this.pos++;
    const name = this.readIdentifier();
    if (!name) this.fail("expected variable identifier");
    if (!this.vars.has(name)) throw new MelodyError(`undefined variable '${name}'`, this.pos);
    return this.vars.get(name)!;
  }

  private parseBlockAlternation(alternate: boolean): string {
    this.skip();
    if (this.peek() !== "{") this.fail("expected {");
    this.pos++;
    if (!alternate) return this.parseSequence("}");
    const parts: string[] = [];
    while (true) {
      this.skip();
      if (this.eof()) this.fail("expected }");
      if (this.peek() === "}") {
        this.pos++;
        break;
      }
      if (this.peek() === ";") {
        this.pos++;
        continue;
      }
      parts.push(this.parseStatement().regex);
      this.skip();
      if (this.peek() === ";") this.pos++;
    }
    return parts.join("|");
  }

  private parseLiteral(): NodePart {
    const s = this.readQuoted("\"");
    return { regex: escapeRegex(s), atom: s.length <= 1 };
  }

  private parseRaw(): NodePart {
    const s = this.readQuoted("`", false);
    return { regex: s, atom: s.length <= 1 || isRegexAtom(s) };
  }

  private parseSymbol(negative: boolean): NodePart {
    this.expect("<");
    const name = this.readUntil(">");
    this.expect(">");
    const map: Record<string, [string, string | null]> = {
      char: [".", null],
      space: [" ", "[^ ]"],
      whitespace: ["\\s", "\\S"],
      digit: ["\\d", "\\D"],
      word: ["\\w", "\\W"],
      start: ["^", null],
      end: ["$", null],
      boundary: ["\\b", "\\B"],
      newline: ["\\n", "[^\\n]"],
      tab: ["\\t", "[^\\t]"],
      return: ["\\r", "[^\\r]"],
      null: ["\\0", "[^\\0]"],
      vertical: ["\\v", "[^\\v]"],
      feed: ["\\f", "[^\\f]"]
    };
    const ent = map[name.trim()];
    if (!ent) throw new MelodyError("usage of an unrecognized symbol", this.pos);
    if (negative) {
      if (ent[1] == null) throw new MelodyError(`negative ${name.trim()} not allowed`, this.pos);
      return { regex: ent[1], atom: true };
    }
    return { regex: ent[0], atom: true };
  }

  private readQuoted(q: string, escapes = true): string {
    this.expect(q);
    let out = "";
    while (!this.eof()) {
      const ch = this.src[this.pos++];
      if (ch === q) return out;
      if (escapes && ch === "\\") {
        if (this.eof()) return out + "\\";
        const n = this.src[this.pos++];
        const table: Record<string, string> = { n: "\n", t: "\t", r: "\r", f: "\f", v: "\v", "0": "\0" };
        out += table[n] ?? n;
      } else {
        out += ch;
      }
    }
    this.fail("expected root");
  }

  private asQuantifiable(n: NodePart): string {
    if (n.atom || isRegexAtom(n.regex)) return n.regex;
    return `(?:${n.regex})`;
  }

  private skip(): void {
    while (!this.eof()) {
      if (/\s/.test(this.peek())) {
        this.pos++;
        continue;
      }
      if (this.src.startsWith("//", this.pos)) {
        this.pos += 2;
        while (!this.eof() && this.peek() !== "\n") this.pos++;
        continue;
      }
      if (this.src.startsWith("/*", this.pos)) {
        this.pos += 2;
        const end = this.src.indexOf("*/", this.pos);
        this.pos = end >= 0 ? end + 2 : this.src.length;
        continue;
      }
      break;
    }
  }

  private readWord(): string | null {
    this.skip();
    const m = /^[A-Za-z_][A-Za-z0-9_-]*|\d+/.exec(this.src.slice(this.pos));
    if (!m) return null;
    this.pos += m[0].length;
    return m[0];
  }

  private readIdentifier(): string {
    this.skip();
    const m = /^[A-Za-z_][A-Za-z0-9_]*/.exec(this.src.slice(this.pos));
    if (!m) return "";
    this.pos += m[0].length;
    return m[0];
  }

  private readNumber(): number | null {
    const w = this.readWord();
    return w && /^\d+$/.test(w) ? Number(w) : null;
  }

  private matchWord(w: string): boolean {
    this.skip();
    if (this.src.slice(this.pos, this.pos + w.length) !== w) return false;
    const beforeOk = this.pos === 0 || !/[A-Za-z0-9_-]/.test(this.src[this.pos - 1]);
    const after = this.src[this.pos + w.length] ?? "";
    if (!beforeOk || /[A-Za-z0-9_-]/.test(after)) return false;
    this.pos += w.length;
    return true;
  }

  private readUntil(ch: string): string {
    const i = this.src.indexOf(ch, this.pos);
    if (i < 0) this.fail(`expected ${ch}`);
    const s = this.src.slice(this.pos, i);
    this.pos = i;
    return s;
  }

  private expect(ch: string): void {
    if (this.peek() !== ch) this.fail(`expected ${ch}`);
    this.pos++;
  }

  private fail(msg: string): never {
    throw new MelodyError(msg, this.pos);
  }

  private peek(): string {
    return this.src[this.pos] ?? "";
  }

  private eof(): boolean {
    return this.pos >= this.src.length;
  }
}

function escapeRegex(s: string): string {
  return s.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/\n/g, "\\n").replace(/\t/g, "\\t").replace(/\r/g, "\\r").replace(/\f/g, "\\f").replace(/\v/g, "\\v").replace(/\0/g, "\\0");
}

function isRegexAtom(s: string): boolean {
  return s.length === 1 || /^\\[dDsSwWbB0ntrfv]$/.test(s) || /^\[\^?.+\]$/.test(s) || /^\(\?[:=!<]/.test(s) || /^\(.+\)$/.test(s);
}

function compile(src: string): string {
  return new Parser(src).parse();
}

function help(): string {
  return `A CLI wrapping the Melody language compiler

Usage: executable [OPTIONS] [INPUT_FILE_PATH]

Arguments:
  [INPUT_FILE_PATH]  Read from a file
                     Use '-' and or pipe input to read from stdin

Options:
  -o, --output <OUTPUT_FILE_PATH>           Write to a file
  -n, --no-color                            Print output with no color
  -r, --repl                                Start the Melody REPL
      --generate-completions <completions>  Outputs completions for the selected shell
                                            To use, write the output to the appropriate location for your shell
  -t, --test <test>                         Test the compiled regex against a string
  -f, --test-file <test-file>               Test the compiled regex against the contents of a file
  -h, --help                                Print help
  -V, --version                             Print version`;
}

function parseArgs(argv: string[]) {
  const opts: any = { input: null, output: null, test: null, testFile: null, completions: null, repl: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const need = () => {
      if (i + 1 >= argv.length) die(`error: a value is required for '${a}'`, 2);
      return argv[++i];
    };
    if (a === "-h" || a === "--help") { console.log(help()); process.exit(0); }
    else if (a === "-V" || a === "--version") { console.log("melody_cli 0.20.0"); process.exit(0); }
    else if (a === "-n" || a === "--no-color") {}
    else if (a === "-r" || a === "--repl") opts.repl = true;
    else if (a === "-o" || a === "--output") opts.output = need();
    else if (a === "-t" || a === "--test") opts.test = need();
    else if (a === "-f" || a === "--test-file") opts.testFile = need();
    else if (a === "--generate-completions") opts.completions = need();
    else if (a === "-" && opts.input == null) opts.input = a;
    else if (a.startsWith("-")) die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [INPUT_FILE_PATH]\n\nFor more information, try '--help'.`, 2);
    else if (opts.input == null) opts.input = a;
    else die(`error: unexpected argument '${a}' found`, 2);
  }
  return opts;
}

function readInput(path: string | null): string {
  try {
    if (path && path !== "-") return fs.readFileSync(path, "utf8");
    return fs.readFileSync(0, "utf8");
  } catch {
    console.error(`Error: unable read file at path ${path}`);
    process.exit(65);
    throw new Error("unreachable");
  }
}

function die(msg: string, code: number): never {
  console.error(msg);
  process.exit(code);
  throw new Error("unreachable");
}

function main(): void {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.completions) {
    console.log(`# completions for ${opts.completions}`);
    return;
  }
  if (opts.repl) {
    console.log("Melody REPL is not available in this build.");
    return;
  }
  const src = readInput(opts.input);
  let regex: string;
  try {
    regex = compile(src);
  } catch (e: any) {
    console.error(`Error: ${e.message || e}`);
    process.exit(65);
    throw new Error("unreachable");
  }
  if (opts.output) {
    fs.writeFileSync(opts.output, regex);
  } else if (opts.test != null || opts.testFile != null) {
    const target = opts.testFile ? fs.readFileSync(opts.testFile, "utf8") : opts.test;
    const label = opts.testFile ?? `'${opts.test}'`;
    const matched = new RegExp(regex).test(target);
    console.log(`${label} ${matched ? "matched" : "did not match"}`);
  } else {
    console.log(regex);
  }
}

main();
