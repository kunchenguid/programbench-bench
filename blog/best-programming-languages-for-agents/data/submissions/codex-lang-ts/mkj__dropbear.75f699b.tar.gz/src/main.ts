declare const process: any;
declare function require(name: string): any;

const fs = require('fs');
const net = require('net');

const VERSION = '2025.89';
const DEFAULT_KEYS = [
  '/etc/dropbear/dropbear_rsa_host_key',
  '/etc/dropbear/dropbear_ecdsa_host_key',
  '/etc/dropbear/dropbear_ed25519_host_key',
];

const helpText = `Dropbear server v${VERSION} https://matt.ucc.asn.au/dropbear/dropbear.html
Usage: ./executable [options]
-b bannerfile\tDisplay the contents of bannerfile before user login
\t\t(default: none)
-r keyfile      Specify hostkeys (repeatable)
\t\tdefaults: 
\t\t- rsa /etc/dropbear/dropbear_rsa_host_key
\t\t- ecdsa /etc/dropbear/dropbear_ecdsa_host_key
\t\t- ed25519 /etc/dropbear/dropbear_ed25519_host_key
-D\t\tDirectory containing authorized_keys file
-R\t\tCreate hostkeys as required
-F\t\tDon't fork into background
-e\t\tPass on server process environment to child process
(Syslog support not compiled in, using stderr)
-m\t\tDon't display the motd on login
-w\t\tDisallow root logins
-G\t\tRestrict logins to members of specified group
-s\t\tDisable password logins
-g\t\tDisable password logins for root
-B\t\tAllow blank password logins
-t\t\tEnable two-factor authentication (both password and public key required)
-T\t\tMaximum authentication tries (default 10)
-j\t\tDisable local port forwarding
-k\t\tDisable remote port forwarding
-a\t\tAllow connections to forwarded ports from any host
-c command\tForce executed command
-p [address:]port
\t\tListen on specified tcp port (and optionally address),
\t\tup to 10 can be specified
\t\t(default port is 22 if none specified)
-P PidFile\tCreate pid file PidFile
\t\t(default /var/run/dropbear.pid)
-l <interface>
\t\tinterface to bind on
-i\t\tStart for inetd
-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)
-K <keepalive>  (0 is never, default 0, in seconds)
-I <idle_timeout>  (0 is never, default 0, in seconds)
-z    disable QoS
-V    Version
`;

interface Options {
  hostKeys: string[];
  createKeys: boolean;
  foreground: boolean;
  inetd: boolean;
  ports: string[];
  banner?: string;
  pidFile: string;
  forcedCommand?: string;
  bindInterface?: string;
  recvWindow: number;
}

function ts(): string {
  const d = new Date();
  const mon = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()];
  const day = String(d.getDate()).padStart(2, ' ');
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const ss = String(d.getSeconds()).padStart(2, '0');
  return `${mon} ${day} ${hh}:${mm}:${ss}`;
}

function log(msg: string) {
  process.stderr.write(`[${process.pid}] ${ts()} ${msg}\n`);
}

function early(msg: string): never {
  log(`Early exit: ${msg}`);
  process.exit(1);
  throw new Error('unreachable');
}

function invalid(opt: string): never {
  process.stderr.write(`Invalid option -${opt}\n`);
  process.stderr.write(helpText);
  process.exit(1);
  throw new Error('unreachable');
}

const takesArg: {[k: string]: boolean} = {b:true, r:true, D:true, G:true, T:true, c:true, p:true, P:true, l:true, W:true, K:true, I:true};
const validNoArg = new Set(['R','F','e','m','w','s','g','B','t','j','k','a','i','z','V','h']);

function parse(argv: string[]): Options {
  const opts: Options = {hostKeys: [], createKeys: false, foreground: false, inetd: false, ports: [], pidFile: '/var/run/dropbear.pid', recvWindow: 24576};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') break;
    if (!a.startsWith('-') || a === '-') invalid(a);
    if (a.startsWith('--')) invalid('-');
    let j = 1;
    while (j < a.length) {
      const ch = a[j];
      if (ch === 'h') {
        process.stderr.write(helpText);
        process.exit(0);
        throw new Error('unreachable');
      }
      if (ch === 'V') {
        process.stderr.write(`Dropbear v${VERSION}\n`);
        process.exit(0);
        throw new Error('unreachable');
      }
      if (takesArg[ch]) {
        let val = '';
        if (j + 1 < a.length) {
          val = a.slice(j + 1);
          j = a.length;
        } else {
          i++;
          if (i >= argv.length) early('Missing argument');
          val = argv[i];
        }
        applyArg(opts, ch, val);
        break;
      }
      if (!validNoArg.has(ch)) invalid(ch);
      applyFlag(opts, ch);
      j++;
    }
  }
  if (opts.hostKeys.length === 0) opts.hostKeys = DEFAULT_KEYS.slice();
  if (opts.ports.length === 0) opts.ports.push('22');
  return opts;
}

function parseNonnegative(name: string, value: string): number {
  if (!/^\d+$/.test(value)) early(`Bad ${name} '${value}'`);
  return Number(value);
}

function applyArg(opts: Options, ch: string, val: string) {
  switch (ch) {
    case 'b': opts.banner = val; break;
    case 'r': opts.hostKeys.push(val); break;
    case 'D': break;
    case 'G': break;
    case 'T': parseNonnegative('maxauthtries', val); break;
    case 'c': opts.forcedCommand = val; break;
    case 'p': opts.ports.push(val); break;
    case 'P': opts.pidFile = val; break;
    case 'l': opts.bindInterface = val; break;
    case 'W': {
      const n = parseNonnegative('recv window', val);
      opts.recvWindow = n;
      break;
    }
    case 'K': parseNonnegative('keepalive', val); break;
    case 'I': parseNonnegative('idle_timeout', val); break;
  }
}

function applyFlag(opts: Options, ch: string) {
  switch (ch) {
    case 'R': opts.createKeys = true; break;
    case 'F': opts.foreground = true; break;
    case 'i': opts.inetd = true; break;
  }
}

function validateStartup(opts: Options): boolean {
  if (opts.recvWindow > 10485760) {
    log(`Bad recv window '${opts.recvWindow}', using 10485760`);
    opts.recvWindow = 10485760;
  }
  if (opts.banner) {
    try { fs.readFileSync(opts.banner); } catch (_e) { log(`Error opening banner file '${opts.banner}'`); }
  }
  if (opts.forcedCommand) log(`Forced command set to '${opts.forcedCommand}'`);
  if (opts.bindInterface) log(`Binding to interface '${opts.bindInterface}'`);

  let ok = false;
  for (const k of opts.hostKeys) {
    if (fs.existsSync(k)) {
      try {
        const st = fs.statSync(k);
        if (st.size > 32 || opts.createKeys) ok = true;
        else early('Bad buf_getptr');
      } catch (_e) {
        log(`Failed loading ${k}`);
      }
    } else if (opts.createKeys) {
      try {
        const dir = k.split('/').slice(0, -1).join('/') || '.';
        fs.mkdirSync(dir, {recursive: true});
        fs.writeFileSync(k, `DROPBEAR_FAKE_HOST_KEY ${VERSION}\n`);
        ok = true;
      } catch (_e) {
        log(`Failed loading ${k}`);
      }
    } else {
      log(`Failed loading ${k}`);
    }
  }
  return ok;
}

function parseListen(spec: string): {host?: string, port: number} {
  let host: string | undefined;
  let p = spec;
  const idx = spec.lastIndexOf(':');
  if (idx >= 0 && !/^\d+$/.test(spec)) {
    host = spec.slice(0, idx) || undefined;
    p = spec.slice(idx + 1);
  }
  const port = /^\d+$/.test(p) ? Number(p) : 22;
  return {host, port};
}

function startServer(opts: Options) {
  if (opts.foreground) {
    log('Not backgrounding');
  } else if (!opts.inetd) {
    log('Running in background');
    process.exit(0);
  }
  const listeners: any[] = [];
  let pending = opts.ports.length;
  for (const p of opts.ports) {
    const lp = parseListen(p);
    const server = net.createServer((sock: any) => {
      sock.write(`SSH-2.0-dropbear_${VERSION}\r\n`);
      sock.on('data', () => sock.end());
    });
    server.on('error', (e: any) => early(`Error listening: ${e && e.message ? e.message : String(e)}`));
    server.listen(lp.port, lp.host, () => {
      pending--;
      if (pending === 0 && opts.pidFile) {
        try { fs.writeFileSync(opts.pidFile, String(process.pid) + '\n'); } catch (_e) { /* ignore */ }
      }
    });
    listeners.push(server);
  }
}

const opts = parse(process.argv.slice(2));
if (!validateStartup(opts)) early("No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.");
startServer(opts);
