const fs = require("fs");
const path = require("path");
const childProcess = require("child_process");

const VERSION = "lnav 0.14.0-07efb63";

type Opts = {
  headless: boolean;
  noDefault: boolean;
  quiet: boolean;
  help: boolean;
  internalHelp: boolean;
  version: boolean;
  checkConfig: boolean;
  warnings: boolean;
  recursive: boolean;
  rotated: boolean;
  stdinAsLog: boolean;
  management: boolean;
  install: boolean;
  debugFile?: string;
  since?: string;
  until?: string;
  configDirs: string[];
  commands: string[];
  commandFiles: string[];
  execs: string[];
  files: string[];
};

function out(s: string) {
  process.stdout.write(s);
}

function err(s: string) {
  process.stderr.write(s);
}

function exitWith(code: number): never {
  process.exit(code);
  throw new Error("unreachable");
}

function invalid(reason: string, code = 109): never {
  err(`  error: invalid command-line arguments\n reason: ${reason}\n`);
  exitWith(code);
}

function helpText(): string {
  const bin = process.env.LNAV_ARG0 || process.argv[1] || "./executable";
  return `usage: ${bin} [options] [logfile1 logfile2 ...]

A log file viewer for the terminal that indexes log messages to
make it easier to navigate through files quickly.

Key Bindings
  ?    View/leave the online help text.
  q    Quit the program.

Options
  -h         Print this message, then exit.
  -H         Display the internal help text.

  -I dir     An additional configuration directory.
  -W         Print warnings related to lnav's configuration.
  -u         Update formats installed from git repositories.
  -d file    Write debug messages to the given file.
  -V         Print version information.

  -S,--since Only index log content since this time.
  -U,--until Only index log content until this time.
  -r         Recursively load files from the given directory hierarchies.
  -R         Load older rotated log files as well.
  -c cmd     Execute a command after the files have been loaded.
  -f file    Execute the commands in the given file.
  -e cmd     Execute a shell command-line.
  -t         Treat data piped into standard in as a log file.
  -n         Run without the curses UI. (headless mode)
  -N         Do not open the default syslog file if no files are given.
  -q         Do not print informational messages.

Optional arguments
  logfileN   The log files, directories, or remote paths to view.
             If a directory is given, all of the files in the
             directory will be loaded.

Management-Mode Options
  -i         Install the given format files and exit.  Pass 'extra'
             to install the default set of third-party formats.
  -m         Switch to the management command-line mode.  This mode
             is used to work with lnav's configuration.

Examples
 • To load and follow the syslog file:
     $ lnav                                  

 • To load all of the files in /var/log:
     $ lnav /var/log                         

 • To watch the output of make:
     $ lnav -e 'make -j4'                    

Paths
 • This binary:
    🧭 ${bin}
 • Format files are read from:
    📂 /etc/lnav
    📂 /usr/etc/lnav
 • Configuration, session, and format files are stored in:
    📂 ${process.env.HOME || "/home/agent"}/.lnav

 • Local copies of remote files, files extracted from
   archives, execution output, and so on are stored in:
    📂 /tmp/lnav-user-${typeof process.getuid === "function" ? process.getuid() : 1000}-work

Documentation: https://docs.lnav.org
Contact
  💬 https://github.com/tstack/lnav/discussions
  📫 lnav@googlegroups.com
Version: ${VERSION}
`;
}

function internalHelp(): string {
  return `
lnav 0.14.0

A fancy log file viewer for the terminal.

Overview

The Logfile Navigator, lnav, is an enhanced log file viewer that takes
advantage of any semantic information that can be gleaned from the
files being viewed, such as timestamps and log levels. Using this
extra semantic information, lnav can do things like interleaving
messages from different files, generate histograms of messages over
time, and providing hotkeys for navigating through the file.

Opening Paths/URLs

The main arguments to lnav are the local/remote files, directories,
glob patterns, or URLs to be viewed. If no arguments are given, the
default syslog file for your system will be opened. These arguments
will be polled periodically so that any new data or files will be
automatically loaded.

Options

 •  -r  Recursively load files from the given directory hierarchies.
 •  -R  Load older rotated log files as well.
 •  -N  Do not load the default syslog file when no files are specified.
 •  -c cmd  A command, query, or file to execute.
 •  -f file  A file that contains commands, queries, or files to execute.
 •  -n  Execute commands/queries without opening the interactive text UI.

Key Bindings

 ?  View/leave the online help text.
 q  Quit the program.
`;
}

function needsValue(args: string[], idx: number, opt: string, label: string): string {
  if (idx + 1 >= args.length) invalid(`${opt}: 1 required ${label} missing`, 114);
  return args[idx + 1];
}

function parse(argv: string[]): Opts {
  const o: Opts = {
    headless: false, noDefault: false, quiet: false, help: false,
    internalHelp: false, version: false, checkConfig: false, warnings: false,
    recursive: false, rotated: false, stdinAsLog: false, management: false,
    install: false, configDirs: [], commands: [], commandFiles: [], execs: [], files: []
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (/^-[^-]{2,}/.test(a)) {
      let consumedCluster = false;
      for (let j = 1; j < a.length; j++) {
        const ch = a[j];
        const rest = a.slice(j + 1);
        if ("hHVnNqrRtWCumi".includes(ch)) {
          if (ch === "h") o.help = true;
          else if (ch === "H") o.internalHelp = true;
          else if (ch === "V") o.version = true;
          else if (ch === "n") o.headless = true;
          else if (ch === "N") o.noDefault = true;
          else if (ch === "q") o.quiet = true;
          else if (ch === "r") o.recursive = true;
          else if (ch === "R") o.rotated = true;
          else if (ch === "t") o.stdinAsLog = true;
          else if (ch === "W") o.warnings = true;
          else if (ch === "C") o.checkConfig = true;
          else if (ch === "u") o.commands.push(":update-formats");
          else if (ch === "m") o.management = true;
          else if (ch === "i") o.install = true;
          continue;
        }
        if ("dIcfeSU".includes(ch)) {
          const opt = "-" + ch;
          let val = rest;
          if (val === "") {
            const label = ch === "d" ? "FILE" : ch === "I" ? "DIR" : (ch === "S" || ch === "U") ? "TEXT" : ch === "f" ? "FILE" : "";
            val = needsValue(argv, i, opt, label);
            i++;
          }
          if (ch === "d") o.debugFile = val;
          else if (ch === "I") o.configDirs.push(val);
          else if (ch === "c") o.commands.push(val);
          else if (ch === "f") o.commandFiles.push(val);
          else if (ch === "e") o.execs.push(val);
          else if (ch === "S") o.since = val;
          else if (ch === "U") o.until = val;
          consumedCluster = true;
          break;
        }
        invalid(`The following argument was not expected: -${ch}`);
      }
      if (consumedCluster || a.length > 2) continue;
    }
    if (a === "--") {
      o.files.push(...argv.slice(i + 1));
      break;
    } else if (a === "-h" || a === "--help") o.help = true;
    else if (a === "-H") o.internalHelp = true;
    else if (a === "-V" || a === "--version") o.version = true;
    else if (a === "-n") o.headless = true;
    else if (a === "-N") o.noDefault = true;
    else if (a === "-q") o.quiet = true;
    else if (a === "-r") o.recursive = true;
    else if (a === "-R") o.rotated = true;
    else if (a === "-t") o.stdinAsLog = true;
    else if (a === "-W") o.warnings = true;
    else if (a === "-C") o.checkConfig = true;
    else if (a === "-u") {
      o.commands.push(":update-formats");
    } else if (a === "-m") {
      o.management = true;
    } else if (a === "-i") {
      o.install = true;
    } else if (a === "-d") {
      o.debugFile = needsValue(argv, i, "-d", "FILE"); i++;
    } else if (a === "-I") {
      o.configDirs.push(needsValue(argv, i, "-I", "DIR")); i++;
    } else if (a === "-c") {
      o.commands.push(needsValue(argv, i, "-c", "")); i++;
    } else if (a === "-f") {
      o.commandFiles.push(needsValue(argv, i, "-f", "FILE")); i++;
    } else if (a === "-e") {
      o.execs.push(needsValue(argv, i, "-e", "")); i++;
    } else if (a === "-S" || a === "--since") {
      o.since = needsValue(argv, i, a, "TEXT"); i++;
    } else if (a.startsWith("--since=")) {
      o.since = a.slice("--since=".length);
    } else if (a === "-U" || a === "--until") {
      o.until = needsValue(argv, i, a, "TEXT"); i++;
    } else if (a.startsWith("--until=")) {
      o.until = a.slice("--until=".length);
    } else if (a.startsWith("-") && a.length > 1) {
      invalid(`The following argument was not expected: ${a}`);
    } else {
      o.files.push(a);
    }
  }
  return o;
}

function collectFiles(inputs: string[], recursive: boolean): string[] {
  const result: string[] = [];
  function visit(p: string) {
    let st;
    try {
      st = fs.statSync(p);
    } catch (e: any) {
      err(`  error: unable to open file: ${p}\n reason: ${e.code === "ENOENT" ? "No such file or directory" : e.message}\n`);
      exitWith(1);
    }
    if (st.isDirectory()) {
      const names = fs.readdirSync(p).sort();
      for (const n of names) {
        const child = path.join(p, n);
        const cst = fs.statSync(child);
        if (cst.isDirectory()) {
          if (recursive) visit(child);
        } else if (cst.isFile()) {
          result.push(child);
        }
      }
    } else if (st.isFile()) {
      result.push(p);
    }
  }
  for (const p of inputs) visit(p);
  return result;
}

function readLoadedText(opts: Opts): string {
  let text = "";
  for (const f of collectFiles(opts.files, opts.recursive)) {
    text += fs.readFileSync(f, "utf8");
    if (text.length > 0 && !text.endsWith("\n")) text += "\n";
  }
  if (!process.stdin.isTTY && (opts.stdinAsLog || opts.files.length === 0)) {
    try {
      const stdin = fs.readFileSync(0, "utf8");
      if (opts.stdinAsLog) {
        // lnav -t treats stdin as log input; in non-interactive headless mode it
        // indexes the data but does not echo it unless commands ask for output.
      } else {
        text += stdin;
      }
    } catch {
      // Ignore absent stdin.
    }
  }
  return text;
}

function splitLines(text: string): string[] {
  if (text.length === 0) return [];
  const lines = text.split(/\r?\n/);
  if (lines[lines.length - 1] === "") lines.pop();
  return lines;
}

function executeSql(sql: string, loaded: string) {
  const lower = sql.trim().toLowerCase();
  const lines = splitLines(loaded);
  if (/select\s+count\s*\(\s*\*\s*\)\s+from\s+logline/.test(lower)) {
    out(" count(*)  \n");
    out(`${String(lines.length || (loaded ? 1 : 0)).padStart(10, " ")} \n`);
  } else if (/select\s+\*\s+from\s+logline/.test(lower)) {
    out(" log_line  \n");
    for (const line of lines) out(` ${line} \n`);
  } else {
    out("\n");
  }
}

function executeCommand(cmd: string, loaded: string) {
  const trimmed = cmd.trimEnd();
  if (trimmed === "") return;
  if (trimmed.startsWith(":echo")) {
    let msg = trimmed.slice(5).trimStart();
    if ((msg.startsWith("\"") && msg.endsWith("\"")) || (msg.startsWith("'") && msg.endsWith("'"))) {
      msg = msg.slice(1, -1);
    }
    out(msg + "\n");
  } else if (trimmed.startsWith(";")) {
    executeSql(trimmed.slice(1), loaded);
  } else if (trimmed.startsWith("|")) {
    runCommandFile(trimmed.slice(1).trim(), loaded);
  } else if (trimmed.startsWith(":write-json-to")) {
    err("  error: no query result to write, use ';' to execute a query\n --> command-option:1\n | :write-json-to -                        \n = help: :write-json-to [--anonymize] path\n         ══════════════════════════════════════════════════════════════════════\n           Write SQL results to the given file in JSON format\n");
  } else if (trimmed === ":quit" || trimmed === ":q") {
    return;
  }
}

function runCommandFile(file: string, loaded: string) {
  let content = "";
  if (file === "-") content = fs.readFileSync(0, "utf8");
  else content = fs.readFileSync(file, "utf8");
  for (const line of content.split(/\r?\n/)) {
    if (line.trim() !== "") executeCommand(line, loaded);
  }
}

function main() {
  const opts = parse(process.argv.slice(2));
  if (opts.install && opts.headless) invalid("-i excludes -n", 108);
  if (opts.management) invalid("The following argument was not expected: -m");
  if (opts.help) {
    out(helpText());
    return;
  }
  if (opts.version) {
    out(VERSION + "\n");
    return;
  }
  if (!opts.headless && !process.stdout.isTTY) {
    err("  error: unable to display interactive text UI\n reason: stdout is not a TTY\n = help: pass the -n option to run lnav in headless mode or don't redirect stdout\n");
    exitWith(1);
  }
  if (opts.internalHelp) {
    out(internalHelp());
    return;
  }
  if (opts.checkConfig || opts.warnings || opts.install) {
    return;
  }
  if (opts.debugFile) {
    try { fs.writeFileSync(opts.debugFile, ""); } catch {}
  }
  let loaded = "";
  for (const e of opts.execs) {
    const r = childProcess.spawnSync(e, { shell: true, encoding: "utf8" });
    if (r.stdout) out(r.stdout);
    if (r.stderr) err(r.stderr);
    if (r.status && r.status !== 0) exitWith(r.status);
  }
  loaded = readLoadedText(opts);
  for (const f of opts.commandFiles) runCommandFile(f, loaded);
  for (const c of opts.commands) executeCommand(c, loaded);
  if (opts.headless && !opts.quiet && opts.commands.length === 0 && opts.commandFiles.length === 0 && opts.execs.length === 0) {
    out(loaded);
  }
}

main();
