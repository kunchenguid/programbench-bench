declare const process: any;
declare const __dirname: string;
declare function require(name: string): any;
