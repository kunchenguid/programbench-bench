#!/usr/bin/env node
declare const require: any;
declare const process: any;
declare const console: any;
declare const URL: any;
const fs = require("fs");

type Node = ElementNode | TextNode;
interface TextNode { kind: "text"; text: string; parent?: ElementNode; }
interface ElementNode {
  kind: "element";
  tag: string;
  attrs: Map<string, string>;
  children: Node[];
  parent?: ElementNode;
}

const VOID_TAGS = new Set(["area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"]);
const RAW_TAGS = new Set(["script", "style", "textarea", "title"]);

function el(tag: string, attrs: Map<string, string> = new Map()): ElementNode {
  return { kind: "element", tag: tag.toLowerCase(), attrs, children: [] };
}
function add(parent: ElementNode, child: Node) { child.parent = parent; parent.children.push(child); }

function parseAttrs(s: string): Map<string, string> {
  const attrs = new Map<string, string>();
  const re = /([^\s"'=<>\/]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s))) attrs.set(m[1].toLowerCase(), decodeEntities(m[2] ?? m[3] ?? m[4] ?? ""));
  return attrs;
}

function parseFragment(input: string): ElementNode {
  const root = el("#document");
  const stack: ElementNode[] = [root];
  let i = 0;
  while (i < input.length) {
    const parent = stack[stack.length - 1];
    const raw = RAW_TAGS.has(parent.tag);
    const lt = raw ? input.toLowerCase().indexOf(`</${parent.tag}`, i) : input.indexOf("<", i);
    if (lt < 0) { if (i < input.length) add(parent, { kind: "text", text: raw ? input.slice(i) : decodeEntities(input.slice(i)) }); break; }
    if (lt > i) add(parent, { kind: "text", text: raw ? input.slice(i, lt) : decodeEntities(input.slice(i, lt)) });
    i = lt;
    if (input.startsWith("<!--", i)) {
      const end = input.indexOf("-->", i + 4);
      i = end < 0 ? input.length : end + 3;
      continue;
    }
    if (/^<!doctype/i.test(input.slice(i, i + 10)) || input.startsWith("<!", i)) {
      const end = input.indexOf(">", i + 2);
      i = end < 0 ? input.length : end + 1;
      continue;
    }
    const gt = input.indexOf(">", i + 1);
    if (gt < 0) { add(parent, { kind: "text", text: raw ? input.slice(i) : decodeEntities(input.slice(i)) }); break; }
    const inside = input.slice(i + 1, gt);
    i = gt + 1;
    if (/^\s*\//.test(inside)) {
      const tag = inside.replace(/^\s*\//, "").trim().split(/\s+/)[0].toLowerCase();
      for (let j = stack.length - 1; j > 0; j--) {
        if (stack[j].tag === tag) { stack.length = j; break; }
      }
      continue;
    }
    const selfClose = /\/\s*$/.test(inside);
    const clean = inside.replace(/\/\s*$/, "").trim();
    if (!clean) continue;
    const sp = clean.search(/\s/);
    const tag = (sp < 0 ? clean : clean.slice(0, sp)).toLowerCase();
    const attrText = sp < 0 ? "" : clean.slice(sp + 1);
    if (tag === "html" || tag === "head" || tag === "body") {
      const node = el(tag, parseAttrs(attrText));
      add(stack[stack.length - 1], node);
      if (!selfClose) stack.push(node);
    } else {
      if (tag === "p" && stack[stack.length - 1].tag === "p") stack.pop();
      const node = el(tag, parseAttrs(attrText));
      add(stack[stack.length - 1], node);
      if (!selfClose && !VOID_TAGS.has(tag)) stack.push(node);
    }
  }
  return normalizeDocument(root);
}

function normalizeDocument(root: ElementNode): ElementNode {
  const directHtml = root.children.find(n => n.kind === "element" && n.tag === "html") as ElementNode | undefined;
  let html: ElementNode, head: ElementNode, body: ElementNode;
  if (directHtml) {
    html = directHtml;
    head = directHtml.children.find(n => n.kind === "element" && n.tag === "head") as ElementNode;
    body = directHtml.children.find(n => n.kind === "element" && n.tag === "body") as ElementNode;
    if (!head) { head = el("head"); head.parent = directHtml; directHtml.children.unshift(head); }
    if (!body) { body = el("body"); body.parent = directHtml; directHtml.children.push(body); }
  } else {
    html = el("html"); head = el("head"); body = el("body");
    add(root, html); add(html, head); add(html, body);
    const old = root.children.filter(n => n !== html);
    root.children = [html];
    for (const n of old) add(body, n);
  }
  const headTags = new Set(["title", "base", "meta", "link", "style"]);
  for (const n of [...body.children]) {
    if (n.kind === "element" && headTags.has(n.tag)) {
      body.children = body.children.filter(c => c !== n);
      add(head, n);
    }
  }
  normalizeTables(root);
  return root;
}

function normalizeTables(n: ElementNode) {
  for (const c of [...n.children]) if (c.kind === "element") normalizeTables(c);
  if (n.tag !== "table") return;
  const trs = n.children.filter(c => c.kind === "element" && c.tag === "tr") as ElementNode[];
  if (!trs.length) return;
  const tbody = el("tbody");
  const first = n.children.indexOf(trs[0]);
  n.children = n.children.filter(c => !(c.kind === "element" && c.tag === "tr"));
  tbody.parent = n;
  n.children.splice(first, 0, tbody);
  for (const tr of trs) add(tbody, tr);
}

function decodeEntities(s: string): string {
  return s.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos|nbsp);/gi, (_, e) => {
    const x = String(e).toLowerCase();
    if (x === "amp") return "&"; if (x === "lt") return "<"; if (x === "gt") return ">";
    if (x === "quot") return "\""; if (x === "apos") return "'"; if (x === "nbsp") return "\u00a0";
    if (x.startsWith("#x")) return String.fromCodePoint(parseInt(x.slice(2), 16));
    return String.fromCodePoint(parseInt(x.slice(1), 10));
  });
}
function escText(s: string): string { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function escAttr(s: string): string { return escText(s).replace(/"/g, "&quot;"); }

function serialize(n: Node, pretty = false, depth = 0): string {
  if (n.kind === "text") return escText(n.text);
  if (n.tag === "#document") return n.children.map(c => serialize(c, pretty, depth)).join("");
  const attrs = [...n.attrs.entries()].sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => ` ${k}="${escAttr(v)}"`).join("");
  const open = `<${n.tag}${attrs}>`;
  if (VOID_TAGS.has(n.tag)) return open;
  if (!pretty) return open + n.children.map(c => serialize(c, false, depth + 1)).join("") + `</${n.tag}>`;
  if (n.children.length === 0) return open + `</${n.tag}>`;
  const inner = n.children.map(c => serialize(c, true, depth + 1)).join("");
  if (n.children.some(c => c.kind === "element")) return open + inner + "\n" + `</${n.tag}>`;
  return open + inner + `</${n.tag}>`;
}

interface Simple {
  tag?: string; universal?: boolean; id?: string; classes: string[];
  attrs: { name: string; op?: string; value?: string }[];
  pseudos: { name: string; arg?: string }[];
}
interface Step { comb: " " | ">" | "+" | "~" | null; simple: Simple; }

function splitTop(s: string, sep: string): string[] {
  const out: string[] = []; let cur = "", q = "", br = 0, par = 0;
  for (const ch of s) {
    if (q) { cur += ch; if (ch === q) q = ""; continue; }
    if (ch === "\"" || ch === "'") { q = ch; cur += ch; continue; }
    if (ch === "[") br++; else if (ch === "]") br--; else if (ch === "(") par++; else if (ch === ")") par--;
    if (ch === sep && br === 0 && par === 0) { out.push(cur.trim()); cur = ""; } else cur += ch;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function parseSelector(selector: string): Step[][] {
  return splitTop(selector, ",").map(group => {
    const steps: Step[] = []; let i = 0, comb: Step["comb"] = null;
    while (i < group.length) {
      let sawSpace = false;
      while (/\s/.test(group[i] ?? "")) { sawSpace = true; i++; }
      if (sawSpace && steps.length && comb === null) comb = " ";
      if ([">","+","~"].includes(group[i] ?? "")) { comb = group[i] as any; i++; continue; }
      let start = i, q = "", br = 0, par = 0;
      while (i < group.length) {
        const ch = group[i];
        if (q) { if (ch === q) q = ""; i++; continue; }
        if (ch === "\"" || ch === "'") { q = ch; i++; continue; }
        if (ch === "[") br++; else if (ch === "]") br--; else if (ch === "(") par++; else if (ch === ")") par--;
        if (br === 0 && par === 0 && (/\s/.test(ch) || [">","+","~"].includes(ch))) break;
        i++;
      }
      const token = group.slice(start, i).trim();
      if (token) { steps.push({ comb: steps.length ? (comb ?? " ") : null, simple: parseSimple(token) }); comb = null; }
    }
    return steps;
  });
}

function parseSimple(t: string): Simple {
  const s: Simple = { classes: [], attrs: [], pseudos: [] };
  let i = 0;
  const m = /^(\*|[a-zA-Z_][\w-]*)/.exec(t);
  if (m) { if (m[1] === "*") s.universal = true; else s.tag = m[1].toLowerCase(); i = m[0].length; }
  while (i < t.length) {
    const ch = t[i];
    if (ch === "#") { const m2 = /^#([\w-]+)/.exec(t.slice(i)); if (m2) { s.id = m2[1]; i += m2[0].length; continue; } }
    if (ch === ".") { const m2 = /^\.([\w-]+)/.exec(t.slice(i)); if (m2) { s.classes.push(m2[1]); i += m2[0].length; continue; } }
    if (ch === "[") {
      const end = findClose(t, i, "[", "]");
      const body = t.slice(i + 1, end).trim();
      const am = /^([^\s~|^$*!=]+)\s*(?:(~=|\|=|\^=|\$=|\*=|=)\s*(?:"([^"]*)"|'([^']*)'|([^\]]*)))?$/.exec(body);
      if (am) s.attrs.push({ name: am[1].toLowerCase(), op: am[2], value: (am[3] ?? am[4] ?? am[5] ?? "").trim() });
      i = end + 1; continue;
    }
    if (ch === ":") {
      const pm = /^:([\w-]+)/.exec(t.slice(i)); if (!pm) { i++; continue; }
      i += pm[0].length; let arg: string | undefined;
      if (t[i] === "(") { const end = findClose(t, i, "(", ")"); arg = t.slice(i + 1, end).trim(); i = end + 1; }
      s.pseudos.push({ name: pm[1], arg }); continue;
    }
    i++;
  }
  return s;
}
function findClose(s: string, start: number, open: string, close: string): number {
  let depth = 0, q = "";
  for (let i = start; i < s.length; i++) {
    const ch = s[i];
    if (q) { if (ch === q) q = ""; continue; }
    if (ch === "\"" || ch === "'") { q = ch; continue; }
    if (ch === open) depth++; else if (ch === close && --depth === 0) return i;
  }
  return s.length - 1;
}

function allElements(root: ElementNode): ElementNode[] {
  const out: ElementNode[] = [];
  const walk = (n: Node) => { if (n.kind === "element") { if (n.tag !== "#document") out.push(n); n.children.forEach(walk); } };
  walk(root); return out;
}
function elementChildren(e: ElementNode): ElementNode[] { return e.children.filter(n => n.kind === "element") as ElementNode[]; }
function descendants(e: ElementNode): ElementNode[] { const r: ElementNode[] = []; for (const c of elementChildren(e)) { r.push(c, ...descendants(c)); } return r; }

function matchesSimple(e: ElementNode, s: Simple): boolean {
  if (s.tag && e.tag !== s.tag) return false;
  if (s.id && e.attrs.get("id") !== s.id) return false;
  const cls = (e.attrs.get("class") ?? "").split(/\s+/);
  if (s.classes.some(c => !cls.includes(c))) return false;
  for (const a of s.attrs) {
    if (!e.attrs.has(a.name)) return false;
    const v = e.attrs.get(a.name) ?? "", av = a.value ?? "";
    if (a.op === "=" && v !== av) return false;
    if (a.op === "~=" && !v.split(/\s+/).includes(av)) return false;
    if (a.op === "|=" && !(v === av || v.startsWith(av + "-"))) return false;
    if (a.op === "^=" && !v.startsWith(av)) return false;
    if (a.op === "$=" && !v.endsWith(av)) return false;
    if (a.op === "*=" && !v.includes(av)) return false;
  }
  for (const p of s.pseudos) if (!matchesPseudo(e, p)) return false;
  return true;
}

function matchesPseudo(e: ElementNode, p: {name: string; arg?: string}): boolean {
  const sib = e.parent ? elementChildren(e.parent) : [];
  const idx = sib.indexOf(e) + 1;
  switch (p.name) {
    case "first-child": return idx === 1;
    case "last-child": return idx === sib.length;
    case "nth-child": return nth(idx, p.arg ?? "");
    case "not": return !parseSelector(p.arg ?? "").some(g => g.length === 1 && matchesSimple(e, g[0].simple));
    case "empty": return e.children.length === 0;
    case "root": return e.tag === "html";
    default: return false;
  }
}
function nth(i: number, expr: string): boolean {
  const e = expr.replace(/\s+/g, "").toLowerCase();
  if (e === "odd") return i % 2 === 1; if (e === "even") return i % 2 === 0;
  if (/^\d+$/.test(e)) return i === Number(e);
  const m = /^([+-]?\d*)n([+-]\d+)?$/.exec(e); if (!m) return false;
  const a = m[1] === "" || m[1] === "+" ? 1 : m[1] === "-" ? -1 : Number(m[1]);
  const b = m[2] ? Number(m[2]) : 0;
  return a === 0 ? i === b : (i - b) / a >= 0 && (i - b) % a === 0;
}

function select(root: ElementNode, selector: string): ElementNode[] {
  const seen = new Set<ElementNode>(), out: ElementNode[] = [];
  for (const group of parseSelector(selector)) {
    let cur = allElements(root).filter(e => matchesSimple(e, group[0].simple));
    for (let i = 1; i < group.length; i++) {
      const st = group[i], next: ElementNode[] = [];
      for (const e of cur) {
        let cand: ElementNode[] = [];
        if (st.comb === ">") cand = elementChildren(e);
        else if (st.comb === "+") { const s = e.parent ? elementChildren(e.parent) : []; const ix = s.indexOf(e); if (ix >= 0 && ix + 1 < s.length) cand = [s[ix + 1]]; }
        else if (st.comb === "~") { const s = e.parent ? elementChildren(e.parent) : []; const ix = s.indexOf(e); cand = ix >= 0 ? s.slice(ix + 1) : []; }
        else cand = descendants(e);
        next.push(...cand.filter(x => matchesSimple(x, st.simple)));
      }
      cur = next;
    }
    for (const e of cur) if (!seen.has(e)) { seen.add(e); out.push(e); }
  }
  return out;
}

function textNodes(e: ElementNode, ignoreWs: boolean): string[] {
  const out: string[] = [];
  const walk = (n: Node) => {
    if (n.kind === "text") { const t = decodeEntities(n.text); if (!ignoreWs || !/^\s*$/.test(t)) out.push(t); }
    else n.children.forEach(walk);
  };
  e.children.forEach(walk); return out;
}

function removeNode(e: ElementNode) {
  if (!e.parent) return;
  e.parent.children = e.parent.children.filter(c => c !== e);
}
function detectBase(root: ElementNode): string | undefined {
  const base = select(root, "base[href]")[0];
  return base?.attrs.get("href");
}
function resolveUrl(value: string, base?: string): string {
  if (!base) return value;
  try { return new URL(value, base).toString(); } catch { return value; }
}

const HELP = `htmlq 0.4.0
Michael Maclean <michael@mgdm.net>
Runs CSS selectors on HTML

USAGE:
    executable [FLAGS] [OPTIONS] [--] [selector]...

FLAGS:
    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to
                               the value of --base, if supplied
    -h, --help                 Prints help information
    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace
    -p, --pretty               Pretty-print the serialised output
    -t, --text                 Output only the contents of text nodes inside selected elements
    -V, --version              Prints version information

OPTIONS:
    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements
    -b, --base <base>                   Use this URL as the base for links
    -f, --filename <FILE>               The input file. Defaults to stdin
    -o, --output <FILE>                 The output file. Defaults to stdout
    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple
                                        times

ARGS:
    <selector>...    The CSS expression to select [default: html]
`;

function parseArgs(argv: string[]) {
  const opt: any = { selectors: [] as string[], removes: [] as string[] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") { opt.selectors.push(...argv.slice(i + 1)); break; }
    if (a === "-h" || a === "--help") opt.help = true;
    else if (a === "-V" || a === "--version") opt.version = true;
    else if (a === "-t" || a === "--text") opt.text = true;
    else if (a === "-p" || a === "--pretty") opt.pretty = true;
    else if (a === "-w" || a === "--ignore-whitespace") opt.ignoreWhitespace = true;
    else if (a === "-B" || a === "--detect-base") opt.detectBase = true;
    else if (a === "-a" || a === "--attribute") opt.attribute = argv[++i];
    else if (a.startsWith("--attribute=")) opt.attribute = a.slice(12);
    else if (a === "-b" || a === "--base") opt.base = argv[++i];
    else if (a.startsWith("--base=")) opt.base = a.slice(7);
    else if (a === "-f" || a === "--filename") opt.filename = argv[++i];
    else if (a.startsWith("--filename=")) opt.filename = a.slice(11);
    else if (a === "-o" || a === "--output") opt.output = argv[++i];
    else if (a.startsWith("--output=")) opt.output = a.slice(9);
    else if (a === "-r" || a === "--remove-nodes") opt.removes.push(argv[++i]);
    else if (a.startsWith("--remove-nodes=")) opt.removes.push(a.slice(15));
    else if (a.startsWith("-") && a.length > 2 && !a.startsWith("--")) {
      for (const ch of a.slice(1)) {
        if (ch === "t") opt.text = true; else if (ch === "p") opt.pretty = true; else if (ch === "w") opt.ignoreWhitespace = true; else if (ch === "B") opt.detectBase = true;
        else throw new Error(`Found argument '-${ch}' which wasn't expected, or isn't valid in this context`);
      }
    } else if (a.startsWith("-")) throw new Error(`Found argument '${a}' which wasn't expected, or isn't valid in this context`);
    else opt.selectors.push(a);
  }
  return opt;
}

function main() {
  let opt: any;
  try { opt = parseArgs(process.argv.slice(2)); }
  catch (e: any) { console.error(`error: ${e.message}\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [--] [selector]...\n\nFor more information try --help`); process.exit(1); }
  if (opt.help) { process.stdout.write(HELP); return; }
  if (opt.version) { process.stdout.write("htmlq 0.4.0\n"); return; }
  const input = opt.filename ? fs.readFileSync(opt.filename, "utf8") : fs.readFileSync(0, "utf8");
  const doc = parseFragment(input);
  for (const r of opt.removes) for (const n of select(doc, r)) removeNode(n);
  const selector = opt.selectors.length ? opt.selectors.join(" ") : "html";
  const base = opt.detectBase ? (detectBase(doc) ?? opt.base) : opt.base;
  const lines: string[] = [];
  for (const n of select(doc, selector)) {
    if (opt.attribute) {
      if (n.attrs.has(opt.attribute.toLowerCase())) {
        const v = n.attrs.get(opt.attribute.toLowerCase()) ?? "";
        lines.push(opt.attribute.toLowerCase() === "href" ? resolveUrl(v, base) : v);
      }
    } else if (opt.text) {
      const parts = textNodes(n, !!opt.ignoreWhitespace);
      lines.push(opt.ignoreWhitespace && parts.length ? parts.join("\n") + "\n" : parts.join(""));
    } else lines.push(serialize(n, !!opt.pretty));
  }
  const output = lines.length ? lines.join("\n") + "\n" : "";
  if (opt.output) fs.writeFileSync(opt.output, output); else process.stdout.write(output);
}
main();
