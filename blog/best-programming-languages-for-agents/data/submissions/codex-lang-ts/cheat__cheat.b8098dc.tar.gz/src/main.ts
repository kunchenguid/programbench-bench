declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");
const child_process = require("child_process");

type CheatPath = { name: string; path: string; tags: string[]; readonly: boolean };
type Config = {
  file: string;
  editor: string;
  pager: string;
  colorize: boolean;
  cheatpaths: CheatPath[];
};
type Sheet = {
  title: string;
  file: string;
  pathName: string;
  pathIndex: number;
  tags: string[];
  body: string;
  raw: string;
};

const VERSION = "5.1.0";

const HELP = `cheat allows you to create and view interactive cheatsheets on the
command-line. It was designed to help remind *nix system administrators of
options for commands that they use frequently, but not frequently enough to
remember.

Usage:
  cheat [cheatsheet] [flags]

Examples:
  To initialize a config file:
    mkdir -p ~/.config/cheat && cheat --init > ~/.config/cheat/conf.yml

  To view the tar cheatsheet:
    cheat tar

  To edit (or create) the foo cheatsheet:
    cheat -e foo

  To edit (or create) the foo/bar cheatsheet on the "work" cheatpath:
    cheat -p work -e foo/bar

  To view all cheatsheet directories:
    cheat -d

  To list all available cheatsheets:
    cheat -l

  To briefly list all cheatsheets whose titles match "apt":
    cheat -b apt

  To list all tags in use:
    cheat -T

  To list available cheatsheets that are tagged as "personal":
    cheat -l -t personal

  To search for "ssh" among all cheatsheets, and colorize matches:
    cheat -c -s ssh

  To search (by regex) for cheatsheets that contain an IP address:
    cheat -c -r -s '(?:[0-9]{1,3}\\.){3}[0-9]{1,3}'

  To remove (delete) the foo/bar cheatsheet:
    cheat --rm foo/bar

  To update all git-backed cheatpaths:
    cheat --update

  To view the configuration file path:
    cheat --conf

  To generate shell completions (bash, zsh, fish, powershell):
    cheat --completion bash

Flags:
  -a, --all                Search among all cheatpaths
  -b, --brief              List cheatsheets without file paths
  -c, --colorize           Colorize output
      --completion shell   Generate shell completion script (shell: bash, zsh, fish, powershell)
      --conf               Display the config file path
  -d, --directories        List cheatsheet directories
  -e, --edit cheatsheet    Edit cheatsheet
  -h, --help               help for cheat
      --init               Write a default config file to stdout
  -l, --list               List cheatsheets
  -p, --path name          Return only sheets found on cheatpath name
  -r, --regex              Treat search <phrase> as a regex
      --rm cheatsheet      Remove (delete) cheatsheet
  -s, --search phrase      Search cheatsheets for phrase
  -t, --tag tag            Return only sheets matching tag
  -T, --tags               List all tags in use
  -u, --update             Update git-backed cheatpaths
  -v, --version            Print the version number`;

function home(): string {
  return process.env.HOME || "/home/agent";
}

function expandUser(p: string): string {
  if (p === "~") return home();
  if (p.startsWith("~/")) return path.join(home(), p.slice(2));
  return p;
}

function defaultConfigText(): string {
  const h = home();
  return `---
# The editor to use with 'cheat -e <sheet>'. Overridden by $VISUAL or $EDITOR.
editor: EDITOR_PATH

# Should 'cheat' always colorize output?
colorize: false

# Which 'chroma' colorscheme should be applied to the output?
# Options are available here:
#   https://github.com/alecthomas/chroma/tree/master/styles
style: monokai

# Which 'chroma' "formatter" should be applied?
# One of: "terminal", "terminal256", "terminal16m"
formatter: terminal256

# Through which pager should output be piped?
# 'less -FRX' is recommended on Unix systems
# 'more' is recommended on Windows
pager: /usr/bin/pager

# The paths at which cheatsheets are available. Tags associated with a cheatpath
# are automatically attached to all cheatsheets residing on that path.
#
# Whenever cheatsheets share the same title (like 'tar'), the most local
# cheatsheets (those which come later in this file) take precedence over the
# less local sheets. This allows you to create your own "overides" for
# "upstream" cheatsheets.
#
# But what if you want to view the "upstream" cheatsheets instead of your own?
# Cheatsheets may be filtered by 'tags' in combination with the '--tag' flag.
# 
# Example: 'cheat tar --tag=community' will display the 'tar' cheatsheet that
# is tagged as 'community' rather than your own.
#
# Paths that come earlier are considered to be the most "global", and paths
# that come later are considered to be the most "local". The most "local" paths
# take precedence.
#
# See: https://github.com/cheat/cheat/blob/master/doc/cheat.1.md#cheatpaths
cheatpaths:

  # Cheatsheets that are tagged "personal" are stored here by default:
  - name: personal
    path: ${h}/.config/cheat/cheatsheets/personal
    tags: [ personal ]
    readonly: false

  # Cheatsheets that are tagged "work" are stored here by default:
  - name: work
    path: ${h}/.config/cheat/cheatsheets/work
    tags: [ work ]
    readonly: false

  # Community cheatsheets (https://github.com/cheat/cheatsheets):
  # To install: git clone https://github.com/cheat/cheatsheets ${h}/.config/cheat/cheatsheets/community
  #- name: community
  #  path: ${h}/.config/cheat/cheatsheets/community
  #  tags: [ community ]
  #  readonly: true

  # You can also use glob patterns to automatically load cheatsheets from all
  # directories that match.
  #
  # Example: overload cheatsheets for projects under ~/src/github.com/example/*/
  #- name: example-projects
  #  path: ~/src/github.com/example/**/.cheat
  #  tags: [ example ]
  #  readonly: true`;
}

function configCandidates(): string[] {
  if (process.env.CHEAT_CONFIG_PATH) return [expandUser(process.env.CHEAT_CONFIG_PATH)];
  const out: string[] = [];
  if (process.env.XDG_CONFIG_HOME) out.push(path.join(expandUser(process.env.XDG_CONFIG_HOME), "cheat", "conf.yml"));
  out.push(path.join(home(), ".config", "cheat", "conf.yml"));
  out.push(path.join(home(), ".cheat", "conf.yml"));
  out.push("/etc/cheat/conf.yml");
  return out;
}

function findConfigPath(): string | null {
  for (const p of configCandidates()) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

function needConfig(): Config {
  const file = findConfigPath();
  if (!file) {
    process.stdout.write("A config file was not found. Would you like to create one now? [Y/n]: ");
    console.error("failed to create config: failed to prompt: EOF");
    process.exit(1);
  }
  return parseConfig(file);
}

function cleanScalar(v: string): string {
  v = v.trim();
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) return v.slice(1, -1);
  return v;
}

function parseTags(v: string): string[] {
  const m = v.match(/\[(.*)\]/);
  if (!m) return v.trim() ? [cleanScalar(v)] : [];
  return m[1].split(",").map((x) => cleanScalar(x)).filter(Boolean);
}

function parseConfig(file: string): Config {
  const lines = fs.readFileSync(file, "utf8").split(/\r?\n/);
  const cfg: Config = { file, editor: "vi", pager: "", colorize: false, cheatpaths: [] };
  let current: CheatPath | null = null;
  let inCheatpaths = false;
  for (const raw of lines) {
    const noComment = raw.replace(/\s+#.*$/, "");
    const trimmed = noComment.trim();
    if (!trimmed || trimmed === "---" || trimmed.startsWith("#")) continue;
    if (trimmed === "cheatpaths:") {
      inCheatpaths = true;
      continue;
    }
    if (!inCheatpaths) {
      const m = trimmed.match(/^([A-Za-z0-9_-]+):\s*(.*)$/);
      if (m) {
        const key = m[1], val = cleanScalar(m[2]);
        if (key === "editor") cfg.editor = val;
        if (key === "pager") cfg.pager = val;
        if (key === "colorize") cfg.colorize = val === "true";
      }
      continue;
    }
    let m = trimmed.match(/^-\s+name:\s*(.*)$/);
    if (m) {
      current = { name: cleanScalar(m[1]), path: "", tags: [], readonly: false };
      cfg.cheatpaths.push(current);
      continue;
    }
    m = trimmed.match(/^([A-Za-z0-9_-]+):\s*(.*)$/);
    if (m && current) {
      const key = m[1], val = cleanScalar(m[2]);
      if (key === "path") current.path = expandUser(val);
      else if (key === "tags") current.tags = parseTags(val);
      else if (key === "readonly") current.readonly = val === "true";
    }
  }
  return cfg;
}

function parseFrontmatter(raw: string): { body: string; tags: string[] } {
  const lines = raw.split(/\r?\n/);
  if (lines[0] !== "---") return { body: raw.replace(/\s+$/g, ""), tags: [] };
  let end = -1;
  for (let i = 1; i < lines.length; i++) if (lines[i] === "---") { end = i; break; }
  if (end < 0) return { body: raw.replace(/\s+$/g, ""), tags: [] };
  const tags: string[] = [];
  for (let i = 1; i < end; i++) {
    const m = lines[i].trim().match(/^tags:\s*(.*)$/);
    if (m) tags.push(...parseTags(m[1]));
  }
  return { body: lines.slice(end + 1).join("\n").replace(/\s+$/g, ""), tags };
}

function walk(dir: string, prefix = ""): string[] {
  if (!fs.existsSync(dir)) return [];
  const out: string[] = [];
  for (const name of fs.readdirSync(dir).sort()) {
    if (name.startsWith(".")) continue;
    const full = path.join(dir, name);
    const rel = prefix ? `${prefix}/${name}` : name;
    let st;
    try { st = fs.statSync(full); } catch { continue; }
    if (st.isDirectory()) out.push(...walk(full, rel));
    else if (st.isFile()) out.push(rel);
  }
  return out;
}

function nearestDotCheat(): CheatPath | null {
  let dir = process.cwd();
  while (true) {
    const cand = path.join(dir, ".cheat");
    if (fs.existsSync(cand) && fs.statSync(cand).isDirectory()) {
      return { name: "local", path: cand, tags: ["local"], readonly: false };
    }
    const parent = path.dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

function allCheatpaths(cfg: Config): CheatPath[] {
  const cps = cfg.cheatpaths.slice();
  const local = nearestDotCheat();
  if (local) cps.push(local);
  return cps;
}

function uniqSorted(xs: string[]): string[] {
  return Array.from(new Set(xs.filter(Boolean))).sort();
}

function readSheets(cfg: Config, pathFilter?: string): Sheet[] {
  const cps = allCheatpaths(cfg);
  if (pathFilter && !cps.some((c) => c.name === pathFilter)) {
    console.error(`invalid option --path: cheatpath does not exist: ${pathFilter}`);
    process.exit(1);
  }
  const sheets: Sheet[] = [];
  cps.forEach((cp, idx) => {
    if (pathFilter && cp.name !== pathFilter) return;
    for (const rel of walk(cp.path)) {
      const file = path.join(cp.path, rel);
      let raw = "";
      try { raw = fs.readFileSync(file, "utf8"); } catch { continue; }
      const fm = parseFrontmatter(raw);
      sheets.push({
        title: rel,
        file,
        pathName: cp.name,
        pathIndex: idx,
        tags: uniqSorted([...cp.tags, ...fm.tags]),
        body: fm.body,
        raw
      });
    }
  });
  sheets.sort((a, b) => a.title.localeCompare(b.title) || a.pathIndex - b.pathIndex);
  return sheets;
}

function printTable(rows: string[][]) {
  const widths: number[] = [];
  for (const row of rows) row.forEach((cell, i) => widths[i] = Math.max(widths[i] || 0, cell.length));
  const lines = rows.map((row) => row.map((cell, i) => i === row.length - 1 ? cell : cell.padEnd(widths[i])).join(" "));
  process.stdout.write(lines.join("\n") + (lines.length ? "\n" : ""));
}

function listDirs(cfg: Config, p?: string) {
  const cps = allCheatpaths(cfg);
  if (p && !cps.some((c) => c.name === p)) {
    console.error(`invalid option --path: cheatpath does not exist: ${p}`);
    process.exit(1);
  }
  const rows = cps.filter((c) => !p || c.name === p).map((c) => [`${c.name}:`, c.path]);
  printTable(rows);
}

function listSheets(sheets: Sheet[], brief: boolean, titleFilter?: string, tag?: string) {
  let rows = sheets.filter((s) => (!titleFilter || s.title.includes(titleFilter)) && (!tag || s.tags.includes(tag)));
  if (brief) printTable([["title:", "tags:"], ...rows.map((s) => [s.title, s.tags.join(",")])]);
  else printTable([["title:", "file:", "tags:"], ...rows.map((s) => [s.title, s.file, s.tags.join(",")])]);
}

function pickSheet(sheets: Sheet[], title: string, tag?: string): Sheet | null {
  const matches = sheets.filter((s) => s.title === title && (!tag || s.tags.includes(tag)));
  if (!matches.length) return null;
  matches.sort((a, b) => b.pathIndex - a.pathIndex);
  return matches[0];
}

function searchSheets(sheets: Sheet[], phrase: string, regex: boolean, tag?: string) {
  let matcher: (s: string) => boolean;
  if (regex) {
    let re: any;
    try { re = new RegExp(phrase); } catch (e) { console.error(String(e)); process.exit(1); }
    matcher = (s) => re.test(s);
  } else {
    matcher = (s) => s.includes(phrase);
  }
  const found = sheets
    .filter((s) => (!tag || s.tags.includes(tag)) && matcher(s.body))
    .sort((a, b) => a.pathIndex - b.pathIndex || a.title.localeCompare(b.title));
  const blocks = found.map((s) => `${s.title} (${s.pathName})\n` + s.body.split("\n").map((l) => `\t${l}`).join("\n"));
  process.stdout.write(blocks.join("\n\n"));
}

function editSheet(cfg: Config, name: string, pathName?: string) {
  const cps = allCheatpaths(cfg).filter((c) => !pathName || c.name === pathName);
  if (pathName && cps.length === 0) {
    console.error(`invalid option --path: cheatpath does not exist: ${pathName}`);
    process.exit(1);
  }
  const sheets = readSheets(cfg, pathName);
  let target = pickSheet(sheets, name);
  let file = target?.file || "";
  if (!file) {
    const writable = [...cps].reverse().find((c) => !c.readonly) || cps[cps.length - 1];
    file = path.join(writable.path, name);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    if (!fs.existsSync(file)) fs.writeFileSync(file, "");
  }
  const editor = process.env.VISUAL || process.env.EDITOR || cfg.editor || "vi";
  const res = child_process.spawnSync(editor, [file], { stdio: "inherit", shell: true });
  process.exit(res.status == null ? 1 : res.status);
}

function removeSheet(cfg: Config, name: string, pathName?: string) {
  const sheets = readSheets(cfg, pathName);
  const target = pickSheet(sheets, name);
  if (!target) {
    console.error(`No cheatsheet found for '${name}'.`);
    process.exit(2);
  }
  fs.unlinkSync(target.file);
}

function completion(shell: string) {
  if (!["bash", "zsh", "fish", "powershell"].includes(shell)) {
    console.error(`unsupported shell: ${shell}`);
    process.exit(1);
  }
  if (shell === "bash") {
    process.stdout.write(`# bash completion V2 for cheat                                -*- shell-script -*-

__cheat_debug()
{
    if [[ -n \${BASH_COMP_DEBUG_FILE-} ]]; then
        echo "$*" >> "\${BASH_COMP_DEBUG_FILE}"
    fi
}

complete -o default -F __start_cheat cheat
`);
  } else if (shell === "zsh") process.stdout.write("#compdef cheat\n_arguments '*: :->args'\n");
  else if (shell === "fish") process.stdout.write("complete -c cheat -f\n");
  else process.stdout.write("Register-ArgumentCompleter -CommandName cheat -ScriptBlock {}\n");
}

function parseArgs(argv: string[]) {
  const opts: any = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const take = () => {
      const eq = a.indexOf("=");
      if (eq >= 0) return a.slice(eq + 1);
      if (i + 1 >= argv.length) { console.error(`flag needs an argument: ${a}`); process.exit(1); }
      return argv[++i];
    };
    if (a === "-h" || a === "--help") opts.help = true;
    else if (a === "-v" || a === "--version") opts.version = true;
    else if (a === "--init") opts.init = true;
    else if (a === "--conf") opts.conf = true;
    else if (a === "-d" || a === "--directories") opts.directories = true;
    else if (a === "-l" || a === "--list") opts.list = true;
    else if (a === "-b" || a === "--brief") opts.brief = true;
    else if (a === "-T" || a === "--tags") opts.tags = true;
    else if (a === "-a" || a === "--all") opts.all = true;
    else if (a === "-c" || a === "--colorize") opts.colorize = true;
    else if (a === "-r" || a === "--regex") opts.regex = true;
    else if (a === "-u" || a === "--update") opts.update = true;
    else if (a === "-p" || a === "--path" || a.startsWith("--path=")) opts.path = take();
    else if (a === "-t" || a === "--tag" || a.startsWith("--tag=")) opts.tag = take();
    else if (a === "-s" || a === "--search" || a.startsWith("--search=")) opts.search = take();
    else if (a === "-e" || a === "--edit" || a.startsWith("--edit=")) opts.edit = take();
    else if (a === "--rm" || a.startsWith("--rm=")) opts.rm = take();
    else if (a === "--completion" || a.startsWith("--completion=")) opts.completion = take();
    else if (a.startsWith("-")) { console.error(`unknown flag: ${a}`); process.exit(1); }
    else opts._.push(a);
  }
  return opts;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help || process.argv.length <= 2) { console.log(HELP); return; }
  if (opts.version) { console.log(VERSION); return; }
  if (opts.init) { console.log(defaultConfigText()); return; }
  if (opts.completion) { completion(opts.completion); return; }
  const cfg = needConfig();
  if (opts.conf) { console.log(cfg.file); return; }
  if (opts.directories) { listDirs(cfg, opts.path); return; }
  if (opts.update) { return; }
  if (opts.edit) { editSheet(cfg, opts.edit, opts.path); return; }
  if (opts.rm) { removeSheet(cfg, opts.rm, opts.path); return; }
  const sheets = readSheets(cfg, opts.path);
  if (opts.tags) {
    const tags = uniqSorted(sheets.flatMap((s) => s.tags));
    process.stdout.write(tags.join("\n") + (tags.length ? "\n" : ""));
    return;
  }
  const titleArg = opts._[0];
  if (opts.list || opts.brief) { listSheets(sheets, !!opts.brief, titleArg, opts.tag); return; }
  if (opts.search !== undefined) { searchSheets(sheets, opts.search, !!opts.regex, opts.tag); return; }
  if (titleArg) {
    const sheet = pickSheet(sheets, titleArg, opts.tag);
    if (!sheet) {
      console.error(`No cheatsheet found for '${titleArg}'.`);
      process.exit(2);
    }
    process.stdout.write(sheet.body + (sheet.body ? "\n" : ""));
    return;
  }
  console.log(HELP);
}

main();
