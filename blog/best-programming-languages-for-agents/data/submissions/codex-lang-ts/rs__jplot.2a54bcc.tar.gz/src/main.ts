declare const process: {
  argv: string[];
  stdout: { write(s: string): void };
  stderr: { write(s: string): void };
  exit(code?: number): never;
};

const RESET_QUERY = "\x1b[c";
const GRAPHICS_REQUIRED = "jplot:  iTerm2, Kitty, or DRCS Sixel graphics required\n";

const USAGE = `Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:

OPTIONS:
  -interval duration
    \tWhen url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)
  -rows int
    \tLimits the height of the graph output.
  -steps int
    \tNumber of values to plot. (default 100)
  -url string
    \tURL to fetch every second. Read JSON objects from stdin if not specified.

FIELD_SPEC: [<option>[,<option>...]:]path
  option:
    - counter: Computes the difference with the last value. The value must increase monotonically.
    - marker: When the value is none-zero, a vertical line is drawn.
  path:
    JSON field path (eg: field.sub-field).
`;

type FlagKind = "int" | "duration" | "string";
const flagKinds: Record<string, FlagKind> = {
  interval: "duration",
  rows: "int",
  steps: "int",
  url: "string",
};

function writeStdout(s: string): void {
  process.stdout.write(s);
}

function writeStderr(s: string): void {
  process.stderr.write(s);
}

function usageErr(prefix?: string): never {
  if (prefix) writeStderr(prefix + "\n");
  writeStderr(USAGE);
  process.exit(prefix ? 2 : 0);
}

function isValidInt(v: string): boolean {
  return /^[+-]?\d+$/.test(v);
}

function isValidDuration(v: string): boolean {
  return /^[+-]?(?:(?:\d+(?:\.\d*)?|\.\d+)(?:ns|us|µs|μs|ms|s|m|h))+$/.test(v);
}

function parseArgs(argv: string[]): void {
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--") return;
    if (arg === "-" || !arg.startsWith("-")) return;

    let raw = arg.replace(/^-+/, "");
    let value: string | undefined;
    const eq = raw.indexOf("=");
    if (eq >= 0) {
      value = raw.slice(eq + 1);
      raw = raw.slice(0, eq);
    }

    if (raw === "h" || raw === "help") usageErr();

    const kind = flagKinds[raw];
    if (!kind) usageErr(`flag provided but not defined: -${raw}`);

    if (value === undefined) {
      if (i + 1 >= argv.length) usageErr(`flag needs an argument: -${raw}`);
      value = argv[++i];
    }

    if (kind === "int" && !isValidInt(value)) {
      usageErr(`invalid value "${value}" for flag -${raw}: parse error`);
    }
    if (kind === "duration" && !isValidDuration(value)) {
      usageErr(`invalid value "${value}" for flag -${raw}: parse error`);
    }
  }
}

function main(): void {
  writeStdout(RESET_QUERY);
  parseArgs(process.argv.slice(2));
  writeStdout(GRAPHICS_REQUIRED);
  process.exit(1);
}

main();
