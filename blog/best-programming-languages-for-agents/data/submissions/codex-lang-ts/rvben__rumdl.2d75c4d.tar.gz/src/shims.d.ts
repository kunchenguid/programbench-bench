declare const process: any;
declare const require: any;
declare module "fs" {
  const fs: any;
  export = fs;
}
declare module "path" {
  const path: any;
  export = path;
}
