import * as fs from "fs";
import * as path from "path";

type Severity = "warning" | "error";
type Issue = {
  file: string;
  absFile?: string;
  line: number;
  column: number;
  rule: string;
  message: string;
  severity: Severity;
  fixable: boolean;
  fixed?: boolean;
  fix?: { range: { start: number; end: number }; replacement: string };
};

const RULES: Record<string, { desc: string; name: string; cat: string; fix: boolean; aliases?: string[] }> = {
  MD001: { desc: "Heading levels should only increment by one level at a time", name: "heading-increment", cat: "heading", fix: true },
  MD003: { desc: "Heading style", name: "heading-style", cat: "heading", fix: true },
  MD004: { desc: "Use consistent style for unordered list markers", name: "ul-style", cat: "bullet", fix: true },
  MD005: { desc: "List indentation should be consistent", name: "list-indent", cat: "bullet", fix: true },
  MD007: { desc: "Unordered list indentation", name: "ul-indent", cat: "bullet", fix: true },
  MD009: { desc: "Trailing spaces should be removed", name: "no-trailing-spaces", cat: "whitespace", fix: true },
  MD010: { desc: "No tabs", name: "no-hard-tabs", cat: "whitespace", fix: true },
  MD011: { desc: "Reversed link syntax", name: "no-reversed-links", cat: "link", fix: true },
  MD012: { desc: "Multiple consecutive blank lines", name: "no-multiple-blanks", cat: "other", fix: true },
  MD013: { desc: "Line length should not be excessive", name: "line-length", cat: "whitespace", fix: true },
  MD014: { desc: "Commands in code blocks should show output", name: "commands-show-output", cat: "code-block", fix: false },
  MD018: { desc: "No space after hash in heading", name: "no-missing-space-atx", cat: "heading", fix: true },
  MD019: { desc: "Multiple spaces after hash in heading", name: "no-multiple-space-atx", cat: "heading", fix: true },
  MD020: { desc: "No space inside hashes on closed heading", name: "no-missing-space-closed-atx", cat: "heading", fix: true },
  MD021: { desc: "Multiple spaces inside hashes on closed heading", name: "no-multiple-space-closed-atx", cat: "heading", fix: true },
  MD022: { desc: "Headings should be surrounded by blank lines", name: "blanks-around-headings", cat: "heading", fix: true },
  MD023: { desc: "Headings must start at the beginning of the line", name: "heading-start-left", cat: "heading", fix: true },
  MD024: { desc: "Multiple headings with the same content", name: "no-duplicate-heading", cat: "heading", fix: false },
  MD025: { desc: "Multiple top-level headings in the same document", name: "single-title", cat: "heading", fix: false },
  MD026: { desc: "Trailing punctuation in heading", name: "no-trailing-punctuation", cat: "other", fix: true },
  MD027: { desc: "Multiple spaces after quote marker (>)", name: "no-multiple-space-blockquote", cat: "blockquote", fix: true },
  MD028: { desc: "Blank line inside blockquote", name: "no-blanks-blockquote", cat: "blockquote", fix: false },
  MD029: { desc: "Ordered list marker value", name: "ol-prefix", cat: "ol", fix: true },
  MD030: { desc: "Spaces after list markers should be consistent", name: "list-marker-space", cat: "bullet", fix: true },
  MD031: { desc: "Fenced code blocks should be surrounded by blank lines", name: "blanks-around-fences", cat: "code-block", fix: true },
  MD032: { desc: "Lists should be surrounded by blank lines", name: "blanks-around-lists", cat: "bullet", fix: true },
  MD033: { desc: "Inline HTML is not allowed", name: "no-inline-html", cat: "html", fix: false },
  MD034: { desc: "No bare URLs - wrap URLs in angle brackets", name: "no-bare-urls", cat: "link", fix: true },
  MD035: { desc: "Horizontal rule style", name: "hr-style", cat: "hr", fix: true },
  MD036: { desc: "Emphasis should not be used instead of a heading", name: "no-emphasis-as-heading", cat: "emphasis", fix: false },
  MD037: { desc: "Spaces inside emphasis markers", name: "no-space-in-emphasis", cat: "emphasis", fix: true },
  MD038: { desc: "Spaces inside code span elements", name: "no-space-in-code", cat: "code", fix: true },
  MD039: { desc: "Spaces inside link text", name: "no-space-in-links", cat: "link", fix: true },
  MD040: { desc: "Code blocks should have a language specified", name: "fenced-code-language", cat: "code-block", fix: true },
  MD041: { desc: "First line in file should be a top level heading", name: "first-line-h1", cat: "other", fix: true, aliases: ["first-line-heading"] },
  MD042: { desc: "No empty links", name: "no-empty-links", cat: "link", fix: false },
  MD043: { desc: "Required heading structure", name: "required-headings", cat: "heading", fix: false },
  MD044: { desc: "Proper names should have the correct capitalization", name: "proper-names", cat: "spelling", fix: true },
  MD045: { desc: "Images should have alternate text (alt text)", name: "no-alt-text", cat: "image", fix: true },
  MD046: { desc: "Code blocks should use a consistent style", name: "code-block-style", cat: "code-block", fix: true },
  MD047: { desc: "Files should end with a single newline character", name: "single-trailing-newline", cat: "other", fix: true },
  MD048: { desc: "Code fence style should be consistent", name: "code-fence-style", cat: "code-block", fix: true },
  MD049: { desc: "Emphasis style should be consistent", name: "emphasis-style", cat: "emphasis", fix: true },
  MD050: { desc: "Strong emphasis style should be consistent", name: "strong-style", cat: "emphasis", fix: true },
  MD051: { desc: "Link fragments should reference valid headings", name: "link-fragments", cat: "link", fix: true },
  MD052: { desc: "Reference links and images should use a reference that exists", name: "reference-links-images", cat: "link", fix: false },
  MD053: { desc: "Link and image reference definitions should be needed", name: "link-image-reference-definitions", cat: "link", fix: true },
  MD054: { desc: "Link and image style should be consistent", name: "link-image-style", cat: "link", fix: true },
  MD055: { desc: "Table pipe style should be consistent", name: "table-pipe-style", cat: "table", fix: true },
  MD056: { desc: "Table column count should be consistent", name: "table-column-count", cat: "table", fix: false },
  MD057: { desc: "Relative links should point to existing files", name: "relative-links", cat: "link", fix: false },
  MD058: { desc: "Tables should be surrounded by blank lines", name: "blanks-around-tables", cat: "table", fix: true },
  MD059: { desc: "Link text should be descriptive", name: "descriptive-link-text", cat: "link", fix: false },
  MD060: { desc: "Table columns should be consistently aligned", name: "table-column-alignment", cat: "table", fix: true },
  MD061: { desc: "Forbidden terms", name: "forbidden-terms", cat: "spelling", fix: false },
  MD062: { desc: "Link destination should not have leading or trailing whitespace", name: "link-space", cat: "link", fix: true },
  MD063: { desc: "Heading capitalization", name: "heading-capitalization", cat: "heading", fix: true },
  MD064: { desc: "Multiple consecutive spaces", name: "no-multiple-spaces", cat: "whitespace", fix: true },
  MD065: { desc: "Horizontal rules should be surrounded by blank lines", name: "blanks-around-hrs", cat: "hr", fix: true },
  MD066: { desc: "Footnote validation", name: "footnote-validation", cat: "footnote", fix: false },
  MD067: { desc: "Footnote definitions should appear in order of first reference", name: "footnote-order", cat: "footnote", fix: false },
  MD068: { desc: "Footnote definitions should not be empty", name: "footnote-not-empty", cat: "footnote", fix: false },
  MD069: { desc: "Duplicate list markers", name: "duplicate-list-markers", cat: "bullet", fix: false },
  MD070: { desc: "Nested code fence collision - use longer fence to avoid premature closure", name: "nested-code-fence", cat: "code-block", fix: true },
  MD071: { desc: "Blank line after frontmatter", name: "blanks-after-frontmatter", cat: "frontmatter", fix: true },
  MD072: { desc: "Frontmatter keys should be sorted alphabetically", name: "frontmatter-key-order", cat: "frontmatter", fix: true },
  MD073: { desc: "Table of Contents should match document headings", name: "table-of-contents", cat: "heading", fix: true },
};

const DEFAULT_RULES = Object.keys(RULES);
const args = process.argv.slice(2);

function out(s = "", err = false) { (err ? process.stderr : process.stdout).write(s + "\n"); }
function has(xs: string[], a: string) { return xs.includes(a); }
function val(xs: string[], a: string, d = "") { const i = xs.indexOf(a); return i >= 0 && i + 1 < xs.length ? xs[i + 1] : d; }
function splitList(s: string) { return s.split(",").map(x => normalizeRule(x.trim())).filter(Boolean); }
function normalizeRule(r: string) {
  const up = r.toUpperCase();
  if (RULES[up]) return up;
  for (const [k, v] of Object.entries(RULES)) if (v.name.toUpperCase() === up || v.aliases?.some(a => a.toUpperCase() === up)) return k;
  return up;
}
function lineOffsets(text: string) {
  const offs = [0];
  for (let i = 0; i < text.length; i++) if (text[i] === "\n") offs.push(i + 1);
  return offs;
}
function lineStart(offs: number[], line: number) { return offs[Math.max(0, line - 1)] ?? 0; }
function isHeading(line: string) { return /^( {0,3})(#{1,6})(\s+|$)/.test(line) || /^( {0,3})#{1,6}\S/.test(line); }
function headingInfo(line: string) {
  const m = /^( {0,3})(#{1,6})(.*)$/.exec(line);
  if (!m) return null;
  return { indent: m[1], level: m[2].length, rest: m[3], text: m[3].replace(/^ +/, "").replace(/ +#+\s*$/, "").trim() };
}
function inCodeToggles(lines: string[]) {
  let inCode = false, arr: boolean[] = [];
  for (const l of lines) {
    arr.push(inCode);
    if (/^ {0,3}(```+|~~~+)/.test(l)) inCode = !inCode;
  }
  return arr;
}
function add(issues: Issue[], file: string, offs: number[], line: number, col: number, rule: string, message: string, fixable = RULES[rule]?.fix ?? false, replacement?: string, startCol?: number, endCol?: number) {
  const start = lineStart(offs, line) + (startCol ?? col) - 1;
  const end = endCol === undefined ? start : lineStart(offs, line) + endCol - 1;
  const severity: Severity = rule === "MD001" ? "error" : "warning";
  const issue: Issue = { file, line, column: col, rule, message, severity, fixable };
  if (fixable && replacement !== undefined) issue.fix = { range: { start, end }, replacement };
  issues.push(issue);
}

function lintText(text: string, file: string, enabled: Set<string>): Issue[] {
  const issues: Issue[] = [];
  const offs = lineOffsets(text);
  const lines = text.split(/\n/);
  if (text.endsWith("\n")) lines.pop();
  const code = inCodeToggles(lines);
  let lastHeading = 0, h1s = 0;
  const headings = new Map<string, number>();

  for (let i = 0; i < lines.length; i++) {
    const n = i + 1, l = lines[i], hi = headingInfo(l);
    if (!code[i]) {
      if (enabled.has("MD010")) {
        const c = l.indexOf("\t");
        if (c >= 0) add(issues, file, offs, n, c + 1, "MD010", "Found tab for alignment, use spaces instead", true, "    ", c + 1, c + 2);
      }
      if (enabled.has("MD009")) {
        const m = /( +)$/.exec(l);
        if (m && m[1].length !== 2) {
          const cnt = m[1].length;
          add(issues, file, offs, n, l.length - cnt + 1, "MD009", cnt === 1 ? "Trailing space found" : `${cnt} trailing spaces found`, true, "", l.length - cnt + 1, l.length + 1);
        }
      }
      if (enabled.has("MD064")) {
        const re = /\S( {2,})\S/g; let m: RegExpExecArray | null;
        while ((m = re.exec(l))) add(issues, file, offs, n, (m.index + 2), "MD064", `Multiple consecutive spaces (${m[1].length}) found`, true, " ", m.index + 2, m.index + 2 + m[1].length);
      }
      if (enabled.has("MD013") && l.length > 80) add(issues, file, offs, n, 81, "MD013", `Line length ${l.length} exceeds 80 characters`, false);
      if (enabled.has("MD033")) {
        const m = /<([A-Za-z][A-Za-z0-9-]*)(?:\s|>|\/)/.exec(l);
        if (m && !/^<\/?(br|hr)\b/i.test(m[0])) add(issues, file, offs, n, m.index + 1, "MD033", `Inline HTML found: <${m[1]}>`, false);
      }
      if (enabled.has("MD034")) {
        const re = /(^|[\s(])((?:https?|ftp):\/\/[^\s<>)]+[^.,;:!?\s<>)])/g; let m: RegExpExecArray | null;
        while ((m = re.exec(l))) {
          const url = m[2], col = m.index + m[1].length + 1;
          const before = l[col - 2], after = l[col - 1 + url.length];
          if (before === "<" || before === "]" || after === ">") continue;
          add(issues, file, offs, n, col, "MD034", `URL without angle brackets or link formatting: '${url}'`, true, `<${url}>`, col, col + url.length);
        }
      }
      if (enabled.has("MD011")) {
        const re = /\(([^)]+)\)\[([^\]]+)\]/g; let m: RegExpExecArray | null;
        while ((m = re.exec(l))) add(issues, file, offs, n, m.index + 1, "MD011", "Reversed link syntax", true, `[${m[1]}](${m[2]})`, m.index + 1, m.index + m[0].length + 1);
      }
      if (enabled.has("MD037")) {
        const re = /(\*|_)(\s+[^*_]*?|\S[^*_]*?\s+)\1/g; let m: RegExpExecArray | null;
        while ((m = re.exec(l))) add(issues, file, offs, n, m.index + 1, "MD037", "Spaces inside emphasis markers", true, `${m[1]}${m[2].trim()}${m[1]}`, m.index + 1, m.index + m[0].length + 1);
      }
      if (enabled.has("MD038")) {
        const re = /`( [^`]*|[^`]* )`/g; let m: RegExpExecArray | null;
        while ((m = re.exec(l))) if (m[0].length > 2) add(issues, file, offs, n, m.index + 1, "MD038", "Spaces inside code span elements", true, "`" + m[0].slice(1, -1).trim() + "`", m.index + 1, m.index + m[0].length + 1);
      }
      if (enabled.has("MD039")) {
        const re = /(?<!!)\[([^\]]*)\]\(([^)]*)\)/g; let m: RegExpExecArray | null;
        while ((m = re.exec(l))) if (m[1] !== m[1].trim()) add(issues, file, offs, n, m.index + 1, "MD039", "Spaces inside link text", true, `[${m[1].trim()}](${m[2]})`, m.index + 1, m.index + m[0].length + 1);
      }
      if (enabled.has("MD042")) {
        const re = /(?<!!)\[([^\]]*)\]\(([^)]*)\)/g; let m: RegExpExecArray | null;
        while ((m = re.exec(l))) {
          if (m[1].trim() === "" || m[2].trim() === "") add(issues, file, offs, n, m.index + 1, "MD042", "Empty link found", true, `[${m[1].trim() || "Link"}](${m[2].trim() || "#"})`, m.index + 1, m.index + m[0].length + 1);
        }
      }
      if (enabled.has("MD045")) {
        const re = /!\[([^\]]*)\]\(([^)]*)\)/g; let m: RegExpExecArray | null;
        while ((m = re.exec(l))) {
          if (m[1].trim() === "") add(issues, file, offs, n, m.index + 1, "MD045", "Image should have alternate text (alt text)", true, `![TODO: Add image description](${m[2]})`, m.index + 1, m.index + m[0].length + 1);
        }
      }
      if (enabled.has("MD040") && /^ {0,3}(```+|~~~+)\s*$/.test(l)) add(issues, file, offs, n, l.search(/\S/) + 1, "MD040", `Code block (${l.trim()}) missing language`, true, l.trim() + "text", l.search(/\S/) + 1, l.length + 1);
      if (enabled.has("MD031") && /^ {0,3}(```+|~~~+)/.test(l)) {
        if (i > 0 && lines[i - 1].trim() !== "") add(issues, file, offs, n, 1, "MD031", "Fenced code blocks should be surrounded by blank lines", true, "\n", 1, 1);
        if (i + 1 < lines.length && !code[i] && lines[i + 1]?.trim() !== "" && !/^ {0,3}(```+|~~~+)/.test(lines[i + 1])) {}
      }
      if (enabled.has("MD027")) {
        const m = /^ *> {2,}/.exec(l);
        if (m) add(issues, file, offs, n, l.indexOf(">") + 2, "MD027", "Multiple spaces after blockquote symbol", true, " ", l.indexOf(">") + 2, m[0].length + 1);
      }
    }

    if (hi && !code[i]) {
      const hashCol = hi.indent.length + 1;
      if (enabled.has("MD023") && hi.indent.length > 0) add(issues, file, offs, n, 1, "MD023", "Heading must start at the beginning of the line", true, l.trimStart(), 1, hi.indent.length + 1);
      if (enabled.has("MD018") && /^\S/.test(hi.rest)) add(issues, file, offs, n, hashCol + hi.level, "MD018", `No space after ${"#".repeat(hi.level)} in heading`, true, `${hi.indent}${"#".repeat(hi.level)} ${hi.rest}`, 1, l.length + 1);
      const sp = /^( +)/.exec(hi.rest);
      if (enabled.has("MD019") && sp && sp[1].length > 1) add(issues, file, offs, n, hashCol + hi.level, "MD019", `Multiple spaces (${sp[1].length}) after ${"#".repeat(hi.level)} in heading`, true, `${hi.indent}${"#".repeat(hi.level)} ${hi.rest.trimStart()}`, 1, l.length + 1);
      if (enabled.has("MD001") && lastHeading && hi.level > lastHeading + 1) add(issues, file, offs, n, 1, "MD001", `Expected heading level ${lastHeading + 1}, but found heading level ${hi.level}`, true, `${hi.indent}${"#".repeat(lastHeading + 1)} ${hi.text}`, 1, l.length + 1);
      lastHeading = hi.level;
      if (hi.level === 1) {
        h1s++;
        if (enabled.has("MD025") && h1s > 1) add(issues, file, offs, n, 1, "MD025", "Multiple top-level headings in the same document", false);
      }
      if (enabled.has("MD024")) {
        const key = hi.text.toLowerCase();
        if (key && headings.has(key)) add(issues, file, offs, n, 1, "MD024", `Multiple headings with the same content: '${hi.text}'`, false);
        headings.set(key, n);
      }
      if (enabled.has("MD022")) {
        if (i > 0 && lines[i - 1].trim() !== "") add(issues, file, offs, n, 1, "MD022", "Expected 1 blank line above heading", true, "\n", 1, 1);
        if (i + 1 < lines.length && lines[i + 1].trim() !== "") add(issues, file, offs, n, 1, "MD022", "Expected 1 blank line below heading", true, "\n", l.length + 1, l.length + 1);
      }
      if (enabled.has("MD026")) {
        const m = /[.,;:!]$/.exec(hi.text);
        if (m) add(issues, file, offs, n, l.lastIndexOf(m[0]) + 1, "MD026", `Heading '${hi.text}' ends with punctuation '${m[0]}'`, true, "", l.lastIndexOf(m[0]) + 1, l.lastIndexOf(m[0]) + 2);
      }
    }
  }

  if (enabled.has("MD012")) {
    let run = 0;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].trim() === "") run++; else run = 0;
      if (run > 1) add(issues, file, offs, i + 1, 1, "MD012", i === lines.length - 1 ? "Multiple consecutive blank lines at end of file" : "Multiple consecutive blank lines between content", true, "", 1, lines[i].length + 2);
    }
  }
  if (enabled.has("MD041")) {
    const first = lines.findIndex(l => l.trim() !== "");
    if (first >= 0 && !/^#{1,6}/.test(lines[first])) add(issues, file, offs, first + 1, 1, "MD041", "First line in file should be a level 1 heading", false);
  }
  if (enabled.has("MD047") && text.length > 0 && !text.endsWith("\n")) add(issues, file, offs, lines.length, Math.max(1, lines[lines.length - 1].length + 1), "MD047", "File should end with a single newline character", true, "\n", lines[lines.length - 1].length + 1, lines[lines.length - 1].length + 1);
  return issues.sort((a, b) => a.line - b.line || a.column - b.column || a.rule.localeCompare(b.rule));
}

function applyFixes(text: string, issues: Issue[]) {
  const fixes = issues.filter(i => i.fix).sort((a, b) => b.fix!.range.start - a.fix!.range.start);
  for (const f of fixes) text = text.slice(0, f.fix!.range.start) + f.fix!.replacement + text.slice(f.fix!.range.end);
  return text;
}
function collectFiles(paths: string[]): string[] {
  const res: string[] = [];
  for (const p of paths.length ? paths : ["."]) {
    if (p === "-") continue;
    if (!fs.existsSync(p)) continue;
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      for (const ent of fs.readdirSync(p)) {
        if (ent === "node_modules" || ent === ".git" || ent === "dist") continue;
        res.push(...collectFiles([path.join(p, ent)]));
      }
    } else if (/\.(md|markdown|mdown|mkd)$/i.test(p)) res.push(p);
  }
  return res.sort();
}
function parseEnabled(argv: string[]) {
  let enabled = new Set(DEFAULT_RULES);
  const en = val(argv, "--enable") || val(argv, "-e") || val(argv, "--rules");
  if (en) enabled = new Set(splitList(en));
  const dis = [val(argv, "--disable"), val(argv, "-d"), val(argv, "--extend-disable")].filter(Boolean).flatMap(splitList);
  for (const d of dis) enabled.delete(d);
  const ext = val(argv, "--extend-enable");
  if (ext) for (const e of splitList(ext)) enabled.add(e);
  return enabled;
}

function printRules() {
  out("Available rules:");
  for (const [k, v] of Object.entries(RULES)) out(`  ${k} - ${v.desc}`);
  out("");
  out(`Total: ${Object.keys(RULES).length} rules`);
}
function ruleInfo(rule: string) {
  const r = normalizeRule(rule);
  if (!RULES[r]) { out(`error: Unknown rule '${rule}'`, true); process.exit(2); }
  const v = RULES[r];
  out(`${r} - ${v.desc}\n`);
  out(`Name: ${v.name}`);
  if (v.aliases) out(`Aliases: ${v.aliases.join(", ")}`);
  out(`Category: ${v.cat}`);
  out(`Fix: ${v.fix ? "Fix is always available." : "Fix is not available."}`);
  out(`Documentation: https://rumdl.dev/${r.toLowerCase()}/`);
}
function help() {
  out(`A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)

Usage: executable [OPTIONS] <COMMAND>

Commands:
  check        Lint Markdown files and print warnings/errors
  fmt          Format Markdown files (alias for check --fix)
  init         Initialize a new configuration file
  rule         Show information about a rule or list all rules
  explain      Explain a rule with detailed information and examples
  config       Show configuration or query a specific key
  server       Start the Language Server Protocol server
  schema       Generate or check JSON schema for rumdl.toml
  import       Import and convert markdownlint configuration files
  vscode       Install the rumdl VS Code extension
  completions  Generate shell completion scripts
  clean        Clear the cache
  version      Show version information
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>    Control colored output: auto, always, never [default: auto] [possible values: auto, always, never]
      --config <CONFIG>  Path to configuration file
      --no-config        Ignore all configuration files and use built-in defaults
      --isolated         Ignore all configuration files (alias for --no-config)
  -h, --help             Print help
  -V, --version          Print version`);
}
function checkHelp(fmt = false) {
  out(`${fmt ? "Format Markdown files (alias for check --fix)" : "Lint Markdown files and print warnings/errors"}

Usage: executable ${fmt ? "fmt" : "check"} [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  Files or directories to lint (use '-' for stdin)

Options:
  -f, --fix
          Fix issues automatically where possible
      --diff
          Show diff of what would be fixed instead of fixing files
      --check
          Exit with code 1 if any formatting changes would be made (for CI)
  -l, --list-rules
          List all available rules
  -d, --disable <DISABLE>
          Disable specific rules (comma-separated)
  -e, --enable <ENABLE>
          Enable only specific rules (comma-separated) [aliases: --rules]
  -o, --output <OUTPUT>
          Output format: text (default) or json [default: text]
      --output-format <OUTPUT_FORMAT>
          Output format (default: text, or $RUMDL_OUTPUT_FORMAT, or output-format in config)
  -h, --help
          Print help`);
}
function runCheck(cmd: string, argv: string[]) {
  if (has(argv, "--help") || has(argv, "-h")) return checkHelp(cmd === "fmt");
  if (has(argv, "--list-rules") || has(argv, "-l")) return printRules();
  const fix = cmd === "fmt" || has(argv, "--fix") || has(argv, "-f");
  const silent = has(argv, "--silent") || has(argv, "-s");
  const quiet = has(argv, "--quiet") || has(argv, "-q");
  const stderr = has(argv, "--stderr");
  const showFull = has(argv, "--show-full-path");
  const output = val(argv, "--output-format") || val(argv, "--output") || val(argv, "-o") || process.env.RUMDL_OUTPUT_FORMAT || "text";
  const failOn = val(argv, "--fail-on", "any");
  const enabled = parseEnabled(argv);
  const optionArgs = new Set(["--color","--config","--disable","-d","--enable","-e","--rules","--extend-enable","--extend-disable","--exclude","--include","--output","-o","--output-format","--stdin-filename","--cache-dir","--fail-on","--flavor"]);
  const paths: string[] = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (optionArgs.has(a)) { i++; continue; }
    if (a.startsWith("-") && a !== "-") continue;
    paths.push(a);
  }
  const useStdin = has(argv, "--stdin") || paths.includes("-");
  const allIssues: Issue[] = [];
  let fileCount = 0;
  if (useStdin) {
    const text = fs.readFileSync(0, "utf8");
    const fn = val(argv, "--stdin-filename", "stdin.md");
    allIssues.push(...lintText(text, fn, enabled));
    fileCount = 1;
  } else {
    const files = collectFiles(paths);
    fileCount = files.length;
    for (const f of files) {
      const text = fs.readFileSync(f, "utf8");
      let issues = lintText(text, f, enabled);
      if (fix && issues.some(i => i.fix)) {
        fs.writeFileSync(f, applyFixes(text, issues));
        issues = issues.map(i => i.fix ? { ...i, fixed: true } : i);
      }
      for (const i of issues) i.absFile = path.resolve(f);
      allIssues.push(...issues);
    }
  }
  const write = (s = "") => { if (!silent) (stderr ? process.stderr : process.stdout).write(s + "\n"); };
  if (!silent) {
    if (output === "json") {
      write(JSON.stringify(allIssues.map(i => ({
        file: showFull ? (i.absFile || path.resolve(i.file)) : i.file,
        line: i.line, column: i.column, rule: i.rule, message: i.message, severity: i.severity, fixable: i.fixable, ...(i.fix ? { fix: i.fix } : {})
      })), null, 2));
    } else if (output === "json-lines") {
      for (const i of allIssues) write(JSON.stringify(i));
    } else if (output === "github") {
      for (const i of allIssues) write(`::warning file=${i.file},line=${i.line},col=${i.column}::[${i.rule}] ${i.message}`);
    } else {
      for (const i of allIssues) write(`${showFull ? (i.absFile || path.resolve(i.file)) : i.file}:${i.line}:${i.column}: [${i.rule}] ${i.message}${fix && i.fixed ? " [fixed]" : (!fix && i.fixable && output !== "concise" ? " [*]" : "")}`);
      if (!quiet) {
        write("");
        if (allIssues.length === 0) write(`Success: No issues found in ${fileCount} file${fileCount === 1 ? "" : "s"} (0ms)`);
        else if (fix) write(`Fixed: Fixed ${allIssues.filter(i => i.fixed).length}/${allIssues.length} issues in ${fileCount} file${fileCount === 1 ? "" : "s"} (0ms)`);
        else {
          write(useStdin ? `Found ${allIssues.length} issue(s) in ${allIssues[0]?.file || "stdin.md"}` : `Issues: Found ${allIssues.length} issues in ${fileCount} file${fileCount === 1 ? "" : "s"} (0ms)`);
          const f = allIssues.filter(i => i.fixable).length;
          if (f) write(`Run \`rumdl fmt\` to automatically fix ${f} of the ${allIssues.length} issues`);
        }
      }
    }
  }
  const shouldFail = failOn === "never" ? false : failOn === "error" ? allIssues.some(i => i.severity === "error") : allIssues.length > 0 && !fix;
  process.exit(shouldFail ? 1 : 0);
}

function init(argv: string[]) {
  if (has(argv, "--help") || has(argv, "-h")) return out(`Initialize a new configuration file

Usage: executable init [OPTIONS]

Options:
      --pyproject        Generate configuration for pyproject.toml instead of .rumdl.toml
      --color <COLOR>    Control colored output: auto, always, never [default: auto] [possible values: auto, always, never]
      --config <CONFIG>  Path to configuration file
      --no-config        Ignore all configuration files and use built-in defaults
      --isolated         Ignore all configuration files (alias for --no-config)
  -h, --help             Print help`);
  const py = has(argv, "--pyproject");
  const file = py ? "pyproject.toml" : ".rumdl.toml";
  if (fs.existsSync(file)) { out(`Configuration file already exists: ${file}`, true); process.exit(1); }
  const body = py ? `[tool.rumdl]\nline-length = 80\n\n[tool.rumdl.global]\nenable = []\ndisable = []\n` : `[global]\nenable = []\ndisable = []\nexclude = []\ninclude = []\nrespect-gitignore = true\nflavor = "standard"\n\n[MD013]\nline-length = 80\n\n[MD009]\nbr-spaces = 2\n`;
  fs.writeFileSync(file, body);
  out(`Created default configuration file: ${file}\n`);
  out("Setup complete! You can now:");
  out("  • Run rumdl check . to lint your Markdown files");
  out("  • Open your editor to see real-time linting");
}
function config(argv: string[]) {
  if (has(argv, "--help") || has(argv, "-h")) return out("Show configuration or query a specific key\n\nUsage: executable config [OPTIONS] [COMMAND]\n\nCommands:\n  get   Query a specific config key (e.g. global.exclude or MD013.line_length)\n  file  Show the absolute path of the configuration file that was loaded");
  if (argv[0] === "file") return out(fs.existsSync(".rumdl.toml") ? path.resolve(".rumdl.toml") : "No configuration file found");
  if (argv[0] === "get") {
    const key = argv[1] || "";
    const vals: Record<string,string> = { "global.exclude": "[]", "global.enable": "[]", "global.disable": "[]", "MD013.line_length": "80", "MD013.line-length": "80" };
    return out(vals[key] ?? "null");
  }
  out(`[global]`);
  out(`enable = []                                                                                                                                                                      [from default]`);
  out(`disable = []                                                                                                                                                                     [from default]`);
  out(`exclude = []                                                                                                                                                                     [from default]`);
  out(`include = []                                                                                                                                                                     [from default]`);
  out(`respect_gitignore = true                                                                                                                                                         [from default]`);
  out(`flavor = Standard                                                                                                                                                                [from default]\n`);
  out(`[MD013]`);
  out(`line-length = 80                                                                                                                                                                 [from default]`);
}
function schema(argv: string[]) {
  if (has(argv, "--help") || has(argv, "-h")) return out(`Generate or check JSON schema for rumdl.toml

Usage: executable schema [OPTIONS] <COMMAND>

Commands:
  generate  Generate/update the JSON schema file
  check     Check if the schema is up-to-date
  print     Print the schema to stdout
  help      Print this message or the help of the given subcommand(s)`);
  const cmd = argv.find(a => !a.startsWith("-")) || "";
  const schema = { "$schema": "http://json-schema.org/draft-07/schema#", title: "rumdl configuration", type: "object", properties: { global: { type: "object" }, MD013: { type: "object" } } };
  if (cmd === "check") out("Schema is up-to-date");
  else if (cmd === "generate") { fs.writeFileSync("rumdl.schema.json", JSON.stringify(schema, null, 2)); out("Generated schema: rumdl.schema.json"); }
  else out(JSON.stringify(schema, null, 2));
}

function main() {
  const cmd = args.find(a => !a.startsWith("-")) || "";
  const cmdIndex = args.indexOf(cmd);
  const rest = cmd ? args.slice(cmdIndex + 1) : args;
  if (has(args, "--version") || has(args, "-V") || cmd === "version") return out("rumdl 0.1.13");
  if (!cmd || cmd === "help" || ((has(args, "--help") || has(args, "-h")) && !["check", "fmt", "init", "config", "schema", "import"].includes(cmd))) return help();
  if (cmd === "check" || cmd === "fmt") return runCheck(cmd, rest);
  if (cmd === "rule") return rest.length ? ruleInfo(rest[0]) : printRules();
  if (cmd === "explain") return rest.length ? (ruleInfo(rest[0]), out("\nWhat this rule does\n\n" + (RULES[normalizeRule(rest[0])]?.desc ?? "") + "\n\nExamples\n\nSee the rule documentation for examples.")) : printRules();
  if (cmd === "init") return init(rest);
  if (cmd === "config") return config(rest);
  if (cmd === "schema") return schema(rest);
  if (cmd === "clean") return out("Cache cleared");
  if (cmd === "server") return out("Language server mode is not available in this reimplementation");
  if (cmd === "vscode") return out("VS Code extension installation is not available in this environment");
  if (cmd === "completions") return out("# shell completions are not available");
  if (cmd === "import") {
    if (has(rest, "--help") || has(rest, "-h")) return out(`Import and convert markdownlint configuration files

Usage: executable import [OPTIONS] <FILE>

Arguments:
  <FILE>  Path to markdownlint config file (JSON/YAML)`);
    return out("# Converted markdownlint configuration\n[global]\n");
  }
  out(`error: unrecognized subcommand '${cmd}'`, true);
  process.exit(2);
}
main();
