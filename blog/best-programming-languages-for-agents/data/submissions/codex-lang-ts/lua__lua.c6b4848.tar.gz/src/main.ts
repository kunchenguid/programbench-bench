declare var require: any, process: any, console: any;
const fs = require('fs');

const NIL = null;
class LuaTable {
  map = new Map<any, any>();
  meta: LuaTable | null = null;
  get(k:any){ if(k===NIL || k===undefined) return NIL; return this.map.has(k)?this.map.get(k):NIL; }
  set(k:any,v:any){ if(k===NIL || k===undefined) throw new Error('table index is nil'); if(v===undefined) v=NIL; if(v===NIL) this.map.delete(k); else this.map.set(k,v); }
  len(){ let n=0; while(this.map.has(n+1)) n++; return n; }
  keys(){ return Array.from(this.map.keys()); }
}
class LuaMulti { constructor(public values:any[]){} }
class ReturnSignal { constructor(public values:any[]){} }
class BreakSignal {}
class Env {
  vars = new Map<string, any>();
  constructor(public parent: Env | null = null){}
  define(n:string,v:any=NIL){ this.vars.set(n,v); }
  get(n:string):any { if(this.vars.has(n)) return this.vars.get(n); if(this.parent) return this.parent.get(n); return NIL; }
  set(n:string,v:any){ if(this.vars.has(n)) this.vars.set(n,v); else if(this.parent) this.parent.set(n,v); else this.vars.set(n,v); }
}
function truthy(v:any){ return v!==NIL && v!==false; }
function luaType(v:any){ if(v===NIL || v===undefined) return 'nil'; if(v instanceof LuaTable) return 'table'; if(typeof v==='function' || v?.__luaFunc) return 'function'; if(typeof v==='boolean') return 'boolean'; if(typeof v==='number') return 'number'; if(typeof v==='string') return 'string'; return typeof v; }
function luaToString(v:any):string { if(v===NIL || v===undefined) return 'nil'; if(v===true) return 'true'; if(v===false) return 'false'; if(typeof v==='number') return Number.isInteger(v)?String(v):String(v); if(v instanceof LuaTable) return 'table: 0x'+(Math.abs(hash(v)).toString(16)); if(typeof v==='function' || v?.__luaFunc) return 'function: 0x'+(Math.abs(hash(v)).toString(16)); return String(v); }
const ids = new WeakMap<object,number>(); let nextId=0x10000; function hash(o:any){ if(typeof o!=='object' && typeof o!=='function') return 0; if(!ids.has(o)) ids.set(o,nextId+=0x111); return ids.get(o)!; }
function first(v:any){ return v instanceof LuaMulti ? (v.values[0]??NIL) : v; }
function values(v:any):any[]{ return v instanceof LuaMulti ? v.values : [v]; }

const keywords = new Set('and break do else elseif end false for function goto if in local nil not or repeat return then true until while'.split(' '));
type Tok={type:string,value:string,line:number};
class Lexer{
  i=0; line=1; toks:Tok[]=[];
  constructor(public s:string){ if(s.startsWith('#!')) this.i = s.indexOf('\n')>=0 ? s.indexOf('\n') : s.length; }
  peek(n=0){return this.s[this.i+n]||''}
  adv(){const c=this.s[this.i++]||''; if(c==='\n') this.line++; return c}
  lex(){ while(this.i<this.s.length){ let c=this.peek();
    if(/\s/.test(c)){this.adv(); continue;}
    if(c==='-'&&this.peek(1)==='-'){ this.adv(); this.adv(); if(this.peek()==='['&&this.peek(1)==='['){this.adv();this.adv(); while(this.i<this.s.length && !(this.peek()===']'&&this.peek(1)===']')) this.adv(); this.adv(); this.adv();} else {while(this.i<this.s.length&&this.peek()!=='\n') this.adv();} continue;}
    if(/[A-Za-z_]/.test(c)){ let st=this.i; while(/[A-Za-z0-9_]/.test(this.peek())) this.adv(); let v=this.s.slice(st,this.i); this.toks.push({type:keywords.has(v)?v:'id',value:v,line:this.line}); continue;}
    if(/[0-9]/.test(c) || (c==='.'&&/[0-9]/.test(this.peek(1)))){ let st=this.i; if(c==='0'&&(this.peek(1)==='x'||this.peek(1)==='X')){this.adv();this.adv(); while(/[0-9a-fA-F.]/.test(this.peek())) this.adv();} else {while(/[0-9]/.test(this.peek())) this.adv(); if(this.peek()==='.'&&this.peek(1)!=='.'){this.adv(); while(/[0-9]/.test(this.peek())) this.adv();} if(/[eE]/.test(this.peek())){this.adv(); if(/[+-]/.test(this.peek())) this.adv(); while(/[0-9]/.test(this.peek())) this.adv();}} this.toks.push({type:'num',value:this.s.slice(st,this.i),line:this.line}); continue;}
    if(c==='"'||c==="'"){ let q=this.adv(), out=''; while(this.i<this.s.length&&this.peek()!==q){ let ch=this.adv(); if(ch==='\\'){ let e=this.adv(); const m:any={n:'\n',t:'\t',r:'\r',a:'\x07',b:'\b',f:'\f',v:'\v','\\':'\\','"':'"',"'":"'"}; out+=m[e]??e; } else out+=ch;} this.adv(); this.toks.push({type:'str',value:out,line:this.line}); continue;}
    if(c==='['&&this.peek(1)==='['){this.adv();this.adv(); let out=''; while(this.i<this.s.length && !(this.peek()===']'&&this.peek(1)===']')) out+=this.adv(); this.adv();this.adv(); this.toks.push({type:'str',value:out,line:this.line}); continue;}
    const three=this.s.slice(this.i,this.i+3), two=this.s.slice(this.i,this.i+2); if(['...'].includes(three)){this.i+=3; this.toks.push({type:three,value:three,line:this.line}); continue;} if(['==','~=','<=','>=','..','//','::'].includes(two)){this.i+=2; this.toks.push({type:two,value:two,line:this.line}); continue;} this.adv(); this.toks.push({type:c,value:c,line:this.line});
  } this.toks.push({type:'eof',value:'',line:this.line}); return this.toks; }
}

type Node=any;
class Parser{
  p=0; constructor(public toks:Tok[]){} cur(){return this.toks[this.p]} is(t:string){return this.cur().type===t} eat(t?:string){let x=this.cur(); if(t&&x.type!==t) throw new Error(`syntax error near '${x.value||x.type}'`); this.p++; return x}
  block(stops=new Set<string>(['eof'])){let body:Node[]=[]; while(!stops.has(this.cur().type)){ if(this.is(';')){this.eat(); continue;} body.push(this.stmt()); } return body;}
  stmt():Node{ let t=this.cur().type;
    if(t==='local'){this.eat(); if(this.is('function')){this.eat(); const name=this.eat('id').value; const fn=this.funcbody(); return {k:'localfunc',name,fn};} let names=[this.eat('id').value]; while(this.is(',')){this.eat(); names.push(this.eat('id').value);} let exprs:Node[]=[]; if(this.is('=')){this.eat(); exprs=this.exprlist();} return {k:'local',names,exprs};}
    if(t==='function'){this.eat(); const target=this.funcname(); const fn=this.funcbody(); return {k:'funcdecl',target,fn};}
    if(t==='if'){this.eat(); const tests=[]; tests.push({cond:this.expr(),body:(this.eat('then'),this.block(new Set(['elseif','else','end'])))}); while(this.is('elseif')){this.eat(); tests.push({cond:this.expr(),body:(this.eat('then'),this.block(new Set(['elseif','else','end'])))});} let other:null|Node[]=null; if(this.is('else')){this.eat(); other=this.block(new Set(['end']));} this.eat('end'); return {k:'if',tests,other};}
    if(t==='do'){this.eat(); const body=this.block(new Set(['end'])); this.eat('end'); return {k:'do',body};}
    if(t==='while'){this.eat(); const cond=this.expr(); this.eat('do'); const body=this.block(new Set(['end'])); this.eat('end'); return {k:'while',cond,body};}
    if(t==='repeat'){this.eat(); const body=this.block(new Set(['until'])); this.eat('until'); const cond=this.expr(); return {k:'repeat',body,cond};}
    if(t==='for'){this.eat(); const name=this.eat('id').value; if(this.is('=')){this.eat(); const a=this.expr(); this.eat(','); const b=this.expr(); let c=null; if(this.is(',')){this.eat(); c=this.expr();} this.eat('do'); const body=this.block(new Set(['end'])); this.eat('end'); return {k:'fornum',name,a,b,c,body};} let names=[name]; while(this.is(',')){this.eat(); names.push(this.eat('id').value);} this.eat('in'); const exprs=this.exprlist(); this.eat('do'); const body=this.block(new Set(['end'])); this.eat('end'); return {k:'forgen',names,exprs,body};}
    if(t==='return'){this.eat(); let exprs:Node[]=[]; if(!['end','else','elseif','until','eof',';'].includes(this.cur().type)) exprs=this.exprlist(); return {k:'return',exprs};}
    if(t==='break'){this.eat(); return {k:'break'};}
    const e=this.prefix(); if(['var','idx'].includes(e.k) && (this.is('=')||this.is(','))){ const vars=[e]; while(this.is(',')){this.eat(); vars.push(this.prefix());} this.eat('='); return {k:'assign',vars,exprs:this.exprlist()}; } return {k:'exprstmt',expr:e}; }
  funcname(){ let e:any={k:'var',name:this.eat('id').value}; while(this.is('.')){this.eat(); e={k:'idx',obj:e,key:{k:'lit',v:this.eat('id').value}};} if(this.is(':')){this.eat(); e={k:'methodslot',obj:e,name:this.eat('id').value};} return e; }
  funcbody(){this.eat('('); let params:string[]=[], vararg=false; if(!this.is(')')){ if(this.is('...')){this.eat(); vararg=true;} else {params.push(this.eat('id').value); while(this.is(',')){this.eat(); if(this.is('...')){this.eat(); vararg=true; break;} params.push(this.eat('id').value);}}} this.eat(')'); const body=this.block(new Set(['end'])); this.eat('end'); return {k:'funcexpr',params,vararg,body};}
  exprlist(){let a=[this.expr()]; while(this.is(',')){this.eat(); a.push(this.expr());} return a;}
  expr(min=0):Node{ let left=this.unary(); const prec:any={or:1,and:2,'==':3,'~=':3,'<':3,'>':3,'<=':3,'>=':3,'..':4,'+':5,'-':5,'*':6,'/':6,'//':6,'%':6,'^':8}; while(true){let op=this.cur().type, p=prec[op]; if(!p||p<min) break; this.eat(); let right=this.expr(op==='^'||op==='..'?p:p+1); left={k:'bin',op,left,right};} return left;}
  unary(){ if(['not','-','#'].includes(this.cur().type)){let op=this.eat().type; return {k:'un',op,e:this.unary()};} return this.prefix();}
  prefix():Node{ let e:Node; if(this.is('num')){let v=this.eat().value; e={k:'lit',v:v.match(/^0x/i)?parseInt(v,16):Number(v)};} else if(this.is('str')) e={k:'lit',v:this.eat().value}; else if(this.is('nil')){this.eat(); e={k:'lit',v:NIL};} else if(this.is('true')){this.eat(); e={k:'lit',v:true};} else if(this.is('false')){this.eat(); e={k:'lit',v:false};} else if(this.is('...')){this.eat(); e={k:'vararg'};} else if(this.is('{')) e=this.table(); else if(this.is('function')){this.eat(); e=this.funcbody();} else if(this.is('(')){this.eat(); e=this.expr(); this.eat(')');} else e={k:'var',name:this.eat('id').value};
    while(true){ if(this.is('.')){this.eat(); e={k:'idx',obj:e,key:{k:'lit',v:this.eat('id').value}};} else if(this.is('[')){this.eat(); const key=this.expr(); this.eat(']'); e={k:'idx',obj:e,key};} else if(this.is(':')){this.eat(); const name=this.eat('id').value; const args=this.args(); e={k:'call',fn:{k:'idx',obj:e,key:{k:'lit',v:name}},args,self:e};} else if(this.is('(')||this.is('{')||this.is('str')){ e={k:'call',fn:e,args:this.args()};} else break;} return e;}
  args(){ if(this.is('(')){this.eat(); let a:Node[]=[]; if(!this.is(')')) a=this.exprlist(); this.eat(')'); return a;} if(this.is('{')) return [this.table()]; if(this.is('str')) return [{k:'lit',v:this.eat().value}]; return [];}
  table(){this.eat('{'); const fields:any[]=[]; while(!this.is('}')){ if(this.is('[')){this.eat(); const key=this.expr(); this.eat(']'); this.eat('='); fields.push({key,val:this.expr()});} else if(this.is('id')&&this.toks[this.p+1].type==='='){const key={k:'lit',v:this.eat().value}; this.eat('='); fields.push({key,val:this.expr()});} else fields.push({key:null,val:this.expr()}); if(this.is(',')||this.is(';')) this.eat(); else break;} this.eat('}'); return {k:'table',fields};}
}

class Runtime{
  global=new Env(); warnings=false;
  constructor(public scriptArgs:string[]=[]){ this.init(); }
  run(code:string,name='(command line)'){ const ast=new Parser(new Lexer(code).lex()).block(); try{this.execBlock(ast,this.global);}catch(e:any){ if(e instanceof ReturnSignal) return e.values; throw e;} }
  execBlock(body:Node[], env:Env){ for(const s of body) this.exec(s,env); }
  evalList(exprs:Node[], env:Env){ let out:any[]=[]; exprs.forEach((e,i)=>{let vs=values(this.eval(e,env)); if(i===exprs.length-1) out.push(...vs); else out.push(vs[0]??NIL);}); return out; }
  assignVar(v:Node,val:any,env:Env){ if(v.k==='var') env.set(v.name,val); else if(v.k==='idx'){ const o=first(this.eval(v.obj,env)); const k=first(this.eval(v.key,env)); if(!(o instanceof LuaTable)) throw new Error('attempt to index a '+luaType(o)+' value'); o.set(k,val);} else if(v.k==='methodslot'){ const o=first(this.eval(v.obj,env)); if(!(o instanceof LuaTable)) throw new Error('attempt to index a '+luaType(o)+' value'); o.set(v.name,val);} }
  exec(s:Node, env:Env):any{ switch(s.k){
    case 'local': {const vals=this.evalList(s.exprs,env); s.names.forEach((n:string,i:number)=>env.define(n, vals[i]??NIL)); break;}
    case 'localfunc': {env.define(s.name,NIL); env.set(s.name,this.makeFunc(s.fn,env)); break;}
    case 'do': this.execBlock(s.body,new Env(env)); break;
    case 'assign': {const vals=this.evalList(s.exprs,env); s.vars.forEach((v:Node,i:number)=>this.assignVar(v, vals[i]??NIL, env)); break;}
    case 'funcdecl': { if(s.target.k==='methodslot') s.fn.params=['self',...s.fn.params]; this.assignVar(s.target, this.makeFunc(s.fn,env), env); break;}
    case 'if': {for(const t of s.tests){ if(truthy(first(this.eval(t.cond,env)))){this.execBlock(t.body,new Env(env)); return;} } if(s.other) this.execBlock(s.other,new Env(env)); break;}
    case 'while': while(truthy(first(this.eval(s.cond,env)))){ try{this.execBlock(s.body,new Env(env));}catch(e){if(e instanceof BreakSignal) break; else throw e;} } break;
    case 'repeat': do{ try{this.execBlock(s.body,new Env(env));}catch(e){if(e instanceof BreakSignal) break; else throw e;} }while(!truthy(first(this.eval(s.cond,env)))); break;
    case 'fornum': {let a=Number(first(this.eval(s.a,env))), b=Number(first(this.eval(s.b,env))), c=s.c?Number(first(this.eval(s.c,env))):1; for(let i=a;c>=0?i<=b:i>=b;i+=c){let e=new Env(env); e.define(s.name,i); try{this.execBlock(s.body,e);}catch(x){if(x instanceof BreakSignal) break; else throw x;}} break;}
    case 'forgen': {const vals=this.evalList(s.exprs,env); if(vals[0]?.__iter){ for(const row of vals[0].__iter()){let e=new Env(env); s.names.forEach((n:string,i:number)=>e.define(n,row[i]??NIL)); try{this.execBlock(s.body,e);}catch(x){if(x instanceof BreakSignal) break; else throw x;}} } break;}
    case 'return': throw new ReturnSignal(this.evalList(s.exprs,env));
    case 'break': throw new BreakSignal();
    case 'exprstmt': this.eval(s.expr,env); break;
  }}
  eval(e:Node, env:Env):any{ switch(e.k){
    case 'lit': return e.v; case 'var': return env.get(e.name); case 'vararg': return new LuaMulti(env.get('...')??[]);
    case 'idx': {const o=first(this.eval(e.obj,env)), k=first(this.eval(e.key,env)); if(o instanceof LuaTable) return o.get(k); if(typeof o==='string'){ if(k==='len') return o.length; const st=env.get('string'); if(st instanceof LuaTable){ const m=st.get(k); if(m!==NIL) return m; }} return NIL;}
    case 'table': {const t=new LuaTable(); let ai=1; for(const f of e.fields){let val=first(this.eval(f.val,env)); if(f.key) t.set(first(this.eval(f.key,env)),val); else t.set(ai++,val);} return t;}
    case 'funcexpr': return this.makeFunc(e,env);
    case 'un': {const v=first(this.eval(e.e,env)); if(e.op==='not') return !truthy(v); if(e.op==='-') return -Number(v); if(e.op==='#') return v instanceof LuaTable?v.len():String(v??'').length;}
    case 'bin': { if(e.op==='and'){const l=first(this.eval(e.left,env)); return truthy(l)?first(this.eval(e.right,env)):l;} if(e.op==='or'){const l=first(this.eval(e.left,env)); return truthy(l)?l:first(this.eval(e.right,env));} const a=first(this.eval(e.left,env)), b=first(this.eval(e.right,env)); switch(e.op){case '+':return Number(a)+Number(b);case '-':return Number(a)-Number(b);case '*':return Number(a)*Number(b);case '/':return Number(a)/Number(b);case '//':return Math.floor(Number(a)/Number(b));case '%':return Number(a)%Number(b);case '^':return Math.pow(Number(a),Number(b));case '..':return luaToString(a)+luaToString(b);case '==':return a===b;case '~=':return a!==b;case '<':return a<b;case '>':return a>b;case '<=':return a<=b;case '>=':return a>=b;} }
    case 'call': {const fn=first(this.eval(e.fn,env)); let args=this.evalList(e.args,env); if(e.self) args.unshift(first(this.eval(e.self,env))); return this.call(fn,args);}
  }}
  makeFunc(n:Node, closure:Env){ const rt=this; return {__luaFunc:true, call(args:any[]){const e=new Env(closure); n.params.forEach((p:string,i:number)=>e.define(p,args[i]??NIL)); if(n.vararg) e.define('...',args.slice(n.params.length)); try{rt.execBlock(n.body,e); return [];}catch(x:any){ if(x instanceof ReturnSignal) return x.values; throw x;}}}; }
  call(fn:any,args:any[]):any{ if(fn?.__luaFunc) return new LuaMulti(fn.call(args)); if(typeof fn==='function') {const r=fn(...args); return r instanceof LuaMulti?r:(Array.isArray(r)?new LuaMulti(r):r);} throw new Error('attempt to call a '+luaType(fn)+' value'); }
  tbl(obj:any){ const t=new LuaTable(); for(const [k,v] of Object.entries(obj)) t.set(k,v); return t; }
  init(){ const g=this.global; g.define('_VERSION','Lua 5.5'); const rt=this;
    const print=(...a:any[])=>{process.stdout.write(a.map(luaToString).join('\t')+'\n'); return NIL;};
    Object.entries({print,type:luaType,tostring:luaToString,tonumber:(x:any,b?:any)=>{if(x===NIL)return NIL; const n=b?parseInt(String(x),Number(b)):Number(x); return Number.isNaN(n)?NIL:n;},assert:(v:any,msg?:any)=>{if(!truthy(v)) throw new Error(msg?String(msg):'assertion failed!'); return v;},error:(m:any)=>{throw new Error(String(m));},select:(what:any,...xs:any[])=>what==='#'?xs.length:new LuaMulti(xs.slice(Number(what)-1)),pcall:(f:any,...xs:any[])=>{try{return new LuaMulti([true,...values(rt.call(f,xs))]);}catch(e:any){return new LuaMulti([false,e.message]);}},rawequal:(a:any,b:any)=>a===b,rawget:(t:any,k:any)=>t instanceof LuaTable?t.get(k):NIL,rawset:(t:any,k:any,v:any)=>{if(t instanceof LuaTable)t.set(k,v); return t;},next:(t:any,k?:any)=>{if(!(t instanceof LuaTable))return NIL; const ks=t.keys(); let idx=k===NIL||k===undefined?-1:ks.findIndex(x=>x===k); const nk=ks[idx+1]; return nk===undefined?NIL:new LuaMulti([nk,t.get(nk)]);},pairs:(t:any)=>({__iter:function*(){if(t instanceof LuaTable) for(const k of t.keys()) yield [k,t.get(k)];}}),ipairs:(t:any)=>({__iter:function*(){if(t instanceof LuaTable) for(let i=1;t.get(i)!==NIL;i++) yield [i,t.get(i)];}}),require:(m:any)=>rt.global.get(String(m))}).forEach(([k,v])=>g.define(k,v));
    g.define('math',this.tbl({abs:Math.abs,acos:Math.acos,asin:Math.asin,atan:Math.atan,ceil:Math.ceil,cos:Math.cos,deg:(x:number)=>x*180/Math.PI,exp:Math.exp,floor:Math.floor,fmod:(a:number,b:number)=>a%b,huge:Infinity,log:Math.log,max:Math.max,min:Math.min,modf:(x:number)=>new LuaMulti([x<0?Math.ceil(x):Math.floor(x),x-(x<0?Math.ceil(x):Math.floor(x))]),pi:Math.PI,rad:(x:number)=>x*Math.PI/180,random:(a?:number,b?:number)=>{const r=Math.random(); if(a===undefined)return r; if(b===undefined)return Math.floor(r*a)+1; return Math.floor(r*(b-a+1))+a;},randomseed:()=>NIL,sin:Math.sin,sqrt:Math.sqrt,tan:Math.tan,type:(x:any)=>Number.isInteger(x)?'integer':'float'}));
    g.define('string',this.tbl({byte:(s:string,i=1)=>s.charCodeAt(i-1)||NIL,char:(...cs:number[])=>String.fromCharCode(...cs),find:(s:string,p:string,init=1)=>{const x=s.indexOf(p,init-1);return x<0?NIL:new LuaMulti([x+1,x+p.length]);},format:(fmt:string,...xs:any[])=>fmt.replace(/%[sdifq]/g,(m:string)=>luaToString(xs.shift())),gsub:(s:string,p:string,r:string)=>new LuaMulti([s.split(p).join(r),s.split(p).length-1]),len:(s:string)=>String(s).length,lower:(s:string)=>String(s).toLowerCase(),match:(s:string,p:string)=>{const m=String(s).match(new RegExp(p));return m?m[0]:NIL;},rep:(s:string,n:number,sep='')=>Array(Number(n)).fill(s).join(sep),reverse:(s:string)=>String(s).split('').reverse().join(''),sub:(s:string,i:number,j?:number)=>String(s).slice(i<0?String(s).length+i:i-1,j&&j<0?String(s).length+j+1:j),upper:(s:string)=>String(s).toUpperCase()}));
    g.define('table',this.tbl({concat:(t:LuaTable,sep='',i=1,j?:number)=>{let n=j??t.len(), a=[]; for(let k=i;k<=n;k++) a.push(luaToString(t.get(k))); return a.join(sep);},insert:(t:LuaTable,pos:any,val?:any)=>{if(val===undefined){val=pos; pos=t.len()+1;} for(let i=t.len()+1;i>pos;i--) t.set(i,t.get(i-1)); t.set(pos,val);},remove:(t:LuaTable,pos?:number)=>{pos=pos??t.len(); const v=t.get(pos); for(let i=pos;i<t.len();i++) t.set(i,t.get(i+1)); t.set(t.len(),NIL); return v;},sort:(t:LuaTable)=>{let a=[]; for(let i=1;i<=t.len();i++) a.push(t.get(i)); a.sort(); a.forEach((v,i)=>t.set(i+1,v));}}));
    g.define('os',this.tbl({clock:()=>process.uptime(),date:(fmt?:string)=>new Date().toString(),difftime:(a:number,b:number)=>a-b,execute:(cmd?:string)=>cmd?require('child_process').execSync(cmd,{stdio:'inherit'}):true,exit:(code=0)=>process.exit(code),getenv:(n:string)=>process.env[n]??NIL,time:()=>Math.floor(Date.now()/1000),tmpname:()=>'/tmp/lua_'+Math.random().toString(16).slice(2)}));
    g.define('io',this.tbl({write:(...xs:any[])=>{process.stdout.write(xs.map(luaToString).join('')); return true;},read:(fmt?:any)=>{const data=fs.readFileSync(0,'utf8'); return data.length?data:NIL;},open:(p:string,mode='r')=>{try{let fd=fs.openSync(p,mode.includes('w')?'w':'r'); return this.tbl({read:()=>fs.readFileSync(fd,'utf8'),write:(x:any)=>fs.writeSync(fd,String(x)),close:()=>fs.closeSync(fd)});}catch(e:any){return new LuaMulti([NIL,e.message]);}}}));
    g.define('dofile',(p:string)=>rt.run(fs.readFileSync(p,'utf8'),p)); g.define('loadfile',(p:string)=>rt.makeFunc({k:'funcexpr',params:[],vararg:false,body:new Parser(new Lexer(fs.readFileSync(p,'utf8')).lex()).block()},rt.global)); g.define('load',(code:string)=>rt.makeFunc({k:'funcexpr',params:[],vararg:false,body:new Parser(new Lexer(String(code)).lex()).block()},rt.global));
    g.define('debug',new LuaTable()); g.define('coroutine',new LuaTable()); g.define('utf8',this.tbl({len:(s:string)=>Array.from(String(s)).length,codes:(s:string)=>({__iter:function*(){let i=1; for(const ch of String(s)){yield [i,ch.codePointAt(0)]; i+=ch.length;}}})}));
    const argt=new LuaTable(); this.scriptArgs.forEach((a,i)=>argt.set(i,a)); g.define('arg',argt);
  }
}

const usage=`usage: ./executable [options] [script [args]]
Available options are:
  -e stat   execute string 'stat'
  -i        enter interactive mode after executing 'script'
  -l mod    require library 'mod' into global 'mod'
  -l g=mod  require library 'mod' into global 'g'
  -v        show version information
  -E        ignore environment variables
  -W        turn warnings on
  --        stop handling options
  -         stop handling options and execute stdin`;
function main(){ const argv=process.argv.slice(2); let chunks:string[]=[], script:string|null=null, sargs:string[]=[], interactive=false; for(let i=0;i<argv.length;i++){const a=argv[i]; if(a==='-v'){console.log('Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio');} else if(a==='-i') interactive=true; else if(a==='-E'||a==='-W'){} else if(a==='-e'){chunks.push(argv[++i]??'');} else if(a.startsWith('-e')&&a.length>2){chunks.push(a.slice(2));} else if(a==='-l'){const spec=argv[++i]||''; const eq=spec.indexOf('='); chunks.push(eq>=0?`${spec.slice(0,eq)} = require('${spec.slice(eq+1)}')`:`${spec} = require('${spec}')`);} else if(a==='--'){script=argv[++i]??null; sargs=argv.slice(i+1); break;} else if(a==='-'){script='-'; sargs=argv.slice(i+1); break;} else if(a.startsWith('-')){process.stderr.write(`./executable: unrecognized option '${a}'\n${usage}\n`); process.exit(1);} else {script=a; sargs=argv.slice(i+1); break;}} const rt=new Runtime([script??'./executable',...sargs]); try{ for(const c of chunks) rt.run(c); if(script){const code=script==='-'?fs.readFileSync(0,'utf8'):fs.readFileSync(script,'utf8'); rt.run(code,script);} if(interactive||(!script&&chunks.length===0&&process.stdin.isTTY)){ if(!chunks.length&&!script) console.log('Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio'); const data=fs.readFileSync(0,'utf8'); if(data.trim()) rt.run(data,'stdin'); } else if(!script&&chunks.length===0){ const data=fs.readFileSync(0,'utf8'); if(data.trim()) rt.run(data,'stdin'); }}catch(e:any){process.stderr.write(`./executable: ${e.message}\n`); process.exit(1);} }
main();
