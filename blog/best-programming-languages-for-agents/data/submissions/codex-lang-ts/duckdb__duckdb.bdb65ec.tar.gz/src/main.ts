const fs = require("fs");
const path = require("path");

type Value = string | number | boolean | null | Value[];
type Row = Record<string, Value>;
type Column = { name: string; type: string };
type Result = { columns: Column[]; rows: Row[] };
type Table = { columns: Column[]; rows: Row[]; sql?: string };
type Database = { tables: Record<string, Table> };

type Options = {
  mode: string;
  header: boolean;
  nullValue: string;
  separator: string;
  newline: string;
  echo: boolean;
  bail: boolean;
  noStdin: boolean;
  dbFile: string | null;
  commands: string[];
  initFiles: string[];
};

const VERSION = "v0.0.1 (Unknown Version) 780a7396";

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if ((opts as any).exitCode !== undefined) process.exit((opts as any).exitCode);
  const db = loadDb(opts.dbFile);
  let status = 0;
  try {
    for (const file of opts.initFiles) runScript(fs.readFileSync(file, "utf8"), opts, db);
    for (const command of opts.commands) runScript(command, opts, db);
    if (!opts.noStdin && opts.commands.length === 0 && !process.stdin.isTTY) {
      runScript(fs.readFileSync(0, "utf8"), opts, db);
    }
    saveDb(opts.dbFile, db);
  } catch (err: any) {
    status = 1;
    process.stderr.write((err && err.message ? err.message : String(err)) + "\n");
  }
  process.exit(status);
}

function parseArgs(args: string[]): Options {
  const opts: Options = {
    mode: "duckbox",
    header: true,
    nullValue: "NULL",
    separator: "|",
    newline: "\n",
    echo: false,
    bail: false,
    noStdin: false,
    dbFile: null,
    commands: [],
    initFiles: [],
  };
  const modes = new Set(["ascii", "box", "column", "csv", "html", "json", "jsonlines", "line", "list", "markdown", "quote", "table"]);
  const needValue = (i: number, opt: string) => {
    if (i + 1 >= args.length) die(`Missing argument for ${opt}`);
    return args[i + 1];
  };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "-help" || a === "--help") {
      printHelp();
      return Object.assign(opts, { exitCode: 0 });
    } else if (a === "-version" || a === "--version") {
      console.log(VERSION);
      return Object.assign(opts, { exitCode: 0 });
    } else if (a === "-c" || a === "-s" || a === "-cmd") {
      opts.commands.push(needValue(i, a));
      i++;
      if (a === "-c" || a === "-s") opts.noStdin = true;
    } else if (a === "-f" || a === "-init" || a === "-format-file") {
      const file = needValue(i, a);
      i++;
      if (a === "-format-file") {
        console.log(formatSql(fs.readFileSync(file, "utf8")));
        return Object.assign(opts, { exitCode: 0 });
      }
      if (a === "-f") {
        opts.commands.push(fs.readFileSync(file, "utf8"));
        opts.noStdin = true;
      } else opts.initFiles.push(file);
    } else if (a === "-format") {
      console.log(formatSql(fs.readFileSync(0, "utf8")));
      return Object.assign(opts, { exitCode: 0 });
    } else if (a === "-header") opts.header = true;
    else if (a === "-noheader") opts.header = false;
    else if (a === "-separator") { opts.separator = decodeSep(needValue(i, a)); i++; }
    else if (a === "-newline") { opts.newline = decodeSep(needValue(i, a)); i++; }
    else if (a === "-nullvalue") { opts.nullValue = needValue(i, a); i++; }
    else if (a === "-echo") opts.echo = true;
    else if (a === "-bail") opts.bail = true;
    else if (a === "-no-stdin") opts.noStdin = true;
    else if (a === "-batch" || a === "-interactive" || a === "-readonly" || a === "-safe" || a === "-unsigned" || a === "-unredacted" || a === "-no-init" || a === "-ui") {
      // Accepted for CLI compatibility.
    } else if (a === "-storage-version") { i++; }
    else if (modes.has(a.replace(/^-/, ""))) opts.mode = a.replace(/^-/, "");
    else if (a.startsWith("-")) {
      process.stderr.write(`Unknown Option Error: Unrecognized option '${a}'\n\nRun './executable -help' for a list of options.\n`);
      return Object.assign(opts, { exitCode: 1 });
    } else if (!opts.dbFile && (a === ":memory:" || !looksLikeSql(a))) opts.dbFile = a === ":memory:" ? null : a;
    else { opts.commands.push(a); opts.noStdin = true; }
  }
  return opts;
}

function printHelp() {
  console.log(`Usage: ./executable [OPTIONS] FILENAME [SQL]

FILENAME is the name of a DuckDB database. A new database is created
if the file does not previously exist.

OPTIONS:
  -ascii                   set output mode to 'ascii'
  -bail                    stop after hitting an error
  -batch                   force batch I/O'
  -box                     set output mode to 'box'
  -column                  set output mode to 'column'
  -cmd COMMAND             run "COMMAND" before reading stdin
  -csv                     set output mode to 'csv'
  -c COMMAND               run "COMMAND" and exit
  -echo                    print commands before execution
  -f FILENAME              read/process named file and exit
  -format                  format SQL from stdin, writing result to stdout
  -format-file FILENAME    format SQL in file, writing result to stdout
  -init FILENAME           read/process named file
  -header                  turn headers on
  -h                       show help message
  -help                    show help message
  -html                    set output mode to HTML
  -interactive             force interactive I/O
  -json                    set output mode to 'json'
  -jsonlines               set output mode to 'jsonlines'
  -line                    set output mode to 'line'
  -list                    set output mode to 'list'
  -markdown                set output mode to 'markdown'
  -newline SEP             set output row separator. Default: '\\n'
  -no-init                 skip processing the init file
  -no-stdin                exit after processing options instead of reading stdin
  -noheader                turn headers off
  -nullvalue TEXT          set text string for NULL values. Default 'NULL'
  -quote                   set output mode to 'quote'
  -readonly                open the database read-only
  -s COMMAND               run "COMMAND" and exit
  -safe                    enable safe-mode
  -separator SEP           set output column separator. Default: '|'
  -storage-version VER     database storage compatibility version to use. Default: 'v0.10.0'
  -table                   set output mode to 'table'
  -ui                      launches a web interface using the ui extension (configurable with .ui_command)
  -unredacted              allow printing unredacted secrets
  -unsigned                allow loading of unsigned extensions
  -version                 show DuckDB version`);
}

function runScript(script: string, opts: Options, db: Database) {
  for (const stmt of splitStatements(script)) {
    const s = stmt.trim();
    if (!s) continue;
    if (opts.echo) process.stdout.write(s + "\n");
    try {
      const res = execute(s, db);
      if (res) process.stdout.write(render(res, opts));
    } catch (e) {
      if (opts.bail) throw e;
      throw e;
    }
  }
}

function execute(stmt: string, db: Database): Result | null {
  const lower = stmt.trim().toLowerCase();
  if (stmt.trim().startsWith(".")) return dotCommand(stmt.trim(), db);
  if (/^create\s+(?:or\s+replace\s+)?table/i.test(stmt)) return createTable(stmt, db);
  if (/^insert\s+into/i.test(stmt)) return insertInto(stmt, db);
  if (/^drop\s+table/i.test(stmt)) { const m = /drop\s+table\s+(?:if\s+exists\s+)?([A-Za-z_][\w]*)/i.exec(stmt); if (m) delete db.tables[m[1].toLowerCase()]; return null; }
  if (/^show\s+tables/i.test(stmt)) return showTables(db);
  if (/^describe\s+/i.test(stmt) || /^desc\s+/i.test(stmt)) return describe(stmt, db);
  if (/^select\s+/i.test(stmt) || /^with\s+/i.test(stmt)) return select(stmt, db);
  if (/^values\s+/i.test(stmt)) return valuesResult(stmt.replace(/^values\s+/i, ""));
  if (/^(pragma|set|load|install|attach|detach|use|begin|commit|rollback|checkpoint|vacuum)\b/i.test(stmt)) return null;
  throw new Error(`Parser Error: syntax error at or near "${stmt.split(/\s+/)[0]}"`);
}

function dotCommand(stmt: string, db: Database): Result | null {
  const [cmd, ...rest] = stmt.split(/\s+/);
  if (cmd === ".tables") return showTables(db);
  if (cmd === ".schema") {
    for (const name of Object.keys(db.tables).sort()) console.log(db.tables[name].sql || schemaSql(name, db.tables[name]));
    return null;
  }
  if (cmd === ".read") return execute(fs.readFileSync(rest.join(" "), "utf8"), db);
  if (cmd === ".quit" || cmd === ".exit") process.exit(0);
  return null;
}

function createTable(stmt: string, db: Database): Result | null {
  const asMatch = /^create\s+(?:or\s+replace\s+)?table\s+([A-Za-z_][\w]*)\s+as\s+(.+)$/is.exec(stmt);
  if (asMatch) {
    const res = select(asMatch[2], db);
    db.tables[asMatch[1].toLowerCase()] = { columns: res.columns, rows: res.rows, sql: schemaSql(asMatch[1], { columns: res.columns, rows: res.rows }) };
    return null;
  }
  const m = /^create\s+(?:or\s+replace\s+)?table\s+([A-Za-z_][\w]*)\s*\((.*)\)$/is.exec(stmt);
  if (!m) throw new Error("Parser Error: syntax error at or near \"create\"");
  const columns = splitTop(m[2], ",").map((part) => {
    const bits = part.trim().split(/\s+/);
    return { name: unquoteIdent(bits[0]), type: normalizeType(bits.slice(1).join(" ") || "varchar") };
  });
  db.tables[m[1].toLowerCase()] = { columns, rows: [], sql: `CREATE TABLE ${m[1]}(${columns.map(c => `${c.name} ${c.type.toUpperCase()}`).join(", ")});` };
  return null;
}

function insertInto(stmt: string, db: Database): Result | null {
  const m = /^insert\s+into\s+([A-Za-z_][\w]*)\s*(?:\(([^)]*)\))?\s+values\s*(.+)$/is.exec(stmt);
  if (!m) throw new Error("Parser Error: syntax error at or near \"insert\"");
  const table = db.tables[m[1].toLowerCase()];
  if (!table) throw new Error(`Catalog Error: Table with name ${m[1]} does not exist!`);
  const names = m[2] ? splitTop(m[2], ",").map(s => unquoteIdent(s.trim())) : table.columns.map(c => c.name);
  for (const group of parseValueGroups(m[3])) {
    const vals = splitTop(group, ",").map(x => evalExpr(x, {}));
    const row: Row = {};
    for (const c of table.columns) row[c.name] = null;
    names.forEach((n, i) => row[n] = vals[i] ?? null);
    table.rows.push(row);
  }
  return null;
}

function select(stmt: string, db: Database): Result {
  stmt = stmt.replace(/;\s*$/, "").trim();
  const sm = /^select\s+(.+)$/is.exec(stmt);
  if (!sm) throw new Error("Parser Error: only simple SELECT statements are supported");
  let body = sm[1].trim();
  let limit: number | null = null;
  body = body.replace(/\s+limit\s+(\d+)\s*$/i, (_: string, n: string) => { limit = Number(n); return ""; });
  let orderBy: string | null = null;
  body = body.replace(/\s+order\s+by\s+([A-Za-z_][\w]*|\d+)(?:\s+(asc|desc))?\s*$/i, (_: string, col: string, dir: string) => { orderBy = col + (dir ? " " + dir : ""); return ""; });
  const fromIdx = findKeyword(body, "from");
  let rows: Row[] = [{}];
  let sourceCols: Column[] = [];
  let exprText = body;
  if (fromIdx >= 0) {
    exprText = body.slice(0, fromIdx).trim();
    let rest = body.slice(fromIdx + 4).trim();
    let whereText = "";
    const whereIdx = findKeyword(rest, "where");
    if (whereIdx >= 0) { whereText = rest.slice(whereIdx + 5).trim(); rest = rest.slice(0, whereIdx).trim(); }
    const source = sourceRows(rest, db);
    rows = source.rows;
    sourceCols = source.columns;
    if (whereText) rows = rows.filter(r => truthy(evalExpr(whereText, r)));
  }
  if (orderBy) {
    const [col, dir] = orderBy.split(/\s+/);
    rows.sort((a, b) => cmp(a[col] ?? a[sourceCols[Number(col) - 1]?.name], b[col] ?? b[sourceCols[Number(col) - 1]?.name]) * (String(dir).toLowerCase() === "desc" ? -1 : 1));
  }
  if (limit !== null) rows = rows.slice(0, limit);
  if (exprText === "*") return { columns: sourceCols, rows };
  const exprs = splitTop(exprText, ",");
  if (exprs.every(e => /^(count|sum|avg|min|max)\s*\(/i.test(parseAlias(e).expr))) {
    const out: Row = {};
    const columns = exprs.map(e => {
      const p = parseAlias(e);
      const m = /^(count|sum|avg|min|max)\s*\((.*)\)$/is.exec(p.expr)!;
      const name = p.alias || defaultName(p.expr);
      const vals = m[2].trim() === "*" ? rows.map(() => 1) : rows.map(r => evalExpr(m[2], r)).filter(v => v !== null);
      let v: Value = null;
      const nums = vals.map(Number);
      if (m[1].toLowerCase() === "count") v = vals.length;
      else if (m[1].toLowerCase() === "sum") v = nums.reduce((a, b) => a + b, 0);
      else if (m[1].toLowerCase() === "avg") v = nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : null;
      else if (m[1].toLowerCase() === "min") v = vals.reduce((a: any, b: any) => cmp(a, b) <= 0 ? a : b, vals[0] as any) ?? null;
      else if (m[1].toLowerCase() === "max") v = vals.reduce((a: any, b: any) => cmp(a, b) >= 0 ? a : b, vals[0] as any) ?? null;
      out[name] = v;
      return { name, type: inferType(v) };
    });
    return { columns, rows: [out] };
  }
  const columns = exprs.map(e => {
    const p = parseAlias(e);
    return { name: p.alias || defaultName(p.expr), type: "varchar" };
  });
  const outRows = rows.map(r => {
    const out: Row = {};
    exprs.forEach((e, i) => {
      const p = parseAlias(e);
      const v = evalExpr(p.expr, r);
      out[columns[i].name] = v;
      columns[i].type = commonType(columns[i].type, inferType(v));
    });
    return out;
  });
  return { columns, rows: outRows };
}

function sourceRows(rest: string, db: Database): Result {
  const values = /^\(?\s*values\s*(.+)\)?$/is.exec(rest);
  if (values) return valuesResult(values[1]);
  const quoted = /^['"](.+)['"]$/s.exec(rest);
  if (quoted) return readCsv(quoted[1]);
  const tableName = rest.split(/\s+/)[0].replace(/["`]/g, "").toLowerCase();
  const table = db.tables[tableName];
  if (!table) throw new Error(`Catalog Error: Table with name ${tableName} does not exist!`);
  return { columns: table.columns, rows: table.rows.map(r => ({ ...r })) };
}

function valuesResult(text: string): Result {
  const groups = parseValueGroups(text);
  const matrix = groups.map(g => splitTop(g, ",").map(x => evalExpr(x, {})));
  const max = Math.max(0, ...matrix.map(r => r.length));
  const columns = Array.from({ length: max }, (_, i) => ({ name: `col${i}`, type: commonType("varchar", ...matrix.map(r => inferType(r[i]))) }));
  const rows = matrix.map(vals => {
    const r: Row = {};
    columns.forEach((c, i) => r[c.name] = vals[i] ?? null);
    return r;
  });
  return { columns, rows };
}

function describe(stmt: string, db: Database): Result {
  const target = stmt.replace(/^(describe|desc)\s+/i, "").trim();
  if (/^select\s+/i.test(target)) {
    const res = select(target, db);
    return { columns: [{ name: "column_name", type: "varchar" }, { name: "column_type", type: "varchar" }, { name: "null", type: "varchar" }, { name: "key", type: "varchar" }, { name: "default", type: "varchar" }, { name: "extra", type: "varchar" }], rows: res.columns.map(c => ({ column_name: c.name, column_type: c.type.toUpperCase(), null: "YES", key: null, default: null, extra: null })) };
  }
  const table = db.tables[target.toLowerCase()];
  if (!table) throw new Error(`Catalog Error: Table with name ${target} does not exist!`);
  return { columns: [{ name: "column_name", type: "varchar" }, { name: "column_type", type: "varchar" }, { name: "null", type: "varchar" }, { name: "key", type: "varchar" }, { name: "default", type: "varchar" }, { name: "extra", type: "varchar" }], rows: table.columns.map(c => ({ column_name: c.name, column_type: c.type.toUpperCase(), null: "YES", key: null, default: null, extra: null })) };
}

function showTables(db: Database): Result {
  return { columns: [{ name: "name", type: "varchar" }], rows: Object.keys(db.tables).sort().map(name => ({ name })) };
}

function evalExpr(expr: string, row: Row): Value {
  expr = expr.trim();
  if (/^\((.*)\)$/s.test(expr) && balanced(expr.slice(1, -1))) return evalExpr(expr.slice(1, -1), row);
  const orIdx = findKeyword(expr, "or");
  if (orIdx >= 0) return truthy(evalExpr(expr.slice(0, orIdx), row)) || truthy(evalExpr(expr.slice(orIdx + 2), row));
  const andIdx = findKeyword(expr, "and");
  if (andIdx >= 0) return truthy(evalExpr(expr.slice(0, andIdx), row)) && truthy(evalExpr(expr.slice(andIdx + 3), row));
  const isNull = /^(.+?)\s+is\s+(not\s+)?null$/is.exec(expr);
  if (isNull) return (evalExpr(isNull[1], row) === null) !== !!isNull[2];
  const like = /^(.+?)\s+like\s+(.+)$/is.exec(expr);
  if (like) {
    const left = String(evalExpr(like[1], row) ?? "");
    const pat = String(evalExpr(like[2], row) ?? "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/%/g, ".*").replace(/_/g, ".");
    return new RegExp("^" + pat + "$").test(left);
  }
  if (/^null$/i.test(expr)) return null;
  if (/^true$/i.test(expr)) return true;
  if (/^false$/i.test(expr)) return false;
  if (/^'.*'$/s.test(expr)) return expr.slice(1, -1).replace(/''/g, "'");
  if (/^".*"$/.test(expr) && row[expr.slice(1, -1)] === undefined) return expr.slice(1, -1);
  if (/^-?\d+(?:\.\d+)?$/.test(expr)) return Number(expr);
  const fn = /^([A-Za-z_][\w]*)\s*\((.*)\)$/s.exec(expr);
  if (fn) {
    const args = fn[2].trim() ? splitTop(fn[2], ",").map(a => evalExpr(a, row)) : [];
    const name = fn[1].toLowerCase();
    if (name === "upper") return String(args[0] ?? "").toUpperCase();
    if (name === "lower") return String(args[0] ?? "").toLowerCase();
    if (name === "length" || name === "len") return String(args[0] ?? "").length;
    if (name === "concat") return args.map(a => a ?? "").join("");
    if (name === "range") return Array.from({ length: Number(args[0] ?? 0) }, (_, i) => i);
    if (name === "coalesce") return args.find(a => a !== null && a !== undefined) ?? null;
    if (name === "abs") return Math.abs(Number(args[0]));
    if (name === "round") return Math.round(Number(args[0]));
    if (name === "sqrt") return Math.sqrt(Number(args[0]));
  }
  const cmpOps = ["<=", ">=", "<>", "!=", "=", "<", ">"];
  for (const op of cmpOps) {
    const idx = findOp(expr, op);
    if (idx >= 0) {
      const a = evalExpr(expr.slice(0, idx), row), b = evalExpr(expr.slice(idx + op.length), row);
      if (op === "=") return a == b;
      if (op === "!=" || op === "<>") return a != b;
      if (op === "<") return cmp(a, b) < 0;
      if (op === ">") return cmp(a, b) > 0;
      if (op === "<=") return cmp(a, b) <= 0;
      if (op === ">=") return cmp(a, b) >= 0;
    }
  }
  for (const ops of [["+", "-"], ["*", "/", "%"]]) {
    for (let i = expr.length - 1, depth = 0, quote = false; i >= 0; i--) {
      const ch = expr[i];
      if (ch === "'") quote = !quote;
      if (quote) continue;
      if (ch === ")") depth++;
      else if (ch === "(") depth--;
      else if (depth === 0 && ops.includes(ch) && i > 0) {
        const a = Number(evalExpr(expr.slice(0, i), row));
        const b = Number(evalExpr(expr.slice(i + 1), row));
        if (ch === "+") return a + b;
        if (ch === "-") return a - b;
        if (ch === "*") return a * b;
        if (ch === "/") return a / b;
        return a % b;
      }
    }
  }
  const key = unquoteIdent(expr);
  if (Object.prototype.hasOwnProperty.call(row, key)) return row[key];
  throw new Error(`Binder Error: Referenced column "${expr}" was not found because the FROM clause is missing`);
}

function render(res: Result, opts: Options): string {
  const cols = res.columns;
  const rows = res.rows;
  if (opts.mode === "json") return JSON.stringify(rows.map(r => jsonRow(r, cols))) + opts.newline;
  if (opts.mode === "jsonlines") return rows.map(r => JSON.stringify(jsonRow(r, cols))).join(opts.newline) + (rows.length ? opts.newline : "");
  if (opts.mode === "line") return rows.map(r => cols.map(c => `${c.name.padStart(5)} = ${val(r[c.name], opts)}`).join(opts.newline)).join(opts.newline + opts.newline) + (rows.length ? opts.newline : "");
  if (opts.mode === "csv") return delimited(res, ",", opts, csvCell);
  if (opts.mode === "list") return delimited(res, opts.separator, opts, x => val(x, opts));
  if (opts.mode === "quote") return delimited(res, opts.separator, opts, quoteCell);
  if (opts.mode === "html") return html(res, opts);
  if (opts.mode === "ascii") return ascii(res, opts);
  if (opts.mode === "column") return column(res, opts);
  if (opts.mode === "markdown") return table(res, opts, "markdown");
  if (opts.mode === "table") return table(res, opts, "ascii");
  return table(res, opts, opts.mode === "duckbox" ? "duckbox" : "box");
}

function table(res: Result, opts: Options, style: string): string {
  const includeTypes = style === "duckbox";
  const data = [res.columns.map(c => c.name), ...(includeTypes ? [res.columns.map(c => c.type)] : []), ...res.rows.map(r => res.columns.map(c => val(r[c.name], opts)))];
  const widths = res.columns.map((_, i) => Math.max(1, ...data.map(row => String(row[i] ?? "").length)));
  const align = (s: string, w: number, right: boolean) => right ? s.padStart(w) : s.padEnd(w);
  const rowLine = (cells: string[], bars: string[]) => bars[0] + cells.map((c, i) => ` ${align(c, widths[i], isNumericText(c))} `).join(bars[1]) + bars[2] + "\n";
  let out = "";
  if (style === "markdown") {
    out += "| " + res.columns.map((c, i) => align(c.name, widths[i], false)).join(" | ") + " |\n";
    out += "|" + widths.map((w, i) => (isNumericType(res.columns[i].type) ? "-".repeat(w + 1) + ":" : "-".repeat(w + 2))).join("|") + "|\n";
    for (const r of res.rows) out += "| " + res.columns.map((c, i) => align(val(r[c.name], opts), widths[i], isNumericType(c.type))).join(" | ") + " |\n";
    return out;
  }
  const chars = style === "ascii" ? ["+", "+", "+", "-", "+"] : ["┌", "┬", "┐", "─", "┼"];
  const mid = style === "ascii" ? ["+", "+", "+"] : ["├", "┼", "┤"];
  const bot = style === "ascii" ? ["+", "+", "+"] : ["└", "┴", "┘"];
  const border = (b: string[]) => b[0] + widths.map(w => chars[3].repeat(w + 2)).join(b[1]) + b[2] + "\n";
  const bars = style === "ascii" ? ["|", "|", "|"] : ["│", "│", "│"];
  out += border(chars);
  out += rowLine(res.columns.map(c => c.name), bars);
  if (includeTypes) out += rowLine(res.columns.map(c => c.type), bars);
  out += border(mid);
  for (const r of res.rows) out += rowLine(res.columns.map(c => val(r[c.name], opts)), bars);
  out += border(bot);
  return out;
}

function column(res: Result, opts: Options): string {
  const values = [res.columns.map(c => c.name), ...res.rows.map(r => res.columns.map(c => val(r[c.name], opts)))];
  const widths = res.columns.map((_, i) => Math.max(...values.map(v => String(v[i] ?? "").length)));
  let out = "";
  if (opts.header) {
    out += res.columns.map((c, i) => c.name.padEnd(widths[i])).join("  ") + "\n";
    out += widths.map(w => "-".repeat(w)).join("  ") + "\n";
  }
  for (const r of res.rows) out += res.columns.map((c, i) => val(r[c.name], opts).padEnd(widths[i])).join("  ") + "\n";
  return out;
}

function delimited(res: Result, sep: string, opts: Options, conv: (v: Value, opts: Options) => string): string {
  let lines: string[] = [];
  if (opts.header) lines.push(res.columns.map(c => conv(c.name, opts)).join(sep));
  for (const r of res.rows) lines.push(res.columns.map(c => conv(r[c.name], opts)).join(sep));
  return lines.join(opts.newline) + (lines.length ? opts.newline : "");
}

function html(res: Result, opts: Options): string {
  let out = "";
  if (opts.header) out += "<tr>" + res.columns.map(c => `<th>${escapeHtml(c.name)}</th>\n`).join("") + "</tr>\n";
  for (const r of res.rows) out += "<tr>" + res.columns.map(c => `<td>${escapeHtml(val(r[c.name], opts))}</td>\n`).join("") + "</tr>\n";
  return out;
}

function ascii(res: Result, opts: Options): string {
  const items: string[] = [];
  if (opts.header) for (const c of res.columns) items.push(c.name);
  for (const r of res.rows) for (const c of res.columns) items.push(val(r[c.name], opts));
  return items.join(opts.newline) + (items.length ? opts.newline : "");
}

function readCsv(file: string): Result {
  const text = fs.readFileSync(file, "utf8").replace(/\r\n/g, "\n");
  const lines = text.split("\n").filter((l: string) => l.length > 0);
  if (!lines.length) return { columns: [], rows: [] };
  const names = parseCsvLine(lines[0]);
  const rawRows = lines.slice(1).map(parseCsvLine);
  const columns = names.map((n, i) => ({ name: n, type: commonType("varchar", ...rawRows.map(r => inferType(parseScalar(r[i])))) }));
  const rows = rawRows.map(vals => {
    const r: Row = {};
    names.forEach((n, i) => r[n] = parseScalar(vals[i] ?? ""));
    return r;
  });
  return { columns, rows };
}

function parseCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = "", quote = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"' && quote && line[i + 1] === '"') { cur += '"'; i++; }
    else if (ch === '"') quote = !quote;
    else if (ch === "," && !quote) { out.push(cur); cur = ""; }
    else cur += ch;
  }
  out.push(cur);
  return out;
}

function splitStatements(s: string): string[] {
  const out: string[] = [];
  let cur = "", quote = false, lineComment = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i], next = s[i + 1];
    if (lineComment) { if (ch === "\n") lineComment = false; continue; }
    if (!quote && ch === "-" && next === "-") { lineComment = true; i++; continue; }
    if (ch === "'" && s[i + 1] === "'") { cur += "''"; i++; continue; }
    if (ch === "'") quote = !quote;
    if (ch === ";" && !quote) { out.push(cur); cur = ""; } else cur += ch;
  }
  if (cur.trim()) out.push(cur);
  return out;
}

function splitTop(s: string, sep: string): string[] {
  const out: string[] = [];
  let cur = "", depth = 0, quote = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === "'" && s[i + 1] === "'") { cur += "''"; i++; continue; }
    if (ch === "'") quote = !quote;
    if (!quote) { if (ch === "(") depth++; else if (ch === ")") depth--; }
    if (!quote && depth === 0 && s.startsWith(sep, i)) { out.push(cur.trim()); cur = ""; i += sep.length - 1; }
    else cur += ch;
  }
  if (cur.trim() || s.length) out.push(cur.trim());
  return out;
}

function parseValueGroups(s: string): string[] {
  const groups: string[] = [];
  let start = -1, depth = 0, quote = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === "'" && s[i + 1] === "'") { i++; continue; }
    if (ch === "'") quote = !quote;
    if (quote) continue;
    if (ch === "(") { if (depth === 0) start = i + 1; depth++; }
    else if (ch === ")") { depth--; if (depth === 0 && start >= 0) groups.push(s.slice(start, i)); }
  }
  return groups;
}

function parseAlias(e: string): { expr: string; alias: string | null } {
  const m = /^(.+?)\s+as\s+([A-Za-z_][\w]*|"[^"]+")$/is.exec(e.trim());
  if (m) return { expr: m[1].trim(), alias: unquoteIdent(m[2]) };
  const parts = splitTop(e.trim(), " ");
  if (parts.length === 2 && /^[A-Za-z_][\w]*$/.test(parts[1]) && !/[+\-*\/<>=]/.test(parts[0])) return { expr: parts[0], alias: parts[1] };
  return { expr: e.trim(), alias: null };
}

function defaultName(expr: string) {
  if (/^'.*'$/.test(expr)) return expr.slice(1, -1);
  return expr.replace(/\s+/g, " ");
}

function inferType(v: Value): string {
  if (v === null || v === undefined) return "int32";
  if (Array.isArray(v)) return "int64[]";
  if (typeof v === "boolean") return "boolean";
  if (typeof v === "number") return Number.isInteger(v) ? (Math.abs(v) > 2147483647 ? "int64" : "int32") : "double";
  return "varchar";
}

function commonType(...types: string[]): string {
  const t = types.filter(Boolean);
  if (t.includes("varchar")) return t.every(x => x === "varchar") ? "varchar" : (t.filter(x => x !== "varchar").length ? t.find(x => x !== "varchar") || "varchar" : "varchar");
  if (t.includes("double")) return "double";
  if (t.includes("int64")) return "int64";
  if (t.includes("boolean")) return "boolean";
  return t[0] || "varchar";
}

function val(v: Value, opts: Options): string {
  if (v === null || v === undefined) return opts.nullValue;
  if (Array.isArray(v)) return "[" + v.map(x => val(x, opts)).join(", ") + "]";
  if (typeof v === "number" && !Number.isFinite(v)) return v > 0 ? "inf" : "-inf";
  return String(v);
}

function jsonRow(r: Row, cols: Column[]) {
  const o: any = {};
  for (const c of cols) o[c.name] = r[c.name];
  return o;
}

function csvCell(v: Value, opts: Options): string {
  const s = val(v, opts);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function quoteCell(v: Value, opts: Options): string {
  if (v === null || v === undefined) return opts.nullValue;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  return `'${String(v).replace(/'/g, "''")}'`;
}

function parseScalar(s: string): Value {
  if (s === "" || /^null$/i.test(s)) return null;
  if (/^-?\d+$/.test(s)) return Number(s);
  if (/^-?\d+\.\d+$/.test(s)) return Number(s);
  if (/^(true|false)$/i.test(s)) return /^true$/i.test(s);
  return s;
}

function loadDb(file: string | null): Database {
  if (!file || !fs.existsSync(file)) return { tables: {} };
  try {
    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    return data && data.tables ? data : { tables: {} };
  } catch {
    return { tables: {} };
  }
}

function saveDb(file: string | null, db: Database) {
  if (!file) return;
  fs.writeFileSync(file, JSON.stringify(db));
}

function schemaSql(name: string, table: Table) {
  return `CREATE TABLE ${name}(${table.columns.map(c => `${c.name} ${c.type.toUpperCase()}`).join(", ")});`;
}

function normalizeType(t: string) {
  t = t.trim().toLowerCase();
  if (t.startsWith("int")) return "integer";
  if (t.startsWith("bigint")) return "bigint";
  if (t.startsWith("double") || t.startsWith("float") || t.startsWith("real")) return "double";
  if (t.startsWith("bool")) return "boolean";
  return t || "varchar";
}

function findKeyword(s: string, kw: string): number {
  let depth = 0, quote = false;
  for (let i = 0; i <= s.length - kw.length; i++) {
    const ch = s[i];
    if (ch === "'") quote = !quote;
    if (quote) continue;
    if (ch === "(") depth++;
    else if (ch === ")") depth--;
    if (depth === 0 && s.slice(i, i + kw.length).toLowerCase() === kw && /\s/.test(s[i - 1] || " ") && /\s/.test(s[i + kw.length] || " ")) return i;
  }
  return -1;
}

function findOp(s: string, op: string): number {
  let depth = 0, quote = false;
  for (let i = 0; i <= s.length - op.length; i++) {
    const ch = s[i];
    if (ch === "'") quote = !quote;
    if (quote) continue;
    if (ch === "(") depth++;
    else if (ch === ")") depth--;
    if (depth === 0 && s.startsWith(op, i)) return i;
  }
  return -1;
}

function balanced(s: string) {
  let depth = 0, quote = false;
  for (const ch of s) {
    if (ch === "'") quote = !quote;
    if (quote) continue;
    if (ch === "(") depth++;
    else if (ch === ")") { depth--; if (depth < 0) return false; }
  }
  return depth === 0;
}

function cmp(a: any, b: any) { return a < b ? -1 : a > b ? 1 : 0; }
function truthy(v: Value) { return !!v; }
function unquoteIdent(s: string) { return s.replace(/^["`]|["`]$/g, ""); }
function isNumericType(t: string) { return /int|double|float|decimal/.test(t); }
function isNumericText(s: string) { return /^-?(?:\d+(?:\.\d+)?|inf)$/.test(s); }
function escapeHtml(s: string) { return s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" } as any)[c]); }
function decodeSep(s: string) { return s.replace(/\\n/g, "\n").replace(/\\t/g, "\t"); }
function looksLikeSql(s: string) { return /^(select|create|insert|show|describe|values|with|pragma|set)\b/i.test(s.trim()); }
function formatSql(s: string) { return s.trim().replace(/\s+/g, " ").replace(/\b(select|from|where|order by|limit|insert|values|create table)\b/ig, m => m.toUpperCase()) + "\n"; }
function die(msg: string): never { throw new Error(msg); }

main();
