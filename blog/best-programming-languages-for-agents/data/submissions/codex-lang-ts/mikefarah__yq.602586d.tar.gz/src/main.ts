declare const require: any;
declare const process: any;
declare const Buffer: any;
const fs = require("fs");

type Any = any;

interface Opts {
  command: string;
  expr?: string;
  files: string[];
  inputFormat: string;
  outputFormat: string;
  inplace: boolean;
  nullInput: boolean;
  pretty: boolean;
  unwrap: boolean;
  exitStatus: boolean;
  indent: number;
  noDoc: boolean;
  nul: boolean;
  csvSep: string;
  propsSep: string;
  expressionFile?: string;
}

const HELP = `yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) 
See https://mikefarah.gitbook.io/yq/ for detailed documentation and examples.

Usage:
  yq [flags]
  yq [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  eval        (default) Apply the expression to each document in each yaml file in sequence
  eval-all    Loads _all_ yaml documents of _all_ yaml files and runs expression once
  help        Help about any command

Flags:
  -C, --colors                            force print with colors
  -e, --exit-status                       set exit status if there are no matches or null or false is returned
  -h, --help                              help for yq
  -I, --indent int                        sets indent level for output (default 2)
  -i, --inplace                           update the file in place of first file given.
  -n, --null-input                        Don't read input, simply evaluate the expression given.
  -o, --output-format string              [auto|yaml|json|props|csv|tsv|xml|base64|uri|shell|lua|ini] output format type. (default "auto")
  -p, --input-format string               [auto|yaml|json|props|csv|tsv|xml|base64|uri|toml|hcl|lua|ini] parse format for input. (default "auto")
  -P, --prettyPrint                       pretty print
  -r, --unwrapScalar                      unwrap scalar (default true)
  -V, --version                           Print version information and quit

Use "yq [command] --help" for more information about a command.`;

function die(msg: string, code = 1): never {
  process.stderr.write(msg + "\n");
  process.exit(code);
  throw new Error(msg);
}

function normFmt(s: string): string {
  const v = (s || "auto").toLowerCase();
  const m: Record<string,string> = { y:"yaml", a:"auto", j:"json", p:"props", c:"csv", t:"tsv", x:"xml", h:"hcl", l:"lua", i:"ini", s:"shell", ky:"yaml", kyaml:"yaml" };
  return m[v] || v;
}

function parseArgs(argv: string[]): Opts {
  const o: Opts = {command:"eval", files:[], inputFormat:"auto", outputFormat:"auto", inplace:false, nullInput:false, pretty:false, unwrap:true, exitStatus:false, indent:2, noDoc:false, nul:false, csvSep:",", propsSep:" = "};
  const args = [...argv];
  if (args[0] === "eval" || args[0] === "e") { o.command = "eval"; args.shift(); }
  else if (args[0] === "eval-all" || args[0] === "ea") { o.command = "eval-all"; args.shift(); }
  else if (args[0] === "completion") {
    console.log("# bash completion V2 for yq\n_yq_completion() { :; }");
    process.exit(0);
  } else if (args[0] === "help") {
    console.log(HELP); process.exit(0);
  }
  for (let i=0;i<args.length;i++) {
    let a = args[i];
    const next = () => args[++i] ?? die(`Error: flag needs an argument: ${a}`);
    if (a === "--") { o.files.push(...args.slice(i+1)); break; }
    else if (a === "-h" || a === "--help") { console.log(HELP); process.exit(0); }
    else if (a === "-V" || a === "--version") { console.log("yq (https://github.com/mikefarah/yq/) version v4.52.5"); process.exit(0); }
    else if (a === "-i" || a === "--inplace") o.inplace = true;
    else if (a === "-n" || a === "--null-input") o.nullInput = true;
    else if (a === "-P" || a === "--prettyPrint") o.pretty = true;
    else if (a === "-e" || a === "--exit-status") o.exitStatus = true;
    else if (a === "-N" || a === "--no-doc") o.noDoc = true;
    else if (a === "-0" || a === "--nul-output") o.nul = true;
    else if (a === "-r" || a === "--unwrapScalar") o.unwrap = true;
    else if (a === "-M" || a === "--no-colors" || a === "-C" || a === "--colors" || a === "-v" || a === "--verbose" || a === "--header-preprocess" || a === "--csv-auto-parse" || a === "--tsv-auto-parse" || a.startsWith("--xml-") || a.startsWith("--security-") || a === "--debug-node-info" || a === "--string-interpolation" || a === "--lua-globals" || a === "--lua-unquoted" || a === "--properties-array-brackets" || a === "-c" || a === "--yaml-compact-seq-indent" || a === "--yaml-fix-merge-anchor-to-spec") {}
    else if (a === "-I" || a === "--indent") o.indent = parseInt(next(),10) || 2;
    else if (a.startsWith("-I") && a.length > 2) o.indent = parseInt(a.slice(2),10) || 2;
    else if (a === "-p" || a === "--input-format") o.inputFormat = normFmt(next());
    else if (a.startsWith("-p") && a.length > 2) o.inputFormat = normFmt(a.slice(2).replace(/^=/,""));
    else if (a.startsWith("--input-format=")) o.inputFormat = normFmt(a.split("=")[1]);
    else if (a === "-o" || a === "--output-format") o.outputFormat = normFmt(next());
    else if (a.startsWith("-o") && a.length > 2) o.outputFormat = normFmt(a.slice(2).replace(/^=/,""));
    else if (a.startsWith("--output-format=")) o.outputFormat = normFmt(a.split("=")[1]);
    else if (a === "--expression") o.expr = next();
    else if (a.startsWith("--expression=")) o.expr = a.slice(13);
    else if (a === "--from-file") o.expressionFile = next();
    else if (a.startsWith("--from-file=")) o.expressionFile = a.slice(12);
    else if (a === "--csv-separator") o.csvSep = next();
    else if (a.startsWith("--csv-separator=")) o.csvSep = a.split("=")[1];
    else if (a === "--properties-separator") o.propsSep = next();
    else if (a.startsWith("--properties-separator=")) o.propsSep = a.slice(23);
    else if (a === "-s" || a === "--split-exp" || a === "--split-exp-file" || a === "-f" || a === "--front-matter" || a === "--lua-prefix" || a === "--lua-suffix" || a === "--shell-key-separator") { next(); }
    else if (a.startsWith("-")) die(`Error: unknown flag: ${a}\nUsage:\n  yq [flags]\n  yq [command]`);
    else if (o.expr === undefined && looksExpr(a, args[i+1])) o.expr = a;
    else o.files.push(a);
  }
  if (o.expressionFile) o.expr = fs.readFileSync(o.expressionFile, "utf8").trim();
  if (!o.expr && !o.nullInput && o.files.length === 1 && fs.existsSync(o.files[0])) o.expr = ".";
  if (!o.expr) o.expr = ".";
  return o;
}

function looksExpr(a: string, next?: string): boolean {
  if (a === "." || a.startsWith(".") || a.includes("=") || a.includes("|") || a.includes("select(") || a.startsWith("[") || a.startsWith("load(") || a.includes("ireduce")) return true;
  return !fs.existsSync(a) && !!next;
}

function scalar(s: string): Any {
  const t = s.trim();
  if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) return t.slice(1,-1).replace(/\\"/g,'"');
  if (t === "null" || t === "~") return null;
  if (t === "true") return true;
  if (t === "false") return false;
  if (/^-?\d+(\.\d+)?$/.test(t)) return Number(t);
  if (t.startsWith("[") || t.startsWith("{")) { try { return JSON.parse(t); } catch {} }
  return t;
}

function stripComment(line: string): string {
  let q = "";
  for (let i=0;i<line.length;i++) {
    const c=line[i]; if ((c === '"' || c === "'") && line[i-1] !== "\\") q = q === c ? "" : (q || c);
    if (c === "#" && !q) return line.slice(0,i);
  }
  return line;
}

function parseYaml(text: string): Any {
  const lines = text.replace(/\r/g,"").split("\n").filter(l => stripComment(l).trim() !== "" && stripComment(l).trim() !== "---" && stripComment(l).trim() !== "...");
  if (lines.length === 0) return null;
  function parseBlock(start: number, indent: number): [Any, number] {
    let arr: Any[]|null = null, obj: Any = {};
    let i = start;
    while (i < lines.length) {
      let raw = stripComment(lines[i]);
      let n = raw.match(/^ */)![0].length;
      if (n < indent) break;
      if (n > indent) break;
      let t = raw.trim();
      if (t.startsWith("- ")) {
        if (!arr) arr = [];
        let rest = t.slice(2).trim();
        if (rest === "") { const [v,j]=parseBlock(i+1, indent+2); arr.push(v); i=j; continue; }
        if (/^[^:]+:\s*/.test(rest)) {
          const item: Any = {};
          const k = rest.split(":")[0].trim();
          const val = rest.slice(rest.indexOf(":")+1).trim();
          if (val === "") { const [v,j]=parseBlock(i+1, indent+2); item[k]=v; i=j; }
          else { item[k]=scalar(val); i++; }
          while (i < lines.length) {
            let nr = stripComment(lines[i]); let nn = nr.match(/^ */)![0].length; let nt = nr.trim();
            if (nn !== indent+2 || nt.startsWith("- ") || !nt.includes(":")) break;
            const kk = nt.split(":")[0].trim(); const vv = nt.slice(nt.indexOf(":")+1).trim();
            if (vv === "") { const [v,j]=parseBlock(i+1, nn+2); item[kk]=v; i=j; } else { item[kk]=scalar(vv); i++; }
          }
          arr.push(item);
        } else { arr.push(scalar(rest)); i++; }
      } else {
        if (!t.includes(":")) { i++; continue; }
        const k = t.split(":")[0].trim();
        const val = t.slice(t.indexOf(":")+1).trim();
        if (val === "") { const [v,j]=parseBlock(i+1, indent+2); obj[k]=v; i=j; }
        else { obj[k]=scalar(val); i++; }
      }
    }
    return [arr || obj, i];
  }
  return parseBlock(0, lines[0].match(/^ */)![0].length)[0];
}

function parseCsv(text: string, sep: string): Any[] {
  const rows = text.trim().split(/\r?\n/).filter(Boolean).map(line => splitCsv(line, sep));
  if (!rows.length) return [];
  const head = rows[0];
  return rows.slice(1).map(r => Object.fromEntries(head.map((h,i)=>[h, scalar(r[i] ?? "")])));
}
function splitCsv(line: string, sep: string): string[] {
  const out:string[]=[]; let cur="", q=false;
  for (let i=0;i<line.length;i++) {
    const c=line[i];
    if (c === '"' && line[i+1] === '"') { cur += '"'; i++; }
    else if (c === '"') q=!q;
    else if (c === sep && !q) { out.push(cur); cur=""; }
    else cur += c;
  }
  out.push(cur); return out;
}

function parseProps(text: string): Any {
  const root: Any = {};
  for (const l of text.split(/\r?\n/)) {
    const line = l.trim(); if (!line || line.startsWith("#")) continue;
    const m = line.match(/^([^:=]+?)\s*[:=]\s*(.*)$/); if (!m) continue;
    setPath(root, parsePath("." + m[1].trim().replace(/\./g,".")), scalar(m[2]));
  }
  return root;
}

function parseXml(text: string): Any {
  text = text.replace(/<\?[\s\S]*?\?>/g,"").replace(/<![\s\S]*?>/g,"").trim();
  const root: Any = {};
  const stack: {name:string,obj:Any}[] = [{name:"",obj:root}];
  const re = /<([^>]+)>|([^<]+)/g; let m;
  while ((m = re.exec(text))) {
    if (m[1]) {
      const tag = m[1].trim();
      if (tag.startsWith("/")) { stack.pop(); continue; }
      const self = tag.endsWith("/");
      const body = tag.replace(/\/$/,"").trim();
      const parts = body.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
      const name = parts.shift() || "";
      const obj: Any = {};
      for (const p of parts) {
        const eq=p.indexOf("="); if (eq>0) obj["+@"+p.slice(0,eq)] = scalar(p.slice(eq+1));
      }
      const parent = stack[stack.length-1].obj;
      if (parent[name] === undefined) parent[name]=obj; else if (Array.isArray(parent[name])) parent[name].push(obj); else parent[name]=[parent[name], obj];
      if (!self) stack.push({name,obj});
    } else {
      const txt = m[2].trim(); if (txt) stack[stack.length-1].obj["+content"] = scalar(txt);
    }
  }
  return root;
}

function parseInput(text: string, fmt: string, file: string, opts: Opts): Any {
  fmt = fmt === "auto" ? detectFmt(file, text) : fmt;
  if (fmt === "json") return JSON.parse(text || "null");
  if (fmt === "csv") return parseCsv(text, opts.csvSep);
  if (fmt === "tsv") return parseCsv(text, "\t");
  if (fmt === "props" || fmt === "properties" || fmt === "ini") return parseProps(text);
  if (fmt === "xml") return parseXml(text);
  if (fmt === "base64") return Buffer.from(text.trim(), "base64").toString("utf8");
  if (fmt === "uri") return decodeURIComponent(text.trim());
  return parseYaml(text);
}

function detectFmt(file: string, text: string): string {
  const ext = (file.split(".").pop() || "").toLowerCase();
  if (["json","csv","tsv","xml","properties","props","ini"].includes(ext)) return ext === "properties" ? "props" : ext;
  const t=text.trim(); if (t.startsWith("{") || t.startsWith("[")) return "json";
  return "yaml";
}

type Seg = string|number|"*";
function parsePath(path: string): Seg[] {
  path = path.trim();
  if (path === "." || path === "") return [];
  if (path.startsWith(".")) path = path.slice(1);
  const segs: Seg[] = []; let cur="";
  for (let i=0;i<path.length;i++) {
    const c=path[i];
    if (c === ".") { if(cur){segs.push(cur);cur="";} }
    else if (c === "[") {
      if(cur){segs.push(cur);cur="";}
      const j=path.indexOf("]",i); const inside=path.slice(i+1,j);
      segs.push(inside === "" ? "*" : Number(inside)); i=j;
    } else cur += c;
  }
  if(cur) segs.push(cur);
  return segs;
}

function getPath(v: Any, segs: Seg[]): Any {
  if (!segs.length) return v;
  const [s,...rest]=segs;
  if (s === "*") return Array.isArray(v) ? v.flatMap(x => { const r=getPath(x,rest); return Array.isArray(r)?r:[r]; }) : [];
  if (v == null) return null;
  return getPath(v[s as any], rest);
}
function setPath(obj: Any, segs: Seg[], val: Any): Any {
  if (!segs.length) return val;
  let cur=obj;
  for (let i=0;i<segs.length-1;i++) {
    const s=segs[i], n=segs[i+1];
    if (cur[s as any] == null) cur[s as any] = typeof n === "number" ? [] : {};
    cur = cur[s as any];
  }
  cur[segs[segs.length-1] as any] = val; return obj;
}

function deepMerge(a: Any, b: Any): Any {
  if (Array.isArray(a) || Array.isArray(b) || typeof a !== "object" || typeof b !== "object" || a == null || b == null) return b;
  const out: Any = {...a};
  for (const k of Object.keys(b)) out[k] = k in out ? deepMerge(out[k], b[k]) : b[k];
  return out;
}

function evalExpr(expr: string, data: Any, docs: Any[], opts: Opts): Any {
  expr = expr.trim();
  const bracketSelect = expr.match(/^\[\s*(\.[A-Za-z0-9_.-]+\[\])\s*\|\s*select\(\s*\.([A-Za-z0-9_-]+)\s*==\s*["']?([^"')]+)["']?\s*\)\s*\]$/);
  if (bracketSelect) {
    const arr = getPath(data, parsePath(bracketSelect[1]));
    return Array.isArray(arr) ? arr.filter(x => x && x[bracketSelect[2]] == bracketSelect[3]) : [];
  }
  const directSelect = expr.match(/^(\.[A-Za-z0-9_.-]+\[\])\s*\|\s*select\(\s*\.([A-Za-z0-9_-]+)\s*==\s*["']?([^"')]+)["']?\s*\)$/);
  if (directSelect) {
    const arr = getPath(data, parsePath(directSelect[1]));
    return Array.isArray(arr) ? arr.filter(x => x && x[directSelect[2]] == directSelect[3]) : [];
  }
  if (expr.includes("|")) {
    return expr.split("|").map(s=>s.trim()).reduce((acc,e)=>evalExpr(e, acc, docs, opts), data);
  }
  if (expr.includes("ireduce") || expr.includes("load(")) {
    if (expr.includes("load(")) {
      const files = [...expr.matchAll(/load\(["']([^"']+)["']\)/g)].map(m=>m[1]);
      return files.map(f=>parseInput(fs.readFileSync(f,"utf8"), opts.inputFormat, f, opts)).reduce(deepMerge, {});
    }
    return docs.reduce(deepMerge, {});
  }
  const assign = expr.match(/^(.+?)\s*=\s*(.+)$/s);
  if (assign) {
    const target = assign[1].trim(); let rhs = assign[2].trim();
    let val: Any;
    const sm = rhs.match(/^strenv\(([^)]+)\)$/); const em = rhs.match(/^env\(([^)]+)\)$/);
    if (sm || em) val = process.env[(sm||em)![1]] ?? "";
    else val = scalar(rhs);
    return setPath(data == null ? {} : data, parsePath(target), val);
  }
  const sel = expr.match(/^\.([^\[]+)\[\]\s*\|\s*select\(\s*\.([A-Za-z0-9_-]+)\s*==\s*["']?([^"')]+)["']?\s*\)$/);
  if (sel) {
    const arr = getPath(data, parsePath("." + sel[1]));
    const res = Array.isArray(arr) ? arr.filter(x => x && x[sel[2]] == sel[3]) : [];
    return res;
  }
  const selectOnly = expr.match(/^select\(\s*\.([A-Za-z0-9_-]+)\s*==\s*["']?([^"')]+)["']?\s*\)$/);
  if (selectOnly) {
    const arr = Array.isArray(data) ? data : [data];
    return arr.filter(x => x && x[selectOnly[1]] == selectOnly[2]);
  }
  if (expr.startsWith("select(")) return data;
  return getPath(data, parsePath(expr));
}

function qstr(s: string): string {
  return /^[A-Za-z0-9_./:-]+$/.test(s) && s !== "" && !["true","false","null"].includes(s) ? s : JSON.stringify(s);
}
function toYaml(v: Any, indent=2, level=0): string {
  const sp = " ".repeat(level);
  if (v == null || typeof v !== "object") return sp + scalarOut(v);
  if (Array.isArray(v)) {
    if (!v.length) return sp + "[]";
    return v.map(x => {
      if (x != null && typeof x === "object" && !Array.isArray(x)) {
        const keys=Object.keys(x); if (!keys.length) return sp+"- {}";
        return keys.map((k,idx)=>{
          const val=x[k]; const pre=(idx===0?sp+"- ":sp+"  ")+k+":";
          return val != null && typeof val === "object" ? pre+"\n"+toYaml(val, indent, level+indent) : pre+" "+scalarOut(val);
        }).join("\n");
      }
      return x != null && typeof x === "object" ? sp+"-\n"+toYaml(x, indent, level+indent) : sp+"- "+scalarOut(x);
    }).join("\n");
  }
  const keys = Object.keys(v); if (!keys.length) return sp + "{}";
  return keys.map(k => {
    const val=v[k];
    return val != null && typeof val === "object" ? `${sp}${k}:\n${toYaml(val, indent, level+indent)}` : `${sp}${k}: ${scalarOut(val)}`;
  }).join("\n");
}
function scalarOut(v: Any): string {
  if (v === null || v === undefined) return "null";
  if (typeof v === "string") return qstr(v);
  return String(v);
}
function flatten(v: Any, prefix=""): string[] {
  if (v != null && typeof v === "object") {
    if (Array.isArray(v)) return v.flatMap((x,i)=>flatten(x, prefix ? `${prefix}.${i}` : String(i)));
    return Object.keys(v).flatMap(k=>flatten(v[k], prefix ? `${prefix}.${k}` : k));
  }
  return [`${prefix} = ${v == null ? "" : String(v)}`];
}
function toCsv(arr: Any[], sep: string): string {
  if (!Array.isArray(arr)) arr=[arr];
  const keys=[...new Set(arr.flatMap(o=>o&&typeof o==="object"?Object.keys(o):["value"]))];
  const esc=(x:Any)=>{let s=x==null?"":String(x); return s.includes(sep)||s.includes('"')||s.includes("\n") ? `"${s.replace(/"/g,'""')}"` : s;};
  return [keys.join(sep), ...arr.map(o=>keys.map(k=>esc(o&&typeof o==="object"?o[k]:o)).join(sep))].join("\n");
}
function toXml(v: Any): string {
  function node(name:string, x:Any): string {
    if (x == null || typeof x !== "object") return `<${name}>${String(x ?? "")}</${name}>`;
    if (Array.isArray(x)) return x.map(y=>node(name,y)).join("");
    const attrs=Object.keys(x).filter(k=>k.startsWith("+@")).map(k=>` ${k.slice(2)}="${x[k]}"`).join("");
    const content=(x["+content"] ?? "") + Object.keys(x).filter(k=>!k.startsWith("+@")&&k!=="+content").map(k=>node(k,x[k])).join("");
    return `<${name}${attrs}>${content}</${name}>`;
  }
  return Object.keys(v||{}).map(k=>node(k,v[k])).join("");
}
function format(v: Any, fmt: string, opts: Opts, inputFile=""): string {
  if (fmt === "auto") fmt = opts.pretty ? "yaml" : (inputFile ? detectFmt(inputFile,"") : "yaml");
  if (fmt === "json") return JSON.stringify(v, null, opts.indent);
  if (fmt === "props" || fmt === "properties") return flatten(v).join("\n");
  if (fmt === "csv") return toCsv(v, opts.csvSep);
  if (fmt === "tsv") return toCsv(v, "\t");
  if (fmt === "xml") return toXml(v);
  if (fmt === "base64") return Buffer.from(String(v)).toString("base64");
  if (fmt === "uri") return encodeURIComponent(String(v));
  if (fmt === "shell") return flatten(v).map(l=>l.replace(/[^A-Za-z0-9=]+/g,"_")).join("\n");
  if (fmt === "lua") return "return " + JSON.stringify(v) + ";";
  if ((v == null || typeof v !== "object") && opts.unwrap) return scalarOut(v);
  return toYaml(v, opts.indent);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const sep = opts.nul ? "\0" : "\n";
  let docs: Any[] = [], files = opts.files.length ? opts.files : (opts.nullInput ? [] : ["-"]);
  if (opts.nullInput) docs = [null];
  else for (const f of files) {
    const text = f === "-" ? fs.readFileSync(0,"utf8") : fs.readFileSync(f,"utf8");
    docs.push(parseInput(text, opts.inputFormat, f, opts));
  }
  let results: Any[] = [];
  if (opts.command === "eval-all") results = [evalExpr(opts.expr!, docs[0] ?? null, docs, opts)];
  else results = docs.map(d => evalExpr(opts.expr!, d, docs, opts));
  if (opts.exitStatus && results.some(r => r == null || r === false || (Array.isArray(r)&&r.length===0))) die("Error: no matches found", 1);
  if (opts.inplace) {
    if (!opts.files.length) die("Error: write in place flag only applicable when giving an expression and at least one file");
    fs.writeFileSync(opts.files[0], format(results[0], opts.outputFormat === "auto" ? detectFmt(opts.files[0],"") : opts.outputFormat, opts, opts.files[0]) + "\n");
    return;
  }
  const outFmt = opts.outputFormat;
  const shouldFlatten = opts.expr!.includes("[]") && !opts.expr!.trim().startsWith("[");
  const parts = results.flatMap(r => Array.isArray(r) && shouldFlatten ? r : [r]).map(r => format(r, outFmt, opts, files[0]));
  process.stdout.write(parts.join(sep) + (parts.length ? sep : ""));
}
try { main(); } catch (e:any) { die("Error: " + (e && e.message ? e.message : String(e))); }
