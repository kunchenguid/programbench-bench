declare const process: any;
declare function require(name: string): any;
declare const Buffer: any;
