const fs = require("fs");
const path = require("path");

type Span = { start: number; end: number };
type Config = {
  scope: string;
  literal: boolean;
  replacement?: string;
  upper: boolean;
  lower: boolean;
  title: boolean;
  normalize: boolean;
  german: boolean;
  germanNaive: boolean;
  symbols: boolean;
  invert: boolean;
  del: boolean;
  squeeze: boolean;
  failAny: boolean;
  failNone: boolean;
  lineNumbers: boolean;
  onlyMatching: boolean;
  glob?: string;
  failNoFiles: boolean;
  dryRun: boolean;
  sorted: boolean;
  files: boolean;
  lang: { name: string; value: string }[];
};

const HELP = `A grep-like tool which understands source code syntax and allows for manipulation in
addition to search

Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]

Arguments:
  [SCOPE]  Scope to apply to, as a regular expression pattern. [default: .*]

Options:
      --completions <SHELL>  Print shell completions for the given shell. [possible values: bash, elvish, fish, powershell, zsh]
  -h, --help                 Print help (see more with '--help')
  -V, --version              Print version

Composable Actions:
  -u, --upper        Uppercase anything in scope. [env: UPPER=]
  -l, --lower        Lowercase anything in scope. [env: LOWER=]
  -t, --titlecase    Titlecase anything in scope. [env: TITLECASE=]
  -n, --normalize    Normalize (Normalization Form D) anything in scope, and throw away marks. [env: NORMALIZE=]
  -g, --german       Perform substitutions on German words, such as 'Abenteuergruesse' to 'Abenteuergrüße', for anything in scope.
  -S, --symbols      Perform substitutions on symbols, such as '!=' to '≠', '->' to '→', on anything in scope.
  [REPLACEMENT]  Replace anything in scope with this value. [env: REPLACE=]

Standalone Actions (only usable alone):
  -d, --delete   Delete anything in scope.
  -s, --squeeze  Squeeze consecutive occurrences of scope into one. [env: SQUEEZE=]

Options (global):
  -G, --glob <GLOB>          Glob of files to work on (instead of reading stdin).
      --fail-no-files        Fail if working on files but none are found.
      --dry-run              Do not destructively overwrite files.
  -i, --invert               Undo the effects of passed actions, where applicable.
  -L, --literal-string       Interpret scope as a literal string.
      --fail-any             If anything at all is found to be in scope, fail.
      --fail-none            If nothing is found to be in scope, fail.
      --line-numbers         Include line numbers in search output.
      --only-matching        Print only matching spans in search output.
      --files                List files that would be processed.
      --sorted               Process files in lexicographically sorted order.

Language scopes:
      --python <PYTHON>      Scope Python code using a prepared query.
      --rust <RUST>          Scope Rust code using a prepared query.
      --go <GO>              Scope Go code using a prepared query.
      --typescript <TS>      Scope TypeScript code using a prepared query.
      --c <C>                Scope C code using a prepared query.
      --csharp <CSHARP>      Scope C# code using a prepared query.
      --hcl <HCL>            Scope HCL code using a prepared query.`;

function main(): void {
  const cfg = parseArgs(process.argv.slice(2));
  if ((cfg as any).exit !== undefined) process.exit((cfg as any).exit);

  if (cfg.glob) {
    const files = findFiles(process.cwd(), cfg.glob, cfg.sorted);
    if (files.length === 0 && cfg.failNoFiles) {
      maybeNoActionLog(cfg);
      console.error("Error: No files found");
      process.exit(1);
    }
    if (cfg.files) {
      for (const f of files) console.log(f);
      process.exit(0);
    }
    let any = false;
    for (const file of files) {
      const input = fs.readFileSync(file, "utf8");
      const res = processText(input, cfg, file);
      any ||= res.any;
      if (hasActions(cfg)) {
        if (!cfg.dryRun && res.output !== input) fs.writeFileSync(file, res.output);
        console.log(file);
      } else if (res.output) process.stdout.write(res.output);
    }
    failChecks(cfg, any);
    return;
  }

  const input = readStdin();
  const res = processText(input, cfg, "(stdin)");
  if (res.output) process.stdout.write(res.output);
  failChecks(cfg, res.any);
}

function parseArgs(args: string[]): Config {
  const cfg: Config = {
    scope: ".*", literal: false, upper: false, lower: false, title: false, normalize: false,
    german: false, germanNaive: false, symbols: false, invert: false, del: false, squeeze: false,
    failAny: false, failNone: false, lineNumbers: false, onlyMatching: false, failNoFiles: false,
    dryRun: false, sorted: false, files: false, lang: []
  };
  const pos: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") {
      cfg.replacement = args.slice(i + 1).join(" ");
      break;
    } else if (a === "-h" || a === "--help") {
      console.log(HELP); (cfg as any).exit = 0; return cfg;
    } else if (a === "-V" || a === "--version") {
      console.log("srgn 0.14.1"); (cfg as any).exit = 0; return cfg;
    } else if (a === "--completions") {
      i++; console.log("# completion script generation is not available in this reimplementation"); (cfg as any).exit = 0; return cfg;
    } else if (a === "-u" || a === "--upper") cfg.upper = true;
    else if (a === "-l" || a === "--lower") cfg.lower = true;
    else if (a === "-t" || a === "--titlecase") cfg.title = true;
    else if (a === "-n" || a === "--normalize") cfg.normalize = true;
    else if (a === "-g" || a === "--german") cfg.german = true;
    else if (a === "--german-naive") cfg.germanNaive = true;
    else if (a === "-S" || a === "--symbols") cfg.symbols = true;
    else if (a === "-i" || a === "--invert") cfg.invert = true;
    else if (a === "-d" || a === "--delete") cfg.del = true;
    else if (a === "-s" || a === "--squeeze" || a === "--squeeze-repeats") cfg.squeeze = true;
    else if (a === "-L" || a === "--literal-string") cfg.literal = true;
    else if (a === "--fail-any") cfg.failAny = true;
    else if (a === "--fail-none") cfg.failNone = true;
    else if (a === "--line-numbers") cfg.lineNumbers = true;
    else if (a === "--only-matching") cfg.onlyMatching = true;
    else if (a === "--files") cfg.files = true;
    else if (a === "--fail-no-files") cfg.failNoFiles = true;
    else if (a === "--dry-run") cfg.dryRun = true;
    else if (a === "--sorted") cfg.sorted = true;
    else if (a === "-G" || a === "--glob") cfg.glob = args[++i];
    else if (["--stdin-detection", "--stdout-detection", "--threads"].includes(a)) i++;
    else if (a === "-j" || a === "--join-language-scopes" || a === "-H" || a === "--hidden" || a === "--gitignored" || a.startsWith("-v")) { /* accepted */ }
    else if (["--python", "--py", "--rust", "--rs", "--go", "--typescript", "--ts", "--c", "--csharp", "--cs", "--hcl"].includes(a)) {
      cfg.lang.push({ name: a.replace(/^--?/, ""), value: args[++i] || "" });
    } else if (a.endsWith("-query") || a.endsWith("-query-file")) {
      cfg.lang.push({ name: a.replace(/^--/, ""), value: args[++i] || "" });
    } else if (a.startsWith("-") && a.length > 2 && !a.startsWith("--")) {
      for (const ch of a.slice(1)) {
        if (ch === "u") cfg.upper = true; else if (ch === "l") cfg.lower = true; else if (ch === "t") cfg.title = true;
        else if (ch === "n") cfg.normalize = true; else if (ch === "g") cfg.german = true; else if (ch === "S") cfg.symbols = true;
        else if (ch === "i") cfg.invert = true; else if (ch === "d") cfg.del = true; else if (ch === "s") cfg.squeeze = true;
      }
    } else pos.push(a);
  }
  if (pos.length > 0) cfg.scope = pos[0];
  if (process.env.REPLACE && cfg.replacement === undefined) cfg.replacement = process.env.REPLACE;
  return cfg;
}

function hasActions(c: Config): boolean {
  return c.replacement !== undefined || c.upper || c.lower || c.title || c.normalize || c.german || c.symbols || c.del || c.squeeze;
}

function processText(input: string, cfg: Config, label: string): { output: string; any: boolean } {
  const regex = makeRegex(cfg);
  const spans = languageSpans(input, cfg);
  const scopedMatches = collectMatches(input, regex, spans);
  const any = scopedMatches.length > 0;
  if (!hasActions(cfg)) {
    if (cfg.lang.length > 0 || cfg.lineNumbers || cfg.onlyMatching) return { output: searchOutput(input, scopedMatches, label), any };
    maybeNoActionLog(cfg);
    return { output: input, any };
  }
  if (cfg.squeeze) {
    const pat = cfg.literal ? escapeRegExp(cfg.scope) : cfg.scope;
    const sq = new RegExp(`(?:${pat})+`, "gms");
    return { output: input.replace(sq, (m: string) => {
      const first = m.match(regex);
      return first ? first[0] : m;
    }), any };
  }
  let out = "";
  let last = 0;
  for (const m of input.matchAll(regex)) {
    const start = m.index || 0;
    const end = start + m[0].length;
    if (!inSpans(start, end, spans)) continue;
    out += input.slice(last, start);
    out += transform(m, cfg);
    last = end || start + 1;
    if (end === start) {
      out += input[start] || "";
      last = Math.max(last, start + 1);
    }
  }
  out += input.slice(last);
  return { output: out, any };
}

function makeRegex(cfg: Config): RegExp {
  const pat = cfg.literal ? escapeRegExp(cfg.scope) : cfg.scope;
  try { return new RegExp(pat, "gms"); } catch { return new RegExp(escapeRegExp(cfg.scope), "gms"); }
}

function collectMatches(input: string, regex: RegExp, spans: Span[]): Span[] {
  const matches: Span[] = [];
  for (const m of input.matchAll(regex)) {
    const start = m.index || 0, end = start + m[0].length;
    if (inSpans(start, end, spans)) matches.push({ start, end });
  }
  return matches;
}

function transform(match: RegExpMatchArray, cfg: Config): string {
  let s = match[0];
  if (cfg.del) return "";
  if (cfg.replacement !== undefined) s = replacement(match, cfg.replacement);
  if (cfg.symbols) s = symbols(s, cfg.invert);
  if (cfg.german) s = german(s);
  if (cfg.normalize) s = s.normalize("NFD").replace(/\p{M}/gu, "");
  if (cfg.upper) s = s.toUpperCase();
  if (cfg.lower) s = s.toLowerCase();
  if (cfg.title) s = s.toLowerCase().replace(/(^|[^\p{L}\p{N}_])(\p{L})/gu, (_m, p, ch) => p + ch.toUpperCase());
  return s;
}

function replacement(m: RegExpMatchArray, repl: string): string {
  return repl.replace(/\$(\w+)/g, (_: string, k: string) => {
    if (/^\d+$/.test(k)) return m[Number(k)] ?? "";
    return (m.groups && m.groups[k]) || "";
  });
}

function symbols(s: string, invert: boolean): string {
  const pairs: [string, string][] = [["!=", "≠"], ["->", "→"], ["<-", "←"], [">=", "≥"], ["<=", "≤"], ["---", "—"], ["--", "–"], ["=>", "⇒"]];
  const list = invert ? pairs.map(([a, b]) => [b, a] as [string, string]) : pairs;
  for (const [a, b] of list) s = s.split(a).join(b);
  return s;
}

function german(s: string): string {
  return s.replace(/ae|oe|ue|Ae|Oe|Ue|ss/g, x => ({ ae: "ä", oe: "ö", ue: "ü", Ae: "Ä", Oe: "Ö", Ue: "Ü", ss: "ß" } as any)[x]);
}

function searchOutput(input: string, matches: Span[], label: string): string {
  const byLine = new Map<number, Span[]>();
  const starts = lineStarts(input);
  for (const m of matches) {
    const line = lineFor(starts, m.start);
    const lineStart = starts[line - 1];
    if (!byLine.has(line)) byLine.set(line, []);
    byLine.get(line)!.push({ start: m.start - lineStart, end: m.end - lineStart });
  }
  let out = "";
  const lines = input.split(/\n/);
  for (const [ln, spans] of byLine) {
    const text = (lines[ln - 1] || "").replace(/\r$/, "");
    const coords = spans.map(s => `${s.start}-${s.end}`).join(";");
    out += `${label}:${ln}:${coords}:${text}\n`;
  }
  return out;
}

function languageSpans(input: string, cfg: Config): Span[] {
  if (cfg.lang.length === 0) return [{ start: 0, end: input.length }];
  let spans: Span[] = [];
  for (const l of cfg.lang) spans.push(...spansFor(input, l.name, l.value));
  return spans.length ? mergeSpans(spans) : [];
}

function spansFor(input: string, lang: string, val: string): Span[] {
  const spans: Span[] = [];
  const lines = input.split(/(?<=\n)/);
  let off = 0;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i], trim = line.trim();
    const addLine = () => spans.push({ start: off, end: off + line.length });
    if (["comments"].includes(val) && /^\s*(#|\/\/|\/\*|\*)/.test(line)) addLine();
    else if (["strings", "doc-strings"].includes(val) && /(["'`])/.test(line)) addLine();
    else if (["imports", "uses", "includes", "usings"].includes(val) && /^\s*(import|from|use|#include|using)\b/.test(line)) addLine();
    else if (["class", "struct", "enum", "interface", "trait", "impl", "def", "func", "fn", "function", "method", "constructor", "type-alias", "type-def", "var-decl", "let", "const", "var", "globals", "variable", "resource", "data", "output", "provider", "module", "locals", "terraform"].some(k => val.startsWith(k))) {
      const word = val.split("~")[0];
      if (matchesConstruct(trim, word, lang)) {
        const indent = line.match(/^\s*/)?.[0].length || 0;
        let end = off + line.length, joff = off + line.length;
        for (let j = i + 1; j < lines.length; j++) {
          const ind = lines[j].match(/^\s*/)?.[0].length || 0;
          if (lines[j].trim() && ind <= indent && lang.includes("python")) break;
          if (!lang.includes("python") && /}\s*$/.test(lines[j])) { end = joff + lines[j].length; break; }
          end = joff + lines[j].length; joff += lines[j].length;
        }
        spans.push({ start: off, end });
      }
    } else if (["identifier", "identifiers", "type-identifier", "function-names", "function-calls", "variable-identifiers", "types"].includes(val)) {
      for (const m of line.matchAll(/[A-Za-z_][A-Za-z0-9_]*/g)) spans.push({ start: off + (m.index || 0), end: off + (m.index || 0) + m[0].length });
    } else addLine();
    off += line.length;
  }
  return spans;
}

function matchesConstruct(trim: string, word: string, lang: string): boolean {
  if (word === "class") return /^(export\s+)?(abstract\s+)?class\b/.test(trim);
  if (word === "def" || word.endsWith("fn") || word === "func" || word === "function" || word === "method" || word === "constructor") return /\b(async\s+)?(def|func|fn|function|constructor)\b/.test(trim);
  if (word === "struct") return /\bstruct\b/.test(trim);
  if (word === "enum") return /\benum\b/.test(trim);
  if (word === "interface") return /\binterface\b/.test(trim);
  if (word === "trait") return /\btrait\b/.test(trim);
  if (word === "impl") return /\bimpl\b/.test(trim);
  if (word === "let") return /^let\b/.test(trim);
  if (word === "const") return /^(const|const\s+\()/ .test(trim);
  if (word === "var" || word === "var-decl" || word === "variable" || word === "globals") return /^(let|const|var|[A-Za-z_]\w*\s*=)/.test(trim);
  if (["resource", "data", "output", "provider", "module", "locals", "terraform"].includes(word)) return trim.startsWith(word + " ") || trim.startsWith(word + "{") || trim.startsWith(word + " {");
  return false;
}

function inSpans(start: number, end: number, spans: Span[]): boolean {
  return spans.some(s => start >= s.start && end <= s.end);
}

function mergeSpans(spans: Span[]): Span[] {
  spans.sort((a, b) => a.start - b.start);
  const out: Span[] = [];
  for (const s of spans) {
    const last = out[out.length - 1];
    if (last && s.start <= last.end) last.end = Math.max(last.end, s.end);
    else out.push({ ...s });
  }
  return out;
}

function lineStarts(s: string): number[] {
  const starts = [0];
  for (let i = 0; i < s.length; i++) if (s[i] === "\n") starts.push(i + 1);
  return starts;
}

function lineFor(starts: number[], idx: number): number {
  let n = 1;
  for (let i = 0; i < starts.length; i++) if (starts[i] <= idx) n = i + 1; else break;
  return n;
}

function findFiles(root: string, pattern: string, sorted: boolean): string[] {
  const re = globToRegExp(pattern);
  const out: string[] = [];
  function walk(dir: string): void {
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      if (ent.name === ".git") continue;
      const full = path.join(dir, ent.name);
      const rel = path.relative(root, full);
      if (ent.isDirectory()) walk(full);
      else if (re.test(rel) || re.test(ent.name)) out.push(rel);
    }
  }
  walk(root);
  return sorted ? out.sort() : out;
}

function globToRegExp(g: string): RegExp {
  let r = "^" + escapeRegExp(g).replace(/\\\*\\\*/g, ".*").replace(/\\\*/g, "[^/]*").replace(/\\\?/g, ".") + "$";
  return new RegExp(r);
}

function readStdin(): string {
  try { return fs.readFileSync(0, "utf8"); } catch { return ""; }
}

function maybeNoActionLog(cfg: Config): void {
  if (!hasActions(cfg)) console.error(`[${new Date().toISOString()} ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.`);
}

function failChecks(cfg: Config, any: boolean): void {
  if (cfg.failAny && any) { console.error("Error: Error applying: Some input was in scope"); process.exit(1); }
  if (cfg.failNone && !any) { console.error("Error: Error applying: No input was in scope"); process.exit(1); }
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

main();
