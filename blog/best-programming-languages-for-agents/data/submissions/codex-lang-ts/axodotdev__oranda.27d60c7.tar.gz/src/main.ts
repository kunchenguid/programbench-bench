declare const require: any;
declare const process: any;
declare const __dirname: string;

const fs = require("fs");
const path = require("path");
const http = require("http");

type GlobalOpts = { verbose: boolean; outputFormat: "human" | "json" };

const VERSION = "oranda 0.6.5";

const LONG_MAIN = `🎁 generate beautiful landing pages for your projects

Usage: executable [OPTIONS] <COMMAND>

Commands:
  build     Build an oranda site
  dev       Start a local development server that recompiles your oranda site if a file changes
  serve     Start a file server to access your oranda site in a browser
  generate  Generate infrastructure files for oranda sites
  help      Print this message or the help of the given subcommand(s)

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`;

const SHORT_MAIN = `🎁 generate beautiful landing pages for your projects

Usage: executable [OPTIONS] <COMMAND>

Commands:
  build     Build an oranda site
  dev       Start a local development server that recompiles your oranda site if a file changes
  serve     Start a file server to access your oranda site in a browser
  generate  Generate infrastructure files for oranda sites
  help      Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]`;

const BUILD_HELP = `Build an oranda site

Usage: executable build [OPTIONS]

Options:
      --json-only
          Only build the artifacts JSON file (if applicable) and other files that may be used to
          support it, such as installer source files

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`;

const DEV_HELP = `Start a local development server that recompiles your oranda site if a file changes

Usage: executable dev [OPTIONS]

Options:
      --port <PORT>
          The port for the file server to be launched on

      --no-first-build
          Skip the first build before starting to watch for changes

  -i, --include-paths <INCLUDE_PATHS>
          List of extra paths to watch

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`;

const SERVE_HELP = `Start a file server to access your oranda site in a browser

Usage: executable serve [OPTIONS]

Options:
      --port <PORT>
          [default: 7979]

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`;

const GENERATE_HELP = `Generate infrastructure files for oranda sites

Usage: executable generate [OPTIONS] <COMMAND>

Commands:
  ci    Generates a CI file that can be used to deploy your site
  help  Print this message or the help of the given subcommand(s)

Options:
  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`;

const CI_HELP = `Generates a CI file that can be used to deploy your site

Usage: executable generate ci [OPTIONS]

Options:
      --ci <CI>
          What CI to generate a file for
          
          [default: github]

          Possible values:
          - github: Deploy to GitHub Pages using GitHub Actions

  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`;

function out(s: string) { process.stdout.write(s + "\n"); }
function err(s: string) { process.stderr.write(s + "\n"); }

function fail(message: string, usage?: string): never {
  err(message);
  if (usage) err("\n" + usage);
  err("\nFor more information, try '--help'.");
  process.exit(2);
  throw new Error("unreachable");
}

function parseGlobal(args: string[]): { opts: GlobalOpts; args: string[] } {
  const opts: GlobalOpts = { verbose: false, outputFormat: "human" };
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-v" || a === "--verbose") opts.verbose = true;
    else if (a === "--output-format") {
      const v = args[++i];
      if (v !== "human" && v !== "json") fail(`error: invalid value '${v ?? ""}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]`);
      opts.outputFormat = v;
    } else if (a.startsWith("--output-format=")) {
      const v = a.slice("--output-format=".length);
      if (v !== "human" && v !== "json") fail(`error: invalid value '${v}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]`);
      opts.outputFormat = v;
    } else rest.push(a);
  }
  return { opts, args: rest };
}

function htmlEscape(s: string): string {
  return s.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[c]));
}

function inlineMd(s: string): string {
  return htmlEscape(s)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>")
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
}

function markdownToHtml(md: string): string {
  const lines = md.split(/\r?\n/);
  const chunks: string[] = [];
  let para: string[] = [];
  const flush = () => {
    if (para.length) {
      chunks.push(`<p>${inlineMd(para.join(" "))}</p>`);
      para = [];
    }
  };
  for (const line of lines) {
    if (!line.trim()) { flush(); continue; }
    const h = /^(#{1,6})\s+(.*)$/.exec(line);
    if (h) { flush(); chunks.push(`<h${h[1].length}>${inlineMd(h[2].trim())}</h${h[1].length}>`); continue; }
    para.push(line.trim());
  }
  flush();
  return chunks.join("\n");
}

function readJson(file: string): any {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return {}; }
}

function readCargo(file: string): any {
  const result: any = {};
  try {
    for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
      const m = /^\s*([A-Za-z0-9_-]+)\s*=\s*"([^"]*)"/.exec(line);
      if (m) result[m[1]] = m[2];
    }
  } catch {}
  return result;
}

function discoverProject(): any {
  const cwd = process.cwd();
  let meta: any = {};
  if (fs.existsSync(path.join(cwd, "package.json"))) {
    const p = readJson(path.join(cwd, "package.json"));
    meta.name = p.name; meta.version = p.version; meta.description = p.description; meta.repository = typeof p.repository === "string" ? p.repository : p.repository?.url; meta.homepage = p.homepage; meta.license = p.license;
  }
  if (fs.existsSync(path.join(cwd, "Cargo.toml"))) meta = { ...meta, ...readCargo(path.join(cwd, "Cargo.toml")) };
  for (const cfg of ["oranda.json", "oranda.jsonc"]) {
    if (fs.existsSync(path.join(cwd, cfg))) {
      const c = readJson(path.join(cwd, cfg));
      meta = { ...meta, ...c, ...c.project };
    }
  }
  const readmePath = ["README.md", "readme.md"].map(f => path.join(cwd, f)).find(fs.existsSync);
  const readme = readmePath ? fs.readFileSync(readmePath, "utf8") : "";
  const firstHeading = (readme.match(/^#\s+(.+)$/m) || [])[1];
  meta.name = meta.name || firstHeading || path.basename(cwd);
  meta.description = meta.description || (readme.split(/\r?\n/).find((l: string) => l.trim() && !l.startsWith("#")) || "Generate beautiful landing pages for your projects.");
  meta.readme = readme;
  return meta;
}

function build(jsonOnly: boolean, opts: GlobalOpts) {
  if (opts.verbose) out("↪ >o_o< DEBUG: No config found, using default values");
  fs.mkdirSync("public", { recursive: true });
  if (!jsonOnly) {
    const meta = discoverProject();
    const title = String(meta.name || "oranda");
    const body = meta.readme ? markdownToHtml(meta.readme) : `<h1>${htmlEscape(title)}</h1><p>${inlineMd(String(meta.description || ""))}</p>`;
    const links = [meta.homepage, meta.repository].filter(Boolean).map((u: string) => `<a href="${htmlEscape(u)}">${htmlEscape(u)}</a>`).join(" ");
    fs.writeFileSync(path.join("public", "oranda.css"), defaultCss());
    fs.writeFileSync(path.join("public", "index.html"), `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${htmlEscape(title)}</title>
  <meta name="description" content="${htmlEscape(String(meta.description || ""))}">
  <link rel="stylesheet" href="oranda.css">
</head>
<body>
  <main>
    ${body}
    ${links ? `<p class="links">${links}</p>` : ""}
  </main>
</body>
</html>
`);
    fs.writeFileSync(path.join("public", "favicon.ico"), "");
  }
  out("✓ >o_o< SUCCESS: Your site build is located in `public`.");
}

function defaultCss(): string {
  return `:root{font-family:Inter,ui-sans-serif,system-ui,sans-serif;color:#202124;background:#f7f7f4}body{margin:0}main{max-width:860px;margin:0 auto;padding:56px 24px}h1{font-size:48px;line-height:1.05;margin:0 0 20px}h2{margin-top:36px}p{font-size:18px;line-height:1.65}a{color:#0b6bcb}code{background:#ecece7;padding:2px 5px;border-radius:4px}.links{display:flex;gap:16px;flex-wrap:wrap}`;
}

function ciYaml(sitePath: string): string {
  return `name: Deploy oranda site to Pages

on:
  push:
    branches: ["main"]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "pages"
  cancel-in-progress: false

jobs:
  deploy:
    environment:
      name: github-pages
      url: \${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Install oranda
        run: curl --proto '=https' --tlsv1.2 -LsSf https://github.com/axodotdev/oranda/releases/latest/download/oranda-installer.sh | sh
      - name: Build
        run: oranda build
        working-directory: ${sitePath}
      - name: Setup Pages
        uses: actions/configure-pages@v4
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: ${sitePath}/public
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
`;
}

function generateCi(args: string[], inheritedOutput = "", inheritedSite = ".") {
  let outputPath = inheritedOutput, sitePath = inheritedSite;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--help" || a === "-h") return out(CI_HELP);
    if (a === "-o" || a === "--output-path") outputPath = args[++i];
    else if (a.startsWith("--output-path=")) outputPath = a.split("=", 2)[1];
    else if (a === "-s" || a === "--site-path") sitePath = args[++i];
    else if (a.startsWith("--site-path=")) sitePath = a.split("=", 2)[1];
    else if (a === "--ci") {
      const v = args[++i];
      if (v !== "github") fail(`error: invalid value '${v}' for '--ci <CI>'\n  [possible values: github]`);
    } else if (a.startsWith("--ci=")) {
      const v = a.split("=", 2)[1];
      if (v !== "github") fail(`error: invalid value '${v}' for '--ci <CI>'\n  [possible values: github]`);
    } else fail(`error: unexpected argument '${a}' found`, "Usage: executable generate ci [OPTIONS]");
  }
  if (!outputPath) outputPath = path.join(".github", "workflows", "web.yml");
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  out("↪ >o_o< INFO: Generating a CI deploy workflow for your site...");
  fs.writeFileSync(outputPath, ciYaml(sitePath));
  out(`✓ >o_o< SUCCESS: Wrote ${outputPath}`);
}

function serve(port: number) {
  const root = path.resolve("public");
  if (!fs.existsSync(root)) {
    err("  × Could not find a build in public");
    err("  help: Did you remember to run `oranda build`?");
    process.exit(255);
  }
  const server = http.createServer((req: any, res: any) => {
    const urlPath = decodeURIComponent((req.url || "/").split("?")[0]);
    let file = path.join(root, urlPath === "/" ? "index.html" : urlPath);
    if (!file.startsWith(root)) { res.statusCode = 403; return res.end("Forbidden"); }
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, "index.html");
    if (!fs.existsSync(file)) { res.statusCode = 404; return res.end("Not Found"); }
    res.end(fs.readFileSync(file));
  });
  server.listen(port, "127.0.0.1", () => out(`✓ >o_o< SUCCESS: Your project is available at: http://127.0.0.1:${port}`));
}

function main() {
  const raw = process.argv.slice(2);
  const { opts, args } = parseGlobal(raw);
  if (args.length === 0) { err(SHORT_MAIN); process.exit(2); }
  const cmd = args[0];
  if (cmd === "--help") return out(LONG_MAIN);
  if (cmd === "-h") return out(SHORT_MAIN);
  if (cmd === "--version" || cmd === "-V") return out(VERSION);
  if (cmd === "help") {
    const topic = args.slice(1).join(" ");
    if (!topic) return out(LONG_MAIN);
    if (topic === "build") return out(BUILD_HELP);
    if (topic === "dev") return out(DEV_HELP);
    if (topic === "serve") return out(SERVE_HELP);
    if (topic === "generate") return out(GENERATE_HELP);
    if (topic === "generate ci") return out(CI_HELP);
    fail(`error: unrecognized subcommand '${args[1] || ""}'`, "Usage: executable [OPTIONS] <COMMAND>");
  }
  if (cmd === "build") {
    let jsonOnly = false;
    for (const a of args.slice(1)) {
      if (a === "--help") return out(BUILD_HELP);
      else if (a === "-h") return out(BUILD_HELP);
      else if (a === "--json-only") jsonOnly = true;
      else fail(`error: unexpected argument '${a}' found`, "Usage: executable build [OPTIONS]");
    }
    return build(jsonOnly, opts);
  }
  if (cmd === "generate") {
    const rest = args.slice(1);
    if (rest[0] === "--help" || rest[0] === "-h") return out(GENERATE_HELP);
    if (rest[0] === "help") {
      if (rest[1] === "ci") return out(CI_HELP);
      return out(GENERATE_HELP);
    }
    let outputPath = "", sitePath = ".";
    let i = 0;
    while (i < rest.length) {
      const a = rest[i];
      if (a === "-o" || a === "--output-path") { outputPath = rest[++i]; i++; }
      else if (a.startsWith("--output-path=")) { outputPath = a.split("=", 2)[1]; i++; }
      else if (a === "-s" || a === "--site-path") { sitePath = rest[++i]; i++; }
      else if (a.startsWith("--site-path=")) { sitePath = a.split("=", 2)[1]; i++; }
      else break;
    }
    const sub = rest[i];
    if (sub === "ci") return generateCi(rest.slice(i + 1), outputPath, sitePath);
    if (!sub) fail("error: the following required arguments were not provided:\n  <COMMAND>", "Usage: executable generate [OPTIONS] <COMMAND>");
    fail(`error: unrecognized subcommand '${sub}'`, "Usage: executable generate [OPTIONS] <COMMAND>");
  }
  if (cmd === "serve") {
    let port = 7979;
    for (let i = 1; i < args.length; i++) {
      const a = args[i];
      if (a === "--help" || a === "-h") return out(SERVE_HELP);
      if (a === "--port") port = Number(args[++i]);
      else if (a.startsWith("--port=")) port = Number(a.split("=", 2)[1]);
      else fail(`error: unexpected argument '${a}' found`, "Usage: executable serve [OPTIONS]");
    }
    return serve(port);
  }
  if (cmd === "dev") {
    let port = 7979, first = true, includes = 0;
    for (let i = 1; i < args.length; i++) {
      const a = args[i];
      if (a === "--help" || a === "-h") return out(DEV_HELP);
      if (a === "--port") port = Number(args[++i]);
      else if (a.startsWith("--port=")) port = Number(a.split("=", 2)[1]);
      else if (a === "--no-first-build") first = false;
      else if (a === "-i" || a === "--include-paths") { includes++; i++; }
      else fail(`error: unexpected argument '${a}' found`, "Usage: executable dev [OPTIONS]");
    }
    if (first) build(false, opts);
    out(`↪ >o_o< INFO: Found ${includes} paths to watch, starting watch...`);
    return serve(port);
  }
  fail(`error: unrecognized subcommand '${cmd}'`, "Usage: executable [OPTIONS] <COMMAND>");
}

main();
