declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const os = require("os");
const path = require("path");
const cp = require("child_process");
const readline = require("readline");

const VERSION = "eureka 2.0.0";
const GREEN_BOLD = "\x1b[0m\x1b[1m\x1b[32m";
const YELLOW = "\x1b[0m\x1b[33m";
const RESET = "\x1b[0m";

function configPath(): string {
  const base = process.env.XDG_CONFIG_HOME || path.join(process.env.HOME || os.homedir(), ".config");
  return path.join(base, "eureka", "config.json");
}

function printHelp(): void {
  console.log("Input and store your ideas without leaving the terminal");
  console.log("");
  console.log("Usage: executable [OPTIONS]");
  console.log("");
  console.log("Options:");
  console.log("      --clear-config  Clear your stored configuration");
  console.log("  -v, --view          View ideas with your $PAGER env variable. If unset use less");
  console.log("  -h, --help          Print help");
  console.log("  -V, --version       Print version");
}

function clapError(arg: string): void {
  console.error(`error: unexpected argument '${arg}' found`);
  console.error("");
  console.error("Usage: executable [OPTIONS]");
  console.error("");
  console.error("For more information, try '--help'.");
  process.exitCode = 2;
}

function eurekaError(message: string): void {
  console.error(` ERROR eureka > ${message}`);
}

function readConfig(): { repo: string } | null {
  try {
    const raw = fs.readFileSync(configPath(), "utf8");
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed.repo === "string") return { repo: parsed.repo };
    return null;
  } catch (err: any) {
    eurekaError(err && err.message ? err.message : String(err));
    return null;
  }
}

function prompt(question: string): Promise<string> {
  return new Promise((resolve) => {
    process.stdout.write(`${GREEN_BOLD}${question}\n${RESET}> `);
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: false });
    let settled = false;
    rl.once("line", (line: string) => {
      settled = true;
      rl.close();
      resolve(line.trim());
    });
    rl.once("close", () => {
      if (!settled) resolve("");
    });
  });
}

async function firstTimeSetup(): Promise<void> {
  console.log(`${YELLOW}############################################################`);
  console.log("####                  First Time Setup                  ####");
  console.log("############################################################");
  console.log("");
  console.log("This tool requires you to have a repository with a README.md");
  console.log("in the root folder. The markdown file is where your ideas");
  console.log("will be stored.");
  console.log("");
  console.log("Once first time setup has completed, simply run Eureka again");
  console.log("to begin writing down ideas.");
  console.log(`        \n${RESET}`);
  const repo = await prompt("Absolute path to your idea repo");
  if (!repo) return;
  const readme = path.join(repo, "README.md");
  if (!path.isAbsolute(repo)) {
    eurekaError("idea repo path must be absolute");
    return;
  }
  if (!fs.existsSync(readme)) {
    eurekaError(`README.md not found in ${repo}`);
    return;
  }
  fs.mkdirSync(path.dirname(configPath()), { recursive: true });
  fs.writeFileSync(configPath(), JSON.stringify({ repo }));
  console.log("First time setup complete. Happy ideation!");
}

function runGit(repo: string, args: string[]): { ok: boolean; stderr: string } {
  const res = cp.spawnSync("git", ["-C", repo, ...args], { encoding: "utf8" });
  return { ok: res.status === 0, stderr: (res.stderr || "").trim() };
}

function currentBranch(repo: string): string {
  const res = cp.spawnSync("git", ["-C", repo, "branch", "--show-current"], { encoding: "utf8" });
  const branch = (res.stdout || "").trim();
  return branch || "main";
}

function shellQuote(s: string): string {
  return `'${s.replace(/'/g, "'\\''")}'`;
}

function editIdea(summary: string): string {
  const editor = process.env.EDITOR || process.env.VISUAL || "vi";
  const tmp = path.join(os.tmpdir(), `eureka-${process.pid}-${Date.now()}.md`);
  fs.writeFileSync(tmp, "");
  const command = `${editor} ${shellQuote(tmp)}`;
  const res = cp.spawnSync(command, { shell: true, stdio: "inherit" });
  let body = "";
  try {
    body = fs.readFileSync(tmp, "utf8").trim();
    fs.unlinkSync(tmp);
  } catch {
    body = "";
  }
  if (res.status !== 0 && body.length === 0) return "";
  if (body.length === 0) return summary;
  return body;
}

function appendIdea(repo: string, summary: string, body: string): void {
  const readme = path.join(repo, "README.md");
  let existing = fs.readFileSync(readme, "utf8");
  const stamp = new Date().toISOString().slice(0, 10);
  const entry = `\n\n## ${summary}\n\n${body}\n\n_Added ${stamp}_\n`;
  if (existing.endsWith("\n")) existing = existing.replace(/\n+$/, "\n");
  fs.writeFileSync(readme, existing + entry);
}

async function captureIdea(): Promise<void> {
  const cfg = readConfig();
  if (!cfg) return;
  const summary = await prompt(">> Idea summary");
  if (!summary) return;
  const body = editIdea(summary);
  appendIdea(cfg.repo, summary, body);
  const branch = currentBranch(cfg.repo);
  console.log(`Adding and committing your new idea to ${branch}..`);
  runGit(cfg.repo, ["add", "README.md"]);
  let committed = runGit(cfg.repo, ["commit", "-m", summary]);
  if (!committed.ok) {
    committed = runGit(cfg.repo, ["commit", "--allow-empty", "-m", summary]);
  }
  if (!committed.ok && committed.stderr) eurekaError(committed.stderr.split("\n")[0]);
  else console.log("Added and committed!");
  console.log("Pushing your new idea..");
  const pushed = runGit(cfg.repo, ["push"]);
  if (!pushed.ok && pushed.stderr) eurekaError(pushed.stderr.split("\n")[0]);
}

function viewIdeas(): void {
  const cfg = readConfig();
  if (!cfg) return;
  const readme = path.join(cfg.repo, "README.md");
  const pager = process.env.PAGER || "less";
  const res = cp.spawnSync(pager, [readme], { stdio: "inherit", shell: false });
  if (res.error) {
    try {
      process.stdout.write(fs.readFileSync(readme));
    } catch (err: any) {
      eurekaError(err && err.message ? err.message : String(err));
    }
  }
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  for (const arg of args) {
    if (!["--clear-config", "--view", "-v", "--help", "-h", "--version", "-V"].includes(arg)) {
      clapError(arg);
      return;
    }
  }
  if (args.includes("--help") || args.includes("-h")) return printHelp();
  if (args.includes("--version") || args.includes("-V")) return console.log(VERSION);
  if (args.includes("--clear-config")) {
    try { fs.unlinkSync(configPath()); } catch {}
    return;
  }
  if (args.includes("--view") || args.includes("-v")) return viewIdeas();
  if (!fs.existsSync(configPath())) return firstTimeSetup();
  return captureIdea();
}

main().catch((err: any) => {
  eurekaError(err && err.message ? err.message : String(err));
});
