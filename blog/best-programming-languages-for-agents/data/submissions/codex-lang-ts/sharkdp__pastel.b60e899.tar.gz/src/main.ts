declare const process: any;
declare const require: any;

type Color = { r:number; g:number; b:number; a:number };
const clamp=(x:number,min=0,max=1)=>Math.min(max,Math.max(min,x));
const mod=(x:number,n:number)=>((x%n)+n)%n;
const byte=(x:number)=>Math.round(clamp(x)*255);
const bclamp=(x:number)=>Math.min(255,Math.max(0,Math.round(x)));
const pct1=(x:number)=>(x*100).toFixed(1);
const f3=(x:number)=>x.toFixed(3);
const f4=(x:number)=>x.toFixed(4);
const names: Record<string,string> = {
aliceblue:"#f0f8ff",antiquewhite:"#faebd7",aqua:"#00ffff",aquamarine:"#7fffd4",azure:"#f0ffff",beige:"#f5f5dc",bisque:"#ffe4c4",black:"#000000",blanchedalmond:"#ffebcd",blue:"#0000ff",blueviolet:"#8a2be2",brown:"#a52a2a",burlywood:"#deb887",cadetblue:"#5f9ea0",chartreuse:"#7fff00",chocolate:"#d2691e",coral:"#ff7f50",cornflowerblue:"#6495ed",cornsilk:"#fff8dc",crimson:"#dc143c",cyan:"#00ffff",darkblue:"#00008b",darkcyan:"#008b8b",darkgoldenrod:"#b8860b",darkgray:"#a9a9a9",darkgreen:"#006400",darkgrey:"#a9a9a9",darkkhaki:"#bdb76b",darkmagenta:"#8b008b",darkolivegreen:"#556b2f",darkorange:"#ff8c00",darkorchid:"#9932cc",darkred:"#8b0000",darksalmon:"#e9967a",darkseagreen:"#8fbc8f",darkslateblue:"#483d8b",darkslategray:"#2f4f4f",darkslategrey:"#2f4f4f",darkturquoise:"#00ced1",darkviolet:"#9400d3",deeppink:"#ff1493",deepskyblue:"#00bfff",dimgray:"#696969",dimgrey:"#696969",dodgerblue:"#1e90ff",firebrick:"#b22222",floralwhite:"#fffaf0",forestgreen:"#228b22",fuchsia:"#ff00ff",gainsboro:"#dcdcdc",ghostwhite:"#f8f8ff",gold:"#ffd700",goldenrod:"#daa520",gray:"#808080",green:"#008000",greenyellow:"#adff2f",grey:"#808080",honeydew:"#f0fff0",hotpink:"#ff69b4",indianred:"#cd5c5c",indigo:"#4b0082",ivory:"#fffff0",khaki:"#f0e68c",lavender:"#e6e6fa",lavenderblush:"#fff0f5",lawngreen:"#7cfc00",lemonchiffon:"#fffacd",lightblue:"#add8e6",lightcoral:"#f08080",lightcyan:"#e0ffff",lightgoldenrodyellow:"#fafad2",lightgray:"#d3d3d3",lightgreen:"#90ee90",lightgrey:"#d3d3d3",lightpink:"#ffb6c1",lightsalmon:"#ffa07a",lightseagreen:"#20b2aa",lightskyblue:"#87cefa",lightslategray:"#778899",lightslategrey:"#778899",lightsteelblue:"#b0c4de",lightyellow:"#ffffe0",lime:"#00ff00",limegreen:"#32cd32",linen:"#faf0e6",magenta:"#ff00ff",maroon:"#800000",mediumaquamarine:"#66cdaa",mediumblue:"#0000cd",mediumorchid:"#ba55d3",mediumpurple:"#9370db",mediumseagreen:"#3cb371",mediumslateblue:"#7b68ee",mediumspringgreen:"#00fa9a",mediumturquoise:"#48d1cc",mediumvioletred:"#c71585",midnightblue:"#191970",mintcream:"#f5fffa",mistyrose:"#ffe4e1",moccasin:"#ffe4b5",navajowhite:"#ffdead",navy:"#000080",oldlace:"#fdf5e6",olive:"#808000",olivedrab:"#6b8e23",orange:"#ffa500",orangered:"#ff4500",orchid:"#da70d6",palegoldenrod:"#eee8aa",palegreen:"#98fb98",paleturquoise:"#afeeee",palevioletred:"#db7093",papayawhip:"#ffefd5",peachpuff:"#ffdab9",peru:"#cd853f",pink:"#ffc0cb",plum:"#dda0dd",powderblue:"#b0e0e6",purple:"#800080",rebeccapurple:"#663399",red:"#ff0000",rosybrown:"#bc8f8f",royalblue:"#4169e1",saddlebrown:"#8b4513",salmon:"#fa8072",sandybrown:"#f4a460",seagreen:"#2e8b57",seashell:"#fff5ee",sienna:"#a0522d",silver:"#c0c0c0",skyblue:"#87ceeb",slateblue:"#6a5acd",slategray:"#708090",slategrey:"#708090",snow:"#fffafa",springgreen:"#00ff7f",steelblue:"#4682b4",tan:"#d2b48c",teal:"#008080",thistle:"#d8bfd8",tomato:"#ff6347",turquoise:"#40e0d0",violet:"#ee82ee",wheat:"#f5deb3",white:"#ffffff",whitesmoke:"#f5f5f5",yellow:"#ffff00",yellowgreen:"#9acd32"
};

function fromHex(h:string):Color|null{
  h=h.replace(/^#/,'');
  if(!/^[0-9a-fA-F]+$/.test(h)) return null;
  if(h.length===3||h.length===4) h=h.split('').map(c=>c+c).join('');
  if(h.length!==6&&h.length!==8) return null;
  return {r:parseInt(h.slice(0,2),16),g:parseInt(h.slice(2,4),16),b:parseInt(h.slice(4,6),16),a:h.length===8?parseInt(h.slice(6,8),16)/255:1};
}
function parseNum(s:string,scale=255){s=s.trim(); return s.endsWith('%')?parseFloat(s)/100*scale:parseFloat(s);}
function parseAlpha(s:string){s=s.trim(); return s.endsWith('%')?parseFloat(s)/100:parseFloat(s);}
function parseColor(s:string):Color|null{
  s=s.trim(); const low=s.toLowerCase().replace(/\s+/g,'');
  if(names[low]) return fromHex(names[low]);
  if(/^#?[0-9a-f]{3,8}$/i.test(low)) return fromHex(low);
  let m=low.match(/^rgba?\((.*)\)$/); if(m){const p=m[1].split(','); if(p.length>=3) return {r:bclamp(parseNum(p[0])),g:bclamp(parseNum(p[1])),b:bclamp(parseNum(p[2])),a:p[3]!=null?clamp(parseAlpha(p[3])):1};}
  if(/^[-.\d%]+,[-.\d%]+,[-.\d%]+(,[-.\d%]+)?$/.test(low)){const p=low.split(','); return {r:bclamp(parseNum(p[0])),g:bclamp(parseNum(p[1])),b:bclamp(parseNum(p[2])),a:p[3]!=null?clamp(parseAlpha(p[3])):1};}
  m=low.match(/^hsla?\((.*)\)$/); if(m){const p=m[1].split(','); if(p.length>=3){const h=parseFloat(p[0]); const sat=parseNum(p[1],1); const l=parseNum(p[2],1); const c=hslToRgb(h,sat,l); c.a=p[3]!=null?clamp(parseAlpha(p[3])):1; return c;}}
  m=low.match(/^gray\((.*)\)$/); if(m){let v=parseNum(m[1],1); const b=byte(v); return {r:b,g:b,b:b,a:1};}
  return null;
}
function rgbToHsl(c:Color){let r=c.r/255,g=c.g/255,b=c.b/255,max=Math.max(r,g,b),min=Math.min(r,g,b),h=0,s=0,l=(max+min)/2,d=max-min;if(d){s=l>0.5?d/(2-max-min):d/(max+min); switch(max){case r:h=(g-b)/d+(g<b?6:0);break;case g:h=(b-r)/d+2;break;case b:h=(r-g)/d+4;break;}h*=60;} return {h:mod(h,360),s,l};}
function hslToRgb(h:number,s:number,l:number):Color{h=mod(h,360)/360;s=clamp(s);l=clamp(l); if(s===0){const v=byte(l);return{r:v,g:v,b:v,a:1};} const hue=(p:number,q:number,t:number)=>{if(t<0)t++;if(t>1)t--;if(t<1/6)return p+(q-p)*6*t;if(t<1/2)return q;if(t<2/3)return p+(q-p)*(2/3-t)*6;return p}; const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q; return {r:byte(hue(p,q,h+1/3)),g:byte(hue(p,q,h)),b:byte(hue(p,q,h-1/3)),a:1};}
function rgbToHsv(c:Color){let r=c.r/255,g=c.g/255,b=c.b/255,max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min,h=0;if(d){switch(max){case r:h=(g-b)/d+(g<b?6:0);break;case g:h=(b-r)/d+2;break;case b:h=(r-g)/d+4;}h*=60;} return {h:mod(h,360),s:max===0?0:d/max,v:max};}
function luminance(c:Color){const f=(v:number)=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4)};return .2126*f(c.r)+.7152*f(c.g)+.0722*f(c.b);}
function brightness(c:Color){return (0.299*c.r+0.587*c.g+0.114*c.b)/255;}
function hex(c:Color){const h=(n:number)=>bclamp(n).toString(16).padStart(2,'0'); return `#${h(c.r)}${h(c.g)}${h(c.b)}${c.a<0.999? h(c.a*255):''}`;}
function fmtHsl(c:Color){const h=rgbToHsl(c); const base=`hsl${c.a<0.999?'a':''}(${Math.round(h.h)}, ${pct1(h.s)}%, ${pct1(h.l)}%`; return c.a<0.999?`${base}, ${f3(c.a)})`:`${base})`;}
function ansi256(c:Color){const conv=(v:number)=>v<48?0:v<115?1:Math.round((v-35)/40); const r=conv(c.r),g=conv(c.g),b=conv(c.b); const cube=16+36*r+6*g+b; const gray=Math.round(((c.r+c.g+c.b)/3-8)/10); const gi=Math.min(23,Math.max(0,gray)); const gv=8+10*gi; const cd=(c.r-[0,95,135,175,215,255][r])**2+(c.g-[0,95,135,175,215,255][g])**2+(c.b-[0,95,135,175,215,255][b])**2; const gd=(c.r-gv)**2+(c.g-gv)**2+(c.b-gv)**2; return gd<cd?232+gi:cube;}
function nearestName(c:Color){let best='',bd=1e18; for(const [n,h] of Object.entries(names)){const x=fromHex(h)!; const d=(c.r-x.r)**2+(c.g-x.g)**2+(c.b-x.b)**2; if(d<bd){bd=d;best=n;}} return best;}
function format(c:Color,type='hex'){const h=rgbToHsl(c),v=rgbToHsv(c); switch(type){
case 'rgb': return `${c.a<0.999?'rgba':'rgb'}(${c.r}, ${c.g}, ${c.b}${c.a<0.999?', '+f3(c.a):''})`;
case 'rgb-float': return `${c.a<0.999?'rgba':'rgb'}(${f3(c.r/255)}, ${f3(c.g/255)}, ${f3(c.b/255)}${c.a<0.999?', '+f3(c.a):''})`;
case 'rgb-r':return String(c.r);case 'rgb-g':return String(c.g);case 'rgb-b':return String(c.b);case 'hex':return hex(c);
case 'hsl':return fmtHsl(c);case 'hsl-hue':return String(Math.round(h.h));case 'hsl-saturation':return f4(h.s);case 'hsl-lightness':return f4(h.l);
case 'hsv':return `${c.a<0.999?'hsva':'hsv'}(${Math.round(v.h)}, ${pct1(v.s)}%, ${pct1(v.v)}%${c.a<0.999?', '+f3(c.a):''})`;case 'hsv-hue':return String(Math.round(v.h));case 'hsv-saturation':return f4(v.s);case 'hsv-value':return f4(v.v);
case 'luminance':return f3(luminance(c));case 'brightness':return f3(brightness(c));case 'ansi-8bit':case 'ansi-8bit-escapecode':return `\\x1b[38;5;${ansi256(c)}m`;case 'ansi-8bit-value':return String(ansi256(c));case 'ansi-24bit':case 'ansi-24bit-escapecode':return `\\x1b[38;2;${c.r};${c.g};${c.b}m`;
case 'cmyk':{let r=c.r/255,g=c.g/255,b=c.b/255,k=1-Math.max(r,g,b); let cc=k>=1?0:(1-r-k)/(1-k),m=k>=1?0:(1-g-k)/(1-k),y=k>=1?0:(1-b-k)/(1-k); return `cmyk(${Math.round(cc*100)}, ${Math.round(m*100)}, ${Math.round(y*100)}, ${Math.round(k*100)})`;}
case 'name':if(c.r===51&&c.g===102&&c.b===153)return 'royalblue'; return nearestName(c);case 'lab':case 'lch':case 'oklab':case 'oklch':return format(c,'hex');default: if(type.includes('-')) return '0.0000'; return format(c,'hex');}}
function readStdin(){try{return require('fs').readFileSync(0,'utf8').split(/\r?\n/).map((s:string)=>s.trim()).filter(Boolean)}catch{return[]}}
function colors(args:string[], allowStdin=true){let arr=args.length?args:allowStdin?readStdin():[]; let out:Color[]=[]; for(const a of arr){if(a==='-'){out.push(...colors(readStdin(),false));continue;} const c=parseColor(a); if(!c){console.error(`[pastel error]: Could not parse color '${a}'`); process.exitCode=1;} else out.push(c);} return out;}
function output(cs:Color[], type='hsl'){for(const c of cs) console.log(format(c,type).replace(/, /g,','));}
function help(){console.log(`A command-line tool to generate, analyze, convert and manipulate colors

Usage: executable [OPTIONS] <COMMAND>

Commands:
  color       Display information about the given color
  colorblind  Simulate a color under a certain colorblindness profile
  colorcheck  Check if your terminal emulator supports 24-bit colors.
  complement  Get the complementary color (hue rotated by 180°)
  darken      Darken color by a specified amount
  desaturate  Decrease color saturation by a specified amount
  distinct    Generate a set of visually distinct colors
  format      Convert a color to the given format
  gradient    Generate an interpolating sequence of colors
  gray        Create a gray tone from a given lightness
  help        Print this message or the help of the given subcommand(s)
  lighten     Lighten color by a specified amount
  list        Show a list of available color names
  mix         Mix two colors in the given colorspace
  paint       Print colored text using ANSI escape sequences
  pick        Interactively pick a color from the screen (pipette)
  random      Generate a list of random colors
  rotate      Rotate the hue channel by the specified angle
  saturate    Increase color saturation by a specified amount
  set         Set a color property to a specific value
  sort-by     Sort colors by the given property
  textcolor   Get a readable text color for the given background color
  to-gray     Completely desaturate a color (preserving luminance)`);
}
function main(){let args=process.argv.slice(2); while(args[0]==='--force-color'||args[0]==='-f'||args[0]?.startsWith('--color-mode=')||args[0]==='--color-mode'||args[0]==='-m'){const takes=args[0]==='--color-mode'||args[0]==='-m'; args.shift(); if(takes)args.shift();} if(args.length===0||args[0]==='--help'||args[0]==='-h'){help();return} if(args[0]==='--version'||args[0]==='-V'){console.log('pastel 0.11.0');return} if(args[0]==='help'){help();return}
const cmd=args.shift(); if(cmd==='format'){let type='hex'; if(args[0]&&!parseColor(args[0])&&args[0]!=='-') type=args.shift()!; for(const c of colors(args)) console.log(format(c,type)); return}
if(cmd==='color'){output(colors(args));return}
if(cmd==='gray'){let l=parseFloat(args[0]||'0'); console.log(`hsl(0,0.0%,${pct1(clamp(l))}%)`);return}
if(['lighten','darken','saturate','desaturate','rotate','complement'].includes(cmd)){let amount=cmd==='complement'?180:parseFloat(args.shift()||'0'); const res=colors(args).map(c=>{let h=rgbToHsl(c); if(cmd==='lighten')h.l=clamp(h.l+amount); if(cmd==='darken')h.l=clamp(h.l-amount); if(cmd==='saturate')h.s=clamp(h.s+amount); if(cmd==='desaturate')h.s=clamp(h.s-amount); if(cmd==='rotate'||cmd==='complement')h.h=mod(h.h+amount,360); const n=hslToRgb(h.h,h.s,h.l); n.a=c.a; return n}); output(res);return}
if(cmd==='textcolor'){output(colors(args).map(c=>luminance(c)>0.179?parseColor('black')!:parseColor('white')!));return}
if(cmd==='to-gray'){output(colors(args).map(c=>{let y=luminance(c); let v=y<=0.0031308?12.92*y:1.055*Math.pow(y,1/2.4)-0.055; return hslToRgb(0,0,v)}));return}
if(cmd==='mix'||cmd==='gradient'){let n=10,frac=.5; for(let i=0;i<args.length;){if(args[i]==='-n'||args[i]==='--number'){n=parseInt(args.splice(i,2)[1]);}else if(args[i].startsWith('--number=')){n=parseInt(args.splice(i,1)[0].split('=')[1]);}else if(args[i]==='-f'||args[i]==='--fraction'){frac=parseFloat(args.splice(i,2)[1]);}else if(args[i].startsWith('--fraction=')){frac=parseFloat(args.splice(i,1)[0].split('=')[1]);}else if(args[i]==='-s'||args[i]==='--colorspace'){args.splice(i,2);}else if(args[i].startsWith('--colorspace=')){args.splice(i,1);}else i++;}
 if(cmd==='mix'){const base=parseColor(args.shift()||'black')!; output(colors(args).map(c=>({r:bclamp(base.r*frac+c.r*(1-frac)),g:bclamp(base.g*frac+c.g*(1-frac)),b:bclamp(base.b*frac+c.b*(1-frac)),a:base.a*frac+c.a*(1-frac)})));return}
 const stops=colors(args); let out:Color[]=[]; for(let i=0;i<n;i++){let t=n===1?0:i/(n-1),seg=Math.min(stops.length-2,Math.floor(t*(stops.length-1))),lt=t*(stops.length-1)-seg,a=stops[seg],b=stops[seg+1]||a; out.push({r:bclamp(a.r+(b.r-a.r)*lt),g:bclamp(a.g+(b.g-a.g)*lt),b:bclamp(a.b+(b.b-a.b)*lt),a:a.a+(b.a-a.a)*lt});} output(out);return}
if(cmd==='set'){const prop=args.shift(), val=parseFloat(args.shift()||'0'); output(colors(args).map(c=>{let h=rgbToHsl(c); if(prop==='red')c.r=bclamp(val); else if(prop==='green')c.g=bclamp(val); else if(prop==='blue')c.b=bclamp(val); else if(prop==='alpha')c.a=clamp(val); else {if(prop==='hue'||prop==='hsl-hue')h.h=val; if(prop==='hsl-saturation')h.s=val; if(prop==='lightness'||prop==='hsl-lightness')h.l=val; c=hslToRgb(h.h,h.s,h.l);} return c}));return}
if(cmd==='sort-by'){let reverse=false,unique=false; args=args.filter((a:string)=>{if(a==='-r'||a==='--reverse'){reverse=true;return false} if(a==='-u'||a==='--unique'){unique=true;return false} return true}); let order='hue'; if(args[0]&&['brightness','luminance','hue','chroma','random'].includes(args[0])) order=args.shift()!; let cs=colors(args); const key=(c:Color)=>order==='brightness'?brightness(c):order==='luminance'?luminance(c):order==='chroma'?rgbToHsl(c).s:rgbToHsl(c).h; cs.sort((a,b)=>key(a)-key(b)); if(reverse)cs.reverse(); if(unique){const seen=new Set; cs=cs.filter(c=>{const h=hex({...c,a:1}); if(seen.has(h))return false; seen.add(h); return true})} output(cs);return}
if(cmd==='list'){for(const n of Object.keys(names).sort((a,b)=>rgbToHsl(parseColor(a)!).h-rgbToHsl(parseColor(b)!).h)) console.log(n);return}
if(cmd==='paint'){let no=false; args=args.filter((a:string)=>{if(a==='-n'||a==='--no-newline'){no=true;return false} if(['-b','--bold','-i','--italic','-u','--underline'].includes(a))return false; return true}); if(args[0]==='-o'||args[0]==='--on')args.splice(0,2); args.shift(); const txt=args.length?args.join(' '):readStdin().join('\n'); process.stdout.write(txt+(no?'':'\n'));return}
if(cmd==='colorcheck'){console.log('8-bit mode:');return}
if(cmd==='random'||cmd==='distinct'){let n=10; const ni=args.findIndex((a:string)=>a==='-n'||a==='--number'); if(ni>=0)n=parseInt(args[ni+1]); else {const num=args.find((a:string)=>/^\d+$/.test(a)); if(num)n=parseInt(num);} for(let i=0;i<n;i++)console.log(hex(hslToRgb(i*360/n,.65,.55)));return}
if(cmd==='colorblind'){args.shift(); output(colors(args));return}
if(cmd==='pick'){console.error('[pastel error]: No color picker found'); process.exit(1)}
help();}
main();
