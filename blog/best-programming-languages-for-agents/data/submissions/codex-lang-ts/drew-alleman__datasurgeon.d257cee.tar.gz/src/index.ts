const fs = require('fs');
const path = require('path');

interface Options {
  file: string; directory: string; add: string; update: string; remove: string; output: string;
  clean: boolean; ignore: boolean; line: boolean; thorough: boolean; display: boolean; suppress: boolean; hide: boolean; time: boolean; list: boolean; help: boolean; version: boolean;
  drop: string; filter: string;
  detectors: Set<string>;
}

const pluginPath = `${process.env.HOME || '/home/agent'}/.DataSurgeon/plugins.json`;
const detectorOrder = ['email','phone','hashes','ip_address','ipv6_address','mac_address','credit_card','url','files','bitcoin_wallet','aws','google','dns','social_security'];
const defaultOrder = ['email','phone','ip_address','mac_address','url','hashes','credit_card','social_security','bitcoin_wallet','files'];
const flagMap: Record<string,string> = { e:'email', p:'phone', H:'hashes', i:'ip_address', '6':'ipv6_address', m:'mac_address', c:'credit_card', u:'url', F:'files', b:'bitcoin_wallet', a:'aws', g:'google', d:'dns', s:'social_security' };
const longDetector: Record<string,string> = { email:'email', phone:'phone', hash:'hashes', 'ip-addr':'ip_address', 'ipv6-addr':'ipv6_address', 'mac-addr':'mac_address', 'credit-card':'credit_card', url:'url', files:'files', bitcoin:'bitcoin_wallet', aws:'aws', google:'google', dns:'dns', social:'social_security' };

function defaults(): Options {
  return { file:'', directory:'', add:'', update:'', remove:'', output:'', clean:false, ignore:false, line:false, thorough:false, display:false, suppress:false, hide:false, time:false, list:false, help:false, version:false, drop:'', filter:'', detectors:new Set() };
}

function parse(argv: string[]): Options {
  const o = defaults();
  const needVal: Record<string, keyof Options> = { '--file':'file','-f':'file','--directory':'directory','--add':'add','--update':'update','--remove':'remove','--output':'output','-o':'output','--drop':'drop','--filter':'filter' };
  for (let i=0;i<argv.length;i++) {
    const a = argv[i];
    if (needVal[a]) { (o as any)[needVal[a]] = argv[++i] ?? ''; continue; }
    if (a.startsWith('--')) {
      const name = a.slice(2);
      if (longDetector[name]) o.detectors.add(longDetector[name]);
      else if (name === 'clean') o.clean = true;
      else if (name === 'ignore') o.ignore = true;
      else if (name === 'line') o.line = true;
      else if (name === 'thorough') o.thorough = true;
      else if (name === 'display') o.display = true;
      else if (name === 'suppress') o.suppress = true;
      else if (name === 'hide') o.hide = true;
      else if (name === 'time') o.time = true;
      else if (name === 'list') o.list = true;
      else if (name === 'help') o.help = true;
      else if (name === 'version') o.version = true;
      continue;
    }
    if (a.startsWith('-') && a.length > 1) {
      for (const ch of a.slice(1)) {
        if (flagMap[ch]) o.detectors.add(flagMap[ch]);
        else if (ch === 'C') o.clean = true;
        else if (ch === 'l') o.line = true;
        else if (ch === 'T') o.thorough = true;
        else if (ch === 'D') o.display = true;
        else if (ch === 'S') o.suppress = true;
        else if (ch === 'X') o.hide = true;
        else if (ch === 't') o.time = true;
        else if (ch === 'h') o.help = true;
        else if (ch === 'V') o.version = true;
      }
    }
  }
  return o;
}

function pluginWarning() { console.error(`Failed to open plugins.json file. PLUGIN_PATH: ${pluginPath}`); }

function printHelp() {
  console.log(`Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.\n\nUsage: executable [OPTIONS]\n\nOptions:\n  -f, --file <file>            File to extract information from [default: ""]\n      --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]\n      --update <update>        Updates a plugin from a GitHub repository. You can also use \`ds --update all\` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: ""]\n      --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]\n      --list                   List all added plugins\n  -C, --clean                  Only displays the matched result, rather than the entire line\n      --directory <directory>  Process all files found in the specified directory [default: ""]\n      --ignore                 Silences error messages\n  -l, --line                   Displays the line number where the match occurred\n  -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line\n  -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)\n  -S, --suppress               Suppress the 'Reading standard input' message when not providing a file\n      --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop "^.{1,10}$" will hide all matches not under 10 characters) [default: ""]\n      --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: ""]\n  -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.\n  -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: ""]\n  -t, --time                   Time how long the operation took\n  -e, --email                  Extract email addresses\n  -p, --phone                  Extracts phone numbers\n  -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)\n  -i, --ip-addr                Extract IP addresses\n  -6, --ipv6-addr              Extract IPv6 addresses\n  -m, --mac-addr               Extract MAC addresses\n  -c, --credit-card            Extract credit card numbers\n  -u, --url                    Extract urls\n  -F, --files                  Extract filenames\n  -b, --bitcoin                Extract bitcoin wallets\n  -a, --aws                    Extract AWS keys\n  -g, --google                 Extract Google service account private key ids (used for google automations services)\n  -d, --dns                    Extract Domain Name System records\n  -s, --social                 Extract social security numbers\n  -h, --help                   Print help\n  -V, --version                Print version`);
}

function reFor(id: string): RegExp {
  switch (id) {
    case 'email': return /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
    case 'phone': return /(?:\+?1[-.\s]?)?(?:\([2-9]\d{2}\)|[2-9]\d{2})[-.\s]?\d{3}[-.\s]?\d{4}/g;
    case 'ip_address': return /(?:\b|(?<=\.))(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}\b/g;
    case 'ipv6_address': return /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}\b|::1\b/g;
    case 'mac_address': return /\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b/g;
    case 'url': return /\bhttps?:\/\/[^\s<>'"),]+/g;
    case 'credit_card': return /\b(?:\d{4}[- ]?){3}\d{4}\b/g;
    case 'social_security': return /\b\d{3}-\d{2}-\d{4}\b/g;
    case 'bitcoin_wallet': return /\b(?:bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}\b/g;
    case 'aws': return /\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/g;
    case 'google': return /\b[a-f0-9]{40}\b/g;
    case 'dns': return /\b(?:A|AAAA|CNAME|MX|NS|PTR|SOA|TXT)\s+[A-Za-z0-9._-]+\b/g;
    case 'files': return /(?:^|[\s\\\/])([A-Za-z0-9_.-]+\.(?:txt|pdf|png|jpe?g|gif|docx?|xlsx?|pptx?|csv|json|xml|html?|log|exe|zip|tar|gz|7z|rar|mp3|mp4|avi|mov|py|js|ts|rs|go|c|cpp|h|md))(?![A-Za-z0-9])/g;
    case 'hashes': return /\b(?:[a-fA-F0-9]{32}|[a-fA-F0-9]{40}|[a-fA-F0-9]{56}|[a-fA-F0-9]{64}|[a-fA-F0-9]{96}|[a-fA-F0-9]{128}|\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53})\b/g;
    default: return /$a/g;
  }
}

function matches(id: string, line: string): string[] {
  const re = reFor(id); const out: string[] = []; let m: RegExpExecArray | null;
  while ((m = re.exec(line)) !== null) {
    let v = id === 'files' && m[1] ? m[1] : m[0];
    if (id === 'url') v = v.replace(/[.]+$/,'');
    out.push(v);
    if (m[0].length === 0) re.lastIndex++;
  }
  return out;
}

function format(label: string, data: string, o: Options, lineNo: number, file?: string): string {
  if (o.output) return `${label}, ${data}`;
  if (o.line) {
    if (o.display && file) return `${label}, file: ${file} ${data}, line: ${lineNo}`;
    return `${label}, ${data}, line: ${lineNo}`;
  }
  if (o.display && file) return `${label}, file: ${file} ${data}`;
  if (o.hide) return data;
  return `${label}: ${data}`;
}

function processText(text: string, o: Options, file?: string): string[] {
  const ids = o.detectors.size ? detectorOrder.filter(x => o.detectors.has(x)) : defaultOrder;
  const lines = text.split(/\r?\n/); if (lines.length && lines[lines.length-1] === '') lines.pop();
  let filterRe: RegExp | null = null, dropRe: RegExp | null = null;
  try { if (o.filter) filterRe = new RegExp(o.filter); } catch {}
  try { if (o.drop) dropRe = new RegExp(o.drop); } catch {}
  const out: string[] = [];
  for (let i=0;i<lines.length;i++) {
    const line = lines[i];
    for (const id of ids) {
      const ms = matches(id, line);
      if (!ms.length) continue;
      if (!o.clean) {
        const data = line;
        if (filterRe && !filterRe.test(data)) continue;
        const finalData = dropRe && dropRe.test(data) ? ms[0] : data;
        out.push(format(id, finalData, o, i+1, file));
      } else {
        const chosen = o.thorough ? ms : [ms[0]];
        for (const m of chosen) {
          if (filterRe && !filterRe.test(m)) continue;
          if (dropRe && dropRe.test(m)) continue;
          out.push(format(id, m, o, i+1, file));
        }
      }
    }
  }
  return out;
}

function readInputs(o: Options): {text:string,file?:string}[] {
  if (o.file) {
    if (!fs.existsSync(o.file)) { if (!o.ignore) console.error(`[-] File not found: ${o.file}`); return []; }
    return [{ text: fs.readFileSync(o.file,'utf8'), file: o.file }];
  }
  if (o.directory) {
    if (!fs.existsSync(o.directory)) return [];
    return fs.readdirSync(o.directory).sort().map((n:string)=>path.join(o.directory,n)).filter((p:string)=>{ try { return fs.statSync(p).isFile(); } catch { return false; } }).map((p:string)=>({ text: fs.readFileSync(p,'utf8'), file:p }));
  }
  if (!o.suppress) console.error(`[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)`);
  let buf = '';
  try { buf = fs.readFileSync(0,'utf8'); } catch {}
  return [{ text: buf }];
}

function main() {
  const start = Date.now();
  const o = parse(process.argv.slice(2));
  pluginWarning();
  if (o.help) { printHelp(); return; }
  if (o.version) { console.log('DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8'); return; }
  if (o.list) { pluginWarning(); console.log(`No plugins found. Plugin File: ${pluginPath}`); return; }
  if (o.add) { console.error('[-] Error: Failed to parse plugins.json from the provided URL. Reason: builder error: relative URL without a base'); return; }
  if (o.remove || o.update) { pluginWarning(); return; }
  const rows: string[] = [];
  for (const input of readInputs(o)) rows.push(...processText(input.text, o, input.file));
  if (o.output) {
    fs.writeFileSync(o.output, 'content_type, data\n' + rows.join('\n') + (rows.length ? '\n' : ''));
  } else {
    for (const r of rows) console.log(r);
  }
  if (o.time) console.log(`Time elapsed: ${((Date.now()-start)/1000).toFixed(2)}s`);
}
main();
