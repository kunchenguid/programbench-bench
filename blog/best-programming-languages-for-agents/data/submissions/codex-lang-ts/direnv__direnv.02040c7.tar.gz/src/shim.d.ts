declare const process: any;
declare const Buffer: any;
declare module "fs" { const x: any; export = x; }
declare module "os" { const x: any; export = x; }
declare module "path" { const x: any; export = x; }
declare module "crypto" { const x: any; export = x; }
declare module "child_process" { export const spawnSync: any; }
