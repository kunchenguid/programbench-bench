import * as fs from "fs";
import * as os from "os";
import * as path from "path";
import * as crypto from "crypto";
import { spawnSync } from "child_process";

const VERSION = "2.37.1";

function home(): string { return process.env.HOME || os.homedir(); }
function xdgConfig(): string { return process.env.DIRENV_CONFIG || path.join(process.env.XDG_CONFIG_HOME || path.join(home(), ".config"), "direnv"); }
function xdgData(): string { return path.join(process.env.XDG_DATA_HOME || path.join(home(), ".local", "share"), "direnv"); }
function selfPath(): string { return process.env.DIRENV_SELF || process.argv[1] || "direnv"; }
function err(msg: string, code = 1): void { process.stderr.write(`\x1b[31mdirenv: error ${msg}\x1b[0m\n`); process.exit(code); }
function log(msg: string) { process.stderr.write(`\x1b[0mdirenv: ${msg}\n`); }
function sha(s: any): string { return crypto.createHash("sha256").update(s).digest("hex"); }
function ensureDir(p: string) { fs.mkdirSync(p, { recursive: true }); }

function help(showPrivate = false) {
  const supported = "[fish, gzenv, tcsh, zsh, pwsh, systemd, bash, gha, json, murex, vim, elvish]";
  const priv = showPrivate ? `*apply_dump FILE:
  Accepts a filename containing \`direnv dump\` output and generates a series of bash export statements to apply the given env
*show_dump DUMP:
  Show the data inside of a dump for debugging purposes
*check-required SHELL ENVRC_PATH PATH...:
  Checks if required files have been allowed
` : "";
  process.stdout.write(`direnv v${VERSION}
Usage: direnv COMMAND [...ARGS]

Available commands
------------------
allow [PATH_TO_RC]:
  aliases: permit, grant
  Grants direnv permission to load the given .envrc or .env file.
${priv}block [PATH_TO_RC]:
  aliases: deny, disallow, revoke
  Revokes the authorization of a given .envrc or .env file.
edit [PATH_TO_RC]:
  Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow
  the file to be loaded afterwards.
exec DIR COMMAND [...ARGS]:
  Executes a command after loading the first .envrc or .env found in DIR
export SHELL:
  Loads an .envrc or .env and prints the diff in terms of exports.
  Supported SHELL values are: ${supported}
fetchurl <url> [<integrity-hash>]:
  Fetches a given URL into direnv's CAS
help [SHOW_PRIVATE]:
  Shows this help
hook SHELL:
  Used to setup the shell hook
prune:
  Removes old allowed and required files
reload:
  Triggers an env reload
status [--json]:
  Prints some debug status information
stdlib:
  Displays the stdlib available in the .envrc execution context
version [VERSION_AT_LEAST]:
  prints the version or checks that direnv is older than VERSION_AT_LEAST.
log [--status | --error] <message>:
  Logs a given message
${showPrivate ? `*watch SHELL PATH...:
  Adds a path to the list that direnv watches for changes
*watch-dir SHELL DIR:
  Recursively adds a directory to the list that direnv watches for changes
*watch-list [SHELL]:
  Pipe pairs of \`mtime path\` to stdin to build a list of files to watch.
*watch-print [--null]:
  prints the watched paths
*current PATH:
  Reports whether direnv's view of a file is current (or stale)
* = private commands
` : ""}`);
}

function cmpVer(a: string, b: string): number {
  const aa = a.replace(/^v/, "").split(".").map(Number), bb = b.replace(/^v/, "").split(".").map(Number);
  for (let i = 0; i < Math.max(aa.length, bb.length); i++) {
    const d = (aa[i] || 0) - (bb[i] || 0);
    if (d) return d;
  }
  return 0;
}

function findRc(start = process.cwd()): string | null {
  let dir = path.resolve(start);
  while (true) {
    const envrc = path.join(dir, ".envrc");
    if (fs.existsSync(envrc)) return envrc;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

function resolveRc(arg?: string): string {
  let p = arg || ".";
  p = path.resolve(p);
  if (fs.existsSync(p) && fs.statSync(p).isDirectory()) {
    const envrc = path.join(p, ".envrc");
    const dotenv = path.join(p, ".env");
    if (fs.existsSync(envrc)) return envrc;
    if (fs.existsSync(dotenv)) return dotenv;
    return envrc;
  }
  if (!fs.existsSync(p)) err(`lstat ${p}: no such file or directory`);
  return p;
}

function allowKey(file: string): string {
  const content = fs.existsSync(file) ? fs.readFileSync(file) : Buffer.from("");
  return sha(path.resolve(file) + "\0" + content.toString("binary"));
}
function allowPath(file: string): string { return path.join(xdgData(), "allow", allowKey(file)); }
function isAllowed(file: string): boolean {
  const p = allowPath(file);
  if (!fs.existsSync(p)) return false;
  return fs.readFileSync(p, "utf8").trim() === path.resolve(file);
}
function allow(file: string) {
  const p = allowPath(file);
  ensureDir(path.dirname(p));
  fs.writeFileSync(p, path.resolve(file) + "\n");
}
function deny(file: string) {
  const dir = path.join(xdgData(), "allow");
  if (!fs.existsSync(dir)) return;
  for (const f of fs.readdirSync(dir)) {
    const fp = path.join(dir, f);
    try { if (fs.readFileSync(fp, "utf8").trim() === path.resolve(file)) fs.unlinkSync(fp); } catch {}
  }
}

function bashQuote(s: string): string {
  return "$'" + s.replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t") + "'";
}
function sq(s: string): string { return "'" + s.replace(/'/g, "'\\''") + "'"; }

const STDLIB = [
  "#!/usr/bin/env bash",
  "has() { type \"$1\" >/dev/null 2>&1; }",
  "expand_path() { python3 -c 'import os,sys; p=sys.argv[1]; b=sys.argv[2] if len(sys.argv)>2 else os.getcwd(); print(os.path.abspath(os.path.join(b, os.path.expanduser(p))))' \"$@\"; }",
  "user_rel_path() { case \"$1\" in \"$HOME\"*) printf '~%s\\n' \"${1#$HOME}\" ;; *) printf '%s\\n' \"$1\" ;; esac; }",
  "find_up() { local n=\"$1\" d=\"$PWD\"; while true; do [ -e \"$d/$n\" ] && { echo \"$d/$n\"; return 0; }; [ \"$d\" = / ] && return 1; d=\"$(dirname \"$d\")\"; done; }",
  "path_add() { local var=\"$1\" p; p=\"$(expand_path \"$2\")\"; eval \"export $var=\\\"$p\\${$var:+:\\${$var}}\\\"\"; }",
  "PATH_add() { path_add PATH \"$1\"; }",
  "MANPATH_add() { path_add MANPATH \"$1\"; }",
  "PATH_rm() { local IFS=: out= item pat keep; for item in $PATH; do keep=1; for pat in \"$@\"; do [[ \"$item\" == $pat ]] && keep=0; done; [ \"$keep\" = 1 ] && out=\"${out:+$out:}$item\"; done; export PATH=\"$out\"; }",
  "dotenv() { local f=\"${1:-.env}\"; [ -f \"$f\" ] || return 1; set -a; source \"$f\"; set +a; }",
  "dotenv_if_exists() { local f=\"${1:-.env}\"; [ -f \"$f\" ] && dotenv \"$f\" || true; }",
  "source_env() { source \"$1\"; }",
  "source_env_if_exists() { [ -f \"$1\" ] && source \"$1\" || true; }",
  "source_up() { local f=\"${1:-.envrc}\" p; p=\"$(find_up \"$f\")\" || return 1; source \"$p\"; }",
  "source_up_if_exists() { source_up \"${1:-.envrc}\" || true; }",
  "env_vars_required() { local r=0 v; for v in \"$@\"; do [ -n \"${!v:-}\" ] || { echo \"direnv: required environment variable '$v' is missing\" >&2; r=1; }; done; return \"$r\"; }",
  "layout() { local t=\"$1\"; shift || true; case \"$t\" in node) PATH_add node_modules/.bin;; php) PATH_add vendor/bin;; go) export GOPATH=\"$(direnv_layout_dir)/go\"; PATH_add bin;; python|python3) local py=\"${1:-python}\"; [ \"$t\" = python3 ] && py=\"python3\"; local v=\".direnv/python-$($py -c 'import sys;print(\".\".join(map(str,sys.version_info[:3])))' 2>/dev/null || echo unknown)\"; mkdir -p \"$v/bin\"; export VIRTUAL_ENV=\"$PWD/$v\"; PATH_add \"$v/bin\";; ruby) export GEM_HOME=\"$PWD/.direnv/ruby\"; PATH_add \"$GEM_HOME/bin\";; julia) export JULIA_PROJECT=\"$PWD\";; *) echo \"direnv: layout $t is unknown\" >&2; return 1;; esac; }",
  "use() { local f=\"use_$1\"; shift; \"$f\" \"$@\"; }",
  "direnv_layout_dir() { echo \"${DIRENV_LAYOUT:-$PWD/.direnv}\"; }",
  "watch_file() { :; }",
  "watch_dir() { :; }",
  "strict_env() { if [ \"$#\" -gt 0 ]; then (set -euo pipefail; \"$@\"); else set -euo pipefail; fi; }",
  "unstrict_env() { if [ \"$#\" -gt 0 ]; then (set +e +u +o pipefail; \"$@\"); else set +e +u +o pipefail; fi; }",
  "direnv_version() { \"$direnv\" version \"$1\"; }",
  "log_status() { echo \"direnv: $*\" >&2; }",
  "log_error() { echo \"direnv: $*\" >&2; }",
].join("\n");

function evalRc(file: string): { env: Record<string, string>, status: number, stderr: string } {
  const before = process.env;
  const script = `
set -a
direnv=${sq(selfPath())}
${STDLIB}
[ -f "${xdgConfig().replace(/"/g, '\\"')}/direnvrc" ] && source "${xdgConfig().replace(/"/g, '\\"')}/direnvrc"
source ${sq(file)}
env -0
`;
  const res = spawnSync("/usr/bin/bash", ["-lc", script], { cwd: path.dirname(file), env: before as any, encoding: "buffer" });
  const stdout = res.stdout || Buffer.alloc(0);
  const map: Record<string, string> = {};
  for (const part of stdout.toString("utf8").split("\0")) {
    if (!part) continue;
    const i = part.indexOf("=");
    if (i > 0) map[part.slice(0, i)] = part.slice(i + 1);
  }
  map.DIRENV_FILE = file;
  map.DIRENV_DIR = "-" + path.dirname(file);
  map.DIRENV_DIFF = Buffer.from("{}").toString("base64");
  map.DIRENV_WATCHES = Buffer.from(file).toString("base64");
  return { env: map, status: res.status ?? 0, stderr: (res.stderr || Buffer.alloc(0)).toString("utf8") };
}

function diffEnv(newEnv: Record<string, string>): Record<string, string | null> {
  const out: Record<string, string | null> = {};
  const include = new Set(["DIRENV_FILE", "DIRENV_DIR", "DIRENV_DIFF", "DIRENV_WATCHES"]);
  for (const [k, v] of Object.entries(newEnv)) {
    if (k === "_" || k === "direnv" || k.startsWith("BASH_FUNC_") || k === "DIRENV_IN_ENVRC" || k === "PWD" || k === "SHLVL") continue;
    if (include.has(k) || process.env[k] !== v) out[k] = v;
  }
  for (const k of Object.keys(process.env)) {
    if (!(k in newEnv) && /^[A-Za-z_][A-Za-z0-9_]*$/.test(k)) out[k] = null;
  }
  return out;
}

function formatExport(shell: string, d: Record<string, string | null>): string {
  const entries = Object.entries(d).sort(([a], [b]) => a.localeCompare(b));
  if (shell === "json" || shell === "elvish" || shell === "murex") return JSON.stringify(Object.fromEntries(entries), null, 2);
  if (shell === "fish") return entries.map(([k, v]) => v == null ? `set -e ${sq(k)};` : `set -x -g ${sq(k)} ${sq(v)};`).join("");
  if (shell === "vim") return entries.map(([k, v]) => v == null ? `call unsetenv(${sq(k)})` : `call setenv(${sq(k)},${sq(v)})`).join("\n") + (entries.length ? "\n" : "");
  if (shell === "tcsh") return entries.map(([k, v]) => v == null ? `unsetenv ${k} ;` : `setenv ${k} ${v.replace(/\s/g, "\\ ")} ;`).join("");
  if (shell === "gha") return entries.filter(([,v]) => v != null).map(([k, v]) => `${k}<<ghadelimiter\n${v}\nghadelimiter`).join("\n") + (entries.length ? "\n" : "");
  if (shell === "systemd") return entries.filter(([,v]) => v != null).map(([k, v]) => `${k}=${v}`).join("\n") + (entries.length ? "\n" : "");
  return entries.map(([k, v]) => v == null ? `unset ${k};` : `export ${k}=${bashQuote(v)};`).join("");
}

function doExport(shell: string) {
  if (!["bash","zsh","fish","tcsh","elvish","pwsh","murex","json","vim","gha","gzenv","systemd"].includes(shell)) err(`unknown target shell '${shell}'`);
  const rc = findRc();
  if (!rc) return;
  if (!isAllowed(rc)) {
    process.stdout.write(formatExport(shell, { DIRENV_FILE: rc, DIRENV_DIR: "-" + path.dirname(rc), DIRENV_DIFF: Buffer.from("{}").toString("base64"), DIRENV_WATCHES: Buffer.from(rc).toString("base64") }));
    err(`${rc} is blocked. Run \`direnv allow\` to approve its content`);
  }
  log(`loading ${rc}`);
  const ev = evalRc(rc);
  if (ev.stderr) process.stderr.write(ev.stderr);
  if (ev.status !== 0) process.exit(ev.status);
  const d = diffEnv(ev.env);
  process.stdout.write(formatExport(shell, d));
  const changed = Object.keys(d).filter(k => !k.startsWith("DIRENV_"));
  if (changed.length) log(`export ${changed.map(k => d[k] == null ? "-" + k : "+" + k).join(" ")}`);
}

function hook(shell: string) {
  const p = selfPath();
  if (shell === "bash") return process.stdout.write([
    "",
    "_direnv_hook() {",
    "  local previous_exit_status=$?;",
    `  vars="$("${p}" export bash)";`,
    "  trap -- '' SIGINT;",
    "  eval \"$vars\";",
    "  trap - SIGINT;",
    "  return $previous_exit_status;",
    "};",
    "if [[ \";${PROMPT_COMMAND[*]:-};\" != *\";_direnv_hook;\"* ]]; then",
    "  if [[ \"$(declare -p PROMPT_COMMAND 2>&1)\" == \"declare -a\"* ]]; then",
    "    PROMPT_COMMAND=(_direnv_hook \"${PROMPT_COMMAND[@]}\")",
    "  else",
    "    PROMPT_COMMAND=\"_direnv_hook${PROMPT_COMMAND:+;$PROMPT_COMMAND}\"",
    "  fi",
    "fi",
    "",
  ].join("\n"));
  if (shell === "zsh") return process.stdout.write([
    "",
    "_direnv_hook() {",
    `  vars="$("${p}" export zsh)"`,
    "  trap -- '' SIGINT",
    "  eval \"$vars\"",
    "  trap - SIGINT",
    "}",
    "typeset -ag precmd_functions",
    "if (( ! ${precmd_functions[(I)_direnv_hook]} )); then",
    "  precmd_functions=(_direnv_hook $precmd_functions)",
    "fi",
    "typeset -ag chpwd_functions",
    "if (( ! ${chpwd_functions[(I)_direnv_hook]} )); then",
    "  chpwd_functions=(_direnv_hook $chpwd_functions)",
    "fi",
    "",
  ].join("\n"));
  if (shell === "fish") return process.stdout.write(`function __direnv_export_eval --on-event fish_prompt; "${p}" export fish | source; end;\n`);
  if (shell === "tcsh") return process.stdout.write("alias precmd 'eval `" + p + " export tcsh`'");
  if (shell === "pwsh") return process.stdout.write("$ExecutionContext.SessionState.InvokeCommand.LocationChangedAction = { Invoke-Expression \"$(" + p + " export pwsh)\" };\n");
  if (shell === "elvish") return process.stdout.write(`## hook for direnv\n`);
  if (shell === "murex") return process.stdout.write(`event: onPrompt direnv_hook=before {\n\t"${p}" export murex -> set exports\n}`);
  if (shell === "gha") err("Hook not implemented for GitHub Actions shell");
  if (shell === "gzenv") err("the gzenv shell doesn't support hooking");
  if (shell === "vim") err("this feature is not supported. Install the direnv.vim plugin instead");
  err("this feature is not supported");
}

function status(json = false) {
  const rc = findRc();
  if (json) {
    process.stdout.write(JSON.stringify({ config: { ConfigDir: xdgConfig(), SelfPath: selfPath() }, state: { foundRC: rc ? { path: rc, allowed: isAllowed(rc) } : null, loadedRC: process.env.DIRENV_FILE || null } }, null, 2) + "\n");
    return;
  }
  process.stdout.write(`direnv exec path ${selfPath()}
DIRENV_CONFIG ${xdgConfig()}
bash_path /usr/bin/bash
disable_stdin false
warn_timeout 5s
whitelist.prefix []
whitelist.exact map[]
${process.env.DIRENV_FILE ? `Found RC path ${process.env.DIRENV_FILE}` : "No .envrc or .env loaded"}
${rc ? `Found RC path ${rc}` : "No .envrc or .env found"}
`);
}

function main() {
  let [cmd, ...args] = process.argv.slice(2);
  if (cmd === "--help" || cmd === "-h") cmd = "help";
  switch (cmd || "help") {
    case "help": return help(args[0] === "true");
    case "version":
      if (!args[0]) return process.stdout.write(`${VERSION}\n`);
      if (!/^[v]?\d+\.\d+\.\d+/.test(args[0])) err(`v${args[0]} is not a valid semver version`);
      if (cmpVer(VERSION, args[0]) < 0) err(`current version v${VERSION} is older than the desired version v${args[0]}`);
      return;
    case "status": return status(args[0] === "--json");
    case "hook": return args[0] ? hook(args[0]) : err("missing target shell");
    case "export": return args[0] ? doExport(args[0]) : err("missing target shell");
    case "allow": case "permit": case "grant": return allow(resolveRc(args[0]));
    case "deny": case "disallow": case "revoke": case "block": return deny(resolveRc(args[0]));
    case "stdlib": return process.stdout.write(STDLIB + "\n");
    case "reload": { const rc = findRc(); if (!rc) err(".envrc not found"); return; }
    case "prune": { const d = path.join(xdgData(), "allow"); if (!fs.existsSync(d)) err(`open ${d}: no such file or directory`); return; }
    case "log": {
      if (args.length < 1) err("invalid arguments");
      const msg = args[0] === "--status" || args[0] === "--error" ? args.slice(1).join(" ") : args.join(" ");
      if (!msg) err("invalid arguments");
      return log(msg);
    }
    case "exec": {
      if (args.length < 2) err("invalid arguments");
      const dir = args[0], command = args.slice(1);
      const rc = findRc(dir);
      let env = { ...process.env };
      if (rc && isAllowed(rc)) env = { ...env, ...evalRc(rc).env };
      const r = spawnSync(command[0], command.slice(1), { cwd: dir, env, stdio: "inherit" });
      process.exit(r.status ?? 0);
    }
    case "edit": {
      const ed = process.env.EDITOR || process.env.VISUAL;
      if (!ed) err("$EDITOR not found.\ndirenv: error could not find a default editor in the PATH");
      const rc = resolveRc(args[0]);
      const r = spawnSync(ed, [rc], { stdio: "inherit" });
      if ((r.status ?? 0) === 0) allow(rc);
      process.exit(r.status ?? 0);
    }
    case "fetchurl": return err(`Get "${args[0] || ""}": unsupported protocol scheme ""`);
    default: return err(`command "${[selfPath(), cmd].join(" ")}" not found`);
  }
}

main();
