declare const process: any;

declare module "fs" {
  export function existsSync(path: string): boolean;
  export function readFileSync(path: string, encoding: string): string;
  export function writeFileSync(path: string, data: string): void;
  export function mkdirSync(path: string, options?: any): void;
}

declare module "path" {
  export function dirname(path: string): string;
  export function resolve(...paths: string[]): string;
  export function basename(path: string, suffix?: string): string;
  export function join(...paths: string[]): string;
}
