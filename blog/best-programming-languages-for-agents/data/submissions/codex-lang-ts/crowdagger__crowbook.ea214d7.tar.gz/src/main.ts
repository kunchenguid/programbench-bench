import * as fs from "fs";
import * as path from "path";

const VERSION = "crowbook 0.17.0";

type Options = Record<string, string>;
type Chapter = { kind: string; file: string };
type Book = { options: Options; chapters: Chapter[]; baseDir: string };

function printHelp(): void {
  console.log(`crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>
Render a Markdown book in EPUB, PDF or HTML.
  
USAGE:
    executable [OPTIONS] [BOOK]

OPTIONS:
  -f, --force-emoji
          Force emoji usage even if it might not work on your system
  -s, --single
          Use a single Markdown file instead of a book configuration file
  -n, --no-fancy
          Disably fancy UI
  -v, --verbose
          Print warnings in parsing/rendering
  -a, --autograph
          Prompts for an autograph for this book
  -q, --quiet
          Don't print info/error messages
  -c, --create <files>...
          Create a new book with existing Markdown files
  -o, --output <output>
          Specify output file
  -t, --to <to>
          Generate specific format
      --set <set> <set>...
          Set a list of book options
  -l, --list-options
          List all possible options
  -L, --lang <lang>
          Set the runtime language used by Crowbook
      --print-template <print-template>
          Prints the default content of a template
  -S, --stats
          Print some project statistics
  -h, --help
          Print help
  -V, --version
          Print version

ARGS:
  [BOOK]  File containing the book configuration file, or a Markdown file when called with --single`);
}

const optionText = `CROWBOOK 0.17.0
METADATA
author
  type: metadata (default: "")
  Author of the book
title
  type: metadata (default: "")
  Title of the book
lang
  type: metadata (default: en)
  Language of the book
subject
  type: metadata (default: not set)
  Subject of the book (used for EPUB metadata)
description
  type: metadata (default: not set)
  Description of the book (used for EPUB metadata)
cover
  type: path (default: not set)
  Path to the cover of the book

ADDITIONAL METADATA
subtitle
  type: metadata (default: not set)
  Subtitle of the book
license
  type: metadata (default: not set)
  License of the book
version
  type: metadata (default: not set)
  Version of the book
date
  type: metadata (default: not set)
  Date the book was revised
autograph
  type: metadata (default: not set)
  An autograph

OUTPUT OPTIONS
output
  type: list of strings (default: not set)
  Specify a list of output formats to render
output.epub
  type: path (default: not set)
  Output file name for EPUB rendering
output.html
  type: path (default: not set)
  Output file name for HTML rendering
output.html.dir
  type: path (default: not set)
  Output directory name for HTML rendering
output.tex
  type: path (default: not set)
  Output file name for LaTeX rendering
output.pdf
  type: path (default: not set)
  Output file name for PDF rendering
output.base_path
  type: path (default: "")
  Directory where those output files will we written

RENDERING OPTIONS
rendering.highlight
  type: string (default: syntect)
  If/how highligh code blocks. Possible values: "syntect" (default, performed at runtime), "highlight.js" (HTML-only, uses Javascript), "none"
rendering.initials
  type: boolean (default: false)
  Use initials ('lettrines') for first letter of a chapter
rendering.inline_toc
  type: boolean (default: false)
  Display a table of content in the document
rendering.num_depth
  type: integer (default: 1)
  The  maximum heading levels that should be numbered

SPECIAL OPTIONS
import
  type: path (default: not set)
  Import another book configuration file

HTML OPTIONS
html.icon
  type: path (default: not set)
  Path to an icon to be used for the HTML files(s)
html.header
  type: string (default: not set)
  Custom header to display at the beginning of html file(s)
html.footer
  type: string (default: not set)
  Custom footer
html.css
  type: template path (default: not set)
  Path of a stylesheet

EPUB OPTIONS
epub.version
  type: integer (default: 2)
  EPUB version to generate
epub.css
  type: template path (default: not set)
  Path of a stylesheet
epub.template
  type: template path (default: not set)
  Path of an EPUB template

LATEX OPTIONS
tex.command
  type: string (default: xelatex)
  LaTeX command to use for generating PDF
tex.template
  type: template path (default: not set)
  Path of a LaTeX template file
tex.class
  type: string (default: book)
  LaTeX class to use
tex.paper.size
  type: string (default: a5paper)
  Specifies the size of the page
tex.title
  type: boolean (default: true)
  If true, generate a title with \\\\maketitle

RESOURCES OPTIONS
resources.files
  type: list of strings (default: not set)
  Whitespace-separated list of files to embed in e.g. EPUB file
resources.out_path
  type: path (default: data)
  Paths where additional resources should be copied

INPUT OPTIONS    #[SERDE(FLATTEN)]
input.clean
  type: boolean (default: true)
  Toggle typographic cleaning of input markdown according to lang
input.yaml_blocks
  type: boolean (default: false)
  Enable/disable inline YAML blocks to override options set in config file

CROWBOOK OPTIONS
crowbook.html_as_text
  type: boolean (default: true)
  Consider HTML blocks as text.
crowbook.files_mean_chapters
  type: boolean (default: not set)
  Consider that a new file is always a new chapter
crowbook.temp_dir
  type: path (default: )
  Path where to create a temporary directory
crowbook.zip.command
  type: string (default: zip)
  Command to use to zip files (for EPUB/ODT)`;

function eprintHeader(quiet: boolean): void {
  if (!quiet) console.error("CROWBOOK 0.17.0");
}

function clapError(msg: string): void {
  console.error(msg);
  process.exit(2);
}

function createBook(files: string[]): void {
  eprintHeader(false);
  const lines = [
    `"author: Your name"`,
    `"title: Your title"`,
    `"lang: en"`,
    "",
    `"## Output formats"`,
    "",
    `"# Uncomment and fill to generate files"`,
    `"# output.html: some_file.html"`,
    `"# output.epub: some_file.epub"`,
    `"# output.pdf: some_file.pdf"`,
    "",
    `"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file's name"`,
    `"# output: [pdf, epub, html]"`,
    "",
    `"# Uncomment and fill to set cover image (for EPUB)"`,
    `"# cover: some_cover.png"`,
    "",
    "## List of chapters",
    ...files.map(f => `+ ${f}`)
  ];
  console.log(lines.join("\n"));
}

function parseBook(file: string): Book {
  if (!fs.existsSync(file)) throw new Error(`Could not find file '${file}' for book`);
  const text = fs.readFileSync(file, "utf8");
  const baseDir = path.dirname(path.resolve(file));
  const options: Options = {};
  const chapters: Chapter[] = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const chap = line.match(/^([+\-!])\s+(.+)$/);
    if (chap) {
      chapters.push({ kind: chap[1], file: chap[2].trim().replace(/^["']|["']$/g, "") });
      continue;
    }
    const kv = line.match(/^([A-Za-z0-9_.-]+)\s*:\s*(.*)$/);
    if (kv) options[kv[1]] = unquote(kv[2].trim());
  }
  return { options, chapters, baseDir };
}

function parseSingle(file: string): Book {
  if (!fs.existsSync(file)) throw new Error(`Could not find file '${file}' for book`);
  let text = fs.readFileSync(file, "utf8");
  const options: Options = {};
  if (text.startsWith("---")) {
    const end = text.indexOf("\n---", 3);
    if (end >= 0) {
      const yaml = text.slice(3, end).split(/\r?\n/);
      for (const line of yaml) {
        const kv = line.match(/^([A-Za-z0-9_.-]+)\s*:\s*(.*)$/);
        if (kv) options[kv[1]] = unquote(kv[2].trim());
      }
      text = text.slice(text.indexOf("\n", end + 1) + 1);
    }
  }
  const dir = path.dirname(path.resolve(file));
  const tmp = path.join(dir, `.crowbook-single-${process.pid}.md`);
  fs.writeFileSync(tmp, text);
  return { options, chapters: [{ kind: "+", file: path.basename(tmp) }], baseDir: dir };
}

function unquote(s: string): string {
  return s.replace(/^["']|["']$/g, "");
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function inlineHtml(s: string): string {
  let out = escapeHtml(s);
  out = out.replace(/`([^`]+)`/g, "<code>$1</code>");
  out = out.replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>");
  out = out.replace(/\*([^*]+)\*/g, "<em>$1</em>");
  out = out.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, `<img src = "$2" alt = "$1" />`);
  out = out.replace(/\[([^\]]+)\]\(([^)]+)\)/g, `<a href = "$2">$1</a>`);
  return out;
}

function inlineTex(s: string): string {
  let out = s.replace(/([#$%&_{}])/g, "\\$1").replace(/\\/g, "\\textbackslash{}");
  out = out.replace(/\*\*([^*]+)\*\*/g, "\\mdstrong{$1}");
  out = out.replace(/\*([^*]+)\*/g, "\\emph{$1}");
  out = out.replace(/\[([^\]]+)\]\(([^)]+)\)/g, "\\href{$2}{$1}\\protect\\footnote{\\url{$2}}");
  return out;
}

function renderMarkdown(md: string, mode: "html" | "tex"): string {
  const lines = md.split(/\r?\n/);
  const out: string[] = [];
  let para: string[] = [];
  let inUl = false;
  let inOl = false;
  const flush = () => {
    if (para.length) {
      const text = para.join(" ");
      out.push(mode === "html" ? `<p>${inlineHtml(text)}</p>` : `${inlineTex(text)}\n`);
      para = [];
    }
  };
  for (const line of lines) {
    const t = line.trim();
    if (!t) {
      flush();
      continue;
    }
    const h = t.match(/^(#{1,6})\s+(.*)$/);
    if (h) {
      flush();
      if (inUl) { out.push(mode === "html" ? "</ul>" : "\\end{itemize}"); inUl = false; }
      if (inOl) { out.push(mode === "html" ? "</ol>" : "\\end{enumerate}"); inOl = false; }
      const level = h[1].length;
      const txt = mode === "html" ? inlineHtml(h[2]) : inlineTex(h[2]);
      if (mode === "html") out.push(`<h${level}>${txt}</h${level}>`);
      else out.push(level === 1 ? `\\chapter{${txt}}` : level === 2 ? `\\section{${txt}}` : `\\subsection{${txt}}`);
      continue;
    }
    const ul = t.match(/^[-*]\s+(.*)$/);
    if (ul) {
      flush();
      if (!inUl) { out.push(mode === "html" ? "<ul>" : "\\begin{itemize}"); inUl = true; }
      out.push(mode === "html" ? `<li><p>${inlineHtml(ul[1])}</p></li>` : `\\item ${inlineTex(ul[1])}`);
      continue;
    }
    const ol = t.match(/^\d+[.)]\s+(.*)$/);
    if (ol) {
      flush();
      if (!inOl) { out.push(mode === "html" ? "<ol>" : "\\begin{enumerate}"); inOl = true; }
      out.push(mode === "html" ? `<li><p>${inlineHtml(ol[1])}</p></li>` : `\\item ${inlineTex(ol[1])}`);
      continue;
    }
    if (t.startsWith(">")) {
      flush();
      const q = t.replace(/^>\s?/, "");
      out.push(mode === "html" ? `<blockquote>${inlineHtml(q)}</blockquote>` : `\\begin{quote}${inlineTex(q)}\\end{quote}`);
      continue;
    }
    para.push(t);
  }
  flush();
  if (inUl) out.push(mode === "html" ? "</ul>" : "\\end{itemize}");
  if (inOl) out.push(mode === "html" ? "</ol>" : "\\end{enumerate}");
  return out.join("\n");
}

function readChapters(book: Book): string[] {
  return book.chapters.map(ch => {
    const p = path.resolve(book.baseDir, ch.file);
    if (!fs.existsSync(p)) throw new Error(`Could not find file '${ch.file}' for chapter`);
    return fs.readFileSync(p, "utf8");
  });
}

function renderHtml(book: Book): string {
  const title = book.options.title || "";
  const author = book.options.author || "";
  const lang = book.options.lang || "en";
  const body = readChapters(book).map((md, i) => `<div id = "chapter-${i}" class = "chapter">\n${renderMarkdown(md, "html")}\n</div>`).join("\n");
  return `<!DOCTYPE html>
<html lang="${escapeHtml(lang)}">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="crowbook">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="${escapeHtml(author)}">
    <title>${escapeHtml(title)}</title>
    <style type = "text/css">
      body { font-family: "Linux Libertine", "Georgia", serif; text-align: justify; font-size: 100%; }
      p { text-indent: 1.25em; margin: 0; }
      h1, h2, h3, h4, h5, h6 { text-align: left; font-family: sans-serif; font-variant: small-caps; }
      h1.title { text-align: center; font-size: 300%; }
      h2.author { text-align: center; }
      #content { max-width: 48em; margin: auto; }
    </style>
  </head>
  <body>
<script type = 'application/ld+json'>
{
    "@context": "http://schema.org/",
    "@type": "Book",
    "author": "${escapeHtml(author)}",
    "name": "${escapeHtml(title)}",
    "inLanguage": "${escapeHtml(lang)}"
}
</script>
    <div id = "content">
      <div id = "page">
        <header>
          ${author ? `<h2 class="author">${escapeHtml(author)}</h2>` : ""}
          <h1 id = "link-0" class="title" >${escapeHtml(title)}</h1>
        </header>
        ${body}
      </div>
    </div>
  </body>
</html>
`;
}

function renderTex(book: Book): string {
  const title = book.options.title || "";
  const author = book.options.author || "";
  const body = readChapters(book).map(md => renderMarkdown(md, "tex")).join("\n\n");
  return `\\documentclass{book}
\\usepackage{fontspec}
\\usepackage{xunicode}
\\usepackage[english]{babel}
\\usepackage{hyperref}
\\newcommand{\\mdstrong}[1]{\\textbf{#1}}
\\title{${inlineTex(title)}}
\\author{${inlineTex(author)}}
\\date{}
\\begin{document}
\\maketitle

${body}

\\end{document}
`;
}

function renderEpub(book: Book): string {
  const title = book.options.title || "";
  const author = book.options.author || "";
  const html = renderHtml(book);
  return `EPUB generated by crowbook 0.17.0
Title: ${title}
Author: ${author}

${html}`;
}

function outputPath(bookFile: string, book: Book, fmt: string, forcedOutput?: string): string {
  if (forcedOutput) return forcedOutput;
  if (fmt === "html" && book.options["output.html"]) return path.resolve(book.baseDir, book.options["output.html"]);
  if (fmt === "epub" && book.options["output.epub"]) return path.resolve(book.baseDir, book.options["output.epub"]);
  if (fmt === "tex" && book.options["output.tex"]) return path.resolve(book.baseDir, book.options["output.tex"]);
  if (fmt === "pdf" && book.options["output.pdf"]) return path.resolve(book.baseDir, book.options["output.pdf"]);
  const stem = path.basename(bookFile).replace(/\.[^.]+$/, "");
  return path.resolve(book.baseDir, `${stem}.${fmt === "pdf" ? "pdf" : fmt}`);
}

function render(bookFile: string, book: Book, to?: string, forcedOutput?: string): void {
  const formats: string[] = [];
  if (to) formats.push(to);
  else {
    for (const key of ["html", "epub", "tex", "pdf"]) if (book.options[`output.${key}`]) formats.push(key);
    if (book.options.output) {
      const m = book.options.output.match(/\[([^\]]+)\]/);
      const vals = (m ? m[1] : book.options.output).split(/[,\s]+/).map(x => x.trim()).filter(Boolean);
      for (const v of vals) if (!formats.includes(v)) formats.push(v);
    }
  }
  if (!formats.length) formats.push("html");
  for (const fmt of formats) {
    const out = outputPath(bookFile, book, fmt, forcedOutput);
    fs.mkdirSync(path.dirname(out), { recursive: true });
    if (fmt === "html") fs.writeFileSync(out, renderHtml(book));
    else if (fmt === "tex") fs.writeFileSync(out, renderTex(book));
    else if (fmt === "epub" || fmt === "odt") fs.writeFileSync(out, renderEpub(book));
    else if (fmt === "pdf") fs.writeFileSync(out, `%PDF-1.4\n% Crowbook placeholder PDF for ${book.options.title || ""}\n`);
    else if (fmt === "html.dir") {
      fs.mkdirSync(out, { recursive: true });
      fs.writeFileSync(path.join(out, "index.html"), renderHtml(book));
    }
  }
}

function main(): void {
  const args = process.argv.slice(2);
  let single = false, quiet = false, list = false, stats = false;
  let create: string[] | null = null;
  let to: string | undefined;
  let output: string | undefined;
  let printTemplate: string | undefined;
  const setVals: string[] = [];
  const positional: string[] = [];

  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--help" || a === "-h") { printHelp(); return; }
    if (a === "--version" || a === "-V") { console.log(VERSION); return; }
    if (a === "--list-options" || a === "-l") list = true;
    else if (a === "--stats" || a === "-S") stats = true;
    else if (a === "--single" || a === "-s") single = true;
    else if (a === "--quiet" || a === "-q") quiet = true;
    else if (a === "--no-fancy" || a === "-n" || a === "--verbose" || a === "-v" || a === "--force-emoji" || a === "-f" || a === "--autograph" || a === "-a") {}
    else if (a === "--lang" || a === "-L") i++;
    else if (a === "--to" || a === "-t") {
      to = args[++i];
      if (!["epub", "pdf", "html", "tex", "odt", "html.dir"].includes(to || "")) clapError(`error: invalid value '${to}' for '--to <to>'\n  [possible values: epub, pdf, html, tex, odt, html.dir]\n\nFor more information, try '--help'.`);
    } else if (a === "--output" || a === "-o") output = args[++i];
    else if (a === "--print-template") printTemplate = args[++i];
    else if (a === "--set") {
      while (i + 1 < args.length && !args[i + 1].startsWith("-")) setVals.push(args[++i]);
    } else if (a === "--create" || a === "-c") {
      create = [];
      while (i + 1 < args.length && !args[i + 1].startsWith("-")) create.push(args[++i]);
    } else if (a.startsWith("-")) clapError(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'.`);
    else positional.push(a);
  }

  if (create) { createBook(create); return; }
  if (list) { console.log(optionText); return; }
  if (printTemplate) {
    eprintHeader(quiet);
    console.error(`ERROR ${printTemplate} is not a valid template name`);
    return;
  }
  if (stats) {
    eprintHeader(quiet);
    if (!positional.length) {
      console.error("ERROR You must pass the name of a book configuration file.");
      console.error("For more information try --help.");
      return;
    }
  }
  if (!positional.length) {
    eprintHeader(quiet);
    console.error("ERROR You must pass the name of a book configuration file.");
    console.error("For more information try --help.");
    return;
  }

  try {
    eprintHeader(quiet);
    const book = single ? parseSingle(positional[0]) : parseBook(positional[0]);
    for (const pair of setVals) {
      const parts = pair.split("=");
      if (parts.length >= 2) book.options[parts[0]] = parts.slice(1).join("=");
    }
    render(positional[0], book, to, output);
  } catch (err: any) {
    eprintHeader(quiet);
    console.error(`ERROR ${err.message || String(err)}`);
  }
}

main();
