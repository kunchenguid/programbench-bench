// @ts-nocheck
import * as fs from "fs";
import * as path from "path";
import { spawnSync } from "child_process";

const VERSION = "3.0.0-20260303205914-9926ea38658f";

type Opts = {
  applyGenerated: boolean;
  companyPrefixes: string[];
  excludes: string[];
  format: boolean;
  importsOrder: string[];
  listDiff: boolean;
  output: string;
  projectName: string;
  recursive: boolean;
  rmUnused: boolean;
  separateNamed: boolean;
  setAlias: boolean;
  setExitStatus: boolean;
  useCache: boolean;
  filePath: string;
  local: string;
};

type ImportItem = {
  alias: string;
  quote: string;
  p: string;
  suffix: string;
  lead: string[];
};

const HELP = `Usage of ./executable:
  -apply-to-generated-files
\tApply imports sorting and formatting(if the option is set) to generated files. Generated file is a file with first comment which starts with comment '// Code generated'. Optional parameter.
  -company-prefixes string
\tCompany package prefixes which will be placed after 3rd-party group by default(if defined). Values should be comma-separated. Optional parameters.
  -excludes string
\tExclude files or dirs, example: '.git/,proto/*.go'.
  -file-path string
\tDeprecated. Put file name as an argument(last item) of command line.
  -format
\tOption will perform additional formatting. Optional parameter.
  -imports-order string
\tYour imports groups can be sorted in your way. 
\tstd - std import group; 
\tgeneral - libs for general purpose; 
\tcompany - inter-org or your company libs(if you set '-company-prefixes'-option, then 4th group will be split separately. In other case, it will be the part of general purpose libs); 
\tproject - your local project dependencies;
\tblanked - imports with "_" alias;
\tdotted - imports with "." alias.
\tOptional parameter. (default "std,general,company,project")
  -list-diff
\tOption will list files whose formatting differs from goimports-reviser. Optional parameter.
  -local string
\tDeprecated
  -output string
\tCan be "file", "write" or "stdout". Whether to write the formatted content back to the file or to stdout. When "write" together with "-list-diff" will list the file name and write back to the file. Optional parameter. (default "file")
  -project-name string
\tYour project name(ex.: github.com/incu6us/goimports-reviser). Optional parameter.
  -recursive
\tApply rules recursively if target is a directory. In case of ./... execution will be recursively applied by default. Optional parameter.
  -rm-unused
\tRemove unused imports. Optional parameter.
  -separate-named
\tOption will separate named imports from the rest of the imports, per group. Optional parameter.
  -set-alias
\tSet alias for versioned package names, like 'github.com/go-pg/pg/v9'. In this case import will be set as 'pg "github.com/go-pg/pg/v9"'. Optional parameter.
  -set-exit-status
\tset the exit status to 1 if a change is needed/made. Optional parameter.
  -use-cache
\tUse cache to improve performance. Optional parameter.
  -version
\tShow version information
  -version-only
\tShow only the version string`;

function usage(exit = 0): never {
  console.log(HELP);
  process.exit(exit);
}

function parseArgs(argv: string[]): { opts: Opts; targets: string[] } {
  const opts: Opts = {
    applyGenerated: false,
    companyPrefixes: [],
    excludes: [],
    format: false,
    importsOrder: ["std", "general", "company", "project"],
    listDiff: false,
    output: "file",
    projectName: "",
    recursive: false,
    rmUnused: false,
    separateNamed: false,
    setAlias: false,
    setExitStatus: false,
    useCache: false,
    filePath: "",
    local: "",
  };
  const targets: string[] = [];
  const bools: Record<string, keyof Opts | "version" | "version-only" | "help"> = {
    "apply-to-generated-files": "applyGenerated",
    format: "format",
    "list-diff": "listDiff",
    recursive: "recursive",
    "rm-unused": "rmUnused",
    "separate-named": "separateNamed",
    "set-alias": "setAlias",
    "set-exit-status": "setExitStatus",
    "use-cache": "useCache",
    version: "version",
    "version-only": "version-only",
    help: "help",
    h: "help",
  };
  const vals: Record<string, keyof Opts> = {
    "company-prefixes": "companyPrefixes",
    excludes: "excludes",
    "file-path": "filePath",
    "imports-order": "importsOrder",
    local: "local",
    output: "output",
    "project-name": "projectName",
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith("-") || a === "-") {
      targets.push(a);
      continue;
    }
    const raw = a.replace(/^-+/, "");
    const eq = raw.indexOf("=");
    const name = eq >= 0 ? raw.slice(0, eq) : raw;
    const attached = eq >= 0 ? raw.slice(eq + 1) : undefined;
    if (bools[name]) {
      const key = bools[name];
      if (key === "help") usage(0);
      if (key === "version") {
        console.log(`version: ${VERSION}`);
        console.log("built with: go1.26.0");
        console.log(`tag: v${VERSION}`);
        console.log("commit: n/a");
        console.log("source: github.com/incu6us/goimports-reviser/v3");
        process.exit(0);
      }
      if (key === "version-only") {
        console.log(VERSION);
        process.exit(0);
      }
      opts[key] = true;
      continue;
    }
    if (vals[name]) {
      const v = attached !== undefined ? attached : argv[++i] ?? "";
      const key = vals[name];
      if (key === "companyPrefixes" || key === "excludes" || key === "importsOrder") {
        opts[key] = v.split(",").map((s) => s.trim()).filter(Boolean);
      } else {
        opts[key] = v;
      }
      continue;
    }
    console.error(`flag provided but not defined: -${name}`);
    usage(2);
  }
  if (!targets.length && opts.filePath) targets.push(opts.filePath);
  if (opts.importsOrder.length < 4) {
    usage(1);
  }
  return { opts, targets };
}

function log(msg: string) {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  console.error(`${d.getUTCFullYear()}/${pad(d.getUTCMonth() + 1)}/${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())} ${msg}`);
}

function findProjectName(start: string): string {
  let dir = fs.existsSync(start) && fs.statSync(start).isDirectory() ? start : path.dirname(start);
  dir = path.resolve(dir);
  while (true) {
    const gomod = path.join(dir, "go.mod");
    if (fs.existsSync(gomod)) {
      const m = fs.readFileSync(gomod, "utf8").match(/^\s*module\s+(\S+)/m);
      if (m) return m[1];
    }
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return "";
}

function shouldExclude(file: string, excludes: string[]): boolean {
  const rel = path.relative(process.cwd(), file).replace(/\\/g, "/");
  return excludes.some((ex) => {
    ex = ex.replace(/\\/g, "/");
    if (!ex) return false;
    if (ex.endsWith("/")) return rel.startsWith(ex) || rel.includes("/" + ex);
    if (ex.includes("*")) {
      const re = new RegExp("^" + ex.split("*").map(escapeRe).join(".*") + "$");
      return re.test(rel);
    }
    return rel === ex || rel.startsWith(ex + "/") || file.endsWith(ex);
  });
}

function escapeRe(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function walk(dir: string, out: string[], excludes: string[]) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (ent.name === ".git" || ent.name === "node_modules" || ent.name === "dist") continue;
    const p = path.join(dir, ent.name);
    if (shouldExclude(p, excludes)) continue;
    if (ent.isDirectory()) walk(p, out, excludes);
    else if (ent.isFile() && ent.name.endsWith(".go")) out.push(p);
  }
}

function collectTargets(targets: string[], opts: Opts): string[] {
  const files: string[] = [];
  for (const t0 of targets.length ? targets : ["."]) {
    const recurseDots = t0.endsWith("/...");
    const t = recurseDots ? t0.slice(0, -4) || "." : t0;
    const p = path.resolve(t);
    if (!fs.existsSync(p)) continue;
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      if (opts.recursive || recurseDots) walk(p, files, opts.excludes);
      else {
        for (const ent of fs.readdirSync(p, { withFileTypes: true })) {
          const fp = path.join(p, ent.name);
          if (ent.isFile() && ent.name.endsWith(".go") && !shouldExclude(fp, opts.excludes)) files.push(fp);
        }
      }
    } else if (st.isFile() && p.endsWith(".go") && !shouldExclude(p, opts.excludes)) {
      files.push(p);
    }
  }
  return Array.from(new Set(files));
}

function isGenerated(src: string): boolean {
  const m = src.match(/^\s*(?:\/\/.*\n|\/\*[\s\S]*?\*\/\s*)*/);
  const head = m ? m[0] : "";
  return head.split(/\r?\n/).some((l) => l.trim().startsWith("// Code generated"));
}

function parseImportLine(line: string, pending: string[]): ImportItem | null {
  const trimmed = line.trim();
  const m = trimmed.match(/^(?:(\S+)\s+)?("([^"]+)")(.*)$/);
  if (!m) return null;
  return { alias: m[1] || "", quote: m[2], p: m[3], suffix: (m[4] || "").trimEnd(), lead: pending.splice(0) };
}

function parseImports(body: string): ImportItem[] {
  const imports: ImportItem[] = [];
  const pending: string[] = [];
  for (const line of body.split(/\r?\n/)) {
    const tr = line.trim();
    if (!tr) {
      pending.length = 0;
      continue;
    }
    if (tr.startsWith("//") || tr.startsWith("/*")) {
      pending.push(tr);
      continue;
    }
    const item = parseImportLine(line, pending);
    if (item) imports.push(item);
    pending.length = 0;
  }
  return imports;
}

function findImportDecl(src: string): { start: number; end: number; imports: ImportItem[] } | null {
  const block = /(^|\n)import\s*\(([\s\S]*?)\n\)/m.exec(src);
  if (block && block.index !== undefined) {
    const start = block.index + block[1].length;
    return { start, end: block.index + block[0].length, imports: parseImports(block[2]) };
  }
  const single = /(^|\n)import\s+((?:(?:\S+)\s+)?"[^"]+".*)/m.exec(src);
  if (single) {
    const start = single.index + single[1].length;
    const lineEnd = src.indexOf("\n", start);
    const end = lineEnd >= 0 ? lineEnd : src.length;
    const pending: string[] = [];
    const item = parseImportLine(single[2], pending);
    return item ? { start, end, imports: [item] } : null;
  }
  return null;
}

function defaultName(item: ImportItem): string {
  if (item.alias && item.alias !== "." && item.alias !== "_") return item.alias;
  const parts = item.p.split("/");
  let b = parts[parts.length - 1] || "";
  if (/^v\d+$/.test(b) && parts.length > 1) b = parts[parts.length - 2];
  return b.replace(/[^A-Za-z0-9_]/g, "_");
}

function removeUnused(items: ImportItem[], srcWithoutImports: string): ImportItem[] {
  const text = srcWithoutImports.replace(/"([^"\\]|\\.)*"/g, "").replace(/`[\s\S]*?`/g, "");
  return items.filter((it) => {
    if (it.alias === "_" || it.alias === ".") return true;
    const name = defaultName(it);
    return new RegExp(`\\b${escapeRe(name)}\\b`).test(text);
  });
}

function isStd(p: string): boolean {
  const first = p.split("/")[0];
  return !first.includes(".");
}

function groupOf(it: ImportItem, opts: Opts, projectName: string): string {
  if (it.alias === "_" && opts.importsOrder.includes("blanked")) return "blanked";
  if (it.alias === "." && opts.importsOrder.includes("dotted")) return "dotted";
  if (projectName && (it.p === projectName || it.p.startsWith(projectName + "/"))) return "project";
  if (isStd(it.p)) return "std";
  if (opts.companyPrefixes.length && opts.companyPrefixes.some((p) => it.p === p || it.p.startsWith(p + "/"))) return "company";
  return "general";
}

function maybeAlias(it: ImportItem, opts: Opts) {
  if (!opts.setAlias || it.alias) return;
  const parts = it.p.split("/");
  const last = parts[parts.length - 1];
  if (/^v\d+$/.test(last) && parts.length > 1) {
    it.alias = parts[parts.length - 2].replace(/[^A-Za-z0-9_]/g, "_");
  }
}

function renderItem(it: ImportItem): string[] {
  const lines = [...it.lead];
  const pre = it.alias ? `${it.alias} ` : "";
  const suffix = it.suffix ? ` ${it.suffix.replace(/^\/\/\s*/, "// ")}` : "";
  lines.push(`\t${pre}"${it.p}"${suffix}`);
  return lines;
}

function renderImports(items: ImportItem[], opts: Opts, projectName: string): string {
  if (!items.length) return "";
  for (const it of items) maybeAlias(it, opts);
  const groups = new Map<string, ImportItem[]>();
  for (const it of items) {
    const g = groupOf(it, opts, projectName);
    if (!groups.has(g)) groups.set(g, []);
    groups.get(g)!.push(it);
  }
  const chunks: string[][] = [];
  for (const g of opts.importsOrder) {
    const arr = groups.get(g);
    if (!arr || !arr.length) continue;
    arr.sort((a, b) => a.p.localeCompare(b.p) || a.alias.localeCompare(b.alias));
    if (opts.separateNamed) {
      const normal = arr.filter((x) => !x.alias || x.alias === "_" || x.alias === ".");
      const named = arr.filter((x) => x.alias && x.alias !== "_" && x.alias !== ".");
      if (normal.length) chunks.push(normal.flatMap(renderItem));
      if (named.length) chunks.push(named.flatMap(renderItem));
    } else {
      chunks.push(arr.flatMap(renderItem));
    }
  }
  for (const [g, arr] of groups) {
    if (opts.importsOrder.includes(g)) continue;
    arr.sort((a, b) => a.p.localeCompare(b.p));
    chunks.push(arr.flatMap(renderItem));
  }
  if (items.length === 1 && chunks.length === 1 && chunks[0].length === 1 && !chunks[0][0].trim().startsWith("//")) {
    return `import ${chunks[0][0].trim()}`;
  }
  return "import (\n" + chunks.map((c) => c.join("\n")).join("\n\n") + "\n)";
}

function basicFormat(src: string): string {
  let out = src.replace(/\r\n/g, "\n");
  out = out.replace(/[ \t]+$/gm, "");
  out = out.replace(/\bfunc\s+([A-Za-z_][\w]*)\s*\(([^)]*)\)\s*\{/g, "func $1($2) {");
  out = out.replace(/\bfunc\s*\(([^)]*)\)\s*([A-Za-z_][\w]*)\s*\(([^)]*)\)\s*\{/g, "func ($1) $2($3) {");
  out = out.replace(/\)\s*\{/g, ") {");
  out = out.replace(/(func[^\n{]*\{)([^\s}\n])/g, "$1 $2");
  out = out.replace(/([^\s{\n])\}/g, "$1 }");
  out = out.replace(/\}\s*else\b/g, "} else");
  out = out.replace(/\n{3,}/g, "\n\n");
  out = out.replace(/^(package[^\n]*\n)(?!\n)/m, "$1\n");
  out = out.replace(/\n(import(?:\s+\S+\s+"[^"]+"|\s+"[^"]+"|\s*\([\s\S]*?\n\)))\n(?=\S)/m, "\n$1\n\n");
  out = out.replace(/\n(import(?:\s+\S+\s+"[^"]+"|\s+"[^"]+"|\s*\([\s\S]*?\n\)))\n{3,}/m, "\n$1\n\n");
  out = out.replace(/\n}\n(?=func\s)/g, "\n}\n\n");
  if (!out.endsWith("\n")) out += "\n";
  return out;
}

function gofmt(src: string): string {
  const r = spawnSync("gofmt", [], { input: src, encoding: "utf8" });
  if (r.status === 0 && r.stdout) return r.stdout;
  return basicFormat(src);
}

function processSource(src: string, opts: Opts, projectName: string): string {
  const decl = findImportDecl(src);
  let out = src;
  if (decl) {
    const without = src.slice(0, decl.start) + src.slice(decl.end);
    let items = decl.imports;
    if (opts.rmUnused) items = removeUnused(items, without);
    const rendered = renderImports(items, opts, projectName);
    out = src.slice(0, decl.start) + rendered + src.slice(decl.end);
  }
  return gofmt(out);
}

function main() {
  const { opts, targets } = parseArgs(process.argv.slice(2));
  if (!targets.length) usage(1);
  const files = collectTargets(targets, opts);
  log(`Paths: [${targets.join(" ")}]`);
  let anyChanged = false;
  for (const file of files) {
    log(`Processing ${path.relative(process.cwd(), file) || file}`);
    const src = fs.readFileSync(file, "utf8");
    const projectName = opts.projectName || findProjectName(file);
    if (!projectName) {
      usage(1);
    }
    if (isGenerated(src) && !opts.applyGenerated) continue;
    const next = processSource(src, opts, projectName);
    const changed = next !== src;
    if (changed) anyChanged = true;
    if (opts.listDiff && changed) console.log(file);
    if (opts.output === "stdout") {
      process.stdout.write(next);
    } else if (!opts.listDiff || opts.output === "write") {
      if (changed) fs.writeFileSync(file, next);
    }
  }
  if (opts.setExitStatus && anyChanged) process.exit(1);
}

main();
