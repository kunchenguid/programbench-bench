declare const require: any;
declare const process: any;
declare const Buffer: any;
declare const console: any;
const fs = require("fs");
const path = require("path");
const dns = require("dns");
const crypto = require("crypto");
const { URL, URLSearchParams } = require("url");

type Value = any;
type Token = { kind: "text" | "action"; text: string };
type Ctx = { dot: Value; root: Value; vars: Record<string, Value>; datasources: Record<string, DataSource>; stdin?: string; left: string; right: string; missingKey: string };
type DataSource = { url: string; raw?: string; value?: Value; loaded?: boolean };

function main() {
  run().catch((e) => {
    const err = e && e.message ? e.message : String(e);
    console.error(JSON.stringify({ time: new Date().toISOString(), level: "ERROR", msg: "", err }));
    process.exit(1);
  });
}

async function run() {
  const argv = process.argv.slice(2);
  const opts: any = { files: [] as string[], datasources: [] as string[], contexts: [] as string[], templates: [] as string[], out: "-", left: process.env.GOMPLATE_LEFT_DELIM || "{{", right: process.env.GOMPLATE_RIGHT_DELIM || "}}", missingKey: "error" };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = () => argv[++i];
    if (a === "--help" || a === "-h") return printHelp();
    if (a === "--version" || a === "-v") return console.log("gomplate version 0.0.0");
    if (a === "-i" || a === "--in") opts.inline = next();
    else if (a === "-f" || a === "--file") opts.files.push(next());
    else if (a === "-o" || a === "--out") opts.out = next();
    else if (a === "-d" || a === "--datasource") opts.datasources.push(next());
    else if (a === "-c" || a === "--context") opts.contexts.push(next());
    else if (a === "-t" || a === "--template") opts.templates.push(next());
    else if (a === "--left-delim") opts.left = next();
    else if (a === "--right-delim") opts.right = next();
    else if (a === "--missing-key") opts.missingKey = next();
    else if (a === "--input-dir") opts.inputDir = next();
    else if (a === "--output-dir") opts.outputDir = next();
    else if (a === "--output-map") opts.outputMap = next();
    else if (a === "--chmod") opts.chmod = next();
    else if (a === "-H" || a === "--datasource-header" || a === "--plugin" || a === "--exclude" || a === "--exclude-processing" || a === "--include" || a === "--config") next();
    else if (a === "-V" || a === "--verbose" || a === "--experimental" || a === "--exec-pipe") {}
    else if (a.startsWith("-")) throw new Error(`unknown flag: ${a}`);
    else opts.files.push(a);
  }

  const stdinNeeded = !opts.inline && (opts.files.length === 0 || opts.files.includes("-") || opts.datasources.some((d: string) => d.includes("stdin:")));
  const stdin = stdinNeeded ? fs.readFileSync(0, "utf8") : undefined;
  const ds: Record<string, DataSource> = {};
  for (const spec of opts.datasources) {
    const [name, url] = splitOnce(spec, "=");
    ds[name] = { url };
  }
  const envMap: Record<string, string> = {};
  for (const [k, v] of Object.entries(process.env) as any[]) envMap[k] = v ?? "";
  let root: any = { Env: envMap };
  const ctx: Ctx = { dot: root, root, vars: { "": root }, datasources: ds, stdin, left: opts.left, right: opts.right, missingKey: opts.missingKey };
  for (const spec of opts.contexts) {
    const [name, url] = splitOnce(spec, "=");
    const val = await loadDatasource({ url }, ctx);
    if (name === ".") {
      root = val; ctx.root = val; ctx.dot = val;
    } else {
      root[name] = val;
    }
  }

  if (opts.inputDir) {
    const outDir = opts.outputDir || ".";
    for (const f of walk(opts.inputDir)) {
      const rel = path.relative(opts.inputDir, f);
      const input = fs.readFileSync(f, "utf8");
      const prior = ctx.dot;
      ctx.dot = { ...ctx.root, in: f };
      const output = await render(input, ctx);
      ctx.dot = prior;
      const target = path.join(outDir, rel);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(target, output);
      if (opts.chmod) fs.chmodSync(target, parseInt(opts.chmod, 8));
    }
    return;
  }

  let input: string;
  if (opts.inline !== undefined) input = opts.inline;
  else if (opts.files.length > 0 && opts.files[0] !== "-") input = fs.readFileSync(opts.files[0], "utf8");
  else input = stdin ?? "";
  for (const t of opts.templates) input = fs.readFileSync(t, "utf8") + "\n" + input;
  const output = await render(input, ctx);
  if (!opts.out || opts.out === "-") process.stdout.write(output);
  else {
    fs.mkdirSync(path.dirname(path.resolve(opts.out)), { recursive: true });
    fs.writeFileSync(opts.out, output);
    if (opts.chmod) fs.chmodSync(opts.out, parseInt(opts.chmod, 8));
  }
}

function printHelp() {
  console.log(`Process text files with Go templates

Usage:
  gomplate [flags]

Flags:
  -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.
  -c, --context datasource           pre-load a datasource into the context, in alias=URL form.
  -f, --file file                    Template file to process. Omit to use standard input, or use --in.
  -i, --in string                    Template string to process
  -o, --out file                     output file name. Omit to use standard output.
      --left-delim delimiter         override the default left-delimiter (default "{{")
      --right-delim delimiter        override the default right-delimiter (default "}}")
  -h, --help                         help for gomplate
  -v, --version                      version for gomplate`);
}

async function render(tmpl: string, ctx: Ctx): Promise<string> {
  return renderTokens(tokenize(tmpl, ctx.left, ctx.right), ctx, 0, new Set()).then(r => r.out);
}

function tokenize(s: string, left: string, right: string): Token[] {
  const out: Token[] = [];
  let i = 0;
  while (i < s.length) {
    const a = s.indexOf(left, i);
    if (a < 0) { out.push({ kind: "text", text: s.slice(i) }); break; }
    let text = s.slice(i, a);
    let j = a + left.length;
    let trimLeft = false, trimRight = false;
    if (s[j] === "-") { trimLeft = true; j++; }
    if (trimLeft) text = text.replace(/[ \t\r\n]+$/, "");
    if (text) out.push({ kind: "text", text });
    const b = s.indexOf(right, j);
    if (b < 0) { out.push({ kind: "text", text: s.slice(a) }); break; }
    let bodyEnd = b;
    if (s[b - 1] === "-") { trimRight = true; bodyEnd = b - 1; }
    out.push({ kind: "action", text: s.slice(j, bodyEnd).trim() });
    i = b + right.length;
    if (trimRight) {
      const m = /^[ \t\r\n]+/.exec(s.slice(i));
      if (m) i += m[0].length;
    }
  }
  return out;
}

async function renderTokens(tokens: Token[], ctx: Ctx, start: number, stops: Set<string>): Promise<{ out: string; idx: number; stop?: string }> {
  let out = "";
  for (let i = start; i < tokens.length; i++) {
    const tok = tokens[i];
    if (tok.kind === "text") { out += tok.text; continue; }
    const action = tok.text;
    const head = firstWord(action);
    if (stops.has(head)) return { out, idx: i, stop: head };
    if (head === "end" || head === "else") return { out, idx: i, stop: head };
    if (head === "if") {
      const cond = truthy(await evalExpr(action.slice(2).trim(), ctx));
      const b = findBlock(tokens, i + 1);
      if (cond) out += (await renderTokens(tokens.slice(i + 1, b.elseIdx ?? b.endIdx), ctx, 0, new Set())).out;
      else if (b.elseIdx !== undefined) {
        const elseText = tokens[b.elseIdx].text;
        const slice = elseText.startsWith("else if ")
          ? [{ kind: "action" as const, text: "if " + elseText.slice(8) }, ...tokens.slice(b.elseIdx + 1, b.endIdx)]
          : tokens.slice(b.elseIdx + 1, b.endIdx);
        out += (await renderTokens(slice, ctx, 0, new Set())).out;
      }
      i = b.endIdx;
      continue;
    }
    if (head === "with") {
      const val = await evalExpr(action.slice(4).trim(), ctx);
      const b = findBlock(tokens, i + 1);
      if (truthy(val)) {
        const old = ctx.dot; ctx.dot = val;
        out += (await renderTokens(tokens.slice(i + 1, b.elseIdx ?? b.endIdx), ctx, 0, new Set())).out;
        ctx.dot = old;
      } else if (b.elseIdx !== undefined) out += (await renderTokens(tokens.slice(b.elseIdx + 1, b.endIdx), ctx, 0, new Set())).out;
      i = b.endIdx;
      continue;
    }
    if (head === "range") {
      const parsed = parseRange(action.slice(5).trim());
      const seq = await evalExpr(parsed.expr, ctx);
      const b = findBlock(tokens, i + 1);
      const entries = rangeEntries(seq);
      if (entries.length === 0 && b.elseIdx !== undefined) {
        out += (await renderTokens(tokens.slice(b.elseIdx + 1, b.endIdx), ctx, 0, new Set())).out; i = b.endIdx; continue;
      }
      const body = tokens.slice(i + 1, b.elseIdx ?? b.endIdx);
      for (const [k, v] of entries) {
        const oldDot = ctx.dot, oldVars = { ...ctx.vars };
        ctx.dot = v;
        if (parsed.vars.length === 1) ctx.vars[parsed.vars[0]] = v;
        if (parsed.vars.length >= 2) { ctx.vars[parsed.vars[0]] = k; ctx.vars[parsed.vars[1]] = v; }
        out += (await renderTokens(body, ctx, 0, new Set())).out;
        ctx.dot = oldDot; ctx.vars = oldVars;
      }
      i = b.endIdx;
      continue;
    }
    if (head === "define" || head === "template" || head === "block") continue;
    if (action.includes(":=")) {
      const [name, expr] = splitOnce(action, ":=");
      ctx.vars[name.trim().replace(/^\$/, "")] = await evalExpr(expr.trim(), ctx);
      continue;
    }
    out += formatValue(await evalExpr(action, ctx));
  }
  return { out, idx: tokens.length };
}

function parseRange(s: string): { vars: string[]; expr: string } {
  const m = s.match(/^((?:\$[\w]+)\s*(?:,\s*\$[\w]+)?|\$[\w]+)\s*:=\s*(.*)$/);
  if (!m) return { vars: [], expr: s };
  return { vars: m[1].split(",").map(v => v.trim().replace(/^\$/, "")), expr: m[2] };
}

function findBlock(tokens: Token[], start: number): { elseIdx?: number; endIdx: number } {
  let depth = 0;
  for (let i = start; i < tokens.length; i++) {
    if (tokens[i].kind !== "action") continue;
    const h = firstWord(tokens[i].text);
    if (h === "if" || h === "range" || h === "with") depth++;
    else if (h === "end") {
      if (depth === 0) return { endIdx: i };
      depth--;
    } else if (h === "else" && depth === 0) {
      const tail = findBlock(tokens, i + 1);
      return { elseIdx: i, endIdx: tail.endIdx };
    }
  }
  return { endIdx: tokens.length };
}

async function evalExpr(expr: string, ctx: Ctx): Promise<Value> {
  expr = expr.trim();
  if (!expr) return "";
  const parts = splitTop(expr, "|");
  let val = await evalCommand(parts[0].trim(), ctx);
  for (let i = 1; i < parts.length; i++) {
    const toks = lex(parts[i].trim());
    if (toks.length === 0) continue;
    const fn = toks[0];
    const args = [];
    for (let j = 1; j < toks.length; j++) args.push(await evalToken(toks[j], ctx));
    args.push(val);
    val = await callFunc(fn, args, ctx);
  }
  return val;
}

async function evalCommand(cmd: string, ctx: Ctx): Promise<Value> {
  cmd = stripParens(cmd.trim());
  const parenField = splitParenField(cmd);
  if (parenField) return getPath(await evalExpr(parenField.inner, ctx), parenField.field, ctx);
  const toks = lex(cmd);
  if (toks.length === 0) return "";
  if (toks.length === 1) return evalToken(toks[0], ctx);
  const args = [];
  for (let i = 1; i < toks.length; i++) args.push(await evalToken(toks[i], ctx));
  return callFunc(toks[0], args, ctx);
}

async function evalToken(tok: string, ctx: Ctx): Promise<Value> {
  tok = tok.trim();
  if (tok.startsWith("(") && tok.endsWith(")")) return evalExpr(tok.slice(1, -1), ctx);
  const pf = splitParenField(tok);
  if (pf) return getPath(await evalExpr(pf.inner, ctx), pf.field, ctx);
  if (/^".*"$/.test(tok) || /^`.*`$/.test(tok)) return unquote(tok);
  if (/^'.*'$/.test(tok)) return tok.slice(1, -1);
  if (tok === "true") return true;
  if (tok === "false") return false;
  if (tok === "nil" || tok === "null") return null;
  if (/^-?(0x[0-9a-f]+|\d+(\.\d+)?([eE][+-]?\d+)?)$/i.test(tok)) return parseNum(tok);
  if (tok.startsWith("$")) {
    if (tok === "$") return ctx.root;
    if (tok.startsWith("$.")) return getPath(ctx.root, tok.slice(2), ctx);
    if (!tok.includes(".")) return ctx.vars[tok.slice(1)];
    return getPath(ctx.vars[tok.slice(1).split(".")[0]], tok.slice(tok.indexOf(".") + 1), ctx);
  }
  if (tok === ".") return ctx.dot;
  if (tok.startsWith(".")) return getPath(ctx.dot, tok.slice(1), ctx);
  if (tok.startsWith("env.Env.")) return getPath(ctx.root.Env, tok.slice("env.Env.".length), ctx);
  if (isFunc(tok)) return callFunc(tok, [], ctx);
  return tok;
}

function lex(s: string): string[] {
  const out: string[] = [];
  let cur = "", quote = "", depth = 0, esc = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (quote) {
      cur += c;
      if (esc) esc = false; else if (c === "\\") esc = true; else if (c === quote) quote = "";
    } else if (c === "\"" || c === "'" || c === "`") { quote = c; cur += c; }
    else if (c === "(") { depth++; cur += c; }
    else if (c === ")") { depth--; cur += c; }
    else if (/\s/.test(c) && depth === 0) { if (cur) { out.push(cur); cur = ""; } }
    else cur += c;
  }
  if (cur) out.push(cur);
  return out;
}

async function callFunc(name: string, args: Value[], ctx: Ctx): Promise<Value> {
  const n = name;
  const sargs = () => args.map(x => String(x));
  switch (n) {
    case "print": return args.map(formatValue).join("");
    case "println": return args.map(formatValue).join(" ") + "\n";
    case "printf": return goPrintf(String(args[0] ?? ""), args.slice(1));
    case "len": return valLength(args[0]);
    case "index": return args.slice(1).reduce((v, k) => v?.[k], args[0]);
    case "eq": return args.every(a => a == args[0]);
    case "ne": return args[0] != args[1];
    case "lt": return args[0] < args[1];
    case "le": return args[0] <= args[1];
    case "gt": return args[0] > args[1];
    case "ge": return args[0] >= args[1];
    case "not": return !truthy(args[0]);
    case "and": return args.every(truthy) ? args[args.length - 1] : false;
    case "or": return args.find(truthy) ?? false;
    case "html": return escapeHtml(String(args[0] ?? ""));
    case "urlquery": return encodeURIComponent(String(args[0] ?? ""));
    case "js": return JSON.stringify(String(args[0] ?? "")).slice(1, -1);
    case "env.Getenv": case "getenv": return getenv(String(args[0] ?? ""), args[1] ?? "");
    case "env.HasEnv": return Object.prototype.hasOwnProperty.call(process.env, String(args[0] ?? ""));
    case "env.ExpandEnv": return expandEnv(String(args[0] ?? ""));
    case "env.Env": return ctx.root.Env;
    case "math.Add": case "add": return nums(args).reduce((a, b) => a + b, 0);
    case "math.Mul": case "mul": return nums(args).reduce((a, b) => a * b, 1);
    case "math.Sub": case "sub": return nums(args).slice(1).reduce((a, b) => a - b, toNum(args[0]));
    case "math.Div": case "div": return toNum(args[0]) / toNum(args[1]);
    case "math.Mod": case "mod": return toNum(args[0]) % toNum(args[1]);
    case "math.Abs": return Math.abs(toNum(args[0]));
    case "math.Ceil": return Math.ceil(toNum(args[0]));
    case "math.Floor": return Math.floor(toNum(args[0]));
    case "math.Round": return Math.round(toNum(args[0]));
    case "math.Pow": return Math.pow(toNum(args[0]), toNum(args[1]));
    case "math.Max": return Math.max(...nums(args));
    case "math.Min": return Math.min(...nums(args));
    case "math.IsInt": return Number.isInteger(toNum(args[0])) && !String(args[0]).includes(".");
    case "math.IsFloat": return String(args[0]).includes(".") || ["NaN", "Inf", "+Inf", "-Inf"].includes(String(args[0]));
    case "math.Seq": case "seq": return seq(args.length === 1 ? 1 : toInt(args[0]), args.length === 1 ? toInt(args[0]) : toInt(args[1]), args.length >= 3 ? toInt(args[2]) : 1);
    case "strings.ToUpper": case "toUpper": case "upper": return String(args[0] ?? "").toUpperCase();
    case "strings.ToLower": case "toLower": case "lower": return String(args[0] ?? "").toLowerCase();
    case "strings.Title": case "title": return String(args[0] ?? "").replace(/\b\w/g, c => c.toUpperCase());
    case "strings.TrimSpace": case "trim": return String(args[0] ?? "").trim();
    case "strings.Contains": return String(args[1] ?? "").includes(String(args[0] ?? ""));
    case "strings.HasPrefix": return String(args[1] ?? "").startsWith(String(args[0] ?? ""));
    case "strings.HasSuffix": return String(args[1] ?? "").endsWith(String(args[0] ?? ""));
    case "strings.Replace": case "replace": return String(args[2] ?? "").split(String(args[0] ?? "")).join(String(args[1] ?? ""));
    case "strings.Split": case "split": return String(args[1] ?? "").split(String(args[0] ?? ""));
    case "strings.Join": case "join": return Array.isArray(args[0]) ? args[0].join(String(args[1] ?? "")) : Array.isArray(args[1]) ? args[1].join(String(args[0] ?? "")) : sargs().join("");
    case "strings.Indent": case "indent": { const width = args.length === 2 ? toInt(args[0]) : toInt(args[0]); const input = String(args[args.length - 1] ?? ""); return input.split("\n").map(l => " ".repeat(width) + l).join("\n"); }
    case "strings.Trunc": return String(args[1] ?? "").slice(0, toInt(args[0]));
    case "base64.Encode": case "base64enc": return Buffer.from(String(args[0] ?? "")).toString("base64");
    case "base64.Decode": case "base64dec": return Buffer.from(String(args[0] ?? ""), "base64").toString("utf8");
    case "base64.DecodeBytes": return Array.from(Buffer.from(String(args[0] ?? ""), "base64"));
    case "coll.Slice": case "slice": return args;
    case "coll.Dict": case "dict": { const o: any = {}; for (let i = 0; i < args.length; i += 2) o[String(args[i])] = args[i + 1]; return o; }
    case "data.JSON": case "json": return JSON.parse(String(args[0] ?? ""));
    case "data.ToJSON": case "toJSON": return JSON.stringify(args[0]);
    case "data.ToJSONPretty": case "toJSONPretty": return JSON.stringify(args.length === 2 ? args[1] : args[0], null, String(args.length === 2 ? args[0] : "  "));
    case "conv.ToString": return formatValue(args[0]);
    case "datasource": case "ds": return datasource(args, ctx, true);
    case "include": return datasource(args, ctx, false);
    case "file.Read": return fs.readFileSync(String(args[0]), "utf8");
    case "file.Exists": return fs.existsSync(String(args[0]));
    case "file.IsDir": return fs.existsSync(String(args[0])) && fs.statSync(String(args[0])).isDirectory();
    case "filepath.Join": case "path.Join": return path.join(...sargs());
    case "filepath.Base": case "path.Base": return path.basename(String(args[0]));
    case "filepath.Dir": case "path.Dir": return path.dirname(String(args[0]));
    case "filepath.Ext": case "path.Ext": return path.extname(String(args[0]));
    case "crypto.SHA1": return hash("sha1", args[0]);
    case "crypto.SHA256": return hash("sha256", args[0]);
    case "crypto.MD5": return hash("md5", args[0]);
    case "uuid.New": return crypto.randomUUID();
    case "net.LookupIP": return (await dns.promises.lookup(String(args[0]), { family: 4 })).address;
    case "net.LookupIPs": return (await dns.promises.lookup(String(args[0]), { family: 4, all: true })).map(x => x.address).filter((v, i, a) => a.indexOf(v) === i);
    case "net.LookupCNAME": { const r = await dns.promises.resolveCname(String(args[0])).catch(() => [String(args[0]).replace(/\.$/, "") + "."]); return r[0]; }
    case "net.LookupTXT": return (await dns.promises.resolveTxt(String(args[0]))).map(x => x.join(""));
    case "net.LookupSRV": return (await callFunc("net.LookupSRVs", args, ctx))[0];
    case "net.LookupSRVs": return (await dns.promises.resolveSrv(String(args[0]))).map(x => ({ Target: x.name.endsWith(".") ? x.name : x.name + ".", Port: x.port, Priority: x.priority, Weight: x.weight }));
  }
  if (n.includes(".")) {
    const val = getPath(ctx.root, n, ctx, false);
    if (val !== undefined) return args.length ? args.reduce((v, k) => v?.[k], val) : val;
  }
  throw new Error(`function "${name}" not defined`);
}

async function datasource(args: Value[], ctx: Ctx, parsed: boolean) {
  const name = String(args[0] ?? "");
  const ds = ctx.datasources[name];
  if (!ds) throw new Error(`datasource '${name}' not defined`);
  const base = parsed ? await loadDatasource(ds, ctx) : await loadDatasourceRaw(ds, ctx);
  if (args.length <= 1) return base;
  return args.slice(1).reduce((v, k) => v?.[k] ?? v?.[String(k).replace(/^\//, "")], base);
}

async function loadDatasource(ds: DataSource, ctx: Ctx): Promise<Value> {
  if (ds.loaded) return ds.value;
  const raw = await loadDatasourceRaw(ds, ctx);
  ds.value = parseData(raw, ds.url);
  ds.loaded = true;
  return ds.value;
}

async function loadDatasourceRaw(ds: DataSource, ctx: Ctx): Promise<string> {
  if (ds.raw !== undefined) return ds.raw;
  let u = ds.url;
  if (u.startsWith("stdin:")) ds.raw = ctx.stdin ?? "";
  else if (u.startsWith("env:///")) ds.raw = process.env[decodeURIComponent(u.slice(7).split("?")[0])] ?? "";
  else if (u.startsWith("file://")) ds.raw = fs.readFileSync(new URL(u), "utf8");
  else if (/^[a-z][a-z0-9+.-]*:\/\//i.test(u)) throw new Error(`unsupported datasource URL scheme in ${u}`);
  else ds.raw = fs.readFileSync(u.split("?")[0], "utf8");
  return ds.raw;
}

function parseData(raw: string, u: string): Value {
  const type = new URLSearchParams((u.split("?")[1] || "").split("#")[0]).get("type") || "";
  const clean = u.split("?")[0].toLowerCase();
  if (type.includes("json") || clean.endsWith(".json")) return JSON.parse(raw);
  if (type.includes("yaml") || clean.endsWith(".yaml") || clean.endsWith(".yml")) return parseYaml(raw);
  if (type.includes("x-env") || clean.endsWith(".env")) return parseEnv(raw);
  if (type.includes("csv") || clean.endsWith(".csv")) return raw.trimEnd().split(/\r?\n/).map(l => l.split(","));
  if (type.includes("toml") || clean.endsWith(".toml")) return parseEnv(raw);
  return raw;
}

function parseYaml(raw: string): any {
  const root: any = {};
  const stack: any[] = [root], indents = [-1];
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith("#")) continue;
    const indent = line.match(/^ */)![0].length;
    while (indent <= indents[indents.length - 1]) { stack.pop(); indents.pop(); }
    const t = line.trim();
    if (t.startsWith("- ")) {
      let arr = stack[stack.length - 1];
      if (!Array.isArray(arr)) continue;
      arr.push(parseScalar(t.slice(2)));
      continue;
    }
    const [k, v] = splitOnce(t, ":");
    if (v.trim() === "") {
      const obj: any = {};
      stack[stack.length - 1][k.trim()] = obj;
      stack.push(obj); indents.push(indent);
    } else stack[stack.length - 1][k.trim()] = parseScalar(v.trim());
  }
  return root;
}

function parseEnv(raw: string): any {
  const o: any = {};
  for (let l of raw.split(/\r?\n/)) {
    l = l.trim(); if (!l || l.startsWith("#")) continue;
    if (l.startsWith("export ")) l = l.slice(7);
    const [k, v] = splitOnce(l, "=");
    o[k.trim()] = parseScalar(v.trim());
  }
  return o;
}

function parseScalar(s: string): any {
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) return unquote(s);
  if (s === "true") return true; if (s === "false") return false; if (s === "null") return null;
  if (/^-?\d+(\.\d+)?$/.test(s)) return Number(s);
  return s;
}

function getPath(obj: any, p: string, ctx: Ctx, allowMissing = true): any {
  if (!p) return obj;
  const parts = p.split(".").filter(Boolean);
  let v = obj;
  for (const part of parts) {
    if (v == null || !(part in Object(v))) {
      if (ctx.missingKey === "error") throw new Error(`map has no entry for key "${part}"`);
      return ctx.missingKey === "zero" ? "" : "<no value>";
    }
    v = v[part];
  }
  return v;
}

function formatValue(v: any): string {
  if (v == null) return "<no value>";
  if (Array.isArray(v)) return "[" + v.map(formatValue).join(" ") + "]";
  if (typeof v === "object") return "map[" + Object.keys(v).sort().map(k => `${k}:${formatValue(v[k])}`).join(" ") + "]";
  return String(v);
}

function seq(start: number, end: number, step: number): number[] {
  if (step === 0) return [];
  if (end < start && step > 0) step = -step;
  if (end > start && step < 0) step = -step;
  end -= (end - start) % step;
  const out = [start]; let last = start;
  while (last !== end) { last += step; out.push(last); if (out.length > 100000) break; }
  return out;
}

function splitOnce(s: string, sep: string): [string, string] { const i = s.indexOf(sep); return i < 0 ? [s, ""] : [s.slice(0, i), s.slice(i + sep.length)]; }
function splitTop(s: string, sep: string): string[] { const out: string[] = []; let cur = "", q = "", d = 0, esc = false; for (const c of s) { if (q) { cur += c; if (esc) esc = false; else if (c === "\\") esc = true; else if (c === q) q = ""; } else if ("\"'`".includes(c)) { q = c; cur += c; } else if (c === "(") { d++; cur += c; } else if (c === ")") { d--; cur += c; } else if (c === sep && d === 0) { out.push(cur); cur = ""; } else cur += c; } out.push(cur); return out; }
function firstWord(s: string): string { return (s.trim().match(/^\S+/) || [""])[0]; }
function stripParens(s: string): string { while (s.startsWith("(") && s.endsWith(")") && balanced(s.slice(1, -1))) s = s.slice(1, -1).trim(); return s; }
function balanced(s: string): boolean { let d = 0, q = ""; for (const c of s) { if (q) { if (c === q) q = ""; } else if ("\"'`".includes(c)) q = c; else if (c === "(") d++; else if (c === ")" && --d < 0) return false; } return d === 0 && !q; }
function splitParenField(s: string): any { if (!s.startsWith("(")) return null; let d = 0, q = ""; for (let i = 0; i < s.length; i++) { const c = s[i]; if (q) { if (c === q) q = ""; } else if ("\"'`".includes(c)) q = c; else if (c === "(") d++; else if (c === ")" && --d === 0) { if (s[i + 1] === ".") return { inner: s.slice(1, i), field: s.slice(i + 2) }; } } return null; }
function unquote(s: string): string { if (s[0] === "`") return s.slice(1, -1); try { return JSON.parse(s); } catch { return s.slice(1, -1); } }
function parseNum(s: string): number { return /^-?0x/i.test(s) ? parseInt(s, 16) : Number(s); }
function toNum(v: any): number { if (String(v) === "Inf" || String(v) === "+Inf") return Infinity; if (String(v) === "-Inf") return -Infinity; return parseNum(String(v)); }
function toInt(v: any): number { return Math.trunc(toNum(v)); }
function nums(a: any[]): number[] { return a.map(toNum); }
function truthy(v: any): boolean { return !!(Array.isArray(v) ? v.length : typeof v === "object" && v ? Object.keys(v).length : v); }
function valLength(v: any): number { return v == null ? 0 : Array.isArray(v) || typeof v === "string" ? v.length : Object.keys(v).length; }
function rangeEntries(v: any): [any, any][] { if (Array.isArray(v) || typeof v === "string") return Array.from(v as any).map((x, i) => [i, x]); if (v && typeof v === "object") return Object.keys(v).sort().map(k => [k, v[k]]); return []; }
function getenv(k: string, def = ""): string { if (process.env[k] !== undefined) return process.env[k]!; const f = process.env[k + "_FILE"]; if (f) try { return fs.readFileSync(f, "utf8").trimEnd(); } catch {} return String(def); }
function expandEnv(s: string): string { return s.replace(/\$(\w+)|\$\{([^}]+)\}/g, (_, a, b) => getenv(a || b, "")); }
function escapeHtml(s: string): string { return s.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&#34;", "'": "&#39;" } as any)[c]); }
function hash(alg: string, v: any): string { return crypto.createHash(alg).update(String(v ?? "")).digest("hex"); }
function goPrintf(fmt: string, args: any[]): string { let i = 0; return fmt.replace(/%[#0 +\-]*[0-9.]*[vdsfq]/g, m => { const a = args[i++]; const verb = m[m.length - 1]; if (verb === "q") return JSON.stringify(String(a)); if (verb === "d") return String(Math.trunc(toNum(a))); if (verb === "f") return String(toNum(a)); if (verb === "s") return String(a); if (verb === "v") return m.includes("#") ? JSON.stringify(a) : formatValue(a); return m; }).replace(/%%/g, "%"); }
function walk(dir: string): string[] { const out: string[] = []; for (const e of fs.readdirSync(dir)) { const p = path.join(dir, e); const st = fs.statSync(p); if (st.isDirectory()) out.push(...walk(p)); else out.push(p); } return out; }
function isFunc(n: string): boolean { return ["env.Env", "uuid.New"].includes(n); }

main();
