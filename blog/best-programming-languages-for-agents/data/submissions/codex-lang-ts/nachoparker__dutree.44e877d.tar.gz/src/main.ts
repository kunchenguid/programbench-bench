// @ts-nocheck
import * as fs from "fs";
import * as path from "path";

type Opts = {
  depth: number;
  aggr: number;
  usage: boolean;
  bytes: boolean;
  filesOnly: boolean;
  noHidden: boolean;
  excludes: string[];
  paths: string[];
};

type NodeInfo = {
  name: string;
  fullPath: string;
  size: number;
  isDir: boolean;
  children: NodeInfo[];
};

const HELP = `Usage: ./executable [options] <path> [<path>..]

Options:
    -d, --depth [DEPTH] show directories up to depth N (def 1)
    -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)
    -s, --summary       equivalent to -da, or -d1 -a1M
    -u, --usage         report real disk usage instead of file size
    -b, --bytes         print sizes in bytes
    -f, --files-only    skip directories for a fast local overview
    -x, --exclude NAME  exclude matching files or directories
    -H, --no-hidden     exclude hidden files
    -A, --ascii         ASCII characters only, no colors
    -h, --help          show help
    -v, --version       print version number`;

function printHelp(): void {
  console.log(HELP);
}

function parseSize(s: string): number | null {
  const m = /^(\d+)([KkMmGg])?$/.exec(s);
  if (!m) return null;
  const n = Number(m[1]);
  const u = (m[2] || "").toUpperCase();
  if (u === "K") return n * 1024;
  if (u === "M") return n * 1024 * 1024;
  if (u === "G") return n * 1024 * 1024 * 1024;
  return n;
}

function maybeNumber(s: string | undefined): boolean {
  return !!s && /^\d+$/.test(s);
}

function parseArgs(argv: string[]): Opts | "exit0" | "exit1" {
  const opts: Opts = {
    depth: 1,
    aggr: 1024 * 1024,
    usage: false,
    bytes: false,
    filesOnly: false,
    noHidden: false,
    excludes: [],
    paths: [],
  };

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help" || a === "-h") {
      printHelp();
      return "exit0";
    }
    if (a === "--version" || a === "-v") {
      console.log("dutree version 0.2.18");
      return "exit0";
    }
    if (a === "--usage" || a === "-u") opts.usage = true;
    else if (a === "--bytes" || a === "-b") opts.bytes = true;
    else if (a === "--files-only" || a === "-f") opts.filesOnly = true;
    else if (a === "--no-hidden" || a === "-H") opts.noHidden = true;
    else if (a === "--ascii" || a === "-A") {
      // Output is plain when stdout is not a tty; keep all rendering plain.
    } else if (a === "--summary" || a === "-s") {
      opts.depth = 1;
      opts.aggr = 1024 * 1024;
    } else if (a === "--depth" || a === "-d") {
      if (maybeNumber(argv[i + 1])) opts.depth = Number(argv[++i]);
    } else if (a.startsWith("--depth=")) {
      const v = a.slice("--depth=".length);
      if (maybeNumber(v)) opts.depth = Number(v);
    } else if (a.startsWith("-d") && a.length > 2) {
      const v = a.slice(2);
      if (maybeNumber(v)) opts.depth = Number(v);
    } else if (a === "--aggr" || a === "-a") {
      if (argv[i + 1] && !argv[i + 1].startsWith("-")) {
        const parsed = parseSize(argv[++i]);
        if (parsed == null) {
          console.log(`invalid argument '${argv[i]}'`);
          return "exit1";
        }
        opts.aggr = parsed;
      }
    } else if (a.startsWith("--aggr=")) {
      const v = a.slice("--aggr=".length);
      const parsed = parseSize(v);
      if (parsed == null) {
        console.log(`invalid argument '${v}'`);
        return "exit1";
      }
      opts.aggr = parsed;
    } else if (a.startsWith("-a") && a.length > 2) {
      const v = a.slice(2);
      const parsed = parseSize(v);
      if (parsed == null) {
        console.log(`invalid argument '${v}'`);
        return "exit1";
      }
      opts.aggr = parsed;
    } else if (a === "--exclude" || a === "-x") {
      if (argv[i + 1]) opts.excludes.push(argv[++i]);
    } else if (a.startsWith("--exclude=")) {
      opts.excludes.push(a.slice("--exclude=".length));
    } else if (a.startsWith("-x") && a.length > 2) {
      opts.excludes.push(a.slice(2));
    } else if (a.startsWith("-")) {
      console.log(`Unrecognized option: '${a.replace(/^-+/, "")}'`);
      printHelp();
      return "exit1";
    } else {
      opts.paths.push(a);
    }
  }

  if (opts.paths.length === 0) opts.paths.push(".");
  return opts;
}

function nameOf(p: string): string {
  const cleaned = p.replace(/\/+$/, "");
  if (cleaned === "" || cleaned === ".") return path.basename(process.cwd());
  return path.basename(cleaned) || cleaned;
}

function excluded(name: string, opts: Opts): boolean {
  if (opts.noHidden && name.startsWith(".")) return true;
  return opts.excludes.some((x) => name === x || name.includes(x));
}

function statSize(st: fs.Stats, opts: Opts): number {
  return opts.usage ? st.blocks * 512 : st.size;
}

function scan(p: string, opts: Opts, isRoot = false): NodeInfo {
  const st = fs.lstatSync(p);
  const isDir = st.isDirectory();
  const node: NodeInfo = {
    name: isRoot ? nameOf(p) : path.basename(p),
    fullPath: p,
    size: statSize(st, opts),
    isDir,
    children: [],
  };
  if (!isDir) return node;

  let entries: string[] = [];
  try {
    entries = fs.readdirSync(p);
  } catch {
    return node;
  }
  for (const ent of entries) {
    if (excluded(ent, opts)) continue;
    const childPath = path.join(p, ent);
    let child: NodeInfo;
    try {
      const stc = fs.lstatSync(childPath);
      if (opts.filesOnly && stc.isDirectory()) continue;
      child = scan(childPath, opts, false);
    } catch {
      continue;
    }
    node.size += child.size;
    node.children.push(child);
  }
  node.children.sort((a, b) => b.size - a.size || b.name.localeCompare(a.name));
  return node;
}

function formatSize(n: number, bytes: boolean): string {
  if (bytes) return `${Math.round(n)} B`;
  const units = ["B", "KiB", "MiB", "GiB", "TiB"];
  let v = n;
  let i = 0;
  while (i < units.length - 1 && v >= 1024) {
    v /= 1024;
    i++;
  }
  if (i === 0) return `${Math.round(v)} B`;
  return `${v.toFixed(2)} ${units[i]}`;
}

function pct(size: number, parent: number): number {
  if (parent <= 0) return 0;
  return Math.floor((size * 100) / parent);
}

function bar(size: number, parent: number, maxSibling: number): string {
  if (size <= 0 || parent <= 0 || maxSibling <= 0) return " ".repeat(32);
  const p = pct(size, parent);
  if (p === 0) return " ".repeat(32);
  let filled = Math.floor((size / maxSibling) * 32);
  if (filled < 1) filled = 1;
  if (filled > 32) filled = 32;
  return " ".repeat(32 - filled) + "#".repeat(filled);
}

function displayName(name: string, prefixLen: number): string {
  const width = Math.max(1, 26 - prefixLen - 3);
  return name.length > width ? name.slice(0, width) : name.padEnd(width, " ");
}

function printLine(prefix: string, connector: string, name: string, size: number, parent: number, maxSibling: number, opts: Opts): void {
  const b = bar(size, parent, maxSibling);
  const p = String(pct(size, parent)).padStart(3, " ");
  const s = formatSize(size, opts.bytes).padStart(13, " ");
  console.log(`${prefix}${connector} ${displayName(name, prefix.length)} │ ${b}│ ${p}% ${s}`);
}

function visibleChildren(node: NodeInfo, opts: Opts): NodeInfo[] {
  if (opts.aggr <= 1) return node.children.slice();
  const shown: NodeInfo[] = [];
  let aggr = 0;
  for (const c of node.children) {
    if (c.size < opts.aggr) aggr += c.size;
    else shown.push(c);
  }
  if (aggr > 0) {
    shown.push({ name: "<aggregated>", fullPath: "", size: aggr, isDir: false, children: [] });
    shown.sort((a, b) => b.size - a.size || b.name.localeCompare(a.name));
  }
  return shown;
}

function renderNode(node: NodeInfo, opts: Opts): void {
  console.log(`[ ${node.name} ${formatSize(node.size, opts.bytes)} ]`);
  renderChildren(node, opts, "", 0);
}

function renderChildren(node: NodeInfo, opts: Opts, prefix: string, level: number): void {
  if (level >= opts.depth) return;
  const kids = visibleChildren(node, opts);
  const maxSibling = kids.reduce((m, c) => Math.max(m, c.size), 0);
  kids.forEach((child, idx) => {
    const last = idx === kids.length - 1;
    printLine(prefix, last ? "└─" : "├─", child.name, child.size, node.size, maxSibling, opts);
    if (child.children.length > 0 && level + 1 < opts.depth && child.name !== "<aggregated>") {
      renderChildren(child, opts, prefix + (last ? "   " : "│  "), level + 1);
    }
  });
}

function main(): void {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed === "exit0") process.exit(0);
  if (parsed === "exit1") process.exit(1);
  const opts = parsed;
  const roots: NodeInfo[] = [];
  for (const p of opts.paths) {
    if (!fs.existsSync(p)) {
      console.log(`path ${p} doesn't exist`);
      process.exit(1);
    }
    roots.push(scan(p, opts, true));
  }

  if (roots.length === 1) {
    renderNode(roots[0], opts);
  } else {
    const collection: NodeInfo = {
      name: "<collection>",
      fullPath: "",
      size: roots.reduce((s, r) => s + r.size, 0),
      isDir: true,
      children: roots.sort((a, b) => b.size - a.size || b.name.localeCompare(a.name)),
    };
    renderNode(collection, opts);
  }
}

main();
