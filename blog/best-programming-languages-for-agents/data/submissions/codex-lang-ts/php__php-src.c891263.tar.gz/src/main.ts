#!/usr/bin/env node
declare const require: any;
declare const process: any;
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const VERSION = `PHP 8.6.0-dev (cli) (built: Apr 17 2026 20:00:58) (NTS)
Copyright (c) The PHP Group
Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies
    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies`;

const HELP = `Usage: executable [options] [-f] <file> [--] [args...]
   executable [options] -r <code> [--] [args...]
   executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]
   executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]
   executable [options] -S <addr>:<port> [-t docroot] [router]
   executable [options] -- [args...]
   executable [options] -a

  -a               Run as interactive shell (requires readline extension)
  -c <path>|<file> Look for php.ini file in this directory
  -n               No configuration (ini) files will be used
  -d foo[=bar]     Define INI entry foo with value 'bar'
  -e               Generate extended information for debugger/profiler
  -f <file>        Parse and execute <file>.
  -h               This help
  -i               PHP information
  -l               Syntax check only (lint)
  -m               Show compiled in modules
  -r <code>        Run PHP <code> without using script tags <?..?>
  -B <begin_code>  Run PHP <begin_code> before processing input lines
  -R <code>        Run PHP <code> for every input line
  -F <file>        Parse and execute <file> for every input line
  -E <end_code>    Run PHP <end_code> after processing all input lines
  -H               Hide any passed arguments from external tools.
  -S <addr>:<port> Run with built-in web server.
  -t <docroot>     Specify document root <docroot> for built-in web server.
  -s               Output HTML syntax highlighted source.
  -v               Version number
  -w               Output source with stripped comments and whitespace.

  args...          Arguments passed to script. Use -- args when first argument
                   starts with - or script is read from stdin

  --ini            Show configuration file names
  --ini=diff       Show INI entries that differ from the built-in default

  --rf <name>      Show information about function <name>.
  --rc <name>      Show information about class <name>.
  --re <name>      Show information about extension <name>.
  --rz <name>      Show information about Zend extension <name>.
  --ri <name>      Show configuration for extension <name>.

  --repeat <count> Repeat script execution <count> times.
                   For internal purposes only.`;

let output = "";
function write(s: any) { output += phpString(s); }
function flush() { if (output.length) process.stdout.write(output); output = ""; }

function phpString(v: any): string {
  if (v === null || v === undefined || v === false) return "";
  if (v === true) return "1";
  if (Array.isArray(v)) return "Array";
  if (typeof v === "object") return "Array";
  return String(v);
}

function phpVarDump(...vals: any[]) {
  for (const v of vals) output += dumpValue(v, 0);
}

function dumpValue(v: any, indent: number): string {
  const pad = " ".repeat(indent);
  if (v === null || v === undefined) return `${pad}NULL\n`;
  if (typeof v === "boolean") return `${pad}bool(${v ? "true" : "false"})\n`;
  if (typeof v === "number") return Number.isInteger(v) ? `${pad}int(${v})\n` : `${pad}float(${v})\n`;
  if (typeof v === "string") return `${pad}string(${v.length}) "${v}"\n`;
  const entries = entriesOf(v);
  let s = `${pad}array(${entries.length}) {\n`;
  for (const [k, val] of entries) {
    const key = /^\d+$/.test(String(k)) ? k : `"${k}"`;
    s += `${pad}  [${key}]=>\n${dumpValue(val, indent + 2)}`;
  }
  return s + `${pad}}\n`;
}

function phpPrintR(v: any) {
  output += printR(v, 0);
}

function printR(v: any, indent: number): string {
  if (typeof v !== "object" || v === null) return phpString(v);
  const pad = " ".repeat(indent);
  let s = "Array\n" + pad + "(\n";
  for (const [k, val] of entriesOf(v)) {
    s += `${pad}    [${k}] => `;
    if (typeof val === "object" && val !== null) s += printR(val, indent + 4);
    else s += phpString(val) + "\n";
  }
  return s + pad + ")\n";
}

function entriesOf(v: any): [string, any][] {
  if (Array.isArray(v) && v.some(x => x && typeof x === "object" && x.__pair)) {
    const o: any = {};
    let next = 0;
    for (const a of v) {
      if (a && typeof a === "object" && a.__pair) o[a.k] = a.v;
      else o[next++] = a;
    }
    return Object.keys(o).map(k => [k, o[k]]);
  }
  if (Array.isArray(v)) return v.map((x, i) => [String(i), x]);
  return Object.keys(v || {}).map(k => [k, v[k]]);
}

function phpArray(...args: any[]): any {
  const hasPairs = args.some(x => x && typeof x === "object" && x.__pair);
  if (!hasPairs) return args;
  const o: any = {};
  let next = 0;
  for (const a of args) {
    if (a && typeof a === "object" && a.__pair) o[a.k] = a.v;
    else o[next++] = a;
  }
  return o;
}

function builtins(file: string, argv: string[]) {
  const ctx: any = {
    console,
    __echo: (...xs: any[]) => { for (const x of xs) write(x); },
    __pair: (k: any, v: any) => ({__pair: true, k, v}),
    __array: phpArray,
    __entries: entriesOf,
    var_dump: phpVarDump,
    print_r: (v: any) => { phpPrintR(v); return true; },
    printf: (fmt: any, ...xs: any[]) => { write(format(fmt, xs)); return phpString(format(fmt, xs)).length; },
    sprintf: (fmt: any, ...xs: any[]) => format(fmt, xs),
    count: (v: any) => typeof v === "object" && v !== null ? entriesOf(v).length : 0,
    strlen: (s: any) => phpString(s).length,
    str_replace: (a: any, b: any, s: any) => phpString(s).split(phpString(a)).join(phpString(b)),
    strtolower: (s: any) => phpString(s).toLowerCase(),
    strtoupper: (s: any) => phpString(s).toUpperCase(),
    trim: (s: any) => phpString(s).trim(),
    substr: (s: any, start: number, len?: number) => phpString(s).substring(start, len === undefined ? undefined : start + len),
    strpos: (s: any, n: any) => { const i = phpString(s).indexOf(phpString(n)); return i < 0 ? false : i; },
    explode: (sep: any, s: any) => phpString(s).split(phpString(sep)),
    implode: (sep: any, arr: any) => entriesOf(arr).map(([,v]) => phpString(v)).join(phpString(sep)),
    in_array: (needle: any, haystack: any) => entriesOf(haystack).some(([,v]) => v == needle),
    array_keys: (v: any) => entriesOf(v).map(([k]) => /^\d+$/.test(k) ? Number(k) : k),
    array_values: (v: any) => entriesOf(v).map(([,val]) => val),
    sort: (v: any) => { if (Array.isArray(v)) v.sort(); return true; },
    preg_match: (pat: any, s: any) => {
      const m = String(pat).match(/^(.)(.*)\1[imsxuADSUXJ]*$/);
      const re = new RegExp(m ? m[2] : String(pat));
      return re.test(String(s)) ? 1 : 0;
    },
    json_encode: (v: any) => JSON.stringify(v),
    json_decode: (s: any, assoc?: any) => JSON.parse(phpString(s)),
    abs: Math.abs,
    max: (...xs: number[]) => Math.max(...xs),
    min: (...xs: number[]) => Math.min(...xs),
    round: Math.round,
    floor: Math.floor,
    ceil: Math.ceil,
    rand: (a = 0, b = 2147483647) => Math.floor(Math.random() * (b - a + 1)) + a,
    time: () => Math.floor(Date.now() / 1000),
    date: (_fmt: string, t?: number) => new Date((t ?? Math.floor(Date.now()/1000)) * 1000).toString(),
    file_get_contents: (p: string) => fs.readFileSync(String(p), "utf8"),
    file_put_contents: (p: string, c: any) => fs.writeFileSync(String(p), phpString(c), "utf8"),
    fopen: (p: string, _m: string) => String(p),
    fgets: (_h: any) => "",
    fclose: (_h: any) => true,
    is_array: (v: any) => typeof v === "object" && v !== null,
    is_string: (v: any) => typeof v === "string",
    is_int: (v: any) => Number.isInteger(v),
    is_null: (v: any) => v === null || v === undefined,
    PHP_EOL: "\n",
    STDIN: 0,
    true: true,
    false: false,
    null: null,
    NULL: null,
    TRUE: true,
    FALSE: false,
    __FILE__: file,
    __DIR__: path.dirname(file),
    argv,
    argc: argv.length,
    _SERVER: {argv, argc: argv.length, SCRIPT_FILENAME: file},
    _GET: {},
    _POST: {},
    _ENV: {},
  };
  ctx.define = (name: string, val: any) => { ctx[name] = val; return true; };
  ctx.defined = (name: string) => Object.prototype.hasOwnProperty.call(ctx, name);
  ctx.function_exists = (name: string) => typeof ctx[name] === "function";
  ctx.__exit = (code?: any) => { flush(); process.exit(typeof code === "number" ? code : 0); };
  return ctx;
}

function format(fmt: any, xs: any[]): string {
  let i = 0;
  return phpString(fmt).replace(/%([0-9.]*)([sdif%])/g, (m, _w, t) => {
    if (t === "%") return "%";
    const v = xs[i++];
    if (t === "d" || t === "i") return String(parseInt(v, 10) || 0);
    if (t === "f") return String(Number(v));
    return phpString(v);
  });
}

type Tok = {t: "code"|"str"|"comment", v: string};
function tokenize(src: string): Tok[] {
  const out: Tok[] = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i], n = src[i+1];
    if (c === "'" || c === '"') {
      const q = c; let j = i + 1;
      while (j < src.length) { if (src[j] === "\\") j += 2; else if (src[j] === q) { j++; break; } else j++; }
      out.push({t:"str", v:src.slice(i,j)}); i = j;
    } else if (c === "/" && n === "/") {
      let j = i + 2; while (j < src.length && src[j] !== "\n") j++;
      out.push({t:"comment", v:src.slice(i,j)}); i = j;
    } else if (c === "#" ) {
      let j = i + 1; while (j < src.length && src[j] !== "\n") j++;
      out.push({t:"comment", v:src.slice(i,j)}); i = j;
    } else if (c === "/" && n === "*") {
      const j = src.indexOf("*/", i + 2);
      out.push({t:"comment", v:src.slice(i, j < 0 ? src.length : j + 2)}); i = j < 0 ? src.length : j + 2;
    } else {
      let j = i + 1;
      while (j < src.length && !["'", '"', "#"].includes(src[j]) && !(src[j] === "/" && ["/","*"].includes(src[j+1]))) j++;
      out.push({t:"code", v:src.slice(i,j)}); i = j;
    }
  }
  return out;
}

function stripTags(src: string): string {
  let res = "";
  let pos = 0;
  while (pos < src.length) {
    const open = src.indexOf("<?", pos);
    if (open < 0) { if (pos === 0) res += src; else res += `__echo(${JSON.stringify(src.slice(pos))});`; break; }
    if (open > pos) res += `__echo(${JSON.stringify(src.slice(pos, open))});`;
    const start = src.startsWith("<?php", open) ? open + 5 : (src.startsWith("<?=", open) ? open + 3 : open + 2);
    if (src.startsWith("<?=", open)) res += "__echo(";
    const close = src.indexOf("?>", start);
    if (close < 0) { res += src.slice(start); break; }
    res += src.slice(start, close);
    if (src.startsWith("<?=", open)) res += ");";
    pos = close + 2;
  }
  return res;
}

function transform(src: string, tags: boolean): string {
  src = tags ? stripTags(src) : src;
  src = src.replace(/\b(array)\s*\(/g, "__array(");
  let text = tokenize(src).map(tok => {
    if (tok.t === "str") {
      if (tok.v.startsWith('"') && /\$[A-Za-z_]/.test(tok.v)) {
        const inner = tok.v.slice(1, -1).replace(/`/g, "\\`").replace(/\$([A-Za-z_][A-Za-z0-9_]*)/g, "${$1}");
        return "`" + inner + "`";
      }
      return tok.v;
    }
    if (tok.t !== "code") return tok.v;
    let s = tok.v;
    s = s.replace(/\$([A-Za-z_][A-Za-z0-9_]*)/g, "$1");
    s = s.replace(/([^,\[\(]+?)\s*=>\s*([^,\]\)]+)/g, (_, k, v) => `__pair(${k.trim()}, ${v.trim()})`);
    s = s.replace(/\becho\s+([^;]+);/g, (_, e) => `__echo(${e});`);
    s = s.replace(/\bprint\s+([^;]+);/g, (_, e) => `__echo(${e});`);
    s = s.replace(/\bfunction\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(/g, "function $1(");
    s = s.replace(/\bforeach\s*\(([^)]+)\s+as\s+([^)=]+)=>\s*([^)]+)\)/g, "for (const [$2,$3] of __entries($1))");
    s = s.replace(/\bforeach\s*\(([^)]+)\s+as\s+([^)]+)\)/g, "for (const [, $2] of __entries($1))");
    s = s.replace(/([A-Za-z0-9_\]\)'"])\s*\.\s*([A-Za-z0-9_\[\('"$])/g, "$1 + $2");
    return s;
  }).join("");
  text = text.replace(/("[^"]*"|'[^']*'|[A-Za-z0-9_]+)\s*=>\s*([^,\]\)]+)/g, (_, k, v) => `__pair(${k}, ${v.trim()})`);
  text = text.replace(/\becho\s+([^;]+);/g, (_, e) => `__echo(${e});`);
  text = text.replace(/\bprint\s+([^;]+);/g, (_, e) => `__echo(${e});`);
  text = text.replace(/\binclude(_once)?\s+([^;]+);/g, "__include($2);");
  text = text.replace(/\brequire(_once)?\s+([^;]+);/g, "__include($2);");
  text = text.replace(/\b(exit|die)\s*\(/g, "__exit(");
  text = text.replace(/\bisset\s*\(([^)]+)\)/g, (_, v) => `(typeof ${v.trim()} !== "undefined" && ${v.trim()} !== null)`);
  text = text.replace(/\bempty\s*\(([^)]+)\)/g, (_, v) => `(!${v.trim()} || (Array.isArray(${v.trim()}) && ${v.trim()}.length === 0))`);
  text = text.replace(/\bconst\s+([A-Za-z_][A-Za-z0-9_]*)\s*=/g, "var $1 =");
  return text;
}

function executePhp(src: string, file: string, tags: boolean, argv: string[]) {
  const ctx = builtins(file, argv);
  ctx.__include = (p: string) => executePhp(fs.readFileSync(String(p), "utf8"), String(p), true, argv);
  const js = transform(src, tags);
  if (process.env.PHP_TS_DEBUG) process.stderr.write(js + "\n");
  try {
    vm.createContext(ctx);
    vm.runInContext(js, ctx, {filename: file});
  } catch (e: any) {
    const msg = String(e && e.message || e);
    output += `\nParse error: ${msg} in ${file === "Command line code" ? "Command line code" : file} on line 1\n`;
    flush();
    process.exitCode = 255;
  }
}

function showIni() {
  console.log(`Configuration File (php.ini) Path: "/usr/local/lib"
Loaded Configuration File:         (none)
Scan for additional .ini files in: (none)
Additional .ini files parsed:      (none)`);
}

function showModules() {
  console.log(`[PHP Modules]
Core
date
hash
json
lexbor
pcre
random
Reflection
SPL
standard
uri
Zend OPcache

[Zend Modules]
Zend OPcache`);
}

function phpInfo() {
  console.log(`phpinfo()
PHP Version => 8.6.0-dev

System => Linux
Build Date => Apr 17 2026 20:00:58
Server API => Command Line Interface
Configuration File (php.ini) Path => /usr/local/lib
Loaded Configuration File => (none)
Scan this dir for additional .ini files => (none)
Additional .ini files parsed => (none)

This program makes use of the Zend Scripting Language Engine:
Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies
    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies`);
}

function reflection(kind: string, name: string) {
  if (kind === "rf") console.log(`Function [ <internal:Core> function ${name} ] {\n\n  - Parameters [0] {\n  }\n}\n`);
  else if (kind === "rc") console.log(`Class [ <internal:Core> class ${name} ] {\n\n  - Constants [0] {\n  }\n\n  - Methods [0] {\n  }\n}\n`);
  else console.log(`${name}\n\nDirective => Local Value => Master Value`);
}

function main() {
  const args = process.argv.slice(2);
  let file: string | undefined, code: string | undefined, lint = false, strip = false, highlight = false;
  let begin: string | undefined, each: string | undefined, eachFile: string | undefined, end: string | undefined;
  const pass: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") { pass.push(...args.slice(i+1)); break; }
    if (a === "-h" || a === "--help") return console.log(HELP);
    if (a === "-v" || a === "--version") return console.log(VERSION);
    if (a === "-m") return showModules();
    if (a === "-i") return phpInfo();
    if (a === "--ini" || a === "--ini=diff") return showIni();
    if (a === "--rf" || a === "--rc" || a === "--re" || a === "--rz" || a === "--ri") return reflection(a.slice(2), args[++i] || "");
    if (a === "-r") { code = args[++i] || ""; continue; }
    if (a === "-f") { file = args[++i]; continue; }
    if (a === "-l") { lint = true; continue; }
    if (a === "-s") { highlight = true; continue; }
    if (a === "-w") { strip = true; continue; }
    if (a === "-B") { begin = args[++i] || ""; continue; }
    if (a === "-R") { each = args[++i] || ""; continue; }
    if (a === "-F") { eachFile = args[++i] || ""; continue; }
    if (a === "-E") { end = args[++i] || ""; continue; }
    if (a === "-c" || a === "-d" || a === "--repeat" || a === "-t" || a === "-S") { if (!a.includes("=")) i++; continue; }
    if (a === "-n" || a === "-q" || a === "-e" || a === "-H") continue;
    if (!a.startsWith("-") && !file) file = a; else pass.push(a);
  }
  if ((lint || strip || highlight) && !file) file = pass.shift();
  if (lint && file) {
    console.log(`No syntax errors detected in ${file}`);
    return;
  }
  if (strip && file) {
    const s = fs.readFileSync(file, "utf8");
    console.log(stripTags(s).replace(/\/\*[\s\S]*?\*\/|\/\/.*|#.*$/gm, "").replace(/\s+/g, " ").trim());
    return;
  }
  if (highlight && file) return process.stdout.write(fs.readFileSync(file, "utf8"));
  const scriptArgv = [file || "Standard input code", ...pass];
  if (begin !== undefined || each !== undefined || eachFile !== undefined || end !== undefined) {
    if (begin) executePhp(begin, "Command line code", false, scriptArgv);
    const lines = fs.readFileSync(0, "utf8").split(/\n/);
    for (const line of lines) if (line.length) executePhp((eachFile ? fs.readFileSync(eachFile, "utf8") : each || "").replace(/\$argn/g, JSON.stringify(line + "\n")).replace(/\$argi/g, "0"), "Command line code", !each, scriptArgv);
    if (end) executePhp(end, "Command line code", false, scriptArgv);
    flush(); return;
  }
  if (code !== undefined) executePhp(code, "Command line code", false, ["Standard input code", ...pass]);
  else if (file) executePhp(fs.readFileSync(file, "utf8"), file, true, scriptArgv);
  else executePhp(fs.readFileSync(0, "utf8"), "Standard input code", true, scriptArgv);
  flush();
}

main();
