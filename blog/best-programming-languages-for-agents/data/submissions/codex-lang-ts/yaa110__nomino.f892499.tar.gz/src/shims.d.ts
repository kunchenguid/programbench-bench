declare const process: {
  argv: string[];
  pid: number;
  cwd(): string;
  exit(code?: number): never;
  stderr: { write(s: string): void };
  stdout: { write(s: string): void };
};
declare function require(name: string): any;
declare const __dirname: string;
