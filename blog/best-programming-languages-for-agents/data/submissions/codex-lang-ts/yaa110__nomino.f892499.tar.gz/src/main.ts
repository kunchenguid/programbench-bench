const fs = require("fs");
const path = require("path");

type Mode = "sort" | "regex" | "map";

interface Options {
  dir: string;
  depth?: number;
  maxDepth?: number;
  noExtension: boolean;
  generate?: string;
  mkdir: boolean;
  map?: string;
  quiet: boolean;
  regex?: string;
  sort?: "asc" | "desc";
  test: boolean;
  overwrite: boolean;
  positionals: string[];
}

interface RenameItem {
  input: string;
  output: string;
}

function usage(): string {
  return `Batch rename utility for developers

Usage: executable [OPTIONS] [[SOURCE] OUTPUT]...

Arguments:
  [[SOURCE] OUTPUT]...
          OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option

Options:
  -d, --dir <PATH>
          Sets the working directory

      --depth <DEPTH>
          Optional value to overwrite inferred subdirectory depth value in 'regex' mode

  -E, --no-extension
          Does not preserve the extension of input files in 'sort' and 'regex' options

  -g, --generate <PATH>
          Stores a JSON map file in '<PATH>' after renaming files

  -h, --help
          Print help (see a summary with '-h')

  -k, --mkdir
          Recursively creates all parent directories of '<OUTPUT>' if they are missing

  -m, --map <PATH>
          Sets the path of map file to be used for renaming files
          
          [aliases: --from-file]

      --max-depth <DEPTH>
          Optional value to set the maximum of subdirectory depth value in 'regex' mode

  -q, --quiet
          Does not print the map table to stdout

  -r, --regex <PATTERN>
          Regex pattern to match by filenames

  -s, --sort <ORDER>
          Sets the order of natural sorting (by name) to rename files using enumerator

          Possible values:
          - asc:  Sort in ascending order
          - desc: Sort in descending order

  -t, --test
          Runs in test mode without renaming actual files
          
          [aliases: --dry-run]

  -V, --version
          Print version

  -w, --overwrite
          Overwrites output files, otherwise, a '_' is prepended to filename

OUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with \`0\`. Please refer to https://github.com/yaa110/nomino for more information.
`;
}

function shortHelp(): string {
  return usage();
}

function fail(msg: string, code = 1): never {
  process.stderr.write(msg.endsWith("\n") ? msg : msg + "\n");
  process.exit(code);
}

function parseArgs(argv: string[]): Options {
  const opts: Options = {
    dir: process.cwd(),
    noExtension: false,
    mkdir: false,
    quiet: false,
    test: false,
    overwrite: false,
    positionals: [],
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const need = (name: string): string => {
      const v = argv[++i];
      if (v === undefined) fail(`error: a value is required for '${name} <PATH>'`, 2);
      return v;
    };
    if (a === "-h" || a === "--help") {
      process.stdout.write(shortHelp());
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      process.stdout.write("nomino 1.6.4\n");
      process.exit(0);
    } else if (a === "-d" || a === "--dir") opts.dir = need(a);
    else if (a === "--depth") opts.depth = parseInt(need(a), 10);
    else if (a === "--max-depth") opts.maxDepth = parseInt(need(a), 10);
    else if (a === "-E" || a === "--no-extension") opts.noExtension = true;
    else if (a === "-g" || a === "--generate") opts.generate = need(a);
    else if (a === "-k" || a === "--mkdir") opts.mkdir = true;
    else if (a === "-m" || a === "--map" || a === "--from-file") opts.map = need(a);
    else if (a === "-q" || a === "--quiet") opts.quiet = true;
    else if (a === "-r" || a === "--regex") opts.regex = need(a);
    else if (a === "-s" || a === "--sort") {
      const v = need(a);
      if (v !== "asc" && v !== "desc") {
        fail(`error: invalid value '${v}' for '--sort <ORDER>'\n  [possible values: asc, desc]\n\nFor more information, try '--help'.`, 2);
      }
      opts.sort = v;
    } else if (a === "-t" || a === "--test" || a === "--dry-run") opts.test = true;
    else if (a === "-w" || a === "--overwrite") opts.overwrite = true;
    else if (a.startsWith("-")) fail(`error: unexpected argument '${a}' found\n\nFor more information, try '--help'.`, 2);
    else opts.positionals.push(a);
  }
  return opts;
}

function naturalCompare(a: string, b: string): number {
  const rx = /(\d+)|(\D+)/g;
  const aa = a.match(rx) || [];
  const bb = b.match(rx) || [];
  for (let i = 0; i < Math.min(aa.length, bb.length); i++) {
    const x = aa[i], y = bb[i];
    if (/^\d+$/.test(x) && /^\d+$/.test(y)) {
      const nx = parseInt(x, 10), ny = parseInt(y, 10);
      if (nx !== ny) return nx - ny;
      if (x.length !== y.length) return x.length - y.length;
    } else {
      const c = x.localeCompare(y);
      if (c !== 0) return c;
    }
  }
  return aa.length - bb.length || a.localeCompare(b);
}

function visibleEntries(dir: string): string[] {
  return fs.readdirSync(dir)
    .filter((n: string) => !n.startsWith("."))
    .filter((n: string) => n !== "executable" && n !== "compile.sh" && n !== "dist" && n !== "src" && n !== "tsconfig.json" && n !== "submission.tar.gz")
    .sort(naturalCompare);
}

function regexEntries(dir: string, sourcePattern: string, opts: Options): string[] {
  const inferred = (sourcePattern.match(/\//g) || []).length;
  const max = opts.depth ?? opts.maxDepth ?? inferred;
  const result: string[] = [];
  function walk(rel: string, depth: number): void {
    const base = rel ? path.resolve(dir, rel) : dir;
    for (const name of fs.readdirSync(base).filter((n: string) => !n.startsWith(".")).sort(naturalCompare)) {
      if (!rel && (name === "executable" || name === "compile.sh" || name === "dist" || name === "src" || name === "tsconfig.json" || name === "submission.tar.gz")) continue;
      const child = rel ? path.join(rel, name) : name;
      result.push(child);
      const full = path.resolve(dir, child);
      if (depth < max && fs.existsSync(full) && fs.statSync(full).isDirectory()) walk(child, depth + 1);
    }
  }
  walk("", 0);
  return result;
}

function splitExt(name: string): { stem: string; ext: string } {
  const base = path.basename(name);
  const idx = base.lastIndexOf(".");
  if (idx <= 0) return { stem: name, ext: "" };
  return { stem: name.slice(0, name.length - (base.length - idx)), ext: base.slice(idx) };
}

function padVal(s: string, width?: number): string {
  if (!width || width <= 0) return s;
  if (!/^\d+$/.test(s)) return s;
  return s.padStart(width, "0");
}

function formatPattern(pattern: string, groups: Record<string, string>, autoStart: number): string {
  let auto = autoStart;
  return pattern.replace(/\{([^{}]*)\}/g, (_m, body: string) => {
    let key = body;
    let width: number | undefined;
    const colon = body.indexOf(":");
    if (colon >= 0) {
      key = body.slice(0, colon);
      const w = body.slice(colon + 1);
      if (w.length > 0) width = parseInt(w, 10);
    }
    let val: string;
    if (key === "" && groups["__index"] !== undefined) {
      val = groups["__index"];
    } else {
      if (key === "") key = String(auto++);
      val = groups[key] ?? "";
    }
    return padVal(String(val), width);
  });
}

function buildGroupsFromMatch(m: RegExpMatchArray): Record<string, string> {
  const g: Record<string, string> = {};
  for (let i = 0; i < m.length; i++) g[String(i)] = m[i] ?? "";
  if (m.groups) {
    for (const k of Object.keys(m.groups)) g[k] = m.groups[k] ?? "";
  }
  return g;
}

function compileRegex(pattern: string): RegExp {
  try {
    const js = pattern.replace(/\(\?P<([A-Za-z_][A-Za-z0-9_]*)>/g, "(?<$1>");
    return new RegExp(js);
  } catch (e: any) {
    fail(`error: ${e && e.message ? e.message : String(e)}`);
  }
}

function planSort(opts: Options, outputPattern: string): RenameItem[] {
  const names = visibleEntries(opts.dir);
  if (opts.sort === "desc") names.reverse();
  return names.map((name, idx) => {
    const { ext } = splitExt(name);
    const out = formatPattern(outputPattern, { "0": name, "1": String(idx + 1), "__index": String(idx + 1) }, idx + 1);
    return { input: name, output: opts.noExtension ? out : out + ext };
  });
}

function planRegex(opts: Options, source: string, outputPattern: string): RenameItem[] {
  const re = compileRegex(source);
  const names = regexEntries(opts.dir, source, opts);
  const out: RenameItem[] = [];
  for (const name of names) {
    const m = name.match(re);
    if (!m) continue;
    const groups = buildGroupsFromMatch(m);
    const { ext } = splitExt(name);
    let target = formatPattern(outputPattern, groups, 1);
    if (!opts.noExtension && ext) target += ext;
    out.push({ input: name, output: target });
  }
  return out;
}

function planMap(opts: Options): RenameItem[] {
  if (!opts.map) return [];
  const raw = fs.readFileSync(path.resolve(opts.dir, opts.map), "utf8");
  const parsed = JSON.parse(raw);
  return Object.keys(parsed).map(k => ({ input: k, output: String(parsed[k]) }));
}

function chooseUnique(dir: string, output: string, overwrite: boolean): string {
  if (overwrite) return output;
  let candidate = output;
  while (fs.existsSync(path.resolve(dir, candidate))) {
    const p = path.parse(candidate);
    candidate = path.join(p.dir, "_" + p.base);
  }
  return candidate;
}

function adjustCollisions(items: RenameItem[], opts: Options): RenameItem[] {
  const planned = new Set<string>();
  return items.map(it => {
    let output = it.output;
    if (!opts.overwrite) {
      while (planned.has(output) || (fs.existsSync(path.resolve(opts.dir, output)) && output !== it.input)) {
        const p = path.parse(output);
        output = path.join(p.dir, "_" + p.base);
      }
    } else {
      output = chooseUnique(opts.dir, output, true);
    }
    planned.add(output);
    return { input: it.input, output };
  });
}

function printTable(items: RenameItem[]): void {
  const inputW = Math.max("Input".length, ...items.map(i => i.input.length));
  const outputW = Math.max("Output".length, ...items.map(i => i.output.length));
  const line = `+${"-".repeat(inputW + 2)}+${"-".repeat(outputW + 2)}+\n`;
  let s = line;
  s += `| ${"Input".padEnd(inputW)} | ${"Output".padEnd(outputW)} |\n`;
  s += line;
  for (const it of items) s += `| ${it.input.padEnd(inputW)} | ${it.output.padEnd(outputW)} |\n`;
  s += line;
  process.stdout.write(s);
}

function renameItems(items: RenameItem[], opts: Options): void {
  const staged: { tmp: string; to: string; input: string; output: string }[] = [];
  for (const it of items) {
    const from = path.resolve(opts.dir, it.input);
    const to = path.resolve(opts.dir, it.output);
    if (opts.mkdir) fs.mkdirSync(path.dirname(to), { recursive: true });
    else if (!fs.existsSync(path.dirname(to))) fail(`error: No such file or directory (os error 2)`);
    if (opts.overwrite && fs.existsSync(to) && from !== to) fs.rmSync(to, { recursive: true, force: true });
    if (from === to) continue;
    const tmp = path.resolve(opts.dir, `.nomino-${process.pid}-${staged.length}`);
    fs.renameSync(from, tmp);
    staged.push({ tmp, to, input: it.input, output: it.output });
  }
  for (const it of staged) {
    fs.renameSync(it.tmp, it.to);
  }
}

function writeGenerate(items: RenameItem[], opts: Options): void {
  if (!opts.generate) return;
  const obj: Record<string, string> = {};
  for (const it of items) obj[it.output] = it.input;
  fs.writeFileSync(path.resolve(opts.dir, opts.generate), JSON.stringify(obj, null, 2) + "\n");
}

function main(): void {
  const opts = parseArgs(process.argv.slice(2));
  let mode: Mode | undefined;
  if (opts.map) mode = "map";
  else if (opts.sort) mode = "sort";
  else if (opts.regex || opts.positionals.length >= 2) mode = "regex";
  if (!mode) fail("error: one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.\nusage: run './executable --help' for more information.");

  let outputPattern: string | undefined;
  let items: RenameItem[];
  if (mode === "map") {
    items = planMap(opts);
  } else if (mode === "sort") {
    outputPattern = opts.positionals[0];
    if (!outputPattern) fail("error: [output-format] output formatter must be set");
    items = planSort(opts, outputPattern);
  } else {
    let source = opts.regex;
    if (opts.positionals.length >= 2) {
      source = opts.positionals[0];
      outputPattern = opts.positionals[1];
    } else {
      outputPattern = opts.positionals[0];
    }
    if (!source) fail("error: one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.\nusage: run './executable --help' for more information.");
    if (!outputPattern) fail("error: [output-format] output formatter must be set");
    items = planRegex(opts, source, outputPattern);
  }
  items = adjustCollisions(items, opts);
  if (!opts.quiet) printTable(items);
  if (!opts.test) renameItems(items, opts);
  writeGenerate(items, opts);
}

main();
