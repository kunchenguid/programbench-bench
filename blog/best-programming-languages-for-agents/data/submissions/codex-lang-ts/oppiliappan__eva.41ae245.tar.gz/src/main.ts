declare const process: any;
declare const require: any;

type AngleUnit = "degree" | "radian" | "gradian";

class CalcError extends Error {
  code: number;
  constructor(message: string, code = 1) {
    super(message);
    this.code = code;
  }
}

type Token =
  | { type: "num"; value: number }
  | { type: "id"; value: string }
  | { type: "op"; value: string }
  | { type: "lp" }
  | { type: "rp" }
  | { type: "comma" }
  | { type: "eof" };

class Lexer {
  private i = 0;
  constructor(private input: string) {}

  tokenize(): Token[] {
    const out: Token[] = [];
    while (this.i < this.input.length) {
      const c = this.input[this.i];
      if (/\s/.test(c)) {
        this.i++;
      } else if (/[0-9.]/.test(c)) {
        out.push(this.number());
      } else if (/[A-Za-z_]/.test(c)) {
        out.push(this.ident());
      } else if (c === "(") {
        out.push({ type: "lp" });
        this.i++;
      } else if (c === ")") {
        out.push({ type: "rp" });
        this.i++;
      } else if (c === ",") {
        out.push({ type: "comma" });
        this.i++;
      } else if ("+-*/^".includes(c)) {
        if (c === "*" && this.input[this.i + 1] === "*") {
          out.push({ type: "op", value: "**" });
          this.i += 2;
        } else {
          out.push({ type: "op", value: c });
          this.i++;
        }
      } else {
        this.i++;
      }
    }
    out.push({ type: "eof" });
    return this.insertImplicitMultiplication(out);
  }

  private number(): Token {
    const start = this.i;
    let seenDot = false;
    while (this.i < this.input.length) {
      const c = this.input[this.i];
      if (c === ".") {
        if (seenDot) break;
        seenDot = true;
        this.i++;
      } else if (/[0-9]/.test(c)) {
        this.i++;
      } else {
        break;
      }
    }
    return { type: "num", value: Number(this.input.slice(start, this.i)) };
  }

  private ident(): Token {
    const start = this.i;
    while (this.i < this.input.length && /[A-Za-z0-9_]/.test(this.input[this.i])) this.i++;
    return { type: "id", value: this.input.slice(start, this.i).toLowerCase() };
  }

  private insertImplicitMultiplication(tokens: Token[]): Token[] {
    const out: Token[] = [];
    for (let i = 0; i < tokens.length - 1; i++) {
      const a = tokens[i];
      const b = tokens[i + 1];
      out.push(a);
      const left = a.type === "num" || a.type === "rp" || a.type === "id";
      const right = b.type === "num" || b.type === "lp" || b.type === "id";
      const funcCall = a.type === "id" && b.type === "lp";
      if (left && right && !funcCall) out.push({ type: "op", value: "*" });
    }
    out.push(tokens[tokens.length - 1]);
    return out;
  }
}

class Parser {
  private pos = 0;
  constructor(private tokens: Token[], private angle: AngleUnit, private prev: number) {}

  parse(): number {
    const v = this.expr();
    if (this.peek().type !== "eof" && this.peek().type !== "rp") {
      throw new CalcError("Parser Error: Too many operators, too few operands");
    }
    if (!Number.isFinite(v)) {
      if (Number.isNaN(v)) throw new CalcError("Domain Error: Out of bounds!");
      throw new CalcError("Math Error: Divide by zero error!");
    }
    return v;
  }

  private expr(): number {
    let v = this.term();
    while (this.matchOp("+") || this.matchOp("-")) {
      const op = (this.tokens[this.pos - 1] as any).value;
      const r = this.term();
      v = op === "+" ? v + r : v - r;
    }
    return v;
  }

  private term(): number {
    let v = this.power();
    while (this.matchOp("*") || this.matchOp("/")) {
      const op = (this.tokens[this.pos - 1] as any).value;
      const r = this.power();
      if (op === "/" && r === 0) throw new CalcError("Math Error: Divide by zero error!");
      v = op === "*" ? v * r : v / r;
    }
    return v;
  }

  private power(): number {
    const v = this.unary();
    if (this.matchOp("^") || this.matchOp("**")) {
      return Math.pow(v, this.power());
    }
    return v;
  }

  private unary(): number {
    if (this.matchOp("+")) return this.unary();
    if (this.matchOp("-")) return -this.unary();
    return this.primary();
  }

  private primary(): number {
    const t = this.peek();
    if (t.type === "num") {
      this.pos++;
      return t.value;
    }
    if (t.type === "lp") {
      this.pos++;
      const v = this.expr();
      if (this.peek().type === "rp") this.pos++;
      return v;
    }
    if (t.type === "id") {
      this.pos++;
      if (t.value === "pi") return Math.PI;
      if (t.value === "e") return Math.E;
      if (t.value === "_") return this.prev;
      if (this.peek().type !== "lp") throw new CalcError(`Syntax Error: Function '${t.value}' expected parentheses`);
      this.pos++;
      const args: number[] = [];
      if (this.peek().type !== "rp" && this.peek().type !== "eof") {
        args.push(this.expr());
        while (this.peek().type === "comma") {
          this.pos++;
          args.push(this.expr());
        }
      }
      if (this.peek().type === "rp") this.pos++;
      return this.call(t.value, args);
    }
    throw new CalcError("Parser Error: Too many operators, too few operands");
  }

  private call(name: string, args: number[]): number {
    const one = () => {
      if (args.length !== 1) throw new CalcError("Parser Error: Too many operators, too few operands");
      return args[0];
    };
    const two = () => {
      if (args.length !== 2) throw new CalcError("Parser Error: Too many operators, too few operands");
      return args as [number, number];
    };
    const trigIn = (x: number) => this.angle === "radian" ? x : x * Math.PI / 180;
    switch (name) {
      case "sin": return Math.sin(trigIn(one()));
      case "cos": return Math.cos(trigIn(one()));
      case "tan": return Math.tan(trigIn(one()));
      case "csc": return 1 / Math.sin(trigIn(one()));
      case "sec": return 1 / Math.cos(trigIn(one()));
      case "cot": return 1 / Math.tan(trigIn(one()));
      case "sinh": return Math.sinh(one());
      case "cosh": return Math.cosh(one());
      case "tanh": return Math.tanh(one());
      case "asin": return Math.asin(one());
      case "acos": return Math.acos(one());
      case "atan": return Math.atan(one());
      case "acsc": return Math.asin(1 / one());
      case "asec": return Math.acos(1 / one());
      case "acot": return Math.atan(1 / one());
      case "ln": return Math.log(one());
      case "log2": return Math.log2(one());
      case "log10": return Math.log10(one());
      case "sqrt": return Math.sqrt(one());
      case "ceil": return Math.ceil(one());
      case "floor": return Math.floor(one());
      case "abs": return Math.abs(one());
      case "log": {
        const [n, b] = two();
        return Math.log(n) / Math.log(b);
      }
      case "nroot": {
        const [n, r] = two();
        return Math.pow(n, 1 / r);
      }
      default:
        throw new CalcError("Parser Error: Too many operators, too few operands");
    }
  }

  private peek(): Token { return this.tokens[this.pos]; }
  private matchOp(op: string): boolean {
    const t = this.peek();
    if (t.type === "op" && t.value === op) {
      this.pos++;
      return true;
    }
    return false;
  }
}

function evalExpr(input: string, angle: AngleUnit, prev: number): number {
  const tokens = new Lexer(input).tokenize();
  return new Parser(tokens, angle, prev).parse();
}

function addCommas(s: string): string {
  const [a, b] = s.split(".");
  const sign = a.startsWith("-") ? "-" : "";
  const body = sign ? a.slice(1) : a;
  return sign + body.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + (b !== undefined ? "." + b : "");
}

function toBase(value: number, base: number): string {
  if (base === 1) {
    const unary = "1".repeat(Math.max(0, Math.floor(Math.abs(value))));
    return unary === "" ? "0.0" : unary + ".0";
  }
  const sign = value < 0 ? "-" : "";
  value = Math.abs(value);
  const digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const intPart = Math.floor(value);
  let n = intPart;
  let int = "";
  if (n === 0) int = "0";
  while (n > 0) {
    int = digits[n % base] + int;
    n = Math.floor(n / base);
  }
  let frac = "";
  let f = value - intPart;
  for (let i = 0; i < 10 && f > 1e-12; i++) {
    f *= base;
    const d = Math.floor(f + 1e-12);
    frac += digits[d];
    f -= d;
  }
  if (frac === "") frac = "0";
  const grouped = sign + int.replace(/\B(?=(.{3})+(?!.))/g, ",") + "." + frac;
  const chars = grouped.padStart(15, " ").split("");
  for (const p of [1, 5, 9]) if (chars[p] === " ") chars[p] = ",";
  return chars.join("");
}

function format(value: number, fix: number, base: number): string {
  if (base === 10) return addCommas(value.toFixed(fix));
  return toBase(value, base);
}

function help(): string {
  return `Calculator REPL similar to bc(1)

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Optional expression string to run eva in command mode

Options:
  -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]
  -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]
  -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]
  -h, --help                     Print help
  -V, --version                  Print version`;
}

function clapError(msg: string, usage = true): never {
  const suffix = usage ? `\n\nFor more information, try '--help'.` : "";
  throw new CalcError(msg + suffix, 2);
}

function parseArgs(argv: string[]) {
  let fix = 10, base = 10, angle: AngleUnit = "degree";
  let input: string | undefined;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const need = (name: string) => {
      if (i + 1 >= argv.length) clapError(`error: a value is required for '${name} <${name === "--fix" || name === "-f" ? "FIX" : name === "--base" || name === "-b" ? "RADIX" : "angle_unit"}>' but none was supplied`);
      return argv[++i];
    };
    if (a === "-h" || a === "--help") { console.log(help()); process.exit(0); }
    else if (a === "-V" || a === "--version") { console.log("eva 0.3.1"); process.exit(0); }
    else if (a === "-f" || a === "--fix") {
      fix = Number(need(a));
      if (!Number.isInteger(fix) || fix < 1 || fix > 64) clapError(`error: invalid value '${fix}' for '--fix <FIX>': ${fix} is not in 1..=64`);
    } else if (a === "-b" || a === "--base") {
      base = Number(need(a));
      if (!Number.isInteger(base) || base < 1 || base > 36) clapError(`error: invalid value '${base}' for '--base <RADIX>': ${base} is not in 1..=36`);
    } else if (a === "-a" || a === "--angle_unit") {
      const v = need(a);
      if (v !== "degree" && v !== "radian" && v !== "gradian") clapError(`error: invalid value '${v}' for '--angle_unit <angle_unit>'`);
      angle = v;
    } else if (a === "--") {
      input = argv.slice(i + 1).join(" ");
      break;
    } else if (a.startsWith("-")) {
      clapError(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [INPUT]`);
    } else if (input === undefined) {
      input = a;
    } else {
      input += " " + a;
    }
  }
  return { fix, base, angle, input };
}

function runOne(input: string, fix: number, base: number, angle: AngleUnit, prev: number): number {
  if (input.trim() === "") return prev;
  const v = evalExpr(input, angle, prev);
  console.log(format(v, fix, base));
  return v;
}

function main() {
  try {
    const { fix, base, angle, input } = parseArgs(process.argv.slice(2));
    if (input !== undefined) {
      runOne(input, fix, base, angle, 0);
      return;
    }
    const fs = require("fs");
    const data = fs.readFileSync(0, "utf8");
    let prev = 0;
    const lines = data.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (i === lines.length - 1 && line === "" && data.endsWith("\n")) continue;
      if (line === "") {
        prev = 0;
        console.log(format(0, fix, base));
        continue;
      }
      if (line === "quit" || line === "exit") {
        try { runOne(line, fix, base, angle, prev); } catch (e) { if (e instanceof CalcError) console.log(e.message); }
        continue;
      }
      try { prev = runOne(line, fix, base, angle, prev); }
      catch (e) { if (e instanceof CalcError) console.log(e.message); else throw e; }
    }
  } catch (e) {
    if (e instanceof CalcError) {
      console.error(e.message);
      process.exit(e.code);
    }
    throw e;
  }
}

main();
