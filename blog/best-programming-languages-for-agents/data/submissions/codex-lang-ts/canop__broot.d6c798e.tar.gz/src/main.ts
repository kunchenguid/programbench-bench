const fs = require("fs");
const path = require("path");
const os = require("os");

type Options = {
  root?: string;
  color: "auto" | "yes" | "no";
  cmd?: string;
  outcmd?: string;
  height?: number;
  maxDepth?: number;
  hidden: boolean;
  onlyFolders: boolean;
  sort?: "count" | "date" | "size" | "type-first" | "type-last" | "none";
  writeDefaultConf?: string;
  printShellFunction?: string;
  setInstallState?: string;
};

const VERSION = "broot 1.54.0";

function writeStdout(s: string): void { process.stdout.write(s); }
function writeStderr(s: string): void { process.stderr.write(s); }

function stripExeName(): string {
  if (process.env.BROOT_ARG0) return process.env.BROOT_ARG0;
  return path.basename(process.argv[1] || "executable");
}

function die(message: string, usage = false): never {
  writeStderr(message + "\n");
  if (usage) writeStderr(`\nUsage: ${stripExeName()} [OPTIONS] [ROOT]\n`);
  process.exit(2);
  throw new Error("unreachable");
}

function needsValue(arg: string): never {
  die(`error: a value is required for '${arg}' but none was supplied`);
}

function invalidValue(opt: string, value: string, extra?: string): never {
  writeStderr(`error: invalid value '${value}' for '${opt}'`);
  if (extra) writeStderr(`\n  ${extra}`);
  writeStderr("\n");
  process.exit(2);
  throw new Error("unreachable");
}

function parseArgs(argv: string[]): Options {
  const opts: Options = { color: "auto", hidden: false, onlyFolders: false };
  const bools = new Set([
    "-d", "--dates", "-D", "--no-dates", "-f", "--only-folders", "-F", "--no-only-folders",
    "--show-root-fs", "-g", "--show-git-info", "-G", "--no-show-git-info", "--git-status",
    "-h", "--hidden", "-H", "--no-hidden", "-i", "--git-ignored", "-I", "--no-git-ignored",
    "-p", "--permissions", "-P", "--no-permissions", "-s", "--sizes", "-S", "--no-sizes",
    "--sort-by-count", "--sort-by-date", "--sort-by-size", "--sort-by-type",
    "--sort-by-type-dirs-first", "--sort-by-type-dirs-last", "--no-sort", "--no-tree", "--tree",
    "-w", "--whale-spotting", "-W", "--no-whale-spotting", "-t", "--trim-root", "-T", "--no-trim-root",
    "--install", "--listen-auto", "--get-root"
  ]);
  const valued = new Set([
    "--conf", "--max-depth", "--outcmd", "--verb-output", "-c", "--cmd", "--color",
    "--height", "--set-install-state", "--print-shell-function", "--listen",
    "--write-default-conf", "--send"
  ]);
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === "--") {
      if (i + 1 < argv.length) opts.root = argv.slice(i + 1).join(" ");
      break;
    }
    let value: string | undefined;
    const eq = a.indexOf("=");
    if (a.startsWith("--") && eq > 0) {
      value = a.slice(eq + 1);
      a = a.slice(0, eq);
    }
    if (a === "--help") {
      printHelp(opts.color);
      process.exit(0);
    }
    if (a === "--version") {
      writeStdout(VERSION + "\n");
      process.exit(0);
    }
    if (a === "-V") die("error: unexpected argument '-V' found\n\n  tip: to pass '-V' as a value, use '-- -V'", true);
    if (bools.has(a)) {
      if (a === "-h" || a === "--hidden" || a === "-w" || a === "--whale-spotting") opts.hidden = true;
      if (a === "-H" || a === "--no-hidden" || a === "-W" || a === "--no-whale-spotting") opts.hidden = false;
      if (a === "-f" || a === "--only-folders") opts.onlyFolders = true;
      if (a === "-F" || a === "--no-only-folders") opts.onlyFolders = false;
      if (a === "--sort-by-count") opts.sort = "count";
      if (a === "--sort-by-date") opts.sort = "date";
      if (a === "--sort-by-size" || a === "-w" || a === "--whale-spotting") opts.sort = "size";
      if (a === "--sort-by-type" || a === "--sort-by-type-dirs-first") opts.sort = "type-first";
      if (a === "--sort-by-type-dirs-last") opts.sort = "type-last";
      if (a === "--no-sort") opts.sort = "none";
      continue;
    }
    if (valued.has(a)) {
      if (value === undefined) {
        if (i + 1 >= argv.length) needsValue(`${a} ${valueName(a)}`);
        value = argv[++i];
      }
      switch (a) {
        case "--color":
          if (!["auto", "yes", "no"].includes(value)) invalidValue("--color <color>", value, "[possible values: auto, yes, no]");
          opts.color = value as Options["color"];
          break;
        case "--height":
          opts.height = parseIntOption("--height <height>", value);
          break;
        case "--max-depth":
          opts.maxDepth = parseIntOption("--max-depth <MAX_DEPTH>", value);
          break;
        case "-c":
        case "--cmd":
          opts.cmd = value;
          break;
        case "--outcmd":
          opts.outcmd = value;
          break;
        case "--write-default-conf":
          opts.writeDefaultConf = value;
          break;
        case "--print-shell-function":
          opts.printShellFunction = value;
          break;
        case "--set-install-state":
          if (!["undefined", "refused", "installed"].includes(value)) {
            invalidValue("--set-install-state <state>", value, "[possible values: undefined, refused, installed]");
          }
          opts.setInstallState = value;
          break;
      }
      continue;
    }
    if (a.startsWith("-")) die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'`, true);
    if (opts.root) die(`error: unexpected argument '${a}' found`, true);
    opts.root = a;
  }
  return opts;
}

function valueName(opt: string): string {
  const names: Record<string, string> = {
    "--print-shell-function": "<shell>",
    "--set-install-state": "<state>",
    "--max-depth": "<MAX_DEPTH>",
    "--write-default-conf": "<path>",
    "--outcmd": "<path>",
    "--height": "<height>",
    "--color": "<color>",
    "--cmd": "<cmd>",
    "-c": "<cmd>"
  };
  return names[opt] || "<value>";
}

function parseIntOption(opt: string, value: string): number {
  if (!/^\d+$/.test(value)) invalidValue(opt, value, "invalid digit found in string");
  return Number(value);
}

function main(): void {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.printShellFunction !== undefined) {
    printShellFunction(opts.printShellFunction);
    return;
  }
  if (opts.writeDefaultConf) {
    copyDefaultConf(opts.writeDefaultConf);
    return;
  }
  if (opts.setInstallState !== undefined) return;
  if (opts.cmd !== undefined) {
    runCommands(opts);
    return;
  }
  if (process.stdout.isTTY && process.stdin.isTTY) {
    printTree(opts);
  } else {
    printTree(opts);
  }
}

function printHelp(_color: string): void {
  writeStdout(`                   broot 1.54.0


broot lets you explore file hierarchies with a
tree-like view, manipulate and preview files,
launch actions, and define your own shortcuts.

broot is best launched as br: this shell function
gives you access to more commands, especially cd.
The br shell function is interactively installed
on first broot launch.

Flags and options can be classically passed on
launch but also written in the configuration file.
Each flag has a counter-flag so that you can
cancel at command line a flag which has been set
in the configuration file.

Complete documentation and tips at
https://dystroy.org/broot

Usage:  broot [options] [ROOT]

• ROOT : Root Directory

Options:
┌────┬────────────────────────────┬──────────────────────────────────────────┐
│short│            long            │description                               │
├────┼────────────────────────────┼──────────────────────────────────────────┤
│    │--help                      │Print help information                    │
│    │--version                   │print the version                         │
│    │--conf <paths>              │Semicolon separated paths to config files │
│-d  │--dates                     │Show the last modified date               │
│-D  │--no-dates                  │Don't show the last modified date         │
│-f  │--only-folders              │Only show folders                         │
│-F  │--no-only-folders           │Show folders and files alike              │
│    │--show-root-fs              │Show filesystem info on top               │
│    │--max-depth <MAX_DEPTH>     │Only show trees up to a certain depth     │
│-g  │--show-git-info             │Show git statuses on files and stats      │
│-G  │--no-show-git-info          │Don't show git statuses                   │
│    │--git-status                │Only show files having git status         │
│-h  │--hidden                    │Show hidden files                         │
│-H  │--no-hidden                 │Don't show hidden files                   │
│-i  │--git-ignored               │Show git ignored files                    │
│-I  │--no-git-ignored            │Don't show git ignored files              │
│-p  │--permissions               │Show permissions                          │
│-P  │--no-permissions            │Don't show permissions                    │
│-s  │--sizes                     │Show the size of files and directories    │
│-S  │--no-sizes                  │Don't show sizes                          │
│    │--sort-by-count             │Sort by count                             │
│    │--sort-by-date              │Sort by date                              │
│    │--sort-by-size              │Sort by size                              │
│    │--sort-by-type              │Same as sort-by-type-dirs-first           │
│    │--sort-by-type-dirs-first   │Sort by type, directories first           │
│    │--sort-by-type-dirs-last    │Sort by type, directories last            │
│    │--no-sort                   │Don't sort                                │
│-w  │--whale-spotting            │Sort by size, show ignored and hidden     │
│-t  │--trim-root                 │Trim the root too                         │
│-T  │--no-trim-root              │Don't trim the root level                 │
│    │--outcmd <path>             │Where to write the produced cmd           │
│-c  │--cmd <cmd>                 │Semicolon separated commands to execute   │
│    │--color <color>             │Whether to have styles and colors         │
│    │                            │ Possible values: [auto, yes, no]         │
│    │--height <height>           │Height                                    │
│    │--install                   │Install or reinstall the br shell function│
│    │--set-install-state <state> │Manually set installation state           │
│    │--print-shell-function <sh> │Print the br function for a shell         │
│    │--write-default-conf <path> │Write default conf files                  │
│    │--send <socket>             │A socket to send commands to              │
└────┴────────────────────────────┴──────────────────────────────────────────┘
`);
}

function printShellFunction(shell: string): void {
  if (shell === "bash" || shell === "zsh") {
    writeStdout(`
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like \`cd\`,
# have no useful effect if executed in a subshell.
function br {
    local cmd cmd_file code
    cmd_file=$(mktemp)
    if broot --outcmd "$cmd_file" "$@"; then
        cmd=$(<"$cmd_file")
        command rm -f "$cmd_file"
        eval "$cmd"
    else
        code=$?
        command rm -f "$cmd_file"
        return "$code"
    fi
}
`);
    return;
  }
  if (shell === "fish") {
    writeStdout(`
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like \`cd\`,
# have no useful effect if executed in a subshell.
function br --wraps=broot
    set -l cmd_file (mktemp)
    if broot --outcmd $cmd_file $argv
        source $cmd_file
        rm -f $cmd_file
    else
        set -l code $status
        rm -f $cmd_file
        return $code
    end
end
`);
    return;
  }
  if (shell === "powershell") {
    writeStdout(`
# https://github.com/Canop/broot/issues/460#issuecomment-1303005689
Function br {
  $args = $args -join ' '
  $cmd_file = New-TemporaryFile
  try {
    $process = Start-Process -FilePath 'broot.exe' -ArgumentList "--outcmd $($cmd_file.FullName) $args" -NoNewWindow -PassThru -WorkingDirectory $PWD
    Wait-Process -InputObject $process
    If ($process.ExitCode -eq 0) {
        $cmd = Get-Content $cmd_file
        If ($cmd -ne $null) { Invoke-Expression -Command $cmd }
    }
  } finally {
    Remove-Item $cmd_file
  }
}
`);
    return;
  }
  if (shell === "nushell") {
    writeStdout(`
# Launch broot
export def --env br [file?: path] {
    let cmd_file = ($nu.temp-path | path join $"broot-(random chars).tmp")
    touch $cmd_file
    if ($file == null) { ^broot --outcmd $cmd_file } else { ^broot --outcmd $cmd_file $file }
    let $cmd = (open $cmd_file)
    rm -p -f $cmd_file
    if (not ($cmd | lines | is-empty)) {
        cd ($cmd | parse -r '^cd\\\\s+(?<path>.+)$' | get path | to text)
    }
}

export extern broot [
    --cmd(-c): string
    --color: string
    --help
    --version
    file?: path
]
`);
    return;
  }
  writeStderr(`Unknown shell: ${shell}\n`);
  process.exit(1);
}

function copyDefaultConf(dest: string): void {
  fs.mkdirSync(dest, { recursive: true });
  const src = path.resolve(__dirname, "..", "resources", "default-conf");
  if (fs.existsSync(src)) {
    copyDir(src, dest);
  } else {
    fs.writeFileSync(path.join(dest, "conf.hjson"), "show_selection_mark: true\n");
    fs.writeFileSync(path.join(dest, "verbs.hjson"), "verbs: []\n");
    fs.mkdirSync(path.join(dest, "skins"), { recursive: true });
    fs.writeFileSync(path.join(dest, "skins", "dark-blue.hjson"), "skin: {}\n");
  }
}

function copyDir(src: string, dest: string): void {
  fs.mkdirSync(dest, { recursive: true });
  for (const name of fs.readdirSync(src)) {
    const s = path.join(src, name);
    const d = path.join(dest, name);
    const st = fs.lstatSync(s);
    if (st.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}

function runCommands(opts: Options): void {
  const sep = process.env.BROOT_CMD_SEPARATOR || ";";
  const commands = (opts.cmd || "").split(sep).map((s: string) => s.trim()).filter(Boolean);
  const root = resolveRoot(opts.root);
  let selected = root;
  for (const c0 of commands) {
    const c = c0.startsWith(":") ? c0.slice(1) : c0;
    if (["q", "quit"].includes(c)) return;
    if (["pt", "print_tree"].includes(c)) {
      printTree({ ...opts, root });
      return;
    }
    if (["pp", "print_path"].includes(c)) {
      writeStdout(selected + "\n");
      return;
    }
    if (["cd"].includes(c)) {
      const dir = directoryFor(selected);
      if (opts.outcmd) fs.writeFileSync(opts.outcmd, `cd ${shellQuote(dir)}\n`);
      return;
    }
    if (c.startsWith("focus ")) {
      selected = resolveRoot(c.slice(6).trim());
      continue;
    }
    const match = findFirst(root, c.replace(/^\/|\/$/g, ""), opts);
    if (match) selected = match;
  }
}

function resolveRoot(root?: string): string {
  const r = root || process.cwd();
  return path.resolve(r.replace(/^~(?=\/|$)/, os.homedir()));
}

function directoryFor(p: string): string {
  try {
    return fs.statSync(p).isDirectory() ? p : path.dirname(p);
  } catch {
    return p;
  }
}

function shellQuote(s: string): string {
  if (/^[A-Za-z0-9_/:.,@%+=-]+$/.test(s)) return s;
  return "'" + s.replace(/'/g, "'\\''") + "'";
}

function findFirst(root: string, pattern: string, opts: Options): string | undefined {
  if (!pattern) return root;
  const stack = [root];
  const low = pattern.toLowerCase();
  while (stack.length) {
    const p = stack.shift()!;
    if (path.basename(p).toLowerCase().includes(low) || p.toLowerCase().includes(low)) return p;
    try {
      for (const e of fs.readdirSync(p)) {
        if (!opts.hidden && e.startsWith(".")) continue;
        const child = path.join(p, e);
        if (fs.statSync(child).isDirectory()) stack.push(child);
      }
    } catch {}
  }
  return undefined;
}

function printTree(opts: Options): void {
  const root = resolveRoot(opts.root);
  const lines: string[] = [root];
  walk(root, "", 0, opts, lines);
  const h = opts.height && opts.height > 0 ? opts.height : undefined;
  writeStdout((h ? lines.slice(0, h) : lines).join("\n") + "\n");
}

function walk(dir: string, prefix: string, depth: number, opts: Options, lines: string[]): void {
  if (opts.maxDepth !== undefined && depth >= opts.maxDepth) return;
  let entries: { name: string; full: string; stat: any }[] = [];
  try {
    entries = fs.readdirSync(dir).map((name: string) => {
      const full = path.join(dir, name);
      let stat: any;
      try { stat = fs.lstatSync(full); } catch { stat = undefined; }
      return { name, full, stat };
    }).filter((e: any) => {
      if (!e.stat) return false;
      if (!opts.hidden && e.name.startsWith(".")) return false;
      if (opts.onlyFolders && !e.stat.isDirectory()) return false;
      return true;
    });
  } catch {
    return;
  }
  sortEntries(entries, opts);
  entries.forEach((e, idx) => {
    const last = idx === entries.length - 1;
    const marker = last ? "└── " : "├── ";
    const slash = e.stat.isDirectory() ? "/" : "";
    lines.push(prefix + marker + e.name + slash);
    if (e.stat.isDirectory()) walk(e.full, prefix + (last ? "    " : "│   "), depth + 1, opts, lines);
  });
}

function sortEntries(entries: any[], opts: Options): void {
  if (opts.sort === "none") return;
  entries.sort((a, b) => {
    if (opts.sort === "date") return b.stat.mtimeMs - a.stat.mtimeMs || a.name.localeCompare(b.name);
    if (opts.sort === "size") return b.stat.size - a.stat.size || a.name.localeCompare(b.name);
    if (opts.sort === "type-last" || opts.sort === "type-first") {
      const ad = a.stat.isDirectory() ? 1 : 0;
      const bd = b.stat.isDirectory() ? 1 : 0;
      if (ad !== bd) return opts.sort === "type-last" ? ad - bd : bd - ad;
    }
    return a.name.localeCompare(b.name);
  });
}

main();
