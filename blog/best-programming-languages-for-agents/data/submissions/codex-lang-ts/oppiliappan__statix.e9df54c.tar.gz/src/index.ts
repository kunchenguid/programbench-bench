#!/usr/bin/env node
declare const require: any;
declare const process: any;
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

type Diag = {
  code: number;
  title: string;
  message: string;
  line: number;
  col: number;
  len: number;
};

const LINTS: [string, string][] = [
  ["W01", "bool_comparison"],
  ["W02", "empty_let_in"],
  ["W03", "manual_inherit"],
  ["W04", "manual_inherit_from"],
  ["W05", "legacy_let_syntax"],
  ["W06", "collapsible_let_in"],
  ["W07", "eta_reduction"],
  ["W08", "useless_parens"],
  ["W10", "empty_pattern"],
  ["W11", "redundant_pattern_bind"],
  ["W12", "unquoted_uri"],
  ["W14", "empty_inherit"],
  ["W17", "deprecated_to_path"],
  ["W18", "bool_simplification"],
  ["W19", "useless_has_attr"],
  ["W20", "repeated_keys"],
  ["W23", "empty_list_concat"],
];

const EXPLAIN: Record<number, string> = {
  1: "## What it does\nChecks for expressions of the form `x == true`, `x != true` and suggests using the variable directly.\n\n## Why is this bad?\nUnnecessary code.\n",
  2: "## What it does\nChecks for `let-in` expressions which create no new bindings.\n\n## Why is this bad?\n`let-in` expressions that create no new bindings are useless.\n",
  3: "## What it does\nChecks for bindings of the form `a = a`.\n\n## Why is this bad?\nIf the aim is to bring attributes from a larger scope into the current scope, prefer an inherit statement.\n",
  4: "## What it does\nChecks for bindings of the form `a = someAttr.a`.\n\n## Why is this bad?\nIf the aim is to extract or bring attributes of an attrset into scope, prefer an inherit statement.\n",
  5: "## What it does\nChecks for legacy-let syntax that was never formalized.\n\n## Why is this bad?\nThis syntax construct is undocumented, refrain from using it.\n",
  6: "## What it does\nChecks for `let-in` expressions whose body is another `let-in` expression.\n\n## Why is this bad?\nUnnecessary code, the `let-in` expressions can be merged.\n",
  7: "## What it does\nChecks for eta-reducible functions.\n\n## Why is this bad?\nOftentimes, eta-reduction results in code that is more natural to read.\n",
  8: "## What it does\nChecks for unnecessary parentheses.\n\n## Why is this bad?\nUnnecessarily parenthesized code is hard to read.\n",
  10: "## What it does\nChecks for an empty variadic pattern: `{...}`, in a function argument.\n",
  11: "## What it does\nChecks for binds of the form `inputs @ { ... }` in function arguments.\n",
  12: "## What it does\nChecks for URI expressions that are not quoted.\n",
  14: "## What it does\nChecks for empty inherit statements.\n",
  17: "## What it does\nChecks for usage of the `toPath` function.\n\n## Why is this bad?\n`toPath` is deprecated.\n",
  18: "## What it does\nChecks for boolean expressions that can be simplified.\n",
  19: "## What it does\nChecks for expressions that use the \"has attribute\" operator: `?`, where the `or` operator would suffice.\n",
  20: "## What it does\nChecks for keys in attribute sets with repetitive keys, and suggests using an attribute set instead.\n",
  23: "## What it does\nChecks for list concatenation with the empty list.\n",
};

function usage(): string {
  return `statix 0.5.8

Akshay <nerdy@peppe.rs>

Lints and suggestions for the Nix programming language

USAGE:
    executable <SUBCOMMAND>

OPTIONS:
    -h, --help       Print help information
    -V, --version    Print version information

SUBCOMMANDS:
    check      Lints and suggestions for the nix programming language
    dump       Dump a sample config to stdout
    explain    Print detailed explanation for a lint warning
    fix        Find and fix issues raised by statix-check
    help       Print this message or the help of the given subcommand(s)
    list       List all available lints
    single     Fix exactly one issue at provided position
`;
}

function subHelp(sub: string): string {
  const map: Record<string, string> = {
    check: `executable-check \n\nLints and suggestions for the nix programming language\n\nUSAGE:\n    executable check [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run check on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -o, --format <FORMAT>       Output format. Supported values: stderr, errfmt [default: stderr]\n    -s, --stdin                 Enable "streaming" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files\n`,
    fix: `executable-fix \n\nFind and fix issues raised by statix-check\n\nUSAGE:\n    executable fix [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run fix on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run               Do not fix files in place, display a diff instead\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -s, --stdin                 Enable "streaming" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files\n`,
    single: `executable-single \n\nFix exactly one issue at provided position\n\nUSAGE:\n    executable single [OPTIONS] --position <POSITION> [TARGET]\n\nARGS:\n    <TARGET>    File to run single-fix on\n\nOPTIONS:\n    -c, --config <CONF_PATH>     Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run                Do not fix files in place, display a diff instead\n    -h, --help                   Print help information\n    -p, --position <POSITION>    Position to attempt a fix at\n    -s, --stdin                  Enable "streaming" mode, accept file on stdin, output diagnostics\n                                 on stdout\n`,
    dump: `executable-dump \n\nDump a sample config to stdout\n\nUSAGE:\n    executable dump\n\nOPTIONS:\n    -h, --help    Print help information\n`,
    list: `executable-list \n\nList all available lints\n\nUSAGE:\n    executable list\n\nOPTIONS:\n    -h, --help    Print help information\n`,
    explain: `executable-explain \n\nPrint detailed explanation for a lint warning\n\nUSAGE:\n    executable explain <TARGET>\n\nARGS:\n    <TARGET>    Warning code to explain\n\nOPTIONS:\n    -h, --help    Print help information\n`,
  };
  return map[sub] || usage();
}

function parseArgs(argv: string[]) {
  const opts: any = { target: ".", format: "stderr", ignore: [], config: ".", stdin: false, dryRun: false, unrestricted: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") { if (argv[i + 1]) opts.target = argv[++i]; continue; }
    if (a === "-s" || a === "--stdin") opts.stdin = true;
    else if (a === "-d" || a === "--dry-run") opts.dryRun = true;
    else if (a === "-u" || a === "--unrestricted") opts.unrestricted = true;
    else if (a === "-o" || a === "--format") opts.format = argv[++i] || "stderr";
    else if (a === "-c" || a === "--config") opts.config = argv[++i] || ".";
    else if (a === "-i" || a === "--ignore") opts.ignore.push(argv[++i] || "");
    else if (a === "-p" || a === "--position") opts.position = argv[++i] || "";
    else if (!a.startsWith("-")) opts.target = a;
  }
  return opts;
}

function loadConfig(p: string) {
  let file = p;
  try {
    if (fs.existsSync(p) && fs.statSync(p).isDirectory()) file = path.join(p, "statix.toml");
  } catch {}
  const cfg = { disabled: new Set<number>(), ignore: [".direnv"] };
  if (!fs.existsSync(file)) return cfg;
  const s = fs.readFileSync(file, "utf8");
  const dis = s.match(/disabled\s*=\s*\[([^\]]*)\]/m);
  if (dis) for (const x of dis[1].match(/['"]([^'"]+)['"]/g) || []) {
    const v = x.slice(1, -1);
    const n = Number(v.replace(/^W/i, ""));
    if (n) cfg.disabled.add(n);
    const found = LINTS.find(([c, name]) => name === v || c === v.toUpperCase());
    if (found) cfg.disabled.add(Number(found[0].slice(1)));
  }
  const ign = s.match(/ignore\s*=\s*\[([^\]]*)\]/m);
  if (ign) cfg.ignore = (ign[1].match(/['"]([^'"]+)['"]/g) || []).map(x => x.slice(1, -1));
  return cfg;
}

function posFromIndex(text: string, idx: number) {
  const before = text.slice(0, idx).split(/\n/);
  return { line: before.length, col: before[before.length - 1].length + 1 };
}

function add(ds: Diag[], text: string, idx: number, code: number, title: string, message: string, len = 1) {
  const p = posFromIndex(text, idx);
  ds.push({ code, title, message, line: p.line, col: p.col, len });
}

function findDiagnostics(text: string, disabled = new Set<number>()): Diag[] {
  const ds: Diag[] = [];
  const scan = (re: RegExp, cb: (m: RegExpExecArray) => void) => {
    let m: RegExpExecArray | null;
    while ((m = re.exec(text))) cb(m);
  };
  if (!disabled.has(3)) scan(/(^|[{\n;]\s*)([A-Za-z_][\w'-]*)\s*=\s*\2\s*;/gm, m => add(ds, text, (m.index + m[1].length), 3, "Assignment instead of inherit", "This assignment is better written with `inherit`", m[0].length - m[1].length));
  if (!disabled.has(4)) scan(/(^|[{\n;]\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'.-]*)\.\2\s*;/gm, m => add(ds, text, m.index + m[1].length, 4, "Assignment instead of inherit from", "This assignment is better written with `inherit`", m[0].length - m[1].length));
  if (!disabled.has(1)) scan(/\b([A-Za-z_][\w'.-]*)\s*(==|!=)\s*(true|false)\b/g, m => add(ds, text, m.index, 1, "Unnecessary comparison with boolean", `Comparing \`${m[1]}\` with boolean literal \`${m[3]}\``, m[0].length));
  if (!disabled.has(2)) scan(/\blet\s+in\b/g, m => add(ds, text, m.index, 2, "This let-in expression has no entries", "This let-in expression has no entries", m[0].length));
  if (!disabled.has(5)) scan(/\blet\s*\{([\s\S]*?)\}/g, m => { if (/\bbody\s*=/.test(m[1])) add(ds, text, m.index, 5, "Prefer `rec` over undocumented `let` syntax", "Prefer `rec` over undocumented `let` syntax", 3); });
  if (!disabled.has(6)) scan(/\blet\b[\s\S]*?\bin\s+\blet\b/g, m => add(ds, text, m.index, 6, "This `let in` expression contains a nested `let in` expression", "This `let in` expression contains a nested `let in` expression", 3));
  if (!disabled.has(7)) scan(/\(([A-Za-z_][\w'-]*)\s*:\s*([A-Za-z_][\w'.-]*)\s+\1\)/g, m => add(ds, text, m.index, 7, "This function is eta-reducible", `Found eta-reduction: \`${m[2]}\``, m[0].length));
  if (!disabled.has(8)) scan(/(^|[\s=:\[\{])\(([A-Za-z_][\w'-]*)\)(?=([\s;\]\)}]|$))/g, m => add(ds, text, m.index + m[1].length, 8, "These parentheses can be omitted", "These parentheses can be omitted", m[2].length + 2));
  if (!disabled.has(10)) scan(/\{\s*\.\.\.\s*\}\s*:/g, m => add(ds, text, m.index, 10, "This pattern is empty, use `_` instead", "This pattern is empty, use `_` instead", m[0].length));
  if (!disabled.has(11)) scan(/\b([A-Za-z_][\w'-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:/g, m => add(ds, text, m.index, 11, "This pattern bind is redundant", `This pattern bind is redundant, use \`${m[1]}\` instead`, m[0].length));
  if (!disabled.has(12)) scan(/(^|[\s=\[\(\{])([A-Za-z][A-Za-z0-9+.-]*:[^\s;"'\]\)\}]+)/g, m => { if (!/^[A-Za-z]:/.test(m[2]) && !m[2].startsWith("builtins:")) add(ds, text, m.index + m[1].length, 12, "This URI should be quoted", "Consider quoting this URI expression", m[2].length); });
  if (!disabled.has(14)) scan(/\binherit\s*;/g, m => add(ds, text, m.index, 14, "This inherit is empty", "This inherit is empty", m[0].length));
  if (!disabled.has(17)) scan(/\bbuiltins\.toPath\b|\btoPath\b/g, m => add(ds, text, m.index, 17, "Found usage of deprecated builtin toPath", "`builtins.toPath` is deprecated, see `:doc builtins.toPath` within the REPL for more", m[0].length));
  if (!disabled.has(18)) scan(/!\s*\(\s*([^)]+?)\s*==\s*([^)]+?)\s*\)/g, m => add(ds, text, m.index, 18, "Boolean expression can be simplified", "Try `!=` instead of `!(... == ...)`", m[0].length));
  if (!disabled.has(19)) scan(/if\s+([A-Za-z_][\w'.-]*)\s+\?\s+([A-Za-z_][\w'-]*)\s+then\s+\1\.\2\s+else\s+([^;\n]+)/g, m => add(ds, text, m.index, 19, "This `if` can use `or`", `Consider using \`${m[1]}.${m[2]} or ${m[3].trim()}\` instead of this \`if\` expression`, m[0].length));
  if (!disabled.has(20)) scan(/([A-Za-z_][\w'-]*)\.([A-Za-z_][\w'-]*)\s*=/g, m => {
    const rest = text.slice(m.index + m[0].length);
    if (new RegExp(`\\b${m[1].replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\.[A-Za-z_][\\w'-]*\\s*=`).test(rest)) add(ds, text, m.index, 20, "Found repeated keys", "This key is repeated; consider an attribute set", m[0].length);
  });
  if (!disabled.has(23)) scan(/\+\+\s*\[\s*\]|\[\s*\]\s*\+\+/g, m => add(ds, text, m.index, 23, "Concatenation with the empty list is a no-op", "Concatenation with the empty list, `[]`, is a no-op", m[0].length));
  return ds.sort((a, b) => a.line - b.line || a.col - b.col || a.code - b.code);
}

function applyFixes(text: string, single?: Diag): string {
  const runAll = !single;
  const codes = new Set(runAll ? [] : [single!.code]);
  const ok = (c: number) => runAll || codes.has(c);
  let out = text;
  if (ok(5)) out = out.replace(/\blet\s*\{([\s\S]*?)\}/g, (_m, body) => {
    if (!/\bbody\s*=/.test(body)) return _m;
    const entries = body.split(";").map((s: string) => s.trim()).filter(Boolean);
    return "rec {\n" + entries.map((e: string) => "  " + e + ";").join("\n") + "\n}.body";
  });
  if (ok(11)) out = out.replace(/\b([A-Za-z_][\w'-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:/g, "$1:");
  if (ok(10)) out = out.replace(/\{\s*\.\.\.\s*\}\s*:/g, "_:");
  if (ok(4)) out = out.replace(/(^|[{\n;]\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'.-]*)\.\2\s*;/gm, "$1inherit ($3) $2;");
  if (ok(3)) out = out.replace(/(^|[{\n;]\s*)([A-Za-z_][\w'-]*)\s*=\s*\2\s*;/gm, "$1inherit $2;");
  if (ok(1)) {
    out = out.replace(/\b([A-Za-z_][\w'.-]*)\s*==\s*true\b/g, "$1");
    out = out.replace(/\b([A-Za-z_][\w'.-]*)\s*!=\s*false\b/g, "$1");
    out = out.replace(/\b([A-Za-z_][\w'.-]*)\s*==\s*false\b/g, "!$1");
    out = out.replace(/\b([A-Za-z_][\w'.-]*)\s*!=\s*true\b/g, "!$1");
  }
  if (ok(18)) out = out.replace(/!\s*\(\s*([^)]+?)\s*==\s*([^)]+?)\s*\)/g, "$1 != $2");
  if (ok(19)) out = out.replace(/if\s+([A-Za-z_][\w'.-]*)\s+\?\s+([A-Za-z_][\w'-]*)\s+then\s+\1\.\2\s+else\s+([^;\n]+)/g, (_m, a, b, c) => `${a}.${b} or ${c.trim()}`);
  if (ok(7)) out = out.replace(/\(([A-Za-z_][\w'-]*)\s*:\s*([A-Za-z_][\w'.-]*)\s+\1\)/g, "$2");
  if (ok(2)) out = out.replace(/\blet\s+in\s+/g, "");
  if (ok(6)) out = out.replace(/\blet([\s\S]*?)\bin\s+\blet\s*/g, "let$1 ");
  if (ok(12)) out = out.replace(/(^|[\s=\[\(\{])([A-Za-z][A-Za-z0-9+.-]*:[^\s;"'\]\)\}]+)/g, (_m, pre, uri) => pre + (/^[A-Za-z]:/.test(uri) ? uri : `"${uri}"`));
  if (ok(14)) out = out.replace(/^\s*inherit\s*;\s*\n?/gm, "");
  if (ok(23)) {
    out = out.replace(/\s*\+\+\s*\[\s*\]/g, "");
    out = out.replace(/\[\s*\]\s*\+\+\s*/g, "");
  }
  if (ok(8)) out = out.replace(/(^|[\s=:\[\{])\(([A-Za-z_][\w'-]*)\)(?=([\s;\]\)}]|$))/g, "$1$2");
  return out;
}

function human(file: string, text: string, d: Diag): string {
  const line = text.split(/\n/)[d.line - 1] ?? "";
  return `[W${String(d.code).padStart(2, "0")}] Warning: ${d.title}\n   ╭─[${file}:${d.line}:${d.col}]\n   │\n ${d.line} │ ${line}\n   · ${" ".repeat(Math.max(0, d.col - 1))}${"─".repeat(Math.max(1, Math.min(d.len, 40)))} ${d.message.replace(/`/g, "")}\n───╯\n`;
}

function collect(target: string, ignores: string[]): string[] {
  const files: string[] = [];
  const skip = (p: string) => ignores.some(i => i && (p.includes(i.replace(/\*/g, "")) || path.basename(p) === i));
  const walk = (p: string) => {
    if (skip(p) || !fs.existsSync(p)) return;
    const st = fs.statSync(p);
    if (st.isDirectory()) for (const e of fs.readdirSync(p)) walk(path.join(p, e));
    else if (p.endsWith(".nix")) files.push(p);
  };
  walk(target);
  return files.sort();
}

function printDiff(file: string, oldText: string, newText: string) {
  if (oldText === newText) return;
  const a = path.join("/tmp", `statix-a-${process.pid}-${Math.random()}`);
  const b = path.join("/tmp", `statix-b-${process.pid}-${Math.random()}`);
  fs.writeFileSync(a, oldText);
  fs.writeFileSync(b, newText);
  const r = spawnSync("diff", ["-u", "--label", file, "--label", `${file} [fixed]`, a, b], { encoding: "utf8" });
  fs.unlinkSync(a); fs.unlinkSync(b);
  process.stdout.write(r.stdout);
}

function pickPosition(ds: Diag[], pos: string): Diag | undefined {
  if (!pos) return ds[0];
  const m = pos.match(/^(\d+)(?::|,)(\d+)$/);
  if (m) {
    const line = Number(m[1]), col = Number(m[2]);
    return ds.find(d => d.line === line && col >= d.col && col <= d.col + Math.max(0, d.len - 1)) ||
      ds.find(d => d.line === line) || ds[0];
  }
  const n = Number(pos);
  if (Number.isFinite(n) && n > 0) return ds[Math.min(ds.length - 1, n - 1)];
  return ds[0];
}

function main() {
  const argv = process.argv.slice(2);
  if (argv.length === 0 || argv[0] === "--help" || argv[0] === "-h") { process.stdout.write(usage()); return; }
  if (argv[0] === "--version" || argv[0] === "-V") { console.log("statix 0.5.8"); return; }
  let sub = argv.shift()!;
  if (sub === "help") { process.stdout.write(argv[0] ? subHelp(argv[0]) : usage()); return; }
  if (argv.includes("--help") || argv.includes("-h")) { process.stdout.write(subHelp(sub)); return; }
  if (sub === "list") { console.log(LINTS.map(x => x.join(" ")).join("\n")); return; }
  if (sub === "dump") { console.log("disabled = []\nignore = ['.direnv']\n"); return; }
  if (sub === "explain") {
    const raw = argv[0] || "";
    const n = Number(raw.replace(/^W/i, ""));
    if (!EXPLAIN[n]) { console.error(`explain error: lint with code \`${n || raw}\` not found`); process.exit(1); }
    process.stdout.write(EXPLAIN[n]);
    return;
  }
  if (!["check", "fix", "single"].includes(sub)) { console.error(`error:  The subcommand '${sub}' wasn't recognized\n\nUSAGE:\n    executable <subcommands>\n\nFor more information try --help`); process.exit(1); }
  const opts = parseArgs(argv);
  const cfg = loadConfig(opts.config);
  const ignores = [...cfg.ignore, ...opts.ignore];
  if (opts.stdin) {
    const text = fs.readFileSync(0, "utf8");
    if (sub === "check") {
      const ds = findDiagnostics(text, cfg.disabled);
      for (const d of ds) process.stdout.write(opts.format === "errfmt" ? `<stdin>>${d.line}:${d.col}:W:${d.code}:${d.message}\n` : human("<stdin>", text, d));
      if (ds.length) process.exit(1);
    } else {
      const ds = findDiagnostics(text, cfg.disabled);
      const fixed = applyFixes(text, sub === "single" ? pickPosition(ds, opts.position) : undefined);
      process.stdout.write(fixed);
    }
    return;
  }
  const files = collect(opts.target, ignores);
  let any = false;
  for (const f of files) {
    const text = fs.readFileSync(f, "utf8");
    const ds = findDiagnostics(text, cfg.disabled);
    if (sub === "check") {
      for (const d of ds) process.stdout.write(opts.format === "errfmt" ? `${f}>${d.line}:${d.col}:W:${d.code}:${d.message}\n` : human(f, text, d));
      if (ds.length) any = true;
    } else {
      const single = sub === "single" ? pickPosition(ds, opts.position) : undefined;
      const fixed = applyFixes(text, single);
      if (fixed !== text) {
        any = true;
        if (opts.dryRun) printDiff(f, text, fixed);
        else fs.writeFileSync(f, fixed);
      }
    }
  }
  if (sub === "check" && any) process.exit(1);
}

main();
