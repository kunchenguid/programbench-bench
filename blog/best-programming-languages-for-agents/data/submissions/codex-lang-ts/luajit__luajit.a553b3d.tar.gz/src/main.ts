declare const require: any;
declare const process: any;
const fs = require("fs");

type LuaValue = any;
type Tok = { type: string; value: string; line: number };

class LuaError extends Error {
  constructor(message: string, public where = "(command line)", public line = 1) {
    super(message);
  }
}

const VERSION = "LuaJIT 2.1.1772570160";

class LuaTable {
  map = new Map<any, any>();
  constructor(items: any[] = [], fields: [any, any][] = []) {
    items.forEach((v, i) => this.map.set(i + 1, v));
    for (const [k, v] of fields) this.map.set(k, v);
    return new Proxy(this, {
      get(target, prop: any) {
        if (prop in target) return (target as any)[prop];
        if (typeof prop === "symbol") return undefined;
        return target.map.get(String(prop));
      },
      set(target, prop: any, value) {
        if (prop in target) (target as any)[prop] = value;
        else target.map.set(String(prop), value);
        return true;
      },
      has(target, prop: any) {
        return prop in target || target.map.has(String(prop));
      }
    });
  }
  get(k: any) { return this.map.get(k) ?? this.map.get(String(k)); }
  set(k: any, v: any) { this.map.set(k, v); }
  len() {
    let n = 0;
    while (this.map.has(n + 1)) n++;
    return n;
  }
  keys() { return Array.from(this.map.keys()); }
}

function truthy(v: any) { return v !== false && v !== null && v !== undefined; }
function luaType(v: any): string {
  if (v === null || v === undefined) return "nil";
  if (v instanceof LuaTable) return "table";
  if (typeof v === "function") return "function";
  if (typeof v === "number") return "number";
  if (typeof v === "boolean") return "boolean";
  if (typeof v === "string") return "string";
  return "userdata";
}
function luaToString(v: any): string {
  if (v === null || v === undefined) return "nil";
  if (v === true) return "true";
  if (v === false) return "false";
  if (v instanceof LuaTable) return "table: 0x" + Math.floor(Math.random() * 0xfffffff).toString(16);
  if (typeof v === "function") return "function: 0x" + Math.floor(Math.random() * 0xfffffff).toString(16);
  return String(v);
}
function arith(a: any, b: any, op: string) {
  a = Number(a); b = Number(b);
  switch (op) {
    case "+": return a + b; case "-": return a - b; case "*": return a * b;
    case "/": return a / b; case "%": return a % b; case "^": return Math.pow(a, b);
  }
}

class Env {
  vals = new Map<string, any>();
  constructor(public parent?: Env) {}
  get(name: string): any {
    if (this.vals.has(name)) return this.vals.get(name);
    if (this.parent) return this.parent.get(name);
    return undefined;
  }
  set(name: string, val: any) {
    if (this.vals.has(name) || !this.parent) this.vals.set(name, val);
    else this.parent.set(name, val);
  }
  local(name: string, val: any = undefined) { this.vals.set(name, val); }
}

class Lexer {
  i = 0; line = 1; toks: Tok[] = [];
  keywords = new Set("and break do else elseif end false for function if in local nil not or repeat return then true until while".split(" "));
  constructor(public src: string) {}
  peek(n = 0) { return this.src[this.i + n] || ""; }
  next() { const c = this.src[this.i++] || ""; if (c === "\n") this.line++; return c; }
  lex(): Tok[] {
    while (this.i < this.src.length) {
      let c = this.peek();
      if (/\s/.test(c)) { this.next(); continue; }
      if (c === "-" && this.peek(1) === "-") {
        this.next(); this.next();
        if (this.peek() === "[" && this.peek(1) === "[") {
          this.next(); this.next();
          while (this.i < this.src.length && !(this.peek() === "]" && this.peek(1) === "]")) this.next();
          this.next(); this.next();
        } else while (this.i < this.src.length && this.peek() !== "\n") this.next();
        continue;
      }
      const line = this.line;
      if (/[A-Za-z_]/.test(c)) {
        let s = "";
        while (/[A-Za-z0-9_]/.test(this.peek())) s += this.next();
        this.toks.push({ type: this.keywords.has(s) ? s : "id", value: s, line });
        continue;
      }
      if (/\d/.test(c) || (c === "." && /\d/.test(this.peek(1)))) {
        let s = "";
        if (c === "0" && /[xX]/.test(this.peek(1))) {
          s += this.next() + this.next();
          while (/[0-9A-Fa-f.]/.test(this.peek())) s += this.next();
        } else {
          while (/[0-9.]/.test(this.peek())) s += this.next();
          if (/[eE]/.test(this.peek())) { s += this.next(); if (/[+-]/.test(this.peek())) s += this.next(); while (/\d/.test(this.peek())) s += this.next(); }
        }
        this.toks.push({ type: "num", value: s, line });
        continue;
      }
      if (c === "\"" || c === "'") {
        const q = this.next(); let s = "";
        while (this.i < this.src.length && this.peek() !== q) {
          c = this.next();
          if (c === "\\") {
            const e = this.next();
            const m: any = { n: "\n", t: "\t", r: "\r", a: "\x07", b: "\b", f: "\f", v: "\v", "\\": "\\", "\"": "\"", "'": "'" };
            s += m[e] ?? e;
          } else s += c;
        }
        this.next();
        this.toks.push({ type: "str", value: s, line });
        continue;
      }
      if (c === "[" && this.peek(1) === "[") {
        this.next(); this.next(); let s = "";
        while (this.i < this.src.length && !(this.peek() === "]" && this.peek(1) === "]")) s += this.next();
        this.next(); this.next();
        this.toks.push({ type: "str", value: s, line });
        continue;
      }
      const two = c + this.peek(1);
      if (["==", "~=", "<=", ">=", ".."].includes(two)) {
        this.i += 2; this.toks.push({ type: two, value: two, line }); continue;
      }
      if (c === "." && this.peek(1) === "." && this.peek(2) === ".") {
        this.i += 3; this.toks.push({ type: "...", value: "...", line }); continue;
      }
      this.next(); this.toks.push({ type: c, value: c, line });
    }
    this.toks.push({ type: "eof", value: "", line: this.line });
    return this.toks;
  }
}

type Expr = any; type Stmt = any;
class Parser {
  i = 0;
  constructor(public toks: Tok[]) {}
  t(n = 0) { return this.toks[this.i + n] || this.toks[this.toks.length - 1]; }
  eat(type?: string) {
    const tok = this.t();
    if (type && tok.type !== type) throw new LuaError(`syntax error near '${tok.value || tok.type}'`, "(command line)", tok.line);
    this.i++; return tok;
  }
  match(...types: string[]) { if (types.includes(this.t().type)) return this.eat(); }
  parseBlock(stop = new Set<string>(["eof"])) {
    const body: Stmt[] = [];
    while (!stop.has(this.t().type)) { if (this.match(";")) continue; body.push(this.statement()); }
    return body;
  }
  statement(): Stmt {
    const tok = this.t();
    if (this.match("local")) {
      if (this.match("function")) {
        const name = this.eat("id").value; return { k: "local", names: [name], vals: [this.funcBody()] };
      }
      const names = [this.eat("id").value]; while (this.match(",")) names.push(this.eat("id").value);
      let vals: Expr[] = []; if (this.match("=")) vals = this.exprList();
      return { k: "local", names, vals };
    }
    if (this.match("function")) {
      const name = this.namePath(); return { k: "assign", vars: [name], vals: [this.funcBody()] };
    }
    if (this.match("if")) {
      const clauses: any[] = [];
      const c = this.expr(); this.eat("then"); clauses.push([c, this.parseBlock(new Set(["elseif", "else", "end"]))]);
      while (this.match("elseif")) { const ec = this.expr(); this.eat("then"); clauses.push([ec, this.parseBlock(new Set(["elseif", "else", "end"]))]); }
      let els: Stmt[] = []; if (this.match("else")) els = this.parseBlock(new Set(["end"]));
      this.eat("end"); return { k: "if", clauses, els };
    }
    if (this.match("while")) {
      const cond = this.expr(); this.eat("do"); const body = this.parseBlock(new Set(["end"])); this.eat("end"); return { k: "while", cond, body };
    }
    if (this.match("repeat")) {
      const body = this.parseBlock(new Set(["until"])); this.eat("until"); return { k: "repeat", body, cond: this.expr() };
    }
    if (this.match("for")) {
      const name = this.eat("id").value;
      if (this.match("=")) {
        const start = this.expr(); this.eat(","); const end = this.expr(); let step: Expr = { k: "num", v: 1 };
        if (this.match(",")) step = this.expr(); this.eat("do");
        const body = this.parseBlock(new Set(["end"])); this.eat("end"); return { k: "fornum", name, start, end, step, body };
      }
      const names = [name]; while (this.match(",")) names.push(this.eat("id").value);
      this.eat("in"); const iter = this.exprList(); this.eat("do"); const body = this.parseBlock(new Set(["end"])); this.eat("end");
      return { k: "forin", names, iter, body };
    }
    if (this.match("return")) return { k: "return", vals: this.t().type === "eof" || this.t().type === "end" ? [] : this.exprList() };
    if (this.match("break")) return { k: "break" };
    if (this.match("do")) { const body = this.parseBlock(new Set(["end"])); this.eat("end"); return { k: "block", body }; }
    const first = this.prefix();
    if (first.k === "call" && !["=", ","].includes(this.t().type)) return { k: "call", call: first };
    const vars = [first]; while (this.match(",")) vars.push(this.prefix());
    this.eat("="); const vals = this.exprList(); return { k: "assign", vars, vals };
  }
  namePath(): Expr {
    let e: Expr = { k: "var", name: this.eat("id").value };
    while (this.match(".")) e = { k: "index", obj: e, idx: { k: "str", v: this.eat("id").value } };
    return e;
  }
  funcBody(): Expr {
    this.eat("("); const params: string[] = []; let vararg = false;
    if (this.t().type !== ")") {
      if (this.match("...")) vararg = true;
      else { params.push(this.eat("id").value); while (this.match(",")) { if (this.match("...")) { vararg = true; break; } params.push(this.eat("id").value); } }
    }
    this.eat(")"); const body = this.parseBlock(new Set(["end"])); this.eat("end");
    return { k: "func", params, vararg, body };
  }
  exprList() { const xs = [this.expr()]; while (this.match(",")) xs.push(this.expr()); return xs; }
  expr(min = 0): Expr {
    let left = this.unary();
    const prec: any = { or: 1, and: 2, "==": 3, "~=": 3, "<": 3, ">": 3, "<=": 3, ">=": 3, "..": 4, "+": 5, "-": 5, "*": 6, "/": 6, "%": 6, "^": 8 };
    while (prec[this.t().type] && prec[this.t().type] >= min) {
      const op = this.eat().type; const right = this.expr(prec[op] + (op === "^" || op === ".." ? 0 : 1));
      left = { k: "bin", op, left, right };
    }
    return left;
  }
  unary(): Expr {
    if (this.match("not")) return { k: "un", op: "not", e: this.unary() };
    if (this.match("-")) return { k: "un", op: "-", e: this.unary() };
    if (this.match("#")) return { k: "un", op: "#", e: this.unary() };
    return this.primary();
  }
  primary(): Expr {
    const tok = this.t();
    if (this.match("num")) return { k: "num", v: tok.value.toLowerCase().startsWith("0x") ? parseInt(tok.value, 16) : Number(tok.value) };
    if (this.match("str")) return { k: "str", v: tok.value };
    if (this.match("nil")) return { k: "nil" };
    if (this.match("true")) return { k: "bool", v: true };
    if (this.match("false")) return { k: "bool", v: false };
    if (this.match("function")) return this.funcBody();
    if (this.match("{")) {
      const items: Expr[] = [], fields: [Expr, Expr][] = [];
      while (this.t().type !== "}") {
        if (this.match("[")) { const k = this.expr(); this.eat("]"); this.eat("="); fields.push([k, this.expr()]); }
        else if (this.t().type === "id" && this.t(1).type === "=") { const k = { k: "str", v: this.eat("id").value }; this.eat("="); fields.push([k, this.expr()]); }
        else items.push(this.expr());
        this.match(",", ";");
      }
      this.eat("}"); return { k: "table", items, fields };
    }
    return this.prefix();
  }
  prefix(): Expr {
    let e: Expr;
    if (this.match("(")) { e = this.expr(); this.eat(")"); }
    else if (this.match("...")) e = { k: "vararg" };
    else e = { k: "var", name: this.eat("id").value };
    while (true) {
      if (this.match(".")) e = { k: "index", obj: e, idx: { k: "str", v: this.eat("id").value } };
      else if (this.match(":")) {
        const obj = e;
        const meth = { k: "str", v: this.eat("id").value };
        this.eat("(");
        const args = this.t().type === ")" ? [] : this.exprList();
        this.eat(")");
        e = { k: "call", fn: { k: "index", obj, idx: meth }, args: [obj].concat(args) };
      }
      else if (this.match("[")) { const idx = this.expr(); this.eat("]"); e = { k: "index", obj: e, idx }; }
      else if (this.t().type === "(") { this.eat("("); const args = this.t().type === ")" ? [] : this.exprList(); this.eat(")"); e = { k: "call", fn: e, args }; }
      else if (this.t().type === "str") e = { k: "call", fn: e, args: [this.primary()] };
      else if (this.t().type === "{") e = { k: "call", fn: e, args: [this.primary()] };
      else break;
    }
    return e;
  }
}

class ReturnSig { constructor(public vals: any[]) {} }
class BreakSig {}

function makeGlobals(stdout: (s: string) => void, stderr: (s: string) => void, argv: string[]) {
  const env = new Env();
  const argt = new LuaTable();
  argv.forEach((v, i) => argt.set(i, v));
  env.local("arg", argt);
  env.local("_VERSION", "Lua 5.1");
  env.local("jit", new LuaTable([], [["version", VERSION], ["arch", "x64"], ["os", "Linux"], ["status", () => [true]]]));
  env.local("print", (...xs: any[]) => stdout(xs.map(luaToString).join("\t") + "\n"));
  env.local("type", luaType); env.local("tostring", luaToString); env.local("tonumber", (x: any, b?: any) => b ? parseInt(String(x), Number(b)) : Number(x));
  env.local("pairs", (t: any) => ({ kind: "pairs", table: t })); env.local("ipairs", (t: any) => ({ kind: "ipairs", table: t }));
  env.local("next", (t: LuaTable, k?: any) => { const keys = t.keys(); const i = k == null ? -1 : keys.findIndex(x => x === k); const nk = keys[i + 1]; return nk === undefined ? null : [nk, t.get(nk)]; });
  env.local("error", (msg: any) => { throw new LuaError(String(msg)); });
  env.local("assert", (v: any, msg = "assertion failed!") => { if (!truthy(v)) throw new LuaError(String(msg)); return v; });
  env.local("pcall", (fn: any, ...args: any[]) => { try { const r = fn(...args); return [true].concat(Array.isArray(r) ? r : [r]); } catch (e: any) { return [false, e.message]; } });
  const math = new LuaTable([], Object.entries({ abs: Math.abs, acos: Math.acos, asin: Math.asin, atan: Math.atan, atan2: Math.atan2, ceil: Math.ceil, cos: Math.cos, deg: (x:number)=>x*180/Math.PI, exp: Math.exp, floor: Math.floor, fmod: (a:number,b:number)=>a%b, log: Math.log, max: Math.max, min: Math.min, pi: Math.PI, pow: Math.pow, rad: (x:number)=>x*Math.PI/180, random: Math.random, sin: Math.sin, sqrt: Math.sqrt, tan: Math.tan }));
  env.local("math", math);
  const stringLib = new LuaTable([], Object.entries({
    len: (s:any)=>String(s).length, lower:(s:any)=>String(s).toLowerCase(), upper:(s:any)=>String(s).toUpperCase(),
    sub:(s:any,i:any,j?:any)=>{ const str=String(s); let a=Number(i); let b=j==null?str.length:Number(j); if(a<0)a=str.length+a+1; if(b<0)b=str.length+b+1; return str.slice(a-1,b); },
    rep:(s:any,n:any)=>String(s).repeat(Number(n)), reverse:(s:any)=>String(s).split("").reverse().join(""),
    byte:(s:any,i=1)=>String(s).charCodeAt(Number(i)-1), char:(...xs:any[])=>xs.map((x:any)=>String.fromCharCode(Number(x))).join(""),
    find:(s:any,p:any)=>{ const i=String(s).indexOf(String(p)); return i<0?null:[i+1,i+String(p).length]; },
    match:(s:any,p:any)=>{ const m=String(s).match(new RegExp(String(p).replace(/%d/g,"\\d").replace(/%w/g,"\\w").replace(/%s/g,"\\s"))); return m?m[0]:null; },
    gsub:(s:any,p:any,r:any)=>String(s).split(String(p)).join(String(r)),
    format:(fmt:any,...xs:any[])=>String(fmt).replace(/%[sdifq]/g,(m:string)=>{ const x=xs.shift(); return m==="%q"?JSON.stringify(String(x)):String(x); })
  }));
  env.local("string", stringLib);
  const tableLib = new LuaTable([], Object.entries({
    insert:(t:LuaTable,pos:any,val?:any)=>{ if(val===undefined){ val=pos; pos=t.len()+1; } for(let i=t.len();i>=pos;i--)t.set(i+1,t.get(i)); t.set(pos,val); },
    concat:(t:LuaTable,sep="")=>{ const a=[]; for(let i=1;i<=t.len();i++)a.push(luaToString(t.get(i))); return a.join(sep); },
    remove:(t:LuaTable,pos?:any)=>{ const p=pos??t.len(); const v=t.get(p); for(let i=p;i<t.len();i++)t.set(i,t.get(i+1)); t.map.delete(t.len()); return v; }
  }));
  env.local("table", tableLib);
  const ioLib = new LuaTable([], Object.entries({
    write: (...xs:any[]) => { stdout(xs.map(luaToString).join("")); },
    read: () => {
      try {
        const data = fs.readFileSync(0, "utf8");
        const line = data.split(/\r?\n/)[0];
        return line.length ? line : null;
      } catch { return null; }
    },
    flush: () => {}
  }));
  env.local("io", ioLib);
  env.local("require", (name: any) => { if (name === "jit") return env.get("jit"); if (name === "math") return math; if (name === "string") return stringLib; if (name === "table") return tableLib; throw new LuaError(`module '${name}' not found`); });
  env.local("dofile", (name: any) => runLua(fs.readFileSync(String(name), "utf8"), env, String(name)));
  env.local("loadstring", (code: any) => () => runLua(String(code), env));
  env.local("os", new LuaTable([], Object.entries({ clock: () => process.uptime(), time: () => Math.floor(Date.now()/1000), date: () => new Date().toString(), exit: (c=0)=>process.exit(Number(c)) })));
  return env;
}

const stringMethods: any = {
  len: (s:any)=>String(s).length, lower:(s:any)=>String(s).toLowerCase(), upper:(s:any)=>String(s).toUpperCase(),
  sub:(s:any,i:any,j?:any)=>{ const str=String(s); let a=Number(i); let b=j==null?str.length:Number(j); if(a<0)a=str.length+a+1; if(b<0)b=str.length+b+1; return str.slice(a-1,b); },
  rep:(s:any,n:any)=>String(s).repeat(Number(n)), reverse:(s:any)=>String(s).split("").reverse().join(""),
  byte:(s:any,i=1)=>String(s).charCodeAt(Number(i)-1), char:(...xs:any[])=>xs.map((x:any)=>String.fromCharCode(Number(x))).join(""),
  find:(s:any,p:any)=>{ const i=String(s).indexOf(String(p)); return i<0?null:[i+1,i+String(p).length]; },
  match:(s:any,p:any)=>{ const m=String(s).match(new RegExp(String(p).replace(/%d/g,"\\d").replace(/%w/g,"\\w").replace(/%s/g,"\\s"))); return m?m[0]:null; },
  gsub:(s:any,p:any,r:any)=>String(s).split(String(p)).join(String(r)),
  format:(fmt:any,...xs:any[])=>String(fmt).replace(/%[sdifq]/g,(m:string)=>{ const x=xs.shift(); return m==="%q"?JSON.stringify(String(x)):String(x); })
};
function getIndex(obj: any, idx: any) {
  if (obj == null) return undefined;
  if (obj instanceof LuaTable) return obj.get(idx);
  if (typeof obj === "string" && stringMethods[idx]) return stringMethods[idx];
  return obj[idx];
}
function setIndex(obj: any, idx: any, val: any) { if (obj instanceof LuaTable) obj.set(idx, val); else obj[idx] = val; }

function evalExpr(e: Expr, env: Env, varargs: any[] = []): any {
  switch (e.k) {
    case "num": case "str": case "bool": return e.v;
    case "nil": return null;
    case "var": return env.get(e.name);
    case "vararg": return varargs;
    case "table": return new LuaTable(e.items.map((x:Expr)=>evalExpr(x,env,varargs)), e.fields.map(([k,v]:any)=>[evalExpr(k,env,varargs), evalExpr(v,env,varargs)]));
    case "index": return getIndex(evalExpr(e.obj, env, varargs), evalExpr(e.idx, env, varargs));
    case "un": { const v = evalExpr(e.e, env, varargs); if (e.op === "not") return !truthy(v); if (e.op === "-") return -Number(v); if (e.op === "#") return v instanceof LuaTable ? v.len() : String(v).length; }
    case "bin": {
      if (e.op === "and") { const l = evalExpr(e.left, env, varargs); return truthy(l) ? evalExpr(e.right, env, varargs) : l; }
      if (e.op === "or") { const l = evalExpr(e.left, env, varargs); return truthy(l) ? l : evalExpr(e.right, env, varargs); }
      const a = evalExpr(e.left, env, varargs), b = evalExpr(e.right, env, varargs);
      if (["+", "-", "*", "/", "%", "^"].includes(e.op)) return arith(a, b, e.op);
      if (e.op === "..") return luaToString(a) + luaToString(b);
      if (e.op === "==") return a === b; if (e.op === "~=") return a !== b;
      if (e.op === "<") return a < b; if (e.op === ">") return a > b; if (e.op === "<=") return a <= b; if (e.op === ">=") return a >= b;
    }
    case "func": return (...args: any[]) => { const fenv = new Env(env); e.params.forEach((p:string,i:number)=>fenv.local(p,args[i])); try { execBlock(e.body, fenv, args.slice(e.params.length)); } catch (r) { if (r instanceof ReturnSig) return r.vals.length <= 1 ? r.vals[0] : r.vals; throw r; } };
    case "call": {
      const fn = evalExpr(e.fn, env, varargs); const args = e.args.flatMap((a:Expr)=>{ const v=evalExpr(a,env,varargs); return Array.isArray(v)&&a.k==="vararg"?v:[v]; });
      if (typeof fn !== "function") throw new LuaError("attempt to call a nil value");
      return fn(...args);
    }
  }
}
function evalList(xs: Expr[], env: Env, varargs: any[] = []) { return xs.flatMap((x,i)=>{ const v=evalExpr(x,env,varargs); return Array.isArray(v)&&i===xs.length-1?v:[v]; }); }
function assign(v: Expr, val: any, env: Env, varargs: any[]) {
  if (v.k === "var") env.set(v.name, val);
  else if (v.k === "index") setIndex(evalExpr(v.obj, env, varargs), evalExpr(v.idx, env, varargs), val);
}
function execBlock(body: Stmt[], env: Env, varargs: any[] = []) {
  for (const s of body) execStmt(s, env, varargs);
}
function execStmt(s: Stmt, env: Env, varargs: any[]) {
  switch (s.k) {
    case "local": { const vals = evalList(s.vals, env, varargs); s.names.forEach((n:string,i:number)=>env.local(n, vals[i])); break; }
    case "assign": { const vals = evalList(s.vals, env, varargs); s.vars.forEach((v:Expr,i:number)=>assign(v, vals[i], env, varargs)); break; }
    case "call": evalExpr(s.call, env, varargs); break;
    case "return": throw new ReturnSig(evalList(s.vals, env, varargs));
    case "break": throw new BreakSig();
    case "block": execBlock(s.body, new Env(env), varargs); break;
    case "if": { for (const [c,b] of s.clauses) if (truthy(evalExpr(c,env,varargs))) { execBlock(b,new Env(env),varargs); return; } execBlock(s.els,new Env(env),varargs); break; }
    case "while": while (truthy(evalExpr(s.cond,env,varargs))) { try { execBlock(s.body,new Env(env),varargs); } catch(e){ if(e instanceof BreakSig) break; throw e; } } break;
    case "repeat": do { try { execBlock(s.body,new Env(env),varargs); } catch(e){ if(e instanceof BreakSig) break; throw e; } } while (!truthy(evalExpr(s.cond,env,varargs))); break;
    case "fornum": { const start=Number(evalExpr(s.start,env,varargs)), end=Number(evalExpr(s.end,env,varargs)), step=Number(evalExpr(s.step,env,varargs)); for(let i=start; step>=0?i<=end:i>=end; i+=step){ const fenv=new Env(env); fenv.local(s.name,i); try{execBlock(s.body,fenv,varargs);}catch(e){if(e instanceof BreakSig)break; throw e;} } break; }
    case "forin": { const it = evalExpr(s.iter[0], env, varargs); if (it?.kind === "pairs" || it?.kind === "ipairs") { const keys = it.kind === "ipairs" ? Array.from({length: it.table.len()},(_,i)=>i+1) : it.table.keys(); for (const k of keys) { const fenv=new Env(env); fenv.local(s.names[0],k); fenv.local(s.names[1],it.table.get(k)); try{execBlock(s.body,fenv,varargs);}catch(e){if(e instanceof BreakSig)break; throw e;} } } break; }
  }
}

function runLua(code: string, env: Env, source = "(command line)") {
  try {
    const ast = new Parser(new Lexer(code).lex()).parseBlock();
    execBlock(ast, env);
    return 0;
  } catch (e: any) {
    if (e instanceof ReturnSig) return 0;
    const msg = e instanceof LuaError ? e.message : e.message || String(e);
    process.stderr.write(`./executable: ${source}:1: ${msg}\n`);
    return 1;
  }
}

function usage() {
  return "usage: ./executable [options]... [script [args]...].\nAvailable options are:\n  -e chunk  Execute string 'chunk'.\n  -l name   Require library 'name'.\n  -b ...    Save or list bytecode.\n  -j cmd    Perform LuaJIT control command.\n  -O[opt]   Control LuaJIT optimizations.\n  -i        Enter interactive mode after executing 'script'.\n  -v        Show version information.\n  -E        Ignore environment variables.\n  --        Stop handling options.\n  -         Execute stdin and stop handling options.\n";
}

function main() {
  const args = process.argv.slice(2);
  let chunks: string[] = [], libs: string[] = [], showVersion = false, script: string | null = null, scriptArgs: string[] = [], interactive = false;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--help" || (a.startsWith("--") && a !== "--")) { process.stdout.write(usage()); return a === "--help" ? 0 : 1; }
    if (a === "--") { script = args[++i] ?? null; scriptArgs = args.slice(i + 1); break; }
    if (a === "-") { script = "-"; scriptArgs = args.slice(i + 1); break; }
    if (!a.startsWith("-") || a === "") { script = a; scriptArgs = args.slice(i + 1); break; }
    if (a === "-v") showVersion = true;
    else if (a === "-i") interactive = true;
    else if (a === "-E") {}
    else if (a === "-b") { process.stderr.write("./executable: unknown luaJIT command or jit.* modules not installed\n"); return 1; }
    else if (a === "-j" || a.startsWith("-j")) {}
    else if (a === "-O" || a.startsWith("-O")) {}
    else if (a === "-e") chunks.push(args[++i] ?? "");
    else if (a.startsWith("-e")) chunks.push(a.slice(2));
    else if (a === "-l") libs.push(args[++i] ?? "");
    else if (a.startsWith("-l")) libs.push(a.slice(2));
    else { process.stdout.write(usage()); return 1; }
  }
  if (showVersion) process.stdout.write(`${VERSION} -- Copyright (C) 2005-2026 Mike Pall. https://luajit.org/\n`);
  const argv = [script ?? (chunks.length ? chunks[0] : "./executable")].concat(scriptArgs);
  const env = makeGlobals((s)=>process.stdout.write(s), (s)=>process.stderr.write(s), argv);
  for (const l of libs) { try { env.get("require")(l); } catch(e:any) { process.stderr.write(`./executable: module '${l}' not found\n`); return 1; } }
  for (const c of chunks) { const rc = runLua(c, env); if (rc) return rc; }
  if (script) {
    let code = "";
    if (script === "-") code = fs.readFileSync(0, "utf8"); else {
      try { code = fs.readFileSync(script, "utf8"); } catch { process.stderr.write(`./executable: cannot open ${script}: No such file or directory\n`); return 1; }
    }
    const rc = runLua(code, env, script); if (rc) return rc;
  } else if (!chunks.length && !showVersion || interactive) {
    process.stdout.write(`${VERSION} -- Copyright (C) 2005-2026 Mike Pall. https://luajit.org/\n`);
    const input = fs.readFileSync(0, "utf8");
    if (input.trim()) return runLua(input, env, "stdin");
  }
  return 0;
}
process.exitCode = main();
