/* eslint-disable no-var */
declare var require: any;
declare var process: any;
declare var Buffer: any;

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const VERSION = 'pigz 2.8';
const HELP = `Usage: pigz [options] [files ...]
  will compress files in place, adding the suffix '.gz'. If no files are
  specified, stdin will be compressed to stdout. pigz does what gzip does,
  but spreads the work over multiple processors and cores when compressing.

Options:
  -0 to -9, -11        Compression level (level 11, zopfli, is much slower)
  --fast, --best       Compression levels 1 and 9 respectively
  -A, --alias xxx      Use xxx as the name for any --zip entry from stdin
  -b, --blocksize mmm  Set compression block size to mmmK (default 128K)
  -c, --stdout         Write all processed output to stdout (won't delete)
  -C, --comment ccc    Put comment ccc in the gzip or zip header
  -d, --decompress     Decompress the compressed input
  -f, --force          Force overwrite, compress .gz, links, and to terminal
  -F  --first          Do iterations first, before block split for -11
  -h, --help           Display a help screen and quit
  -H, --huffman        Use only Huffman coding for compression
  -i, --independent    Compress blocks independently for damage recovery
  -I, --iterations n   Number of iterations for -11 optimization
  -J, --maxsplits n    Maximum number of split blocks for -11
  -k, --keep           Do not delete original file after processing
  -K, --zip            Compress to PKWare zip (.zip) single entry format
  -l, --list           List the contents of the compressed input
  -L, --license        Display the pigz license and quit
  -m, --no-time        Do not store or restore mod time
  -M, --time           Store or restore mod time
  -n, --no-name        Do not store or restore file name or mod time
  -N, --name           Store or restore file name and mod time
  -O  --oneblock       Do not split into smaller blocks for -11
  -p, --processes n    Allow up to n compression threads (default is the
                       number of online processors, or 8 if unknown)
  -q, --quiet          Print no messages, even on error
  -r, --recursive      Process the contents of all subdirectories
  -R, --rsyncable      Input-determined block locations for rsync
  -S, --suffix .sss    Use suffix .sss instead of .gz (for compression)
  -t, --test           Test the integrity of the compressed input
  -U, --rle            Use run-length encoding for compression
  -v, --verbose        Provide more verbose output
  -V  --version        Show the version of pigz
  -Y  --synchronous    Force output file write to permanent storage
  -z, --zlib           Compress to zlib (.zz) instead of gzip format
  --                   All arguments after "--" are treated as files`;

const crcTable = (() => {
  const t: number[] = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf: any): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function dosTime(d: Date): {time: number, date: number} {
  return { time: (d.getSeconds() >> 1) | (d.getMinutes() << 5) | (d.getHours() << 11), date: d.getDate() | ((d.getMonth() + 1) << 5) | ((d.getFullYear() - 1980) << 9) };
}
function readAllStdin(): any { return fs.readFileSync(0); }
function writeAllStdout(buf: any) { fs.writeSync(1, buf); }
function eprint(s: string, quiet = false) { if (!quiet) process.stderr.write(s + '\n'); }
function baseName(p: string): string { return p === '-' ? '-' : path.basename(p); }
function splitEnv(s: string | undefined): string[] {
  if (!s) return [];
  const out: string[] = []; let cur = ''; let quote = ''; let esc = false;
  for (const ch of s) {
    if (esc) { cur += ch; esc = false; continue; }
    if (ch === '\\') { esc = true; continue; }
    if (quote) { if (ch === quote) quote = ''; else cur += ch; continue; }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (/\s/.test(ch)) { if (cur) { out.push(cur); cur = ''; } continue; }
    cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

interface Opts { level: number; stdout: boolean; decompress: boolean; force: boolean; keep: boolean; zip: boolean; zlibFmt: boolean; list: boolean; test: boolean; verbose: number; quiet: boolean; suffix: string; name: boolean; time: boolean; comment?: string; alias?: string; recursive: boolean; strategy: number; files: string[]; }
function defaults(): Opts { return { level: 6, stdout: false, decompress: false, force: false, keep: false, zip: false, zlibFmt: false, list: false, test: false, verbose: 0, quiet: false, suffix: '.gz', name: true, time: true, recursive: false, strategy: zlib.constants.Z_DEFAULT_STRATEGY, files: [] }; }
function parse(argv: string[], prog: string): Opts {
  const opts = defaults(); if (/unpigz/.test(prog)) opts.decompress = true;
  const args = [...splitEnv(process.env.GZIP), ...splitEnv(process.env.PIGZ), ...argv];
  let filesOnly = false;
  const need = (i: number, a: string) => { if (i + 1 >= args.length) throw new Error(`abort: option requires an argument: ${a}`); return args[++i]; };
  for (let i = 0; i < args.length; i++) {
    let a = args[i];
    if (filesOnly || a === '-' || !a.startsWith('-')) { opts.files.push(a); continue; }
    if (a === '--') { filesOnly = true; continue; }
    const longArg = (name: string) => a === `--${name}` || a.startsWith(`--${name}=`);
    const longVal = (name: string) => a.includes('=') ? a.slice(name.length + 3) : need(i, a);
    if (a === '--help') { console.log(HELP); process.exit(0); }
    if (a === '--version') { console.log(VERSION); process.exit(0); }
    if (a === '--license') { license(); process.exit(0); }
    if (a === '--fast') { opts.level = 1; continue; }
    if (a === '--best') { opts.level = 9; continue; }
    if (longArg('alias')) { opts.alias = longVal('alias'); if (!a.includes('=')) i++; continue; }
    if (longArg('blocksize') || longArg('processes') || longArg('iterations') || longArg('maxsplits')) { if (!a.includes('=')) i++; continue; }
    if (longArg('comment')) { opts.comment = longVal('comment'); if (!a.includes('=')) i++; continue; }
    if (longArg('suffix')) { opts.suffix = longVal('suffix'); if (!a.includes('=')) i++; continue; }
    const longMap: any = {stdout:'c', 'to-stdout':'c', decompress:'d', uncompress:'d', force:'f', huffman:'H', independent:'i', keep:'k', zip:'K', list:'l', 'no-time':'m', time:'M', 'no-name':'n', name:'N', quiet:'q', silent:'q', recursive:'r', rsyncable:'R', test:'t', rle:'U', verbose:'v', zlib:'z', first:'F', oneblock:'O', synchronous:'Y'};
    if (a.startsWith('--') && longMap[a.slice(2)]) { setShort(opts, longMap[a.slice(2)]); continue; }
    if (a.startsWith('--')) throw new Error(`abort: invalid option: ${a}`);
    if (a === '-11') { opts.level = 9; continue; }
    for (let j = 1; j < a.length; j++) {
      const ch = a[j];
      if (/[0-9]/.test(ch)) { opts.level = Number(ch); continue; }
      if ('AbCIJpS'.includes(ch)) {
        const rest = a.slice(j + 1); let val = rest || need(i, '-' + ch); if (!rest) i++;
        if (ch === 'A') opts.alias = val; else if (ch === 'C') opts.comment = val; else if (ch === 'S') opts.suffix = val;
        break;
      }
      setShort(opts, ch);
    }
  }
  return opts;
}
function setShort(opts: Opts, ch: string) {
  if (ch === 'c') opts.stdout = true; else if (ch === 'd') opts.decompress = true; else if (ch === 'f') opts.force = true; else if (ch === 'k') opts.keep = true;
  else if (ch === 'K') opts.zip = true; else if (ch === 'z') opts.zlibFmt = true; else if (ch === 'l') opts.list = true; else if (ch === 't') opts.test = true;
  else if (ch === 'v') opts.verbose++; else if (ch === 'q') opts.quiet = true; else if (ch === 'r') opts.recursive = true; else if (ch === 'H') opts.strategy = zlib.constants.Z_HUFFMAN_ONLY;
  else if (ch === 'U') opts.strategy = zlib.constants.Z_RLE; else if (ch === 'n') { opts.name = false; opts.time = false; } else if (ch === 'N') { opts.name = true; opts.time = true; }
  else if (ch === 'm') opts.time = false; else if (ch === 'M') opts.time = true; else if ('iRFYO'.includes(ch)) { /* accepted, ignored */ }
  else if (ch === 'h') { console.log(HELP); process.exit(0); } else if (ch === 'V') { console.log(VERSION); if (opts.verbose) console.log('zlib 1.2.11'); process.exit(0); }
  else if (ch === 'L') { license(); process.exit(0); } else throw new Error(`abort: invalid option: -${ch}`);
}
function license() { console.log('pigz 2.8\nCopyright (C) 2007-2023 Mark Adler\nSubject to the terms of the zlib license.\nNo warranty is provided or implied.'); }

function gzipMake(input: any, opts: Opts, name?: string, mtime?: number): any {
  const def = zlib.deflateRawSync(input, { level: opts.level, strategy: opts.strategy });
  let flags = 0; const parts: any[] = [];
  if (opts.name && name) flags |= 8; if (opts.comment) flags |= 16;
  const hdr = Buffer.alloc(10); hdr[0]=0x1f; hdr[1]=0x8b; hdr[2]=8; hdr[3]=flags; hdr.writeUInt32LE(opts.time && mtime ? mtime : 0,4); hdr[8]=opts.level===9?2:opts.level===1?4:0; hdr[9]=3; parts.push(hdr);
  if (opts.name && name) parts.push(Buffer.from(name.replace(/\0/g,''),'utf8'), Buffer.from([0]));
  if (opts.comment) parts.push(Buffer.from(opts.comment.replace(/\0/g,''),'utf8'), Buffer.from([0]));
  const tail = Buffer.alloc(8); tail.writeUInt32LE(crc32(input),0); tail.writeUInt32LE(input.length >>> 0,4);
  return Buffer.concat([...parts, def, tail]);
}
function zlibMake(input: any, opts: Opts): any { return zlib.deflateSync(input, { level: opts.level, strategy: opts.strategy }); }
function zipMake(input: any, opts: Opts, name: string): any {
  const def = zlib.deflateRawSync(input, { level: opts.level, strategy: opts.strategy });
  const crc = crc32(input); const n = Buffer.from(name || '-', 'utf8'); const c = opts.comment ? Buffer.from(opts.comment, 'utf8') : Buffer.alloc(0);
  const now = dosTime(new Date());
  const local = Buffer.alloc(30); local.writeUInt32LE(0x04034b50,0); local.writeUInt16LE(20,4); local.writeUInt16LE(0,6); local.writeUInt16LE(8,8); local.writeUInt16LE(now.time,10); local.writeUInt16LE(now.date,12); local.writeUInt32LE(crc,14); local.writeUInt32LE(def.length,18); local.writeUInt32LE(input.length,22); local.writeUInt16LE(n.length,26); local.writeUInt16LE(0,28);
  const central = Buffer.alloc(46); central.writeUInt32LE(0x02014b50,0); central.writeUInt16LE(0x031e,4); central.writeUInt16LE(20,6); central.writeUInt16LE(0,8); central.writeUInt16LE(8,10); central.writeUInt16LE(now.time,12); central.writeUInt16LE(now.date,14); central.writeUInt32LE(crc,16); central.writeUInt32LE(def.length,20); central.writeUInt32LE(input.length,24); central.writeUInt16LE(n.length,28); central.writeUInt16LE(0,30); central.writeUInt16LE(c.length,32); central.writeUInt32LE(0,38); central.writeUInt32LE(0,42);
  const off = local.length + n.length + def.length; const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50,0); end.writeUInt16LE(1,8); end.writeUInt16LE(1,10); end.writeUInt32LE(central.length+n.length+c.length,12); end.writeUInt32LE(off,16); end.writeUInt16LE(0,20);
  return Buffer.concat([local,n,def,central,n,c,end]);
}
function parseGzip(buf: any): any {
  if (buf.length < 18 || buf[0] !== 0x1f || buf[1] !== 0x8b || buf[2] !== 8) throw new Error('not in gzip format');
  let p = 10; const flg = buf[3]; let name = ''; let comment = '';
  if (flg & 4) { const xlen = buf.readUInt16LE(p); p += 2 + xlen; }
  if (flg & 8) { const s = p; while (p < buf.length && buf[p]) p++; name = buf.slice(s,p).toString(); p++; }
  if (flg & 16) { const s = p; while (p < buf.length && buf[p]) p++; comment = buf.slice(s,p).toString(); p++; }
  if (flg & 2) p += 2;
  const crc = buf.readUInt32LE(buf.length-8); const size = buf.readUInt32LE(buf.length-4);
  return { header: p, name, comment, mtime: buf.readUInt32LE(4), crc, size, compData: Math.max(0, buf.length - p - 8) };
}
function unzipFirst(buf: any): any {
  if (buf.readUInt32LE(0) !== 0x04034b50) throw new Error('not in zip format');
  const method = buf.readUInt16LE(8), csize = buf.readUInt32LE(18), nlen = buf.readUInt16LE(26), xlen = buf.readUInt16LE(28);
  const p = 30 + nlen + xlen; const data = buf.slice(p, p + csize);
  return method === 0 ? data : zlib.inflateRawSync(data);
}
function inflateAny(buf: any, opts: Opts): any {
  if (opts.zip || (buf.length > 4 && buf.readUInt32LE(0) === 0x04034b50)) return unzipFirst(buf);
  if (opts.zlibFmt) return zlib.inflateSync(buf);
  return zlib.gunzipSync(buf);
}
function outNameForDecompress(file: string, opts: Opts, meta?: any): string {
  if (opts.name && meta && meta.name) return meta.name;
  if (file.endsWith(opts.suffix)) return file.slice(0, -opts.suffix.length);
  if (file.endsWith('.gz') || file.endsWith('.zz')) return file.slice(0, -3);
  if (file.endsWith('.zip')) return file.slice(0, -4);
  return file + '.out';
}
function collectFiles(files: string[], recursive: boolean): string[] {
  const out: string[] = [];
  for (const f of files) {
    try {
      const st = fs.statSync(f);
      if (st.isDirectory()) {
        if (!recursive) { eprint(`executable: ${f} is a directory -- ignored`); continue; }
        for (const ent of fs.readdirSync(f)) out.push(...collectFiles([path.join(f, ent)], true));
      } else out.push(f);
    } catch { out.push(f); }
  }
  return out;
}
function ratio(comp: number, orig: number): string { if (!orig) return '  0.0%'; return (100 - comp * 100 / orig).toFixed(1).padStart(5) + '%'; }
function fmtDate(sec: number): string { const d = sec ? new Date(sec*1000) : new Date(); return d.toLocaleString('en-US', {month:'short', day:'2-digit', hour:'2-digit', minute:'2-digit', hour12:false}).replace(',', '').replace(' 24:', ' 00:'); }
function listFile(file: string, opts: Opts): boolean {
  try {
    const b = fs.readFileSync(file === '-' ? 0 : file); const m = parseGzip(b); const name = m.name || outNameForDecompress(file, opts, m);
    if (opts.verbose) {
      console.log('method    check    timestamp    compressed   original reduced  name');
      console.log(`gzip 8  ${m.crc.toString(16).padStart(8,'0')}  ${fmtDate(m.mtime).padEnd(12)} ${String(m.compData).padStart(10)} ${String(m.size).padStart(10)} ${ratio(m.compData,m.size).padStart(7)}  ${name}`);
    } else {
      console.log('compressed   original reduced  name');
      console.log(`${String(m.compData).padStart(10)} ${String(m.size).padStart(10)} ${ratio(m.compData,m.size).padStart(7)}  ${name}`);
    }
    return true;
  } catch (e: any) { eprint(`executable: skipping: ${file}: ${e.message}`, opts.quiet); return false; }
}
function processOne(file: string, opts: Opts): boolean {
  try {
    const stdin = file === '-';
    if (!stdin && !fs.existsSync(file)) { eprint(`executable: skipping: ${file} does not exist`, opts.quiet); return false; }
    if (opts.list) return listFile(file, opts);
    const input = stdin ? readAllStdin() : fs.readFileSync(file);
    if (opts.decompress || opts.test) {
      const meta = (!opts.zlibFmt && !opts.zip && input[0] === 0x1f) ? parseGzip(input) : undefined;
      const out = inflateAny(input, opts);
      if (opts.test) return true;
      if (opts.stdout || stdin) writeAllStdout(out); else {
        const dest = outNameForDecompress(file, opts, meta);
        if (fs.existsSync(dest) && !opts.force) { eprint(`executable: skipping: ${dest} exists`, opts.quiet); return false; }
        fs.writeFileSync(dest, out); if (!opts.keep) fs.unlinkSync(file);
        if (opts.time && meta && meta.mtime) fs.utimesSync(dest, new Date(), new Date(meta.mtime*1000));
      }
    } else {
      if (!stdin && file.endsWith(opts.suffix) && !opts.force) { eprint(`executable: skipping: ${file} ends with ${opts.suffix}`, opts.quiet); return false; }
      const st = stdin ? undefined : fs.statSync(file); const mtime = st ? Math.floor(st.mtimeMs/1000) : 0;
      let out: any; let dest = '';
      if (opts.zip) { out = zipMake(input, opts, stdin ? (opts.alias || '-') : baseName(file)); dest = file + '.zip'; }
      else if (opts.zlibFmt) { out = zlibMake(input, opts); dest = file + '.zz'; }
      else { out = gzipMake(input, opts, stdin ? undefined : baseName(file), mtime); dest = file + opts.suffix; }
      if (opts.stdout || stdin) writeAllStdout(out); else {
        if (fs.existsSync(dest) && !opts.force) { eprint(`executable: skipping: ${dest} exists`, opts.quiet); return false; }
        fs.writeFileSync(dest, out); if (st) fs.utimesSync(dest, st.atime, st.mtime); if (!opts.keep) fs.unlinkSync(file);
      }
    }
    return true;
  } catch (e: any) { eprint(`executable: ${file}: ${e.message}`, opts.quiet); return false; }
}
function main() {
  try {
    const opts = parse(process.argv.slice(2), path.basename(process.argv[1] || 'pigz'));
    let files = opts.files.length ? opts.files : ['-']; files = collectFiles(files, opts.recursive);
    let ok = true; for (const f of files) if (!processOne(f, opts)) ok = false;
    process.exit(ok ? 0 : 1);
  } catch (e: any) { eprint(`executable: ${e.message}`); process.exit(22); }
}
main();
