declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

type Opts = {
  background: string;
  fillColor: string;
  strokeColor: string;
  fontFamily: string;
  fontSize: number;
  strokeWidth: number;
  scale: number;
  output?: string;
  inline: boolean;
};

type LineEl = { kind: "line"; x1: number; y1: number; x2: number; y2: number; cls: string };
type PolyEl = { kind: "poly"; points: number[]; cls: string };
type RectEl = { kind: "rect"; x: number; y: number; w: number; h: number };
type TextEl = { kind: "text"; x: number; y: number; text: string };
type El = LineEl | PolyEl | RectEl | TextEl;

const defaultOpts = (): Opts => ({
  background: "white",
  fillColor: "black",
  strokeColor: "black",
  fontFamily: "Iosevka Fixed, monospace",
  fontSize: 14,
  strokeWidth: 2,
  scale: 1,
  inline: false,
});

function help() {
  return `svgbob 0.7.6
SvgBobRus is an ascii to svg converter

USAGE:
    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -s               parse an inline string
    -V, --version    Prints version information

OPTIONS:
        --background <background>        backdrop background will be filled with this color (default: 'white')
        --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')
        --font-family <font-family>      text will be rendered with this font (default: 'arial')
        --font-size <font-size>          text will be rendered with this font size (default: 14)
    -o, --output <output>                where to write svg output [default: STDOUT]
        --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor
                                         (default: 1)
        --stroke-color <stroke-color>    stroke color for all lines (default: 'black')
        --stroke-width <stroke-width>    stroke width for all lines (default: 2)

ARGS:
    <input>    svgbob text file or inline string to parse [default: STDIN]

SUBCOMMANDS:
    build    Batch convert files to svg.
    help     Prints this message or the help of the given subcommand(s)
`;
}

function buildHelp() {
  return `executable-build 0.0.1
Batch convert files to svg.

USAGE:
    executable build [OPTIONS]

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -i, --input <input>      set input file pattern like: *.bob or dir/*.bob
    -o, --outdir <outdir>    set dir of svg files
`;
}

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function parseArgs(argv: string[]) {
  const opts = defaultOpts();
  const args: string[] = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = () => argv[++i] ?? "";
    if (a === "-h" || a === "--help") return { mode: "help", opts, args };
    if (a === "-V" || a === "--version") return { mode: "version", opts, args };
    if (a === "-s") opts.inline = true;
    else if (a === "-o" || a === "--output") opts.output = next();
    else if (a === "--background") opts.background = next();
    else if (a === "--fill-color") opts.fillColor = next();
    else if (a === "--stroke-color") opts.strokeColor = next();
    else if (a === "--font-family") opts.fontFamily = next();
    else if (a === "--font-size") opts.fontSize = Number(next());
    else if (a === "--stroke-width") opts.strokeWidth = Number(next());
    else if (a === "--scale") opts.scale = Number(next());
    else args.push(a);
  }
  return { mode: "run", opts, args };
}

function grid(text: string): string[][] {
  const lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  const h = Math.max(1, lines.length);
  const w = Math.max(0, ...lines.map((l: string) => l.length));
  const g: string[][] = [];
  for (let y = 0; y < h; y++) {
    g[y] = [];
    for (let x = 0; x < w; x++) g[y][x] = lines[y]?.[x] ?? " ";
  }
  return g;
}

function ch(g: string[][], x: number, y: number): string {
  return y >= 0 && y < g.length && x >= 0 && x < (g[y]?.length ?? 0) ? g[y][x] : " ";
}

function isH(c: string) { return c === "-" || c === "=" || c === "+" || c === "<" || c === ">"; }
function isV(c: string) { return c === "|" || c === "+" || c === "^" || c === "v"; }
function isTextChar(c: string) { return c !== " " && !"-=|/\\".includes(c); }
const cx = (x: number) => x * 8 + 4;
const cy = (y: number) => y * 16 + 8;

function arrowRight(x: number, y: number): PolyEl {
  return { kind: "poly", points: [x * 8, cy(y) - 4, (x + 1) * 8, cy(y), x * 8, cy(y) + 4], cls: "filled" };
}
function arrowLeft(x: number, y: number): PolyEl {
  return { kind: "poly", points: [(x + 1) * 8, cy(y) - 4, x * 8, cy(y), (x + 1) * 8, cy(y) + 4], cls: "filled" };
}
function arrowUp(x: number, y: number): PolyEl {
  return { kind: "poly", points: [cx(x) - 4, (y + 1) * 16 - 4, cx(x), y * 16, cx(x) + 4, (y + 1) * 16 - 4], cls: "filled" };
}
function arrowDown(x: number, y: number): PolyEl {
  return { kind: "poly", points: [cx(x) - 4, y * 16 + 4, cx(x) + 4, y * 16 + 4, cx(x), (y + 1) * 16], cls: "filled" };
}

function analyze(text: string): { w: number; h: number; elements: El[] } {
  const g = grid(text);
  const h = g.length;
  const w = Math.max(0, ...g.map(r => r.length));
  const used: boolean[][] = Array.from({ length: h }, () => Array(w).fill(false));
  const elements: El[] = [];

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (ch(g, x, y) !== "+") continue;
      let xr = x + 1;
      while (xr < w && (ch(g, xr, y) === "-" || ch(g, xr, y) === "=")) xr++;
      if (xr <= x + 1 || ch(g, xr, y) !== "+") continue;
      let yb = y + 1;
      while (yb < h) {
        if (ch(g, x, yb) === "+" && ch(g, xr, yb) === "+") {
          let ok = true;
          for (let yy = y + 1; yy < yb; yy++) ok = ok && isV(ch(g, x, yy)) && isV(ch(g, xr, yy));
          for (let xx = x + 1; xx < xr; xx++) ok = ok && (ch(g, xx, yb) === "-" || ch(g, xx, yb) === "=");
          if (ok) {
            elements.push({ kind: "rect", x: cx(x), y: cy(y), w: (xr - x) * 8, h: (yb - y) * 16 });
            for (let xx = x; xx <= xr; xx++) { used[y][xx] = true; used[yb][xx] = true; }
            for (let yy = y; yy <= yb; yy++) { used[yy][x] = true; used[yy][xr] = true; }
            break;
          }
        }
        yb++;
      }
    }
  }

  for (let y = 0; y < h; y++) {
    let x = 0;
    while (x < w) {
      if (used[y][x] || !isH(ch(g, x, y)) || ch(g, x, y) === "<" && ch(g, x + 1, y) !== "-") { x++; continue; }
      const start = x;
      let end = x;
      while (end + 1 < w && !used[y][end + 1] && isH(ch(g, end + 1, y))) end++;
      const len = end - start + 1;
      if (len >= 1 && (len > 1 || ch(g, start, y) === "-")) {
        let x1 = ch(g, start, y) === "<" ? (start + 1) * 8 : cx(start) - 4;
        let x2 = ch(g, end, y) === ">" ? end * 8 : cx(end) + 4;
        if (ch(g, start, y) === "+") x1 = cx(start);
        if (ch(g, end, y) === "+") x2 = cx(end);
        if (ch(g, start, y) === "<") elements.push(arrowLeft(start, y));
        elements.push({ kind: "line", x1, y1: cy(y), x2, y2: cy(y), cls: "solid" });
        if (ch(g, end, y) === ">") elements.push(arrowRight(end, y));
        for (let xx = start; xx <= end; xx++) used[y][xx] = true;
      }
      x = end + 1;
    }
  }

  for (let x = 0; x < w; x++) {
    let y = 0;
    while (y < h) {
      if (used[y]?.[x] || !isV(ch(g, x, y))) { y++; continue; }
      const start = y;
      let end = y;
      while (end + 1 < h && !used[end + 1]?.[x] && isV(ch(g, x, end + 1))) end++;
      const len = end - start + 1;
      if (len >= 1 && (len > 1 || ch(g, x, start) === "|")) {
        let y1 = ch(g, x, start) === "^" ? (start + 1) * 16 - 4 : start * 16;
        let y2 = ch(g, x, end) === "v" ? end * 16 + 4 : (end + 1) * 16;
        if (ch(g, x, start) === "^") elements.push(arrowUp(x, start));
        elements.push({ kind: "line", x1: cx(x), y1, x2: cx(x), y2, cls: "solid" });
        if (ch(g, x, end) === "v") elements.push(arrowDown(x, end));
        for (let yy = start; yy <= end; yy++) used[yy][x] = true;
      }
      y = end + 1;
    }
  }

  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const c = ch(g, x, y);
    if (used[y][x]) continue;
    if (c === "/") { elements.push({ kind: "line", x1: (x + 1) * 8, y1: y * 16, x2: x * 8, y2: (y + 1) * 16, cls: "solid" }); used[y][x] = true; }
    else if (c === "\\") { elements.push({ kind: "line", x1: x * 8, y1: y * 16, x2: (x + 1) * 8, y2: (y + 1) * 16, cls: "solid" }); used[y][x] = true; }
  }

  for (let y = 0; y < h; y++) {
    let x = 0;
    while (x < w) {
      while (x < w && (used[y][x] || !isTextChar(ch(g, x, y)))) x++;
      const start = x;
      let s = "";
      while (x < w && !used[y][x] && isTextChar(ch(g, x, y))) s += ch(g, x++, y);
      if (s) elements.push({ kind: "text", x: start * 8 + 2, y: y * 16 + 12, text: s });
    }
  }
  return { w, h, elements };
}

function style(opts: Opts): string {
  return `<style>.svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {
  stroke: ${opts.strokeColor};
  stroke-width: ${opts.strokeWidth};
  stroke-opacity: 1;
  fill-opacity: 1;
  stroke-linecap: round;
  stroke-linejoin: miter;
}

.svgbob text {
  white-space: pre;
  fill: ${opts.strokeColor};
  font-family: ${opts.fontFamily};
  font-size: ${opts.fontSize}px;
}

.svgbob rect.backdrop {
  stroke: none;
  fill: ${opts.background};
}

.svgbob .broken {
  stroke-dasharray: 8;
}

.svgbob .filled {
  fill: ${opts.fillColor};
}

.svgbob .bg_filled {
  fill: ${opts.background};
  stroke-width: 1;
}

.svgbob .nofill {
  fill: ${opts.background};
}

.svgbob .end_marked_arrow {
  marker-end: url(#arrow);
}

.svgbob .start_marked_arrow {
  marker-start: url(#arrow);
}

.svgbob .end_marked_diamond {
  marker-end: url(#diamond);
}

.svgbob .start_marked_diamond {
  marker-start: url(#diamond);
}

.svgbob .end_marked_circle {
  marker-end: url(#circle);
}

.svgbob .start_marked_circle {
  marker-start: url(#circle);
}

.svgbob .end_marked_open_circle {
  marker-end: url(#open_circle);
}

.svgbob .start_marked_open_circle {
  marker-start: url(#open_circle);
}

.svgbob .end_marked_big_open_circle {
  marker-end: url(#big_open_circle);
}

.svgbob .start_marked_big_open_circle {
  marker-start: url(#big_open_circle);
}

</style>`;
}

function defs() {
  return `  <defs>
    <marker id="arrow" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,0 0,4 4,2 0,0"></polygon>
    </marker>
    <marker id="diamond" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,2 2,0 4,2 2,4 0,2"></polygon>
    </marker>
    <marker id="circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="filled"></circle>
    </marker>
    <marker id="open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="bg_filled"></circle>
    </marker>
    <marker id="big_open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="3" class="bg_filled"></circle>
    </marker>
  </defs>`;
}

function num(n: number): string { return Number.isInteger(n) ? String(n) : String(n); }
function sc(n: number, opts: Opts): string { return num(n * opts.scale); }

function render(text: string, opts: Opts): string {
  const a = analyze(text);
  const width = (a.w + 1) * 8 * opts.scale;
  const height = (a.h + 1) * 16 * opts.scale;
  const out: string[] = [];
  out.push(`<svg xmlns="http://www.w3.org/2000/svg" width="${num(width)}" height="${num(height)}" class="svgbob">`);
  out.push("  " + style(opts));
  out.push(defs());
  out.push(`  <rect class="backdrop" x="0" y="0" width="${num(width)}" height="${num(height)}"></rect>`);
  for (const e of a.elements) {
    if (e.kind === "line") out.push(`  <line x1="${sc(e.x1, opts)}" y1="${sc(e.y1, opts)}" x2="${sc(e.x2, opts)}" y2="${sc(e.y2, opts)}" class="${e.cls}"></line>`);
    else if (e.kind === "poly") {
      const pts: string[] = [];
      for (let i = 0; i < e.points.length; i += 2) pts.push(`${sc(e.points[i], opts)},${sc(e.points[i + 1], opts)}`);
      out.push(`  <polygon points="${pts.join(" ")}" class="${e.cls}"></polygon>`);
    } else if (e.kind === "rect") out.push(`  <rect x="${sc(e.x, opts)}" y="${sc(e.y, opts)}" width="${sc(e.w, opts)}" height="${sc(e.h, opts)}" class="solid nofill" rx="0"></rect>`);
    else out.push(`  <text x="${sc(e.x, opts)}" y="${sc(e.y, opts)}" >${esc(e.text)}</text>`);
  }
  out.push("</svg>");
  return out.join("\n") + "\n";
}

function readInput(args: string[], opts: Opts): string {
  if (opts.inline) return args.join(" ");
  if (args[0]) return fs.readFileSync(args[0], "utf8");
  return fs.readFileSync(0, "utf8");
}

function globFiles(pattern: string): string[] {
  if (!pattern) return [];
  if (!pattern.includes("*")) return [pattern];
  const dir = path.dirname(pattern);
  const base = path.basename(pattern);
  const re = new RegExp("^" + base.split("*").map((p: string) => p.replace(/[.+?^${}()|[\]\\]/g, "\\$&")).join(".*") + "$");
  return fs.readdirSync(dir === "." ? process.cwd() : dir).filter((f: string) => re.test(f)).map((f: string) => path.join(dir, f));
}

function runBuild(argv: string[]) {
  let input = "";
  let outdir = "";
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "-h" || argv[i] === "--help") { process.stdout.write(buildHelp()); return; }
    if (argv[i] === "-V" || argv[i] === "--version") { process.stdout.write("executable-build 0.0.1\n"); return; }
    if (argv[i] === "-i" || argv[i] === "--input") input = argv[++i] ?? "";
    else if (argv[i] === "-o" || argv[i] === "--outdir") outdir = argv[++i] ?? "";
  }
  fs.mkdirSync(outdir || ".", { recursive: true });
  for (const f of globFiles(input)) {
    const svg = render(fs.readFileSync(f, "utf8"), defaultOpts());
    const dest = path.join(outdir || ".", path.basename(f, path.extname(f)) + ".svg");
    fs.writeFileSync(dest, svg);
    process.stdout.write(`${f} => ${dest}\n`);
  }
}

function main() {
  const argv = process.argv.slice(2);
  if (argv[0] === "build") return runBuild(argv.slice(1));
  if (argv[0] === "help" && argv[1] === "build") { process.stdout.write(buildHelp()); return; }
  if (argv[0] === "help") { process.stdout.write(help()); return; }
  const parsed = parseArgs(argv);
  if (parsed.mode === "help") { process.stdout.write(help()); return; }
  if (parsed.mode === "version") { process.stdout.write("svgbob 0.7.6\n"); return; }
  const svg = render(readInput(parsed.args, parsed.opts), parsed.opts);
  if (parsed.opts.output) fs.writeFileSync(parsed.opts.output, svg);
  else process.stdout.write(svg);
}

main();
