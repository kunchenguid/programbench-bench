declare const require: any;
declare const process: any;
const fs = require("fs");
const path = require("path");

type HNode = TextNode | ElementNode;
type TextNode = { type: "text"; text: string };
type ElementNode = { type: "element"; tag: string; attrs: Record<string, string>; children: HNode[] };

type Options = {
  input?: string;
  output?: string;
  overwrite: boolean;
  domain?: string;
  include?: string;
  exclude?: string;
  strong: string;
  strike: boolean;
  table: boolean;
  tablePadding: "aligned" | "minimal" | "none";
  tableHeaderPromotion: boolean;
  tableNewline: "skip" | "preserve";
  tablePresentation: boolean;
  tableSkipEmptyRows: boolean;
  tableSpan: "empty" | "mirror";
};

const voidTags = new Set(["area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"]);
const blockTags = new Set(["address", "article", "aside", "blockquote", "body", "center", "dd", "details", "dialog", "dir", "div", "dl", "dt", "fieldset", "figcaption", "figure", "footer", "form", "frame", "frameset", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hr", "html", "iframe", "legend", "li", "main", "menu", "nav", "noframes", "ol", "p", "pre", "section", "table", "tbody", "td", "tfoot", "th", "thead", "tr", "ul"]);

function usage(): string {
  return `
# html2markdown - convert html to markdown [version dev]

Convert HTML to Markdown. Even works with entire websites!

## Basics

By default the "Commonmark" Plugin will be enabled. You can customize the options,
for example changing the appearance of bold with --opt-strong-delimiter="__"

Other Plugins can also be enabled. For example "GitHub Flavored Markdown" (GFM)
extends Commonmark with more features.

## Relative / Absolute Links

Use --domain="https://example.com" to convert *relative* links to *absolute* links.
The same also works for images.

## Escaping

Some characters have a special meaning in markdown. The library escapes these — if necessary.
See the documentation for more info.

## Security

Once you convert this markdown *back* to HTML you need to be careful of malicious content. 
Use a HTML sanitizer before displaying the HTML in the browser!


## Examples

    echo "<strong>important</strong>" | html2markdown

    curl --no-progress-meter http://example.com | html2markdown


    html2markdown --input file.html --output file.md

    html2markdown --input "src/*.html" --output "dist/"


## Flags

    -v, --version
        show the version of html2markdown and exit

    --help

    --input PATH
        Input file, directory, or glob pattern (instead of stdin)

    --output PATH
        Output file or directory (instead of stdout)

    --output-overwrite
        Replace existing files

    If --input is a directory or glob pattern, --output must be a directory.



    --domain
        The url of the web page, used to convert relative links to absolute links.

    --exclude-selector
        css query selector to exclude parts of the input

    --include-selector
        css query selector to only include parts of the input

    --opt-strong-delimiter
        Make bold text. Should <strong> be indicated by two asterisks or two underscores?
        "**" or "__" (default: "**")

    --opt-table-cell-padding-behavior
        [for --plugin-table] whether cells in the tables should include extra padding for visual continuity: "aligned", "minimal", or "none"

    --opt-table-header-promotion
        [for --plugin-table] first row should be treated as a header

    --opt-table-newline-behavior
        [for --plugin-table] how tables containing newlines should be handled: "skip" or "preserve"

    --opt-table-presentation-tables
        [for --plugin-table] whether tables with role="presentation" should be converted

    --opt-table-skip-empty-rows
        [for --plugin-table] omit empty rows from the output

    --opt-table-span-cell-behavior
        [for --plugin-table] how colspan/rowspan should be rendered: "empty" or "mirror"

    --plugin-strikethrough
        enable the plugin ~~strikethrough~~

    --plugin-table
        enable the plugin table



For more information visit the documentation:
https://github.com/Johanneskaufmann/html-to-markdown
`;
}

function version(): string {
  return "html2markdown\n\nGitVersion:  dev\nGitCommit:   none\nBuildDate:   unknown";
}

function parseArgs(argv: string[]): Options | "help" | "version" {
  const o: Options = { overwrite: false, strong: "**", strike: false, table: false, tablePadding: "aligned", tableHeaderPromotion: false, tableNewline: "skip", tablePresentation: false, tableSkipEmptyRows: false, tableSpan: "empty" };
  const needsValue = new Set(["--input", "--output", "--domain", "--exclude-selector", "--include-selector", "--opt-strong-delimiter", "--opt-table-cell-padding-behavior", "--opt-table-newline-behavior", "--opt-table-span-cell-behavior"]);
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    let v: string | undefined;
    if (a.includes("=") && a.startsWith("--")) {
      const p = a.indexOf("=");
      v = a.slice(p + 1);
      a = a.slice(0, p);
    } else if (needsValue.has(a)) {
      v = argv[++i];
    }
    switch (a) {
      case "--help": return "help";
      case "-v":
      case "--version": return "version";
      case "--input": o.input = v; break;
      case "--output": o.output = v; break;
      case "--output-overwrite": o.overwrite = true; break;
      case "--domain": o.domain = v; break;
      case "--exclude-selector": o.exclude = v; break;
      case "--include-selector": o.include = v; break;
      case "--opt-strong-delimiter": o.strong = v === "__" ? "__" : "**"; break;
      case "--plugin-strikethrough": o.strike = true; break;
      case "--plugin-table": o.table = true; break;
      case "--opt-table-cell-padding-behavior": if (v === "minimal" || v === "none") o.tablePadding = v; break;
      case "--opt-table-header-promotion": o.tableHeaderPromotion = true; break;
      case "--opt-table-newline-behavior": if (v === "preserve") o.tableNewline = v; break;
      case "--opt-table-presentation-tables": o.tablePresentation = true; break;
      case "--opt-table-skip-empty-rows": o.tableSkipEmptyRows = true; break;
      case "--opt-table-span-cell-behavior": if (v === "mirror") o.tableSpan = v; break;
      default:
        if (a.startsWith("-")) die(`unknown flag: ${a}`);
        o.input = a;
    }
  }
  return o;
}

function die(msg: string) {
  process.stderr.write(`\nerror: ${msg}\n\n`);
  process.exit(1);
}

function decodeEntities(s: string): string {
  const named: Record<string, string> = { amp: "&", quot: "\"", apos: "'", lt: "&lt;", gt: "&gt;", nbsp: "\u00a0", copy: "\u00a9", reg: "\u00ae", mdash: "\u2014", ndash: "\u2013", hellip: "\u2026" };
  return s.replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z][a-zA-Z0-9]+);/g, (_, e) => {
    if (e[0] === "#") {
      const n = e[1]?.toLowerCase() === "x" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(n) ? String.fromCodePoint(n) : _;
    }
    return named[e] ?? _;
  });
}

function parseAttrs(s: string): Record<string, string> {
  const attrs: Record<string, string> = {};
  const re = /([:@\w.-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s))) attrs[m[1].toLowerCase()] = decodeEntities(m[2] ?? m[3] ?? m[4] ?? "");
  return attrs;
}

function parseHtml(html: string): ElementNode {
  const root: ElementNode = { type: "element", tag: "root", attrs: {}, children: [] };
  const stack: ElementNode[] = [root];
  const re = /<!--[\s\S]*?-->|<!\[CDATA\[[\s\S]*?\]\]>|<![^>]*>|<[^>]+>/g;
  let last = 0, m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    if (m.index > last) stack[stack.length - 1].children.push({ type: "text", text: decodeEntities(html.slice(last, m.index)) });
    const tok = m[0];
    if (tok.startsWith("<!--") || tok.startsWith("<!")) {
      last = re.lastIndex;
      continue;
    }
    if (/^<\s*\//.test(tok)) {
      const tag = tok.replace(/^<\s*\//, "").replace(/\s*>$/, "").trim().toLowerCase();
      for (let i = stack.length - 1; i > 0; i--) {
        if (stack[i].tag === tag) {
          stack.length = i;
          break;
        }
      }
    } else {
      const inner = tok.slice(1, -1);
      const self = /\/\s*$/.test(inner);
      const mm = inner.trim().match(/^([^\s/>]+)([\s\S]*)$/);
      if (mm) {
        const tag = mm[1].toLowerCase();
        const el: ElementNode = { type: "element", tag, attrs: parseAttrs(mm[2] || ""), children: [] };
        stack[stack.length - 1].children.push(el);
        if (!self && !voidTags.has(tag)) stack.push(el);
      }
    }
    last = re.lastIndex;
  }
  if (last < html.length) stack[stack.length - 1].children.push({ type: "text", text: decodeEntities(html.slice(last)) });
  return root;
}

function selectNodes(root: ElementNode, selector?: string): HNode[] {
  if (!selector) return root.children;
  const sels = selector.split(",").map(s => s.trim()).filter(Boolean);
  const out: HNode[] = [];
  const visit = (n: HNode) => {
    if (n.type === "element") {
      if (sels.some(s => matches(n, s))) out.push(n);
      n.children.forEach(visit);
    }
  };
  root.children.forEach(visit);
  return out;
}

function matches(n: ElementNode, sel: string): boolean {
  if (sel.startsWith("#")) return n.attrs.id === sel.slice(1);
  if (sel.startsWith(".")) return (n.attrs.class || "").split(/\s+/).includes(sel.slice(1));
  const m = sel.match(/^([a-zA-Z0-9_-]+)?(?:\.([a-zA-Z0-9_-]+))?(?:#([a-zA-Z0-9_-]+))?$/);
  if (!m) return false;
  if (m[1] && n.tag !== m[1].toLowerCase()) return false;
  if (m[2] && !(n.attrs.class || "").split(/\s+/).includes(m[2])) return false;
  if (m[3] && n.attrs.id !== m[3]) return false;
  return true;
}

function removeMatches(n: ElementNode, selector?: string) {
  if (!selector) return;
  n.children = n.children.filter(c => !(c.type === "element" && selector.split(",").some(s => matches(c, s.trim()))));
  n.children.forEach(c => { if (c.type === "element") removeMatches(c, selector); });
}

function convert(html: string, opt: Options): string {
  const root = parseHtml(html);
  removeMatches(root, opt.exclude);
  const nodes = opt.include ? selectNodes(root, opt.include) : root.children;
  return cleanBlocks(nodes.map(n => renderBlock(n, opt, 0)).join("\n\n"));
}

function cleanBlocks(s: string): string {
  s = s.split("\n").map(l => l.endsWith("  ") ? l : l.replace(/[ \t]+$/g, "")).join("\n");
  return s.replace(/\n{3,}/g, "\n\n").replace(/^\s+|\s+$/g, "");
}

function renderBlock(n: HNode, opt: Options, depth: number): string {
  if (n.type === "text") return escapeText(collapse(n.text), false);
  const t = n.tag;
  if (t === "script" || t === "style" || t === "noscript") return "";
  if (/^h[1-6]$/.test(t)) return `${"#".repeat(Number(t[1]))} ${renderInlineChildren(n, opt).trim()}`;
  if (t === "p") return renderInlineChildren(n, opt).trim();
  if (t === "br") return "  \n";
  if (t === "hr") return "* * *";
  if (t === "pre") return renderPre(n);
  if (t === "blockquote") return prefixQuote(cleanBlocks(n.children.map(c => renderBlock(c, opt, depth)).join("\n\n")));
  if (t === "ul" || t === "ol") return renderList(n, opt, depth, t === "ol");
  if (t === "table") return opt.table ? renderTable(n, opt) : renderInlineChildren(n, opt).trim();
  if (t === "tr" || t === "tbody" || t === "thead" || t === "tfoot") return n.children.map(c => renderBlock(c, opt, depth)).filter(Boolean).join("\n");
  if (t === "li") return renderInlineChildren(n, opt).trim();
  if (t === "div" || t === "section" || t === "article" || t === "main" || t === "header" || t === "footer" || t === "body" || t === "html" || t === "root" || t === "dl" || t === "dd" || t === "dt") {
    return cleanBlocks(n.children.map(c => renderBlock(c, opt, depth)).join("\n\n"));
  }
  return renderInline(n, opt).trim();
}

function renderInlineChildren(n: ElementNode, opt: Options): string {
  return normalizeInline(n.children.map(c => renderInline(c, opt)).join(""));
}

function renderInline(n: HNode, opt: Options): string {
  if (n.type === "text") return escapeText(collapse(n.text), false);
  const t = n.tag;
  if (t === "script" || t === "style" || t === "noscript") return "";
  if (t === "br") return "  \n";
  if (t === "img") {
    const alt = escapeText(n.attrs.alt || "", true);
    return `![${alt}](${absUrl(n.attrs.src || "", opt.domain)})`;
  }
  if (t === "a") {
    const text = renderInlineChildren(n, opt);
    const href = n.attrs.href || "";
    return href ? `[${text}](${absUrl(href, opt.domain)})` : text;
  }
  if (t === "strong" || t === "b") return `${opt.strong}${renderInlineChildren(n, opt)}${opt.strong}`;
  if (t === "em" || t === "i") return `*${renderInlineChildren(n, opt)}*`;
  if (t === "code") return inlineCode(textContent(n));
  if ((t === "del" || t === "s" || t === "strike") && opt.strike) return `~~${renderInlineChildren(n, opt)}~~`;
  if (t === "input") return "";
  if (blockTags.has(t)) return renderBlock(n, opt, 0);
  return n.children.map(c => renderInline(c, opt)).join("");
}

function collapse(s: string): string {
  return s.replace(/\s+/g, " ");
}

function normalizeInline(s: string): string {
  return s.replace(/\n[ \t]*/g, "\n").replace(/[ \t]{3,}/g, " ").replace(/^ | $/g, "");
}

function escapeText(s: string, inLink: boolean): string {
  if (!s) return "";
  s = s.replace(/\\/g, "\\\\");
  if (inLink) return s.replace(/]/g, "\\]");
  return s.replace(/([*_`\[\]])/g, "\\$1").replace(/^([#>])/gm, "\\$1").replace(/^(\s*)([-+])(\s)/gm, "$1\\$2$3").replace(/^(\s*)(\d+)\.(\s)/gm, "$1$2\\.$3");
}

function inlineCode(s: string): string {
  const max = Math.max(1, ...Array.from(s.matchAll(/`+/g)).map(m => m[0].length + 1));
  const ticks = "`".repeat(max);
  return `${ticks}${s}${ticks}`;
}

function textContent(n: HNode): string {
  if (n.type === "text") return n.text.replace(/&lt;/g, "<").replace(/&gt;/g, ">");
  if (n.tag === "br") return "\n";
  return n.children.map(textContent).join("");
}

function renderPre(n: ElementNode): string {
  let txt = textContent(n);
  txt = txt.replace(/^\n+|\n+$/g, "");
  return "```\n" + txt + "\n```";
}

function prefixQuote(s: string): string {
  return s.split("\n").map(l => l ? `> ${l}` : "> ").join("\n");
}

function renderList(n: ElementNode, opt: Options, depth: number, ordered: boolean): string {
  const lis = n.children.filter(c => c.type === "element" && c.tag === "li") as ElementNode[];
  return lis.map((li, idx) => {
    const marker = ordered ? `${idx + 1}. ` : "- ";
    const parts: string[] = [];
    const inlineNodes: HNode[] = [];
    for (const c of li.children) {
      if (c.type === "element" && (c.tag === "ul" || c.tag === "ol")) parts.push(renderList(c, opt, depth + 1, c.tag === "ol"));
      else inlineNodes.push(c);
    }
    const first = normalizeInline(inlineNodes.map(c => renderInline(c, opt)).join("")).trim();
    const indent = "  ".repeat(depth);
    let out = indent + marker + first;
    for (const p of parts) {
      if (p.trim()) out += "\n  \n" + p.split("\n").map(l => indent + l).join("\n");
    }
    return out;
  }).join("\n");
}

function absUrl(u: string, domain?: string): string {
  if (!u || !domain || /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(u) || u.startsWith("#") || u.startsWith("//")) return u;
  try { return new URL(u, domain).toString(); } catch { return u; }
}

function renderTable(n: ElementNode, opt: Options): string {
  if ((n.attrs.role || "").toLowerCase() === "presentation" && !opt.tablePresentation) return renderInlineChildren(n, opt).trim();
  const rows: ElementNode[][] = [];
  const visit = (e: ElementNode) => {
    if (e.tag === "tr") rows.push(e.children.filter(c => c.type === "element" && (c.tag === "td" || c.tag === "th")) as ElementNode[]);
    else e.children.forEach(c => { if (c.type === "element") visit(c); });
  };
  visit(n);
  let data = rows.map(r => r.map(c => cleanBlocks(c.children.map(ch => renderInline(ch, opt)).join("")).replace(/\n/g, opt.tableNewline === "preserve" ? "<br>" : " ")));
  if (opt.tableSkipEmptyRows) data = data.filter(r => r.some(c => c.trim()));
  if (!data.length) return "";
  const header = data[0];
  const cols = Math.max(...data.map(r => r.length));
  for (const r of data) while (r.length < cols) r.push("");
  while (header.length < cols) header.push("");
  const widths = Array(cols).fill(1);
  if (opt.tablePadding === "aligned") {
    for (const r of data) r.forEach((c, i) => widths[i] = Math.max(widths[i], visibleLen(c)));
  }
  const fmt = (r: string[]) => {
    if (opt.tablePadding === "none") return `|${r.join("|")}|`;
    if (opt.tablePadding === "minimal") return `| ${r.join(" | ")} |`;
    return "| " + r.map((c, i) => c + " ".repeat(widths[i] - visibleLen(c))).join(" | ") + " |";
  };
  const sep = opt.tablePadding === "none"
    ? `|${widths.map(w => "-".repeat(w + 2)).join("|")}|`
    : opt.tablePadding === "minimal"
      ? `| ${widths.map(() => "---").join(" | ")} |`
      : `|${widths.map(w => "-".repeat(w + 2)).join("|")}|`;
  return [fmt(header), sep, ...data.slice(1).map(fmt)].join("\n");
}

function visibleLen(s: string): number { return s.length; }

function expandInputs(pat: string): string[] {
  if (!/[*?[\]]/.test(pat)) {
    if (fs.existsSync(pat) && fs.statSync(pat).isDirectory()) return fs.readdirSync(pat).filter(f => /\.html?$/i.test(f)).map(f => path.join(pat, f)).sort();
    return [pat];
  }
  const dir = path.dirname(pat) === "." ? process.cwd() : path.dirname(pat);
  const base = path.basename(pat).replace(/[.+^${}()|\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
  const re = new RegExp("^" + base + "$");
  return fs.readdirSync(dir).filter(f => re.test(f)).map(f => path.join(dir, f)).sort();
}

function main() {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed === "help") { process.stdout.write(usage()); return; }
  if (parsed === "version") { process.stdout.write(version()); return; }
  const opt = parsed;
  const inputs = opt.input ? expandInputs(opt.input) : [];
  if (!inputs.length) {
    const html = fs.readFileSync(0, "utf8");
    const out = convert(html, opt);
    if (opt.output) writeOne(opt.output, out, opt.overwrite);
    else process.stdout.write(out);
    return;
  }
  if (inputs.length > 1 || (opt.input && fs.existsSync(opt.input) && fs.statSync(opt.input).isDirectory())) {
    if (!opt.output) die("output path is required when input is a directory or glob pattern");
    if (!fs.existsSync(opt.output)) fs.mkdirSync(opt.output, { recursive: true });
    if (!fs.statSync(opt.output).isDirectory()) die("output must be a directory when input is a directory or glob pattern");
    for (const f of inputs) {
      const outPath = path.join(opt.output, path.basename(f).replace(/\.[^.]+$/, ".md"));
      writeOne(outPath, convert(fs.readFileSync(f, "utf8"), opt), opt.overwrite);
    }
  } else {
    const out = convert(fs.readFileSync(inputs[0], "utf8"), opt);
    if (opt.output) writeOne(opt.output, out, opt.overwrite);
    else process.stdout.write(out);
  }
}

function writeOne(file: string, data: string, overwrite: boolean) {
  if (fs.existsSync(file) && !overwrite) die(`output path "${file}" already exists. Use --output-overwrite to replace existing files`);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, data);
}

main();
