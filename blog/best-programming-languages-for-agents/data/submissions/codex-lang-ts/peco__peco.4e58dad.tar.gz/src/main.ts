const fs = require("fs");
const cp = require("child_process");

const HELP = `
Usage: peco [options] [FILE]

Options:
  -h, --help            show this help message and exit
  --query               initial value for query
  --rcfile              path to the settings file
  --version             print the version and exit
  -b, --buffer-size     number of lines to keep in search buffer
  --null                expect NUL (\\0) as separator for target/output
  --initial-index       position of the initial index of the selection (0 base)
  --initial-filter      specify the default filter
  --prompt              specify the prompt string
  --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'
  --select-1            select first item and immediately exit if the input contains only 1 item
  --exit-0              exit immediately with status 1 if the input is empty
  --select-all          select all items and immediately exit
  --on-cancel           specify action on user cancel. 'success' or 'error'.
                        default is 'success'. This may change in future versions
  --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.
                        default is to use colors. This option is experimental
  --exec                execute command instead of finishing/terminating peco.
                        Please note that this command will receive selected line(s) from stdin,
                        and will be executed via '/bin/sh -c' or 'cmd /c'
  --print-query         print out the current query as first line of output
  --ansi                enable ANSI color code support
  --height              display height in lines or percentage (e.g. '10', '50%')
`;

type Opts = {
  query: string;
  rcfile?: string;
  bufferSize: number;
  nullMode: boolean;
  initialIndex: number;
  initialFilter: string;
  prompt: string;
  layout: string;
  select1: boolean;
  exit0: boolean;
  selectAll: boolean;
  onCancel: string;
  selectionPrefix?: string;
  execCmd?: string;
  printQuery: boolean;
  ansi: boolean;
  height?: string;
  file?: string;
};

function usageError(msg: string): void {
  process.stderr.write(`${msg}\n${HELP}`);
  process.stderr.write(`Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line options: ${msg}\n`);
  process.exit(1);
}

function parseIntFlag(flag: string, value: string): number {
  if (!/^-?\d+$/.test(value)) {
    const m = `invalid argument for flag \`${flag}' (expected int): strconv.ParseInt: parsing "${value}": invalid syntax`;
    usageError(m);
  }
  return Number(value);
}

function parseArgs(argv: string[]): Opts {
  const o: Opts = {
    query: "",
    bufferSize: 0,
    nullMode: false,
    initialIndex: 0,
    initialFilter: "IgnoreCase",
    prompt: "QUERY>",
    layout: "top-down",
    select1: false,
    exit0: false,
    selectAll: false,
    onCancel: "success",
    printQuery: false,
    ansi: false,
  };
  const need = (i: number, flag: string): string => {
    if (i + 1 >= argv.length || argv[i + 1].startsWith("--") && argv[i + 1] !== "-") {
      usageError(`expected argument for flag \`${flag}'`);
    }
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    let val: string | undefined;
    if (a.startsWith("--") && a.includes("=")) {
      const p = a.indexOf("=");
      val = a.slice(p + 1);
      a = a.slice(0, p);
    }
    const arg = (flag: string): string => val !== undefined ? val : need(i++, flag);
    switch (a) {
      case "-h":
      case "--help":
        process.stdout.write(HELP);
        process.exit(0);
      case "--version":
        process.stdout.write("peco version v0.5.11 (built with go1.25.0)\n");
        process.exit(0);
      case "--query":
        o.query = arg("--query");
        break;
      case "--rcfile":
        o.rcfile = arg("--rcfile");
        break;
      case "-b":
      case "--buffer-size":
        o.bufferSize = parseIntFlag(a === "-b" ? "-b, --buffer-size" : "--buffer-size", arg(a));
        break;
      case "--null":
        o.nullMode = true;
        break;
      case "--initial-index":
        o.initialIndex = parseIntFlag("--initial-index", arg("--initial-index"));
        break;
      case "--initial-filter":
        o.initialFilter = arg("--initial-filter");
        break;
      case "--prompt":
        o.prompt = arg("--prompt");
        break;
      case "--layout":
        o.layout = arg("--layout");
        break;
      case "--select-1":
        o.select1 = true;
        break;
      case "--exit-0":
        o.exit0 = true;
        break;
      case "--select-all":
        o.selectAll = true;
        break;
      case "--on-cancel":
        o.onCancel = arg("--on-cancel");
        break;
      case "--selection-prefix":
        o.selectionPrefix = arg("--selection-prefix");
        break;
      case "--exec":
        o.execCmd = arg("--exec");
        break;
      case "--print-query":
        o.printQuery = true;
        break;
      case "--ansi":
        o.ansi = true;
        break;
      case "--height":
        o.height = arg("--height");
        break;
      default:
        if (a.startsWith("-")) usageError(`unknown flag \`${a.replace(/^-+/, "")}'`);
        if (o.file) {
          process.stderr.write(`Error: failed to setup peco: failed to parse command line: too many arguments\n`);
          process.exit(1);
        }
        o.file = a;
    }
  }
  validate(o);
  return o;
}

function validate(o: Opts) {
  const filters = new Set(["IgnoreCase", "CaseSensitive", "SmartCase", "IRegexp", "Regexp", "Fuzzy"]);
  if (!filters.has(o.initialFilter)) {
    process.stderr.write("Error: failed to setup peco: failed to apply configuration: failed to populate initial filter: failed to set filter: specified filter was not found\n");
    process.exit(1);
  }
  if (!["top-down", "bottom-up", "top-down-query-bottom"].includes(o.layout)) {
    process.stderr.write(`Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line arguments: unknown layout: '${o.layout}'\n`);
    process.exit(1);
  }
  if (!["success", "error"].includes(o.onCancel)) {
    process.stderr.write(`Error: failed to setup peco: failed to apply configuration: invalid --on-cancel value: invalid OnCancel value "${o.onCancel}": must be "success" or "error"\n`);
    process.exit(1);
  }
  if (o.rcfile && !fs.existsSync(o.rcfile)) {
    process.stderr.write(`Error: failed to setup peco: failed to load config file: open ${o.rcfile}: no such file or directory\n`);
    process.exit(1);
  }
}

type Item = { display: any; result: any; raw: any };

function readInput(o: Opts): any {
  if (o.file) {
    try { return fs.readFileSync(o.file); }
    catch (e: any) {
      process.stderr.write(`Error: failed to setup peco: failed to open ${o.file}: ${e.message}\n`);
      process.exit(1);
    }
  }
  return fs.readFileSync(0);
}

function splitLines(buf: any): Item[] {
  const s = buf.toString("utf8");
  if (s.length === 0) return [];
  const parts = s.split(/\n/);
  if (parts[parts.length - 1] === "") parts.pop();
  return parts.map((p: string) => ({ display: p, result: p, raw: p }));
}

function splitNull(buf: any): Item[] {
  if (buf.length === 0) return [];
  const parts: any[] = [];
  let start = 0;
  for (let i = 0; i < buf.length; i++) {
    if (buf[i] === 0) {
      parts.push(buf.slice(start, i));
      start = i + 1;
    }
  }
  if (start < buf.length) parts.push(buf.slice(start));
  const items: Item[] = [];
  const newlineOnly = parts.length <= 1 && buf.indexOf(10) >= 0;
  if (newlineOnly) return splitLines(buf);
  for (let i = 0; i < parts.length; i += 2) {
    const display = parts[i];
    if (display.length === 0 && i >= parts.length - 1) continue;
    const result = i + 1 < parts.length ? parts[i + 1] : display;
    items.push({ display, result, raw: result });
  }
  return items;
}

function applyBuffer(items: Item[], n: number): Item[] {
  if (!n || n <= 0 || items.length <= n) return items;
  return items.slice(items.length - n);
}

function outRecord(x: any, nul: boolean) {
  process.stdout.write(x);
  process.stdout.write(nul ? Buffer.from([0]) : "\n");
}

function output(items: Item[], o: Opts) {
  let wrote = false;
  if (o.printQuery) {
    outRecord(o.query, o.nullMode);
    wrote = true;
  }
  for (const it of items) {
    outRecord(it.result, o.nullMode);
    wrote = true;
  }
  if (o.nullMode && wrote) process.stdout.write("\n");
}

function stripAnsi(s: string): string {
  return s.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "");
}

function terms(query: string): { pos: string[], neg: string[] } {
  const pos: string[] = [], neg: string[] = [];
  for (const raw of query.trim().split(/\s+/).filter(Boolean)) {
    let t = raw;
    let negative = false;
    if (t.startsWith("\\-")) t = t.slice(1);
    else if (t.startsWith("-") && t.length > 1) { negative = true; t = t.slice(1); }
    (negative ? neg : pos).push(t);
  }
  return { pos, neg };
}

function matches(item: Item, o: Opts, query = o.query): boolean {
  if (!query) return true;
  const text0 = typeof item.display === "string" ? item.display : item.display.toString("utf8");
  const text = o.ansi ? stripAnsi(text0) : text0;
  const { pos, neg } = terms(query);
  const insensitive = o.initialFilter === "IgnoreCase" || o.initialFilter === "IRegexp" ||
    (o.initialFilter === "SmartCase" && query.toLowerCase() === query);
  const hay = insensitive ? text.toLowerCase() : text;
  const chk = (t: string) => {
    if (o.initialFilter === "Regexp" || o.initialFilter === "IRegexp") {
      try { return new RegExp(t, o.initialFilter === "IRegexp" ? "i" : "").test(text); }
      catch { return false; }
    }
    const needle = insensitive ? t.toLowerCase() : t;
    if (o.initialFilter === "Fuzzy") {
      let p = 0;
      for (const ch of hay) if (ch === needle[p]) p++;
      return p >= needle.length;
    }
    return hay.includes(needle);
  };
  return pos.every(chk) && neg.every(t => !chk(t));
}

function tryTerminal(items: Item[], o: Opts): void {
  if (!process.env.TERM) {
    process.stderr.write("Error: failed to initialize screen: failed to create tcell screen: terminal entry not found: term not set\n");
    process.exit(1);
  }
  let input = "";
  try {
    const tty = fs.openSync("/dev/tty", "r");
    const b = Buffer.alloc(4096);
    const n = fs.readSync(tty, b, 0, b.length, null);
    input = b.slice(0, n).toString("utf8");
    fs.closeSync(tty);
  } catch {
    if (process.stdin.isTTY) {
      try { input = fs.readFileSync(0).toString("utf8"); } catch {}
    } else {
      process.stderr.write("Error: failed to initialize screen: failed to initialize tcell screen: open /dev/tty: no such device or address\n");
      process.exit(1);
    }
  }
  for (const ch of input) {
    if (ch === "\x1b") process.exit(o.onCancel === "error" ? 1 : 0);
    if (ch === "\r" || ch === "\n") break;
    if (ch === "\b" || ch === "\x7f") o.query = o.query.slice(0, -1);
    else if (ch >= " ") o.query += ch;
  }
  const filtered = items.filter(it => matches(it, o));
  if (filtered.length > 0) output([filtered[Math.min(Math.max(o.initialIndex, 0), filtered.length - 1)]], o);
  process.exit(0);
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  const items = applyBuffer(o.nullMode ? splitNull(readInput(o)) : splitLines(readInput(o)), o.bufferSize);
  if (o.exit0 && items.length === 0) process.exit(o.nullMode ? 0 : 1);
  const filtered = items.filter(it => matches(it, o));
  if (o.selectAll) {
    if (!o.nullMode && !o.file) tryTerminal(items, o);
    if (o.execCmd) {
      const data = filtered.map(it => it.result).join(o.nullMode ? "\0" : "\n") + (filtered.length ? (o.nullMode ? "\0" : "\n") : "");
      cp.spawnSync("/bin/sh", ["-c", o.execCmd], { input: data, stdio: ["pipe", "inherit", "inherit"] });
      process.exit(0);
    }
    output(filtered, o);
    process.exit(0);
  }
  if (o.select1 && filtered.length === 1) {
    output(filtered, o);
    process.exit(0);
  }
  tryTerminal(items, o);
}

main();
