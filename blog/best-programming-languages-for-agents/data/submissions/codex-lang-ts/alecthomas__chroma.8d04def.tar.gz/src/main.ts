declare const require: any;
declare const process: any;
declare const __dirname: string;

const fs = require("fs");
const path = require("path");

type Token = { type: string; value: string };

const VERSION = "?-?-?";
const DEFAULT_STYLE = "swapoff";
const TYPE_CLASS: Record<string, string> = {
  Text: "",
  TextWhitespace: "w",
  Keyword: "k",
  KeywordDeclaration: "kd",
  KeywordNamespace: "kn",
  KeywordReserved: "kr",
  KeywordConstant: "kc",
  NameOther: "nx",
  NameFunction: "nf",
  NameBuiltin: "nb",
  NameClass: "nc",
  NameTag: "nt",
  NameAttribute: "na",
  LiteralString: "s",
  LiteralStringDouble: "s2",
  LiteralStringSingle: "s1",
  LiteralNumber: "m",
  LiteralNumberInteger: "mi",
  LiteralNumberFloat: "mf",
  Comment: "c",
  CommentSingle: "c1",
  CommentMultiline: "cm",
  Operator: "o",
  OperatorWord: "ow",
  Punctuation: "p",
  NameVariable: "nv"
};

const aliases: Record<string, string> = {
  txt: "plaintext", text: "plaintext", plain: "plaintext", plaintext: "plaintext",
  go: "go", golang: "go",
  py: "python", python: "python", python3: "python",
  js: "javascript", jsx: "javascript", javascript: "javascript",
  ts: "typescript", tsx: "typescript", typescript: "typescript",
  json: "json", html: "html", xml: "xml", md: "markdown", markdown: "markdown",
  bash: "bash", sh: "bash", shell: "bash", zsh: "bash",
  c: "c", h: "c", cpp: "cpp", "c++": "cpp", cc: "cpp", hpp: "cpp",
  java: "java", rb: "ruby", ruby: "ruby", rs: "rust", rust: "rust",
  css: "css", yaml: "yaml", yml: "yaml", toml: "toml", sql: "sql"
};

function usage(): string {
  return `Usage: executable [<files> ...] [flags]

Chroma is a general purpose syntax highlighting library and corresponding
command, for Go.

Arguments:
  [<files> ...]    Files to highlight.

Flags:
  -h, --help               Show context-sensitive help.
      --version            Show version.
      --list               List lexers, styles and formatters.
      --unbuffered         Do not buffer output.
      --trace              Trace lexer states as they are traversed.
      --check              Do not format, check for tokenisation errors instead.
      --filename=STRING    Filename to use for selecting a lexer when reading
                           from stdin.
      --fail               Exit silently with status 1 if no specific lexer was
                           found.

Select lexer and style:
  -l, --lexer="autodetect"    Lexer to use when formatting or path to an XML
                              file to load.
  -s, --style="swapoff"       Style to use for formatting or path to an XML file
                              to load.

Output format:
  -f, --formatter="terminal"    Formatter to use.
      --json                    Convenience flag to use JSON formatter.
      --html                    Convenience flag to use HTML formatter.
      --svg                     Convenience flag to use SVG formatter.

HTML formatter options:
  --html-prefix=PREFIX             HTML CSS class prefix.
  --html-styles                    Output HTML CSS styles.
  --html-all-styles                Output all HTML CSS styles, including
                                   redundant ones.
  --html-only                      Output HTML fragment.
  --html-inline-styles             Output HTML with inline styles (no classes).
  --html-tab-width=8               Set the HTML tab width.
  --html-lines                     Include line numbers in output.
  --html-lines-table               Split line numbers and code in a HTML table
  --html-lines-style=STRING        Style for line numbers.
  --html-highlight=N[:M][,...]     Highlight these lines.
  --html-highlight-style=STRING    Style used for highlighting lines.
  --html-base-line=1               Base line number.
  --html-prevent-surrounding-pre
                                   Prevent the surrounding pre tag.
  --html-linkable-lines            Make the line numbers linkable and be a link
                                   to themselves.
`;
}

function die(message: string, code = 1): never {
  process.stderr.write(`executable: error: ${message}\n`);
  process.exit(code);
  throw new Error(message);
}

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&#34;");
}

function readStdin(): string {
  try { return fs.readFileSync(0, "utf8"); } catch { return ""; }
}

function detectLexer(filename?: string, requested?: string): string | null {
  if (requested && requested !== "autodetect") return aliases[requested.toLowerCase()] ?? requested.toLowerCase();
  if (!filename) return "plaintext";
  const base = path.basename(filename).toLowerCase();
  if (base === "makefile") return "makefile";
  const ext = base.includes(".") ? base.slice(base.lastIndexOf(".") + 1) : base;
  return aliases[ext] ?? null;
}

const keywordSets: Record<string, Set<string>> = {
  go: new Set("break default func interface select case defer go map struct chan else goto package switch const fallthrough if range type continue for import return var".split(" ")),
  python: new Set("and as assert break class continue def del elif else except False finally for from global if import in is lambda None nonlocal not or pass raise return True try while with yield".split(" ")),
  javascript: new Set("async await break case catch class const continue debugger default delete do else export extends finally for from function if import in instanceof let new of return static super switch this throw try typeof var void while with yield".split(" ")),
  typescript: new Set("abstract any as async await boolean break case catch class const constructor continue debugger declare default delete do else enum export extends false finally for from function if implements import in infer instanceof interface keyof let module namespace never new null number object of package private protected public readonly return static string super switch symbol this throw true try type typeof undefined unknown var void while with yield".split(" ")),
  c: new Set("auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while".split(" ")),
  cpp: new Set("alignas alignof auto bool break case catch char class const constexpr continue default delete do double else enum explicit export extern false float for friend goto if inline int long namespace new noexcept nullptr operator private protected public return short signed sizeof static struct switch template this throw true try typedef typename union unsigned using virtual void volatile while".split(" ")),
  java: new Set("abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while".split(" ")),
  rust: new Set("as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while".split(" ")),
  bash: new Set("if then else elif fi for while do done case esac function in select until time coproc".split(" ")),
  ruby: new Set("BEGIN END alias and begin break case class def defined do else elsif end ensure false for if in module next nil not or redo rescue retry return self super then true undef unless until when while yield".split(" ")),
  sql: new Set("select from where insert update delete create drop alter table into values join left right inner outer on group by order having limit offset and or not null is as distinct union all".split(" "))
};

const builtins = new Set("println print printf len cap append make new delete panic int string bool float64 true false nil console require JSON Math Array Object Promise".split(" "));

function pushToken(tokens: Token[], type: string, value: string) {
  if (!value) return;
  const last = tokens[tokens.length - 1];
  if (last && last.type === type) last.value += value; else tokens.push({ type, value });
}

function lexGeneric(input: string, lang: string): Token[] {
  const tokens: Token[] = [];
  const kws = keywordSets[lang] ?? keywordSets.javascript ?? new Set<string>();
  let i = 0;
  while (i < input.length) {
    const rest = input.slice(i);
    const ws = /^[ \t\r\n]+/.exec(rest);
    if (ws) { pushToken(tokens, "TextWhitespace", ws[0]); i += ws[0].length; continue; }
    if (rest.startsWith("//") || rest.startsWith("#")) {
      const m = /^[^\n]*(?:\n|$)/.exec(rest)![0]; pushToken(tokens, "CommentSingle", m); i += m.length; continue;
    }
    if (rest.startsWith("/*")) {
      const end = input.indexOf("*/", i + 2);
      const m = input.slice(i, end < 0 ? input.length : end + 2); pushToken(tokens, "CommentMultiline", m); i += m.length; continue;
    }
    if (rest[0] === `"` || rest[0] === "'" || rest[0] === "`") {
      const q = rest[0]; let j = i + 1;
      while (j < input.length) { if (input[j] === "\\") j += 2; else if (input[j] === q) { j++; break; } else j++; }
      pushToken(tokens, "LiteralString", input.slice(i, j)); i = j; continue;
    }
    const num = /^(?:0x[0-9a-fA-F]+|\d+(?:\.\d+)?)/.exec(rest);
    if (num) { pushToken(tokens, num[0].includes(".") ? "LiteralNumberFloat" : "LiteralNumberInteger", num[0]); i += num[0].length; continue; }
    const id = /^[A-Za-z_$][A-Za-z0-9_$]*/.exec(rest);
    if (id) {
      const word = id[0];
      let type = "NameOther";
      if (kws.has(word.toLowerCase()) || kws.has(word)) {
        type = word === "package" || word === "import" || word === "from" ? "KeywordNamespace" : (word === "func" || word === "function" || word === "def" || word === "fn" || word === "var" || word === "let" || word === "const" ? "KeywordDeclaration" : "Keyword");
      } else if (builtins.has(word)) type = "NameBuiltin";
      const after = input.slice(i + word.length);
      if (type === "NameOther" && /^\s*\(/.test(after)) type = "NameFunction";
      pushToken(tokens, type, word); i += word.length; continue;
    }
    const op = /^(?:==|!=|<=|>=|:=|&&|\|\||[-+*/%=<>!&|.^~:]+)/.exec(rest);
    if (op) { pushToken(tokens, "Operator", op[0]); i += op[0].length; continue; }
    pushToken(tokens, "Punctuation", rest[0]); i++;
  }
  return tokens;
}

function lexJson(input: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < input.length) {
    const rest = input.slice(i);
    const ws = /^[ \t\r\n]+/.exec(rest);
    if (ws) { pushToken(tokens, "TextWhitespace", ws[0]); i += ws[0].length; continue; }
    const str = /^"(?:\\.|[^"\\])*"/.exec(rest);
    if (str) { pushToken(tokens, "LiteralStringDouble", str[0]); i += str[0].length; continue; }
    const num = /^-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/.exec(rest);
    if (num) { pushToken(tokens, "LiteralNumber", num[0]); i += num[0].length; continue; }
    const kw = /^(true|false|null)\b/.exec(rest);
    if (kw) { pushToken(tokens, "KeywordConstant", kw[0]); i += kw[0].length; continue; }
    pushToken(tokens, "Punctuation", rest[0]); i++;
  }
  return tokens;
}

function lexHtml(input: string): Token[] {
  const tokens: Token[] = [];
  const re = /<\/?[A-Za-z][^>]*>|[^<]+|</g;
  for (const m of input.matchAll(re)) {
    const v = m[0];
    if (v.startsWith("<") && v.endsWith(">")) pushToken(tokens, "NameTag", v);
    else pushToken(tokens, /\s+/.test(v) ? "TextWhitespace" : "Text", v);
  }
  return tokens;
}

function lex(input: string, lang: string): Token[] {
  if (lang === "plaintext" || lang === "markdown") return [{ type: "Text", value: input }];
  if (lang === "json") return lexJson(input);
  if (lang === "html" || lang === "xml") return lexHtml(input);
  return lexGeneric(input, lang);
}

function formatJson(tokens: Token[]): string {
  return "[\n" + tokens.map(t => `  ${JSON.stringify(t)}`).join(",\n") + "\n]\n";
}

function formatTokens(tokens: Token[]): string {
  return tokens.map(t => `&Token{${t.type}, ${JSON.stringify(t.value)}}`).join("\n") + (tokens.length ? "\n" : "");
}

function formatTerminal(tokens: Token[], style: string): string {
  const text = tokens.map(t => t.value).join("");
  if (style === "bw") return text;
  return text;
}

function css(prefix: string): string {
  return `<style type="text/css">
/* Background */ .${prefix}bg { background-color: #ffffff; }
/* PreWrapper */ .${prefix}chroma { background-color: #ffffff; -webkit-text-size-adjust: none; }
/* LineLink */ .${prefix}chroma .lnlinks { outline: none; text-decoration: none; color: inherit }
/* LineTableTD */ .${prefix}chroma .lntd { vertical-align: top; padding: 0; margin: 0; border: 0; }
/* LineTable */ .${prefix}chroma .lntable { border-spacing: 0; padding: 0; margin: 0; border: 0; }
/* LineHighlight */ .${prefix}chroma .hl { background-color: #e5e5e5 }
/* LineNumbersTable */ .${prefix}chroma .lnt { white-space: pre; -webkit-user-select: none; user-select: none; margin-right: 0.4em; padding: 0 0.4em 0 0.4em;color: #7f7f7f }
/* LineNumbers */ .${prefix}chroma .ln { white-space: pre; -webkit-user-select: none; user-select: none; margin-right: 0.4em; padding: 0 0.4em 0 0.4em;color: #7f7f7f }
/* Line */ .${prefix}chroma .line { display: flex; }
/* Keyword */ .${prefix}chroma .k { font-weight: bold }
/* KeywordDeclaration */ .${prefix}chroma .kd { font-weight: bold }
/* KeywordNamespace */ .${prefix}chroma .kn { font-weight: bold }
/* LiteralString */ .${prefix}chroma .s { font-style: italic }
/* Comment */ .${prefix}chroma .c { font-style: italic }
body { background-color:#fff;; }
</style>`;
}

function tokenHtml(t: Token, inline: boolean): string {
  const value = esc(t.value);
  const cls = TYPE_CLASS[t.type] ?? "";
  if (!cls) return value;
  if (inline) {
    const st = t.type.startsWith("Keyword") ? "font-weight:bold" : t.type.startsWith("LiteralString") || t.type.startsWith("Comment") ? "font-style:italic" : "";
    return st ? `<span style="${st}">${value}</span>` : value;
  }
  return `<span class="${cls}">${value}</span>`;
}

function formatHtml(tokens: Token[], opts: Opts): string {
  if (opts.htmlStyles) return css(opts.htmlPrefix) + "\n";
  const raw = tokens.map(t => t.value).join("");
  const lines = raw.length ? raw.match(/[^\n]*(?:\n|$)/g)!.filter((x, idx, a) => !(idx === a.length - 1 && x === "")) : [""];
  let idx = 0;
  let body = `<pre class="chroma">`;
  if (!opts.htmlPreventPre) body += "<code>";
  lines.forEach((line, n) => {
    const lineTokens: Token[] = [];
    let need = line.length;
    while (need > 0 && idx < tokens.length) {
      const t = tokens[idx];
      if (t.value.length <= need) { lineTokens.push(t); need -= t.value.length; idx++; }
      else { lineTokens.push({ type: t.type, value: t.value.slice(0, need) }); tokens[idx] = { type: t.type, value: t.value.slice(need) }; need = 0; }
    }
    const content = lineTokens.map(t => tokenHtml(t, opts.htmlInline)).join("");
    const ln = opts.htmlLines ? `<span class="ln">${opts.htmlBaseLine + n}</span>` : "";
    body += `<span class="line">${ln}<span class="cl">${content}</span></span>`;
  });
  if (!opts.htmlPreventPre) body += "</code>";
  body += "</pre>";
  if (opts.htmlOnly) return body + "\n";
  return `<html>\n${css(opts.htmlPrefix)}<body class="bg">\n${body}\n</body>\n</html>\n`;
}

function formatSvg(tokens: Token[]): string {
  const text = esc(tokens.map(t => t.value).join(""));
  const lines = text.split("\n").length;
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.0//EN" "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">
<svg width="800px" height="${Math.max(43, lines * 20 + 20)}px" xmlns="http://www.w3.org/2000/svg">
<rect width="100%" height="100%" fill="#ffffff"/>
<g font-family="Liberation Mono, monospace" font-size="14px" fill="#000000">
<text x="0" y="1.200000em" xml:space="preserve">${text}</text>
</g>
</svg>
`;
}

type Opts = {
  files: string[];
  lexer: string;
  style: string;
  formatter: string;
  filename?: string;
  fail: boolean;
  check: boolean;
  trace: boolean;
  htmlOnly: boolean;
  htmlStyles: boolean;
  htmlInline: boolean;
  htmlLines: boolean;
  htmlBaseLine: number;
  htmlPrefix: string;
  htmlPreventPre: boolean;
};

function parse(argv: string[]): Opts | "help" | "version" | "list" {
  const opts: Opts = { files: [], lexer: "autodetect", style: DEFAULT_STYLE, formatter: "terminal", fail: false, check: false, trace: false, htmlOnly: false, htmlStyles: false, htmlInline: false, htmlLines: false, htmlBaseLine: 1, htmlPrefix: "", htmlPreventPre: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const val = () => {
      const eq = a.indexOf("=");
      if (eq >= 0) return a.slice(eq + 1);
      if (i + 1 >= argv.length) die(`expected argument for flag ${a}`, 80);
      return argv[++i];
    };
    if (a === "-h" || a === "--help") return "help";
    else if (a === "--version") return "version";
    else if (a === "--list") return "list";
    else if (a === "--json") opts.formatter = "json";
    else if (a === "--html") opts.formatter = "html";
    else if (a === "--svg") opts.formatter = "svg";
    else if (a === "--fail") opts.fail = true;
    else if (a === "--check") opts.check = true;
    else if (a === "--trace") opts.trace = true;
    else if (a === "--unbuffered") {}
    else if (a === "-l" || a === "--lexer" || a.startsWith("--lexer=")) opts.lexer = val();
    else if (a === "-s" || a === "--style" || a.startsWith("--style=")) opts.style = val();
    else if (a === "-f" || a === "--formatter" || a.startsWith("--formatter=")) opts.formatter = val();
    else if (a === "--filename" || a.startsWith("--filename=")) opts.filename = val();
    else if (a === "--html-only") opts.htmlOnly = true;
    else if (a === "--html-styles" || a === "--html-all-styles") opts.htmlStyles = true;
    else if (a === "--html-inline-styles") opts.htmlInline = true;
    else if (a === "--html-lines" || a === "--html-lines-table") opts.htmlLines = true;
    else if (a === "--html-prevent-surrounding-pre") opts.htmlPreventPre = true;
    else if (a === "--html-base-line" || a.startsWith("--html-base-line=")) opts.htmlBaseLine = Number(val()) || 1;
    else if (a === "--html-prefix" || a.startsWith("--html-prefix=")) opts.htmlPrefix = val();
    else if (a.startsWith("--html-highlight") || a.startsWith("--html-lines-style") || a.startsWith("--html-tab-width") || a === "--html-linkable-lines") { if (!a.includes("=") && !["--html-linkable-lines"].includes(a)) i++; }
    else if (a.startsWith("-")) die(`unknown flag ${a}`, 80);
    else opts.files.push(a);
  }
  return opts;
}

function outputList() {
  const candidates = [path.join(process.cwd(), "chroma-list.txt"), path.join(__dirname, "..", "chroma-list.txt")];
  for (const p of candidates) {
    if (fs.existsSync(p)) { process.stdout.write(fs.readFileSync(p, "utf8")); return; }
  }
  process.stdout.write("lexers:\n  plaintext\n    aliases: text plain\n\nstyles: bw swapoff\nformatters: html json noop svg terminal terminal16 terminal16m terminal256 terminal8 tokens\n");
}

function main() {
  const parsed = parse(process.argv.slice(2));
  if (parsed === "help") { process.stdout.write(usage()); return; }
  if (parsed === "version") { process.stdout.write(VERSION + "\n"); return; }
  if (parsed === "list") { outputList(); return; }
  const opts = parsed;
  if (opts.style === DEFAULT_STYLE) die(`open ${DEFAULT_STYLE}: no such file or directory`);
  const inputs: { filename?: string; text: string; lexer: string }[] = [];
  if (opts.files.length === 0) {
    const lexer = detectLexer(opts.filename, opts.lexer);
    if (!lexer) { if (opts.fail) process.exit(1); else inputs.push({ text: readStdin(), lexer: "plaintext" }); }
    else inputs.push({ filename: opts.filename, text: readStdin(), lexer });
  } else {
    for (const file of opts.files) {
      let text: string;
      try { text = fs.readFileSync(file, "utf8"); } catch (e: any) { die(`[<files> ...]: ${e.message}`, 80); }
      const lexer = detectLexer(file, opts.lexer);
      if (!lexer) { if (opts.fail) process.exit(1); else inputs.push({ filename: file, text, lexer: "plaintext" }); }
      else inputs.push({ filename: file, text, lexer });
    }
  }
  if (opts.check) return;
  for (const input of inputs) {
    const tokens = lex(input.text, input.lexer);
    if (opts.trace) for (const t of tokens) process.stderr.write(`${t.type}: ${JSON.stringify(t.value)}\n`);
    switch (opts.formatter) {
      case "json": process.stdout.write(formatJson(tokens)); break;
      case "tokens": process.stdout.write(formatTokens(tokens)); break;
      case "html": process.stdout.write(formatHtml(tokens, opts)); break;
      case "svg": process.stdout.write(formatSvg(tokens)); break;
      case "noop": break;
      default: process.stdout.write(formatTerminal(tokens, opts.style)); break;
    }
  }
}

main();
