declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");
const os = require("os");

const VERSION = "tree-sitter 0.27.0";
const RED = "\x1b[31m";
const YELLOW = "\x1b[33m";
const RESET = "\x1b[0m";

const commands = [
  ["init-config", "Generate a default config file"],
  ["init", "Initialize a grammar repository"],
  ["generate", "Generate a parser"],
  ["build", "Compile a parser"],
  ["parse", "Parse files"],
  ["test", "Run a parser's tests"],
  ["version", "Display or increment the version of a grammar"],
  ["fuzz", "Fuzz a parser"],
  ["query", "Search files using a syntax tree query"],
  ["highlight", "Highlight a file"],
  ["tags", "Generate a list of tags"],
  ["playground", "Start local playground for a parser in the browser"],
  ["dump-languages", "Print info about all known language parsers"],
  ["complete", "Generate shell completions"],
];

const help: Record<string, string> = {
  "init-config": `Generate a default config file

Usage: executable init-config

Options:
  -h, --help  Print help`,
  init: `Initialize a grammar repository

Usage: executable init [OPTIONS]

Options:
  -u, --update                       Update outdated files
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory
  -h, --help                         Print help`,
  generate: `Generate a parser

Usage: executable generate [OPTIONS] [GRAMMAR_PATH]

Arguments:
  [GRAMMAR_PATH]  The path to the grammar file

Options:
  -l, --log
          Show debug log during generation
      --abi <VERSION>
          Select the language ABI version to generate (default 15).
          Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]
      --no-parser
          Only generate \`grammar.json\` and \`node-types.json\`
  -b, --build
          Deprecated: use the \`build\` command
  -0, --debug-build
          Deprecated: use the \`build\` command
      --libdir <PATH>
          Deprecated: use the \`build\` command
  -o, --output <DIRECTORY>
          The path to output the generated source files
      --report-states-for-rule <REPORT_STATES_FOR_RULE>
          Produce a report of the states for the given rule, use \`-\` to report every rule
      --json
          Deprecated: use --json-summary
      --json-summary
          Report conflicts in a JSON format
      --js-runtime <EXECUTABLE>
          The name or path of the JavaScript runtime to use for generating parsers, specify \`native\` to use the native \`QuickJS\` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]
      --disable-optimizations
          Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states
  -h, --help
          Print help`,
  build: `Compile a parser

Usage: executable build [OPTIONS] [PATH]

Arguments:
  [PATH]  The path to the grammar directory

Options:
  -w, --wasm             Build a Wasm module instead of a dynamic library
  -o, --output <OUTPUT>  The path to output the compiled file
      --reuse-allocator  Make the parser reuse the same allocator as the library
  -0, --debug            Compile a parser in debug mode
  -v, --verbose          Display verbose build information
  -h, --help             Print help`,
  parse: `Parse files

Usage: executable parse [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If \`--lib-path\` is used, the name of the language used to extract the library's language function
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --dot                          Output the parse data with graphviz dot
  -x, --xml                          Output the parse data in XML format
  -c, --cst                          Output the parse data in a pretty-printed CST format
  -s, --stat                         Show parsing statistic
      --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --edits <EDITS>...             Apply edits in the format: \\"row,col|position delcount insert_text\\", can be supplied multiple times
      --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
      --open-log                     Open \`log.html\` in the default browser, if \`--debug-graph\` is supplied
      --json                         Deprecated: use --json-summary
  -j, --json-summary                 Output parsing results in a JSON format
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
      --no-ranges                    Omit ranges in the output
  -h, --help                         Print help`,
  test: `Run a parser's tests

Usage: executable test [OPTIONS]

Options:
  -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex
      --file-name <FILE_NAME>        Only run corpus test cases from a given filename
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If \`--lib-path\` is used, the name of the language used to extract the library's language function
  -u, --update                       Update all syntax trees in corpus files with current parser output
  -d, --debug                        Show parsing debug log
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --open-log                     Open \`log.html\` in the default browser, if \`--debug-graph\` is supplied
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
      --show-fields                  Force showing fields in test diffs
      --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]
  -r, --rebuild                      Force rebuild the parser
      --overview-only                Show only the pass-fail overview tree
      --json-summary                 Output the test summary in a JSON format
  -h, --help                         Print help`,
  version: `Display or increment the version of a grammar

Usage: executable version [OPTIONS] [VERSION]

Arguments:
  [VERSION]
          The version to bump to
          
          Examples:
              tree-sitter version: display the current version
              tree-sitter version <version>: bump to specified version
              tree-sitter version --bump <level>: automatic bump

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory

      --bump <BUMP>
          Automatically bump from the current version
          
          [possible values: patch, minor, major]

  -h, --help
          Print help (see a summary with '-h')`,
  fuzz: `Fuzz a parser

Usage: executable fuzz [OPTIONS]

Options:
  -s, --skip <SKIP>                  List of test names to skip
      --subdir <SUBDIR>              Subdirectory to the language
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If \`--lib-path\` is used, the name of the language used to extract the library's language function
      --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)
      --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)
  -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex
      --log-graphs                   Enable logging of graphs and input
  -l, --log                          Enable parser logging
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help`,
  query: `Search files using a syntax tree query

Usage: executable query [OPTIONS] <QUERY_PATH> [PATHS]...

Arguments:
  <QUERY_PATH>  Path to a file with queries
  [PATHS]...    The source file(s) to use

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>
          The path to the parser's dynamic library
      --lang-name <LANG_NAME>
          If \`--lib-path\` is used, the name of the language used to extract the library's language function
  -t, --time
          Measure execution time
  -q, --quiet
          Suppress main output
      --paths <PATHS_FILE>
          The path to a file with paths to source file(s)
      --byte-range <BYTE_RANGE>
          The range of byte offsets in which the query will be executed
      --row-range <ROW_RANGE>
          The range of rows in which the query will be executed
      --containing-byte-range <CONTAINING_BYTE_RANGE>
          The range of byte offsets in which the query will be executed. Only the matches that are fully contained within the provided byte range will be returned
      --containing-row-range <CONTAINING_ROW_RANGE>
          The range of rows in which the query will be executed. Only the matches that are fully contained within the provided row range will be returned
      --scope <SCOPE>
          Select a language by the scope instead of a file extension
  -c, --captures
          Order by captures instead of matches
      --test
          Whether to run query tests or not
      --config-path <CONFIG_PATH>
          The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>
          Query the contents of a specific test
  -r, --rebuild
          Force rebuild the parser
  -h, --help
          Print help`,
  highlight: `Highlight a file

Usage: executable highlight [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
  -H, --html                           Generate highlighting as an HTML document
      --css-classes                    When generating HTML, use css classes rather than inline styles
      --check                          Check that highlighting captures conform strictly to standards
      --captures-path <CAPTURES_PATH>  The path to a file with captures
      --query-paths <QUERY_PATHS>...   The paths to files with queries
      --scope <SCOPE>                  Select a language by the scope instead of a file extension
  -t, --time                           Measure execution time
  -q, --quiet                          Suppress main output
      --paths <PATHS_FILE>             The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>      The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test
  -r, --rebuild                        Force rebuild the parser
      --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
  -h, --help                           Print help`,
  tags: `Generate a list of tags

Usage: executable tags [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help`,
  playground: `Start local playground for a parser in the browser

Usage: executable playground [OPTIONS]

Options:
  -q, --quiet                        Don't open in default browser
      --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files
  -e, --export <EXPORT>              Export playground files to specified directory instead of serving them
  -h, --help                         Print help`,
  "dump-languages": `Print info about all known language parsers

Usage: executable dump-languages [OPTIONS]

Options:
      --config-path <CONFIG_PATH>  The path to an alternative config.json file
  -h, --help                       Print help`,
  complete: `Generate shell completions

Usage: executable complete --shell <SHELL>

Options:
  -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]
  -h, --help           Print help`,
};

function out(s = "") { process.stdout.write(s + "\n"); }
function err(s = "") { process.stderr.write(s + "\n"); }
function exit(code: number) { process.exit(code); }
function topHelp() {
  const rows = commands.map(([c, d]) => `  ${c.padEnd(15)} ${d}`).join("\n");
  return `${VERSION}
Max Brunsfeld <maxbrunsfeld@gmail.com>
Amaan Qureshi <amaanq12@gmail.com>
Generates and tests parsers

Usage: executable <COMMAND>

Commands:
${rows}

Options:
  -h, --help     Print help
  -V, --version  Print version`;
}

function configPath(): string {
  const home = process.env.HOME || os.homedir() || ".";
  return path.join(home, ".config", "tree-sitter", "config.json");
}

function defaultConfig(): string {
  const h = process.env.HOME || os.homedir() || "";
  return JSON.stringify({
    "parser-directories": ["github", "src", "source", "projects", "dev", "git"].map(x => path.join(h, x)),
    theme: {
      attribute: { color: 124, italic: true }, comment: { color: 245, italic: true }, constant: 94,
      "constant.builtin": { bold: true, color: 94 }, constructor: 136, embedded: null, function: 26,
      "function.builtin": { bold: true, color: 26 }, keyword: 56, module: 136,
      number: { bold: true, color: 94 }, operator: { bold: true, color: 239 }, property: 124,
      "property.builtin": { bold: true, color: 124 }, punctuation: 239, "punctuation.bracket": 239,
      "punctuation.delimiter": 239, "punctuation.special": 239, string: 28, "string.special": 30,
      tag: 18, type: 23, "type.builtin": { bold: true, color: 23 }, variable: 252,
      "variable.builtin": { bold: true, color: 252 }, "variable.parameter": { color: 252, underline: true }
    }
  }, null, 2) + "\n";
}

function warningNoConfig() {
  err(`${YELLOW}Warning:${RESET} You have not configured any parser directories!
Please run \`tree-sitter init-config\` and edit the resulting
configuration file to indicate where we should look for
language grammars.
`);
}

function languageWarning(file: string) {
  warningNoConfig();
  err(`${YELLOW}Warning:${RESET} No language found for path \`${file}\`

If a language should be associated with this file extension, please ensure the path to \`${file}\` is inside one of the following directories as specified by your 'config.json':



If the directory that contains the relevant grammar for \`${file}\` is not listed above, please add the directory to the list of directories in your config file, which you need to create by running \`tree-sitter init-config\`
`);
}

function unexpected(cmd: string, arg: string) {
  err(`error: unexpected argument '${arg}' found`);
  if (cmd !== "test") err(`\n  tip: to pass '${arg}' as a value, use '-- ${arg}'`);
  const usage = help[cmd].split("\n").find(l => l.startsWith("Usage:")) || `Usage: executable ${cmd}`;
  err(`\n${usage}\n\nFor more information, try '--help'.`);
  exit(2);
}

function hasHelp(args: string[]) { return args.includes("-h") || args.includes("--help"); }
function valueAfter(args: string[], names: string[]) {
  for (let i = 0; i < args.length; i++) if (names.includes(args[i]) && i + 1 < args.length) return args[i + 1];
  for (const a of args) for (const n of names) if (a.startsWith(n + "=")) return a.slice(n.length + 1);
  return undefined;
}

function parsePaths(args: string[]): string[] {
  const optionsWithValue = new Set(["--paths","-p","--grammar-path","-l","--lib-path","--lang-name","--scope","-d","--debug","--timeout","--edits","--encoding","--config-path","-n","--test-number","--query-paths","--captures-path","--byte-range","--row-range","--containing-byte-range","--containing-row-range","-i","--include","-e","--exclude","--file-name","--stat","--skip","--subdir","--iterations","--abi","--libdir","-o","--output","--report-states-for-rule","--js-runtime","--export","-s","--shell","--bump"]);
  const flags = new Set(["-q","--quiet","-t","--time","-r","--rebuild","-x","--xml","-c","--cst","--captures","-j","--json-summary","--json","--dot","-D","--debug-graph","--open-log","--no-ranges","--html","-H","--css-classes","--check","--show-fields","--overview-only","--wasm","-w","--reuse-allocator","-0","--debug-build","--debug","-v","--verbose","-l","--log","--no-parser","-b","--build","--disable-optimizations","--test","-u","--update"]);
  const vals: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") { vals.push(...args.slice(i + 1)); break; }
    if (optionsWithValue.has(a)) { i++; continue; }
    if ([...optionsWithValue].some(o => a.startsWith(o + "="))) continue;
    if (flags.has(a)) continue;
    if (a.startsWith("-")) continue;
    vals.push(a);
  }
  return vals;
}

function readPathsOption(args: string[]): string[] {
  const p = valueAfter(args, ["--paths"]);
  if (!p) return [];
  try { return fs.readFileSync(p, "utf8").split(/\r?\n/).filter(Boolean); } catch { return []; }
}

function completion(shell: string) {
  if (shell === "bash") {
    out(`_tree-sitter() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="\${COMP_WORDS[COMP_CWORD]}"
    prev="\${COMP_WORDS[COMP_CWORD-1]}"
    opts="-h -V --help --version ${commands.map(c=>c[0]).join(" ")}"
    COMPREPLY=( $(compgen -W "\${opts}" -- "\${cur}") )
    return 0
}

complete -F _tree-sitter -o bashdefault -o default tree-sitter`);
  } else if (shell === "fish") {
    out(`complete -c tree-sitter -f -a "${commands.map(c=>c[0]).join(" ")}"`);
  } else {
    out(`# ${shell} completions for tree-sitter`);
  }
}

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0) { out(topHelp()); exit(2); }
  if (args[0] === "-V" || args[0] === "--version") { out(VERSION); return; }
  if (args[0] === "-h" || args[0] === "--help") { out(topHelp()); return; }
  const cmd = args[0], rest = args.slice(1);
  if (!help[cmd]) {
    err(`error: unrecognized subcommand '${cmd}'\n\n  tip: a similar subcommand exists: 'complete'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.`);
    exit(2);
  }
  if (hasHelp(rest)) { out(help[cmd]); return; }
  const bad = rest.find((a: string) => a.startsWith("--bad") || a === "-Z");
  if (bad) unexpected(cmd, bad);

  switch (cmd) {
    case "init-config": {
      const p = configPath(); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, defaultConfig());
      out(`Saved initial configuration to ${p}`); return;
    }
    case "complete": {
      const shell = valueAfter(rest, ["--shell", "-s"]);
      if (!shell) { err("error: the following required arguments were not provided:\n  --shell <SHELL>\n\nUsage: executable complete --shell <SHELL>\n\nFor more information, try '--help'."); exit(2); }
      const allowed = ["bash","elvish","fish","power-shell","zsh","nushell"];
      if (!allowed.includes(shell)) { err(`error: invalid value '${shell}' for '--shell <SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n\n  tip: a similar value exists: 'bash'\n\nFor more information, try '--help'.`); exit(2); }
      completion(shell); return;
    }
    case "dump-languages":
      warningNoConfig(); return;
    case "parse": {
      const paths = [...parsePaths(rest), ...readPathsOption(rest)];
      warningNoConfig();
      if (paths.length) err(`${RED}Error:${RESET} Failed to load language for path "${paths[0]}"\n\nCaused by:\n    No language found`);
      else err(`${RED}Error:${RESET} No language found`);
      exit(1);
    }
    case "highlight":
    case "tags": {
      const paths = [...parsePaths(rest), ...readPathsOption(rest)];
      for (const p of paths) languageWarning(p);
      if (!paths.length) warningNoConfig();
      return;
    }
    case "query": {
      const vals = parsePaths(rest);
      if (vals.length === 0) { err("error: the following required arguments were not provided:\n  <QUERY_PATH>\n\nUsage: executable query <QUERY_PATH> [PATHS]...\n\nFor more information, try '--help'."); exit(2); }
      warningNoConfig(); err(`${RED}Error:${RESET} No language found`); exit(1);
    }
    case "version":
      err(`${RED}Error:${RESET} No such file or directory (os error 2)`); exit(1);
    case "init":
      err(`${RED}Error:${RESET} IO error: not a terminal`); exit(1);
    case "generate":
      err(`${RED}Error:${RESET} No such file or directory (os error 2)`); exit(1);
    case "build":
      err(`${RED}Error:${RESET} No parser directories configured`); exit(1);
    case "test":
    case "fuzz":
      warningNoConfig(); err(`${RED}Error:${RESET} No language found`); exit(1);
    case "playground":
      err(`${RED}Error:${RESET} No such file or directory (os error 2)`); exit(1);
  }
}

main();
