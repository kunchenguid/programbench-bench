declare const require: any;
declare const process: any;
const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
const readline = require("readline");

type LabelType = "long" | "short" | "none";
type Style = { hide?: boolean; bold?: boolean; foreground?: string; background?: string; faint?: boolean; italic?: boolean; underline?: boolean; inverse?: boolean };
type Config = {
  labelType: LabelType;
  coverThreshold: number;
  leaveTestPrefix: boolean;
  removals: RegExp[];
  buildStyle: Style; startStyle: Style; passStyle: Style; failStyle: Style; skipStyle: Style;
  passPackageStyle: Style; failPackageStyle: Style; coveredStyle: Style; uncoveredStyle: Style; fileStyle: Style; lineStyle: Style;
};

const defaults: Config = {
  labelType: "long",
  coverThreshold: 50,
  leaveTestPrefix: false,
  removals: [],
  buildStyle: { bold: true, foreground: "yellow" },
  startStyle: { foreground: "lightBlack" },
  passStyle: { foreground: "green" },
  failStyle: { bold: true, foreground: "red" },
  skipStyle: { foreground: "lightBlack" },
  passPackageStyle: { foreground: "green", hide: true },
  failPackageStyle: { bold: true, foreground: "red", hide: true },
  coveredStyle: { foreground: "green" },
  uncoveredStyle: { bold: true, foreground: "yellow" },
  fileStyle: { foreground: "cyan" },
  lineStyle: { foreground: "magenta" },
};

const colorMap: Record<string, number> = {
  black: 30, red: 31, green: 32, yellow: 33, blue: 34, magenta: 35, cyan: 36, white: 37,
  lightBlack: 90, gray: 90, grey: 90, lightRed: 91, lightGreen: 92, lightYellow: 93,
  lightBlue: 94, lightMagenta: 95, lightCyan: 96, lightWhite: 97,
};

function cloneConfig(): Config {
  return {
    ...defaults,
    removals: [],
    buildStyle: {...defaults.buildStyle}, startStyle: {...defaults.startStyle}, passStyle: {...defaults.passStyle},
    failStyle: {...defaults.failStyle}, skipStyle: {...defaults.skipStyle}, passPackageStyle: {...defaults.passPackageStyle},
    failPackageStyle: {...defaults.failPackageStyle}, coveredStyle: {...defaults.coveredStyle}, uncoveredStyle: {...defaults.uncoveredStyle},
    fileStyle: {...defaults.fileStyle}, lineStyle: {...defaults.lineStyle},
  };
}

function parseBool(v: string): boolean | undefined {
  const s = v.trim().toLowerCase();
  if (s === "true") return true;
  if (s === "false") return false;
  return undefined;
}
function cleanVal(v: string): string { return v.trim().replace(/^['"]|['"]$/g, ""); }

function loadConfig(): Config {
  const cfg = cloneConfig();
  const cwd = process.cwd();
  const bases: string[] = [];
  const localOnly = process.env.RICHGO_LOCAL === "1";
  bases.push(cwd);
  if (!localOnly) {
    if (process.env.GOPATH) bases.push(process.env.GOPATH);
    if (process.env.GOROOT) bases.push(process.env.GOROOT);
    if (process.env.HOME) bases.push(process.env.HOME);
  }
  let file: string | undefined;
  for (const b of bases) for (const n of [".richstyle", ".richstyle.yaml", ".richstyle.yml"]) {
    const p = path.join(b, n); if (!file && fs.existsSync(p)) file = p;
  }
  if (!file) return cfg;
  const styleKeys = new Set(["buildStyle","startStyle","passStyle","failStyle","skipStyle","passPackageStyle","failPackageStyle","coveredStyle","uncoveredStyle","fileStyle","lineStyle"]);
  let current: string | null = null, inRemovals = false;
  for (const raw of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const noComment = raw.replace(/\s+#.*$/, "");
    if (!noComment.trim()) continue;
    const indent = /^\s*/.exec(noComment)![0].length;
    const line = noComment.trim();
    if (line.startsWith("- ") && inRemovals) {
      try { cfg.removals.push(new RegExp(cleanVal(line.slice(2)), "g")); } catch {}
      continue;
    }
    const m = /^([A-Za-z][A-Za-z0-9]*):\s*(.*)$/.exec(line);
    if (!m) continue;
    const [, key, val0] = m; const val = cleanVal(val0);
    if (indent === 0) { current = null; inRemovals = false; }
    if (styleKeys.has(key) && val0 === "") { current = key; continue; }
    if (key === "removals") { inRemovals = true; continue; }
    if (indent === 0) {
      if (key === "labelType" && ["long","short","none"].includes(val)) cfg.labelType = val as LabelType;
      else if (key === "coverThreshold") cfg.coverThreshold = Number(val) || cfg.coverThreshold;
      else if (key === "leaveTestPrefix") cfg.leaveTestPrefix = parseBool(val) ?? cfg.leaveTestPrefix;
    } else if (current && (cfg as any)[current]) {
      const st = (cfg as any)[current] as Style;
      const b = parseBool(val);
      if (b !== undefined) (st as any)[key] = b; else (st as any)[key] = val;
    }
  }
  return cfg;
}

function sgr(style: Style): string {
  const codes: number[] = [];
  if (style.foreground && colorMap[style.foreground] !== undefined) codes.push(colorMap[style.foreground]);
  if (style.bold) codes.push(1);
  if (style.faint) codes.push(2);
  if (style.italic) codes.push(3);
  if (style.underline) codes.push(4);
  if (style.inverse) codes.push(7);
  if (!codes.length) return "";
  return codes.map(c => `\x1b[${c}m`).join("");
}
function paint(text: string, style: Style): string { const s = sgr(style); return s ? s + text + "\x1b[0m" : text; }
function label(kind: string, cfg: Config): string {
  if (cfg.labelType === "none") return "";
  if (cfg.labelType === "short") {
    const map: Record<string,string> = { BUILD:"!!", START:">", PASS:"o", FAIL:"x", SKIP:"-", COVER:"%", BLANK:"" };
    return (map[kind] ?? "").padEnd(3, " ");
  }
  if (kind === "BLANK") return "     | ";
  return kind.padEnd(5, " ") + "| ";
}
function stripTestName(name: string, cfg: Config): string {
  if (cfg.leaveTestPrefix) return name;
  return name.split("/").map(p => p.startsWith("Test") ? p.slice(4) : p).join("/");
}
function indentFor(name: string): string { return "  ".repeat(Math.max(0, name.split("/").length - 1)); }
function progress(pct: number): string { const n = Math.floor(pct / 10 + 1e-9); return "[" + "#".repeat(Math.max(0, Math.min(10, n))) + "_".repeat(Math.max(0, 10 - Math.max(0, Math.min(10, n)))) + "]"; }

function applyRemovals(line: string, cfg: Config): string {
  let out = line;
  for (const r of cfg.removals) out = out.replace(r, "");
  return out;
}

function formatLine(input: string, cfg: Config, decorate: boolean, state?: {seen: boolean}): string | null {
  const line = applyRemovals(input, cfg);
  if (!decorate) return line;
  let m: RegExpMatchArray | null;
  if ((m = line.match(/^=== RUN\s+(.+)$/))) {
    const nm = stripTestName(m[1], cfg); return paint(label("START", cfg) + indentFor(m[1]) + nm, cfg.startStyle);
  }
  if ((m = line.match(/^--- PASS: (.+)$/))) {
    const rest = m[1]; const nm0 = rest.replace(/ \([^)]*\)$/, ""); const suffix = rest.slice(nm0.length);
    const nm = stripTestName(nm0, cfg); return paint(label("PASS", cfg) + indentFor(nm0) + nm + suffix, cfg.passStyle);
  }
  if ((m = line.match(/^--- FAIL: (.+)$/))) {
    const rest = m[1]; const nm0 = rest.replace(/ \([^)]*\)$/, ""); const suffix = rest.slice(nm0.length);
    const nm = stripTestName(nm0, cfg); return paint(label("FAIL", cfg) + indentFor(nm0) + nm + suffix, cfg.failStyle);
  }
  if ((m = line.match(/^--- SKIP: (.+)$/))) {
    const rest = m[1]; const nm0 = rest.replace(/ \([^)]*\)$/, ""); const suffix = rest.slice(nm0.length);
    const nm = stripTestName(nm0, cfg); return paint(label("SKIP", cfg) + indentFor(nm0) + nm + suffix, cfg.skipStyle);
  }
  if ((m = line.match(/^coverage:\s*([0-9.]+)%.*$/))) {
    const pct = Number(m[1]); const st = pct >= cfg.coverThreshold ? cfg.coveredStyle : cfg.uncoveredStyle;
    return paint(label("COVER", cfg) + `${m[1]}% ${progress(pct)}`, st);
  }
  if (line === "PASS") { if (state) state.seen = true; return cfg.passPackageStyle.hide ? null : paint("PASS", cfg.passPackageStyle); }
  if (line === "FAIL") { if (state) state.seen = true; return cfg.failPackageStyle.hide ? null : paint("FAIL", cfg.failPackageStyle); }
  if (line.startsWith("ok")) { if (state) state.seen = true;
    const parts = line.split("\t"); const pkg = parts[0].trim() === "ok" ? (parts[1] ?? "") : parts[0].replace(/^ok\s+/, ""); const cov = parts.find(p => p.startsWith("coverage:"));
    return paint(label("PASS", cfg) + pkg + " " + (cov ?? ""), cfg.passStyle);
  }
  if (line.startsWith("FAIL\t")) { if (state) state.seen = true; return paint(label("FAIL", cfg) + line.slice(4), cfg.failStyle); }
  if (line.startsWith("?   \t")) { if (state) state.seen = true; return paint(label("SKIP", cfg) + line.slice(5), cfg.skipStyle); }
  if ((m = line.match(/^(\s+)([^\s:]+\.go):(\d+):(.*)$/))) {
    return sgr(cfg.startStyle) + label("BLANK", cfg) + m[1] + paint(m[2], cfg.fileStyle) + paint(":" + m[3], cfg.lineStyle) + paint(":" + m[4], cfg.startStyle);
  }
  if (state && !state.seen) return label("BLANK", cfg) + line;
  return paint(label("BLANK", cfg) + line, cfg.startStyle);
}

function filterStream(input: any, output: any, cfg: Config, decorate: boolean, done?: () => void) {
  const rl = readline.createInterface({ input, crlfDelay: Infinity });
  const state = { seen: false };
  rl.on("line", (line) => { const out = formatLine(line, cfg, decorate, state); if (out !== null) output.write(out + "\n"); });
  rl.on("close", () => done && done());
}

function shouldDecorate(): boolean { return !!process.env.RICHGO_FORCE_COLOR || !!(process.stdout as any).isTTY; }
function panicNoGo() {
  process.stderr.write('panic: exec: "go": executable file not found in $PATH\n\ngoroutine 1 [running]:\nmain.main()\n\t/workspace/main.go:74 +0x465\n');
  process.exit(2);
}

function main() {
  const args = process.argv.slice(2);
  const cfg = loadConfig();
  const decorate = shouldDecorate();
  if (args[0] === "testfilter") {
    filterStream(process.stdin, process.stdout, cfg, decorate, () => process.exit(0));
    return;
  }
  const isTest = args[0] === "test";
  const child = spawn("go", args, { stdio: ["inherit", "pipe", "pipe"] });
  child.on("error", (e: any) => { if (e && e.code === "ENOENT") panicNoGo(); else { console.error(String(e)); process.exit(1); } });
  if (isTest) {
    filterStream(child.stdout!, process.stdout, cfg, decorate);
    filterStream(child.stderr!, process.stderr, cfg, decorate);
  } else {
    child.stdout!.pipe(process.stdout); child.stderr!.pipe(process.stderr);
  }
  child.on("close", (code, signal) => { if (signal) process.kill(process.pid, signal); else process.exit(code ?? 0); });
}
main();
