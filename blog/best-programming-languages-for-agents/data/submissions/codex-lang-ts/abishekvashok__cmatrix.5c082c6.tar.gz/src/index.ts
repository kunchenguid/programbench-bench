#!/usr/bin/env node
type Options = {
  asyncScroll: boolean;
  bold: 0 | 1 | 2;
  oldStyle: boolean;
  screensaver: boolean;
  lambda: boolean;
  rainbow: boolean;
  change: boolean;
  linux: boolean;
  lock: boolean;
  xterm: boolean;
  consoleMode: boolean;
  delay: number;
  color: string;
  message: string | null;
  tty: string | null;
};

const USAGE = ` Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
`;

const VERSION = ` CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)
Email: abishekvashok@gmail.com
Web: https://github.com/abishekvashok/cmatrix
`;

const COLOR_CODES: Record<string, number> = {
  black: 30,
  red: 31,
  green: 32,
  yellow: 33,
  blue: 34,
  magenta: 35,
  cyan: 36,
  white: 37
};

const RAINBOW = [31, 33, 32, 36, 34, 35, 37];
const GLYPHS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*+-=?/\\|[]{}()<>";
const KATAKANA = "日ﾊﾐﾋｰｳｼﾅﾓﾆｻﾜﾂｵﾘｱﾎﾃﾏｹﾒｴｶｷﾑﾕﾗｾﾈｽﾀﾇﾍ";

function write(s: string): void {
  process.stdout.write(s);
}

function usageAndExit(): void {
  write(USAGE);
  process.exit(0);
}

function parseArgs(argv: string[]): Options | "version" | "usage" | "badcolor" {
  const opt: Options = {
    asyncScroll: false,
    bold: 0,
    oldStyle: false,
    screensaver: false,
    lambda: false,
    rainbow: false,
    change: false,
    linux: false,
    lock: false,
    xterm: false,
    consoleMode: false,
    delay: 4,
    color: "green",
    message: null,
    tty: null
  };

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (!arg.startsWith("-") || arg === "-") return "usage";
    if (arg === "--help") return "usage";
    if (arg === "--version") return "usage";

    for (let pos = 1; pos < arg.length; pos++) {
      const ch = arg[pos];
      switch (ch) {
        case "a": opt.asyncScroll = true; break;
        case "b": if (opt.bold !== 2) opt.bold = 1; break;
        case "B": opt.bold = 2; break;
        case "c": opt.consoleMode = true; break;
        case "f": break;
        case "l": opt.linux = true; break;
        case "L": opt.lock = true; if (opt.message === null) opt.message = "Computer locked."; break;
        case "o": opt.oldStyle = true; break;
        case "h": case "?": return "usage";
        case "n": opt.bold = 0; break;
        case "s": opt.screensaver = true; break;
        case "x": opt.xterm = true; break;
        case "V": return "version";
        case "r": opt.rainbow = true; break;
        case "m": opt.lambda = true; break;
        case "k": opt.change = true; break;
        case "u": {
          if (pos !== arg.length - 1 || i + 1 >= argv.length) return "usage";
          const value = argv[++i];
          opt.delay = Number.parseInt(value, 10);
          pos = arg.length;
          break;
        }
        case "C": {
          if (pos !== arg.length - 1 || i + 1 >= argv.length) return "usage";
          const value = argv[++i].toLowerCase();
          if (!(value in COLOR_CODES)) return "badcolor";
          opt.color = value;
          pos = arg.length;
          break;
        }
        case "M": {
          if (pos !== arg.length - 1 || i + 1 >= argv.length) return "usage";
          opt.message = argv[++i];
          pos = arg.length;
          break;
        }
        case "t": {
          if (pos !== arg.length - 1 || i + 1 >= argv.length) return "usage";
          opt.tty = argv[++i];
          pos = arg.length;
          break;
        }
        default:
          return "usage";
      }
    }
  }
  return opt;
}

class Random {
  private state = (Date.now() ^ process.pid) >>> 0;
  next(): number {
    this.state = (1664525 * this.state + 1013904223) >>> 0;
    return this.state / 0x100000000;
  }
  int(max: number): number {
    return Math.floor(this.next() * max);
  }
}

function initTerminal(): void {
  write("\x1b[?1049h\x1b[22;0;0t\x1b[1;24r\x1b(B\x1b[m\x1b[4l\x1b[?7h\x1b[?25l");
  write("\x1b[39;49m\x1b[39;49m\x1b(B\x1b[m\x1b[H\x1b[2J");
}

function restoreTerminal(): void {
  write("\x1b[24;1H\x1b[?12l\x1b[?25h\x1b[?1049l\x1b[23;0;0t\r\x1b[?1l\x1b>");
}

function setupInput(onKey: (key: string) => void): void {
  if (!process.stdin.isTTY) return;
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.on("data", (buf: any) => {
    const s = Buffer.from(buf).toString("utf8");
    for (const key of s) onKey(key);
  });
}

function terminalSize(): { rows: number; cols: number } {
  const rows = Number(process.env.LINES) || process.stdout.rows || 24;
  const cols = Number(process.env.COLUMNS) || process.stdout.columns || 80;
  return { rows: Math.max(2, rows), cols: Math.max(2, cols) };
}

function runMatrix(opt: Options): void {
  const term = process.env.TERM || "unknown";
  if (term === "unknown" || term === "") {
    process.stderr.write("Error opening terminal: unknown.\n");
    process.exit(1);
  }

  const rnd = new Random();
  let { rows, cols } = terminalSize();
  const drops: number[] = [];
  const speeds: number[] = [];
  for (let c = 0; c < cols; c++) {
    drops[c] = -rnd.int(rows);
    speeds[c] = opt.asyncScroll ? 1 + rnd.int(3) : 1;
  }

  let frame = 0;
  let currentColor = opt.color;
  let stopped = false;
  const cleanup = () => {
    if (stopped) return;
    stopped = true;
    if (process.stdin.isTTY) {
      try { process.stdin.setRawMode(false); } catch {}
    }
    restoreTerminal();
  };
  process.on("SIGINT", () => { cleanup(); process.exit(0); });
  process.on("SIGTERM", () => { cleanup(); process.exit(0); });
  process.on("exit", cleanup);

  setupInput((key) => {
    if (opt.screensaver) { cleanup(); process.exit(0); }
    if (key === "q" && !opt.lock) { cleanup(); process.exit(0); }
    if (key >= "0" && key <= "9") opt.delay = Number(key);
    if (key === "a") opt.asyncScroll = !opt.asyncScroll;
    if (key === "b") opt.bold = 1;
    if (key === "B") opt.bold = 2;
    if (key === "n") opt.bold = 0;
    const map: Record<string, string> = { "!": "red", "@": "green", "#": "yellow", "$": "blue", "%": "magenta", "^": "cyan", "&": "white", ")": "black" };
    if (map[key]) currentColor = map[key];
  });

  initTerminal();

  const draw = () => {
    const size = terminalSize();
    if (size.rows !== rows || size.cols !== cols) {
      rows = size.rows;
      cols = size.cols;
      for (let c = 0; c < cols; c++) {
        if (drops[c] === undefined) drops[c] = -rnd.int(rows);
        if (speeds[c] === undefined) speeds[c] = opt.asyncScroll ? 1 + rnd.int(3) : 1;
      }
      write("\x1b[H\x1b[2J");
    }

    let out = "";
    if (opt.oldStyle) out += "\x1b[H";
    for (let c = 0; c < cols; c++) {
      const speed = opt.asyncScroll ? speeds[c] : 1;
      if (frame % speed !== 0) continue;
      const head = drops[c]++;
      const tail = head - (5 + rnd.int(Math.max(6, rows / 2)));
      const color = opt.rainbow ? RAINBOW[(c + frame) % RAINBOW.length] : COLOR_CODES[currentColor];
      if (tail >= 1 && tail <= rows) out += `\x1b[${tail};${c + 1}H `;
      if (head >= 1 && head <= rows) {
        const bright = opt.bold === 2 || (opt.bold === 1 && rnd.int(3) === 0);
        const glyph = opt.lambda ? "λ" : (opt.consoleMode ? KATAKANA[rnd.int(KATAKANA.length)] : GLYPHS[rnd.int(GLYPHS.length)]);
        out += `\x1b[${head};${c + 1}H\x1b[${bright ? "1;" : ""}${color}m${glyph}\x1b[0m`;
      }
      if (head > rows + 20) {
        drops[c] = -rnd.int(rows);
        speeds[c] = opt.asyncScroll ? 1 + rnd.int(3) : 1;
      }
    }

    const msg = opt.message;
    if (msg) {
      const row = Math.max(1, Math.floor(rows / 2));
      const col = Math.max(1, Math.floor((cols - msg.length) / 2));
      out += `\x1b[${row};${col}H\x1b[37m${msg}\x1b[0m`;
    }
    write(out);
    frame++;
  };

  draw();
  const interval = Math.max(8, opt.delay * 12 + 8);
  setInterval(draw, interval);
}

const parsed = parseArgs(process.argv.slice(2));
if (parsed === "usage") usageAndExit();
if (parsed === "version") {
  write(VERSION);
  process.exit(0);
}
if (parsed === "badcolor") {
  write(" Invalid color selection\n Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n");
  process.exit(0);
}
runMatrix(parsed as Options);
