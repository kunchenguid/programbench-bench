declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");
const child_process = require("child_process");

const BLUE = "\x1b[0;34m";
const RED = "\x1b[0;31m";
const RESET = "\x1b[0m";

type Vaults = { current?: string; vaults: Record<string, string> };
type VData = { name: string; location: string; folder: string; history: string[] };

function home(): string {
  return process.env.HOME || process.env.USERPROFILE || ".";
}

function dataDir(): string {
  return path.join(home(), ".local", "share", "jot");
}

function configDir(): string {
  return path.join(home(), ".config", "jot");
}

function vaultsFile(): string {
  return path.join(dataDir(), "vaults");
}

function configFile(): string {
  return path.join(configDir(), "config");
}

function ensureBase() {
  fs.mkdirSync(dataDir(), { recursive: true });
  fs.mkdirSync(configDir(), { recursive: true });
  if (!fs.existsSync(vaultsFile())) fs.writeFileSync(vaultsFile(), "[vaults]\n");
  if (!fs.existsSync(configFile())) fs.writeFileSync(configFile(), "editor = 'nvim'\nconflict = true\n");
}

function parseTomlish(file: string): Record<string, string> {
  if (!fs.existsSync(file)) return {};
  const out: Record<string, string> = {};
  for (const raw of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("[") || line.startsWith("#")) continue;
    const m = line.match(/^([A-Za-z0-9_-]+)\s*=\s*(.*)$/);
    if (!m) continue;
    let v = m[2].trim();
    if ((v.startsWith("'") && v.endsWith("'")) || (v.startsWith('"') && v.endsWith('"'))) v = v.slice(1, -1);
    out[m[1]] = v;
  }
  return out;
}

function loadVaults(): Vaults {
  ensureBase();
  const parsed = parseTomlish(vaultsFile());
  const current = parsed.current;
  delete parsed.current;
  return { current, vaults: parsed };
}

function saveVaults(v: Vaults) {
  let s = "";
  if (v.current) s += `current = '${v.current}'\n\n`;
  s += "[vaults]\n";
  for (const k of Object.keys(v.vaults)) s += `${k} = '${v.vaults[k]}'\n`;
  fs.writeFileSync(vaultsFile(), s);
}

function vaultRoot(name: string, loc: string): string {
  return path.join(loc, name);
}

function dataFile(name: string, loc: string): string {
  return path.join(vaultRoot(name, loc), ".jot", "data");
}

function saveVData(d: VData) {
  const file = dataFile(d.name, d.location);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `name = '${d.name}'\nlocation = '${d.location}'\nfolder = '${d.folder}'\nhistory = []\n`);
}

function loadVData(name: string, loc: string): VData {
  const p = parseTomlish(dataFile(name, loc));
  return { name, location: loc, folder: p.folder || "", history: [] };
}

function err(msg: string) {
  console.log(`${RED}error${RESET}: ${msg}`);
}

function c(s: string): string {
  return `${BLUE}${s}${RESET}`;
}

function itemType(t: string): string {
  if (t === "vault" || t === "vl") return "vault";
  if (t === "note" || t === "nt") return "note";
  if (t === "folder" || t === "fd") return "folder";
  return t;
}

function currentData(): { all: Vaults; data: VData; root: string } | undefined {
  const all = loadVaults();
  if (!all.current || !all.vaults[all.current]) {
    err("not inside a vault");
    return undefined;
  }
  const data = loadVData(all.current, all.vaults[all.current]);
  return { all, data, root: vaultRoot(data.name, data.location) };
}

function currentFolder(d: VData): string {
  return path.join(vaultRoot(d.name, d.location), d.folder);
}

function notePath(dir: string, name: string): string {
  return path.join(dir, name.endsWith(".md") ? name : `${name}.md`);
}

function displayNoteName(file: string): string {
  return file.endsWith(".md") ? file.slice(0, -3) : file;
}

function resolveFolder(root: string, folder: string, target: string): string {
  const base = path.isAbsolute(target) ? root : path.join(root, folder);
  return path.normalize(path.join(base, target));
}

function inside(root: string, p: string): boolean {
  const rel = path.relative(root, p);
  return rel === "" || (!rel.startsWith("..") && !path.isAbsolute(rel));
}

function helpMain(exitCode = 0) {
  console.log(`${BLUE}________      _____ 
______(_)_______  /_
_____  /_  __ \\  __/
____  / / /_/ / /_  
___  /  \\____/\\__/  
/___/         ᵥ₀.₁.₂  
${RESET}         

usage: jt <command>

${BLUE}commands:${RESET}

create items
    ${c("vault")}, ${c("vl")}       create a vault or list vaults
    create items in current folder
        ${c("note")}, ${c("nt")}        create a note 
        ${c("folder")}, ${c("fd")}      create a folder

interact with items
    ${c("enter")}, ${c("en")}       enter a vault
    ${c("open")}, ${c("op")}        open a note from current folder
    ${c("opdir")}, ${c("od")}       open current folder in file explorer
    ${c("chdir")}, ${c("cd")}       change folder within current vault
    ${c("list")}, ${c("ls")}        list items in current folder

perform fs operations on items
    ${c("remove")}, ${c("rm")}      remove an item 
    ${c("rename")}, ${c("rn")}      rename an item 
    ${c("move")}, ${c("mv")}        move an item to a new location
    ${c("vmove")}, ${c("vm")}       move an item to a different vault

config
    ${c("config")}, ${c("cf")}      display, set or open config

get help 
    use ${c("help")} or ${c("-h")} and ${c("--help")} flags along with a command to get corresponding help`);
  process.exit(exitCode);
}

const helpText: Record<string, string> = {
  vault: "executable-vault \ncreate a vault or list vaults\n\nUSAGE:\n    jt vault\n    jt vault -l\n    jt vault <vault name> <vault location>\n\nARGS:\n    <vault name>        name for new vault\n    <vault location>    absolute path to location of new vault\n\nOPTIONS:\n    -l            show vaults' location\n    -h, --help    Print help information",
  note: "executable-note \ncreate a note\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nARGS:\n    <note name>    name for new note (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information",
  folder: "executable-folder \ncreate a folder\n\nUSAGE:\n    jt folder\n    jt folder [folder name]\n\nARGS:\n    <folder name>    name for new folder (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information",
  enter: "executable-enter \nenter a vault\n\nUSAGE:\n    executable enter <vault name>\n\nARGS:\n    <vault name>    name of the vault to enter\n\nOPTIONS:\n    -h, --help    Print help information",
  open: "executable-open \nopen a note (from the current folder)\n\nUSAGE:\n    executable open <note name>\n\nARGS:\n    <note name>    name of note to be opened\n\nOPTIONS:\n    -h, --help    Print help information",
  opdir: "executable-opdir \nopen current folder in file explorer\n\nUSAGE:\n    executable opdir\n\nOPTIONS:\n    -h, --help    Print help information",
  chdir: "executable-chdir \nchange folder within current vault\n\nUSAGE:\n    executable chdir <folder path>\n\nARGS:\n    <folder path>    path to folder to switch to (from current folder)\n\nOPTIONS:\n    -h, --help    Print help information",
  list: "executable-list \nlist items in current folder\n\nUSAGE:\n    executable list [item type]\n\nARGS:\n    <item type>    \n\nOPTIONS:\n    -h, --help    Print help information",
  remove: "executable-remove \nremove an item\n\nUSAGE:\n    executable remove <item type> <name>\n\nARGS:\n    <item type>    remove a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be removed\n\nOPTIONS:\n    -h, --help    Print help information",
  rename: "executable-rename \nrename an item\n\nUSAGE:\n    executable rename <item type> <name> <new name>\n\nARGS:\n    <item type>    rename a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be renamed\n    <new name>     new name of item\n\nOPTIONS:\n    -h, --help    Print help information",
  move: "executable-move \nmove an item\n\nUSAGE:\n    executable move <item type> <name> <new location>\n\nARGS:\n    <item type>       move a vault (or vl) | note (or nt) | folder (or fd)\n    <name>            name of item to be moved\n    <new location>    path to new location of item (current folder as root in case of note or\n                      folder)\n\nOPTIONS:\n    -h, --help    Print help information",
  vmove: "executable-vmove \nmove notes and folders to a different vault\n\nUSAGE:\n    executable vmove <item type> <name> <vault name>\n\nARGS:\n    <item type>     move a note (or nt) | folder (or fd)\n    <name>          name of item to be moved\n    <vault name>    name of vault to move the item to\n\nOPTIONS:\n    -h, --help    Print help information",
  config: "executable-config \ndisplay, set or open config\n\nUSAGE:\n    jt config <config type>\n    jt config <config type> [config value]\n\nARGS:\n    <config type>     name of config item to display or set\n    <config value>    pass a value if config needs to be updated\n\nOPTIONS:\n    -h, --help    Print help information"
};

function maybeHelp(cmd: string, args: string[]) {
  if (args.includes("-h") || args.includes("--help")) {
    console.log(helpText[cmd] || "");
    process.exit(0);
  }
}

function cmdVault(args: string[]) {
  maybeHelp("vault", args);
  const v = loadVaults();
  if (args.length === 0 || (args.length === 1 && args[0] === "-l")) {
    for (const name of Object.keys(v.vaults)) {
      if (args[0] === "-l") console.log(`   ${name} \t ${v.vaults[name]}`);
      else console.log(`   ${name}`);
    }
    return;
  }
  if (args.length !== 2) return clapExtra(args[2] || "");
  const [name, loc] = args;
  if (!path.isAbsolute(loc)) return err("specified path isn't absolute");
  if (!fs.existsSync(loc)) return err("couldn't find the path specified");
  if (v.vaults[name]) return err(`vault ${name} already exists`);
  fs.mkdirSync(path.join(loc, name, ".jot"), { recursive: true });
  v.vaults[name] = loc;
  saveVaults(v);
  saveVData({ name, location: loc, folder: "", history: [] });
  console.log(`vault ${c(name)} created`);
}

function cmdEnter(args: string[]) {
  maybeHelp("enter", args);
  const name = args[0];
  const v = loadVaults();
  if (!name || !v.vaults[name]) return err(`vault ${name} doesn't exist`);
  v.current = name;
  saveVaults(v);
  saveVData(loadVData(name, v.vaults[name]));
  console.log(`entered ${c(name)}`);
}

function cmdCreate(kind: "note" | "folder", args: string[]) {
  maybeHelp(kind, args);
  const name = args[0];
  if (!name) return;
  const cur = currentData();
  if (!cur) return;
  const dir = currentFolder(cur.data);
  if (kind === "note") {
    const p = notePath(dir, name);
    if (fs.existsSync(p)) return err(`a note named ${displayNoteName(path.basename(p))} already exists in this location`);
    fs.writeFileSync(p, "");
  } else {
    const p = path.join(dir, name);
    if (fs.existsSync(p)) return err(`a folder named ${name} already exists in this location`);
    fs.mkdirSync(p, { recursive: false });
  }
  console.log(`${kind} ${c(name)} created`);
}

function cmdChdir(args: string[]) {
  maybeHelp("chdir", args);
  const cur = currentData();
  if (!cur) return;
  const target = args[0] || "";
  const p = resolveFolder(cur.root, cur.data.folder, target);
  if (!inside(cur.root, p) || !fs.existsSync(p) || !fs.statSync(p).isDirectory()) return err("couldn't find the path specified");
  cur.data.folder = path.relative(cur.root, p);
  if (cur.data.folder === ".") cur.data.folder = "";
  saveVData(cur.data);
  console.log("folder changed");
}

function entriesFor(dir: string, filter?: string): { name: string; full: string; isDir: boolean; isNote: boolean }[] {
  if (!fs.existsSync(dir)) return [];
  const list = fs.readdirSync(dir).filter((n: string) => n !== ".jot").map((n: string) => {
    const full = path.join(dir, n);
    const st = fs.statSync(full);
    return { name: n, full, isDir: st.isDirectory(), isNote: st.isFile() && n.endsWith(".md") };
  }).filter((e: any) => !filter || (filter === "note" ? e.isNote : filter === "folder" ? e.isDir : true));
  list.sort((a: any, b: any) => a.name.localeCompare(b.name));
  return list;
}

function printTree(root: string, dir: string, title: string, filter?: string, prefix = "") {
  if (prefix === "") console.log(title);
  const ents = entriesFor(dir, filter);
  ents.forEach((e: any, i: number) => {
    const last = i === ents.length - 1;
    const label = e.isNote ? c(displayNoteName(e.name)) : e.name;
    console.log(`${prefix}${last ? "└── " : "├── "}${label}`);
    if (e.isDir && !filter) printTree(root, e.full, title, undefined, `${prefix}${last ? "    " : "│   "}`);
  });
}

function cmdList(args: string[]) {
  maybeHelp("list", args);
  const cur = currentData();
  if (!cur) return;
  const f = itemType(args[0] || "");
  const title = cur.data.folder ? `${cur.data.name} > ${cur.data.folder.split(path.sep).join(" > ")}` : cur.data.name;
  printTree(cur.root, currentFolder(cur.data), title, f === "note" || f === "folder" ? f : undefined);
}

function locate(kind: string, dir: string, name: string): string {
  return kind === "note" ? notePath(dir, name) : path.join(dir, name);
}

function cmdRemove(args: string[]) {
  maybeHelp("remove", args);
  const kind = itemType(args[0] || "");
  const name = args[1];
  if (kind === "vault") {
    const all = loadVaults();
    if (!all.vaults[name]) return err(`vault ${name} doesn't exist`);
    fs.rmSync(vaultRoot(name, all.vaults[name]), { recursive: true, force: true });
    delete all.vaults[name];
    if (all.current === name) delete all.current;
    saveVaults(all);
    console.log(`vault ${c(name)} removed`);
    return;
  }
  const cur = currentData();
  if (!cur) return;
  const p = locate(kind, currentFolder(cur.data), name);
  if (!fs.existsSync(p)) return err("couldn't find the path specified");
  fs.rmSync(p, { recursive: true, force: true });
  console.log(`${kind} ${c(name)} removed`);
}

function cmdRename(args: string[]) {
  maybeHelp("rename", args);
  const kind = itemType(args[0] || "");
  const name = args[1], nn = args[2];
  if (kind === "vault") {
    const all = loadVaults();
    if (!all.vaults[name]) return err(`vault ${name} doesn't exist`);
    if (all.vaults[nn]) return err(`vault ${nn} already exists`);
    const oldLoc = all.vaults[name];
    fs.renameSync(vaultRoot(name, oldLoc), vaultRoot(nn, oldLoc));
    delete all.vaults[name];
    all.vaults[nn] = oldLoc;
    if (all.current === name) all.current = nn;
    saveVaults(all);
    saveVData({ name: nn, location: all.vaults[nn], folder: "", history: [] });
    console.log(`vault ${c(name)} renamed to ${c(nn)}`);
    return;
  }
  const cur = currentData();
  if (!cur) return;
  const dir = currentFolder(cur.data);
  const from = locate(kind, dir, name);
  const to = locate(kind, dir, nn);
  if (!fs.existsSync(from)) return err("couldn't find the path specified");
  fs.renameSync(from, to);
  console.log(`${kind} ${c(name)} renamed to ${c(nn)}`);
}

function cmdMove(args: string[]) {
  maybeHelp("move", args);
  const kind = itemType(args[0] || "");
  const name = args[1], dest = args[2];
  if (kind === "vault") {
    const all = loadVaults();
    if (!all.vaults[name]) return err(`vault ${name} doesn't exist`);
    if (!path.isAbsolute(dest)) return err("specified path isn't absolute");
    if (!fs.existsSync(dest)) return err("couldn't find the path specified");
    fs.renameSync(vaultRoot(name, all.vaults[name]), vaultRoot(name, dest));
    all.vaults[name] = dest;
    saveVaults(all);
    saveVData({ name, location: dest, folder: "", history: [] });
    console.log(`vault ${c(name)} moved`);
    return;
  }
  const cur = currentData();
  if (!cur) return;
  const from = locate(kind, currentFolder(cur.data), name);
  const toDir = resolveFolder(cur.root, cur.data.folder, dest);
  if (!fs.existsSync(from) || !inside(cur.root, toDir) || !fs.existsSync(toDir) || !fs.statSync(toDir).isDirectory()) return err("couldn't find the path specified");
  fs.renameSync(from, path.join(toDir, path.basename(from)));
  console.log(`${kind} ${c(name)} moved`);
}

function cmdVMove(args: string[]) {
  maybeHelp("vmove", args);
  const kind = itemType(args[0] || "");
  const name = args[1], vault = args[2];
  const cur = currentData();
  if (!cur) return;
  if (!cur.all.vaults[vault]) return err(`vault ${vault} doesn't exist`);
  const from = locate(kind, currentFolder(cur.data), name);
  if (!fs.existsSync(from)) return err("couldn't find the path specified");
  const to = path.join(vaultRoot(vault, cur.all.vaults[vault]), path.basename(from));
  fs.renameSync(from, to);
  console.log(`${kind} ${c(name)} moved to vault ${c(vault)}`);
}

function loadConfig(): Record<string, string> {
  ensureBase();
  const c = parseTomlish(configFile());
  return { editor: c.editor || "nvim", conflict: c.conflict || "true" };
}

function saveConfig(cf: Record<string, string>) {
  fs.writeFileSync(configFile(), `editor = '${cf.editor}'\nconflict = ${cf.conflict}\n`);
}

function cmdConfig(args: string[]) {
  maybeHelp("config", args);
  const cf = loadConfig();
  if (args.length === 0) {
    try { child_process.spawnSync(cf.editor, [configFile()], { stdio: "inherit" }); } catch (_) {}
    return;
  }
  const key = args[0];
  if (key !== "editor" && key !== "conflict") {
    console.log(`error: "${key}" isn't a valid value for '<config type>'\n\t[possible values: editor, conflict]\n\nFor more information try --help`);
    process.exit(2);
  }
  if (args.length === 1) console.log(`${key}: ${c(String(cf[key]))}`);
  else {
    cf[key] = args[1];
    saveConfig(cf);
    console.log(`set ${c(key)} to ${c(args[1])}`);
  }
}

function cmdOpen(args: string[]) {
  maybeHelp("open", args);
  const cur = currentData();
  if (!cur) return;
  const p = notePath(currentFolder(cur.data), args[0] || "");
  if (!fs.existsSync(p)) return err("couldn't find the path specified");
  const cf = loadConfig();
  child_process.spawnSync(cf.editor, [p], { stdio: "inherit" });
}

function cmdOpdir(args: string[]) {
  maybeHelp("opdir", args);
  const cur = currentData();
  if (!cur) return;
  const dir = currentFolder(cur.data);
  const opener = process.platform === "darwin" ? "open" : "xdg-open";
  child_process.spawnSync(opener, [dir], { stdio: "inherit" });
}

function clapExtra(arg: string) {
  console.log(`error: Found argument '${arg}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help`);
  process.exit(2);
}

function main() {
  ensureBase();
  const argv = process.argv.slice(2);
  if (argv.length === 0 || argv[0] === "--help" || argv[0] === "-h") helpMain(argv.length === 0 ? 2 : 0);
  let cmd = argv[0];
  const args = argv.slice(1);
  if (cmd === "help") {
    const h = args[0] || "";
    const canonical = aliases[h] || h;
    if (canonical && helpText[canonical]) console.log(helpText[canonical]);
    else helpMain(0);
    return;
  }
  cmd = aliases[cmd] || cmd;
  switch (cmd) {
    case "vault": return cmdVault(args);
    case "enter": return cmdEnter(args);
    case "note": return cmdCreate("note", args);
    case "folder": return cmdCreate("folder", args);
    case "chdir": return cmdChdir(args);
    case "list": return cmdList(args);
    case "remove": return cmdRemove(args);
    case "rename": return cmdRename(args);
    case "move": return cmdMove(args);
    case "vmove": return cmdVMove(args);
    case "config": return cmdConfig(args);
    case "open": return cmdOpen(args);
    case "opdir": return cmdOpdir(args);
    default: return clapExtra(cmd);
  }
}

const aliases: Record<string, string> = {
  vl: "vault", en: "enter", nt: "note", fd: "folder", cd: "chdir", ls: "list",
  rm: "remove", rn: "rename", mv: "move", vm: "vmove", cf: "config", op: "open", od: "opdir"
};

main();
