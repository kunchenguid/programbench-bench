declare const require: any;
declare const process: any;
declare const Buffer: any;
declare const console: any;

const fs = require("fs");
const path = require("path");

type Heading = {
  level: number;
  text: string;
  line: number;
  offset: number;
  id: string;
  slug: string;
  endLine: number;
  contentRaw: string;
  children: Heading[];
};

type CodeBlock = { type: "code"; language: string | null; content: string; start_line: number; end_line: number; raw: string };
type Link = { type: "link"; text: string; url: string; link_type: string };
type Image = { type: "image"; alt: string; url: string };
type ListBlock = { type: "list"; ordered: boolean; items: any[]; raw?: string };
type Table = { type: "table"; rows: string[][]; raw: string };
type Blockquote = { type: "blockquote"; content: string; raw: string };

const VERSION = "treemd 0.5.7";

function shortHelp(): string {
  return `A markdown navigator with tree-based structural navigation

Usage: executable [OPTIONS] [FILE]... [COMMAND]

Commands:
  at-line  Show heading at specific line number
  help     Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]...  Markdown file(s) to view (.md or .markdown), directory, or '-' for stdin

Options:
  -l, --list                   List all headings in the document (non-interactive)
      --tree                   Show heading tree structure with box-drawing characters (non-interactive)
      --filter <PATTERN>       Filter headings by text pattern (case-insensitive)
  -L, --level <LEVEL>          Show only headings at specific level (1-6)
  -o, --output <OUTPUT>        Output format for --list and --tree modes [default: plain] [possible values: plain, json, tree]
  -s, --section <HEADING>      Extract specific section by heading name
      --count                  Count headings by level (shows statistics)
      --setup-completions      Set up shell completions interactively
      --theme <THEME>          Set theme for TUI mode
      --color-mode <MODE>      Force color mode (auto, rgb, 256) [possible values: auto, rgb, 256]
      --no-images              Disable image rendering in TUI mode
      --images                 Enable image rendering in TUI mode (override config)
  -q, --query <EXPR>           Query expression for selecting/filtering document elements
      --query-help             Show query language documentation and examples
      --query-output <FORMAT>  Output format for query results
  -h, --help                   Print help (see more with '--help')
  -V, --version                Print version`;
}

function longHelp(): string {
  return `treemd - A modern markdown viewer combining tree-based navigation with interactive TUI.

Launch without flags for interactive mode with dual-pane interface, vim-style navigation,
syntax highlighting, and real-time search. Use flags for CLI mode to extract, filter,
and analyze markdown structure.

Examples:
  treemd README.md              # Interactive TUI mode
  treemd -l README.md           # List all headings
  treemd --tree README.md       # Show heading tree
  treemd -s Installation doc.md # Extract section
  treemd --setup-completions    # Set up shell completions

${shortHelp()}`;
}

function queryHelp(): string {
  return `treemd Query Language (tql)

A jq-like query language for navigating and extracting markdown structure.

ELEMENT SELECTORS
    .h, .heading    All headings (any level)
    .h1 - .h6       Headings by level
    .code           All code blocks
    .code[rust]     Code blocks by language
    .link, .a       All links
    .link[external] External links only
    .img            All images
    .table          All tables
    .list           All lists
    .blockquote     All blockquotes

FILTERS & INDEXING
    .h2[Features]       Heading containing "Features" (fuzzy)
    .h2["Installation"] Heading with exact text
    .h2[0]              First h2
    .h2[-1]             Last h2
    .h2[1:3]            h2s at index 1 and 2
    .h2[:3]             First 3 h2s

PIPES
    .h2 | text          Get heading text (strips ##)
    [.h2] | count       Count all h2s
    .code | lang        Get code block languages
    .link | url         Get link URLs

OUTPUT FORMATS (--query-output)
    plain       Human-readable text (default)
    json        Compact JSON
    json-pretty Pretty-printed JSON (alias: jsonp)
    jsonl       Line-delimited JSON (one per line)
    md          Raw markdown
    tree        Tree structure`;
}

function slugify(s: string): string {
  return s.toLowerCase().trim().replace(/[^\p{L}\p{N}\s-]/gu, "").replace(/\s+/g, "-").replace(/-+/g, "-");
}

function stripHeading(line: string): { level: number; text: string } | null {
  const m = /^(#{1,6})[ \t]+(.+?)[ \t]*$/.exec(line);
  if (!m) return null;
  let text = m[2].replace(/[ \t]+#+[ \t]*$/, "").trim();
  if (!text) return null;
  return { level: m[1].length, text };
}

function parseMarkdown(input: string) {
  const normalized = input.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = normalized.split("\n");
  const headings: Heading[] = [];
  let inFence = false;
  let fence = "";
  let offset = 0;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const fm = /^(\s*)(`{3,}|~{3,})/.exec(line);
    if (fm) {
      const mark = fm[2][0];
      if (!inFence) {
        inFence = true;
        fence = mark;
      } else if (mark === fence) {
        inFence = false;
      }
    }
    if (!inFence) {
      const h = stripHeading(line);
      if (h) {
        const slug = slugify(h.text);
        headings.push({ level: h.level, text: h.text, line: i + 1, offset, id: slug, slug, endLine: lines.length, contentRaw: "", children: [] });
      }
    }
    offset += Buffer.byteLength(line, "utf8") + (i < lines.length - 1 ? 1 : 0);
  }
  for (let i = 0; i < headings.length; i++) {
    const h = headings[i];
    let end = lines.length + 1;
    for (let j = i + 1; j < headings.length; j++) {
      if (headings[j].level <= h.level) {
        end = headings[j].line;
        break;
      }
    }
    h.endLine = end - 1;
    const childLines = new Set<number>();
    for (let j = i + 1; j < headings.length; j++) {
      const c = headings[j];
      if (c.line >= end) break;
      if (c.level > h.level) {
        for (let k = c.line; k <= c.endLine; k++) childLines.add(k);
      }
    }
    const content: string[] = [];
    for (let ln = h.line + 1; ln < end; ln++) {
      if (!childLines.has(ln)) content.push(lines[ln - 1] ?? "");
    }
    h.contentRaw = trimBlankLines(content).join("\n");
  }
  return { input: normalized, lines, headings, tree: buildTree(headings), blocks: parseBlocks(normalized), links: parseLinks(normalized), images: parseImages(normalized) };
}

function trimBlankLines(lines: string[]): string[] {
  let a = 0, b = lines.length;
  while (a < b && lines[a].trim() === "") a++;
  while (b > a && lines[b - 1].trim() === "") b--;
  return lines.slice(a, b);
}

function buildTree(headings: Heading[]): Heading[] {
  const roots: Heading[] = [];
  const stack: Heading[] = [];
  for (const h of headings) {
    h.children = [];
    while (stack.length && stack[stack.length - 1].level >= h.level) stack.pop();
    if (stack.length) stack[stack.length - 1].children.push(h); else roots.push(h);
    stack.push(h);
  }
  return roots;
}

function parseBlocks(md: string): any[] {
  const lines = md.split("\n");
  const blocks: any[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const fence = /^```([^`]*)\s*$|^~~~([^~]*)\s*$/.exec(line);
    if (fence) {
      const lang = (fence[1] ?? fence[2] ?? "").trim() || null;
      const start = i + 1;
      const body: string[] = [];
      i++;
      while (i < lines.length && !/^```|^~~~/.test(lines[i])) body.push(lines[i++]);
      blocks.push({ type: "code", language: lang, content: trimTrailingNewline(body.join("\n")), start_line: start + 1, end_line: i, raw: `${line}\n${body.join("\n")}\n${lines[i] ?? ""}` });
      continue;
    }
    if (/^\s*[-*+]\s+/.test(line) || /^\s*\d+[.)]\s+/.test(line)) {
      const ordered = /^\s*\d+[.)]\s+/.test(line);
      const items: any[] = [];
      const raw: string[] = [];
      while (i < lines.length && (/^\s*[-*+]\s+/.test(lines[i]) || /^\s*\d+[.)]\s+/.test(lines[i]))) {
        raw.push(lines[i]);
        const item = lines[i].replace(/^\s*(?:[-*+]|\d+[.)])\s+/, "");
        const cb = /^\[([ xX])\]\s+(.*)$/.exec(item);
        const content = cb ? cb[2] : item;
        items.push({ checked: cb ? cb[1].toLowerCase() === "x" : null, content, inline: parseInline(content) });
        i++;
      }
      i--;
      blocks.push({ type: "list", ordered, items, raw: raw.join("\n") });
      continue;
    }
    if (/^\s*>/.test(line)) {
      const raw: string[] = [];
      while (i < lines.length && /^\s*>/.test(lines[i])) raw.push(lines[i++]);
      i--;
      blocks.push({ type: "blockquote", content: raw.map((x) => x.replace(/^\s*>\s?/, "")).join("\n"), raw: raw.join("\n") });
      continue;
    }
    if (line.includes("|") && i + 1 < lines.length && /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(lines[i + 1])) {
      const raw: string[] = [line, lines[++i]];
      while (i + 1 < lines.length && lines[i + 1].includes("|") && lines[i + 1].trim()) raw.push(lines[++i]);
      const rows = raw.filter((_, idx) => idx !== 1).map((r) => r.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim()));
      blocks.push({ type: "table", rows, raw: raw.join("\n") });
      continue;
    }
    if (line.trim() && !stripHeading(line)) {
      const para: string[] = [line];
      while (i + 1 < lines.length && lines[i + 1].trim() && !stripHeading(lines[i + 1]) && !/^```|^~~~/.test(lines[i + 1]) && !/^\s*[-*+]\s+/.test(lines[i + 1])) para.push(lines[++i]);
      const content = para.join("\n");
      blocks.push({ type: "paragraph", content, inline: parseInline(content) });
    }
  }
  return blocks;
}

function parseInline(s: string): any[] {
  const out: any[] = [];
  const re = /!?\[([^\]]*)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g;
  let last = 0, m: RegExpExecArray | null;
  while ((m = re.exec(s))) {
    if (m.index > last) out.push({ type: "text", value: s.slice(last, m.index) });
    if (s[m.index] === "!") out.push({ type: "image", alt: m[1], url: m[2], title: m[3] ?? null });
    else out.push({ type: "link", text: m[1], url: m[2], title: m[3] ?? null });
    last = re.lastIndex;
  }
  if (last < s.length) out.push({ type: "text", value: s.slice(last) });
  return out.length ? out : [{ type: "text", value: s }];
}

function parseLinks(md: string): Link[] {
  const links: Link[] = [];
  const re = /(?<!!)\[([^\]]+)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(md))) links.push({ type: "link", text: m[1], url: m[2], link_type: /^(https?:)?\/\//i.test(m[2]) ? "external" : m[2].startsWith("#") ? "anchor" : "relative" });
  return links;
}

function parseImages(md: string): Image[] {
  const imgs: Image[] = [];
  const re = /!\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(md))) imgs.push({ type: "image", alt: m[1], url: m[2] });
  return imgs;
}

function trimTrailingNewline(s: string): string {
  return s.replace(/\n+$/, "");
}

function filteredHeadings(headings: Heading[], filter?: string, level?: number): Heading[] {
  return headings.filter((h) => (!level || h.level === level) && (!filter || h.text.toLowerCase().includes(filter.toLowerCase())));
}

function printList(headings: Heading[]): string {
  return headings.map((h) => `${"#".repeat(h.level)} ${h.text}`).join("\n");
}

function printTree(nodes: Heading[], prefix = ""): string[] {
  const lines: string[] = [];
  nodes.forEach((h, idx) => {
    const last = idx === nodes.length - 1;
    lines.push(`${prefix}${last ? "└──" : "├──"}${"#".repeat(h.level)} ${h.text}`);
    lines.push(...printTree(h.children, prefix + (last ? "   " : "│  ")));
  });
  return lines;
}

function sectionJson(h: Heading): any {
  return {
    id: h.id, level: h.level, title: h.text, slug: h.slug,
    position: { line: h.line + 1, offset: h.offset + Buffer.byteLength(`${"#".repeat(h.level)} ${h.text}\n`, "utf8") },
    content: { raw: h.contentRaw, blocks: parseBlocks(h.contentRaw).map(cleanBlock) },
    children: h.children.map(sectionJson)
  };
}

function cleanBlock(b: any): any {
  const c = { ...b };
  delete c.raw;
  return c;
}

function wordCount(md: string): number {
  const words = md.match(/[\p{L}\p{N}_'-]+/gu);
  return words ? words.length : 0;
}

function documentJson(parsed: any): any {
  return { document: { metadata: { source: null, headingCount: parsed.headings.length, maxDepth: Math.max(0, ...parsed.headings.map((h: Heading) => h.level)), wordCount: wordCount(parsed.input) }, sections: parsed.tree.map(sectionJson) } };
}

function readInputs(files: string[]): string {
  if (files.length === 0 || files.includes("-")) {
    try { return fs.readFileSync(0, "utf8"); } catch { return ""; }
  }
  const chunks: string[] = [];
  for (const f of files) {
    try {
      const st = fs.statSync(f);
      if (st.isDirectory()) {
        const mds = fs.readdirSync(f).filter((n: string) => /\.(md|markdown)$/i.test(n)).sort();
        for (const name of mds) chunks.push(fs.readFileSync(path.join(f, name), "utf8"));
      } else {
        chunks.push(fs.readFileSync(f, "utf8"));
      }
    } catch (e: any) {
      console.error(`Error reading input: I/O error: ${e.message}`);
      process.exit(1);
    }
  }
  return chunks.join("\n");
}

function findSection(headings: Heading[], name: string, lines: string[]): string | null {
  const needle = name.toLowerCase();
  const h = headings.find((x) => x.text.toLowerCase() === needle) ?? headings.find((x) => x.text.toLowerCase().includes(needle));
  if (!h) return null;
  return trimBlankLines(lines.slice(h.line - 1, h.endLine)).join("\n");
}

function queryElements(expr: string, parsed: any): any[] {
  let q = expr.trim();
  if (q.startsWith("[") && q.includes("]")) q = q.slice(1, q.indexOf("]")) + q.slice(q.indexOf("]") + 1);
  q = q.split("|")[0].trim();
  const child = q.includes(">") || q.includes(">>");
  if (child) q = q.split(/>{1,2}/).pop()!.trim();
  let selector = q;
  let bracket: string | null = null;
  const bm = /^([.\w]+)\[(.*)\]$/.exec(q);
  if (bm) { selector = bm[1]; bracket = bm[2].replace(/^["']|["']$/g, ""); }
  let arr: any[];
  if (selector === "." || selector === "") arr = [{ type: "document", ...parsed }];
  else if (selector === ".h" || selector === ".heading") arr = parsed.headings.map((h: Heading) => ({ type: "heading", level: h.level, text: h.text, line: h.line, heading: h }));
  else if (/^\.h[1-6]$/.test(selector)) {
    const lvl = Number(selector.slice(2));
    arr = parsed.headings.filter((h: Heading) => h.level === lvl).map((h: Heading) => ({ type: "heading", level: h.level, text: h.text, line: h.line, heading: h }));
  } else if (selector === ".code") arr = parsed.blocks.filter((b: any) => b.type === "code").map((b: CodeBlock) => ({ type: "code", language: b.language, content: b.content, start_line: 1, end_line: 1, raw: b.raw }));
  else if (selector === ".link" || selector === ".a") arr = parsed.links;
  else if (selector === ".img" || selector === ".image") arr = parsed.images;
  else if (selector === ".list") arr = parsed.blocks.filter((b: any) => b.type === "list");
  else if (selector === ".table") arr = parsed.blocks.filter((b: any) => b.type === "table");
  else if (selector === ".blockquote") arr = parsed.blocks.filter((b: any) => b.type === "blockquote");
  else arr = [];
  if (bracket !== null) {
    if (/^-?\d+$/.test(bracket)) {
      const idx = Number(bracket);
      arr = [arr[idx < 0 ? arr.length + idx : idx]].filter(Boolean);
    } else if (/^-?\d*:-?\d*$/.test(bracket)) {
      const [a, b] = bracket.split(":");
      arr = arr.slice(a ? Number(a) : undefined, b ? Number(b) : undefined);
    } else if (bracket.toLowerCase() === "external") arr = arr.filter((x) => x.link_type === "external");
    else arr = arr.filter((x) => JSON.stringify(x).toLowerCase().includes(bracket!.toLowerCase()));
  }
  return arr;
}

function applyPipe(expr: string, items: any[], parsed: any): any {
  const pipes = expr.split("|").slice(1).map((p) => p.trim()).filter(Boolean);
  let cur: any = items;
  for (const p of pipes) {
    const name = p.replace(/\(.*\)$/, "");
    const arg = /\((.*)\)$/.exec(p)?.[1]?.replace(/^["']|["']$/g, "");
    if (["count", "length", "len", "size"].includes(name)) cur = Array.isArray(cur) ? cur.length : String(cur).length;
    else if (name === "text") cur = asArray(cur).map(plainTextOf);
    else if (name === "url" || name === "href" || name === "src") cur = asArray(cur).map((x) => x.url ?? x.src ?? "");
    else if (name === "lang") cur = asArray(cur).map((x) => x.language ?? "");
    else if (name === "content") cur = asArray(cur).map((x) => x.content ?? x.heading?.contentRaw ?? "");
    else if (name === "md") cur = asArray(cur).map(markdownOf);
    else if (name === "upper") cur = asArray(cur).map((x) => String(x).toUpperCase());
    else if (name === "lower") cur = asArray(cur).map((x) => String(x).toLowerCase());
    else if (name === "trim") cur = asArray(cur).map((x) => String(x).trim());
    else if (name === "slugify") cur = asArray(cur).map((x) => slugify(String(x)));
    else if (name === "first" || name === "head") cur = asArray(cur).slice(0, 1);
    else if (name === "last") cur = asArray(cur).slice(-1);
    else if (name === "reverse") cur = asArray(cur).slice().reverse();
    else if (name === "sort") cur = asArray(cur).slice().sort((a, b) => textOf(a).localeCompare(textOf(b)));
    else if (name === "unique") cur = [...new Set(asArray(cur).map((x) => typeof x === "string" ? x : JSON.stringify(x)))];
    else if (name === "levels") cur = levelStats(parsed.headings);
    else if (name === "langs") cur = countBy(parsed.blocks.filter((b: any) => b.type === "code").map((b: any) => b.language ?? ""));
    else if (name === "types") cur = countBy(parsed.links.map((l: Link) => l.link_type));
    else if (name === "stats") cur = { headings: parsed.headings.length, maxDepth: Math.max(0, ...parsed.headings.map((h: Heading) => h.level)), words: wordCount(parsed.input), links: parsed.links.length, codeBlocks: parsed.blocks.filter((b: any) => b.type === "code").length };
    else if ((name === "limit" || name === "take") && arg) cur = asArray(cur).slice(0, Number(arg));
    else if ((name === "skip" || name === "drop") && arg) cur = asArray(cur).slice(Number(arg));
    else if (name === "nth" && arg) cur = [asArray(cur)[Number(arg)]].filter(Boolean);
    else if (name === "select" || name === "where" || name === "filter") {
      const cm = /contains\(["'](.+)["']\)/.exec(p) || /includes\(["'](.+)["']\)/.exec(p);
      if (cm) cur = asArray(cur).filter((x) => textOf(x).toLowerCase().includes(cm[1].toLowerCase()));
    }
  }
  return cur;
}

function asArray(x: any): any[] { return Array.isArray(x) ? x : [x]; }
function plainTextOf(x: any): string { return x?.type === "heading" ? x.text : typeof x === "string" ? x : x?.text ?? x?.content ?? JSON.stringify(x); }
function textOf(x: any): string { return x?.type === "heading" ? `${"#".repeat(x.level)} ${x.text}` : x?.type === "link" ? `[${x.text}](${x.url})` : x?.type === "code" ? `\`\`\`${x.language ?? ""}\n${x.content}\n\`\`\`` : typeof x === "string" ? x : x?.text ?? x?.content ?? JSON.stringify(x); }
function markdownOf(x: any): string { return x?.type === "heading" ? `${"#".repeat(x.level)} ${x.text}` : x?.raw ?? textOf(x); }
function levelStats(headings: Heading[]): any { const o: any = {}; for (const h of headings) o[h.level] = (o[h.level] ?? 0) + 1; return o; }
function countBy(vals: string[]): any { const o: any = {}; for (const v of vals) o[v] = (o[v] ?? 0) + 1; return o; }

function outputQuery(result: any, fmt: string): string {
  const arr = asArray(result);
  if (fmt === "json") return JSON.stringify(Array.isArray(result) && result.length === 1 ? result[0] : result);
  if (fmt === "jsonl") return arr.map((x) => JSON.stringify(cleanQueryObject(x))).join("\n");
  if (fmt === "json-pretty") return JSON.stringify(Array.isArray(result) && result.length === 1 ? result[0] : result, replacer, 2);
  if (fmt === "md") return arr.map(markdownOf).join("\n");
  if (fmt === "tree") return arr.map(textOf).join("\n");
  if (typeof result === "number") return String(result);
  return arr.map(textOf).join("\n");
}

function cleanQueryObject(x: any): any {
  if (!x || typeof x !== "object") return x;
  const c: any = {};
  for (const k of Object.keys(x)) if (k !== "heading" && k !== "raw") c[k] = x[k];
  return c;
}
function replacer(k: string, v: any) { return k === "heading" || k === "raw" ? undefined : v; }

function parseArgs(argv: string[]) {
  const opts: any = { files: [], output: "plain", queryOutput: "plain" };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h") opts.help = "short";
    else if (a === "--help") opts.help = "long";
    else if (a === "-V" || a === "--version") opts.version = true;
    else if (a === "-l" || a === "--list") opts.list = true;
    else if (a === "--tree") opts.tree = true;
    else if (a === "--count") opts.count = true;
    else if (a === "--query-help") opts.queryHelp = true;
    else if (a === "--setup-completions") opts.setupCompletions = true;
    else if (a === "--no-images" || a === "--images") { /* accepted */ }
    else if (a === "--filter") opts.filter = argv[++i] ?? "";
    else if (a === "-L" || a === "--level") opts.level = Number(argv[++i]);
    else if (a === "-o" || a === "--output") opts.output = argv[++i] ?? "plain";
    else if (a === "-s" || a === "--section") opts.section = argv[++i] ?? "";
    else if (a === "-q" || a === "--query") opts.query = argv[++i] ?? "";
    else if (a === "--query-output") opts.queryOutput = argv[++i] ?? "plain";
    else if (a === "--theme" || a === "--color-mode") i++;
    else if (a === "help") opts.help = "long";
    else if (a === "at-line") { opts.atLine = Number(argv[++i]); }
    else opts.files.push(a);
  }
  return opts;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.version) return console.log(VERSION);
  if (opts.queryHelp) return console.log(queryHelp());
  if (opts.help) return console.log(opts.help === "long" ? longHelp() : shortHelp());
  if (opts.output && !["plain", "json", "tree"].includes(opts.output)) {
    console.error(`error: invalid value '${opts.output}' for '--output <OUTPUT>'\n  [possible values: plain, json, tree]\n\nFor more information, try '--help'.`);
    process.exit(2);
  }
  if (opts.setupCompletions) return console.log("Shell completions setup is not available in this environment.");
  const input = readInputs(opts.files);
  const parsed = parseMarkdown(input);
  if (opts.atLine) {
    const h = [...parsed.headings].reverse().find((x) => x.line <= opts.atLine);
    if (h) console.log(`${"#".repeat(h.level)} ${h.text}`);
    return;
  }
  if (opts.section !== undefined) {
    const s = findSection(parsed.headings, opts.section, parsed.lines);
    if (s == null) { console.error(`Section '${opts.section}' not found`); process.exit(1); }
    console.log(s);
    return;
  }
  if (opts.count) {
    const counts = levelStats(parsed.headings);
    console.log("Heading counts:");
    for (let i = 1; i <= 6; i++) if (counts[i]) console.log(`  ${"#".repeat(i)}: ${counts[i]}`);
    console.log(`\nTotal: ${parsed.headings.length}`);
    return;
  }
  if (opts.query !== undefined) {
    if (opts.queryOutput === "jsonp") opts.queryOutput = "json-pretty";
    const elems = queryElements(opts.query, parsed).map(cleanQueryObject);
    const res = applyPipe(opts.query, elems, parsed);
    console.log(outputQuery(res, opts.queryOutput));
    return;
  }
  if (opts.list || opts.tree) {
    const hs = filteredHeadings(parsed.headings, opts.filter, opts.level);
    if (opts.output === "json") {
      if (opts.list) console.log(JSON.stringify(documentJson({ ...parsed, headings: hs, tree: buildTree(hs) }), null, 2));
      else console.log(JSON.stringify(hs.map((h) => ({ level: h.level, text: h.text })), null, 2));
    } else if (opts.output === "tree" || opts.tree) console.log(printTree(buildTree(hs)).join("\n"));
    else console.log(printList(hs));
    return;
  }
  if (input.trim()) {
    console.log(printList(parsed.headings));
    return;
  }
  console.error("Failed to enable raw mode: Cannot open /dev/tty: No such device or address (os error 6). Interactive mode requires a terminal.");
  process.exit(1);
}

main();
