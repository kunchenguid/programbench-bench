declare function require(name: string): any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");

type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue };

const VERSION = "1.4.1";

const c = {
  reset: "\x1b[39m\x1b[49m",
  key: "\x1b[94m\x1b[49m",
  string: "\x1b[32m\x1b[49m",
  number: "\x1b[96m\x1b[49m",
  bool: "\x1b[93m\x1b[49m",
  header: "\x1b[36m\x1b[49m",
  bold: "\x1b[1m",
  unbold: "\x1b[22m",
  reverse: "\x1b[7m",
  unreverse: "\x1b[27m",
};

function writeHelp(): void {
  process.stdout.write(`  json-tui {OPTIONS} [file]

    A JSON terminal UI

  OPTIONS:

      file                              A JSON file. Omit to read from stdin.
      -h, --help                        Display this help menu.
      -v, --version                     Print version.
      -k, --key, --keybinding           Display key binding.
      -f, --fullscreen                  Display the JSON in fullscreen, in an
                                        alternate buffer
      "--" can be used to terminate flag options and force all following
      arguments to be treated as positional options

    If no file is given, json-tui reads JSON from the standard input
    Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues
`);
}

function writeKeybinding(): void {
  const h = c.header;
  const r = c.reset;
  const lines = [
    "┌───────────┬────────────────┐",
    `│${h}keys       ${r}│${h}action          ${r}│`,
    "├───────────┼────────────────┤",
    "│Navigate   │← ↑ ↓ →         │",
    "│           │h j k l         │",
    "│           │Mouse::WheelUp  │",
    "│           │Mouse::WheelDown│",
    "├───────────┼────────────────┤",
    "│Toggle     │enter           │",
    "│           │Mouse::Left     │",
    "├───────────┼────────────────┤",
    "│Deep       │                │",
    "│ - Expand  │+               │",
    "│ - Collapse│-               │",
    "├───────────┼────────────────┤",
    "│Exit       │Escape          │",
    "│           │q               │",
    "├───────────┼────────────────┤",
    "│Navigate   │                │",
    "│ - first   │page-up         │",
    "│ - last    │page-down       │",
    "│ - top     │gg              │",
    "│ - bottom  │G               │",
    "└───────────┴────────────────┘",
  ];
  process.stdout.write(lines.join("\r\n") + "\0\n");
}

interface Options {
  fullscreen: boolean;
  file?: string;
}

function parseArgs(argv: string[]): Options | "help" | "version" | "keys" | "invalid" {
  const files: string[] = [];
  let fullscreen = false;
  let positional = false;
  for (const arg of argv) {
    if (positional) {
      files.push(arg);
      continue;
    }
    if (arg === "--") {
      positional = true;
    } else if (arg === "-h" || arg === "--help") {
      return "help";
    } else if (arg === "-v" || arg === "--version") {
      return "version";
    } else if (arg === "-k" || arg === "--key" || arg === "--keybinding") {
      return "keys";
    } else if (arg === "-f" || arg === "--fullscreen") {
      fullscreen = true;
    } else if (arg.startsWith("-")) {
      return "invalid";
    } else {
      files.push(arg);
    }
  }
  if (files.length > 1) return "invalid";
  return { fullscreen, file: files[0] };
}

function readStdin(): string {
  process.stdout.write("Reading from stdin...\0");
  return fs.readFileSync(0, "utf8");
}

function classifyParseError(input: string, err: unknown): string {
  const msg = err instanceof Error ? err.message : String(err);
  const posMatch = msg.match(/position\s+(\d+)/);
  let pos = posMatch ? Number(posMatch[1]) : 0;
  if (!posMatch) {
    const tokenMatch = msg.match(/Unexpected token '?(.)'?/);
    if (tokenMatch) {
      const found = input.indexOf(tokenMatch[1]);
      if (found >= 0) pos = found;
    }
  }
  const prefix = input.slice(0, Math.max(0, pos + 1));
  const lines = prefix.split(/\n/);
  const line = lines.length;
  const column = Math.max(1, lines[lines.length - 1].length);
  const last = input.slice(0, Math.min(input.length, pos + 1)).replace(/\n/g, "\\n");
  return `[json.exception.parse_error.101] parse error at line ${line}, column ${column}: syntax error while parsing value - invalid literal; last read: '${last}'`;
}

function visibleLength(s: string): number {
  return s.replace(/\x1b\[[0-9;?]*[A-Za-z]/g, "").replace(/\0/g, "").length;
}

function padVisible(s: string, width: number): string {
  return s + " ".repeat(Math.max(0, width - visibleLength(s)));
}

function primitive(v: JsonValue): string {
  if (v === null) return `${c.bold}null${c.unbold}`;
  if (typeof v === "string") return `${c.string}${JSON.stringify(v)}${c.reset}`;
  if (typeof v === "number") return `${c.number}${String(v)}${c.reset}`;
  if (typeof v === "boolean") return `${c.bool}${String(v)}${c.reset}`;
  return "";
}

function render(value: JsonValue, indent = 0, expandedDepth = 1): string[] {
  const sp = " ".repeat(indent);
  if (value === null || typeof value !== "object") return [sp + primitive(value)];
  if (Array.isArray(value)) {
    if (value.length === 0) return [sp + "[]"];
    if (expandedDepth <= 0) return [sp + `${c.bold}[...]${c.unbold}`];
    const out = [sp + "["];
    value.forEach((item, i) => {
      const child = render(item, indent + 2, expandedDepth - 1);
      child[child.length - 1] += i + 1 === value.length ? "" : ",";
      out.push(...child);
    });
    out.push(sp + "]");
    return out;
  }
  const entries = Object.entries(value);
  if (entries.length === 0) return [sp + "{}"];
  if (expandedDepth <= 0) return [sp + `${c.bold}{...}${c.unbold}`];
  const out = [sp + "{"];
  entries.forEach(([key, item], i) => {
    const comma = i + 1 === entries.length ? "" : ",";
    if (item !== null && typeof item === "object") {
      const summary = Array.isArray(item) ? "[...]" : "{...}";
      out.push(`${" ".repeat(indent + 2)}${c.key}${JSON.stringify(key)}${c.reset}: ${c.bold}${summary}${comma}${c.unbold}`);
    } else {
      out.push(`${" ".repeat(indent + 2)}${c.key}${JSON.stringify(key)}${c.reset}: ${primitive(item)}${comma}`);
    }
  });
  out.push(sp + "}");
  return out;
}

function renderFull(value: JsonValue): string[] {
  return render(value, 0, 20);
}

function writeScreen(value: JsonValue, fullscreen: boolean): void {
  const rows = process.stdout.rows || 24;
  const cols = process.stdout.columns || 80;
  const lines = render(value, 0, 1);
  if (fullscreen) process.stdout.write("\x1b[?1049h");
  process.stdout.write("\0\x1b[?7l\x1b[?1000h\x1b[?1003h\x1b[?1015h\x1b[?1006h\0\r");
  const view = lines.slice(0, Math.max(1, rows - 1));
  view.forEach((line, i) => {
    const selected = i === 0 && line.length > 0 ? c.reverse + line[0] + c.unreverse + line.slice(1) : line;
    process.stdout.write("\x1b[2K" + padVisible(selected, Math.min(cols, Math.max(visibleLength(line), 1))) + (i + 1 < view.length ? "\r\n" : ""));
  });
  process.stdout.write(`\x1b[${Math.max(0, view.length - 1)}A\x1b[?25l\0`);
}

function cleanup(fullscreen: boolean): void {
  process.stdout.write("\x1b[?1006l\x1b[?1015l\x1b[?1003l\x1b[?1000l\x1b[?7h\x1b[?25h\x1b[1 q\0\r\n");
  if (fullscreen) process.stdout.write("\x1b[?1049l");
}

function interactive(value: JsonValue, fullscreen: boolean): void {
  if (!process.stdin.isTTY) {
    process.stdout.write(renderFull(value).join("\n") + "\n");
    return;
  }
  writeScreen(value, fullscreen);
  const stdin = process.stdin;
  stdin.setRawMode(true);
  stdin.resume();
  stdin.on("data", (buf: any) => {
    const s = buf.toString("utf8");
    if (s === "q" || s === "\u001b" || s === "\u0003") {
      stdin.setRawMode(false);
      cleanup(fullscreen);
      process.exit(0);
    }
  });
}

function main(): void {
  const args = parseArgs(process.argv.slice(2));
  if (args === "help") return writeHelp();
  if (args === "version") return process.stdout.write(VERSION + "\n");
  if (args === "keys") return writeKeybinding();
  if (args === "invalid") {
    process.stderr.write("Invalid arguments\n");
    process.exit(1);
  }
  const opts = args as Options;

  let text = "";
  if (opts.file) {
    try {
      text = fs.readFileSync(opts.file, "utf8");
    } catch {
      process.stderr.write(`Could not open file ${opts.file}\n`);
      process.exit(1);
    }
  } else {
    text = readStdin();
  }

  let json: JsonValue = null;
  try {
    json = JSON.parse(text) as JsonValue;
  } catch (err) {
    process.stderr.write(classifyParseError(text, err) + "\n");
    process.exit(1);
  }
  interactive(json, opts.fullscreen);
}

main();
