declare const require: any;
declare const process: any;
declare const setTimeout: any;
const { spawnSync } = require('child_process');
const fs = require('fs');

const VERSION = 'hwatch 0.3.19';
const DESC = 'A modern alternative to the watch command, records the differences in execution results and can check this differences at after.';
const HEADER_COLOR = '\x1b[38;5;240m';
const RESET = '\x1b[0m';

type OutputMode = 'output' | 'stdout' | 'stderr';
type DiffMode = 'none' | 'watch' | 'line' | 'word';

interface Options {
  batch: boolean;
  beep: boolean;
  border: boolean;
  scrollbar: boolean;
  mouse: boolean;
  color: boolean;
  reverse: boolean;
  compress: boolean;
  noTitle: boolean;
  enableSummaryChar: boolean;
  lineNumber: boolean;
  noHelpBanner: boolean;
  noSummary: boolean;
  execDirect: boolean;
  diffOutputOnly: boolean;
  precise: boolean;
  aftercommand?: string;
  logfile?: string;
  shell: string;
  interval: number;
  limit: number;
  tabSize: number;
  differences: DiffMode;
  output: OutputMode;
  keymaps: string[];
  command: string[];
}

interface RunResult {
  timestamp: string;
  command: string;
  status: boolean;
  output: string;
  stdout: string;
  stderr: string;
}

function help(): string {
  return `${DESC}\n\nUsage: executable [OPTIONS] [command]...\n\nArguments:\n  [command]...  \n\nOptions:\n  -b, --batch                         output execution results to stdout\n  -B, --beep                          beep if command has a change result\n      --border                        Surround each pane with a border frame\n      --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.\n      --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.\n  -c, --color                         interpret ANSI color and style sequences\n  -r, --reverse                       display text upside down.\n  -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.\n  -t, --no-title                      hide the UI on start. Use \`t\` to toggle it.\n      --enable-summary-char           collect character-level diff count in summary.\n  -N, --line-number                   show line number\n      --no-help-banner                hide the "Display help with h key" message\n      --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.\n  -x, --exec                          Run the command directly, not through the shell. Much like the \`-x\` option of the watch command.\n  -O, --diff-output-only              Display only the lines with differences during \`line\` diff and \`word\` diff.\n  -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable \${HWATCH_DATA}.\n  -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.\n  -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {COMMAND}. [default: "sh -c"]\n  -n, --interval <interval>           seconds to wait between updates [default: 2]\n      --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run\n  -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set \`0\` for unlimited recording. (default: 5000) [default: 5000]\n      --tab-size <tab_size>           Specifying tab display size [default: 4]\n  -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]\n  -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]\n  -K, --keymap <keymap>               Add keymap\n  -h, --help                          Print help\n  -V, --version                       Print version\n`;
}

function tokenizeEnv(s: string): string[] {
  const out: string[] = [];
  let cur = '';
  let quote = '';
  let esc = false;
  for (const ch of s) {
    if (esc) { cur += ch; esc = false; continue; }
    if (ch === '\\') { esc = true; continue; }
    if (quote) {
      if (ch === quote) quote = ''; else cur += ch;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (/\s/.test(ch)) { if (cur) { out.push(cur); cur = ''; } continue; }
    cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

function parseFloatLike(raw: string): number | null {
  const normalized = raw.replace(',', '.');
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(normalized)) return null;
  const n = Number(normalized);
  return Number.isFinite(n) ? Math.max(n, 0.001) : null;
}

function parseIntLike(raw: string): number | null {
  if (!/^[+-]?\d+$/.test(raw)) return null;
  const n = Number(raw);
  return Number.isSafeInteger(n) ? n : null;
}

function parse(argv0: string[]): Options | 'help' | 'version' {
  const argv = [...tokenizeEnv(process.env.HWATCH || ''), ...argv0];
  const opt: Options = {
    batch: false, beep: false, border: false, scrollbar: false, mouse: false,
    color: false, reverse: false, compress: false, noTitle: false,
    enableSummaryChar: false, lineNumber: false, noHelpBanner: false,
    noSummary: false, execDirect: false, diffOutputOnly: false, precise: false,
    shell: 'sh -c', interval: 2, limit: 5000, tabSize: 4,
    differences: 'none', output: 'output', keymaps: [], command: []
  };

  let i = 0;
  outer: while (i < argv.length) {
    const a = argv[i];
    if (a === '--') { opt.command = argv.slice(i + 1); break; }
    if (!a.startsWith('-') || a === '-') { opt.command = argv.slice(i); break; }
    switch (a) {
      case '-h': case '--help': return 'help';
      case '-V': case '--version': return 'version';
      case '-b': case '--batch': opt.batch = true; i++; break;
      case '-B': case '--beep': opt.beep = true; i++; break;
      case '--border': opt.border = true; i++; break;
      case '--with-scrollbar': opt.scrollbar = true; i++; break;
      case '--mouse': opt.mouse = true; i++; break;
      case '-c': case '--color': opt.color = true; i++; break;
      case '-r': case '--reverse': opt.reverse = true; i++; break;
      case '-C': case '--compress': opt.compress = true; i++; break;
      case '-t': case '--no-title': opt.noTitle = true; i++; break;
      case '--enable-summary-char': opt.enableSummaryChar = true; i++; break;
      case '-N': case '--line-number': opt.lineNumber = true; i++; break;
      case '--no-help-banner': opt.noHelpBanner = true; i++; break;
      case '--no-summary': opt.noSummary = true; i++; break;
      case '-x': case '-e': case '--exec': opt.execDirect = true; i++; break;
      case '-O': case '--diff-output-only': opt.diffOutputOnly = true; i++; break;
      case '--precise': opt.precise = true; i++; break;
      case '-A': case '--aftercommand': opt.aftercommand = needValue(argv, ++i, a); i++; break;
      case '-s': case '--shell': opt.shell = needValue(argv, ++i, a); i++; break;
      case '-K': case '--keymap': opt.keymaps.push(needValue(argv, ++i, a)); i++; break;
      case '-l': case '--logfile': {
        const next = argv[i + 1];
        if (next && !next.startsWith('-')) { opt.logfile = next; i += 2; } else { opt.logfile = 'hwatch.log'; i++; }
        break;
      }
      case '-n': case '--interval': {
        const val = needValue(argv, ++i, a);
        const n = parseFloatLike(val);
        if (n === null) die(`error: invalid value '${val}' for '--interval <interval>': invalid float literal\n\nFor more information, try '--help'.`);
        opt.interval = n; i++; break;
      }
      case '-L': case '--limit': {
        const val = needValue(argv, ++i, a);
        const n = parseIntLike(val);
        if (n === null) die(`error: invalid value '${val}' for '--limit <limit>': invalid digit found in string\n\nFor more information, try '--help'.`);
        opt.limit = n; i++; break;
      }
      case '--tab-size': {
        const val = needValue(argv, ++i, a);
        const n = parseIntLike(val);
        if (n === null) die(`error: invalid value '${val}' for '--tab-size <tab_size>': invalid digit found in string\n\nFor more information, try '--help'.`);
        opt.tabSize = n; i++; break;
      }
      case '-d': case '--differences': {
        const next = argv[i + 1];
        if (next && ['none','watch','line','word'].includes(next)) { opt.differences = next as DiffMode; i += 2; }
        else if (next && !next.startsWith('-')) die(`error: invalid value '${next}' for '--differences [<differences>]'\n  [possible values: none, watch, line, word]\n\nFor more information, try '--help'.`);
        else { opt.differences = 'watch'; i++; }
        break;
      }
      case '-o': case '--output': {
        const next = argv[i + 1];
        if (next && ['output','stdout','stderr'].includes(next)) { opt.output = next as OutputMode; i += 2; }
        else if (next && !next.startsWith('-')) die(`error: invalid value '${next}' for '--output [<output>]'\n  [possible values: output, stdout, stderr]\n\nFor more information, try '--help'.`);
        else { opt.output = 'output'; i++; }
        break;
      }
      default:
        if (a.startsWith('--aftercommand=')) { opt.aftercommand = a.slice(15); i++; break; }
        if (a.startsWith('--logfile=')) { opt.logfile = a.slice(10); i++; break; }
        if (a.startsWith('--shell=')) { opt.shell = a.slice(8); i++; break; }
        if (a.startsWith('--keymap=')) { opt.keymaps.push(a.slice(9)); i++; break; }
        if (a.startsWith('--interval=')) { const val = a.slice(11); const n = parseFloatLike(val); if (n === null) die(`error: invalid value '${val}' for '--interval <interval>': invalid float literal\n\nFor more information, try '--help'.`); opt.interval = n; i++; break; }
        if (a.startsWith('--limit=')) { const val = a.slice(8); const n = parseIntLike(val); if (n === null) die(`error: invalid value '${val}' for '--limit <limit>': invalid digit found in string\n\nFor more information, try '--help'.`); opt.limit = n; i++; break; }
        if (a.startsWith('--tab-size=')) { const val = a.slice(11); const n = parseIntLike(val); if (n === null) die(`error: invalid value '${val}' for '--tab-size <tab_size>': invalid digit found in string\n\nFor more information, try '--help'.`); opt.tabSize = n; i++; break; }
        if (a.startsWith('--differences=')) { const val = a.slice(14); if (!['none','watch','line','word'].includes(val)) die(`error: invalid value '${val}' for '--differences [<differences>]'\n  [possible values: none, watch, line, word]\n\nFor more information, try '--help'.`); opt.differences = val as DiffMode; i++; break; }
        if (a.startsWith('--output=')) { const val = a.slice(9); if (!['output','stdout','stderr'].includes(val)) die(`error: invalid value '${val}' for '--output [<output>]'\n  [possible values: output, stdout, stderr]\n\nFor more information, try '--help'.`); opt.output = val as OutputMode; i++; break; }
        opt.command = argv.slice(i);
        break outer;
    }
  }
  return opt;
}

function needValue(argv: string[], i: number, flag: string): string {
  if (i >= argv.length) die(`error: a value is required for '${flag}' but none was supplied\n\nFor more information, try '--help'.`);
  return argv[i];
}

function die(msg: string): void {
  process.stderr.write(msg + (msg.endsWith('\n') ? '' : '\n'));
  process.exit(2);
}

function pad(n: number, w = 2): string { return String(n).padStart(w, '0'); }
function timestamp(d = new Date()): string {
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}`;
}

function commandString(opt: Options): string { return opt.command.join(' '); }

function runCommand(opt: Options): RunResult {
  const ts = timestamp();
  const command = commandString(opt);
  let res;
  if (opt.execDirect) {
    const [cmd, ...args] = opt.command;
    res = spawnSync(cmd, args, { encoding: 'utf8', maxBuffer: 1024 * 1024 * 100 });
  } else {
    const shell = opt.shell;
    if (shell.includes('{COMMAND}')) {
      res = spawnSync(shell.replaceAll('{COMMAND}', command), { shell: true, encoding: 'utf8', maxBuffer: 1024 * 1024 * 100 });
    } else {
      const parts = shell.trim().split(/\s+/);
      const cmd = parts.shift() || 'sh';
      res = spawnSync(cmd, [...parts, command], { encoding: 'utf8', maxBuffer: 1024 * 1024 * 100 });
    }
  }
  const stdout = (res.stdout || '').toString();
  const stderr = (res.stderr || '').toString();
  const err = res.error ? String(res.error.message) + '\n' : '';
  const fullErr = stderr + err;
  return { timestamp: ts, command, status: (res.status ?? 1) === 0 && !res.error, output: stdout + fullErr, stdout, stderr: fullErr };
}

function selected(r: RunResult, opt: Options): string {
  if (opt.output === 'stdout') return r.stdout;
  if (opt.output === 'stderr') return r.stderr;
  return r.output;
}

function decorateOutput(s: string, opt: Options): string {
  let out = s.replace(/\t/g, ' '.repeat(Math.max(0, opt.tabSize)));
  if (opt.reverse) out = out.split('\n').reverse().join('\n');
  if (opt.lineNumber) {
    const lines = out.split('\n');
    out = lines.map((line, idx) => `${HEADER_COLOR}${idx + 1}${RESET}${HEADER_COLOR} | ${RESET}${line}`).join('\n');
  }
  return out;
}

function printRecord(r: RunResult, opt: Options): void {
  process.stdout.write(`${HEADER_COLOR}=====[${r.timestamp}]=========================${RESET}\n`);
  process.stdout.write(decorateOutput(selected(r, opt), opt));
  if (!selected(r, opt).endsWith('\n')) process.stdout.write('\n');
  process.stdout.write('\n');
}

function appendLog(path: string, r: RunResult): void {
  fs.appendFileSync(path, JSON.stringify(r) + '\n');
}

function replayLog(path: string, opt: Options): void {
  if (!fs.existsSync(path) || fs.statSync(path).size === 0) die('error: command not specified and logfile is empty.\n\nUsage: hwatch [OPTIONS] [command]...\n\nFor more information, try \'--help\'.');
  const lines = fs.readFileSync(path, 'utf8').split(/\r?\n/).filter(Boolean);
  for (const line of lines) {
    try {
      const r = JSON.parse(line) as RunResult;
      if (r.timestamp) printRecord(r, opt);
    } catch { /* ignore malformed log lines */ }
  }
}

function sleep(ms: number): Promise<void> { return new Promise(resolve => setTimeout(resolve, ms)); }

async function main() {
  const parsed = parse(process.argv.slice(2));
  if (parsed === 'help') { process.stdout.write(help()); return; }
  if (parsed === 'version') { process.stdout.write(VERSION + '\n'); return; }
  const opt = parsed;

  if (opt.command.length === 0) {
    if (opt.logfile) replayLog(opt.logfile, opt);
    else die('error: command not specified and logfile is empty.\n\nUsage: hwatch [OPTIONS] [command]...\n\nFor more information, try \'--help\'.');
    return;
  }

  let last = '';
  let first = true;
  if (opt.logfile && (!fs.existsSync(opt.logfile) || fs.statSync(opt.logfile).size === 0)) {
    appendLog(opt.logfile, { timestamp: '', command: '', status: true, output: '', stdout: '', stderr: '' });
  }

  let stopping = false;
  process.on('SIGTERM', () => { stopping = true; process.exit(124); });
  process.on('SIGINT', () => { stopping = true; process.exit(130); });

  const loopForever = opt.batch || process.stdout.isTTY;
  do {
    const started = Date.now();
    const r = runCommand(opt);
    const cur = selected(r, opt);
    const changed = first || cur !== last;
    printRecord(r, opt);
    if (opt.logfile && changed) appendLog(opt.logfile, r);
    if (!first && changed && opt.aftercommand) {
      spawnSync(opt.aftercommand, { shell: true, stdio: 'inherit', env: { ...process.env, HWATCH_DATA: JSON.stringify(r) } });
    }
    if (opt.beep && !first && changed) process.stdout.write('\x07');
    first = false;
    last = cur;
    if (!loopForever) break;
    const wait = Math.max(1, opt.interval * 1000 - (opt.precise ? (Date.now() - started) : 0));
    await sleep(wait);
  } while (!stopping);
}

main().catch(err => { process.stderr.write(String(err && err.stack || err) + '\n'); process.exit(1); });
