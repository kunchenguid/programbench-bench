declare const process: any;
declare function require(name: string): any;

const fs = require('fs');
const path = require('path');
const os = require('os');

interface Config {
  ignoreSigs: string[];
  ignoreSigRegexps: RegExp[];
  ignorePackageGlobs: string[];
  ignoreInterfaceRegexps: RegExp[];
  reportInternalErrors: boolean;
}

interface Diagnostic { file: string; line: number; col: number; msg: string; text?: string }

const DEFAULT_IGNORES = [
  '.Errorf(', 'errors.New(', 'errors.Unwrap(', 'errors.Join(', '.Wrap(', '.Wrapf(',
  '.WithMessage(', '.WithMessagef(', '.WithStack(',
];
const MSG = 'error returned from external package is unwrapped';

function usage(exitCode = 0): void {
  const out = `wrapcheck: Checks that errors returned from external packages are wrapped\n\nUsage: wrapcheck [-flag] [package]\n\n\nFlags:\n  -V\tprint version and exit\n  -all\n    \tno effect (deprecated)\n  -c int\n    \tdisplay offending line with this many lines of context (default -1)\n  -cpuprofile string\n    \twrite CPU profile to this file\n  -debug string\n    \tdebug flags, any subset of "fpstv"\n  -diff\n    \twith -fix, don't update the files, but print a unified diff\n  -fix\n    \tapply all suggested fixes\n  -flags\n    \tprint analyzer flags in JSON\n  -json\n    \temit JSON output\n  -memprofile string\n    \twrite memory profile to this file\n  -source\n    \tno effect (deprecated)\n  -tags string\n    \tno effect (deprecated)\n  -test\n    \tindicates whether test files should be analyzed, too (default true)\n  -trace string\n    \twrite trace log to this file\n  -v\tno effect (deprecated)\n`;
  (exitCode === 0 ? process.stdout : process.stderr).write(out);
  process.exit(exitCode);
}

function flagsJson(): void {
  const arr = [
    ['V', true, 'print version and exit'], ['all', true, 'no effect (deprecated)'],
    ['c', false, 'display offending line with this many lines of context'],
    ['diff', true, "with -fix, don't update the files, but print a unified diff"],
    ['flags', true, 'print analyzer flags in JSON'], ['json', true, 'emit JSON output'],
    ['source', true, 'no effect (deprecated)'], ['tags', false, 'no effect (deprecated)'],
    ['test', true, 'indicates whether test files should be analyzed, too'], ['v', true, 'no effect (deprecated)'],
  ].map(([Name, Bool, Usage]) => ({Name, Bool, Usage}));
  process.stdout.write(JSON.stringify(arr, null, '\t') + '\n');
  process.exit(0);
}

function parseArgs(argv: string[]) {
  const opts: any = {json: false, context: -1, test: true, packages: [] as string[]};
  const bools = new Set(['all','diff','fix','flags','json','source','v']);
  const strings = new Set(['cpuprofile','debug','memprofile','tags','trace']);
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '--help' || a === '-h' || a === '-help') usage(0);
    if (!a.startsWith('-') || a === '-') { opts.packages.push(a); continue; }
    let name = a.replace(/^-+/, '');
    let val: any = undefined;
    const eq = name.indexOf('=');
    if (eq >= 0) { val = name.slice(eq + 1); name = name.slice(0, eq); }
    if (name === 'V') {
      if (val === undefined) {
        process.stderr.write('wrapcheck: unsupported flag value: -V=true (use -V=full)\n');
      } else if (val !== 'full') {
        process.stderr.write(`wrapcheck: unsupported flag value: -V=${val} (use -V=full)\n`);
      } else {
        process.stderr.write(`wrapcheck: open ${(process.env.WRAPCHECK_EXE || path.resolve(process.argv[1] || 'executable'))}: permission denied\n`);
      }
      process.exit(1);
    }
    if (name === 'c') { if (val === undefined) val = argv[++i]; opts.context = parseInt(val ?? '-1', 10); continue; }
    if (name === 'test') { opts.test = val === undefined ? true : !(val === 'false' || val === '0'); continue; }
    if (bools.has(name)) { opts[name] = val === undefined ? true : !(val === 'false' || val === '0'); continue; }
    if (strings.has(name)) { if (val === undefined) val = argv[++i]; opts[name] = val || ''; continue; }
    process.stderr.write(`flag provided but not defined: -${name}\n`); usage(2);
  }
  if (opts.flags) flagsJson();
  if (opts.packages.length === 0) opts.packages.push('.');
  return opts;
}

function loadConfig(start: string): Config {
  let cfg: Config = {ignoreSigs: [...DEFAULT_IGNORES], ignoreSigRegexps: [], ignorePackageGlobs: [], ignoreInterfaceRegexps: [], reportInternalErrors: false};
  const files = [path.join(start, '.wrapcheck.yaml'), path.join(os.homedir(), '.wrapcheck.yaml')];
  for (const f of files) if (fs.existsSync(f)) { cfg = parseYamlConfig(fs.readFileSync(f, 'utf8'), cfg); break; }
  return cfg;
}

function parseYamlConfig(txt: string, base: Config): Config {
  const cfg: Config = {...base, ignoreSigs: [...base.ignoreSigs], ignoreSigRegexps: [...base.ignoreSigRegexps], ignorePackageGlobs: [...base.ignorePackageGlobs], ignoreInterfaceRegexps: [...base.ignoreInterfaceRegexps]};
  const lines = txt.split(/\r?\n/); let key = '';
  const arrays: any = {ignoreSigs: [], extraIgnoreSigs: [], ignoreSigRegexps: [], ignorePackageGlobs: [], ignoreInterfaceRegexps: []};
  for (let raw of lines) {
    const noComment = raw.replace(/\s+#.*$/, ''); if (!noComment.trim()) continue;
    const m = noComment.match(/^([A-Za-z0-9_]+):\s*(.*)$/);
    if (m) {
      key = m[1]; const val = m[2].trim();
      if (key === 'reportInternalErrors') cfg.reportInternalErrors = /^true$/i.test(val);
      else if (val && val.startsWith('[')) arrays[key] = val.replace(/[\[\]]/g,'').split(',').map((s:string)=>unquote(s.trim())).filter(Boolean);
      continue;
    }
    const it = noComment.match(/^\s*-\s*(.*)$/);
    if (it && arrays[key]) arrays[key].push(unquote(it[1].trim()));
  }
  if (arrays.ignoreSigs.length) cfg.ignoreSigs = arrays.ignoreSigs;
  cfg.ignoreSigs.push(...arrays.extraIgnoreSigs);
  cfg.ignoreSigRegexps.push(...arrays.ignoreSigRegexps.map((s:string)=>safeRe(s)).filter(Boolean));
  cfg.ignorePackageGlobs.push(...arrays.ignorePackageGlobs);
  cfg.ignoreInterfaceRegexps.push(...arrays.ignoreInterfaceRegexps.map((s:string)=>safeRe(s)).filter(Boolean));
  return cfg;
}
function unquote(s: string): string { return s.replace(/^['"]|['"]$/g, ''); }
function safeRe(s: string): RegExp | null { try { return new RegExp(s); } catch { return null; } }

function findModuleRoot(start: string): {root: string, module: string} {
  let d = path.resolve(start);
  if (fs.existsSync(d) && fs.statSync(d).isFile()) d = path.dirname(d);
  while (true) {
    const gm = path.join(d, 'go.mod');
    if (fs.existsSync(gm)) {
      const m = fs.readFileSync(gm,'utf8').match(/^module\s+(\S+)/m);
      return {root: d, module: m ? m[1] : ''};
    }
    const p = path.dirname(d); if (p === d) return {root: path.resolve(start), module: ''}; d = p;
  }
}

function expandPackage(arg: string, test: boolean): string[] {
  const cwd = process.cwd();
  const absArg = path.resolve(cwd, arg.replace(/\.\.\.$/, ''));
  const recursive = arg.endsWith('/...') || arg === './...';
  const dirs: string[] = [];
  const visit = (d: string) => {
    if (!fs.existsSync(d) || !fs.statSync(d).isDirectory()) return;
    const base = path.basename(d); if (base === '.git' || base === 'vendor' || base === 'node_modules' || base === 'dist') return;
    const hasGo = fs.readdirSync(d).some((f:string)=>f.endsWith('.go') && (test || !f.endsWith('_test.go')));
    if (hasGo) dirs.push(d);
    if (recursive) for (const e of fs.readdirSync(d)) visit(path.join(d,e));
  };
  visit(absArg);
  return dirs;
}

function stripComments(src: string): string {
  return src.replace(/\/\*[\s\S]*?\*\//g, m => m.replace(/[^\n]/g, ' ')).replace(/\/\/.*$/gm, '');
}

function parseImports(src: string): Map<string,string> {
  const imports = new Map<string,string>();
  const add = (alias: string, imp: string) => { if (alias !== '_' && alias !== '.') imports.set(alias || path.basename(imp), imp); };
  for (const m of src.matchAll(/import\s+\(([\s\S]*?)\)/g)) {
    for (const line of m[1].split(/\r?\n/)) {
      const mm = line.trim().match(/^(?:(\w+)\s+)?"([^"]+)"/); if (mm) add(mm[1] || '', mm[2]);
    }
  }
  for (const m of src.matchAll(/import\s+(?:(\w+)\s+)?"([^"]+)"/g)) add(m[1] || '', m[2]);
  return imports;
}

function isExternalImport(imp: string, mod: string, cfg: Config): boolean {
  if (!imp) return false;
  if (cfg.ignorePackageGlobs.some(g => globMatch(g, imp))) return false;
  if (!cfg.reportInternalErrors && mod && (imp === mod || imp.startsWith(mod + '/'))) return false;
  return true;
}
function globMatch(g: string, s: string): boolean { const r = '^' + g.split('*').map(x=>x.replace(/[.+?^${}()|[\]\\]/g,'\\$&')).join('.*') + '$'; return new RegExp(r).test(s); }

function ignored(expr: string, cfg: Config): boolean { return cfg.ignoreSigs.some(s => expr.includes(s)) || cfg.ignoreSigRegexps.some(r => r.test(expr)); }
function lineCol(src: string, idx: number) { const pre = src.slice(0, idx); const parts = pre.split('\n'); return {line: parts.length, col: parts[parts.length-1].length + 1}; }
function splitReturns(s: string): string[] { const out: string[]=[]; let cur='', depth=0, str=''; for (let i=0;i<s.length;i++){ const c=s[i], p=s[i-1]; if(str){cur+=c; if(c===str && p!=='\\') str=''; continue;} if(c==='"'||c==='`'||c==="'"){str=c;cur+=c;continue;} if(c==='('||c==='['||c==='{') depth++; if(c===')'||c===']'||c==='}') depth--; if(c===','&&depth===0){out.push(cur.trim());cur='';} else cur+=c;} if(cur.trim()) out.push(cur.trim()); return out; }

function analyzeFile(file: string, module: string, cfg: Config): Diagnostic[] {
  const raw = fs.readFileSync(file, 'utf8'); const src = stripComments(raw); const imports = parseImports(src);
  const diags: Diagnostic[] = []; const errVars = new Map<string, string>(); const safeVars = new Set<string>(); const varPkgs = new Map<string, string>();
  const lines = src.split(/\r?\n/); let offset = 0;
  for (let ln = 0; ln < lines.length; ln++) {
    const line = lines[ln]; const trimmed = line.trim();
    // Track assignments receiving an error from an external package call.
    for (const assign of trimmed.matchAll(/(?:^|[;{]\s*)(?:(?:[\w\[\]*\.]+\s*,\s*)*)(\w+)\s*(?::=|=)\s*([^;]+)/g)) {
      const varName = assign[1], rhs = assign[2].trim();
      const vp = externalValuePackage(rhs, imports, module, cfg);
      if (vp) varPkgs.set(varName, vp);
      const pkg = externalCallPackage(rhs, imports, module, cfg, varPkgs);
      if (pkg && !ignored(rhs, cfg)) errVars.set(varName, pkg);
      else if (rhs.includes('fmt.Errorf') || ignored(rhs, cfg) || rhs === 'nil') { errVars.delete(varName); safeVars.add(varName); }
    }
    const retMatch = line.match(/\breturn\b([\s\S]*)/);
    if (retMatch) {
      const exprText = retMatch[1].replace(/;.*/, '').trim();
      for (const rawExpr of splitReturns(exprText)) {
        const expr = rawExpr.replace(/[}\s]+$/g, '').trim();
        let bad = false;
        if (errVars.has(expr) && !safeVars.has(expr)) bad = true;
        const pkg = externalCallPackage(expr, imports, module, cfg, varPkgs) || externalValuePackage(expr, imports, module, cfg);
        if (pkg && !ignored(expr, cfg)) bad = true;
        if (bad) {
          const idx = offset + line.indexOf('return') + 1;
          const lc = lineCol(src, idx - 1);
          diags.push({file, line: lc.line, col: lc.col, msg: MSG, text: raw.split(/\r?\n/)[lc.line-1] || ''});
          break;
        }
      }
    }
    offset += line.length + 1;
  }
  return diags;
}

function externalCallPackage(expr: string, imports: Map<string,string>, module: string, cfg: Config, varPkgs: Map<string,string> = new Map()): string | null {
  if (!expr || ignored(expr, cfg)) return null;
  for (const [alias, imp] of imports) {
    if (!isExternalImport(imp, module, cfg)) continue;
    const re = new RegExp(`(?:^|[^\\w])${alias.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}\\.[A-Za-z_][\\w]*\\s*\\(`);
    if (re.test(expr)) return imp;
  }
  for (const [v, imp] of varPkgs) {
    if (!isExternalImport(imp, module, cfg)) continue;
    const re = new RegExp(`(?:^|[^\\w])${v.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}\\.[A-Za-z_][\\w]*\\s*\\(`);
    if (re.test(expr)) return imp;
  }
  return null;
}

function externalValuePackage(expr: string, imports: Map<string,string>, module: string, cfg: Config): string | null {
  if (!expr || ignored(expr, cfg)) return null;
  for (const [alias, imp] of imports) {
    if (!isExternalImport(imp, module, cfg)) continue;
    const esc = alias.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    if (new RegExp(`(?:^|[^\\w])${esc}\\.[A-Za-z_][\\w]*(?:\\{|$|[\\s,)])`).test(expr.trim())) return imp;
  }
  return null;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  let all: Diagnostic[] = [];
  for (const p of opts.packages) {
    for (const dir of expandPackage(p, opts.test)) {
      const mod = findModuleRoot(dir); const cfg = loadConfig(dir);
      for (const f of fs.readdirSync(dir).filter((x:string)=>x.endsWith('.go') && (opts.test || !x.endsWith('_test.go'))).sort()) {
        all.push(...analyzeFile(path.join(dir, f), mod.module, cfg));
      }
    }
  }
  all.sort((a,b)=>a.file.localeCompare(b.file)||a.line-b.line||a.col-b.col);
  if (opts.json) {
    const obj: any = {};
    for (const d of all) { const rel = path.relative(process.cwd(), d.file) || d.file; (obj[rel] ||= []).push({posn: `${rel}:${d.line}:${d.col}`, message: d.msg}); }
    process.stdout.write(all.length ? JSON.stringify(obj, null, '\t') + '\n' : '{}\n');
  } else {
    for (const d of all) {
      const rel = path.relative(process.cwd(), d.file) || d.file;
      process.stdout.write(`${rel}:${d.line}:${d.col}: ${d.msg}\n`);
      if (opts.context >= 0 && d.text !== undefined) process.stdout.write(`${d.line}: ${d.text}\n`);
    }
  }
  process.exit(all.length ? 3 : 0);
}
main();
