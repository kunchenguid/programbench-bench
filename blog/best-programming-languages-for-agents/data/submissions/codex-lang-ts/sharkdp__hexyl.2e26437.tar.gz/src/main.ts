import * as fs from "fs";
import * as path from "path";

type Border = "unicode" | "ascii" | "none";
type Base = "hexadecimal" | "decimal" | "octal" | "binary";
type CharTable = "default" | "ascii" | "braille" | "codepage-437" | "codepage-1047";

interface Options {
  file?: string;
  length?: number;
  skip: number;
  blockSize: number;
  noSqueezing: boolean;
  color: "always" | "auto" | "never" | "force";
  border: Border;
  characters: boolean;
  position: boolean;
  displayOffset: number;
  displayOffsetGiven: boolean;
  panels?: number | "auto";
  groupSize: 1 | 2 | 4 | 8;
  endian: "big" | "little";
  base: Base;
  terminalWidth?: number;
  include: boolean;
  charTable: CharTable;
  printColorTable: boolean;
}

const VERSION = "hexyl 0.16.0";

function shortHelp(): string {
  return `A command-line hex viewer

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]  The file to display. If no FILE argument is given, read from STDIN

Options:
  -n, --length <N>                Only read N bytes from the input. The short option '-l' can be used as an alias.
  -s, --skip <N>                  Skip the first N bytes of the input.
      --block-size <SIZE>         Sets the size of the \`block\` unit to SIZE. [default: 512]
  -v, --no-squeezing              Displays all input data
      --color <WHEN>              When to use colors [default: always] [possible values: always, auto, never, force]
      --border <STYLE>            Whether to draw a border [default: unicode] [possible values: unicode, ascii, none]
  -p, --plain                     Display output with --no-characters, --no-position, --border=none, and --color=never
      --no-characters             Do not show the character panel on the right
  -C, --characters                Show the character panel on the right
      --character-table <FORMAT>  Defines how bytes are mapped to characters
      --color-scheme <FORMAT>     Defines the color scheme for the characters
  -P, --no-position               Whether to display the position panel on the left
  -o, --display-offset <N>        Add N bytes to the displayed file position. [default: 0]
      --panels <N>                Sets the number of hex data panels to be displayed
  -g, --group-size <N>            Number of bytes/octets that should be grouped together. [default: 1]
      --endianness <FORMAT>       Whether to print out groups in little-endian or big-endian format
  -b, --base <B>                  Sets the base used for the bytes. [default: hexadecimal]
      --terminal-width <N>        Sets the number of terminal columns to be displayed.
      --print-color-table         Print a table showing how different types of bytes are colored
  -i, --include                   Output in C include file style
      --completion <SHELL>        Show shell completion for a certain shell
  -h, --help                      Print help (see more with '--help')
  -V, --version                   Print version
`;
}

function parseCount(raw: string, blockSize: number, allowNegative: boolean): number {
  let s = raw.trim();
  let sign = 1;
  if (s.startsWith("-")) {
    if (!allowNegative) {
      throw new Error(`negative offset specified, but only positive offsets (counts) are accepted in this context`);
    }
    sign = -1;
    s = s.slice(1);
  }
  let n: number;
  const lower = s.toLowerCase();
  const m = lower.match(/^((?:0x[0-9a-f]+)|(?:\d+(?:\.\d+)?))([a-z]+)?$/);
  if (!m) throw new Error(`invalid byte count '${raw}'`);
  if (m[1].startsWith("0x")) n = parseInt(m[1], 16);
  else n = Number(m[1]);
  const unit = m[2] || "";
  const mult: Record<string, number> = {
    "": 1, b: 1, byte: 1, bytes: 1,
    kb: 1000, mb: 1000 ** 2, gb: 1000 ** 3, tb: 1000 ** 4,
    kib: 1024, mib: 1024 ** 2, gib: 1024 ** 3, tib: 1024 ** 4,
    k: 1000, m: 1000 ** 2, g: 1000 ** 3, t: 1000 ** 4,
    block: blockSize, blocks: blockSize,
  };
  if (!(unit in mult)) throw new Error(`invalid unit '${unit}'`);
  return sign * Math.trunc(n * mult[unit]);
}

function parseArgs(argv: string[]): Options {
  const opt: Options = {
    skip: 0, blockSize: 512, noSqueezing: false, color: "always", border: "unicode",
    characters: true, position: true, displayOffset: 0, displayOffsetGiven: false,
    groupSize: 1, endian: "big", base: "hexadecimal", include: false,
    charTable: "default", printColorTable: false,
  };
  const take = (i: number, name: string): [string, number] => {
    const a = argv[i];
    const eq = a.indexOf("=");
    if (eq >= 0) return [a.slice(eq + 1), i];
    if (i + 1 >= argv.length) die(`error: a value is required for '${name}'`, 2);
    return [argv[i + 1], i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") {
      if (i + 1 < argv.length) opt.file = argv[i + 1];
      break;
    } else if (a === "-h" || a === "--help") {
      process.stdout.write(shortHelp());
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      console.log(VERSION);
      process.exit(0);
    } else if (a === "-v" || a === "--no-squeezing") opt.noSqueezing = true;
    else if (a === "-p" || a === "--plain") {
      opt.characters = false; opt.position = false; opt.border = "none"; opt.color = "never";
    } else if (a === "--no-characters") opt.characters = false;
    else if (a === "-C" || a === "--characters") opt.characters = true;
    else if (a === "-P" || a === "--no-position") opt.position = false;
    else if (a === "-i" || a === "--include") opt.include = true;
    else if (a === "--print-color-table") opt.printColorTable = true;
    else if (a === "-e") opt.endian = "little";
    else if (a.startsWith("-n") && a !== "-n" && !a.startsWith("--")) opt.length = parseCount(a.slice(2), opt.blockSize, false);
    else if (a === "-n" || a === "-l" || a === "-c" || a === "--length" || a === "--bytes" || a.startsWith("--length=") || a.startsWith("--bytes=")) {
      const [v, ni] = take(i, a); i = ni; opt.length = parseCount(v, opt.blockSize, false);
    } else if (a === "-s" || a === "--skip" || a.startsWith("--skip=")) {
      const [v, ni] = take(i, a); i = ni; opt.skip = parseCount(v, opt.blockSize, true);
    } else if (a === "-o" || a === "--display-offset" || a.startsWith("--display-offset=")) {
      const [v, ni] = take(i, a); i = ni; opt.displayOffset = parseCount(v, opt.blockSize, true); opt.displayOffsetGiven = true;
    } else if (a === "--block-size" || a.startsWith("--block-size=")) {
      const [v, ni] = take(i, a); i = ni; opt.blockSize = parseCount(v, opt.blockSize, false);
    } else if (a === "--color" || a.startsWith("--color=")) {
      const [v, ni] = take(i, a); i = ni; if (["always","auto","never","force"].includes(v)) opt.color = v as any;
    } else if (a === "--border" || a.startsWith("--border=")) {
      const [v, ni] = take(i, a); i = ni; if (["unicode","ascii","none"].includes(v)) opt.border = v as Border;
    } else if (a === "--panels" || a.startsWith("--panels=")) {
      const [v, ni] = take(i, a); i = ni; opt.panels = v === "auto" ? "auto" : Math.max(1, parseInt(v, 10));
    } else if (a === "--terminal-width" || a.startsWith("--terminal-width=")) {
      const [v, ni] = take(i, a); i = ni; opt.terminalWidth = parseInt(v, 10);
    } else if (a === "-g" || a === "--group-size" || a === "--groupsize" || a.startsWith("--group-size=") || a.startsWith("--groupsize=")) {
      const [v, ni] = take(i, a); i = ni; const g = Number(v); if ([1,2,4,8].includes(g)) opt.groupSize = g as any; else die(`error: invalid value '${v}' for '--group-size <N>'`, 2);
    } else if (a === "--endianness" || a.startsWith("--endianness=")) {
      const [v, ni] = take(i, a); i = ni; if (v === "little" || v === "big") opt.endian = v;
    } else if (a === "-b" || a === "--base" || a.startsWith("--base=")) {
      const [v, ni] = take(i, a); i = ni;
      const map: Record<string, Base> = {hex: "hexadecimal", hexadecimal: "hexadecimal", dec: "decimal", decimal: "decimal", oct: "octal", octal: "octal", bin: "binary", binary: "binary"};
      if (map[v]) opt.base = map[v]; else die(`error: invalid value '${v}' for '--base <B>'`, 2);
    } else if (a === "--character-table" || a.startsWith("--character-table=")) {
      const [v, ni] = take(i, a); i = ni; if (["default","ascii","braille","codepage-437","codepage-1047"].includes(v)) opt.charTable = v as CharTable;
    } else if (a === "--color-scheme" || a.startsWith("--color-scheme=")) {
      const [, ni] = take(i, a); i = ni;
    } else if (a === "--completion" || a.startsWith("--completion=")) {
      const [v] = take(i, a); console.log(`# completion for ${v} is not available in this reimplementation`); process.exit(0);
    } else if (a.startsWith("-")) die(`error: unexpected argument '${a}' found`, 2);
    else if (!opt.file) opt.file = a;
    else die(`error: unexpected argument '${a}' found`, 2);
  }
  return opt;
}

function die(msg: string, code = 1): never {
  console.error(msg);
  process.exit(code);
  throw new Error(msg);
}

function readInput(opt: Options): Buffer {
  let buf: Buffer;
  if (opt.file) {
    try { buf = fs.readFileSync(opt.file); }
    catch (e: any) { die(`Error: ${e.message.replace(/, open '.*/, "")}`); }
  } else {
    buf = fs.readFileSync(0);
  }
  let start = opt.skip >= 0 ? opt.skip : Math.max(0, buf.length + opt.skip);
  if (start > buf.length) start = buf.length;
  let end = opt.length == null ? buf.length : Math.min(buf.length, start + opt.length);
  const sliced = buf.subarray(start, end);
  if (opt.displayOffsetGiven && opt.displayOffset < 0) {
    die(`Error: failed to parse \`--display-offset\` arg \"${opt.displayOffset}\" as byte count\n\nCaused by:\n    negative offset specified, but only positive offsets (counts) are accepted in this context`);
  }
  opt.displayOffset += start;
  return sliced;
}

function ansiForByte(b: number): string {
  if (b === 0) return "\x1b[90m";
  if (b >= 0x80) return "\x1b[33m";
  if (b >= 0x20 && b <= 0x7e && b !== 0x20) return "\x1b[36m";
  return "\x1b[32m";
}

function colorize(s: string, b: number, use: boolean): string {
  return use ? ansiForByte(b) + s : s;
}

function charForByte(b: number, table: CharTable): string {
  if (table === "ascii") return b >= 0x20 && b <= 0x7e ? String.fromCharCode(b) : ".";
  if (table === "braille") {
    if (b === 0) return "⋄";
    if (b === 9) return "→";
    if (b === 10) return "↵";
    if (b === 13) return "←";
    if (b === 32) return " ";
    if (b >= 0x20 && b <= 0x7e) return String.fromCharCode(b);
    return String.fromCharCode(0x2800 + b);
  }
  if (table === "codepage-437") {
    const cp = ["⋄","☺","☻","♥","♦","♣","♠","•","◘","○","◙","♂","♀","♪","♫","☼","►","◄","↕","‼","¶","§","▬","↨","↑","↓","→","←","∟","↔","▲","▼"];
    if (b === 0) return "⋄";
    if (b < 32) return cp[b] || ".";
    if (b >= 32 && b <= 126) return String.fromCharCode(b);
    const extra: Record<number, string> = {127:"⌂",128:"Ç",255:"ﬀ"};
    return extra[b] || ".";
  }
  if (table === "codepage-1047") {
    if (b >= 0x20 && b <= 0x7e) return String.fromCharCode(b);
    return ".";
  }
  if (b === 0) return "⋄";
  if (b === 0x20) return " ";
  if ([9,10,12,13].includes(b)) return "_";
  if (b >= 0x21 && b <= 0x7e) return String.fromCharCode(b);
  if (b < 0x80) return "•";
  return "×";
}

function byteString(bytes: number[], opt: Options): string {
  if (opt.base === "decimal") return bytes[0].toString(10).padStart(3, "0");
  if (opt.base === "octal") return bytes[0].toString(8).padStart(3, "0");
  if (opt.base === "binary") return bytes[0].toString(2).padStart(8, "0");
  return bytes.map(b => b.toString(16).padStart(2, "0")).join("");
}

function cellWidth(opt: Options): number {
  if (opt.base === "binary") return 8;
  if (opt.base === "decimal" || opt.base === "octal") return 3;
  return opt.groupSize * 2;
}

function hexPanelWidth(opt: Options): number {
  if (opt.base !== "hexadecimal") return 1 + 8 * (cellWidth(opt) + 1);
  return 2 + (8 / opt.groupSize) * cellWidth(opt) + ((8 / opt.groupSize) - 1);
}

function panelCount(opt: Options): number {
  if (opt.panels && opt.panels !== "auto") return opt.panels;
  if (opt.base !== "hexadecimal" || opt.terminalWidth && opt.terminalWidth < 80) return 1;
  if (opt.terminalWidth) {
    const one = 8 + 1 + hexPanelWidth(opt) + 1 + 8;
    const two = 8 + 1 + hexPanelWidth(opt) * 2 + 3 + 1 + 8 * 2 + 1;
    return opt.terminalWidth >= two ? 2 : (opt.terminalWidth >= one ? 1 : 1);
  }
  return 2;
}

function formatHexPanel(row: Buffer, panel: number, opt: Options, useColor: boolean): string {
  const start = panel * 8;
  const pieces: string[] = [];
  if (opt.base === "hexadecimal") {
    for (let i = 0; i < 8; i += opt.groupSize) {
      const group: number[] = [];
      for (let j = 0; j < opt.groupSize; j++) if (start + i + j < row.length) group.push(row[start + i + j]);
      if (!group.length) break;
      const shown = opt.endian === "little" ? [...group].reverse() : group;
      pieces.push(colorize(byteString(shown, opt), group[0], useColor));
    }
  } else {
    for (let i = 0; i < 8; i++) {
      if (start + i < row.length) {
        const b = row[start + i];
        pieces.push(colorize(byteString([b], opt), b, useColor));
      }
    }
  }
  let s = " " + pieces.join(" ");
  const width = hexPanelWidth(opt);
  const visible = stripAnsi(s).length;
  return s + " ".repeat(Math.max(0, width - visible));
}

function stripAnsi(s: string): string {
  return s.replace(/\x1b\\[[0-9;]*m/g, "");
}

function formatCharPanel(row: Buffer, panel: number, opt: Options, useColor: boolean): string {
  const start = panel * 8;
  let s = "";
  for (let i = 0; i < 8; i++) {
    if (start + i < row.length) {
      const b = row[start + i];
      s += colorize(charForByte(b, opt.charTable), b, useColor);
    } else {
      s += " ";
    }
  }
  return s;
}

function borderLine(kind: "top" | "bottom", widths: number[], border: Border): string {
  if (border === "none") return "";
  const u = border === "unicode";
  const chars = u
    ? (kind === "top" ? ["┌","┬","┐","─"] : ["└","┴","┘","─"])
    : (kind === "top" ? ["+","+","+","-"] : ["+","+","+","-"]);
  return chars[0] + widths.map(w => chars[3].repeat(w)).join(chars[1]) + chars[2];
}

function renderRow(offset: number | "*", row: Buffer, opt: Options, panels: number, useColor: boolean): string {
  const sep = opt.border === "unicode" ? "│" : opt.border === "ascii" ? "|" : "";
  const mid = opt.border === "unicode" ? "┊" : opt.border === "ascii" ? "|" : " ";
  const parts: string[] = [];
  if (opt.position) {
    const off = offset === "*" ? "*".padEnd(8, " ") : Math.max(0, offset).toString(16).padStart(8, "0");
    parts.push(useColor && offset !== "*" ? `\x1b[90m${off}\x1b[39m` : off);
  }
  for (let p = 0; p < panels; p++) parts.push(formatHexPanel(row, p, opt, useColor));
  if (opt.characters) for (let p = 0; p < panels; p++) parts.push(formatCharPanel(row, p, opt, useColor));
  if (opt.border === "none") {
    const startIdx = opt.position ? 1 : 0;
    const prefix = opt.position ? " " + parts[0] + " " : " ";
    const hp = parts.slice(startIdx, startIdx + panels).join(" ");
    if (!opt.characters) return prefix + hp;
    const cp = parts.slice(startIdx + panels).join(" ");
    return prefix + hp + " " + cp + " ";
  }
  let out = sep;
  let idx = 0;
  if (opt.position) out += parts[idx++] + sep;
  for (let p = 0; p < panels; p++) out += parts[idx++] + (p === panels - 1 ? sep : mid);
  if (opt.characters) for (let p = 0; p < panels; p++) out += parts[idx++] + (p === panels - 1 ? sep : mid);
  if (useColor) out += "\x1b[39m";
  return out;
}

function render(buf: Buffer, opt: Options): string {
  const useColor = opt.color === "force" || (opt.color === "always" && !process.env.NO_COLOR);
  const panels = panelCount(opt);
  const rowSize = panels * 8;
  const widths: number[] = [];
  if (opt.position) widths.push(8);
  for (let i = 0; i < panels; i++) widths.push(hexPanelWidth(opt));
  if (opt.characters) for (let i = 0; i < panels; i++) widths.push(8);
  const lines: string[] = [];
  const top = borderLine("top", widths, opt.border); if (top) lines.push(top);
  let lastFull: Buffer | undefined;
  let squeezing = false;
  for (let pos = 0; pos < buf.length; pos += rowSize) {
    const row = buf.subarray(pos, Math.min(buf.length, pos + rowSize));
    const full = row.length === rowSize;
    if (!opt.noSqueezing && full && lastFull && Buffer.compare(row, lastFull) === 0) {
      if (!squeezing) {
        lines.push(renderRow("*", Buffer.alloc(0), opt, panels, false));
        squeezing = true;
      }
      continue;
    }
    squeezing = false;
    lines.push(renderRow(opt.displayOffset + pos, row, opt, panels, useColor));
    if (full) lastFull = Buffer.from(row);
  }
  if (squeezing && buf.length % rowSize === 0) {
    lines.push(renderRow(opt.displayOffset + buf.length, Buffer.alloc(0), opt, panels, useColor));
  }
  const bottom = borderLine("bottom", widths, opt.border); if (bottom) lines.push(bottom);
  return lines.join("\n") + (lines.length ? "\n" : "");
}

function cIdent(file?: string): string {
  const base = file ? path.basename(file) : "stdin";
  return base.replace(/[^A-Za-z0-9_]/g, "_").replace(/^[0-9]/, "_$&");
}

function renderInclude(buf: Buffer, opt: Options): string {
  const name = cIdent(opt.file);
  const vals = Array.from(buf as any, (b: any) => "0x" + Number(b).toString(16).padStart(2, "0"));
  const lines = [`unsigned char ${name}[] = {`];
  for (let i = 0; i < vals.length; i += 12) lines.push("  " + vals.slice(i, i + 12).join(", ") + (i + 12 < vals.length ? "," : ""));
  lines.push("};");
  lines.push(`unsigned int ${name}_len = ${buf.length};`);
  return lines.join("\n") + "\n";
}

function printColorTable(): void {
  console.log("hexyl color reference:\n");
  console.log("\x1b[90m⋄ NULL bytes (0x00)");
  console.log("\x1b[39m\x1b[36ma ASCII printable characters (0x20 - 0x7E)");
  console.log("\x1b[39m\x1b[32m_ ASCII whitespace (0x09 - 0x0D, 0x20)");
  console.log("\x1b[39m\x1b[32m• ASCII control characters (except NULL and whitespace)");
  console.log("\x1b[39m\x1b[33m× Non-ASCII bytes (0x80 - 0xFF)");
  process.stdout.write("\x1b[39m");
}

function main(): void {
  try {
    const opt = parseArgs(process.argv.slice(2));
    if (opt.printColorTable) { printColorTable(); return; }
    const buf = readInput(opt);
    process.stdout.write(opt.include ? renderInclude(buf, opt) : render(buf, opt));
  } catch (e: any) {
    die(`Error: ${e.message}`);
  }
}

main();
