declare module "fs" {
  export function readFileSync(path: string | number): any;
  export function writeFileSync(path: string, data: any): void;
}

declare module "path" {
  export function basename(path: string): string;
}

declare const process: any;
declare const Buffer: any;
type Buffer = any;
