declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const VERSION = "*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***";
const SHORT_HELP = `${VERSION}
Compress or decompress the INPUT file(s); reads from STDIN if INPUT is \`-\` or not provided.

Usage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]

Options:
  -o OUTPUT                     Write output to a single file, OUTPUT.
  -k, --keep                    Preserve INPUT file(s). [Default] 
  --rm                          Remove INPUT file(s) after successful (de)compression to file.

  -#                            Desired compression level, where \`#\` is a number between 1 and 19;
                                lower numbers provide faster compression, higher numbers yield
                                better compression ratios. [Default: 3]

  -d, --decompress              Perform decompression.
  -D DICT                       Use DICT as the dictionary for compression or decompression.

  -f, --force                   Disable input and output checks. Allows overwriting existing files,
                                receiving input from the console, printing output to STDOUT, and
                                operating on links, block devices, etc. Unrecognized formats will be
                                passed-through through as-is.

  -h                            Display short usage and exit.
  -H, --help                    Display full help and exit.
  -V, --version                 Display the program version and exit.
`;

const FULL_HELP = `${SHORT_HELP}
Advanced options:
  -c, --stdout                  Write to STDOUT (even if it is a console) and keep the INPUT file(s).

  -v, --verbose                 Enable verbose output; pass multiple times to increase verbosity.
  -q, --quiet                   Suppress warnings; pass twice to suppress errors.
  --trace LOG                   Log tracing information to LOG.

  --[no-]progress               Forcibly show/hide the progress counter. NOTE: Any (de)compressed
                                output to terminal will mix with progress counter text.

  -r                            Operate recursively on directories.
  --filelist LIST               Read a list of files to operate on from LIST.
  --output-dir-flat DIR         Store processed files in DIR.
  --output-dir-mirror DIR       Store processed files in DIR, respecting original directory structure.
  --[no-]asyncio                Use asynchronous IO. [Default: Enabled]

  --[no-]check                  Add XXH64 integrity checksums during compression. [Default: Add, Validate]
                                If \`-d\` is present, ignore/validate checksums during decompression.

  --                            Treat remaining arguments after \`--\` as files.

Advanced compression options:
  --ultra                       Enable levels beyond 19, up to 22; requires more memory.
  --fast[=#]                    Use to very fast compression levels. [Default: 1]
  --adapt                       Dynamically adapt compression level to I/O conditions.
  --long[=#]                    Enable long distance matching with window log #. [Default: 27]
  --patch-from=REF              Use REF as the reference point for Zstandard's diff engine. 
  --patch-apply                 Equivalent for \`-d --patch-from\` 

  -T#                           Spawn # compression threads. [Default: 3; pass 0 for core count.]
  --single-thread               Share a single thread for I/O and compression (slightly different than \`-T1\`).
  --auto-threads={physical|logical}
                                Use physical/logical cores when using \`-T0\`. [Default: Physical]

  --jobsize=#                   Set job size to #. [Default: 0 (automatic)]
  --rsyncable                   Compress using a rsync-friendly method (\`--jobsize=#\` sets unit size). 

  --exclude-compressed          Only compress files that are not already compressed.

  --stream-size=#               Specify size of streaming input from STDIN.
  --size-hint=#                 Optimize compression parameters for streaming input of approximately size #.
  --target-compressed-block-size=#
                                Generate compressed blocks of approximately # size.

  --no-dictID                   Don't write \`dictID\` into the header (dictionary compression only).
  --[no-]compress-literals      Force (un)compressed literals.
  --[no-]row-match-finder       Explicitly enable/disable the fast, row-based matchfinder for
                                the 'greedy', 'lazy', and 'lazy2' strategies.

  --format=zstd                 Compress files to the \`.zst\` format. [Default]
  --[no-]mmap-dict              Memory-map dictionary file rather than mallocing and loading all at once
  --format=gzip                 Compress files to the \`.gz\` format.

Advanced decompression options:
  -l                            Print information about Zstandard-compressed files.
  --test                        Test compressed file integrity.
  -M#                           Set the memory usage limit to # megabytes.
  --[no-]sparse                 Enable sparse mode. [Default: Enabled for files, disabled for STDOUT.]
  --[no-]pass-through           Pass through uncompressed files as-is. [Default: Disabled]

Dictionary builder:
  --train                       Create a dictionary from a training set of files.

Benchmark options:
  -b#                           Perform benchmarking with compression level #. [Default: 3]
`;

type Opts = {
  decompress: boolean; stdout: boolean; force: boolean; rm: boolean; keep: boolean;
  test: boolean; list: boolean; recursive: boolean; outputDir?: string; mirrorDir?: string;
  output?: string; format: string; quiet: number; files: string[];
};

function die(msg: string, code = 1): never {
  if (msg) process.stderr.write(msg.endsWith("\n") ? msg : msg + "\n");
  process.exit(code);
  throw new Error(msg);
}

function parseArgs(argv: string[]): Opts {
  const o: Opts = {decompress: false, stdout: false, force: false, rm: false, keep: true, test: false, list: false, recursive: false, format: "zstd", quiet: 0, files: []};
  let end = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (end) { o.files.push(a); continue; }
    if (a === "--") { end = true; continue; }
    if (a === "-h") { process.stdout.write(SHORT_HELP); process.exit(0); }
    if (a === "-H" || a === "--help") { process.stdout.write(FULL_HELP); process.exit(0); }
    if (a === "-V" || a === "--version") { process.stdout.write(VERSION + "\n"); process.exit(0); }
    if (a === "-d" || a === "--decompress" || a === "--uncompress") { o.decompress = true; continue; }
    if (a === "-c" || a === "--stdout" || a === "--to-stdout") { o.stdout = true; o.keep = true; continue; }
    if (a === "-f" || a === "--force") { o.force = true; continue; }
    if (a === "-k" || a === "--keep") { o.keep = true; o.rm = false; continue; }
    if (a === "--rm") { o.rm = true; o.keep = false; continue; }
    if (a === "-t" || a === "--test") { o.decompress = true; o.test = true; continue; }
    if (a === "-l") { o.list = true; continue; }
    if (a === "-q" || a === "--quiet") { o.quiet++; continue; }
    if (a === "-r") { o.recursive = true; continue; }
    if (a === "-o") { if (i + 1 >= argv.length) die("error: missing argument for -o"); o.output = argv[++i]; if (o.output === "-") o.stdout = true; continue; }
    if (a.startsWith("-o") && a.length > 2) { o.output = a.slice(2); if (o.output === "-") o.stdout = true; continue; }
    if (a === "-D") { i++; continue; }
    if (a.startsWith("-D") && a.length > 2) continue;
    if (a === "--filelist") {
      if (i + 1 >= argv.length) die("error: missing argument for --filelist");
      const list = fs.readFileSync(argv[++i], "utf8").split(/\r?\n/).filter(Boolean);
      o.files.push(...list);
      continue;
    }
    if (a === "--output-dir-flat") {
      if (i + 1 >= argv.length) die("error: missing argument for --output-dir-flat");
      o.outputDir = argv[++i];
      continue;
    }
    if (a === "--output-dir-mirror") {
      if (i + 1 >= argv.length) die("error: missing argument for --output-dir-mirror");
      o.mirrorDir = argv[++i];
      continue;
    }
    if (a === "--trace") { i++; continue; }
    if (/^-[cdfkqltv]+$/.test(a)) {
      for (const ch of a.slice(1)) {
        if (ch === "c") { o.stdout = true; o.keep = true; }
        else if (ch === "d") o.decompress = true;
        else if (ch === "f") o.force = true;
        else if (ch === "k") { o.keep = true; o.rm = false; }
        else if (ch === "q") o.quiet++;
        else if (ch === "t") { o.decompress = true; o.test = true; }
        else if (ch === "l") o.list = true;
      }
      continue;
    }
    if (a.startsWith("--format=")) { o.format = a.slice(9); continue; }
    if (/^-[0-9]+$/.test(a) || /^-T[0-9]+$/.test(a) || /^-M[0-9]+$/.test(a) || /^-[beiS][0-9]*$/.test(a)) continue;
    if (a.startsWith("--output-dir-flat=")) { o.outputDir = a.slice(18); continue; }
    if (a.startsWith("--output-dir-mirror=")) { o.mirrorDir = a.slice(20); continue; }
    if (a.startsWith("--fast") || a.startsWith("--long") || a === "--ultra" || a === "--adapt" || a === "--rsyncable" || a.startsWith("--jobsize") || a.startsWith("--stream-size") || a.startsWith("--size-hint") || a.startsWith("--target-compressed-block-size") || a.startsWith("--auto-threads") || a.startsWith("--trace=") || a.startsWith("--") && (a.includes("check") || a.includes("progress") || a.includes("asyncio") || a.includes("sparse") || a.includes("pass-through") || a.includes("mmap-dict") || a.includes("compress-literals") || a.includes("row-match-finder") || a === "--single-thread" || a === "--exclude-compressed" || a === "--no-dictID")) continue;
    if (a.startsWith("-") && a !== "-") die(`Incorrect parameter: ${a} \n${SHORT_HELP}`);
    o.files.push(a);
  }
  return o;
}

function writeU24LE(buf: any, val: number, off: number) {
  buf[off] = val & 255; buf[off + 1] = (val >>> 8) & 255; buf[off + 2] = (val >>> 16) & 255;
}

function compressZstd(input: any): any {
  const maxBlock = 128 * 1024;
  const header = Buffer.alloc(13);
  header.writeUInt32LE(0xfd2fb528, 0);
  header[4] = 0xe0; // single segment, 8-byte frame content size
  header.writeBigUInt64LE(BigInt(input.length), 5);
  const parts = [header];
  for (let off = 0; off < input.length || (input.length === 0 && off === 0); off += maxBlock) {
    const end = Math.min(input.length, off + maxBlock);
    const chunk = input.subarray(off, end);
    const bh = Buffer.alloc(3);
    const last = end >= input.length ? 1 : 0;
    writeU24LE(bh, (chunk.length << 3) | last, 0);
    parts.push(bh, chunk);
    if (input.length === 0) break;
  }
  return Buffer.concat(parts);
}

function readU24LE(buf: any, off: number): number {
  return buf[off] | (buf[off + 1] << 8) | (buf[off + 2] << 16);
}

function parseZstd(input: any): {data: any, size?: number, frames: number, skips: number, checksum: boolean} {
  let off = 0, frames = 0, skips = 0, checksum = false;
  const outs: any[] = [];
  while (off < input.length) {
    if (off + 4 > input.length) throw new Error("premature end");
    const magic = input.readUInt32LE(off); off += 4;
    if ((magic & 0xfffffff0) === 0x184d2a50) {
      if (off + 4 > input.length) throw new Error("premature end");
      const sz = input.readUInt32LE(off); off += 4 + sz; skips++; continue;
    }
    if (magic !== 0xfd2fb528) throw new Error("unsupported format");
    frames++;
    if (off >= input.length) throw new Error("premature end");
    const fhd = input[off++];
    const fcsFlag = fhd >>> 6;
    const single = !!(fhd & 0x20);
    const frameChecksum = !!(fhd & 0x04);
    checksum = checksum || frameChecksum;
    const dictFlag = fhd & 0x03;
    if (!single) off++; // window descriptor
    const dictSizes = [0, 1, 2, 4];
    off += dictSizes[dictFlag];
    let frameSize: number | undefined;
    let fcsBytes = fcsFlag === 0 ? (single ? 1 : 0) : (fcsFlag === 1 ? 2 : (fcsFlag === 2 ? 4 : 8));
    if (fcsBytes === 1) frameSize = input[off++];
    else if (fcsBytes === 2) { frameSize = input.readUInt16LE(off) + 256; off += 2; }
    else if (fcsBytes === 4) { frameSize = input.readUInt32LE(off); off += 4; }
    else if (fcsBytes === 8) { frameSize = Number(input.readBigUInt64LE(off)); off += 8; }
    const frameOuts: any[] = [];
    while (true) {
      if (off + 3 > input.length) throw new Error("premature end");
      const bh = readU24LE(input, off); off += 3;
      const last = bh & 1;
      const type = (bh >>> 1) & 3;
      const bsz = bh >>> 3;
      if (type === 0) {
        if (off + bsz > input.length) throw new Error("premature end");
        frameOuts.push(input.subarray(off, off + bsz)); off += bsz;
      } else if (type === 1) {
        if (off >= input.length) throw new Error("premature end");
        frameOuts.push(Buffer.alloc(bsz, input[off++])); 
      } else if (type === 2) {
        throw new Error("compressed zstd blocks are not supported by this reimplementation");
      } else {
        throw new Error("invalid block");
      }
      if (last) break;
    }
    if (frameChecksum) off += 4;
    const frameData = Buffer.concat(frameOuts);
    if (frameSize !== undefined && frameData.length !== frameSize) throw new Error("corrupt frame size");
    outs.push(frameData);
  }
  return {data: Buffer.concat(outs), size: outs.reduce((n, b) => n + b.length, 0), frames, skips, checksum};
}

function outName(file: string, opts: Opts): string {
  if (opts.output) return opts.output;
  let name: string;
  if (!opts.decompress) name = file + (opts.format === "gzip" ? ".gz" : ".zst");
  else {
    let found = false;
    name = file;
    for (const s of [".zst", ".tzst", ".gz", ".tgz"]) {
      if (file.endsWith(s)) { name = file.slice(0, -s.length) + (s === ".tgz" ? ".tar" : ""); found = true; break; }
    }
    if (!found) die(`zstd: ${file}: unknown suffix (.zst/.tzst/.gz/.tgz expected). Can't derive the output file name. Specify it with -o dstFileName. Ignoring.`);
  }
  if (opts.outputDir) return path.join(opts.outputDir, path.basename(name));
  if (opts.mirrorDir) return path.join(opts.mirrorDir, name.replace(/^\/+/, ""));
  return name;
}

function readInput(file: string): any {
  if (file === "-") return fs.readFileSync(0);
  try { return fs.readFileSync(file); }
  catch (e: any) { die(`zstd: can't stat ${file} : No such file or directory -- ignored `); }
}

function writeOutput(dest: string | undefined, data: any, opts: Opts) {
  if (opts.stdout || dest === "-") { process.stdout.write(data); return; }
  if (!opts.force && fs.existsSync(dest)) die(`zstd: ${dest} already exists; overwrite (y/n) ? Not overwritten  \n `);
  fs.mkdirSync(path.dirname(dest), {recursive: true});
  fs.writeFileSync(dest, data);
}

function expandFiles(files: string[], recursive: boolean): string[] {
  const out: string[] = [];
  for (const f of files) {
    if (f === "-") { out.push(f); continue; }
    let st;
    try { st = fs.statSync(f); } catch { out.push(f); continue; }
    if (st.isDirectory()) {
      if (!recursive) die(`${f} is a directory -- ignored`);
      const stack = [f];
      while (stack.length) {
        const d = stack.pop();
        for (const ent of fs.readdirSync(d)) {
          const p = path.join(d, ent);
          const s = fs.statSync(p);
          if (s.isDirectory()) stack.push(p);
          else if (s.isFile()) out.push(p);
        }
      }
    } else out.push(f);
  }
  return out;
}

function ratioLine(src: string, inLen: number, outLen: number, out: string) {
  if (process.stderr.isTTY) process.stderr.write(`${src.padEnd(20)}:${(outLen * 100 / Math.max(1, inLen)).toFixed(2)}%   (${String(inLen).padStart(6)} B => ${String(outLen).padStart(6)} B, ${out}) \n`);
}

function listFile(file: string, input: any, opts: Opts) {
  try {
    const p = parseZstd(input);
    if (!opts.quiet) process.stdout.write("Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename\n");
    const ratio = p.size ? (p.size / input.length).toFixed(3) : "0.000";
    process.stdout.write(`${String(p.frames).padStart(6)} ${String(p.skips).padStart(6)} ${String(input.length).padStart(7)}   B ${String(p.size).padStart(9)}   B  ${ratio}  ${p.checksum ? "XXH64" : "None "}  ${file}\n`);
  } catch (e: any) {
    die(`${file} : Decoding error (36) : ${e.message}`);
  }
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.files.length === 0) {
    opts.files.push("-");
    if (!opts.output && !opts.test && !opts.list) opts.stdout = true;
  }
  let rc = 0;
  for (const file of expandFiles(opts.files, opts.recursive)) {
    try {
      const input = readInput(file);
      if (opts.list) { listFile(file, input, opts); continue; }
      if (opts.test) {
        const p = opts.format === "gzip" || file.endsWith(".gz") ? {data: zlib.gunzipSync(input)} : parseZstd(input);
        if (!opts.quiet) process.stderr.write(`${file.padEnd(20)}: ${p.data.length} bytes \n`);
        continue;
      }
      let output: any;
      if (opts.decompress) output = (file.endsWith(".gz") || input[0] === 0x1f && input[1] === 0x8b) ? zlib.gunzipSync(input) : parseZstd(input).data;
      else output = opts.format === "gzip" ? zlib.gzipSync(input) : compressZstd(input);
      const dest = opts.stdout ? "-" : outName(file, opts);
      writeOutput(dest, output, opts);
      if (!opts.stdout && opts.rm && file !== "-") fs.unlinkSync(file);
      if (!opts.stdout && !opts.quiet && !opts.decompress) ratioLine(file, input.length, output.length, dest);
      if (!opts.stdout && !opts.quiet && opts.decompress) process.stderr.write(`${file.padEnd(20)}: ${output.length} bytes \n`);
    } catch (e: any) {
      rc = 1;
      if (opts.quiet < 2) process.stderr.write(`${file} : Decoding error (36) : ${e.message}\n`);
    }
  }
  process.exit(rc);
}

main();
