declare const require: any;
declare const process: any;
declare const Buffer: any;

const http = require("http");
const https = require("https");
const zlib = require("zlib");
const fs = require("fs");
const pathMod = require("path");

const VERSION = "0.1.0";

type HeaderMap = Record<string, string>;

interface Options {
  auth: string;
  bench: boolean;
  benchN: number;
  benchC: number;
  body: string;
  hasBody: boolean;
  form: boolean;
  json: boolean;
  pretty: boolean;
  insecure: boolean;
  proxy: string;
  print: string;
  version: boolean;
}

const helpText = `bat is a Go implemented CLI cURL-like tool for humans.

Usage:

\tbat [flags] [METHOD] URL [ITEM [ITEM]]

flags:
  -a, -auth=USER[:PASS]       Pass a username:password pair as the argument
  -b, -bench=false            Sends bench requests to URL
  -b.N=1000                   Number of requests to run
  -b.C=100                    Number of requests to run concurrently
  -body=""                    Send RAW data as body
  -f, -form=false             Submitting the data as a form
  -j, -json=true              Send the data in a JSON object
  -p, -pretty=true            Print Json Pretty Format
  -i, -insecure=false         Allow connections to SSL sites without certs
  -proxy=PROXY_URL            Proxy with host and port
  -print="A"                  String specifying what the output should contain, default will print all information
         "H" request headers
         "B" request body
         "h" response headers
         "b" response body
  -v, -version=true           Show Version Number

METHOD:
  bat defaults to either GET (if there is no request data) or POST (with request data).

URL:
  The only information needed to perform a request is a URL. The default scheme is http://,
  which can be omitted from the argument; example.org works just fine.

ITEM:
  Can be any of:
    Query string   key=value
    Header         key:value
    Post data      key=value
    File upload    key@/path/file

Example:

\tbat beego.me

more help information please refer to https://github.com/astaxie/bat
`;

function timestamp(): string {
  const d = new Date();
  const p = (n: number, w = 2) => String(n).padStart(w, "0");
  return `${d.getFullYear()}/${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${p(d.getMilliseconds(), 3)}000`;
}

function logError(file: string, line: number, message: string): void {
  console.error(`${timestamp()} ${file}:${line}: ${message}`);
}

function parseBool(v: string): boolean {
  return !/^(false|0|no)$/i.test(v);
}

function parseArgs(argv: string[]): { opts: Options; positional: string[]; badFlag?: string } {
  const opts: Options = {
    auth: "",
    bench: false,
    benchN: 1000,
    benchC: 100,
    body: "",
    hasBody: false,
    form: false,
    json: true,
    pretty: true,
    insecure: false,
    proxy: "",
    print: "A",
    version: false,
  };
  const positional: string[] = [];
  const takesValue: Record<string, keyof Options> = {
    a: "auth",
    auth: "auth",
    body: "body",
    proxy: "proxy",
    print: "print",
  };
  const bools: Record<string, keyof Options> = {
    b: "bench",
    bench: "bench",
    f: "form",
    form: "form",
    j: "json",
    json: "json",
    p: "pretty",
    pretty: "pretty",
    i: "insecure",
    insecure: "insecure",
    v: "version",
    version: "version",
    h: "version",
    help: "version",
    download: "bench",
  };

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") {
      positional.push(...argv.slice(i + 1));
      break;
    }
    if (!a.startsWith("-") || a === "-") {
      positional.push(a);
      continue;
    }
    let raw = a.replace(/^-+/, "");
    let value: string | undefined;
    const eq = raw.indexOf("=");
    if (eq >= 0) {
      value = raw.slice(eq + 1);
      raw = raw.slice(0, eq);
    }
    if (raw === "b.N") {
      opts.benchN = parseInt(value ?? argv[++i] ?? "1000", 10) || 1000;
      continue;
    }
    if (raw === "b.C") {
      opts.benchC = parseInt(value ?? argv[++i] ?? "100", 10) || 100;
      continue;
    }
    if (Object.prototype.hasOwnProperty.call(takesValue, raw)) {
      const key = takesValue[raw];
      const val = value !== undefined ? value : (argv[++i] ?? "");
      (opts as any)[key] = val;
      if (key === "body") opts.hasBody = true;
      continue;
    }
    if (Object.prototype.hasOwnProperty.call(bools, raw)) {
      const key = bools[raw];
      const val = value !== undefined ? parseBool(value) : true;
      (opts as any)[key] = val;
      if (raw === "h" || raw === "help") (opts as any).__help = true;
      continue;
    }
    return { opts, positional, badFlag: raw };
  }
  return { opts, positional };
}

function isMethod(s: string): boolean {
  return /^(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)$/i.test(s);
}

function normalizeUrl(input: string): any {
  const withScheme = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(input) ? input : `http://${input}`;
  return new URL(withScheme);
}

function displayUrl(input: string): string {
  return /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(input) ? input : `http://${input}`;
}

function splitItem(item: string): { kind: "header" | "data" | "file" | "unknown"; key: string; value: string } {
  const colon = item.indexOf(":");
  const eq = item.indexOf("=");
  const at = item.indexOf("@");
  if (colon > 0 && (eq < 0 || colon < eq) && (at < 0 || colon < at)) {
    return { kind: "header", key: item.slice(0, colon), value: item.slice(colon + 1) };
  }
  if (at > 0 && (eq < 0 || at < eq)) {
    return { kind: "file", key: item.slice(0, at), value: item.slice(at + 1) };
  }
  if (eq >= 0) {
    return { kind: "data", key: item.slice(0, eq), value: item.slice(eq + 1) };
  }
  return { kind: "unknown", key: item, value: "" };
}

function makeJson(data: Record<string, string>): string {
  return JSON.stringify(data) + "\n";
}

function requestOnce(method: string, urlObj: any, headers: HeaderMap, body: any, opts: Options): Promise<{ statusCode: number; statusMessage: string; headers: HeaderMap; body: any }> {
  return new Promise((resolve, reject) => {
    const isHttps = urlObj.protocol === "https:";
    const client = isHttps ? https : http;
    const reqOpts: any = {
      protocol: urlObj.protocol,
      hostname: urlObj.hostname,
      port: urlObj.port || (isHttps ? 443 : 80),
      path: `${urlObj.pathname}${urlObj.search}`,
      method,
      headers,
      rejectUnauthorized: !opts.insecure,
    };
    const req = client.request(reqOpts, (res: any) => {
      const chunks: any[] = [];
      res.on("data", (c: any) => chunks.push(c));
      res.on("end", () => {
        let out = Buffer.concat(chunks);
        const enc = String(res.headers["content-encoding"] || "").toLowerCase();
        try {
          if (enc.includes("gzip")) out = zlib.gunzipSync(out);
          else if (enc.includes("deflate")) out = zlib.inflateSync(out);
        } catch (_) {
          // Keep the original bytes if decompression fails.
        }
        resolve({ statusCode: res.statusCode || 0, statusMessage: res.statusMessage || "", headers: res.headers, body: out });
      });
    });
    req.on("error", reject);
    if (body !== undefined && body !== null && method !== "GET" && method !== "HEAD") req.write(body);
    req.end();
  });
}

function printResponse(resp: { headers: HeaderMap; body: any }, opts: Options): void {
  const body = Buffer.isBuffer(resp.body) ? resp.body.toString() : String(resp.body ?? "");
  console.log("");
  const ctype = String((resp.headers as any)["content-type"] || "");
  if (opts.pretty && ctype.includes("application/json")) {
    try {
      console.log(JSON.stringify(JSON.parse(body), null, 2));
      return;
    } catch (_) {
      // fall through
    }
  }
  process.stdout.write(body);
  if (!body.endsWith("\n")) process.stdout.write("\n");
}

async function main(): Promise<void> {
  const parsed = parseArgs(process.argv.slice(2));
  const opts = parsed.opts;
  const help = (opts as any).__help === true;
  if (parsed.badFlag) {
    console.error(`flag provided but not defined: -${parsed.badFlag}`);
    process.stdout.write(helpText);
    process.exitCode = 2;
    return;
  }
  if (help || process.argv.length <= 2) {
    process.stdout.write(helpText);
    process.exitCode = 2;
    return;
  }
  if (opts.version) {
    console.log(`Version: ${VERSION}`);
    return;
  }

  const args = parsed.positional;
  let method = "";
  if (args.length > 0 && isMethod(args[0])) method = args.shift()!.toUpperCase();
  if (args.length === 0) {
    logError("filter.go", 35, "Miss the URL");
    return;
  }
  const rawUrl = args.shift()!;
  const urlObj = normalizeUrl(rawUrl);
  const urlForLog = displayUrl(rawUrl);
  const headers: HeaderMap = {
    "User-Agent": `bat/${VERSION}`,
    "Accept": "application/json",
    "Accept-Encoding": "gzip, deflate",
  };
  if (opts.auth) {
    const parts = opts.auth.split(":");
    const user = parts[0] || "";
    const pass = parts.length > 1 ? parts.slice(1).join(":") : "";
    headers["Authorization"] = `Basic ${Buffer.from(`${user}:${pass}`).toString("base64")}`;
  }

  const data: Record<string, string> = {};
  const files: Record<string, string> = {};
  for (const item of args) {
    const p = splitItem(item);
    if (p.kind === "header") headers[p.key] = p.value;
    else if (p.kind === "file") files[p.key] = p.value;
    else if (p.kind === "data") data[p.key] = p.value;
  }
  const hasData = Object.keys(data).length > 0 || Object.keys(files).length > 0 || opts.hasBody;
  if (!method) method = hasData ? "POST" : "GET";

  let body: any = undefined;
  if (method === "GET" || method === "HEAD") {
    for (const [k, v] of Object.entries(data)) urlObj.searchParams.append(k, v as string);
  } else if (opts.hasBody) {
    body = opts.body;
  } else if (opts.form) {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(data)) params.append(k, v as string);
    body = params.toString();
    headers["Content-Type"] = "application/x-www-form-urlencoded";
  } else if (Object.keys(files).length > 0) {
    const boundary = `BatBoundary${Date.now()}`;
    headers["Content-Type"] = `multipart/form-data; boundary=${boundary}`;
    const parts: any[] = [];
    for (const [k, v] of Object.entries(data)) {
      parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`));
    }
    for (const [k, p] of Object.entries(files)) {
      let content: any = Buffer.alloc(0);
      try { content = fs.readFileSync(p as string); } catch (_) {}
      parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"; filename="${pathMod.basename(p as string)}"\r\n\r\n`));
      parts.push(content);
      parts.push(Buffer.from("\r\n"));
    }
    parts.push(Buffer.from(`--${boundary}--\r\n`));
    body = Buffer.concat(parts);
  } else if (Object.keys(data).length > 0) {
    body = makeJson(data);
    headers["Content-Type"] = "application/json";
  }
  if (body !== undefined && body !== null && method !== "GET" && method !== "HEAD") {
    headers["Content-Length"] = String(Buffer.byteLength(body));
  }

  if (opts.bench) {
    const total = Math.max(1, opts.benchN);
    const conc = Math.max(1, opts.benchC);
    let done = 0;
    const start = Date.now();
    async function worker(): Promise<void> {
      while (done < total) {
        done++;
        try { await requestOnce(method, urlObj, headers, body, opts); } catch (_) {}
      }
    }
    await Promise.all(Array.from({ length: Math.min(conc, total) }, () => worker()));
    const elapsed = (Date.now() - start) / 1000;
    console.log(`Finished ${total} requests`);
    console.log(`Requests per second: ${(total / Math.max(elapsed, 0.001)).toFixed(2)}`);
    return;
  }

  try {
    const resp = await requestOnce(method, urlObj, headers, body, opts);
    printResponse(resp, opts);
  } catch (e: any) {
    const verb = method.charAt(0) + method.slice(1).toLowerCase();
    let detail = e.message || String(e);
    if (e && e.code === "ECONNREFUSED") {
      detail = `dial tcp ${urlObj.hostname}:${urlObj.port || (urlObj.protocol === "https:" ? "443" : "80")}: connect: connection refused`;
    }
    logError("bat.go", 215, `can't get the url ${verb} "${urlForLog}": ${detail}`);
  }
}

main();
