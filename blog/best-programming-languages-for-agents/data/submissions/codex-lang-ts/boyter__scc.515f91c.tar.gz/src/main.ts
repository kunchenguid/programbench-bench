declare const require: any;
declare const process: any;
declare const Buffer: any;
const fs = require("fs");
const path = require("path");

type Stats = {
  Name: string; Bytes: number; CodeBytes: number; Lines: number; Code: number;
  Comment: number; Blank: number; Complexity: number; Count: number;
  WeightedComplexity: number; Files: FileStats[]; LineLength: any; ULOC: number;
};
type FileStats = Omit<Stats, "Files"> & { Location: string; PossibleLanguages?: string[] };
type InternalFileStats = FileStats & { _ulines?: Set<string> };

const VERSION = "3.7.0";
const BORDER = "───────────────────────────────────────────────────────────────────────────────";

const LANG_LINES = `ABAP (abap)
ABNF (abnf)
ActionScript (as)
Ada (ada,adb,ads,pad)
Agda (agda)
Assembly (s,asm)
BASH (bash,bash_login,bash_logout,bash_profile,bashrc,.bashrc)
Batch (bat,btm,cmd)
Bazel (bzl,build.bazel,build,workspace)
C (c,ec,pgc)
C Header (h)
C# (cs,csx)
C++ (cc,cpp,cxx,c++,pcc,ino)
C++ Header (hh,hpp,hxx,h++,inl,ipp,tpp)
CMake (cmake,cmakelists.txt)
COBOL (cob,cbl,ccp,cobol,cpy)
CoffeeScript (coffee)
Clojure (clj,cljc)
CSS (css)
CSV (csv)
D (d)
Dart (dart)
Dockerfile (dockerfile,dockerfile)
Elixir (ex,exs)
Elm (elm)
Erlang (erl,hrl)
F# (fs,fsi,fsx,fsscript)
FORTRAN Legacy (f,for,ftn,f77)
Fortran Modern (f03,f08,f90,f95)
Go (go)
Go Template (tmpl,gohtml,gotxt)
Gradle (gradle)
GraphQL (graphql)
Groovy (groovy)
Haskell (hs)
HTML (html,htm)
INI (ini)
Java (java)
JavaScript (js,cjs,mjs)
JSON (json)
JSX (jsx)
Julia (jl)
Kotlin (kt,kts)
LaTeX (tex)
LESS (less)
License (license,licence,copying,unlicense,copyright)
Lisp (lisp,lsp)
Lua (lua)
m4 (m4)
Makefile (makefile,mak,mk,gnumakefile)
Markdown (md,markdown)
MATLAB (m)
Objective C (m)
Objective C++ (mm)
OCaml (ml,mli)
Pascal (pas)
Perl (pl,plx,pm)
PHP (php)
Plain Text (text,txt)
Powershell (ps1,psm1)
Protocol Buffers (proto)
Python (py,pyw,pyi)
R (r)
Ruby (rb)
Rust (rs)
Sass (sass,scss)
Scala (scala)
Shell (sh)
SQL (sql)
SVG (svg)
Swift (swift)
TOML (toml)
TypeScript (ts,mts,cts)
TSX (tsx)
Vim Script (vim)
Vue (vue)
XML (xml)
YAML (yaml,yml)
Zig (zig)`;

const EXT_LANG: Record<string, string> = {};
for (const line of LANG_LINES.split("\n")) {
  const m = /^(.*?) \((.*)\)$/.exec(line);
  if (!m) continue;
  for (const e of m[2].split(",")) EXT_LANG[e.toLowerCase()] = m[1];
}
Object.assign(EXT_LANG, {
  dockerfile: "Dockerfile", makefile: "Makefile", gnumakefile: "Makefile",
  rakefile: "Ruby", gemfile: "Ruby", jenkinsfile: "Jenkins Buildfile",
  license: "License", copying: "License", readme: "Markdown"
});

const HASH = new Set(["Python","Ruby","Perl","Shell","BASH","YAML","TOML","R","Makefile","Dockerfile","Powershell","Julia","CoffeeScript","Elixir"]);
const CLIKE = new Set(["C","C Header","C++","C++ Header","C#","Java","JavaScript","TypeScript","JSX","TSX","Go","Rust","Swift","Kotlin","Scala","CSS","PHP","Dart","Objective C","Objective C++","Lua","SQL","Protocol Buffers","Less"]);
const XMLLIKE = new Set(["HTML","XML","SVG","Vue","Markdown"]);
const SEMI = new Set(["Lisp","Clojure"]);
const COMPLEX = /\b(if|for|while|case|catch|elif|else\s+if|switch|select|foreach|loop|when|unless|&&|\|\|)\b|\?|&&|\|\|/g;

function help(): string {
  return `Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.
Version 3.7.0
Ben Boyter <ben@boyter.org> + Contributors

Usage:
  scc [flags] [files or directories]

Flags:
      --avg-wage int                       average wage value used for basic COCOMO calculation (default 56286)
      --binary                             disable binary file detection
      --by-file                            display output for every file
  -m, --character                          calculate max and mean characters per line
      --ci                                 enable CI output settings where stdout is ASCII
      --cocomo-project-type string         change COCOMO model type [organic, semi-detached, embedded, "custom,1,1,1,1"] (default "organic")
      --cost-comparison                    show both COCOMO and LOCOMO estimates side by side
      --count-as string                    count extension as language [e.g. jsp:htm,chead:"C Header" maps extension jsp to html and chead to C Header]
      --count-ignore                       set to allow .gitignore and .ignore files to be counted
      --currency-symbol string             set currency symbol (default "$")
      --debug                              enable debug output
  -a, --dryness                            calculate the DRYness of the project (implies --uloc)
  -x, --exclude-ext strings                ignore file extensions (overrides include-ext) [comma separated list: e.g. go,java,js]
  -n, --exclude-file strings               ignore files with matching names (default [package-lock.json,Cargo.lock,yarn.lock,pubspec.lock,Podfile.lock,pnpm-lock.yaml])
  -f, --format string                      set output format [tabular, wide, json, json2, csv, csv-stream, cloc-yaml, html, html-table, sql, sql-insert, openmetrics] (default "tabular")
  -h, --help                               help for scc
  -i, --include-ext strings                limit to file extensions [comma separated list: e.g. go,java,js]
      --include-symlinks                   if set will count symlink files
  -l, --languages                          print supported languages and extensions
      --no-cocomo                          remove COCOMO calculation output
  -c, --no-complexity                      skip calculation of code complexity
  -d, --no-duplicates                      remove duplicate files from stats and output
      --no-gitignore                       disables .gitignore file logic
      --no-ignore                          disables .ignore file logic
      --no-size                            remove size calculation output
  -o, --output string                      output filename (default stdout)
  -p, --percent                            include percentage values in output
  -s, --sort string                        column to sort by [files, name, lines, blanks, code, comments, complexity] (default "files")
  -u, --uloc                               calculate the number of unique lines of code (ULOC) for the project
  -v, --verbose                            verbose output
      --version                            version for scc
  -w, --wide                               wider output with additional statistics (implies --complexity)
`;
}

function parseArgs(argv: string[]) {
  const opt: any = { format: "tabular", paths: [], excludeDir: [".git",".hg",".svn"], excludeFile: ["package-lock.json","Cargo.lock","yarn.lock","pubspec.lock","Podfile.lock","pnpm-lock.yaml"], includeExt: null, excludeExt: [], sort: "files", cocomo: true, complexity: true, size: true, gitignore: true, ignore: true, symlinks: false, byFile: false, wide: false, uloc: false, dryness: false, percent: false, output: "" };
  const needs = new Set(["--format","-f","--output","-o","--sort","-s","--include-ext","-i","--exclude-ext","-x","--exclude-dir","--exclude-file","-n","--count-as","--size-unit","--avg-wage","--currency-symbol","--cocomo-project-type","--sql-project","--not-match","-M","--format-multi","--remap-all","--remap-unknown"]);
  for (let i=0;i<argv.length;i++) {
    let a = argv[i];
    let val: string|undefined;
    if (a.includes("=") && a.startsWith("-")) { const p=a.indexOf("="); val=a.slice(p+1); a=a.slice(0,p); }
    if (needs.has(a)) val = val ?? argv[++i] ?? "";
    if (a === "--help" || a === "-h") opt.help = true;
    else if (a === "--version") opt.version = true;
    else if (a === "--languages" || a === "-l") opt.languages = true;
    else if (a === "--by-file") opt.byFile = true;
    else if (a === "--wide" || a === "-w") { opt.wide = true; opt.format = "wide"; }
    else if (a === "--no-complexity" || a === "-c") opt.complexity = false;
    else if (a === "--no-cocomo") opt.cocomo = false;
    else if (a === "--no-size") opt.size = false;
    else if (a === "--no-gitignore") opt.gitignore = false;
    else if (a === "--no-ignore") opt.ignore = false;
    else if (a === "--include-symlinks") opt.symlinks = true;
    else if (a === "--uloc" || a === "-u") opt.uloc = true;
    else if (a === "--dryness" || a === "-a") { opt.uloc = true; opt.dryness = true; }
    else if (a === "--percent" || a === "-p") opt.percent = true;
    else if (a === "--format" || a === "-f") opt.format = val || "tabular";
    else if (a === "--output" || a === "-o") opt.output = val || "";
    else if (a === "--sort" || a === "-s") opt.sort = val || "files";
    else if (a === "--include-ext" || a === "-i") opt.includeExt = splitList(val);
    else if (a === "--exclude-ext" || a === "-x") opt.excludeExt = splitList(val);
    else if (a === "--exclude-dir") opt.excludeDir = splitList(val);
    else if (a === "--exclude-file" || a === "-n") opt.excludeFile = splitList(val);
    else if (a === "--count-as") applyCountAs(val || "");
    else if (!a.startsWith("-")) opt.paths.push(a);
  }
  if (!opt.paths.length) opt.paths = ["."];
  return opt;
}
function splitList(s?: string){ return (s||"").split(",").map(x=>x.trim()).filter(Boolean); }
function applyCountAs(s: string) {
  for (const part of s.split(",")) {
    const [from, to] = part.split(":"); if (!from || !to) continue;
    EXT_LANG[from.replace(/^\./,"").toLowerCase()] = EXT_LANG[to.toLowerCase()] || to.replace(/^"|"$/g,"");
  }
}

function langFor(file: string): string | null {
  const base = path.basename(file).toLowerCase();
  if (EXT_LANG[base]) return EXT_LANG[base];
  const ext = path.extname(base).replace(/^\./,"");
  if (!ext) return null;
  return EXT_LANG[ext] || null;
}
function shebangLang(text: string): string | null {
  const first = text.split(/\r?\n/,1)[0].toLowerCase();
  if (!first.startsWith("#!")) return null;
  if (first.includes("python")) return "Python";
  if (first.includes("node") || first.includes("deno")) return "JavaScript";
  if (first.includes("bash")) return "BASH";
  if (first.includes("sh")) return "Shell";
  if (first.includes("ruby")) return "Ruby";
  if (first.includes("perl")) return "Perl";
  if (first.includes("php")) return "PHP";
  if (first.includes("pwsh") || first.includes("powershell")) return "Powershell";
  return null;
}
function detectableLang(file:string): string | null {
  const known = langFor(file);
  if (known) return known;
  try { return shebangLang(fs.readFileSync(file, "utf8").slice(0, 200)); } catch { return null; }
}
function extOf(file:string){ const b=path.basename(file).toLowerCase(); return path.extname(b).replace(/^\./,"") || b; }

function gitIgnoreMatcher(root: string, opt:any): ((p:string)=>boolean)[] {
  const matchers: ((p:string)=>boolean)[] = [];
  for (const name of [opt.gitignore?".gitignore":"", opt.ignore?".ignore":"", ".sccignore"]) {
    if (!name) continue;
    const f = path.join(root, name);
    if (!fs.existsSync(f)) continue;
    for (const raw of fs.readFileSync(f,"utf8").split(/\r?\n/)) {
      const line = raw.trim(); if (!line || line.startsWith("#")) continue;
      const pat = line.replace(/^\//,"");
      matchers.push((p:string) => {
        const rel = path.relative(root,p).split(path.sep).join("/");
        if (pat.startsWith("*.")) return rel.endsWith(pat.slice(1));
        if (pat.endsWith("/")) return rel.startsWith(pat.slice(0,-1)+"/");
        return rel === pat || rel.endsWith("/"+pat);
      });
    }
  }
  return matchers;
}

function walk(inputs: string[], opt:any): string[] {
  const out: string[] = [], seen = new Set<string>();
  const roots = inputs.map(p=>path.resolve(p));
  const matchers = roots.filter(r=>fs.existsSync(r) && fs.statSync(r).isDirectory()).flatMap(r=>gitIgnoreMatcher(r,opt));
  function rec(p:string) {
    let st: any;
    try { st = opt.symlinks ? fs.statSync(p) : fs.lstatSync(p); } catch { return; }
    if (st.isSymbolicLink() && !opt.symlinks) return;
    if (matchers.some(m=>m(p))) return;
    const base = path.basename(p);
    if (st.isDirectory()) {
      if (opt.excludeDir.includes(base)) return;
      for (const c of fs.readdirSync(p).sort()) rec(path.join(p,c));
    } else if (st.isFile()) {
      if (opt.excludeFile.includes(base)) return;
      const ext = extOf(p);
      if (opt.includeExt && !opt.includeExt.includes(ext)) return;
      if (opt.excludeExt.includes(ext)) return;
      const l = detectableLang(p); if (!l) return;
      const rp = path.resolve(p); if (!seen.has(rp)) { seen.add(rp); out.push(rp); }
    }
  }
  for (const p of inputs) rec(path.resolve(p));
  return out;
}

function isBinary(buf: any): boolean {
  const n = Math.min(buf.length, 8000);
  for (let i=0;i<n;i++) if (buf[i] === 0) return true;
  return false;
}

function countFile(file: string, opt:any): InternalFileStats | null {
  const buf = fs.readFileSync(file);
  if (isBinary(buf)) return null;
  let text = buf.toString("utf8");
  const lang = langFor(file) || shebangLang(text); if (!lang) return null;
  const hasFinalNewline = text.endsWith("\n");
  let lines = text.length ? text.split(/\r?\n/) : [];
  if (hasFinalNewline) lines = lines.slice(0,-1);
  let blank=0, comment=0, code=0, complexity=0, inBlock=false;
  const codeLines = new Set<string>();
  const block = CLIKE.has(lang) || XMLLIKE.has(lang);
  const blockStart = XMLLIKE.has(lang) ? "<!--" : "/*";
  const blockEnd = XMLLIKE.has(lang) ? "-->" : "*/";
  for (const line of lines) {
    const t = line.trim();
    if (t === "") { blank++; continue; }
    if (CLIKE.has(lang)) {
      if (inBlock) {
        comment++;
        if (t.includes("*/")) inBlock = false;
        continue;
      }
      if (t.startsWith("/*")) {
        comment++;
        if (!t.includes("*/")) inBlock = true;
        continue;
      }
      if (t.startsWith("//")) { comment++; continue; }
    }
    if (XMLLIKE.has(lang)) {
      if (inBlock) {
        comment++;
        if (t.includes("-->")) inBlock = false;
        continue;
      }
      if (t.startsWith("<!--")) {
        comment++;
        if (!t.includes("-->")) inBlock = true;
        continue;
      }
    }
    if (HASH.has(lang) && t.startsWith("#") && !t.startsWith("#!")) { comment++; continue; }
    if (SEMI.has(lang) && t.startsWith(";")) { comment++; continue; }
    if (lang === "SQL" && t.startsWith("--")) { comment++; continue; }
    let hasCode=false, hasComment=false, rest=t;
    if (inBlock) {
      hasComment=true;
      const end = rest.indexOf(blockEnd);
      if (end >= 0) { inBlock=false; rest = rest.slice(end+blockEnd.length).trim(); if (rest) hasCode=true; }
    }
    if (!inBlock) {
      if (HASH.has(lang) && rest.startsWith("#") && !rest.startsWith("#!")) hasComment = true;
      else if (SEMI.has(lang) && rest.startsWith(";")) hasComment = true;
      else if (lang === "SQL" && rest.startsWith("--")) hasComment = true;
      else if (block && rest.startsWith(blockStart)) {
        hasComment = true;
        const end = rest.indexOf(blockEnd, blockStart.length);
        if (end < 0) inBlock = true;
        else if (rest.slice(end+blockEnd.length).trim()) hasCode = true;
      } else {
        hasCode = true;
        const slash = rest.indexOf("//");
        const hash = HASH.has(lang) ? rest.indexOf("#") : -1;
        const sql = lang==="SQL" ? rest.indexOf("--") : -1;
        const bs = block ? rest.indexOf(blockStart) : -1;
        const points = [slash,hash,sql,bs].filter(x=>x>=0).sort((a,b)=>a-b);
        if (points.length) {
          hasComment = true;
          if (bs >= 0 && bs === points[0] && rest.indexOf(blockEnd, bs+blockStart.length) < 0) inBlock = true;
        }
      }
    }
    if (hasComment && !hasCode) comment++;
    else if (hasCode) { code++; codeLines.add(t); }
    if (hasCode && opt.complexity) complexity += (line.match(COMPLEX)||[]).length;
  }
  if (lang === "Go" && complexity === 0) complexity = 0;
  const loc = path.relative(process.cwd(), file) || file;
  return {Name: lang, Bytes: buf.length, CodeBytes: 0, Lines: lines.length, Code: code, Comment: comment, Blank: blank, Complexity: complexity, Count: 1, WeightedComplexity: 0, Location: loc, LineLength: null, ULOC: codeLines.size, _ulines: codeLines};
}

function emptyStat(name:string): Stats { return {Name:name,Bytes:0,CodeBytes:0,Lines:0,Code:0,Comment:0,Blank:0,Complexity:0,Count:0,WeightedComplexity:0,Files:[],LineLength:null,ULOC:0}; }
function summarize(files: InternalFileStats[], opt:any): Stats[] {
  const map = new Map<string, Stats>();
  const u = new Map<string, Set<string>>();
  for (const f of files) {
    let s = map.get(f.Name); if (!s) { s=emptyStat(f.Name); map.set(f.Name,s); }
    s.Bytes += f.Bytes; s.Lines += f.Lines; s.Code += f.Code; s.Comment += f.Comment; s.Blank += f.Blank; s.Complexity += f.Complexity; s.Count += 1; s.Files.push(f);
    if (!u.has(f.Name)) u.set(f.Name, new Set());
    for (const line of (f._ulines || [])) u.get(f.Name)!.add(line);
  }
  for (const [name,set] of u) map.get(name)!.ULOC = set.size;
  const arr = [...map.values()];
  const key = opt.sort;
  arr.sort((a,b) => {
    if (key === "name") return a.Name.localeCompare(b.Name);
    const prop: any = {files:"Count", lines:"Lines", blanks:"Blank", code:"Code", comments:"Comment", complexity:"Complexity"}[key] || "Count";
    return (b[prop]-a[prop]) || a.Name.localeCompare(b.Name);
  });
  return arr;
}
function total(stats: Stats[]): Stats { const t=emptyStat("Total"); for (const s of stats){ t.Bytes+=s.Bytes;t.Lines+=s.Lines;t.Code+=s.Code;t.Comment+=s.Comment;t.Blank+=s.Blank;t.Complexity+=s.Complexity;t.Count+=s.Count;t.ULOC+=s.ULOC;} return t; }
function commas(n:number){ return Math.trunc(n).toLocaleString("en-US"); }
function row(cols:(string|number)[], widths:number[], leftFirst=true){ return cols.map((c,i)=>{ const s=typeof c==="number"?commas(c):String(c); return i===0&&leftFirst ? s.padEnd(widths[i]) : s.padStart(widths[i]); }).join(" "); }
function table(stats: Stats[], opt:any): string {
  const t = total(stats), lines:string[] = [];
  const comp = opt.complexity !== false;
  const extra = opt.dryness ? "DRYness" : (opt.uloc ? "ULOC" : "");
  const widths = comp ? [20,8,10,8,9,10,10] : [24,8,10,10,11,10];
  if (extra) widths.push(10);
  lines.push(BORDER);
  const headers = comp ? ["Language","Files","Lines","Blanks","Comments","Code","Complexity"] : ["Language","Files","Lines","Blanks","Comments","Code"];
  if (extra) headers.push(extra);
  lines.push(row(headers, widths));
  lines.push(BORDER);
  for (const s of stats) {
    const vals: any[] = comp ? [s.Name,s.Count,s.Lines,s.Blank,s.Comment,s.Code,s.Complexity] : [s.Name,s.Count,s.Lines,s.Blank,s.Comment,s.Code];
    if (opt.dryness) vals.push(s.Code ? `${((s.ULOC / s.Code) * 100).toFixed(1)}%` : "0.0%");
    else if (opt.uloc) vals.push(s.ULOC);
    lines.push(row(vals, widths));
    if (opt.byFile) {
      lines.push(BORDER);
      for (const f of s.Files.sort((a,b)=>a.Location.localeCompare(b.Location))) {
        const fvals: any[] = comp ? [f.Location,"",f.Lines,f.Blank,f.Comment,f.Code,f.Complexity] : [f.Location,"",f.Lines,f.Blank,f.Comment,f.Code];
        if (opt.dryness) fvals.push(f.Code ? `${((f.ULOC / f.Code) * 100).toFixed(1)}%` : "0.0%");
        else if (opt.uloc) fvals.push(f.ULOC);
        lines.push(row(fvals, widths));
      }
      lines.push(BORDER);
    }
  }
  lines.push(BORDER);
  const tv: any[] = comp ? ["Total",t.Count,t.Lines,t.Blank,t.Comment,t.Code,t.Complexity] : ["Total",t.Count,t.Lines,t.Blank,t.Comment,t.Code];
  if (opt.dryness) tv.push(t.Code ? `${((t.ULOC / t.Code) * 100).toFixed(1)}%` : "0.0%");
  else if (opt.uloc) tv.push(t.ULOC);
  lines.push(row(tv, widths));
  lines.push(BORDER);
  if (opt.cocomo) {
    const cost = Math.round(Math.max(0,t.Code) * 36.6);
    lines.push(`Estimated Cost to Develop (organic) $${commas(cost)}`);
    lines.push(`Estimated Schedule Effort (organic) ${(Math.max(0.01,Math.pow(Math.max(t.Code,1)/1000,0.38)*2.5)).toFixed(2)} months`);
    lines.push(`Estimated People Required (organic) ${(Math.max(0.01,Math.pow(Math.max(t.Code,1)/1000,0.5))).toFixed(2)}`);
    lines.push(BORDER);
  }
  if (opt.size) { lines.push(`Processed ${t.Bytes} bytes, ${(t.Bytes/1000000).toFixed(3)} megabytes (SI)`); lines.push(BORDER); }
  return lines.join("\n")+"\n";
}
function jsonShape(stats: Stats[], byFile=false) {
  return stats.map(s => ({Name:s.Name,Bytes:s.Bytes,CodeBytes:0,Lines:s.Lines,Code:s.Code,Comment:s.Comment,Blank:s.Blank,Complexity:s.Complexity,Count:s.Count,WeightedComplexity:0,Files:byFile?s.Files:[],LineLength:null,ULOC:s.ULOC}));
}
function csv(stats: Stats[], stream=false) {
  const out = ["Language,Lines,Code,Comments,Blanks,Complexity,Bytes,Files,ULOC"];
  for (const s of stats) out.push(`${s.Name},${s.Lines},${s.Code},${s.Comment},${s.Blank},${s.Complexity},${s.Bytes},${s.Count},${s.ULOC}`);
  return out.join("\n")+"\n";
}
function yaml(stats: Stats[]) {
  let o = "";
  for (const s of stats) o += `${s.Name}:\n  nFiles: ${s.Count}\n  blank: ${s.Blank}\n  comment: ${s.Comment}\n  code: ${s.Code}\n`;
  const t=total(stats); o += `SUM:\n  blank: ${t.Blank}\n  comment: ${t.Comment}\n  code: ${t.Code}\n  nFiles: ${t.Count}\n`;
  return o;
}
function openmetrics(stats: Stats[]) {
  let o = "";
  for (const s of stats) {
    const l = s.Name.replace(/\\/g,"\\\\").replace(/"/g,'\\"');
    o += `scc_files{language="${l}"} ${s.Count}\nscc_lines{language="${l}"} ${s.Lines}\nscc_code{language="${l}"} ${s.Code}\nscc_comments{language="${l}"} ${s.Comment}\nscc_blanks{language="${l}"} ${s.Blank}\n`;
  }
  return o;
}
function render(stats: Stats[], opt:any): string {
  switch (opt.format) {
    case "json": return JSON.stringify(jsonShape(stats,opt.byFile));
    case "json2": return JSON.stringify({languageSummary: jsonShape(stats,opt.byFile), estimatedCost: total(stats).Code*20.727352168480744, estimatedScheduleMonths: Math.pow(Math.max(total(stats).Code,1)/1000,0.38)*2.5, estimatedPeople: Math.pow(Math.max(total(stats).Code,1)/1000,0.5)*0.3});
    case "csv": case "csv-stream": return csv(stats,opt.format==="csv-stream");
    case "cloc-yaml": return yaml(stats);
    case "openmetrics": return openmetrics(stats);
    case "html": case "html-table": return `<table><tr><th>Language</th><th>Files</th><th>Lines</th><th>Blank</th><th>Comment</th><th>Code</th><th>Complexity</th></tr>${stats.map(s=>`<tr><td>${s.Name}</td><td>${s.Count}</td><td>${s.Lines}</td><td>${s.Blank}</td><td>${s.Comment}</td><td>${s.Code}</td><td>${s.Complexity}</td></tr>`).join("")}</table>\n`;
    case "sql": case "sql-insert": return stats.map(s=>`INSERT INTO metadata (language, files, lines, blanks, comments, code, complexity) VALUES ('${s.Name.replace(/'/g,"''")}', ${s.Count}, ${s.Lines}, ${s.Blank}, ${s.Comment}, ${s.Code}, ${s.Complexity});`).join("\n")+"\n";
    default: return table(stats,opt);
  }
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  if (opt.help) return process.stdout.write(help());
  if (opt.version) return process.stdout.write(`scc version ${VERSION}\n`);
  if (opt.languages) return process.stdout.write(LANG_LINES.split("\n").sort().join("\n")+"\n");
  const files = walk(opt.paths, opt);
  const counted = files.map(f=>countFile(f,opt)).filter(Boolean) as InternalFileStats[];
  const stats = summarize(counted,opt);
  const out = render(stats,opt);
  if (opt.output) fs.writeFileSync(opt.output,out); else process.stdout.write(out);
}
main();
