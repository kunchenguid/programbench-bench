#!/usr/bin/env node
declare const require: any;
declare const process: any;
const fs = require("fs");

interface Opts {
  digits: boolean; nonDigits: boolean; spaces: boolean; nonSpaces: boolean; words: boolean; nonWords: boolean;
  escape: boolean; surrogates: boolean; reps: boolean; minReps: number; minSubLen: number;
  start: boolean; end: boolean; verbose: boolean; color: boolean; ignoreCase: boolean; capture: boolean;
  file?: string; inputs: string[];
}

const HELP = `grex 1.4.6
© 2019-today Peter M. Stahl <pemistahl@gmail.com>
Licensed under the Apache License, Version 2.0
Downloadable from https://crates.io/crates/grex
Source code at https://github.com/pemistahl/grex

grex generates regular expressions from user-provided test cases.

Usage: grex [OPTIONS] {INPUT...|--file <FILE>}

Input:
  [INPUT]...         One or more test cases separated by blank space
  -f, --file <FILE>  Reads test cases on separate lines from a file

Digit Options:
  -d, --digits      Converts any Unicode decimal digit to \\d
  -D, --non-digits  Converts any character which is not a Unicode decimal digit to \\D

Whitespace Options:
  -s, --spaces      Converts any Unicode whitespace character to \\s
  -S, --non-spaces  Converts any character which is not a Unicode whitespace character to \\S

Word Options:
  -w, --words      Converts any Unicode word character to \\w
  -W, --non-words  Converts any character which is not a Unicode word character to \\W

Escaping Options:
  -e, --escape           Replaces all non-ASCII characters with unicode escape sequences
      --with-surrogates  Converts astral code points to surrogate pairs if --escape is set

Repetition Options:
  -r, --repetitions
          Detects repeated non-overlapping substrings and converts them to {min,max} quantifier notation
      --min-repetitions <QUANTITY>          [default: 1]
      --min-substring-length <LENGTH>       [default: 1]

Anchor Options:
      --no-start-anchor  Removes the caret anchor \`^\` from the resulting regular expression
      --no-end-anchor    Removes the dollar sign anchor \`$\` from the resulting regular expression
      --no-anchors       Removes the caret and dollar sign anchors from the resulting regular expression

Display Options:
  -x, --verbose   Produces a nicer-looking regular expression in verbose mode
  -c, --colorize  Provides syntax highlighting for the resulting regular expression

Miscellaneous Options:
  -i, --ignore-case     Performs case-insensitive matching, letters match both upper and lower case
  -g, --capture-groups  Replaces non-capturing groups with capturing ones
  -h, --help            Prints help information
  -v, --version         Prints version information`;

function die(msg: string, code = 1): never { console.error(msg); process.exit(code); throw new Error(msg); }

function parseArgs(argv: string[]): Opts {
  const o: Opts = {
    digits: false, nonDigits: false, spaces: false, nonSpaces: false, words: false, nonWords: false,
    escape: false, surrogates: false, reps: false, minReps: 1, minSubLen: 1,
    start: true, end: true, verbose: false, color: false, ignoreCase: false, capture: false,
    inputs: [],
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help" || a === "-h") { console.log(HELP); process.exit(0); }
    if (a === "--version" || a === "-v") { console.log("grex 1.4.6"); process.exit(0); }
    if (a === "--file" || a === "-f") { o.file = argv[++i]; if (!o.file) die("error: a value is required for '--file <FILE>' but none was supplied", 2); continue; }
    if (a === "--digits") { o.digits = true; continue; }
    if (a === "--non-digits") { o.nonDigits = true; continue; }
    if (a === "--spaces") { o.spaces = true; continue; }
    if (a === "--non-spaces") { o.nonSpaces = true; continue; }
    if (a === "--words") { o.words = true; continue; }
    if (a === "--non-words") { o.nonWords = true; continue; }
    if (a === "--escape") { o.escape = true; continue; }
    if (a === "--with-surrogates") { o.surrogates = true; continue; }
    if (a === "--repetitions") { o.reps = true; continue; }
    if (a === "--min-repetitions") { o.minReps = parseInt(argv[++i] || "1", 10); continue; }
    if (a === "--min-substring-length") { o.minSubLen = parseInt(argv[++i] || "1", 10); continue; }
    if (a === "--no-start-anchor") { o.start = false; continue; }
    if (a === "--no-end-anchor") { o.end = false; continue; }
    if (a === "--no-anchors") { o.start = false; o.end = false; continue; }
    if (a === "--verbose") { o.verbose = true; continue; }
    if (a === "--colorize") { o.color = true; continue; }
    if (a === "--ignore-case") { o.ignoreCase = true; continue; }
    if (a === "--capture-groups") { o.capture = true; continue; }
    if (a.startsWith("-") && a.length >= 2 && !a.startsWith("--")) {
      let ok = true;
      for (const ch of a.slice(1)) {
        if (!"dDsSwWergxic".includes(ch)) { ok = false; break; }
        if (ch === "d") o.digits = true; else if (ch === "D") o.nonDigits = true;
        else if (ch === "s") o.spaces = true; else if (ch === "S") o.nonSpaces = true;
        else if (ch === "w") o.words = true; else if (ch === "W") o.nonWords = true;
        else if (ch === "e") o.escape = true; else if (ch === "r") o.reps = true;
        else if (ch === "g") o.capture = true; else if (ch === "x") o.verbose = true;
        else if (ch === "i") o.ignoreCase = true; else if (ch === "c") o.color = true;
      }
      if (ok) continue;
    }
    o.inputs.push(a);
  }
  return o;
}

function stdin(): string { return fs.readFileSync(0, "utf8"); }
function getInputs(o: Opts): string[] {
  if (o.file !== undefined) {
    const path = o.file === "-" ? stdin().trimEnd() : o.file;
    try { return fs.readFileSync(path, "utf8").replace(/\r\n/g, "\n").replace(/\n$/, "").split("\n"); }
    catch { die("error: the specified file could not be found", 1); }
  }
  if (o.inputs.length === 1 && o.inputs[0] === "-") return stdin().replace(/\r\n/g, "\n").replace(/\n$/, "").split("\n");
  if (o.inputs.length === 0) die("error: the following required arguments were not provided:\n  --file <FILE>\n  <INPUT>...\n\nUsage: grex [OPTIONS] {INPUT...|--file <FILE>}\n\nFor more information, try '--help'.", 2);
  return o.inputs;
}

function graphemes(s: string): string[] {
  const out: string[] = [];
  for (const ch of Array.from(s)) {
    if (out.length && /\p{Mark}/u.test(ch)) out[out.length - 1] += ch;
    else out.push(ch);
  }
  return out;
}
function isDigit(ch: string) { return /^\p{Decimal_Number}$/u.test(ch); }
function isSpace(ch: string) { return /^\s$/u.test(ch); }
function isWord(ch: string) { return /^[\p{Alphabetic}\p{Mark}\p{Decimal_Number}\p{Connector_Punctuation}\u200c\u200d]$/u.test(ch); }

function escLit(g: string, o: Opts): string {
  let r = "";
  for (const ch of Array.from(g)) {
    const cp = ch.codePointAt(0)!;
    if (o.escape && cp > 0x7f) {
      if (o.surrogates && cp > 0xffff) {
        const n = cp - 0x10000, hi = 0xd800 + (n >> 10), lo = 0xdc00 + (n & 1023);
        r += `\\u{${hi.toString(16)}}\\u{${lo.toString(16)}}`;
      } else r += `\\u{${cp.toString(16)}}`;
    } else if (/[\\^$.*+?()[\]{}|\-]/u.test(ch)) r += "\\" + ch;
    else r += ch;
  }
  return r;
}
function atom(g: string, o: Opts): string {
  if (Array.from(g).length === 1) {
    const ch = g;
    if (o.digits && isDigit(ch)) return "\\d";
    if (o.spaces && isSpace(ch)) return "\\s";
    if (o.words && isWord(ch)) return "\\w";
    if (o.nonDigits && !isDigit(ch)) return "\\D";
    if (o.nonWords && !isWord(ch)) return "\\W";
    if (o.nonSpaces && !isSpace(ch)) return "\\S";
  }
  return escLit(g, o);
}

function unescapeOne(s: string): string | null {
  if (s.length === 1) return s;
  if (s.length === 2 && s[0] === "\\") return s[1];
  return null;
}
function classEsc(raw: string): string { return raw.replace(/\\/g, "\\\\").replace(/]/g, "\\]").replace(/\^/g, "\\^").replace(/-/g, "\\-"); }
function tryCharClass(alts: string[]): string | null {
  const chars: string[] = [];
  for (const a of alts) { const u = unescapeOne(a); if (u === null || Array.from(u).length !== 1) return null; chars.push(u); }
  if (chars.length < 2) return null;
  const cps = [...new Set(chars)].map(c => c.codePointAt(0)!).sort((a, b) => a - b);
  let body = "";
  for (let i = 0; i < cps.length;) {
    let j = i; while (j + 1 < cps.length && cps[j + 1] === cps[j] + 1) j++;
    if (j - i >= 2) body += classEsc(String.fromCodePoint(cps[i])) + "-" + classEsc(String.fromCodePoint(cps[j]));
    else for (let k = i; k <= j; k++) body += classEsc(String.fromCodePoint(cps[k]));
    i = j + 1;
  }
  return `[${body}]`;
}
function group(s: string, o: Opts) { return (o.capture ? "(" : "(?:") + s + ")"; }
function optional(s: string, o: Opts): string {
  if (/^\((?:\?:)?/.test(s) && s.endsWith(")")) return s + "?";
  if (/^\\[dDsSwW]$/.test(s)) return group(s, o) + "?";
  if (/^(?:\\.|(\[[^\]]+\])|[^\\|(){}?+*])$/.test(s)) return s + "?";
  return group(s, o) + "?";
}

function cmpAlt(a: string, b: string) {
  const eff = (s: string) => s.replace(/\(\?:/g, "").replace(/[()?]/g, "").replace(/\{[^}]+\}/g, "").replace(/\[[^\]]+\]/g, "x").replace(/\\./g, "x").length;
  const la = eff(a), lb = eff(b);
  if (lb !== la) return lb - la;
  return a.localeCompare(b);
}

function commonPrefix(seqs: string[][]): number {
  let n = 0;
  while (seqs.every(s => s.length > n && s[n] === seqs[0][n])) n++;
  return n;
}
function commonSuffix(seqs: string[][]): number {
  let n = 0;
  while (seqs.every(s => s.length > n && s[s.length - 1 - n] === seqs[0][seqs[0].length - 1 - n])) n++;
  return n;
}
function joinAlternatives(alts: string[], o: Opts): string {
  const q = compactQuantifierAlts(alts, o);
  if (q !== null) return q;
  const singles: string[] = [], rest: string[] = [];
  for (const a of alts) (unescapeOne(a) !== null ? singles : rest).push(a);
  if (singles.length >= 2) rest.push(tryCharClass(singles)!);
  else rest.push(...singles);
  rest.sort(cmpAlt);
  if (rest.length === 1) return rest[0];
  return group(rest.join("|"), o);
}
function compactQuantifierAlts(alts: string[], o: Opts): string | null {
  if (alts.length < 2) return null;
  let base: string | null = null; const nums: number[] = [];
  for (const a of alts) {
    const m = a.match(/^(.*?)(?:\{(\d+)\})?$/);
    if (!m || m[1] === "" || m[1].includes("|") || m[1].endsWith("}")) return null;
    if (base === null) base = m[1]; else if (base !== m[1]) return null;
    nums.push(m[2] ? parseInt(m[2], 10) : 1);
  }
  nums.sort((a, b) => a - b);
  const parts: string[] = [];
  for (let i = 0; i < nums.length;) {
    let j = i; while (j + 1 < nums.length && nums[j + 1] === nums[j] + 1) j++;
    if (i === j) parts.push(nums[i] === 1 ? base! : `${base}{${nums[i]}}`);
    else parts.push(`${base}{${nums[i]},${nums[j]}}`);
    i = j + 1;
  }
  return parts.length === 1 ? parts[0] : group(parts.join("|"), o);
}
function buildSeqs(inputSeqs: string[][], o: Opts): string {
  const seen = new Set<string>(), seqs: string[][] = [];
  for (const s of inputSeqs) { const k = s.join("\0"); if (!seen.has(k)) { seen.add(k); seqs.push(s); } }
  if (seqs.length === 0) return "";
  if (seqs.length === 1) return seqs[0].join("");
  const empty = seqs.filter(s => s.length === 0);
  const nonEmpty = seqs.filter(s => s.length > 0);
  if (empty.length) return optional(buildSeqs(nonEmpty, o), o);
  const pre = commonPrefix(seqs);
  if (pre > 0) return seqs[0].slice(0, pre).join("") + buildSeqs(seqs.map(s => s.slice(pre)), o);
  const suf = commonSuffix(seqs);
  if (suf > 0) return buildSeqs(seqs.map(s => s.slice(0, s.length - suf)), o) + seqs[0].slice(seqs[0].length - suf).join("");
  const groups = new Map<string, string[][]>();
  for (const s of seqs) {
    if (!groups.has(s[0])) groups.set(s[0], []);
    groups.get(s[0])!.push(s.slice(1));
  }
  const alts = [...groups.entries()].map(([head, tails]) => head + buildSeqs(tails, o));
  return joinAlternatives(alts, o);
}

function applyRepsToSeq(seq: string[], o: Opts): string[] {
  const out: string[] = []; let i = 0;
  while (i < seq.length) {
    let bestLen = 0, bestCount = 0;
    for (let len = Math.max(1, o.minSubLen); len <= Math.floor((seq.length - i) / 2); len++) {
      let c = 1;
      while (i + (c + 1) * len <= seq.length && seq.slice(i, i + len).join("\0") === seq.slice(i + c * len, i + (c + 1) * len).join("\0")) c++;
      if (c - 1 >= o.minReps && c * len > bestCount * bestLen) { bestLen = len; bestCount = c; }
    }
    if (bestCount) {
      const part = seq.slice(i, i + bestLen).join("");
      out.push((bestLen === 1 ? part : group(part, o)) + `{${bestCount}}`);
      i += bestLen * bestCount;
    } else out.push(seq[i++]);
  }
  return out;
}

function buildRegex(inputs: string[], o: Opts): string {
  const seqs: string[][] = [];
  for (const s0 of [...new Set(inputs.map(s => o.ignoreCase ? s.toLocaleLowerCase() : s))]) {
    let seq = graphemes(s0).map(g => atom(g, o));
    if (o.reps) seq = applyRepsToSeq(seq, o);
    seqs.push(seq);
  }
  let body = buildSeqs(seqs, o);
  if (o.start) body = "^" + body;
  if (o.end) body += "$";
  if (o.ignoreCase) body = "(?i)" + body;
  if (o.verbose) body = verbose(body);
  return body;
}

function verbose(re: string): string {
  const lines: string[] = ["(?x)"];
  let i = 0, ind = 0, cur = "";
  const emit = () => { if (cur) { lines.push("  ".repeat(ind) + cur); cur = ""; } };
  while (i < re.length) {
    if (re.startsWith("(?i)", i)) { cur += "(?i)"; i += 4; continue; }
    const ch = re[i++];
    if (ch === "(") {
      emit();
      if (re.startsWith("?:", i)) { lines.push("  ".repeat(ind) + "(?:"); i += 2; } else lines.push("  ".repeat(ind) + "(");
      ind++;
    } else if (ch === ")") {
      emit(); ind = Math.max(0, ind - 1);
      let suffix = ""; if (i < re.length && "?*+".includes(re[i])) suffix = re[i++];
      lines.push("  ".repeat(ind) + ")" + suffix);
    } else if (ch === "|") {
      emit(); lines.push("  ".repeat(ind) + "|");
    } else cur += ch;
  }
  emit();
  return lines.join("\n");
}

const opts = parseArgs(process.argv.slice(2));
console.log(buildRegex(getInputs(opts), opts));
