declare const require: any;
declare const process: any;
const { spawnSync } = require("child_process");
const fs = require("fs");
const path = require("path");

type Patch = { name: string; commit: string; message: string };
type State = { base: string; applied: Patch[]; unapplied: Patch[]; hidden: Patch[] };

function run(cmd: string, args: string[], opts: any = {}) {
  return spawnSync(cmd, args, { encoding: "utf8", ...opts });
}

function git(args: string[], opts: any = {}) {
  const r = run("git", args, opts);
  if (opts.check !== false && r.status !== 0) {
    if (r.stdout) process.stdout.write(r.stdout);
    if (r.stderr) process.stderr.write(r.stderr);
    process.exit(r.status || 1);
  }
  return (r.stdout || "").trimEnd();
}

function gitMaybe(args: string[]) {
  return run("git", args, { encoding: "utf8" });
}

function die(msg: string, code = 2): never {
  process.stderr.write(`error: ${msg}\n`);
  process.exit(code);
  throw new Error(msg);
}

function branch(): string {
  const b = gitMaybe(["rev-parse", "--abbrev-ref", "HEAD"]);
  if (b.status !== 0) die("not a git repository (or any of the parent directories): .git", 1);
  return (b.stdout || "").trim();
}

function gitDir(): string {
  const gd = gitMaybe(["rev-parse", "--git-dir"]);
  if (gd.status !== 0) die("not a git repository (or any of the parent directories): .git", 1);
  return path.resolve((gd.stdout || "").trim());
}

function stateFile(br = branch()): string {
  return path.join(gitDir(), "stg-ts", encodeURIComponent(br) + ".json");
}

function head(): string {
  return git(["rev-parse", "HEAD"]);
}

function emptyState(): State {
  return { base: head(), applied: [], unapplied: [], hidden: [] };
}

function load(): State {
  const f = stateFile();
  if (!fs.existsSync(f)) return emptyState();
  return JSON.parse(fs.readFileSync(f, "utf8"));
}

function save(st: State) {
  const f = stateFile();
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f, JSON.stringify(st, null, 2));
}

function ensure(): State {
  const f = stateFile();
  if (!fs.existsSync(f)) {
    const st = emptyState();
    save(st);
    return st;
  }
  return load();
}

function stripGlobal(argv: string[]): string[] {
  const out: string[] = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--color" || a === "-C") {
      const v = argv[++i];
      if (a === "-C" && v) process.chdir(v);
      continue;
    }
    if (a.startsWith("--color=")) continue;
    out.push(a);
  }
  return out;
}

function slug(s: string): string {
  const x = s.toLowerCase().replace(/[^a-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "");
  return x || "patch";
}

function parseMessage(args: string[]) {
  let msg = "";
  let name = "";
  let refresh = false;
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-m" || a === "--message") msg += (msg ? "\n\n" : "") + (args[++i] || "");
    else if (a.startsWith("--message=")) msg += (msg ? "\n\n" : "") + a.slice(10);
    else if (a === "-n" || a === "--name") name = args[++i] || "";
    else if (a.startsWith("--name=")) name = a.slice(7);
    else if (a === "-r" || a === "--refresh") refresh = true;
    else if (a === "-e" || a === "--edit" || a === "-d" || a === "--diff") continue;
    else if (a === "--") rest.push(...args.slice(i + 1));
    else if (a.startsWith("-")) continue;
    else rest.push(a);
  }
  if (!name && rest.length) name = rest.shift() || "";
  if (!msg) msg = name || "patch";
  if (!name) name = slug(msg.split(/\r?\n/)[0]);
  return { msg, name, refresh, paths: rest };
}

function patchByRev(st: State, rev?: string): Patch | undefined {
  if (!rev || rev === "HEAD" || rev === "{top}") return st.applied[st.applied.length - 1];
  if (rev === "{base}") return { name: "{base}", commit: st.base, message: "base" };
  return [...st.applied, ...st.unapplied, ...st.hidden].find(p => p.name === rev || p.commit.startsWith(rev));
}

function commitSubject(rev: string): string {
  return git(["log", "-1", "--format=%s", rev], { check: false }) || "";
}

function mainHelp() {
  process.stdout.write(`Maintain a stack of patches on top of a Git branch.

Usage: stg [OPTIONS] <command> [...]
       stg [OPTIONS] <-h|--help>
       stg --version

Patch inspection commands:
  diff   Show a diff
  files  Show files modified by a patch
  id     Print git hash of a StGit revision
  log    Display or optionally clear the stack changelog
  name   Print patch name of a StGit revision
  show   Show patch commits

Patch manipulation commands:
  new      Create a new patch at top of the stack
  refresh  Incorporate worktree changes into current patch
  rename   Rename a patch

Stack inspection commands:
  next     Print the name of the next patch
  prev     Print the name of the previous patch
  series   Display the patch series
  top      Print the name of the top patch

Stack manipulation commands:
  branch  Branch operations: switch, list, create, rename, delete, ...
  delete  Delete patches
  init    Initialize a StGit stack on a branch
  pop     Pop (unapply) one or more applied patches
  push    Push (apply) one or more unapplied patches

Administration commands:
  version  Print version information and exit

Aliases:
  add       Alias for shell command \`git add\`
  mv        Alias for shell command \`git mv\`
  resolved  Alias for shell command \`git add\`
  rm        Alias for shell command \`git rm\`
  status    Alias for shell command \`git status -s\`

Help:
  help  Print this message or the help of the given subcommand(s)
`);
}

function cmdVersion(args: string[]) {
  if (args.includes("-s") || args.includes("--short")) process.stdout.write("Stacked Git 2.5.5\n");
  else process.stdout.write(`Stacked Git 2.5.5
Copyright (C) 2005-2025 StGit authors
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
SPDX-License-Identifier: GPL-2.0-only
git version 2.34.1
`);
}

function cmdInit() {
  save(emptyState());
}

function cmdNew(args: string[]) {
  const st = ensure();
  const p = parseMessage(args);
  if ([...st.applied, ...st.unapplied, ...st.hidden].some(x => x.name === p.name)) die(`patch \`${p.name}\` already exists`);
  if (p.refresh) git(["add", "-A", ...(p.paths || [])]);
  git(["commit", "--allow-empty", "-m", p.msg], { stdio: "ignore" });
  const patch = { name: p.name, commit: head(), message: p.msg };
  st.applied.push(patch);
  save(st);
  process.stdout.write(`> ${p.name} (new)\n`);
}

function selected(st: State, args: string[]) {
  let patches: Patch[] = [...st.applied, ...st.unapplied];
  if (args.includes("-A") || args.includes("--applied")) patches = [...st.applied];
  if (args.includes("-U") || args.includes("--unapplied")) patches = [...st.unapplied];
  if (args.includes("-H") || args.includes("--hidden")) patches = [...st.hidden];
  if (args.includes("-a") || args.includes("--all")) patches = [...st.applied, ...st.unapplied, ...st.hidden];
  const names = args.filter(a => !a.startsWith("-"));
  if (names.length) patches = patches.filter(p => names.includes(p.name));
  if (args.includes("-r") || args.includes("--reverse")) patches.reverse();
  return patches;
}

function cmdSeries(args: string[]) {
  const st = load();
  const patches = selected(st, args);
  if (args.includes("-c") || args.includes("--count")) {
    process.stdout.write(String(patches.length) + "\n");
    return;
  }
  const noPrefix = args.includes("-P") || args.includes("--no-prefix");
  const desc = args.includes("-d") || args.includes("--description");
  const ids = args.some(a => a === "-i" || a === "--commit-id" || a.startsWith("--commit-id"));
  for (const p of patches) {
    let pref = "";
    if (!noPrefix) {
      if (st.hidden.some(x => x.name === p.name)) pref = "! ";
      else if (st.unapplied.some(x => x.name === p.name)) pref = "- ";
      else pref = (st.applied[st.applied.length - 1]?.name === p.name ? "> " : "+ ");
    }
    let line = pref + p.name;
    if (ids) line += " " + p.commit;
    if (desc) line += "  " + commitSubject(p.commit);
    process.stdout.write(line + "\n");
  }
}

function cmdTop() {
  const a = load().applied;
  const p = a[a.length - 1];
  if (!p) die("no patches applied");
  process.stdout.write(p.name + "\n");
}

function cmdPrev() {
  const a = load().applied;
  if (a.length < 2) die("not enough patches applied");
  process.stdout.write(a[a.length - 2].name + "\n");
}

function cmdNext() {
  const p = load().unapplied[0];
  if (!p) die("no unapplied patches");
  process.stdout.write(p.name + "\n");
}

function cmdPop(args: string[]) {
  const st = ensure();
  if (!st.applied.length) die("no patches applied");
  let n = 1;
  if (args.includes("-a") || args.includes("--all")) n = st.applied.length;
  const ni = args.findIndex(a => a === "-n" || a === "--number");
  if (ni >= 0) n = Math.max(0, parseInt(args[ni + 1] || "1", 10));
  for (let i = 0; i < n && st.applied.length; i++) {
    const p = st.applied.pop()!;
    p.commit = head();
    git(["reset", "--hard", "HEAD^"], { stdio: "ignore" });
    st.unapplied.unshift(p);
    process.stdout.write(`- ${p.name}\n`);
  }
  const top = st.applied[st.applied.length - 1];
  if (top) process.stdout.write(`> ${top.name}\n`);
  save(st);
}

function cmdPush(args: string[]) {
  const st = ensure();
  if (!st.unapplied.length) die("no unapplied patches");
  let list: Patch[] = [];
  if (args.includes("-a") || args.includes("--all")) list = [...st.unapplied];
  else {
    const names = args.filter(a => !a.startsWith("-"));
    if (names.length) list = names.map(n => st.unapplied.find(p => p.name === n)).filter(Boolean) as Patch[];
    else list = [st.unapplied[0]];
  }
  for (const p of list) {
    git(["cherry-pick", "--allow-empty", "--keep-redundant-commits", p.commit], { stdio: "ignore" });
    st.unapplied = st.unapplied.filter(x => x.name !== p.name);
    p.commit = head();
    st.applied.push(p);
    process.stdout.write(`> ${p.name}\n`);
  }
  save(st);
}

function cmdRefresh(args: string[]) {
  const st = ensure();
  const p = st.applied[st.applied.length - 1];
  if (!p) die("no patches applied");
  const paths = args.filter(a => !a.startsWith("-"));
  git(["add", "-A", ...paths]);
  const r = gitMaybe(["diff", "--cached", "--quiet"]);
  if (r.status === 0) return;
  git(["commit", "--amend", "--no-edit"], { stdio: "ignore" });
  p.commit = head();
  save(st);
}

function cmdDelete(args: string[]) {
  const st = ensure();
  let names = args.filter(a => !a.startsWith("-"));
  if (args.includes("-t") || args.includes("--top")) {
    const top = st.applied[st.applied.length - 1];
    names = top ? [top.name] : [];
  }
  if (args.includes("-a") || args.includes("--all")) names = [...st.applied, ...st.unapplied].map(p => p.name);
  if (!names.length) die("no patches specified");
  for (const n of names) {
    const idxA = st.applied.findIndex(p => p.name === n);
    if (idxA === st.applied.length - 1) {
      git(["reset", "--hard", "HEAD^"], { stdio: "ignore" });
      st.applied.pop();
      process.stdout.write(`- ${n}\n`);
    } else {
      st.unapplied = st.unapplied.filter(p => p.name !== n);
      st.hidden = st.hidden.filter(p => p.name !== n);
    }
  }
  save(st);
}

function cmdId(args: string[]) {
  const st = load();
  const rev = args.find(a => !a.startsWith("-"));
  const p = patchByRev(st, rev);
  process.stdout.write((p ? p.commit : git(["rev-parse", rev || "HEAD"])) + "\n");
}

function cmdName(args: string[]) {
  const st = load();
  const rev = args.find(a => !a.startsWith("-"));
  const p = patchByRev(st, rev);
  if (!p || p.name === "{base}") die("revision does not refer to a patch");
  process.stdout.write(p.name + "\n");
}

function cmdFiles(args: string[]) {
  const st = load();
  const rev = args.find(a => !a.startsWith("-"));
  const p = patchByRev(st, rev);
  const stat = args.includes("-s") || args.includes("--stat");
  if (!p) die("no patches applied");
  const gargs = stat ? ["show", "--stat", "--oneline", "--no-renames", p.commit] : ["diff-tree", "--no-commit-id", "--name-only", "-r", p.commit];
  const r = run("git", gargs, { encoding: "utf8" });
  process.stdout.write(r.stdout || "");
}

function cmdDiff(args: string[]) {
  const stat = args.includes("-s") || args.includes("--stat");
  const ri = args.findIndex(a => a === "-r" || a === "--range");
  const gargs = ["diff"];
  if (stat) gargs.push("--stat");
  if (ri >= 0) gargs.push(args[ri + 1].replace("..", " "));
  gargs.push(...args.filter((a, i) => !a.startsWith("-") && i !== ri + 1));
  const r = run("git", gargs.flatMap(a => a.includes(" ") ? a.split(" ") : [a]), { encoding: "utf8" });
  process.stdout.write(r.stdout || "");
  if (r.stderr) process.stderr.write(r.stderr);
  process.exit(r.status || 0);
}

function cmdShow(args: string[]) {
  const st = load();
  let revs = args.filter(a => !a.startsWith("-"));
  if (!revs.length) {
    const top = st.applied[st.applied.length - 1];
    revs = [top ? top.name : "HEAD"];
  }
  const stat = args.includes("-s") || args.includes("--stat");
  const commits = revs.map(r => patchByRev(st, r)?.commit || r);
  const r = run("git", ["show", ...(stat ? ["--stat"] : []), ...commits], { encoding: "utf8" });
  process.stdout.write(r.stdout || "");
  if (r.stderr) process.stderr.write(r.stderr);
  process.exit(r.status || 0);
}

function cmdBranch(args: string[]) {
  if (!args.length) { process.stdout.write(branch() + "\n"); return; }
  if (args.includes("-l") || args.includes("--list")) {
    const r = run("git", ["branch"], { encoding: "utf8" }); process.stdout.write(r.stdout || ""); return;
  }
  const ci = args.findIndex(a => a === "-c" || a === "--create");
  if (ci >= 0) { git(["checkout", "-b", args[ci + 1], ...(args[ci + 2] ? [args[ci + 2]] : [])], { stdio: "inherit" }); cmdInit(); return; }
  const di = args.findIndex(a => a === "-D" || a === "--delete");
  if (di >= 0) { git(["branch", "-D", args[di + 1] || ""], { stdio: "inherit" }); return; }
  git(["checkout", args[args.length - 1]], { stdio: "inherit" });
}

function gitAlias(cmd: string, args: string[]) {
  const real = cmd === "status" ? ["status", "-s", ...args] : [cmd === "resolved" ? "add" : cmd, ...args];
  const r = run("git", real, { stdio: "inherit" });
  process.exit(r.status || 0);
}

function dispatch() {
  const argv = stripGlobal(process.argv.slice(2));
  if (!argv.length || argv[0] === "-h" || argv[0] === "--help") return mainHelp();
  if (argv[0] === "--version") return cmdVersion([]);
  let cmd = argv.shift()!;
  if (cmd === "help") {
    if (!argv.length) return mainHelp();
    cmd = argv.shift()!;
    argv.unshift("--help");
  }
  if (argv.includes("-h") || argv.includes("--help")) {
    process.stdout.write(`${cmd[0].toUpperCase() + cmd.slice(1)} command\n\nUsage: stg ${cmd} [OPTIONS] [args]\n`);
    return;
  }
  switch (cmd) {
    case "version": return cmdVersion(argv);
    case "init": return cmdInit();
    case "new": return cmdNew(argv);
    case "series": return cmdSeries(argv);
    case "top": return cmdTop();
    case "prev": return cmdPrev();
    case "next": return cmdNext();
    case "pop": return cmdPop(argv);
    case "push": return cmdPush(argv);
    case "refresh": return cmdRefresh(argv);
    case "delete": return cmdDelete(argv);
    case "id": return cmdId(argv);
    case "name": return cmdName(argv);
    case "files": return cmdFiles(argv);
    case "diff": return cmdDiff(argv);
    case "show": return cmdShow(argv);
    case "branch": return cmdBranch(argv);
    case "status": case "add": case "rm": case "mv": case "resolved": return gitAlias(cmd, argv);
    default: die(`unrecognized subcommand '${cmd}'`);
  }
}

dispatch();
