declare const require: any;
declare const process: any;
declare const Buffer: any;

const dgram = require("dgram");
const net = require("net");
const fs = require("fs");

const HELP = `dog ● command-line DNS client

Usage:
  dog [OPTIONS] [--] <arguments>

Examples:
  dog example.net                          Query a domain using default settings
  dog example.net MX                       ...looking up MX records instead
  dog example.net MX @1.1.1.1              ...using a specific nameserver instead
  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP
  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments

Query options:
  <arguments>              Human-readable host names, nameservers, types, or classes
  -q, --query=HOST         Host name or domain name to query
  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)
  -n, --nameserver=ADDR    Address of the nameserver to send packets to
  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)

Sending options:
  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)
  --txid=NUMBER            Set the transaction ID to a specific value
  -Z=TWEAKS                Set uncommon protocol-level tweaks

Protocol options:
  -U, --udp                Use the DNS protocol over UDP
  -T, --tcp                Use the DNS protocol over TCP
  -S, --tls                Use the DNS-over-TLS protocol
  -H, --https              Use the DNS-over-HTTPS protocol

Output options:
  -1, --short              Short mode: display nothing but the first result
  -J, --json               Display the output as JSON
  --color, --colour=WHEN   When to colourise the output (always, automatic, never)
  --seconds                Do not format durations, display them as seconds
  --time                   Print how long the response took to arrive

Meta options:
  -?, --help               Print list of command-line options
  -v, --version            Print version information`;

const VERSION = `dog ● command-line DNS client
v0.2.0-pre [d3a34280] built on 2026-04-17 (pre-release!)
mhttps://dns.lookup.dog/`;

const TYPES: Record<string, number> = {
  A: 1, NS: 2, CNAME: 5, SOA: 6, PTR: 12, HINFO: 13, MX: 15, TXT: 16,
  AAAA: 28, LOC: 29, SRV: 33, NAPTR: 35, CAA: 257, SSHFP: 44, TLSA: 52,
  OPT: 41, ANY: 255, AFSDB: 18, IXFR: 251, AXFR: 252
};
const TYPE_BY_NUM: Record<number, string> = Object.fromEntries(Object.entries(TYPES).map(([k, v]) => [v, k]));
const CLASSES: Record<string, number> = { IN: 1, CH: 3, HS: 4 };
const CLASS_BY_NUM: Record<number, string> = { 1: "IN", 3: "CH", 4: "HS" };

type Opts = {
  domains: string[]; types: string[]; classes: string[]; nameservers: string[];
  short: boolean; json: boolean; time: boolean; seconds: boolean;
  tcp: boolean; tls: boolean; https: boolean; txid?: number;
};

function dieOptions(msg: string): never {
  console.error(`dog: Invalid options: ${msg}`);
  process.exit(3);
  throw new Error(msg);
}

function takeValue(args: string[], i: number, opt: string): [string, number] {
  if (i + 1 >= args.length) dieOptions(`Argument to option '${opt}' missing`);
  return [args[i + 1], i + 1];
}

function parseArgs(argv: string[]): Opts | "help" | "version" {
  const o: Opts = { domains: [], types: [], classes: [], nameservers: [], short: false, json: false, time: false, seconds: false, tcp: false, tls: false, https: false };
  let positionalOnly = false;
  function addType(v: string) {
    const t = v.toUpperCase();
    if (!(t in TYPES) && !/^TYPE\d+$/.test(t)) dieOptions(`Invalid query type "${v}"`);
    o.types.push(t);
  }
  function addClass(v: string) {
    const c = v.toUpperCase();
    if (!(c in CLASSES)) dieOptions(`Invalid query class "${v}"`);
    o.classes.push(c);
  }
  function addTxid(v: string) {
    if (!/^\d+$/.test(v) || Number(v) < 0 || Number(v) > 65535) dieOptions(`Invalid transaction ID "${v}"`);
    o.txid = Number(v);
  }
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (!positionalOnly && a === "--") { positionalOnly = true; continue; }
    if (!positionalOnly && (a === "--help" || a === "-?")) return "help";
    if (!positionalOnly && (a === "--version" || a === "-v")) return "version";
    if (!positionalOnly && a.startsWith("--")) {
      let key = a, val: string | undefined;
      const eq = a.indexOf("=");
      if (eq >= 0) { key = a.slice(0, eq); val = a.slice(eq + 1); }
      const need = (name: string) => {
        if (val !== undefined) return val;
        const got = takeValue(argv, i, name); i = got[1]; return got[0];
      };
      if (key === "--query") o.domains.push(need("query"));
      else if (key === "--type") addType(need("type"));
      else if (key === "--nameserver") o.nameservers.push(need("nameserver"));
      else if (key === "--class") addClass(need("class"));
      else if (key === "--edns") { const v = need("edns"); if (!["disable", "hide", "show"].includes(v)) dieOptions(`Invalid EDNS setting "${v}"`); }
      else if (key === "--txid") addTxid(need("txid"));
      else if (key === "--udp") {}
      else if (key === "--tcp") o.tcp = true;
      else if (key === "--tls") o.tls = true;
      else if (key === "--https") o.https = true;
      else if (key === "--short") o.short = true;
      else if (key === "--json") o.json = true;
      else if (key === "--seconds") o.seconds = true;
      else if (key === "--time") o.time = true;
      else if (key === "--color" || key === "--colour") { if (val === undefined && i + 1 < argv.length && !argv[i + 1].startsWith("-")) i++; }
      else dieOptions(`Unrecognized option: '${key.replace(/^--/, "")}'`);
      continue;
    }
    if (!positionalOnly && a.startsWith("-") && a !== "-") {
      if (a === "-1") { o.short = true; continue; }
      if (a === "-J") { o.json = true; continue; }
      if (a === "-U") continue;
      if (a === "-T") { o.tcp = true; continue; }
      if (a === "-S") { o.tls = true; continue; }
      if (a === "-H") { o.https = true; continue; }
      if (a === "-q" || a === "-t" || a === "-n" || a === "-Z") {
        const got = takeValue(argv, i, a.slice(1)); i = got[1];
        if (a === "-q") o.domains.push(got[0]);
        else if (a === "-t") addType(got[0]);
        else if (a === "-n") o.nameservers.push(got[0]);
        else if (!/^aa$|^ad$|^cd$|^bufsize=\d+$/i.test(got[0])) dieOptions(`Invalid protocol tweak "${got[0]}"`);
        continue;
      }
      if (a.startsWith("-Z=")) { const v = a.slice(3); if (!/^aa$|^ad$|^cd$|^bufsize=\d+$/i.test(v)) dieOptions(`Invalid protocol tweak "${v}"`); continue; }
      dieOptions(`Unrecognized option: '${a.replace(/^-+/, "")}'`);
    }
    if (a.startsWith("@")) o.nameservers.push(a.slice(1));
    else {
      const up = a.toUpperCase();
      if (up in TYPES || /^TYPE\d+$/.test(up)) addType(a);
      else if (up in CLASSES) addClass(a);
      else o.domains.push(a);
    }
  }
  if (o.domains.length === 0) {
    console.log(HELP);
    process.exit(3);
  }
  if (o.types.length === 0) o.types.push("A");
  if (o.classes.length === 0) o.classes.push("IN");
  if (o.nameservers.length === 0) o.nameservers = systemNameservers();
  return o;
}

function systemNameservers(): string[] {
  try {
    const txt = fs.readFileSync("/etc/resolv.conf", "utf8");
    const ns = txt.split(/\n/).map((l: string) => l.trim().match(/^nameserver\s+(\S+)/)?.[1]).filter(Boolean);
    if (ns.length) return ns;
  } catch {}
  return ["127.0.0.53"];
}

function parseNs(s: string): { host: string; port: number } {
  if (s.startsWith("[")) {
    const end = s.indexOf("]");
    const host = s.slice(1, end);
    const port = s[end + 1] === ":" ? Number(s.slice(end + 2)) : 53;
    return { host, port: port || 53 };
  }
  const idx = s.lastIndexOf(":");
  if (idx > -1 && s.indexOf(":") === idx && /^\d+$/.test(s.slice(idx + 1))) return { host: s.slice(0, idx), port: Number(s.slice(idx + 1)) };
  return { host: s, port: 53 };
}

function encName(name: string): any {
  const parts = name.replace(/\.$/, "").split(".").filter(Boolean);
  return Buffer.concat([...parts.map((p: string) => Buffer.concat([Buffer.from([Buffer.byteLength(p)]), Buffer.from(p)])), Buffer.from([0])]);
}

function packet(domain: string, type: string, klass: string, txid: number): any {
  const tail = Buffer.alloc(4);
  tail.writeUInt16BE(TYPES[type], 0);
  tail.writeUInt16BE(CLASSES[klass], 2);
  const q = Buffer.concat([encName(domain), tail]);
  const h = Buffer.alloc(12);
  h.writeUInt16BE(txid, 0); h.writeUInt16BE(0x0100, 2); h.writeUInt16BE(1, 4);
  return Buffer.concat([h, q]);
}

function queryUdp(buf: any, ns: { host: string; port: number }): Promise<any> {
  return new Promise((resolve, reject) => {
    const sock = dgram.createSocket(net.isIP(ns.host) === 6 ? "udp6" : "udp4");
    const timer = setTimeout(() => { sock.close(); reject(new Error("timed out")); }, 5000);
    sock.once("error", (e: any) => { clearTimeout(timer); sock.close(); reject(e); });
    sock.once("message", (msg: any) => { clearTimeout(timer); sock.close(); resolve(msg); });
    sock.send(buf, ns.port, ns.host, (e: any) => { if (e) { clearTimeout(timer); sock.close(); reject(e); } });
  });
}

function queryTcp(buf: any, ns: { host: string; port: number }): Promise<any> {
  return new Promise((resolve, reject) => {
    const sock = net.createConnection(ns.port, ns.host);
    let chunks: any[] = [], need = -1;
    const timer = setTimeout(() => { sock.destroy(); reject(new Error("timed out")); }, 5000);
    sock.on("connect", () => { const len = Buffer.alloc(2); len.writeUInt16BE(buf.length); sock.write(Buffer.concat([len, buf])); });
    sock.on("data", (d: any) => {
      chunks.push(d); const all = Buffer.concat(chunks);
      if (need < 0 && all.length >= 2) need = all.readUInt16BE(0);
      if (need >= 0 && all.length >= need + 2) { clearTimeout(timer); sock.destroy(); resolve(all.slice(2, need + 2)); }
    });
    sock.on("error", (e: any) => { clearTimeout(timer); reject(e); });
  });
}

function readName(buf: any, off: number, seen = new Set<number>()): [string, number] {
  const labels: string[] = [];
  let pos = off, jumped = false, end = off;
  while (true) {
    const len = buf[pos];
    if ((len & 0xc0) === 0xc0) {
      const ptr = ((len & 0x3f) << 8) | buf[pos + 1];
      if (seen.has(ptr)) return [labels.join(".") + ".", pos + 2];
      seen.add(ptr);
      const got = readName(buf, ptr, seen);
      labels.push(got[0].replace(/\.$/, ""));
      if (!jumped) end = pos + 2;
      return [labels.filter(Boolean).join(".") + ".", end];
    }
    pos++;
    if (len === 0) { if (!jumped) end = pos; break; }
    labels.push(buf.slice(pos, pos + len).toString("utf8")); pos += len;
  }
  return [labels.join(".") + ".", end];
}

function ipv6(b: any): string {
  const words: number[] = [];
  for (let i = 0; i < 16; i += 2) words.push(b.readUInt16BE(i));
  let bestS = -1, bestL = 0;
  for (let i = 0; i < 8;) {
    if (words[i] !== 0) { i++; continue; }
    let j = i; while (j < 8 && words[j] === 0) j++;
    if (j - i > bestL) { bestS = i; bestL = j - i; }
    i = j;
  }
  if (bestL < 2) return words.map(w => w.toString(16)).join(":");
  const left = words.slice(0, bestS).map(w => w.toString(16)).join(":");
  const right = words.slice(bestS + bestL).map(w => w.toString(16)).join(":");
  return `${left}::${right}`.replace(/^:/, "::").replace(/:$/, "::");
}

function parseResponse(buf: any): any {
  let off = 12;
  const qd = buf.readUInt16BE(4), an = buf.readUInt16BE(6), ns = buf.readUInt16BE(8), ar = buf.readUInt16BE(10);
  const queries: any[] = [];
  for (let i = 0; i < qd; i++) {
    const rn = readName(buf, off); off = rn[1];
    const type = buf.readUInt16BE(off), klass = buf.readUInt16BE(off + 2); off += 4;
    queries.push({ name: rn[0], class: CLASS_BY_NUM[klass] || `CLASS${klass}`, type: TYPE_BY_NUM[type] || `TYPE${type}` });
  }
  function rr() {
    const rn = readName(buf, off); off = rn[1];
    const typeNum = buf.readUInt16BE(off), klassNum = buf.readUInt16BE(off + 2), ttl = buf.readUInt32BE(off + 4), len = buf.readUInt16BE(off + 8); off += 10;
    const start = off, rdata = buf.slice(off, off + len); off += len;
    const type = TYPE_BY_NUM[typeNum] || `TYPE${typeNum}`, klass = CLASS_BY_NUM[klassNum] || `CLASS${klassNum}`;
    let data: any = { bytes: Array.from(rdata) }, text = Array.from(rdata).join(" ");
    if (type === "A" && len === 4) { text = Array.from(rdata).join("."); data = { address: text }; }
    else if (type === "AAAA" && len === 16) { text = ipv6(rdata); data = { address: text }; }
    else if (["NS", "CNAME", "PTR"].includes(type)) { const n = readName(buf, start)[0]; text = `"${n}"`; data = { domain: n }; }
    else if (type === "MX") { const pref = rdata.readUInt16BE(0); const ex = readName(buf, start + 2)[0]; text = `${pref} "${ex}"`; data = { preference: pref, exchange: ex }; }
    else if (type === "TXT") { let p = 0, arr: string[] = []; while (p < rdata.length) { const l = rdata[p++]; arr.push(rdata.slice(p, p + l).toString("utf8")); p += l; } text = arr.map(s => `"${s}"`).join(" "); data = { strings: arr }; }
    else if (type === "SOA") { const m = readName(buf, start); const r = readName(buf, m[1]); text = `"${m[0]}" "${r[0]}"`; data = { mname: m[0], rname: r[0] }; }
    else if (type === "SRV") { const pri = rdata.readUInt16BE(0), weight = rdata.readUInt16BE(2), port = rdata.readUInt16BE(4), target = readName(buf, start + 6)[0]; text = `${pri} ${weight} ${port} "${target}"`; data = { priority: pri, weight, port, target }; }
    return { name: rn[0], class: klass, ttl, type, data, text };
  }
  const answers = [], authorities = [], additionals = [];
  for (let i = 0; i < an; i++) answers.push(rr());
  for (let i = 0; i < ns; i++) authorities.push(rr());
  for (let i = 0; i < ar; i++) additionals.push(rr());
  return { queries, answers, authorities, additionals };
}

function dur(ttl: number, seconds: boolean): string {
  if (seconds) return `${ttl}s`;
  const h = Math.floor(ttl / 3600), m = Math.floor((ttl % 3600) / 60), s = ttl % 60;
  if (h) return `${h}h${String(m).padStart(2, "0")}m${String(s).padStart(2, "0")}s`;
  return `${m}m${String(s).padStart(2, "0")}s`;
}

function printText(records: any[], seconds: boolean) {
  if (!records.length) return;
  const w = Math.max(...records.map(r => r.type.length));
  for (const r of records) {
    console.log(`${r.type.padStart(w)} ${r.name} ${dur(r.ttl, seconds).padEnd(7)} ${r.text}`);
  }
}

async function main() {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed === "help") { console.log(HELP); return; }
  if (parsed === "version") { console.log(VERSION); return; }
  const opts = parsed as Opts;
  const start = Date.now();
  const responses: any[] = [];
  let exit = 0, firstErr = "";
  for (const domain of opts.domains) for (const type of opts.types) for (const klass of opts.classes) for (const nsText of opts.nameservers) {
    const ns = parseNs(nsText);
    try {
      if (opts.tls || opts.https) throw new Error("unsupported protocol");
      const id = opts.txid ?? Math.floor(Math.random() * 65536);
      const q = packet(domain, type, klass, id);
      const msg = opts.tcp ? await queryTcp(q, ns) : await queryUdp(q, ns);
      responses.push(parseResponse(msg));
    } catch (e: any) {
      exit = 1;
      firstErr = formatError(e);
      if (!opts.json) console.error(`Error [network]: ${firstErr}`);
    }
  }
  if (opts.json) {
    console.log(JSON.stringify({ responses: responses.map(r => ({
      queries: r.queries,
      answers: r.answers.map(jsonRecord),
      authorities: r.authorities.map(jsonRecord),
      additionals: r.additionals.map(jsonRecord)
    })) }));
    if (exit) console.error(JSON.stringify({ error: true, error_phase: "network", error_message: firstErr }));
  } else if (opts.short) {
    const ans = responses.flatMap(r => r.answers);
    for (const r of ans) console.log(shortText(r));
    if (exit || ans.length === 0) { if (exit) console.error("No results"); process.exit(2); }
  } else {
    printText(responses.flatMap(r => r.answers), opts.seconds);
  }
  if (opts.time) console.log(`Ran in ${Date.now() - start}ms`);
  process.exit(exit);
}

function jsonRecord(r: any): any {
  return { name: r.name, class: r.class, ttl: r.ttl, type: r.type, data: r.data };
}

function shortText(r: any): string {
  if (r.type === "A" || r.type === "AAAA") return r.data.address;
  if (r.type === "MX") return r.data.exchange || r.text;
  if (r.data.domain) return r.data.domain;
  if (r.type === "TXT" && r.data.strings) return r.data.strings.join(" ");
  return r.text.replace(/^"|"$/g, "");
}

function formatError(e: any): string {
  if (e?.code === "ENETUNREACH") return "Network is unreachable (os error 101)";
  if (e?.code === "ECONNREFUSED") return "Connection refused (os error 111)";
  if (e?.code === "EHOSTUNREACH") return "No route to host (os error 113)";
  if (e?.message === "timed out" || e?.code === "ETIMEDOUT") return "Operation timed out (os error 110)";
  return e && e.message ? e.message : String(e);
}

main().catch((e: any) => { console.error(`Error [network]: ${formatError(e)}`); process.exit(1); });
