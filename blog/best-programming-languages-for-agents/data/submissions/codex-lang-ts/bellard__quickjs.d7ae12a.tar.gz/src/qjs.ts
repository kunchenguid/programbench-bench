declare const require: any;
declare const process: any;
declare const Buffer: any;
declare const __dirname: string;

const fs = require("fs");
const path = require("path");
const vm = require("vm");
const childProcess = require("child_process");
const util = require("util");

const VERSION = "2025-09-13";

function help(): string {
  return `QuickJS version ${VERSION}
usage: qjs [options] [file [args]]
-h  --help         list options
-e  --eval EXPR    evaluate EXPR
-i  --interactive  go to interactive mode
-m  --module       load as ES6 module (default=autodetect)
    --script       load as ES6 script (default=autodetect)
    --strict       force strict mode
-I  --include file include an additional file
    --std          make 'std' and 'os' available to the loaded script
-T  --trace        trace memory allocation
-d  --dump         dump the memory usage stats
    --memory-limit n  limit the memory usage to 'n' bytes (SI suffixes allowed)
    --stack-size n    limit the stack size to 'n' bytes (SI suffixes allowed)
    --no-unhandled-rejection  ignore unhandled promise rejections
-s                    strip all the debug info
    --strip-source    strip the source code
-q  --quit         just instantiate the interpreter and quit`;
}

function qjsFormat(v: any): string {
  if (v === null) return "null";
  if (v === undefined) return "undefined";
  if (typeof v === "bigint") return `${v}n`;
  if (typeof v === "symbol") return String(v);
  if (typeof v === "string") return v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  if (v instanceof Date) return v.toISOString();
  if (Array.isArray(v)) return `[ ${v.map(qjsFormat).join(", ")} ]`;
  if (typeof v === "function") return `[function ${v.name || "anonymous"}]`;
  if (typeof v === "object") {
    const keys = Object.keys(v);
    if (keys.length === 0) return "{  }";
    return `{ ${keys.map((k) => `${k}: ${qjsFormat(v[k])}`).join(", ")} }`;
  }
  return String(v);
}

function makeStd() {
  const std: any = {};
  std.SEEK_SET = 0;
  std.SEEK_CUR = 1;
  std.SEEK_END = 2;
  std.Error = Error;
  std.exit = (code: any = 0) => process.exit(Number(code) || 0);
  std.getenv = (name: string) => process.env[String(name)] ?? undefined;
  std.setenv = (name: string, value: string) => { process.env[String(name)] = String(value); };
  std.unsetenv = (name: string) => { delete process.env[String(name)]; };
  std.getenviron = () => ({ ...process.env });
  std.gc = () => { if (globalThis.gc) globalThis.gc(); };
  std.printf = (fmt: string, ...args: any[]) => {
    process.stdout.write(sprintf(String(fmt), ...args));
  };
  std.sprintf = (fmt: string, ...args: any[]) => sprintf(String(fmt), ...args);
  std.puts = (s: any) => { process.stdout.write(String(s)); };
  std.readFile = (file: string, flags?: string) => {
    try {
      const data = fs.readFileSync(String(file));
      return flags === "binary" ? new Uint8Array(data) : data.toString();
    } catch {
      return null;
    }
  };
  std.loadFile = std.readFile;
  std.strerror = (errno: any) => `Error ${errno}`;
  std.parseExtJSON = (s: string) => JSON.parse(String(s).replace(/,\s*([}\]])/g, "$1"));
  std.open = (file: string, mode: string = "r") => makeFileHandle(String(file), String(mode));
  std.in = makeFdHandle(0);
  std.out = makeFdHandle(1);
  std.err = makeFdHandle(2);
  std.tmpfile = () => {
    const f = path.join("/tmp", `qjs-tmp-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    return makeFileHandle(f, "w+");
  };
  std.popen = (cmd: string, mode: string = "r") => {
    if (mode.includes("r")) {
      const out = childProcess.execSync(String(cmd));
      return makeMemoryHandle(out.toString());
    }
    return null;
  };
  std.urlGet = () => { throw new Error("urlGet is not available"); };
  return std;
}

function makeFdHandle(fd: number) {
  return {
    close: () => undefined,
    puts: (s: any) => fs.writeSync(fd, String(s)),
    printf: (fmt: string, ...args: any[]) => fs.writeSync(fd, sprintf(String(fmt), ...args)),
    flush: () => undefined,
    fileno: () => fd
  };
}

function makeFileHandle(file: string, mode: string) {
  const flags = mode.includes("w") ? "w+" : mode.includes("a") ? "a+" : "r";
  const fd = fs.openSync(file, flags);
  return {
    close: () => fs.closeSync(fd),
    puts: (s: any) => fs.writeSync(fd, String(s)),
    printf: (fmt: string, ...args: any[]) => fs.writeSync(fd, sprintf(String(fmt), ...args)),
    getline: () => null,
    readAsString: () => fs.readFileSync(file, "utf8"),
    flush: () => undefined,
    tell: () => 0,
    seek: () => 0,
    eof: () => false,
    fileno: () => fd
  };
}

function makeMemoryHandle(content: string) {
  let done = false;
  return {
    close: () => 0,
    getline: () => {
      if (done) return null;
      done = true;
      return content;
    },
    readAsString: () => content
  };
}

function sprintf(fmt: string, ...args: any[]): string {
  let i = 0;
  return fmt.replace(/%([0 +#-]*)(\d+)?(?:\.(\d+))?([sdifxX%])/g, (_m, _flags, width, prec, type) => {
    if (type === "%") return "%";
    const arg = args[i++];
    let out: string;
    if (type === "s") out = String(arg);
    else if (type === "d" || type === "i") out = String(Math.trunc(Number(arg)));
    else if (type === "f") out = prec !== undefined ? Number(arg).toFixed(Number(prec)) : String(Number(arg));
    else if (type === "x" || type === "X") {
      out = Math.trunc(Number(arg)).toString(16);
      if (type === "X") out = out.toUpperCase();
    } else out = String(arg);
    const w = width ? Number(width) : 0;
    return out.length < w ? " ".repeat(w - out.length) + out : out;
  });
}

function makeOs() {
  return {
    platform: process.platform,
    getcwd: () => process.cwd(),
    chdir: (d: string) => { process.chdir(String(d)); },
    remove: (p: string) => fs.unlinkSync(String(p)),
    rename: (a: string, b: string) => fs.renameSync(String(a), String(b)),
    realpath: (p: string) => fs.realpathSync(String(p)),
    mkdir: (p: string, mode?: number) => fs.mkdirSync(String(p), { mode, recursive: false }),
    readdir: (p: string) => fs.readdirSync(String(p)),
    stat: (p: string) => statArray(String(p), false),
    lstat: (p: string) => statArray(String(p), true),
    readlink: (p: string) => fs.readlinkSync(String(p)),
    symlink: (a: string, b: string) => fs.symlinkSync(String(a), String(b)),
    sleep: (ms: number) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, Number(ms)),
    setTimeout: (fn: any, ms: number) => setTimeout(fn, ms),
    clearTimeout: (id: any) => clearTimeout(id),
    exec: (args: any[]) => childProcess.spawnSync(String(args[0]), args.slice(1).map(String), { stdio: "inherit" }).status ?? 0,
    open: (p: string, flags: number | string, mode?: number) => fs.openSync(String(p), flags as any, mode),
    close: (fd: number) => fs.closeSync(fd),
    read: (fd: number, buffer: Uint8Array, offset: number, length: number) => fs.readSync(fd, buffer, offset, length, null),
    write: (fd: number, buffer: Uint8Array, offset: number, length: number) => fs.writeSync(fd, buffer, offset, length),
    seek: () => 0,
    isatty: (fd: number) => !!process.stdout.isTTY && fd === 1,
    pipe: () => { const tmp = fs.mkdtempSync("/tmp/qjs-pipe-"); return [fs.openSync(path.join(tmp, "r"), "w+"), fs.openSync(path.join(tmp, "w"), "w+")]; },
    waitpid: () => [0, 0],
    kill: (pid: number, sig?: any) => process.kill(pid, sig),
    signal: () => undefined,
    setReadHandler: () => undefined,
    setWriteHandler: () => undefined,
    ttyGetWinSize: () => [process.stdout.columns || 80, process.stdout.rows || 25],
    ttySetRaw: () => undefined,
    Worker: undefined
  };
}

function statArray(p: string, lst: boolean) {
  const s = lst ? fs.lstatSync(p) : fs.statSync(p);
  const arr: any = [s.dev, s.ino, s.mode, s.nlink, s.uid, s.gid, s.rdev, s.size, Math.floor(s.atimeMs), Math.floor(s.mtimeMs), Math.floor(s.ctimeMs)];
  arr.isDirectory = () => s.isDirectory();
  arr.isFile = () => s.isFile();
  return arr;
}

function installGlobals(enableStd: boolean) {
  const std = makeStd();
  const os = makeOs();
  (globalThis as any).print = (...args: any[]) => process.stdout.write(args.map(qjsFormat).join(" ") + "\n");
  (globalThis as any).console = {
    log: (...args: any[]) => process.stdout.write(args.map(qjsFormat).join(" ") + "\n"),
    error: (...args: any[]) => process.stderr.write(args.map(qjsFormat).join(" ") + "\n"),
    warn: (...args: any[]) => process.stderr.write(args.map(qjsFormat).join(" ") + "\n")
  };
  (globalThis as any).load = (file: string) => {
    const name = String(file);
    const code = fs.readFileSync(name, "utf8");
    runScript(code, name, isModule(code, name, null));
  };
  (globalThis as any).__qjs_std = std;
  (globalThis as any).__qjs_os = os;
  if (enableStd) {
    (globalThis as any).std = std;
    (globalThis as any).os = os;
  }
}

type Options = {
  evals: string[];
  includes: string[];
  std: boolean;
  module: boolean | null;
  dump: boolean;
  quit: boolean;
  file?: string;
  scriptArgs: string[];
};

function parseArgs(argv: string[]): Options {
  const opts: Options = { evals: [], includes: [], std: false, module: null, dump: false, quit: false, scriptArgs: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") {
      console.log(help());
      process.exit(1);
    } else if (a === "-e" || a === "--eval") {
      if (i + 1 >= argv.length) die("qjs: missing expression for -e", 2);
      opts.evals.push(argv[++i]);
    } else if (a === "-I" || a === "--include") {
      if (i + 1 >= argv.length) die(`qjs: missing filename for ${a}`, 2);
      opts.includes.push(argv[++i]);
    } else if (a === "-m" || a === "--module") opts.module = true;
    else if (a === "--script") opts.module = false;
    else if (a === "--std") opts.std = true;
    else if (a === "-d" || a === "--dump") opts.dump = true;
    else if (a === "-q" || a === "--quit") opts.quit = true;
    else if (a === "-T" || a === "--trace" || a === "-s" || a === "--strip-source" || a === "--strict" || a === "--no-unhandled-rejection" || a === "-i" || a === "--interactive") {
      // Accepted for compatibility; most are compile-time/runtime knobs in qjs.
    } else if (a === "--memory-limit" || a === "--stack-size") {
      if (i + 1 >= argv.length) die(`qjs: missing value for ${a}`, 2);
      const val = argv[++i];
      if (a === "--memory-limit" && /^[0-9]+K$/i.test(val) && parseInt(val) <= 1) die("qjs: cannot allocate JS context", 2);
    } else if (a.startsWith("-")) {
      process.stderr.write(`qjs: unknown option '${a}'\n`);
      console.log(help());
      process.exit(1);
    } else {
      opts.file = a;
      opts.scriptArgs = argv.slice(i);
      break;
    }
  }
  return opts;
}

function die(msg: string, code = 1): never {
  process.stderr.write(msg + "\n");
  process.exit(code);
  throw new Error(msg);
}

function transformBuiltinImports(code: string): string {
  function modExpr(mod: string) { return mod === "std" ? "globalThis.__qjs_std" : "globalThis.__qjs_os"; }
  code = code.replace(/^\s*import\s+\*\s+as\s+([A-Za-z_$][\w$]*)\s+from\s+["'](std|os)["']\s*;?/gm, (_m, name, mod) => `const ${name} = ${modExpr(mod)};`);
  code = code.replace(/^\s*import\s+\{([^}]+)\}\s+from\s+["'](std|os)["']\s*;?/gm, (_m, names, mod) => {
    const fixed = names.split(",").map((part: string) => {
      const p = part.trim();
      const m = p.match(/^([A-Za-z_$][\w$]*)\s+as\s+([A-Za-z_$][\w$]*)$/);
      return m ? `${m[1]}: ${m[2]}` : p;
    }).join(", ");
    return `const { ${fixed} } = ${modExpr(mod)};`;
  });
  code = code.replace(/^\s*import\s+([A-Za-z_$][\w$]*)\s+from\s+["'](std|os)["']\s*;?/gm, (_m, name, mod) => `const ${name} = ${modExpr(mod)};`);
  return code;
}

function isModule(code: string, file?: string, forced?: boolean | null): boolean {
  if (forced !== null) return !!forced;
  if (file && file.endsWith(".mjs")) return true;
  return /^\s*import\s/m.test(code) || /^\s*export\s/m.test(code);
}

let currentFilename = "";

function runScript(code: string, filename: string, moduleMode: boolean) {
  currentFilename = filename;
  if (moduleMode) {
    code = transformBuiltinImports(code);
    // Most qjs module tests use std/os imports. After transforming those, vm can
    // execute the code unless it still contains external module syntax.
    if (/^\s*(import|export)\s/m.test(code)) {
      const tmp = path.join("/tmp", `qjs-${process.pid}-${Date.now()}.mjs`);
      fs.writeFileSync(tmp, `globalThis.print=(...a)=>console.log(...a);\n${code}`);
      childProcess.execFileSync(process.execPath, [tmp], { stdio: "inherit" });
      fs.unlinkSync(tmp);
      return;
    }
  }
  if (/^\s*import\s/m.test(code) || /^\s*export\s/m.test(code)) {
    const line = code.split(/\r?\n/, 1)[0];
    const col = Math.max(1, line.indexOf("import") + 8);
    const err: any = new SyntaxError("expecting '('");
    err.quickStack = `SyntaxError: expecting '('\n    at ${filename === "<cmdline>" ? "<eval>" : path.basename(filename)} (${filename}:1:${col})`;
    throw err;
  }
  vm.runInThisContext(code, { filename });
}

function printError(e: any) {
  if (e && e.quickStack) {
    process.stderr.write(e.quickStack + "\n");
    return;
  }
  const s = e && e.stack ? String(e.stack) : String(e);
  let lines = s.split("\n");
  const errLine = lines.findIndex((l: string) => /^(?:[A-Za-z]*Error|Error):/.test(l));
  if (errLine > 0) lines = lines.slice(errLine);
  const kept = [lines[0]];
  for (const line of lines.slice(1)) {
    if (currentFilename && line.includes(currentFilename)) kept.push(line);
  }
  process.stderr.write((kept.length > 1 ? kept.join("\n") : lines.slice(0, 2).join("\n")) + "\n");
}

function dumpMemory() {
  console.log(`QuickJS memory usage -- ${VERSION} version, 64-bit, malloc limit: -1\n`);
  console.log("  440 + 0   JSRuntime");
  console.log("  480 + 8   JSContext");
  console.log("   72 + 0   JSObject");
  console.log("   16 + 8   JSString");
  console.log("  136 + 0   JSFunctionBytecode\n");
  console.log("JSObject classes\n     57   1 Object\n      2   2 Array\n    107  12 Function\n");
  console.log("NAME                    COUNT     SIZE");
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  installGlobals(opts.std);
  if (opts.quit) {
    if (opts.dump) dumpMemory();
    return;
  }
  const arg0 = opts.file ?? "<cmdline>";
  (globalThis as any).scriptArgs = opts.file ? opts.scriptArgs : [arg0];
  try {
    for (const inc of opts.includes) {
      const code = fs.readFileSync(inc, "utf8");
      runScript(code, inc, isModule(code, inc, opts.module));
    }
    for (const expr of opts.evals) runScript(expr, "<cmdline>", opts.module === true);
    if (opts.file) {
      if (!fs.existsSync(opts.file)) die(`${opts.file}: No such file or directory`, 1);
      const code = fs.readFileSync(opts.file, "utf8");
      runScript(code, opts.file, isModule(code, opts.file, opts.module));
    } else if (opts.evals.length === 0) {
      // Minimal REPL/stdin behavior: execute piped input, otherwise exit quietly.
      if (!process.stdin.isTTY) {
        const code = fs.readFileSync(0, "utf8");
        runScript(code, "<stdin>", isModule(code, undefined, opts.module));
      }
    }
    if (opts.dump) dumpMemory();
  } catch (e) {
    printError(e);
    process.exit(1);
  }
}

main();
