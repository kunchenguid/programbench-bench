#!/usr/bin/env node

import * as fs from "fs";
import * as path from "path";

type Graph = Map<string, string[]>;
type Config = {
  exclude?: string[];
  only?: string[];
  unwrapExports?: boolean;
  check?: {
    entrypoints?: string[];
    allowCircularDependencies?: boolean;
    allow?: Record<string, any>;
    deny?: Record<string, any>;
    aliases?: Record<string, string[]>;
  };
};

const VERSION = "v0.23.4";
const SOURCE_EXTS = [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".py", ".go", ".rs"];
const JS_EXTS = [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".json"];

function main() {
  const argv = process.argv.slice(2);
  if (argv.includes("-h") || argv.includes("--help")) {
    printHelp(argv[0]);
    return;
  }
  if (argv.includes("-v") || argv.includes("--version")) {
    console.log(`dep-tree version ${VERSION}`);
    return;
  }

  const parsed = parseArgs(argv);
  const command = parsed.command;
  try {
    if (command === "config" || command === "init") return writeSampleConfig(parsed.configPath);
    if (command === "check") return cmdCheck(parsed);
    if (command === "explain") return cmdExplain(parsed);
    if (command === "tree") return cmdTree(parsed);
    if (command === "entropy" || command === "") return cmdEntropy(parsed);
    const maybe = command;
    if (maybe && fs.existsSync(maybe)) {
      parsed.positionals.unshift(maybe);
      return cmdEntropy(parsed);
    }
    fail(`${maybe} does not match with any existing file`);
  } catch (err: any) {
    fail(err?.message || String(err));
  }
}

function parseArgs(argv: string[]) {
  let command = "";
  const positionals: string[] = [];
  const flags: Record<string, any> = {};
  let configPath = ".dep-tree.yml";
  const only: string[] = [];
  const exclude: string[] = [];

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-c" || a === "--config") configPath = argv[++i] || configPath;
    else if (a === "--only") only.push(argv[++i] || "");
    else if (a === "--exclude") exclude.push(argv[++i] || "");
    else if (a === "--json") flags.json = true;
    else if (a === "-l" || a === "--overlap-left") flags.overlapLeft = true;
    else if (a === "-r" || a === "--overlap-right") flags.overlapRight = true;
    else if (a.startsWith("--")) flags[a.slice(2)] = true;
    else if (!command && ["entropy", "tree", "check", "explain", "config", "init", "help"].includes(a)) command = a;
    else positionals.push(a);
  }
  return { command, positionals, flags, configPath, only, exclude };
}

function printHelp(command?: string) {
  if (command === "tree") {
    console.log(`Render the dependency tree starting from the provided entrypoint

Usage:
  dep-tree tree [flags]

Flags:
  -h, --help   help for tree
      --json   render the dependency tree in a machine readable json format`);
    return printGlobal();
  }
  if (command === "check") {
    console.log(`Checks that the dependency rules defined in the configuration file are not broken

Usage:
  dep-tree check [flags]

Flags:
  -h, --help   help for check`);
    return printGlobal();
  }
  if (command === "explain") {
    console.log(`Shows all the dependencies between two parts of the code

Usage:
  dep-tree explain [flags]

Flags:
  -h, --help            help for explain
  -l, --overlap-left    When there's an overlap between the files at the left and the right, keep the ones at the left
  -r, --overlap-right   When there's an overlap between the files at the left and the right, keep the ones at the right`);
    return printGlobal();
  }
  if (command === "entropy") {
    console.log(`(default) Renders a 3d force-directed graph in the browser

Usage:
  dep-tree entropy [flags]

Flags:
      --enable-gui           Enables a GUI for changing rendering settings
  -h, --help                 help for entropy
      --no-browser-open      Disable the automatic browser open while rendering entropy
      --render-path string   Sets the output path of the rendered html file`);
    return printGlobal();
  }
  if (command === "config" || command === "init") {
    console.log(`Generates a sample config in case that there's not already one present

Usage:
  dep-tree config [flags]

Aliases:
  config, init

Flags:
  -h, --help   help for config`);
    return printGlobal();
  }
  console.log(`
      ____         _ __       _
     |  _ \\   ___ |  _ \\    _| |_  _ __  ___   ___
     | | | | / _ \\| |_) |  |_   _||  __|/ _ \\ / _ \\
     | |_| ||  __/| .__/     | |  | |  |  __/|  __/
     |____/  \\__| |_|        | \\__|_|   \\___| \\___|

Usage:
  dep-tree [command]

Visualize your dependencies graphically
  entropy     (default) Renders a 3d force-directed graph in the browser
  tree        Render the dependency tree starting from the provided entrypoint

Check your dependencies against your own rules
  check       Checks that the dependency rules defined in the configuration file are not broken

Display what are the dependencies between two portions of code
  explain     Shows all the dependencies between two parts of the code

Additional Commands:
  config      Generates a sample config in case that there's not already one present
  help        Help about any command

Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
  -h, --help                                 help for dep-tree
  -v, --version                              version for dep-tree`);
}

function printGlobal() {
  console.log(`
Global Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)`);
}

function cmdTree(parsed: ReturnType<typeof parseArgs>) {
  const entries = parsed.positionals;
  if (!entries.length) throw new Error("requires at least 1 arg(s), only received 0");
  const cfg = loadConfig(parsed.configPath);
  const graph = buildGraph(entries, cfg, parsed);
  const circularDependencies = findCycles(graph);
  const tree: any = {};
  for (const e of entries) tree[norm(e)] = buildTree(norm(e), graph, new Set());
  if (parsed.flags.json) console.log(JSON.stringify({ tree, circularDependencies, errors: {} }, null, 2));
  else printTree(tree);
}

function cmdExplain(parsed: ReturnType<typeof parseArgs>) {
  if (parsed.positionals.length < 2) throw new Error("requires 2 arg(s), only received " + parsed.positionals.length);
  const [leftPat, rightPat] = parsed.positionals;
  let left = expandGlob(leftPat), right = expandGlob(rightPat);
  const overlap = new Set(left.filter(x => right.includes(x)));
  if (parsed.flags.overlapLeft) right = right.filter(x => !overlap.has(x));
  if (parsed.flags.overlapRight) left = left.filter(x => !overlap.has(x));
  const graph = buildGraph([...left, ...right], loadConfig(parsed.configPath), parsed, true);
  const rightSet = new Set(right);
  for (const l of left) for (const d of graph.get(l) || []) if (rightSet.has(d)) console.log(`${l} -> ${d}`);
}

function cmdCheck(parsed: ReturnType<typeof parseArgs>) {
  const cfg = loadConfig(parsed.configPath);
  const entries = cfg.check?.entrypoints || parsed.positionals;
  if (!entries.length) throw new Error("no entrypoints found for check");
  const graph = buildGraph(entries, cfg, parsed);
  const violations: { from: string; to: string; reason?: string }[] = [];
  const aliases = cfg.check?.aliases || {};
  for (const [from, deps] of graph) {
    for (const to of deps) {
      const denyReason = denied(from, to, cfg, aliases);
      if (denyReason !== undefined) violations.push({ from, to, reason: denyReason });
      const allowReason = allowedViolation(from, to, cfg, aliases);
      if (allowReason !== undefined) violations.push({ from, to, reason: allowReason });
    }
  }
  if (!cfg.check?.allowCircularDependencies) {
    for (const cyc of findCycles(graph)) violations.push({ from: cyc[0], to: cyc[1], reason: `Circular dependency: ${cyc.join(" -> ")}` });
  }
  if (violations.length) {
    console.error("Error: Check failed, the following dependencies are not allowed:");
    for (const v of violations) {
      console.error(`- ${v.from} -> ${v.to}`);
      if (v.reason) console.error(`  ${v.reason}`);
    }
    process.exit(1);
  }
}

function cmdEntropy(parsed: ReturnType<typeof parseArgs>) {
  const outIdx = process.argv.indexOf("--render-path");
  const out = outIdx >= 0 ? process.argv[outIdx + 1] : "";
  if (out) fs.writeFileSync(out, "<!doctype html><title>Dep Tree</title><div id=\"root\"></div>\n");
  else console.log("Rendering dependency graph...");
}

function writeSampleConfig(configPath: string) {
  if (fs.existsSync(configPath)) throw new Error(`${configPath} already exists`);
  fs.writeFileSync(configPath, "check:\n  entrypoints:\n    - src/index.ts\n  allowCircularDependencies: false\n");
}

function buildGraph(entries: string[], cfg: Config, parsed: ReturnType<typeof parseArgs>, includeAll = false): Graph {
  const graph: Graph = new Map();
  const seen = new Set<string>();
  const only = [...(cfg.only || []), ...parsed.only].filter(Boolean);
  const exclude = [...(cfg.exclude || []), ...parsed.exclude].filter(Boolean);
  const visit = (file: string) => {
    file = norm(file);
    if (seen.has(file)) return;
    seen.add(file);
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) return;
    if (exclude.some(p => matchGlob(file, p))) return;
    if (only.length && !only.some(p => matchGlob(file, p))) return;
    const deps = parseDeps(file).filter(d => fs.existsSync(d));
    graph.set(file, unique(deps));
    for (const d of deps) visit(d);
  };
  for (const e of entries) visit(e);
  if (includeAll) for (const f of allSourceFiles()) if (!seen.has(f)) visit(f);
  return graph;
}

function parseDeps(file: string): string[] {
  const ext = path.extname(file);
  const text = fs.readFileSync(file, "utf8");
  if ([".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"].includes(ext)) return parseJs(file, text);
  if (ext === ".py") return parsePy(file, text);
  if (ext === ".go") return parseGo(file, text);
  if (ext === ".rs") return parseRust(file, text);
  return [];
}

function parseJs(file: string, text: string): string[] {
  const deps: string[] = [];
  const re = /\b(?:import|export)\s+(?:[^'"]*?\s+from\s+)?["']([^"']+)["']|require\s*\(\s*["']([^"']+)["']\s*\)|import\s*\(\s*["']([^"']+)["']\s*\)/g;
  for (const m of text.matchAll(re)) {
    const spec = m[1] || m[2] || m[3];
    if (spec?.startsWith(".")) {
      const r = resolveJs(path.dirname(file), spec);
      if (r) deps.push(r);
    }
  }
  return deps;
}

function resolveJs(base: string, spec: string): string | null {
  const p = norm(path.join(base, spec));
  for (const e of ["", ...JS_EXTS]) if (fs.existsSync(p + e) && fs.statSync(p + e).isFile()) return norm(p + e);
  for (const e of JS_EXTS) if (fs.existsSync(path.join(p, "index" + e))) return norm(path.join(p, "index" + e));
  return null;
}

function parsePy(file: string, text: string): string[] {
  const deps: string[] = [];
  const dir = path.dirname(file);
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.replace(/#.*/, "");
    let m = line.match(/^\s*from\s+([.\w]+)\s+import\s+(.+)/);
    if (m) {
      const mod = m[1], names = m[2].split(",").map(s => s.trim().split(/\s+/)[0]);
      if (mod.startsWith(".")) {
        const base = pyRelBase(file, mod);
        for (const n of names) {
          const r = resolvePyPath(path.join(base, n));
          if (r) deps.push(r);
        }
        const direct = resolvePyPath(base);
        if (direct) deps.push(direct);
      } else {
        const direct = resolvePyModule(mod);
        if (direct) deps.push(direct);
        for (const n of names) {
          const r = resolvePyModule(mod + "." + n);
          if (r) deps.push(r);
        }
      }
      continue;
    }
    m = line.match(/^\s*import\s+(.+)/);
    if (m) for (const part of m[1].split(",")) {
      const mod = part.trim().split(/\s+as\s+/)[0];
      const r = resolvePyModule(mod);
      if (r) deps.push(r);
    }
  }
  return deps.filter(d => norm(d) !== norm(file));
}

function pyRelBase(file: string, mod: string): string {
  const dots = mod.match(/^\.+/)?.[0].length || 0;
  let base = path.dirname(file);
  for (let i = 1; i < dots; i++) base = path.dirname(base);
  const rest = mod.slice(dots).replace(/\./g, "/");
  return norm(path.join(base, rest));
}

function resolvePyModule(mod: string): string | null {
  return resolvePyPath(mod.replace(/\./g, "/"));
}

function resolvePyPath(p: string): string | null {
  p = norm(p);
  if (fs.existsSync(p + ".py")) return p + ".py";
  if (fs.existsSync(path.join(p, "__init__.py"))) return norm(path.join(p, "__init__.py"));
  return null;
}

function parseGo(file: string, text: string): string[] {
  const deps: string[] = [];
  const module = readGoModule();
  const re = /import\s+(?:\(([\s\S]*?)\)|"([^"]+)")/g;
  for (const m of text.matchAll(re)) {
    const specs = m[2] ? [m[2]] : [...m[1].matchAll(/"([^"]+)"/g)].map(x => x[1]);
    for (const s of specs) {
      let rel = s;
      if (module && s.startsWith(module + "/")) rel = s.slice(module.length + 1);
      if (rel.startsWith("./") || rel.startsWith("../") || rel !== s) {
        const r = resolveGoPackage(rel.startsWith(".") ? path.join(path.dirname(file), rel) : rel);
        deps.push(...r);
      }
    }
  }
  return deps;
}

function readGoModule(): string {
  if (!fs.existsSync("go.mod")) return "";
  const m = fs.readFileSync("go.mod", "utf8").match(/^module\s+(\S+)/m);
  return m?.[1] || "";
}

function resolveGoPackage(dir: string): string[] {
  dir = norm(dir);
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) return [];
  return fs.readdirSync(dir).filter(f => f.endsWith(".go") && !f.endsWith("_test.go")).map(f => norm(path.join(dir, f)));
}

function parseRust(file: string, text: string): string[] {
  const deps: string[] = [];
  for (const m of text.matchAll(/^\s*(?:pub\s+)?mod\s+([A-Za-z_]\w*)\s*;/gm)) {
    const name = m[1];
    for (const p of [path.join(path.dirname(file), name + ".rs"), path.join(path.dirname(file), name, "mod.rs")]) {
      if (fs.existsSync(p)) deps.push(norm(p));
    }
  }
  for (const m of text.matchAll(/\buse\s+crate::([A-Za-z_]\w*)/g)) {
    for (const p of [path.join("src", m[1] + ".rs"), path.join("src", m[1], "mod.rs")]) if (fs.existsSync(p)) deps.push(norm(p));
  }
  return deps;
}

function buildTree(file: string, graph: Graph, stack: Set<string>): any {
  if (stack.has(file)) return null;
  const deps = graph.get(file) || [];
  if (!deps.length) return null;
  const next = new Set(stack);
  next.add(file);
  const obj: any = {};
  for (const d of deps) {
    if (next.has(d)) continue;
    obj[d] = buildTree(d, graph, next);
  }
  if (!Object.keys(obj).length) return null;
  return obj;
}

function findCycles(graph: Graph): string[][] {
  const cycles: string[][] = [];
  const keys = new Set<string>();
  const dfs = (node: string, stack: string[]) => {
    const idx = stack.indexOf(node);
    if (idx >= 0) {
      const cyc = [...stack.slice(idx), node];
      const body = cyc.slice(0, -1);
      const rotations = body.map((_, i) => [...body.slice(i), ...body.slice(0, i)].join("\0"));
      const key = rotations.sort()[0];
      if (!keys.has(key)) {
        keys.add(key);
        cycles.push(cyc);
      }
      return;
    }
    for (const d of graph.get(node) || []) dfs(d, [...stack, node]);
  };
  for (const n of graph.keys()) dfs(n, []);
  return cycles;
}

function denied(from: string, to: string, cfg: Config, aliases: Record<string, string[]>): string | undefined {
  for (const [pat, raw] of Object.entries(cfg.check?.deny || {})) {
    if (!matchGlob(from, pat)) continue;
    for (const rule of Array.isArray(raw) ? raw : []) {
      const target = typeof rule === "string" ? rule : rule.to;
      for (const p of expandAlias(target, aliases)) if (matchGlob(to, p)) return typeof rule === "string" ? "" : rule.reason || "";
    }
  }
  return undefined;
}

function allowedViolation(from: string, to: string, cfg: Config, aliases: Record<string, string[]>): string | undefined {
  for (const [pat, raw] of Object.entries(cfg.check?.allow || {})) {
    if (!matchGlob(from, pat)) continue;
    const targets = Array.isArray(raw) ? raw : raw.to || [];
    const ok = targets.flatMap((t: string) => expandAlias(t, aliases)).some((p: string) => matchGlob(to, p));
    if (!ok) return Array.isArray(raw) ? "" : raw.reason || "";
  }
  return undefined;
}

function expandAlias(p: string, aliases: Record<string, string[]>): string[] {
  return aliases[p] || [p];
}

function loadConfig(configPath: string): Config {
  if (!fs.existsSync(configPath)) return {};
  return parseYaml(fs.readFileSync(configPath, "utf8"));
}

function parseYaml(text: string): any {
  const root: any = {};
  const stack: { indent: number; value: any; key?: string }[] = [{ indent: -1, value: root }];
  const lines = text.split(/\r?\n/).filter(l => l.trim() && !l.trim().startsWith("#"));
  for (const line of lines) {
    const indent = line.match(/^\s*/)?.[0].length || 0;
    const trimmed = line.trim();
    while (stack.length > 1 && indent <= stack[stack.length - 1].indent) stack.pop();
    const parent = stack[stack.length - 1].value;
    if (trimmed.startsWith("- ")) {
      if (!Array.isArray(parent)) continue;
      const item = trimmed.slice(2);
      if (item.includes(": ")) {
        const [k, v] = splitKeyVal(item);
        const obj: any = {};
        obj[unquote(k)] = scalar(v);
        parent.push(obj);
        stack.push({ indent, value: obj });
      } else parent.push(scalar(item));
      continue;
    }
    const [k0, v0] = splitKeyVal(trimmed);
    const k = unquote(k0);
    if (v0 === "") {
      const container: any = nextIsArray(lines, line) ? [] : {};
      parent[k] = container;
      stack.push({ indent, value: container, key: k });
    } else parent[k] = scalar(v0);
  }
  return root;
}

function nextIsArray(lines: string[], cur: string): boolean {
  const idx = lines.indexOf(cur);
  const curIndent = cur.match(/^\s*/)?.[0].length || 0;
  for (let i = idx + 1; i < lines.length; i++) {
    const ind = lines[i].match(/^\s*/)?.[0].length || 0;
    if (ind > curIndent) return lines[i].trim().startsWith("- ");
  }
  return false;
}

function splitKeyVal(s: string): [string, string] {
  const idx = s.indexOf(":");
  if (idx < 0) return [s, ""];
  return [s.slice(0, idx).trim(), s.slice(idx + 1).trim()];
}

function scalar(v: string): any {
  v = unquote(v);
  if (v === "true") return true;
  if (v === "false") return false;
  if (v === "null") return null;
  if (v.startsWith("[") && v.endsWith("]")) return v.slice(1, -1).split(",").map(x => scalar(x.trim())).filter(Boolean);
  return v;
}

function unquote(s: string): string {
  return s.replace(/^['"]|['"]$/g, "");
}

function expandGlob(pattern: string): string[] {
  return allSourceFiles().filter(f => matchGlob(f, pattern)).sort();
}

function allSourceFiles(): string[] {
  const out: string[] = [];
  const walk = (dir: string) => {
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      if ([".git", "node_modules", "dist"].includes(ent.name)) continue;
      const p = norm(path.join(dir, ent.name));
      if (ent.isDirectory()) walk(p);
      else if (SOURCE_EXTS.includes(path.extname(p))) out.push(p);
    }
  };
  walk(".");
  return out.sort();
}

function matchGlob(file: string, pattern: string): boolean {
  file = norm(file);
  pattern = norm(pattern);
  let re = "^";
  for (let i = 0; i < pattern.length; i++) {
    const ch = pattern[i];
    if (ch === "*") {
      if (pattern[i + 1] === "*") {
        if (pattern[i + 2] === "/") {
          re += "(?:.*/)?";
          i += 2;
        } else {
          re += ".*";
          i++;
        }
      } else re += "[^/]*";
    } else if (ch === "?") re += ".";
    else re += ch.replace(/[.+^${}()|[\]\\]/g, "\\$&");
  }
  re += "$";
  return new RegExp(re).test(file);
}

function unique<T>(xs: T[]): T[] {
  return [...new Set(xs.map(x => x as any))] as T[];
}

function norm(p: string): string {
  return path.normalize(p).replace(/\\/g, "/").replace(/^\.\//, "");
}

function printTree(tree: any, indent = "") {
  for (const [k, v] of Object.entries(tree)) {
    console.log(indent + k);
    if (v) printTree(v, indent + "  ");
  }
}

function fail(msg: string): void {
  console.error(`Error: ${msg}`);
  process.exit(1);
}

main();
