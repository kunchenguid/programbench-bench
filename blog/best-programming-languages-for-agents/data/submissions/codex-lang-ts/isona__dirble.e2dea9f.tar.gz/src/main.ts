import * as fs from "fs";
import * as path from "path";
import * as http from "http";
import * as https from "https";
import { URL } from "url";

type Result = {
  url: string;
  code: number;
  size: number;
  is_directory: boolean;
  is_listable: boolean;
  redirect_url: string;
  found_from_listable: boolean;
};

type Opts = {
  uris: string[];
  uriFile?: string;
  verb: string;
  wordlist?: string;
  prefixes: string[];
  prefixFile?: string;
  extensions: string[];
  extensionFile?: string;
  extSub: boolean;
  forceExtension: boolean;
  timeout: number;
  maxErrors: number;
  jsonFile?: string;
  outputFile?: string;
  xmlFile?: string;
  outputAll?: string;
  noColor: boolean;
  maxThreads: number;
  wordlistSplit: number;
  throttle: number;
  username?: string;
  password?: string;
  scanListable: boolean;
  maxRecursionDepth: number;
  disableRecursion: boolean;
  scrapeListable: boolean;
  userAgent?: string;
  cookies: string[];
  headers: string[];
  silent: boolean;
  verbose: number;
  blacklist: number[];
  whitelist?: number[];
  disableValidator: boolean;
  showHtaccess: boolean;
  ignoreCert: boolean;
  proxy?: string;
  noProxy: boolean;
  scan401: boolean;
  scan403: boolean;
  hideLengths: Array<[number, number]>;
};

const HELP = `Fast directory scanning and scraping tool

Usage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>

Arguments:
  [uri]
          The URI of the host to scan, optionally supports basic auth with
          http://user:pass@host:port

Options:
  -u, --uri <uri>
          Additional hosts to scan [aliases: url]
  -U, --uri-file <uri-file>
          The filename of a file containing a list of URIs to scan - cookies and
          headers set will be applied to all URIs [aliases: url-file]
      --verb <http_verb>
          Specify which HTTP verb to use
           [default: get] [possible values: get, head, post]
  -w, --wordlist <wordlist>
          Sets which wordlist to use, defaults to dirble_wordlist.txt in the same
          folder as the executable
  -p, --prefixes <prefixes>...
          Provides comma separated prefixes to extend queries with
  -P, --prefix-file <prefix-file>
          The name of a file containing extensions to extend queries with, one
          per line
  -x, --extensions <extensions>...
          Provides comma separated extensions to extend queries with
  -X, --extension-file <extension-file>
          The name of a file containing extensions to extend queries with, one
          per line
      --ext-sub
          Indicates whether the string "%EXT%" in a wordlist file should be 
          substituted with the current extension
  -f, --force-extension
          Only scan with provided extensions
  -k, --ignore-cert
          Ignore the certificate validity for HTTPS
      --show-htaccess
          Enable display of items containing .ht when they return 403 responses
      --timeout <timeout>
          Maximum time to wait for a response before giving up, given in seconds
           [default: 5]
      --max-errors <max_errors>
          The number of consecutive errors a thread can have before it exits,
          set to 0 to disable [default: 5]
      --json-file <json_file>
          Sets a file to write JSON output to [aliases: oJ]
      --no-color
          Disable coloring of terminal output
  -o, --output-file <output_file>
          Sets the file to write the report to [aliases: oN]
      --xml-file <xml_file>
          Sets a file to write XML output to [aliases: oX]
      --hide-lengths <length_blacklist>...
          Specify length ranges to hide, e.g. --hide-lengths 348,500-700
      --output-all <output_all>
          Stores all output types respectively as .txt, .json and .xml [aliases: oA]
      --burp
          Sets the proxy to use the default burp proxy values
          (http://localhost:8080)
      --no-proxy
          Disables proxy use even if there is a system proxy
      --proxy <proxy>
          The proxy address to use, including type and port, can also include a
          username and password in the form 
          "http://username:password@proxy_url:proxy_port"
  -t, --max-threads <max-threads>
          Sets the maximum number of request threads that will be spawned [default: 10]
  -T, --wordlist-split <wordlist_split>
          The number of threads to run for each folder/extension combo [default: 3]
  -z, --throttle <milliseconds>
          Time each thread will wait between requests, given in milliseconds
      --username <username>
          Sets the username to authenticate with
      --password <password>
          Sets the password to authenticate with
  -l, --scan-listable
          Scan listable directories
      --max-recursion-depth <max_recursion_depth>
          Sets the maximum directory depth to recurse to, 0 will disable
          recursion
  -r, --disable-recursion
          Disable discovered subdirectory scanning
      --scrape-listable
          Enable scraping of listable directories for urls, often produces large
          amounts of output
  -a, --user-agent <user_agent>
          Set the user-agent provided with requests, by default it isn't set
  -c, --cookie <cookie>
          Provide a cookie in the form "name=value", can be used multiple times
  -H, --header <header>
          Provide an arbitrary header in the form "header:value" - headers with
          no value must end in a semicolon
  -S, --silent
          Don't output information during the scan, only output the report at
          the end.
  -v, --verbose...
          Increase the verbosity level. Use twice for full verbosity.
  -B, --code-blacklist <code_blacklist>...
          Provide a comma separated list of response codes to not show in output
      --disable-validator
          Disable automatic detection of not found codes
  -W, --code-whitelist <code_whitelist>...
          Provide a comma separated list of response codes to show in output,
          also disables detection of not found codes
      --scan-401
          Scan folders even if they return 401 - Unauthorized frequently
      --scan-403
          Scan folders if they return 403 - Forbidden frequently
  -h, --help
          Print help
  -V, --version
          Print version

OUTPUT FORMAT:
    + [url] - File
    D [url] - Directory
    L [url] - Listable Directory

EXAMPLE USE:
    - Run against a website using the default dirble_wordlist.txt from the
      current directory:
        dirble [address]

    - Run with a different wordlist and including .php and .html extensions:
        dirble [address] -w example_wordlist.txt -x .php,.html

    - With listable directory scraping enabled:
        dirble [address] --scrape-listable

    - Providing a list of extensions and a list of URIs:
        dirble [address] -X wordlists/web.lst -U uri-list.txt

    - Providing multiple hosts to scan via command line:
        dirble [address] -u [address] -u [address]`;

function defaultOpts(): Opts {
  return {
    uris: [], verb: "get", prefixes: [], extensions: [], extSub: false,
    forceExtension: false, timeout: 5, maxErrors: 5, noColor: false,
    maxThreads: 10, wordlistSplit: 3, throttle: 0, scanListable: false,
    maxRecursionDepth: 10, disableRecursion: false, scrapeListable: false,
    cookies: [], headers: [], silent: false, verbose: 0, blacklist: [],
    disableValidator: false, showHtaccess: false, ignoreCert: false,
    noProxy: false, scan401: false, scan403: false, hideLengths: []
  };
}

function die(msg: string): never {
  console.error(msg);
  process.exit(2);
  throw new Error(msg);
}

function parseList(v: string): string[] {
  return v.split(",").map(s => s.trim()).filter(Boolean);
}

function need(args: string[], i: number, name: string): string {
  if (i + 1 >= args.length) die(`error: a value is required for '${name}' but none was supplied`);
  return args[i + 1];
}

function parseArgs(args: string[]): Opts {
  const o = defaultOpts();
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") { console.log(HELP); process.exit(0); }
    if (a === "-V" || a === "--version") { console.log("Dirble 1.4.2 (commit d520c82, build 2026-04-17)"); process.exit(0); }
    if (a === "-u" || a === "--uri" || a === "--url") o.uris.push(need(args, i++, a));
    else if (a === "-U" || a === "--uri-file" || a === "--url-file") o.uriFile = need(args, i++, a);
    else if (a === "--verb") {
      o.verb = need(args, i++, a).toLowerCase();
      if (!["get", "head", "post"].includes(o.verb)) die(`error: invalid value '${o.verb}' for '--verb <http_verb>'\n  [possible values: get, head, post]\n\nFor more information, try '--help'.`);
    } else if (a === "-w" || a === "--wordlist") o.wordlist = need(args, i++, a);
    else if (a === "-p" || a === "--prefixes") o.prefixes.push(...parseList(need(args, i++, a)));
    else if (a === "-P" || a === "--prefix-file") o.prefixFile = need(args, i++, a);
    else if (a === "-x" || a === "--extensions") o.extensions.push(...parseList(need(args, i++, a)));
    else if (a === "-X" || a === "--extension-file") o.extensionFile = need(args, i++, a);
    else if (a === "--ext-sub") o.extSub = true;
    else if (a === "-f" || a === "--force-extension") o.forceExtension = true;
    else if (a === "-k" || a === "--ignore-cert") o.ignoreCert = true;
    else if (a === "--show-htaccess") o.showHtaccess = true;
    else if (a === "--timeout") o.timeout = Number(need(args, i++, a));
    else if (a === "--max-errors") o.maxErrors = Number(need(args, i++, a));
    else if (a === "--json-file" || a === "--oJ") o.jsonFile = need(args, i++, a);
    else if (a === "--no-color") o.noColor = true;
    else if (a === "-o" || a === "--output-file" || a === "--oN") o.outputFile = need(args, i++, a);
    else if (a === "--xml-file" || a === "--oX") o.xmlFile = need(args, i++, a);
    else if (a === "--output-all" || a === "--oA") o.outputAll = need(args, i++, a);
    else if (a === "--hide-lengths") o.hideLengths.push(...parseLengths(need(args, i++, a)));
    else if (a === "--burp") o.proxy = "http://localhost:8080";
    else if (a === "--no-proxy") o.noProxy = true;
    else if (a === "--proxy") o.proxy = need(args, i++, a);
    else if (a === "-t" || a === "--max-threads") o.maxThreads = Number(need(args, i++, a));
    else if (a === "-T" || a === "--wordlist-split") o.wordlistSplit = Number(need(args, i++, a));
    else if (a === "-z" || a === "--throttle") o.throttle = Number(need(args, i++, a));
    else if (a === "--username") o.username = need(args, i++, a);
    else if (a === "--password") o.password = need(args, i++, a);
    else if (a === "-l" || a === "--scan-listable") o.scanListable = true;
    else if (a === "--max-recursion-depth") o.maxRecursionDepth = Number(need(args, i++, a));
    else if (a === "-r" || a === "--disable-recursion") o.disableRecursion = true;
    else if (a === "--scrape-listable") o.scrapeListable = true;
    else if (a === "-a" || a === "--user-agent") o.userAgent = need(args, i++, a);
    else if (a === "-c" || a === "--cookie") o.cookies.push(need(args, i++, a));
    else if (a === "-H" || a === "--header") o.headers.push(need(args, i++, a));
    else if (a === "-S" || a === "--silent") o.silent = true;
    else if (a === "-v" || a === "--verbose") o.verbose++;
    else if (/^-v+$/.test(a)) o.verbose += a.length - 1;
    else if (a === "-B" || a === "--code-blacklist") o.blacklist.push(...parseList(need(args, i++, a)).map(Number));
    else if (a === "--disable-validator") o.disableValidator = true;
    else if (a === "-W" || a === "--code-whitelist") { o.whitelist = (o.whitelist || []).concat(parseList(need(args, i++, a)).map(Number)); o.disableValidator = true; }
    else if (a === "--scan-401") o.scan401 = true;
    else if (a === "--scan-403") o.scan403 = true;
    else if (a.startsWith("-")) die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>\n\nFor more information, try '--help'.`);
    else o.uris.push(a);
  }
  if (o.uriFile) o.uris.push(...readLines(o.uriFile));
  if (o.uris.length === 0) { console.log(HELP); process.exit(2); }
  return o;
}

function parseLengths(s: string): Array<[number, number]> {
  return parseList(s).map(x => {
    const m = x.match(/^(\d+)-(\d+)$/);
    if (m) return [Number(m[1]), Number(m[2])];
    const n = Number(x);
    return [n, n];
  });
}

function readLines(file: string): string[] {
  return fs.readFileSync(file, "utf8").split(/\r?\n/).map(x => x.trim()).filter(x => x && !x.startsWith("#"));
}

function normalizeBase(uri: string): string {
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(uri)) uri = "http://" + uri;
  const u = new URL(uri);
  if (!u.pathname.endsWith("/")) u.pathname += "/";
  u.hash = "";
  return u.toString();
}

function buildWords(o: Opts): string[] {
  const wl = o.wordlist || path.join(path.dirname(process.argv[1] || "."), "dirble_wordlist.txt");
  const raw = readLines(wl).sort();
  if (o.prefixFile) o.prefixes.push(...readLines(o.prefixFile));
  if (o.extensionFile) o.extensions.push(...readLines(o.extensionFile).flatMap(parseList));
  const exts = o.extensions.map(e => e.startsWith(".") ? e : "." + e);
  const bases = raw.flatMap(word => o.prefixes.length ? o.prefixes.map(p => p + word) : [word]).sort();
  const out: string[] = [];
  if (!o.forceExtension && !o.extSub) out.push(...bases);
  for (const e of exts) for (const b of bases) out.push(o.extSub ? b.replace(/%EXT%/g, e.replace(/^\./, "")) : b + e);
  return [...new Set(out)];
}

function headersFor(o: Opts, url: URL): any {
  const h: any = {};
  if (o.userAgent) h["User-Agent"] = o.userAgent;
  if (o.cookies.length) h["Cookie"] = o.cookies.join("; ");
  for (const raw of o.headers) {
    const semi = raw.endsWith(";");
    const idx = raw.indexOf(":");
    if (idx >= 0) h[raw.slice(0, idx).trim()] = raw.slice(idx + 1).trim();
    else if (semi) h[raw.slice(0, -1).trim()] = "";
  }
  const user = o.username || decodeURIComponent(url.username || "");
  const pass = o.password || decodeURIComponent(url.password || "");
  if (user || pass) h["Authorization"] = "Basic " + Buffer.from(`${user}:${pass}`).toString("base64");
  return h;
}

function requestUrl(urlString: string, o: Opts): Promise<Result | null> {
  return new Promise(resolve => {
    const u = new URL(urlString);
    const lib = u.protocol === "https:" ? https : http;
    const opts: any = {
      method: o.verb.toUpperCase(),
      headers: headersFor(o, u),
      timeout: Math.max(1, o.timeout) * 1000,
      rejectUnauthorized: !o.ignoreCert
    };
    const req = lib.request(u, opts, (res: any) => {
      const chunks: any[] = [];
      res.on("data", (c: any) => chunks.push(c));
      res.on("end", () => {
        const body = Buffer.concat(chunks);
        const loc = res.headers.location || "";
        const isDir = String(loc).endsWith("/") || urlString.endsWith("/");
        const text = body.toString("utf8");
        const listable = /Index of|Directory Listing|<title>\s*Index/i.test(text);
        resolve({ url: urlString, code: res.statusCode || 0, size: Number(res.headers["content-length"] || body.length || 0), is_directory: isDir, is_listable: listable, redirect_url: String(loc || ""), found_from_listable: false });
      });
    });
    req.on("timeout", () => { req.destroy(new Error("timeout")); });
    req.on("error", (e: any) => {
      if (o.verbose) console.error(`Curl error after requesting ${urlString} : [7] Could not connect to server (${e.message})`);
      resolve(null);
    });
    req.end();
  });
}

function visible(r: Result, o: Opts, notFound: Set<number>): boolean {
  if (o.whitelist && !o.whitelist.includes(r.code)) return false;
  if (o.blacklist.includes(r.code)) return false;
  if (!o.disableValidator && notFound.has(r.code)) return false;
  if (!o.showHtaccess && r.code === 403 && r.url.includes(".ht")) return false;
  if (o.hideLengths.some(([a,b]) => r.size >= a && r.size <= b)) return false;
  return true;
}

function line(r: Result): string {
  const mark = r.is_listable ? "L" : r.is_directory ? "D" : "+";
  const redir = r.redirect_url ? `|REDIRECT:${r.redirect_url}` : "";
  return `${mark} ${r.url} (CODE:${r.code}|SIZE:${r.size}${redir})`;
}

async function detectNotFound(base: string, o: Opts): Promise<Set<number>> {
  const s = new Set<number>();
  if (o.disableValidator || o.whitelist) return s;
  const probe = base + "dirble-not-found-" + Math.random().toString(36).slice(2, 12);
  const r = await requestUrl(probe, { ...o, verbose: 0 });
  if (r) {
    s.add(r.code);
    if (!o.silent) console.log(`[INFO] Detected nonexistent paths for ${base} are (CODE:${r.code})`);
  }
  return s;
}

async function scanBase(base: string, words: string[], o: Opts): Promise<Result[]> {
  const results: Result[] = [];
  const notFound = await detectNotFound(base, o);
  const queue: Array<{base: string, depth: number}> = [{ base, depth: 0 }];
  const seenBases = new Set<string>([base]);
  while (queue.length) {
    const cur = queue.shift()!;
    for (const w of words) {
      const url = cur.base + w.replace(/^\/+/, "");
      const r = await requestUrl(url, o);
      if (o.throttle) await new Promise(res => setTimeout(res, o.throttle));
      if (!r) continue;
      results.push(r);
      if (visible(r, o, notFound) && !o.silent) console.log(line(r));
      if (!o.disableRecursion && o.maxRecursionDepth !== 0 && cur.depth < o.maxRecursionDepth && (r.is_directory || r.url.endsWith("/")) && [200,301,302,307,308,401,403].includes(r.code)) {
        if ((r.code === 401 && !o.scan401) || (r.code === 403 && !o.scan403)) continue;
        const nb = r.url.endsWith("/") ? r.url : r.url + "/";
        if (!seenBases.has(nb)) { seenBases.add(nb); queue.push({ base: nb, depth: cur.depth + 1 }); }
      }
    }
  }
  return results.filter(r => visible(r, o, notFound) || r.code === 403);
}

function reportText(grouped: Array<{base: string, results: Result[]}>): string {
  let s = "";
  for (const g of grouped) {
    s += `Dirble Scan Report for ${g.base}:\n`;
    for (const r of g.results) {
      if (r.code === 403 && r.url.includes(".ht")) continue;
      s += line(r) + "\n";
    }
    s += "\n";
  }
  return s;
}

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function writeReports(o: Opts, grouped: Array<{base: string, results: Result[]}>) {
  const all = grouped.flatMap(g => g.results);
  if (o.outputAll) {
    o.outputFile = o.outputFile || `${o.outputAll}.txt`;
    o.jsonFile = o.jsonFile || `${o.outputAll}.json`;
    o.xmlFile = o.xmlFile || `${o.outputAll}.xml`;
  }
  if (o.outputFile) fs.writeFileSync(o.outputFile, reportText(grouped));
  if (o.jsonFile) fs.writeFileSync(o.jsonFile, all.map((r, i) => (i ? ",\n" : "[") + JSON.stringify(r)).join("") + "]");
  if (o.xmlFile) {
    let x = `<?xml version="1.0" encoding="UTF-8"?>\n<dirble_scan>\n`;
    for (const r of all) x += `<path url="${esc(r.url)}" code="${r.code}" content_len="${r.size}" is_directory="${r.is_directory}" is_listable="${r.is_listable}" redirect_url="${esc(r.redirect_url)}" found_from_listable="${r.found_from_listable}"/>\n`;
    x += `</dirble_scan>`;
    fs.writeFileSync(o.xmlFile, x);
  }
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  const words = buildWords(opts);
  const grouped: Array<{base: string, results: Result[]}> = [];
  for (const u of opts.uris) {
    const base = normalizeBase(u);
    grouped.push({ base, results: await scanBase(base, words, opts) });
  }
  writeReports(opts, grouped);
}

main().catch((e: any) => {
  console.error(e && e.stack ? e.stack : String(e));
  process.exit(1);
});
