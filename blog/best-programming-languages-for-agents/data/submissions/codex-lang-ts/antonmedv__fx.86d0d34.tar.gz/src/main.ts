declare const require: any;
declare const process: any;

const fs = require("fs");
const vm = require("vm");

type Json = any;

const VERSION = "39.2.0";

function help(): string {
  return `
  fx ${VERSION}
    Terminal JSON viewer

  Usage
    fx data.json
    fx data.json .field
    curl ... | fx

  Flags
    -h, --help            print help
    -v, --version         print version
    --themes              print themes
    --comp <shell>        print completion script
    -r, --raw             treat input as a raw string
    -s, --slurp           read all inputs into an array
    --yaml                parse input as YAML
    --toml                parse input as TOML
    --strict              strict mode
    --no-inline           disable inlining in output
    --game-of-life        play the game of life

  More info
    https://fx.wtf

  Author
    Anton Medvedev <anton@medv.io>
`;
}

function themes(): string {
  const sample = `{
  "string": "Fox jumps over the lazy dog",
  "number": 1234567890,
  "boolean": true,
  "null": null,
  "collapsed": {"preview":…}
}`;
  let out = "";
  for (let i = 0; i <= 10; i++) {
    out += `export FX_THEME="${i}"\n${sample}\n`;
  }
  return out;
}

function completion(shell: string): string {
  if (shell === "bash") return "\ncomplete -o filenames -C fx fx\n";
  if (shell === "zsh") return `#compdef fx

_fx() {
    local -a reply
    reply=("\${(@f)$(COMP_ZSH="\${LBUFFER}" fx)}")
    if (( \${#reply} )); then
        compadd "\${reply[@]}"
    fi
}
compdef _fx fx
`;
  if (shell === "fish") return "complete -c fx -f -a '(fx)'\n";
  return "";
}

function readStdin(): string {
  try {
    return fs.readFileSync(0, "utf8");
  } catch {
    return "";
  }
}

function splitTopLevelJson(input: string): string[] {
  const s = input.trim();
  if (!s) return [];
  const parts: string[] = [];
  let start = -1, depth = 0, inString = false, esc = false;
  let primitiveStart = -1;
  const finishPrimitive = (i: number) => {
    if (primitiveStart >= 0) {
      const p = s.slice(primitiveStart, i).trim();
      if (p) parts.push(p);
      primitiveStart = -1;
    }
  };
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (inString) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === "\"") inString = false;
      continue;
    }
    if (ch === "\"") {
      if (depth === 0 && start < 0 && primitiveStart < 0) primitiveStart = i;
      inString = true;
      continue;
    }
    if (ch === "{" || ch === "[") {
      if (depth === 0) start = i;
      depth++;
      continue;
    }
    if (ch === "}" || ch === "]") {
      depth--;
      if (depth === 0 && start >= 0) {
        parts.push(s.slice(start, i + 1));
        start = -1;
      }
      continue;
    }
    if (depth === 0) {
      if (/\s/.test(ch)) finishPrimitive(i);
      else if (start < 0 && primitiveStart < 0) primitiveStart = i;
    }
  }
  if (start >= 0) parts.push(s.slice(start));
  finishPrimitive(s.length);
  return parts.length ? parts : [s];
}

function parseJsonInputs(input: string): Json[] {
  const chunks = splitTopLevelJson(input);
  if (chunks.length === 0) return [];
  return chunks.map((chunk) => JSON.parse(chunk));
}

function scalar(v: string): any {
  const t = v.trim();
  if (t === "true") return true;
  if (t === "false") return false;
  if (t === "null") return null;
  if ((t.startsWith("\"") && t.endsWith("\"")) || (t.startsWith("'") && t.endsWith("'"))) return t.slice(1, -1);
  if (/^-?\d+(\.\d+)?$/.test(t)) return Number(t);
  return t;
}

function parseYaml(input: string): Json {
  const lines = input.replace(/\r/g, "").split("\n");
  const root: any = {};
  let currentKey: string | null = null;
  for (const raw of lines) {
    if (!raw.trim() || raw.trim().startsWith("#")) continue;
    const item = raw.match(/^\s*-\s*(.*)$/);
    if (item && currentKey) {
      if (!Array.isArray(root[currentKey])) root[currentKey] = [];
      root[currentKey].push(scalar(item[1]));
      continue;
    }
    const m = raw.match(/^([^:]+):\s*(.*)$/);
    if (m) {
      currentKey = m[1].trim();
      root[currentKey] = m[2].trim() === "" ? [] : scalar(m[2]);
    }
  }
  return root;
}

function parseToml(input: string): Json {
  const root: any = {};
  let target = root;
  for (const raw of input.replace(/\r/g, "").split("\n")) {
    const line = raw.replace(/#.*$/, "").trim();
    if (!line) continue;
    const sec = line.match(/^\[([^\]]+)\]$/);
    if (sec) {
      target = root;
      for (const part of sec[1].split(".")) target = target[part] ??= {};
      continue;
    }
    const m = line.match(/^([A-Za-z0-9_.-]+)\s*=\s*(.*)$/);
    if (!m) continue;
    target[m[1]] = scalar(m[2]);
  }
  return root;
}

function transformExpression(expr: string): string {
  const trimmed = expr.trim();
  if (!trimmed || trimmed === ".") return "x";
  if (trimmed === "keys") return "Object.keys(x)";
  if (trimmed === "values") return "Object.values(x)";
  if (trimmed === "len") return "(x == null ? 0 : (typeof x === 'object' ? Object.keys(x).length : x.length))";
  if (trimmed.startsWith(".")) return "x" + trimmed;
  return trimmed;
}

function evalExpression(expr: string, x: Json): Json {
  const code = transformExpression(expr);
  const context = vm.createContext({
    x,
    JSON,
    Object,
    Array,
    Math,
    Number,
    String,
    Boolean,
    Date,
    console,
    keys: Object.keys(x ?? {}),
    values: Object.values(x ?? {}),
    len: x == null ? 0 : (typeof x === "object" ? Object.keys(x).length : x.length),
  });
  let result = vm.runInContext(`(${code})`, context);
  if (typeof result === "function") result = result(x);
  return result;
}

function format(value: Json): string {
  if (value === undefined) return "undefined\n";
  if (typeof value === "string") return value + "\n";
  if (typeof value === "number" || typeof value === "boolean" || value === null) return String(value) + "\n";
  return JSON.stringify(value, null, 2) + "\n";
}

function formatError(expr: string, e: any): string {
  const msg = e && e.name ? `${e.name}: ${e.message}` : String(e);
  return `\n  ${expr}\n  ${"^".repeat(Math.max(1, expr.length))}\n\n${msg}\n`;
}

function main(): number {
  const args = process.argv.slice(2);
  if (args.includes("-h") || args.includes("--help")) {
    process.stdout.write(help());
    return 0;
  }
  if (args.includes("-v") || args.includes("--version")) {
    process.stdout.write(VERSION + "\n");
    return 0;
  }
  if (args.includes("--themes")) {
    process.stdout.write(themes());
    return 0;
  }
  const compIdx = args.indexOf("--comp");
  if (compIdx >= 0) {
    process.stdout.write(completion(args[compIdx + 1] ?? ""));
    return 0;
  }
  if (args.includes("--game-of-life")) {
    process.stdout.write("Game of Life is unavailable in this terminal.\n");
    return 0;
  }

  const raw = args.includes("-r") || args.includes("--raw");
  const slurp = args.includes("-s") || args.includes("--slurp");
  const yaml = args.includes("--yaml");
  const toml = args.includes("--toml");
  const positional = args.filter((a, i) => {
    if (i > 0 && args[i - 1] === "--comp") return false;
    return !["-r", "--raw", "-s", "--slurp", "--yaml", "--toml", "--strict", "--no-inline"].includes(a);
  });

  let input = "";
  const exprs: string[] = [];
  for (const p of positional) {
    if (!p.startsWith(".") && fs.existsSync(p) && fs.statSync(p).isFile()) input += fs.readFileSync(p, "utf8");
    else exprs.push(p);
  }
  if (!input) input = readStdin();

  let values: Json[];
  try {
    if (raw) values = [input.replace(/\n$/, "")];
    else if (yaml) values = [parseYaml(input)];
    else if (toml) values = [parseToml(input)];
    else values = parseJsonInputs(input);
  } catch (e: any) {
    process.stderr.write(e.message + "\n");
    return 1;
  }

  let current: Json[] = slurp ? [values] : values;
  const expressions = exprs.length ? exprs : ["."];
  for (const expr of expressions) {
    const next: Json[] = [];
    for (const v of current) {
      try {
        next.push(evalExpression(expr, v));
      } catch (e) {
        process.stderr.write(formatError(expr, e));
        return 1;
      }
    }
    current = next;
  }
  for (const v of current) process.stdout.write(format(v));
  return 0;
}

process.exitCode = main();
