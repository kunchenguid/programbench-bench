declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");
const childProcess = require("child_process");

type Opts = {
  allEvents: boolean;
  clear: number;
  dirs: number;
  nonInteractive: boolean;
  postpone: boolean;
  restart: boolean;
  shell: boolean;
  statusFormat: number;
  exitAfter: boolean;
};

type WatchEntry = {
  input: string;
  abs: string;
  isDir: boolean;
  mtimeMs: number;
  size: number;
  entries: Set<string>;
};

const invoked = process.env.ENTR_INVOKED || process.argv[1] || "executable";
const prog = path.basename(invoked);

function usage(hint = true): void {
  console.error("release: 5.7");
  console.error("usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames");
  if (hint) {
    console.error("hint: use -h to display option summary");
  } else {
    console.error("summary:");
    console.error("    -a  Do not consolidate events");
    console.error("    -c  Clear screen before execution");
    console.error("    -d  Track files added or removed from directories");
    console.error("    -n  Non-interactive mode");
    console.error("    -p  Wait for first event");
    console.error("    -r  Run as a background process, use signal to restart");
    console.error("    -s  Evaluate using a shell");
    console.error("    -x  Format exit status");
    console.error("    -z  Exit after the utility completes");
    console.error("docs:");
    console.error("    man entr");
  }
}

function die(message: string, code = 1): never {
  console.error(`${prog}: ${message}`);
  process.exit(code);
  throw new Error(message);
}

function parseArgs(argv: string[]): { opts: Opts; cmd: string[] } {
  const opts: Opts = {
    allEvents: false,
    clear: 0,
    dirs: 0,
    nonInteractive: false,
    postpone: false,
    restart: false,
    shell: false,
    statusFormat: 0,
    exitAfter: false,
  };

  if (argv.length > 0 && argv[0] === "-h") {
    usage(false);
    process.exit(1);
  }

  let i = 0;
  outer: for (; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--") {
      i++;
      break;
    }
    if (!arg.startsWith("-") || arg === "-") break;
    for (let j = 1; j < arg.length; j++) {
      const ch = arg[j];
      switch (ch) {
        case "a":
          opts.allEvents = true;
          break;
        case "c":
          opts.clear++;
          break;
        case "d":
          opts.dirs++;
          break;
        case "n":
          opts.nonInteractive = true;
          break;
        case "p":
          opts.postpone = true;
          break;
        case "r":
          opts.restart = true;
          break;
        case "s":
          opts.shell = true;
          break;
        case "x":
          opts.statusFormat++;
          break;
        case "z":
          opts.exitAfter = true;
          break;
        default:
          console.error(`${invoked}: invalid option -- '${ch}'`);
          usage(true);
          process.exit(1);
      }
    }
  }

  const cmd = argv.slice(i);
  if (opts.shell && cmd.length > 1) {
    die("-s requires commands to be formatted as a single argument");
  }
  if (cmd.length === 0) {
    usage(true);
    process.exit(1);
  }
  return { opts, cmd };
}

function readStdin(): string {
  try {
    return fs.readFileSync(0, "utf8");
  } catch (_err) {
    return "";
  }
}

function listDir(abs: string, includeHidden: boolean): Set<string> {
  try {
    const names: string[] = fs.readdirSync(abs);
    return new Set(names.filter((n) => includeHidden || !n.startsWith(".")));
  } catch (_err) {
    return new Set();
  }
}

function makeEntry(input: string, opts: Opts): WatchEntry | null {
  let st;
  try {
    st = fs.statSync(input);
  } catch (_err) {
    console.error(`${prog}: unable to stat '${input}'`);
    return null;
  }
  const abs = path.resolve(input);
  const isDir = st.isDirectory();
  if (!st.isFile() && !isDir) return null;
  return {
    input,
    abs,
    isDir,
    mtimeMs: st.mtimeMs,
    size: st.size,
    entries: isDir ? listDir(abs, opts.dirs > 1) : new Set<string>(),
  };
}

function buildWatchList(inputs: string[], opts: Opts): WatchEntry[] {
  const seen = new Set<string>();
  const out: WatchEntry[] = [];
  for (const raw of inputs) {
    const input = raw.replace(/\r$/, "");
    if (input.length === 0) continue;
    const entry = makeEntry(input, opts);
    if (!entry) continue;
    const key = entry.abs;
    if (!seen.has(key)) {
      seen.add(key);
      out.push(entry);
    }
    if (opts.dirs > 0 && !entry.isDir) {
      const dirInput = path.dirname(input) || ".";
      const dirAbs = path.resolve(dirInput);
      if (!seen.has(dirAbs)) {
        try {
          const st = fs.statSync(dirInput);
          if (st.isDirectory()) {
            seen.add(dirAbs);
            out.push({
              input: dirInput,
              abs: dirAbs,
              isDir: true,
              mtimeMs: st.mtimeMs,
              size: st.size,
              entries: listDir(dirAbs, opts.dirs > 1),
            });
          }
        } catch (_err) {
          // The file itself was already accepted; ignore a disappearing parent.
        }
      }
    }
  }
  return out;
}

function signalToNode(name: string | undefined): string {
  const n = (name || "TERM").replace(/^SIG/, "").toUpperCase();
  const allowed: any = { HUP: "SIGHUP", INT: "SIGINT", QUIT: "SIGQUIT", TERM: "SIGTERM", USR1: "SIGUSR1", USR2: "SIGUSR2" };
  return allowed[n] || "SIGTERM";
}

function clearScreen(opts: Opts): void {
  if (opts.clear <= 0) return;
  process.stdout.write(opts.clear > 1 ? "\x1b[3J\x1b[H\x1b[2J" : "\x1b[H\x1b[2J");
}

function commandFor(cmd: string[], opts: Opts, trigger: string): { file: string; args: string[]; options: any } {
  if (opts.shell) {
    const shell = process.env.SHELL || "/bin/sh";
    return { file: shell, args: ["-c", cmd[0], trigger], options: { stdio: "inherit", env: { ...process.env, PAGER: process.env.PAGER || "/bin/cat" } } };
  }
  const replaced = cmd.map((a) => (a === "/_" ? trigger : a));
  return { file: replaced[0], args: replaced.slice(1), options: { stdio: "inherit", env: { ...process.env, PAGER: process.env.PAGER || "/bin/cat" } } };
}

function runOnce(cmd: string[], opts: Opts, trigger: string): Promise<number> {
  clearScreen(opts);
  return new Promise((resolve) => {
    const spec = commandFor(cmd, opts, trigger);
    let child;
    try {
      child = childProcess.spawn(spec.file, spec.args, spec.options);
    } catch (err: any) {
      console.error(`${prog}: exec ${spec.file}: ${err && err.message ? err.message : "No such file or directory"}`);
      resolve(1);
      return;
    }
    child.on("error", (err: any) => {
      const msg = err && err.code === "ENOENT" ? "No such file or directory" : (err && err.message) || "error";
      console.error(`${prog}: exec ${spec.file}: ${msg}`);
      resolve(1);
    });
    child.on("exit", (code: number | null, signal: string | null) => {
      if (typeof code === "number") resolve(code);
      else if (signal && /^SIG/.test(signal)) {
        const constants = require("os").constants.signals;
        resolve((constants[signal] || 0) + 128);
      } else resolve(1);
    });
  });
}

function changed(entry: WatchEntry, opts: Opts): { changed: boolean; dirChanged: boolean } {
  let st;
  try {
    st = fs.statSync(entry.abs);
  } catch (_err) {
    return { changed: true, dirChanged: entry.isDir };
  }
  if (entry.isDir) {
    const now = listDir(entry.abs, opts.dirs > 1);
    if (now.size !== entry.entries.size) {
      entry.entries = now;
      return { changed: true, dirChanged: true };
    }
    for (const n of now) {
      if (!entry.entries.has(n)) {
        entry.entries = now;
        return { changed: true, dirChanged: true };
      }
    }
    entry.mtimeMs = st.mtimeMs;
    entry.size = st.size;
    return { changed: false, dirChanged: false };
  }
  if (st.mtimeMs !== entry.mtimeMs || st.size !== entry.size) {
    entry.mtimeMs = st.mtimeMs;
    entry.size = st.size;
    return { changed: true, dirChanged: false };
  }
  return { changed: false, dirChanged: false };
}

async function watchLoop(entries: WatchEntry[], cmd: string[], opts: Opts): Promise<void> {
  let running = false;
  let queued: string | null = null;
  let child: any = null;
  const restartSignal = signalToNode(process.env.ENTR_RESTART_SIGNAL);

  const launch = async (trigger: string) => {
    if (!opts.restart) {
      running = true;
      const code = await runOnce(cmd, opts, trigger);
      running = false;
      if (opts.exitAfter) process.exit(code);
      if (queued) {
        const q = queued;
        queued = null;
        void launch(q);
      }
      return;
    }

    const start = () => {
      clearScreen(opts);
      const spec = commandFor(cmd, opts, trigger);
      try {
        child = childProcess.spawn(spec.file, spec.args, { ...spec.options, detached: true });
      } catch (err: any) {
        console.error(`${prog}: exec ${spec.file}: ${err && err.message ? err.message : "No such file or directory"}`);
        child = null;
      }
      if (child) {
        child.on("exit", (code: number | null) => {
          child = null;
          if (opts.exitAfter && code !== null) process.exit(code);
        });
        child.on("error", (err: any) => {
          console.error(`${prog}: exec ${spec.file}: ${(err && err.code === "ENOENT") ? "No such file or directory" : err.message}`);
          child = null;
        });
      }
    };

    if (child && child.pid) {
      running = true;
      try {
        process.kill(-child.pid, restartSignal);
      } catch (_err) {
        try { child.kill(restartSignal); } catch (_err2) {}
      }
      await new Promise((resolve) => {
        const done = () => resolve(null);
        child.once("exit", done);
        setTimeout(done, 2000);
      });
      running = false;
    }
    start();
  };

  if (!opts.postpone) await launch(entries[0].input);

  process.on("SIGINT", () => {
    if (child && child.pid) {
      try { process.kill(-child.pid, "SIGINT"); } catch (_err) { try { child.kill("SIGINT"); } catch (_err2) {} }
    }
    process.exit(0);
  });
  process.on("SIGTERM", () => process.exit(0));

  setInterval(() => {
    for (const entry of entries) {
      const c = changed(entry, opts);
      if (!c.changed) continue;
      if (process.env.EV_TRACE) console.error(`${entry.input}: change`);
      if (c.dirChanged && opts.dirs > 0 && !opts.restart && !opts.exitAfter) {
        process.exit(2);
      }
      if (running && !opts.allEvents) {
        queued = entry.input;
      } else {
        void launch(entry.input);
      }
      break;
    }
  }, 250);
}

async function main(): Promise<void> {
  const { opts, cmd } = parseArgs(process.argv.slice(2));

  const inputs = readStdin().split("\n");
  const entries = buildWatchList(inputs, opts);
  if (entries.length === 0) die("No regular files to watch");

  if (!opts.nonInteractive && !process.stdin.isTTY) {
    // entr tries to open /dev/tty, but these cleanroom tests run without one.
    die("unable to get terminal attributes, use '-n' to run non-interactively");
  }

  const first = entries[0].input;
  if (opts.exitAfter) {
    const code = opts.postpone ? 0 : await runOnce(cmd, opts, first);
    process.exit(code);
  }

  await watchLoop(entries, cmd, opts);
}

void main();
