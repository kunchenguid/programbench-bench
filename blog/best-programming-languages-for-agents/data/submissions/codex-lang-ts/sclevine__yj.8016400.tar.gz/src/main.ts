declare const process: {
  argv: string[];
  stdin: { on(event: string, cb: (chunk?: any) => void): any; setEncoding(enc: string): void };
  stdout: { write(s: string): void };
  stderr: { write(s: string): void };
  exit(code?: number): never;
};

type J = null | boolean | number | string | J[] | { [k: string]: J };
type Mode = "y" | "t" | "j" | "c";

const HELP = `Usage: ./executable [-][ytjcrneikhv]

Convert between YAML, TOML, JSON, and HCL.
Preserves map order.

-x[x]  Convert using stdin. Valid options:
          -yj, -y = YAML to JSON (default)
          -yy     = YAML to YAML
          -yt     = YAML to TOML
          -yc     = YAML to HCL
          -tj, -t = TOML to JSON
          -ty     = TOML to YAML
          -tt     = TOML to TOML
          -tc     = TOML to HCL
          -jj     = JSON to JSON
          -jy, -r = JSON to YAML
          -jt     = JSON to TOML
          -jc     = JSON to HCL
          -cy     = HCL to YAML
          -ct     = HCL to TOML
          -cj, -c = HCL to JSON
          -cc     = HCL to HCL
-n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)
-e     Escape HTML (JSON out only)
-i     Indent output (JSON or TOML out only)
-k     Attempt to parse keys as objects or numeric types (YAML out only)
-h     Show this help message
-v     Show version
`;

interface Opts { input: Mode; output: Mode; indent: boolean; escapeHtml: boolean; noStringFloats: boolean; parseKeys: boolean; }

function parseArgs(argv: string[]): Opts | "help" | "version" {
  let flags = "";
  for (const a of argv.slice(2)) {
    if (!a.startsWith("-")) continue;
    flags += a.slice(1);
  }
  const valid = new Set("ytjcrneikhv".split(""));
  const bad = flags.split("").filter(c => !valid.has(c));
  if (bad.length) fail(`invalid flags specified: ${bad.join(" ")}`, true);
  if (flags.includes("h")) return "help";
  if (flags.includes("v")) return "version";
  let input: Mode = "y", output: Mode = "j";
  if (flags.includes("r")) { input = "j"; output = "y"; }
  const modes = flags.split("").filter(c => "ytjc".includes(c)) as Mode[];
  if (modes.length === 1) {
    if (modes[0] === "y") { input = "y"; output = "j"; }
    else if (modes[0] === "t") { input = "t"; output = "j"; }
    else if (modes[0] === "c") { input = "c"; output = "j"; }
    else { input = "j"; output = "j"; }
  } else if (modes.length >= 2) {
    input = modes[0]; output = modes[1];
  }
  return { input, output, indent: flags.includes("i"), escapeHtml: flags.includes("e"), noStringFloats: flags.includes("n"), parseKeys: flags.includes("k") };
}

function fail(msg: string, usage = false): never {
  if (usage) process.stderr.write(HELP + "\n");
  process.stderr.write(`Error: ${msg}\n`);
  process.exit(1);
}

function stripComment(s: string): string {
  let quote = "", esc = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (esc) { esc = false; continue; }
    if (quote) {
      if (c === "\\") esc = true;
      else if (c === quote) quote = "";
    } else if (c === '"' || c === "'") quote = c;
    else if (c === "#") return s.slice(0, i).trimEnd();
  }
  return s.trimEnd();
}

function unquote(s: string): string {
  s = s.trim();
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
    if (s[0] === '"') {
      try { return JSON.parse(s); } catch { return s.slice(1, -1); }
    }
    return s.slice(1, -1).replace(/''/g, "'");
  }
  return s;
}

function splitTop(s: string, sep: string): string[] {
  const out: string[] = [];
  let start = 0, depth = 0, quote = "", esc = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (esc) { esc = false; continue; }
    if (quote) {
      if (c === "\\") esc = true;
      else if (c === quote) quote = "";
    } else if (c === '"' || c === "'") quote = c;
    else if (c === "[" || c === "{") depth++;
    else if (c === "]" || c === "}") depth--;
    else if (c === sep && depth === 0) { out.push(s.slice(start, i).trim()); start = i + 1; }
  }
  out.push(s.slice(start).trim());
  return out.filter(x => x.length);
}

function findTopColon(s: string): number {
  let depth = 0, quote = "", esc = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (esc) { esc = false; continue; }
    if (quote) {
      if (c === "\\") esc = true;
      else if (c === quote) quote = "";
    } else if (c === '"' || c === "'") quote = c;
    else if (c === "[" || c === "{") depth++;
    else if (c === "]" || c === "}") depth--;
    else if (c === ":" && depth === 0) return i;
  }
  return -1;
}

function parseScalar(raw: string, noStringFloats: boolean): J {
  const s = raw.trim();
  if (s === "") return "";
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) return unquote(s);
  const low = s.toLowerCase();
  if (["null", "~"].includes(low)) return null;
  if (["true", "yes", "on"].includes(low)) return true;
  if (["false", "no", "off"].includes(low)) return false;
  if ([".inf", ".infinity", "+.inf", "+.infinity", "inf", "+inf"].includes(low)) return noStringFloats ? Number.MAX_VALUE : "Infinity";
  if (["-.inf", "-.infinity", "-inf"].includes(low)) return noStringFloats ? -Number.MAX_VALUE : "-Infinity";
  if ([".nan", "nan"].includes(low)) return noStringFloats ? null : "NaN";
  if (/^[+-]?(?:0|[1-9][\d_]*)(?:\.[\d_]+)?(?:[eE][+-]?[\d_]+)?$/.test(s)) return Number(s.replace(/_/g, ""));
  if (s.startsWith("[") && s.endsWith("]")) return splitTop(s.slice(1, -1), ",").map(x => parseScalar(x, noStringFloats));
  if (s.startsWith("{") && s.endsWith("}")) {
    const o: { [k: string]: J } = {};
    for (const part of splitTop(s.slice(1, -1), ",")) {
      const p = findTopColon(part) >= 0 ? findTopColon(part) : part.indexOf("=");
      if (p >= 0) o[unquote(part.slice(0, p).trim())] = parseScalar(part.slice(p + 1), noStringFloats);
    }
    return o;
  }
  return s;
}

interface YLine { indent: number; text: string; }

function yamlLines(input: string): YLine[] {
  return input.replace(/\r\n/g, "\n").split("\n").map(line => {
    const stripped = stripComment(line);
    return { indent: (stripped.match(/^ */) || [""])[0].length, text: stripped.trim() };
  }).filter(l => l.text);
}

function parseYAML(input: string, opts: Opts): J {
  const lines = yamlLines(input);
  if (!lines.length) return null;
  function block(i: number, indent: number): [J, number] {
    if (i >= lines.length) return [null, i];
    if (lines[i].text.startsWith("- ")) {
      const arr: J[] = [];
      while (i < lines.length && lines[i].indent === indent && lines[i].text.startsWith("- ")) {
        const item = lines[i].text.slice(2).trim();
        i++;
        if (!item) {
          const r = block(i, nextIndent(i, indent));
          arr.push(r[0]); i = r[1];
        } else {
          const c = findTopColon(item);
          if (c > 0 && !item.startsWith("{")) {
            const o: { [k: string]: J } = {};
            const key = unquote(item.slice(0, c).trim());
            const rest = item.slice(c + 1).trim();
            if (rest) o[key] = parseScalar(rest, opts.noStringFloats);
            else { const r = block(i, nextIndent(i, indent)); o[key] = r[0]; i = r[1]; }
            while (i < lines.length && lines[i].indent > indent && !lines[i].text.startsWith("- ")) {
              const p = findTopColon(lines[i].text);
              if (p < 0) break;
              const k = unquote(lines[i].text.slice(0, p).trim());
              const v = lines[i].text.slice(p + 1).trim();
              const myIndent = lines[i].indent;
              i++;
              if (v) o[k] = parseScalar(v, opts.noStringFloats);
              else { const r = block(i, nextIndent(i, myIndent)); o[k] = r[0]; i = r[1]; }
            }
            arr.push(o);
          } else arr.push(parseScalar(item, opts.noStringFloats));
        }
      }
      return [arr, i];
    }
    const obj: { [k: string]: J } = {};
    while (i < lines.length && lines[i].indent === indent && !lines[i].text.startsWith("- ")) {
      const p = findTopColon(lines[i].text);
      if (p < 0) { i++; continue; }
      const key = unquote(lines[i].text.slice(0, p).trim());
      const rest = lines[i].text.slice(p + 1).trim();
      const myIndent = lines[i].indent;
      i++;
      if (rest) obj[key] = parseScalar(rest, opts.noStringFloats);
      else { const r = block(i, nextIndent(i, myIndent)); obj[key] = r[0]; i = r[1]; }
    }
    return [obj, i];
  }
  function nextIndent(i: number, fallback: number): number {
    return i < lines.length ? lines[i].indent : fallback + 2;
  }
  return block(0, lines[0].indent)[0];
}

function parseJSON(input: string): J {
  return JSON.parse(input || "null") as J;
}

function setPath(root: any, path: string[], value: J) {
  let cur = root;
  for (let i = 0; i < path.length - 1; i++) cur = cur[path[i]] ??= {};
  cur[path[path.length - 1]] = value;
}

function parseValue(s: string, opts: Opts): J {
  s = s.trim().replace(/,$/, "");
  const eqObj = s.startsWith("{") && s.endsWith("}") && s.includes("=");
  if (eqObj) {
    const o: { [k: string]: J } = {};
    for (const p of splitTop(s.slice(1, -1), ",")) {
      const at = p.indexOf("=");
      if (at >= 0) o[unquote(p.slice(0, at))] = parseValue(p.slice(at + 1), opts);
    }
    return o;
  }
  return parseScalar(s, opts.noStringFloats);
}

function parseTOML(input: string, opts: Opts): J {
  const root: any = {};
  let table: string[] = [];
  for (const raw of input.replace(/\r\n/g, "\n").split("\n")) {
    const line = stripComment(raw).trim();
    if (!line) continue;
    if (line.startsWith("[[") && line.endsWith("]]")) {
      table = line.slice(2, -2).trim().split(".").map(unquote);
      let parent = root;
      for (let i = 0; i < table.length - 1; i++) parent = parent[table[i]] ??= {};
      const k = table[table.length - 1];
      parent[k] ??= [];
      parent[k].push({});
      continue;
    }
    if (line.startsWith("[") && line.endsWith("]")) {
      table = line.slice(1, -1).trim().split(".").map(unquote);
      let cur = root;
      for (const k of table) cur = cur[k] ??= {};
      continue;
    }
    const at = line.indexOf("=");
    if (at < 0) continue;
    const key = line.slice(0, at).trim().split(".").map(unquote);
    const val = parseValue(line.slice(at + 1), opts);
    let cur = root;
    for (const k of table) {
      cur = Array.isArray(cur[k]) ? cur[k][cur[k].length - 1] : (cur[k] ??= {});
    }
    setPath(cur, key, val);
  }
  return root;
}

function parseHCL(input: string, opts: Opts): J {
  const root: any = {};
  const stack: any[] = [root];
  for (const raw of input.replace(/\r\n/g, "\n").split("\n")) {
    let line = stripComment(raw).trim();
    if (!line) continue;
    while (line === "}" || line.startsWith("}")) { stack.pop(); line = line.slice(1).trim(); if (!line) break; }
    if (!line) continue;
    if (line.endsWith("{")) {
      const name = unquote(line.slice(0, -1).trim().split(/\s+/)[0]);
      const parent = stack[stack.length - 1];
      parent[name] ??= [];
      if (!Array.isArray(parent[name])) parent[name] = [parent[name]];
      const obj: any = {};
      parent[name].push(obj);
      stack.push(obj);
      continue;
    }
    const at = line.indexOf("=");
    if (at >= 0) stack[stack.length - 1][unquote(line.slice(0, at).trim())] = parseValue(line.slice(at + 1), opts);
  }
  return root;
}

function stringifyJSON(v: J, opts: Opts): string {
  let s = JSON.stringify(v, (_k, val) => typeof val === "number" && !Number.isFinite(val) ? null : val, opts.indent ? 2 : 0);
  if (opts.escapeHtml) s = s.replace(/[<>&]/g, c => c === "<" ? "\\u003c" : c === ">" ? "\\u003e" : "\\u0026");
  return s + "\n";
}

function yamlString(s: string): string {
  if (s === "") return '""';
  if (/^(?:y|Y|yes|Yes|YES|n|N|no|No|NO|true|True|TRUE|false|False|FALSE|on|On|ON|off|Off|OFF|null|Null|NULL|~|\d.*|-?\d.*)$/.test(s)) return JSON.stringify(s);
  if (/[:#\[\]{},&*!|>'"%@`]|^\s|\s$/.test(s)) return JSON.stringify(s);
  return s;
}

function toYAML(v: J, indent = 0): string {
  const sp = " ".repeat(indent);
  if (Array.isArray(v)) {
    return v.map(x => {
      if (x && typeof x === "object" && !Array.isArray(x)) {
        const entries = Object.entries(x);
        if (!entries.length) return `${sp}- {}`;
        const [firstKey, firstVal] = entries[0];
        const first = firstVal && typeof firstVal === "object"
          ? `${sp}- ${yamlString(firstKey)}:\n${toYAML(firstVal, indent + 4)}`
          : `${sp}- ${yamlString(firstKey)}: ${scalarOut(firstVal, "yaml")}`;
        const rest = entries.slice(1).map(([k, val]) => {
          if (val && typeof val === "object") return `${" ".repeat(indent + 2)}${yamlString(k)}:\n${toYAML(val, indent + 4)}`;
          return `${" ".repeat(indent + 2)}${yamlString(k)}: ${scalarOut(val, "yaml")}`;
        });
        return [first, ...rest].join("\n");
      }
      if (Array.isArray(x)) return `${sp}-\n${toYAML(x, indent + 2)}`;
      return `${sp}- ${scalarOut(x, "yaml")}`;
    }).join("\n");
  }
  if (v && typeof v === "object") {
    return Object.entries(v).map(([k, val]) => {
      const key = yamlString(k);
      if (val && typeof val === "object") return `${sp}${key}:\n${toYAML(val, indent + 2)}`;
      return `${sp}${key}: ${scalarOut(val, "yaml")}`;
    }).join("\n");
  }
  return sp + scalarOut(v, "yaml");
}

function scalarOut(v: J, kind: "yaml" | "toml" | "hcl"): string {
  if (v === null) return kind === "toml" ? '""' : "null";
  if (typeof v === "string") return kind === "yaml" ? yamlString(v) : JSON.stringify(v);
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  if (Array.isArray(v)) return `[${v.map(x => scalarOut(x, kind)).join(kind === "yaml" ? ", " : ", ")}]`;
  return kind === "hcl" ? `{\n${hclObject(v as any, 2)}\n}` : JSON.stringify(v);
}

function toTOML(v: J, indentFlag: boolean): string {
  if (!v || typeof v !== "object" || Array.isArray(v)) return scalarOut(v, "toml") + "\n";
  const lines: string[] = [];
  function writeTable(obj: any, path: string[]) {
    for (const [k, val] of Object.entries(obj)) {
      if (val === null || typeof val !== "object" || Array.isArray(val)) lines.push(`${k} = ${scalarOut(val as J, "toml")}`);
    }
    for (const [k, val] of Object.entries(obj)) {
      if (val && typeof val === "object" && !Array.isArray(val)) {
        if (lines.length) lines.push("");
        const p = [...path, k];
        lines.push(`[${p.join(".")}]`);
        writeTable(val, p);
      }
    }
  }
  writeTable(v, []);
  return lines.join("\n") + "\n";
}

function hclObject(obj: { [k: string]: J }, indent: number): string {
  const sp = " ".repeat(indent);
  return Object.entries(obj).map(([k, v]) => `${sp}${JSON.stringify(k)} = ${scalarOut(v, "hcl")}`).join("\n");
}

function toHCL(v: J): string {
  if (!v || typeof v !== "object" || Array.isArray(v)) return scalarOut(v, "hcl") + "\n";
  return Object.entries(v).map(([k, val]) => `${JSON.stringify(k)} = ${scalarOut(val, "hcl")}`).join("\n\n") + "\n";
}

function convert(input: string, opts: Opts): string {
  let data: J;
  if (opts.input === "j") data = parseJSON(input);
  else if (opts.input === "y") data = parseYAML(input, opts);
  else if (opts.input === "t") data = parseTOML(input, opts);
  else data = parseHCL(input, opts);
  if (opts.output === "j") return stringifyJSON(data, opts);
  if (opts.output === "y") return toYAML(data) + "\n";
  if (opts.output === "t") return toTOML(data, opts.indent);
  return toHCL(data);
}

const parsed = parseArgs(process.argv);
if (parsed === "help") { process.stdout.write(HELP + "\n"); process.exit(0); }
if (parsed === "version") { process.stdout.write("v0.0.0\n"); process.exit(0); }

let input = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", c => { input += c; });
process.stdin.on("end", () => {
  try { process.stdout.write(convert(input, parsed)); }
  catch (e: any) { fail(e?.message || String(e)); }
});
