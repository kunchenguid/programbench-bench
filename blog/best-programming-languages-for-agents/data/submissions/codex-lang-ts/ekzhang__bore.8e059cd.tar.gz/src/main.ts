declare function require(name: string): any;
declare const process: any;
declare const Buffer: any;

const net = require("net");

const CONTROL_PORT = 7835;
const VERSION = "bore-cli 0.6.0";
const DESC =
  "A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls.";

type Socket = any;

function stdout(text: string): void {
  process.stdout.write(text);
}

function stderr(text: string): void {
  process.stderr.write(text);
}

function mainHelp(): string {
  return `${DESC}

Usage: executable <COMMAND>

Commands:
  local   Starts a local proxy to the remote server
  server  Runs the remote proxy server
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version
`;
}

function localHelp(): string {
  return `Starts a local proxy to the remote server

Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>

Arguments:
  <LOCAL_PORT>  The local port to expose [env: BORE_LOCAL_PORT=]

Options:
  -l, --local-host <HOST>  The local host to expose [default: localhost]
  -t, --to <TO>            Address of the remote server to expose local ports to [env: BORE_SERVER=]
  -p, --port <PORT>        Optional port on the remote server to select [default: 0]
  -s, --secret <SECRET>    Optional secret for authentication [env: BORE_SECRET]
  -h, --help               Print help
`;
}

function serverHelp(): string {
  return `Runs the remote proxy server

Usage: executable server [OPTIONS]

Options:
      --min-port <MIN_PORT>          Minimum accepted TCP port number [env: BORE_MIN_PORT=] [default: 1024]
      --max-port <MAX_PORT>          Maximum accepted TCP port number [env: BORE_MAX_PORT=] [default: 65535]
  -s, --secret <SECRET>              Optional secret for authentication [env: BORE_SECRET]
      --bind-addr <BIND_ADDR>        IP address to bind to, clients must reach this [default: 0.0.0.0]
      --bind-tunnels <BIND_TUNNELS>  IP address where tunnels will listen on, defaults to --bind-addr
  -h, --help                         Print help
`;
}

function parsePort(value: string, label: string): number {
  if (!/^\d+$/.test(value)) {
    die(`error: invalid value '${value}' for '${label}': invalid digit found in string\n\nFor more information, try '--help'.\n`, 2);
  }
  const n = Number(value);
  if (n < 0 || n > 65535) {
    die(`error: invalid value '${value}' for '${label}': ${value} is not in 0..=65535\n\nFor more information, try '--help'.\n`, 2);
  }
  return n;
}

function die(message: string, code = 1): never {
  stderr(message);
  process.exit(code);
  throw new Error(message);
}

function log(msg: string): void {
  const ts = new Date().toISOString();
  stderr(`${ts} INFO ${msg}\n`);
}

function readJsonLines(sock: Socket, cb: (msg: any) => void): void {
  let buf = "";
  sock.on("data", (chunk: any) => {
    buf += chunk.toString("utf8");
    for (;;) {
      const idx = buf.indexOf("\n");
      if (idx < 0) break;
      const line = buf.slice(0, idx);
      buf = buf.slice(idx + 1);
      if (!line.trim()) continue;
      try {
        cb(JSON.parse(line));
      } catch {
        sock.destroy();
      }
    }
  });
}

function send(sock: Socket, obj: any): void {
  sock.write(JSON.stringify(obj) + "\n");
}

function parseLocal(args: string[]) {
  let localHost = "localhost";
  let to = process.env.BORE_SERVER || "";
  let remotePort = 0;
  let secret = process.env.BORE_SECRET || "";
  const positional: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") {
      stdout(localHelp());
      process.exit(0);
    } else if (a === "-l" || a === "--local-host") {
      localHost = args[++i] || "";
    } else if (a === "-t" || a === "--to") {
      to = args[++i] || "";
    } else if (a === "-p" || a === "--port") {
      remotePort = parsePort(args[++i] || "", "--port <PORT>");
    } else if (a === "-s" || a === "--secret") {
      secret = args[++i] || "";
    } else if (a.startsWith("-")) {
      die(`error: unexpected argument '${a}' found\n\nUsage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>\n\nFor more information, try '--help'.\n`, 2);
    } else {
      positional.push(a);
    }
  }
  if (!to || positional.length === 0) {
    const missing = [!to ? "  --to <TO>" : "", positional.length === 0 ? "  <LOCAL_PORT>" : ""].filter(Boolean).join("\n");
    die(`error: the following required arguments were not provided:\n${missing}\n\nUsage: executable local --to <TO> <LOCAL_PORT>\n\nFor more information, try '--help'.\n`, 2);
  }
  const localPort = parsePort(positional[0], "<LOCAL_PORT>");
  return { localHost, to, remotePort, secret, localPort };
}

function parseServer(args: string[]) {
  let minPort = process.env.BORE_MIN_PORT ? parsePort(process.env.BORE_MIN_PORT, "--min-port <MIN_PORT>") : 1024;
  let maxPort = process.env.BORE_MAX_PORT ? parsePort(process.env.BORE_MAX_PORT, "--max-port <MAX_PORT>") : 65535;
  let secret = process.env.BORE_SECRET || "";
  let bindAddr = "0.0.0.0";
  let bindTunnels = "";
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") {
      stdout(serverHelp());
      process.exit(0);
    } else if (a === "--min-port") {
      minPort = parsePort(args[++i] || "", "--min-port <MIN_PORT>");
    } else if (a === "--max-port") {
      maxPort = parsePort(args[++i] || "", "--max-port <MAX_PORT>");
    } else if (a === "-s" || a === "--secret") {
      secret = args[++i] || "";
    } else if (a === "--bind-addr") {
      bindAddr = args[++i] || "";
    } else if (a === "--bind-tunnels") {
      bindTunnels = args[++i] || "";
    } else {
      die(`error: unexpected argument '${a}' found\n\nUsage: executable server [OPTIONS]\n\nFor more information, try '--help'.\n`, 2);
    }
  }
  if (!bindTunnels) bindTunnels = bindAddr;
  return { minPort, maxPort, secret, bindAddr, bindTunnels };
}

async function runLocal(args: string[]): Promise<void> {
  const cfg = parseLocal(args);
  const control = net.connect(CONTROL_PORT, cfg.to);
  control.on("error", (err: any) => die(`Error: could not connect to ${cfg.to}:${CONTROL_PORT}\n\nCaused by:\n    ${err.message}\n`));
  control.on("connect", () => send(control, { type: "hello", port: cfg.remotePort, secret: cfg.secret }));
  readJsonLines(control, (msg) => {
    if (msg.type === "ok") {
      log(`connected to server remote_port=${msg.port}`);
      log(`listening at ${cfg.to}:${msg.port}`);
    } else if (msg.type === "error") {
      die(`Error: ${msg.message}\n`);
    } else if (msg.type === "connect") {
      openLocalData(cfg, msg.id);
    }
  });
}

function openLocalData(cfg: any, id: number): void {
  const local = net.connect(cfg.localPort, cfg.localHost);
  const remote = net.connect(CONTROL_PORT, cfg.to);
  let remoteReady = false;
  let localReady = false;
  const maybePipe = () => {
    if (remoteReady && localReady) {
      local.pipe(remote);
      remote.pipe(local);
    }
  };
  remote.on("connect", () => {
    send(remote, { type: "data", id, secret: cfg.secret });
    remoteReady = true;
    maybePipe();
  });
  local.on("connect", () => {
    localReady = true;
    maybePipe();
  });
  local.on("error", () => remote.destroy());
  remote.on("error", () => local.destroy());
}

const tunnels = new Map<number, any>();

async function listenOn(server: any, port: number, host: string): Promise<number> {
  return await new Promise((resolve, reject) => {
    const onError = (e: any) => reject(e);
    server.once("error", onError);
    server.listen(port, host, () => {
      server.off("error", onError);
      resolve(server.address().port);
    });
  });
}

async function allocatePort(srv: any, requested: number, min: number, max: number, host: string): Promise<number> {
  if (requested !== 0) {
    if (requested < min || requested > max) throw new Error(`requested port ${requested} is not in range ${min}..=${max}`);
    return await listenOn(srv, requested, host);
  }
  for (let p = min; p <= max; p++) {
    try {
      return await listenOn(srv, p, host);
    } catch (e: any) {
      if (e.code !== "EADDRINUSE" && e.code !== "EACCES") throw e;
    }
  }
  throw new Error("no ports available");
}

async function setupTunnel(control: Socket, cfg: any, requested: number): Promise<void> {
  const pending = new Map<number, Socket>();
  let nextId = 1;
  const publicServer = net.createServer((publicSock: Socket) => {
    const id = nextId++;
    pending.set(id, publicSock);
    send(control, { type: "connect", id });
    const timer = setTimeout(() => {
      const s = pending.get(id);
      if (s) s.destroy();
      pending.delete(id);
    }, 10000);
    publicSock.on("close", () => {
      clearTimeout(timer);
      pending.delete(id);
    });
  });
  const port = await allocatePort(publicServer, requested, cfg.minPort, cfg.maxPort, cfg.bindTunnels);
  const state = { control, pending, publicServer };
  tunnels.set(port, state);
  control.on("close", () => {
    publicServer.close();
    tunnels.delete(port);
    for (const sock of pending.values()) sock.destroy();
  });
  send(control, { type: "ok", port });
  log(`new client host=${cfg.bindAddr} port=${port}`);
}

function attachData(sock: Socket, id: number): void {
  for (const state of tunnels.values()) {
    const publicSock = state.pending.get(id);
    if (!publicSock) continue;
    state.pending.delete(id);
    sock.removeAllListeners("data");
    sock.pipe(publicSock);
    publicSock.pipe(sock);
    return;
  }
  sock.destroy();
}

async function runServer(args: string[]): Promise<void> {
  const cfg = parseServer(args);
  const controlServer = net.createServer((sock: Socket) => {
    log("incoming connection");
    readJsonLines(sock, async (msg) => {
      if (msg.secret !== cfg.secret) {
        send(sock, { type: "error", message: "authentication failed" });
        sock.destroy();
        return;
      }
      if (msg.type === "hello") {
        try {
          await setupTunnel(sock, cfg, Number(msg.port) || 0);
        } catch (e: any) {
          send(sock, { type: "error", message: e.message });
          sock.destroy();
        }
      } else if (msg.type === "data") {
        attachData(sock, Number(msg.id));
      }
    });
    sock.on("close", () => log("connection exited"));
  });
  controlServer.on("error", (e: any) => die(`Error: ${e.message}\n`));
  await listenOn(controlServer, CONTROL_PORT, cfg.bindAddr);
  log(`server listening addr=${cfg.bindAddr}`);
}

const argv = process.argv.slice(2);
if (argv.length === 0 || argv[0] === "-h" || argv[0] === "--help") {
  stdout(mainHelp());
  process.exit(argv.length === 0 ? 2 : 0);
}
if (argv[0] === "-V" || argv[0] === "--version") {
  stdout(VERSION + "\n");
  process.exit(0);
}
if (argv[0] === "help") {
  if (argv[1] === "local") stdout(localHelp());
  else if (argv[1] === "server") stdout(serverHelp());
  else stdout(mainHelp());
  process.exit(0);
}
if (argv[0] === "local") {
  runLocal(argv.slice(1));
} else if (argv[0] === "server") {
  runServer(argv.slice(1));
} else {
  die(`error: unrecognized subcommand '${argv[0]}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n`, 2);
}
