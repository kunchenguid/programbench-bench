#!/usr/bin/env node
declare const require: any;
declare const process: any;
const fs = require('fs');
const path = require('path');

const VERSION = '0.21.1';
const SCHEMA = '2024-11-02';

type Quantity = 'apparent-size' | 'block-size' | 'block-count';
type BytesFormat = 'plain' | 'metric' | 'binary';

type NodeT = { name: string; size: number; children: NodeT[]; _apparent?: number; _path?: string; _key?: string; _links?: number; _ino?: number };
type Opts = {
  jsonInput: boolean; jsonOutput: boolean; bytesFormat: BytesFormat; dedupe: boolean;
  topDown: boolean; alignRight: boolean; quantity: Quantity; maxDepth: number;
  totalWidth?: number; columnWidth?: [number, number]; minRatio: number; sort: boolean;
  silent: boolean; progress: boolean; threads: string; omitDetails: boolean; omitSummary: boolean; files: string[];
};

function help(long = false): string {
  if (!long) return `Summarize disk usage of the set of files, recursively for directories.\n\nUsage: executable [OPTIONS] [FILES]...\n\nArguments:\n  [FILES]...  List of files and/or directories\n\nOptions:\n      --json-input\n          Read JSON data from stdin\n      --json-output\n          Print JSON data instead of an ASCII chart\n  -b, --bytes-format <BYTES_FORMAT>\n          How to display the numbers of bytes [default: metric] [possible values: plain, metric, binary]\n  -H, --deduplicate-hardlinks\n          Detect and subtract the sizes of hardlinks from their parent directory totals [aliases: --detect-links, --dedupe-links]\n      --top-down\n          Print the tree top-down instead of bottom-up\n      --align-right\n          Set the root of the bars to the right\n  -q, --quantity <QUANTITY>\n          Aspect of the files/directories to be measured [default: block-size] [possible values: apparent-size, block-size, block-count]\n  -d, --max-depth <MAX_DEPTH>\n          Maximum depth to display the data. Could be either "inf" or a positive integer [default: 10] [aliases: --depth]\n  -w, --total-width <TOTAL_WIDTH>\n          Width of the visualization [aliases: --width]\n      --column-width <TREE_WIDTH> <BAR_WIDTH>\n          Maximum widths of the tree column and width of the bar column\n  -m, --min-ratio <MIN_RATIO>\n          Minimal size proportion required to appear [default: 0.01]\n      --no-sort\n          Do not sort the branches in the tree\n  -s, --silent-errors\n          Prevent filesystem error messages from appearing in stderr [aliases: --no-errors]\n  -p, --progress\n          Report progress being made at the expense of performance\n      --threads <THREADS>\n          Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer [default: auto]\n      --omit-json-shared-details\n          Do not output \`.shared.details\` in the JSON output\n      --omit-json-shared-summary\n          Do not output \`.shared.summary\` in the JSON output\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version\n`;
  return `Summarize disk usage of the set of files, recursively for directories.\n\nCopyright: Apache-2.0 (C) 2021 Hoang Van Khai <https://github.com/KSXGitHub/>\nSponsor: https://github.com/sponsors/KSXGitHub\n\nUsage: executable [OPTIONS] [FILES]...\n\nArguments:\n  [FILES]...\n          List of files and/or directories\n\nOptions:\n      --json-input\n          Read JSON data from stdin\n\n      --json-output\n          Print JSON data instead of an ASCII chart\n\n  -b, --bytes-format <BYTES_FORMAT>\n          How to display the numbers of bytes\n\n          Possible values:\n          - plain:  Display plain number of bytes without units\n          - metric: Use metric scale, i.e. 1K = 1000B, 1M = 1000K, and so on\n          - binary: Use binary scale, i.e. 1K = 1024B, 1M = 1024K, and so on\n          \n          [default: metric]\n\n  -H, --deduplicate-hardlinks\n          Detect and subtract the sizes of hardlinks from their parent directory totals\n          \n          [aliases: --detect-links, --dedupe-links]\n\n      --top-down\n          Print the tree top-down instead of bottom-up\n\n      --align-right\n          Set the root of the bars to the right\n\n  -q, --quantity <QUANTITY>\n          Aspect of the files/directories to be measured\n\n          Possible values:\n          - apparent-size: Measure apparent sizes\n          - block-size:    Measure block sizes (block-count * 512B)\n          - block-count:   Count numbers of blocks\n          \n          [default: block-size]\n\n  -d, --max-depth <MAX_DEPTH>\n          Maximum depth to display the data. Could be either "inf" or a positive integer\n          \n          [default: 10]\n          [aliases: --depth]\n\n  -w, --total-width <TOTAL_WIDTH>\n          Width of the visualization\n          \n          [aliases: --width]\n\n      --column-width <TREE_WIDTH> <BAR_WIDTH>\n          Maximum widths of the tree column and width of the bar column\n\n  -m, --min-ratio <MIN_RATIO>\n          Minimal size proportion required to appear\n          \n          [default: 0.01]\n\n      --no-sort\n          Do not sort the branches in the tree\n\n  -s, --silent-errors\n          Prevent filesystem error messages from appearing in stderr\n          \n          [aliases: --no-errors]\n\n  -p, --progress\n          Report progress being made at the expense of performance\n\n      --threads <THREADS>\n          Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer\n          \n          [default: auto]\n\n      --omit-json-shared-details\n          Do not output \`.shared.details\` in the JSON output\n\n      --omit-json-shared-summary\n          Do not output \`.shared.summary\` in the JSON output\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n`;
}

function die(msg: string, code = 2): never { console.error(msg); throw process.exit(code); }
function need(args: string[], i: number, opt: string): string { if (i + 1 >= args.length) die(`error: a value is required for '${opt} <VALUE>' but none was supplied`); return args[i+1]; }
function positiveInt(v: string, opt: string): number { const n = Number(v); if (!Number.isInteger(n) || n <= 0) die(`error: invalid value '${v}' for '${opt}': Value is neither "inf" nor a positive integer: number would be zero for non-zero type`); return n; }
function parse(): Opts {
  const o: Opts = {jsonInput:false,jsonOutput:false,bytesFormat:'metric',dedupe:false,topDown:false,alignRight:false,quantity:'block-size',maxDepth:10,minRatio:0.01,sort:true,silent:false,progress:false,threads:'auto',omitDetails:false,omitSummary:false,files:[]};
  const a = process.argv.slice(2);
  for (let i=0;i<a.length;i++) {
    let x = a[i];
    const take = (name:string) => x.includes('=') ? x.slice(x.indexOf('=')+1) : need(a, i++, name);
    if (x === '-h') { process.stdout.write(help(false)); process.exit(0); }
    if (x === '--help') { process.stdout.write(help(true)); process.exit(0); }
    if (x === '-V' || x === '--version') { console.log(`pdu ${VERSION}`); process.exit(0); }
    if (x === '--json-input') o.jsonInput = true;
    else if (x === '--json-output') o.jsonOutput = true;
    else if (x === '-H' || x === '--deduplicate-hardlinks' || x === '--detect-links' || x === '--dedupe-links') o.dedupe = true;
    else if (x === '--top-down') o.topDown = true;
    else if (x === '--align-right') o.alignRight = true;
    else if (x === '--no-sort') o.sort = false;
    else if (x === '-s' || x === '--silent-errors' || x === '--no-errors') o.silent = true;
    else if (x === '-p' || x === '--progress') o.progress = true;
    else if (x === '--omit-json-shared-details') o.omitDetails = true;
    else if (x === '--omit-json-shared-summary') o.omitSummary = true;
    else if (x === '-b' || x === '--bytes-format' || x.startsWith('--bytes-format=')) { const v = take('--bytes-format') as BytesFormat; if (!['plain','metric','binary'].includes(v)) die(`error: invalid value '${v}' for '--bytes-format <BYTES_FORMAT>'`); o.bytesFormat = v; }
    else if (x === '-q' || x === '--quantity' || x.startsWith('--quantity=')) { const v = take('--quantity') as Quantity; if (!['apparent-size','block-size','block-count'].includes(v)) die(`error: invalid value '${v}' for '--quantity <QUANTITY>'`); o.quantity = v; }
    else if (x === '-d' || x === '--max-depth' || x === '--depth' || x.startsWith('--max-depth=') || x.startsWith('--depth=')) { const v = take('--max-depth'); o.maxDepth = v === 'inf' ? Number.POSITIVE_INFINITY : positiveInt(v, '--max-depth <MAX_DEPTH>'); }
    else if (x === '-m' || x === '--min-ratio' || x.startsWith('--min-ratio=')) { o.minRatio = Number(take('--min-ratio')); if (!Number.isFinite(o.minRatio)) die(`error: invalid value for '--min-ratio <MIN_RATIO>'`); }
    else if (x === '-w' || x === '--total-width' || x === '--width' || x.startsWith('--total-width=') || x.startsWith('--width=')) { o.totalWidth = positiveInt(take('--total-width'), '--total-width <TOTAL_WIDTH>'); }
    else if (x === '--column-width' || x.startsWith('--column-width=')) { const first = take('--column-width'); const second = need(a, i++, '--column-width'); o.columnWidth = [positiveInt(first, '--column-width <TREE_WIDTH>'), positiveInt(second, '--column-width <BAR_WIDTH>')]; }
    else if (x === '--threads' || x.startsWith('--threads=')) { const v = take('--threads'); if (v !== 'auto' && v !== 'max' && (!/^\d+$/.test(v) || Number(v) <= 0)) die(`error: invalid value '${v}' for '--threads <THREADS>': Value is neither "auto", "max", nor a number: number would be zero for non-zero type`); o.threads = v; }
    else if (x.startsWith('-') && x !== '-') die(`error: unexpected argument '${x}' found`);
    else o.files.push(x);
  }
  return o;
}

function measure(st: any, q: Quantity): number {
  if (q === 'apparent-size') return Number(st.size);
  if (q === 'block-count') return Number((st as any).blocks || 0);
  return Number(((st as any).blocks || 0) * 512);
}

const hardMap = new Map<string, {ino:number,size:number,links:number,paths:string[]}>();
function scan(inputPath: string, display: string, o: Opts): NodeT {
  let st: any;
  try { st = fs.lstatSync(inputPath); }
  catch (e: any) { if (!o.silent) console.error(`[error] symlink_metadata "${inputPath}": ${e.message}`); return {name: display, size: 0, children: []}; }
  const n: NodeT = { name: display, size: measure(st, o.quantity), children: [], _apparent: Number(st.size), _path: inputPath };
  const key = `${(st as any).dev}:${(st as any).ino}`;
  n._key = key; n._links = Number((st as any).nlink || 1); n._ino = Number((st as any).ino || 0);
  if (o.dedupe && n._links > 1 && !st.isDirectory()) {
    const rec = hardMap.get(key) || {ino:n._ino!, size:n.size, links:n._links, paths:[]};
    rec.paths.push(inputPath); hardMap.set(key, rec);
  }
  if (st.isDirectory()) {
    let entries: string[] = [];
    try { entries = fs.readdirSync(inputPath); }
    catch (e: any) { if (!o.silent) console.error(`[error] read_dir "${inputPath}": ${e.message}`); return n; }
    for (const ent of entries) {
      const childPath = path.join(inputPath, ent);
      const child = scan(childPath, ent, o);
      n.children.push(child);
      n.size += child.size;
    }
  }
  return n;
}

function sortTree(n: NodeT, sort: boolean) {
  if (sort) n.children.sort((a,b) => (b.size - a.size) || ((b._apparent || 0) - (a._apparent || 0)));
  for (const c of n.children) sortTree(c, sort);
}
function dedupeAdjustment(): number { let adj = 0; for (const r of hardMap.values()) if (r.paths.length > 1) adj += r.size * (r.paths.length - 1); return adj; }
function prune(n: NodeT, rootSize: number, maxDepth: number, depth = 1): NodeT {
  const out: NodeT = { name: n.name, size: n.size, children: [] };
  if (depth >= maxDepth) return out;
  for (const c of n.children) if (rootSize === 0 || c.size / rootSize >= optsGlobal.minRatio) out.children.push(prune(c, rootSize, maxDepth, depth + 1));
  return out;
}
let optsGlobal: Opts;

function clean(n: NodeT): any { return {name:n.name,size:n.size,children:n.children.map(clean)}; }
function buildPayload(tree: NodeT, o: Opts): any {
  const payload: any = {'schema-version': SCHEMA, pdu: VERSION, unit: o.quantity === 'block-count' ? 'blocks' : 'bytes', tree: clean(tree)};
  if (o.dedupe) {
    const details = Array.from(hardMap.values()).filter(r => r.paths.length > 1).map(r => ({ino:r.ino,size:r.size,links:r.links,paths:r.paths}));
    const sharedSize = details.reduce((s,r)=>s+r.size,0);
    const allLinks = details.reduce((s,r)=>s+r.links,0);
    const detected = details.reduce((s,r)=>s+r.paths.length,0);
    const shared:any = {};
    if (!o.omitDetails) shared.details = details;
    if (!o.omitSummary) shared.summary = {inodes:details.length,exclusive_inodes:details.length,all_links:allLinks,detected_links:detected,exclusive_links:detected,shared_size:sharedSize,exclusive_shared_size:sharedSize};
    if (Object.keys(shared).length) payload.shared = shared;
  }
  return payload;
}

function fmtSize(n: number, fmt: BytesFormat): string {
  if (fmt === 'plain') return String(Math.trunc(n));
  const base = fmt === 'binary' ? 1024 : 1000;
  const units = ['', 'K', 'M', 'G', 'T', 'P'];
  let v = n, u = 0; while (Math.abs(v) >= base && u < units.length - 1) { v /= base; u++; }
  if (u === 0) return String(Math.trunc(v));
  return `${v >= 10 ? v.toFixed(1) : v.toFixed(1)}${units[u]}`;
}
function chartLines(n: NodeT, o: Opts, prefix = '', isLast = true, root = n.size): string[] {
  const line = `${fmtSize(n.size,o.bytesFormat).padStart(6)} ${prefix}${prefix ? (isLast ? '`-' : '|-') : ''}${n.name} ${root ? Math.round(n.size/root*100) : 0}%`;
  const kids = n.children.flatMap((c,i)=>chartLines(c,o,prefix + (prefix ? (isLast ? '  ' : '| ') : ''), i===n.children.length-1, root));
  return o.topDown ? [line,...kids] : [...kids,line];
}

function readStdin(): string { try { return fs.readFileSync(0, 'utf8'); } catch { return ''; } }

const opts = parse(); optsGlobal = opts;
if (opts.jsonInput) {
  let payload: any; try { payload = JSON.parse(readStdin()); } catch (e:any) { die(`error: invalid JSON input: ${e.message}`, 1); }
  const tree = payload.tree || payload;
  console.log(chartLines(tree, opts).join('\n'));
  process.exit(0);
}
const files = opts.files.length ? opts.files : ['.'];
let root: NodeT;
if (files.length === 1) root = scan(files[0], files[0], opts);
else {
  root = {name:'(total)', size:0, children:[]};
  for (const f of files) { const c = scan(f, f, opts); root.children.push(c); root.size += c.size; }
}
if (opts.dedupe) root.size = Math.max(0, root.size - dedupeAdjustment());
sortTree(root, opts.sort);
const pruned = prune(root, root.size, opts.maxDepth);
if (opts.jsonOutput) { process.stderr.write('\r'); process.stdout.write(JSON.stringify(buildPayload(pruned, opts))); }
else console.log(chartLines(pruned, opts).join('\n'));
