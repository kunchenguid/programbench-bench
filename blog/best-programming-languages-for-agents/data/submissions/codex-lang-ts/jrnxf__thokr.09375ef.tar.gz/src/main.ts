declare const require: any;
declare const process: any;
declare const __dirname: string;

const fs = require('fs');
const path = require('path');
const os = require('os');

const VERSION = 'thokr 0.4.1';
const ABOUT = 'sleek typing tui with visualized results and historical logging';
const VALID_LANGS = ['english', 'english1k', 'english10k'];

const WORDS = `the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take person into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us is are was were been has had did shall should may might must many much more very every those people man woman child world school state family student group country problem hand part place case week company system program question work government number night point home water room mother area money story fact month lot right study book eye job word business issue side kind head house service friend father power hour game line end member law car city community name president team minute idea kid body information back parent face others level office door health art war history party result change morning reason research girl guy moment air teacher force education foot boy age policy process music market sense nation plan college interest death experience effect class control care field development role effort rate heart drug show leader light voice wife police mind mind price report decision son view relationship town road arm difference value building action model season society tax director position player record paper space ground form event official matter center couple site project activity star table need court oil situation cost industry figure street image phone data picture practice piece land product doctor wall patient worker news test movie north love support technology step baby computer type attention film tree source organization hair look century evidence window culture chance brother energy period course summer plant opportunity term letter condition choice place single rule daughter administration south husband congress floor campaign material population economy medical hospital church close thousand risk current fire future wrong involve defense anyone increase security bank myself certainly west sport board seek per subject officer private rest behavior deal performance fight throw top quickly past goal second bed order author fill represent focus foreign drop plan blood upon agency push nature color recently store reduce sound note fine before near movement page enter share common poor natural race concern series significant similar hot language each usually response dead rise animal factor decade article shoot east save seven artist away scene stock career despite central eight thus treatment beyond happy exactly protect approach lie size dog fund serious occur media ready sign thought list individual simple quality pressure accept answer hard resource identify left meeting determine prepare disease whatever success argue cup particularly amount ability staff recognize growth loss degree wonder attack herself region television box tv training pretty trade deal election everybody physical lay general feeling standard bill message fail outside arrive analysis benefit sex forward lawyer present section environmental glass skill sister pm professor operation financial crime stage ok compare authority miss design sort act ten knowledge gun station blue strategy clearly discuss indeed truth song example democratic check environment leg dark public various rather laugh guess executive set study prove hang entire rock design enough forget since claim note remove manager help close sound enjoy network legal religious cold form final main science green memory card above seat cell establish nice trial expert that spring firm democrat radio visit management avoid imagine tonight huge ball finish yourself theory impact respond statement maintain charge popular traditional onto reveal direction weapon employee cultural contain peace head control base pain apply play measure wide shake fly interview manage chair fish particular camera structure politics perform bit weight suddenly discover candidate production treat trip evening affect inside conference unit best style adult worry range mention rather far deep front edge individual specific writer trouble necessary throughout challenge fear shoulder institution middle sea dream bar beautiful property instead improve stuff detail method somebody magazine hotel soldier reflect heavy sexual cause bag heat fall marriage tough sing surface purpose exist pattern whom skin agent owner machine gas down ahead generation commercial address cancer test item reality coach Mrs yard beat violence total tend investment discussion finger garden notice collection modern task partner positive civil kitchen consumer shot budget wish painting scientist safe agreement capital mouth nor victim newspaper threat responsibility smile attorney score account interesting break audience rich dinner vote western relate travel debate prevent citizen majority none born admit senior assume wind key professional mission fast alone customer suffer speech successful option participant southern fresh eventually forest video global senate reform access restaurant judge publish relation release own bird opinion credit critical corner concerned recall version stare safety effective neighborhood original act troop income directly hurt species immediately track basic strike hope sky freedom absolutely plane nobody achieve object attitude labor refer concept client powerful perfect nine therefore conduct announce conversation examine touch please attend completely variety sleep turn involved investigation nuclear researcher press conflict spirit replace British encourage argument by once camp brain feature afternoon AM weekend dozen possibility along insurance department battle beginning date generally African sorry crisis complete fan stick define easily through hole element vision status normal Chinese ship solution stone slowly scale bit university introduce driver attempt park spot lack ice boat drink sun front distance wood handle truck return mountain survey supposed tradition winter village Soviet refuse sales roll communication screen gain resident hide gold club farm potential European presence independent district shape reader Ms contract crowd Christian express apartment willing strength previous band obviously horse interested target prison ride guard terms demand reporter deliver text tool wild vehicle observe flight facility understanding average emerge advantage quick leadership earn pound basis bright operate guest sample contribute tiny block protection settle feed collect additional while highly identity title mostly lesson faith river promote living count unless marry tomorrow technique path ear shop folk principle survive lift border competition jump gather limit fit cry equipment worth associate critic warm aspect insist failure annual French Christmas comment responsible affair procedure regular spread chairman baseball soft ignore egg belief demonstrate anybody murder gift religion review editor engagement coffee document speed cross influence anyway threaten commit female youth wave move afraid quarter background native broad wonderful deny apparently slightly reaction twice suit perspective growing blow construction intelligence destroy cook connection burn shoe grade context committee hey mistake location clothes Indian quiet dress promise aware neighbor complete drive function bone active extend chief average combine wine below cool voter mean demand learning bus hell dangerous remind moral United category relatively victory academic Internet healthy negative following historical medicine tour depend photo finding grab direct classroom contact justice participate daily fair pair famous exercise knee flower tape hire familiar appropriate supply fully actor birth search tie democracy eastern primary yesterday circle device progress bottom island exchange clean studio train lady colleague application neck lean damage plastic tall plate hate otherwise writing male alive expression football intend chicken army abuse theater shut map extra session danger welcome domestic lots literature rain desire assessment injury respect northern nod paint fuel leaf direct dry Russian instruction fight pool climb sweet lead engine fourth salt expand importance metal fat ticket software disappear corporate strange lip reading urban mental increasingly lunch educational somewhere farmer sugar planet favorite explore obtain enemy greatest complex surround athlete invite repeat carefully soul scientific impossible panel meaning mom married instrument predict weather presidential emotional commitment Supreme bear pocket thin temperature surprise poll proposal consequence half breath sight cover balance adopt minority straight connect works teaching belong aid advice okay photograph empty regional trail novel code somehow organize jury breast Iraqi human acknowledge theme storm union desk thanks fruit expensive yellow conclusion prime shadow struggle conclude analyst dance limit like regulation being last ring largely shift revenue mark locate county appearance package difficulty bridge recommend obvious train basically e-mail generate anymore propose thinking possibly trend visitor loan currently comfortable investor profit angry crew deep accident male meal hearing traffic muscle notion capture prefer truly earth Japanese chest search thick cash museum beauty emergency unique internal ethnic link stress content select root nose declare outside appreciate actual bottle hardly setting launch dress file sick outcome ad defend matter judge duty sheet ought ensure Catholic extremely extent component mix long slow contrast zone wake airport chief brown shirt pilot warn ultimately cat contribution capacity ourselves estate guide circumstance snow English politician steal pursue slip percentage meat funny neither soil surgery correct Jewish blame estimate due basketball late golf investigate crazy significantly chain address branch combination just frequently governor relief user dad kick part manner ancient silence rating golden motion German gender solve fee landscape used bowl equal long official forth frame typical except conservative eliminate host hall trust ocean score row producer afford meanwhile regime division confirm fix appeal mirror tooth smart length entirely rely topic complain variable telephone perception attract confidence bedroom secret debt rare his tank nurse coverage opposition aside anywhere bond file pleasure master era requirement check stand fun expectation wing separate now clear struggle mean somewhat pour stir judgment clean except beer English reference tear doubt grant seriously minister totally hero industrial cloud stretch winner volume travel seed surprised rest fashion pepper separate busy intervention copy tip cheap aim cite welfare vegetable gray dish beach improvement everywhere opening overall divide initial terrible oppose contemporary route multiple essential league criminal careful core upper rush necessarily specifically tired employ holiday vast resolution household fewer abortion apart witness match barely sector representative lack beneath beside black incident limited proud flow faculty increased waste merely mass emphasize experiment definitely bomb enormous tone liberal massive engineer wheel female decline invest promise cable towards expose rural AIDS Jew narrow cream secretary gate solid hill typically noise grass unfortunately hat legislation succeed either celebrate achievement fishing drink accuse useful land secret reject talent taste characteristic milk escape cast sentence unusual closely convince height physician assess plenty ride virtually first addition sharp creative lower behind approve explanation outside gay campus proper live guilty living acquire compete technical plus mind potential immigrant weak illegal hi alternative interaction column personality signal curriculum honor passenger assistance forever fun regard Israeli association twenty knock wrap lab offer display criticism asset depression spiritual musical journalist prayer suspect scholar warning climate cheese observation childhood payment sir permit cigarette definition priority bread creation graduate request emotion universe gap excellent deeply prosecutor mark green lucky drag airline library agenda recover factory selection primarily roof unable expense initiative diet arrest funding therapy wash schedule sad brief housing post purchase existing dark steel regarding shout remaining visual fairly chip violent silent suppose self bike tea perceive comparison settlement layer planning far description later slow slide widely wedding inform portion territory immediate opponent abandon link mass lake transform tension display leading bother consist alcohol enable bend saving gain desert shall error release cop Arab double walk sand Spanish rule hit print preserve passage formal transition existence album participation arrange atmosphere joint reply cycle opposite lock whole deserve consistent resistance discovery tear exposure pose stream sale trust benefit pot grand mine hello coalition tale knife resolve racial phase present joke coat Mexican symptom manufacturer philosophy potato foundation quote online pass negotiation good urge occasion dust breathe elect investigator jacket glad ordinary reduction rarely shift pack suicide numerous touch substance discipline elsewhere iron practical moreover passion volunteer implement essentially gene enforcement vs sauce independence marketing priest amazing intense advance employer shock inspire adjust retire sure visible kiss illness cap habit competitive juice congressional involvement dominate previously whenever transfer analyze another attach for disaster parking prospect boss complaint championship coach exercise fundamental severe enhance mystery impose poverty other entry fat spending king evaluate symbol still trade maker mood accomplish emphasis illustrate boot monitor Asian entertainment bean evaluation creature commander digital arrangement concentrate total usual anger psychological heavily peak approximately increasing disorder missile equally vary wire round distribution transportation holy ring twin command commission interpretation breakfast stop strongly engineering luck so-called constant race clinic veteran smell tablespoon capable nervous tourist toss crucial bury pray tomato exception butter deficit bathroom objective block electronic ally journey reputation mixture surely tower smoke confront pure glance dimension toy prisoner fellow smooth nearby peer designer personnel shape educator relative immigration belt teaspoon birthday implication perfectly coast supporter accompany silver teenage recognition retirement flag recovery whisper watch gentleman corn moon inner junior rather throat salary swing observer due straight publication pretty crop dig strike permanent plant phenomenon anxiety unlike wet literally resist convention embrace supply assist exhibition construct viewer pan accommodation reporter brown display consultant administrator reminder newspaper lawyer properly lake repeat record troop enhance trait length absolute considerable assignment wood gap demonstrate tax length involve secretary consume copy trace spread repeat rather accurate stone brown operate collective bear tea form random test crisp typed clear speed practice quick`.split(/\s+/);

function binName(): string {
  const b = path.basename(process.argv[1] || 'executable');
  return b === 'main.js' ? 'executable' : b;
}

function helpText(name = binName()): string {
  return `${VERSION}\n${ABOUT}\n\nUSAGE:\n    ${name} [OPTIONS]\n\nOPTIONS:\n    -f, --full-sentences <NUMBER_OF_SENTENCES>\n            number of sentences to use in test\n\n    -h, --help\n            Print help information\n\n    -l, --supported-language <SUPPORTED_LANGUAGE>\n            language to pull words from [default: english] [possible values: english, english1k,\n            english10k]\n\n    -p, --prompt <PROMPT>\n            custom prompt to use\n\n    -s, --number-of-secs <NUMBER_OF_SECS>\n            number of seconds to run test\n\n    -V, --version\n            Print version information\n\n    -w, --number-of-words <NUMBER_OF_WORDS>\n            number of words to use in test [default: 15]\n`;
}

function err(msg: string, usage?: string): never {
  let text = `error: ${msg}\n`;
  if (usage) text += `\n${usage}\n\n`;
  else text += `\n`;
  text += `For more information try --help\n`;
  process.stderr.write(text);
  process.exit(2);
  throw new Error("unreachable");
}

function parseNum(opt: string, display: string, value: string): number {
  if (value.startsWith('-')) {
    err(`Found argument '${value}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply \`${value}\` as a value rather than a flag, use \`-- ${value}\``, `USAGE:\n    ${binName()} [OPTIONS]`);
  }
  if (!/^\d+$/.test(value)) err(`Invalid value "${value}" for '${opt} <${display}>': invalid digit found in string`);
  const n = Number(value);
  if (!Number.isSafeInteger(n)) err(`Invalid value "${value}" for '${opt} <${display}>': number too large to fit in target type`);
  return n;
}

interface Options { words: number; secs?: number; sentences?: number; lang: string; prompt?: string; }

function parseArgs(argv: string[]): Options | 'exit' {
  const opts: Options = { words: 15, lang: 'english' };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '-h' || a === '--help') { process.stdout.write(helpText()); return 'exit'; }
    if (a === '-V' || a === '--version') { process.stdout.write(`${VERSION}\n`); return 'exit'; }
    if (a === '--') continue;

    const readVal = (long: string, meta: string, possible = false): string => {
      if (i + 1 >= argv.length) {
        let m = `The argument '${long} <${meta}>' requires a value but none was supplied`;
        if (possible) m += `\n\t[possible values: english, english1k, english10k]`;
        err(m, `USAGE:\n    ${binName()} [OPTIONS]`);
      }
      return argv[++i];
    };

    if (a.startsWith('--number-of-words=')) { opts.words = parseNum('--number-of-words', 'NUMBER_OF_WORDS', a.slice(18)); continue; }
    if (a === '-w' || a === '--number-of-words') { opts.words = parseNum('--number-of-words', 'NUMBER_OF_WORDS', readVal('--number-of-words', 'NUMBER_OF_WORDS')); continue; }
    if (a.startsWith('-w') && a.length > 2) { opts.words = parseNum('--number-of-words', 'NUMBER_OF_WORDS', a.slice(2)); continue; }

    if (a.startsWith('--number-of-secs=')) { opts.secs = parseNum('--number-of-secs', 'NUMBER_OF_SECS', a.slice(17)); continue; }
    if (a === '-s' || a === '--number-of-secs') { opts.secs = parseNum('--number-of-secs', 'NUMBER_OF_SECS', readVal('--number-of-secs', 'NUMBER_OF_SECS')); continue; }
    if (a.startsWith('-s') && a.length > 2) { opts.secs = parseNum('--number-of-secs', 'NUMBER_OF_SECS', a.slice(2)); continue; }

    if (a.startsWith('--full-sentences=')) { opts.sentences = parseNum('--full-sentences', 'NUMBER_OF_SENTENCES', a.slice(17)); continue; }
    if (a === '-f' || a === '--full-sentences') { opts.sentences = parseNum('--full-sentences', 'NUMBER_OF_SENTENCES', readVal('--full-sentences', 'NUMBER_OF_SENTENCES')); continue; }
    if (a.startsWith('-f') && a.length > 2) { opts.sentences = parseNum('--full-sentences', 'NUMBER_OF_SENTENCES', a.slice(2)); continue; }

    if (a.startsWith('--prompt=')) { opts.prompt = a.slice(9); continue; }
    if (a === '-p' || a === '--prompt') { opts.prompt = readVal('--prompt', 'PROMPT'); continue; }
    if (a.startsWith('-p') && a.length > 2) { opts.prompt = a.slice(2); continue; }

    if (a.startsWith('--supported-language=')) { opts.lang = a.slice(21); validateLang(opts.lang); continue; }
    if (a === '-l' || a === '--supported-language') { opts.lang = readVal('--supported-language', 'SUPPORTED_LANGUAGE', true); validateLang(opts.lang); continue; }
    if (a.startsWith('-l') && a.length > 2) { opts.lang = a.slice(2); validateLang(opts.lang); continue; }

    err(`Found argument '${a}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply \`${a}\` as a value rather than a flag, use \`-- ${a}\``, `USAGE:\n    ${binName()} [OPTIONS]`);
  }
  return opts;
}

function validateLang(v: string) {
  if (!VALID_LANGS.includes(v)) {
    err(`"${v}" isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'\n\t[possible values: english, english1k, english10k]`, `USAGE:\n    ${binName()} --supported-language <SUPPORTED_LANGUAGE>`);
  }
}

function runtimeTtyError(): never {
  err('stdin must be a tty', 'USAGE:\n    thokr [OPTIONS]');
}

function makePrompt(opts: Options): string {
  if (opts.prompt !== undefined) return opts.prompt;
  if (opts.sentences !== undefined) {
    const s: string[] = [];
    for (let i = 0; i < opts.sentences; i++) {
      const count = 7 + (i % 6);
      const words = pickWords(count);
      words[0] = words[0].charAt(0).toUpperCase() + words[0].slice(1);
      s.push(words.join(' ') + '.');
    }
    return s.join(' ');
  }
  return pickWords(opts.words).join(' ');
}

function pickWords(n: number): string[] {
  const out: string[] = [];
  for (let i = 0; i < n; i++) out.push(WORDS[Math.floor(Math.random() * WORDS.length)] || 'the');
  return out;
}

function render(prompt: string, typed: string, started: number, secs?: number) {
  const elapsed = started ? (Date.now() - started) / 1000 : 0;
  const remaining = secs ? Math.max(0, Math.ceil(secs - elapsed)) : undefined;
  process.stdout.write('\x1b[2J\x1b[H');
  process.stdout.write(`${VERSION}\n\n`);
  process.stdout.write(prompt + '\n\n');
  process.stdout.write(typed + '\n\n');
  if (remaining !== undefined) process.stdout.write(`time: ${remaining}s\n`);
}

function finish(prompt: string, typed: string, started: number) {
  const elapsed = Math.max((Date.now() - started) / 1000, 0.001);
  let correct = 0;
  for (let i = 0; i < typed.length; i++) if (typed[i] === prompt[i]) correct++;
  const accuracy = typed.length ? Math.round((correct / typed.length) * 100) : 0;
  const wpm = Math.round((correct / 5) / (elapsed / 60));
  process.stdout.write('\x1b[2J\x1b[H');
  process.stdout.write(`wpm: ${wpm}\naccuracy: ${accuracy}%\ntime: ${elapsed.toFixed(1)}s\n`);
  appendLog(wpm, accuracy, elapsed, prompt.length, typed.length);
}

function appendLog(wpm: number, accuracy: number, elapsed: number, promptLen: number, typedLen: number) {
  try {
    const base = process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config');
    const dir = path.join(base, 'thokr');
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, 'log.csv');
    if (!fs.existsSync(file)) fs.writeFileSync(file, 'timestamp,wpm,accuracy,seconds,prompt_length,typed_length\n');
    fs.appendFileSync(file, `${new Date().toISOString()},${wpm},${accuracy},${elapsed.toFixed(3)},${promptLen},${typedLen}\n`);
  } catch (_) {}
}

function run(opts: Options) {
  if (!process.stdin.isTTY) runtimeTtyError();
  const prompt = makePrompt(opts);
  let typed = '';
  let started = Date.now();
  if (process.stdin.setRawMode) process.stdin.setRawMode(true);
  process.stdin.resume();
  render(prompt, typed, started, opts.secs);
  const timer = opts.secs ? setInterval(() => {
    render(prompt, typed, started, opts.secs);
    if ((Date.now() - started) / 1000 >= (opts.secs || 0)) done();
  }, 200) : null;
  function done() {
    if (timer) clearInterval(timer);
    if (process.stdin.setRawMode) process.stdin.setRawMode(false);
    process.stdin.pause();
    finish(prompt, typed, started);
    process.exit(0);
  }
  process.stdin.on('data', (buf: any) => {
    const s = buf.toString('utf8');
    if (s === '\u0003' || s === '\u001b') process.exit(0);
    if (s === '\u001b[D') { typed = ''; started = Date.now(); render(prompt, typed, started, opts.secs); return; }
    if (s === '\u001b[C' && opts.prompt === undefined) { typed = ''; started = Date.now(); render(makePrompt(opts), typed, started, opts.secs); return; }
    for (const ch of s) {
      if (ch === '\r' || ch === '\n') continue;
      if (ch === '\b' || ch === '\x7f') typed = typed.slice(0, -1);
      else if (ch >= ' ' && ch !== '\x7f') typed += ch;
    }
    render(prompt, typed, started, opts.secs);
    if (typed.length >= prompt.length) done();
  });
}

const parsed = parseArgs(process.argv.slice(2));
if (parsed !== 'exit') run(parsed);
