declare const require: any;
declare const process: any;

const fs = require("fs");
const os = require("os");
const path = require("path");

const VERSION = "htop 3.5.0-dev-878e0ce";

const HELP = `${VERSION}
(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.
Released under the GNU GPLv2+.

-C --no-color                   Use a monochrome color scheme
-d --delay=DELAY                Set the delay between updates, in tenths of seconds
-F --filter=FILTER              Show only the commands matching the given filter
   --no-function-bar             Hide the function bar
-h --help                       Print this help screen
-H --highlight-changes[=DELAY]  Highlight new and old processes
-M --no-mouse                   Disable the mouse
   --no-meters                  Hide meters
-n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates
-p --pid=PID[,PID,PID...]       Show only the given PIDs
   --readonly                   Disable all system and process changing features
-s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)
-t --tree                       Show the tree view (can be combined with -s)
-u --user[=USERNAME]            Show only processes for a given user (or $USER)
-U --no-unicode                 Do not use unicode but plain ASCII
-V --version                    Print version info

Press F1 inside htop for online help.
See 'man htop' for more information.
`;

const SORT_HELP = `                PID Process/thread ID
            Command Command line (insert as last column only)
              STATE Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)
               PPID Parent process ID
               PGRP Process group ID
            SESSION Process's session ID
                TTY Controlling terminal
              TPGID Process ID of the fg process group of the controlling terminal
             MINFLT Number of minor faults which have not required loading a memory page from disk
            CMINFLT Children processes' minor faults
             MAJFLT Number of major faults which have required loading a memory page from disk
            CMAJFLT Children processes' major faults
              UTIME User CPU time - time the process spent executing in user mode
              STIME System CPU time - time the kernel spent running system calls for this process
             CUTIME Children processes' user CPU time
             CSTIME Children processes' system CPU time
           PRIORITY Kernel's internal priority for the process
               NICE Nice value (the higher the value, the more it lets other processes take priority)
          STARTTIME Time the process was started
          PROCESSOR Id of the CPU the process last executed on
             M_VIRT Total program size in virtual memory
         M_RESIDENT Resident set size, size of the text and data sections, plus stack usage
            M_SHARE Size of the process's shared pages
              M_TRS Size of the .text segment of the process (CODE)
              M_DRS Size of the .data segment plus stack usage of the process (DATA)
              M_LRS The library size of the process (calculated from memory maps)
             ST_UID User ID of the process owner
        PERCENT_CPU Percentage of the CPU time the process used in the last sampling
        PERCENT_MEM Percentage of the memory the process is using, based on resident memory size
               USER Username of the process owner (or user ID if name cannot be determined)
               TIME Total time the process has spent in user and system time
               NLWP Number of threads in the process
               TGID Thread group ID (i.e. process ID)
   PERCENT_NORM_CPU Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)
            ELAPSED Time since the process was started
    SCHEDULERPOLICY Current scheduling policy of the process
              RCHAR Number of bytes the process has read
              WCHAR Number of bytes the process has written
              SYSCR Number of read(2) syscalls for the process
              SYSCW Number of write(2) syscalls for the process
             RBYTES Bytes of read(2) I/O for the process
             WBYTES Bytes of write(2) I/O for the process
             CNCLWB Bytes of cancelled write(2) I/O
       IO_READ_RATE The I/O rate of read(2) in bytes per second for the process
      IO_WRITE_RATE The I/O rate of write(2) in bytes per second for the process
            IO_RATE Total I/O rate in bytes per second
             CGROUP Which cgroup the process is in
                OOM OOM (Out-of-Memory) killer score
        IO_PRIORITY I/O priority
              M_PSS proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it
             M_SWAP Size of the process's swapped pages
            M_PSSWP shows proportional swap share of this mapping, unlike "Swap", this does not take into account swapped out page of underlying shmem objects
               CTXT Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)
            SECATTR Security attribute of the process (e.g. SELinux or AppArmor)
               COMM comm string of the process from /proc/[pid]/comm
                EXE Basename of exe of the process from /proc/[pid]/exe
                CWD The current working directory of the process
       AUTOGROUP_ID The autogroup identifier of the process
     AUTOGROUP_NICE Nice value (the higher the value, the more other processes take priority) associated with the process autogroup
            CCGROUP Which cgroup the process is in (condensed to essentials)
          CONTAINER Name of the container the process is in (guessed by heuristics)
             M_PRIV The private memory size of the process - resident set size minus shared memory
           GPU_TIME Total GPU time
        GPU_PERCENT Percentage of the GPU time the process used in the last sampling
        ISCONTAINER Whether the process is running inside a child container
`;

const VALID_COLUMNS = new Set(SORT_HELP.split("\n").map((line: string) => line.trim().split(/\s+/)[0]).filter(Boolean));
VALID_COLUMNS.add("Command");

type Opts = {
  noMeters: boolean;
  noFunctionBar: boolean;
  readonly: boolean;
  tree: boolean;
  filter?: string;
  user?: string;
  pids?: Set<number>;
  sortKey: string;
  maxIterations: number;
};

function die(msg: string) {
  process.stderr.write(msg + "\n");
  process.exit(1);
}

function needArg(args: string[], i: number, opt: string): string {
  if (i + 1 >= args.length) {
    const flag = opt.length === 2 ? `option requires an argument -- '${opt[1]}'` : `option '${opt}' requires an argument`;
    die(`./executable: ${flag}`);
  }
  return args[i + 1];
}

function parseNumber(value: string, what: string): number {
  if (!/^-?\d+$/.test(value)) die(`Error: invalid ${what} "${value}".`);
  return parseInt(value, 10);
}

function parseArgs(args: string[]): Opts {
  const opts: Opts = { noMeters: false, noFunctionBar: false, readonly: false, tree: false, sortKey: "PERCENT_CPU", maxIterations: 1 };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") {
      if (i + 1 < args.length) die(`Error: unsupported non-option ARGV-elements: ${args.slice(i + 1).join(" ")}`);
      break;
    }
    if (/^-[A-Za-z]/.test(a) && !a.startsWith("--") && a.length > 2) {
      const consumed = handleShortCluster(a.slice(1), args, i, opts);
      i += consumed;
      continue;
    }
    if (a === "-h" || a === "--help") {
      process.stdout.write(HELP);
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      process.stdout.write(VERSION + "\n");
      process.exit(0);
    } else if (a === "-C" || a === "--no-color" || a === "--no-colour" || a === "-U" || a === "--no-unicode" || a === "-M" || a === "--no-mouse") {
      continue;
    } else if (a === "-t" || a === "--tree") {
      opts.tree = true;
    } else if (a === "--no-meters") {
      opts.noMeters = true;
    } else if (a === "--no-function-bar") {
      opts.noFunctionBar = true;
    } else if (a === "--readonly") {
      opts.readonly = true;
    } else if (a === "-d" || a === "--delay") {
      const v = needArg(args, i, a); i++;
      parseNumber(v, "delay value");
    } else if (a.startsWith("--delay=")) {
      parseNumber(a.slice(8), "delay value");
    } else if (a === "-n" || a === "--max-iterations") {
      const v = needArg(args, i, a); i++;
      const n = parseNumber(v, "maximum iteration count");
      if (n <= 0) die("Error: maximum iteration count must be positive.");
      opts.maxIterations = n;
    } else if (a.startsWith("--max-iterations=")) {
      const n = parseNumber(a.slice(17), "maximum iteration count");
      if (n <= 0) die("Error: maximum iteration count must be positive.");
      opts.maxIterations = n;
    } else if (a === "-p" || a === "--pid") {
      const v = needArg(args, i, a); i++;
      opts.pids = parsePids(v);
    } else if (a.startsWith("--pid=")) {
      opts.pids = parsePids(a.slice(6));
    } else if (a === "-F" || a === "--filter") {
      opts.filter = needArg(args, i, a); i++;
    } else if (a.startsWith("--filter=")) {
      opts.filter = a.slice(9);
    } else if (a === "-s" || a === "--sort-key") {
      const v = needArg(args, i, a); i++;
      handleSortKey(v, opts);
    } else if (a.startsWith("--sort-key=")) {
      handleSortKey(a.slice(11), opts);
    } else if (a === "-u" || a === "--user") {
      const next = args[i + 1];
      if (next && !next.startsWith("-")) { opts.user = next; i++; } else opts.user = process.env.USER || "";
      validateUser(opts.user);
    } else if (a.startsWith("--user=")) {
      opts.user = a.slice(7);
      validateUser(opts.user);
    } else if (a === "-H" || a === "--highlight-changes") {
      continue;
    } else if (a.startsWith("--highlight-changes=")) {
      parseNumber(a.slice(20), "highlight delay value");
    } else if (a.startsWith("--")) {
      die(`./executable: unrecognized option '${a}'`);
    } else if (a.startsWith("-") && a.length > 1) {
      die(`./executable: invalid option -- '${a[1]}'`);
    } else {
      die(`Error: unsupported non-option ARGV-elements: ${a}`);
    }
  }
  return opts;
}

function handleShortCluster(cluster: string, args: string[], index: number, opts: Opts): number {
  let consumed = 0;
  for (let j = 0; j < cluster.length; j++) {
    const ch = cluster[j];
    const rest = cluster.slice(j + 1);
    if (ch === "h") {
      process.stdout.write(HELP);
      process.exit(0);
    } else if (ch === "V") {
      process.stdout.write(VERSION + "\n");
      process.exit(0);
    } else if (ch === "C" || ch === "U" || ch === "M" || ch === "H") {
      continue;
    } else if (ch === "t") {
      opts.tree = true;
    } else if (ch === "d") {
      const v = rest || needArg(args, index, "-d");
      if (!rest) consumed = 1;
      parseNumber(v, "delay value");
      return consumed;
    } else if (ch === "n") {
      const v = rest || needArg(args, index, "-n");
      if (!rest) consumed = 1;
      const n = parseNumber(v, "maximum iteration count");
      if (n <= 0) die("Error: maximum iteration count must be positive.");
      opts.maxIterations = n;
      return consumed;
    } else if (ch === "p") {
      const v = rest || needArg(args, index, "-p");
      if (!rest) consumed = 1;
      opts.pids = parsePids(v);
      return consumed;
    } else if (ch === "F") {
      const v = rest || needArg(args, index, "-F");
      if (!rest) consumed = 1;
      opts.filter = v;
      return consumed;
    } else if (ch === "s") {
      const v = rest || needArg(args, index, "-s");
      if (!rest) consumed = 1;
      handleSortKey(v, opts);
      return consumed;
    } else if (ch === "u") {
      const v = rest || ((args[index + 1] && !args[index + 1].startsWith("-")) ? args[index + 1] : "");
      if (rest) {
        opts.user = v;
      } else if (v) {
        opts.user = v;
        consumed = 1;
      } else {
        opts.user = process.env.USER || "";
      }
      validateUser(opts.user);
      return consumed;
    } else {
      die(`./executable: invalid option -- '${ch}'`);
    }
  }
  return consumed;
}

function handleSortKey(v: string, opts: Opts) {
  if (v === "help") {
    process.stdout.write(SORT_HELP);
    process.exit(0);
  }
  if (!VALID_COLUMNS.has(v)) die(`Error: invalid column "${v}".`);
  opts.sortKey = v;
}

function parsePids(v: string): Set<number> {
  const set = new Set<number>();
  for (const part of v.split(",")) {
    if (/^\d+$/.test(part)) set.add(parseInt(part, 10));
  }
  return set;
}

function validateUser(u: string) {
  if (!u) return;
  try {
    const passwd = fs.readFileSync("/etc/passwd", "utf8");
    const ok = passwd.split("\n").some((line: string) => line.split(":")[0] === u || line.split(":")[2] === u);
    if (!ok) die(`Error: invalid user "${u}".`);
  } catch {
  }
}

function readCmdline(pid: string): string {
  try {
    const s = fs.readFileSync(`/proc/${pid}/cmdline`);
    const text = s.toString("utf8").replace(/\0/g, " ").trim();
    if (text) return text;
  } catch {}
  try { return `[${fs.readFileSync(`/proc/${pid}/comm`, "utf8").trim()}]`; } catch { return ""; }
}

function username(uid: number): string {
  try {
    const passwd = fs.readFileSync("/etc/passwd", "utf8").split("\n");
    for (const line of passwd) {
      const p = line.split(":");
      if (parseInt(p[2], 10) === uid) return p[0];
    }
  } catch {}
  return String(uid);
}

function fmtMem(kb: number): string {
  if (kb >= 1024 * 1024) return `${Math.round(kb / 1024 / 1024)}G`;
  if (kb >= 1024) return `${Math.round(kb / 1024)}M`;
  return String(kb);
}

function readProcesses(opts: Opts) {
  const hz = 100;
  const pagesize = 4;
  const rows: any[] = [];
  let totalMem = 1;
  try {
    const meminfo = fs.readFileSync("/proc/meminfo", "utf8");
    const m = meminfo.match(/^MemTotal:\s+(\d+)/m);
    if (m) totalMem = parseInt(m[1], 10);
  } catch {}
  for (const pid of fs.readdirSync("/proc").filter((x: string) => /^\d+$/.test(x))) {
    if (opts.pids && !opts.pids.has(parseInt(pid, 10))) continue;
    try {
      const stat = fs.readFileSync(`/proc/${pid}/stat`, "utf8");
      const rp = stat.lastIndexOf(")");
      const rest = stat.slice(rp + 2).split(/\s+/);
      const state = rest[0];
      const utime = parseInt(rest[11], 10) || 0;
      const stime = parseInt(rest[12], 10) || 0;
      const priority = parseInt(rest[15], 10) || 20;
      const nice = parseInt(rest[16], 10) || 0;
      const vsize = Math.round((parseInt(rest[20], 10) || 0) / 1024);
      const rss = (parseInt(rest[21], 10) || 0) * pagesize;
      const status = fs.readFileSync(`/proc/${pid}/status`, "utf8");
      const uidm = status.match(/^Uid:\s+(\d+)/m);
      const uid = uidm ? parseInt(uidm[1], 10) : 0;
      const user = username(uid);
      if (opts.user && opts.user !== user && opts.user !== String(uid)) continue;
      const cmd = readCmdline(pid);
      if (opts.filter) {
        const terms = opts.filter.toLowerCase().split("|");
        if (!terms.some((t: string) => cmd.toLowerCase().includes(t))) continue;
      }
      rows.push({ pid: parseInt(pid, 10), user, priority, nice, vsize, rss, shr: 0, state, cpu: 0, mem: (rss / totalMem) * 100, time: utime + stime, cmd });
    } catch {}
  }
  rows.sort((a, b) => opts.sortKey === "PID" ? a.pid - b.pid : b.cpu - a.cpu || a.pid - b.pid);
  return rows;
}

function pad(s: string, n: number, left = false): string {
  s = String(s);
  if (s.length > n) return s.slice(0, n);
  return left ? s.padStart(n) : s.padEnd(n);
}

function cpuMeters(): string {
  const n = Math.min(os.cpus().length, 8);
  const parts: string[] = [];
  for (let i = 0; i < n; i++) parts.push(`${i}[          0.0%]`);
  return parts.join("   ");
}

function printFrame(opts: Opts) {
  const rows = readProcesses(opts);
  const out: string[] = [];
  if (!opts.noMeters) {
    out.push(cpuMeters());
    const load = os.loadavg().map((x: number) => x.toFixed(2)).join(" ");
    out.push(`Tasks: ${rows.length}, ${rows.filter(r => r.state === "R").length} running; Load average: ${load}; Uptime: ${formatUptime(os.uptime())}`);
  }
  out.push("  PID USER       PRI  NI  VIRT   RES   SHR S  CPU%-MEM%   TIME+  Command");
  for (const r of rows.slice(0, 30)) {
    const time = formatTicks(r.time);
    out.push(`${pad(r.pid, 5, true)} ${pad(r.user, 10)} ${pad(r.priority, 3, true)} ${pad(r.nice, 3, true)} ${pad(fmtMem(r.vsize), 5, true)} ${pad(fmtMem(r.rss), 5, true)} ${pad(fmtMem(r.shr), 5, true)} ${r.state} ${pad(r.cpu.toFixed(1), 5, true)} ${pad(r.mem.toFixed(1), 4, true)} ${pad(time, 8, true)} ${r.cmd}`);
  }
  if (!opts.noFunctionBar) out.push(opts.readonly ? "F1Help  F2Setup F3SearchF4FilterF5Tree  F6SortByF7      F8      F9      F10Quit" : "F1Help  F2Setup F3SearchF4FilterF5Tree  F6SortByF7Nice -F8Nice +F9Kill  F10Quit");
  process.stdout.write(out.join("\n") + "\n");
}

function formatTicks(ticks: number): string {
  const sec = Math.floor(ticks / 100);
  const min = Math.floor(sec / 60);
  const sec2 = sec % 60;
  const hund = Math.floor((ticks % 100) / 10);
  return `${min}:${String(sec2).padStart(2, "0")}.${hund}`;
}

function formatUptime(sec: number): string {
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return `${d} days, ${h}:${String(m).padStart(2, "0")}`;
}

const opts = parseArgs(process.argv.slice(2));
printFrame(opts);
