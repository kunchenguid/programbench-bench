declare const process: any;

type Options = {
  seconds: boolean;
  screensaver: boolean;
  box: boolean;
  center: boolean;
  color: number;
  bold: boolean;
  twelve: boolean;
  utc: boolean;
  rebound: boolean;
  dateFormat: string;
  noQuit: boolean;
  hideDate: boolean;
  blink: boolean;
  delaySeconds: number;
  delayNanos: number;
  tty?: string;
};

const USAGE =
  "usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] \n" +
  "    -s            Show seconds                                   \n" +
  "    -S            Screensaver mode                               \n" +
  "    -x            Show box                                       \n" +
  "    -c            Set the clock at the center of the terminal    \n" +
  "    -C [0-7]      Set the clock color                            \n" +
  "    -b            Use bold colors                                \n" +
  "    -t            Set the hour in 12h format                     \n" +
  "    -u            Use UTC time                                   \n" +
  "    -T tty        Display the clock on the specified terminal    \n" +
  "    -r            Do rebound the clock                           \n" +
  "    -f format     Set the date format                            \n" +
  "    -n            Don't quit on keypress                         \n" +
  "    -v            Show tty-clock version                         \n" +
  "    -i            Show some info about tty-clock                 \n" +
  "    -h            Show this page                                 \n" +
  "    -D            Hide date                                      \n" +
  "    -B            Enable blinking colon                          \n" +
  "    -d delay      Set the delay between two redraws of the clock. Default 1s. \n" +
  "    -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns.\n";

const DIGITS: Record<string, string[]> = {
  "0": [" #### ", "##  ##", "##  ##", "##  ##", "##  ##", " #### "],
  "1": ["  ##  ", " ###  ", "  ##  ", "  ##  ", "  ##  ", " #### "],
  "2": [" #### ", "##  ##", "   ## ", "  ##  ", " ##   ", "######"],
  "3": [" #### ", "##  ##", "   ## ", "  ### ", "##  ##", " #### "],
  "4": ["##  ##", "##  ##", "######", "    ##", "    ##", "    ##"],
  "5": ["######", "##    ", "##### ", "    ##", "##  ##", " #### "],
  "6": [" #### ", "##    ", "##### ", "##  ##", "##  ##", " #### "],
  "7": ["######", "    ##", "   ## ", "  ##  ", " ##   ", "##    "],
  "8": [" #### ", "##  ##", " #### ", "##  ##", "##  ##", " #### "],
  "9": [" #### ", "##  ##", "##  ##", " #####", "    ##", " #### "],
  ":": ["  ", "##", "  ", "##", "  ", "  "],
};

function progName(): string {
  return process.env.TTY_CLOCK_PROG || process.argv[1] || "tty-clock";
}

function pad(n: number, w = 2): string {
  return String(n).padStart(w, "0");
}

function getPart(d: Date, utc: boolean, part: string): number {
  const prefix = utc ? "getUTC" : "get";
  return (d as any)[prefix + part]();
}

function formatDate(date: Date, fmt: string, utc: boolean): string {
  const year = getPart(date, utc, "FullYear");
  const month = getPart(date, utc, "Month") + 1;
  const day = getPart(date, utc, "Date");
  const hour = getPart(date, utc, "Hours");
  const min = getPart(date, utc, "Minutes");
  const sec = getPart(date, utc, "Seconds");
  const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const mons = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const shortDays = days.map((s) => s.slice(0, 3));
  const shortMons = mons.map((s) => s.slice(0, 3));
  return fmt.replace(/%[aAbBcdDeFHImMpRStTuUyY%]/g, (m) => {
    switch (m) {
      case "%%": return "%";
      case "%Y": return String(year);
      case "%y": return pad(year % 100);
      case "%m": return pad(month);
      case "%d": return pad(day);
      case "%e": return String(day).padStart(2, " ");
      case "%H": return pad(hour);
      case "%I": return pad(((hour + 11) % 12) + 1);
      case "%M": return pad(min);
      case "%S": return pad(sec);
      case "%p": return hour < 12 ? "AM" : "PM";
      case "%P": return hour < 12 ? "am" : "pm";
      case "%F": return `${year}-${pad(month)}-${pad(day)}`;
      case "%R": return `${pad(hour)}:${pad(min)}`;
      case "%T": return `${pad(hour)}:${pad(min)}:${pad(sec)}`;
      case "%u": {
        const dow = getPart(date, utc, "Day");
        return String(dow === 0 ? 7 : dow);
      }
      case "%w": return String(getPart(date, utc, "Day"));
      case "%a": return shortDays[getPart(date, utc, "Day")];
      case "%A": return days[getPart(date, utc, "Day")];
      case "%b":
      case "%h": return shortMons[month - 1];
      case "%B": return mons[month - 1];
      case "%c": return date.toString();
      case "%D": return `${pad(month)}/${pad(day)}/${pad(year % 100)}`;
      default: return m;
    }
  });
}

function parseArgs(argv: string[]): Options | "exit" {
  const opts: Options = {
    seconds: false, screensaver: false, box: false, center: false, color: 2,
    bold: false, twelve: false, utc: false, rebound: false, dateFormat: "%F",
    noQuit: false, hideDate: false, blink: false, delaySeconds: 1, delayNanos: 0,
  };
  const needsArg = new Set(["C", "f", "d", "a", "T"]);
  const noArg = new Set("iuvsScbtrahnDBx".split(""));
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (!arg.startsWith("-") || arg === "-") continue;
    if (arg === "--") break;
    for (let j = 1; j < arg.length; j++) {
      const ch = arg[j];
      if (needsArg.has(ch)) {
        let val = arg.slice(j + 1);
        if (!val) {
          if (i + 1 >= argv.length) {
            process.stderr.write(`${progName()}: option requires an argument -- '${ch}'\n`);
            process.stdout.write(USAGE);
            return "exit";
          }
          val = argv[++i];
        }
        if (ch === "C") opts.color = Number.parseInt(val, 10);
        else if (ch === "f") opts.dateFormat = val;
        else if (ch === "d") opts.delaySeconds = Number.parseFloat(val) || 0;
        else if (ch === "a") opts.delayNanos = Number.parseInt(val, 10) || 0;
        else if (ch === "T") opts.tty = val;
        break;
      }
      if (!noArg.has(ch)) {
        process.stderr.write(`${progName()}: invalid option -- '${ch}'\n`);
        process.stdout.write(USAGE);
        return "exit";
      }
      if (ch === "h") { process.stdout.write(USAGE); return "exit"; }
      if (ch === "v") { process.stdout.write("TTY-Clock 2 © devel version\n"); return "exit"; }
      if (ch === "i") { process.stdout.write("TTY-Clock 2 © by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)\n"); return "exit"; }
      if (ch === "s") opts.seconds = true;
      else if (ch === "S") opts.screensaver = true;
      else if (ch === "x") opts.box = true;
      else if (ch === "c") opts.center = true;
      else if (ch === "b") opts.bold = true;
      else if (ch === "t") opts.twelve = true;
      else if (ch === "u") opts.utc = true;
      else if (ch === "r") opts.rebound = true;
      else if (ch === "n") opts.noQuit = true;
      else if (ch === "D") opts.hideDate = true;
      else if (ch === "B") opts.blink = true;
    }
  }
  return opts;
}

function move(row: number, col: number): string {
  return `\x1b[${row};${col}H`;
}

function timeString(date: Date, opts: Options): string {
  let h = getPart(date, opts.utc, "Hours");
  const m = getPart(date, opts.utc, "Minutes");
  const s = getPart(date, opts.utc, "Seconds");
  if (opts.twelve) h = ((h + 11) % 12) + 1;
  let out = `${pad(h)}:${pad(m)}`;
  if (opts.seconds) out += `:${pad(s)}`;
  return out;
}

function renderRows(text: string): string[] {
  const rows = Array.from({ length: 6 }, () => "");
  for (const ch of text) {
    const glyph = DIGITS[ch] || DIGITS["0"];
    for (let r = 0; r < 6; r++) rows[r] += glyph[r] + " ";
  }
  return rows.map((r) => r.replace(/\s+$/, ""));
}

function draw(opts: Options): void {
  const cols = Number.parseInt(process.env.COLUMNS || "80", 10) || 80;
  const lines = Number.parseInt(process.env.LINES || "24", 10) || 24;
  const now = new Date();
  const rows = renderRows(timeString(now, opts));
  const date = formatDate(now, opts.dateFormat, opts.utc);
  const width = Math.max(...rows.map((r) => r.length), opts.hideDate ? 0 : date.length);
  const height = 6 + (opts.hideDate ? 0 : 2);
  let top = opts.center ? Math.max(1, Math.floor((lines - height) / 2) + 1) : 2;
  let left = opts.center ? Math.max(1, Math.floor((cols - width) / 2) + 1) : 2;
  if (opts.rebound) {
    const t = Math.floor(Date.now() / Math.max(1, (opts.delaySeconds * 1000) + Math.floor(opts.delayNanos / 1000000)));
    top = 1 + (t % Math.max(1, lines - height));
    left = 1 + ((t * 2) % Math.max(1, cols - width));
  }
  const color = Number.isFinite(opts.color) ? ((opts.color % 8) + 8) % 8 : 2;
  const bg = 40 + color;
  const fg = 30 + color;
  const attr = `\x1b[${opts.bold ? "1" : "0"}${opts.blink ? ";5" : ""}m`;
  let out = "\x1b[H\x1b[2J";
  if (opts.box) {
    const bw = width + 4;
    const bh = height + 2;
    const btop = Math.max(1, top - 1);
    const bleft = Math.max(1, left - 1);
    out += move(btop, bleft) + "\x1b(0l" + "q".repeat(Math.max(0, bw - 2)) + "k\x1b(B";
    for (let r = 1; r < bh - 1; r++) out += move(btop + r, bleft) + "\x1b(0x\x1b(B" + move(btop + r, bleft + bw - 1) + "\x1b(0x\x1b(B";
    out += move(btop + bh - 1, bleft) + "\x1b(0m" + "q".repeat(Math.max(0, bw - 2)) + "j\x1b(B";
  }
  for (let r = 0; r < rows.length; r++) {
    out += move(top + r, left) + attr;
    let inBlock = false;
    for (const ch of rows[r]) {
      if (ch === "#") {
        if (!inBlock) { out += `\x1b[${bg}m`; inBlock = true; }
        out += " ";
      } else {
        if (inBlock) { out += "\x1b[49m"; inBlock = false; }
        out += " ";
      }
    }
    if (inBlock) out += "\x1b[49m";
    out += "\x1b(B\x1b[m";
  }
  if (!opts.hideDate) {
    out += move(top + 7, left + Math.max(0, Math.floor((width - date.length) / 2))) + `\x1b[${fg}m${date}\x1b[39m\x1b(B\x1b[m`;
  }
  process.stdout.write(out);
}

function main(): void {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed === "exit") return;
  const term = process.env.TERM || "unknown";
  if (term === "unknown" || term === "dumb") {
    process.stderr.write("Error opening terminal: unknown.\n");
    process.exitCode = 1;
    return;
  }
  process.stdout.write("\x1b[?1049h\x1b[22;0;0t\x1b[1;24r\x1b(B\x1b[m\x1b[4l\x1b[?7h\x1b[?1h\x1b=\x1b[39;49m\x1b[?25l\x1b[39;49m\x1b(B\x1b[m\x1b[H\x1b[2J");
  const intervalMs = Math.max(20, Math.floor(parsed.delaySeconds * 1000 + parsed.delayNanos / 1000000));
  draw(parsed);
  const timer = setInterval(() => draw(parsed), intervalMs);
  const cleanup = () => {
    clearInterval(timer);
    process.stdout.write("\x1b[39;49m\x1b(B\x1b[m\x1b[?25h\x1b[?1049l");
  };
  process.on("SIGINT", () => { cleanup(); process.exit(0); });
  process.on("SIGTERM", () => { cleanup(); process.exit(0); });
  if (process.stdin && process.stdin.setRawMode) {
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on("data", (buf: any) => {
      const s = String(buf).toLowerCase();
      if (!parsed.noQuit && (s.includes("q") || parsed.screensaver)) {
        cleanup();
        process.exit(0);
      }
    });
  }
}

main();
