declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");

const VERSION_FULL = "RustOwl v1.0.0-rc.1";
const VERSION_SHORT = "v1.0.0-rc.1";

function out(s = ""): void { process.stdout.write(s + "\n"); }
function err(s = ""): void { process.stderr.write(s + "\n"); }
function exit(code: number): never { process.exit(code); throw new Error("unreachable"); }

const rootHelp = `Usage: executable [OPTIONS] [COMMAND]

Commands:
  check        Check availability
  clean        Remove artifacts from the target directory
  toolchain    Install or uninstall the toolchain
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Options:
  -V, --version   Print version
  -q, --quiet...  Suppress output
      --stdio     Use stdio to communicate with the LSP server
  -h, --help      Print help`;

const checkHelp = `Check availability

Usage: executable check [OPTIONS] [path]

Arguments:
  [path]  The path of a file or directory to check availability

Options:
      --all-targets   Run the check for all targets instead of current only
      --all-features  Run the check for all features instead of the current active ones only
  -h, --help          Print help`;

const cleanHelp = `Remove artifacts from the target directory

Usage: executable clean

Options:
  -h, --help  Print help`;

const toolchainHelp = `Install or uninstall the toolchain

Usage: executable toolchain [COMMAND]

Commands:
  install    Install the toolchain
  uninstall  Uninstall the toolchain
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help`;

const installHelp = `Install the toolchain

Usage: executable toolchain install [OPTIONS]

Options:
      --path <path>             Runtime directory path to install RustOwl toolchain
      --skip-rustowl-toolchain  Install Rust toolchain only
  -h, --help                    Print help`;

const uninstallHelp = `Uninstall the toolchain

Usage: executable toolchain uninstall

Options:
  -h, --help  Print help`;

const completionsHelp = `Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>
          The shell to generate completions for

          Possible values:
          - bash:       Bourne Again \`SHell\` (bash)
          - elvish:     Elvish shell
          - fish:       Friendly Interactive \`SHell\` (fish)
          - powershell: \`PowerShell\`
          - zsh:        Z \`SHell\` (zsh)
          - nushell:    Nushell

Options:
  -h, --help
          Print help (see a summary with '-h')`;

function usageFor(cmd: string): string {
  switch (cmd) {
    case "check": return "Usage: executable check [OPTIONS] [path]";
    case "clean": return "Usage: executable clean";
    case "toolchain": return "Usage: executable toolchain [COMMAND]";
    case "toolchain install": return "Usage: executable toolchain install [OPTIONS]";
    case "toolchain uninstall": return "Usage: executable toolchain uninstall";
    case "completions": return "Usage: executable completions <SHELL>";
    default: return "Usage: executable [OPTIONS] [COMMAND]";
  }
}

function unexpected(arg: string, cmd = ""): never {
  err(`error: unexpected argument '${arg}' found`);
  err("");
  err(usageFor(cmd));
  err("");
  err("For more information, try '--help'.");
  exit(2);
}

function unrecognized(cmd: string): never {
  err(`error: unrecognized subcommand '${cmd}'`);
  err("");
  err(rootHelp.split("\n")[0]);
  err("");
  err("For more information, try '--help'.");
  exit(2);
}

function missingShell(): never {
  err("error: the following required arguments were not provided:");
  err("  <SHELL>");
  err("");
  err("Usage: executable completions <SHELL>");
  err("");
  err("For more information, try '--help'.");
  exit(2);
}

function invalidShell(shell: string): never {
  err(`error: invalid value '${shell}' for '<SHELL>'`);
  err("  [possible values: bash, elvish, fish, powershell, zsh, nushell]");
  if (shell === "bad") {
    err("");
    err("  tip: a similar value exists: 'bash'");
  }
  err("");
  err("For more information, try '--help'.");
  exit(2);
}

function logFailure(): void {
  err(`${new Date().toISOString()} WARN  [rustowl::toolchain] cargo not found; fallback`);
  err(`${new Date().toISOString()} WARN  [rustowl::toolchain] rustowlc not found; fallback`);
  err(`${new Date().toISOString()} WARN  [rustowl::lsp::analyze] Invalid analysis target: ${process.cwd()}`);
  err(`${new Date().toISOString()} ERROR [rustowl] Analyze failed`);
}

function toolchainDownloadFailure(): never {
  err(`${new Date().toISOString()} INFO  [rustowl::toolchain] start installing Rust toolchain...`);
  err(`${new Date().toISOString()} INFO  [rustowl::toolchain] temp dir is made: /tmp/.tmpRustOwl`);
  err(`${new Date().toISOString()} INFO  [rustowl::toolchain] start downloading https://static.rust-lang.org/dist/2025-06-20/rustc-nightly-x86_64-unknown-linux-gnu.tar.gz...`);
  err(`${new Date().toISOString()} ERROR [rustowl::toolchain] failed to download tarball`);
  exit(1);
}

function generateCompletion(shell: string): string {
  const commands = "check clean toolchain completions help";
  if (shell === "bash") return `_rustowl() {
    local cur opts
    COMPREPLY=()
    cur="\${COMP_WORDS[COMP_CWORD]}"
    opts="-V --version -q --quiet --stdio -h --help ${commands}"
    COMPREPLY=( $(compgen -W "$opts" -- "$cur") )
}
complete -F _rustowl rustowl
`;
  if (shell === "zsh") return `#compdef rustowl
_arguments '-V[Print version]' '--version[Print version]' '*-q[Suppress output]' '*--quiet[Suppress output]' '--stdio[Use stdio to communicate with the LSP server]' '-h[Print help]' '--help[Print help]' '1: :((check\\:Check\\ availability clean\\:Remove\\ artifacts\\ from\\ the\\ target\\ directory toolchain\\:Install\\ or\\ uninstall\\ the\\ toolchain completions\\:Generate\\ shell\\ completions help\\:Print\\ help))'
`;
  if (shell === "fish") return `complete -c rustowl -s V -l version -d 'Print version'
complete -c rustowl -s q -l quiet -d 'Suppress output'
complete -c rustowl -l stdio -d 'Use stdio to communicate with the LSP server'
complete -c rustowl -s h -l help -d 'Print help'
complete -c rustowl -f -a 'check clean toolchain completions help'
`;
  if (shell === "powershell") return `using namespace System.Management.Automation
Register-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock {
  param($wordToComplete, $commandAst, $cursorPosition)
  '-V','--version','-q','--quiet','--stdio','-h','--help','check','clean','toolchain','completions','help' |
    Where-Object { $_ -like "$wordToComplete*" } |
    ForEach-Object { [CompletionResult]::new($_, $_, [CompletionResultType]::ParameterValue, $_) }
}
`;
  if (shell === "elvish") return `use builtin
set edit:completion:arg-completer[rustowl] = {|@words|
  put -V --version -q --quiet --stdio -h --help check clean toolchain completions help
}
`;
  return `module completions {
  export extern rustowl [
    --version(-V)             # Print version
    --quiet(-q)               # Suppress output
    --stdio                   # Use stdio to communicate with the LSP server
    --help(-h)                # Print help
  ]
  export extern "rustowl check" [
    --all-targets             # Run the check for all targets instead of current only
    --all-features            # Run the check for all features instead of the current active ones only
    --help(-h)                # Print help
    path?: path               # The path of a file or directory to check availability
  ]
  export extern "rustowl clean" [ --help(-h) ]
  export extern "rustowl toolchain" [ --help(-h) ]
  export extern "rustowl toolchain install" [
    --path: path              # Runtime directory path to install RustOwl toolchain
    --skip-rustowl-toolchain  # Install Rust toolchain only
    --help(-h)
  ]
  export extern "rustowl toolchain uninstall" [ --help(-h) ]
  export extern "rustowl completions" [ shell: string ]
}
`;
}

function sendRpc(message: any): void {
  const body = JSON.stringify(message);
  process.stdout.write(`Content-Length: ${Buffer.byteLength(body, "utf8")}\r\n\r\n${body}`);
}

function runStdio(): void {
  err(VERSION_FULL);
  err("This is an LSP server. You can use --help flag to show help.");
  let buffer = Buffer.alloc(0);
  process.stdin.on("data", (chunk: any) => {
    buffer = Buffer.concat([buffer, chunk]);
    for (;;) {
      const text = buffer.toString("utf8");
      const headerEnd = text.indexOf("\r\n\r\n");
      if (headerEnd < 0) return;
      const header = text.slice(0, headerEnd);
      const m = /Content-Length:\s*(\d+)/i.exec(header);
      if (!m) { buffer = Buffer.alloc(0); return; }
      const len = Number(m[1]);
      const start = Buffer.byteLength(text.slice(0, headerEnd + 4), "utf8");
      if (buffer.length < start + len) return;
      const body = buffer.slice(start, start + len).toString("utf8");
      buffer = buffer.slice(start + len);
      handleRpc(body);
    }
  });
}

function handleRpc(body: string): void {
  let msg: any;
  try { msg = JSON.parse(body); } catch { return; }
  if (msg.id === undefined || msg.id === null) return;
  if (msg.method === "initialize") {
    sendRpc({ jsonrpc: "2.0", id: msg.id, result: { capabilities: {
      textDocumentSync: 1,
      hoverProvider: true,
      executeCommandProvider: { commands: ["rustowl/analyze"] }
    }, serverInfo: { name: "RustOwl", version: "1.0.0-rc.1" } } });
  } else if (msg.method === "shutdown") {
    sendRpc({ jsonrpc: "2.0", id: msg.id, result: null });
  } else if (msg.method === "textDocument/hover") {
    sendRpc({ jsonrpc: "2.0", id: msg.id, result: null });
  } else {
    sendRpc({ jsonrpc: "2.0", id: msg.id, error: { code: -32601, message: "Method not found" } });
  }
}

function clean(): void {
  for (const name of ["target", ".rustowl"]) {
    try { fs.rmSync(path.join(process.cwd(), name), { recursive: true, force: true }); } catch {}
  }
}

function main(argv: string[]): void {
  let quiet = 0;
  let stdio = false;
  while (argv.length && argv[0].startsWith("-")) {
    const a = argv[0];
    if (a === "--") { argv.shift(); break; }
    if (a === "-h" || a === "--help") { out(rootHelp); return; }
    if (a === "-V" || a === "--version") { out(quiet ? VERSION_SHORT : VERSION_FULL); return; }
    if (a === "--stdio") { stdio = true; argv.shift(); continue; }
    if (a === "-q" || a === "--quiet") { quiet++; argv.shift(); continue; }
    if (/^-q+$/.test(a)) { quiet += a.length - 1; argv.shift(); continue; }
    unexpected(a);
  }
  if (stdio && argv.length === 0) { runStdio(); return; }
  const cmd = argv.shift();
  if (!cmd) return;
  if (cmd === "help") {
    const topic = argv.shift();
    if (!topic) { out(rootHelp); return; }
    if (topic === "check") out(checkHelp);
    else if (topic === "clean") out(cleanHelp);
    else if (topic === "toolchain") out(toolchainHelp);
    else if (topic === "completions") out(completionsHelp);
    else unrecognized(topic);
    return;
  }
  if (cmd === "check") {
    let seenPath = false;
    for (const a of argv) {
      if (a === "-h" || a === "--help") { out(checkHelp); return; }
      if (a === "--all-targets" || a === "--all-features") continue;
      if (a.startsWith("-")) {
        err(`error: unexpected argument '${a}' found`);
        err("");
        err(`  tip: to pass '${a}' as a value, use '-- ${a}'`);
        err("");
        err(usageFor("check"));
        err("");
        err("For more information, try '--help'.");
        exit(2);
      }
      if (seenPath) unexpected(a, "check");
      seenPath = true;
    }
    logFailure();
    exit(1);
  }
  if (cmd === "clean") {
    for (const a of argv) {
      if (a === "-h" || a === "--help") { out(cleanHelp); return; }
      unexpected(a, "clean");
    }
    clean();
    return;
  }
  if (cmd === "toolchain") {
    const sub = argv.shift();
    if (!sub || sub === "-h" || sub === "--help") { out(toolchainHelp); return; }
    if (sub === "help") { out(toolchainHelp); return; }
    if (sub === "install") {
      for (let i = 0; i < argv.length; i++) {
        const a = argv[i];
        if (a === "-h" || a === "--help") { out(installHelp); return; }
        if (a === "--skip-rustowl-toolchain") continue;
        if (a === "--path") { if (argv[++i] === undefined) unexpected("--path", "toolchain install"); continue; }
        if (a.startsWith("--path=")) continue;
        unexpected(a, "toolchain install");
      }
      toolchainDownloadFailure();
    }
    if (sub === "uninstall") {
      for (const a of argv) {
        if (a === "-h" || a === "--help") { out(uninstallHelp); return; }
        unexpected(a, "toolchain uninstall");
      }
      return;
    }
    unrecognized(sub);
  }
  if (cmd === "completions") {
    if (argv[0] === "-h" || argv[0] === "--help") { out(completionsHelp); return; }
    if (!argv[0]) missingShell();
    if (argv.length > 1) unexpected(argv[1], "completions");
    const shell = argv[0];
    if (!["bash", "elvish", "fish", "powershell", "zsh", "nushell"].includes(shell)) invalidShell(shell);
    process.stdout.write(generateCompletion(shell));
    return;
  }
  unrecognized(cmd);
}

main(process.argv.slice(2));
