declare const require: any;
declare const process: any;
declare const Buffer: any;
type Buffer = any;

const fs = require("fs");
const nodeCrypto = require("crypto");
const zlib = require("zlib");

type Options = {
  inputFile?: string;
  workers?: number;
  passwordDictionary?: string;
  charset: string;
  charsetFile?: string;
  minPasswordLen: number;
  maxPasswordLen: number;
  fileNumber: number;
  startingPassword?: string;
};

type ZipEntry = {
  flag: number;
  method: number;
  mtime: number;
  crc: number;
  compressedSize: number;
  uncompressedSize: number;
  localOffset: number;
  extra: Buffer;
};

type AesInfo = {
  strength: number;
  actualMethod: number;
};

const SYMBOLS = " !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";

function usage(full: boolean): string {
  const body = `Find the password of protected ZIP files

Usage: executable [OPTIONS] --inputFile <inputFile>

Options:
  -i, --inputFile <inputFile>                    path to zip input file
  -w, --workers <workers>                        number of workers
  -p, --passwordDictionary <passwordDictionary>  path to a password dictionary file
  -c, --charset <charset>                        charset to use to generate password [default: lud]
      --charsetFile <charsetFile>                path to a charset file
      --minPasswordLen <minPasswordLen>          minimum password length [default: 1]
      --maxPasswordLen <maxPasswordLen>          maximum password length [default: 10]
      --fileNumber <fileNumber>                  file number in the zip archive [default: 0]
  -s, --startingPassword <startingPassword>      password to start from
  -h, --help                                     Print help
  -V, --version                                  Print version`;
  return full ? body : body;
}

function parseIntArg(name: string, value: string): number {
  if (!/^\d+$/.test(value)) {
    console.error(`error: invalid value '${value}' for '${name}': invalid digit found in string\n`);
    console.error("For more information, try '--help'.");
    process.exit(2);
  }
  return Number(value);
}

function parseArgs(argv: string[]): Options {
  const opts: Options = { charset: "lud", minPasswordLen: 1, maxPasswordLen: 10, fileNumber: 0 };
  const take = (i: number, opt: string): string => {
    const v = argv[i + 1];
    if (v === undefined || v.startsWith("-")) {
      console.error(`error: a value is required for '${opt} <${opt.replace(/^--?/, "")}>' but none was supplied`);
      process.exit(2);
    }
    return v;
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") {
      console.log(usage(true));
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      console.log("zip-password-finder 0.10.3");
      process.exit(0);
    } else if (a === "-i" || a === "--inputFile") {
      opts.inputFile = take(i, a);
      i++;
    } else if (a === "-w" || a === "--workers") {
      opts.workers = parseIntArg(`'${a}'`, take(i, a));
      i++;
    } else if (a === "-p" || a === "--passwordDictionary") {
      opts.passwordDictionary = take(i, a);
      i++;
    } else if (a === "-c" || a === "--charset") {
      opts.charset = take(i, a);
      i++;
    } else if (a === "--charsetFile") {
      opts.charsetFile = take(i, a);
      i++;
    } else if (a === "--minPasswordLen") {
      opts.minPasswordLen = parseIntArg("--minPasswordLen <minPasswordLen>", take(i, a));
      i++;
    } else if (a === "--maxPasswordLen") {
      opts.maxPasswordLen = parseIntArg("--maxPasswordLen <maxPasswordLen>", take(i, a));
      i++;
    } else if (a === "--fileNumber") {
      opts.fileNumber = parseIntArg("--fileNumber <fileNumber>", take(i, a));
      i++;
    } else if (a === "-s" || a === "--startingPassword") {
      opts.startingPassword = take(i, a);
      i++;
    } else {
      console.error(`error: unexpected argument '${a}' found\n`);
      console.error("Usage: executable [OPTIONS] --inputFile <inputFile>\n");
      console.error("For more information, try '--help'.");
      process.exit(2);
    }
  }
  if (!opts.inputFile) {
    console.error("error: the following required arguments were not provided:");
    console.error("  --inputFile <inputFile>\n");
    console.error("Usage: executable --inputFile <inputFile>\n");
    console.error("For more information, try '--help'.");
    process.exit(2);
  }
  if (!fs.existsSync(opts.inputFile)) {
    console.error(`CLI argument error - "'inputFile' does not exist"`);
    process.exit(1);
  }
  if (opts.passwordDictionary && !fs.existsSync(opts.passwordDictionary)) {
    console.error(`CLI argument error - "'passwordDictionary' does not exist"`);
    process.exit(1);
  }
  if (opts.charsetFile && !fs.existsSync(opts.charsetFile)) {
    console.error(`CLI argument error - "'charsetFile' does not exist"`);
    process.exit(1);
  }
  return opts;
}

function findEocd(buf: Buffer): number {
  const min = Math.max(0, buf.length - 22 - 0xffff);
  for (let i = buf.length - 22; i >= min; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) return i;
  }
  throw new Error("Could not find end of central directory");
}

function readEntries(buf: Buffer): ZipEntry[] {
  const eocd = findEocd(buf);
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const entries: ZipEntry[] = [];
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) throw new Error("Invalid central directory");
    const flag = buf.readUInt16LE(off + 8);
    const method = buf.readUInt16LE(off + 10);
    const mtime = buf.readUInt16LE(off + 12);
    const crc = buf.readUInt32LE(off + 16);
    const compressedSize = buf.readUInt32LE(off + 20);
    const uncompressedSize = buf.readUInt32LE(off + 24);
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    const localOffset = buf.readUInt32LE(off + 42);
    const extra = buf.subarray(off + 46 + nameLen, off + 46 + nameLen + extraLen);
    entries.push({ flag, method, mtime, crc, compressedSize, uncompressedSize, localOffset, extra });
    off += 46 + nameLen + extraLen + commentLen;
  }
  return entries;
}

function entryData(buf: Buffer, entry: ZipEntry): Buffer {
  const off = entry.localOffset;
  if (buf.readUInt32LE(off) !== 0x04034b50) throw new Error("Invalid local header");
  const nameLen = buf.readUInt16LE(off + 26);
  const extraLen = buf.readUInt16LE(off + 28);
  const start = off + 30 + nameLen + extraLen;
  return buf.subarray(start, start + entry.compressedSize);
}

function parseAes(extra: Buffer): AesInfo | undefined {
  let off = 0;
  while (off + 4 <= extra.length) {
    const id = extra.readUInt16LE(off);
    const len = extra.readUInt16LE(off + 2);
    const data = extra.subarray(off + 4, off + 4 + len);
    if (id === 0x9901 && data.length >= 7) {
      return { strength: data[4], actualMethod: data.readUInt16LE(5) };
    }
    off += 4 + len;
  }
  return undefined;
}

const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
  crcTable[n] = c >>> 0;
}

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (const b of buf) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function crc32Update(c: number, b: number): number {
  return (crcTable[(c ^ b) & 0xff] ^ (c >>> 8)) >>> 0;
}

class ZipCrypto {
  private k0 = 0x12345678;
  private k1 = 0x23456789;
  private k2 = 0x34567890;

  constructor(password: string) {
    for (const b of Buffer.from(password, "utf8")) this.update(b);
  }

  private update(b: number): void {
    this.k0 = crc32Update(this.k0, b);
    this.k1 = (Math.imul((this.k1 + (this.k0 & 0xff)) >>> 0, 134775813) + 1) >>> 0;
    this.k2 = crc32Update(this.k2, this.k1 >>> 24);
  }

  decryptByte(): number {
    const t = (this.k2 | 2) & 0xffff;
    return (Math.imul(t, t ^ 1) >>> 8) & 0xff;
  }

  decrypt(src: Buffer): Buffer {
    const out = Buffer.allocUnsafe(src.length);
    for (let i = 0; i < src.length; i++) {
      const p = src[i] ^ this.decryptByte();
      this.update(p);
      out[i] = p;
    }
    return out;
  }
}

function testZipCrypto(buf: Buffer, entry: ZipEntry, password: string): boolean {
  const data = entryData(buf, entry);
  if (data.length < 12) return false;
  const zc = new ZipCrypto(password);
  const header = zc.decrypt(data.subarray(0, 12));
  const expected = (entry.flag & 0x8) ? ((entry.mtime >> 8) & 0xff) : ((entry.crc >>> 24) & 0xff);
  if (header[11] !== expected) return false;
  const plain = zc.decrypt(data.subarray(12));
  let content: Buffer;
  try {
    if (entry.method === 0) content = plain;
    else if (entry.method === 8) content = zlib.inflateRawSync(plain);
    else return true;
  } catch {
    return false;
  }
  if (entry.uncompressedSize !== 0xffffffff && content.length !== entry.uncompressedSize) return false;
  return crc32(content) === entry.crc;
}

function testAes(buf: Buffer, entry: ZipEntry, password: string): boolean {
  const info = parseAes(entry.extra);
  if (!info) return false;
  const saltLen = info.strength === 1 ? 8 : info.strength === 2 ? 12 : 16;
  const keyLen = info.strength === 1 ? 16 : info.strength === 2 ? 24 : 32;
  const data = entryData(buf, entry);
  if (data.length < saltLen + 12) return false;
  const salt = data.subarray(0, saltLen);
  const verifier = data.subarray(saltLen, saltLen + 2);
  const encrypted = data.subarray(saltLen + 2, data.length - 10);
  const auth = data.subarray(data.length - 10);
  const derived = nodeCrypto.pbkdf2Sync(Buffer.from(password, "utf8"), salt, 1000, keyLen * 2 + 2, "sha1");
  if (!nodeCrypto.timingSafeEqual(verifier, derived.subarray(keyLen * 2, keyLen * 2 + 2))) return false;
  const mac = nodeCrypto.createHmac("sha1", derived.subarray(keyLen, keyLen * 2)).update(encrypted).digest().subarray(0, 10);
  return nodeCrypto.timingSafeEqual(auth, mac);
}

function passwordWorks(buf: Buffer, entry: ZipEntry, password: string): boolean {
  if ((entry.flag & 1) === 0) return false;
  if (entry.method === 99) return testAes(buf, entry, password);
  return testZipCrypto(buf, entry, password);
}

function charsetFromOptions(opts: Options): string {
  if (opts.charsetFile) return fs.readFileSync(opts.charsetFile, "utf8").replace(/\r?\n$/, "");
  let out = "";
  for (const ch of opts.charset) {
    if (ch === "l") out += "abcdefghijklmnopqrstuvwxyz";
    else if (ch === "u") out += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    else if (ch === "d") out += "0123456789";
    else if (ch === "h") out += "0123456789abcdef";
    else if (ch === "H") out += "0123456789ABCDEF";
    else if (ch === "s") out += SYMBOLS;
    else {
      console.error(`CLI argument error - "Unknown charset option '${ch}'"`);
      process.exit(1);
    }
  }
  return out;
}

function* brutePasswords(chars: string, minLen: number, maxLen: number): Generator<string> {
  for (let len = minLen; len <= maxLen; len++) {
    const idx = new Array(len).fill(0);
    while (true) {
      yield idx.map((i) => chars[i]).join("");
      let pos = len - 1;
      while (pos >= 0) {
        idx[pos]++;
        if (idx[pos] < chars.length) break;
        idx[pos] = 0;
        pos--;
      }
      if (pos < 0) break;
    }
  }
}

function formatElapsed(start: bigint): string {
  const ns = process.hrtime.bigint() - start;
  const ms = ns / 1_000_000n;
  const us = (ns / 1_000n) % 1000n;
  const rem = ns % 1000n;
  return `${ms}ms ${us}us ${rem}ns`;
}

function main(): void {
  const opts = parseArgs(process.argv.slice(2));
  const start = process.hrtime.bigint();
  const zip = fs.readFileSync(opts.inputFile!);
  const entries = readEntries(zip);
  const entry = entries[opts.fileNumber];
  if (!entry) {
    console.error(`CLI argument error - "File number ${opts.fileNumber} does not exist"`);
    process.exit(1);
  }

  let found: string | undefined;
  if (opts.passwordDictionary) {
    const words = fs.readFileSync(opts.passwordDictionary, "utf8").split(/\r?\n/);
    for (let word of words) {
      if (word.endsWith("\r")) word = word.slice(0, -1);
      if (passwordWorks(zip, entry, word)) {
        found = word;
        break;
      }
    }
  } else {
    const chars = charsetFromOptions(opts);
    let active = opts.startingPassword === undefined;
    for (const pwd of brutePasswords(chars, opts.minPasswordLen, opts.maxPasswordLen)) {
      if (!active) {
        if (pwd === opts.startingPassword) active = true;
        else continue;
      }
      if (passwordWorks(zip, entry, pwd)) {
        found = pwd;
        break;
      }
    }
  }

  console.log(`Time elapsed: ${formatElapsed(start)}`);
  if (found !== undefined) console.log(`Password found:${found}`);
  else console.log("Password not found");
}

try {
  main();
} catch (err) {
  const msg = err instanceof Error ? err.message : String(err);
  console.error(msg);
  process.exit(1);
}
