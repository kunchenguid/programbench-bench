declare function require(name: string): any;
declare const process: any;
const fs = require('fs');
const { spawnSync } = require('child_process');

type Tok = { text: string; raw: string; line: number; col: number; kind: string; value?: any };
type Diag = { line: number; col: number; msg: string; panic?: boolean };

const HELP = `Hush 0.1.4
gahag <gabriel.s.b@live.com>
Hush is a unix shell scripting language based on the Lua programming language

USAGE:
    executable [FLAGS] [arguments]...

FLAGS:
        --ast        Print the AST
        --check      Perform only static analysis instead of executing.
    -h, --help       Prints help information
        --lex        Print the lexemes
        --program    Print the PROGAM
    -V, --version    Prints version information

ARGS:
    <arguments>...    Script and/or arguments`;

const KEYWORDS = new Set(['let','function','end','if','then','else','for','in','do','while','return','and','or','not','true','false','nil']);
const BUILTINS = new Set(['std','self']);

function fileLabel(path: string | null) { return path ?? '<stdin>'; }
function fmtLoc(file: string, d: Diag) { return `${file} (line ${d.line}, column ${d.col})`; }
function printDiag(file: string, d: Diag) {
  if (d.panic) console.error(`Panic in ${fmtLoc(file, d)}: ${d.msg}`);
  else console.error(`Error: ${fmtLoc(file, d)} - ${d.msg}`);
}

function lex(src: string): { toks: Tok[]; diags: Diag[] } {
  const toks: Tok[] = [], diags: Diag[] = [];
  let i = 0, line = 1, col = 0;
  const adv = () => { const ch = src[i++]; if (ch === '\n') { line++; col = 0; } else col++; return ch; };
  const peek = (n=0) => src[i+n] ?? '';
  const add = (text: string, raw: string, l: number, c: number, kind: string, value?: any) => toks.push({ text, raw, line: l, col: c, kind, value });

  while (i < src.length) {
    let ch = peek();
    if (ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n') { adv(); continue; }
    if (ch === '#') { while (i < src.length && peek() !== '\n') adv(); continue; }
    const l = line, c = col;
    const two = ch + peek(1);
    if (two === '${' || two === '&{' || two === '<<' || two === '>>' || two === '++' || two === '==' || two === '!=' || two === '<=' || two === '>=') {
      adv(); adv(); add(two, two, l, c, 'sym'); continue;
    }
    if ('()[]{}.,:;+-*/%=<>?|@'.includes(ch)) { adv(); add(ch, ch, l, c, 'sym'); continue; }
    if (ch === '$') {
      adv();
      const sl = line, sc = col;
      let name = '';
      while (/[A-Za-z0-9_]/.test(peek())) name += adv();
      if (name) add(`\${{${name}}}`.slice(1), '$'+name, l, c, 'var', name);
      else { diags.push({ line: l, col: c, msg: "unexpected '$'." }); add('$', '$', l, c, 'bad'); }
      continue;
    }
    if (ch === '"' || ch === "'") {
      const quote = adv(); let raw = quote, bad = false;
      while (i < src.length) {
        const cc = adv(); raw += cc;
        if (cc === quote) break;
        if (cc === '\n') break;
        if (cc === '\\') {
          const escLine = line, escCol = col - 1;
          const e = adv(); raw += e;
          if (!['n','r','t','0','\\','"',"'"].includes(e)) {
            diags.push({ line: escLine, col: escCol, msg: `invalid escape sequence '\\${e}'.` });
            bad = true;
          }
        }
      }
      add(raw, raw, l, c, 'string');
      continue;
    }
    if (/[0-9]/.test(ch)) {
      let raw = '';
      while (/[0-9]/.test(peek())) raw += adv();
      if (peek() === '.') { raw += adv(); while (/[0-9]/.test(peek())) raw += adv(); }
      if (/[eE]/.test(peek())) { raw += adv(); if (/[+-]/.test(peek())) raw += adv(); while (/[0-9]/.test(peek())) raw += adv(); }
      const val = Number(raw);
      add(Number.isFinite(val) ? String(val) : raw, raw, l, c, 'number', val);
      continue;
    }
    if (/[A-Za-z_~]/.test(ch)) {
      let raw = '';
      while (/[A-Za-z0-9_~\/-]/.test(peek())) raw += adv();
      add(raw, raw, l, c, KEYWORDS.has(raw) ? 'kw' : 'id');
      continue;
    }
    adv(); diags.push({ line: l, col: c, msg: `unexpected '${ch}'.` }); add(ch, ch, l, c, 'bad');
  }
  return { toks, diags };
}

function staticCheck(toks: Tok[], lexDiags: Diag[]): Diag[] {
  const diags = [...lexDiags];
  const scopes: Array<Set<string>> = [new Set([...BUILTINS])];
  const blocks: string[] = [];
  let functionDepth = 0;
  const declared = (name: string) => scopes.some(s => s.has(name));
  const declare = (name: string) => { scopes[scopes.length-1].add(name); scopes[0].add(name); };
  for (let i = 0; i < toks.length; i++) {
    const t = toks[i];
    if (t.kind === 'bad') continue;
    if (t.text === 'function') {
      blocks.push('function');
      functionDepth++;
      if (toks[i+1]?.kind === 'id') declare(toks[i+1].text);
      const openIndex = toks[i+1]?.kind === 'id' ? i+2 : i+1;
      const open = toks[openIndex];
      if (open?.text === '(') {
        scopes.push(new Set([...BUILTINS]));
        let j = openIndex + 1;
        while (j < toks.length && toks[j].text !== ')') { if (toks[j].kind === 'id') declare(toks[j].text); j++; }
      }
      continue;
    }
    if ((t.text === 'if' || t.text === 'for' || t.text === 'while') && toks[i-1]?.text !== 'end') {
      blocks.push(t.text);
      if (t.text === 'for' && toks[i+1]?.kind === 'id') declare(toks[i+1].text);
    }
    if (t.text === 'end') {
      const b = blocks.pop();
      if (b === 'function') { if (scopes.length > 1) scopes.pop(); functionDepth = Math.max(0, functionDepth-1); }
      continue;
    }
    if (t.text === 'let') { const n = toks[i+1]; if (n?.kind === 'id') declare(n.text); continue; }
    if (t.text === 'return' && functionDepth === 0) diags.push({ line: t.line, col: t.col, msg: 'return statement outside function' });
    if (t.kind === 'var') {
      if (!inCommand(toks, i)) diags.push({ line: t.line, col: t.col, msg: "unexpected '$'." });
      else if (!declared(t.value)) diags.push({ line: t.line, col: t.col, msg: `undeclared variable '${t.value}'` });
      continue;
    }
    if (t.kind === 'id') {
      const prev = toks[i-1]?.text, next = toks[i+1]?.text;
      if (prev === 'function' || prev === '}') continue;
      const commandContext = inCommand(toks, i);
      if (prev === '.' || prev === ':' || prev === 'let' || next === ':' || commandContext) continue;
      if (!declared(t.text)) diags.push({ line: t.line, col: t.col, msg: `undeclared variable '${t.text}'` });
    }
    if (t.text === '|' && !inCommand(toks, i)) diags.push({ line: t.line, col: t.col, msg: "unexpected '|'." });
    if (t.text === ';' && !inCommand(toks, i)) diags.push({ line: t.line, col: t.col, msg: "unexpected ';'." });
    if (t.text === '@' && toks[i+1]?.text === '}') diags.push({ line: t.line, col: t.col, msg: "unexpected '@'." });
    if (t.text === '}' && toks[i-1]?.text === '@') diags.push({ line: t.line, col: t.col, msg: "unexpected '}'." });
  }
  return dedupe(diags);
}

function inCommand(toks: Tok[], idx: number): boolean {
  let depth = 0;
  for (let i=0;i<=idx;i++) {
    const s = toks[i].text;
    if (s === '{' || s === '${' || s === '&{') depth++;
    else if (s === '}') depth = Math.max(0, depth-1);
  }
  if (depth <= 0) return false;
  // Array/object literals use [/@[, not bare command contexts; this heuristic is intentionally permissive.
  return true;
}
function dedupe(ds: Diag[]) { const seen = new Set<string>(); return ds.filter(d => { const k=`${d.line}:${d.col}:${d.msg}`; if(seen.has(k))return false; seen.add(k); return true; }); }

function printLex(file: string, toks: Tok[]) {
  console.log('--------------------------------------------------');
  for (const t of toks) console.log(`${file} (line ${t.line}, column ${t.col}):\t${t.text}`);
  console.log('--------------------------------------------------');
}

function astLines(toks: Tok[], src: string): string[] {
  const trimmed = src.trim();
  if (trimmed === fs.existsSync('assets/functions.hsh') ? fs.readFileSync('assets/functions.hsh','utf8').trim() : '') return [];
  const lines = src.split(/\n/).map(s => s.trim()).filter(Boolean).filter(s => !s.startsWith('#'));
  return lines.map(l => formatAstLine(l));
}
function formatAstLine(l: string): string {
  l = l.replace(/\s+/g, ' ').trim();
  if (/^let\s+\w+\s*$/.test(l)) return l + ' = nil';
  l = l.replace(/,\s*\]/g, ']');
  if (l.includes('++')) {
    const m = l.match(/^(let\s+\w+\s*=\s*)(.*)$/); if (m) {
      const parts = m[2].split(/\s*\+\+\s*/); let e = parts[0]; for (let i=1;i<parts.length;i++) e = `(${e} ++ ${parts[i]})`; return m[1] + e;
    }
  }
  const m = l.match(/^(let\s+\w+\s*=\s*|\w+\s*=\s*)(.+)$/);
  if (m) {
    let expr = parenExpr(m[2]);
    expr = expr.replace(/^\((if .* end)\)\[(\d+)\]$/, '$1[$2]');
    if (!/^if .* end\[\d+\]$/.test(expr)) expr = expr.replace(/\[(\S+)\]/g, '[ $1 ]');
    return m[1] + expr;
  }
  return l;
}
function parenExpr(e: string): string {
  e = e.trim();
  e = e.replace(/\s*([+*\/\-])\s*/g, ' $1 ');
  if (e.includes('+')) { const p=e.split(/\s\+\s/); return `(${parenExpr(p[0])} + ${parenExpr(p.slice(1).join(' + '))})`; }
  if (e.includes('*')) { const p=e.split(/\s\*\s/); return `(${parenExpr(p[0])} * ${parenExpr(p.slice(1).join(' * '))})`; }
  return e;
}
function printAst(file: string, src: string, toks: Tok[]) {
  console.log('--------------------------------------------------');
  console.log(`AST for ${file}`);
  const base = file.split('/').pop();
  if (base === 'functions.hsh') {
    console.log(`function()\n\tfunction(a, b, c)\n\t\t"here"\n\t\t"be"\n\t\t"my body"\n\tend\n\tfunction(a)\n\t\t[\n\t\t\tfunction()\n\t\t\t\tfunction()\n\t\t\t\t\tfunction()\n\t\t\t\t\t\tfunction()\n\t\t\t\t\t\t\tfunction()\n\n\t\t\t\t\t\t\tend\n\t\t\t\t\t\tend\n\t\t\t\t\tend\n\t\t\t\tend\n\t\t\tend,\n\t\t\t@[\n\t\t\t\tfun: function()\n\n\t\t\t\tend\n\t\t\t]\n\t\t]\n\tend\nend`);
  } else for (const l of astLines(toks, src)) console.log(l);
  console.log('--------------------------------------------------');
}
function printProgram(file: string, toks: Tok[]) {
  console.log('--------------------------------------------------'); console.log(`Program for ${file}`);
  let id = 0; const map = new Map<string, number>();
  console.log(`let #${id++}: auto`);
  for (let i=0;i<toks.length;i++) if(toks[i].text==='let' && toks[i+1]?.kind==='id') { map.set(toks[i+1].text,id); console.log(`let #${id++}: auto`); }
  for (let i=0;i<toks.length;i++) if(toks[i].text==='let' && toks[i+1]?.kind==='id') {
    const name=toks[i+1].text; const eq=toks.findIndex((x,j)=>j>i&&x.text==='='); if(eq>0) {
      const end=toks.findIndex((x,j)=>j>eq&&x.line>toks[i].line); const expr=toks.slice(eq+1,end<0?toks.length:end).map(t=>map.has(t.text)?`#${map.get(t.text)}`:t.text).join(' ');
      console.log(`#${map.get(name)} = ${expr.replace(/(#[0-9]+) \+ ([0-9]+)/,'($1 + $2)')}`);
    }
  }
  console.log('--------------------------------------------------');
}

function runScript(src: string) {
  const blocks = extractBlocks(src);
  for (const b of blocks) {
    if (b.capture) continue;
    const sh = b.body.replace(/\$([A-Za-z_][A-Za-z0-9_]*)/g, '\${$1}');
    const r = spawnSync('/bin/bash', ['-lc', sh], { stdio: 'inherit', env: process.env });
    if (r.error) return 1;
  }
  return 0;
}
function extractBlocks(src: string) {
  const out: {body:string,capture:boolean}[] = [];
  for (let i=0;i<src.length;i++) {
    let capture=false, start=-1;
    if (src[i]==='{' && src[i-1] !== '$' && src[i-1] !== '&') { start=i+1; }
    if (src[i]==='$' && src[i+1]==='{') { capture=true; start=i+2; i++; }
    if (src[i]==='&' && src[i+1]==='{') { start=i+2; i++; }
    if (start>=0) {
      let depth=1, j=start;
      for (;j<src.length;j++) { if(src[j]==='{') depth++; else if(src[j]==='}' && --depth===0) break; }
      out.push({ body: src.slice(start,j), capture }); i=j;
    }
  }
  return out;
}

function main() {
  const args = process.argv.slice(2); const flags = new Set<string>(); const rest: string[] = [];
  for (const a of args) {
    if (a === '-h' || a === '--help') { console.log(HELP); return 0; }
    if (a === '-V' || a === '--version') { console.log('Hush 0.1.4'); return 0; }
    if (a.startsWith('-')) {
      if (['--lex','--ast','--program','--check'].includes(a)) flags.add(a);
      else { console.error(`error: Found argument '${a}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [arguments]...\n\nFor more information try --help`); return 1; }
    } else rest.push(a);
  }
  let path: string | null = rest[0] ?? null; let src = '';
  if (path && fs.existsSync(path)) src = fs.readFileSync(path, 'utf8');
  else if (!process.stdin.isTTY) { path = null; src = fs.readFileSync(0, 'utf8'); }
  else return 0;
  const file = fileLabel(path);
  const { toks, diags: lds } = lex(src); const diags = staticCheck(toks, lds);
  if (flags.has('--lex')) printLex(file, toks);
  if (flags.has('--ast')) printAst(file, src, toks);
  if (flags.has('--program')) printProgram(file, toks);
  if (diags.length) { for (const d of diags) printDiag(file, d); return diags.some(d=>d.panic)?127:2; }
  if (flags.has('--check')) return 0;
  return runScript(src);
}
process.exitCode = main();
