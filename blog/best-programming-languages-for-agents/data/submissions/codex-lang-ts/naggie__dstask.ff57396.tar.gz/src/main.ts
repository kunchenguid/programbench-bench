import * as fs from "fs";
import * as os from "os";
import * as path from "path";
import { spawnSync } from "child_process";

type Status = "pending" | "active" | "paused" | "resolved";
type Task = {
  uuid: string;
  status: Status;
  id: number;
  summary: string;
  notes: string;
  tags: string[];
  project: string;
  priority: string;
  created: string;
  resolved: string;
  due: string;
};

const zeroTime = "0001-01-01T00:00:00Z";
const statuses: Status[] = ["pending", "active", "paused", "resolved"];
const commands = new Set([
  "next", "add", "template", "log", "start", "note", "stop", "done", "context", "modify", "edit", "undo", "sync", "open", "git", "remove",
  "show-projects", "show-tags", "show-active", "show-paused", "show-open", "show-resolved", "show-templates", "show-unorganised",
  "bash-completion", "fish-completion", "zsh-completion", "powershell-completion", "help", "version"
]);

function repo(): string {
  return process.env.DSTASK_GIT_REPO || path.join(os.homedir(), ".dstask");
}

function ensureRepo() {
  const r = repo();
  fs.mkdirSync(r, { recursive: true });
  for (const s of statuses) fs.mkdirSync(path.join(r, s), { recursive: true });
  if (!fs.existsSync(path.join(r, ".git"))) {
    const res = spawnSync("git", ["init"], { cwd: r, encoding: "utf8" });
    if (res.stdout) process.stdout.write(res.stdout);
    if (res.stderr) process.stderr.write(res.stderr);
    console.log("\nAdd a remote repository with:\n\n\tdstask git remote add origin <repo>\n");
  }
}

function now(): string {
  return new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
}

function uuid(): string {
  const c: any = globalThis.crypto;
  if (c?.randomUUID) return c.randomUUID();
  const b = Array.from({ length: 16 }, () => Math.floor(Math.random() * 256));
  b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80;
  const h = b.map(x => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;
}

function quoteYaml(v: string): string {
  if (v === "") return '""';
  if (/[:#\n\r]|^\s|\s$/.test(v)) return JSON.stringify(v);
  return v;
}

function taskFile(t: Task): string {
  return path.join(repo(), t.status, `${t.uuid}.yml`);
}

function saveTask(t: Task) {
  fs.mkdirSync(path.dirname(taskFile(t)), { recursive: true });
  const tagLines = t.tags.length ? "\n" + t.tags.map(x => `- ${x}`).join("\n") : " []";
  const data =
`summary: ${quoteYaml(t.summary)}
notes: ${quoteYaml(t.notes)}
tags:${tagLines}
project: ${quoteYaml(t.project)}
priority: ${t.priority || "P2"}
delegatedto: ""
subtasks: []
dependencies: []
created: ${t.created}
resolved: ${t.resolved}
due: ${t.due}
`;
  fs.writeFileSync(taskFile(t), data);
}

function parseScalar(v: string): string {
  v = v.trim();
  if (v === '""' || v === "''") return "";
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
    try { return JSON.parse(v); } catch { return v.slice(1, -1); }
  }
  return v;
}

function parseTask(file: string, status: Status): Task {
  const lines = fs.readFileSync(file, "utf8").split(/\r?\n/);
  const get = (k: string) => {
    const l = lines.find(x => x.startsWith(k + ":"));
    return l ? parseScalar(l.slice(k.length + 1)) : "";
  };
  const tags: string[] = [];
  let inTags = false;
  for (const l of lines) {
    if (l.startsWith("tags:")) {
      inTags = true;
      const rest = l.slice(5).trim();
      if (rest === "[]") inTags = false;
      continue;
    }
    if (inTags) {
      if (l.startsWith("- ")) tags.push(parseScalar(l.slice(2)));
      else if (/^[a-zA-Z]/.test(l)) inTags = false;
    }
  }
  const base = path.basename(file).replace(/\.ya?ml$/, "");
  return {
    uuid: base, status, id: 0, summary: get("summary"), notes: get("notes"), tags,
    project: get("project"), priority: get("priority") || "P2", created: get("created") || zeroTime,
    resolved: get("resolved") || zeroTime, due: get("due") || zeroTime
  };
}

function readTasks(): Task[] {
  ensureRepo();
  const out: Task[] = [];
  for (const s of statuses) {
    const dir = path.join(repo(), s);
    if (!fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir).filter(x => /\.ya?ml$/.test(x))) out.push(parseTask(path.join(dir, f), s));
  }
  const idsPath = path.join(repo(), ".dstask-ids.json");
  let ids: Record<string, number> = {};
  if (fs.existsSync(idsPath)) {
    try { ids = JSON.parse(fs.readFileSync(idsPath, "utf8")); } catch {}
  }
  const used = new Set<number>();
  for (const t of out) {
    if (t.status !== "resolved" && ids[t.uuid]) { t.id = ids[t.uuid]; used.add(t.id); }
  }
  let next = 1;
  for (const t of out.sort((a, b) => a.created.localeCompare(b.created))) {
    if (t.status === "resolved") { t.id = 0; continue; }
    if (!t.id) { while (used.has(next)) next++; t.id = next; used.add(next); ids[t.uuid] = t.id; }
  }
  fs.writeFileSync(idsPath, JSON.stringify(ids, null, 2));
  return out;
}

function nextId(tasks: Task[]): number {
  const used = new Set(tasks.filter(t => t.status !== "resolved").map(t => t.id));
  let i = 1; while (used.has(i)) i++; return i;
}

function saveId(t: Task) {
  const p = path.join(repo(), ".dstask-ids.json");
  let ids: Record<string, number> = {};
  if (fs.existsSync(p)) { try { ids = JSON.parse(fs.readFileSync(p, "utf8")); } catch {} }
  ids[t.uuid] = t.id;
  fs.writeFileSync(p, JSON.stringify(ids, null, 2));
}

function priorityRank(p: string): number { return { P0: 0, P1: 1, P2: 2, P3: 3 }[p] ?? 2; }
function sortTasks(ts: Task[]): Task[] { return ts.sort((a, b) => priorityRank(a.priority) - priorityRank(b.priority) || a.created.localeCompare(b.created)); }
function printJson(x: any) { console.log(JSON.stringify(x, null, 2)); }

function parseAttrs(args: string[]) {
  const attrs: any = { tagsAdd: [] as string[], tagsDel: [] as string[], summary: [] as string[], note: [] as string[] };
  let inNote = false;
  for (const a of args) {
    if (a === "/") { inNote = true; continue; }
    if (inNote) { attrs.note.push(a); continue; }
    if (/^\+[A-Za-z0-9_.:-]+$/.test(a)) attrs.tagsAdd.push(a.slice(1));
    else if (/^-[A-Za-z0-9_.:-]+$/.test(a)) attrs.tagsDel.push(a.slice(1));
    else if (/^project:/.test(a)) attrs.project = a.slice(8);
    else if (/^-project:/.test(a)) attrs.project = "";
    else if (/^priority:P[0-3]$/.test(a)) attrs.priority = a.slice(9);
    else if (/^P[0-3]$/.test(a)) attrs.priority = a;
    else if (/^due:/.test(a)) attrs.due = a.slice(4) ? `${a.slice(4)}T00:00:00Z` : zeroTime;
    else if (/^template:\d+$/.test(a)) attrs.template = Number(a.slice(9));
    else attrs.summary.push(a);
  }
  return attrs;
}

function contextTokens(): string[] {
  const env = process.env.DSTASK_CONTEXT;
  if (env !== undefined) return env.trim() ? env.trim().split(/\s+/) : [];
  const p = path.join(repo(), "context");
  if (fs.existsSync(p)) return fs.readFileSync(p, "utf8").trim().split(/\s+/).filter(Boolean);
  return [];
}

function applyContextToAttrs(attrs: any, ignore: boolean) {
  if (ignore) return;
  for (const tok of contextTokens()) {
    if (tok.startsWith("+")) attrs.tagsAdd.push(tok.slice(1));
    else if (tok.startsWith("project:")) attrs.project = tok.slice(8);
  }
}

function matchFilter(t: Task, args: string[], ignoreContext = false): boolean {
  const toks = [...(ignoreContext ? [] : contextTokens()), ...args];
  const text: string[] = [];
  for (const a of toks) {
    if (a === "--") continue;
    if (a.startsWith("+")) {
      if (!t.tags.includes(a.slice(1))) return false;
      continue;
    }
    if (a.startsWith("-")) {
      if (t.tags.includes(a.slice(1))) return false;
      continue;
    }
    if (a.startsWith("project:")) {
      if (t.project !== a.slice(8)) return false;
      continue;
    }
    if (/^P[0-3]$/.test(a)) {
      if (t.priority !== a) return false;
      continue;
    }
    if (!commands.has(a)) text.push(a.toLowerCase());
  }
  const hay = (t.summary + " " + t.notes).toLowerCase();
  return text.every(x => hay.includes(x));
}

function commit(msg: string) {
  const r = repo();
  spawnSync("git", ["add", "."], { cwd: r });
  const res = spawnSync("git", ["commit", "-m", msg], { cwd: r, encoding: "utf8" });
  const out = (res.stdout || "") + (res.stderr || "");
  if (out.trim()) process.stderr.write("\x1b[38;5;245m" + out + "\x1b[0m");
}

function findByIds(ids: number[]): Task[] {
  const tasks = readTasks();
  return tasks.filter(t => ids.includes(t.id) && t.status !== "resolved");
}

function addTask(args: string[], resolved = false, templ = false) {
  const ignore = args.includes("--");
  args = args.filter(a => a !== "--");
  const tasks = readTasks();
  const attrs = parseAttrs(args);
  applyContextToAttrs(attrs, ignore);
  let base: Partial<Task> = {};
  if (attrs.template) {
    const src = tasks.find(t => t.id === attrs.template);
    if (src) base = { summary: src.summary, notes: src.notes, tags: [...src.tags], project: src.project, priority: src.priority, due: src.due };
  }
  const summary = attrs.summary.length ? attrs.summary.join(" ") : (base.summary || "");
  const t: Task = {
    uuid: uuid(), status: resolved ? "resolved" : "pending", id: resolved ? 0 : nextId(tasks),
    summary, notes: attrs.note.length ? attrs.note.join(" ") : (base.notes || ""),
    tags: Array.from(new Set([...(base.tags || []), ...attrs.tagsAdd, ...(templ ? ["template"] : [])])).filter(x => !attrs.tagsDel.includes(x)),
    project: attrs.project ?? base.project ?? "", priority: attrs.priority ?? base.priority ?? "P2",
    created: now(), resolved: resolved ? now() : zeroTime, due: attrs.due ?? base.due ?? zeroTime
  };
  saveTask(t); if (!resolved) saveId(t);
  console.log(`\n${resolved ? "Logged" : "Added"} ${t.id || 0}: ${t.summary}`);
  commit(`${resolved ? "Logged" : "Added"} ${t.id || 0}: ${t.summary}`);
}

function list(kind: string, filterArgs: string[], ignore: boolean) {
  let ts = readTasks();
  if (kind === "open" || kind === "next") ts = ts.filter(t => t.status !== "resolved");
  if (kind === "active") ts = ts.filter(t => t.status === "active");
  if (kind === "paused") ts = ts.filter(t => t.status === "paused");
  if (kind === "resolved") ts = ts.filter(t => t.status === "resolved");
  if (kind === "templates") ts = ts.filter(t => t.tags.includes("template") && t.status !== "resolved");
  if (kind === "unorganised") ts = ts.filter(t => t.status !== "resolved" && !t.project && t.tags.length === 0);
  ts = sortTasks(ts.filter(t => matchFilter(t, filterArgs, ignore)));
  printJson(ts);
}

function move(ids: number[], status: Status, word: string) {
  for (const t of findByIds(ids)) {
    const old = taskFile(t);
    if (status === "resolved") t.resolved = now();
    t.status = status;
    if (fs.existsSync(old)) fs.unlinkSync(old);
    saveTask(t);
    console.log(`\n${word} ${t.id}: ${t.summary}`);
    commit(`${word} ${t.id}: ${t.summary}`);
  }
}

function modify(ids: number[], args: string[]) {
  for (const t of findByIds(ids)) {
    const attrs = parseAttrs(args);
    t.tags = t.tags.filter(x => !attrs.tagsDel.includes(x));
    for (const tag of attrs.tagsAdd) if (!t.tags.includes(tag)) t.tags.push(tag);
    if (attrs.project !== undefined) t.project = attrs.project;
    if (attrs.priority) t.priority = attrs.priority;
    if (attrs.due) t.due = attrs.due;
    saveTask(t);
    console.log(`\nModified ${t.id}: ${t.summary}`);
    commit(`Modified ${t.id}: ${t.summary}`);
  }
}

function removeTasks(ids: number[]) {
  for (const t of findByIds(ids)) {
    const f = taskFile(t);
    if (fs.existsSync(f)) fs.unlinkSync(f);
    console.log(`\nRemoved ${t.id}: ${t.summary}`);
    commit(`Removed ${t.id}: ${t.summary}`);
  }
}

function note(ids: number[], args: string[]) {
  for (const t of findByIds(ids)) {
    if (args.length) {
      t.notes = t.notes ? `${t.notes}\n${args.join(" ")}` : args.join(" ");
      saveTask(t);
      console.log(`\nModified ${t.id}: ${t.summary}`);
      commit(`Modified ${t.id}: ${t.summary}`);
    } else {
      console.log(t.notes);
    }
  }
}

function showTags() {
  const counts: Record<string, number> = {};
  for (const t of readTasks().filter(x => x.status !== "resolved")) for (const tag of t.tags) counts[tag] = (counts[tag] || 0) + 1;
  Object.keys(counts).sort((a, b) => counts[b] - counts[a] || a.localeCompare(b)).forEach(x => console.log(x));
}

function showProjects() {
  const by: Record<string, Task[]> = {};
  for (const t of readTasks().filter(x => x.project)) (by[t.project] ||= []).push(t);
  const rows = Object.entries(by).map(([name, ts]) => {
    const open = sortTasks(ts.filter(t => t.status !== "resolved"));
    const all = sortTasks(ts);
    const first = open[0] || all[0];
    return { name, taskCount: ts.length, resolvedCount: ts.filter(t => t.status === "resolved").length,
      active: ts.some(t => t.status === "active"), created: first.created, resolved: first.resolved, priority: first.priority };
  }).sort((a, b) => priorityRank(a.priority) - priorityRank(b.priority) || a.name.localeCompare(b.name));
  printJson(rows);
}

function help(cmd?: string) {
  if (cmd === "add") console.log("Usage: dstask add [template:<id>] [task summary] [--]\nExample: dstask add Fix main web page 500 error +bug P1 project:website\n\nAdd a task, returning the git commit output which contains the task ID, used\nlater to reference the task.");
  else if (cmd === "context") console.log('Usage: dstask context <filter>\nExample: dstask context +work -bug\nExample: dstask context none\n\nSet a global filter consisting of a project, tags or antitags.');
  else if (cmd === "note") console.log("Usage: dstask note <id>\nUsage: dstask note <id> <text>\n\nEdit or append text to the markdown notes attached to a particular task.");
  else console.log(`Usage: dstask [id...] <cmd> [task summary/filter]

Available commands:

next              : Show most important tasks (priority, creation date -- truncated and default)
add               : Add a task
template          : Add a task template
log               : Log a task (already resolved)
start             : Change task status to active
note              : Append to or edit note for a task
stop              : Change task status to pending
done              : Resolve a task
context           : Set global context for task list and new tasks (use "none" to set no context)
modify            : Change task attributes specified on command line
edit              : Edit task with text editor
undo              : Undo last n commits
sync              : Pull then push to git repository, automatic merge commit.
open              : Open all URLs found in summary/annotations
git               : Pass a command to git in the repository. Used for push/pull.
remove            : Remove a task (use to remove tasks added by mistake)
show-projects     : List projects with completion status
show-tags         : List tags in use
show-active       : Show tasks that have been started
show-paused       : Show tasks that have been started then stopped
show-open         : Show all non-resolved tasks (without truncation)
show-resolved     : Show resolved tasks
show-templates    : Show task templates
show-unorganised  : Show untagged tasks with no projects (global context)
bash-completion   : Print bash completion script to stdout
fish-completion   : Print fish completion script to stdout
zsh-completion    : Print zsh completion script to stdout
help              : Get help on any command or show this message
version           : Show dstask version information`);
}

function main() {
  let args = process.argv.slice(2);
  if (args[0] === "--help" || args[0] === "-h") return help();
  let ignore = false;
  if (args[0] === "--") { ignore = true; args = args.slice(1); }
  const ids: number[] = [];
  while (args[0] && /^\d+$/.test(args[0])) ids.push(Number(args.shift()));
  let cmd = args[0] && commands.has(args[0]) ? args.shift()! : "next";
  while (args[0] && /^\d+$/.test(args[0])) ids.push(Number(args.shift()));
  if (args.includes("--")) { ignore = true; args = args.filter(a => a !== "--"); }

  if (cmd === "help" || cmd === "--help" || cmd === "-h") return help(args[0]);
  if (cmd === "version") return console.log("Version: Unknown\nGit commit: Unknown\nBuild date: Unknown");
  if (cmd.endsWith("-completion") || cmd === "powershell-completion") return console.log(`# ${cmd} for dstask`);
  ensureRepo();
  if (cmd === "add") return addTask(args);
  if (cmd === "template") return addTask([...args, "+template"]);
  if (cmd === "log") return addTask(args, true);
  if (cmd === "next" || cmd === "show-open") return list("open", args, ignore);
  if (cmd === "show-active") return list("active", args, ignore);
  if (cmd === "show-paused") return list("paused", args, ignore);
  if (cmd === "show-resolved") return list("resolved", args, true);
  if (cmd === "show-templates") return list("templates", args, ignore);
  if (cmd === "show-unorganised") return list("unorganised", args, true);
  if (cmd === "show-tags") return showTags();
  if (cmd === "show-projects") return showProjects();
  if (cmd === "start") return move(ids, "active", "Started");
  if (cmd === "stop") return move(ids, "paused", "Stopped");
  if (cmd === "done") return move(ids, "resolved", "Resolved");
  if (cmd === "remove") return removeTasks(ids);
  if (cmd === "modify") return modify(ids.length ? ids : readTasks().filter(t => t.status !== "resolved" && matchFilter(t, [], ignore)).map(t => t.id), args);
  if (cmd === "note") return note(ids, args);
  if (cmd === "context") {
    const val = args.join(" ");
    if (!val || val === "none" || val === "--") { fs.writeFileSync(path.join(repo(), "context"), ""); console.log("Context cleared"); }
    else if (args.some(a => !a.startsWith("+") && !a.startsWith("-") && !a.startsWith("project:"))) console.error("\x1b[31mcontext cannot contain text\x1b[0m");
    else { fs.writeFileSync(path.join(repo(), "context"), val); console.log(`Context set to ${val}`); }
    return;
  }
  if (cmd === "git") {
    const res = spawnSync("git", args, { cwd: repo(), stdio: "inherit" });
    process.exit(res.status ?? 0);
  }
  if (cmd === "sync") {
    spawnSync("git", ["pull"], { cwd: repo(), stdio: "inherit" });
    const res = spawnSync("git", ["push"], { cwd: repo(), stdio: "inherit" });
    process.exit(res.status ?? 0);
  }
  if (cmd === "undo") {
    const n = args[0] || "1";
    spawnSync("git", ["reset", "--hard", `HEAD~${n}`], { cwd: repo(), stdio: "inherit" });
    return;
  }
  if (cmd === "open") return;
  help();
}

main();
