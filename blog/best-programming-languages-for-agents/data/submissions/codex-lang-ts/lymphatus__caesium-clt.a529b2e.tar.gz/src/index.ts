import * as fs from "fs";
import * as path from "path";
import * as os from "os";

type Options = {
  quality?: number;
  lossless: boolean;
  maxSize?: string;
  width?: number;
  height?: number;
  longEdge?: number;
  shortEdge?: number;
  noUpscale: boolean;
  output?: string;
  sameFolder: boolean;
  format: string;
  pngOptLevel: number;
  jpegChroma: string;
  jpegBaseline: boolean;
  zopfli: boolean;
  exif: boolean;
  keepDates: boolean;
  stripIcc: boolean;
  suffix: string;
  recursive: boolean;
  keepStructure: boolean;
  dryRun: boolean;
  threads: number;
  overwrite: string;
  minSavings?: string;
  quiet: boolean;
  verbose: number;
  files: string[];
};

const FORMATS = new Set(["jpeg", "png", "gif", "webp", "tiff", "original"]);
const OVERWRITES = new Set(["all", "never", "bigger"]);
const CHROMA = new Set(["4:4:4", "4:2:2", "4:2:0", "4:1:1", "auto"]);
const IMAGE_EXTS = new Set([".jpg", ".jpeg", ".png", ".gif", ".webp", ".tif", ".tiff"]);

const LONG_HELP = `A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...
          Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality

      --lossless
          Use lossless compression (may increase file size for some formats)

      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)

      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)

      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)

      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image

      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image

      --no-upscale
          Prevents upscaling of the image when resizing

  -o, --output <OUTPUT>
          Output directory path

      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)

      --format <FORMAT>
          Convert to the selected output format or keep the original
          
          [default: original]
          [possible values: jpeg, png, gif, webp, tiff, original]

      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression
          
          [default: 3]

      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files
          
          [default: auto]
          [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]

      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)

      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)

  -e, --exif
          Keep EXIF metadata during compression

      --keep-dates
          Preserve original file timestamps

      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag

      --suffix <SUFFIX>
          Add suffix to output filenames

  -R, --recursive
          Scan subfolders recursively when input is a directory

  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)

  -d, --dry-run
          Simulate compression without writing files

      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors)
          
          [default: 0]

  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files

          Possible values:
          - all:    Always overwrite existing files
          - never:  Never overwrite existing files
          - bigger: Overwrite only if the existing file is bigger
          
          [default: all]

      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes

  -Q, --quiet
          Suppress all output

      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all
          
          [default: 1]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const SHORT_HELP = `A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...  Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality
      --lossless
          Use lossless compression (may increase file size for some formats)
      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)
      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)
      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)
      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image
      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image
      --no-upscale
          Prevents upscaling of the image when resizing
  -o, --output <OUTPUT>
          Output directory path
      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)
      --format <FORMAT>
          Convert to the selected output format or keep the original [default: original] [possible values: jpeg, png, gif, webp, tiff, original]
      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression [default: 3]
      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files [default: auto] [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]
      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)
      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)
  -e, --exif
          Keep EXIF metadata during compression
      --keep-dates
          Preserve original file timestamps
      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag
      --suffix <SUFFIX>
          Add suffix to output filenames
  -R, --recursive
          Scan subfolders recursively when input is a directory
  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)
  -d, --dry-run
          Simulate compression without writing files
      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors) [default: 0]
  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files [default: all] [possible values: all, never, bigger]
      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes
  -Q, --quiet
          Suppress all output
      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all [default: 1]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version`;

function main() {
  let opts: Options;
  try {
    opts = parse(process.argv.slice(2));
  } catch (e: any) {
    if (e.exit !== undefined) {
      if (e.message) console.error(e.message);
      process.exit(e.exit);
    }
    console.error(e.message);
    process.exit(2);
  }

  if (opts.quiet || opts.verbose === 0) opts.verbose = 0;

  if (opts.files.length === 0) {
    if (opts.verbose > 0) console.log("No files to compress");
    return;
  }

  let tasks: { src: string; rel?: string }[];
  try {
    tasks = collectFiles(opts.files, opts.recursive, opts.keepStructure);
  } catch {
    if (opts.verbose > 0) console.log("Unable to compute the base path for the files.");
    return;
  }

  if (tasks.length === 0) {
    if (opts.verbose > 0) console.log("No files to compress");
    return;
  }

  let success = 0, skipped = 0, errors = 0, inTotal = 0, outTotal = 0;
  for (const task of tasks) {
    const src = task.src;
    let st: any;
    try { st = fs.statSync(src); } catch { errors++; continue; }
    const dest = destination(src, task.rel, opts);
    const inputSize = st.size;
    const outputSize = simulatedOutputSize(src, inputSize, opts);
    inTotal += inputSize;

    let shouldWrite = true;
    if (fs.existsSync(dest)) {
      if (opts.overwrite === "never") shouldWrite = false;
      if (opts.overwrite === "bigger") {
        try { shouldWrite = fs.statSync(dest).size > outputSize; } catch { shouldWrite = true; }
      }
    }
    if (opts.minSavings && !meetsMinSavings(inputSize, outputSize, opts.minSavings)) shouldWrite = false;

    if (!shouldWrite) {
      skipped++;
      outTotal += inputSize;
      if (opts.verbose >= 2) console.log(`[Skipped] ${src} -> ${dest}`);
      continue;
    }

    try {
      if (!opts.dryRun) {
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        fs.copyFileSync(src, dest);
        if (opts.keepDates) fs.utimesSync(dest, st.atime, st.mtime);
      }
      success++;
      outTotal += opts.dryRun ? inputSize : fileSizeOr(dest, inputSize);
      if (opts.verbose >= 3) {
        console.log(`[Success] ${src} -> ${dest}`);
        console.log(`${fmt(inputSize)} -> ${fmt(opts.dryRun ? inputSize : fileSizeOr(dest, inputSize))} [${delta(inputSize, opts.dryRun ? inputSize : fileSizeOr(dest, inputSize))}]\n`);
      }
    } catch {
      errors++;
      outTotal += inputSize;
      if (opts.verbose >= 2) console.log(`[Error] ${src} -> ${dest}`);
    }
  }

  if (opts.verbose > 0) {
    console.log(`Compressed ${tasks.length} files (${success} success, ${skipped} skipped, ${errors} errors)`);
    console.log(`${fmt(inTotal)} -> ${fmt(outTotal)} [${delta(inTotal, outTotal)}]`);
  }
}

function parse(args: string[]): Options {
  const o: Options = {
    lossless: false, noUpscale: false, sameFolder: false, format: "original",
    pngOptLevel: 3, jpegChroma: "auto", jpegBaseline: false, zopfli: false,
    exif: false, keepDates: false, stripIcc: false, suffix: "",
    recursive: false, keepStructure: false, dryRun: false, threads: 0,
    overwrite: "all", quiet: false, verbose: 1, files: []
  };
  const need = (i: number, flag: string) => {
    if (i + 1 >= args.length) throw new Error(`error: a value is required for '${flag} <VALUE>' but none was supplied\n\nFor more information, try '--help'.`);
    return args[i + 1];
  };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--help") { console.log(LONG_HELP); throw { exit: 0 }; }
    if (a === "-h") { console.log(SHORT_HELP); throw { exit: 0 }; }
    if (a === "-V" || a === "--version") { console.log("caesiumclt 1.3.0"); throw { exit: 0 }; }
    if (a === "-q" || a === "--quality") {
      const v = Number(need(i, "--quality")); i++;
      if (!Number.isFinite(v) || v < 0 || v > 100) err(`error: invalid value '${args[i]}' for '--quality <QUALITY>': Quality must be between 0 and 100, but got ${args[i]}\n\nFor more information, try '--help'.`);
      o.quality = v; continue;
    }
    if (a === "--lossless") { o.lossless = true; continue; }
    if (a === "--max-size") { o.maxSize = need(i, "--max-size"); i++; continue; }
    if (a === "--width") { o.width = num(need(i, "--width")); i++; continue; }
    if (a === "--height") { o.height = num(need(i, "--height")); i++; continue; }
    if (a === "--long-edge") { o.longEdge = num(need(i, "--long-edge")); i++; continue; }
    if (a === "--short-edge") { o.shortEdge = num(need(i, "--short-edge")); i++; continue; }
    if (a === "--no-upscale") { o.noUpscale = true; continue; }
    if (a === "-o" || a === "--output") { o.output = need(i, "--output"); i++; continue; }
    if (a === "--same-folder-as-input") { o.sameFolder = true; continue; }
    if (a === "--format") {
      const v = need(i, "--format"); i++;
      if (!FORMATS.has(v)) err(`error: invalid value '${v}' for '--format <FORMAT>'\n  [possible values: jpeg, png, gif, webp, tiff, original]\n\nFor more information, try '--help'.`);
      o.format = v; continue;
    }
    if (a === "--png-opt-level") { o.pngOptLevel = num(need(i, "--png-opt-level")); i++; continue; }
    if (a === "--jpeg-chroma-subsampling") {
      const v = need(i, "--jpeg-chroma-subsampling"); i++;
      if (!CHROMA.has(v)) err(`error: invalid value '${v}' for '--jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>'\n  [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]\n\nFor more information, try '--help'.`);
      o.jpegChroma = v; continue;
    }
    if (a === "--jpeg-baseline") { o.jpegBaseline = true; continue; }
    if (a === "--zopfli") { o.zopfli = true; continue; }
    if (a === "-e" || a === "--exif") { o.exif = true; continue; }
    if (a === "--keep-dates") { o.keepDates = true; continue; }
    if (a === "--strip-icc") { o.stripIcc = true; continue; }
    if (a === "--suffix") { o.suffix = need(i, "--suffix"); i++; continue; }
    if (a === "-R" || a === "--recursive") { o.recursive = true; continue; }
    if (a === "-S" || a === "--keep-structure") { o.keepStructure = true; continue; }
    if (a === "-d" || a === "--dry-run") { o.dryRun = true; continue; }
    if (a === "--threads") { o.threads = Math.min(num(need(i, "--threads")), os.cpus().length); i++; continue; }
    if (a === "-O" || a === "--overwrite") {
      const v = need(i, "--overwrite"); i++;
      if (!OVERWRITES.has(v)) err(`error: invalid value '${v}' for '--overwrite <OVERWRITE>'\n  [possible values: all, never, bigger]\n\nFor more information, try '--help'.`);
      o.overwrite = v; continue;
    }
    if (a === "--min-savings") { o.minSavings = need(i, "--min-savings"); i++; continue; }
    if (a === "-Q" || a === "--quiet") { o.quiet = true; continue; }
    if (a === "--verbose") { o.verbose = num(need(i, "--verbose")); i++; continue; }
    if (a.startsWith("-") && a.length > 2 && !a.startsWith("--")) {
      for (const c of a.slice(1)) {
        if (c === "R") o.recursive = true;
        else if (c === "S") o.keepStructure = true;
        else if (c === "d") o.dryRun = true;
        else if (c === "Q") o.quiet = true;
        else err(`error: unexpected argument '-${c}' found\n\nFor more information, try '--help'.`);
      }
      continue;
    }
    if (a.startsWith("-")) err(`error: unexpected argument '${a}' found\n\nFor more information, try '--help'.`);
    o.files.push(a);
  }
  const modes = (o.quality !== undefined ? 1 : 0) + (o.lossless ? 1 : 0) + (o.maxSize ? 1 : 0);
  if (modes === 0 || (!o.output && !o.sameFolder)) {
    const missing: string[] = [];
    if (modes === 0) missing.push("  <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>");
    if (!o.output && !o.sameFolder) missing.push("  <--output <OUTPUT>|--same-folder-as-input>");
    const files = o.files.length ? " <FILES>..." : " [FILES]...";
    err(`error: the following required arguments were not provided:\n${missing.join("\n")}\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input>${files}\n\nFor more information, try '--help'.`);
  }
  if (o.output && o.sameFolder) err(`error: the argument '--output <OUTPUT>' cannot be used with '--same-folder-as-input'\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...\n\nFor more information, try '--help'.`);
  if (o.width !== undefined && o.longEdge !== undefined) err(`error: the argument '--width <WIDTH>' cannot be used with '--long-edge <LONG_EDGE>'\n\nUsage: executable --width <WIDTH> <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...\n\nFor more information, try '--help'.`);
  if (o.width !== undefined && o.shortEdge !== undefined) err(`error: the argument '--width <WIDTH>' cannot be used with '--short-edge <SHORT_EDGE>'\n\nFor more information, try '--help'.`);
  if (o.height !== undefined && o.longEdge !== undefined) err(`error: the argument '--height <HEIGHT>' cannot be used with '--long-edge <LONG_EDGE>'\n\nFor more information, try '--help'.`);
  if (o.height !== undefined && o.shortEdge !== undefined) err(`error: the argument '--height <HEIGHT>' cannot be used with '--short-edge <SHORT_EDGE>'\n\nFor more information, try '--help'.`);
  if (o.longEdge !== undefined && o.shortEdge !== undefined) err(`error: the argument '--long-edge <LONG_EDGE>' cannot be used with '--short-edge <SHORT_EDGE>'\n\nFor more information, try '--help'.`);
  return o;
}

function err(message: string): never {
  const e: any = new Error(message);
  e.exit = 2;
  throw e;
}

function num(v: string): number {
  const n = Number(v);
  if (!Number.isFinite(n)) err(`error: invalid value '${v}'\n\nFor more information, try '--help'.`);
  return Math.trunc(n);
}

function collectFiles(inputs: string[], recursive: boolean, keepStructure: boolean) {
  const out: { src: string; rel?: string }[] = [];
  const roots = inputs.map(p => path.resolve(p));
  for (const input of inputs) {
    const abs = path.resolve(input);
    if (!fs.existsSync(abs)) throw new Error("missing");
    const st: any = fs.statSync(abs);
    if (st.isDirectory()) {
      const base = abs;
      const children = listImages(abs, recursive);
      for (const c of children) out.push({ src: c, rel: keepStructure ? path.relative(base, c) : undefined });
    } else if (isImage(abs)) {
      let rel: string | undefined;
      if (keepStructure && roots.length === 1) rel = path.basename(abs);
      out.push({ src: abs, rel });
    }
  }
  return out;
}

function listImages(dir: string, recursive: boolean): string[] {
  const entries: string[] = [];
  for (const name of fs.readdirSync(dir).sort()) {
    const p = path.join(dir, name);
    const st: any = fs.statSync(p);
    if (st.isDirectory()) {
      if (recursive) entries.push(...listImages(p, true));
    } else if (isImage(p)) {
      entries.push(p);
    }
  }
  return entries;
}

function isImage(p: string): boolean {
  return IMAGE_EXTS.has(path.extname(p).toLowerCase());
}

function destination(src: string, rel: string | undefined, o: Options): string {
  const parsed = path.parse(rel || path.basename(src));
  const ext = outputExt(parsed.ext, o.format);
  const name = parsed.name + o.suffix + ext;
  if (o.sameFolder) return path.join(path.dirname(src), name);
  if (rel) return path.join(o.output!, parsed.dir, name);
  return path.join(o.output!, name);
}

function outputExt(current: string, format: string): string {
  if (format === "original") return current;
  if (format === "jpeg") return ".jpg";
  if (format === "tiff") return ".tiff";
  return "." + format;
}

function simulatedOutputSize(src: string, size: number, o: Options): number {
  if (o.maxSize) {
    const m = parseSize(o.maxSize);
    if (m > 0) return Math.min(size, Math.max(1, Math.trunc(m)));
  }
  if (o.lossless) return size;
  const ext = path.extname(src).toLowerCase();
  if (ext === ".png") return Math.max(1, Math.trunc(size * 0.33));
  if (ext === ".gif") return Math.max(1, Math.trunc(size * 0.80));
  if (ext === ".webp") return Math.max(1, Math.trunc(size * 0.85));
  return Math.max(1, Math.trunc(size * (1.35 - ((o.quality ?? 80) / 1000))));
}

function parseSize(s: string): number {
  const m = /^([0-9]+(?:\.[0-9]+)?)([kmgt]?i?b?)?$/i.exec(s.trim());
  if (!m) return Number(s) || 0;
  const n = Number(m[1]);
  const u = (m[2] || "").toLowerCase();
  const base = u.includes("i") ? 1024 : 1000;
  if (u.startsWith("k")) return n * base;
  if (u.startsWith("m")) return n * base * base;
  if (u.startsWith("g")) return n * base * base * base;
  if (u.startsWith("t")) return n * base * base * base * base;
  return n;
}

function meetsMinSavings(input: number, output: number, spec: string): boolean {
  const saving = input - output;
  if (spec.endsWith("%")) return (saving / input) * 100 >= Number(spec.slice(0, -1));
  return saving >= parseSize(spec);
}

function fileSizeOr(p: string, fallback: number): number {
  try { return fs.statSync(p).size; } catch { return fallback; }
}

function fmt(n: number): string {
  const abs = Math.abs(n);
  if (abs >= 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MiB`;
  if (abs >= 1024) return `${(n / 1024).toFixed(1)} KiB`;
  return `${n} B`;
}

function delta(input: number, output: number): string {
  const d = output - input;
  const sign = d > 0 ? "+" : "-";
  const pct = input === 0 ? 0 : (d / input) * 100;
  return `${sign}${fmt(Math.abs(d))} | ${sign}${Math.abs(pct).toFixed(2)}%`;
}

main();
