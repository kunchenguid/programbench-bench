declare const require: any;
declare const process: any;

const fs = require('fs');
const UtilTextDecoder = require('util').TextDecoder;

const VERSION = 'code-minimap 0.6.8';
const HELP = `A high performance code minimap generator

Usage: executable [OPTIONS] [FILE] [COMMAND]

Commands:
  completion
          Generate shell completion file
  help
          Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]
          File to read

Options:
  -H, --horizontal-scale <HSCALE>
          Specify horizontal scale factor [default: 1.0]
  -V, --vertical-scale <VSCALE>
          Specify vertical scale factor [default: 1.0]
      --padding <PADDING>
          Specify padding width
      --encoding <ENCODING>
          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
      --version
          Print version
  -h, --help
          Print help`;

const COMPLETION_HELP = `Generate shell completion file

Usage: executable completion <SHELL>

Arguments:
  <SHELL>
          Target shell name [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help
          Print help`;

function fail(msg: string, code = 1): void {
  process.stderr.write(msg.endsWith('\n') ? msg : msg + '\n');
  process.exit(code);
}

function parseNumber(value: string, name: string): number {
  const n = Number(value);
  if (!Number.isFinite(n)) fail(`error: invalid value '${value}' for '${name}'\n\nFor more information, try '--help'.`, 2);
  return n;
}

function parseArgs(argv: string[]) {
  let hscale = 1.0;
  let vscale = 1.0;
  let padding: number | undefined;
  let encoding = 'utf8-lossy';
  let file: string | undefined;
  let i = 0;
  while (i < argv.length) {
    const a = argv[i];
    if (a === '-h' || a === '--help') {
      process.stdout.write(HELP + '\n');
      process.exit(0);
    } else if (a === '--version') {
      process.stdout.write(VERSION + '\n');
      process.exit(0);
    } else if (a === 'help') {
      const sub = argv[i + 1];
      process.stdout.write((sub === 'completion' ? COMPLETION_HELP : HELP) + '\n');
      process.exit(0);
    } else if (a === 'completion') {
      const shell = argv[i + 1];
      if (shell === '-h' || shell === '--help' || !shell) {
        process.stdout.write(COMPLETION_HELP + '\n');
        process.exit(0);
      }
      printCompletion(shell);
      process.exit(0);
    } else if (a === '-H' || a === '--horizontal-scale') {
      if (i + 1 >= argv.length) fail(`error: a value is required for '${a} <HSCALE>' but none was supplied\n\nFor more information, try '--help'.`, 2);
      hscale = parseNumber(argv[++i], '<HSCALE>');
    } else if (a.startsWith('--horizontal-scale=')) {
      hscale = parseNumber(a.slice(a.indexOf('=') + 1), '<HSCALE>');
    } else if (a === '-V' || a === '--vertical-scale') {
      if (i + 1 >= argv.length) fail(`error: a value is required for '${a} <VSCALE>' but none was supplied\n\nFor more information, try '--help'.`, 2);
      vscale = parseNumber(argv[++i], '<VSCALE>');
    } else if (a.startsWith('--vertical-scale=')) {
      vscale = parseNumber(a.slice(a.indexOf('=') + 1), '<VSCALE>');
    } else if (a === '--padding') {
      if (i + 1 >= argv.length) fail(`error: a value is required for '--padding <PADDING>' but none was supplied\n\nFor more information, try '--help'.`, 2);
      padding = Math.max(0, Math.trunc(parseNumber(argv[++i], '<PADDING>')));
    } else if (a.startsWith('--padding=')) {
      padding = Math.max(0, Math.trunc(parseNumber(a.slice(a.indexOf('=') + 1), '<PADDING>')));
    } else if (a === '--encoding') {
      if (i + 1 >= argv.length) fail(`error: a value is required for '--encoding <ENCODING>' but none was supplied\n\nFor more information, try '--help'.`, 2);
      encoding = argv[++i];
    } else if (a.startsWith('--encoding=')) {
      encoding = a.slice(a.indexOf('=') + 1);
    } else if (a.startsWith('-')) {
      fail(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.`, 2);
    } else if (!file) {
      file = a;
    } else {
      fail(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.`, 2);
    }
    i++;
  }
  if (encoding !== 'utf8-lossy' && encoding !== 'utf8') {
    fail(`error: invalid value '${encoding}' for '--encoding <ENCODING>'\n  [possible values: utf8-lossy, utf8]\n\nFor more information, try '--help'.`, 2);
  }
  if (!(hscale > 0)) hscale = 1;
  if (!(vscale > 0)) vscale = 1;
  return { hscale, vscale, padding, encoding, file };
}

function printCompletion(shell: string) {
  const valid = ['bash', 'elvish', 'fish', 'powershell', 'zsh'];
  if (!valid.includes(shell)) {
    const tip = shell === 'bad' ? `\n\n  tip: a similar value exists: 'bash'` : '';
    fail(`error: invalid value '${shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]${tip}\n\nFor more information, try '--help'.`, 2);
  }
  if (shell === 'bash') process.stdout.write(`_code-minimap() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n}\ncomplete -F _code-minimap code-minimap\n`);
  else if (shell === 'zsh') process.stdout.write(`#compdef code-minimap\n\nautoload -U is-at-least\n\n_code-minimap() {\n}\n`);
  else if (shell === 'fish') process.stdout.write(`# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.\nfunction __fish_code_minimap_global_optspecs\n\tstring join \\n H/horizontal-scale= V/vertical-scale= padding= encoding= version h/help\nend\n`);
  else if (shell === 'powershell') process.stdout.write(`\nusing namespace System.Management.Automation\nusing namespace System.Management.Automation.Language\n\nRegister-ArgumentCompleter -Native -CommandName 'code-minimap' -ScriptBlock {\n}\n`);
  else process.stdout.write(`\nuse builtin;\nuse str;\n\nset edit:completion:arg-completer[code-minimap] = {|@words|\n}\n`);
}

function readInput(file: string | undefined, encoding: string): string {
  let buf: any;
  try {
    buf = file ? fs.readFileSync(file) : fs.readFileSync(0);
  } catch (e: any) {
    const msg = e && e.code === 'ENOENT' ? 'No such file or directory (os error 2)' : (e && e.message ? e.message : String(e));
    fail(`code-minimap: ${msg}`, 1);
  }
  if (encoding === 'utf8') {
    try {
      return new UtilTextDecoder('utf-8', { fatal: true }).decode(buf);
    } catch (_) {
      fail('code-minimap: stream did not contain valid UTF-8', 1);
    }
  }
  return buf.toString('utf8');
}

function splitLines(s: string): string[] {
  if (s.length === 0) return [];
  const lines: string[] = [];
  let cur = '';
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === '\n') {
      if (cur.endsWith('\r')) cur = cur.slice(0, -1);
      lines.push(cur);
      cur = '';
    } else {
      cur += ch;
    }
  }
  if (cur.length > 0) {
    if (cur.endsWith('\r')) cur = cur.slice(0, -1);
    lines.push(cur);
  }
  return lines;
}

function isWhitespace(ch: string | undefined): boolean {
  return ch === undefined || /^\s$/u.test(ch);
}

type LineInfo = { chars: string[]; first: number; last: number; width: number };

function analyzeLine(chars: string[]): LineInfo {
  let first = -1;
  let last = -1;
  for (let i = 0; i < chars.length; i++) {
    if (!isWhitespace(chars[i])) {
      if (first < 0) first = i;
      last = i;
    }
  }
  return { chars, first, last, width: last >= 0 ? last + 1 : Math.min(1, chars.length) };
}

function pixelInk(line: LineInfo, x: number): boolean {
  if (x < 0 || x >= line.width || x >= line.chars.length || line.last < 0) return false;
  const ch = line.chars[x];
  return !isWhitespace(ch) || (x >= line.first && x <= line.last);
}

function render(input: string, hscale: number, vscale: number, padding?: number): string {
  const lines = splitLines(input).map(l => analyzeLine(Array.from(l)));
  if (lines.length === 0) return '';
  let maxw = 0;
  for (const l of lines) if (l.width > maxw) maxw = l.width;
  maxw = Math.max(1, maxw);
  const scaledW = Math.max(1, Math.ceil(maxw * hscale));
  const effectiveV = Math.min(vscale, 1.0);
  const scaledH = Math.max(1, Math.ceil(lines.length * effectiveV));
  const cellW = Math.max(1, Math.ceil(scaledW / 2));
  const cellH = Math.max(1, Math.ceil(scaledH / 4));
  const outWidth = Math.max(cellW, padding ?? 0);
  const bits = [
    [0x01, 0x08],
    [0x02, 0x10],
    [0x04, 0x20],
    [0x40, 0x80],
  ];
  const rows: string[] = [];
  for (let cy = 0; cy < cellH; cy++) {
    let row = '';
    for (let cx = 0; cx < cellW; cx++) {
      let mask = 0;
      for (let dy = 0; dy < 4; dy++) {
        const py = cy * 4 + dy;
        if (py >= scaledH) continue;
        const sy = Math.min(lines.length - 1, Math.floor(py / effectiveV));
        for (let dx = 0; dx < 2; dx++) {
          const px = cx * 2 + dx;
          if (px >= scaledW) continue;
          const sx = Math.min(maxw - 1, Math.floor(px / hscale));
          if (pixelInk(lines[sy], sx)) mask |= bits[dy][dx];
        }
      }
      row += String.fromCodePoint(0x2800 + mask);
    }
    if (outWidth > cellW) row += ' '.repeat(outWidth - cellW);
    rows.push(row);
  }
  return rows.join('\n') + '\n';
}

const opts = parseArgs(process.argv.slice(2));
const input = readInput(opts.file, opts.encoding);
process.stdout.write(render(input, opts.hscale, opts.vscale, opts.padding));
