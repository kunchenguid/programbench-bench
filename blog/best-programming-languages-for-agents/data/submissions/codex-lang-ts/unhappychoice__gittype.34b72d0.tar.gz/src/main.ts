declare const process: {
  argv: string[];
  exit(code?: number): never;
  stdout: { write(s: string): void; isTTY?: boolean };
  stderr: { write(s: string): void; isTTY?: boolean };
  env: Record<string, string | undefined>;
};

const supportedLangs = new Set([
  "rust", "rs", "typescript", "ts", "javascript", "js",
  "python", "py", "ruby", "rb", "go", "swift",
  "kotlin", "kt", "java", "php", "csharp", "cs",
  "c#", "c", "cpp", "c++", "haskell", "hs",
  "dart", "scala", "sc", "zig", "clojure", "clj", "cljs",
]);

function out(s = ""): void {
  process.stdout.write(s + "\n");
}

function err(s = ""): void {
  process.stderr.write(s + "\n");
}

function exit(code: number): never {
  process.exit(code);
}

const longHelp = `GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. 

Examples:
  gittype                           # Use current directory
  gittype /path/to/repo             # Use specific repository
  gittype --repo owner/repo         # Clone and use GitHub repository
  gittype --langs rust,python       # Filter by languages

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]
          Repository path to extract code from

Options:
      --repo <REPO>
          GitHub repository URL or path to clone and play with. Supports formats:
            - owner/repo
            - https://github.com/owner/repo
            - git@github.com:owner/repo.git

      --langs <LANGS>
          Filter by programming languages (comma-separated). Supported languages:
            rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig
            Example: --langs rust,python,typescript

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const shortHelp = `A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]  Repository path to extract code from

Options:
      --repo <REPO>    GitHub repository URL or path to clone and play with
      --langs <LANGS>  Filter by programming languages (comma-separated)
  -h, --help           Print help (see more with '--help')
  -V, --version        Print version`;

const cacheHelp = `Manage challenge cache

Usage: executable cache <COMMAND>

Commands:
  stats  Show cache statistics
  clear  Clear all cached challenges
  list   List cached repository keys
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help`;

const repoHelp = `Manage repositories

Usage: executable repo <COMMAND>

Commands:
  list   List all cached repositories
  clear  Clear all cached repositories
  play   Play a cached repository interactively
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help`;

function commandHelp(cmd: string): string | undefined {
  switch (cmd) {
    case "history":
      return "Show session history\n\nUsage: executable history\n\nOptions:\n  -h, --help  Print help";
    case "stats":
      return "Show analytics\n\nUsage: executable stats\n\nOptions:\n  -h, --help  Print help";
    case "export":
      return "Export session data\n\nUsage: executable export [OPTIONS]\n\nOptions:\n      --format <FORMAT>  Export format [default: json]\n      --output <OUTPUT>  Output file path\n  -h, --help             Print help";
    case "cache":
      return cacheHelp;
    case "repo":
      return repoHelp;
    case "trending":
      return `Select and practice with trending repositories from GitHub

Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]

Arguments:
  [LANGUAGE]
          Programming language to filter trending repositories.
          Supported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig

  [REPO_NAME]
          Specific repository name to select from trending list

Options:
      --period <PERIOD>
          Time period for trending (daily, weekly, monthly)
          
          [default: daily]

  -h, --help
          Print help (see a summary with '-h')`;
    default:
      return undefined;
  }
}

function cacheSubHelp(sub: string): string | undefined {
  if (sub === "stats") return "Show cache statistics\n\nUsage: executable cache stats\n\nOptions:\n  -h, --help  Print help";
  if (sub === "clear") return "Clear all cached challenges\n\nUsage: executable cache clear\n\nOptions:\n  -h, --help  Print help";
  if (sub === "list") return "List cached repository keys\n\nUsage: executable cache list\n\nOptions:\n  -h, --help  Print help";
  return undefined;
}

function repoSubHelp(sub: string): string | undefined {
  if (sub === "list") return "List all cached repositories\n\nUsage: executable repo list\n\nOptions:\n  -h, --help  Print help";
  if (sub === "clear") return "Clear all cached repositories\n\nUsage: executable repo clear [OPTIONS]\n\nOptions:\n      --force  Force clear without confirmation\n  -h, --help   Print help";
  if (sub === "play") return "Play a cached repository interactively\n\nUsage: executable repo play\n\nOptions:\n  -h, --help  Print help";
  return undefined;
}

function parseValue(args: string[], i: number, flag: string, metavar: string): [string, number] {
  const a = args[i];
  const eq = a.indexOf("=");
  if (eq !== -1) return [a.slice(eq + 1), i];
  if (i + 1 >= args.length || args[i + 1].startsWith("-")) {
    err(`error: a value is required for '${flag} <${metavar}>' but none was supplied`);
    err("");
    err("For more information, try '--help'.");
    exit(2);
  }
  return [args[i + 1], i + 1];
}

function unsupportedLangs(value: string): boolean {
  const bad = value.split(",").filter((x) => !supportedLangs.has(x.toLowerCase()));
  if (bad.length === 0) return false;
  out(`❌ Unsupported language(s): ${bad.join(", ")}`);
  out("💡 Supported languages:");
  out("   rust, rs, typescript, ts, javascript, js");
  out("   python, py, ruby, rb, go, swift");
  out("   kotlin, kt, java, php, csharp, cs");
  out("   c#, c, cpp, c++, haskell, hs");
  out("   dart, scala, sc, zig, clojure, clj");
  out("   cljs");
  return true;
}

function terminalError(): never {
  const stamp = makeStamp();
  out(`💾 Error details written to: gittype_error_${stamp}.log`);
  out("Error: Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)");
  exit(1);
}

function makeStamp(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}_${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}`;
}

function clapUnexpected(arg: string, usage: string, tip = false): never {
  err(`error: unexpected argument '${arg}' found`);
  if (tip) {
    err("");
    err(`  tip: to pass '${arg}' as a value, use '-- ${arg}'`);
  }
  err("");
  err(`Usage: ${usage}`);
  err("");
  err("For more information, try '--help'.");
  exit(2);
}

function unrecognizedSub(arg: string, usage: string): never {
  err(`error: unrecognized subcommand '${arg}'`);
  err("");
  err(`Usage: ${usage}`);
  err("");
  err("For more information, try '--help'.");
  exit(2);
}

function needSub(help: string): never {
  out(help);
  exit(2);
}

function doExport(args: string[]): never {
  let format = "json";
  let outputPath: string | undefined;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") {
      out(commandHelp("export")!);
      exit(0);
    } else if (a === "--format" || a.startsWith("--format=")) {
      const r = parseValue(args, i, "--format", "FORMAT");
      format = r[0];
      i = r[1];
    } else if (a === "--output" || a.startsWith("--output=")) {
      const r = parseValue(args, i, "--output", "OUTPUT");
      outputPath = r[0];
      i = r[1];
    } else {
      clapUnexpected(a, "executable export [OPTIONS]");
    }
  }
  out("❌ Export command is not yet implemented");
  out(`💡 Requested format: ${format}`);
  if (outputPath !== undefined) out(`💡 Requested output: ${outputPath}`);
  out("💡 This feature is planned for a future release");
  exit(1);
}

function doCache(args: string[]): never {
  if (args.length === 0) needSub(cacheHelp);
  if (args[0] === "-h" || args[0] === "--help" || args[0] === "help") {
    if (args[0] === "help" && args[1]) {
      const h = cacheSubHelp(args[1]);
      if (h) out(h);
      else unrecognizedSub(args[1], "executable cache <COMMAND>");
    } else out(cacheHelp);
    exit(0);
  }
  const sub = args[0];
  if (args.includes("-h") || args.includes("--help")) {
    const h = cacheSubHelp(sub);
    if (h) { out(h); exit(0); }
  }
  if (sub === "stats") {
    if (args.length > 1) clapUnexpected(args[1], "executable cache stats");
    out("Challenge Cache Statistics:");
    out("  Cached repositories: 0");
    out("  Total size: 0 bytes");
    exit(0);
  }
  if (sub === "clear") {
    if (args.length > 1) clapUnexpected(args[1], "executable cache clear");
    out("Challenge cache cleared successfully.");
    exit(0);
  }
  if (sub === "list") {
    if (args.length > 1) clapUnexpected(args[1], "executable cache list");
    out("No cached challenges found.");
    exit(0);
  }
  unrecognizedSub(sub, "executable cache <COMMAND>");
}

function doRepo(args: string[]): never {
  if (args.length === 0) needSub(repoHelp);
  if (args[0] === "-h" || args[0] === "--help" || args[0] === "help") {
    if (args[0] === "help" && args[1]) {
      const h = repoSubHelp(args[1]);
      if (h) out(h);
      else unrecognizedSub(args[1], "executable repo <COMMAND>");
    } else out(repoHelp);
    exit(0);
  }
  const sub = args[0];
  if (args.includes("-h") || args.includes("--help")) {
    const h = repoSubHelp(sub);
    if (h) { out(h); exit(0); }
  }
  if (sub === "clear") {
    for (const a of args.slice(1)) {
      if (a !== "--force") clapUnexpected(a, "executable repo clear [OPTIONS]");
    }
    out("No cached repositories directory found.");
    exit(0);
  }
  if (sub === "list" || sub === "play") terminalError();
  unrecognizedSub(sub, "executable repo <COMMAND>");
}

function doTrending(args: string[]): never {
  let positional: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") {
      out(commandHelp("trending")!);
      exit(0);
    } else if (a === "--period" || a.startsWith("--period=")) {
      const r = parseValue(args, i, "--period", "PERIOD");
      i = r[1];
    } else if (a.startsWith("-")) {
      clapUnexpected(a, "executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]");
    } else {
      positional.push(a);
    }
  }
  if (positional.length >= 2 && !/^[^/\s]+\/[^/\s]+$/.test(positional[1])) {
    out("⚠️ Repository name must be in format 'owner/repo'");
    exit(0);
  }
  terminalError();
}

function main(): never {
  const args = process.argv.slice(2);
  if (args.length === 0) terminalError();

  if (args[0] === "-V" || args[0] === "--version") {
    out("gittype 0.8.0");
    exit(0);
  }
  if (args[0] === "-h") {
    out(shortHelp);
    exit(0);
  }
  if (args[0] === "--help") {
    out(longHelp);
    exit(0);
  }
  if (args[0] === "help") {
    const h = args[1] ? commandHelp(args[1]) : longHelp;
    if (h) { out(h); exit(0); }
    unrecognizedSub(args[1], "executable [OPTIONS] [REPO_PATH] [COMMAND]");
  }

  let rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") {
      out(longHelp);
      exit(0);
    }
    if (a === "--repo" || a.startsWith("--repo=")) {
      const r = parseValue(args, i, "--repo", "REPO");
      i = r[1];
    } else if (a === "--langs" || a.startsWith("--langs=")) {
      const r = parseValue(args, i, "--langs", "LANGS");
      if (unsupportedLangs(r[0])) exit(1);
      i = r[1];
    } else if (a.startsWith("-")) {
      clapUnexpected(a, "executable [OPTIONS] [REPO_PATH] [COMMAND]", true);
    } else {
      rest = args.slice(i);
      break;
    }
  }

  const cmd = rest[0];
  if (cmd === "history") {
    if (rest.includes("-h") || rest.includes("--help")) { out(commandHelp("history")!); exit(0); }
    if (rest.length > 1) clapUnexpected(rest[1], "executable history");
    out("❌ History command is not yet implemented");
    out("💡 This feature is planned for a future release");
    exit(1);
  }
  if (cmd === "stats") {
    if (rest.includes("-h") || rest.includes("--help")) { out(commandHelp("stats")!); exit(0); }
    if (rest.length > 1) clapUnexpected(rest[1], "executable stats");
    out("❌ Stats command is not yet implemented");
    out("💡 This feature is planned for a future release");
    exit(1);
  }
  if (cmd === "export") doExport(rest.slice(1));
  if (cmd === "cache") doCache(rest.slice(1));
  if (cmd === "repo") doRepo(rest.slice(1));
  if (cmd === "trending") doTrending(rest.slice(1));
  if (cmd && ["history", "stats", "export", "cache", "repo", "trending"].includes(cmd) === false && rest.length === args.length) {
    // A bare unknown word is treated as a repository path by the real program.
    terminalError();
  }
  terminalError();
}

main();
