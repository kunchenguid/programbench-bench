declare function require(name: string): any;
declare const process: {
  argv: string[];
  stdout: { write(text: string): void; isTTY?: boolean };
  stderr: { write(text: string): void; isTTY?: boolean };
  stdin: { isTTY?: boolean };
  chdir(path: string): void;
  exit(code?: number): never;
};

const { spawnSync } = require("node:child_process") as {
  spawnSync(command: string, args: string[], options: { encoding: "utf8" }): { status: number | null; stdout?: string; stderr?: string };
};
const { existsSync, statSync } = require("node:fs") as {
  existsSync(path: string): boolean;
  statSync(path: string): { isDirectory(): boolean };
};

const VERSION = "2.6.0-g87c9c25";

const HELP = `tig ${VERSION} 

Usage: tig        [options] [revs] [--] [paths]
   or: tig log    [options] [revs] [--] [paths]
   or: tig show   [options] [revs] [--] [paths]
   or: tig reflog [options] [revs]
   or: tig blame  [options] [rev] [--] path
   or: tig grep   [options] [pattern]
   or: tig refs   [options]
   or: tig stash  [options]
   or: tig status
   or: tig <      [git command output]

Options:
  +<number>       Select line <number> in the first view
  -v, --version   Show version and exit
  -h, --help      Show help message and exit
  -C <path>       Start in <path>
`;

function out(text: string): void {
  process.stdout.write(text);
}

function err(text: string): void {
  process.stderr.write(text);
}

function die(message: string, code = 1): never {
  err(`tig: ${message}\n`);
  process.exit(code);
}

function isDirectory(path: string): boolean {
  try {
    return existsSync(path) && statSync(path).isDirectory();
  } catch {
    return false;
  }
}

function parseArgs(input: string[]): string[] {
  const rest: string[] = [];

  for (let i = 0; i < input.length; i += 1) {
    const arg = input[i];

    if (arg === "-C") {
      const candidate = input[i + 1];
      if (candidate && candidate !== "--help" && candidate !== "-h" && candidate !== "--version" && candidate !== "-v") {
        if (!isDirectory(candidate)) {
          die(`Failed to change directory to ${candidate}`);
        }
        process.chdir(candidate);
        i += 1;
      }
      continue;
    }

    rest.push(arg);
  }

  return rest;
}

function hasAny(args: string[], names: string[]): boolean {
  return args.some((arg) => names.includes(arg));
}

function firstCommand(args: string[]): string | undefined {
  for (const arg of args) {
    if (arg === "--") {
      return undefined;
    }
    if (arg.startsWith("+")) {
      continue;
    }
    return arg;
  }
  return undefined;
}

function git(args: string[]): { status: number | null; stdout: string; stderr: string } {
  const result = spawnSync("git", args, { encoding: "utf8" });
  return {
    status: result.status,
    stdout: result.stdout ?? "",
    stderr: result.stderr ?? "",
  };
}

function looksLikeExistingPath(arg: string): boolean {
  if (arg === "--") {
    return false;
  }
  return existsSync(arg);
}

function revisionArgs(args: string[]): string[] {
  const commands = new Set(["log", "show", "reflog", "blame", "grep", "refs", "stash", "status"]);
  const result: string[] = [];
  let afterSeparator = false;

  for (const arg of args) {
    if (arg === "--") {
      afterSeparator = true;
      continue;
    }
    if (afterSeparator || arg.startsWith("-") || arg.startsWith("+") || commands.has(arg)) {
      continue;
    }
    if (looksLikeExistingPath(arg)) {
      continue;
    }
    result.push(arg);
  }

  return result;
}

function shouldReportBadRevision(args: string[]): boolean {
  const revs = revisionArgs(args);
  if (revs.length === 0) {
    return false;
  }

  const check = git(["rev-parse", "--verify", "--quiet", ...revs]);
  return check.status !== 0;
}

function main(): never {
  const args = parseArgs(process.argv.slice(2));

  if (hasAny(args, ["--help", "-h"])) {
    out(HELP);
    process.exit(0);
  }

  if (hasAny(args, ["--version", "-v"])) {
    out(`tig version ${VERSION}\nncursesw version 6.3.20211021\n`);
    process.exit(0);
  }

  const command = firstCommand(args);

  if (command === "help") {
    die("No revisions match the given arguments.");
  }

  if (shouldReportBadRevision(args)) {
    die("No revisions match the given arguments.");
  }

  die("Failed to open tty for input");
}

main();
