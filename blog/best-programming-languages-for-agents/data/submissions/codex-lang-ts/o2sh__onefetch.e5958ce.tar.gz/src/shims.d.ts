declare var process: any;
declare module "child_process" {
  export function execFileSync(command: string, args?: readonly string[], options?: any): any;
}
declare module "fs" {
  export const existsSync: any;
  export const statSync: any;
  export const readFileSync: any;
  export type Stats = any;
}
declare module "path" {
  export const basename: any;
  export const extname: any;
  export const join: any;
  export const resolve: any;
}
