import { execFileSync } from "child_process";
import * as fs from "fs";
import * as path from "path";

type Opts = {
  input: string;
  output?: "json" | "yaml";
  noTitle: boolean;
  noArt: boolean;
  noPalette: boolean;
  email: boolean;
  iso: boolean;
  includeHidden: boolean;
  noMerges: boolean;
  noBots?: string | boolean;
  disabled: Set<string>;
  numAuthors: number;
  numLangs: number;
  numChurn: number;
  churnPool?: number;
  separator: "plain" | "comma" | "space" | "underscore";
  exclude: string[];
  types: Set<string>;
};

const languages = [
  "ABNF","ABAP","Ada","Agda","Arduino C++","Assembly","ATS","AutoHotKey","BASH","C","CMake","C#","Ceylon","Clojure","CoffeeScript","ColdFusion","Coq","C++","Crystal","CSS","CUDA","D","Dart","Dockerfile","Emacs Lisp","Elixir","Elm","Emojicode","Erlang","F#","Fish","Forth","FORTRAN Legacy","FORTRAN Modern","GDScript","GLSL","Go","GraphQL","Groovy","Haskell","Haxe","HCL","HLSL","HolyC","HTML","Idris","Java","JavaScript","JSON","Jsonnet","JSX","Julia","Jupyter Notebooks","Kotlin","LLVM","Lean","Common Lisp","Lua","Makefile","Markdown","Modelica","Nim","Nix","OCaml","Objective-C","Odin","OpenSCAD","Org","Oz","Pascal","Perl","PHP","PowerShell","Processing","Prolog","Protocol Buffers","PureScript","Python","QML","R","Racket","ReScript","Ruby","Rust","Sass","Scala","Scheme","Shell","Solidity","SQL","Svelte","SVG","Swift","SystemVerilog","TCL","TeX","Plain Text","TOML","TSX","TypeScript","Typst","Vala","Verilog","VHDL","Vim Script","Visual Basic","Vue","WebAssembly","Wolfram","XSL","XAML","XML","YAML","Zig","Zsh"
];

const langByExt: Record<string, { lang: string; type: string }> = {
  ".js": { lang: "JavaScript", type: "programming" }, ".jsx": { lang: "JSX", type: "programming" },
  ".ts": { lang: "TypeScript", type: "programming" }, ".tsx": { lang: "TSX", type: "programming" },
  ".py": { lang: "Python", type: "programming" }, ".rs": { lang: "Rust", type: "programming" },
  ".go": { lang: "Go", type: "programming" }, ".c": { lang: "C", type: "programming" },
  ".h": { lang: "C", type: "programming" }, ".cpp": { lang: "C++", type: "programming" },
  ".cc": { lang: "C++", type: "programming" }, ".hpp": { lang: "C++", type: "programming" },
  ".java": { lang: "Java", type: "programming" }, ".rb": { lang: "Ruby", type: "programming" },
  ".php": { lang: "PHP", type: "programming" }, ".cs": { lang: "C#", type: "programming" },
  ".swift": { lang: "Swift", type: "programming" }, ".kt": { lang: "Kotlin", type: "programming" },
  ".kts": { lang: "Kotlin", type: "programming" }, ".scala": { lang: "Scala", type: "programming" },
  ".sh": { lang: "Shell", type: "programming" }, ".bash": { lang: "BASH", type: "programming" },
  ".zsh": { lang: "Zsh", type: "programming" }, ".fish": { lang: "Fish", type: "programming" },
  ".lua": { lang: "Lua", type: "programming" }, ".r": { lang: "R", type: "programming" },
  ".dart": { lang: "Dart", type: "programming" }, ".ex": { lang: "Elixir", type: "programming" },
  ".exs": { lang: "Elixir", type: "programming" }, ".erl": { lang: "Erlang", type: "programming" },
  ".hs": { lang: "Haskell", type: "programming" }, ".ml": { lang: "OCaml", type: "programming" },
  ".fs": { lang: "F#", type: "programming" }, ".clj": { lang: "Clojure", type: "programming" },
  ".html": { lang: "HTML", type: "markup" }, ".htm": { lang: "HTML", type: "markup" },
  ".css": { lang: "CSS", type: "markup" }, ".scss": { lang: "Sass", type: "markup" },
  ".sass": { lang: "Sass", type: "markup" }, ".vue": { lang: "Vue", type: "markup" },
  ".svelte": { lang: "Svelte", type: "markup" }, ".xml": { lang: "XML", type: "markup" },
  ".xaml": { lang: "XAML", type: "markup" }, ".svg": { lang: "SVG", type: "markup" },
  ".md": { lang: "Markdown", type: "prose" }, ".rst": { lang: "Plain Text", type: "prose" },
  ".txt": { lang: "Plain Text", type: "prose" }, ".json": { lang: "JSON", type: "data" },
  ".yaml": { lang: "YAML", type: "data" }, ".yml": { lang: "YAML", type: "data" },
  ".toml": { lang: "TOML", type: "data" }, ".sql": { lang: "SQL", type: "data" }
};

function git(cwd: string, args: string[], fallback = ""): string {
  try {
    return execFileSync("git", args, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trimEnd();
  } catch {
    return fallback;
  }
}

function die(msg: string, code = 1): void {
  console.error(msg);
  process.exit(code);
}

function help(long = false): string {
  if (!long) return `Command-line Git information tool

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Run as if onefetch was started in <input> instead of the current working directory

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

INFO:
  -d, --disabled-fields <FIELD>...   Allows you to disable FIELD(s) from appearing in the output
      --no-title                     Hides the title
      --number-of-authors <NUM>      Maximum NUM of authors to be shown [default: 3]
      --number-of-languages <NUM>    Maximum NUM of languages to be shown [default: 6]
      --number-of-file-churns <NUM>  Maximum NUM of file churns to be shown [default: 3]
      --churn-pool-size <NUM>        Minimum NUM of commits from HEAD used to compute the churn summary
  -e, --exclude <EXCLUDE>...         Ignore all files & directories matching EXCLUDE
      --no-bots[=<REGEX>]            Exclude [bot] commits
      --no-merges                    Ignores merge commits
  -E, --email                        Show the email address of each author
      --include-hidden               Count hidden files and directories
  -T, --type <TYPE>...               Filters output by language type [default: programming markup]

TEXT FORMATTING:
  -z, --iso-time                      Use ISO 8601 formatted timestamps
      --number-separator <SEPARATOR>  Which thousands SEPARATOR to use [default: plain]
      --no-bold                       Turns off bold formatting

DEVELOPER:
  -o, --output <FORMAT>   Outputs Onefetch in a specific format [possible values: json, yaml]
      --generate <SHELL>  If provided, outputs the completion file for given SHELL

OTHER:
  -l, --languages         Prints out supported languages
  -p, --package-managers  Prints out supported package managers`;
  return `Command-line Git information tool

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]
          Run as if onefetch was started in <input> instead of the current working directory

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

INFO:
  -d, --disabled-fields <FIELD>...
          Allows you to disable FIELD(s) from appearing in the output

      --no-title
          Hides the title

      --number-of-authors <NUM>
          Maximum NUM of authors to be shown
          
          [default: 3]

      --number-of-languages <NUM>
          Maximum NUM of languages to be shown
          
          [default: 6]

      --number-of-file-churns <NUM>
          Maximum NUM of file churns to be shown
          
          [default: 3]

  -e, --exclude <EXCLUDE>...
          Ignore all files & directories matching EXCLUDE

      --no-merges
          Ignores merge commits

  -E, --email
          Show the email address of each author

      --include-hidden
          Count hidden files and directories

DEVELOPER:
  -o, --output <FORMAT>
          Outputs Onefetch in a specific format
          
          [possible values: json, yaml]

OTHER:
  -l, --languages
          Prints out supported languages

  -p, --package-managers
          Prints out supported package managers`;
}

function parse(argv: string[]): Opts {
  const opts: Opts = { input: process.cwd(), noTitle: false, noArt: false, noPalette: false, email: false, iso: false, includeHidden: false, noMerges: false, disabled: new Set(), numAuthors: 3, numLangs: 6, numChurn: 3, separator: "plain", exclude: [], types: new Set(["programming","markup"]) };
  const takes = new Set(["--number-of-authors","--number-of-languages","--number-of-file-churns","--churn-pool-size","--number-separator","--output","-o","--ascii-input","--ascii-language","-a","--true-color","--image","-i","--image-protocol","--color-resolution"]);
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === "--") { if (argv[i+1]) opts.input = argv[i+1]; break; }
    if (a === "-h") { console.log(help(false)); process.exit(0); }
    if (a === "--help") { console.log(help(true)); process.exit(0); }
    if (a === "-V" || a === "--version") { console.log("onefetch 2.25.0"); process.exit(0); }
    if (a === "-l" || a === "--languages") { console.log(languages.join("\n")); process.exit(0); }
    if (a === "-p" || a === "--package-managers") { console.log("Npm\nCargo"); process.exit(0); }
    if (a === "--generate") { console.log(`_onefetch() {\n    COMPREPLY=()\n}\ncomplete -F _onefetch onefetch`); process.exit(0); }
    if (a.startsWith("--output=")) { opts.output = a.split("=")[1] as any; continue; }
    if (a === "-o" || a === "--output") { opts.output = argv[++i] as any; continue; }
    if (a === "--no-title") { opts.noTitle = true; continue; }
    if (a === "--no-art") { opts.noArt = true; continue; }
    if (a === "--no-color-palette") { opts.noPalette = true; continue; }
    if (a === "--email" || a === "-E") { opts.email = true; continue; }
    if (a === "--no-bold" || a === "--http-url" || a === "--hide-token" || a === "--nerd-fonts") { continue; }
    if (a === "--iso-time" || a === "-z") { opts.iso = true; continue; }
    if (a === "--include-hidden") { opts.includeHidden = true; continue; }
    if (a === "--no-merges") { opts.noMerges = true; continue; }
    if (a.startsWith("--no-bots")) { opts.noBots = a.includes("=") ? a.slice(a.indexOf("=")+1) : true; continue; }
    if (a === "--number-of-authors") { opts.numAuthors = parseInt(argv[++i] || "3", 10); continue; }
    if (a === "--number-of-languages") { opts.numLangs = parseInt(argv[++i] || "6", 10); continue; }
    if (a === "--number-of-file-churns") { opts.numChurn = parseInt(argv[++i] || "3", 10); continue; }
    if (a === "--churn-pool-size") { opts.churnPool = parseInt(argv[++i] || "0", 10); continue; }
    if (a === "--number-separator") { opts.separator = (argv[++i] as any) || "plain"; continue; }
    if (a === "-d" || a === "--disabled-fields") {
      while (argv[i+1] && !argv[i+1].startsWith("-")) opts.disabled.add(argv[++i]);
      continue;
    }
    if (a === "-e" || a === "--exclude") {
      while (argv[i+1] && !argv[i+1].startsWith("-")) opts.exclude.push(argv[++i]);
      continue;
    }
    if (a === "-c" || a === "--ascii-colors" || a === "-t" || a === "--text-colors") {
      while (argv[i+1] && !argv[i+1].startsWith("-")) i++;
      continue;
    }
    if (a === "-T" || a === "--type") {
      opts.types.clear();
      while (argv[i+1] && !argv[i+1].startsWith("-")) opts.types.add(argv[++i]);
      continue;
    }
    if (takes.has(a)) { i++; continue; }
    if (a.startsWith("-")) die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.`, 2);
    opts.input = a;
  }
  if (opts.output && opts.output !== "json" && opts.output !== "yaml") die(`error: invalid value '${opts.output}' for '--output <FORMAT>'\n  [possible values: json, yaml]`, 2);
  return opts;
}

function trackedFiles(repo: string, opts: Opts): string[] {
  const raw = git(repo, ["ls-files"], "");
  return raw ? raw.split("\n").filter(f => f && (opts.includeHidden || !f.split("/").some(p => p.startsWith("."))) && !opts.exclude.some(e => f.includes(e))) : [];
}

function langOf(file: string) {
  const base = path.basename(file);
  if (base === "Makefile") return { lang: "Makefile", type: "programming" };
  if (base === "Dockerfile") return { lang: "Dockerfile", type: "programming" };
  return langByExt[path.extname(file).toLowerCase()];
}

function countLines(abs: string): number {
  try {
    const s = fs.readFileSync(abs, "utf8");
    if (!s) return 0;
    return s.endsWith("\n") ? s.split("\n").length - 1 : s.split("\n").length;
  } catch { return 0; }
}

function relTime(epochSec: number, opts: Opts): string {
  if (!epochSec) return "";
  const d = new Date(epochSec * 1000);
  if (opts.iso) return d.toISOString();
  const diff = Math.max(0, Date.now() - d.getTime());
  const day = 86400000;
  if (diff < day) return "now";
  if (diff < 2 * day) return "a day ago";
  if (diff < 30 * day) return `${Math.floor(diff/day)} days ago`;
  if (diff < 60 * day) return "a month ago";
  if (diff < 365 * day) return `${Math.floor(diff/(30*day))} months ago`;
  const y = Math.floor(diff/(365*day));
  return y === 1 ? "a year ago" : `${y} years ago`;
}

function fmtNum(n: number, opts: Opts): string {
  const s = String(n);
  const sep = opts.separator === "comma" ? "," : opts.separator === "space" ? " " : opts.separator === "underscore" ? "_" : "";
  return sep ? s.replace(/\B(?=(\d{3})+(?!\d))/g, sep) : s;
}

function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KiB","MiB","GiB"];
  let v = bytes / 1024, u = 0;
  while (v >= 1024 && u < units.length - 1) { v /= 1024; u++; }
  return `${v.toFixed(2)} ${units[u]}`;
}

function yaml(v: any, indent = 0): string {
  const sp = " ".repeat(indent);
  if (Array.isArray(v)) return v.map(x => typeof x === "object" && x !== null ? `${sp}- ${yaml(x, indent + 2).trimStart()}` : `${sp}- ${scalar(x)}`).join("\n");
  if (v && typeof v === "object") return Object.entries(v).map(([k,val]) => {
    if (val && typeof val === "object") return `${sp}${k}:\n${yaml(val, indent + 2)}`;
    return `${sp}${k}: ${scalar(val)}`;
  }).join("\n");
  return `${sp}${scalar(v)}`;
}
function scalar(v: any): string {
  if (v === null) return "null";
  if (v === "") return "''";
  return String(v);
}

function status(repo: string) {
  const lines = git(repo, ["status", "--porcelain=v1"], "").split("\n").filter(Boolean);
  let added = 0, deleted = 0, modified = 0;
  for (const l of lines) {
    const x = l[0], y = l[1];
    if (x === "A" || x === "?" || y === "A") added++;
    else if (x === "D" || y === "D") deleted++;
    else modified++;
  }
  return { added, deleted, modified };
}

function makeData(repo: string, opts: Opts) {
  const gitVersion = git(repo, ["--version"], "git version 2.34.1");
  const gitUsername = git(repo, ["config", "user.name"], "");
  const files = trackedFiles(repo, opts);
  const head = git(repo, ["rev-parse", "--short=7", "HEAD"], "");
  const branch = git(repo, ["branch", "--show-current"], "");
  const logArgs = ["log", "--format=%an%x00%ae%x00%ct"];
  if (opts.noMerges) logArgs.splice(1, 0, "--no-merges");
  const log = git(repo, logArgs, "");
  const commits = log ? log.split("\n").filter(Boolean).map(l => l.split("\x00")) : [];
  const filtered = commits.filter(c => {
    if (!opts.noBots) return true;
    const re = new RegExp(typeof opts.noBots === "string" ? opts.noBots : "bot|\\[bot\\]", "i");
    return !re.test(c[0]) && !re.test(c[1]);
  });
  const count = filtered.length;
  const first = filtered.length ? Number(filtered[filtered.length - 1][2]) : 0;
  const last = filtered.length ? Number(filtered[0][2]) : 0;
  const authorMap = new Map<string, {name: string; email: string; n: number}>();
  for (const c of filtered) {
    const key = opts.email ? `${c[0]}\x00${c[1]}` : c[0];
    const cur = authorMap.get(key) || { name: c[0], email: c[1], n: 0 };
    cur.n++;
    authorMap.set(key, cur);
  }
  const authors = [...authorMap.values()].sort((a,b) => b.n - a.n || a.name.localeCompare(b.name)).slice(0, opts.numAuthors).map(a => ({
    name: a.name, email: opts.email ? a.email : null, nbrOfCommits: a.n, contribution: count ? Math.round(a.n * 100 / count) : 0
  }));
  const langBytes = new Map<string, number>();
  let loc = 0, size = 0;
  for (const f of files) {
    const abs = path.join(repo, f);
    let st: fs.Stats; try { st = fs.statSync(abs); } catch { continue; }
    if (!st.isFile()) continue;
    size += st.size;
    const l = langOf(f);
    if (l && opts.types.has(l.type)) {
      langBytes.set(l.lang, (langBytes.get(l.lang) || 0) + st.size);
      loc += countLines(abs);
    }
  }
  const totalLang = [...langBytes.values()].reduce((a,b)=>a+b,0);
  const langs = [...langBytes.entries()].sort((a,b) => b[1]-a[1] || a[0].localeCompare(b[0])).slice(0, opts.numLangs).map(([language,b]) => ({
    language, percentage: totalLang ? Math.round((b * 100 / totalLang) * 10) / 10 : 0
  }));
  const poolSize = opts.churnPool || 1;
  const churnArgs = ["log", `-${poolSize}`, "--name-only", "--format="];
  const churnLines = git(repo, churnArgs, "").split("\n").filter(Boolean);
  const churnMap = new Map<string, number>();
  for (const f of churnLines) if (files.includes(f)) churnMap.set(f, (churnMap.get(f) || 0) + 1);
  const churn = [...churnMap.entries()].sort((a,b) => b[1]-a[1] || a[0].localeCompare(b[0])).slice(0, opts.numChurn).map(([filePath,nbrOfCommits]) => ({ filePath, nbrOfCommits }));
  const license = detectLicense(repo, files);
  const pkgVersion = readVersion(repo, files);
  const deps = readDeps(repo, files);
  const fields: any[] = [];
  const add = (key: string, obj: any) => { if (!opts.disabled.has(key)) fields.push(obj); };
  add("project", { ProjectInfo: { repoName: "", numberOfBranches: 0, numberOfTags: 0 } });
  add("description", { DescriptionInfo: { description: null } });
  add("head", { HeadInfo: { headRefs: { shortCommitId: head, refs: branch ? [branch] : [] } } });
  add("pending", { PendingInfo: status(repo) });
  add("version", { VersionInfo: { version: pkgVersion } });
  add("created", { CreatedInfo: { creationDate: relTime(first, opts) } });
  if (langs.length) add("languages", { LanguagesInfo: { languagesWithPercentage: langs } });
  add("dependencies", { DependenciesInfo: { dependencies: deps } });
  add("authors", { AuthorsInfo: { authors } });
  add("last-change", { LastChangeInfo: { lastChange: relTime(last, opts) } });
  add("contributors", { ContributorsInfo: { totalNumberOfAuthors: authorMap.size } });
  add("url", { UrlInfo: { repoUrl: remoteUrl(repo) } });
  add("commits", { CommitsInfo: { numberOfCommits: count, isShallow: fs.existsSync(path.join(git(repo, ["rev-parse","--git-dir"], ".git"), "shallow")) } });
  add("churn", { ChurnInfo: { file_churns: churn, churn_pool_size: Math.min(poolSize, count) } });
  if (loc) add("lines-of-code", { LocInfo: { linesOfCode: loc } });
  add("size", { SizeInfo: { repoSize: fmtSize(size), fileCount: files.length } });
  add("license", { LicenseInfo: { license } });
  return { title: { gitUsername, gitVersion }, infoFields: fields };
}

function detectLicense(repo: string, files: string[]): string {
  const lf = files.find(f => /^licen[sc]e(\.|$)/i.test(path.basename(f)));
  if (!lf) return "";
  try {
    const s = fs.readFileSync(path.join(repo, lf), "utf8");
    if (/Permission is hereby granted, free of charge/i.test(s) && /MIT/i.test(s)) return "MIT";
    if (/Apache License/i.test(s)) return "Apache-2.0";
    if (/GNU GENERAL PUBLIC LICENSE/i.test(s)) return "GPL";
    return "";
  } catch { return ""; }
}
function readVersion(repo: string, files: string[]): string {
  if (files.includes("package.json")) try { return JSON.parse(fs.readFileSync(path.join(repo,"package.json"),"utf8")).version || ""; } catch {}
  if (files.includes("Cargo.toml")) {
    const m = fs.readFileSync(path.join(repo,"Cargo.toml"),"utf8").match(/^\s*version\s*=\s*"([^"]+)"/m);
    return m ? m[1] : "";
  }
  return "";
}
function readDeps(repo: string, files: string[]): string {
  const managers = [];
  if (files.includes("package.json")) managers.push("Npm");
  if (files.includes("Cargo.toml")) managers.push("Cargo");
  return managers.join(", ");
}
function remoteUrl(repo: string): string { return git(repo, ["config", "--get", "remote.origin.url"], ""); }

function text(data: any, opts: Opts): string {
  const out: string[] = [];
  if (!opts.noTitle) {
    const t = [data.title.gitUsername, data.title.gitVersion].filter(Boolean).join(" ~ ");
    if (t) { out.push(t); out.push("-".repeat(t.length)); }
  }
  for (const f of data.infoFields) {
    const key = Object.keys(f)[0], v = f[key];
    if (key === "ProjectInfo") continue;
    if (key === "DescriptionInfo" && !v.description) continue;
    if (key === "HeadInfo") out.push(`HEAD: ${v.headRefs.shortCommitId}${v.headRefs.refs.length ? " (" + v.headRefs.refs.join(", ") + ")" : ""}`);
    if (key === "PendingInfo") { const p = [`${v.added}+`, `${v.deleted}-`, `${v.modified}~`].filter(x => !x.startsWith("0")); if (p.length) out.push(`Pending: ${p.join(", ")}`); }
    if (key === "VersionInfo" && v.version) out.push(`Version: ${v.version}`);
    if (key === "CreatedInfo" && v.creationDate) out.push(`Created: ${v.creationDate}`);
    if (key === "LanguagesInfo") out.push(`Languages: ${v.languagesWithPercentage.map((l:any)=>`${l.language} (${l.percentage.toFixed(1)} %)`).join(", ")}`);
    if (key === "DependenciesInfo" && v.dependencies) out.push(`Dependencies: ${v.dependencies}`);
    if (key === "AuthorsInfo" && v.authors.length) { out.push(`${v.authors.length === 1 ? "Author" : "Authors"}: ${v.authors.map((a:any)=>`${a.contribution}% ${a.name}${opts.email && a.email ? " <"+a.email+">" : ""} ${a.nbrOfCommits}`).join("\n         ")}`); }
    if (key === "LastChangeInfo" && v.lastChange) out.push(`Last change: ${v.lastChange}`);
    if (key === "ContributorsInfo") out.push(`Contributors: ${fmtNum(v.totalNumberOfAuthors, opts)}`);
    if (key === "UrlInfo" && v.repoUrl) out.push(`URL: ${v.repoUrl}`);
    if (key === "CommitsInfo") out.push(`Commits: ${fmtNum(v.numberOfCommits, opts)}${v.isShallow ? " (shallow)" : ""}`);
    if (key === "ChurnInfo" && v.file_churns.length) out.push(`Churn (${v.churn_pool_size}): ${v.file_churns.map((c:any)=>`${c.filePath} ${c.nbrOfCommits}`).join("\n           ")}`);
    if (key === "LocInfo") out.push(`Lines of code: ${fmtNum(v.linesOfCode, opts)}`);
    if (key === "SizeInfo") out.push(`Size: ${v.repoSize} (${fmtNum(v.fileCount, opts)} ${v.fileCount === 1 ? "file" : "files"})`);
    if (key === "LicenseInfo" && v.license) out.push(`License: ${v.license}`);
  }
  return out.join("\n");
}

function main() {
  const opts = parse(process.argv.slice(2));
  const repo = path.resolve(opts.input);
  if (!fs.existsSync(repo) || !fs.statSync(repo).isDirectory()) die(`Error: Failed to access a directory, or path is not a directory: '${opts.input}'`);
  if (!git(repo, ["rev-parse", "--is-inside-work-tree"], "")) die("Error: not a git repository");
  const data = makeData(repo, opts);
  if (opts.output === "json") console.log(JSON.stringify(data, null, 2));
  else if (opts.output === "yaml") console.log(yaml(data));
  else console.log(text(data, opts));
}

main();
