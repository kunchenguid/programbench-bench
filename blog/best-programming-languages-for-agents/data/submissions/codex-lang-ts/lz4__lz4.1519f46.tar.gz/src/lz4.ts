declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");

const VERSION = "*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***";
const MAGIC = 0x184d2204;
const SKIPPABLE_BASE = 0x184d2a50;

function usage(long = false): string {
  const base = `${VERSION}
Usage : 
      executable [arg] [input] [output] 

input   : a filename 
          with no FILE, or when FILE is - or stdin, read standard input
Arguments : 
 -1     : fast compression (default) 
 -12    : slowest compression level 
 -T#    : use # threads for compression (default:0==auto) 
 -d     : decompression (default for .lz4 extension)
 -f     : overwrite output without prompting 
 -k     : preserve source files(s)  (default) 
--rm    : remove source file(s) after successful de/compression 
 -h/-H  : display help/long help and exit 

Advanced arguments :
 -V     : display Version number and exit 
 -v     : verbose mode 
 -q     : suppress warnings; specify twice to suppress errors too
 -c     : force write to standard output, even if it is the console
 -t     : test compressed file integrity
 -m     : multiple input files (implies automatic output filenames)
 -r     : operate recursively on directories (sets also -m) 
 -l     : compress using Legacy format (Linux kernel compression)
 -z     : force compression 
 -D FILE: use FILE as dictionary (compression & decompression)
 -B#    : cut file into blocks of size # bytes [32+] 
                     or predefined block size [4-7] (default: 7) 
 -BI    : Block Independence (default) 
 -BD    : Block dependency (improves compression ratio) 
 -BX    : enable block checksum (default:disabled) 
--no-frame-crc : disable stream checksum (default:enabled) 
--content-size : compressed frame includes original size (default:not present)
--list FILE : lists information about .lz4 files (useful for files compressed with --content-size flag)
--[no-]sparse  : sparse mode (default:enabled on file, disabled on stdout)
--favor-decSpeed: compressed files decompress faster, but are less compressed 
--fast[=#]: switch to ultra fast compression level (default: 1)
--best  : same as -12
Benchmark arguments : 
 -b#    : benchmark file(s), using # compression level (default : 1) 
 -e#    : test all compression levels from -bX to # (default : 1)
 -i#    : minimum evaluation time in seconds (default : 3s) 
`;
  if (!long) return base;
  return base + `
****************************
***** Advanced comment *****
****************************

Which values can [output] have ? 
---------------------------------
[output] : a filename 
          'stdout', or '-' for standard output (pipe mode)
          'null' to discard output (test mode) 
`;
}

function u32(n: number): number {
  return n >>> 0;
}

function rotl(n: number, r: number): number {
  return u32((n << r) | (n >>> (32 - r)));
}

function xxhash32(buf: any, seed = 0): number {
  const p1 = 0x9e3779b1, p2 = 0x85ebca77, p3 = 0xc2b2ae3d, p4 = 0x27d4eb2f, p5 = 0x165667b1;
  let off = 0;
  let h: number;
  if (buf.length >= 16) {
    let v1 = u32(seed + p1 + p2), v2 = u32(seed + p2), v3 = u32(seed), v4 = u32(seed - p1);
    const limit = buf.length - 16;
    while (off <= limit) {
      v1 = Math.imul(rotl(u32(v1 + Math.imul(buf.readUInt32LE(off), p2)), 13), p1) >>> 0; off += 4;
      v2 = Math.imul(rotl(u32(v2 + Math.imul(buf.readUInt32LE(off), p2)), 13), p1) >>> 0; off += 4;
      v3 = Math.imul(rotl(u32(v3 + Math.imul(buf.readUInt32LE(off), p2)), 13), p1) >>> 0; off += 4;
      v4 = Math.imul(rotl(u32(v4 + Math.imul(buf.readUInt32LE(off), p2)), 13), p1) >>> 0; off += 4;
    }
    h = u32(rotl(v1, 1) + rotl(v2, 7) + rotl(v3, 12) + rotl(v4, 18));
  } else {
    h = u32(seed + p5);
  }
  h = u32(h + buf.length);
  while (off + 4 <= buf.length) {
    h = Math.imul(rotl(u32(h + Math.imul(buf.readUInt32LE(off), p3)), 17), p4) >>> 0;
    off += 4;
  }
  while (off < buf.length) {
    h = Math.imul(rotl(u32(h + Math.imul(buf[off], p5)), 11), p1) >>> 0;
    off++;
  }
  h ^= h >>> 15; h = Math.imul(h, p2) >>> 0;
  h ^= h >>> 13; h = Math.imul(h, p3) >>> 0;
  h ^= h >>> 16;
  return h >>> 0;
}

function decompressBlock(input: any, expected?: number): any {
  const out: number[] = [];
  let ip = 0;
  while (ip < input.length) {
    const token = input[ip++];
    let litLen = token >>> 4;
    if (litLen === 15) {
      let s = 255;
      while (s === 255) {
        if (ip >= input.length) throw new Error("corrupt input");
        s = input[ip++]; litLen += s;
      }
    }
    if (ip + litLen > input.length) throw new Error("corrupt input");
    for (let i = 0; i < litLen; i++) out.push(input[ip++]);
    if (ip >= input.length) break;
    if (ip + 2 > input.length) throw new Error("corrupt input");
    const offset = input[ip] | (input[ip + 1] << 8);
    ip += 2;
    if (offset === 0 || offset > out.length) throw new Error("corrupt input");
    let matchLen = token & 15;
    if (matchLen === 15) {
      let s = 255;
      while (s === 255) {
        if (ip >= input.length) throw new Error("corrupt input");
        s = input[ip++]; matchLen += s;
      }
    }
    matchLen += 4;
    for (let i = 0; i < matchLen; i++) out.push(out[out.length - offset]);
  }
  if (expected !== undefined && out.length !== expected) throw new Error("corrupt input");
  return Buffer.from(out);
}

type FrameInfo = { compressed: number; decompressed?: number; blockCode: number; blocks: number; frames: number };

function decompressFrameStream(buf: any, testOnly = false): { data: any; info: FrameInfo } {
  let pos = 0;
  const chunks: any[] = [];
  let totalOut = 0, frames = 0, blocks = 0, blockCode = 0, compressed = buf.length;
  while (pos < buf.length) {
    if (pos + 4 > buf.length) throw new Error("Error 44 : Unrecognized header");
    const magic = buf.readUInt32LE(pos); pos += 4;
    if ((magic & 0xfffffff0) === SKIPPABLE_BASE) {
      if (pos + 4 > buf.length) throw new Error("corrupt input");
      const len = buf.readUInt32LE(pos); pos += 4 + len;
      continue;
    }
    if (magic !== MAGIC) throw new Error("Error 44 : Unrecognized header");
    if (pos + 3 > buf.length) throw new Error("corrupt input");
    const descriptorStart = pos;
    const flg = buf[pos++], bd = buf[pos++];
    blockCode = (bd >>> 4) & 7;
    const hasBlockChecksum = (flg & 0x10) !== 0;
    const hasContentSize = (flg & 0x08) !== 0;
    const hasContentChecksum = (flg & 0x04) !== 0;
    const hasDict = (flg & 0x01) !== 0;
    let contentSize: number | undefined;
    if ((flg >>> 6) !== 1) throw new Error("unsupported frame version");
    if (hasContentSize) {
      if (pos + 8 > buf.length) throw new Error("corrupt input");
      const lo = buf.readUInt32LE(pos), hi = buf.readUInt32LE(pos + 4);
      contentSize = lo + hi * 0x100000000;
      pos += 8;
    }
    if (hasDict) pos += 4;
    if (pos >= buf.length) throw new Error("corrupt input");
    const hc = buf[pos++];
    const calc = (xxhash32(buf.subarray(descriptorStart, pos - 1)) >>> 8) & 255;
    if (hc !== calc) throw new Error("corrupt input");
    const frameChunks: any[] = [];
    const checksumChunks: any[] = [];
    let frameOut = 0;
    while (true) {
      if (pos + 4 > buf.length) throw new Error("corrupt input");
      let size = buf.readUInt32LE(pos); pos += 4;
      if (size === 0) break;
      const raw = (size & 0x80000000) !== 0;
      size = size & 0x7fffffff;
      if (pos + size > buf.length) throw new Error("corrupt input");
      const block = buf.subarray(pos, pos + size); pos += size;
      const out = raw ? Buffer.from(block) : decompressBlock(block);
      frameOut += out.length; blocks++;
      if (!testOnly) frameChunks.push(out);
      if (hasContentChecksum) checksumChunks.push(out);
      if (hasBlockChecksum) {
        if (pos + 4 > buf.length) throw new Error("corrupt input");
        const want = buf.readUInt32LE(pos); pos += 4;
        if (xxhash32(block) !== want) throw new Error("corrupt input");
      }
    }
    if (hasContentChecksum) {
      if (pos + 4 > buf.length) throw new Error("corrupt input");
      const want = buf.readUInt32LE(pos); pos += 4;
      if (xxhash32(Buffer.concat(checksumChunks)) !== want) throw new Error("corrupt input");
    }
    if (contentSize !== undefined && contentSize !== frameOut) throw new Error("corrupt input");
    totalOut += frameOut; frames++;
    if (!testOnly) chunks.push(...frameChunks);
  }
  return { data: testOnly ? Buffer.alloc(0) : Buffer.concat(chunks), info: { compressed, decompressed: totalOut, blockCode, blocks, frames } };
}

function compressStored(input: any): any {
  const flg = 0x60, bd = 0x70;
  const headerBytes = Buffer.from([flg, bd]);
  const hc = (xxhash32(headerBytes) >>> 8) & 255;
  const parts = [Buffer.from([0x04, 0x22, 0x4d, 0x18, flg, bd, hc])];
  const max = 4 * 1024 * 1024;
  for (let off = 0; off < input.length; off += max) {
    const chunk = input.subarray(off, Math.min(input.length, off + max));
    const len = Buffer.alloc(4);
    len.writeUInt32LE((chunk.length | 0x80000000) >>> 0, 0);
    parts.push(len, chunk);
  }
  parts.push(Buffer.from([0, 0, 0, 0]));
  return Buffer.concat(parts);
}

function parseArgs(argv: string[]) {
  const opts: any = { files: [], force: false, stdout: false, mode: "", test: false, list: false, quiet: 0, rm: false, multiple: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help") opts.help = true;
    else if (a === "--list") opts.list = true;
    else if (a === "--rm") opts.rm = true;
    else if (a === "--keep") {}
    else if (a === "--compress") opts.mode = "compress";
    else if (a === "--decompress" || a === "--uncompress") opts.mode = "decompress";
    else if (a.startsWith("--fast") || a === "--best" || a === "--no-frame-crc" || a === "--content-size" || a === "--sparse" || a === "--no-sparse" || a === "--favor-decSpeed") {}
    else if (a === "-D") i++;
    else if (a.startsWith("-") && a !== "-") {
      for (let j = 1; j < a.length; j++) {
        const c = a[j];
        if (c === "h") opts.help = true;
        else if (c === "H") opts.longHelp = true;
        else if (c === "V") opts.version = true;
        else if (c === "d") opts.mode = "decompress";
        else if (c === "z") opts.mode = "compress";
        else if (c === "t") { opts.test = true; opts.mode = "decompress"; }
        else if (c === "c") opts.stdout = true;
        else if (c === "f") opts.force = true;
        else if (c === "q") opts.quiet++;
        else if (c === "m" || c === "r") opts.multiple = true;
        else if (c === "D") { if (j === a.length - 1) i++; break; }
        else if ("0123456789lkvBIT".includes(c)) {}
        else if (c === "B") break;
      }
    } else opts.files.push(a);
  }
  return opts;
}

function readInput(file?: string): any {
  if (!file || file === "-") return fs.readFileSync(0);
  return fs.readFileSync(file);
}

function writeOutput(file: string | undefined, data: any, force: boolean) {
  if (!file || file === "-" || file === "stdout") {
    fs.writeFileSync(1, data);
    return;
  }
  if (file === "null") return;
  if (!force && fs.existsSync(file)) {
    process.stderr.write(`${file} already exists; do you want to overwrite (y/N) ?     not overwritten  \n`);
    process.exit(1);
  }
  fs.writeFileSync(file, data);
}

function defaultOut(input: string | undefined, mode: string): string | undefined {
  if (!input || input === "-") return undefined;
  if (mode === "compress") return input + ".lz4";
  return input.endsWith(".lz4") ? input.slice(0, -4) : input + ".out";
}

function processOne(inputFile: string | undefined, outputFile: string | undefined, opts: any, mode: string) {
  const input = readInput(inputFile);
  if (mode === "decompress") {
    const result = decompressFrameStream(input, opts.test);
    writeOutput(outputFile, result.data, opts.force);
    if (opts.quiet === 0 && inputFile) {
      const verb = opts.test ? "decoded" : "decoded";
      process.stderr.write(`${inputFile.padEnd(30)}: ${verb} ${result.info.decompressed} bytes \n`);
    }
  } else {
    const out = compressStored(input);
    writeOutput(outputFile, out, opts.force);
    if (opts.quiet === 0 && inputFile && outputFile) {
      process.stderr.write(`Compressed ${input.length} bytes into ${out.length} bytes\n`);
    }
  }
  if (opts.rm && inputFile && inputFile !== "-") fs.unlinkSync(inputFile);
}

function blockName(code: number): string {
  return code === 4 ? "B4I" : code === 5 ? "B5I" : code === 6 ? "B6I" : "B7I";
}

function fmtBytes(n: number): string {
  return n.toFixed(2);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.version) { console.log(VERSION); return; }
  if (opts.help || opts.longHelp) { process.stdout.write(usage(!!opts.longHelp)); return; }
  const files: string[] = opts.files;
  if (opts.list) {
    const file = files[0];
    if (!file) throw new Error("missing filename");
    const info = decompressFrameStream(fs.readFileSync(file), true).info;
    console.log("    Frames           Type Block  Compressed  Uncompressed    Ratio   Filename");
    const uncomp = info.decompressed === undefined ? "-" : String(info.decompressed);
    const ratio = info.decompressed ? ((info.compressed / info.decompressed) * 100).toFixed(2) + "%" : "-";
    console.log(`${String(info.frames).padStart(10)}       LZ4Frame ${blockName(info.blockCode).padStart(4)}${fmtBytes(info.compressed).padStart(12)}${uncomp.padStart(14)}${ratio.padStart(9)}   ${file}`);
    return;
  }

  const inputFile = files[0];
  let outputFile = files[1];
  let mode = opts.mode || (inputFile && inputFile.endsWith(".lz4") ? "decompress" : "compress");
  if (opts.stdout) outputFile = undefined;
  else if (opts.test) outputFile = "null";
  else if (!outputFile) outputFile = defaultOut(inputFile, mode);

  if (opts.multiple && files.length > 1 && !opts.stdout && !files[1].startsWith("-")) {
    for (const file of files) {
      const m = opts.mode || (file.endsWith(".lz4") ? "decompress" : "compress");
      processOne(file, opts.test ? "null" : defaultOut(file, m), opts, m);
    }
    return;
  }
  processOne(inputFile, outputFile, opts, mode);
}

try {
  main();
} catch (e: any) {
  process.stderr.write((e && e.message ? e.message : String(e)) + "\n");
  process.exit(1);
}
