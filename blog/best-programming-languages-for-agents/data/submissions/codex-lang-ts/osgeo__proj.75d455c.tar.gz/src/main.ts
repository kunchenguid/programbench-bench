declare const require: any;
declare const process: any;

const fs = require("fs");

const VERSION = "Rel. 9.9.0, September 15th, 2026";
const A_WGS84 = 6378137.0;
const F_WGS84 = 1 / 298.257223563;
const E2_WGS84 = F_WGS84 * (2 - F_WGS84);
const DEG = Math.PI / 180;
const RAD = 180 / Math.PI;

type Params = Record<string, string | boolean>;
type Opts = {
  inverse: boolean;
  echo: boolean;
  reverseInput: boolean;
  reverseOutput: boolean;
  fmt: string;
  files: string[];
  params: Params;
  list?: string;
  multiplier: number;
  decimals?: number;
};

function basename(): string {
  return "<executable>";
}

function die(msg: string, code = 3): never {
  console.error(VERSION);
  console.error(`${basename()}: `);
  console.error(msg);
  console.error("program abnormally terminated");
  process.exit(code);
  throw new Error(msg);
}

function parseArgs(argv: string[]): Opts {
  const opts: Opts = {
    inverse: false, echo: false, reverseInput: false, reverseOutput: false,
    fmt: "%.2f", files: [], params: {}, multiplier: 1
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("+")) {
      const s = a.slice(1);
      const eq = s.indexOf("=");
      if (eq >= 0) opts.params[s.slice(0, eq)] = s.slice(eq + 1);
      else opts.params[s] = true;
    } else if (a === "-I") opts.inverse = true;
    else if (a === "-E") opts.echo = true;
    else if (a === "-r") opts.reverseInput = true;
    else if (a === "-s") opts.reverseOutput = true;
    else if (a === "-f") {
      if (++i >= argv.length) die("missing argument for -f");
      opts.fmt = argv[i];
    } else if (a.startsWith("-f") && a.length > 2) opts.fmt = a.slice(2);
    else if (a === "-m") {
      if (++i >= argv.length) die("missing argument for -m");
      opts.multiplier = Number(argv[i]) || 1;
    } else if (a.startsWith("-m") && a.length > 2) opts.multiplier = Number(a.slice(2)) || 1;
    else if (a === "-d") {
      if (++i >= argv.length) die("missing argument for -d");
      opts.decimals = Number(argv[i]);
      opts.fmt = `%${isFinite(opts.decimals) ? "." + opts.decimals : ""}f`;
    } else if (a.startsWith("-d") && a.length > 2) {
      opts.decimals = Number(a.slice(2));
      opts.fmt = `%${isFinite(opts.decimals) ? "." + opts.decimals : ""}f`;
    } else if (/^-w\d+/.test(a) || /^-W\d+/.test(a)) {
      // Width only affects sexagesimal output; numeric output keeps printf formatting.
    } else if (a === "-l") opts.list = "p";
    else if (a.startsWith("-l")) {
      const kind = a.slice(2) || (argv[++i] || "");
      if (kind === "p" || kind === "P" || kind === "") opts.list = "p";
      else if (kind === "u") opts.list = "u";
      else if (kind === "e") opts.list = "e";
      else die(`invalid list option: l${kind}`, 0);
    } else if (a.startsWith("--")) die("invalid option: --", 0);
    else if (a.startsWith("-")) die(`invalid option: ${a.slice(0, 2)}`, 0);
    else opts.files.push(a);
  }
  return opts;
}

function list(kind: string) {
  if (kind === "u") {
    console.log("          mm 0.001                millimetre");
    console.log("          cm 0.01                 centimetre");
    console.log("           m 1                    metre");
    console.log("          ft 0.3048               foot");
    console.log("       us-ft 0.304800609601219    US survey foot");
    console.log("          km 1000                 kilometre");
    console.log("          mi 1609.344             Statute mile");
    console.log("          yd 0.9144               yard");
    console.log("          in 0.0254               inch");
    return;
  }
  if (kind === "e") {
    console.log("    GRS80 a=6378137.0      rf=298.257222101 GRS 1980(IUGG, 1980)");
    console.log("     airy a=6377563.396    rf=299.3249646   Airy 1830");
    console.log("   bessel a=6377397.155    rf=299.1528128   Bessel 1841");
    console.log("   clrk66 a=6378206.4      b=6356583.8      Clarke 1866");
    console.log("     intl a=6378388.0      rf=297.          International 1924 (Hayford 1909, 1910)");
    console.log("    WGS72 a=6378135.0      rf=298.26        WGS 72");
    console.log("    WGS84 a=6378137.0      rf=298.257223563 WGS 84");
    console.log("   sphere a=6370997.0      b=6370997.0      Normal Sphere (r=6370997)");
    return;
  }
  const rows = [
    ["aea", "Albers Equal Area"], ["aeqd", "Azimuthal Equidistant"], ["cass", "Cassini"],
    ["cea", "Equal Area Cylindrical"], ["eqc", "Equidistant Cylindrical (Plate Carree)"],
    ["etmerc", "Extended Transverse Mercator"], ["gnom", "Gnomonic"], ["laea", "Lambert Azimuthal Equal Area"],
    ["lcc", "Lambert Conformal Conic"], ["longlat", "Lat/long (Geodetic alias)"],
    ["merc", "Mercator"], ["mill", "Miller Cylindrical"], ["moll", "Mollweide"],
    ["ortho", "Orthographic"], ["sinu", "Sinusoidal (Sanson-Flamsteed)"],
    ["stere", "Stereographic"], ["tmerc", "Transverse Mercator"], ["utm", "Universal Transverse Mercator (UTM)"]
  ];
  for (const [id, desc] of rows) console.log(`${id} : ${desc}`);
}

function numParam(p: Params, key: string, def: number): number {
  const v = p[key];
  if (typeof v === "string") {
    const n = parseFloat(v);
    if (isFinite(n)) return n;
  }
  return def;
}

function ellipsoid(p: Params): { a: number, e2: number } {
  let a = numParam(p, "R", NaN);
  if (isFinite(a)) return { a, e2: 0 };
  a = numParam(p, "a", A_WGS84);
  const b = numParam(p, "b", NaN);
  if (isFinite(b)) return { a, e2: 1 - (b * b) / (a * a) };
  const rf = numParam(p, "rf", NaN);
  if (isFinite(rf) && rf !== 0) {
    const f = 1 / rf;
    return { a, e2: f * (2 - f) };
  }
  if (p.ellps === "sphere") return { a: 6370997.0, e2: 0 };
  return { a, e2: E2_WGS84 };
}

function parseCoord(tok: string): number {
  if (!tok) return 0;
  let sign = /^[SWsw-]/.test(tok) || /[SWsw]$/.test(tok) ? -1 : 1;
  let s = tok.replace(/[NSEWnsew]/g, "");
  if (s.startsWith("-")) { sign = -1; s = s.slice(1); }
  if (/[rR]$/.test(s)) return sign * parseFloat(s) * RAD;
  const m = s.match(/^([0-9.]+)d(?:([0-9.]+))?(?:'([0-9.]+)?)?(?:"([0-9.]+)?)?/);
  if (m) {
    const d = parseFloat(m[1]) || 0, min = parseFloat(m[2] || m[3] || "0") || 0, sec = parseFloat(m[4] || "0") || 0;
    return sign * (d + min / 60 + sec / 3600);
  }
  const n = parseFloat(tok);
  return isFinite(n) ? n : 0;
}

function splitLine(line: string): { x: number, y: number, rest: string, rawX: string, rawY: string } {
  const m = line.match(/^(\S+)(?:\s+(\S+))?(.*)$/);
  const rawX = m ? m[1] : "";
  const rawY = m && m[2] ? m[2] : "";
  return { x: parseCoord(rawX), y: parseCoord(rawY), rest: m ? (m[3] || "") : "", rawX, rawY };
}

function meridionalArc(phi: number, a: number, e2: number): number {
  const e4 = e2 * e2, e6 = e4 * e2;
  return a * ((1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi
    - (3 * e2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * Math.sin(2 * phi)
    + (15 * e4 / 256 + 45 * e6 / 1024) * Math.sin(4 * phi)
    - (35 * e6 / 3072) * Math.sin(6 * phi));
}

function project(lonDeg: number, latDeg: number, p: Params, inverse: boolean): [number, number] | null {
  const proj = String(p.proj || "");
  if (!proj) die("projection initialization failure\ncause: Unknown error (code 2)");
  if ((proj === "longlat" || proj === "latlong" || proj === "lonlat") && !inverse) {
    die("can't initialize operations that produce angular output coordinates", 3);
  }
  const { a, e2 } = ellipsoid(p);
  const e = Math.sqrt(Math.max(0, e2));
  const lon0 = numParam(p, "lon_0", proj === "utm" ? (numParam(p, "zone", 31) * 6 - 183) : 0) * DEG;
  const lat0 = numParam(p, "lat_0", 0) * DEG;
  const k0 = numParam(p, "k_0", numParam(p, "k", proj === "utm" ? 0.9996 : 1));
  const x0 = numParam(p, "x_0", proj === "utm" ? 500000 : 0);
  const y0 = numParam(p, "y_0", p.south === true ? 10000000 : 0);
  if (inverse) return inverseProject(lonDeg, latDeg, p, { a, e2, e, lon0, lat0, k0, x0, y0 });
  const lam = lonDeg * DEG, phi = latDeg * DEG;
  const dlam = normLon(lam - lon0);
  switch (proj) {
    case "merc": {
      if (Math.abs(latDeg) >= 90) return null;
      let y: number;
      if (e2 === 0) y = a * Math.log(Math.tan(Math.PI / 4 + phi / 2));
      else {
        const s = Math.sin(phi);
        y = a * Math.log(Math.tan(Math.PI / 4 + phi / 2) * Math.pow((1 - e * s) / (1 + e * s), e / 2));
      }
      return [x0 + k0 * a * dlam, y0 + k0 * y];
    }
    case "eqc":
    case "latlong":
    case "longlat":
      return [
        x0 + a * dlam * smallM(numParam(p, "lat_ts", 0) * DEG, e2),
        y0 + (e2 === 0 ? a * (phi - lat0) : meridionalArc(phi, a, e2) - meridionalArc(lat0, a, e2))
      ];
    case "utm":
    case "tmerc":
    case "etmerc":
      return tmercForward(phi, dlam, a, e2, k0, x0, y0, lat0);
    case "sinu":
      return [x0 + a * dlam * Math.cos(phi), y0 + a * (phi - lat0)];
    case "cea": {
      const ts = numParam(p, "lat_ts", 0) * DEG;
      return [x0 + a * dlam * Math.cos(ts), y0 + a * Math.sin(phi) / Math.cos(ts)];
    }
    case "mill":
      return [x0 + a * dlam, y0 + a * 1.25 * Math.log(Math.tan(Math.PI / 4 + 0.4 * phi))];
    case "moll": {
      let th = phi;
      for (let i = 0; i < 10; i++) {
        const d = -(2 * th + Math.sin(2 * th) - Math.PI * Math.sin(phi)) / (2 + 2 * Math.cos(2 * th));
        th += d; if (Math.abs(d) < 1e-12) break;
      }
      return [x0 + a * 2 * Math.SQRT2 / Math.PI * dlam * Math.cos(th), y0 + a * Math.SQRT2 * Math.sin(th)];
    }
    case "laea": {
      const sp0 = Math.sin(lat0), cp0 = Math.cos(lat0), sp = Math.sin(phi), cp = Math.cos(phi);
      const k = Math.sqrt(2 / (1 + sp0 * sp + cp0 * cp * Math.cos(dlam)));
      return [x0 + a * k * cp * Math.sin(dlam), y0 + a * k * (cp0 * sp - sp0 * cp * Math.cos(dlam))];
    }
    case "aeqd": {
      const sp0 = Math.sin(lat0), cp0 = Math.cos(lat0), sp = Math.sin(phi), cp = Math.cos(phi);
      const cosc = sp0 * sp + cp0 * cp * Math.cos(dlam);
      const c = Math.acos(Math.max(-1, Math.min(1, cosc)));
      const k = Math.abs(c) < 1e-12 ? 1 : c / Math.sin(c);
      return [x0 + a * k * cp * Math.sin(dlam), y0 + a * k * (cp0 * sp - sp0 * cp * Math.cos(dlam))];
    }
    case "ortho": {
      const sp0 = Math.sin(lat0), cp0 = Math.cos(lat0), sp = Math.sin(phi), cp = Math.cos(phi);
      return [x0 + a * cp * Math.sin(dlam), y0 + a * (cp0 * sp - sp0 * cp * Math.cos(dlam))];
    }
    case "gnom": {
      const sp0 = Math.sin(lat0), cp0 = Math.cos(lat0), sp = Math.sin(phi), cp = Math.cos(phi);
      const cosc = sp0 * sp + cp0 * cp * Math.cos(dlam);
      return [x0 + a * cp * Math.sin(dlam) / cosc, y0 + a * (cp0 * sp - sp0 * cp * Math.cos(dlam)) / cosc];
    }
    case "stere": {
      const sp0 = Math.sin(lat0), cp0 = Math.cos(lat0), sp = Math.sin(phi), cp = Math.cos(phi);
      const k = 2 * a * k0 / (1 + sp0 * sp + cp0 * cp * Math.cos(dlam));
      return [x0 + k * cp * Math.sin(dlam), y0 + k * (cp0 * sp - sp0 * cp * Math.cos(dlam))];
    }
    case "lcc": return lccForward(phi, dlam, p, a, x0, y0, lat0);
    case "aea": return aeaForward(phi, dlam, p, a, x0, y0, lat0);
    default:
      console.error("proj_create: unrecognized format / unknown name");
      die("projection initialization failure\ncause: Unknown error (code 2)");
  }
}

function normLon(x: number): number {
  while (x > Math.PI) x -= 2 * Math.PI;
  while (x < -Math.PI) x += 2 * Math.PI;
  return x;
}

function tmercForward(phi: number, lam: number, a: number, e2: number, k0: number, x0: number, y0: number, lat0: number): [number, number] {
  const ep2 = e2 / (1 - e2);
  const N = a / Math.sqrt(1 - e2 * Math.sin(phi) ** 2);
  const T = Math.tan(phi) ** 2;
  const C = ep2 * Math.cos(phi) ** 2;
  const A = Math.cos(phi) * lam;
  const M = meridionalArc(phi, a, e2);
  const M0 = meridionalArc(lat0, a, e2);
  const x = x0 + k0 * N * (A + (1 - T + C) * A ** 3 / 6 + (5 - 18 * T + T ** 2 + 72 * C - 58 * ep2) * A ** 5 / 120);
  const y = y0 + k0 * (M - M0 + N * Math.tan(phi) * (A ** 2 / 2 + (5 - T + 9 * C + 4 * C ** 2) * A ** 4 / 24 + (61 - 58 * T + T ** 2 + 600 * C - 330 * ep2) * A ** 6 / 720));
  return [x, y];
}

function inverseProject(xIn: number, yIn: number, p: Params, c: any): [number, number] | null {
  const proj = String(p.proj || "");
  let x = (xIn - c.x0) / c.k0, y = (yIn - c.y0) / c.k0;
  if (proj === "merc") {
    const lon = c.lon0 + x / c.a;
    let phi = Math.PI / 2 - 2 * Math.atan(Math.exp(-y / c.a));
    if (c.e2 !== 0) {
      for (let i = 0; i < 12; i++) {
        const s = Math.sin(phi);
        phi = Math.PI / 2 - 2 * Math.atan(Math.exp(-y / c.a) * Math.pow((1 - c.e * s) / (1 + c.e * s), c.e / 2));
      }
    }
    return [lon * RAD, phi * RAD];
  }
  if (proj === "eqc" || proj === "longlat" || proj === "latlong") {
    return [(c.lon0 + x / (c.a * smallM(numParam(p, "lat_ts", 0) * DEG, c.e2))) * RAD, (c.lat0 + y / c.a) * RAD];
  }
  if (proj === "utm" || proj === "tmerc" || proj === "etmerc") return tmercInverse(xIn, yIn, c).map(v => v * RAD) as [number, number];
  return null;
}

function tmercInverse(xIn: number, yIn: number, c: any): [number, number] {
  const x = xIn - c.x0, y = yIn - c.y0;
  const e1 = (1 - Math.sqrt(1 - c.e2)) / (1 + Math.sqrt(1 - c.e2));
  const M = meridionalArc(c.lat0, c.a, c.e2) + y / c.k0;
  const mu = M / (c.a * (1 - c.e2 / 4 - 3 * c.e2 ** 2 / 64 - 5 * c.e2 ** 3 / 256));
  const phi1 = mu + (3 * e1 / 2 - 27 * e1 ** 3 / 32) * Math.sin(2 * mu)
    + (21 * e1 ** 2 / 16 - 55 * e1 ** 4 / 32) * Math.sin(4 * mu)
    + (151 * e1 ** 3 / 96) * Math.sin(6 * mu) + (1097 * e1 ** 4 / 512) * Math.sin(8 * mu);
  const ep2 = c.e2 / (1 - c.e2);
  const C1 = ep2 * Math.cos(phi1) ** 2, T1 = Math.tan(phi1) ** 2;
  const N1 = c.a / Math.sqrt(1 - c.e2 * Math.sin(phi1) ** 2);
  const R1 = c.a * (1 - c.e2) / (1 - c.e2 * Math.sin(phi1) ** 2) ** 1.5;
  const D = x / (N1 * c.k0);
  const lat = phi1 - (N1 * Math.tan(phi1) / R1) * (D ** 2 / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 ** 2 - 9 * ep2) * D ** 4 / 24
    + (61 + 90 * T1 + 298 * C1 + 45 * T1 ** 2 - 252 * ep2 - 3 * C1 ** 2) * D ** 6 / 720);
  const lon = c.lon0 + (D - (1 + 2 * T1 + C1) * D ** 3 / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 ** 2 + 8 * ep2 + 24 * T1 ** 2) * D ** 5 / 120) / Math.cos(phi1);
  return [lon, lat];
}

function smallM(phi: number, e2: number): number {
  const s = Math.sin(phi);
  return Math.cos(phi) / Math.sqrt(1 - e2 * s * s);
}

function lccForward(phi: number, lam: number, p: Params, a: number, x0: number, y0: number, lat0: number): [number, number] {
  const lat1 = numParam(p, "lat_1", numParam(p, "lat_0", 0)) * DEG;
  const lat2 = numParam(p, "lat_2", lat1 / DEG) * DEG;
  const n = Math.abs(lat1 - lat2) < 1e-12 ? Math.sin(lat1) : Math.log(Math.cos(lat1) / Math.cos(lat2)) / Math.log(Math.tan(Math.PI / 4 + lat2 / 2) / Math.tan(Math.PI / 4 + lat1 / 2));
  const F = Math.cos(lat1) * Math.pow(Math.tan(Math.PI / 4 + lat1 / 2), n) / n;
  const rho = a * F / Math.pow(Math.tan(Math.PI / 4 + phi / 2), n);
  const rho0 = a * F / Math.pow(Math.tan(Math.PI / 4 + lat0 / 2), n);
  return [x0 + rho * Math.sin(n * lam), y0 + rho0 - rho * Math.cos(n * lam)];
}

function aeaForward(phi: number, lam: number, p: Params, a: number, x0: number, y0: number, lat0: number): [number, number] {
  const lat1 = numParam(p, "lat_1", 0) * DEG, lat2 = numParam(p, "lat_2", 0) * DEG;
  const n = (Math.sin(lat1) + Math.sin(lat2 || lat1)) / 2;
  const C = Math.cos(lat1) ** 2 + 2 * n * Math.sin(lat1);
  const rho = a * Math.sqrt(Math.max(0, C - 2 * n * Math.sin(phi))) / n;
  const rho0 = a * Math.sqrt(Math.max(0, C - 2 * n * Math.sin(lat0))) / n;
  return [x0 + rho * Math.sin(n * lam), y0 + rho0 - rho * Math.cos(n * lam)];
}

function formatNumber(n: number, fmt: string, inverse: boolean): string {
  if (!isFinite(n)) return "*";
  if (Math.abs(n) < 1e-9) n = 0;
  const m = fmt.match(/%[-+ #0]*\d*(?:\.(\d+))?[a-zA-Z]/);
  const prec = m && m[1] !== undefined ? parseInt(m[1], 10) : 2;
  if (inverse && fmt === "%.2f") return formatDMS(n);
  return n.toFixed(isFinite(prec) ? prec : 2);
}

function formatDMS(v: number): string {
  const hemi = v < 0 ? "W" : "E";
  return `${Math.abs(v).toFixed(0)}d${hemi}`;
}

function processText(text: string, opts: Opts) {
  const lines = text.split(/\n/);
  for (let idx = 0; idx < lines.length; idx++) {
    if (idx === lines.length - 1 && lines[idx] === "") continue;
    const line = lines[idx];
    if (line.startsWith("#")) { console.log(line); continue; }
    const sp = splitLine(line);
    let x = sp.x, y = sp.y;
    if (opts.reverseInput) [x, y] = [y, x];
    if (opts.inverse) {
      const uf = unitFactor(opts.params);
      x *= uf; y *= uf;
    }
    const out = project(x, y, opts.params, opts.inverse);
    let a = NaN, b = NaN;
    if (out) {
      const unitDiv = opts.inverse ? 1 : unitFactor(opts.params);
      a = (out[0] / unitDiv) * opts.multiplier;
      b = (out[1] / unitDiv) * opts.multiplier;
    }
    if (opts.reverseOutput) [a, b] = [b, a];
    const first = formatNumber(a, opts.fmt, opts.inverse);
    let second = formatNumber(b, opts.fmt, false);
    if (opts.inverse && opts.fmt === "%.2f") second = `${Math.abs(b).toFixed(0)}d${b < 0 ? "S" : "N"}`;
    const prefix = opts.echo ? `${line}\t` : "";
    console.log(`${prefix}${first}\t${second}${sp.rest}`);
  }
}

function unitFactor(p: Params): number {
  const u = String(p.units || "m");
  const table: Record<string, number> = {
    m: 1, km: 1000, cm: 0.01, mm: 0.001, ft: 0.3048, "us-ft": 0.304800609601219,
    yd: 0.9144, mi: 1609.344, in: 0.0254
  };
  if (typeof p.to_meter === "string") {
    const n = parseFloat(p.to_meter);
    if (isFinite(n) && n !== 0) return n;
  }
  return table[u] || 1;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.list) { list(opts.list); return; }
  if (!opts.params.proj) {
    console.error("proj_create: unrecognized format / unknown name");
    die("projection initialization failure\ncause: Unknown error (code 2)");
  }
  if (opts.files.length === 0) {
    processText(fs.readFileSync(0, "utf8"), opts);
  } else {
    for (const f of opts.files) processText(fs.readFileSync(f, "utf8"), opts);
  }
}

main();
