declare function require(name: string): any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");

type Opts = {
  patterns: string[];
  patternFiles: string[];
  paths: string[];
  ignoreCase: boolean;
  caseSensitive: boolean;
  smartCase: boolean;
  fixed: boolean;
  invert: boolean;
  word: boolean;
  line: boolean;
  lineNumber: boolean | null;
  withFilename: boolean | null;
  count: boolean;
  countMatches: boolean;
  filesWithMatches: boolean;
  filesWithoutMatch: boolean;
  files: boolean;
  typeList: boolean;
  version: boolean;
  help: boolean;
  shortHelp: boolean;
  onlyMatching: boolean;
  column: boolean;
  byteOffset: boolean;
  quiet: boolean;
  before: number;
  after: number;
  maxCount: number | null;
  maxDepth: number | null;
  hidden: boolean;
  unrestricted: number;
  noIgnore: boolean;
  text: boolean;
  globs: string[];
  types: string[];
  notTypes: string[];
  sort: string | null;
  sortReverse: boolean;
  trim: boolean;
  nullSep: boolean;
  json: boolean;
  vimgrep: boolean;
  passthru: boolean;
  replace: string | null;
  color: string;
  heading: boolean;
};

const VERSION = `ripgrep 14.1.1 (rev 719e15af5e)`;
let FORCE_DOT_PREFIX = false;
let IGNORE_PATTERNS: string[] = [];

const TYPE_MAP: Record<string, string[]> = {
  c: [".c", ".h", ".H"], cpp: [".cpp", ".cc", ".cxx", ".hpp", ".hh", ".hxx", ".inl"],
  py: [".py", ".pyw"], python: [".py", ".pyw"], js: [".js", ".jsx", ".mjs", ".cjs"],
  javascript: [".js", ".jsx", ".mjs", ".cjs"], ts: [".ts", ".tsx"], typescript: [".ts", ".tsx"],
  rust: [".rs"], rs: [".rs"], go: [".go"], java: [".java"], rb: [".rb"], ruby: [".rb"],
  php: [".php"], html: [".html", ".htm"], css: [".css", ".scss"], json: [".json"],
  md: [".md", ".markdown"], markdown: [".md", ".markdown"], txt: [".txt"], toml: [".toml"],
  yaml: [".yaml", ".yml"], yml: [".yaml", ".yml"], xml: [".xml"], sh: [".sh", ".bash", ".zsh"],
  shell: [".sh", ".bash", ".zsh"], make: ["Makefile", ".mk"], docker: ["Dockerfile"]
};

function usage(long = false): string {
  const body = `${VERSION}
Andrew Gallant <jamslam@gmail.com>

ripgrep (rg) recursively searches the current directory for lines matching
a regex pattern. By default, ripgrep will respect gitignore rules and
automatically skip hidden files/directories and binary files.

USAGE:
  rg [OPTIONS] PATTERN [PATH ...]

INPUT OPTIONS:
  -e, --regexp=PATTERN            A pattern to search for.
  -f, --file=PATTERNFILE          Search for patterns from the given file.
SEARCH OPTIONS:
  -F, --fixed-strings             Treat all patterns as literals.
  -i, --ignore-case               Case insensitive search.
  -v, --invert-match              Invert matching.
  -w, --word-regexp               Show matches surrounded by word boundaries.
  -x, --line-regexp               Show matches surrounded by line boundaries.
FILTER OPTIONS:
  -g, --glob=GLOB                 Include or exclude file paths.
  -., --hidden                    Search hidden files and directories.
  -t, --type=TYPE                 Only search files matching TYPE.
  -T, --type-not=TYPE             Do not search files matching TYPE.
  -u, --unrestricted              Reduce the level of "smart" filtering.
OUTPUT OPTIONS:
  -A, --after-context=NUM         Show NUM lines after each match.
  -B, --before-context=NUM        Show NUM lines before each match.
  -C, --context=NUM               Show NUM lines before and after each match.
  -n, --line-number               Show line numbers.
  -N, --no-line-number            Suppress line numbers.
  -o, --only-matching             Print only matched parts of a line.
  -H, --with-filename             Print the file path with each matching line.
  -I, --no-filename               Never print the path with each matching line.
OUTPUT MODES:
  -c, --count                     Show count of matching lines for each file.
  -l, --files-with-matches        Print the paths with at least one match.
  --files-without-match           Print the paths that contain zero matches.
OTHER BEHAVIORS:
  --files                         Print each file that would be searched.
  --type-list                     Show all supported file types.
  -V, --version                   Print ripgrep's version.
`;
  return long ? body + "\nProject home page: https://github.com/BurntSushi/ripgrep\n" : body;
}

function defaultOpts(): Opts {
  return {patterns: [], patternFiles: [], paths: [], ignoreCase: false, caseSensitive: false, smartCase: false,
    fixed: false, invert: false, word: false, line: false, lineNumber: null, withFilename: null, count: false,
    countMatches: false, filesWithMatches: false, filesWithoutMatch: false, files: false, typeList: false,
    version: false, help: false, shortHelp: false, onlyMatching: false, column: false, byteOffset: false,
    quiet: false, before: 0, after: 0, maxCount: null, maxDepth: null, hidden: false, unrestricted: 0,
    noIgnore: false, text: false, globs: [], types: [], notTypes: [], sort: null, sortReverse: false,
    trim: false, nullSep: false, json: false, vimgrep: false, passthru: false, replace: null, color: "never",
    heading: false};
}

function die(msg: string): never {
  process.stderr.write(`rg: ${msg}\n`);
  process.exit(2);
  throw new Error(msg);
}

function parseNum(s: string | undefined, flag: string): number {
  if (s == null || s === "") die(`the argument '${flag}' requires a value but none was supplied`);
  const n = Number(s);
  if (!Number.isFinite(n) || n < 0) die(`invalid number for ${flag}: ${s}`);
  return Math.floor(n);
}

function parseArgs(argv: string[]): Opts {
  const o = defaultOpts();
  let positional = false;
  const take = (i: number, cur: string, name: string): [string, number] => {
    const eq = cur.indexOf("=");
    if (eq >= 0) return [cur.slice(eq + 1), i];
    if (i + 1 >= argv.length) die(`the argument '${name}' requires a value but none was supplied`);
    return [argv[i + 1], i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (positional || a === "-" || !a.startsWith("-")) { o.paths.push(a); continue; }
    if (a === "--") { positional = true; continue; }
    if (a.startsWith("--")) {
      const name = a.split("=")[0];
      if (name === "--help") o.help = true;
      else if (name === "--version") o.version = true;
      else if (name === "--type-list") o.typeList = true;
      else if (name === "--files") o.files = true;
      else if (name === "--regexp") { const r = take(i, a, "--regexp"); o.patterns.push(r[0]); i = r[1]; }
      else if (name === "--file") { const r = take(i, a, "--file"); o.patternFiles.push(r[0]); i = r[1]; }
      else if (name === "--ignore-case") o.ignoreCase = true;
      else if (name === "--case-sensitive") o.caseSensitive = true;
      else if (name === "--smart-case") o.smartCase = true;
      else if (name === "--fixed-strings") o.fixed = true;
      else if (name === "--invert-match") o.invert = true;
      else if (name === "--word-regexp") o.word = true;
      else if (name === "--line-regexp") o.line = true;
      else if (name === "--line-number") o.lineNumber = true;
      else if (name === "--no-line-number") o.lineNumber = false;
      else if (name === "--with-filename") o.withFilename = true;
      else if (name === "--no-filename") o.withFilename = false;
      else if (name === "--count") o.count = true;
      else if (name === "--count-matches") o.countMatches = true;
      else if (name === "--files-with-matches") o.filesWithMatches = true;
      else if (name === "--files-without-match") o.filesWithoutMatch = true;
      else if (name === "--only-matching") o.onlyMatching = true;
      else if (name === "--column") o.column = true;
      else if (name === "--byte-offset") o.byteOffset = true;
      else if (name === "--quiet") o.quiet = true;
      else if (name === "--hidden") o.hidden = true;
      else if (name === "--no-ignore") o.noIgnore = true;
      else if (name === "--text") o.text = true;
      else if (name === "--json") o.json = true;
      else if (name === "--vimgrep") o.vimgrep = true;
      else if (name === "--passthru") o.passthru = true;
      else if (name === "--trim") o.trim = true;
      else if (name === "--null") o.nullSep = true;
      else if (name === "--heading") o.heading = true;
      else if (name === "--glob" || name === "--iglob") { const r = take(i, a, name); o.globs.push(r[0]); i = r[1]; }
      else if (name === "--type") { const r = take(i, a, name); o.types.push(r[0]); i = r[1]; }
      else if (name === "--type-not") { const r = take(i, a, name); o.notTypes.push(r[0]); i = r[1]; }
      else if (name === "--after-context") { const r = take(i, a, name); o.after = parseNum(r[0], name); i = r[1]; }
      else if (name === "--before-context") { const r = take(i, a, name); o.before = parseNum(r[0], name); i = r[1]; }
      else if (name === "--context") { const r = take(i, a, name); o.before = o.after = parseNum(r[0], name); i = r[1]; }
      else if (name === "--max-count") { const r = take(i, a, name); o.maxCount = parseNum(r[0], name); i = r[1]; }
      else if (name === "--max-depth") { const r = take(i, a, name); o.maxDepth = parseNum(r[0], name); i = r[1]; }
      else if (name === "--replace") { const r = take(i, a, name); o.replace = r[0]; i = r[1]; }
      else if (name === "--color") { const r = take(i, a, name); o.color = r[0]; i = r[1]; }
      else if (name === "--sort") { const r = take(i, a, name); o.sort = r[0]; i = r[1]; }
      else if (name === "--sortr") { const r = take(i, a, name); o.sort = r[0]; o.sortReverse = true; i = r[1]; }
      else if (["--no-messages","--debug","--trace","--stats","--mmap","--no-mmap","--pcre2","--auto-hybrid-regex","--engine","--encoding","--pre","--pre-glob","--search-zip","--crlf","--null-data","--multiline","--multiline-dotall","--no-unicode","--block-buffered","--line-buffered","--sort-files","--include-zero","--follow","--binary","--no-ignore-vcs","--no-ignore-dot","--no-ignore-parent","--no-ignore-global","--no-ignore-files","--no-ignore-exclude","--no-require-git","--one-file-system","--glob-case-insensitive","--ignore-file","--ignore-file-case-insensitive","--max-filesize","--type-add","--type-clear","--colors","--context-separator","--field-context-separator","--field-match-separator","--path-separator","--max-columns","--max-columns-preview","--pcre2-version","--generate","--no-config","--hostname-bin","--hyperlink-format","--dfa-size-limit","--regex-size-limit","--stop-on-nonmatch","--no-pcre2-unicode"].includes(name)) {
        if (a.indexOf("=") < 0 && ["--engine","--encoding","--pre","--pre-glob","--ignore-file","--max-filesize","--type-add","--type-clear","--colors","--context-separator","--field-context-separator","--field-match-separator","--path-separator","--max-columns","--hostname-bin","--hyperlink-format","--dfa-size-limit","--regex-size-limit","--generate"].includes(name)) i++;
      } else die(`unrecognized flag ${a}`);
      continue;
    }
    for (let j = 1; j < a.length; j++) {
      const c = a[j];
      const rest = a.slice(j + 1);
      const val = (flag: string): string => { if (rest) { j = a.length; return rest; } if (++i >= argv.length) die(`the argument '${flag}' requires a value but none was supplied`); j = a.length; return argv[i]; };
      if (c === "h") o.shortHelp = true;
      else if (c === "V") o.version = true;
      else if (c === "e") o.patterns.push(val("-e"));
      else if (c === "f") o.patternFiles.push(val("-f"));
      else if (c === "i") o.ignoreCase = true;
      else if (c === "s") o.caseSensitive = true;
      else if (c === "S") o.smartCase = true;
      else if (c === "F") o.fixed = true;
      else if (c === "v") o.invert = true;
      else if (c === "w") o.word = true;
      else if (c === "x") o.line = true;
      else if (c === "n") o.lineNumber = true;
      else if (c === "N") o.lineNumber = false;
      else if (c === "H") o.withFilename = true;
      else if (c === "I") o.withFilename = false;
      else if (c === "c") o.count = true;
      else if (c === "l") o.filesWithMatches = true;
      else if (c === "o") o.onlyMatching = true;
      else if (c === "q") o.quiet = true;
      else if (c === "b") o.byteOffset = true;
      else if (c === "A") o.after = parseNum(val("-A"), "-A");
      else if (c === "B") o.before = parseNum(val("-B"), "-B");
      else if (c === "C") { const n = parseNum(val("-C"), "-C"); o.before = o.after = n; }
      else if (c === "m") o.maxCount = parseNum(val("-m"), "-m");
      else if (c === "d") o.maxDepth = parseNum(val("-d"), "-d");
      else if (c === "g") o.globs.push(val("-g"));
      else if (c === "t") o.types.push(val("-t"));
      else if (c === "T") o.notTypes.push(val("-T"));
      else if (c === "u") o.unrestricted++;
      else if (c === ".") o.hidden = true;
      else if (c === "a") o.text = true;
      else if (c === "0") o.nullSep = true;
      else if (c === "p") { o.color = "always"; o.heading = true; o.lineNumber = true; }
      else if (["L","z","P","U","M","r","j","E"].includes(c)) { if (["M","r","j","E"].includes(c)) val("-" + c); }
      else die(`unrecognized flag -${c}`);
    }
  }
  if (o.patterns.length === 0 && o.patternFiles.length === 0 && !o.files && !o.typeList && !o.version && !o.help && !o.shortHelp) {
    if (o.paths.length > 0) o.patterns.push(o.paths.shift() as string);
  }
  return o;
}

function escapeRe(s: string): string { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
function hasUpper(s: string): boolean { return /[A-Z]/.test(s); }

function loadPatterns(o: Opts): string[] {
  const ps = [...o.patterns];
  for (const pf of o.patternFiles) {
    const txt = pf === "-" ? fs.readFileSync(0, "utf8") : fs.readFileSync(pf, "utf8");
    for (const line of txt.split(/\r?\n/)) if (line.length || txt.endsWith("\n")) ps.push(line);
  }
  return ps;
}

function makeRegexes(o: Opts, patterns: string[]): RegExp[] {
  let flags = "g";
  if ((o.ignoreCase || (o.smartCase && !patterns.some(hasUpper))) && !o.caseSensitive) flags += "i";
  return patterns.map(p => {
    let q = o.fixed ? escapeRe(p) : p;
    if (o.word) q = `\\b(?:${q})\\b`;
    if (o.line) q = `^(?:${q})$`;
    try { return new RegExp(q, flags); } catch (e: any) { die(`regex parse error: ${e.message || e}`); }
  });
}

function isHidden(p: string): boolean {
  return p.split(/[\\/]/).some(part => part.length > 1 && part.startsWith("."));
}

function globToRe(g: string): RegExp {
  let s = "", i = 0;
  while (i < g.length) {
    const c = g[i++];
    if (c === "*") s += ".*";
    else if (c === "?") s += ".";
    else if (c === "{") {
      let end = g.indexOf("}", i);
      if (end >= 0) { s += "(" + g.slice(i, end).split(",").map(escapeRe).join("|") + ")"; i = end + 1; }
      else s += "\\{";
    } else s += escapeRe(c);
  }
  return new RegExp("^" + s + "$");
}

function matchesGlob(rel: string, g: string): boolean {
  const neg = g.startsWith("!");
  if (neg) g = g.slice(1);
  const base = path.basename(rel);
  const target = g.includes("/") ? rel : base;
  return globToRe(g).test(target);
}

function typeMatch(file: string, t: string): boolean {
  const rules = TYPE_MAP[t] || [];
  const base = path.basename(file);
  const ext = path.extname(file);
  return rules.some(r => r.startsWith(".") ? ext === r : base === r || base.includes(r.replaceAll("*", "")));
}

function shouldInclude(file: string, rel: string, o: Opts): boolean {
  if (!(o.hidden || o.unrestricted >= 2) && isHidden(rel)) return false;
  if (!(o.noIgnore || o.unrestricted >= 1)) {
    for (const pat of IGNORE_PATTERNS) {
      if (!pat || pat.startsWith("#")) continue;
      const neg = pat.startsWith("!");
      const g = neg ? pat.slice(1) : pat;
      const hit = matchesGlob(rel, g) || matchesGlob(path.basename(rel), g);
      if (hit && !neg) return false;
    }
  }
  if (o.types.length && !o.types.some(t => typeMatch(file, t))) return false;
  if (o.notTypes.some(t => typeMatch(file, t))) return false;
  for (const g of o.globs) {
    const neg = g.startsWith("!");
    const ok = matchesGlob(rel, g);
    if (neg && ok) return false;
    if (!neg && !ok) return false;
  }
  return true;
}

function loadIgnores() {
  IGNORE_PATTERNS = [];
  const cwd = process.cwd();
  const hasGit = fs.existsSync(path.join(cwd, ".git"));
  for (const name of [".ignore", ".rgignore", ...(hasGit ? [".gitignore"] : [])]) {
    const p = path.join(cwd, name);
    try {
      const txt = fs.readFileSync(p, "utf8");
      IGNORE_PATTERNS.push(...txt.split(/\r?\n/).filter((x: string) => x.length));
    } catch {}
  }
}

function walk(input: string, o: Opts, root = process.cwd(), depth = 0): string[] {
  let st: any;
  try { st = fs.statSync(input); } catch { process.stderr.write(`rg: ${input}: No such file or directory (os error 2)\n`); return []; }
  if (st.isFile()) return [input];
  if (!st.isDirectory()) return [];
  if (o.maxDepth !== null && depth > o.maxDepth) return [];
  let out: string[] = [];
  let entries: string[] = [];
  try { entries = fs.readdirSync(input); } catch { return []; }
  for (const e of entries) {
    const p = path.join(input, e);
    const rel = path.relative(root, p) || e;
    let st2: any; try { st2 = fs.statSync(p); } catch { continue; }
    if (st2.isDirectory()) {
      if (!(o.hidden || o.unrestricted >= 2) && e.startsWith(".")) continue;
      if (o.maxDepth === null || depth < o.maxDepth) out = out.concat(walk(p, o, root, depth + 1));
    } else if (st2.isFile() && shouldInclude(p, rel, o)) out.push(p);
  }
  return out;
}

function collectFiles(paths: string[], o: Opts): string[] {
  const roots = paths.length ? paths : ["."];
  let files: string[] = [];
  for (const p of roots) files = files.concat(walk(p, o, path.resolve(p) === path.resolve(".") ? process.cwd() : path.dirname(path.resolve(p)), 0));
  if (o.sort) files.sort((a, b) => a.localeCompare(b));
  if (o.sortReverse) files.reverse();
  return files;
}

function splitLines(buf: any): {text: string, offset: number, newline: string}[] {
  const s = buf.toString("utf8");
  const lines: {text: string, offset: number, newline: string}[] = [];
  let start = 0;
  for (let i = 0; i < s.length; i++) {
    if (s[i] === "\n") {
      const end = i > start && s[i - 1] === "\r" ? i - 1 : i;
      lines.push({text: s.slice(start, end), offset: Buffer.byteLength(s.slice(0, start)), newline: s.slice(end, i + 1)});
      start = i + 1;
    }
  }
  if (start < s.length) lines.push({text: s.slice(start), offset: Buffer.byteLength(s.slice(0, start)), newline: ""});
  return lines;
}

function findMatches(line: string, regs: RegExp[]): {start: number, end: number, text: string}[] {
  const ms: {start: number, end: number, text: string}[] = [];
  for (const r of regs) {
    r.lastIndex = 0;
    let m: any;
    while ((m = r.exec(line)) !== null) {
      ms.push({start: m.index, end: m.index + m[0].length, text: m[0]});
      if (m[0].length === 0) r.lastIndex++;
    }
  }
  ms.sort((a, b) => a.start - b.start || a.end - b.end);
  return ms;
}

function displayPath(file: string, rootsCount: number): string {
  if (file === "-") return "";
  let rel = path.relative(process.cwd(), file) || file;
  if (!rel.startsWith(".") && (file.startsWith("./") || FORCE_DOT_PREFIX)) rel = "./" + rel;
  return rel;
}

function colorize(line: string, ms: any[], o: Opts): string {
  if (o.color !== "always" || ms.length === 0) return line;
  let out = "", pos = 0;
  for (const m of ms) { out += line.slice(pos, m.start) + "\x1b[0m\x1b[1m\x1b[31m" + line.slice(m.start, m.end) + "\x1b[0m"; pos = m.end; }
  return out + line.slice(pos);
}

function formatLine(prefixPath: string, lineNo: number, col: number | null, byteOff: number | null, text: string, matched: boolean, o: Opts, showFile: boolean, context = false): string {
  const sep = context ? "-" : ":";
  const parts: string[] = [];
  if (showFile && prefixPath) parts.push(prefixPath);
  if (o.lineNumber === true || (o.lineNumber === null && false)) parts.push(String(lineNo));
  if (o.column && col !== null && !context) parts.push(String(col));
  if (o.byteOffset && byteOff !== null) parts.push(String(byteOff));
  let body = o.trim ? text.trimStart() : text;
  if (parts.length === 0) return body;
  return parts.join(sep) + sep + body;
}

function searchOne(file: string, content: any, regs: RegExp[], o: Opts, showFile: boolean, rootsCount: number): {matched: boolean, output: string[], matchLines: number, matches: number} {
  if (!(o.text || o.unrestricted >= 3) && content.includes && content.includes(0)) return {matched:false, output:[], matchLines:0, matches:0};
  const p = file === "-" ? "" : displayPath(file, rootsCount);
  const lines = splitLines(content);
  const out: string[] = [];
  let matchedAny = false, matchLines = 0, matchesN = 0, lastPrinted = -1, printedMatch = 0;
  const emitContext = (idx: number, matched: boolean, ms: any[]) => {
    const ln = lines[idx];
    const text = matched ? colorize(ln.text, ms, o) : ln.text;
    out.push(formatLine(p, idx + 1, ms[0] ? ms[0].start + 1 : null, ln.offset, text, matched, o, showFile, !matched));
    lastPrinted = idx;
  };
  for (let i = 0; i < lines.length; i++) {
    const ms = findMatches(lines[i].text, regs);
    let ok = ms.length > 0;
    if (o.invert) ok = !ok;
    if (o.passthru) ok = true;
    if (ok) {
      matchedAny = true;
      if (!o.passthru || ms.length) { matchLines++; matchesN += Math.max(1, ms.length); printedMatch++; }
      if (o.quiet) continue;
      if (o.filesWithMatches || o.filesWithoutMatch || o.count || o.countMatches) continue;
      if (o.vimgrep && !o.invert) {
        for (const m of ms.length ? ms : [{start: 0, end: 0, text: ""}]) {
          const vp = p || file;
          out.push(`${vp}:${i + 1}:${m.start + 1}:${lines[i].text}`);
        }
      } else if (o.onlyMatching && !o.invert) {
        for (const m of ms) {
          const s = o.replace !== null ? m.text.replace(regs[0], o.replace) : m.text;
          out.push(formatLine(p, i + 1, m.start + 1, lines[i].offset + Buffer.byteLength(lines[i].text.slice(0, m.start)), s, true, o, showFile, false));
        }
      } else {
        for (let c = Math.max(0, i - o.before); c < i; c++) {
          if (c <= lastPrinted) continue;
          if (lastPrinted >= 0 && c > lastPrinted + 1) out.push("--");
          emitContext(c, false, []);
        }
        if (lastPrinted >= 0 && i > lastPrinted + 1 && (o.before || o.after)) out.push("--");
        let text = lines[i].text;
        if (o.replace !== null && !o.invert) for (const r of regs) { r.lastIndex = 0; text = text.replace(r, o.replace); }
        out.push(formatLine(p, i + 1, ms[0] ? ms[0].start + 1 : 1, lines[i].offset, colorize(text, ms, o), true, o, showFile, false));
        lastPrinted = i;
        for (let c = i + 1; c <= Math.min(lines.length - 1, i + o.after); c++) if (c > lastPrinted) emitContext(c, false, []);
      }
      if (o.maxCount !== null && printedMatch >= o.maxCount) break;
    }
  }
  if (o.filesWithoutMatch) matchedAny = matchLines > 0;
  return {matched: matchedAny, output: out, matchLines, matches: matchesN};
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  FORCE_DOT_PREFIX = o.paths.includes(".");
  loadIgnores();
  if (o.version) { process.stdout.write(`${VERSION}\n\nfeatures:-pcre2\nsimd(compile):+SSE2,-SSSE3,-AVX2\nsimd(runtime):+SSE2,+SSSE3,+AVX2\n\nPCRE2 is not available in this build of ripgrep.\n`); return; }
  if (o.help || o.shortHelp) { process.stdout.write(usage(o.help)); return; }
  if (o.typeList) {
    const keys = Object.keys(TYPE_MAP).sort();
    for (const k of keys) process.stdout.write(`${k}: ${TYPE_MAP[k].map(x => x.startsWith(".") ? "*" + x : x).join(", ")}\n`);
    return;
  }
  if (o.files) {
    for (const f of collectFiles(o.paths, o)) process.stdout.write(displayPath(f, o.paths.length) + (o.nullSep ? "\0" : "\n"));
    return;
  }
  if (o.patterns.length === 0 && o.patternFiles.length === 0) die("ripgrep requires at least one pattern to execute a search");
  const patterns = loadPatterns(o);
  const regs = makeRegexes(o, patterns);
  let stdinHasData = false;
  try {
    const st = fs.fstatSync(0);
    stdinHasData = !process.stdin.isTTY && (st.isFIFO() || st.isFile());
  } catch {}
  const stdinMode = o.paths.length === 0 && stdinHasData;
  const files = stdinMode ? ["-"] : collectFiles(o.paths.length ? o.paths : ["."], o);
  const showFile = o.withFilename !== null ? o.withFilename : (!stdinMode && (files.length > 1 || (o.paths.some((p: string) => { try { return fs.statSync(p).isDirectory(); } catch { return false; } }))));
  let any = false;
  const allOut: string[] = [];
  if (o.json) allOut.push(JSON.stringify({type:"begin",data:{path:{text: files[0] && files[0] !== "-" ? displayPath(files[0], o.paths.length) : "<stdin>"}}}));
  for (const f of files) {
    let buf: any; try { buf = f === "-" ? fs.readFileSync(0) : fs.readFileSync(f); } catch (e: any) { process.stderr.write(`rg: ${f}: ${e.message}\n`); continue; }
    const res = searchOne(f, buf, regs, o, showFile, o.paths.length);
    if (res.matchLines > 0) any = true;
    const p = f === "-" ? "" : displayPath(f, o.paths.length);
    if (o.quiet && any) process.exit(0);
    if (o.filesWithMatches && res.matchLines > 0) allOut.push(p);
    else if (o.filesWithoutMatch && res.matchLines === 0) allOut.push(p);
    else if (o.count || o.countMatches) {
      const n = o.countMatches ? res.matches : res.matchLines;
      if (showFile && p) allOut.push(`${p}:${n}`); else allOut.push(String(n));
    } else if (o.json) {
      for (const line of splitLines(buf)) {
        const ms = findMatches(line.text, regs);
        if (ms.length) allOut.push(JSON.stringify({type:"match",data:{path:{text:p},lines:{text:line.text + line.newline},line_number:1,absolute_offset:line.offset,submatches:ms.map(m=>({match:{text:m.text},start:m.start,end:m.end}))}}));
      }
    } else allOut.push(...res.output);
  }
  if (o.json) allOut.push(JSON.stringify({type:"summary",data:{elapsed_total:{human:"0.000000s",nanos:0,secs:0},stats:{bytes_printed:0,bytes_searched:0,elapsed:{human:"0.000000s",nanos:0,secs:0},matched_lines:0,matches:0,searches:files.length,searches_with_match:any?1:0}}}));
  if (!o.quiet) process.stdout.write(allOut.join("\n") + (allOut.length ? "\n" : ""));
  process.exit(any ? 0 : 1);
}

main();
