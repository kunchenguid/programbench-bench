// @ts-nocheck
import * as fs from "fs";
import * as path from "path";

type Tag = {
  name: string;
  file: string;
  line: number;
  text: string;
  patternText?: string;
  patternComplete?: boolean;
  letter: string;
  kind: string;
  scopeKind?: string;
  scope?: string;
  typeref?: string;
  fileScope?: boolean;
};

const VERSION =
  "Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team\n" +
  "Universal Ctags is derived from Exuberant Ctags.\n" +
  "Exuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert\n" +
  "  Compiled: Apr 20 2026, 16:52:56\n" +
  "  URL: https://ctags.io/\n" +
  "  Output version: 1.1\n" +
  "  Optional compiled features: +wildcards, +regex, +iconv, +option-directory, +xpath, +json, +interactive, +sandbox, +yaml, +packcc, +optscript";

const LANGS = [
  "Abaqus","Abc","Ada","AnsiblePlaybook","Ant","Asciidoc","Asm","Asp","Autoconf","AutoIt","Automake","Awk","Basic","Bats","BETA","BibLaTeX","BibTeX","C","C#","C++","Cargo [disabled]","Clojure","CMake","Cobol","CobolFree","CobolVariable","CPreProcessor","CSS","Ctags","CUDA","D","DBusIntrospect","DBusService","Diff","DosBatch","DTD","DTS","Eiffel","Elixir","Elm","EmacsLisp","Erlang","Falcon","Flex","Forth","Fortran","FrontMatter","FunctionParameters","Fypp","Gdbinit","GDScript","GemSpec","Glade","Go","GoMod","GPerf","Haskell","Haxe","HTML","I18nRubyGem","Iniconf","Inko","IPythonCell","ITCl","Java","JavaProperties","JavaScript","JNI","JSON","Julia","Kconfig","Kotlin","LdScript","LEX","Lisp","LiterateHaskell","Lua","M4","Make","Man","Markdown","MatLab","Meson","Myrddin","NSIS","ObjectiveC","OCaml","Odin","OpenAPI","Org","Pascal","Passwd","Perl","Perl6","PHP","PkgConfig","PlistXML","Pod","PowerShell","Prolog","Protobuf","PuppetManifest","Python","PythonEntryPoints","PythonLoggingConfig","QemuHX","QtMoc","Quarto","R","R6Class","Rake","Raku","RelaxNG","ReStructuredText","REXX","RMarkdown","Robot","RpmMacros","RpmSpec","RSpec","Ruby","Rust","S4Class","Scdoc","Scheme","SCSS","SELinuxInterface","SELinuxTypeEnforcement","Sh","SINEX","SLang","SML","SQL","SVG","SystemdUnit","SystemTap","SystemVerilog","Tcl","TclOO","Terraform","TerraformVariables","Tex","TeXBeamer","Thrift","TOML [disabled]","TTCN","Txt2tags","TypeScript","TypeSpec","Unknown [disabled]","V","Varlink","Vera","Verilog","VHDL","Vim","WindRes","XML","XRC","XSLT","YACC","Yaml","YumRepo","Zephir","Zsh"
];

const kindNames: Record<string, Record<string, string>> = {
  C: { d: "macro", e: "enumerator", f: "function", g: "enum", h: "header", l: "local", m: "member", p: "prototype", s: "struct", t: "typedef", u: "union", v: "variable", x: "externvar", z: "parameter" },
  "C++": { c: "class", d: "macro", e: "enumerator", f: "function", g: "enum", m: "member", n: "namespace", p: "prototype", s: "struct", t: "typedef", u: "union", v: "variable" },
  Python: { c: "class", f: "function", m: "member", v: "variable", i: "module" },
  JavaScript: { f: "function", c: "class", m: "method", p: "property", C: "constant", v: "variable", g: "generator", G: "getter", S: "setter", M: "field" },
  TypeScript: { f: "function", c: "class", i: "interface", m: "method", p: "property", C: "constant", v: "variable", e: "enumerator", g: "enum", a: "alias" },
  Go: { c: "const", f: "func", i: "interface", m: "member", n: "methodSpec", p: "package", s: "struct", t: "type", v: "var" },
  Rust: { C: "constant", e: "enumerator", f: "function", g: "enum", i: "interface", m: "field", n: "module", P: "method", s: "struct", t: "typedef" },
  Java: { c: "class", e: "enumConstant", f: "field", g: "enum", i: "interface", m: "method", p: "package" },
  Ruby: { c: "class", f: "method", m: "module", F: "singletonMethod" },
  Sh: { f: "function", v: "variable" },
  Make: { m: "macro", t: "target" },
};

function usage(): string {
  return `${VERSION}

Usage: executable [options] [file(s)]

Input/Output Options
  --exclude=<pattern>
       Exclude files and directories matching <pattern>.
  --filter[=(yes|no)]
       Behave as a filter, reading file names from standard input and
       writing tags to standard output [no].
  --links[=(yes|no)]
       Indicate whether symbolic links should be followed [yes].
  --maxdepth=<N>
       Specify maximum recursion depth.
  --recurse[=(yes|no)]
       Recurse into directories supplied on command line [no].
  -R   Equivalent to --recurse.
  -L <file>
       A list of input file names is read from the specified <file>.
  --append[=(yes|no)]
       Should tags should be appended to existing tag file [no]?
  -a   Append the tags to an existing tag file.
  -f <tagfile>
       Write tags to specified <tagfile>. Value of "-" writes tags to stdout
       ["tags"; or "TAGS" when -e supplied].
  -o   Alternative for -f.

Output Format Options
  --output-format=(u-ctags|e-ctags|etags|xref|json)
      Specify the output format. [u-ctags]
  -e   Output tag file for use with Emacs.
  -x   Print a tabular cross reference file to standard output.
  --sort=(yes|no|foldcase)
       Should tags be sorted (optionally ignoring case) [yes]?
  -u   Equivalent to --sort=no.

Language Selection and Mapping Options
  --language-force=(<language>|auto)
       Force all files to be interpreted using specified <language>.
  --list-languages
       Output list of supported languages.

Miscellaneous Options
  --help
       Print this option summary.
  --license
       Print details of software license.
  --print-language
       Don't make tags file but just print the guessed language name for
       input file.
  --totals[=(yes|no|extra)]
       Print statistics about input and tag files [no].
  --verbose[=(yes|no)]
       Enable verbose messages describing actions on each input file.
  --version[=<language>]
       Print version identifier of the program to standard output.
  -V   Equivalent to --verbose.`;
}

function readStdin(): string {
  try { return fs.readFileSync(0, "utf8"); } catch { return ""; }
}

function parseBool(s: string | undefined, def: boolean): boolean {
  if (s === undefined || s === "") return def;
  return !/^(no|false|0)$/i.test(s);
}

function parseArgs(argv: string[]) {
  const opt: any = { files: [], output: "tags", sort: "yes", format: "u-ctags", recurse: false, append: false, excludes: [], maxdepth: Infinity, fields: "fks" };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = () => argv[++i] || "";
    if (a === "--help" || a === "-?") opt.help = true;
    else if (a === "--help-full") opt.help = true;
    else if (a.startsWith("--version")) opt.version = true;
    else if (a === "--license") opt.license = true;
    else if (a === "--list-languages") opt.listLanguages = true;
    else if (a.startsWith("--list-languages=")) opt.listLanguages = true;
    else if (a.startsWith("--list-features")) opt.listFeatures = true;
    else if (a.startsWith("--list-output-formats")) opt.listFormats = true;
    else if (a.startsWith("--list-kinds")) opt.listKinds = a.includes("=") ? a.split("=")[1] : (argv[i + 1] && !argv[i + 1].startsWith("-") ? next() : "all");
    else if (a.startsWith("--list-fields")) opt.listFields = true;
    else if (a.startsWith("--list-extras")) opt.listExtras = true;
    else if (a === "-f" || a === "-o") opt.output = next();
    else if (a.startsWith("-f") && a.length > 2) opt.output = a.slice(2);
    else if (a.startsWith("--output-format=")) opt.format = a.split("=")[1];
    else if (a === "-x") { opt.format = "xref"; opt.output = "-"; }
    else if (a === "-e") { opt.format = "etags"; opt.output = "TAGS"; }
    else if (a === "-R") opt.recurse = true;
    else if (a.startsWith("--recurse")) opt.recurse = parseBool(a.split("=")[1], true);
    else if (a === "-u") opt.sort = "no";
    else if (a.startsWith("--sort=")) opt.sort = a.split("=")[1];
    else if (a === "-a") opt.append = true;
    else if (a.startsWith("--append")) opt.append = parseBool(a.split("=")[1], true);
    else if (a === "-L") opt.listFile = next();
    else if (a.startsWith("--language-force=")) opt.langForce = canonicalLang(a.split("=")[1]);
    else if (a.startsWith("--languages=")) opt.languages = a.split("=")[1].replace(/^[+-]/, "").split(",");
    else if (a.startsWith("--fields=")) opt.fields = a.split("=")[1].replace(/^[+-]/, "");
    else if (a.startsWith("--kinds-")) {
      const eq = a.indexOf("=");
      if (eq >= 0) {
        opt.kindFilters = opt.kindFilters || {};
        opt.kindFilters[canonicalLang(a.slice("--kinds-".length, eq))] = a.slice(eq + 1);
      }
    }
    else if (a.startsWith("--extras=")) opt.extras = a.split("=")[1];
    else if (a === "--print-language") opt.printLanguage = true;
    else if (a.startsWith("--totals")) opt.totals = parseBool(a.split("=")[1], true);
    else if (a === "-V" || a.startsWith("--verbose")) opt.verbose = parseBool(a.split("=")[1], true);
    else if (a.startsWith("--exclude=")) opt.excludes.push(a.slice("--exclude=".length));
    else if (a.startsWith("--maxdepth=")) opt.maxdepth = Number(a.split("=")[1]);
    else if (a.startsWith("--filter")) { opt.filter = parseBool(a.split("=")[1], true); opt.output = "-"; }
    else if (a.startsWith("--filter-terminator=")) opt.filterTerminator = a.slice("--filter-terminator=".length);
    else if (a === "--") opt.files.push(...argv.slice(i + 1)), i = argv.length;
    else if (a.startsWith("-")) {
      // Accepted but mostly ignored compatibility options.
      if (["-n","-N","-B","-F","-G"].includes(a)) continue;
      if (["-I","-D","-h"].includes(a)) i++;
    } else opt.files.push(a);
  }
  return opt;
}

function canonicalLang(s: string): string {
  const low = (s || "").toLowerCase();
  const map: any = { c: "C", cpp: "C++", "c++": "C++", python: "Python", py: "Python", javascript: "JavaScript", js: "JavaScript", typescript: "TypeScript", ts: "TypeScript", go: "Go", rust: "Rust", rs: "Rust", java: "Java", ruby: "Ruby", rb: "Ruby", sh: "Sh", bash: "Sh", make: "Make", makefile: "Make", php: "PHP", json: "JSON", yaml: "Yaml", yml: "Yaml", html: "HTML", css: "CSS" };
  return map[low] || s;
}

function detectLang(file: string): string {
  const base = path.basename(file);
  const ext = path.extname(file).toLowerCase();
  if (/^(Makefile|makefile|GNUmakefile)$/.test(base)) return "Make";
  const m: any = { ".c": "C", ".h": "C", ".cpp": "C++", ".cc": "C++", ".cxx": "C++", ".hpp": "C++", ".hh": "C++", ".py": "Python", ".js": "JavaScript", ".mjs": "JavaScript", ".cjs": "JavaScript", ".ts": "TypeScript", ".tsx": "TypeScript", ".jsx": "JavaScript", ".go": "Go", ".rs": "Rust", ".java": "Java", ".rb": "Ruby", ".sh": "Sh", ".bash": "Sh", ".zsh": "Zsh", ".php": "PHP", ".json": "JSON", ".yaml": "Yaml", ".yml": "Yaml", ".html": "HTML", ".htm": "HTML", ".css": "CSS", ".scss": "SCSS", ".sql": "SQL", ".lua": "Lua", ".pl": "Perl" };
  return m[ext] || "Unknown";
}

function globToRegExp(g: string): RegExp {
  const esc = g.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
  return new RegExp("^" + esc + "$");
}

function collectFiles(inputs: string[], opt: any): string[] {
  const out: string[] = [];
  const ex = opt.excludes.map(globToRegExp);
  const skip = (p: string) => ex.some((r: RegExp) => r.test(path.basename(p)) || r.test(p));
  const walk = (p: string, depth: number) => {
    if (skip(p)) return;
    let st: fs.Stats;
    try { st = fs.statSync(p); } catch { return; }
    if (st.isDirectory()) {
      if (!opt.recurse || depth >= opt.maxdepth) return;
      for (const child of fs.readdirSync(p)) walk(path.join(p, child), depth + 1);
    } else if (st.isFile()) out.push(p);
  };
  for (const f of inputs) walk(f, 0);
  return out;
}

function escPattern(s: string): string {
  return s.replace(/\\/g, "\\\\").replace(/\//g, "\\/").replace(/\$/g, "\\$");
}

function add(tags: Tag[], file: string, line: number, text: string, name: string, letter: string, kind: string, extras: Partial<Tag> = {}) {
  if (!name || /^[_\W]*$/.test(name)) return;
  tags.push({ name, file, line, text: text.replace(/\r$/, ""), letter, kind, ...extras });
}

function parseFile(file: string, lang: string): Tag[] {
  let src = "";
  try { src = fs.readFileSync(file, "utf8"); } catch { return []; }
  const lines = src.split(/\n/);
  if (lang === "C" || lang === "C++") return parseC(lines, file, lang);
  if (lang === "Python") return parsePython(lines, file);
  if (lang === "JavaScript" || lang === "TypeScript") return parseJS(lines, file, lang);
  if (lang === "Go") return parseGo(lines, file);
  if (lang === "Rust") return parseRust(lines, file);
  if (lang === "Java") return parseJava(lines, file);
  if (lang === "Ruby") return parseRuby(lines, file);
  if (lang === "Sh" || lang === "Zsh") return parseSh(lines, file);
  if (lang === "Make") return parseMake(lines, file);
  if (lang === "PHP") return parsePHP(lines, file);
  return parseGeneric(lines, file);
}

function parseC(lines: string[], file: string, lang: string): Tag[] {
  const tags: Tag[] = [];
  const stack: any[] = [];
  let pending: any = null;
  const typeWords = "(?:[A-Za-z_][\\w:<>~*&\\s]+?)";
  for (let i = 0; i < lines.length; i++) {
    const text = lines[i];
    const s = text.trim();
    let m;
    if ((m = s.match(/^#\s*define\s+([A-Za-z_]\w*)(\([^)]*\))?(\s+.*)?$/))) {
      const pat = m[2] ? `#define ${m[1]}(` : m[3] ? `#define ${m[1]} ` : `#define ${m[1]}`;
      add(tags, file, i + 1, text, m[1], "d", "macro", { fileScope: true, patternText: pat, patternComplete: !m[2] && !m[3] });
    }
    if ((m = s.match(/\btypedef\s+(struct|union|enum)\s+([A-Za-z_]\w*)?.*?\}\s*([A-Za-z_]\w*)\s*;/))) {
      const sk = m[1], inner = m[2] || m[3], name = m[3];
      add(tags, file, i + 1, text, inner, sk === "union" ? "u" : sk === "enum" ? "g" : "s", sk, { fileScope: true });
      add(tags, file, i + 1, text, name, "t", "typedef", { typeref: `${sk}:${inner}`, fileScope: true });
      const body = s.replace(/^.*?\{/, "").replace(/\}.*$/, "");
      for (const mm of body.matchAll(/\b([A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s*(?:[:;\[,=]|$)/g)) add(tags, file, i + 1, text, mm[2], "m", "member", { scopeKind: sk, scope: inner, typeref: `typename:${mm[1]}`, fileScope: true });
    } else if ((m = s.match(/\b(struct|union|enum|class)\s+([A-Za-z_]\w*)/))) {
      const letter = m[1] === "class" ? "c" : m[1] === "union" ? "u" : m[1] === "enum" ? "g" : "s";
      add(tags, file, i + 1, text, m[2], letter, m[1], { fileScope: /^static\b/.test(s) });
      if (s.includes("{")) stack.push({ kind: m[1], name: m[2], braces: 1 });
    }
    if ((m = s.match(new RegExp(`^(?:static\\s+|inline\\s+|extern\\s+|virtual\\s+|constexpr\\s+)*(${typeWords})\\s+([A-Za-z_~]\\w*)\\s*\\([^;]*\\)\\s*(?:\\{|$)`))) && !/^(if|for|while|switch|return)\b/.test(s)) {
      const typ = m[1].trim().split(/\s+/).pop() || m[1].trim();
      add(tags, file, i + 1, text, m[2], "f", "function", { typeref: `typename:${typ.replace(/[&*]/g, "")}`, fileScope: /^static\b/.test(s) });
    } else if ((m = s.match(new RegExp(`^(?:static\\s+|extern\\s+|const\\s+)*(${typeWords})\\s+([A-Za-z_]\\w*)\\s*(?:=[^;]*)?;\\s*$`))) && !/\(/.test(s)) {
      const typ = m[1].trim().split(/\s+/).pop() || m[1].trim();
      add(tags, file, i + 1, text, m[2], "v", "variable", { typeref: `typename:${typ.replace(/[&*]/g, "")}`, fileScope: /^static\b/.test(s) });
    }
    const top = stack[stack.length - 1];
    if (top && (m = s.match(/^\s*(?:public:|private:|protected:)?\s*([A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s*[;=]/))) {
      add(tags, file, i + 1, text, m[2], "m", "member", { scopeKind: top.kind, scope: top.name, typeref: `typename:${m[1]}` });
    }
    if (top) {
      top.braces += (text.match(/\{/g) || []).length - (text.match(/\}/g) || []).length;
      if (top.braces <= 0) stack.pop();
    }
  }
  return tags;
}

function parsePython(lines: string[], file: string): Tag[] {
  const tags: Tag[] = [], classes: any[] = [];
  for (let i = 0; i < lines.length; i++) {
    const text = lines[i], s = text.trim(), indent = (text.match(/^\s*/) || [""])[0].length;
    while (classes.length && indent <= classes[classes.length - 1].indent && s) classes.pop();
    let m;
    if ((m = s.match(/^class\s+([A-Za-z_]\w*)/))) { add(tags, file, i + 1, text, m[1], "c", "class"); classes.push({ name: m[1], indent }); }
    else if ((m = s.match(/^(?:async\s+)?def\s+([A-Za-z_]\w*)\s*\(/))) {
      const c = classes[classes.length - 1];
      add(tags, file, i + 1, text, m[1], c ? "m" : "f", c ? "member" : "function", c ? { scopeKind: "class", scope: c.name } : {});
    } else if (!classes.length && (m = s.match(/^([A-Za-z_]\w*)\s*[:=]/))) add(tags, file, i + 1, text, m[1], "v", "variable");
  }
  return tags;
}

function parseJS(lines: string[], file: string, lang: string): Tag[] {
  const tags: Tag[] = [], classes: any[] = [];
  for (let i = 0; i < lines.length; i++) {
    const text = lines[i], s = text.trim();
    let m;
    if ((m = s.match(/^(?:export\s+default\s+|export\s+)?class\s+([A-Za-z_$][\w$]*)/))) {
      add(tags, file, i + 1, text, m[1], "c", "class");
      classes.push({ name: m[1], depth: 0 });
      for (const mm of s.matchAll(/\b([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{/g)) if (!["if","for","while","switch","function","class"].includes(mm[1])) add(tags, file, i + 1, text, mm[1], "m", "method", { scopeKind: "class", scope: m[1] });
    }
    if ((m = s.match(/^(?:export\s+)?(?:async\s+)?function\*?\s+([A-Za-z_$][\w$]*)\s*\(/))) add(tags, file, i + 1, text, m[1], "f", "function");
    else if (lang !== "TypeScript" && (m = s.match(/^(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:function\b|\([^)]*\)\s*=>|[A-Za-z_$][\w$]*\s*=>)/))) add(tags, file, i + 1, text, m[1], "f", "function");
    else if ((m = s.match(/^(?:export\s+)?const\s+([A-Za-z_$][\w$]*)\s*=/))) add(tags, file, i + 1, text, m[1], "C", "constant");
    else if ((m = s.match(/^(?:export\s+)?(?:let|var)\s+([A-Za-z_$][\w$]*)\s*=/))) add(tags, file, i + 1, text, m[1], "v", "variable");
    if ((m = s.match(/^exports\.([A-Za-z_$][\w$]*)\s*=\s*(?:function|\([^)]*\)\s*=>)/))) add(tags, file, i + 1, text, m[1], "f", "function", { scopeKind: "variable", scope: "exports" });
    if (lang === "TypeScript") {
      if ((m = s.match(/^(?:export\s+)?interface\s+([A-Za-z_$][\w$]*)/))) add(tags, file, i + 1, text, m[1], "i", "interface");
      if ((m = s.match(/^(?:export\s+)?interface\s+([A-Za-z_$][\w$]*).*?\{(.*)\}/))) for (const pm of m[2].matchAll(/\b([A-Za-z_$][\w$]*)\s*[:(?]/g)) add(tags, file, i + 1, text, pm[1], "p", "property", { scopeKind: "interface", scope: m[1] });
      if ((m = s.match(/^(?:export\s+)?type\s+([A-Za-z_$][\w$]*)\s*=/))) add(tags, file, i + 1, text, m[1], "a", "alias");
      if ((m = s.match(/^(?:export\s+)?enum\s+([A-Za-z_$][\w$]*).*?\{(.*)\}/))) {
        add(tags, file, i + 1, text, m[1], "g", "enum");
        for (const em of m[2].matchAll(/\b([A-Za-z_$][\w$]*)\b/g)) add(tags, file, i + 1, text, em[1], "e", "enumerator", { scopeKind: "enum", scope: m[1] });
      }
    }
  }
  return tags;
}

function parseGo(lines: string[], file: string): Tag[] {
  const tags: Tag[] = [];
  let pkg = "";
  for (let i = 0; i < lines.length; i++) {
    const text = lines[i], s = text.trim(); let m;
    if ((m = s.match(/^package\s+(\w+)/))) { pkg = m[1]; add(tags, file, i + 1, text, m[1], "p", "package"); }
    if ((m = s.match(/^func\s+\([^)]*\s+([A-Za-z_]\w*)\)\s*([A-Za-z_]\w*)\s*\(/))) add(tags, file, i + 1, text, m[2], "f", "func", { scopeKind: "struct", scope: `${pkg}.${m[1]}` });
    else if ((m = s.match(/^func\s+([A-Za-z_]\w*)\s*\([^)]*\)\s*([A-Za-z_]\w*)?/))) add(tags, file, i + 1, text, m[1], "f", "func", { scopeKind: "package", scope: pkg, typeref: m[2] ? `typename:${m[2]}` : undefined });
    if ((m = s.match(/^type\s+([A-Za-z_]\w*)\s+struct\b.*?\{(.*)\}/))) {
      add(tags, file, i + 1, text, m[1], "s", "struct", { scopeKind: "package", scope: pkg });
      for (const mm of m[2].matchAll(/\b([A-Za-z_]\w*)\s+([A-Za-z_]\w*)/g)) add(tags, file, i + 1, text, mm[1], "m", "member", { scopeKind: "struct", scope: `${pkg}.${m[1]}`, typeref: `typename:${mm[2]}` });
    } else if ((m = s.match(/^type\s+([A-Za-z_]\w*)\s+interface\b.*?\{(.*)\}/))) {
      add(tags, file, i + 1, text, m[1], "i", "interface", { scopeKind: "package", scope: pkg });
      for (const mm of m[2].matchAll(/\b([A-Za-z_]\w*)\s*\([^)]*\)\s*([A-Za-z_]\w*)?/g)) add(tags, file, i + 1, text, mm[1], "n", "methodSpec", { scopeKind: "interface", scope: `${pkg}.${m[1]}`, typeref: `typename:${mm[2] || ""}` });
    } else if ((m = s.match(/^type\s+([A-Za-z_]\w*)\b/))) add(tags, file, i + 1, text, m[1], "t", "type", { scopeKind: "package", scope: pkg });
    if ((m = s.match(/^var\s+([A-Za-z_]\w*)\s*([A-Za-z_]\w*)?/))) add(tags, file, i + 1, text, m[1], "v", "var", { scopeKind: "package", scope: pkg, typeref: m[2] ? `typename:${m[2]}` : undefined });
    if ((m = s.match(/^const\s+([A-Za-z_]\w*)/))) add(tags, file, i + 1, text, m[1], "c", "const", { scopeKind: "package", scope: pkg });
  }
  return tags;
}

function parseRust(lines: string[], file: string): Tag[] {
  const tags: Tag[] = [];
  for (let i = 0; i < lines.length; i++) {
    const text = lines[i], s = text.trim().replace(/^pub(?:\([^)]*\))?\s+/, ""); let m;
    if ((m = s.match(/^fn\s+([A-Za-z_]\w*)\s*[<(]/))) add(tags, file, i + 1, text, m[1], "f", "function");
    if ((m = s.match(/^struct\s+([A-Za-z_]\w*)/))) add(tags, file, i + 1, text, m[1], "s", "struct");
    if ((m = s.match(/^enum\s+([A-Za-z_]\w*).*?\{(.*)\}/))) {
      add(tags, file, i + 1, text, m[1], "g", "enum");
      for (const em of m[2].matchAll(/\b([A-Za-z_]\w*)\b/g)) add(tags, file, i + 1, text, em[1], "e", "enumerator", { scopeKind: "enum", scope: m[1] });
    }
    if ((m = s.match(/^trait\s+([A-Za-z_]\w*)/))) add(tags, file, i + 1, text, m[1], "i", "interface");
    if ((m = s.match(/^mod\s+([A-Za-z_]\w*)/))) add(tags, file, i + 1, text, m[1], "n", "module");
    if ((m = s.match(/^const\s+([A-Za-z_]\w*)/))) add(tags, file, i + 1, text, m[1], "C", "constant");
    if ((m = s.match(/^type\s+([A-Za-z_]\w*)/))) add(tags, file, i + 1, text, m[1], "t", "typedef");
    if ((m = s.match(/^struct\s+([A-Za-z_]\w*).*?\{(.*)\}/))) for (const fm of m[2].matchAll(/\b([A-Za-z_]\w*)\s*:/g)) add(tags, file, i + 1, text, fm[1], "m", "field", { scopeKind: "struct", scope: m[1] });
    if ((m = s.match(/^trait\s+([A-Za-z_]\w*).*?\{\s*fn\s+([A-Za-z_]\w*)/))) add(tags, file, i + 1, text, m[2], "P", "method", { scopeKind: "interface", scope: m[1] });
  }
  return tags;
}

function parseJava(lines: string[], file: string): Tag[] {
  const tags: Tag[] = [];
  let currentClass = "", currentEnum = "";
  for (let i = 0; i < lines.length; i++) {
    const text = lines[i], s = text.trim(); let m;
    if ((m = s.match(/^package\s+([\w.]+)\s*;/))) add(tags, file, i + 1, text, m[1], "p", "package");
    if ((m = s.match(/\b(class|interface|enum)\s+([A-Za-z_]\w*)/))) {
      add(tags, file, i + 1, text, m[2], m[1] === "class" ? "c" : m[1] === "enum" ? "g" : "i", m[1] === "enum" ? "enum" : m[1]);
      if (m[1] === "class") currentClass = m[2];
      if (m[1] === "enum") {
        currentEnum = m[2];
        const body = s.replace(/^.*?\{/, "").replace(/\}.*$/, "");
        for (const em of body.matchAll(/\b([A-Z][A-Z0-9_]*)\b/g)) add(tags, file, i + 1, text, em[1], "e", "enumConstant", { scopeKind: "enum", scope: currentEnum, fileScope: true });
      }
    }
    if ((m = s.match(/(public|private|protected)?(?:\s+static|\s+final|\s+synchronized|\s)*\s+[\w<>\[\]]+\s+([A-Za-z_]\w*)\s*\([^;]*\)\s*(?:\{|throws|$)/))) add(tags, file, i + 1, text, m[2], "m", "method", currentClass ? { scopeKind: "class", scope: currentClass, fileScope: m[1] === "private" } : {});
    else if ((m = s.match(/(public|private|protected)?(?:\s+static|\s+final)*\s+[\w<>\[\]]+\s+([A-Za-z_]\w*)\s*(?:=|;)/))) add(tags, file, i + 1, text, m[2], "f", "field", currentClass ? { scopeKind: "class", scope: currentClass, fileScope: m[1] !== "public" } : {});
  }
  return tags;
}

function parseRuby(lines: string[], file: string): Tag[] {
  const tags: Tag[] = [], scopes: any[] = [];
  for (let i = 0; i < lines.length; i++) {
    const text = lines[i], s = text.trim(); let m;
    if ((m = s.match(/^class\s+([A-Z]\w*(?:::\w+)*)/))) { add(tags, file, i + 1, text, m[1].split("::").pop(), "c", "class"); scopes.push(m[1]); }
    else if ((m = s.match(/^module\s+([A-Z]\w*(?:::\w+)*)/))) { add(tags, file, i + 1, text, m[1].split("::").pop(), "m", "module"); scopes.push(m[1]); }
    else if ((m = s.match(/^def\s+(?:self\.)?([A-Za-z_]\w*[!?=]?)/))) add(tags, file, i + 1, text, m[1], s.startsWith("def self.") ? "F" : "f", s.startsWith("def self.") ? "singletonMethod" : "method", scopes.length ? { scopeKind: "class", scope: scopes[scopes.length - 1] } : {});
    else if (s === "end") scopes.pop();
  }
  return tags;
}

function parseSh(lines: string[], file: string): Tag[] {
  const tags: Tag[] = [];
  for (let i = 0; i < lines.length; i++) {
    const text = lines[i], s = text.trim(); let m;
    if ((m = s.match(/^(?:function\s+)?([A-Za-z_]\w*)\s*\(\)\s*\{/)) || (m = s.match(/^function\s+([A-Za-z_]\w*)/))) add(tags, file, i + 1, text, m[1], "f", "function");
    else if ((m = s.match(/^([A-Za-z_]\w*)=/))) add(tags, file, i + 1, text, m[1], "v", "variable");
  }
  return tags;
}

function parseMake(lines: string[], file: string): Tag[] {
  const tags: Tag[] = [];
  for (let i = 0; i < lines.length; i++) {
    const text = lines[i]; let m;
    if ((m = text.match(/^([A-Za-z0-9_.-]+)\s*[:+?]?=/))) add(tags, file, i + 1, text, m[1], "m", "macro");
    else if ((m = text.match(/^([A-Za-z0-9_.\/-]+)\s*:(?![=])/))) add(tags, file, i + 1, text, m[1], "t", "target");
  }
  return tags;
}

function parsePHP(lines: string[], file: string): Tag[] {
  const tags: Tag[] = [];
  for (let i = 0; i < lines.length; i++) {
    const text = lines[i], s = text.trim(); let m;
    if ((m = s.match(/^(?:abstract\s+|final\s+)?class\s+([A-Za-z_]\w*)/))) add(tags, file, i + 1, text, m[1], "c", "class");
    if ((m = s.match(/^interface\s+([A-Za-z_]\w*)/))) add(tags, file, i + 1, text, m[1], "i", "interface");
    if ((m = s.match(/^function\s+([A-Za-z_]\w*)\s*\(/))) add(tags, file, i + 1, text, m[1], "f", "function");
    if ((m = s.match(/^\$([A-Za-z_]\w*)\s*=/))) add(tags, file, i + 1, text, m[1], "v", "variable");
  }
  return tags;
}

function parseGeneric(lines: string[], file: string): Tag[] {
  const tags: Tag[] = [];
  for (let i = 0; i < lines.length; i++) {
    const text = lines[i], s = text.trim(); let m;
    if ((m = s.match(/^(?:function|def|sub|proc)\s+([A-Za-z_]\w*)/i))) add(tags, file, i + 1, text, m[1], "f", "function");
    else if ((m = s.match(/^(?:class|struct|interface)\s+([A-Za-z_]\w*)/i))) add(tags, file, i + 1, text, m[1], "c", "class");
  }
  return tags;
}

function kindName(t: Tag): string { return t.kind || t.letter; }

function formatTag(t: Tag): string {
  const fields: string[] = [];
  if (t.scope && t.scopeKind) fields.push(`${t.scopeKind}:${t.scope}`);
  if (t.typeref) fields.push(`typeref:${t.typeref}`);
  if (t.fileScope) fields.push("file:");
  const end = t.patternText && t.patternComplete === false ? "" : "$";
  return `${t.name}\t${t.file}\t/^${escPattern(t.patternText || t.text)}${end}/;"\t${t.letter}${fields.length ? "\t" + fields.join("\t") : ""}`;
}

function formatJson(t: Tag): string {
  const end = t.patternText && t.patternComplete === false ? "" : "$";
  const o: any = { _type: "tag", name: t.name, path: t.file, pattern: `/^${escPattern(t.patternText || t.text)}${end}/` };
  if (t.fileScope) o.file = true;
  if (t.typeref) o.typeref = t.typeref;
  o.kind = kindName(t);
  if (t.scope) { o.scope = t.scope; o.scopeKind = t.scopeKind; }
  return "{" + Object.entries(o).map(([k, v]) => `${JSON.stringify(k)}: ${JSON.stringify(v)}`).join(", ") + "}";
}

function formatXref(t: Tag): string {
  return `${t.name.padEnd(16)} ${kindName(t).padEnd(12)} ${String(t.line).padStart(4)} ${t.file.padEnd(16)} ${t.text.trim()}`;
}

function pseudoHeader(sort: string): string[] {
  return [
    "!_TAG_EXTRA_DESCRIPTION\tanonymous\t/Include tags for non-named objects like lambda/",
    "!_TAG_EXTRA_DESCRIPTION\tfileScope\t/Include tags of file scope/",
    "!_TAG_EXTRA_DESCRIPTION\tpseudo\t/Include pseudo tags/",
    "!_TAG_FIELD_DESCRIPTION\tfile\t/File-restricted scoping/",
    "!_TAG_FIELD_DESCRIPTION\tpattern\t/pattern/",
    "!_TAG_FIELD_DESCRIPTION\ttyperef\t/Type and name of a variable or typedef/",
    "!_TAG_FILE_FORMAT\t2\t/extended format; --format=1 will not append ;\" to lines/",
    `!_TAG_FILE_SORTED\t${sort === "foldcase" ? 2 : sort === "no" ? 0 : 1}\t/0=unsorted, 1=sorted, 2=foldcase/`,
    "!_TAG_OUTPUT_MODE\tu-ctags\t/u-ctags or e-ctags/",
    "!_TAG_OUTPUT_VERSION\t1.1\t/current.age/",
    `!_TAG_PROC_CWD\t${process.cwd().replace(/\\/g, "/")}/\t//`,
    "!_TAG_PROGRAM_AUTHOR\tUniversal Ctags Team\t//",
    "!_TAG_PROGRAM_NAME\tUniversal Ctags\t/Derived from Exuberant Ctags/",
    "!_TAG_PROGRAM_URL\thttps://ctags.io/\t/official site/",
    "!_TAG_PROGRAM_VERSION\t6.2.0\t/d922013/",
  ];
}

function sortTags(tags: Tag[], mode: string): Tag[] {
  if (mode === "no") return tags;
  return tags.slice().sort((a, b) => {
    const an = mode === "foldcase" ? a.name.toLowerCase() : a.name;
    const bn = mode === "foldcase" ? b.name.toLowerCase() : b.name;
    if (an !== bn) return an < bn ? -1 : 1;
    if (a.file !== b.file) return a.file < b.file ? -1 : 1;
    return a.line - b.line;
  });
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  if (opt.help) return console.log(usage());
  if (opt.version) return console.log(VERSION);
  if (opt.license) return console.log(VERSION + "\n\nThis program is free software; you can redistribute it and/or\nmodify it under the terms of the GNU General Public License\nas published by the Free Software Foundation; either version 2of the License, or (at your option) any later version.\n\nThis program is distributed in the hope that it will be useful,\nbut WITHOUT ANY WARRANTY; without even the implied warranty of\nMERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\nGNU General Public License for more details.");
  if (opt.listLanguages) return console.log(LANGS.join("\n"));
  if (opt.listFeatures) return console.log("#NAME             DESCRIPTION\niconv             can convert input/output encodings\ninteractive       accepts source code from stdin\njson              supports json format output\noption-directory  TO BE WRITTEN\noptscript         can use the interpreter\npackcc            has peg based parser(s)\nregex             can use regular expression based pattern matching\nsandbox           linked with code for system call level sandbox\nwildcards         can use glob matching\nxpath             linked with library for parsing xml input\nyaml              linked with library for parsing yaml input");
  if (opt.listFormats) return console.log("#OFORMAT DEFAULT AVAILABLE NULLTAG \ne-ctags       no       yes      no \netags         no       yes      no \njson          no       yes     yes \nu-ctags      yes       yes      no \nxref          no       yes     yes ");
  if (opt.listKinds) {
    const l = canonicalLang(opt.listKinds);
    const ks = kindNames[l] || kindNames.C;
    return console.log(Object.entries(ks).map(([k, v]) => `${k}  ${v}${["l","p","z"].includes(k) ? " [off]" : ""}`).join("\n"));
  }
  if (opt.listFields) return console.log("f  file\nk  kind\ns  scope\nt  typeref\nn  line");
  if (opt.listExtras) return console.log("F  fileScope\nf  inputFile\np  pseudo\nq  qualified");

  let inputs = opt.files.slice();
  if (opt.listFile) {
    const data = opt.listFile === "-" ? readStdin() : fs.readFileSync(opt.listFile, "utf8");
    inputs.push(...data.split(/\r?\n/).filter(Boolean));
  }
  if (opt.filter) inputs = readStdin().split(/\r?\n/).filter(Boolean);
  if (!inputs.length) inputs = [];
  const files = collectFiles(inputs, opt);
  if (opt.printLanguage) {
    for (const f of files) console.log(`${f}: ${opt.langForce && opt.langForce !== "auto" ? opt.langForce : detectLang(f)}`);
    return;
  }

  let tags: Tag[] = [];
  for (const f of files) {
    const lang = opt.langForce && opt.langForce !== "auto" ? opt.langForce : detectLang(f);
    if (opt.languages && !opt.languages.map(canonicalLang).includes(lang)) continue;
    if (opt.verbose) console.error(`OPENING ${f} as ${lang} language file`);
    let fileTags = parseFile(f, lang);
    const kf = opt.kindFilters && (opt.kindFilters[lang] || opt.kindFilters.all || opt.kindFilters.All);
    if (kf) {
      const spec = kf.replace(/\*/g, Object.keys(kindNames[lang] || {}).join(""));
      if (spec.startsWith("-")) fileTags = fileTags.filter(t => !spec.slice(1).includes(t.letter));
      else if (spec.startsWith("+")) fileTags = fileTags;
      else fileTags = fileTags.filter(t => spec.includes(t.letter));
    }
    tags.push(...fileTags);
    if (opt.filter && opt.filterTerminator) process.stdout.write(sortTags(tags, opt.sort).map(formatTag).join("\n") + "\n" + opt.filterTerminator + "\n"), tags = [];
  }
  tags = sortTags(tags, opt.sort);
  let lines: string[] = [];
  if (opt.format === "json") lines = tags.map(formatJson);
  else if (opt.format === "xref") lines = tags.map(formatXref);
  else if (opt.format === "etags") lines = tags.map(t => `${t.file},${t.line}\n${t.text}\x7f${t.name}\x01${t.line},0`);
  else {
    if (opt.output !== "-") lines.push(...pseudoHeader(opt.sort));
    lines.push(...tags.map(formatTag));
  }
  const out = lines.length ? lines.join("\n") + "\n" : "";
  if (opt.output === "-") process.stdout.write(out);
  else if (opt.append) fs.appendFileSync(opt.output, out);
  else fs.writeFileSync(opt.output, out);
  if (opt.totals) console.error(`${files.length} files, ${tags.length} tags`);
}

main();
