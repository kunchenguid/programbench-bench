declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");

type FileTime = "a" | "c" | "m";

interface Options {
  depth?: number;
  lines?: number;
  fullPaths: boolean;
  apparent: boolean;
  reverse: boolean;
  noBars: boolean;
  barsRight: boolean;
  screenReader: boolean;
  skipTotal: boolean;
  filecount: boolean;
  ignoreHidden: boolean;
  onlyDir: boolean;
  onlyFile: boolean;
  fileTypes: boolean;
  outputJson: boolean;
  printErrors: boolean;
  dereference: boolean;
  minSize: number;
  outputFormat?: string;
  filter?: RegExp;
  invertFilters: RegExp[];
  ignoreDirs: string[];
  collapse: string[];
  filetime?: FileTime;
  configFile?: string;
  timeFilters: { kind: FileTime; spec: string }[];
  paths: string[];
  filesFrom?: string;
  files0From?: string;
}

interface NodeInfo {
  name: string;
  fullPath: string;
  isDir: boolean;
  isSymlink: boolean;
  ownSize: number;
  size: number;
  count: number;
  time: number;
  children: NodeInfo[];
  depth: number;
}

const HELP_LONG = `Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...
          Input files or directories

Options:
  -d, --depth <DEPTH>
          Depth to show

  -T, --threads <THREADS>
          Number of threads to use

      --config <FILE>
          Specify a config file to use

  -n, --number-of-lines <NUMBER>
          Number of lines of output to show. (Default is terminal_height - 10)

  -p, --full-paths
          Subdirectories will not have their path shortened

  -X, --ignore-directory <PATH>
          Exclude any file or directory with this path

  -I, --ignore-all-in-file <FILE>
          Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter

  -L, --dereference-links
          dereference sym links - Treat sym links as directories and go into them

  -x, --limit-filesystem
          Only count the files and directories on the same filesystem as the supplied directory

  -s, --apparent-size
          Use file length instead of blocks

  -r, --reverse
          Print tree upside down (biggest highest)

  -c, --no-colors
          No colors will be printed (Useful for commands like: watch)

  -C, --force-colors
          Force colors print

  -b, --no-percent-bars
          No percent bars or percentages will be displayed

  -B, --bars-on-right
          percent bars moved to right side of screen

  -z, --min-size <MIN_SIZE>
          Minimum size file to include in output

  -R, --screen-reader
          For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)

      --skip-total
          No total row will be displayed

  -f, --filecount
          Directory 'size' is number of child files instead of disk size

  -i, --ignore-hidden
          Do not display hidden files

  -v, --invert-filter <REGEX>
          Exclude filepaths matching this regex. To ignore png files type: -v "\\.png$"

  -e, --filter <REGEX>
          Only include filepaths matching this regex. For png files type: -e "\\.png$"

  -t, --file-types
          show only these file types

  -w, --terminal-width <WIDTH>
          Specify width of output overriding the auto detection of terminal width

  -P, --no-progress
          Disable the progress indication

      --print-errors
          Print path with errors

  -D, --only-dir
          Only directories will be displayed

  -F, --only-file
          Only files will be displayed. (Finds your largest files)

  -o, --output-format <FORMAT>
          Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size

          Possible values:
          - si: SI prefix (powers of 1000)
          - b:  byte (B)
          - k:  kibibyte (KiB)
          - m:  mebibyte (MiB)
          - g:  gibibyte (GiB)
          - t:  tebibyte (TiB)
          - kb: kilobyte (kB)
          - mb: megabyte (MB)
          - gb: gigabyte (GB)
          - tb: terabyte (TB)

  -S, --stack-size <STACK_SIZE>
          Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)

  -j, --output-json
          Output the directory tree as json to the current directory

  -M, --mtime <MTIME>
          +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (−∞, curr−(n+1)), n => [curr−(n+1), curr−n), and -n => (𝑐𝑢𝑟𝑟−𝑛, +∞)

  -A, --atime <ATIME>
          just like -mtime, but based on file access time

  -y, --ctime <CTIME>
          just like -mtime, but based on file change time

      --files0-from <FILES0_FROM>
          Read NUL-terminated paths from FILE (use \`-\` for stdin)

      --files-from <FILES_FROM>
          Read newline-terminated paths from FILE (use \`-\` for stdin)

      --collapse <COLLAPSE>
          Keep these directories collapsed

  -m, --filetime <FILETIME>
          Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time

          Possible values:
          - a: last accessed time
          - c: last changed time
          - m: last modified time

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const HELP_SHORT = `Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...  Input files or directories

Options:
  -d, --depth <DEPTH>              Depth to show
  -T, --threads <THREADS>          Number of threads to use
      --config <FILE>              Specify a config file to use
  -n, --number-of-lines <NUMBER>   Number of lines of output to show. (Default is terminal_height - 10)
  -p, --full-paths                 Subdirectories will not have their path shortened
  -X, --ignore-directory <PATH>    Exclude any file or directory with this path
  -I, --ignore-all-in-file <FILE>  Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter
  -L, --dereference-links          dereference sym links - Treat sym links as directories and go into them
  -x, --limit-filesystem           Only count the files and directories on the same filesystem as the supplied directory
  -s, --apparent-size              Use file length instead of blocks
  -r, --reverse                    Print tree upside down (biggest highest)
  -c, --no-colors                  No colors will be printed (Useful for commands like: watch)
  -C, --force-colors               Force colors print
  -b, --no-percent-bars            No percent bars or percentages will be displayed
  -B, --bars-on-right              percent bars moved to right side of screen
  -z, --min-size <MIN_SIZE>        Minimum size file to include in output
  -R, --screen-reader              For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)
      --skip-total                 No total row will be displayed
  -f, --filecount                  Directory 'size' is number of child files instead of disk size
  -i, --ignore-hidden              Do not display hidden files
  -v, --invert-filter <REGEX>      Exclude filepaths matching this regex. To ignore png files type: -v "\\.png$"
  -e, --filter <REGEX>             Only include filepaths matching this regex. For png files type: -e "\\.png$"
  -t, --file-types                 show only these file types
  -w, --terminal-width <WIDTH>     Specify width of output overriding the auto detection of terminal width
  -P, --no-progress                Disable the progress indication
      --print-errors               Print path with errors
  -D, --only-dir                   Only directories will be displayed
  -F, --only-file                  Only files will be displayed. (Finds your largest files)
  -o, --output-format <FORMAT>     Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size [possible values: si, b, k, m, g, t, kb, mb, gb, tb]
  -S, --stack-size <STACK_SIZE>    Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)
  -j, --output-json                Output the directory tree as json to the current directory
  -M, --mtime <MTIME>              +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (−∞, curr−(n+1)), n => [curr−(n+1), curr−n), and -n => (𝑐𝑢𝑟𝑟−𝑛, +∞)
  -A, --atime <ATIME>              just like -mtime, but based on file access time
  -y, --ctime <CTIME>              just like -mtime, but based on file change time
      --files0-from <FILES0_FROM>  Read NUL-terminated paths from FILE (use \`-\` for stdin)
      --files-from <FILES_FROM>    Read newline-terminated paths from FILE (use \`-\` for stdin)
      --collapse <COLLAPSE>        Keep these directories collapsed
  -m, --filetime <FILETIME>        Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time [possible values: a, c, m]
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version`;

function defaultOptions(): Options {
  return {
    fullPaths: false,
    apparent: false,
    reverse: false,
    noBars: false,
    barsRight: false,
    screenReader: false,
    skipTotal: false,
    filecount: false,
    ignoreHidden: false,
    onlyDir: false,
    onlyFile: false,
    fileTypes: false,
    outputJson: false,
    printErrors: false,
    dereference: false,
    minSize: 0,
    invertFilters: [],
    ignoreDirs: [],
    collapse: [],
    timeFilters: [],
    paths: []
  };
}

const valueFlags = new Set(["-d", "--depth", "-T", "--threads", "--config", "-n", "--number-of-lines", "-X", "--ignore-directory", "-I", "--ignore-all-in-file", "-z", "--min-size", "-v", "--invert-filter", "-e", "--filter", "-w", "--terminal-width", "-o", "--output-format", "-S", "--stack-size", "-M", "--mtime", "-A", "--atime", "-y", "--ctime", "--files0-from", "--files-from", "--collapse", "-m", "--filetime"]);

function parseArgs(argv: string[]): Options {
  const opts = defaultOptions();
  for (let i = 0; i < argv.length; i++) {
    let arg = argv[i];
    if (arg === "--") {
      opts.paths.push(...argv.slice(i + 1));
      break;
    }
    let value: string | undefined;
    if (arg.startsWith("--") && arg.includes("=")) {
      const parts = arg.split(/=(.*)/s);
      arg = parts[0];
      value = parts[1] ?? "";
    }
    const needValue = () => {
      if (value !== undefined) return value;
      if (i + 1 >= argv.length) die(`error: a value is required for '${arg}' but none was supplied\n\nFor more information, try '--help'.`, 2);
      return argv[++i];
    };
    if (arg === "-h") {
      console.log(HELP_SHORT);
      process.exit(0);
    } else if (arg === "--help") {
      console.log(HELP_LONG);
      process.exit(0);
    } else if (arg === "-V" || arg === "--version") {
      console.log("Dust 1.2.3");
      process.exit(0);
    } else if (valueFlags.has(arg)) {
      const v = needValue();
      switch (arg) {
        case "-d": case "--depth": opts.depth = Number(v); break;
        case "-n": case "--number-of-lines": opts.lines = Number(v); break;
        case "-X": case "--ignore-directory": opts.ignoreDirs.push(v); break;
        case "-I": case "--ignore-all-in-file": loadRegexFile(v, opts); break;
        case "-z": case "--min-size": opts.minSize = parseSize(v); break;
        case "-v": case "--invert-filter": opts.invertFilters.push(new RegExp(v)); break;
        case "-e": case "--filter": opts.filter = new RegExp(v); break;
        case "-o": case "--output-format": opts.outputFormat = v.toLowerCase(); break;
        case "-M": case "--mtime": opts.timeFilters.push({kind: "m", spec: v}); break;
        case "-A": case "--atime": opts.timeFilters.push({kind: "a", spec: v}); break;
        case "-y": case "--ctime": opts.timeFilters.push({kind: "c", spec: v}); break;
        case "--files0-from": opts.files0From = v; break;
        case "--files-from": opts.filesFrom = v; break;
        case "--collapse": opts.collapse.push(v); break;
        case "-m": case "--filetime":
          if (!["a", "c", "m"].includes(v)) die(`error: invalid value '${v}' for '${arg} <FILETIME>'\n  [possible values: a, c, m]\n\nFor more information, try '--help'.`, 2);
          opts.filetime = v as FileTime;
          break;
        case "--config": opts.configFile = v; break;
        default:
          break;
      }
    } else if (arg.startsWith("--")) {
      applyLongFlag(arg, opts);
    } else if (arg.startsWith("-") && arg !== "-") {
      for (let j = 1; j < arg.length; j++) {
        const ch = "-" + arg[j];
        if (valueFlags.has(ch)) {
          const rest = arg.slice(j + 1);
          argv.splice(i + 1, 0, rest || (argv[++i] ?? ""));
          argv[i] = ch;
          i--;
          break;
        }
        applyShortFlag(ch, opts, arg);
      }
    } else {
      opts.paths.push(arg);
    }
  }
  if (opts.paths.length === 0) opts.paths.push(".");
  applyConfig(opts);
  return opts;
}

function applyLongFlag(flag: string, opts: Options) {
  switch (flag) {
    case "--full-paths": opts.fullPaths = true; break;
    case "--dereference-links": opts.dereference = true; break;
    case "--limit-filesystem": break;
    case "--apparent-size": opts.apparent = true; break;
    case "--reverse": opts.reverse = true; break;
    case "--no-colors": break;
    case "--force-colors": break;
    case "--no-percent-bars": opts.noBars = true; break;
    case "--bars-on-right": opts.barsRight = true; break;
    case "--screen-reader": opts.screenReader = true; opts.noBars = true; break;
    case "--skip-total": opts.skipTotal = true; break;
    case "--filecount": opts.filecount = true; break;
    case "--ignore-hidden": opts.ignoreHidden = true; break;
    case "--file-types": opts.fileTypes = true; break;
    case "--no-progress": break;
    case "--print-errors": opts.printErrors = true; break;
    case "--only-dir": opts.onlyDir = true; break;
    case "--only-file": opts.onlyFile = true; break;
    case "--output-json": opts.outputJson = true; break;
    default:
      die(`error: unexpected argument '${flag}' found\n\n  tip: to pass '${flag}' as a value, use '-- ${flag}'\n\nUsage: executable [OPTIONS] [PATH]...\n\nFor more information, try '--help'.`, 2);
  }
}

function applyShortFlag(flag: string, opts: Options, original: string) {
  switch (flag) {
    case "-p": opts.fullPaths = true; break;
    case "-L": opts.dereference = true; break;
    case "-s": opts.apparent = true; break;
    case "-r": opts.reverse = true; break;
    case "-b": opts.noBars = true; break;
    case "-B": opts.barsRight = true; break;
    case "-R": opts.screenReader = true; opts.noBars = true; break;
    case "-f": opts.filecount = true; break;
    case "-i": opts.ignoreHidden = true; break;
    case "-t": opts.fileTypes = true; break;
    case "-D": opts.onlyDir = true; break;
    case "-F": opts.onlyFile = true; break;
    case "-j": opts.outputJson = true; break;
    case "-c": case "-C": case "-P": case "-x": break;
    default:
      die(`error: unexpected argument '${original}' found\n\n  tip: to pass '${original}' as a value, use '-- ${original}'\n\nUsage: executable [OPTIONS] [PATH]...\n\nFor more information, try '--help'.`, 2);
  }
}

function applyConfig(opts: Options) {
  const homes = opts.configFile ? [opts.configFile] : [process.env.HOME ? path.join(process.env.HOME, ".config/dust/config.toml") : "", process.env.HOME ? path.join(process.env.HOME, ".dust.toml") : ""].filter(Boolean);
  for (const file of homes) {
    if (!fs.existsSync(file)) continue;
    try {
      const text = fs.readFileSync(file, "utf8");
      for (const raw of text.split(/\r?\n/)) {
        const line = raw.replace(/#.*/, "").trim();
        const m = line.match(/^([A-Za-z0-9_-]+)\s*=\s*(.+)$/);
        if (!m) continue;
        const key = m[1], val = m[2].trim().replace(/^"|"$/g, "");
        const bool = val === "true";
        if (key === "reverse") opts.reverse = bool;
        if (key === "display-full-paths") opts.fullPaths = bool;
        if (key === "display-apparent-size") opts.apparent = bool;
        if (key === "no-bars") opts.noBars = bool;
        if (key === "skip-total") opts.skipTotal = bool;
        if (key === "ignore-hidden") opts.ignoreHidden = bool;
        if (key === "output-format") opts.outputFormat = val;
        if (key === "number-of-lines") opts.lines = Number(val);
      }
    } catch {}
    break;
  }
}

function loadRegexFile(file: string, opts: Options) {
  try {
    const text = fs.readFileSync(file, "utf8");
    for (const line of text.split(/\r?\n/)) {
      if (line.trim()) opts.invertFilters.push(new RegExp(line.trim()));
    }
  } catch (e: any) {
    console.error(`Failed to read file: ${e.message}`);
  }
}

function readPathList(file: string, nul: boolean): string[] {
  let data: any;
  try {
    data = file === "-" ? fs.readFileSync(0) : fs.readFileSync(file);
  } catch (e: any) {
    console.error(`Failed to read file: ${e.message}`);
    return [];
  }
  const text = data.toString("utf8");
  return text.split(nul ? "\0" : /\r?\n/).map((s: string) => s.trim()).filter(Boolean);
}

function die(msg: string, code: number): never {
  console.error(msg);
  process.exit(code);
  throw new Error(msg);
}

function parseSize(s: string): number {
  const m = String(s).trim().match(/^([0-9]+(?:\.[0-9]+)?)([kmgtp]?i?b?|[KMGTPI]?B?)?$/);
  if (!m) return Number(s) || 0;
  const n = Number(m[1]);
  const u = (m[2] || "").toLowerCase();
  const base = u.includes("i") || ["k", "m", "g", "t"].includes(u) ? 1024 : 1000;
  const pow = u.startsWith("k") ? 1 : u.startsWith("m") ? 2 : u.startsWith("g") ? 3 : u.startsWith("t") ? 4 : u.startsWith("p") ? 5 : 0;
  return Math.floor(n * Math.pow(base, pow));
}

function shouldSkipPath(p: string, name: string, opts: Options, isRoot: boolean): boolean {
  if (!isRoot && opts.ignoreHidden && name.startsWith(".")) return true;
  for (const ign of opts.ignoreDirs) {
    if (name === ign || p === ign || p.endsWith(path.sep + ign)) return true;
  }
  for (const re of opts.invertFilters) {
    if (re.test(p)) return true;
  }
  return false;
}

function statTimeMs(st: any, kind: FileTime): number {
  return kind === "a" ? st.atimeMs : kind === "c" ? st.ctimeMs : st.mtimeMs;
}

function matchesTime(st: any, opts: Options): boolean {
  const day = 24 * 60 * 60 * 1000;
  const now = Date.now();
  for (const tf of opts.timeFilters) {
    const m = tf.spec.match(/^([+-]?)(\d+)$/);
    if (!m) continue;
    const sign = m[1], n = Number(m[2]);
    const age = Math.floor((now - statTimeMs(st, tf.kind)) / day);
    if (sign === "+" && !(age > n)) return false;
    if (sign === "-" && !(age < n)) return false;
    if (sign === "" && !(age === n)) return false;
  }
  return true;
}

function scan(inputPath: string, opts: Options, depth = 0, root = true): NodeInfo | null {
  const full = path.resolve(inputPath);
  let lst: any;
  try {
    lst = fs.lstatSync(full);
  } catch (e: any) {
    console.error(`No such file or directory: ${inputPath}`);
    return null;
  }
  const name = path.basename(full) || full;
  if (shouldSkipPath(full, name, opts, root)) return null;
  let st = lst;
  if (opts.dereference && lst.isSymbolicLink()) {
    try { st = fs.statSync(full); } catch {}
  }
  const isDir = st.isDirectory();
  const isSymlink = lst.isSymbolicLink();
  if (!matchesTime(st, opts)) return null;
  let ownSize = opts.apparent ? Number(st.size || 0) : Number(st.blocks || 0) * 512;
  let count = (isDir || isSymlink) ? 0 : 1;
  let time = opts.filetime ? statTimeMs(st, opts.filetime) : 0;
  if (opts.filter && !isDir && !opts.filter.test(full)) return null;
  if (opts.filter && isDir) ownSize = 0;
  const node: NodeInfo = {name, fullPath: full, isDir, isSymlink, ownSize, size: ownSize, count, time, children: [], depth};
  if (isDir && !opts.collapse.includes(name) && !opts.collapse.includes(full)) {
    let entries: string[] = [];
    try {
      entries = fs.readdirSync(full);
    } catch (e: any) {
      if (opts.printErrors) console.error(`${full}: ${e.message}`);
    }
    for (const ent of entries) {
      const child = scan(path.join(full, ent), opts, depth + 1, false);
      if (!child) continue;
      node.children.push(child);
      node.size += child.size;
      node.count += child.count;
      node.time = Math.max(node.time, child.time);
    }
  }
  if (opts.filter && isDir && node.children.length === 0 && !root) return null;
  if (opts.filecount) node.size = node.count;
  if (opts.filetime) node.size = node.time ? Math.floor(node.time / 1000) : 0;
  if (node.size < opts.minSize && !root) return null;
  node.children.sort(compareDesc);
  return node;
}

function compareDesc(a: NodeInfo, b: NodeInfo) {
  if (b.size !== a.size) return b.size - a.size;
  return b.name < a.name ? -1 : b.name > a.name ? 1 : 0;
}

function displayName(n: NodeInfo, opts: Options): string {
  return opts.fullPaths || opts.outputJson ? n.fullPath : n.name;
}

function formattedValue(n: number, opts: Options): string {
  if (opts.filecount) return String(n);
  if (opts.filetime) return new Date(n * 1000).toISOString().replace("T", " ").slice(0, 19);
  const fmt = opts.outputFormat || "";
  if (fmt === "b") return `${Math.round(n)}B`;
  const units: Record<string, [number, string]> = {
    k: [1024, "K"], m: [1024 ** 2, "M"], g: [1024 ** 3, "G"], t: [1024 ** 4, "T"],
    kb: [1000, "K"], mb: [1000 ** 2, "M"], gb: [1000 ** 3, "G"], tb: [1000 ** 4, "T"]
  };
  if (units[fmt]) {
    const [div, suf] = units[fmt];
    return `${Math.round(n / div)}${suf}`;
  }
  const si = fmt === "si";
  const base = si ? 1000 : 1024;
  const labels = si ? ["B", "K", "M", "G", "T"] : ["B", "K", "M", "G", "T"];
  let v = n, i = 0;
  while (v >= base && i < labels.length - 1) { v /= base; i++; }
  if (i === 0) return `${Math.round(v)}B`;
  return `${v < 10 ? v.toFixed(1) : Math.floor(v).toString()}${labels[i]}`;
}

function collectPost(n: NodeInfo, opts: Options, out: NodeInfo[] = []): NodeInfo[] {
  const maxDepth = opts.depth ?? Infinity;
  if (n.depth < maxDepth) {
    const kids = [...n.children].sort(opts.reverse ? compareDesc : (a, b) => -compareDesc(a, b));
    for (const c of kids) collectPost(c, opts, out);
  }
  if (visibleNode(n, opts) || n.depth === 0) out.push(n);
  return out;
}

function visibleNode(n: NodeInfo, opts: Options): boolean {
  if (opts.onlyFile) return !n.isDir;
  if (opts.onlyDir) return n.isDir || n.isSymlink;
  return true;
}

function collectFiles(n: NodeInfo, out: NodeInfo[] = []): NodeInfo[] {
  if (!n.isDir) out.push(n);
  for (const c of n.children) collectFiles(c, out);
  return out;
}

function renderTree(root: NodeInfo, opts: Options): string {
  let nodes = opts.onlyFile ? [...collectFiles(root).sort((a, b) => a.size - b.size || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0)), root] : collectPost(root, opts).filter(n => visibleNode(n, opts) || n === root);
  if (opts.reverse) nodes = [...nodes].reverse();
  if (opts.lines && opts.lines > 0 && nodes.length > opts.lines) {
    const keepRoot = nodes.includes(root);
    nodes = nodes.slice(Math.max(0, nodes.length - opts.lines));
    if (keepRoot && !nodes.includes(root)) nodes[nodes.length - 1] = root;
  }
  if (opts.skipTotal) nodes = nodes.filter(n => n !== root);
  const total = Math.max(root.size, 1);
  const sizeStrings = nodes.map(n => formattedValue(n.size, opts));
  const width = Math.max(1, ...sizeStrings.map(s => s.length));
  const nameWidth = Math.max(1, ...nodes.map(n => displayName(n, opts).length));
  return nodes.map((n, idx) => {
    const size = sizeStrings[idx].padStart(width);
    const pct = Math.round(n.size * 100 / total);
    const indent = "  ".repeat(opts.onlyFile ? 0 : n.depth);
    const connector = n === root ? "┌─┴ " : (n.isDir ? "├─┴ " : "├── ");
    const nm = (indent + connector + displayName(n, opts)).padEnd(nameWidth + indent.length + 4);
    if (opts.screenReader) return `${size} ${n.depth} ${displayName(n, opts)}`;
    if (opts.noBars) return `${size} ${nm}`;
    const bar = makeBar(pct, Math.max(8, 58 - width - nameWidth - Math.min(n.depth * 2, 16)));
    return `${size} ${nm} │${bar}│ ${String(pct).padStart(3)}%`;
  }).join("\n");
}

function makeBar(pct: number, width: number): string {
  const fill = Math.max(1, Math.min(width, Math.round(width * pct / 100)));
  return "█".repeat(fill).padEnd(width, " ");
}

function renderFileTypes(root: NodeInfo, opts: Options): string {
  const groups = new Map<string, number>();
  for (const f of collectFiles(root)) {
    const ext = path.extname(f.name) || "(no extension)";
    groups.set(ext, (groups.get(ext) || 0) + f.size);
  }
  const children: NodeInfo[] = [...groups.entries()].filter(([name, size]) => size > 0 && name !== "(no extension)").map(([name, size]) => ({name, fullPath: name, isDir: false, isSymlink: false, ownSize: size, size, count: 1, time: 0, children: [], depth: 0})).sort((a, b) => a.size - b.size || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
  const totalSize = children.reduce((a, b) => a + b.size, 0);
  const fakeRoot: NodeInfo = {name: "(total)", fullPath: "(total)", isDir: true, isSymlink: false, ownSize: 0, size: totalSize, count: children.length, time: 0, children, depth: 0};
  return renderTree({ ...fakeRoot, children }, { ...opts, onlyFile: false, onlyDir: false, skipTotal: false });
}

function toJson(n: NodeInfo, opts: Options): any {
  return {
    size: formattedValue(n.size, opts),
    name: n.fullPath,
    children: n.children.sort(compareDesc).map(c => toJson(c, opts))
  };
}

function combineRoots(roots: NodeInfo[], opts: Options): NodeInfo {
  if (roots.length === 1) return roots[0];
  const cwd = path.resolve(".");
  const root: NodeInfo = {name: ".", fullPath: cwd, isDir: true, isSymlink: false, ownSize: 0, size: 0, count: 0, time: 0, children: roots, depth: 0};
  for (const r of roots) {
    r.depth = 1;
    fixDepth(r);
    root.size += r.size;
    root.count += r.count;
    root.time = Math.max(root.time, r.time);
  }
  root.children.sort(compareDesc);
  return root;
}

function fixDepth(n: NodeInfo) {
  for (const c of n.children) {
    c.depth = n.depth + 1;
    fixDepth(c);
  }
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.filesFrom) opts.paths = readPathList(opts.filesFrom, false);
  if (opts.files0From) opts.paths = readPathList(opts.files0From, true);
  if (opts.paths.length === 0) opts.paths = ["."];
  const roots = opts.paths.map(p => scan(p, opts, 0, true)).filter(Boolean) as NodeInfo[];
  if (roots.length === 0) return;
  const root = combineRoots(roots, opts);
  if (opts.outputJson) {
    console.log(JSON.stringify(toJson(root, opts)));
  } else if (opts.fileTypes) {
    console.log(renderFileTypes(root, opts));
  } else {
    console.log(renderTree(root, opts));
  }
}

main();
