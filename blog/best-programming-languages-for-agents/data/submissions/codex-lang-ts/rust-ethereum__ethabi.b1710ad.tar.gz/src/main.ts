declare const process: any;
declare const Buffer: any;
declare function require(name: string): any;
const fs = require("fs");

type AbiType = { base: string; bits?: number; size?: number; array?: number | null; child?: AbiType };

function cleanHex(s: string): string {
  if (s.startsWith("0x") || s.startsWith("0X")) s = s.slice(2);
  if (s.length % 2) throw new Error("Odd number of digits");
  if (!/^[0-9a-fA-F]*$/.test(s)) throw new Error("Invalid character");
  return s.toLowerCase();
}
function zpad(h: string, n = 64) { return h.padStart(n, "0"); }
function rpad(h: string, n: number) { return h.padEnd(n, "0"); }
function word(n: bigint) { let h = n.toString(16); if (h.length > 64) h = h.slice(-64); return zpad(h); }
function bytesToHex(a: number[]) { return a.map(x => x.toString(16).padStart(2, "0")).join(""); }
function hexToBytes(h: string) { h = cleanHex(h); const out: number[] = []; for (let i = 0; i < h.length; i += 2) out.push(parseInt(h.slice(i, i + 2), 16)); return out; }
function utf8Hex(s: string) { return Buffer.from(s, "utf8").toString("hex"); }
function hexUtf8(h: string) { return Buffer.from(h, "hex").toString("utf8"); }

function parseType(s: string): AbiType {
  const m = s.match(/^(.*)\[([0-9]*)\]$/);
  if (m) return { base: "array", array: m[2] === "" ? null : Number(m[2]), child: parseType(m[1]) };
  let x = s.match(/^uint([0-9]*)$/); if (x) return { base: "uint", bits: x[1] ? Number(x[1]) : 256 };
  x = s.match(/^int([0-9]*)$/); if (x) return { base: "int", bits: x[1] ? Number(x[1]) : 256 };
  x = s.match(/^bytes([0-9]+)$/); if (x) return { base: "fixedbytes", size: Number(x[1]) };
  if (["bool", "address", "string", "bytes"].includes(s)) return { base: s };
  throw new Error(`Invalid type: ${s}`);
}
function typeName(t: AbiType): string {
  if (t.base === "array") return typeName(t.child!) + "[" + (t.array == null ? "" : t.array) + "]";
  if (t.base === "uint" || t.base === "int") return t.base + t.bits;
  if (t.base === "fixedbytes") return "bytes" + t.size;
  return t.base;
}
function canonicalType(t: any): string { return t.type; }
function isDynamic(t: AbiType): boolean {
  if (t.base === "string" || t.base === "bytes") return true;
  if (t.base === "array") return t.array == null || isDynamic(t.child!);
  return false;
}
function staticWords(t: AbiType): number {
  if (isDynamic(t)) return 1;
  if (t.base === "array") return (t.array || 0) * staticWords(t.child!);
  return 1;
}
function splitArray(s: string): string[] {
  s = s.trim();
  if (!s.startsWith("[") || !s.endsWith("]")) throw new Error("Invalid data");
  s = s.slice(1, -1).trim();
  if (!s) return [];
  const out: string[] = []; let depth = 0, cur = "";
  for (const ch of s) {
    if (ch === "[" ) depth++;
    if (ch === "]" ) depth--;
    if (ch === "," && depth === 0) { out.push(cur.trim()); cur = ""; } else cur += ch;
  }
  out.push(cur.trim());
  return out;
}
function parseBigParam(s: string, lenient: boolean, signed = false): bigint {
  if (lenient) return BigInt(s);
  const h = cleanHex(s);
  if (h.length !== 64) throw new Error("Invalid data");
  let v = BigInt("0x" + h);
  if (signed && v >= (1n << 255n)) v -= 1n << 256n;
  return v;
}
function encPrimitive(t: AbiType, v: any, lenient: boolean): string {
  switch (t.base) {
    case "bool":
      if (v === "true") v = "1"; if (v === "false") v = "0";
      return word(BigInt(v) !== 0n ? 1n : 0n);
    case "uint": {
      const n = parseBigParam(String(v), lenient, false);
      if (n < 0n) throw new Error("Invalid data");
      return word(n);
    }
    case "int": {
      let n = parseBigParam(String(v), lenient, true);
      if (n < 0n) n = (1n << 256n) + n;
      return word(n);
    }
    case "address": {
      const h = cleanHex(String(v));
      if (h.length !== 40) throw new Error("Invalid data");
      return zpad(h);
    }
    case "fixedbytes": {
      const h = cleanHex(String(v));
      if (h.length !== (t.size! * 2)) throw new Error("Invalid data");
      return rpad(h, 64);
    }
  }
  throw new Error("Invalid data");
}
function encDynamicData(t: AbiType, v: any, lenient: boolean): string {
  if (t.base === "string") {
    const h = utf8Hex(String(v)); return word(BigInt(h.length / 2)) + rpad(h, Math.ceil(h.length / 64) * 64);
  }
  if (t.base === "bytes") {
    const h = cleanHex(String(v)); return word(BigInt(h.length / 2)) + rpad(h, Math.ceil(h.length / 64) * 64);
  }
  if (t.base === "array") {
    const vals = Array.isArray(v) ? v : splitArray(String(v));
    if (t.array != null && vals.length !== t.array) throw new Error("Invalid data");
    const body = encodeTuple(vals, vals.map(() => t.child!), lenient);
    return (t.array == null ? word(BigInt(vals.length)) : "") + body;
  }
  return encPrimitive(t, v, lenient);
}
function encodeTuple(vals: any[], types: AbiType[], lenient: boolean): string {
  if (vals.length !== types.length) throw new Error("Invalid data");
  let head = "", tail = ""; let headBytes = 32 * types.reduce((n, t) => n + staticWords(t), 0);
  for (let i = 0; i < types.length; i++) {
    if (isDynamic(types[i])) {
      const data = encDynamicData(types[i], vals[i], lenient);
      head += word(BigInt(headBytes + tail.length / 2));
      tail += data;
    } else head += types[i].base === "array" ? encDynamicData(types[i], vals[i], lenient) : encPrimitive(types[i], vals[i], lenient);
  }
  return head + tail;
}
function readWord(data: string, off: number): string {
  const w = data.slice(off * 2, off * 2 + 64);
  if (w.length !== 64) throw new Error("Invalid data");
  return w;
}
function toNum(w: string) { return Number(BigInt("0x" + w)); }
function decPayload(t: AbiType, data: string, p: number): any {
  if (t.base === "string") { const n = toNum(readWord(data, p)); return hexUtf8(data.slice((p + 32) * 2, (p + 32 + n) * 2)); }
  if (t.base === "bytes") { const n = toNum(readWord(data, p)); return data.slice((p + 32) * 2, (p + 32 + n) * 2); }
  if (t.base === "array") {
    let len = t.array!, start = p;
    if (t.array == null) { len = toNum(readWord(data, p)); start = p + 32; }
    const vals: any[] = [];
    for (let i = 0; i < len; i++) {
      if (isDynamic(t.child!)) vals.push(decPayload(t.child!, data, start + toNum(readWord(data, start + i * 32))));
      else vals.push(decAt(t.child!, data, start + i * 32));
    }
    return vals;
  }
  return decAt(t, data, p);
}
function decAt(t: AbiType, data: string, off: number): any {
  const w = readWord(data, off);
  switch (t.base) {
    case "bool": return BigInt("0x" + w) !== 0n;
    case "uint": return BigInt("0x" + w).toString(16);
    case "int": { let v = BigInt("0x" + w); if (v >= (1n << 255n)) v -= 1n << 256n; return v < 0 ? w : v.toString(16); }
    case "address": return w.slice(24);
    case "fixedbytes": return w.slice(0, t.size! * 2);
    case "string": return decPayload(t, data, toNum(w));
    case "bytes": return decPayload(t, data, toNum(w));
    case "array": return isDynamic(t) ? decPayload(t, data, toNum(w)) : decPayload(t, data, off);
  }
}
function decodeTuple(types: AbiType[], hex: string): any[] {
  const data = cleanHex(hex);
  const out: any[] = []; let off = 0;
  for (const t of types) { out.push(decAt(t, data, off)); off += staticWords(t) * 32; }
  return out;
}
function fmtVal(v: any): string {
  if (Array.isArray(v)) return "[" + v.map(fmtVal).join(",") + "]";
  if (typeof v === "boolean") return v ? "true" : "false";
  return String(v);
}

const R = [1,3,6,10,15,21,28,36,45,55,2,14,27,41,56,8,25,43,62,18,39,61,20,44];
const RC = [1n,32898n,9223372036854808714n,9223372039002292224n,32907n,2147483649n,9223372039002292353n,9223372036854808585n,138n,136n,2147516425n,2147483658n,2147516555n,9223372036854775947n,9223372036854808713n,9223372036854808579n,9223372036854808578n,9223372036854775936n,32778n,9223372039002259466n,9223372039002292353n,9223372036854808704n,2147483649n,9223372039002292232n];
function rot(x: bigint, n: number) { return ((x << BigInt(n)) | (x >> BigInt(64 - n))) & ((1n << 64n) - 1n); }
function keccak256(msg: string): string {
  const bytes = Array.from(Buffer.from(msg, "utf8")) as number[]; const rate = 136; bytes.push(1);
  while ((bytes.length % rate) !== rate - 1) bytes.push(0); bytes.push(0x80);
  const st = new Array<bigint>(25).fill(0n);
  for (let b = 0; b < bytes.length; b += rate) {
    for (let i = 0; i < rate / 8; i++) {
      let v = 0n; for (let j = 0; j < 8; j++) v |= BigInt(bytes[b + i * 8 + j]) << BigInt(8 * j);
      st[i] ^= v;
    }
    for (let round = 0; round < 24; round++) {
      const C = [0n,0n,0n,0n,0n], D = [0n,0n,0n,0n,0n];
      for (let x = 0; x < 5; x++) C[x] = st[x] ^ st[x+5] ^ st[x+10] ^ st[x+15] ^ st[x+20];
      for (let x = 0; x < 5; x++) D[x] = C[(x+4)%5] ^ rot(C[(x+1)%5], 1);
      for (let x = 0; x < 5; x++) for (let y = 0; y < 5; y++) st[x+5*y] ^= D[x];
      let x = 1, y = 0, cur = st[1];
      for (let i = 0; i < 24; i++) { const nx = y, ny = (2*x + 3*y) % 5; const idx = nx + 5*ny; const tmp = st[idx]; st[idx] = rot(cur, R[i]); cur = tmp; x = nx; y = ny; }
      for (let y0 = 0; y0 < 5; y0++) {
        const row = [0n,0n,0n,0n,0n]; for (let x0 = 0; x0 < 5; x0++) row[x0] = st[x0+5*y0];
        for (let x0 = 0; x0 < 5; x0++) st[x0+5*y0] = row[x0] ^ ((~row[(x0+1)%5]) & row[(x0+2)%5]);
      }
      st[0] ^= RC[round];
    }
  }
  const out: number[] = [];
  for (let i = 0; out.length < 32; i++) for (let j = 0; j < 8 && out.length < 32; j++) out.push(Number((st[i] >> BigInt(8*j)) & 255n));
  return bytesToHex(out);
}

function loadAbi(path: string) { return JSON.parse(fs.readFileSync(path, "utf8")); }
function sig(item: any) { return item.name + "(" + (item.inputs || []).map(canonicalType).join(",") + ")"; }
function findItem(abi: any[], kind: string, name: string) {
  const items = abi.filter(x => x.type === kind);
  if (name.includes("(")) {
    const m = items.find(x => sig(x) === name);
    if (!m) throw new Error(`invalid ${kind} signature \`${name}\``);
    return m;
  }
  const m = items.filter(x => x.name === name);
  if (m.length > 1) throw new Error(`More than one ${kind} found for name \`${name}\`, try providing the full signature`);
  if (!m.length) throw new Error(`${kind} not found`);
  return m[0];
}
function help() {
  console.log("ethabi-cli 18.0.0\nEthereum ABI coder\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nSUBCOMMANDS:\n    decode    Decode ABI call result\n    encode    Encode ABI call\n    help      Prints this message or the help of the given subcommand(s)");
}
function subHelp(a: string[]) {
  const p = a.slice(0, 2).join(" ");
  if (p === "encode params") return console.log("executable-encode-params 18.0.0\nSpecify types of input params inline\n\nUSAGE:\n    executable encode params [FLAGS] [OPTIONS]\n\nFLAGS:\n    -h, --help       Prints help information\n    -l, --lenient    Allow short representation of input params (numbers are in decimal form)\n    -V, --version    Prints version information\n\nOPTIONS:\n    -v <type-or-param> <type-or-param>");
  if (p === "encode function") return console.log("executable-encode-function 18.0.0\nLoad function from JSON ABI file\n\nUSAGE:\n    executable encode function [FLAGS] [OPTIONS] <abi-path> <function-name-or-signature>\n\nFLAGS:\n    -h, --help       Prints help information\n    -l, --lenient    Allow short representation of input params\n    -V, --version    Prints version information\n\nOPTIONS:\n    -p <params>...");
  if (p === "decode params") return console.log("executable-decode-params 18.0.0\nSpecify types of input params inline\n\nUSAGE:\n    executable decode params [OPTIONS] <data>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -t <type>...");
  if (p === "decode function") return console.log("executable-decode-function 18.0.0\nLoad function from JSON ABI file\n\nUSAGE:\n    executable decode function <abi-path> <function-name-or-signature> <data>");
  if (p === "decode log") return console.log("executable-decode-log 18.0.0\nDecode event log\n\nUSAGE:\n    executable decode log [OPTIONS] <abi-path> <event-name-or-signature> <data>\n\nOPTIONS:\n    -l <topic>...");
  if (a[0] === "encode") return console.log("executable-encode 18.0.0\nEncode ABI call\n\nUSAGE:\n    executable encode <SUBCOMMAND>\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    params      Specify types of input params inline");
  if (a[0] === "decode") return console.log("executable-decode 18.0.0\nDecode ABI call result\n\nUSAGE:\n    executable decode <SUBCOMMAND>\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    log         Decode event log\n    params      Specify types of input params inline");
  help();
}
function parseOpts(args: string[]) {
  const vals: string[] = [], types: string[] = [], topics: string[] = []; let lenient = false, rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-l" || args[i] === "--lenient") {
      if (i + 1 < args.length && !args[i+1].startsWith("-") && args[i] === "-l") topics.push(args[++i]); else lenient = true;
    } else if (args[i] === "-v") { types.push(args[++i]); vals.push(args[++i]); }
    else if (args[i] === "-t") types.push(args[++i]);
    else if (args[i] === "-p") vals.push(args[++i]);
    else rest.push(args[i]);
  }
  return { vals, types, topics, lenient, rest };
}
function main() {
  const a = process.argv.slice(2);
  try {
    if (!a.length || a[0] === "--help" || a[0] === "-h" || a[0] === "help") return help();
    if (a.includes("--help") || a.includes("-h")) return subHelp(a);
    if (a[0] === "--version" || a[0] === "-V") return console.log("ethabi-cli 18.0.0");
    if (a[0] === "encode" && a[1] === "params") {
      const o = parseOpts(a.slice(2)); return console.log(encodeTuple(o.vals, o.types.map(parseType), o.lenient));
    }
    if (a[0] === "decode" && a[1] === "params") {
      const o = parseOpts(a.slice(2)); const data = o.rest[o.rest.length - 1]; const ts = o.types.map(parseType);
      decodeTuple(ts, data).forEach((v, i) => console.log(typeName(ts[i]) + " " + fmtVal(v))); return;
    }
    if (a[0] === "encode" && a[1] === "function") {
      const o = parseOpts(a.slice(2)); const [path, name] = o.rest; const f = findItem(loadAbi(path), "function", name);
      const ts = (f.inputs || []).map((x: any) => parseType(x.type)); return console.log(keccak256(sig(f)).slice(0, 8) + encodeTuple(o.vals, ts, o.lenient));
    }
    if (a[0] === "decode" && a[1] === "function") {
      const [path, name, data] = a.slice(2); const f = findItem(loadAbi(path), "function", name);
      const ts = (f.outputs || []).map((x: any) => parseType(x.type)); decodeTuple(ts, data).forEach((v, i) => console.log(typeName(ts[i]) + " " + fmtVal(v))); return;
    }
    if (a[0] === "decode" && a[1] === "log") {
      const o = parseOpts(a.slice(2)); const [path, name, data] = o.rest; const e = findItem(loadAbi(path), "event", name);
      const outs: string[] = []; let ti = 0; const nonTypes: AbiType[] = [];
      for (const inp of e.inputs || []) {
        const t = parseType(inp.type);
        if (inp.indexed) { const h = o.topics[ti++]; outs.push(typeName(t) + " " + (isDynamic(t) ? cleanHex(h) : fmtVal(decAt(t, cleanHex(h), 0)))); }
        else nonTypes.push(t);
      }
      const vals = decodeTuple(nonTypes, data); let vi = 0;
      for (const inp of e.inputs || []) if (!inp.indexed) { const t = parseType(inp.type); outs.push(typeName(t) + " " + fmtVal(vals[vi++])); }
      outs.forEach(x => console.log(x)); return;
    }
    help();
  } catch (e: any) {
    console.error("Error: " + (e && e.message ? e.message : String(e)));
    process.exit(1);
  }
}
main();
