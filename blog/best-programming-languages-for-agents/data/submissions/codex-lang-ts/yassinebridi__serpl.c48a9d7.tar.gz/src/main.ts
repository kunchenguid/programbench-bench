import * as fs from "fs";
import * as path from "path";
import * as os from "os";

const HELP = `A simple terminal UI for search and replace, ala VS Code

Usage: executable [OPTIONS]

Options:
  -p, --project-root <PATH>  Path to the project root [default: .]
  -h, --help                 Print help
  -V, --version              Print version
`;

function version(): string {
  return `serpl 0.3.4- (2026-04-20)

Authors: Yassine Bridi <ybridi@gmail.com>

Config directory: ${os.homedir()}/.config/serpl
`;
}

type Args = { root: string; mode: "run" | "help" | "version" };

function parseArgs(argv: string[]): Args {
  let root = ".";
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") return { root, mode: "help" };
    if (a === "-V" || a === "--version") return { root, mode: "version" };
    if (a === "-p" || a === "--project-root") {
      const next = argv[i + 1];
      if (!next || next.startsWith("-")) {
        console.error(`error: a value is required for '--project-root <PATH>' but none was supplied

For more information, try '--help'.`);
        process.exit(2);
      }
      root = next;
      i++;
      continue;
    }
    if (a.startsWith("-p=")) {
      root = a.slice(3);
      continue;
    }
    if (a.startsWith("--project-root=")) {
      root = a.slice("--project-root=".length);
      continue;
    }
    console.error(`error: unexpected argument '${a}' found

Usage: executable [OPTIONS]

For more information, try '--help'.`);
    process.exit(2);
  }
  return { root, mode: "run" };
}

type Hit = { file: string; lines: number[] };

const RESET = "\x1b[39m\x1b[49m\x1b[59m\x1b[0m";
const WHITE = "\x1b[38;5;15;49m";
const GREEN_BOLD = "\x1b[1m\x1b[38;5;2;49m";
const GREEN = "\x1b[38;5;2;49m";
const BLUE = "\x1b[38;5;4;49m";
const YELLOW = "\x1b[38;5;3;49m";

let projectRoot = ".";
let query = "";
let replaceText = "";
let focus: "search" | "replace" | "results" = "search";
let help = false;
let searchRegex = false;
let replaceRegex = false;
let hits: Hit[] = [];
let status = "Help: <Ctrl-b> | Search: <Enter> | Toggle search mode: <Ctrl-n>";

function isBinary(buf: any): boolean {
  const n = Math.min(buf.length, 1024);
  for (let i = 0; i < n; i++) if (buf[i] === 0) return true;
  return false;
}

function walk(dir: string, out: string[] = []): string[] {
  let entries: any[] = [];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const e of entries) {
    if (e.name === ".git" || e.name === "node_modules" || e.name === "dist" || e.name === "submission.tar.gz") continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (e.isFile()) out.push(p);
  }
  return out;
}

function performSearch() {
  hits = [];
  if (!query) return;
  const root = path.resolve(projectRoot);
  let matcher: (s: string) => boolean;
  try {
    if (searchRegex) {
      const re = new RegExp(query);
      matcher = (s) => re.test(s);
    } else {
      matcher = (s) => s.includes(query);
    }
  } catch (e: any) {
    status = `Invalid regex: ${e.message || e}`;
    return;
  }
  for (const file of walk(root)) {
    let buf: any;
    try {
      buf = fs.readFileSync(file);
    } catch {
      continue;
    }
    if (isBinary(buf)) continue;
    const text = buf.toString("utf8");
    const lines = text.split(/\r?\n/);
    const matched: number[] = [];
    for (let i = 0; i < lines.length; i++) if (matcher(lines[i])) matched.push(i + 1);
    if (matched.length) hits.push({ file: path.relative(root, file) || file, lines: matched });
  }
  status = `Found ${hits.reduce((n, h) => n + h.lines.length, 0)} results in ${hits.length} files`;
}

function replaceAll() {
  if (!query) return;
  const root = path.resolve(projectRoot);
  let changed = 0;
  for (const h of hits) {
    const file = path.join(root, h.file);
    let text = fs.readFileSync(file, "utf8");
    const old = text;
    if (searchRegex) {
      try {
        text = text.replace(new RegExp(query, "g"), replaceText);
      } catch {
        continue;
      }
    } else {
      text = text.split(query).join(replaceText);
    }
    if (text !== old) {
      fs.writeFileSync(file, text);
      changed++;
    }
  }
  performSearch();
  status = `Replaced matches in ${changed} files`;
}

function cell(s: string, width: number): string {
  const clean = s.length > width ? s.slice(0, Math.max(0, width - 1)) : s;
  return clean + " ".repeat(Math.max(0, width - clean.length));
}

function renderBox(x: number, y: number, w: number, h: number, title: string, active: boolean, body: string[]) {
  const c = active ? GREEN_BOLD : WHITE;
  process.stdout.write(`\x1b[${y};${x}H${c}╭${title}${"─".repeat(Math.max(0, w - title.length - 2))}╮${RESET}`);
  for (let r = 1; r < h - 1; r++) {
    process.stdout.write(`\x1b[${y + r};${x}H${c}│${WHITE}${cell(body[r - 1] || "", w - 2)}${c}│${RESET}`);
  }
  process.stdout.write(`\x1b[${y + h - 1};${x}H${c}╰${"─".repeat(w - 2)}╯${RESET}`);
}

function redraw() {
  const cols = process.stdout.columns || 80;
  const rows = process.stdout.rows || 24;
  process.stdout.write("\x1b[?25l\x1b[1;1H");
  if (help) {
    process.stdout.write("\x1b[2J");
    renderMain(cols, rows);
    const left = 1, top = 5, w = Math.min(cols, 80), h = Math.min(15, rows - 5);
    const body = [
      "",
      " - Ctrl-c: Quit",
      " - Ctrl-d: Quit",
      " - Ctrl-b: Help dialog",
      " - Ctrl-o: Process Replace For All Files",
      " - Ctrl-n: Loop through search and replace modes",
      " - Enter: Select/Deselect file",
      " - d: delete file/delete line from the replace process",
      " - r: Replace Selected File Or Line"
    ];
    renderBox(left, top, w, h, " [1] Global ─ [2] Navigation ───────────────Press 'q' to close", false, body);
    process.stdout.write(`\x1b[${rows};1H${BLUE}Close Help: <Esc> | Next Tab: <Right> | Previous Tab: <Left>${RESET}\x1b[?25l`);
    return;
  }
  renderMain(cols, rows);
  const cursorRow = focus === "replace" ? 5 : 2;
  const cursorCol = 2 + (focus === "replace" ? replaceText.length : query.length);
  process.stdout.write(`\x1b[?25h\x1b[${cursorRow};${cursorCol}H`);
}

function renderMain(cols: number, rows: number) {
  const leftW = Math.min(25, Math.max(20, Math.floor(cols * 0.32)));
  const rightW = Math.max(20, cols - leftW);
  const resultH = Math.max(5, rows - 7);
  renderBox(1, 1, leftW, 3, `Search────────[${searchRegex ? "Regex" : "Simple"}]`, focus === "search", [query]);
  renderBox(1, 4, leftW, 3, `Replace───────[${replaceRegex ? "Regex" : "Simple"}]`, focus === "replace", [replaceText]);
  const list = hits.slice(0, Math.max(0, resultH - 2)).map(h => `${h.file}(${h.lines.length})`);
  renderBox(1, 7, leftW, resultH, "Result List───────────", focus === "results", list);
  const preview: string[] = [];
  if (hits[0]) {
    preview.push(hits[0].file);
    try {
      const lines = fs.readFileSync(path.join(path.resolve(projectRoot), hits[0].file), "utf8").split(/\r?\n/);
      for (const ln of hits[0].lines.slice(0, Math.max(1, rows - 5))) {
        preview.push(`${ln}: ${lines[ln - 1] || ""}`);
      }
    } catch {}
  }
  renderBox(leftW + 1, 1, rightW, rows - 1, "Preview───────────────────────────────────────────────", false, preview);
  process.stdout.write(`\x1b[${rows};1H${BLUE}${cell(status, cols)}${RESET}`);
}

function cleanup() {
  if (process.stdout.isTTY) process.stdout.write(`${RESET}\x1b[?1049l\x1b[?25h`);
}

function runTui(root: string) {
  projectRoot = root;
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    console.error("serpl error: Something went wrong");
    console.error("Error: ");
    console.error("   0: \x1b[91mResource temporarily unavailable (os error 11)\x1b[0m");
    process.exit(1);
  }
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.setEncoding("utf8");
  process.stdout.write("\x1b[?1049h");
  redraw();
  const quit = () => { cleanup(); process.exit(0); };
  process.on("SIGINT", quit);
  process.on("exit", cleanup);
  process.stdin.on("data", (key: string) => {
    if (key === "\u0003" || key === "\u0004") quit();
    if (help) {
      if (key === "q" || key === "\u001b" || key === "\u0002") help = false;
      redraw();
      return;
    }
    if (key === "\u0002") help = true;
    else if (key === "\u000f") replaceAll();
    else if (key === "\u000e" || key === "\t") focus = focus === "search" ? "replace" : focus === "replace" ? "results" : "search";
    else if (key === "\r" || key === "\n") performSearch();
    else if (key === "\u007f" || key === "\b") {
      if (focus === "search") query = query.slice(0, -1);
      if (focus === "replace") replaceText = replaceText.slice(0, -1);
    } else if (key.length === 1 && key >= " " && key !== "\u007f") {
      if (focus === "search") query += key;
      else if (focus === "replace") replaceText += key;
    }
    redraw();
  });
}

const args = parseArgs(process.argv.slice(2));
if (args.mode === "help") process.stdout.write(HELP);
else if (args.mode === "version") process.stdout.write(version());
else runTui(args.root);
