declare const process: any;
declare const require: any;
declare const __dirname: string;
declare const Buffer: any;
declare module "fs";
declare module "path";
declare module "os";
