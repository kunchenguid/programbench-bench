declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

type Severity = "error" | "warning" | "style" | "performance" | "portability" | "information";

interface Finding {
  file: string;
  line: number;
  column: number;
  severity: Severity;
  id: string;
  message: string;
  code?: string;
}

interface Options {
  quiet: boolean;
  xml: boolean;
  outputFormat: string;
  template: string;
  outputFile?: string;
  errorExitCode?: number;
  enable: Set<string>;
  suppress: string[];
  inlineSuppr: boolean;
  checkConfig: boolean;
  preprocess: boolean;
  fileFilters: string[];
  ignored: string[];
  paths: string[];
}

const HELP = `Cppcheck - A tool for static C/C++ code analysis

Syntax:
    cppcheck [OPTIONS] [files or paths]

If a directory is given instead of a filename, *.cpp, *.cxx, *.cc, *.c++, *.c, *.ipp,
*.ixx, *.tpp, and *.txx files are checked recursively from the given directory.

Options:
    -h, --help           Print this help.
    --version            Print out version number.
    --enable=<severity>  Enable additional checks. Severities include warning,
                         performance, portability, information, style,
                         unusedFunction, missingInclude, and all.
    --error-exitcode=<n> If errors are found, integer [n] is returned instead of
                         the default '0'.
    --errorlist          Print a list of all the error messages in XML format.
    --output-file=<file> Write results to file, rather than standard error.
    --output-format=<format>
                         Specify the output format: text, sarif, xml, xmlv2, xmlv3.
    --template='<text>'  Format the error messages.
    -q, --quiet          Do not show progress reports.
    --xml                Write results in xml format to error stream (stderr).
    -E                   Print preprocessor output on stdout and don't do any
                         further processing.

Example usage:
  cppcheck .
  cppcheck --quiet ../myproject/
  cppcheck --enable=all --inconclusive --library=posix test.cpp
`;

const ERRORLIST = [
  ["arrayIndexOutOfBounds", "error", "Array 'arr[16]' accessed at index 16, which is out of bounds.", "788"],
  ["nullPointer", "error", "Null pointer dereference.", "476"],
  ["zerodiv", "error", "Division by zero.", "369"],
  ["uninitvar", "error", "Uninitialized variable: var", "457"],
  ["memleak", "error", "Memory leak: var", "401"],
  ["unusedVariable", "style", "Unused variable: var", "563"],
  ["missingInclude", "information", "Include file is not found.", "0"],
  ["syntaxError", "error", "syntax error", "0"],
];

function main(): void {
  const args = process.argv.slice(2);
  if (args.length === 0 || args.includes("--help") || args.includes("-h")) {
    process.stdout.write(HELP);
    process.exit(0);
  }
  if (args.includes("--version")) {
    process.stdout.write("Cppcheck 2.19 dev\n");
    process.exit(0);
  }
  if (args.includes("--errorlist")) {
    process.stdout.write(renderErrorList());
    process.exit(0);
  }

  const parsed = parseArgs(args);
  if (typeof parsed === "string") {
    process.stdout.write(parsed);
    process.exit(1);
  }
  const opts = parsed as Options;

  if (opts.paths.length === 0 && !opts.preprocess) {
    process.stdout.write(HELP);
    process.exit(0);
  }

  const files = collectFiles(opts);
  if (opts.preprocess) {
    for (const file of files) {
      try {
        process.stdout.write(preprocess(file));
      } catch (err: any) {
        process.stdout.write(`cppcheck: error: could not open file '${file}': ${err.message}\n`);
        process.exit(1);
      }
    }
    process.exit(0);
  }

  const findings: Finding[] = [];
  files.forEach((file, i) => {
    if (!opts.quiet) {
      process.stdout.write(`Checking ${file}...\n`);
      if (files.length > 1) {
        const pct = Math.round(((i + 1) / files.length) * 100);
        process.stdout.write(`${i + 1}/${files.length} files checked ${pct}% done\n`);
      }
    }
    findings.push(...analyze(file, opts));
  });

  const filtered = findings.filter((f) => !isSuppressed(f, opts));
  const rendered = renderFindings(filtered, opts);
  if (opts.outputFile) {
    fs.writeFileSync(opts.outputFile, rendered);
  } else if (rendered) {
    process.stderr.write(rendered);
  }

  if (filtered.length > 0 && opts.errorExitCode !== undefined) {
    process.exit(opts.errorExitCode);
  }
  process.exit(0);
}

function parseArgs(args: string[]): Options | string {
  const opts: Options = {
    quiet: false,
    xml: false,
    outputFormat: "text",
    template: "gcc",
    enable: new Set(),
    suppress: [],
    inlineSuppr: false,
    checkConfig: false,
    preprocess: false,
    fileFilters: [],
    ignored: [],
    paths: [],
  };
  const takesValue = new Set(["-I", "-i", "-j", "-l", "-D", "-U", "--include", "--includes-file", "--file-list", "--file-filter", "--output-file", "--template", "--error-exitcode", "--enable", "--disable", "--suppress", "--language", "-x", "--std", "--library", "--platform", "--project", "--cppcheck-build-dir"]);
  const recognizedNoValue = new Set(["-q", "--quiet", "--xml", "-E", "-f", "--force", "--inline-suppr", "--inconclusive", "--check-config", "--check-library", "--dump", "--verbose", "-v", "--safety", "--report-progress", "--fsigned-char", "--funsigned-char"]);

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    const eq = arg.indexOf("=");
    const key = eq >= 0 ? arg.slice(0, eq) : arg;
    const val = eq >= 0 ? arg.slice(eq + 1) : undefined;
    const getOptVal = (): string => {
      if (val !== undefined) return val;
      i++;
      return args[i] || "";
    };

    if (arg === "-q" || arg === "--quiet") opts.quiet = true;
    else if (arg === "--xml") opts.xml = true;
    else if (arg === "-E") opts.preprocess = true;
    else if (arg === "--inline-suppr") opts.inlineSuppr = true;
    else if (arg === "--check-config") opts.checkConfig = true;
    else if (key === "--output-format") opts.outputFormat = getOptVal();
    else if (key === "--template") opts.template = getOptVal();
    else if (key === "--output-file") opts.outputFile = getOptVal();
    else if (key === "--error-exitcode") opts.errorExitCode = parseInt(getOptVal(), 10) || 0;
    else if (key === "--enable") getOptVal().split(",").forEach((x) => opts.enable.add(x));
    else if (key === "--suppress") opts.suppress.push(getOptVal());
    else if (key === "--file-filter") opts.fileFilters.push(getOptVal());
    else if (arg === "-i" || key === "-i") opts.ignored.push(getOptVal());
    else if (key === "--file-list") {
      const list = getOptVal();
      if (list === "-") {
        const input = fs.readFileSync(0, "utf8");
        opts.paths.push(...input.split(/\r?\n/).filter(Boolean));
      } else if (fs.existsSync(list)) {
        opts.paths.push(...fs.readFileSync(list, "utf8").split(/\r?\n/).filter(Boolean));
      }
    } else if (recognizedNoValue.has(arg)) {
      continue;
    } else if (takesValue.has(arg) || takesValue.has(key)) {
      if (val === undefined && !args[i + 1]) return `cppcheck: error: option '${arg}' requires an argument.\n`;
      if (val === undefined) i++;
    } else if (arg.startsWith("-D") || arg.startsWith("-U") || arg.startsWith("-I")) {
      continue;
    } else if (arg.startsWith("-")) {
      return `cppcheck: error: unrecognized command line option: "${arg}".\n`;
    } else {
      opts.paths.push(arg);
    }
  }
  return opts;
}

function value(arg: string, val: string | undefined, args: string[], nextIndex: number): string {
  if (val !== undefined) return val;
  return args[nextIndex] || "";
}

function collectFiles(opts: Options): string[] {
  const result: string[] = [];
  for (const p of opts.paths) {
    if (!fs.existsSync(p)) {
      process.stdout.write(`cppcheck: error: could not find or open any of the paths given.\n`);
      process.exit(1);
    }
    const st = fs.statSync(p);
    if (st.isDirectory()) walk(p, result);
    else if (isSource(p)) result.push(p);
  }
  return result.filter((f) => !opts.ignored.some((pat) => matchGlob(f, pat)) && (opts.fileFilters.length === 0 || opts.fileFilters.some((pat) => matchGlob(f, pat))));
}

function walk(dir: string, out: string[]): void {
  for (const ent of fs.readdirSync(dir).sort()) {
    const full = path.join(dir, ent);
    const st = fs.statSync(full);
    if (st.isDirectory()) walk(full, out);
    else if (isSource(full)) out.push(full);
  }
}

function isSource(file: string): boolean {
  return /\.(c|cc|cpp|cxx|c\+\+|ipp|ixx|tpp|txx|h|hpp)$/i.test(file);
}

function preprocess(file: string): string {
  return fs.readFileSync(file, "utf8")
    .split(/\r?\n/)
    .filter((line: string) => !/^\s*#\s*include\b/.test(line))
    .join("\n") + "\n";
}

function analyze(file: string, opts: Options): Finding[] {
  let text = "";
  try {
    text = fs.readFileSync(file, "utf8");
  } catch {
    return [{ file, line: 0, column: 0, severity: "error", id: "file", message: "Could not open file." }];
  }
  const lines = text.split(/\r?\n/);
  const findings: Finding[] = [];
  const arrays = new Map<string, { size: number; line: number }>();
  const vars = new Map<string, { line: number; initialized: boolean; type: string; used: boolean }>();
  const nullPtrs = new Set<string>();
  const mallocs = new Set<string>();

  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const line = stripComments(raw);
    const lineNo = i + 1;
    if (opts.inlineSuppr && /cppcheck-suppress/.test(lines[Math.max(0, i - 1)] || "")) continue;

    let m: RegExpExecArray | null;
    const arrRe = /\b(?:char|short|int|long|float|double|bool|unsigned|signed|size_t)\s+([A-Za-z_]\w*)\s*\[\s*(\d+)\s*\]/g;
    while ((m = arrRe.exec(line))) arrays.set(m[1], { size: parseInt(m[2], 10), line: lineNo });

    const varRe = /\b(?:int|char|short|long|float|double|bool|size_t)\s+([A-Za-z_]\w*)\s*(=([^,;]+))?\s*[,;]/g;
    while ((m = varRe.exec(line))) vars.set(m[1], { line: lineNo, initialized: !!m[2], type: "var", used: false });

    const ptrRe = /\b(?:int|char|void|float|double|struct\s+\w+)\s*\*\s*([A-Za-z_]\w*)\s*=\s*(0|NULL|nullptr)\b/g;
    while ((m = ptrRe.exec(line))) nullPtrs.add(m[1]);

    const mallocRe = /\b(?:\w+\s*\*?\s*)?([A-Za-z_]\w*)\s*=\s*(?:\([^)]*\)\s*)?(malloc|calloc|realloc)\s*\(/g;
    while ((m = mallocRe.exec(line))) mallocs.add(m[1]);

    const freeRe = /\bfree\s*\(\s*([A-Za-z_]\w*)\s*\)/g;
    while ((m = freeRe.exec(line))) mallocs.delete(m[1]);

    const accessRe = /\b([A-Za-z_]\w*)\s*\[\s*(\d+)\s*\]/g;
    while ((m = accessRe.exec(line))) {
      const before = line.slice(0, m.index);
      if (/\b(?:char|short|int|long|float|double|bool|unsigned|signed|size_t)\s+$/.test(before)) continue;
      const arr = arrays.get(m[1]);
      if (arr && parseInt(m[2], 10) >= arr.size) {
        findings.push({ file, line: lineNo, column: m.index + 1, severity: "error", id: "arrayIndexOutOfBounds", message: `Array '${m[1]}[${arr.size}]' index ${m[2]} out of bounds`, code: raw.trim() });
      }
    }

    for (const p of nullPtrs) {
      const re = new RegExp(`(\\*\\s*${escapeRegExp(p)}\\b|${escapeRegExp(p)}\\s*->)`);
      if (re.test(line)) findings.push({ file, line: lineNo, column: Math.max(1, line.indexOf(p) + 1), severity: "error", id: "nullPointer", message: `Null pointer dereference: ${p}`, code: raw.trim() });
    }

    if (/(^|[^=!<>])\/\s*0+\b/.test(line)) {
      findings.push({ file, line: lineNo, column: Math.max(1, line.indexOf("/") + 1), severity: "error", id: "zerodiv", message: "Division by zero", code: raw.trim() });
    }

    const ret = /\breturn\s+([A-Za-z_]\w*)\s*;/.exec(line);
    if (ret) {
      const v = vars.get(ret[1]);
      if (v && !v.initialized) findings.push({ file, line: lineNo, column: line.indexOf(ret[1]) + 1, severity: "error", id: "uninitvar", message: `Uninitialized variable: ${ret[1]}`, code: raw.trim() });
    }

    for (const [name, v] of vars) {
      if (lineNo !== v.line && new RegExp(`\\b${escapeRegExp(name)}\\b`).test(line)) v.used = true;
    }

    if (enabled(opts, "missingInclude")) {
      const inc = /^\s*#\s*include\s+"([^"]+)"/.exec(raw);
      if (inc && !fs.existsSync(path.join(path.dirname(file), inc[1]))) {
        findings.push({ file, line: lineNo, column: 1, severity: "information", id: "missingInclude", message: `Include file: "${inc[1]}" not found.`, code: raw.trim() });
      }
    }
  }

  if (enabled(opts, "style")) {
    for (const [name, v] of vars) {
      if (!v.used && name !== "main") findings.push({ file, line: v.line, column: 1, severity: "style", id: "unusedVariable", message: `Unused variable: ${name}`, code: lines[v.line - 1].trim() });
    }
  }
  if (enabled(opts, "warning") || enabled(opts, "performance") || enabled(opts, "all")) {
    for (const name of mallocs) {
      findings.push({ file, line: 1, column: 1, severity: "error", id: "memleak", message: `Memory leak: ${name}` });
    }
  }
  return findings;
}

function enabled(opts: Options, sev: string): boolean {
  return opts.enable.has("all") || opts.enable.has(sev);
}

function stripComments(line: string): string {
  return line.replace(/\/\/.*$/, "").replace(/\/\*.*?\*\//g, "");
}

function isSuppressed(f: Finding, opts: Options): boolean {
  return opts.suppress.some((s) => {
    const [id, file, line] = s.split(":");
    const idOk = !id || id === "*" || id === f.id;
    const fileOk = !file || f.file.includes(file);
    const lineOk = !line || parseInt(line, 10) === f.line;
    return idOk && fileOk && lineOk;
  });
}

function renderFindings(findings: Finding[], opts: Options): string {
  if (opts.xml || opts.outputFormat.startsWith("xml")) {
    return `<?xml version="1.0" encoding="UTF-8"?>\n<results version="2">\n    <cppcheck version="2.19 dev"/>\n    <errors>\n${findings.map(xmlFinding).join("")}    </errors>\n</results>\n`;
  }
  if (opts.outputFormat === "sarif") {
    return JSON.stringify({ version: "2.1.0", runs: [{ tool: { driver: { name: "Cppcheck", version: "2.19 dev" } }, results: findings.map((f) => ({ ruleId: f.id, level: f.severity === "error" ? "error" : "warning", message: { text: f.message }, locations: [{ physicalLocation: { artifactLocation: { uri: f.file }, region: { startLine: f.line, startColumn: f.column } } }] })) }] }, null, 2) + "\n";
  }
  return findings.map((f) => renderText(f, opts.template)).join("");
}

function renderText(f: Finding, template: string): string {
  if (template === "cppcheck1") return `[${f.file}:${f.line}]: (${f.severity}) ${f.message}\n`;
  if (template === "vs") return `${f.file}(${f.line}): ${f.severity}: ${f.message} [${f.id}]\n`;
  if (template === "edit") return `${f.file} +${f.line}: ${f.message}\n`;
  if (template && template !== "gcc") {
    return template
      .replace(/\\n/g, "\n")
      .replace(/\\t/g, "\t")
      .replace(/\{file\}/g, f.file)
      .replace(/\{line\}/g, String(f.line))
      .replace(/\{column\}/g, String(f.column))
      .replace(/\{severity\}/g, f.severity)
      .replace(/\{message\}/g, f.message)
      .replace(/\{id\}/g, f.id)
      .replace(/\{code\}/g, f.code || "") + "\n";
  }
  return `${f.file}:${f.line}:${f.column}: ${f.severity}: ${f.message} [${f.id}]\n`;
}

function renderErrorList(): string {
  return `<?xml version="1.0" encoding="UTF-8"?>\n<results version="2">\n    <cppcheck version="2.19 dev"/>\n    <errors>\n${ERRORLIST.map(([id, sev, msg, cwe]) => `        <error id="${id}" severity="${sev}" msg="${xmlEscape(msg)}" verbose="${xmlEscape(msg)}"${cwe !== "0" ? ` cwe="${cwe}"` : ""}/>\n`).join("")}    </errors>\n</results>\n`;
}

function xmlFinding(f: Finding): string {
  return `        <error id="${f.id}" severity="${f.severity}" msg="${xmlEscape(f.message)}" verbose="${xmlEscape(f.message)}" file="${xmlEscape(f.file)}" line="${f.line}" column="${f.column}"/>\n`;
}

function xmlEscape(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function matchGlob(file: string, pat: string): boolean {
  if (!pat) return false;
  const re = "^" + pat.split("*").map(escapeRegExp).join(".*").split("?").join(".") + "$";
  return new RegExp(re).test(file) || file.includes(pat.replace(/\*/g, ""));
}

main();
