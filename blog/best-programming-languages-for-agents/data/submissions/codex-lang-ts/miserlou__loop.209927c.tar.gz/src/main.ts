declare const require: any;
declare const process: any;

const cp = require("child_process");
const fs = require("fs");

const VERSION = "loop 0.6.1";
const HELP = `loop 0.6.1
Rich Jones <miserlou@gmail.com>
UNIX's missing \`loop\` command

USAGE:
    executable [FLAGS] [OPTIONS] [input]...

FLAGS:
    -D, --error-duration    Exit with timeout error code on duration
    -h, --help              Prints help information
    -l, --only-last         Only print the output of the last execution of the command
    -i, --stdin             Read from standard input
        --summary           Provide a summary
    -C, --until-changes     Keep going until the output changes
    -f, --until-fail        Keep going until the command exit status is non-zero
    -S, --until-same        Keep going until the output changes
    -s, --until-success     Keep going until the command exit status is zero
    -V, --version           Prints version information

OPTIONS:
    -b, --count-by <count_by>                Amount to increment the counter by [default: 1]
    -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]
        --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue
    -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)
    -n, --num <num>                          Number of iterations to execute
    -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]
    -c, --until-contains <until_contains>    Keep going until the output contains this string
    -r, --until-error <until_error>          Keep going until the command exit status is the value given
    -m, --until-match <until_match>          Keep going until the output matches this regular expression
    -t, --until-time <until_time>            Keep going until a future time, ex. "2018-04-20 04:20:00" (Times in UTC.)

ARGS:
    <input>...    The command to be looped`;

type Opts = {
  num?: number;
  every: number;
  countBy: number;
  offset: number;
  forDuration?: number;
  untilTime?: number;
  forValues?: string[];
  stdin: boolean;
  onlyLast: boolean;
  summary: boolean;
  errorDuration: boolean;
  untilSuccess: boolean;
  untilFail: boolean;
  untilError?: number;
  untilContains?: string;
  untilMatch?: RegExp;
  untilChanges: boolean;
  untilSame: boolean;
  input: string[];
};

function usageError(msg: string): never {
  process.stderr.write(`error: ${msg}\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input]...\n\nFor more information try --help\n`);
  process.exit(1);
  throw new Error("unreachable");
}

function invalidValue(opt: string, val: string, reason = "invalid float literal"): never {
  process.stderr.write(`error: Invalid value for '${opt}': ${reason}\n`);
  process.exit(1);
  throw new Error("unreachable");
}

function parseNumber(opt: string, val: string): number {
  if (!/^[-+]?\d+(?:\.\d+)?$/.test(val)) invalidValue(opt, val);
  return Number(val);
}

function parseIntValue(opt: string, val: string): number {
  if (!/^[-+]?\d+$/.test(val)) invalidValue(opt, val, "invalid digit found in string");
  return parseInt(val, 10);
}

function parseDuration(s: string): number {
  if (/^[-+]?\d+(?:\.\d+)?$/.test(s)) return Number(s);
  let total = 0;
  let pos = 0;
  const re = /(\d+(?:\.\d+)?)(us|ms|s|m|h|d)/g;
  let m: any;
  while ((m = re.exec(s)) !== null) {
    if (m.index !== pos) return NaN;
    const n = Number(m[1]);
    const u = m[2];
    if (u === "us") total += n / 1000;
    else if (u === "ms") total += n;
    else if (u === "s") total += n * 1000;
    else if (u === "m") total += n * 60000;
    else if (u === "h") total += n * 3600000;
    else if (u === "d") total += n * 86400000;
    pos = re.lastIndex;
  }
  return pos === s.length && pos > 0 ? total : NaN;
}

function nextArg(args: string[], i: number, flag: string): [string, number] {
  if (i + 1 >= args.length) usageError(`The argument '${flag}' requires a value but none was supplied`);
  return [args[i + 1], i + 1];
}

function parseArgs(argv: string[]): Opts {
  const opts: Opts = { every: 0.001, countBy: 1, offset: 0, stdin: false, onlyLast: false, summary: false, errorDuration: false, untilSuccess: false, untilFail: false, untilChanges: false, untilSame: false, input: [] };
  let afterDashDash = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (afterDashDash) { opts.input.push(a); continue; }
    if (a === "--") { afterDashDash = true; continue; }
    if (a === "-h" || a === "--help") { process.stdout.write(HELP + "\n"); process.exit(0); }
    if (a === "-V" || a === "--version") { process.stdout.write(VERSION + "\n"); process.exit(0); }
    if (a === "-D" || a === "--error-duration") opts.errorDuration = true;
    else if (a === "-l" || a === "--only-last") opts.onlyLast = true;
    else if (a === "-i" || a === "--stdin") opts.stdin = true;
    else if (a === "--summary") opts.summary = true;
    else if (a === "-C" || a === "--until-changes") opts.untilChanges = true;
    else if (a === "-S" || a === "--until-same") opts.untilSame = true;
    else if (a === "-f" || a === "--until-fail") opts.untilFail = true;
    else if (a === "-s" || a === "--until-success") opts.untilSuccess = true;
    else if (["-b", "--count-by"].includes(a)) { let v; [v, i] = nextArg(argv, i, a); opts.countBy = parseNumber("--count-by <count_by>", v); }
    else if (["-o", "--offset"].includes(a)) { let v; [v, i] = nextArg(argv, i, a); opts.offset = parseNumber("--offset <offset>", v); }
    else if (["-n", "--num"].includes(a)) { let v; [v, i] = nextArg(argv, i, a); opts.num = parseNumber("--num <num>", v); }
    else if (["-e", "--every"].includes(a)) { let v; [v, i] = nextArg(argv, i, a); const d = parseDuration(v); if (!isFinite(d)) invalidValue("--every <every>", v); opts.every = d; }
    else if (a === "--for") { let v; [v, i] = nextArg(argv, i, a); opts.forValues = v.length ? v.split(",") : [""]; }
    else if (["-d", "--for-duration"].includes(a)) { let v; [v, i] = nextArg(argv, i, a); const d = parseDuration(v); if (!isFinite(d)) invalidValue("--for-duration <for_duration>", v); opts.forDuration = d; }
    else if (["-t", "--until-time"].includes(a)) { let v; [v, i] = nextArg(argv, i, a); const t = Date.parse(v.replace(" ", "T") + (/[zZ]|[+-]\d\d:?\d\d$/.test(v) ? "" : "Z")); if (!isFinite(t)) invalidValue("--until-time <until_time>", v); opts.untilTime = t; }
    else if (["-c", "--until-contains"].includes(a)) { let v; [v, i] = nextArg(argv, i, a); opts.untilContains = v; }
    else if (["-r", "--until-error"].includes(a)) { let v; [v, i] = nextArg(argv, i, a); opts.untilError = parseIntValue("--until-error <until_error>", v); }
    else if (["-m", "--until-match"].includes(a)) { let v; [v, i] = nextArg(argv, i, a); try { opts.untilMatch = new RegExp(v); } catch (_) { usageError(`Invalid regex for '--until-match <until_match>'`); } }
    else if (a.startsWith("-")) usageError(`Found argument '${a}' which wasn't expected, or isn't valid in this context`);
    else opts.input.push(a);
  }
  return opts;
}

function sleep(ms: number) {
  if (ms < 1) return;
  cp.spawnSync("bash", ["-lc", `sleep ${Math.max(ms / 1000, 0)}`]);
}

function writeOutput(text: string, fd: 1 | 2) {
  if (text.length === 0) return;
  (fd === 1 ? process.stdout : process.stderr).write(text);
  if (!text.endsWith("\n")) (fd === 1 ? process.stdout : process.stderr).write("\n");
}

function runCommand(command: string, envItem?: string): { stdout: string; stderr: string; status: number; combined: string } {
  const env: any = Object.assign({}, process.env);
  if (envItem !== undefined) env.ITEM = envItem;
  const r = cp.spawnSync("/bin/sh", ["-c", command], { encoding: "utf8", env });
  const status = typeof r.status === "number" ? r.status : 1;
  const stdout = r.stdout || "";
  const stderr = r.stderr || "";
  return { stdout, stderr, status, combined: stdout + stderr };
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const command = opts.input.join(" ");
  if (command.length === 0) { process.stdout.write("No command supplied, exiting.\n"); return; }

  let items: string[] | undefined = opts.forValues;
  if (opts.stdin) {
    const data = fs.readFileSync(0, "utf8");
    items = data.split(/\r?\n/).filter((x: string, idx: number, arr: string[]) => !(idx === arr.length - 1 && x === ""));
  }

  const start = Date.now();
  let runs = 0, successes = 0, failures = 0;
  let counter = opts.offset;
  let lastOut = "";
  let prevOut: string | undefined;
  let itemIndex = 0;
  const maxRuns = opts.num !== undefined ? Math.max(0, Math.floor(opts.num)) : (items ? items.length : undefined);

  while (true) {
    if (maxRuns !== undefined && runs >= maxRuns) break;
    if (opts.forDuration !== undefined && Date.now() - start >= opts.forDuration) break;
    if (opts.untilTime !== undefined && Date.now() >= opts.untilTime) break;

    const item = items ? items[itemIndex % Math.max(items.length, 1)] : undefined;
    const res = runCommand(command, item);
    runs++;
    if (res.status === 0) successes++; else failures++;
    lastOut = res.stdout + res.stderr;
    if (!opts.onlyLast) { writeOutput(res.stdout, 1); writeOutput(res.stderr, 2); }

    let stop = false;
    if (opts.untilSuccess && res.status === 0) stop = true;
    if (opts.untilFail && res.status !== 0) stop = true;
    if (opts.untilError !== undefined && res.status === opts.untilError) stop = true;
    if (opts.untilContains !== undefined && res.combined.includes(opts.untilContains)) stop = true;
    if (opts.untilMatch && opts.untilMatch.test(res.combined)) stop = true;
    if (opts.untilChanges && prevOut !== undefined && res.combined !== prevOut) stop = true;
    if (opts.untilSame && prevOut !== undefined && res.combined === prevOut) stop = true;
    prevOut = res.combined;
    counter += opts.countBy;
    itemIndex++;
    if (stop) break;
    if (maxRuns === undefined && opts.forDuration === undefined && opts.untilTime === undefined && !opts.untilSuccess && !opts.untilFail && opts.untilError === undefined && opts.untilContains === undefined && !opts.untilMatch && !opts.untilChanges && !opts.untilSame) {
      // Match loop's default behavior: continue forever until interrupted.
    }
    sleep(opts.every);
  }

  if (opts.onlyLast) writeOutput(lastOut, 1);
  if (opts.summary) {
    process.stdout.write(`Total runs:\t${runs}\nSuccesses:\t${successes}\nFailures:\t${failures}\n`);
  }
  if (opts.errorDuration && opts.forDuration !== undefined && Date.now() - start >= opts.forDuration) process.exit(124);
}

main();
