declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");

type Mode = "fields" | "bytes" | "chars" | "lines";
type Piece = { kind: "single"; index: number; fallback?: string } | { kind: "range"; start?: number; end?: number };
type Segment = { text: string; delimAfter: string };

interface Opts {
  mode: Mode;
  spec: string;
  delimiter: string;
  regex?: string;
  greedy: boolean;
  compress: boolean;
  onlyDelimited: boolean;
  zero: boolean;
  complement: boolean;
  join?: boolean;
  replace?: string;
  json: boolean;
  trim?: string;
  fallback?: string;
  file?: string;
}

const HELP = `tuc 1.3.0
Cut text (or bytes) where a delimiter matches, then keep the desired parts.

USAGE:
    tuc [FLAGS] [OPTIONS] < input
    tuc [FLAGS] [OPTIONS] filepath

FLAGS:
    -g, --greedy-delimiter        Match consecutive delimiters as if it was one
    -p, --compress-delimiter      Print only the first delimiter of a sequence
    -s, --only-delimited          Print only lines containing the delimiter
    -V, --version                 Print version information
    -z, --zero-terminated         Line delimiter is NUL (\\0), not LF (\\n)
    -h, --help                    Print this help and exit
    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
    -j, --(no-)join               Print selected parts with delimiter in between
    --json                        Print fields as a JSON array of strings
    --no-mmap                     Disable memory mapping

OPTIONS:
    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.
    -b, --bytes <bounds>          Same as --fields, but it keeps bytes
    -c, --characters <bounds>     Same as --fields, but it keeps characters
    -l, --lines <bounds>          Same as --fields, but it keeps lines
    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text
                                  [default: \\t]
    -e, --regex <some regex>      Use a regular expression as delimiter
    -r, --replace-delimiter <new> Replace the delimiter with the provided text.
                                  Implies --join
    -t, --trim <type>             Trim the delimiter (greedy). Valid values are
                                  (l|L)eft, (r|R)ight, (b|B)oth
        --fallback-oob <fallback> Generic fallback output for any field that
                                  cannot be found (oob stands for out of bound).
    -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.
`;

function die(msg: string): never {
  process.stderr.write(msg + "\n");
  process.exit(1);
  throw new Error(msg);
}

function nextArg(args: string[], i: number, flag: string): [string, number] {
  if (i + 1 >= args.length) die(`tuc: missing value for ${flag}`);
  return [args[i + 1], i + 1];
}

function unescapeDelim(s: string): string {
  return s.replace(/\\0/g, "\0").replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\r/g, "\r");
}

function parseArgs(argv: string[]): Opts {
  const o: Opts = { mode: "fields", spec: "1:", delimiter: "\t", greedy: false, compress: false, onlyDelimited: false, zero: false, complement: false, json: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") { process.stdout.write(HELP); process.exit(0); }
    if (a === "-V" || a === "--version") { process.stdout.write("tuc 1.3.0\n"); process.exit(0); }
    if (a === "-g" || a === "--greedy-delimiter") o.greedy = true;
    else if (a === "-p" || a === "--compress-delimiter") o.compress = true;
    else if (a === "-s" || a === "--only-delimited") o.onlyDelimited = true;
    else if (a === "-z" || a === "--zero-terminated") o.zero = true;
    else if (a === "-m" || a === "--complement") o.complement = true;
    else if (a === "-j" || a === "--join") o.join = true;
    else if (a === "--no-join") o.join = false;
    else if (a === "--json") o.json = true;
    else if (a === "--no-mmap") {}
    else if (a === "-M" || a === "--fixed-memory") { const r = nextArg(argv, i, a); i = r[1]; }
    else if (a === "-f" || a === "--fields") { const r = nextArg(argv, i, a); o.mode = "fields"; o.spec = r[0]; i = r[1]; }
    else if (a === "-b" || a === "--bytes") { const r = nextArg(argv, i, a); o.mode = "bytes"; o.spec = r[0]; i = r[1]; }
    else if (a === "-c" || a === "--characters") { const r = nextArg(argv, i, a); o.mode = "chars"; o.spec = r[0]; i = r[1]; }
    else if (a === "-l" || a === "--lines") { const r = nextArg(argv, i, a); o.mode = "lines"; o.spec = r[0]; if (o.join === undefined) o.join = true; i = r[1]; }
    else if (a === "-d" || a === "--delimiter") { const r = nextArg(argv, i, a); o.delimiter = unescapeDelim(r[0]); i = r[1]; }
    else if (a === "-e" || a === "--regex") { const r = nextArg(argv, i, a); o.regex = r[0]; i = r[1]; }
    else if (a === "-r" || a === "--replace-delimiter") { const r = nextArg(argv, i, a); o.replace = unescapeDelim(r[0]); o.join = true; i = r[1]; }
    else if (a === "-t" || a === "--trim") { const r = nextArg(argv, i, a); o.trim = r[0].toLowerCase(); o.greedy = true; i = r[1]; }
    else if (a === "--fallback-oob") { const r = nextArg(argv, i, a); o.fallback = r[0]; i = r[1]; }
    else if (a.startsWith("-")) die(`tuc: unexpected arguments: ["${a}"]\nTry 'tuc --help' for more information.`);
    else if (!o.file) o.file = a;
    else die(`tuc: unexpected arguments: ["${a}"]`);
  }
  return o;
}

function parseNum(s: string, whole: string): number {
  if (!/^-?\d+$/.test(s)) die(`failed to parse '${whole}': Not a number \`${s}\``);
  const n = Number(s);
  if (n === 0) die(`failed to parse '${whole}': Field cannot be zero`);
  return n;
}

function parsePieces(spec: string): Piece[] {
  const out: Piece[] = [];
  for (const raw of spec.split(",")) {
    if (raw === "") continue;
    let part = raw, fallback: string | undefined;
    const eq = raw.indexOf("=");
    if (eq >= 0) { part = raw.slice(0, eq); fallback = raw.slice(eq + 1); }
    if (part.includes(":")) {
      const [a, b] = part.split(":", 2);
      const start = a === "" ? undefined : parseNum(a, raw);
      const end = b === "" ? undefined : parseNum(b, raw);
      if (start !== undefined && end !== undefined && start > 0 && end > 0 && start > end) die(`failed to parse '${raw}': Field left value cannot be greater than right value`);
      if (start !== undefined && end !== undefined && start < 0 && end < 0 && start > end) die(`failed to parse '${raw}': Field left value cannot be greater than right value`);
      out.push({ kind: "range", start, end });
    } else {
      out.push({ kind: "single", index: parseNum(part, raw), fallback });
    }
  }
  return out.length ? out : [{ kind: "range", start: 1 }];
}

function resolveIndex(idx: number, n: number): number {
  return idx < 0 ? n + idx + 1 : idx;
}

function indicesFor(pieces: Piece[], n: number, complement: boolean): number[] {
  const idxs: number[] = [];
  for (const p of pieces) {
    if (p.kind === "single") idxs.push(resolveIndex(p.index, n));
    else {
      const s = p.start === undefined ? 1 : resolveIndex(p.start, n);
      const e = p.end === undefined ? n : resolveIndex(p.end, n);
      if (s > e) die(`failed to parse '${p.start}:${p.end}': Field left value cannot be greater than right value`);
      for (let i = s; i <= e; i++) idxs.push(i);
    }
  }
  if (!complement) return idxs;
  const set = new Set(idxs.filter(x => x >= 1 && x <= n));
  const inv: number[] = [];
  for (let i = 1; i <= n; i++) if (!set.has(i)) inv.push(i);
  return inv;
}

function splitFields(line: string, o: Opts): Segment[] {
  let s = line;
  if (o.compress && !o.regex && o.delimiter) {
    const d = escapeRe(o.delimiter);
    s = s.replace(new RegExp(`${d}+`, "g"), o.delimiter);
  }
  const segs: Segment[] = [];
  if (o.regex) {
    const re = new RegExp(o.regex, "g");
    let last = 0, m: RegExpExecArray | null;
    while ((m = re.exec(s)) !== null) {
      const d = m[0];
      if (d === "") { re.lastIndex++; continue; }
      segs.push({ text: s.slice(last, m.index), delimAfter: d });
      last = m.index + d.length;
    }
    segs.push({ text: s.slice(last), delimAfter: "" });
  } else {
    const d = o.delimiter;
    let i = 0;
    while (true) {
      const pos = s.indexOf(d, i);
      if (pos < 0) break;
      let end = pos + d.length;
      if (o.greedy || o.compress || o.trim) while (s.startsWith(d, end)) end += d.length;
      segs.push({ text: s.slice(i, pos), delimAfter: s.slice(pos, end) });
      i = end;
    }
    segs.push({ text: s.slice(i), delimAfter: "" });
  }
  if (o.trim && !o.regex) {
    for (let i = 0; i < segs.length; i++) {
      if (o.trim === "l" || o.trim === "b") segs[i].text = segs[i].text.replace(/[ \t]+$/g, "");
      if (o.trim === "r" || o.trim === "b") segs[i].text = segs[i].text.replace(/^[ \t]+/g, "");
    }
  }
  return segs;
}

function escapeRe(s: string): string { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

function selectedStrings(segs: Segment[], pieces: Piece[], o: Opts): string[] {
  const vals: string[] = [];
  if (o.complement) {
    for (const i of indicesFor(pieces, segs.length, true)) vals.push(segs[i - 1]?.text ?? o.fallback ?? "");
    return vals;
  }
  for (const p of pieces) {
    if (p.kind === "single") {
      const idx = resolveIndex(p.index, segs.length);
      const v = idx >= 1 && idx <= segs.length ? segs[idx - 1].text : (p.fallback ?? o.fallback);
      if (v !== undefined) vals.push(v);
    } else {
      for (const i of indicesFor([p], segs.length, false)) if (i >= 1 && i <= segs.length) vals.push(segs[i - 1].text);
    }
  }
  return vals;
}

function renderSelection(segs: Segment[], pieces: Piece[], o: Opts): string {
  if (o.json) return JSON.stringify(selectedStrings(segs, pieces, o));
  if (isTemplate(o.spec)) return renderTemplate(o.spec, segs, o);
  const idxs = indicesFor(pieces, segs.length, o.complement);
  const parts: string[] = [];
  for (let k = 0; k < idxs.length; k++) {
    const idx = idxs[k];
    const seg = idx >= 1 && idx <= segs.length ? segs[idx - 1] : undefined;
    if (!seg) {
      const p = pieces[k];
      const fb = p && p.kind === "single" ? p.fallback : undefined;
      if (fb !== undefined || o.fallback !== undefined) parts.push(fb ?? o.fallback ?? "");
      continue;
    }
    parts.push(seg.text);
    const next = idxs[k + 1];
    if (next !== undefined) {
      if (o.join) {
        if (o.replace !== undefined) parts.push(o.replace);
        else if (next === idx + 1) parts.push(seg.delimAfter || (o.regex ? "" : o.delimiter));
        else parts.push(o.regex ? "" : o.delimiter);
      }
      else if (next === idx + 1) parts.push(o.replace !== undefined ? o.replace : seg.delimAfter);
    }
  }
  return parts.join("");
}

function isTemplate(spec: string): boolean {
  return /(^|[^{])\{\s*-?\d/.test(spec);
}

function renderTemplate(spec: string, segs: Segment[], o: Opts): string {
  let res = "";
  for (let i = 0; i < spec.length; i++) {
    if (spec[i] === "{" && spec[i + 1] === "{") { res += "{"; i++; continue; }
    if (spec[i] === "}" && spec[i + 1] === "}") { res += "}"; i++; continue; }
    if (spec[i] === "{") {
      const j = spec.indexOf("}", i + 1);
      if (j >= 0) {
        const inner = spec.slice(i + 1, j).trim();
        if (/^-?\d+$/.test(inner)) {
          const idx = resolveIndex(Number(inner), segs.length);
          res += idx >= 1 && idx <= segs.length ? segs[idx - 1].text : (o.fallback ?? "");
          i = j;
          continue;
        }
      }
    }
    res += spec[i];
  }
  return res;
}

function splitRecords(input: string, sep: string): { records: string[]; ended: boolean } {
  const ended = input.endsWith(sep);
  const arr = input.split(sep);
  if (ended) arr.pop();
  return { records: arr, ended };
}

function processFields(input: string, o: Opts): string {
  if (o.regex && o.join && o.replace === undefined) die("tuc: runtime error. Cannot use --regex and --join without --replace-delimiter");
  const lineSep = o.zero ? "\0" : "\n";
  const { records, ended } = splitRecords(input, lineSep);
  const pieces = isTemplate(o.spec) ? [] : parsePieces(o.spec);
  const out: string[] = [];
  for (const rec of records) {
    const segs = splitFields(rec, o);
    const hasDelim = segs.length > 1;
    if (o.onlyDelimited && !hasDelim) continue;
    out.push(renderSelection(segs, pieces, o) + lineSep);
  }
  if (!ended && out.length > 0 && out[out.length - 1].endsWith(lineSep)) out[out.length - 1] = out[out.length - 1].slice(0, -lineSep.length);
  return out.join("");
}

function charsOf(s: string): string[] { return Array.from(s); }

function processChars(input: string, o: Opts): string {
  const sep = o.zero ? "\0" : "\n";
  const { records, ended } = splitRecords(input, sep);
  const pieces = parsePieces(o.spec);
  const out: string[] = [];
  for (const rec of records) {
    const segs = charsOf(rec).map(ch => ({ text: ch, delimAfter: "" }));
    out.push(renderSelection(segs, pieces, { ...o, join: false }) + sep);
  }
  if (!ended && out.length) out[out.length - 1] = out[out.length - 1].slice(0, -sep.length);
  return out.join("");
}

function processBytes(buf: any, o: Opts): any {
  const pieces = parsePieces(o.spec);
  const idxs = indicesFor(pieces, buf.length, o.complement);
  const bytes: number[] = [];
  for (const idx of idxs) if (idx >= 1 && idx <= buf.length) bytes.push(buf[idx - 1]);
  return Buffer.from(bytes);
}

function processLines(input: string, o: Opts): string {
  const sep = o.zero ? "\0" : "\n";
  const { records } = splitRecords(input, sep);
  const pieces = parsePieces(o.spec);
  const segs = records.map(t => ({ text: t, delimAfter: sep }));
  const idxs = indicesFor(pieces, records.length, o.complement);
  const parts: string[] = [];
  for (let k = 0; k < idxs.length; k++) {
    const idx = idxs[k];
    if (idx < 1 || idx > records.length) continue;
    parts.push(records[idx - 1]);
    if (o.join !== false) parts.push(o.replace ?? sep);
  }
  if (o.join === false) parts.push(sep);
  return o.json ? JSON.stringify(selectedStrings(segs, pieces, o)) + sep : parts.join("");
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  let buf: any;
  try {
    buf = o.file ? fs.readFileSync(o.file) : fs.readFileSync(0);
  } catch (e: any) {
    die(`tuc: ${e.message}`);
  }
  if (o.mode === "bytes") process.stdout.write(processBytes(buf, o));
  else {
    const input = buf.toString("utf8");
    if (o.mode === "chars") process.stdout.write(processChars(input, o));
    else if (o.mode === "lines") process.stdout.write(processLines(input, o));
    else process.stdout.write(processFields(input, o));
  }
}

main();
