declare const require: any;
declare const process: any;
declare const __dirname: string;

const fs = require("fs");
const path = require("path");
const child_process = require("child_process");

type Opts = { [key: string]: any; _: string[] };
type Note = {
  path: string;
  abs: string;
  title: string;
  content: string;
  tags: string[];
  created: Date;
  modified: Date;
  links: string[];
};

const ROOT_HELP = `Usage: zk <command>

Commands:

NOTEBOOK
  A notebook is a directory containing a collection of notes

  init     Create a new notebook in the given directory.
  index    Index the notes to be searchable.

NOTES
  Edit or browse your notes

  new      Create a new note in the given notebook directory.
  list     List notes matching the given criteria.
  graph    Produce a graph of the notes matching the given criteria.
  edit     Edit notes matching the given criteria.
  tag      Manage the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Run "zk <command> --help" for more information on a command.`;

const COMMON_FLAGS = `Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.`;

const FILTER_HELP = `Filtering
  -i, --interactive                Select notes interactively with fzf.
  -n, --limit=COUNT                Limit the number of notes found.
  -m, --match=QUERY,...            Terms to search for in the notes.
  -M, --match-strategy=STRATEGY    Text matching strategy among: fts, re, exact.
  -x, --exclude=PATH,...           Ignore notes matching the given path,
                                   including its descendants.
  -t, --tag=TAG,...                Find notes tagged with the given tags.
      --mention=PATH,...           Find notes mentioning the title of the given
                                   ones.
      --mentioned-by=PATH,...      Find notes whose title is mentioned in the
                                   given ones.
  -l, --link-to=PATH,...           Find notes which are linking to the given
                                   ones.
      --no-link-to=PATH,...        Find notes which are not linking to the given
                                   notes.
  -L, --linked-by=PATH,...         Find notes which are linked by the given
                                   ones.
      --no-linked-by=PATH,...      Find notes which are not linked by the given
                                   ones.
      --orphan                     Find notes which are not linked by any other
                                   note.
      --tagless                    Find notes which have no tags.
      --missing-backlink           Find notes with at least one missing
                                   backlink.
      --related=PATH,...           Find notes which might be related to the
                                   given ones.
      --max-distance=COUNT         Maximum distance between two linked notes.
  -r, --recursive                  Follow links recursively.
      --created=DATE
      --created-before=DATE        Find notes created before the given date.
      --created-after=DATE         Find notes created after the given date.
      --modified=DATE              Find notes modified on the given date.
      --modified-before=DATE       Find notes modified before the given date.
      --modified-after=DATE        Find notes modified after the given date.`;

const SORT_HELP = `Sorting
  -s, --sort=TERM,...    Order the notes by the given criterion.`;

const HELPS: { [key: string]: string } = {
  init: `Usage: zk init [<directory>]

Create a new notebook in the given directory.

Arguments:
  [<directory>]    Directory containing the notebook.

${COMMON_FLAGS}`,
  index: `Usage: zk index

Index the notes to be searchable.

You usually do not need to run \`zk index\` manually, as notes are indexed
automatically when needed.

${COMMON_FLAGS}

  -f, --force                Force indexing all the notes.
  -v, --verbose              Print detailed information about the indexing
                             process.
  -q, --quiet                Do not print statistics nor progress.`,
  new: `Usage: zk new [<directory>]

Create a new note in the given notebook directory.

Arguments:
  [<directory>]    Directory in which to create the note.

${COMMON_FLAGS}

  -i, --interactive            Read contents from standard input.
  -t, --title=TITLE            Title of the new note.
      --date=DATE              Set the current date.
  -g, --group=NAME             Name of the config group this note belongs to.
                               Takes precedence over the config of the
                               directory.
      --extra=KEY=VALUE,...    Extra variables passed to the templates.
      --template=PATH          Custom template used to render the note.
  -p, --print-path             Print the path of the created note instead of
                               editing it.
  -n, --dry-run                Don't actually create the note. Instead, prints
                               its content on stdout and the generated path on
                               stderr.
      --id=ID                  Skip id generation and use provided value.`,
  list: `Usage: zk list [<path> ...]

List notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

${COMMON_FLAGS}

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: oneline, short, medium,
                           long, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print notes delimited by the given separator.
  -0, --delimiter0         Print notes delimited by ASCII NUL characters. This
                           is useful when used in conjunction with \`xargs -0\`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of notes found.

${FILTER_HELP}

${SORT_HELP}`,
  graph: `Usage: zk graph --format=STRING [<path> ...]

Produce a graph of the notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

${COMMON_FLAGS}

Formatting
  -f, --format=STRING    Format of the graph among: json.
  -q, --quiet            Do not print the total number of notes found.

${FILTER_HELP}

${SORT_HELP}`,
  edit: `Usage: zk edit [<path> ...]

Edit notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

${COMMON_FLAGS}

  -f, --force                Do not confirm before editing many notes at the
                             same time.

${FILTER_HELP}

${SORT_HELP}`,
  tag: `Usage: zk tag <command>

Manage the note tags.

Commands:
  tag list    List all the note tags.

${COMMON_FLAGS}`,
  tagList: `Usage: zk tag list

List all the note tags.

${COMMON_FLAGS}

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: name, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print tags delimited by the given separator.
  -0, --delimiter0         Print tags delimited by ASCII NUL characters. This is
                           useful when used in conjunction with \`xargs -0\`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of tags found.

Sorting
  -s, --sort=TERM,...    Order the tags by the given criterion.`
};

function stdout(s: string) { process.stdout.write(s + "\n"); }
function stderr(s: string) { process.stderr.write(s + "\n"); }
function fail(msg: string): never { stderr(`zk: error: ${msg}`); process.exit(1); throw new Error(msg); }

function parse(argv: string[]): { global: Opts; cmd?: string; rest: string[] } {
  const global: Opts = { _: [] };
  let i = 0;
  while (i < argv.length) {
    const a = argv[i];
    if (a === "--") { i++; break; }
    if (!a.startsWith("-")) break;
    if (a === "-h" || a === "--help") { global.help = true; i++; continue; }
    if (a === "--version") { global.version = true; i++; continue; }
    if (a === "--no-input") { global.noInput = true; i++; continue; }
    if (a === "-W" || a === "--working-dir") { global.workingDir = argv[++i]; i++; continue; }
    if (a.startsWith("--working-dir=")) { global.workingDir = a.slice(14); i++; continue; }
    if (a === "--notebook-dir") { global.notebookDir = argv[++i]; i++; continue; }
    if (a.startsWith("--notebook-dir=")) { global.notebookDir = a.slice(15); i++; continue; }
    fail(`unknown flag ${a}`);
  }
  const cmd = argv[i];
  return { global, cmd, rest: cmd ? argv.slice(i + 1) : [] };
}

function parseCommand(rest: string[]): Opts {
  const o: Opts = { _: [] };
  const bools: any = {
    "-h": "help", "--help": "help", "-i": "interactive", "--interactive": "interactive",
    "-p": "printPath", "--print-path": "printPath", "-n": "dryRun", "--dry-run": "dryRun",
    "-f": "force", "--force": "force", "-v": "verbose", "--verbose": "verbose",
    "-q": "quiet", "--quiet": "quiet", "-0": "delimiter0", "--delimiter0": "delimiter0",
    "-P": "noPager", "--no-pager": "noPager", "-r": "recursive", "--recursive": "recursive",
    "--orphan": "orphan", "--tagless": "tagless", "--missing-backlink": "missingBacklink",
    "--no-input": "noInput"
  };
  const vals: any = {
    "-t": "title", "--title": "title", "--date": "date", "-g": "group", "--group": "group",
    "--extra": "extra", "--template": "template", "--id": "id", "-f": "format", "--format": "format",
    "--header": "header", "--footer": "footer", "-d": "delimiter", "--delimiter": "delimiter",
    "-n": "limit", "--limit": "limit", "-m": "match", "--match": "match", "-M": "matchStrategy",
    "--match-strategy": "matchStrategy", "-x": "exclude", "--exclude": "exclude", "--tag": "tag",
    "--mention": "mention", "--mentioned-by": "mentionedBy", "-l": "linkTo", "--link-to": "linkTo",
    "--no-link-to": "noLinkTo", "-L": "linkedBy", "--linked-by": "linkedBy",
    "--no-linked-by": "noLinkedBy", "--related": "related", "--max-distance": "maxDistance",
    "--created": "created", "--created-before": "createdBefore", "--created-after": "createdAfter",
    "--modified": "modified", "--modified-before": "modifiedBefore", "--modified-after": "modifiedAfter",
    "-s": "sort", "--sort": "sort", "--notebook-dir": "notebookDir", "-W": "workingDir",
    "--working-dir": "workingDir"
  };
  for (let i = 0; i < rest.length; i++) {
    const a = rest[i];
    if (!a.startsWith("-") || a === "-") { o._.push(a); continue; }
    const eq = a.indexOf("=");
    const key = eq >= 0 ? a.slice(0, eq) : a;
    const val = eq >= 0 ? a.slice(eq + 1) : undefined;
    if (bools[key] && !(key in vals)) { o[bools[key]] = true; continue; }
    if (vals[key]) { o[vals[key]] = val !== undefined ? val : rest[++i]; continue; }
    fail(`unknown flag ${a}`);
  }
  return o;
}

function cwdFrom(global: Opts): string {
  return path.resolve(global.workingDir || process.cwd());
}

function findNotebook(global: Opts): string {
  if (global.notebookDir) {
    const nb = path.resolve(cwdFrom(global), global.notebookDir);
    if (fs.existsSync(path.join(nb, ".zk"))) return nb;
    fail(`failed to open notebook: no notebook found in ${nb} or a parent directory`);
  }
  let d = cwdFrom(global);
  while (true) {
    if (fs.existsSync(path.join(d, ".zk"))) return d;
    const p = path.dirname(d);
    if (p === d) break;
    d = p;
  }
  fail(`failed to open notebook: no notebook found in ${cwdFrom(global)} or a parent directory`);
}

function mkdirp(p: string) { fs.mkdirSync(p, { recursive: true }); }

function initNotebook(global: Opts, opts: Opts) {
  if (opts._.length > 1) fail(`unexpected argument ${opts._[1]}`);
  const dir = path.resolve(cwdFrom(global), opts._[0] || ".");
  mkdirp(path.join(dir, ".zk", "templates"));
  const config = path.join(dir, ".zk", "config.toml");
  if (!fs.existsSync(config)) fs.writeFileSync(config, defaultConfig(), "utf8");
  const tmpl = path.join(dir, ".zk", "templates", "default.md");
  if (!fs.existsSync(tmpl)) fs.writeFileSync(tmpl, "# {{title}}\n\n{{content}}\n", "utf8");
}

function defaultConfig(): string {
  return `# zk configuration file

[note]
template = "default.md"

[format.markdown]
link-format = "wiki"
hashtags = true
colon-tags = false
multiword-tags = false
`;
}

function randomId(): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let s = "";
  for (let i = 0; i < 4; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function readStdinIfPiped(): string {
  try {
    const st = fs.fstatSync(0);
    if (!st.isFIFO() && !st.isFile()) return "";
    return fs.readFileSync(0, "utf8");
  } catch { return ""; }
}

function createNote(global: Opts, opts: Opts) {
  if (opts._.length > 1) fail(`unexpected argument ${opts._[1]}`);
  const nb = findNotebook(global);
  const sub = opts._[0] || ".";
  const dir = path.resolve(nb, sub);
  if (!dir.startsWith(nb)) fail(`invalid note directory`);
  const id = opts.id || randomId();
  const title = opts.title || "Untitled";
  const input = opts.interactive ? readStdinIfPiped() : readStdinIfPiped();
  const templatePath = opts.template ? path.resolve(cwdFrom(global), opts.template) : path.join(nb, ".zk", "templates", "default.md");
  let template = "# {{title}}\n\n{{content}}\n";
  if (fs.existsSync(templatePath)) template = fs.readFileSync(templatePath, "utf8");
  const content = renderTemplate(template, { id, title, content: input.replace(/\s+$/g, ""), date: opts.date || today() });
  const rel = path.join(sub === "." ? "" : sub, `${id}.md`).replace(/\\/g, "/");
  const abs = path.join(nb, rel);
  if (opts.dryRun) {
    process.stdout.write(content);
    if (!content.endsWith("\n")) process.stdout.write("\n");
    process.stderr.write(rel + "\n");
    return;
  }
  mkdirp(path.dirname(abs));
  if (fs.existsSync(abs)) fail(`note already exists: ${rel}`);
  fs.writeFileSync(abs, content, "utf8");
  if (opts.printPath) stdout(rel);
  else {
    const editor = process.env.EDITOR || process.env.VISUAL;
    if (editor) child_process.spawnSync(editor, [abs], { stdio: "inherit", shell: true });
  }
}

function today(): string { return new Date().toISOString().slice(0, 10); }

function renderTemplate(t: string, vars: any): string {
  return t.replace(/\{\{\s*([^} ]+)\s*\}\}/g, (_: string, k: string) => String(vars[k] ?? ""));
}

function walk(dir: string, out: string[] = []): string[] {
  if (!fs.existsSync(dir)) return out;
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (ent.name === ".zk" || ent.name === ".git") continue;
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(p, out);
    else if (ent.isFile() && /\.(md|markdown|txt)$/i.test(ent.name)) out.push(p);
  }
  return out;
}

function parseNote(nb: string, abs: string): Note {
  const content = fs.readFileSync(abs, "utf8");
  const rel = path.relative(nb, abs).replace(/\\/g, "/");
  const titleMatch = content.match(/^\s*#\s+(.+?)\s*$/m);
  const tags = new Set<string>();
  for (const m of content.matchAll(/(^|[^\w])#([A-Za-z0-9_\/-]+)/g)) tags.add(m[2]);
  for (const m of content.matchAll(/:([A-Za-z0-9_\/-]+):/g)) tags.add(m[1]);
  const links: string[] = [];
  for (const m of content.matchAll(/\[\[([^\]|]+)(?:\|[^\]]*)?\]\]/g)) links.push(m[1]);
  for (const m of content.matchAll(/\[[^\]]+\]\(([^)]+)\)/g)) links.push(m[1]);
  const st = fs.statSync(abs);
  return { path: rel, abs, title: titleMatch ? titleMatch[1] : path.basename(rel, path.extname(rel)), content, tags: [...tags].sort(), created: st.birthtime, modified: st.mtime, links };
}

function allNotes(nb: string): Note[] {
  return walk(nb).map(p => parseNote(nb, p));
}

function csv(v: any): string[] {
  if (!v) return [];
  return String(v).split(",").map(x => x.trim()).filter(Boolean);
}

function filterNotes(notes: Note[], opts: Opts): Note[] {
  let ns = notes;
  if (opts._.length) {
    ns = ns.filter(n => opts._.some((p: string) => n.path === p || n.path.startsWith(p.replace(/\/+$/, "") + "/") || n.path.includes(p)));
  }
  for (const x of csv(opts.exclude)) ns = ns.filter(n => !(n.path === x || n.path.startsWith(x.replace(/\/+$/, "") + "/")));
  const tags = csv(opts.tag);
  if (tags.length) ns = ns.filter(n => tags.every(t => n.tags.includes(t.replace(/^#/, ""))));
  if (opts.tagless) ns = ns.filter(n => n.tags.length === 0);
  const matches = csv(opts.match);
  if (matches.length) {
    ns = ns.filter(n => matches.every(q => {
      if (opts.matchStrategy === "re") {
        try { return new RegExp(q, "i").test(n.content); } catch { return false; }
      }
      return n.content.toLowerCase().includes(q.toLowerCase()) || n.title.toLowerCase().includes(q.toLowerCase());
    }));
  }
  sortNotes(ns, opts.sort);
  const lim = opts.limit ? parseInt(opts.limit, 10) : 0;
  if (lim > 0) ns = ns.slice(0, lim);
  return ns;
}

function sortNotes(ns: Note[], spec: string) {
  const terms = csv(spec || "path");
  ns.sort((a, b) => {
    for (const raw of terms) {
      const desc = raw.endsWith("-");
      const t = raw.replace(/[+-]$/, "");
      let av: any = (a as any)[t] ?? (t === "filename" ? path.basename(a.path) : a.path);
      let bv: any = (b as any)[t] ?? (t === "filename" ? path.basename(b.path) : b.path);
      if (av instanceof Date) av = av.getTime();
      if (bv instanceof Date) bv = bv.getTime();
      const c = av < bv ? -1 : av > bv ? 1 : 0;
      if (c) return desc ? -c : c;
    }
    return 0;
  });
}

function noteObj(n: Note) {
  return { path: n.path, title: n.title, tags: n.tags, created: n.created.toISOString(), modified: n.modified.toISOString(), wordCount: n.content.trim() ? n.content.trim().split(/\s+/).length : 0 };
}

function formatNote(n: Note, fmt: string): string {
  if (!fmt || fmt === "oneline") return `${n.path}${n.title ? " " + n.title : ""}`;
  if (fmt === "path") return n.path;
  if (fmt === "title") return n.title;
  if (fmt === "short") return `${n.path}\t${n.title}`;
  if (fmt === "medium") return `${n.path}\n${n.title}`;
  if (fmt === "long" || fmt === "full") return `${n.path}\n# ${n.title}\n\n${n.content.trim()}`;
  return renderTemplate(fmt, { path: n.path, title: n.title, filename: path.basename(n.path), tags: n.tags.join(" "), content: n.content.trim() });
}

function listCommand(global: Opts, opts: Opts) {
  const nb = findNotebook(global);
  const notes = filterNotes(allNotes(nb), opts);
  const fmt = opts.format || "oneline";
  if (fmt === "json") { stdout(JSON.stringify(notes.map(noteObj), null, 2)); return; }
  if (fmt === "jsonl") { for (const n of notes) stdout(JSON.stringify(noteObj(n))); return; }
  const delim = opts.delimiter0 ? "\0" : opts.delimiter !== undefined ? decodeEsc(opts.delimiter) : "\n";
  if (opts.header) process.stdout.write(decodeEsc(opts.header));
  process.stdout.write(notes.map(n => formatNote(n, fmt)).join(delim));
  if (notes.length) process.stdout.write(delim === "\0" ? "\0" : "\n");
  if (opts.footer) process.stdout.write(decodeEsc(opts.footer));
}

function decodeEsc(s: string): string {
  return String(s).replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\0/g, "\0");
}

function tagList(global: Opts, opts: Opts) {
  const nb = findNotebook(global);
  const counts = new Map<string, number>();
  for (const n of allNotes(nb)) for (const t of n.tags) counts.set(t, (counts.get(t) || 0) + 1);
  let rows = [...counts.entries()].map(([name, count]) => ({ name, count }));
  rows.sort((a, b) => a.name.localeCompare(b.name));
  if (opts.sort && opts.sort.includes("count")) rows.sort((a, b) => (opts.sort.endsWith("-") ? b.count - a.count : a.count - b.count));
  const fmt = opts.format || "name";
  if (fmt === "json") { stdout(JSON.stringify(rows, null, 2)); return; }
  if (fmt === "jsonl") { for (const r of rows) stdout(JSON.stringify(r)); return; }
  const delim = opts.delimiter0 ? "\0" : opts.delimiter !== undefined ? decodeEsc(opts.delimiter) : "\n";
  const lines = rows.map(r => fmt === "full" ? `${r.name}\t${r.count}` : renderTemplate(fmt === "name" ? "{{name}}" : fmt, r));
  if (opts.header) process.stdout.write(decodeEsc(opts.header));
  process.stdout.write(lines.join(delim));
  if (lines.length) process.stdout.write(delim === "\0" ? "\0" : "\n");
  if (opts.footer) process.stdout.write(decodeEsc(opts.footer));
}

function graphCommand(global: Opts, opts: Opts) {
  if (!opts.format) fail("missing flags: --format=STRING");
  if (opts.format !== "json") fail(`invalid value "${opts.format}" for "--format"`);
  const nb = findNotebook(global);
  const notes = filterNotes(allNotes(nb), opts);
  const byStem = new Map<string, Note>();
  for (const n of allNotes(nb)) {
    byStem.set(path.basename(n.path, path.extname(n.path)), n);
    byStem.set(n.title, n);
    byStem.set(n.path, n);
  }
  const links: any[] = [];
  for (const n of notes) {
    for (const l of n.links) {
      const target = byStem.get(l) || byStem.get(l.replace(/\.(md|markdown|txt)$/i, ""));
      if (target) links.push({ source: n.path, target: target.path });
    }
  }
  stdout(JSON.stringify({ notes: notes.map(noteObj), links }, null, 2));
}

function editCommand(global: Opts, opts: Opts) {
  const nb = findNotebook(global);
  const notes = filterNotes(allNotes(nb), opts);
  if (!notes.length) return;
  const editor = process.env.EDITOR || process.env.VISUAL;
  if (!editor) fail("could not find editor, please set $EDITOR or $VISUAL");
  for (const n of notes) child_process.spawnSync(editor, [n.abs], { stdio: "inherit", shell: true });
}

function main() {
  const { global, cmd, rest } = parse(process.argv.slice(2));
  if (global.version) return stdout("zk dev");
  if (global.workingDir) process.chdir(cwdFrom(global));
  if (!cmd || global.help) return stdout(ROOT_HELP);
  const opts = parseCommand(rest);
  if (opts.notebookDir) global.notebookDir = opts.notebookDir;
  if (opts.workingDir) {
    global.workingDir = opts.workingDir;
    process.chdir(cwdFrom(global));
  }
  if (opts.noInput) global.noInput = true;
  if ((cmd === "list" || cmd === "graph" || cmd === "edit") && opts.title && !opts.tag) {
    opts.tag = opts.title;
    delete opts.title;
  }
  if (opts.help) {
    if (cmd === "tag" && opts._[0] === "list") return stdout(HELPS.tagList);
    return stdout(HELPS[cmd] || ROOT_HELP);
  }
  if (cmd === "init") return initNotebook(global, opts);
  if (cmd === "index") { findNotebook(global); if (!opts.quiet) stdout("0 notes indexed"); return; }
  if (cmd === "new") return createNote(global, opts);
  if (cmd === "list") return listCommand(global, opts);
  if (cmd === "graph") return graphCommand(global, opts);
  if (cmd === "edit") return editCommand(global, opts);
  if (cmd === "tag") {
    const sub = opts._.shift();
    if (!sub) { findNotebook(global); fail("missing command"); }
    if (sub === "list") return tagList(global, opts);
    fail(`unexpected argument ${sub}`);
  }
  fail(`unexpected argument ${cmd}`);
}

main();
