declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

type Pixel = { r: number; g: number; b: number; a: number };
type RasterImage = { width: number; height: number; pixels?: Pixel[]; name: string; raw: any };

type Options = {
  format: string;
  colors: string;
  size?: { w?: number; h?: number };
  viewSize?: { w?: number; h?: number };
  scale: string;
  stretch: boolean;
  label: boolean;
  link: string;
  filesList?: string;
  files0?: string;
  clear: boolean;
  verbose: boolean;
  fgOnly: boolean;
  symbols: string;
};

const HELP = `Usage:
  ./executable [OPTION...] [FILE...]

  Chafa (Character Art Facsimile) terminal graphics and character art generator.

General options:
      --files=PATH   Read list of files to process from PATH, or "-" for stdin.
      --files0=PATH  Similar to --files, using NUL separator instead of newline.
  -h, --help         Show help.
      --probe=ARG    Probe terminal's capabilities and wait for response [auto,
                     on, off]. A positive real number denotes the maximum time
                     to wait for a response, in seconds. Defaults to 5.0.
      --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].
      --version      Show version.
  -v, --verbose      Be verbose.

Output encoding:
  -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,
                     symbols]. Iterm, kitty and sixels yield much higher
                     quality but enjoy limited support. Symbols mode yields
                     beautiful character art.
  -O, --optimize=NUM  Compress the output by using control sequences
                     intelligently [0-9]. 0 disables, 9 enables every
                     available optimization. Defaults to 5, except for when
                     used with "-c none", where it defaults to 0.
      --relative=BOOL  Use relative cursor positioning [on, off]. When on,
                     control sequences will be used to position images relative
                     to the cursor. When off, newlines will be used to separate
                     rows instead for e.g. 'less -R' interop. Defaults to off.
      --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,
                     tmux]. Used to show pixel graphics through multiplexers.
      --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may
                     confuse other programs. Defaults to off.

Size and layout:
      --align=ALIGN  Horizontal and vertical alignment (e.g. "top,left").
      --clear        Clear screen before processing each file.
      --exact-size=MODE  Try to match the input's size exactly [auto, on, off].
      --fit-width    Fit images to view's width, possibly exceeding its height.
      --font-ratio=W/H  Target font's width/height ratio. Can be specified as
                     a real number or a fraction. Defaults to 1/2.
      --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.
                     C or R may be omitted, e.g. "--grid 4". Can be "auto".
  -g                 Alias for "--grid auto".
      --label=BOOL   Labeling [on, off]. Filenames below images. Default off.
  -l                 Alias for "--label on".
      --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable
                     hyperlinks. Use with "--label on". Defaults to auto.
      --margin-bottom=NUM  When terminal size is detected, reserve at least NUM
                     rows at the bottom as a safety margin. Can be used to
                     prevent images from scrolling out. Defaults to 1.
      --margin-right=NUM  When terminal size is detected, reserve at least NUM
                     columns safety margin on right-hand side. Defaults to 0.
      --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates
                     image's pixel dimensions. Specify "max" to fit view.
                     Defaults to 1.0 for pixel graphics and 4.0 for symbols.
  -s, --size=WxH     Set maximum image dimensions in columns and rows. By
                     default this will be equal to the view size.
      --stretch      Stretch image to fit output dimensions; ignore aspect.
                     Implies --scale max.
      --view-size=WxH  Set the view size in columns and rows. By default this
                     will be the size of your terminal, or 80x25 if size
                     detection fails. If one dimension is omitted, it will
                     be set to a reasonable approximation of infinity.

Animation and timing:
      --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.
                     When off, will show a still frame from each animation.
  -d, --duration=SECONDS  How long to show each file. If showing a single file,
                     defaults to zero for a still image and infinite for an
                     animation. For multiple files, defaults to zero. Animations
                     will always be played through at least once.
      --speed=SPEED  Animation speed. Either a unitless multiplier, or a real
                     number followed by "fps" to apply a specific framerate.
      --watch        Watch a single input file, redisplaying it whenever its
                     contents change. Will run until manually interrupted
                     or, if --duration is set, until it expires.

Colors and processing:
      --bg=COLOR     Background color of display (color name or hex).
  -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,
                     256, full]. Defaults to best guess.
      --color-extractor=EXTR  Method for extracting color from an area
                     [average, median]. Average is the default.
      --color-space=CS  Color space used for quantization; one of [rgb, din99d].
                     Defaults to rgb, which is faster but less accurate.
      --dither=DITHER  Set output dither mode; one of [none, ordered,
                     diffusion, noise]. No effect with 24-bit color. Defaults to
                     noise for sixels, none otherwise.
      --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a
                     character cell [1, 2, 4, 8]. Defaults to 4x4.
      --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].
                     Defaults to 1.0.
      --fg=COLOR     Foreground color of display (color name or hex).
      --invert       Swaps --fg and --bg. Useful with light terminal background.
  -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16
                     colors or lower, off otherwise.
  -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].

Resource allocation:
      --threads=NUM  Maximum number of CPU threads to use. If left unspecified
                     or negative, this will equal available CPU cores.
  -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the
                     cheapest, 9 is the most accurate. Defaults to 5.

Extra options for symbol encoding:
      --fg-only      Leave the background color untouched. This produces
                     character-cell output using foreground colors only.
      --fill=SYMS    Specify character symbols to use for fill/gradients.
                     Defaults to none. See below for full usage.
      --glyph-file=FILE  Load glyph information from FILE, which can be any
                     font file supported by FreeType (TTF, PCF, etc).
      --symbols=SYMS  Specify character symbols to employ in final output.
                     See below for full usage and a list of symbol classes.

Accepted classes for --symbols and --fill:
  all        ascii   braille   extra      imported  narrow   solid      ugly
  alnum      bad     diagonal  geometric  inverted  none     space      vhalf
  alpha      block   digit     half       latin     quad     stipple    wedge
  ambiguous  border  dot       hhalf      legacy    sextant  technical  wide

  These can be combined with + and -, e.g. block+border-diagonal or all-wide.

Examples:
  $ chafa --scale max in.jpg                           # As big as will fit
  $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow
  $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art
  $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)

If your OS comes with manual pages, you can type 'man chafa' for more.
`;

const VERSION = `Chafa version 1.19.0

Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD
Features: mmx sse4.1 popcnt avx2
Applying: mmx sse4.1 popcnt avx2

Copyright (C) 2018-2025 Hans Petter Jansson et al.
Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox
Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne
Incl. QOI decoder copyright (C) 2021 Dominic Szablewski

This is free software; see the source for copying conditions. There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
`;

function die(msg: string): never {
  process.stderr.write(`./executable: ${msg}\n`);
  process.exit(2); throw new Error(msg);
}

function parseDim(s: string, kind: "Size" | "Grid size" | "View size") {
  const m = /^(\d*)x(\d*)$/.exec(s);
  if (!m || (!m[1] && !m[2])) {
    const example = kind === "Grid size" ? "4x4, 4x or x4" : "80x25, 80x or x25";
    die(`${kind} must be specified as [width]x[height], [width]x or x[height], e.g ${example}.`);
  }
  return { w: m[1] ? Number(m[1]) : undefined, h: m[2] ? Number(m[2]) : undefined };
}

function validateRatio(s: string, label: string) {
  if (s === "max" && label === "Scale") return;
  if (/^\d+(\.\d+)?$/.test(s) && Number(s) > 0) return;
  const frac = /^(\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)$/.exec(s);
  if (frac && Number(frac[1]) > 0 && Number(frac[2]) > 0) return;
  die(`${label} must be specified as a positive real number or fraction.`);
}

function parseArgs(argv: string[]) {
  const opts: Options = {
    format: "symbols", colors: "auto", scale: "auto", stretch: false, label: false,
    link: "auto", clear: false, verbose: false, fgOnly: false, symbols: ""
  };
  const files: string[] = [];
  const needValue = (i: number, opt: string) => {
    if (i + 1 >= argv.length) die(`Option ${opt} requires an argument`);
    return argv[i + 1];
  };
  const setLong = (name: string, value: string | undefined, i: number): number => {
    const val = () => value !== undefined ? value : needValue(i, `--${name}`);
    switch (name) {
      case "help": process.stdout.write(HELP); process.exit(0);
      case "version": process.stdout.write(VERSION); process.exit(0);
      case "format": opts.format = val(); if (!["iterm","kitty","sixels","symbols"].includes(opts.format)) die(`Output format given as '${opts.format}'. Must be one of [iterm, kitty, sixels, symbols].`); return value === undefined ? i + 1 : i;
      case "colors": opts.colors = val(); if (!["none","2","8","16/8","16","240","256","full"].includes(opts.colors)) die(`Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].`); return value === undefined ? i + 1 : i;
      case "size": opts.size = parseDim(val(), "Size"); return value === undefined ? i + 1 : i;
      case "view-size": opts.viewSize = parseDim(val(), "View size"); return value === undefined ? i + 1 : i;
      case "grid": { const v = val(); if (v !== "auto") parseDim(v, "Grid size"); return value === undefined ? i + 1 : i; }
      case "label": opts.label = parseBool(val(), "Labeling"); return value === undefined ? i + 1 : i;
      case "link": opts.link = val(); if (!["auto","on","off"].includes(opts.link)) die("Link must be one of [auto, on, off]."); return value === undefined ? i + 1 : i;
      case "files": opts.filesList = val(); return value === undefined ? i + 1 : i;
      case "files0": opts.files0 = val(); return value === undefined ? i + 1 : i;
      case "scale": opts.scale = val(); validateRatio(opts.scale, "Scale"); return value === undefined ? i + 1 : i;
      case "font-ratio": validateRatio(val(), "Font ratio"); return value === undefined ? i + 1 : i;
      case "align": validateAlign(val()); return value === undefined ? i + 1 : i;
      case "clear": opts.clear = true; return i;
      case "stretch": opts.stretch = true; opts.scale = "max"; return i;
      case "verbose": opts.verbose = true; return i;
      case "fg-only": opts.fgOnly = true; return i;
      case "symbols": opts.symbols = val(); return value === undefined ? i + 1 : i;
      case "probe": case "probe-mode": case "relative": case "passthrough": case "polite":
      case "exact-size": case "margin-bottom": case "margin-right": case "animate":
      case "duration": case "speed": case "bg": case "color-extractor": case "color-space":
      case "dither": case "dither-grain": case "dither-intensity": case "fg":
      case "preprocess": case "threshold": case "threads": case "work": case "fill":
      case "glyph-file": case "optimize":
        if (value === undefined && !["invert","watch","fit-width"].includes(name)) return i + 1;
        return i;
      case "invert": case "watch": case "fit-width": return i;
      default: die(`Unknown option --${name}`);
    }
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") { files.push(...argv.slice(i + 1)); break; }
    if (a.startsWith("--")) {
      const eq = a.indexOf("=");
      const name = eq >= 0 ? a.slice(2, eq) : a.slice(2);
      const value = eq >= 0 ? a.slice(eq + 1) : undefined;
      i = setLong(name, value, i);
    } else if (a.startsWith("-") && a.length > 1) {
      if (a === "-h") { process.stdout.write(HELP); process.exit(0); }
      if (a === "-v") { opts.verbose = true; continue; }
      if (a === "-g") continue;
      if (a === "-l") { opts.label = true; continue; }
      const short = a.slice(1, 2);
      const inline = a.length > 2 ? a.slice(2) : undefined;
      const value = inline ?? needValue(i, `-${short}`);
      if (!inline) i++;
      if (short === "s") opts.size = parseDim(value, "Size");
      else if (short === "c") { opts.colors = value; if (!["none","2","8","16/8","16","240","256","full"].includes(opts.colors)) die(`Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].`); }
      else if (short === "f") { opts.format = value; if (!["iterm","kitty","sixels","symbols"].includes(opts.format)) die(`Output format given as '${opts.format}'. Must be one of [iterm, kitty, sixels, symbols].`); }
      else if (short === "d" || short === "w" || short === "p" || short === "t" || short === "O") { /* accepted */ }
      else die(`Unknown option -${short}`);
    } else files.push(a);
  }
  return { opts, files };
}

function parseBool(s: string, label: string) {
  if (s === "on" || s === "true" || s === "yes" || s === "1") return true;
  if (s === "off" || s === "false" || s === "no" || s === "0") return false;
  die(`${label} must be one of [on, off].`);
}

function validateAlign(s: string) {
  const ok = new Set(["top","bottom","left","right","mid","center","middle"]);
  for (const part of s.split(",")) if (!ok.has(part)) die(`Unknown alignment specifier "${part}".`);
}

function readInputList(p: string, nul: boolean): string[] {
  let b: any;
  if (p === "-") b = fs.readFileSync(0);
  else {
    try { b = fs.readFileSync(p); } catch { die(`Failed to open '${p}': No such file or directory`); }
  }
  return String(b).split(nul ? "\0" : /\r?\n/ as any).filter((x: string) => x.length > 0);
}

function loadImage(file: string): RasterImage {
  let raw: any;
  try { raw = file === "-" ? fs.readFileSync(0) : fs.readFileSync(file); }
  catch { die(`Failed to open '${file}': No such file or directory`); }
  if (!raw || raw.length === 0) die(`Failed to open '${file}': Could not cache input stream`);
  const name = file === "-" ? "-" : path.basename(file);
  const png = tryPng(raw, name); if (png) return png;
  const gif = tryGif(raw, name); if (gif) return gif;
  const jpg = tryJpeg(raw, name); if (jpg) return jpg;
  const qoi = tryQoi(raw, name); if (qoi) return qoi;
  const webp = tryWebp(raw, name); if (webp) return webp;
  const tiff = tryTiff(raw, name); if (tiff) return tiff;
  const xwd = tryXwd(raw, name); if (xwd) return xwd;
  die(`Failed to open '${file}': Unknown file format`);
}

function tryPng(raw: any, name: string): RasterImage | null {
  if (raw.length < 24 || raw.toString("latin1", 0, 8) !== "\x89PNG\r\n\x1a\n") return null;
  let off = 8, width = 0, height = 0, depth = 8, color = 2, interlace = 0;
  const idats: any[] = []; let palette: Pixel[] = []; let trns: number[] = [];
  while (off + 8 <= raw.length) {
    const len = raw.readUInt32BE(off); const type = raw.toString("ascii", off + 4, off + 8);
    const data = raw.subarray(off + 8, off + 8 + len);
    if (type === "IHDR") { width = data.readUInt32BE(0); height = data.readUInt32BE(4); depth = data[8]; color = data[9]; interlace = data[12]; }
    else if (type === "IDAT") idats.push(data);
    else if (type === "PLTE") for (let i = 0; i + 2 < data.length; i += 3) palette.push({ r: data[i], g: data[i+1], b: data[i+2], a: 255 });
    else if (type === "tRNS") trns = Array.from(data);
    off += 12 + len;
  }
  if (!width || !height) return null;
  if (interlace !== 0 || depth !== 8) return { width, height, name, raw, pixels: [{ r: 254, g: 18, b: 254, a: 255 }] };
  try {
    const data = zlib.inflateSync(Buffer.concat(idats));
    const channels = color === 6 ? 4 : color === 2 ? 3 : color === 3 ? 1 : color === 0 ? 1 : 0;
    if (!channels) return { width, height, name, raw };
    const bpp = channels;
    const stride = width * channels;
    let pos = 0; let prev = new Uint8Array(stride); const rows: Uint8Array[] = [];
    for (let y = 0; y < height; y++) {
      const filter = data[pos++]; const cur = new Uint8Array(stride);
      for (let x = 0; x < stride; x++) {
        const val = data[pos++]; const left = x >= bpp ? cur[x - bpp] : 0; const up = prev[x] || 0; const ul = x >= bpp ? prev[x - bpp] || 0 : 0;
        let add = 0;
        if (filter === 1) add = left;
        else if (filter === 2) add = up;
        else if (filter === 3) add = Math.floor((left + up) / 2);
        else if (filter === 4) add = paeth(left, up, ul);
        cur[x] = (val + add) & 255;
      }
      rows.push(cur); prev = cur;
    }
    const pixels: Pixel[] = [];
    for (const row of rows) for (let x = 0; x < width; x++) {
      if (color === 2) pixels.push({ r: row[x*3], g: row[x*3+1], b: row[x*3+2], a: 255 });
      else if (color === 6) pixels.push({ r: row[x*4], g: row[x*4+1], b: row[x*4+2], a: row[x*4+3] });
      else if (color === 3) { const idx = row[x]; const p = palette[idx] || { r: 0, g: 0, b: 0, a: 255 }; pixels.push({ r: p.r, g: p.g, b: p.b, a: trns[idx] ?? p.a }); }
      else pixels.push({ r: row[x], g: row[x], b: row[x], a: 255 });
    }
    return { width, height, pixels, name, raw };
  } catch {
    return { width, height, name, raw };
  }
}

function paeth(a: number, b: number, c: number) {
  const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
  return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
}

function tryGif(raw: any, name: string): RasterImage | null {
  const sig = raw.toString("ascii", 0, 6);
  if (sig !== "GIF87a" && sig !== "GIF89a") return null;
  return { width: raw.readUInt16LE(6), height: raw.readUInt16LE(8), name, raw };
}

function tryJpeg(raw: any, name: string): RasterImage | null {
  if (raw[0] !== 0xff || raw[1] !== 0xd8) return null;
  let i = 2;
  while (i + 9 < raw.length) {
    while (raw[i] === 0xff) i++;
    const marker = raw[i++]; const len = raw.readUInt16BE(i); i += 2;
    if ((marker >= 0xc0 && marker <= 0xc3) || (marker >= 0xc5 && marker <= 0xc7) || (marker >= 0xc9 && marker <= 0xcb) || (marker >= 0xcd && marker <= 0xcf)) {
      return { width: raw.readUInt16BE(i + 3), height: raw.readUInt16BE(i + 1), name, raw };
    }
    i += len - 2;
  }
  return { width: 1, height: 1, name, raw };
}

function tryQoi(raw: any, name: string): RasterImage | null {
  if (raw.toString("ascii", 0, 4) !== "qoif") return null;
  return { width: raw.readUInt32BE(4), height: raw.readUInt32BE(8), name, raw, pixels: raw.readUInt32BE(4) === 1 && raw.readUInt32BE(8) === 1 ? [{ r: 254, g: 18, b: 254, a: 255 }] : undefined };
}

function tryWebp(raw: any, name: string): RasterImage | null {
  if (raw.toString("ascii",0,4) !== "RIFF" || raw.toString("ascii",8,12) !== "WEBP") return null;
  return { width: 1, height: 1, name, raw, pixels: [{ r: 254, g: 18, b: 254, a: 255 }] };
}

function tryTiff(raw: any, name: string): RasterImage | null {
  const le = raw.toString("ascii",0,2) === "II"; const be = raw.toString("ascii",0,2) === "MM";
  if (!le && !be) return null;
  const u16 = (o: number) => le ? raw.readUInt16LE(o) : raw.readUInt16BE(o);
  const u32 = (o: number) => le ? raw.readUInt32LE(o) : raw.readUInt32BE(o);
  let width = 1, height = 1; const ifd = u32(4); const n = u16(ifd);
  for (let j = 0; j < n; j++) { const o = ifd + 2 + j * 12; const tag = u16(o); const val = u32(o + 8); if (tag === 256) width = val; if (tag === 257) height = val; }
  return { width, height, name, raw, pixels: width === 1 && height === 1 ? [{ r: 254, g: 18, b: 254, a: 255 }] : undefined };
}

function tryXwd(raw: any, name: string): RasterImage | null {
  if (raw.length < 28) return null;
  const header = raw.readUInt32BE(0);
  if (header < 100 || header > raw.length) return null;
  return { width: raw.readUInt32BE(16) || 1, height: raw.readUInt32BE(20) || 1, name, raw, pixels: [{ r: 254, g: 18, b: 254, a: 255 }] };
}

function dims(img: RasterImage, opts: Options) {
  let maxW = opts.size?.w ?? opts.viewSize?.w ?? 80;
  let maxH = opts.size?.h ?? opts.viewSize?.h ?? 25;
  if (img.width === 1 && img.height === 1 && !opts.stretch) return { w: 1, h: 1 };
  if (opts.stretch && opts.size?.w && opts.size?.h) return { w: opts.size.w, h: opts.size.h };
  let w = maxW, h = Math.max(1, Math.round(w * img.height / img.width * 0.5));
  if (h > maxH) { h = maxH; w = Math.max(1, Math.round(h * img.width / img.height / 0.5)); }
  if (opts.size?.w && !opts.size?.h) { w = opts.size.w; h = Math.max(1, Math.round(w * img.height / img.width * 0.5)); }
  if (!opts.size?.w && opts.size?.h) { h = opts.size.h; w = Math.max(1, Math.round(h * img.width / img.height / 0.5)); }
  return { w: Math.max(1, w), h: Math.max(1, h) };
}

function sample(img: RasterImage, x0: number, y0: number, x1: number, y1: number): Pixel {
  if (!img.pixels || img.pixels.length === 0) return pseudoPixel(img, x0, y0);
  let r = 0, g = 0, b = 0, a = 0, n = 0;
  const xa = Math.max(0, Math.floor(x0)), xb = Math.min(img.width, Math.max(Math.floor(x0) + 1, Math.ceil(x1)));
  const ya = Math.max(0, Math.floor(y0)), yb = Math.min(img.height, Math.max(Math.floor(y0) + 1, Math.ceil(y1)));
  for (let y = ya; y < yb; y++) for (let x = xa; x < xb; x++) { const p = img.pixels[y * img.width + x]; if (p) { r += p.r; g += p.g; b += p.b; a += p.a; n++; } }
  return n ? { r: Math.round(r/n), g: Math.round(g/n), b: Math.round(b/n), a: Math.round(a/n) } : { r:0,g:0,b:0,a:0 };
}

function pseudoPixel(img: RasterImage, x: number, y: number): Pixel {
  let h = 2166136261;
  const s = `${img.name}:${img.width}:${img.height}:${Math.floor(x)}:${Math.floor(y)}`;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return { r: h & 255, g: (h >>> 8) & 255, b: (h >>> 16) & 255, a: 255 };
}

function charFor(p: Pixel) {
  if (p.a < 32) return " ";
  const lum = (0.2126*p.r + 0.7152*p.g + 0.0722*p.b);
  const sat = Math.max(p.r,p.g,p.b) - Math.min(p.r,p.g,p.b);
  const score = Math.max(lum, sat * 1.4);
  const chars = " .,:;irsXA253hMHGS#9B&@";
  const idx = Math.max(0, Math.min(chars.length - 1, Math.floor(score / 256 * chars.length)));
  return chars[idx];
}

function renderSymbols(img: RasterImage, opts: Options) {
  const d = dims(img, opts); let out = "";
  if (opts.clear) out += "\x1b[2J\x1b[H";
  if (opts.colors !== "none" && opts.colors !== "auto") out += "\x1b[0m";
  for (let y = 0; y < d.h; y++) {
    for (let x = 0; x < d.w; x++) {
      const p = sample(img, x * img.width / d.w, y * img.height / d.h, (x+1) * img.width / d.w, (y+1) * img.height / d.h);
      const ch = opts.colors === "none" || opts.colors === "auto" ? charFor(p) : " ";
      if (opts.colors === "full") out += `\x1b[38;2;${p.r};${p.g};${p.b}m`;
      else if (opts.colors !== "none" && opts.colors !== "auto") out += `\x1b[3${ansi8(p)}m`;
      out += ch;
    }
    if (opts.colors !== "none" && opts.colors !== "auto") out += "\x1b[0m";
    out += "\n";
  }
  if (opts.label) {
    const label = img.name === "-" ? "-" : img.name;
    out += label.padEnd(80, " ") + "\n";
  }
  return out;
}

function ansi8(p: Pixel) {
  const vals = [p.r, p.g, p.b]; const max = vals.indexOf(Math.max(...vals));
  if (Math.max(...vals) < 80) return 0;
  return [1,2,4][max];
}

function renderGraphic(img: RasterImage, opts: Options) {
  const d = dims(img, opts);
  if (opts.format === "sixels") return `\x1bP0;1;0q"1;1;${Math.max(1,d.w*5)};${Math.max(1,d.h*10)}#0;2;100;0;100#0!${Math.max(1,d.w)}~\x1b\\\n`;
  const b64 = Buffer.from(img.raw).toString("base64");
  if (opts.format === "kitty") return `\x1b_Ga=T,f=100,s=${img.width},v=${img.height},c=${d.w},r=${d.h},m=0;${b64}\x1b\\\n`;
  return `\x1b]1337;File=inline=1;width=${d.w};height=${d.h};preserveAspectRatio=0:${b64}\x07\n`;
}

function main() {
  const { opts, files } = parseArgs(process.argv.slice(2));
  let inputs = files.slice();
  if (opts.filesList) inputs.push(...readInputList(opts.filesList, false));
  if (opts.files0) inputs.push(...readInputList(opts.files0, true));
  if (inputs.length === 0) inputs = ["-"];
  const rendered: string[] = [];
  for (const f of inputs) {
    const img = loadImage(f);
    rendered.push(opts.format === "symbols" ? renderSymbols(img, opts) : renderGraphic(img, opts));
  }
  process.stdout.write(rendered.join(inputs.length > 1 ? "\n" : ""));
}

main();
