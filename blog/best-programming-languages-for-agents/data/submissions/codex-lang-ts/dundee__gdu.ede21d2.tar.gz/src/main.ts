declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");
const child_process = require("child_process");

type Opts = {
  paths: string[];
  nonInteractive: boolean;
  noProgress: boolean;
  summarize: boolean;
  apparent: boolean;
  noPrefix: boolean;
  si: boolean;
  kib: boolean;
  reverse: boolean;
  top: number;
  depth: number;
  noHidden: boolean;
  followSymlinks: boolean;
  type: Set<string> | null;
  excludeType: Set<string>;
  ignoreDirs: string[];
  ignorePatterns: RegExp[];
  inputFile: string | null;
  outputFile: string | null;
  minMtime: number | null;
  maxMtime: number | null;
  showDisks: boolean;
  help: boolean;
  version: boolean;
  writeConfig: boolean;
  configFile: string | null;
};

type NodeInfo = {
  name: string;
  abs: string;
  isDir: boolean;
  isSymlink: boolean;
  empty: boolean;
  asize: number;
  dsize: number;
  mtime: number;
  children: NodeInfo[];
};

const VERSION = `Version:\t dev
Built time:\t Fri Apr 17 19:59:35 UTC 2026
Built user:\t root`;

function cpuCount(): number {
  try {
    const os = require("os");
    return os.cpus().length || 1;
  } catch {
    return 1;
  }
}

function help(): string {
  const n = cpuCount();
  return `Pretty fast disk usage analyzer written in Go.

Gdu is intended primarily for SSD disks where it can fully utilize parallel processing.
However HDDs work as well, but the performance gain is not so huge.

Usage:
  gdu [directory_to_scan] [flags]

Flags:
      --archive-browsing              Enable browsing of zip/jar archives
      --collapse-path                 Collapse single-child directory chains
      --config-file string            Read config from file (default is $HOME/.gdu.yaml)
  -D, --db string                     Store analysis in database (*.sqlite for SQLite, *.badger for BadgerDB)
      --depth int                     Show directory structure up to specified depth in non-interactive mode (0 means the flag is ignored)
      --enable-profiling              Enable collection of profiling data and provide it on http://localhost:6060/debug/pprof/
  -E, --exclude-type strings          File types to exclude (e.g., --exclude-type yaml,json)
  -L, --follow-symlinks               Follow symlinks for files, i.e. show the size of the file to which symlink points to (symlinks to directories are not followed)
  -h, --help                          help for gdu
  -i, --ignore-dirs strings           Paths to ignore (separated by comma). Can be absolute or relative to current directory (default [/proc,/dev,/sys,/run])
  -I, --ignore-dirs-pattern strings   Path patterns to ignore (separated by comma)
  -X, --ignore-from string            Read path patterns to ignore from file
  -f, --input-file string             Import analysis from JSON file
  -l, --log-file string               Path to a logfile (default "/dev/null")
      --max-age string                Include files with mtime no older than DURATION (e.g., 7d, 2h30m, 1y2mo)
  -m, --max-cores int                 Set max cores that Gdu will use. ${n} cores available (default ${n})
      --min-age string                Include files with mtime at least DURATION old (e.g., 30d, 1w)
      --mouse                         Use mouse
  -c, --no-color                      Do not use colorized output
  -x, --no-cross                      Do not cross filesystem boundaries
      --no-delete                     Do not allow deletions
  -H, --no-hidden                     Ignore hidden directories (beginning with dot)
      --no-prefix                     Show sizes as raw numbers without any prefixes (SI or binary) in non-interactive mode
  -p, --no-progress                   Do not show progress in non-interactive mode
      --no-spawn-shell                Do not allow spawning shell
  -u, --no-unicode                    Do not use Unicode symbols (for size bar)
  -n, --non-interactive               Do not run in interactive mode
  -o, --output-file string            Export all info into file as JSON
  -r, --read-from-storage             Use existing database instead of re-scanning
      --reverse-sort                  Reverse sorting order (smallest to largest) in non-interactive mode
      --sequential                    Use sequential scanning (intended for rotating HDDs)
  -A, --show-annexed-size             Use apparent size of git-annex'ed files in case files are not present locally (real usage is zero)
  -a, --show-apparent-size            Show apparent size
  -d, --show-disks                    Show all mounted disks
  -k, --show-in-kib                   Show sizes in KiB (or kB with --si) in non-interactive mode
  -C, --show-item-count               Show number of items in directory
  -M, --show-mtime                    Show latest mtime of items in directory
  -B, --show-relative-size            Show relative size
      --si                            Show sizes with decimal SI prefixes (kB, MB, GB) instead of binary prefixes (KiB, MiB, GiB)
      --since string                  Include files with mtime >= WHEN. WHEN accepts RFC3339 timestamp (e.g., 2025-08-11T01:00:00-07:00) or date only YYYY-MM-DD (calendar-day compare; includes the whole day)
  -s, --summarize                     Show only a total in non-interactive mode
  -t, --top int                       Show only top X largest files in non-interactive mode
  -T, --type strings                  File types to include (e.g., --type yaml,json)
      --until string                  Include files with mtime <= WHEN. WHEN accepts RFC3339 timestamp or date only YYYY-MM-DD
  -v, --version                       Print version
      --write-config                  Write current configuration to file`;
}

function defaultOpts(): Opts {
  return {
    paths: [],
    nonInteractive: false,
    noProgress: false,
    summarize: false,
    apparent: false,
    noPrefix: false,
    si: false,
    kib: false,
    reverse: false,
    top: 0,
    depth: 0,
    noHidden: false,
    followSymlinks: false,
    type: null,
    excludeType: new Set(),
    ignoreDirs: ["/proc", "/dev", "/sys", "/run"],
    ignorePatterns: [],
    inputFile: null,
    outputFile: null,
    minMtime: null,
    maxMtime: null,
    showDisks: false,
    help: false,
    version: false,
    writeConfig: false,
    configFile: null
  };
}

const needsValue: Record<string, keyof Opts | "ignoreFrom" | "noop"> = {
  "--depth": "depth",
  "--top": "top",
  "--type": "type",
  "--exclude-type": "excludeType",
  "--ignore-dirs": "ignoreDirs",
  "--ignore-dirs-pattern": "ignorePatterns",
  "--ignore-from": "ignoreFrom",
  "--input-file": "inputFile",
  "--output-file": "outputFile",
  "--config-file": "configFile",
  "--db": "noop",
  "--log-file": "noop",
  "--max-cores": "noop",
  "--max-age": "noop",
  "--min-age": "noop",
  "--since": "noop",
  "--until": "noop",
  "--storage": "noop",
  "--style": "noop"
};

function splitList(s: string): string[] {
  return s.split(",").map(x => x.trim()).filter(Boolean);
}

function setValue(opts: Opts, key: keyof Opts | "ignoreFrom" | "noop", value: string) {
  if (key === "noop") return;
  if (key === "depth" || key === "top") (opts as any)[key] = parseInt(value, 10) || 0;
  else if (key === "type") opts.type = new Set(splitList(value).map(normExt));
  else if (key === "excludeType") splitList(value).map(normExt).forEach(x => opts.excludeType.add(x));
  else if (key === "ignoreDirs") opts.ignoreDirs = splitList(value);
  else if (key === "ignorePatterns") opts.ignorePatterns.push(...splitList(value).map(x => new RegExp(x)));
  else if (key === "ignoreFrom") {
    try {
      const lines = fs.readFileSync(value, "utf8").split(/\r?\n/).map((x: string) => x.trim()).filter(Boolean);
      opts.ignorePatterns.push(...lines.map((x: string) => new RegExp(x)));
    } catch {}
  } else (opts as any)[key] = value;
}

function parseDurationSeconds(s: string): number {
  const re = /(\d+(?:\.\d+)?)(y|mo|w|d|h|m|s)/g;
  let total = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s)) !== null) {
    const v = parseFloat(m[1]);
    const u = m[2];
    if (u === "y") total += v * 365 * 86400;
    else if (u === "mo") total += v * 30 * 86400;
    else if (u === "w") total += v * 7 * 86400;
    else if (u === "d") total += v * 86400;
    else if (u === "h") total += v * 3600;
    else if (u === "m") total += v * 60;
    else total += v;
  }
  return total || (parseFloat(s) || 0);
}

function parseWhenStart(s: string): number {
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return Math.floor(new Date(`${s}T00:00:00`).getTime() / 1000);
  return Math.floor(new Date(s).getTime() / 1000);
}

function parseWhenEnd(s: string): number {
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return Math.floor(new Date(`${s}T23:59:59.999`).getTime() / 1000);
  return Math.floor(new Date(s).getTime() / 1000);
}

function parseArgs(argv: string[]): Opts {
  const opts = defaultOpts();
  const shortVal: Record<string, keyof Opts | "ignoreFrom" | "noop"> = {
    D: "noop", E: "excludeType", i: "ignoreDirs", I: "ignorePatterns", X: "ignoreFrom",
    f: "inputFile", l: "noop", m: "noop", o: "outputFile", t: "top", T: "type"
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") { opts.paths.push(...argv.slice(i + 1)); break; }
    if (a.startsWith("--")) {
      const eq = a.indexOf("=");
      const name = eq >= 0 ? a.slice(0, eq) : a;
      const val = eq >= 0 ? a.slice(eq + 1) : null;
      if (name === "--max-age") opts.minMtime = Math.floor(Date.now() / 1000 - parseDurationSeconds(val ?? argv[++i] ?? ""));
      else if (name === "--min-age") opts.maxMtime = Math.floor(Date.now() / 1000 - parseDurationSeconds(val ?? argv[++i] ?? ""));
      else if (name === "--since") opts.minMtime = parseWhenStart(val ?? argv[++i] ?? "");
      else if (name === "--until") opts.maxMtime = parseWhenEnd(val ?? argv[++i] ?? "");
      else if (name in needsValue) setValue(opts, needsValue[name], val ?? argv[++i] ?? "");
      else if (name === "--help") opts.help = true;
      else if (name === "--version") opts.version = true;
      else if (name === "--non-interactive") opts.nonInteractive = true;
      else if (name === "--no-progress") opts.noProgress = true;
      else if (name === "--summarize") opts.summarize = true;
      else if (name === "--show-apparent-size") opts.apparent = true;
      else if (name === "--no-prefix") opts.noPrefix = true;
      else if (name === "--si") opts.si = true;
      else if (name === "--show-in-kib") opts.kib = true;
      else if (name === "--reverse-sort") opts.reverse = true;
      else if (name === "--no-hidden") opts.noHidden = true;
      else if (name === "--follow-symlinks") opts.followSymlinks = true;
      else if (name === "--show-disks") opts.showDisks = true;
      else if (name === "--write-config") opts.writeConfig = true;
      else if (["--archive-browsing","--collapse-path","--enable-profiling","--mouse","--no-color","--no-cross","--no-delete","--no-spawn-shell","--no-unicode","--read-from-storage","--sequential","--show-annexed-size","--show-item-count","--show-mtime","--show-relative-size","--shared","--use-git-ignore"].includes(name)) {}
      else throw new Error(`unknown flag: ${name}`);
    } else if (a.startsWith("-") && a.length > 1) {
      const chars = a.slice(1).split("");
      for (let ci = 0; ci < chars.length; ci++) {
        const c = chars[ci];
        if (shortVal[c]) {
          const rest = chars.slice(ci + 1).join("");
          setValue(opts, shortVal[c], rest || argv[++i] || "");
          break;
        }
        if (c === "h") opts.help = true;
        else if (c === "v") opts.version = true;
        else if (c === "n") opts.nonInteractive = true;
        else if (c === "p") opts.noProgress = true;
        else if (c === "s") opts.summarize = true;
        else if (c === "a") opts.apparent = true;
        else if (c === "k") opts.kib = true;
        else if (c === "H") opts.noHidden = true;
        else if (c === "L") opts.followSymlinks = true;
        else if (c === "d") opts.showDisks = true;
        else if (["c","x","u","A","C","M","B","r","g"].includes(c)) {}
        else throw new Error(`unknown shorthand flag: '${c}' in -${chars.join("")}`);
      }
    } else opts.paths.push(a);
  }
  return opts;
}

function normExt(s: string): string {
  return s.replace(/^\./, "").toLowerCase();
}

function fileExt(name: string): string {
  const b = path.basename(name);
  const i = b.lastIndexOf(".");
  return i >= 0 ? b.slice(i + 1).toLowerCase() : "";
}

function diskSize(st: any): number {
  if (typeof st.blocks === "number") return st.blocks * 512;
  if (st.size === 0) return 0;
  return Math.ceil(st.size / 4096) * 4096;
}

function shouldIgnore(abs: string, root: string, name: string, isDir: boolean, opts: Opts): boolean {
  if (opts.noHidden && isDir && name.startsWith(".") && abs !== root) return true;
  const rel = path.relative(root, abs);
  for (const ig of opts.ignoreDirs) {
    const full = path.isAbsolute(ig) ? ig : path.join(root, ig);
    if (abs === full || abs.startsWith(full + path.sep) || rel === ig || rel.startsWith(ig + path.sep)) return true;
  }
  for (const re of opts.ignorePatterns) if (re.test(abs) || re.test(rel)) return true;
  return false;
}

function fileAllowed(abs: string, opts: Opts): boolean {
  const ext = normExt(fileExt(abs));
  if (opts.type && !opts.type.has(ext)) return false;
  if (opts.excludeType.has(ext)) return false;
  return true;
}

function timeAllowed(mtime: number, opts: Opts): boolean {
  if (opts.minMtime !== null && mtime < opts.minMtime) return false;
  if (opts.maxMtime !== null && mtime > opts.maxMtime) return false;
  return true;
}

function scan(abs: string, root: string, opts: Opts): NodeInfo | null {
  const lst = fs.lstatSync(abs);
  let st = lst;
  let isSymlink = lst.isSymbolicLink();
  let isDir = lst.isDirectory();
  if (isSymlink && opts.followSymlinks) {
    try {
      const real = fs.statSync(abs);
      if (!real.isDirectory()) {
        st = real;
        isDir = false;
        isSymlink = false;
      }
    } catch {}
  }
  const name = path.basename(abs);
  if (shouldIgnore(abs, root, name, isDir, opts)) return null;
  if (!isDir && !isSymlink && (!fileAllowed(abs, opts) || !timeAllowed(Math.floor(st.mtimeMs / 1000), opts))) return null;
  if (isSymlink && opts.type) return null;

  const node: NodeInfo = {
    name,
    abs,
    isDir,
    isSymlink,
    empty: false,
    asize: st.size || 0,
    dsize: isSymlink && !opts.followSymlinks ? 0 : diskSize(st),
    mtime: Math.floor(st.mtimeMs / 1000),
    children: []
  };
  if (isDir) {
    let entries: string[] = [];
    try { entries = fs.readdirSync(abs); } catch {}
    for (const ent of entries) {
      const child = scan(path.join(abs, ent), root, opts);
      if (child) {
        node.children.push(child);
        node.asize += child.asize;
        node.dsize += child.dsize;
        if (child.mtime > node.mtime) node.mtime = child.mtime;
      }
    }
    node.empty = node.children.length === 0;
  }
  return node;
}

function sortNodes(nodes: NodeInfo[], opts: Opts): NodeInfo[] {
  const mul = opts.reverse ? -1 : 1;
  return nodes.slice().sort((a, b) => {
    const sa = opts.apparent ? a.asize : a.dsize;
    const sb = opts.apparent ? b.asize : b.dsize;
    if (sa !== sb) return (sb - sa) * mul;
    return 0;
  });
}

function sizeOf(n: NodeInfo, opts: Opts): number {
  return opts.apparent ? n.asize : n.dsize;
}

function fmtSize(size: number, opts: Opts): string {
  if (opts.noPrefix) return String(size).padStart(10);
  if (opts.kib) {
    const unit = opts.si ? "kB" : "KiB";
    return `${(size / 1024).toFixed(1).padStart(6)} ${unit}`;
  }
  const base = opts.si ? 1000 : 1024;
  const units = opts.si ? ["B", "kB", "MB", "GB", "TB", "PB"] : ["B", "KiB", "MiB", "GiB", "TiB", "PiB"];
  let v = size;
  let u = 0;
  while (Math.abs(v) >= base && u < units.length - 1) { v /= base; u++; }
  if (u === 0) return `${String(Math.round(v)).padStart(7)} ${units[u]}`;
  return `${v.toFixed(1).padStart(6)} ${units[u]}`;
}

function lineFor(n: NodeInfo, displayName: string, opts: Opts): string {
  const flag = n.isSymlink ? "@" : (n.isDir && n.empty ? "e" : " ");
  return `${flag}${fmtSize(sizeOf(n, opts), opts)} ${displayName}`;
}

function childName(n: NodeInfo): string {
  return n.isDir ? `/${n.name}` : n.name;
}

function flatten(n: NodeInfo, depth = 0): Array<{n: NodeInfo, depth: number}> {
  let out = [{n, depth}];
  for (const c of n.children) out = out.concat(flatten(c, depth + 1));
  return out;
}

function printListing(root: NodeInfo, opts: Opts): string {
  if (opts.summarize) return ` ${fmtSize(sizeOf(root, opts), opts)} ${root.name}`;
  if (opts.top > 0) {
    const files = flatten(root).filter(x => !x.n.isDir).map(x => x.n);
    return sortNodes(files, opts).slice(0, opts.top).map(n => lineFor(n, n.abs, opts)).join("\n");
  }
  if (opts.depth > 0) {
    const rows: string[] = [];
    const walk = (n: NodeInfo, level: number) => {
      if (level > opts.depth) return;
      rows.push(lineFor(n, n.abs, opts));
      if (level < opts.depth) for (const c of sortNodes(n.children, opts)) walk(c, level + 1);
    };
    walk(root, 0);
    return rows.join("\n");
  }
  const rows = sortNodes(root.children, opts).map(c => lineFor(c, childName(c), opts));
  return rows.join("\n");
}

function toJsonNode(n: NodeInfo): any {
  const meta: any = { name: n.abs };
  if (n.abs !== n.name) meta.name = n.name;
  meta.mtime = n.mtime;
  if (!n.isDir) {
    meta.asize = n.asize;
    if (n.dsize) meta.dsize = n.dsize;
    if (n.isSymlink) meta.notreg = true;
    return meta;
  }
  return [{ name: n.name, mtime: n.mtime }, ...n.children.map(toJsonNode)];
}

function exportJson(root: NodeInfo): string {
  const tree = [{ name: root.abs, mtime: root.mtime }, ...root.children.map(toJsonNode)];
  return JSON.stringify([1, 2, { progname: "gdu", progver: "dev", timestamp: Math.floor(Date.now() / 1000) }, tree]);
}

function fromJson(x: any, parent: string = ""): NodeInfo {
  if (Array.isArray(x)) {
    const meta = x[0] || {};
    const abs = path.isAbsolute(meta.name) ? meta.name : path.join(parent, meta.name || "");
    const n: NodeInfo = { name: meta.name || path.basename(abs), abs, isDir: true, isSymlink: false, empty: false, asize: 0, dsize: 0, mtime: meta.mtime || 0, children: [] };
    for (let i = 1; i < x.length; i++) {
      const c = fromJson(x[i], abs);
      n.children.push(c);
      n.asize += c.asize;
      n.dsize += c.dsize;
    }
    n.empty = n.children.length === 0;
    return n;
  }
  const abs = path.isAbsolute(x.name) ? x.name : path.join(parent, x.name || "");
  return { name: x.name || path.basename(abs), abs, isDir: false, isSymlink: !!x.notreg, empty: false, asize: x.asize || 0, dsize: x.dsize || 0, mtime: x.mtime || 0, children: [] };
}

function showDisks() {
  console.log("   Device      Size      Used      Free Used% Mount point");
  try {
    const out = child_process.execFileSync("df", ["-hP"], { encoding: "utf8" }).trim().split(/\r?\n/).slice(1);
    for (const line of out) {
      const p = line.trim().split(/\s+/);
      if (p.length >= 6) console.log(`${p[0].padStart(9)} ${p[1].padStart(9)} ${p[2].padStart(9)} ${p[3].padStart(9)} ${p[4].padStart(5)} ${p.slice(5).join(" ")}`);
    }
  } catch {}
}

function main() {
  let opts: Opts;
  try { opts = parseArgs(process.argv.slice(2)); }
  catch (e: any) { console.error(`Error: ${e.message}`); process.exit(1); return; }
  if (opts.help) { console.log(help()); return; }
  if (opts.version) { console.log(VERSION); return; }
  if (opts.showDisks && opts.paths.length === 0) { showDisks(); return; }
  if (opts.writeConfig) {
    const file = opts.configFile || path.join(process.env.HOME || ".", ".gdu.yaml");
    fs.writeFileSync(file, "no-color: false\nno-progress: false\n");
    return;
  }
  let root: NodeInfo;
  try {
    if (opts.inputFile) {
      const parsed = JSON.parse(fs.readFileSync(opts.inputFile, "utf8"));
      root = fromJson(parsed[3]);
    } else {
      const target = path.resolve(opts.paths[0] || ".");
      root = scan(target, target, opts)!;
    }
  } catch (e: any) {
    console.error(`Error: ${e.message}`);
    process.exit(1);
    return;
  }
  if (!root) { console.error("Error: no data"); process.exit(1); return; }
  if (opts.outputFile) fs.writeFileSync(opts.outputFile, exportJson(root));
  const out = printListing(root, opts);
  if (out) console.log(out);
}

main();
