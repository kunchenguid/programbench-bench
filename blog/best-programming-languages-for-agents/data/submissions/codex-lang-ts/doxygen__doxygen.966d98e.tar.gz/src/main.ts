declare const require: any;
declare const process: any;
declare const __dirname: string;

const fs = require("fs");
const path = require("path");

const VERSION = "1.17.0 (9135bd68ddc9ea65023d967c75048a7a86a5d495)";
const SHORT_VERSION = VERSION;

function prog(): string {
  if (process.env && process.env.DOXYGEN_ARGV0) return process.env.DOXYGEN_ARGV0;
  const p = process.argv[1] || "doxygen";
  return p.includes("/") ? p : `./${p}`;
}

function templatePath(name: string): string {
  return path.join(__dirname, "..", "templates", name);
}

function readTemplate(name: string): string {
  return fs.readFileSync(templatePath(name), "utf8");
}

function writeFile(name: string, content: string): void {
  if (name === "-") {
    process.stdout.write(content);
  } else {
    fs.writeFileSync(name, content);
  }
}

function helpText(): string {
  const p = prog();
  return `Doxygen version ${VERSION}
Copyright Dimitri van Heesch 1997-2025

You can use Doxygen in a number of ways:

1) Use Doxygen to generate a template configuration file*:
    ${p} [-s] -g [configName]

2) Use Doxygen to update an old configuration file*:
    ${p} [-s] -u [configName]

3) Use Doxygen to generate documentation using an existing configuration file*:
    ${p} [configName]

4) Use Doxygen to generate a template file controlling the layout of the
   generated documentation:
    ${p} -l [layoutFileName]

    In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.
    If - is used for layoutFileName Doxygen will write to standard output.

5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.
    RTF:        ${p} -w rtf styleSheetFile
    HTML:       ${p} -w html headerFile footerFile styleSheetFile [configFile]
    LaTeX:      ${p} -w latex headerFile footerFile styleSheetFile [configFile]

6) Use Doxygen to generate a rtf extensions file
    ${p} -e rtf extensionsFile

    If - is used for extensionsFile Doxygen will write to standard output.

7) Use Doxygen to compare the used configuration file with the template configuration file
    ${p} -x [configFile]

   Use Doxygen to compare the used configuration file with the template configuration file
   without replacing the environment variables or CMake type replacement variables
    ${p} -x_noenv [configFile]

8) Use Doxygen to show a list of built-in emojis.
    ${p} -f emoji outputFileName

    If - is used for outputFileName Doxygen will write to standard output.

*) If -s is specified the comments of the configuration items in the config file will be omitted.
   If configName is omitted 'Doxyfile' will be used as a default.
   If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.

If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.

-v print version string, -V print extended version information
-h,-? prints usage help information
${p} -d prints additional usage flags for debugging purposes
`;
}

function debugText(): string {
  return `Developer parameters:
  -m          dump symbol map
  -b          making messages output unbuffered
  -c <file>   process input file as a comment block and produce HTML output
  -d <level>  enable a debug level, such as (multiple invocations of -d are possible):
\talias
\tcite
\tcommentcnv
\tcommentscan
\tentries
\textcmd
\tfilteroutput
\tformula
\tfortranfixed2free
\tlayout
\tlex
\tlex:code
\tlex:commentcnv
\tlex:commentscan
\tlex:configimpl
\tlex:constexp
\tlex:declinfo
\tlex:defargs
\tlex:doctokenizer
\tlex:fortrancode
\tlex:fortranscanner
\tlex:lexcode
\tlex:lexscanner
\tlex:pre
\tlex:pycode
\tlex:pyscanner
\tlex:scanner
\tlex:sqlcode
\tlex:vhdlcode
\tlex:xml
\tlex:xmlcode
\tmarkdown
\tnolineno
\tplantuml
\tpreprocessor
\tprinttree
\tqhp
\trtf
\tsections
\tstderr
\ttag
\ttime
`;
}

function exitError(message: string, withHelp = false): never {
  process.stderr.write(`error: ${message}\n`);
  if (withHelp) process.stderr.write(helpText());
  process.exit(1);
  throw new Error(message);
}

function parseConfig(content: string): Record<string, string> {
  const out: Record<string, string> = {};
  let current = "";
  for (const raw of content.split(/\r?\n/)) {
    let line = raw;
    const hash = line.indexOf("#");
    if (hash >= 0) line = line.slice(0, hash);
    if (!line.trim()) continue;
    const cont = /\\\s*$/.test(line);
    line = line.replace(/\\\s*$/, "");
    if (current) {
      current += " " + line.trim();
    } else {
      current = line.trim();
    }
    if (cont) continue;
    const m = current.match(/^([A-Za-z0-9_]+)\s*(\+?=)\s*(.*)$/);
    if (m) {
      const key = m[1];
      const val = unquote(m[3].trim());
      out[key] = m[2] === "+=" && out[key] ? `${out[key]} ${val}`.trim() : val;
    }
    current = "";
  }
  return out;
}

function unquote(s: string): string {
  if (s.length >= 2 && s.startsWith('"') && s.endsWith('"')) return s.slice(1, -1);
  return s;
}

function defaultConfig(): Record<string, string> {
  return parseConfig(readTemplate("Doxyfile.min"));
}

function generateConfig(silent: boolean, file: string): void {
  writeFile(file, readTemplate(silent ? "Doxyfile.min" : "Doxyfile"));
  if (file !== "-") {
    process.stdout.write(`\n\nConfiguration file '${file}' created.\n\nNow edit the configuration file and enter\n\n  doxygen${file === "Doxyfile" ? "" : " " + file}\n\nto generate the documentation for your project\n`);
  }
}

function updateConfig(silent: boolean, file: string): void {
  if (file !== "-" && !fs.existsSync(file)) exitError(`configuration file ${file} not found!`, true);
  const old = file === "-" ? fs.readFileSync(0, "utf8") : fs.readFileSync(file, "utf8");
  const values = parseConfig(old);
  let cfg = readTemplate(silent ? "Doxyfile.min" : "Doxyfile");
  for (const [key, val] of Object.entries(values)) {
    const re = new RegExp(`^(${key}\\s*=).*`, "m");
    if (re.test(cfg)) cfg = cfg.replace(re, (_: string, p1: string) => `${p1} ${quoteIfNeeded(val)}`);
  }
  writeFile(file, cfg);
  if (file !== "-") process.stdout.write(`\n\nConfiguration file '${file}' updated.\n\n`);
}

function quoteIfNeeded(v: string): string {
  if (!v) return "";
  return /\s/.test(v) && !(v.startsWith('"') && v.endsWith('"')) ? `"${v}"` : v;
}

function compareConfig(file: string): void {
  if (!fs.existsSync(file)) exitError(`configuration file ${file} not found!`, true);
  const cfg = parseConfig(fs.readFileSync(file, "utf8"));
  const def = defaultConfig();
  process.stdout.write(`# Difference with default Doxyfile ${VERSION}\n`);
  for (const key of Object.keys(cfg)) {
    if ((def[key] ?? "") !== cfg[key]) {
      const padded = key.padEnd(23, " ");
      process.stdout.write(`${padded}= ${quoteIfNeeded(cfg[key])}\n`);
    }
  }
}

function ensureDir(d: string): void {
  fs.mkdirSync(d, { recursive: true });
}

function htmlEscape(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function baseNameNoExt(f: string): string {
  return path.basename(f).replace(/\.[^.]*$/, "");
}

function extractBrief(content: string): string {
  const m = content.match(/\/\*\*([\s\S]*?)\*\//) || content.match(/\/\/\/\s?(.*)/);
  if (!m) return "";
  const text = (m[1] || "").split(/\r?\n/).map((x: string) => x.replace(/^\s*\*\s?/, "").trim()).filter(Boolean).join(" ");
  return text.replace(/[@\\](brief|file|mainpage)\s*/g, "").trim();
}

function discoverMembers(content: string): string[] {
  const members: string[] = [];
  const re = /^\s*(?:[A-Za-z_][\w:<>\*&\s]+)\s+([A-Za-z_]\w*)\s*\([^;{}]*\)\s*(?:const\s*)?[{;]/gm;
  let m: any;
  while ((m = re.exec(content))) {
    if (!["if", "for", "while", "switch"].includes(m[1])) members.push(m[1]);
  }
  const classRe = /^\s*(class|struct)\s+([A-Za-z_]\w*)/gm;
  while ((m = classRe.exec(content))) members.push(m[2]);
  return Array.from(new Set(members));
}

function page(title: string, project: string, body: string): string {
  return `<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8"/>
<meta name="generator" content="Doxygen 1.17.0"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${htmlEscape(project)}: ${htmlEscape(title)}</title>
<link href="doxygen.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="titlearea"><div id="projectname">${htmlEscape(project)}</div></div>
<div id="main-nav"><ul><li><a href="index.html">Main Page</a></li><li><a href="files.html">Files</a></li></ul></div>
<div class="contents">
${body}
</div>
<hr class="footer"/><address class="footer"><small>Generated by Doxygen 1.17.0</small></address>
</body>
</html>
`;
}

function runDocumentation(configFile: string, quietFlag: boolean): void {
  if (!fs.existsSync(configFile)) exitError(`configuration file ${configFile} not found!`, true);
  const cfg = { ...defaultConfig(), ...parseConfig(fs.readFileSync(configFile, "utf8")) };
  if (quietFlag) cfg.QUIET = "YES";
  const quiet = cfg.QUIET === "YES";
  const outRoot = cfg.OUTPUT_DIRECTORY || ".";
  if (!fs.existsSync(outRoot)) {
    ensureDir(outRoot);
    if (!quiet && outRoot !== ".") process.stdout.write(`Notice: Output directory '${outRoot}' does not exist. I have created it for you.\n`);
  }
  const htmlOn = cfg.GENERATE_HTML !== "NO";
  const latexOn = cfg.GENERATE_LATEX !== "NO";
  const manOn = cfg.GENERATE_MAN === "YES";
  const project = cfg.PROJECT_NAME || "My Project";
  if (!quiet) {
    process.stdout.write(`Doxygen version used: ${VERSION}\n`);
    process.stdout.write("Searching for include files...\nSearching for example files...\nSearching for images...\nSearching INPUT for files to process...\nParsing files\n");
  }
  const inputs = (cfg.INPUT || ".").split(/\s+/).filter(Boolean);
  const files = collectInputFiles(inputs);
  if (htmlOn) generateHtml(path.join(outRoot, cfg.HTML_OUTPUT || "html"), project, files, quiet);
  if (latexOn) generateLatex(path.join(outRoot, cfg.LATEX_OUTPUT || "latex"), project);
  if (manOn) generateMan(path.join(outRoot, cfg.MAN_OUTPUT || "man"), project, files);
  if (!quiet) process.stdout.write("finished...\n");
}

function collectInputFiles(inputs: string[]): string[] {
  const result: string[] = [];
  const exts = new Set([".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".java", ".py", ".js", ".ts", ".md"]);
  function walk(p: string): void {
    if (!fs.existsSync(p)) return;
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      for (const e of fs.readdirSync(p)) walk(path.join(p, e));
    } else if (exts.has(path.extname(p).toLowerCase())) {
      result.push(p);
    }
  }
  for (const i of inputs) walk(i);
  return result.sort();
}

function generateHtml(dir: string, project: string, files: string[], quiet: boolean): void {
  ensureDir(dir);
  fs.writeFileSync(path.join(dir, "doxygen.css"), readTemplate("html_style.css"));
  fs.writeFileSync(path.join(dir, "tabs.css"), "body{font-family:Arial,sans-serif}\n");
  const fileLinks = files.map((f) => `<li><a href="${htmlEscape(filePageName(f))}">${htmlEscape(path.basename(f))}</a></li>`).join("\n");
  fs.writeFileSync(path.join(dir, "index.html"), page("Main Page", project, `<h1>${htmlEscape(project)} Documentation</h1>\n<p>Generated documentation.</p>\n<ul>${fileLinks}</ul>`));
  fs.writeFileSync(path.join(dir, "files.html"), page("File List", project, `<h1>File List</h1>\n<ul>${fileLinks}</ul>`));
  fs.writeFileSync(path.join(dir, "globals.html"), page("Globals", project, "<h1>Globals</h1>"));
  for (const f of files) {
    if (!quiet) process.stdout.write(`Generating docs for file ${f}...\n`);
    const content = fs.readFileSync(f, "utf8");
    const brief = extractBrief(content);
    const members = discoverMembers(content);
    const body = `<h1>${htmlEscape(path.basename(f))} File Reference</h1>
${brief ? `<p>${htmlEscape(brief)}</p>` : ""}
${members.length ? `<h2>Functions</h2><ul>${members.map((m) => `<li>${htmlEscape(m)}</li>`).join("")}</ul>` : ""}
<h2>Source</h2><pre class="fragment">${htmlEscape(content)}</pre>`;
    fs.writeFileSync(path.join(dir, filePageName(f)), page(`${path.basename(f)} File Reference`, project, body));
  }
}

function filePageName(f: string): string {
  return path.basename(f).replace(/\W/g, "_") + ".html";
}

function generateLatex(dir: string, project: string): void {
  ensureDir(dir);
  fs.writeFileSync(path.join(dir, "refman.tex"), `\\documentclass{article}\n\\title{${project}}\n\\begin{document}\n\\maketitle\nGenerated by Doxygen 1.17.0\n\\end{document}\n`);
  fs.writeFileSync(path.join(dir, "doxygen.sty"), readTemplate("latex_style.sty"));
}

function generateMan(dir: string, project: string, files: string[]): void {
  ensureDir(dir);
  fs.writeFileSync(path.join(dir, `${baseNameNoExt(project).replace(/\W/g, "_")}.3`), `.TH "${project}" 3\n.SH NAME\n${project} \\- generated documentation\n`);
  for (const f of files) fs.writeFileSync(path.join(dir, `${baseNameNoExt(f)}.3`), `.TH "${path.basename(f)}" 3\n.SH NAME\n${path.basename(f)}\n`);
}

function commentToHtml(file: string): void {
  if (!fs.existsSync(file)) exitError(`source file ${file} not found!`);
  const text = extractBrief(fs.readFileSync(file, "utf8")) || fs.readFileSync(file, "utf8");
  process.stdout.write(`<p>${htmlEscape(text)}</p>\n`);
}

function main(): void {
  const args: string[] = process.argv.slice(2);
  let silent = false;
  let quiet = false;
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-s") silent = true;
    else if (a === "-q") quiet = true;
    else rest.push(a);
  }
  if (rest.length === 0) return runDocumentation("Doxyfile", quiet);
  const a = rest[0];
  if (a === "-h" || a === "-?" || a === "--help") { process.stdout.write(helpText()); return; }
  if (a === "-v") { process.stdout.write(`${SHORT_VERSION}\n`); return; }
  if (a === "-V") { process.stdout.write(`${VERSION}\n    with sqlite3 3.42.0.\n`); return; }
  if (a === "-d" && rest.length === 1) { process.stdout.write(debugText()); return; }
  if (a === "-g") return generateConfig(silent, rest[1] || "Doxyfile");
  if (a === "-u") return updateConfig(silent, rest[1] || "Doxyfile");
  if (a === "-l") return writeFile(rest[1] || "DoxygenLayout.xml", readTemplate("layout.xml"));
  if (a === "-x" || a === "-x_noenv") return compareConfig(rest[1] || "Doxyfile");
  if (a === "-c") return commentToHtml(rest[1] || "");
  if (a === "-w") {
    const fmt = rest[1];
    if (!["rtf", "html", "latex"].includes(fmt)) exitError(`Illegal format specifier "${fmt}": should be one of rtf, html or latex`);
    if (fmt === "rtf") return writeFile(rest[2] || "doxygen_rtf.cfg", readTemplate("rtf_style.cfg"));
    if (fmt === "html") {
      writeFile(rest[2] || "header.html", readTemplate("html_header.html"));
      writeFile(rest[3] || "footer.html", readTemplate("html_footer.html"));
      writeFile(rest[4] || "doxygen.css", readTemplate("html_style.css"));
      return;
    }
    writeFile(rest[2] || "header.tex", readTemplate("latex_header.tex"));
    writeFile(rest[3] || "footer.tex", readTemplate("latex_footer.tex"));
    writeFile(rest[4] || "doxygen.sty", readTemplate("latex_style.sty"));
    return;
  }
  if (a === "-e") {
    if (rest[1] !== "rtf") exitError('option "-e" has invalid format specifier.');
    return writeFile(rest[2] || "rtfext.cfg", readTemplate("rtf_extensions.cfg"));
  }
  if (a === "-f") {
    if (rest[1] !== "emoji") exitError('option "-f" has invalid list specifier.');
    return writeFile(rest[2] || "-", readTemplate("emoji.txt"));
  }
  if (a.startsWith("-")) exitError(`Unknown option "${a}"`, true);
  runDocumentation(a, quiet);
}

try {
  main();
} catch (e: any) {
  process.stderr.write(`${e && e.message ? e.message : String(e)}\n`);
  process.exit(1);
}
