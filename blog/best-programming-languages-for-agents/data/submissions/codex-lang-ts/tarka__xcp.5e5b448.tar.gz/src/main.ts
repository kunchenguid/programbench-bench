declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");
const os = require("os");

type BackupMode = "none" | "numbered" | "auto";
type ReflinkMode = "auto" | "always" | "never";

interface Options {
  recursive: boolean;
  dereference: boolean;
  workers: number;
  blockSize: string;
  noClobber: boolean;
  force: boolean;
  gitignore: boolean;
  glob: boolean;
  noProgress: boolean;
  noPerms: boolean;
  noTimestamps: boolean;
  ownership: boolean;
  driver: string;
  noTargetDirectory: boolean;
  targetDirectory?: string;
  fsync: boolean;
  reflink: ReflinkMode;
  backup: BackupMode;
  verbose: number;
}

interface Parsed {
  opts: Options;
  paths: string[];
}

const VERSION = "xcp 0.24.3";

const shortHelp = `A (partial) clone of the Unix \`cp\` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  Path list

Options:
  -v, --verbose...
          Verbosity
  -r, --recursive
          Copy directories recursively
  -L, --dereference
          Dereference symlinks in source
  -w, --workers <WORKERS>
          Number of parallel workers [default: 4]
      --block-size <BLOCK_SIZE>
          Block size for operations [default: 1MB]
  -n, --no-clobber
          Do not overwrite an existing file
  -f, --force
          Force (compatability only)
      --gitignore
          Use .gitignore if present
  -g, --glob
          Expand file patterns
      --no-progress
          Disable progress bar
      --no-perms
          Do not copy the file permissions
      --no-timestamps
          Do not copy the file timestamps
  -o, --ownership
          Copy ownership
      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel' [default: parfile]
  -T, --no-target-directory
          Target should not be a directory
      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target
      --fsync
          Sync each file to disk after writing
      --reflink <REFLINK>
          Reflink options [default: auto]
      --backup <BACKUP>
          Backup options [default: none]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version`;

const longHelp = `A (partial) clone of the Unix \`cp\` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          Path list.
          
          Source and destination files, or multiple source(s) to a directory.

Options:
  -v, --verbose...
          Verbosity.
          
          Can be specified multiple times to increase logging.

  -r, --recursive
          Copy directories recursively

  -L, --dereference
          Dereference symlinks in source
          
          Follow symlinks, possibly recursively, when copying source files.

  -w, --workers <WORKERS>
          Number of parallel workers.
          
          Default is 4; if the value is negative or 0 it uses the number of logical CPUs.
          
          [default: 4]

      --block-size <BLOCK_SIZE>
          Block size for operations.
          
          Accepts standard size modifiers like "M" and "GB". Actual usage internally depends on the driver.
          
          [default: 1MB]

  -n, --no-clobber
          Do not overwrite an existing file

  -f, --force
          Force (compatability only)
          
          Overwrite files; this is the default behaviour, this flag is for compatibility with \`cp\` only. See \`--no-clobber\` for the inverse flag. Using this in conjunction with \`--no-clobber\` will cause an error.

      --gitignore
          Use .gitignore if present.
          
          NOTE: This is fairly basic at the moment, and only honours a .gitignore in the directory root for directory copies; global or sub-directory ignores are skipped.

  -g, --glob
          Expand file patterns.
          
          Glob (expand) filename patterns natively (note; the shell may still do its own expansion first)

      --no-progress
          Disable progress bar

      --no-perms
          Do not copy the file permissions

      --no-timestamps
          Do not copy the file timestamps

  -o, --ownership
          Copy ownership.
          
          Whether to copy ownship (user/group).  This option requires root permissions or appropriate capabilities; if the attempt to copy ownership fails a warning is issued but the operation continues.

      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel'.
          
          Currently there are 2; the default "parfile", which parallelises copies across workers at the file level, and an experimental "parblock" driver, which parellelises at the block level. See also '--block-size'.
          
          [default: parfile]

  -T, --no-target-directory
          Target should not be a directory.
          
          Analogous to cp's no-target-directory. Expected behavior is that when copying a directory to another directory, instead of creating a sub-folder in target, overwrite target.

      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target

      --fsync
          Sync each file to disk after writing

      --reflink <REFLINK>
          Reflink options.
          
          Whether and how to use reflinks. 'auto' (the default) will attempt to reflink and fallback to a copy if it is not possible, 'always' will return an error if it cannot reflink, and 'never' will always perform a full data copy.
          
          Note: when using Linux accelerated copy operations (the default when available) the kernel may choose to reflink rather than perform a fully copy regardless of this setting.
          
          [default: auto]

      --backup <BACKUP>
          Backup options
          
          Whether to create backups of overwritten files. Current options are 'none'/'off', or 'numbered', or 'auto'. Numbered backups follow the semantics of \`cp\` numbered backups (e.g. \`file.txt.~123~\`). 'auto' will only create a numbered backup if a previous backups exists. Default is 'none'.
          
          [default: none]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

function defaultOptions(): Options {
  return {
    recursive: false,
    dereference: false,
    workers: 4,
    blockSize: "1MB",
    noClobber: false,
    force: false,
    gitignore: false,
    glob: false,
    noProgress: false,
    noPerms: false,
    noTimestamps: false,
    ownership: false,
    driver: "parfile",
    noTargetDirectory: false,
    fsync: false,
    reflink: "auto",
    backup: "none",
    verbose: 0,
  };
}

function exitError(msg: string, code = 1): never {
  console.error(msg);
  process.exit(code);
  throw new Error(msg);
}

function clapError(msg: string): never {
  console.error(msg);
  console.error("");
  console.error("For more information, try '--help'.");
  process.exit(2);
  throw new Error(msg);
}

function parseArgs(argv: string[]): Parsed {
  const opts = defaultOptions();
  const paths: string[] = [];
  let stop = false;
  const needValue = (i: number, name: string): string => {
    if (i + 1 >= argv.length) {
      clapError(`error: a value is required for '${name}' but none was supplied`);
    }
    return argv[i + 1];
  };

  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (stop) {
      paths.push(a);
      continue;
    }
    if (a === "--") {
      stop = true;
      continue;
    }
    if (a === "-h") {
      console.log(shortHelp);
      process.exit(0);
    }
    if (a === "--help") {
      console.log(longHelp);
      process.exit(0);
    }
    if (a === "-V" || a === "--version") {
      console.log(VERSION);
      process.exit(0);
    }
    if (a.startsWith("--")) {
      let val: string | undefined;
      const eq = a.indexOf("=");
      if (eq >= 0) {
        val = a.slice(eq + 1);
        a = a.slice(0, eq);
      }
      switch (a) {
        case "--verbose": opts.verbose++; break;
        case "--recursive": opts.recursive = true; break;
        case "--dereference": opts.dereference = true; break;
        case "--workers":
          if (val === undefined) { val = needValue(i, "--workers <WORKERS>"); i++; }
          opts.workers = parseInt(val, 10);
          break;
        case "--block-size":
          if (val === undefined) { val = needValue(i, "--block-size <BLOCK_SIZE>"); i++; }
          opts.blockSize = val;
          break;
        case "--no-clobber": opts.noClobber = true; break;
        case "--force": opts.force = true; break;
        case "--gitignore": opts.gitignore = true; break;
        case "--glob": opts.glob = true; break;
        case "--no-progress": opts.noProgress = true; break;
        case "--no-perms": opts.noPerms = true; break;
        case "--no-timestamps": opts.noTimestamps = true; break;
        case "--ownership": opts.ownership = true; break;
        case "--driver":
          if (val === undefined) { val = needValue(i, "--driver <DRIVER>"); i++; }
          if (val !== "parfile" && val !== "parblock" && val !== "file-parallel") {
            clapError(`error: invalid value '${val}' for '--driver <DRIVER>': Unknown driver: ${val}`);
          }
          opts.driver = val;
          break;
        case "--no-target-directory": opts.noTargetDirectory = true; break;
        case "--target-directory":
          if (val === undefined) { val = needValue(i, "--target-directory <TARGET_DIRECTORY>"); i++; }
          opts.targetDirectory = val;
          break;
        case "--fsync": opts.fsync = true; break;
        case "--reflink":
          if (val === undefined) { val = needValue(i, "--reflink <REFLINK>"); i++; }
          if (val !== "auto" && val !== "always" && val !== "never") {
            clapError(`error: invalid value '${val}' for '--reflink <REFLINK>': Invalid arguments: Unexpected value for 'reflink': ${val}`);
          }
          opts.reflink = val;
          break;
        case "--backup":
          if (val === undefined) { val = needValue(i, "--backup <BACKUP>"); i++; }
          if (val === "off") val = "none";
          if (val !== "none" && val !== "numbered" && val !== "auto") {
            clapError(`error: invalid value '${val}' for '--backup <BACKUP>': Invalid arguments: Unexpected value for 'backup': ${val}`);
          }
          opts.backup = val as BackupMode;
          break;
        default:
          console.error(`error: unexpected argument '${a}' found`);
          console.error("");
          console.error(`  tip: to pass '${a}' as a value, use '-- ${a}'`);
          console.error("");
          console.error("Usage: executable [OPTIONS] [PATHS]...");
          console.error("");
          console.error("For more information, try '--help'.");
          process.exit(2);
      }
      continue;
    }
    if (a.startsWith("-") && a !== "-") {
      for (let j = 1; j < a.length; j++) {
        const c = a[j];
        switch (c) {
          case "v": opts.verbose++; break;
          case "r": opts.recursive = true; break;
          case "L": opts.dereference = true; break;
          case "n": opts.noClobber = true; break;
          case "f": opts.force = true; break;
          case "g": opts.glob = true; break;
          case "o": opts.ownership = true; break;
          case "T": opts.noTargetDirectory = true; break;
          case "w": {
            let val = a.slice(j + 1);
            if (!val) { val = needValue(i, "-w <WORKERS>"); i++; }
            opts.workers = parseInt(val, 10);
            j = a.length;
            break;
          }
          default:
            clapError(`error: unexpected argument '-${c}' found`);
        }
      }
      continue;
    }
    paths.push(a);
  }
  return { opts, paths };
}

function exists(p: string): boolean {
  try { fs.lstatSync(p); return true; } catch (e: any) { return false; }
}

function statSource(p: string, dereference: boolean): any {
  return dereference ? fs.statSync(p) : fs.lstatSync(p);
}

function mkdirp(p: string): void {
  fs.mkdirSync(p, { recursive: true });
}

function removeDest(p: string): void {
  if (!exists(p)) return;
  fs.rmSync(p, { recursive: true, force: true });
}

function copyMetadata(src: string, dest: string, st: any, opts: Options, symlink: boolean): void {
  if (!opts.noPerms && !symlink) {
    try { fs.chmodSync(dest, st.mode & 0o7777); } catch (_) {}
  }
  if (!opts.noTimestamps && !symlink) {
    try { fs.utimesSync(dest, st.atime, st.mtime); } catch (_) {}
  }
  if (opts.ownership && !symlink) {
    try { fs.chownSync(dest, st.uid, st.gid); } catch (_) {}
  }
}

function backupPath(dest: string): string {
  const dir = path.dirname(dest);
  const base = path.basename(dest);
  let max = 0;
  if (exists(dir)) {
    for (const ent of fs.readdirSync(dir)) {
      const m = ent.match(new RegExp("^" + escapeRegExp(base) + "\\.~(\\d+)~$"));
      if (m) max = Math.max(max, parseInt(m[1], 10));
    }
  }
  return path.join(dir, `${base}.~${max + 1}~`);
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function shouldBackup(dest: string, mode: BackupMode): boolean {
  if (!exists(dest)) return false;
  if (mode === "numbered") return true;
  if (mode !== "auto") return false;
  const dir = path.dirname(dest);
  const base = path.basename(dest);
  if (!exists(dir)) return false;
  return fs.readdirSync(dir).some((ent: string) => new RegExp("^" + escapeRegExp(base) + "\\.~\\d+~$").test(ent));
}

function prepareDest(dest: string, opts: Options): void {
  if (!exists(dest)) return;
  if (opts.noClobber) {
    throw new Error(`Destination Exists: Destination file exists and --no-clobber is set., ${dest}`);
  }
  if (shouldBackup(dest, opts.backup)) {
    fs.renameSync(dest, backupPath(dest));
  }
}

function copyFile(src: string, dest: string, opts: Options, st: any): void {
  prepareDest(dest, opts);
  fs.copyFileSync(src, dest);
  if (opts.fsync) {
    try {
      const fd = fs.openSync(dest, "r");
      fs.fsyncSync(fd);
      fs.closeSync(fd);
    } catch (_) {}
  }
  copyMetadata(src, dest, st, opts, false);
}

function copySymlink(src: string, dest: string, opts: Options, st: any): void {
  prepareDest(dest, opts);
  const target = fs.readlinkSync(src);
  fs.symlinkSync(target, dest);
  copyMetadata(src, dest, st, opts, true);
}

function loadGitignore(root: string, opts: Options): ((rel: string) => boolean) {
  if (!opts.gitignore) return () => false;
  const file = path.join(root, ".gitignore");
  if (!exists(file)) return () => false;
  const rules = fs.readFileSync(file, "utf8").split(/\r?\n/)
    .map((l: string) => l.trim())
    .filter((l: string) => l && !l.startsWith("#"));
  return (rel: string): boolean => {
    const name = path.basename(rel);
    return rules.some((r: string) => matchIgnoreRule(r, rel, name));
  };
}

function matchIgnoreRule(rule: string, rel: string, name: string): boolean {
  let r = rule.replace(/^\//, "");
  if (r.endsWith("/")) r = r.slice(0, -1);
  if (r.includes("/")) return globMatch(r, rel);
  return globMatch(r, name) || globMatch(r, rel);
}

function copyDirContents(src: string, dest: string, opts: Options, root: string, ignored: (rel: string) => boolean): void {
  mkdirp(dest);
  const st = statSource(src, opts.dereference);
  copyMetadata(src, dest, st, opts, false);
  for (const ent of fs.readdirSync(src)) {
    const s = path.join(src, ent);
    const rel = path.relative(root, s).split(path.sep).join("/");
    if (ignored(rel)) continue;
    copyAny(s, path.join(dest, ent), opts, root, ignored);
  }
}

function copyAny(src: string, dest: string, opts: Options, root?: string, ignored?: (rel: string) => boolean): void {
  const st = statSource(src, opts.dereference);
  if (st.isDirectory()) {
    if (!opts.recursive) throw new Error("Invalid source: Source is directory and --recursive not specified.");
    const ig = ignored || loadGitignore(src, opts);
    copyDirContents(src, dest, opts, root || src, ig);
  } else if (!opts.dereference && st.isSymbolicLink && st.isSymbolicLink()) {
    copySymlink(src, dest, opts, st);
  } else if (st.isFile()) {
    copyFile(src, dest, opts, st);
  } else {
    copyFile(src, dest, opts, st);
  }
}

function globMatch(pattern: string, name: string): boolean {
  const esc = pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&")
    .replace(/\*/g, ".*")
    .replace(/\?/g, ".");
  return new RegExp("^" + esc + "$").test(name);
}

function expandGlob(pattern: string): string[] {
  if (!/[?*[]/.test(pattern)) return [pattern];
  const dir = pattern.includes("/") ? path.dirname(pattern) : ".";
  const base = pattern.includes("/") ? path.basename(pattern) : pattern;
  if (!exists(dir)) return [];
  return fs.readdirSync(dir).filter((n: string) => globMatch(base, n)).map((n: string) => path.join(dir, n));
}

function sourceList(paths: string[], opts: Options): string[] {
  const out: string[] = [];
  for (const p of paths) {
    if (opts.glob) out.push(...expandGlob(p));
    else out.push(p);
  }
  return out;
}

function main(): void {
  const { opts, paths } = parseArgs(process.argv.slice(2));
  if (opts.force && opts.noClobber) {
    exitError("Error: Invalid arguments: --force and --noclobber cannot be set at the same time.");
  }

  try {
    if (opts.targetDirectory) {
      if (paths.length < 1) exitError("Error: Invalid arguments: Insufficient arguments");
      const sources = sourceList(paths, opts);
      if (sources.length === 0) exitError("Error: Invalid source: No source files found.");
      for (const src of sources) {
        copyAny(src, path.join(opts.targetDirectory, path.basename(src)), opts);
      }
      return;
    }

    if (paths.length < 2) {
      if (paths.length === 0) exitError("Error: Invalid arguments: Insufficient arguments");
      exitError("Error: Invalid source: No source files found.");
    }

    const rawDest = paths[paths.length - 1];
    const sources = sourceList(paths.slice(0, -1), opts);
    if (sources.length === 0) exitError("Error: Invalid source: No source files found.");

    const destExists = exists(rawDest);
    const destIsDir = destExists && fs.lstatSync(rawDest).isDirectory();
    if (sources.length > 1 && (!destExists || !destIsDir)) {
      exitError("Error: Invalid destination: Multiple sources and destination is not a directory.");
    }

    for (const src of sources) {
      const srcSt = statSource(src, opts.dereference);
      let dest = rawDest;
      if (!opts.noTargetDirectory && destIsDir) {
        dest = path.join(rawDest, path.basename(src));
      }
      copyAny(src, dest, opts);
    }
  } catch (e: any) {
    const msg = e && e.message ? e.message : String(e);
    if (msg.startsWith("Invalid ") || msg.startsWith("Destination Exists:")) {
      exitError(`Error: ${msg}`);
    }
    exitError(`Error: Error during copy: ${msg}`);
  }
}

main();
