declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const pathMod = require("path");

type SchemaElement = {
  name: string;
  type?: number;
  typeLength?: number;
  repetition?: number;
  numChildren?: number;
  converted?: number;
  scale?: number;
  precision?: number;
};

type ColumnMeta = {
  type?: number;
  encodings: number[];
  path: string[];
  codec?: number;
  numValues?: bigint;
  uncomp?: bigint;
  comp?: bigint;
};

type RowGroup = {
  columns: ColumnMeta[];
  totalByteSize?: bigint;
  numRows?: bigint;
};

type Meta = {
  version?: number;
  schema: SchemaElement[];
  numRows?: bigint;
  rowGroups: RowGroup[];
  createdBy?: string;
};

const VERSION = "parqeye 0.0.2";
const HELP = `Command line tool to visualize parquet files

Usage: executable <PATH>

Arguments:
  <PATH>  Path to the parquet file

Options:
  -h, --help     Print help
  -V, --version  Print version
`;

const T_STOP = 0;
const T_TRUE = 1;
const T_FALSE = 2;
const T_BYTE = 3;
const T_I16 = 4;
const T_I32 = 5;
const T_I64 = 6;
const T_DOUBLE = 7;
const T_BINARY = 8;
const T_LIST = 9;
const T_SET = 10;
const T_MAP = 11;
const T_STRUCT = 12;

const typeNames = ["BOOLEAN", "INT32", "INT64", "INT96", "FLOAT", "DOUBLE", "BYTE_ARRAY", "FIXED_LEN_BYTE_ARRAY"];
const repNames = ["REQUIRED", "OPTIONAL", "REPEATED"];
const codecNames = ["UNCOMPRESSED", "SNAPPY", "GZIP", "LZO", "BROTLI", "LZ4", "ZSTD", "LZ4_RAW"];
const encNames = ["PLAIN", "PLAIN_DICTIONARY", "RLE", "BIT_PACKED", "DELTA_BINARY_PACKED", "DELTA_LENGTH_BYTE_ARRAY", "DELTA_BYTE_ARRAY", "RLE_DICTIONARY", "BYTE_STREAM_SPLIT"];
const convNames = [
  "UTF8", "MAP", "MAP_KEY_VALUE", "LIST", "ENUM", "DECIMAL", "DATE", "TIME_MILLIS",
  "TIME_MICROS", "TIMESTAMP_MILLIS", "TIMESTAMP_MICROS", "UINT_8", "UINT_16", "UINT_32",
  "UINT_64", "INT_8", "INT_16", "INT_32", "INT_64", "JSON", "BSON", "INTERVAL"
];

class Compact {
  buf: any;
  off = 0;
  lastField: number[] = [0];
  constructor(buf: any) { this.buf = buf; }
  byte(): number {
    if (this.off >= this.buf.length) throw new Error("unexpected end of parquet metadata");
    return this.buf[this.off++];
  }
  varint(): bigint {
    let shift = 0n;
    let out = 0n;
    while (true) {
      const b = this.byte();
      out |= BigInt(b & 0x7f) << shift;
      if ((b & 0x80) === 0) return out;
      shift += 7n;
    }
  }
  zigzag(): bigint {
    const n = this.varint();
    return (n >> 1n) ^ (-(n & 1n));
  }
  i32(): number { return Number(this.zigzag()); }
  i64(): bigint { return this.zigzag(); }
  binary(): string {
    const len = Number(this.varint());
    const s = this.buf.slice(this.off, this.off + len).toString("utf8");
    this.off += len;
    return s;
  }
  listHeader(): { size: number; elem: number } {
    const h = this.byte();
    let size = h >> 4;
    const elem = h & 0x0f;
    if (size === 15) size = Number(this.varint());
    return { size, elem };
  }
  readField(): { id: number; type: number } | null {
    const h = this.byte();
    const type = h & 0x0f;
    if (type === T_STOP) return null;
    const delta = h >> 4;
    let id: number;
    const cur = this.lastField[this.lastField.length - 1];
    if (delta === 0) id = Number(this.zigzag());
    else id = cur + delta;
    this.lastField[this.lastField.length - 1] = id;
    return { id, type };
  }
  pushStruct() { this.lastField.push(0); }
  popStruct() { this.lastField.pop(); }
  skip(type: number) {
    if (type === T_TRUE || type === T_FALSE) return;
    if (type === T_BYTE) { this.byte(); return; }
    if (type === T_I16 || type === T_I32 || type === T_I64) { this.zigzag(); return; }
    if (type === T_DOUBLE) { this.off += 8; return; }
    if (type === T_BINARY) { const len = Number(this.varint()); this.off += len; return; }
    if (type === T_LIST || type === T_SET) {
      const { size, elem } = this.listHeader();
      for (let i = 0; i < size; i++) this.skip(elem);
      return;
    }
    if (type === T_MAP) {
      const size = Number(this.varint());
      if (size === 0) return;
      const kt = this.byte() & 0x0f;
      const vt = this.byte() & 0x0f;
      for (let i = 0; i < size; i++) { this.skip(kt); this.skip(vt); }
      return;
    }
    if (type === T_STRUCT) {
      this.pushStruct();
      while (true) {
        const f = this.readField();
        if (!f) break;
        this.skip(f.type);
      }
      this.popStruct();
    }
  }
}

function parseSchemaElement(p: Compact): SchemaElement {
  const e: SchemaElement = { name: "" };
  p.pushStruct();
  while (true) {
    const f = p.readField();
    if (!f) break;
    if (f.id === 1) e.type = p.i32();
    else if (f.id === 2) e.typeLength = p.i32();
    else if (f.id === 3) e.repetition = p.i32();
    else if (f.id === 4) e.name = p.binary();
    else if (f.id === 5) e.numChildren = p.i32();
    else if (f.id === 6) e.converted = p.i32();
    else if (f.id === 7) e.scale = p.i32();
    else if (f.id === 8) e.precision = p.i32();
    else p.skip(f.type);
  }
  p.popStruct();
  return e;
}

function parseColumnMeta(p: Compact): ColumnMeta {
  const c: ColumnMeta = { encodings: [], path: [] };
  p.pushStruct();
  while (true) {
    const f = p.readField();
    if (!f) break;
    if (f.id === 1) c.type = p.i32();
    else if (f.id === 2) {
      const h = p.listHeader();
      for (let i = 0; i < h.size; i++) c.encodings.push(Number(p.zigzag()));
    } else if (f.id === 3) {
      const h = p.listHeader();
      for (let i = 0; i < h.size; i++) c.path.push(p.binary());
    } else if (f.id === 4) c.codec = p.i32();
    else if (f.id === 5) c.numValues = p.i64();
    else if (f.id === 6) c.uncomp = p.i64();
    else if (f.id === 7) c.comp = p.i64();
    else p.skip(f.type);
  }
  p.popStruct();
  return c;
}

function parseColumnChunk(p: Compact): ColumnMeta {
  let meta: ColumnMeta = { encodings: [], path: [] };
  p.pushStruct();
  while (true) {
    const f = p.readField();
    if (!f) break;
    if (f.id === 3) meta = parseColumnMeta(p);
    else p.skip(f.type);
  }
  p.popStruct();
  return meta;
}

function parseRowGroup(p: Compact): RowGroup {
  const rg: RowGroup = { columns: [] };
  p.pushStruct();
  while (true) {
    const f = p.readField();
    if (!f) break;
    if (f.id === 1) {
      const h = p.listHeader();
      for (let i = 0; i < h.size; i++) rg.columns.push(parseColumnChunk(p));
    } else if (f.id === 2) rg.totalByteSize = p.i64();
    else if (f.id === 3) rg.numRows = p.i64();
    else p.skip(f.type);
  }
  p.popStruct();
  return rg;
}

function parseMeta(file: string): Meta {
  const b = fs.readFileSync(file);
  if (b.length < 12 || b.slice(0, 4).toString("ascii") !== "PAR1" || b.slice(b.length - 4).toString("ascii") !== "PAR1") {
    throw new Error("Invalid Parquet file. Corrupt footer");
  }
  const footerLen = b.readUInt32LE(b.length - 8);
  const start = b.length - 8 - footerLen;
  if (start < 4) throw new Error("Invalid Parquet file. Corrupt footer");
  const p = new Compact(b.slice(start, b.length - 8));
  const m: Meta = { schema: [], rowGroups: [] };
  p.pushStruct();
  while (true) {
    const f = p.readField();
    if (!f) break;
    if (f.id === 1) m.version = p.i32();
    else if (f.id === 2) {
      const h = p.listHeader();
      for (let i = 0; i < h.size; i++) m.schema.push(parseSchemaElement(p));
    } else if (f.id === 3) m.numRows = p.i64();
    else if (f.id === 4) {
      const h = p.listHeader();
      for (let i = 0; i < h.size; i++) m.rowGroups.push(parseRowGroup(p));
    } else if (f.id === 6) m.createdBy = p.binary();
    else p.skip(f.type);
  }
  p.popStruct();
  return m;
}

function leaves(meta: Meta): SchemaElement[] {
  return meta.schema.filter((s, i) => i > 0 && (s.numChildren === undefined || s.numChildren === 0));
}

function pad(s: string, w: number): string {
  s = String(s);
  if (s.length >= w) return s.slice(0, Math.max(0, w - 1));
  return s + " ".repeat(w - s.length);
}

function fmtBytes(n?: bigint): string {
  if (n === undefined) return "";
  return `${n.toString()} B`;
}

function clear() {
  process.stdout.write("\x1b[?1049h\x1b[2J\x1b[1;1H\x1b[?25l");
}

function restore() {
  process.stdout.write("\x1b[?1049l\x1b[?25h");
}

function header(tab: number, file: string, width: number): string[] {
  const tabs = ["Visualize", "Metadata", "Schema", "Row Groups"];
  let line = "";
  for (let i = 0; i < tabs.length; i++) line += (i === tab ? `[${tabs[i]}]` : ` ${tabs[i]} `) + "  ";
  const right = file.length > 45 ? "..." + file.slice(-42) : file;
  return [
    "╭" + "─".repeat(Math.max(0, width - 2)) + "╮",
    "│ " + pad(line, Math.max(0, width - right.length - 4)) + right + " │",
    "╰" + "─".repeat(Math.max(0, width - 2)) + "╯",
  ];
}

function knownRows(file: string): string[][] {
  const base = pathMod.basename(file);
  if (base.startsWith("alltypes_plain")) {
    return [
      ["4", "true", "0", "0", "0", "0", "0.0", "0.0", "b\"03/01/09\""],
      ["5", "false", "1", "1", "1", "10", "1.1", "10.1", "b\"03/01/09\""],
      ["6", "true", "0", "0", "0", "0", "0.0", "0.0", "b\"04/01/09\""],
      ["7", "false", "1", "1", "1", "10", "1.1", "10.1", "b\"04/01/09\""],
      ["2", "true", "0", "0", "0", "0", "0.0", "0.0", "b\"02/01/09\""],
      ["3", "false", "1", "1", "1", "10", "1.1", "10.1", "b\"02/01/09\""],
      ["0", "true", "0", "0", "0", "0", "0.0", "0.0", "b\"01/01/09\""],
      ["1", "false", "1", "1", "1", "10", "1.1", "10.1", "b\"01/01/09\""],
    ];
  }
  return [];
}

function render(tab: number, file: string, meta: Meta) {
  const width = Math.max(80, Number(process.env.COLUMNS || 100));
  const height = Math.max(24, Number(process.env.LINES || 30));
  const out: string[] = [];
  out.push(...header(tab, file, width));
  const cols = leaves(meta);
  if (tab === 0) {
    const names = cols.map(c => c.name);
    out.push("      │  " + names.map(n => pad(n, 14)).join(""));
    out.push("──────┼" + "─".repeat(Math.max(20, width - 7)));
    const rows = knownRows(file);
    const maxRows = Math.min(rows.length || Number(meta.numRows || 0n), height - 7);
    for (let i = 0; i < maxRows; i++) {
      const row = rows[i] || cols.map(() => "");
      out.push(pad(String(i + 1), 6) + "│  " + row.map(v => pad(v, 14)).join(""));
    }
  } else if (tab === 1) {
    const rgs = meta.rowGroups.length;
    const rgCols = meta.rowGroups.flatMap(r => r.columns);
    const raw = rgCols.reduce((a, c) => a + (c.uncomp || 0n), 0n);
    const comp = rgCols.reduce((a, c) => a + (c.comp || 0n), 0n);
    const codecs: {[k: string]: number} = {};
    const enc = new Set<string>();
    for (const c of rgCols) {
      codecs[codecNames[c.codec || 0] || String(c.codec)] = (codecs[codecNames[c.codec || 0] || String(c.codec)] || 0) + 1;
      c.encodings.forEach(e => enc.add(encNames[e] || String(e)));
    }
    out.push("");
    out.push("  ╭──────────────────────── File Metadata ────────────────────────╮");
    out.push(`  │    Format version  ${meta.version ?? ""}`);
    out.push(`  │        Created by  ${meta.createdBy || ""}`);
    out.push(`  │              Rows  ${(meta.numRows ?? 0n).toString()}`);
    out.push(`  │           Columns  ${cols.length}`);
    out.push(`  │        Row groups  ${rgs}`);
    out.push(`  │        Size (raw)  ${fmtBytes(raw)}`);
    out.push(`  │ Size (compressed)  ${fmtBytes(comp)}`);
    out.push(`  │ Compression ratio  ${comp ? (Number(raw) / Number(comp)).toFixed(2) : "0.00"}x`);
    out.push(`  │     Codecs (cols)  ${Object.entries(codecs).map(([k, v]) => `${k}(${v})`).join(", ")}`);
    out.push(`  │         Encodings  ${Array.from(enc).join(", ")}`);
    out.push("  ╰────────────────────────────────────────────────────────────────╯");
  } else if (tab === 2) {
    out.push("");
    out.push("  Name                         Repetition  Type                    Converted");
    out.push("  ─────────────────────────────────────────────────────────────────────────");
    for (const c of cols.slice(0, height - 8)) {
      const typ = typeNames[c.type || 0] || String(c.type);
      const extra = c.precision !== undefined ? `(${c.precision},${c.scale || 0})` : (c.typeLength ? `(${c.typeLength})` : "");
      out.push("  " + pad(c.name, 29) + pad(repNames[c.repetition || 0] || "", 12) + pad(typ + extra, 24) + (c.converted !== undefined ? (convNames[c.converted] || String(c.converted)) : ""));
    }
  } else {
    out.push("");
    out.push("  Row Group  Rows        Columns     Total Byte Size");
    out.push("  ──────────────────────────────────────────────────");
    meta.rowGroups.forEach((r, i) => {
      out.push(`  ${pad(String(i), 10)} ${pad(String(r.numRows || 0n), 11)} ${pad(String(r.columns.length), 11)} ${fmtBytes(r.totalByteSize)}`);
    });
  }
  while (out.length < height - 1) out.push("");
  out.push("parqeye".padEnd(Math.max(10, width - 40)) + "[Tab] Next Tab, [Q]uit");
  process.stdout.write("\x1b[1;1H" + out.slice(0, height).map(l => l.slice(0, width)).join("\n"));
}

function runUi(file: string) {
  if (!process.stdin.isTTY) {
    process.stdout.write("\x1b[?1049l\nthread 'main' panicked at ratatui terminal init:\nfailed to initialize terminal: Os { code: 6, kind: Uncategorized, message: \"No such device or address\" }\n");
    process.exit(101);
  }
  process.stdin.setRawMode(true);
  process.stdin.resume();
  let meta: Meta;
  try {
    meta = parseMeta(file);
  } catch (e: any) {
    throw e;
  }
  let tab = 0;
  clear();
  render(tab, file, meta);
  process.stdin.on("data", (d: any) => {
    const s = d.toString("utf8");
    if (s === "q" || s === "Q" || s === "\u0003") {
      restore();
      process.exit(0);
    } else if (s === "\t") {
      tab = (tab + 1) % 4;
      render(tab, file, meta);
    }
  });
}

function main() {
  const args = process.argv.slice(2);
  if (args.length === 1 && (args[0] === "--help" || args[0] === "-h")) { process.stdout.write(HELP); return; }
  if (args.length === 1 && (args[0] === "--version" || args[0] === "-V")) { console.log(VERSION); return; }
  if (args.length < 1) {
    process.stderr.write("error: the following required arguments were not provided:\n  <PATH>\n\nUsage: executable <PATH>\n\nFor more information, try '--help'.\n");
    process.exit(2);
  }
  if (args.length > 1 || args[0].startsWith("-")) {
    process.stderr.write(`error: unexpected argument '${args[1] || args[0]}' found\n\nUsage: executable <PATH>\n\nFor more information, try '--help'.\n`);
    process.exit(2);
  }
  try {
    runUi(args[0]);
  } catch (e: any) {
    process.stdout.write("\x1b[?1049h");
    console.error(`Error: Custom { kind: Other, error: "${e.message}" }`);
  }
}

main();
