declare const require: any;
declare const process: any;
const fs = require('fs');
const path = require('path');

const HOME = process.env.HOME || '/home/agent';
const DEFAULT_CONFIG = `${HOME}/.caps-log/config.ini`;
const DEFAULT_LOG_DIR = `${HOME}/.caps-log/day`;
const VERSION = 'commit-93cc85d16ab60ba8d646458fe0233778317b22a3';

interface Options {
  help: boolean;
  config: string;
  logDir?: string;
  logNameFormat?: string;
  sundayStart: boolean;
  firstLineSection: boolean;
  password?: string;
  encrypt: boolean;
  decrypt: boolean;
}

function helpText(): string {
  return `Captain's Log (caps-log)! A CLI journalig tool.
Version: ${VERSION}
Allowed options:
  -h [ --help ]         show this message
  -c [ --config ] arg   override the default config file path 
                        (${DEFAULT_CONFIG})
  --log-dir-path arg    path where log files are stored
  --log-name-format arg format in which log entry markdown files are saved
  --sunday-start        have the calendar display sunday as first day of the 
                        week
  --first-line-section  override the default behaviour of ignoring sections 
                        (lines starting with \`#\`) in the first line of a log 
                        entry file
  --password arg        password for encrypted log repositories or to be used 
                        with --encrypt/--decrypt
  --encrypt             apply encryption to all logs in log dir path (needs 
                        --password)
  --decrypt             apply decryption to all logs in log dir path (needs 
                        --password)`;
}

function die(message: string): never {
  console.error("Captain's log encountered an error: ");
  console.error(' ' + message);
  process.exit(1);
  throw new Error(message);
}

function parseArgs(argv: string[]): Options {
  const opts: Options = { help: false, config: DEFAULT_CONFIG, sundayStart: false, firstLineSection: false, encrypt: false, decrypt: false };
  const needsArg: Record<string, keyof Options> = {
    '-c': 'config', '--config': 'config', '--log-dir-path': 'logDir', '--log-name-format': 'logNameFormat', '--password': 'password'
  };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '-h' || a === '--help') { opts.help = true; continue; }
    if (a === '--sunday-start') { opts.sundayStart = true; continue; }
    if (a === '--first-line-section') { opts.firstLineSection = true; continue; }
    if (a === '--encrypt') { opts.encrypt = true; continue; }
    if (a === '--decrypt') { opts.decrypt = true; continue; }
    const eq = a.indexOf('=');
    if (eq > 0) {
      const key = a.slice(0, eq);
      const val = a.slice(eq + 1);
      if (needsArg[key]) { (opts as any)[needsArg[key]] = val; continue; }
    }
    if (needsArg[a]) {
      if (i + 1 >= argv.length || argv[i + 1].startsWith('-')) die(`the required argument for option '${a}' is missing`);
      (opts as any)[needsArg[a]] = argv[++i];
      continue;
    }
    die(`unrecognised option '${a}'`);
  }
  return opts;
}

function parseConfig(file: string): Record<string,string> {
  let text: string;
  try { text = fs.readFileSync(file, 'utf8'); }
  catch { die(`Failed to open file: ${file}`); }
  const cfg: Record<string,string> = {};
  const lines = text.split(/\r?\n/);
  let section = '';
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].trim();
    if (!line || line.startsWith('#') || line.startsWith(';')) continue;
    const comment = line.indexOf(' #');
    if (comment >= 0) line = line.slice(0, comment).trim();
    if (line.startsWith('[') && line.endsWith(']')) { section = line.slice(1, -1).trim(); continue; }
    const p = line.indexOf('=');
    if (p < 0) die(`Failed to parse configuration file: <unspecified file>(${i + 1}): '=' character not found in line`);
    const key = (section ? section + '.' : '') + line.slice(0, p).trim();
    cfg[key] = line.slice(p + 1).trim();
  }
  return cfg;
}

function boolVal(v: string | undefined): boolean { return v === 'true' || v === '1' || v === 'yes'; }

function mergeConfig(opts: Options, cfg: Record<string,string>): Options {
  if (!opts.logDir && cfg['log-dir-path']) opts.logDir = cfg['log-dir-path'];
  if (!opts.logNameFormat && (cfg['log-name-format'] || cfg['log-filename-format'])) opts.logNameFormat = cfg['log-name-format'] || cfg['log-filename-format'];
  if (!opts.password && cfg['password']) opts.password = cfg['password'];
  if (!opts.sundayStart) opts.sundayStart = boolVal(cfg['sunday-start']);
  if (!opts.firstLineSection) opts.firstLineSection = boolVal(cfg['first-line-section']);
  return opts;
}

function cryptoMode(opts: Options): void {
  if ((opts.encrypt || opts.decrypt) && !opts.password) {
    die(opts.encrypt ? 'Password must be provided when encrypting logs!' : 'Password must be provided when decrypting logs!');
  }
  if (opts.password && !opts.encrypt && !opts.decrypt) die('Password provided for a non encrypted repository!');
  const logDir = opts.logDir || DEFAULT_LOG_DIR;
  if (opts.encrypt || opts.decrypt) {
    console.log('Applying crypto...');
    if (opts.decrypt) die('Already applied');
    try { fs.readdirSync(logDir); }
    catch { die(`filesystem error: directory iterator cannot open directory: No such file or directory [${logDir}]`); }
    process.exit(0);
  }
}

function listLogs(logDir: string): string[] {
  try { return fs.readdirSync(logDir).filter((f: string) => /\.(md|txt)$/i.test(f)); }
  catch { return []; }
}

function renderCalendar(opts: Options): void {
  const now = new Date();
  const year = now.getUTCFullYear();
  const d = String(now.getUTCDate()).padStart(2, '0');
  const m = String(now.getUTCMonth() + 1).padStart(2, '0');
  const logs = listLogs(opts.logDir || DEFAULT_LOG_DIR);
  process.stdout.write('\x1b[?1049h\x1b[?7l');
  console.log(`       Today is: ${d}. ${m}. ${year}.  | There are ${logs.length} log entries for year ${year}.        `);
  console.log('┌─Sections───────────┐┌─Tags──────────────┐┌─' + year + '────────────────────┐');
  console.log('│> <select none>     ││> <select none>    ││ Calendar view       │');
  console.log('│                    ││                  ││ Use hjkl/arrows     │');
  console.log('│                    ││                  ││ Enter opens editor  │');
  console.log('└────────────────────┘└──────────────────┘└─────────────────────┘');
  console.log('');
  console.log('Caps-Log is running. Press Ctrl+C to exit.');
  setInterval(() => {}, 1000);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) { console.log(helpText()); return; }
  const cfg = parseConfig(opts.config);
  mergeConfig(opts, cfg);
  cryptoMode(opts);
  if (opts.password) die('Password provided for a non encrypted repository!');
  renderCalendar(opts);
}

main();
