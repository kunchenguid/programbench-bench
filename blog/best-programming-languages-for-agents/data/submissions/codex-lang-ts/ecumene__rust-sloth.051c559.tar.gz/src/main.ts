declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

type Vec3 = { x: number; y: number; z: number };
type Face = { idx: number[]; mat?: string; normal?: Vec3 };
type Model = { vertices: Vec3[]; faces: Face[]; materials: Record<string, [number, number, number]> };
type Options = { yaw: number; pitch: number; roll: number; colorless: boolean; width?: number; height?: number; webify?: number };

const BG: [number, number, number] = [25, 25, 25];
const BLACK: [number, number, number] = [0, 0, 0];
const HELP = `Sloth 0.1
Mitchell Hynes. <mshynes@mun.ca>
A toy for rendering 3D objects in the command line

USAGE:
    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -x, --yaw <x>      Sets the object's static X rotation (in radians)
    -y, --pitch <y>    Sets the object's static Y rotation (in radians)
    -z, --roll <z>     Sets the object's static Z rotation (in radians)

ARGS:
    <input filename(s)>...    Sets the input file to render

SUBCOMMANDS:
    help     Prints this message or the help of the given subcommand(s)
    image    Generates a colorless terminal output as lines of text`;

function imageHelp(withInput: boolean) {
  return `executable-image 
Mitchell Hynes <mitchell.hynes@ecumene.xyz>
Generates a colorless terminal output as lines of text

USAGE:
    executable ${withInput ? "<input filename(s)>... " : ""}image [FLAGS] [OPTIONS] -w <width>

FLAGS:
        --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -j, --webify <frame count>    Generates a portable JS based render of your object for the web
    -h <height>                   Sets the height of the image to generate
    -w <width>                    Sets the width of the image to generate
    -x, --yaw <x>                 Sets the object's static X rotation (in radians)
    -y, --pitch <y>               Sets the object's static Y rotation (in radians)
    -z, --roll <z>                Sets the object's static Z rotation (in radians)`;
}

function die(msg: string, code = 1): void {
  process.stderr.write(msg + "\n");
  process.exit(code);
}

function parseArgs(argv: string[]) {
  const opts: Options = { yaw: 0, pitch: 0, roll: 0, colorless: false };
  const files: string[] = [];
  let sub: string | undefined;
  let sawFileBeforeImage = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (sub === "image" && a === "-h") {
      opts.height = Number(argv[++i] || 0);
      continue;
    }
    if (a === "--help" || (a === "-h" && sub !== "image")) {
      if (sub === "image" || argv.includes("image")) {
        console.log(imageHelp(argv.indexOf("image") > 0));
      } else {
        console.log(HELP);
      }
      process.exit(0);
    }
    if (a === "help") {
      if (argv[i + 1] === "image") console.log(imageHelp(false)); else console.log(HELP);
      process.exit(0);
    }
    if (a === "--version" || a === "-V") {
      console.log("Sloth 0.1");
      process.exit(0);
    }
    if (a === "image") {
      sub = "image";
      sawFileBeforeImage = files.length > 0;
      continue;
    }
    if (a === "-b") {
      opts.colorless = true;
      continue;
    }
    if (a === "-x" || a === "--yaw") {
      opts.yaw = Number(argv[++i] || 0);
      continue;
    }
    if (a === "-y" || a === "--pitch") {
      opts.pitch = Number(argv[++i] || 0);
      continue;
    }
    if (a === "-z" || a === "--roll") {
      opts.roll = Number(argv[++i] || 0);
      continue;
    }
    if (sub === "image" && a === "-w") {
      opts.width = Number(argv[++i] || 0);
      continue;
    }
    if (sub === "image" && (a === "-j" || a === "--webify")) {
      opts.webify = Number(argv[++i] || 0);
      continue;
    }
    if (a.startsWith("-")) {
      die(`error: Found argument '${a}' which wasn't expected, or isn't valid in this context

USAGE:
    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

For more information try --help`);
    }
    files.push(...a.split(/\s+/).filter(Boolean));
  }
  if (files.length === 0) {
    die(`error: The following required arguments were not provided:
    <input filename(s)>...

USAGE:
    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

For more information try --help`);
  }
  if (sub === "image" && !opts.width) {
    die(`error: The following required arguments were not provided:
    -w <width>

USAGE:
    executable image [FLAGS] [OPTIONS] -w <width>

For more information try --help`);
  }
  return { opts, files, sub, sawFileBeforeImage };
}

function parseMtl(file: string): Record<string, [number, number, number]> {
  const out: Record<string, [number, number, number]> = {};
  let cur = "";
  const text = fs.readFileSync(file, "utf8");
  for (const line of text.split(/\r?\n/)) {
    const t = line.trim().split(/\s+/);
    if (t[0] === "newmtl") cur = t.slice(1).join(" ");
    if (t[0] === "Kd" && cur) out[cur] = [Math.round(Number(t[1]) * 255), Math.round(Number(t[2]) * 255), Math.round(Number(t[3]) * 255)];
  }
  return out;
}

function objPanic(file: string): void {
  process.stderr.write(`
thread 'main' (211) panicked at src/inputs.rs:126:39:
called \`Result::unwrap()\` on an \`Err\` value: "filename: [${file}] couldn't load, tobj couldnt load/parse OBJ. open file failed"
note: run with \`RUST_BACKTRACE=1\` environment variable to display a backtrace
`);
  process.exit(101);
}

function matPanic(): void {
  process.stderr.write(`
thread 'main' (91) panicked at src/inputs.rs:112:39:
Expected to have materials.: OpenFileFailed
note: run with \`RUST_BACKTRACE=1\` environment variable to display a backtrace
`);
  process.exit(101);
}

function loadObj(file: string): Model {
  if (!fs.existsSync(file)) objPanic(file);
  const dir = path.dirname(file);
  const vertices: Vec3[] = [];
  const faces: Face[] = [];
  const materials: Record<string, [number, number, number]> = {};
  let curMat = "";
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const t = line.trim().split(/\s+/);
    if (t[0] === "mtllib") {
      const m = path.join(dir, t.slice(1).join(" "));
      if (!fs.existsSync(m)) matPanic();
      Object.assign(materials, parseMtl(m));
    } else if (t[0] === "usemtl") {
      curMat = t.slice(1).join(" ");
    } else if (t[0] === "v") {
      vertices.push({ x: Number(t[1]), y: Number(t[2]), z: Number(t[3]) });
    } else if (t[0] === "f") {
      const idx = t.slice(1).map((p: string) => Number(p.split("/")[0]) - 1).filter((n: number) => Number.isFinite(n));
      if (idx.length >= 3) faces.push({ idx, mat: curMat });
    }
  }
  return { vertices, faces, materials };
}

function loadStl(file: string): Model {
  if (!fs.existsSync(file)) objPanic(file);
  const vertices: Vec3[] = [];
  const faces: Face[] = [];
  let tri: number[] = [];
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const t = line.trim().split(/\s+/);
    if (t[0] === "vertex") {
      vertices.push({ x: Number(t[1]), y: Number(t[2]), z: Number(t[3]) });
      tri.push(vertices.length - 1);
      if (tri.length === 3) {
        faces.push({ idx: tri, mat: "white" });
        tri = [];
      }
    }
  }
  return { vertices, faces, materials: { white: [255, 255, 255] } };
}

function mergeModels(files: string[]): Model {
  const all: Model = { vertices: [], faces: [], materials: {} };
  for (const f of files) {
    const m = f.toLowerCase().endsWith(".stl") ? loadStl(f) : loadObj(f);
    const off = all.vertices.length;
    all.vertices.push(...m.vertices);
    Object.assign(all.materials, m.materials);
    for (const face of m.faces) all.faces.push({ ...face, idx: face.idx.map(i => i + off) });
  }
  return all;
}

function rotate(v: Vec3, o: Options): Vec3 {
  let { x, y, z } = v;
  let c = Math.cos(o.yaw), s = Math.sin(o.yaw); [y, z] = [y * c - z * s, y * s + z * c];
  c = Math.cos(o.pitch); s = Math.sin(o.pitch); [x, z] = [x * c + z * s, -x * s + z * c];
  c = Math.cos(o.roll); s = Math.sin(o.roll); [x, y] = [x * c - y * s, x * s + y * c];
  return { x, y, z };
}

function normal(a: Vec3, b: Vec3, c: Vec3): Vec3 {
  const ux = b.x - a.x, uy = b.y - a.y, uz = b.z - a.z;
  const vx = c.x - a.x, vy = c.y - a.y, vz = c.z - a.z;
  return { x: uy * vz - uz * vy, y: uz * vx - ux * vz, z: ux * vy - uy * vx };
}

function render(model: Model, opts: Options, frame = 0): { ch: string; rgb: [number, number, number] }[][] {
  const width = Math.max(1, Math.floor(opts.width || 80));
  const height = Math.max(1, Math.floor(opts.height || Math.max(1, Math.round(width * 0.5))));
  const o = { ...opts, roll: opts.roll + frame * 0.25, pitch: opts.pitch + frame * 0.12 };
  const rv = model.vertices.map(v => rotate(v, o));
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const v of rv) { minX = Math.min(minX, v.x); maxX = Math.max(maxX, v.x); minY = Math.min(minY, v.y); maxY = Math.max(maxY, v.y); }
  const sx = (width - 2) / Math.max(0.0001, maxX - minX), sy = (height - 2) / Math.max(0.0001, maxY - minY);
  const scale = Math.min(sx, sy);
  const ox = (width - (maxX - minX) * scale) / 2 - minX * scale;
  const oy = (height - (maxY - minY) * scale) / 2 + maxY * scale;
  const pix = Array.from({ length: height }, () => Array.from({ length: width }, () => ({ ch: " ", rgb: BLACK as [number, number, number], z: -Infinity })));
  const shadeChars = " .:-=+*#%@";
  const light = { x: -0.3, y: -0.4, z: 1 };
  for (const f of model.faces) {
    const pts = f.idx.map(i => rv[i]).filter(Boolean);
    if (pts.length < 3) continue;
    const n = normal(pts[0], pts[1], pts[2]);
    const len = Math.hypot(n.x, n.y, n.z) || 1;
    const intensity = Math.max(0.15, Math.min(1, (n.x * light.x + n.y * light.y + n.z * light.z) / len));
    const xs = pts.map(p => Math.round(p.x * scale + ox));
    const ys = pts.map(p => Math.round(oy - p.y * scale));
    const z = pts.reduce((a, p) => a + p.z, 0) / pts.length;
    const minpx = Math.max(0, Math.min(...xs)), maxpx = Math.min(width - 1, Math.max(...xs));
    const minpy = Math.max(0, Math.min(...ys)), maxpy = Math.min(height - 1, Math.max(...ys));
    const base = opts.colorless ? [255, 255, 255] as [number, number, number] : (model.materials[f.mat || ""] || [255, 255, 255]);
    const rgb: [number, number, number] = [Math.round(base[0] * intensity), Math.round(base[1] * intensity), Math.round(base[2] * intensity)];
    const ch = shadeChars[Math.min(shadeChars.length - 1, Math.max(1, Math.round(intensity * (shadeChars.length - 1))))];
    for (let y = minpy; y <= maxpy; y++) for (let x = minpx; x <= maxpx; x++) {
      if (inside(x + 0.5, y + 0.5, xs, ys) && z >= pix[y][x].z) {
        pix[y][x] = { ch, rgb, z };
      }
    }
  }
  return pix.map(row => row.map(p => ({ ch: p.ch, rgb: p.rgb })));
}

function inside(x: number, y: number, xs: number[], ys: number[]) {
  let inn = false;
  for (let i = 0, j = xs.length - 1; i < xs.length; j = i++) {
    if (((ys[i] > y) !== (ys[j] > y)) && x < (xs[j] - xs[i]) * (y - ys[i]) / ((ys[j] - ys[i]) || 1e-9) + xs[i]) inn = !inn;
  }
  return inn;
}

function ansiFrame(frame: { ch: string; rgb: [number, number, number] }[][]) {
  return frame.map(row => row.map(p => `\x1b[48;2;${BG[0]};${BG[1]};${BG[2]}m\x1b[38;2;${p.rgb[0]};${p.rgb[1]};${p.rgb[2]}m${p.ch}\x1b[49m\x1b[39m`).join("")).join("\n") + "\n";
}

function htmlFrame(frame: { ch: string; rgb: [number, number, number] }[][]) {
  return frame.map(row => row.map(p => `<span style="color:rgb(${p.rgb[0]},${p.rgb[1]},${p.rgb[2]})">${p.ch}`).join("")).join("\n") + " ";
}

function main() {
  const { opts, files, sub } = parseArgs(process.argv.slice(2));
  const model = mergeModels(files);
  if (sub === "image" && opts.webify) {
    const parts: string[] = ["let frames = ["];
    for (let i = 0; i < opts.webify; i++) parts.push("`\n" + htmlFrame(render(model, opts, i)) + "`" + (i + 1 < opts.webify! ? "," : ""));
    parts.push("];");
    process.stdout.write(parts.join("\n") + "\n");
    return;
  }
  process.stdout.write(ansiFrame(render(model, opts, 0)));
  if (sub !== "image" && !process.stdout.isTTY) {
    process.stderr.write('Error: IoError(Os { code: 25, kind: Uncategorized, message: "Inappropriate ioctl for device" })\n');
    process.exit(1);
  }
}

main();
