declare const require: any;
declare const process: any;
const fs = require('fs');
const path = require('path');

type Attrs = Record<string, string>;
type XmlNode = { name: string; local: string; attrs: Attrs; children: XmlNode[]; text: string };

type Field = { name: string; type: string; xmlName: string; ns?: string; attr?: boolean; array?: boolean; comment?: string; inline?: Field[]; chardata?: boolean };
type TypeDef = { name: string; kind: 'struct'|'alias'|'datetime'; ns?: string; fields: Field[]; base?: string; enumValues?: {name:string; value:string; comment?:string}[]; xmlName?: boolean };
type Message = { name: string; element?: string; type?: string };
type Operation = { name: string; input?: string; output?: string; action: string };

function localName(n: string): string { const i = n.indexOf(':'); return i >= 0 ? n.slice(i + 1) : n; }
function decodeXml(s: string): string { return s.replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&'); }
function parseAttrs(s: string): Attrs {
  const attrs: Attrs = {};
  const re = /([A-Za-z_][\w.:-]*)\s*=\s*("[^"]*"|'[^']*')/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s))) attrs[m[1]] = decodeXml(m[2].slice(1, -1));
  return attrs;
}
function parseXml(xml: string): XmlNode {
  xml = xml.replace(/^\uFEFF/, '').replace(/<\?[^>]*\?>/g, '').replace(/<!--[\s\S]*?-->/g, '');
  const root: XmlNode = { name: '#root', local: '#root', attrs: {}, children: [], text: '' };
  const stack: XmlNode[] = [root];
  const re = /<[^>]+>|[^<]+/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) {
    const tok = m[0];
    if (tok.startsWith('<![CDATA[')) { stack[stack.length - 1].text += tok.slice(9, -3); continue; }
    if (!tok.startsWith('<')) { const t = decodeXml(tok); if (t.trim()) stack[stack.length - 1].text += t; continue; }
    if (/^<\//.test(tok)) { if (stack.length > 1) stack.pop(); continue; }
    if (/^<!/.test(tok)) continue;
    const self = /\/\s*>$/.test(tok);
    const body = tok.slice(1, tok.length - (self ? 2 : 1)).trim();
    const sp = body.search(/\s/);
    const name = sp < 0 ? body : body.slice(0, sp);
    const attrText = sp < 0 ? '' : body.slice(sp + 1);
    const node: XmlNode = { name, local: localName(name), attrs: parseAttrs(attrText), children: [], text: '' };
    stack[stack.length - 1].children.push(node);
    if (!self) stack.push(node);
  }
  return root;
}
function walk(n: XmlNode, pred: (n: XmlNode) => boolean, out: XmlNode[] = []): XmlNode[] { for (const c of n.children) { if (pred(c)) out.push(c); walk(c, pred, out); } return out; }
function child(n: XmlNode, local: string): XmlNode | undefined { return n.children.find(c => c.local === local); }
function children(n: XmlNode, local: string): XmlNode[] { return n.children.filter(c => c.local === local); }
function attr(n: XmlNode, key: string): string | undefined { return n.attrs[key] ?? n.attrs[Object.keys(n.attrs).find(k => localName(k) === key) || '']; }
function stripPrefix(s?: string): string | undefined { if (!s) return undefined; const i = s.indexOf(':'); return i >= 0 ? s.slice(i + 1) : s; }
function documentation(n: XmlNode): string | undefined { const d = walk(n, x => x.local === 'documentation')[0]; return d?.text.trim() || undefined; }
function sanitizeIdent(s: string): string { const parts = s.replace(/[^A-Za-z0-9]+/g, ' ').trim().split(/\s+/).filter(Boolean); let r = parts.map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(''); if (!r) r = 'Value'; if (/^[0-9]/.test(r)) r = 'N' + r; const reserved = new Set(['Map','String','Error','Interface','Func','Var','Const','Package','Import','Default','Range','Select','Case','Defer','Go']); return reserved.has(r) ? r + '_' : r; }
function publicName(s: string, pub: boolean): string { const r = sanitizeIdent(s); return pub ? r : r.charAt(0).toLowerCase() + r.slice(1); }
function lowerFirst(s: string): string { return s.charAt(0).toLowerCase() + s.slice(1); }
function goType(xsd?: string, pub = true): string {
  const t = stripPrefix(xsd) || 'string';
  const map: Record<string,string> = { string:'string', normalizedString:'string', token:'string', language:'string', Name:'string', NCName:'NCName', NMTOKEN:'string', anyURI:'AnyURI', boolean:'bool', bool:'bool', byte:'int8', unsignedByte:'uint8', short:'int16', unsignedShort:'uint16', int:'int', integer:'int', nonPositiveInteger:'int', negativeInteger:'int', long:'int64', unsignedInt:'uint', unsignedLong:'uint64', float:'float32', double:'float64', decimal:'float64', dateTime:'soap.XSDDateTime', date:'soap.XSDDate', time:'soap.XSDTime', base64Binary:'[]byte', hexBinary:'[]byte', anyType:'AnyType' };
  return map[t] || publicName(t, pub);
}
function xmlTag(f: Field): string { if (f.chardata) return ',chardata'; const ns = f.ns ? f.ns + ' ' : ''; const suffix = f.attr ? ',attr,omitempty' : ',omitempty'; return ns + f.xmlName + suffix; }
function jsonTag(f: Field): string { return f.chardata ? '-,' : f.xmlName + ',omitempty'; }

function parseFields(container: XmlNode, ns: string, pub: boolean): Field[] {
  const group = child(container, 'sequence') || child(container, 'all') || child(container, 'choice') || container;
  const fields: Field[] = [];
  for (const e of children(group, 'element')) {
    const name = attr(e, 'name') || stripPrefix(attr(e, 'ref')) || 'Value';
    const max = attr(e, 'maxOccurs');
    const min = attr(e, 'minOccurs');
    let typ = goType(attr(e, 'type'), pub);
    const comment = documentation(e);
    let inline: Field[] | undefined;
    const ct = child(e, 'complexType');
    const st = child(e, 'simpleType');
    if (ct) {
      const sc = child(ct, 'simpleContent');
      const ext = sc ? child(sc, 'extension') : undefined;
      if (ext) {
        typ = 'struct';
        inline = [{ name: 'Value', type: goType(attr(ext, 'base'), pub), xmlName: '', chardata: true }];
        for (const a of children(ext, 'attribute')) inline.push(parseAttribute(a, ns, pub));
      } else {
        typ = publicName(name, pub);
        inline = parseFields(ct, ns, pub).concat(parseAttributes(ct, ns, pub));
      }
    } else if (st) typ = goType(attr(child(st, 'restriction') || st, 'base'), pub);
    fields.push({ name: publicName(name, pub), type: typ, xmlName: name, ns: undefined, array: max === 'unbounded' || (!!max && max !== '1'), comment, inline });
  }
  return fields;
}
function parseAttribute(a: XmlNode, ns: string, pub: boolean): Field {
  const name = attr(a, 'name') || stripPrefix(attr(a, 'ref')) || 'Attr';
  let typ = goType(attr(a, 'type'), pub);
  if (!attr(a, 'type') && child(a, 'simpleType')) typ = 'string';
  if (attr(a, 'type') && !/^(string|bool|int|int8|uint8|int16|uint16|int64|uint|uint64|float32|float64|\[\]byte|AnyURI|NCName|AnyType|soap\.)/.test(typ)) typ = '*' + typ;
  return { name: publicName(name, pub), type: typ, xmlName: name, ns, attr: true, comment: documentation(a) };
}
function parseAttributes(ct: XmlNode, ns: string, pub: boolean): Field[] { return children(ct, 'attribute').map(a => parseAttribute(a, ns, pub)); }
function enumVals(st: XmlNode, typeName: string): {name:string; value:string; comment?:string}[] {
  const vals: {name:string; value:string; comment?:string}[] = [];
  for (const e of walk(st, n => n.local === 'enumeration')) {
    const v = attr(e, 'value'); if (!v) continue;
    vals.push({ name: typeName + sanitizeIdent(v), value: v, comment: documentation(e) });
  }
  return vals;
}
function collect(root: XmlNode, pub: boolean) {
  const defs = walk(root, n => n.local === 'definitions')[0] || root.children[0] || root;
  const targetNs = attr(defs, 'targetNamespace') || '';
  const schemas = walk(root, n => n.local === 'schema');
  const types: TypeDef[] = [];
  for (const s of schemas) {
    const ns = attr(s, 'targetNamespace') || targetNs;
    for (const e of children(s, 'element')) {
      const raw = attr(e, 'name'); if (!raw) continue;
      const name = publicName(raw, pub);
      const ct = child(e, 'complexType'); const st = child(e, 'simpleType');
      if (ct) types.push({ name, kind: 'struct', ns, xmlName: true, fields: parseFields(ct, ns, pub).concat(parseAttributes(ct, ns, pub)) });
      else if (st) {
        const base = goType(attr(child(st, 'restriction') || st, 'base'), pub);
        types.push({ name, kind: base === 'soap.XSDDateTime' ? 'datetime' : 'alias', ns, fields: [], base, enumValues: enumVals(st, name), xmlName: false });
      } else if (attr(e, 'type')) {
        const gt = goType(attr(e, 'type'), pub);
        if (gt.startsWith('soap.XSDDateTime')) types.push({ name, kind: 'datetime', fields: [], base: gt });
        else types.push({ name, kind: 'alias', fields: [], base: gt });
      }
    }
    for (const ct of children(s, 'complexType')) {
      const raw = attr(ct, 'name'); if (!raw) continue;
      const name = publicName(raw, pub);
      const sc = child(ct, 'simpleContent'); const ext = sc ? child(sc, 'extension') : undefined;
      let fields: Field[] = [];
      if (ext) fields = ([{ name: 'Value', type: goType(attr(ext, 'base'), pub), xmlName: '', chardata: true }] as Field[]).concat(children(ext, 'attribute').map(a => parseAttribute(a, ns, pub))); 
      else fields = parseFields(ct, ns, pub).concat(parseAttributes(ct, ns, pub));
      types.push({ name, kind: 'struct', ns, fields });
    }
    for (const st of children(s, 'simpleType')) {
      const raw = attr(st, 'name'); if (!raw) continue;
      const name = publicName(raw, pub); const base = goType(attr(child(st, 'restriction') || st, 'base'), pub);
      types.push({ name, kind: base === 'soap.XSDDateTime' ? 'datetime' : 'alias', fields: [], base, enumValues: enumVals(st, name) });
    }
  }
  const messages: Record<string, Message> = {};
  for (const m of walk(root, n => n.local === 'message')) {
    const nm = attr(m, 'name'); if (!nm) continue;
    const p = child(m, 'part');
    messages[nm] = { name: nm, element: stripPrefix(p && attr(p, 'element')), type: stripPrefix(p && attr(p, 'type')) };
  }
  const actions: Record<string,string> = {};
  for (const op of walk(root, n => n.local === 'operation')) {
    const nm = attr(op, 'name'); if (!nm) continue;
    const so = child(op, 'operation');
    if (so && so.name.includes(':')) actions[nm] = attr(so, 'soapAction') ?? "''";
  }
  const port = walk(root, n => n.local === 'portType')[0];
  const serviceName = port ? publicName(attr(port, 'name') || 'Service', pub) : undefined;
  const operations: Operation[] = [];
  if (port) for (const op of children(port, 'operation')) {
    const nm = attr(op, 'name') || 'Operation'; const inp = stripPrefix(attr(child(op, 'input') || op, 'message')); const out = stripPrefix(attr(child(op, 'output') || op, 'message'));
    operations.push({ name: publicName(nm, pub), input: inp && (messages[inp]?.element || messages[inp]?.type), output: out && (messages[out]?.element || messages[out]?.type), action: actions[nm] ?? "''" });
  }
  return { types: uniqueTypes(types), serviceName, operations };
}
function uniqueTypes(types: TypeDef[]): TypeDef[] { const seen = new Set<string>(); const out: TypeDef[] = []; for (const t of types) { if (seen.has(t.name)) continue; seen.add(t.name); out.push(t); } return out; }
function renderField(f: Field): string {
  if (f.inline) {
    let s = `${f.name} ` + (f.array ? '[]' : '') + `struct {\n`;
    for (const sf of f.inline) { if (sf.comment) s += `\n\t\t// ${sf.comment}\n`; s += `\t\t${sf.name} ${sf.type} \`xml:"${xmlTag(sf)}" json:"${jsonTag(sf)}"\`\n`; }
    s += `\t} \`xml:"${xmlTag(f)}" json:"${jsonTag(f)}"\``;
    return s;
  }
  return `${f.name} ${f.array ? '[]' : ''}${f.type} \`xml:"${xmlTag(f)}" json:"${jsonTag(f)}"\``;
}
function renderGo(pkg: string, data: ReturnType<typeof collect>): string {
  let out = `// Code generated by gowsdl DO NOT EDIT.\n\npackage ${pkg}\n\nimport (\n\t"context"\n\t"encoding/xml"\n\t"github.com/hooklift/gowsdl/soap"\n\t"time"\n)\n\n// against "unused imports"\nvar _ time.Time\nvar _ xml.Name\n\ntype AnyType struct {\n\tInnerXML string \`xml:",innerxml"\`\n}\n\ntype AnyURI string\n\ntype NCName string\n\n`;
  for (const t of data.types) {
    if (t.kind === 'struct') {
      out += `type ${t.name} struct {\n`;
      if (t.xmlName && t.ns) out += `\tXMLName xml.Name \`xml:"${t.ns} ${t.name}"\`\n\n`;
      for (const f of t.fields) { if (f.comment) out += `\t// ${f.comment}\n`; out += `\t${renderField(f)}\n`; }
      out += `}\n\n`;
    } else if (t.kind === 'datetime') {
      out += `type ${t.name} soap.XSDDateTime\n\nfunc (xdt ${t.name}) MarshalXML(e *xml.Encoder, start xml.StartElement) error {\n\treturn soap.XSDDateTime(xdt).MarshalXML(e, start)\n}\n\nfunc (xdt *${t.name}) UnmarshalXML(d *xml.Decoder, start xml.StartElement) error {\n\treturn (*soap.XSDDateTime)(xdt).UnmarshalXML(d, start)\n}\n\n`;
    } else {
      out += `type ${t.name} ${t.base || 'string'}\n\n`;
      if (t.enumValues && t.enumValues.length) { out += `const (\n`; for (const ev of t.enumValues) { if (ev.comment) out += `\n\t// ${ev.comment}\n`; out += `\t${ev.name} ${t.name} = "${ev.value}"\n`; } out += `)\n\n`; }
    }
  }
  if (data.serviceName && data.operations.length) {
    const iface = data.serviceName; const recv = lowerFirst(iface);
    out += `type ${iface} interface {\n`;
    for (const op of data.operations) { out += `\t${op.name}(request *${op.input || 'AnyType'}) (*${op.output || 'AnyType'}, error)\n\n\t${op.name}Context(ctx context.Context, request *${op.input || 'AnyType'}) (*${op.output || 'AnyType'}, error)\n`; }
    out += `}\n\n`;
    out += `type ${recv} struct {\n\tclient *soap.Client\n}\n\nfunc New${iface}(client *soap.Client) ${iface} {\n\treturn &${recv}{\n\t\tclient: client,\n\t}\n}\n\n`;
    for (const op of data.operations) {
      out += `func (service *${recv}) ${op.name}Context(ctx context.Context, request *${op.input || 'AnyType'}) (*${op.output || 'AnyType'}, error) {\n\tresponse := new(${op.output || 'AnyType'})\n\terr := service.client.CallContext(ctx, "${op.action}", request, response)\n\tif err != nil {\n\t\treturn nil, err\n\t}\n\n\treturn response, nil\n}\n\n`;
      out += `func (service *${recv}) ${op.name}(request *${op.input || 'AnyType'}) (*${op.output || 'AnyType'}, error) {\n\treturn service.${op.name}Context(\n\t\tcontext.Background(),\n\t\trequest,\n\t)\n}\n\n`;
    }
  }
  return out;
}
function usage(exit = 0, err?: string): void { if (err) console.error(err); console.error(`Usage: ./executable [options] myservice.wsdl\n  -d string\n    \tDirectory under which package directory will be created (default "./")\n  -i\tSkips TLS Verification\n  -make-public\n    \tMake the generated types public/exported (default true)\n  -o string\n    \tFile where the generated code will be saved (default "myservice.go")\n  -p string\n    \tPackage under which code will be generated (default "myservice")\n  -v\tShows gowsdl version`); process.exit(exit); }
function main() {
  const args = process.argv.slice(2); let d = './', o = 'myservice.go', p = 'myservice', pub = true; const files: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--help' || a === '-h') usage(0);
    else if (a === '-v') { console.log('🍀  v0.5.0'); return; }
    else if (a === '-i') {}
    else if (a === '-d' || a === '-o' || a === '-p') { if (i + 1 >= args.length) usage(2, `flag needs an argument: ${a}`); const val = args[++i]; if (a === '-d') d = val; else if (a === '-o') o = val; else p = val; }
    else if (a === '-make-public') pub = true;
    else if (a.startsWith('-make-public=')) pub = a.split('=')[1] !== 'false';
    else if (a.startsWith('-')) usage(2, `flag provided but not defined: ${a}`);
    else files.push(a);
  }
  if (files.length === 0) usage(0);
  const input = path.resolve(files[0]);
  console.log(`🍀  Reading file ${input}`);
  let xml: string;
  try { xml = fs.readFileSync(input, 'utf8'); } catch (e: any) { console.log(`🍀  open ${input}: no such file or directory`); process.exit(1); }
  try {
    const parsed = parseXml(xml); const data = collect(parsed, pub); const code = renderGo(p, data);
    const dir = path.join(d, p); fs.mkdirSync(dir); fs.writeFileSync(path.join(dir, o), code);
    console.log('🍀  Done 👍');
  } catch (e: any) { console.log(`🍀  ${e.message}`); process.exit(1); }
}
main();
