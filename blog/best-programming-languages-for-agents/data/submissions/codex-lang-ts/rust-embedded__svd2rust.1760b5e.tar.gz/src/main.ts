// @ts-nocheck
import * as fs from "fs";
import * as path from "path";

type XmlNode = { name: string; attrs: Record<string, string>; children: XmlNode[]; text: string };
type Field = { name: string; desc: string; offset: number; width: number; access?: string; enums: EnumVal[] };
type EnumVal = { name: string; desc: string; value: string };
type Register = { name: string; desc: string; offset: number; size: number; access: string; reset: bigint; fields: Field[] };
type Peripheral = { name: string; desc: string; base: bigint; group?: string; registers: Register[]; interrupts: { name: string; value: number; desc: string }[] };

const VERSION = "svd2rust 0.37.1 (e29353d 2026-03-03)";

function usage(long = false): string {
  const identTypes = '["peripheral_singleton", "enum_name", "field_accessor", "peripheral_mod", "field_reader", "peripheral", "register_mod", "cluster_accessor", "field_writer", "register_accessor", "enum_value_accessor", "enum_read_name", "cluster_mod", "interrupt", "register", "cluster", "peripheral_feature", "peripheral_spec", "register_spec", "enum_value", "enum_write_name"]';
  const lines = [
    "Generate a Rust API from SVD files",
    "",
    "Usage: executable [OPTIONS]",
    "",
    "Options:",
    "  -i <FILE>",
    "          Input SVD file",
    "  -o, --output-dir <PATH>",
    "          Directory to place generated files",
    "  -c, --config <TOML_FILE>",
    "          Config TOML file",
    "      --settings <YAML_FILE>",
    "          Target-specific settings YAML file",
    "      --edition <YEAR>",
    "          Rust edition of generated code",
    "      --target <ARCH>",
    "          Target architecture",
    "      --atomics",
    "          Generate atomic register modification API",
    "      --atomics-feature <FEATURE>",
    "          add feature gating for atomic register modification API",
    "      --ignore-groups",
    "          Don't add alternateGroup name as prefix to register name",
    "      --keep-list",
    "          Keep lists when generating code of dimElement, instead of trying to generate arrays",
    "  -g, --generic-mod",
    "          Push generic mod in separate file",
    "      --feature-group",
    "          Use group_name of peripherals as feature",
    "      --feature-peripheral",
    "          Use independent cfg feature flags for each peripheral",
    "  -f, --ident-format <ident_format>",
    "          Specify `-f type:prefix:case:suffix` to change default ident formatting.",
    `          Allowed values of \`type\` are ${identTypes}.`,
    "          Allowed cases are `unchanged` (''), `pascal` ('p'), `constant` ('c') and `snake` ('s').",
    "          ",
    "      --ident-formats-theme <THEME>",
    "          A set of `ident_format` settings. `new` or `legacy`",
    "      --field-names-for-enums",
    "          Use field name for enumerations even when enumeratedValues has a name",
    "      --max-cluster-size",
    "          Use array increment for cluster size",
    "      --impl-debug",
    "          implement Debug for readable blocks and registers",
    "      --impl-debug-feature <FEATURE>",
    "          Add feature gating for block and register debug implementation",
    "      --impl-defmt <FEATURE>",
    "          Add automatic defmt implementation for enumerated values",
    "  -m, --make-mod",
    "          Create mod.rs instead of lib.rs, without inner attributes",
    "      --skip-crate-attributes",
    "          Do not generate crate attributes",
    "  -s, --strict",
    "          Make advanced checks due to parsing SVD",
    "      --source-type <source_type>",
    "          Specify file/stream format",
    "      --reexport-core-peripherals",
    "          For Cortex-M target reexport peripherals from cortex-m crate",
    "      --reexport-interrupt",
    "          Reexport interrupt macro from cortex-m-rt like crates",
    "  -b, --base-address-shift <base_address_shift>",
    "          Add offset to all base addresses on all peripherals in the SVD file.",
    `  -l, --log <log_level>`,
    long ? "          Choose which messages to log (overrides RUST_LOG)\n          \n          [possible values: off, error, warn, info, debug, trace]" : "          Choose which messages to log (overrides RUST_LOG) [possible values: off, error, warn, info, debug, trace]",
    "  -h, --help",
    long ? "          Print help (see a summary with '-h')" : "          Print help (see more with '--help')",
    "  -V, --version",
    "          Print version",
  ];
  return lines.join("\n");
}

function parseArgs(argv: string[]) {
  const opts: any = { out: ".", makeMod: false, skipAttrs: false, baseShift: 0n };
  const valueOpts = new Set(["-i", "-o", "--output-dir", "-c", "--config", "--settings", "--edition", "--target", "--atomics-feature", "-f", "--ident-format", "--ident-formats-theme", "--impl-debug-feature", "--impl-defmt", "--source-type", "-b", "--base-address-shift", "-l", "--log"]);
  const boolOpts = new Set(["--atomics", "--ignore-groups", "--keep-list", "-g", "--generic-mod", "--feature-group", "--feature-peripheral", "--field-names-for-enums", "--max-cluster-size", "--impl-debug", "-m", "--make-mod", "--skip-crate-attributes", "-s", "--strict", "--reexport-core-peripherals", "--reexport-interrupt"]);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h") { console.log(usage(false)); process.exit(0); }
    if (a === "--help") { console.log(usage(true)); process.exit(0); }
    if (a === "-V" || a === "--version") { console.log(VERSION); process.exit(0); }
    if (valueOpts.has(a)) {
      const v = argv[++i];
      if (v == null) die(`error: a value is required for '${a}' but none was supplied`, 2);
      if (a === "-i") opts.input = v;
      else if (a === "-o" || a === "--output-dir") opts.out = v;
      else if (a === "-b" || a === "--base-address-shift") opts.baseShift = parseBig(v);
      continue;
    }
    if (boolOpts.has(a)) {
      if (a === "-m" || a === "--make-mod") opts.makeMod = true;
      if (a === "-g" || a === "--generic-mod") opts.genericMod = true;
      if (a === "--skip-crate-attributes") opts.skipAttrs = true;
      continue;
    }
    if (a.startsWith("-")) die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.`, 2);
    opts.input = a;
  }
  return opts;
}

function die(msg: string, code = 1): never {
  console.error(msg);
  process.exit(code);
}

function logInfo(msg: string) { console.error(`[INFO  svd2rust] ${msg}`); }
function logError(msg: string) { console.error(`[ERROR svd2rust] ${msg}`); }

function decodeXml(s: string): string {
  return s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
}

function parseXml(xml: string): XmlNode {
  xml = xml.replace(/^\uFEFF/, "").replace(/<\?xml[\s\S]*?\?>/g, "").replace(/<!--[\s\S]*?-->/g, "");
  const root: XmlNode = { name: "#document", attrs: {}, children: [], text: "" };
  const stack = [root];
  const re = /<!\[CDATA\[([\s\S]*?)\]\]>|<([^>]+)>|([^<]+)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml))) {
    const cur = stack[stack.length - 1];
    if (m[1] != null) { cur.text += m[1]; continue; }
    if (m[3] != null) { cur.text += decodeXml(m[3]); continue; }
    let tag = m[2].trim();
    if (!tag || tag.startsWith("!")) continue;
    if (tag.startsWith("/")) { stack.pop(); continue; }
    const self = tag.endsWith("/");
    if (self) tag = tag.slice(0, -1).trim();
    const space = tag.search(/\s/);
    const rawName = space < 0 ? tag : tag.slice(0, space);
    const name = rawName.split(":").pop() || rawName;
    const attrText = space < 0 ? "" : tag.slice(space + 1);
    const attrs: Record<string, string> = {};
    attrText.replace(/([\w:.-]+)\s*=\s*("([^"]*)"|'([^']*)')/g, (_, k, __, v1, v2) => {
      attrs[(k as string).split(":").pop() || k] = decodeXml(v1 ?? v2 ?? "");
      return "";
    });
    const node: XmlNode = { name, attrs, children: [], text: "" };
    cur.children.push(node);
    if (!self) stack.push(node);
  }
  if (root.children.length === 0) throw new Error("the document does not have a root node");
  return root.children[0];
}

function kids(n: XmlNode | undefined, name: string): XmlNode[] { return n ? n.children.filter(c => c.name === name) : []; }
function kid(n: XmlNode | undefined, name: string): XmlNode | undefined { return n?.children.find(c => c.name === name); }
function text(n: XmlNode | undefined, name: string, def = ""): string {
  const c = kid(n, name);
  return c ? c.text.trim() : def;
}
function ownText(n: XmlNode | undefined, def = ""): string { return n ? n.text.trim() : def; }
function parseBig(s: string | undefined, def = 0n): bigint {
  if (!s) return def;
  let t = s.trim().replace(/_/g, "");
  if (!t) return def;
  if (/^#/.test(t)) t = "0x" + t.slice(1);
  if (/^[01]+b$/i.test(t)) return BigInt("0b" + t.slice(0, -1));
  if (/^0x/i.test(t)) return BigInt(t);
  return BigInt(parseInt(t, 10));
}
function parseNum(s: string | undefined, def = 0): number { return Number(parseBig(s, BigInt(def))); }

function parseDimName(name: string, idx: string): string {
  if (name.includes("%s")) return name.replace(/%s/g, idx);
  if (name.includes("[%s]")) return name.replace(/\[%s\]/g, idx);
  if (name.includes("[]")) return name.replace(/\[\]/g, idx);
  return name + idx;
}

function dimIndices(n: XmlNode): string[] {
  const dim = parseNum(text(n, "dim"), 0);
  if (!dim) return [""];
  const idx = text(n, "dimIndex");
  if (idx) return idx.split(/\s*,\s*/).filter(Boolean);
  return Array.from({ length: dim }, (_, i) => String(i));
}

function parseField(n: XmlNode): Field[] {
  const out: Field[] = [];
  for (const ix of dimIndices(n)) {
    let name = text(n, "name", "FIELD");
    if (ix) name = parseDimName(name, ix);
    let offset = parseNum(text(n, "bitOffset"), -1);
    let width = parseNum(text(n, "bitWidth"), -1);
    const range = text(n, "bitRange");
    if ((offset < 0 || width < 0) && range) {
      const m = range.match(/\[(\d+)\s*:\s*(\d+)\]/);
      if (m) { const hi = +m[1], lo = +m[2]; offset = Math.min(hi, lo); width = Math.abs(hi - lo) + 1; }
    }
    if (offset < 0) offset = parseNum(text(n, "lsb"), 0);
    if (width < 0) width = parseNum(text(n, "msb"), offset) - offset + 1;
    const enums: EnumVal[] = [];
    for (const evs of kids(n, "enumeratedValues")) for (const ev of kids(evs, "enumeratedValue")) {
      enums.push({ name: text(ev, "name", "VALUE"), desc: text(ev, "description"), value: text(ev, "value", "0") });
    }
    out.push({ name, desc: text(n, "description"), offset, width, access: text(n, "access"), enums });
  }
  return out;
}

function parseRegister(n: XmlNode, inherited: Partial<Register> = {}): Register[] {
  const out: Register[] = [];
  const inc = parseNum(text(n, "dimIncrement"), 0);
  let ord = 0;
  for (const ix of dimIndices(n)) {
    let name = text(n, "name", inherited.name || "REG");
    if (ix) name = parseDimName(name, ix);
    const fields = kids(kid(n, "fields"), "field").flatMap(f => parseField(f));
    out.push({
      name,
      desc: text(n, "description", inherited.desc || ""),
      offset: parseNum(text(n, "addressOffset"), inherited.offset || 0) + (ix ? inc * ord : 0),
      size: parseNum(text(n, "size"), inherited.size || 32),
      access: text(n, "access", inherited.access || "read-write"),
      reset: parseBig(text(n, "resetValue"), inherited.reset ?? 0n),
      fields: fields.length ? fields : (inherited.fields || []),
    });
    ord++;
  }
  return out;
}

function parseRegisters(container: XmlNode | undefined, inheritedMap: Map<string, Register> = new Map(), prefix = "", baseOffset = 0): Register[] {
  const regs: Register[] = [];
  for (const n of container?.children || []) {
    if (n.name === "register") {
      const inherited = n.attrs.derivedFrom ? inheritedMap.get(n.attrs.derivedFrom) || inheritedMap.get(prefix + n.attrs.derivedFrom) || {} : {};
      for (const r of parseRegister(n, inherited)) {
        r.name = prefix + r.name;
        r.offset += baseOffset;
        inheritedMap.set(r.name, r);
        regs.push(r);
      }
    } else if (n.name === "cluster") {
      const inc = parseNum(text(n, "dimIncrement"), 0);
      let ord = 0;
      for (const ix of dimIndices(n)) {
        let cname = text(n, "name", "CLUSTER");
        if (ix) cname = parseDimName(cname, ix);
        const pfx = prefix + cname + "_";
        const off = baseOffset + parseNum(text(n, "addressOffset"), 0) + (ix ? inc * ord : 0);
        regs.push(...parseRegisters(n, inheritedMap, pfx, off));
        ord++;
      }
    }
  }
  return regs;
}

function parseDevice(root: XmlNode, baseShift: bigint) {
  if (root.name !== "device") throw new Error(`expected <device> as root, found <${root.name}>`);
  const devName = text(root, "name", "DEVICE");
  const nvic = text(kid(root, "cpu"), "nvicPrioBits", "");
  const periphMap = new Map<string, Peripheral>();
  const peripherals: Peripheral[] = [];
  for (const p of kids(kid(root, "peripherals"), "peripheral")) {
    const derived = p.attrs.derivedFrom ? periphMap.get(p.attrs.derivedFrom) : undefined;
    const regMap = new Map<string, Register>();
    derived?.registers.forEach(r => regMap.set(r.name, r));
    const regs: Register[] = parseRegisters(kid(p, "registers"), regMap);
    const interrupts = kids(p, "interrupt").map(i => ({ name: text(i, "name", "INTERRUPT"), value: parseNum(text(i, "value"), 0), desc: text(i, "description") }));
    const per: Peripheral = {
      name: text(p, "name", derived?.name || "PERIPHERAL"),
      desc: text(p, "description", derived?.desc || ""),
      base: parseBig(text(p, "baseAddress"), derived?.base || 0n) + baseShift,
      group: text(p, "groupName", derived?.group || ""),
      registers: regs.length ? regs : (derived?.registers || []),
      interrupts: interrupts.length ? interrupts : (derived?.interrupts || []),
    };
    periphMap.set(per.name, per);
    peripherals.push(per);
  }
  return { name: devName, nvic, peripherals };
}

function words(s: string): string[] {
  return (s || "").replace(/%s/g, "").replace(/([a-z0-9])([A-Z])/g, "$1_$2").split(/[^A-Za-z0-9]+/).filter(Boolean);
}
function snake(s: string): string {
  const w = words(s).join("_").toLowerCase();
  return /^[0-9]/.test(w) ? "_" + w : (w || "x");
}
function pascal(s: string): string {
  const w = words(s).map(x => x.charAt(0).toUpperCase() + x.slice(1).toLowerCase()).join("");
  return /^[0-9]/.test(w) ? "_" + w : (w || "X");
}
function constName(s: string): string { return snake(s).toUpperCase(); }
function escDoc(s: string): string { return (s || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r?\n/g, "\\n"); }
function fmtHex(v: bigint): string {
  const h = v.toString(16);
  return "0x" + h.replace(/\B(?=(?:[0-9a-f]{4})+(?![0-9a-f]))/g, "_");
}
function ux(size: number): string { return size <= 8 ? "u8" : size <= 16 ? "u16" : size <= 32 ? "u32" : "u64"; }
function accessFlags(a: string) {
  const s = (a || "read-write").toLowerCase();
  return { r: !s.includes("write-only") && !s.includes("writeonly"), w: !s.includes("read-only") && !s.includes("readonly"), label: s.includes("read-only") ? "r" : s.includes("write-only") ? "w" : "rw" };
}

function prelude(dev: string, nvic: string, attrs: boolean): string {
  const attr = attrs ? `#![doc = "Peripheral access API for ${escDoc(dev)} microcontrollers (generated using svd2rust v0.37.1 (e29353d 2026-03-03))"]\n#![allow(non_camel_case_types)]\n#![allow(non_snake_case)]\n#![no_std]\n` : "";
  return `${attr}
${nvic ? `#[doc = r"Number available in the NVIC for configuring priority"]\npub const NVIC_PRIO_BITS: u8 = ${nvic};\n` : ""}
use core::cell::UnsafeCell;
use core::marker::PhantomData;

pub trait RawReg: Copy + From<bool> + core::ops::BitOr<Output=Self> + core::ops::BitAnd<Output=Self> + core::ops::Not<Output=Self> + core::ops::Shl<u8, Output=Self> {
    const ZERO: Self;
    const ONE: Self;
    fn mask(width: u8) -> Self;
}
macro_rules! impl_raw { ($t:ty) => { impl RawReg for $t { const ZERO: Self = 0; const ONE: Self = 1; fn mask(width: u8) -> Self { if width as usize >= core::mem::size_of::<$t>() * 8 { <$t>::MAX } else { ((1 as $t) << width) - 1 } } } }; }
impl_raw!(u8); impl_raw!(u16); impl_raw!(u32); impl_raw!(u64);
pub trait RegisterSpec { type Ux: RawReg; }
pub trait Readable: RegisterSpec {}
pub trait Writable: RegisterSpec { type Safety; const ZERO_TO_MODIFY_FIELDS_BITMAP: Self::Ux = <Self::Ux as RawReg>::ZERO; const ONE_TO_MODIFY_FIELDS_BITMAP: Self::Ux = <Self::Ux as RawReg>::ZERO; }
pub trait Resettable: RegisterSpec { const RESET_VALUE: Self::Ux = <Self::Ux as RawReg>::ZERO; fn reset_value() -> Self::Ux { Self::RESET_VALUE } }
pub struct Safe; pub struct Unsafe;
pub trait PeripheralSpec { type RB; const ADDRESS: usize; const NAME: &'static str; }
pub struct Periph<PER: PeripheralSpec> { _marker: PhantomData<PER> }
unsafe impl<PER: PeripheralSpec> Send for Periph<PER> {}
impl<PER: PeripheralSpec> Periph<PER> { pub const PTR: *const PER::RB = PER::ADDRESS as *const _; pub const fn ptr() -> *const PER::RB { Self::PTR } pub unsafe fn steal() -> Self { Self { _marker: PhantomData } } }
impl<PER: PeripheralSpec> core::ops::Deref for Periph<PER> { type Target = PER::RB; fn deref(&self) -> &Self::Target { unsafe { &*Self::PTR } } }
pub struct VolatileCell<T> { value: UnsafeCell<T> }
unsafe impl<T: Send> Send for VolatileCell<T> {}
impl<T: Copy> VolatileCell<T> { pub const fn new(value: T) -> Self { Self { value: UnsafeCell::new(value) } } pub fn get(&self) -> T { unsafe { core::ptr::read_volatile(self.value.get()) } } pub fn set(&self, value: T) { unsafe { core::ptr::write_volatile(self.value.get(), value) } } }
#[repr(transparent)] pub struct Reg<REG: RegisterSpec> { register: VolatileCell<REG::Ux>, _marker: PhantomData<REG> }
impl<REG: RegisterSpec> Reg<REG> { pub fn as_ptr(&self) -> *mut REG::Ux { self.register.value.get() } }
pub struct R<REG: RegisterSpec> { bits: REG::Ux, _reg: PhantomData<REG> }
impl<REG: RegisterSpec> R<REG> { pub const fn bits(&self) -> REG::Ux { self.bits } }
pub struct W<REG: Writable> { bits: REG::Ux, _reg: PhantomData<REG> }
impl<REG: Writable> W<REG> { pub unsafe fn bits(&mut self, bits: REG::Ux) -> &mut Self { self.bits = bits; self } }
impl<REG: Readable> Reg<REG> { pub fn read(&self) -> R<REG> { R { bits: self.register.get(), _reg: PhantomData } } }
impl<REG: Writable> Reg<REG> { pub fn write<F>(&self, f: F) where for<'w> F: FnOnce(&'w mut W<REG>) -> &'w mut W<REG>, REG: Resettable { let mut w = W { bits: REG::RESET_VALUE, _reg: PhantomData }; f(&mut w); self.register.set(w.bits); } pub fn write_with_zero<F>(&self, f: F) where for<'w> F: FnOnce(&'w mut W<REG>) -> &'w mut W<REG> { let mut w = W { bits: <REG::Ux as RawReg>::ZERO, _reg: PhantomData }; f(&mut w); self.register.set(w.bits); } }
impl<REG: Readable + Writable> Reg<REG> { pub fn modify<F>(&self, f: F) where for<'w> F: FnOnce(&R<REG>, &'w mut W<REG>) -> &'w mut W<REG> { let bits = self.register.get(); let r = R { bits, _reg: PhantomData }; let mut w = W { bits, _reg: PhantomData }; f(&r, &mut w); self.register.set(w.bits); } }
impl<REG: Resettable + Writable> Reg<REG> { pub fn reset(&self) { self.register.set(REG::RESET_VALUE); } }
pub struct FieldReader<T = u8> { bits: T }
impl<T: Copy> FieldReader<T> { pub const fn new(bits: T) -> Self { Self { bits } } pub const fn bits(&self) -> T { self.bits } }
pub struct BitReader<T = bool> { bits: bool, _marker: PhantomData<T> }
impl<T> BitReader<T> { pub const fn new(bits: bool) -> Self { Self { bits, _marker: PhantomData } } pub const fn bit(&self) -> bool { self.bits } pub const fn bit_is_clear(&self) -> bool { !self.bits } pub const fn bit_is_set(&self) -> bool { self.bits } }
pub struct FieldWriter<'a, REG: Writable, const WI: u8, FI = u8> { w: &'a mut W<REG>, o: u8, _field: PhantomData<FI> }
impl<'a, REG: Writable, const WI: u8, FI> FieldWriter<'a, REG, WI, FI> where REG::Ux: From<u8> { pub fn new(w: &'a mut W<REG>, o: u8) -> Self { Self { w, o, _field: PhantomData } } pub unsafe fn bits(self, value: u8) -> &'a mut W<REG> { self.w.bits = (self.w.bits & !(<REG::Ux as RawReg>::mask(WI) << self.o)) | ((REG::Ux::from(value) & <REG::Ux as RawReg>::mask(WI)) << self.o); self.w } }
pub struct BitWriter<'a, REG: Writable, FI = bool> { w: &'a mut W<REG>, o: u8, _field: PhantomData<FI> }
impl<'a, REG: Writable, FI> BitWriter<'a, REG, FI> { pub fn new(w: &'a mut W<REG>, o: u8) -> Self { Self { w, o, _field: PhantomData } } pub fn bit(self, value: bool) -> &'a mut W<REG> { if value { self.set_bit() } else { self.clear_bit() } } pub fn set_bit(self) -> &'a mut W<REG> { self.w.bits = self.w.bits | (<REG::Ux as RawReg>::ONE << self.o); self.w } pub fn clear_bit(self) -> &'a mut W<REG> { self.w.bits = self.w.bits & !(<REG::Ux as RawReg>::ONE << self.o); self.w } }
`;
}

function genRegister(r: Register): string {
  const mod = snake(r.name), typ = pascal(r.name), spec = `${typ}Spec`, acc = accessFlags(r.access);
  let s = `\n#[doc = "${escDoc(r.name)} (${acc.label}) register accessor: ${escDoc(r.desc)}"]\n#[doc(alias = "${escDoc(r.name)}")]\npub type ${typ} = crate::Reg<${mod}::${spec}>;\n#[doc = "${escDoc(r.desc || r.name)}"]\npub mod ${mod} {\n`;
  if (acc.r) s += `#[doc = "Register \`${escDoc(r.name)}\` reader"]\npub type R = crate::R<${spec}>;\n`;
  if (acc.w) s += `#[doc = "Register \`${escDoc(r.name)}\` writer"]\npub type W = crate::W<${spec}>;\n`;
  for (const f of r.fields) {
    const fn = pascal(f.name);
    if (acc.r) s += `#[doc = "Field \`${escDoc(f.name)}\` reader - ${escDoc(f.desc)}"]\npub type ${fn}R = crate::${f.width === 1 ? "BitReader" : "FieldReader"};\n`;
    if (acc.w) s += `#[doc = "Field \`${escDoc(f.name)}\` writer - ${escDoc(f.desc)}"]\npub type ${fn}W<'a, REG> = crate::${f.width === 1 ? "BitWriter" : `FieldWriter<'a, REG, ${f.width}`}${f.width === 1 ? "<'a, REG>" : ">"};\n`;
    for (const ev of f.enums) s += `#[doc = "${escDoc(ev.desc)}"]\npub const ${constName(f.name)}_${constName(ev.name)}: u8 = ${parseNum(ev.value, 0)};\n`;
  }
  if (acc.r && r.fields.length) {
    s += `impl R {\n`;
    for (const f of r.fields) {
      const mn = snake(f.name), ret = `${pascal(f.name)}R`;
      if (f.width === 1) s += `#[doc = "Bit ${f.offset}${f.desc ? " - " + escDoc(f.desc) : ""}"]\npub fn ${mn}(&self) -> ${ret} { ${ret}::new(((self.bits() >> ${f.offset}) & 1) != 0) }\n`;
      else s += `#[doc = "Bits ${f.offset}:${f.offset + f.width - 1}${f.desc ? " - " + escDoc(f.desc) : ""}"]\npub fn ${mn}(&self) -> ${ret} { ${ret}::new(((self.bits() >> ${f.offset}) & ${Number((1n << BigInt(Math.min(f.width, 31))) - 1n)}) as u8) }\n`;
    }
    s += `}\n`;
  }
  if (acc.w && r.fields.length) {
    s += `impl W {\n`;
    for (const f of r.fields) {
      s += `#[doc = "${f.width === 1 ? "Bit" : "Bits"} ${f.offset}${f.width === 1 ? "" : ":" + (f.offset + f.width - 1)}${f.desc ? " - " + escDoc(f.desc) : ""}"]\npub fn ${snake(f.name)}(&mut self) -> ${pascal(f.name)}W<'_, ${spec}> { ${pascal(f.name)}W::new(self, ${f.offset}) }\n`;
    }
    s += `}\n`;
  }
  s += `#[doc = "${escDoc(r.desc || r.name)}"]\npub struct ${spec};\nimpl crate::RegisterSpec for ${spec} { type Ux = ${ux(r.size)}; }\n`;
  if (acc.r) s += `impl crate::Readable for ${spec} {}\n`;
  if (acc.w) s += `impl crate::Writable for ${spec} { type Safety = crate::Unsafe; }\n`;
  s += `impl crate::Resettable for ${spec} { const RESET_VALUE: Self::Ux = ${r.reset.toString()} as ${ux(r.size)}; }\n}\n`;
  return s;
}

function genPeripheral(p: Peripheral): string {
  const mod = snake(p.name), type = pascal(p.name), spec = `${type}Spec`;
  const regs = [...p.registers].sort((a, b) => a.offset - b.offset);
  let cur = 0, res = 0, fields = "";
  for (const r of regs) {
    if (r.offset > cur) fields += `    _reserved${++res}: [u8; 0x${(r.offset - cur).toString(16)}],\n`;
    fields += `    ${snake(r.name)}: ${pascal(r.name)},\n`;
    cur = Math.max(cur, r.offset + Math.max(1, r.size / 8));
  }
  let s = `\n#[doc = "${escDoc(p.desc || p.name)}"]\npub type ${type} = crate::Periph<${spec}>;\npub struct ${spec};\nimpl crate::PeripheralSpec for ${spec} { type RB = ${mod}::RegisterBlock; const ADDRESS: usize = ${fmtHex(p.base)}; const NAME: &'static str = "${type}"; }\n`;
  s += `#[doc = "${escDoc(p.desc || p.name)}"]\npub mod ${mod} {\n#[repr(C)]\n#[doc = "Register block"]\npub struct RegisterBlock {\n${fields}}\nimpl RegisterBlock {\n`;
  for (const r of regs) s += `#[doc = "0x${r.offset.toString(16).padStart(2, "0")} - ${escDoc(r.desc || r.name)}"]\npub const fn ${snake(r.name)}(&self) -> &${pascal(r.name)} { &self.${snake(r.name)} }\n`;
  s += `}\n`;
  for (const r of regs) s += genRegister(r);
  s += `}\n`;
  return s;
}

function generate(dev: any, opts: any): { lib: string; deviceX: string; build: string } {
  let lib = prelude(dev.name, dev.nvic, !opts.makeMod && !opts.skipAttrs);
  for (const p of dev.peripherals) lib += genPeripheral(p);
  const ints = dev.peripherals.flatMap((p: Peripheral) => p.interrupts);
  if (ints.length) {
    lib += `\n#[allow(non_camel_case_types)]\n#[derive(Copy, Clone, Debug, PartialEq, Eq)]\npub enum Interrupt {\n`;
    for (const it of ints.sort((a, b) => a.value - b.value)) lib += `    #[doc = "${escDoc(it.desc || it.name)}"]\n    ${pascal(it.name)} = ${it.value},\n`;
    lib += `}\n`;
  }
  lib += `\n#[no_mangle]\nstatic mut DEVICE_PERIPHERALS: bool = false;\n#[doc = r" All the peripherals."]\n#[allow(non_snake_case)]\npub struct Peripherals {\n`;
  for (const p of dev.peripherals) lib += `    #[doc = "${escDoc(p.name)}"] pub ${snake(p.name)}: ${pascal(p.name)},\n`;
  lib += `}\nimpl Peripherals {\n    pub unsafe fn steal() -> Self { DEVICE_PERIPHERALS = true; Peripherals {\n`;
  for (const p of dev.peripherals) lib += `        ${snake(p.name)}: ${pascal(p.name)}::steal(),\n`;
  lib += `    } }\n}\n`;
  const build = `#![doc = r" Builder file for Peripheral access crate generated by svd2rust tool"]\nuse std::env; use std::fs::File; use std::io::Write; use std::path::PathBuf;\nfn main() { if env::var_os("CARGO_FEATURE_RT").is_some() { let out = &PathBuf::from(env::var_os("OUT_DIR").unwrap()); File::create(out.join("device.x")).unwrap().write_all(include_bytes!("device.x")).unwrap(); println!("cargo:rustc-link-search={}", out.display()); println!("cargo:rerun-if-changed=device.x"); } println!("cargo:rerun-if-changed=build.rs"); }\n`;
  let deviceX = "";
  for (const it of ints) deviceX += `PROVIDE(${it.name} = DefaultHandler);\n`;
  return { lib, build, deviceX };
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  logInfo("Parsing device from SVD file");
  let xml = "";
  try {
    xml = opts.input ? fs.readFileSync(opts.input, "utf8") : fs.readFileSync(0, "utf8");
    const root = parseXml(xml);
    const dev = parseDevice(root, opts.baseShift);
    logInfo("Rendering device");
    const out = generate(dev, opts);
    fs.mkdirSync(opts.out, { recursive: true });
    fs.writeFileSync(path.join(opts.out, opts.makeMod ? "mod.rs" : "lib.rs"), out.lib);
    if (opts.genericMod) fs.writeFileSync(path.join(opts.out, "generic.rs"), "// generic register support is emitted inline by this reimplementation\n");
    fs.writeFileSync(path.join(opts.out, "build.rs"), out.build);
    fs.writeFileSync(path.join(opts.out, "device.x"), out.deviceX);
  } catch (e: any) {
    logError(`Error parsing SVD XML file\n    \n    Caused by:\n        ${e?.message || e}`);
    process.exit(1);
  }
}

main();
