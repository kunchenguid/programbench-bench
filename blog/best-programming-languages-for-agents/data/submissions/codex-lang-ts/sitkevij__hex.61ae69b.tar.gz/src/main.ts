declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");

type Format = "x" | "X" | "o" | "b";

interface Options {
  cols: number;
  len?: number;
  format: Format;
  color: boolean;
  array?: string;
  func?: number;
  places: number;
  prefix: boolean;
  input?: string;
}

const HELP = `Futuristic take on hexdump, made in Rust.


Usage: executable [OPTIONS] [INPUTFILE]

Arguments:
  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin

Options:
  -c, --cols <columns>        Set column length
  -l, --len <len>             Set <len> bytes to read
  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]
  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]
  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]
  -u, --func <func_length>    Set function wave length
  -p, --places <func_places>  Set function wave output decimal places
  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]
  -h, --help                  Print help
  -V, --version               Print version`;

function die(message: string, code = 1): never {
  process.stderr.write(message.endsWith("\n") ? message : message + "\n");
  process.exit(code);
  throw new Error("unreachable");
}

function invalidValue(opt: string, val: string, values: string): never {
  die(`error: invalid value '${val}' for '${opt}'\n  [possible values: ${values}]\n\nFor more information, try '--help'.`, 2);
}

function parseIntOpt(name: string, val: string): number {
  if (!/^\d+$/.test(val)) {
    const short = name === "--cols" ? "-c, --cols" : name === "--len" ? "-l, --len" : name === "--func" ? "-u, --func" : "-p, --places";
    process.stderr.write(`${short} <integer> expected. ParseIntError { kind: InvalidDigit }\n`);
    die("error: invalid digit found in string", 1);
  }
  return Number(val);
}

function parseArgs(argv: string[]): Options {
  const opts: Options = { cols: 10, format: "x", color: false, places: 4, prefix: true };
  const needVal = (i: number, name: string): string => {
    if (i + 1 >= argv.length) die(`error: a value is required for '${name} <value>' but none was supplied\n\nFor more information, try '--help'.`, 2);
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") {
      process.stdout.write(HELP + "\n");
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      process.stdout.write("hx 0.7.0\n");
      process.exit(0);
    } else if (a === "-c" || a === "--cols") {
      opts.cols = parseIntOpt("--cols", needVal(i, a));
      if (opts.cols === 0) opts.cols = 1;
      i++;
    } else if (a.startsWith("--cols=")) {
      opts.cols = parseIntOpt("--cols", a.slice(7));
      if (opts.cols === 0) opts.cols = 1;
    } else if (a === "-l" || a === "--len") {
      opts.len = parseIntOpt("--len", needVal(i, a));
      i++;
    } else if (a.startsWith("--len=")) {
      opts.len = parseIntOpt("--len", a.slice(6));
    } else if (a === "-f" || a === "--format") {
      const v = needVal(i, a);
      if (!["o", "x", "X", "b"].includes(v)) invalidValue("--format <format>", v, "o, x, X, b");
      opts.format = v as Format;
      i++;
    } else if (a.startsWith("--format=")) {
      const v = a.slice(9);
      if (!["o", "x", "X", "b"].includes(v)) invalidValue("--format <format>", v, "o, x, X, b");
      opts.format = v as Format;
    } else if (a === "-t" || a === "--color") {
      const v = needVal(i, a);
      if (!["0", "1"].includes(v)) invalidValue("--color <color>", v, "0, 1");
      opts.color = v === "1";
      i++;
    } else if (a.startsWith("--color=")) {
      const v = a.slice(8);
      if (!["0", "1"].includes(v)) invalidValue("--color <color>", v, "0, 1");
      opts.color = v === "1";
    } else if (a === "-r" || a === "--prefix") {
      const v = needVal(i, a);
      if (!["0", "1"].includes(v)) invalidValue("--prefix <prefix>", v, "0, 1");
      opts.prefix = v === "1";
      i++;
    } else if (a.startsWith("--prefix=")) {
      const v = a.slice(9);
      if (!["0", "1"].includes(v)) invalidValue("--prefix <prefix>", v, "0, 1");
      opts.prefix = v === "1";
    } else if (a === "-a" || a === "--array") {
      const v = needVal(i, a);
      if (!["r", "c", "g", "p", "k", "j", "s", "f"].includes(v)) invalidValue("--array <array_format>", v, "r, c, g, p, k, j, s, f");
      opts.array = v;
      i++;
    } else if (a.startsWith("--array=")) {
      const v = a.slice(8);
      if (!["r", "c", "g", "p", "k", "j", "s", "f"].includes(v)) invalidValue("--array <array_format>", v, "r, c, g, p, k, j, s, f");
      opts.array = v;
    } else if (a === "-u" || a === "--func") {
      opts.func = parseIntOpt("--func", needVal(i, a));
      i++;
    } else if (a.startsWith("--func=")) {
      opts.func = parseIntOpt("--func", a.slice(7));
    } else if (a === "-p" || a === "--places") {
      opts.places = parseIntOpt("--places", needVal(i, a));
      i++;
    } else if (a.startsWith("--places=")) {
      opts.places = parseIntOpt("--places", a.slice(9));
    } else if (a.startsWith("-")) {
      die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [INPUTFILE]\n\nFor more information, try '--help'.`, 2);
    } else if (!opts.input) {
      opts.input = a;
    } else {
      die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [INPUTFILE]\n\nFor more information, try '--help'.`, 2);
    }
  }
  return opts;
}

function readInput(opts: Options): any {
  let data: any;
  if (opts.input) {
    try {
      data = fs.readFileSync(opts.input);
    } catch (e: any) {
      if (e && e.code === "ENOENT") die("error: No such file or directory (os error 2)", 1);
      die(`error: ${e.message.replace(/, open '.*'$/, "")}`, 1);
    }
  } else {
    data = fs.readFileSync(0);
  }
  if (opts.len !== undefined && opts.len > 0 && opts.len < data.length) return data.subarray(0, opts.len);
  return data;
}

function hexByte(b: number): string {
  return b.toString(16).padStart(2, "0");
}

function fmtByte(b: number, format: Format, prefix: boolean): string {
  if (format === "x") return (prefix ? "0x" : "") + hexByte(b);
  if (format === "X") return (prefix ? "0x" : "") + b.toString(16).toUpperCase().padStart(2, "0");
  if (format === "o") return (prefix ? "0o" : "") + b.toString(8).padStart(4, "0");
  return (prefix ? "0b" : "") + b.toString(2).padStart(8, "0");
}

function printable(b: number): string {
  return b >= 0x20 && b <= 0x7e ? String.fromCharCode(b) : ".";
}

function colorize(s: string, b: number, enable: boolean): string {
  if (!enable) return s;
  return `\x1b[38;5;${b % 256}m${s}\x1b[0m`;
}

function dump(data: any, opts: Options): string {
  const out: string[] = [];
  const cols = opts.cols || 1;
  const unitWidth = fmtByte(0, opts.format, opts.prefix).length;
  for (let off = 0; off < data.length || (data.length > 0 && data.length % cols === 0 && off === data.length); off += cols) {
    const chunk = data.subarray(off, Math.min(off + cols, data.length));
    let line = `0x${off.toString(16).padStart(6, "0")}:`;
    if (chunk.length > 0) line += " ";
    const nums: string[] = [];
    for (const b of chunk) nums.push(colorize(fmtByte(b, opts.format, opts.prefix), b, opts.color));
    line += nums.join(" ");
    const spaces = Math.max(1, (cols - chunk.length) * 5 + 1);
    line += " ".repeat(spaces);
    let ascii = "";
    for (const b of chunk) ascii += colorize(printable(b), b, opts.color);
    line += ascii;
    out.push(line);
    if (chunk.length === 0) break;
  }
  if (data.length === 0) {
    out.push("0x000000: " + " ".repeat(cols * (unitWidth + 1)));
  }
  out.push(`   bytes: ${data.length}`);
  return out.join("\n") + "\n";
}

function arrayOutput(data: any, opts: Options): string {
  const n = data.length;
  const cols = opts.cols || 10;
  const vals: string[] = Array.from(data, (b: number) => "0x" + hexByte(b));
  const sep = opts.array === "f" ? "uy; " : ", ";
  const endVal = opts.array === "f" ? "uy" : "";
  const lines: string[] = [];
  const head: Record<string, string> = {
    r: `let ARRAY: [u8; ${n}] = [`,
    c: `unsigned char ARRAY[${n}] = {`,
    g: `a := [${n}]byte{`,
    p: "a = [",
    k: "val a = byteArrayOf(",
    j: "byte[] a = new byte[]{",
    s: "let a: [UInt8] = [",
    f: "let a = [|"
  };
  const tail: Record<string, string> = { r: "];", c: "};", g: "}", p: "]", k: ")", j: "};", s: "]", f: "|]" };
  lines.push(head[opts.array!]);
  for (let i = 0; i < vals.length; i += cols) {
    const row = vals.slice(i, i + cols).map(v => opts.array === "f" ? v + endVal : v);
    const isLast = i + cols >= vals.length && vals.length % cols !== 0;
    let body: string;
    if (opts.array === "g") {
      body = row.join(", ") + ", ";
    } else if (!isLast) {
      body = row.join(opts.array === "f" ? "; " : ", ") + (opts.array === "f" ? "; " : ", ");
    } else {
      body = row.join(opts.array === "f" ? "; " : ", ");
    }
    lines.push("    " + body);
  }
  if (vals.length > 0 && vals.length % cols === 0) lines.push("    ");
  lines.push(tail[opts.array!]);
  return lines.join("\n") + "\n";
}

function wave(n: number, places: number): string {
  const vals: string[] = [];
  for (let i = 0; i < n; i++) vals.push(Math.sin(i * Math.PI / (2 * n)).toFixed(places));
  return vals.join(",") + ",\n";
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.func !== undefined) {
    process.stdout.write(wave(opts.func, opts.places));
    return;
  }
  const data = readInput(opts);
  if (opts.array) process.stdout.write(arrayOutput(data, opts));
  else process.stdout.write(dump(data, opts));
}

main();
