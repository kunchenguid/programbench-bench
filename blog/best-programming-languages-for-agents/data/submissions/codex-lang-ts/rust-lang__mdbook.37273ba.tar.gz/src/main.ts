import * as fs from "fs";
import * as path from "path";
import { spawnSync } from "child_process";
import * as http from "http";

const VERSION = "mdbook v0.5.0-alpha.1";

type Config = {
  title: string;
  src: string;
  language: string;
  buildDir: string;
  description: string;
};

type Chapter = {
  title: string;
  link: string;
  level: number;
  source: string;
  dest: string;
};

function now(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

function log(level: "INFO" | "ERROR", module: string, message: string) {
  console.error(`${now()} [${level}] (${module}): ${message}`);
}

function die(message: string, code = 101): never {
  log("ERROR", "mdbook_core::utils", `Error: ${message}`);
  process.exit(code);
  throw new Error(message);
}

function usage(): string {
  return `Creates a book from markdown files

Usage: executable [COMMAND]

Commands:
  init         Creates the boilerplate structure and files for a new book
  build        Builds a book from its markdown files
  test         Tests that a book's Rust code samples compile
  clean        Deletes a built book
  completions  Generate shell completions for your shell to stdout
  watch        Watches a book's files and rebuilds it on changes
  serve        Serves a book at http://localhost:3000, and rebuilds it on changes
  help         Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version

For more information about a specific command, try \`mdbook <command> --help\`
The source code for mdBook is available at: https://github.com/rust-lang/mdBook`;
}

const helps: Record<string, string> = {
  init: `Creates the boilerplate structure and files for a new book

Usage: executable init [OPTIONS] [dir]

Arguments:
  [dir]  Directory to create the book in
         (Defaults to the current directory when omitted)

Options:
      --theme            Copies the default theme into your source folder
      --force            Skips confirmation prompts
      --title <title>    Sets the book title
      --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]
  -h, --help             Print help
  -V, --version          Print version`,
  build: `Builds a book from its markdown files

Usage: executable build [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             \`./book\`.
  -o, --open                 Opens the compiled book in a web browser
  -h, --help                 Print help
  -V, --version              Print version`,
  test: `Tests that a book's Rust code samples compile

Usage: executable test [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             \`./book\`.
  -c, --chapter <chapter>    
  -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path
                             when building tests
  -h, --help                 Print help
  -V, --version              Print version`,
  clean: `Deletes a built book

Usage: executable clean [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             \`./book\`.
  -h, --help                 Print help
  -V, --version              Print version`,
  completions: `Generate shell completions for your shell to stdout

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,
           zsh]

Options:
  -h, --help     Print help
  -V, --version  Print version`,
  watch: `Watches a book's files and rebuilds it on changes

Usage: executable watch [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             \`./book\`.
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version`,
  serve: `Serves a book at http://localhost:3000, and rebuilds it on changes

Usage: executable serve [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             \`./book\`.
  -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]
  -p, --port <port>          Port to use for HTTP connections [default: 3000]
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version`
};

function mkdirp(p: string) {
  fs.mkdirSync(p, { recursive: true });
}

function readConfig(root: string): Config {
  const cfg: Config = { title: "mdBook", src: "src", language: "en", buildDir: "book", description: "" };
  const file = path.join(root, "book.toml");
  if (!fs.existsSync(file)) return cfg;
  let section = "";
  for (const raw of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const sec = line.match(/^\[([^\]]+)\]$/);
    if (sec) { section = sec[1]; continue; }
    const m = line.match(/^([A-Za-z0-9_.-]+)\s*=\s*(.*)$/);
    if (!m) continue;
    const key = m[1];
    let val = m[2].trim().replace(/\s+#.*$/, "");
    if (val.startsWith('"') && val.endsWith('"')) val = val.slice(1, -1);
    if (section === "book" && key === "title") cfg.title = val;
    if (section === "book" && key === "src") cfg.src = val;
    if (section === "book" && key === "language") cfg.language = val;
    if (section === "book" && key === "description") cfg.description = val;
    if (section === "build" && key === "build-dir") cfg.buildDir = val;
  }
  return cfg;
}

function parseArgs(args: string[]) {
  const opts: Record<string, any> = {};
  const pos: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") opts.help = true;
    else if (a === "-V" || a === "--version") opts.version = true;
    else if (a === "-o" || a === "--open") opts.open = true;
    else if (a === "--force") opts.force = true;
    else if (a === "--theme") opts.theme = true;
    else if (a === "-d" || a === "--dest-dir") opts.destDir = args[++i];
    else if (a.startsWith("--dest-dir=")) opts.destDir = a.slice(11);
    else if (a === "--title") opts.title = args[++i];
    else if (a.startsWith("--title=")) opts.title = a.slice(8);
    else if (a === "--ignore") opts.ignore = args[++i];
    else if (a.startsWith("--ignore=")) opts.ignore = a.slice(9);
    else if (a === "-c" || a === "--chapter") opts.chapter = args[++i];
    else if (a === "-L" || a === "--library-path") opts.libraryPath = args[++i];
    else if (a === "-n" || a === "--hostname") opts.hostname = args[++i];
    else if (a === "-p" || a === "--port") opts.port = args[++i];
    else if (a === "--watcher") opts.watcher = args[++i];
    else if (a.startsWith("-")) {
      console.error(`error: unexpected argument '${a}' found`);
      process.exit(2);
    } else pos.push(a);
  }
  return { opts, pos };
}

function summaryPath(root: string, cfg: Config) {
  return path.join(root, cfg.src, "SUMMARY.md");
}

function parseSummary(root: string, cfg: Config): Chapter[] {
  const sp = summaryPath(root, cfg);
  if (!fs.existsSync(sp)) die(`Couldn't open SUMMARY.md in "${path.join(root, cfg.src)}" directory\n\tCaused By: No such file or directory (os error 2)`);
  const lines = fs.readFileSync(sp, "utf8").split(/\r?\n/);
  const chapters: Chapter[] = [];
  for (const line of lines) {
    const m = line.match(/^(\s*)(?:[-*+]\s*)?\[([^\]]+)\]\(([^)]*)\)/);
    if (!m) continue;
    const link = m[3];
    if (link === "") continue;
    const level = Math.floor(m[1].replace(/\t/g, "    ").length / 2);
    const clean = link.split("#")[0].replace(/^\.\//, "");
    const dest = mdToHtml(clean);
    chapters.push({ title: m[2], link, level, source: clean, dest });
  }
  return chapters;
}

function mdToHtml(file: string): string {
  const norm = file.replace(/\\/g, "/").replace(/^\.\//, "");
  if (/^(README|readme)\.md$/.test(norm)) return "index.html";
  return norm.replace(/\.md$/i, ".html").replace(/\/README\.html$/i, "/index.html");
}

function htmlEscape(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function inline(s: string): string {
  let out = htmlEscape(s);
  out = out.replace(/`([^`]+)`/g, "<code>$1</code>");
  out = out.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  out = out.replace(/\*([^*]+)\*/g, "<em>$1</em>");
  out = out.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_m, text, href) => `<a href="${htmlEscape(mdToHtml(href))}">${text}</a>`);
  return out;
}

function slug(s: string): string {
  return s.toLowerCase().replace(/<[^>]+>/g, "").replace(/[^a-z0-9 -]/g, "").trim().replace(/\s+/g, "-");
}

function renderMarkdown(md: string): { html: string; firstHeading: string } {
  const lines = md.split(/\r?\n/);
  let html = "";
  let para: string[] = [];
  let inCode = false, code = "", codeLang = "";
  let inList = false;
  let firstHeading = "";
  const flushPara = () => {
    if (para.length) { html += `<p>${inline(para.join(" "))}</p>\n`; para = []; }
  };
  const closeList = () => { if (inList) { html += "</ul>\n"; inList = false; } };
  for (const line of lines) {
    const fence = line.match(/^```([A-Za-z0-9_-]*)/);
    if (fence) {
      if (inCode) {
        html += `<pre><code class="language-${htmlEscape(codeLang)}">${htmlEscape(code.replace(/\n$/, ""))}</code></pre>\n`;
        inCode = false; code = ""; codeLang = "";
      } else {
        flushPara(); closeList(); inCode = true; codeLang = fence[1] || "";
      }
      continue;
    }
    if (inCode) { code += line + "\n"; continue; }
    if (/^\s*$/.test(line)) { flushPara(); closeList(); continue; }
    const h = line.match(/^(#{1,6})\s+(.*)$/);
    if (h) {
      flushPara(); closeList();
      const level = h[1].length;
      const text = inline(h[2].replace(/\s+#+\s*$/, ""));
      if (!firstHeading) firstHeading = h[2].replace(/\s+#+\s*$/, "");
      html += `<h${level} id="${slug(h[2])}"><a class="header" href="#${slug(h[2])}">${text}</a></h${level}>\n`;
      continue;
    }
    const li = line.match(/^\s*[-*+]\s+(.*)$/);
    if (li) {
      flushPara();
      if (!inList) { html += "<ul>\n"; inList = true; }
      html += `<li>${inline(li[1])}</li>\n`;
      continue;
    }
    para.push(line.trim());
  }
  flushPara(); closeList();
  if (inCode) html += `<pre><code>${htmlEscape(code)}</code></pre>\n`;
  return { html, firstHeading };
}

function pageTemplate(title: string, content: string, toc: string, cfg: Config, rootRel: string): string {
  return `<!DOCTYPE HTML>
<html lang="${htmlEscape(cfg.language)}" class="light sidebar-visible" dir="ltr">
<head>
<meta charset="UTF-8">
<title>${htmlEscape(title)}</title>
<meta name="description" content="${htmlEscape(cfg.description)}">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="${rootRel}css/general.css">
<link rel="stylesheet" href="${rootRel}css/chrome.css">
<link rel="stylesheet" href="${rootRel}css/print.css" media="print">
<script>const path_to_root="${rootRel}"; window.path_to_searchindex_js="${rootRel}searchindex.js";</script>
</head>
<body>
<div id="body-container">
<nav id="sidebar" class="sidebar" aria-label="Table of contents">
<div class="sidebar-scrollbox">${toc}</div>
</nav>
<div id="page-wrapper" class="page-wrapper"><div class="page"><main><div class="content">${content}</div></main></div></div>
</div>
<script src="${rootRel}book.js"></script>
</body>
</html>
`;
}

function tocHtml(chapters: Chapter[]): string {
  let out = `<ol class="chapter">`;
  for (const ch of chapters) {
    const indent = "&nbsp;".repeat(ch.level * 4);
    out += `<li class="chapter-item">${indent}<a href="${htmlEscape(ch.dest)}">${htmlEscape(ch.title)}</a></li>`;
  }
  return out + "</ol>";
}

function writeAssets(dest: string) {
  mkdirp(path.join(dest, "css"));
  mkdirp(path.join(dest, "fonts"));
  fs.writeFileSync(path.join(dest, ".nojekyll"), "");
  fs.writeFileSync(path.join(dest, "css", "general.css"), "body{font-family:Arial,sans-serif;margin:0;line-height:1.55}.content{max-width:900px;margin:0 auto;padding:2rem}pre{background:#f6f6f6;padding:1rem;overflow:auto}code{font-family:monospace}.header{text-decoration:none;color:inherit}\n");
  fs.writeFileSync(path.join(dest, "css", "chrome.css"), ".sidebar{position:fixed;top:0;bottom:0;width:260px;overflow:auto;background:#fafafa;border-right:1px solid #ddd}.page-wrapper{margin-left:260px}.chapter{padding:1rem 1rem 1rem 2rem}.chapter-item{margin:.3rem 0}@media(max-width:800px){.sidebar{position:static;width:auto}.page-wrapper{margin-left:0}}\n");
  fs.writeFileSync(path.join(dest, "css", "print.css"), ".sidebar{display:none}.page-wrapper{margin:0}.content{max-width:none}\n");
  for (const f of ["book.js", "toc.js", "searcher.js", "highlight.js", "clipboard.min.js", "elasticlunr.min.js", "mark.min.js"]) fs.writeFileSync(path.join(dest, f), "");
  for (const f of ["highlight.css", "tomorrow-night.css", "ayu-highlight.css"]) fs.writeFileSync(path.join(dest, f), "");
  fs.writeFileSync(path.join(dest, "favicon.svg"), "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 16 16\"><text y=\"14\">M</text></svg>");
  fs.writeFileSync(path.join(dest, "favicon.png"), "");
  fs.writeFileSync(path.join(dest, "fonts", "fonts.css"), "");
}

function copyStatic(srcDir: string, destDir: string) {
  if (!fs.existsSync(srcDir)) return;
  for (const ent of fs.readdirSync(srcDir, { withFileTypes: true })) {
    const s = path.join(srcDir, ent.name);
    const d = path.join(destDir, ent.name);
    if (ent.isDirectory()) copyStatic(s, d);
    else if (!ent.name.toLowerCase().endsWith(".md")) {
      mkdirp(path.dirname(d));
      fs.copyFileSync(s, d);
    }
  }
}

function destDir(root: string, cfg: Config, override?: string): string {
  const d = override || cfg.buildDir || "book";
  return path.isAbsolute(d) ? d : path.join(root, d);
}

function commandInit(args: string[]) {
  const { opts, pos } = parseArgs(args);
  if (opts.help) { console.log(helps.init); return; }
  if (opts.version) { console.log(VERSION); return; }
  const root = path.resolve(pos[0] || ".");
  const src = path.join(root, "src");
  mkdirp(src);
  const title = opts.title || "My First Book";
  fs.writeFileSync(path.join(root, "book.toml"), `[book]\nauthors = []\nlanguage = "en"\nsrc = "src"\ntitle = "${title.replace(/"/g, '\\"')}"\n`);
  const sum = path.join(src, "SUMMARY.md");
  if (!fs.existsSync(sum)) fs.writeFileSync(sum, "# Summary\n\n- [Chapter 1](./chapter_1.md)\n");
  log("INFO", "mdbook_driver::init", "Creating a new book with stub content");
  for (const ch of parseSummary(root, readConfig(root))) {
    const target = path.join(src, ch.source);
    if (!fs.existsSync(target)) {
      mkdirp(path.dirname(target));
      fs.writeFileSync(target, `# ${ch.title}\n`);
    }
  }
  if (!fs.existsSync(path.join(src, "chapter_1.md")) && fs.readFileSync(sum, "utf8").includes("chapter_1.md")) {
    fs.writeFileSync(path.join(src, "chapter_1.md"), "# Chapter 1\n");
  }
  if (opts.theme) {
    mkdirp(path.join(src, "theme"));
    fs.writeFileSync(path.join(src, "theme", "index.hbs"), "{{ content }}\n");
  }
  if (opts.ignore === "git") fs.writeFileSync(path.join(root, ".gitignore"), "book\n");
  console.log("\nAll done, no errors...");
}

function commandBuild(args: string[], quiet = false): { root: string; dest: string; chapters: Chapter[]; cfg: Config } {
  const { opts, pos } = parseArgs(args);
  if (opts.help) { console.log(helps.build); return null as any; }
  if (opts.version) { console.log(VERSION); return null as any; }
  const root = path.resolve(pos[0] || ".");
  const cfg = readConfig(root);
  const src = path.join(root, cfg.src);
  const chapters = parseSummary(root, cfg);
  const dest = destDir(root, cfg, opts.destDir);
  if (!quiet) log("INFO", "mdbook_driver::mdbook", "Book building has started");
  fs.rmSync(dest, { recursive: true, force: true });
  mkdirp(dest);
  copyStatic(src, dest);
  writeAssets(dest);
  const toc = tocHtml(chapters);
  const rendered: string[] = [];
  for (const ch of chapters) {
    const mdPath = path.join(src, ch.source);
    if (!fs.existsSync(mdPath)) {
      mkdirp(path.dirname(mdPath));
      fs.writeFileSync(mdPath, `# ${ch.title}\n`);
    }
    const md = fs.readFileSync(mdPath, "utf8");
    const r = renderMarkdown(md);
    const title = r.firstHeading || ch.title || cfg.title;
    const out = path.join(dest, ch.dest);
    mkdirp(path.dirname(out));
    const rel = path.relative(path.dirname(out), dest).replace(/\\/g, "/");
    const rootRel = rel ? rel + "/" : "";
    fs.writeFileSync(out, pageTemplate(title, r.html, toc, cfg, rootRel));
    rendered.push(`<h1>${htmlEscape(title)}</h1>\n${r.html}`);
  }
  if (chapters.length && !fs.existsSync(path.join(dest, "index.html"))) {
    fs.copyFileSync(path.join(dest, chapters[0].dest), path.join(dest, "index.html"));
  }
  fs.writeFileSync(path.join(dest, "toc.html"), pageTemplate("Table of Contents", toc, toc, cfg, ""));
  fs.writeFileSync(path.join(dest, "print.html"), pageTemplate(cfg.title, rendered.join("\n"), toc, cfg, ""));
  fs.writeFileSync(path.join(dest, "404.html"), pageTemplate("404", "<h1>404</h1><p>Page not found.</p>", toc, cfg, ""));
  fs.writeFileSync(path.join(dest, "searchindex.js"), `window.search = Object.assign(window.search || {}, ${JSON.stringify({ doc_urls: chapters.map(c => c.dest), results_options: { limit_results: 30 } })});`);
  if (!quiet) {
    log("INFO", "mdbook_driver::mdbook", "Running the html backend");
    log("INFO", "mdbook_html::html_handlebars::hbs_renderer", `HTML book written to \`${dest}\``);
  }
  return { root, dest, chapters, cfg };
}

function dirSize(p: string): number {
  if (!fs.existsSync(p)) return 0;
  const st = fs.statSync(p);
  if (!st.isDirectory()) return st.size;
  return fs.readdirSync(p).reduce((n, e) => n + dirSize(path.join(p, e)), 0);
}

function commandClean(args: string[]) {
  const { opts, pos } = parseArgs(args);
  if (opts.help) { console.log(helps.clean); return; }
  if (opts.version) { console.log(VERSION); return; }
  const root = path.resolve(pos[0] || ".");
  const cfg = readConfig(root);
  const d = destDir(root, cfg, opts.destDir);
  const existed = fs.existsSync(d);
  const size = dirSize(d);
  fs.rmSync(d, { recursive: true, force: true });
  if (existed) console.log(`Removed 1 directory, ${humanSize(size)} total`);
}

function humanSize(n: number): string {
  if (n < 1024) return `${n}.00B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(2)}KiB`;
  return `${(n / 1024 / 1024).toFixed(2)}MiB`;
}

function extractRust(md: string): string[] {
  const out: string[] = [];
  const re = /```([^`\n]*)\n([\s\S]*?)```/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(md))) {
    const lang = m[1].trim();
    if (lang === "rust" || lang === "rs" || lang === "" || lang.includes("rust")) out.push(m[2]);
  }
  return out;
}

function commandTest(args: string[]) {
  const { opts, pos } = parseArgs(args);
  if (opts.help) { console.log(helps.test); return; }
  if (opts.version) { console.log(VERSION); return; }
  const root = path.resolve(pos[0] || ".");
  const cfg = readConfig(root);
  const chapters = parseSummary(root, cfg);
  const hasRustdoc = spawnSync("bash", ["-lc", "command -v rustdoc >/dev/null 2>&1"]).status === 0;
  if (!hasRustdoc) {
    for (const ch of chapters) {
      if (opts.chapter && ch.title !== opts.chapter && ch.source !== opts.chapter) continue;
      log("INFO", "mdbook_driver::mdbook", `Testing chapter '${ch.title}': "${ch.source}"`);
      log("ERROR", "mdbook_driver::mdbook", "rustdoc returned an error:\n\n--- stdout\n\n--- stderr\n");
      die("One or more tests failed");
    }
    return;
  }
  let failed = false, count = 0;
  const tmp = fs.mkdtempSync(path.join("/tmp", "mdbook-test-"));
  for (const ch of chapters) {
    if (opts.chapter && ch.title !== opts.chapter && ch.source !== opts.chapter) continue;
    log("INFO", "mdbook_driver::mdbook", `Testing chapter '${ch.title}': "${ch.source}"`);
    const mdPath = path.join(root, cfg.src, ch.source);
    if (!fs.existsSync(mdPath)) continue;
    for (const code of extractRust(fs.readFileSync(mdPath, "utf8"))) {
      count++;
      const file = path.join(tmp, `test${count}.rs`);
      const wrapped = /\bfn\s+main\s*\(/.test(code) ? code : `fn main() {\n${code}\n}\n`;
      fs.writeFileSync(file, wrapped);
      const res = spawnSync("rustc", ["--edition=2018", file, "-o", path.join(tmp, `test${count}`)], { encoding: "utf8" });
      if (res.status !== 0) {
        failed = true;
        log("ERROR", "mdbook_driver::mdbook", `rustdoc returned an error:\n\n--- stdout\n${res.stdout || ""}\n--- stderr\n${res.stderr || ""}`);
      }
    }
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  if (failed) die("One or more tests failed");
}

function commandCompletions(args: string[]) {
  const { opts, pos } = parseArgs(args);
  if (opts.help) { console.log(helps.completions); return; }
  if (opts.version) { console.log(VERSION); return; }
  const shell = pos[0];
  if (!shell || !["bash", "elvish", "fish", "powershell", "zsh"].includes(shell)) {
    console.error("error: invalid value for '<SHELL>'");
    process.exit(2);
  }
  console.log(`# ${shell} completion for mdbook\ncomplete -W "init build test clean completions watch serve help" mdbook executable`);
}

function commandServe(args: string[]) {
  const { opts, pos } = parseArgs(args);
  if (opts.help) { console.log(helps.serve); return; }
  if (opts.version) { console.log(VERSION); return; }
  const buildArgs = [...args.filter(a => !["--open", "-o", "--watcher", "poll", "native"].includes(a))];
  const built = commandBuild(buildArgs, false);
  const host = opts.hostname || "localhost";
  const port = Number(opts.port || 3000);
  const server = http.createServer((req, res) => {
    const url = decodeURIComponent((req.url || "/").split("?")[0]);
    let file = path.join(built.dest, url === "/" ? "index.html" : url);
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, "index.html");
    if (!fs.existsSync(file)) file = path.join(built.dest, "404.html");
    res.end(fs.readFileSync(file));
  });
  server.listen(port, host, () => console.error(`Serving on http://${host}:${port}`));
}

function commandWatch(args: string[]) {
  const { opts } = parseArgs(args);
  if (opts.help) { console.log(helps.watch); return; }
  if (opts.version) { console.log(VERSION); return; }
  commandBuild(args, false);
  console.error("Watching for changes...");
  setInterval(() => {}, 1 << 30);
}

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0 || args[0] === "-h" || args[0] === "--help") { console.log(usage()); return; }
  if (args[0] === "-V" || args[0] === "--version") { console.log(VERSION); return; }
  const cmd = args[0] === "help" ? (args[1] || "") : args[0];
  const rest = args[0] === "help" ? args.slice(2) : args.slice(1);
  if (args[0] === "help" && cmd && helps[cmd]) { console.log(helps[cmd]); return; }
  if (args[0] === "help") { console.log(usage()); return; }
  if (cmd === "init") commandInit(rest);
  else if (cmd === "build") commandBuild(rest);
  else if (cmd === "clean") commandClean(rest);
  else if (cmd === "test") commandTest(rest);
  else if (cmd === "completions") commandCompletions(rest);
  else if (cmd === "serve") commandServe(rest);
  else if (cmd === "watch") commandWatch(rest);
  else {
    console.error(`error: unrecognized subcommand '${cmd}'\n\nUsage: executable [COMMAND]\n\nFor more information, try '--help'.`);
    process.exit(2);
  }
}

main();
