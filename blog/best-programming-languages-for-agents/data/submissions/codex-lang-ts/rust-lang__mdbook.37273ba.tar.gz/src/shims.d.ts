declare const process: any;
declare const require: any;
declare const __dirname: string;
declare module "fs";
declare module "path";
declare module "child_process";
declare module "http";
