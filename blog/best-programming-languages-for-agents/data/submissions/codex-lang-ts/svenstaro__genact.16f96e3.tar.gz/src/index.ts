declare const process: {
  argv: string[];
  stdout: { write(s: string): void; columns?: number };
  stderr: { write(s: string): void };
  exit(code?: number): never;
};

const VERSION = "1.5.1";
const MODULES = [
  "ansible", "bootlog", "botnet", "bruteforce", "cargo", "cc", "composer",
  "cryptomining", "docker_build", "docker_image_rm", "download", "julia",
  "kernel_compile", "memdump", "mkinitcpio", "rkhunter", "simcity",
  "terraform", "uv", "weblog", "wpt",
] as const;
type ModuleName = typeof MODULES[number];

type Options = {
  modules: ModuleName[];
  speedFactor: number;
  instantLines: number;
  exitAfterModules?: number;
  exitAfterTime?: string;
};

class Rng {
  private state = 0x12345678;
  next(): number {
    this.state = (1664525 * this.state + 1013904223) >>> 0;
    return this.state / 0x100000000;
  }
  int(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }
  pick<T>(items: readonly T[]): T {
    return items[this.int(0, items.length - 1)];
  }
  hex(n: number): string {
    let s = "";
    for (let i = 0; i < n; i++) s += this.int(0, 15).toString(16);
    return s;
  }
}

const rng = new Rng();

function help(): string {
  return `A nonsense activity generator

Usage: executable [OPTIONS]

Options:
  -l, --list-modules
          List available modules
  -m, --modules <MODULES>
          Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,
          composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,
          memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]
  -s, --speed-factor <SPEED_FACTOR>
          Global speed factor [default: 1]
  -i, --instant-print-lines <INSTANT_PRINT_LINES>
          Instantly print this many lines [default: 0]
      --inhibit
          Keep the computer awake and the display on while genact is running
      --exit-after-time <EXIT_AFTER_TIME>
          Exit after running for this long (format example: 2h10min)
      --exit-after-modules <EXIT_AFTER_MODULES>
          Exit after running this many modules
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,
          zsh]
      --print-manpage
          Generate man page
  -h, --help
          Print help
  -V, --version
          Print version
`;
}

function manpage(): string {
  return `.ie \\n(.g .ds Aq \\(aq
.el .ds Aq '
.TH genact 1  "genact ${VERSION}" 
.SH NAME
genact \\- A nonsense activity generator
.SH SYNOPSIS
\\fBgenact\\fR [\\fB\\-l\\fR|\\fB\\-\\-list\\-modules\\fR] [\\fB\\-m\\fR|\\fB\\-\\-modules\\fR] [\\fB\\-s\\fR|\\fB\\-\\-speed\\-factor\\fR] [\\fB\\-i\\fR|\\fB\\-\\-instant\\-print\\-lines\\fR] [\\fB\\-\\-inhibit\\fR] [\\fB\\-\\-exit\\-after\\-time\\fR] [\\fB\\-\\-exit\\-after\\-modules\\fR] [\\fB\\-\\-print\\-completions\\fR] [\\fB\\-\\-print\\-manpage\\fR] [\\fB\\-h\\fR|\\fB\\-\\-help\\fR] [\\fB\\-V\\fR|\\fB\\-\\-version\\fR] 
.SH DESCRIPTION
A nonsense activity generator
.SH OPTIONS
.TP
\\fB\\-l\\fR, \\fB\\-\\-list\\-modules\\fR
List available modules
.TP
\\fB\\-m\\fR, \\fB\\-\\-modules\\fR \\fI<MODULES>\\fR
Run only these modules
.br

.br
\\fIPossible values:\\fR
.RS 14
${MODULES.map(m => `.IP \\(bu 2\n${m}`).join("\n")}
.RE
.TP
\\fB\\-s\\fR, \\fB\\-\\-speed\\-factor\\fR \\fI<SPEED_FACTOR>\\fR [default: 1]
Global speed factor
.TP
\\fB\\-i\\fR, \\fB\\-\\-instant\\-print\\-lines\\fR \\fI<INSTANT_PRINT_LINES>\\fR [default: 0]
Instantly print this many lines
.TP
\\fB\\-\\-inhibit\\fR
Keep the computer awake and the display on while genact is running
.TP
\\fB\\-\\-exit\\-after\\-time\\fR \\fI<EXIT_AFTER_TIME>\\fR
Exit after running for this long (format example: 2h10min)
.TP
\\fB\\-\\-exit\\-after\\-modules\\fR \\fI<EXIT_AFTER_MODULES>\\fR
Exit after running this many modules
.TP
\\fB\\-\\-print\\-completions\\fR \\fI<shell>\\fR
Generate completion file for a shell
.TP
\\fB\\-\\-print\\-manpage\\fR
Generate man page
.TP
\\fB\\-h\\fR, \\fB\\-\\-help\\fR
Print help
.TP
\\fB\\-V\\fR, \\fB\\-\\-version\\fR
Print version
.SH VERSION
v${VERSION}
.SH AUTHORS
Sven\\-Hendrik Haase <svenstaro@gmail.com>
`;
}

function completions(shell: string): string {
  const mods = MODULES.join(" ");
  if (shell === "bash") {
    return `_genact() {
    local cur prev opts
    COMPREPLY=()
    cur="\${COMP_WORDS[COMP_CWORD]}"
    prev="\${COMP_WORDS[COMP_CWORD-1]}"
    opts="-l -m -s -i -h -V --list-modules --modules --speed-factor --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage --help --version"
    case "\${prev}" in
        --modules|-m) COMPREPLY=($(compgen -W "${mods}" -- "\${cur}")); return 0 ;;
        --print-completions) COMPREPLY=($(compgen -W "bash elvish fish powershell zsh" -- "\${cur}")); return 0 ;;
    esac
    COMPREPLY=($(compgen -W "\${opts}" -- "\${cur}"))
}
complete -F _genact genact
`;
  }
  if (shell === "fish") return `complete -c genact -s l -l list-modules -d 'List available modules'\ncomplete -c genact -s m -l modules -a '${mods}'\n`;
  if (shell === "zsh") return `#compdef genact\n_arguments '-l[List available modules]' '-m[Run only these modules]:module:(${mods})' '--help[Print help]'\n`;
  if (shell === "powershell") return `using namespace System.Management.Automation\n# genact completions\n`;
  if (shell === "elvish") return `# genact completions\n`;
  invalidCompletion(shell);
}

function listModules(): string {
  return `Available modules:\n${MODULES.map(m => `  ${m}`).join("\n")}\n`;
}

function error(msg: string): never {
  process.stderr.write(`error: ${msg}\n\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function invalidModule(value: string): never {
  process.stderr.write(`error: invalid value '${value}' for '--modules <MODULES>'\n  [possible values: ${MODULES.join(", ")}]\n\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function invalidCompletion(value: string): never {
  process.stderr.write(`error: invalid value '${value}' for '--print-completions <shell>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function parse(): Options | undefined {
  const args = process.argv.slice(2);
  const opts: Options = { modules: [], speedFactor: 1, instantLines: 0 };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    const need = (name: string): string => {
      const v = args[++i];
      if (v === undefined) error(`a value is required for '${name} <${name.replace(/^--?/, "").toUpperCase()}>' but none was supplied`);
      return v;
    };
    switch (a) {
      case "-h": case "--help": process.stdout.write(help()); return undefined;
      case "-V": case "--version": process.stdout.write(`genact ${VERSION}\n`); return undefined;
      case "-l": case "--list-modules": process.stdout.write(listModules()); return undefined;
      case "--print-manpage": process.stdout.write(manpage()); return undefined;
      case "--print-completions": process.stdout.write(completions(need(a))); return undefined;
      case "--inhibit": break;
      case "-m": case "--modules": {
        const v = need(a);
        if (!(MODULES as readonly string[]).includes(v)) invalidModule(v);
        opts.modules.push(v as ModuleName);
        break;
      }
      case "-s": case "--speed-factor": opts.speedFactor = Number(need(a)) || 1; break;
      case "-i": case "--instant-print-lines": opts.instantLines = Math.max(0, Number(need(a)) | 0); break;
      case "--exit-after-modules": opts.exitAfterModules = Math.max(0, Number(need(a)) | 0); break;
      case "--exit-after-time": opts.exitAfterTime = need(a); break;
      default: error(`unexpected argument '${a}' found`);
    }
  }
  if (opts.modules.length === 0) opts.modules = MODULES.slice() as ModuleName[];
  return opts;
}

function moduleLine(module: ModuleName, i: number): string {
  const paths = ["arch/x86/kernel", "drivers/net/ethernet/intel", "fs/ext4", "kernel/sched", "drivers/gpu/drm/amd/amdgpu", "sound/pci/hda", "crypto", "mm"];
  const files = ["main", "init", "setup", "core", "sys", "util", "inode", "device", "parser", "worker"];
  switch (module) {
    case "cargo": return `${rng.pick([" Downloading", "   Compiling", "    Checking"])} ${rng.pick(["serde", "tokio", "clap", "rand", "regex", "openssl-sys", "genact", "tracing"])} v${rng.int(0, 2)}.${rng.int(0, 99)}.${rng.int(0, 20)}`;
    case "cc": return `${rng.pick(["gcc", "clang"])} -c -O${rng.int(1, 3)} -Wall -Wextra -Wundef -fPIC -funroll-loops -I${rng.pick(paths)} -D${rng.pick(["DEBUG", "NDEBUG", "PIC", "_REENTRANT"])} -o ${rng.pick(paths)}/${rng.pick(files)}.o`;
    case "kernel_compile": return `  CC      ${rng.pick(paths)}/${rng.pick(files)}.o`;
    case "download": return `${rng.int(1, 99)}% [${"#".repeat(i % 20).padEnd(20, ".")}] ${rng.int(50, 950)} KiB/s downloading https://mirror.example.org/${rng.pick(files)}-${rng.int(1, 9)}.${rng.int(0, 9)}.tar.gz`;
    case "weblog": return `${rng.int(10, 240)}.${rng.int(0, 255)}.${rng.int(0, 255)}.${rng.int(1, 254)} - - [${new Date(Date.now() + i * 1000).toISOString()}] "GET /${rng.pick(["", "index.html", "api/v1/users", "assets/app.js", "wp-login.php"])} HTTP/1.1" ${rng.pick([200, 200, 301, 304, 404, 500])} ${rng.int(128, 65535)}`;
    case "memdump": return `0x${rng.hex(8)}  ${Array.from({ length: 16 }, () => rng.hex(2)).join(" ")}  |${Array.from({ length: 16 }, () => String.fromCharCode(rng.int(32, 126))).join("")}|`;
    case "docker_build": return `Step ${i + 1}/${rng.int(i + 3, i + 9)} : ${rng.pick(["FROM ubuntu:22.04", "RUN apt-get update", "COPY . /app", "RUN cargo build --release", "CMD ./app"])}`;
    case "docker_image_rm": return `Untagged: ${rng.pick(["alpine", "ubuntu", "node", "redis", "postgres"])}:${rng.pick(["latest", "22.04", "20", "7", "15"])}\nDeleted: sha256:${rng.hex(64)}`;
    case "cryptomining": return `[${rng.int(1, 12)}:${rng.int(10, 59)}:${rng.int(10, 59)}] accepted: ${i}/${i + rng.int(1, 5)} (${rng.int(50, 900)}.${rng.int(0, 9)} kH/s) yes!`;
    case "bruteforce": return `Trying ${rng.pick(["root", "admin", "oracle", "postgres", "deploy"])}:${rng.pick(["password", "123456", "qwerty", "letmein", rng.hex(6)])} on ${rng.int(10, 192)}.${rng.int(0, 168)}.${rng.int(0, 255)}.${rng.int(1, 254)} ... ${rng.pick(["failed", "failed", "timeout"])}`;
    case "ansible": return `${rng.pick(["TASK", "PLAY", "RUNNING HANDLER"])} [${rng.pick(["Gathering Facts", "Install packages", "Template config", "Restart service"])}] ${"*".repeat(rng.int(10, 45))}`;
    case "terraform": return `${rng.pick(["aws_instance.web", "module.vpc.aws_subnet.public", "google_compute_network.main"])}: ${rng.pick(["Refreshing state...", "Creating...", "Still creating...", "Creation complete"])} [id=${rng.hex(8)}]`;
    case "composer": return `${rng.pick(["Installing", "Updating", "Downloading"])} ${rng.pick(["symfony/console", "psr/log", "doctrine/orm", "monolog/monolog"])} (${rng.int(1, 9)}.${rng.int(0, 9)}.${rng.int(0, 20)})`;
    case "uv": return `${rng.pick(["Resolved", "Prepared", "Installed"])} ${rng.int(1, 127)} packages in ${rng.int(10, 900)}ms`;
    case "julia": return `${rng.pick(["Precompiling", "Updating registry", "Resolving package versions", "Installing"])} ${rng.pick(["DataFrames", "Flux", "Plots", "JuMP", "HTTP"])} v${rng.int(0, 2)}.${rng.int(1, 12)}.${rng.int(0, 9)}`;
    case "rkhunter": return `[${rng.pick([" OK ", "Warn"])}] Checking ${rng.pick(["system commands", "rootkit files", "network interfaces", "loaded modules", "hidden processes"])}`;
    case "mkinitcpio": return `==> ${rng.pick(["Starting build", "Generating module dependencies", "Creating gzip-compressed initcpio image", "Build complete"])}: '${rng.pick(["linux", "linux-lts", "fallback"])}'`;
    case "bootlog": return `[  ${rng.int(0, 99)}.${rng.int(100000, 999999)}] ${rng.pick(["systemd", "kernel", "audit", "udevd"])}: ${rng.pick(["Started Network Manager", "Mounted /home", "Reached target Multi-User System", "Loading initial ramdisk"])}`;
    case "botnet": return `bot-${rng.hex(6)} ${rng.pick(["connected", "syn flood", "beacon", "awaiting command"])} ${rng.int(100, 9999)} packets/s`;
    case "simcity": return `Year ${1900 + i}: ${rng.pick(["Residential", "Commercial", "Industrial"])} demand ${rng.int(-100, 100)}; population ${rng.int(1000, 999999)}`;
    case "wpt": return `Test ${rng.pick(["First View", "Repeat View"])}: ${rng.pick(["DNS Lookup", "TTFB", "Start Render", "Speed Index"])} ${rng.int(10, 5000)}ms`;
  }
}

async function main(): Promise<void> {
  const opts = parse();
  if (!opts) return;
  const maxModules = opts.exitAfterModules ?? (opts.exitAfterTime ? opts.modules.length : 1);
  const linesPerModule = Math.max(opts.instantLines || 40, 1);
  let printedModules = 0;
  for (const module of opts.modules) {
    for (let i = 0; i < linesPerModule; i++) process.stdout.write(moduleLine(module, i) + "\n");
    printedModules++;
    if (printedModules >= maxModules) break;
  }
}

main().catch(e => {
  process.stderr.write(String(e) + "\n");
  process.exit(1);
});
