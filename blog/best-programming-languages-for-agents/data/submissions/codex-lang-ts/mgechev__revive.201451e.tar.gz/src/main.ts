declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");
const arg0 = process.env.REVIVE_ARG0 || process.argv[1];

type Pos = { Filename: string; Offset: number; Line: number; Column: number };
type Issue = {
  Severity: string;
  Failure: string;
  RuleName: string;
  Category: string;
  Position: { Start: Pos; End: Pos };
  Confidence: number;
  ReplacementLine: string;
};

const BANNER = `
 _ __ _____   _(_)__  _____
| '__/ _ \\ \\ / / \\ \\ / / _ \\
| | |  __/\\ V /| |\\ V /  __/
|_|  \\___| \\_/ |_| \\_/ \\___|

Example:
  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...
`;

const FLAG_USAGE = `  -config string
\tpath to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)
  -exclude value
\tlist of globs which specify files to be excluded (i.e. -exclude foo/...)
  -formatter string
\tformatter to be used for the output (i.e. -formatter stylish)
  -max_open_files int
\tmaximum number of open files at the same time
  -set_exit_status
\tset exit status to 1 if any issues are found, overwrites errorCode and warningCode in config
  -version
\tget revive version`;

function printHelp(full: boolean) {
  if (full) process.stdout.write(`Usage of ${arg0}:\n${BANNER}\n${FLAG_USAGE}\n`);
  else process.stdout.write(`${BANNER}\nflag provided but not defined: ${badFlag}\nUsage of ${arg0}:\n${FLAG_USAGE}\n`);
}

let badFlag = "";

type Config = {
  severity: string;
  errorCode: number;
  warningCode: number;
  rules: Record<string, { disabled: boolean; args: any[] }>;
};

function parseArgs(argv: string[]) {
  const opts: any = { formatter: "default", excludes: [], setExitStatus: false, packages: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help" || a === "-h") { opts.help = true; continue; }
    if (a === "-version") { opts.version = true; continue; }
    if (a === "-set_exit_status") { opts.setExitStatus = true; continue; }
    if (a === "-config" || a === "-formatter" || a === "-exclude" || a === "-max_open_files") {
      const v = argv[++i];
      if (v === undefined) {
        process.stderr.write(`flag needs an argument: ${a}\nUsage of ${arg0}:\n${FLAG_USAGE}\n`);
        process.exit(2);
      }
      if (a === "-exclude") opts.excludes.push(v);
      else if (a === "-max_open_files") opts.maxOpenFiles = Number(v);
      else opts[a.slice(1)] = v;
      continue;
    }
    if (a.startsWith("-")) {
      badFlag = a;
      printHelp(false);
      process.exit(2);
    }
    opts.packages.push(a);
  }
  return opts;
}

function version() {
  process.stdout.write("Version:\ta75b67b\nCommit:\t\ta75b67b73b9edb91dfc9f302dd108fa9d3ea5b05\nBuilt\t\t2026-04-17 19:59 UTC by build.sh\n");
}

function parseConfig(file?: string): Config | null {
  if (!file) return null;
  let text = "";
  try { text = fs.readFileSync(file, "utf8"); }
  catch { process.stdout.write("cannot read the config file\n"); process.exit(1); }
  const cfg: Config = { severity: "warning", errorCode: 0, warningCode: 0, rules: {} };
  let current = "";
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.replace(/#.*/, "").trim();
    if (!line) continue;
    const sec = line.match(/^\[rule\.([A-Za-z0-9_-]+)\]$/);
    if (sec) {
      current = sec[1];
      if (!cfg.rules[current]) cfg.rules[current] = { disabled: false, args: [] };
      continue;
    }
    const kv = line.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!kv) continue;
    const key = kv[1], val = kv[2].trim();
    if (current) {
      if (key.toLowerCase() === "disabled") cfg.rules[current].disabled = /^true$/i.test(val);
      if (key === "arguments") {
        const nums = Array.from(val.matchAll(/-?\d+/g)).map((m: any) => Number(m[0]));
        cfg.rules[current].args = nums;
      }
    } else {
      if (key === "severity") cfg.severity = strip(val) || "warning";
      if (key === "errorCode") cfg.errorCode = Number(val) || 0;
      if (key === "warningCode") cfg.warningCode = Number(val) || 0;
    }
  }
  return cfg;
}

function strip(s: string) { return s.replace(/^["']|["']$/g, ""); }

function defaultConfigError() {
  process.stdout.write('initializing revive - getting lint rules: cannot configure rule: "var-naming": load std packages: err: go command required, not found: exec: "go": executable file not found in $PATH: stderr: \n');
  process.exit(1);
}

function walk(dir: string, out: string[]) {
  let ents: any[] = [];
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  ents.sort((a: any, b: any) => a.name.localeCompare(b.name));
  for (const e of ents) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name !== ".git" && e.name !== "vendor" && e.name !== "node_modules" && e.name !== "dist") walk(p, out);
    } else if (e.isFile() && e.name.endsWith(".go") && !e.name.endsWith("_test.go")) out.push(norm(p));
  }
}

function norm(p: string) { return p.split(path.sep).join("/").replace(/^\.\//, ""); }

function gatherFiles(args: string[], excludes: string[]): string[] {
  if (!args.length) args = ["."];
  const files: string[] = [];
  for (const a of args) {
    if (a.endsWith("/...") || a === "./...") {
      const base = a === "./..." ? "." : a.slice(0, -4);
      walk(base || ".", files);
    } else {
      let st: any = null;
      try { st = fs.statSync(a); } catch { continue; }
      if (st.isDirectory()) walk(a, files);
      else if (st.isFile() && a.endsWith(".go")) files.push(norm(a));
    }
  }
  const uniq = Array.from(new Set(files)).sort();
  return uniq.filter(f => !excludes.some(ex => matchExclude(f, ex)));
}

function matchExclude(file: string, pat: string): boolean {
  pat = norm(pat);
  if (pat.endsWith("/...")) return file === pat.slice(0, -4) || file.startsWith(pat.slice(0, -3));
  if (pat.includes("*")) {
    const re = new RegExp("^" + pat.split("*").map(esc).join(".*") + "$");
    return re.test(file);
  }
  return file === pat || file.endsWith("/" + pat);
}
function esc(s: string) { return s.replace(/[.+?^${}()|[\]\\]/g, "\\$&"); }

function posAt(text: string, filename: string, offset: number): Pos {
  let line = 1, col = 1;
  for (let i = 0; i < offset; i++) {
    if (text[i] === "\n") { line++; col = 1; } else col++;
  }
  return { Filename: filename, Offset: offset, Line: line, Column: col };
}

function lineOffset(lines: string[], idx: number) {
  let off = 0;
  for (let i = 0; i < idx; i++) off += lines[i].length + 1;
  return off;
}

function previousComment(lines: string[], idx: number, name: string): boolean {
  let j = idx - 1;
  while (j >= 0 && lines[j].trim() === "") j--;
  if (j < 0) return false;
  const t = lines[j].trim();
  return t.startsWith("// " + name) || t.startsWith("//" + name) || t.startsWith("/* " + name) || t.startsWith("/*" + name);
}

function issue(file: string, text: string, start: number, end: number, rule: string, cat: string, msg: string, severity: string): Issue {
  return { Severity: severity, Failure: msg, RuleName: rule, Category: cat, Position: { Start: posAt(text, file, start), End: posAt(text, file, end) }, Confidence: 1, ReplacementLine: "" };
}

function lintFile(file: string, cfg: Config): Issue[] {
  const text = fs.readFileSync(file, "utf8");
  const lines = text.split(/\n/);
  const issues: Issue[] = [];
  const enabled = (r: string) => cfg.rules[r] && !cfg.rules[r].disabled;
  const disabledLine = (i: number, rule: string) => {
    const prev = i > 0 ? lines[i - 1] : "";
    const cur = lines[i] || "";
    return prev.includes("revive:disable-next-line") || cur.includes("revive:disable-line") || text.includes("revive:disable");
  };
  if (enabled("package-comments")) {
    const mi = lines.findIndex(l => /^\s*package\s+\w+/.test(l));
    if (mi >= 0) {
      let has = false;
      for (let j = 0; j < mi; j++) if (lines[j].trim().startsWith("// Package ") || lines[j].trim().startsWith("/* Package ")) has = true;
      if (!has && !disabledLine(mi, "package-comments")) {
        const start = lineOffset(lines, mi) + (lines[mi].match(/^\s*/)?.[0].length || 0);
        issues.push(issue(file, text, start, start + lines[mi].trimEnd().length, "package-comments", "comments", "should have a package comment", cfg.severity));
      }
    }
  }
  if (enabled("exported")) {
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      const m = l.match(/^(\s*)(func|type|var|const)\s+(?:\([^)]*\)\s*)?([A-Z][A-Za-z0-9_]*)/);
      if (!m || disabledLine(i, "exported")) continue;
      const kind = m[2], name = m[3];
      if (previousComment(lines, i, name)) continue;
      const col = kind === "func" ? m[1].length : l.indexOf(name);
      const start = lineOffset(lines, i) + col;
      const end = lineOffset(lines, i) + l.length;
      const k = kind === "func" ? "function" : kind;
      issues.push(issue(file, text, start, end, "exported", "comments", `exported ${k} ${name} should have comment or be unexported`, cfg.severity));
    }
  }
  if (enabled("line-length-limit")) {
    const limit = cfg.rules["line-length-limit"].args[0] || 80;
    for (let i = 0; i < lines.length; i++) {
      const len = lines[i].replace(/\r$/, "").length;
      if (len > limit && !disabledLine(i, "line-length-limit")) {
        const start = lineOffset(lines, i);
        issues.push(issue(file, text, start, start + len, "line-length-limit", "style", `line is ${len} characters, out of limit ${limit}`, cfg.severity));
      }
    }
  }
  return issues;
}

function fmtDefault(issues: Issue[]) {
  for (const x of issues) {
    if (x.RuleName === "line-length-limit") process.stdout.write(`${x.Position.Start.Filename}:${x.Position.Start.Line}: ${x.Failure}\n`);
    else process.stdout.write(`${x.Position.Start.Filename}:${x.Position.Start.Line}:${x.Position.Start.Column}: ${x.Failure}\n`);
  }
}
function fmtPlain(issues: Issue[]) {
  for (const x of issues) process.stdout.write(`${x.Position.Start.Filename}:${x.Position.Start.Line}:${x.Position.Start.Column}: ${x.Failure} https://revive.run/r#${x.RuleName}\n`);
  if (issues.length) process.stdout.write("\n");
}
function fmtUnix(issues: Issue[]) {
  for (const x of issues) process.stdout.write(`${x.Position.Start.Filename}:${x.Position.Start.Line}:${x.Position.Start.Column}: [${x.RuleName}] ${x.Failure}\n`);
  if (issues.length) process.stdout.write("\n");
}
function fmtNdjson(issues: Issue[]) {
  for (const x of issues) process.stdout.write(JSON.stringify(x) + "\n");
  if (issues.length) process.stdout.write("\n");
}
function groupRules(issues: Issue[]) {
  const m: Record<string, number> = {};
  for (const x of issues) m[x.RuleName] = (m[x.RuleName] || 0) + 1;
  return m;
}
function fmtFriendly(issues: Issue[]) {
  for (const x of issues) process.stdout.write(`  ⚠  https://revive.run/r#${x.RuleName}  ${x.Failure}\n  ${x.Position.Start.Filename}:${x.Position.Start.Line}:${x.Position.Start.Column}\n\n`);
  if (issues.length) {
    const errs = issues.filter(i => i.Severity === "error").length, warns = issues.length - errs;
    process.stdout.write(`⚠ ${issues.length} problems (${errs} errors, ${warns} warnings)\n\nWarnings:\n`);
    for (const [r, n] of Object.entries(groupRules(issues))) process.stdout.write(`  ${n}  ${r}\n`);
    process.stdout.write("\n\n");
  }
}
function fmtStylish(issues: Issue[]) {
  const by: Record<string, Issue[]> = {};
  for (const x of issues) (by[x.Position.Start.Filename] ||= []).push(x);
  for (const f of Object.keys(by).sort()) {
    process.stdout.write(`${f}\n`);
    for (const x of by[f]) process.stdout.write(`  (${x.Position.Start.Line}, ${x.Position.Start.Column})  https://revive.run/r#${x.RuleName}  ${x.Failure}\n`);
    process.stdout.write("\n");
  }
  if (issues.length) {
    const errs = issues.filter(i => i.Severity === "error").length, warns = issues.length - errs;
    process.stdout.write(`\n ✖ ${issues.length} problems (${errs} errors) (${warns} warnings)\n`);
  }
}
function xmlEsc(s: string) { return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function fmtCheckstyle(issues: Issue[]) {
  process.stdout.write("<?xml version='1.0' encoding='UTF-8'?>\n<checkstyle version=\"5.0\">\n");
  const by: Record<string, Issue[]> = {};
  for (const x of issues) (by[x.Position.Start.Filename] ||= []).push(x);
  for (const f of Object.keys(by).sort()) {
    process.stdout.write(`    <file name="${xmlEsc(f)}">\n`);
    for (const x of by[f]) process.stdout.write(`      <error line="${x.Position.Start.Line}" column="${x.Position.Start.Column}" message="${xmlEsc(x.Failure)} (confidence 1)" severity="${x.Severity}" source="revive/${x.RuleName}"/>\n`);
    process.stdout.write("    </file>\n");
  }
  process.stdout.write("</checkstyle>\n");
}
function fmtSarif(issues: Issue[]) {
  const rules = Array.from(new Set(issues.map(i => i.RuleName))).sort().map(r => ({ helpUri: `https://revive.run/r#${r}`, id: r, properties: { severity: "" } }));
  const results = issues.map(x => ({ locations: [{ physicalLocation: { artifactLocation: { uri: x.Position.Start.Filename }, region: { startColumn: x.Position.Start.Column, startLine: x.Position.Start.Line } } }], message: { text: x.Failure }, ruleId: x.RuleName }));
  process.stdout.write(JSON.stringify({ runs: [{ results, tool: { driver: { informationUri: "https://revive.run", name: "revive", rules } } }], version: "2.1.0" }, null, 2) + "\n");
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) { printHelp(true); return; }
  if (opts.version) { version(); return; }
  const cfg = parseConfig(opts.config);
  if (!cfg) defaultConfigError();
  if (cfg.rules["var-naming"] && !cfg.rules["var-naming"].disabled) defaultConfigError();
  const formatters: any = { default: fmtDefault, plain: fmtPlain, unix: fmtUnix, json: (i: Issue[]) => process.stdout.write((i.length ? JSON.stringify(i) : "null") + "\n"), ndjson: fmtNdjson, friendly: fmtFriendly, stylish: fmtStylish, checkstyle: fmtCheckstyle, sarif: fmtSarif };
  if (!formatters[opts.formatter]) {
    process.stdout.write(`formatting - getting formatter: unknown formatter ${opts.formatter}\n`);
    process.exit(1);
  }
  const files = gatherFiles(opts.packages, opts.excludes);
  const issues = files.flatMap(f => lintFile(f, cfg));
  formatters[opts.formatter](issues);
  if (opts.setExitStatus && issues.length) process.exit(1);
  const hasErr = issues.some(i => i.Severity === "error");
  const hasWarn = issues.some(i => i.Severity !== "error");
  if (hasErr && cfg.errorCode) process.exit(cfg.errorCode);
  if (hasWarn && cfg.warningCode) process.exit(cfg.warningCode);
}

main();
