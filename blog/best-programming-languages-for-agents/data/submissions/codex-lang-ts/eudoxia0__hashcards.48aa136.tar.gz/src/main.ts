declare const require: any;
declare const process: any;

const fs = require('fs');
const path = require('path');
const nodeCrypto = require('crypto');
const http = require('http');

type Card = {
  hash: string;
  familyHash: string | null;
  deckName: string;
  location: { filePath: string; lineStart: number; lineEnd: number };
  content: any;
  performance: null;
};

function sha256(s: string): string {
  return nodeCrypto.createHash('sha256').update(s, 'utf8').digest('hex');
}

function trimBlankLines(lines: string[]): { lines: string[]; leading: number; trailing: number } {
  let a = 0;
  let b = lines.length;
  while (a < b && lines[a].trim() === '') a++;
  while (b > a && lines[b - 1].trim() === '') b--;
  return { lines: lines.slice(a, b), leading: a, trailing: lines.length - b };
}

function isStart(line: string): boolean {
  return /^\s*[QC]:/.test(line);
}
function isQ(line: string): boolean { return /^\s*Q:/.test(line); }
function isA(line: string): boolean { return /^\s*A:/.test(line); }
function isC(line: string): boolean { return /^\s*C:/.test(line); }
function afterMarker(line: string): string { return line.replace(/^\s*[QAC]:\s?/, ''); }

function parseCloze(raw: string): { text: string; ranges: Array<[number, number]> } {
  let text = '';
  const ranges: Array<[number, number]> = [];
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (ch === '[') {
      let j = i + 1;
      while (j < raw.length && raw[j] !== ']') j++;
      if (j < raw.length) {
        const inner = raw.slice(i + 1, j);
        const start = text.length;
        text += inner;
        ranges.push([start, text.length ? text.length - 1 : start]);
        i = j;
        continue;
      }
    }
    text += ch;
  }
  return { text, ranges };
}

function makeBasic(deckName: string, filePath: string, start: number, end: number, question: string, answer: string): Card {
  const content = { basic: { question, answer } };
  return {
    hash: sha256('basic\0' + question + '\0' + answer),
    familyHash: null,
    deckName,
    location: { filePath, lineStart: start, lineEnd: end },
    content,
    performance: null,
  };
}

function makeClozes(deckName: string, filePath: string, start: number, end: number, raw: string): Card[] {
  const parsed = parseCloze(raw);
  const familyHash = sha256('cloze-family\0' + parsed.text);
  return parsed.ranges.map(([a, b], idx) => {
    const content = { cloze: { text: parsed.text, start: a, end: b } };
    return {
      hash: sha256('cloze\0' + parsed.text + '\0' + a + '\0' + b + '\0' + idx),
      familyHash,
      deckName,
      location: { filePath, lineStart: start, lineEnd: end },
      content,
      performance: null,
    };
  });
}

function parseMarkdown(filePath: string): Card[] {
  const deckName = path.basename(filePath, path.extname(filePath));
  const text = fs.readFileSync(filePath, 'utf8').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const lines = text.split('\n');
  if (lines.length && lines[lines.length - 1] === '') lines.pop();
  const cards: Card[] = [];
  let i = 0;
  while (i < lines.length) {
    if (isQ(lines[i])) {
      const start = i;
      const qLines: string[] = [afterMarker(lines[i])];
      i++;
      while (i < lines.length && !isA(lines[i]) && !isStart(lines[i])) { qLines.push(lines[i]); i++; }
      if (i >= lines.length || !isA(lines[i])) continue;
      const aLines: string[] = [afterMarker(lines[i])];
      i++;
      while (i < lines.length && !isStart(lines[i])) { aLines.push(lines[i]); i++; }
      const qt = trimBlankLines(qLines).lines.join('\n');
      const at = trimBlankLines(aLines).lines.join('\n');
      cards.push(makeBasic(deckName, filePath, start, i < lines.length ? i : Math.max(start, lines.length - 1), qt, at));
      continue;
    }
    if (isC(lines[i])) {
      const start = i;
      const cLines: string[] = [afterMarker(lines[i])];
      i++;
      while (i < lines.length && !isStart(lines[i])) { cLines.push(lines[i]); i++; }
      const ct = trimBlankLines(cLines).lines.join('\n');
      cards.push(...makeClozes(deckName, filePath, start, i < lines.length ? i : Math.max(start, lines.length - 1), ct));
      continue;
    }
    i++;
  }
  return cards;
}

function collectionFiles(dir: string): string[] {
  const root = path.resolve(dir || '.');
  if (!fs.existsSync(root)) throw new Error(`No such file or directory: ${root}`);
  return fs.readdirSync(root)
    .filter((f: string) => f.toLowerCase().endsWith('.md'))
    .sort()
    .map((f: string) => path.join(root, f));
}

function loadCards(dir: string): Card[] {
  const cards: Card[] = [];
  for (const f of collectionFiles(dir)) cards.push(...parseMarkdown(f));
  cards.sort((a, b) => a.hash.localeCompare(b.hash));
  return cards;
}

function texMacroCount(dir: string): number {
  const root = path.resolve(dir || '.');
  if (!fs.existsSync(root)) return 0;
  let n = 0;
  for (const f of fs.readdirSync(root)) {
    if (!f.toLowerCase().endsWith('.tex')) continue;
    const s = fs.readFileSync(path.join(root, f), 'utf8');
    const m = s.match(/\\(?:newcommand|renewcommand|def|DeclareMathOperator)\b/g);
    if (m) n += m.length;
    else n += s.split(/\n/).filter((line: string) => line.trim() && !line.trim().startsWith("%" )).length;
  }
  return n;
}

function printTopHelp() {
  console.log(`A plain text-based spaced repetition system.\n\nUsage: executable <COMMAND>\n\nCommands:\n  drill    Drill cards through a web interface\n  check    Check the integrity of a collection\n  stats    Print collection statistics\n  orphans  Commands relating to orphan cards\n  export   Export a collection\n  help     Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version`);
}

const helps: Record<string, string> = {
  check: `Check the integrity of a collection\n\nUsage: executable check [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help`,
  export: `Export a collection\n\nUsage: executable export [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --output <OUTPUT>  Optional path to the output file. By default, the output is printed to stdout\n  -h, --help             Print help`,
  stats: `Print collection statistics\n\nUsage: executable stats [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]\n          Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --format <FORMAT>\n          Which output format to use\n\n          Possible values:\n          - html: HTML output\n          - json: JSON output\n          \n          [default: html]\n\n  -h, --help\n          Print help (see a summary with '-h')`,
  orphans: `Commands relating to orphan cards\n\nUsage: executable orphans <COMMAND>\n\nCommands:\n  list    List the hashes of all orphan cards in the collection\n  delete  Remove all orphan cards from the database\n  help    Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help  Print help`,
  drill: `Drill cards through a web interface\n\nUsage: executable drill [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]\n          Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --card-limit <CARD_LIMIT>\n          Maximum number of cards to drill in a session. By default, all cards due today are drilled\n\n      --new-card-limit <NEW_CARD_LIMIT>\n          Maximum number of new cards to drill in a session\n\n      --host <HOST>\n          The host address to bind to. Default is 127.0.0.1\n          \n          [default: 127.0.0.1]\n\n      --port <PORT>\n          The port to use for the web server. Default is 8000\n          \n          [default: 8000]\n\n      --from-deck <FROM_DECK>\n          Only drill cards from this deck\n\n      --open-browser <OPEN_BROWSER>\n          Whether to open the browser automatically. Default is true\n          \n          [possible values: true, false]\n\n      --answer-controls <ANSWER_CONTROLS>\n          Which answer controls to show:\n\n          Possible values:\n          - full:   Show all four rating buttons (Forgot/Hard/Good/Easy)\n          - binary: Show only two rating buttons (Forgot/Good)\n          \n          [default: full]\n\n      --bury-siblings <BURY_SIBLINGS>\n          Whether or not to bury siblings. Default is true\n          \n          [possible values: true, false]\n\n  -h, --help\n          Print help (see a summary with '-h')`,
  'orphans list': `List the hashes of all orphan cards in the collection\n\nUsage: executable orphans list [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help`,
  'orphans delete': `Remove all orphan cards from the database\n\nUsage: executable orphans delete [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help`,
};

function die(msg: string, code = 1): void {
  console.error(`hashcards: error: ${msg}`);
  process.exit(code);
}

function argDirectory(args: string[]): string {
  const positional = args.filter(a => !a.startsWith('-'));
  return positional[0] || '.';
}

function cmdStats(args: string[]) {
  if (args.includes('-h') || args.includes('--help')) return console.log(helps.stats);
  let format = 'html';
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--format') { format = args[++i] || ''; continue; }
    rest.push(args[i]);
  }
  const dir = argDirectory(rest);
  if (format === 'html') return console.log('HTML output is not implemented yet.');
  if (format !== 'json') die(`invalid value '${format}' for '--format <FORMAT>'`);
  const obj = { cardsInDeckCount: loadCards(dir).length, cardsInDbCount: 0, texMacroCount: texMacroCount(dir), cardsReviewedTodayCount: 0 };
  console.log(JSON.stringify(obj, null, 2));
}

function cmdExport(args: string[]) {
  if (args.includes('-h') || args.includes('--help')) return console.log(helps.export);
  let output: string | null = null;
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--output') { output = args[++i] || null; continue; }
    rest.push(args[i]);
  }
  const dir = argDirectory(rest);
  const data = JSON.stringify({ cards: loadCards(dir), sessions: [] }, null, 2) + '\n';
  if (output) fs.writeFileSync(output, data); else process.stdout.write(data);
}

function cmdCheck(args: string[]) {
  if (args.includes('-h') || args.includes('--help')) return console.log(helps.check);
  loadCards(argDirectory(args));
  console.log('ok');
}

function cmdOrphans(args: string[]) {
  if (args.length === 0 || args[0] === 'help' || args.includes('-h') || args.includes('--help')) return console.log(helps.orphans);
  if (args[0] === 'list') return;
  if (args[0] === 'delete') return;
  die(`unrecognized subcommand '${args[0]}'`);
}

function cmdDrill(args: string[]) {
  if (args.includes('-h') || args.includes('--help')) return console.log(helps.drill);
  let host = '127.0.0.1';
  let port = 8000;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--host') host = args[++i] || host;
    else if (args[i] === '--port') port = Number(args[++i] || port);
    else if (['--card-limit','--new-card-limit','--from-deck','--open-browser','--answer-controls','--bury-siblings'].includes(args[i])) i++;
  }
  const server = http.createServer((_req: any, res: any) => {
    res.setHeader('content-type', 'text/html; charset=utf-8');
    res.end('<!doctype html><title>Hashcards</title><h1>Hashcards</h1>');
  });
  server.listen(port, host, () => console.log(`Listening on http://${host}:${port}`));
}

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0 || args[0] === '-h' || args[0] === '--help' || args[0] === 'help') return printTopHelp();
  if (args[0] === '-V' || args[0] === '--version') return console.log('hashcards 0.3.0');
  try {
    const [cmd, ...rest] = args;
    if (cmd === 'check') return cmdCheck(rest);
    if (cmd === 'stats') return cmdStats(rest);
    if (cmd === 'export') return cmdExport(rest);
    if (cmd === 'orphans') return cmdOrphans(rest);
    if (cmd === 'drill') return cmdDrill(rest);
    die(`unrecognized subcommand '${cmd}'`);
  } catch (e: any) {
    die(e && e.message ? e.message : String(e));
  }
}

main();
