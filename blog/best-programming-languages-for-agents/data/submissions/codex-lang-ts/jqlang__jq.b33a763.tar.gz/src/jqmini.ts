#!/usr/bin/env node
declare var require: any;
declare var process: any;
const fs = require('fs');

type J = any;
type Ctx = { vars: Record<string,J>, args: {named: Record<string,J>, positional: J[]} };
type EvalFn = (input:J, ctx:Ctx)=>J[];

type Tok = {t:string, v:string};
class Lexer {
  s:string; i=0; toks:Tok[]=[];
  constructor(s:string){this.s=s;}
  lex():Tok[]{
    while(this.i<this.s.length){
      const c=this.s[this.i];
      if(/\s/.test(c)){this.i++; continue;}
      if(c==='#'){ while(this.i<this.s.length && this.s[this.i] !== '\n') this.i++; continue; }
      const two=this.s.slice(this.i,this.i+2);
      if(['==','!=','<=','>=','//','..'].includes(two)){this.toks.push({t:two,v:two}); this.i+=2; continue;}
      if(/[0-9]/.test(c) || (c==='-' && /[0-9]/.test(this.s[this.i+1]||''))) { this.toks.push({t:'num',v:this.readNum()}); continue; }
      if(c==='?'||c==='.'||c==='|'||c===','||c===':'||c===';'||c==='('||c===')'||c==='['||c===']'||c==='{'||c==='}'||c==='+'||c==='-'||c==='*'||c==='/'||c==='%'||c==='<'||c==='>') {this.toks.push({t:c,v:c}); this.i++; continue;}
      if(c==='$') { this.i++; const name=this.readIdent(); this.toks.push({t:'var',v:name}); continue; }
      if(c==='"' || c==="'") { this.toks.push({t:'str',v:this.readString(c)}); continue; }
      if(/[A-Za-z_]/.test(c)) { const id=this.readIdent(); this.toks.push({t:'id',v:id}); continue; }
      throw new Error(`unexpected character ${c}`);
    }
    this.toks.push({t:'eof',v:''}); return this.toks;
  }
  readIdent(){ const st=this.i; while(/[A-Za-z0-9_]/.test(this.s[this.i]||'')) this.i++; return this.s.slice(st,this.i); }
  readNum(){ const st=this.i; if(this.s[this.i]==='-') this.i++; while(/[0-9]/.test(this.s[this.i]||'')) this.i++; if(this.s[this.i]==='.') {this.i++; while(/[0-9]/.test(this.s[this.i]||'')) this.i++;} if(/[eE]/.test(this.s[this.i]||'')){this.i++; if(/[+-]/.test(this.s[this.i]||'')) this.i++; while(/[0-9]/.test(this.s[this.i]||'')) this.i++;} return this.s.slice(st,this.i); }
  readString(q:string){ let out=''; this.i++; while(this.i<this.s.length){ const c=this.s[this.i++]; if(c===q) return out; if(c==='\\'){ const n=this.s[this.i++]; if(n==='n') out+='\n'; else if(n==='r') out+='\r'; else if(n==='t') out+='\t'; else if(n==='b') out+='\b'; else if(n==='f') out+='\f'; else if(n==='u'){ const h=this.s.slice(this.i,this.i+4); this.i+=4; out+=String.fromCharCode(parseInt(h,16)); } else out+=n; } else out+=c;} throw new Error('unterminated string'); }
}

const truthy=(v:J)=>!(v===false||v===null);
const reserved=new Set(['as','then','else','end','and','or']);
const typeOf=(v:J)=>v===null?'null':Array.isArray(v)?'array':typeof v;
const deepEq=(a:J,b:J)=>JSON.stringify(a)===JSON.stringify(b);
const clone=(v:J)=> v===undefined?undefined:JSON.parse(JSON.stringify(v));
function cmp(a:J,b:J){ const sa=JSON.stringify(a), sb=JSON.stringify(b); if(typeof a==='number'&&typeof b==='number') return a-b; if(typeof a==='string'&&typeof b==='string') return a< b?-1:a>b?1:0; return sa<sb?-1:sa>sb?1:0; }
function jqAdd(a:J,b:J):J{ if(a==null) return b; if(b==null) return a; if(typeof a==='number'&&typeof b==='number') return a+b; if(typeof a==='string'&&typeof b==='string') return a+b; if(Array.isArray(a)&&Array.isArray(b)) return a.concat(b); if(typeOf(a)==='object'&&typeOf(b)==='object') return {...a,...b}; throw new Error('cannot add'); }
function jqSub(a:J,b:J):J{ if(typeof a==='number'&&typeof b==='number') return a-b; if(Array.isArray(a)&&Array.isArray(b)) return a.filter(x=>!b.some(y=>deepEq(x,y))); throw new Error('cannot subtract'); }
function len(v:J):number{ if(v==null) return 0; if(typeof v==='string'||Array.isArray(v)) return v.length; if(typeof v==='object') return Object.keys(v).length; if(typeof v==='number') return Math.abs(v); return 0; }

class Parser {
  toks:Tok[]; p=0;
  constructor(src:string){this.toks=new Lexer(src).lex();}
  peek(){return this.toks[this.p];} take(){return this.toks[this.p++];}
  eat(t:string){ if(this.peek().t===t){this.p++; return true;} return false; }
  need(t:string){ const x=this.take(); if(x.t!==t) throw new Error(`expected ${t}, got ${x.t}`); return x; }
  parse():EvalFn{ const e=this.parseComma(); if(this.peek().t!=='eof') throw new Error(`unexpected ${this.peek().v}`); return e; }
  parseComma():EvalFn{ let left=this.parsePipe(); const parts=[left]; while(this.eat(',')) parts.push(this.parsePipe()); if(parts.length===1) return left; return (inp,ctx)=>parts.flatMap(f=>f(inp,ctx)); }
  parsePipe():EvalFn{ let f=this.parseAs(); while(this.eat('|')){ const g=this.parseAs(); const prev=f; f=(inp,ctx)=>prev(inp,ctx).flatMap(v=>g(v,ctx)); } return f; }
  parseAs():EvalFn{ const f=this.parseAlt(); if(this.peek().t==='id' && this.peek().v==='as'){ this.take(); const v=this.need('var').v; this.need('|'); const rest=this.parsePipe(); return (inp,ctx)=>f(inp,ctx).flatMap(val=>rest(inp,{...ctx, vars:{...ctx.vars,[v]:val}})); } return f; }
  parseAlt():EvalFn{ let f=this.parseBool(); while(this.eat('//')){ const g=this.parseBool(); const prev=f; f=(inp,ctx)=>{ const r=prev(inp,ctx).filter(truthy); return r.length?r:g(inp,ctx); }; } return f; }
  parseBool():EvalFn{ let f=this.parseCmp(); while(this.peek().t==='id' && ['and','or'].includes(this.peek().v)){ const op=this.take().v; const g=this.parseCmp(); const prev=f; f=(inp,ctx)=>[op==='and' ? (prev(inp,ctx).some(truthy)&&g(inp,ctx).some(truthy)) : (prev(inp,ctx).some(truthy)||g(inp,ctx).some(truthy))]; } return f; }
  parseCmp():EvalFn{ let f=this.parseAdd(); while(['==','!=','<','>','<=','>='].includes(this.peek().t)){ const op=this.take().t; const g=this.parseAdd(); const prev=f; f=(inp,ctx)=>{ const a=prev(inp,ctx)[0], b=g(inp,ctx)[0]; if(op==='==') return [deepEq(a,b)]; if(op==='!=') return [!deepEq(a,b)]; const c=cmp(a,b); return [op==='<'?c<0:op==='>'?c>0:op==='<='?c<=0:c>=0]; }; } return f; }
  parseAdd():EvalFn{ let f=this.parseMul(); while(['+','-'].includes(this.peek().t)){ const op=this.take().t; const g=this.parseMul(); const prev=f; f=(inp,ctx)=>{ const a=prev(inp,ctx)[0], b=g(inp,ctx)[0]; return [op==='+'?jqAdd(a,b):jqSub(a,b)]; }; } return f; }
  parseMul():EvalFn{ let f=this.parsePost(); while(['*','/','%'].includes(this.peek().t)){ const op=this.take().t; const g=this.parsePost(); const prev=f; f=(inp,ctx)=>{ const a=prev(inp,ctx)[0], b=g(inp,ctx)[0]; if(op==='*') return [typeof a==='string'&&typeof b==='number'?a.repeat(b):a*b]; if(op==='/') return [typeof a==='string'&&typeof b==='string'?a.split(b):a/b]; return [a%b]; }; } return f; }
  parsePost():EvalFn{ let f=this.parsePrimary(); for(;;){
      if(this.eat('.')){ if(this.peek().t==='id' && !reserved.has(this.peek().v)){ const k=this.take().v; const opt=this.eat('?'); const prev=f; f=(inp,ctx)=>prev(inp,ctx).flatMap(v=>getField(v,k,opt)); }
        else { const prev=f; f=(inp,ctx)=>prev(inp,ctx); } continue; }
      if(this.eat('[')){ if(this.eat(']')){ const prev=f; const opt=this.eat('?'); f=(inp,ctx)=>prev(inp,ctx).flatMap(v=>iter(v,opt)); }
        else { let a:EvalFn|undefined=this.peek().t===':'?undefined:this.parseComma(); if(this.eat(':')){ let b:EvalFn|undefined=this.peek().t===']'?undefined:this.parseComma(); this.need(']'); const prev=f; f=(inp,ctx)=>prev(inp,ctx).flatMap(v=>sliceVal(v,a?a(inp,ctx)[0]:undefined,b?b(inp,ctx)[0]:undefined)); }
        else { this.need(']'); const opt=this.eat('?'); const prev=f; f=(inp,ctx)=>prev(inp,ctx).flatMap(v=>getField(v,a!(inp,ctx)[0],opt)); }} continue; }
      break;
    } return f; }
  parsePrimary():EvalFn{
    const tk=this.peek();
    if(this.eat('..')) return (inp)=>descend(inp);
    if(this.eat('.') ) {
      if(this.peek().t==='id' && !reserved.has(this.peek().v)){ const k=this.take().v; const opt=this.eat('?'); return (inp)=>getField(inp,k,opt); }
      return (inp)=>[inp];
    }
    if(tk.t==='num'){this.take(); const n=Number(tk.v); return ()=>[n];}
    if(tk.t==='str'){this.take(); return ()=>[tk.v];}
    if(tk.t==='var'){this.take(); return (_i,ctx)=>[tk.v==='ARGS'?ctx.args:ctx.vars[tk.v]];}
    if(tk.t==='id'){
      const id=this.take().v;
      if(id==='true'||id==='false'||id==='null') return ()=>[id==='true'?true:id==='false'?false:null];
      if(id==='if') return this.parseIf();
      let args:EvalFn[]=[]; if(this.eat('(')){ if(!this.eat(')')){ do { args.push(this.parseComma()); } while(this.eat(';')||this.eat(',')); this.need(')'); } }
      return (inp,ctx)=>callBuiltin(id,args,inp,ctx);
    }
    if(this.eat('(')){ const e=this.parseComma(); this.need(')'); return e; }
    if(this.eat('[')){ if(this.eat(']')) return ()=>[[]]; const inner=this.parseComma(); this.need(']'); return (inp,ctx)=>[inner(inp,ctx)]; }
    if(this.eat('{')) return this.parseObject();
    throw new Error(`unexpected ${tk.v}`);
  }
  parseIf():EvalFn{ const cond=this.parseComma(); const th=this.need('id'); if(th.v!=='then') throw new Error('expected then'); const yes=this.parseComma(); const el=this.need('id'); if(el.v!=='else') throw new Error('expected else'); const no=this.parseComma(); const en=this.need('id'); if(en.v!=='end') throw new Error('expected end'); return (inp,ctx)=> (cond(inp,ctx).some(truthy)?yes:no)(inp,ctx); }
  parseObject():EvalFn{
    const entries:{key?:string,keyExpr?:EvalFn,val:EvalFn}[]=[];
    if(this.eat('}')) return ()=>[{}];
    do{
      let key:string|undefined, keyExpr:EvalFn|undefined;
      if(this.peek().t==='id'){ key=this.take().v; }
      else if(this.peek().t==='str'){ key=this.take().v; }
      else if(this.peek().t==='var'){ key=this.take().v; }
      else if(this.eat('(')){ keyExpr=this.parseComma(); this.need(')'); }
      else throw new Error('bad object key');
      let val:EvalFn;
      if(this.eat(':')) val=this.parsePipe(); else if(key!==undefined && this.toks[this.p-1]?.t==='var') val=((name:string)=>(_i:J,ctx:Ctx)=>[ctx.vars[name]])(key); else val=new Parser('.'+key).parse();
      entries.push({key,keyExpr,val});
    } while(this.eat(','));
    this.need('}');
    return (inp,ctx)=>{ const o:any={}; for(const e of entries){ const ks=e.keyExpr?e.keyExpr(inp,ctx):[e.key]; const vs=e.val(inp,ctx); for(const k of ks) o[String(k)] = vs.length===1?vs[0]:vs; } return [o]; };
  }
}

function getField(v:J,k:J,opt=false):J[]{ if(v==null) return opt?[]:[null]; if(typeof k==='number'){ if(Array.isArray(v)||typeof v==='string'){ let i=k<0?v.length+k:k; return [v[i]===undefined?null:v[i]];} return opt?[]:[null]; } if(typeof v==='object'&&!Array.isArray(v)) return [v[k]===undefined?null:v[k]]; return opt?[]:[null]; }
function iter(v:J,opt=false):J[]{ if(v==null) return opt?[]:[]; if(Array.isArray(v)) return v; if(typeof v==='object') return Object.values(v); return opt?[]:[]; }
function sliceVal(v:J,a:any,b:any):J[]{ if(Array.isArray(v)||typeof v==='string'){ const n=v.length; let s=a==null?0:Number(a); let e=b==null?n:Number(b); if(s<0)s=n+s; if(e<0)e=n+e; return [(v as any).slice(s,e)]; } return [null]; }

function callBuiltin(name:string,args:EvalFn[],inp:J,ctx:Ctx):J[]{
  const arg=(i:number)=>args[i]?args[i](inp,ctx)[0]:undefined;
  switch(name){
    case 'empty': return [];
    case 'length': return [len(inp)];
    case 'type': return [typeOf(inp)];
    case 'keys': return [Array.isArray(inp)?inp.map((_,i)=>i):Object.keys(inp||{}).sort()];
    case 'keys_unsorted': return [Array.isArray(inp)?inp.map((_,i)=>i):Object.keys(inp||{})];
    case 'has': { const k=arg(0); return [Array.isArray(inp)?Number.isInteger(k)&&k>=0&&k<inp.length:inp!=null&&Object.prototype.hasOwnProperty.call(inp,k)]; }
    case 'map': return [Array.isArray(inp)?inp.flatMap(x=>args[0](x,ctx)):[]];
    case 'map_values': { if(Array.isArray(inp)) return [inp.map(x=>args[0](x,ctx)[0])]; const o:any={}; for(const [k,v] of Object.entries(inp||{})) o[k]=args[0](v,ctx)[0]; return [o]; }
    case 'select': return args[0](inp,ctx).some(truthy)?[inp]:[];
    case 'arrays': return Array.isArray(inp)?[inp]:[];
    case 'objects': return typeOf(inp)==='object'?[inp]:[];
    case 'iterables': return (Array.isArray(inp)||typeOf(inp)==='object')?[inp]:[];
    case 'booleans': return typeof inp==='boolean'?[inp]:[];
    case 'numbers': return typeof inp==='number'?[inp]:[];
    case 'strings': return typeof inp==='string'?[inp]:[];
    case 'nulls': return inp===null?[inp]:[];
    case 'values': return inp!==null?[inp]:[];
    case 'scalars': return (!Array.isArray(inp)&&typeOf(inp)!=='object')?[inp]:[];
    case 'add': return [Array.isArray(inp)?inp.reduce((a,b)=>jqAdd(a,b),null):inp];
    case 'not': return [!truthy(inp)];
    case 'tostring': return [typeof inp==='string'?inp:JSON.stringify(inp)];
    case 'tonumber': return [typeof inp==='number'?inp:Number(inp)];
    case 'toboolean': return [typeof inp==='boolean'?inp:inp==='true'?true:inp==='false'?false:null];
    case 'sort': return [Array.isArray(inp)?[...inp].sort(cmp):inp];
    case 'sort_by': return [Array.isArray(inp)?[...inp].sort((a,b)=>cmp(args[0](a,ctx)[0],args[0](b,ctx)[0])):inp];
    case 'reverse': return [Array.isArray(inp)?[...inp].reverse():typeof inp==='string'?[...inp].reverse().join(''):inp];
    case 'min': return [Array.isArray(inp)?[...inp].sort(cmp)[0]:inp];
    case 'max': return [Array.isArray(inp)?[...inp].sort(cmp).slice(-1)[0]:inp];
    case 'min_by': return [Array.isArray(inp)?[...inp].sort((a,b)=>cmp(args[0](a,ctx)[0],args[0](b,ctx)[0]))[0]:inp];
    case 'max_by': return [Array.isArray(inp)?[...inp].sort((a,b)=>cmp(args[0](a,ctx)[0],args[0](b,ctx)[0])).slice(-1)[0]:inp];
    case 'unique': return [Array.isArray(inp)?unique(inp):inp];
    case 'unique_by': { const seen:string[]=[]; const out:J[]=[]; for(const x of (Array.isArray(inp)?inp:[])){ const k=JSON.stringify(args[0](x,ctx)[0]); if(!seen.includes(k)){seen.push(k); out.push(x);} } return [out]; }
    case 'group_by': { const arr=Array.isArray(inp)?[...inp]:[]; arr.sort((a,b)=>cmp(args[0](a,ctx)[0],args[0](b,ctx)[0])); const groups:J[][]=[]; for(const x of arr){ const k=JSON.stringify(args[0](x,ctx)[0]); const last=groups[groups.length-1]; if(last&&JSON.stringify(args[0](last[0],ctx)[0])===k) last.push(x); else groups.push([x]); } return [groups]; }
    case 'flatten': return [flatten(inp,args[0]?Number(arg(0)):Infinity)];
    case 'range': { let from=0, to=0, by=1; if(args.length===1){to=Number(arg(0));} else {from=Number(arg(0)); to=Number(arg(1)); by=args[2]?Number(arg(2)):1;} const r=[]; if(by>0){for(let i=from;i<to;i+=by)r.push(i)} else {for(let i=from;i>to;i+=by)r.push(i)} return r; }
    case 'contains': return [contains(inp,arg(0))];
    case 'inside': return [contains(arg(0),inp)];
    case 'startswith': return [String(inp).startsWith(String(arg(0)))];
    case 'endswith': return [String(inp).endsWith(String(arg(0)))];
    case 'split': return [String(inp).split(String(arg(0)))];
    case 'join': return [Array.isArray(inp)?inp.map(x=>x==null?'':String(x)).join(String(arg(0))):''];
    case 'indices': return [indices(inp,arg(0))];
    case 'index': { const r=indices(inp,arg(0)); return [r.length?r[0]:null]; }
    case 'rindex': { const r=indices(inp,arg(0)); return [r.length?r[r.length-1]:null]; }
    case 'ltrimstr': { const s=String(inp), p=String(arg(0)); return [s.startsWith(p)?s.slice(p.length):s]; }
    case 'rtrimstr': { const s=String(inp), p=String(arg(0)); return [s.endsWith(p)?s.slice(0,-p.length):s]; }
    case 'trimstr': { const s=String(inp), p=String(arg(0)); return [s.startsWith(p)&&s.endsWith(p)?s.slice(p.length,-p.length):s]; }
    case 'trim': return [String(inp).trim()];
    case 'ltrim': return [String(inp).trimStart()];
    case 'rtrim': return [String(inp).trimEnd()];
    case 'to_entries': return [Array.isArray(inp)?inp.map((v,i)=>({key:i,value:v})):Object.keys(inp||{}).map(k=>({key:k,value:inp[k]}))];
    case 'from_entries': { const o:any={}; for(const e of (Array.isArray(inp)?inp:[])) o[e.key??e.Key??e.name??e.Name]=e.value??e.Value; return [o]; }
    case 'with_entries': { const es=callBuiltin('to_entries',[],inp,ctx)[0].flatMap((e:J)=>args[0](e,ctx)); return callBuiltin('from_entries',[],es,ctx); }
    case 'first': return Array.isArray(inp)?[inp[0]??null]:[inp];
    case 'last': return Array.isArray(inp)?[inp[inp.length-1]??null]:[inp];
    case 'any': return [Array.isArray(inp)?inp.some(truthy):truthy(inp)];
    case 'all': return [Array.isArray(inp)?inp.every(truthy):truthy(inp)];
    case 'explode': return [[...String(inp)].map(ch=>ch.codePointAt(0))];
    case 'implode': return [Array.isArray(inp)?String.fromCodePoint(...inp):''];
    case 'ascii_downcase': return [String(inp).toLowerCase()];
    case 'ascii_upcase': return [String(inp).toUpperCase()];
    case 'abs': return [Math.abs(Number(inp))];
    case 'floor': return [Math.floor(Number(inp))];
    case 'sqrt': return [Math.sqrt(Number(inp))];
    case 'env': return [process.env];
    default: throw new Error(`${name}/0 is not defined`);
  }
}
function flatten(v:J,d:number):J{ if(d<=0||!Array.isArray(v)) return v; return v.flatMap(x=>Array.isArray(x)?flatten(x,d-1):x); }
function descend(v:J):J[]{ const out=[v]; if(Array.isArray(v)) for(const x of v) out.push(...descend(x)); else if(v&&typeof v==='object') for(const x of Object.values(v)) out.push(...descend(x)); return out; }
function unique(a:J[]):J[]{ const seen:string[]=[]; const out:J[]=[]; for(const x of a){ const k=JSON.stringify(x); if(!seen.includes(k)){seen.push(k); out.push(x);} } return out; }
function indices(inp:J, needle:J):number[]{ const out:number[]=[]; if(typeof inp==='string'){ const n=String(needle); let i=inp.indexOf(n); while(i>=0){ out.push(i); i=inp.indexOf(n,i+Math.max(1,n.length)); } } else if(Array.isArray(inp)){ for(let i=0;i<inp.length;i++) if(deepEq(inp[i],needle)) out.push(i); } return out; }
function contains(a:J,b:J):boolean{ if(typeof a==='string'&&typeof b==='string') return a.includes(b); if(Array.isArray(a)) return Array.isArray(b)?b.every(x=>a.some(y=>contains(y,x)||deepEq(y,x))):a.some(x=>deepEq(x,b)); if(typeOf(a)==='object'&&typeOf(b)==='object') return Object.keys(b).every(k=>contains(a[k],b[k])||deepEq(a[k],b[k])); return deepEq(a,b); }

function parseJsonStream(s:string):J[]{ const vals:J[]=[]; let i=0; while(i<s.length){ while(/\s/.test(s[i]||'')) i++; if(i>=s.length) break; for(let j=i+1;j<=s.length;j++){ try{ const sub=s.slice(i,j); const v=JSON.parse(sub); if(j===s.length || /\s/.test(s[j]||'')){ vals.push(v); i=j; break; } } catch{} if(j===s.length) throw new Error('parse error'); } } return vals; }
function readInputs(files:string[], raw:boolean, slurp:boolean, nullInput:boolean):J[]{ if(nullInput) return [null]; const text=files.length?files.map(f=>fs.readFileSync(f,'utf8')).join(''):fs.readFileSync(0,'utf8'); if(raw) return slurp?[text]:text.split(/\n/).filter((x,i,a)=>i<a.length-1||x.length>0); const vals=parseJsonStream(text); return slurp?[vals]:vals; }
function stable(v:J, sort:boolean):J{ if(Array.isArray(v)) return v.map(x=>stable(x,sort)); if(v&&typeof v==='object'){ const o:any={}; for(const k of (sort?Object.keys(v).sort():Object.keys(v))) o[k]=stable(v[k],sort); return o;} return v; }
function format(v:J,opt:any):string{ if(opt.raw && typeof v==='string') return v; const sp=opt.compact?0:(opt.tab?'\t':opt.indent); return JSON.stringify(stable(v,opt.sort), null, sp); }

function help(){ console.log(`jq - commandline JSON processor [version build-2b77eb1]\n\nUsage:\tjq [options] <jq filter> [file...]\n\tjq [options] --args <jq filter> [strings...]\n\tjq [options] --jsonargs <jq filter> [JSON_TEXTS...]`); }
function main(){
  const argv=process.argv.slice(2); const opt:any={rawIn:false,slurp:false,nullIn:false,compact:false,raw:false,join:false,sort:false,tab:false,indent:2,exitStatus:false}; const vars:Record<string,J>={}; const named:Record<string,J>={}; let filter:string|undefined; const files:string[]=[]; const positional:J[]=[];
  for(let i=0;i<argv.length;i++){ let a=argv[i];
    if(/^-[A-Za-z]{2,}$/.test(a) && !['--args'].includes(a)) { const rest=a.slice(1).split('').map(ch=>'-'+ch); argv.splice(i,1,...rest); a=argv[i]; }
    if(a==='--'){ files.push(...argv.slice(i+1)); break; }
    if(a==='-h'||a==='--help'){help(); return;} if(a==='-V'||a==='--version'){console.log('jq-build-2b77eb1'); return;} if(a==='--build-configuration'){console.log('--disable-docs --with-oniguruma=builtin --enable-static --enable-all-static --prefix=/usr/local'); return;}
    if(a==='-n'||a==='--null-input') opt.nullIn=true; else if(a==='-R'||a==='--raw-input') opt.rawIn=true; else if(a==='-s'||a==='--slurp') opt.slurp=true; else if(a==='-c'||a==='--compact-output') opt.compact=true; else if(a==='-r'||a==='--raw-output') opt.raw=true; else if(a==='-j'||a==='--join-output'){opt.raw=true; opt.join=true;} else if(a==='-S'||a==='--sort-keys') opt.sort=true; else if(a==='--tab') opt.tab=true; else if(a==='--indent') opt.indent=Math.max(0,Math.min(7,Number(argv[++i]))); else if(a==='-e'||a==='--exit-status') opt.exitStatus=true; else if(a==='-f'||a==='--from-file') filter=fs.readFileSync(argv[++i],'utf8'); else if(a==='--arg'){ const n=argv[++i], v=argv[++i]; vars[n]=v; named[n]=v; } else if(a==='--argjson'){ const n=argv[++i], v=JSON.parse(argv[++i]); vars[n]=v; named[n]=v; } else if(a==='--rawfile'){ const n=argv[++i], f=argv[++i], v=fs.readFileSync(f,'utf8'); vars[n]=v; named[n]=v; } else if(a==='--slurpfile'){ const n=argv[++i], f=argv[++i], v=parseJsonStream(fs.readFileSync(f,'utf8')); vars[n]=v; named[n]=v; } else if(a==='--args'){ if(filter===undefined) filter=argv[++i]; positional.push(...argv.slice(i+1)); break; } else if(a==='--jsonargs'){ if(filter===undefined) filter=argv[++i]; positional.push(...argv.slice(i+1).map(JSON.parse)); break; } else if(a.startsWith('-')&&filter===undefined){ /* ignore unsupported output flags */ } else if(filter===undefined) filter=a; else files.push(a);
  }
  if(filter===undefined){ help(); process.exit(2); }
  const argsObj={positional, named}; const ctx:Ctx={vars:{...vars, ARGS:argsObj}, args:argsObj}; const fn=new Parser(filter).parse(); const inputs=readInputs(files,opt.rawIn,opt.slurp,opt.nullIn); let last:any=undefined, produced=false;
  for(const inp of inputs){ for(const out of fn(inp,ctx)){ produced=true; last=out; process.stdout.write(format(out,opt)); if(!opt.join) process.stdout.write('\n'); }}
  if(opt.exitStatus) process.exit(!produced?4:truthy(last)?0:1);
}
try{ main(); } catch(e:any){ console.error('jq: error: '+(e?.message||e)); process.exit(3); }
