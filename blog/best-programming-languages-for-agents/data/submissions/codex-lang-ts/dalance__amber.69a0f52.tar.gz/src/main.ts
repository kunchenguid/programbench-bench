declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

type Opts = {
  keyFromFile: boolean;
  repFromFile: boolean;
  verbose: boolean;
  regex: boolean;
  column: boolean;
  row: boolean;
  binary: boolean;
  statistics: boolean;
  skipped: boolean;
  preserveTime: boolean;
  interactive: boolean;
  recursive: boolean;
  symlink: boolean;
  color: boolean;
  file: boolean;
  skipVcs: boolean;
  skipGitignore: boolean;
  fixedOrder: boolean;
  parentIgnore: boolean;
  tbm: boolean;
  sse: boolean;
  maxThreads: string;
  sizePerThread: string;
  binCheckBytes: number;
  mmapBytes: string;
};

const VERSION = "ambr 0.6.0";

function defaultOpts(): Opts {
  return {
    keyFromFile: false,
    repFromFile: false,
    verbose: false,
    regex: false,
    column: false,
    row: false,
    binary: false,
    statistics: false,
    skipped: false,
    preserveTime: false,
    interactive: true,
    recursive: true,
    symlink: true,
    color: true,
    file: true,
    skipVcs: true,
    skipGitignore: true,
    fixedOrder: true,
    parentIgnore: true,
    tbm: false,
    sse: false,
    maxThreads: "4",
    sizePerThread: "1048576",
    binCheckBytes: 256,
    mmapBytes: "1048576"
  };
}

function help(): string {
  return `${VERSION}

USAGE:
    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...

FLAGS:
        --key-from-file        Use file contents of KEYWORD as keyword for search
        --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement
        --verbose              Verbose message
    -r, --regex                Enable regular expression search
        --column               Enable column output
        --row                  Enable row output
        --binary               Enable binary file search
        --statistics           Enable statistics output
        --skipped              Enable skipped file output
        --preserve-time        Enable timestamp preserve
        --no-interactive       Disable interactive replace
        --no-recursive         Disable recursive directory search
        --no-symlink           Disable symbolic link follow
        --no-color             Disable colored output
        --no-file              Disable filename output
        --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip
        --no-skip-gitignore    Disable .gitignore skip
        --no-fixed-order       Disable output order guarantee
        --no-parent-ignore     Disable .*ignore file search at parent directories
        --tbm                  [Experimental] Enable TBM matcher
        --sse                  [Experimental] Enable SSE 4.2
    -h, --help                 Prints help information
    -V, --version              Prints version information

OPTIONS:
        --max-threads <NUM>          Number of max threads [default: 4]
        --size-per-thread <BYTES>    File size per one thread [default: 1048576]
        --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]
        --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]

ARGS:
    <KEYWORD>        Keyword for search
    <REPLACEMENT>    Keyword for replace
    <PATHS>...       Search paths
`;
}

function usageShort(): string {
  return "USAGE:\n    executable <KEYWORD> <REPLACEMENT> --bin-check-bytes <BYTES> --max-threads <NUM> --mmap-bytes <BYTES> --size-per-thread <BYTES>";
}

function die(msg: string, code = 1): void {
  process.stderr.write(msg + "\n");
  process.exit(code);
}

function parse(argv: string[]): { opts: Opts; positional: string[] } {
  const opts = defaultOpts();
  const positional: string[] = [];
  const needValue: Record<string, keyof Opts> = {
    "--max-threads": "maxThreads",
    "--size-per-thread": "sizePerThread",
    "--bin-check-bytes": "binCheckBytes",
    "--mmap-bytes": "mmapBytes"
  };
  const flags: Record<string, (o: Opts) => void> = {
    "--key-from-file": o => o.keyFromFile = true,
    "--rep-from-file": o => o.repFromFile = true,
    "--verbose": o => o.verbose = true,
    "-r": o => o.regex = true,
    "--regex": o => o.regex = true,
    "--column": o => o.column = true,
    "--row": o => o.row = true,
    "--binary": o => o.binary = true,
    "--statistics": o => o.statistics = true,
    "--skipped": o => o.skipped = true,
    "--preserve-time": o => o.preserveTime = true,
    "--no-interactive": o => o.interactive = false,
    "--no-recursive": o => o.recursive = false,
    "--no-symlink": o => o.symlink = false,
    "--no-color": o => o.color = false,
    "--no-file": o => o.file = false,
    "--no-skip-vcs": o => o.skipVcs = false,
    "--no-skip-gitignore": o => o.skipGitignore = false,
    "--no-fixed-order": o => o.fixedOrder = false,
    "--no-parent-ignore": o => o.parentIgnore = false,
    "--tbm": o => o.tbm = true,
    "--sse": o => o.sse = true
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") {
      process.stdout.write(help());
      process.exit(0);
    }
    if (a === "-V" || a === "--version") {
      process.stdout.write(VERSION + "\n");
      process.exit(0);
    }
    if (a === "--") {
      positional.push(...argv.slice(i + 1));
      break;
    }
    if (a in needValue) {
      const v = argv[++i];
      if (v === undefined) die(`error: The argument '${a} <${a === "--max-threads" ? "NUM" : "BYTES"}>' requires a value\n\n${usageShort()}\n\nFor more information try --help`);
      (opts as any)[needValue[a]] = needValue[a] === "binCheckBytes" ? parseInt(v, 10) || 0 : v;
    } else if (a.startsWith("--") && a.includes("=") && a.split("=")[0] in needValue) {
      const [k, ...rest] = a.split("=");
      const v = rest.join("=");
      (opts as any)[needValue[k]] = needValue[k] === "binCheckBytes" ? parseInt(v, 10) || 0 : v;
    } else if (a in flags) {
      flags[a](opts);
    } else if (a.startsWith("-") && a !== "-") {
      die(`error: Found argument '${a}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...\n\nFor more information try --help`);
    } else {
      positional.push(a);
    }
  }
  return { opts, positional };
}

function readTextFile(p: string): string {
  return fs.readFileSync(p, "utf8");
}

function isBinary(buf: any, n: number): boolean {
  const len = Math.min(buf.length, n);
  for (let i = 0; i < len; i++) {
    if (buf[i] === 0) return true;
  }
  return false;
}

const vcsNames = new Set([".git", ".hg", ".svn", ".bzr"]);

function loadIgnoreFile(dir: string): string[] {
  const names = [".gitignore", ".ignore", ".amberignore"];
  const pats: string[] = [];
  for (const name of names) {
    const p = path.join(dir, name);
    try {
      const s = fs.readFileSync(p, "utf8");
      for (const raw of s.split(/\r?\n/)) {
        const line = raw.trim();
        if (!line || line.startsWith("#") || line.startsWith("!")) continue;
        pats.push(line);
      }
    } catch {}
  }
  return pats;
}

function ignored(name: string, rel: string, pats: string[]): boolean {
  for (const pat of pats) {
    const p = pat.replace(/^\//, "").replace(/\/$/, "");
    if (!p) continue;
    if (p.includes("/")) {
      if (rel === p || rel.startsWith(p + "/")) return true;
    } else {
      if (name === p || rel.split(path.sep).includes(p)) return true;
      if (p.startsWith("*") && name.endsWith(p.slice(1))) return true;
      if (p.endsWith("*") && name.startsWith(p.slice(0, -1))) return true;
    }
  }
  return false;
}

function collectFiles(inputs: string[], opts: Opts): { files: string[]; skipped: string[] } {
  const files: string[] = [];
  const skipped: string[] = [];
  const roots = inputs.length ? inputs : ["."];
  function walk(p: string, base: string, inherited: string[]) {
    let st;
    try {
      st = opts.symlink ? fs.statSync(p) : fs.lstatSync(p);
    } catch {
      skipped.push(p);
      return;
    }
    const name = path.basename(p);
    const rel = path.relative(base, p) || name;
    if (opts.skipVcs && vcsNames.has(name)) {
      skipped.push(p);
      return;
    }
    if (opts.skipGitignore && ignored(name, rel, inherited)) {
      skipped.push(p);
      return;
    }
    if (st.isDirectory()) {
      if (!opts.recursive && p !== base) return;
      let pats = inherited;
      if (opts.skipGitignore) pats = inherited.concat(loadIgnoreFile(p));
      let ents: string[] = [];
      try { ents = fs.readdirSync(p); } catch { skipped.push(p); return; }
      ents.sort();
      for (const e of ents) walk(path.join(p, e), base, pats);
    } else if (st.isFile()) {
      files.push(p);
    }
  }
  for (const r of roots) walk(r, r, opts.parentIgnore && opts.skipGitignore ? parentIgnores(path.resolve(r)) : []);
  return { files, skipped };
}

function parentIgnores(start: string): string[] {
  let dir = fs.existsSync(start) && fs.statSync(start).isDirectory() ? start : path.dirname(start);
  const dirs: string[] = [];
  while (true) {
    dirs.push(dir);
    const next = path.dirname(dir);
    if (next === dir) break;
    dir = next;
  }
  dirs.reverse();
  let pats: string[] = [];
  for (const d of dirs) pats = pats.concat(loadIgnoreFile(d));
  return pats;
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function convertReplacement(rep: string): string {
  let out = rep.replace(/\$\{(\d+)\}/g, (_: string, n: string) => "$" + n);
  out = out.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g, (_: string, n: string) => "$<" + n + ">");
  out = out.replace(/\$([A-Za-z_][A-Za-z0-9_]*)/g, (_: string, n: string) => "$<" + n + ">");
  return out;
}

function askOnce(): string {
  process.stderr.write("Replace keyword? ( Yes[Y], No[N], All[A], Quit[Q] ):\n");
  try {
    const buf = fs.readFileSync(0, "utf8");
    return (buf.split(/\r?\n/)[0] || "").trim().toLowerCase();
  } catch {
    return "n";
  }
}

function main() {
  const { opts, positional } = parse(process.argv.slice(2));
  if (positional.length < 2) {
    die("error: The following required arguments were not provided:\n    <KEYWORD>\n    <REPLACEMENT>\n\n" + usageShort() + "\n\nFor more information try --help");
  }
  let keyword = positional[0];
  let replacement = positional[1];
  const paths = positional.slice(2);
  try {
    if (opts.keyFromFile) keyword = readTextFile(keyword);
    if (opts.repFromFile) replacement = readTextFile(replacement);
  } catch (e: any) {
    die(`error: ${e.message}`);
  }
  let re: RegExp;
  try {
    re = new RegExp(opts.regex ? keyword : escapeRegExp(keyword), "g");
  } catch (e: any) {
    die(`error: ${e.message}`);
  }
  const rep = opts.regex ? convertReplacement(replacement) : replacement.replace(/\$/g, "$$$$");
  const { files, skipped } = collectFiles(paths, opts);
  let changedFiles = 0;
  let matches = 0;
  let all = !opts.interactive;
  for (const f of files) {
    let buf;
    try { buf = fs.readFileSync(f); } catch { skipped.push(f); continue; }
    if (!opts.binary && isBinary(buf, opts.binCheckBytes)) { skipped.push(f); continue; }
    const old = buf.toString("utf8");
    re.lastIndex = 0;
    const found = old.match(re);
    if (!found || found.length === 0) continue;
    if (!all && opts.interactive) {
      const ans = askOnce();
      if (ans === "q" || ans === "quit") break;
      if (ans === "a" || ans === "all") all = true;
      else if (!(ans === "y" || ans === "yes")) continue;
    }
    let stat: any = null;
    if (opts.preserveTime) {
      try { stat = fs.statSync(f); } catch {}
    }
    const next = old.replace(re, rep);
    if (next !== old) {
      fs.writeFileSync(f, next);
      if (stat) {
        try { fs.utimesSync(f, stat.atime, stat.mtime); } catch {}
      }
      changedFiles++;
      matches += found.length;
      if (opts.verbose && opts.file) process.stdout.write(`${f}\n`);
    }
  }
  if (opts.skipped) {
    for (const s of skipped) process.stdout.write(`Skip: ${s}\n`);
  }
  if (opts.statistics) {
    process.stdout.write(`${changedFiles} files changed\n${matches} matches replaced\n`);
  }
  process.exit(changedFiles > 0 ? 0 : 1);
}

main();
