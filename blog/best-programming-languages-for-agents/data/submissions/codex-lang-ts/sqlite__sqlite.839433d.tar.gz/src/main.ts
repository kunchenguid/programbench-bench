declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

type Value = string | number | null;
type Table = { name: string; columns: string[]; createSql: string; rows: Value[][] };
type Database = { tables: Record<string, Table> };
type Result = { columns: string[]; rows: Value[][] };

const VERSION = "3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)";

const HELP = `Usage: ./executable [OPTIONS] [FILENAME [SQL...]]
FILENAME is the name of an SQLite database. A new database is created
if the file does not previously exist. Defaults to :memory:.
OPTIONS include:
   --                   treat no subsequent arguments as options
   -A ARGS...           run ".archive ARGS" and exit
   -append              append the database to the end of the file
   -ascii               set output mode to 'ascii'
   -bail                stop after hitting an error
   -batch               force batch I/O
   -box                 set output mode to 'box'
   -cmd COMMAND         run "COMMAND" before reading stdin
   -column              set output mode to 'column'
   -csv                 set output mode to 'csv'
   -deserialize         open the database using sqlite3_deserialize()
   -echo                print inputs before execution
   -escape T            ctrl-char escape; T is one of: symbol, ascii, off
   -init FILENAME       read/process named file
   -[no]header          turn headers on or off
   -help                show this message
   -html                set output mode to HTML
   -ifexists            only open if database already exists
   -interactive         force interactive I/O
   -json                set output mode to 'json'
   -line                set output mode to 'line'
   -list                set output mode to 'list'
   -lookaside SIZE N    use N entries of SZ bytes for lookaside memory
   -markdown            set output mode to 'markdown'
   -maxsize N           maximum size for a --deserialize database
   -memtrace            trace all memory allocations and deallocations
   -mmap N              default mmap size set to N
   -newline SEP         set output row separator. Default: '\\n'
   -nofollow            refuse to open symbolic links to database files
   -noinit              Do not read the ~/.sqliterc file at startup
   -nonce STRING        set the safe-mode escape nonce
   -no-rowid-in-view    Disable rowid-in-view using sqlite3_config()
   -nullvalue TEXT      set text string for NULL values. Default ''
   -pagecache SIZE N    use N slots of SZ bytes each for page cache memory
   -pcachetrace         trace all page cache operations
   -quote               set output mode to 'quote'
   -readonly            open the database read-only
   -safe                enable safe-mode
   -screenwidth N       use N as the default screenwidth 
   -separator SEP       set output column separator. Default: '|'
   -stats               print memory stats before each finalize
   -table               set output mode to 'table'
   -tabs                set output mode to 'tabs'
   -unsafe-testing      allow unsafe commands and modes for testing
   -version             show SQLite version
   -vfs NAME            use NAME as the default VFS
   -vfstrace            enable tracing of all VFS calls
   -zip                 open the file as a ZIP Archive`;

const DOT_HELP = `.archive ...             Manage SQL archives
.auth ON|OFF             Show authorizer callbacks
.backup ?DB? FILE        Backup DB (default "main") to FILE
.bail on|off             Stop after hitting an error.  Default OFF
.cd DIRECTORY            Change the working directory to DIRECTORY
.changes on|off          Show number of rows changed by SQL
.check OPTIONS ...       Verify the results of a .testcase
.clone NEWDB             Clone data into NEWDB from the existing database
.connection [close] [#]  Open or close an auxiliary database connection
.databases               List names and files of attached databases
.dump ?OBJECTS?          Render database content as SQL
.echo on|off             Turn command echo on or off
.exit ?CODE?             Exit this program with return-code CODE
.headers on|off          Turn display of headers on or off
.help ?-all? ?PATTERN?   Show help text for PATTERN
.indexes ?PATTERN?       Show names of indexes matching PATTERN
.mode ?MODE? ?OPTIONS?   Set output mode
.nullvalue STRING        Use STRING in place of NULL values
.open ?OPTIONS? ?FILE?   Close existing database and reopen FILE
.output ?FILE?           Send output to FILE or stdout if FILE is omitted
.print STRING...         Print literal STRING
.quit                    Stop interpreting input stream, exit if primary.
.read FILE               Read input from FILE or command output
.schema ?PATTERN?        Show the CREATE statements matching PATTERN
.separator COL ?ROW?     Change the column and row separators
.tables ?TABLE?          List names of tables matching LIKE pattern TABLE
.version                 Show source, library and compiler versions`;

class Shell {
  dbFile = ":memory:";
  db: Database = { tables: {} };
  mode = "list";
  headers = false;
  separator = "|";
  rowSep = "\n";
  nullValue = "";
  bail = false;
  echo = false;
  outputFile: string | null = null;
  exitCode = 0;
  shouldExit = false;

  constructor(file: string) {
    this.open(file);
  }

  open(file: string) {
    this.dbFile = file || ":memory:";
    this.db = { tables: {} };
    if (this.dbFile !== ":memory:" && fs.existsSync(this.dbFile)) {
      try {
        const txt = fs.readFileSync(this.dbFile, "utf8");
        if (txt.startsWith("TSQLITE:")) this.db = JSON.parse(txt.slice(8));
      } catch {}
    }
  }

  save() {
    if (this.dbFile === ":memory:") return;
    fs.writeFileSync(this.dbFile, "TSQLITE:" + JSON.stringify(this.db));
  }

  out(s: string) {
    if (this.outputFile) fs.appendFileSync(this.outputFile, s);
    else process.stdout.write(s);
  }

  err(s: string) {
    process.stderr.write(s);
  }

  runScript(script: string, source = "stdin") {
    let buf = "";
    for (const raw of script.split(/\n/)) {
      const line = raw.replace(/\r$/, "");
      if (!buf.trim() && line.trim().startsWith(".")) {
        if (this.echo) this.out(line + "\n");
        this.dot(line.trim());
        if (this.shouldExit) return;
        continue;
      }
      buf += (buf ? "\n" : "") + line;
      const parts = splitStatements(buf);
      if (parts.complete.length) {
        for (const stmt of parts.complete) {
          if (this.echo) this.out(stmt + ";\n");
          this.runSql(stmt, source);
          if (this.shouldExit || (this.bail && this.exitCode)) return;
        }
      }
      buf = parts.rest;
    }
    if (buf.trim()) this.runSql(buf, source);
  }

  runSql(sql: string, source = "SQL") {
    const stmt = sql.trim().replace(/;+\s*$/, "");
    if (!stmt) return;
    try {
      const res = execute(this.db, stmt);
      this.save();
      if (res) this.render(res);
    } catch (e: any) {
      this.exitCode = 1;
      const msg = e && e.message ? e.message : String(e);
      this.err(`Parse error near ${source}: ${msg}\n`);
    }
  }

  dot(line: string) {
    const args = shellWords(line);
    const cmd = args[0].slice(1);
    const a = args.slice(1);
    switch (cmd) {
      case "help": this.out(DOT_HELP + "\n"); break;
      case "quit":
      case "exit": this.shouldExit = true; this.exitCode = a[0] ? Number(a[0]) || 0 : this.exitCode; break;
      case "mode": if (a[0]) this.setMode(a[0]); else this.out(`${this.mode}\n`); break;
      case "headers":
      case "header": this.headers = boolArg(a[0], this.headers); break;
      case "separator": if (a[0] !== undefined) this.separator = unescapeArg(a[0]); if (a[1] !== undefined) this.rowSep = unescapeArg(a[1]); break;
      case "nullvalue": this.nullValue = a.join(" "); break;
      case "print": this.out(a.join(" ") + "\n"); break;
      case "tables": this.out(Object.keys(this.db.tables).sort().join(" ") + (Object.keys(this.db.tables).length ? "\n" : "")); break;
      case "schema":
        for (const t of Object.values(this.db.tables).sort((x: any, y: any) => x.name.localeCompare(y.name)) as Table[]) this.out(t.createSql + ";\n");
        break;
      case "dump":
        this.out("PRAGMA foreign_keys=OFF;\nBEGIN TRANSACTION;\n");
        for (const t of Object.values(this.db.tables).sort((x: any, y: any) => x.name.localeCompare(y.name)) as Table[]) {
          this.out(t.createSql + ";\n");
          for (const r of t.rows) this.out(`INSERT INTO ${quoteIdent(t.name)} VALUES(${r.map(sqlLiteral).join(",")});\n`);
        }
        this.out("COMMIT;\n");
        break;
      case "databases":
        this.render({ columns: ["seq", "name", "file"], rows: [[0, "main", this.dbFile === ":memory:" ? "" : path.resolve(this.dbFile)]] });
        break;
      case "version":
        this.out(`SQLite ${VERSION}\n`);
        break;
      case "open":
        this.save();
        this.open(a[a.length - 1] || ":memory:");
        break;
      case "read":
        if (a[0]) this.runScript(fs.readFileSync(a[0], "utf8"), a[0]);
        break;
      case "output":
      case "once":
        this.outputFile = a[0] || null;
        if (this.outputFile) fs.writeFileSync(this.outputFile, "");
        break;
      case "bail": this.bail = boolArg(a[0], this.bail); break;
      case "echo": this.echo = boolArg(a[0], this.echo); break;
      case "cd": if (a[0]) process.chdir(a[0]); break;
      default:
        this.err(`Error: unknown command or invalid arguments:  "${line}"\n`);
        this.exitCode = 1;
    }
  }

  setMode(m: string) {
    m = m.toLowerCase();
    if (m === "tabs") { this.mode = "list"; this.separator = "\t"; return; }
    if (m === "ascii") { this.mode = "list"; this.separator = "\x1f"; this.rowSep = "\x1e"; return; }
    this.mode = m;
  }

  render(res: Result) {
    const rows = res.rows;
    const cols = res.columns;
    if (this.mode === "json") {
      const arr = rows.map(r => Object.fromEntries(cols.map((c, i) => [c, r[i]])));
      this.out(JSON.stringify(arr) + "\n");
      return;
    }
    if (this.mode === "line") {
      const w = Math.max(...cols.map(k => k.length));
      for (const r of rows) {
        cols.forEach((c, i) => this.out(`${c.padStart(w)}: ${fmt(r[i], this)}\n`));
        this.out("\n");
      }
      return;
    }
    if (this.mode === "csv") {
      if (this.headers) this.out(cols.map(csv).join(",") + "\r\n");
      for (const r of rows) this.out(r.map(csv).join(",") + "\r\n");
      return;
    }
    if (this.mode === "quote") {
      if (this.headers) this.out(cols.map(s => sqlLiteral(s)).join(",") + "\n");
      for (const r of rows) this.out(r.map(sqlLiteral).join(",") + "\n");
      return;
    }
    if (this.mode === "html") {
      if (this.headers) this.out("<TR>\n" + cols.map(c => `<TH>${escapeHtml(c)}\n`).join("") + "</TR>\n");
      for (const r of rows) this.out("<TR>\n" + r.map(v => `<TD>${v === null ? "null" : escapeHtml(String(v))}\n`).join("") + "</TR>\n");
      return;
    }
    if (["column", "table", "markdown", "box"].includes(this.mode)) return this.renderTable(res);
    if (this.headers) this.out(cols.join(this.separator) + this.rowSep);
    for (const r of rows) this.out(r.map(v => fmt(v, this)).join(this.separator) + this.rowSep);
  }

  renderTable(res: Result) {
    const data = (this.headers || this.mode !== "column") ? [res.columns, ...res.rows.map(r => r.map(v => fmt(v, this)))] : res.rows.map(r => r.map(v => fmt(v, this)));
    const widths = res.columns.map((c, i) => Math.max(c.length, ...data.map(r => String(r[i] ?? "").length)));
    const padrow = (r: any[]) => "| " + widths.map((w, i) => String(r[i] ?? "").padEnd(w)).join(" | ") + " |";
    if (this.mode === "markdown") {
      this.out(padrow(res.columns) + "\n");
      this.out("|" + widths.map(w => "-".repeat(w + 2)).join("|") + "|\n");
      for (const r of res.rows) this.out(padrow(r.map(v => fmt(v, this))) + "\n");
      return;
    }
    if (this.mode === "table" || this.mode === "box") {
      if (this.mode === "box") {
        const top = "╭" + widths.map(w => "─".repeat(w + 2)).join("┬") + "╮\n";
        const mid = "╞" + widths.map(w => "═".repeat(w + 2)).join("╪") + "╡\n";
        const bot = "╰" + widths.map(w => "─".repeat(w + 2)).join("┴") + "╯\n";
        this.out(top + "│ " + widths.map((w, i) => res.columns[i].padEnd(w)).join(" │ ") + " │\n" + mid);
        for (const r of res.rows) this.out("│ " + widths.map((w, i) => fmt(r[i], this).padEnd(w)).join(" │ ") + " │\n");
        this.out(bot);
      } else {
        const sep = "+" + widths.map(w => "-".repeat(w + 2)).join("+") + "+\n";
        this.out(sep + padrow(res.columns) + "\n" + sep);
        for (const r of res.rows) this.out(padrow(r.map(v => fmt(v, this))) + "\n");
        this.out(sep);
      }
      return;
    }
    const rows = this.headers ? [res.columns, widths.map(w => "-".repeat(w)), ...res.rows.map(r => r.map(v => fmt(v, this)))] : res.rows.map(r => r.map(v => fmt(v, this)));
    for (const r of rows) this.out(widths.map((w, i) => String(r[i] ?? "").padEnd(w)).join("  ").trimEnd() + "\n");
  }
}

function execute(db: Database, stmt: string): Result | null {
  let m: RegExpMatchArray | null;
  if (/^(begin|commit|rollback|vacuum|analyze)\b/i.test(stmt)) return null;
  if ((m = stmt.match(/^create\s+table\s+(?:if\s+not\s+exists\s+)?("?[\w$]+"?)\s*\(([\s\S]*)\)$/i))) {
    const name = cleanIdent(m[1]);
    const defs = splitComma(m[2]);
    const cols = defs.map(d => cleanIdent(d.trim().split(/\s+/)[0])).filter(c => c && !/^(primary|foreign|unique|check|constraint)$/i.test(c));
    db.tables[name] = { name, columns: cols, createSql: `CREATE TABLE ${name}(${defs.join(",")})`, rows: [] };
    return null;
  }
  if ((m = stmt.match(/^drop\s+table\s+(?:if\s+exists\s+)?("?[\w$]+"?)/i))) { delete db.tables[cleanIdent(m[1])]; return null; }
  if ((m = stmt.match(/^alter\s+table\s+("?[\w$]+"?)\s+add\s+(?:column\s+)?([\s\S]+)$/i))) {
    const t = table(db, cleanIdent(m[1])); const col = cleanIdent(m[2].trim().split(/\s+/)[0]);
    t.columns.push(col); t.rows.forEach(r => r.push(null)); t.createSql = t.createSql.replace(/\);?$/, `,${m![2]})`);
    return null;
  }
  if ((m = stmt.match(/^insert\s+(?:or\s+\w+\s+)?into\s+("?[\w$]+"?)\s*(?:\(([^)]*)\))?\s*values\s*([\s\S]+)$/i))) {
    const t = table(db, cleanIdent(m[1]));
    const cols = m[2] ? splitComma(m[2]).map(cleanIdent) : t.columns;
    for (const group of valueGroups(m[3])) {
      const vals = splitComma(group).map(v => evalExpr(v, {}));
      const row = Array(t.columns.length).fill(null);
      cols.forEach((c, i) => { const idx = colIndex(t, c); row[idx] = vals[i] ?? null; });
      t.rows.push(row);
    }
    return null;
  }
  if ((m = stmt.match(/^delete\s+from\s+("?[\w$]+"?)(?:\s+where\s+([\s\S]+))?$/i))) {
    const t = table(db, cleanIdent(m[1]));
    t.rows = t.rows.filter(r => m![2] && !where(m![2], rowObj(t, r)));
    return null;
  }
  if ((m = stmt.match(/^update\s+("?[\w$]+"?)\s+set\s+([\s\S]*?)(?:\s+where\s+([\s\S]+))?$/i))) {
    const t = table(db, cleanIdent(m[1]));
    const assigns = splitComma(m[2]).map(x => x.split(/=(.*)/s).filter(Boolean));
    for (const r of t.rows) if (!m[3] || where(m[3], rowObj(t, r))) for (const [c, e] of assigns) r[colIndex(t, cleanIdent(c.trim()))] = evalExpr(e, rowObj(t, r));
    return null;
  }
  if ((m = stmt.match(/^pragma\s+table_info\s*\(\s*([\w$"']+)\s*\)$/i))) {
    const t = table(db, cleanIdent(stripQuotes(m[1])));
    return { columns: ["cid", "name", "type", "notnull", "dflt_value", "pk"], rows: t.columns.map((c, i) => [i, c, "", 0, null, 0]) };
  }
  if (/^pragma\s+database_list/i.test(stmt)) return { columns: ["seq", "name", "file"], rows: [[0, "main", ""]] };
  if (/^select\b/i.test(stmt)) return select(db, stmt);
  throw new Error("near \"" + stmt.split(/\s+/)[0] + "\": syntax error");
}

function select(db: Database, stmt: string): Result {
  const sm = stmt.match(/^select\s+([\s\S]*?)(?:\s+from\s+("?[\w$]+"?)([\s\S]*))?$/i);
  if (!sm) throw new Error("near \"select\": syntax error");
  const list = splitComma(sm[1]);
  if (!sm[2]) {
    const vals = list.map(x => evalExpr(exprPart(x), {}));
    return { columns: list.map(aliasOf), rows: [vals] };
  }
  const t = table(db, cleanIdent(sm[2]));
  let tail = sm[3] || "";
  let whereExpr = ""; let orderCol = ""; let limit = -1;
  const lm = tail.match(/\s+limit\s+(\d+)\s*$/i); if (lm) { limit = Number(lm[1]); tail = tail.slice(0, lm.index); }
  const om = tail.match(/\s+order\s+by\s+([\w$"]+)(?:\s+(desc|asc))?/i); if (om) { orderCol = cleanIdent(om[1]) + (om[2]?.toLowerCase() === "desc" ? " desc" : ""); tail = tail.slice(0, om.index); }
  const wm = tail.match(/\s+where\s+([\s\S]+)/i); if (wm) whereExpr = wm[1];
  let rows = t.rows.map(r => rowObj(t, r));
  if (whereExpr) rows = rows.filter(r => where(whereExpr, r));
  if (orderCol) {
    const desc = orderCol.endsWith(" desc"); const oc = desc ? orderCol.slice(0, -5) : orderCol;
    rows.sort((a, b) => cmp(a[oc], b[oc]) * (desc ? -1 : 1));
  }
  if (limit >= 0) rows = rows.slice(0, limit);
  if (list.length === 1 && /^count\s*\(\s*\*\s*\)$/i.test(list[0])) return { columns: [aliasOf(list[0])], rows: [[rows.length]] };
  const cols = list.length === 1 && list[0].trim() === "*" ? t.columns : list.map(aliasOf);
  const out = rows.map(r => list.length === 1 && list[0].trim() === "*" ? t.columns.map(c => r[c]) : list.map(e => evalExpr(exprPart(e), r)));
  return { columns: cols, rows: out };
}

function splitStatements(s: string) {
  const complete: string[] = []; let start = 0, quote = "";
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quote) { if (ch === quote) { if (s[i + 1] === quote) i++; else quote = ""; } continue; }
    if (ch === "'" || ch === '"') quote = ch;
    else if (ch === ";") { complete.push(s.slice(start, i).trim()); start = i + 1; }
  }
  return { complete: complete.filter(Boolean), rest: s.slice(start) };
}
function splitComma(s: string) {
  const out: string[] = []; let start = 0, depth = 0, quote = "";
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quote) { if (ch === quote) { if (s[i + 1] === quote) i++; else quote = ""; } continue; }
    if (ch === "'" || ch === '"') quote = ch; else if (ch === "(") depth++; else if (ch === ")") depth--; else if (ch === "," && depth === 0) { out.push(s.slice(start, i).trim()); start = i + 1; }
  }
  out.push(s.slice(start).trim()); return out.filter(x => x.length);
}
function valueGroups(s: string) {
  const out: string[] = []; let depth = 0, start = -1, quote = "";
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quote) { if (ch === quote) { if (s[i + 1] === quote) i++; else quote = ""; } continue; }
    if (ch === "'" || ch === '"') quote = ch;
    else if (ch === "(") { if (depth++ === 0) start = i + 1; }
    else if (ch === ")" && --depth === 0) out.push(s.slice(start, i));
  }
  return out;
}
function evalExpr(expr: string, row: Record<string, Value>): Value {
  expr = exprPart(expr.trim());
  if (/^null$/i.test(expr)) return null;
  if (/^'.*'$/.test(expr)) return expr.slice(1, -1).replace(/''/g, "'");
  if (/^".*"$/.test(expr)) return stripQuotes(expr);
  if (/^-?\d+(?:\.\d+)?$/.test(expr)) return Number(expr);
  const fm = expr.match(/^(upper|lower|length)\s*\((.*)\)$/i);
  if (fm) { const v = evalExpr(fm[2], row); if (fm[1].toLowerCase() === "length") return v === null ? null : String(v).length; return v === null ? null : (fm[1].toLowerCase() === "upper" ? String(v).toUpperCase() : String(v).toLowerCase()); }
  const op = expr.match(/^(.+)\s*([+*/-])\s*(.+)$/);
  if (op) { const a = Number(evalExpr(op[1], row) ?? 0), b = Number(evalExpr(op[3], row) ?? 0); return op[2] === "+" ? a + b : op[2] === "-" ? a - b : op[2] === "*" ? a * b : a / b; }
  const id = cleanIdent(expr); if (Object.prototype.hasOwnProperty.call(row, id)) return row[id];
  throw new Error("no such column: " + expr);
}
function exprPart(s: string) { return s.replace(/\s+as\s+[\w$"]+$/i, "").replace(/\s+[\w$"]+$/i, (m) => /^\s*(from|where|order|limit)$/i.test(m.trim()) ? m : ""); }
function aliasOf(s: string) { const m = s.match(/\s+as\s+("?[\w$]+"?)$/i) || s.match(/\s+("?[\w$]+"?)$/); return m ? cleanIdent(m[1]) : exprPart(s).trim(); }
function where(expr: string, row: Record<string, Value>) { return expr.split(/\s+and\s+/i).every(p => { const m = p.match(/^(.+?)\s*(=|!=|<>|<=|>=|<|>|is(?:\s+not)?)\s*(.+)$/i); if (!m) return !!evalExpr(p, row); const a = evalExpr(m[1], row), b = evalExpr(m[3], row); const op = m[2].toLowerCase(); if (op === "=" || op === "is") return a === b; if (op === "!=" || op === "<>" || op === "is not") return a !== b; return op === "<" ? cmp(a,b)<0 : op === ">" ? cmp(a,b)>0 : op === "<=" ? cmp(a,b)<=0 : cmp(a,b)>=0; }); }
function cmp(a: any, b: any) { if (a === b) return 0; if (a === null) return -1; if (b === null) return 1; return a < b ? -1 : 1; }
function table(db: Database, name: string) { const t = db.tables[name]; if (!t) throw new Error("no such table: " + name); return t; }
function rowObj(t: Table, r: Value[]) { return Object.fromEntries(t.columns.map((c, i) => [c, r[i]])); }
function colIndex(t: Table, c: string) { const i = t.columns.indexOf(c); if (i < 0) throw new Error("table " + t.name + " has no column named " + c); return i; }
function cleanIdent(s: string) { return stripQuotes(String(s).trim()).replace(/[`[\]]/g, ""); }
function stripQuotes(s: string) { s = String(s).trim(); const last = s[s.length - 1]; return ((s[0] === "'" && last === "'") || (s[0] === '"' && last === '"')) ? s.slice(1, -1).replace(/''/g, "'").replace(/""/g, '"') : s; }
function quoteIdent(s: string) { return /^[A-Za-z_]\w*$/.test(s) ? s : '"' + s.replace(/"/g, '""') + '"'; }
function sqlLiteral(v: any) { if (v === null || v === undefined) return "NULL"; if (typeof v === "number") return String(v); return "'" + String(v).replace(/'/g, "''") + "'"; }
function csv(v: any) { if (v === null || v === undefined) return ""; const s = String(v); return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
function fmt(v: any, sh: Shell) { return v === null || v === undefined ? sh.nullValue : String(v); }
function escapeHtml(s: string) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function boolArg(a: string | undefined, old: boolean) { if (a === undefined) return old; return /^(1|on|yes|true)$/i.test(a); }
function unescapeArg(s: string) { return s.replace(/\\n/g, "\n").replace(/\\t/g, "\t").replace(/\\r/g, "\r"); }
function shellWords(s: string) { const out: string[] = []; let cur = "", q = ""; for (let i=0;i<s.length;i++){const ch=s[i]; if(q){ if(ch===q) q=""; else cur+=ch; } else if(ch==="'"||ch==='"') q=ch; else if(/\s/.test(ch)){ if(cur){out.push(cur); cur="";}} else cur+=ch;} if(cur) out.push(cur); return out; }

function main() {
  const args = process.argv.slice(2);
  let dbFile = ":memory:"; const cmds: string[] = []; let sqlArgs: string[] = []; let i = 0;
  const pre: ((s: Shell)=>void)[] = [];
  while (i < args.length) {
    const a = args[i];
    if (a === "--") { i++; break; }
    if (a === "-help" || a === "--help") { console.log(HELP); return; }
    if (a === "-version" || a === "--version") { console.log(VERSION); return; }
    if (a === "-cmd") { cmds.push(args[++i] || ""); i++; continue; }
    if (a.startsWith("-") && a !== "-") {
      const opt = a.replace(/^-+/, "");
      const val1 = args[i + 1], val2 = args[i + 2];
      pre.push((s: Shell) => {
        if (["csv","column","line","list","quote","json","table","markdown","html","box","tabs","ascii"].includes(opt)) s.setMode(opt);
        else if (opt === "header") s.headers = true; else if (opt === "noheader") s.headers = false;
        else if (opt === "bail") s.bail = true; else if (opt === "echo") s.echo = true;
        else if (opt === "separator") s.separator = unescapeArg(val1 || s.separator);
        else if (opt === "newline") s.rowSep = unescapeArg(val1 || s.rowSep);
        else if (opt === "nullvalue") s.nullValue = val1 || "";
      });
      if (["separator","nullvalue","newline","init","vfs","mmap","maxsize","lookaside","pagecache","screenwidth","escape","nonce"].includes(opt)) i++;
      if (["lookaside","pagecache"].includes(opt)) i++;
      i++; continue;
    }
    dbFile = a; i++; break;
  }
  sqlArgs = args.slice(i);
  const sh = new Shell(dbFile);
  pre.forEach(f => f(sh));
  for (const c of cmds) sh.runScript(c.includes("\n") || c.trim().startsWith(".") ? c : c + ";", "command line");
  if (sqlArgs.length) sh.runScript(sqlArgs.join(" "), "command line argument");
  else {
    let input = "";
    try { input = fs.readFileSync(0, "utf8"); } catch {}
    if (input) sh.runScript(input, "line");
  }
  sh.save();
  process.exit(sh.exitCode);
}
main();
