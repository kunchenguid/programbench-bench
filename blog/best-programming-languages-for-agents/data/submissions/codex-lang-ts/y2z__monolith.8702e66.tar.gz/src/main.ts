declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");
const { pathToFileURL, fileURLToPath } = require("url");

type Options = {
  noAudio: boolean;
  baseUrl?: string;
  blacklist: boolean;
  noCss: boolean;
  cookieFile?: string;
  domains: string[];
  ignoreErrors: boolean;
  encoding?: string;
  noFrames: boolean;
  noFonts: boolean;
  noImages: boolean;
  isolate: boolean;
  noJs: boolean;
  insecure: boolean;
  mhtml: boolean;
  noMetadata: boolean;
  unwrapNoscript: boolean;
  output?: string;
  quiet: boolean;
  timeout: number;
  userAgent?: string;
  noVideo: boolean;
  target?: string;
};

const VERSION = "monolith 2.11.0";
const HELP = ` _____    _____________   __________     ___________________    ___
|     \\  /             \\ |          |   |                   |  |   |
|      \\/       __      \\|    __    |   |    ___     ___    |__|   |
|              |  |          |  |   |   |   |   |   |   |          |
|   |\\    /|   |__|          |__|   |___|   |   |   |   |    __    |
|   | \\__/ |          |\\                    |   |   |   |   |  |   |
|___|      |__________| \\___________________|   |___|   |___|  |___|

monolith 2.11.0

CLI tool and library for saving web pages as a single HTML file

Usage: executable [OPTIONS] <TARGET>

Arguments:
  <TARGET>  URL or file path, use - for STDIN

Options:
  -a, --no-audio                      Remove audio sources
  -b, --base-url <http://localhost/>  Set custom base URL
  -B, --blacklist-domains             Treat specified domains as blacklist
  -c, --no-css                        Remove CSS
  -C, --cookie-file <cookies.txt>     Specify cookie file
  -d, --domain <example.com>          Specify domains to use for white/black-listing
  -e, --ignore-errors                 Ignore network errors
  -E, --encoding <UTF-8>              Enforce custom charset
  -f, --no-frames                     Remove frames and iframes
  -F, --no-fonts                      Remove fonts
  -i, --no-images                     Remove images
  -I, --isolate                       Cut off document from the Internet
  -j, --no-js                         Remove JavaScript
  -k, --insecure                      Allow invalid X.509 (TLS) certificates
  -m, --mhtml                         Use MHTML as output format
  -M, --no-metadata                   Exclude timestamp and source information
  -n, --unwrap-noscript               Replace NOSCRIPT elements with their contents
  -o, --output <result.html>          File to write to, use - for STDOUT
  -q, --quiet                         Suppress verbosity
  -t, --timeout <60>                  Adjust network request timeout
  -u, --user-agent <Firefox>          Set custom User-Agent string
  -v, --no-video                      Remove video sources
  -h, --help                          Print help
  -V, --version                       Print version`;

function die(message: string, code = 2): never {
  process.stderr.write(message + "\n");
  process.exit(code);
  throw new Error(message);
}

function parseArgs(argv: string[]): Options {
  const opts: Options = {
    noAudio: false, blacklist: false, noCss: false, domains: [], ignoreErrors: false,
    noFrames: false, noFonts: false, noImages: false, isolate: false, noJs: false,
    insecure: false, mhtml: false, noMetadata: false, unwrapNoscript: false,
    quiet: false, timeout: 60, noVideo: false,
  };
  const needValue = (i: number, flag: string) => {
    if (i + 1 >= argv.length) die(`error: a value is required for '${flag}' but none was supplied\n\nFor more information, try '--help'.`);
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") {
      if (i + 1 < argv.length) opts.target = argv[++i];
      continue;
    }
    if (!a.startsWith("-") || a === "-") {
      if (opts.target) die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] <TARGET>\n\nFor more information, try '--help'.`);
      opts.target = a;
      continue;
    }
    const longWithEq = a.match(/^(--[^=]+)=(.*)$/);
    const flag = longWithEq ? longWithEq[1] : a;
    const eqVal = longWithEq ? longWithEq[2] : undefined;
    const take = () => eqVal !== undefined ? eqVal : needValue(i++, flag);
    switch (flag) {
      case "-h": case "--help": process.stdout.write(HELP + "\n"); process.exit(0);
      case "-V": case "--version": process.stdout.write(VERSION + "\n"); process.exit(0);
      case "-a": case "--no-audio": opts.noAudio = true; break;
      case "-b": case "--base-url": opts.baseUrl = take(); break;
      case "-B": case "--blacklist-domains": opts.blacklist = true; break;
      case "-c": case "--no-css": opts.noCss = true; break;
      case "-C": case "--cookie-file": opts.cookieFile = take(); break;
      case "-d": case "--domain": opts.domains.push(take()); break;
      case "-e": case "--ignore-errors": opts.ignoreErrors = true; break;
      case "-E": case "--encoding": opts.encoding = take(); break;
      case "-f": case "--no-frames": opts.noFrames = true; break;
      case "-F": case "--no-fonts": opts.noFonts = true; break;
      case "-i": case "--no-images": opts.noImages = true; break;
      case "-I": case "--isolate": opts.isolate = true; break;
      case "-j": case "--no-js": opts.noJs = true; break;
      case "-k": case "--insecure": opts.insecure = true; break;
      case "-m": case "--mhtml": opts.mhtml = true; break;
      case "-M": case "--no-metadata": opts.noMetadata = true; break;
      case "-n": case "--unwrap-noscript": opts.unwrapNoscript = true; break;
      case "-o": case "--output": opts.output = take(); break;
      case "-q": case "--quiet": opts.quiet = true; break;
      case "-t": case "--timeout": {
        const v = take();
        if (!/^\d+$/.test(v)) die(`error: invalid value '${v}' for '--timeout <60>': invalid digit found in string\n\nFor more information, try '--help'.`);
        opts.timeout = Number(v);
        break;
      }
      case "-u": case "--user-agent": opts.userAgent = take(); break;
      case "-v": case "--no-video": opts.noVideo = true; break;
      default:
        if (/^-[A-Za-z]{2,}$/.test(a) && !a.startsWith("--")) {
          const chars = a.slice(1).split("");
          argv.splice(i, 1, ...chars.map(c => "-" + c));
          i--;
          break;
        }
        die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] <TARGET>\n\nFor more information, try '--help'.`);
    }
  }
  if (!opts.target) die("error: the following required arguments were not provided:\n  <TARGET>\n\nUsage: executable <TARGET>\n\nFor more information, try '--help'.");
  return opts;
}

function log(opts: Options, s: string) {
  if (!opts.quiet) process.stderr.write(s + "\n");
}

function mimeFor(u: string): string {
  const ext = (u.split("?")[0].split("#")[0].match(/\.([A-Za-z0-9]+)$/)?.[1] || "").toLowerCase();
  const map: {[k: string]: string} = {
    html: "text/html", htm: "text/html", css: "text/css", js: "text/javascript", mjs: "text/javascript",
    png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", svg: "image/svg+xml",
    webp: "image/webp", ico: "image/x-icon", woff: "font/woff", woff2: "font/woff2", ttf: "font/ttf",
    otf: "font/otf", mp3: "audio/mpeg", wav: "audio/wav", ogg: "audio/ogg", mp4: "video/mp4",
    webm: "video/webm", txt: "text/plain",
  };
  return map[ext] || "text/plain";
}

function isAbsUrl(s: string): boolean {
  return /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(s) || s.startsWith("//");
}

function defaultBaseForTarget(target: string): string {
  if (target === "-") return pathToFileURL(process.cwd() + "/").href;
  if (/^https?:\/\//i.test(target)) return target;
  const p = path.resolve(target);
  return pathToFileURL(path.dirname(p) + path.sep).href;
}

function resolveUrl(ref: string, base: string): string {
  try {
    if (ref.startsWith("//")) return "https:" + ref;
    return new URL(ref, base).href;
  } catch {
    return ref;
  }
}

async function readUrl(u: string, opts: Options): Promise<any | null> {
  if (/^data:/i.test(u) || /^mailto:/i.test(u) || /^javascript:/i.test(u) || u.startsWith("#")) return null;
  try {
    let buf: any;
    if (u.startsWith("file://")) {
      const p = fileURLToPath(u);
      buf = fs.readFileSync(p);
    } else if (/^https?:\/\//i.test(u)) {
      const res = await fetch(u, { headers: opts.userAgent ? { "user-agent": opts.userAgent } : undefined });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const ab = await res.arrayBuffer();
      buf = Buffer.from(ab);
    } else {
      buf = fs.readFileSync(u);
    }
    log(opts, u);
    return buf;
  } catch (e: any) {
    log(opts, `${u} (${e && e.code === "ENOENT" ? "file not found" : (e?.message || "error")})`);
    if (!opts.ignoreErrors) return null;
    return null;
  }
}

function dataUrl(buf: any, mime: string): string {
  return `data:${mime};base64,${buf.toString("base64")}`;
}

function attrReplace(tag: string, attr: string, value: string): string {
  const re = new RegExp(`\\s${attr}\\s*=\\s*(\"[^\"]*\"|'[^']*'|[^\\s>]+)`, "i");
  if (re.test(tag)) return tag.replace(re, ` ${attr}="${escapeAttr(value)}"`);
  return tag.replace(/\/?>$/, ` ${attr}="${escapeAttr(value)}"$&`);
}

function attrRemove(tag: string, attr: string): string {
  return tag.replace(new RegExp(`\\s${attr}\\s*=\\s*(\"[^\"]*\"|'[^']*'|[^\\s>]+)`, "ig"), "");
}

function getAttr(tag: string, attr: string): string | null {
  const m = tag.match(new RegExp(`\\s${attr}\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))`, "i"));
  return m ? (m[2] ?? m[3] ?? m[4] ?? "") : null;
}

function escapeAttr(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
}

function extractTitle(html: string): string {
  const m = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  if (!m) return "";
  return m[1].replace(/<[^>]*>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").trim();
}

function insertHead(html: string, snippet: string): string {
  const m = html.match(/<head[^>]*>/i);
  if (m && m.index !== undefined) return html.slice(0, m.index + m[0].length) + snippet + html.slice(m.index + m[0].length);
  const hm = html.match(/<html[^>]*>/i);
  if (hm && hm.index !== undefined) return html.slice(0, hm.index + hm[0].length) + "<head>" + snippet + "</head>" + html.slice(hm.index + hm[0].length);
  return "<head>" + snippet + "</head>" + html;
}

function appendHead(html: string, snippet: string): string {
  if (/<\/head>/i.test(html)) return html.replace(/<\/head>/i, snippet + "</head>");
  return insertHead(html, snippet);
}

function ensureCharset(html: string, enc?: string): string {
  if (!enc) return html;
  if (/<meta[^>]+charset\s*=/i.test(html)) return html.replace(/<meta([^>]+)charset\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)([^>]*)>/i, `<meta$1charset="${enc}"$3>`);
  return insertHead(html, `<meta charset="${escapeAttr(enc)}">`);
}

async function inlineCss(css: string, base: string, opts: Options): Promise<string> {
  if (opts.noFonts) css = css.replace(/@font-face\s*\{[\s\S]*?\}/gi, "");
  const matches = [...css.matchAll(/url\(\s*(['"]?)(.*?)\1\s*\)/gi)];
  for (const m of matches) {
    const raw = m[2].trim();
    if (!raw || /^data:/i.test(raw)) continue;
    if (opts.noFonts && /\.(woff2?|ttf|otf)([?#].*)?$/i.test(raw)) {
      css = css.replace(m[0], "url()");
      continue;
    }
    if (opts.noImages && /\.(png|jpe?g|gif|svg|webp|ico)([?#].*)?$/i.test(raw)) {
      css = css.replace(m[0], "url()");
      continue;
    }
    const abs = resolveUrl(raw, base);
    const buf = await readUrl(abs, opts);
    css = css.replace(m[0], buf ? `url("${dataUrl(buf, mimeFor(abs))}")` : "url()");
  }
  return css;
}

async function processHtml(input: string, target: string, opts: Options): Promise<string> {
  let html = input;
  const base = opts.baseUrl || defaultBaseForTarget(target);
  log(opts, target === "-" ? "stdin" : (/^https?:\/\//i.test(target) ? target : pathToFileURL(path.resolve(target)).href));

  if (opts.unwrapNoscript) {
    html = html.replace(/<noscript\b[^>]*>([\s\S]*?)<\/noscript>/gi, "<!--noscript-->$1<!--/noscript-->");
  }
  html = ensureCharset(html, opts.encoding);

  if (opts.noCss) {
    html = html.replace(/<link\b([^>]*\brel\s*=\s*["']?stylesheet["']?[^>]*)>/gi, (t) => attrRemove(t, "href"));
    html = html.replace(/<style\b([^>]*)>[\s\S]*?<\/style>/gi, "<style$1></style>");
  } else {
    const linkMatches = [...html.matchAll(/<link\b[^>]*>/gi)];
    for (const m of linkMatches) {
      const tag = m[0];
      if (!/\brel\s*=\s*["']?stylesheet/i.test(tag)) continue;
      const href = getAttr(tag, "href");
      if (!href) continue;
      const abs = resolveUrl(href, base);
      const buf = await readUrl(abs, opts);
      let css = buf ? buf.toString("utf8") : "";
      css = await inlineCss(css, abs, opts);
      html = html.replace(tag, attrReplace(tag, "href", dataUrl(Buffer.from(css), "text/css")));
    }
    const styleMatches = [...html.matchAll(/<style\b[^>]*>[\s\S]*?<\/style>/gi)];
    for (const m of styleMatches) {
      const tag = m[0];
      const body = tag.replace(/^<style\b[^>]*>/i, "").replace(/<\/style>$/i, "");
      const css = await inlineCss(body, base, opts);
      html = html.replace(tag, tag.replace(body, css));
    }
  }

  if (opts.noJs) {
    html = html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, (t) => {
      const open = t.match(/^<script\b[^>]*>/i)?.[0] || "<script>";
      return attrRemove(open, "src") + "</script>";
    });
  } else {
    const scripts = [...html.matchAll(/<script\b[^>]*\bsrc\s*=[^>]*>[\s\S]*?<\/script>/gi)];
    for (const m of scripts) {
      const tag = m[0];
      const open = tag.match(/^<script\b[^>]*>/i)![0];
      const src = getAttr(open, "src");
      if (!src) continue;
      const abs = resolveUrl(src, base);
      const buf = await readUrl(abs, opts);
      html = html.replace(tag, attrRemove(open, "src") + (buf ? buf.toString("utf8") : "") + "</script>");
    }
  }

  html = await replaceAssetTags(html, "img", "src", base, opts, opts.noImages);
  html = await replaceAssetTags(html, "source", "src", base, opts, opts.noAudio || opts.noVideo);
  html = await replaceSrcset(html, base, opts, opts.noImages);
  html = await replaceAssetTags(html, "audio", "src", base, opts, opts.noAudio);
  html = await replaceAssetTags(html, "video", "src", base, opts, opts.noVideo);
  html = await replaceAssetTags(html, "video", "poster", base, opts, opts.noImages);
  html = await replaceAssetTags(html, "iframe", "src", base, opts, opts.noFrames, true);
  html = await replaceAssetTags(html, "frame", "src", base, opts, opts.noFrames, true);

  html = absolutizeLinks(html, base);
  if (opts.baseUrl) html = appendHead(html, `<base href="${escapeAttr(opts.baseUrl)}"></base>`);
  html = appendHead(html, `<meta name="robots" content="none"></meta>`);

  const csp: string[] = [];
  if (opts.isolate) csp.push("default-src 'unsafe-eval' 'unsafe-inline' data:;");
  if (opts.noCss) csp.push("style-src 'none';");
  if (opts.noJs) csp.push("script-src 'none';");
  if (opts.noFrames) csp.push("frame-src 'none'; child-src 'none';");
  if (opts.noFonts) csp.push("font-src 'none';");
  if (opts.noImages) csp.push("img-src data:;");
  for (const policy of csp.reverse()) html = insertHead(html, `<meta http-equiv="Content-Security-Policy" content="${escapeAttr(policy)}"></meta>`);

  if (!opts.noMetadata) {
    const ts = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
    const src = /^https?:\/\//i.test(target) ? target : "local source";
    html = `<!-- Saved from ${src} at ${ts} using monolith v2.11.0 -->\n` + html;
  }
  return html;
}

async function replaceAssetTags(html: string, tagName: string, attr: string, base: string, opts: Options, disabled: boolean, wrapHtml = false): Promise<string> {
  const re = new RegExp(`<${tagName}\\b[^>]*>`, "gi");
  const tags = [...html.matchAll(re)];
  for (const m of tags) {
    const tag = m[0];
    const val = getAttr(tag, attr);
    if (!val) continue;
    if (disabled) {
      html = html.replace(tag, attrReplace(tag, attr, ""));
      continue;
    }
    const abs = resolveUrl(val, base);
    const buf = await readUrl(abs, opts);
    if (!buf) {
      html = html.replace(tag, attrRemove(tag, attr));
      continue;
    }
    let out = buf;
    let mime = mimeFor(abs);
    if (wrapHtml && mime === "text/plain") {
      out = Buffer.from(`<html><head></head><body>${buf.toString("utf8")}</body></html>`);
      mime = "text/html";
    }
    html = html.replace(tag, attrReplace(tag, attr, dataUrl(out, mime)));
  }
  return html;
}

async function replaceSrcset(html: string, base: string, opts: Options, disabled: boolean): Promise<string> {
  const tags = [...html.matchAll(/<(?:img|source)\b[^>]*\bsrcset\s*=[^>]*>/gi)];
  for (const m of tags) {
    const tag = m[0];
    const ss = getAttr(tag, "srcset");
    if (!ss) continue;
    if (disabled) {
      html = html.replace(tag, attrReplace(tag, "srcset", ""));
      continue;
    }
    const parts: string[] = [];
    for (const item of ss.split(",")) {
      const trimmed = item.trim();
      if (!trimmed) continue;
      const bits = trimmed.split(/\s+/);
      const u = bits.shift()!;
      const abs = resolveUrl(u, base);
      const buf = await readUrl(abs, opts);
      parts.push((buf ? dataUrl(buf, mimeFor(abs)) : "") + (bits.length ? " " + bits.join(" ") : ""));
    }
    html = html.replace(tag, attrReplace(tag, "srcset", parts.join(", ")));
  }
  return html;
}

function absolutizeLinks(html: string, base: string): string {
  return html.replace(/<a\b[^>]*\bhref\s*=[^>]*>/gi, (tag) => {
    const href = getAttr(tag, "href");
    if (!href || isAbsUrl(href) || href.startsWith("#")) return tag;
    return attrReplace(tag, "href", resolveUrl(href, base));
  });
}

async function readTarget(target: string, opts: Options): Promise<string> {
  if (target === "-") return fs.readFileSync(0, "utf8");
  if (/^https?:\/\//i.test(target)) {
    const buf = await readUrl(target, opts);
    if (!buf) process.exit(1);
    return buf.toString("utf8");
  }
  return fs.readFileSync(target, "utf8");
}

function outputName(pattern: string, html: string): string {
  const ts = new Date().toISOString().replace(/\.\d{3}Z$/, "Z").replace(/:/g, "_");
  const title = extractTitle(html) || "untitled";
  return pattern.replace(/%title%/g, title).replace(/%timestamp%/g, ts);
}

function toMhtml(html: string, target: string): string {
  const location = target === "-" ? "stdin" : target;
  return `MIME-Version: 1.0\r
Content-Type: multipart/related; boundary="----=_NextPart_000_0000"\r
\r
------=_NextPart_000_0000\r
Content-Type: text/html; charset="utf-8"\r
Content-Location: ${location}\r
\r
${html}\r
------=_NextPart_000_0000--\r
`;
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.cookieFile) {
    try { fs.readFileSync(opts.cookieFile); } catch {}
  }
  const source = await readTarget(opts.target!, opts);
  let html = await processHtml(source, opts.target!, opts);
  if (opts.mhtml) html = toMhtml(html, opts.target!);
  if (opts.output && opts.output !== "-") {
    const out = outputName(opts.output, html);
    fs.writeFileSync(out, html);
  } else {
    process.stdout.write(html);
    if (!html.endsWith("\n")) process.stdout.write("\n");
  }
}

main().catch((e: any) => {
  process.stderr.write((e?.message || String(e)) + "\n");
  process.exit(1);
});
