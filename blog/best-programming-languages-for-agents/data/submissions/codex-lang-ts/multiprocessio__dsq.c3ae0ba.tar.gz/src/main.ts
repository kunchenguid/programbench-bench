declare const require: any;
declare const process: any;
declare const Buffer: any;
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

type Row = Record<string, any>;
type Table = { name: string; rows: Row[]; columns: string[] };

const HELP = `dsq (Version latest) - commandline SQL engine for data files

Usage:  dsq [file...] $query
        dsq $file [query]
        cat $file | dsq -s $filetype [query]
        dsq $file -f $queryfile

dsq is a tool for running SQL on one or more data files. It uses
SQLite's SQL dialect. Files as tables are accessible via "{N}" where N
is the 0-based index of the file in the commandline.

The shorthand "{}" is replaced with "{0}".

Examples:

    # This simply dumps the CSV as JSON
    $ dsq test.csv

    # This dumps the first 10 rows of the parquet file as JSON.
    $ dsq data.parquet "SELECT * FROM {} LIMIT 10"

    # This joins two datasets of differing origin types (CSV and JSON).
    $ dsq testdata/join/users.csv testdata/join/ages.json \\
          "select {0}.name, {1}.age from {0} join {1} on {0}.id = {1}.id"

See the repo for more details: https://github.com/multiprocessio/dsq`;

function die(msg: string): never {
  console.error(msg);
  process.exit(1);
  throw new Error(msg);
}

function readStdin(): string {
  try { return fs.readFileSync(0, "utf8"); } catch { return ""; }
}

function splitDelimited(text: string, delim: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [], cur = "", quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"') {
        if (text[i + 1] === '"') { cur += '"'; i++; } else quoted = false;
      } else cur += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === delim) { row.push(cur); cur = ""; }
    else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && text[i + 1] === "\n") i++;
      row.push(cur); rows.push(row); row = []; cur = "";
    } else cur += ch;
  }
  if (cur.length || row.length) { row.push(cur); rows.push(row); }
  return rows.filter(r => r.some(c => c.length));
}

function parseJson(text: string): Row[] {
  const s = text.trim();
  if (!s) return [];
  try {
    const v = JSON.parse(s);
    if (Array.isArray(v)) return v.map(x => typeof x === "object" && x !== null ? x : { value: x });
    if (typeof v === "object" && v !== null) return [v as Row];
    return [{ value: v }];
  } catch {
    return s.split(/\r?\n/).filter(Boolean).map(line => {
      const v = JSON.parse(line);
      return typeof v === "object" && v !== null ? v : { value: v };
    });
  }
}

function parseLogfmt(text: string): Row[] {
  return text.split(/\r?\n/).filter(Boolean).map(line => {
    const row: Row = {};
    const re = /(\w+)=("(?:[^"\\]|\\.)*"|\S+)/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(line))) {
      let v = m[2];
      if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1).replace(/\\"/g, '"');
      row[m[1]] = v;
    }
    return row;
  });
}

function zipEntries(buf: any): Map<string, any> {
  const out = new Map<string, any>();
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 66000); i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) return out;
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) break;
    const method = buf.readUInt16LE(off + 10);
    const csize = buf.readUInt32LE(off + 20);
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    const local = buf.readUInt32LE(off + 42);
    const name = buf.slice(off + 46, off + 46 + nameLen).toString("utf8");
    const lnameLen = buf.readUInt16LE(local + 26);
    const lextraLen = buf.readUInt16LE(local + 28);
    const dataStart = local + 30 + lnameLen + lextraLen;
    const comp = buf.slice(dataStart, dataStart + csize);
    try {
      out.set(name, method === 0 ? comp : method === 8 ? zlib.inflateRawSync(comp) : Buffer.alloc(0));
    } catch {
      out.set(name, Buffer.alloc(0));
    }
    off += 46 + nameLen + extraLen + commentLen;
  }
  return out;
}

function xmlText(s: string): string {
  return s.replace(/<[^>]+>/g, "").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
}

function parseXlsx(buf: any): Row[] {
  const zip = zipEntries(buf);
  const sharedXml = zip.get("xl/sharedStrings.xml")?.toString("utf8") || "";
  const shared: string[] = [];
  for (const m of sharedXml.matchAll(/<si[\s\S]*?<\/si>/g)) shared.push(xmlText(m[0]));
  let sheetName = "xl/worksheets/sheet1.xml";
  if (!zip.has(sheetName)) {
    const first = [...zip.keys()].find(k => /^xl\/worksheets\/sheet\d+\.xml$/.test(k));
    if (first) sheetName = first;
  }
  const sheet = zip.get(sheetName)?.toString("utf8") || "";
  const grid: string[][] = [];
  for (const rm of sheet.matchAll(/<row[^>]*>([\s\S]*?)<\/row>/g)) {
    const cells: string[] = [];
    for (const cm of rm[1].matchAll(/<c\b([^>]*)>([\s\S]*?)<\/c>/g)) {
      const attrs = cm[1], body = cm[2];
      const ref = attrs.match(/\br="([A-Z]+)\d+"/);
      let col = cells.length;
      if (ref) col = ref[1].split("").reduce((a, ch) => a * 26 + ch.charCodeAt(0) - 64, 0) - 1;
      const type = attrs.match(/\bt="([^"]+)"/)?.[1];
      const raw = body.match(/<v[^>]*>([\s\S]*?)<\/v>/)?.[1] ?? body.match(/<t[^>]*>([\s\S]*?)<\/t>/)?.[1] ?? "";
      cells[col] = type === "s" ? (shared[Number(raw)] ?? "") : xmlText(raw);
    }
    grid.push(cells.map(x => x ?? ""));
  }
  const hdr = grid.shift() || [];
  return grid.filter(r => r.some(Boolean)).map(r => Object.fromEntries(hdr.map((h, i) => [h || `column${i + 1}`, r[i] ?? ""])));
}

function parseOds(buf: any): Row[] {
  const zip = zipEntries(buf);
  const xml = zip.get("content.xml")?.toString("utf8") || "";
  const firstTable = xml.match(/<table:table\b[\s\S]*?<\/table:table>/)?.[0] || xml;
  const grid: string[][] = [];
  for (const rm of firstTable.matchAll(/<table:table-row\b([^>]*)>([\s\S]*?)<\/table:table-row>/g)) {
    const rowRepeat = Number(rm[1].match(/table:number-rows-repeated="(\d+)"/)?.[1] || "1");
    if (rowRepeat > 1000) continue;
    const row: string[] = [];
    for (const cm of rm[2].matchAll(/<table:table-cell\b([^>]*)>([\s\S]*?)<\/table:table-cell>|<table:covered-table-cell\b([^>]*)\/>/g)) {
      const attrs = cm[1] || cm[3] || "";
      const repeat = Math.min(Number(attrs.match(/table:number-columns-repeated="(\d+)"/)?.[1] || "1"), 1000);
      const body = cm[2] || "";
      const value = attrs.match(/office:value="([^"]*)"/)?.[1] ?? attrs.match(/office:boolean-value="([^"]*)"/)?.[1] ?? xmlText(body);
      for (let i = 0; i < repeat; i++) row.push(value);
    }
    for (let i = 0; i < rowRepeat; i++) if (row.some(Boolean)) grid.push([...row]);
  }
  const hdr = grid.shift() || [];
  return grid.filter(r => r.some(Boolean)).map(r => Object.fromEntries(hdr.map((h, i) => [h || `column${i + 1}`, r[i] ?? ""])));
}

function extensionFormat(file: string): string {
  const ext = path.extname(file).toLowerCase().replace(".", "");
  if (ext === "txt") return "csv";
  if (ext === "ndjson" || ext === "jsonl") return "json";
  if (ext === "logfmt") return "logfmt";
  return ext;
}

function rowsToTable(rows: Row[], name: string): Table {
  const seen = new Set<string>(), columns: string[] = [];
  for (const r of rows) for (const k of Object.keys(r)) if (!seen.has(k)) { seen.add(k); columns.push(k); }
  return { name, rows, columns };
}

function loadTable(file: string, format?: string, index = 0): Table {
  const fmt = (format || extensionFormat(file)).toLowerCase();
  if (fmt === "xlsx") return rowsToTable(parseXlsx(fs.readFileSync(file)), `{${index}}`);
  if (fmt === "ods") return rowsToTable(parseOds(fs.readFileSync(file)), `{${index}}`);
  const text = file === "-" ? readStdin() : fs.readFileSync(file, "utf8");
  if (fmt === "json" || fmt === "jsonl" || fmt === "ndjson") return rowsToTable(parseJson(text), `{${index}}`);
  if (fmt === "tsv") {
    const rows = splitDelimited(text, "\t");
    const hdr = rows.shift() || [];
    return rowsToTable(rows.map(r => Object.fromEntries(hdr.map((h, i) => [h, r[i] ?? ""]))), `{${index}}`);
  }
  if (fmt === "csv" || fmt === "") {
    const rows = splitDelimited(text, ",");
    const hdr = rows.shift() || [];
    return rowsToTable(rows.map(r => Object.fromEntries(hdr.map((h, i) => [h, r[i] ?? ""]))), `{${index}}`);
  }
  if (fmt === "logfmt") return rowsToTable(parseLogfmt(text), `{${index}}`);
  die(`Unknown mimetype for file: ${file}.`);
}

function schema(rows: Row[]): any {
  const obj: any = {};
  const keys = new Set<string>();
  for (const r of rows) for (const k of Object.keys(r)) keys.add(k);
  for (const k of keys) {
    let kind = "null";
    for (const r of rows) if (r[k] !== undefined && r[k] !== null) {
      const v = r[k];
      kind = Array.isArray(v) ? "array" : typeof v === "object" ? "object" : typeof v === "number" ? "number" : typeof v === "boolean" ? "boolean" : "string";
      break;
    }
    obj[k] = { kind: "scalar", scalar: kind };
  }
  return { kind: "array", array: { kind: "object", object: obj } };
}

function normalizeQuery(q: string): string {
  return q.trim().replace(/\{\}/g, "{0}");
}

function splitTop(s: string, sep = ","): string[] {
  const out: string[] = [];
  let cur = "", depth = 0, quote = "";
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quote) { cur += ch; if (ch === quote) quote = ""; continue; }
    if (ch === "'" || ch === '"') { quote = ch; cur += ch; continue; }
    if (ch === "(") depth++;
    if (ch === ")") depth--;
    if (ch === sep && depth === 0) { out.push(cur.trim()); cur = ""; } else cur += ch;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function val(row: Row, expr: string): any {
  expr = expr.trim();
  const as = expr.match(/^(.*?)(?:\s+as\s+|\s+)([A-Za-z_]\w*)$/i);
  if (as && !/[+\-*/<>=]|\(|\)/.test(as[2])) expr = as[1].trim();
  if (/^'.*'$/.test(expr) || /^".*"$/.test(expr)) return expr.slice(1, -1);
  if (/^-?\d+(?:\.\d+)?$/.test(expr)) return Number(expr);
  const mQual = expr.match(/^\{?(\d+)\}?\.(.+)$/);
  if (mQual) return row[`${mQual[1]}.${mQual[2]}`] ?? row[mQual[2]];
  if (expr in row) return row[expr];
  if (expr.includes(".")) return row[expr.split(".").pop() || expr];
  const arith = expr.match(/^(.+?)\s*([+\-*/])\s*(.+)$/);
  if (arith) {
    const a = Number(val(row, arith[1])), b = Number(val(row, arith[3]));
    if (arith[2] === "+") return a + b;
    if (arith[2] === "-") return a - b;
    if (arith[2] === "*") return a * b;
    return a / b;
  }
  return undefined;
}

function cmp(a: any, op: string, b: any): boolean {
  const an = Number(a), bn = Number(b);
  const numeric = a !== "" && b !== "" && !Number.isNaN(an) && !Number.isNaN(bn);
  const x: any = numeric ? an : String(a), y: any = numeric ? bn : String(b);
  if (op === "=" || op === "==") return x == y;
  if (op === "!=" || op === "<>") return x != y;
  if (op === ">") return x > y;
  if (op === "<") return x < y;
  if (op === ">=") return x >= y;
  if (op === "<=") return x <= y;
  return false;
}

function where(row: Row, cond?: string): boolean {
  if (!cond) return true;
  const orParts = cond.split(/\s+or\s+/i);
  return orParts.some(part => part.split(/\s+and\s+/i).every(c => {
    c = c.trim().replace(/^\((.*)\)$/, "$1");
    const inM = c.match(/^(.+?)\s+in\s*\((.*)\)$/i);
    if (inM) return splitTop(inM[2]).some(x => cmp(val(row, inM[1]), "=", val(row, x)));
    const isM = c.match(/^(.+?)\s+is\s+(not\s+)?null$/i);
    if (isM) return isM[2] ? val(row, isM[1]) != null : val(row, isM[1]) == null;
    const m = c.match(/^(.+?)\s*(>=|<=|<>|!=|=|>|<)\s*(.+)$/);
    if (!m) return !!val(row, c);
    return cmp(val(row, m[1]), m[2], val(row, m[3]));
  }));
}

function aliasOf(expr: string): string {
  const m = expr.match(/^(.*?)\s+as\s+(.+)$/i);
  if (m) return m[2].replace(/^["'`]|["'`]$/g, "");
  const bare = expr.match(/^(.+?)\s+([A-Za-z_]\w*)$/);
  if (bare && !/\)$/.test(bare[1])) return bare[2];
  return expr.trim().replace(/^\{?\d+\}?\./, "");
}

function aggregate(expr: string, rows: Row[]): any {
  const m = expr.match(/^(count|sum|avg|min|max)\s*\((.*?)\)$/i);
  if (!m) return val(rows[0] || {}, expr);
  const fn = m[1].toLowerCase(), inner = m[2].trim();
  if (fn === "count") return inner === "*" ? rows.length : rows.filter(r => val(r, inner) != null).length;
  const vals = rows.map(r => val(r, inner)).filter(v => v != null);
  if (fn === "sum" || fn === "avg") {
    const sum = vals.reduce((a, v) => a + Number(v), 0);
    return fn === "sum" ? sum : (vals.length ? sum / vals.length : null);
  }
  vals.sort((a, b) => cmp(a, "<", b) ? -1 : cmp(a, ">", b) ? 1 : 0);
  return fn === "min" ? vals[0] : vals[vals.length - 1];
}

function project(rows: Row[], select: string, groupBy?: string): Row[] {
  const distinct = /^distinct\s+/i.test(select);
  if (distinct) select = select.replace(/^distinct\s+/i, "");
  const exprs = splitTop(select);
  const hasAgg = exprs.some(e => /^(?:.+\s+as\s+)?\s*(count|sum|avg|min|max)\s*\(/i.test(e));
  let groups: Row[][] = [rows];
  if (groupBy) {
    const keys = splitTop(groupBy);
    const map = new Map<string, Row[]>();
    for (const r of rows) {
      const k = JSON.stringify(keys.map(x => val(r, x)));
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(r);
    }
    groups = [...map.values()];
  } else if (!hasAgg) groups = rows.map(r => [r]);
  const out = groups.map(g => {
    const src = g[0] || {};
    if (exprs.length === 1 && exprs[0] === "*") {
      const o: Row = {};
      for (const [k, v] of Object.entries(src)) if (!/^\d+\./.test(k)) o[k] = v;
      return o;
    }
    const o: Row = {};
    for (const e0 of exprs) {
      const e = e0.replace(/\s+as\s+.+$/i, "").trim();
      o[aliasOf(e0)] = /^(count|sum|avg|min|max)\s*\(/i.test(e) ? aggregate(e, g) : val(src, e);
    }
    return o;
  });
  if (!distinct) return out;
  const seen = new Set<string>();
  return out.filter(r => { const k = JSON.stringify(r); if (seen.has(k)) return false; seen.add(k); return true; });
}

function qualifyRows(t: Table, idx: number): Row[] {
  return t.rows.map(r => {
    const o: Row = { ...r };
    for (const [k, v] of Object.entries(r)) o[`${idx}.${k}`] = v;
    return o;
  });
}

function execute(query: string, tables: Table[]): Row[] {
  query = normalizeQuery(query).replace(/;$/, "");
  const m = query.match(/^select\s+([\s\S]+?)\s+from\s+([\s\S]+)$/i);
  if (!m) die("Error: unsupported query");
  let select = m[1].trim(), rest = m[2].trim();
  const takeClause = (name: string): string | undefined => {
    const re = new RegExp(`\\s+${name}\\s+([\\s\\S]+)$`, "i");
    const mm = rest.match(re);
    if (!mm) return undefined;
    const before = rest.slice(0, mm.index).trim();
    let clause = mm[1].trim();
    for (const n of ["where", "group by", "order by", "limit", "offset"]) {
      const r = new RegExp(`\\s+${n}\\s+`, "i");
      const x = clause.search(r);
      if (x >= 0) clause = clause.slice(0, x).trim();
    }
    rest = before + rest.slice((mm.index || 0) + (` ${name} ` + clause).length);
    return clause.trim();
  };
  const limitM = rest.match(/\s+limit\s+(\d+)(?:\s+offset\s+(\d+))?/i);
  const limit = limitM ? Number(limitM[1]) : undefined;
  const offset = limitM?.[2] ? Number(limitM[2]) : 0;
  if (limitM) rest = (rest.slice(0, limitM.index) + rest.slice((limitM.index || 0) + limitM[0].length)).trim();
  const orderM = rest.match(/\s+order\s+by\s+(.+)$/i);
  const order = orderM?.[1]?.trim();
  if (orderM) rest = rest.slice(0, orderM.index).trim();
  const groupM = rest.match(/\s+group\s+by\s+(.+)$/i);
  const group = groupM?.[1]?.trim();
  if (groupM) rest = rest.slice(0, groupM.index).trim();
  const whereM = rest.match(/\s+where\s+(.+)$/i);
  const cond = whereM?.[1]?.trim();
  if (whereM) rest = rest.slice(0, whereM.index).trim();
  const joinM = rest.match(/^(\{\d+\}|\S+)\s+join\s+(\{\d+\}|\S+)\s+on\s+(.+)$/i);
  let rows: Row[] = [];
  if (joinM) {
    const a = tableIndex(joinM[1]), b = tableIndex(joinM[2]);
    for (const ra of qualifyRows(tables[a], a)) for (const rb of qualifyRows(tables[b], b)) {
      const merged = { ...ra, ...rb };
      if (where(merged, joinM[3])) rows.push(merged);
    }
  } else {
    rows = qualifyRows(tables[tableIndex(rest.split(/\s+/)[0])], tableIndex(rest.split(/\s+/)[0]));
  }
  rows = rows.filter(r => where(r, cond));
  let out = project(rows, select, group);
  if (order) {
    const om = order.match(/^(.+?)(?:\s+(asc|desc))?$/i)!;
    out.sort((a, b) => cmp(val(a, om[1]), "<", val(b, om[1])) ? -1 : cmp(val(a, om[1]), ">", val(b, om[1])) ? 1 : 0);
    if ((om[2] || "").toLowerCase() === "desc") out.reverse();
  }
  return out.slice(offset, limit === undefined ? undefined : offset + limit);
}

function tableIndex(s: string): number {
  const m = s.match(/\{?(\d+)\}?/);
  return m ? Number(m[1]) : 0;
}

function printJson(rows: Row[]) {
  if (rows.length === 0) { console.log("[]"); return; }
  console.log("[" + rows.map(r => JSON.stringify(r)).join(",\n") + "]");
}

function printPretty(rows: Row[]) {
  const cols: string[] = [];
  for (const r of rows) for (const k of Object.keys(r)) if (!cols.includes(k)) cols.push(k);
  const widths = cols.map(c => Math.max(c.length, ...rows.map(r => String(r[c] ?? "").length)));
  const line = "+" + widths.map(w => "-".repeat(w + 2)).join("+") + "+";
  console.log(line);
  console.log("| " + cols.map((c, i) => c.padEnd(widths[i])).join(" | ") + " |");
  console.log(line);
  for (const r of rows) console.log("| " + cols.map((c, i) => {
    const s = String(r[c] ?? "");
    return /^-?\d+(?:\.\d+)?$/.test(s) ? s.padStart(widths[i]) : s.padEnd(widths[i]);
  }).join(" | ") + " |");
  console.log(line);
  console.log(`(${rows.length} ${rows.length === 1 ? "row" : "rows"})`);
}

function main() {
  const args = process.argv.slice(2);
  if (args.includes("--help") || args.includes("-h")) { console.log(HELP); return; }
  if (args.includes("--version")) { console.log("dsq latest"); return; }
  let pretty = false, schemaFlag = false, streamFmt: string | undefined, queryFile: string | undefined;
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-p" || a === "--pretty") pretty = true;
    else if (a === "--schema") schemaFlag = true;
    else if (a === "-s") streamFmt = args[++i];
    else if (a === "-f" || a === "--file") queryFile = args[++i];
    else if (a === "-C" || a === "--cache" || a === "-i" || a === "--interactive") continue;
    else rest.push(a);
  }
  let query: string | undefined = queryFile ? fs.readFileSync(queryFile, "utf8") : undefined;
  let files = rest;
  if (!query && rest.length && /^select\b/i.test(rest[rest.length - 1])) {
    query = rest[rest.length - 1];
    files = rest.slice(0, -1);
  }
  if (streamFmt && files.length === 0) files = ["-"];
  if (files.length === 0) die(HELP);
  const tables = files.map((f, i) => loadTable(f, f === "-" ? streamFmt : undefined, i));
  if (schemaFlag) { console.log(JSON.stringify(schema(tables[0].rows), null, 2)); return; }
  if (!query) query = "select * from {0}";
  const rows = execute(query, tables);
  pretty ? printPretty(rows) : printJson(rows);
}

main();
