declare const require: any;
declare const process: any;

const fs = require("fs");
const os = require("os");
const path = require("path");
const child_process = require("child_process");

type Options = {
  lang?: string;
  file?: string;
  code?: string;
  noDetect: boolean;
  args: string[];
};

const HELP = `Universal multi-language runner and REPL

Usage: executable [OPTIONS] [ARGS]...

Arguments:
  [ARGS]...  Positional arguments (language, code, or file)

Options:
  -V, --version      Print version information and exit
  -l, --lang <LANG>  Explicitly choose the language to execute
  -f, --file <PATH>  Execute code from the provided file path
  -c, --code <CODE>  Execute the provided code snippet
      --no-detect    Disable heuristic language detection
  -h, --help         Print help`;

const VERSION = `run-kit 0.3.2
Universal multi-language runner and smart REPL
author: Esubalew Chekol <esubalewchekol6@gmail.com>
homepage: https://esubalew.et
repository: https://github.com/Esubaalew/run
license: Apache-2.0
commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)
built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]
rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)`;

function dieParse(message: string): void {
  process.stderr.write(`${message}\n\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function parse(argv: string[]): Options {
  const opts: Options = { noDetect: false, args: [] };
  let passthrough = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (passthrough) {
      opts.args.push(a);
      continue;
    }
    if (a === "--") {
      passthrough = true;
      continue;
    }
    if (a === "-h" || a === "--help") {
      console.log(HELP);
      process.exit(0);
    }
    if (a === "-V" || a === "--version") {
      console.log(VERSION);
      process.exit(0);
    }
    if (a === "--no-detect") {
      opts.noDetect = true;
      continue;
    }
    if (a === "-l" || a === "--lang") {
      if (i + 1 >= argv.length || argv[i + 1].startsWith("-")) {
        dieParse(`error: a value is required for '--lang <LANG>' but none was supplied`);
      }
      opts.lang = argv[++i];
      continue;
    }
    if (a === "-f" || a === "--file") {
      if (i + 1 >= argv.length || argv[i + 1].startsWith("-")) {
        dieParse(`error: a value is required for '--file <PATH>' but none was supplied`);
      }
      opts.file = argv[++i];
      continue;
    }
    if (a === "-c" || a === "--code") {
      if (i + 1 >= argv.length) {
        dieParse(`error: a value is required for '--code <CODE>' but none was supplied`);
      }
      opts.code = argv[++i];
      continue;
    }
    if (a.startsWith("-")) {
      process.stderr.write(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [ARGS]...\n\nFor more information, try '--help'.\n`);
      process.exit(2);
    }
    opts.args.push(a);
  }
  return opts;
}

function normalizeLang(lang: string | undefined): string | undefined {
  if (!lang) return undefined;
  const l = lang.toLowerCase();
  const map: Record<string, string> = {
    javascript: "js",
    node: "js",
    nodejs: "js",
    typescript: "ts",
    py: "python",
    shell: "bash",
    sh: "bash",
    cxx: "cpp",
    "c++": "cpp",
  };
  return map[l] || l;
}

function detectFromFile(file: string): string | undefined {
  const ext = path.extname(file).toLowerCase();
  const map: Record<string, string> = {
    ".js": "js",
    ".mjs": "js",
    ".cjs": "js",
    ".ts": "ts",
    ".py": "python",
    ".sh": "bash",
    ".bash": "bash",
    ".c": "c",
    ".h": "c",
    ".cc": "cpp",
    ".cpp": "cpp",
    ".cxx": "cpp",
    ".rs": "rust",
    ".go": "go",
    ".pl": "perl",
    ".lua": "lua",
    ".rb": "ruby",
  };
  return map[ext];
}

function detectFromCode(code: string, noDetect: boolean): string {
  if (noDetect) return "python";
  const s = code.trim();
  if (/^(console\.log|const |let |var |function |import |require\(|process\.)/.test(s)) return "js";
  if (/^(echo|printf|ls|cat|pwd|cd|export|for |if |while )\b/.test(s) || s.includes("#!/bin/sh") || s.includes("#!/usr/bin/env bash")) return "bash";
  if (/^print\s*\(/.test(s)) return "lua";
  if (/^puts\b/.test(s)) return "ruby";
  if (/#include\s*<iostream>|std::|cout\s*<</.test(s)) return "cpp";
  if (/#include\s*<|printf\s*\(|int\s+main\s*\(/.test(s)) return "c";
  return "python";
}

function run(cmd: string, args: string[], input?: any): void {
  const r = child_process.spawnSync(cmd, args, { stdio: input === undefined ? "inherit" : ["pipe", "inherit", "inherit"], input });
  if (r.error) {
    process.exit(127);
  }
  process.exit(r.status === null ? 1 : r.status);
}

function unavailable(lang: string): void {
  if (lang === "python") {
    process.stderr.write("python is not available in the ts-mandated arm\n");
    process.exit(127);
  }
  if (lang === "lua") {
    process.stderr.write("Error: Lua support requires the `lua` executable. Install it from https://www.lua.org/download.html and ensure it is on your PATH.\n");
    process.exit(1);
  }
  if (lang === "ruby") process.exit(127);
  if (lang === "ts") process.exit(127);
  process.stderr.write(`Error: Unsupported language: ${lang}\n`);
  process.exit(1);
}

function withTempDir(prefix: string, fn: (dir: string) => number): void {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), prefix));
  let status = 1;
  try {
    status = fn(dir);
  } finally {
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) {}
  }
  process.exit(status);
}

function runCompiled(lang: string, code: string): void {
  withTempDir(`run-${lang}`, (dir) => {
    if (lang === "c") {
      const src = path.join(dir, "main.c");
      const bin = path.join(dir, "main");
      let body = code;
      if (!/int\s+main\s*\(/.test(code)) body = `#include <stdio.h>\nint main(){\n${code}\nreturn 0;\n}\n`;
      fs.writeFileSync(src, body);
      const c = child_process.spawnSync("gcc", [src, "-o", bin], { stdio: "inherit" });
      if (c.status !== 0) return c.status || 1;
      const r = child_process.spawnSync(bin, [], { stdio: "inherit" });
      return r.status === null ? 1 : r.status;
    }
    const src = path.join(dir, "main.cpp");
    const bin = path.join(dir, "main");
    fs.writeFileSync(src, code);
    const c = child_process.spawnSync("g++", [src, "-o", bin], { stdio: "inherit" });
    if (c.status !== 0) return c.status || 1;
    const r = child_process.spawnSync(bin, [], { stdio: "inherit" });
    return r.status === null ? 1 : r.status;
  });
}

function execute(lang: string, code?: string, file?: string): void {
  lang = normalizeLang(lang) || "";
  if (file) {
    if (lang === "js") return run("node", [file]);
    if (lang === "bash") return run("bash", [file]);
    if (lang === "perl") return run("perl", [file]);
    if (lang === "python" || lang === "lua" || lang === "ruby" || lang === "ts") return unavailable(lang);
    if (lang === "c" || lang === "cpp") {
      const source = fs.readFileSync(file, "utf8");
      return runCompiled(lang, source);
    }
  }
  code = code || "";
  if (lang === "js") return run("node", ["-e", code]);
  if (lang === "bash") return run("bash", ["-c", code]);
  if (lang === "perl") return run("perl", ["-e", code]);
  if (lang === "c" || lang === "cpp") return runCompiled(lang, code);
  if (lang === "go") {
    process.stderr.write("Error: Go support requires the `go` executable. Install it from https://go.dev/dl/ and ensure it is on your PATH.\n");
    process.exit(1);
  }
  if (lang === "rust") {
    process.stderr.write("Error: Rust support requires the `rustc` executable. Install it via Rustup and ensure it is on your PATH.\n");
    process.exit(1);
  }
  return unavailable(lang || "python");
}

function main(): void {
  const opts = parse(process.argv.slice(2));
  if (opts.code !== undefined && opts.args.length > 0) {
    if (!opts.lang && opts.args.length === 1) {
      opts.lang = opts.args[0];
      opts.args = [];
    } else {
      process.stderr.write("Error: Unexpected positional arguments after specifying --code\n");
      process.exit(1);
    }
  }

  let lang = normalizeLang(opts.lang);
  let file = opts.file;
  let code = opts.code;

  if (!file && code === undefined && opts.args.length > 0) {
    const first = opts.args[0];
    if (fs.existsSync(first) && fs.statSync(first).isFile()) {
      file = first;
    } else if (opts.args.length === 1 && !lang) {
      code = first;
    } else {
      if (!lang) lang = normalizeLang(first);
      code = opts.args.slice(1).join(" ");
    }
  }

  if (file) {
    if (!lang) lang = detectFromFile(file) || "python";
    return execute(lang, undefined, file);
  }
  if (code !== undefined) {
    if (!lang) lang = detectFromCode(code, opts.noDetect);
    return execute(lang, code, undefined);
  }
  process.exit(127);
}

main();
