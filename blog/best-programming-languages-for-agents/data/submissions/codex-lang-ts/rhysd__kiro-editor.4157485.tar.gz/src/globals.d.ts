declare const process: any;
declare const Buffer: any;
declare function require(name: string): any;
