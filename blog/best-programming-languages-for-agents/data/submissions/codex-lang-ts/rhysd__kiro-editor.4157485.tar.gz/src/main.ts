const fs = require("fs");
const path = require("path");

const VERSION = "0.4.3";

const HELP = `./executable: A tiny UTF-8 terminal text editor

Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.
Specify file paths to edit as a command argument or run without argument to
start to write a new text.
Help can show up with key mapping Ctrl-?.

Usage:
    ./executable [options] [FILES...]

Mappings:
    Ctrl-Q                        : Quit
    Ctrl-S                        : Save to file
    Ctrl-O                        : Open text buffer
    Ctrl-X                        : Next text buffer
    Alt-X                         : Previous text buffer
    Ctrl-P or UP                  : Move cursor up
    Ctrl-N or DOWN                : Move cursor down
    Ctrl-F or RIGHT               : Move cursor right
    Ctrl-B or LEFT                : Move cursor left
    Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line
    Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line
    Ctrl-[ or Ctrl-V or PAGE DOWN : Next page
    Ctrl-] or Alt-V or PAGE UP    : Previous page
    Alt-F or Ctrl-RIGHT           : Move cursor to next word
    Alt-B or Ctrl-LEFT            : Move cursor to previous word
    Alt-N or Ctrl-DOWN            : Move cursor to next paragraph
    Alt-P or Ctrl-UP              : Move cursor to previous paragraph
    Alt-<                         : Move cursor to top of file
    Alt->                         : Move cursor to bottom of file
    Ctrl-H or BACKSPACE           : Delete character
    Ctrl-D or DELETE              : Delete next character
    Ctrl-W                        : Delete a word
    Ctrl-J                        : Delete until head of line
    Ctrl-K                        : Delete until end of line
    Ctrl-U                        : Undo last change
    Ctrl-R                        : Redo last undo change
    Ctrl-G                        : Search text
    Ctrl-M                        : New line
    Ctrl-L                        : Refresh screen
    Ctrl-?                        : Show this help

Options:
    -v, --version       Print version
    -h, --help          Print this help
`;

type Snapshot = { rows: string[]; cx: number; cy: number };

class TextBuffer {
  filename: string | null;
  rows: string[];
  cx = 0;
  cy = 0;
  dirty = false;
  undo: Snapshot[] = [];
  redo: Snapshot[] = [];

  constructor(filename: string | null) {
    this.filename = filename;
    if (filename) {
      try {
        const text = fs.readFileSync(filename, "utf8").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
        this.rows = text.length ? text.replace(/\n$/, "").split("\n") : [""];
      } catch (_e) {
        this.rows = [""];
      }
    } else {
      this.rows = [""];
    }
  }

  snap(): Snapshot {
    return { rows: this.rows.slice(), cx: this.cx, cy: this.cy };
  }

  restore(s: Snapshot): void {
    this.rows = s.rows.slice();
    this.cx = s.cx;
    this.cy = s.cy;
    this.clamp();
  }

  record(): void {
    this.undo.push(this.snap());
    if (this.undo.length > 100) this.undo.shift();
    this.redo = [];
  }

  clamp(): void {
    if (this.cy < 0) this.cy = 0;
    if (this.cy >= this.rows.length) this.cy = this.rows.length - 1;
    if (this.cx < 0) this.cx = 0;
    const len = [...this.rows[this.cy]].length;
    if (this.cx > len) this.cx = len;
  }

  lineChars(): string[] {
    return [...this.rows[this.cy]];
  }

  setLine(chars: string[]): void {
    this.rows[this.cy] = chars.join("");
  }

  insert(s: string): void {
    this.record();
    for (const ch of [...s]) {
      if (ch === "\n") this.newline(false);
      else {
        const chars = this.lineChars();
        chars.splice(this.cx, 0, ch);
        this.setLine(chars);
        this.cx++;
      }
    }
    this.dirty = true;
  }

  newline(record = true): void {
    if (record) this.record();
    const chars = this.lineChars();
    const left = chars.slice(0, this.cx).join("");
    const right = chars.slice(this.cx).join("");
    this.rows[this.cy] = left;
    this.rows.splice(this.cy + 1, 0, right);
    this.cy++;
    this.cx = 0;
    this.dirty = true;
  }

  backspace(): void {
    if (this.cx === 0 && this.cy === 0) return;
    this.record();
    if (this.cx > 0) {
      const chars = this.lineChars();
      chars.splice(this.cx - 1, 1);
      this.cx--;
      this.setLine(chars);
    } else {
      const prevLen = [...this.rows[this.cy - 1]].length;
      this.rows[this.cy - 1] += this.rows[this.cy];
      this.rows.splice(this.cy, 1);
      this.cy--;
      this.cx = prevLen;
    }
    this.dirty = true;
  }

  deleteForward(): void {
    const chars = this.lineChars();
    if (this.cx >= chars.length && this.cy >= this.rows.length - 1) return;
    this.record();
    if (this.cx < chars.length) {
      chars.splice(this.cx, 1);
      this.setLine(chars);
    } else {
      this.rows[this.cy] += this.rows[this.cy + 1];
      this.rows.splice(this.cy + 1, 1);
    }
    this.dirty = true;
  }

  killToEnd(): void {
    this.record();
    const chars = this.lineChars();
    if (this.cx < chars.length) {
      this.setLine(chars.slice(0, this.cx));
    } else if (this.cy < this.rows.length - 1) {
      this.rows[this.cy] += this.rows[this.cy + 1];
      this.rows.splice(this.cy + 1, 1);
    }
    this.dirty = true;
  }

  killToStart(): void {
    if (this.cx === 0) return;
    this.record();
    const chars = this.lineChars();
    this.setLine(chars.slice(this.cx));
    this.cx = 0;
    this.dirty = true;
  }

  deleteWord(): void {
    if (this.cx === 0) {
      this.backspace();
      return;
    }
    this.record();
    const chars = this.lineChars();
    let start = this.cx;
    while (start > 0 && /\s/u.test(chars[start - 1])) start--;
    while (start > 0 && !/\s/u.test(chars[start - 1])) start--;
    chars.splice(start, this.cx - start);
    this.cx = start;
    this.setLine(chars);
    this.dirty = true;
  }

  save(): string {
    if (!this.filename) return "No file name";
    fs.writeFileSync(this.filename, this.rows.join("\n") + "\n", "utf8");
    this.dirty = false;
    return `${this.rows.length} lines written to ${this.filename}`;
  }
}

class Editor {
  buffers: TextBuffer[];
  current = 0;
  rowoff = 0;
  coloff = 0;
  screenRows = 24;
  screenCols = 80;
  message = "";
  quit = false;
  prompt: { label: string; value: string; done: (v: string | null) => void } | null = null;

  constructor(files: string[]) {
    this.buffers = files.length ? files.map((f) => new TextBuffer(f)) : [new TextBuffer(null)];
    this.updateSize();
    process.stdout.on("resize", () => {
      this.updateSize();
      this.refresh();
    });
  }

  get buf(): TextBuffer {
    return this.buffers[this.current];
  }

  updateSize(): void {
    this.screenRows = Math.max(4, process.stdout.rows || 24);
    this.screenCols = Math.max(20, process.stdout.columns || 80);
  }

  start(): void {
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.setEncoding("utf8");
    process.stdout.write("\x1b[?1049h\x1b[?25l");
    this.message = "HELP: Ctrl-? = help | Ctrl-S = save | Ctrl-Q = quit";
    this.refresh();
    process.stdin.on("data", (chunk: string) => this.onData(chunk));
    process.on("SIGINT", () => this.close());
  }

  close(): void {
    try { process.stdin.setRawMode(false); } catch (_e) {}
    process.stdout.write("\x1b[?25h\x1b[?1049l");
    process.exit(0);
  }

  refresh(): void {
    this.scroll();
    const b = this.buf;
    let out = "\x1b[?25l\x1b[H";
    const rowsForText = this.screenRows - 2;
    for (let y = 0; y < rowsForText; y++) {
      const filerow = y + this.rowoff;
      if (filerow >= b.rows.length) {
        out += "~";
      } else {
        const line = [...b.rows[filerow]].slice(this.coloff, this.coloff + this.screenCols).join("");
        out += line;
      }
      out += "\x1b[K\r\n";
    }
    const name = b.filename ? path.basename(b.filename) : "[No Name]";
    const dirty = b.dirty ? " (modified)" : "";
    const statusLeft = ` ${name}${dirty} - ${b.rows.length} lines `;
    const statusRight = `${this.current + 1}/${this.buffers.length} ${b.cy + 1}:${b.cx + 1} `;
    const gap = Math.max(0, this.screenCols - width(statusLeft) - width(statusRight));
    out += "\x1b[7m" + truncate(statusLeft + " ".repeat(gap) + statusRight, this.screenCols) + "\x1b[m\r\n";
    const msg = this.prompt ? `${this.prompt.label}${this.prompt.value}` : this.message;
    out += truncate(msg, this.screenCols) + "\x1b[K";
    const cy = b.cy - this.rowoff + 1;
    const cx = b.cx - this.coloff + 1;
    out += `\x1b[${cy};${cx}H\x1b[?25h`;
    process.stdout.write(out);
  }

  scroll(): void {
    const b = this.buf;
    b.clamp();
    const textRows = this.screenRows - 2;
    if (b.cy < this.rowoff) this.rowoff = b.cy;
    if (b.cy >= this.rowoff + textRows) this.rowoff = b.cy - textRows + 1;
    if (b.cx < this.coloff) this.coloff = b.cx;
    if (b.cx >= this.coloff + this.screenCols) this.coloff = b.cx - this.screenCols + 1;
  }

  onData(chunk: string): void {
    for (let i = 0; i < chunk.length; i++) {
      const ch = chunk[i];
      if (ch === "\x1b" && i + 1 < chunk.length) {
        let seq = ch + chunk[++i];
        if (seq[1] === "[" || seq[1] === "O") {
          while (i + 1 < chunk.length && !/[A-Za-z~<>]/.test(chunk[i])) seq += chunk[++i];
        } else if (i + 1 < chunk.length) {
          seq += chunk[++i];
        }
        this.key(seq);
      } else {
        this.key(ch);
      }
      if (this.quit) return;
    }
    this.refresh();
  }

  key(k: string): void {
    if (this.prompt) {
      this.promptKey(k);
      return;
    }
    const b = this.buf;
    if (k === "\x11") this.close();
    else if (k === "\x13") this.message = b.save();
    else if (k === "\x0f") this.openPrompt();
    else if (k === "\x18") this.switchBuffer(1);
    else if (k === "\x1bx") this.switchBuffer(-1);
    else if (k === "\x15") this.undo();
    else if (k === "\x12") this.redo();
    else if (k === "\x07") this.searchPrompt();
    else if (k === "\x0c") this.message = "";
    else if (k === "\x7f" || k === "\x08") b.backspace();
    else if (k === "\x04" || k === "\x1b[3~") b.deleteForward();
    else if (k === "\x17") b.deleteWord();
    else if (k === "\x0a") b.killToStart();
    else if (k === "\x0b") b.killToEnd();
    else if (k === "\r" || k === "\x0d") b.newline();
    else if (k === "\x10" || k === "\x1b[A") this.move(0, -1);
    else if (k === "\x0e" || k === "\x1b[B") this.move(0, 1);
    else if (k === "\x06" || k === "\x1b[C") this.move(1, 0);
    else if (k === "\x02" || k === "\x1b[D") this.move(-1, 0);
    else if (k === "\x01" || k === "\x1b[H" || k === "\x1b[1~" || k === "\x1bOH" || k === "\x1b[1;3D") b.cx = 0;
    else if (k === "\x05" || k === "\x1b[F" || k === "\x1b[4~" || k === "\x1bOF" || k === "\x1b[1;3C") b.cx = [...b.rows[b.cy]].length;
    else if (k === "\x1b[6~" || k === "\x16" || k === "\x1b") this.page(1);
    else if (k === "\x1b[5~" || k === "\x1b]" || k === "\x1bv") this.page(-1);
    else if (k === "\x1bf" || k === "\x1b[1;5C") this.word(1);
    else if (k === "\x1bb" || k === "\x1b[1;5D") this.word(-1);
    else if (k === "\x1bn" || k === "\x1b[1;5B") this.paragraph(1);
    else if (k === "\x1bp" || k === "\x1b[1;5A") this.paragraph(-1);
    else if (k === "\x1b<") { b.cy = 0; b.cx = 0; }
    else if (k === "\x1b>") { b.cy = b.rows.length - 1; b.cx = [...b.rows[b.cy]].length; }
    else if (k === "\x1b?" || k === "\x7f") this.message = "Ctrl-Q quit | Ctrl-S save | Ctrl-O open | Ctrl-G search | Ctrl-U undo | Ctrl-R redo";
    else if (k >= " " && k !== "\x7f" && !k.startsWith("\x1b")) b.insert(k);
  }

  move(dx: number, dy: number): void {
    const b = this.buf;
    if (dy) b.cy += dy;
    if (dx < 0) {
      if (b.cx > 0) b.cx--;
      else if (b.cy > 0) { b.cy--; b.cx = [...b.rows[b.cy]].length; }
    } else if (dx > 0) {
      if (b.cx < [...b.rows[b.cy]].length) b.cx++;
      else if (b.cy < b.rows.length - 1) { b.cy++; b.cx = 0; }
    }
    b.clamp();
  }

  page(dir: number): void {
    const amount = this.screenRows - 2;
    this.buf.cy += dir * amount;
    this.buf.clamp();
  }

  word(dir: number): void {
    const b = this.buf;
    if (dir > 0) {
      const line = [...b.rows[b.cy]];
      while (b.cx < line.length && !/\s/u.test(line[b.cx])) b.cx++;
      while (b.cx < line.length && /\s/u.test(line[b.cx])) b.cx++;
      if (b.cx >= line.length && b.cy < b.rows.length - 1) { b.cy++; b.cx = 0; }
    } else {
      if (b.cx === 0 && b.cy > 0) { b.cy--; b.cx = [...b.rows[b.cy]].length; }
      const line = [...b.rows[b.cy]];
      while (b.cx > 0 && /\s/u.test(line[b.cx - 1])) b.cx--;
      while (b.cx > 0 && !/\s/u.test(line[b.cx - 1])) b.cx--;
    }
    b.clamp();
  }

  paragraph(dir: number): void {
    const b = this.buf;
    do {
      b.cy += dir;
    } while (b.cy > 0 && b.cy < b.rows.length - 1 && b.rows[b.cy].trim() !== "");
    b.cx = 0;
    b.clamp();
  }

  switchBuffer(delta: number): void {
    this.current = (this.current + delta + this.buffers.length) % this.buffers.length;
    this.rowoff = 0;
    this.coloff = 0;
  }

  undo(): void {
    const b = this.buf;
    const s = b.undo.pop();
    if (!s) return;
    b.redo.push(b.snap());
    b.restore(s);
    b.dirty = true;
  }

  redo(): void {
    const b = this.buf;
    const s = b.redo.pop();
    if (!s) return;
    b.undo.push(b.snap());
    b.restore(s);
    b.dirty = true;
  }

  openPrompt(): void {
    this.prompt = { label: "Open: ", value: "", done: (v) => {
      if (v) {
        this.buffers.push(new TextBuffer(v));
        this.current = this.buffers.length - 1;
        this.message = `Opened ${v}`;
      }
    }};
  }

  searchPrompt(): void {
    this.prompt = { label: "Search: ", value: "", done: (v) => {
      if (!v) return;
      const b = this.buf;
      for (let y = 0; y < b.rows.length; y++) {
        const idx = b.rows[y].indexOf(v);
        if (idx >= 0) {
          b.cy = y;
          b.cx = [...b.rows[y].slice(0, idx)].length;
          this.message = `Found: ${v}`;
          return;
        }
      }
      this.message = `Not found: ${v}`;
    }};
  }

  promptKey(k: string): void {
    const p = this.prompt!;
    if (k === "\x1b" || k === "\x07") {
      this.prompt = null;
      p.done(null);
    } else if (k === "\r" || k === "\x0d") {
      this.prompt = null;
      p.done(p.value);
    } else if (k === "\x7f" || k === "\x08") {
      p.value = [...p.value].slice(0, -1).join("");
    } else if (k >= " " && !k.startsWith("\x1b")) {
      p.value += k;
    }
  }
}

function width(s: string): number {
  return [...s].length;
}

function truncate(s: string, n: number): string {
  return [...s].slice(0, n).join("");
}

function parse(argv: string[]): { files: string[]; exit: boolean; code: number } {
  const files: string[] = [];
  let endOptions = false;
  for (const arg of argv) {
    if (!endOptions && arg === "--") {
      endOptions = true;
      continue;
    }
    if (!endOptions && (arg === "-v" || arg === "--version" || arg.includes("v") && arg.startsWith("-") && !arg.startsWith("--"))) {
      process.stdout.write(VERSION + "\n");
      return { files, exit: true, code: 0 };
    }
    if (!endOptions && (arg === "-h" || arg === "--help" || arg.includes("h") && arg.startsWith("-") && !arg.startsWith("--"))) {
      process.stdout.write(HELP);
      return { files, exit: true, code: 0 };
    }
    if (!endOptions && arg.startsWith("-")) {
      const opt = arg.replace(/^-+/, "");
      process.stderr.write(`Error: Unrecognized option: '${opt}'. Please see --help for more details\n`);
      return { files, exit: true, code: 1 };
    }
    files.push(arg);
  }
  return { files, exit: false, code: 0 };
}

const parsed = parse(process.argv.slice(2));
if (parsed.exit) process.exit(parsed.code);
if (!process.stdin.isTTY || !process.stdout.isTTY) {
  process.stderr.write("Error: Inappropriate ioctl for device (os error 25)\n");
  process.exit(1);
}
new Editor(parsed.files).start();
