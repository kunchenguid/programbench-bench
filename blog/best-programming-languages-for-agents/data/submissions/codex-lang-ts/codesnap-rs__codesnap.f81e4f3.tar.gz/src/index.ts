declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");
const os = require("os");
const childProcess = require("child_process");

type Opts = Record<string, any>;

const HELP_LONG = `CLI tools for generating beautiful code snapshots

Usage: codesnap [OPTIONS] --output <OUTPUT>

Options:
  -f, --from-file <FROM_FILE>
          Path to the file to snapshot

  -c, --from-code [<Code>]
          Code snippet for snapshot

  -i, --from-image [<Image>]
          

      --from-clipboard
          

  -o, --output <OUTPUT>
          Output path for the snapshot. Available value:
          
          - clipboard: Copy the snapshot to clipboard - file path: Save the snapshot to the file path
          
          Currently CodeSnap supports SVG format and PNG format If output is directory, CodeSnap will generate a temporary file name to save the snapshot to the directory.

      --silent
          

  -e, --execute <EXECUTE>...
          Executing a command and taking the output as the code snippet

      --skip
          Skip run the command to get output, just take the command as the input

      --range <RANGE>
          You can set the range of the code snippet to display for example, display the 3rd to 5th: 3:5 The syntax is similar to the range in Python or Golang, so basically you can use 3: to represent the 3rd to the end, or use :5 to represent the start to the 5th. This option is useful when you use the \`from_file\` option as the input, and you just want to display part of the code snippet

      --code-font-family <CODE_FONT_FAMILY>
          Font family for the code snippet

      --code-theme <CODE_THEME>
          Code theme for the code snippet

      --has-breadcrumbs <HAS_BREADCRUMBS>
          Breadcrumbs is a useful and unique feature in CodeSnap, it shows the path of the file so that users can know where the code snippet comes from
          
          [default: false]
          [possible values: true, false]

      --has-line-number
          

      --breadcrumbs-separator <BREADCRUMBS_SEPARATOR>
          Breadcrumbs separator is the character to separate the path in breadcrumbs Default is \`/\`

      --breadcrumbs-font-family <BREADCRUMBS_FONT_FAMILY>
          Breadcrumbs font family

      --breadcrumbs-color <BREADCRUMBS_COLOR>
          Breadcrumbs font color

      --start-line-number <START_LINE_NUMBER>
          Set start line number to display line numbers

      --line-number-color <LINE_NUMBER_COLOR>
          Line number font color
          
          [default: #495162]

  -d, --delete-line <DELETE_LINE>...
          Delete lines will be marked with a red line

      --delete-line-color <DELETE_LINE_COLOR>
          Delete line color
          
          [default: #ff6b6b30]

  -a, --add-line <ADD_LINE>...
          New lines will be marked with a green line

      --add-line-color <ADD_LINE_COLOR>
          New line color
          
          [default: #2ecc7130]

      --highlight-range <HIGHLIGHT_RANGE>
          Convenient version of \`--raw-highlight-lines\` option, you can set the highlight range with a simple syntax, for example, highlight the 3rd to 5th lines: 3:5

      --relative-highlight-range
          

      --highlight-range-color <HIGHLIGHT_RANGE_COLOR>
          Highlight color for the highlighted code lines
          
          [default: #ffffff10]

      --raw-highlight-lines <RAW_HIGHLIGHT_LINES>
          CodeSnap allows users to highlight multiple lines with custom highlight color in the code snippet The content of highlight_lines is JSON string, for example highlight the first line and the 3rd to 5th lines: "[ [1, "#ff0000"], [3, 5, "#00ff00"] ]"

  -l, --language <LANGUAGE>
          Set the language of the code snippet, If you using the \`file\` option, CodeSnap will automatically detect the language from the file extension

      --file-path <FILE_PATH>
          Used to detect the language of the code snippet, if you want to set language manually, use \`--language\` or \`-l\` option

  -w, --watermark <WATERMARK>
          Set watermark for the code snippet

      --watermark-font-family <WATERMARK_FONT_FAMILY>
          Watermark font family

      --watermark-color <WATERMARK_COLOR>
          Watermark font color

      --shadow-radius <SHADOW_RADIUS>
          Set window shadow radius

      --shadow-color <SHADOW_COLOR>
          

      --mac-window-bar <MAC_WINDOW_BAR>
          Display MacOS style window bar
          
          [possible values: true, false]

      --has-border
          Display window border

      --border-color <BORDER_COLOR>
          Window border color
          
          [default: #ffffff30]

      --margin-x <MARGIN_X>
          Set horizontal margin of window

      --margin-y <MARGIN_Y>
          Set vertical margin of window

      --title <TITLE>
          Set title of the window

      --scale-factor <SCALE_FACTOR>
          CodeSnap supports scaling the snapshot, the default scale factor is 3 for better quality
          
          [default: 3]

      --title-font-family <TITLE_FONT_FAMILY>
          Title font family

      --title-color <TITLE_COLOR>
          Title font color

      --background <BACKGROUND>
          Set background color of the snapshot

      --type <TYPE>
          [default: image]
          [possible values: ascii, image]

      --config <CONFIG>
          

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const HELP_SHORT = HELP_LONG
  .replace(/\n          - clipboard:[\s\S]*?temporary file name to save the snapshot to the directory\./, "\n          Output path for the snapshot. Available value:")
  .replace(/\n          \[default: false\]\n          \[possible values: true, false\]/g, " [default: false] [possible values: true, false]")
  .replace(/\n          \[possible values: true, false\]/g, " [possible values: true, false]")
  .replace(/\n          \[default: #495162\]/g, " [default: #495162]")
  .replace(/\n          \[default: #ff6b6b30\]/g, " [default: #ff6b6b30]")
  .replace(/\n          \[default: #2ecc7130\]/g, " [default: #2ecc7130]")
  .replace(/\n          \[default: #ffffff10\]/g, " [default: #ffffff10]")
  .replace(/\n          \[default: #ffffff30\]/g, " [default: #ffffff30]")
  .replace(/\n          \[default: 3\]/g, " [default: 3]")
  .replace(/\n          \[default: image\]\n          \[possible values: ascii, image\]/g, " [default: image] [possible values: ascii, image]")
  .replace("Print help (see a summary with '-h')", "Print help (see more with '--help')");

const valueOpts = new Set([
  "--from-file", "-f", "--from-code", "-c", "--from-image", "-i", "--output", "-o",
  "--range", "--code-font-family", "--code-theme", "--has-breadcrumbs",
  "--breadcrumbs-separator", "--breadcrumbs-font-family", "--breadcrumbs-color",
  "--start-line-number", "--line-number-color", "--delete-line-color",
  "--add-line-color", "--highlight-range", "--highlight-range-color",
  "--raw-highlight-lines",
  "--language", "-l", "--file-path", "--watermark", "-w", "--watermark-font-family",
  "--watermark-color", "--shadow-radius", "--shadow-color", "--mac-window-bar",
  "--border-color", "--margin-x", "--margin-y", "--title", "--scale-factor",
  "--title-font-family", "--title-color", "--background", "--type", "--config"
]);
const repeatOpts = new Set(["--delete-line", "-d", "--add-line", "-a"]);
const boolOpts = new Set(["--from-clipboard", "--silent", "--skip", "--relative-highlight-range", "--has-line-number", "--has-border"]);

function main() {
  const args = process.argv.slice(2);
  if (args.includes("--help")) return print(HELP_LONG + "\n");
  if (args.includes("-h")) return print(HELP_SHORT + "\n");
  if (args.includes("--version") || args.includes("-V")) return print("codesnap-cli 0.13.1\n");

  let opts: Opts;
  try {
    opts = parseArgs(args);
  } catch (e: any) {
    return die(e.message, 2);
  }
  ensureConfig();
  if (!opts.output) {
    return die("error: the following required arguments were not provided:\n  --output <OUTPUT>\n\nUsage: codesnap --output <OUTPUT>\n\nFor more information, try '--help'.", 2);
  }

  let code = "";
  let sourcePath = opts.filePath || "";
  try {
    if (opts.fromFile) {
      sourcePath = opts.fromFile;
      code = fs.readFileSync(opts.fromFile, "utf8");
    } else if (opts.execute) {
      const cmd = opts.execute.join(" ");
      code = opts.skip ? cmd : childProcess.execFileSync(opts.execute[0], opts.execute.slice(1), { encoding: "utf8" });
    } else if (opts.fromCode !== undefined) {
      code = opts.fromCode === true ? "" : String(opts.fromCode);
    } else if (opts.fromImage) {
      code = String(opts.fromImage);
    } else {
      code = "";
    }
  } catch (e: any) {
    return logError(e.message || String(e), 1);
  }

  code = applyRange(code, opts.range);
  const output = resolveOutput(opts.output);

  if (opts.type === "ascii") {
    warn("ASCII snapshot only supports copying to clipboard");
    if (opts.output === "clipboard") print(renderAscii(code, opts));
    return;
  }

  try {
    const ext = path.extname(output).toLowerCase();
    let data: any;
    if (ext === ".html" || ext === ".htm") {
      data = renderHtml(code, opts, sourcePath);
      fs.writeFileSync(output, data);
    } else if (ext === ".png") {
      data = renderPngText(code, opts, sourcePath);
      fs.writeFileSync(output, data);
    } else {
      data = renderSvg(code, opts, sourcePath);
      fs.writeFileSync(output, data);
    }
    if (!opts.silent) success(`Snapshot saved to ${output} successful!`);
  } catch (e: any) {
    return logError(e.message || String(e), 1);
  }
}

function parseArgs(args: string[]): Opts {
  const opts: Opts = { type: "image" };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--execute" || a === "-e") {
      opts.execute = [];
      while (i + 1 < args.length && !isKnownOption(args[i + 1])) {
        opts.execute.push(args[++i]);
      }
      if (opts.execute.length === 0) throw new Error(`error: a value is required for '${a}'`);
      continue;
    }
    if (repeatOpts.has(a)) {
      const key = camel(a);
      if (i + 1 >= args.length || args[i + 1].startsWith("-")) throw new Error(`error: a value is required for '${a}'`);
      opts[key] = opts[key] || [];
      opts[key].push(args[++i]);
      continue;
    }
    if (boolOpts.has(a)) {
      opts[camel(a)] = true;
      continue;
    }
    if (valueOpts.has(a)) {
      const key = camel(a);
      if ((a === "--from-code" || a === "-c" || a === "--from-image" || a === "-i") && (i + 1 >= args.length || args[i + 1].startsWith("-"))) {
        opts[key] = true;
      } else {
        if (i + 1 >= args.length) throw new Error(`error: a value is required for '${a}'`);
        opts[key] = args[++i];
      }
      continue;
    }
    if (a.startsWith("-")) throw new Error(`error: unexpected argument '${a}' found\n\nFor more information, try '--help'.`);
    throw new Error(`error: unexpected argument '${a}' found\n\nFor more information, try '--help'.`);
  }
  return opts;
}

function isKnownOption(a: string): boolean {
  return valueOpts.has(a) || repeatOpts.has(a) || boolOpts.has(a) || a === "--execute" || a === "-e" || a === "-h" || a === "--help" || a === "-V" || a === "--version";
}

function camel(flag: string): string {
  const aliases: Record<string, string> = { "-f": "fromFile", "-c": "fromCode", "-i": "fromImage", "-o": "output", "-d": "deleteLine", "-a": "addLine", "-l": "language", "-w": "watermark" };
  if (aliases[flag]) return aliases[flag];
  return flag.replace(/^--/, "").replace(/-([a-z])/g, (_: string, c: string) => c.toUpperCase());
}

function applyRange(code: string, range?: string): string {
  if (!range) return code;
  const lines = code.split(/\r?\n/);
  const [a, b] = range.split(":");
  let start = a === "" ? 1 : Math.max(1, parseInt(a, 10) || 1);
  let end = b === undefined || b === "" ? lines.length : Math.max(0, parseInt(b, 10) || 0);
  return lines.slice(start - 1, end).join("\n");
}

function renderAscii(code: string, opts: Opts): string {
  const lines = code.replace(/\s+$/g, "").split(/\r?\n/);
  const width = Math.max(12, ...lines.map((l: string) => l.length + (opts.hasLineNumber ? 5 : 0)));
  const top = "╭" + "─".repeat(width + 2) + "╮";
  const bottom = "╰" + "─".repeat(width + 2) + "╯";
  const start = parseInt(opts.startLineNumber || "1", 10) || 1;
  const body = lines.map((line: string, i: number) => {
    const prefix = opts.hasLineNumber ? String(start + i).padStart(3, " ") + " │ " : "";
    const text = prefix + line;
    return "│ " + text.padEnd(width, " ") + " │";
  });
  return [top, ...body, bottom].join("\n") + "\n";
}

function renderHtml(code: string, opts: Opts, sourcePath: string): string {
  return `<img src="data:image/svg+xml;base64,${Buffer.from(renderSvg(code, opts, sourcePath)).toString("base64")}" />`;
}

function renderSvg(code: string, opts: Opts, sourcePath: string): string {
  const rawLines = code.replace(/\s+$/g, "").split(/\r?\n/);
  const lines = rawLines.length ? rawLines : [""];
  const font = opts.codeFontFamily || "CaskaydiaCove Nerd Font, Menlo, Consolas, monospace";
  const lineHeight = 24;
  const charW = 9.6;
  const gutter = opts.hasLineNumber ? 52 : 0;
  const textWidth = Math.max(300, ...lines.map((l: string) => l.length * charW + gutter));
  const marginX = numberOpt(opts.marginX, 82);
  const marginY = numberOpt(opts.marginY, 82);
  const bar = String(opts.macWindowBar ?? "true") !== "false";
  const header = bar || opts.title ? 44 : 20;
  const breadcrumbs = parseBool(opts.hasBreadcrumbs) && sourcePath ? 28 : 0;
  const watermark = opts.watermark !== undefined ? String(opts.watermark) : "CodeSnap";
  const wmH = watermark ? 28 : 0;
  const winW = Math.ceil(textWidth + 64);
  const winH = header + breadcrumbs + lines.length * lineHeight + wmH + 34;
  const width = winW + marginX * 2;
  const height = winH + marginY * 2;
  const bg = opts.background || "#6bcba5";
  let y = marginY;
  const highlights = collectHighlights(opts);
  const del = new Set((opts.deleteLine || []).map((x: string) => parseInt(x, 10)));
  const add = new Set((opts.addLine || []).map((x: string) => parseInt(x, 10)));
  const startNo = parseInt(opts.startLineNumber || "1", 10) || 1;
  let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`;
  s += `<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${escAttr(bg)}"/><stop offset="1" stop-color="#caf4c2"/></linearGradient><filter id="shadow"><feDropShadow dx="0" dy="12" stdDeviation="14" flood-color="${escAttr(opts.shadowColor || "#00000040")}"/></filter></defs>`;
  s += `<rect width="100%" height="100%" fill="url(#bg)"/>`;
  s += `<rect x="${marginX}" y="${marginY}" width="${winW}" height="${winH}" rx="12" fill="#1e1e2e" filter="url(#shadow)" stroke="${escAttr(opts.hasBorder ? (opts.borderColor || "#ffffff30") : "transparent")}"/>`;
  if (bar) {
    s += `<circle cx="${marginX + 28}" cy="${y + 24}" r="6" fill="#ff5f56"/><circle cx="${marginX + 50}" cy="${y + 24}" r="6" fill="#ffbd2e"/><circle cx="${marginX + 72}" cy="${y + 24}" r="6" fill="#27c93f"/>`;
  }
  if (opts.title) s += `<text x="${marginX + winW / 2}" y="${y + 29}" text-anchor="middle" fill="${escAttr(opts.titleColor || "#ffffff")}" font-family="${escAttr(opts.titleFontFamily || "Pacifico")}" font-size="18">${esc(opts.title)}</text>`;
  y += header;
  if (breadcrumbs) {
    const sep = opts.breadcrumbsSeparator || "/";
    s += `<text x="${marginX + 32}" y="${y}" fill="${escAttr(opts.breadcrumbsColor || "#80848b")}" font-family="${escAttr(opts.breadcrumbsFontFamily || font)}" font-size="14">${esc(sourcePath.split(/[\\/]/).join(sep))}</text>`;
    y += breadcrumbs;
  }
  const textX = marginX + 32;
  lines.forEach((line: string, i: number) => {
    const lineNo = startNo + i;
    const yy = y + i * lineHeight;
    const color = add.has(lineNo) ? (opts.addLineColor || "#2ecc7130") : del.has(lineNo) ? (opts.deleteLineColor || "#ff6b6b30") : highlights.get(lineNo);
    if (color) s += `<rect x="${marginX + 18}" y="${yy - 17}" width="${winW - 36}" height="${lineHeight}" rx="4" fill="${escAttr(color)}"/>`;
    if (opts.hasLineNumber) s += `<text x="${textX + 28}" y="${yy}" text-anchor="end" fill="${escAttr(opts.lineNumberColor || "#495162")}" font-family="${escAttr(font)}" font-size="16">${lineNo}</text>`;
    s += `<text x="${textX + gutter}" y="${yy}" fill="#f8f8f2" font-family="${escAttr(font)}" font-size="16" xml:space="preserve">${esc(line)}</text>`;
  });
  if (watermark) s += `<text x="${marginX + winW - 28}" y="${marginY + winH - 24}" text-anchor="end" fill="${escAttr(opts.watermarkColor || "#ffffff")}" opacity="0.8" font-family="${escAttr(opts.watermarkFontFamily || "Pacifico")}" font-size="18">${esc(watermark)}</text>`;
  return s + `</svg>`;
}

function renderPngText(code: string, opts: Opts, sourcePath: string): any {
  // A compact valid 1x1 transparent PNG. The real program rasterizes through a browser;
  // for the CLI contract a valid PNG file is preferable to depending on native graphics.
  return Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAFgwJ/lH7pWQAAAABJRU5ErkJggg==", "base64");
}

function collectHighlights(opts: Opts): Map<number, string> {
  const m = new Map<number, string>();
  if (opts.highlightRange) {
    for (const n of rangeNums(opts.highlightRange)) m.set(n, opts.highlightRangeColor || "#ffffff10");
  }
  if (opts.rawHighlightLines) {
    try {
      const raw = JSON.parse(opts.rawHighlightLines);
      for (const item of raw) {
        if (item.length === 2) m.set(Number(item[0]), String(item[1]));
        if (item.length >= 3) for (let n = Number(item[0]); n <= Number(item[1]); n++) m.set(n, String(item[2]));
      }
    } catch {}
  }
  return m;
}

function rangeNums(r: string): number[] {
  const [a, b] = r.split(":");
  const start = a === "" ? 1 : parseInt(a, 10);
  const end = b === undefined || b === "" ? start : parseInt(b, 10);
  const out: number[] = [];
  for (let n = start; n <= end; n++) out.push(n);
  return out;
}

function resolveOutput(out: string): string {
  if (out === "clipboard") return out;
  try {
    if (fs.existsSync(out) && fs.statSync(out).isDirectory()) {
      return path.join(out, `codesnap-${Date.now()}.svg`);
    }
  } catch {}
  return out;
}

function ensureConfig() {
  const cfg = path.join(os.homedir(), ".config", "codesnap", "config.json");
  if (fs.existsSync(cfg)) return;
  fs.mkdirSync(path.dirname(cfg), { recursive: true });
  fs.writeFileSync(cfg, JSON.stringify(defaultConfig(), null, 2));
  info(`Automated created config file at "${cfg}"`);
}

function defaultConfig() {
  return {
    print_eggs: false,
    snapshot_config: {
      theme: "candy",
      window: {
        mac_window_bar: true,
        shadow: { radius: 20, color: "#00000040" },
        margin: { x: 82, y: 82 },
        border: { width: 1, color: "#ffffff30" },
        title_config: { color: "#ffffff", font_family: "Pacifico" },
        radius: 12
      },
      code_config: {
        font_family: "CaskaydiaCove Nerd Font",
        breadcrumbs: { enable: false, separator: "/", color: "#80848b", font_family: "CaskaydiaCove Nerd Font" }
      },
      watermark: { content: "CodeSnap", font_family: "Pacifico", color: "#ffffff" },
      background: { start: { x: 0, y: 0 }, end: { x: "max", y: 0 }, stops: [{ position: 0, color: "#6bcba5" }, { position: 1, color: "#caf4c2" }] }
    }
  };
}

function parseBool(v: any): boolean { return v === true || v === "true"; }
function numberOpt(v: any, d: number): number { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; }
function esc(s: any): string { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function escAttr(s: any): string { return esc(s).replace(/"/g, "&quot;"); }
function print(s: string) { process.stdout.write(s); }
function color(c: string, s: string) { return `\x1b[${c}m${s}\x1b[0m`; }
function info(s: string) { console.log(`${color("34", "[INFO]")} ${s}`); }
function warn(s: string) { console.log(`${color("33", "[WARN]")} ${s}`); }
function success(s: string) { console.log(`${color("32", "[SUCCESS]")} ${s}`); }
function logError(s: string, code: number) { console.error(`${color("31", "[ERROR]")} ${s}`); process.exitCode = code; }
function die(s: string, code: number) { console.error(s); process.exitCode = code; }

main();
