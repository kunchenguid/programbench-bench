declare const require: any;
declare const process: any;

const cp = require("child_process");

type Run = { ok: boolean; code: number; stdout: string; stderr: string };
type Branch = { name: string; oid: string; upstream: string; upstreamGone: boolean };
type RemoteBranch = { remote: string; branch: string; short: string; oid: string };
type DeleteSpec = { kind: string; remote?: string };

const HELP_SHORT = `Automatically trims your tracking branches whose upstream branches are merged or stray.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks \`git symbolic-ref refs/remotes/*/HEAD\`] [config: trim.bases]
  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. \`release-*\`, \`feature/*\`) of branches that should never be deleted. [config: trim.protected]
      --no-update
          Do not update remotes [config: trim.update]
      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]
      --no-confirm
          Do not ask confirm [config: trim.confirm]
      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]
  -d, --delete <DELETE>
          Comma separated values of \`<delete range>[:<remote name>]\`. Delete range is one of the \`merged, merged-local, merged-remote, stray, diverged, local, remote\`. \`:<remote name>\` is only necessary to a \`<delete range>\` when the range is applied to remote branches. You can use \`*\` as \`<remote name>\` to delete a range of branches from all remotes. [default : \`merged:origin\`] [config: trim.delete]
      --dry-run
          Do not delete branches, show what branches will be deleted
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version`;

const HELP_LONG = `Automatically trims your tracking branches whose upstream branches are merged or stray.
\`git-trim\` is a missing companion to the \`git fetch --prune\` and a proper, safer, faster alternative to your \`<bash oneliner HERE>\`.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks \`git symbolic-ref refs/remotes/*/HEAD\`] [config: trim.bases]
          
          The default value is a branch that tracks \`git symbolic-ref refs/remotes/*/HEAD\`. They might not be reflected correctly when the HEAD branch of your remote repository is changed. You can see the changed HEAD branch name with \`git remote show <remote>\` and apply it to your local repository with \`git remote set-head <remote> --auto\`.

  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. \`release-*\`, \`feature/*\`) of branches that should never be deleted. [config: trim.protected]

      --no-update
          Do not update remotes [config: trim.update]

      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]

      --no-confirm
          Do not ask confirm [config: trim.confirm]

      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]

  -d, --delete <DELETE>
          Comma separated values of \`<delete range>[:<remote name>]\`. Delete range is one of the \`merged, merged-local, merged-remote, stray, diverged, local, remote\`. \`:<remote name>\` is only necessary to a \`<delete range>\` when the range is applied to remote branches. You can use \`*\` as \`<remote name>\` to delete a range of branches from all remotes. [default : \`merged:origin\`] [config: trim.delete]
          
          \`merged\` implies \`merged-local,merged-remote\`.
          
          \`merged-local\` will delete merged tracking local branches. \`merged-remote:<remote>\` will delete merged upstream branches from \`<remote>\`. \`stray\` will delete tracking local branches, which is not merged, but the upstream is gone. \`diverged:<remote>\` will delete merged tracking local branches, and their upstreams from \`<remote>\` even if the upstreams are not merged and diverged from local ones. \`local\` will delete non-tracking merged local branches. \`remote:<remote>\` will delete non-upstream merged remote tracking branches. Use with caution when you are using other than \`merged\`. It might lose changes, and even nuke repositories.

      --dry-run
          Do not delete branches, show what branches will be deleted

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

function run(args: string[], input?: string): Run {
  const r = cp.spawnSync(args[0], args.slice(1), { encoding: "utf8", input });
  return { ok: r.status === 0, code: r.status ?? 1, stdout: r.stdout || "", stderr: r.stderr || "" };
}

function git(args: string[], input?: string): Run {
  return run(["git", ...args], input);
}

function gitOut(args: string[]): string {
  const r = git(args);
  if (!r.ok) throw new Error((r.stderr || r.stdout).trim());
  return r.stdout;
}

function config(name: string): string {
  const r = git(["config", "--get", name]);
  return r.ok ? r.stdout.trim() : "";
}

function boolConfig(name: string, def: boolean): boolean {
  const v = config(name).toLowerCase();
  if (!v) return def;
  if (["false", "0", "no", "off"].includes(v)) return false;
  if (["true", "1", "yes", "on"].includes(v)) return true;
  return def;
}

function splitCsv(s: string): string[] {
  return s.split(",").map(x => x.trim()).filter(Boolean);
}

function dieCli(msg: string): never {
  process.stderr.write(msg + "\n\nFor more information, try '--help'.\n");
  process.exit(2);
  throw new Error(msg);
}

function parseArgs(argv: string[]) {
  const opt: any = {
    bases: "",
    protected: "",
    update: undefined,
    updateInterval: undefined,
    confirm: undefined,
    detach: undefined,
    delete: "",
    dryRun: false,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const take = (long: string): string => {
      if (a.includes("=")) return a.slice(a.indexOf("=") + 1);
      if (i + 1 >= argv.length || argv[i + 1].startsWith("-")) dieCli(`error: a value is required for '${long} <${long.toUpperCase().replace(/^--/, "")}>' but none was supplied`);
      return argv[++i];
    };
    if (a === "-h") { console.log(HELP_SHORT); process.exit(0); }
    else if (a === "--help") { console.log(HELP_LONG); process.exit(0); }
    else if (a === "-V" || a === "--version") { console.log("git-trim 0.4.4"); process.exit(0); }
    else if (a === "-b" || a === "--bases" || a.startsWith("--bases=")) opt.bases = take("--bases");
    else if (a === "-p" || a === "--protected" || a.startsWith("--protected=")) opt.protected = take("--protected");
    else if (a === "-d" || a === "--delete" || a.startsWith("--delete=")) opt.delete = take("--delete");
    else if (a === "--update-interval" || a.startsWith("--update-interval=")) {
      const v = take("--update-interval");
      if (!/^\d+$/.test(v)) dieCli(`error: invalid value '${v}' for '--update-interval <UPDATE_INTERVAL>': invalid digit found in string`);
      opt.updateInterval = Number(v);
    } else if (a === "--no-update") opt.update = false;
    else if (a === "--update") opt.update = true;
    else if (a === "--no-confirm") opt.confirm = false;
    else if (a === "--confirm") opt.confirm = true;
    else if (a === "--no-detach") opt.detach = false;
    else if (a === "--detach") opt.detach = true;
    else if (a === "--dry-run") opt.dryRun = true;
    else dieCli(`error: unexpected argument '${a}' found`);
  }
  return opt;
}

function parseDelete(s: string): DeleteSpec[] {
  const out: DeleteSpec[] = [];
  for (const part of splitCsv(s || "merged:origin")) {
    const [kind, remote] = part.split(":", 2);
    if (!["merged", "merged-local", "merged-remote", "stray", "diverged", "local", "remote"].includes(kind)) {
      dieCli(`error: invalid value '${part}' for '--delete <DELETE>'`);
    }
    if (kind === "merged") {
      out.push({ kind: "merged-local" }, { kind: "merged-remote", remote: remote || "origin" });
    } else {
      out.push({ kind, remote });
    }
  }
  return out;
}

function listLocal(): Branch[] {
  const s = gitOut(["for-each-ref", "--format=%(refname:short)%00%(objectname)%00%(upstream:short)%00%(upstream:track)", "refs/heads"]);
  return s.trimEnd().split("\n").filter(Boolean).map(line => {
    const [name, oid, upstream, track] = line.split("\0");
    return { name, oid, upstream: upstream || "", upstreamGone: (track || "").includes("gone") };
  });
}

function listRemote(): RemoteBranch[] {
  const s = gitOut(["for-each-ref", "--format=%(refname:short)%00%(objectname)", "refs/remotes"]);
  return s.trimEnd().split("\n").filter(Boolean).map(line => {
    const [short, oid] = line.split("\0");
    const slash = short.indexOf("/");
    return { remote: short.slice(0, slash), branch: short.slice(slash + 1), short, oid };
  }).filter(b => b.branch !== "HEAD");
}

function remoteHeads(): string[] {
  const s = gitOut(["for-each-ref", "--format=%(refname:short)%00%(symref)", "refs/remotes"]);
  const heads: string[] = [];
  for (const line of s.trimEnd().split("\n").filter(Boolean)) {
    const [short, sym] = line.split("\0");
    if (short.endsWith("/HEAD") && sym.startsWith("refs/remotes/")) heads.push(sym.replace("refs/remotes/", ""));
  }
  return heads;
}

function isAncestor(a: string, b: string): boolean {
  if (!a || !b) return false;
  return git(["merge-base", "--is-ancestor", a, b]).ok;
}

function globToRe(pat: string): RegExp {
  let s = "^";
  for (const ch of pat) {
    if (ch === "*") s += ".*";
    else if (ch === "?") s += ".";
    else s += ch.replace(/[|\\{}()[\]^$+?.]/g, "\\$&");
  }
  return new RegExp(s + "$");
}

function uniq<T>(xs: T[]): T[] {
  return Array.from(new Set(xs));
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  const repo = git(["rev-parse", "--git-dir"]);
  if (!repo.ok) {
    process.stderr.write("Error: could not find repository at '.'; class=Repository (6); code=NotFound (-3)\n");
    process.exit(1);
  }

  opt.bases = opt.bases || config("trim.bases");
  opt.protected = opt.protected || config("trim.protected");
  opt.delete = opt.delete || config("trim.delete") || "merged:origin";
  opt.update = opt.update === undefined ? boolConfig("trim.update", true) : opt.update;
  opt.confirm = opt.confirm === undefined ? boolConfig("trim.confirm", true) : opt.confirm;
  opt.detach = opt.detach === undefined ? boolConfig("trim.detach", true) : opt.detach;
  opt.updateInterval = opt.updateInterval === undefined ? Number(config("trim.updateInterval") || "5") : opt.updateInterval;

  if (opt.update) {
    git(["fetch", "--all", "--prune"]);
  }

  const locals = listLocal();
  const remotes = listRemote();
  let bases = splitCsv(opt.bases);
  if (!bases.length) {
    const heads = remoteHeads();
    bases = locals.filter(l => heads.includes(l.upstream)).map(l => l.name);
  }
  if (!bases.length) {
    process.stderr.write("I can't detect base branch! Try following any resolution:\n");
    process.stderr.write(" * `git remote set-head origin --auto` will help `git-trim` to automatically\n");
    process.stderr.write("   detect the base branch.\n");
    process.stderr.write("   If you see `origin/HEAD set to <base branch>` in the output of the previous\n");
    process.stderr.write("   command, then `git branch --set-upstream origin/<base branch> <base branch>`\n");
    process.stderr.write("   to set an upstream branch for <base branch> if exists.\n");
    process.stderr.write("You also can set bases manually with any of following commands:\n");
    process.stderr.write(" * `git config trim.bases develop,master` for a repository.\n");
    process.stderr.write(" * `git config --global trim.bases develop,master` to set globally.\n");
    process.stderr.write(" * `git trim --bases develop,master` to set temporarily.\n");
    process.stderr.write("Error: No base branch is found!\n");
    process.exit(1);
  }

  const baseSet = new Set(bases);
  const localMap = new Map(locals.map(b => [b.name, b]));
  const remoteMap = new Map(remotes.map(b => [b.short, b]));
  const baseTargets = bases.map(b => localMap.get(b)?.upstream || b).filter(Boolean);
  const prot = splitCsv(opt.protected).map(globToRe);
  const specs = parseDelete(opt.delete);
  const specHas = (kind: string, remote?: string) => specs.some(s => s.kind === kind && (remote === undefined || !s.remote || s.remote === remote || s.remote === "*"));
  const isProtected = (name: string) => baseSet.has(name) || prot.some(r => r.test(name));
  const mergedToBase = (ref: string) => baseTargets.some(b => isAncestor(ref, b));
  const localByUpstream = new Map<string, Branch[]>();
  for (const l of locals) if (l.upstream) localByUpstream.set(l.upstream, [...(localByUpstream.get(l.upstream) || []), l]);

  const delLocal = new Map<string, string>();
  const delRemote = new Map<string, RemoteBranch>();

  for (const l of locals) {
    if (isProtected(l.name)) continue;
    const upstreamExists = l.upstream && remoteMap.has(l.upstream);
    if (l.upstream && !upstreamExists && l.upstreamGone && specHas("stray")) delLocal.set(l.name, "stray");
    if (l.upstream && upstreamExists && mergedToBase(l.name) && specHas("merged-local")) delLocal.set(l.name, "merged");
    if (!l.upstream && mergedToBase(l.name) && specHas("local")) delLocal.set(l.name, "local");
  }

  for (const r of remotes) {
    if (baseTargets.includes(r.short)) continue;
    if (isProtected(r.branch) || isProtected(r.short)) continue;
    if (mergedToBase(r.short) && specHas("merged-remote", r.remote)) delRemote.set(r.short, r);
    if (mergedToBase(r.short) && !localByUpstream.has(r.short) && specHas("remote", r.remote)) delRemote.set(r.short, r);
  }

  for (const s of specs.filter(x => x.kind === "diverged")) {
    for (const l of locals) {
      if (isProtected(l.name) || !l.upstream || !mergedToBase(l.name)) continue;
      const rb = remoteMap.get(l.upstream);
      if (rb && (!s.remote || s.remote === "*" || rb.remote === s.remote)) {
        delLocal.set(l.name, "diverged");
        delRemote.set(rb.short, rb);
      }
    }
  }

  const remainLocals = locals.filter(l => !delLocal.has(l.name));
  const remainRemotes = remotes.filter(r => !delRemote.has(r.short));

  if (remainLocals.length || remainRemotes.length) {
    console.log("Branches that will remain:");
    if (remainLocals.length) {
      console.log("  local branches:");
      for (const l of remainLocals.sort((a,b) => a.name.localeCompare(b.name))) {
        let tag = "";
        if (baseSet.has(l.name)) tag = " [base]";
        else if (l.upstreamGone) tag = " [stray, but: delete range `stray` was not given]";
        console.log(`    ${l.name}${tag}`);
      }
    }
    if (remainRemotes.length) {
      console.log("  remote references:");
      for (const r of remainRemotes.sort((a,b) => a.short.localeCompare(b.short))) {
        const tag = baseTargets.includes(r.short) ? " [base]" : "";
        console.log(`    ${r.short}${tag}`);
      }
    }
    console.log("");
  }

  const localsByReason = (reason: string) => Array.from(delLocal.entries()).filter(([,r]) => r === reason).map(([n]) => n).sort();
  const printLocal = (title: string, ns: string[]) => { if (ns.length) { console.log(title); ns.forEach(n => console.log(`  - ${n}`)); } };
  printLocal("Delete merged local branches:", localsByReason("merged"));
  const rlist = Array.from(delRemote.values()).sort((a,b) => a.short.localeCompare(b.short));
  if (rlist.length) {
    console.log("Delete merged remote refs:");
    rlist.forEach(r => console.log(`  - ${r.remote}, refs/heads/${r.branch}`));
  }
  printLocal("Delete stray local branches:", localsByReason("stray"));
  printLocal("Delete non-tracking local branches:", localsByReason("local"));
  printLocal("Delete diverged local branches:", localsByReason("diverged"));

  const allDelLocal = Array.from(delLocal.keys()).sort();
  if (!allDelLocal.length && !rlist.length) return;

  if (!opt.dryRun && opt.confirm) {
    process.stdout.write("Do you want to delete these branches? [y/N] ");
    const input = require("fs").readFileSync(0, "utf8").trim().toLowerCase();
    if (input !== "y" && input !== "yes") return;
  }

  const current = git(["branch", "--show-current"]).stdout.trim();
  if (current && delLocal.has(current) && opt.detach && !opt.dryRun) git(["checkout", "--detach"]);

  for (const r of rlist) {
    const args = ["push"];
    if (opt.dryRun) args.push("--dry-run");
    args.push(r.remote, "--delete", r.branch);
    const res = git(args);
    process.stdout.write(res.stdout);
    process.stderr.write(res.stderr);
  }
  for (const n of allDelLocal) {
    if (opt.dryRun) console.log(`Delete branch ${n} (dry run).`);
    else {
      const res = git(["branch", "-D", n]);
      process.stdout.write(res.stdout);
      process.stderr.write(res.stderr);
      if (!res.ok) process.exitCode = 1;
    }
  }
}

try {
  main();
} catch (e: any) {
  process.stderr.write(`Error: ${e.message || String(e)}\n`);
  process.exit(1);
}
