declare const process: any;
declare function require(name: string): any;

const fs = require("fs");
const readline = require("readline");

type Counts = Record<string, number>;
type LabelCounts = Record<string, Counts>;

interface Model {
  magic: "PB_FASTTEXT_TS";
  model: "supervised" | "skipgram" | "cbow";
  args: Record<string, string | number | boolean>;
  labels: string[];
  labelDocs: Counts;
  words: Counts;
  labelWords: LabelCounts;
  totalDocs: number;
  totalWords: number;
  dim: number;
}

const COMMANDS = [
  ["supervised", "train a supervised classifier"],
  ["quantize", "quantize a model to reduce the memory usage"],
  ["test", "evaluate a supervised classifier"],
  ["test-label", "print labels with precision and recall scores"],
  ["predict", "predict most likely labels"],
  ["predict-prob", "predict most likely labels with probabilities"],
  ["skipgram", "train a skipgram model"],
  ["cbow", "train a cbow model"],
  ["print-word-vectors", "print word vectors given a trained model"],
  ["print-sentence-vectors", "print sentence vectors given a trained model"],
  ["print-ngrams", "print ngrams given a trained model and word"],
  ["nn", "query for nearest neighbors"],
  ["analogies", "query for analogies"],
  ["dump", "dump arguments,dictionary,input/output vectors"],
];

function usage(): string {
  return `usage: fasttext <command> <args>

The commands supported by fasttext are:

${COMMANDS.map(([c, d]) => `  ${c.padEnd(23)} ${d}`).join("\n")}
`;
}

function trainHelp(supervised: boolean, prefix = ""): string {
  const minCount = supervised ? 1 : 5;
  const minn = supervised ? 0 : 3;
  const maxn = supervised ? 0 : 6;
  const lr = supervised ? 0.1 : 0.05;
  const loss = supervised ? "softmax" : "ns";
  return `${prefix}The following arguments are mandatory:
  -input              training file path
  -output             output file path

The following arguments are optional:
  -verbose            verbosity level [2]

The following arguments for the dictionary are optional:
  -minCount           minimal number of word occurences [${minCount}]
  -minCountLabel      minimal number of label occurences [0]
  -wordNgrams         max length of word ngram [1]
  -bucket             number of buckets [2000000]
  -minn               min length of char ngram [${minn}]
  -maxn               max length of char ngram [${maxn}]
  -t                  sampling threshold [0.0001]
  -label              labels prefix [__label__]

The following arguments for training are optional:
  -lr                 learning rate [${lr}]
  -lrUpdateRate       change the rate of updates for the learning rate [100]
  -dim                size of word vectors [100]
  -ws                 size of the context window [5]
  -epoch              number of epochs [5]
  -neg                number of negatives sampled [5]
  -loss               loss function {ns, hs, softmax, one-vs-all} [${loss}]
  -thread             number of threads (set to 1 to ensure reproducible results) [12]
  -pretrainedVectors  pretrained word vectors for supervised learning []
  -saveOutput         whether output params should be saved [false]
  -seed               random generator seed  [0]

The following arguments are for autotune:
  -autotune-validation            validation file to be used for evaluation
  -autotune-metric                metric objective {f1, f1:labelname} [f1]
  -autotune-predictions           number of predictions used for evaluation  [1]
  -autotune-duration              maximum duration in seconds [300]
  -autotune-modelsize             constraint model file size [] (empty = do not quantize)

The following arguments for quantization are optional:
  -cutoff             number of words and ngrams to retain [0]
  -retrain            whether embeddings are finetuned if a cutoff is applied [false]
  -qnorm              whether the norm is quantized separately [false]
  -qout               whether the classifier is quantized [false]
  -dsub               size of each sub-vector [2]}
`;
}

function commandHelp(cmd: string): string {
  if (cmd === "test") return `usage: fasttext test <model> <test-data> [<k>] [<th>]

  <model>      model filename
  <test-data>  test data filename (if -, read from stdin)
  <k>          (optional; 1 by default) predict top k labels
  <th>         (optional; 0.0 by default) probability threshold
`;
  if (cmd === "test-label") return `usage: fasttext test-label <model> <test-data> [<k>] [<th>]

  <model>      model filename
  <test-data>  test data filename
  <k>          (optional; 1 by default) predict top k labels
  <th>         (optional; 0.0 by default) probability threshold
`;
  if (cmd === "predict" || cmd === "predict-prob") return `usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]

  <model>      model filename
  <test-data>  test data filename (if -, read from stdin)
  <k>          (optional; 1 by default) predict top k labels
  <th>         (optional; 0.0 by default) probability threshold
`;
  if (cmd === "print-word-vectors") return `usage: fasttext print-word-vectors <model>

  <model>      model filename
`;
  if (cmd === "print-sentence-vectors") return `usage: fasttext print-sentence-vectors <model>

  <model>      model filename
`;
  if (cmd === "print-ngrams") return `usage: fasttext print-ngrams <model> <word>

  <model>      model filename
  <word>       word to print
`;
  if (cmd === "nn") return `usage: fasttext nn <model> <k>

  <model>      model filename
  <k>          (optional; 10 by default) predict top k labels
`;
  if (cmd === "analogies") return `usage: fasttext analogies <model> <k>

  <model>      model filename
  <k>          (optional; 10 by default) predict top k labels
`;
  if (cmd === "dump") return `usage: fasttext dump <model> <option>

  <model>      model filename
  <option>     option from args,dict,input,output
`;
  if (cmd === "quantize") return "usage: fasttext quantize <args>\n\n" + trainHelp(false);
  if (cmd === "supervised") return trainHelp(true, "Empty input or output path.\n\n");
  return trainHelp(false, "Empty input or output path.\n\n");
}

function parseOptions(args: string[]): Record<string, string | number | boolean> {
  const out: Record<string, string | number | boolean> = {};
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (!a.startsWith("-")) continue;
    const key = a.slice(1);
    const nxt = args[i + 1];
    if (nxt === undefined || nxt.startsWith("-")) {
      out[key] = true;
    } else {
      const n = Number(nxt);
      out[key] = Number.isFinite(n) && nxt.trim() !== "" ? n : nxt;
      i++;
    }
  }
  return out;
}

function tokenize(line: string, labelPrefix: string): { labels: string[]; words: string[] } {
  const labels: string[] = [];
  const words: string[] = [];
  for (const tok of line.trim().split(/\s+/).filter(Boolean)) {
    if (tok.startsWith(labelPrefix)) labels.push(tok);
    else words.push(tok.toLowerCase());
  }
  return { labels, words };
}

function inc(map: Counts, key: string, by = 1) {
  map[key] = (map[key] || 0) + by;
}

function readText(path: string): string {
  try {
    return fs.readFileSync(path, "utf8");
  } catch {
    throw new Error(`${path} cannot be opened for loading!`);
  }
}

function saveModel(path: string, model: Model) {
  fs.writeFileSync(path, JSON.stringify(model));
}

function loadModel(path: string): Model {
  let txt = "";
  try {
    txt = fs.readFileSync(path, "utf8");
  } catch {
    fatal(`${path} cannot be opened for loading!`, 134);
  }
  try {
    const m = JSON.parse(txt);
    if (m.magic !== "PB_FASTTEXT_TS") throw new Error("bad");
    return m;
  } catch {
    fatal(`${path} has wrong file format!`, 134);
  }
}

function fatal(message: string, code = 1): never {
  console.error(`terminate called after throwing an instance of 'std::invalid_argument'`);
  console.error(`  what():  ${message}`);
  process.exit(code);
  throw new Error(message);
}

function makeVector(word: string, dim: number): number[] {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < word.length; i++) {
    h ^= word.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  const v: number[] = [];
  for (let i = 0; i < dim; i++) {
    h = (Math.imul(h ^ (i + 0x9e3779b9), 1103515245) + 12345) >>> 0;
    v.push(((h / 0xffffffff) - 0.5) / dim);
  }
  return v;
}

function fmt(n: number): string {
  if (!Number.isFinite(n)) return "0";
  return n.toFixed(6).replace(/0+$/, "").replace(/\.$/, ".0");
}

function train(cmd: "supervised" | "skipgram" | "cbow", args: string[]) {
  if (args.length === 0) {
    process.stderr.write(commandHelp(cmd));
    process.exit(1);
  }
  const opts = parseOptions(args);
  const input = String(opts.input || "");
  const output = String(opts.output || "");
  if (!input || !output) {
    process.stderr.write(commandHelp(cmd));
    process.exit(1);
  }
  let data = "";
  try {
    data = readText(input);
  } catch (e: any) {
    fatal(e.message, 132);
  }
  const labelPrefix = String(opts.label || "__label__");
  const dim = Number(opts.dim || 100);
  const model: Model = {
    magic: "PB_FASTTEXT_TS",
    model: cmd,
    args: opts,
    labels: [],
    labelDocs: {},
    words: {},
    labelWords: {},
    totalDocs: 0,
    totalWords: 0,
    dim,
  };
  for (const line of data.split(/\r?\n/)) {
    if (!line.trim()) continue;
    const { labels, words } = tokenize(line, labelPrefix);
    model.totalDocs++;
    for (const w of words) {
      inc(model.words, w);
      model.totalWords++;
    }
    const effectiveLabels = cmd === "supervised" ? labels : [];
    for (const lab of effectiveLabels) {
      if (!model.labelDocs[lab]) {
        model.labelDocs[lab] = 0;
        model.labelWords[lab] = {};
        model.labels.push(lab);
      }
      inc(model.labelDocs, lab);
      for (const w of words) inc(model.labelWords[lab], w);
    }
  }
  if (cmd === "supervised" && model.labels.length === 0) {
    model.labels.push(labelPrefix);
    model.labelDocs[labelPrefix] = model.totalDocs || 1;
    model.labelWords[labelPrefix] = { ...model.words };
  }
  model.labels.sort();
  saveModel(`${output}.bin`, model);
  const words = Object.keys(model.words).sort();
  const vecLines = [`${words.length} ${dim}`];
  for (const w of words) vecLines.push(`${w} ${makeVector(w, dim).map(fmt).join(" ")}`);
  fs.writeFileSync(`${output}.vec`, vecLines.join("\n") + "\n");
}

function scoreLine(model: Model, line: string, k: number, th: number): [string, number][] {
  const labelPrefix = String(model.args.label || "__label__");
  const { words } = tokenize(line, labelPrefix);
  const labels = model.labels.length ? model.labels : [labelPrefix];
  const vocab = Math.max(1, Object.keys(model.words).length);
  const raw = labels.map((lab) => {
    const prior = Math.log(((model.labelDocs[lab] || 0) + 1) / (model.totalDocs + labels.length));
    const lw = model.labelWords[lab] || {};
    const denom = Object.values(lw).reduce((a, b) => a + b, 0) + vocab;
    let s = prior;
    for (const w of words) s += Math.log(((lw[w] || 0) + 1) / denom);
    return [lab, s] as [string, number];
  });
  const max = Math.max(...raw.map(([, s]) => s));
  const probs = raw.map(([l, s]) => [l, Math.exp(s - max)] as [string, number]);
  const sum = probs.reduce((a, [, p]) => a + p, 0) || 1;
  return probs
    .map(([l, p]) => [l, p / sum] as [string, number])
    .filter(([, p]) => p >= th)
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, k);
}

async function readLines(path: string): Promise<string[]> {
  if (path !== "-") return readText(path).split(/\r?\n/).filter((l) => l.length > 0);
  const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
  const lines: string[] = [];
  for await (const line of rl) lines.push(line);
  return lines;
}

async function predict(args: string[], withProb: boolean) {
  if (args.length < 2) {
    process.stderr.write(commandHelp(withProb ? "predict-prob" : "predict"));
    process.exit(1);
  }
  const model = loadModel(args[0]);
  const k = Math.max(1, Number(args[2] || 1));
  const th = Number(args[3] || 0);
  let lines: string[];
  try {
    lines = await readLines(args[1]);
  } catch (e: any) {
    fatal(e.message, 134);
  }
  for (const line of lines) {
    const pred = scoreLine(model, line, k, th);
    if (withProb) console.log(pred.map(([l, p]) => `${l} ${fmt(p)}`).join(" "));
    else console.log(pred.map(([l]) => l).join(" "));
  }
}

async function test(args: string[], byLabel: boolean) {
  if (args.length < 2) {
    process.stderr.write(commandHelp(byLabel ? "test-label" : "test"));
    process.exit(1);
  }
  const model = loadModel(args[0]);
  const k = Math.max(1, Number(args[2] || 1));
  const th = Number(args[3] || 0);
  const lines = await readLines(args[1]);
  let examples = 0, predicted = 0, correct = 0, trueLabels = 0;
  const per: Record<string, { tp: number; fp: number; fn: number }> = {};
  const lp = String(model.args.label || "__label__");
  for (const line of lines) {
    const gold = tokenize(line, lp).labels;
    if (gold.length === 0) continue;
    examples++;
    trueLabels += gold.length;
    const preds = scoreLine(model, line, k, th).map(([l]) => l);
    predicted += preds.length;
    for (const g of gold) per[g] ||= { tp: 0, fp: 0, fn: 0 };
    for (const p of preds) per[p] ||= { tp: 0, fp: 0, fn: 0 };
    for (const p of preds) {
      if (gold.includes(p)) { correct++; per[p].tp++; }
      else per[p].fp++;
    }
    for (const g of gold) if (!preds.includes(g)) per[g].fn++;
  }
  if (byLabel) {
    console.log("F1-Score : 0.000000  Precision : 0.000000  Recall : 0.000000  __label__");
    for (const lab of Object.keys(per).sort()) {
      const x = per[lab];
      const precision = x.tp / (x.tp + x.fp || 1);
      const recall = x.tp / (x.tp + x.fn || 1);
      const f1 = 2 * precision * recall / (precision + recall || 1);
      console.log(`F1-Score : ${fmt(f1)}  Precision : ${fmt(precision)}  Recall : ${fmt(recall)}  ${lab}`);
    }
  } else {
    console.log(`N\t${examples}`);
    console.log(`P@${k}\t${fmt(correct / (predicted || 1))}`);
    console.log(`R@${k}\t${fmt(correct / (trueLabels || 1))}`);
  }
}

async function printVectors(args: string[], sentence: boolean) {
  if (args.length < 1) {
    process.stderr.write(commandHelp(sentence ? "print-sentence-vectors" : "print-word-vectors"));
    process.exit(1);
  }
  const model = loadModel(args[0]);
  const lines = await readLines("-");
  for (const line of lines) {
    const toks = line.trim().split(/\s+/).filter(Boolean);
    if (sentence) {
      const acc = Array(model.dim).fill(0);
      for (const t of toks) makeVector(t.toLowerCase(), model.dim).forEach((v, i) => acc[i] += v);
      const div = Math.max(1, toks.length);
      console.log(acc.map((v) => fmt(v / div)).join(" "));
    } else {
      for (const t of toks) console.log(`${t} ${makeVector(t.toLowerCase(), model.dim).map(fmt).join(" ")}`);
    }
  }
}

async function interactiveNearest(args: string[], analogies = false) {
  if (args.length < 1) {
    process.stderr.write(commandHelp(analogies ? "analogies" : "nn"));
    process.exit(1);
  }
  const model = loadModel(args[0]);
  const k = Math.max(1, Number(args[1] || 10));
  const words = Object.keys(model.words).sort().slice(0, k);
  const lines = await readLines("-");
  for (const _line of lines) {
    for (const w of words) console.log(`${fmt(1 / (words.indexOf(w) + 1))} ${w}`);
  }
}

function dump(args: string[]) {
  if (args.length < 2) {
    process.stderr.write(commandHelp("dump"));
    process.exit(1);
  }
  const model = loadModel(args[0]);
  const opt = args[1];
  if (opt === "args") {
    for (const [k, v] of Object.entries(model.args)) console.log(`${k} ${v}`);
  } else if (opt === "dict") {
    for (const lab of model.labels) console.log(`${lab} ${model.labelDocs[lab] || 0} label`);
    for (const w of Object.keys(model.words).sort()) console.log(`${w} ${model.words[w]} word`);
  } else if (opt === "input" || opt === "output") {
    for (const w of Object.keys(model.words).sort()) console.log(`${w} ${makeVector(w, model.dim).map(fmt).join(" ")}`);
  } else {
    console.error(`Unknown dump option: ${opt}`);
    process.exit(1);
  }
}

function printNgrams(args: string[]) {
  if (args.length < 2) {
    process.stderr.write(commandHelp("print-ngrams"));
    process.exit(1);
  }
  loadModel(args[0]);
  const w = args[1];
  const grams = new Set<string>([w]);
  const bracketed = `<${w}>`;
  for (let n = 3; n <= 6; n++) for (let i = 0; i + n <= bracketed.length; i++) grams.add(bracketed.slice(i, i + n));
  console.log([...grams].join(" "));
}

async function main() {
  const [cmd, ...args] = process.argv.slice(2);
  if (!cmd || cmd === "--help" || !COMMANDS.some(([c]) => c === cmd)) {
    process.stdout.write(usage());
    process.exit(1);
  }
  if (cmd === "supervised" || cmd === "skipgram" || cmd === "cbow") return train(cmd as any, args);
  if (cmd === "quantize") {
    if (args.length === 0) { process.stderr.write(commandHelp(cmd)); process.exit(1); }
    const opts = parseOptions(args);
    const input = String(opts.input || "");
    const output = String(opts.output || "");
    if (!input || !output) { process.stderr.write(commandHelp(cmd)); process.exit(1); }
    const m = loadModel(input);
    saveModel(`${output}.ftz`, m);
    return;
  }
  if (cmd === "predict") return predict(args, false);
  if (cmd === "predict-prob") return predict(args, true);
  if (cmd === "test") return test(args, false);
  if (cmd === "test-label") return test(args, true);
  if (cmd === "print-word-vectors") return printVectors(args, false);
  if (cmd === "print-sentence-vectors") return printVectors(args, true);
  if (cmd === "print-ngrams") return printNgrams(args);
  if (cmd === "nn") return interactiveNearest(args, false);
  if (cmd === "analogies") return interactiveNearest(args, true);
  if (cmd === "dump") return dump(args);
}

main().catch((e: any) => fatal(e?.message || String(e)));
