declare var require: any;
declare var process: any;
declare var Buffer: any;
declare module "fs" { const x: any; export = x; }
declare module "path" { const x: any; export = x; }
declare module "http" { const x: any; export = x; }
declare module "child_process" { export const spawnSync: any; }
