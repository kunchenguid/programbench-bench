import * as fs from "fs";
import * as path from "path";
import * as http from "http";
import { spawnSync } from "child_process";

const VERSION = "0.2.7";
const FOOTER = '<div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>';

type Config = {
  name: string; tagline: string; url: string; language: string; pagination: number;
  footer: string; content_path: string; static_path: string; media_path: string;
  default_date_format: string; enable_search: boolean; enable_related_content: boolean;
  toc: boolean; json_feed: boolean; show_next_prev_links: boolean; publish_md: boolean;
  build_sitemap: boolean; publish_urls_json: boolean; enable_shortcodes: boolean;
  pages_title: string; tags_title: string; archives_title: string; authors_title: string;
};

type Content = {
  source: string; rel: string; slug: string; url: string; title: string; html: string; text: string;
  date: Date | null; dateRaw: string; tags: string[]; authors: string[]; isPage: boolean; body: string;
};

function help(): string {
  return `Marmite is the easiest static site generator.

Usage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]

Arguments:
  <INPUT_FOLDER>   Input folder containing markdown files
  [OUTPUT_FOLDER]  Output folder to generate the site [default: \`input_folder/site\`]

Options:
  -v, --verbose...          Verbosity level (0-4)
  -w, --watch               Detect changes and rebuild the site automatically
      --serve               Serve the site with a built-in HTTP server
      --bind <BIND>         Address to bind the server [default: 0.0.0.0:8000]
  -c, --config <CONFIG>     Path to custom configuration file [default: marmite.yaml]
      --init-templates      Initialize templates in the project
      --start-theme <START_THEME>
      --set-theme <SET_THEME>
      --generate-config     Generate the configuration file
      --init-site           Init a new site with sample content and default configuration
      --force               Force the rebuild of the site even if no changes detected
      --shortcodes          List all available shortcodes
      --show-urls           Show all site URLs organized by content type
      --new <NEW>           Create a new post with the given title and open in the default editor
  -e                         Edit the file in the default editor
  -p                         Set the new content as a page
  -t <TAGS>                  Set the tags for the new content tags are comma separated
      --name <NAME>          Site name [default: "Home" or value from config file]
      --tagline <TAGLINE>    Site tagline [default: empty or value from config file]
      --url <URL>            Site url [default: empty or value from config file]
      --https <HTTPS>        If protocol is missing in the URL setting, whether to use HTTPS or not
      --footer <FOOTER>      Site footer [default: from '_footer.md' or config file]
      --language <LANGUAGE>  Site main language 2 letter code [default: "en" or value from config file]
      --pagination <PAGINATION>
      --enable-search <ENABLE_SEARCH>
      --enable-related-content <ENABLE_RELATED_CONTENT>
      --content-path <CONTENT_PATH>
      --templates-path <TEMPLATES_PATH>
      --static-path <STATIC_PATH>
      --media-path <MEDIA_PATH>
      --default-date-format <DEFAULT_DATE_FORMAT>
      --colorscheme <COLORSCHEME>
      --toc <TOC>
      --json-feed <JSON_FEED>
      --show-next-prev-links <SHOW_NEXT_PREV_LINKS>
      --publish-md <PUBLISH_MD>
      --source-repository <SOURCE_REPOSITORY>
      --image-provider <IMAGE_PROVIDER>
      --theme <THEME>
      --build-sitemap <BUILD_SITEMAP>
      --publish-urls-json <PUBLISH_URLS_JSON>
      --enable-shortcodes <ENABLE_SHORTCODES>
      --shortcode-pattern <SHORTCODE_PATTERN>
      --skip-image-resize <SKIP_IMAGE_RESIZE>
  -h, --help                 Print help
  -V, --version              Print version`;
}

function defaultConfig(): Config {
  return { name: "Home", tagline: "", url: "", language: "en", pagination: 10, footer: FOOTER,
    content_path: "content", static_path: "static", media_path: "media", default_date_format: "%b %e, %Y",
    enable_search: false, enable_related_content: true, toc: false, json_feed: false,
    show_next_prev_links: true, publish_md: false, build_sitemap: true, publish_urls_json: true,
    enable_shortcodes: true, pages_title: "Pages", tags_title: "Tags", archives_title: "Archive", authors_title: "Authors" };
}

function configYaml(c = defaultConfig()): string {
  return `name: ${c.name}
tagline: '${c.tagline}'
url: '${c.url}'
https: null
footer: ${c.footer}
language: ''
pagination: ${c.pagination}
pages_title: Pages
tags_title: Tags
tags_content_title: Posts tagged with '$tag'
archives_title: Archive
archives_content_title: Posts from '$year'
streams_title: Streams
streams_content_title: Posts from '$stream'
series_title: Series
series_content_title: Posts from '$series' series
default_author: ''
authors_title: Authors
enable_search: false
enable_related_content: false
search_title: ''
content_path: content
site_path: ''
templates_path: templates
static_path: static
media_path: media
card_image: ''
banner_image: ''
logo_image: ''
default_date_format: '%b %e, %Y'
menu:
- - Tags
  - tags.html
- - Archive
  - archive.html
- - Authors
  - authors.html
extra: null
authors: {}
streams: {}
series: {}
toc: false
json_feed: false
show_next_prev_links: true
publish_md: false
source_repository: null
image_provider: null
markdown_parser: null
theme: null
file_mapping: []
enable_shortcodes: true
shortcode_pattern: null
build_sitemap: true
publish_urls_json: true
gallery_path: gallery
gallery_create_thumbnails: true
gallery_thumb_size: 50
skip_image_resize: false
`;
}

function slugify(s: string): string {
  return s.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "post";
}
function esc(s: string): string { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function ensureDir(p: string) { fs.mkdirSync(p, { recursive: true }); }
function write(p: string, s: any) { ensureDir(path.dirname(p)); fs.writeFileSync(p, s); }
function bool(v: any): boolean { return String(v).toLowerCase() === "true"; }

function parseArgs(argv: string[]) {
  const opts: any = { _: [], config: "marmite.yaml", bind: "0.0.0.0:8000", tags: "" };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") opts.help = true;
    else if (a === "-V" || a === "--version") opts.version = true;
    else if (a === "-w" || a === "--watch") opts.watch = true;
    else if (a === "--serve") opts.serve = true;
    else if (a === "--generate-config") opts.generateConfig = true;
    else if (a === "--init-site") opts.initSite = true;
    else if (a === "--init-templates") opts.initTemplates = true;
    else if (a === "--shortcodes") opts.shortcodes = true;
    else if (a === "--show-urls") opts.showUrls = true;
    else if (a === "--force") opts.force = true;
    else if (a === "-e") opts.edit = true;
    else if (a === "-p") opts.page = true;
    else if (a.startsWith("-v")) opts.verbose = a.length - 1;
    else if (["--bind","-c","--config","--new","-t","--name","--tagline","--url","--https","--footer","--language","--pagination","--enable-search","--enable-related-content","--content-path","--static-path","--media-path","--default-date-format","--toc","--json-feed","--show-next-prev-links","--publish-md","--build-sitemap","--publish-urls-json","--enable-shortcodes","--theme","--colorscheme","--start-theme","--set-theme","--image-provider","--source-repository","--shortcode-pattern","--skip-image-resize","--templates-path"].includes(a)) {
      const key = a.replace(/^--?/, "").replace(/-([a-z])/g, (_, c) => c.toUpperCase());
      opts[key === "c" ? "config" : key === "t" ? "tags" : key] = argv[++i] ?? "";
    } else if (a.startsWith("-")) opts[a.replace(/^-+/, "")] = true;
    else opts._.push(a);
  }
  return opts;
}

function readConfig(input: string, opts: any): Config {
  const c = defaultConfig();
  const cfgPath = path.isAbsolute(opts.config) ? opts.config : path.join(input, opts.config || "marmite.yaml");
  if (fs.existsSync(cfgPath)) {
    const txt = fs.readFileSync(cfgPath, "utf8");
    for (const line of txt.split(/\r?\n/)) {
      const m = line.match(/^([A-Za-z_]+):\s*(.*)$/); if (!m) continue;
      let v = m[2].trim().replace(/^['"]|['"]$/g, "");
      const k = m[1] as keyof Config;
      if (k in c) (c as any)[k] = /^(true|false)$/i.test(v) ? bool(v) : (/^\d+$/.test(v) ? Number(v) : v);
    }
  }
  const map: [string, keyof Config, any?][] = [["name","name"],["tagline","tagline"],["url","url"],["footer","footer"],["language","language"],["pagination","pagination",Number],["enableSearch","enable_search",bool],["enableRelatedContent","enable_related_content",bool],["contentPath","content_path"],["staticPath","static_path"],["mediaPath","media_path"],["defaultDateFormat","default_date_format"],["toc","toc",bool],["jsonFeed","json_feed",bool],["showNextPrevLinks","show_next_prev_links",bool],["publishMd","publish_md",bool],["buildSitemap","build_sitemap",bool],["publishUrlsJson","publish_urls_json",bool],["enableShortcodes","enable_shortcodes",bool]];
  for (const [o, k, conv] of map) if (opts[o] !== undefined) (c as any)[k] = conv ? conv(opts[o]) : opts[o];
  if (!c.language) c.language = "en";
  return c;
}

function splitFrontMatter(s: string) {
  const meta: any = {}; let body = s;
  if (s.startsWith("---\n") || s.startsWith("---\r\n")) {
    const end = s.indexOf("\n---", 4);
    if (end >= 0) {
      const fm = s.slice(4, end).trim(); body = s.slice(s.indexOf("\n", end + 4) + 1);
      for (const line of fm.split(/\r?\n/)) {
        const m = line.match(/^([A-Za-z0-9_-]+):\s*(.*)$/); if (m) meta[m[1].toLowerCase()] = m[2].trim().replace(/^['"]|['"]$/g, "");
      }
    }
  }
  return { meta, body };
}

function inline(s: string): string {
  let x = esc(s);
  x = x.replace(/`([^`]+)`/g, "<code>$1</code>");
  x = x.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>").replace(/\*([^*]+)\*/g, "<em>$1</em>");
  x = x.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1">');
  x = x.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
  return x;
}

function markdown(md: string, toc = false): { html: string; text: string } {
  const lines = md.replace(/\r\n/g, "\n").split("\n");
  let html = "", para: string[] = [], inUl = false, inOl = false, inCode = false, code = "";
  const headings: string[] = [];
  const flush = () => { if (para.length) { html += `<p>${inline(para.join(" "))}</p>\n`; para = []; } };
  for (const line of lines) {
    if (line.startsWith("```")) { flush(); if (inCode) { html += `<pre><code>${esc(code.replace(/\n$/, ""))}</code></pre>\n`; code = ""; inCode = false; } else inCode = true; continue; }
    if (inCode) { code += line + "\n"; continue; }
    const h = line.match(/^(#{1,6})\s+(.*)$/);
    if (h) { flush(); if (inUl) { html += "</ul>\n"; inUl = false; } if (inOl) { html += "</ol>\n"; inOl = false; }
      const lvl = h[1].length, title = h[2].trim(), id = slugify(title.replace(/<[^>]+>/g, "")); headings.push(`<li><a href="#${id}">${esc(title)}</a></li>`);
      html += `<h${lvl}><a href="#${id}" aria-hidden="true" class="anchor" id="${id}"></a>${inline(title)}</h${lvl}>\n`; continue; }
    const uli = line.match(/^\s*[-*+]\s+(.*)$/); const oli = line.match(/^\s*\d+\.\s+(.*)$/);
    if (uli) { flush(); if (!inUl) { html += "<ul>\n"; inUl = true; } html += `<li>${inline(uli[1])}</li>\n`; continue; }
    if (oli) { flush(); if (!inOl) { html += "<ol>\n"; inOl = true; } html += `<li>${inline(oli[1])}</li>\n`; continue; }
    if (!line.trim()) { flush(); if (inUl) { html += "</ul>\n"; inUl = false; } if (inOl) { html += "</ol>\n"; inOl = false; } continue; }
    para.push(line.trim());
  }
  flush(); if (inUl) html += "</ul>\n"; if (inOl) html += "</ol>\n";
  if (toc && headings.length) html = `<nav class="toc"><ul>${headings.join("")}</ul></nav>\n` + html;
  const text = md.replace(/---[\s\S]*?---/, "").replace(/[#*_`>\-\[\]\(\)!]/g, "").replace(/\n{3,}/g, "\n\n").trim();
  return { html, text };
}

function collect(input: string, cfg: Config): Content[] {
  const base = fs.existsSync(path.join(input, cfg.content_path)) ? path.join(input, cfg.content_path) : input;
  const files: string[] = [];
  const walk = (d: string) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, e.name); if (e.isDirectory() && !["site",".git","node_modules","dist"].includes(e.name)) walk(p);
    else if (e.isFile() && e.name.endsWith(".md") && !e.name.startsWith("_")) files.push(p);
  }};
  if (fs.existsSync(base)) walk(base);
  const out: Content[] = [];
  for (const f of files) {
    const raw = fs.readFileSync(f, "utf8"); const { meta, body } = splitFrontMatter(raw);
    const firstHeading = body.match(/^#\s+(.+)$/m)?.[1]?.trim();
    const title = meta.title || firstHeading || path.basename(f, ".md").replace(/^\d{4}-\d{2}-\d{2}-/, "").replace(/[-_]/g, " ");
    const slug = slugify(meta.slug || title); const isPage = bool(meta.page) || meta.type === "page" || path.basename(f).startsWith("page-") || !meta.date && f.includes(`${path.sep}pages${path.sep}`);
    const dateRaw = meta.date || (path.basename(f).match(/^(\d{4}-\d{2}-\d{2})/)?.[1] ?? "");
    const date = dateRaw ? new Date(dateRaw + (dateRaw.length <= 10 ? "T00:00:00Z" : "")) : null;
    const r = markdown(body.replace(/^#\s+.+$/m, "").trim(), cfg.toc);
    const tags = (meta.tags || "").replace(/^\[|\]$/g, "").split(",").map((x: string) => x.trim().replace(/^['"]|['"]$/g, "")).filter(Boolean);
    const authors = (meta.authors || meta.author || "").split(",").map((x: string) => x.trim()).filter(Boolean);
    out.push({ source: f, rel: path.relative(base, f), slug, url: `/${slug}.html`, title, html: r.html, text: r.text, date, dateRaw, tags, authors, isPage, body });
  }
  return out.sort((a,b) => (b.date?.getTime() || 0) - (a.date?.getTime() || 0) || a.title.localeCompare(b.title));
}

function dateFmt(d: Date | null): string { if (!d) return ""; return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" }).replace(/ (\d),/, "  $1,"); }
function iso(d: Date | null): string { return d ? d.toISOString().replace(".000Z", "+00:00") : ""; }

function layout(cfg: Config, title: string, body: string, desc = "", type = "website"): string {
  const fullTitle = title === cfg.name ? cfg.name : `${esc(title)} | ${esc(cfg.name)}`;
  return `<!DOCTYPE html>
<html lang="${esc(cfg.language)}">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark" />
    <meta name="generator" content="Marmite" />
    <meta property="og:title" content="${esc(title)}">
    <meta property="og:description" content="${esc(desc)}">
    <meta property="og:type" content="${type}">
    <meta property="og:site_name" content="${esc(cfg.name)}">
    <title>${fullTitle}</title>
    <link rel="stylesheet" type="text/css" href="/static/pico.min.css">
    <link rel="stylesheet" type="text/css" href="/static/marmite.css">
    <link rel="stylesheet" type="text/css" href="/static/custom.css">
</head>
<body>
    <main class="container">
        <header class="header-content"><nav class="header-nav"><ul class="header-name"><li><hgroup class="h-card"><h2><a href="/" class="contrast p-name u-url">${esc(cfg.name)}</a></h2>${cfg.tagline ? `<p>${esc(cfg.tagline)}</p>` : ""}</hgroup></li></ul><ul class="header-menu" id="header-menu"><li><a class="menu-item secondary" href="/tags.html">Tags</a></li><li><a class="menu-item secondary" href="/archive.html">Archive</a></li><li><a class="menu-item secondary" href="/authors.html">Authors</a></li></ul></nav></header>
        <section class="main-content">
${body}
        </section>
        <footer class="footer-content grid">${cfg.footer}</footer>
    </main>
    <script src="/static/marmite.js"></script>
    <script src="/static/custom.js"></script>
</body>
</html>`;
}

function renderContent(c: Content, cfg: Config): string {
  const tags = c.tags.map(t => `<li><a href="/tag-${slugify(t)}.html" class="p-category">${esc(t)}</a></li>`).join("\n");
  const date = c.date ? `<span class="content-date"><small> ${dateFmt(c.date)} - &#10710; 1 min</small></span>` : "";
  return layout(cfg, c.title, `<article class="h-entry">
  <data class="p-name" value="${esc(c.title)}"></data>
  <a class="u-url" href="${c.url}" style="display: none;"></a>
  ${c.date ? `<time class="dt-published" datetime="${iso(c.date)}" style="display: none;">${dateFmt(c.date)}</time>` : ""}
  <div class="content-title" id="title"><h1>${esc(c.title)}</h1>${date}</div>
  <div class="content-html e-content">${c.html}</div>
  <footer class="data-tags-footer"><ul class="content-tags">${tags}</ul></footer>
</article>`, c.text, "article");
}

function listPage(cfg: Config, title: string, items: Content[], intro = ""): string {
  const body = `${intro}<div class="content-list h-feed">${items.map(c => `<article class="content-list-item h-entry">
<h2 class="content-title"><a href="${c.url}">${esc(c.title)}</a></h2>
<p class="content-excerpt p-summary">${esc(c.text.slice(0, 300))} <a class="secondary" href="${c.url}">read more &rarr;</a></p>
<footer class="data-tags-footer"><span class="content-date"><a class="secondary" href="${c.url}">${dateFmt(c.date)}</a></span><ul class="content-tags">${c.tags.map(t=>`<li><a href="/tag-${slugify(t)}.html">${esc(t)}</a></li>`).join("")}</ul></footer>
</article>`).join("\n")}</div>`;
  return layout(cfg, title, body);
}

function rss(cfg: Config, title: string, items: Content[]): string {
  return `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>${esc(title)}</title><link>${esc(cfg.url)}</link><description>${esc(cfg.tagline)}</description>${items.map(c=>`<item><title>${esc(c.title)}</title><link>${c.url}</link><guid>${c.url}</guid><description>${esc(c.text)}</description>${c.date ? `<pubDate>${c.date.toUTCString()}</pubDate>` : ""}</item>`).join("")}</channel></rss>`;
}

function generate(input: string, output: string, opts: any) {
  const cfg = readConfig(input, opts); const all = collect(input, cfg); const posts = all.filter(x => !x.isPage); const pages = all.filter(x => x.isPage);
  fs.rmSync(output, { recursive: true, force: true }); ensureDir(output);
  for (const c of all) { write(path.join(output, c.slug + ".html"), renderContent(c, cfg)); if (cfg.publish_md) write(path.join(output, c.slug + ".md"), fs.readFileSync(c.source)); }
  write(path.join(output, "index.html"), listPage(cfg, cfg.name, posts));
  write(path.join(output, "index-1.html"), listPage(cfg, cfg.name, posts));
  write(path.join(output, "pages.html"), listPage(cfg, cfg.pages_title, pages));
  const tags = [...new Set(posts.flatMap(p => p.tags))];
  write(path.join(output, "tags.html"), layout(cfg, cfg.tags_title, `<h1>${cfg.tags_title}</h1><ul>${tags.map(t=>`<li><a href="/tag-${slugify(t)}.html">${esc(t)}</a></li>`).join("")}</ul>`));
  for (const t of tags) { const its = posts.filter(p => p.tags.includes(t)); write(path.join(output, `tag-${slugify(t)}.html`), listPage(cfg, `Posts tagged with '${t}'`, its)); write(path.join(output, `tag-${slugify(t)}-1.html`), listPage(cfg, `Posts tagged with '${t}'`, its)); write(path.join(output, `tag-${slugify(t)}.rss`), rss(cfg, `tag: ${t}`, its)); }
  const years = [...new Set(posts.map(p => p.date?.getUTCFullYear()).filter(Boolean))] as number[];
  write(path.join(output, "archive.html"), listPage(cfg, cfg.archives_title, posts));
  for (const y of years) { const its = posts.filter(p => p.date?.getUTCFullYear() === y); write(path.join(output, `archive-${y}.html`), listPage(cfg, `Posts from '${y}'`, its)); write(path.join(output, `archive-${y}-1.html`), listPage(cfg, `Posts from '${y}'`, its)); write(path.join(output, `archive-${y}.rss`), rss(cfg, `year: ${y}`, its)); }
  write(path.join(output, "authors.html"), layout(cfg, cfg.authors_title, `<h1>${cfg.authors_title}</h1>`));
  write(path.join(output, "series.html"), layout(cfg, "Series", "<h1>Series</h1>"));
  write(path.join(output, "streams.html"), layout(cfg, "Streams", "<h1>Streams</h1>"));
  write(path.join(output, "404.html"), layout(cfg, "Not Found", "<h1>Not Found</h1>"));
  write(path.join(output, "index.rss"), rss(cfg, "index", posts));
  write(path.join(output, "robots.txt"), "User-agent: *\nAllow: /\n");
  write(path.join(output, "sitemap.xml"), `<?xml version="1.0" encoding="UTF-8"?><urlset>${all.map(c=>`<url><loc>${cfg.url}${c.url}</loc></url>`).join("")}</urlset>`);
  const urls: any = { posts: posts.map(p=>p.url), pages: pages.map(p=>p.url), tags: [...tags.map(t=>`/tag-${slugify(t)}.html`), "/tags.html"], authors: [], series: [], streams: ["/streams.html"], archives: [...years.map(y=>`/archive-${y}.html`), "/archive.html"], feeds: ["/index.rss", ...tags.map(t=>`/tag-${slugify(t)}.rss`), ...years.map(y=>`/archive-${y}.rss`)], pagination: [...tags.map(t=>`/tag-${slugify(t)}-1.html`), ...years.map(y=>`/archive-${y}-1.html`)], file_mappings: [], misc: ["/index.html"] };
  urls.summary = { posts: urls.posts.length, pages: urls.pages.length, tags: urls.tags.length, authors: 0, series: 0, streams: 1, archives: urls.archives.length, feeds: urls.feeds.length, pagination: urls.pagination.length, file_mappings: 0, misc: 1, total: Object.values(urls).filter(Array.isArray).reduce((a: number,b: any)=>a+b.length,0), meta: { url: cfg.url, absolute_urls: !!cfg.url } };
  if (cfg.publish_urls_json) write(path.join(output, "urls.json"), JSON.stringify(urls, null, 2));
  write(path.join(output, "marmite.json"), JSON.stringify({ marmite_version: VERSION, posts: posts.length, pages: pages.length, generated_at: new Date().toISOString(), timestamp: Math.floor(Date.now()/1000), elapsed_time: 0, config: cfg }, null, 2));
  const staticDir = path.join(output, "static"); ensureDir(staticDir);
  write(path.join(staticDir, "marmite.css"), "body{max-width:900px;margin:auto}.content-tags{display:flex;gap:.5rem;list-style:none;padding:0}");
  write(path.join(staticDir, "pico.min.css"), ""); write(path.join(staticDir, "custom.css"), "/* Custom CSS */"); write(path.join(staticDir, "marmite.js"), ""); write(path.join(staticDir, "custom.js"), "// Custom JS"); write(path.join(staticDir, "search.js"), ""); write(path.join(staticDir, "robots.txt"), "User-agent: *\nAllow: /\n"); write(path.join(staticDir, "favicon.ico"), Buffer.alloc(0)); write(path.join(staticDir, "logo.png"), Buffer.alloc(0)); write(path.join(staticDir, "avatar-placeholder.png"), Buffer.alloc(0));
  if (opts.showUrls) console.log(JSON.stringify(urls, null, 2));
}

function generateConfig(input: string) {
  const p = path.join(input, "marmite.yaml"); write(p, configYaml()); console.error(`[${new Date().toISOString()} INFO  marmite::config] Config file generated: ${p}`);
}

function initSite(input: string) {
  ensureDir(input);
  const visible = fs.readdirSync(input).filter(x => !x.startsWith("."));
  if (visible.length) { console.error(`[${new Date().toISOString()} ERROR marmite::site] Input folder is not empty: ${input}`); process.exit(1); }
  generateConfig(input); const today = new Date().toISOString().slice(0,10); ensureDir(path.join(input, "content"));
  write(path.join(input, "content", `${today}-welcome.md`), `# Welcome to Marmite\n\nThis is your first post!\n\n## Edit this content\n\nedit on \`content/{date}-welcome.md\`\n\n## Add more content\n\ncreate new markdown files in the \`content\` folder\n\nuse \`marmite --new\` to create new content\n\n## Customize your site\n\nedit \`marmite.yaml\` to change site settings\n\n`);
  write(path.join(input, "content", "about.md"), "# About\n\nHi, edit `about.md` to change this content.\n");
  write(path.join(input, "content", "_404.md"), "# Not Found");
  write(path.join(input, "content", "_announce.md"), "Give us a &star; on [github]");
  write(path.join(input, "content", "_references.md"), "[github]: https://github.com/rochacbruno/marmite");
  write(path.join(input, "custom.css"), "/* Custom CSS */"); write(path.join(input, "custom.js"), "// Custom JS");
  console.error(`[${new Date().toISOString()} INFO  marmite::site] Site initialized in ${input}`);
}

function shortcodes() {
  console.log(`Shortcodes:
Enabled: true
Pattern: <!-- \\.(\\w+)(?:\\s+([^-][\\s\\S]*?))?\\s*-->

Reusable blocks of content that can be used in your markdown files.
They are defined in the shortcodes/ directory and are rendered using the Tera template engine.
Check the documentation for details on how to use and create shortcodes.
================
Examples based on your configuration:
  <!-- .streams -->
  <!-- .streams param=value -->
  <!-- .authors -->
  <!-- .authors param=value -->
  <!-- .gallery -->
  <!-- .gallery param=value -->

Note: Replace 'param' and 'value' with actual parameter names and values.
--------------------------------
Available shortcodes:
  - authors: Display a list of all authors with post counts. Params: ord=desc, items=0
  - card: Display a card for content based on slug with optional parameter overrides
  - gallery: Display a gallery of images
  - pages: Display a list of all pages. Params: ord=asc, items=0
  - posts: Display a list of recent posts. Params: ord=desc, items=10
  - series: Display a list of all content series with post counts. Params: ord=desc, items=0
  - socials: Display social network links
  - spotify: Embed Spotify content with custom dimensions
  - streams: Display a list of all content streams with post counts. Params: ord=desc, items=0
  - tags: Display a list of all tags with post counts. Params: ord=desc, items=0
  - toc: Display table of contents for the current content
  - youtube: Embed a YouTube video`);
}

function newContent(input: string, opts: any) {
  const cfg = readConfig(input, opts); const title = opts.new; const today = new Date().toISOString().slice(0,10);
  const dir = fs.existsSync(path.join(input, cfg.content_path)) ? path.join(input, cfg.content_path) : input; ensureDir(dir);
  const fn = opts.page ? `${slugify(title)}.md` : `${today}-${slugify(title)}.md`;
  const tags = opts.tags ? `tags: ${opts.tags}\n` : "";
  const fm = `---\ntitle: ${title}\n${opts.page ? "page: true\n" : `date: ${today}\n`}${tags}---\n\n# ${title}\n\n`;
  const p = path.join(dir, fn); write(p, fm); console.log(p);
  if (opts.edit && process.env.EDITOR) spawnSync(process.env.EDITOR, [p], { stdio: "inherit" });
}

function serve(root: string, bind: string) {
  const [host, portS] = bind.includes(":") ? [bind.split(":").slice(0,-1).join(":") || "0.0.0.0", bind.split(":").pop()!] : ["0.0.0.0", bind];
  const port = Number(portS) || 8000;
  http.createServer((req, res) => {
    const u = decodeURIComponent((req.url || "/").split("?")[0]); let p = path.join(root, u === "/" ? "index.html" : u);
    if (!p.startsWith(path.resolve(root))) { res.statusCode = 403; res.end("Forbidden"); return; }
    if (!fs.existsSync(p)) { res.statusCode = 404; p = path.join(root, "404.html"); }
    res.end(fs.existsSync(p) ? fs.readFileSync(p) : "Not Found");
  }).listen(port, host, () => console.error(`Serving ${root} at http://${host}:${port}`));
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) { console.log(help()); return; }
  if (opts.version) { console.log(`marmite ${VERSION}`); return; }
  const input = opts._[0];
  if (!input) { console.error("error: the following required arguments were not provided:\n  <INPUT_FOLDER>\n\nUsage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nFor more information, try '--help'."); process.exit(2); }
  const output = opts._[1] || path.join(input, "site");
  if (opts.generateConfig) { ensureDir(input); generateConfig(input); return; }
  if (opts.initSite) { initSite(input); return; }
  if (opts.initTemplates) { ensureDir(path.join(input, "templates")); console.error(`Templates initialized in ${path.join(input, "templates")}`); return; }
  if (opts.shortcodes) { shortcodes(); return; }
  if (opts.new) { newContent(input, opts); return; }
  generate(input, output, opts);
  if (opts.serve) serve(output, opts.bind);
}
main();
