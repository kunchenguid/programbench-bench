declare const require: any;
declare const process: any;
const fs = require("fs");
const path = require("path");
const nodeCrypto = require("crypto");

type Kind = "apt" | "event" | "todo";
type CalItem = {
  kind: "apt" | "event";
  raw: string;
  start: Date;
  end: Date;
  msg: string;
  important?: boolean;
  note?: string;
  recur?: string;
  days?: number;
};
type TodoItem = { kind: "todo"; raw: string; priority: number; msg: string; note?: string; completed: boolean };
type Item = CalItem | TodoItem;

const VERSION = `calcurse 4.8.2 -- text-based organizer

Copyright (c) 2004-2023 calcurse Development Team.
This is free software; see the source for copying conditions.`;

const HELP = `Usage:
calcurse [-D <directory>] [-C <directory>] [-c <calendar file>]
calcurse -Q [--from <date>] [--to <date>] [--days <number>]
calcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]
calcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon

Operations in command line mode:
  -Q, --query   Print items in a given query range
  -G, --grep    Grep items from the data files
  -P, --purge   Read items and write them back
Query short forms:
-a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>

Note that filter, format and day-range options affect input or output:
  --filter-*              Filter items loaded by -Q, -G, -P and -x
  --format-*              Rewrite output from -Q, -G and --dump-imported
  --from <date>           Limit day range of -Q.
  --to <date>             Limit day range of -Q.
  --days <number>         Limit day range of -Q.

  --limit, -l <number>    Limit number of query results
  --search, -S <regexp>   Match regular expression in queries
Consult the man page for details.

Miscellaneous:
  -c, --calendar <file>   The calendar data file to use
  -C, --confdir <dir>     The configuration directory to use
  --daemon                Run notification daemon in the background
  -D, --datadir <dir>     The data directory to use
  -g, --gc                Run the garbage collector
  -h, --help              Show this help text
  -i, --import <file>     Import iCal data from file
  -q, --quiet             Suppress import/export result message
  --read-only             Do not save configuration or data files
  --status                Display status of running instances
  -v, --version           Show version information
  -x, --export[<format>]  Export to stdout in ical (default) or pcal format

For more information, type '?' from within calcurse, or read the manpage.
Submit feature requests and suggestions to <misc@calcurse.org>.
Submit bug reports to <bugs@calcurse.org>.`;

function pad(n: number) { return String(n).padStart(2, "0"); }
function localDate(y: number, m: number, d: number, hh = 0, mm = 0, ss = 0) { return new Date(y, m - 1, d, hh, mm, ss, 0); }
function cloneDate(d: Date) { return new Date(d.getTime()); }
function addDays(d: Date, n: number) { const x = cloneDate(d); x.setDate(x.getDate() + n); return x; }
function addMonths(d: Date, n: number) { const x = cloneDate(d); x.setMonth(x.getMonth() + n); return x; }
function addYears(d: Date, n: number) { const x = cloneDate(d); x.setFullYear(x.getFullYear() + n); return x; }
function startOfDay(d: Date) { return localDate(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
function sameDay(a: Date, b: Date) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }
function dateKey(d: Date) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function fmtFull(d: Date) { return `${pad(d.getMonth() + 1)}/${pad(d.getDate())}/${d.getFullYear()}`; }
function fmtShort(d: Date) { return `${pad(d.getMonth() + 1)}/${pad(d.getDate())}/${pad(d.getFullYear() % 100)}`; }
function fmtTime(d: Date) { return `${pad(d.getHours())}:${pad(d.getMinutes())}`; }
function icalDate(d: Date) { return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`; }
function icalDateTime(d: Date) { return `${icalDate(d)}T${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`; }
function escapeIcal(s: string) { return s.replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;"); }
function unescapeIcal(s: string) { return s.replace(/\\n/gi, "\n").replace(/\\,/g, ",").replace(/\\;/g, ";").replace(/\\\\/g, "\\"); }

function parseDateArg(s: string, inputFmt: number): Date | null {
  const lower = s.toLowerCase();
  const today = startOfDay(new Date());
  if (["today", "now"].includes(lower)) return today;
  if (lower === "tomorrow") return addDays(today, 1);
  if (lower === "yesterday") return addDays(today, -1);
  const wds = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const wi = wds.findIndex(w => lower.startsWith(w));
  if (wi >= 0) {
    const diff = (wi - today.getDay() + 7) % 7;
    return addDays(today, diff);
  }
  const datePart = s.trim().split(/\s+/)[0];
  let m: RegExpMatchArray | null;
  if ((m = datePart.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/))) return localDate(+m[1], +m[2], +m[3]);
  if ((m = datePart.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/))) {
    let a = +m[1], b = +m[2], y = +m[3]; if (y < 100) y += 2000;
    return inputFmt === 2 ? localDate(y, b, a) : localDate(y, a, b);
  }
  return null;
}

function parseIcalDate(v: string): Date | null {
  const m = v.match(/^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?)?/);
  if (!m) return null;
  return localDate(+m[1], +m[2], +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
}
function parseDuration(s: string): number {
  const m = s.match(/^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/i);
  if (!m) return 0;
  return ((+(m[1] || 0) * 86400) + (+(m[2] || 0) * 3600) + (+(m[3] || 0) * 60) + +(m[4] || 0)) * 1000;
}
function durationIcal(ms: number): string {
  let sec = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(sec / 86400); sec %= 86400;
  const h = Math.floor(sec / 3600); sec %= 3600;
  const m = Math.floor(sec / 60); sec %= 60;
  return `P${d ? d + "D" : ""}T${h ? h + "H" : ""}${m ? m + "M" : ""}${sec ? sec + "S" : (h || m ? "0S" : "0S")}`;
}

function dataDir(opts: any): string {
  if (opts.datadir) return opts.datadir;
  const home = process.env.HOME || ".";
  if (fs.existsSync(path.join(home, ".calcurse"))) return path.join(home, ".calcurse");
  return path.join(process.env.XDG_DATA_HOME || path.join(home, ".local", "share"), "calcurse");
}

function readItems(opts: any): Item[] {
  const dir = dataDir(opts), apts = opts.calendar || path.join(dir, "apts"), todo = path.join(dir, "todo");
  const items: Item[] = [];
  if (fs.existsSync(todo)) {
    for (const raw of fs.readFileSync(todo, "utf8").split(/\r?\n/).filter(Boolean)) {
      const m = raw.match(/^\[(-?\d+)\](?:>([0-9a-f]{40}))?\s*(.*)$/);
      if (m) items.push({ kind: "todo", raw, priority: Math.abs(+m[1]), completed: m[1].startsWith("-"), note: m[2], msg: m[3] });
    }
  }
  if (fs.existsSync(apts)) {
    for (const raw of fs.readFileSync(apts, "utf8").split(/\r?\n/).filter(Boolean)) {
      let m = raw.match(/^(\d\d)\/(\d\d)\/(\d{4})\s+\[(\d+)\](?:\s+\{([^}]*)\})?(?:\s+>([0-9a-f]{40}))?\s+(.*)$/);
      if (m) {
        const d = localDate(+m[3], +m[1], +m[2]); const days = +m[4];
        items.push({ kind: "event", raw, start: d, end: addDays(d, days), days, recur: m[5], note: m[6], msg: m[7] });
        continue;
      }
      m = raw.match(/^(\d\d)\/(\d\d)\/(\d{4}) @ (\d\d):(\d\d) -> (\d\d)\/(\d\d)\/(\d{4}) @ (\d\d):(\d\d)(?:\s+\{([^}]*)\})?(?:>([0-9a-f]{40}))?\s*([!|])?(.*)$/);
      if (m) {
        items.push({ kind: "apt", raw, start: localDate(+m[8], +m[6], +m[7], +m[9], +m[10]), end: localDate(+m[8], +m[6], +m[7], +m[9], +m[10]), msg: "" });
        const it = items[items.length - 1] as CalItem;
        it.start = localDate(+m[3], +m[1], +m[2], +m[4], +m[5]);
        it.recur = m[11]; it.note = m[12]; it.important = m[13] === "!"; it.msg = m[14] || "";
      }
    }
  }
  return items;
}

function unfoldedLines(text: string): string[] {
  const out: string[] = [];
  for (const l of text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n")) {
    if (/^[ \t]/.test(l) && out.length) out[out.length - 1] += l.slice(1);
    else out.push(l);
  }
  return out.filter(l => l.length);
}
function propName(line: string) { const i = line.indexOf(":"); return (i < 0 ? line : line.slice(0, i)).split(";")[0].toUpperCase(); }
function propValue(line: string) { const i = line.indexOf(":"); return i < 0 ? "" : line.slice(i + 1); }

function noteFor(obj: Record<string, string>): string | undefined {
  const parts: string[] = [];
  if (obj.DESCRIPTION !== undefined) parts.push(unescapeIcal(obj.DESCRIPTION));
  if (obj.LOCATION !== undefined) parts.push(`Location: ${unescapeIcal(obj.LOCATION).trimStart()}`);
  if (obj.COMMENT !== undefined) parts.push(`Comment: ${unescapeIcal(obj.COMMENT)}`);
  const s = parts.join("\n");
  return s.length ? s + (s.endsWith("\n") ? "" : "\n") : undefined;
}
function sha(s: string) { return nodeCrypto.createHash("sha1").update(s).digest("hex"); }

function importIcal(file: string, opts: any): Item[] {
  const text = fs.readFileSync(file, "utf8");
  const dir = dataDir(opts); fs.mkdirSync(dir, { recursive: true }); fs.mkdirSync(path.join(dir, "notes"), { recursive: true });
  const calObjs: CalItem[] = [], todoObjs: TodoItem[] = []; const imported: Item[] = [];
  let cur: string | null = null, obj: Record<string, string> = {}, startLine = 0;
  let apps = 0, events = 0, todos = 0, skipped = 0;
  const lines = unfoldedLines(text);
  function finish() {
    if (!cur) return;
    const summary = unescapeIcal(obj.SUMMARY || "");
    const note = noteFor(obj); const noteHash = note ? sha(note) : undefined;
    if (note && noteHash) fs.writeFileSync(path.join(dir, "notes", noteHash), note);
    if (cur === "VTODO") {
      const pri0 = obj.PRIORITY ? +obj.PRIORITY : 0;
      const completed = (obj.STATUS || "").toUpperCase() === "COMPLETED";
      const pri = completed ? `[-${pri0}]` : `[${pri0 || 9}]`;
      const raw = `${pri}${noteHash ? ">" + noteHash : ""} ${summary}`;
      const todoObj = { kind: "todo" as const, raw, priority: Math.abs(pri0 || 9), completed, note: noteHash, msg: summary };
      todoObjs.push(todoObj); todos++;
      imported.push(todoObj);
    } else if (cur === "VEVENT") {
      const ds = obj.DTSTART; const start = ds ? parseIcalDate(ds) : null;
      if (!start) { skipped++; return; }
      const isDate = (obj._DTSTART_PARAMS || "").includes("VALUE=DATE");
      let end = obj.DTEND ? parseIcalDate(obj.DTEND)! : (obj.DURATION ? new Date(start.getTime() + parseDuration(obj.DURATION)) : cloneDate(start));
      let raw: string;
      const recur = recurrence(obj, start, end, isDate);
      if (isDate) {
        if (!obj.DTEND && obj.DURATION) end = new Date(start.getTime() + parseDuration(obj.DURATION));
        const days = Math.max(1, Math.round((startOfDay(end).getTime() - startOfDay(start).getTime()) / 86400000));
        raw = `${fmtFull(start)} [${days}]${recur ? " {" + recur + "}" : ""}${noteHash ? " >" + noteHash : ""} ${summary}`;
        events++;
        calObjs.push({ kind: "event", raw, start, end, days, recur, note: noteHash, msg: summary });
        imported.push(calObjs[calObjs.length - 1]);
      } else {
        end = new Date(Math.floor(end.getTime() / 60000) * 60000);
        raw = `${fmtFull(start)} @ ${fmtTime(start)} -> ${fmtFull(end)} @ ${fmtTime(end)}${recur ? " {" + recur + "}" : ""}${noteHash ? ">" + noteHash : ""}|${summary}`;
        apps++;
        calObjs.push({ kind: "apt", raw, start, end, recur, note: noteHash, msg: summary });
        imported.push(calObjs[calObjs.length - 1]);
      }
    }
  }
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i], p = propName(line), v = propValue(line);
    if (p === "BEGIN" && (v === "VEVENT" || v === "VTODO")) { cur = v; obj = {}; startLine = i + 1; continue; }
    if (p === "END" && cur === v) { finish(); cur = null; continue; }
    if (cur) {
      if (p === "DTSTART") obj._DTSTART_PARAMS = line.slice(0, line.indexOf(":")).toUpperCase();
      obj[p] = v;
    }
  }
  calObjs.sort((a, b) => (a.kind === b.kind ? 0 : a.kind === "event" ? -1 : 1) || a.start.getTime() - b.start.getTime() || a.msg.localeCompare(b.msg));
  todoObjs.sort((a, b) => Number(a.completed) - Number(b.completed) || a.priority - b.priority || a.msg.localeCompare(b.msg));
  const calLines = calObjs.map(x => x.raw), todoLines = todoObjs.map(x => x.raw);
  fs.writeFileSync(opts.calendar || path.join(dir, "apts"), calLines.join("\n") + (calLines.length ? "\n" : ""));
  fs.writeFileSync(path.join(dir, "todo"), todoLines.join("\n") + (todoLines.length ? "\n" : ""));
  if (!opts.quiet || opts.dumpImported) {
    if (opts.dumpImported) for (const it of imported) process.stdout.write(formatItem(it, opts, false));
    process.stderr.write(`Import process report: ${String(lines.length).padStart(4, "0")} lines read\n${apps} app / ${events} events / ${todos} todo / ${skipped} skipped\n`);
  }
  return imported;
}

function recurrence(obj: Record<string, string>, start: Date, end: Date, isDate: boolean): string | undefined {
  if (!obj.RRULE) return undefined;
  const r: Record<string, string> = {};
  for (const part of obj.RRULE.split(";")) { const [k, v] = part.split("="); r[k] = v; }
  const freq = ({ DAILY: "D", WEEKLY: "W", MONTHLY: "M", YEARLY: "Y" } as any)[r.FREQ] || "D";
  const interval = r.INTERVAL || "1";
  let until = "";
  if (r.COUNT) {
    let u = cloneDate(start); const n = Math.max(0, +r.COUNT - 1) * +(interval || 1);
    if (freq === "D") u = addDays(u, n); else if (freq === "W") u = addDays(u, n * 7); else if (freq === "M") u = addMonths(u, n); else u = addYears(u, n);
    until = fmtFull(u);
  } else if (r.UNTIL) {
    const u = parseIcalDate(r.UNTIL)!;
    until = fmtFull(isDate ? u : (u.getTime() < end.getTime() ? addDays(u, -1) : u));
  } else until = "0";
  let extra = "";
  if (r.BYDAY) extra += " w" + r.BYDAY.split(",").map(x => x.replace("MO", "1").replace("TU", "2").replace("WE", "3").replace("TH", "4").replace("FR", "5").replace("SA", "6").replace("SU", "0")).join(",");
  if (r.BYMONTH) extra += " m" + r.BYMONTH;
  if (r.BYMONTHDAY) extra += " d" + r.BYMONTHDAY;
  if (obj.EXDATE) extra += " " + obj.EXDATE.split(",").map(x => "!" + fmtFull(parseIcalDate(x)!)).join(" ");
  return `${interval}${freq} -> ${until}${extra}`;
}

function matchesFilters(it: Item, opts: any): boolean {
  let ok = true;
  if (opts.type) {
    const set = new Set<string>();
    for (const t of opts.type.split(",")) {
      if (t === "cal") ["event", "apt", "recur-event", "recur-apt"].forEach(x => set.add(x));
      else if (t === "recur") ["recur-event", "recur-apt"].forEach(x => set.add(x)); else set.add(t);
    }
    const name = it.kind === "todo" ? "todo" : ((it as CalItem).recur ? `recur-${it.kind}` : it.kind);
    ok &&= set.has(name);
  }
  if (opts.pattern) ok &&= new RegExp(opts.pattern).test((it as any).msg);
  if (opts.priority !== undefined && it.kind === "todo") ok &&= it.priority === +opts.priority;
  if (opts.completed && it.kind === "todo") ok &&= it.completed;
  if (opts.uncompleted && it.kind === "todo") ok &&= !it.completed;
  return opts.invert ? !ok : ok;
}

function formatItem(it: Item, opts: any, query: boolean, day?: Date): string {
  const custom = it.kind === "todo" ? opts.formatTodo : it.kind === "apt" ? opts.formatApt : opts.formatEvent;
  const fmt = custom ?? (query ? (it.kind === "todo" ? "%p. %m\n" : it.kind === "apt" ? " - %S -> %E\n\t%m\n" : " * %m\n") : "%(raw)");
  return applyFormat(fmt, it, day);
}
function applyFormat(fmt: string, it: Item, day?: Date): string {
  const cal = it as CalItem;
  const raw = it.raw;
  function sTime() { return day && cal.start < startOfDay(day) ? "..:.." : fmtTime(cal.start); }
  function eTime() { return day && cal.end > addDays(startOfDay(day), 1) ? "..:.." : fmtTime(cal.end); }
  return fmt.replace(/\\n/g, "\n").replace(/\\t/g, "\t")
    .replace(/%\((raw|hash|start(?::[^)]*)?|end(?::[^)]*)?|duration(?::[^)]*)?)\)/g, (_m, spec) => {
      if (spec === "raw") return raw;
      if (spec === "hash") return sha(raw);
      if (spec.startsWith("start")) return spec.includes("epoch") ? Math.floor(cal.start.getTime() / 1000).toString() : fmtTime(cal.start);
      if (spec.startsWith("end")) return spec.includes("epoch") ? Math.floor(cal.end.getTime() / 1000).toString() : fmtTime(cal.end);
      if (spec.startsWith("duration")) return Math.floor((cal.end.getTime() - cal.start.getTime()) / 1000).toString();
      return "";
    })
    .replace(/%[dDeEmnNpPrsSE]/g, m => {
      switch (m) {
        case "%m": return (it as any).msg;
        case "%p": return it.kind === "todo" ? String(it.priority) : "";
        case "%S": return it.kind === "apt" ? sTime() : "";
        case "%E": return it.kind === "apt" ? eTime() : "";
        case "%s": return it.kind === "apt" ? Math.floor(cal.start.getTime() / 1000).toString() : "";
        case "%e": return it.kind === "apt" ? Math.floor(cal.end.getTime() / 1000).toString() : "";
        case "%d": return it.kind === "apt" ? Math.floor((cal.end.getTime() - cal.start.getTime()) / 1000).toString() : "";
        case "%n": return (it as any).note || "";
        case "%N": return "";
        default: return "";
      }
    });
}

function query(items: Item[], opts: any) {
  const filtered = items.filter(it => matchesFilters(it, opts));
  const showTodo = !opts.type || opts.type.includes("todo");
  const todos = filtered.filter((x): x is TodoItem => x.kind === "todo" && (!opts.hideCompleted || !x.completed));
  if (showTodo && todos.length) {
    process.stdout.write("to do:\n");
    for (const t of todos) process.stdout.write(formatItem(t, opts, true));
    process.stdout.write("\n");
  }
  const from = opts.from || startOfDay(new Date());
  let days = opts.days ?? 1; let start = from, end = opts.to || addDays(from, Math.abs(days) - 1);
  if (days < 0) { start = addDays(from, days + 1); end = from; }
  for (let d = startOfDay(start); d <= startOfDay(end); d = addDays(d, 1)) {
    const dayItems = filtered.filter((x): x is CalItem => x.kind !== "todo" && x.start < addDays(d, 1) && (x.end > d || sameDay(x.start, d)));
    if (!dayItems.length) continue;
    process.stdout.write(`${opts.outputFmt ? strftime(d, opts.outputFmt) : fmtShort(d)}:\n`);
    for (const it of dayItems.sort((a, b) => a.start.getTime() - b.start.getTime())) process.stdout.write(formatItem(it, opts, true, d));
    process.stdout.write("\n");
  }
}
function strftime(d: Date, f: string) { return f.replace(/%Y/g, String(d.getFullYear())).replace(/%y/g, pad(d.getFullYear() % 100)).replace(/%m/g, pad(d.getMonth() + 1)).replace(/%d/g, pad(d.getDate())); }

function exportItems(items: Item[], format = "ical") {
  if (format === "pcal") {
    for (const it of items) if (it.kind !== "todo") process.stdout.write(`${fmtFull(it.start)} ${it.msg}\n`);
    return;
  }
  process.stdout.write("BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//calcurse//NONSGML v4.8.2//EN\n");
  for (const it of items.filter(x => x.kind === "event") as CalItem[]) {
    process.stdout.write("BEGIN:VEVENT\n");
    process.stdout.write(`DTSTART;VALUE=DATE:${icalDate(it.start)}\nDTEND;VALUE=DATE:${icalDate(it.end)}\nSUMMARY:${escapeIcal(it.msg)}\nEND:VEVENT\n`);
  }
  for (const it of items.filter(x => x.kind === "apt") as CalItem[]) {
    process.stdout.write("BEGIN:VEVENT\n");
    process.stdout.write(`DTSTART:${icalDateTime(it.start)}\nDURATION:${durationIcal(it.end.getTime() - it.start.getTime())}\nSUMMARY:${escapeIcal(it.msg)}\nEND:VEVENT\n`);
  }
  for (const t of items.filter(x => x.kind === "todo") as TodoItem[]) {
    process.stdout.write("BEGIN:VTODO\n");
    process.stdout.write(`PRIORITY:${t.priority}\nSUMMARY:${escapeIcal(t.msg)}\nEND:VTODO\n`);
  }
  process.stdout.write("END:VCALENDAR\n");
}

function parseArgs(argv: string[]) {
  const opts: any = { inputFmt: 1 }; let op = "";
  function need(i: number, o: string) { if (i + 1 >= argv.length) throw new Error(`${o}: option requires an argument`); return argv[i + 1]; }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") op = "help";
    else if (a === "-v" || a === "--version") op = "version";
    else if (a === "--status") op = "status";
    else if (a === "-q" || a === "--quiet") opts.quiet = true;
    else if (a === "-D" || a === "--datadir") opts.datadir = need(i++, a);
    else if (a === "-C" || a === "--confdir") opts.confdir = need(i++, a);
    else if (a === "-c" || a === "--calendar") opts.calendar = need(i++, a);
    else if (a === "-i" || a === "--import") { op = "import"; opts.importFile = need(i++, a); }
    else if (a === "-Q" || a === "--query") op = "query";
    else if (a === "-G" || a === "--grep") op = "grep";
    else if (a === "-P" || a === "--purge") op = "purge";
    else if (a === "-g" || a === "--gc") op = "gc";
    else if (a === "--daemon") op = "daemon";
    else if (a === "--dump-imported") opts.dumpImported = true;
    else if (a.startsWith("-x") && a !== "--export") { op = "export"; opts.exportFmt = a.length > 2 ? a.slice(2) : "ical"; }
    else if (a === "--export") { op = "export"; opts.exportFmt = argv[i + 1] && !argv[i + 1].startsWith("-") ? argv[++i] : "ical"; }
    else if (a === "--from") { const d = parseDateArg(need(i++, a), opts.inputFmt); if (!d) dieInvalidDate(argv[i]); opts.from = d; }
    else if (a === "--to") { const d = parseDateArg(need(i++, a), opts.inputFmt); if (!d) dieInvalidDate(argv[i]); opts.to = d; }
    else if (a === "--days") opts.days = +need(i++, a);
    else if (a === "--input-datefmt") opts.inputFmt = +need(i++, a);
    else if (a === "--output-datefmt") opts.outputFmt = need(i++, a);
    else if (a === "--filter-type") opts.type = need(i++, a);
    else if (a === "--filter-pattern" || a === "--search" || a === "-S") opts.pattern = need(i++, a);
    else if (a === "--filter-priority") opts.priority = need(i++, a);
    else if (a === "--filter-completed") opts.completed = true;
    else if (a === "--filter-uncompleted") opts.uncompleted = true;
    else if (a === "--filter-invert") opts.invert = true;
    else if (a === "--format-apt") opts.formatApt = need(i++, a);
    else if (a === "--format-event") opts.formatEvent = need(i++, a);
    else if (a === "--format-recur-apt") opts.formatApt = need(i++, a);
    else if (a === "--format-recur-event") opts.formatEvent = need(i++, a);
    else if (a === "--format-todo") opts.formatTodo = need(i++, a);
    else if (a === "-a" || a === "--appointment") { op = "query"; opts.type = "cal"; opts.from = startOfDay(new Date()); opts.days = 1; }
    else if (a === "-n" || a === "--next") { op = "next"; opts.type = "apt"; }
    else if (a.startsWith("-r") && a !== "--range") { op = "query"; opts.type = "cal"; opts.days = +(a.slice(2) || 1); }
    else if (a === "--range") { op = "query"; opts.type = "cal"; opts.days = argv[i + 1] && !argv[i + 1].startsWith("-") ? +argv[++i] : 1; }
    else if (a.startsWith("-t") && a !== "--todo") { op = "query"; opts.type = "todo"; opts.hideCompleted = true; if (a.length > 2) { opts.priority = +a.slice(2); opts.uncompleted = opts.priority !== 0; opts.completed = opts.priority === 0; opts.hideCompleted = opts.priority !== 0; } }
    else if (a === "--todo") { op = "query"; opts.type = "todo"; if (argv[i + 1] && !argv[i + 1].startsWith("-")) opts.priority = +argv[++i]; opts.hideCompleted = true; }
    else if (a === "-d" || a === "--day") { op = "query"; opts.type = "cal"; const v = need(i++, a); if (/^-?\d+$/.test(v)) opts.days = +v; else { const d = parseDateArg(v, opts.inputFmt); if (!d) dieInvalidDate(v); opts.from = d; opts.days = 1; } }
    else if (a.startsWith("-d") && a.length > 2) { op = "query"; opts.type = "cal"; const v = a.slice(2); if (/^-?\d+$/.test(v)) opts.days = +v; }
    else if (a.startsWith("--")) { process.stderr.write(`./executable: unrecognized option '${a}'\n${shortUsage()}`); process.exit(1); }
    else if (a.startsWith("-")) { process.stderr.write(`./executable: invalid option -- '${a[1]}'\n${shortUsage()}`); process.exit(1); }
  }
  return { op, opts };
}
function shortUsage() { return `Usage:
calcurse [-D <directory>] [-C <directory>] [-c <calendar file>]
calcurse -Q [--from <date>] [--to <date>] [--days <number>]
calcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]
calcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon
Try \`calcurse -h' for more information.\n`; }
function dieInvalidDate(s: string) { process.stderr.write(`args.c: 797: invalid date: ${s}\n`); process.exit(1); }

function main() {
  const { op, opts } = parseArgs(process.argv.slice(2));
  if (op === "help") { console.log(HELP); return; }
  if (op === "version") { console.log(VERSION); return; }
  if (op === "status") { console.log("calcurse is not running"); return; }
  if (op === "daemon") return;
  if (op === "gc") return;
  if (op === "import") { importIcal(opts.importFile, opts); return; }
  if (op === "export") {
    if (!["ical", "pcal", undefined].includes(opts.exportFmt)) { process.stderr.write(`args.c: 631: invalid export format: ${opts.exportFmt}\n`); process.exit(1); }
    exportItems(readItems(opts).filter(it => matchesFilters(it, opts)), opts.exportFmt || "ical"); return;
  }
  if (op === "grep") { for (const it of readItems(opts).filter(it => matchesFilters(it, opts))) process.stdout.write(formatItem(it, opts, false) + (formatItem(it, opts, false).endsWith("\n") ? "" : "\n")); return; }
  if (op === "purge") return;
  if (op === "next") {
    const now = new Date();
    const next = (readItems(opts).filter(i => i.kind === "apt") as CalItem[]).filter(i => i.start >= now).sort((a, b) => a.start.getTime() - b.start.getTime())[0];
    if (next) process.stdout.write(`next appointment:\n   [${fmtTime(next.start)}] ${next.msg}\n`);
    return;
  }
  if (op === "query") { query(readItems(opts), opts); return; }
  // A non-interactive stub; enough for scripted tests and avoids curses setup.
  console.log("calcurse 4.8.2");
}
main();
