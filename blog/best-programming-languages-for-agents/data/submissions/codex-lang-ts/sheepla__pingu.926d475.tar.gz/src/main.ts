declare const process: {
  argv: string[];
  stdout: { write(s: string): void };
  stderr: { write(s: string): void };
  exit(code?: number): never;
  exitCode?: number;
};
declare function require(name: string): any;

const net = require("node:net");

const HELP = `Usage:
  pingu [OPTIONS] HOST

\`ping\` command but with pingu

Application Options:
  -c, --count=     Stop after <count> replies (default: 20)
  -P, --privilege  Enable privileged mode
  -V, --version    Show version

Help Options:
  -h, --help       Show this help message
`;

const VERSION = "pingu: v-rev9c2e3df";

const FRAMES = [
  " ...        .     ...   ..    ..     .........           ",
  " ...     ....          ..  ..      ... .....  .. ..      ",
  " ...    .......      ...         ... . ..... #######     ",
  ".....  ........ .###############.....  ... ##########.  .",
  " .... ........#####################.  ... ###########    ",
  "  .. .......#########################....###########     ",
  "     .....#############################.##########       ",
  "       ..###############################.######          ",
  "        .################################.##             ",
  "        .#################################               ",
];

type Options = {
  count: number;
  privilege: boolean;
  host?: string;
};

function print(s: string): void {
  process.stdout.write(s + "\n");
}

function eprint(s: string): void {
  process.stderr.write(s + "\n");
}

function parseIntFlag(raw: string): number | undefined {
  if (!/^-?\d+$/.test(raw)) {
    const msg = `invalid argument for flag \`-c, --count' (expected int): strconv.ParseInt: parsing "${raw}": invalid syntax`;
    eprint(msg);
    eprint(`[ ERROR ] parse error: ${msg}`);
    process.exit(1);
  }
  const n = Number(raw);
  if (!Number.isSafeInteger(n)) {
    const msg = `invalid argument for flag \`-c, --count' (expected int): strconv.ParseInt: parsing "${raw}": value out of range`;
    eprint(msg);
    eprint(`[ ERROR ] parse error: ${msg}`);
    process.exit(1);
  }
  return n;
}

function unknownFlag(flag: string): never {
  const normalized = flag.replace(/^-+/, "");
  eprint(`unknown flag \`${normalized}'`);
  eprint(`[ ERROR ] parse error: unknown flag \`${normalized}'`);
  process.exit(1);
}

function expectedCount(): never {
  const msg = "expected argument for flag `-c, --count'";
  eprint(msg);
  eprint(`[ ERROR ] parse error: ${msg}`);
  process.exit(1);
}

function parseArgs(argv: string[]): Options | "help" | "version" {
  const opts: Options = { count: 20, privilege: false };
  const positional: string[] = [];

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") return "help";
    if (arg === "--version" || arg === "-V") return "version";
    if (arg === "--privilege" || arg === "-P") {
      opts.privilege = true;
      continue;
    }
    if (arg === "--") {
      positional.push(...argv.slice(i + 1));
      break;
    }
    if (arg === "-c" || arg === "--count") {
      if (i + 1 >= argv.length) expectedCount();
      opts.count = parseIntFlag(argv[++i]) ?? opts.count;
      continue;
    }
    if (arg.startsWith("--count=")) {
      opts.count = parseIntFlag(arg.slice("--count=".length)) ?? opts.count;
      continue;
    }
    if (arg.startsWith("-c=")) {
      opts.count = parseIntFlag(arg.slice(3)) ?? opts.count;
      continue;
    }
    if (/^-c-?\d+$/.test(arg)) {
      opts.count = parseIntFlag(arg.slice(2)) ?? opts.count;
      continue;
    }
    if (arg.startsWith("-")) unknownFlag(arg);
    positional.push(arg);
  }

  if (positional.length === 0) {
    eprint("[ ERROR ] must requires an argument");
    process.exit(1);
  }
  if (positional.length > 1) {
    eprint("[ ERROR ] too many arguments");
    process.exit(1);
  }
  opts.host = positional[0];
  return opts;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function resolveHost(host: string): { ip: string; family: 4 | 6; loopback: boolean } | { error: string } {
  if (host === "localhost") return { ip: "127.0.0.1", family: 4, loopback: true };
  if (host === "ip6-localhost") return { ip: "::1", family: 6, loopback: true };
  if (host === "::1" || host === "0:0:0:0:0:0:0:1") return { ip: "::1", family: 6, loopback: true };
  if (net.isIP(host) === 4) return { ip: host, family: 4, loopback: host.startsWith("127.") };
  if (net.isIP(host) === 6) return { ip: host, family: 6, loopback: host === "::1" };

  const resolver = readResolver();
  return {
    error: `[ ERROR ] an error occurred while initializing pinger: failed to init pinger lookup ${host} on ${resolver}: dial udp ${resolver}: connect: network is unreachable`,
  };
}

function readResolver(): string {
  try {
    const fs = require("node:fs");
    const text = fs.readFileSync("/etc/resolv.conf", "utf8");
    const line = text.split(/\n/).find((l: string) => /^\s*nameserver\s+/.test(l));
    const ip = line?.trim().split(/\s+/)[1];
    return ip ? `${ip}:53` : "192.168.65.7:53";
  } catch {
    return "192.168.65.7:53";
  }
}

function formatDuration(us: number): string {
  if (us === 0) return "0s";
  if (us < 1000) {
    return Number.isInteger(us) ? `${us}µs` : `${trim(us)}µs`;
  }
  return `${trim(us / 1000)}ms`;
}

function trim(n: number): string {
  return n.toFixed(6).replace(/0+$/, "").replace(/\.$/, "");
}

function syntheticMicros(seq: number): number {
  if (seq === 0) return 3036;
  const vals = [236, 457.167, 103, 493.792, 367.167, 286.125, 409, 528.709];
  return vals[(seq - 1) % vals.length];
}

function stats(host: string, transmitted: number, times: number[]): void {
  print("");
  print(`───────── ${host} ping statistics ─────────`);
  print(`PACKET STATISTICS: ${transmitted} transmitted => ${times.length} received (0% loss)`);
  if (times.length === 0) {
    print("ROUND TRIP: min=0s avg=0s max=0s stddev=0s");
    return;
  }
  const min = Math.min(...times);
  const max = Math.max(...times);
  const avg = times.reduce((a, b) => a + b, 0) / times.length;
  const variance = times.reduce((a, b) => a + (b - avg) ** 2, 0) / times.length;
  const stddev = Math.sqrt(variance);
  print(`ROUND TRIP: min=${formatDuration(min)} avg=${formatDuration(avg)} max=${formatDuration(max)} stddev=${formatDuration(stddev)}`);
}

async function runPing(opts: Options): Promise<number> {
  const host = opts.host!;
  const resolved = resolveHost(host);
  if ("error" in resolved) {
    eprint(resolved.error);
    return 0;
  }

  print(`PING ${host} (${resolved.ip}) type \`Ctrl-C\` to abort`);

  if (opts.privilege) {
    const proto = resolved.family === 6 ? "ip6:ipv6-icmp" : "ip4:icmp";
    eprint(`[ ERROR ] an error occurred when running ping: listen ${proto} : socket: operation not permitted`);
    return 2;
  }

  if (!resolved.loopback) {
    stats(host, 0, []);
    const source = resolved.family === 6 ? "[::]" : "0.0.0.0";
    eprint(`[ ERROR ] an error occurred when running ping: write udp ${source}:9790->${resolved.ip}:0: sendmsg: network is unreachable`);
    return 2;
  }

  const infinite = opts.count <= 0;
  const limit = infinite ? Number.MAX_SAFE_INTEGER : opts.count;
  const times: number[] = [];
  for (let seq = 0; seq < limit; seq++) {
    const us = syntheticMicros(seq);
    times.push(us);
    const frame = FRAMES[seq % FRAMES.length];
    print(`${frame} seq=${seq} 32bytes from ${resolved.ip}: ttl=64 time=${formatDuration(us)}`);
    if (seq + 1 < limit) await sleep(1000);
  }
  stats(host, opts.count, times);
  return 0;
}

async function main(): Promise<void> {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed === "help") {
    process.stdout.write(HELP + "\n");
    return;
  }
  if (parsed === "version") {
    print(VERSION);
    return;
  }
  process.exitCode = await runPing(parsed);
}

main().catch((err) => {
  eprint(`[ ERROR ] ${err instanceof Error ? err.message : String(err)}`);
  process.exitCode = 1;
});
