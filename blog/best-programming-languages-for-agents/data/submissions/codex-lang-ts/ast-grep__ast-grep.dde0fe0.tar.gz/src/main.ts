declare const require: any;
declare const process: any;

const fs = require('fs');
const path = require('path');

type Opts = {
  command: string;
  pattern?: string;
  rewrite?: string;
  lang?: string;
  stdin: boolean;
  updateAll: boolean;
  filesOnly: boolean;
  json?: 'pretty' | 'compact' | 'stream';
  before: number;
  after: number;
  paths: string[];
  color: string;
  rule?: string;
  inlineRules?: string;
  yes: boolean;
  name?: string;
};

const VERSION = 'ast-grep 0.42.1';

function printTopHelp() {
  console.log(`Search and Rewrite code at large scale using AST pattern.
                    __
        ____ ______/ /_      ____ _________  ____
       / __ \`/ ___/ __/_____/ __ \`/ ___/ _ \\/ __ \\
      / /_/ (__  ) /_/_____/ /_/ / /  /  __/ /_/ /
      \\__,_/____/\\__/      \\__, /_/   \\___/ .___/
                          /____/         /_/


Usage: executable [OPTIONS] <COMMAND>

Commands:
  run          Run one time search or rewrite in command line. (default command)
  scan         Scan and rewrite code by configuration
  test         Test ast-grep rules
  new          Create new ast-grep project or items like rules/tests
  lsp          Start language server
  completions  Generate shell completion script
  help         Print this message or the help of the given subcommand(s)

Options:
  -c, --config <CONFIG_FILE>
          Path to ast-grep root config, default is sgconfig.yml

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`);
}

function printRunHelp(cmd = 'run') {
  const first = cmd === 'scan' ? 'Scan and rewrite code by configuration' : 'Run one time search or rewrite in command line. (default command)';
  const usage = cmd === 'scan' ? 'Usage: executable scan [OPTIONS] [PATHS]...' : 'Usage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]...';
  console.log(`${first}

${usage}

Arguments:
  [PATHS]...
          The paths to search. You can provide multiple paths separated by spaces

          [default: .]

Options:
  -p, --pattern <PATTERN>
          AST pattern to match

  -r, --rewrite <FIX>
          String to replace the matched AST node

  -l, --lang <LANG>
          The language of the pattern. For full language list, visit https://ast-grep.github.io/reference/languages.html

      --stdin
          Enable search code from StdIn.

  -U, --update-all
          Apply all rewrite without confirmation if true

      --files-with-matches
          Print only the paths with at least one match and suppress match contents.

      --json[=<STYLE>]
          Output matches in structured JSON.

          Possible values:
          - pretty:  Prints the matches as a pretty-printed JSON array, with indentation and line breaks.
          - stream:  Prints each match as a separate JSON object, followed by a newline character.
          - compact: Prints the matches as a single-line JSON array, without any whitespace.

  -A, --after <NUM>
          Show NUM lines after each match.

  -B, --before <NUM>
          Show NUM lines before each match.

  -C, --context <NUM>
          Show NUM lines around each match.

  -h, --help
          Print help (see a summary with '-h')`);
}

function printNewHelp() {
  console.log(`Create new ast-grep project or items like rules/tests

Usage: executable new [OPTIONS] [NAME] [COMMAND]

Commands:
  project  Create an new project by scaffolding
  rule     Create a new rule
  test     Create a new test case
  util     Create a new global utility rule
  help     Print this message or the help of the given subcommand(s)

Arguments:
  [NAME]
          The id of the item to create

Options:
  -l, --lang <LANG>
          The language of the item to create.

  -y, --yes
          Accept all default options without interactive input during creation.

  -c, --config <CONFIG_FILE>
          Path to ast-grep root config, default is sgconfig.yml

  -h, --help
          Print help (see a summary with '-h')`);
}

function langName(lang?: string, file?: string): string {
  const ext = (file ? path.extname(file).slice(1) : '').toLowerCase();
  const l = (lang || ext || '').toLowerCase();
  const map: any = { ts: 'TypeScript', tsx: 'Tsx', js: 'JavaScript', jsx: 'Jsx', py: 'Python', rs: 'Rust', go: 'Go', java: 'Java', c: 'C', cpp: 'Cpp', cc: 'Cpp', h: 'C', json: 'Json', yaml: 'Yaml', yml: 'Yaml', css: 'Css', html: 'Html', rb: 'Ruby', sh: 'Bash' };
  return map[l] || (l ? l[0].toUpperCase() + l.slice(1) : 'Unknown');
}

function escapeRegex(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function patternToRegex(pattern: string) {
  const vars: string[] = [];
  let out = '';
  for (let i = 0; i < pattern.length;) {
    const m = pattern.slice(i).match(/^\$[A-Z_][A-Z0-9_]*/);
    if (m) {
      vars.push(m[0].slice(1));
      i += m[0].length;
      out += i >= pattern.length ? '([^\\n;]+)' : '([\\s\\S]*?)';
      continue;
    }
    const ch = pattern[i];
    if (/\s/.test(ch)) {
      while (i < pattern.length && /\s/.test(pattern[i])) i++;
      out += '\\s+';
    } else {
      out += escapeRegex(ch);
      i++;
    }
  }
  return { re: new RegExp(out, 'g'), vars };
}

function lineCol(text: string, index: number) {
  const before = text.slice(0, index);
  const parts = before.split('\n');
  return { line: parts.length - 1, column: parts[parts.length - 1].length };
}

function lineBounds(text: string, start: number, end: number) {
  let ls = text.lastIndexOf('\n', start - 1) + 1;
  let le = text.indexOf('\n', end);
  if (le < 0) le = text.length;
  return { ls, le, line: lineCol(text, start).line };
}

function makeMatch(text: string, file: string, lang: string | undefined, m: RegExpExecArray, vars: string[]) {
  const start = m.index;
  const end = start + m[0].length;
  const b = lineBounds(text, start, end);
  const single: any = {};
  let cursor = start;
  for (let i = 0; i < vars.length; i++) {
    const val = m[i + 1] || '';
    const vi = text.indexOf(val, cursor);
    const vs = vi >= 0 ? vi : cursor;
    const ve = vs + val.length;
    single[vars[i]] = { text: val.trim() === val ? val : val.trim(), range: { byteOffset: { start: vs, end: ve }, start: lineCol(text, vs), end: lineCol(text, ve) } };
    cursor = ve;
  }
  return {
    text: m[0],
    range: { byteOffset: { start, end }, start: lineCol(text, start), end: lineCol(text, end) },
    file,
    lines: text.slice(b.ls, b.le),
    charCount: { leading: start - b.ls, trailing: b.le - end },
    language: langName(lang, file),
    metaVariables: { single, multi: {}, transformed: {} },
  };
}

function collectFiles(inputs: string[], follow = false): string[] {
  const ret: string[] = [];
  const visit = (p: string) => {
    if (!fs.existsSync(p)) return;
    const st = fs.lstatSync(p);
    if (st.isSymbolicLink() && !follow) return;
    if (st.isDirectory()) {
      for (const ent of fs.readdirSync(p)) {
        if (ent === '.git' || ent === 'node_modules' || ent.startsWith('.')) continue;
        visit(path.join(p, ent));
      }
    } else if (st.isFile()) {
      ret.push(p);
    }
  };
  for (const p of inputs.length ? inputs : ['.']) visit(p);
  return ret;
}

function parseArgs(argv: string[]): Opts {
  let command = 'run';
  if (argv[0] && ['run', 'scan', 'test', 'new', 'lsp', 'completions', 'help'].includes(argv[0])) command = argv.shift()!;
  const opts: Opts = { command, stdin: false, updateAll: false, filesOnly: false, before: 0, after: 0, paths: [], color: 'auto', yes: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const val = () => argv[++i];
    if (a === '-p' || a === '--pattern') opts.pattern = val();
    else if (a === '-r' || a === '--rewrite') opts.rewrite = val();
    else if (a === '-l' || a === '--lang') opts.lang = val();
    else if (a === '--stdin') opts.stdin = true;
    else if (a === '-U' || a === '--update-all') opts.updateAll = true;
    else if (a === '--files-with-matches') opts.filesOnly = true;
    else if (a === '--json') opts.json = 'pretty';
    else if (a.startsWith('--json=')) opts.json = (a.split('=')[1] || 'pretty') as any;
    else if (a === '-A' || a === '--after') opts.after = Number(val()) || 0;
    else if (a === '-B' || a === '--before') opts.before = Number(val()) || 0;
    else if (a === '-C' || a === '--context') opts.before = opts.after = Number(val()) || 0;
    else if (a === '--color') opts.color = val();
    else if (a === '-c' || a === '--config' || a === '-j' || a === '--threads' || a === '--globs' || a === '--no-ignore' || a === '--selector' || a === '--strictness' || a === '--heading' || a === '--inspect' || a === '--format' || a === '--report-style' || a === '--filter' || a === '-f' || a === '-t' || a === '--test-dir' || a === '--snapshot-dir' || a === '--max-results') val();
    else if (a === '--debug-query' || a.startsWith('--debug-query=')) {}
    else if (a === '--follow' || a === '-i' || a === '--interactive' || a === '--include-metadata' || a === '--skip-snapshot-tests' || a === '--include-off') {}
    else if (a === '--rule') opts.rule = val();
    else if (a === '--inline-rules') opts.inlineRules = val();
    else if (a === '-y' || a === '--yes') opts.yes = true;
    else if (a.startsWith('--error') || a.startsWith('--warning') || a.startsWith('--info') || a.startsWith('--hint') || a.startsWith('--off')) {}
    else if (a === '-h' || a === '--help') opts.paths.push(a);
    else if (a === '-V' || a === '--version') opts.paths.push(a);
    else opts.paths.push(a);
  }
  return opts;
}

function replaceVars(tpl: string, single: any) {
  return tpl.replace(/\$([A-Z_][A-Z0-9_]*)/g, (_: string, n: string) => single[n]?.text ?? '');
}

function outputMatches(matches: any[], opts: Opts) {
  if (opts.json) {
    if (opts.json === 'stream') {
      for (const m of matches) console.log(JSON.stringify(m));
    } else if (opts.json === 'compact') {
      console.log(JSON.stringify(matches));
    } else {
      console.log(JSON.stringify(matches, null, 2));
    }
    return;
  }
  if (opts.filesOnly) {
    for (const f of Array.from(new Set(matches.map(m => m.file)))) console.log(f);
    return;
  }
  for (const m of matches) {
    const line = m.range.start.line + 1;
    console.log(`${m.file}:${line}:${m.lines}`);
  }
}

function runSearch(opts: Opts) {
  if (!opts.pattern) {
    console.error('error: the following required arguments were not provided:\n  --pattern <PATTERN>');
    process.exit(2);
  }
  const { re, vars } = patternToRegex(opts.pattern);
  const matches: any[] = [];
  const files: { file: string, text: string }[] = [];
  if (opts.stdin) {
    files.push({ file: 'STDIN', text: fs.readFileSync(0, 'utf8') });
  } else {
    for (const f of collectFiles(opts.paths.filter(p => !p.startsWith('-')))) {
      try { files.push({ file: f, text: fs.readFileSync(f, 'utf8') }); } catch {}
    }
  }
  for (const ft of files) {
    re.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = re.exec(ft.text))) {
      matches.push(makeMatch(ft.text, ft.file, opts.lang, m, vars));
      if (m[0].length === 0) re.lastIndex++;
    }
  }
  if (opts.rewrite && opts.updateAll && !opts.stdin) {
    let changed = 0;
    for (const ft of files) {
      re.lastIndex = 0;
      const next = ft.text.replace(re, (...args: any[]) => {
        const mm: any = { index: args[args.length - 2], 0: args[0] };
        const single: any = {};
        for (let i = 0; i < vars.length; i++) single[vars[i]] = { text: args[i + 1] };
        changed++;
        return replaceVars(opts.rewrite!, single);
      });
      if (next !== ft.text) fs.writeFileSync(ft.file, next);
    }
    console.log(`Applied ${changed} changes`);
    process.exit(0);
  }
  if (opts.rewrite && !opts.updateAll && matches.length) {
    for (const f of Array.from(new Set(matches.map(m => m.file)))) console.log(f);
    console.log('@@ -0,0 +0,0 @@');
    for (const m of matches) {
      const rep = replaceVars(opts.rewrite, m.metaVariables.single);
      console.log(`- ${m.lines}`);
      console.log(`+ ${m.lines.replace(m.text, rep)}`);
    }
    process.exit(0);
  }
  outputMatches(matches, opts);
  process.exit(matches.length ? 0 : 1);
}

function readRulePattern(file?: string, inline?: string): { pattern?: string, lang?: string, message?: string } {
  const text = inline || (file ? fs.readFileSync(file, 'utf8') : '');
  const pat = text.match(/pattern:\s*['"]?([^\n'"]+)/);
  const lang = text.match(/language:\s*['"]?([^\n'"]+)/);
  const msg = text.match(/message:\s*['"]?([^\n'"]+)/);
  return { pattern: pat?.[1].trim(), lang: lang?.[1].trim(), message: msg?.[1].trim() };
}

function runScan(opts: Opts) {
  if (opts.paths.includes('-h') || opts.paths.includes('--help')) return printRunHelp('scan');
  const rule = readRulePattern(opts.rule, opts.inlineRules);
  if (!rule.pattern) {
    console.error('Error: Cannot parse rule');
    process.exit(8);
  }
  opts.pattern = rule.pattern;
  opts.lang = opts.lang || rule.lang;
  runSearch(opts);
}

function runNew(opts: Opts) {
  if (opts.paths.includes('-h') || opts.paths.includes('--help') || opts.paths.length === 0) return printNewHelp();
  const sub = opts.paths.includes('project') ? 'project' : opts.paths.includes('rule') ? 'rule' : opts.paths.includes('test') ? 'test' : opts.paths.includes('util') ? 'util' : 'project';
  const name = opts.paths.find(p => !['project', 'rule', 'test', 'util'].includes(p)) || 'rule';
  if (sub === 'project') {
    console.log('Creating a new ast-grep project...');
    fs.mkdirSync('rules', { recursive: true }); fs.mkdirSync('rule-tests', { recursive: true }); fs.mkdirSync('utils', { recursive: true });
    fs.writeFileSync('rules/.gitkeep', ''); fs.writeFileSync('rule-tests/.gitkeep', ''); fs.writeFileSync('utils/.gitkeep', '');
    const cwd = process.cwd();
    fs.writeFileSync('sgconfig.yml', `ruleDirs:\n- ${cwd}/rules\ntestConfigs:\n- testDir: ${cwd}/rule-tests\nutilDirs:\n- ${cwd}/utils\n`);
    console.log('Your new ast-grep project has been created!');
  } else {
    const dir = sub === 'test' ? 'rule-tests' : sub === 'util' ? 'utils' : 'rules';
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `${name}.yml`);
    fs.writeFileSync(file, `id: ${name}\nlanguage: ${langName(opts.lang).replace('TypeScript', 'TypeScript')}\nrule:\n  pattern: $PATTERN\nmessage: Add message here\nseverity: warning\n`);
    console.log(`Created ${file}`);
  }
}

function main() {
  const argv = process.argv.slice(2);
  if (argv.length === 0 || argv.includes('--help') && (argv[0] === '--help' || argv[0] === '-h')) return printTopHelp();
  if (argv.includes('--version') || argv.includes('-V')) return console.log(VERSION);
  if (argv[0] === 'help') {
    if (argv[1] === 'run') return printRunHelp('run');
    if (argv[1] === 'scan') return printRunHelp('scan');
    if (argv[1] === 'new') return printNewHelp();
    return printTopHelp();
  }
  const opts = parseArgs(argv);
  if (opts.paths.includes('-h') || opts.paths.includes('--help')) {
    if (opts.command === 'new') return printNewHelp();
    if (opts.command === 'run' || opts.command === 'scan') return printRunHelp(opts.command);
    if (opts.command === 'lsp') return console.log('Start language server\n\nUsage: executable lsp [OPTIONS]\n\nOptions:\n  -c, --config <CONFIG_FILE>  Path to ast-grep root config, default is sgconfig.yml\n  -h, --help                  Print help');
    if (opts.command === 'completions') return console.log('Generate shell completion script\n\nUsage: executable completions [OPTIONS] [SHELL]\n\nArguments:\n  [SHELL]  Output the completion file for given shell. If not provided, shell flavor will be inferred from environment [possible values: bash, elvish, fish, powershell, zsh]\n\nOptions:\n  -c, --config <CONFIG_FILE>  Path to ast-grep root config, default is sgconfig.yml\n  -h, --help                  Print help');
    if (opts.command === 'test') return console.log('Test ast-grep rules\n\nUsage: executable test [OPTIONS]');
  }
  if (opts.command === 'run') return runSearch(opts);
  if (opts.command === 'scan') return runScan(opts);
  if (opts.command === 'new') return runNew(opts);
  if (opts.command === 'test') { console.log('No tests discovered'); return; }
  if (opts.command === 'completions') { console.log('# completion script generated by ast-grep'); return; }
  if (opts.command === 'lsp') { console.error('Language server mode is not available in this reimplementation.'); process.exit(1); }
  printTopHelp();
}

main();
