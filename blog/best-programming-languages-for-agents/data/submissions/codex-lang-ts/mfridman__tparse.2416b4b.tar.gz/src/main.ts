declare const require: any;
declare const process: any;
const fs = require('fs');

const HELP = `Usage:
    go test ./... -json | tparse [options...]
    go test [packages...] -json | tparse [options...]
    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out

Options:
    -h                 Show help.
    -v                 Show version.
    -all               Display table event for pass and skip. (Failed items always displayed)
    -pass              Display table for passed tests.
    -skip              Display table for skipped tests.
    -notests           Display packages containing no test files or empty test files.
    -smallscreen       Split subtest names vertically to fit on smaller screens.
    -slow              Number of slowest tests to display. Default is 0, display all.
    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.
    -nocolor           Disable all colors. (NO_COLOR also supported)
    -format            The output format for tables [basic, plain, markdown]. Default is basic.
    -file              Read test output from a file.
    -follow            Follow raw output from go test to stdout.
    -follow-output     Write raw output from go test to a file (takes precedence over -follow).
    -include-timestamp Include timestamps in follow output. 
    -progress          Print a single summary line for each package. Useful for long running test suites.
    -compare           Compare against a previous test output file. (experimental)
    -trimpath          Remove path prefix from package names in output, simplifying their display.`;

type GoEvent = {Time?: string, Action?: string, Package?: string, Test?: string, Output?: string, Elapsed?: number};
type TestRec = {pkg:string, name:string, status:string, elapsed:number, output:string[]};
type PkgRec = {name:string, status:string, elapsed:number, cover:string, pass:number, fail:number, skip:number, outputs:string[], tests:Map<string,TestRec>, noTest?:string};

type Opts = {all:boolean, pass:boolean, skip:boolean, notests:boolean, small:boolean, nocolor:boolean, format:string, file?:string, follow:boolean, followOutput?:string, includeTimestamp:boolean, progress:boolean, compare?:string, trimpath?:string, slow:number, sort:string};

function parseArgs(argv:string[]): Opts {
  const o: Opts = {all:false, pass:false, skip:false, notests:false, small:false, nocolor:!!process.env.NO_COLOR, format:'basic', follow:false, includeTimestamp:false, progress:false, slow:0, sort:'name'};
  const needs = new Set(['-file','-format','-follow-output','-compare','-trimpath','-slow','-sort']);
  for (let i=0;i<argv.length;i++) {
    let a = argv[i]; let val: string|undefined;
    if (a.includes('=') && a.startsWith('-')) { const p=a.indexOf('='); val=a.slice(p+1); a=a.slice(0,p); }
    if (a==='-h' || a==='--help') { console.log(HELP); process.exit(0); }
    if (a==='-v' || a==='--version') { console.log('tparse version: (devel)'); process.exit(0); }
    if (needs.has(a)) { if (val===undefined) val=argv[++i]; if (val===undefined) { console.error(`flag needs an argument: ${a}`); console.log(HELP); process.exit(1); } }
    switch(a) {
      case '-all': o.all=true; break; case '-pass': o.pass=true; break; case '-skip': o.skip=true; break;
      case '-notests': o.notests=true; break; case '-smallscreen': o.small=true; break; case '-nocolor': o.nocolor=true; break;
      case '-file': o.file=val; break; case '-format': o.format=val || 'basic'; break; case '-follow': o.follow=true; break;
      case '-follow-output': o.followOutput=val; break; case '-include-timestamp': o.includeTimestamp=true; break; case '-progress': o.progress=true; break;
      case '-compare': o.compare=val; break; case '-trimpath': o.trimpath=val; break; case '-slow': o.slow=parseInt(val||'0',10)||0; break; case '-sort': o.sort=val||'name'; break;
      default: console.error(`flag provided but not defined: ${a}`); console.log(HELP); process.exit(1);
    }
  }
  return o;
}
function pkgName(name:string, o:Opts): string { let n=name||''; if (o.trimpath && n.startsWith(o.trimpath)) n=n.slice(o.trimpath.length); if (o.small) { const parts=n.split('/'); return parts[parts.length-1]||n; } return n; }
function statusOf(a:string): string { return a==='pass'?'PASS':a==='fail'?'FAIL':a==='skip'?'SKIP':a.toUpperCase(); }
function fmtElapsed(n:number, sec=false): string { const v = (Number.isFinite(n)?n:0).toFixed(2); return sec ? v+'s' : v; }
function visualLen(s:string): number { return [...stripAnsi(s)].length; }
function stripAnsi(s:string): string { return String(s).replace(/\x1b\[[0-9;]*m/g,''); }
function center(s:string,w:number): string { const l=visualLen(s); const pad=Math.max(0,w-l); const left=Math.floor(pad/2), right=pad-left; return ' '.repeat(left)+s+' '.repeat(right); }
function color(s:string, code:string, o:Opts): string { return o.nocolor?s:`\x1b[${code}m${s}\x1b[0m`; }
function cStatus(s:string,o:Opts):string { if (s==='FAIL') return color(s,'91',o); if (s==='PASS') return color(s,'92',o); if (s==='SKIP') return color(s,'93',o); return s; }
function getPkg(map:Map<string,PkgRec>, name:string): PkgRec {
  let p=map.get(name); if (!p) { p={name,status:'',elapsed:0,cover:'--',pass:0,fail:0,skip:0,outputs:[],tests:new Map()}; map.set(name,p); } return p;
}
function parseInput(text:string, o:Opts): {pkgs:PkgRec[], events:number} {
  const map = new Map<string,PkgRec>(); let events=0; const followLines:string[]=[];
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let e: GoEvent; try { e=JSON.parse(line); } catch { continue; }
    if (!e || typeof e !== 'object' || !e.Action) continue; events++;
    const p = getPkg(map, e.Package || '');
    if (e.Output !== undefined) {
      p.outputs.push(e.Output);
      const m = e.Output.match(/coverage:\s+([^\s]+)\s+of statements/); if (m) p.cover=m[1];
      const nt = e.Output.match(/\[(no test files|no tests to run)\]/); if (nt) p.noTest='['+nt[1]+']';
      if (e.Test) { let t=p.tests.get(e.Test); if (!t) { t={pkg:p.name,name:e.Test,status:'',elapsed:0,output:[]}; p.tests.set(e.Test,t); } t.output.push(e.Output); }
      if (o.follow || o.followOutput) followLines.push((o.includeTimestamp&&e.Time?e.Time+' ':'')+e.Output);
    }
    if ((e.Action==='pass'||e.Action==='fail'||e.Action==='skip') && e.Test) {
      let t=p.tests.get(e.Test); if (!t) { t={pkg:p.name,name:e.Test,status:'',elapsed:0,output:[]}; p.tests.set(e.Test,t); }
      t.status=statusOf(e.Action); t.elapsed=Number(e.Elapsed||0);
    }
    if ((e.Action==='pass'||e.Action==='fail'||e.Action==='skip') && !e.Test) {
      p.status=statusOf(e.Action); p.elapsed=Number(e.Elapsed||0);
      if (p.noTest && e.Action==='skip') p.status='NOTEST';
      p.pass=0; p.fail=0; p.skip=0;
      for (const t of p.tests.values()) { if (t.status==='PASS') p.pass++; else if (t.status==='FAIL') p.fail++; else if (t.status==='SKIP') p.skip++; }
    }
  }
  if (o.followOutput) fs.writeFileSync(o.followOutput, followLines.join('')); else if (o.follow) process.stdout.write(followLines.join(''));
  return {pkgs:[...map.values()], events};
}
function readAll(file?:string): string { if (file) return fs.readFileSync(file,'utf8'); return fs.readFileSync(0,'utf8'); }

function table(rows:string[][], headers:string[], format:string): string {
  if (!rows.length) return '';
  const all=[headers,...rows]; const widths=headers.map((_,i)=>Math.max(...all.map(r=>visualLen(r[i]??''))));
  if (format==='markdown') {
    const mk = (r:string[])=>'| '+r.map((c,i)=>center(c,widths[i])).join(' | ')+' |';
    return [mk(headers),'|'+widths.map(w=>'-'.repeat(w+2)).join('|')+'|',...rows.map(mk)].join('\n');
  }
  if (format==='plain') {
    const line=(r:string[])=>'  '+r.map((c,i)=>center(c,widths[i]+2)).join(' ')+'  ';
    return [line(headers),'  '+widths.map(w=>' '.repeat(w+2)).join(' ')+'  ',...rows.map(line)].join('\n');
  }
  const top='╭'+widths.map(w=>'─'.repeat(w+2)).join('┬')+'╮';
  const mid='├'+widths.map(w=>'─'.repeat(w+2)).join('┼')+'┤';
  const bot='╰'+widths.map(w=>'─'.repeat(w+2)).join('┴')+'╯';
  const line=(r:string[])=>'│ '+r.map((c,i)=>center(c,widths[i])).join(' │ ')+' │';
  return [top,line(headers),mid,...rows.map(line),bot].join('\n');
}
function banner(pkg:string,o:Opts): string { const inner=`   ${cStatus('FAIL',o)}  package: ${pkg}   `; const w=visualLen(inner); const edge=color('┏'+'━'.repeat(w)+'┓','38;5;103',o); const bot=color('┗'+'━'.repeat(w)+'┛','38;5;103',o); const body=color('┃','38;5;103',o)+inner+color('┃','38;5;103',o); return `${edge}\n${body}\n${bot}`; }
function failureText(p:PkgRec): string {
  let out='';
  for (const t of p.tests.values()) if (t.status==='FAIL') {
    for (const s of t.output) if (!/^=== RUN/.test(s) && !/^--- FAIL/.test(s)) out += s;
  }
  if (!out && p.status==='FAIL' && p.fail===0) {
    for (const s of p.outputs) if (!/^# /.test(s) && !/^FAIL\b/.test(s) && !/coverage:/.test(s)) out += s;
  }
  return out.replace(/\n$/,'');
}
function testRows(pkgs:PkgRec[], o:Opts): string[][] {
  const rows:string[][]=[];
  if (!(o.all || o.pass || o.skip)) return rows;
  const order = o.all ? ['PASS','SKIP','FAIL'] : o.pass ? ['PASS','FAIL'] : ['SKIP','FAIL'];
  for (const want of order) {
    for (const p of pkgs) for (const t of p.tests.values()) {
      if (t.status===want) rows.push([cStatus(t.status,o), fmtElapsed(t.elapsed,false), t.name, pkgName(t.pkg,o)]);
    }
  }
  return rows;
}
function pkgRows(pkgs:PkgRec[], o:Opts, prev?:Map<string,PkgRec>): string[][] {
  const sorted=[...pkgs];
  if (o.sort==='elapsed') sorted.sort((a,b)=>b.elapsed-a.elapsed);
  else if (o.sort==='cover') sorted.sort((a,b)=>parseFloat(b.cover)-parseFloat(a.cover));
  else sorted.sort((a,b)=>pkgName(a.name,o).localeCompare(pkgName(b.name,o)));
  const rows:string[][]=[];
  for (const p of sorted) {
    if (p.status==='NOTEST' && !o.notests) continue;
    if (!p.status && p.tests.size===0) continue;
    let cover=p.cover || '--';
    if (cover==='--' || !cover) cover='--';
    if (o.compare) {
      const old=prev?.get(p.name); let suffix='-';
      if (old && old.cover && old.cover!=='--' && p.cover && p.cover!=='--') {
        const d=parseFloat(p.cover)-parseFloat(old.cover); suffix=(d>=0?'+':'')+d.toFixed(1)+'%';
      }
      cover = `${cover} (${suffix})`;
    }
    if (p.status==='NOTEST') rows.push(['NOTEST',fmtElapsed(p.elapsed,true),pkgName(p.name,o),cover,'--','--','--'], ['', '', p.noTest||'[no test files]', '', '', '', '']);
    else rows.push([cStatus(p.status||'PASS',o),fmtElapsed(p.elapsed,true),pkgName(p.name,o),cover, String(p.pass), String(p.fail), String(p.skip)]);
  }
  return rows;
}
function renderMarkdown(pkgs:PkgRec[], o:Opts, prev?:Map<string,PkgRec>): string {
  const parts:string[]=[];
  for (const p of pkgs) {
    const rows = testRows([p], {...o, small:true});
    if (rows.length) parts.push(`## 📦 Package **\`${p.name}\`**\n\nTests: ✓ ${p.pass} passed | ${p.skip} skipped | ${p.fail} failed\n\n<details>\n\n<summary>Click for test summary</summary>\n\n${table(rows.map(r=>r.slice(0,3)), ['Status','Elapsed','Test'], 'markdown')}\n</details>\n`);
    if (p.fail>0) parts.push(`\n## FAIL • ${p.name}\n\n\`\`\`\n${failureText(p)}\n\n\`\`\`\n`);
  }
  const pr=pkgRows(pkgs,o,prev); if (pr.length) parts.push(table(pr,['Status','Elapsed','Package','Cover','Pass','Fail','Skip'],'markdown'));
  return parts.join('\n');
}
function render(pkgs:PkgRec[], o:Opts, prev?:Map<string,PkgRec>): string {
  if (o.progress) for (const p of pkgs) if (p.status && p.status!=='NOTEST') console.log(`[${p.status}]\t${fmtElapsed(p.elapsed,true).padStart(9)}\t${pkgName(p.name,o)}`);
  if (o.format==='markdown') return renderMarkdown(pkgs,o,prev);
  const parts:string[]=[]; const tr=testRows(pkgs,o); if (tr.length) parts.push(table(tr,['Status','Elapsed','Test','Package'],o.format));
  for (const p of pkgs) if (p.fail>0) parts.push(banner(p.name,o)+'\n\n\n'+failureText(p));
  const pr=pkgRows(pkgs,o,prev); if (pr.length) parts.push(table(pr,['Status','Elapsed','Package','Cover','Pass','Fail','Skip'],o.format));
  return parts.filter(Boolean).join('\n');
}
function main() {
  const o=parseArgs(process.argv.slice(2)); let text='';
  try { text=readAll(o.file); } catch(e:any) { console.error(e.message || String(e)); process.exit(1); }
  const parsed=parseInput(text,o); if (parsed.events===0) { console.error('no parsable events: Make sure to run go test with -json flag'); process.exit(1); }
  let prev:Map<string,PkgRec>|undefined;
  if (o.compare) { try { prev = new Map(parseInput(fs.readFileSync(o.compare,'utf8'), {...o, follow:false, followOutput:undefined}).pkgs.map(p=>[p.name,p])); } catch {} }
  const out=render(parsed.pkgs,o,prev); if (out) console.log(out);
  const failed=parsed.pkgs.some(p=>p.status==='FAIL'||p.fail>0); process.exit(failed?1:0);
}
main();
