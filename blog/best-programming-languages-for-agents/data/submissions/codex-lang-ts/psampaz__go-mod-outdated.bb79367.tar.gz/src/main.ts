declare const require: (name: string) => { readFileSync: (fd: number, encoding: string) => string };
declare const process: {
  argv: string[];
  env: { [key: string]: string | undefined };
  stderr: { write: (s: string) => void };
  stdout: { write: (s: string) => void };
  exit: (code?: number) => never;
};

const fs = require("fs");

type ModuleInfo = {
  Path?: string;
  Version?: string;
  Time?: string;
  Main?: boolean;
  Indirect?: boolean;
  Update?: {
    Path?: string;
    Version?: string;
    Time?: string;
  };
};

type Options = {
  ci: boolean;
  direct: boolean;
  update: boolean;
  style: string;
};

const headers = ["MODULE", "VERSION", "NEW VERSION", "DIRECT", "VALID TIMESTAMPS"];

function usage(): string {
  const arg0 = process.env.GMO_ARG0 || process.argv[1] || "executable";
  return `Usage of ${arg0}:\n` +
    `  -ci\n` +
    `    \tNon-zero exit code when at least one outdated dependency was found\n` +
    `  -direct\n` +
    `    \tList only direct modules\n` +
    `  -style string\n` +
    `    \tOutput style, pass 'markdown' for a Markdown table (default "default")\n` +
    `  -update\n` +
    `    \tList only modules with updates\n`;
}

function parseArgs(argv: string[]): Options | undefined {
  const opts: Options = { ci: false, direct: false, update: false, style: "default" };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "-h" || arg === "-help" || arg === "--help") {
      process.stderr.write(usage());
      process.exit(0);
    }
    if (arg === "-ci" || arg === "-ci=true") opts.ci = true;
    else if (arg === "-ci=false") opts.ci = false;
    else if (arg === "-direct" || arg === "-direct=true") opts.direct = true;
    else if (arg === "-direct=false") opts.direct = false;
    else if (arg === "-update" || arg === "-update=true") opts.update = true;
    else if (arg === "-update=false") opts.update = false;
    else if (arg === "-style") {
      if (i + 1 >= argv.length) {
        process.stderr.write("flag needs an argument: -style\n" + usage());
        process.exit(2);
      }
      opts.style = argv[++i];
    } else if (arg.startsWith("-style=")) {
      opts.style = arg.slice("-style=".length);
    } else if (arg.startsWith("-")) {
      process.stderr.write(`flag provided but not defined: ${arg}\n` + usage());
      process.exit(2);
    } else {
      process.stderr.write(`flag provided but not defined: ${arg}\n` + usage());
      process.exit(2);
    }
  }
  return opts;
}

function logLine(message: string): void {
  const d = new Date();
  const pad = (n: number) => n.toString().padStart(2, "0");
  const stamp = `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  process.stderr.write(`${stamp} ${message}\n`);
}

function splitJsonObjects(input: string): string[] {
  const out: string[] = [];
  let depth = 0;
  let start = -1;
  let inString = false;
  let escape = false;

  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (inString) {
      if (escape) escape = false;
      else if (ch === "\\") escape = true;
      else if (ch === "\"") inString = false;
      continue;
    }
    if (ch === "\"") {
      inString = true;
      continue;
    }
    if (ch === "{") {
      if (depth === 0) start = i;
      depth++;
    } else if (ch === "}") {
      depth--;
      if (depth === 0 && start >= 0) {
        out.push(input.slice(start, i + 1));
        start = -1;
      }
    }
  }

  const trailing = input.trim();
  if (out.length === 0 && trailing.length > 0) {
    out.push(trailing);
  }
  return out;
}

function parseModules(input: string): ModuleInfo[] | undefined {
  if (input.trim() === "") return [];
  const modules: ModuleInfo[] = [];
  for (const part of splitJsonObjects(input)) {
    try {
      modules.push(JSON.parse(part) as ModuleInfo);
    } catch (err) {
      logLine(err instanceof Error ? err.message : String(err));
      return undefined;
    }
  }
  return modules;
}

function parseGoTime(value: string | undefined): Date {
  if (!value) {
    return new Date(0);
  }
  const normalized = value.replace(/\.(\d{3})\d+(Z|[+-]\d\d:\d\d)$/, ".$1$2");
  const d = new Date(normalized);
  if (Number.isNaN(d.getTime())) {
    throw new Error(`parsing time "${value}" as "2006-01-02T15:04:05Z07:00": cannot parse "${value}" as "2006"`);
  }
  return d;
}

function validTimestamps(module: ModuleInfo): boolean {
  if (!module.Update) return true;
  const current = parseGoTime(module.Time);
  const update = parseGoTime(module.Update.Time);
  return update.getTime() > current.getTime();
}

function filteredRows(modules: ModuleInfo[], opts: Options): string[][] | undefined {
  const rows: string[][] = [];
  for (const m of modules) {
    if (m.Main) continue;
    if (opts.direct && m.Indirect) continue;
    if (opts.update && !m.Update) continue;
    let valid: boolean;
    try {
      valid = validTimestamps(m);
    } catch (err) {
      logLine(err instanceof Error ? err.message : String(err));
      return undefined;
    }
    rows.push([
      m.Path || "",
      m.Version || "",
      m.Update?.Version || "",
      (!m.Indirect).toString(),
      valid.toString(),
    ]);
  }
  return rows;
}

function center(value: string, width: number): string {
  const extra = width - value.length;
  const left = Math.floor(extra / 2);
  const right = extra - left;
  return " ".repeat(left) + value + " ".repeat(right);
}

function left(value: string, width: number): string {
  return value + " ".repeat(width - value.length);
}

function widths(rows: string[][]): number[] {
  return headers.map((h, i) => Math.max(h.length, ...rows.map((r) => r[i].length)));
}

function separator(ws: number[]): string {
  return "+" + ws.map((w) => "-".repeat(w + 2)).join("+") + "+\n";
}

function renderDefault(rows: string[][]): string {
  if (rows.length === 0) return "";
  const ws = widths(rows);
  let out = separator(ws);
  out += "|" + headers.map((h, i) => ` ${center(h, ws[i])} `).join("|") + "|\n";
  out += separator(ws);
  for (const r of rows) {
    out += "|" + r.map((v, i) => ` ${left(v, ws[i])} `).join("|") + "|\n";
  }
  out += separator(ws);
  return out;
}

function renderMarkdown(rows: string[][]): string {
  if (rows.length === 0) return "";
  const ws = widths(rows);
  let out = "|" + headers.map((h, i) => ` ${center(h, ws[i])} `).join("|") + "|\n";
  out += "|" + ws.map((w) => "-".repeat(w + 2)).join("|") + "|\n";
  for (const r of rows) {
    out += "|" + r.map((v, i) => ` ${left(v, ws[i])} `).join("|") + "|\n";
  }
  return out;
}

function main(): void {
  const opts = parseArgs(process.argv.slice(2))!;
  const input = fs.readFileSync(0, "utf8");
  const modules = parseModules(input);
  if (!modules) return;
  const rows = filteredRows(modules, opts);
  if (!rows) return;
  process.stdout.write(opts.style === "markdown" ? renderMarkdown(rows) : renderDefault(rows));
  if (opts.ci && rows.some((r) => r[2] !== "")) {
    process.exit(1);
  }
}

main();
