declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

type Match = { lineNo: number; text: string; ranges: Array<[number, number]> };

type Opts = {
  after: number;
  before: number;
  color: boolean;
  column: boolean;
  count: boolean;
  depth: number;
  fileRegex?: RegExp;
  filenamePattern?: string;
  filesWithMatches: boolean;
  filesWithoutMatches: boolean;
  fixed: boolean;
  follow: boolean;
  heading: boolean;
  hidden: boolean;
  ignoreCase?: boolean;
  ignores: string[];
  invert: boolean;
  literal: boolean;
  maxCount: number;
  noFilename?: boolean;
  noNumbers?: boolean;
  onlyMatching: boolean;
  passthrough: boolean;
  print0: boolean;
  printAllFiles: boolean;
  printLongLines: boolean;
  recurse: boolean;
  searchBinary: boolean;
  searchZip: boolean;
  silent: boolean;
  smartCase: boolean;
  stats: boolean;
  statsOnly: boolean;
  typeExts?: Set<string>;
  unrestricted: boolean;
  vimgrep: boolean;
  word: boolean;
  paths: string[];
  pattern?: string;
};

const HELP = `
Usage: ag [FILE-TYPE] [OPTIONS] PATTERN [PATH]

  Recursively search for PATTERN in PATH.
  Like grep or ack, but faster.

Example:
  ag -i foo /bar/

Output Options:
     --ackmate            Print results in AckMate-parseable format
  -A --after [LINES]      Print lines after match (Default: 2)
  -B --before [LINES]     Print lines before match (Default: 2)
     --[no]break          Print newlines between matches in different files
                          (Enabled by default)
  -c --count              Only print the number of matches in each file.
                          (This often differs from the number of matching lines)
     --[no]color          Print color codes in results (Enabled by default)
     --color-line-number  Color codes for line numbers (Default: 1;33)
     --color-match        Color codes for result match numbers (Default: 30;43)
     --color-path         Color codes for path names (Default: 1;32)
     --column             Print column numbers in results
     --[no]filename       Print file names (Enabled unless searching a single file)
  -H --[no]heading        Print file names before each file's matches
                          (Enabled by default)
  -C --context [LINES]    Print lines before and after matches (Default: 2)
     --[no]group          Same as --[no]break --[no]heading
  -g --filename-pattern PATTERN
                          Print filenames matching PATTERN
  -l --files-with-matches Only print filenames that contain matches
                          (don't print the matching lines)
  -L --files-without-matches
                          Only print filenames that don't contain matches
     --print-all-files    Print headings for all files searched, even those that
                          don't contain matches
     --[no]numbers        Print line numbers. Default is to omit line numbers
                          when searching streams
  -o --only-matching      Prints only the matching part of the lines
     --print-long-lines   Print matches on very long lines (Default: >2k characters)
     --passthrough        When searching a stream, print all lines even if they
                          don't match
     --silent             Suppress all log messages, including errors
     --stats              Print stats (files scanned, time taken, etc.)
     --stats-only         Print stats and nothing else.
                          (Same as --count when searching a single file)
     --vimgrep            Print results like vim's :vimgrep /pattern/g would
                          (it reports every match on the line)
  -0 --null --print0      Separate filenames with null (for 'xargs -0')

Search Options:
  -a --all-types          Search all files (doesn't include hidden files
                          or patterns from ignore files)
  -D --debug              Ridiculous debugging (probably not useful)
     --depth NUM          Search up to NUM directories deep (Default: 25)
  -f --follow             Follow symlinks
  -F --fixed-strings      Alias for --literal for compatibility with grep
  -G --file-search-regex  PATTERN Limit search to filenames matching PATTERN
     --hidden             Search hidden files (obeys .*ignore files)
  -i --ignore-case        Match case insensitively
     --ignore PATTERN     Ignore files/directories matching PATTERN
                          (literal file/directory names also allowed)
     --ignore-dir NAME    Alias for --ignore for compatibility with ack.
  -m --max-count NUM      Skip the rest of a file after NUM matches (Default: 10,000)
     --one-device         Don't follow links to other devices.
  -p --path-to-ignore STRING
                          Use .ignore file at STRING
  -Q --literal            Don't parse PATTERN as a regular expression
  -s --case-sensitive     Match case sensitively
  -S --smart-case         Match case insensitively unless PATTERN contains
                          uppercase characters (Enabled by default)
     --search-binary      Search binary files for matches
  -t --all-text           Search all text files (doesn't include hidden files)
  -u --unrestricted       Search all files (ignore .ignore, .gitignore, etc.;
                          searches binary and hidden files as well)
  -U --skip-vcs-ignores   Ignore VCS ignore files
                          (.gitignore, .hgignore; still obey .ignore)
  -v --invert-match
  -w --word-regexp        Only match whole words
  -W --width NUM          Truncate match lines after NUM characters
  -z --search-zip         Search contents of compressed (e.g., gzip) files

File Types:
The search can be restricted to certain types of files. Example:
  ag --html needle
  - Searches for 'needle' in files with suffix .htm, .html, .shtml or .xhtml.

For a list of supported file types run:
  ag --list-file-types

ag was originally created by Geoff Greer. More information (and the latest release)
can be found at http://geoff.greer.fm/ag
`;

const TYPE_EXTS: Record<string, string[]> = {
  actionscript: [".as", ".mxml"], ada: [".ada", ".adb", ".ads"],
  asciidoc: [".adoc", ".ad", ".asc", ".asciidoc"], asm: [".asm", ".s"],
  asp: [".asp", ".asa", ".aspx", ".asax", ".ashx", ".ascx", ".asmx"],
  aspx: [".asp", ".asa", ".aspx", ".asax", ".ashx", ".ascx", ".asmx"],
  batch: [".bat", ".cmd"], bazel: [".bazel"], cc: [".c", ".h", ".xs"],
  cpp: [".cpp", ".cc", ".C", ".cxx", ".m", ".hpp", ".hh", ".h", ".H", ".hxx", ".tpp"],
  csharp: [".cs"], css: [".css"], elisp: [".el"], elixir: [".ex", ".eex", ".exs"],
  erlang: [".erl", ".hrl"], go: [".go"], groovy: [".groovy", ".gradle"],
  haskell: [".hs", ".lhs"], html: [".htm", ".html", ".shtml", ".xhtml"],
  java: [".java", ".properties"], js: [".js", ".jsx", ".vue"], json: [".json"],
  kotlin: [".kt", ".kts"], lua: [".lua"], make: ["Makefile", "makefile", ".mk"],
  markdown: [".md", ".markdown", ".mkd"], objc: [".m", ".h"], perl: [".pl", ".pm", ".pod", ".t"],
  php: [".php", ".phpt", ".php3", ".php4", ".php5", ".phtml"], python: [".py"],
  ruby: [".rb", ".rhtml", ".rake", ".gemspec"], rust: [".rs"],
  scala: [".scala"], shell: [".sh", ".bash", ".csh", ".tcsh", ".ksh", ".zsh", ".fish"],
  sql: [".sql"], swift: [".swift"], tex: [".tex", ".cls", ".sty"], ts: [".ts", ".tsx"],
  xml: [".xml", ".dtd", ".xsl", ".xslt", ".ent"], yaml: [".yaml", ".yml"]
};

function die(msg: string, code = 2): never {
  process.stderr.write(msg + "\n");
  process.exit(code);
  throw new Error(msg);
}

function defaultOpts(): Opts {
  return {
    after: 0, before: 0, color: false, column: false, count: false, depth: 25,
    filesWithMatches: false, filesWithoutMatches: false, fixed: false,
    follow: false, heading: false, hidden: false, ignores: [], invert: false,
    literal: false, maxCount: 10000, onlyMatching: false, passthrough: false,
    print0: false, printAllFiles: false, printLongLines: false, recurse: true,
    searchBinary: false, searchZip: false, silent: false, smartCase: true,
    stats: false, statsOnly: false, unrestricted: false, vimgrep: false,
    word: false, paths: []
  };
}

function parseArgs(argv: string[]): Opts | "exit" {
  const o = defaultOpts();
  const positional: string[] = [];
  let endOpts = false;
  function need(i: number, opt: string) {
    if (i + 1 >= argv.length) die(`ERR: Expected value after ${opt}`);
    return argv[i + 1];
  }
  function optionalNum(i: number, fallback: number): [number, number] {
    if (i + 1 < argv.length && /^-?\d+$/.test(argv[i + 1])) return [parseNum(argv[i + 1], fallback), i + 1];
    return [fallback, i];
  }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (endOpts || !a.startsWith("-") || a === "-") {
      positional.push(a);
      continue;
    }
    if (a === "--") { endOpts = true; continue; }
    if (a === "--help" || a === "-h") { process.stdout.write(HELP); return "exit"; }
    if (a === "--version" || a === "-V") {
      process.stdout.write("ag version 2.2.0\n\nFeatures:\n  +jit +lzma +zlib\n");
      return "exit";
    }
    if (/^-[ABC]\d+$/.test(a)) {
      const n = parseNum(a.slice(2), 2);
      if (a[1] === "A") o.after = n;
      else if (a[1] === "B") o.before = n;
      else { o.before = n; o.after = n; }
      continue;
    }
    if (a === "--list-file-types") { printTypes(); return "exit"; }
    if (TYPE_EXTS[a.slice(2)]) { o.typeExts = new Set(TYPE_EXTS[a.slice(2)]); continue; }
    if (a === "-A" || a === "--after") { const r = optionalNum(i, 2); o.after = r[0]; i = r[1]; continue; }
    if (a === "-B" || a === "--before") { const r = optionalNum(i, 2); o.before = r[0]; i = r[1]; continue; }
    if (a === "-C" || a === "--context") { const r = optionalNum(i, 2); o.before = r[0]; o.after = r[0]; i = r[1]; continue; }
    if (a === "-W" || a === "--width") { i++; continue; }
    if (a === "-m" || a === "--max-count") { o.maxCount = parseNum(need(i++, a), 0); continue; }
    if (a === "--depth") { o.depth = parseNum(need(i++, a), 25); continue; }
    if (a === "-G" || a === "--file-search-regex") { o.fileRegex = new RegExp(need(i++, a)); continue; }
    if (a === "-g" || a === "--filename-pattern") { o.filenamePattern = need(i++, a); continue; }
    if (a === "--ignore" || a === "--ignore-dir") { o.ignores.push(need(i++, a)); continue; }
    if (a === "-p" || a === "--path-to-ignore" || a === "--workers" || a === "--pager") { i++; continue; }
    if (a === "-a" || a === "--all-types" || a === "-t" || a === "--all-text") { o.ignores = ["__DISABLE_DEFAULT_IGNORES__"]; continue; }
    if (a === "-c" || a === "--count") { o.count = true; continue; }
    if (a === "--column") { o.column = true; continue; }
    if (a === "-f" || a === "--follow") { o.follow = true; continue; }
    if (a === "-F" || a === "--fixed-strings" || a === "-Q" || a === "--literal") { o.literal = true; o.fixed = true; continue; }
    if (a === "-H" || a === "--heading" || a === "--group") { o.heading = true; continue; }
    if (a === "--noheading" || a === "--no-heading" || a === "--nogroup" || a === "--no-group" || a === "--nobreak" || a === "--no-break") { o.heading = false; continue; }
    if (a === "--filename") { o.noFilename = false; continue; }
    if (a === "--nofilename" || a === "--no-filename") { o.noFilename = true; continue; }
    if (a === "--hidden") { o.hidden = true; continue; }
    if (a === "-i" || a === "--ignore-case") { o.ignoreCase = true; o.smartCase = false; continue; }
    if (a === "-s" || a === "--case-sensitive") { o.ignoreCase = false; o.smartCase = false; continue; }
    if (a === "-S" || a === "--smart-case") { o.smartCase = true; continue; }
    if (a === "-l" || a === "--files-with-matches") { o.filesWithMatches = true; continue; }
    if (a === "-L" || a === "--files-without-matches") { o.filesWithoutMatches = true; continue; }
    if (a === "-n" || a === "--norecurse") { o.recurse = false; continue; }
    if (a === "-o" || a === "--only-matching") { o.onlyMatching = true; continue; }
    if (a === "--numbers") { o.noNumbers = false; continue; }
    if (a === "--nonumbers") { o.noNumbers = true; continue; }
    if (a === "--print-all-files") { o.printAllFiles = true; continue; }
    if (a === "--print-long-lines") { o.printLongLines = true; continue; }
    if (a === "--passthrough" || a === "--passthru") { o.passthrough = true; continue; }
    if (a === "--nocolor" || a === "--no-color" || a === "--color=never") { o.color = false; continue; }
    if (a === "--color" || a === "--color=always") { o.color = true; continue; }
    if (a === "--silent") { o.silent = true; continue; }
    if (a === "--stats") { o.stats = true; continue; }
    if (a === "--stats-only") { o.stats = true; o.statsOnly = true; continue; }
    if (a === "-u" || a === "--unrestricted") { o.unrestricted = true; o.hidden = true; o.searchBinary = true; o.ignores = ["__DISABLE_DEFAULT_IGNORES__"]; continue; }
    if (a === "-U" || a === "--skip-vcs-ignores") { continue; }
    if (a === "-v" || a === "--invert-match") { o.invert = true; continue; }
    if (a === "--vimgrep") { o.vimgrep = true; o.heading = false; o.column = true; continue; }
    if (a === "-w" || a === "--word-regexp") { o.word = true; continue; }
    if (a === "-z" || a === "--search-zip") { o.searchZip = true; continue; }
    if (a === "-0" || a === "--null" || a === "--print0") { o.print0 = true; continue; }
    if (a === "--search-binary") { o.searchBinary = true; continue; }
    if (a === "-D" || a === "--debug" || a === "--one-device" || a === "--parallel" || a === "--ackmate" || a === "--mmap" || a === "--nommap" || a === "--multiline" || a === "--nomultiline" || a === "--affinity" || a === "--noaffinity" || a === "--recurse") { continue; }
    if (a.startsWith("--color-")) { i++; continue; }
    die(`ERR: Unknown option: ${a}`);
  }
  if (o.filenamePattern !== undefined) {
    o.pattern = o.filenamePattern;
    o.paths = positional.length ? positional : ["."];
    return o;
  }
  if (positional.length === 0) die("ERR: No pattern specified");
  o.pattern = positional[0];
  o.paths = positional.slice(1);
  if (o.paths.length === 0) o.paths = fs.fstatSync(0).isFIFO() ? [] : ["."];
  return o;
}

function parseNum(s: string, fallback: number): number {
  const n = Number.parseInt(s, 10);
  return Number.isFinite(n) ? n : fallback;
}

function printTypes() {
  process.stdout.write("The following file types are supported:\n");
  for (const k of Object.keys(TYPE_EXTS).sort()) {
    process.stdout.write(`  --${k}\n      ${TYPE_EXTS[k].join("  ")}\n\n`);
  }
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function makeRegex(o: Opts): RegExp {
  let source = o.literal ? escapeRegExp(o.pattern || "") : (o.pattern || "");
  if (o.word) source = `\\b(?:${source})\\b`;
  const ignore = o.ignoreCase !== undefined ? o.ignoreCase : (o.smartCase && !/[A-Z]/.test(o.pattern || ""));
  try {
    return new RegExp(source, "g" + (ignore ? "i" : ""));
  } catch (_e) {
    die(`ERR: Bad regex! pcre_compile() failed\nIf you meant to search for a literal string, run ag with -Q`);
  }
}

function loadIgnoreFiles(dir: string, disabled: boolean): string[] {
  if (disabled) return [];
  const pats: string[] = [];
  for (const n of [".ignore", ".gitignore", ".hgignore"]) {
    const p = path.join(dir, n);
    try {
      const text = fs.readFileSync(p, "utf8");
      for (const line of text.split(/\r?\n/)) {
        const t = line.trim();
        if (t && !t.startsWith("#")) pats.push(t);
      }
    } catch {}
  }
  return pats;
}

function ignored(name: string, rel: string, patterns: string[]): boolean {
  for (const p of patterns) {
    const pat = p.replace(/^\//, "").replace(/\/$/, "");
    if (pat === name || pat === rel) return true;
    const re = new RegExp("^" + escapeRegExp(pat).replace(/\\\*/g, ".*").replace(/\\\?/g, ".") + "$");
    if (re.test(name) || re.test(rel)) return true;
  }
  return false;
}

function isBinary(buf: any): boolean {
  const n = Math.min(buf.length, 4096);
  for (let i = 0; i < n; i++) if (buf[i] === 0) return true;
  return false;
}

function displayPath(file: string, roots: string[]): string {
  const rel = path.relative(process.cwd(), file);
  return rel || path.basename(file);
}

function collectFiles(o: Opts): string[] {
  const files: string[] = [];
  const disabledIgnores = o.ignores.includes("__DISABLE_DEFAULT_IGNORES__");
  const extraIgnores = o.ignores.filter(x => x !== "__DISABLE_DEFAULT_IGNORES__");
  function visit(p: string, depth: number, inherited: string[]) {
    let st;
    try { st = o.follow ? fs.statSync(p) : fs.lstatSync(p); }
    catch (e: any) {
      if (!o.silent) {
        process.stderr.write(`ERR: Error stat()ing: ${p}\n`);
        process.stderr.write(`ERR: Error opening directory ${p}: ${e.message}\n`);
      }
      return;
    }
    const base = path.basename(p);
    if (depth > 0 && !o.hidden && base.startsWith(".") && base !== "." && base !== "..") return;
    const rel = path.relative(process.cwd(), p) || base;
    if (depth > 0 && ignored(base, rel, inherited.concat(extraIgnores))) return;
    if (st.isDirectory()) {
      if (!o.recurse && depth > 0) return;
      if (depth > o.depth && o.depth >= 0) return;
      const localIgnores = inherited.concat(loadIgnoreFiles(p, disabledIgnores));
      let entries: string[] = [];
      try { entries = fs.readdirSync(p); } catch { return; }
      for (const e of entries) visit(path.join(p, e), depth + 1, localIgnores);
    } else if (st.isFile()) {
      if (o.typeExts) {
        const ext = path.extname(p);
        const bn = path.basename(p);
        if (!o.typeExts.has(ext) && !o.typeExts.has(bn)) return;
      }
      if (o.fileRegex && !o.fileRegex.test(p)) return;
      files.push(p);
    }
  }
  for (const p of o.paths.length ? o.paths : []) visit(path.resolve(p), 0, []);
  return files;
}

function readFileMaybe(file: string, o: Opts): string | undefined {
  try {
    let buf = fs.readFileSync(file);
    if (o.searchZip && file.endsWith(".gz")) buf = zlib.gunzipSync(buf);
    if (!o.searchBinary && isBinary(buf)) return undefined;
    return buf.toString("utf8");
  } catch (e: any) {
    if (!o.silent) process.stderr.write(`ERR: Error opening file ${file}: ${e.message}\n`);
    return undefined;
  }
}

function findMatches(text: string, re: RegExp, o: Opts): Match[] {
  const lines = text.split(/\n/);
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  const out: Match[] = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].replace(/\r$/, "");
    if (!o.printLongLines && line.length > 2000) continue;
    const ranges: Array<[number, number]> = [];
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(line)) !== null) {
      const s = m.index;
      const e = s + (m[0].length || 1);
      ranges.push([s, e]);
      if (m[0].length === 0) re.lastIndex++;
      if (!o.vimgrep && !o.onlyMatching && !o.count) break;
    }
    const matched = ranges.length > 0;
    if ((matched && !o.invert) || (!matched && o.invert)) {
      out.push({ lineNo: i + 1, text: line, ranges: matched ? ranges : [[0, 0]] });
      if (o.maxCount > 0 && out.length >= o.maxCount) break;
    }
  }
  return out;
}

function linePrefix(file: string | undefined, lineNo: number, col?: number, showFile = false, numbers = true, sep = ":"): string {
  let s = "";
  if (showFile && file) s += file + ":";
  if (numbers) s += `${lineNo}${sep}`;
  if (col !== undefined) s += `${col}:`;
  return s;
}

function printSearchResult(file: string | undefined, text: string, matches: Match[], o: Opts, manyFiles: boolean): number {
  const showFile = !!file && !o.noFilename && (manyFiles || o.noFilename === false || o.vimgrep);
  const numbers = !o.noNumbers && (!!file || o.noNumbers === false);
  const name = file;
  if (o.filesWithMatches || o.filesWithoutMatches) {
    const yes = matches.length > 0;
    if ((yes && o.filesWithMatches) || (!yes && o.filesWithoutMatches)) {
      process.stdout.write((name || "") + (o.print0 ? "\0" : "\n"));
    }
    return matches.length;
  }
  if (o.count || o.statsOnly) {
    const c = matches.reduce((n, m) => n + (o.vimgrep ? m.ranges.length : Math.max(1, m.ranges.length)), 0);
    if (!o.statsOnly) process.stdout.write((showFile ? `${name}:` : "") + `${c}\n`);
    return c;
  }
  if (o.printAllFiles && name) process.stdout.write(`${name}\n`);
  if (matches.length === 0 && !o.passthrough) return 0;
  const lineMap = new Map<number, { text: string; match?: Match }>();
  const lines = text.split(/\n/).map((l: string) => l.replace(/\r$/, ""));
  for (const m of matches) {
    for (let n = Math.max(1, m.lineNo - o.before); n <= Math.min(lines.length, m.lineNo + o.after); n++) {
      const existing = lineMap.get(n);
      const current = { text: lines[n - 1], match: n === m.lineNo ? m : undefined };
      if (!existing || current.match || !existing.match) lineMap.set(n, existing?.match && !current.match ? existing : current);
    }
  }
  if (o.passthrough) for (let i = 1; i <= lines.length; i++) if (!lineMap.has(i)) lineMap.set(i, { text: lines[i - 1] });
  if (o.heading && name && !o.vimgrep) process.stdout.write(`${name}\n`);
  const ordered = [...lineMap.entries()].sort((a, b) => a[0] - b[0]);
  for (const [lineNo, entry] of ordered) {
    const m = entry.match;
    if (o.onlyMatching && m) {
      for (const [s, e] of m.ranges) process.stdout.write(linePrefix(name, lineNo, o.column ? s + 1 : undefined, showFile && !o.heading, numbers) + entry.text.slice(s, e) + "\n");
    } else if (o.vimgrep && m) {
      for (const [s] of m.ranges) process.stdout.write(`${name}:${lineNo}:${s + 1}:${entry.text}\n`);
    } else {
      const sep = m ? ":" : "-";
      const col = m && o.column ? m.ranges[0][0] + 1 : undefined;
      process.stdout.write(linePrefix(name, lineNo, col, showFile && !o.heading, numbers, sep) + entry.text + "\n");
    }
  }
  return matches.length;
}

function run() {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed === "exit") return;
  const o = parsed;
  const start = Date.now();
  if (o.filenamePattern !== undefined) {
    const re = new RegExp(o.pattern || "");
    const files = collectFiles(o);
    let matched = 0;
    for (const f of files) {
      const d = displayPath(f, o.paths);
      if (re.test(d)) { process.stdout.write(d + (o.print0 ? "\0" : "\n")); matched++; }
    }
    process.exit(matched ? 0 : 1);
  }
  const re = makeRegex(o);
  let total = 0;
  let scanned = 0;
  if (o.paths.length === 0) {
    const input = fs.readFileSync(0, "utf8");
    const matches = findMatches(input, re, o);
    total += printSearchResult(undefined, input, matches, o, false);
    process.exit(total ? 0 : 1);
  }
  const files = collectFiles(o);
  const many = files.length > 1 || o.paths.some(p => {
    try { return fs.statSync(p).isDirectory(); } catch { return false; }
  });
  for (const f of files) {
    const data = readFileMaybe(f, o);
    if (data === undefined) continue;
    scanned++;
    const matches = findMatches(data, re, o);
    const shown = displayPath(f, o.paths);
    total += printSearchResult(shown, data, matches, o, many);
  }
  if (o.stats) {
    const elapsed = ((Date.now() - start) / 1000).toFixed(3);
    process.stdout.write(`${scanned} files searched\n${total} matches\n${elapsed} seconds\n`);
  }
  process.exit(total ? 0 : 1);
}

run();
