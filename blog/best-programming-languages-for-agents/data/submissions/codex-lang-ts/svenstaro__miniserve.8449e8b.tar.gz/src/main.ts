// @ts-nocheck
const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const http = require("http");
const https = require("https");
const crypto = require("crypto");
const { spawn } = require("child_process");
const { URL } = require("url");

const VERSION = "0.32.0";

const LONG_HELP = `For when you really just want to serve some files over HTTP right now!

Usage: executable [OPTIONS] [PATH]

Arguments:
  [PATH]
          Which path to serve
          
          [env: MINISERVE_PATH=]

Options:
  -v, --verbose
          Be verbose, includes emitting access logs
          
          [env: MINISERVE_VERBOSE=]

      --temp-directory <TEMP_UPLOAD_DIRECTORY>
          The path to where file uploads will be written to before being moved to their correct
          location. It's wise to make sure that this directory will be written to disk and not into
          memory.
          
          This value will only be used **IF** file uploading is enabled. If this option is not set,
          the operating system default temporary directory will be used.
          
          [env: MINISERVER_TEMP_UPLOAD_DIRECTORY=]

      --index <INDEX>
          The name of a directory index file to serve, like "index.html"
          
          Normally, when miniserve serves a directory, it creates a listing for that directory.
          However, if a directory contains this file, miniserve will serve that file instead.
          
          [env: MINISERVE_INDEX=]

      --spa
          Activate SPA (Single Page Application) mode
          
          This will cause the file given by --index to be served for all non-existing file paths. In
          effect, this will serve the index file whenever a 404 would otherwise occur in order to
          allow the SPA router to handle the request instead.
          
          [env: MINISERVE_SPA=]

      --pretty-urls
          Activate Pretty URLs mode
          
          This will cause the server to serve the equivalent \`.html\` file indicated by the path.
          
          \`/about\` will try to find \`about.html\` and serve it.
          
          [env: MINISERVE_PRETTY_URLS=]

  -p, --port <PORT>
          Port to use
          
          [env: MINISERVE_PORT=]
          [default: 8080]

  -i, --interfaces <INTERFACES>
          Interface to listen on
          
          [env: MINISERVE_INTERFACE=]

  -a, --auth <AUTH>
          Set authentication
          
          Currently supported formats:
          username:password, username:sha256:hash, username:sha512:hash
          (e.g. joe:123,
          joe:sha256:a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3)
          
          [env: MINISERVE_AUTH=]

      --auth-file <AUTH_FILE>
          Read authentication values from a file
          
          Example file content:
          
          joe:123
          bob:sha256:a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3
          bill:
          
          [env: MINISERVE_AUTH_FILE=]

      --route-prefix <ROUTE_PREFIX>
          Use a specific route prefix
          
          [env: MINISERVE_ROUTE_PREFIX=]

      --random-route
          Generate a random 6-hexdigit route
          
          [env: MINISERVE_RANDOM_ROUTE=]

  -P, --no-symlinks
          Hide symlinks in listing and prevent them from being followed
          
          [env: MINISERVE_NO_SYMLINKS=]

  -H, --hidden
          Show hidden files
          
          [env: MINISERVE_HIDDEN=]

  -S, --default-sorting-method <DEFAULT_SORTING_METHOD>
          Default sorting method for file list

          Possible values:
          - name: Sort by name
          - size: Sort by size
          - date: Sort by last modification date (natural sort: follows alphanumerical order)
          
          [env: MINISERVE_DEFAULT_SORTING_METHOD=]
          [default: name]

  -O, --default-sorting-order <DEFAULT_SORTING_ORDER>
          Default sorting order for file list

          Possible values:
          - asc:  Ascending order
          - desc: Descending order
          
          [env: MINISERVE_DEFAULT_SORTING_ORDER=]
          [default: desc]

  -c, --color-scheme <COLOR_SCHEME>
          Default color scheme
          
          [env: MINISERVE_COLOR_SCHEME=]
          [default: squirrel]
          [possible values: squirrel, archlinux, zenburn, monokai]

  -d, --color-scheme-dark <COLOR_SCHEME_DARK>
          Default color scheme
          
          [env: MINISERVE_COLOR_SCHEME_DARK=]
          [default: archlinux]
          [possible values: squirrel, archlinux, zenburn, monokai]

  -q, --qrcode
          Enable QR code display
          
          [env: MINISERVE_QRCODE=]

  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]
          Enable file uploading (and optionally specify for which directory)
          
          [env: MINISERVE_ALLOWED_UPLOAD_DIR=]

      --web-upload-files-concurrency <WEB_UPLOAD_CONCURRENCY>
          Configure amount of concurrent uploads when visiting the website.
          
          [env: MINISERVE_WEB_UPLOAD_CONCURRENCY=]
          [default: 0]

      --chmod <CHMOD>
          Set unix file permissions of uploaded files
          
          [env: MINISERVE_CHMOD=]

      --directory-size
          Enable recursive directory size calculation
          
          [env: MINISERVE_DIRECTORY_SIZE=]

  -U, --mkdir
          Enable creating directories
          
          [env: MINISERVE_MKDIR_ENABLED=]

  -m, --media-type <MEDIA_TYPE>
          Specify uploadable media types
          
          [env: MINISERVE_MEDIA_TYPE=]
          [possible values: image, audio, video]

  -M, --raw-media-type <MEDIA_TYPE_RAW>
          Directly specify the uploadable media type expression
          
          [env: MINISERVE_RAW_MEDIA_TYPE=]

  -o, --on-duplicate-files <ON_DUPLICATE_FILES>
          What to do if existing files with same name is present during file upload
          
          [env: MINISERVE_ON_DUPLICATE_FILES=]
          [default: error]
          [possible values: error, overwrite, rename]

  -R, --rm-files [<ALLOWED_RM_DIR>]
          Enable file and directory deletion (and optionally specify for which directory)
          
          [env: MINISERVE_ALLOWED_RM_DIR=]

  -r, --enable-tar
          Enable uncompressed tar archive generation
          
          [env: MINISERVE_ENABLE_TAR=]

  -g, --enable-tar-gz
          Enable gz-compressed tar archive generation
          
          [env: MINISERVE_ENABLE_TAR_GZ=]

  -z, --enable-zip
          Enable zip archive generation
          
          [env: MINISERVE_ENABLE_ZIP=]

  -C, --compress-response
          Compress response
          
          [env: MINISERVE_COMPRESS_RESPONSE=]

  -D, --dirs-first
          List directories first
          
          [env: MINISERVE_DIRS_FIRST=]

  -t, --title <TITLE>
          Shown instead of host in page title and heading
          
          [env: MINISERVE_TITLE=]

      --header <HEADER>
          Inserts custom headers into the responses.
          
          [env: MINISERVE_HEADER=]

  -l, --show-symlink-info
          Visualize symlinks in directory listing
          
          [env: MINISERVE_SHOW_SYMLINK_INFO=]

  -F, --hide-version-footer
          Hide version footer
          
          [env: MINISERVE_HIDE_VERSION_FOOTER=]

      --hide-theme-selector
          Hide theme selector
          
          [env: MINISERVE_HIDE_THEME_SELECTOR=]

  -W, --show-wget-footer
          If enabled, display a wget command to recursively download the current directory
          
          [env: MINISERVE_SHOW_WGET_FOOTER=]

      --print-completions <shell>
          Generate completion file for a shell
          
          [possible values: bash, elvish, fish, powershell, zsh]

      --print-manpage
          Generate man page

      --tls-cert <TLS_CERT>
          TLS certificate to use
          
          [env: MINISERVE_TLS_CERT=]

      --tls-key <TLS_KEY>
          TLS private key to use
          
          [env: MINISERVE_TLS_KEY=]

      --readme
          Enable README.md rendering in directories
          
          [env: MINISERVE_README=]

  -I, --disable-indexing
          Disable indexing
          
          [env: MINISERVE_DISABLE_INDEXING=]

      --enable-webdav
          Enable read-only WebDAV support (PROPFIND requests)
          
          [env: MINISERVE_ENABLE_WEBDAV=]

      --size-display <SIZE_DISPLAY>
          Show served file size in exact bytes
          
          [env: MINISERVE_SIZE_DISPLAY=]
          [default: human]
          [possible values: human, exact]

      --file-external-url <FILE_EXTERNAL_URL>
          Optional external URL (e.g., 'http://external.example.com:8081') prepended to file links
          in listings.
          
          [env: MINISERVE_FILE_EXTERNAL_URL=]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const SHORT_HELP = LONG_HELP.replace(/\n\nArguments:[\s\S]*?Options:/, "\n\nArguments:\n  [PATH]  Which path to serve [env: MINISERVE_PATH=]\n\nOptions:")
  .split("\n").filter((line, i, arr) => !line.startsWith("          ") || line.includes("[env:") || line.includes("[default:") || line.includes("[possible values:")).join("\n")
  .replace("Print help (see a summary with '-h')", "Print help (see more with '--help')");

function die(msg, code = 1) { console.error(msg); process.exit(code); }
function envBool(name) { return !!process.env[name] && !["0","false","False","FALSE"].includes(process.env[name]); }
function htmlEscape(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;"}[c])); }
function encPath(p) { return p.split("/").map(encodeURIComponent).join("/"); }
function posixJoin(a,b){ return (a.replace(/\/+$/,"") + "/" + b.replace(/^\/+/,"")).replace(/^$/, "/"); }

function parseArgs(argv) {
  const o = {
    path: process.env.MINISERVE_PATH || ".",
    port: process.env.MINISERVE_PORT || "8080",
    interfaces: process.env.MINISERVE_INTERFACE || undefined,
    verbose: envBool("MINISERVE_VERBOSE"),
    index: process.env.MINISERVE_INDEX || undefined,
    spa: envBool("MINISERVE_SPA"),
    pretty: envBool("MINISERVE_PRETTY_URLS"),
    auth: [],
    authFile: process.env.MINISERVE_AUTH_FILE || undefined,
    routePrefix: process.env.MINISERVE_ROUTE_PREFIX || "",
    randomRoute: envBool("MINISERVE_RANDOM_ROUTE"),
    noSymlinks: envBool("MINISERVE_NO_SYMLINKS"),
    hidden: envBool("MINISERVE_HIDDEN"),
    sort: process.env.MINISERVE_DEFAULT_SORTING_METHOD || "name",
    order: process.env.MINISERVE_DEFAULT_SORTING_ORDER || "desc",
    upload: envBool("MINISERVE_ALLOWED_UPLOAD_DIR"),
    uploadDir: process.env.MINISERVE_ALLOWED_UPLOAD_DIR || "/",
    mkdir: envBool("MINISERVE_MKDIR_ENABLED"),
    rm: envBool("MINISERVE_ALLOWED_RM_DIR"),
    rmDir: process.env.MINISERVE_ALLOWED_RM_DIR || "/",
    tar: envBool("MINISERVE_ENABLE_TAR"),
    targz: envBool("MINISERVE_ENABLE_TAR_GZ"),
    zip: envBool("MINISERVE_ENABLE_ZIP"),
    dirsFirst: envBool("MINISERVE_DIRS_FIRST"),
    title: process.env.MINISERVE_TITLE || "",
    headers: [],
    footer: !envBool("MINISERVE_HIDE_VERSION_FOOTER"),
    themeSelector: !envBool("MINISERVE_HIDE_THEME_SELECTOR"),
    wget: envBool("MINISERVE_SHOW_WGET_FOOTER"),
    tlsCert: process.env.MINISERVE_TLS_CERT || "",
    tlsKey: process.env.MINISERVE_TLS_KEY || "",
    readme: envBool("MINISERVE_README"),
    disableIndex: envBool("MINISERVE_DISABLE_INDEXING"),
    webdav: envBool("MINISERVE_ENABLE_WEBDAV"),
    sizeDisplay: process.env.MINISERVE_SIZE_DISPLAY || "human",
    fileExternalUrl: process.env.MINISERVE_FILE_EXTERNAL_URL || "",
    chmod: process.env.MINISERVE_CHMOD || "",
    duplicate: process.env.MINISERVE_ON_DUPLICATE_FILES || "error",
  };
  if (process.env.MINISERVE_AUTH) o.auth.push(process.env.MINISERVE_AUTH);
  for (let i=0;i<argv.length;i++) {
    const a = argv[i];
    const need = () => { if (i+1 >= argv.length) die(`error: a value is required for '${a} <VALUE>'\n\nFor more information, try '--help'.`); return argv[++i]; };
    if (a === "--") { if (i+1 < argv.length) o.path = argv[++i]; continue; }
    if (a === "--help") { console.log(LONG_HELP); process.exit(0); }
    else if (a === "-h") { console.log(SHORT_HELP); process.exit(0); }
    else if (a === "-V" || a === "--version") { console.log(`miniserve ${VERSION}`); process.exit(0); }
    else if (a === "--print-manpage") { console.log(`.TH miniserve 1  "miniserve ${VERSION}"\n.SH NAME\nminiserve \\- For when you really just want to serve some files over HTTP right now!\n.SH SYNOPSIS\nminiserve [OPTIONS] [PATH]\n.SH DESCRIPTION\n${LONG_HELP}`); process.exit(0); }
    else if (a === "--print-completions") { console.log(`# completion for ${need()}\n_complete_miniserve() { :; }`); process.exit(0); }
    else if (a === "-v" || a === "--verbose") o.verbose = true;
    else if (a === "--index") o.index = need();
    else if (a === "--spa") o.spa = true;
    else if (a === "--pretty-urls") o.pretty = true;
    else if (a === "-p" || a === "--port") o.port = need();
    else if (a === "-i" || a === "--interfaces") o.interfaces = need();
    else if (a === "-a" || a === "--auth") o.auth.push(need());
    else if (a === "--auth-file") o.authFile = need();
    else if (a === "--route-prefix") o.routePrefix = need();
    else if (a === "--random-route") o.randomRoute = true;
    else if (a === "-P" || a === "--no-symlinks") o.noSymlinks = true;
    else if (a === "-H" || a === "--hidden") o.hidden = true;
    else if (a === "-S" || a === "--default-sorting-method") o.sort = need();
    else if (a === "-O" || a === "--default-sorting-order") o.order = need();
    else if (a === "-c" || a === "--color-scheme" || a === "-d" || a === "--color-scheme-dark" || a === "-m" || a === "--media-type" || a === "-M" || a === "--raw-media-type" || a === "--web-upload-files-concurrency" || a === "--temp-directory") need();
    else if (a === "-q" || a === "--qrcode" || a === "--directory-size" || a === "-C" || a === "--compress-response" || a === "-l" || a === "--show-symlink-info") {}
    else if (a === "-u" || a === "--upload-files") { o.upload = true; if (argv[i+1] && !argv[i+1].startsWith("-")) o.uploadDir = argv[++i]; }
    else if (a === "--chmod") o.chmod = need();
    else if (a === "-U" || a === "--mkdir") o.mkdir = true;
    else if (a === "-o" || a === "--on-duplicate-files") o.duplicate = need();
    else if (a === "-R" || a === "--rm-files") { o.rm = true; if (argv[i+1] && !argv[i+1].startsWith("-")) o.rmDir = argv[++i]; }
    else if (a === "-r" || a === "--enable-tar") o.tar = true;
    else if (a === "-g" || a === "--enable-tar-gz") o.targz = true;
    else if (a === "-z" || a === "--enable-zip") o.zip = true;
    else if (a === "-D" || a === "--dirs-first") o.dirsFirst = true;
    else if (a === "-t" || a === "--title") o.title = need();
    else if (a === "--header") o.headers.push(need());
    else if (a === "-F" || a === "--hide-version-footer") o.footer = false;
    else if (a === "--hide-theme-selector") o.themeSelector = false;
    else if (a === "-W" || a === "--show-wget-footer") o.wget = true;
    else if (a === "--tls-cert") o.tlsCert = need();
    else if (a === "--tls-key") o.tlsKey = need();
    else if (a === "--readme") o.readme = true;
    else if (a === "-I" || a === "--disable-indexing") o.disableIndex = true;
    else if (a === "--enable-webdav") o.webdav = true;
    else if (a === "--size-display") o.sizeDisplay = need();
    else if (a === "--file-external-url") o.fileExternalUrl = need();
    else if (a.startsWith("-")) die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [PATH]\n\nFor more information, try '--help'.`);
    else o.path = a;
  }
  if (!/^\d+$/.test(String(o.port))) die(`error: invalid value '${o.port}' for '--port <PORT>': invalid digit found in string\n\nFor more information, try '--help'.`);
  if (!["name","size","date"].includes(o.sort)) die(`error: invalid value '${o.sort}' for '--default-sorting-method <DEFAULT_SORTING_METHOD>'\n\nFor more information, try '--help'.`);
  if (!["asc","desc"].includes(o.order)) die(`error: invalid value '${o.order}' for '--default-sorting-order <DEFAULT_SORTING_ORDER>'\n\nFor more information, try '--help'.`);
  if (o.randomRoute) o.routePrefix = crypto.randomBytes(3).toString("hex");
  o.routePrefix = o.routePrefix ? "/" + o.routePrefix.replace(/^\/+|\/+$/g, "") : "";
  return o;
}

function mime(p) {
  const e = path.extname(p).toLowerCase();
  return {".html":"text/html; charset=utf-8",".htm":"text/html; charset=utf-8",".txt":"text/plain; charset=utf-8",".md":"text/markdown; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json",".svg":"image/svg+xml",".png":"image/png",".jpg":"image/jpeg",".jpeg":"image/jpeg",".gif":"image/gif",".wasm":"application/wasm",".pdf":"application/pdf"}[e] || "application/octet-stream";
}
function human(n) {
  const units = ["B","KiB","MiB","GiB","TiB"]; let v=n, i=0;
  while (v >= 1024 && i < units.length-1) { v/=1024; i++; }
  return i===0 ? `${n} B` : `${v.toFixed(v>=10?1:2).replace(/\.0+$/,"")} ${units[i]}`;
}
function safeResolve(root, rel) {
  const full = path.resolve(root, "." + decodeURIComponent(rel));
  const rr = path.resolve(root);
  if (full !== rr && !full.startsWith(rr + path.sep)) return null;
  return full;
}
function addHeaders(res, opt) {
  for (const h of opt.headers) {
    const idx = h.indexOf(":");
    if (idx > 0 && !res.hasHeader(h.slice(0,idx))) res.setHeader(h.slice(0,idx).trim(), h.slice(idx+1).trim());
  }
}
function pageHead(title, opt) {
  const p = opt.routePrefix;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="color-scheme" content="dark light"><link rel="icon" type="image/svg+xml" href="${p}/__miniserve_internal/favicon.svg"><link rel="stylesheet" href="${p}/__miniserve_internal/style.css"><title>${htmlEscape(title)}</title><script>const API_ROUTE='${p}/__miniserve_internal/api';</script></head>`;
}
function footer(opt) {
  return opt.footer ? `<div class="footer"><div class="version"><a href="https://github.com/svenstaro/miniserve">miniserve</a>/${VERSION}</div></div>` : "";
}
function errorPage(status, msg, opt) {
  return `${pageHead(status, opt)}<body><div class="error"><p>${htmlEscape(status)}</p><p>${htmlEscape(msg)}</p><div class="error-nav"><a class="error-back" href="${opt.routePrefix || "/" }">Go back to file listing</a></div><p class="footer">${footer(opt)}</p></div></body></html>`;
}
async function statMaybe(p, noSymlinks=false) {
  try {
    const st = noSymlinks ? await fsp.lstat(p) : await fsp.stat(p);
    if (noSymlinks && st.isSymbolicLink()) return null;
    return st;
  } catch { return null; }
}
async function dirSize(p) {
  let total = 0;
  async function walk(d) {
    for (const n of await fsp.readdir(d)) {
      const f = path.join(d,n); const st = await statMaybe(f);
      if (!st) continue; if (st.isDirectory()) await walk(f); else total += st.size;
    }
  }
  await walk(p); return total;
}

async function listDirectory(abs, reqPath, reqUrl, opt, host) {
  if (opt.disableIndex) return {status:404, type:"text/html", body:errorPage("404 Not Found", `Route ${reqPath} could not be found`, opt)};
  const index = opt.index && path.join(abs, opt.index);
  if (index && await statMaybe(index)) return {file:index};
  let names = await fsp.readdir(abs);
  let rows = [];
  for (const name of names) {
    if (!opt.hidden && name.startsWith(".")) continue;
    const full = path.join(abs, name);
    const st = await statMaybe(full, opt.noSymlinks);
    if (!st) continue;
    const isDir = st.isDirectory();
    rows.push({name, full, st, isDir});
  }
  const q = reqUrl.searchParams;
  const sort = q.get("sort") || opt.sort;
  const order = q.get("order") || (sort === "name" ? "asc" : opt.order);
  rows.sort((a,b) => {
    if (opt.dirsFirst && a.isDir !== b.isDir) return a.isDir ? -1 : 1;
    let c = 0;
    if (sort === "size") c = a.st.size - b.st.size;
    else if (sort === "date") c = a.st.mtimeMs - b.st.mtimeMs;
    else c = a.name.localeCompare(b.name, undefined, {numeric:true});
    return order === "asc" ? c : -c;
  });
  const title = opt.title || host || "localhost";
  const bodyRows = rows.map(e => {
    const shown = e.name + (e.isDir ? "/" : "");
    const hrefRel = posixJoin(opt.routePrefix || "", posixJoin(reqPath, encPath(e.name) + (e.isDir ? "/" : "")));
    const href = e.isDir ? hrefRel : (opt.fileExternalUrl ? opt.fileExternalUrl.replace(/\/+$/,"") + posixJoin(reqPath, encPath(e.name)) : hrefRel);
    const size = e.isDir ? "" : (opt.sizeDisplay === "exact" ? String(e.st.size) : human(e.st.size));
    return `<tr class="entry-type-${e.isDir?"directory":"file"}"><td><p><a class="${e.isDir?"directory":"file"}" href="${href}">${htmlEscape(shown)}</a></p></td><td class="size-cell">${size}</td><td class="date-cell"><span>${e.st.mtime.toISOString()}</span></td></tr>`;
  }).join("");
  let toolbar = "";
  if (opt.upload) toolbar += `<a href="${opt.routePrefix}/upload?path=${encodeURIComponent(reqPath)}">Upload files</a> `;
  if (opt.tar || opt.targz || opt.zip) toolbar += `<a href="?download=tar">tar</a> <a href="?download=targz">tar.gz</a> <a href="?download=zip">zip</a>`;
  const readmePath = path.join(abs, "README.md");
  let readme = "";
  if (opt.readme && await statMaybe(readmePath)) readme = `<div class="readme"><pre>${htmlEscape(await fsp.readFile(readmePath,"utf8"))}</pre></div>`;
  const html = `${pageHead(title, opt)}<body id="drop-container">${opt.themeSelector?`<nav><div><p>Change theme...</p><ul class="theme"><li data-theme="default"><a>Default (light/dark)</a></li><li data-theme="squirrel"><a>Squirrel (light)</a></li><li data-theme="archlinux"><a>Arch Linux (dark)</a></li><li data-theme="zenburn"><a>Zenburn (dark)</a></li><li data-theme="monokai"><a>Monokai (dark)</a></li></ul></div></nav>`:""}<div class="container"><span id="top"></span><h1 class="title" dir="ltr"><span><bdi>${htmlEscape(title)}</bdi></span>${htmlEscape(reqPath)}</h1><div class="toolbar">${toolbar}</div><table><thead><tr><th class="name"><a href="?sort=name&amp;order=asc">Name</a></th><th class="size"><a href="?sort=size&amp;order=asc">Size</a></th><th class="date"><a href="?sort=date&amp;order=asc">Last modification</a></th></tr></thead><tbody>${bodyRows}</tbody></table>${readme}${opt.wget?`<div class="wget">wget -r -np ${htmlEscape("http://"+host+reqPath)}</div>`:""}<a class="back" href="#top">⇪</a>${footer(opt)}</div></body></html>`;
  return {status:200, type:"text/html; charset=utf-8", body:html};
}

async function sendFile(req, res, file, opt) {
  const st = await fsp.stat(file);
  let start = 0, end = st.size - 1, status = 200;
  const range = req.headers.range;
  if (range && /^bytes=\d*-\d*$/.test(range)) {
    const [a,b] = range.slice(6).split("-");
    if (a === "") { const len = Number(b); start = Math.max(0, st.size - len); }
    else { start = Number(a); if (b !== "") end = Number(b); }
    if (start <= end && start < st.size) { status = 206; end = Math.min(end, st.size-1); res.setHeader("Content-Range", `bytes ${start}-${end}/${st.size}`); }
  }
  res.statusCode = status;
  res.setHeader("Content-Length", Math.max(0, end-start+1));
  res.setHeader("Content-Type", mime(file));
  res.setHeader("Accept-Ranges", "bytes");
  res.setHeader("Last-Modified", st.mtime.toUTCString());
  res.setHeader("ETag", `"${st.ino.toString(16)}:${st.size.toString(16)}:${Math.floor(st.mtimeMs).toString(16)}"`);
  const disp = mime(file).startsWith("text/") || mime(file).startsWith("image/") || mime(file)==="application/pdf" ? "inline" : "attachment";
  res.setHeader("Content-Disposition", `${disp}; filename="${path.basename(file).replace(/"/g,'\\"')}"`);
  addHeaders(res,opt);
  if (req.method === "HEAD") return res.end();
  fs.createReadStream(file, {start, end}).pipe(res);
}

function parseAuthLine(line) {
  const p = line.trim(); if (!p) return null;
  const parts = p.split(":");
  return {user:parts[0], kind:parts.length>=3 && ["sha256","sha512"].includes(parts[1]) ? parts[1] : "plain", pass:parts.length>=3 && ["sha256","sha512"].includes(parts[1]) ? parts.slice(2).join(":") : parts.slice(1).join(":")};
}
function checkAuth(req, auths) {
  if (!auths.length) return true;
  const h = req.headers.authorization || "";
  if (!h.startsWith("Basic ")) return false;
  let decoded = ""; try { decoded = Buffer.from(h.slice(6), "base64").toString(); } catch { return false; }
  const idx = decoded.indexOf(":"); if (idx < 0) return false;
  const user = decoded.slice(0,idx), pass = decoded.slice(idx+1);
  return auths.some(a => a && a.user === user && (a.kind === "plain" ? a.pass === pass : crypto.createHash(a.kind).update(pass).digest("hex") === a.pass));
}
function collect(req) {
  return new Promise((resolve,reject)=>{ const bufs=[]; req.on("data",b=>bufs.push(b)); req.on("end",()=>resolve(Buffer.concat(bufs))); req.on("error",reject); });
}
async function handleUpload(req, res, root, url, opt) {
  if (!opt.upload) return respond(res, 404, "text/html", errorPage("404 Not Found", "Upload is disabled", opt), opt);
  const targetRel = url.searchParams.get("path") || "/";
  const dir = safeResolve(root, targetRel);
  if (!dir) return respond(res, 403, "text/plain", "Forbidden", opt);
  await fsp.mkdir(dir, {recursive:true});
  if (req.method === "GET") return respond(res, 200, "text/html", `${pageHead("Upload",opt)}<body><form method="post" enctype="multipart/form-data"><input type="file" name="path" multiple><button>Upload</button></form></body></html>`, opt);
  const ctype = req.headers["content-type"] || "";
  const m = /boundary=(?:"([^"]+)"|([^;]+))/.exec(ctype);
  const body = await collect(req);
  if (!m) return respond(res, 400, "text/plain", "Missing multipart boundary", opt);
  const boundary = Buffer.from("--" + (m[1] || m[2]));
  let written = 0, pos = 0;
  while ((pos = body.indexOf(boundary, pos)) >= 0) {
    let partStart = pos + boundary.length;
    if (body.slice(partStart, partStart+2).toString() === "--") break;
    if (body.slice(partStart, partStart+2).toString() === "\r\n") partStart += 2;
    const headEnd = body.indexOf(Buffer.from("\r\n\r\n"), partStart);
    if (headEnd < 0) break;
    const headers = body.slice(partStart, headEnd).toString();
    const fnm = /filename="([^"]*)"/.exec(headers);
    const next = body.indexOf(boundary, headEnd+4);
    if (fnm && next > 0) {
      let name = path.basename(fnm[1]); if (!name) { pos = next; continue; }
      let out = path.join(dir, name);
      if (fs.existsSync(out)) {
        if (opt.duplicate === "error") return respond(res, 409, "text/plain", "File exists", opt);
        if (opt.duplicate === "rename") { const ext=path.extname(name), base=name.slice(0,name.length-ext.length); let n=1; while (fs.existsSync(path.join(dir, `${base}-${n}${ext}`))) n++; out = path.join(dir, `${base}-${n}${ext}`); }
      }
      let data = body.slice(headEnd+4, next-2);
      await fsp.writeFile(out, data); if (opt.chmod) await fsp.chmod(out, parseInt(opt.chmod,8)).catch(()=>{});
      written++;
    }
    pos = next;
  }
  respond(res, 200, "text/plain", `Uploaded ${written} file(s)\n`, opt);
}
function respond(res, status, type, body, opt, extra={}) {
  res.statusCode = status; res.setHeader("Content-Type", type); for (const [k,v] of Object.entries(extra)) res.setHeader(k,v); addHeaders(res,opt); res.end(body);
}
function pipeCommand(res, cmd, args, type, filename) {
  res.statusCode = 200; res.setHeader("Content-Type", type); res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  const p = spawn(cmd,args); p.stdout.pipe(res); p.on("error",()=>res.end()); p.stderr.resume();
}

async function main() {
  const opt = parseArgs(process.argv.slice(2));
  const root = path.resolve(opt.path);
  let rootStat;
  try { rootStat = await fsp.stat(root); } catch(e) {
    const reason = e && e.code === "ENOENT" ? "No such file or directory (os error 2)" : (e.message || String(e));
    const now = new Date().toUTCString().replace("GMT","+0000");
    console.error(`${now} [ERROR] Failed to resolve path to be served`);
    console.error(`${now} [ERROR] caused by: ${reason}`);
    die(`Error: Failed to resolve path to be served\ncaused by: ${reason}`);
  }
  let auths = opt.auth.map(parseAuthLine).filter(Boolean);
  if (opt.authFile) {
    try { auths.push(...(await fsp.readFile(opt.authFile,"utf8")).split(/\r?\n/).map(parseAuthLine).filter(Boolean)); } catch(e) { die(`Error: Failed to read auth file\ncaused by: ${e.message}`); }
  }
  const serverHandler = async (req, res) => {
    try {
      const host = req.headers.host || `127.0.0.1:${opt.port}`;
      if (opt.verbose) console.error(`${req.socket.remoteAddress || "-"} "${req.method} ${req.url}"`);
      if (!checkAuth(req, auths)) {
        const has = !!req.headers.authorization;
        if (!has) { res.statusCode=401; res.setHeader("WWW-Authenticate","Basic"); res.setHeader("Content-Length","0"); return res.end(); }
        return respond(res, 401, "text/html", errorPage("401 Unauthorized", "Invalid credentials for HTTP authentication", opt), opt, {"WWW-Authenticate": 'Basic realm="miniserve"'});
      }
      const fullUrl = new URL(req.url, `http://${host}`);
      if (opt.routePrefix && !(fullUrl.pathname === opt.routePrefix || fullUrl.pathname.startsWith(opt.routePrefix + "/"))) {
        return respond(res,404,"text/html",errorPage("404 Not Found", `Route ${fullUrl.pathname} could not be found`, opt), opt);
      }
      let reqPath = opt.routePrefix ? fullUrl.pathname.slice(opt.routePrefix.length) || "/" : fullUrl.pathname;
      if (reqPath.startsWith("/__miniserve_internal/")) {
        if (reqPath.endsWith("favicon.svg")) return respond(res,200,"image/svg+xml",`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><text y="48" font-size="48">m</text></svg>`,opt);
        if (reqPath.endsWith("style.css")) return respond(res,200,"text/css",`body{font-family:sans-serif;margin:2rem}.container{max-width:1100px;margin:auto}table{width:100%;border-collapse:collapse}td,th{padding:.35rem;border-bottom:1px solid #ddd}.size-cell{text-align:right}.error{text-align:center;margin-top:4rem}`,opt);
        if (reqPath.endsWith("api") && req.method === "POST") { const b = JSON.parse((await collect(req)).toString()||"{}"); if (b.DirSize) { const p=safeResolve(root,b.DirSize); return respond(res,200,"text/plain",p?human(await dirSize(p)):"~",opt); } }
      }
      if (reqPath === "/upload") return handleUpload(req,res,root,fullUrl,opt);
      if (req.method === "PROPFIND" && opt.webdav) {
        return respond(res,207,"application/xml",`<?xml version="1.0"?><D:multistatus xmlns:D="DAV:"><D:response><D:href>${htmlEscape(fullUrl.pathname)}</D:href><D:propstat><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response></D:multistatus>`,opt);
      }
      let abs = rootStat.isFile() ? root : safeResolve(root, reqPath);
      if (!abs) return respond(res,403,"text/html",errorPage("403 Forbidden","Forbidden",opt),opt);
      let st = await statMaybe(abs, opt.noSymlinks);
      if (!st && opt.pretty && !reqPath.endsWith(".html")) { abs = safeResolve(root, reqPath + ".html"); st = abs && await statMaybe(abs,opt.noSymlinks); }
      if (!st && opt.spa && opt.index) { abs = path.join(root, opt.index); st = await statMaybe(abs,opt.noSymlinks); }
      if (!st) return respond(res,404,"text/html",errorPage("404 Not Found", `Route ${reqPath} could not be found`, opt),opt);
      if ((req.method === "DELETE" || fullUrl.searchParams.get("delete") !== null) && opt.rm) {
        if (st.isDirectory()) await fsp.rm(abs,{recursive:true,force:true}); else await fsp.unlink(abs);
        return respond(res,200,"text/plain","Deleted\n",opt);
      }
      if (opt.mkdir && req.method === "MKCOL") { await fsp.mkdir(abs,{recursive:true}); return respond(res,201,"text/plain","Created\n",opt); }
      if (st.isDirectory()) {
        const dl = fullUrl.searchParams.get("download");
        if (dl === "tar" && opt.tar) return pipeCommand(res,"tar",["-C",abs,"-cf","-","."],"application/x-tar","download.tar");
        if ((dl === "targz" || dl === "tar.gz") && opt.targz) return pipeCommand(res,"tar",["-C",abs,"-czf","-","."],"application/gzip","download.tar.gz");
        if (dl === "zip" && opt.zip) return pipeCommand(res,"python3",["-c",`import os,sys,zipfile,io; b=io.BytesIO(); z=zipfile.ZipFile(b,'w'); root=sys.argv[1]\nfor dp,_,fs in os.walk(root):\n  [z.write(os.path.join(dp,f), os.path.relpath(os.path.join(dp,f),root)) for f in fs]\nz.close(); sys.stdout.buffer.write(b.getvalue())`,abs],"application/zip","download.zip");
        if (!reqPath.endsWith("/")) { res.statusCode=308; res.setHeader("Location", opt.routePrefix + reqPath + "/"); return res.end(); }
        const out = await listDirectory(abs, reqPath, fullUrl, opt, host);
        if (out.file) return sendFile(req,res,out.file,opt);
        return respond(res,out.status,out.type,out.body,opt);
      }
      return sendFile(req,res,abs,opt);
    } catch(e) {
      respond(res,500,"text/html",errorPage("500 Internal Server Error", e.message || String(e), opt),opt);
    }
  };
  let server;
  if (opt.tlsCert && opt.tlsKey) server = https.createServer({cert:fs.readFileSync(opt.tlsCert), key:fs.readFileSync(opt.tlsKey)}, serverHandler);
  else server = http.createServer(serverHandler);
  const port = Number(opt.port);
  const host = opt.interfaces || "::";
  server.listen(port, host, () => {
    const actual = server.address().port;
    console.error(`miniserve v${VERSION}`);
    console.error(`Bound to [::]:${actual}, 0.0.0.0:${actual}`);
    console.error(`Serving path ${root}`);
    console.error(`Available at (non-exhaustive list):`);
    console.error(`    ${opt.tlsCert?"https":"http"}://127.0.0.1:${actual}${opt.routePrefix}`);
    console.error(`    ${opt.tlsCert?"https":"http"}://[::1]:${actual}${opt.routePrefix}`);
    console.error("");
  });
}
main();
