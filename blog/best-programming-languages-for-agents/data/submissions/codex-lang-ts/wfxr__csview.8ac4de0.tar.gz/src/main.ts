declare const require: any;
declare const process: any;

const fs = require("fs");

type Align = "left" | "center" | "right";
type StyleName = "none" | "ascii" | "ascii2" | "sharp" | "rounded" | "reinforced" | "markdown" | "grid";

interface Opts {
  noHeaders: boolean;
  number: boolean;
  delimiter: string;
  style: StyleName;
  padding: number;
  indent: number;
  sniff: number;
  headerAlign: Align;
  bodyAlign: Align;
  file?: string;
}

const HELP = `A high performance csv viewer with cjk/emoji support.

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          File to view

Options:
  -H, --no-headers
          Specify that the input has no header row
  -n, --number
          Prepend a column of line numbers to the table
  -t, --tsv
          Use '\\t' as delimiter for tsv
  -d, --delimiter <DELIMITER>
          Specify the field delimiter [default: ,]
  -s, --style <STYLE>
          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
          rounded, reinforced, markdown, grid]
  -p, --padding <PADDING>
          Specify padding for table cell [default: 1]
  -i, --indent <INDENT>
          Specify global indent for table [default: 0]
      --sniff <LIMIT>
          Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
          [default: 1000]
      --header-align <HEADER_ALIGN>
          Specify the alignment of the table header [default: center] [possible values: left,
          center, right]
      --body-align <BODY_ALIGN>
          Specify the alignment of the table body [default: left] [possible values: left, center,
          right]
  -P, --disable-pager
          Disable pager
  -h, --help
          Print help
  -V, --version
          Print version`;

const STYLE_VALUES: StyleName[] = ["none", "ascii", "ascii2", "sharp", "rounded", "reinforced", "markdown", "grid"];
const ALIGN_VALUES: Align[] = ["left", "center", "right"];

function die(msg: string): never {
  process.stderr.write(msg + "\n");
  process.exit(2);
  throw new Error("unreachable");
}

function valueFor(args: string[], i: number, flag: string): [string, number] {
  const eq = flag.indexOf("=");
  if (eq >= 0) return [flag.slice(eq + 1), i];
  if (i + 1 >= args.length) die(`error: a value is required for '${flag}' but none was supplied`);
  return [args[i + 1], i + 1];
}

function parseArgs(args: string[]): Opts {
  const opts: Opts = {
    noHeaders: false,
    number: false,
    delimiter: ",",
    style: "sharp",
    padding: 1,
    indent: 0,
    sniff: 1000,
    headerAlign: "center",
    bodyAlign: "left",
  };

  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") {
      if (i + 1 < args.length) opts.file = args[++i];
      if (i + 1 < args.length) die(`error: unexpected argument '${args[i + 1]}' found`);
      break;
    } else if (a === "-h" || a === "--help") {
      process.stdout.write(HELP + "\n");
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      process.stdout.write("csview 1.3.4\n");
      process.exit(0);
    } else if (a === "-H" || a === "--no-headers") opts.noHeaders = true;
    else if (a === "-n" || a === "--number") opts.number = true;
    else if (a === "-t" || a === "--tsv") opts.delimiter = "\t";
    else if (a === "-P" || a === "--disable-pager") {
      // The reimplementation writes directly to stdout, so pager disabling is implicit.
    } else if (a === "-d" || a === "--delimiter" || a.startsWith("--delimiter=")) {
      const got = valueFor(args, i, a); opts.delimiter = got[0]; i = got[1];
      if (opts.delimiter === "\\t") opts.delimiter = "\t";
    } else if (a === "-s" || a === "--style" || a.startsWith("--style=")) {
      const got = valueFor(args, i, a); i = got[1];
      if (!STYLE_VALUES.includes(got[0] as StyleName)) {
        die(`error: invalid value '${got[0]}' for '--style <STYLE>'\n  [possible values: none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid]\n\nFor more information, try '--help'.`);
      }
      opts.style = got[0] as StyleName;
    } else if (a === "-p" || a === "--padding" || a.startsWith("--padding=")) {
      const got = valueFor(args, i, a); opts.padding = Math.max(0, parseInt(got[0], 10) || 0); i = got[1];
    } else if (a === "-i" || a === "--indent" || a.startsWith("--indent=")) {
      const got = valueFor(args, i, a); opts.indent = Math.max(0, parseInt(got[0], 10) || 0); i = got[1];
    } else if (a === "--sniff" || a.startsWith("--sniff=")) {
      const got = valueFor(args, i, a); opts.sniff = Math.max(0, parseInt(got[0], 10) || 0); i = got[1];
    } else if (a === "--header-align" || a.startsWith("--header-align=")) {
      const got = valueFor(args, i, a); i = got[1];
      if (!ALIGN_VALUES.includes(got[0] as Align)) die(`error: invalid value '${got[0]}' for '--header-align <HEADER_ALIGN>'`);
      opts.headerAlign = got[0] as Align;
    } else if (a === "--body-align" || a.startsWith("--body-align=")) {
      const got = valueFor(args, i, a); i = got[1];
      if (!ALIGN_VALUES.includes(got[0] as Align)) die(`error: invalid value '${got[0]}' for '--body-align <BODY_ALIGN>'`);
      opts.bodyAlign = got[0] as Align;
    } else if (a.startsWith("-")) {
      die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.`);
    } else if (!opts.file) opts.file = a;
    else die(`error: unexpected argument '${a}' found`);
  }
  return opts;
}

function parseCsv(input: string, delim: string): string[][] {
  input = input.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let q = false;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (q) {
      if (ch === '"') {
        if (input[i + 1] === '"') { field += '"'; i++; }
        else q = false;
      } else field += ch;
    } else {
      if (ch === '"') q = true;
      else if (ch === delim) { row.push(field); field = ""; }
      else if (ch === "\n") { row.push(field); rows.push(row); row = []; field = ""; }
      else field += ch;
    }
  }
  if (field.length > 0 || row.length > 0 || (input.length > 0 && input[input.length - 1] === delim)) {
    row.push(field);
    rows.push(row);
  }
  if (rows.length && rows[rows.length - 1].length === 1 && rows[rows.length - 1][0] === "" && input.endsWith("\n")) rows.pop();
  return rows;
}

function wcwidth(s: string): number {
  let w = 0;
  for (const ch of Array.from(s.normalize("NFC"))) {
    const cp = ch.codePointAt(0) || 0;
    if (cp === 0) continue;
    if (cp < 32 || (cp >= 0x7f && cp < 0xa0)) continue;
    if ((cp >= 0x300 && cp <= 0x36f) || (cp >= 0x1ab0 && cp <= 0x1aff) || (cp >= 0x1dc0 && cp <= 0x1dff) || (cp >= 0xfe00 && cp <= 0xfe0f)) continue;
    if (
      cp >= 0x1100 && (
        cp <= 0x115f || cp === 0x2329 || cp === 0x232a ||
        (cp >= 0x2e80 && cp <= 0xa4cf && cp !== 0x303f) ||
        (cp >= 0xac00 && cp <= 0xd7a3) ||
        (cp >= 0xf900 && cp <= 0xfaff) ||
        (cp >= 0xfe10 && cp <= 0xfe19) ||
        (cp >= 0xfe30 && cp <= 0xfe6f) ||
        (cp >= 0xff00 && cp <= 0xff60) ||
        (cp >= 0xffe0 && cp <= 0xffe6) ||
        (cp >= 0x1f000 && cp <= 0x1faff) ||
        (cp >= 0x20000 && cp <= 0x3fffd)
      )
    ) w += 2;
    else w += 1;
  }
  return w;
}

function fit(text: string, width: number, align: Align): string {
  const gap = Math.max(0, width - wcwidth(text));
  if (align === "right") return " ".repeat(gap) + text;
  if (align === "center") {
    const left = Math.floor(gap / 2);
    return " ".repeat(left) + text + " ".repeat(gap - left);
  }
  return text + " ".repeat(gap);
}

interface Chars {
  v: string; h: string; tl: string; tm: string; tr: string; ml: string; mm: string; mr: string; bl: string; bm: string; br: string;
}

const CHARS: Record<Exclude<StyleName, "none" | "ascii2" | "markdown">, Chars> = {
  ascii: { v: "|", h: "-", tl: "+", tm: "+", tr: "+", ml: "+", mm: "+", mr: "+", bl: "+", bm: "+", br: "+" },
  sharp: { v: "│", h: "─", tl: "┌", tm: "┬", tr: "┐", ml: "├", mm: "┼", mr: "┤", bl: "└", bm: "┴", br: "┘" },
  grid: { v: "│", h: "─", tl: "┌", tm: "┬", tr: "┐", ml: "├", mm: "┼", mr: "┤", bl: "└", bm: "┴", br: "┘" },
  rounded: { v: "│", h: "─", tl: "╭", tm: "┬", tr: "╮", ml: "├", mm: "┼", mr: "┤", bl: "╰", bm: "┴", br: "╯" },
  reinforced: { v: "│", h: "─", tl: "┏", tm: "┬", tr: "┓", ml: "├", mm: "┼", mr: "┤", bl: "┗", bm: "┴", br: "┛" },
};

function sep(widths: number[], chars: Chars, pos: "top" | "mid" | "bot", indent: string): string {
  const l = pos === "top" ? chars.tl : pos === "mid" ? chars.ml : chars.bl;
  const m = pos === "top" ? chars.tm : pos === "mid" ? chars.mm : chars.bm;
  const r = pos === "top" ? chars.tr : pos === "mid" ? chars.mr : chars.br;
  return indent + l + widths.map(w => chars.h.repeat(w)).join(m) + r;
}

function renderDelimited(rows: string[][], opts: Opts): string {
  if (rows.length === 0) return "";
  const colCount = Math.max(...rows.map(r => r.length), 0);
  const full = rows.map(r => {
    const x = r.slice();
    while (x.length < colCount) x.push("");
    return x;
  });
  let data = full;
  if (opts.number) {
    data = full.map((r, idx) => {
      const n = opts.noHeaders ? String(idx + 1) : (idx === 0 ? "#" : String(idx));
      return [n, ...r];
    });
  }
  const sniffRows = opts.sniff === 0 ? data : data.slice(0, opts.sniff + (opts.noHeaders ? 0 : 1));
  const widths = Array.from({ length: data[0].length }, (_, c) => Math.max(0, ...sniffRows.map(r => wcwidth(r[c] ?? ""))) + opts.padding * 2);
  const indent = " ".repeat(opts.indent);
  const bodyStart = opts.noHeaders ? 0 : 1;

  const rowLine = (r: string[], align: Align, style: StyleName) => {
    if (style === "none") return indent + r.map((v, i) => fit(v, widths[i] - opts.padding * 2, align).padStart(fit(v, widths[i] - opts.padding * 2, align).length + opts.padding).padEnd(widths[i], " ")).join("");
    if (style === "ascii2") return indent + " " + r.map((v, i) => " ".repeat(opts.padding) + fit(v, widths[i] - opts.padding * 2, align) + " ".repeat(opts.padding)).join("|") + " ";
    const vbar = style === "markdown" ? "|" : CHARS[style as keyof typeof CHARS].v;
    return indent + vbar + r.map((v, i) => " ".repeat(opts.padding) + fit(v, widths[i] - opts.padding * 2, align) + " ".repeat(opts.padding)).join(vbar) + vbar;
  };

  const out: string[] = [];
  if (opts.style === "none") {
    data.forEach((r, idx) => out.push(rowLine(r, idx < bodyStart ? opts.headerAlign : opts.bodyAlign, "none")));
  } else if (opts.style === "ascii2") {
    if (!opts.noHeaders) {
      out.push(rowLine(data[0], opts.headerAlign, "ascii2"));
      out.push(indent + " " + widths.map(w => "-".repeat(w)).join("+") + " ");
      data.slice(1).forEach(r => out.push(rowLine(r, opts.bodyAlign, "ascii2")));
    } else data.forEach(r => out.push(rowLine(r, opts.bodyAlign, "ascii2")));
  } else if (opts.style === "markdown") {
    if (!opts.noHeaders) {
      out.push(rowLine(data[0], opts.headerAlign, "markdown"));
      out.push(indent + "|" + widths.map(w => "-".repeat(w)).join("|") + "|");
      data.slice(1).forEach(r => out.push(rowLine(r, opts.bodyAlign, "markdown")));
    } else data.forEach(r => out.push(rowLine(r, opts.bodyAlign, "markdown")));
  } else {
    const chars = CHARS[opts.style as keyof typeof CHARS];
    out.push(sep(widths, chars, "top", indent));
    data.forEach((r, idx) => {
      out.push(rowLine(r, idx < bodyStart ? opts.headerAlign : opts.bodyAlign, opts.style));
      if (!opts.noHeaders && idx === 0) out.push(sep(widths, chars, "mid", indent));
      else if (opts.style === "grid" && idx >= bodyStart && idx !== data.length - 1) out.push(sep(widths, chars, "mid", indent));
    });
    out.push(sep(widths, chars, "bot", indent));
  }
  return out.join("\n") + "\n";
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  let input = "";
  try {
    input = opts.file ? fs.readFileSync(opts.file, "utf8") : fs.readFileSync(0, "utf8");
  } catch (e: any) {
    process.stderr.write(`error: ${e.message}\n`);
    process.exit(1);
  }
  const rows = parseCsv(input, opts.delimiter);
  process.stdout.write(renderDelimited(rows, opts));
}

main();
