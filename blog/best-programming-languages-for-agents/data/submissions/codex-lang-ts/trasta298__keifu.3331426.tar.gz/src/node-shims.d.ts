declare module "child_process" {
  export function spawnSync(command: string, args?: string[], options?: any): any;
  export function execFileSync(file: string, args?: string[], options?: any): any;
}
declare module "fs" {
  export function readFileSync(path: string, encoding: string): string;
}
declare module "os" {
  export function homedir(): string;
}
declare module "path" {
  export function basename(p: string): string;
  export function join(...parts: string[]): string;
}
declare const process: any;
declare class Buffer {
  toString(encoding?: string): string;
}
