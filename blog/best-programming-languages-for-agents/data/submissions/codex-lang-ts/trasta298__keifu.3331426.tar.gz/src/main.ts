import { execFileSync, spawnSync } from "child_process";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";

type Commit = {
  hash: string;
  short: string;
  date: string;
  author: string;
  subject: string;
  refs: string;
  files: string[];
};

type Branch = {
  name: string;
  hash: string;
  head: boolean;
  remote: boolean;
};

const VERSION = "keifu 0.2.3";
const HELP = `A TUI tool to visualize Git commit graphs with branch genealogy

Usage: executable

Options:
  -h, --help     Print help
  -V, --version  Print version`;

function printUnexpected(arg: string): never {
  console.error(`error: unexpected argument '${arg}' found

Usage: executable

For more information, try '--help'.`);
  process.exit(2);
  throw new Error("unreachable");
}

function git(args: string[], cwd = process.cwd(), allowFail = false): string {
  const res = spawnSync("git", args, { cwd, encoding: "utf8" });
  if (res.status !== 0) {
    if (allowFail) return "";
    throw new Error((res.stderr || res.stdout || `git ${args.join(" ")} failed`).trim());
  }
  return res.stdout;
}

function findRepo(): string {
  const res = spawnSync("git", ["rev-parse", "--show-toplevel"], { encoding: "utf8" });
  if (res.status !== 0) {
    console.error(`Error: Git repository not found. Please run inside a Git repository.

Caused by:
    could not find repository at '.'; class=Repository (6); code=NotFound (-3)`);
    process.exit(1);
  }
  return res.stdout.trim() || process.cwd();
}

function loadBranches(repo: string): Branch[] {
  const out = git(["for-each-ref", "--format=%(refname:short)%1f%(objectname:short)%1f%(HEAD)", "refs/heads", "refs/remotes"], repo, true);
  return out.split(/\r?\n/).filter(Boolean).map((line) => {
    const [name, hash, head] = line.split("\x1f");
    return { name, hash, head: head === "*", remote: name.includes("/") };
  }).filter((b) => b.name !== "origin/HEAD");
}

function loadCommits(repo: string): Commit[] {
  const fmt = "%H%x1f%h%x1f%ad%x1f%an%x1f%s%x1f%D%x1e";
  const out = git(["log", "--all", "--max-count=500", "--date=short", `--pretty=format:${fmt}`], repo, true);
  return out.split("\x1e").map((chunk) => chunk.trim()).filter(Boolean).map((chunk) => {
    const lines = chunk.split(/\r?\n/);
    const [hash, short, date, author, subject, refs] = (lines.shift() || "").split("\x1f");
    const files = loadCommitFiles(repo, hash);
    return { hash, short, date, author, subject, refs, files };
  }).filter((c) => c.hash);
}

function loadCommitFiles(repo: string, hash: string): string[] {
  if (!hash || hash === "uncommitted") return [];
  const out = git(["show", "--first-parent", "--format=", "--name-only", "--no-renames", hash], repo, true);
  return out.split(/\r?\n/).map((s) => s.trim()).filter(Boolean).slice(0, 50);
}

function hasChanges(repo: string): boolean {
  return git(["status", "--porcelain", "--untracked-files=no"], repo, true).trim().length > 0;
}

function branchLabels(commit: Commit, branches: Branch[]): string {
  const at = branches.filter((b) => b.hash === commit.short);
  if (at.length > 0) {
    const head = at.find((b) => b.head);
    const first = head || at[0];
    return at.length === 1 ? first.name : `${first.name} +${at.length - 1}`;
  }
  let refs = (commit.refs || "").replace(/HEAD -> /g, "").replace(/tag: /g, "").split(",").map((s) => s.trim()).filter(Boolean);
  if (refs.length === 0) return "";
  return refs.length === 1 ? refs[0] : `${refs[0]} +${refs.length - 1}`;
}

function shortAuthor(s: string, width: number): string {
  if (s.length <= width) return s.padEnd(width);
  return s.slice(0, Math.max(0, width - 1)) + "…";
}

function stripAnsi(s: string): string {
  return s.replace(/\x1b\[[0-9;?]*[A-Za-z]/g, "");
}

function fit(s: string, width: number): string {
  const plain = stripAnsi(s);
  if (plain.length <= width) return s + " ".repeat(width - plain.length);
  return plain.slice(0, Math.max(0, width - 1)) + "…";
}

function color(n: number): string {
  const colors = [31, 32, 33, 34, 35, 36, 91, 92, 93, 94, 95, 96];
  return `\x1b[${colors[n % colors.length]}m`;
}

function termSize(): { cols: number; rows: number } {
  return {
    cols: process.stdout.columns || Number(process.env.COLUMNS) || 100,
    rows: process.stdout.rows || Number(process.env.LINES) || 30,
  };
}

function render(repo: string, commits: Commit[], branches: Branch[], selected: number, showHelp: boolean, message = "") {
  const { cols, rows } = termSize();
  const detailRows = Math.max(7, Math.floor(rows * 0.28));
  const listRows = Math.max(1, rows - detailRows - (showHelp ? 5 : 2));
  const top = Math.max(0, Math.min(selected - Math.floor(listRows / 2), Math.max(0, commits.length - listRows)));
  const headBranch = branches.find((b) => b.head)?.name || git(["branch", "--show-current"], repo, true).trim() || "detached";
  let out = "\x1b[H\x1b[2J";
  out += `keifu ${path.basename(repo)}  HEAD: ${headBranch}  commits: ${commits.length}\n`;
  for (let i = 0; i < listRows; i++) {
    const idx = top + i;
    if (idx >= commits.length) {
      out += "\n";
      continue;
    }
    const c = commits[idx];
    const labels = branchLabels(c, branches);
    const marker = idx === selected ? "\x1b[7m" : "";
    const reset = "\x1b[0m";
    const graph = `${color(idx)}●${reset}`;
    const label = labels ? ` [${labels}]` : "";
    const line = `${marker}${graph} ${c.date} ${shortAuthor(c.author, 14)} ${c.short}${label} ${c.subject}${reset}`;
    out += fit(line, cols) + "\n";
  }
  const c = commits[selected];
  out += "─".repeat(cols) + "\n";
  if (c) {
    out += fit(`Commit ${c.hash}`, cols) + "\n";
    out += fit(`Author ${c.author}    Date ${c.date}`, cols) + "\n";
    out += fit(c.subject, cols) + "\n";
    const files = c.files.length ? c.files : ["(no changed files listed)"];
    out += fit(`Changed files (${c.files.length})`, cols) + "\n";
    for (const f of files.slice(0, Math.max(1, detailRows - 5))) out += fit(`  ${f}`, cols) + "\n";
  } else {
    out += fit("No commits found", cols) + "\n";
  }
  if (message) out += fit(message, cols) + "\n";
  if (showHelp) {
    out += "─".repeat(cols) + "\n";
    out += fit("j/↓ down  k/↑ up  g top  G bottom  @ HEAD  R refresh  f fetch  ? help  q quit", cols) + "\n";
    out += fit("Enter checkout selected commit/branch  b create branch  d delete local branch  / search", cols) + "\n";
  }
  process.stdout.write(out);
}

function checkoutTarget(repo: string, commit: Commit, branches: Branch[]): string {
  const labels = branches.filter((b) => b.hash === commit.short);
  const local = labels.find((b) => !b.remote);
  const remote = labels.find((b) => b.remote);
  if (local) return local.name;
  if (remote) return remote.name.replace(/^origin\//, "");
  return commit.hash;
}

function promptLine(prompt: string, cb: (answer: string) => void) {
  process.stdin.setRawMode?.(false);
  process.stdout.write(`\n${prompt}`);
  let buf = "";
  const onData = (d: Buffer) => {
    const s = d.toString("utf8");
    if (s.includes("\n") || s.includes("\r")) {
      process.stdin.off("data", onData);
      process.stdin.setRawMode?.(true);
      cb(buf.trim());
    } else if (s === "\u0003" || s === "\x1b") {
      process.stdin.off("data", onData);
      process.stdin.setRawMode?.(true);
      cb("");
    } else {
      buf += s.replace(/[^\x20-\x7e]/g, "");
    }
  };
  process.stdin.on("data", onData);
}

function runTui(repo: string) {
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    console.error("Error: No such device or address (os error 6)");
    process.exit(1);
  }
  let branches = loadBranches(repo);
  let commits = loadCommits(repo);
  if (hasChanges(repo)) {
    commits = [{ hash: "uncommitted", short: "changes", date: "", author: "", subject: "uncommitted changes", refs: "HEAD", files: [] }, ...commits];
  }
  let selected = 0;
  let help = false;
  let message = "";
  process.stdin.setRawMode?.(true);
  process.stdin.resume();
  process.stdout.write("\x1b[?1049h\x1b[?25l");
  const cleanup = () => {
    process.stdout.write("\x1b[?1049l\x1b[?25h\x1b[0m");
    process.stdin.setRawMode?.(false);
  };
  process.on("exit", cleanup);
  process.on("SIGINT", () => process.exit(0));
  const refresh = () => {
    branches = loadBranches(repo);
    commits = loadCommits(repo);
    if (hasChanges(repo)) commits = [{ hash: "uncommitted", short: "changes", date: "", author: "", subject: "uncommitted changes", refs: "HEAD", files: [] }, ...commits];
    selected = Math.min(selected, Math.max(0, commits.length - 1));
    render(repo, commits, branches, selected, help, message);
  };
  refresh();
  const timer = setInterval(refresh, readRefreshInterval());
  process.stdin.on("data", (data: Buffer) => {
    const s = data.toString("utf8");
    if (s.includes("q") || s.includes("\x1b")) {
      clearInterval(timer);
      process.exit(0);
    } else if (s === "j" || s === "\x1b[B" || s === "\t" || s === "\u0004") {
      selected = Math.min(commits.length - 1, selected + 1);
    } else if (s === "k" || s === "\x1b[A" || s === "\x1b[Z" || s === "\u0015") {
      selected = Math.max(0, selected - 1);
    } else if (s === "g" || s === "\x1b[H") {
      selected = 0;
    } else if (s === "G" || s === "\x1b[F") {
      selected = Math.max(0, commits.length - 1);
    } else if (s === "?" ) {
      help = !help;
    } else if (s === "R") {
      message = "Repository refreshed";
      refresh();
      return;
    } else if (s === "f") {
      const r = spawnSync("git", ["fetch", "origin"], { cwd: repo, encoding: "utf8" });
      message = r.status === 0 ? "Fetched origin" : (r.stderr || "Fetch failed").trim();
    } else if (s === "\r" || s === "\n") {
      const c = commits[selected];
      if (c && c.hash !== "uncommitted") {
        const target = checkoutTarget(repo, c, branches);
        const r = spawnSync("git", ["checkout", target], { cwd: repo, encoding: "utf8" });
        message = r.status === 0 ? `Checked out ${target}` : (r.stderr || "Checkout failed").trim();
      }
    } else if (s === "b") {
      const c = commits[selected];
      if (c && c.hash !== "uncommitted") promptLine("New branch name: ", (name) => {
        if (name) {
          const r = spawnSync("git", ["branch", name, c.hash], { cwd: repo, encoding: "utf8" });
          message = r.status === 0 ? `Created branch ${name}` : (r.stderr || "Create branch failed").trim();
        }
        refresh();
      });
      return;
    } else if (s === "d") {
      const c = commits[selected];
      const b = c && branches.find((x) => x.hash === c.short && !x.remote && !x.head);
      if (b) {
        const r = spawnSync("git", ["branch", "-d", b.name], { cwd: repo, encoding: "utf8" });
        message = r.status === 0 ? `Deleted branch ${b.name}` : (r.stderr || "Delete branch failed").trim();
      } else message = "No deletable local branch selected";
    } else if (s === "@" ) {
      const head = branches.find((b) => b.head);
      const idx = head ? commits.findIndex((c) => c.short === head.hash) : -1;
      if (idx >= 0) selected = idx;
    } else if (s === "/") {
      promptLine("Search branch: ", (q) => {
        if (q) {
          const b = branches.find((x) => x.name.toLowerCase().includes(q.toLowerCase()));
          const idx = b ? commits.findIndex((c) => c.short === b.hash) : -1;
          if (idx >= 0) selected = idx;
          else message = "No branch found";
        }
        refresh();
      });
      return;
    }
    render(repo, commits, branches, selected, help, message);
  });
}

function readRefreshInterval(): number {
  const cfg = path.join(os.homedir(), ".config", "keifu", "config.toml");
  try {
    const text = fs.readFileSync(cfg, "utf8");
    if (/auto_refresh\s*=\s*false/.test(text)) return 2147483647;
    const m = text.match(/refresh_interval\s*=\s*(\d+)/);
    if (m) return Math.max(1, Number(m[1])) * 1000;
  } catch {}
  return 10000;
}

function main() {
  const args = process.argv.slice(2);
  if (args.length > 1) printUnexpected(args[0]);
  if (args[0] === "-h" || args[0] === "--help") {
    console.log(HELP);
    return;
  }
  if (args[0] === "-V" || args[0] === "--version") {
    console.log(VERSION);
    return;
  }
  if (args.length === 1) printUnexpected(args[0]);
  const repo = findRepo();
  runTui(repo);
}

main();
