declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

const VERSION = "xplr 1.1.0";

const HELP = `xplr 1.1.0
Arijit Basu <hi@arijitbasu.in>
A hackable, minimal, fast TUI file explorer

USAGE:
    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...

FLAGS:
  -                            Reads new-line (\\n) separated paths from stdin
  --                           Denotes the end of command-line flags and options
      --force-focus            Focuses on the given <PATH>, even if it is a directory
  -h, --help                   Prints help information
  -m, --pipe-msg-in            Helps safely passing messages to the active xplr
                                 session, use %%, %s and %q as the placeholders
  -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of
                                 passing to the active xplr session
      --print-pwd-as-result    Prints the present working directory when quitting
                                 with \`PrintResultAndQuit\`
      --read-only              Enables read-only mode (config.general.read_only)
      --read0                  Reads paths separated using the null character (\\0)
      --write0                 Prints paths separated using the null character (\\0)
  -0  --null                   Combines --read0 and --write0
  -V, --version                Prints version information

OPTIONS:
  -c, --config <PATH>             Specifies a custom config file (default is
                                    "$HOME/.config/xplr/init.lua")
  -C, --extra-config <PATH>...    Specifies extra config files to load
      --on-load <MESSAGE>...      Sends messages when xplr loads
      --vroot <PATH>              Treats the specified path as the virtual root

ARGS:
  <PATH>            Path to focus on, or enter if directory, (default is \`.\`)
  <SELECTION>...    Paths to select, requires <PATH> to be set explicitly`;

const VARIANTS = new Set([
  "ExplorePwd","ExplorePwdAsync","ExploreParentsAsync","TryCompletePath","ClearScreen","Refresh",
  "FocusNext","FocusNextSelection","FocusNextByRelativeIndex","FocusNextByRelativeIndexFromInput",
  "FocusPrevious","FocusPreviousSelection","FocusPreviousByRelativeIndex","FocusPreviousByRelativeIndexFromInput",
  "FocusFirst","FocusLast","FocusPath","FocusPathFromInput","FocusByIndex","FocusByIndexFromInput",
  "FocusByFileName","ScrollUp","ScrollDown","ScrollUpHalf","ScrollDownHalf","ChangeDirectory","Enter",
  "Back","LastVisitedPath","NextVisitedPath","PreviousVisitedDeepBranch","NextVisitedDeepBranch",
  "FollowSymlink","SetVroot","UnsetVroot","ToggleVroot","ResetVroot","SetInputPrompt","UpdateInputBuffer",
  "UpdateInputBufferFromKey","BufferInput","BufferInputFromKey","SetInputBuffer","RemoveInputBufferLastCharacter",
  "RemoveInputBufferLastWord","ResetInputBuffer","SwitchMode","SwitchModeKeepingInputBuffer","SwitchModeBuiltin",
  "SwitchModeBuiltinKeepingInputBuffer","SwitchModeCustom","SwitchModeCustomKeepingInputBuffer","PopMode",
  "PopModeKeepingInputBuffer","SwitchLayout","SwitchLayoutBuiltin","SwitchLayoutCustom","Call","Call0",
  "CallSilently","CallSilently0","BashExec","BashExec0","BashExecSilently","BashExecSilently0","CallLua",
  "CallLuaSilently","LuaEval","LuaEvalSilently","Select","SelectAll","SelectPath","UnSelect","UnSelectAll",
  "UnSelectPath","ToggleSelection","ToggleSelectAll","ToggleSelectionByPath","ClearSelection","AddNodeFilter",
  "RemoveNodeFilter","ToggleNodeFilter","AddNodeFilterFromInput","RemoveNodeFilterFromInput","RemoveLastNodeFilter",
  "ResetNodeFilters","ClearNodeFilters","AddNodeSorter","RemoveNodeSorter","ReverseNodeSorter","ToggleNodeSorter",
  "ReverseNodeSorters","RemoveLastNodeSorter","ResetNodeSorters","ClearNodeSorters","Search","SearchFromInput",
  "SearchFuzzy","SearchFuzzyFromInput","SearchFuzzyUnordered","SearchFuzzyUnorderedFromInput","SearchRegex",
  "SearchRegexFromInput","SearchRegexUnordered","SearchRegexUnorderedFromInput","ToggleSearchAlgorithm",
  "EnableSearchOrder","DisableSearchOrder","ToggleSearchOrder","AcceptSearch","CancelSearch","EnableMouse",
  "DisableMouse","ToggleMouse","StartFifo","StopFifo","ToggleFifo","LogInfo","LogSuccess","LogWarning",
  "LogError","Debug","Quit","PrintPwdAndQuit","PrintFocusPathAndQuit","PrintSelectionAndQuit",
  "PrintResultAndQuit","PrintAppStateAndQuit","Terminate"
]);

function fail(msg: string): never {
  process.stderr.write(`error: ${msg}\n`);
  process.exit(1);
  throw new Error(msg);
}

function usage(opt: string): never {
  const forms: Record<string, string> = {
    "-c": "xplr -c PATH",
    "--config": "xplr -c PATH",
    "--vroot": "xplr --vroot PATH",
    "-M": "xplr -M FORMAT [ARGUMENT]...",
    "--print-msg-in": "xplr -M FORMAT [ARGUMENT]...",
    "-m": "xplr -m FORMAT [ARGUMENT]...",
    "--pipe-msg-in": "xplr -m FORMAT [ARGUMENT]..."
  };
  fail(`usage: ${forms[opt] ?? `xplr ${opt}`}`);
}

function absolutize(p: string): string {
  return path.isAbsolute(p) ? path.normalize(p) : path.resolve(process.cwd(), p);
}

function mustExist(p: string): void {
  const full = absolutize(p);
  if (!fs.existsSync(full)) fail(`path doesn't exist: ${full}`);
}

function jsonQuote(s: string): string {
  return JSON.stringify(s);
}

function formatTemplate(fmt: string, vals: string[]): string {
  let out = "";
  let i = 0;
  let vi = 0;
  while (i < fmt.length) {
    if (fmt[i] !== "%") {
      out += fmt[i++];
      continue;
    }
    const col = i + 1;
    i++;
    if (i >= fmt.length) fail("xplr -m: template ended with incomplete placeholder");
    if (fmt[i] === "%") {
      out += "%";
      i++;
    } else if (fmt[i] === "s") {
      if (vi >= vals.length) fail(`xplr -m: placeholder missing value at column ${col}`);
      out += vals[vi++];
      i++;
    } else if (fmt[i] === "q") {
      if (vi >= vals.length) fail(`xplr -m: placeholder missing value at column ${col}`);
      out += jsonQuote(vals[vi++]);
      i++;
    } else if (fmt[i] === "*" && fmt[i + 1] === "q") {
      const rest = vals.slice(vi).map(jsonQuote).join(",");
      vi = vals.length;
      out += rest;
      i += 2;
    } else {
      fail(`xplr -m: invalid placeholder '%${fmt[i]}' at column ${col}, use one of '%s' or '%q', or escape it using '%%'`);
    }
  }
  if (vi < vals.length) fail("xplr -m: too many positional values, not enough positional placeholders");
  return out;
}

function quoteBareKeys(flow: string): string {
  return flow.replace(/([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)(\s*:)/g, "$1\"$2\"$3");
}

function parseScalar(s: string): unknown {
  const t = s.trim();
  if (t === "") return "";
  if (/^-?\d+$/.test(t)) return Number(t);
  if (t === "true") return true;
  if (t === "false") return false;
  if ((t.startsWith("\"") && t.endsWith("\"")) || t.startsWith("{") || t.startsWith("[") || t === "null") {
    return JSON.parse(quoteBareKeys(t));
  }
  return t;
}

function renderMessage(input: string): string {
  const text = input.trim();
  try {
    if (text.startsWith("{") || text.startsWith("[") || (text.startsWith("\"") && text.endsWith("\""))) {
      const value = JSON.parse(quoteBareKeys(text));
      if (typeof value === "string" && !VARIANTS.has(value)) throw new Error(`unknown variant \`${value}\``);
      return JSON.stringify(value);
    }
    const m = text.match(/^([A-Za-z_][A-Za-z0-9_]*):(.*)$/s);
    if (m) {
      const key = m[1];
      const val = parseScalar(m[2]);
      return JSON.stringify({ [key]: val });
    }
    if (VARIANTS.has(text)) return JSON.stringify(text);
    throw new Error(`unknown variant \`${text}\``);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (msg.startsWith("unknown variant")) fail(`${msg} at line 1 column 1`);
    fail(`xplr -m: yaml: ${msg}`);
  }
}

function handleMessage(printOnly: boolean, args: string[], flag: string): never {
  if (args.length === 0) usage(flag);
  const rendered = renderMessage(formatTemplate(args[0], args.slice(1)));
  if (printOnly) {
    process.stdout.write(rendered);
    process.exit(0);
    throw new Error("unreachable");
  }
  const pipe = process.env.XPLR_PIPE_MSG_IN;
  if (!pipe) {
    process.stdout.write(rendered + "\n");
    process.exit(0);
  }
  if (!fs.existsSync(pipe)) fail("No such file or directory (os error 2)");
  fs.appendFileSync(pipe, rendered + "\n");
  process.exit(0);
  throw new Error("unreachable");
}

function readStdin(read0: boolean): string[] {
  const data = fs.readFileSync(0);
  const sep = read0 ? "\0" : "\n";
  return data.toString("utf8").split(sep).filter((x: string) => x.length > 0);
}

function main(): void {
  const argv = process.argv.slice(2);
  let read0 = false;
  let stdinPaths = false;
  const positional: string[] = [];
  let endFlags = false;

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!endFlags && (a === "-M" || a === "--print-msg-in")) handleMessage(true, argv.slice(i + 1), a);
    if (!endFlags && (a === "-m" || a === "--pipe-msg-in")) handleMessage(false, argv.slice(i + 1), a);
    if (!endFlags && (a === "-h" || a === "--help")) {
      process.stdout.write(HELP + "\n");
      return;
    }
    if (!endFlags && (a === "-V" || a === "--version")) {
      process.stdout.write(VERSION + "\n");
      return;
    }
    if (!endFlags && a === "--") {
      endFlags = true;
      continue;
    }
    if (!endFlags && a === "-") {
      stdinPaths = true;
      continue;
    }
    if (!endFlags && (a === "--read0")) {
      read0 = true;
      continue;
    }
    if (!endFlags && (a === "-0" || a === "--null")) {
      read0 = true;
      continue;
    }
    if (!endFlags && (a === "--write0" || a === "--read-only" || a === "--force-focus" || a === "--print-pwd-as-result")) {
      continue;
    }
    if (!endFlags && (a === "-c" || a === "--config" || a === "--vroot")) {
      if (i + 1 >= argv.length) usage(a);
      mustExist(argv[++i]);
      continue;
    }
    if (!endFlags && (a === "-C" || a === "--extra-config" || a === "--on-load")) {
      while (i + 1 < argv.length && !argv[i + 1].startsWith("-")) {
        i++;
        if (a !== "--on-load") mustExist(argv[i]);
      }
      continue;
    }
    if (!endFlags && a.startsWith("-")) {
      fail(`invalid argument: "${a}", try \`-- "${a}"\` or \`--help\``);
    }
    positional.push(a);
  }

  const inputs = stdinPaths ? readStdin(read0) : [];
  const allPaths = inputs.concat(positional);
  for (const p of allPaths) mustExist(p);
  fail("No such device or address (os error 6)");
}

main();
