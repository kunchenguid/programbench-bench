declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");
const os = require("os");

type Detail =
  | "dev" | "ino" | "nlink" | "typ" | "perm" | "oct" | "user" | "uid"
  | "group" | "gid" | "size" | "blocks" | "btime" | "ctime" | "mtime"
  | "atime" | "git" | "none" | "std" | "all";

type SortKey =
  | "dev" | "ino" | "nlink" | "typ" | "cat" | "user" | "uid" | "group"
  | "gid" | "size" | "blocks" | "btime" | "ctime" | "mtime" | "atime"
  | "name" | "cname" | "ext" | "none";

interface Options {
  details: Detail[];
  header: boolean;
  unit: "binary" | "decimal" | "none";
  grid: boolean;
  down: boolean;
  icon: boolean;
  suffix: boolean;
  sym: boolean;
  collapse: boolean;
  align: boolean;
  types: string[];
  imp: number;
  exclude?: RegExp;
  only?: RegExp;
  sorts: { key: SortKey; rev: boolean }[];
  paths: string[];
}

interface NodeInfo {
  inputPath: string;
  fullPath: string;
  name: string;
  st: any;
  kind: string;
  target?: string;
  error?: string;
}

const VERSION = "pls 0.0.1-beta.9";
const detailVals = ["dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid", "size", "blocks", "btime", "ctime", "mtime", "atime", "git", "none", "std", "all"];
const typeVals = ["dir", "symlink", "fifo", "socket", "block-device", "char-device", "file", "none", "all"];
const sortVals = ["dev", "ino", "nlink", "typ", "cat", "user", "uid", "group", "gid", "size", "blocks", "btime", "ctime", "mtime", "atime", "name", "cname", "ext", "inode_", "nlinks_", "typ_", "cat_", "user_", "uid_", "group_", "gid_", "size_", "blocks_", "btime_", "ctime_", "mtime_", "atime_", "name_", "cname_", "ext_", "none"];

function help(): string {
  return `pls is a prettier and powerful ls(1) for the pros.

Read docs: https://pls.cli.rs/
Get source: https://github.com/pls-rs/pls/
Sponsor: https://github.com/sponsors/dhruvkb/

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          the paths to list, each of which may be a file or directory

          [default: .]

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Detail view:
  -d, --det <DETAILS>
          the data points to show about each node

          [default: none]
          [possible values: ${detailVals.join(", ")}]

  -H, --header <HEADER>
          show headers above columnar data

          [default: true]
          [possible values: true, false]

  -u, --unit <UNIT>
          the type of units to use for the node sizes

          [default: binary]
          [possible values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>
          display node names in multiple columns

          [default: false]
          [possible values: true, false]

  -D, --down <DOWN>
          display node names column-first

          [default: false]
          [possible values: true, false]

Presentation:
  -i, --icon <ICON>
          display icons next to node names

          [default: true]
          [possible values: true, false]

  -S, --suffix <SUFFIX>
          display node type suffixes after the node name

          [default: true]
          [possible values: true, false]

  -l, --sym <SYM>
          show symlink targets

          [default: true]
          [possible values: true, false]

  -c, --collapse <COLLAPSE>
          show dependent nodes as children of their principal nodes

          [default: true]
          [possible values: true, false]

  -a, --align <ALIGN>
          align items accounting for leading dots

          [default: true]
          [possible values: true, false]

Filtering:
  -t, --typ <TYPES>
          the set of node types to include in the output

          [default: all]
          [possible values: ${typeVals.join(", ")}]

  -I, --imp <IMP>
          the importance cutoff to dim or hide unimportant files

          [default: 0]

  -e, --exclude <EXCLUDE>
          the pattern of files to selectively hide from the output

  -o, --only <ONLY>
          the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>
          the set of fields to sort by, trailing \`_\` reverses the direction

          [default: cat cname]
          [possible values: ${sortVals.join(", ")}]`;
}

function dieArg(msg: string, code = 2): never {
  console.error(msg);
  process.exit(code);
  throw new Error(msg);
}

function readValue(args: string[], i: number, opt: string): [string, number] {
  if (i + 1 >= args.length) dieArg(`error: a value is required for '${opt} <${opt.toUpperCase()}>' but none was supplied\n\nFor more information, try '--help'.`);
  return [args[i + 1], i + 1];
}

function boolVal(v: string, opt: string): boolean {
  if (v === "true") return true;
  if (v === "false") return false;
  dieArg(`error: invalid value '${v}' for '${opt} <${opt.replace(/^-+/, "").toUpperCase()}>'\n  [possible values: true, false]\n\nFor more information, try '--help'.`);
}

function parseRegex(v: string, opt: string): RegExp {
  try {
    return new RegExp(v);
  } catch (e: any) {
    dieArg(`error: invalid value '${v}' for '${opt} <${opt === "--only" || opt === "-o" ? "ONLY" : "EXCLUDE"}>': ${String(e.message).replace(/^Invalid regular expression: /, "regex parse error: ")}\n\nFor more information, try '--help'.`);
  }
}

function parseArgs(argv: string[]): Options {
  const opt: Options = {
    details: ["none"],
    header: true,
    unit: "binary",
    grid: false,
    down: false,
    icon: true,
    suffix: true,
    sym: true,
    collapse: true,
    align: true,
    types: ["all"],
    imp: 0,
    sorts: [{ key: "cat", rev: false }, { key: "cname", rev: false }],
    paths: [],
  };
  const detailSeen: Detail[] = [];
  const typeSeen: string[] = [];
  const sortSeen: { key: SortKey; rev: boolean }[] = [];
  let positionalOnly = false;
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (positionalOnly) { opt.paths.push(a); continue; }
    if (a === "--") { positionalOnly = true; continue; }
    if (a === "-h" || a === "--help") { console.log(help()); process.exit(0); }
    if (a === "-V" || a === "--version") { console.log(VERSION); process.exit(0); }
    let inline: string | undefined;
    if (a.startsWith("--") && a.includes("=")) {
      const parts = a.split(/=(.*)/s);
      a = parts[0];
      inline = parts[1];
    }
    const get = (name: string): string => {
      if (inline !== undefined) return inline;
      const got = readValue(argv, i, name);
      i = got[1];
      return got[0];
    };
    switch (a) {
      case "-d": case "--det": {
        const v = get(a) as Detail;
        if (!detailVals.includes(v)) dieArg(`error: invalid value '${v}' for '--det <DETAILS>'\n  [possible values: ${detailVals.join(", ")}]\n\nFor more information, try '--help'.`);
        detailSeen.push(v);
        break;
      }
      case "-H": case "--header": opt.header = boolVal(get(a), a); break;
      case "-u": case "--unit": {
        const v = get(a);
        if (!["binary", "decimal", "none"].includes(v)) dieArg(`error: invalid value '${v}' for '--unit <UNIT>'\n  [possible values: binary, decimal, none]\n\nFor more information, try '--help'.`);
        opt.unit = v as Options["unit"];
        break;
      }
      case "-g": case "--grid": opt.grid = boolVal(get(a), a); break;
      case "-D": case "--down": opt.down = boolVal(get(a), a); break;
      case "-i": case "--icon": opt.icon = boolVal(get(a), a); break;
      case "-S": case "--suffix": opt.suffix = boolVal(get(a), a); break;
      case "-l": case "--sym": opt.sym = boolVal(get(a), a); break;
      case "-c": case "--collapse": opt.collapse = boolVal(get(a), a); break;
      case "-a": case "--align": opt.align = boolVal(get(a), a); break;
      case "-t": case "--typ": {
        const v = get(a);
        if (!typeVals.includes(v)) dieArg(`error: invalid value '${v}' for '--typ <TYPES>'\n  [possible values: ${typeVals.join(", ")}]\n\nFor more information, try '--help'.`);
        typeSeen.push(v);
        break;
      }
      case "-I": case "--imp": opt.imp = Number(get(a)) || 0; break;
      case "-e": case "--exclude": opt.exclude = parseRegex(get(a), a); break;
      case "-o": case "--only": opt.only = parseRegex(get(a), a); break;
      case "-s": case "--sort": {
        const raw = get(a);
        if (!sortVals.includes(raw)) dieArg(`error: invalid value '${raw}' for '--sort <SORT_BASES>'\n  [possible values: ${sortVals.join(", ")}]\n\nFor more information, try '--help'.`);
        const rev = raw.endsWith("_");
        const base = raw.replace(/_$/, "");
        let key = (base === "inode" ? "ino" : base === "nlinks" ? "nlink" : base) as SortKey;
        sortSeen.push({ key, rev });
        break;
      }
      default:
        if (a.startsWith("-") && a !== "-") dieArg(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.`);
        opt.paths.push(a);
    }
  }
  if (detailSeen.length) opt.details = expandDetails(detailSeen);
  if (typeSeen.length) opt.types = typeSeen;
  if (sortSeen.length) opt.sorts = sortSeen;
  if (!opt.paths.length) opt.paths = ["."];
  return opt;
}

function expandDetails(vals: Detail[]): Detail[] {
  const out: Detail[] = [];
  for (const v of vals) {
    if (v === "none") return ["none"];
    if (v === "std") out.push("nlink", "typ", "perm", "user", "group", "size", "mtime");
    else if (v === "all") out.push("dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid", "size", "blocks", "btime", "ctime", "mtime", "atime", "git");
    else out.push(v);
  }
  return [...new Set(out)].filter(v => v !== "none");
}

function kind(st: any): string {
  if (st.isDirectory()) return "dir";
  if (st.isSymbolicLink()) return "symlink";
  if (st.isFIFO()) return "fifo";
  if (st.isSocket()) return "socket";
  if (st.isBlockDevice()) return "block-device";
  if (st.isCharacterDevice()) return "char-device";
  return "file";
}

function typeLetter(k: string): string {
  return ({ dir: "d", symlink: "l", fifo: "p", socket: "s", "block-device": "b", "char-device": "c", file: "f" } as Record<string, string>)[k] || "f";
}

function userName(uid: number): string {
  if (typeof process.getuid === "function" && uid === process.getuid()) return os.userInfo().username;
  return String(uid);
}

function groupName(gid: number): string {
  const u = os.userInfo();
  if (gid === u.gid) return u.username;
  return String(gid);
}

function perms(mode: number): string {
  const bit = (n: number, ch: string) => (mode & n ? ch : "-");
  return `${bit(0o400, "r")}${bit(0o200, "w")}${bit(0o100, "x")} ${bit(0o040, "r")}${bit(0o020, "w")}${bit(0o010, "x")} ${bit(0o004, "r")}${bit(0o002, "w")}${bit(0o001, "x")}`;
}

function oct(mode: number): string {
  return (mode & 0o7777).toString(8).slice(-3);
}

function fmtDate(d: Date): string {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  let h = d.getHours();
  const ampm = h >= 12 ? "pm" : "am";
  h %= 12; if (h === 0) h = 12;
  return `${d.getFullYear()}-${months[d.getMonth()]}-${String(d.getDate()).padStart(2, "0")} ${String(h).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}${ampm}`;
}

function fmtSize(n: number, unit: Options["unit"]): string {
  if (unit === "none") return `${n} B`;
  const base = unit === "decimal" ? 1000 : 1024;
  const suffixes = unit === "decimal" ? ["B", "kB", "MB", "GB", "TB"] : ["B", "KiB", "MiB", "GiB", "TiB"];
  let v = n, idx = 0;
  while (idx < suffixes.length - 1 && Math.abs(v) >= base) { v /= base; idx++; }
  const w = unit === "decimal" ? 2 : 3;
  return `${v.toFixed(1)} ${suffixes[idx].padStart(w)}`;
}

function iconFor(n: NodeInfo): string {
  if (n.kind === "dir") return "\uf07b";
  if (n.kind === "symlink") return "\udb80\udf39";
  if (n.kind === "fifo") return "\udb81\udfe5";
  const lower = n.name.toLowerCase();
  if (lower.endsWith(".rs")) return "\ue68b";
  if (lower.endsWith(".txt")) return "\ue612";
  if (n.name === "Makefile" || n.name.toLowerCase().includes("makefile")) return "\udb81\udf2e";
  return " ";
}

function suffixFor(n: NodeInfo): string {
  if (n.kind === "dir") return "/";
  if (n.kind === "symlink") return "@";
  if (n.kind === "fifo") return "|";
  if (n.kind === "socket") return "=";
  if (n.kind === "file" && (n.st.mode & 0o111)) return "*";
  return "";
}

function displayName(n: NodeInfo, opt: Options): string {
  let s = n.name + (opt.suffix ? suffixFor(n) : "");
  if (n.kind === "symlink" && opt.sym && n.target !== undefined) s += ` \udb80\udc54 ${n.target}`;
  return s;
}

function collectPath(p: string): { nodes?: NodeInfo[]; err?: string; file?: NodeInfo } {
  try {
    const st = fs.lstatSync(p);
    const n = toNode(p, p, st);
    if (!st.isDirectory()) return { file: n };
    const entries = fs.readdirSync(p);
    const nodes = entries.map(name => {
      const fp = path.join(p, name);
      return toNode(fp, name, fs.lstatSync(fp));
    });
    return { nodes };
  } catch (e: any) {
    if (e?.code === "ENOENT") return { err: "No such file or directory (os error 2)" };
    if (e?.code === "EACCES") return { err: "Permission denied (os error 13)" };
    return { err: e?.message || "No such file or directory (os error 2)" };
  }
}

function toNode(fullPath: string, name: string, st: any): NodeInfo {
  const n: NodeInfo = { inputPath: fullPath, fullPath, name, st, kind: kind(st) };
  if (n.kind === "symlink") {
    try { n.target = fs.readlinkSync(fullPath); } catch {}
  }
  return n;
}

function includeNode(n: NodeInfo, opt: Options): boolean {
  if (!opt.types.includes("all")) {
    if (opt.types.includes("none")) return false;
    if (!opt.types.includes(n.kind)) return false;
  }
  if (opt.exclude && opt.exclude.test(n.name)) return false;
  if (opt.only && !opt.only.test(n.name)) return false;
  return true;
}

function cmpVal(n: NodeInfo, key: SortKey): string | number {
  switch (key) {
    case "dev": return n.st.dev;
    case "ino": return n.st.ino;
    case "nlink": return n.st.nlink;
    case "typ": return typeLetter(n.kind);
    case "cat": return catRank(n);
    case "user": return userName(n.st.uid);
    case "uid": return n.st.uid;
    case "group": return groupName(n.st.gid);
    case "gid": return n.st.gid;
    case "size": return n.st.size;
    case "blocks": return n.st.blocks;
    case "btime": return n.st.birthtimeMs;
    case "ctime": return n.st.ctimeMs;
    case "mtime": return n.st.mtimeMs;
    case "atime": return n.st.atimeMs;
    case "name": return n.name;
    case "cname": return n.name.toLowerCase().replace(/^\./, "");
    case "ext": return path.extname(n.name).replace(/^\./, "").toLowerCase();
    case "none": return 0;
  }
}

function catRank(n: NodeInfo): number {
  if (n.kind === "dir") return 0;
  return 1;
}

function sortNodes(nodes: NodeInfo[], opt: Options): NodeInfo[] {
  if (opt.sorts.some(s => s.key === "none")) return nodes;
  return [...nodes].sort((a, b) => {
    for (const s of opt.sorts) {
      const av = cmpVal(a, s.key), bv = cmpVal(b, s.key);
      let c = 0;
      if (typeof av === "number" && typeof bv === "number") c = av - bv;
      else c = String(av).localeCompare(String(bv));
      if (c !== 0) return s.rev ? -c : c;
    }
    return a.name.localeCompare(b.name);
  });
}

interface Col { name: Detail | "name"; head: string; value: (n: NodeInfo) => string; }

function columns(opt: Options): Col[] {
  const map: Record<string, Col> = {
    dev: { name: "dev", head: "Device", value: n => String(n.st.dev) },
    ino: { name: "ino", head: "inode", value: n => String(n.st.ino) },
    nlink: { name: "nlink", head: "Link#", value: n => String(n.st.nlink) },
    typ: { name: "typ", head: "T", value: n => typeLetter(n.kind) },
    perm: { name: "perm", head: "Permissions", value: n => perms(n.st.mode) },
    oct: { name: "oct", head: "SUGO", value: n => oct(n.st.mode) },
    user: { name: "user", head: "User", value: n => userName(n.st.uid) },
    uid: { name: "uid", head: "UID", value: n => String(n.st.uid) },
    group: { name: "group", head: "Group", value: n => groupName(n.st.gid) },
    gid: { name: "gid", head: "GID", value: n => String(n.st.gid) },
    size: { name: "size", head: "Size", value: n => n.kind === "dir" ? "" : fmtSize(n.st.size, opt.unit) },
    blocks: { name: "blocks", head: "Blocks", value: n => String(n.st.blocks) },
    btime: { name: "btime", head: "Created", value: n => fmtDate(n.st.birthtime) },
    ctime: { name: "ctime", head: "Changed", value: n => fmtDate(n.st.ctime) },
    mtime: { name: "mtime", head: "Modified", value: n => fmtDate(n.st.mtime) },
    atime: { name: "atime", head: "Accessed", value: n => fmtDate(n.st.atime) },
    git: { name: "git", head: "Git", value: _n => "" },
  };
  const out = opt.details.filter(d => d !== "none").map(d => map[d]).filter(Boolean);
  out.push({ name: "name", head: "Name", value: n => displayName(n, opt) });
  return out;
}

function renderNodes(nodes: NodeInfo[], opt: Options): string[] {
  const filtered = sortNodes(nodes.filter(n => includeNode(n, opt)), opt);
  if (opt.details.length === 1 && opt.details[0] === "none") return filtered.map(n => renderSimple(n, opt));
  const cols = columns(opt);
  const rows = filtered.map(n => cols.map(c => c.value(n)));
  const widths = cols.map((c, idx) => Math.max(c.head.length, ...rows.map(r => r[idx].length)));
  const lines: string[] = [];
  if (opt.header) lines.push(cols.map((c, i) => pad(c.head, widths[i], rightAlign(c.name))).join(" "));
  for (const r of rows) {
    lines.push(r.map((v, i) => i === r.length - 1 ? v : pad(v, widths[i], rightAlign(cols[i].name))).join(" "));
  }
  return lines;
}

function rightAlign(name: Detail | "name"): boolean {
  return ["dev", "ino", "nlink", "oct", "uid", "gid", "size", "blocks"].includes(name);
}

function pad(s: string, w: number, right: boolean): string {
  return right ? s.padStart(w) : s.padEnd(w);
}

function renderSimple(n: NodeInfo, opt: Options): string {
  const name = displayName(n, opt);
  if (!opt.icon) return (opt.align && !n.name.startsWith(".") ? " " : "") + name;
  return `${iconFor(n)}  ${opt.align && !n.name.startsWith(".") ? " " : ""}${name}`;
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  const listed: { path: string; lines: string[]; isDir: boolean }[] = [];
  const errors: string[] = [];
  const files: NodeInfo[] = [];
  const dirs: { path: string; nodes: NodeInfo[] }[] = [];
  for (const p of opt.paths) {
    const c = collectPath(p);
    if (c.err) errors.push(`${p}:\n\terror: ${c.err}`);
    else if (c.file) files.push(c.file);
    else if (c.nodes) dirs.push({ path: p, nodes: c.nodes });
  }
  if (errors.length) console.error(errors.join("\n"));
  if (files.length) listed.push({ path: "", lines: renderNodes(files, opt), isDir: false });
  for (const d of dirs) listed.push({ path: d.path, lines: renderNodes(d.nodes, opt), isDir: true });
  const showHeaders = opt.paths.length > 1;
  listed.forEach((item, idx) => {
    if ((errors.length || idx > 0) && (item.lines.length || showHeaders)) console.log("");
    if (showHeaders && item.isDir) console.log(`${item.path}:`);
    for (const l of item.lines) console.log(l);
  });
}

main();
