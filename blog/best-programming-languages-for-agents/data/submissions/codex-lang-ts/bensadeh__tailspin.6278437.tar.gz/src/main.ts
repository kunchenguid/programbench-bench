declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const childProcess = require("child_process");

const RESET = "\x1b[0m";
const CODES: Record<string, string> = {
  red: "\x1b[31m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  magenta: "\x1b[35m",
  cyan: "\x1b[36m",
  white: "\x1b[37m",
  dim: "\x1b[2m",
  italicRed: "\x1b[3;31m",
  italicBlue: "\x1b[3;34m",
  dimGreen: "\x1b[2;32m",
  dimBlue: "\x1b[2;34m",
  get: "\x1b[42;30m",
  post: "\x1b[43;30m",
};

const VALID_GROUPS = [
  "numbers",
  "urls",
  "pointers",
  "dates",
  "paths",
  "quotes",
  "key-value-pairs",
  "uuids",
  "ip-addresses",
  "processes",
  "json",
] as const;

type Group = (typeof VALID_GROUPS)[number];

interface Args {
  follow: boolean;
  print: boolean;
  file?: string;
  exec?: string;
  configPath?: string;
  pager?: string;
  highlights: Array<{ color: string; words: string[] }>;
  enable?: Set<Group>;
  disable: Set<Group>;
  disableBuiltin: boolean;
}

function color(code: string, text: string): string {
  return `${code}${text}${RESET}`;
}

function help(long: boolean): string {
  if (!long) {
    return `A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]  Filepath

Options:
  -f, --follow
          Follow the contents of a file
  -p, --print
          Print the output to stdout
      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file
  -e, --exec <EXEC>
          Run command and view the output in a pager
      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
          quotes, key-value-pairs, uuids, ip-addresses, processes, json]
      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
          quotes, key-value-pairs, uuids, ip-addresses, processes, json]
      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)
      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. \`--pager="ov -f [FILE]"\`) [env:
          TAILSPIN_PAGER=]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
`;
  }
  return `A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          Filepath

Options:
  -f, --follow
          Follow the contents of a file

  -p, --print
          Print the output to stdout

      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file

  -e, --exec <EXEC>
          Run command and view the output in a pager

      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
          
          [possible values: red, green, yellow, blue, magenta, cyan]

      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)

      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. \`--pager="ov -f [FILE]"\`)
          
          [env: TAILSPIN_PAGER=]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
`;
}

function die(message: string, code = 2): never {
  process.stderr.write(message);
  process.exit(code);
  throw new Error(message);
}

function parseList(value: string, opt: string): Group[] {
  const groups = value.split(",").filter(Boolean);
  for (const group of groups) {
    if (!VALID_GROUPS.includes(group as Group)) {
      die(`error: invalid value '${group}' for '${opt} <${opt === "--enable" ? "ENABLED" : "DISABLED"}_HIGHLIGHTERS>'
  [possible values: ${VALID_GROUPS.join(", ")}]

For more information, try '--help'.
`);
    }
  }
  return groups as Group[];
}

function takeValue(argv: string[], i: number, opt: string): [string, number] {
  const value = argv[i + 1];
  if (value === undefined) {
    die(`error: a value is required for '${opt} <VALUE>' but none was supplied

For more information, try '--help'.
`);
  }
  return [value, i + 1];
}

function parseArgs(argv: string[]): Args {
  const args: Args = {
    follow: false,
    print: false,
    highlights: [],
    disable: new Set<Group>(),
    disableBuiltin: false,
  };
  let literal = false;
  for (let i = 0; i < argv.length; i++) {
    const raw = argv[i];
    if (!literal && raw === "--") {
      literal = true;
      continue;
    }
    if (!literal && (raw === "-h" || raw === "--help")) {
      process.stdout.write(help(raw === "--help"));
      process.exit(0);
    }
    if (!literal && (raw === "-V" || raw === "--version")) {
      process.stdout.write("tspin 5.6.0\n");
      process.exit(0);
    }
    if (!literal && (raw === "-f" || raw === "--follow")) {
      args.follow = true;
      continue;
    }
    if (!literal && (raw === "-p" || raw === "--print")) {
      args.print = true;
      continue;
    }
    if (!literal && raw === "--disable-builtin-keywords") {
      args.disableBuiltin = true;
      continue;
    }
    if (!literal && (raw === "-e" || raw === "--exec" || raw.startsWith("--exec="))) {
      let value: string;
      if (raw.startsWith("--exec=")) {
        value = raw.slice("--exec=".length);
      } else {
        [value, i] = takeValue(argv, i, raw);
      }
      args.exec = value;
      continue;
    }
    if (!literal && (raw === "--config-path" || raw.startsWith("--config-path="))) {
      let value: string;
      if (raw.startsWith("--config-path=")) {
        value = raw.slice("--config-path=".length);
      } else {
        [value, i] = takeValue(argv, i, raw);
      }
      args.configPath = value;
      continue;
    }
    if (!literal && (raw === "--pager" || raw.startsWith("--pager="))) {
      let value: string;
      if (raw.startsWith("--pager=")) {
        value = raw.slice("--pager=".length);
      } else {
        [value, i] = takeValue(argv, i, raw);
      }
      args.pager = value;
      continue;
    }
    if (!literal && (raw === "--highlight" || raw.startsWith("--highlight="))) {
      let value: string;
      if (raw.startsWith("--highlight=")) {
        value = raw.slice("--highlight=".length);
      } else {
        [value, i] = takeValue(argv, i, raw);
      }
      const colon = value.indexOf(":");
      const c = colon < 0 ? value : value.slice(0, colon);
      if (!["red", "green", "yellow", "blue", "magenta", "cyan"].includes(c)) {
        die(`error: invalid value '${value}' for '--highlight <COLOR_WORD>': invalid variant: ${c}

For more information, try '--help'.
`);
      }
      const words = colon < 0 ? [] : value.slice(colon + 1).split(",").filter(Boolean);
      args.highlights.push({ color: c, words });
      continue;
    }
    if (!literal && (raw === "--enable" || raw.startsWith("--enable="))) {
      let value: string;
      if (raw.startsWith("--enable=")) {
        value = raw.slice("--enable=".length);
      } else {
        [value, i] = takeValue(argv, i, raw);
      }
      args.enable = new Set([...(args.enable ?? []), ...parseList(value, "--enable")]);
      continue;
    }
    if (!literal && (raw === "--disable" || raw.startsWith("--disable="))) {
      let value: string;
      if (raw.startsWith("--disable=")) {
        value = raw.slice("--disable=".length);
      } else {
        [value, i] = takeValue(argv, i, raw);
      }
      for (const group of parseList(value, "--disable")) args.disable.add(group);
      continue;
    }
    if (!literal && raw.startsWith("-")) {
      die(`error: unexpected argument '${raw}' found

  tip: to pass '${raw}' as a value, use '-- ${raw}'

Usage: executable [OPTIONS] [FILE]

For more information, try '--help'.
`);
    }
    if (args.file === undefined) {
      args.file = raw;
    } else {
      die(`error: unexpected argument '${raw}' found

Usage: executable [OPTIONS] [FILE]

For more information, try '--help'.
`);
    }
  }
  if (args.enable && args.disable.size > 0) {
    die("Error:   × cannot both enable and disable highlighters\n\n", 1);
  }
  return args;
}

function enabled(args: Args, group: Group): boolean {
  if (args.enable) return args.enable.has(group);
  return !args.disable.has(group);
}

function addSpan(spans: Span[], start: number, end: number, code: string): void {
  if (end <= start) return;
  for (const span of spans) {
    if (start < span.end && end > span.start) return;
  }
  spans.push({ start, end, code });
}

interface Span {
  start: number;
  end: number;
  code: string;
}

function escapeRegex(text: string): string {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function collect(re: RegExp, line: string, spans: Span[], code: string, groupIndex = 0): void {
  for (const match of line.matchAll(re)) {
    const value = match[groupIndex];
    if (value === undefined) continue;
    const base = match.index ?? 0;
    const prefix = match[0].indexOf(value);
    addSpan(spans, base + prefix, base + prefix + value.length, code);
  }
}

function collectDates(line: string, spans: Span[]): void {
  collect(/\b\d{4}[-/]\d{2}[-/]\d{2}(?:[T ]\d{2}:\d{2}:\d{2}(?:[,.]\d+)?Z?)?/g, line, spans, CODES.magenta);
  collect(/\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\b/g, line, spans, CODES.magenta);
  collect(/\b(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\b/g, line, spans, CODES.magenta);
  collect(/\b\d{2}:\d{2}:\d{2}(?:[,.]\d+)?\b/g, line, spans, CODES.blue);
  collect(/(?<=\d)T(?=\d)|(?<=\d)Z\b/g, line, spans, CODES.red);
}

function collectPaths(line: string, spans: Span[]): void {
  for (const match of line.matchAll(/(?:^|[\s=])((?:\/[\w.@+-]+)+\/?)/g)) {
    const path = match[1];
    const start = (match.index ?? 0) + match[0].indexOf(path);
    let offset = start;
    for (const part of path.split(/(\/)/)) {
      if (!part) continue;
      addSpan(spans, offset, offset + part.length, part === "/" ? CODES.yellow : CODES.green);
      offset += part.length;
    }
  }
  collect(/[A-Za-z]:\\(?:[^:\s"']+\\?)+/g, line, spans, CODES.green);
}

function collectUrl(line: string, spans: Span[]): void {
  for (const match of line.matchAll(/\b(https?|ftp):\/\/[^\s"'<>]+/g)) {
    const url = match[0];
    const start = match.index ?? 0;
    const scheme = match[1];
    addSpan(spans, start, start + scheme.length, CODES.dimGreen);
    const rest = url.slice(scheme.length + 3);
    const slash = rest.search(/[/?#]/);
    const hostLen = slash < 0 ? rest.length : slash;
    addSpan(spans, start + scheme.length + 3, start + scheme.length + 3 + hostLen, CODES.dimBlue);
    if (slash >= 0) addSpan(spans, start + scheme.length + 3 + hostLen, start + url.length, CODES.blue);
  }
}

function collectIp(line: string, spans: Span[]): void {
  for (const match of line.matchAll(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g)) {
    const start = match.index ?? 0;
    let offset = start;
    for (const part of match[0].split(/(\.)/)) {
      addSpan(spans, offset, offset + part.length, part === "." ? CODES.red : CODES.italicBlue);
      offset += part.length;
    }
  }
  collect(/\b(?:[0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F:.%]+\b/g, line, spans, CODES.italicBlue);
}

function collectKeyValue(line: string, spans: Span[]): void {
  for (const match of line.matchAll(/(^|[\s,{])([A-Za-z_][\w.-]*)(=|:)(?=\S)/g)) {
    const start = (match.index ?? 0) + match[0].indexOf(match[2]);
    if (match[3] === ":" && line.slice(start + match[2].length + 1, start + match[2].length + 3) === "//") {
      continue;
    }
    addSpan(spans, start, start + match[2].length, CODES.dim);
    addSpan(spans, start + match[2].length, start + match[2].length + match[3].length, CODES.white);
  }
}

function collectJson(line: string, spans: Span[]): void {
  collect(/"([^"\\]*(?:\\.[^"\\]*)*)"(?=\s*:)/g, line, spans, CODES.yellow, 0);
}

function collectNumbers(line: string, spans: Span[]): void {
  collect(/(?<![\w.-])[-+]?\d+(?:\.\d+)?(?![\w.-])/g, line, spans, CODES.cyan);
}

function collectBuiltin(line: string, spans: Span[]): void {
  collect(/\b(?:ERROR|ERR|FATAL)\b/g, line, spans, CODES.red);
  collect(/\b(?:WARN|WARNING)\b/g, line, spans, CODES.yellow);
  collect(/\bINFO\b/g, line, spans, CODES.white);
  collect(/\bDEBUG\b/g, line, spans, CODES.green);
  collect(/\bTRACE\b/g, line, spans, CODES.dim);
  collect(/\bGET\b/g, line, spans, CODES.get);
  collect(/\b(?:POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\b/g, line, spans, CODES.post);
  collect(/\b(?:true|false|null|nil|None)\b/g, line, spans, CODES.italicRed);
}

function highlightLine(line: string, args: Args): string {
  const spans: Span[] = [];
  for (const custom of args.highlights) {
    for (const word of custom.words) {
      collect(new RegExp(`(?<![\\w])${escapeRegex(word)}(?![\\w])`, "g"), line, spans, CODES[custom.color]);
    }
  }
  if (enabled(args, "urls")) collectUrl(line, spans);
  if (enabled(args, "dates")) collectDates(line, spans);
  if (enabled(args, "key-value-pairs")) collectKeyValue(line, spans);
  if (enabled(args, "json")) collectJson(line, spans);
  if (enabled(args, "quotes")) collect(/"([^"\\]*(?:\\.[^"\\]*)*)"/g, line, spans, CODES.yellow, 0);
  if (enabled(args, "ip-addresses")) collectIp(line, spans);
  if (enabled(args, "uuids")) collect(/[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/g, line, spans, CODES.italicBlue);
  if (enabled(args, "paths")) collectPaths(line, spans);
  if (enabled(args, "processes")) collect(/\b[\w.-]+\[\d+\]/g, line, spans, CODES.yellow);
  if (enabled(args, "pointers")) collect(/\b0x[0-9a-fA-F]+\b/g, line, spans, CODES.italicBlue);
  if (!args.disableBuiltin) collectBuiltin(line, spans);
  if (enabled(args, "numbers")) collectNumbers(line, spans);
  spans.sort((a, b) => a.start - b.start || b.end - a.end);
  let out = "";
  let pos = 0;
  for (const span of spans) {
    if (span.start < pos) continue;
    out += line.slice(pos, span.start);
    out += color(span.code, line.slice(span.start, span.end));
    pos = span.end;
  }
  return out + line.slice(pos);
}

function highlight(text: string, args: Args): string {
  const parts = text.split(/(\n)/);
  return parts.map((part) => (part === "\n" ? part : highlightLine(part, args))).join("");
}

function readStdin(): string {
  return fs.readFileSync(0, "utf8");
}

function readInput(args: Args): string {
  if (args.exec !== undefined) {
    try {
      return childProcess.execSync(args.exec, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"], shell: "/bin/bash" });
    } catch (error) {
      const e = error as { stdout?: string; stderr?: string; status?: number };
      if (e.stdout) return e.stdout;
      if (e.stderr) process.stderr.write(e.stderr);
      process.exit(typeof e.status === "number" ? e.status : 1);
    }
  }
  if (args.file) {
    try {
      return fs.readFileSync(args.file, "utf8");
    } catch (error) {
      const e = error as { code?: string; message: string };
      const reason = e.code === "ENOENT" ? "No such file or directory" : e.message;
      process.stderr.write(`Error:   ⚠ ${color(CODES.yellow, args.file)}: ${reason}\n\n`);
      process.exit(1);
    }
  }
  return readStdin();
}

function followFile(path: string, args: Args): void {
  let offset = 0;
  try {
    const initial = fs.readFileSync(path, "utf8");
    offset = Buffer.byteLength(initial);
    process.stdout.write(highlight(initial, args));
  } catch (error) {
    const e = error as { code?: string; message: string };
    process.stderr.write(`Error:   ⚠ ${color(CODES.yellow, path)}: ${e.code === "ENOENT" ? "No such file or directory" : e.message}\n\n`);
    process.exit(1);
  }
  fs.watchFile(path, { interval: 500 }, () => {
    const stat = fs.statSync(path);
    if (stat.size < offset) offset = 0;
    if (stat.size > offset) {
      const fd = fs.openSync(path, "r");
      const buf = Buffer.alloc(stat.size - offset);
      fs.readSync(fd, buf, 0, buf.length, offset);
      fs.closeSync(fd);
      offset = stat.size;
      process.stdout.write(highlight(buf.toString("utf8"), args));
    }
  });
}

function main(): void {
  const args = parseArgs(process.argv.slice(2));
  if (args.configPath) {
    try {
      fs.accessSync(args.configPath, fs.constants.R_OK);
    } catch {
      process.stderr.write("Error:   × could not find the TOML file\n\n");
      process.exit(1);
    }
  }
  if (args.follow && args.file) {
    followFile(args.file, args);
    return;
  }
  const input = readInput(args);
  process.stdout.write(highlight(input, args));
}

main();
