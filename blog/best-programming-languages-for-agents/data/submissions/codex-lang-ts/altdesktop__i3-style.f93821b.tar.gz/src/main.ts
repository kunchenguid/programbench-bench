declare const process: any;
declare function require(name: string): any;

const fs = require("fs");
const path = require("path");
const os = require("os");
const child_process = require("child_process");

type WinKey = "focused" | "focused_inactive" | "unfocused" | "urgent";
type WsKey = "focused_workspace" | "active_workspace" | "inactive_workspace" | "urgent_workspace";
type Theme = {
  description: string;
  colors: Record<string, string>;
  window_colors: Record<WinKey, string[]>;
  bar_colors: {
    background?: string;
    statusline?: string;
    separator?: string;
  } & Record<WsKey, string[]>;
};

const ORDER = [
  ["slate", "Slate theme by Jody Ribton <jody@ribton.me>"],
  ["alphare", "A beige theme by Alphare"],
  ["ubuntu", "Ubuntu theme by lasers"],
  ["flat-gray", "flat gray based theme"],
  ["purple", "Purple theme by AAlakkad <http://aalakkad.me>"],
  ["archlinux", "Archlinux theme by okraits <http://okraits.de>"],
  ["default", "Default theme for i3wm <http://i3wm.org>"],
  ["debian", "Debian theme by lasers"],
  ["oceanic-next", "Theme by Valentin Weber inspired by voronianski (https://github.com/voronianski/oceanic-next-color-scheme)"],
  ["base16-tomorrow", "Base16 Tomorrow, by Chris Kempson (http://chriskempson.com)"],
  ["okraits", "A simple theme by okraits <http://okraits.de>"],
  ["icelines", "icelines theme by mbfraga"],
  ["solarized", "Solarized theme by lasers"],
  ["deep-purple", "Inspired by the Purple and Default themes. By jcpst <http://jcpst.com>"],
  ["tomorrow-night-80s", "Tomorrow Night 80s theme by jmfurlott <http://jmfurlott.com>"],
  ["seti", "seti theme by Jody Ribton - based on the seti Atom theme at https://atom.io/themes/seti-ui"],
  ["lime", "Lime theme by wei2912 <http://wei2912.github.io>, based on Archlinux theme by okraits <http://okraits.de>"],
  ["gruvbox", "Made by freeware-preacher <https://github.com/freeware-preacher> to match gruvbox by morhetz <https://github.com/morhetz>"],
  ["mate", "Theme for blending i3 into MATE"],
] as const;

const rawThemes: Record<string, string[]> = {
  slate: ["#586e75","#002b36","#aea79f","#586e75 #586e75 #ffffff","#073642 #073642 #ffffff","#002b36 #002b36 #aea79f","#77216f #77216f #ffffff","#586e75 #586e75 #fdf6e3 #268bd2","#073642 #073642 #93a1a1 #002b36","#002b36 #002b36 #586e75 #002b36","#dc322f #dc322f #fdf6e3 #dc322f"],
  alphare: ["#000000","#FDF6E3","#002B36","#000000 #268BD2 #FFFFFF","#333333 #222222 #FFFFFF","#333333 #222222 #888888","#2F343A #900000 #FFFFFF","#000000 #FDF6E3 #002B36 #000000","#000000 #5F676A #FDF6E3 #484E50","#000000 #000000 #FDF6E3 #000000","#000000 #DC322F #FDF6E3 #DC322F"],
  ubuntu: ["#333333","#2c001e","#aea79f","#dd4814 #dd4814 #ffffff","#902a07 #902a07 #aea79f","#902a07 #902a07 #aea79f","#77216f #77216f #ffffff","#dd4814 #dd4814 #ffffff #902a07","#5e2750 #5e2750 #aea79f #5e2750","#5e2750 #5e2750 #aea79f #5e2750","#77216f #77216f #ffffff #efb73e"],
  "flat-gray": ["#111111","#333333","#AAAAAA","#282828 #282828 #FFFFFF","#111111 #111111 #111111","#333333 #333333 #AAAAAA","#111111 #111111 #111111","#000000 #000000 #FFFFFF #000000","#333333 #333333 #FFFFFF #000000","#333333 #333333 #FFFFFF #333333","#111111 #111111 #111111 #111111"],
  purple: ["#AAAAAA","#222133","#FFFFFF","#664477 #664477 #cccccc","#DCCD69 #DCCD69 #181715","#222133 #222133 #AAAAAA","#CE4045 #CE4045 #FFFFFF","#664477 #664477 #cccccc #e7d8b1","#e7d8b1 #e7d8b1 #181715 #A074C4","#222133 #222133 #AAAAAA #A074C4","#CE4045 #CE4045 #e7d8b1 #DCCD69"],
  archlinux: ["#666666","#222222","#dddddd","#0088CC #0088CC #ffffff","#333333 #333333 #ffffff","#333333 #333333 #888888","#2f343a #900000 #ffffff","#0088CC #0088CC #ffffff #dddddd","#333333 #333333 #888888 #292d2e","#333333 #333333 #888888 #292d2e","#2f343a #900000 #ffffff #900000"],
  default: ["#666666","#000000","#ffffff","#4c7899 #285577 #ffffff","#333333 #5f676a #ffffff","#333333 #222222 #888888","#2f343a #900000 #ffffff","#4c7899 #285577 #ffffff #2e9ef4","#333333 #5f676a #ffffff #484e50","#333333 #222222 #888888 #292d2e","#2f343a #900000 #ffffff #900000"],
  debian: ["#444444","#222222","#666666","#d70a53 #d70a53 #ffffff","#333333 #333333 #888888","#333333 #333333 #888888","#eb709b #eb709b #ffffff","#d70a53 #d70a53 #ffffff #8c0333","#333333 #333333 #888888 #333333","#333333 #333333 #888888 #333333","#eb709b #eb709b #ffffff #eb709b"],
  "oceanic-next": ["#65737E","#1B2B34","#D8DEE9","#6699CC #6699CC #1B2B34","#5FB3B3 #5FB3B3 #1B2B34","#343D46 #343D46 #D8DEE9","#EC5f67 #EC5f67 #1B2B34","#6699CC #6699CC #1B2B34 #6699CC","#5FB3B3 #5FB3B3 #D8DEE9 #A7ADBA","#343D46 #343D46 #D8DEE9 #343D46","#EC5f67 #EC5f67 #1B2B34 #EC5f67"],
  "base16-tomorrow": ["#969896","#1d1f21","#c5c8c6","#81a2be #81a2be #1d1f21","#373b41 #373b41 #ffffff","#282a2e #282a2e #969896","#cc6666 #cc6666 #ffffff","#81a2be #81a2be #1d1f21 #282a2e","#373b41 #373b41 #969896 #282a2e","#282a2e #282a2e #969896 #282a2e","#373b41 #cc6666 #ffffff #cc6666"],
  okraits: ["#666666","#333333","#bbbbbb","#888888 #dddddd #222222","#333333 #555555 #bbbbbb","#333333 #555555 #bbbbbb","#2f343a #900000 #ffffff","#888888 #dddddd #222222 #2e9ef4","#333333 #555555 #bbbbbb #484e50","#333333 #333333 #888888 #292d2e","#2f343a #900000 #ffffff #900000"],
  icelines: ["#7d7d7d","#141414","#00b0ef","#00b0ef #141414 #00b0ef","#141414 #141414 #00b0ef","#141414 #141414 #7d7d7d","#ff7066 #141414 #ff7066","#00b0ef #00b0ef #141414 #ff7066","#141414 #141414 #00b0ef #472b2a","#141414 #141414 #7d7d7d #141414","#ff7066 #ff7066 #141414 #ff7066"],
  solarized: ["#dc322f","#002b36","#268bd2","#fdf6e3 #859900 #fdf6e3","#fdf6e3 #6c71c4 #fdf6e3","#586e75 #93a1a1 #002b36","#d33682 #d33682 #fdf6e3","#859900 #859900 #fdf6e3 #6c71c4","#073642 #073642 #eee8d5 #6c71c4","#073642 #073642 #93a1a1 #586e75","#d33682 #d33682 #fdf6e3 #dc322f"],
  "deep-purple": ["#666666","#000000","#ffffff","#551a8b #551a8b #ffffff","#333333 #5f676a #ffffff","#000000 #000000 #888888","#2f343a #900000 #ffffff","#3b1261 #3b1261 #ffffff #662b9c","#333333 #5f676a #ffffff #484e50","#222222 #222222 #888888 #292d2e","#2f343a #900000 #ffffff #900000"],
  "tomorrow-night-80s": ["#515151","#2d2d2d","#cccccc","#99cc99 #99cc99 #000000","#333333 #333333 #ffffff","#2d2d2d #2d2d2d #999999","#f2777a #f2777a #ffffff","#99cc99 #99cc99 #000000 #2d2d2d","#393939 #393939 #888888 #292d2e","#2d2d2d #2d2d2d #999999 #292d2e","#2f343a #900000 #ffffff #900000"],
  seti: ["#AAAAAA","#1f2326","#FFFFFF","#9FCA56 #9FCA56 #151718","#DCCD69 #DCCD69 #151718","#1f2326 #1f2326 #AAAAAA","#CE4045 #CE4045 #FFFFFF","#4F99D3 #4F99D3 #151718 #9FCA56","#9FCA56 #9FCA56 #151718 #A074C4","#1f2326 #1f2326 #AAAAAA #A074C4","#CE4045 #CE4045 #FFFFFF #DCCD69"],
  lime: ["#888888","#333333","#FFFFFF","#4E9C00 #4E9C00 #FFFFFF","#333333 #333333 #FFFFFF","#333333 #333333 #888888","#C20000 #C20000 #FFFFFF","#4E9C00 #4E9C00 #FFFFFF #FFFFFF","#1B3600 #1B3600 #888888 #FFFFFF","#333333 #333333 #888888 #FFFFFF","#C20000 #C20000 #FFFFFF #FFFFFF"],
  gruvbox: ["#928374","#282828","#ebdbb2","#689d6a #689d6a #282828","#1d2021 #1d2021 #928374","#32302f #32302f #928374","#cc241d #cc241d #ebdbb2","#689d6a #689d6a #282828 #282828","#1d2021 #1d2021 #928374 #282828","#32302f #32302f #928374 #282828","#cc241d #cc241d #ebdbb2 #282828"],
  mate: ["#ffffff","#3c3b37","#ffffff","#526532 #526532 #ffffff","#aea79f #aea79f #3c3b37","#3c3b37 #3c3b37 #aea79f","#FF0000 #FF0000 #ffffff","#526532 #526532 #ffffff #a4cb64","#aea79f #aea79f #3c3b37 #aea79f","#3c3b37 #3c3b37 #aea79f #3c3b37","#FF0000 #FF0000 #ffffff #FF0000"],
};

const themes: Record<string, Theme> = {};
for (const [name, desc] of ORDER) {
  const r = rawThemes[name];
  themes[name] = {
    description: desc,
    colors: {},
    bar_colors: {
      separator: r[0], background: r[1], statusline: r[2],
      focused_workspace: r[3].split(/\s+/), active_workspace: r[4].split(/\s+/),
      inactive_workspace: r[5].split(/\s+/), urgent_workspace: r[6].split(/\s+/),
    } as any,
    window_colors: {
      focused: r[7].split(/\s+/), focused_inactive: r[8].split(/\s+/),
      unfocused: r[9].split(/\s+/), urgent: r[10].split(/\s+/),
    },
  };
}

function help() {
  console.log(`i3-style 1.0
Make your i3 config a bit more stylish

USAGE:
    executable [FLAGS] [OPTIONS] [theme]

FLAGS:
    -h, --help        Prints help information
    -l, --list-all    Print a list of all available themes
    -r, --reload      Apply the theme by reloading the config
    -s, --save        Set the output file to the path of the input file
    -V, --version     Prints version information

OPTIONS:
    -c, --config <file>      The config file the theme should be applied to. Defaults to the default i3 location.
    -o, --output <file>      Apply the theme, attempt to validate the result, and write it to <file>
    -t, --to-theme <file>    Prints an i3-style theme based on the given config suitable for sharing with others
                             [default: ]

ARGS:
    <theme>    The theme to use`);
}

function parseArgs(argv: string[]) {
  const a: any = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const x = argv[i];
    if (x === "-h" || x === "--help") a.help = true;
    else if (x === "-V" || x === "--version") a.version = true;
    else if (x === "-l" || x === "--list-all") a.list = true;
    else if (x === "-r" || x === "--reload") a.reload = true;
    else if (x === "-s" || x === "--save") a.save = true;
    else if (x === "-c" || x === "--config") a.config = argv[++i] || "";
    else if (x === "-o" || x === "--output") a.output = argv[++i] || "";
    else if (x === "-t" || x === "--to-theme") a.toTheme = argv[++i] || "";
    else a._.push(x);
  }
  return a;
}

function defaultConfig(): string | null {
  const home = process.env.HOME || os.homedir();
  const old = path.join(home, ".i3", "config");
  const modern = path.join(home, ".config", "i3", "config");
  if (fs.existsSync(old)) return old;
  if (fs.existsSync(modern)) return modern;
  return old;
}

function resolveTheme(name: string): Theme | null {
  if (themes[name]) return themes[name];
  if (name && fs.existsSync(name)) return parseTheme(fs.readFileSync(name, "utf8"));
  return null;
}

function unquote(v: string) {
  return v.trim().replace(/^["']|["']$/g, "");
}

function parseTheme(text: string): Theme {
  const t: Theme = {
    description: "CUSTOM THEME",
    colors: {},
    window_colors: {} as any,
    bar_colors: {} as any,
  };
  let section = "", sub = "";
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith("#") || line.trim() === "---") continue;
    const indent = (line.match(/^\s*/) || [""])[0].length;
    const m = line.trim().match(/^([A-Za-z0-9_-]+):\s*(.*)$/);
    if (!m) continue;
    const key = m[1], val = unquote(m[2] || "");
    if (indent === 0) { section = key; sub = ""; continue; }
    if (section === "meta" && key === "description") t.description = val;
    else if (section === "colors" && val) t.colors[key] = val;
    else if ((section === "window_colors" || section === "bar_colors") && indent === 2) {
      if (val) (t as any)[section][key] = ref(val, t.colors);
      else sub = key;
    } else if ((section === "window_colors" || section === "bar_colors") && indent >= 4 && sub) {
      const map: Record<string, number> = { border: 0, background: 1, text: 2, indicator: 3 };
      const idx = map[key];
      if (idx !== undefined) {
        const arr = ((t as any)[section][sub] ||= []);
        arr[idx] = ref(val, t.colors);
      }
    }
  }
  const def = themes.default;
  for (const k of ["focused","focused_inactive","unfocused","urgent"] as WinKey[]) {
    t.window_colors[k] = fill(t.window_colors[k], def.window_colors[k]);
  }
  for (const k of ["focused_workspace","active_workspace","inactive_workspace","urgent_workspace"] as WsKey[]) {
    (t.bar_colors as any)[k] = fill((t.bar_colors as any)[k], (def.bar_colors as any)[k]);
  }
  t.bar_colors.background ||= def.bar_colors.background;
  t.bar_colors.statusline ||= def.bar_colors.statusline;
  t.bar_colors.separator ||= def.bar_colors.separator;
  return t;
}

function ref(v: string, colors: Record<string, string>): string {
  return colors[v] || v;
}
function fill(arr: string[] | undefined, def: string[]): string[] {
  const out = def.slice();
  if (arr) for (let i = 0; i < arr.length; i++) if (arr[i]) out[i] = arr[i];
  return out;
}

const hexRe = /#[0-9A-Fa-f]{6}/g;
function applyTheme(config: string, theme: Theme): string {
  const lines = config.split(/\r?\n/);
  const hadFinalNewline = /\n$/.test(config);
  const seenWin: Record<string, boolean> = {};
  const seenBar: Record<string, boolean> = {};
  let inColors = false, braceDepth = 0;
  const out: string[] = [];
  for (const line of lines) {
    if (line === "" && out.length === lines.length - 1 && !hadFinalNewline) { out.push(line); continue; }
    const trim = line.trim();
    const ind = (line.match(/^\s*/) || [""])[0];
    if (/^colors\s*\{/.test(trim)) { inColors = true; braceDepth = 1; out.push(line); continue; }
    if (inColors) {
      if (trim.includes("{")) braceDepth += (trim.match(/\{/g) || []).length;
      if (trim.includes("}")) {
        braceDepth -= (trim.match(/\}/g) || []).length;
        if (braceDepth <= 0) {
          for (const k of ["separator","background","statusline"]) {
            if (!seenBar[k]) out.push(`  ${k} ${(theme.bar_colors as any)[k]}`);
          }
          inColors = false;
        }
      }
      const bm = trim.match(/^(separator|background|statusline)\b/);
      const wm = trim.match(/^(focused_workspace|active_workspace|inactive_workspace|urgent_workspace)\b/);
      if (bm) {
        seenBar[bm[1]] = true;
        out.push(`${ind}${bm[1]} ${(theme.bar_colors as any)[bm[1]]}`);
        continue;
      } else if (wm) {
        seenBar[wm[1]] = true;
        const old = trim.match(hexRe) || [];
        const extra = old.length >= 3 ? ` ${old[2]}` : "";
        out.push(`${ind}${wm[1]} ${(theme.bar_colors as any)[wm[1]].join(" ")}${extra}`);
        continue;
      }
    }
    const cm = trim.match(/^(client\.(focused_inactive|focused|unfocused|urgent))\b/);
    if (cm) {
      const key = cm[2] as WinKey;
      seenWin[key] = true;
      out.push(`${ind}${cm[1]} ${theme.window_colors[key].join(" ")}`);
      continue;
    }
    out.push(line);
  }
  while (out.length && out[out.length - 1] === "") out.pop();
  for (const k of ["focused","focused_inactive","unfocused","urgent"] as WinKey[]) {
    if (!seenWin[k]) out.push(`client.${k} ${theme.window_colors[k].join(" ")}`);
  }
  return out.join("\n") + "\n";
}

function validate(file: string, display = file): boolean {
  try {
    child_process.execFileSync("i3", ["-C", "-c", file], { stdio: "ignore" });
    return true;
  } catch {
    console.error("Could not validate config.");
    console.error(`Use \`i3 -C -c ${display}\` to see validation errors.`);
    return false;
  }
}

function toTheme(config: string): string {
  const vals: Record<string, string[]> = {};
  const scanOrder: string[] = [];
  for (const line of config.split(/\r?\n/)) {
    const tr = line.trim();
    const key = (tr.match(/^(client\.(?:focused_inactive|focused|unfocused|urgent)|separator|background|statusline|focused_workspace|inactive_workspace|urgent_workspace)\b/) || [])[1];
    if (key) {
      vals[key] = tr.match(hexRe) || [];
      scanOrder.push(...vals[key]);
    }
  }
  const colorNames = ["black","maroon","green","olive","navy","purple","teal","silver","gray","red","lime","yellow","blue","fuchsia","aqua","white"];
  const known: Record<string,string> = {
    "#DC322F":"crimson","#002B36":"darkslategray","#268BD2":"steelblue","#FDF6E3":"oldlace","#859900":"olive",
    "#586E75":"dimgray","#93A1A1":"darkgray","#D33682":"mediumvioletred","#6C71C4":"slateblue","#073642":"darkslategray",
    "#EEE8D5":"antiquewhite"
  };
  const names: Record<string,string> = {};
  const ordered: string[] = [];
  function add(c: string) {
    if (!c) return "";
    const up = c.toUpperCase();
    if (!names[up]) {
      let base = known[up] || colorNames[ordered.length] || `color${ordered.length}`;
      let n = base, i = 1;
      while (Object.values(names).includes(n)) n = `${base}-${i++}`;
      names[up] = n; ordered.push(up);
    }
    return names[up];
  }
  const wkeys: [string,string][] = [["focused","client.focused"],["focused_inactive","client.focused_inactive"],["unfocused","client.unfocused"],["urgent","client.urgent"]];
  const bkeys: [string,string][] = [["focused_workspace","focused_workspace"],["urgent_workspace","urgent_workspace"]];
  scanOrder.forEach(add);
  let s = "---\nmeta:\n  description: AUTOMATICALLY GENERATED THEME\ncolors:\n";
  for (const c of ordered) s += `  ${names[c]}: "${c}"\n`;
  s += "window_colors:\n";
  for (const [name,k] of wkeys) {
    const a = vals[k] || [];
    s += `  ${name}:\n    border: ${add(a[0])}\n    background: ${add(a[1])}\n    text: ${add(a[2])}\n    indicator: ${add(a[3])}\n`;
  }
  s += "bar_colors:\n";
  s += `  background: ${add((vals.background || [])[0])}\n  statusline: ${add((vals.statusline || [])[0])}\n  separator: ${add((vals.separator || [])[0])}\n`;
  for (const [name,k] of bkeys) {
    const a = vals[k] || [];
    s += `  ${name}:\n    border: ${add(a[0])}\n    background: ${add(a[1])}\n    text: ${add(a[2])}\n`;
  }
  return s;
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) return help();
  if (args.version) return console.log("i3-style 1.0");
  if (args.list) {
    console.log("Available themes:\n");
    for (const [n,d] of ORDER) console.log(`  ${n.padEnd(18)} - ${d}`);
    return;
  }
  if (args.toTheme !== undefined) {
    const cfg = args.toTheme || args.config || defaultConfig();
    if (!cfg || !fs.existsSync(cfg)) { console.error("Could not find i3 config"); process.exit(1); }
    if (!validate(cfg, cfg)) process.exit(1);
    process.stdout.write(toTheme(fs.readFileSync(cfg, "utf8")));
    return;
  }
  const themeName = args._[0];
  const theme = resolveTheme(themeName || "");
  if (!theme) { console.error("Could not find i3 config"); process.exit(1); }
  const cfgPath = args.config || defaultConfig();
  if (!cfgPath || !fs.existsSync(cfgPath)) { console.error("Could not find i3 config"); process.exit(1); }
  const input = fs.readFileSync(cfgPath, "utf8");
  const rendered = applyTheme(input, theme);
  const outPath = args.save ? cfgPath : args.output;
  if (outPath) {
    const tmpRoot = path.join(os.tmpdir(), "i3-style", String(Math.floor(Math.random() * 1000000000)));
    fs.mkdirSync(tmpRoot, { recursive: true });
    const tmp = path.join(tmpRoot, "config-input");
    fs.writeFileSync(tmp, rendered);
    console.error(`saving config at ${cfgPath} to ${tmp}`);
    if (!validate(tmp, cfgPath)) process.exit(1);
    fs.writeFileSync(outPath, rendered);
  } else {
    const tmp = path.join(os.tmpdir(), `i3-style-${process.pid}`);
    fs.writeFileSync(tmp, rendered);
    if (!validate(tmp, cfgPath)) { try { fs.unlinkSync(tmp); } catch {} process.exit(1); }
    try { fs.unlinkSync(tmp); } catch {}
    process.stdout.write(rendered);
  }
  if (args.reload) {
    try { child_process.execFileSync("i3-msg", ["reload"], { stdio: "ignore" }); } catch {}
  }
}

main();
