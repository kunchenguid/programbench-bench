declare const require: any;
declare const process: any;
declare const Buffer: any;

const fs = require('fs');
const path = require('path');

const PROG = './executable';
const XZ_MAGIC = [0xfd,0x37,0x7a,0x58,0x5a,0x00];
const FOOTER_MAGIC = [0x59,0x5a];

function makeCrc32Table() {
  const t: number[] = [];
  for (let n=0;n<256;n++) {
    let c=n;
    for (let k=0;k<8;k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) >>> 0 : (c >>> 1);
    t[n]=c>>>0;
  }
  return t;
}
const CRC32_TABLE = makeCrc32Table();
function crc32(buf: any): number {
  let c = 0xffffffff;
  for (const b of buf) c = CRC32_TABLE[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function u32le(n:number): number[] { return [n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]; }
function u64le(n: bigint): number[] { const a:number[]=[]; for(let i=0n;i<8n;i++) a.push(Number((n>>(8n*i))&255n)); return a; }

const CRC64_POLY = 0xC96C5795D7870F42n;
function makeCrc64Table() {
  const t: bigint[] = [];
  for (let i=0;i<256;i++) {
    let r = BigInt(i);
    for (let j=0;j<8;j++) r = (r & 1n) ? ((r >> 1n) ^ CRC64_POLY) : (r >> 1n);
    t[i] = r & 0xffffffffffffffffn;
  }
  return t;
}
const CRC64_TABLE = makeCrc64Table();
function crc64(buf: any): bigint {
  let c = 0xffffffffffffffffn;
  for (const b of buf) c = CRC64_TABLE[Number((c ^ BigInt(b)) & 255n)] ^ (c >> 8n);
  return (c ^ 0xffffffffffffffffn) & 0xffffffffffffffffn;
}

function encVLI(n: number | bigint): number[] {
  let x = BigInt(n); const out:number[]=[];
  do { let b = Number(x & 0x7fn); x >>= 7n; if (x) b |= 0x80; out.push(b); } while (x);
  return out;
}
function decVLI(buf:any, posObj:{pos:number}): bigint {
  let shift=0n, val=0n;
  for (let i=0;i<9;i++) {
    if (posObj.pos >= buf.length) throw new Error('Unexpected end of input');
    const b = buf[posObj.pos++];
    val |= BigInt(b & 0x7f) << shift;
    if ((b & 0x80) === 0) return val;
    shift += 7n;
  }
  throw new Error('Invalid XZ file');
}
function pad4(arr:number[]) { while (arr.length % 4) arr.push(0); }
function concat(parts:any[]): any { return Buffer.concat(parts.map(p => Buffer.from(p))); }

function lzma2Stored(data:any): any {
  const out:number[]=[];
  for (let off=0; off<data.length; off += 65536) {
    const len = Math.min(65536, data.length - off);
    out.push(0x01, ((len-1)>>>8)&255, (len-1)&255);
    for (let i=0;i<len;i++) out.push(data[off+i]);
  }
  out.push(0x00);
  return Buffer.from(out);
}

function blockHeader(uncompSize:number, compSize:number): any {
  const body:number[] = [];
  body.push(0xc0); // compressed and uncompressed sizes present, one filter
  body.push(...encVLI(compSize));
  body.push(...encVLI(uncompSize));
  body.push(0x21, 0x01, 0x0c); // LZMA2, 8 MiB dictionary property
  const totalNoCrc = 1 + body.length;
  const headerSize = Math.ceil((totalNoCrc + 4) / 4) * 4;
  const sizeByte = headerSize / 4 - 1;
  const hdr = [sizeByte, ...body];
  while (hdr.length < headerSize - 4) hdr.push(0);
  hdr.push(...u32le(crc32(Buffer.from(hdr))));
  return Buffer.from(hdr);
}

function makeXZ(data:any): any {
  const flags = Buffer.from([0x00, 0x04]); // CRC64
  const header = Buffer.from([...XZ_MAGIC, ...flags, ...u32le(crc32(flags))]);
  const comp = lzma2Stored(data);
  const bh = blockHeader(data.length, comp.length);
  const check = Buffer.from(u64le(crc64(data)));
  const unpadded = bh.length + comp.length + check.length;
  const blockParts = [bh, comp];
  const padLen = (4 - (unpadded % 4)) % 4;
  if (padLen) blockParts.push(Buffer.alloc(padLen));
  blockParts.push(check);
  const indexArr:number[] = [0x00, ...encVLI(1), ...encVLI(unpadded), ...encVLI(data.length)];
  pad4(indexArr);
  indexArr.push(...u32le(crc32(Buffer.from(indexArr))));
  const index = Buffer.from(indexArr);
  const backSize = index.length / 4 - 1;
  const footerNoCrc = Buffer.from([...u32le(backSize), ...flags]);
  const footer = Buffer.from([...u32le(crc32(footerNoCrc)), ...footerNoCrc, ...FOOTER_MAGIC]);
  return concat([header, ...blockParts, index, footer]);
}

function readBlockHeader(buf:any, pos:number) {
  const sizeByte = buf[pos];
  if (sizeByte === 0) return null;
  const len = (sizeByte + 1) * 4;
  if (pos + len > buf.length) throw new Error('Unexpected end of input');
  const hdr = buf.subarray(pos, pos+len);
  const stored = hdr.readUInt32LE(len-4);
  if (crc32(hdr.subarray(0,len-4)) !== stored) throw new Error('Corrupt input data');
  const p = {pos:1};
  const flags = hdr[p.pos++];
  const filterCount = (flags & 3) + 1;
  let compSize: bigint | null = null, uncompSize: bigint | null = null;
  if (flags & 0x40) compSize = decVLI(hdr, p);
  if (flags & 0x80) uncompSize = decVLI(hdr, p);
  let filterId = 0n, props:any = Buffer.alloc(0);
  for (let i=0;i<filterCount;i++) {
    filterId = decVLI(hdr,p); const propsLen = Number(decVLI(hdr,p));
    props = hdr.subarray(p.pos, p.pos+propsLen); p.pos += propsLen;
  }
  if (filterId !== 0x21n) throw new Error('Unsupported options');
  return {len, compSize, uncompSize};
}

function decodeLzma2Stored(comp:any): any {
  const chunks:any[]=[]; let p=0;
  while (p < comp.length) {
    const ctrl = comp[p++];
    if (ctrl === 0x00) break;
    if (ctrl === 0x01 || ctrl === 0x02) {
      if (p+2 > comp.length) throw new Error('Unexpected end of input');
      const len = ((comp[p]<<8) | comp[p+1]) + 1; p += 2;
      if (p+len > comp.length) throw new Error('Unexpected end of input');
      chunks.push(comp.subarray(p,p+len)); p += len;
    } else {
      throw new Error('Compressed LZMA2 data is not supported by this reimplementation');
    }
  }
  return Buffer.concat(chunks);
}

function decodeXZ(buf:any, testOnly=false) {
  if (buf.length < 24 || !XZ_MAGIC.every((v,i)=>buf[i]===v)) throw new Error('File format not recognized');
  const flags = buf.subarray(6,8);
  const checkType = flags[1] & 0x0f;
  let pos = 12; const outs:any[]=[]; const records:{unpadded:number,uncompressed:number}[]=[];
  while (pos < buf.length - 12) {
    if (buf[pos] === 0x00) break;
    const bh = readBlockHeader(buf,pos); if (!bh) break; pos += bh.len;
    let compLen:number;
    if (bh.compSize !== null) compLen = Number(bh.compSize);
    else {
      const end = buf.indexOf(0x00, pos);
      if (end < 0) throw new Error('Unexpected end of input');
      compLen = end - pos + 1;
    }
    const comp = buf.subarray(pos,pos+compLen); pos += compLen;
    const data = decodeLzma2Stored(comp);
    const checkLen = checkType === 4 ? 8 : checkType === 1 ? 4 : checkType === 10 ? 32 : 0;
    const unpadded = bh.len + compLen + checkLen;
    while (pos % 4) pos++;
    const check = buf.subarray(pos,pos+checkLen); pos += checkLen;
    if (checkType === 4 && check.length === 8) {
      const got = check.readBigUInt64LE(0); const want = crc64(data);
      if (got !== want) throw new Error('Corrupt input data');
    } else if (checkType === 1 && check.length === 4) {
      if (check.readUInt32LE(0) !== crc32(data)) throw new Error('Corrupt input data');
    }
    outs.push(data); records.push({unpadded, uncompressed:data.length});
  }
  return {data: Buffer.concat(outs), records};
}

function shortHelp() {
  return `Usage: ${PROG} [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files
  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -h, --help          display this short help and exit
  -H, --long-help     display the long help (lists also the advanced options)
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>
`;}
function version(){return 'xz (XZ Utils) 5.8.2\nliblzma 5.8.2\n';}
function longHelp(){return shortHelp().replace('  -h, --help          display this short help and exit','      --robot         use machine-parsable messages (useful for scripts)\n\n      --info-memory   display the total amount of RAM and the currently active\n                      memory usage limits, and exit\n  -h, --help          display the short help (lists only the basic options)');}
function fmtBytes(n:number){ return n < 10000 ? `${n} B` : `${n} B`; }
function baseOutName(file:string, suffix:string){ return file.endsWith(suffix) ? file.slice(0,-suffix.length) : file.endsWith('.txz') ? file.slice(0,-4)+'.tar' : file + '.out'; }

function parseArgs(argv:string[]) {
  const o:any={mode:'compress', keep:false, stdout:false, force:false, quiet:0, suffix:'.xz', files:[]};
  for (let i=0;i<argv.length;i++) {
    const a=argv[i];
    if (a === '--') { o.files.push(...argv.slice(i+1)); break; }
    if (!a.startsWith('-') || a === '-') { o.files.push(a); continue; }
    if (a === '--help') { process.stdout.write(shortHelp()); process.exit(0); }
    if (a === '--long-help') { process.stdout.write(longHelp()); process.exit(0); }
    if (a === '--version') { process.stdout.write(version()); process.exit(0); }
    if (a === '--info-memory') { process.stdout.write('Hardware information:\n  Amount of physical memory (RAM):  32045 MiB (33601298432 B)\n  Number of processor threads:      12\n\nMemory usage limits:\n  Compression:                      Disabled\n  Decompression:                    Disabled\n  Multi-threaded decompression:     8012 MiB (8400324608 B)\n  Default for -T0:                  8012 MiB (8400324608 B)\n'); process.exit(0); }
    if (a === '--filters-help') { process.stdout.write('Filter chains are set using the --filters=FILTERS or --filters1=FILTERS ...\n--filters9=FILTERS options. Each filter in the chain can be separated by\nspaces or \'--\'. Alternatively a preset <0-9>[e] can be specified instead of\na filter chain.\n\nThe supported filters and their options are:\nlzma2:preset=<0-9[e]>,dict=<4KiB-1536MiB>,lc=<0-4>,lp=<0-4>,pb=<0-4>,mode=<fast|normal>,nice=<2-273>,mf=<hc3|hc4|bt2|bt3|bt4>,depth=<0-4294967295>\nx86:start=<0-4294967295>\narm:start=<0-4294967295>\narmthumb:start=<0-4294967295>\narm64:start=<0-4294967295>\nriscv:start=<0-4294967295>\npowerpc:start=<0-4294967295>\nia64:start=<0-4294967295>\nsparc:start=<0-4294967295>\ndelta:dist=<1-256>\n'); process.exit(0); }
    if (a.startsWith('--suffix=')) { o.suffix=a.slice(9); continue; }
    if (a === '--compress') { o.mode='compress'; continue; }
    if (a === '--decompress' || a === '--uncompress') { o.mode='decompress'; continue; }
    if (a === '--test') { o.mode='test'; continue; }
    if (a === '--list') { o.mode='list'; continue; }
    if (a === '--keep') { o.keep=true; continue; }
    if (a === '--force') { o.force=true; continue; }
    if (a === '--stdout' || a === '--to-stdout') { o.stdout=true; o.keep=true; continue; }
    if (a.startsWith('--threads') || a.startsWith('--format') || a.startsWith('--check') || a === '--extreme' || a === '--no-sync' || a === '--single-stream' || a === '--no-sparse' || a === '--quiet' || a === '--verbose' || a === '--robot' || a === '--no-warn' || a.startsWith('--memlimit') || a === '--ignore-check' || a === '--no-adjust') { continue; }
    if (a.startsWith('--')) { err(`unrecognized option '${a}'`); err(`Try '${PROG} --help' for more information.`); process.exit(1); }
    for (let j=1;j<a.length;j++) {
      const c=a[j];
      if (c==='z') o.mode='compress'; else if (c==='d') o.mode='decompress'; else if (c==='t') o.mode='test'; else if (c==='l') o.mode='list';
      else if (c==='k') o.keep=true; else if (c==='f') o.force=true; else if (c==='c') {o.stdout=true;o.keep=true;}
      else if (c==='q') o.quiet++; else if (c==='v' || c==='e' || /[0-9]/.test(c)) {}
      else if (c==='T' || c==='S' || c==='F' || c==='C' || c==='M') { if (j < a.length-1) break; else i++; break; }
      else if (c==='h') { process.stdout.write(shortHelp()); process.exit(0); }
      else if (c==='H') { process.stdout.write(longHelp()); process.exit(0); }
      else if (c==='V') { process.stdout.write(version()); process.exit(0); }
      else { err(`invalid option -- '${c}'`); process.exit(1); }
    }
  }
  return o;
}
function err(s:string){ process.stderr.write(`${PROG}: ${s}\n`); }
function processOne(o:any, file:string|null): boolean {
  try {
    const stdin = file === null || file === '-';
    const input = stdin ? fs.readFileSync(0) : fs.readFileSync(file);
    if (o.mode === 'compress') {
      const out = makeXZ(input);
      if (o.stdout || stdin) process.stdout.write(out);
      else { const of=file+o.suffix; if (!o.force && fs.existsSync(of)) throw new Error(`${of}: File exists`); fs.writeFileSync(of,out); if(!o.keep) fs.unlinkSync(file); }
    } else if (o.mode === 'decompress') {
      const res = decodeXZ(input);
      if (o.stdout || stdin) process.stdout.write(res.data);
      else { const of=baseOutName(file,o.suffix); if (!o.force && fs.existsSync(of)) throw new Error(`${of}: File exists`); fs.writeFileSync(of,res.data); if(!o.keep) fs.unlinkSync(file); }
    } else if (o.mode === 'test') {
      decodeXZ(input,true);
    } else if (o.mode === 'list') {
      const res = decodeXZ(input,true); const comp = stdin ? input.length : fs.statSync(file).size; const uncomp=res.data.length;
      process.stdout.write('Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename\n');
      process.stdout.write(`${String(1).padStart(5)} ${String(res.records.length).padStart(7)} ${fmtBytes(comp).padStart(12)} ${fmtBytes(uncomp).padStart(12)}    ---  CRC64   ${stdin ? '(stdin)' : file}\n`);
    }
    return true;
  } catch(e:any) {
    const prefix = file && file !== '-' ? `${file}: ` : '';
    let msg = e && e.code === 'ENOENT' ? 'No such file or directory' : (e && e.code === 'EEXIST' ? 'File exists' : (e && e.message ? e.message : String(e)));
    err(prefix + msg);
    return false;
  }
}
function main(){ const o=parseArgs(process.argv.slice(2)); const files=o.files.length?o.files:[null]; let ok=true; for (const f of files) if(!processOne(o,f)) ok=false; process.exit(ok?0:1); }
main();
