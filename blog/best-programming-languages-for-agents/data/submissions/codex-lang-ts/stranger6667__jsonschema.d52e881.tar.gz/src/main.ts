declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

type J = any;

interface Options {
  schema?: string;
  instances: string[];
  output: "text" | "flag" | "list" | "hierarchical";
  assertFormat: boolean;
  errorsOnly: boolean;
  draft?: string;
}

interface VError {
  path: string;
  schemaPath: string;
  keyword: string;
  message: string;
}

interface Context {
  root: J;
  baseDir: string;
  schemaFile: string;
  assertFormat: boolean;
  seen: Set<string>;
}

function usage(full: boolean): string {
  if (!full) return "Usage: executable <SCHEMA>\n";
  return `Usage: executable [OPTIONS] [SCHEMA]

Arguments:
  [SCHEMA]  The JSON Schema to validate with (i.e. schema.json)

Options:
  -i, --instance <INSTANCES>       A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)
  -d, --draft <DRAFT>              Enforce a specific JSON Schema draft [possible values: 4, 6, 7, 2019, 2020]
      --assert-format              Turn ON format validation
      --no-assert-format           Turn OFF format validation
      --output <OUTPUT>            Select output style: text (default), flag, list, hierarchical [default: text] [possible values: text, flag, list, hierarchical]
  -v, --version                    Show program's version number and exit
      --errors-only                Only show validation errors
      --connect-timeout <SECONDS>  Timeout for establishing connections (in seconds)
      --timeout <SECONDS>          Total timeout for HTTP requests (in seconds)
  -k, --insecure                   Skip TLS certificate verification (dangerous!)
      --cacert <FILE>              Path to a custom CA certificate file (PEM format)
  -h, --help                       Print help`;
}

function parseArgs(argv: string[]): Options | number {
  const o: Options = { instances: [], output: "text", assertFormat: false, errorsOnly: false };
  const need = (i: number, name: string) => {
    if (i + 1 >= argv.length) {
      console.error(`error: a value is required for '${name} <${name === "--output" ? "OUTPUT" : "VALUE"}>' but none was supplied`);
      return false;
    }
    return true;
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") {
      console.log(usage(true));
      return 0;
    } else if (a === "-v" || a === "--version") {
      console.log("Version: 0.41.0");
      return 0;
    } else if (a === "-i" || a === "--instance") {
      if (!need(i, a)) return 2;
      o.instances.push(argv[++i]);
    } else if (a.startsWith("--instance=")) {
      o.instances.push(a.slice(11));
    } else if (a === "--output") {
      if (!need(i, a)) return 2;
      const v = argv[++i];
      if (!["text", "flag", "list", "hierarchical"].includes(v)) {
        console.error(`error: invalid value '${v}' for '--output <OUTPUT>'\n  [possible values: text, flag, list, hierarchical]\n\nFor more information, try '--help'.`);
        return 2;
      }
      o.output = v as Options["output"];
    } else if (a.startsWith("--output=")) {
      const v = a.slice(9);
      if (!["text", "flag", "list", "hierarchical"].includes(v)) {
        console.error(`error: invalid value '${v}' for '--output <OUTPUT>'\n  [possible values: text, flag, list, hierarchical]\n\nFor more information, try '--help'.`);
        return 2;
      }
      o.output = v as Options["output"];
    } else if (a === "--assert-format") {
      o.assertFormat = true;
    } else if (a === "--no-assert-format") {
      o.assertFormat = false;
    } else if (a === "--errors-only") {
      o.errorsOnly = true;
    } else if (a === "-d" || a === "--draft") {
      if (!need(i, a)) return 2;
      const v = argv[++i];
      if (!["4", "6", "7", "2019", "2020"].includes(v)) {
        console.error(`error: invalid value '${v}' for '--draft <DRAFT>'\n  [possible values: 4, 6, 7, 2019, 2020]\n\nFor more information, try '--help'.`);
        return 2;
      }
      o.draft = v;
    } else if (["--connect-timeout", "--timeout", "--cacert"].includes(a)) {
      if (!need(i, a)) return 2;
      i++;
    } else if (a === "-k" || a === "--insecure") {
    } else if (a.startsWith("-")) {
      console.error(`error: unexpected argument '${a}' found\n\nFor more information, try '--help'.`);
      return 2;
    } else if (!o.schema) {
      o.schema = a;
    } else {
      console.error(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [SCHEMA]\n\nFor more information, try '--help'.`);
      return 2;
    }
  }
  if (!o.schema) {
    console.error("error: the following required arguments were not provided:\n  <SCHEMA>\n\nUsage: executable <SCHEMA>\n\nFor more information, try '--help'.");
    return 2;
  }
  return o;
}

function readJson(file: string): J {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function ptr(pathParts: (string | number)[]): string {
  if (pathParts.length === 0) return "";
  return "/" + pathParts.map(p => String(p).replace(/~/g, "~0").replace(/\//g, "~1")).join("/");
}

function unptr(s: string): string[] {
  if (!s || s === "#") return [];
  const t = s.startsWith("#") ? s.slice(1) : s;
  if (!t) return [];
  return t.split("/").slice(1).map(x => decodeURIComponent(x).replace(/~1/g, "/").replace(/~0/g, "~"));
}

function atPointer(root: J, ref: string): J {
  let cur = root;
  for (const p of unptr(ref)) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

function typeName(v: J): string {
  if (v === null) return "null";
  if (Array.isArray(v)) return "array";
  if (typeof v === "number" && Number.isInteger(v)) return "integer";
  return typeof v;
}

function matchesType(v: J, t: string): boolean {
  if (t === "integer") return typeof v === "number" && Number.isInteger(v);
  if (t === "number") return typeof v === "number" && Number.isFinite(v);
  if (t === "array") return Array.isArray(v);
  if (t === "object") return v !== null && typeof v === "object" && !Array.isArray(v);
  if (t === "null") return v === null;
  return typeof v === t;
}

function repr(v: J): string {
  return JSON.stringify(v);
}

function eq(a: J, b: J): boolean {
  return JSON.stringify(a) === JSON.stringify(b);
}

function add(errors: VError[], inst: (string | number)[], sch: (string | number)[], keyword: string, message: string) {
  errors.push({ path: ptr(inst), schemaPath: ptr(sch), keyword, message });
}

function resolveRef(ref: string, ctx: Context): J {
  if (ref.startsWith("#")) return atPointer(ctx.root, ref);
  const [file, frag = ""] = ref.split("#", 2);
  const p = path.resolve(ctx.baseDir, file);
  const doc = readJson(p);
  return frag ? atPointer(doc, "#" + frag) : doc;
}

function validate(schema: J, inst: J, ctx: Context, ip: (string | number)[] = [], sp: (string | number)[] = []): VError[] {
  const errors: VError[] = [];
  if (schema === true || schema === undefined) return errors;
  if (schema === false) {
    add(errors, ip, sp, "false schema", `${repr(inst)} is not allowed`);
    return errors;
  }
  if (schema === null || typeof schema !== "object") return errors;

  if (typeof schema.$ref === "string") {
    const key = schema.$ref + "|" + ptr(ip);
    if (!ctx.seen.has(key)) {
      ctx.seen.add(key);
      errors.push(...validate(resolveRef(schema.$ref, ctx), inst, ctx, ip, sp.concat("$ref")));
      ctx.seen.delete(key);
    }
    return errors;
  }

  if (schema.const !== undefined && !eq(inst, schema.const)) add(errors, ip, sp.concat("const"), "const", `${repr(schema.const)} was expected`);
  if (Array.isArray(schema.enum) && !schema.enum.some((x: J) => eq(x, inst))) {
    add(errors, ip, sp.concat("enum"), "enum", `${repr(inst)} is not one of ${schema.enum.map(repr).join(" or ")}`);
  }

  if (schema.type !== undefined) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type];
    if (!types.some((t: string) => matchesType(inst, t))) add(errors, ip, sp.concat("type"), "type", `${repr(inst)} is not of type ${types.map((t: string) => `"${t}"`).join(" or ")}`);
  }

  if (typeof inst === "number") {
    if (typeof schema.multipleOf === "number" && Math.abs(inst / schema.multipleOf - Math.round(inst / schema.multipleOf)) > 1e-12) add(errors, ip, sp.concat("multipleOf"), "multipleOf", `${repr(inst)} is not a multiple of ${schema.multipleOf}`);
    if (typeof schema.minimum === "number" && inst < schema.minimum) add(errors, ip, sp.concat("minimum"), "minimum", `${repr(inst)} is less than the minimum of ${schema.minimum}`);
    if (typeof schema.maximum === "number" && inst > schema.maximum) add(errors, ip, sp.concat("maximum"), "maximum", `${repr(inst)} is greater than the maximum of ${schema.maximum}`);
    if (typeof schema.exclusiveMinimum === "number" && inst <= schema.exclusiveMinimum) add(errors, ip, sp.concat("exclusiveMinimum"), "exclusiveMinimum", `${repr(inst)} is less than or equal to the minimum of ${schema.exclusiveMinimum}`);
    if (typeof schema.exclusiveMaximum === "number" && inst >= schema.exclusiveMaximum) add(errors, ip, sp.concat("exclusiveMaximum"), "exclusiveMaximum", `${repr(inst)} is greater than or equal to the maximum of ${schema.exclusiveMaximum}`);
    if (schema.exclusiveMinimum === true && typeof schema.minimum === "number" && inst <= schema.minimum) add(errors, ip, sp.concat("exclusiveMinimum"), "exclusiveMinimum", `${repr(inst)} is less than or equal to the minimum of ${schema.minimum}`);
    if (schema.exclusiveMaximum === true && typeof schema.maximum === "number" && inst >= schema.maximum) add(errors, ip, sp.concat("exclusiveMaximum"), "exclusiveMaximum", `${repr(inst)} is greater than or equal to the maximum of ${schema.maximum}`);
  }

  if (typeof inst === "string") {
    if (typeof schema.minLength === "number" && Array.from(inst).length < schema.minLength) add(errors, ip, sp.concat("minLength"), "minLength", `${repr(inst)} is too short`);
    if (typeof schema.maxLength === "number" && Array.from(inst).length > schema.maxLength) add(errors, ip, sp.concat("maxLength"), "maxLength", `${repr(inst)} is too long`);
    if (typeof schema.pattern === "string" && !(new RegExp(schema.pattern, "u")).test(inst)) add(errors, ip, sp.concat("pattern"), "pattern", `${repr(inst)} does not match ${repr(schema.pattern)}`);
    if (ctx.assertFormat && typeof schema.format === "string" && !formatOk(inst, schema.format)) add(errors, ip, sp.concat("format"), "format", `${repr(inst)} is not a "${schema.format}"`);
  }

  if (Array.isArray(inst)) {
    if (typeof schema.minItems === "number" && inst.length < schema.minItems) add(errors, ip, sp.concat("minItems"), "minItems", `${repr(inst)} has fewer than ${schema.minItems} items`);
    if (typeof schema.maxItems === "number" && inst.length > schema.maxItems) add(errors, ip, sp.concat("maxItems"), "maxItems", `${repr(inst)} has more than ${schema.maxItems} items`);
    if (schema.uniqueItems === true) {
      const seen = new Set(inst.map(repr));
      if (seen.size !== inst.length) add(errors, ip, sp.concat("uniqueItems"), "uniqueItems", `${repr(inst)} has non-unique elements`);
    }
    if (Array.isArray(schema.prefixItems)) {
      schema.prefixItems.forEach((s: J, i: number) => { if (i < inst.length) errors.push(...validate(s, inst[i], ctx, ip.concat(i), sp.concat("prefixItems", i))); });
    }
    if (schema.items !== undefined) {
      if (Array.isArray(schema.items)) {
        schema.items.forEach((s: J, i: number) => { if (i < inst.length) errors.push(...validate(s, inst[i], ctx, ip.concat(i), sp.concat("items", i))); });
      } else {
        inst.forEach((v: J, i: number) => errors.push(...validate(schema.items, v, ctx, ip.concat(i), sp.concat("items"))));
      }
    }
    if (typeof schema.minContains === "number" || typeof schema.maxContains === "number" || schema.contains !== undefined) {
      const count = inst.filter((v: J, i: number) => validate(schema.contains ?? true, v, ctx, ip.concat(i), sp.concat("contains")).length === 0).length;
      const min = schema.minContains ?? (schema.contains !== undefined ? 1 : 0);
      if (count < min) add(errors, ip, sp.concat("contains"), "contains", `${repr(inst)} does not contain items matching the given schema`);
      if (typeof schema.maxContains === "number" && count > schema.maxContains) add(errors, ip, sp.concat("maxContains"), "maxContains", `${repr(inst)} contains too many matching items`);
    }
  }

  if (inst !== null && typeof inst === "object" && !Array.isArray(inst)) {
    const keys = Object.keys(inst);
    if (typeof schema.minProperties === "number" && keys.length < schema.minProperties) add(errors, ip, sp.concat("minProperties"), "minProperties", `${repr(inst)} does not have enough properties`);
    if (typeof schema.maxProperties === "number" && keys.length > schema.maxProperties) add(errors, ip, sp.concat("maxProperties"), "maxProperties", `${repr(inst)} has too many properties`);
    if (Array.isArray(schema.required)) {
      for (const r of schema.required) if (!(r in inst)) add(errors, ip, sp.concat("required"), "required", `"${r}" is a required property`);
    }
    const props = schema.properties && typeof schema.properties === "object" ? schema.properties : {};
    for (const k of Object.keys(props)) if (k in inst) errors.push(...validate(props[k], inst[k], ctx, ip.concat(k), sp.concat("properties", k)));
    if (schema.patternProperties && typeof schema.patternProperties === "object") {
      for (const pat of Object.keys(schema.patternProperties)) {
        const re = new RegExp(pat, "u");
        for (const k of keys) if (re.test(k)) errors.push(...validate(schema.patternProperties[pat], inst[k], ctx, ip.concat(k), sp.concat("patternProperties", pat)));
      }
    }
    if (schema.propertyNames) for (const k of keys) errors.push(...validate(schema.propertyNames, k, ctx, ip.concat(k), sp.concat("propertyNames")));
    if (schema.dependencies && typeof schema.dependencies === "object") {
      for (const k of Object.keys(schema.dependencies)) if (k in inst) {
        const d = schema.dependencies[k];
        if (Array.isArray(d)) for (const req of d) if (!(req in inst)) add(errors, ip, sp.concat("dependencies", k), "dependencies", `"${req}" is a dependency of "${k}"`);
        else errors.push(...validate(d, inst, ctx, ip, sp.concat("dependencies", k)));
      }
    }
    if (schema.dependentRequired && typeof schema.dependentRequired === "object") {
      for (const k of Object.keys(schema.dependentRequired)) if (k in inst) for (const req of schema.dependentRequired[k]) if (!(req in inst)) add(errors, ip, sp.concat("dependentRequired", k), "dependentRequired", `"${req}" is a dependency of "${k}"`);
    }
    if (schema.dependentSchemas && typeof schema.dependentSchemas === "object") {
      for (const k of Object.keys(schema.dependentSchemas)) if (k in inst) errors.push(...validate(schema.dependentSchemas[k], inst, ctx, ip, sp.concat("dependentSchemas", k)));
    }
    if (schema.additionalProperties === false || typeof schema.additionalProperties === "object") {
      const matched = new Set(Object.keys(props));
      if (schema.patternProperties) for (const pat of Object.keys(schema.patternProperties)) {
        const re = new RegExp(pat, "u");
        for (const k of keys) if (re.test(k)) matched.add(k);
      }
      const extras = keys.filter(k => !matched.has(k));
      if (schema.additionalProperties === false && extras.length) add(errors, ip, sp.concat("additionalProperties"), "additionalProperties", `Additional properties are not allowed (${extras.map(k => `'${k}' was unexpected`).join(", ")})`);
      else if (typeof schema.additionalProperties === "object") for (const k of extras) errors.push(...validate(schema.additionalProperties, inst[k], ctx, ip.concat(k), sp.concat("additionalProperties")));
    }
  }

  if (Array.isArray(schema.allOf)) schema.allOf.forEach((s: J, i: number) => errors.push(...validate(s, inst, ctx, ip, sp.concat("allOf", i))));
  if (Array.isArray(schema.anyOf) && !schema.anyOf.some((s: J, i: number) => validate(s, inst, ctx, ip, sp.concat("anyOf", i)).length === 0)) add(errors, ip, sp.concat("anyOf"), "anyOf", `${repr(inst)} is not valid under any of the schemas listed in the 'anyOf' keyword`);
  if (Array.isArray(schema.oneOf)) {
    const ok = schema.oneOf.filter((s: J, i: number) => validate(s, inst, ctx, ip, sp.concat("oneOf", i)).length === 0).length;
    if (ok === 0) add(errors, ip, sp.concat("oneOf"), "oneOf", `${repr(inst)} is not valid under any of the schemas listed in the 'oneOf' keyword`);
    else if (ok > 1) add(errors, ip, sp.concat("oneOf"), "oneOf", `${repr(inst)} is valid under more than one of the schemas listed in the 'oneOf' keyword`);
  }
  if (schema.not !== undefined && validate(schema.not, inst, ctx, ip, sp.concat("not")).length === 0) add(errors, ip, sp.concat("not"), "not", `${repr(inst)} is not allowed for ${repr(schema.not)}`);
  if (schema.if !== undefined) {
    const cond = validate(schema.if, inst, ctx, ip, sp.concat("if")).length === 0;
    if (cond && schema.then !== undefined) errors.push(...validate(schema.then, inst, ctx, ip, sp.concat("then")));
    if (!cond && schema.else !== undefined) errors.push(...validate(schema.else, inst, ctx, ip, sp.concat("else")));
  }

  return errors;
}

function formatOk(s: string, f: string): boolean {
  if (f === "email") return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(s);
  if (f === "ipv4") return /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/.test(s);
  if (f === "ipv6") return /^[0-9a-f:]+$/i.test(s) && s.includes(":");
  if (f === "uri" || f === "url" || f === "iri") { try { new URL(s); return true; } catch { return false; } }
  if (f === "uuid") return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(s);
  if (f === "date-time") return !Number.isNaN(Date.parse(s));
  if (f === "date") return /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s + "T00:00:00Z"));
  if (f === "time") return /^\d{2}:\d{2}:\d{2}/.test(s);
  if (f === "hostname") return /^[A-Za-z0-9.-]+$/.test(s) && s.length <= 253;
  return true;
}

function fileUri(p: string): string {
  return "file://" + path.resolve(p);
}

function jsonLine(schemaPath: string, instPath: string, output: string, errors: VError[]) {
  const valid = errors.length === 0;
  if (output === "flag") {
    console.log(JSON.stringify({ instance: instPath, output, payload: { valid }, schema: schemaPath }));
    return;
  }
  const root: any = { evaluationPath: "", instanceLocation: "", schemaLocation: fileUri(schemaPath) + "#", valid };
  if (!valid) root.errors = Object.fromEntries(errors.map(e => [e.keyword, e.message]));
  const details = [root, ...errors.map(e => ({ errors: { [e.keyword]: e.message }, evaluationPath: e.schemaPath, instanceLocation: e.path, schemaLocation: fileUri(schemaPath) + "#" + e.schemaPath, valid: false }))];
  if (output === "list") console.log(JSON.stringify({ instance: instPath, output, payload: { details, valid }, schema: schemaPath }));
  else console.log(JSON.stringify({ instance: instPath, output, payload: { ...root, details: details.slice(1) }, schema: schemaPath }));
}

function main() {
  const parsed = parseArgs(process.argv.slice(2));
  if (typeof parsed === "number") process.exit(parsed);
  const opts = parsed as Options;
  try {
    const schema = readJson(opts.schema!);
    const instances = opts.instances.length ? opts.instances : ["-"];
    let anyInvalid = false;
    for (const instPath of instances) {
      const inst = instPath === "-" ? JSON.parse(fs.readFileSync(0, "utf8")) : readJson(instPath);
      const ctx: Context = { root: schema, baseDir: path.dirname(path.resolve(opts.schema!)), schemaFile: opts.schema!, assertFormat: opts.assertFormat, seen: new Set() };
      const errors = validate(schema, inst, ctx);
      if (errors.length) anyInvalid = true;
      if (opts.output === "text") {
        if (errors.length) {
          console.log(`${instPath} - INVALID. Errors:`);
          errors.forEach((e, i) => console.log(`${i + 1}. ${e.message}`));
        } else if (!opts.errorsOnly) {
          console.log(`${instPath} - VALID`);
        }
      } else {
        if (!opts.errorsOnly || errors.length) jsonLine(opts.schema!, instPath, opts.output, errors);
      }
    }
    process.exit(anyInvalid ? 1 : 0);
  } catch (e: any) {
    console.error(`Error: ${e.message}`);
    process.exit(1);
  }
}

main();
