declare const require: any;
declare const process: any;
declare const Buffer: any;
type Buffer = any;
