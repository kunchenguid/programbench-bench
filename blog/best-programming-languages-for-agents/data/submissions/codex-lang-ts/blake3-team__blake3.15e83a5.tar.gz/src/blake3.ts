const IV = new Uint32Array([
  0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
  0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
]);

const MSG_PERMUTATION = [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8];

const CHUNK_LEN = 1024;
const BLOCK_LEN = 64;
const OUT_LEN = 32;

const CHUNK_START = 1;
const CHUNK_END = 2;
const PARENT = 4;
const ROOT = 8;
const KEYED_HASH = 16;
const DERIVE_KEY_CONTEXT = 32;
const DERIVE_KEY_MATERIAL = 64;

function add(a: number, b: number): number {
  return (a + b) >>> 0;
}

function rotr(x: number, n: number): number {
  return ((x >>> n) | (x << (32 - n))) >>> 0;
}

function g(s: Uint32Array, a: number, b: number, c: number, d: number, mx: number, my: number): void {
  s[a] = add(add(s[a], s[b]), mx);
  s[d] = rotr(s[d] ^ s[a], 16);
  s[c] = add(s[c], s[d]);
  s[b] = rotr(s[b] ^ s[c], 12);
  s[a] = add(add(s[a], s[b]), my);
  s[d] = rotr(s[d] ^ s[a], 8);
  s[c] = add(s[c], s[d]);
  s[b] = rotr(s[b] ^ s[c], 7);
}

function round(s: Uint32Array, m: Uint32Array): void {
  g(s, 0, 4, 8, 12, m[0], m[1]);
  g(s, 1, 5, 9, 13, m[2], m[3]);
  g(s, 2, 6, 10, 14, m[4], m[5]);
  g(s, 3, 7, 11, 15, m[6], m[7]);
  g(s, 0, 5, 10, 15, m[8], m[9]);
  g(s, 1, 6, 11, 12, m[10], m[11]);
  g(s, 2, 7, 8, 13, m[12], m[13]);
  g(s, 3, 4, 9, 14, m[14], m[15]);
}

function permute(m: Uint32Array): Uint32Array {
  const out = new Uint32Array(16);
  for (let i = 0; i < 16; i++) out[i] = m[MSG_PERMUTATION[i]];
  return out;
}

function wordsFromBlock(block: Uint8Array): Uint32Array {
  const words = new Uint32Array(16);
  for (let i = 0; i < 16; i++) {
    const j = i * 4;
    words[i] = ((block[j] ?? 0) |
      ((block[j + 1] ?? 0) << 8) |
      ((block[j + 2] ?? 0) << 16) |
      ((block[j + 3] ?? 0) << 24)) >>> 0;
  }
  return words;
}

function storeWords(words: Uint32Array): Uint8Array {
  const out = new Uint8Array(words.length * 4);
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    out[i * 4] = w & 0xff;
    out[i * 4 + 1] = (w >>> 8) & 0xff;
    out[i * 4 + 2] = (w >>> 16) & 0xff;
    out[i * 4 + 3] = (w >>> 24) & 0xff;
  }
  return out;
}

function low32(x: bigint): number {
  return Number(x & 0xffffffffn) >>> 0;
}

function high32(x: bigint): number {
  return Number((x >> 32n) & 0xffffffffn) >>> 0;
}

function compress(
  cv: Uint32Array,
  blockWords: Uint32Array,
  counter: bigint,
  blockLen: number,
  flags: number,
): Uint32Array {
  let m = new Uint32Array(blockWords);
  const s = new Uint32Array(16);
  s.set(cv, 0);
  s.set(IV, 8);
  s[12] = low32(counter);
  s[13] = high32(counter);
  s[14] = blockLen >>> 0;
  s[15] = flags >>> 0;
  for (let i = 0; i < 7; i++) {
    round(s, m);
    if (i !== 6) m = permute(m);
  }
  const out = new Uint32Array(16);
  for (let i = 0; i < 8; i++) {
    out[i] = (s[i] ^ s[i + 8]) >>> 0;
    out[i + 8] = (s[i + 8] ^ cv[i]) >>> 0;
  }
  return out;
}

function parentCv(left: Uint32Array, right: Uint32Array, key: Uint32Array, flags: number): Uint32Array {
  const block = new Uint32Array(16);
  block.set(left, 0);
  block.set(right, 8);
  return compress(key, block, 0n, BLOCK_LEN, flags | PARENT).slice(0, 8);
}

function chunkCv(input: Uint8Array, chunkCounter: bigint, key: Uint32Array, flags: number): Uint32Array {
  let cv = new Uint32Array(key);
  const blockCount = Math.max(1, Math.ceil(input.length / BLOCK_LEN));
  for (let i = 0; i < blockCount; i++) {
    const start = i * BLOCK_LEN;
    const block = input.subarray(start, Math.min(start + BLOCK_LEN, input.length));
    let blockFlags = flags;
    if (i === 0) blockFlags |= CHUNK_START;
    if (i === blockCount - 1) blockFlags |= CHUNK_END;
    const out = compress(cv, wordsFromBlock(block), chunkCounter, block.length, blockFlags);
    cv = out.slice(0, 8);
  }
  return cv;
}

function rootOutput(input: Uint8Array, key: Uint32Array, flags: number): { cv: Uint32Array; blockWords: Uint32Array; blockLen: number; flags: number } {
  if (input.length <= CHUNK_LEN) {
    let cv = new Uint32Array(key);
    const blockCount = Math.max(1, Math.ceil(input.length / BLOCK_LEN));
    let lastBlock = new Uint8Array(0);
    for (let i = 0; i < blockCount; i++) {
      const start = i * BLOCK_LEN;
      const block = input.subarray(start, Math.min(start + BLOCK_LEN, input.length));
      lastBlock = block;
      let blockFlags = flags;
      if (i === 0) blockFlags |= CHUNK_START;
      if (i === blockCount - 1) {
        return { cv, blockWords: wordsFromBlock(block), blockLen: block.length, flags: blockFlags | CHUNK_END };
      }
      cv = compress(cv, wordsFromBlock(block), 0n, block.length, blockFlags).slice(0, 8);
    }
    return { cv, blockWords: wordsFromBlock(lastBlock), blockLen: lastBlock.length, flags: flags | CHUNK_START | CHUNK_END };
  }

  const cvs: Uint32Array[] = [];
  const chunkCount = Math.ceil(input.length / CHUNK_LEN);
  for (let i = 0; i < chunkCount; i++) {
    const start = i * CHUNK_LEN;
    cvs.push(chunkCv(input.subarray(start, Math.min(start + CHUNK_LEN, input.length)), BigInt(i), key, flags));
  }
  while (cvs.length > 2) {
    const next: Uint32Array[] = [];
    for (let i = 0; i < cvs.length; i += 2) {
      if (i + 1 < cvs.length) next.push(parentCv(cvs[i], cvs[i + 1], key, flags));
      else next.push(cvs[i]);
    }
    cvs.splice(0, cvs.length, ...next);
  }
  const block = new Uint32Array(16);
  block.set(cvs[0], 0);
  block.set(cvs[1], 8);
  return { cv: key, blockWords: block, blockLen: BLOCK_LEN, flags: flags | PARENT };
}

function outputBytes(root: { cv: Uint32Array; blockWords: Uint32Array; blockLen: number; flags: number }, seek: bigint, length: number): Uint8Array {
  const out = new Uint8Array(length);
  let written = 0;
  let blockCounter = seek / 64n;
  let skip = Number(seek % 64n);
  while (written < length) {
    const words = compress(root.cv, root.blockWords, blockCounter, root.blockLen, root.flags | ROOT);
    const block = storeWords(words);
    const take = Math.min(length - written, 64 - skip);
    out.set(block.subarray(skip, skip + take), written);
    written += take;
    blockCounter++;
    skip = 0;
  }
  return out;
}

function keyWords(keyBytes: Uint8Array): Uint32Array {
  if (keyBytes.length !== 32) throw new Error("key must be 32 bytes");
  return wordsFromBlock(keyBytes).slice(0, 8);
}

export type Mode =
  | { kind: "hash" }
  | { kind: "keyed"; key: Uint8Array }
  | { kind: "derive"; context: string };

export function blake3(input: Uint8Array, length = OUT_LEN, seek: bigint = 0n, mode: Mode = { kind: "hash" }): Uint8Array {
  let key = IV;
  let flags = 0;
  if (mode.kind === "keyed") {
    key = keyWords(mode.key);
    flags = KEYED_HASH;
  } else if (mode.kind === "derive") {
    const contextRoot = rootOutput(Buffer.from(mode.context, "utf8"), IV, DERIVE_KEY_CONTEXT);
    key = keyWords(outputBytes(contextRoot, 0n, 32));
    flags = DERIVE_KEY_MATERIAL;
  }
  return outputBytes(rootOutput(input, key, flags), seek, length);
}

export function toHex(bytes: Uint8Array): string {
  let s = "";
  for (const b of bytes) s += b.toString(16).padStart(2, "0");
  return s;
}
