import { blake3, Mode, toHex } from "./blake3";

const fs = require("fs");

interface Opts {
  files: string[];
  mode: Mode;
  length: number;
  seek: bigint;
  noNames: boolean;
  raw: boolean;
  tag: boolean;
  check: boolean;
  quiet: boolean;
}

const HELP_LONG = `Usage: executable [OPTIONS] [FILE]...

Arguments:
  [FILE]...
          Files to hash, or checkfiles to check
          
          When no file is given, or when - is given, read standard input.

Options:
      --keyed
          Use the keyed mode, reading the 32-byte key from stdin

      --derive-key <CONTEXT>
          Use the key derivation mode, with the given context string
          
          Cannot be used with --keyed.

  -l, --length <LEN>
          The number of output bytes, before hex encoding
          
          [default: 32]

      --seek <SEEK>
          The starting output byte offset, before hex encoding
          
          [default: 0]

      --num-threads <NUM>
          The maximum number of threads to use
          
          By default, this is the number of logical cores. If this flag is omitted, or if its value
          is 0, RAYON_NUM_THREADS is also respected.

      --no-mmap
          Disable memory mapping
          
          Currently this also disables multithreading.

      --no-names
          Omit filenames in the output

      --raw
          Write raw output bytes to stdout, rather than hex
          
          --no-names is implied. In this case, only a single input is allowed.

      --tag
          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]

  -c, --check
          Read BLAKE3 sums from the [FILE]s and check them

      --quiet
          Skip printing OK for each checked file
          
          Must be used with --check.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const HELP_SHORT = `Usage: executable [OPTIONS] [FILE]...

Arguments:
  [FILE]...  Files to hash, or checkfiles to check

Options:
      --keyed                 Use the keyed mode, reading the 32-byte key from stdin
      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string
  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]
      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]
      --num-threads <NUM>     The maximum number of threads to use
      --no-mmap               Disable memory mapping
      --no-names              Omit filenames in the output
      --raw                   Write raw output bytes to stdout, rather than hex
      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]
  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them
      --quiet                 Skip printing OK for each checked file
  -h, --help                  Print help (see more with '--help')
  -V, --version               Print version`;

function die(msg: string, code = 1): never {
  process.stderr.write(msg + "\n");
  process.exit(code);
  for (;;) {
    // Unreachable after process.exit, but this keeps strict TypeScript happy.
  }
}

function needValue(args: string[], i: number, flag: string): string {
  if (i + 1 >= args.length) die(`error: a value is required for '${flag}' but none was supplied`);
  return args[i + 1];
}

function parseNum(s: string, name: string): number {
  if (!/^\d+$/.test(s)) die(`error: invalid value '${s}' for '${name}'`);
  const n = Number(s);
  if (!Number.isSafeInteger(n)) die(`error: invalid value '${s}' for '${name}'`);
  return n;
}

function parseArgs(argv: string[]): Opts {
  const opts: Opts = {
    files: [],
    mode: { kind: "hash" },
    length: 32,
    seek: 0n,
    noNames: false,
    raw: false,
    tag: false,
    check: false,
    quiet: false,
  };
  let keyed = false;
  let derive = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") {
      opts.files.push(...argv.slice(i + 1));
      break;
    } else if (a === "--help") {
      console.log(HELP_LONG);
      process.exit(0);
    } else if (a === "-h") {
      console.log(HELP_SHORT);
      process.exit(0);
    } else if (a === "--version" || a === "-V") {
      console.log("b3sum 1.8.4");
      process.exit(0);
    } else if (a === "--keyed") {
      keyed = true;
    } else if (a === "--derive-key") {
      derive = true;
      opts.mode = { kind: "derive", context: needValue(argv, i, a) };
      i++;
    } else if (a.startsWith("--derive-key=")) {
      derive = true;
      opts.mode = { kind: "derive", context: a.slice(13) };
    } else if (a === "-l" || a === "--length") {
      opts.length = parseNum(needValue(argv, i, a), a);
      i++;
    } else if (a.startsWith("--length=")) {
      opts.length = parseNum(a.slice(9), "--length");
    } else if (a === "--seek") {
      const v = needValue(argv, i, a);
      if (!/^\d+$/.test(v)) die(`error: invalid value '${v}' for '--seek'`);
      opts.seek = BigInt(v);
      i++;
    } else if (a.startsWith("--seek=")) {
      const v = a.slice(7);
      if (!/^\d+$/.test(v)) die(`error: invalid value '${v}' for '--seek'`);
      opts.seek = BigInt(v);
    } else if (a === "--num-threads") {
      parseNum(needValue(argv, i, a), a);
      i++;
    } else if (a.startsWith("--num-threads=")) {
      parseNum(a.slice(14), "--num-threads");
    } else if (a === "--no-mmap") {
      // Performance-only flag.
    } else if (a === "--no-names") {
      opts.noNames = true;
    } else if (a === "--raw") {
      opts.raw = true;
      opts.noNames = true;
    } else if (a === "--tag") {
      opts.tag = true;
    } else if (a === "-c" || a === "--check") {
      opts.check = true;
    } else if (a === "--quiet") {
      opts.quiet = true;
    } else if (a.startsWith("-") && a !== "-") {
      die(`error: unexpected argument '${a}' found`);
    } else {
      opts.files.push(a);
    }
  }
  if (keyed && derive) die("error: the argument '--keyed' cannot be used with '--derive-key <CONTEXT>'");
  if (keyed) opts.mode = { kind: "keyed", key: new Uint8Array(32) };
  if (opts.raw && opts.files.length > 1) die("b3sum: --raw requires exactly one input");
  if (opts.quiet && !opts.check) die("error: the argument '--quiet' requires '--check'");
  return opts;
}

function readStdin(): Buffer {
  try {
    return fs.readFileSync(0);
  } catch {
    return Buffer.alloc(0);
  }
}

function readInput(name: string, stdinData: Buffer | null): Buffer {
  if (name === "-") return stdinData ?? readStdin();
  return fs.readFileSync(name);
}

function escapedName(name: string): { text: string; escaped: boolean } {
  let escaped = false;
  let text = "";
  for (const ch of name) {
    if (ch === "\\") {
      text += "\\\\";
      escaped = true;
    } else if (ch === "\n") {
      text += "\\n";
      escaped = true;
    } else if (ch === "\r") {
      text += "\\r";
      escaped = true;
    } else {
      text += ch;
    }
  }
  return { text, escaped };
}

function unescapeName(name: string): string {
  let out = "";
  for (let i = 0; i < name.length; i++) {
    const ch = name[i];
    if (ch === "\\" && i + 1 < name.length) {
      const n = name[++i];
      if (n === "n") out += "\n";
      else if (n === "r") out += "\r";
      else out += n;
    } else {
      out += ch;
    }
  }
  return out;
}

function hashOne(data: Buffer, opts: Opts): string {
  return toHex(blake3(data, opts.length, opts.seek, opts.mode));
}

function runHash(opts: Opts): void {
  let stdinData: Buffer | null = null;
  if (opts.mode.kind === "keyed") {
    const all = readStdin();
    if (all.length < 32) die("b3sum: expected 32 key bytes from stdin");
    opts.mode.key = all.subarray(0, 32);
    stdinData = all.subarray(32);
  }

  const files = opts.files.length === 0 ? ["-"] : opts.files;
  if (opts.raw && files.length !== 1) die("b3sum: --raw requires exactly one input");

  for (const file of files) {
    let data: Buffer;
    try {
      data = readInput(file, stdinData);
      if (file === "-") stdinData = Buffer.alloc(0);
    } catch (e: any) {
      process.stderr.write(`b3sum: ${file}: ${e.message}\n`);
      process.exitCode = 1;
      continue;
    }
    const bytes = blake3(data, opts.length, opts.seek, opts.mode);
    if (opts.raw) {
      process.stdout.write(Buffer.from(bytes));
    } else if (opts.noNames) {
      process.stdout.write(toHex(bytes) + "\n");
    } else if (opts.tag) {
      const name = escapedName(file);
      process.stdout.write(`${name.escaped ? "\\" : ""}BLAKE3 (${name.text}) = ${toHex(bytes)}\n`);
    } else {
      const name = escapedName(file);
      process.stdout.write(`${name.escaped ? "\\" : ""}${toHex(bytes)}  ${name.text}\n`);
    }
  }
}

interface CheckLine {
  filename: string;
  expected: string;
}

function parseCheckLine(line: string): CheckLine | null {
  if (line.length === 0) return null;
  const escaped = line.startsWith("\\");
  const body = escaped ? line.slice(1) : line;
  const bsd = /^BLAKE3 \((.*)\) = ([0-9a-fA-F]+)$/.exec(body);
  if (bsd) return { filename: escaped ? unescapeName(bsd[1]) : bsd[1], expected: bsd[2].toLowerCase() };
  const gnu = /^([0-9a-fA-F]+) [ *](.*)$/.exec(body);
  if (gnu) return { filename: escaped ? unescapeName(gnu[2]) : gnu[2], expected: gnu[1].toLowerCase() };
  return null;
}

function runCheck(opts: Opts): void {
  const checkFiles = opts.files.length === 0 ? ["-"] : opts.files;
  let total = 0;
  let failed = 0;
  let malformed = 0;
  let stdinData: Buffer | null = null;
  for (const cf of checkFiles) {
    let text: string;
    try {
      text = readInput(cf, stdinData).toString("utf8");
      if (cf === "-") stdinData = Buffer.alloc(0);
    } catch (e: any) {
      process.stderr.write(`b3sum: ${cf}: ${e.message}\n`);
      failed++;
      continue;
    }
    const lines = text.split(/\r?\n/);
    for (const line of lines) {
      if (line === "") continue;
      const parsed = parseCheckLine(line);
      if (!parsed) {
        malformed++;
        process.stderr.write(`b3sum: ${cf}: no properly formatted checksum lines found\n`);
        continue;
      }
      total++;
      let actual = "";
      try {
        const data = fs.readFileSync(parsed.filename);
        actual = hashOne(data, { ...opts, length: parsed.expected.length / 2, seek: 0n });
      } catch (e: any) {
        process.stderr.write(`b3sum: ${parsed.filename}: ${e.message}\n`);
        failed++;
        if (!opts.quiet) process.stdout.write(`${parsed.filename}: FAILED open or read\n`);
        continue;
      }
      if (actual === parsed.expected) {
        if (!opts.quiet) {
          const name = escapedName(parsed.filename);
          process.stdout.write(`${name.escaped ? "\\" : ""}${name.text}: OK\n`);
        }
      } else {
        failed++;
        const name = escapedName(parsed.filename);
        process.stdout.write(`${name.escaped ? "\\" : ""}${name.text}: FAILED\n`);
      }
    }
  }
  if (failed > 0) process.stderr.write(`b3sum: WARNING: ${failed} computed checksum did NOT match\n`);
  if (malformed > 0 && total === 0) process.exitCode = 1;
  if (failed > 0) process.exitCode = 1;
}

function main(): void {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.check) runCheck(opts);
  else runHash(opts);
}

main();
