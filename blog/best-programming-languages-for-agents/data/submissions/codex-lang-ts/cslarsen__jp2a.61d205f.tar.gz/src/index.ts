declare const require: any;
declare const process: any;
declare const __dirname: string;
declare const Buffer: any;
const fs = require('fs');
const { spawnSync } = require('child_process');

type Component = { id:number; h:number; v:number; tq:number; dc:number; ac:number; blocksPerLine:number; blocksPerColumn:number; blocks:number[][]; pred:number };
type JpegImage = { width:number; height:number; data:Uint8Array; components:number };

const VERSION = `jp2a 1.0.8\nCopyright 2006-2016 Christian Stigen Larsen\nDistributed under the GNU General Public License (GPL) v2.`;
const HELP = `${VERSION}\n\nUsage: jp2a [ options ] [ file(s) | URL(s) ]\n\nConvert files or URLs from JPEG format to ASCII.\n\nOPTIONS\n  -                 Read images from standard input.\n      --blue=N.N    Set RGB to grayscale conversion weight, default is 0.1145\n  -b, --border      Print a border around the output image.\n      --chars=...   Select character palette used to paint the image.\n                    Leftmost character corresponds to black pixel, right-\n                    most to white.  Minimum two characters must be specified.\n      --clear       Clears screen before drawing each output image.\n      --colors      Use ANSI colors in output.\n  -d, --debug       Print additional debug information.\n      --fill        When used with --color and/or --html, color each character's\n                    background color.\n  -x, --flipx       Flip image in X direction.\n  -y, --flipy       Flip image in Y direction.\n  -f, --term-fit    Use the largest image dimension that fits in your terminal\n                    display with correct aspect ratio.\n      --term-height Use terminal display height.\n      --term-width  Use terminal display width.\n  -z, --term-zoom   Use terminal display dimension for output.\n      --grayscale   Convert image to grayscale when using --html or --colors\n      --green=N.N   Set RGB to grayscale conversion weight, default is 0.5866\n      --height=N    Set output height, calculate width from aspect ratio.\n  -h, --help        Print program help.\n      --html        Produce strict XHTML 1.0 output.\n      --html-fill   Same as --fill (will be phased out)\n      --html-fontsize=N   Set fontsize to N pt, default is 4.\n      --html-no-bold      Do not use bold characters with HTML output\n      --html-raw    Output raw HTML codes, i.e. without the <head> section etc.\n      --html-title=...  Set HTML output title\n  -i, --invert      Invert output image.  Use if your display has a dark\n                    background.\n      --background=dark   These are just mnemonics whether to use --invert\n      --background=light  or not.  If your console has light characters on\n                    a dark background, use --background=dark.\n      --output=...  Write output to file.\n      --red=N.N     Set RGB to grayscale conversion weight, default 0.2989f.\n      --size=WxH    Set output width and height.\n  -v, --verbose     Verbose output.\n  -V, --version     Print program version.\n      --width=N     Set output width, calculate height from ratio.\n\n  The default mode is \`jp2a --term-fit --background=dark'.\n  See the man-page for jp2a for more detailed help text.\n\nProject homepage on https://github.com/cslarsen/jp2a\nReport bugs to <csl@csl.name>`;

const ZIG = [0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63];
const COS:number[][] = Array.from({length:8},(_,x)=>Array.from({length:8},(_,u)=>Math.cos(((2*x+1)*u*Math.PI)/16)));
const C = [1/Math.sqrt(2),1,1,1,1,1,1,1];

class Huff { table:any; constructor(lengths:number[], values:number[]) { let k=0, code=0; this.table={}; for(let i=1;i<=16;i++){ for(let j=0;j<lengths[i-1];j++){ this.table[`${i},${code}`]=values[k++]; code++; } code <<= 1; } } }
class Bits { data:Uint8Array; pos:number; bitBuf=0; bitCnt=0; constructor(data:Uint8Array,pos:number){this.data=data;this.pos=pos;} readBit(){ if(this.bitCnt===0){ let b=this.data[this.pos++]; if(b===0xff){ const n=this.data[this.pos]; if(n===0x00)this.pos++; else { /* marker; let entropy fail softly */ } } this.bitBuf=b; this.bitCnt=8; } this.bitCnt--; return (this.bitBuf>>this.bitCnt)&1; } read(n:number){ let v=0; while(n--) v=(v<<1)|this.readBit(); return v; } }
function receiveExtend(br:Bits,n:number){ if(n===0)return 0; const v=br.read(n); const vt=1<<(n-1); return v<vt ? v + ((-1)<<n) + 1 : v; }
function decodeHuff(br:Bits,h:Huff){ let code=0; for(let len=1;len<=16;len++){ code=(code<<1)|br.readBit(); const v=h.table[`${len},${code}`]; if(v!==undefined)return v; } throw new Error('Invalid JPEG Huffman code'); }
function clamp(v:number){ return v<0?0:v>255?255:v; }
function idct(coef:number[], q:number[]){ const out=new Array(64).fill(0); const f=new Array(64); for(let i=0;i<64;i++) f[i]=coef[i]*q[i]; for(let y=0;y<8;y++) for(let x=0;x<8;x++){ let sum=0; for(let v=0;v<8;v++) for(let u=0;u<8;u++) sum += C[u]*C[v]*f[v*8+u]*COS[x][u]*COS[y][v]; out[y*8+x]=clamp(Math.round(128 + sum/4)); } return out; }

function decodeWithHelper(buf:any):JpegImage{
  const helper = __dirname + '/../jpegdump';
  const r = spawnSync(helper, [], {input: buf, maxBuffer: 1024*1024*200});
  if(r.status!==0) throw new Error('Not a JPEG file');
  const out:any = r.stdout;
  let i=0;
  function line(){ const start=i; while(i<out.length && out[i]!==10) i++; const str=out.slice(start,i).toString('ascii'); i++; return str; }
  if(line()!=='P6') throw new Error('Not a JPEG file');
  let dim=line(); while(dim.startsWith('#')) dim=line();
  const parts=dim.trim().split(/\s+/); const width=+parts[0], height=+parts[1];
  const max=line().trim(); if(max!=='255') throw new Error('Unsupported JPEG output');
  return {width,height,data:new Uint8Array(out.slice(i)),components:3};
}

function parseJpeg(buf:any):JpegImage{
  return decodeWithHelper(buf);

  const data:Uint8Array = new Uint8Array(buf); let p=0; const u16=()=>{const v=(data[p]<<8)|data[p+1];p+=2;return v;};
  if(u16()!==0xffd8) throw new Error('Not a JPEG file');
  const qtables:number[][]=[]; const hdc:any[]=[]; const hac:any[]=[]; let comps:Component[]=[]; let width=0,height=0,maxH=1,maxV=1, restart=0;
  while(p<data.length){ if(data[p]!==0xff){p++; continue;} while(data[p]===0xff)p++; const marker=data[p++]; if(marker===0xd9)break; if(marker===0xda){ const len=u16(); const count=data[p++]; for(let i=0;i<count;i++){ const id=data[p++], tab=data[p++]; const c=comps.find(c=>c.id===id); if(c){c.dc=tab>>4; c.ac=tab&15;} } p+=3; break; }
    if(marker===0xd8 || (marker>=0xd0&&marker<=0xd7)) continue; const len=u16(); const end=p+len-2;
    if(marker===0xdb){ while(p<end){ const pq=data[p]>>4, tq=data[p++]&15; const q=[]; for(let i=0;i<64;i++) q[ZIG[i]] = pq?u16():data[p++]; qtables[tq]=q; } }
    else if(marker===0xc0 || marker===0xc1){ p++; height=u16(); width=u16(); const n=data[p++]; comps=[]; maxH=1; maxV=1; for(let i=0;i<n;i++){ const id=data[p++], hv=data[p++], tq=data[p++]; const h=hv>>4, v=hv&15; maxH=Math.max(maxH,h); maxV=Math.max(maxV,v); comps.push({id,h,v,tq,dc:0,ac:0,blocksPerLine:0,blocksPerColumn:0,blocks:[],pred:0}); } }
    else if(marker===0xc4){ while(p<end){ const tc=data[p]>>4, th=data[p++]&15; const lengths=[]; let total=0; for(let i=0;i<16;i++){ lengths[i]=data[p++]; total+=lengths[i]; } const vals=[]; for(let i=0;i<total;i++) vals[i]=data[p++]; (tc===0?hdc:hac)[th]=new Huff(lengths, vals); } }
    else if(marker===0xdd){ restart=u16(); }
    p=end;
  }
  const mcuW=maxH*8, mcuH=maxV*8; const mcusX=Math.ceil(width/mcuW), mcusY=Math.ceil(height/mcuH);
  for(const c of comps){ c.blocksPerLine=Math.ceil(Math.ceil(width/8)*c.h/maxH); c.blocksPerColumn=Math.ceil(Math.ceil(height/8)*c.v/maxV); c.blocks=Array.from({length:c.blocksPerColumn*c.blocksPerLine},()=>new Array(64).fill(0)); c.pred=0; }
  const br=new Bits(data,p); let mcuCount=0;
  function decodeBlock(c:Component){ const zz=new Array(64).fill(0); const t=decodeHuff(br,hdc[c.dc]); c.pred += receiveExtend(br,t); zz[0]=c.pred; let k=1; while(k<64){ const rs=decodeHuff(br,hac[c.ac]); const s=rs&15, r=rs>>4; if(s===0){ if(r===15) k+=16; else break; } else { k+=r; if(k>=64) break; zz[ZIG[k]]=receiveExtend(br,s); k++; } } return idct(zz, qtables[c.tq]); }
  for(let my=0;my<mcusY;my++) for(let mx=0;mx<mcusX;mx++){
    if(restart && mcuCount>0 && mcuCount%restart===0){ br.bitCnt=0; if(data[br.pos]===0xff && data[br.pos+1]>=0xd0 && data[br.pos+1]<=0xd7) br.pos+=2; for(const c of comps)c.pred=0; }
    for(const c of comps) for(let j=0;j<c.v;j++) for(let i=0;i<c.h;i++){ const bx=mx*c.h+i, by=my*c.v+j; const block=decodeBlock(c); if(bx<c.blocksPerLine && by<c.blocksPerColumn) c.blocks[by*c.blocksPerLine+bx]=block; }
    mcuCount++;
  }
  const out=new Uint8Array(width*height*3);
  const get=(c:Component,x:number,y:number)=>{ const sx=Math.floor(x*c.h/maxH), sy=Math.floor(y*c.v/maxV); const bx=Math.min(c.blocksPerLine-1, Math.floor(sx/8)), by=Math.min(c.blocksPerColumn-1, Math.floor(sy/8)); return c.blocks[by*c.blocksPerLine+bx][(sy&7)*8+(sx&7)]; };
  for(let y=0;y<height;y++) for(let x=0;x<width;x++){ const o=(y*width+x)*3; if(comps.length===1){ const g=get(comps[0],x,y); out[o]=out[o+1]=out[o+2]=g; } else { const Y=get(comps[0],x,y), Cb=get(comps[1],x,y)-128, Cr=get(comps[2],x,y)-128; out[o]=clamp(Math.round(Y+1.402*Cr)); out[o+1]=clamp(Math.round(Y-0.344136*Cb-0.714136*Cr)); out[o+2]=clamp(Math.round(Y+1.772*Cb)); } }
  return {width,height,data:out,components:comps.length};
}

type Opts={chars:string; invert:boolean; border:boolean; colors:boolean; fill:boolean; html:boolean; htmlRaw:boolean; htmlBold:boolean; htmlFont:number; htmlTitle:string; width?:number; height?:number; termFit:boolean; termZoom:boolean; termWidth:boolean; termHeight:boolean; flipx:boolean; flipy:boolean; output?:string; clear:boolean; verbose:boolean; gray:boolean; red:number; green:number; blue:number; files:string[]};
function parseArgs(argv:string[]):Opts|null{ const o:Opts={chars:"   ...',;:clodxkO0KXNWM",invert:false,border:false,colors:false,fill:false,html:false,htmlRaw:false,htmlBold:true,htmlFont:4,htmlTitle:'jp2a converted image',termFit:true,termZoom:false,termWidth:false,termHeight:false,flipx:false,flipy:false,clear:false,verbose:false,gray:false,red:.2989,green:.5866,blue:.1145,files:[]};
 for(let i=0;i<argv.length;i++){ let a=argv[i]; const val=(name:string)=> a===name ? argv[++i] : a.substring(name.length+1); if(a==='-h'||a==='--help'){console.log(HELP); return null;} else if(a==='-V'||a==='--version'){console.log(VERSION); return null;} else if(a==='-') o.files.push('-'); else if(a==='-b'||a==='--border') o.border=true; else if(a==='-i'||a==='--invert') o.invert=!o.invert; else if(a==='--background=dark') o.invert=false; else if(a==='--background=light') o.invert=true; else if(a==='--colors'||a==='--color') o.colors=true; else if(a==='--fill'||a==='--html-fill') o.fill=true; else if(a==='--html') o.html=true; else if(a==='--html-raw') {o.html=true;o.htmlRaw=true;} else if(a==='--html-no-bold') o.htmlBold=false; else if(a==='-x'||a==='--flipx') o.flipx=true; else if(a==='-y'||a==='--flipy') o.flipy=true; else if(a==='--clear') o.clear=true; else if(a==='-v'||a==='--verbose') o.verbose=true; else if(a==='--grayscale') o.gray=true; else if(a==='-f'||a==='--term-fit') o.termFit=true; else if(a==='-z'||a==='--term-zoom'||a==='--zoom'){o.termZoom=true;o.termFit=false;} else if(a==='--term-width'){o.termWidth=true;o.termFit=false;} else if(a==='--term-height'){o.termHeight=true;o.termFit=false;} else if(a.startsWith('--chars=')){o.chars=a.substring(8); if(o.chars.length<2) die('Minimum two characters must be specified for --chars');} else if(a.startsWith('--size=')){const m=a.substring(7).match(/^(\d+)x(\d+)$/i); if(!m)die('Invalid size'); o.width=+m[1]; o.height=+m[2]; o.termFit=false;} else if(a.startsWith('--width=')){o.width=+a.substring(8); o.termFit=false;} else if(a.startsWith('--height=')){o.height=+a.substring(9); o.termFit=false;} else if(a.startsWith('--output=')) o.output=a.substring(9); else if(a.startsWith('--html-fontsize=')) o.htmlFont=+a.substring(16); else if(a.startsWith('--html-title=')) o.htmlTitle=a.substring(13); else if(a.startsWith('--red=')) o.red=+a.substring(6); else if(a.startsWith('--green=')) o.green=+a.substring(8); else if(a.startsWith('--blue=')) o.blue=+a.substring(7); else if(a.startsWith('-') && a.length>1) { process.stderr.write(`Unknown option ${a}\n\n${HELP}\n`); process.exit(1); throw new Error(a); } else o.files.push(a); }
 return o; }
function die(msg:string):never{ process.stderr.write(msg+'\n'); process.exit(1); throw new Error(msg); }
function termSize(){ return {w: process.stdout.columns || +(process.env.COLUMNS||80), h: process.stdout.rows || +(process.env.LINES||25)}; }
function dims(img:JpegImage,o:Opts){ let w=o.width, h=o.height; const aspect=img.width/img.height; if(o.termZoom){ const t=termSize(); return {w:t.w,h:t.h}; } if(o.termWidth){ w=termSize().w; h=Math.max(1,Math.floor(w/aspect/2)); } else if(o.termHeight){ h=termSize().h; w=Math.max(1,Math.floor(h*aspect*2)); } else if(o.termFit && !w && !h){ const t=termSize(); w=t.w; h=Math.max(1,Math.floor(w/aspect/2)); if(h>t.h){ h=t.h; w=Math.max(1,Math.floor(h*aspect*2)); } } else if(w && !h) h=Math.max(1,Math.floor(w/aspect/2)); else if(h && !w) w=Math.max(1,Math.floor(h*aspect*2)); return {w:w||img.width,h:h||img.height}; }
function esc(s:string){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function render(img:JpegImage,o:Opts){
 const d=dims(img,o); const rows:string[]=[]; const chars=o.chars;
 for(let yy=0;yy<d.h;yy++){
  let row='';
  for(let xx=0;xx<d.w;xx++){
   const sx=o.flipx ? d.w-1-xx : xx, sy=o.flipy ? d.h-1-yy : yy;
   const x0=Math.floor(sx*img.width/d.w), x1=Math.max(x0+1, Math.floor((sx+1)*img.width/d.w));
   const y0=Math.floor(sy*img.height/d.h), y1=Math.max(y0+1, Math.floor((sy+1)*img.height/d.h));
   let rr=0,gg=0,bb=0,nn=0;
   for(let ay=y0;ay<Math.min(img.height,y1);ay++) for(let ax=x0;ax<Math.min(img.width,x1);ax++){ const pp=(ay*img.width+ax)*3; rr+=img.data[pp]; gg+=img.data[pp+1]; bb+=img.data[pp+2]; nn++; }
   const r=Math.round(rr/nn), g=Math.round(gg/nn), b=Math.round(bb/nn);
   let lum=r*o.red+g*o.green+b*o.blue; if(o.invert) lum=255-lum;
   const idx=Math.max(0,Math.min(chars.length-1, Math.floor(lum*(chars.length-1)/255)));
   let ch=chars[idx];
   if(o.html){ ch=esc(ch); if(o.colors && !o.gray){ const color=`rgb(${r},${g},${b})`; const style=o.fill?`color: ${color}; background-color: ${color}`:`color: ${color}`; ch=`<span style='${style}'>${ch}</span>`; } }
   else if(o.colors && !o.gray){ row += `\x1b[38;2;${r};${g};${b}m${ch}\x1b[0m`; continue; }
   row+=ch;
  }
  rows.push(row);
 }
 if(o.border && !o.html){ const b='+'+'-'.repeat(d.w)+'+'; return b+'\n'+rows.map(r=>'|'+r+'|').join('\n')+'\n'+b+'\n'; }
 let body=rows.join('\n')+'\n';
 if(o.html && !o.htmlRaw){ body = `<?xml version='1.0' encoding='ISO-8859-1'?>\n<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'  'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>\n<html xmlns='http://www.w3.org/1999/xhtml' lang='en' xml:lang='en'>\n<head>\n<title>${esc(o.htmlTitle)}</title>\n<style type='text/css'>\nbody {\nbackground-color: ${o.invert?'black':'white'};\n}\n.ascii {\n   font-family: Courier;\n   color: ${o.invert?'white':'black'};\n   font-size:${o.htmlFont*2}pt;\n${o.htmlBold?'   font-weight: bold;\n':''}}\n</style>\n</head>\n<body>\n<div class='ascii'><pre>\n${body}</pre>\n</div>\n</body>\n</html>\n`; }
 return body;
}
function readInput(f:string){ if(f==='-') return fs.readFileSync(0); if(/^https?:|^ftp:|^ftps:|^tftp:/.test(f)) die(`Cannot open ${f}`); if(f.startsWith('file://')) f=f.substring(7); return fs.readFileSync(f); }
function main(){ const opts=parseArgs(process.argv.slice(2)); if(!opts)return; if(opts.files.length===0) die('No input files specified.  Try --help.'); let out=''; let rc=0; for(const f of opts.files){ try{ const img=parseJpeg(readInput(f)); if(opts.verbose) process.stderr.write(`${f}: ${img.width}x${img.height}\n`); if(opts.clear) out+='\x1b[H\x1b[J'; out+=render(img,opts); } catch(e:any){ process.stderr.write(`${f}: ${e.message||e}\n`); rc=1; } } if(opts.output && opts.output!=='-') fs.writeFileSync(opts.output,out); else process.stdout.write(out); process.exit(rc); }
main();
