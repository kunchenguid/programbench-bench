#include <stdio.h>
#include <stdlib.h>
#include <jpeglib.h>
#include <string.h>

int main(void) {
  struct jpeg_decompress_struct cinfo;
  struct jpeg_error_mgr jerr;
  jpeg_create_decompress(&cinfo);
  cinfo.err = jpeg_std_error(&jerr);

  unsigned char *buf = NULL;
  size_t cap = 0, len = 0;
  unsigned char tmp[8192];
  for (;;) {
    size_t n = fread(tmp, 1, sizeof(tmp), stdin);
    if (n) {
      if (len + n > cap) {
        cap = cap ? cap * 2 : 65536;
        while (cap < len + n) cap *= 2;
        buf = (unsigned char*)realloc(buf, cap);
        if (!buf) return 2;
      }
      memcpy(buf + len, tmp, n);
      len += n;
    }
    if (n < sizeof(tmp)) {
      if (ferror(stdin)) return 2;
      break;
    }
  }

  jpeg_mem_src(&cinfo, buf, len);
  jpeg_read_header(&cinfo, TRUE);
  cinfo.out_color_space = JCS_RGB;
  jpeg_start_decompress(&cinfo);
  printf("P6\n%u %u\n255\n", cinfo.output_width, cinfo.output_height);
  JSAMPARRAY row = (*cinfo.mem->alloc_sarray)((j_common_ptr)&cinfo, JPOOL_IMAGE, cinfo.output_width * cinfo.output_components, 1);
  while (cinfo.output_scanline < cinfo.output_height) {
    jpeg_read_scanlines(&cinfo, row, 1);
    fwrite(row[0], 1, cinfo.output_width * cinfo.output_components, stdout);
  }
  jpeg_finish_decompress(&cinfo);
  jpeg_destroy_decompress(&cinfo);
  free(buf);
  return 0;
}
