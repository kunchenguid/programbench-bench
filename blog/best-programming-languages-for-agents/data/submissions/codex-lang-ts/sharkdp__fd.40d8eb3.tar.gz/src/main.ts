declare const require: any;
declare const process: any;
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

type When = "auto" | "always" | "never";

interface Options {
  hidden: boolean;
  noIgnore: boolean;
  caseSensitive?: boolean;
  glob: boolean;
  fixed: boolean;
  absolute: boolean;
  listDetails: boolean;
  follow: boolean;
  fullPath: boolean;
  print0: boolean;
  maxDepth: number | null;
  minDepth: number;
  excludes: string[];
  types: Set<string>;
  extensions: string[];
  sizeFilters: SizeFilter[];
  changedWithin: number | null;
  changedBefore: number | null;
  owners: OwnerFilter[];
  format: string | null;
  execs: ExecSpec[];
  execBatches: ExecSpec[];
  batchSize: number;
  color: When;
  hyperlink: When;
  ignoreContain: string[];
  maxResults: number | null;
  quiet: boolean;
  showErrors: boolean;
  baseDirectory: string | null;
  pathSeparator: string;
  searchPaths: string[];
  stripCwdPrefix: "auto" | "always" | "never";
  prune: boolean;
  andPatterns: string[];
  ignoreFiles: string[];
}

interface SizeFilter { op: "eq" | "ge" | "le"; bytes: number; }
interface OwnerFilter { user?: number; group?: number; notUser?: boolean; notGroup?: boolean; }
interface ExecSpec { cmd: string[]; }
interface Entry {
  abs: string;
  display: string;
  relFromRoot: string;
  name: string;
  stat: any;
  lst: any;
  isDir: boolean;
  isSymlink: boolean;
}
interface IgnoreRule { pattern: string; neg: boolean; dirOnly: boolean; base: string; }

const HELP_SHORT = `A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]  the search pattern (a regular expression, unless '--glob' is used; optional)
  [path]...  the root directories for the filesystem search (optional)

Options:
  -H, --hidden                     Search hidden files and directories
  -I, --no-ignore                  Do not respect .(git|fd)ignore files
  -s, --case-sensitive             Case-sensitive search (default: smart case)
  -i, --ignore-case                Case-insensitive search (default: smart case)
  -g, --glob                       Glob-based search (default: regular expression)
  -a, --absolute-path              Show absolute instead of relative paths
  -l, --list-details               Use a long listing format with file metadata
  -L, --follow                     Follow symbolic links
  -p, --full-path                  Search full abs. path (default: filename only)
  -d, --max-depth <depth>          Set maximum search depth (default: none)
  -E, --exclude <pattern>          Exclude entries that match the given glob pattern
  -t, --type <filetype>            Filter by type: file (f), directory (d/dir), symlink (l),
                                   executable (x), empty (e), socket (s), pipe (p), char-device
                                   (c), block-device (b)
  -e, --extension <ext>            Filter by file extension
  -S, --size <size>                Limit results based on the size of files
      --changed-within <date|dur>  Filter by file modification time (newer than)
      --changed-before <date|dur>  Filter by file modification time (older than)
  -o, --owner <user:group>         Filter by owning user and/or group
      --format <fmt>               Print results according to template
  -x, --exec <cmd>...              Execute a command for each search result
  -X, --exec-batch <cmd>...        Execute a command with all search results at once
  -c, --color <when>               When to use colors [default: auto] [possible values: auto,
                                   always, never]
      --hyperlink[=<when>]         Add hyperlinks to output paths [default: never] [possible
                                   values: auto, always, never]
      --ignore-contain <name>      Ignore directories containing the named entry
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version
`;

const HELP_LONG = `A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]
          the search pattern which is either a regular expression (default) or a glob pattern (if
          --glob is used). If no pattern has been specified, every entry is considered a match.

  [path]...
          The directory where the filesystem search is rooted (optional). If omitted, search the
          current working directory.

Options:
  -H, --hidden          Include hidden directories and files in the search results
  -I, --no-ignore       Show search results from files and directories that would otherwise be ignored
  -u, --unrestricted... Perform an unrestricted search, including ignored and hidden files
  -s, --case-sensitive  Perform a case-sensitive search
  -i, --ignore-case     Perform a case-insensitive search
  -g, --glob            Perform a glob-based search instead of a regular expression search
      --regex           Perform a regular-expression based search
  -F, --fixed-strings   Treat the pattern as a literal string instead of a regular expression
      --and <pattern>   Add additional required search patterns
  -a, --absolute-path   Shows the full path starting from the root
  -l, --list-details    Use a detailed listing format like 'ls -l'
  -L, --follow          Traverse symbolic links
  -p, --full-path       Match against the full path
  -0, --print0          Separate search results by the null character
  -d, --max-depth <depth>          Limit the directory traversal to a given depth
      --min-depth <depth>          Only show search results starting at the given depth
      --exact-depth <depth>        Only show search results at the exact given depth
  -E, --exclude <pattern>          Exclude files/directories that match the given glob pattern
      --prune           Do not traverse into directories that match the search criteria
  -t, --type <filetype> Filter the search by type
  -e, --extension <ext> Filter search results by their file extension
  -S, --size <size>     Limit results based on the size of files
      --changed-within <date|dur>  Filter results based on the file modification time
      --changed-before <date|dur>  Filter results based on the file modification time
  -o, --owner <user:group>         Filter files by their user and/or group
      --format <fmt>    Print results according to template
  -x, --exec <cmd>...   Execute a command for each search result
  -X, --exec-batch <cmd>...        Execute the given command once, with all search results
      --batch-size <size>          Maximum number of arguments to pass to the command
      --ignore-file <path>         Add a custom ignore-file in '.gitignore' format
  -c, --color <when>    Declare when to use color for the pattern match output
      --hyperlink[=<when>]         Add a terminal hyperlink to a file:// url
      --ignore-contain <name>      Ignore directories containing the named entry
  -j, --threads <num>   Set number of threads to use for searching & executing
      --max-results <count>        Limit the number of search results
  -1                    Limit the search to a single result
  -q, --quiet           Return 0 if there is at least one match, otherwise 1
      --show-errors     Enable the display of filesystem errors
  -C, --base-directory <path>      Change the current working directory
      --path-separator <separator> Set the path separator to use when printing file paths
      --search-path <search-path>  Provide paths to search
      --strip-cwd-prefix[=<when>]  Change ./ prefix behavior for exec/print0
      --one-file-system            Do not descend into a different file system
  -h, --help            Print help (see a summary with '-h')
  -V, --version         Print version

Bugs can be reported on GitHub: https://github.com/sharkdp/fd/issues
`;

function defaultOptions(): Options {
  return {
    hidden: false, noIgnore: false, glob: false, fixed: false, absolute: false,
    listDetails: false, follow: false, fullPath: false, print0: false,
    maxDepth: null, minDepth: 1, excludes: [], types: new Set(), extensions: [],
    sizeFilters: [], changedWithin: null, changedBefore: null, owners: [],
    format: null, execs: [], execBatches: [], batchSize: 0, color: "auto",
    hyperlink: "never", ignoreContain: [], maxResults: null, quiet: false,
    showErrors: false, baseDirectory: null, pathSeparator: path.sep,
    searchPaths: [], stripCwdPrefix: "auto", prune: false, andPatterns: [],
    ignoreFiles: []
  };
}

function die(msg: string, code = 1): any {
  console.error(`[fd error]: ${msg}`);
  process.exit(code);
}

function main() {
  const argv = normalizeShortOptions(process.argv.slice(2));
  const opts = defaultOptions();
  const positional: string[] = [];
  parseArgs(argv, opts, positional);
  if (opts.baseDirectory) process.chdir(opts.baseDirectory);

  let pattern: string | null = null;
  let roots: string[] = [];
  if (opts.searchPaths.length) {
    roots = opts.searchPaths;
    if (positional.length) pattern = positional[0];
  } else if (positional.length === 0) {
    roots = ["."];
  } else if (positional.length === 1) {
    pattern = positional[0];
    roots = ["."];
  } else {
    pattern = positional[0];
    roots = positional.slice(1);
  }

  if (!opts.fullPath && pattern && pattern.includes(path.sep)) {
    console.error(`[fd error]: The search pattern '${pattern}' contains a path-separation character ('/') and will not lead to any search results.\n`);
    console.error(`If you want to search for all files inside the '${pattern}' directory, use a match-all pattern:\n\n  fd . '${pattern}'\n`);
    console.error(`Instead, if you want your pattern to match the full file path, use:\n\n  fd --full-path '${pattern}'`);
    process.exit(1);
  }

  const matchers = [pattern, ...opts.andPatterns].map(p => buildMatcher(p, opts)).filter(Boolean) as ((e: Entry) => boolean)[];
  const customRules = opts.ignoreFiles.flatMap(file => readIgnoreFile(path.resolve(file), path.dirname(path.resolve(file))));
  const results: Entry[] = [];
  for (const rootArg of roots) {
    const absRoot = path.resolve(rootArg);
    let st: any;
    try { st = fs.statSync(absRoot); } catch { die(`Search path '${rootArg}' is not a directory.`); }
    if (!st.isDirectory()) die(`Search path '${rootArg}' is not a directory.`);
    const prefix = opts.absolute ? absRoot : rootArg;
    walk(absRoot, rootArg, prefix, 0, opts, matchers, customRules, results);
    if (opts.maxResults !== null && results.length >= opts.maxResults) break;
  }

  const final = opts.maxResults !== null ? results.slice(0, opts.maxResults) : results;
  if (opts.quiet) process.exit(final.length ? 0 : 1);
  if (opts.listDetails) {
    const args = final.map(e => e.display);
    if (args.length) spawnSync("ls", ["-ld", ...args], { stdio: "inherit" });
  } else if (opts.execs.length || opts.execBatches.length) {
    runExecs(opts, final);
  } else {
    for (const e of final) printEntry(opts, e);
  }
}

function parseArgs(argv: string[], opts: Options, positional: string[]) {
  let stop = false;
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (stop || a === "-" || !a.startsWith("-")) { positional.push(a); continue; }
    if (a === "--") { stop = true; continue; }
    const [name, eqVal] = a.includes("=") ? a.split(/=(.*)/s, 2) : [a, undefined];
    const val = () => eqVal !== undefined ? eqVal : argv[++i] ?? die(`The argument '${a}' requires a value but none was supplied`);
    const takeExec = (): string[] => {
      const cmd: string[] = [];
      while (i + 1 < argv.length) {
        const n = argv[++i];
        if (n === ";") break;
        cmd.push(n);
      }
      if (!cmd.length) die(`The argument '${a}' requires a value but none was supplied`);
      return cmd;
    };
    switch (name) {
      case "-h": console.log(HELP_SHORT); process.exit(0);
      case "--help": console.log(HELP_LONG); process.exit(0);
      case "-V": case "--version": console.log("fd 10.3.0"); process.exit(0);
      case "-H": case "--hidden": opts.hidden = true; break;
      case "--no-hidden": opts.hidden = false; break;
      case "-I": case "--no-ignore": opts.noIgnore = true; break;
      case "--ignore": opts.noIgnore = false; break;
      case "-u": case "--unrestricted": opts.hidden = true; opts.noIgnore = true; break;
      case "-s": case "--case-sensitive": opts.caseSensitive = true; break;
      case "-i": case "--ignore-case": opts.caseSensitive = false; break;
      case "-g": case "--glob": opts.glob = true; break;
      case "--regex": opts.glob = false; break;
      case "-F": case "--fixed-strings": opts.fixed = true; break;
      case "--and": opts.andPatterns.push(val()); break;
      case "-a": case "--absolute-path": opts.absolute = true; break;
      case "--relative-path": opts.absolute = false; break;
      case "-l": case "--list-details": opts.listDetails = true; break;
      case "-L": case "--follow": opts.follow = true; break;
      case "--no-follow": opts.follow = false; break;
      case "-p": case "--full-path": opts.fullPath = true; break;
      case "-0": case "--print0": opts.print0 = true; break;
      case "-d": case "--max-depth": opts.maxDepth = parseDepth(val()); break;
      case "--min-depth": opts.minDepth = parseDepth(val()); break;
      case "--exact-depth": { const d = parseDepth(val()); opts.minDepth = d; opts.maxDepth = d; break; }
      case "-E": case "--exclude": opts.excludes.push(val()); break;
      case "--prune": opts.prune = true; break;
      case "-t": case "--type": addType(opts, val()); break;
      case "-e": case "--extension": opts.extensions.push(val().replace(/^\./, "").toLowerCase()); break;
      case "-S": case "--size": opts.sizeFilters.push(parseSize(val())); break;
      case "--changed-within": case "--change-newer-than": case "--newer": case "--changed-after": opts.changedWithin = parseDateOrDuration(val()); break;
      case "--changed-before": case "--change-older-than": case "--older": opts.changedBefore = parseDateOrDuration(val()); break;
      case "-o": case "--owner": opts.owners.push(parseOwner(val())); break;
      case "--format": opts.format = val(); break;
      case "-x": case "--exec": opts.execs.push({ cmd: takeExec() }); break;
      case "-X": case "--exec-batch": opts.execBatches.push({ cmd: takeExec() }); break;
      case "--batch-size": opts.batchSize = parseInt(val(), 10) || 0; break;
      case "--ignore-file": opts.ignoreFiles.push(val()); break;
      case "-c": case "--color": opts.color = val() as When; break;
      case "--hyperlink": opts.hyperlink = eqVal === undefined ? "auto" : eqVal as When; break;
      case "--ignore-contain": opts.ignoreContain.push(val()); break;
      case "-j": case "--threads": i++; break;
      case "--max-results": opts.maxResults = parseInt(val(), 10); break;
      case "-1": opts.maxResults = 1; break;
      case "-q": case "--quiet": case "--has-results": opts.quiet = true; opts.maxResults = 1; break;
      case "--show-errors": opts.showErrors = true; break;
      case "-C": case "--base-directory": opts.baseDirectory = val(); break;
      case "--path-separator": opts.pathSeparator = val(); break;
      case "--search-path": opts.searchPaths.push(val()); break;
      case "--strip-cwd-prefix": opts.stripCwdPrefix = eqVal === undefined ? "always" : eqVal as any; break;
      case "--one-file-system": case "--mount": case "--xdev": break;
      case "--no-ignore-vcs": case "--no-require-git": case "--no-ignore-parent": break;
      default:
        die(`unexpected argument '${a}' found`);
    }
  }
}

function normalizeShortOptions(args: string[]): string[] {
  const out: string[] = [];
  let stop = false;
  const valueOpts = new Set(["d", "E", "t", "e", "S", "o", "c", "j", "C"]);
  for (const a of args) {
    if (stop || a === "--" || !a.startsWith("-") || a.startsWith("--") || a === "-" || a.length <= 2) {
      out.push(a);
      if (a === "--") stop = true;
      continue;
    }
    let rest = a.slice(1);
    while (rest.length) {
      const ch = rest[0];
      out.push("-" + ch);
      rest = rest.slice(1);
      if (valueOpts.has(ch)) {
        if (rest.length) out.push(rest);
        break;
      }
    }
  }
  return out;
}

function parseDepth(s: string) { const n = parseInt(s, 10); if (isNaN(n)) die(`'${s}' isn't a valid value for '<depth>'`); return n; }

function addType(opts: Options, t: string) {
  const map: Record<string, string> = { f: "file", file: "file", d: "dir", dir: "dir", directory: "dir", l: "symlink", symlink: "symlink", x: "executable", executable: "executable", e: "empty", empty: "empty", s: "socket", socket: "socket", p: "pipe", pipe: "pipe", b: "block", "block-device": "block", c: "char", "char-device": "char" };
  const v = map[t];
  if (!v) die(`invalid value '${t}' for '--type <filetype>'`);
  opts.types.add(v);
  if (v === "executable") opts.types.add("file");
}

function parseSize(s: string): SizeFilter {
  const m = /^([+-]?)(\d+)([a-zA-Z]+)?$/.exec(s);
  if (!m) die(`'${s}' is not a valid size`);
  const unit = (m[3] || "b").toLowerCase();
  const mult: Record<string, number> = { b: 1, k: 1000, m: 1e6, g: 1e9, t: 1e12, ki: 1024, mi: 1048576, gi: 1073741824, ti: 1099511627776 };
  if (!mult[unit]) die(`'${unit}' is not a valid size unit`);
  return { op: m[1] === "+" ? "ge" : m[1] === "-" ? "le" : "eq", bytes: parseInt(m[2], 10) * mult[unit] };
}

function parseDateOrDuration(s: string): number {
  if (s.startsWith("@")) return parseInt(s.slice(1), 10) * 1000;
  const dur = /^(\d+)\s*([a-zA-Z]+)$/.exec(s);
  if (dur) {
    const n = parseInt(dur[1], 10);
    const u = dur[2].toLowerCase();
    const mult = u.startsWith("sec") || u === "s" ? 1000 : u.startsWith("min") ? 60000 : u === "h" || u.startsWith("hour") ? 3600000 : u === "d" || u.startsWith("day") ? 86400000 : u.startsWith("week") || u === "w" ? 604800000 : 0;
    if (mult) return Date.now() - n * mult;
  }
  const t = Date.parse(s.includes("T") ? s : s.replace(" ", "T"));
  if (isNaN(t)) die(`'${s}' is not a valid date or duration`);
  return t;
}

function parseOwner(s: string): OwnerFilter {
  const [u, g] = s.split(":");
  const f: OwnerFilter = {};
  if (u) { f.notUser = u.startsWith("!"); f.user = lookupId(f.notUser ? u.slice(1) : u, "passwd"); }
  if (g !== undefined && g !== "") { f.notGroup = g.startsWith("!"); f.group = lookupId(f.notGroup ? g.slice(1) : g, "group"); }
  return f;
}

function lookupId(v: string, db: "passwd" | "group"): number {
  if (/^\d+$/.test(v)) return parseInt(v, 10);
  try {
    const file = fs.readFileSync(db === "passwd" ? "/etc/passwd" : "/etc/group", "utf8");
    for (const line of file.split("\n")) {
      const p = line.split(":");
      if (p[0] === v) return parseInt(p[2], 10);
    }
  } catch {}
  return -999999;
}

function buildMatcher(pattern: string | null, opts: Options): ((e: Entry) => boolean) | null {
  if (pattern === null || pattern === "" || pattern === ".") return null;
  const sensitive = opts.caseSensitive !== undefined ? opts.caseSensitive : /[A-Z]/.test(pattern);
  if (opts.fixed) {
    const needle = sensitive ? pattern : pattern.toLowerCase();
    return e => {
      const target = matchTarget(e, opts);
      const s = sensitive ? target : target.toLowerCase();
      return s.includes(needle);
    };
  }
  if (opts.glob) {
    const re = globToRegExp(pattern, sensitive);
    return e => re.test(matchTarget(e, opts));
  }
  let re: RegExp;
  try { re = new RegExp(pattern, sensitive ? "" : "i"); } catch (err: any) { die(`regex parse error: ${err.message}`); }
  return e => re.test(matchTarget(e, opts));
}

function matchTarget(e: Entry, opts: Options): string {
  return opts.fullPath ? e.abs : e.name;
}

function walk(absDir: string, rootArg: string, displayPrefix: string, depth: number, opts: Options, matchers: ((e: Entry) => boolean)[], inheritedRules: IgnoreRule[], results: Entry[]) {
  if (opts.maxDepth !== null && depth >= opts.maxDepth) return;
  let names: string[];
  try { names = fs.readdirSync(absDir).sort(); } catch (err: any) { if (opts.showErrors) console.error(`[fd error]: ${err.message}`); return; }
  const localRules = opts.noIgnore ? inheritedRules : inheritedRules.concat(readLocalIgnores(absDir));
  for (const name of names) {
    const abs = path.join(absDir, name);
    let lst: any, st: any;
    try { lst = fs.lstatSync(abs); st = opts.follow ? fs.statSync(abs) : lst; } catch (err: any) { if (opts.showErrors) console.error(`[fd error]: ${err.message}`); continue; }
    const childDepth = depth + 1;
    const relRoot = path.relative(path.resolve(rootArg), abs) || name;
    const display = makeDisplay(abs, rootArg, displayPrefix, relRoot, opts, st.isDirectory());
    const entry: Entry = { abs, display, relFromRoot: relRoot, name, stat: st, lst, isDir: st.isDirectory(), isSymlink: lst.isSymbolicLink() };
    const hiddenSkip = !opts.hidden && isHidden(relRoot);
    const ignored = !opts.noIgnore && isIgnored(entry, localRules);
    const excluded = opts.excludes.some(p => globToRegExp(p, true).test(name) || globToRegExp(p, true).test(relRoot));
    const containSkip = entry.isDir && opts.ignoreContain.some(n => fs.existsSync(path.join(abs, n)));
    const matched = !hiddenSkip && !ignored && !excluded && passesFilters(entry, opts) && matchers.every(m => m(entry));
    if (matched && childDepth >= opts.minDepth) {
      results.push(entry);
      if (opts.maxResults !== null && results.length >= opts.maxResults) return;
    }
    const shouldPrune = opts.prune && matched;
    if (entry.isDir && !entry.isSymlink && !hiddenSkip && !ignored && !excluded && !containSkip && !shouldPrune) {
      walk(abs, rootArg, displayPrefix, childDepth, opts, matchers, localRules, results);
      if (opts.maxResults !== null && results.length >= opts.maxResults) return;
    }
    if (entry.isDir && opts.follow && entry.isSymlink && !hiddenSkip && !ignored && !excluded && !containSkip && !shouldPrune) {
      walk(abs, rootArg, displayPrefix, childDepth, opts, matchers, localRules, results);
    }
  }
}

function makeDisplay(abs: string, rootArg: string, prefix: string, relRoot: string, opts: Options, isDir: boolean): string {
  let d: string;
  if (opts.absolute) d = abs;
  else if (rootArg === ".") d = relRoot;
  else d = path.join(prefix, relRoot);
  if (isDir && !d.endsWith(path.sep)) d += path.sep;
  if ((opts.print0 || opts.execs.length || opts.execBatches.length) && opts.stripCwdPrefix !== "always" && !path.isAbsolute(d) && !d.startsWith("./") && d.startsWith("-")) d = "./" + d;
  if (opts.pathSeparator !== path.sep) d = d.split(path.sep).join(opts.pathSeparator);
  return d;
}

function isHidden(rel: string) {
  return rel.split(path.sep).some(part => part.startsWith(".") && part !== "." && part !== "..");
}

function readLocalIgnores(dir: string): IgnoreRule[] {
  const rules: IgnoreRule[] = [];
  for (const f of [".gitignore", ".ignore", ".fdignore"]) rules.push(...readIgnoreFile(path.join(dir, f), dir));
  return rules;
}

function readIgnoreFile(file: string, base: string): IgnoreRule[] {
  try {
    return fs.readFileSync(file, "utf8").split(/\r?\n/).map(line => line.trim()).filter(line => line && !line.startsWith("#")).map(line => {
      const neg = line.startsWith("!");
      if (neg) line = line.slice(1);
      const dirOnly = line.endsWith("/");
      if (dirOnly) line = line.slice(0, -1);
      return { pattern: line, neg, dirOnly, base };
    });
  } catch { return []; }
}

function isIgnored(e: Entry, rules: IgnoreRule[]): boolean {
  let ignored = false;
  for (const r of rules) {
    if (r.dirOnly && !e.isDir) continue;
    const rel = path.relative(r.base, e.abs);
    if (rel.startsWith("..")) continue;
    const target = r.pattern.includes("/") ? rel : e.name;
    if (globToRegExp(r.pattern, true).test(target)) ignored = !r.neg;
  }
  return ignored;
}

function passesFilters(e: Entry, opts: Options): boolean {
  if (opts.types.size) {
    const normalTypes = [...opts.types].filter(t => t !== "empty" && t !== "executable");
    let ok = normalTypes.length === 0 || normalTypes.some(t => typeMatches(e, t));
    if (opts.types.has("executable")) ok = ok && e.stat.isFile() && (e.stat.mode & 0o111) !== 0;
    if (opts.types.has("empty")) ok = ok && isEmpty(e);
    if (!ok) return false;
  }
  if (opts.extensions.length) {
    const ext = path.extname(e.name).replace(/^\./, "").toLowerCase();
    if (!opts.extensions.includes(ext)) return false;
  }
  for (const sf of opts.sizeFilters) {
    if (sf.op === "eq" && e.stat.size !== sf.bytes) return false;
    if (sf.op === "ge" && e.stat.size < sf.bytes) return false;
    if (sf.op === "le" && e.stat.size > sf.bytes) return false;
  }
  if (opts.changedWithin !== null && e.stat.mtimeMs <= opts.changedWithin) return false;
  if (opts.changedBefore !== null && e.stat.mtimeMs >= opts.changedBefore) return false;
  for (const ofi of opts.owners) {
    if (ofi.user !== undefined && ((e.stat.uid === ofi.user) === !!ofi.notUser)) return false;
    if (ofi.group !== undefined && ((e.stat.gid === ofi.group) === !!ofi.notGroup)) return false;
  }
  return true;
}

function typeMatches(e: Entry, t: string): boolean {
  switch (t) {
    case "file": return e.stat.isFile();
    case "dir": return e.stat.isDirectory();
    case "symlink": return e.lst.isSymbolicLink();
    case "socket": return e.stat.isSocket();
    case "pipe": return e.stat.isFIFO();
    case "block": return e.stat.isBlockDevice();
    case "char": return e.stat.isCharacterDevice();
    default: return false;
  }
}

function isEmpty(e: Entry): boolean {
  if (e.stat.isFile()) return e.stat.size === 0;
  if (e.stat.isDirectory()) {
    try { return fs.readdirSync(e.abs).length === 0; } catch { return false; }
  }
  return false;
}

function globToRegExp(glob: string, sensitive: boolean): RegExp {
  let re = "";
  for (let i = 0; i < glob.length; i++) {
    const c = glob[i];
    if (c === "*") {
      if (glob[i + 1] === "*") { re += ".*"; i++; }
      else re += "[^/]*";
    } else if (c === "?") re += "[^/]";
    else if (c === "[") {
      let j = i + 1;
      while (j < glob.length && glob[j] !== "]") j++;
      if (j < glob.length) { re += glob.slice(i, j + 1); i = j; } else re += "\\[";
    } else re += c.replace(/[\\^$+?.()|{}]/g, "\\$&");
  }
  return new RegExp("^" + re + "$", sensitive ? "" : "i");
}

function printEntry(opts: Options, e: Entry) {
  let out = opts.format ? applyTemplate(opts.format, e) : e.display;
  if (!opts.format && opts.color === "always") out = colorize(out, e);
  if (!opts.format && opts.hyperlink === "always") out = `\x1b]8;;file://${e.abs}\x1b\\${out}\x1b]8;;\x1b\\`;
  process.stdout.write(out + (opts.print0 ? "\0" : "\n"));
}

function colorize(s: string, e: Entry): string {
  const slash = s.endsWith(path.sep) ? path.sep : "";
  const raw = slash ? s.slice(0, -1) : s;
  const dir = path.dirname(raw);
  const base = path.basename(raw);
  const prefix = dir === "." ? "" : `\x1b[38;5;81m${dir}/\x1b[0m`;
  const code = e.isDir ? "38;5;81" : e.stat.isFile() && (e.stat.mode & 0o111) ? "38;5;48" : "38;5;185";
  return `${prefix}\x1b[${code}m${base}${slash}\x1b[0m`;
}

function applyTemplate(fmt: string, e: Entry): string {
  return replacePlaceholders(fmt, e, false) as string;
}

function replacePlaceholders(arg: string, e: Entry, arrayMode: false): string;
function replacePlaceholders(arg: string, entries: Entry[], arrayMode: true): string[];
function replacePlaceholders(arg: string, x: Entry | Entry[], arrayMode: boolean): string | string[] {
  if (arrayMode) return (x as Entry[]).map(e => replacePlaceholders(arg, e, false) as string);
  const e = x as Entry;
  const noSlash = e.display.endsWith(path.sep) ? e.display.slice(0, -1) : e.display;
  const base = path.basename(noSlash);
  const dir = path.dirname(noSlash);
  const ext = path.extname(base);
  const pathNoExt = ext ? noSlash.slice(0, -ext.length) : noSlash;
  const baseNoExt = ext ? base.slice(0, -ext.length) : base;
  return arg.replace(/\{\{|\}\}|\{\/\/\}|\{\/\.\}|\{\/\}|\{\.\}|\{\}/g, m => {
    switch (m) {
      case "{{": return "{";
      case "}}": return "}";
      case "{}": return e.display;
      case "{/}": return base;
      case "{//}": return dir;
      case "{.}": return pathNoExt;
      case "{/.}": return baseNoExt;
      default: return m;
    }
  });
}

function runExecs(opts: Options, entries: Entry[]) {
  for (const e of entries) {
    for (const ex of opts.execs) {
      const args = expandExec(ex.cmd, [e]);
      if (args.length) spawnSync(args[0], args.slice(1), { stdio: "inherit" });
      if (opts.print0) process.stdout.write("\0");
    }
  }
  for (const ex of opts.execBatches) {
    const batches = opts.batchSize > 0 ? chunk(entries, opts.batchSize) : [entries];
    for (const b of batches) {
      const args = expandExec(ex.cmd, b);
      if (args.length) spawnSync(args[0], args.slice(1), { stdio: "inherit" });
    }
  }
}

function expandExec(cmd: string[], entries: Entry[]): string[] {
  const hasPlaceholder = cmd.some(a => /\{(?:\}|\/\}|\/\/\}|\/\.\}|\.\})/.test(a));
  const out: string[] = [];
  for (const a of cmd) {
    if (hasPlaceholder && entries.length > 1 && /\{(?:\}|\/\}|\/\/\}|\/\.\}|\.\})/.test(a)) out.push(...replacePlaceholders(a, entries, true));
    else out.push(replacePlaceholders(a, entries[0], false) as string);
  }
  if (!hasPlaceholder) out.push(...entries.map(e => e.display));
  return out;
}

function chunk<T>(xs: T[], n: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < xs.length; i += n) out.push(xs.slice(i, i + n));
  return out;
}

main();
