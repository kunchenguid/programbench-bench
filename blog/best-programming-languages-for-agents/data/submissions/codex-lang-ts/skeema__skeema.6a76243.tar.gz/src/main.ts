declare const require: any;
declare const process: any;

const fs = require('fs');
const path = require('path');

const VERSION = 'skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z';
const commands = ['add-environment','diff','format','help','init','lint','pull','push','version'];
const summaries: Record<string,string> = {
  'add-environment':'Add a new named environment to an existing host directory',
  diff:"Compare a DB server's schemas to the filesystem",
  format:'Normalize format of filesystem representation of database objects',
  help:'Display usage information',
  init:"Save a DB server's schemas to the filesystem",
  lint:'Check for problems in filesystem representation of database objects',
  pull:'Update the filesystem representation of schemas',
  push:'Alter objects on DBs to reflect the filesystem representation',
  version:'Display program version',
};

function out(s='') { process.stdout.write(s + '\n'); }
function err(s: string) { process.stderr.write(s + '\n'); }
function stamp(): string {
  const d = new Date();
  const p = (n:number) => String(n).padStart(2,'0');
  return `${d.getUTCFullYear()}-${p(d.getUTCMonth()+1)}-${p(d.getUTCDate())} ${p(d.getUTCHours())}:${p(d.getUTCMinutes())}:${p(d.getUTCSeconds())}`;
}
function log(level: 'INFO'|'WARN'|'ERROR', msg: string) { err(`${stamp()} [${level}] ${level === 'WARN' || level === 'INFO' ? ' ' : ''}${msg}`); }
function die(msg: string, code=78): void { log('ERROR', msg); process.exit(code); }

const globalOptions = `Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version`;

function mainHelp(): string { return `
Usage:  skeema [<options>] <command>

Skeema is a declarative schema management system for MySQL and MariaDB. It
allows you to export a database schema to the filesystem, and apply online
schema changes by modifying CREATE statements in .sql files.

Commands:
      add-environment  Add a new named environment to an existing host directory
      diff             Compare a DB server's schemas to the filesystem
      format           Normalize format of filesystem representation of database objects
      help             Display usage information
      init             Save a DB server's schemas to the filesystem
      lint             Check for problems in filesystem representation of database objects
      pull             Update the filesystem representation of schemas
      push             Alter objects on DBs to reflect the filesystem representation
      version          Display program version

${globalOptions}

Complete documentation for this command suite is available online:
https://www.skeema.io/docs/commands
`; }

function commandHelp(cmd: string): string {
  if (cmd === 'version') return `
Usage:  skeema version [<options>]

Display program version

${globalOptions}

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/version
`;
  const usage: Record<string,string> = {
    init:'skeema init [<options>] [<environment>]', pull:'skeema pull [<options>] [<environment>]',
    diff:'skeema diff [<options>] [<environment>]', push:'skeema push [<options>] [<environment>]',
    lint:'skeema lint [<options>] [<environment>]', format:'skeema format [<options>] [<environment>]',
    'add-environment':'skeema add-environment [<options>] <environment>', help:'skeema [<options>] <command>'
  };
  const desc: Record<string,string> = {
    init:'Creates a filesystem representation of the schemas on a database server. For\neach schema on the DB server (or just the single schema specified by --schema),\na subdir with a .skeema config file will be created. Each directory will be\npopulated with .sql files containing CREATE statements for every table and\nroutine in the schema.',
    pull:'Updates the existing filesystem representation of the schemas on a DB server.\nUse this command when changes have been applied to the database manually or\noutside of Skeema, in order to make the filesystem representation reflect those\nchanges.',
    diff:'Compares the schemas on database server(s) to the corresponding filesystem\nrepresentation of them. The output is a series of DDL commands that, if run on\nthe DB server, would cause its schemas to now match the definitions from the\nfilesystem.\n\nThe `skeema diff` command is equivalent to running `skeema push` with its\n--dry-run option enabled.',
    push:'Modifies the schemas on database server(s) to match the corresponding filesystem\nrepresentation of them. This essentially performs the same diff logic as `skeema\ndiff`, but then actually runs the generated DDL. You should generally run\n`skeema diff` first to see what changes will be applied.',
    lint:'Checks for problems in filesystem representation of database objects. A set of\nlinter rules are run against all objects. Each rule may be configured to\ngenerate an error, a warning, or be ignored entirely. Statements that contain\ninvalid SQL, or otherwise return an error from the database, are always flagged\nas linter errors.\n\nBy default, this command also reformats CREATE statements to their canonical\nform, just like `skeema format`.',
    format:'Reformats the filesystem representation of database objects to match the\ncanonical format shown in SHOW CREATE.',
    'add-environment':'Modifies the .skeema file in an existing host directory to add a new named\nenvironment. For example, if `skeema init` was previously used to create a dir\nfor a host with the default "production" environment, `skeema add-environment`\ncould be used to define a "staging" or "development" environment pointing at a\ndifferent host and port, or perhaps a "local" environment pointing at localhost\nand a socket path.',
    help:'Display usage information'
  };
  let opts = '';
  if (cmd === 'init') opts = `Init Options:\n  -d, --dir value              Subdir name to use for this host's schemas (default "<hostname>")\n  -h, --host value             Database hostname or IP address\n      --include-auto-inc       Include starting auto-inc values in table files\n  -P, --port value             Port to use for database host (default "3306")\n      --schema value           Only import the one specified schema; skip creation of subdirs for each schema\n  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")\n      --strip-partitioning     Omit PARTITION BY clause when writing partitioned tables to filesystem`;
  else if (cmd === 'add-environment') opts = `Add-Environment Options:\n  -d, --dir value              Base dir for this host's schemas (default ".")\n  -h, --host value             Database hostname or IP address\n  -P, --port value             Port to use for database host (default "3306")\n  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")`;
  else if (cmd === 'format') opts = `Format Options:\n      --strip-partitioning         Remove PARTITION BY clauses from *.sql files\n      --[skip-]write               Update files to correct format (enabled by default; disable with --skip-write)\n\nWorkspace Options:\n      --docker-cleanup value       With --workspace=docker, specifies how to clean up containers (valid values: "none", "stop", "destroy") (default "none")\n  -t, --temp-schema value          Name of temporary schema for intermediate operations, created and dropped each run (default "_skeema_tmp")\n  -w, --workspace value            Specifies where to run intermediate operations (valid values: "temp-schema", "docker") (default "temp-schema")`;
  else if (cmd === 'lint') opts = `Format Options:\n      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)\n      --strip-partitioning         Remove PARTITION BY clauses from *.sql files\n\nLinter Rule Options:\n      --allow-auto-inc value       List of allowed auto_increment column data types for --lint-auto-inc (default "int unsigned, bigint unsigned")\n      --allow-charset value        List of allowed character sets for --lint-charset (default "latin1,utf8mb4")\n      --allow-engine value         List of allowed storage engines for --lint-engine (default "innodb")\n      --lint-pk value              Flag tables that lack a primary key (valid values: "ignore", "warning", "error") (default "warning")\n      --lint-reserved-word value   Flag names of tables, columns, or routines that used reserved words (valid values: "ignore", "warning", "error") (default "warning")\n\nWorkspace Options:\n  -t, --temp-schema value          Name of temporary schema for intermediate operations, created and dropped each run (default "_skeema_tmp")\n  -w, --workspace value            Specifies where to run intermediate operations (valid values: "temp-schema", "docker") (default "temp-schema")`;
  else opts = `External Tool Options:\n  -x, --alter-wrapper value           Output ALTER TABLEs as shell commands rather than just raw DDL; see manual for template vars\n  -X, --ddl-wrapper value             Like --alter-wrapper, but applies to all DDL types (CREATE, DROP, ALTER)\n\nSQL Generation Options:\n      --alter-algorithm value         Apply an ALGORITHM clause to all ALTER TABLEs (valid values: "inplace", "copy", "instant", "nocopy")\n      --alter-lock value              Apply a LOCK clause to all ALTER TABLEs (valid values: "none", "shared", "exclusive")\n      --exact-match                   Follow *.sql table definitions exactly, even for differences with no functional impact\n\nSafety Options:\n      --allow-unsafe                  Permit generating ALTER or DROP operations that are potentially destructive\n      --dry-run                       Output DDL but don't run it; equivalent to \`skeema diff\`\n      --[skip-]verify                 Test all generated ALTER statements on temp schema to verify correctness (enabled by default; disable with --skip-verify)\n\nWorkspace Options:\n  -w, --workspace value               Specifies where to run intermediate operations (valid values: "temp-schema", "docker") (default "temp-schema")`;
  return `
Usage:  ${usage[cmd]}

${desc[cmd]}

${opts}

${globalOptions}

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/${cmd}
`;
}

const takesValue = new Set(['-o','--connect-options','-H','--host-wrapper','--ignore-func','--ignore-proc','--ignore-schema','--ignore-table','-p','--password','--ssl-mode','-u','--user','-d','--dir','-h','--host','-P','--port','-S','--socket','--schema','-x','--alter-wrapper','--alter-wrapper-min-size','-X','--ddl-wrapper','--alter-algorithm','--alter-lock','--partitioning','--allow-auto-inc','--allow-charset','--allow-compression','--allow-definer','--allow-engine','--allow-pk-type','--lint-auto-inc','--lint-charset','--lint-compression','--lint-definer','--lint-display-width','--lint-dupe-index','--lint-engine','--lint-fk-parent','--lint-has-enum','--lint-has-fk','--lint-has-float','--lint-has-routine','--lint-has-time','--lint-name-case','--lint-pk','--lint-pk-type','--lint-reserved-word','--lint-zero-date','--safe-below-size','-c','--concurrent-servers','--docker-cleanup','-t','--temp-schema','--temp-schema-binlog','--temp-schema-mode','--temp-schema-threads','-w','--workspace']);
const flags = new Set(['--debug','--my-cnf','--skip-my-cnf','--version','-?','--help','--include-auto-inc','--strip-partitioning','--update-partitioning','--format','--skip-format','--new-schemas','--skip-new-schemas','--alter-validate-virtual','--compare-metadata','--exact-match','--lax-column-order','--lax-comments','--lint','--skip-lint','--allow-unsafe','--verify','--skip-verify','-q','--brief','-1','--first-only','--dry-run','--foreign-key-checks','--write','--skip-write']);

type Parsed = { positionals: string[], opts: Record<string,string|boolean> };
function parse(argv: string[]): Parsed {
  const positionals: string[] = []; const opts: Record<string,string|boolean> = {};
  for (let i=0;i<argv.length;i++) {
    const a = argv[i];
    if (a === '--') { positionals.push(...argv.slice(i+1)); break; }
    if (a.startsWith('--help=')) { opts['--help'] = a.slice(7); continue; }
    if (a.startsWith('--') && a.includes('=')) {
      const [k,v] = a.split(/=(.*)/s,2); if (!takesValue.has(k) && !flags.has(k)) die(`CLI: Unknown option "${k.slice(2)}"`); opts[k]=v; continue;
    }
    if (takesValue.has(a)) { if (i+1 < argv.length && !argv[i+1].startsWith('-')) opts[a]=argv[++i]; else opts[a]=''; continue; }
    if (flags.has(a)) { opts[a]=true; continue; }
    if (a.startsWith('-')) die(`CLI: Unknown option "${a.replace(/^-+/,'')}"`);
    positionals.push(a);
  }
  return {positionals, opts};
}
function hasSql(dir: string): boolean { return fs.readdirSync(dir, {withFileTypes:true}).some(d => d.isFile() && d.name.toLowerCase().endsWith('.sql')); }
function readSkeema(dir: string): Record<string,string> {
  const p = path.join(dir,'.skeema'); const ret: Record<string,string> = {};
  if (!fs.existsSync(p)) return ret;
  for (const line of fs.readFileSync(p,'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z0-9_-]+)\s*=\s*(.*?)\s*$/); if (m) ret[m[1]]=m[2];
  }
  return ret;
}
function connError(host: string, port: string, dir: string): string {
  if (host === 'localhost') return `Unable to connect to localhost:/tmp/mysql.sock for ${dir}: dial unix /tmp/mysql.sock: connect: no such file or directory`;
  return `Unable to connect to ${host}:${port || '3306'} for ${dir}: dial tcp ${host}:${port || '3306'}: connect: connection refused`;
}

function cmdFormat(cmd: 'format'|'lint', parsed: Parsed): void {
  const cwd = process.cwd();
  const write = parsed.opts['--skip-write'] ? false : true;
  if (cmd === 'format') log('INFO', `${write ? 'Reformatting' : 'Checking format of'} ${cwd}`);
  else log('INFO', `Linting ${cwd}`);
  if (!hasSql(cwd)) process.exit(0);
  const conf = readSkeema(cwd);
  if (!conf.host && !conf.flavor) {
    const msg = `This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment "production"`;
    if (cmd === 'format') die(`Skipping ${cwd}: ${msg}`);
    log('ERROR', `Skipping directory ${path.basename(cwd)} due to error: ${msg}`); log('ERROR', 'Skipped 1 operation due to fatal errors'); process.exit(78);
  }
  if (conf.host) {
    const msg = connError(conf.host, conf.port || '3306', cwd);
    if (cmd === 'format') die(`Skipping ${cwd}: ${msg}`);
    log('ERROR', `Skipping directory ${path.basename(cwd)} due to error: ${msg}`); log('ERROR','Skipped 1 operation due to fatal errors'); process.exit(78);
  }
  process.exit(0);
}

function cmdAddEnv(parsed: Parsed): void {
  const pos = parsed.positionals;
  if (pos.length < 1) die('Too few positional args supplied on command line; command add-environment requires at least 1 args');
  if (pos.length > 1) die(`Extra command-line arg "${pos[1]}" supplied; command add-environment takes a max of 1 args`);
  const env = pos[0]; const dir = String(parsed.opts['-d'] || parsed.opts['--dir'] || '.');
  const host = String(parsed.opts['-h'] || parsed.opts['--host'] || '');
  const port = String(parsed.opts['-P'] || parsed.opts['--port'] || '3306');
  if (!host) die('`skeema add-environment` requires --host to be supplied on command-line');
  const file = path.resolve(dir,'.skeema');
  let content = fs.existsSync(file) ? fs.readFileSync(file,'utf8').replace(/\s*$/,'') : '';
  content += `\n\n[${env}]\nhost=${host}\nport=${port}\n`;
  fs.writeFileSync(file, content);
  log('WARN', `Unable to automatically determine database server's vendor/version. To set manually, use the "flavor" option in ${file}`);
  log('INFO', `Added environment [${env}] to ${file}`);
}

function cmdInit(parsed: Parsed): void {
  const pos = parsed.positionals;
  if (pos.length > 1) die(`Extra command-line arg "${pos[1]}" supplied; command init takes a max of 1 args`);
  const host = String(parsed.opts['-h'] || parsed.opts['--host'] || '');
  if (!host) die('Option --host must be supplied on the command-line');
  const dirOpt = parsed.opts['-d'] || parsed.opts['--dir']; const dir = path.resolve(String(dirOpt || host));
  log('ERROR', connError(host, String(parsed.opts['-P'] || parsed.opts['--port'] || '3306'), dir)); process.exit(2);
}

function main() {
  const argv = process.argv.slice(2);
  const parsed = parse(argv);
  if (parsed.opts['--version']) { out(VERSION); return; }
  let pos = parsed.positionals;
  if (parsed.opts['--help']) {
    const target = typeof parsed.opts['--help'] === 'string' && parsed.opts['--help'] ? String(parsed.opts['--help']) : (pos[0] || '');
    out(target && commands.includes(target) ? commandHelp(target) : mainHelp()); return;
  }
  if (pos.length === 0) { out(mainHelp()); return; }
  let cmd = pos[0];
  if (cmd === 'help') { const target = pos[1]; if (target === 'version') { out(VERSION); return; } out(target && commands.includes(target) ? commandHelp(target) : mainHelp()); return; }
  if (!commands.includes(cmd)) die(`Unknown command "${cmd}"`);
  parsed.positionals = pos.slice(1);
  if (argv.includes('--help') || argv.includes('-?')) { out(commandHelp(cmd)); return; }
  switch (cmd) {
    case 'version': out(VERSION); return;
    case 'format': cmdFormat('format', parsed); return;
    case 'lint': cmdFormat('lint', parsed); return;
    case 'add-environment': cmdAddEnv(parsed); return;
    case 'init': cmdInit(parsed); return;
    case 'diff': case 'push': case 'pull': return;
  }
}
main();
