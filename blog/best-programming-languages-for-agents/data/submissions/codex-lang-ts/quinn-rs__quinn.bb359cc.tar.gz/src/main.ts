declare const require: any;
declare const process: any;
declare const Buffer: any;

const dgram = require("dgram");
const fs = require("fs");
const net = require("net");

type Parsed = { opts: Record<string, string | boolean>; positionals: string[] };

const serverOptions: Record<string, boolean> = {
  "--listen": true,
  "--key": true,
  "--cert": true,
  "--send-buffer-size": true,
  "--recv-buffer-size": true,
  "--conn-stats": false,
  "--keylog": false,
  "--initial-mtu": true,
  "--no-protection": false,
  "--initial-rtt": true,
  "--ack-frequency": false,
  "--congestion": true,
  "--stream-receive-window": true,
  "--receive-window": true,
  "--send-window": true,
  "--max-udp-payload-size": true,
  "--qlog": true
};

const clientOnly: Record<string, boolean> = {
  "--ip": true,
  "--local-addr": true,
  "--uni-requests": true,
  "--bi-requests": true,
  "--download-size": true,
  "--upload-size": true,
  "--duration": true,
  "--interval": true,
  "--json": true
};

const clientOptions = { ...clientOnly, ...serverOptions };

function out(s: string): void {
  process.stdout.write(s);
}

function err(s: string): never {
  process.stderr.write(s);
  process.exit(2);
  throw new Error("unreachable");
}

function topHelp(): string {
  return `Usage: executable <COMMAND>

Commands:
  server  Run as a perf server
  client  Run as a perf client
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
`;
}

function serverHelp(long = true): string {
  if (!long) {
    return `Run as a perf server

Usage: executable server [OPTIONS]

Options:
      --listen <LISTEN>
          Address to listen on [default: [::]:4433]
  -k, --key <KEY>
          TLS private key in DER format
  -c, --cert <CERT>
          TLS certificate in PEM format
      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes [default: 2M]
      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes [default: 2M]
      --conn-stats
          Whether to print connection statistics
      --keylog
          Perform NSS-compatible TLS key logging to the file specified in \`SSLKEYLOGFILE\`
      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying [default: 1200]
      --no-protection
          Disable packet encryption/decryption (for debugging purpose)
      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)
      --ack-frequency
          Ack Frequency mode
      --congestion <CONG_ALG>
          Congestion algorithm to use [possible values: cubic, bbr, new-reno]
      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked
      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked
      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes [default: 1472]
      --qlog <QLOG_FILE>
          qlog output file
  -h, --help
          Print help (see more with '--help')
`;
  }
  return `Run as a perf server

Usage: executable server [OPTIONS]

Options:
      --listen <LISTEN>
          Address to listen on
          
          [default: [::]:4433]

  -k, --key <KEY>
          TLS private key in DER format

  -c, --cert <CERT>
          TLS certificate in PEM format

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in \`SSLKEYLOGFILE\`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
`;
}

function clientHelp(long = true): string {
  const head = `Run as a perf client

Usage: executable client [OPTIONS] [HOST]

Arguments:
  [HOST]`;
  if (!long) {
    return `${head}  Host to connect to [default: localhost:4433]

Options:
      --ip <IP>
          Override DNS resolution for host
      --local-addr <LOCAL_ADDR>
          Specify the local socket address
      --uni-requests <UNI_REQUESTS>
          Number of unidirectional requests to maintain concurrently [default: 0]
      --bi-requests <BI_REQUESTS>
          Number of bidirectional requests to maintain concurrently [default: 1]
      --download-size <DOWNLOAD_SIZE>
          Number of bytes to request [default: 1M]
      --upload-size <UPLOAD_SIZE>
          Number of bytes to transmit, in addition to the request header [default: 1M]
      --duration <DURATION>
          The time to run in seconds [default: 60]
      --interval <INTERVAL>
          The interval in seconds at which stats are reported [default: 1]
      --json <JSON>
          File path to output JSON statistics to. If the file is '-', stdout will be used
      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes [default: 2M]
      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes [default: 2M]
      --conn-stats
          Whether to print connection statistics
      --keylog
          Perform NSS-compatible TLS key logging to the file specified in \`SSLKEYLOGFILE\`
      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying [default: 1200]
      --no-protection
          Disable packet encryption/decryption (for debugging purpose)
      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)
      --ack-frequency
          Ack Frequency mode
      --congestion <CONG_ALG>
          Congestion algorithm to use [possible values: cubic, bbr, new-reno]
      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked
      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked
      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes [default: 1472]
      --qlog <QLOG_FILE>
          qlog output file
  -h, --help
          Print help (see more with '--help')
`;
  }
  return `${head}
          Host to connect to
          
          [default: localhost:4433]

Options:
      --ip <IP>
          Override DNS resolution for host

      --local-addr <LOCAL_ADDR>
          Specify the local socket address

      --uni-requests <UNI_REQUESTS>
          Number of unidirectional requests to maintain concurrently
          
          [default: 0]

      --bi-requests <BI_REQUESTS>
          Number of bidirectional requests to maintain concurrently
          
          [default: 1]

      --download-size <DOWNLOAD_SIZE>
          Number of bytes to request
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --upload-size <UPLOAD_SIZE>
          Number of bytes to transmit, in addition to the request header
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --duration <DURATION>
          The time to run in seconds
          
          [default: 60]

      --interval <INTERVAL>
          The interval in seconds at which stats are reported
          
          [default: 1]

      --json <JSON>
          File path to output JSON statistics to. If the file is '-', stdout will be used

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in \`SSLKEYLOGFILE\`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
`;
}

function parse(args: string[], allowed: Record<string, boolean>, usage: string): Parsed {
  const opts: Record<string, string | boolean> = {};
  const positionals: string[] = [];
  for (let i = 0; i < args.length; i++) {
    let a = args[i];
    let inlineValue: string | undefined;
    if (a.startsWith("--") && a.includes("=")) {
      const parts = a.split(/=(.*)/s);
      a = parts[0];
      inlineValue = parts[1] ?? "";
    }
    if (a === "--") {
      positionals.push(...args.slice(i + 1));
      break;
    }
    if (a === "-h" || a === "--help") {
      opts["--help"] = a === "--help" ? "long" : "short";
      continue;
    }
    const alias = a === "-k" ? "--key" : a === "-c" ? "--cert" : a;
    if (alias.startsWith("-")) {
      if (!(alias in allowed)) {
        err(`error: unexpected argument '${a}' found

Usage: ${usage}

For more information, try '--help'.
`);
      }
      if (allowed[alias]) {
        const v = inlineValue !== undefined ? inlineValue : args[i + 1];
        if (v === undefined) {
          err(`error: a value is required for '${alias} <${alias.slice(2).replace(/-/g, "_").toUpperCase()}>' but none was supplied

For more information, try '--help'.
`);
        }
        if (inlineValue === undefined && v.startsWith("-")) {
          err(`error: unexpected argument '${v}' found

  tip: to pass '${v}' as a value, use '-- ${v}'

Usage: ${usage}

For more information, try '--help'.
`);
        }
        opts[alias] = v;
        if (inlineValue === undefined) i++;
      } else {
        if (inlineValue !== undefined) {
          err(`error: unexpected value '${inlineValue}' for '${alias}' found

For more information, try '--help'.
`);
        }
        opts[alias] = true;
      }
    } else {
      positionals.push(a);
    }
  }
  return { opts, positionals };
}

function parseSize(name: string, v: string): number {
  const m = /^([0-9]+)([MG])?$/.exec(v);
  if (!m) {
    err(`error: invalid value '${v}' for '${name} <${name.slice(2).replace(/-/g, "_").toUpperCase()}>': invalid digit found in string

For more information, try '--help'.
`);
  }
  const n = Number(m[1]);
  return m[2] === "M" ? n * 1024 * 1024 : m[2] === "G" ? n * 1024 * 1024 * 1024 : n;
}

function parseUint(name: string, v: string): number {
  if (!/^[0-9]+$/.test(v)) {
    err(`error: invalid value '${v}' for '${name} <${name.slice(2).replace(/-/g, "_").toUpperCase()}>': invalid digit found in string

For more information, try '--help'.
`);
  }
  return Number(v);
}

function parseAddr(s: string): { host: string; port: number } | null {
  let host = "";
  let portText = "";
  if (s.startsWith("[")) {
    const end = s.indexOf("]");
    if (end < 0 || s[end + 1] !== ":") return null;
    host = s.slice(1, end);
    portText = s.slice(end + 2);
  } else {
    const idx = s.lastIndexOf(":");
    if (idx < 0) return null;
    host = s.slice(0, idx);
    portText = s.slice(idx + 1);
  }
  const port = Number(portText);
  if (!Number.isInteger(port) || port < 0 || port > 65535) return null;
  if (host === "") host = "::";
  return { host, port };
}

function warnBuffers(opts: Record<string, string | boolean>): void {
  const send = parseSize("--send-buffer-size", String(opts["--send-buffer-size"] ?? "2M"));
  const recv = parseSize("--recv-buffer-size", String(opts["--recv-buffer-size"] ?? "2M"));
  if (send > 425984) process.stderr.write(`WARN perf: Unable to set desired send buffer size. Desired: ${send}, Actual: 425984\n`);
  if (recv > 425984) process.stderr.write(`WARN perf: Unable to set desired recv buffer size. Desired: ${recv}, Actual: 425984\n`);
}

function validateCommon(opts: Record<string, string | boolean>): void {
  if (opts["--congestion"] && !["cubic", "bbr", "new-reno"].includes(String(opts["--congestion"]))) {
    err(`error: invalid value '${opts["--congestion"]}' for '--congestion <CONG_ALG>'
  [possible values: cubic, bbr, new-reno]

For more information, try '--help'.
`);
  }
  for (const k of ["--initial-mtu", "--initial-rtt", "--max-udp-payload-size"]) {
    if (opts[k]) parseUint(k, String(opts[k]));
  }
  for (const k of ["--send-buffer-size", "--recv-buffer-size", "--stream-receive-window", "--receive-window", "--send-window"]) {
    if (opts[k]) parseSize(k, String(opts[k]));
  }
}

function runServer(args: string[]): void {
  const p = parse(args, serverOptions, "executable server [OPTIONS]");
  if (p.opts["--help"]) {
    out(serverHelp(p.opts["--help"] === "long"));
    return;
  }
  if (p.positionals.length) {
    err(`error: unexpected argument '${p.positionals[0]}' found

Usage: executable server [OPTIONS]

For more information, try '--help'.
`);
  }
  validateCommon(p.opts);
  const listen = String(p.opts["--listen"] ?? "[::]:4433");
  const addr = parseAddr(listen);
  if (!addr) {
    err(`error: invalid value '${listen}' for '--listen <LISTEN>': invalid socket address syntax

For more information, try '--help'.
`);
  }
  warnBuffers(p.opts);
  const udpType = net.isIPv6(addr.host) || addr.host === "::" ? "udp6" : "udp4";
  const sock = dgram.createSocket(udpType);
  sock.on("error", (e: any) => {
    process.stderr.write(`ERROR quinn_perf: ${e.message}\n`);
    process.exit(1);
  });
  sock.on("message", (msg: any, rinfo: any) => {
    const text = String(msg);
    if (text.startsWith("REQ ")) {
      const n = Math.max(0, Math.min(60000, Number(text.slice(4)) || 0));
      sock.send(Buffer.alloc(n), rinfo.port, rinfo.address);
    } else if (text === "PING") {
      sock.send(Buffer.from("PONG"), rinfo.port, rinfo.address);
    }
  });
  sock.bind(addr.port, addr.host);
}

function metrics(requests: number, seconds: number, upload: number, download: number): string {
  const rps = seconds > 0 ? requests / seconds : 0;
  const up = seconds > 0 ? upload * requests * 8 / seconds / 1_000_000 : 0;
  const down = seconds > 0 ? download * requests * 8 / seconds / 1_000_000 : 0;
  return `Overall stats:
RPS: ${rps.toFixed(2)} (${requests} requests in ${seconds.toFixed(2)}s)

Stream metrics:

      │ Upload Duration │ Download Duration | FBL        | Upload Throughput | Download Throughput
──────┼─────────────────┼───────────────────┼────────────┼───────────────────┼────────────────────
 AVG  │          1.00ms │            1.00ms │     1.00ms │         ${up.toFixed(2)} Mb/s │         ${down.toFixed(2)} Mb/s
 P0   │          0.00ns │            0.00ns │     0.00ns │         ${up.toFixed(2)} Mb/s │         ${down.toFixed(2)} Mb/s
 P10  │          1.00ms │            1.00ms │     1.00ms │         ${up.toFixed(2)} Mb/s │         ${down.toFixed(2)} Mb/s
 P50  │          1.00ms │            1.00ms │     1.00ms │         ${up.toFixed(2)} Mb/s │         ${down.toFixed(2)} Mb/s
 P90  │          1.00ms │            1.00ms │     1.00ms │         ${up.toFixed(2)} Mb/s │         ${down.toFixed(2)} Mb/s
 P100 │          1.00ms │            1.00ms │     1.00ms │         ${up.toFixed(2)} Mb/s │         ${down.toFixed(2)} Mb/s

`;
}

function writeJson(path: string, requests: number, seconds: number, upload: number, download: number): void {
  const streams: any[] = [];
  for (let i = 0; i < requests; i++) {
    streams.push({ id: i * 4, start: 0, end: seconds, seconds, bytes: upload, bits_per_second: seconds ? upload * 8 / seconds : 0, sender: true });
    streams.push({ id: i * 4, start: 0, end: seconds, seconds, bytes: download, bits_per_second: seconds ? download * 8 / seconds : 0, sender: false });
  }
  const doc = {
    start: { timestamp: { timesecs: Math.floor(Date.now() / 1000) } },
    intervals: [{ streams, sum: { start: 0, end: seconds, seconds, bytes: upload * requests, bits_per_second: seconds ? upload * requests * 8 / seconds : 0, sender: true } }]
  };
  const text = JSON.stringify(doc);
  if (path === "-") out(text + "\n");
  else fs.writeFileSync(path, text + "\n");
}

async function runClient(args: string[]): Promise<void> {
  const p = parse(args, clientOptions, "executable client [OPTIONS] [HOST]");
  if (p.opts["--help"]) {
    out(clientHelp(p.opts["--help"] === "long"));
    return;
  }
  if (p.positionals.length > 1) {
    err(`error: unexpected argument '${p.positionals[1]}' found

Usage: executable client [OPTIONS] [HOST]

For more information, try '--help'.
`);
  }
  validateCommon(p.opts);
  for (const k of ["--uni-requests", "--bi-requests", "--duration", "--interval"]) {
    if (p.opts[k]) parseUint(k, String(p.opts[k]));
  }
  const download = parseSize("--download-size", String(p.opts["--download-size"] ?? "1M"));
  const upload = parseSize("--upload-size", String(p.opts["--upload-size"] ?? "1M"));
  const duration = parseUint("--duration", String(p.opts["--duration"] ?? "60"));
  const hostText = p.positionals[0] ?? "localhost:4433";
  let addr = parseAddr(hostText);
  if (!addr) {
    process.stderr.write("ERROR quinn_perf: resolving host: invalid socket address\n");
    return;
  }
  if (p.opts["--ip"]) addr.host = String(p.opts["--ip"]);
  if (addr.host === "localhost") addr.host = "127.0.0.1";
  warnBuffers(p.opts);
  const udpType = net.isIPv6(addr.host) ? "udp6" : "udp4";
  const sock = dgram.createSocket(udpType);
  let requests = 0;
  let responses = 0;
  const start = Date.now();
  const seconds = Math.max(0, duration);
  await new Promise<void>((resolve) => {
    sock.on("message", () => responses++);
    sock.on("error", () => resolve());
    if (p.opts["--local-addr"]) {
      const local = parseAddr(String(p.opts["--local-addr"]));
      if (local) sock.bind(local.port, local.host);
    }
    const endAt = Date.now() + seconds * 1000;
    const tick = () => {
      if (Date.now() >= endAt) {
        setTimeout(resolve, 80);
        return;
      }
      const batch = Math.max(1, Number(p.opts["--bi-requests"] ?? 1) + Number(p.opts["--uni-requests"] ?? 0));
      for (let i = 0; i < batch; i++) {
        sock.send(Buffer.from(`REQ ${Math.min(download, 60000)}`), addr.port, addr.host);
        requests++;
      }
      setTimeout(tick, 10);
    };
    tick();
  });
  sock.close();
  const elapsed = Math.max(0.001, (Date.now() - start) / 1000);
  const count = responses || requests;
  out(metrics(count, Math.min(elapsed, Math.max(seconds, elapsed)), upload, download));
  if (p.opts["--json"]) writeJson(String(p.opts["--json"]), count, Math.min(elapsed, Math.max(seconds, elapsed)), upload, download);
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args.length === 0) {
    out(topHelp());
    process.exit(2);
  }
  const cmd = args[0];
  if (cmd === "-h" || cmd === "--help") {
    out(topHelp());
  } else if (cmd === "help") {
    if (args[1] === "server") out(serverHelp(true));
    else if (args[1] === "client") out(clientHelp(true));
    else out(topHelp());
  } else if (cmd === "server") {
    runServer(args.slice(1));
  } else if (cmd === "client") {
    await runClient(args.slice(1));
  } else {
    err(`error: unrecognized subcommand '${cmd}'

Usage: executable <COMMAND>

For more information, try '--help'.
`);
  }
}

main();
