declare const require: any;
declare const process: any;
declare const Buffer: any;

const http = require("http");
const https = require("https");

type Options = {
  accepted: string;
  bufferSize: number;
  maxConnections: number;
  maxConnectionsPerHost: number;
  maxResponseBodySize: number;
  excludes: RegExp[];
  includes: RegExp[];
  followRobots: boolean;
  followSitemap: boolean;
  headers: Record<string, string>;
  ignoreFragments: boolean;
  maxRetries: number;
  dnsResolver?: string;
  format: "text" | "json" | "junit";
  maxRedirections: number;
  rateLimit?: number;
  timeout: number;
  verbose: boolean;
  proxy?: string;
  skipTlsVerification: boolean;
  onePageOnly: boolean;
  color: string;
  root?: string;
};

type FetchResult = {
  url: string;
  status: number;
  body: string;
  headers: Record<string, any>;
  finalUrl: string;
};

type LinkResult = {
  url: string;
  status?: number;
  error?: string;
};

type PageResult = {
  url: string;
  links: LinkResult[];
};

const HELP = `Usage:
  executable [options] <url>

Application Options:
      --accepted-status-codes=<codes>       Accepted HTTP response status codes
                                            (e.g. '200..300,403') (default:
                                            200..300)
  -b, --buffer-size=<size>                  HTTP response buffer size in bytes
                                            (default: 4096)
  -c, --max-connections=<count>             Maximum number of HTTP connections
                                            (default: 512)
      --max-connections-per-host=<count>    Maximum number of HTTP connections
                                            per host (default: 512)
      --max-response-body-size=<size>       Maximum response body size to read
                                            (default: 10000000)
  -e, --exclude=<pattern>...                Exclude URLs matched with given
                                            regular expressions
  -i, --include=<pattern>...                Include URLs matched with given
                                            regular expressions
      --follow-robots-txt                   Follow robots.txt when scraping
                                            pages
      --follow-sitemap-xml                  Scrape only pages listed in
                                            sitemap.xml (deprecated)
      --header=<header>...                  Custom headers
  -f, --ignore-fragments                    Ignore URL fragments
      --max-retries=<count>                 Maximum retry count for network
                                            errors (default: 0)
      --dns-resolver=<address>              Custom DNS resolver
      --format=[text|json|junit]            Output format (default: text)
      --json                                Output results in JSON (deprecated)
      --experimental-verbose-json           Include successful results in JSON
                                            (deprecated)
      --junit                               Output results as JUnit XML file
                                            (deprecated)
  -r, --max-redirections=<count>            Maximum number of redirections
                                            (default: 64)
      --rate-limit=<rate>                   Max requests per second
  -t, --timeout=<seconds>                   Timeout for HTTP requests in
                                            seconds (default: 10)
  -v, --verbose                             Show successful results too
      --proxy=<host>                        HTTP proxy host
      --skip-tls-verification               Skip TLS certificate verification
      --one-page-only                       Only check links found in the given
                                            URL
      --color=[auto|always|never]           Color output (default: auto)
  -h, --help                                Show this help
      --version                             Show version`;

function defaultOptions(): Options {
  return {
    accepted: "200..300",
    bufferSize: 4096,
    maxConnections: 512,
    maxConnectionsPerHost: 512,
    maxResponseBodySize: 10000000,
    excludes: [],
    includes: [],
    followRobots: false,
    followSitemap: false,
    headers: {},
    ignoreFragments: false,
    maxRetries: 0,
    format: "text",
    maxRedirections: 64,
    timeout: 10,
    verbose: false,
    skipTlsVerification: false,
    onePageOnly: false,
    color: "auto",
  };
}

function fail(message: string): never {
  console.error(message);
  process.exit(1);
  throw new Error(message);
}

function parseArgs(argv: string[]): Options | null {
  const opts = defaultOptions();
  const positional: string[] = [];

  const takesValue: Record<string, keyof Options | "header" | "include" | "exclude"> = {
    "accepted-status-codes": "accepted",
    "buffer-size": "bufferSize",
    "max-connections": "maxConnections",
    "max-connections-per-host": "maxConnectionsPerHost",
    "max-response-body-size": "maxResponseBodySize",
    "exclude": "exclude",
    "include": "include",
    "header": "header",
    "max-retries": "maxRetries",
    "dns-resolver": "dnsResolver",
    "format": "format",
    "max-redirections": "maxRedirections",
    "rate-limit": "rateLimit",
    "timeout": "timeout",
    "proxy": "proxy",
    "color": "color",
  };
  const short: Record<string, string> = {
    b: "buffer-size",
    c: "max-connections",
    e: "exclude",
    i: "include",
    r: "max-redirections",
    t: "timeout",
  };

  function setValue(name: string, value: string) {
    const key = takesValue[name];
    if (!key) fail(`unknown flag \`${name}\``);
    if (key === "include") opts.includes.push(new RegExp(value));
    else if (key === "exclude") opts.excludes.push(new RegExp(value));
    else if (key === "header") {
      const i = value.indexOf(":");
      if (i >= 0) opts.headers[value.slice(0, i).trim()] = value.slice(i + 1).trim();
    } else if (key === "format") {
      if (value !== "text" && value !== "json" && value !== "junit") fail(`invalid argument for flag \`format'`);
      opts.format = value;
    } else if (["accepted", "dnsResolver", "proxy", "color"].includes(key as string)) {
      (opts as any)[key] = value;
    } else {
      (opts as any)[key] = Number(value);
    }
  }

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") {
      console.log(HELP);
      return null;
    }
    if (arg === "--version") {
      console.log("2.11.1");
      return null;
    }
    if (arg === "--json") {
      opts.format = "json";
      continue;
    }
    if (arg === "--junit") {
      opts.format = "junit";
      continue;
    }
    if (arg === "--experimental-verbose-json") continue;
    if (arg === "--follow-robots-txt") {
      opts.followRobots = true;
      continue;
    }
    if (arg === "--follow-sitemap-xml") {
      opts.followSitemap = true;
      continue;
    }
    if (arg === "--ignore-fragments" || arg === "-f") {
      opts.ignoreFragments = true;
      continue;
    }
    if (arg === "--verbose" || arg === "-v") {
      opts.verbose = true;
      continue;
    }
    if (arg === "--skip-tls-verification") {
      opts.skipTlsVerification = true;
      continue;
    }
    if (arg === "--one-page-only") {
      opts.onePageOnly = true;
      continue;
    }
    if (arg.startsWith("--")) {
      const raw = arg.slice(2);
      const eq = raw.indexOf("=");
      const name = eq >= 0 ? raw.slice(0, eq) : raw;
      const key = takesValue[name];
      if (!key) fail(`unknown flag \`${name}\``);
      const value = eq >= 0 ? raw.slice(eq + 1) : argv[++i];
      if (value == null) fail(`expected argument for flag \`${name}'`);
      setValue(name, value);
      continue;
    }
    if (arg.startsWith("-") && arg.length > 1) {
      const s = arg.slice(1);
      const name = short[s[0]];
      if (!name) fail(`unknown flag \`${s[0]}\``);
      const value = s.length > 1 ? s.slice(1) : argv[++i];
      if (value == null) fail(`expected argument for flag \`${s[0]}'`);
      setValue(name, value);
      continue;
    }
    positional.push(arg);
  }
  if (positional.length !== 1) fail("invalid number of arguments");
  opts.root = positional[0];
  return opts;
}

function acceptedChecker(spec: string): (code: number) => boolean {
  const parts = spec.split(",").map((x) => x.trim()).filter(Boolean);
  return (code: number) => {
    for (const part of parts) {
      const m = part.match(/^(\d+)\.\.(\d+)$/);
      if (m && code >= Number(m[1]) && code < Number(m[2])) return true;
      if (/^\d+$/.test(part) && code === Number(part)) return true;
    }
    return false;
  };
}

function normalizeUrl(raw: string, base?: string): string | null {
  try {
    const u = base ? new URL(raw, base) : new URL(raw);
    if (!["http:", "https:"].includes(u.protocol)) return null;
    return u.href;
  } catch {
    return null;
  }
}

function withoutHash(url: string): string {
  const u = new URL(url);
  u.hash = "";
  return u.href;
}

function sameOrigin(a: string, b: string): boolean {
  return new URL(a).origin === new URL(b).origin;
}

function contentType(headers: Record<string, any>): string {
  return String(headers["content-type"] || "").toLowerCase();
}

function decodeEntities(s: string): string {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, "\"")
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
}

function extractLinks(html: string, base: string): string[] {
  const attrs = ["href", "src", "action", "poster", "data", "cite"];
  const out: string[] = [];
  const seen = new Set<string>();
  for (const attr of attrs) {
    const re = new RegExp(`\\b${attr}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, "gi");
    let m: RegExpExecArray | null;
    while ((m = re.exec(html))) {
      const raw = decodeEntities((m[1] ?? m[2] ?? m[3] ?? "").trim());
      if (!raw || raw.startsWith("javascript:") || raw.startsWith("mailto:") || raw.startsWith("tel:") || raw.startsWith("data:")) continue;
      const url = normalizeUrl(raw, base);
      if (url && !seen.has(url)) {
        seen.add(url);
        out.push(url);
      }
    }
  }
  return out;
}

function idsIn(html: string): Set<string> {
  const ids = new Set<string>();
  const re = /\b(?:id|name)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) ids.add(decodeEntities(m[1] ?? m[2] ?? m[3] ?? ""));
  return ids;
}

function xmlEscape(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function fetchUrl(url: string, opts: Options, redirectsLeft: number): Promise<FetchResult> {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === "https:" ? https : http;
    const reqOpts: any = {
      method: "GET",
      headers: { "User-Agent": "muffet", ...opts.headers },
      timeout: opts.timeout * 1000,
      rejectUnauthorized: !opts.skipTlsVerification,
    };
    const req = lib.request(u, reqOpts, (res: any) => {
      const status = Number(res.statusCode || 0);
      if ([301, 302, 303, 307, 308].includes(status) && res.headers.location && redirectsLeft > 0) {
        res.resume();
        const next = normalizeUrl(res.headers.location, url);
        if (next) {
          fetchUrl(next, opts, redirectsLeft - 1).then(resolve, reject);
          return;
        }
      }
      const chunks: any[] = [];
      let size = 0;
      res.on("data", (chunk: any) => {
        size += chunk.length;
        if (size <= opts.maxResponseBodySize) chunks.push(chunk);
      });
      res.on("end", () => {
        resolve({
          url,
          status,
          body: Buffer.concat(chunks).toString("utf8"),
          headers: res.headers,
          finalUrl: url,
        });
      });
    });
    req.on("timeout", () => req.destroy(new Error("timeout")));
    req.on("error", (err: any) => reject(err));
    req.end();
  });
}

async function fetchWithRetries(url: string, opts: Options): Promise<FetchResult> {
  let last: any;
  for (let i = 0; i <= opts.maxRetries; i++) {
    try {
      return await fetchUrl(url, opts, opts.maxRedirections);
    } catch (e) {
      last = e;
    }
  }
  throw last;
}

function networkError(e: any, url: string): string {
  const msg = e && e.message ? String(e.message) : String(e);
  const u = new URL(url);
  return `error when dialing ${u.host}: ${msg}`;
}

function filterLink(url: string, opts: Options): boolean {
  if (opts.includes.length && !opts.includes.some((r) => r.test(url))) return false;
  if (opts.excludes.some((r) => r.test(url))) return false;
  return true;
}

async function allowedByRobots(root: string, opts: Options): Promise<(url: string) => boolean> {
  if (!opts.followRobots) return () => true;
  try {
    const robotsUrl = new URL("/robots.txt", root).href;
    const r = await fetchWithRetries(robotsUrl, opts);
    const disallow: string[] = [];
    for (const line of r.body.split(/\r?\n/)) {
      const m = line.match(/^\s*Disallow\s*:\s*(.*?)\s*$/i);
      if (m && m[1]) disallow.push(m[1]);
    }
    return (url: string) => {
      const path = new URL(url).pathname;
      return !disallow.some((d) => d !== "" && path.startsWith(d));
    };
  } catch {
    return () => true;
  }
}

async function sitemapUrls(root: string, opts: Options): Promise<string[]> {
  if (!opts.followSitemap) return [];
  try {
    const sm = await fetchWithRetries(new URL("/sitemap.xml", root).href, opts);
    const urls: string[] = [];
    const re = /<loc>\s*([^<]+?)\s*<\/loc>/gi;
    let m: RegExpExecArray | null;
    while ((m = re.exec(sm.body))) {
      const u = normalizeUrl(decodeEntities(m[1]));
      if (u) urls.push(u);
    }
    return urls;
  } catch {
    return [];
  }
}

async function crawl(root: string, opts: Options): Promise<PageResult[]> {
  const isAccepted = acceptedChecker(opts.accepted);
  const collectAllLinks = opts.verbose || opts.format === "junit";
  const rootUrl = normalizeUrl(root);
  if (!rootUrl) fail("failed to parse url");
  const rootFetch = await fetchWithRetries(rootUrl, opts).catch((e) => {
    fail(`failed to fetch root page: ${networkError(e, rootUrl)}`);
  });
  if (!isAccepted(rootFetch.status)) fail(`failed to fetch root page: ${rootFetch.status}`);

  const allow = await allowedByRobots(rootUrl, opts);
  const pageBodies = new Map<string, string>();
  const pageIds = new Map<string, Set<string>>();
  const results: PageResult[] = [];
  const queued = new Set<string>();
  const seenPages = new Set<string>();
  const queue: string[] = [];

  async function cachePage(url: string, fetched?: FetchResult): Promise<FetchResult> {
    const r = fetched || await fetchWithRetries(url, opts);
    if (isAccepted(r.status) && contentType(r.headers).includes("html")) {
      pageBodies.set(withoutHash(url), r.body);
      pageIds.set(withoutHash(url), idsIn(r.body));
    }
    return r;
  }

  await cachePage(rootUrl, rootFetch);
  if (opts.followSitemap) {
    for (const u of await sitemapUrls(rootUrl, opts)) {
      if (sameOrigin(u, rootUrl) && allow(u) && !queued.has(withoutHash(u))) {
        queued.add(withoutHash(u));
        queue.push(withoutHash(u));
      }
    }
  } else {
    queue.push(withoutHash(rootUrl));
    queued.add(withoutHash(rootUrl));
  }

  const linkCache = new Map<string, Promise<LinkResult>>();

  async function checkLink(url: string): Promise<LinkResult> {
    if (!opts.ignoreFragments && new URL(url).hash) {
      const base = withoutHash(url);
      try {
        if (!pageBodies.has(base)) await cachePage(base);
        const hash = decodeURIComponent(new URL(url).hash.slice(1));
        if (!pageIds.get(base)?.has(hash)) return { url, error: `id #${hash} not found` };
        return { url, status: 200 };
      } catch (e) {
        return { url, error: networkError(e, base) };
      }
    }
    const base = withoutHash(url);
    try {
      const r = await fetchWithRetries(base, opts);
      if (!isAccepted(r.status)) return { url, error: String(r.status) };
      if (sameOrigin(base, rootUrl) && !opts.onePageOnly && contentType(r.headers).includes("html") && allow(base) && !queued.has(base)) {
        queued.add(base);
        queue.push(base);
      }
      return { url, status: r.status };
    } catch (e) {
      return { url, error: networkError(e, base) };
    }
  }

  while (queue.length) {
    const pageUrl = queue.shift()!;
    if (seenPages.has(pageUrl) || !allow(pageUrl)) continue;
    seenPages.add(pageUrl);
    let pageBody = pageBodies.get(pageUrl);
    if (pageBody == null) {
      try {
        const r = await cachePage(pageUrl);
        if (!isAccepted(r.status) || !contentType(r.headers).includes("html")) continue;
        pageBody = r.body;
      } catch {
        continue;
      }
    }
    const links = extractLinks(pageBody, pageUrl).filter((u) => filterLink(u, opts));
    const page: PageResult = { url: pageUrl, links: [] };
    for (const link of links) {
      const key = opts.ignoreFragments ? withoutHash(link) : link;
      if (!linkCache.has(key)) linkCache.set(key, checkLink(link));
      const res = await linkCache.get(key)!;
      if (collectAllLinks || res.error) page.links.push(res);
    }
    if (collectAllLinks || page.links.some((l) => l.error)) results.push(page);
  }
  return results;
}

function emitText(results: PageResult[], verbose: boolean) {
  for (const page of results) {
    const links = verbose ? page.links : page.links.filter((l) => l.error);
    if (!verbose && links.length === 0) continue;
    console.log(page.url);
    for (const link of links) console.log(`\t${link.error ?? link.status}\t${link.url}`);
  }
}

function emitJson(results: PageResult[], verbose: boolean) {
  const out = results
    .map((p) => ({ url: p.url, links: verbose ? p.links : p.links.filter((l) => l.error) }))
    .filter((p) => verbose || p.links.length);
  console.log(JSON.stringify(out));
}

function emitJunit(results: PageResult[]) {
  console.log(`<?xml version="1.0" encoding="UTF-8"?>`);
  console.log(`<testsuites>`);
  for (const page of results) {
    const failures = page.links.filter((l) => l.error).length;
    console.log(`  <testsuite name="${xmlEscape(page.url)}" tests="${page.links.length}" failures="${failures}" skipped="0">`);
    for (const link of page.links) {
      console.log(`    <testcase name="${xmlEscape(link.url)}" classname="${xmlEscape(page.url)}">${link.error ? "" : "</testcase>"}`);
      if (link.error) {
        console.log(`      <failure message="${xmlEscape(link.error)}"></failure>`);
        console.log(`    </testcase>`);
      }
    }
    console.log(`  </testsuite>`);
  }
  console.log(`</testsuites>`);
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (!opts) return;
  const results = await crawl(opts.root!, opts);
  const failed = results.some((p) => p.links.some((l) => l.error));
  if (opts.format === "json") emitJson(results, opts.verbose);
  else if (opts.format === "junit") emitJunit(results);
  else emitText(results, opts.verbose);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => fail(String(e && e.message ? e.message : e)));
