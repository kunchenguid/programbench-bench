declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");
const readline = require("readline");

type Tok = { raw: string; norm: string; line: number; col: number };
type Region = {
  file: string;
  startLine: number;
  endLine: number;
  startTok: number;
  endTok: number;
  key: string;
  score: number;
};

const usage = `Usage: dupl [flags] [paths]

Paths:
  If the given path is a file, dupl will use it regardless of
  the file extension. If it is a directory, it will recursively
  search for *.go files in that directory.

  If no path is given, dupl will recursively search for *.go
  files in the current directory.

Flags:
  -files
    \tread file names from stdin one at each line
  -html
    \toutput the results as HTML, including duplicate code fragments
  -plumbing
    \tplumbing (easy-to-parse) output for consumption by scripts or tools
  -t, -threshold size
    \tminimum token sequence size as a clone (default 15)
  -vendor
    \tcheck files in vendor directory
  -v, -verbose
    \texplain what is being done

Examples:
  dupl -t 100
    \tSearch clones in the current directory of size at least
    \t100 tokens.
  dupl $(find app/ -name '*_test.go')
    \tSearch for clones in tests in the app directory.
  find app/ -name '*_test.go' |dupl -files
    \tThe same as above.`;

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) {
    console.error(usage);
    process.exit(2);
  }
  if (opts.error) {
    console.error(opts.error);
    console.error(usage);
    process.exit(2);
  }
  run(opts).catch((err) => {
    console.error(err && err.message ? err.message : String(err));
    process.exit(1);
  });
}

function parseArgs(args: string[]) {
  const opts: any = {
    threshold: 15,
    filesMode: false,
    html: false,
    plumbing: false,
    vendor: false,
    verbose: false,
    paths: [] as string[],
    help: false,
    error: "",
  };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--help" || a === "-h") opts.help = true;
    else if (a === "-files") opts.filesMode = true;
    else if (a === "-html") opts.html = true;
    else if (a === "-plumbing") opts.plumbing = true;
    else if (a === "-vendor") opts.vendor = true;
    else if (a === "-v" || a === "-verbose") opts.verbose = true;
    else if (a === "-t" || a === "-threshold") {
      const n = args[++i];
      if (!n || !/^\d+$/.test(n)) opts.error = `invalid value "${n || ""}" for flag -threshold: parse error`;
      else opts.threshold = parseInt(n, 10);
    } else if (a.startsWith("-threshold=")) {
      opts.threshold = parseInt(a.slice("-threshold=".length), 10);
    } else if (a.startsWith("-t=")) {
      opts.threshold = parseInt(a.slice(3), 10);
    } else if (a.startsWith("-")) {
      opts.error = `flag provided but not defined: ${a}`;
    } else {
      opts.paths.push(a);
    }
  }
  return opts;
}

async function run(opts: any) {
  let files: string[] = [];
  if (opts.filesMode) files = await stdinLines();
  else files = collectFiles(opts.paths.length ? opts.paths : ["."], opts.vendor);
  files = files.filter(Boolean);

  if (opts.verbose) log("Building suffix tree");
  const regions: Region[] = [];
  for (const f of files) {
    try {
      const text = fs.readFileSync(f, "utf8");
      regions.push(...regionsForFile(f, text, opts.threshold));
    } catch (e: any) {
      log(`${f}: ${e.message}`);
    }
  }
  if (opts.verbose) log("Searching for clones");
  const groups = findGroups(regions, opts.threshold);
  if (opts.html) printHtml(groups);
  else if (opts.plumbing) printPlumbing(groups);
  else printText(groups);
}

function log(msg: string) {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  const stamp = `${d.getUTCFullYear()}/${pad(d.getUTCMonth() + 1)}/${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
  console.error(`${stamp} ${msg}`);
}

async function stdinLines(): Promise<string[]> {
  const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
  const out: string[] = [];
  for await (const line of rl) out.push(line.trim());
  return out;
}

function collectFiles(inputs: string[], includeVendor: boolean): string[] {
  const out: string[] = [];
  for (const p0 of inputs) {
    const p = path.resolve(p0);
    if (!fs.existsSync(p)) continue;
    const st = fs.statSync(p);
    if (st.isFile()) out.push(p);
    else if (st.isDirectory()) walk(p, includeVendor, out);
  }
  return out.sort();
}

function walk(dir: string, includeVendor: boolean, out: string[]) {
  for (const ent of fs.readdirSync(dir).sort()) {
    const p = path.join(dir, ent);
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      if (!includeVendor && ent === "vendor") continue;
      walk(p, includeVendor, out);
    } else if (st.isFile() && ent.endsWith(".go")) out.push(p);
  }
}

function lex(src: string): Tok[] {
  const toks: Tok[] = [];
  let i = 0, line = 1, col = 1;
  const adv = (n = 1) => {
    while (n-- > 0) {
      if (src[i] === "\n") { line++; col = 1; } else col++;
      i++;
    }
  };
  const add = (raw: string, norm: string, l: number, c: number) => toks.push({ raw, norm, line: l, col: c });
  const keywords = new Set("break default func interface select case defer go map struct chan else goto package switch const fallthrough if range type continue for import return var".split(" "));
  const two = new Set(["++", "--", ":=", "==", "!=", "<=", ">=", "&&", "||", "<<", ">>", "&^", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "...", "<-"]);
  while (i < src.length) {
    const ch = src[i];
    if (/\s/.test(ch)) { adv(); continue; }
    if (ch === "/" && src[i + 1] === "/") { while (i < src.length && src[i] !== "\n") adv(); continue; }
    if (ch === "/" && src[i + 1] === "*") { adv(2); while (i < src.length && !(src[i] === "*" && src[i + 1] === "/")) adv(); if (i < src.length) adv(2); continue; }
    const l = line, c = col;
    if (/[A-Za-z_]/.test(ch)) {
      let s = "";
      while (i < src.length && /[A-Za-z0-9_]/.test(src[i])) { s += src[i]; adv(); }
      add(s, keywords.has(s) ? s : "IDENT", l, c);
      continue;
    }
    if (/[0-9]/.test(ch)) {
      let s = "";
      while (i < src.length && /[A-Za-z0-9_.]/.test(src[i])) { s += src[i]; adv(); }
      add(s, "LIT", l, c);
      continue;
    }
    if (ch === '"' || ch === "'" || ch === "`") {
      const q = ch; let s = ch; adv();
      while (i < src.length) {
        const cur = src[i]; s += cur; adv();
        if (q !== "`" && cur === "\\" && i < src.length) { s += src[i]; adv(); continue; }
        if (cur === q) break;
      }
      add(s, "LIT", l, c);
      continue;
    }
    const tri = src.slice(i, i + 3), duo = src.slice(i, i + 2);
    if (two.has(tri)) { add(tri, tri, l, c); adv(3); }
    else if (two.has(duo)) { add(duo, duo, l, c); adv(2); }
    else { add(ch, ch, l, c); adv(); }
  }
  return toks;
}

function regionsForFile(file: string, text: string, threshold: number): Region[] {
  const toks = lex(text);
  const regs: Region[] = [];
  const add = (s: number, e: number, bonus = 0) => {
    if (e < s) return;
    const len = e - s + 1;
    if (len < threshold) return;
    const key = toks.slice(s, e + 1).map(t => t.norm).join(" ");
    regs.push({ file, startLine: toks[s].line, endLine: toks[e].line, startTok: s, endTok: e, key, score: len + bonus });
  };
  if (toks.length >= threshold) add(0, toks.length - 1, 200);
  for (let i = 0; i < toks.length; i++) {
    if (toks[i].norm === "func") {
      const b = findNext(toks, i, "{");
      if (b >= 0) {
        const e = matchBrace(toks, b);
        if (e >= 0) add(i, e, 100);
      }
    }
    if (toks[i].norm === "{") {
      const e = matchBrace(toks, i);
      if (e >= 0) add(i, e, 20);
    }
  }
  // Add line-oriented statement windows for small thresholds.
  const byLine = new Map<number, [number, number]>();
  toks.forEach((t, idx) => {
    const cur = byLine.get(t.line);
    byLine.set(t.line, cur ? [cur[0], idx] : [idx, idx]);
  });
  const lines = [...byLine.keys()].sort((a, b) => a - b);
  for (let a = 0; a < lines.length; a++) {
    for (let b = a; b < Math.min(lines.length, a + 5); b++) {
      const s = byLine.get(lines[a])![0], e = byLine.get(lines[b])![1];
      add(s, e, 0);
    }
  }
  return regs;
}

function findNext(toks: Tok[], start: number, norm: string): number {
  for (let i = start; i < toks.length; i++) if (toks[i].norm === norm) return i;
  return -1;
}

function matchBrace(toks: Tok[], open: number): number {
  let d = 0;
  for (let i = open; i < toks.length; i++) {
    if (toks[i].norm === "{") d++;
    else if (toks[i].norm === "}") {
      d--;
      if (d === 0) return i;
    }
  }
  return -1;
}

function findGroups(regions: Region[], threshold: number): Region[][] {
  const map = new Map<string, Region[]>();
  for (const r of regions) {
    const arr = map.get(r.key) || [];
    arr.push(r); map.set(r.key, arr);
  }
  let groups = [...map.values()].map(g => {
    const seen = new Set<string>();
    const uniq: Region[] = [];
    for (const r of g.sort((a, b) => b.score - a.score || regionCmp(a, b))) {
      const k = `${r.file}:${r.startLine}:${r.endLine}`;
      if (!seen.has(k)) { seen.add(k); uniq.push(r); }
    }
    return uniq.sort(regionCmp);
  }).filter(g => g.length > 1);
  groups.sort((a, b) => Math.max(...b.map(r => r.score)) - Math.max(...a.map(r => r.score)) || regionCmp(a[0], b[0]));
  const selected: Region[] = [];
  const out: Region[][] = [];
  for (const g of groups) {
    const swallowed = g.every(r => selected.some(s =>
      s.file === r.file && s.startLine <= r.startLine && s.endLine >= r.endLine &&
      (s.startLine !== r.startLine || s.endLine !== r.endLine || s.score >= r.score)
    ));
    if (!swallowed) {
      out.push(g);
      selected.push(...g);
    }
  }
  return out.sort((a, b) => regionCmp(a[0], b[0]));
}

function regionCmp(a: Region, b: Region) {
  return a.file.localeCompare(b.file) || a.startLine - b.startLine || a.endLine - b.endLine;
}

function printText(groups: Region[][]) {
  for (const g of groups) {
    console.log(`found ${g.length} clones:`);
    for (const r of g) console.log(`  ${r.file}:${r.startLine},${r.endLine}`);
  }
  console.log("");
  console.log(`Found total ${groups.length} clone groups.`);
}

function printPlumbing(groups: Region[][]) {
  for (const g of groups) {
    for (let i = 0; i < g.length; i++) {
      const a = g[i], b = g[(i + 1) % g.length];
      console.log(`${a.file}:${a.startLine}-${a.endLine}: duplicate of ${b.file}:${b.startLine}-${b.endLine}`);
    }
  }
}

function printHtml(groups: Region[][]) {
  console.log(`<!DOCTYPE html>
<meta charset="utf-8"/>
<title>Duplicates</title>
<style>
\tpre {
\t\tbackground-color: #FFD;
\t\tborder: 1px solid #E2E2E2;
\t\tpadding: 1ex;
\t}
</style>`);
  groups.forEach((g, idx) => {
    console.log(`<h1>#${idx + 1} found ${g.length} clones</h1>`);
    for (const r of g) {
      console.log(`<h2>${escapeHtml(r.file)}:${r.startLine}</h2>`);
      console.log(`<pre>${escapeHtml(snippet(r))}</pre>`);
    }
  });
}

function snippet(r: Region): string {
  const lines = fs.readFileSync(r.file, "utf8").split(/\r?\n/);
  return lines.slice(r.startLine - 1, r.endLine).join("\n");
}

function escapeHtml(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

main();
