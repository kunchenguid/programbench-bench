#!/usr/bin/env node

declare const require: any;
declare const process: any;

const fs = require("fs");
const os = require("os");
const path = require("path");

type Config = {
  backend_type: string;
  scroll_per_page: number;
  sync_os_clipboard: boolean;
  history_limit: number;
  colored_tags: boolean;
  datum_visibility: string;
  app_state_dir: string;
  export: { path?: string; show_confirmation: boolean };
  external_editor: { command?: string; args?: string[]; auto_save: boolean; temp_file_extension: string };
  json_backend: { file_path: string };
  sqlite_backend: { file_path: string };
};

const VERSION = "tui-journal 0.16.1";
const DEFAULT_THEME = `[general.input_block_active]
fg = "LightYellow"
modifiers = ""

[general.input_block_invalid]
fg = "LightRed"
modifiers = ""

[general.input_corsur_active]
fg = "Black"
bg = "LightYellow"
modifiers = ""

[general.input_corsur_invalid]
fg = "Black"
bg = "LightRed"
modifiers = ""

[general.list_item_selected]
fg = "LightYellow"
modifiers = "BOLD"

[general.list_highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[general.list_highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = ""

[journals_list.block_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.block_inactive]
fg = "#AAAAC8"
modifiers = ""

[journals_list.block_multi_select]
fg = "Yellow"
modifiers = "BOLD | ITALIC"

[journals_list.highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = "BOLD"

[journals_list.highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = "BOLD"

[journals_list.title_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.title_inactive]
fg = "#AAAAC8"
modifiers = "BOLD"

[journals_list.title_selected]
fg = "Yellow"
modifiers = "BOLD"

[journals_list.date_priority]
fg = "LightBlue"
modifiers = ""

[journals_list.tags_default]
fg = "LightCyan"
modifiers = "DIM"

[editor.block_insert]
fg = "LightGreen"
modifiers = "BOLD"

[editor.block_visual]
fg = "Blue"
modifiers = "BOLD"

[editor.block_normal_active]
fg = "Reset"
modifiers = "BOLD"

[editor.block_normal_inactive]
fg = "#AAAAC8"
modifiers = ""

[editor.cursor_normal]
fg = "Black"
bg = "White"
modifiers = ""

[editor.cursor_insert]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[editor.cursor_visual]
fg = "Black"
bg = "Blue"
modifiers = ""

[editor.selection_style]
fg = "Black"
bg = "White"
modifiers = ""

[msgbox]
error = "LightRed"
warning = "Yellow"
info = "LightGreen"
question = "LightBlue"

`;

function home(): string {
  return process.env.HOME || os.homedir() || "/home/agent";
}

function defaultConfig(): Config {
  const h = home();
  return {
    backend_type: "Sqlite",
    scroll_per_page: 5,
    sync_os_clipboard: false,
    history_limit: 10,
    colored_tags: true,
    datum_visibility: "show",
    app_state_dir: path.join(h, ".local/state/tui-journal"),
    export: { show_confirmation: true },
    external_editor: { auto_save: false, temp_file_extension: "txt" },
    json_backend: { file_path: path.join(h, "tui-journal/entries.json") },
    sqlite_backend: { file_path: path.join(h, "tui-journal/entries.db") },
  };
}

function mainHelp(): string {
  return `Tui app allows writing and managing journals/notes from within the terminal With different local back-ends

Usage: executable [OPTIONS] [COMMAND]

Commands:
  print-config     Print the current settings including the paths for the back-end files [aliases: pc]
  import-journals  Import journals from the given transfer JSON file to the current back-end file [aliases: imj]
  assign-priority  Assign priority for all the entries with empty priority field [aliases: ap]
  theme            Provides commands regarding changing themes and styles of the app [aliases: style]
  help             Print this message or the help of the given subcommand(s)

Options:
  -j, --json-file-path <FILE PATH>    Sets the entries Json file path and starts using it
  -s, --sqlite-file-path <FILE PATH>  Sets the entries sqlite file path and starts using it
  -b, --backend-type <BACKEND_TYPE>   Sets the backend type and starts using it [possible values: json, sqlite]
  -c, --config <DIR PATH>             Specifies the path for the configuration directory.
                                      Configuration files is considered as root for themes file too.
                                      It still accepts the path for configuration file for backward compatibility.
                                      (default path: /home/agent/.config/tui-journal)
  -v, --verbose...                    Increases logging verbosity each use for up to 3 times
  -l, --log <FILE PATH>               Specifies a file to use for logging
                                      (default file: /home/agent/.cache/tui-journal/tui-journal.log)
  -h, --help                          Print help
  -V, --version                       Print version`;
}

function themeHelp(): string {
  return `Provides commands regarding changing themes and styles of the app

Usage: executable theme <COMMAND>

Commands:
  print-path      Prints the path to the user themes file [aliases: path]
  print-default   Dumps the styles with the default values to be used as a reference and base for user custom themes [aliases: default]
  write-defaults  Creates user custom themes file if doesn't exist then writes the default styles to it [aliases: write]
  help            Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help`;
}

const SUB_HELP: Record<string, string> = {
  "print-config": `Print the current settings including the paths for the back-end files

Usage: executable print-config

Options:
  -h, --help  Print help`,
  "import-journals": `Import journals from the given transfer JSON file to the current back-end file

Usage: executable import-journals --path <FILE PATH>

Options:
  -p, --path <FILE PATH>  Path of the JSON file to import from
  -h, --help              Print help`,
  "assign-priority": `Assign priority for all the entries with empty priority field

Usage: executable assign-priority <PRIORITY>

Arguments:
  <PRIORITY>  Priority value (Positive number)

Options:
  -h, --help  Print help`,
  "theme print-path": `Prints the path to the user themes file

Usage: executable theme print-path

Options:
  -h, --help  Print help`,
  "theme write-defaults": `Creates user custom themes file if doesn't exist then writes the default styles to it

Usage: executable theme write-defaults

Options:
  -h, --help  Print help`,
};

function stripQuotes(s: string): string {
  const t = s.trim();
  if (t.startsWith('"') && t.endsWith('"')) return t.slice(1, -1);
  return t;
}

function parseScalar(s: string): any {
  const t = s.trim();
  if (t === "true") return true;
  if (t === "false") return false;
  if (/^-?\d+$/.test(t)) return Number(t);
  if (t.startsWith("[") && t.endsWith("]")) {
    const inner = t.slice(1, -1).trim();
    if (!inner) return [];
    return inner.split(",").map(stripQuotes);
  }
  return stripQuotes(t);
}

function readConfig(configDir: string | undefined): { cfg: Config; dir: string } {
  const cfg = defaultConfig();
  let dir = configDir || path.join(home(), ".config/tui-journal");
  let file = path.join(dir, "config.toml");
  if (configDir && !fs.existsSync(configDir)) {
    throw new Error(`Provided custom directory doesn't exit. Path: ${configDir}`);
  }
  if (configDir && fs.existsSync(configDir) && fs.statSync(configDir).isFile()) {
    file = configDir;
    dir = path.dirname(configDir);
  }
  if (fs.existsSync(file)) {
    let section = "";
    for (const raw of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
      const line = raw.replace(/#.*$/, "").trim();
      if (!line) continue;
      const msec = line.match(/^\[([^\]]+)\]$/);
      if (msec) {
        section = msec[1];
        continue;
      }
      const eq = line.indexOf("=");
      if (eq < 0) continue;
      const key = line.slice(0, eq).trim();
      const val = parseScalar(line.slice(eq + 1));
      const target: any = section ? (cfg as any)[section] : cfg;
      if (target && key in target) target[key] = val;
    }
  }
  return { cfg, dir };
}

function printConfig(cfg: Config) {
  const lines = [
    `backend_type = "${cfg.backend_type}"`,
    `scroll_per_page = ${cfg.scroll_per_page}`,
    `sync_os_clipboard = ${cfg.sync_os_clipboard}`,
    `history_limit = ${cfg.history_limit}`,
    `colored_tags = ${cfg.colored_tags}`,
    `datum_visibility = "${cfg.datum_visibility}"`,
    `app_state_dir = "${cfg.app_state_dir}"`,
    "",
    "[export]",
  ];
  if (cfg.export.path) lines.push(`path = "${cfg.export.path}"`);
  lines.push(`show_confirmation = ${cfg.export.show_confirmation}`, "", "[external_editor]");
  if (cfg.external_editor.command) lines.push(`command = "${cfg.external_editor.command}"`);
  lines.push(`auto_save = ${cfg.external_editor.auto_save}`);
  lines.push(`temp_file_extension = "${cfg.external_editor.temp_file_extension}"`, "", "[json_backend]");
  lines.push(`file_path = "${cfg.json_backend.file_path}"`, "", "[sqlite_backend]");
  lines.push(`file_path = "${cfg.sqlite_backend.file_path}"`, "");
  process.stdout.write(lines.join("\n"));
}

function loadJsonFile(file: string): any {
  if (!fs.existsSync(file)) return [];
  const txt = fs.readFileSync(file, "utf8").trim();
  if (!txt) return [];
  return JSON.parse(txt);
}

function normalizeCollection(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (data && Array.isArray(data.journals)) return data.journals;
  if (data && Array.isArray(data.entries)) return data.entries;
  return [];
}

function saveLike(original: any, items: any[], file: string) {
  let out: any = items;
  if (original && !Array.isArray(original)) {
    out = { ...original };
    if (Array.isArray(original.journals)) out.journals = items;
    else if (Array.isArray(original.entries)) out.entries = items;
    else out.entries = items;
  }
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(out, null, 2));
}

function importJournals(cfg: Config, importPath: string): void {
  if (cfg.backend_type.toLowerCase() !== "json") {
    console.error("Error: SQLite backend is not supported by this reimplementation");
    process.exit(1);
  }
  const src = loadJsonFile(importPath);
  const dest = loadJsonFile(cfg.json_backend.file_path);
  const merged = [...normalizeCollection(dest), ...normalizeCollection(src)];
  saveLike(dest, merged, cfg.json_backend.file_path);
}

function assignPriority(cfg: Config, priority: number) {
  if (cfg.backend_type.toLowerCase() !== "json") {
    console.error("Error: SQLite backend is not supported by this reimplementation");
    process.exit(1);
  }
  const original = loadJsonFile(cfg.json_backend.file_path);
  const items = normalizeCollection(original);
  for (const item of items) {
    if (item && typeof item === "object" && (item.priority === undefined || item.priority === null || item.priority === "")) {
      item.priority = priority;
    }
  }
  saveLike(original, items, cfg.json_backend.file_path);
}

function clapError(message: string, usage: string): never {
  console.error(`error: ${message}\n\nUsage: ${usage}\n\nFor more information, try '--help'.`);
  process.exit(2);
  throw new Error("unreachable");
}

function run() {
  const args = process.argv.slice(2);
  let configDir: string | undefined;
  let jsonPath: string | undefined;
  let sqlitePath: string | undefined;
  let backendType: string | undefined;
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    const next = () => args[++i];
    if (a === "-h" || a === "--help") {
      console.log(mainHelp());
      return;
    } else if (a === "-V" || a === "--version") {
      console.log(VERSION);
      return;
    } else if (a === "-c" || a === "--config") {
      configDir = next();
    } else if (a === "-j" || a === "--json-file-path") {
      jsonPath = next();
    } else if (a === "-s" || a === "--sqlite-file-path") {
      sqlitePath = next();
    } else if (a === "-b" || a === "--backend-type") {
      backendType = next();
      if (!["json", "sqlite"].includes((backendType || "").toLowerCase())) {
        console.error(`error: invalid value '${backendType}' for '--backend-type <BACKEND_TYPE>'
  [possible values: json, sqlite]

For more information, try '--help'.`);
        process.exit(2);
      }
    } else if (a === "-v" || a === "--verbose" || a.startsWith("-v")) {
      continue;
    } else if (a === "-l" || a === "--log") {
      i++;
    } else {
      rest.push(a);
    }
  }

  let cfg: Config;
  let dir: string;
  try {
    const r = readConfig(configDir);
    cfg = r.cfg;
    dir = r.dir;
  } catch (e: any) {
    console.error(`Error: ${e.message}`);
    process.exit(1);
  }
  if (jsonPath) cfg.json_backend.file_path = jsonPath;
  if (sqlitePath) cfg.sqlite_backend.file_path = sqlitePath;
  if (backendType) cfg.backend_type = backendType.toLowerCase() === "json" ? "Json" : "Sqlite";

  if (rest.length === 0) {
    console.error("Error: No such device or address (os error 6)");
    process.exit(1);
  }

  const cmd = rest[0];
  if (cmd === "help") {
    const topic = rest.slice(1);
    if (topic[0] === "theme" && topic[1]) console.log(SUB_HELP[`theme ${canonicalTheme(topic[1])}`] || themeHelp());
    else if (topic[0] === "theme") console.log(themeHelp());
    else if (topic[0]) console.log(SUB_HELP[canonical(topic[0])] || mainHelp());
    else console.log(mainHelp());
    return;
  }
  if (["print-config", "pc"].includes(cmd)) {
    if (rest.includes("-h") || rest.includes("--help")) console.log(SUB_HELP["print-config"]);
    else printConfig(cfg);
    return;
  }
  if (["import-journals", "imj"].includes(cmd)) {
    if (rest.includes("-h") || rest.includes("--help")) {
      console.log(SUB_HELP["import-journals"]);
      return;
    }
    let p = "";
    for (let i = 1; i < rest.length; i++) if (rest[i] === "-p" || rest[i] === "--path") p = rest[++i];
    if (!p) clapError("the following required arguments were not provided:\n  --path <FILE PATH>", "executable import-journals --path <FILE PATH>");
    importJournals(cfg, p);
    return;
  }
  if (["assign-priority", "ap"].includes(cmd)) {
    if (rest.includes("-h") || rest.includes("--help")) {
      console.log(SUB_HELP["assign-priority"]);
      return;
    }
    const pri = rest[1];
    if (!pri) clapError("the following required arguments were not provided:\n  <PRIORITY>", "executable assign-priority <PRIORITY>");
    const n = Number(pri);
    if (!Number.isFinite(n) || n < 0) clapError(`invalid value '${pri}' for '<PRIORITY>'`, "executable assign-priority <PRIORITY>");
    assignPriority(cfg, n);
    return;
  }
  if (["theme", "style"].includes(cmd)) {
    const sub = canonicalTheme(rest[1] || "");
    if (!sub || rest[1] === "help" || rest.includes("-h") || rest.includes("--help")) {
      console.log(sub && SUB_HELP[`theme ${sub}`] ? SUB_HELP[`theme ${sub}`] : themeHelp());
      return;
    }
    if (sub === "print-path") {
      console.log(path.join(dir, "themes.toml"));
      return;
    }
    if (sub === "print-default") {
      process.stdout.write(DEFAULT_THEME);
      return;
    }
    if (sub === "write-defaults") {
      fs.mkdirSync(dir, { recursive: true });
      const file = path.join(dir, "themes.toml");
      fs.writeFileSync(file, DEFAULT_THEME);
      console.log(`Default themes have been written to ${file}`);
      return;
    }
    clapError(`unrecognized subcommand '${rest[1]}'`, "executable theme <COMMAND>");
  }
  clapError(`unrecognized subcommand '${cmd}'`, "executable [OPTIONS] [COMMAND]");
}

function canonical(s: string): string {
  if (s === "pc") return "print-config";
  if (s === "imj") return "import-journals";
  if (s === "ap") return "assign-priority";
  return s;
}

function canonicalTheme(s: string): string {
  if (s === "path") return "print-path";
  if (s === "default") return "print-default";
  if (s === "write") return "write-defaults";
  return s;
}

run();
