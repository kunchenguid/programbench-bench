declare const require: any;
declare const process: any;

const fs = require("fs");
const path = require("path");

for (const stream of [process.stdout, process.stderr]) {
  stream.on("error", (e: any) => {
    if (e && e.code === "EPIPE") process.exit(0);
    throw e;
  });
}

type Cmd = { name: string; desc: string; aliases?: string[] };

const warning =
  "WARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\n" +
  "The project reserves the right to modify, rename, reorganize, and change the behavior of the utility\n" +
  "until it is officially frozen in a future feature release of GDAL.";

const version = "GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20";

const top: Cmd[] = [
  { name: "convert", desc: "Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert')." },
  { name: "dataset", desc: "Commands to manage datasets." },
  { name: "driver", desc: "Command for driver specific operations." },
  { name: "info", desc: "Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info')." },
  { name: "mdim", desc: "Multidimensional commands." },
  { name: "pipeline", desc: "Process a dataset applying several steps." },
  { name: "raster", desc: "Raster commands." },
  { name: "vector", desc: "Vector commands." },
  { name: "vsi", desc: "GDAL Virtual System Interface (VSI) commands." },
];

const dataset: Cmd[] = [
  { name: "check", desc: "Check whether there are errors when reading the content of a dataset." },
  { name: "copy", desc: "Copy files of a dataset.", aliases: ["cp"] },
  { name: "delete", desc: "Delete dataset(s).", aliases: ["rm", "remove"] },
  { name: "identify", desc: "Identify driver opening dataset(s)." },
  { name: "rename", desc: "Rename files of a dataset.", aliases: ["ren", "mv"] },
];
const vsi: Cmd[] = [
  { name: "copy", desc: "Copy files located on GDAL Virtual System Interface (VSI).", aliases: ["cp"] },
  { name: "delete", desc: "Delete files located on GDAL Virtual System Interface (VSI).", aliases: ["rm", "rmdir", "del"] },
  { name: "list", desc: "List files of one of the GDAL Virtual System Interface (VSI).", aliases: ["ls"] },
  { name: "move", desc: "Move/rename a file/directory located on GDAL Virtual System Interface (VSI).", aliases: ["mv", "ren", "rename"] },
  { name: "sozip", desc: "Seek-optimized ZIP (SOZIP) commands." },
  { name: "sync", desc: "Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI)." },
];
const raster: Cmd[] = [
  ["as-features","Create features from pixels of a raster dataset"],["aspect","Generate an aspect map"],["blend","Blend/compose two raster datasets"],["calc","Perform raster algebra"],["clean-collar","Clean the collar of a raster dataset, removing noise."],["clip","Clip a raster dataset."],["color-map","Generate a RGB or RGBA dataset from a single band, using a color map"],["compare","Compare two raster datasets."],["contour","Creates a vector contour from a raster elevation model (DEM)."],["convert","Convert a raster dataset."],["create","Create a new raster dataset."],["edit","Edit a raster dataset."],["fill-nodata","Fill nodata raster regions by interpolation from edges."],["footprint","Compute the footprint of a raster dataset."],["hillshade","Generate a shaded relief map"],["index","Create a vector index of raster datasets."],["info","Return information on a raster dataset."],["mosaic","Build a mosaic, either virtual (VRT) or materialized."],["neighbors","Compute the value of each pixel from its neighbors (focal statistics)"],["nodata-to-alpha","Replace nodata value(s) with an alpha band."],["overview","Manage overviews of a raster dataset."],["pansharpen","Perform a pansharpen operation."],["pipeline","Process a raster dataset applying several steps."],["pixel-info","Return information on a pixel of a raster dataset."],["polygonize","Create a polygon feature dataset from a raster band."],["proximity","Produces a raster proximity map."],["reclassify","Reclassify values in a raster dataset"],["reproject","Reproject a raster dataset."],["resize","Resize a raster dataset without changing the georeferenced extents."],["rgb-to-palette","Convert a RGB image into a pseudo-color / paletted image."],["roughness","Generate a roughness map"],["scale","Scale the values of the bands of a raster dataset."],["select","Select a subset of bands from a raster dataset."],["set-type","Modify the data type of bands of a raster dataset."],["sieve","Remove small polygons from a raster dataset."],["slope","Generate a slope map"],["stack","Combine together input bands into a multi-band output, either virtual (VRT) or materialized."],["tile","Generate tiles in separate files from a raster dataset."],["tpi","Generate a Topographic Position Index (TPI) map"],["tri","Generate a Terrain Ruggedness Index (TRI) map"],["unscale","Convert scaled values of a raster dataset into unscaled values."],["update","Update the destination raster with the content of the input one."],["viewshed","Compute the viewshed of a raster dataset."],["zonal-stats","Calculate raster zonal statistics"]
].map(([name, desc]) => ({ name, desc }));
raster.find(c => c.name === "neighbors")!.aliases = ["neighbours"];
const vector: Cmd[] = [
  ["buffer","Compute a buffer around geometries of a vector dataset."],["check-coverage","Check a polygon coverage for validity"],["check-geometry","Check a dataset for invalid geometries"],["clean-coverage","Alter polygon boundaries to make shared edges identical, removing gaps and overlaps"],["clip","Clip a vector dataset."],["combine","Combine features into collections"],["concat","Concatenate vector datasets."],["concave-hull","Compute the concave hull of geometries of a vector dataset."],["convert","Convert a vector dataset."],["convex-hull","Compute the convex hull of geometries of a vector dataset."],["create","Create a vector dataset."],["dissolve","Dissolves multipart features"],["edit","Edit metadata of a vector dataset."],["explode-collections","Explode geometries of type collection of a vector dataset."],["export-schema","Export the OGR_SCHEMA from a vector dataset."],["filter","Filter a vector dataset."],["grid","Create a regular grid from scattered points."],["index","Create a vector index of vector datasets."],["info","Return information on a vector dataset."],["layer-algebra","Perform algebraic operation between 2 layers."],["make-point","Create point geometries from attribute fields"],["make-valid","Fix validity of geometries of a vector dataset."],["partition","Partition a vector dataset into multiple files."],["pipeline","Process a vector dataset applying several steps."],["rasterize","Burns vector geometries into a raster."],["rename-layer","Rename layer(s) of a vector dataset."],["reproject","Reproject a vector dataset."],["segmentize","Segmentize geometries of a vector dataset."],["select","Select a subset of fields from a vector dataset."],["set-field-type","Modify the type of a field of a vector dataset."],["set-geom-type","Modify the geometry type of a vector dataset."],["simplify","Simplify geometries of a vector dataset."],["simplify-coverage","Simplify shared boundaries of a polygonal vector dataset."],["sort","Spatially order the features in a layer"],["sql","Apply SQL statement(s) to a dataset."],["swap-xy","Swap X and Y coordinates of geometries of a vector dataset."],["update","Update an existing vector dataset with an input vector dataset."]
].map(([name, desc]) => ({ name, desc }));

function out(s = "") { process.stdout.write(s + (s.endsWith("\n") ? "" : "\n")); }
function err(s = "") { process.stderr.write(s + (s.endsWith("\n") ? "" : "\n")); }
function has(a: string[], ...xs: string[]) { return xs.some(x => a.includes(x)); }
function stripCommon(a: string[]) {
  const r: string[] = [];
  for (let i = 0; i < a.length; i++) {
    if (a[i] === "--config") i++;
    else if (a[i].startsWith("--config=")) {}
    else r.push(a[i]);
  }
  return r;
}
function alias(list: Cmd[], n: string) { return list.find(c => c.name === n || c.aliases?.includes(n)); }
function padName(c: Cmd, w: number) {
  let name = c.name;
  if (c.aliases?.length) name += ` (alias: ${c.aliases.join(", ")})`;
  return `  - ${name}:${" ".repeat(Math.max(1, w - name.length))}${c.desc}`;
}
function common(includeQuiet = false) {
  return `Common Options:
  -h, --help${" ".repeat(14)}Display help message and exit
  --json-usage${" ".repeat(12)}Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]` + (includeQuiet ? `\n  -q, --quiet${" ".repeat(13)}Quiet mode (no progress bar or warning message)` : "");
}
function subHelp(name: string, list: Cmd[], url: string, extra = "") {
  const width = Math.max(...list.map(c => c.name.length + (c.aliases?.length ? 10 + c.aliases.join(", ").length : 0))) + 1;
  return `Usage: gdal ${name} <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
${list.map(c => padName(c, width)).join("\n")}

${common()}${extra ? "\n\n" + extra : ""}

For more details, consult ${url}

${warning}`;
}
function topHelp(tryHelp = false) {
  return `Usage: gdal <COMMAND> [OPTIONS]
where <COMMAND> is one of:
${top.map(c => padName(c, 9)).join("\n")}

${common()}
${tryHelp ? "\nTry 'gdal --help' for help.\n" : ""}
'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.
And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.

For more details, consult https://gdal.org/programs/index.html

${warning}`;
}
const helps: Record<string,string> = {
  "convert": `Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>

Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').

Positional arguments:
  -i, --input <INPUT>                                  Input raster, vector or multidimensional raster dataset [required]
  -o, --output <OUTPUT>                                Output raster, vector or multidimensional raster dataset (created by algorithm) [required]

${common(true)}

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format

For all options, run 'gdal raster convert --help' or 'gdal vector convert --help'

For more details, consult https://gdal.org/programs/gdal_convert.html

${warning}`,
  "info": `Usage: gdal info [OPTIONS] <INPUT>

Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input raster, vector or multidimensional raster dataset [required]

${common()}

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text

For all options, run 'gdal raster info --help' or 'gdal vector info --help'

For more details, consult https://gdal.org/programs/gdal_info.html

${warning}`,
  "raster info": `Usage: gdal raster info [OPTIONS] <INPUT>

Return information on a raster dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input raster dataset [required]

${common()}

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  --mm, --min-max                                      Compute minimum and maximum value
  --stats                                              Retrieve or compute statistics, using all pixels
  --approx-stats                                       Retrieve or compute statistics, using a subset of pixels
  --hist                                               Retrieve or compute histogram

Advanced Options:
  --if, --input-format <INPUT-FORMAT>                  Input formats [may be repeated]
  --oo, --open-option <KEY>=<VALUE>                    Open options [may be repeated]

For more details, consult https://gdal.org/programs/gdal_raster_info.html

${warning}`,
  "raster convert": `Usage: gdal raster convert [OPTIONS] <INPUT> <OUTPUT>

Convert a raster dataset.

Positional arguments:
  -i, --input <INPUT>                                  Input raster datasets [required]
  -o, --output <OUTPUT>                                Output raster dataset [required]

${common(true)}

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format ("GDALG" allowed)
  --co, --creation-option <KEY>=<VALUE>                Creation option [may be repeated]
  --overwrite                                          Whether overwriting existing output dataset is allowed
  --append                                             Append as a subdataset to existing output

For more details, consult https://gdal.org/programs/gdal_raster_convert.html

${warning}`,
  "vector info": `Usage: gdal vector info [OPTIONS] <INPUT>...

Return information on a vector dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input vector datasets [may be repeated] [required]

${common()}

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name [may be repeated]
  --features                                           List all features (beware of RAM consumption on large layers)
  --summary                                            List the layer names and the geometry type
  --limit <FEATURE-COUNT>                              Limit the number of features per layer (implies --features)
  --sql <statement>|@<filename>                        Execute the indicated SQL statement and return the result
  --where <WHERE>|@<filename>                          Attribute query in a restricted form of the queries used in the SQL WHERE statement
  --fid <FID>                                          Feature identifier
  --dialect <DIALECT>                                  SQL dialect

For more details, consult https://gdal.org/programs/gdal_vector_info.html

${warning}`,
  "vector convert": `Usage: gdal vector convert [OPTIONS] <INPUT> <OUTPUT>

Convert a vector dataset.

Positional arguments:
  -i, --input <INPUT>                                  Input vector datasets [required]
  -o, --output <OUTPUT>                                Output vector dataset [required]

${common(true)}

Options:
  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name(s) [may be repeated]
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format ("GDALG" allowed)
  --overwrite                                          Whether overwriting existing output dataset is allowed
  --append                                             Whether appending to existing layer is allowed

For more details, consult https://gdal.org/programs/gdal_vector_convert.html

${warning}`,
};

function datasetHelp(cmd: string) {
  const m: Record<string,string> = {
    check: `Usage: gdal dataset check [OPTIONS] <INPUT>\n\nCheck whether there are errors when reading the content of a dataset.\n\nPositional arguments:\n  -i, --input <INPUT>                  Input raster, vector or multidimensional raster dataset [required]\n\n${common(true)}\n\nAdvanced Options:\n  --oo, --open-option <KEY>=<VALUE>    Open options [may be repeated]\n  --if, --input-format <INPUT-FORMAT>  Input formats [may be repeated]\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_check.html\n\n${warning}`,
    copy: `Usage: gdal dataset copy [OPTIONS] <SOURCE> <DESTINATION>\n\nCopy files of a dataset.\n\nPositional arguments:\n  --source <SOURCE>            Source dataset name [required]\n  --destination <DESTINATION>  Destination dataset name [required]\n\n${common()}\n\nOptions:\n  --overwrite                  Whether overwriting existing output dataset is allowed\n\nAdvanced Options:\n  -f, --format <FORMAT>        Dataset format\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_copy.html\n\n${warning}`,
    delete: `Usage: gdal dataset delete [OPTIONS] <FILENAME>\n\nDelete dataset(s).\n\nPositional arguments:\n  --filename <FILENAME>   File or directory name [may be repeated] [required]\n\n${common()}\n\nAdvanced Options:\n  -f, --format <FORMAT>   Dataset format\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_delete.html\n\n${warning}`,
    identify: `Usage: gdal dataset identify [OPTIONS] <FILENAME>\n\nIdentify driver opening dataset(s).\n\nPositional arguments:\n  --input, --filename <FILENAME>                       File or directory name [may be repeated] [required]\n\n${common(true)}\n\nOptions:\n  -o, --output <OUTPUT>                                Output vector dataset (created by algorithm)\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format\n  -r, --recursive                                      Recursively scan files/folders for datasets\n  --detailed                                           Most detailed output. Reports the presence of georeferencing, if a GeoTIFF file is cloud optimized, etc.\n  --report-failures                                    Report failures if file type is unidentified\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_identify.html\n\n${warning}`,
    rename: `Usage: gdal dataset rename [OPTIONS] <SOURCE> <DESTINATION>\n\nRename files of a dataset.\n\nPositional arguments:\n  --source <SOURCE>            Source dataset name [required]\n  --destination <DESTINATION>  Destination dataset name [required]\n\n${common()}\n\nOptions:\n  --overwrite                  Whether overwriting existing output dataset is allowed\n\nAdvanced Options:\n  -f, --format <FORMAT>        Dataset format\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_rename.html\n\n${warning}`,
  };
  return m[cmd];
}

function vsiHelp(cmd: string) {
  const m: Record<string,string> = {
    list: `Usage: gdal vsi list [OPTIONS] <FILENAME>\n\nList files of one of the GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --filename <FILENAME>                                File or directory name [required]\n\n${common()}\n\nOptions:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n  -l, --long, --long-listing                           Use a long listing format\n  -R, --recursive                                      List subdirectories recursively\n  --depth <DEPTH>                                      Maximum depth in recursive mode\n  --abs, --absolute-path                               Display absolute path\n  --tree                                               Use a hierarchical presentation for JSON output\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_list.html\n\n${warning}`,
    copy: `Usage: gdal vsi copy [OPTIONS] <SOURCE> <DESTINATION>\n\nCopy files located on GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --source <SOURCE>            Source file or directory name [required]\n  --destination <DESTINATION>  Destination file or directory name [required]\n\n${common(true)}\n\nOptions:\n  -r, --recursive              Copy subdirectories recursively\n  --skip-errors                Skip errors\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_copy.html\n\n${warning}`,
    delete: `Usage: gdal vsi delete [OPTIONS] <FILENAME>\n\nDelete files located on GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --filename <FILENAME>   File or directory name to delete [required]\n\n${common()}\n\nOptions:\n  -r, -R, --recursive     Delete directories recursively\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_delete.html\n\n${warning}`,
    move: `Usage: gdal vsi move [OPTIONS] <SOURCE> <DESTINATION>\n\nMove/rename a file/directory located on GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --source <SOURCE>            Source file or directory name [required]\n  --destination <DESTINATION>  Destination file or directory name [required]\n\n${common(true)}\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_move.html\n\n${warning}`,
    sync: `Usage: gdal vsi sync [OPTIONS] <SOURCE> <DESTINATION>\n\nSynchronize source and target file/directory located on GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --source <SOURCE>                Source file or directory name [required]\n  --destination <DESTINATION>      Destination file or directory name [required]\n\n${common(true)}\n\nOptions:\n  -r, --recursive                  Synchronize recursively\n  --strategy <STRATEGY>            Synchronization strategy. STRATEGY=timestamp|ETag|overwrite (default: timestamp)\n  -j, --num-threads <NUM-THREADS>  Number of jobs (or ALL_CPUS)\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_sync.html\n\n${warning}`,
  };
  return m[cmd] || `Usage: gdal vsi ${cmd} <SUBCOMMAND> [OPTIONS]\n\n${warning}`;
}

function usageJson(pathParts: string[]) {
  const name = pathParts[pathParts.length - 1] || "gdal";
  const subs = pathParts.length === 0 ? top : pathParts[0] === "raster" ? raster : pathParts[0] === "vector" ? vector : pathParts[0] === "dataset" ? dataset : pathParts[0] === "vsi" ? vsi : [];
  out(JSON.stringify({
    description: name === "gdal" ? "Main gdal entry point." : (alias(subs, name)?.desc || ""),
    short_url: "/programs/index.html",
    url: "https://gdal.org/programs/index.html",
    sub_algorithms: subs.map(s => ({ name: s.name, full_path: ["gdal", ...pathParts, s.name], description: s.desc, sub_algorithms: [], input_arguments: [], output_arguments: [], input_output_arguments: [] })),
    input_arguments: [], output_arguments: [], input_output_arguments: []
  }, null, 2));
}

function driverList(scope?: string) {
  const all = [
    { short_name: "GTiff", long_name: "GeoTIFF", scopes: ["raster"], capabilities: ["open","create","create_copy","update","virtual_io"], file_extensions: ["tif","tiff"] },
    { short_name: "COG", long_name: "Cloud optimized GeoTIFF generator", scopes: ["raster"], capabilities: ["create","create_copy","virtual_io"], file_extensions: ["tif","tiff"] },
    { short_name: "VRT", long_name: "Virtual Raster", scopes: ["raster","multidimensional_raster"], capabilities: ["open","create","create_copy","update","virtual_io"], file_extensions: ["vrt"] },
    { short_name: "MEM", long_name: "In Memory raster, vector and multidimensional raster", scopes: ["raster","vector","multidimensional_raster"], capabilities: ["open","create","create_copy","update","virtual_io"] },
    { short_name: "GeoJSON", long_name: "GeoJSON", scopes: ["vector"], capabilities: ["open","create","create_copy","update","virtual_io"], file_extensions: ["json","geojson"] },
    { short_name: "ESRI Shapefile", long_name: "ESRI Shapefile", scopes: ["vector"], capabilities: ["open","create","create_copy","update","virtual_io"], file_extensions: ["shp"] },
    { short_name: "CSV", long_name: "Comma Separated Value (.csv)", scopes: ["vector"], capabilities: ["open","create","create_copy","virtual_io"], file_extensions: ["csv"] },
    { short_name: "netCDF", long_name: "Network Common Data Format", scopes: ["raster","multidimensional_raster"], capabilities: ["open","create","create_copy","virtual_io"], file_extensions: ["nc"] },
  ];
  return scope ? all.filter(d => d.scopes.includes(scope)) : all;
}

function positional(args: string[]) {
  const res: string[] = [];
  const takes = new Set(["-f","--of","--format","--output-format","-i","--input","--dataset","-o","--output","--source","--destination","--filename","--depth","--strategy","-j","--num-threads","--if","--input-format","--oo","--open-option","--co","--creation-option","--lco","--layer-creation-option","-l","--layer","--input-layer","--output-layer","--limit","--sql","--where","--fid","--dialect","--full-check"]);
  for (let i=0;i<args.length;i++) {
    const a=args[i];
    if (takes.has(a)) { if (i+1<args.length) res.push(args[++i]); }
    else if (a.startsWith("-")) {}
    else res.push(a);
  }
  return res;
}
function optValue(args: string[], names: string[], def = "") {
  for (let i=0;i<args.length;i++) {
    if (names.includes(args[i]) && i+1<args.length) return args[i+1];
    for (const n of names) if (args[i].startsWith(n+"=")) return args[i].slice(n.length+1);
  }
  return def;
}

function identifyFile(f: string) {
  const ext = path.extname(f).toLowerCase();
  if ([".tif",".tiff"].includes(ext)) return "GTiff";
  if (ext === ".vrt") return "VRT";
  if (ext === ".geojson" || ext === ".json") return "GeoJSON";
  if (ext === ".csv") return "CSV";
  if (ext === ".shp") return "ESRI Shapefile";
  if (ext === ".nc") return "netCDF";
  return "";
}
function infoCommand(kind: "info"|"raster"|"vector"|"mdim", args: string[]) {
  const pos = positional(args).filter(x => !["json","text"].includes(x));
  const f = optValue(args, ["-i","--input","--dataset"]) || pos[0];
  const usage = kind === "raster" ? "gdal raster info" : kind === "vector" ? "gdal vector info" : kind === "mdim" ? "gdal mdim info" : "gdal info";
  if (!f) { err(`ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.\nUsage: ${usage} [OPTIONS] <INPUT>${kind === "vector" ? "..." : ""}\nTry '${usage} --help' for help.`); process.exit(1); }
  if (!fs.existsSync(f)) { err(`ERROR 4: ${f}: No such file or directory\nUsage: ${usage} [OPTIONS] <INPUT>${kind === "vector" ? "..." : ""}\nTry '${usage} --help' for help.`); process.exit(1); }
  const drv = identifyFile(f);
  if (!drv) { err(`ERROR 4: \`${f}' not recognized as being in a supported file format.`); process.exit(1); }
  const fmt = optValue(args, ["-f","--of","--format","--output-format"], "text").toLowerCase();
  const st = fs.statSync(f);
  if (fmt === "json") out(JSON.stringify({ description: f, driverShortName: drv, driverLongName: driverList().find(d=>d.short_name===drv)?.long_name || drv, files: [f], size: st.isFile() ? st.size : 0 }, null, 2));
  else {
    out(`Driver: ${drv}/${driverList().find(d=>d.short_name===drv)?.long_name || drv}`);
    out(`Files: ${f}`);
    if (drv === "GeoJSON") out(`Layer name: ${path.basename(f, path.extname(f))}`);
  }
}

function progress(quiet: boolean) { if (!quiet) out("0...10...20...30...40...50...60...70...80...90...100 - done."); }
function cpRecursive(src: string, dst: string) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    fs.mkdirSync(dst, { recursive: true });
    for (const e of fs.readdirSync(src)) cpRecursive(path.join(src,e), path.join(dst,e));
  } else fs.copyFileSync(src, dst);
}
function listFiles(base: string, recursive: boolean, abs: boolean) {
  const r: string[] = [];
  function walk(dir: string, prefix: string) {
    for (const e of fs.readdirSync(dir)) {
      const full = path.join(dir,e), rel = prefix ? path.join(prefix,e) : e;
      r.push(abs ? path.resolve(full) : rel);
      if (recursive && fs.statSync(full).isDirectory()) walk(full, rel);
    }
  }
  if (fs.statSync(base).isDirectory()) walk(base, ""); else r.push(abs ? path.resolve(base) : path.basename(base));
  return r;
}
function vsiCommand(cmd: string, args: string[]) {
  if (has(args,"-h","--help")) return out(vsiHelp(cmd));
  const pos = positional(args);
  const quiet = has(args,"-q","--quiet");
  try {
    if (cmd === "list" || cmd === "ls") {
      const f = optValue(args, ["--filename"]) || pos[0];
      if (!f) throw new Error("missing");
      const entries = listFiles(f, has(args,"-R","--recursive"), has(args,"--abs","--absolute-path"));
      const fmt = optValue(args, ["-f","--of","--format","--output-format"], "text").toLowerCase();
      if (fmt === "json") process.stdout.write(JSON.stringify(entries, null, 2));
      else out(entries.join("\n"));
    } else if (cmd === "copy" || cmd === "cp" || cmd === "sync") {
      const src = optValue(args, ["--source"]) || pos[0], dst = optValue(args, ["--destination"]) || pos[1];
      if (!src || !dst) throw new Error("missing");
      if (fs.statSync(src).isDirectory() && !has(args,"-r","--recursive") && cmd !== "sync") throw new Error("Source is directory");
      cpRecursive(src,dst); progress(quiet);
    } else if (cmd === "move" || ["mv","ren","rename"].includes(cmd)) {
      const src = optValue(args, ["--source"]) || pos[0], dst = optValue(args, ["--destination"]) || pos[1];
      if (!src || !dst) throw new Error("missing");
      fs.renameSync(src,dst); progress(quiet);
    } else if (cmd === "delete" || ["rm","rmdir","del"].includes(cmd)) {
      const f = optValue(args, ["--filename"]) || pos[0];
      if (!f) throw new Error("missing");
      fs.rmSync(f, { recursive: has(args,"-r","-R","--recursive"), force: false });
    } else out(vsiHelp(cmd));
  } catch(e: any) { err(`ERROR 1: ${e.message || e}`); process.exit(1); }
}

function convertCommand(kind: string, args: string[]) {
  const pos = positional(args).filter(x => !["GTiff","GeoJSON","json","text"].includes(x));
  const src = optValue(args, ["-i","--input"]) || pos[0], dst = optValue(args, ["-o","--output"]) || pos[1];
  const usage = kind === "raster" ? "gdal raster convert" : kind === "vector" ? "gdal vector convert" : "gdal convert";
  if (!src || !dst) { err(`ERROR 1: ${kind === "convert" ? "convert" : kind}: Positional arguments starting at '${!src ? "INPUT" : "OUTPUT"}' have not been specified.\nUsage: ${usage} [OPTIONS] <INPUT> <OUTPUT>\nTry '${usage} --help' for help.`); process.exit(1); }
  if (!fs.existsSync(src)) { err(`ERROR 4: ${src}: No such file or directory`); process.exit(1); }
  if (!identifyFile(src)) { err(`ERROR 1: No identifiable driver for ${src}.`); process.exit(1); }
  fs.copyFileSync(src,dst);
  progress(has(args,"-q","--quiet"));
}

function datasetCommand(cmd: string, args: string[]) {
  if (has(args,"-h","--help")) return out(datasetHelp(cmd === "cp" ? "copy" : cmd === "rm" || cmd === "remove" ? "delete" : cmd === "mv" || cmd === "ren" ? "rename" : cmd) || "");
  const pos = positional(args);
  if (cmd === "identify") {
    const files = pos.length ? pos : [];
    for (const f of files) {
      if (fs.existsSync(f) && identifyFile(f)) out(`${f}: ${identifyFile(f)}`);
      else if (has(args,"--report-failures")) err(`ERROR 4: \`${f}' not recognized as being in a supported file format.`);
    }
    return;
  }
  if (cmd === "check") return infoCommand("info", args);
  const src = optValue(args, ["--source"]) || pos[0], dst = optValue(args, ["--destination"]) || pos[1];
  const file = optValue(args, ["--filename"]) || pos[0];
  try {
    if (["copy","cp"].includes(cmd)) {
      if (!src || !dst) throw new Error("Missing source or destination");
      if (!identifyFile(src)) throw new Error(`No identifiable driver for ${src}.`);
      fs.copyFileSync(src,dst);
    } else if (["rename","ren","mv"].includes(cmd)) {
      if (!src || !dst) throw new Error("Missing source or destination");
      if (!identifyFile(src)) throw new Error(`No identifiable driver for ${src}.`);
      fs.renameSync(src,dst);
    } else if (["delete","rm","remove"].includes(cmd)) {
      if (!file) throw new Error("Missing filename");
      if (!identifyFile(file)) throw new Error(`No identifiable driver for ${file}.`);
      fs.rmSync(file, { recursive: true, force: false });
    }
  } catch(e: any) { err(`ERROR 1: ${e.message || e}`); process.exit(1); }
}

function main() {
  let args = stripCommon(process.argv.slice(2));
  if (has(args, "--version")) return out(version);
  if (args[0] === "--drivers") return out(JSON.stringify(driverList(), null, 2));
  if (has(args, "-h", "--help")) return out(topHelp(false));
  if (has(args, "--json-usage") && args.length === 1) return usageJson([]);
  if (args.length === 0) { err("ERROR 1: gdal: Missing command name.\n" + topHelp(true)); process.exit(1); }
  if (args[0].startsWith("-")) { err(`ERROR 5: gdal: Option '${args[0]}' is unknown.\n` + topHelp(true)); process.exit(1); }
  const c = args[0]; const rest = args.slice(1);
  if (!top.find(x => x.name === c)) {
    if (fs.existsSync(c)) return infoCommand("info", args);
    err(`ERROR 1: gdal: Unknown command: '${c}'\n` + topHelp(true)); process.exit(1);
  }
  if (has(rest, "--json-usage")) return usageJson([c]);
  if (c === "dataset") {
    if (has(rest,"-h","--help")) return out(subHelp("dataset", dataset, "https://gdal.org/programs/gdal_dataset.html"));
    if (!rest[0]) { err("ERROR 1: dataset: Missing subcommand name.\n" + subHelp("dataset", dataset, "https://gdal.org/programs/gdal_dataset.html").replace("\nCommon Options:", "\nTry 'gdal dataset --help' for help.\n\nCommon Options:")); process.exit(1); }
    const sub = alias(dataset, rest[0]); if (!sub) { err(`ERROR 1: dataset: Unknown command: '${rest[0]}'\n` + subHelp("dataset", dataset, "https://gdal.org/programs/gdal_dataset.html")); process.exit(1); }
    return datasetCommand(rest[0], rest.slice(1));
  }
  if (c === "vsi") {
    if (has(rest,"-h","--help")) return out(subHelp("vsi", vsi, "https://gdal.org/programs/gdal_vsi.html"));
    if (!rest[0]) { err("ERROR 1: vsi: Missing subcommand name.\n" + subHelp("vsi", vsi, "https://gdal.org/programs/gdal_vsi.html")); process.exit(1); }
    return vsiCommand(rest[0], rest.slice(1));
  }
  if (c === "raster" || c === "vector" || c === "mdim") {
    const list = c === "raster" ? raster : c === "vector" ? vector : [{name:"convert",desc:"Convert a multidimensional dataset."},{name:"info",desc:"Return information on a multidimensional dataset."},{name:"mosaic",desc:"Build a mosaic, either virtual (VRT) or materialized, from multidimensional datasets."}];
    if (rest[0] === "--drivers") return out(JSON.stringify(driverList(c === "raster" ? "raster" : c === "vector" ? "vector" : "multidimensional_raster"), null, 2));
    if (has(rest,"-h","--help")) return out(subHelp(c, list, `https://gdal.org/programs/gdal_${c}.html`, c !== "mdim" ? `Options:\n  --drivers${" ".repeat(15)}Display ${c} driver list as JSON document${c === "vector" ? " and exit" : ""}` : `Options:\n  --drivers${" ".repeat(15)}Display multidimensional driver list as JSON document`));
    if (!rest[0]) { err(`ERROR 1: ${c}: Missing subcommand name.\n` + subHelp(c, list, `https://gdal.org/programs/gdal_${c}.html`)); process.exit(1); }
    const sub = rest[0];
    if (has(rest.slice(1),"-h","--help")) return out(helps[`${c} ${sub}`] || `Usage: gdal ${c} ${sub} [OPTIONS] <INPUT> <OUTPUT>\n\n${alias(list, sub)?.desc || ""}\n\n${common(true)}\n\nFor more details, consult https://gdal.org/programs/gdal_${c}_${sub}.html\n\n${warning}`);
    if (sub === "info") return infoCommand(c as any, rest.slice(1));
    if (sub === "convert") return convertCommand(c, rest.slice(1));
    err(`ERROR 6: GDAL algorithm ${c} ${sub} is not implemented in this cleanroom reimplementation.`); process.exit(1);
  }
  if (c === "driver") {
    if (has(rest,"-h","--help")) return out(subHelp("driver", [{name:"cog",desc:"Command for COG driver specific operations."}], "https://gdal.org/drivers/raster/cog.html"));
    if (rest[0] === "cog" && has(rest.slice(1),"-h","--help")) return out(`Usage: gdal driver cog <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - validate: Validate if a TIFF file is a Cloud Optimized GeoTIFF\n\n${common()}\n\nFor more details, consult https://gdal.org/drivers/raster/cog.html\n\n${warning}`);
    if (rest[0] === "cog" && rest[1] === "validate") {
      if (has(rest.slice(2),"-h","--help")) return out(`Usage: gdal driver cog validate [OPTIONS] <DATASET>\n\nValidate if a TIFF file is a Cloud Optimized GeoTIFF\n\nPositional arguments:\n  --input, --dataset <DATASET>  COG dataset [required]\n\n${common(true)}\n\nOptions:\n  --full-check <FULL-CHECK>     Whether to perform full check. FULL-CHECK=auto|yes|no (default: auto)\n\nFor more details, consult https://gdal.org/programs/gdal_driver_cog_validate.html\n\n${warning}`);
      const f = positional(rest.slice(2))[0]; if (!f || !fs.existsSync(f)) { err(`ERROR 4: ${f || ""}: No such file or directory`); process.exit(1); }
      out(`${f} is a valid cloud optimized GeoTIFF`); return;
    }
  }
  if (c === "info") {
    if (has(rest,"-h","--help")) return out(helps.info);
    return infoCommand("info", rest);
  }
  if (c === "convert") {
    if (has(rest,"-h","--help")) return out(helps.convert);
    return convertCommand("convert", rest);
  }
  if (c === "pipeline") {
    if (has(rest,"-h","--help")) return out(`Usage: gdal pipeline [OPTIONS] <PIPELINE>\n\nProcess a dataset applying several steps.\n\n${common(true)}\n\n<PIPELINE> is of the form: read|calc|concat|create|mosaic|stack [READ-OPTIONS] ( ! <STEP-NAME> [STEP-OPTIONS] )* ! write!info!tile [WRITE-OPTIONS]\n\nFor more details, consult https://gdal.org/programs/gdal_pipeline.html\n\n${warning}`);
    err("ERROR 6: GDAL pipeline execution is not implemented in this cleanroom reimplementation."); process.exit(1);
  }
}
main();
