const fs = require("fs");
const path = require("path");
const nodeCrypto = require("crypto");

type Opts = { [key: string]: string | boolean | string[] };

const COMMUNITY = `You're running the community build of Atlas, which may differ from the official version.
If this error persists, try installing the official version as a troubleshooting step:

  curl -sSf https://atlasgo.sh | sh

More installation options: https://atlasgo.io/docs#installation`;

const NOTICE = `Notice: This Atlas edition lacks support for features such as checkpoints,
testing, down migrations, and more. Additionally, advanced database objects such as views, 
triggers, and stored procedures are not supported. To read more: https://atlasgo.io/community-edition

To install the non-community version of Atlas, use the following command:

\tcurl -sSf https://atlasgo.sh | sh

Or, visit the website to see all installation options:

\thttps://atlasgo.io/docs#installation
`;

const rootHelp = `Manage your database schema as code

Usage:
  atlas [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  help        Help about any command
  license     Display license information
  migrate     Manage versioned migration files
  schema      Work with atlas schemas.
  version     Prints this Atlas CLI version information.

Flags:
  -h, --help   help for atlas

Use "atlas [command] --help" for more information about a command.`;

const schemaHelp = `The \`atlas schema\` command groups subcommands working with declarative Atlas schemas.

Usage:
  atlas schema [command]

Available Commands:
  apply       Apply an atlas schema to a target database.
  clean       Removes all objects from the connected database.
  diff        Calculate and print the diff between two schemas.
  fmt         Formats Atlas HCL files
  inspect     Inspect a database and print its schema in Atlas DDL syntax.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for schema
      --var <name>=<value>   input variables (default [])

Use "atlas schema [command] --help" for more information about a command.`;

const migrateHelp = `'atlas migrate' wraps several sub-commands for migration management.

Usage:
  atlas migrate [command]

Available Commands:
  apply       Applies pending migration files on the connected database.
  diff        Compute the diff between the migration directory and a desired state and create a new migration file.
  hash        Hash (re-)creates an integrity hash file for the migration directory.
  import      Import a migration directory from another migration management tool to the Atlas format.
  lint        Run analysis on the migration directory
  new         Creates a new empty migration file in the migration directory.
  set         Set the current version of the migration history table.
  status      Get information about the current migration status.
  validate    Validates the migration directories checksum and SQL statements.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for migrate
      --var <name>=<value>   input variables (default [])

Use "atlas migrate [command] --help" for more information about a command.`;

const helpTexts: Record<string, string> = {
  "schema inspect": `'atlas schema inspect' connects to the given database and inspects its schema.
It then prints to the screen the schema of that database in Atlas DDL syntax. This output can be
saved to a file, commonly by redirecting the output to a file named with a ".hcl" suffix:

  atlas schema inspect -u "mysql://user:pass@localhost:3306/dbname" > schema.hcl

Usage:
  atlas schema inspect [flags]

Examples:
  atlas schema inspect -u "mysql://user:pass@localhost:3306/dbname"
  atlas schema inspect -u "mariadb://user:pass@localhost:3306/" --schema=schemaA,schemaB -s schemaC
  atlas schema inspect --url "postgres://user:pass@host:port/dbname?sslmode=disable"
  atlas schema inspect -u "sqlite://file:ex1.db?_fk=1"

Flags:
  -u, --url string        [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
  -s, --schema strings    set schema names
      --exclude strings   list of glob patterns used to filter resources from applying
      --format string     Go template to use to format the output
  -h, --help              help for inspect

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`,
  "schema fmt": `'atlas schema fmt' formats all ".hcl" files under the given paths using
canonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.
Unless stated otherwise, the fmt command will use the current directory.

After running, the command will print the names of the files it has formatted. If all
files in the directory are formatted, no input will be printed out.

Usage:
  atlas schema fmt [path ...] [flags]

Flags:
  -h, --help   help for fmt

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`,
  "schema diff": `'atlas schema diff' reads the state of two given schema definitions, 
calculates the difference in their schemas, and prints a plan of
SQL statements to migrate the "from" database to the schema of the "to" database.

Usage:
  atlas schema diff [flags]

Flags:
  -f, --from strings      [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --to strings        [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
  -h, --help              help for diff`,
  "schema apply": `'atlas schema apply' plans and executes a database migration to bring a given
database to the state described in the provided Atlas schema. Before running the
migration, Atlas will print the migration plan and prompt the user for approval.

Usage:
  atlas schema apply [flags]

Flags:
  -u, --url string              [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dry-run                 print SQL without executing it
      --auto-approve            apply changes without prompting for approval
  -h, --help                    help for apply`,
  "schema clean": `'atlas schema clean' drops all objects in the connected database and leaves it in an empty state.
As a safety feature, 'atlas schema clean' will ask for confirmation before attempting to execute any SQL.

Usage:
  atlas schema clean [flags]

Flags:
  -u, --url string      [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dry-run         print SQL without executing it
      --format string   Go template to use to format the output
      --auto-approve    apply changes without prompting for approval
  -h, --help            help for clean`,
  "migrate new": `'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.

Usage:
  atlas migrate new [flags] [name]

Examples:
  atlas migrate new my-new-migration

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
      --edit                edit the created migration file(s)
  -h, --help                help for new`,
  "migrate hash": `'atlas migrate hash' computes the integrity hash sum of the migration directory and stores it in the atlas.sum file.
This command should be used whenever a manual change in the migration directory was made.

Usage:
  atlas migrate hash [flags]

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for hash`,
  "migrate validate": `'atlas migrate validate' computes the integrity hash sum of the migration directory and compares it to the
atlas.sum file. If there is a mismatch it will be reported. If the --dev-url flag is given, the migration
files are executed on the connected database in order to validate SQL semantics.

Usage:
  atlas migrate validate [flags]

Flags:
      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for validate`,
  "migrate apply": `'atlas migrate apply' reads the migration state of the connected database and computes what migrations are pending.
It then attempts to apply the pending migration files in the correct order onto the database.

Usage:
  atlas migrate apply [flags] [amount]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dir string                select migration directory using URL format (default "file://migrations")
      --dry-run                   print SQL without executing it
  -h, --help                      help for apply`,
  "migrate status": `'atlas migrate status' reports information about the current status of a connected database compared to the migration directory.

Usage:
  atlas migrate status [flags]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --format string             Go template to use to format the output
      --dir string                select migration directory using URL format (default "file://migrations")
  -h, --help                      help for status`,
  "migrate set": `'atlas migrate set' edits the revision table to consider all migrations up to and including the given version
to be applied. This command is usually used after manually making changes to the managed database.

Usage:
  atlas migrate set [flags] [version]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dir string                select migration directory using URL format (default "file://migrations")
  -h, --help                      help for set`,
};

function out(s: string) { process.stdout.write(s + "\n"); }
function err(s: string, code = 1): never {
  process.stderr.write(s + "\n");
  throw Object.assign(new Error(s), { exitCode: code });
}

function parse(args: string[]): { positional: string[]; opts: Opts } {
  const positional: string[] = [];
  const opts: Opts = {};
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") opts.help = true;
    else if (a === "-u" || a === "--url") opts.url = args[++i] ?? "";
    else if (a.startsWith("--url=")) opts.url = a.slice(6);
    else if (a === "-c" || a === "--config") opts.config = args[++i] ?? "";
    else if (a.startsWith("--config=")) opts.config = a.slice(9);
    else if (a === "--env") opts.env = args[++i] ?? "";
    else if (a.startsWith("--env=")) opts.env = a.slice(6);
    else if (a === "--var") pushOpt(opts, "var", args[++i] ?? "");
    else if (a.startsWith("--var=")) pushOpt(opts, "var", a.slice(6));
    else if (a === "-f" || a === "--from") pushOpt(opts, "from", args[++i] ?? "");
    else if (a.startsWith("--from=")) pushOpt(opts, "from", a.slice(7));
    else if (a === "--to") pushOpt(opts, "to", args[++i] ?? "");
    else if (a.startsWith("--to=")) pushOpt(opts, "to", a.slice(5));
    else if (a === "--dir") opts.dir = args[++i] ?? "";
    else if (a.startsWith("--dir=")) opts.dir = a.slice(6);
    else if (a === "--dev-url") opts["dev-url"] = args[++i] ?? "";
    else if (a.startsWith("--dev-url=")) opts["dev-url"] = a.slice(10);
    else if (a === "--dry-run" || a === "--auto-approve" || a === "--edit" || a === "--allow-dirty") opts[a.slice(2)] = true;
    else if (a.startsWith("-")) {
      const next = args[i + 1];
      if (next && !next.startsWith("-")) i++;
    } else positional.push(a);
  }
  return { positional, opts };
}

function pushOpt(opts: Opts, key: string, val: string) {
  const cur = opts[key];
  if (Array.isArray(cur)) cur.push(val);
  else opts[key] = cur ? [String(cur), val] : [val];
}

function unsupported(name: string): never {
  out(`'atlas ${name}' is not supported by the community version.

To install the non-community version of Atlas, use the following command:

\tcurl -sSf https://atlasgo.sh | sh

Or, visit the website to see all installation options:

\thttps://atlasgo.io/docs#installation`);
  process.exit(0);
  throw new Error("unreachable");
}

function fileURLToPathish(u: string): string {
  if (!u || u === "file://migrations") return "migrations";
  if (u.startsWith("file://")) {
    const rest = u.slice(7).split("?")[0];
    return rest.startsWith("/") ? rest : rest;
  }
  return u;
}

function schemaInspect(opts: Opts) {
  const env = loadEnv(opts);
  const url = String(opts.url || env.url || "");
  if (!opts["dev-url"] && env.dev) opts["dev-url"] = env.dev;
  if (!url) err(`Error: required flag(s) "url" not set`);
  if (url.startsWith("file://") && !opts["dev-url"]) err("Error: --dev-url cannot be empty");
  if (url.startsWith("sqlite://")) {
    process.stderr.write(NOTICE + "\n");
    out(`schema "main" {
}`);
    return;
  }
  if (url.startsWith("file://")) {
    const p = fileURLToPathish(url);
    if (fs.existsSync(p)) process.stdout.write(fs.readFileSync(p, "utf8"));
    else err(`Error: stat ${p}: no such file or directory`);
    return;
  }
  err("Error: sql/sqlclient: missing driver. See: https://atlasgo.io/url");
}

function formatHCL(input: string): string {
  const lines = input.replace(/\r\n/g, "\n").split("\n");
  let level = 0;
  const res: string[] = [];
  for (let raw of lines) {
    let t = raw.trim();
    if (!t) {
      if (res.length && res[res.length - 1] !== "") res.push("");
      continue;
    }
    t = t.replace(/\s+/g, " ");
    t = t.replace(/\s*=\s*/g, " = ");
    t = t.replace(/\s*,\s*/g, ", ");
    t = t.replace(/\[\s*/g, "[").replace(/\s*\]/g, "]");
    t = t.replace(/\s*\{\s*$/g, " {");
    if (t.startsWith("}")) level = Math.max(0, level - 1);
    res.push("  ".repeat(level) + t);
    if (t.endsWith("{")) level++;
  }
  while (res.length && res[res.length - 1] === "") res.pop();
  return res.join("\n") + "\n";
}

function walkHCL(p: string): string[] {
  const st = fs.statSync(p);
  if (st.isFile()) return p.endsWith(".hcl") ? [p] : [];
  const all: string[] = [];
  for (const ent of fs.readdirSync(p)) all.push(...walkHCL(path.join(p, ent)));
  return all.sort();
}

function schemaFmt(paths: string[]) {
  const targets = paths.length ? paths : ["."];
  for (const p of targets) {
    if (!fs.existsSync(p)) err(`Error: stat ${p}: no such file or directory`);
  }
  const files = targets.flatMap(walkHCL);
  for (const f of files) {
    const old = fs.readFileSync(f, "utf8");
    const neu = formatHCL(old);
    if (old !== neu) {
      fs.writeFileSync(f, neu);
      out(f);
    }
  }
}

function migDir(opts: Opts): string {
  return fileURLToPathish(String(opts.dir || "file://migrations"));
}

function loadEnv(opts: Opts): Record<string, any> {
  const envName = String(opts.env || "");
  if (!envName) return {};
  const cfg = fileURLToPathish(String(opts.config || "file://atlas.hcl"));
  if (!fs.existsSync(cfg)) err(`Error: open ${cfg}: no such file or directory`);
  let text = fs.readFileSync(cfg, "utf8");
  const vars: Record<string, string> = {};
  for (const m of text.matchAll(/variable\s+"([^"]+)"\s*\{([\s\S]*?)\}/g)) {
    const dm = String(m[2]).match(/default\s*=\s*"([^"]*)"/);
    if (dm) vars[m[1]] = dm[1];
  }
  const passed = opts.var;
  const arr = Array.isArray(passed) ? passed : passed ? [String(passed)] : [];
  for (const item of arr) {
    const eq = item.indexOf("=");
    if (eq > 0) vars[item.slice(0, eq)] = item.slice(eq + 1);
  }
  const locals: Record<string, string> = {};
  const lm = text.match(/locals\s*\{([\s\S]*?)\}/);
  if (lm) {
    for (const line of lm[1].split("\n")) {
      const m = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.+?)\s*$/);
      if (m) locals[m[1]] = evalExpr(m[2], vars, locals, envName);
    }
  }
  const body = findNamedBlock(text, "env", envName);
  if (body === undefined) err(`Error: env "${envName}" not found`);
  const got: Record<string, any> = {};
  for (const line of body.split("\n")) {
    const m = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.+?)\s*$/);
    if (!m) continue;
    const key = m[1] === "dev" ? "dev" : m[1];
    got[key] = evalExpr(m[2], vars, locals, envName);
  }
  return got;
}

function evalExpr(expr: string, vars: Record<string, string>, locals: Record<string, string>, envName: string): string {
  let s = expr.trim().replace(/,$/, "");
  const str = s.match(/^"([\s\S]*)"$/);
  if (str) s = str[1];
  const ge = s.match(/^getenv\("([^"]+)"\)$/);
  if (ge) return process.env[ge[1]] || "";
  if (s === "atlas.env") return envName;
  const vr = s.match(/^var\.([A-Za-z0-9_]+)$/);
  if (vr) return vars[vr[1]] || "";
  const lr = s.match(/^local\.([A-Za-z0-9_]+)$/);
  if (lr) return locals[lr[1]] || "";
  s = s.replace(/\$\{var\.([A-Za-z0-9_]+)\}/g, (_: string, k: string) => vars[k] || "");
  return s;
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function findNamedBlock(text: string, kind: string, name: string): string | undefined {
  const lines = text.split("\n");
  const start = new RegExp(`^\\s*${kind}\\s+"${escapeRegExp(name)}"\\s*\\{\\s*$`);
  for (let i = 0; i < lines.length; i++) {
    if (!start.test(lines[i])) continue;
    const body: string[] = [];
    for (let j = i + 1; j < lines.length; j++) {
      if (/^\s*}\s*$/.test(lines[j])) return body.join("\n");
      body.push(lines[j]);
    }
    return body.join("\n");
  }
  return undefined;
}

function sumLine(file: string, content: any): string {
  const h = nodeCrypto.createHash("sha256").update(content).digest("base64");
  return `${path.basename(file)} h1:${h}`;
}

function writeSum(dir: string) {
  fs.mkdirSync(dir, { recursive: true });
  const files = fs.readdirSync(dir).filter((f: string) => f.endsWith(".sql")).sort();
  const lines = files.map((f: string) => sumLine(f, fs.readFileSync(path.join(dir, f))));
  const total = nodeCrypto.createHash("sha256").update(lines.join("\n")).digest("base64");
  fs.writeFileSync(path.join(dir, "atlas.sum"), [`h1:${total}`, ...lines].join("\n") + "\n");
}

function migrateNew(args: string[], opts: Opts) {
  const name = (args[0] || "new_migration").replace(/[^A-Za-z0-9_-]+/g, "_");
  const d = migDir(opts);
  fs.mkdirSync(d, { recursive: true });
  const now = new Date();
  const stamp = now.toISOString().replace(/[-:T]/g, "").slice(0, 14);
  fs.closeSync(fs.openSync(path.join(d, `${stamp}_${name}.sql`), "a"));
  writeSum(d);
}

function migrateValidate(opts: Opts) {
  const d = migDir(opts);
  if (!fs.existsSync(d)) return;
  const sum = path.join(d, "atlas.sum");
  if (!fs.existsSync(sum)) err(`Error: checksum file not found: ${sum}`);
  const old = fs.readFileSync(sum, "utf8");
  const tmp = path.join(d, ".atlas.sum.tmp");
  writeSum(d);
  const neu = fs.readFileSync(sum, "utf8");
  fs.writeFileSync(sum, old);
  try { fs.unlinkSync(tmp); } catch {}
  if (old !== neu) err("Error: checksum mismatch");
}

function migrateApply(opts: Opts) {
  if (!opts.url) err(`Error: required flag "url" not set`);
  if (String(opts.url).startsWith("sqlite://") && opts["dry-run"]) {
    out("No migration files to execute");
    return;
  }
  err("Error: sql/sqlclient: missing driver. See: https://atlasgo.io/url");
}

function completion(shell: string, help: boolean) {
  if (!shell) { out(`Generate the autocompletion script for atlas for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  atlas completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion`); return; }
  if (help) { out(`Generate the autocompletion script for the ${shell} shell.

Usage:
  atlas completion ${shell} [flags]

Flags:
  -h, --help              help for ${shell}
      --no-descriptions   disable completion descriptions`); return; }
  out(`# ${shell} completion for atlas`);
}

function main() {
  const argv = process.argv.slice(2);
  const { positional, opts } = parse(argv);
  if (opts.help && positional.length === 0) return out(rootHelp);
  const [a, b, ...rest] = positional;
  if (!a) return out(rootHelp);
  if (a === "help") {
    const topic = positional.slice(1).join(" ");
    if (!topic) return out(`Help provides help for any command in the application.
Simply type atlas help [path to command] for full details.`);
    return out(topic === "schema" ? schemaHelp : topic === "migrate" ? migrateHelp : helpTexts[topic] || rootHelp);
  }
  if (a === "version") return opts.help ? out(`Prints this Atlas CLI version information.

Usage:
  atlas version [flags]

Flags:
  -h, --help   help for version`) : out(`atlas unofficial version - development
https://github.com/ariga/atlas/releases/latest
To download an official version, visit: https://atlasgo.io/getting-started#installation`);
  if (a === "license") return opts.help ? out(`Display license information

Usage:
  atlas license [flags]

Flags:
  -h, --help   help for license`) : out(`LICENSE
Atlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE.`);
  if (a === "completion") return completion(b || "", Boolean(opts.help));
  if (a === "schema") {
    if (!b || opts.help) return out(b ? (helpTexts[`schema ${b}`] || schemaHelp) : schemaHelp);
    if (b === "inspect") return schemaInspect(opts);
    if (b === "fmt") return schemaFmt(rest);
    if (b === "test") return unsupported("schema test");
    if (["diff", "apply"].includes(b)) return err("Error: --dev-url cannot be empty");
    if (b === "clean") return opts.url ? err("Error: sql/sqlclient: missing driver. See: https://atlasgo.io/url") : err(`Error: required flag(s) "url" not set`);
    return out(schemaHelp);
  }
  if (a === "migrate") {
    if (!b || opts.help) return out(b ? (helpTexts[`migrate ${b}`] || migrateHelp) : migrateHelp);
    if (b === "test") return unsupported("migrate test");
    if (b === "new") return migrateNew(rest, opts);
    if (b === "hash") return writeSum(migDir(opts));
    if (b === "validate") return migrateValidate(opts);
    if (b === "apply") return migrateApply(opts);
    if (b === "status") return err("Error: sql/sqlclient: missing driver. See: https://atlasgo.io/url");
    if (b === "set") return err(`Error: migration with version "${rest[0] || ""}" not found`);
    if (["diff", "lint", "import"].includes(b)) return err("Error: --dev-url cannot be empty");
    return out(migrateHelp);
  }
  err(`Error: unknown command "${a}" for "atlas"
Run 'atlas --help' for usage.
${COMMUNITY}`);
}

try {
  main();
} catch (e: any) {
  if (e && typeof e.exitCode === "number") process.exit(e.exitCode);
  throw e;
}
