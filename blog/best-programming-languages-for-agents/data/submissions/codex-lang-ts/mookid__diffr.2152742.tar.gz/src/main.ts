declare const process: any;
declare function require(name: string): any;

const fs = require("fs");

const RESET = "\x1b[0m";

type FaceName = "added" | "removed" | "refine-added" | "refine-removed";

class Face {
  seq: string;
  constructor(seq: string) {
    this.seq = seq;
  }
  paint(s: string): string {
    return this.seq + s + RESET;
  }
}

const faces: Record<FaceName, Face> = {
  "added": new Face("\x1b[32m"),
  "removed": new Face("\x1b[31m"),
  "refine-added": new Face("\x1b[1m\x1b[38;2;255;255;255m\x1b[42m"),
  "refine-removed": new Face("\x1b[1m\x1b[38;2;255;255;255m\x1b[41m"),
};

const LONG_HELP = `diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...
            Configure color settings for console ouput.

            There are four faces to customize:
            +----------------+--------------+----------------+
            |  line prefix   |      +       |       -        |
            +----------------+--------------+----------------+
            | common segment |    added     |    removed     |
            | unique segment | refine-added | refine-removed |
            +----------------+--------------+----------------+

            The customization allows
            - to change the foreground or background color;
            - to set or unset the attributes 'bold', 'intense', 'underline';
            - to clear all attributes.

            Customization is done passing a color_spec argument.
            This flag may be provided multiple times.

            The syntax is the following:

            color_spec = face-name + ':' + attributes
            attributes = attribute
                       | attribute + ':' + attributes
            attribute  = ('foreground' | 'background') + ':' + color
                       | (<empty> | 'no') + font-flag
                       | 'none'
            font-flag  = 'italic'
                       | 'bold'
                       | 'intense'
                       | 'underline'
            color      = 'none'
                       | [0-255]
                       | [0-255] + ',' + [0-255] + ',' + [0-255]
                       | ('black', 'blue', 'green', 'red',
                          'cyan', 'magenta', 'yellow', 'white')

            For example, the color_spec

                'refine-added:background:blue:bold'

            sets the color of unique added segments with
            a blue background, written with a bold font.

        --line-numbers <compact|aligned>
            Display line numbers. Style is optional.
            When style = 'compact', take as little width as possible.
            When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]

    -h, --help
            Prints help information

    -V, --version
            Prints version information
`;

const SHORT_HELP = `diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...    Configure color settings.
        --line-numbers              Display line numbers.
    -h, --help                      Prints help information
    -V, --version                   Prints version information
`;

function die(msg: string, code = 255): never {
  process.stderr.write(msg + "\n");
  process.exit(code);
  throw new Error(msg);
}

let lineNumbers: false | "compact" | "aligned" | "fixed" = false;
const args = process.argv.slice(2);
for (let i = 0; i < args.length; i++) {
  const a = args[i];
  if (a === "-h" || a === "--help") {
    process.stdout.write(LONG_HELP);
    process.exit(0);
  } else if (a === "-V" || a === "--version") {
    process.stdout.write("diffr 0.1.5\n");
    process.exit(0);
  } else if (a === "--line-numbers") {
    const n = args[i + 1];
    if (n === "compact" || n === "aligned" || n === "fixed") {
      lineNumbers = n;
      i++;
    } else if (n && !n.startsWith("-")) {
      die(`unexpected line number style: got '${n}', expected aligned|compact|fixed`);
    } else {
      lineNumbers = "compact";
    }
  } else if (a === "--colors") {
    const spec = args[++i];
    if (!spec) die("missing color spec");
    applyColorSpec(spec);
  } else {
    process.stderr.write(`bad argument: '${a}'\n`);
    process.stderr.write(SHORT_HELP);
    process.exit(2);
  }
}

function sgrForColor(kind: "foreground" | "background", color: string): string {
  const base = kind === "foreground" ? 30 : 40;
  const names: Record<string, number> = {
    black: 0, red: 1, green: 2, yellow: 3, blue: 4, magenta: 5, cyan: 6, white: 7,
  };
  if (color === "none") return kind === "foreground" ? "\x1b[39m" : "\x1b[49m";
  if (/^\d+$/.test(color)) return `\x1b[${kind === "foreground" ? 38 : 48};5;${Number(color)}m`;
  if (/^\d+,\d+,\d+$/.test(color)) {
    const [r, g, b] = color.split(",").map(Number);
    return `\x1b[${kind === "foreground" ? 38 : 48};2;${r};${g};${b}m`;
  }
  if (Object.prototype.hasOwnProperty.call(names, color)) return `\x1b[${base + names[color]}m`;
  return "";
}

function applyColorSpec(spec: string) {
  const parts = spec.split(":");
  const face = parts.shift() as FaceName;
  if (!["added", "removed", "refine-added", "refine-removed"].includes(face)) {
    die(`unexpected face name: got '${face}', expected added|refine-added|removed|refine-removed`);
  }
  let seq = "";
  const flags: string[] = [];
  let fg = "";
  let bg = "";
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    if (p === "none") {
      seq = ""; flags.length = 0; fg = ""; bg = "";
    } else if (p === "foreground" || p === "background") {
      const c = sgrForColor(p, parts[++i] || "none");
      if (p === "foreground") fg = c; else bg = c;
    } else if (p === "bold") flags.push("\x1b[1m");
    else if (p === "nobold") flags.push("\x1b[22m");
    else if (p === "intense") flags.push("\x1b[1m");
    else if (p === "nointense") flags.push("\x1b[22m");
    else if (p === "underline") flags.push("\x1b[4m");
    else if (p === "nounderline") flags.push("\x1b[24m");
    else if (p === "italic") flags.push("\x1b[3m");
    else if (p === "noitalic") flags.push("\x1b[23m");
  }
  seq += flags.join("") + fg + bg;
  faces[face] = new Face(seq);
}

interface Item { type: "add" | "del" | "ctx" | "other" | "hdr"; text: string; oldNo?: number; newNo?: number; oldW?: number; newW?: number; }

const input: string = fs.readFileSync(0, "utf8");
const rawLines = input.length ? input.split(/\n/) : [];
const hadFinalNewline = input.endsWith("\n");
if (hadFinalNewline) rawLines.pop();

let oldNo = 0, newNo = 0, oldW = 1, newW = 1;
const items: Item[] = [];
for (const line of rawLines) {
  const hm = /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/.exec(line);
  if (hm) {
    oldNo = Number(hm[1]);
    newNo = Number(hm[3]);
    const oldEnd = oldNo + Math.max(1, Number(hm[2] || "1")) - 1;
    const newEnd = newNo + Math.max(1, Number(hm[4] || "1")) - 1;
    oldW = String(oldEnd).length;
    newW = String(newEnd).length;
    items.push({ type: "hdr", text: line });
  } else if (line.startsWith("-") && !line.startsWith("---")) {
    items.push({ type: "del", text: line.slice(1), oldNo: oldNo++, oldW, newW });
  } else if (line.startsWith("+") && !line.startsWith("+++")) {
    items.push({ type: "add", text: line.slice(1), newNo: newNo++, oldW, newW });
  } else if (line.startsWith(" ")) {
    items.push({ type: "ctx", text: line.slice(1), oldNo: oldNo++, newNo: newNo++, oldW, newW });
  } else {
    items.push({ type: "other", text: line });
  }
}

function lnum(it: Item, face?: Face): string {
  if (!lineNumbers || it.type === "hdr" || it.type === "other") return "";
  const ow = it.oldW || oldW;
  const nw = it.newW || newW;
  let s = "";
  if (it.type === "del") s = String(it.oldNo).padStart(ow, " ") + " ".repeat(nw + 1);
  else if (it.type === "add") s = " ".repeat(ow + 1) + String(it.newNo).padStart(nw, " ");
  else if (it.oldNo === it.newNo) s = " ".repeat(ow + 1) + String(it.newNo).padStart(nw, " ");
  else s = String(it.oldNo).padStart(ow, " ") + " " + String(it.newNo).padStart(nw, " ");
  if (lineNumbers === "aligned") s += "\t";
  if (face) return face.paint(s);
  return s;
}

function tokenize(s: string): string[] {
  const re = /[A-Za-z0-9_]+[ \t]*|[ \t]+|.[ \t]*/gs;
  const m = s.match(re);
  return m || (s ? [s] : []);
}

function commonTokenIndexes(a: string[], b: string[]): [Set<number>, Set<number>] {
  const n = a.length, m = b.length;
  const dp: number[][] = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const ai = new Set<number>(), bi = new Set<number>();
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) { ai.add(i++); bi.add(j++); }
    else if (dp[i + 1][j] >= dp[i][j + 1]) i++;
    else j++;
  }
  return [ai, bi];
}

function paintByTokens(tokens: string[], common: Set<number>, base: Face, refine: Face): string {
  let out = "";
  let buf = "", cur: boolean | null = null;
  const flush = () => {
    if (!buf) return;
    out += (cur ? base : refine).paint(buf);
    buf = "";
  };
  for (let i = 0; i < tokens.length; i++) {
    const c = common.has(i);
    if (cur === null) cur = c;
    if (cur !== c) { flush(); cur = c; }
    buf += tokens[i];
  }
  flush();
  if (tokens.length === 0) out += base.paint("");
  return out;
}

function emitItem(it: Item, pair?: Item): string {
  if (it.type === "hdr" || it.type === "other") return RESET + it.text + RESET;
  if (it.type === "ctx") return lnum(it) + RESET + " " + it.text + RESET;
  const isAdd = it.type === "add";
  const base = faces[isAdd ? "added" : "removed"];
  const refine = faces[isAdd ? "refine-added" : "refine-removed"];
  let body: string;
  if (pair) {
    const oldTokens = tokenize(isAdd ? pair.text : it.text);
    const newTokens = tokenize(isAdd ? it.text : pair.text);
    const [oc, nc] = commonTokenIndexes(oldTokens, newTokens);
    body = isAdd ? paintByTokens(newTokens, nc, base, refine) : paintByTokens(oldTokens, oc, base, refine);
  } else {
    body = refine.paint(it.text) + base.paint("");
  }
  return RESET + lnum(it, base) + base.paint(isAdd ? "+" : "-") + RESET + body;
}

let out: string[] = [];
for (let i = 0; i < items.length; i++) {
  if (items[i].type === "del") {
    const dels: Item[] = [];
    const adds: Item[] = [];
    while (i < items.length && items[i].type === "del") dels.push(items[i++]);
    while (i < items.length && items[i].type === "add") adds.push(items[i++]);
    i--;
    for (let j = 0; j < dels.length; j++) out.push(emitItem(dels[j], adds[j]));
    for (let j = 0; j < adds.length; j++) out.push(emitItem(adds[j], dels[j]));
  } else {
    out.push(emitItem(items[i]));
  }
}

process.stdout.write(out.join("\n") + (hadFinalNewline || out.length ? "\n" : ""));
