declare const process: any;
declare function require(name: string): any;
declare const Buffer: any;

const fs = require("fs");
const path = require("path");
const http = require("http");
const https = require("https");

type Header = { name: string; value: string };
type Item =
  | { kind: "query"; key: string; value: string }
  | { kind: "field"; key: string; value: any; literal: boolean }
  | { kind: "header"; key: string; value: string | null }
  | { kind: "file"; key: string; file: string }
  | { kind: "bodyFile"; file: string };

type Opts = {
  json: boolean;
  form: boolean;
  multipart: boolean;
  raw?: string;
  offline: boolean;
  curl: boolean;
  curlLong: boolean;
  ignoreStdin: boolean;
  print?: string;
  output?: string;
  download: boolean;
  follow: boolean;
  headersOnly: boolean;
  bodyOnly: boolean;
  metaOnly: boolean;
  verbose: number;
  quiet: number;
  auth?: string;
  authType: string;
  httpsDefault: boolean;
  timeout: number;
  checkStatus: boolean;
  generate?: string;
};

const VERSION = "xh 0.25.3\n-native-tls +rustls";

const SHORT_HELP = `xh is a friendly and fast tool for sending HTTP requests

Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...

Arguments:
  <[METHOD] URL>     The request URL, preceded by an optional HTTP method
  [REQUEST_ITEM]...  Optional key-value pairs to be included in the request.

Options:
  -j, --json                             (default) Serialize data items from the command line as a JSON object
  -f, --form                             Serialize data items from the command line as form fields
      --multipart                        Like --form, but force a multipart/form-data request even without files
      --raw <RAW>                        Pass raw request data without extra processing
      --pretty <STYLE>                   Controls output processing [possible values: all, colors, format, none]
      --format-options <FORMAT_OPTIONS>  Set output formatting options
  -s, --style <THEME>                    Output coloring style [possible values: auto, solarized, monokai, fruity]
      --response-charset <ENCODING>      Override the response encoding for terminal display purposes
      --response-mime <MIME_TYPE>        Override the response mime type for coloring and formatting for the terminal
  -p, --print <FORMAT>                   String specifying what the output should contain
  -h, --headers                          Print only the response headers. Shortcut for --print=h
  -b, --body                             Print only the response body. Shortcut for --print=b
  -m, --meta                             Print only the response metadata. Shortcut for --print=m
  -v, --verbose...                       Print the whole request as well as the response
      --debug                            Print full error stack traces and debug log messages
      --all                              Show any intermediary requests/responses while following redirects with --follow
  -P, --history-print <FORMAT>           The same as --print but applies only to intermediary requests/responses
  -q, --quiet...                         Do not print to stdout or stderr
  -S, --stream                           Always stream the response body
  -x, --compress...                      Content compressed (encoded) with Deflate algorithm
  -o, --output <FILE>                    Save output to FILE instead of stdout
  -d, --download                         Download the body to a file instead of printing it
  -c, --continue                         Resume an interrupted download. Requires --download and --output
      --session <FILE>                   Create, or reuse and update a session
      --session-read-only <FILE>         Create or read a session without updating it from the request/response exchange
  -A, --auth-type <AUTH_TYPE>            Specify the auth mechanism [possible values: basic, bearer, digest]
  -a, --auth <USER[:PASS] | TOKEN>       Authenticate as USER with PASS (-A basic|digest) or with TOKEN (-A bearer)
      --ignore-netrc                     Do not use credentials from .netrc
      --offline                          Construct HTTP requests without sending them anywhere
      --check-status                     (default) Exit with an error status code if the server replies with an error
  -F, --follow                           Do follow redirects
      --max-redirects <NUM>              Number of redirects to follow. Only respected if --follow is used
      --timeout <SEC>                    Connection timeout of the request
      --proxy <PROTOCOL:URL>             Use a proxy for a protocol. For example: --proxy https:http://proxy.host:8080
      --verify <VERIFY>                  If "no", skip SSL verification. If a file path, use it as a CA bundle
      --cert <FILE>                      Use a client side certificate for SSL
      --cert-key <FILE>                  A private key file to use with --cert
      --ssl <VERSION>                    Force a particular TLS version [possible values: auto, tls1, tls1.1, tls1.2, tls1.3]
      --https                            Make HTTPS requests if not specified in the URL
      --http-version <VERSION>           HTTP version to use [possible values: 1.0, 1.1, 2, 2-prior-knowledge, 3-prior-knowledge]
      --resolve <HOST:ADDRESS>           Override DNS resolution for specific domain to a custom IP
      --interface <NAME>                 Bind to a network interface or local IP address
  -4, --ipv4                             Resolve hostname to ipv4 addresses only
  -6, --ipv6                             Resolve hostname to ipv6 addresses only
      --unix-socket <FILE>               Connect using a Unix domain socket
  -I, --ignore-stdin                     Do not attempt to read stdin
      --curl                             Print a translation to a curl command
      --curl-long                        Use the long versions of curl's flags
      --generate <KIND>                  Generate shell completions or man pages
      --help                             Print help
  -V, --version                          Print version

Each option can be reset with a --no-OPTION argument.

Run "xh help" for more complete documentation.`;

const LONG_HELP = `xh is a friendly and fast tool for sending HTTP requests.

It reimplements as much as possible of HTTPie's excellent design, with a focus on improved
performance.

Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...

Arguments:
  <[METHOD] URL>
          The request URL, preceded by an optional HTTP method.

          If the method is omitted, it will default to GET, or to POST if the request contains a
          body.

  [REQUEST_ITEM]...
          Optional key-value pairs to be included in the request.

          key==value     Add a query string to the URL.
          key=value      Add a JSON property or form field to the request body.
          key:=value     Add a field with a literal JSON value to the request body.
          key@filename   Upload a file.
          @filename      Use a file as the request body.
          header:value   Add a header.
          header:        Unset a header.
          header;        Add a header with an empty value.

${SHORT_HELP.split("\n").slice(SHORT_HELP.split("\n").findIndex(l => l === "Options:")).join("\n")}`;

function die(msg: string, code = 1): never {
  process.stderr.write(`executable: error: ${msg}\n`);
  process.exit(code);
  throw new Error(msg);
}

function readStdin(): Promise<string> {
  return new Promise((resolve) => {
    let chunks: any[] = [];
    process.stdin.on("data", (c: any) => chunks.push(c));
    process.stdin.on("end", () => resolve(Buffer.concat(chunks).toString()));
    process.stdin.resume();
  });
}

function shellQuote(s: string): string {
  if (/^[A-Za-z0-9_.,:\/@%+=-]+$/.test(s)) return s;
  return "'" + s.replace(/'/g, "'\\''") + "'";
}

function titleHeader(s: string): string {
  return s.split("-").map(p => p ? p[0].toUpperCase() + p.slice(1).toLowerCase() : p).join("-");
}

function findSep(s: string, seps: string[]): { sep: string; idx: number } | null {
  for (let i = 0; i < s.length; i++) {
    if (s[i] === "\\") { i++; continue; }
    for (const sep of seps) if (s.startsWith(sep, i)) return { sep, idx: i };
  }
  return null;
}

function unescapeKey(s: string): string {
  return s.replace(/\\([:=;@])/g, "$1");
}

function parseJsonLiteral(v: string): any {
  try { return JSON.parse(v); } catch { return v; }
}

function setDeep(obj: any, key: string, val: any) {
  const parts: (string | number)[] = [];
  let m: RegExpExecArray | null;
  const re = /([^\[\]]+)|\[([^\]]*)\]/g;
  while ((m = re.exec(key))) {
    const p = m[1] !== undefined ? m[1] : m[2];
    parts.push(/^\d+$/.test(p) ? Number(p) : p);
  }
  if (!parts.length) { obj[key] = val; return; }
  let cur = obj;
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    if (i === parts.length - 1) { cur[p as any] = val; break; }
    const n = parts[i + 1];
    if (cur[p as any] == null) cur[p as any] = typeof n === "number" ? [] : {};
    cur = cur[p as any];
  }
}

function parseItem(raw: string): Item {
  if (raw.startsWith("@") && raw.length > 1) return { kind: "bodyFile", file: raw.slice(1) };
  const found = findSep(raw, ["==", ":=", "=", ":", ";", "@"]);
  if (!found) die(`Invalid request item: ${raw}`);
  const key = unescapeKey(raw.slice(0, found.idx));
  const value = raw.slice(found.idx + found.sep.length);
  if (!key) die(`Invalid request item: ${raw}`);
  switch (found.sep) {
    case "==": return { kind: "query", key, value };
    case "=": return { kind: "field", key, value: value.startsWith("@") ? fs.readFileSync(value.slice(1), "utf8").trimEnd() : value, literal: false };
    case ":=": return { kind: "field", key, value: parseJsonLiteral(value), literal: true };
    case ":": return { kind: "header", key, value: value.startsWith("@") ? fs.readFileSync(value.slice(1), "utf8").trimEnd() : (value || null) };
    case ";": return { kind: "header", key, value: "" };
    case "@": return { kind: "file", key, file: value.split(";")[0] };
  }
  throw new Error(`Invalid request item: ${raw}`);
}

function parseArgs(argv: string[]): { opts: Opts; pos: string[] } {
  const opts: Opts = {
    json: true, form: false, multipart: false, offline: false, curl: false, curlLong: false,
    ignoreStdin: false, download: false, follow: false, headersOnly: false, bodyOnly: false,
    metaOnly: false, verbose: 0, quiet: 0, authType: "basic",
    httpsDefault: ["xhs", "https", "xhttps"].includes(path.basename(process.argv[1] || "")),
    timeout: 0, checkStatus: !process.env.XH_HTTPIE_COMPAT_MODE
  };
  const pos: string[] = [];
  const needVal = new Set(["--raw","--pretty","--format-options","--style","--response-charset","--response-mime","--print","-p","--history-print","-P","--output","-o","--session","--session-read-only","--auth-type","-A","--auth","-a","--max-redirects","--timeout","--proxy","--verify","--cert","--cert-key","--ssl","--http-version","--resolve","--interface","--unix-socket","--generate"]);
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === "--") { pos.push(...argv.slice(i + 1)); break; }
    if (!a.startsWith("-") || a === "-") { pos.push(a); continue; }
    let val: string | undefined;
    if (a.startsWith("--") && a.includes("=")) { const p = a.indexOf("="); val = a.slice(p + 1); a = a.slice(0, p); }
    if (needVal.has(a)) {
      if (val === undefined) val = argv[++i];
      if (val === undefined) die(`a value is required for '${a} <VALUE>' but none was supplied`);
    }
    switch (a) {
      case "--help": console.log(SHORT_HELP); process.exit(0);
      case "-V": case "--version": console.log(VERSION); process.exit(0);
      case "-j": case "--json": opts.json = true; opts.form = opts.multipart = false; break;
      case "-f": case "--form": opts.form = true; opts.json = opts.multipart = false; break;
      case "--multipart": opts.multipart = true; opts.form = opts.json = false; break;
      case "--raw": opts.raw = val; break;
      case "--offline": opts.offline = true; break;
      case "--curl": opts.curl = true; break;
      case "--curl-long": opts.curl = true; opts.curlLong = true; break;
      case "-I": case "--ignore-stdin": opts.ignoreStdin = true; break;
      case "-p": case "--print": opts.print = val; break;
      case "-h": case "--headers": opts.print = "h"; opts.headersOnly = true; break;
      case "-b": case "--body": opts.print = "b"; opts.bodyOnly = true; break;
      case "-m": case "--meta": opts.print = "m"; opts.metaOnly = true; break;
      case "-v": case "--verbose": opts.verbose++; opts.print = opts.verbose > 1 ? "HhBbm" : "HhBb"; break;
      case "-q": case "--quiet": opts.quiet++; break;
      case "-o": case "--output": opts.output = val; break;
      case "-d": case "--download": opts.download = true; opts.follow = true; break;
      case "-F": case "--follow": opts.follow = true; break;
      case "-a": case "--auth": opts.auth = val; break;
      case "-A": case "--auth-type": opts.authType = (val || "basic").toLowerCase(); break;
      case "--https": opts.httpsDefault = true; break;
      case "--timeout": opts.timeout = Number(val || 0); break;
      case "--generate": opts.generate = val; break;
      default:
        if (a.startsWith("--no-")) break;
        if (/^-[vq]+$/.test(a)) { for (const ch of a.slice(1)) ch === "v" ? opts.verbose++ : opts.quiet++; if (opts.verbose) opts.print = opts.verbose > 1 ? "HhBbm" : "HhBb"; break; }
        if (/^-[A-Za-z0-9]+$/.test(a) && a.length > 2) {
          for (const ch of a.slice(1)) {
            if (ch === "I") opts.ignoreStdin = true;
            else if (ch === "F") opts.follow = true;
            else if (ch === "j") { opts.json = true; opts.form = opts.multipart = false; }
            else if (ch === "f") { opts.form = true; opts.json = opts.multipart = false; }
            else if (ch === "b") opts.print = "b";
            else if (ch === "h") opts.print = "h";
            else if (ch === "v") { opts.verbose++; opts.print = opts.verbose > 1 ? "HhBbm" : "HhBb"; }
          }
          break;
        }
        break;
    }
  }
  return { opts, pos };
}

function normalizeUrl(input: string, httpsDefault: boolean): URL {
  let u = input;
  if (u.startsWith("://")) u = u.slice(3);
  if (u.startsWith(":")) {
    if (/^:\d/.test(u)) u = "localhost" + u;
    else u = "localhost" + u.slice(1);
  }
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(u)) u = (httpsDefault ? "https://" : "http://") + u;
  const url = new URL(u);
  if (!url.pathname) url.pathname = "/";
  return url;
}

function buildRequest(opts: Opts, pos: string[], stdinBody: string | null, stdinPresent: boolean) {
  if (pos[0] === "help") { console.log(LONG_HELP); process.exit(0); }
  if (opts.generate) {
    if (opts.generate === "man") {
      console.log(`.TH XH 1 2026-05-28 0.25.3 "User Commands"\n.SH NAME\nxh \\- Friendly and fast tool for sending HTTP requests\n.SH SYNOPSIS\n.B xh\n[\\fIOPTIONS\\fR] [\\fIMETHOD\\fR] \\fIURL\\fR [\\fIREQUEST_ITEM\\fR ...]`);
    } else {
      console.log(`# completion for executable\ncomplete -W "--help --version --json --form --offline --curl --curl-long --ignore-stdin --headers --body --verbose" executable`);
    }
    process.exit(0);
  }
  if (!pos.length) die("the following required arguments were not provided:\n  <[METHOD] URL>");
  const methods = new Set(["GET","POST","PUT","PATCH","DELETE","HEAD","OPTIONS","TRACE","CONNECT"]);
  let method: string | undefined;
  let urlArg: string;
  let rest: string[];
  if (pos.length >= 2 && methods.has(pos[0].toUpperCase())) {
    method = pos[0].toUpperCase(); urlArg = pos[1]; rest = pos.slice(2);
  } else {
    urlArg = pos[0]; rest = pos.slice(1);
  }
  const url = normalizeUrl(urlArg, opts.httpsDefault);
  const items = rest.map(parseItem);
  const fields = items.filter((i): i is Extract<Item,{kind:"field"}> => i.kind === "field");
  const queries = items.filter((i): i is Extract<Item,{kind:"query"}> => i.kind === "query");
  const customHeaders = items.filter((i): i is Extract<Item,{kind:"header"}> => i.kind === "header");
  const files = items.filter((i): i is Extract<Item,{kind:"file"}> => i.kind === "file");
  const bodyFile = items.find((i): i is Extract<Item,{kind:"bodyFile"}> => i.kind === "bodyFile");
  for (const q of queries) url.searchParams.append(q.key, q.value);
  const hasData = fields.length > 0 || files.length > 0 || opts.raw !== undefined || bodyFile !== undefined || stdinPresent;
  if (!method) method = hasData && (fields.length || files.length || opts.raw !== undefined || bodyFile || stdinPresent) ? "POST" : "GET";
  if (stdinPresent && (fields.length || files.length)) die("Request body (from stdin) and request data (key=value) cannot be mixed. Pass --ignore-stdin to ignore standard input.");
  if (stdinPresent && opts.raw !== undefined) die("Request body from stdin and --raw cannot be mixed. Pass --ignore-stdin to ignore standard input.");
  let body = "";
  const headers: Header[] = [
    { name: "Accept-Encoding", value: "gzip, deflate, br, zstd" },
    { name: "User-Agent", value: "xh/0.25.3" },
    { name: "Connection", value: "keep-alive" },
  ];
  for (const h of customHeaders) {
    if (!/^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/.test(h.key)) die("invalid HTTP header name");
    const idx = headers.findIndex(x => x.name.toLowerCase() === h.key.toLowerCase());
    if (idx >= 0) headers.splice(idx, 1);
    if (h.value !== null) headers.push({ name: titleHeader(h.key), value: h.value });
  }
  if (bodyFile) body = fs.readFileSync(bodyFile.file, "utf8");
  else if (opts.raw !== undefined) body = opts.raw;
  else if (stdinPresent) body = stdinBody || "";
  else if (fields.length) {
    if (opts.form) {
      body = fields.map(f => `${encodeURIComponent(f.key)}=${encodeURIComponent(String(f.value))}`).join("&");
      headers.push({ name: "Content-Type", value: "application/x-www-form-urlencoded" });
    } else {
      const obj: any = {};
      for (const f of fields) setDeep(obj, f.key, f.value);
      body = JSON.stringify(obj);
      headers.push({ name: "Accept", value: "application/json, */*;q=0.5" });
      headers.push({ name: "Content-Type", value: "application/json" });
    }
  }
  if ((opts.raw !== undefined || stdinPresent || bodyFile) && !headers.some(h => h.name.toLowerCase() === "accept")) {
    headers.push({ name: "Accept", value: "application/json, */*;q=0.5" });
    headers.push({ name: "Content-Type", value: "application/json" });
  }
  if (!headers.some(h => h.name.toLowerCase() === "accept")) headers.push({ name: "Accept", value: "*/*" });
  if (opts.auth) {
    if (opts.authType === "bearer") headers.push({ name: "Authorization", value: `Bearer ${opts.auth}` });
    else headers.push({ name: "Authorization", value: `Basic ${Buffer.from(opts.auth).toString("base64")}` });
  }
  if (body.length || method !== "GET" && method !== "HEAD") headers.push({ name: "Content-Length", value: String(Buffer.byteLength(body)) });
  headers.push({ name: "Host", value: url.host });
  return { method, url, headers, body, fields };
}

function requestText(req: any): string {
  const target = req.url.pathname + req.url.search;
  let out = `${req.method} ${target || "/"} HTTP/1.1\n`;
  for (const h of req.headers) out += `${h.name}: ${h.value}\n`;
  out += "\n";
  if (req.body) out += req.body + "\n";
  return out;
}

function curlText(req: any, opts: Opts): string {
  const long = opts.curlLong;
  const parts = ["curl"];
  if (req.method !== "GET") parts.push(long ? "--request" : "-X", req.method);
  parts.push(req.url.toString());
  const curlHeaders = [...req.headers].sort((a: Header, b: Header) => {
    const al = a.name.toLowerCase(), bl = b.name.toLowerCase();
    if (al === "content-type" && bl === "accept") return -1;
    if (al === "accept" && bl === "content-type") return 1;
    return 0;
  });
  for (const h of curlHeaders) {
    const low = h.name.toLowerCase();
    if (["accept-encoding","user-agent","connection","content-length","host"].includes(low)) continue;
    if (low === "authorization" && opts.auth) continue;
    parts.push(long ? "--header" : "-H", shellQuote(`${low}: ${h.value}`));
  }
  if (opts.auth) {
    if (opts.authType === "bearer") parts.push("--oauth2-bearer", shellQuote(opts.auth));
    else parts.push("--basic", "-u", shellQuote(opts.auth));
  }
  if (req.body) {
    if (opts.form) {
      for (const f of req.fields) parts.push("--data-urlencode", shellQuote(`${f.key}=${f.value}`));
    } else {
      parts.push(long ? "--data" : "-d", shellQuote(req.body));
    }
  }
  return parts.join(" ") + "\n";
}

function statusLine(code: number, msg: string): string {
  return `HTTP/1.1 ${code} ${msg || ""}`.trimEnd();
}

function sendHttp(req: any, opts: Opts): Promise<{statusCode:number; statusMessage:string; headers:any; body:any}> {
  return new Promise((resolve, reject) => {
    const lib = req.url.protocol === "https:" ? https : http;
    const headers: any = {};
    for (const h of req.headers) if (!["host","content-length"].includes(h.name.toLowerCase())) headers[h.name] = h.value;
    const r = lib.request(req.url, { method: req.method, headers, timeout: opts.timeout ? opts.timeout * 1000 : undefined }, (res: any) => {
      const chunks: any[] = [];
      res.on("data", (c: any) => chunks.push(c));
      res.on("end", () => resolve({ statusCode: res.statusCode, statusMessage: res.statusMessage, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    r.on("error", reject);
    r.on("timeout", () => { r.destroy(new Error("request timed out")); });
    if (req.body) r.write(req.body);
    r.end();
  });
}

async function main() {
  const { opts, pos } = parseArgs(process.argv.slice(2));
  let stdinBody: string | null = null, stdinPresent = false;
  if (!opts.ignoreStdin && !process.stdin.isTTY) {
    stdinBody = await readStdin();
    stdinPresent = true;
  }
  const req = buildRequest(opts, pos, stdinBody, stdinPresent);
  if (opts.quiet) return;
  if (opts.curl) { process.stdout.write(curlText(req, opts)); return; }
  if (opts.offline) { process.stdout.write(requestText(req)); return; }
  try {
    const res = await sendHttp(req, opts);
    const fmt = opts.print || (opts.download ? "b" : "b");
    let out = "";
    if (fmt.includes("H")) out += requestText(req) + "\n";
    if (fmt.includes("h")) {
      out += statusLine(res.statusCode, res.statusMessage) + "\n";
      for (const [k, v] of Object.entries(res.headers)) out += `${titleHeader(k)}: ${Array.isArray(v) ? v.join(", ") : v}\n`;
      out += "\n";
    }
    if (fmt.includes("b")) {
      const ctype = String(res.headers["content-type"] || "");
      let text = res.body.toString();
      if (ctype.includes("json")) {
        try { text = JSON.stringify(JSON.parse(text), null, 4) + "\n"; } catch {}
      }
      out += text;
    }
    if (opts.output) fs.writeFileSync(opts.output, fmt === "b" ? res.body : out);
    else process.stdout.write(out);
    if (opts.checkStatus) {
      if (res.statusCode >= 500) process.exit(5);
      if (res.statusCode >= 400) process.exit(4);
      if (res.statusCode >= 300 && !opts.follow) process.exit(3);
    }
  } catch (e: any) {
    die(`error sending request for url (${req.url.toString()})\n\nCaused by:\n    ${e.message || e}`);
  }
}

main();
