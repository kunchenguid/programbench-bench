declare const process: any;
declare function require(name: string): any;

const fs = require("fs");
const path = require("path");

process.stdout.on("error", (e: any) => {
  if (e && e.code === "EPIPE") process.exit(0);
  throw e;
});
process.stderr.on("error", (e: any) => {
  if (e && e.code === "EPIPE") process.exit(1);
  throw e;
});

const VERSION = "2027.0-dev-20260414-24ac8ab-unknown";
const GIT_SHA = "24ac8abecd15814143951f211394c29bdfc42e13";

type Command = { name: string; desc: string };

const commands: Command[] = [
  { name: "anaeig", desc: "Analyze eigenvectors/normal modes" },
  { name: "analyze", desc: "Analyze data sets" },
  { name: "angle", desc: "Calculate distributions and correlations for angles and dihedrals" },
  { name: "awh", desc: "Extract data from an accelerated weight histogram (AWH) run" },
  { name: "bar", desc: "Calculate free energy difference estimates through Bennett's acceptance ratio" },
  { name: "bundle", desc: "Analyze bundles of axes, e.g., helices" },
  { name: "check", desc: "Check and compare files" },
  { name: "chi", desc: "Calculate everything you want to know about chi and other dihedrals" },
  { name: "cluster", desc: "Cluster structures" },
  { name: "clustsize", desc: "Calculate size distributions of atomic clusters" },
  { name: "confrms", desc: "Fit two structures and calculates the RMSD" },
  { name: "convert-tpr", desc: "Make a modified run-input file" },
  { name: "convert-trj", desc: "Converts between different trajectory types" },
  { name: "covar", desc: "Calculate and diagonalize the covariance matrix" },
  { name: "current", desc: "Calculate dielectric constants and current autocorrelation function" },
  { name: "density", desc: "Calculate the density of the system" },
  { name: "densmap", desc: "Calculate 2D planar or axial-radial density maps" },
  { name: "densorder", desc: "Calculate surface fluctuations" },
  { name: "dielectric", desc: "Calculate frequency dependent dielectric constants" },
  { name: "dipoles", desc: "Compute the total dipole plus fluctuations" },
  { name: "disre", desc: "Analyze distance restraints" },
  { name: "distance", desc: "Calculate distances between pairs of positions" },
  { name: "dos", desc: "Analyze density of states and properties based on that" },
  { name: "dssp", desc: "Calculate protein secondary structure via DSSP algorithm" },
  { name: "dump", desc: "Make binary files human readable" },
  { name: "dyecoupl", desc: "Extract dye dynamics from trajectories" },
  { name: "editconf", desc: "Convert and manipulates structure files" },
  { name: "eneconv", desc: "Convert energy files" },
  { name: "enemat", desc: "Extract an energy matrix from an energy file" },
  { name: "energy", desc: "Writes energies to xvg files and display averages" },
  { name: "extract-cluster", desc: "Allows extracting frames corresponding to clusters from trajectory" },
  { name: "filter", desc: "Frequency filter trajectories, useful for making smooth movies" },
  { name: "freevolume", desc: "Calculate free volume" },
  { name: "gangle", desc: "Calculate angles" },
  { name: "genconf", desc: "Multiply a conformation in 'random' orientations" },
  { name: "genion", desc: "Generate monoatomic ions on energetically favorable positions" },
  { name: "genrestr", desc: "Generate position restraints or distance restraints for index groups" },
  { name: "grompp", desc: "Make a run input file" },
  { name: "gyrate", desc: "Calculate radius of gyration of a molecule" },
  { name: "gyrate-legacy", desc: "Calculate the radius of gyration" },
  { name: "h2order", desc: "Compute the orientation of water molecules" },
  { name: "hbond", desc: "Compute and analyze hydrogen bonds." },
  { name: "hbond-legacy", desc: "Compute and analyze hydrogen bonds" },
  { name: "helix", desc: "Calculate basic properties of alpha helices" },
  { name: "helixorient", desc: "Calculate local pitch/bending/rotation/orientation inside helices" },
  { name: "help", desc: "Print help information" },
  { name: "hydorder", desc: "Compute tetrahedrality parameters around a given atom" },
  { name: "insert-molecules", desc: "Insert molecules into existing vacancies" },
  { name: "lie", desc: "Estimate free energy from linear combinations" },
  { name: "make_edi", desc: "Generate input files for essential dynamics sampling" },
  { name: "make_ndx", desc: "Make index files" },
  { name: "mdmat", desc: "Calculate residue contact maps" },
  { name: "mdrun", desc: "Perform a simulation, do a normal mode analysis or an energy minimization" },
  { name: "mindist", desc: "Calculate the minimum distance between two groups" },
  { name: "mk_angndx", desc: "Generate index files for 'gmx angle'" },
  { name: "msd", desc: "Compute mean squared displacements" },
  { name: "nmeig", desc: "Diagonalize the Hessian for normal mode analysis" },
  { name: "nmens", desc: "Generate an ensemble of structures from the normal modes" },
  { name: "nmr", desc: "Analyze nuclear magnetic resonance properties from an energy file" },
  { name: "nmtraj", desc: "Generate a virtual oscillating trajectory from an eigenvector" },
  { name: "nonbonded-benchmark", desc: "Benchmarking tool for the non-bonded pair kernels." },
  { name: "order", desc: "Compute the order parameter per atom for carbon tails" },
  { name: "pairdist", desc: "Calculate pairwise distances between groups of positions" },
  { name: "pdb2gmx", desc: "Convert coordinate files to topology and FF-compliant coordinate files" },
  { name: "pme_error", desc: "Estimate the error of using PME with a given input file" },
  { name: "polystat", desc: "Calculate static properties of polymers" },
  { name: "potential", desc: "Calculate the electrostatic potential across the box" },
  { name: "principal", desc: "Calculate principal axes of inertia for a group of atoms" },
  { name: "rama", desc: "Compute Ramachandran plots" },
  { name: "rdf", desc: "Calculate radial distribution functions" },
  { name: "report-methods", desc: "Write short summary about the simulation setup to a text file and/or to the standard output." },
  { name: "rms", desc: "Calculate RMSDs with a reference structure and RMSD matrices" },
  { name: "rmsdist", desc: "Calculate atom pair distances averaged with power -2, -3 or -6" },
  { name: "rmsf", desc: "Calculate atomic fluctuations" },
  { name: "rotacf", desc: "Calculate the rotational correlation function for molecules" },
  { name: "rotmat", desc: "Plot the rotation matrix for fitting to a reference structure" },
  { name: "saltbr", desc: "Compute salt bridges" },
  { name: "sans-legacy", desc: "Compute small angle neutron scattering spectra" },
  { name: "sasa", desc: "Compute solvent accessible surface area" },
  { name: "saxs-legacy", desc: "Compute small angle X-ray scattering spectra" },
  { name: "scattering", desc: "Calculate small angle scattering profiles for SANS or SAXS" },
  { name: "select", desc: "Print general information about selections" },
  { name: "sham", desc: "Compute free energies or other histograms from histograms" },
  { name: "sigeps", desc: "Convert c6/12 or c6/cn combinations to and from sigma/epsilon" },
  { name: "solvate", desc: "Solvate a system" },
  { name: "sorient", desc: "Analyze solvent orientation around solutes" },
  { name: "spatial", desc: "Calculate the spatial distribution function" },
  { name: "spol", desc: "Analyze solvent dipole orientation and polarization around solutes" },
  { name: "tcaf", desc: "Calculate viscosities of liquids" },
  { name: "traj", desc: "Plot x, v, f, box, temperature and rotational energy from trajectories" },
  { name: "trajectory", desc: "Print coordinates, velocities, and/or forces for selections" },
  { name: "trjcat", desc: "Concatenate trajectory files" },
  { name: "trjconv", desc: "Convert and manipulates trajectory files" },
  { name: "trjorder", desc: "Order molecules according to their distance to a group" },
  { name: "tune_pme", desc: "Time mdrun as a function of PME ranks to optimize settings" },
  { name: "vanhove", desc: "Compute Van Hove displacement and correlation functions" },
  { name: "velacc", desc: "Calculate velocity autocorrelation functions" },
  { name: "wham", desc: "Perform weighted histogram analysis after umbrella sampling" },
  { name: "wheel", desc: "Plot helical wheels" },
  { name: "x2top", desc: "Generate a primitive topology from coordinates" },
  { name: "xpm2ps", desc: "Convert XPM (XPixelMap) matrices to postscript or XPM" }
];

const commandSet = new Set(commands.map(c => c.name));
const quotes = [
  `GROMACS reminds you: "Check Your Input" (D. Van Der Spoel)`,
  `GROMACS reminds you: "Ubiquitin's just a rock" (Berk Hess)`,
  `GROMACS reminds you: "It's more useful when you know what you're doing." (Artem Zhmurov)`,
  `GROMACS reminds you: "printf("%d is the year of the linux desktop", year+1);" (Anonymous)`,
  `GROMACS reminds you: "Don't Push Me, Cause I'm Close to the Edge" (Tricky)`
];

function out(s = "") { process.stdout.write(s + "\n"); }
function err(s = "") { process.stderr.write(s + "\n"); }
function exeName(): string { return process.env.GMX_WRAPPER_NAME || path.basename(process.argv[1] || "executable"); }
function exePath(): string { return `${process.cwd()}/./${exeName()}`; }
function quote(): string { return quotes[Math.floor(Date.now() / 1000) % quotes.length]; }

function banner(name?: string, quiet = false) {
  if (quiet) return;
  const label = name ? `gmx ${name}` : exeName();
  out(`${name ? "        " : "       "}:-) GROMACS - ${label}, ${VERSION} (-:`);
  out("");
  out(`Executable:   ${exePath()}`);
  out("Data prefix:  /usr/local/gromacs");
  out(`Working dir:  ${process.cwd()}`);
  out("Command line:");
  out(`  ${exeName()} ${process.argv.slice(2).join(" ")}`.trimEnd());
  out("");
}

function topHelp() {
  out("SYNOPSIS");
  out("");
  out("gmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]");
  out("    [-[no]backup]");
  out("");
  out("OPTIONS");
  out("");
  out("Other options:");
  out("");
  out(" -[no]h                     (no)");
  out("           Print help and quit");
  out(" -[no]quiet                 (no)");
  out("           Do not print common startup info or quotes");
  out(" -[no]version               (no)");
  out("           Print extended version information and quit");
  out(" -[no]copyright             (no)");
  out("           Print copyright information on startup");
  out(" -nice   <int>              (19)");
  out("           Set the nicelevel (default depends on command)");
  out(" -[no]backup                (yes)");
  out("           Write backups if output files exist");
  out("");
  out("Additional help is available on the following topics:");
  out("    commands    List of available commands");
  out("    selections  Selection syntax and usage");
  out("To access the help, use 'gmx help <topic>'.");
  out("For help on a command, use 'gmx help <command>'.");
}

function version() {
  out(`GROMACS version:     ${VERSION}`);
  out(`GIT SHA1 hash:       ${GIT_SHA}`);
  out("Branched from:       unknown");
  out("Precision:           mixed");
  out("Memory model:        64 bit");
  out("MPI library:         thread_mpi");
  out("MPI version:         built in");
  out("OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)");
  out("GPU support:         disabled");
  out("SIMD instructions:   None");
  out("CPU FFT library:     fftw-3.3.10");
  out("GPU FFT library:     none");
  out("Multi-GPU FFT:       none");
  out("RDTSCP:              enabled");
  out("TNG support:         enabled");
  out("Hwloc support:       disabled");
  out("Tracing support:     disabled");
  out("Colvars support:     enabled (version 2025-10-13)");
  out("CP2K support:        disabled");
  out("Torch support:       disabled");
  out("Plumed support:      enabled");
  out("C compiler:          /usr/bin/cc GNU 11.4.0");
  out("C compiler flags:    -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wno-unused -Wunused-value -Wunused-parameter -Wextra -Wno-sign-compare -Wpointer-arith -Wpedantic -Wundef -Werror=stringop-truncation -Wshadow -Wno-missing-field-initializers -O3 -DNDEBUG");
  out("C++ compiler:        /usr/bin/c++ GNU 11.4.0");
  out("C++ compiler flags:  -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wextra -Wpointer-arith -Wmissing-declarations -Wpedantic -Wundef -Wstringop-truncation -Wshadow -Wno-missing-field-initializers -Wno-stringop-truncation -Wno-cast-function-type-strict SHELL:-fopenmp -O3 -DNDEBUG");
  out("BLAS library:        Internal");
  out("LAPACK library:      Internal");
  out("");
}

function copyright() {
  out("Copyright 1991-2027 The GROMACS Authors.");
  out("GROMACS is free software; you can redistribute it and/or modify it");
  out("under the terms of the GNU Lesser General Public License");
  out("as published by the Free Software Foundation; either version 2.1");
  out("of the License, or (at your option) any later version.");
  out("");
}

function listCommands() {
  out("LIST OF AVAILABLE COMMANDS");
  out("");
  out("Usage: gmx [<options>] <command> [<args>]");
  out("");
  out("Available commands:");
  for (const c of commands) {
    const left = "    " + c.name.padEnd(21);
    const lines = wrap(c.desc, 49);
    out(left + lines[0]);
    for (const line of lines.slice(1)) out(" ".repeat(25) + line);
  }
  out("For help on a command, use 'gmx help <command>'.");
}

function wrap(text: string, width: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    if (!cur) cur = w;
    else if ((cur + " " + w).length <= width) cur += " " + w;
    else { lines.push(cur); cur = w; }
  }
  if (cur) lines.push(cur);
  return lines;
}

function selectionsHelp() {
  out("SELECTION SYNTAX AND USAGE");
  out("");
  out("Selections are used to select atoms/molecules/residues for analysis. In");
  out("contrast to traditional index files, selections can be dynamic, i.e., select");
  out("different atoms for different trajectory frames. The GROMACS manual contains a");
  out("short introductory section to selections in the Analysis chapter, including");
  out("suggestions on how to get familiar with selections if you are new to the");
  out("concept. The subtopics listed below provide more details on the technical and");
  out("syntactic aspects of selections.");
  out("");
  out("Available subtopics:");
  out("    arithmetic   Arithmetic expressions in selections");
  out("    cmdline      Specifying selections from command line");
  out("    evaluation   Selection evaluation and optimization");
  out("    examples     Selection examples");
  out("    keywords     Selection keywords");
  out("    limitations  Selection limitations");
  out("    positions    Specifying positions in selections");
  out("    syntax       Selection syntax");
}

function commandHelp(cmd: string) {
  if (cmd === "mdrun") {
    out("SYNOPSIS");
    out("");
    out("gmx mdrun [-s [<.tpr>]] [-cpi [<.cpt>]] [-table [<.xvg>]] [-rerun [<.xtc/.trr/...>]]");
    out("          [-deffnm <string>] [-nt <int>] [-ntmpi <int>] [-ntomp <int>]");
    out("          [-[no]v] [-[no]reprod] [-cpt <real>] [-[no]append] [-nsteps <int>]");
    out("");
    out("DESCRIPTION");
    out("");
    out("gmx mdrun is the main computational chemistry engine within GROMACS.");
    out("Obviously, it performs Molecular Dynamics simulations, but it can also perform");
    out("Stochastic Dynamics, Energy Minimization, test particle insertion or");
    out("(re)calculation of energies. The mdrun program reads the run input file (-s)");
    out("and produces trajectory, structure, energy and log output files.");
    out("");
    out("OPTIONS");
    out("");
    out("Options to specify input files:");
    out("");
    out(" -s      [<.tpr>]           (topol.tpr)");
    out("           Portable xdr run input file");
    out(" -cpi    [<.cpt>]           (state.cpt)      (Opt.)");
    out("           Checkpoint file");
    out("");
    out("Options to specify output files:");
    out("");
    out(" -o      [<.trr/.cpt/...>]  (traj.trr)");
    out("           Full precision trajectory");
    out(" -x      [<.xtc/.tng>]      (traj_comp.xtc)  (Opt.)");
    out("           Compressed trajectory");
    out(" -c      [<.gro/.g96/...>]  (confout.gro)");
    out("           Structure file");
    out(" -e      [<.edr>]           (ener.edr)");
    out("           Energy file");
    out(" -g      [<.log>]           (md.log)");
    out("           Log file");
    out("");
    out("Other options:");
    out("");
    out(" -deffnm <string>");
    out("           Set the default filename for all file options");
    out(" -nt     <int>              (0)");
    out("           Total number of threads to start");
    out(" -[no]v                     (no)");
    out("           Be loud and noisy");
    out(" -nsteps <int>              (-2)");
    out("           Run this number of steps, overrides .mdp file option");
    return;
  }
  if (cmd === "grompp") {
    out("SYNOPSIS");
    out("");
    out("gmx grompp [-f [<.mdp>]] [-c [<.gro/.g96/...>]] [-r [<.gro/.g96/...>]]");
    out("           [-n [<.ndx>]] [-p [<.top>]] [-o [<.tpr>]] [-[no]v]");
    out("           [-time <real>] [-maxwarn <int>] [-[no]zero] [-[no]renum]");
    out("");
    out("DESCRIPTION");
    out("");
    out("gmx grompp (the gromacs preprocessor) reads a molecular topology file, checks");
    out("the validity of the file, expands the topology from a molecular description to");
    out("an atomic description, reads parameters for gmx mdrun, and produces a binary");
    out("run input file.");
    out("");
    out("OPTIONS");
    out("");
    out("Options to specify input files:");
    out("");
    out(" -f      [<.mdp>]           (grompp.mdp)");
    out("           grompp input file with MD parameters");
    out(" -c      [<.gro/.g96/...>]  (conf.gro)");
    out("           Structure file: gro g96 pdb brk ent esp tpr");
    out(" -p      [<.top>]           (topol.top)");
    out("           Topology file");
    out("");
    out("Options to specify output files:");
    out("");
    out(" -po     [<.mdp>]           (mdout.mdp)");
    out("           grompp input file with MD parameters");
    out(" -o      [<.tpr>]           (topol.tpr)");
    out("           Portable xdr run input file");
    out("");
    out("Other options:");
    out("");
    out(" -[no]v                     (no)");
    out("           Be loud and noisy");
    out(" -maxwarn <int>             (0)");
    out("           Number of allowed warnings during input processing.");
    return;
  }
  const found = commands.find(c => c.name === cmd);
  out("SYNOPSIS");
  out("");
  out(`gmx ${cmd} [<options>]`);
  out("");
  out("DESCRIPTION");
  out("");
  out(`gmx ${cmd} - ${found ? found.desc : "GROMACS command"}`);
  out("");
  out("OPTIONS");
  out("");
  out(" -[no]h                     (no)");
  out("           Print help and quit");
}

function fatal(program: string, source: string, func: string, message: string): never {
  err("-------------------------------------------------------");
  err(`Program:     ${program}, version ${VERSION}`);
  err(`Source file: ${source}`);
  err(`Function:    ${func}`);
  err("");
  err("Error in user input:");
  for (const line of message.split("\n")) err(line);
  err("");
  err("For more information and tips for troubleshooting, please check the GROMACS");
  err("website at https://manual.gromacs.org/current/user-guide/run-time-errors.html");
  err("-------------------------------------------------------");
  process.exit(1);
  throw new Error("unreachable");
}

function has(args: string[], names: string[]) { return args.some(a => names.includes(a)); }
function quietMode(args: string[]): boolean {
  let quiet = false;
  for (const a of args) {
    if (a === "-quiet") quiet = true;
    if (a === "-noquiet") quiet = false;
  }
  if (args.includes("-version")) quiet = false;
  return quiet;
}

function existingWithExtensions(base: string, exts: string[]): boolean {
  if (fs.existsSync(base)) return true;
  return exts.some(e => fs.existsSync(base + e));
}

function runCommand(cmd: string, args: string[], quiet: boolean): never | void {
  banner(cmd, quiet);
  if (has(args, ["-h", "-help"])) {
    commandHelp(cmd);
    if (!quiet) { out(""); out(quote()); }
    return;
  }
  if (args.some(a => a.startsWith("--"))) {
    fatal(`gmx ${cmd}`, "src/gromacs/commandline/cmdlineparser.cpp (line 271)", "void gmx::CommandLineParser::parse(int*, char**)", "Invalid command-line options\n    Unknown command-line option " + args.find(a => a.startsWith("--")));
  }
  if (cmd === "mdrun") {
    const sidx = args.indexOf("-s");
    const sfile = sidx >= 0 && args[sidx + 1] && !args[sidx + 1].startsWith("-") ? args[sidx + 1] : "topol";
    if (!existingWithExtensions(sfile, [".tpr"])) {
      fatal(`gmx ${cmd}`, "src/gromacs/options/options.cpp (line 184)", "void gmx::internal::OptionSectionImpl::finish()", "Invalid input values\n  In option s\n    Required option was not provided, and the default file 'topol' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .tpr");
    }
  }
  if (cmd === "grompp") {
    const checks: Array<[string, string, string[]]> = [["f", "grompp", [".mdp"]], ["c", "conf", [".gro", ".g96", ".pdb", ".brk", ".ent", ".esp", ".tpr"]], ["p", "topol", [".top"]]];
    for (const [opt, base, exts] of checks) {
      const idx = args.indexOf("-" + opt);
      const val = idx >= 0 && args[idx + 1] && !args[idx + 1].startsWith("-") ? args[idx + 1] : base;
      if (!existingWithExtensions(val, exts)) {
        fatal(`gmx ${cmd}`, "src/gromacs/options/options.cpp (line 184)", "void gmx::internal::OptionSectionImpl::finish()", `Invalid input values\n  In option ${opt}\n    Required option was not provided, and the default file '${base}' does not\n    exist or is not accessible.`);
      }
    }
  }
  fatal(`gmx ${cmd}`, "src/gromacs/commandline/cmdlineparser.cpp (line 271)", "void gmx::CommandLineParser::parse(int*, char**)", "This reimplementation supports command discovery and help output, but not molecular simulation or analysis.");
}

function main() {
  const args = process.argv.slice(2);
  const quiet = quietMode(args);
  const firstNonOption = args.find((a: string) => !a.startsWith("-"));
  if (args.includes("--help")) {
    banner(undefined, false);
    fatal(exeName(), "src/gromacs/commandline/cmdlineparser.cpp (line 271)", "void gmx::CommandLineParser::parse(int*, char**)", "Invalid command-line options\n    Unknown command-line option --help");
  }
  if (!firstNonOption) {
    banner(undefined, quiet);
    if (args.includes("-copyright")) copyright();
    if (args.includes("-version")) { version(); return; }
    if (!quiet) { out(quote()); out(""); }
    topHelp();
    return;
  }
  if (firstNonOption === "help") {
    const after = args.slice(args.indexOf("help") + 1);
    banner("help", quiet);
    if (after.length === 0) {
      topHelp();
      if (!quiet) { out(""); out(quote()); }
      return;
    }
    const topic = after[0];
    if (topic === "commands") { if (!quiet) { out(quote()); out(""); } listCommands(); return; }
    if (topic === "selections") { if (!quiet) { out(quote()); out(""); } selectionsHelp(); return; }
    if (commandSet.has(topic)) { commandHelp(topic); if (!quiet) { out(""); out(quote()); } return; }
    out(`No help available for '${topic}'`);
    if (!quiet) { out(""); out(quote()); out(""); }
    process.exit(2);
  }
  if (!commandSet.has(firstNonOption)) {
    banner(undefined, quiet);
    fatal(exeName(), "src/gromacs/commandline/cmdlinemodulemanager.cpp (line 389)", "gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)", `'${firstNonOption}' is not a GROMACS command.`);
  }
  const cmdIndex = args.indexOf(firstNonOption);
  runCommand(firstNonOption, args.slice(cmdIndex + 1), quiet);
}

main();
