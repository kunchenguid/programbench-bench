declare function require(name: string): any;
declare const process: any;
declare const Buffer: any;

const fs = require("fs");
const pathMod = require("path");
const zlib = require("zlib");

type Hit = {
  raw: string;
  date: string;
  time: string;
  remote_addr: string;
  method: string;
  path: string;
  status: string;
  bytes_sent: number;
  referer: string;
  stamp: number;
};

type Options = {
  output: string;
  key: "hits" | "bytes";
  length: number;
  fields: string;
  all: boolean;
  noNameCheck: boolean;
  filters: Record<string, string[]>;
  files: string[];
};

const MONTHS: Record<string, string> = {
  Jan: "01", Feb: "02", Mar: "03", Apr: "04", May: "05", Jun: "06",
  Jul: "07", Aug: "08", Sep: "09", Oct: "10", Nov: "11", Dec: "12",
};

const DEFAULT_FIELDS = ["date", "status", "ref", "path"];
const ALL_FIELDS = ["date", "time", "method", "status", "ip", "ref", "path"];
const FIELD_ALIASES: Record<string, string> = {
  d: "date", date: "date",
  t: "time", time: "time",
  m: "method", method: "method",
  s: "status", status: "status",
  i: "ip", ip: "ip",
  r: "ref", ref: "ref", referer: "ref", referrer: "ref",
  p: "path", path: "path",
  a: "all", all: "all",
};

function usage(): void {
  console.log(`rhit 2.0.4

Rhit analyzes your nginx logs.

Usage: rhit [options] [FILES]

Options:
  --help                 Print help information
  --version              Print the version
  --color <auto|yes|no>  Whether to have styles and colors
  -k, --key <KEY>        Key used in sorting and histogram, hits or bytes
  -l, --length <LENGTH>  Detail level, from 0 to 6
  -f, --fields <FIELDS>  Comma separated list of hit fields to display
  -c, --changes          Add tables with more popular and less popular entries
  -d, --date <DATE>      Filter dates
  -i, --ip <IP>          Ip address to filter by
  -m, --method <METHOD>  HTTP method to filter by
  -p, --path <PATH>      Pattern for path filtering
  -r, --referer <REF>    Referrer filter
  -s, --status <STATUS>  Status filter
  -t, --time <TIME>      Filter time of day
  -a, --all              Show all paths, including resources
      --no-name-check    Try to open all files
  -o, --output <OUTPUT>  Output: tables, csv, json, raw
      --silent-load      Don't print anything during load`);
}

function parseArgs(argv: string[]): Options {
  const opt: Options = {
    output: "tables",
    key: "hits",
    length: 1,
    fields: "",
    all: false,
    noNameCheck: false,
    filters: {},
    files: [],
  };
  const needsValue: Record<string, keyof Options | string> = {
    "-k": "key", "--key": "key",
    "-l": "length", "--length": "length",
    "-f": "fields", "--fields": "fields", "--field": "fields",
    "-d": "date", "--date": "date",
    "-i": "ip", "--ip": "ip",
    "-m": "method", "--method": "method",
    "-p": "path", "--path": "path",
    "-r": "referer", "--referer": "referer",
    "-s": "status", "--status": "status",
    "-t": "time", "--time": "time",
    "-o": "output", "--output": "output",
    "--color": "color",
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help") {
      usage();
      process.exit(0);
    } else if (a === "--version") {
      console.log("rhit 2.0.4");
      process.exit(0);
    } else if (a === "-a" || a === "--all") {
      opt.all = true;
    } else if (a === "--no-name-check") {
      opt.noNameCheck = true;
    } else if (a === "-c" || a === "--changes" || a === "--silent-load") {
      continue;
    } else if (a.startsWith("--") && a.includes("=")) {
      const [name, value] = a.split(/=(.*)/, 2);
      applyArg(opt, needsValue[name], value);
    } else if (needsValue[a]) {
      i++;
      applyArg(opt, needsValue[a], argv[i] ?? "");
    } else if (a.startsWith("-")) {
      console.error(`Error: Unknown flag ${a}`);
      process.exit(1);
    } else {
      opt.files.push(a);
    }
  }
  opt.output = normalizeOutput(opt.output);
  if (opt.key.startsWith("b" as any)) opt.key = "bytes";
  else opt.key = "hits";
  return opt;
}

function applyArg(opt: Options, target: keyof Options | string | undefined, value: string): void {
  if (!target || target === "color") return;
  if (target === "length") opt.length = Number.parseInt(value, 10) || 1;
  else if (target === "key") opt.key = value as any;
  else if (target === "fields") opt.fields = value;
  else if (target === "output") opt.output = value;
  else {
    if (!opt.filters[target]) opt.filters[target] = [];
    opt.filters[target].push(value);
  }
}

function normalizeOutput(s: string): string {
  const v = (s || "tables").toLowerCase();
  if (v === "r") return "raw";
  if (v === "c") return "csv";
  if (v === "j") return "json";
  if (v === "t") return "tables";
  return v;
}

function collectFiles(inputs: string[], noNameCheck: boolean): string[] {
  if (inputs.length === 0) {
    inputs = ["/var/log/nginx/access.log", "/var/log/nginx", "/var/log/apache2/access.log"];
  }
  const out: string[] = [];
  const visit = (p: string) => {
    if (!fs.existsSync(p)) return;
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      for (const name of fs.readdirSync(p).sort()) visit(pathMod.join(p, name));
    } else if (noNameCheck || isLogName(p)) {
      out.push(p);
    }
  };
  for (const input of inputs) visit(input);
  return out;
}

function isLogName(p: string): boolean {
  const b = pathMod.basename(p);
  return /access\.log|access\.log\.\d+|\.log$|\.log\.gz$|access.*\.gz$/i.test(b);
}

function readFileText(file: string): string {
  const data = fs.readFileSync(file);
  if (file.endsWith(".gz")) return zlib.gunzipSync(data).toString("utf8");
  return data.toString("utf8");
}

function parseHit(line: string): Hit | null {
  const re = /^(\S+) \S+ \S+ \[(\d{1,2})\/([A-Za-z]{3})\/(\d{4}):(\d\d):(\d\d):(\d\d) [^\]]+\] "([^"]*)" (\d{3}) (\S+) "([^"]*)" "([^"]*)"/;
  const m = line.match(re);
  if (!m) return null;
  const bytes = Number.parseInt(m[10], 10);
  if (!Number.isFinite(bytes)) return null;
  const day = m[2].padStart(2, "0");
  const month = MONTHS[m[3]];
  if (!month) return null;
  const date = `${m[4]}/${month}/${day}`;
  const time = `${m[5]}:${m[6]}:${m[7]}`;
  const req = m[8];
  let method = "none";
  let reqPath = req;
  const rm = req.match(/^([A-Z]+)\s+(\S+)(?:\s+HTTP\/[0-9.]+)?$/);
  if (rm) {
    method = rm[1];
    reqPath = rm[2];
  }
  const q = reqPath.indexOf("?");
  if (q >= 0) reqPath = reqPath.slice(0, q);
  return {
    raw: line,
    date,
    time,
    remote_addr: m[1],
    method,
    path: reqPath,
    status: m[9],
    bytes_sent: bytes,
    referer: m[11],
    stamp: Date.UTC(Number(m[4]), Number(month) - 1, Number(day), Number(m[5]), Number(m[6]), Number(m[7])),
  };
}

function loadHits(files: string[]): Hit[] {
  const hits: Hit[] = [];
  for (const file of files) {
    for (const line of readFileText(file).split(/\r?\n/)) {
      if (!line) continue;
      const hit = parseHit(line);
      if (hit) hits.push(hit);
    }
  }
  return hits;
}

function filterHits(hits: Hit[], opt: Options): Hit[] {
  return hits.filter(h => {
    for (const pat of opt.filters.path || []) if (!matchTextExpr(h.path, pat)) return false;
    for (const pat of opt.filters.referer || []) if (!matchTextExpr(h.referer, pat)) return false;
    for (const pat of opt.filters.ip || []) if (!matchSimple(h.remote_addr, pat)) return false;
    for (const pat of opt.filters.method || []) if (!matchSimple(h.method, pat)) return false;
    for (const pat of opt.filters.status || []) if (!matchStatus(h.status, pat)) return false;
    for (const pat of opt.filters.date || []) if (!matchDate(h, pat, hits)) return false;
    for (const pat of opt.filters.time || []) if (!matchTime(h.time, pat)) return false;
    return true;
  });
}

function makeRegex(pat: string): RegExp {
  return new RegExp(pat);
}

function matchSimple(value: string, pat: string): boolean {
  let neg = false;
  if (pat.startsWith("!")) {
    neg = true;
    pat = pat.slice(1);
  }
  const ok = makeRegex(pat).test(value);
  return neg ? !ok : ok;
}

function matchTextExpr(value: string, expr: string): boolean {
  const parts = splitTop(expr, ",");
  return parts.every(part => evalBoolExpr(value, part.trim()));
}

function splitTop(s: string, sep: string): string[] {
  const out: string[] = [];
  let depth = 0, cur = "";
  for (const ch of s) {
    if (ch === "(") depth++;
    if (ch === ")") depth--;
    if (ch === sep && depth === 0) {
      out.push(cur);
      cur = "";
    } else cur += ch;
  }
  out.push(cur);
  return out.filter(x => x.length > 0);
}

function evalBoolExpr(value: string, expr: string): boolean {
  expr = expr.trim();
  if (!expr) return true;
  if (!hasBooleanOperators(expr)) {
    let neg = false;
    if (expr.startsWith("!")) {
      neg = true;
      expr = expr.slice(1).trim();
    }
    const ok = makeRegex(expr).test(value);
    return neg ? !ok : ok;
  }
  const tokens = tokenizeExpr(expr);
  let pos = 0;
  const parseOr = (): boolean => {
    let v = parseAnd();
    while (tokens[pos] === "|") {
      pos++;
      v = parseAnd() || v;
    }
    return v;
  };
  const parseAnd = (): boolean => {
    let v = parseFactor();
    while (tokens[pos] === "&") {
      pos++;
      v = parseFactor() && v;
    }
    return v;
  };
  const parseFactor = (): boolean => {
    const t = tokens[pos++];
    if (t === "!") return !parseFactor();
    if (t === "(") {
      const v = parseOr();
      if (tokens[pos] === ")") pos++;
      return v;
    }
    return makeRegex(t || "").test(value);
  };
  return parseOr();
}

function hasBooleanOperators(expr: string): boolean {
  return /(^|\s)[&|](\s|$)/.test(expr) || /(^|\s)!\s*\(/.test(expr);
}

function tokenizeExpr(expr: string): string[] {
  const out: string[] = [];
  let cur = "";
  for (let i = 0; i < expr.length; i++) {
    const ch = expr[i];
    if (/\s/.test(ch)) {
      if (cur) { out.push(cur); cur = ""; }
    } else if ("()&|!".includes(ch)) {
      if (cur) { out.push(cur); cur = ""; }
      out.push(ch);
    } else cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

function matchStatus(status: string, spec: string): boolean {
  const tokens = spec.split(",").map(s => s.trim()).filter(Boolean);
  const positives = tokens.filter(t => !t.startsWith("!"));
  const negatives = tokens.filter(t => t.startsWith("!")).map(t => t.slice(1));
  if (negatives.some(t => statusToken(status, t))) return false;
  if (positives.length === 0) return true;
  return positives.some(t => statusToken(status, t));
}

function statusToken(status: string, token: string): boolean {
  const n = Number(status);
  const cm = token.match(/^(\d)xx$/i);
  if (cm) return Math.floor(n / 100) === Number(cm[1]);
  const rm = token.match(/^(\d+)-(\d+)$/);
  if (rm) return n >= Number(rm[1]) && n <= Number(rm[2]);
  return status === token;
}

function parseDatePart(part: string, hits: Hit[], end: boolean): number {
  const bits = part.split(/[\/T:]/).filter(Boolean).map(x => Number.parseInt(x, 10));
  let year: number, month = 1, day = 1, hour = 0, min = 0, sec = 0;
  if (bits.length === 1) {
    year = bits[0];
    if (end) { month = 12; day = 31; hour = 23; min = 59; sec = 59; }
  } else if (bits.length === 2) {
    if (bits[0] > 31) {
      year = bits[0]; month = bits[1];
    } else {
      year = inferYear(hits); month = bits[0]; day = bits[1];
    }
    if (end) { day = lastDay(year, month); hour = 23; min = 59; sec = 59; }
  } else {
    year = bits[0]; month = bits[1]; day = bits[2];
    if (bits.length > 3) hour = bits[3];
    if (bits.length > 4) min = bits[4];
    if (bits.length > 5) sec = bits[5];
    else if (end && bits.length <= 3) { hour = 23; min = 59; sec = 59; }
    else if (end && bits.length === 4) { min = 59; sec = 59; }
    else if (end && bits.length === 5) { sec = 59; }
  }
  return Date.UTC(year, month - 1, day, hour, min, sec);
}

function inferYear(hits: Hit[]): number {
  const years = Array.from(new Set(hits.map(h => Number(h.date.slice(0, 4)))));
  return years.length === 1 ? years[0] : new Date().getUTCFullYear();
}

function lastDay(year: number, month: number): number {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

function matchDate(h: Hit, spec: string, hits: Hit[]): boolean {
  let neg = false;
  if (spec.startsWith("!")) { neg = true; spec = spec.slice(1); }
  let ok: boolean;
  if (spec.startsWith(">")) ok = h.stamp > parseDatePart(spec.slice(1), hits, true);
  else if (spec.startsWith("<")) ok = h.stamp < parseDatePart(spec.slice(1), hits, false);
  else if (spec.includes("-")) {
    const [a, b] = spec.split("-", 2);
    ok = h.stamp >= parseDatePart(a, hits, false) && h.stamp <= parseDatePart(b, hits, true);
  } else {
    ok = h.stamp >= parseDatePart(spec, hits, false) && h.stamp <= parseDatePart(spec, hits, true);
  }
  return neg ? !ok : ok;
}

function seconds(t: string): number {
  const [h, m, s] = t.split(":").map(Number);
  return h * 3600 + m * 60 + (s || 0);
}

function matchTime(time: string, spec: string): boolean {
  let neg = false;
  if (spec.startsWith("!")) { neg = true; spec = spec.slice(1); }
  const val = seconds(time);
  let ok: boolean;
  if (spec.startsWith(">")) ok = val > seconds(normalizeTime(spec.slice(1), true));
  else if (spec.startsWith("<")) ok = val < seconds(normalizeTime(spec.slice(1), false));
  else if (spec.includes("-")) {
    const [a, b] = spec.split("-", 2);
    ok = val >= seconds(normalizeTime(a, false)) && val <= seconds(normalizeTime(b, true));
  } else ok = val >= seconds(normalizeTime(spec, false)) && val <= seconds(normalizeTime(spec, true));
  return neg ? !ok : ok;
}

function normalizeTime(t: string, end: boolean): string {
  const parts = t.split(":");
  while (parts.length < 3) parts.push(end ? "59" : "00");
  return parts.map((p, i) => i === 0 ? p.padStart(2, "0") : p.padStart(2, "0")).join(":");
}

function csvEscape(v: string): string {
  return `"${v.replace(/"/g, "\"\"")}"`;
}

function outputCsv(hits: Hit[]): void {
  console.log("date,time,remote address,method,path,status,bytes sent,referer");
  for (const h of hits) {
    console.log([h.date, h.time, h.remote_addr, h.method, csvEscape(h.path), h.status, String(h.bytes_sent), csvEscape(h.referer)].join(","));
  }
}

function outputJson(hits: Hit[]): void {
  const arr = hits.map(h => ({
    date: h.date,
    time: h.time,
    remote_addr: h.remote_addr,
    method: h.method,
    path: h.path,
    status: h.status,
    bytes_sent: h.bytes_sent,
    referer: h.referer,
  }));
  console.log(JSON.stringify(arr, null, 2));
}

function outputRaw(hits: Hit[]): void {
  for (const h of hits) console.log(h.raw);
}

function selectedFields(spec: string): string[] {
  if (!spec) return DEFAULT_FIELDS.slice();
  let fields = spec.startsWith("+") || spec.startsWith("-") ? DEFAULT_FIELDS.slice() : [];
  const parts = spec.match(/[+-]?[^+-]+/g) || [];
  for (const raw of parts) {
    const op = raw[0] === "+" || raw[0] === "-" ? raw[0] : "+";
    const nameRaw = raw.replace(/^[+-]/, "");
    const names = nameRaw.split(/[, ]+/).filter(Boolean);
    for (const n of names) {
      const alias = FIELD_ALIASES[n.toLowerCase()];
      const singularAlias = alias || FIELD_ALIASES[n.toLowerCase().replace(/s$/, "")];
      const expanded = singularAlias === "all" ? ALL_FIELDS : [singularAlias || n];
      for (const e of expanded) {
        if (op === "-") fields = fields.filter(f => f !== e);
        else {
          fields = fields.filter(f => f !== e);
          fields.push(e);
        }
      }
    }
  }
  return fields;
}

function outputTables(hits: Hit[], opt: Options): void {
  const bytes = hits.reduce((s, h) => s + h.bytes_sent, 0);
  if (hits.length === 0) {
    console.log("0 hits");
    return;
  }
  const min = hits.reduce((a, h) => h.date < a ? h.date : a, hits[0].date);
  const max = hits.reduce((a, h) => h.date > a ? h.date : a, hits[0].date);
  console.log(`${hits.length} hits and ${bytes} from ${min} to ${max}`);
  for (const field of selectedFields(opt.fields)) {
    if (field === "date") printDateTable(hits, opt);
    else if (field === "time") printTimeTable(hits, opt);
    else printValueTable(hits, field, opt);
  }
}

function valueFor(h: Hit, field: string): string {
  if (field === "ip") return h.remote_addr;
  if (field === "ref") return h.referer;
  return (h as any)[field] ?? "";
}

function isResource(p: string): boolean {
  return /\.(?:png|jpe?g|gif|webp|svg|ico|css|js|map|woff2?|ttf|eot|mp4|mp3|avi|mov|pdf|zip|gz|tar|rar)$/i.test(p);
}

function printValueTable(hits: Hit[], field: string, opt: Options): void {
  let source = hits;
  if (field === "path" && !opt.all) source = hits.filter(h => !isResource(h.path));
  if (field === "ref") source = source.filter(h => h.referer !== "-");
  const map = new Map<string, { hits: number; bytes: number }>();
  for (const h of source) {
    const v = valueFor(h, field);
    const row = map.get(v) || { hits: 0, bytes: 0 };
    row.hits++;
    row.bytes += h.bytes_sent;
    map.set(v, row);
  }
  const rows = Array.from(map.entries()).sort((a, b) => {
    const k = opt.key === "bytes" ? b[1].bytes - a[1].bytes : b[1].hits - a[1].hits;
    return k || a[0].localeCompare(b[0]);
  }).slice(0, tableLimit(opt.length));
  const title = field === "ip" ? "remote IP addresses" : field === "ref" ? "referrers" : field === "status" ? "HTTP status codes" : `${field}s`;
  console.log(`${map.size} ${title}.`);
  console.log(`#\t${field}\thits\t%\tbytes`);
  let i = 1;
  for (const [v, r] of rows) {
    console.log(`${i++}\t${v}\t${r.hits}\t${((r.hits * 100) / hits.length).toFixed(1)}%\t${r.bytes}`);
  }
}

function printDateTable(hits: Hit[], opt: Options): void {
  const map = new Map<string, { hits: number; bytes: number }>();
  for (const h of hits) {
    const row = map.get(h.date) || { hits: 0, bytes: 0 };
    row.hits++;
    row.bytes += h.bytes_sent;
    map.set(h.date, row);
  }
  console.log("date\thits\tbytes");
  for (const [d, r] of Array.from(map.entries()).sort()) console.log(`${d}\t${r.hits}\t${r.bytes}`);
}

function printTimeTable(hits: Hit[], opt: Options): void {
  const rows = Array.from({ length: 24 }, () => ({ hits: 0, bytes: 0 }));
  for (const h of hits) {
    const hour = Number(h.time.slice(0, 2));
    rows[hour].hits++;
    rows[hour].bytes += h.bytes_sent;
  }
  console.log("hour\thits\tbytes");
  rows.forEach((r, i) => console.log(`${i}\t${r.hits}\t${r.bytes}`));
}

function tableLimit(length: number): number {
  return [5, 10, 20, 30, 50, 100, 100000][Math.max(0, Math.min(6, length))] || 10;
}

function main(): void {
  try {
    const opt = parseArgs(process.argv.slice(2));
    const files = collectFiles(opt.files, opt.noNameCheck);
    const hits = filterHits(loadHits(files), opt);
    if (opt.output === "raw") outputRaw(hits);
    else if (opt.output === "csv") outputCsv(hits);
    else if (opt.output === "json") outputJson(hits);
    else outputTables(hits, opt);
  } catch (e: any) {
    console.error(`Error: ${e?.message || e}`);
    process.exit(1);
  }
}

main();
