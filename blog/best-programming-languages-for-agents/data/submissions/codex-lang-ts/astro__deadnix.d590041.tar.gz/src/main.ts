declare const require: any;
declare const process: any;
const fs = require("fs");
const path = require("path");

type Kind = "let binding" | "lambda argument" | "lambda pattern";
type Finding = {
  file: string;
  line: number;
  column: number;
  endColumn: number;
  name: string;
  message: string;
  kind: Kind | "used let binding";
  start: number;
  end: number;
  lineStart: number;
  lineEnd: number;
};

type Options = {
  noLambdaArg: boolean;
  noLambdaPatternNames: boolean;
  noUnderscore: boolean;
  warnUsedUnderscore: boolean;
  quiet: boolean;
  edit: boolean;
  hidden: boolean;
  fail: boolean;
  outputFormat: "human-readable" | "json";
  excludes: string[];
  paths: string[];
};

const VERSION = "deadnix 1.3.1";

function help(): string {
  return `Find dead code in .nix files

Usage: executable [OPTIONS] [FILE_PATHS]...

Arguments:
  [FILE_PATHS]...  .nix files, or directories with .nix files inside [default: .]

Options:
  -l, --no-lambda-arg                  Don't check lambda parameter arguments
  -L, --no-lambda-pattern-names        Don't check lambda attrset pattern names (don't break nixpkgs callPackage)
  -_, --no-underscore                  Don't check any bindings that start with a _
                                       (Lambda arguments starting with _ are not checked anyway.)
  -W, --warn-used-underscore           Warn if bindings are referenced that start with '_'
  -q, --quiet                          Don't print dead code report
  -e, --edit                           Remove unused code and write to source file
  -h, --hidden                         Recurse into hidden subdirectories and process hidden .*.nix files
      --help                           
  -f, --fail                           Exit with 1 if unused code has been found
  -o, --output-format <OUTPUT_FORMAT>  Output format to use [default: human-readable] [possible values: human-readable, json]
      --exclude <EXCLUDES>...          Files to exclude from analysis
  -V, --version                        Print version`;
}

function parseArgs(argv: string[]): Options {
  const opt: Options = {
    noLambdaArg: false,
    noLambdaPatternNames: false,
    noUnderscore: false,
    warnUsedUnderscore: false,
    quiet: false,
    edit: false,
    hidden: false,
    fail: false,
    outputFormat: "human-readable",
    excludes: [],
    paths: [],
  };
  let onlyPaths = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (onlyPaths) {
      opt.paths.push(a);
      continue;
    }
    if (a === "--") {
      onlyPaths = true;
    } else if (a === "--help") {
      console.log(help());
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      console.log(VERSION);
      process.exit(0);
    } else if (a === "-l" || a === "--no-lambda-arg") opt.noLambdaArg = true;
    else if (a === "-L" || a === "--no-lambda-pattern-names") opt.noLambdaPatternNames = true;
    else if (a === "-_" || a === "--no-underscore") opt.noUnderscore = true;
    else if (a === "-W" || a === "--warn-used-underscore") opt.warnUsedUnderscore = true;
    else if (a === "-q" || a === "--quiet") opt.quiet = true;
    else if (a === "-e" || a === "--edit") opt.edit = true;
    else if (a === "-h" || a === "--hidden") opt.hidden = true;
    else if (a === "-f" || a === "--fail") opt.fail = true;
    else if (a === "-o" || a === "--output-format") {
      const v = argv[++i];
      if (v !== "human-readable" && v !== "json") {
        console.error(`error: invalid value '${v}' for '--output-format <OUTPUT_FORMAT>'`);
        console.error("  [possible values: human-readable, json]\n");
        console.error("For more information, try '--help'.");
        process.exit(2);
      }
      opt.outputFormat = v as "human-readable" | "json";
    } else if (a === "--exclude") {
      while (i + 1 < argv.length && !argv[i + 1].startsWith("-")) opt.excludes.push(argv[++i]);
    } else if (a.startsWith("-") && a.length > 1) {
      for (let j = 1; j < a.length; j++) {
        const c = a[j];
        if (c === "l") opt.noLambdaArg = true;
        else if (c === "L") opt.noLambdaPatternNames = true;
        else if (c === "_") opt.noUnderscore = true;
        else if (c === "W") opt.warnUsedUnderscore = true;
        else if (c === "q") opt.quiet = true;
        else if (c === "e") opt.edit = true;
        else if (c === "h") opt.hidden = true;
        else if (c === "f") opt.fail = true;
        else {
          console.error(`error: unexpected argument '${a}' found\n`);
          console.error("Usage: executable [OPTIONS] [FILE_PATHS]...\n");
          console.error("For more information, try '--help'.");
          process.exit(2);
        }
      }
    } else opt.paths.push(a);
  }
  if (opt.paths.length === 0) opt.paths.push(".");
  return opt;
}

function lineStarts(s: string): number[] {
  const r = [0];
  for (let i = 0; i < s.length; i++) if (s[i] === "\n") r.push(i + 1);
  return r;
}

function posOf(starts: number[], idx: number): { line: number; column: number } {
  let lo = 0, hi = starts.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (starts[mid] <= idx) lo = mid + 1;
    else hi = mid - 1;
  }
  return { line: hi + 1, column: idx - starts[hi] + 1 };
}

function lineBounds(s: string, idx: number): [number, number] {
  const a = s.lastIndexOf("\n", Math.max(0, idx - 1)) + 1;
  const nl = s.indexOf("\n", idx);
  return [a, nl < 0 ? s.length : nl + 1];
}

function maskSource(s: string): string {
  const a = s.split("");
  for (let i = 0; i < s.length; i++) {
    if (s[i] === "#") {
      while (i < s.length && s[i] !== "\n") a[i++] = " ";
      i--;
    } else if (s[i] === '"') {
      a[i++] = " ";
      while (i < s.length) {
        if (s[i] === "\\" && i + 1 < s.length) {
          a[i++] = " "; a[i] = " ";
        } else if (s[i] === "$" && s[i + 1] === "{") {
          i += 2;
          let depth = 1;
          while (i < s.length && depth > 0) {
            if (s[i] === "{") depth++;
            else if (s[i] === "}") depth--;
            i++;
          }
          i--;
        } else if (s[i] === '"') {
          a[i] = " ";
          break;
        } else if (s[i] !== "\n") a[i] = " ";
        i++;
      }
    } else if (s[i] === "'" && s[i + 1] === "'") {
      a[i++] = " "; a[i++] = " ";
      while (i < s.length) {
        if (s[i] === "$" && s[i + 1] === "{") {
          i += 2;
          let depth = 1;
          while (i < s.length && depth > 0) {
            if (s[i] === "{") depth++;
            else if (s[i] === "}") depth--;
            i++;
          }
          i--;
        } else if (s[i] === "'" && s[i + 1] === "'") {
          a[i++] = " "; a[i] = " ";
          break;
        } else if (s[i] !== "\n") a[i] = " ";
        i++;
      }
    }
  }
  return a.join("");
}

function collectTokens(masked: string): Map<string, number[]> {
  const m = new Map<string, number[]>();
  const re = /\b[A-Za-z_][A-Za-z0-9_'-]*\b/g;
  let x: RegExpExecArray | null;
  while ((x = re.exec(masked))) {
    const k = x[0];
    if (!m.has(k)) m.set(k, []);
    m.get(k)!.push(x.index);
  }
  return m;
}

function isDeclPosition(pos: number, decls: Finding[]): boolean {
  return decls.some(d => pos >= d.start && pos < d.end);
}

function nextSameDecl(pos: number, name: string, decls: Finding[]): number {
  let n = Infinity;
  for (const d of decls) if (d.name === name && d.start > pos && d.start < n) n = d.start;
  return n;
}

function makeFinding(file: string, starts: number[], source: string, name: string, start: number, kind: Kind, lineStart?: number, lineEnd?: number): Finding {
  const p = posOf(starts, start);
  const [ls, le] = lineStart === undefined ? lineBounds(source, start) : [lineStart, lineEnd!];
  return {
    file,
    line: p.line,
    column: p.column,
    endColumn: p.column + name.length,
    name,
    kind,
    message: `Unused ${kind}: ${name}`,
    start,
    end: start + name.length,
    lineStart: ls,
    lineEnd: le,
  };
}

function analyzeFile(file: string, opt: Options): { source: string; findings: Finding[] } {
  const source = fs.readFileSync(file, "utf8");
  const masked = maskSource(source);
  const starts = lineStarts(source);
  const decls: Finding[] = [];
  const lines = source.split(/(?<=\n)/);
  let off = 0;
  let inLet = false;
  let skipNext = false;
  for (const line of lines) {
    const trimmedMask = maskSource(line);
    if (/^\s*in\b/.test(trimmedMask)) inLet = false;
    if (/^\s*let\s*$/.test(trimmedMask)) inLet = true;
    if (/deadnix:\s*skip/.test(line)) skipNext = true;
    if (inLet && !skipNext) {
      let mm = /^(\s*)([A-Za-z_][A-Za-z0-9_'-]*)(?:\.[^=;]+)?\s*=/.exec(trimmedMask);
      if (mm) {
        const name = mm[2];
        decls.push(makeFinding(file, starts, source, name, off + mm[1].length, "let binding", off, off + line.length));
      }
      mm = /^(\s*)inherit(?:\s*\([^)]*\))?\s+([^;]+);/.exec(trimmedMask);
      if (mm) {
        const base = off + mm[0].indexOf(mm[2]);
        const re = /\b[A-Za-z_][A-Za-z0-9_'-]*\b/g;
        let x: RegExpExecArray | null;
        while ((x = re.exec(mm[2]))) decls.push(makeFinding(file, starts, source, x[0], base + x.index, "let binding", off, off + line.length));
      }
    }
    if (!skipNext) {
      const inlineLet = /\blet\s+([A-Za-z_][A-Za-z0-9_'-]*)\s*=/.exec(trimmedMask);
      if (inlineLet) {
        decls.push(makeFinding(file, starts, source, inlineLet[1], off + inlineLet.index + inlineLet[0].indexOf(inlineLet[1]), "let binding", off, off + line.length));
      }
    }
    if (skipNext && !/deadnix:\s*skip/.test(line)) skipNext = false;
    off += line.length;
  }

  {
    const attrLambda = /([A-Za-z_][A-Za-z0-9_'-]*\s*@\s*)?\{([^{}]*)\}(\s*@\s*[A-Za-z_][A-Za-z0-9_'-]*)?\s*:/g;
    let m: RegExpExecArray | null;
    while ((m = attrLambda.exec(masked))) {
      const before = m[1];
      const body = m[2];
      const after = m[3];
      if (before) {
        const nm = before.match(/[A-Za-z_][A-Za-z0-9_'-]*/)?.[0];
        if (nm) decls.push(makeFinding(file, starts, source, nm, m.index + before.indexOf(nm), "lambda pattern"));
      }
      const bodyStart = m.index + (before ? before.length : 0) + 1;
      if (!opt.noLambdaPatternNames) {
        const partRe = /(?:^|,)\s*([A-Za-z_][A-Za-z0-9_'-]*)/g;
        let p: RegExpExecArray | null;
        while ((p = partRe.exec(body))) {
          const nm = p[1];
          if (nm !== "...") decls.push(makeFinding(file, starts, source, nm, bodyStart + p.index + p[0].lastIndexOf(nm), "lambda pattern"));
        }
      }
      if (after) {
        const nm = after.match(/[A-Za-z_][A-Za-z0-9_'-]*/)?.[0];
        if (nm) decls.push(makeFinding(file, starts, source, nm, m.index + m[0].lastIndexOf(nm), "lambda pattern"));
      }
    }
  }

  if (!opt.noLambdaArg) {
    const simple = /(^|[=\s(])([A-Za-z_][A-Za-z0-9_'-]*)\s*:/g;
    let m: RegExpExecArray | null;
    while ((m = simple.exec(masked))) {
      const start = m.index + m[1].length;
      const name = m[2];
      if (name.startsWith("_")) continue;
      const prev = masked.slice(Math.max(0, start - 3), start);
      if (prev.includes("@")) continue;
      const ahead = masked.slice(start + name.length).trimStart();
      if (ahead.startsWith(":")) decls.push(makeFinding(file, starts, source, name, start, "lambda argument"));
    }
  }

  const tokens = collectTokens(masked);
  const findings: Finding[] = [];
  for (const d of decls) {
    if (opt.noUnderscore && d.name.startsWith("_")) continue;
    const poss = tokens.get(d.name) || [];
    const limit = nextSameDecl(d.start, d.name, decls);
    const used = poss.some(p => {
      if (p === d.start || isDeclPosition(p, decls)) return false;
      if (d.kind === "lambda pattern") return true;
      return p > d.start && p < limit;
    });
    if (d.name.startsWith("_") && used && opt.warnUsedUnderscore && d.kind === "let binding") {
      findings.push({ ...d, kind: "used let binding", message: `Used let binding: ${d.name}` });
    } else if (!used) findings.push(d);
  }
  findings.sort((a, b) => a.line - b.line || a.column - b.column || a.message.localeCompare(b.message));
  return { source, findings };
}

function applyEdit(source: string, findings: Finding[]): string {
  const unused = findings.filter(f => !f.message.startsWith("Used "));
  let s = source;
  const fullLine = new Set<number>();
  for (const f of unused) if (f.kind === "let binding") fullLine.add(f.lineStart);
  const removeRanges: [number, number][] = [];
  for (const ls of fullLine) {
    const fs = unused.filter(f => f.lineStart === ls && f.kind === "let binding");
    const line = source.slice(fs[0].lineStart, fs[0].lineEnd);
    if (/^\s*inherit\b/.test(line)) {
      const names = [...line.matchAll(/\b[A-Za-z_][A-Za-z0-9_'-]*\b/g)].filter(x => x[0] !== "inherit");
      const bad = new Set(fs.map(f => f.name));
      const declared = names.filter(x => !line.slice(0, x.index).endsWith("("));
      if (declared.every(x => bad.has(x[0]))) removeRanges.push([fs[0].lineStart, fs[0].lineEnd]);
    } else removeRanges.push([fs[0].lineStart, fs[0].lineEnd]);
  }
  for (const f of unused) if (f.kind === "lambda pattern") {
    let a = f.start, b = f.end;
    let pre = a - 1;
    while (pre > 0 && /[ \t]/.test(source[pre])) pre--;
    if (source[pre] !== "{") {
      while (a > 0 && /[ \t]/.test(source[a - 1])) a--;
    }
    if (source[b] === ",") b++;
    while (b < source.length && /[ \t]/.test(source[b])) b++;
    if (source[a - 1] === "," && (source[b] === "}" || source[b] === ":")) a--;
    if (source.slice(f.end, f.end + 1) === "@") {
      b = f.end + 1;
      while (b < source.length && /\s/.test(source[b])) b++;
    }
    removeRanges.push([a, b]);
  }
  removeRanges.sort((a, b) => b[0] - a[0]);
  for (const [a, b] of removeRanges) s = s.slice(0, a) + s.slice(b);
  return s;
}

function collectFiles(pathsIn: string[], opt: Options): string[] {
  const out: string[] = [];
  const excluded = opt.excludes.map(e => path.resolve(e));
  const skip = (p: string) => excluded.some(e => path.resolve(p) === e || path.resolve(p).startsWith(e + path.sep));
  function walk(p: string) {
    if (skip(p)) return;
    let st: any;
    try { st = fs.statSync(p); } catch (e: any) { console.error(`Error stating file ${p}: ${e.message}`); return; }
    const base = path.basename(p);
    if (!opt.hidden && base.startsWith(".") && p !== ".") return;
    if (st.isDirectory()) {
      for (const ent of fs.readdirSync(p).sort()) walk(path.join(p, ent));
    } else if (st.isFile() && p.endsWith(".nix")) out.push(p);
  }
  for (const p of pathsIn) walk(p);
  return out;
}

function printHuman(file: string, source: string, findings: Finding[]) {
  if (findings.length === 0) return;
  console.log("Warning: Unused declarations were found.");
  const first = findings[0];
  console.log(`    ╭─[${file}:${first.line}:${first.column}]`);
  const lines = source.split(/\n/);
  const byLine = new Map<number, Finding[]>();
  for (const f of findings) {
    if (!byLine.has(f.line)) byLine.set(f.line, []);
    byLine.get(f.line)!.push(f);
  }
  for (const [ln, fs0] of byLine) {
    const text = lines[ln - 1] ?? "";
    console.log(`${String(ln).padStart(3)} │${text}`);
    const fs = fs0.sort((a, b) => a.column - b.column);
    for (const f of fs) {
      const spaces = " ".repeat(Math.max(0, f.column - 1));
      const mark = "╰" + "─".repeat(Math.max(1, f.name.length - 1));
      console.log(`    │${spaces}${mark} ${f.message}`);
    }
  }
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  const files = collectFiles(opt.paths, opt);
  let anyUnused = false;
  for (const f of files) {
    const { source, findings } = analyzeFile(f, opt);
    if (findings.some(x => !x.message.startsWith("Used "))) anyUnused = true;
    if (opt.edit) {
      const edited = applyEdit(source, findings);
      if (edited !== source) fs.writeFileSync(f, edited);
    }
    if (!opt.quiet) {
      if (opt.outputFormat === "json") {
        console.log(JSON.stringify({ file: f, results: findings.map(x => ({ column: x.column, endColumn: x.endColumn, line: x.line, message: x.message })) }));
      } else printHuman(f, source, findings);
    }
  }
  process.exit(opt.fail && anyUnused ? 1 : 0);
}

main();
