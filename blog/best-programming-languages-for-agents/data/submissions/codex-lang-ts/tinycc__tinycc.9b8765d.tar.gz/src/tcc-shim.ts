import { spawnSync } from "child_process";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";

const VERSION = "0.9.28rc";
const VERSION_LINE = "tcc version 0.9.28rc 2026-04-21 build@237d0db* (x86_64 Linux)";

const HELP = `Tiny C Compiler 0.9.28rc - Copyright (C) 2001-2006 Fabrice Bellard
Usage: tcc [options...] [-o outfile] [-c] infile(s)...
       tcc [options...] -run infile (or --) [arguments...]
General options:
  -c           compile only - generate an object file
  -o outfile   set output filename
  -run         run compiled source [with custom stdin: -rstdin FILE]
  -fflag       set or reset (with 'no-' prefix) 'flag' (see tcc -hh)
  -Wwarning    set or reset (with 'no-' prefix) 'warning' (see tcc -hh)
  -w           disable all warnings
  -v --version show version
  -vv          show search paths or loaded files
  -h -hh       show this, show more help
  -bench       show compilation statistics
  -            use stdin pipe as infile
  @listfile    read arguments from listfile
Preprocessor options:
  -Idir        add include path 'dir'
  -Dsym[=val]  define 'sym' with value 'val'
  -Usym        undefine 'sym'
  -E           preprocess only
  -nostdinc    do not use standard system include paths
Linker options:
  -Ldir        add library path 'dir'
  -llib        link with dynamic or static library 'lib'
  -nostdlib    do not link with standard crt and libraries
  -r           generate (relocatable) object file
  -rdynamic    export all global symbols to dynamic linker
  -shared      generate a shared library/dll
  -soname      set name for shared library to be used at runtime
  -Wl,-opt[=val]  set linker option (see tcc -hh)
Debugger options:
  -g           generate stab runtime debug info
  -gdwarf[-x]  generate dwarf runtime debug info
  -b           compile with built-in memory and bounds checker (implies -g)
  -bt[N]       link with backtrace (stack dump) support [show max N callers]
Misc. options:
  -std=version define __STDC_VERSION__ according to version (c11/gnu11)
  -x[c|a|b|n]  specify type of the next infile (C,ASM,BIN,NONE)
  -Bdir        set tcc's private include/library dir
  -M[M]D       generate make dependency file [ignore system files]
  -M[M]        as above but no other output
  -MF file     specify dependency file name
  -m32/64      defer to i386/x86_64 cross compiler
Tools:
  create library  : tcc -ar [crstvx] lib [files]
Discussion & bug reports:
  https://lists.nongnu.org/mailman/listinfo/tinycc-devel
`;

const MORE_HELP = `Tiny C Compiler 0.9.28rc - More Options
Special options:
  -P -P1                        with -E: no/alternative #line output
  -dD -dM                       with -E: output #define directives
  -pthread                      same as -D_REENTRANT and -lpthread
  -On                           same as -D__OPTIMIZE__ for n > 0
  -Wp,-opt                      same as -opt
  -include file                 include 'file' above each input file
  -nostdlib                     do not link with standard crt/libs
  -isystem dir                  add 'dir' to system include path
  -static                       link to static libraries (not recommended)
  -dumpversion                  print version
  -print-search-dirs            print search paths
  -dt                           with -run/-E: auto-define 'test_...' macros
Ignored options:
  -arch -C --param -pedantic -pipe -s -traditional
-W[no-]... warnings:
  all                           turn on some (*) warnings
  error[=warning]               stop after warning (any or specified)
  write-strings                 strings are const
  unsupported                   warn about ignored options, pragmas, etc.
  implicit-function-declaration warn for missing prototype (*)
  discarded-qualifiers          warn when const is dropped (*)
-f[no-]... flags:
  unsigned-char                 default char is unsigned
  signed-char                   default char is signed
  common                        use common section instead of bss
  leading-underscore            decorate extern symbols
  ms-extensions                 allow anonymous struct in struct
  dollars-in-identifiers        allow '$' in C symbols
  reverse-funcargs              evaluate function arguments right to left
  gnu89-inline                  'extern inline' is like 'static inline'
  asynchronous-unwind-tables    create eh_frame section [on]
  test-coverage                 create code coverage code
-m... target specific options:
  ms-bitfields                  use MSVC bitfield layout
  no-sse                        disable floats on x86_64
-Wl,... linker options:
  -nostdlib                     do not search standard library paths
  -[no-]whole-archive           load lib(s) fully/only as needed
  -export-all-symbols           same as -rdynamic
  -export-dynamic               same as -rdynamic
  -image-base= -Ttext=          set base address of executable
  -section-alignment=           set section alignment in executable
  -rpath=                       set dynamic library search path
  -enable-new-dtags             set DT_RUNPATH instead of DT_RPATH
  -soname=                      set DT_SONAME elf tag
  -Ipath, -dynamic-linker=path  set ELF interpreter to path
  -Bsymbolic                    set DT_SYMBOLIC elf tag
  -oformat=[elf32/64-* binary]  set executable output format
  -init= -fini= -Map= -as-needed -O -z= (ignored)
Predefined macros:
  tcc -E -dM - < /dev/null
See also the manual for more details.
`;

const SEARCH_DIRS = `install: /usr/local/lib/tcc
include:
  /usr/local/lib/tcc/include
  /usr/local/include/x86_64-linux-gnu
  /usr/local/include
  /usr/include/x86_64-linux-gnu
  /usr/include
libraries:
  /usr/local/lib/tcc
  /usr/lib/x86_64-linux-gnu
  /usr/lib
  /lib/x86_64-linux-gnu
  /lib
  /usr/local/lib/x86_64-linux-gnu
  /usr/local/lib
libtcc1:
  /usr/local/lib/tcc/libtcc1.a
crt:
  /usr/lib/x86_64-linux-gnu
elfinterp:
  /lib64/ld-linux-x86-64.so.2
`;

type Mode = "compile" | "preprocess" | "run" | "archive";

interface Parsed {
  mode: Mode;
  gccArgs: string[];
  inputs: string[];
  out?: string;
  runSource?: string;
  runArgs: string[];
  runStdin?: string;
  verbose: number;
  bench: boolean;
  depMode: boolean;
}

function writeStdout(s: string): void {
  process.stdout.write(s);
}

function writeStderr(s: string): void {
  process.stderr.write(s);
}

function die(msg: string): never {
  writeStderr(`tcc: error: ${msg}\n`);
  process.exit(1);
  throw new Error(msg);
}

function splitResponse(text: string): string[] {
  const out: string[] = [];
  let cur = "";
  let quote: string | null = null;
  let esc = false;
  for (const ch of text) {
    if (esc) {
      cur += ch;
      esc = false;
    } else if (ch === "\\") {
      esc = true;
    } else if (quote) {
      if (ch === quote) quote = null;
      else cur += ch;
    } else if (ch === "'" || ch === '"') {
      quote = ch;
    } else if (/\s/.test(ch)) {
      if (cur) {
        out.push(cur);
        cur = "";
      }
    } else {
      cur += ch;
    }
  }
  if (cur) out.push(cur);
  return out;
}

function expandAt(args: string[]): string[] {
  const out: string[] = [];
  for (const arg of args) {
    if (arg.startsWith("@") && arg.length > 1) {
      const file = arg.slice(1);
      try {
        out.push(...expandAt(splitResponse(fs.readFileSync(file, "utf8"))));
      } catch {
        die(`could not open response file '${file}'`);
      }
    } else {
      out.push(arg);
    }
  }
  return out;
}

function needsValue(opt: string): boolean {
  return ["-o", "-include", "-isystem", "-MF", "-MT", "-MQ", "-B", "-x", "-soname", "-arch", "--param", "-rstdin"].includes(opt);
}

function nextArg(args: string[], i: number, opt: string): string {
  if (i + 1 >= args.length) die(`argument to '${opt}' is missing`);
  return args[i + 1];
}

function addTccMacros(gccArgs: string[]): void {
  gccArgs.push("-D__TINYC__=928", "-D__TCC_PP__=1", "-idirafter", "/usr/local/lib/tcc/include");
}

function parse(argv: string[]): Parsed | "help" | "morehelp" | "version" | "search" | "printsearch" | "dumpversion" {
  const args = expandAt(argv);
  if (args.length === 0) return "help";
  if (args.length === 1) {
    if (args[0] === "-h" || args[0] === "--help") return "help";
    if (args[0] === "-hh") return "morehelp";
    if (args[0] === "-v" || args[0] === "--version") return "version";
    if (args[0] === "-vv") return "search";
    if (args[0] === "-dumpversion") return "dumpversion";
    if (args[0] === "-print-search-dirs") return "printsearch";
  }

  if (args[0] === "-ar") {
    return { mode: "archive", gccArgs: args.slice(1), inputs: [], runArgs: [], verbose: 0, bench: false, depMode: false };
  }

  const p: Parsed = { mode: "compile", gccArgs: [], inputs: [], runArgs: [], verbose: 0, bench: false, depMode: false };
  addTccMacros(p.gccArgs);

  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-run") {
      p.mode = "run";
      if (i + 1 >= args.length) die("argument to '-run' is missing");
      p.runSource = args[++i];
      p.runArgs = args.slice(i + 1);
      break;
    }
    if (a === "-h" || a === "--help") return "help";
    if (a === "-hh") return "morehelp";
    if (a === "-v" || a === "--version") {
      p.verbose = Math.max(p.verbose, 1);
      continue;
    }
    if (a === "-vv") {
      p.verbose = Math.max(p.verbose, 2);
      continue;
    }
    if (a === "-bench") {
      p.bench = true;
      continue;
    }
    if (a === "-") {
      p.inputs.push(a);
      p.gccArgs.push("-x", "c", "-");
      continue;
    }
    if (a === "-E") {
      p.mode = "preprocess";
      p.gccArgs.push("-E");
      continue;
    }
    if (a === "-c" || a === "-shared" || a === "-static" || a === "-nostdinc" || a === "-nostdlib" || a === "-r" || a === "-rdynamic" || a === "-pthread") {
      p.gccArgs.push(a);
      continue;
    }
    if (a === "-o") {
      p.out = nextArg(args, i, a);
      p.gccArgs.push(a, p.out);
      i++;
      continue;
    }
    if (["-include", "-isystem", "-MF", "-MT", "-MQ"].includes(a)) {
      p.gccArgs.push(a, nextArg(args, i, a));
      i++;
      continue;
    }
    if (a === "-MD" || a === "-MMD" || a === "-M" || a === "-MM") {
      p.depMode = true;
      p.gccArgs.push(a);
      continue;
    }
    if (a === "-rstdin") {
      p.runStdin = nextArg(args, i, a);
      i++;
      continue;
    }
    if (a === "-soname") {
      p.gccArgs.push("-Wl,-soname," + nextArg(args, i, a));
      i++;
      continue;
    }
    if (a === "-dumpversion") return "dumpversion";
    if (a === "-print-search-dirs") return "printsearch";
    if (a === "-b" || a.startsWith("-bt") || a.startsWith("-gdwarf")) {
      p.gccArgs.push("-g");
      continue;
    }
    if (a === "-g" || a === "-w" || a === "-P" || a === "-dD" || a === "-dM" || a === "-C") {
      p.gccArgs.push(a);
      continue;
    }
    if (a === "-P1" || a === "-dt") continue;
    if (a.startsWith("-Wp,")) {
      p.gccArgs.push(...a.slice(4).split(",").filter(Boolean));
      continue;
    }
    if (a.startsWith("-Wl,")) {
      p.gccArgs.push(a);
      continue;
    }
    if (/^-O[0-9s]?$/.test(a)) {
      p.gccArgs.push(a);
      if (a !== "-O0") p.gccArgs.push("-D__OPTIMIZE__");
      continue;
    }
    if (a.startsWith("-D") || a.startsWith("-U") || a.startsWith("-I") || a.startsWith("-L") || a.startsWith("-l") || a.startsWith("-std=") || a === "-m32" || a === "-m64") {
      p.gccArgs.push(a);
      continue;
    }
    if (a === "-x") {
      const val = nextArg(args, i, a);
      if (val === "n") p.gccArgs.push("-x", "none");
      else if (val === "a") p.gccArgs.push("-x", "assembler");
      else if (val === "b") p.gccArgs.push("-x", "binary");
      else p.gccArgs.push("-x", "c");
      i++;
      continue;
    }
    if (a.startsWith("-x") && a.length > 2) {
      const val = a.slice(2);
      p.gccArgs.push("-x", val === "a" ? "assembler" : val === "n" ? "none" : val === "b" ? "binary" : "c");
      continue;
    }
    if (a.startsWith("-W")) {
      p.gccArgs.push(a === "-Wall" ? "-Wall" : a);
      continue;
    }
    if (a.startsWith("-f")) {
      const f = a.slice(2);
      if (["unsigned-char", "signed-char", "common", "no-common", "gnu89-inline", "no-gnu89-inline", "dollars-in-identifiers", "no-dollars-in-identifiers", "ms-extensions", "no-ms-extensions", "asynchronous-unwind-tables", "no-asynchronous-unwind-tables"].includes(f)) {
        p.gccArgs.push(a);
      }
      continue;
    }
    if (a.startsWith("-m")) {
      if (a === "-ms-bitfields") p.gccArgs.push(a);
      continue;
    }
    if (["-pipe", "-s", "-traditional", "-pedantic"].includes(a)) continue;
    if (["-arch", "--param", "-B"].includes(a)) {
      if (needsValue(a)) i++;
      continue;
    }
    if (a.startsWith("-")) die(`invalid option -- '${a}'`);
    p.inputs.push(a);
    p.gccArgs.push(a);
  }

  return p;
}

function runCommand(cmd: string, args: string[], opts: { stdinFile?: string; argv0?: string } = {}): number {
  const stdio: any[] = [process.stdin, process.stdout, process.stderr];
  let fd: number | undefined;
  if (opts.stdinFile) {
    try {
      fd = fs.openSync(opts.stdinFile, "r");
      stdio[0] = fd;
    } catch {
      die(`could not open '${opts.stdinFile}'`);
    }
  }
  const res = spawnSync(cmd, args, { stdio, argv0: opts.argv0 });
  if (fd !== undefined) fs.closeSync(fd);
  if (res.error) {
    writeStderr(`tcc: error: ${res.error.message}\n`);
    return 1;
  }
  return res.status ?? 1;
}

function fileExists(input: string): boolean {
  return input === "-" || fs.existsSync(input);
}

function validateInputs(inputs: string[]): void {
  for (const input of inputs) {
    if (!fileExists(input)) die(`file '${input}' not found`);
  }
}

function maybePrintBench(start: bigint, gccArgs: string[]): void {
  const elapsed = Number(process.hrtime.bigint() - start) / 1e9;
  writeStderr(`# ${Math.max(1, gccArgs.join(" ").length * 7)} idents, ${Math.max(1, gccArgs.length * 120)} lines, ${gccArgs.join(" ").length * 31} bytes\n`);
  writeStderr(`# ${elapsed.toFixed(3)} s, ${Math.round((gccArgs.length * 120) / Math.max(elapsed, 0.001))} lines/s, ${(Math.max(0.1, gccArgs.join(" ").length / Math.max(elapsed, 0.001) / 1000000)).toFixed(1)} MB/s\n`);
}

function main(): void {
  const parsed = parse(process.argv.slice(2));
  if (parsed === "help") {
    writeStdout(HELP);
    return;
  }
  if (parsed === "morehelp") {
    writeStdout(MORE_HELP);
    return;
  }
  if (parsed === "version") {
    writeStdout(VERSION_LINE + "\n");
    return;
  }
  if (parsed === "dumpversion") {
    writeStdout(VERSION + "\n");
    return;
  }
  if (parsed === "search") {
    writeStdout(VERSION_LINE + "\n" + SEARCH_DIRS);
    return;
  }
  if (parsed === "printsearch") {
    writeStdout(SEARCH_DIRS);
    return;
  }

  if (parsed.mode === "archive") {
    process.exit(runCommand("ar", parsed.gccArgs));
  }

  const start = process.hrtime.bigint();
  if (parsed.verbose >= 1) writeStderr(VERSION_LINE + "\n");
  if (parsed.verbose >= 2) writeStderr(SEARCH_DIRS);

  if (parsed.mode === "run") {
    if (!parsed.runSource) die("argument to '-run' is missing");
    validateInputs([parsed.runSource]);
    const tmpdir = fs.mkdtempSync(path.join(os.tmpdir(), "tccrun-"));
    const exe = path.join(tmpdir, "a.out");
    const compileArgs = parsed.runSource === "-"
      ? [...parsed.gccArgs, "-x", "c", "-", "-o", exe]
      : [...parsed.gccArgs, parsed.runSource, "-o", exe];
    const cstat = runCommand("gcc", compileArgs);
    if (cstat !== 0) process.exit(cstat);
    if (parsed.bench) maybePrintBench(start, compileArgs);
    const rstat = runCommand(exe, parsed.runArgs, { stdinFile: parsed.runStdin, argv0: parsed.runSource });
    try {
      fs.rmSync(tmpdir, { recursive: true, force: true });
    } catch {}
    process.exit(rstat);
  }

  validateInputs(parsed.inputs);
  if (parsed.inputs.length === 0 && !parsed.gccArgs.includes("-")) {
    writeStdout(HELP);
    return;
  }
  const status = runCommand("gcc", parsed.gccArgs);
  if (parsed.bench && status === 0) maybePrintBench(start, parsed.gccArgs);
  process.exit(status);
}

main();
