declare module "child_process" {
  export function spawnSync(command: string, args?: readonly string[], options?: any): any;
}

declare module "fs" {
  export function readFileSync(path: string, encoding: string): string;
  export function existsSync(path: string): boolean;
  export function openSync(path: string, flags: string): number;
  export function closeSync(fd: number): void;
  export function mkdtempSync(prefix: string): string;
  export function rmSync(path: string, options?: any): void;
}

declare module "os" {
  export function tmpdir(): string;
}

declare module "path" {
  export function join(...parts: string[]): string;
}

declare const process: any;
declare const require: any;
