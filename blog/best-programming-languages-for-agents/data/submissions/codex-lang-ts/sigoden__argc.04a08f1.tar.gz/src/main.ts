declare const require: any;
declare const process: any;
const fs = require("fs");
const path = require("path");
const child_process = require("child_process");

type Opt = {
  id: string; names: string[]; short?: string; long?: string; flag: boolean; desc: string;
  required: boolean; multi: boolean; delimiter?: string; terminated: boolean; assigned: boolean; prefixed: boolean;
  notations: string[]; min: number; max: number; def?: string; choice?: string[]; choiceFn?: string; skipChoice: boolean; env?: string;
};
type Pos = { id: string; desc: string; required: boolean; multi: boolean; delimiter?: string; terminated: boolean; def?: string; choice?: string[]; choiceFn?: string; skipChoice: boolean; notation: string; env?: string };
type Env = { name: string; required: boolean; def?: string; choice?: string[]; choiceFn?: string; skipChoice: boolean };
type Cmd = { name: string; display: string; fn?: string; desc: string; longDesc: string[]; aliases: string[]; opts: Opt[]; pos: Pos[]; envs: Env[]; sub: Cmd[]; parent?: Cmd; version?: string; meta: Record<string,string>; };

function main() {
  const argv = process.argv.slice(2);
  const cmd = argv[0];
  try {
    if (!cmd || cmd === "--help") return defaultRun(argv);
    if (cmd === "--argc-help") return printGlobalHelp();
    if (cmd === "--argc-version") return out("argc 1.23.0\n");
    if (cmd === "--argc-shell-path") return out("/usr/bin/bash\n");
    if (cmd === "--argc-script-path") return scriptPath();
    if (cmd === "--argc-eval") return argcEval(argv.slice(1));
    if (cmd === "--argc-run") return argcRun(argv.slice(1));
    if (cmd === "--argc-export") return argcExport(argv.slice(1));
    if (cmd === "--argc-create") return argcCreate(argv.slice(1));
    if (cmd === "--argc-completions") return completions(argv.slice(1));
    if (cmd === "--argc-compgen") return compgen(argv.slice(1));
    if (cmd === "--argc-mangen" || cmd === "--argc-build") return simpleCopy(argv.slice(1), cmd);
    if (cmd === "--argc-parallel") return argcParallel(argv.slice(1));
    return defaultRun(argv);
  } catch (e:any) {
    err((e && e.message) ? e.message + "\n" : String(e) + "\n");
    process.exit(1);
  }
}

function out(s:string){ process.stdout.write(s); }
function err(s:string){ process.stderr.write(s); }
function q(s:string){ return "'" + String(s).replace(/'/g, `'\\''`) + "'"; }
function bashArray(a:string[]){ return "(" + a.map((v,i)=>`[${i}]=${q(v)}`).join(" ") + ")"; }
function idFromName(s:string){ return s.replace(/^[+-]+/, "").replace(/^X-/, "X_").replace(/[^A-Za-z0-9]+/g, "_").replace(/^_+|_+$/g, "").toLowerCase(); }
function notation(id:string){ return id.replace(/_/g, "-").toUpperCase(); }

function printGlobalHelp(){
  out(`A bash cli framework, also a bash-based command runner - https://github.com/sigoden/argc

USAGE:
    argc --argc-eval <FILE> <ARGS~>            Use \`eval "$(argc --argc-eval "$0" "$@")"\`
    argc --argc-create <RECIPES~>              Create a boilerplate argcfile
    argc --argc-run <FILE> <ARGS~>             Run an argc-based script
    argc --argc-build <FILE> <OUTPATH?>        Generate bashscript without argc dependency
    argc --argc-mangen <FILE> <OUTDIR>         Generate man pages
    argc --argc-completions <SHELL> <CMDS>     Generate shell completion scripts
    argc --argc-compgen <SHELL> <FILE> <ARGS>  Generate completion candidates
    argc --argc-export <FILE>                  Export command line definitions as json
    argc --argc-parallel <FILE> <ARGS~>        Run functions in parallel
    argc --argc-script-path                    Print current argcfile path
    argc --argc-shell-path                     Print current shell path
    argc --argc-help                           Print help information
    argc --argc-version                        Print version information

`);
}
function scriptPath(){ err("Argcfile not found.\n"); process.exit(1); }
function defaultRun(argv:string[]){ err("Argcfile not found, try `argc --argc-help` for help.\n"); process.exit(1); }

function emptyCmd():Cmd { return {name:"", display:"", desc:"", longDesc:[], aliases:[], opts:[], pos:[], envs:[], sub:[], meta:{}}; }

function parseFile(file:string):Cmd {
  const text = fs.readFileSync(file, "utf8");
  const lines = text.split(/\r?\n/);
  const root = emptyCmd();
  root.name = path.basename(file).replace(/\.[^.]+$/, "");
  root.display = root.name;
  let pending:{tag:string, body:string, extra:string[]}[] = [];
  let last:any = null;
  function addTag(tag:string, body:string){
    if (tag === "cmd" && pending.length && !pending.some(p=>p.tag==="cmd")) apply(root);
    const o={tag,body:body.trim(),extra:[]}; pending.push(o); last=o;
  }
  function apply(target:Cmd){
    for (const p of pending) {
      const body = [p.body, ...p.extra].filter(Boolean).join("\n");
      if (p.tag === "describe") { target.desc = p.body; target.longDesc = p.extra; }
      else if (p.tag === "cmd") { if (p.body && !target.desc) target.desc = p.body; if (p.extra.length) target.longDesc = p.extra; }
      else if (p.tag === "alias") target.aliases.push(...p.body.split(/[,\s]+/).filter(Boolean));
      else if (p.tag === "arg") target.pos.push(parsePos(p.body));
      else if (p.tag === "option") target.opts.push(parseOpt(p.body, false));
      else if (p.tag === "flag") target.opts.push(parseOpt(p.body, true));
      else if (p.tag === "env") target.envs.push(parseEnv(p.body));
      else if (p.tag === "meta") { const [k,...r]=p.body.split(/\s+/); target.meta[k]=r.join(" ") || "1"; if(k==="version") target.version=r.join(" "); }
    }
    pending = []; last = null;
  }
  for (let i=0;i<lines.length;i++) {
    const line = lines[i];
    const m = line.match(/^\s*#\s*@([A-Za-z_-]+)\s*(.*)$/);
    if (m) { addTag(m[1], m[2]); continue; }
    const cont = line.match(/^\s*#\s?(.*)$/);
    if (cont && last) { last.extra.push(cont[1].trimEnd()); continue; }
    const fn = line.match(/^\s*(?:function\s+)?([A-Za-z_][A-Za-z0-9_:-]*)\s*(?:\(\))?\s*\{/);
    if (fn) {
      const name = fn[1];
      const hasCmd = pending.some(p=>p.tag==="cmd");
      if (hasCmd) {
        const parts = name.split("::");
        let cur = root;
        for (let pi=0; pi<parts.length; pi++) {
          const display = parts[pi];
          let child = cur.sub.find(c=>c.display===display);
          if (!child) { child = emptyCmd(); child.name=display; child.display=display; child.parent=cur; cur.sub.push(child); }
          cur = child;
        }
        cur.fn = name; apply(cur);
      } else if (name === "main") {
        root.fn = "main"; apply(root);
      } else if (pending.length) {
        apply(root);
      }
      continue;
    }
    if (line.includes("eval ") && pending.length) apply(root);
    else if (line.trim() && !cont) { if (pending.length && pending.some(p=>p.tag==="describe"||p.tag==="meta"||p.tag==="env")) apply(root); else { pending=[]; last=null; } }
  }
  if (pending.length) apply(root);
  addBuiltins(root);
  inherit(root, root.meta["inherit-flag-options"] !== undefined ? root.opts.filter(o=>o.id!=="help"&&o.id!=="version") : []);
  return root;
}

function inherit(c:Cmd, inherited:Opt[]) {
  for (const s of c.sub) {
    for (const o of inherited) if (!s.opts.some(x=>x.id===o.id)) s.opts.unshift({...o});
    inherit(s, inherited);
  }
}
function addBuiltins(c:Cmd) {
  const hasSub = c.sub.length>0;
  if (!c.opts.some(o=>o.id==="help")) c.opts.push({id:"help",names:["-h","--help"],short:"-h",long:"--help",flag:true,desc: hasSub||!c.fn ? "" : "Print help",required:false,multi:false,terminated:false,assigned:false,prefixed:false,notations:[],min:0,max:0,skipChoice:false});
  if (!c.parent && !hasSub && !c.opts.some(o=>o.id==="version")) c.opts.push({id:"version",names:["-V","--version"],short:"-V",long:"--version",flag:true,desc:"Print version",required:false,multi:false,terminated:false,assigned:false,prefixed:false,notations:[],min:0,max:0,skipChoice:false});
  for (const s of c.sub) addBuiltins(s);
}

function splitDesc(s:string):[string,string] {
  let inB=0, inT=false;
  for (let i=0;i<s.length;i++) {
    const ch=s[i]; if(ch==="`") inT=!inT; else if(!inT&&ch==="[") inB++; else if(!inT&&ch==="]") inB--;
    if (!inT && inB<=0 && /\s/.test(ch)) { let j=i; while(j<s.length&&/\s/.test(s[j])) j++; if(j<s.length) return [s.slice(0,i), s.slice(j)]; }
  }
  return [s,""];
}
function parseSpec(raw:string) {
  const r:any = {base:raw, required:false, multi:false, plus:false, delimiter:undefined, terminated:false, def:undefined, choice:undefined, choiceFn:undefined, skipChoice:false};
  if (r.base.endsWith(",")) { r.delimiter=","; r.base=r.base.slice(0,-1); }
  if (r.base.endsWith("~")) { r.terminated=true; r.base=r.base.slice(0,-1); }
  const bm = r.base.match(/^(.*)\[(.*)\]$/);
  if (bm) {
    r.base=bm[1]; const inner=bm[2];
    if (inner.startsWith("?`") && inner.endsWith("`")) { r.skipChoice=true; r.choiceFn=inner.slice(2,-1); }
    else if (inner.startsWith("`") && inner.endsWith("`")) r.choiceFn=inner.slice(1,-1);
    else { const val=inner.startsWith("=")?inner.slice(1):inner; r.choice=val.split("|").filter(Boolean); if(inner.startsWith("=") && r.choice.length) r.def=r.choice[0]; }
  }
  const dm = r.base.match(/^(.*?)=(.*)$/);
  if (dm) { r.base=dm[1]; r.def=dm[2]; }
  if (r.base.endsWith("!")) { r.required=true; r.base=r.base.slice(0,-1); }
  if (r.base.endsWith("*")) { r.multi=true; r.base=r.base.slice(0,-1); }
  if (r.base.endsWith("+")) { r.multi=true; r.plus=true; r.required=true; r.base=r.base.slice(0,-1); }
  return r;
}
function parsePos(s:string):Pos {
  const [head,desc] = splitDesc(s.trim()); const sp=parseSpec(head);
  const not = (desc.match(/<([^>]+)>/)||[])[1] || notation(sp.base);
  const id=idFromName(sp.base); const envBind=bindEnv(desc, id);
  return {id, desc: envBind.desc.replace(/<[^>]+>/g,"").trim(), required:sp.required||sp.plus, multi:sp.multi, delimiter:sp.delimiter, terminated:sp.terminated, def:sp.def, choice:sp.choice, choiceFn:sp.choiceFn, skipChoice:sp.skipChoice, notation:not, env:envBind.env};
}
function parseEnv(s:string):Env {
  const [head] = splitDesc(s.trim()); const sp=parseSpec(head);
  return {name:sp.base, required:sp.required, def:sp.def, choice:sp.choice, choiceFn:sp.choiceFn, skipChoice:sp.skipChoice};
}
function parseOpt(s:string, flag:boolean):Opt {
  const parts=s.trim().split(/\s+/); const names:string[]=[]; let i=0;
  while(i<parts.length && /^[+-]/.test(parts[i])) { names.push(parts[i]); i++; }
  const rest=parts.slice(i).join(" ");
  let primary=names.find(n=>n.startsWith("--")) || names[names.length-1] || "";
  let assigned=false; if(primary.includes(":")) { assigned=true; primary=primary.split(":")[0]; names[names.length-1]=primary; }
  const sp=parseSpec(primary);
  const realNames=names.map((n,idx)=> idx===names.length-1 ? sp.base : n);
  const notationMatches=[...rest.matchAll(/<([^>]+)>/g)].map((m:any)=>m[1]);
  const id=idFromName(sp.base); const envBind=bindEnv(rest, id);
  const desc=envBind.desc.replace(/<[^>]+>/g,"").trim();
  let min=flag?0:1, max=flag?0:1;
  if (!flag && notationMatches.length) {
    min=0; max=0;
    for (const n of notationMatches) {
      if (n.endsWith("*")) max=999; else if (n.endsWith("+")) { min++; max=999; } else if (n.endsWith("?")) max++; else { min++; max++; }
    }
  }
  if (sp.terminated) { min=0; max=999; }
  return {id, names:realNames, short:realNames.find(n=>/^-[^-]/.test(n)), long:realNames.find(n=>/^--/.test(n)), flag, desc, required:sp.required, multi:sp.multi, delimiter:sp.delimiter, terminated:sp.terminated, assigned, prefixed:sp.base.includes("*"), notations:notationMatches.length?notationMatches.map((n:any)=>n.replace(/[+*?]$/,"")):[notation(id)], min, max, def:sp.def, choice:sp.choice, choiceFn:sp.choiceFn, skipChoice:sp.skipChoice, env:envBind.env};
}
function bindEnv(desc:string, id:string) {
  const m=desc.match(/(?:^|\s)\$([A-Za-z_][A-Za-z0-9_]*|\$)(?:\s|$)/);
  if(!m) return {desc, env:undefined};
  const env=m[1]==="$" ? id.toUpperCase() : m[1];
  return {desc:desc.replace(m[0]," ").trim(), env};
}

function argcEval(args:string[]) {
  if (!args.length) { err("error: missing required argument <FILE>\n"); process.exit(1); }
  const file=args[0]; (globalThis as any).__argc_file = file;
  const root=parseFile(file); const parsed=parseArgs(root, args.slice(1), path.basename(file).replace(/\.[^.]+$/,""));
  if (parsed.help) { out(emitTextShell(helpText(parsed.cmd, root), 0)); return; }
  if (parsed.version) { out(emitTextShell(`${root.name} ${root.version||""}\n`, 0)); return; }
  if (parsed.error) { out(`echo ${q(parsed.error)} >&2\nexit 1\n`); return; }
  out(emitShell(parsed, root, args.slice(1)));
}

function parseArgs(root:Cmd, argv:string[], prog:string) {
  const chain=[root]; let cmd=root; let idx=0;
  const def = root.sub.find(s=>s.meta["default-subcommand"]!==undefined);
  if (def && argv[0] && !findSub(root, argv[0]) && !argv[0].startsWith("-")) { cmd=def; chain.push(cmd); }
  while(idx<argv.length) {
    const s=findSub(cmd, argv[idx]); if(!s) break; cmd=s; chain.push(cmd); idx++;
  }
  const vals:Record<string,string[]>={}; const posVals:string[]=[]; let help=false, version=false, stop=false;
  for (const o of cmd.opts) vals[o.id]=[];
  while(idx<argv.length) {
    let a=argv[idx];
    if(!stop && a==="--") { stop=true; idx++; continue; }
    if(!stop && (a==="-h"||a==="--help")) { help=true; idx++; continue; }
    if(!stop && (a==="-V"||a==="--version")) { version=true; idx++; continue; }
    if(!stop && /^[+-]/.test(a)) {
      const match=findOpt(cmd.opts,a);
      if (match) {
        const {opt,name,value,consumedName}=match; idx += consumedName;
        if (opt.flag) { vals[opt.id].push("1"); continue; }
        let takes:string[]=[];
        if (value!==undefined) takes.push(value);
        while(takes.length<opt.min && idx<argv.length) takes.push(argv[idx++]);
        while(opt.terminated && idx<argv.length) takes.push(argv[idx++]);
        if (takes.length<opt.min) return {cmd,error:`error: a value is required for '${name}' but none was supplied`};
        vals[opt.id].push(...expandVals(opt,takes));
        continue;
      }
      const combo = comboShort(cmd, a, vals);
      if (combo) { idx++; continue; }
      return {cmd,error:`error: unexpected argument '${a}' found`};
    }
    posVals.push(a); idx++;
  }
  if (help || version) return {cmd, chain, help, version};
  const assigned:Record<string,string[]|string>={}; const callArgs:string[]=[];
  let pi=0;
  for (const p of cmd.pos) {
    let arr:string[]=[];
    if (p.terminated || p.multi) { arr=posVals.slice(pi); pi=posVals.length; }
    else if (pi<posVals.length) arr=[posVals[pi++]];
    else if (p.env && process.env[p.env]!==undefined) arr=[process.env[p.env]];
    else if (p.def!==undefined) arr=[resolveDefault(p.def, root)];
    if ((p.required || (p.multi && !p.def && p.required)) && arr.length===0) return {cmd,error:`error: the following required arguments were not provided:\n  <${p.notation}>`};
    const bad=checkChoice(p, arr, root); if (bad) return {cmd,error:bad};
    assigned[p.id]=p.multi?arr:(arr[0]||"");
    callArgs.push(...arr);
  }
  if (pi<posVals.length) return {cmd,error:`error: unexpected argument '${posVals[pi]}' found`};
  for (const e of [...root.envs, ...cmd.envs]) {
    const v = process.env[e.name] ?? e.def;
    if (e.required && (v===undefined || v==="")) return {cmd,error:`error: the following required environment variables were not provided:\n  ${e.name}`};
  }
  for (const o of cmd.opts) {
    if (o.id === "help" || o.id === "version") continue;
    let arr=vals[o.id]||[];
    if (arr.length===0 && o.env && process.env[o.env]!==undefined) arr=o.flag ? (truthy(process.env[o.env])?["1"]:[]) : [process.env[o.env]];
    if (arr.length===0 && o.def!==undefined) arr=[resolveDefault(o.def, root)];
    if (o.required && arr.length===0) return {cmd,error:`error: the following required arguments were not provided:\n  <${o.notations[0]}>`};
    const bad=checkChoice(o, arr, root); if (bad) return {cmd,error:bad};
    assigned[o.id]=o.flag ? String(arr.length) : (o.multi || o.delimiter || o.max>1 ? arr : (arr[0]||""));
  }
  return {cmd, chain, assigned, positionals:callArgs, help, version};
}
function truthy(v:string){ return !["","0","false","False","FALSE","no","NO"].includes(v); }
function findSub(c:Cmd, s:string){ return c.sub.find(x=>x.display===s || x.aliases.includes(s)); }
function findOpt(opts:Opt[], a:string) {
  for (const o of opts) for (const n of o.names) {
    if (a===n) return {opt:o,name:n,consumedName:1};
    if (!o.flag && (a.startsWith(n+"=") || (o.assigned && a.startsWith(n+":")))) return {opt:o,name:n,value:a.slice(n.length+1),consumedName:1};
    if (o.prefixed && a.startsWith(n.replace("*",""))) return {opt:o,name:n,value:a.slice(n.indexOf("*")),consumedName:1};
  }
}
function comboShort(cmd:Cmd, a:string, vals:Record<string,string[]>) {
  if (cmd.meta["combine-shorts"]===undefined && cmd.parent?.meta["combine-shorts"]===undefined) return false;
  if (!/^-[A-Za-z]{2,}$/.test(a)) return false;
  for (const ch of a.slice(1)) {
    const o=cmd.opts.find(x=>x.flag && x.short===`-${ch}`); if(!o) return false; vals[o.id].push("1");
  }
  return true;
}
function expandVals(o:Opt, vals:string[]){ return o.delimiter ? vals.flatMap(v=>v.split(o.delimiter!).filter(x=>x.length>0)) : vals; }
function resolveDefault(d:string, root:Cmd){ if (d.startsWith("`") && d.endsWith("`")) return runFunc(root, d.slice(1,-1)).split(/\r?\n/)[0]||""; return d; }
function choices(x:any, root:Cmd){ if(x.choice) return x.choice; if(x.choiceFn) return runFunc(root, x.choiceFn).split(/\r?\n/).filter(Boolean); return undefined; }
function checkChoice(x:any, arr:string[], root:Cmd) {
  if (x.skipChoice) return undefined; const ch=choices(x, root); if(!ch) return undefined;
  for (const v of arr) if(v && !ch.includes(v)) return `error: invalid value \`${v}\` for \`<${x.notation||x.notations?.[0]||notation(x.id)}>\`\n  [possible values: ${ch.join(", ")}]`;
}
function runFunc(root:Cmd, fn:string) {
  try {
    const file=(globalThis as any).__argc_file; if(!file) return "";
    const text=fs.readFileSync(file,"utf8");
    const esc=fn.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
    const m=text.match(new RegExp(`${esc}\\s*\\(\\)\\s*\\{([\\s\\S]*?)\\n\\}`));
    if(!m) return "";
    const vals:string[]=[];
    for(const em of m[1].matchAll(/echo\s+["']?([^"'\n]+)["']?/g)) vals.push(String(em[1]).trim());
    if(vals.length) return vals.join("\n")+"\n";
  } catch {}
  return "";
}

function emitShell(parsed:any, root:Cmd, argv:string[]) {
  const lines:string[]=[];
  lines.push(`argc__args=${bashArray([root.name, ...argv])}`);
  if (parsed.cmd.fn) lines.push(`argc__fn=${q(parsed.cmd.fn)}`);
  lines.push(`argc__positionals=${bashArray(parsed.positionals||[])}`);
  for (const e of [...root.envs, ...(parsed.cmd.envs||[])]) {
    let v=process.env[e.name];
    if ((v===undefined || v==="") && e.def!==undefined) v=resolveDefault(e.def, root);
    if (v!==undefined) lines.push(`export ${e.name}=${q(v)}`);
  }
  for (const [k,v] of Object.entries(parsed.assigned||{})) {
    if (Array.isArray(v)) lines.push(`argc_${k}=${bashArray(v as string[])}`);
    else lines.push(`argc_${k}=${q(v as string)}`);
  }
  const fn=parsed.cmd.fn || (root.fn==="main" ? "main" : "");
  if (fn) {
    lines.push(`if declare -F _argc_before >/dev/null; then _argc_before; fi`);
    lines.push(`${fn} ${parsed.positionals.map((x:string)=>q(x)).join(" ")}`);
    lines.push(`_argc_status=$?`);
    lines.push(`if declare -F _argc_after >/dev/null; then _argc_after; fi`);
    lines.push(`return $_argc_status 2>/dev/null || exit $_argc_status`);
  }
  return lines.join("\n")+"\n";
}

function emitTextShell(text:string, code:number) {
  return `cat <<'__ARGC_EOF__'\n${text.replace(/\n?$/,"\n")}__ARGC_EOF__\nreturn ${code} 2>/dev/null || exit ${code}\n`;
}
function helpText(c:Cmd, root:Cmd) {
  let s="";
  if (c.desc) s += c.desc+"\n"; if (c.longDesc.length) s += "\n"+c.longDesc.join("\n").trim()+"\n";
  const names=[]; let p:any=c; while(p&&p.parent){names.unshift(p.display); p=p.parent;}
  let usage = `USAGE: ${root.name}${names.length?" "+names.join(" "):""}`;
  if (c.sub.length) usage += " <COMMAND>"; else { if(c.opts.some(o=>o.id!=="help"&&o.id!=="version")) usage += " [OPTIONS]"; for(const a of c.pos) usage += " " + fmtPos(a); }
  s += `\n${usage}\n`;
  if (c.pos.length) { s += "\nARGS:\n"; for(const a of c.pos) s += `  ${fmtPos(a).padEnd(9)} ${a.desc}\n`; }
  if (c.opts.length && !c.sub.length) { s += "\nOPTIONS:\n"; for(const o of c.opts) { const label=fmtOpt(o); s += `  ${label.padEnd(20)} ${o.desc|| (o.id==="help"?"Print help":o.id==="version"?"Print version":"")}\n`; } }
  if (c.sub.length) { s += "\nCOMMANDS:\n"; for(const sub of c.sub) { const al=sub.aliases.length?` [aliases: ${sub.aliases.join(", ")}]`:""; s += `  ${sub.display.padEnd(9)} ${sub.desc}${al}\n`; } }
  return s + "\n";
}
function fmtPos(a:Pos){ const n=a.notation; return a.required&&!a.multi?`<${n}>`:a.required&&a.multi?`<${n}>...`:a.multi?`[${n}]...`:`[${n}]`; }
function fmtOpt(o:Opt){ const names=[]; if(o.short) names.push(o.short); if(o.long) names.push(o.long); else if(!o.short&&o.names[0]) names.push(o.names[0]); let s=names.join(", "); if(!o.flag) s += ` <${o.notations[0]||notation(o.id)}>`; return s; }

function argcRun(args:string[]) {
  if(!args.length) process.exit(1);
  const exe = process.argv[1]; const dir=fs.mkdtempSync("/tmp/argc-"); fs.symlinkSync(exe, path.join(dir,"argc"));
  const env={...process.env, PATH:dir+":"+process.env.PATH};
  const r=child_process.spawnSync("/usr/bin/bash", [args[0], ...args.slice(1)], {stdio:"inherit", env});
  process.exit(r.status||0);
}
function argcExport(args:string[]) { const root=parseFile(args[0]); out(JSON.stringify(toJson(root), null, 2)+"\n"); }
function toJson(c:Cmd):any { return {name:c.display, describe:c.desc||null, version:c.version||null, aliases:c.aliases, flag_options:c.opts.map(o=>({id:o.id,long_name:o.long||null,short_name:o.short||null,describe:o.desc,flag:o.flag,notations:o.flag?[]:o.notations,required:o.required,multiple_values:o.max>1,multiple_occurs:o.multi,num_args:[o.min,o.max>99?null:o.max],delimiter:o.delimiter||null,terminated:o.terminated,prefixed:o.prefixed,assigned:o.assigned,default:o.def||null,choice:o.choice||null,env:o.env||null,inherited:false})), positionals:c.pos.map(p=>({id:p.id,describe:p.desc,notation:p.notation,required:p.required,multiple:p.multi,delimiter:p.delimiter||null,terminated:p.terminated,default:p.def||null,choice:p.choice||null,env:p.env||null})), envs:c.envs, subcommands:c.sub.map(toJson), command_fn:c.fn||null}; }
function argcCreate(args:string[]){ for(const r of args) out(`# @cmd\n${r}() {\n    :;\n}\n\n`); }
function completions(args:string[]){ out("# argc completions\n"); }
function compgen(args:string[]) {
  const file=args[1]; const prefix=args[args.length-1]||""; const root=parseFile(file); const c=root;
  for(const o of c.opts) for(const n of o.names) if(n.startsWith(prefix)) out(`${n}\t${o.desc||""}\n`);
  for(const s of c.sub) if(s.display.startsWith(prefix)) out(`${s.display}\t${s.desc||""}\n`);
}
function simpleCopy(args:string[], mode:string){ if(args.length<1) process.exit(1); const input=args[0], outp=args[1]||input; if(mode==="--argc-build"){ fs.mkdirSync(outp,{recursive:true}); fs.copyFileSync(input,path.join(outp,path.basename(input))); } else { fs.copyFileSync(input,outp); } }
function argcParallel(args:string[]){ if(args.length<2) process.exit(0); const file=args[0]; const chunks=args.slice(1).join(" ").split(/\s+:::\s+/); for(const ch of chunks){ child_process.spawnSync("/usr/bin/bash", ["-lc", `source ${q(file)}; ${ch}`], {stdio:"inherit"}); } }

main();
