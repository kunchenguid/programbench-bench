#!/usr/bin/env node

declare const require: any;
declare const process: any;
const fs = require("fs");

type Rec = { keys: string[]; values: Map<string, any> };
type Verb = { name: string; args: string[] };

const VERSION = "mlr 6.16.0";

function die(msg: string) {
  console.error(msg);
  process.exit(1);
}

function cloneRec(r: Rec): Rec {
  return { keys: [...r.keys], values: new Map(r.values) };
}

function get(r: Rec, k: string): any {
  return r.values.has(k) ? r.values.get(k) : "";
}

function set(r: Rec, k: string, v: any, prepend = false) {
  if (!r.values.has(k)) {
    if (prepend) r.keys.unshift(k);
    else r.keys.push(k);
  }
  r.values.set(k, v);
}

function infer(s: string): any {
  if (s === "") return "";
  if (/^-?(0|[1-9][0-9]*)$/.test(s)) return Number(s);
  if (/^-?([0-9]*\.[0-9]+|[0-9]+\.[0-9]*)([eE][-+]?[0-9]+)?$/.test(s) || /^-?[0-9]+[eE][-+]?[0-9]+$/.test(s)) return Number(s);
  if (s === "true") return true;
  if (s === "false") return false;
  return s;
}

function str(v: any): string {
  if (v === null || v === undefined) return "";
  if (Array.isArray(v) || (typeof v === "object" && !(v instanceof String))) return JSON.stringify(v);
  return String(v);
}

function parseCSVLine(line: string, sep: string): string[] {
  const out: string[] = [];
  let cur = "";
  let inq = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (inq) {
      if (c === '"') {
        if (line[i + 1] === '"') {
          cur += '"';
          i++;
        } else inq = false;
      } else cur += c;
    } else {
      if (c === '"') inq = true;
      else if (c === sep) {
        out.push(cur);
        cur = "";
      } else cur += c;
    }
  }
  out.push(cur);
  return out;
}

function csvQuote(s: string, sep: string, quoteAll: boolean): string {
  const needs = quoteAll || s.includes(sep) || s.includes('"') || s.includes("\n") || s.includes("\r");
  if (!needs) return s;
  return `"${s.replace(/"/g, '""')}"`;
}

function splitLines(text: string): string[] {
  return text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n").filter((l, i, a) => !(i === a.length - 1 && l === ""));
}

function parseDelimited(text: string, sep: string, implicit: boolean): Rec[] {
  const lines = splitLines(text);
  if (lines.length === 0) return [];
  let headers: string[];
  let start = 0;
  if (implicit) headers = parseCSVLine(lines[0], sep).map((_, i) => String(i + 1));
  else {
    headers = parseCSVLine(lines[0], sep);
    start = 1;
  }
  const recs: Rec[] = [];
  for (let i = start; i < lines.length; i++) {
    if (lines[i] === "") continue;
    const fields = parseCSVLine(lines[i], sep);
    const keys = [...headers];
    const values = new Map<string, any>();
    for (let j = 0; j < fields.length; j++) {
      const k = headers[j] ?? String(j + 1);
      if (!keys.includes(k)) keys.push(k);
      values.set(k, infer(fields[j]));
    }
    for (const k of keys) if (!values.has(k)) values.set(k, "");
    recs.push({ keys, values });
  }
  return recs;
}

function parseDKVP(text: string, fsSep: string, psSep: string): Rec[] {
  return splitLines(text).filter(l => l.length > 0).map(line => {
    const keys: string[] = [];
    const values = new Map<string, any>();
    const parts = line.split(fsSep);
    parts.forEach((p, idx) => {
      const pos = p.indexOf(psSep);
      const k = pos >= 0 ? p.slice(0, pos) : String(idx + 1);
      const v = pos >= 0 ? p.slice(pos + psSep.length) : p;
      if (!values.has(k)) keys.push(k);
      values.set(k, infer(v));
    });
    return { keys, values };
  });
}

function flattenObj(obj: any, prefix = "", out: {[k: string]: any} = {}): {[k: string]: any} {
  if (obj && typeof obj === "object" && !Array.isArray(obj)) {
    for (const [k, v] of Object.entries(obj)) flattenObj(v, prefix ? `${prefix}.${k}` : k, out);
  } else if (Array.isArray(obj)) {
    obj.forEach((v, i) => flattenObj(v, prefix ? `${prefix}.${i + 1}` : String(i + 1), out));
  } else out[prefix] = obj;
  return out;
}

function parseJSONInput(text: string, jsonl: boolean): Rec[] {
  const objs = jsonl ? splitLines(text).filter(Boolean).map(l => JSON.parse(l)) : (Array.isArray(JSON.parse(text || "[]")) ? JSON.parse(text || "[]") : [JSON.parse(text)]);
  return objs.map((o: any) => {
    const flat = flattenObj(o);
    const keys = Object.keys(flat);
    const values = new Map<string, any>();
    keys.forEach(k => values.set(k, flat[k]));
    return { keys, values };
  });
}

function parsePprint(text: string): Rec[] {
  const lines = splitLines(text).filter(l => l.trim() !== "");
  if (lines.length === 0) return [];
  const headers = lines[0].trim().split(/\s+/);
  return lines.slice(1).map(line => {
    const vals = line.trim().split(/\s+/);
    const values = new Map<string, any>();
    headers.forEach((h, i) => values.set(h, infer(vals[i] ?? "")));
    return { keys: [...headers], values };
  });
}

function allKeys(recs: Rec[]): string[] {
  const keys: string[] = [];
  for (const r of recs) for (const k of r.keys) if (!keys.includes(k)) keys.push(k);
  return keys;
}

function writeRecords(recs: Rec[], fmt: string, opts: any): string {
  if (fmt === "csv" || fmt === "tsv") {
    const sep = fmt === "tsv" ? "\t" : ",";
    const keys = allKeys(recs);
    const lines: string[] = [];
    if (!opts.headerlessOutput && keys.length) lines.push(keys.map(k => csvQuote(k, sep, opts.quoteAll)).join(sep));
    for (const r of recs) lines.push(keys.map(k => csvQuote(str(get(r, k)), sep, opts.quoteAll)).join(sep));
    return lines.join("\n") + (lines.length ? "\n" : "");
  }
  if (fmt === "dkvp") {
    return recs.map(r => r.keys.map(k => `${k}=${str(get(r, k))}`).join(",")).join("\n") + (recs.length ? "\n" : "");
  }
  if (fmt === "nidx") {
    return recs.map(r => r.keys.map(k => str(get(r, k))).join(" ")).join("\n") + (recs.length ? "\n" : "");
  }
  if (fmt === "jsonl") {
    return recs.map(r => JSON.stringify(Object.fromEntries(r.keys.map(k => [k, get(r, k)])))).join("\n") + (recs.length ? "\n" : "");
  }
  if (fmt === "json") {
    const objs = recs.map(r => Object.fromEntries(r.keys.map(k => [k, get(r, k)])));
    if (opts.noJvstack) return JSON.stringify(objs) + "\n";
    return JSON.stringify(objs, null, 2) + "\n";
  }
  if (fmt === "pprint") {
    const keys = allKeys(recs);
    if (keys.length === 0) return "";
    const widths = keys.map(k => Math.max(k.length, ...recs.map(r => str(get(r, k)).length)));
    const line = (vals: string[]) => vals.map((v, i) => v.padEnd(widths[i], " ")).join(" ").replace(/\s+$/, "");
    return [line(keys), ...recs.map(r => line(keys.map(k => str(get(r, k)))))].join("\n") + "\n";
  }
  return writeRecords(recs, "dkvp", opts);
}

function readInput(files: string[], opts: any): Rec[] {
  const chunks = files.length ? files.map(f => fs.readFileSync(f, "utf8")).join("") : fs.readFileSync(0, "utf8");
  if (opts.noInput) return [];
  switch (opts.iformat) {
    case "csv": return parseDelimited(chunks, ",", opts.implicitHeader);
    case "tsv": return parseDelimited(chunks, "\t", opts.implicitHeader);
    case "json": return parseJSONInput(chunks, false);
    case "jsonl": return parseJSONInput(chunks, true);
    case "pprint": return parsePprint(chunks);
    default: return parseDKVP(chunks, ",", "=");
  }
}

function parseList(s: string): string[] {
  return s ? s.split(",").filter(Boolean) : [];
}

function applyCat(recs: Rec[], args: string[], files: string[]): Rec[] {
  let counterName: string | null = null;
  let filename = false, filenum = false;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-n") counterName = "n";
    else if (args[i] === "-N") counterName = args[++i];
    else if (args[i] === "--filename") filename = true;
    else if (args[i] === "--filenum") filenum = true;
  }
  return recs.map((r, i) => {
    const c = cloneRec(r);
    if (filenum) set(c, "filenum", 1, true);
    if (filename) set(c, "filename", files[0] ?? "-", true);
    if (counterName) set(c, counterName, i + 1, true);
    return c;
  });
}

function applyCut(recs: Rec[], args: string[]): Rec[] {
  let fields: string[] = [], complement = false, order = false;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-f") fields = parseList(args[++i]);
    else if (args[i] === "-x" || args[i] === "--complement") complement = true;
    else if (args[i] === "-o") order = true;
  }
  return recs.map(r => {
    const keys = complement ? r.keys.filter(k => !fields.includes(k)) : (order ? fields.filter(k => r.values.has(k)) : r.keys.filter(k => fields.includes(k)));
    const values = new Map<string, any>();
    keys.forEach(k => values.set(k, get(r, k)));
    return { keys, values };
  });
}

function applySort(recs: Rec[], args: string[]): Rec[] {
  const specs: {field: string; numeric: boolean; desc: boolean; folded: boolean}[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (["-f","-r","-c","-cr","-n","-nf","-nr"].includes(a)) {
      for (const f of parseList(args[++i])) specs.push({ field: f, numeric: a === "-n" || a === "-nf" || a === "-nr", desc: a === "-r" || a === "-cr" || a === "-nr", folded: a === "-c" || a === "-cr" });
    }
  }
  return [...recs].sort((a, b) => {
    for (const s of specs) {
      let av = get(a, s.field), bv = get(b, s.field);
      let cmp = 0;
      if (s.numeric) cmp = (Number(av) || 0) - (Number(bv) || 0);
      else {
        let as = str(av), bs = str(bv);
        if (s.folded) { as = as.toLowerCase(); bs = bs.toLowerCase(); }
        cmp = as < bs ? -1 : as > bs ? 1 : 0;
      }
      if (cmp !== 0) return s.desc ? -cmp : cmp;
    }
    return 0;
  });
}

function groupKey(r: Rec, fields: string[]): string {
  return fields.map(f => str(get(r, f))).join("\x1f");
}

function applyHeadTail(recs: Rec[], args: string[], tail: boolean): Rec[] {
  let n = 10, groups: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-n") n = Number(args[++i]);
    else if (args[i] === "-g") groups = parseList(args[++i]);
  }
  if (!groups.length) return tail ? recs.slice(Math.max(0, recs.length - n)) : recs.slice(0, n);
  const buckets = new Map<string, Rec[]>();
  for (const r of recs) {
    const k = groupKey(r, groups);
    if (!buckets.has(k)) buckets.set(k, []);
    buckets.get(k)!.push(r);
  }
  const allowed = new Set<Rec>();
  for (const b of buckets.values()) (tail ? b.slice(Math.max(0, b.length - n)) : b.slice(0, n)).forEach(r => allowed.add(r));
  return recs.filter(r => allowed.has(r));
}

function applyCount(recs: Rec[], args: string[]): Rec[] {
  let groups: string[] = [], out = "count";
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-g") groups = parseList(args[++i]);
    else if (args[i] === "-o") out = args[++i];
  }
  if (!groups.length) return [{ keys: [out], values: new Map([[out, recs.length]]) }];
  const map = new Map<string, {vals: any[]; count: number}>();
  for (const r of recs) {
    const vals = groups.map(g => get(r, g));
    const k = vals.map(str).join("\x1f");
    map.set(k, { vals, count: (map.get(k)?.count ?? 0) + 1 });
  }
  return [...map.values()].map(e => {
    const keys = [...groups, out];
    const values = new Map<string, any>();
    groups.forEach((g, i) => values.set(g, e.vals[i]));
    values.set(out, e.count);
    return { keys, values };
  });
}

function percentile(vals: number[], p: number): number {
  if (!vals.length) return NaN;
  const idx = Math.ceil((p / 100) * vals.length) - 1;
  return vals[Math.max(0, Math.min(vals.length - 1, idx))];
}

function applyStats1(recs: Rec[], args: string[]): Rec[] {
  let accs: string[] = [], fields: string[] = [], groups: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-a") accs = parseList(args[++i]);
    else if (args[i] === "-f") fields = parseList(args[++i]);
    else if (args[i] === "-g") groups = parseList(args[++i]);
  }
  if (!accs.length) accs = ["count"];
  const buckets = new Map<string, Rec[]>();
  for (const r of recs) {
    const k = groupKey(r, groups);
    if (!buckets.has(k)) buckets.set(k, []);
    buckets.get(k)!.push(r);
  }
  const out: Rec[] = [];
  for (const bucket of buckets.values()) {
    const keys: string[] = [];
    const values = new Map<string, any>();
    if (groups.length && bucket[0]) for (const g of groups) { keys.push(g); values.set(g, get(bucket[0], g)); }
    for (const f of fields) {
      const raw = bucket.map(r => get(r, f)).filter(v => v !== "");
      const nums = raw.map(Number).filter(v => !Number.isNaN(v)).sort((a, b) => a - b);
      for (const a of accs) {
        const name = a === "median" ? "p50" : a;
        const ok = `${f}_${a}`;
        keys.push(ok);
        if (name === "count") values.set(ok, raw.length);
        else if (name === "null_count") values.set(ok, bucket.length - raw.length);
        else if (name === "distinct_count") values.set(ok, new Set(raw.map(str)).size);
        else if (name === "sum") values.set(ok, nums.reduce((x, y) => x + y, 0));
        else if (name === "mean") values.set(ok, nums.reduce((x, y) => x + y, 0) / nums.length);
        else if (name === "min") values.set(ok, nums[0]);
        else if (name === "max") values.set(ok, nums[nums.length - 1]);
        else if (/^p[0-9.]+$/.test(name)) values.set(ok, percentile(nums, Number(name.slice(1))));
        else if (name === "mode" || name === "antimode") {
          const counts = new Map<string, number>();
          raw.forEach(v => counts.set(str(v), (counts.get(str(v)) ?? 0) + 1));
          let best = "", bestn = name === "mode" ? -1 : Infinity;
          for (const v of raw.map(str)) {
            const c = counts.get(v)!;
            if ((name === "mode" && c > bestn) || (name === "antimode" && c < bestn)) { best = v; bestn = c; }
          }
          values.set(ok, best);
        } else if (name === "var" || name === "stddev") {
          const mean = nums.reduce((x, y) => x + y, 0) / nums.length;
          const variance = nums.length > 1 ? nums.reduce((x, y) => x + (y - mean) ** 2, 0) / (nums.length - 1) : 0;
          values.set(ok, name === "stddev" ? Math.sqrt(variance) : variance);
        } else values.set(ok, "");
      }
    }
    out.push({ keys, values });
  }
  return out;
}

function exprToJS(expr: string, r: Rec): string {
  return expr.replace(/\$([A-Za-z_][A-Za-z0-9_]*)/g, (_, k) => JSON.stringify(get(r, k)))
    .replace(/\bAND\b/g, "&&").replace(/\bOR\b/g, "||");
}

function evalExpr(expr: string, r: Rec): any {
  const js = exprToJS(expr, r);
  return Function(`"use strict"; return (${js});`)();
}

function applyFilter(recs: Rec[], args: string[]): Rec[] {
  let invert = false;
  const parts: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-x") invert = true;
    else if (args[i] === "-e") parts.push(args[++i]);
    else if (!args[i].startsWith("-")) parts.push(args[i]);
  }
  const expr = parts.join(" ");
  return recs.filter(r => Boolean(evalExpr(expr, r)) !== invert);
}

function applyPut(recs: Rec[], args: string[]): Rec[] {
  const expr = args.filter(a => !a.startsWith("-")).join(" ");
  const m = expr.match(/^\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*;?\s*$/);
  if (!m) return recs;
  return recs.map(r => {
    const c = cloneRec(r);
    set(c, m[1], evalExpr(m[2], c));
    return c;
  });
}

function applySimple(recs: Rec[], name: string, args: string[], files: string[]): Rec[] {
  switch (name) {
    case "cat": return applyCat(recs, args, files);
    case "cut": return applyCut(recs, args);
    case "sort": return applySort(recs, args);
    case "head": return applyHeadTail(recs, args, false);
    case "tail": return applyHeadTail(recs, args, true);
    case "tac": return [...recs].reverse();
    case "count": return applyCount(recs, args);
    case "stats1": return applyStats1(recs, args);
    case "filter": return applyFilter(recs, args);
    case "put": return applyPut(recs, args);
    case "uniq": return applyUniq(recs, args);
    case "label": return applyLabel(recs, args);
    case "rename": return applyRename(recs, args);
    case "reorder": return applyReorder(recs, args);
    case "grep": return applyGrep(recs, args);
    case "case": return applyCase(recs, args);
    case "clean-whitespace": return applyCleanWhitespace(recs, args, false);
    case "unspace": return applyCleanWhitespace(recs, args, true);
    case "fill-empty": return applyFillEmpty(recs, args);
    case "fill-down": return applyFillDown(recs, args);
    case "seqgen": return applySeqgen(args);
    case "nothing": return [];
    default: return recs;
  }
}

function applyUniq(recs: Rec[], args: string[]): Rec[] {
  let fields: string[] = [], count = false, all = false, outName = "count";
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-g" || args[i] === "-f") fields = parseList(args[++i]);
    else if (args[i] === "-c") count = true;
    else if (args[i] === "-a") all = true;
    else if (args[i] === "-o") outName = args[++i];
  }
  const seen = new Map<string, {rec: Rec; n: number}>();
  for (const r of recs) {
    const keys = all || !fields.length ? r.keys : fields;
    const k = keys.map(f => `${f}=${str(get(r, f))}`).join("\x1f");
    if (!seen.has(k)) {
      const nr = all || !fields.length ? cloneRec(r) : applyCut([r], ["-f", fields.join(","), "-o"])[0];
      seen.set(k, { rec: nr, n: 0 });
    }
    seen.get(k)!.n++;
  }
  return [...seen.values()].map(e => {
    if (count) set(e.rec, outName, e.n);
    return e.rec;
  });
}

function applyLabel(recs: Rec[], args: string[]): Rec[] {
  const labels = parseList(args.find(a => !a.startsWith("-")) ?? "");
  if (!labels.length) return recs;
  return recs.map(r => {
    const keys = r.keys.map((k, i) => labels[i] ?? k);
    const values = new Map<string, any>();
    r.keys.forEach((k, i) => values.set(keys[i], get(r, k)));
    return { keys, values };
  });
}

function applyRename(recs: Rec[], args: string[]): Rec[] {
  let pairs: string[] = [];
  for (let i = 0; i < args.length; i++) if (args[i] === "-f" || !args[i].startsWith("-")) pairs = parseList(args[i] === "-f" ? args[++i] : args[i]);
  const map = new Map<string, string>();
  for (let i = 0; i + 1 < pairs.length; i += 2) map.set(pairs[i], pairs[i + 1]);
  return recs.map(r => {
    const keys = r.keys.map(k => map.get(k) ?? k);
    const values = new Map<string, any>();
    r.keys.forEach((k, i) => values.set(keys[i], get(r, k)));
    return { keys, values };
  });
}

function applyReorder(recs: Rec[], args: string[]): Rec[] {
  let fields: string[] = [], end = false;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-f") fields = parseList(args[++i]);
    else if (args[i] === "-e") end = true;
  }
  return recs.map(r => {
    const selected = fields.filter(f => r.values.has(f));
    const rest = r.keys.filter(k => !selected.includes(k));
    const keys = end ? [...rest, ...selected] : [...selected, ...rest];
    return { keys, values: new Map(r.values) };
  });
}

function applyGrep(recs: Rec[], args: string[]): Rec[] {
  let inv = false, valuesOnly = false, ci = false, pat = "";
  for (const a of args) {
    if (a === "-v") inv = true;
    else if (a === "-a") valuesOnly = true;
    else if (a === "-i") ci = true;
    else if (!a.startsWith("-")) pat = a;
  }
  const re = new RegExp(pat, ci ? "i" : "");
  return recs.filter(r => {
    const s = valuesOnly ? r.keys.map(k => str(get(r, k))).join(",") : r.keys.map(k => `${k}=${str(get(r, k))}`).join(",");
    return re.test(s) !== inv;
  });
}

function titleCase(s: string): string {
  return s.replace(/\b\w/g, c => c.toUpperCase());
}

function applyCase(recs: Rec[], args: string[]): Rec[] {
  let keysOnly = false, valsOnly = false, mode = "upper";
  let fields: string[] | null = null;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-k") keysOnly = true;
    else if (args[i] === "-v") valsOnly = true;
    else if (args[i] === "-f") fields = parseList(args[++i]);
    else if (args[i] === "-l") mode = "lower";
    else if (args[i] === "-s") mode = "sentence";
    else if (args[i] === "-t") mode = "title";
    else if (args[i] === "-u") mode = "upper";
  }
  const conv = (s: string) => mode === "lower" ? s.toLowerCase() : mode === "title" ? titleCase(s.toLowerCase()) : mode === "sentence" ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : s.toUpperCase();
  return recs.map(r => {
    const keys = r.keys.map(k => (!valsOnly && (!fields || fields.includes(k))) ? conv(k) : k);
    const values = new Map<string, any>();
    r.keys.forEach((old, i) => {
      const nk = keys[i];
      let v = get(r, old);
      if (!keysOnly && (!fields || fields.includes(old)) && typeof v === "string") v = conv(v);
      values.set(nk, v);
    });
    return { keys, values };
  });
}

function applyCleanWhitespace(recs: Rec[], args: string[], unspace: boolean): Rec[] {
  let keysOnly = false, valsOnly = false, filler = "_";
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-k" || args[i] === "--keys-only") keysOnly = true;
    else if (args[i] === "-v" || args[i] === "--values-only") valsOnly = true;
    else if (args[i] === "-f") filler = args[++i];
  }
  const conv = (s: string) => unspace ? s.replace(/ /g, filler) : s.trim().replace(/\s+/g, " ");
  return recs.map(r => {
    const keys = r.keys.map(k => valsOnly ? k : conv(k));
    const values = new Map<string, any>();
    r.keys.forEach((old, i) => {
      let v = get(r, old);
      if (!keysOnly && typeof v === "string") v = conv(v);
      values.set(keys[i], v);
    });
    return { keys, values };
  });
}

function applyFillEmpty(recs: Rec[], args: string[]): Rec[] {
  let fill = "N/A";
  for (let i = 0; i < args.length; i++) if (args[i] === "-v") fill = args[++i];
  return recs.map(r => {
    const c = cloneRec(r);
    for (const k of c.keys) if (get(c, k) === "") c.values.set(k, infer(fill));
    return c;
  });
}

function applyFillDown(recs: Rec[], args: string[]): Rec[] {
  let fields: string[] = [], all = false, absentOnly = false;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "-f") fields = parseList(args[++i]);
    else if (args[i] === "--all") all = true;
    else if (args[i] === "-a" || args[i] === "--only-if-absent") absentOnly = true;
  }
  const last = new Map<string, any>();
  return recs.map(r => {
    const c = cloneRec(r);
    const fs = all ? c.keys : fields;
    for (const f of fs) {
      const missing = absentOnly ? !c.values.has(f) : (!c.values.has(f) || get(c, f) === "");
      if (missing && last.has(f)) set(c, f, last.get(f));
      if (c.values.has(f) && get(c, f) !== "") last.set(f, get(c, f));
    }
    return c;
  });
}

function applySeqgen(args: string[]): Rec[] {
  let start = 1, stop = 100, step = 1, name = "i";
  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--start" || args[i] === "--gen-start") start = Number(args[++i]);
    else if (args[i] === "--stop" || args[i] === "--gen-stop") stop = Number(args[++i]);
    else if (args[i] === "--step" || args[i] === "--gen-step") step = Number(args[++i]);
    else if (args[i] === "-f" || args[i] === "--gen-field-name") name = args[++i];
  }
  const out: Rec[] = [];
  for (let v = start; step >= 0 ? v <= stop : v >= stop; v += step) out.push({ keys: [name], values: new Map([[name, v]]) });
  return out;
}

const verbNames = new Set("altkv bar bootstrap case cat check clean-whitespace count-distinct count count-similar cut decimate fill-down fill-empty filter flatten format-values fraction gap grep group-by group-like gsub having-fields head histogram json-parse json-stringify join label least-frequent merge-fields most-frequent nest nothing put regularize remove-empty-columns rename reorder repeat reshape sample sec2gmtdate sec2gmt seqgen shuffle skip-trivial-records sort sort-within-records sparsify split ssub stats1 stats2 step sub summary surv tac tail tee template top uniq unspace unsparsify".split(" "));

function parseArgs(argv: string[]) {
  const opts: any = { iformat: "dkvp", oformat: "dkvp", implicitHeader: false, headerlessOutput: false, quoteAll: false, noInput: false, noJvstack: false };
  const files: string[] = [];
  const verbs: Verb[] = [];
  let i = 0;
  function setFmt(inFmt: string, outFmt: string) { opts.iformat = inFmt; opts.oformat = outFmt; }
  while (i < argv.length) {
    const a = argv[i];
    if (a === "--help" || a === "-h") { printUsage(); process.exit(0); }
    if (a === "--version") { console.log(VERSION); process.exit(0); }
    if (a === "version") { console.log("mlr version 6.16.0 for linux/amd64/go1.24.0"); process.exit(0); }
    if (a === "help") { printHelp(argv.slice(i + 1)); process.exit(0); }
    if (a === "--csv" || a === "-c" || a === "--c2c") setFmt("csv", "csv");
    else if (a === "--tsv" || a === "-t" || a === "--t2t") setFmt("tsv", "tsv");
    else if (a === "--dkvp" || a === "--d2d") setFmt("dkvp", "dkvp");
    else if (a === "--json" || a === "-j" || a === "--j2j") setFmt("json", "json");
    else if (a === "--jsonl" || a === "--l2l") setFmt("jsonl", "jsonl");
    else if (a === "--pprint" || a === "--p2p") setFmt("pprint", "pprint");
    else if (/^--[cdjlntp]2[cdjlntp]$/.test(a)) {
      const map: any = { c: "csv", t: "tsv", d: "dkvp", j: "json", l: "jsonl", n: "nidx", p: "pprint" };
      opts.iformat = map[a[2]]; opts.oformat = map[a[4]];
    }
    else if (a === "--icsv") opts.iformat = "csv";
    else if (a === "--itsv") opts.iformat = "tsv";
    else if (a === "--idkvp") opts.iformat = "dkvp";
    else if (a === "--ijson") opts.iformat = "json";
    else if (a === "--ijsonl") opts.iformat = "jsonl";
    else if (a === "--ipprint") opts.iformat = "pprint";
    else if (a === "--ocsv") opts.oformat = "csv";
    else if (a === "--otsv") opts.oformat = "tsv";
    else if (a === "--odkvp") opts.oformat = "dkvp";
    else if (a === "--ojson") opts.oformat = "json";
    else if (a === "--ojsonl") opts.oformat = "jsonl";
    else if (a === "--opprint") opts.oformat = "pprint";
    else if (a === "-i" || a === "--io") { opts.iformat = argv[++i]; if (a === "--io") opts.oformat = opts.iformat; }
    else if (a === "-o") opts.oformat = argv[++i];
    else if (a === "-N") { opts.implicitHeader = true; opts.headerlessOutput = true; }
    else if (a === "--implicit-csv-header" || a === "--hi" || a === "--headerless-csv-input") opts.implicitHeader = true;
    else if (a === "--headerless-csv-output" || a === "--ho") opts.headerlessOutput = true;
    else if (a === "--quote-all") opts.quoteAll = true;
    else if (a === "--no-jvstack") opts.noJvstack = true;
    else if (a === "-n") opts.noInput = true;
    else if (a === "--from") files.push(argv[++i]);
    else if (verbNames.has(a) || a === "then") break;
    else if (a.startsWith("-")) { if (["--fs","--ifs","--ofs","--rs","--ors","--ofmt"].includes(a)) i++; }
    else break;
    i++;
  }
  let cur: Verb | null = null;
  for (; i < argv.length; i++) {
    const a = argv[i];
    if (a === "then") { if (cur) verbs.push(cur); cur = null; continue; }
    if (!cur && verbNames.has(a)) cur = { name: a, args: [] };
    else if (cur) cur.args.push(a);
    else files.push(a);
  }
  if (cur) verbs.push(cur);
  while (verbs.length && verbs[verbs.length - 1].args.length) {
    const args = verbs[verbs.length - 1].args;
    const last = args[args.length - 1];
    if (!last.startsWith("-") && fs.existsSync(last)) files.unshift(args.pop()!);
    else break;
  }
  if (!verbs.length) verbs.push({ name: "cat", args: [] });
  return { opts, files, verbs };
}

function printUsage() {
  console.log(`Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}

If zero file names are provided, standard input is read, e.g.
  mlr --csv sort -f shape example.csv

Output of one verb may be chained as input to another using "then", e.g.
  mlr --csv stats1 -a min,mean,max -f quantity then sort -f color example.csv

Please see 'mlr help topics' for more information.
Please also see https://miller.readthedocs.io`);
}

function printHelp(args: string[]) {
  const topic = args.join(" ");
  if (topic === "topics" || topic === "") {
    console.log(`Type 'mlr help {topic}' for any of the following:
Essentials:
  mlr help topics
  mlr help basic-examples
  mlr help file-formats
Flags:
  mlr help flags
Verbs:
  mlr help list-verbs
  mlr help usage-verbs`);
  } else if (topic === "list-verbs") console.log([...verbNames].join("\n"));
  else if (topic === "basic-examples") console.log(`mlr --icsv --opprint cat example.csv
mlr --icsv --opprint sort -f shape example.csv
mlr --icsv --opprint sort -f shape -nr index example.csv
mlr --icsv --opprint cut -f flag,shape example.csv
mlr --csv filter '$color == "red"' example.csv
mlr --icsv --ojson put '$ratio = $quantity / $rate' example.csv
mlr --icsv --opprint --from example.csv sort -nr index then cut -f shape,quantity`);
  else if (topic.startsWith("verb ")) console.log(`${topic.slice(5)}\nUsage: mlr ${topic.slice(5)} [options]`);
  else if (topic === "flags") console.log("FILE-FORMAT FLAGS\n--csv --tsv --dkvp --json --jsonl --icsv --ocsv --opprint\n");
  else console.log(`No help found for "${topic}". Please try 'mlr help find ${topic}' for approximate match.\nSee also 'mlr help topics'.`);
}

function main() {
  const { opts, files, verbs } = parseArgs(process.argv.slice(2));
  let recs = readInput(files, opts);
  for (const v of verbs) recs = applySimple(recs, v.name, v.args, files);
  process.stdout.write(writeRecords(recs, opts.oformat, opts));
}

main();
