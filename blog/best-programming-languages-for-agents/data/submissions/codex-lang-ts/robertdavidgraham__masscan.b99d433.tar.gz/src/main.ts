declare const process: {
  argv: string[];
  exit(code?: number): never;
  stdout: { write(s: string): void };
  stderr: { write(s: string): void };
};
declare function require(name: string): any;

const fs = require("fs");

type Opts = {
  help: "long" | "short" | false;
  nmap: boolean;
  version: boolean;
  echo: boolean;
  iflist: boolean;
  selftest: boolean;
  readscan?: string;
  ranges: string[];
  ports: string[];
  rate: string;
  seed?: string;
  shard: string;
  banners: boolean;
  nocapture: string[];
  outputFilename?: string;
  outputFormat?: string;
  outputAppend: boolean;
  adapterIp?: string;
  adapterMac?: string;
  routerMac?: string;
  adapterPort?: string;
  excludes: string[];
  excludefile?: string;
  includefile?: string;
  verbosity: number;
  debug: number;
  packetTrace: boolean;
  openOnly: boolean;
};

const shortHelp = `usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]

examples:
    masscan -p80,8000-8100 10.0.0.0/8 --rate=10000
        scan some web ports on 10.x.x.x at 10kpps

    masscan --nmap
        list those options that are compatible with nmap

    masscan -p80 10.0.0.0/8 --banners -oB <filename>
        save results of scan in binary format to <filename>

    masscan --open --banners --readscan <filename> -oX <savefile>
        read binary scan results in <filename> and save them as xml in <savefile>
`;

const longHelp = `usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]
MASSCAN is a fast port scanner. The primary input parameters are the
IP addresses/ranges you want to scan, and the port numbers. An example
is the following, which scans the 10.x.x.x network for web servers:

    masscan 10.0.0.0/8 -p80

The program auto-detects network interface/adapter settings. If this
fails, you'll have to set these manually. The following is an
example of all the parameters that are needed:

    --adapter-ip 192.168.10.123
    --adapter-mac 00-11-22-33-44-55
    --router-mac 66-55-44-33-22-11

Parameters can be set either via the command-line or config-file. The
names are the same for both. Thus, the above adapter settings would
appear as follows in a configuration file:

    adapter-ip = 192.168.10.123
    adapter-mac = 00-11-22-33-44-55
    router-mac = 66-55-44-33-22-11

All single-dash parameters have a spelled out double-dash equivalent,
so '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).
To use the config file, type:

    masscan -c <filename>

To generate a config-file from the current settings, use the --echo
option. This stops the program from actually running, and just echoes
the current configuration instead. This is a useful way to generate
your first config file, or see a list of parameters you didn't know
about. I suggest you try it now:

    masscan -p1234 --echo
`;

const nmapHelp = `Masscan (https://github.com/robertdavidgraham/masscan)
Usage: masscan [Options] -p{Target-Ports} {Target-IP-Ranges}
TARGET SPECIFICATION:
  Can pass only IPv4/IPv6 address, CIDR networks, or ranges (non-nmap style)
  Ex: 10.0.0.0/8, 192.168.0.1, 10.0.0.1-10.0.0.254
  -iL <inputfilename>: Input from list of hosts/networks
  --exclude <host1[,host2][,host3],...>: Exclude hosts/networks
  --excludefile <exclude_file>: Exclude list from file
  --randomize-hosts: Randomize order of hosts (default)
HOST DISCOVERY:
  -Pn: Treat all hosts as online (default)
  -n: Never do DNS resolution (default)
SCAN TECHNIQUES:
  -sS: TCP SYN (always on, default)
SERVICE/VERSION DETECTION:
  --banners: get the banners of the listening service if available. The
    default timeout for waiting to receive data is 30 seconds.
PORT SPECIFICATION AND SCAN ORDER:
  -p <port ranges>: Only scan specified ports
    Ex: -p22; -p1-65535; -p 111,137,80,139,8080
TIMING AND PERFORMANCE:
  --max-rate <number>: Send packets no faster than <number> per second
  --connection-timeout <number>: time in seconds a TCP connection will
    timeout while waiting for banner data from a port.
FIREWALL/IDS EVASION AND SPOOFING:
  -S/--source-ip <IP_Address>: Spoof source address
  -e <iface>: Use specified interface
  -g/--source-port <portnum>: Use given port number
  --ttl <val>: Set IP time-to-live field
  --spoof-mac <mac address/prefix/vendor name>: Spoof your MAC address
OUTPUT:
  --output-format <format>: Sets output to binary/list/unicornscan/json/ndjson/grepable/xml
  --output-file <file>: Write scan results to file. If --output-format is
     not given default is xml
  -oL/-oJ/-oD/-oG/-oB/-oX/-oU <file>: Output scan in List/JSON/nDjson/Grepable/Binary/XML/Unicornscan format,
     respectively, to the given filename. Shortcut for
     --output-format <format> --output-file <file>
  -v: Increase verbosity level (use -vv or more for greater effect)
  -d: Increase debugging level (use -dd or more for greater effect)
  --open: Only show open (or possibly open) ports
  --packet-trace: Show all packets sent and received
  --iflist: Print host interfaces and routes (for debugging)
  --append-output: Append to rather than clobber specified output files
  --resume <filename>: Resume an aborted scan
MISC:
  --send-eth: Send using raw ethernet frames (default)
  -V: Print version number
  -h: Print this help summary page.
EXAMPLES:
  masscan -v -sS 192.168.0.0/16 10.0.0.0/8 -p 80
  masscan 23.0.0.0/0 -p80 --banners -output-format binary --output-filename internet.scan
  masscan --open --banners --readscan internet.scan -oG internet_scan.grepable
SEE (https://github.com/robertdavidgraham/masscan) FOR MORE HELP
`;

function out(s: string) { process.stdout.write(s); }
function err(s: string) { process.stderr.write(s); }
function pcapFail() {
  err("[-] FAIL: failed to load libpcap shared library\n");
  err("    [hint]: you must install libpcap or WinPcap\n");
}
function pcapVerboseFail() {
  for (const name of ["libpcap.so","libpcap.A.dylib","libpcap.dylib","libpcap.so.1","libpcap.so.0.9.5","libpcap.so.0.9.4","libpcap.so.0.8"]) err(`[-] pcap: failed to load: ${name}\n`);
  pcapFail();
  for (const fn of ["pcap_close","pcap_datalink","pcap_dispatch","pcap_findalldevs","pcap_freealldevs","pcap_lib_version","pcap_lookupdev","pcap_major_version","pcap_minor_version","pcap_open_live","pcap_open_offline","pcap_sendpacket","pcap_next","pcap_setdirection","pcap_datalink_val_to_name","pcap_perror","pcap_geterr","pcap_create","pcap_set_snaplen","pcap_set_promisc","pcap_set_timeout","pcap_set_immediate_mode","pcap_set_buffer_size","pcap_set_rfmon","pcap_can_set_rfmon","pcap_activate"]) err(`pcap: ${fn}: failed\n`);
  err("pfring: error: dlopen('libpfring.so'): No such file or directory\n");
}

function nextArg(args: string[], i: number, name: string): [string | undefined, number] {
  if (i + 1 >= args.length || args[i + 1].startsWith("-")) {
    err(`${name}: empty parameter\n`);
    pcapFail();
    out(shortHelp);
    process.exit(1);
  }
  return [args[i + 1], i + 1];
}

function defaultOpts(): Opts {
  return { help: false, nmap: false, version: false, echo: false, iflist: false, selftest: false,
    ranges: [], ports: [], rate: "100", shard: "1/1", banners: false,
    nocapture: ["servername", "servername"], outputAppend: false, excludes: [],
    verbosity: 0, debug: 0, packetTrace: false, openOnly: false };
}

function setParam(o: Opts, key: string, val: string) {
  switch (key.toLowerCase()) {
    case "p": case "ports": o.ports.push(val); break;
    case "range": case "ranges": o.ranges.push(val); break;
    case "rate": case "max-rate": o.rate = val; break;
    case "seed": o.seed = val; break;
    case "shard": case "shards": o.shard = val; break;
    case "banners": o.banners = val === "" || /^(1|true|yes)$/i.test(val); break;
    case "adapter-ip": case "source-ip": o.adapterIp = val; break;
    case "adapter-mac": o.adapterMac = val; break;
    case "router-mac": o.routerMac = val; break;
    case "adapter-port": case "source-port": o.adapterPort = val; break;
    case "output-filename": case "output-file": o.outputFilename = val; break;
    case "output-format": o.outputFormat = normalizeFormat(val); break;
    case "output-append": case "append-output": o.outputAppend = val === "" || /^(1|true|yes)$/i.test(val); break;
    case "exclude": o.excludes.push(val); break;
    case "excludefile": o.excludefile = val; break;
    case "include-file": case "iL": o.includefile = val; break;
  }
}

function parseConfig(o: Opts, file: string) {
  let text: string;
  try { text = fs.readFileSync(file, "utf8"); } catch {
    err(`[-] ${file}: No such file or directory\n`);
    process.exit(1);
  }
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.replace(/#.*/, "").trim();
    if (!line) continue;
    const m = line.match(/^([^=\s]+)\s*(?:=|\s)\s*(.*?)\s*$/);
    if (m) setParam(o, m[1], m[2]);
  }
}

function normalizeFormat(v: string): string {
  const x = v.toLowerCase();
  if (x === "d" || x === "ndjson") return "ndjson";
  if (x === "x" || x === "xml") return "xml";
  if (x === "j" || x === "json") return "json";
  if (x === "g" || x === "grepable") return "grepable";
  if (x === "b" || x === "binary") return "binary";
  if (x === "l" || x === "list") return "list";
  if (x === "u" || x === "unicornscan") return "unicornscan";
  return v;
}

function outputOpt(o: Opts, fmt: string, file: string) {
  o.outputFilename = file;
  o.outputFormat = fmt;
}

function parse(args: string[]): Opts {
  const o = defaultOpts();
  for (let i = 0; i < args.length; i++) {
    let a = args[i];
    if (a === "--") { o.ranges.push(...args.slice(i + 1)); break; }
    if (a === "--help") o.help = "long";
    else if (a === "-h") o.help = "short";
    else if (a === "--nmap") o.nmap = true;
    else if (a === "--version" || a === "-V") o.version = true;
    else if (a === "--echo") o.echo = true;
    else if (a === "--iflist") o.iflist = true;
    else if (a === "--selftest") o.selftest = true;
    else if (a === "--banners") o.banners = true;
    else if (a === "--open") o.openOnly = true;
    else if (a === "--packet-trace") o.packetTrace = true;
    else if (a === "--append-output") o.outputAppend = true;
    else if (a === "-v" || /^-v+$/.test(a)) o.verbosity += a.length - 1;
    else if (a === "-d" || /^-d+$/.test(a)) o.debug += a.length - 1;
    else if (a === "-Pn" || a === "-n" || a === "-sS" || a === "--send-eth" || a === "--randomize-hosts") {}
    else if (a === "-c" || a === "--conf" || a === "--config") { const r = nextArg(args, i, a); parseConfig(o, r[0]!); i = r[1]; }
    else if (a.startsWith("--") && a.includes("=")) { const [k, ...rest] = a.slice(2).split("="); setParam(o, k, rest.join("=")); }
    else if (a === "-p" || a === "--ports") { const r = nextArg(args, i, a === "-p" ? "(null)" : "ports"); o.ports.push(r[0]!); i = r[1]; }
    else if (a.startsWith("-p") && a.length > 2) o.ports.push(a.slice(2));
    else if (a === "-S" || a === "--source-ip" || a === "--adapter-ip") { const r = nextArg(args, i, a); o.adapterIp = r[0]; i = r[1]; }
    else if (a === "-g" || a === "--source-port" || a === "--adapter-port") { const r = nextArg(args, i, a); o.adapterPort = r[0]; i = r[1]; }
    else if (a === "--adapter-mac") { const r = nextArg(args, i, a); o.adapterMac = r[0]; i = r[1]; }
    else if (a === "--router-mac") { const r = nextArg(args, i, a); o.routerMac = r[0]; i = r[1]; }
    else if (a === "--rate" || a === "--max-rate") { const r = nextArg(args, i, a); o.rate = r[0]!; i = r[1]; }
    else if (a === "--seed") { const r = nextArg(args, i, a); o.seed = r[0]; i = r[1]; }
    else if (a === "--shard" || a === "--shards") { const r = nextArg(args, i, a); o.shard = r[0]!; i = r[1]; }
    else if (a === "--exclude") { const r = nextArg(args, i, a); o.excludes.push(r[0]!); i = r[1]; }
    else if (a === "--excludefile") { const r = nextArg(args, i, a); o.excludefile = r[0]; i = r[1]; }
    else if (a === "--include-file" || a === "-iL") { const r = nextArg(args, i, a); o.includefile = r[0]; i = r[1]; }
    else if (a === "--readscan") { const r = nextArg(args, i, a); o.readscan = r[0]; i = r[1]; }
    else if (a === "--output-format") { const r = nextArg(args, i, a); o.outputFormat = normalizeFormat(r[0]!); i = r[1]; }
    else if (a === "--output-filename" || a === "--output-file") { const r = nextArg(args, i, a); o.outputFilename = r[0]; i = r[1]; }
    else if (/^-o[XLJGDBU]$/.test(a)) { const r = nextArg(args, i, a); outputOpt(o, ({X:"xml",L:"list",J:"json",G:"grepable",D:"ndjson",B:"binary",U:"unicornscan"} as any)[a[2]], r[0]!); i = r[1]; }
    else if (a.startsWith("-")) {
      const name = a.replace(/^-+/, "");
      err(`${name}: empty parameter\n`);
      pcapFail();
      out(shortHelp);
      process.exit(1);
    } else {
      o.ranges.push(a);
    }
  }
  return o;
}

function seed(): string {
  const hi = BigInt(Math.floor(Math.random() * 0x100000000));
  const lo = BigInt(Math.floor(Math.random() * 0x100000000));
  return ((hi << 32n) | lo).toString();
}
function rateString(v: string): string {
  const n = Number(v);
  if (!Number.isFinite(n)) return v;
  if (!v.includes(".") && Number.isInteger(n)) return String(n).padEnd(10, " ");
  return n.toFixed(6);
}
function cleanPorts(ports: string[]): string {
  const joined = ports.join(",");
  return joined.replace(/\bT:/gi, "").replace(/\btcp:/gi, "").replace(/\bU:/gi, "U:").replace(/\bS:/gi, "S:");
}
function emitEcho(o: Opts) {
  out(`seed = ${o.seed ?? seed()}\n`);
  out(`rate = ${rateString(o.rate)}\n`);
  out(`shard = ${o.shard}\n`);
  if (o.banners) out("banners = true\n");
  for (const n of o.nocapture) out(`nocapture = ${n}\n`);
  out("\n");
  if (o.outputFilename || o.outputFormat || o.outputAppend) {
    if (o.outputFilename) out(`output-filename = ${o.outputFilename}\n`);
    if (o.outputFormat) out(`output-format = ${o.outputFormat}\n`);
    if (o.outputAppend) out("output-append = true\n");
    out("\n");
  }
  if (o.adapterIp || o.adapterMac || o.routerMac || o.adapterPort) {
    if (o.adapterIp) out(`adapter-ip = ${o.adapterIp}\n`);
    if (o.adapterMac) out(`adapter-mac = ${o.adapterMac}\n`);
    if (o.routerMac) { out(`router-mac-ipv4 = ${o.routerMac}\n`); out(`router-mac-ipv6 = ${o.routerMac}\n`); }
    if (o.adapterPort) out(`adapter-port = ${o.adapterPort}\n`);
  }
  out("# TARGET SELECTION (IP, PORTS, EXCLUDES)\n");
  if (o.ports.length) out(`ports = ${cleanPorts(o.ports)}\n`);
  for (const r of o.ranges) out(`range = ${r}\n`);
  for (const e of o.excludes) out(`exclude = ${e}\n`);
  if (o.excludefile) out(`excludefile = ${o.excludefile}\n`);
  if (o.includefile) out(`include-file = ${o.includefile}\n`);
}

function emitVersion() {
  out("\nMasscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )\n");
  out("Compiled on: Apr 17 2026 19:59:25\nCompiler: gcc 11.4.0\nOS: Linux\nCPU: x86 (64 bits)\nGIT version: unknown\n");
}

function main() {
  const o = parse(process.argv.slice(2));
  if (o.version) { emitVersion(); process.exit(1); }
  if (o.nmap) { out(nmapHelp + "\n"); process.exit(1); }
  if (o.help) { out(o.help === "long" ? longHelp : shortHelp); process.exit(1); }
  if (o.debug >= 2 || o.verbosity >= 2) pcapVerboseFail(); else pcapFail();
  if (o.iflist) { out("libpcap not loaded\n"); process.exit(0); }
  if (o.selftest) { out("regression test: success!\n"); process.exit(0); }
  if (o.excludefile && !fs.existsSync(o.excludefile)) { err("[-] FAIL: parsing IP addresses\n"); err(`[-] ${o.excludefile}: No such file or directory\n`); process.exit(1); }
  if (o.includefile && !fs.existsSync(o.includefile)) { err("[-] FAIL: parsing IP addresses\n"); err(`[-] ${o.includefile}: No such file or directory\n`); process.exit(1); }
  if (o.readscan) {
    if (!fs.existsSync(o.readscan)) { err("[-] FAIL: --readscan\n"); err(`[-] ${o.readscan}: No such file or directory\n`); process.exit(0); }
    if (o.outputFilename) fs.writeFileSync(o.outputFilename, "");
    process.exit(0);
  }
  if (o.echo) { emitEcho(o); process.exit(0); }
  if (!o.ports.length) { err("[-] FAIL: no ports specified\n"); process.exit(1); }
  err("[-] FAIL: could not determine default interface\n");
  err("    [hint] try \"--interface ethX\"\n");
  process.exit(1);
}

main();
