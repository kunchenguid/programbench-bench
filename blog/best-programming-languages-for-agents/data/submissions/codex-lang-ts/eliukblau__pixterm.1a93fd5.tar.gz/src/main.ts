// @ts-nocheck
declare const require: any;
declare const process: any;
declare const Buffer: any;
const fs = require('fs');
const zlib = require('zlib');

const VERSION = '1.3.2';
const banner = `   ___  _____  ____
  / _ \\/  _/ |/_/ /____ ______ _      Made with love by Eliuk Blau
 / ___// /_>  </ __/ -_) __/  ' \\ https://github.com/eliukblau/pixterm
/_/  /___/_/|_|\\__/\\__/_/ /_/_/_/                ${VERSION}
`;
const help = `${banner}
USAGE:

  executable [options] image/url

  Supported image formats: JPEG, PNG, GIF, BMP, TIFF, WebP.
  Supported URL protocols: HTTP, HTTPS.

OPTIONS:

  -credits
    \tshow some love to contributors <3
  -d mode
    \tdithering mode:
    \t   0 - no dithering (default)
    \t   1 - with blocks
    \t   2 - with chars
  -go
    \toutput Go code to 'fmt.Print()' the image
  -m color
    \tmatte color for transparency or background
    \t(optional, hex format, default: 000000)
  -nobg
    \tdisable background color
    \t(optional, only in dithering mode, ignores matte color)
  -s method
    \tscale method:
    \t   0 - resize (default)
    \t   1 - fill
    \t   2 - fit
  -tc columns
    \tterminal columns (optional, >=2; when piping, default: 80)
  -tr rows
    \tterminal rows (optional, >=2; when piping, default: 24)
  -version
    \tshow PIXterm version
  -help
\tprints this message :D LOL
`;
const credits = `${banner}
CONTRIBUTORS:

  > @disq - https://github.com/disq
      + Original code for image transparency support.

  > @timob - https://github.com/timob
      + Fix for ANSIpixel type: use 8bit color component for output.

  > @HongjiangHuang - https://github.com/HongjiangHuang
      + Original code for image download support.

  > @brutestack - https://github.com/brutestack
      + Color support for Windows (Command Prompt & PowerShell).
      + Original code for disable background color in dithering mode.
      + Original code for output Go code to 'fmt.Print()' the image.

  > @diamondburned - https://github.com/diamondburned
      + NewFromImage() & NewScaledFromImage() for ANSImage API.

  > @MichaelMure - https://github.com/MichaelMure
      + More conventional 'go.mod' file at repository.

  > @Calinou - https://github.com/Calinou
      + Use HTTPS URLs everywhere.
      + Other awesome contributions.

  > @danirod - https://github.com/danirod
  > @Xpktro - https://github.com/Xpktro
      + Moral support.
`;

type Image = { width: number; height: number; data: Uint8ClampedArray };
type RGB = [number, number, number];

function die(msg: string): void {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  const stamp = `${d.getFullYear()}/${pad(d.getMonth()+1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  process.stderr.write(`${banner}\n[PIXTERM ERROR] ${stamp} ${msg}\n`);
  process.exit(1);
}
function showHelp(): void { process.stdout.write(help); }
function parseHex(s: string): RGB | null {
  if (!/^[0-9a-fA-F]{6}$/.test(s)) return null;
  return [parseInt(s.slice(0,2),16), parseInt(s.slice(2,4),16), parseInt(s.slice(4,6),16)];
}

function paeth(a: number, b: number, c: number): number {
  const p = a + b - c, pa = Math.abs(p-a), pb = Math.abs(p-b), pc = Math.abs(p-c);
  return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
}

function readPng(buf: any): Image {
  if (buf.length < 8 || buf.toString('hex',0,8) !== '89504e470d0a1a0a') throw new Error('image: unknown format');
  let off = 8, width = 0, height = 0, bit = 8, color = 6, interlace = 0;
  const idats: any[] = [];
  let palette: number[] | null = null, trans: any | null = null;
  while (off + 8 <= buf.length) {
    const len = buf.readUInt32BE(off); const typ = buf.toString('ascii', off+4, off+8); const data = buf.subarray(off+8, off+8+len); off += 12 + len;
    if (typ === 'IHDR') { width=data.readUInt32BE(0); height=data.readUInt32BE(4); bit=data[8]; color=data[9]; interlace=data[12]; }
    else if (typ === 'IDAT') idats.push(data);
    else if (typ === 'PLTE') palette = Array.from(data);
    else if (typ === 'tRNS') trans = data;
    else if (typ === 'IEND') break;
  }
  if (interlace !== 0) throw new Error('interlaced PNG is not supported');
  if (bit !== 8 && !(color === 3 && [1,2,4,8].includes(bit))) throw new Error('unsupported PNG bit depth');
  const channels = color === 0 ? 1 : color === 2 ? 3 : color === 3 ? 1 : color === 4 ? 2 : color === 6 ? 4 : 0;
  if (!channels) throw new Error('unsupported PNG color type');
  const bpp = Math.max(1, Math.ceil(channels * bit / 8));
  const scan = Math.ceil(width * channels * bit / 8);
  const raw = zlib.inflateSync(Buffer.concat(idats));
  const recon = Buffer.alloc(height * scan);
  let p = 0;
  for (let y=0; y<height; y++) {
    const f = raw[p++]; const row = recon.subarray(y*scan, (y+1)*scan); const prev = y ? recon.subarray((y-1)*scan, y*scan) : null;
    for (let x=0; x<scan; x++) {
      const val = raw[p++]; const left = x>=bpp ? row[x-bpp] : 0; const up = prev ? prev[x] : 0; const ul = prev && x>=bpp ? prev[x-bpp] : 0;
      if (f === 0) row[x] = val;
      else if (f === 1) row[x] = (val + left) & 255;
      else if (f === 2) row[x] = (val + up) & 255;
      else if (f === 3) row[x] = (val + Math.floor((left+up)/2)) & 255;
      else if (f === 4) row[x] = (val + paeth(left, up, ul)) & 255;
      else throw new Error('bad PNG filter');
    }
  }
  const out = new Uint8ClampedArray(width*height*4);
  for (let y=0; y<height; y++) {
    const row = recon.subarray(y*scan, (y+1)*scan);
    for (let x=0; x<width; x++) {
      let r=0,g=0,b=0,a=255;
      if (color === 6) { const i=x*4; r=row[i]; g=row[i+1]; b=row[i+2]; a=row[i+3]; }
      else if (color === 2) { const i=x*3; r=row[i]; g=row[i+1]; b=row[i+2]; }
      else if (color === 0) { r=g=b=row[x]; if (trans && trans.length>=2 && row[x] === trans.readUInt16BE(0)) a=0; }
      else if (color === 4) { const i=x*2; r=g=b=row[i]; a=row[i+1]; }
      else if (color === 3) {
        let idx: number;
        if (bit === 8) idx = row[x]; else { const per=8/bit, byte=row[Math.floor(x/per)], shift=(per-1-(x%per))*bit; idx=(byte>>shift)&((1<<bit)-1); }
        if (!palette || idx*3+2 >= palette.length) throw new Error('bad PNG palette');
        r=palette[idx*3]; g=palette[idx*3+1]; b=palette[idx*3+2]; a=trans && idx<trans.length ? trans[idx] : 255;
      }
      const o=(y*width+x)*4; out[o]=r; out[o+1]=g; out[o+2]=b; out[o+3]=a;
    }
  }
  return {width, height, data: out};
}

function readBmp(buf: any): Image {
  if (buf.toString('ascii',0,2) !== 'BM') throw new Error('image: unknown format');
  const dataOff = buf.readUInt32LE(10), dib = buf.readUInt32LE(14);
  const width = buf.readInt32LE(18), rawH = buf.readInt32LE(22), topDown = rawH < 0, height = Math.abs(rawH);
  const planes = buf.readUInt16LE(26), bpp = buf.readUInt16LE(28), comp = buf.readUInt32LE(30);
  if (planes !== 1 || comp !== 0 || (bpp !== 24 && bpp !== 32 && bpp !== 8)) throw new Error('unsupported BMP');
  let palette: number[] = [];
  if (bpp === 8) { const colors = (dataOff - 14 - dib) / 4; for (let i=0;i<colors;i++){const p=14+dib+i*4; palette.push(buf[p+2],buf[p+1],buf[p]);} }
  const rowSize = Math.floor((bpp * width + 31) / 32) * 4;
  const out = new Uint8ClampedArray(width*height*4);
  for (let y=0;y<height;y++) {
    const sy = topDown ? y : height-1-y; let p = dataOff + sy*rowSize;
    for (let x=0;x<width;x++) {
      let r=0,g=0,b=0,a=255;
      if (bpp===24) { b=buf[p++]; g=buf[p++]; r=buf[p++]; }
      else if (bpp===32) { b=buf[p++]; g=buf[p++]; r=buf[p++]; a=buf[p++]; }
      else { const idx=buf[p++]; r=palette[idx*3]??0; g=palette[idx*3+1]??0; b=palette[idx*3+2]??0; }
      const o=(y*width+x)*4; out[o]=r; out[o+1]=g; out[o+2]=b; out[o+3]=a;
    }
  }
  return {width,height,data:out};
}

function decodeImage(path: string): Image {
  if (/^https?:\/\//i.test(path)) throw new Error('Get "' + path + '": unsupported protocol scheme in cleanroom build');
  const buf = fs.readFileSync(path);
  if (buf.toString('hex',0,8) === '89504e470d0a1a0a') return readPng(buf);
  if (buf.toString('ascii',0,2) === 'BM') return readBmp(buf);
  throw new Error('image: unknown format');
}

function matte(img: Image, bg: RGB): Image {
  const d = new Uint8ClampedArray(img.width*img.height*4);
  for (let i=0;i<img.data.length;i+=4) {
    const a = img.data[i+3] / 255, ia = 1-a;
    d[i] = Math.floor(img.data[i]*a + bg[0]*ia);
    d[i+1] = Math.floor(img.data[i+1]*a + bg[1]*ia);
    d[i+2] = Math.floor(img.data[i+2]*a + bg[2]*ia);
    d[i+3] = 255;
  }
  return {width:img.width,height:img.height,data:d};
}

function resize(img: Image, w: number, h: number): Image {
  w = Math.max(1, Math.floor(w)); h = Math.max(1, Math.floor(h));
  const out = new Uint8ClampedArray(w*h*4);
  const sxr = img.width / w, syr = img.height / h;
  for (let y=0;y<h;y++) {
    const sy = (y + 0.5) * syr - 0.5; const y0 = Math.max(0, Math.floor(sy)); const y1 = Math.min(img.height-1, y0+1); const fy = Math.max(0, Math.min(1, sy-y0));
    for (let x=0;x<w;x++) {
      const sx = (x + 0.5) * sxr - 0.5; const x0 = Math.max(0, Math.floor(sx)); const x1 = Math.min(img.width-1, x0+1); const fx = Math.max(0, Math.min(1, sx-x0));
      const o=(y*w+x)*4;
      for (let c=0;c<4;c++) {
        const p00=img.data[(y0*img.width+x0)*4+c], p10=img.data[(y0*img.width+x1)*4+c], p01=img.data[(y1*img.width+x0)*4+c], p11=img.data[(y1*img.width+x1)*4+c];
        const v0=p00*(1-fx)+p10*fx, v1=p01*(1-fx)+p11*fx; out[o+c]=Math.round(v0*(1-fy)+v1*fy);
      }
    }
  }
  return {width:w,height:h,data:out};
}

function scaleTo(img: Image, tw: number, th: number, method: number): Image {
  if (method === 0) return resize(img, tw, th);
  const ar = img.width / img.height, tar = tw / th;
  let w=tw,h=th;
  if (method === 2) { if (ar > tar) h = Math.max(1, Math.round(tw / ar)); else w = Math.max(1, Math.round(th * ar)); }
  if (method === 1) { if (ar > tar) w = Math.max(1, Math.round(th * ar)); else h = Math.max(1, Math.round(tw / ar)); }
  const scaled = resize(img, w, h);
  if (method === 1 && (w !== tw || h !== th)) {
    const ox=Math.floor((w-tw)/2), oy=Math.floor((h-th)/2); const out=new Uint8ClampedArray(tw*th*4);
    for(let y=0;y<th;y++) for(let x=0;x<tw;x++) out.set(scaled.data.subarray(((y+oy)*w+x+ox)*4, ((y+oy)*w+x+ox)*4+4), (y*tw+x)*4);
    return {width:tw,height:th,data:out};
  }
  return scaled;
}

const esc = (kind: 38|48, r:number,g:number,b:number) => `\x1b[${kind};2;${r};${g};${b}m`;
function renderClassic(img: Image, cols: number, rows: number, method: number): string {
  const s = scaleTo(img, cols, rows*2, method); let out='';
  const pad = (method === 2) ? {x: Math.floor((cols-s.width)/2), y: Math.floor((rows*2-s.height)/2)} : {x:0,y:0};
  for (let cy=0; cy<rows; cy++) {
    for (let x=0; x<cols; x++) {
      const px=x-pad.x, y0=cy*2-pad.y, y1=y0+1;
      const top = px>=0&&px<s.width&&y0>=0&&y0<s.height ? (y0*s.width+px)*4 : -1;
      const bot = px>=0&&px<s.width&&y1>=0&&y1<s.height ? (y1*s.width+px)*4 : top;
      if (top < 0 && bot < 0) { out += ' '; continue; }
      const ti = top >= 0 ? top : bot, bi = bot >= 0 ? bot : ti;
      out += esc(48,s.data[ti],s.data[ti+1],s.data[ti+2]) + esc(38,s.data[bi],s.data[bi+1],s.data[bi+2]) + '▄';
    }
    out += '\x1b[0m\n';
  }
  return out;
}
function lum(d: Uint8ClampedArray, i:number): number { return 0.299*d[i] + 0.587*d[i+1] + 0.114*d[i+2]; }
function renderDither(img: Image, cols:number, rows:number, method:number, mode:number, matteColor:RGB, nobg:boolean): string {
  const s = scaleTo(img, cols, rows, method); const chars = mode===1 ? ['█','▓','▒','░',' '] : ['&','X','x',';',' ']; let out='';
  for (let y=0;y<s.height;y++) {
    for (let x=0;x<s.width;x++) { const i=(y*s.width+x)*4; const l=lum(s.data,i); const idx = l<51?4:l<102?3:l<153?2:l<204?1:0; if(!nobg) out += esc(48,matteColor[0],matteColor[1],matteColor[2]); out += esc(38,s.data[i],s.data[i+1],s.data[i+2]) + chars[idx]; }
    out += '\x1b[0m\n';
  }
  return out;
}
function goQuote(s: string): string { return s.replace(/\\/g,'\\\\').replace(/\x1b/g,'\\033').replace(/\n/g,'\\n').replace(/"/g,'\\"'); }

function main(): void {
  const args = process.argv.slice(2); let d=0, method=0, go=false, nobg=false, tc=80, tr=24, matteStr='000000'; const rest:string[]=[];
  for (let i=0;i<args.length;i++) {
    const a=args[i];
    if (a === '-help' || a === '--help' || a === '-h') { showHelp(); return; }
    else if (a === '-version') { console.log(VERSION); return; }
    else if (a === '-credits') { process.stdout.write(credits); return; }
    else if (a === '-go') go=true;
    else if (a === '-nobg') nobg=true;
    else if (a === '-d') d = Number(args[++i]);
    else if (a === '-s') method = Number(args[++i]);
    else if (a === '-tc') tc = Number(args[++i]);
    else if (a === '-tr') tr = Number(args[++i]);
    else if (a === '-m') matteStr = args[++i];
    else if (a.startsWith('-')) { showHelp(); return; }
    else rest.push(a);
  }
  if (rest.length !== 1 || ![0,1,2].includes(d) || ![0,1,2].includes(method) || !Number.isFinite(tc) || !Number.isFinite(tr) || tc < 2 || tr < 2) { showHelp(); return; }
  const mc = parseHex(matteStr); if (!mc) die(`matte color : ${matteStr} is not a hex-color`);
  let img: Image; try { img = matte(decodeImage(rest[0]), mc); } catch(e:any) { die(e.message || String(e)); return; }
  const rendered = d === 0 ? renderClassic(img, Math.floor(tc), Math.floor(tr), method) : renderDither(img, Math.floor(tc), Math.floor(tr), method, d, mc, nobg);
  if (go) { for (const line of rendered.split(/(?<=\n)/)) if (line.length) process.stdout.write(`fmt.Print("${goQuote(line)}")\n`); }
  else process.stdout.write(rendered);
}
main();
