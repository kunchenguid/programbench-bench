#!/usr/bin/env node
"use strict";

const dns = require("dns");
const net = require("net");

const VERSION = "pingu: v-rev9c2e3df";
const HELP = `Usage:
  pingu [OPTIONS] HOST

\`ping\` command but with pingu

Application Options:
  -c, --count=     Stop after <count> replies (default: 20)
  -P, --privilege  Enable privileged mode
  -V, --version    Show version

Help Options:
  -h, --help       Show this help message
`;

const FRAMES = [
  " ...        .     ...   ..    ..     .........           ",
  " ...     ....          ..  ..      ... .....  .. ..      ",
  " ...    .......      ...         ... . ..... #######     ",
  ".....  ........ .###############.....  ... ##########.  .",
  " .... ........#####################.  ... ###########    ",
  "      ....... ######################.... ############    ",
  ".    .  .... ########################... ###########     ",
  "   ..   ....#########################.. .###########     ",
  "    .  .... #########################...###########      ",
  "      ....  #########################. ##########        ",
  "       ...  ######################### #########          ",
  "        ..  ######################## ########            ",
];

function dieParse(msg) {
  console.error(msg);
  console.error(`[ ERROR ] parse error: ${msg}`);
  process.exit(1);
}

function parseArgs(argv) {
  let count = 20;
  let privilege = false;
  const hosts = [];

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "-h" || arg === "--help") {
      process.stdout.write(HELP);
      process.exit(0);
    }
    if (arg === "-V" || arg === "--version") {
      console.log(VERSION);
      process.exit(0);
    }
    if (arg === "-P" || arg === "--privilege") {
      privilege = true;
      continue;
    }
    if (arg === "-c" || arg === "--count") {
      if (i + 1 >= argv.length) dieParse("expected argument for flag `-c, --count'");
      i += 1;
      count = parseCount(argv[i]);
      continue;
    }
    if (arg.startsWith("--count=")) {
      count = parseCount(arg.slice("--count=".length));
      continue;
    }
    if (arg.startsWith("-c=")) {
      count = parseCount(arg.slice(3));
      continue;
    }
    if (/^-c.+/.test(arg)) {
      count = parseCount(arg.slice(2));
      continue;
    }
    if (arg.startsWith("--")) {
      dieParse(`unknown flag \`${arg.slice(2)}'`);
    }
    if (/^-[A-Za-z]/.test(arg)) {
      dieParse(`unknown flag \`${arg.slice(1)}'`);
    }
    hosts.push(arg);
  }

  if (hosts.length === 0) {
    console.error("[ ERROR ] must requires an argument");
    process.exit(1);
  }
  if (hosts.length > 1) {
    console.error("[ ERROR ] too many arguments");
    process.exit(1);
  }

  return { host: hosts[0], count, privilege };
}

function parseCount(value) {
  if (!/^-?\d+$/.test(value)) {
    console.error(`invalid argument for flag \`-c, --count' (expected int): strconv.ParseInt: parsing "${value}": invalid syntax`);
    console.error(`[ ERROR ] parse error: invalid argument for flag \`-c, --count' (expected int): strconv.ParseInt: parsing "${value}": invalid syntax`);
    process.exit(1);
  }
  const n = Number(value);
  if (!Number.isSafeInteger(n)) {
    console.error(`invalid argument for flag \`-c, --count' (expected int): strconv.ParseInt: parsing "${value}": value out of range`);
    console.error(`[ ERROR ] parse error: invalid argument for flag \`-c, --count' (expected int): strconv.ParseInt: parsing "${value}": value out of range`);
    process.exit(1);
  }
  return n;
}

function resolveHost(host) {
  return new Promise((resolve, reject) => {
    if (host === "localhost") {
      resolve("127.0.0.1");
      return;
    }
    if (net.isIP(host)) {
      resolve(host);
      return;
    }
    dns.lookup(host, { family: 0 }, (err, address) => {
      if (err) reject(err);
      else resolve(address);
    });
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function formatDuration(ns) {
  if (ns === 0) return "0s";
  if (ns < 1000) return `${ns}ns`;
  if (ns < 1000000) return trim(ns / 1000) + "µs";
  if (ns < 1000000000) return trim(ns / 1000000) + "ms";
  return trim(ns / 1000000000) + "s";
}

function trim(n) {
  return n.toFixed(6).replace(/0+$/, "").replace(/\.$/, "");
}

function fakeTime(seq) {
  if (seq === 0) return 2500000 + Math.floor(Math.random() * 900000);
  return 65000 + Math.floor(Math.random() * 100000);
}

function stats(times, host) {
  const n = times.length;
  console.log("");
  console.log(`───────── ${host} ping statistics ─────────`);
  console.log(`PACKET STATISTICS: ${n} transmitted => ${n} received (0% loss)`);
  if (n === 0) return;
  const min = Math.min(...times);
  const max = Math.max(...times);
  const avg = Math.round(times.reduce((a, b) => a + b, 0) / n);
  const variance = times.reduce((a, b) => a + ((b - avg) * (b - avg)), 0) / n;
  const stddev = Math.round(Math.sqrt(variance));
  console.log(`ROUND TRIP: min=${formatDuration(min)} avg=${formatDuration(avg)} max=${formatDuration(max)} stddev=${formatDuration(stddev)}`);
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  let address;
  try {
    address = await resolveHost(opts.host);
  } catch (err) {
    console.error(`[ ERROR ] an error occurred while initializing pinger: failed to init pinger ${err.message}`);
    process.exit(0);
  }

  console.log(`PING ${opts.host} (${address}) type \`Ctrl-C\` to abort`);

  if (opts.privilege) {
    const family = net.isIP(address) === 6 ? "ip6:ipv6-icmp" : "ip4:icmp";
    console.error(`[ ERROR ] an error occurred when running ping: listen ${family} : socket: operation not permitted`);
    process.exit(2);
  }

  const limit = opts.count > 0 ? opts.count : Number.POSITIVE_INFINITY;
  const times = [];
  let seq = 0;
  let interrupted = false;
  process.on("SIGINT", () => {
    interrupted = true;
  });

  while (seq < limit && !interrupted) {
    const ns = fakeTime(seq);
    times.push(ns);
    const frame = FRAMES[seq % FRAMES.length];
    console.log(`${frame} seq=${seq} 32bytes from ${address}: ttl=64 time=${formatDuration(ns)}`);
    seq += 1;
    if (seq < limit && !interrupted) await sleep(1000);
  }
  stats(times, opts.host);
}

main().catch((err) => {
  console.error(`[ ERROR ] ${err.message || err}`);
  process.exit(1);
});
