#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const http = require("http");
const https = require("https");
const { URL, pathToFileURL, fileURLToPath } = require("url");

const VERSION = "monolith 2.11.0";
const BANNER = ` _____    _____________   __________     ___________________    ___
|     \\  /             \\ |          |   |                   |  |   |
|      \\/       __      \\|    __    |   |    ___     ___    |__|   |
|              |  |          |  |   |   |   |   |   |   |          |
|   |\\    /|   |__|          |__|   |___|   |   |   |   |    __    |
|   | \\__/ |          |\\                    |   |   |   |   |  |   |
|___|      |__________| \\___________________|   |___|   |___|  |___|`;

const HELP = `${BANNER}

${VERSION}

CLI tool and library for saving web pages as a single HTML file

Usage: executable [OPTIONS] <TARGET>

Arguments:
  <TARGET>  URL or file path, use - for STDIN

Options:
  -a, --no-audio                      Remove audio sources
  -b, --base-url <http://localhost/>  Set custom base URL
  -B, --blacklist-domains             Treat specified domains as blacklist
  -c, --no-css                        Remove CSS
  -C, --cookie-file <cookies.txt>     Specify cookie file
  -d, --domain <example.com>          Specify domains to use for white/black-listing
  -e, --ignore-errors                 Ignore network errors
  -E, --encoding <UTF-8>              Enforce custom charset
  -f, --no-frames                     Remove frames and iframes
  -F, --no-fonts                      Remove fonts
  -i, --no-images                     Remove images
  -I, --isolate                       Cut off document from the Internet
  -j, --no-js                         Remove JavaScript
  -k, --insecure                      Allow invalid X.509 (TLS) certificates
  -m, --mhtml                         Use MHTML as output format
  -M, --no-metadata                   Exclude timestamp and source information
  -n, --unwrap-noscript               Replace NOSCRIPT elements with their contents
  -o, --output <result.html>          File to write to, use - for STDOUT
  -q, --quiet                         Suppress verbosity
  -t, --timeout <60>                  Adjust network request timeout
  -u, --user-agent <Firefox>          Set custom User-Agent string
  -v, --no-video                      Remove video sources
  -h, --help                          Print help
  -V, --version                       Print version`;

const MIME = {
  ".html": "text/html", ".htm": "text/html", ".css": "text/css",
  ".js": "text/javascript", ".mjs": "text/javascript",
  ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
  ".gif": "image/gif", ".svg": "image/svg+xml", ".webp": "image/webp",
  ".ico": "image/x-icon", ".bmp": "image/bmp",
  ".woff": "font/woff", ".woff2": "font/woff2", ".ttf": "font/ttf",
  ".otf": "font/otf", ".mp3": "audio/mpeg", ".wav": "audio/wav",
  ".ogg": "audio/ogg", ".mp4": "video/mp4", ".webm": "video/webm",
  ".pdf": "application/pdf"
};

function parseArgs(argv) {
  const opts = { domains: [] };
  const flags = {
    "-a": "noAudio", "--no-audio": "noAudio",
    "-B": "blacklist", "--blacklist-domains": "blacklist",
    "-c": "noCss", "--no-css": "noCss",
    "-e": "ignoreErrors", "--ignore-errors": "ignoreErrors",
    "-f": "noFrames", "--no-frames": "noFrames",
    "-F": "noFonts", "--no-fonts": "noFonts",
    "-i": "noImages", "--no-images": "noImages",
    "-I": "isolate", "--isolate": "isolate",
    "-j": "noJs", "--no-js": "noJs",
    "-k": "insecure", "--insecure": "insecure",
    "-m": "mhtml", "--mhtml": "mhtml",
    "-M": "noMetadata", "--no-metadata": "noMetadata",
    "-n": "unwrapNoscript", "--unwrap-noscript": "unwrapNoscript",
    "-q": "quiet", "--quiet": "quiet",
    "-h": "help", "--help": "help",
    "-V": "version", "--version": "version"
  };
  const values = {
    "-b": "baseUrl", "--base-url": "baseUrl",
    "-C": "cookieFile", "--cookie-file": "cookieFile",
    "-d": "domain", "--domain": "domain",
    "-E": "encoding", "--encoding": "encoding",
    "-o": "output", "--output": "output",
    "-t": "timeout", "--timeout": "timeout",
    "-u": "userAgent", "--user-agent": "userAgent"
  };
  const targets = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") {
      targets.push(...argv.slice(i + 1));
      break;
    } else if (flags[a]) {
      opts[flags[a]] = true;
    } else if (values[a]) {
      if (i + 1 >= argv.length) die(`error: a value is required for '${a}'\n`);
      const v = argv[++i];
      if (values[a] === "domain") opts.domains.push(v);
      else opts[values[a]] = v;
    } else if (a.startsWith("-")) {
      die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] <TARGET>\n\nFor more information, try '--help'.\n`);
    } else {
      targets.push(a);
    }
  }
  if (opts.help || opts.version) return opts;
  if (targets.length === 0) die("error: the following required arguments were not provided:\n  <TARGET>\n\nUsage: executable <TARGET>\n\nFor more information, try '--help'.\n");
  opts.target = targets[0];
  return opts;
}

function die(msg, code = 2) {
  process.stderr.write(msg);
  process.exit(code);
}

function log(opts, msg) {
  if (!opts.quiet) process.stderr.write(msg + "\n");
}

function isUrl(s) {
  return /^https?:\/\//i.test(s) || /^file:\/\//i.test(s);
}

function mimeFor(name) {
  return MIME[path.extname((name || "").split("?")[0]).toLowerCase()] || "application/octet-stream";
}

function dataUrl(buf, mime) {
  return `data:${mime};base64,${Buffer.from(buf).toString("base64")}`;
}

function attr(tag, name) {
  const re = new RegExp(`\\s${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s"'=<>` + "`" + `]+))`, "i");
  const m = tag.match(re);
  return m ? (m[1] ?? m[2] ?? m[3] ?? "") : null;
}

function setAttr(tag, name, value) {
  const re = new RegExp(`(\\s${name}\\s*=\\s*)(?:"[^"]*"|'[^']*'|[^\\s"'=<>` + "`" + `]+)`, "i");
  if (re.test(tag)) return tag.replace(re, `$1"${value}"`);
  return tag.replace(/\/?>$/, ` ${name}="${value}"$&`);
}

function removeAttr(tag, name) {
  const re = new RegExp(`\\s${name}\\s*=\\s*(?:"[^"]*"|'[^']*'|[^\\s"'=<>` + "`" + `]+)`, "ig");
  return tag.replace(re, "");
}

async function fetchHttp(url, opts) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const mod = u.protocol === "https:" ? https : http;
    const req = mod.get(u, {
      timeout: Number(opts.timeout || 60) * 1000,
      rejectUnauthorized: !opts.insecure,
      headers: { "User-Agent": opts.userAgent || "Mozilla/5.0" }
    }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        res.resume();
        resolve(fetchHttp(new URL(res.headers.location, u).href, opts));
        return;
      }
      const chunks = [];
      res.on("data", c => chunks.push(c));
      res.on("end", () => resolve({ buf: Buffer.concat(chunks), finalUrl: url, mime: (res.headers["content-type"] || "").split(";")[0] }));
    });
    req.on("timeout", () => req.destroy(new Error("operation timed out")));
    req.on("error", reject);
  });
}

async function readResource(ref, base, opts) {
  if (!ref || /^data:/i.test(ref) || /^mailto:/i.test(ref) || /^javascript:/i.test(ref) || ref.startsWith("#")) return null;
  let resolved;
  try {
    if (base) resolved = new URL(ref, base).href;
    else resolved = pathToFileURL(path.resolve(ref)).href;
  } catch {
    resolved = ref;
  }
  try {
    if (/^https?:\/\//i.test(resolved)) {
      log(opts, resolved);
      const r = await fetchHttp(resolved, opts);
      return { ...r, url: resolved, mime: r.mime || mimeFor(resolved) };
    }
    const p = resolved.startsWith("file:") ? fileURLToPath(resolved) : path.resolve(ref);
    const buf = fs.readFileSync(p);
    log(opts, pathToFileURL(p).href);
    return { buf, url: pathToFileURL(p).href, mime: mimeFor(p) };
  } catch (e) {
    log(opts, `${resolved} (${e.code === "ENOENT" ? "file not found" : e.message})`);
    if (opts.ignoreErrors) return null;
    return null;
  }
}

async function transformCss(css, base, opts) {
  if (opts.noFonts) css = css.replace(/@font-face\s*{[\s\S]*?}/gi, "");
  const parts = [];
  let last = 0;
  const re = /url\(\s*(["']?)(.*?)\1\s*\)/ig;
  for (let m; (m = re.exec(css));) {
    parts.push(css.slice(last, m.index));
    const url = m[2];
    if (opts.noImages && /\.(png|jpe?g|gif|svg|webp|bmp|ico)(\?|$)/i.test(url)) {
      parts.push("url(\"\")");
    } else if (opts.noFonts && /\.(woff2?|ttf|otf|eot)(\?|$)/i.test(url)) {
      parts.push("url(\"\")");
    } else {
      const r = await readResource(url, base, opts);
      parts.push(r ? `url("${dataUrl(r.buf, r.mime)}")` : `url("${url}")`);
    }
    last = re.lastIndex;
  }
  parts.push(css.slice(last));
  return parts.join("");
}

function ensureDocument(html) {
  if (!/<html[\s>]/i.test(html)) html = `<html><head></head><body>${html}</body></html>`;
  if (!/<head[\s>]/i.test(html)) html = html.replace(/<html[^>]*>/i, "$&<head></head>");
  if (!/<body[\s>]/i.test(html)) html = html.replace(/<\/head>/i, "$&<body>") + "</body>";
  return html;
}

function insertHead(html, text) {
  if (/<head[^>]*>/i.test(html)) return html.replace(/<head[^>]*>/i, m => m + text);
  return `<head>${text}</head>` + html;
}

function appendHead(html, text) {
  if (/<\/head>/i.test(html)) return html.replace(/<\/head>/i, text + "</head>");
  return insertHead(html, text);
}

async function transformHtml(input, base, opts, nested = false) {
  let html = ensureDocument(String(input));

  if (opts.unwrapNoscript) {
    html = html.replace(/<noscript\b[^>]*>([\s\S]*?)<\/noscript>/gi, "<!--noscript-->$1<!--/noscript-->");
  }

  html = await replaceAsync(html, /<link\b[^>]*>/gi, async (tag) => {
    const rel = attr(tag, "rel") || "";
    const href = attr(tag, "href");
    if (!/\bstylesheet\b/i.test(rel) || !href) return tag;
    if (opts.noCss) return removeAttr(tag, "href");
    const r = await readResource(href, base, opts);
    if (!r) return tag;
    const css = await transformCss(r.buf.toString("utf8"), r.url, opts);
    return setAttr(tag, "href", dataUrl(Buffer.from(css), "text/css"));
  });

  html = await replaceAsync(html, /<style\b([^>]*)>([\s\S]*?)<\/style>/gi, async (all, attrs, css) => {
    if (opts.noCss) return `<style${attrs}></style>`;
    return `<style${attrs}>${await transformCss(css, base, opts)}</style>`;
  });

  html = await replaceAsync(html, /<script\b[^>]*>[\s\S]*?<\/script>/gi, async (all) => {
    const open = all.match(/^<script\b[^>]*>/i)[0];
    const src = attr(open, "src");
    if (opts.noJs) return removeAttr(open, "src") + "</script>";
    if (!src) return all;
    const r = await readResource(src, base, opts);
    return removeAttr(open, "src") + (r ? r.buf.toString("utf8") : "") + "</script>";
  });

  html = await replaceAsync(html, /<(img|image)\b[^>]*>/gi, async (tag, name) => {
    const src = attr(tag, "src") || attr(tag, "href") || attr(tag, "xlink:href");
    if (!src) return tag;
    const an = attr(tag, "src") != null ? "src" : (attr(tag, "href") != null ? "href" : "xlink:href");
    if (opts.noImages) return setAttr(tag, an, "");
    const r = await readResource(src, base, opts);
    return r ? setAttr(tag, an, dataUrl(r.buf, r.mime)) : tag;
  });

  html = await replaceAsync(html, /<(audio|video|source)\b[^>]*>/gi, async (tag, name) => {
    const src = attr(tag, "src");
    if (!src) return tag;
    if ((name.toLowerCase() === "audio" && opts.noAudio) || (name.toLowerCase() === "video" && opts.noVideo)) {
      return removeAttr(tag, "src");
    }
    const r = await readResource(src, base, opts);
    return r ? setAttr(tag, "src", dataUrl(r.buf, r.mime)) : removeAttr(tag, "src");
  });

  html = await replaceAsync(html, /<iframe\b[^>]*>/gi, async (tag) => {
    const src = attr(tag, "src");
    if (!src) return tag;
    if (opts.noFrames) return setAttr(tag, "src", "");
    const r = await readResource(src, base, opts);
    if (!r) return tag;
    const inner = await transformHtml(r.buf.toString("utf8"), r.url, { ...opts, noMetadata: true }, true);
    return setAttr(tag, "src", dataUrl(Buffer.from(inner), "text/html"));
  });

  const csp = cspContent(opts);
  if (csp && !nested) html = insertHead(html, `<meta http-equiv="Content-Security-Policy" content="${escapeAttr(csp)}"></meta>`);
  if (opts.baseUrl && opts.target === "-" && !nested) html = appendHead(html, `<base href="${escapeAttr(opts.baseUrl)}"></base>`);
  if (!nested) html = appendHead(html, `<meta name="robots" content="none"></meta>`);
  if (opts.encoding && !nested) html = appendHead(html, `<meta charset="${escapeAttr(opts.encoding)}"></meta>`);
  if (!opts.noMetadata && !nested) {
    const source = opts.target === "-" || (base && base.startsWith("file:")) ? "local source" : (base || opts.target);
    const stamp = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
    html = `<!-- Saved from ${source} at ${stamp} using monolith v2.11.0 -->\n` + html;
  }
  return html;
}

function cspContent(opts) {
  const bits = [];
  if (opts.isolate) bits.push("default-src 'unsafe-eval' 'unsafe-inline' data:;");
  if (opts.noCss) bits.push("style-src 'none';");
  if (opts.noJs) bits.push("script-src 'none';");
  if (opts.noFrames) bits.push("frame-src 'none'; child-src 'none';");
  if (opts.noImages) bits.push("img-src data:;");
  return bits.join(" ");
}

function escapeAttr(s) {
  return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
}

async function replaceAsync(str, re, fn) {
  const out = [];
  let last = 0;
  for (let m; (m = re.exec(str));) {
    out.push(str.slice(last, m.index));
    out.push(await fn(...m));
    last = re.lastIndex;
  }
  out.push(str.slice(last));
  return out.join("");
}

function titleOf(html) {
  const m = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return m ? m[1].replace(/<[^>]+>/g, "").trim() : "page";
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) { console.log(HELP); return; }
  if (opts.version) { console.log(VERSION); return; }

  let buf, base;
  if (opts.target === "-") {
    buf = fs.readFileSync(0);
    base = opts.baseUrl || null;
  } else if (/^https?:\/\//i.test(opts.target)) {
    const r = await fetchHttp(opts.target, opts);
    buf = r.buf;
    base = r.finalUrl;
    log(opts, base);
  } else if (/^file:\/\//i.test(opts.target)) {
    base = opts.target;
    log(opts, base);
    buf = fs.readFileSync(fileURLToPath(opts.target));
  } else {
    const p = path.resolve(opts.target);
    base = pathToFileURL(p).href;
    log(opts, base);
    buf = fs.readFileSync(p);
  }

  if (opts.mhtml) opts.noJs = true;
  let result = await transformHtml(buf.toString("utf8"), base, opts);
  if (opts.mhtml) {
    result = `MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary="----=_NextPart_000_0000"\r\n\r\n------=_NextPart_000_0000\r\nContent-Type: text/html; charset="utf-8"\r\nContent-Location: http://example.com/\r\n\r\n${result}\r\n------=_NextPart_000_0000--\r\n`;
  }

  let output = opts.output;
  if (output && output !== "-") {
    const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
    output = output.replace(/%title%/g, titleOf(result)).replace(/%timestamp%/g, stamp);
    fs.writeFileSync(output, result);
  } else {
    process.stdout.write(result);
    if (!result.endsWith("\n")) process.stdout.write("\n");
  }
}

main().catch(e => {
  process.stderr.write(`Error: ${e.message}\n`);
  process.exit(1);
});
