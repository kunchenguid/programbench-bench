#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const VERSION = 'DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8';
const PLUGIN = 'Failed to open plugins.json file. PLUGIN_PATH: /home/agent/.DataSurgeon/plugins.json';

const HELP = `Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.

Usage: executable [OPTIONS]

Options:
  -f, --file <file>            File to extract information from [default: ""]
      --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --update <update>        Updates a plugin from a GitHub repository. You can also use \`ds --update all\` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: ""]
      --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --list                   List all added plugins
  -C, --clean                  Only displays the matched result, rather than the entire line
      --directory <directory>  Process all files found in the specified directory [default: ""]
      --ignore                 Silences error messages
  -l, --line                   Displays the line number where the match occurred
  -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line
  -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)
  -S, --suppress               Suppress the 'Reading standard input' message when not providing a file
      --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop "^.{1,10}$" will hide all matches not under 10 characters) [default: ""]
      --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: ""]
  -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.
  -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: ""]
  -t, --time                   Time how long the operation took
  -e, --email                  Extract email addresses
  -p, --phone                  Extracts phone numbers
  -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)
  -i, --ip-addr                Extract IP addresses
  -6, --ipv6-addr              Extract IPv6 addresses
  -m, --mac-addr               Extract MAC addresses
  -c, --credit-card            Extract credit card numbers
  -u, --url                    Extract urls
  -F, --files                  Extract filenames
  -b, --bitcoin                Extract bitcoin wallets
  -a, --aws                    Extract AWS keys
  -g, --google                 Extract Google service account private key ids (used for google automations services)
  -d, --dns                    Extract Domain Name System records
  -s, --social                 Extract social security numbers
  -h, --help                   Print help
  -V, --version                Print version`;

function defaults() {
  return {
    file: '', directory: '', output: '', add: '', update: '', remove: '',
    clean: false, ignore: false, line: false, thorough: false, display: false,
    suppress: false, drop: '', filter: '', hide: false, time: false,
    list: false, help: false, version: false,
    types: new Set(),
  };
}

const shortMap = {
  C: 'clean', l: 'line', T: 'thorough', D: 'display', S: 'suppress', X: 'hide',
  t: 'time', e: 'email', p: 'phone', H: 'hash', i: 'ip', '6': 'ipv6',
  m: 'mac', c: 'cc', u: 'url', F: 'files', b: 'bitcoin', a: 'aws',
  g: 'google', d: 'dns', s: 'social', h: 'help', V: 'version',
};
const longTypes = {
  email: 'email', phone: 'phone', hash: 'hash', 'ip-addr': 'ip',
  'ipv6-addr': 'ipv6', 'mac-addr': 'mac', 'credit-card': 'cc',
  url: 'url', files: 'files', bitcoin: 'bitcoin', aws: 'aws',
  google: 'google', dns: 'dns', social: 'social',
};
const longBools = {
  clean: 'clean', ignore: 'ignore', line: 'line', thorough: 'thorough',
  display: 'display', suppress: 'suppress', hide: 'hide', time: 'time',
  list: 'list', help: 'help', version: 'version',
};
const valueLong = new Set(['file', 'directory', 'drop', 'filter', 'output', 'add', 'update', 'remove']);

function parse(argv) {
  const o = defaults();
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a.startsWith('--')) {
      let name = a.slice(2), val = null;
      const eq = name.indexOf('=');
      if (eq >= 0) {
        val = name.slice(eq + 1);
        name = name.slice(0, eq);
      }
      if (valueLong.has(name)) {
        if (val === null) val = argv[++i] || '';
        o[name === 'output' ? 'output' : name] = val;
      } else if (longTypes[name]) {
        o.types.add(longTypes[name]);
      } else if (longBools[name]) {
        o[longBools[name]] = true;
      }
      continue;
    }
    if (a.startsWith('-') && a.length > 1) {
      const flags = a.slice(1);
      if (flags[0] === 'f' && flags.length === 1) o.file = argv[++i] || '';
      else if (flags[0] === 'o' && flags.length === 1) o.output = argv[++i] || '';
      else {
        for (const ch of flags) {
          const k = shortMap[ch];
          if (!k) continue;
          if (['email','phone','hash','ip','ipv6','mac','cc','url','files','bitcoin','aws','google','dns','social'].includes(k)) o.types.add(k);
          else o[k] = true;
        }
      }
    }
  }
  return o;
}

const extractors = [
  ['hash', 'hashes', /(?:\$2[aby]\$[./A-Za-z0-9]{56}|[A-Fa-f0-9]{128}|[A-Fa-f0-9]{96}|[A-Fa-f0-9]{64}|[A-Fa-f0-9]{56}|[A-Fa-f0-9]{40}|[A-Fa-f0-9]{32})/g],
  ['email', 'email', /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g],
  ['cc', 'credit_card', /(?:\b\d{4}[- ]?){3}\d{4}\b|\b\d{13,19}\b/g],
  ['files', 'files', /(?:[A-Za-z0-9_ .\/\\-]+)\.(?:txt|csv|json|xml|ya?ml|html?|css|js|ts|jsx|tsx|py|rb|php|java|c|cpp|h|hpp|rs|go|sh|bat|ps1|md|pdf|docx?|xlsx?|pptx?|png|jpe?g|gif|svg|zip|tar|gz|7z|rar|exe|dll|so|log|conf|ini|sql)\b/gi],
  ['ip', 'ip_address', /\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g],
  ['url', 'url', /\b(?:https?|ftp):\/\/[^\s<>"']+/gi],
  ['mac', 'mac_address', /\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b/g],
  ['ipv6', 'ipv6_address', /\b(?:[A-Fa-f0-9]{1,4}:){2,7}[A-Fa-f0-9]{0,4}\b/g],
  ['bitcoin', 'bitcoin_wallet', /\b(?:[13][a-km-zA-HJ-NP-Z1-9]{25,34}|bc1[ac-hj-np-z02-9]{11,71})\b/g],
  ['aws', 'aws_key', /\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/g],
  ['google', 'google_api', /\b[A-Fa-f0-9]{40}\b/g],
  ['dns', 'dns', /\b(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}\b/g],
  ['social', 'social_security', /\b\d{3}-\d{2}-\d{4}\b/g],
  ['phone', 'phone', /\b(?:\+?1[-. ]?)?(?:\(?[2-9]\d{2}\)?[-. ]*)[2-9]\d{2}[-. ]*\d{4}\b/g],
];

function chosenExtractors(opts) {
  if (opts.types.size === 0) return extractors;
  return extractors.filter(([key]) => opts.types.has(key));
}

function readInputs(opts) {
  if (opts.directory) {
    const files = [];
    function walk(dir) {
      let entries;
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
      catch (e) { if (!opts.ignore) console.error(`[-] Failed to read directory: ${dir}`); return; }
      entries.sort((a, b) => a.name.localeCompare(b.name));
      for (const ent of entries) {
        const p = path.join(dir, ent.name);
        if (ent.isDirectory()) walk(p);
        else if (ent.isFile()) files.push(p);
      }
    }
    walk(opts.directory);
    return files.map(file => {
      try { return { file, text: fs.readFileSync(file, 'utf8') }; }
      catch (e) { if (!opts.ignore) console.error(`[-] Failed to read file: ${file}`); return null; }
    }).filter(Boolean);
  }
  if (opts.file) {
    if (!fs.existsSync(opts.file)) {
      if (!opts.ignore) console.error(`[-] File not found: ${opts.file}`);
      return [];
    }
    return [{ file: opts.file, text: fs.readFileSync(opts.file, 'utf8') }];
  }
  if (!opts.suppress) console.error("[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)");
  return [{ file: '', text: fs.readFileSync(0, 'utf8') }];
}

function reset(re) { re.lastIndex = 0; return re; }

function collect(opts) {
  let filterRe = null, dropRe = null;
  try { if (opts.filter) filterRe = new RegExp(opts.filter); } catch {}
  try { if (opts.drop) dropRe = new RegExp(opts.drop); } catch {}
  const rows = [];
  const exts = chosenExtractors(opts);
  for (const input of readInputs(opts)) {
    const lines = input.text.split(/\r?\n/);
    for (let idx = 0; idx < lines.length; idx++) {
      const line = lines[idx];
      if (line === '' && idx === lines.length - 1) continue;
      let emittedForLine = false;
      for (const [key, label, re] of exts) {
        if (!opts.thorough && emittedForLine) break;
        const matches = Array.from(line.matchAll(reset(re))).map(m => m[0]);
        if (!matches.length) continue;
        const selected = opts.thorough ? matches : [matches[0]];
        for (let match of selected) {
          if (key === 'files') match = match.replace(/^[\\/]+/, '');
          const data = opts.clean ? match : line;
          if (filterRe && !filterRe.test(data)) continue;
          if (dropRe && dropRe.test(data)) continue;
          rows.push({ label, data, file: input.file, line: idx + 1 });
          emittedForLine = true;
          if (!opts.thorough) break;
        }
      }
    }
  }
  return rows;
}

function formatRows(rows, opts) {
  if (opts.output) {
    const header = opts.line ? 'content_type, line, data' : 'content_type, data';
    const body = rows.map(r => opts.line ? `${r.label}, ${r.line}, ${r.data}` : `${r.label}, ${r.data}`);
    return [header, ...body].join('\n') + '\n';
  }
  return rows.map(r => {
    const bits = [];
    if (!opts.hide) bits.push(r.label);
    if (opts.display && r.file) bits.push(`file: ${r.file}`);
    let prefix = '';
    if (bits.length === 1 && !opts.display) prefix = `${bits[0]}: `;
    else if (bits.length) prefix = `${bits.join(', ')} `;
    let s = `${prefix}${r.data}`;
    if (opts.line) s += `, line: ${r.line}`;
    return s;
  }).join('\n') + (rows.length ? '\n' : '');
}

function main() {
  const start = Date.now();
  const opts = parse(process.argv.slice(2));
  console.error(PLUGIN);
  if (opts.help) { console.log(HELP); return; }
  if (opts.version) { console.log(VERSION); return; }
  if (opts.list) {
    console.error(PLUGIN);
    console.log('No plugins found. Plugin File: /home/agent/.DataSurgeon/plugins.json');
    return;
  }
  if (opts.add || opts.update || opts.remove) return;
  const rows = collect(opts);
  const output = formatRows(rows, opts);
  if (opts.output) fs.writeFileSync(opts.output, output);
  else process.stdout.write(output);
  if (opts.time) console.log(`Operation completed in ${((Date.now() - start) / 1000).toFixed(2)}s`);
}

main();
