#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const VERSION = '0.41.0';
const DRAFTS = new Set(['4', '6', '7', '2019', '2020']);
const OUTPUTS = new Set(['text', 'flag', 'list', 'hierarchical']);

function usage(full = false, pattern) {
  if (full) {
    return `Usage: executable [OPTIONS] [SCHEMA]

Arguments:
  [SCHEMA]  The JSON Schema to validate with (i.e. schema.json)

Options:
  -i, --instance <INSTANCES>       A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)
  -d, --draft <DRAFT>              Enforce a specific JSON Schema draft [possible values: 4, 6, 7, 2019, 2020]
      --assert-format              Turn ON format validation
      --no-assert-format           Turn OFF format validation
      --output <OUTPUT>            Select output style: text (default), flag, list, hierarchical [default: text] [possible values: text, flag, list, hierarchical]
  -v, --version                    Show program's version number and exit
      --errors-only                Only show validation errors
      --connect-timeout <SECONDS>  Timeout for establishing connections (in seconds)
      --timeout <SECONDS>          Total timeout for HTTP requests (in seconds)
  -k, --insecure                   Skip TLS certificate verification (dangerous!)
      --cacert <FILE>              Path to a custom CA certificate file (PEM format)
  -h, --help                       Print help`;
  }
  return `Usage: executable ${pattern || '[OPTIONS] [SCHEMA]'}\n\nFor more information, try '--help'.`;
}

function die(msg, code = 1) {
  console.error(msg);
  process.exit(code);
}

function parseArgs(argv) {
  const opts = { instances: [], output: 'text', assertFormat: false, errorsOnly: false };
  let positional = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const need = (name) => {
      if (i + 1 >= argv.length) die(`error: a value is required for '${name}' but none was supplied\n\n${usage(false)}`, 2);
      return argv[++i];
    };
    if (a === '-h' || a === '--help') { console.log(usage(true)); process.exit(0); }
    else if (a === '-v' || a === '--version') { console.log(`Version: ${VERSION}`); process.exit(0); }
    else if (a === '-i' || a === '--instance') opts.instances.push(need(a));
    else if (a.startsWith('--instance=')) opts.instances.push(a.slice(11));
    else if (a === '-d' || a === '--draft') {
      const v = need(a);
      if (!DRAFTS.has(v)) die(`error: invalid value '${v}' for '--draft <DRAFT>'\n  [possible values: 4, 6, 7, 2019, 2020]\n\nFor more information, try '--help'.`, 2);
      opts.draft = v;
    } else if (a.startsWith('--draft=')) {
      const v = a.slice(8);
      if (!DRAFTS.has(v)) die(`error: invalid value '${v}' for '--draft <DRAFT>'\n  [possible values: 4, 6, 7, 2019, 2020]\n\nFor more information, try '--help'.`, 2);
      opts.draft = v;
    } else if (a === '--assert-format') opts.assertFormat = true;
    else if (a === '--no-assert-format') opts.assertFormat = false;
    else if (a === '--errors-only') opts.errorsOnly = true;
    else if (a === '--output') {
      const v = need(a);
      if (!OUTPUTS.has(v)) die(`error: invalid value '${v}' for '--output <OUTPUT>'\n  [possible values: text, flag, list, hierarchical]\n\nFor more information, try '--help'.`, 2);
      opts.output = v;
    } else if (a.startsWith('--output=')) {
      const v = a.slice(9);
      if (!OUTPUTS.has(v)) die(`error: invalid value '${v}' for '--output <OUTPUT>'\n  [possible values: text, flag, list, hierarchical]\n\nFor more information, try '--help'.`, 2);
      opts.output = v;
    } else if (a === '--connect-timeout' || a === '--timeout' || a === '--cacert') { need(a); }
    else if (a === '-k' || a === '--insecure') {}
    else if (a.startsWith('-')) die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\n${usage(false)}`, 2);
    else positional.push(a);
  }
  if (positional.length === 0) {
    const pat = opts.instances.length ? '--instance <INSTANCES> <SCHEMA>' : '<SCHEMA>';
    die(`error: the following required arguments were not provided:\n  <SCHEMA>\n\n${usage(false, pat)}`, 2);
  }
  opts.schemaPath = positional[0];
  return opts;
}

function readJson(file) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); }
  catch (e) { die(`Error: ${e.code === 'ENOENT' ? 'No such file or directory (os error 2)' : e.message}`); }
  try { return JSON.parse(text); }
  catch (e) { die(`Error: ${jsonParseMessage(text, e)}`); }
}

function jsonParseMessage(text, e) {
  const m = /position (\d+)/.exec(e.message);
  let pos;
  if (!m) {
    if (/Unexpected end/.test(e.message)) pos = text.length;
    else return e.message;
  } else {
    pos = Number(m[1]);
  }
  let line = 1, col = 0;
  for (let i = 0; i < Math.min(pos, text.length); i++) {
    if (text[i] === '\n') { line++; col = 0; } else col++;
  }
  if (/Unexpected end/.test(e.message)) return `EOF while parsing a value at line ${line} column ${col}`;
  return `${e.message} at line ${line} column ${col}`;
}

function selectedDraft(opts, schema) {
  if (opts.draft) return opts.draft;
  const uri = schema && typeof schema.$schema === 'string' ? schema.$schema : '';
  if (/draft-?04|draft\/4/.test(uri)) return '4';
  if (/draft-?06|draft\/6/.test(uri)) return '6';
  if (/draft-?07|draft\/7/.test(uri)) return '7';
  if (/2019/.test(uri)) return '2019';
  return '2020';
}

function makeAjv(opts, schema) {
  let Ajv;
  const draft = selectedDraft(opts, schema);
  if (draft === '2019') Ajv = require('ajv/dist/2019');
  else if (draft === '2020') Ajv = require('ajv/dist/2020');
  else Ajv = require('ajv');
  const ajv = new Ajv({ allErrors: true, strict: false, validateSchema: true, verbose: true, messages: true, validateFormats: !!opts.assertFormat, logger: false });
  if (opts.assertFormat) require('ajv-formats')(ajv);
  return ajv;
}

function jsonPointerGet(root, pointer) {
  if (!pointer) return root;
  let cur = root;
  for (const raw of pointer.split('/').slice(1)) {
    const key = raw.replace(/~1/g, '/').replace(/~0/g, '~');
    if (cur == null) return undefined;
    cur = cur[key];
  }
  return cur;
}

function show(v) {
  if (typeof v === 'string') return JSON.stringify(v);
  return JSON.stringify(v);
}

function joinValues(vals) {
  const s = vals.map(show);
  if (s.length === 1) return s[0];
  if (s.length === 2) return `${s[0]} or ${s[1]}`;
  return `${s.slice(0, -1).join(', ')}, or ${s[s.length - 1]}`;
}

function typeName(t) {
  if (Array.isArray(t)) return t.map(typeName).join(' or ');
  return t;
}

function friendlyError(err, instance) {
  const val = jsonPointerGet(instance, err.instancePath || '');
  const p = err.params || {};
  switch (err.keyword) {
    case 'required': return `${JSON.stringify(p.missingProperty)} is a required property`;
    case 'additionalProperties': return `Additional properties are not allowed ('${p.additionalProperty}' was unexpected)`;
    case 'type': return `${show(val)} is not of type ${JSON.stringify(typeName(p.type))}`;
    case 'minimum': return `${show(val)} is less than the minimum of ${p.limit}`;
    case 'maximum': return `${show(val)} is greater than the maximum of ${p.limit}`;
    case 'exclusiveMinimum': return `${show(val)} is less than or equal to the minimum of ${p.limit}`;
    case 'exclusiveMaximum': return `${show(val)} is greater than or equal to the maximum of ${p.limit}`;
    case 'multipleOf': return `${show(val)} is not a multiple of ${p.multipleOf}`;
    case 'minLength': return `${show(val)} is shorter than ${p.limit} characters`;
    case 'maxLength': return `${show(val)} is longer than ${p.limit} characters`;
    case 'pattern': return `${show(val)} does not match ${JSON.stringify(p.pattern)}`;
    case 'minItems': return `${show(val)} has less than ${p.limit} items`;
    case 'maxItems': return `${show(val)} has more than ${p.limit} item${p.limit === 1 ? '' : 's'}`;
    case 'uniqueItems': return `${show(val)} has non-unique elements`;
    case 'const': return `${show(err.schema)} was expected`;
    case 'enum': return `${show(val)} is not one of ${joinValues(err.schema || p.allowedValues || [])}`;
    case 'format': return `${show(val)} is not a ${JSON.stringify(p.format)}`;
    case 'anyOf': return `${show(val)} is not valid under any of the schemas listed in the 'anyOf' keyword`;
    case 'oneOf': return `${show(val)} is valid under more than one of the schemas listed in the 'oneOf' keyword`;
    case 'not': return `${show(val)} is not allowed`;
    default: return err.message || `${show(val)} is invalid`;
  }
}

function schemaUrl(schemaPath, schemaPathPtr) {
  const abs = path.resolve(schemaPath);
  const fileUrl = 'file://' + abs.split(path.sep).map((p, i) => i === 0 ? p : encodeURIComponent(p)).join('/');
  const ptr = schemaPathPtr && schemaPathPtr.startsWith('#') ? schemaPathPtr.slice(1) : (schemaPathPtr || '');
  return fileUrl + '#' + ptr;
}

function detailFromError(err, instance, schemaPath) {
  const ep = (err.schemaPath || '#').replace(/^#/, '') || '';
  const item = {
    evaluationPath: ep,
    instanceLocation: err.instancePath || '',
    schemaLocation: schemaUrl(schemaPath, ep),
    valid: false
  };
  item.errors = { [err.keyword || 'validation']: friendlyError(err, instance) };
  return item;
}

function structured(output, schemaPath, instancePath, valid, errors, instance) {
  const payload = valid
    ? { details: [{ evaluationPath: '', instanceLocation: '', schemaLocation: schemaUrl(schemaPath, ''), valid: true }], valid: true }
    : { details: [{ evaluationPath: '', instanceLocation: '', schemaLocation: schemaUrl(schemaPath, ''), valid: false }].concat((errors || []).map(e => detailFromError(e, instance, schemaPath))), valid: false };
  const obj = { output, payload, schema: schemaPath };
  if (instancePath) obj.instance = instancePath;
  return JSON.stringify(obj);
}

function sortedErrors(errors) {
  return (errors || []).slice().sort((a, b) => {
    const rank = (e) => e.keyword === 'required' ? 0 : (e.keyword === 'additionalProperties' ? 2 : 1);
    const ra = rank(a), rb = rank(b);
    if (ra !== rb) return ra - rb;
    const pa = a.instancePath || '';
    const pb = b.instancePath || '';
    if (pa !== pb) return pa < pb ? -1 : 1;
    const sa = a.schemaPath || '';
    const sb = b.schemaPath || '';
    return sa < sb ? -1 : (sa > sb ? 1 : 0);
  });
}

function schemaForAjv(schema, opts) {
  const draft = selectedDraft(opts, schema);
  if ((draft === '4' || draft === '6') && schema && typeof schema === 'object' && typeof schema.$schema === 'string') {
    const copy = Array.isArray(schema) ? schema.slice() : { ...schema };
    delete copy.$schema;
    return copy;
  }
  return schema;
}

function validateSchemaItself(ajv, schema, opts) {
  const ajvSchema = schemaForAjv(schema, opts);
  let valid;
  try { valid = ajv.validateSchema(ajvSchema); }
  catch (e) { die(`Schema is invalid. Error: ${e.message}`); }
  if (!valid) {
    const errors = ajv.errors || [];
    const chosen = errors.find(e => e.keyword === 'anyOf') || errors[0];
    const msg = friendlyError(chosen, schema);
    if (opts.output === 'text') console.log(`Schema is invalid. Error: ${msg}`);
    else console.log(JSON.stringify({ output: opts.output, payload: { valid: false }, schema: opts.schemaPath }));
    process.exit(1);
  }
  if (opts.instances.length) return;
  if (opts.output === 'text') {
    if (!opts.errorsOnly) console.log('Schema is valid');
  } else if (opts.output === 'flag') {
    console.log(JSON.stringify({ output: 'flag', payload: { valid: true }, schema: opts.schemaPath }));
  } else {
    console.log(structured(opts.output, opts.schemaPath, null, true, [], schema));
  }
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const schema = readJson(opts.schemaPath);
  const ajv = makeAjv(opts, schema);
  validateSchemaItself(ajv, schema, opts);
  if (!opts.instances.length) return;
  let validate;
  try { validate = ajv.compile(schemaForAjv(schema, opts)); }
  catch (e) { die(`Schema is invalid. Error: ${e.message}`); }
  let exitCode = 0;
  for (const instPath of opts.instances) {
    const instance = readJson(instPath);
    const valid = !!validate(instance);
    const errors = sortedErrors(validate.errors || []);
    if (!valid) exitCode = 1;
    if (opts.output === 'text') {
      if (valid) {
        if (!opts.errorsOnly) console.log(`${instPath} - VALID`);
      } else {
        console.log(`${instPath} - INVALID. Errors:`);
        errors.forEach((e, i) => console.log(`${i + 1}. ${friendlyError(e, instance)}`));
      }
    } else if (opts.output === 'flag') {
      console.log(JSON.stringify({ instance: instPath, output: 'flag', payload: { valid }, schema: opts.schemaPath }));
    } else {
      console.log(structured(opts.output, opts.schemaPath, instPath, valid, errors, instance));
    }
  }
  process.exit(exitCode);
}

main();
