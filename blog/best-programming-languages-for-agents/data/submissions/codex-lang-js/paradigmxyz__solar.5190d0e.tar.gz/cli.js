#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = `solar Version: 0.1.8
Commit SHA: 8f228ae9f0bd90ad4ec81fb1ef4fbba29748b8d5
Build Timestamp: 2026-04-17T19:59:51.519973035Z
Build Features: mimalloc,tracing
Build Profile: release`;

const HELP_SHORT = `Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Files to compile, or import remappings

Options:
  -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]
      --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]
      --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: parsing, lowering, analysis]
      --out-dir <OUT_DIR>          Directory to write output files
      --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]
  -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version

Input options:
      --base-path <BASE_PATH>        Use the given path as the root of the source tree
  -I, --include-path <INCLUDE_PATH>  Directory to search for files
      --allow-paths <ALLOW_PATHS>    Allow a given path for imports

Display options:
      --color <COLOR>                Coloring [default: auto] [possible values: auto, always, never]
  -v, --verbose                      Use verbose output
      --pretty-json                  Pretty-print JSON output
      --pretty-json-err              Pretty-print error JSON output
      --error-format <ERROR_FORMAT>  How errors and other messages are produced [default: human] [possible values: human, json, rustc-json]
      --error-format-human <VALUE>   Human-readable error message style [default: unicode] [possible values: ascii, unicode, short]
      --diagnostic-width <WIDTH>     Terminal width for error message formatting
      --no-warnings                  Whether to disable warnings`;

const HELP_LONG = `Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...
          Files to compile, or import remappings.
          
          \`-\` specifies standard input.
          
          Import remappings are specified as \`[context:]prefix=path\`. See <https://docs.soliditylang.org/en/latest/path-resolution.html#import-remapping>.

Options:
  -j, --threads <THREADS>
          Number of threads to use. Zero specifies the number of logical cores
          
          [default: 4]
          [aliases: --jobs]

      --evm-version <EVM_VERSION>
          EVM version
          
          [default: prague]
          [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]

      --stop-after <STOP_AFTER>
          Stop execution after the given compiler stage
          
          [possible values: parsing, lowering, analysis]

      --out-dir <OUT_DIR>
          Directory to write output files

      --emit <EMIT>
          Comma separated list of types of output for the compiler to emit
          
          [possible values: abi, hashes]

  -Z <FLAG>
          Unstable flags. WARNING: these are completely unstable, and may change at any time.
          
          See \`-Zhelp\` for more details.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Input options:
      --base-path <BASE_PATH>
          Use the given path as the root of the source tree

  -I, --include-path <INCLUDE_PATH>
          Directory to search for files.
          
          Can be used multiple times.

      --allow-paths <ALLOW_PATHS>
          Allow a given path for imports

Display options:
      --color <COLOR>
          Coloring
          
          [default: auto]
          [possible values: auto, always, never]

  -v, --verbose
          Use verbose output

      --pretty-json
          Pretty-print JSON output.
          
          Does not include errors. See \`--pretty-json-err\`.

      --pretty-json-err
          Pretty-print error JSON output

      --error-format <ERROR_FORMAT>
          How errors and other messages are produced
          
          [default: human]
          [possible values: human, json, rustc-json]

      --error-format-human <VALUE>
          Human-readable error message style
          
          [default: unicode]
          [possible values: ascii, unicode, short]

      --diagnostic-width <WIDTH>
          Terminal width for error message formatting

      --no-warnings
          Whether to disable warnings`;

const ZHELP = `error: List of all unstable flags.
WARNING: these are completely unstable, and may change at any time!

Options:
      -Zui-testing
          Enables UI testing mode

      -Ztrack-diagnostics
          Prints a note for every diagnostic that is emitted with the creation and emission location.
          
          This is enabled by default on debug builds.

      -Zparse-yul
          Enables parsing Yul files for testing

      -Zno-resolve-imports
          Disables import resolution

      -Zdump=<KIND[=PATHS...]>
          Print additional information about the compiler's internal state.
          
          Valid kinds are \`ast\` and \`hir\`.

      -Zast-stats
          Print AST stats

      -Zspan-visitor
          Run the span visitor after parsing

      -Zprint-max-storage-sizes
          Print contracts' max storage sizes

      -Ztypeck
          Type check the program. WIP

      -Zhelp
          Print help

Usage: solar [OPTIONS] [INPUT]...

For more information, try '--help'.`;

const EVM = new Set('homestead tangerineWhistle spuriousDragon byzantium constantinople petersburg istanbul berlin london paris shanghai cancun prague osaka'.split(' '));
const STAGES = new Set('parsing lowering analysis'.split(' '));

function die(msg, code = 1) {
  process.stderr.write(msg.endsWith('\n') ? msg : msg + '\n');
  process.exit(code);
}

function cliError(msg) {
  die(`${msg}\n\nFor more information, try '--help'.`, 2);
}

function parseArgs(argv) {
  const opts = { emit: [], pretty: false, outDir: null, inputs: [], astStats: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h') { console.log(HELP_SHORT); process.exit(0); }
    if (a === '--help') { console.log(HELP_LONG); process.exit(0); }
    if (a === '-V' || a === '--version') { console.log(VERSION); process.exit(0); }
    if (a === '--pretty-json') { opts.pretty = true; continue; }
    if (a === '--pretty-json-err' || a === '--no-warnings' || a === '-v' || a === '--verbose') continue;
    if (a === '-Zhelp') { process.stderr.write(ZHELP + '\n'); process.exit(0); }
    if (a === '-Zast-stats') { opts.astStats = true; continue; }
    if (a === '-Z' || a === '--threads' || a === '--jobs' || a === '-j' || a === '--base-path' || a === '-I' || a === '--include-path' || a === '--allow-paths' || a === '--color' || a === '--error-format' || a === '--error-format-human' || a === '--diagnostic-width') { i++; continue; }
    if (a === '--evm-version') {
      const v = argv[++i];
      if (!EVM.has(v)) cliError(`error: invalid value '${v}' for '--evm-version <EVM_VERSION>'\n  [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]`);
      continue;
    }
    if (a === '--stop-after') {
      const v = argv[++i];
      if (!STAGES.has(v)) cliError(`error: invalid value '${v}' for '--stop-after <STOP_AFTER>'\n  [possible values: parsing, lowering, analysis]`);
      continue;
    }
    if (a === '--out-dir') { opts.outDir = argv[++i]; continue; }
    if (a === '--emit') {
      const v = argv[++i] || '';
      for (const e of v.split(',').filter(Boolean)) {
        if (e !== 'abi' && e !== 'hashes') cliError(`error: invalid value '${e}' for '--emit <EMIT>'\n  [possible values: abi, hashes]`);
        if (!opts.emit.includes(e)) opts.emit.push(e);
      }
      continue;
    }
    if (a === '-') { opts.inputs.push(a); continue; }
    if (a.startsWith('-')) {
      die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.`, 2);
    }
    if (!a.includes('=')) opts.inputs.push(a);
  }
  return opts;
}

function stripComments(s) {
  return s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/[^\n\r]*/g, '');
}

function findMatching(s, open) {
  let d = 0, quote = null;
  for (let i = open; i < s.length; i++) {
    const c = s[i];
    if (quote) { if (c === '\\') i++; else if (c === quote) quote = null; continue; }
    if (c === '"' || c === "'") { quote = c; continue; }
    if (c === '{') d++;
    else if (c === '}' && --d === 0) return i;
  }
  return -1;
}

function topItems(body) {
  const out = [];
  let i = 0, start = 0, par = 0, br = 0, depth = 0;
  for (; i < body.length; i++) {
    const c = body[i];
    if (c === '(') par++; else if (c === ')') par--;
    else if (c === '[') br++; else if (c === ']') br--;
    else if (c === '{' && par === 0 && br === 0) {
      if (depth++ === 0) {
        const head = body.slice(start, i).trim();
        const end = findMatching(body, i);
        out.push((head + ' {}').trim());
        i = end < 0 ? body.length : end;
        start = i + 1; depth = 0;
      }
    } else if (c === ';' && par === 0 && br === 0 && depth === 0) {
      const x = body.slice(start, i + 1).trim();
      if (x) out.push(x);
      start = i + 1;
    }
  }
  return out;
}

function splitTop(s, sep = ',') {
  const r = []; let start = 0, p = 0, b = 0, a = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (c === '(') p++; else if (c === ')') p--;
    else if (c === '[') b++; else if (c === ']') b--;
    else if (c === '<') a++; else if (c === '>') a--;
    else if (c === sep && p === 0 && b === 0 && a === 0) { r.push(s.slice(start, i).trim()); start = i + 1; }
  }
  const last = s.slice(start).trim(); if (last) r.push(last);
  return r;
}

function mappingParts(t) {
  const m = /^mapping\s*\((.*)=>(.*)\)$/s.exec(t.trim());
  if (!m) return null;
  return [m[1].trim(), m[2].trim()];
}

function canonicalType(t) {
  t = t.trim().replace(/\s+/g, ' ');
  t = t.replace(/\b(memory|calldata|storage|payable|indexed)\b/g, '').replace(/\s+/g, ' ').trim();
  t = t.replace(/\s*\[\s*([^\]]*)\s*\]/g, '[$1]');
  const mp = mappingParts(t);
  if (mp) return 'mapping';
  t = t.replace(/\buint\b/g, 'uint256').replace(/\bint\b/g, 'int256');
  t = t.replace(/\bbyte\b/g, 'bytes1');
  return t.replace(/\s+/g, '');
}

function internalType(t) {
  t = t.trim().replace(/\b(memory|calldata|storage|indexed)\b/g, '').replace(/\s+/g, ' ').trim();
  t = t.replace(/\s*\[\s*([^\]]*)\s*\]/g, '[$1]');
  t = t.replace(/\buint\b/g, 'uint256').replace(/\bint\b/g, 'int256').replace(/\bbyte\b/g, 'bytes1');
  return t;
}

const MODS = new Set('public private external internal view pure payable virtual override returns memory calldata storage indexed anonymous'.split(' '));
function parseParamList(s, eventMode = false) {
  if (!s.trim()) return [];
  return splitTop(s).map(p => {
    let toks = p.trim().split(/\s+/).filter(Boolean);
    let indexed = false;
    toks = toks.filter(x => { if (x === 'indexed') { indexed = true; return false; } return !['memory','calldata','storage'].includes(x); });
    let name = '';
    if (toks.length > 1 && !MODS.has(toks[toks.length - 1]) && !/\]$/.test(toks[toks.length - 1]) && toks[toks.length - 1] !== 'payable') name = toks.pop();
    let typ = toks.join(' ');
    const o = eventMode
      ? { name, type: canonicalType(typ), indexed, internalType: internalType(typ) }
      : { name, type: canonicalType(typ), internalType: internalType(typ) };
    return o;
  });
}

function stateMut(head) {
  const h = head.replace(/\([^()]*\)/g, ' ');
  if (/\bpayable\b/.test(h)) return 'payable';
  if (/\bpure\b/.test(h)) return 'pure';
  if (/\bview\b/.test(h)) return 'view';
  return 'nonpayable';
}

function extractParenAfter(s, word) {
  const i = s.indexOf(word);
  const o = s.indexOf('(', i + word.length);
  let d = 0;
  for (let j = o; j < s.length; j++) {
    if (s[j] === '(') d++; else if (s[j] === ')' && --d === 0) return s.slice(o + 1, j);
  }
  return '';
}

function parseReturns(head) {
  const m = /\breturns\s*\(/.exec(head);
  if (!m) return [];
  return parseParamList(extractParenAfter(head, 'returns'));
}

function publicGetter(line) {
  if (!/\bpublic\b/.test(line) || /^function\b/.test(line)) return null;
  let s = line.replace(/;.*/, '').trim();
  const eq = s.indexOf(' = ');
  if (eq >= 0) s = s.slice(0, eq).trim();
  if (/^(struct|enum|event|error|using|modifier)\b/.test(s)) return null;
  const toks = s.split(/\s+/);
  const name = toks[toks.length - 1];
  if (!/^[A-Za-z_]\w*$/.test(name)) return null;
  const before = s.slice(0, s.lastIndexOf(name)).replace(/\b(public|private|internal|external|constant|immutable|override)\b/g, '').trim();
  if (!before) return null;
  let typ = before;
  const inputs = [];
  let outType = typ;
  const mp = mappingParts(typ);
  if (mp) {
    inputs.push({ name: '', type: canonicalType(mp[0]), internalType: internalType(mp[0]) });
    outType = mp[1];
  } else {
    let base = typ;
    const dims = [...typ.matchAll(/\[[^\]]*\]/g)];
    if (dims.length) {
      for (const _ of dims) inputs.push({ name: '', type: 'uint256', internalType: 'uint256' });
      base = typ.replace(/\[[^\]]*\]/g, '');
      outType = base;
    }
  }
  return { type: 'function', name, inputs, outputs: [{ name: '', type: canonicalType(outType), internalType: internalType(outType) }], stateMutability: 'view' };
}

function parseContract(fileKey, name, body) {
  const items = topItems(body);
  const constructors = [], errors = [], events = [], fallbacks = [], funcs = [], receives = [];
  for (const raw of items) {
    const item = raw.trim().replace(/\s*\{\}\s*$/, '');
    if (/^constructor\s*\(/.test(item)) {
      constructors.push({ type: 'constructor', inputs: parseParamList(extractParenAfter(item, 'constructor')), stateMutability: stateMut(item) });
    } else if (/^event\s+/.test(item)) {
      const m = /^event\s+([A-Za-z_]\w*)/.exec(item); if (!m) continue;
      events.push({ type: 'event', name: m[1], inputs: parseParamList(extractParenAfter(item, m[1]), true), anonymous: /\banonymous\b/.test(item) });
    } else if (/^error\s+/.test(item)) {
      const m = /^error\s+([A-Za-z_]\w*)/.exec(item); if (!m) continue;
      errors.push({ type: 'error', name: m[1], inputs: parseParamList(extractParenAfter(item, m[1])) });
    } else if (/^fallback\s*\(/.test(item)) {
      fallbacks.push({ type: 'fallback', stateMutability: stateMut(item) });
    } else if (/^receive\s*\(/.test(item)) {
      receives.push({ type: 'receive', stateMutability: stateMut(item) });
    } else if (/^function\s+/.test(item)) {
      const m = /^function\s+([A-Za-z_]\w*)/.exec(item); if (!m) continue;
      funcs.push({ type: 'function', name: m[1], inputs: parseParamList(extractParenAfter(item, m[1])), outputs: parseReturns(item), stateMutability: stateMut(item) });
    } else {
      const g = publicGetter(item);
      if (g) funcs.push(g);
    }
  }
  funcs.sort((a, b) => a.name.localeCompare(b.name));
  const abi = [...constructors, ...errors, ...events, ...fallbacks, ...funcs, ...receives];
  const hashes = {};
  for (const f of funcs) {
    const sig = `${f.name}(${f.inputs.map(x => x.type).join(',')})`;
    hashes[sig] = keccak256(Buffer.from(sig)).subarray(0, 4).toString('hex');
  }
  return { key: `${fileKey}:${name}`, abi, hashes };
}

function parseSource(fileKey, src) {
  const s = stripComments(src);
  const out = [];
  const re = /\b(contract|interface|library)\s+([A-Za-z_]\w*)[^{;]*\{/g;
  let m;
  while ((m = re.exec(s))) {
    const open = s.indexOf('{', m.index);
    const close = findMatching(s, open);
    if (close < 0) throw new Error(`parse:${fileKey}`);
    out.push(parseContract(fileKey, m[2], s.slice(open + 1, close)));
    re.lastIndex = close + 1;
  }
  return out;
}

function rot(x, n) { n = BigInt(n); return ((x << n) | (x >> (64n - n))) & 0xffffffffffffffffn; }
const RC = [1n,0x8082n,0x800000000000808an,0x8000000080008000n,0x808bn,0x80000001n,0x8000000080008081n,0x8000000000008009n,0x8an,0x88n,0x80008009n,0x8000000an,0x8000808bn,0x800000000000008bn,0x8000000000008089n,0x8000000000008003n,0x8000000000008002n,0x8000000000000080n,0x800an,0x800000008000000an,0x8000000080008081n,0x8000000000008080n,0x80000001n,0x8000000080008008n];
const R = [[0,36,3,41,18],[1,44,10,45,2],[62,6,43,15,61],[28,55,25,21,56],[27,20,39,8,14]];
function keccakF(a) {
  for (let rnd = 0; rnd < 24; rnd++) {
    const c = Array(5).fill(0n), d = Array(5).fill(0n), b = Array(25).fill(0n);
    for (let x = 0; x < 5; x++) c[x] = a[x]^a[x+5]^a[x+10]^a[x+15]^a[x+20];
    for (let x = 0; x < 5; x++) d[x] = c[(x+4)%5] ^ rot(c[(x+1)%5], 1);
    for (let x = 0; x < 5; x++) for (let y = 0; y < 5; y++) a[x+5*y] ^= d[x];
    for (let x = 0; x < 5; x++) for (let y = 0; y < 5; y++) b[y + 5*((2*x+3*y)%5)] = rot(a[x+5*y], R[x][y]);
    for (let x = 0; x < 5; x++) for (let y = 0; y < 5; y++) a[x+5*y] = b[x+5*y] ^ ((~b[((x+1)%5)+5*y]) & b[((x+2)%5)+5*y] & 0xffffffffffffffffn);
    a[0] ^= RC[rnd];
  }
}
function keccak256(msg) {
  const rate = 136, a = Array(25).fill(0n);
  const blocks = [];
  for (let i = 0; i < msg.length; i += rate) blocks.push(msg.subarray(i, i + rate));
  let last = blocks.length ? blocks[blocks.length - 1] : Buffer.alloc(0);
  if (last.length === rate) { absorb(last); last = Buffer.alloc(0); }
  const pad = Buffer.alloc(rate); last.copy(pad); pad[last.length] = 0x01; pad[rate - 1] |= 0x80; absorb(pad);
  function absorb(block) {
    for (let i = 0; i < rate / 8; i++) {
      let v = 0n;
      for (let j = 0; j < 8; j++) v |= BigInt(block[i*8+j] || 0) << BigInt(8*j);
      a[i] ^= v;
    }
    keccakF(a);
  }
  const out = Buffer.alloc(32);
  for (let i = 0; i < 4; i++) {
    let v = a[i];
    for (let j = 0; j < 8; j++) { out[i*8+j] = Number(v & 0xffn); v >>= 8n; }
  }
  return out;
}

function readUnit(input, seen = new Set()) {
  let src, key = input;
  if (input === '-') {
    src = fs.readFileSync(0, 'utf8');
    key = '<stdin>';
  } else {
    if (!fs.existsSync(input)) die(`error: file ${input} not found\n\nerror: aborting due to 1 previous error\n`, 1);
    src = fs.readFileSync(input, 'utf8');
  }
  const units = [{ key, src }];
  if (input !== '-') {
    const dir = path.dirname(input);
    const re = /\bimport\s+(?:(?:[^'"]+from\s*)?)["']([^"']+)["']\s*;/g;
    let m;
    while ((m = re.exec(src))) {
      let p = m[1];
      if (!path.isAbsolute(p)) p = path.normalize(path.join(dir, p));
      if (!seen.has(p) && fs.existsSync(p)) {
        seen.add(p);
        units.push(...readUnit(p, seen));
      }
    }
  }
  return units;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const contracts = {};
  try {
    const seen = new Set();
    for (const input of opts.inputs) {
      for (const {key, src} of readUnit(input, seen)) {
      for (const c of parseSource(key, src)) {
        contracts[c.key] = {};
        if (opts.emit.includes('abi')) contracts[c.key].abi = c.abi;
        if (opts.emit.includes('hashes')) contracts[c.key].hashes = c.hashes;
      }
      }
    }
  } catch (e) {
    die(`error: expected contract item (function, variable, struct, or modifier definition), found \`<eof>\`\n\nerror: aborting due to 1 previous error\n`, 1);
  }
  if (opts.astStats) process.stderr.write('ast-stats AST STATS\nast-stats Total                  0\nast-stats\n');
  if (!opts.emit.length) return;
  const result = { contracts, version: '0.1.8' };
  const json = opts.pretty ? JSON.stringify(result, null, 2) : JSON.stringify(result);
  if (opts.outDir) {
    try { fs.writeFileSync(path.join(opts.outDir, 'combined.json'), json); }
    catch (_) { die('error: failed to write to output: No such file or directory (os error 2)\n\nerror: aborting due to 1 previous error\n', 1); }
  } else {
    process.stdout.write(json + '\n');
  }
}

main();
