#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const VERSION = '1.17.0 (9135bd68ddc9ea65023d967c75048a7a86a5d495)';
const YEAR = '2025';
const root = __dirname;
const templates = path.join(root, '..', 'templates');

function prog() { return process.env.DOXYGEN_PROG || process.argv[1] || './executable'; }
function out(s='') { process.stdout.write(s + (s.endsWith('\n') ? '' : '\n')); }
function err(s='') { process.stderr.write(s + (s.endsWith('\n') ? '' : '\n')); }
function readT(name) { return fs.readFileSync(path.join(templates, name), 'utf8'); }
function writeOrStdout(file, data) {
  if (!file || file === '-') process.stdout.write(data);
  else fs.writeFileSync(file, data);
}

function usage() {
  const p = prog();
  return `Doxygen version ${VERSION}
Copyright Dimitri van Heesch 1997-${YEAR}

You can use Doxygen in a number of ways:

1) Use Doxygen to generate a template configuration file*:
    ${p} [-s] -g [configName]

2) Use Doxygen to update an old configuration file*:
    ${p} [-s] -u [configName]

3) Use Doxygen to generate documentation using an existing configuration file*:
    ${p} [configName]

4) Use Doxygen to generate a template file controlling the layout of the
   generated documentation:
    ${p} -l [layoutFileName]

    In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.
    If - is used for layoutFileName Doxygen will write to standard output.

5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.
    RTF:        ${p} -w rtf styleSheetFile
    HTML:       ${p} -w html headerFile footerFile styleSheetFile [configFile]
    LaTeX:      ${p} -w latex headerFile footerFile styleSheetFile [configFile]

6) Use Doxygen to generate a rtf extensions file
    ${p} -e rtf extensionsFile

    If - is used for extensionsFile Doxygen will write to standard output.

7) Use Doxygen to compare the used configuration file with the template configuration file
    ${p} -x [configFile]

   Use Doxygen to compare the used configuration file with the template configuration file
   without replacing the environment variables or CMake type replacement variables
    ${p} -x_noenv [configFile]

8) Use Doxygen to show a list of built-in emojis.
    ${p} -f emoji outputFileName

    If - is used for outputFileName Doxygen will write to standard output.

*) If -s is specified the comments of the configuration items in the config file will be omitted.
   If configName is omitted 'Doxyfile' will be used as a default.
   If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.

If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.

-v print version string, -V print extended version information
-h,-? prints usage help information
${p} -d prints additional usage flags for debugging purposes
`;
}

function devUsage() {
  return `Developer parameters:
  -m          dump symbol map
  -b          making messages output unbuffered
  -c <file>   process input file as a comment block and produce HTML output
  -d <level>  enable a debug level, such as (multiple invocations of -d are possible):
\talias
\tcite
\tcommentcnv
\tcommentscan
\tentries
\textcmd
\tfilteroutput
\tformula
\tfortranfixed2free
\tlayout
\tlex
\tlex:code
\tlex:commentcnv
\tlex:commentscan
\tlex:configimpl
\tlex:constexp
\tlex:declinfo
\tlex:defargs
\tlex:doctokenizer
\tlex:fortrancode
\tlex:fortranscanner
\tlex:lexcode
\tlex:lexscanner
\tlex:pre
\tlex:pycode
\tlex:pyscanner
\tlex:scanner
\tlex:sqlcode
\tlex:vhdlcode
\tlex:xml
\tlex:xmlcode
\tmarkdown
\tnolineno
\tplantuml
\tpreprocessor
\tprinttree
\tqhp
\trtf
\tsections
\tstderr
\ttag
\ttime
`;
}

function parseConfig(text) {
  const cfg = {};
  let current = null;
  for (const raw of text.split(/\r?\n/)) {
    let line = raw.replace(/\s+#.*$/, '').trimEnd();
    if (!line.trim() || line.trimStart().startsWith('#')) continue;
    const cont = /\\$/.test(line);
    if (cont) line = line.replace(/\\\s*$/, '');
    const m = line.match(/^([A-Za-z0-9_]+)\s*(\+?=)\s*(.*)$/);
    if (m) {
      current = m[1];
      const value = unquote(m[3].trim());
      cfg[current] = m[2] === '+=' && cfg[current] ? cfg[current] + ' ' + value : value;
    } else if (current) {
      cfg[current] += ' ' + unquote(line.trim());
    }
    if (!cont) current = null;
  }
  return cfg;
}

function unquote(s) {
  return s.replace(/^"(.*)"$/, '$1').replace(/\\"/g, '"');
}

function htmlEscape(s) {
  return String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
}

function words(v) {
  if (!v) return [];
  const out = [];
  const re = /"([^"]*)"|'([^']*)'|(\S+)/g;
  let m;
  while ((m = re.exec(v))) out.push(m[1] ?? m[2] ?? m[3]);
  return out;
}

function isYes(v, d=false) {
  if (v == null || v === '') return d;
  return /^(yes|true|1)$/i.test(String(v).trim());
}

function collectFiles(inputs, recursive) {
  const result = [];
  const seen = new Set();
  const exts = new Set(['.c','.cc','.cpp','.cxx','.h','.hh','.hpp','.hxx','.js','.mjs','.java','.py','.cs','.php','.md','.markdown','.dox','.txt']);
  function add(p) {
    if (!fs.existsSync(p)) return;
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      for (const e of fs.readdirSync(p)) {
        const full = path.join(p, e);
        if (fs.statSync(full).isDirectory()) { if (recursive) add(full); }
        else add(full);
      }
    } else if (exts.has(path.extname(p).toLowerCase()) || path.basename(p).toLowerCase() === 'readme') {
      const r = path.resolve(p);
      if (!seen.has(r)) { seen.add(r); result.push(r); }
    }
  }
  (inputs.length ? inputs : ['.']).forEach(add);
  return result;
}

function cleanDoc(s) {
  return s.split(/\r?\n/).map(l => l
    .replace(/^\s*\/\*\*?/, '')
    .replace(/\*\/\s*$/, '')
    .replace(/^\s*\* ?/, '')
    .replace(/^\s*\/\/\/ ?/, '')
    .replace(/^\s*## ?/, '')
  ).join('\n').trim();
}

function extractDocs(file) {
  let text = '';
  try { text = fs.readFileSync(file, 'utf8'); } catch { return []; }
  const docs = [];
  const block = /\/\*\*([\s\S]*?)\*\/\s*([^\n{;]*[({;][^\n]*)?/g;
  let m;
  while ((m = block.exec(text))) docs.push({doc: cleanDoc(m[0].replace((m[2]||''), '')), decl: (m[2]||'').trim()});
  const lines = text.split(/\r?\n/);
  for (let i=0; i<lines.length; i++) {
    if (/^\s*\/\/\//.test(lines[i])) {
      const buf = [];
      while (i<lines.length && /^\s*\/\/\//.test(lines[i])) buf.push(lines[i++]);
      const decl = (lines[i] || '').trim();
      docs.push({doc: cleanDoc(buf.join('\n')), decl});
    }
  }
  return docs.map(d => {
    const name = guessName(d.decl) || firstTitle(d.doc) || path.basename(file);
    return {...d, name, brief: brief(d.doc)};
  });
}

function firstTitle(s) {
  const m = s.match(/(?:@mainpage|\\mainpage|#)\s+(.+)/);
  return m && m[1].trim();
}

function brief(s) {
  const b = s.match(/(?:@brief|\\brief)\s+([^\n]+)/);
  if (b) return b[1].trim();
  return s.split(/\n\s*\n/)[0].replace(/[@\\](param|return|retval)\b.*$/gms, '').trim();
}

function guessName(decl) {
  if (!decl) return '';
  let m = decl.match(/\b(class|struct|interface|enum)\s+([A-Za-z_][\w:]*)/);
  if (m) return m[2];
  m = decl.match(/([A-Za-z_][\w:]*)\s*\([^;]*\)/);
  if (m) return m[1].split('::').pop();
  m = decl.match(/\b([A-Za-z_][\w]*)\s*[;=]/);
  return m ? m[1] : '';
}

function page(title, project, body) {
  return `<!DOCTYPE html>
<html lang="en-US"><head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
<meta name="generator" content="Doxygen 1.17.0"/>
<title>${htmlEscape(project ? project + ': ' + title : title)}</title>
<link href="doxygen.css" rel="stylesheet" type="text/css" />
</head><body>
<div id="titlearea"><div id="projectname">${htmlEscape(project)}</div></div>
<div id="main-nav"><a href="index.html">Main Page</a> <a href="files.html">Files</a> <a href="annotated.html">Classes</a></div>
<main class="contents">${body}</main>
<hr/><address class="footer"><small>Generated by Doxygen 1.17.0</small></address>
</body></html>\n`;
}

function renderDoc(d) {
  let s = d.doc.replace(/(?:@brief|\\brief)\s+/g, '');
  s = s.replace(/(?:@param|\\param)\s+(\w+)\s+([^\n]+)/g, '<dt>$1</dt><dd>$2</dd>');
  s = s.replace(/(?:@return|\\return|@returns|\\returns)\s+([^\n]+)/g, '<h3>Returns</h3><p>$1</p>');
  return '<p>' + htmlEscape(s).replace(/\n\s*\n/g, '</p><p>').replace(/\n/g, '<br/>')
    .replace(/&lt;dt&gt;/g, '<dl><dt>').replace(/&lt;\/dd&gt;/g, '</dd></dl>')
    .replace(/&lt;dd&gt;/g, '<dd>').replace(/&lt;\/dt&gt;/g, '</dt>')
    .replace(/&lt;h3&gt;/g, '<h3>').replace(/&lt;\/h3&gt;/g, '</h3>')
    .replace(/&lt;p&gt;/g, '<p>').replace(/&lt;\/p&gt;/g, '</p>') + '</p>';
}

function generate(configPath, quietFlag) {
  let cfgText = '';
  if (configPath === '-') {
    cfgText = fs.readFileSync(0, 'utf8');
  } else {
    const f = configPath || 'Doxyfile';
    if (!fs.existsSync(f)) {
      process.stdout.write(usage());
      err(configPath ? `error: configuration file ${f} not found!` : 'error: Doxyfile not found and no input file specified!');
      process.exit(1);
    }
    cfgText = fs.readFileSync(f, 'utf8');
  }
  const cfg = parseConfig(cfgText);
  if (quietFlag) cfg.QUIET = 'YES';
  const quiet = isYes(cfg.QUIET, false);
  const project = cfg.PROJECT_NAME || 'My Project';
  const outDir = cfg.OUTPUT_DIRECTORY || '.';
  const htmlDir = path.join(outDir, cfg.HTML_OUTPUT || 'html');
  const latexDir = path.join(outDir, cfg.LATEX_OUTPUT || 'latex');
  if (!quiet) {
    out(`Doxygen version used: ${VERSION}`);
    if (outDir !== '.' && !fs.existsSync(outDir)) out(`Notice: Output directory '${outDir}' does not exist. I have created it for you.`);
    out('Searching for include files...');
    out('Searching INPUT for files to process...');
    out('Parsing files');
  }
  fs.mkdirSync(htmlDir, {recursive:true});
  fs.writeFileSync(path.join(htmlDir, 'doxygen.css'), readT('style.css'));
  for (const f of ['tabs.css','navtree.css','dynsections.js','clipboard.js','menu.js','menudata.js','navtree.js','navtreedata.js','navtreeindex0.js','cookie.js']) {
    fs.writeFileSync(path.join(htmlDir, f), f.endsWith('.css') ? '/* generated */\n' : '// generated\n');
  }
  const inputs = words(cfg.INPUT);
  const files = collectFiles(inputs, isYes(cfg.RECURSIVE, false));
  const docs = [];
  for (const f of files) {
    if (!quiet) out(`Parsing file ${f}...`);
    docs.push(...extractDocs(f).map(d => ({...d, file:f})));
    const srcName = safeFile(path.basename(f)) + '_source.html';
    fs.writeFileSync(path.join(htmlDir, srcName), page(path.basename(f), project, `<h1>${htmlEscape(path.basename(f))}</h1><pre>${htmlEscape(fs.readFileSync(f,'utf8'))}</pre>`));
  }
  const mainDoc = docs.find(d => /[@\\]mainpage/.test(d.doc));
  let indexBody = `<h1>${htmlEscape(project)}</h1>`;
  if (mainDoc) indexBody += renderDoc({...mainDoc, doc: mainDoc.doc.replace(/[@\\]mainpage[^\n]*/, '')});
  else if (cfg.PROJECT_BRIEF) indexBody += `<p>${htmlEscape(cfg.PROJECT_BRIEF)}</p>`;
  if (docs.length) indexBody += '<h2>Documentation</h2><ul>' + docs.map(d => `<li><a href="${docFile(d)}">${htmlEscape(d.name)}</a> ${htmlEscape(d.brief)}</li>`).join('\n') + '</ul>';
  fs.writeFileSync(path.join(htmlDir, 'index.html'), page('Main Page', project, indexBody));
  fs.writeFileSync(path.join(htmlDir, 'files.html'), page('File List', project, '<h1>File List</h1><ul>' + files.map(f => `<li>${htmlEscape(path.basename(f))}</li>`).join('\n') + '</ul>'));
  fs.writeFileSync(path.join(htmlDir, 'annotated.html'), page('Data Structures', project, '<h1>Data Structures</h1><ul>' + docs.filter(d=>/\b(class|struct|interface)\b/.test(d.decl)).map(d => `<li>${htmlEscape(d.name)}</li>`).join('\n') + '</ul>'));
  for (const d of docs) {
    fs.writeFileSync(path.join(htmlDir, docFile(d)), page(d.name, project, `<h1>${htmlEscape(d.name)}</h1>${d.decl ? `<div class="memproto">${htmlEscape(d.decl)}</div>` : ''}${renderDoc(d)}`));
  }
  if (isYes(cfg.GENERATE_LATEX, true)) {
    fs.mkdirSync(latexDir, {recursive:true});
    fs.writeFileSync(path.join(latexDir, 'refman.tex'), `\\documentclass{book}\n\\begin{document}\n\\title{${project}}\n\\maketitle\nGenerated by Doxygen 1.17.0\n\\end{document}\n`);
  }
  if (!quiet) {
    out('Generating style sheet...');
    out('Generating file documentation...');
    out('Generating docs for compound list...');
    out('Running plantuml with JAVA...');
    out('lookup cache used 0/65536 hits=0 misses=0');
    out('finished...');
  }
}

function safeFile(s) { return s.replace(/[^A-Za-z0-9_]/g, '_'); }
function docFile(d) { return safeFile(d.name || path.basename(d.file)) + '.html'; }

function diffConfig(file, noenv) {
  const cfg = fs.existsSync(file) ? parseConfig(fs.readFileSync(file, 'utf8')) : {};
  const def = parseConfig(readT('Doxyfile.simple'));
  out(`# Difference with default Doxyfile ${VERSION}`);
  for (const [k,v] of Object.entries(cfg)) {
    if ((def[k] || '') !== v) out(`${k.padEnd(22)} = ${v}`);
  }
}

function main() {
  let args = process.argv.slice(2);
  let simple = false, quiet = false;
  args = args.filter(a => {
    if (a === '-s') { simple = true; return false; }
    if (a === '-q') { quiet = true; return false; }
    return true;
  });
  if (args.length === 0) return generate(null, quiet);
  const a = args[0];
  if (a === '--help' || a === '-h' || a === '-?') { process.stdout.write(usage()); return; }
  if (a === '-v') { out(VERSION); return; }
  if (a === '-V') { out(VERSION); out('    with sqlite3 3.42.0.'); return; }
  if (a === '-d' && args.length === 1) { process.stdout.write(devUsage()); return; }
  if (a === '-g' || a === '-u') {
    const name = args[1] || 'Doxyfile';
    writeOrStdout(name, readT(simple ? 'Doxyfile.simple' : 'Doxyfile'));
    if (name !== '-') {
      if (a === '-g') out(`\n\nConfiguration file '${name}' created.\n\nNow edit the configuration file and enter\n\n  ${prog()} ${name}\n\nto generate the documentation for your project\n`);
      else out(`Configuration file '${name}' updated.`);
    }
    return;
  }
  if (a === '-l') { writeOrStdout(args[1] || 'DoxygenLayout.xml', readT('layout.xml')); return; }
  if (a === '-e') {
    if (!args[1]) { err('error: option "-e" is missing format specifier rtf.'); process.exit(1); }
    if (args[1] !== 'rtf') { err(`error: Illegal format specifier "${args[1]}": should be rtf`); process.exit(1); }
    writeOrStdout(args[2], readT('rtf.ext')); return;
  }
  if (a === '-f') {
    if (!args[1]) { err('error: option "-f" is missing list specifier.'); process.exit(1); }
    if (args[1] !== 'emoji') { err(`error: Illegal list specifier "${args[1]}": should be emoji`); process.exit(1); }
    writeOrStdout(args[2], readT('emoji.txt')); return;
  }
  if (a === '-w') {
    if (!args[1]) { err('error: option "-w" is missing format specifier rtf, html or latex'); process.exit(1); }
    if (!['rtf','html','latex'].includes(args[1])) { err(`error: Illegal format specifier "${args[1]}": should be one of rtf, html or latex`); process.exit(1); }
    if (args[1] === 'rtf') writeOrStdout(args[2], readT('rtfstyle.cfg'));
    if (args[1] === 'html') { writeOrStdout(args[2], readT('header.html')); writeOrStdout(args[3], readT('footer.html')); writeOrStdout(args[4], readT('style.css')); }
    if (args[1] === 'latex') { writeOrStdout(args[2], readT('h.tex')); writeOrStdout(args[3], readT('f.tex')); writeOrStdout(args[4], readT('s.sty')); }
    return;
  }
  if (a === '-x' || a === '-x_noenv') { diffConfig(args[1] || 'Doxyfile', a === '-x_noenv'); return; }
  if (a.startsWith('-')) { process.stdout.write(usage()); err(`error: Unknown option "${a}"`); process.exit(1); }
  generate(a, quiet);
}

try { main(); } catch (e) { err('error: ' + e.message); process.exit(1); }
