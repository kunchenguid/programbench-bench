#!/usr/bin/env node
"use strict";

const { spawnSync } = require("child_process");
const fs = require("fs");

const GRAY = "\x1b[38;5;240m";
const GREEN = "\x1b[32m";
const RED = "\x1b[31m";
const RESET = "\x1b[0m";

function usage(binary = "executable") {
  return `A modern alternative to the watch command, records the differences in execution results and can check this differences at after.

Usage: ${binary} [OPTIONS] [command]...

Arguments:
  [command]...  

Options:
  -b, --batch                         output execution results to stdout
  -B, --beep                          beep if command has a change result
      --border                        Surround each pane with a border frame
      --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.
      --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.
  -c, --color                         interpret ANSI color and style sequences
  -r, --reverse                       display text upside down.
  -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.
  -t, --no-title                      hide the UI on start. Use \`t\` to toggle it.
      --enable-summary-char           collect character-level diff count in summary.
  -N, --line-number                   show line number
      --no-help-banner                hide the "Display help with h key" message
      --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.
  -x, --exec                          Run the command directly, not through the shell. Much like the \`-x\` option of the watch command.
  -O, --diff-output-only              Display only the lines with differences during \`line\` diff and \`word\` diff.
  -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable \${HWATCH_DATA}.
  -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.
  -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {COMMAND}. [default: "sh -c"]
  -n, --interval <interval>           seconds to wait between updates [default: 2]
      --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run
  -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set \`0\` for unlimited recording. (default: 5000) [default: 5000]
      --tab-size <tab_size>           Specifying tab display size [default: 4]
  -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]
  -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]
  -K, --keymap <keymap>               Add keymap
  -h, --help                          Print help
  -V, --version                       Print version`;
}

function shellWords(s) {
  if (!s) return [];
  const out = [];
  let cur = "", q = null, esc = false;
  for (const ch of s) {
    if (esc) { cur += ch; esc = false; continue; }
    if (ch === "\\") { esc = true; continue; }
    if (q) {
      if (ch === q) q = null; else cur += ch;
    } else if (ch === "'" || ch === '"') q = ch;
    else if (/\s/.test(ch)) { if (cur) { out.push(cur); cur = ""; } }
    else cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

function parse(argv) {
  const args = [...shellWords(process.env.HWATCH || ""), ...argv];
  const opt = {
    batch: false, exec: false, reverse: false, lineNumber: false, color: false,
    interval: 2, output: "output", diff: "none", diffOnly: false, tabSize: 4,
    shell: "sh -c", logfile: null, after: null, command: []
  };
  const takes = new Set(["-A","--aftercommand","-s","--shell","-n","--interval","-L","--limit","--tab-size","-o","--output","-K","--keymap"]);
  const flags = new Set(["-b","--batch","-B","--beep","--border","--with-scrollbar","--mouse","-c","--color","-r","--reverse","-C","--compress","-t","--no-title","--enable-summary-char","-N","--line-number","--no-help-banner","--no-summary","-x","--exec","--precise","-O","--diff-output-only"]);
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") { opt.command = args.slice(i + 1); break; }
    if (a === "-h" || a === "--help") { opt.help = true; continue; }
    if (a === "-V" || a === "--version") { opt.version = true; continue; }
    if (a === "-b" || a === "--batch") opt.batch = true;
    else if (a === "-x" || a === "--exec") opt.exec = true;
    else if (a === "-r" || a === "--reverse") opt.reverse = true;
    else if (a === "-N" || a === "--line-number") opt.lineNumber = true;
    else if (a === "-c" || a === "--color") opt.color = true;
    else if (a === "-O" || a === "--diff-output-only") opt.diffOnly = true;
    else if (a === "-l" || a === "--logfile") {
      const n = args[i + 1];
      if (n && !n.startsWith("-")) opt.logfile = args[++i]; else opt.logfile = "hwatch.log";
    } else if (a.startsWith("--logfile=")) opt.logfile = a.slice(10) || "hwatch.log";
    else if (a === "-d" || a === "--differences") {
      const n = args[i + 1];
      if (n && !n.startsWith("-")) { opt.diff = n; i++; } else opt.diff = "watch";
      if (!["none","watch","line","word"].includes(opt.diff)) dieInvalid(a, opt.diff, "differences", "[<differences>]", "[possible values: none, watch, line, word]");
    } else if (a.startsWith("--differences=")) {
      opt.diff = a.slice(14) || "watch";
      if (!["none","watch","line","word"].includes(opt.diff)) dieInvalid("--differences", opt.diff, "differences", "[<differences>]", "[possible values: none, watch, line, word]");
    } else if (takes.has(a)) {
      if (i + 1 >= args.length) die(`error: a value is required for '${a} <${a.replace(/^-+/, "").replace("-", "_")}>' but none was supplied`);
      const v = args[++i];
      if (a === "-n" || a === "--interval") {
        const num = parseFloat(v.replace(",", "."));
        if (!Number.isFinite(num)) die(`error: invalid value '${v}' for '--interval <interval>': invalid float literal\n\nFor more information, try '--help'.`, 2);
        opt.interval = Math.max(0.001, num);
      } else if (a === "-o" || a === "--output") {
        opt.output = v;
        if (!["output","stdout","stderr"].includes(v)) dieInvalid(a, v, "output", "[<output>]", "[possible values: output, stdout, stderr]");
      } else if (a === "-s" || a === "--shell") opt.shell = v;
      else if (a === "-A" || a === "--aftercommand") opt.after = v;
      else if (a === "--tab-size") opt.tabSize = parseInt(v, 10) || 4;
    } else if (flags.has(a)) {
      continue;
    } else {
      opt.command = args.slice(i);
      break;
    }
  }
  return opt;
}

function dieInvalid(flag, val, name, placeholder, extra) {
  die(`error: invalid value '${val}' for '--${name} ${placeholder}'\n  ${extra}\n\nFor more information, try '--help'.`, 2);
}
function die(msg, code = 1) { console.error(msg); process.exit(code); }

function timestamp(d = new Date()) {
  const p = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${p(d.getMilliseconds(),3)}`;
}

function runCommand(opt) {
  const commandText = opt.command.join(" ");
  if (opt.exec) {
    if (!opt.command.length) return { status: false, stdout: "", stderr: "" };
    const r = spawnSync(opt.command[0], opt.command.slice(1), { encoding: "utf8", maxBuffer: 1024 * 1024 * 100 });
    return { status: (r.status || 0) === 0, stdout: r.stdout || "", stderr: r.stderr || (r.error ? String(r.error.message) + "\n" : "") };
  }
  let file = "sh", args = ["-c", commandText];
  if (opt.shell.includes("{COMMAND}")) {
    const words = shellWords(opt.shell.replace("{COMMAND}", commandText));
    file = words.shift() || "sh"; args = words;
  } else {
    const words = shellWords(opt.shell);
    file = words.shift() || "sh"; args = [...words, commandText];
  }
  const r = spawnSync(file, args, { encoding: "utf8", maxBuffer: 1024 * 1024 * 100 });
  return { status: (r.status || 0) === 0, stdout: r.stdout || "", stderr: r.stderr || (r.error ? String(r.error.message) + "\n" : "") };
}

function selected(res, mode) {
  if (mode === "stdout") return res.stdout;
  if (mode === "stderr") return res.stderr;
  return (res.stdout || "") + (res.stderr || "");
}

function addLineNumbers(text) {
  const lines = text.split("\n");
  return lines.map((l, i) => `${GRAY}${i + 1}${RESET}${GRAY} | ${RESET}${l}`).join("\n");
}

function reverseLines(text) {
  return text.split("\n").reverse().join("\n");
}

function lineDiff(text, prev, mode, only) {
  if (mode === "none" || mode === "watch") return text;
  const lines = text.replace(/\n$/, "").split("\n");
  const old = new Set((prev || "").replace(/\n$/, "").split("\n"));
  const out = [];
  for (const l of lines) {
    if (!old.has(l)) out.push(`${GREEN}+  ${RESET}${GREEN}${l}${RESET}`);
    else if (!only) out.push(`   ${l}`);
  }
  return out.join("\n") + (out.length ? "\n" : "");
}

function writeLog(path, rec) {
  fs.appendFileSync(path, JSON.stringify(rec) + "\n");
}

function out(s) {
  fs.writeSync(1, s);
}

function main() {
  const opt = parse(process.argv.slice(2));
  const bin = process.argv[1] && process.argv[1].endsWith("hwatch.js") ? "executable" : (process.argv[1] || "executable").split("/").pop();
  if (opt.help) { console.log(usage(bin)); return; }
  if (opt.version) { console.log("hwatch 0.3.19"); return; }
  if (!opt.command.length && !opt.logfile) die("error: command not specified and logfile is empty.\n\nUsage: hwatch [OPTIONS] [command]...\n\nFor more information, try '--help'.", 1);
  if (!opt.command.length && opt.logfile && fs.existsSync(opt.logfile)) {
    process.stdout.write(fs.readFileSync(opt.logfile, "utf8"));
    return;
  }
  if (opt.logfile) writeLog(opt.logfile, { timestamp: "", command: "", status: true, output: "", stdout: "", stderr: "" });

  let prev = null;
  const once = !opt.batch && !process.stdout.isTTY;
  while (true) {
    const now = timestamp();
    const res = runCommand(opt);
    const outRaw = selected(res, opt.output);
    let body = lineDiff(outRaw, prev, opt.diff, opt.diffOnly);
    if (opt.reverse) body = reverseLines(body);
    if (opt.lineNumber) body = addLineNumbers(body);
    out(`${GRAY}=====[${now}]=========================${RESET}\n`);
    out(body);
    if (!body.endsWith("\n")) out("\n");
    if (opt.diff === "none" || opt.diff === "watch") out("\n");
    if (opt.logfile && outRaw !== prev) writeLog(opt.logfile, { timestamp: now, command: opt.command.join(" "), status: res.status, output: res.stdout + res.stderr, stdout: res.stdout, stderr: res.stderr });
    if (opt.after && prev !== null && outRaw !== prev) {
      const data = JSON.stringify({ timestamp: now, command: opt.command.join(" "), status: res.status, output: res.stdout + res.stderr, stdout: res.stdout, stderr: res.stderr });
      spawnSync("sh", ["-c", opt.after], { env: { ...process.env, HWATCH_DATA: data }, stdio: "inherit" });
    }
    prev = outRaw;
    if (once) return;
    const end = Date.now() + Math.round(opt.interval * 1000);
    while (Date.now() < end) Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, Math.min(50, end - Date.now()));
  }
}

main();
