#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = 'hexyl 0.16.0';

const HELP = `A command-line hex viewer

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          The file to display. If no FILE argument is given, read from STDIN

Options:
  -n, --length <N>
          Only read N bytes from the input. The N argument can also include a unit with a
          decimal prefix (kB, MB, ..) or binary prefix (kiB, MiB, ..), or can be specified
          using a hex number. The short option '-l' can be used as an alias.
          Examples: --length=64, --length=4KiB, --length=0xff
          
          [aliases: bytes]
          [short aliases: c]

  -s, --skip <N>
          Skip the first N bytes of the input. The N argument can also include a unit (see
          \`--length\` for details).
          A negative value is valid and will seek from the end of the file.

      --block-size <SIZE>
          Sets the size of the \`block\` unit to SIZE.
          Examples: --block-size=1024, --block-size=4kB
          
          [default: 512]

  -v, --no-squeezing
          Displays all input data. Otherwise any number of groups of output lines which
          would be identical to the preceding group of lines, are replaced with a line
          comprised of a single asterisk

      --color <WHEN>
          When to use colors
          
          [default: always]

          Possible values:
          - always: Always use colorized output
          - auto:   Only displays colors if the output goes to an interactive terminal
          - never:  Do not use colorized output
          - force:  Override the NO_COLOR environment variable

      --border <STYLE>
          Whether to draw a border
          
          [default: unicode]

          Possible values:
          - unicode: Draw a border with Unicode characters
          - ascii:   Draw a border with ASCII characters
          - none:    Do not draw a border at all

  -p, --plain
          Display output with --no-characters, --no-position, --border=none, and
          --color=never

      --no-characters
          Do not show the character panel on the right

  -C, --characters
          Show the character panel on the right. This is the default, unless
          --no-characters has been specified

      --character-table <FORMAT>
          Defines how bytes are mapped to characters
          
          [default: default]

          Possible values:
          - default:       Show printable ASCII characters as-is, '⋄' for NULL bytes, ' '
            for space, '_' for other ASCII whitespace, '•' for other ASCII characters, and
            '×' for non-ASCII bytes
          - ascii:         Show printable ASCII as-is, ' ' for space, '.' for everything
            else
          - codepage-1047: Show printable EBCDIC as-is, ' ' for space, '.' for everything
            else
          - codepage-437:  Uses code page 437 (for non-ASCII bytes)
          - braille:       Uses braille characters for non-printable bytes

      --color-scheme <FORMAT>
          Defines the color scheme for the characters
          
          [default: default]

          Possible values:
          - default:  Show the default colors: bright black for NULL bytes, green for
            ASCII space characters and non-printable ASCII, cyan for printable ASCII
            characters, and yellow for non-ASCII bytes
          - gradient: Show bright black for NULL bytes, cyan for printable ASCII
            characters, a gradient from pink to violet for non-printable ASCII characters
            and a heatmap-like gradient from red to yellow to white for non-ASCII bytes

  -P, --no-position
          Whether to display the position panel on the left

  -o, --display-offset <N>
          Add N bytes to the displayed file position. The N argument can also include a
          unit (see \`--length\` for details).
          A negative value is valid and calculates an offset relative to the end of the
          file.
          
          [default: 0]

      --panels <N>
          Sets the number of hex data panels to be displayed. \`--panels=auto\` will display
          the maximum number of hex data panels based on the current terminal width. By
          default, hexyl will show two panels, unless the terminal is not wide enough for
          that

  -g, --group-size <N>
          Number of bytes/octets that should be grouped together. You can use the
          '--endianness' option to control the ordering of the bytes within a group.
          '--groupsize' can be used as an alias (xxd-compatibility)
          
          [default: 1]

          Possible values:
          - 1: Grouped together every byte/octet
          - 2: Grouped together every 2 bytes/octets
          - 4: Grouped together every 4 bytes/octets
          - 8: Grouped together every 8 bytes/octets

      --endianness <FORMAT>
          Whether to print out groups in little-endian or big-endian format. This option
          only has an effect if the '--group-size' is larger than 1. '-e' can be used as
          an alias for '--endianness=little'
          
          [default: big]

          Possible values:
          - little: Print out groups in little-endian format
          - big:    Print out groups in big-endian format

  -b, --base <B>
          Sets the base used for the bytes. The possible options are binary, octal,
          decimal, and hexadecimal
          
          [default: hexadecimal]

      --terminal-width <N>
          Sets the number of terminal columns to be displayed.
          Since the terminal width may not be an evenly divisible by the width per hex
          data column, this will use the greatest number of hex data panels that can fit
          in the requested width but still leave some space to the right.
          Cannot be used with other width-setting options.

      --print-color-table
          Print a table showing how different types of bytes are colored

  -i, --include
          Output in C include file style

      --completion <SHELL>
          Show shell completion for a certain shell
          
          [possible values: bash, elvish, fish, powershell, zsh]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

function die(msg, code = 1) {
  process.stderr.write(msg + '\n');
  process.exit(code);
}

function takeValue(args, i, name) {
  const arg = args[i];
  const eq = arg.indexOf('=');
  if (eq !== -1) return [arg.slice(eq + 1), i];
  if (i + 1 >= args.length) die(`error: a value is required for '${name}' but none was supplied`);
  if (args[i + 1].startsWith('-')) {
    die(`error: unexpected argument '${args[i + 1]}' found\n\n  tip: to pass '${args[i + 1]}' as a value, use '-- ${args[i + 1]}'\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.`);
  }
  return [args[i + 1], i + 1];
}

function parseCount(s, blockSize, allowNegative = true) {
  let text = String(s).trim();
  let sign = 1;
  if (text.startsWith('-')) {
    if (!allowNegative) throw new Error('negative offset specified, but only positive offsets (counts) are accepted in this context');
    sign = -1;
    text = text.slice(1);
  } else if (text.startsWith('+')) {
    text = text.slice(1);
  }
  if (!text) throw new Error('invalid digit found in string');
  const m = text.match(/^(0x[0-9a-fA-F]+|\d+(?:\.\d+)?)([a-zA-Z]*)$/);
  if (!m) throw new Error('invalid digit found in string');
  let n = m[1].startsWith('0x') ? parseInt(m[1], 16) : Number(m[1]);
  const u = m[2].toLowerCase();
  const units = {
    '': 1, b: 1,
    kb: 1000, mb: 1000 ** 2, gb: 1000 ** 3, tb: 1000 ** 4,
    kib: 1024, mib: 1024 ** 2, gib: 1024 ** 3, tib: 1024 ** 4,
    k: 1000, m: 1000 ** 2, g: 1000 ** 3, t: 1000 ** 4,
    block: blockSize, blocks: blockSize
  };
  if (!(u in units)) throw new Error(`invalid unit '${m[2]}'`);
  return Math.trunc(sign * n * units[u]);
}

function parseArgs(argv) {
  let initialBlockSize = 512;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') break;
    const key = a.split('=')[0];
    if (key === '--block-size') {
      const v = a.includes('=') ? a.slice(a.indexOf('=') + 1) : argv[i + 1];
      if (v) {
        try { initialBlockSize = parseCount(v, initialBlockSize, false); } catch (_) {}
      }
    }
  }
  const o = {
    length: null, skip: 0, blockSize: 512, squeeze: true, color: 'always',
    border: 'unicode', chars: true, position: true, charTable: 'default',
    colorScheme: 'default', displayOffset: 0, panels: null, group: 1,
    endian: 'big', base: 'hexadecimal', terminalWidth: null, include: false,
    file: null, printColorTable: false, completion: null
  };
  o.blockSize = initialBlockSize;
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '--') {
      if (i + 1 < argv.length) o.file = argv[++i];
      if (i + 1 < argv.length) die(`error: unexpected argument '${argv[i + 1]}' found`);
      break;
    }
    if (a === '-h' || a === '--help') { process.stdout.write(HELP + '\n'); process.exit(0); }
    if (a === '-V' || a === '--version') { process.stdout.write(VERSION + '\n'); process.exit(0); }
    if (a === '-v' || a === '--no-squeezing') { o.squeeze = false; continue; }
    if (a === '-p' || a === '--plain') { o.chars = false; o.position = false; o.border = 'none'; o.color = 'never'; continue; }
    if (a === '--no-characters') { o.chars = false; continue; }
    if (a === '-C' || a === '--characters') { o.chars = true; continue; }
    if (a === '-P' || a === '--no-position') { o.position = false; continue; }
    if (a === '-i' || a === '--include') { o.include = true; continue; }
    if (a === '-e') { o.endian = 'little'; continue; }
    const long = a.split('=')[0];
    const needs = ['-n','--length','--bytes','-c','-l','-s','--skip','--block-size','--color','--border','--character-table','--color-scheme','-o','--display-offset','--panels','-g','--group-size','--groupsize','--endianness','-b','--base','--terminal-width','--completion'];
    if (needs.includes(long)) {
      const [v, ni] = takeValue(argv, i, long); i = ni;
      try {
        if (['-n','--length','--bytes','-c','-l'].includes(long)) o.length = parseCount(v, o.blockSize, false);
        else if (['-s','--skip'].includes(long)) o.skip = parseCount(v, o.blockSize, true);
        else if (long === '--block-size') o.blockSize = parseCount(v, o.blockSize, false);
        else if (long === '--color') o.color = v;
        else if (long === '--border') o.border = v;
        else if (long === '--character-table') o.charTable = v;
        else if (long === '--color-scheme') o.colorScheme = v;
        else if (['-o','--display-offset'].includes(long)) o.displayOffset = parseCount(v, o.blockSize, false);
        else if (long === '--panels') o.panels = v === 'auto' ? 'auto' : parseInt(v, 10);
        else if (['-g','--group-size','--groupsize'].includes(long)) o.group = parseInt(v, 10);
        else if (long === '--endianness') o.endian = v;
        else if (['-b','--base'].includes(long)) o.base = normalizeBase(v);
        else if (long === '--terminal-width') o.terminalWidth = parseInt(v, 10);
        else if (long === '--completion') o.completion = v;
      } catch (e) {
        die(`Error: failed to parse \`${long}\` arg "${v}" as byte count\n\nCaused by:\n    ${e.message}`);
      }
      continue;
    }
    if (a === '--print-color-table') { o.printColorTable = true; continue; }
    if (a.startsWith('-')) die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.`);
    if (o.file !== null) die(`error: unexpected argument '${a}' found`);
    o.file = a;
  }
  if (![1,2,4,8].includes(o.group)) die(`error: invalid value '${o.group}' for '--group-size <N>'`);
  return o;
}

function normalizeBase(v) {
  const x = String(v).toLowerCase();
  if (['hex','hexadecimal'].includes(x)) return 'hexadecimal';
  if (['dec','decimal'].includes(x)) return 'decimal';
  if (['oct','octal'].includes(x)) return 'octal';
  if (['bin','binary'].includes(x)) return 'binary';
  return x;
}

function readInput(o) {
  let buf;
  try {
    buf = o.file ? fs.readFileSync(o.file) : fs.readFileSync(0);
  } catch (e) {
    if (e.code === 'ENOENT') die('Error: No such file or directory (os error 2)');
    die(`Error: ${e.message.replace(/, open .*/, '')}`);
  }
  let start = o.skip < 0 ? Math.max(0, buf.length + o.skip) : Math.min(buf.length, o.skip);
  let end = o.length == null ? buf.length : Math.min(buf.length, start + o.length);
  o.baseOffset = start;
  return buf.subarray(start, end);
}

function byteWord(b, base) {
  if (base === 'decimal') return String(b).padStart(3, '0');
  if (base === 'octal') return b.toString(8).padStart(3, '0');
  if (base === 'binary') return b.toString(2).padStart(8, '0');
  return b.toString(16).padStart(2, '0');
}

function panelWidth(base, group) {
  const per = base === 'binary' ? 8 : base === 'hexadecimal' ? 2 : 3;
  return 1 + (8 / group) * (per * group + 1);
}

function formatPanel(bytes, base, group, endian) {
  const per = base === 'binary' ? 8 : base === 'hexadecimal' ? 2 : 3;
  const groups = [];
  for (let i = 0; i < 8; i += group) {
    const part = bytes.slice(i, i + group);
    if (part.length === 0) break;
    const arr = endian === 'little' && group > 1 ? part.slice().reverse() : part;
    groups.push(arr.map(b => byteWord(b, base)).join(''));
  }
  let s = ' ' + groups.join(' ');
  if (groups.length) s += ' ';
  return s.padEnd(panelWidth(base, group), ' ');
}

const cp437 = [
  'Ç','ü','é','â','ä','à','å','ç','ê','ë','è','ï','î','ì','Ä','Å','É','æ','Æ','ô','ö','ò','û','ù','ÿ','Ö','Ü','¢','£','¥','₧','ƒ',
  'á','í','ó','ú','ñ','Ñ','ª','º','¿','⌐','¬','½','¼','¡','«','»','░','▒','▓','│','┤','╡','╢','╖','╕','╣','║','╗','╝','╜','╛','┐',
  '└','┴','┬','├','─','┼','╞','╟','╚','╔','╩','╦','╠','═','╬','╧','╨','╤','╥','╙','╘','╒','╓','╫','╪','┘','┌','█','▄','▌','▐','▀',
  'α','ß','Γ','π','Σ','σ','µ','τ','Φ','Θ','Ω','δ','∞','φ','ε','∩','≡','±','≥','≤','⌠','⌡','÷','≈','°','∙','·','√','ⁿ','²','■',' '
];

function charFor(b, table) {
  if (table === 'ascii') return b >= 0x20 && b <= 0x7e ? String.fromCharCode(b) : '.';
  if (table === 'codepage-437') {
    if (b >= 0x20 && b <= 0x7e) return String.fromCharCode(b);
    return b >= 0x80 ? cp437[b - 0x80] || '.' : '.';
  }
  if (table === 'braille') {
    if (b >= 0x20 && b <= 0x7e) return String.fromCharCode(b);
    if (b === 0) return '⋄';
    if (b === 10) return '↵';
    return String.fromCharCode(0x2800 + b);
  }
  if (b === 0) return '⋄';
  if (b === 0x20) return ' ';
  if (b >= 0x21 && b <= 0x7e) return String.fromCharCode(b);
  if ([9,10,11,12,13].includes(b)) return '_';
  if (b < 0x80) return '•';
  return '×';
}

function formatChars(bytes, table) {
  let s = '';
  for (const b of bytes) s += charFor(b, table);
  return s.padEnd(8, ' ');
}

function choosePanels(o) {
  if (typeof o.panels === 'number' && o.panels > 0) return o.panels;
  const width = o.terminalWidth || process.stdout.columns || 80;
  const pWidth = panelWidth(o.base, o.group);
  let best = 1;
  for (let p = 1; p <= (o.panels === 'auto' ? 16 : 2); p++) {
    const colCount = (o.position ? 1 : 0) + p + (o.chars ? p : 0);
    const cols = (o.position ? 8 : 0) + p * pWidth + (o.chars ? p * 8 : 0) + colCount + 1;
    if (cols <= width) best = p;
  }
  return best;
}

function borderChars(style) {
  if (style === 'ascii') return {tl:'+', tr:'+', bl:'+', br:'+', h:'-', v:'|', tm:'+', bm:'+', sep:'|', mid:'|'};
  return {tl:'┌', tr:'┐', bl:'└', br:'┘', h:'─', v:'│', tm:'┬', bm:'┴', sep:'│', mid:'┊'};
}

function columns(o, panels, offsetWidth) {
  const cols = [];
  if (o.position) cols.push(offsetWidth);
  for (let i = 0; i < panels; i++) cols.push(panelWidth(o.base, o.group));
  if (o.chars) for (let i = 0; i < panels; i++) cols.push(8);
  return cols;
}

function renderBorder(o, panels, offsetWidth, bottom = false) {
  if (o.border === 'none') return '';
  const b = borderChars(o.border);
  const cols = columns(o, panels, offsetWidth);
  return (bottom ? b.bl : b.tl) + cols.map(w => b.h.repeat(w)).join(bottom ? b.bm : b.tm) + (bottom ? b.br : b.tr);
}

function renderRow(o, panels, offsetWidth, offset, chunk, star = false) {
  const pWidth = panelWidth(o.base, o.group);
  const c = o.border === 'none' ? null : borderChars(o.border);
  const hexPanels = [];
  const charPanels = [];
  for (let p = 0; p < panels; p++) {
    const part = chunk.slice(p * 8, p * 8 + 8);
    hexPanels.push(star ? ' '.repeat(pWidth) : formatPanel(Array.from(part), o.base, o.group, o.endian));
    if (o.chars) charPanels.push(star ? ' '.repeat(8) : formatChars(part, o.charTable));
  }
  const pos = star ? '*'.padEnd(offsetWidth, ' ') : offset.toString(16).padStart(offsetWidth, '0');
  if (o.border === 'none') {
    const parts = [];
    if (o.position) parts.push(pos);
    parts.push(...hexPanels);
    if (o.chars) parts.push(...charPanels);
    return ' ' + parts.join(' ');
  }
  let s = c.v;
  if (o.position) s += pos + c.sep;
  s += hexPanels.join(c.mid);
  if (o.chars) s += c.sep + charPanels.join(c.mid);
  return s + c.v;
}

function renderHex(buf, o) {
  const panels = choosePanels(o);
  const bytesPerLine = panels * 8;
  const offsetBase = (o.baseOffset || 0) + o.displayOffset;
  const offsetWidth = Math.max(8, (offsetBase + buf.length).toString(16).length);
  const out = [];
  const top = renderBorder(o, panels, offsetWidth, false);
  if (top) out.push(top);
  let prev = null, squeezed = false;
  for (let off = 0; off < buf.length; off += bytesPerLine) {
    const chunk = buf.subarray(off, Math.min(buf.length, off + bytesPerLine));
    const full = chunk.length === bytesPerLine;
    const same = full && prev && Buffer.compare(chunk, prev) === 0;
    if (o.squeeze && same) { squeezed = true; continue; }
    if (squeezed) { out.push(renderRow(o, panels, offsetWidth, 0, Buffer.alloc(0), true)); squeezed = false; }
    out.push(renderRow(o, panels, offsetWidth, offsetBase + off, chunk, false));
    if (full) prev = Buffer.from(chunk);
  }
  if (squeezed) {
    out.push(renderRow(o, panels, offsetWidth, 0, Buffer.alloc(0), true));
    out.push(renderRow(o, panels, offsetWidth, offsetBase + buf.length, Buffer.alloc(0), false));
  }
  const bot = renderBorder(o, panels, offsetWidth, true);
  if (bot) out.push(bot);
  return out.join('\n') + (out.length ? '\n' : '');
}

function includeOutput(buf, file) {
  let name = file ? path.basename(file).replace(/[^A-Za-z0-9]/g, '_') : 'stdin';
  if (!/^[A-Za-z_]/.test(name)) name = '_' + name;
  const parts = Array.from(buf, b => '0x' + b.toString(16).padStart(2, '0'));
  const lines = [`unsigned char ${name}[] = {`];
  for (let i = 0; i < parts.length; i += 12) lines.push('  ' + parts.slice(i, i + 12).join(', ') + (i + 12 < parts.length ? ',' : ''));
  lines.push('};');
  lines.push(`unsigned int ${name}_len = ${buf.length};`);
  return lines.join('\n') + '\n';
}

function colorTable() {
  return 'hexyl color reference:\n\n' +
    '\x1b[90m⋄ NULL bytes (0x00)\n\x1b[39m' +
    '\x1b[36ma ASCII printable characters (0x20 - 0x7E)\n\x1b[39m' +
    '\x1b[32m_ ASCII whitespace (0x09 - 0x0D, 0x20)\n\x1b[39m' +
    '\x1b[32m• ASCII control characters (except NULL and whitespace)\n\x1b[39m' +
    '\x1b[33m× Non-ASCII bytes (0x80 - 0xFF)\n\x1b[39m';
}

function completion(shell) {
  if (shell === 'bash') return '_hexyl() {\n    COMPREPLY=()\n}\ncomplete -F _hexyl -o bashdefault -o default hexyl\n';
  return '';
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  if (o.printColorTable) { process.stdout.write(colorTable()); return; }
  if (o.completion) { process.stdout.write(completion(o.completion)); return; }
  const buf = readInput(o);
  process.stdout.write(o.include ? includeOutput(buf, o.file) : renderHex(buf, o));
}

main();
