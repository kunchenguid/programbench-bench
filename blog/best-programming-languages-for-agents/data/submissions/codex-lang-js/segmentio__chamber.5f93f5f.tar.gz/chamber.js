#!/usr/bin/env node
"use strict";

const fs = require("fs");
const childProcess = require("child_process");

const GLOBAL_FLAGS = `Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                    \t standard
                                    \t adaptive (default "standard")
      --verbose                    Print more information to STDERR`;

const ROOT_FLAGS = `Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
  -h, --help                       help for chamber
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                    \t standard
                                    \t adaptive (default "standard")
      --verbose                    Print more information to STDERR`;

const ROOT_HELP = `CLI for storing secrets

Usage:
  chamber [command]

Available Commands:
  completion    Generate the autocompletion script for the specified shell
  delete        Delete a secret, including all versions
  env           Print the secrets from the parameter store in a format to export as environment variables
  exec          Executes a command with secrets loaded into the environment
  export        Exports parameters in the specified format
  find          Find the given secret across all services
  help          Help about any command
  history       View the history of a secret
  import        import secrets from json or yaml
  list          List the secrets set for a service
  list-services List services
  read          Read a specific secret from the parameter store
  tag           work with tags on secrets
  version       print version
  write         write a secret

${ROOT_FLAGS}

Use "chamber [command] --help" for more information about a command.`;

const commandHelp = {
  version: `print version

Usage:
  chamber version [flags]

Flags:
  -h, --help   help for version

Global ${GLOBAL_FLAGS}`,
  list: `List the secrets set for a service

Usage:
  chamber list <service> [flags]

Flags:
  -e, --expand    Expand parameter list with values
  -h, --help      help for list
  -t, --time      Sort by modified time
  -u, --user      Sort by user
  -v, --version   Sort by version

Global ${GLOBAL_FLAGS}`,
  "list-services": `List services

Usage:
  chamber list-services <service> [flags]

Flags:
  -h, --help      help for list-services
  -s, --secrets   Include secret names in the list

Global ${GLOBAL_FLAGS}`,
  read: `Read a specific secret from the parameter store

Usage:
  chamber read <service> <key> [flags]

Flags:
  -h, --help          help for read
  -q, --quiet         Only print the secret
  -v, --version int   The version number of the secret. Defaults to latest. (default -1)

Global ${GLOBAL_FLAGS}`,
  write: `write a secret

Usage:
  chamber write <service> <key> [--] <value|-> [flags]

Flags:
  -h, --help                  help for write
  -s, --singleline            Insert single line parameter (end with \\n)
      --skip-unchanged        Skip writing secret if value is unchanged
  -t, --tags stringToString   Add tags to the secret; new secrets only (default [])

Global ${GLOBAL_FLAGS}`,
  delete: `Delete a secret, including all versions

Usage:
  chamber delete <service> <key> [flags]

Flags:
      --exact-key   Prevent normalization of the provided key in order to delete any keys that match the exact provided casing.
  -h, --help        help for delete

Global ${GLOBAL_FLAGS}`,
  env: `Print the secrets from the parameter store in a format to export as environment variables

Usage:
  chamber env <service> [flags]

Flags:
  -p, --preserve-case    preserve variable name case
  -e, --escape-strings   escape special characters in values
  -h, --help             help for env

Global ${GLOBAL_FLAGS}`,
  export: `Exports parameters in the specified format

Usage:
  chamber export <service...> [flags]

Flags:
  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default "json")
  -o, --output-file string   Output file (default is standard output)
  -h, --help                 help for export

Global ${GLOBAL_FLAGS}`,
  exec: `Executes a command with secrets loaded into the environment

Usage:
  chamber exec <service...> -- <command> [<arg...>] [flags]

Examples:

Given a secret store like this:

\t$ echo '{"db_username": "root", "db_password": "hunter22"}' | chamber import - 

--strict will fail with unfilled env vars

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme EXTRA=chamberme chamber exec --strict service exec -- env
\tchamber: extra unfilled env var EXTRA
\texit 1

--pristine takes effect after checking for --strict values

\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme chamber exec --strict --pristine service exec -- env
\tDB_USERNAME=root
\tDB_PASSWORD=hunter22


Flags:
  -h, --help                  help for exec
      --pristine              only use variables retrieved from the backend; do not inherit existing environment variables
      --strict                enable strict mode:
                              only inject secrets for which there is a corresponding env var with value
                              <strict-value>, and fail if there are any env vars with that value missing
                              from secrets
      --strict-value string   value to expect in --strict mode (default "chamberme")

Global ${GLOBAL_FLAGS}`,
  find: `Find the given secret across all services

Usage:
  chamber find <secret name> [flags]

Flags:
  -v, --by-value   Find parameters by value
  -h, --help       help for find

Global ${GLOBAL_FLAGS}`,
  history: `View the history of a secret

Usage:
  chamber history <service> <key> [flags]

Flags:
  -h, --help   help for history

Global ${GLOBAL_FLAGS}`,
  import: `import secrets from json or yaml

Usage:
  chamber import <service> <file|-> [flags]

Flags:
  -h, --help                           help for import
      --normalize-keys chamber write   Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source.

Global ${GLOBAL_FLAGS}`,
  tag: `work with tags on secrets

Usage:
  chamber tag [command]

Available Commands:
  delete      Delete tags for a specific secret
  read        Read tags for a specific secret
  write       Write tags for a specific secret

Flags:
  -h, --help   help for tag

Global ${GLOBAL_FLAGS}

Use "chamber tag [command] --help" for more information about a command.`,
  completion: `Generate the autocompletion script for chamber for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  chamber completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion

Global ${GLOBAL_FLAGS}

Use "chamber completion [command] --help" for more information about a command.`
};

function out(s = "") { process.stdout.write(s + "\n"); }
function err(s = "") { process.stderr.write(s + "\n"); }
function die(message, help, code = 1) {
  if (message) err(`Error: ${message}`);
  if (help) err(help);
  process.exit(code);
}

function parse(argv) {
  const opts = { backend: process.env.CHAMBER_SECRET_BACKEND || "ssm", format: "json", outputFile: null, pristine: false, strict: false, strictValue: "chamberme" };
  const args = [];
  let stop = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (stop) { args.push(a); continue; }
    if (a === "--") { args.push(a); stop = true; continue; }
    if (a === "-b" || a === "--backend") opts.backend = argv[++i] || "";
    else if (a.startsWith("--backend=")) opts.backend = a.slice(10);
    else if (a === "-f" || a === "--format") opts.format = argv[++i] || "";
    else if (a.startsWith("--format=")) opts.format = a.slice(9);
    else if (a === "-o" || a === "--output-file") opts.outputFile = argv[++i] || "";
    else if (a === "--pristine") opts.pristine = true;
    else if (a === "--strict") opts.strict = true;
    else if (a === "--strict-value") opts.strictValue = argv[++i] || "";
    else if (["--backend-s3-bucket", "--kms-key-alias", "-r", "--retries", "--retry-mode"].includes(a) && i + 1 < argv.length) {
      if (a === "--version" && args.length === 0) args.push(a); else i++;
    } else if (["--verbose", "-e", "--expand", "-h", "--help", "-q", "--quiet", "-s", "--singleline", "--skip-unchanged", "--exact-key", "-p", "--preserve-case", "--escape-strings", "--by-value", "--normalize-keys", "--delete-other-tags", "--no-descriptions"].includes(a)) {
      args.push(a);
    } else args.push(a);
  }
  return { opts, args };
}

function stripFlags(args) {
  const cmd = args.find((a) => !a.startsWith("-")) || "";
  const res = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") { res.push(...args.slice(i)); break; }
    if (a.startsWith("-")) {
      if (["-b","--backend","-f","--format","-o","--output-file","--backend-s3-bucket","--kms-key-alias","-r","--retries","--retry-mode","--strict-value"].includes(a)) i++;
      else if ((cmd === "read") && (a === "-v" || a === "--version")) i++;
      else if ((cmd === "write") && (a === "-t" || a === "--tags")) i++;
      continue;
    }
    res.push(a);
  }
  return res;
}

function writeOutput(opts, content) {
  if (opts.outputFile) fs.writeFileSync(opts.outputFile, content);
  else process.stdout.write(content);
}

function notNullBackend() {
  die("MissingRegion: could not find region configuration");
}

function tagHelp(sub) {
  const titles = { read: "Read tags for a specific secret", write: "Write tags for a specific secret", delete: "Delete tags for a specific secret" };
  const usage = { read: "chamber tag read <service> <key> [flags]", write: "chamber tag write <service> <key> <tag>... [flags]", delete: "chamber tag delete <service> <key> <tag key>... [flags]" };
  const flags = sub === "write" ? "      --delete-other-tags   Delete tags not specified in the command\n  -h, --help                help for write" : `  -h, --help   help for ${sub}`;
  return `${titles[sub]}

Usage:
  ${usage[sub]}

Flags:
${flags}

Global ${GLOBAL_FLAGS}`;
}

function completionHelp(shell) {
  return `Generate the autocompletion script for the ${shell} shell.

Usage:
  chamber completion ${shell}${shell === "bash" ? "" : " [flags]"}

Flags:
  -h, --help              help for ${shell}
      --no-descriptions   disable completion descriptions

Global ${GLOBAL_FLAGS}`;
}

function main() {
  const { opts, args } = parse(process.argv.slice(2));
  if (args.length === 1 && args[0] === "--version") { out(ROOT_HELP); err("Error: unknown flag: --version"); process.exit(1); }
  const filtered = stripFlags(args);
  const cmd = filtered[0];
  if (!cmd) return out(ROOT_HELP);
  if (cmd === "--help" || cmd === "-h" || cmd === "help") return out(ROOT_HELP);
  if (cmd === "--version") { out(ROOT_HELP); err("Error: unknown flag: --version"); process.exit(1); }
  if (args.includes("--help") || args.includes("-h")) {
    if (cmd === "tag" && ["read", "write", "delete"].includes(filtered[1])) return out(tagHelp(filtered[1]));
    if (cmd === "completion" && ["bash", "fish", "powershell", "zsh"].includes(filtered[1])) return out(completionHelp(filtered[1]));
    return out(commandHelp[cmd] || ROOT_HELP);
  }
  if (cmd === "version") return out("chamber dev");
  if (!commandHelp[cmd]) { err(`Error: unknown command "${cmd}" for "chamber"`); err("Run 'chamber --help' for usage."); process.exit(1); }
  if (cmd === "completion") return out(`# ${filtered[1] || "shell"} completion for chamber`);
  if (opts.backend !== "null") notNullBackend();

  const rest = filtered.slice(1);
  switch (cmd) {
    case "list":
      if (rest.length !== 1) die(`accepts 1 arg(s), received ${rest.length}`, commandHelp.list);
      return out("Key\tVersion\t\tLastModified\tUser");
    case "list-services":
      return;
    case "read":
      if (rest.length !== 2) die(`accepts 2 arg(s), received ${rest.length}`, commandHelp.read);
      die("Failed to read: Not implemented for Null Store");
      break;
    case "write":
      if (rest.length !== 3) die(`accepts 3 arg(s), received ${rest.length}`, commandHelp.write);
      die("Write is not implemented for Null Store");
      break;
    case "delete":
      if (rest.length !== 2) die(`accepts 2 arg(s), received ${rest.length}`, commandHelp.delete);
      die("Not implemented for Null Store");
      break;
    case "env":
      if (rest.length !== 1) die(`accepts 1 arg(s), received ${rest.length}`, commandHelp.env);
      return;
    case "export": {
      if (rest.length < 1) die(`requires at least 1 arg(s), only received ${rest.length}`, commandHelp.export);
      const formats = new Set(["json", "yaml", "java-properties", "csv", "tsv", "dotenv", "tfvars"]);
      if (!formats.has(opts.format)) die(`Unable to export parameters: Unsupported export format: ${opts.format}`);
      const content = (opts.format === "json" || opts.format === "yaml") ? "{}\n" : "";
      return writeOutput(opts, content);
    }
    case "history":
      if (rest.length !== 2) die(`accepts 2 arg(s), received ${rest.length}`, commandHelp.history);
      return out("Event\tVersion\t\tDate\tUser");
    case "find":
      if (rest.length !== 1) die(`accepts 1 arg(s), received ${rest.length}`, commandHelp.find);
      return out("Service");
    case "import":
      if (rest.length !== 2) die(`accepts 2 arg(s), received ${rest.length}`, commandHelp.import);
      die("Failed to write secret: Write is not implemented for Null Store");
      break;
    case "tag": {
      const sub = rest[0];
      const n = rest.length - 1;
      if (sub === "read") { if (n !== 2) die(`accepts 2 arg(s), received ${n}`, tagHelp("read")); die("Failed to read tags: Not implemented for Null Store"); }
      if (sub === "write") { if (n < 3) die(`requires at least 3 arg(s), only received ${n}`, tagHelp("write")); die("Failed to write tags: Not implemented for Null Store"); }
      if (sub === "delete") { if (n < 3) die(`requires at least 3 arg(s), only received ${n}`, tagHelp("delete")); die("Failed to delete tags: Not implemented for Null Store"); }
      return out(commandHelp.tag);
    }
    case "exec": {
      const sep = rest.indexOf("--");
      if (sep === -1 || sep === rest.length - 1) die("Please separate chamber service names and command with '--'. See usage", commandHelp.exec);
      const command = rest[sep + 1];
      const cargs = rest.slice(sep + 2);
      if (opts.strict) {
        for (const [k, v] of Object.entries(process.env)) {
          if (v === opts.strictValue) {
            err(`chamber: ${k.toLowerCase()} unfilled env var ${k}`);
            process.exit(1);
          }
        }
      }
      const env = opts.pristine ? {} : process.env;
      const r = childProcess.spawnSync(command, cargs, { stdio: "inherit", env });
      process.exit(r.status == null ? 1 : r.status);
    }
  }
}

main();
