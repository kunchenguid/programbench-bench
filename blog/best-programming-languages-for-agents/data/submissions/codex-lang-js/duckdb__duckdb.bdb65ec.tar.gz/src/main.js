#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const VERSION = 'v0.0.1 (Unknown Version) 780a7396';
const HELP = `\x1b[1mUsage: \x1b[00m\x1b[32m./executable\x1b[00m\x1b[33m [OPTIONS] FILENAME [SQL]\n\n\x1b[00m\x1b[1mFILENAME\x1b[00m is the name of a DuckDB database. A new database is created\nif the file does not previously exist.\n\n\x1b[1mOPTIONS:\n\x1b[00m\x1b[32m  -ascii\x1b[00m                   set output mode to 'ascii'\n\x1b[32m  -bail\x1b[00m                    stop after hitting an error\n\x1b[32m  -batch\x1b[00m                   force batch I/O'\n\x1b[32m  -box\x1b[00m                     set output mode to 'box'\n\x1b[32m  -column\x1b[00m                  set output mode to 'column'\n\x1b[32m  -cmd\x1b[00m\x1b[33m COMMAND\x1b[00m             run "COMMAND" before reading stdin\n\x1b[32m  -csv\x1b[00m                     set output mode to 'csv'\n\x1b[32m  -c\x1b[00m\x1b[33m COMMAND\x1b[00m               run "COMMAND" and exit\n\x1b[32m  -echo\x1b[00m                    print commands before execution\n\x1b[32m  -f\x1b[00m\x1b[33m FILENAME\x1b[00m              read/process named file and exit\n\x1b[32m  -format\x1b[00m                  format SQL from stdin, writing result to stdout\n\x1b[32m  -format-file\x1b[00m\x1b[33m FILENAME\x1b[00m    format SQL in file, writing result to stdout\n\x1b[32m  -init\x1b[00m\x1b[33m FILENAME\x1b[00m           read/process named file\n\x1b[32m  -header\x1b[00m                  turn headers on\n\x1b[32m  -h\x1b[00m                       show help message\n\x1b[32m  -help\x1b[00m                    show help message\n\x1b[32m  -html\x1b[00m                    set output mode to HTML\n\x1b[32m  -interactive\x1b[00m             force interactive I/O\n\x1b[32m  -json\x1b[00m                    set output mode to 'json'\n\x1b[32m  -jsonlines\x1b[00m               set output mode to 'jsonlines'\n\x1b[32m  -line\x1b[00m                    set output mode to 'line'\n\x1b[32m  -list\x1b[00m                    set output mode to 'list'\n\x1b[32m  -markdown\x1b[00m                set output mode to 'markdown'\n\x1b[32m  -newline\x1b[00m\x1b[33m SEP\x1b[00m             set output row separator. Default: '\\n'\n\x1b[32m  -no-init\x1b[00m                 skip processing the init file\n\x1b[32m  -no-stdin\x1b[00m                exit after processing options instead of reading stdin\n\x1b[32m  -noheader\x1b[00m                turn headers off\n\x1b[32m  -nullvalue\x1b[00m\x1b[33m TEXT\x1b[00m          set text string for NULL values. Default 'NULL'\n\x1b[32m  -quote\x1b[00m                   set output mode to 'quote'\n\x1b[32m  -readonly\x1b[00m                open the database read-only\n\x1b[32m  -s\x1b[00m\x1b[33m COMMAND\x1b[00m               run "COMMAND" and exit\n\x1b[32m  -safe\x1b[00m                    enable safe-mode\n\x1b[32m  -separator\x1b[00m\x1b[33m SEP\x1b[00m           set output column separator. Default: '|'\n\x1b[32m  -storage-version\x1b[00m\x1b[33m VER\x1b[00m     database storage compatibility version to use. Default: 'v0.10.0'\n\x1b[32m  -table\x1b[00m                   set output mode to 'table'\n\x1b[32m  -ui\x1b[00m                      launches a web interface using the ui extension (configurable with .ui_command)\n\x1b[32m  -unredacted\x1b[00m              allow printing unredacted secrets\n\x1b[32m  -unsigned\x1b[00m                allow loading of unsigned extensions\n\x1b[32m  -version\x1b[00m                 show DuckDB version`;
const DOT_HELP = `.about                                  Show information about DuckDB\n.bail on|off                             Stop after hitting an error.  Default OFF\n.databases                               List names and files of attached databases\n.dump ?TABLE?                            Render database content as SQL\n.echo on|off                             Turn command echo on or off\n.exit ?CODE?                             Exit this program with return-code CODE\n.headers on|off                          Turn display of headers on or off\n.help ?-all? ?PATTERN?                   Show help text for PATTERN\n.import FILE TABLE                       Import data from FILE into TABLE\n.mode MODE ?TABLE?                       Set output mode\n.nullvalue STRING                        Use STRING in place of NULL values\n.open ?OPTIONS? ?FILE?                   Close existing database and reopen FILE\n.once ?FILE?                             Output for the next SQL command only to FILE\n.output ?FILE?                           Send output to FILE or stdout if FILE is omitted\n.print STRING...                         Print literal STRING\n.quit                                    Exit this program\n.read FILE                               Read input from FILE\n.schema ?PATTERN?                        Show the CREATE statements matching PATTERN\n.shell CMD ARGS...                       Run CMD ARGS... in a system shell\n.show                                    Show the current values for various settings\n.tables ?TABLE?                          List names of tables matching LIKE pattern TABLE\n.timer on|off                            Turn SQL timer on or off\n.version                                 Show the version\n.width NUM1 NUM2 ...                     Set minimum column widths for columnar output\n\nRun .help --all for extended information\nRun .help shortcuts for keyboard shortcuts`;

class DB {
  constructor(file) { this.file = file || ':memory:'; this.tables = {}; this.load(); }
  load() {
    if (!this.file || this.file === ':memory:' || !fs.existsSync(this.file)) return;
    try { const x = JSON.parse(fs.readFileSync(this.file, 'utf8')); if (x && x.tables) this.tables = x.tables; } catch (_) {}
  }
  save() {
    if (!this.file || this.file === ':memory:') return;
    fs.writeFileSync(this.file, JSON.stringify({ duckshim: true, tables: this.tables }, null, 2));
  }
}

const state = { mode: 'box', headers: true, nullvalue: 'NULL', colsep: '|', rowsep: '\n', echo: false, bail: false, db: null, out: null, once: null, exitCode: 0 };
function out(s='') {
  if (state.once) { fs.appendFileSync(state.once, s + (s.endsWith('\n') ? '' : '\n')); state.once = null; return; }
  if (state.out) fs.appendFileSync(state.out, s + (s.endsWith('\n') ? '' : '\n')); else process.stdout.write(s + (s.endsWith('\n') ? '' : '\n'));
}
const stripAnsi = s => s.replace(/\x1b\[[0-9;]*m/g, '');
const unquote = s => {
  s = String(s).trim();
  if ((s[0] === "'" && s.at(-1) === "'") || (s[0] === '"' && s.at(-1) === '"')) return s.slice(1, -1).replace(/''/g, "'").replace(/\\"/g, '"');
  return s;
};
function splitTop(s, sep=',') {
  const a=[]; let q=null,d=0,start=0;
  for (let i=0;i<s.length;i++) { const c=s[i];
    if (q) { if (c===q && s[i+1]===q) i++; else if (c===q) q=null; continue; }
    if (c==="'"||c==='"') { q=c; continue; }
    if (c==='(') d++; else if (c===')') d--; else if (c===sep && d===0) { a.push(s.slice(start,i).trim()); start=i+1; }
  }
  a.push(s.slice(start).trim()); return a.filter(x=>x.length);
}
function splitStatements(s) {
  const a=[]; let q=null,start=0;
  for (let i=0;i<s.length;i++) { const c=s[i];
    if (q) { if (c===q && s[i+1]===q) i++; else if (c===q) q=null; continue; }
    if (c==="'"||c==='"') q=c; else if (c===';') { a.push(s.slice(start,i).trim()); start=i+1; }
  }
  const rest=s.slice(start).trim(); if (rest) a.push(rest); return a;
}
function tokenizeExpr(expr) {
  const toks=[]; let i=0;
  while (i<expr.length) {
    let c=expr[i]; if (/\s/.test(c)) { i++; continue; }
    if (c==="'"||c==='"') { const q=c; let j=++i, val=''; while (j<expr.length) { if (expr[j]===q) { if (expr[j+1]===q) { val+=q; j+=2; } else break; } else val+=expr[j++]; } toks.push({t:'str',v:val}); i=j+1; continue; }
    const two=expr.slice(i,i+2); if (['<=','>=','<>','!=','||'].includes(two)) { toks.push({t:'op',v:two}); i+=2; continue; }
    if ('()+-*/%,=<>'.includes(c)) { toks.push({t:c,v:c}); i++; continue; }
    const m=expr.slice(i).match(/^[A-Za-z_][A-Za-z0-9_.$]*|^\d+(?:\.\d+)?/); if (m) { const v=m[0]; toks.push(/^\d/.test(v)?{t:'num',v:Number(v)}:{t:'id',v}); i+=v.length; continue; }
    i++;
  }
  return toks;
}
function evalExpr(expr, row={}) {
  const toks=tokenizeExpr(expr); let p=0;
  function peek(){return toks[p];} function eat(v){if (peek() && (peek().v?.toLowerCase?.()===String(v).toLowerCase() || peek().t===v)) return toks[p++];}
  function primary() {
    let x=peek(); if (!x) return null;
    if (eat('(')) { const v=cmp(); eat(')'); return v; }
    if (eat('-')) return -Number(primary()||0);
    x=toks[p++];
    if (x.t==='num'||x.t==='str') return x.v;
    if (x.t==='id') {
      const name=x.v, low=name.toLowerCase();
      if (eat('(')) {
        const args=[]; if (!eat(')')) { do { args.push(cmp()); } while (eat(',')); eat(')'); }
        if (low==='upper') return String(args[0]??'').toUpperCase();
        if (low==='lower') return String(args[0]??'').toLowerCase();
        if (low==='length'||low==='len') return String(args[0]??'').length;
        if (low==='abs') return Math.abs(Number(args[0]||0));
        if (low==='round') return Math.round(Number(args[0]||0));
        if (low==='coalesce') return args.find(v=>v!==null&&v!==undefined) ?? null;
        if (low==='concat') return args.map(v=>v??'').join('');
        if (low==='version') return VERSION.split(' ')[0];
        if (low==='typeof') return infer(args[0]).toUpperCase();
        return null;
      }
      if (low==='null') return null; if (low==='true') return true; if (low==='false') return false;
      if (low==='current_date') return new Date().toISOString().slice(0,10);
      if (Object.prototype.hasOwnProperty.call(row, name)) return row[name];
      const base=name.split('.').pop(); if (Object.prototype.hasOwnProperty.call(row, base)) return row[base];
      return null;
    }
    return null;
  }
  function mul(){let v=primary(); for(;;){if(eat('*'))v=Number(v)*Number(primary()); else if(eat('/'))v=Number(v)/Number(primary()); else if(eat('%'))v=Number(v)%Number(primary()); else return v;}}
  function add(){let v=mul(); for(;;){if(eat('+'))v=(typeof v==='string'?String(v):Number(v))+mul(); else if(eat('-'))v=Number(v)-Number(mul()); else if(eat('||'))v=String(v??'')+String(mul()??''); else return v;}}
  function cmp(){let v=add(); for(;;){let op=peek()?.v?.toLowerCase(); if(!['=','<','>','<=','>=','<>','!=','and','or','like'].includes(op)) return v; p++; let r=add(); if(op==='=')v=v==r; else if(op==='!='||op==='<>')v=v!=r; else if(op==='<')v=v<r; else if(op==='>')v=v>r; else if(op==='<=')v=v<=r; else if(op==='>=')v=v>=r; else if(op==='and')v=Boolean(v)&&Boolean(r); else if(op==='or')v=Boolean(v)||Boolean(r); else if(op==='like')v=new RegExp('^'+String(r).replace(/[%_]/g,m=>m==='%'?'.*':'.')+'$','i').test(String(v));}}
  return cmp();
}
function infer(v){ if(v===null||v===undefined)return 'NULL'; if(typeof v==='number')return Number.isInteger(v)?'int32':'double'; if(typeof v==='boolean')return 'boolean'; return 'varchar'; }
function parseCSV(file) {
  const text=fs.readFileSync(file,'utf8').replace(/\r\n/g,'\n').replace(/\r/g,'\n'); const rows=[]; let row=[],cell='',q=false;
  for(let i=0;i<text.length;i++){const c=text[i]; if(q){ if(c==='"'&&text[i+1]==='"'){cell+='"';i++;} else if(c==='"')q=false; else cell+=c; } else if(c==='"')q=true; else if(c===','){row.push(cell);cell='';} else if(c==='\n'){row.push(cell); if(row.some(x=>x!=='')) rows.push(row); row=[]; cell='';} else cell+=c;}
  if(cell||row.length){row.push(cell);rows.push(row);} const cols=rows.shift()||[]; return {cols, rows: rows.map(r=>Object.fromEntries(cols.map((c,i)=>[c, cast(r[i]??'')]))), types: cols.map(()=> 'varchar')};
}
function cast(v){ if(v===null||v===undefined)return null; if(/^null$/i.test(v))return null; if(/^true$/i.test(v))return true; if(/^false$/i.test(v))return false; if(String(v).trim()!=='' && !isNaN(Number(v)))return Number(v); return v; }
function executeSQL(sql) {
  sql = sql.trim().replace(/;$/,''); if (!sql) return null;
  let m;
  if ((m=sql.match(/^create\s+(?:or\s+replace\s+)?table\s+([A-Za-z_][\w]*)\s*\(([\s\S]*)\)$/i))) {
    const name=m[1], defs=splitTop(m[2]); state.db.tables[name]={cols:defs.map(d=>d.trim().split(/\s+/)[0].replace(/["`]/g,'')), types:defs.map(d=>d.trim().split(/\s+/).slice(1).join(' ')||'VARCHAR'), rows:[], schema:`CREATE TABLE ${name}(${defs.join(', ')});`}; state.db.save(); return null;
  }
  if ((m=sql.match(/^drop\s+table\s+(?:if\s+exists\s+)?([A-Za-z_][\w]*)/i))) { delete state.db.tables[m[1]]; state.db.save(); return null; }
  if ((m=sql.match(/^insert\s+into\s+([A-Za-z_][\w]*)(?:\s*\(([^)]*)\))?\s+values\s*([\s\S]+)$/i))) {
    const t=state.db.tables[m[1]]; if(!t) throw Error(`Catalog Error: Table with name ${m[1]} does not exist!`);
    const cols=m[2]?splitTop(m[2]).map(x=>x.replace(/["`]/g,'')):t.cols; const vals=m[3]; const groups=[]; let d=0,start=-1,q=null;
    for(let i=0;i<vals.length;i++){const c=vals[i]; if(q){ if(c===q&&vals[i+1]===q)i++; else if(c===q)q=null; continue;} if(c==="'"||c==='"')q=c; else if(c==='('){if(d++===0)start=i+1;} else if(c===')'&&--d===0)groups.push(vals.slice(start,i));}
    for(const g of groups){const r={}; t.cols.forEach(c=>r[c]=null); splitTop(g).forEach((e,i)=>r[cols[i]]=evalExpr(e,r)); t.rows.push(r);} state.db.save(); return null;
  }
  if ((m=sql.match(/^delete\s+from\s+([A-Za-z_][\w]*)(?:\s+where\s+([\s\S]+))?$/i))) { const t=state.db.tables[m[1]]; if(!t)throw Error(`Catalog Error: Table with name ${m[1]} does not exist!`); t.rows=t.rows.filter(r=>m[2]?!evalExpr(m[2],r):false); state.db.save(); return null; }
  if (/^show\s+tables/i.test(sql)) return {cols:['name'], types:['varchar'], rows:Object.keys(state.db.tables).map(name=>({name}))};
  if (/^pragma\s+version/i.test(sql)) return {cols:['library_version','source_id'], types:['varchar','varchar'], rows:[{library_version:VERSION.split(' ')[0],source_id:'780a7396'}]};
  if (/^select\b/i.test(sql) || /^with\b/i.test(sql)) return selectSQL(sql);
  if ((m=sql.match(/^describe\s+([A-Za-z_][\w]*)/i))) { const t=state.db.tables[m[1]]; if(!t)throw Error(`Catalog Error: Table with name ${m[1]} does not exist!`); return {cols:['column_name','column_type','null','key','default','extra'], types:['varchar','varchar','varchar','varchar','varchar','varchar'], rows:t.cols.map((c,i)=>({column_name:c,column_type:t.types[i]||'VARCHAR',null:'YES',key:null,default:null,extra:null}))}; }
  throw Error(`Parser Error: syntax error at or near "${sql.split(/\s+/)[0]}"`);
}
function selectSQL(sql) {
  let s=sql.replace(/^select\s+/i,''); const parts={};
  for (const key of [' limit ',' order by ',' where ']) { const idx=s.toLowerCase().lastIndexOf(key); if(idx>=0){parts[key.trim()]=s.slice(idx+key.length).trim(); s=s.slice(0,idx).trim();} }
  let sel=s, from=null; const idx=s.toLowerCase().indexOf(' from '); if(idx>=0){sel=s.slice(0,idx).trim(); from=s.slice(idx+6).trim();}
  let sourceRows=[{}], sourceCols=[], sourceTypes=[];
  if(from){ let name=from.split(/\s+/)[0]; name=unquote(name); let tab, rm;
    if ((rm=name.match(/^(?:range|generate_series)\((\d+)(?:\s*,\s*(\d+))?\)$/i))) { const a=Number(rm[1]), b=rm[2]===undefined?null:Number(rm[2]); const start=b===null?0:a, end=b===null?a:b; tab={cols:['range'],types:['BIGINT'],rows:Array.from({length:Math.max(0,end-start)},(_,i)=>({range:start+i}))}; }
    else if (fs.existsSync(name) && /\.csv$/i.test(name)) tab=parseCSV(name); else tab=state.db.tables[name];
    if(!tab) throw Error(`Catalog Error: Table with name ${name} does not exist!`);
    sourceRows=tab.rows.map(r=>({...r})); sourceCols=tab.cols; sourceTypes=tab.types || sourceCols.map(c=>infer(sourceRows[0]?.[c]));
  }
  if(parts.where) sourceRows=sourceRows.filter(r=>!!evalExpr(parts.where,r));
  const items=sel==='*'?sourceCols.map(c=>({expr:c, alias:c})):splitTop(sel).map((it,i)=>{let mm=it.match(/^(.*?)(?:\s+as\s+|\s+)([A-Za-z_][\w]*)$/i); if(mm && !/[+\-*\/<>=(),]/.test(mm[2])) return {expr:mm[1].trim(), alias:mm[2]}; return {expr:it, alias:it.replace(/^['"]|['"]$/g,'')};});
  const agg = items.some(x=>/^(count|sum|avg|min|max)\s*\(/i.test(x.expr));
  let rows;
  if(agg){const r={}; for(const it of items){const mm=it.expr.match(/^(count|sum|avg|min|max)\s*\((.*?)\)$/i); if(!mm){r[it.alias]=evalExpr(it.expr, sourceRows[0]||{}); continue;} const fn=mm[1].toLowerCase(), ex=mm[2].trim(); const vals=ex==='*'?sourceRows:sourceRows.map(row=>evalExpr(ex,row)).filter(v=>v!=null); if(fn==='count')r[it.alias]=ex==='*'?sourceRows.length:vals.length; if(fn==='sum')r[it.alias]=vals.reduce((a,b)=>a+Number(b),0); if(fn==='avg')r[it.alias]=vals.reduce((a,b)=>a+Number(b),0)/(vals.length||1); if(fn==='min')r[it.alias]=vals.reduce((a,b)=>a<b?a:b,vals[0]); if(fn==='max')r[it.alias]=vals.reduce((a,b)=>a>b?a:b,vals[0]);} rows=[r];}
  else rows=sourceRows.map(row=>Object.fromEntries(items.map(it=>[it.alias, evalExpr(it.expr,row)])));
  if(parts['order by']){const k=parts['order by'].split(/\s+/)[0]; rows.sort((a,b)=>(a[k]??0)>(b[k]??0)?1:-1);}
  if(parts.limit) rows=rows.slice(0, Number(parts.limit.match(/\d+/)?.[0]||rows.length));
  const cols=items.map(x=>x.alias); return {cols, types:cols.map(c=>infer(rows[0]?.[c])), rows};
}
function cell(v, quote=false) { if(v===null||v===undefined)return state.nullvalue; if(quote&&typeof v==='string')return `'${v.replace(/'/g,"''")}'`; return String(v); }
function csvCell(v){ if(v===null||v===undefined)return state.nullvalue; const s=String(v); return /[",\n]/.test(s)?`"${s.replace(/"/g,'""')}"`:s; }
function widths(cols, rows, types=null){return cols.map((c,i)=>Math.max(String(c).length, types?String(types[i]||'').length:0, ...rows.map(r=>cell(r[c]).length)));}
function render(res) {
  if(!res) return; const cols=res.cols, rows=res.rows, w=widths(cols,rows,state.mode==='box' ? res.types : null); const lines=[];
  if(state.mode==='json'){out(JSON.stringify(rows));return;} if(state.mode==='jsonlines'){out(rows.map(r=>JSON.stringify(r)).join('\n'));return;}
  if(state.mode==='csv'){ if(state.headers)lines.push(cols.map(csvCell).join(',')); for(const r of rows)lines.push(cols.map(c=>csvCell(r[c])).join(',')); out(lines.join(state.rowsep)); return; }
  if(state.mode==='list'||state.mode==='quote'){ if(state.headers)lines.push(cols.map(c=>state.mode==='quote'?`'${c}'`:c).join(state.colsep)); for(const r of rows)lines.push(cols.map(c=>cell(r[c],state.mode==='quote')).join(state.colsep)); out(lines.join(state.rowsep)); return; }
  if(state.mode==='line'){ for(const r of rows) for(const c of cols) lines.push(`${c.padStart(5)} = ${cell(r[c])}`); out(lines.join('\n')); return; }
  if(state.mode==='html'){ if(state.headers)lines.push('<tr>'+cols.map(c=>`<th>${c}</th>`).join('\n')+'</tr>'); for(const r of rows)lines.push('<tr>'+cols.map(c=>`<td>${cell(r[c])}</td>`).join('\n')+'</tr>'); out(lines.join('\n')); return; }
  if(state.mode==='markdown'){lines.push('| '+cols.map((c,i)=>String(c).padStart(w[i])).join(' | ')+' |'); lines.push('|'+w.map(x=>'-'.repeat(Math.max(2,x))+(x?':':'')).join('|')+'|'); for(const r of rows)lines.push('| '+cols.map((c,i)=>cell(r[c]).padStart(w[i])).join(' | ')+' |'); out(lines.join('\n')); return;}
  if(state.mode==='ascii'){out([...(state.headers?cols:[]),...rows.flatMap(r=>cols.map(c=>cell(r[c])))].join('\n')); return;}
  if(state.mode==='column'){ if(state.headers){lines.push(cols.map((c,i)=>String(c).padEnd(w[i])).join('  ')); lines.push(w.map(x=>'-'.repeat(x)).join('  '));} for(const r of rows)lines.push(cols.map((c,i)=>cell(r[c]).padEnd(w[i])).join('  ')); out(lines.join('\n')); return;}
  const table = state.mode==='table';
  const tl=table?'+':"┌", tr=table?'+':"┐", bl=table?'+':"└", br=table?'+':"┘", h=table?'-':'─', v=table?'|':'│', tm=table?'+':'┬', mm=table?'+':'┼', bm=table?'+':'┴', lm=table?'+':'├', rm=table?'+':'┤';
  const border=(l,m,r)=>l+w.map(x=>h.repeat(x+2)).join(m)+r; lines.push(border(tl,tm,tr));
  lines.push(v+cols.map((c,i)=>' '+String(c).padStart(w[i])+' ').join(v)+v);
  if(state.mode==='box'){lines.push(v+res.types.map((t,i)=>' '+String(t||'').padStart(w[i])+' ').join(v)+v);}
  lines.push(border(lm,mm,rm)); for(const r of rows)lines.push(v+cols.map((c,i)=>' '+cell(r[c]).padStart(w[i])+' ').join(v)+v); lines.push(border(bl,bm,br)); out(lines.join('\n'));
}
function dot(line) {
  const [cmd,...rest]=line.trim().split(/\s+/); const arg=rest.join(' ');
  if(['.quit','.exit'].includes(cmd)){process.exit(Number(rest[0]||0));}
  if(cmd==='.help'){out(DOT_HELP);return;} if(cmd==='.version'){out(VERSION);return;} if(cmd==='.about'){out('DuckDB '+VERSION);return;}
  if(cmd==='.mode'){ if(rest[0]) state.mode=rest[0].replace('duckbox','box'); return; } if(cmd==='.headers'||cmd==='.header') {state.headers=/^on|yes|1$/i.test(rest[0]||'on');return;}
  if(cmd==='.nullvalue'){state.nullvalue=arg;return;} if(cmd==='.separator'){state.colsep=rest[0]??state.colsep; state.rowsep=rest[1]??state.rowsep; return;}
  if(cmd==='.tables'){out(Object.keys(state.db.tables).join(' '));return;} if(cmd==='.schema'){out(Object.entries(state.db.tables).map(([n,t])=>t.schema||`CREATE TABLE ${n}(${t.cols.join(', ')});`).join('\n'));return;}
  if(cmd==='.databases'){render({cols:['database_name','database_file'],types:['varchar','varchar'],rows:[{database_name:'memory',database_file:state.db.file===':memory:'?null:path.resolve(state.db.file)}]});return;}
  if(cmd==='.show'){out(`        echo: ${state.echo?'on':'off'}\n     headers: ${state.headers?'on':'off'}\n        mode: ${state.mode}\n   nullvalue: "${state.nullvalue}"\n   separator: "${state.colsep}"`);return;}
  if(cmd==='.print'){out(arg);return;} if(cmd==='.read'){runInput(fs.readFileSync(unquote(arg),'utf8'));return;} if(cmd==='.output'){state.out=arg?unquote(arg):null;return;} if(cmd==='.once'){state.once=unquote(arg);return;}
  if(cmd==='.open'){state.db=new DB(unquote(rest.at(-1)||':memory:'));return;} if(cmd==='.shell'||cmd==='.system'){try{out(cp.execSync(arg,{encoding:'utf8'}).replace(/\n$/,''));}catch(e){process.stderr.write(e.stderr||String(e));}return;}
  throw Error(`Error: unknown command or invalid arguments:  "${cmd}". Enter ".help" for help`);
}
function runOne(stmt){ if(!stmt)return; if(state.echo) out(stmt); if(stmt.trim().startsWith('.')) dot(stmt.trim()); else render(executeSQL(stmt)); }
function runInput(input) {
  let buf=''; for(const line of input.split(/\n/)){ const t=line.trim(); if(!buf && t.startsWith('.')){try{dot(t);}catch(e){process.stderr.write(e.message+'\n'); if(state.bail) return false;} continue;} buf += (buf?'\n':'') + line; if(t.endsWith(';')){ for(const st of splitStatements(buf)) try{runOne(st);}catch(e){process.stderr.write(e.message+'\n'); state.exitCode=1; if(state.bail)return false;} buf='';}}
  if(buf.trim()) for(const st of splitStatements(buf)) try{runOne(st);}catch(e){process.stderr.write(e.message+'\n'); state.exitCode=1; if(state.bail)return false;} return true;
}
function formatSQL(s){return splitStatements(s).map(x=>x.replace(/\s+/g,' ').trim()+';').join('\n');}
function main(argv) {
  let dbfile=null, sqls=[], readStdin=true, init=[];
  for(let i=0;i<argv.length;i++){const a=argv[i];
    if(['-h','-help','--help'].includes(a)){console.log(HELP);return 0;} if(a==='-version'){console.log(VERSION);return 0;}
    if(a==='-format'){process.stdout.write(formatSQL(fs.readFileSync(0,'utf8'))+'\n');return 0;} if(a==='-format-file'){process.stdout.write(formatSQL(fs.readFileSync(argv[++i],'utf8'))+'\n');return 0;}
    if(['-csv','-list','-column','-line','-table','-box','-ascii','-markdown','-json','-jsonlines','-quote','-html'].includes(a)){state.mode=a.slice(1);continue;}
    if(a==='-header'){state.headers=true;continue;} if(a==='-noheader'){state.headers=false;continue;} if(a==='-separator'){state.colsep=argv[++i];continue;} if(a==='-newline'){state.rowsep=argv[++i];continue;} if(a==='-nullvalue'){state.nullvalue=argv[++i];continue;}
    if(a==='-echo'){state.echo=true;continue;} if(a==='-bail'){state.bail=true;continue;} if(a==='-no-stdin'){readStdin=false;continue;} if(a==='-cmd'){init.push(argv[++i]);continue;} if(a==='-init'){init.push(fs.readFileSync(argv[++i],'utf8'));continue;}
    if(['-c','-s'].includes(a)){sqls.push(argv[++i]); readStdin=false;continue;} if(a==='-f'){sqls.push(fs.readFileSync(argv[++i],'utf8')); readStdin=false;continue;}
    if(a.startsWith('-')) continue; if(!dbfile) dbfile=a; else {sqls.push(a); readStdin=false;}
  }
  state.db = new DB(dbfile || ':memory:');
  for(const x of init) runInput(x); for(const x of sqls) runInput(x);
  if(readStdin && !process.stdin.isTTY) runInput(fs.readFileSync(0,'utf8'));
  return state.exitCode;
}
process.exitCode = main(process.argv.slice(2));
