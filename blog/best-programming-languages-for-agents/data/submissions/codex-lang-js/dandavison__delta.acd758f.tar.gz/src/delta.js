#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const ESC = '\x1b[';
const RESET = `${ESC}0m`;
const BLUE = `${ESC}34m`;
const RED = `${ESC}31m`;
const GREEN = `${ESC}32m`;
const BOLD = `${ESC}1m`;
const UNDER = `${ESC}4m`;
const YELLOW = `${ESC}33m`;
const WHITE = `${ESC}38;5;231m`;
const MINUS_BG = `${ESC}48;5;52m`;
const PLUS_BG = `${ESC}48;5;22m`;

const VALUE_OPTIONS = new Set([
  '--blame-code-style','--blame-format','--blame-palette','--blame-separator-format',
  '--blame-separator-style','--blame-timestamp-format','--blame-timestamp-output-format',
  '--config','--commit-decoration-style','--commit-regex','--commit-style',
  '--default-language','--detect-dark-light','--diff-args','-@','--diff-stat-align-width',
  '--features','--file-added-label','--file-copied-label','--file-decoration-style',
  '--file-modified-label','--file-removed-label','--file-renamed-label','--file-style',
  '--file-transformation','--generate-completion','--grep-context-line-style',
  '--grep-file-style','--grep-header-decoration-style','--grep-header-file-style',
  '--grep-line-number-style','--grep-output-type','--grep-match-line-style',
  '--grep-match-word-style','--grep-separator-symbol','--hunk-header-decoration-style',
  '--hunk-header-file-style','--hunk-header-line-number-style','--hunk-header-style',
  '--hunk-label','--hyperlinks-commit-link-format','--hyperlinks-file-link-format',
  '--inline-hint-style','--inspect-raw-lines','--line-buffer-size','--line-fill-method',
  '--line-numbers-left-format','--line-numbers-left-style','--line-numbers-minus-style',
  '--line-numbers-plus-style','--line-numbers-right-format','--line-numbers-right-style',
  '--line-numbers-zero-style','--map-styles','--max-line-distance','--max-line-length',
  '--merge-conflict-begin-symbol','--merge-conflict-end-symbol',
  '--merge-conflict-ours-diff-header-decoration-style','--merge-conflict-ours-diff-header-style',
  '--merge-conflict-theirs-diff-header-decoration-style','--merge-conflict-theirs-diff-header-style',
  '--minus-empty-line-marker-style','--minus-emph-style','--minus-non-emph-style',
  '--minus-style','--navigate-regex','--pager','--paging','--plus-emph-style',
  '--plus-empty-line-marker-style','--plus-non-emph-style','--plus-style',
  '--right-arrow','--syntax-theme','--tabs','--true-color','--whitespace-error-style',
  '--width','--word-diff-regex','--wrap-left-symbol','--wrap-max-lines',
  '--wrap-right-percent','--wrap-right-prefix-symbol','--wrap-right-symbol','--zero-style'
]);

const FLAG_OPTIONS = new Set([
  '-n','-s','-w','-h','-V','--color-only','--dark','--diff-highlight',
  '--diff-so-fancy','--help','--hyperlinks','--keep-plus-minus-markers',
  '--light','--line-numbers','--list-languages','--list-syntax-themes',
  '--navigate','--no-gitconfig','--parse-ansi','--raw','--relative-paths',
  '--show-colors','--show-config','--show-syntax-themes','--show-themes',
  '--side-by-side','--24-bit-color','--version'
]);

function hasColor() {
  return process.env.NO_COLOR === undefined;
}

function c(s, code) {
  return hasColor() ? `${code}${s}${RESET}` : s;
}

function readStdin() {
  try {
    return fs.readFileSync(0, 'utf8');
  } catch (_) {
    return '';
  }
}

function print(s = '') {
  process.stdout.write(s.endsWith('\n') || s === '' ? s : s + '\n');
}

function usageError(arg) {
  const bin = process.env.DELTA_BIN_NAME || path.basename(process.argv[1] || 'delta');
  process.stderr.write(`${BOLD}${RED}error:${RESET} unexpected argument '${YELLOW}${arg}${RESET}' found\n\n`);
  process.stderr.write(`  ${GREEN}tip:${RESET} to pass '${YELLOW}${arg}${RESET}' as a value, use '${GREEN}-- ${arg}${RESET}'\n\n`);
  process.stderr.write(`${BOLD}${UNDER}Usage:${RESET} ${BOLD}${bin}${RESET} [OPTIONS] [MINUS_FILE] [PLUS_FILE]\n\n`);
  process.stderr.write(`For more information, try '${BOLD}--help${RESET}'.\n`);
  process.exit(2);
}

function parseArgs(argv) {
  const opts = {};
  const files = [];
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '--') {
      files.push(...argv.slice(i + 1));
      break;
    }
    if (a.startsWith('--') && a.includes('=')) {
      const [k, ...rest] = a.split('=');
      if (!VALUE_OPTIONS.has(k) && !FLAG_OPTIONS.has(k)) usageError(k);
      opts[k] = rest.join('=');
      continue;
    }
    if (VALUE_OPTIONS.has(a)) {
      opts[a] = argv[++i] ?? '';
      continue;
    }
    if (FLAG_OPTIONS.has(a)) {
      opts[a] = true;
      continue;
    }
    if (a.startsWith('-') && a !== '-') usageError(a);
    files.push(a);
  }
  if (files.length > 2) usageError(files[2]);
  return { opts, files };
}

function helpText() {
  const p = path.join(ROOT, 'help.txt');
  let txt = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : 'A viewer for git and diff output\n\nUsage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]\n';
  const bin = process.env.DELTA_BIN_NAME || path.basename(process.argv[1] || 'delta');
  return txt.replace(/^Usage: delta /m, `Usage: ${bin} `);
}

function listThemes() {
  return [
    'dark\t1337','dark\tColdark-Cold','dark\tColdark-Dark','dark\tDarkNeon','dark\tDracula',
    'dark\tMonokai Extended','dark\tMonokai Extended Bright','dark\tMonokai Extended Origin',
    'dark\tNord','dark\tOneHalfDark','dark\tSolarized (dark)','dark\tSublime Snazzy',
    'dark\tTwoDark','dark\tVisual Studio Dark+','dark\tansi','dark\tbase16','dark\tbase16-256',
    'dark\tgruvbox-dark','dark\tzenburn','light\tGitHub','light\tMonokai Extended Light',
    'light\tOneHalfLight','light\tSolarized (light)','light\tgruvbox-light'
  ].join('\n') + '\n';
}

function listLanguages() {
  return [
    ['ActionScript','as'], ['Ada','adb, ads, gpr'], ['Apache Conf','envvars, htaccess, .htaccess'],
    ['AppleScript','applescript'], ['ARM Assembly','s, S'], ['AsciiDoc (Asciidoctor)','adoc, ad, asciidoc'],
    ['ASP','asa'], ['Assembly (x86_64)','yasm, nasm, asm, inc'], ['AWK','awk'],
    ['Batch File','bat, cmd'], ['BibTeX','bib'], ['Bourne Again Shell (bash)','sh, bash, zsh, ash, .bashrc, .profile'],
    ['C','c, h'], ['C#','cs, csx'], ['C++','cpp, cc, cxx, c++, hpp, hxx'], ['Cabal','cabal'],
    ['CSS','css'], ['Diff','diff, patch'], ['Dockerfile','Dockerfile'], ['Go','go'],
    ['HTML','html, htm'], ['Java','java'], ['JavaScript','js, jsx, mjs'], ['JSON','json'],
    ['Makefile','Makefile, makefile, mk'], ['Markdown','md, markdown'], ['Python','py, pyw'],
    ['Rust','rs'], ['Shell-Unix-Generic','sh'], ['TOML','toml'], ['TypeScript','ts, tsx'], ['YAML','yaml, yml']
  ].map(([name, exts]) => `${name.padEnd(26)}${c(exts.split(', ').join(RESET + ', ' + GREEN), GREEN)}`).join('\n') + '\n';
}

function showSyntaxThemes() {
  return `\nSyntax theme: ${c('1337', BOLD)}\n\n\n${c('example.rs', BLUE)}\n${c('----------', BLUE)}\n\n` +
    `${MINUS_BG}// Output the square of a number.${RESET}\n` +
    `${MINUS_BG}fn print_square(num: f64) {${RESET}\n` +
    `${PLUS_BG}${WHITE}// Output the cube of a number.${RESET}\n` +
    `${PLUS_BG}${WHITE}fn print_cube(num: f64) {${RESET}\n`;
}

function completion(shell) {
  const map = { bash: 'completion.bash', fish: 'completion.fish', zsh: 'completion.zsh' };
  if (map[shell]) {
    const p = path.join(ROOT, 'completion', map[shell]);
    if (fs.existsSync(p)) return fs.readFileSync(p, 'utf8');
  }
  return `# completion for delta (${shell || 'unknown'})\n`;
}

function diffFiles(a, b, opts) {
  let args = ['-u', a, b];
  if (opts['--diff-args']) args = opts['--diff-args'].split(/\s+/).filter(Boolean).concat([a, b]);
  const r = cp.spawnSync('diff', args, { encoding: 'utf8' });
  return (r.stdout || '') + (r.stderr || '');
}

function parseHunk(line) {
  const m = /^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@/.exec(line);
  if (!m) return null;
  return { old: Number(m[1]), neu: Number(m[2]) };
}

function filenameFrom(lines, i) {
  for (let j = i; j < Math.min(lines.length, i + 8); j++) {
    const m = /^\+\+\+ (?:b\/)?(.+)$/.exec(lines[j]);
    if (m && m[1] !== '/dev/null') return m[1].replace(/\t.*$/, '');
  }
  for (let j = i; j >= 0; j--) {
    const m = /^diff --git a\/(.+?) b\/(.+)$/.exec(lines[j]);
    if (m) return m[2];
  }
  return null;
}

function stripAnsi(s) {
  return s.replace(/\x1b\[[0-9;]*m/g, '');
}

function renderColorOnly(input) {
  const out = [];
  for (const line of input.split(/\n/)) {
    if (line.startsWith('+++') || line.startsWith('---') || line.startsWith('@@') || line.startsWith('diff ') || line.startsWith('index ')) {
      out.push(line);
    } else if (line.startsWith('+')) {
      out.push(c(line, GREEN));
    } else if (line.startsWith('-')) {
      out.push(c(line, RED));
    } else if (line.length) {
      out.push(line.startsWith(' ') ? ' ' + c(line.slice(1), WHITE) : line);
    } else {
      out.push(line);
    }
  }
  return out.join('\n');
}

function renderPretty(input, opts) {
  const lines = input.replace(/\r\n/g, '\n').split('\n');
  const out = [];
  let oldNo = 0, newNo = 0, inDiff = false, lastFile = '';
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line === '' && i === lines.length - 1) continue;
    if (line.startsWith('diff --git ') || line.startsWith('--- ')) {
      const f = filenameFrom(lines, i);
      if (f && f !== lastFile) {
        if (out.length) out.push('');
        out.push(c(f, BLUE));
        out.push(c('─'.repeat(Math.max(10, Number(opts['--width']) || 80)), BLUE));
        lastFile = f;
      }
      inDiff = true;
      continue;
    }
    if (line.startsWith('+++ ') || line.startsWith('index ') || line.startsWith('new file ') || line.startsWith('deleted file ')) {
      inDiff = true;
      continue;
    }
    const h = parseHunk(line);
    if (h) {
      oldNo = h.old; newNo = h.neu; inDiff = true;
      out.push('');
      out.push(c('───┐', BLUE));
      out.push(c(String(newNo), BLUE) + ': ' + c('│', BLUE));
      out.push(c('───┘', BLUE));
      continue;
    }
    if (!inDiff) {
      out.push(renderGrepLine(line, opts));
      continue;
    }
    if (line.startsWith('-') && !line.startsWith('---')) {
      out.push(formatCode(line.slice(1), 'minus', oldNo, null, opts)); oldNo++;
    } else if (line.startsWith('+') && !line.startsWith('+++')) {
      out.push(formatCode(line.slice(1), 'plus', null, newNo, opts)); newNo++;
    } else if (line.startsWith(' ')) {
      out.push(formatCode(line.slice(1), 'context', oldNo, newNo, opts)); oldNo++; newNo++;
    } else if (/^(commit|Author:|Date:)/.test(line)) {
      out.push(c(line, BLUE));
    } else {
      out.push(line);
    }
  }
  return out.join('\n') + (input.endsWith('\n') ? '\n' : '');
}

function formatCode(text, kind, oldNo, newNo, opts) {
  const keep = opts['--keep-plus-minus-markers'];
  let marker = '';
  if (keep) marker = kind === 'minus' ? '-' : kind === 'plus' ? '+' : ' ';
  let prefix = '';
  if (opts['--line-numbers'] || opts['--side-by-side']) {
    const l = oldNo == null ? '' : String(oldNo);
    const r = newNo == null ? '' : String(newNo);
    prefix = c(l.padStart(4), BLUE) + c(' │ ', BLUE) + c(r.padStart(4), BLUE) + c(' │ ', BLUE);
  }
  if (kind === 'minus') return prefix + c(marker + text, hasColor() ? MINUS_BG : '');
  if (kind === 'plus') return prefix + c(marker + text, hasColor() ? PLUS_BG + WHITE : '');
  return prefix + c(marker + text, WHITE);
}

function renderGrepLine(line) {
  const m = /^(.+?)([:-])(\d+)([:-])(.*)$/.exec(line);
  if (!m) return line;
  return `${c(m[1], BLUE)}${m[2]}${c(m[3], GREEN)}${m[4]}${m[5]}`;
}

function renderSideBySide(input, opts) {
  const lines = input.replace(/\r\n/g, '\n').split('\n');
  const out = [];
  let pendingMinus = [];
  const width = Math.max(40, Number(opts['--width']) || 120);
  const col = Math.floor((width - 3) / 2);
  function flushPlus(text) {
    if (pendingMinus.length) {
      const left = pendingMinus.shift();
      out.push(c(left.padEnd(col), MINUS_BG) + c(' │ ', BLUE) + c(text.padEnd(col), PLUS_BG + WHITE));
    } else {
      out.push(' '.repeat(col) + c(' │ ', BLUE) + c(text.padEnd(col), PLUS_BG + WHITE));
    }
  }
  function flushAll() {
    while (pendingMinus.length) out.push(c(pendingMinus.shift().padEnd(col), MINUS_BG) + c(' │ ', BLUE));
  }
  for (const line of lines) {
    if (line.startsWith('-') && !line.startsWith('---')) pendingMinus.push(line.slice(1));
    else if (line.startsWith('+') && !line.startsWith('+++')) flushPlus(line.slice(1));
    else {
      flushAll();
      if (line.startsWith('diff ') || line.startsWith('---') || line.startsWith('+++') || line.startsWith('index ')) continue;
      if (parseHunk(line)) out.push(c(line, BLUE));
      else out.push(line.startsWith(' ') ? line.slice(1) : line);
    }
  }
  flushAll();
  return out.join('\n') + (input.endsWith('\n') ? '\n' : '');
}

function showConfig() {
  return [
    'delta.detect-dark-light = "auto"',
    'delta.diff-stat-align-width = 48',
    'delta.file-style = "blue"',
    'delta.hunk-header-style = "line-number syntax file"',
    'delta.minus-style = "syntax #3f0001"',
    'delta.plus-style = "syntax #002800"',
    'delta.syntax-theme = "Monokai Extended"'
  ].join('\n') + '\n';
}

function main() {
  const { opts, files } = parseArgs(process.argv.slice(2));
  if (opts['--help'] || opts['-h']) return print(helpText());
  if (opts['--version'] || opts['-V']) return print('delta 0.18.2');
  if (opts['--list-syntax-themes'] || opts['--show-themes']) return print(listThemes());
  if (opts['--list-languages']) return print(listLanguages());
  if (opts['--show-syntax-themes']) return print(showSyntaxThemes());
  if (opts['--generate-completion']) return print(completion(opts['--generate-completion']));
  if (opts['--show-config']) return print(showConfig());
  if (opts['--show-colors']) return print(showColors());

  let input = '';
  if (files.length === 2) input = diffFiles(files[0], files[1], opts);
  else if (files.length === 1) {
    try { input = fs.readFileSync(files[0], 'utf8'); }
    catch (e) { process.stderr.write(`No such file or directory: ${files[0]}\n`); process.exit(1); }
  } else {
    input = readStdin();
  }
  if (opts['--color-only'] || opts['--raw']) process.stdout.write(renderColorOnly(input));
  else if (opts['--side-by-side']) process.stdout.write(renderSideBySide(input, opts));
  else process.stdout.write(renderPretty(input, opts));
}

function showColors() {
  const names = ['Black','Red','Green','Yellow','Blue','Magenta','Cyan','White'];
  return names.map((n, i) => `\n${c(n, BOLD)}\n${ESC}3${i}mexport function color(): string { return "${n.toLowerCase()}" }${RESET}`).join('\n') + '\n';
}

main();
