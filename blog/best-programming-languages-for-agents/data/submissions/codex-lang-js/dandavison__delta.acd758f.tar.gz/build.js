const fs = require('fs');
fs.chmodSync('src/delta.js', 0o755);
