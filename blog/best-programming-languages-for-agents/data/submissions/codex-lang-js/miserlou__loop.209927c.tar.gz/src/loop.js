#!/usr/bin/env node
'use strict';

const { spawnSync } = require('child_process');

const HELP = `loop 0.6.1
Rich Jones <miserlou@gmail.com>
UNIX's missing \`loop\` command

USAGE:
    executable [FLAGS] [OPTIONS] [input]...

FLAGS:
    -D, --error-duration    Exit with timeout error code on duration
    -h, --help              Prints help information
    -l, --only-last         Only print the output of the last execution of the command
    -i, --stdin             Read from standard input
        --summary           Provide a summary
    -C, --until-changes     Keep going until the output changes
    -f, --until-fail        Keep going until the command exit status is non-zero
    -S, --until-same        Keep going until the output changes
    -s, --until-success     Keep going until the command exit status is zero
    -V, --version           Prints version information

OPTIONS:
    -b, --count-by <count_by>                Amount to increment the counter by [default: 1]
    -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]
        --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue
    -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)
    -n, --num <num>                          Number of iterations to execute
    -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]
    -c, --until-contains <until_contains>    Keep going until the output contains this string
    -r, --until-error <until_error>          Keep going until the command exit status is the value given
    -m, --until-match <until_match>          Keep going until the output matches this regular expression
    -t, --until-time <until_time>            Keep going until a future time, ex. "2018-04-20 04:20:00" (Times in UTC.)

ARGS:
    <input>...    The command to be looped`;

const VERSION = 'loop 0.6.1';

function die(message, status = 1) {
  process.stderr.write(message + '\n');
  process.exit(status);
}

function usageFor(opt) {
  if (opt === '--num') return '    executable --num <num>';
  return '    executable [FLAGS] [OPTIONS] [input]...';
}

function unexpected(arg, opt) {
  die(`error: Found argument '${arg}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n${usageFor(opt)}\n\nFor more information try --help`);
}

function invalidValue(opt, value, reason) {
  die(`error: Invalid value for '${opt}': ${reason}`);
}

function parseFloatOption(opt, value) {
  if (value == null) die(`error: The argument '${opt}' requires a value but none was supplied`);
  const n = Number(value);
  if (!Number.isFinite(n)) invalidValue(opt, value, 'invalid float literal');
  return n;
}

function parseDuration(s, opt) {
  if (s == null) die(`error: The argument '${opt}' requires a value but none was supplied`);
  let pos = 0;
  let total = 0;
  const units = { h: 3600000, m: 60000, s: 1000, ms: 1, us: 0.001 };
  while (pos < s.length) {
    const num = /^[0-9]+(?:\.[0-9]+)?/.exec(s.slice(pos));
    if (!num) invalidValue(opt, s, `expected number at ${pos}`);
    pos += num[0].length;
    let unit = null;
    for (const u of ['ms', 'us', 'h', 'm', 's']) {
      if (s.slice(pos, pos + u.length) === u) {
        unit = u;
        pos += u.length;
        break;
      }
    }
    if (!unit) invalidValue(opt, s, `expected unit at ${pos}`);
    total += Number(num[0]) * units[unit];
  }
  return total;
}

function parseTime(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/.exec(s || '');
  if (!m) return NaN;
  return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
}

function readStdinLines() {
  try {
    const buf = require('fs').readFileSync(0, 'utf8');
    const lines = buf.split(/\n/);
    if (lines.length && lines[lines.length - 1] === '') lines.pop();
    return lines;
  } catch {
    return [];
  }
}

function sleepMs(ms) {
  if (ms <= 0) return;
  const sab = new SharedArrayBuffer(4);
  const ia = new Int32Array(sab);
  Atomics.wait(ia, 0, 0, Math.max(0, ms));
}

function parseArgs(argv) {
  const opts = {
    countBy: 1,
    every: 0.001,
    offset: 0,
    command: [],
    onlyLast: false,
    stdin: false,
    summary: false,
    errorDuration: false,
  };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    let attached = null;
    const eq = a.startsWith('--') ? a.indexOf('=') : -1;
    if (eq > 0) {
      attached = a.slice(eq + 1);
      a = a.slice(0, eq);
    }
    if (a === '--') {
      opts.command.push(...argv.slice(i + 1));
      break;
    }
    if (!a.startsWith('-') || a === '-') {
      opts.command.push(...argv.slice(i));
      break;
    }
    const val = (usageOpt = null) => {
      if (attached != null) {
        const v = attached;
        attached = null;
        return v;
      }
      const v = argv[++i];
      if (v == null) die(`error: The argument '${a}' requires a value but none was supplied`);
      if (v.startsWith('-')) unexpected(v, usageOpt);
      return v;
    };
    switch (a) {
      case '-h':
      case '--help':
        console.log(HELP);
        process.exit(0);
      case '-V':
      case '--version':
        console.log(VERSION);
        process.exit(0);
      case '-D':
      case '--error-duration':
        opts.errorDuration = true; break;
      case '-l':
      case '--only-last':
        opts.onlyLast = true; break;
      case '-i':
      case '--stdin':
        opts.stdin = true; break;
      case '--summary':
        opts.summary = true; break;
      case '-C':
      case '--until-changes':
        opts.untilChanges = true; break;
      case '-f':
      case '--until-fail':
        opts.untilFail = true; break;
      case '-S':
      case '--until-same':
        opts.untilSame = true; break;
      case '-s':
      case '--until-success':
        opts.untilSuccess = true; break;
      case '-b':
      case '--count-by':
        opts.countBy = parseFloatOption('--count-by <count_by>', val()); break;
      case '-e':
      case '--every':
        opts.every = parseDuration(val(), '--every <every>'); break;
      case '--for':
        opts.forValues = (val() ?? '').split(','); break;
      case '-d':
      case '--for-duration':
        opts.forDuration = parseDuration(val(), '--for-duration <for_duration>'); break;
      case '-n':
      case '--num':
        opts.num = Math.floor(parseFloatOption('--num <num>', val('--num'))); break;
      case '-o':
      case '--offset':
        opts.offset = parseFloatOption('--offset <offset>', val()); break;
      case '-c':
      case '--until-contains':
        opts.untilContains = val(); break;
      case '-r':
      case '--until-error':
        opts.untilError = Math.floor(parseFloatOption('--until-error <until_error>', val())); break;
      case '-m':
      case '--until-match':
        opts.untilMatch = new RegExp(val()); break;
      case '-t':
      case '--until-time':
        opts.untilTime = parseTime(val()); break;
      default:
        if (/^-\d/.test(a)) unexpected(a, '--num');
        unexpected(a);
    }
  }
  return opts;
}

function runCommand(command, env) {
  const result = spawnSync('/bin/sh', ['-c', `{ ${command}\n} 2>&1`], {
    env,
    encoding: 'utf8',
    maxBuffer: 1024 * 1024 * 64,
  });
  return {
    output: result.stdout || '',
    status: result.status == null ? 1 : result.status,
  };
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (!opts.command.length) {
    process.stdout.write('No command supplied, exiting.\n');
    return;
  }

  const command = opts.command.join(' ');
  const itemValues = opts.stdin ? readStdinLines() : (opts.forValues || []);
  const start = Date.now();
  let count = opts.offset;
  let iteration = 0;
  let successes = 0;
  let failures = 0;
  let lastOutput = '';
  let previousOutput = null;

  while (true) {
    if (opts.num != null && iteration >= opts.num) break;
    if (opts.forDuration != null && Date.now() - start >= opts.forDuration) {
      if (opts.errorDuration) process.exit(124);
      break;
    }
    if (opts.untilTime != null && Number.isFinite(opts.untilTime) && Date.now() >= opts.untilTime) break;

    let item = '';
    if (itemValues.length) item = itemValues[Math.min(iteration, itemValues.length - 1)];
    const env = { ...process.env, COUNT: String(count), ITEM: item };
    const { output, status } = runCommand(command, env);
    if (status === 0) successes++; else failures++;
    lastOutput = output;

    if (!opts.onlyLast) process.stdout.write(output);

    let stop = false;
    if (opts.untilSuccess && status === 0) stop = true;
    if (opts.untilFail && status !== 0) stop = true;
    if (opts.untilError != null && status === opts.untilError) stop = true;
    if (opts.untilContains != null && output.includes(opts.untilContains)) stop = true;
    if (opts.untilMatch && opts.untilMatch.test(output)) stop = true;
    if (opts.untilChanges && previousOutput != null && output !== previousOutput) stop = true;
    if (opts.untilSame && previousOutput != null && output === previousOutput) stop = true;

    previousOutput = output;
    iteration++;
    count += opts.countBy;
    if (stop) break;
    sleepMs(opts.every);
  }

  if (opts.onlyLast) process.stdout.write(lastOutput);
  if (opts.summary) {
    process.stdout.write(`Total runs:\t${successes + failures}\nSuccesses:\t${successes}\nFailures:\t${failures}\n`);
  }
}

main();
