#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const CONFIG = `# zk configuration file
#
# Uncomment the properties you want to customize.

# NOTE SETTINGS
#
# Defines the default options used when generating new notes.
[note]

# Language used when writing notes.
# This is used to generate slugs or with date formats.
#language = "en"

# The default title used for new note, if no \`--title\` flag is provided.
#default-title = "Untitled"

# Template used to generate a note's filename, without extension.
#filename = "{{id}}"

# The file extension used for the notes.
#extension = "md"

# Template used to generate a note's content.
# If not an absolute path or "~/unix/path", it's relative to .zk/templates/
template = "default.md"

# Path globs ignored while indexing existing notes.
#exclude = [
#    "drafts/*",
#    "log.md"
#]

# Configure random ID generation.

# The charset used for random IDs. You can use:
#   * letters: only letters from a to z.
#   * numbers: 0 to 9
#   * alphanum: letters + numbers
#   * hex: hexadecimal, from a to f and 0 to 9
#   * custom string: will use any character from the provided value
#id-charset = "alphanum"

# Length of the generated IDs.
#id-length = 4

# Letter case for the random IDs, among lower, upper or mixed.
#id-case = "lower"


# EXTRA VARIABLES
#
# A dictionary of variables you can use for any custom values when generating
# new notes. They are accessible in templates with {{extra.<key>}}
[extra]

#key = "value"


# MARKDOWN SETTINGS
[format.markdown]
link-format = "wiki"
hashtags = true
colon-tags = false
multiword-tags = false

[tool]

[lsp]
[lsp.diagnostics]
dead-link = "error"

[lsp.completion]

[filter]
`;

const HELP = {
main: `Usage: zk <command>

Commands:

NOTEBOOK
  A notebook is a directory containing a collection of notes

  init     Create a new notebook in the given directory.
  index    Index the notes to be searchable.

NOTES
  Edit or browse your notes

  new      Create a new note in the given notebook directory.
  list     List notes matching the given criteria.
  graph    Produce a graph of the notes matching the given criteria.
  edit     Edit notes matching the given criteria.
  tag      Manage the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Run "zk <command> --help" for more information on a command.`,
init: `Usage: zk init [<directory>]

Create a new notebook in the given directory.

Arguments:
  [<directory>]    Directory containing the notebook.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.`,
index: `Usage: zk index

Index the notes to be searchable.

You usually do not need to run \`zk index\` manually, as notes are indexed
automatically when needed.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

  -f, --force                Force indexing all the notes.
  -v, --verbose              Print detailed information about the indexing
                             process.
  -q, --quiet                Do not print statistics nor progress.`,
new: `Usage: zk new [<directory>]

Create a new note in the given notebook directory.

Arguments:
  [<directory>]    Directory in which to create the note.

Flags:
  -h, --help                   Show context-sensitive help.
      --notebook-dir=PATH      Turn off notebook auto-discovery and set manually
                               the notebook where commands are run.
  -W, --working-dir=PATH       Run as if zk was started in <PATH> instead of the
                               current working directory.
      --no-input               Never prompt or ask for confirmation.

  -i, --interactive            Read contents from standard input.
  -t, --title=TITLE            Title of the new note.
      --date=DATE              Set the current date.
  -g, --group=NAME             Name of the config group this note belongs to.
                               Takes precedence over the config of the
                               directory.
      --extra=KEY=VALUE,...    Extra variables passed to the templates.
      --template=PATH          Custom template used to render the note.
  -p, --print-path             Print the path of the created note instead of
                               editing it.
  -n, --dry-run                Don't actually create the note. Instead, prints
                               its content on stdout and the generated path on
                               stderr.
      --id=ID                  Skip id generation and use provided value.`,
tag: `Usage: zk tag <command>

Manage the note tags.

Commands:
  tag list    List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.`,
taglist: `Usage: zk tag list

List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: name, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print tags delimited by the given separator.
  -0, --delimiter0         Print tags delimited by ASCII NUL characters. This is
                           useful when used in conjunction with \`xargs -0\`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of tags found.

Sorting
  -s, --sort=TERM,...    Order the tags by the given criterion.`
};
HELP.list = `Usage: zk list [<path> ...]

List notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: oneline, short, medium,
                           long, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print notes delimited by the given separator.
  -0, --delimiter0         Print notes delimited by ASCII NUL characters. This
                           is useful when used in conjunction with \`xargs -0\`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of notes found.

Filtering
  -i, --interactive                Select notes interactively with fzf.
  -n, --limit=COUNT                Limit the number of notes found.
  -m, --match=QUERY,...            Terms to search for in the notes.
  -M, --match-strategy=STRATEGY    Text matching strategy among: fts, re, exact.
  -x, --exclude=PATH,...           Ignore notes matching the given path,
                                   including its descendants.
  -t, --tag=TAG,...                Find notes tagged with the given tags.
      --mention=PATH,...           Find notes mentioning the title of the given
                                   ones.
      --mentioned-by=PATH,...      Find notes whose title is mentioned in the
                                   given ones.
  -l, --link-to=PATH,...           Find notes which are linking to the given
                                   ones.
      --no-link-to=PATH,...        Find notes which are not linking to the given
                                   notes.
  -L, --linked-by=PATH,...         Find notes which are linked by the given
                                   ones.
      --no-linked-by=PATH,...      Find notes which are not linked by the given
                                   ones.
      --orphan                     Find notes which are not linked by any other
                                   note.
      --tagless                    Find notes which have no tags.
      --missing-backlink           Find notes with at least one missing
                                   backlink.
      --related=PATH,...           Find notes which might be related to the
                                   given ones.
      --max-distance=COUNT         Maximum distance between two linked notes.
  -r, --recursive                  Follow links recursively.
      --created=DATE
      --created-before=DATE        Find notes created before the given date.
      --created-after=DATE         Find notes created after the given date.
      --modified=DATE              Find notes modified on the given date.
      --modified-before=DATE       Find notes modified before the given date.
      --modified-after=DATE        Find notes modified after the given date.

Sorting
  -s, --sort=TERM,...    Order the notes by the given criterion.`;
HELP.graph = HELP.list.replace('Usage: zk list [<path> ...]', 'Usage: zk graph --format=STRING [<path> ...]').replace('List notes matching the given criteria.', 'Produce a graph of the notes matching the given criteria.').replace(/Formatting[\s\S]*?Filtering/, 'Formatting\n  -f, --format=STRING    Format of the graph among: json.\n  -q, --quiet            Do not print the total number of notes found.\n\nFiltering');
HELP.edit = HELP.list.replace('Usage: zk list [<path> ...]', 'Usage: zk edit [<path> ...]').replace('List notes matching the given criteria.', 'Edit notes matching the given criteria.').replace(/Formatting[\s\S]*?Filtering/, '  -f, --force                Do not confirm before editing many notes at the\n                             same time.\n\nFiltering');

function eprint(s){ process.stderr.write(String(s).replace(/\n?$/,'\n')); }
function die(msg, code=1){ eprint('zk: error: '+msg); process.exit(code); }
function show(s){ console.log(s); }
function getOpt(args, names, def=null){ for(let i=0;i<args.length;i++){let a=args[i]; for(const n of names){ if(a===n) return args[i+1]??true; if(a.startsWith(n+'=')) return a.slice(n.length+1); }} return def; }
function has(args,...names){ return args.some(a=>names.includes(a)); }
function removeGlobal(argv){ const globals={notebookDir:null, workingDir:null, noInput:false}; const out=[]; for(let i=0;i<argv.length;i++){let a=argv[i]; if(a==='--no-input'){globals.noInput=true; continue;} if(a==='--notebook-dir'){globals.notebookDir=argv[++i]; continue;} if(a.startsWith('--notebook-dir=')){globals.notebookDir=a.split('=').slice(1).join('='); continue;} if(a==='-W'||a==='--working-dir'){globals.workingDir=argv[++i]; continue;} if(a.startsWith('--working-dir=')){globals.workingDir=a.split('=').slice(1).join('='); continue;} out.push(a); } return {globals,args:out}; }
function cwdWith(g){ return path.resolve(g.workingDir || process.cwd()); }
function findNotebook(g){ let base = g.notebookDir ? path.resolve(cwdWith(g), g.notebookDir) : cwdWith(g); let d=base; while(true){ if(fs.existsSync(path.join(d,'.zk'))) return d; let p=path.dirname(d); if(p===d) break; d=p; } if(g.notebookDir && !fs.existsSync(base)) { eprint('zk: warning: lstat '+base+': no such file or directory'); eprint('zk: warning: lstat '+base+': no such file or directory'); } die('failed to open notebook: no notebook found in '+base+' or a parent directory'); }
function walk(dir, root, arr=[]){ for(const ent of fs.readdirSync(dir,{withFileTypes:true})){ if(ent.name==='.zk'||ent.name==='.git'||ent.name==='node_modules') continue; const p=path.join(dir,ent.name); if(ent.isDirectory()) walk(p,root,arr); else if(ent.isFile() && /\.(md|markdown|mdown)$/i.test(ent.name)) arr.push(p); } return arr; }
function parseFront(content){ const fm={}; let body=content; if(content.startsWith('---\n')){ const end=content.indexOf('\n---',4); if(end>=0){ const raw=content.slice(4,end).split(/\r?\n/); body=content.slice(content.indexOf('\n',end+1)+1); for(const l of raw){ const m=l.match(/^([A-Za-z0-9_-]+):\s*(.*)$/); if(m) fm[m[1]]=m[2].trim(); } } } return {fm,body}; }
function titleFrom(file, content){ const {fm,body}=parseFront(content); if(fm.title) return stripQuotes(fm.title); const h=body.match(/^#\s+(.+)$/m); if(h) return h[1].trim(); return path.basename(file).replace(/\.[^.]+$/,'').replace(/[-_]/g,' '); }
function stripQuotes(s){ return String(s).replace(/^['"]|['"]$/g,''); }
function tagsFrom(content){ const {fm}=parseFront(content); const set=new Set(); if(fm.tags){ let v=fm.tags; if(v.startsWith('[')) v=v.replace(/^\[/,'').replace(/\]$/,'').split(',').forEach(x=>{x=stripQuotes(x.trim()); if(x) set.add(x.replace(/^#/,''));}); else v.split(/[ ,]+/).forEach(x=>{x=stripQuotes(x.trim()); if(x) set.add(x.replace(/^#/,''));}); }
 const re=/(^|\s)#([A-Za-z0-9_][A-Za-z0-9_\/-]*)/g; let m; while((m=re.exec(content))) set.add(m[2]); return [...set].sort(); }
function linksFrom(content){ const links=[]; let m; const w=/\[\[([^\]|#]+)(?:#[^\]|]+)?(?:\|[^\]]+)?\]\]/g; while((m=w.exec(content))) links.push(m[1].trim()); const md=/\[[^\]]+\]\(([^)]+)\)/g; while((m=md.exec(content))) links.push(decodeURIComponent(m[1].split('#')[0])); return links; }
function readNotes(root){ return walk(root,root).map(file=>{ const st=fs.statSync(file); const content=fs.readFileSync(file,'utf8'); const rel=path.relative(root,file).split(path.sep).join('/'); const title=titleFrom(file,content); return {path:rel, absPath:file, title, filename:path.basename(file), stem:path.basename(file).replace(/\.[^.]+$/,''), content, tags:tagsFrom(content), links:linksFrom(content), created:st.birthtime.toISOString(), modified:st.mtime.toISOString()}; }).sort((a,b)=>a.path.localeCompare(b.path)); }
function csv(v){ return String(v||'').split(',').filter(Boolean); }

function positionalArgs(args, command){
  const valueOpts = new Set(['-W','--working-dir','--notebook-dir','-f','--format','--header','--footer','-d','--delimiter','-n','--limit','-m','--match','-M','--match-strategy','-x','--exclude','-t','--tag','--mention','--mentioned-by','-l','--link-to','--no-link-to','-L','--linked-by','--no-linked-by','--related','--max-distance','-s','--sort','--created','--created-before','--created-after','--modified','--modified-before','--modified-after','--title','-g','--group','--extra','--template','--id','--date']);
  const out=[];
  for(let i=0;i<args.length;i++){
    const a=args[i];
    if(i===0 && a===command) continue;
    if(a.startsWith('--') && a.includes('=')) continue;
    if(valueOpts.has(a)){ i++; continue; }
    if(a.startsWith('-')) continue;
    out.push(a);
  }
  return out;
}

function filterNotes(notes,args,root){ let cmd=args[0]; let paths=positionalArgs(args, cmd); if(paths.length) notes=notes.filter(n=>paths.some(p=>n.path.startsWith(p.replace(/^\.\//,'')))); const match=csv(getOpt(args,['-m','--match'],'')); if(match.length) notes=notes.filter(n=>match.every(q=>n.content.toLowerCase().includes(q.toLowerCase())||n.title.toLowerCase().includes(q.toLowerCase()))); const tags=csv(getOpt(args,['-t','--tag'],'')); if(tags.length) notes=notes.filter(n=>tags.every(t=>n.tags.includes(t.replace(/^#/,'')))); if(has(args,'--tagless')) notes=notes.filter(n=>n.tags.length===0); if(has(args,'--orphan')) { const targets=new Set(); for(const n of notes) for(const l of n.links) targets.add(l.toLowerCase()); notes=notes.filter(n=>!targets.has(n.title.toLowerCase())&&!targets.has(n.path.toLowerCase())&&!targets.has(n.stem.toLowerCase())); }
 const excl=csv(getOpt(args,['-x','--exclude'],'')); if(excl.length) notes=notes.filter(n=>!excl.some(x=>n.path.startsWith(x))); const sort=getOpt(args,['-s','--sort'],'path'); notes=sortNotes(notes,sort); const lim=parseInt(getOpt(args,['-n','--limit'],'0'),10); if(lim>0) notes=notes.slice(0,lim); return notes; }
function sortNotes(notes,sort){ const key=String(sort).split(',')[0]; const desc=key.endsWith('-'); const k=key.replace(/[+-]$/,''); return notes.slice().sort((a,b)=>{ let av=(k==='title'?a.title:k==='modified'?a.modified:k==='created'?a.created:a.path); let bv=(k==='title'?b.title:k==='modified'?b.modified:k==='created'?b.created:b.path); return (desc?-1:1)*String(av).localeCompare(String(bv)); }); }
function noteObj(n){ return {path:n.path,title:n.title,filename:n.filename,extension:path.extname(n.filename).slice(1),absPath:n.absPath,tags:n.tags,links:n.links}; }
function formatNote(n,fmt){ if(fmt==='short') return `${n.path}`; if(fmt==='medium') return `${n.path}\t${n.title}`; if(fmt==='long'||fmt==='full') return `${n.path}\nTitle: ${n.title}\nTags: ${n.tags.join(', ')}`; if(fmt && fmt.includes('{{')) return fmt.replace(/{{\s*path\s*}}/g,n.path).replace(/{{\s*title\s*}}/g,n.title).replace(/{{\s*filename\s*}}/g,n.filename); return n.path; }
function delimiter(args){ if(has(args,'-0','--delimiter0')) return '\0'; return getOpt(args,['-d','--delimiter'],'\n').replace(/\\n/g,'\n').replace(/\\t/g,'\t'); }
function outputList(notes,args){ const fmt=getOpt(args,['-f','--format'],'oneline'); const header=getOpt(args,['--header'],null); const footer=getOpt(args,['--footer'],null); if(header) process.stdout.write(header.replace(/\\n/g,'\n')); if(fmt==='json') process.stdout.write(JSON.stringify(notes.map(noteObj),null,2)+'\n'); else if(fmt==='jsonl') notes.forEach(n=>process.stdout.write(JSON.stringify(noteObj(n))+'\n')); else { const del=delimiter(args); if(notes.length) process.stdout.write(notes.map(n=>formatNote(n,fmt)).join(del)+(del==='\0'?'\0':'\n')); } if(footer!==null) process.stdout.write(String(footer).replace(/\\n/g,'\n')); if(!has(args,'-q','--quiet') && false) eprint(`${notes.length} notes`); }
function slug(s){ return String(s||'Untitled').toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'') || 'untitled'; }
function randomId(){ const chars='abcdefghijklmnopqrstuvwxyz0123456789'; let s=''; for(let i=0;i<4;i++) s+=chars[Math.floor(Math.random()*chars.length)]; return s; }
function readStdin(){ try { return fs.readFileSync(0,'utf8'); } catch { return ''; } }

function cmdInit(args,g){ if(has(args,'-h','--help')) return show(HELP.init); const dir=path.resolve(cwdWith(g), args.find(a=>!a.startsWith('-')) || '.'); fs.mkdirSync(path.join(dir,'.zk','templates'),{recursive:true}); if(!fs.existsSync(path.join(dir,'.zk','templates','default.md'))) fs.writeFileSync(path.join(dir,'.zk','templates','default.md'),'# {{title}}\n\n{{content}}\n'); if(!fs.existsSync(path.join(dir,'.zk','config.toml'))) fs.writeFileSync(path.join(dir,'.zk','config.toml'),CONFIG); if(!fs.existsSync(path.join(dir,'.zk','notebook.db'))) fs.writeFileSync(path.join(dir,'.zk','notebook.db'),''); }
function cmdIndex(args,g){ if(has(args,'-h','--help')) return show(HELP.index); const root=findNotebook(g); const count=readNotes(root).length; if(!has(args,'-q','--quiet')) console.log(`${count} notes indexed`); }
function cmdNew(args,g){ if(has(args,'-h','--help')) return show(HELP.new); const root=findNotebook(g); const title=getOpt(args,['-t','--title'],'Untitled'); const id=getOpt(args,['--id'],null)||randomId(); const dirArg=positionalArgs(['new',...args], 'new')[0]; const sub=dirArg?dirArg:''; const filename=(id || slug(title))+'.md'; const outDir=path.resolve(root,sub); const file=path.join(outDir,filename); let content=has(args,'-i','--interactive')?readStdin():''; const tmplPath=getOpt(args,['--template'],null); let tmpl='# {{title}}\n\n{{content}}\n'; if(tmplPath){ const p=path.isAbsolute(tmplPath)?tmplPath:path.resolve(cwdWith(g),tmplPath); if(fs.existsSync(p)) tmpl=fs.readFileSync(p,'utf8'); } else { const p=path.join(root,'.zk','templates','default.md'); if(fs.existsSync(p)) tmpl=fs.readFileSync(p,'utf8'); }
 const rendered=tmpl.replace(/{{\s*title\s*}}/g,title).replace(/{{\s*content\s*}}/g,content).replace(/{{\s*id\s*}}/g,id).replace(/{{\s*date\s*}}/g,getOpt(args,['--date'],new Date().toISOString().slice(0,10)));
 const rel=path.relative(root,file).split(path.sep).join('/'); if(has(args,'-n','--dry-run')) { process.stdout.write(rendered); eprint(rel); return; } fs.mkdirSync(outDir,{recursive:true}); fs.writeFileSync(file,rendered); if(has(args,'-p','--print-path')) console.log(rel); else { const ed=process.env.EDITOR||process.env.VISUAL; if(ed) cp.spawnSync(ed,[file],{stdio:'inherit',shell:true}); else console.log(rel); } }
function cmdList(args,g){ if(has(args,'-h','--help')) return show(HELP.list); const root=findNotebook(g); outputList(filterNotes(readNotes(root),['list',...args],root),args); }
function cmdGraph(args,g){ if(has(args,'-h','--help')) return show(HELP.graph); const root=findNotebook(g); const notes=filterNotes(readNotes(root),['graph',...args],root); const byTitle=new Map(notes.map(n=>[n.title.toLowerCase(),n])); const byPath=new Map(notes.map(n=>[n.path.toLowerCase(),n])); const nodes=notes.map(n=>({id:n.path,path:n.path,title:n.title})); const edges=[]; for(const n of notes){ for(const l of n.links){ const t=byTitle.get(l.toLowerCase())||byPath.get(l.toLowerCase())||byPath.get(l.replace(/^\.\//,'').toLowerCase()); if(t) edges.push({source:n.path,target:t.path}); } } console.log(JSON.stringify({nodes,links:edges},null,2)); }
function cmdEdit(args,g){ if(has(args,'-h','--help')) return show(HELP.edit); const root=findNotebook(g); const notes=filterNotes(readNotes(root),['edit',...args],root); const ed=process.env.EDITOR||process.env.VISUAL; if(!ed) { notes.forEach(n=>console.log(n.path)); return; } cp.spawnSync(ed,notes.map(n=>path.join(root,n.path)),{stdio:'inherit',shell:true}); }
function cmdTag(args,g){ if(args[0]==='list'){ if(has(args,'-h','--help')) return show(HELP.taglist); const root=findNotebook(g); const counts=new Map(); for(const n of readNotes(root)) for(const t of n.tags) counts.set(t,(counts.get(t)||0)+1); let tags=[...counts.entries()].map(([name,count])=>({name,count})).sort((a,b)=>a.name.localeCompare(b.name)); const fmt=getOpt(args,['-f','--format'],'name'); if(fmt==='json') console.log(JSON.stringify(tags,null,2)); else if(fmt==='jsonl') tags.forEach(t=>console.log(JSON.stringify(t))); else { const del=delimiter(args); const lines=tags.map(t=>fmt==='full'?`${t.name}\t${t.count}`:t.name); if(lines.length) process.stdout.write(lines.join(del)+(del==='\0'?'\0':'\n')); } return; } if(has(args,'-h','--help')||args.length===0) return show(HELP.tag); die('unexpected argument '+args[0]); }
function main(){ const parsed=removeGlobal(process.argv.slice(2)); const {globals:g,args}=parsed; if(args.length===0) { show(HELP.main); return; } const cmd=args[0]; if(has(args,'-h','--help') && HELP[cmd]) return show(HELP[cmd]); if(cmd==='--help'||cmd==='-h') return show(HELP.main); if(cmd==='--version') return console.log('zk dev'); const rest=args.slice(1); if(cmd==='init') return cmdInit(rest,g); if(cmd==='index') return cmdIndex(rest,g); if(cmd==='new') return cmdNew(rest,g); if(cmd==='list') return cmdList(rest,g); if(cmd==='graph') return cmdGraph(rest,g); if(cmd==='edit') return cmdEdit(rest,g); if(cmd==='tag') return cmdTag(rest,g); die('unexpected argument '+cmd); }
try{ main(); }catch(e){ die(e.message||e); }
