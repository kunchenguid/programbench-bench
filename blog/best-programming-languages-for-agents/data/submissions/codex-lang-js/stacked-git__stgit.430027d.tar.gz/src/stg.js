#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const cp = require("child_process");

function run(args, opts = {}) {
  const r = cp.spawnSync(args[0], args.slice(1), {
    encoding: opts.encoding || "utf8",
    input: opts.input,
    stdio: opts.stdio || ["pipe", "pipe", "pipe"],
  });
  if (opts.check !== false && r.status !== 0) {
    if (r.stdout) process.stdout.write(r.stdout);
    if (r.stderr) process.stderr.write(r.stderr);
    process.exit(r.status || 1);
  }
  return r;
}

function git(args, opts = {}) {
  return run(["git", ...args], opts);
}

function out(s = "") {
  process.stdout.write(s.endsWith("\n") ? s : s + "\n");
}

function err(s) {
  process.stderr.write(s.endsWith("\n") ? s : s + "\n");
}

function die(s, code = 2) {
  err(`error: ${s}`);
  process.exit(code);
}

function gitOut(args) {
  return git(args).stdout.trim();
}

function repoRoot() {
  const r = git(["rev-parse", "--show-toplevel"], { check: false });
  if (r.status !== 0) die("not a git repository (or any of the parent directories): .git", 128);
  return r.stdout.trim();
}

function gitDir() {
  return path.join(repoRoot(), ".git");
}

function statePath() {
  return path.join(gitDir(), "stg-js", "state.json");
}

function branch() {
  const b = gitOut(["branch", "--show-current"]);
  if (!b) die("not on a branch");
  return b;
}

function emptyState() {
  return { version: 1, branch: branch(), base: gitOut(["rev-parse", "HEAD"]), patches: [] };
}

function loadState(auto = false) {
  const p = statePath();
  if (!fs.existsSync(p)) {
    if (auto) return saveState(emptyState());
    die("current branch is not initialized");
  }
  const s = JSON.parse(fs.readFileSync(p, "utf8"));
  if (!s.patches) s.patches = [];
  return s;
}

function saveState(s) {
  fs.mkdirSync(path.dirname(statePath()), { recursive: true });
  fs.writeFileSync(statePath(), JSON.stringify(s, null, 2));
  return s;
}

function applied(s) {
  return s.patches.filter((p) => p.applied);
}

function unapplied(s) {
  return s.patches.filter((p) => !p.applied && !p.hidden);
}

function topPatch(s) {
  const a = applied(s);
  return a.length ? a[a.length - 1] : null;
}

function findPatch(s, name) {
  return s.patches.find((p) => p.name === name);
}

function currentUserTrailer(kind) {
  const n = git(["config", "user.name"], { check: false }).stdout.trim() || "Unknown";
  const e = git(["config", "user.email"], { check: false }).stdout.trim() || "unknown";
  return `${kind}: ${n} <${e}>`;
}

function parseMessage(args) {
  let msg = null;
  let file = null;
  let name = null;
  const rest = [];
  const trailers = [];
  let refresh = false;
  let index = false;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-m" || a === "--message") msg = args[++i] || "";
    else if (a === "-f" || a === "--file") file = args[++i];
    else if (a === "-n" || a === "--name") name = args[++i];
    else if (a === "-r" || a === "--refresh") refresh = true;
    else if (a === "-i" || a === "--index") index = true;
    else if (a === "-s" || a.startsWith("--signoff")) trailers.push(currentUserTrailer("Signed-off-by"));
    else if (a === "--ack" || a.startsWith("--ack=")) trailers.push(a.includes("=") ? `Acked-by: ${a.split("=").slice(1).join("=")}` : currentUserTrailer("Acked-by"));
    else if (a === "--review" || a.startsWith("--review=")) trailers.push(a.includes("=") ? `Reviewed-by: ${a.split("=").slice(1).join("=")}` : currentUserTrailer("Reviewed-by"));
    else if (a === "--") {
      rest.push(...args.slice(i + 1));
      break;
    } else if (a.startsWith("-")) {
      if (["--author", "--authname", "--authemail", "--authdate", "--save-template"].includes(a)) i++;
    } else rest.push(a);
  }
  if (file) msg = file === "-" ? fs.readFileSync(0, "utf8") : fs.readFileSync(file, "utf8");
  if (msg == null) msg = name || rest[0] || "New patch";
  if (trailers.length) msg = msg.replace(/\s*$/, "\n\n") + trailers.join("\n") + "\n";
  return { msg, name, rest, refresh, index };
}

function patchNameFromMessage(msg) {
  return (msg.split(/\r?\n/)[0] || "patch")
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "patch";
}

function uniqueName(s, base) {
  let n = base;
  let i = 2;
  while (findPatch(s, n)) n = `${base}-${i++}`;
  return n;
}

function commitAll(message, amend = false, allowEmpty = true) {
  git(["add", "-u"]);
  const args = ["commit"];
  if (amend) args.push("--amend");
  if (allowEmpty) args.push("--allow-empty");
  args.push("-m", message);
  const r = git(args, { check: false });
  if (r.status !== 0) {
    if (/nothing to commit|no changes added/.test(r.stdout + r.stderr)) return gitOut(["rev-parse", "HEAD"]);
    if (r.stderr) process.stderr.write(r.stderr);
    process.exit(r.status || 1);
  }
  return gitOut(["rev-parse", "HEAD"]);
}

function selectPatch(s, rev) {
  if (!rev) {
    const t = topPatch(s);
    return t ? t.commit : "HEAD";
  }
  if (rev === "{base}") return s.base;
  if (rev.endsWith("^") && findPatch(s, rev.slice(0, -1))) return `${findPatch(s, rev.slice(0, -1)).commit}^`;
  const p = findPatch(s, rev);
  return p ? p.commit : rev;
}

function cmdInit() {
  repoRoot();
  if (!fs.existsSync(statePath())) saveState(emptyState());
}

function cmdNew(args) {
  const s = loadState(true);
  const parsed = parseMessage(args);
  const dash = args.indexOf("--");
  const beforeDash = (dash >= 0 ? args.slice(0, dash) : args).filter((a, i, ar) => {
    const prev = ar[i - 1];
    return !a.startsWith("-") && !["-m", "--message", "-f", "--file", "-n", "--name"].includes(prev);
  });
  const afterDash = dash >= 0 ? args.slice(dash + 1) : [];
  const paths = afterDash.length ? afterDash : [];
  let name = parsed.name || beforeDash[0] || patchNameFromMessage(parsed.msg);
  if (args.includes("--name") || args.includes("-n")) name = parsed.name;
  name = uniqueName(s, name);
  if (parsed.refresh || paths.length) {
    if (parsed.index) {
      const r = git(["commit", "--allow-empty", "-m", parsed.msg], { check: false });
      if (r.status !== 0) commitAll(parsed.msg);
    } else {
      if (paths.length) git(["add", "--", ...paths]);
      else git(["add", "-u"]);
      git(["commit", "--allow-empty", "-m", parsed.msg]);
    }
  } else {
    git(["commit", "--allow-empty", "-m", parsed.msg]);
  }
  const commit = gitOut(["rev-parse", "HEAD"]);
  const idx = applied(s).length;
  s.patches.splice(idx, 0, { name, commit, applied: true, hidden: false, message: parsed.msg });
  saveState(s);
  out(`> ${name} (new)`);
}

function cmdRefresh(args) {
  const s = loadState();
  const t = topPatch(s);
  if (!t) die("no patches applied");
  const index = args.includes("-i") || args.includes("--index");
  const paths = args.filter((a) => !a.startsWith("-"));
  if (!index) {
    if (paths.length) git(["add", "--", ...paths]);
    else git(["add", "-u"]);
  }
  t.commit = commitAll(t.message || git(["log", "-1", "--format=%B"]).stdout, true);
  saveState(s);
  out("> refresh-temp (new)");
  out("- refresh-temp");
  out("# refresh-temp");
  out(`& ${t.name}`);
  out(`> ${t.name}`);
}

function cmdSeries(args) {
  const s = loadState();
  const showApplied = args.includes("-A") || args.includes("--applied");
  const showUnapplied = args.includes("-U") || args.includes("--unapplied");
  const count = args.includes("-c") || args.includes("--count");
  const desc = args.includes("-d") || args.includes("--description");
  const commitOpt = args.find((a) => a.startsWith("--commit-id")) || (args.includes("-i") ? "-i" : null);
  let list = s.patches.filter((p) => !p.hidden);
  if (showApplied) list = list.filter((p) => p.applied);
  if (showUnapplied) list = list.filter((p) => !p.applied);
  if (args.includes("--reverse")) list = list.slice().reverse();
  if (count) return out(String(list.length));
  const top = topPatch(s);
  for (const p of list) {
    let prefix = p.applied ? (top && p.name === top.name ? ">" : "+") : "-";
    let line = `${prefix} `;
    if (commitOpt) {
      let len = 40;
      const m = commitOpt.match(/=(\d+)/);
      if (m) len = Number(m[1]);
      line += `${p.commit.slice(0, len)} `;
    }
    line += p.name;
    if (desc) line += ` # ${(p.message || "").split(/\r?\n/)[0]}`;
    out(line);
  }
}

function cmdTop() {
  const t = topPatch(loadState());
  if (!t) die("no patches applied");
  out(t.name);
}

function cmdPrev() {
  const a = applied(loadState());
  if (a.length < 2) die("not enough patches applied");
  out(a[a.length - 2].name);
}

function cmdNext() {
  const u = unapplied(loadState());
  if (!u.length) die("no unapplied patches");
  out(u[0].name);
}

function cmdPop(args) {
  const s = loadState();
  let n = 1;
  if (args.includes("-a") || args.includes("--all")) n = applied(s).length;
  const ni = args.findIndex((a) => a === "-n" || a === "--number");
  if (ni >= 0) n = Number(args[ni + 1]);
  if (n < 0) n = Math.max(0, applied(s).length + n);
  for (let i = 0; i < n; i++) {
    const t = topPatch(s);
    if (!t) die("no patches applied");
    git(["reset", "--hard", "HEAD~1"], { stdio: ["ignore", "ignore", "pipe"] });
    t.applied = false;
    out(`- ${t.name}`);
  }
  const t = topPatch(s);
  if (t) out(`> ${t.name}`);
  saveState(s);
}

function cmdPush(args) {
  const s = loadState();
  let toPush = [];
  if (args.includes("-a") || args.includes("--all")) toPush = unapplied(s);
  else {
    const names = args.filter((a, i) => !a.startsWith("-") && args[i - 1] !== "-n" && args[i - 1] !== "--number");
    const ni = args.findIndex((a) => a === "-n" || a === "--number");
    if (ni >= 0) toPush = unapplied(s).slice(0, Number(args[ni + 1]));
    else if (names.length) toPush = names.map((n) => findPatch(s, n)).filter(Boolean);
    else toPush = unapplied(s).slice(0, 1);
  }
  if (args.includes("--reverse")) toPush = toPush.slice().reverse();
  if (!toPush.length) die("no unapplied patches");
  for (const p of toPush) {
    const r = git(["cherry-pick", p.commit], { check: false });
    if (r.status !== 0) {
      if (r.stderr) process.stderr.write(r.stderr);
      process.exit(r.status || 1);
    }
    p.commit = gitOut(["rev-parse", "HEAD"]);
    p.applied = true;
    out(`> ${p.name}`);
  }
  saveState(s);
}

function cmdRename(args) {
  const s = loadState();
  const names = args.filter((a) => !a.startsWith("-"));
  let oldName, newName;
  if (names.length === 1) {
    const t = topPatch(s);
    if (!t) die("no patches applied");
    oldName = t.name; newName = names[0];
  } else {
    oldName = names[0]; newName = names[1];
  }
  const p = findPatch(s, oldName);
  if (!p) die(`patch \`${oldName}\` not found`);
  p.name = newName;
  saveState(s);
  out(`${oldName} => ${newName}`);
  if (p.applied && topPatch(s).name === newName) out(`> ${newName}`);
}

function cmdDelete(args) {
  const s = loadState();
  let names = args.filter((a) => !a.startsWith("-"));
  if (args.includes("-t") || args.includes("--top")) {
    const t = topPatch(s);
    if (!t) die("no patches applied");
    names = [t.name];
  } else if (args.includes("-a") || args.includes("--all")) names = s.patches.map((p) => p.name);
  else if (!names.length) {
    const t = topPatch(s);
    if (!t) die("no patches applied");
    names = [t.name];
  }
  for (const n of names) {
    const idx = s.patches.findIndex((p) => p.name === n);
    if (idx < 0) die(`patch \`${n}\` not found`);
    const p = s.patches[idx];
    if (p.applied && topPatch(s).name === p.name) git(["reset", "--hard", "HEAD~1"], { stdio: ["ignore", "ignore", "pipe"] });
    s.patches.splice(idx, 1);
    out(`- ${p.name}`);
    out(`# ${p.name}`);
  }
  const t = topPatch(s);
  if (t) out(`> ${t.name}`);
  saveState(s);
}

function cmdFiles(args) {
  const s = loadState();
  const stat = args.includes("-s") || args.includes("--stat");
  const rev = args.filter((a) => !a.startsWith("-"))[0];
  const c = selectPatch(s, rev);
  const gargs = stat ? ["diff", "--stat", `${c}^`, c] : ["diff", "--name-status", `${c}^`, c];
  const r = git(gargs, { check: false });
  process.stdout.write(r.stdout);
}

function cmdDiff(args) {
  const s = fs.existsSync(statePath()) ? loadState() : null;
  const stat = args.includes("-s") || args.includes("--stat");
  const ri = args.findIndex((a) => a === "-r" || a === "--range");
  let gargs = ["diff"];
  if (stat) gargs.push("--stat");
  if (ri >= 0) {
    const [a, b] = args[ri + 1].split("..");
    gargs.push(s ? selectPatch(s, a) : a);
    if (b) gargs.push(s ? selectPatch(s, b) : b);
  }
  gargs.push(...args.filter((a, i) => !a.startsWith("-") && i !== ri + 1));
  const r = git(gargs, { check: false });
  process.stdout.write(r.stdout);
}

function cmdShow(args) {
  const s = loadState();
  const stat = args.includes("-s") || args.includes("--stat");
  const names = args.filter((a) => !a.startsWith("-"));
  const revs = names.length ? names.map((n) => selectPatch(s, n)) : [selectPatch(s)];
  const gargs = ["show", "--no-ext-diff"];
  if (stat) gargs.push("--stat");
  gargs.push(...revs);
  const r = git(gargs, { check: false });
  process.stdout.write(r.stdout);
}

function cmdId(args) {
  const s = loadState();
  const rev = args.filter((a) => !a.startsWith("-"))[0];
  out(gitOut(["rev-parse", selectPatch(s, rev)]));
}

function cmdName(args) {
  const s = loadState();
  const rev = args.filter((a) => !a.startsWith("-"))[0];
  if (!rev) return cmdTop();
  const id = gitOut(["rev-parse", rev]);
  const p = s.patches.find((x) => gitOut(["rev-parse", x.commit]) === id);
  if (!p) die("revision does not correspond to a patch");
  out(args.includes("--showbranch") ? `${branch()}:${p.name}` : p.name);
}

function cmdCommit(args) {
  const s = loadState();
  let n = 1;
  if (args.includes("-a") || args.includes("--all")) n = applied(s).length;
  const ni = args.findIndex((a) => a === "-n" || a === "--number");
  if (ni >= 0) n = Number(args[ni + 1]);
  const a = applied(s);
  const remove = new Set(a.slice(0, n).map((p) => p.name));
  s.patches = s.patches.filter((p) => !remove.has(p.name));
  if (!s.patches.some((p) => p.applied)) s.base = gitOut(["rev-parse", "HEAD"]);
  saveState(s);
}

function cmdUncommit(args) {
  const s = loadState(true);
  const ni = args.findIndex((a) => a === "-n" || a === "--number");
  let n = ni >= 0 ? Number(args[ni + 1]) : args.filter((a) => !a.startsWith("-")).length || 1;
  const names = args.filter((a, i) => !a.startsWith("-") && i !== ni + 1);
  const commits = gitOut(["rev-list", "--max-count=" + n, "HEAD"]).split(/\n/).filter(Boolean);
  commits.reverse();
  const newP = commits.map((c, i) => ({
    name: uniqueName(s, names[i] || patchNameFromMessage(git(["log", "-1", "--format=%s", c]).stdout.trim())),
    commit: c,
    applied: true,
    hidden: false,
    message: git(["log", "-1", "--format=%B", c]).stdout,
  }));
  s.base = gitOut(["rev-parse", `${commits[0]}^`]);
  s.patches = [...newP, ...s.patches];
  saveState(s);
}

function cmdClean(args) {
  const s = loadState();
  const keep = [];
  for (const p of s.patches) {
    const same = git(["diff", "--quiet", `${p.commit}^`, p.commit], { check: false }).status === 0;
    if (same) out(`# ${p.name}`);
    else keep.push(p);
  }
  s.patches = keep;
  saveState(s);
}

function cmdBranch(args) {
  if (!args.length) return out(branch());
  if (args.includes("-l") || args.includes("--list")) return process.stdout.write(git(["branch"]).stdout);
  const ci = args.findIndex((a) => a === "-c" || a === "--create");
  if (ci >= 0) {
    git(["checkout", "-b", args[ci + 1], args[ci + 2]].filter(Boolean));
    saveState(emptyState());
    return;
  }
  const ri = args.findIndex((a) => a === "-r" || a === "--rename");
  if (ri >= 0) return git(["branch", "-m", ...args.slice(ri + 1)], { stdio: "inherit" });
  const di = args.findIndex((a) => a === "-D" || a === "--delete");
  if (di >= 0) return git(["branch", "-D", args[di + 1] || branch()], { stdio: "inherit" });
  git(["checkout", args[args.length - 1]], { stdio: "inherit" });
}

function version(short = false) {
  if (short) out("2.5.5");
  else out("Stacked Git 2.5.5\nCopyright (C) 2005-2025 StGit authors\nThis is free software: you are free to change and redistribute it.\nThere is NO WARRANTY, to the extent permitted by law.\nSPDX-License-Identifier: GPL-2.0-only\n" + git(["--version"]).stdout.trim());
}

function help() {
  out(`Maintain a stack of patches on top of a Git branch.

Usage: stg [OPTIONS] <command> [...]
       stg [OPTIONS] <-h|--help>
       stg --version

Patch inspection commands:
  diff   Show a diff
  files  Show files modified by a patch
  id     Print git hash of a StGit revision
  name   Print patch name of a StGit revision
  show   Show patch commits

Patch manipulation commands:
  new      Create a new patch at top of the stack
  refresh  Incorporate worktree changes into current patch
  rename   Rename a patch

Stack inspection commands:
  next     Print the name of the next patch
  prev     Print the name of the previous patch
  series   Display the patch series
  top      Print the name of the top patch

Stack manipulation commands:
  branch    Branch operations: switch, list, create, rename, delete, ...
  clean     Delete empty patches from the series
  commit    Finalize patches to the stack base
  delete    Delete patches
  goto      Go to patch by pushing or popping as necessary
  init      Initialize a StGit stack on a branch
  pop       Pop (unapply) one or more applied patches
  push      Push (apply) one or more unapplied patches
  uncommit  Convert regular Git commits into StGit patches

Administration commands:
  version     Print version information and exit

Aliases:
  add       Alias for shell command \`git -C "$GIT_PREFIX" add\`
  mv        Alias for shell command \`git -C "$GIT_PREFIX" mv\`
  resolved  Alias for shell command \`git -C "$GIT_PREFIX" add\`
  rm        Alias for shell command \`git -C "$GIT_PREFIX" rm\`
  status    Alias for shell command \`git status -s\``);
}

function main() {
  let args = process.argv.slice(2);
  for (;;) {
    const i = args.indexOf("-C");
    if (i < 0) break;
    process.chdir(args[i + 1]);
    args.splice(i, 2);
  }
  args = args.filter((a) => !a.startsWith("--color"));
  if (!args.length || args[0] === "-h" || args[0] === "--help" || args[0] === "help") return help();
  if (args[0] === "--version") return version(false);
  const cmd = args.shift();
  if (args.includes("-h") || args.includes("--help")) return help();
  if (["add", "resolved"].includes(cmd)) return git(["add", ...args], { stdio: "inherit" });
  if (cmd === "rm") return git(["rm", ...args], { stdio: "inherit" });
  if (cmd === "mv") return git(["mv", ...args], { stdio: "inherit" });
  if (cmd === "status") return git(["status", "-s", ...args], { stdio: "inherit" });
  const table = { init: cmdInit, new: cmdNew, refresh: cmdRefresh, series: cmdSeries, top: cmdTop, prev: cmdPrev, next: cmdNext, pop: cmdPop, push: cmdPush, rename: cmdRename, delete: cmdDelete, files: cmdFiles, diff: cmdDiff, show: cmdShow, id: cmdId, name: cmdName, commit: cmdCommit, uncommit: cmdUncommit, clean: cmdClean, branch: cmdBranch };
  if (cmd === "version") return version(args.includes("-s") || args.includes("--short"));
  if (cmd === "goto") {
    const target = args.find((a) => !a.startsWith("-"));
    const s = loadState();
    const idx = s.patches.findIndex((p) => p.name === target);
    if (idx < 0) die(`patch \`${target}\` not found`);
    while (topPatch(s) && s.patches.findIndex((p) => p.name === topPatch(s).name) > idx) cmdPop([]);
    while (!s.patches[idx].applied) cmdPush([s.patches.find((p) => !p.applied).name]);
    return;
  }
  if (!table[cmd]) die(`unrecognized subcommand '${cmd}'`);
  return table[cmd](args);
}

main();
