#!/usr/bin/env node
'use strict';

const fs = require('fs');
const http = require('http');
const https = require('https');
const zlib = require('zlib');
const path = require('path');

const VERSION = '0.25.3';
const SHORT_HELP = `xh is a friendly and fast tool for sending HTTP requests

Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...

Arguments:
  <[METHOD] URL>     The request URL, preceded by an optional HTTP method
  [REQUEST_ITEM]...  Optional key-value pairs to be included in the request.

Options:
  -j, --json                 (default) Serialize data items from the command line as a JSON object
  -f, --form                 Serialize data items from the command line as form fields
      --multipart            Like --form, but force a multipart/form-data request even without files
      --raw <RAW>            Pass raw request data without extra processing
      --pretty <STYLE>       Controls output processing [possible values: all, colors, format, none]
      --format-options <FORMAT_OPTIONS>
                             Set output formatting options
  -s, --style <THEME>        Output coloring style [possible values: auto, solarized, monokai, fruity]
      --response-charset <ENCODING>
                             Override the response encoding for terminal display purposes
      --response-mime <MIME_TYPE>
                             Override the response mime type for coloring and formatting for the terminal
  -p, --print <FORMAT>       String specifying what the output should contain
  -h, --headers              Print only the response headers. Shortcut for --print=h
  -b, --body                 Print only the response body. Shortcut for --print=b
  -m, --meta                 Print only the response metadata. Shortcut for --print=m
  -v, --verbose...           Print the whole request as well as the response
      --debug                Print full error stack traces and debug log messages
      --all                  Show any intermediary requests/responses while following redirects with --follow
  -P, --history-print <FORMAT>
                             The same as --print but applies only to intermediary requests/responses
  -q, --quiet...             Do not print to stdout or stderr
  -S, --stream               Always stream the response body
  -x, --compress...          Content compressed (encoded) with Deflate algorithm
  -o, --output <FILE>        Save output to FILE instead of stdout
  -d, --download             Download the body to a file instead of printing it
  -c, --continue             Resume an interrupted download. Requires --download and --output
      --session <FILE>       Create, or reuse and update a session
      --session-read-only <FILE>
                             Create or read a session without updating it from the request/response exchange
  -A, --auth-type <AUTH_TYPE>
                             Specify the auth mechanism [possible values: basic, bearer, digest]
  -a, --auth <USER[:PASS] | TOKEN>
                             Authenticate as USER with PASS (-A basic|digest) or with TOKEN (-A bearer)
      --ignore-netrc         Do not use credentials from .netrc
      --offline              Construct HTTP requests without sending them anywhere
      --check-status         (default) Exit with an error status code if the server replies with an error
  -F, --follow               Do follow redirects
      --max-redirects <NUM>  Number of redirects to follow. Only respected if --follow is used
      --timeout <SEC>        Connection timeout of the request
      --proxy <PROTOCOL:URL> Use a proxy for a protocol. For example: --proxy https:http://proxy.host:8080
      --verify <VERIFY>      If "no", skip SSL verification. If a file path, use it as a CA bundle
      --cert <FILE>          Use a client side certificate for SSL
      --cert-key <FILE>      A private key file to use with --cert
      --ssl <VERSION>        Force a particular TLS version [possible values: auto, tls1, tls1.1, tls1.2, tls1.3]
      --https                Make HTTPS requests if not specified in the URL
      --http-version <VERSION>
                             HTTP version to use [possible values: 1.0, 1.1, 2, 2-prior-knowledge, 3-prior-knowledge]
      --resolve <HOST:ADDRESS>
                             Override DNS resolution for specific domain to a custom IP
      --interface <NAME>     Bind to a network interface or local IP address
  -4, --ipv4                 Resolve hostname to ipv4 addresses only
  -6, --ipv6                 Resolve hostname to ipv6 addresses only
      --unix-socket <FILE>   Connect using a Unix domain socket
  -I, --ignore-stdin         Do not attempt to read stdin
      --curl                 Print a translation to a curl command
      --curl-long            Use the long versions of curl's flags
      --generate <KIND>      Generate shell completions or man pages
      --help                 Print help
  -V, --version              Print version

Each option can be reset with a --no-OPTION argument.

Run "xh help" for more complete documentation.`;
const LONG_HELP = `xh is a friendly and fast tool for sending HTTP requests.

It reimplements as much as possible of HTTPie's excellent design, with a focus on improved
performance.

Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...

Arguments:
  <[METHOD] URL>
          The request URL, preceded by an optional HTTP method.

          If the method is omitted, it will default to GET, or to POST if the request contains a
          body.

          The URL scheme defaults to "http://" normally, or "https://" if the program is invoked as
          "xhs".

          A leading colon works as shorthand for localhost. ":8000" is equivalent to
          "localhost:8000", and ":/path" is equivalent to "localhost/path".

  [REQUEST_ITEM]...
          Optional key-value pairs to be included in the request.

          The separator is used to determine the type:

              key==value      Add a query string to the URL.
              key=value       Add a JSON property (--json) or form field (--form) to the request body.
              key:=value      Add a field with a literal JSON value to the request body.
              key@filename    Upload a file (requires --form or --multipart).
              @filename       Use a file as the request body.
              header:value    Add a header, e.g. "user-agent:foobar"
              header:         Unset a header, e.g. "connection:"
              header;         Add a header with an empty value.

Options:
${SHORT_HELP.split('Options:\n')[1]}`;

function stdout(s){ process.stdout.write(s); }
function stderr(s){ process.stderr.write(s); }
function die(msg, code=1){ stderr(`executable: error: ${msg}\n`); process.exit(code); }
function clapDie(msg){ stderr(`error: ${msg}\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.\n`); process.exit(2); }
function quoteSh(s){ return `'${String(s).replace(/'/g, `'\\''`)}'`; }
function isMethod(s){ return /^[A-Za-z]+$/.test(s) && ['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS','TRACE','CONNECT'].includes(s.toUpperCase()); }
function readStdin(){ try { return fs.readFileSync(0); } catch { return Buffer.alloc(0); } }
function hasValue(args, i){ if (i+1 >= args.length) clapDie(`a value is required for '${args[i]}' but none was supplied`); return args[++i]; }

function parseArgs(argv){
  const opt = {mode:'json', pretty:null, print:null, verbose:0, quiet:0, headers:false, body:false, meta:false,
    offline:false, curl:false, curlLong:false, ignoreStdin:false, https:false, follow:false, maxRedirects:10,
    output:null, download:false, cont:false, raw:null, auth:null, authType:'basic', formatOptions:{jsonIndent:4,jsonFormat:true,headersSort:true},
    generate:null, timeout:0, verify:'yes', httpVersion:'1.1', compress:0, session:null, sessionReadOnly:null,
    responseMime:null, responseCharset:null, all:false, historyPrint:null, debug:false, proxy:[], resolve:[], interface:null,
    unixSocket:null, ipv4:false, ipv6:false};
  const pos=[]; let stop=false;
  for (let i=0;i<argv.length;i++){
    let a=argv[i];
    if (stop){ pos.push(a); continue; }
    if (a==='--'){ stop=true; continue; }
    if (a==='help'){ opt.helpLong=true; continue; }
    if (a==='--help'){ opt.help=true; continue; }
    if (a==='-V'||a==='--version'){ opt.version=true; continue; }
    if (a.startsWith('--no-')){ const n=a.slice(5); if(n==='check-status') opt.noCheckStatus=true; else if(n==='follow') opt.follow=false; else if(n==='json'){} else if(n==='form'){} else if(n==='multipart'){}; continue; }
    if (a.startsWith('--') && a.includes('=')) { const [k,...rest]=a.split('='); argv.splice(i,1,k,rest.join('=')); i--; continue; }
    if (a==='-j'||a==='--json'){ opt.mode='json'; continue; }
    if (a==='-f'||a==='--form'){ opt.mode='form'; continue; }
    if (a==='--multipart'){ opt.mode='multipart'; continue; }
    if (a==='--raw'){ opt.raw=hasValue(argv,i); i++; continue; }
    if (a==='--pretty'){ opt.pretty=hasValue(argv,i); i++; continue; }
    if (a==='--format-options'){ parseFormatOptions(opt, hasValue(argv,i)); i++; continue; }
    if (a==='-s'||a==='--style'||a==='--response-charset'||a==='--response-mime'||a==='--ssl'||a==='--http-version'||a==='--verify'||a==='--cert'||a==='--cert-key'||a==='--proxy'||a==='--resolve'||a==='--interface'||a==='--unix-socket'||a==='--timeout'||a==='--max-redirects'||a==='-P'||a==='--history-print'||a==='--session'||a==='--session-read-only'||a==='--generate'||a==='-A'||a==='--auth-type'||a==='-a'||a==='--auth'||a==='-o'||a==='--output'){
      const v=hasValue(argv,i); i++;
      if(a==='-p'||a==='--print') opt.print=v;
      else if(a==='--response-mime') opt.responseMime=v; else if(a==='--response-charset') opt.responseCharset=v;
      else if(a==='--http-version') opt.httpVersion=v; else if(a==='--verify') opt.verify=v;
      else if(a==='--proxy') opt.proxy.push(v); else if(a==='--resolve') opt.resolve.push(v); else if(a==='--interface') opt.interface=v;
      else if(a==='--unix-socket') opt.unixSocket=v; else if(a==='--timeout') opt.timeout=Number(v)||0; else if(a==='--max-redirects') opt.maxRedirects=Number(v)||0;
      else if(a==='-P'||a==='--history-print') opt.historyPrint=v; else if(a==='--session') opt.session=v; else if(a==='--session-read-only') opt.sessionReadOnly=v;
      else if(a==='--generate') opt.generate=v; else if(a==='-A'||a==='--auth-type') opt.authType=v; else if(a==='-a'||a==='--auth') opt.auth=v; else if(a==='-o'||a==='--output') opt.output=v;
      continue;
    }
    if (a==='-p'||a==='--print'){ opt.print=hasValue(argv,i); i++; continue; }
    if (a==='-h'||a==='--headers'){ opt.print='h'; continue; }
    if (a==='-b'||a==='--body'){ opt.print='b'; continue; }
    if (a==='-m'||a==='--meta'){ opt.print='m'; continue; }
    if (a==='-v'||a==='--verbose'){ opt.verbose++; opt.all=true; continue; }
    if (/^-v{2,}$/.test(a)){ opt.verbose += a.length-1; opt.all=true; continue; }
    if (a==='--debug'){ opt.debug=true; continue; }
    if (a==='--all'){ opt.all=true; continue; }
    if (a==='-q'||a==='--quiet'){ opt.quiet++; continue; }
    if (/^-q{2,}$/.test(a)){ opt.quiet += a.length-1; continue; }
    if (a==='-S'||a==='--stream'){ opt.stream=true; continue; }
    if (a==='-x'||a==='--compress'){ opt.compress++; continue; }
    if (/^-x{2,}$/.test(a)){ opt.compress += a.length-1; continue; }
    if (a==='-d'||a==='--download'){ opt.download=true; continue; }
    if (a==='-c'||a==='--continue'){ opt.cont=true; continue; }
    if (a==='--ignore-netrc'){ opt.ignoreNetrc=true; continue; }
    if (a==='--offline'){ opt.offline=true; continue; }
    if (a==='--check-status'){ opt.noCheckStatus=false; continue; }
    if (a==='-F'||a==='--follow'){ opt.follow=true; continue; }
    if (a==='--https'){ opt.https=true; continue; }
    if (a==='-4'||a==='--ipv4'){ opt.ipv4=true; continue; }
    if (a==='-6'||a==='--ipv6'){ opt.ipv6=true; continue; }
    if (a==='-I'||a==='--ignore-stdin'){ opt.ignoreStdin=true; continue; }
    if (a==='--curl'){ opt.curl=true; continue; }
    if (a==='--curl-long'){ opt.curl=true; opt.curlLong=true; continue; }
    if (a.startsWith('-')) clapDie(`unexpected argument '${a}' found`);
    pos.push(a);
  }
  opt.pos = pos;
  return opt;
}
function parseFormatOptions(opt, str){
  for (const p of str.split(',')){
    const [k,v] = p.split(':');
    if(k==='json.indent') opt.formatOptions.jsonIndent=Math.max(0, Number(v)||0);
    if(k==='json.format') opt.formatOptions.jsonFormat=(v!=='false');
    if(k==='headers.sort') opt.formatOptions.headersSort=(v!=='false');
  }
}
function normalizeUrl(s,opt){
  if (s.startsWith(':/')) s = 'localhost' + s.slice(1);
  else if (s.startsWith(':')) s = 'localhost:' + s.slice(1);
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = (opt.https?'https://':'http://') + s;
  const u = new URL(s);
  if (!u.pathname) u.pathname='/';
  return u;
}
function splitItem(item){
  let esc=false;
  for(let i=0;i<item.length;i++){
    const c=item[i];
    if(esc){ esc=false; continue; }
    if(c==='\\'){ esc=true; continue; }
    if(c==='=' && item[i+1]==='=') return [item.slice(0,i).replace(/\\([:=@;])/g,'$1'),'==',item.slice(i+2)];
    if(c===':' && item[i+1]==='=') return [item.slice(0,i).replace(/\\([:=@;])/g,'$1'),':=',item.slice(i+2)];
    if(c==='=' ) return [item.slice(0,i).replace(/\\([:=@;])/g,'$1'),'=',item.slice(i+1)];
    if(c==='@' && i>0) return [item.slice(0,i).replace(/\\([:=@;])/g,'$1'),'@',item.slice(i+1)];
    if(c===':') return [item.slice(0,i).replace(/\\([:=@;])/g,'$1'),':',item.slice(i+1)];
    if(c===';' && i===item.length-1) return [item.slice(0,i).replace(/\\([:=@;])/g,'$1'),';',''];
  }
  if(item.startsWith('@')) return ['','@body',item.slice(1)];
  return [item,'arg',''];
}
function readAtValue(v){ if(v.startsWith('@')) return fs.readFileSync(v.slice(1),'utf8').replace(/\r?\n$/,''); return v; }
function setJsonPath(obj,key,val){
  const parts=[]; let cur='';
  for(let i=0;i<key.length;i++){ const c=key[i]; if(c==='.'||c==='['||c===']'){ if(cur){parts.push(cur);cur='';} } else cur+=c; }
  if(cur) parts.push(cur);
  let o=obj;
  for(let i=0;i<parts.length-1;i++){ const p=parts[i]; const next=/^\d+$/.test(parts[i+1])?[]:{}; if(o[p]===undefined) o[p]=next; o=o[p]; }
  o[parts[parts.length-1]]=val;
}
function buildRequest(opt){
  let pos = opt.pos.slice();
  if(pos.length===0) { stderr(`error: the following required arguments were not provided:\n  <[METHOD] URL>\n\nUsage: executable <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.\n`); process.exit(2); }
  let method=null, urlS;
  if(pos.length>=2 && isMethod(pos[0])) { method=pos.shift().toUpperCase(); urlS=pos.shift(); } else { urlS=pos.shift(); }
  const u=normalizeUrl(urlS,opt);
  const headers=[]; const hmap=new Map(); const userHeaderKeys=[]; const query=[]; const fields=[]; const json={}; const files=[]; let bodyFile=null;
  for(const it of pos){
    const [k,sep,v0]=splitItem(it); let v=v0;
    if(sep==='==') query.push([k, readAtValue(v)]);
    else if(sep==='=') { v=readAtValue(v); fields.push([k,v,false]); setJsonPath(json,k,v); }
    else if(sep===':=') { if(opt.mode==='form'||opt.mode==='multipart') die('JSON values are not supported in Form fields'); let val; try{ val=JSON.parse(v); }catch{ die(`'${k}:=${v}' is not a valid JSON literal`); } fields.push([k,val,true]); setJsonPath(json,k,val); }
    else if(sep==='@') files.push([k,v]);
    else if(sep==='@body') bodyFile=v;
    else if(sep===':') { const name=canonicalHeader(k); const lk=name.toLowerCase(); if(v==='') hmap.delete(lk); else { if(!hmap.has(lk)) userHeaderKeys.push(lk); hmap.set(lk, [name, v.startsWith('@')?readAtValue(v):v]); } }
    else if(sep===';') { const name=canonicalHeader(k); const lk=name.toLowerCase(); if(!hmap.has(lk)) userHeaderKeys.push(lk); hmap.set(lk, [name, '']); }
    else fields.push([k,'',false]);
  }
  for(const [k,v] of query) u.searchParams.append(k,v);
  let stdinBody=null; const stdinPresent=(!opt.ignoreStdin && !process.stdin.isTTY);
  if(stdinPresent){ stdinBody=readStdin(); }
  if(stdinPresent && (fields.length||files.length)) die('Request body (from stdin) and request data (key=value) cannot be mixed. Pass --ignore-stdin to ignore standard input.');
  if(stdinPresent && opt.raw!==null) die('Request body from stdin and --raw cannot be mixed. Pass --ignore-stdin to ignore standard input.');
  if(bodyFile && (fields.length||files.length||opt.raw!==null)) die('Request body from file and request data cannot be mixed.');
  let body=null;
  if(opt.raw!==null) body=Buffer.from(opt.raw);
  else if(bodyFile) body=fs.readFileSync(bodyFile);
  else if(stdinBody && stdinBody.length>0) body=stdinBody;
  else if(files.length) { opt.mode='multipart'; body=makeMultipart(fields, files, hmap); }
  else if(fields.length){
    if(opt.mode==='form') body=Buffer.from(new URLSearchParams(fields.map(f=>[f[0],String(f[1])])).toString());
    else if(opt.mode==='multipart') body=makeMultipart(fields, [], hmap);
    else body=Buffer.from(JSON.stringify(json));
  }
  if(!method) method = body ? 'POST' : 'GET';
  function putDefault(k,v){ const lk=k.toLowerCase(); if(!hmap.has(lk)) hmap.set(lk,[k,v]); }
  putDefault('Accept-Encoding','gzip, deflate, br, zstd');
  putDefault('User-Agent',`xh/${VERSION}`);
  putDefault('Connection','keep-alive');
  putDefault('Accept', body && opt.mode==='json' ? 'application/json, */*;q=0.5' : '*/*');
  if(body && (opt.mode==='json'||opt.raw!==null)) putDefault('Content-Type','application/json');
  if(body && opt.mode==='form') putDefault('Content-Type','application/x-www-form-urlencoded');
  if(body && opt.mode==='multipart'){};
  if(opt.auth){
    if(opt.authType==='bearer') putDefault('Authorization',`Bearer ${opt.auth}`);
    else putDefault('Authorization',`Basic ${Buffer.from(opt.auth).toString('base64')}`);
  }
  if(body) putDefault('Content-Length', String(body.length));
  putDefault('Host', hostHeader(u));
  const order=['accept-encoding','user-agent','connection','accept','content-type',...userHeaderKeys,'authorization','content-length','host'];
  const finalHeaders=[]; const seen=new Set();
  for(const k of order){ if(hmap.has(k) && !seen.has(k)){ finalHeaders.push(hmap.get(k)); seen.add(k); } }
  for(const [k,v] of hmap){ if(!seen.has(k)) finalHeaders.push(v); }
  return {method,url:u,headers:finalHeaders,body,opt};
}
function canonicalHeader(k){ return k.split('-').map(p=>p?p[0].toUpperCase()+p.slice(1).toLowerCase():p).join('-'); }
function hostHeader(u){ return u.port ? `${u.hostname}:${u.port}` : u.hostname; }
function makeMultipart(fields, files, hmap){
  const boundary='------------------------'+Math.random().toString(16).slice(2,18);
  hmap.set('content-type',['Content-Type',`multipart/form-data; boundary=${boundary}`]);
  const chunks=[];
  for(const [k,v] of fields){ chunks.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`)); }
  for(const [k,spec] of files){ const [filePart,...params]=spec.split(';'); const filenameParam=params.find(p=>p.startsWith('filename=')); const typeParam=params.find(p=>p.startsWith('type=')); const fn=filenameParam?filenameParam.slice(9):path.basename(filePart); const type=typeParam?typeParam.slice(5):'application/octet-stream'; chunks.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"; filename="${fn}"\r\nContent-Type: ${type}\r\n\r\n`)); chunks.push(fs.readFileSync(filePart)); chunks.push(Buffer.from('\r\n')); }
  chunks.push(Buffer.from(`--${boundary}--\r\n`)); return Buffer.concat(chunks);
}
function requestHead(req){
  const pathq = (req.url.pathname || '/') + req.url.search;
  let s=`${req.method} ${pathq} HTTP/1.1\n`;
  for(const [k,v] of req.headers) s += `${k}: ${v}\n`;
  return s+'\n';
}
function responseHead(res){
  let msg = res.statusMessage || statusText(res.statusCode);
  let s=`HTTP/${res.httpVersion||'1.1'} ${res.statusCode} ${msg}\n`;
  const pairs=[];
  for(let i=0;i<res.rawHeaders.length;i+=2) pairs.push([res.rawHeaders[i],res.rawHeaders[i+1]]);
  for(const [k,v] of pairs) s += `${k}: ${v}\n`;
  return s+'\n';
}
function formatBody(buf, headers, opt){
  const text=buf.toString(opt.responseCharset && /latin-?1/i.test(opt.responseCharset)?'latin1':'utf8');
  const ctype=(opt.responseMime || headerLookup(headers,'content-type') || '').toLowerCase();
  const pretty = opt.pretty || (!process.stdout.isTTY ? 'none' : 'all');
  if(opt.formatOptions.jsonFormat && pretty!=='none' && (ctype.includes('json') || /^[\s\r\n]*[\[{]/.test(text))){ try { return JSON.stringify(JSON.parse(text), null, opt.formatOptions.jsonIndent)+'\n'; } catch{} }
  return text;
}
function headerLookup(headers,name){ name=name.toLowerCase(); if(Array.isArray(headers)){ for(const [k,v] of headers) if(k.toLowerCase()===name) return v; } return ''; }
function curl(req){
  const long=req.opt.curlLong; const parts=['curl'];
  if(req.method!=='GET') parts.push(long?'--request':'-X', req.method);
  parts.push(quoteSh(req.url.href));
  for(const [k,v] of req.headers){ const kl=k.toLowerCase(); if(['host','user-agent','connection','accept-encoding','content-length'].includes(kl)) continue; if(kl==='authorization' && req.opt.authType==='bearer' && req.opt.auth){ parts.push('--oauth2-bearer', req.opt.auth); continue; } parts.push(long?'--header':'-H', quoteSh(`${k.toLowerCase()}: ${v}`)); }
  if(req.body) parts.push(long?'--data':'-d', quoteSh(req.body.toString()));
  return parts.join(' ')+'\n';
}
function generate(kind){
  if(kind==='man') { stdout(`.TH XH 1 2026-05-28 ${VERSION} "User Commands"\n.SH NAME\nxh \\- Friendly and fast tool for sending HTTP requests\n.SH SYNOPSIS\n.B xh\n[OPTIONS] [METHOD] URL [REQUEST_ITEM ...]\n.SH DESCRIPTION\n${LONG_HELP.replace(/\n/g,'\n.br\n')}\n`); return; }
  stdout(`# ${kind} completions for xh\n`);
}
function statusText(c){ return http.STATUS_CODES[c] || ''; }
async function send(req, redirects=0){
  const lib=req.url.protocol==='https:'?https:http;
  const options={method:req.method, headers:Object.fromEntries(req.headers.filter(([k])=>k.toLowerCase()!=='host')), timeout:req.opt.timeout?req.opt.timeout*1000:0};
  if(req.opt.unixSocket) options.socketPath=req.opt.unixSocket;
  if(req.opt.verify==='no'||req.opt.verify==='false') options.rejectUnauthorized=false;
  return new Promise((resolve)=>{
    const r=lib.request(req.url, options, res=>{
      const chunks=[]; res.on('data',d=>chunks.push(d)); res.on('end',async()=>{
        let buf=Buffer.concat(chunks);
        const enc=(res.headers['content-encoding']||'').toLowerCase();
        try{ if(enc.includes('gzip')) buf=zlib.gunzipSync(buf); else if(enc.includes('deflate')) buf=zlib.inflateSync(buf); else if(enc.includes('br')) buf=zlib.brotliDecompressSync(buf); }catch{}
        if(req.opt.follow && [301,302,303,307,308].includes(res.statusCode) && res.headers.location && redirects<req.opt.maxRedirects){
          const nu=new URL(res.headers.location, req.url); req.url=nu; if(res.statusCode===303){req.method='GET'; req.body=null;} resolve(await send(req, redirects+1)); return;
        }
        resolve({res,body:buf});
      });
    });
    r.on('timeout',()=>{ r.destroy(new Error('operation timed out')); });
    r.on('error',e=>{ if(req.opt.quiet<1) stderr(`executable: error: ${e.message}\n`); process.exit(1); });
    if(req.body) r.write(req.body); r.end();
  });
}
async function main(){
  const opt=parseArgs(process.argv.slice(2));
  if(opt.version){ stdout(`xh ${VERSION}\n-native-tls +rustls\n`); return; }
  if(opt.help){ stdout(SHORT_HELP+'\n'); return; }
  if(opt.helpLong){ stdout(LONG_HELP+'\n'); return; }
  if(opt.generate){ generate(opt.generate); return; }
  const req=buildRequest(opt);
  if(opt.quiet>0) return;
  if(opt.curl){ stdout(curl(req)); return; }
  if(opt.offline){ stdout(requestHead(req)); if(req.body) stdout(req.body.toString()+"\n"); return; }
  const out=await send(req);
  const print = opt.print || (opt.verbose>0 ? (opt.verbose>1?'HhBbm':'HhBb') : 'hb');
  let result='';
  if(print.includes('H')) result += requestHead(req);
  if(print.includes('B') && req.body) result += req.body.toString()+"\n";
  if(print.includes('m')) result += `HTTP ${out.res.statusCode} ${statusText(out.res.statusCode)}\n`;
  if(print.includes('h')) result += responseHead(out.res);
  if(print.includes('b')) result += formatBody(out.body, Object.entries(out.res.headers), opt);
  if(opt.download){ const fn=opt.output || path.basename(req.url.pathname) || 'index.html'; fs.writeFileSync(fn,out.body); }
  else if(opt.output) fs.writeFileSync(opt.output,result); else stdout(result);
  if(!opt.noCheckStatus){ if(out.res.statusCode>=500) process.exit(5); if(out.res.statusCode>=400) process.exit(4); if(out.res.statusCode>=300 && !opt.follow) process.exit(3); }
}
main().catch(e=>{ stderr(`executable: error: ${e.message}\n`); process.exit(1); });
