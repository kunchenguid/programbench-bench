#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "3.7.0";
const BORDER = "───────────────────────────────────────────────────────────────────────────────";
const WIDE_BORDER = "─────────────────────────────────────────────────────────────────────────────────────────────────────────────";

const languages = [
  ["ABAP", ["abap"]], ["ABNF", ["abnf"]], ["ActionScript", ["as"]], ["Ada", ["ada","adb","ads","pad"]],
  ["Agda", ["agda"]], ["Alex", ["x"]], ["Android Interface Definition Language", ["aidl"]],
  ["Apex", ["apex","trigger"]], ["AsciiDoc", ["adoc"]], ["ASP", ["asa","asp"]],
  ["ASP.NET", ["asax","ascx","asmx","aspx","master","sitemap","webinfo"]], ["Assembly", ["s","asm"]],
  ["Astro", ["astro"]], ["Autoconf", ["in"]], ["AWK", ["awk"]], ["BASH", ["bash","bash_login","bash_logout","bash_profile","bashrc",".bash_login",".bash_logout",".bash_profile",".bashrc","sh"]],
  ["Batch", ["bat","btm","cmd"]], ["Bazel", ["bzl","build.bazel","build","workspace"]], ["C", ["c","ec","pgc"]],
  ["C Header", ["h"]], ["C Shell", ["csh",".cshrc"]], ["C#", ["cs","csx"]], ["C++", ["cc","cpp","cxx","c++","pcc","ino"]],
  ["C++ Header", ["hh","hpp","hxx","h++","inl","ipp","ixx","tpp"]], ["CMake", ["cmake","cmakelists.txt"]],
  ["COBOL", ["cob","cbl","ccp","cobol","cpy"]], ["CoffeeScript", ["coffee"]], ["Clojure", ["clj","cljc"]],
  ["Crystal", ["cr"]], ["CSS", ["css"]], ["CSV", ["csv"]], ["Cuda", ["cu","cuh"]], ["Cython", ["pyx","pxi","pxd"]],
  ["D", ["d"]], ["Dart", ["dart"]], ["Dockerfile", ["dockerfile","containerfile"]], ["Elixir", ["ex","exs"]],
  ["Elm", ["elm"]], ["Erlang", ["erl","hrl"]], ["F#", ["fs","fsi","fsx"]], ["Fortran", ["f","for","f90","f95","f03"]],
  ["Go", ["go"]], ["GraphQL", ["graphql","gql"]], ["Groovy", ["groovy","gradle"]], ["HAML", ["haml"]],
  ["Handlebars", ["hbs","handlebars"]], ["Haskell", ["hs","lhs"]], ["HTML", ["htm","html","xhtml"]],
  ["INI", ["ini"]], ["Java", ["java"]], ["JavaScript", ["js","jsx","mjs","cjs"]], ["JSON", ["json"]],
  ["JSX", ["jsx"]], ["Julia", ["jl"]], ["Kotlin", ["kt","kts"]], ["LESS", ["less"]],
  ["License", ["license","licence","copying","copying.md"]], ["Lua", ["lua"]], ["Makefile", ["makefile","gnumakefile","mk"]],
  ["Markdown", ["md","markdown","mkd"]], ["MATLAB", ["m"]], ["MSBuild", ["csproj","vbproj","vcxproj","fsproj"]],
  ["Nim", ["nim"]], ["Nix", ["nix"]], ["Objective C", ["m"]], ["OCaml", ["ml","mli"]], ["Perl", ["pl","pm","t"]],
  ["PHP", ["php","php3","php4","php5","phtml"]], ["Plain Text", ["txt","text"]], ["PowerShell", ["ps1","psm1","psd1"]],
  ["Protocol Buffers", ["proto"]], ["Python", ["py","pyw"]], ["R", ["r","R"]], ["Razor", ["cshtml","vbhtml"]],
  ["ReStructuredText", ["rst"]], ["Ruby", ["rb","rake","gemspec"]], ["Rust", ["rs"]], ["Sass", ["sass","scss"]],
  ["Scala", ["scala","sbt"]], ["Shell", ["sh","ksh","zsh"]], ["SQL", ["sql"]], ["Svelte", ["svelte"]],
  ["Swift", ["swift"]], ["TCL", ["tcl"]], ["TOML", ["toml"]], ["TypeScript", ["ts","tsx","mts","cts"]],
  ["Vue", ["vue"]], ["XML", ["xml"]], ["YAML", ["yaml","yml"]], ["Zig", ["zig"]], ["gitignore", ["gitignore","ignore","sccignore"]]
];

const extMap = new Map();
for (const [name, exts] of languages) for (const e of exts) if (!extMap.has(e.toLowerCase())) extMap.set(e.toLowerCase(), name);

function parseArgs(argv) {
  const opts = {
    format: "tabular", paths: [], noCocomo: false, noSize: false, byFile: false, wide: false,
    includeExt: null, excludeExt: new Set(), excludeDir: new Set([".git",".hg",".svn"]),
    excludeFile: new Set(["package-lock.json","Cargo.lock","yarn.lock","pubspec.lock","Podfile.lock","pnpm-lock.yaml"]),
    noGitignore: false, noIgnore: false, noSccIgnore: false, countIgnore: false, includeSymlinks: false,
    sort: "files", output: null, countAs: {}, uloc: false, dryness: false, character: false,
    avgWage: 56286, eaf: 1, overhead: 2.4, currency: "$", projectType: "organic", percent: false,
    ci: false, noComplexity: false, noDuplicates: false, notMatch: []
  };
  const args = [...argv];
  function need(i, flag) { if (i + 1 >= args.length) die(`Error: flag needs an argument: ${flag}`); return args[i + 1]; }
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--") { opts.paths.push(...args.slice(i + 1)); break; }
    if (!a.startsWith("-") || a === "-") { opts.paths.push(a); continue; }
    if (a === "-h" || a === "--help") { printHelp(); process.exit(0); }
    if (a === "--version") { console.log(`scc version ${VERSION}`); process.exit(0); }
    if (a === "-l" || a === "--languages") { printLanguages(); process.exit(0); }
    const setVal = (key) => { opts[key] = need(i, a); i++; };
    switch (a) {
      case "-f": case "--format": setVal("format"); break;
      case "-o": case "--output": setVal("output"); break;
      case "--format-multi": i++; break;
      case "--no-cocomo": opts.noCocomo = true; break;
      case "--no-size": opts.noSize = true; break;
      case "--by-file": opts.byFile = true; break;
      case "-w": case "--wide": opts.wide = true; opts.format = "wide"; break;
      case "-i": case "--include-ext": opts.includeExt = new Set(splitList(need(i, a))); i++; break;
      case "-x": case "--exclude-ext": for (const x of splitList(need(i, a))) opts.excludeExt.add(x); i++; break;
      case "--exclude-dir": opts.excludeDir = new Set(splitList(need(i, a))); i++; break;
      case "-n": case "--exclude-file": opts.excludeFile = new Set(splitList(need(i, a))); i++; break;
      case "--no-gitignore": opts.noGitignore = true; break;
      case "--no-ignore": opts.noIgnore = true; break;
      case "--no-scc-ignore": opts.noSccIgnore = true; break;
      case "--count-ignore": opts.countIgnore = true; break;
      case "--include-symlinks": opts.includeSymlinks = true; break;
      case "-s": case "--sort": setVal("sort"); break;
      case "--count-as": Object.assign(opts.countAs, parseCountAs(need(i, a))); i++; break;
      case "-u": case "--uloc": opts.uloc = true; break;
      case "-a": case "--dryness": opts.dryness = true; opts.uloc = true; break;
      case "-m": case "--character": opts.character = true; break;
      case "--avg-wage": opts.avgWage = Number(need(i, a)); i++; break;
      case "--eaf": opts.eaf = Number(need(i, a)); i++; break;
      case "--overhead": opts.overhead = Number(need(i, a)); i++; break;
      case "--currency-symbol": opts.currency = need(i, a); i++; break;
      case "--cocomo-project-type": opts.projectType = need(i, a); i++; break;
      case "-p": case "--percent": opts.percent = true; break;
      case "--ci": opts.ci = true; break;
      case "-c": case "--no-complexity": opts.noComplexity = true; break;
      case "-d": case "--no-duplicates": opts.noDuplicates = true; break;
      case "-M": case "--not-match": opts.notMatch.push(new RegExp(need(i, a))); i++; break;
      case "--binary": case "--debug": case "--trace": case "-t": case "-v": case "--verbose":
      case "--gen": case "--min": case "-z": case "--min-gen": case "--no-gen": case "--no-min": case "--no-min-gen":
      case "--no-large": case "--no-gitmodule": case "--no-hborder": case "--locomo": case "--cost-comparison":
      case "--sloccount-format": case "--mcp":
        break;
      default:
        if (a.includes("=")) {
          const [k, v] = a.split(/=(.*)/s);
          args.splice(i, 1, k, v); i--; break;
        }
        if (["--directory-walker-job-workers","--file-gc-count","--file-list-queue-size","--file-process-job-workers",
          "--file-summary-job-queue-size","--large-byte-count","--large-line-count","--min-gen-line-length",
          "--generated-markers","--remap-all","--remap-unknown","--size-unit","--sql-project","--locomo-config",
          "--locomo-cycles","--locomo-input-price","--locomo-output-price","--locomo-preset","--locomo-review","--locomo-tps"].includes(a)) i++;
        else die(`Error: unknown flag: ${a}`);
    }
  }
  if (opts.paths.length === 0) opts.paths = ["."];
  return opts;
}

function splitList(s) { return String(s).split(",").map(x => x.trim().replace(/^\./, "")).filter(Boolean); }
function parseCountAs(s) {
  const out = {};
  for (const part of String(s).split(",")) {
    const idx = part.indexOf(":");
    if (idx > 0) out[part.slice(0, idx).replace(/^\./, "").toLowerCase()] = part.slice(idx + 1).replace(/^"|"$/g, "");
  }
  return out;
}

function die(msg) { console.error(msg); process.exit(1); }

function printHelp() {
  console.log(`Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.
Version ${VERSION}
Ben Boyter <ben@boyter.org> + Contributors

Usage:
  scc [flags] [files or directories]

Flags:
      --avg-wage int                       average wage value used for basic COCOMO calculation (default 56286)
      --binary                             disable binary file detection
      --by-file                            display output for every file
  -m, --character                          calculate max and mean characters per line
      --ci                                 enable CI output settings where stdout is ASCII
      --cocomo-project-type string         change COCOMO model type [organic, semi-detached, embedded, "custom,1,1,1,1"] (default "organic")
      --cost-comparison                    show both COCOMO and LOCOMO estimates side by side
      --count-as string                    count extension as language [e.g. jsp:htm,chead:"C Header" maps extension jsp to html and chead to C Header]
      --count-ignore                       set to allow .gitignore and .ignore files to be counted
      --currency-symbol string             set currency symbol (default "$")
      --debug                              enable debug output
  -a, --dryness                            calculate the DRYness of the project (implies --uloc)
      --eaf float                          the effort adjustment factor derived from the cost drivers (1.0 if rated nominal) (default 1)
      --exclude-dir strings                directories to exclude (default [.git,.hg,.svn])
  -x, --exclude-ext strings                ignore file extensions (overrides include-ext) [comma separated list: e.g. go,java,js]
  -n, --exclude-file strings               ignore files with matching names (default [package-lock.json,Cargo.lock,yarn.lock,pubspec.lock,Podfile.lock,pnpm-lock.yaml])
  -f, --format string                      set output format [tabular, wide, json, json2, csv, csv-stream, cloc-yaml, html, html-table, sql, sql-insert, openmetrics] (default "tabular")
  -h, --help                               help for scc
  -i, --include-ext strings                limit to file extensions [comma separated list: e.g. go,java,js]
      --include-symlinks                   if set will count symlink files
  -l, --languages                          print supported languages and extensions
      --no-cocomo                          remove COCOMO calculation output
  -c, --no-complexity                      skip calculation of code complexity
  -d, --no-duplicates                      remove duplicate files from stats and output
      --no-gitignore                       disables .gitignore file logic
      --no-ignore                          disables .ignore file logic
      --no-size                            remove size calculation output
  -o, --output string                      output filename (default stdout)
  -p, --percent                            include percentage values in output
  -s, --sort string                        column to sort by [files, name, lines, blanks, code, comments, complexity] (default "files")
  -u, --uloc                               calculate the number of unique lines of code (ULOC) for the project
      --version                            version for scc
  -w, --wide                               wider output with additional statistics (implies --complexity)`);
}

function printLanguages() {
  for (const [name, exts] of languages) console.log(`${name} (${exts.join(",")})`);
}

function getKey(file) {
  const base = path.basename(file);
  const lower = base.toLowerCase();
  if (["makefile","gnumakefile"].includes(lower)) return lower;
  if (["dockerfile","containerfile"].includes(lower)) return lower;
  if (["license","licence","copying"].includes(lower)) return lower;
  if (lower.startsWith(".")) return lower.slice(1);
  const ext = path.extname(lower);
  return ext ? ext.slice(1) : lower;
}

function languageFor(file, content, opts) {
  let key = getKey(file);
  if (opts.countAs[key]) return normalizeLang(opts.countAs[key]);
  let lang = extMap.get(key);
  if (!lang && key === "tsx") lang = "TypeScript";
  if (!lang && key === "jsx") lang = "JavaScript";
  if (!lang && !path.extname(file)) {
    const first = content.slice(0, 100);
    if (first.startsWith("#!")) {
      if (first.includes("python")) lang = "Python";
      else if (first.includes("node") || first.includes("javascript")) lang = "JavaScript";
      else if (first.includes("ruby")) lang = "Ruby";
      else if (first.includes("perl")) lang = "Perl";
      else if (first.includes("bash")) lang = "BASH";
      else if (first.includes("sh")) lang = "Shell";
    }
  }
  return lang || null;
}
function normalizeLang(s) {
  const low = s.toLowerCase();
  for (const [name, exts] of languages) if (name.toLowerCase() === low || exts.includes(low)) return name;
  return s;
}

function loadIgnore(dir, opts) {
  const pats = [];
  const files = [];
  if (!opts.noGitignore) files.push(".gitignore");
  if (!opts.noIgnore) files.push(".ignore");
  if (!opts.noSccIgnore) files.push(".sccignore");
  for (const f of files) {
    const p = path.join(dir, f);
    try {
      for (let line of fs.readFileSync(p, "utf8").split(/\r?\n/)) {
        line = line.trim();
        if (!line || line.startsWith("#") || line.startsWith("!")) continue;
        pats.push(line.replace(/\/$/, ""));
      }
    } catch {}
  }
  return pats;
}
function ignored(rel, base, isDir, opts, inherited) {
  const name = path.basename(rel);
  if (isDir && opts.excludeDir.has(name)) return true;
  if (!isDir && opts.excludeFile.has(name)) return true;
  if (!opts.countIgnore && [".gitignore",".ignore",".sccignore"].includes(name)) return true;
  for (const r of opts.notMatch) if (r.test(rel)) return true;
  for (const pat of inherited) {
    if (pat.includes("*")) {
      const re = new RegExp("^" + pat.split("*").map(esc).join(".*") + "$");
      if (re.test(name) || re.test(rel)) return true;
    } else if (name === pat || rel === pat || rel.startsWith(pat + path.sep)) return true;
  }
  return false;
}
function esc(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

function collect(paths, opts) {
  const files = [];
  function walk(p, root, ignores) {
    let st;
    try { st = opts.includeSymlinks ? fs.statSync(p) : fs.lstatSync(p); } catch { return; }
    const rel = path.relative(root, p) || path.basename(p);
    if (st.isSymbolicLink() && !opts.includeSymlinks) return;
    if (ignored(rel, root, st.isDirectory(), opts, ignores)) return;
    if (st.isDirectory()) {
      const here = ignores.concat(loadIgnore(p, opts));
      let entries = [];
      try { entries = fs.readdirSync(p).sort(); } catch { return; }
      for (const e of entries) walk(path.join(p, e), root, here);
    } else if (st.isFile()) files.push(p);
  }
  for (const p0 of paths) {
    const p = path.resolve(p0);
    walk(p, fs.existsSync(p) && fs.statSync(p).isDirectory() ? p : path.dirname(p), []);
  }
  return files;
}

function isBinary(buf) {
  const n = Math.min(buf.length, 8000);
  for (let i = 0; i < n; i++) if (buf[i] === 0) return true;
  return false;
}

const hashComment = new Set(["Python","Ruby","Perl","Shell","BASH","Makefile","YAML","TOML","R","gitignore","Dockerfile","INI"]);
const slashBlock = new Set(["C","C Header","C++","C++ Header","Java","JavaScript","TypeScript","CSS","Go","Rust","C#","PHP","Swift","Kotlin","Scala","Dart"]);
const slashLine = new Set([...slashBlock, "SQL"]);
const htmlComment = new Set(["HTML","XML","Markdown","Vue","Svelte"]);

function analyze(file, opts) {
  let buf;
  try { buf = fs.readFileSync(file); } catch { return null; }
  if (isBinary(buf)) return null;
  const content = buf.toString("utf8");
  const lang = languageFor(file, content, opts);
  if (!lang) return null;
  const ext = getKey(file);
  if (opts.includeExt && !opts.includeExt.has(ext)) return null;
  if (opts.excludeExt.has(ext)) return null;
  const lines = content.length ? content.split(/\n/) : [];
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  let blank = 0, comment = 0, code = 0, complexity = 0, inBlock = false, inHtml = false, maxLen = 0, totalLen = 0;
  const unique = new Set();
  for (let raw of lines) {
    if (raw.endsWith("\r")) raw = raw.slice(0, -1);
    maxLen = Math.max(maxLen, raw.length); totalLen += raw.length;
    const t = raw.trim();
    if (!t) { blank++; continue; }
    let isCom = false, isCode = false;
    if (inHtml) {
      isCom = true; if (t.includes("-->")) inHtml = false;
    } else if (inBlock) {
      isCom = true; if (t.includes("*/")) inBlock = false;
    } else if (htmlComment.has(lang) && t.startsWith("<!--")) {
      isCom = true; if (!t.includes("-->")) inHtml = true;
    } else if (slashBlock.has(lang) && t.startsWith("/*")) {
      isCom = true; if (!t.includes("*/") || t.indexOf("*/") < t.indexOf("/*")) inBlock = true;
    } else if (slashLine.has(lang) && t.startsWith("//")) {
      isCom = true;
    } else if (lang === "SQL" && t.startsWith("--")) {
      isCom = true;
    } else if (hashComment.has(lang) && t.startsWith("#") && !t.startsWith("#!")) {
      isCom = true;
    } else {
      isCode = true;
    }
    if (isCom) comment++; else if (isCode) { code++; unique.add(t); complexity += countComplexity(t, lang); }
  }
  if (opts.noComplexity) complexity = 0;
  return { Name: lang, Bytes: buf.length, CodeBytes: 0, Lines: lines.length, Code: code, Comment: comment, Blank: blank,
    Complexity: complexity, Count: 1, WeightedComplexity: 0, Files: [], LineLength: opts.character ? {Max: maxLen, Mean: lines.length ? totalLen / lines.length : 0} : null,
    ULOC: opts.uloc ? unique.size : 0, Path: file };
}
function countComplexity(s, lang) {
  if (["Markdown","JSON","YAML","TOML","XML","HTML","CSS","Plain Text","License","CSV"].includes(lang)) return 0;
  const m = s.match(/\b(if|for|while|case|catch|switch|elif|else if|except|when|guard|foreach|loop)\b|&&|\|\||\?/g);
  return m ? m.length : 0;
}

function summarize(files, opts) {
  const seen = new Set(), perFile = [];
  for (const file of files) {
    const r = analyze(file, opts);
    if (!r) continue;
    if (opts.noDuplicates) {
      const sig = `${r.Bytes}:${r.Lines}:${r.Code}:${r.Comment}:${r.Blank}`;
      if (seen.has(sig)) continue;
      seen.add(sig);
    }
    perFile.push(r);
  }
  const map = new Map();
  for (const f of perFile) {
    if (!map.has(f.Name)) map.set(f.Name, {Name:f.Name,Bytes:0,CodeBytes:0,Lines:0,Code:0,Comment:0,Blank:0,Complexity:0,Count:0,WeightedComplexity:0,Files:[],LineLength:null,ULOC:0});
    const g = map.get(f.Name);
    for (const k of ["Bytes","Lines","Code","Comment","Blank","Complexity","Count","ULOC"]) g[k] += f[k];
    if (opts.byFile) g.Files.push(f);
  }
  let rows = [...map.values()];
  rows.sort((a, b) => compareRows(a, b, opts.sort));
  return { rows, perFile };
}
function compareRows(a, b, sort) {
  const keys = {files:"Count", name:"Name", lines:"Lines", blanks:"Blank", code:"Code", comments:"Comment", complexity:"Complexity"};
  const k = keys[sort] || "Count";
  const nameCmp = a.Name === b.Name ? 0 : (a.Name < b.Name ? -1 : 1);
  if (k === "Name") return nameCmp;
  const d = b[k] - a[k];
  return d || nameCmp;
}

function total(rows) {
  const t = {Name:"Total",Bytes:0,Lines:0,Code:0,Comment:0,Blank:0,Complexity:0,Count:0,ULOC:0};
  for (const r of rows) for (const k of ["Bytes","Lines","Code","Comment","Blank","Complexity","Count","ULOC"]) t[k] += r[k];
  return t;
}
function n(x) { return Math.round(x).toLocaleString("en-US"); }
function money(x) { return Math.floor(x).toLocaleString("en-US"); }
function cocomo(code, opts) {
  let a = 2.4, b = 1.05, c = 2.5, d = 0.38, name = opts.projectType || "organic";
  if (name === "semi-detached") { a = 3.0; b = 1.12; d = 0.35; }
  else if (name === "embedded") { a = 3.6; b = 1.20; d = 0.32; }
  else if (name.startsWith("custom,")) {
    const p = name.split(",").slice(1).map(Number); if (p.length >= 4) [a,b,c,d] = p;
    name = "custom";
  }
  const effort = a * Math.pow(Math.max(code, 1) / 1000, b) * opts.eaf;
  const sched = c * Math.pow(effort, d);
  const people = effort / sched;
  const cost = effort * (opts.avgWage / 12) * opts.overhead;
  return { cost, sched, people, name };
}
function table(rows, opts) {
  const t = total(rows), wide = opts.format === "wide" || opts.wide, border = wide ? WIDE_BORDER : BORDER;
  const out = [border];
  if (wide) out.push(`${"Language".padEnd(34)} ${"Files".padStart(8)} ${"Lines".padStart(9)} ${"Blanks".padStart(8)} ${"Comments".padStart(9)} ${"Code".padStart(8)} ${"Complexity".padStart(10)} ${"Complexity/Lines".padStart(16)}`);
  else out.push(`${"Language".padEnd(16)} ${"Files".padStart(8)} ${"Lines".padStart(11)} ${"Blanks".padStart(9)} ${"Comments".padStart(9)} ${"Code".padStart(10)} ${"Complexity".padStart(10)}`);
  out.push(border);
  const rowRatios = new Map(rows.map(r => [r.Name, r.Code ? r.Complexity / r.Code * 100 : 0]));
  function row(r, file) {
    let ratio = r.Name === "Total" ? [...rowRatios.values()].reduce((a, b) => a + b, 0) : (file ? (r.Code ? r.Complexity / r.Code * 100 : 0) : rowRatios.get(r.Name) || 0);
    if (wide) return `${(file || r.Name).padEnd(34).slice(0,34)} ${file ? "".padStart(8) : n(r.Count).padStart(8)} ${n(r.Lines).padStart(9)} ${n(r.Blank).padStart(8)} ${n(r.Comment).padStart(9)} ${n(r.Code).padStart(8)} ${n(r.Complexity).padStart(10)} ${(ratio.toFixed(2)).padStart(16)}`;
    return `${(file || r.Name).padEnd(16).slice(0,16)} ${file ? "".padStart(8) : n(r.Count).padStart(8)} ${n(r.Lines).padStart(11)} ${n(r.Blank).padStart(9)} ${n(r.Comment).padStart(9)} ${n(r.Code).padStart(10)} ${n(r.Complexity).padStart(10)}`;
  }
  for (const r of rows) {
    out.push(row(r));
    if (opts.byFile) {
      out.push(border);
      for (const f of r.Files.sort((a,b) => path.basename(a.Path).localeCompare(path.basename(b.Path)))) out.push(row(f, path.basename(f.Path)));
      out.push(border);
    }
  }
  if (!opts.byFile) out.push(border);
  out.push(row(t));
  out.push(border);
  if (!opts.noCocomo) {
    const c = cocomo(t.Code, opts);
    out.push(`Estimated Cost to Develop (${c.name}) ${opts.currency}${money(c.cost)}`);
    out.push(`Estimated Schedule Effort (${c.name}) ${c.sched.toFixed(2)} months`);
    out.push(`Estimated People Required (${c.name}) ${c.people.toFixed(2)}`);
    out.push(border);
  }
  if (!opts.noSize) {
    out.push(`Processed ${t.Bytes} bytes, ${(t.Bytes / 1000000).toFixed(3)} megabytes (SI)`);
    out.push(border);
  }
  return out.join("\n") + "\n";
}
function jsonRows(rows) { return JSON.stringify(rows.map(r => ({...r, Files: [], LineLength: r.LineLength || null}))); }
function csv(rows) {
  const lines = ["Language,Lines,Code,Comments,Blanks,Complexity,Bytes,Files,ULOC"];
  for (const r of rows) lines.push([r.Name,r.Lines,r.Code,r.Comment,r.Blank,r.Complexity,r.Bytes,r.Count,r.ULOC || 0].map(csvEsc).join(","));
  return lines.join("\n") + "\n";
}
function csvEsc(v) { const s = String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; }
function yaml(rows) {
  const t = total(rows);
  const out = [`# https://github.com/boyter/scc/`, `header:`, `  url: https://github.com/boyter/scc/`, `  version: ${VERSION}`, `  elapsed_seconds: 0.001`, `  n_files: ${t.Count}`, `  n_lines: ${t.Lines}`, `  files_per_second: ${t.Count * 1000}`, `  lines_per_second: ${t.Lines * 1000}`];
  for (const r of rows) out.push(`${r.Name}:`, `  name: ${r.Name}`, `  code: ${r.Code}`, `  comment: ${r.Comment}`, `  blank: ${r.Blank}`, `  nFiles: ${r.Count}`);
  out.push(`SUM:`, `  code: ${t.Code}`, `  comment: ${t.Comment}`, `  blank: ${t.Blank}`, `  nFiles: ${t.Count}`);
  return out.join("\n") + "\n";
}
function html(rows, onlyTable) {
  const head = onlyTable ? "" : "<!doctype html><html><head><meta charset=\"utf-8\"><title>scc</title></head><body>";
  const foot = onlyTable ? "" : "</body></html>";
  const trs = rows.map(r => `<tr><td>${r.Name}</td><td>${r.Count}</td><td>${r.Lines}</td><td>${r.Blank}</td><td>${r.Comment}</td><td>${r.Code}</td><td>${r.Complexity}</td></tr>`).join("");
  return `${head}<table><thead><tr><th>Language</th><th>Files</th><th>Lines</th><th>Blanks</th><th>Comments</th><th>Code</th><th>Complexity</th></tr></thead><tbody>${trs}</tbody></table>${foot}\n`;
}
function sql(rows, insertsOnly, opts) {
  const project = opts.sqlProject || "scc";
  const out = [];
  if (!insertsOnly) out.push("CREATE TABLE t (Project TEXT, Language TEXT, Lines INT, Code INT, Comments INT, Blanks INT, Complexity INT, Bytes INT, Files INT);");
  for (const r of rows) out.push(`INSERT INTO t VALUES ('${project}','${String(r.Name).replace(/'/g,"''")}',${r.Lines},${r.Code},${r.Comment},${r.Blank},${r.Complexity},${r.Bytes},${r.Count});`);
  return out.join("\n") + "\n";
}
function openmetrics(rows) {
  const out = [];
  for (const r of rows) {
    const l = r.Name.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    out.push(`scc_files{language="${l}"} ${r.Count}`, `scc_lines{language="${l}"} ${r.Lines}`, `scc_code{language="${l}"} ${r.Code}`, `scc_comments{language="${l}"} ${r.Comment}`, `scc_blanks{language="${l}"} ${r.Blank}`, `scc_complexity{language="${l}"} ${r.Complexity}`);
  }
  return out.join("\n") + "\n";
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const { rows } = summarize(collect(opts.paths, opts), opts);
  let out;
  switch (opts.format) {
    case "json": out = jsonRows(rows); break;
    case "json2": {
      const t = total(rows), c = cocomo(t.Code, opts);
      out = JSON.stringify({languageSummary: rows.map(r => ({...r, Files: [], LineLength: r.LineLength || null})), estimatedCost: c.cost, estimatedScheduleMonths: c.sched, estimatedPeople: c.people});
      break;
    }
    case "csv": case "csv-stream": out = csv(rows); break;
    case "cloc-yaml": out = yaml(rows); break;
    case "html": out = html(rows, false); break;
    case "html-table": out = html(rows, true); break;
    case "sql": out = sql(rows, false, opts); break;
    case "sql-insert": out = sql(rows, true, opts); break;
    case "openmetrics": out = openmetrics(rows); break;
    case "wide": case "tabular": default: out = table(rows, opts); break;
  }
  if (opts.output) fs.writeFileSync(opts.output, out); else process.stdout.write(out);
}
main();
