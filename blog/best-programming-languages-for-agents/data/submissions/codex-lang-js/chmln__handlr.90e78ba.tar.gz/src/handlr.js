#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const VERSION = 'handlr 0.6.4';

const MIME_BY_EXT = {
  txt: 'text/plain',
  text: 'text/plain',
  md: 'text/markdown',
  markdown: 'text/markdown',
  rs: 'text/rust',
  vim: 'text/plain',
  json: 'application/json',
  js: 'application/javascript',
  html: 'text/html',
  htm: 'text/html',
  css: 'text/css',
  csv: 'text/csv',
  pdf: 'application/pdf',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  gif: 'image/gif',
  svg: 'image/svg+xml',
  webp: 'image/webp',
  mp3: 'audio/mpeg',
  ogg: 'audio/ogg',
  flac: 'audio/flac',
  wav: 'audio/wav',
  mp4: 'video/mp4',
  mkv: 'video/x-matroska',
  zip: 'application/zip',
  gz: 'application/gzip',
  tar: 'application/x-tar',
};

function out(s = '') { process.stdout.write(String(s) + '\n'); }
function err(s = '') { process.stderr.write(String(s) + '\n'); }

function mainHelp() {
  return `${VERSION}

USAGE:
    executable <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    list      List default apps and the associated handlers
    open      Open a path/URL with its default handler
    set       Set the default handler for mime/extension
    unset     Unset the default handler for mime/extension
    launch    Launch the handler for specified extension/mime with optional arguments
    get       Get handler for this mime/extension
    add       Add a handler for given mime/extension Note that the first handler is the default`;
}

const helps = {
  list: `executable-list 
List default apps and the associated handlers

USAGE:
    executable list [FLAGS]

FLAGS:
    -a, --all        
    -h, --help       Prints help information
    -V, --version    Prints version information`,
  open: `executable-open 
Open a path/URL with its default handler

USAGE:
    executable open <paths>...

ARGS:
    <paths>...    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information`,
  set: `executable-set 
Set the default handler for mime/extension

USAGE:
    executable set <mime> <handler>

ARGS:
    <mime>       
    <handler>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information`,
  unset: `executable-unset 
Unset the default handler for mime/extension

USAGE:
    executable unset <mime>

ARGS:
    <mime>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information`,
  launch: `executable-launch 
Launch the handler for specified extension/mime with optional arguments

USAGE:
    executable launch <mime> [args]...

ARGS:
    <mime>       
    <args>...    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information`,
  get: `executable-get 
Get handler for this mime/extension

USAGE:
    executable get [FLAGS] <mime>

ARGS:
    <mime>    

FLAGS:
        --json       
    -h, --help       Prints help information
    -V, --version    Prints version information`,
  add: `executable-add 
Add a handler for given mime/extension Note that the first handler is the default

USAGE:
    executable add <mime> <handler>

ARGS:
    <mime>       
    <handler>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information`,
};

function dieClap(msg, usage) {
  err(`error: ${msg}`);
  err('');
  err(usage);
  err('');
  err('For more information try --help');
  process.exit(2);
}

function dieInvalid(arg, msg) {
  err(`error: Invalid value for '<${arg}>': ${msg}`);
  err('');
  err('For more information try --help');
  process.exit(2);
}

function xdgConfigHome() {
  return process.env.XDG_CONFIG_HOME || path.join(process.env.HOME || '.', '.config');
}
function xdgDataHome() {
  return process.env.XDG_DATA_HOME || path.join(process.env.HOME || '.', '.local', 'share');
}
function configPath() { return path.join(xdgConfigHome(), 'mimeapps.list'); }
function ensureConfig() {
  const hdir = path.join(xdgConfigHome(), 'handlr');
  fs.mkdirSync(hdir, { recursive: true });
  const hp = path.join(hdir, 'handlr.toml');
  if (!fs.existsSync(hp)) fs.writeFileSync(hp, `enable_selector = false\nselector = "rofi -dmenu -i -p 'Open With: '"\n`);
  const mp = configPath();
  fs.mkdirSync(path.dirname(mp), { recursive: true });
  if (!fs.existsSync(mp)) fs.writeFileSync(mp, '');
}

function parseIni(text) {
  const sections = {};
  let sec = '';
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const m = line.match(/^\[(.*)\]$/);
    if (m) { sec = m[1]; if (!sections[sec]) sections[sec] = {}; continue; }
    const i = raw.indexOf('=');
    if (i >= 0) {
      if (!sections[sec]) sections[sec] = {};
      sections[sec][raw.slice(0, i).trim()] = raw.slice(i + 1).trim();
    }
  }
  return sections;
}

function readMimeApps() {
  ensureConfig();
  const p = configPath();
  const s = parseIni(fs.readFileSync(p, 'utf8'));
  const defaults = {};
  const added = {};
  for (const [k, v] of Object.entries(s['Default Applications'] || {})) defaults[k] = splitHandlers(v);
  for (const [k, v] of Object.entries(s['Added Associations'] || {})) added[k] = splitHandlers(v);
  return { defaults, added };
}

function splitHandlers(v) {
  return v.split(';').map(x => x.trim()).filter(Boolean);
}

function writeMimeApps(db) {
  ensureConfig();
  const lines = ['[Added Associations]'];
  for (const k of Object.keys(db.added).sort()) {
    if (db.added[k].length) lines.push(`${k}=${db.added[k].join(';')};`);
  }
  lines.push('', '[Default Applications]');
  for (const k of Object.keys(db.defaults).sort()) {
    if (db.defaults[k].length) lines.push(`${k}=${db.defaults[k].join(';')};`);
  }
  fs.writeFileSync(configPath(), lines.join('\n') + '\n');
}

function dataDirs() {
  const dirs = [path.join(xdgDataHome(), 'applications')];
  for (const d of (process.env.XDG_DATA_DIRS || '/usr/local/share:/usr/share').split(':')) {
    if (d) dirs.push(path.join(d, 'applications'));
  }
  return dirs;
}

function findDesktop(id) {
  if (id.includes('/') && fs.existsSync(id)) return id;
  for (const dir of dataDirs()) {
    const p = path.join(dir, id);
    if (fs.existsSync(p)) return p;
  }
  return null;
}

function parseDesktop(id) {
  const file = findDesktop(id);
  if (!file) return null;
  const ini = parseIni(fs.readFileSync(file, 'utf8'));
  const d = ini['Desktop Entry'] || {};
  return {
    id: path.basename(id),
    file,
    name: d.Name || path.basename(id, '.desktop'),
    exec: d.Exec || '',
    mimeTypes: splitHandlers(d.MimeType || ''),
    noDisplay: String(d.NoDisplay || '').toLowerCase() === 'true',
  };
}

function allDesktopApps() {
  const seen = new Set(), apps = [];
  for (const dir of dataDirs()) {
    if (!fs.existsSync(dir)) continue;
    for (const name of fs.readdirSync(dir)) {
      if (!name.endsWith('.desktop') || seen.has(name)) continue;
      seen.add(name);
      const app = parseDesktop(name);
      if (app) apps.push(app);
    }
  }
  return apps;
}

function normalizeMime(input, forPath = false) {
  if (forPath && /^[A-Za-z][A-Za-z0-9+.-]*:\/\//.test(input)) {
    const scheme = input.slice(0, input.indexOf(':'));
    return `x-scheme-handler/${scheme}`;
  }
  if (forPath && /^[A-Za-z][A-Za-z0-9+.-]*:[^/]/.test(input)) {
    const scheme = input.slice(0, input.indexOf(':'));
    return `x-scheme-handler/${scheme}`;
  }
  if (forPath) {
    const ext = path.extname(input).replace(/^\./, '').toLowerCase();
    if (ext && MIME_BY_EXT[ext]) return MIME_BY_EXT[ext];
    try {
      if (fs.existsSync(input) && fs.statSync(input).isFile()) {
        const b = fs.readFileSync(input, { encoding: null, flag: 'r' }).subarray(0, 512);
        if (!b.includes(0)) return 'text/plain';
      }
    } catch {}
  }
  if (input.startsWith('.')) {
    dieInvalid('mime', `could not figure out the mime type of '${input}'`);
  }
  const slash = input.indexOf('/');
  if (slash < 0) dieInvalid('mime', 'mime parse error: a slash (/) was missing between the type and subtype');
  const bad = input.search(/[^A-Za-z0-9!#$&^_.+-/.*]/);
  if (bad >= 0 || input.startsWith('/') || input.includes(':')) {
    const ch = input.charCodeAt(Math.max(0, bad >= 0 ? bad : (input.startsWith('/') ? 0 : input.indexOf(':')))).toString(16).toUpperCase();
    dieInvalid('mime', `mime parse error: an invalid token was encountered, ${ch} at position ${Math.max(0, bad >= 0 ? bad : (input.startsWith('/') ? 0 : input.indexOf(':')))}`);
  }
  return input;
}

function validateHandler(handler) {
  if (!findDesktop(handler)) dieInvalid('handler', `no handlers found for '${handler}'`);
}

function systemAssociations() {
  const map = {};
  for (const app of allDesktopApps()) {
    for (const m of app.mimeTypes) {
      if (!map[m]) map[m] = [];
      map[m].push(app.id);
    }
  }
  return map;
}

function lookupHandlers(mime) {
  const db = readMimeApps();
  if (db.defaults[mime] && db.defaults[mime].length) return db.defaults[mime];
  const wildcard = mime.replace(/\/.*/, '/*');
  if (db.defaults[wildcard] && db.defaults[wildcard].length) return db.defaults[wildcard];
  const sys = systemAssociations();
  if (sys[mime] && sys[mime].length) return sys[mime];
  if (sys[wildcard] && sys[wildcard].length) return sys[wildcard];
  return [];
}

function cleanExecTemplate(exec) {
  const endedWithFileArg = /%[fFuU]\s*$/.test(exec);
  const cleaned = exec.replace(/%[fFuUdDnNickvm]/g, '').replace(/"/g, '').replace(/\s+/g, ' ').trim();
  return endedWithFileArg ? cleaned + ' ' : cleaned;
}

function shellQuote(s) {
  return `'${String(s).replace(/'/g, `'\\''`)}'`;
}

function commandFor(app, args) {
  let e = app.exec || '';
  e = e.replace(/\$/g, '\\$');
  if (/%[fFuU]/.test(e)) {
    e = e.replace(/%[fFuU]/g, args.map(shellQuote).join(' '));
  } else if (args.length) {
    e += ' ' + args.map(shellQuote).join(' ');
  }
  e = e.replace(/%[dDnNickvm]/g, '').trim();
  return e;
}

function table(rows) {
  const w1 = Math.max(0, ...rows.map(r => r[0].length));
  const w2 = Math.max(0, ...rows.map(r => r[1].length));
  const top = `┌${'─'.repeat(w1 + 2)}┬${'─'.repeat(w2 + 2)}┐`;
  const bot = `└${'─'.repeat(w1 + 2)}┴${'─'.repeat(w2 + 2)}┘`;
  const body = rows.map(r => `│ ${r[0].padEnd(w1)} │ ${r[1].padEnd(w2)} │`);
  return [top, ...body, bot].join('\n');
}

function cmdList(args) {
  const all = args.includes('-a') || args.includes('--all');
  const db = readMimeApps();
  const defRows = Object.keys(db.defaults).sort().filter(k => db.defaults[k].length).map(k => [k, db.defaults[k].join(', ')]);
  if (!all) { out(table(defRows)); return; }
  out('Default Apps');
  out(table(defRows));
  out('System Apps');
  const sys = systemAssociations();
  const sysRows = Object.keys(sys).sort().map(k => [k, sys[k].join(', ')]);
  out(table(sysRows));
}

function cmdSet(args, addMode) {
  if (args.length < 2) {
    const missing = args.length === 0 ? '    <mime>\n    <handler>' : '    <handler>';
    dieClap(`The following required arguments were not provided:\n${missing}`, `USAGE:\n    executable ${addMode ? 'add' : 'set'} <mime> <handler>`);
  }
  const mime = normalizeMime(args[0]);
  validateHandler(args[1]);
  const db = readMimeApps();
  if (addMode) {
    if (!db.defaults[mime]) db.defaults[mime] = [];
    db.defaults[mime].push(args[1]);
  } else {
    db.defaults[mime] = [args[1]];
  }
  writeMimeApps(db);
}

function cmdUnset(args) {
  if (args.length < 1) dieClap(`The following required arguments were not provided:\n    <mime>`, 'USAGE:\n    executable unset <mime>');
  const mime = normalizeMime(args[0]);
  const db = readMimeApps();
  db.defaults[mime] = [];
  writeMimeApps(db);
}

function cmdGet(args) {
  const json = args.includes('--json');
  args = args.filter(a => a !== '--json');
  if (args.length < 1) dieClap(`The following required arguments were not provided:\n    <mime>`, 'USAGE:\n    executable get [FLAGS] <mime>');
  const mime = normalizeMime(args[0]);
  const hs = lookupHandlers(mime);
  if (!hs.length) process.exit(1);
  const app = parseDesktop(hs[0]);
  if (json) {
    out(JSON.stringify({ handler: hs[0], name: app ? app.name : path.basename(hs[0], '.desktop'), cmd: app ? cleanExecTemplate(app.exec) : '' }));
  } else {
    out(hs[0]);
  }
}

function cmdLaunch(args) {
  if (args.length < 1) dieClap(`The following required arguments were not provided:\n    <mime>`, 'USAGE:\n    executable launch <mime> [args]...');
  const mime = normalizeMime(args[0]);
  const rest = args.slice(1).filter(a => a !== '--');
  const hs = lookupHandlers(mime);
  if (!hs.length) process.exit(1);
  const app = parseDesktop(hs[0]);
  if (!app || !app.exec) process.exit(1);
  const c = commandFor(app, rest);
  try {
    cp.execSync(c, { stdio: 'ignore', shell: '/bin/bash' });
  } catch (e) {
    process.exit(e.status || 1);
  }
}

function cmdOpen(args) {
  if (args.length < 1) dieClap(`The following required arguments were not provided:\n    <paths>...`, 'USAGE:\n    executable open <paths>...');
  let status = 0;
  for (const p of args) {
    let mime;
    try { mime = normalizeMime(p, true); } catch { status = 1; continue; }
    const hs = lookupHandlers(mime);
    const app = hs.length ? parseDesktop(hs[0]) : null;
    if (!app || !app.exec) { status = 1; continue; }
    try { cp.execSync(commandFor(app, [p]), { stdio: 'ignore', shell: '/bin/bash' }); } catch (e) { status = e.status || 1; }
  }
  process.exit(status);
}

function unexpected(arg, sub) {
  err(`error: Found argument '${arg}' which wasn't expected, or isn't valid in this context`);
  err('');
  err(`If you tried to supply \`${arg}\` as a PATTERN use \`-- ${arg}\``);
  err('');
  err(`USAGE:\n    executable${sub ? ' ' + sub + (sub === 'get' ? ' [FLAGS] <mime>' : ' <SUBCOMMAND>') : ' <SUBCOMMAND>'}`);
  err('');
  err('For more information try --help');
  process.exit(2);
}

function main() {
  let args = process.argv.slice(2);
  if (args.length === 0) { out(mainHelp()); process.exit(2); }
  if (args[0] === '-h' || args[0] === '--help') { out(mainHelp()); return; }
  if (args[0] === '-V' || args[0] === '--version') { out(VERSION); return; }
  const sub = args.shift();
  if (!helps[sub]) unexpected(sub);
  if (args.includes('-h') || args.includes('--help')) { out(helps[sub]); return; }
  if (args.includes('-V') || args.includes('--version')) { out(`${sub} 0.6.4`); return; }
  if (sub !== 'get' && args.some(a => a.startsWith('--') && a !== '--all')) unexpected(args.find(a => a.startsWith('--')), sub);
  if (sub === 'get' && args.some(a => a.startsWith('--') && a !== '--json')) unexpected(args.find(a => a.startsWith('--')), sub);
  if (sub === 'list') return cmdList(args);
  if (sub === 'set') return cmdSet(args, false);
  if (sub === 'add') return cmdSet(args, true);
  if (sub === 'unset') return cmdUnset(args);
  if (sub === 'get') return cmdGet(args);
  if (sub === 'launch') return cmdLaunch(args);
  if (sub === 'open') return cmdOpen(args);
}

main();
