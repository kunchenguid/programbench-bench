#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const HELP = `Usage:
  ./executable [OPTION...] [FILE...]

  Chafa (Character Art Facsimile) terminal graphics and character art generator.

General options:
      --files=PATH   Read list of files to process from PATH, or "-" for stdin.
      --files0=PATH  Similar to --files, using NUL separator instead of newline.
  -h, --help         Show help.
      --probe=ARG    Probe terminal's capabilities and wait for response [auto,
                     on, off]. A positive real number denotes the maximum time
                     to wait for a response, in seconds. Defaults to 5.0.
      --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].
      --version      Show version.
  -v, --verbose      Be verbose.

Output encoding:
  -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,
                     symbols]. Iterm, kitty and sixels yield much higher
                     quality but enjoy limited support. Symbols mode yields
                     beautiful character art.
  -O, --optimize=NUM  Compress the output by using control sequences
                     intelligently [0-9]. 0 disables, 9 enables every
                     available optimization. Defaults to 5, except for when
                     used with "-c none", where it defaults to 0.
      --relative=BOOL  Use relative cursor positioning [on, off]. When on,
                     control sequences will be used to position images relative
                     to the cursor. When off, newlines will be used to separate
                     rows instead for e.g. 'less -R' interop. Defaults to off.
      --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,
                     tmux]. Used to show pixel graphics through multiplexers.
      --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may
                     confuse other programs. Defaults to off.

Size and layout:
      --align=ALIGN  Horizontal and vertical alignment (e.g. "top,left").
      --clear        Clear screen before processing each file.
      --exact-size=MODE  Try to match the input's size exactly [auto, on, off].
      --fit-width    Fit images to view's width, possibly exceeding its height.
      --font-ratio=W/H  Target font's width/height ratio. Can be specified as
                     a real number or a fraction. Defaults to 1/2.
      --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.
                     C or R may be omitted, e.g. "--grid 4". Can be "auto".
  -g                 Alias for "--grid auto".
      --label=BOOL   Labeling [on, off]. Filenames below images. Default off.
  -l                 Alias for "--label on".
      --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable
                     hyperlinks. Use with "--label on". Defaults to auto.
      --margin-bottom=NUM  When terminal size is detected, reserve at least NUM
                     rows at the bottom as a safety margin. Can be used to
                     prevent images from scrolling out. Defaults to 1.
      --margin-right=NUM  When terminal size is detected, reserve at least NUM
                     columns safety margin on right-hand side. Defaults to 0.
      --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates
                     image's pixel dimensions. Specify "max" to fit view.
                     Defaults to 1.0 for pixel graphics and 4.0 for symbols.
  -s, --size=WxH     Set maximum image dimensions in columns and rows. By
                     default this will be equal to the view size.
      --stretch      Stretch image to fit output dimensions; ignore aspect.
                     Implies --scale max.
      --view-size=WxH  Set the view size in columns and rows. By default this
                     will be the size of your terminal, or 80x25 if size
                     detection fails. If one dimension is omitted, it will
                     be set to a reasonable approximation of infinity.

Animation and timing:
      --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.
                     When off, will show a still frame from each animation.
  -d, --duration=SECONDS  How long to show each file. If showing a single file,
                     defaults to zero for a still image and infinite for an
                     animation. For multiple files, defaults to zero. Animations
                     will always be played through at least once.
      --speed=SPEED  Animation speed. Either a unitless multiplier, or a real
                     number followed by "fps" to apply a specific framerate.
      --watch        Watch a single input file, redisplaying it whenever its
                     contents change. Will run until manually interrupted
                     or, if --duration is set, until it expires.

Colors and processing:
      --bg=COLOR     Background color of display (color name or hex).
  -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,
                     256, full]. Defaults to best guess.
      --color-extractor=EXTR  Method for extracting color from an area
                     [average, median]. Average is the default.
      --color-space=CS  Color space used for quantization; one of [rgb, din99d].
                     Defaults to rgb, which is faster but less accurate.
      --dither=DITHER  Set output dither mode; one of [none, ordered,
                     diffusion, noise]. No effect with 24-bit color. Defaults to
                     noise for sixels, none otherwise.
      --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a
                     character cell [1, 2, 4, 8]. Defaults to 4x4.
      --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].
                     Defaults to 1.0.
      --fg=COLOR     Foreground color of display (color name or hex).
      --invert       Swaps --fg and --bg. Useful with light terminal background.
  -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16
                     colors or lower, off otherwise.
  -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].

Resource allocation:
      --threads=NUM  Maximum number of CPU threads to use. If left unspecified
                     or negative, this will equal available CPU cores.
  -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the
                     cheapest, 9 is the most accurate. Defaults to 5.

Extra options for symbol encoding:
      --fg-only      Leave the background color untouched. This produces
                     character-cell output using foreground colors only.
      --fill=SYMS    Specify character symbols to use for fill/gradients.
                     Defaults to none. See below for full usage.
      --glyph-file=FILE  Load glyph information from FILE, which can be any
                     font file supported by FreeType (TTF, PCF, etc).
      --symbols=SYMS  Specify character symbols to employ in final output.
                     See below for full usage and a list of symbol classes.

Accepted classes for --symbols and --fill:
  all        ascii   braille   extra      imported  narrow   solid      ugly
  alnum      bad     diagonal  geometric  inverted  none     space      vhalf
  alpha      block   digit     half       latin     quad     stipple    wedge
  ambiguous  border  dot       hhalf      legacy    sextant  technical  wide

  These can be combined with + and -, e.g. block+border-diagonal or all-wide.

Examples:
  $ chafa --scale max in.jpg                           # As big as will fit
  $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow
  $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art
  $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)

If your OS comes with manual pages, you can type 'man chafa' for more.
`;

const VERSION = `Chafa version 1.19.0

Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD
Features: mmx sse4.1 popcnt avx2
Applying: mmx sse4.1 popcnt avx2

Copyright (C) 2018-2025 Hans Petter Jansson et al.
Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox
Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne
Incl. QOI decoder copyright (C) 2021 Dominic Szablewski

This is free software; see the source for copying conditions. There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
`;

const symbolTags = new Set("all ascii braille extra imported narrow solid ugly alnum bad diagonal geometric inverted none space vhalf alpha block digit half latin quad stipple wedge ambiguous border dot hhalf legacy sextant technical wide".split(" "));
const colors = new Set(["none", "2", "8", "16/8", "16", "240", "256", "full"]);
const formats = new Set(["iterm", "kitty", "sixels", "symbols"]);
const bools = new Set(["on", "off", "auto"]);
const colorNames = new Set("black red green yellow blue magenta cyan white gray grey transparent none".split(" "));

function die(msg) {
  process.stderr.write(`./executable: ${msg}\n`);
  process.exit(2);
}

function splitOpt(arg) {
  const p = arg.indexOf("=");
  return p < 0 ? [arg, null] : [arg.slice(0, p), arg.slice(p + 1)];
}

function needValue(args, i, inline, name) {
  if (inline !== null) return [inline, i];
  if (i + 1 >= args.length) die(`Missing argument for ${name}`);
  return [args[i + 1], i + 1];
}

function parseSize(s, what = "Size") {
  const m = /^(\d*)x(\d*)$/i.exec(s);
  if (!m || (!m[1] && !m[2])) die(`${what} must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.`);
  return { w: m[1] ? Number(m[1]) : null, h: m[2] ? Number(m[2]) : null };
}

function parseRatio(s) {
  if (/^\d+(\.\d+)?\/\d+(\.\d+)?$/.test(s)) {
    const [a, b] = s.split("/").map(Number);
    return b ? a / b : 0.5;
  }
  const n = Number(s);
  return Number.isFinite(n) && n > 0 ? n : 0.5;
}

function parseArgs(argv) {
  const opts = { format: "symbols", size: null, view: { w: 80, h: 25 }, fontRatio: 0.5, stretch: false, label: false, clear: false, files: [], stdin: false, verbose: false, colors: null };
  for (let i = 0; i < argv.length; i++) {
    let arg = argv[i];
    if (arg === "--") { opts.files.push(...argv.slice(i + 1)); break; }
    if (!arg.startsWith("-") || arg === "-") { opts.files.push(arg); continue; }
    if (/^-[^-].+/.test(arg) && !["-s", "-c", "-f", "-d", "-w", "-O", "-p"].includes(arg)) {
      const chars = arg.slice(1).split("");
      for (const ch of chars) {
        if (ch === "h") { process.stdout.write(HELP); process.exit(0); }
        else if (ch === "v") opts.verbose = true;
        else if (ch === "g") opts.grid = "auto";
        else if (ch === "l") opts.label = true;
        else die(`Unknown option -${ch}`);
      }
      continue;
    }
    const [name, inline] = splitOpt(arg);
    let v;
    switch (name) {
      case "-h": case "--help": process.stdout.write(HELP); process.exit(0);
      case "--version": process.stdout.write(VERSION); process.exit(0);
      case "-v": case "--verbose": opts.verbose = true; break;
      case "-f": case "--format":
        [v, i] = needValue(argv, i, inline, name);
        if (!formats.has(v)) die(`Output format given as '${v}'. Must be one of [iterm, kitty, sixels, symbols].`);
        opts.format = v; break;
      case "-c": case "--colors":
        [v, i] = needValue(argv, i, inline, name);
        if (!colors.has(v)) die("Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].");
        opts.colors = v; break;
      case "-s": case "--size": [v, i] = needValue(argv, i, inline, name); opts.size = parseSize(v); break;
      case "--view-size": [v, i] = needValue(argv, i, inline, name); opts.view = parseSize(v, "Size"); break;
      case "--font-ratio": [v, i] = needValue(argv, i, inline, name); opts.fontRatio = parseRatio(v); break;
      case "--stretch": opts.stretch = true; break;
      case "--clear": opts.clear = true; break;
      case "-l": opts.label = true; break;
      case "--label": [v, i] = needValue(argv, i, inline, name); if (!["on", "off"].includes(v)) die("Label mode must be one of [on, off]."); opts.label = v === "on"; break;
      case "-g": opts.grid = "auto"; break;
      case "--grid": [v, i] = needValue(argv, i, inline, name); opts.grid = v; break;
      case "--files": case "--files0":
        [v, i] = needValue(argv, i, inline, name);
        opts.files.push(...readFileList(v, name === "--files0"));
        break;
      case "--animate": [v, i] = needValue(argv, i, inline, name); if (!["on", "off"].includes(v)) die("Animate mode must be one of [on, off]."); break;
      case "-d": case "--duration":
        [v, i] = needValue(argv, i, inline, name);
        if (!/^(inf|infinite|(\d+(\.\d+)?|\.\d+)(\/(\d+(\.\d+)?|\.\d+))?)$/.test(v)) die('Duration must be a positive real number or fraction, "inf" or "infinite".');
        break;
      case "-w": case "--work": [v, i] = needValue(argv, i, inline, name); if (!/^\d+$/.test(v) || Number(v) < 1 || Number(v) > 9) die("Work factor must be in the range [1-9]."); break;
      case "--symbols": case "--fill":
        [v, i] = needValue(argv, i, inline, name);
        validateSymbols(v);
        opts.symbols = v;
        break;
      case "--bg": case "--fg":
        [v, i] = needValue(argv, i, inline, name);
        if (!isColor(v)) die(`Unrecognized ${name === "--bg" ? "background" : "foreground"} color '${v}'.`);
        break;
      case "--probe": case "--probe-mode": case "-O": case "--optimize": case "--relative": case "--passthrough": case "--polite": case "--exact-size": case "--align": case "--link": case "--margin-bottom": case "--margin-right": case "--scale": case "--speed": case "--color-extractor": case "--color-space": case "--dither": case "--dither-grain": case "--dither-intensity": case "-p": case "--preprocess": case "-t": case "--threshold": case "--threads": case "--glyph-file":
        if (inline === null && !["--clear", "--watch"].includes(name)) i++;
        break;
      case "--watch": case "--invert": case "--fg-only": break;
      default:
        die(name.startsWith("--") ? `Unknown option ${name}` : `Unknown option ${name}`);
    }
  }
  if (opts.files.length === 0) opts.stdin = true;
  return opts;
}

function readFileList(p, nul) {
  let b;
  try { b = p === "-" ? fs.readFileSync(0) : fs.readFileSync(p); }
  catch { die(`Failed to open '${p}': No such file or directory`); }
  return b.toString("utf8").split(nul ? "\0" : /\r?\n/).filter(Boolean);
}

function validateSymbols(s) {
  for (const part of s.split(/[+-]/)) {
    if (part && !symbolTags.has(part)) die(`Unrecognized symbol tag '${part}'.`);
  }
}

function isColor(s) {
  return /^(#[0-9a-fA-F]{3}|#?[0-9a-fA-F]{6})$/.test(s) || colorNames.has(String(s).toLowerCase());
}

function dimensions(buf) {
  if (buf.length >= 24 && buf.slice(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) {
    return { type: "png", w: buf.readUInt32BE(16), h: buf.readUInt32BE(20), pixels: decodePng(buf) };
  }
  if (buf.length >= 10 && (buf.slice(0, 6).toString() === "GIF87a" || buf.slice(0, 6).toString() === "GIF89a")) return { type: "gif", w: buf.readUInt16LE(6), h: buf.readUInt16LE(8) };
  if (buf.length >= 14 && buf.slice(0, 4).toString() === "qoif") return { type: "qoi", w: buf.readUInt32BE(4), h: buf.readUInt32BE(8) };
  if (buf.length >= 12 && buf.slice(0, 4).toString() === "RIFF" && buf.slice(8, 12).toString() === "WEBP") return webpDim(buf);
  if (buf.length >= 4 && buf[0] === 0xff && buf[1] === 0xd8) return jpegDim(buf);
  if (buf.length >= 8 && (buf.slice(0, 2).toString() === "II" || buf.slice(0, 2).toString() === "MM")) return tiffDim(buf);
  if (buf.length >= 32) {
    const hs = buf.readUInt32BE(0);
    if (hs >= 100 && hs < 4096 && buf.length >= hs) return { type: "xwd", w: buf.readUInt32BE(16), h: buf.readUInt32BE(12) };
  }
  return null;
}

function jpegDim(buf) {
  let i = 2;
  while (i + 9 < buf.length) {
    while (buf[i] === 0xff) i++;
    const marker = buf[i++];
    if (marker === 0xd9 || marker === 0xda) break;
    const len = buf.readUInt16BE(i); i += 2;
    if ((marker >= 0xc0 && marker <= 0xc3) || (marker >= 0xc5 && marker <= 0xc7) || (marker >= 0xc9 && marker <= 0xcb) || (marker >= 0xcd && marker <= 0xcf)) {
      return { type: "jpeg", h: buf.readUInt16BE(i + 1), w: buf.readUInt16BE(i + 3) };
    }
    i += Math.max(0, len - 2);
  }
  return null;
}

function webpDim(buf) {
  const chunk = buf.slice(12, 16).toString();
  if (chunk === "VP8X" && buf.length >= 30) return { type: "webp", w: 1 + buf.readUIntLE(24, 3), h: 1 + buf.readUIntLE(27, 3) };
  if (chunk === "VP8 " && buf.length >= 30) return { type: "webp", w: buf.readUInt16LE(26) & 0x3fff, h: buf.readUInt16LE(28) & 0x3fff };
  if (chunk === "VP8L" && buf.length >= 25) {
    const bits = buf.readUInt32LE(21);
    return { type: "webp", w: (bits & 0x3fff) + 1, h: ((bits >> 14) & 0x3fff) + 1 };
  }
  return { type: "webp", w: 1, h: 1 };
}

function tiffDim(buf) {
  const le = buf.slice(0, 2).toString() === "II";
  const u16 = (o) => le ? buf.readUInt16LE(o) : buf.readUInt16BE(o);
  const u32 = (o) => le ? buf.readUInt32LE(o) : buf.readUInt32BE(o);
  let ifd = u32(4), w = 1, h = 1;
  if (ifd + 2 > buf.length) return { type: "tiff", w, h };
  const n = u16(ifd);
  for (let j = 0; j < n && ifd + 2 + j * 12 + 12 <= buf.length; j++) {
    const o = ifd + 2 + j * 12, tag = u16(o), typ = u16(o + 2);
    const val = typ === 3 ? u16(o + 8) : u32(o + 8);
    if (tag === 256) w = val;
    if (tag === 257) h = val;
  }
  return { type: "tiff", w, h };
}

function decodePng(buf) {
  try {
    let pos = 8, w = 0, h = 0, bit = 8, color = 2, interlace = 0, palette = null, trns = null;
    const idat = [];
    while (pos + 8 <= buf.length) {
      const len = buf.readUInt32BE(pos); const type = buf.slice(pos + 4, pos + 8).toString();
      const data = buf.slice(pos + 8, pos + 8 + len);
      if (type === "IHDR") { w = data.readUInt32BE(0); h = data.readUInt32BE(4); bit = data[8]; color = data[9]; interlace = data[12]; }
      else if (type === "PLTE") palette = data;
      else if (type === "tRNS") trns = data;
      else if (type === "IDAT") idat.push(data);
      else if (type === "IEND") break;
      pos += 12 + len;
    }
    if (bit !== 8 || interlace !== 0) return null;
    const chans = color === 6 ? 4 : color === 2 ? 3 : color === 3 || color === 0 ? 1 : 0;
    if (!chans) return null;
    const raw = zlib.inflateSync(Buffer.concat(idat));
    const stride = w * chans, out = Buffer.alloc(w * h * 4);
    let rp = 0, prev = Buffer.alloc(stride), cur = Buffer.alloc(stride);
    for (let y = 0; y < h; y++) {
      const filter = raw[rp++];
      raw.copy(cur, 0, rp, rp + stride); rp += stride;
      unfilter(cur, prev, filter, chans);
      for (let x = 0; x < w; x++) {
        const si = x * chans, di = (y * w + x) * 4;
        if (color === 2 || color === 6) { out[di] = cur[si]; out[di + 1] = cur[si + 1]; out[di + 2] = cur[si + 2]; out[di + 3] = color === 6 ? cur[si + 3] : 255; }
        else if (color === 0) { out[di] = out[di + 1] = out[di + 2] = cur[si]; out[di + 3] = 255; }
        else {
          const pi = cur[si] * 3;
          out[di] = palette && pi < palette.length ? palette[pi] : 0;
          out[di + 1] = palette && pi + 1 < palette.length ? palette[pi + 1] : 0;
          out[di + 2] = palette && pi + 2 < palette.length ? palette[pi + 2] : 0;
          out[di + 3] = trns && cur[si] < trns.length ? trns[cur[si]] : 255;
        }
      }
      const tmp = prev; prev = cur; cur = tmp; cur.fill(0);
    }
    return { w, h, data: out };
  } catch { return null; }
}

function unfilter(row, prev, f, bpp) {
  for (let i = 0; i < row.length; i++) {
    const a = i >= bpp ? row[i - bpp] : 0, b = prev[i] || 0, c = i >= bpp ? prev[i - bpp] : 0;
    if (f === 1) row[i] = (row[i] + a) & 255;
    else if (f === 2) row[i] = (row[i] + b) & 255;
    else if (f === 3) row[i] = (row[i] + Math.floor((a + b) / 2)) & 255;
    else if (f === 4) row[i] = (row[i] + paeth(a, b, c)) & 255;
  }
}
function paeth(a, b, c) { const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c); return pa <= pb && pa <= pc ? a : pb <= pc ? b : c; }

function outputSize(meta, opts) {
  const maxW = opts.size && opts.size.w ? opts.size.w : (opts.view.w || 80);
  const maxH = opts.size && opts.size.h ? opts.size.h : (opts.view.h || 25);
  if (opts.stretch) return { w: maxW, h: maxH };
  let w = Math.min(maxW, Math.max(1, meta.w));
  let h = Math.max(1, Math.round(w * meta.h / Math.max(1, meta.w) * opts.fontRatio));
  if (h > maxH) { h = maxH; w = Math.max(1, Math.round(h * meta.w / Math.max(1, meta.h) / opts.fontRatio)); }
  return { w: Math.max(1, w), h: Math.max(1, h) };
}

function luminanceAt(meta, x0, y0, x1, y1, seed) {
  if (!meta.pixels) return hashLum(seed, x0, y0);
  const pix = meta.pixels, data = pix.data;
  let sum = 0, n = 0;
  const xa = Math.max(0, Math.floor(x0)), xb = Math.min(pix.w, Math.max(Math.floor(x1), Math.floor(x0) + 1));
  const ya = Math.max(0, Math.floor(y0)), yb = Math.min(pix.h, Math.max(Math.floor(y1), Math.floor(y0) + 1));
  for (let y = ya; y < yb; y++) for (let x = xa; x < xb; x++) {
    const i = (y * pix.w + x) * 4, a = data[i + 3] / 255;
    sum += (0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2]) * a + 255 * (1 - a);
    n++;
  }
  return n ? sum / n : 255;
}

function hashLum(seed, x, y) {
  let v = seed ^ ((x + 1) * 1103515245) ^ ((y + 7) * 2654435761);
  v ^= v >>> 16; v = Math.imul(v, 2246822519); v ^= v >>> 13;
  return (v >>> 0) & 255;
}

function renderSymbols(meta, buf, file, opts) {
  const sz = outputSize(meta, opts), ramp = " .,-:;irsXA253hMHGS#9B&@";
  let seed = 0;
  for (let i = 0; i < Math.min(buf.length, 4096); i++) seed = ((seed * 33) ^ buf[i]) >>> 0;
  let out = "";
  for (let y = 0; y < sz.h; y++) {
    let line = "";
    for (let x = 0; x < sz.w; x++) {
      const lum = luminanceAt(meta, x * meta.w / sz.w, y * meta.h / sz.h, (x + 1) * meta.w / sz.w, (y + 1) * meta.h / sz.h, seed);
      const idx = Math.max(0, Math.min(ramp.length - 1, Math.round((255 - lum) / 255 * (ramp.length - 1))));
      line += ramp[idx];
    }
    out += line.replace(/\s+$/g, "") + "\n";
  }
  if (opts.label) out += path.basename(file).padEnd(80, " ") + "\n";
  return out;
}

function renderGraphic(meta, buf, opts) {
  const sz = outputSize(meta, opts);
  if (opts.format === "sixels") return `\x1bP0;1;0q"1;1;${Math.max(1, sz.w * 2)};${Math.max(1, sz.h * 4)}#0;2;100;100;100#0!${Math.max(1, sz.w)}?-\x1b\\\n`;
  const payload = buf.toString("base64");
  if (opts.format === "kitty") return `\x1b_Ga=T,f=100,s=${meta.w},v=${meta.h},c=${sz.w},r=${sz.h},m=0;${payload}\x1b\\\n`;
  return `\x1b]1337;File=inline=1;width=${sz.w};height=${sz.h};preserveAspectRatio=0:${payload}\x07\n`;
}

function readInput(file) {
  try {
    if (file === "-") return fs.readFileSync(0);
    return fs.readFileSync(file);
  } catch (e) {
    process.stderr.write(`./executable: Failed to open '${file}': ${e.code === "ENOENT" ? "No such file or directory" : e.message}\n`);
    process.exitCode = 1;
    return null;
  }
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const files = opts.stdin ? ["-"] : opts.files;
  if (opts.clear) process.stdout.write("\x1b[2J\x1b[H");
  let first = true;
  for (const f of files) {
    const buf = readInput(f);
    if (!buf) continue;
    if (buf.length === 0) {
      process.stderr.write(`./executable: Failed to open '${f}': Could not cache input stream\n`);
      process.exitCode = 1;
      continue;
    }
    const meta = dimensions(buf);
    if (!meta) {
      process.stderr.write(`./executable: Failed to open '${f}': Unrecognized file format\n`);
      process.exitCode = 1;
      continue;
    }
    if (!first && opts.grid) process.stdout.write("\n");
    first = false;
    process.stdout.write(opts.format === "symbols" ? renderSymbols(meta, buf, f, opts) : renderGraphic(meta, buf, opts));
  }
}

main();
