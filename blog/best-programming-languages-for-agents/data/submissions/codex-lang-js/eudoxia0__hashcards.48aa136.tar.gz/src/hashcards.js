#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const http = require("http");

const VERSION = "hashcards 0.3.0";
const ABOUT = "A plain text-based spaced repetition system.";

function sha(value) {
  return crypto.createHash("sha256").update(value, "utf8").digest("hex");
}

function println(s = "") {
  process.stdout.write(String(s) + "\n");
}

function die(message, code = 1) {
  process.stderr.write(message + "\n");
  process.exit(code);
}

function mainHelp() {
  return `${ABOUT}

Usage: executable <COMMAND>

Commands:
  drill    Drill cards through a web interface
  check    Check the integrity of a collection
  stats    Print collection statistics
  orphans  Commands relating to orphan cards
  export   Export a collection
  help     Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version`;
}

const helps = {
  stats: `Print collection statistics

Usage: executable stats [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]
          Path to the collection directory. By default, the current working directory is used

Options:
      --format <FORMAT>
          Which output format to use

          Possible values:
          - html: HTML output
          - json: JSON output
          
          [default: html]

  -h, --help
          Print help (see a summary with '-h')`,
  check: `Check the integrity of a collection

Usage: executable check [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help`,
  export: `Export a collection

Usage: executable export [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
      --output <OUTPUT>  Optional path to the output file. By default, the output is printed to stdout
  -h, --help             Print help`,
  orphans: `Commands relating to orphan cards

Usage: executable orphans <COMMAND>

Commands:
  list    List the hashes of all orphan cards in the collection
  delete  Remove all orphan cards from the database
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help`,
  "orphans list": `List the hashes of all orphan cards in the collection

Usage: executable orphans list [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help`,
  "orphans delete": `Remove all orphan cards from the database

Usage: executable orphans delete [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help`,
  drill: `Drill cards through a web interface

Usage: executable drill [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]
          Path to the collection directory. By default, the current working directory is used

Options:
      --card-limit <CARD_LIMIT>
          Maximum number of cards to drill in a session. By default, all cards due today are drilled

      --new-card-limit <NEW_CARD_LIMIT>
          Maximum number of new cards to drill in a session

      --host <HOST>
          The host address to bind to. Default is 127.0.0.1
          
          [default: 127.0.0.1]

      --port <PORT>
          The port to use for the web server. Default is 8000
          
          [default: 8000]

      --from-deck <FROM_DECK>
          Only drill cards from this deck

      --open-browser <OPEN_BROWSER>
          Whether to open the browser automatically. Default is true
          
          [possible values: true, false]

      --answer-controls <ANSWER_CONTROLS>
          Which answer controls to show:

          Possible values:
          - full:   Show all four rating buttons (Forgot/Hard/Good/Easy)
          - binary: Show only two rating buttons (Forgot/Good)
          
          [default: full]

      --bury-siblings <BURY_SIBLINGS>
          Whether or not to bury siblings. Default is true
          
          [possible values: true, false]

  -h, --help
          Print help (see a summary with '-h')`,
};

function listFiles(root) {
  const out = [];
  function walk(dir) {
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(p);
      else if (ent.isFile()) out.push(p);
    }
  }
  walk(root);
  return out.sort();
}

function trimBlankEdges(lines) {
  let start = 0;
  let end = lines.length;
  while (start < end && lines[start].trim() === "") start++;
  while (end > start && lines[end - 1].trim() === "") end--;
  return lines.slice(start, end).join("\n");
}

function cardEndExclusive(lines, from) {
  for (let i = from + 1; i < lines.length; i++) {
    if (/^(Q|C):(?:\s|$)/.test(lines[i])) return i;
  }
  return lines.length;
}

function parseCloze(raw) {
  let text = "";
  const spans = [];
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (ch === "[") {
      const close = raw.indexOf("]", i + 1);
      if (close !== -1) {
        const inner = raw.slice(i + 1, close);
        const start = text.length;
        text += inner;
        const end = text.length === start ? start : text.length - 1;
        spans.push({ start, end });
        i = close;
        continue;
      }
    }
    text += ch;
  }
  return { text, spans };
}

function parseMarkdown(file, root) {
  const deckName = path.basename(file).replace(/\.md$/i, "");
  const content = fs.readFileSync(file, "utf8").replace(/\r\n/g, "\n");
  const lines = content.split("\n");
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  const cards = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.startsWith("Q:")) {
      const end = cardEndExclusive(lines, i);
      const lineEnd = end === lines.length ? Math.max(i, lines.length - 1) : end;
      const a = (() => {
        for (let j = i; j < end; j++) if (lines[j].startsWith("A:")) return j;
        return -1;
      })();
      if (a === -1) continue;
      const qLines = [line.slice(2).trimStart(), ...lines.slice(i + 1, a)];
      const aFirst = lines[a].slice(2).trimStart();
      const aLines = [aFirst, ...lines.slice(a + 1, end)];
      const question = trimBlankEdges(qLines);
      const answer = trimBlankEdges(aLines);
      const hash = sha("basic\n" + question + "\n---\n" + answer);
      const obj = {
        hash,
        familyHash: null,
        deckName,
        location: { filePath: file, lineStart: i, lineEnd },
        content: { basic: { question, answer } },
        performance: null,
      };
      cards.push(obj);
      i = end - 1;
    } else if (line.startsWith("C:")) {
      const end = cardEndExclusive(lines, i);
      const lineEnd = end === lines.length ? Math.max(i, lines.length - 1) : end;
      const first = line.slice(2).trimStart();
      const raw = trimBlankEdges([first, ...lines.slice(i + 1, end)]);
      const parsed = parseCloze(raw);
      if (parsed.spans.length === 0) {
        die(`hashcards: error: Parse error: Cloze card must contain at least one cloze deletion. Location: ${file}:${i + 1}`);
      }
      const familyHash = sha("cloze-family\n" + parsed.text);
      for (const span of parsed.spans) {
        const hash = sha("cloze\n" + parsed.text + "\n" + span.start + "\n" + span.end);
        const obj = {
          hash,
          familyHash,
          deckName,
          location: { filePath: file, lineStart: i, lineEnd },
          content: { cloze: { text: parsed.text, start: span.start, end: span.end } },
          performance: null,
        };
        cards.push(obj);
      }
      i = end - 1;
    }
  }
  return cards;
}

function loadCollection(dirArg) {
  const dir = path.resolve(dirArg || process.cwd());
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) {
    die("hashcards: error: directory does not exist.");
  }
  const files = listFiles(dir);
  const cards = [];
  for (const f of files) {
    if (/\.md$/i.test(f)) cards.push(...parseMarkdown(f, dir));
  }
  cards.sort((a, b) => a.hash.localeCompare(b.hash));
  return { dir, cards, files };
}

function stats(dir, format) {
  const c = loadCollection(dir);
  if (format === "json") {
    const texMacroCount = c.files.filter((f) => path.basename(f) === "macros.tex").length;
    println(JSON.stringify({
      cardsInDeckCount: c.cards.length,
      cardsInDbCount: 0,
      texMacroCount,
      cardsReviewedTodayCount: 0,
    }, null, 2));
  } else {
    println("HTML output is not implemented yet.");
  }
}

function exportCollection(dir, output) {
  const c = loadCollection(dir);
  const body = JSON.stringify({ cards: c.cards, sessions: [] }, null, 2) + "\n";
  if (output) fs.writeFileSync(output, body);
  else process.stdout.write(body);
}

function parseOptionArgs(args, spec) {
  const opts = {};
  const positionals = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") opts.help = true;
    else if (spec.includes(a)) {
      if (i + 1 >= args.length) die(`error: a value is required for '${a}' but none was supplied`, 2);
      opts[a] = args[++i];
    } else if (a.startsWith("--")) {
      die(`error: unexpected argument '${a}' found`, 2);
    } else {
      positionals.push(a);
    }
  }
  return { opts, positionals };
}

function runDrill(args) {
  const { opts, positionals } = parseOptionArgs(args, [
    "--card-limit", "--new-card-limit", "--host", "--port", "--from-deck",
    "--open-browser", "--answer-controls", "--bury-siblings",
  ]);
  if (opts.help) return println(helps.drill);
  loadCollection(positionals[0]);
  const host = opts["--host"] || "127.0.0.1";
  const port = Number(opts["--port"] || 8000);
  const server = http.createServer((req, res) => {
    res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
    res.end("<!doctype html><title>Hashcards</title><h1>Hashcards</h1>\n");
  });
  server.listen(port, host);
}

function dispatch(argv) {
  const [cmd, ...rest] = argv;
  if (!cmd || cmd === "-h" || cmd === "--help" || cmd === "help") {
    if (cmd === "help" && rest.length) {
      const key = rest.join(" ");
      println(helps[key] || helps[rest[0]] || mainHelp());
    } else println(mainHelp());
    return;
  }
  if (cmd === "-V" || cmd === "--version") return println(VERSION);
  if (cmd === "stats") {
    const { opts, positionals } = parseOptionArgs(rest, ["--format"]);
    if (opts.help) return println(helps.stats);
    const format = opts["--format"] || "html";
    if (!["html", "json"].includes(format)) {
      die(`error: invalid value '${format}' for '--format <FORMAT>'\n  [possible values: html, json]\n\nFor more information, try '--help'.`, 2);
    }
    return stats(positionals[0], format);
  }
  if (cmd === "check") {
    const { opts, positionals } = parseOptionArgs(rest, []);
    if (opts.help) return println(helps.check);
    loadCollection(positionals[0]);
    return println("ok");
  }
  if (cmd === "export") {
    const { opts, positionals } = parseOptionArgs(rest, ["--output"]);
    if (opts.help) return println(helps.export);
    return exportCollection(positionals[0], opts["--output"]);
  }
  if (cmd === "orphans") {
    const sub = rest[0];
    if (!sub || sub === "-h" || sub === "--help" || sub === "help") {
      if (sub === "help" && rest[1]) println(helps["orphans " + rest[1]] || helps.orphans);
      else println(helps.orphans);
      return;
    }
    if (sub === "list" || sub === "delete") {
      const { opts, positionals } = parseOptionArgs(rest.slice(1), []);
      if (opts.help) return println(helps["orphans " + sub]);
      loadCollection(positionals[0]);
      return;
    }
    die(`error: unrecognized subcommand '${sub}'\n\nUsage: executable orphans <COMMAND>\n\nFor more information, try '--help'.`, 2);
  }
  if (cmd === "drill") return runDrill(rest);
  die(`error: unrecognized subcommand '${cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.`, 2);
}

dispatch(process.argv.slice(2));
