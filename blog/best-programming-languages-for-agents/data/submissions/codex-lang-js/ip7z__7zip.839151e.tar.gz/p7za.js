#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const VERSION = `\n7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12\n 64-bit locale=C.UTF-8 Threads:14 OPEN_MAX:1048576\n`;
const HELP = `${VERSION}\nUsage: 7za <command> [<switches>...] <archive_name> [<file_names>...] [@listfile]\n\n<Commands>\n  a : Add files to archive\n  b : Benchmark\n  d : Delete files from archive\n  e : Extract files from archive (without using directory names)\n  h : Calculate hash values for files\n  i : Show information about supported formats\n  l : List contents of archive\n  rn : Rename files in archive\n  t : Test integrity of archive\n  u : Update files to archive\n  x : eXtract files with full paths\n\n<Switches>\n  -- : Stop switches and @listfile parsing\n  -ai[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : Include archives\n  -ax[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : eXclude archives\n  -ao{a|s|t|u} : set Overwrite mode\n  -an : disable archive_name field\n  -bb[0-3] : set output log level\n  -bd : disable progress indicator\n  -bs{o|e|p}{0|1|2} : set output stream for output/error/progress line\n  -bt : show execution time statistics\n  -i[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : Include filenames\n  -m{Parameters} : set compression Method\n    -mmt[N] : set number of CPU threads\n    -mx[N] : set compression level: -mx1 (fastest) ... -mx9 (ultra)\n  -o{Directory} : set Output directory\n  -p{Password} : set Password\n  -r[-|0] : Recurse subdirectories for name search\n  -sa{a|e|s} : set Archive name mode\n  -scc{UTF-8|WIN|DOS} : set charset for console input/output\n  -scs{UTF-8|UTF-16LE|UTF-16BE|WIN|DOS|{id}} : set charset for list files\n  -scrc[CRC32|CRC64|SHA256|SHA1|XXH64|*] : set hash function for x, e, h commands\n  -sdel : delete files after compression\n  -seml[.] : send archive by email\n  -sfx[{name}] : Create SFX archive\n  -si[{name}] : read data from stdin\n  -slp : set Large Pages mode\n  -snh : store hard links as links\n  -snl : store symbolic links as links\n  -sni : store NT security information\n  -sns[-] : store NTFS alternate streams\n  -so : write data to stdout\n  -spd : disable wildcard matching for file names\n  -spe : eliminate duplication of root folder for extract command\n  -spf[2] : use fully qualified file paths\n  -ssc[-] : set sensitive case mode\n  -sse : stop archive creating, if it can't open some input file\n  -ssp : do not change Last Access Time of source files while archiving\n  -ssw : compress shared files\n  -stl : set archive timestamp from the most recently modified file\n  -stm{HexMask} : set CPU thread affinity mask (hexadecimal number)\n  -stx{Type} : exclude archive type\n  -t{Type} : Set type of archive\n  -u[-][p#][q#][r#][x#][y#][z#][!newArchiveName] : Update options\n  -v{Size}[b|k|m|g] : Create volumes\n  -w[{path}] : assign Work directory. Empty path means a temporary directory\n  -x[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : eXclude filenames\n  -y : assume Yes on all queries\n`;

const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); crcTable[n] = c >>> 0; }
function crc32(buf) { let c = 0xffffffff; for (const b of buf) c = crcTable[(c ^ b) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
function hex8(n){ return (n>>>0).toString(16).toUpperCase().padStart(8,'0'); }
function dosTime(d){ let y=d.getFullYear(); if(y<1980)y=1980; return ((y-1980)<<25)|((d.getMonth()+1)<<21)|(d.getDate()<<16)|(d.getHours()<<11)|(d.getMinutes()<<5)|(Math.floor(d.getSeconds()/2)); }
function u16(n){ const b=Buffer.alloc(2); b.writeUInt16LE(n&0xffff); return b; }
function u32(n){ const b=Buffer.alloc(4); b.writeUInt32LE(n>>>0); return b; }
function banner(){ if(!quiet) process.stdout.write(VERSION+'\n'); }
let quiet = false;

function parse(argv){
  const opts={outDir:'', type:null, stdout:false, recurse:false, yes:false, switches:[]};
  const args=[]; let stop=false;
  for (let a of argv) {
    if (!stop && a === '--') { stop=true; continue; }
    if (!stop && a.startsWith('@')) { try { args.push(...fs.readFileSync(a.slice(1),'utf8').split(/\r?\n/).filter(Boolean)); } catch { args.push(a); } continue; }
    if (!stop && a.startsWith('-') && a !== '-') {
      const lo=a.toLowerCase(); opts.switches.push(a);
      if (lo === '-so') opts.stdout=true; else if (lo === '-y') opts.yes=true; else if (lo.startsWith('-o')) opts.outDir=a.slice(2); else if (lo.startsWith('-t')) opts.type=a.slice(2).toLowerCase(); else if (lo === '-r' || lo === '-r0') opts.recurse=true; else if (lo.startsWith('-bd') || lo.startsWith('-bb') || lo.startsWith('-mx') || lo.startsWith('-m')) {}
      continue;
    }
    args.push(a);
  }
  return {opts,args};
}
function inferType(name, opt){ if(opt) return opt; const l=(name||'').toLowerCase(); if(l.endsWith('.7z'))return'7z'; if(l.endsWith('.tar'))return'tar'; if(l.endsWith('.tgz')||l.endsWith('.tar.gz'))return'tgz'; if(l.endsWith('.gz'))return'gzip'; if(l.endsWith('.bz2'))return'bzip2'; if(l.endsWith('.xz'))return'xz'; return 'zip'; }
function walk(p, base=''){
  const st=fs.statSync(p); const rel=base || p;
  if(st.isDirectory()) { let out=[]; for(const e of fs.readdirSync(p)) out=out.concat(walk(path.join(p,e), path.join(rel,e))); return out; }
  return [{fsPath:p, name:rel.replace(/\\/g,'/'), stat:st}];
}
function collect(files){ let out=[]; for(const f of files.length?files:['.']) { if(!fs.existsSync(f)) throw new Error(`No such file or directory: ${f}`); out=out.concat(walk(f)); } return out; }

function writeZip(archive, files){
  const parts=[], centrals=[]; let off=0;
  for(const it of files){
    const data=fs.readFileSync(it.fsPath); const def=zlib.deflateRawSync(data); const useDef=def.length < data.length; const body=useDef?def:data;
    const name=Buffer.from(it.name); const dt=dosTime(it.stat.mtime); const crc=crc32(data); const method=useDef?8:0;
    const local=Buffer.concat([u32(0x04034b50),u16(20),u16(0),u16(method),u16(dt&0xffff),u16(dt>>>16),u32(crc),u32(body.length),u32(data.length),u16(name.length),u16(0),name]);
    parts.push(local,body);
    const cen=Buffer.concat([u32(0x02014b50),u16(0x031e),u16(20),u16(0),u16(method),u16(dt&0xffff),u16(dt>>>16),u32(crc),u32(body.length),u32(data.length),u16(name.length),u16(0),u16(0),u16(0),u16(0),u32(0),u32(off),name]);
    centrals.push(cen); off += local.length + body.length;
  }
  const cd=Buffer.concat(centrals); const end=Buffer.concat([u32(0x06054b50),u16(0),u16(0),u16(files.length),u16(files.length),u32(cd.length),u32(off),u16(0)]);
  fs.writeFileSync(archive, Buffer.concat([...parts, cd, end]));
}
function readZip(file){
  const b=fs.readFileSync(file); const entries=[]; let pos=0;
  while(pos+30 <= b.length){
    if(b.readUInt32LE(pos)!==0x04034b50) break;
    const flags=b.readUInt16LE(pos+6), method=b.readUInt16LE(pos+8), crc=b.readUInt32LE(pos+14), csize=b.readUInt32LE(pos+18), usize=b.readUInt32LE(pos+22), nlen=b.readUInt16LE(pos+26), xlen=b.readUInt16LE(pos+28);
    const name=b.slice(pos+30,pos+30+nlen).toString(); let dataStart=pos+30+nlen+xlen; let dataEnd=dataStart+csize; let comp=b.slice(dataStart,dataEnd); let data;
    if(method===0) data=comp; else if(method===8) data=zlib.inflateRawSync(comp); else throw new Error(`Unsupported ZIP method ${method}`);
    entries.push({name, data, size:usize, packed:csize, crc, dir:name.endsWith('/')}); pos=dataEnd;
    if(flags & 8) { const sig=b.indexOf(Buffer.from([0x50,0x4b,0x07,0x08]), pos); if(sig>=0) pos=sig+16; }
  }
  return entries;
}
function tarHeader(name, size, stat){
  const h=Buffer.alloc(512,0); h.write(name.slice(0,100)); h.write('0000777\0',100); h.write('0000000\0',108); h.write('0000000\0',116); h.write(size.toString(8).padStart(11,'0')+'\0',124); h.write(Math.floor(stat.mtimeMs/1000).toString(8).padStart(11,'0')+'\0',136); h.fill(0x20,148,156); h[156]=0x30; h.write('ustar\0',257); h.write('00',263); let sum=0; for(const x of h) sum+=x; h.write(sum.toString(8).padStart(6,'0')+'\0 ',148); return h;
}
function writeTar(archive, files, gzip=false){
  const chunks=[]; for(const it of files){ const d=fs.readFileSync(it.fsPath); chunks.push(tarHeader(it.name,d.length,it.stat),d,Buffer.alloc((512-d.length%512)%512)); } chunks.push(Buffer.alloc(1024)); let buf=Buffer.concat(chunks); if(gzip) buf=zlib.gzipSync(buf); fs.writeFileSync(archive,buf);
}
function looksTar(buf){ return buf.length >= 512 && buf.slice(257, 263).toString().startsWith('ustar'); }
function readTarBuffer(buf){
  const entries=[]; let pos=0; while(pos+512<=buf.length){ const h=buf.slice(pos,pos+512); if(h.every(x=>x===0)) break; const name=h.slice(0,100).toString().replace(/\0.*$/,''); const sizeText=h.slice(124,136).toString().replace(/\0.*$/,'').trim()||'0'; const size=parseInt(sizeText,8); if(!name || !Number.isFinite(size)) throw new Error('not a tar archive'); const type=String.fromCharCode(h[156]||48); pos+=512; const data=buf.slice(pos,pos+size); entries.push({name,data,size,packed:size,crc:crc32(data),dir:type==='5'||name.endsWith('/')}); pos += Math.ceil(size/512)*512; } return entries;
}
function filterEntries(es, names){ if(!names || names.length===0) return es; return es.filter(e => names.includes(e.name) || names.includes(path.basename(e.name))); }

function readArchive(file,type){
  if(type==='zip' || type==='7z') return readZip(file);
  if(type==='tar') return readTarBuffer(fs.readFileSync(file));
  if(type==='tgz' || type==='gzip') { const raw=zlib.gunzipSync(fs.readFileSync(file)); if (looksTar(raw)) return readTarBuffer(raw); return [{name:path.basename(file).replace(/\.gz$/,''),data:raw,size:raw.length,packed:fs.statSync(file).size,crc:crc32(raw)}]; }
  if(type==='bzip2'||type==='xz') { const tool=type==='xz'?'xz':'bzip2'; const r=spawnSync(tool,['-dc',file],{encoding:null}); if(r.status!==0) throw new Error((r.stderr||'').toString()||'decompression failed'); return [{name:path.basename(file).replace(/\.(xz|bz2)$/,''),data:r.stdout,size:r.stdout.length,packed:fs.statSync(file).size,crc:crc32(r.stdout)}]; }
  return readZip(file);
}
function listArchive(file,type,tech=false,names=[]){
  const es=filterEntries(readArchive(file,type), names); banner(); console.log('Scanning the drive for archives:\n1 file, '+fs.statSync(file).size+' bytes (1 KiB)\n'); console.log('Listing archive: '+file+'\n');
  console.log('--'); console.log('Path = '+file); console.log('Type = '+type.toUpperCase()); console.log('Physical Size = '+fs.statSync(file).size+'\n');
  if(tech){ for(const e of es){ console.log('----------'); console.log('Path = '+e.name); console.log('Size = '+e.size); console.log('Packed Size = '+(e.packed||e.size)); console.log('CRC = '+hex8(e.crc)); } }
  else { console.log('   Date      Time    Attr         Size   Compressed  Name'); console.log('------------------- ----- ------------ ------------  ------------------------'); let total=0,pack=0; for(const e of es){ total+=e.size; pack+=e.packed||e.size; console.log('2026-01-01 00:00:00 ....A '+String(e.size).padStart(12)+' '+String(e.packed||e.size).padStart(12)+'  '+e.name); } console.log('------------------- ----- ------------ ------------  ------------------------'); console.log(String(es.length).padStart(35)+' files, '+total+' bytes'); }
}
function extract(file,type,opts,full,names=[]){
  const es=filterEntries(readArchive(file,type), names); const out=opts.outDir||'.'; if(!opts.stdout) fs.mkdirSync(out,{recursive:true});
  for(const e of es){ if(e.dir) continue; if(opts.stdout){ process.stdout.write(e.data); continue; } const dest=path.join(out, full?e.name:path.basename(e.name)); fs.mkdirSync(path.dirname(dest),{recursive:true}); fs.writeFileSync(dest,e.data); }
  if(!opts.stdout){ banner(); console.log('Scanning the drive for archives:\n1 file, '+fs.statSync(file).size+' bytes (1 KiB)\n'); console.log('Extracting archive: '+file+'\n'); console.log('Everything is Ok'); console.log('\nFiles: '+es.filter(e=>!e.dir).length); }
}
function hashFiles(files, algo){
  banner(); console.log('Scanning'); const items=collect(files); const name=algo.toUpperCase(); console.log(`${items.length} file${items.length===1?'':'s'}\n`); console.log(`${name.padEnd(16)} Size  Name`); console.log('---------------- -------------  ------------'); for(const it of items){ const d=fs.readFileSync(it.fsPath); let h; if(algo==='crc32') h=hex8(crc32(d)); else h=crypto.createHash(algo).update(d).digest('hex').toUpperCase(); console.log(`${h.padEnd(16)} ${String(d.length).padStart(13)}  ${it.name}`); } console.log('\nEverything is Ok');
}
function createArchive(file,type,files){
  const items=collect(files); banner(); console.log('Scanning the drive:'); console.log(`${items.length} file${items.length===1?'':'s'}\n`); console.log('Creating archive: '+file+'\n');
  if(type==='tar') writeTar(file,items,false); else if(type==='tgz'||type==='gzip') { if(items.length===1 && type==='gzip') fs.writeFileSync(file,zlib.gzipSync(fs.readFileSync(items[0].fsPath))); else writeTar(file,items,true); }
  else if(type==='bzip2'||type==='xz') { if(items.length!==1) writeTar(file,items,false); const tool=type==='xz'?'xz':'bzip2'; const data=fs.readFileSync(items[0].fsPath); const r=spawnSync(tool,['-c'],{input:data,encoding:null}); if(r.status!==0) throw new Error('compression failed'); fs.writeFileSync(file,r.stdout); }
  else writeZip(file,items);
  console.log(`Add new data to archive: ${items.length} file${items.length===1?'':'s'}\n`); console.log('\nFiles read from disk: '+items.length); console.log('Archive size: '+fs.statSync(file).size+' bytes (1 KiB)'); console.log('Everything is Ok');
}
function delFromZip(file,names){ const es=readZip(file).filter(e=>!names.includes(e.name)&&!names.includes(path.basename(e.name))); const tmp=fs.mkdtempSync('/tmp/p7z-'); const items=[]; for(const e of es){ const p=path.join(tmp,e.name); fs.mkdirSync(path.dirname(p),{recursive:true}); fs.writeFileSync(p,e.data); items.push({fsPath:p,name:e.name,stat:fs.statSync(p)}); } writeZip(file,items); fs.rmSync(tmp,{recursive:true,force:true}); banner(); console.log('Everything is Ok'); }

function main(){
  const {opts,args}=parse(process.argv.slice(2)); quiet = opts.stdout;
  if(args.length===0 || args[0]==='--help' || args[0]==='-h' || args[0]==='-?' || args[0]==='/?') { process.stdout.write(HELP); return; }
  const cmd=args[0].toLowerCase();
  if(cmd==='i'){ banner(); console.log('Formats:\n   C...F..........c.a.m+..  7z       7z\n   C......O...LH......m+..  tar      tar\n   C...FMG........c.a.m+..  zip      zip\n   CK.................m+..  gzip     gz gzip tgz (.tar)\n   CK.....................  bzip2    bz2 bzip2\n   CK.....................  xz       xz txz (.tar)\n\nCodecs:\n    ED         0 Copy\n    ED     40108 Deflate\n\nHashers:\n      4        1 CRC32\n     20      201 SHA1\n     32        A SHA256'); return; }
  if(cmd==='b'){ banner(); console.log('RAM size:    128808 MB,  # CPU hardware threads:  32'); console.log('Benchmark stub\nEverything is Ok'); return; }
  if(cmd==='h'){ let algo='crc32'; for(const s of opts.switches){ const m=s.match(/^-scrc(.+)/i); if(m) algo=m[1].toLowerCase().replace('sha256','sha256').replace('sha1','sha1'); } if(!['crc32','sha1','sha256','md5'].includes(algo)) algo='crc32'; hashFiles(args.slice(1),algo); return; }
  const archive=args[1]; if(!archive) { process.stderr.write('Command Line Error:\nCannot find archive name\n'); process.exit(7); }
  const type=inferType(archive,opts.type);
  if(cmd==='a'||cmd==='u') return createArchive(archive,type,args.slice(2));
  if(cmd==='l') return listArchive(archive,type,opts.switches.some(s=>s.toLowerCase()==='-slt'),args.slice(2));
  if(cmd==='x'||cmd==='e') return extract(archive,type,opts,cmd==='x',args.slice(2));
  if(cmd==='t'){ const es=filterEntries(readArchive(archive,type), args.slice(2)); banner(); console.log('Testing archive: '+archive+'\n'); console.log('Everything is Ok\n'); console.log('Files: '+es.length); return; }
  if(cmd==='d') return delFromZip(archive,args.slice(2));
  console.error('Command Line Error:\nUnsupported command: '+cmd); process.exit(7);
}
try { main(); } catch(e){ if(!quiet) banner(); console.error('\nERROR: '+(e.message||e)); process.exit(2); }
