#!/usr/bin/env node

const fs = require("fs");
const os = require("os");
const path = require("path");

const args = process.argv.slice(2);

const COMMANDS = new Set(["history", "stats", "export", "cache", "repo", "trending", "help"]);
const VALID_LANGS = new Set([
  "rust", "rs", "typescript", "ts", "javascript", "js", "python", "py",
  "ruby", "rb", "go", "swift", "kotlin", "kt", "java", "php",
  "csharp", "cs", "c#", "c", "cpp", "c++", "haskell", "hs", "dart",
  "scala", "sc", "zig", "clojure", "clj", "cljs",
]);
const TRENDING_LANGS = new Set([
  "c", "c#", "c++", "dart", "go", "haskell", "java", "javascript",
  "kotlin", "php", "python", "ruby", "rust", "scala", "swift",
  "typescript", "zig",
]);

function out(s = "") { process.stdout.write(s + "\n"); }
function err(s = "") { process.stderr.write(s + "\n"); }
function exit(code) { process.exitCode = code; }

const longTopHelp = `GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. 

Examples:
  gittype                           # Use current directory
  gittype /path/to/repo             # Use specific repository
  gittype --repo owner/repo         # Clone and use GitHub repository
  gittype --langs rust,python       # Filter by languages

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]
          Repository path to extract code from

Options:
      --repo <REPO>
          GitHub repository URL or path to clone and play with. Supports formats:
            - owner/repo
            - https://github.com/owner/repo
            - git@github.com:owner/repo.git

      --langs <LANGS>
          Filter by programming languages (comma-separated). Supported languages:
            rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig
            Example: --langs rust,python,typescript

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const shortTopHelp = `A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]  Repository path to extract code from

Options:
      --repo <REPO>    GitHub repository URL or path to clone and play with
      --langs <LANGS>  Filter by programming languages (comma-separated)
  -h, --help           Print help (see more with '--help')
  -V, --version        Print version`;

const helpText = {
  history: `Show session history

Usage: executable history

Options:
  -h, --help  Print help`,
  stats: `Show analytics

Usage: executable stats

Options:
  -h, --help  Print help`,
  export: `Export session data

Usage: executable export [OPTIONS]

Options:
      --format <FORMAT>  Export format [default: json]
      --output <OUTPUT>  Output file path
  -h, --help             Print help`,
  cache: `Manage challenge cache

Usage: executable cache <COMMAND>

Commands:
  stats  Show cache statistics
  clear  Clear all cached challenges
  list   List cached repository keys
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help`,
  "cache stats": `Show cache statistics

Usage: executable cache stats

Options:
  -h, --help  Print help`,
  "cache clear": `Clear all cached challenges

Usage: executable cache clear

Options:
  -h, --help  Print help`,
  "cache list": `List cached repository keys

Usage: executable cache list

Options:
  -h, --help  Print help`,
  repo: `Manage repositories

Usage: executable repo <COMMAND>

Commands:
  list   List all cached repositories
  clear  Clear all cached repositories
  play   Play a cached repository interactively
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help`,
  "repo list": `List all cached repositories

Usage: executable repo list

Options:
  -h, --help  Print help`,
  "repo clear": `Clear all cached repositories

Usage: executable repo clear [OPTIONS]

Options:
      --force  Force clear without confirmation
  -h, --help   Print help`,
  "repo play": `Play a cached repository interactively

Usage: executable repo play

Options:
  -h, --help  Print help`,
};

const trendingLong = `Select and practice with trending repositories from GitHub

Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]

Arguments:
  [LANGUAGE]
          Programming language to filter trending repositories.
          Supported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig

  [REPO_NAME]
          Specific repository name to select from trending list

Options:
      --period <PERIOD>
          Time period for trending (daily, weekly, monthly)
          
          [default: daily]

  -h, --help
          Print help (see a summary with '-h')`;

const trendingShort = `Select and practice with trending repositories from GitHub

Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]

Arguments:
  [LANGUAGE]   Programming language to filter trending repositories
  [REPO_NAME]  Specific repository name to select from trending list

Options:
      --period <PERIOD>  Time period for trending (daily, weekly, monthly) [default: daily]
  -h, --help             Print help (see more with '--help')`;

function usageError(message, usage) {
  err(message);
  err("");
  if (usage) err(usage);
  err("For more information, try '--help'.");
  exit(2);
}

function unexpected(arg, usage) {
  usageError(`error: unexpected argument '${arg}' found`, usage);
}

function unrecognized(sub, usage) {
  usageError(`error: unrecognized subcommand '${sub}'`, usage);
}

function terminalError() {
  const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/T/, "_").slice(0, 15);
  const file = `gittype_error_${stamp}.log`;
  try {
    fs.writeFileSync(file, `ERROR MESSAGE: Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)\n`);
  } catch (_) {}
  out(`💾 Error details written to: ${file}`);
  out("Error: Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)");
  exit(1);
}

function unsupportedLangs(bad) {
  out(`❌ Unsupported language(s): ${bad.join(", ")}`);
  out("💡 Supported languages:");
  out("   rust, rs, typescript, ts, javascript, js");
  out("   python, py, ruby, rb, go, swift");
  out("   kotlin, kt, java, php, csharp, cs");
  out("   c#, c, cpp, c++, haskell, hs");
  out("   dart, scala, sc, zig, clojure, clj");
  out("   cljs");
  process.exit(1);
}

function validateLangList(value) {
  const bad = String(value || "").split(",").map(s => s.trim()).filter(Boolean).filter(s => !VALID_LANGS.has(s.toLowerCase()));
  if (bad.length) unsupportedLangs(bad);
}

function cacheDirCandidates() {
  const home = os.homedir();
  return [
    path.join(home, ".cache", "gittype", "challenges"),
    path.join(home, ".cache", "gittype", "cache"),
    path.join(home, ".gittype", "cache"),
    path.join(home, ".gittype", "challenges"),
  ];
}

function dirSize(p) {
  let total = 0;
  if (!fs.existsSync(p)) return 0;
  for (const ent of fs.readdirSync(p, { withFileTypes: true })) {
    const q = path.join(p, ent.name);
    try {
      if (ent.isDirectory()) total += dirSize(q);
      else total += fs.statSync(q).size;
    } catch (_) {}
  }
  return total;
}

function cacheEntries() {
  for (const d of cacheDirCandidates()) {
    try {
      if (fs.existsSync(d) && fs.statSync(d).isDirectory()) {
        return fs.readdirSync(d).filter(n => !n.startsWith(".")).map(n => ({ name: n, dir: path.join(d, n) }));
      }
    } catch (_) {}
  }
  return [];
}

function handleCache(rest) {
  if (rest.length === 0) {
    out(helpText.cache);
    exit(2);
    return;
  }
  if (rest[0] === "help") {
    if (rest[1] && helpText[`cache ${rest[1]}`]) out(helpText[`cache ${rest[1]}`]);
    else out(helpText.cache);
    return;
  }
  if (!["stats", "clear", "list"].includes(rest[0])) return unrecognized(rest[0], "Usage: executable cache <COMMAND>\n");
  const sub = rest[0];
  const tail = rest.slice(1);
  if (tail.includes("-h") || tail.includes("--help")) return out(helpText[`cache ${sub}`]);
  if (tail.length) return unexpected(tail[0], `Usage: executable cache ${sub}\n`);
  const entries = cacheEntries();
  if (sub === "stats") {
    let total = 0;
    for (const e of entries) total += dirSize(e.dir);
    out("Challenge Cache Statistics:");
    out(`  Cached repositories: ${entries.length}`);
    out(`  Total size: ${total} bytes`);
  } else if (sub === "list") {
    if (entries.length === 0) out("No cached challenges found.");
    else entries.forEach(e => out(e.name));
  } else {
    for (const d of cacheDirCandidates()) {
      try { if (fs.existsSync(d)) fs.rmSync(d, { recursive: true, force: true }); } catch (_) {}
    }
    out("Challenge cache cleared successfully.");
  }
}

function handleRepo(rest) {
  if (rest.length === 0) {
    out(helpText.repo);
    exit(2);
    return;
  }
  if (rest[0] === "help") {
    if (rest[1] && helpText[`repo ${rest[1]}`]) out(helpText[`repo ${rest[1]}`]);
    else out(helpText.repo);
    return;
  }
  if (!["list", "clear", "play"].includes(rest[0])) return unrecognized(rest[0], "Usage: executable repo <COMMAND>\n");
  const sub = rest[0];
  const tail = rest.slice(1);
  if (tail.includes("-h") || tail.includes("--help")) return out(helpText[`repo ${sub}`]);
  if (sub === "clear") {
    const extra = tail.filter(a => a !== "--force");
    if (extra.length) return unexpected(extra[0], "Usage: executable repo clear [OPTIONS]\n");
    const repoDir = path.join(os.homedir(), ".gittype", "repositories");
    if (!fs.existsSync(repoDir)) out("No cached repositories directory found.");
    else {
      fs.rmSync(repoDir, { recursive: true, force: true });
      out("Cached repositories cleared successfully.");
    }
    return;
  }
  if (tail.length) return unexpected(tail[0], `Usage: executable repo ${sub}\n`);
  terminalError();
}

function handleExport(rest) {
  let format = "json";
  let output = null;
  for (let i = 0; i < rest.length; i++) {
    const a = rest[i];
    if (a === "-h" || a === "--help") return out(helpText.export);
    if (a === "--format") {
      if (i + 1 >= rest.length) return usageError("error: a value is required for '--format <FORMAT>' but none was supplied", null);
      format = rest[++i];
    } else if (a === "--output") {
      if (i + 1 >= rest.length) return usageError("error: a value is required for '--output <OUTPUT>' but none was supplied", null);
      output = rest[++i];
    } else {
      return unexpected(a, "Usage: executable export [OPTIONS]\n");
    }
  }
  out("❌ Export command is not yet implemented");
  out(`💡 Requested format: ${format}`);
  if (output) out(`💡 Requested output: ${output}`);
  out("💡 This feature is planned for a future release");
  exit(1);
}

function handleTrending(rest) {
  if (rest.includes("--help")) return out(trendingLong);
  if (rest.includes("-h")) return out(trendingShort);
  let pos = [];
  for (let i = 0; i < rest.length; i++) {
    const a = rest[i];
    if (a === "--period") {
      if (i + 1 >= rest.length) return usageError("error: a value is required for '--period <PERIOD>' but none was supplied", null);
      i++;
    } else if (a.startsWith("-")) {
      return unexpected(a, "Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]\n");
    } else {
      pos.push(a);
    }
  }
  if (pos[0] && !TRENDING_LANGS.has(pos[0].toLowerCase())) {
    out(`❌ Unsupported language: '${pos[0]}'`);
    out("📚 Supported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript");
    const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/T/, "_").slice(0, 15);
    const file = `gittype_error_${stamp}.log`;
    try { fs.writeFileSync(file, `ERROR MESSAGE: Validation error: Unsupported language: ${pos[0]}\n`); } catch (_) {}
    out(`💾 Error details written to: ${file}`);
    out(`Error: Validation error: Unsupported language: ${pos[0]}`);
    exit(1);
    return;
  }
  if (pos[1] && !/^[^/\s]+\/[^/\s]+$/.test(pos[1])) {
    out("⚠️ Repository name must be in format 'owner/repo'");
    return;
  }
  terminalError();
}

function handleSimple(name, rest) {
  if (rest.includes("-h") || rest.includes("--help")) return out(helpText[name]);
  if (rest.length) return unexpected(rest[0], `Usage: executable ${name}\n`);
  out(`❌ ${name[0].toUpperCase()}${name.slice(1)} command is not yet implemented`);
  out("💡 This feature is planned for a future release");
  exit(1);
}

function main(argv) {
  if (argv.length === 0) return terminalError();
  if (argv[0] === "--help") return out(longTopHelp);
  if (argv[0] === "-h") return out(shortTopHelp);
  if (argv[0] === "--version" || argv[0] === "-V") return out("gittype 0.8.0");
  if (argv[0] === "help") {
    if (argv.length === 1) return out(longTopHelp);
    const sub = argv[1];
    if (sub === "trending") return out(trendingLong);
    if (sub === "cache") return handleCache(["help", ...argv.slice(2)]);
    if (sub === "repo") return handleRepo(["help", ...argv.slice(2)]);
    if (helpText[sub]) return out(helpText[sub]);
    return unrecognized(sub, "Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]\n");
  }
  if (argv[0].startsWith("-") && !["--repo", "--langs"].includes(argv[0])) {
    err(`error: unexpected argument '${argv[0]}' found`);
    err("");
    err(`  tip: to pass '${argv[0]}' as a value, use '-- ${argv[0]}'`);
    err("");
    err("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]");
    err("");
    err("For more information, try '--help'.");
    exit(2);
    return;
  }

  let i = 0;
  while (i < argv.length && argv[i].startsWith("-")) {
    const a = argv[i];
    if (a === "--repo") {
      if (i + 1 >= argv.length) return usageError("error: a value is required for '--repo <REPO>' but none was supplied", null);
      i += 2;
    } else if (a === "--langs") {
      if (i + 1 >= argv.length) return usageError("error: a value is required for '--langs <LANGS>' but none was supplied", null);
      validateLangList(argv[i + 1]);
      i += 2;
    } else {
      return unexpected(a, "Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]\n");
    }
  }

  const head = argv[i];
  const rest = argv.slice(i + 1);
  if (!head || !COMMANDS.has(head)) return terminalError();
  if (head === "history" || head === "stats") return handleSimple(head, rest);
  if (head === "export") return handleExport(rest);
  if (head === "cache") return handleCache(rest);
  if (head === "repo") return handleRepo(rest);
  if (head === "trending") return handleTrending(rest);
}

main(args);
