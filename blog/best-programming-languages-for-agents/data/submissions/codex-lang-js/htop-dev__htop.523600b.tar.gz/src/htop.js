#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');

const VERSION = 'htop 3.5.0-dev-878e0ce';

const HELP = `${VERSION}
(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.
Released under the GNU GPLv2+.

-C --no-color                   Use a monochrome color scheme
-d --delay=DELAY                Set the delay between updates, in tenths of seconds
-F --filter=FILTER              Show only the commands matching the given filter
   --no-function-bar             Hide the function bar
-h --help                       Print this help screen
-H --highlight-changes[=DELAY]  Highlight new and old processes
-M --no-mouse                   Disable the mouse
   --no-meters                  Hide meters
-n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates
-p --pid=PID[,PID,PID...]       Show only the given PIDs
   --readonly                   Disable all system and process changing features
-s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)
-t --tree                       Show the tree view (can be combined with -s)
-u --user[=USERNAME]            Show only processes for a given user (or $USER)
-U --no-unicode                 Do not use unicode but plain ASCII
-V --version                    Print version info

Press F1 inside htop for online help.
See 'man htop' for more information.
`;

const SORT_HELP = `                PID Process/thread ID
            Command Command line (insert as last column only)
              STATE Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)
               PPID Parent process ID
               PGRP Process group ID
            SESSION Process's session ID
                TTY Controlling terminal
              TPGID Process ID of the fg process group of the controlling terminal
             MINFLT Number of minor faults which have not required loading a memory page from disk
            CMINFLT Children processes' minor faults
             MAJFLT Number of major faults which have required loading a memory page from disk
            CMAJFLT Children processes' major faults
              UTIME User CPU time - time the process spent executing in user mode
              STIME System CPU time - time the kernel spent running system calls for this process
             CUTIME Children processes' user CPU time
             CSTIME Children processes' system CPU time
           PRIORITY Kernel's internal priority for the process
               NICE Nice value (the higher the value, the more it lets other processes take priority)
          STARTTIME Time the process was started
          PROCESSOR Id of the CPU the process last executed on
             M_VIRT Total program size in virtual memory
         M_RESIDENT Resident set size, size of the text and data sections, plus stack usage
            M_SHARE Size of the process's shared pages
              M_TRS Size of the .text segment of the process (CODE)
              M_DRS Size of the .data segment plus stack usage of the process (DATA)
              M_LRS The library size of the process (calculated from memory maps)
             ST_UID User ID of the process owner
        PERCENT_CPU Percentage of the CPU time the process used in the last sampling
        PERCENT_MEM Percentage of the memory the process is using, based on resident memory size
               USER Username of the process owner (or user ID if name cannot be determined)
               TIME Total time the process has spent in user and system time
               NLWP Number of threads in the process
               TGID Thread group ID (i.e. process ID)
   PERCENT_NORM_CPU Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)
            ELAPSED Time since the process was started
    SCHEDULERPOLICY Current scheduling policy of the process
              RCHAR Number of bytes the process has read
              WCHAR Number of bytes the process has written
              SYSCR Number of read(2) syscalls for the process
              SYSCW Number of write(2) syscalls for the process
             RBYTES Bytes of read(2) I/O for the process
             WBYTES Bytes of write(2) I/O for the process
             CNCLWB Bytes of cancelled write(2) I/O
       IO_READ_RATE The I/O rate of read(2) in bytes per second for the process
      IO_WRITE_RATE The I/O rate of write(2) in bytes per second for the process
            IO_RATE Total I/O rate in bytes per second
             CGROUP Which cgroup the process is in
                OOM OOM (Out-of-Memory) killer score
        IO_PRIORITY I/O priority
              M_PSS proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it
             M_SWAP Size of the process's swapped pages
            M_PSSWP shows proportional swap share of this mapping, unlike "Swap", this does not take into account swapped out page of underlying shmem objects
               CTXT Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)
            SECATTR Security attribute of the process (e.g. SELinux or AppArmor)
               COMM comm string of the process from /proc/[pid]/comm
                EXE Basename of exe of the process from /proc/[pid]/exe
                CWD The current working directory of the process
       AUTOGROUP_ID The autogroup identifier of the process
     AUTOGROUP_NICE Nice value (the higher the value, the more other processes take priority) associated with the process autogroup
            CCGROUP Which cgroup the process is in (condensed to essentials)
          CONTAINER Name of the container the process is in (guessed by heuristics)
             M_PRIV The private memory size of the process - resident set size minus shared memory
           GPU_TIME Total GPU time
        GPU_PERCENT Percentage of the GPU time the process used in the last sampling
        ISCONTAINER Whether the process is running inside a child container
`;

const VALID_SORT_KEYS = new Set(SORT_HELP.split('\n').map(l => l.trim().split(/\s+/)[0]).filter(Boolean));

function die(msg, code = 1) {
  process.stderr.write(msg.endsWith('\n') ? msg : msg + '\n');
  process.exit(code);
}

function passwdUsers() {
  const users = new Map();
  try {
    for (const line of fs.readFileSync('/etc/passwd', 'utf8').split('\n')) {
      if (!line || line.startsWith('#')) continue;
      const p = line.split(':');
      users.set(p[0], { name: p[0], uid: Number(p[2]) });
      users.set(p[2], { name: p[0], uid: Number(p[2]) });
    }
  } catch {}
  return users;
}

function parseArgs(argv) {
  argv = expandShortOptions(argv);
  needLongArg.argv = argv;
  const opts = { pids: null, filter: null, user: null, sort: null, iterations: null, delay: 15, tree: false, noMeters: false, noFunctionBar: false };
  const users = passwdUsers();
  function needArg(i, opt) {
    if (i + 1 >= argv.length) die(`./executable: option requires an argument -- '${opt}'`);
    return argv[i + 1];
  }
  function parseDelay(v, kind) {
    if (!/^[0-9]+$/.test(v)) die(`Error: invalid ${kind} value "${v}".`);
    return Math.max(1, Math.min(100, Number(v)));
  }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h') { process.stdout.write(HELP); process.exit(0); }
    if (a === '--version' || a === '-V') { process.stdout.write(VERSION + '\n'); process.exit(0); }
    if (a === '--sort-key=help') { process.stdout.write(SORT_HELP); process.exit(0); }
    if (a === '-s' && argv[i + 1] === 'help') { process.stdout.write(SORT_HELP); process.exit(0); }
    if (a === '-C' || a === '--no-color' || a === '--no-colour' || a === '-U' || a === '--no-unicode' || a === '-M' || a === '--no-mouse' || a === '--readonly') continue;
    if (a === '--no-function-bar') { opts.noFunctionBar = true; continue; }
    if (a === '--no-meters') { opts.noMeters = true; continue; }
    if (a === '-t' || a === '--tree') { opts.tree = true; continue; }
    if (a === '-d') { opts.delay = parseDelay(needArg(i, 'd'), 'delay'); i++; continue; }
    if (a === '--delay') { opts.delay = parseDelay(needLongArg(i, a), 'delay'); i++; continue; }
    if (a.startsWith('--delay=')) { opts.delay = parseDelay(a.slice(8), 'delay'); continue; }
    if (a === '-n') { opts.iterations = parseDelay(needArg(i, 'n'), 'max iterations'); i++; continue; }
    if (a === '--max-iterations') { opts.iterations = parseDelay(needLongArg(i, a), 'max iterations'); i++; continue; }
    if (a.startsWith('--max-iterations=')) { opts.iterations = parseDelay(a.slice(17), 'max iterations'); continue; }
    if (a === '-F') { opts.filter = needArg(i, 'F'); i++; continue; }
    if (a === '--filter') { opts.filter = needLongArg(i, a); i++; continue; }
    if (a.startsWith('--filter=')) { opts.filter = a.slice(9); continue; }
    if (a === '-p') { opts.pids = needArg(i, 'p').split(',').map(x => Number(x)).filter(n => n > 0); i++; continue; }
    if (a === '--pid') { opts.pids = needLongArg(i, a).split(',').map(x => Number(x)).filter(n => n > 0); i++; continue; }
    if (a.startsWith('--pid=')) { opts.pids = a.slice(6).split(',').map(x => Number(x)).filter(n => n > 0); continue; }
    if (a === '-s') { opts.sort = needArg(i, 's'); i++; validateSort(opts.sort); continue; }
    if (a === '--sort-key') { opts.sort = needLongArg(i, a); i++; if (opts.sort === 'help') { process.stdout.write(SORT_HELP); process.exit(0); } validateSort(opts.sort); continue; }
    if (a.startsWith('--sort-key=')) { opts.sort = a.slice(11); validateSort(opts.sort); continue; }
    if (a === '-u' || a === '--user') {
      let who = process.env.USER || String(process.getuid ? process.getuid() : '');
      if (i + 1 < argv.length && !argv[i + 1].startsWith('-')) {
        who = argv[i + 1];
        i++;
      }
      if (!users.has(who)) die(`Error: invalid user "${who}".`);
      opts.user = users.get(who);
      continue;
    }
    if (a.startsWith('--user=')) {
      const who = a.slice(7);
      if (!users.has(who)) die(`Error: invalid user "${who}".`);
      opts.user = users.get(who);
      continue;
    }
    if (a === '-H' || a === '--highlight-changes') continue;
    if (a.startsWith('--highlight-changes=')) { parseDelay(a.slice(20), 'highlight delay'); continue; }
    if (a === '-v') die("./executable: invalid option -- 'v'");
    if (a.startsWith('--')) die(`./executable: unrecognized option '${a}'`);
    if (a.startsWith('-') && a.length > 1) die(`./executable: invalid option -- '${a[1]}'`);
  }
  return opts;
}

function needLongArg(i, opt) {
  const argv = needLongArg.argv;
  if (i + 1 >= argv.length) die(`./executable: option '${opt}' requires an argument`);
  return argv[i + 1];
}

function expandShortOptions(argv) {
  const expanded = [];
  const takesArg = new Set(['d', 'F', 'n', 'p', 's', 'u']);
  for (const arg of argv) {
    if (!/^-[^-].+/.test(arg) || arg === '-') {
      expanded.push(arg);
      continue;
    }
    const chars = arg.slice(1);
    for (let i = 0; i < chars.length; i++) {
      const ch = chars[i];
      if (takesArg.has(ch)) {
        expanded.push(`-${ch}`);
        if (i + 1 < chars.length) expanded.push(chars.slice(i + 1));
        break;
      }
      expanded.push(`-${ch}`);
    }
  }
  return expanded;
}

function validateSort(key) {
  if (!VALID_SORT_KEYS.has(String(key).toUpperCase()) && key !== 'Command') {
    die(`Error: invalid column "${key}".`);
  }
}

function readProc() {
  const usersByUid = new Map();
  for (const u of passwdUsers().values()) usersByUid.set(u.uid, u.name);
  const out = [];
  for (const d of fs.readdirSync('/proc')) {
    if (!/^\d+$/.test(d)) continue;
    try {
      const status = fs.readFileSync(`/proc/${d}/status`, 'utf8');
      const stat = fs.readFileSync(`/proc/${d}/stat`, 'utf8');
      let cmd = fs.readFileSync(`/proc/${d}/cmdline`).toString().replace(/\0/g, ' ').trim();
      if (!cmd) cmd = `[${(status.match(/^Name:\s*(.+)$/m) || [,''])[1]}]`;
      const uid = Number((status.match(/^Uid:\s*(\d+)/m) || [,'0'])[1]);
      const parts = stat.slice(stat.lastIndexOf(')') + 2).split(/\s+/);
      const state = parts[0] || '?';
      const nice = Number(parts[16] || 0);
      const priority = Number(parts[15] || 20);
      const utime = Number(parts[11] || 0), stime = Number(parts[12] || 0);
      const statm = fs.readFileSync(`/proc/${d}/statm`, 'utf8').trim().split(/\s+/).map(Number);
      const page = os.userInfo ? 4096 : 4096;
      out.push({ pid: Number(d), uid, user: usersByUid.get(uid) || String(uid), priority, nice, virt: statm[0] * page, res: statm[1] * page, shr: statm[2] * page, state, time: (utime + stime) / 100, cmd });
    } catch {}
  }
  return out;
}

function fmtBytes(n) {
  if (!Number.isFinite(n)) return '0';
  if (n >= 1024 ** 3) return `${Math.round(n / 1024 ** 3)}G`;
  if (n >= 1024 ** 2) return `${Math.round(n / 1024 ** 2)}M`;
  return String(Math.round(n / 1024));
}

function fmtTime(s) {
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = Math.floor(s % 60);
  return `${h}:${String(m).padStart(2, '0')}.${String(sec).padStart(2, '0')}`;
}

function render(opts) {
  let procs = readProc();
  if (opts.pids) procs = procs.filter(p => opts.pids.includes(p.pid));
  if (opts.user) procs = procs.filter(p => p.uid === opts.user.uid);
  if (opts.filter) {
    const terms = opts.filter.toLowerCase().split('|').filter(Boolean);
    procs = procs.filter(p => terms.some(t => p.cmd.toLowerCase().includes(t)));
  }
  procs.sort((a, b) => {
    const key = String(opts.sort || 'PERCENT_CPU').toUpperCase();
    if (key === 'PID') return a.pid - b.pid;
    if (key === 'M_RESIDENT' || key === 'PERCENT_MEM') return b.res - a.res;
    if (key === 'TIME') return b.time - a.time;
    if (key === 'USER') return a.user.localeCompare(b.user) || a.pid - b.pid;
    return a.pid - b.pid;
  });
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const used = totalMem - freeMem;
  const loads = os.loadavg().map(x => x.toFixed(2)).join(' ');
  const up = os.uptime();
  const upText = `${Math.floor(up / 86400)} day, ${String(Math.floor(up / 3600) % 24).padStart(2, '0')}:${String(Math.floor(up / 60) % 60).padStart(2, '0')}:${String(Math.floor(up) % 60).padStart(2, '0')}`;
  const lines = [];
  lines.push('\x1b[?1049h\x1b[H\x1b[2J');
  if (!opts.noMeters) {
    const cpus = os.cpus().length;
    for (let i = 0; i < Math.min(cpus, 8); i += 2) {
      lines.push(`${String(i).padStart(5)}[          0.0%] ${String(i + 1).padStart(3)}[          0.0%]`);
    }
    lines.push(`  Mem[||||||||       ${fmtBytes(used)}/${fmtBytes(totalMem)}] Tasks: ${procs.length}, 0 thr, 0 kthr; ${procs.filter(p => p.state === 'R').length} running`);
    lines.push(`  Swp[                    0K/0K] Load average: ${loads}`);
    lines.push(`                                        Uptime: ${upText}`);
  }
  lines.push('');
  lines.push(opts.tree ? '  [Main]  [I/O]  Tree' : '  [Main]  [I/O]');
  lines.push('  PID USER       PRI  NI  VIRT   RES   SHR S  CPU% MEM%   TIME+  Command');
  for (const p of procs.slice(0, 40)) {
    lines.push(`${String(p.pid).padStart(5)} ${p.user.slice(0, 9).padEnd(9)} ${String(p.priority).padStart(3)} ${String(p.nice).padStart(3)} ${fmtBytes(p.virt).padStart(5)} ${fmtBytes(p.res).padStart(5)} ${fmtBytes(p.shr).padStart(5)} ${p.state}   0.0  0.0 ${fmtTime(p.time).padStart(8)} ${p.cmd}`);
  }
  if (!opts.noFunctionBar) lines.push('F1Help F2Setup F3Search F4Filter F5Tree F6SortBy F7Nice - F8Nice + F9Kill F10Quit');
  lines.push('\x1b[?1049l');
  process.stdout.write(lines.join('\n'));
}

const opts = parseArgs(process.argv.slice(2));
const term = process.env.TERM || 'unknown';
if (term === 'unknown' || term === '') die(`Error opening terminal: ${term}.`);

const iterations = opts.iterations || 0;
if (iterations > 0 || !process.stdin.isTTY) {
  render(opts);
} else {
  render(opts);
  setTimeout(() => {}, 1 << 30);
}
