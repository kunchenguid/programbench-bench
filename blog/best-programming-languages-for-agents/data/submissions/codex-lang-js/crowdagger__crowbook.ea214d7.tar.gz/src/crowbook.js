#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "crowbook 0.17.0";
const BANNER = "CROWBOOK 0.17.0";

const HELP = `crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>
Render a Markdown book in EPUB, PDF or HTML.
  
USAGE:
    executable [OPTIONS] [BOOK]

OPTIONS:
  -f, --force-emoji
          Force emoji usage even if it might not work on your system
  -s, --single
          Use a single Markdown file instead of a book configuration file
  -n, --no-fancy
          Disably fancy UI
  -v, --verbose
          Print warnings in parsing/rendering
  -a, --autograph
          Prompts for an autograph for this book
  -q, --quiet
          Don't print info/error messages
  -c, --create <files>...
          Create a new book with existing Markdown files
  -o, --output <output>
          Specify output file
  -t, --to <to>
          Generate specific format
      --set <set> <set>...
          Set a list of book options
  -l, --list-options
          List all possible options
  -L, --lang <lang>
          Set the runtime language used by Crowbook
      --print-template <print-template>
          Prints the default content of a template
  -S, --stats
          Print some project statistics
  -h, --help
          Print help
  -V, --version
          Print version

ARGS:
  [BOOK]  File containing the book configuration file, or a Markdown file when called with --single`;

const LIST_OPTIONS = `${BANNER}
METADATA
author
  type: metadata (default: "")
  Author of the book
title
  type: metadata (default: "")
  Title of the book
lang
  type: metadata (default: en)
  Language of the book
subject
  type: metadata (default: not set)
  Subject of the book (used for EPUB metadata)
description
  type: metadata (default: not set)
  Description of the book (used for EPUB metadata)
cover
  type: path (default: not set)
  Path to the cover of the book

ADDITIONAL METADATA
subtitle
  type: metadata (default: not set)
  Subtitle of the book
license
  type: metadata (default: not set)
  License of the book
version
  type: metadata (default: not set)
  Version of the book
date
  type: metadata (default: not set)
  Date the book was revised
autograph
  type: metadata (default: not set)
  An autograph

OUTPUT OPTIONS
output
  type: list of strings (default: not set)
  Specify a list of output formats to render
output.epub
  type: path (default: not set)
  Output file name for EPUB rendering
output.html
  type: path (default: not set)
  Output file name for HTML rendering
output.html.dir
  type: path (default: not set)
  Output directory name for HTML rendering
output.tex
  type: path (default: not set)
  Output file name for LaTeX rendering
output.pdf
  type: path (default: not set)
  Output file name for PDF rendering
output.base_path
  type: path (default: "")
  Directory where those output files will we written

RENDERING OPTIONS
rendering.highlight
  type: string (default: syntect)
  If/how highligh code blocks. Possible values: "syntect" (default, performed at
  runtime), "highlight.js" (HTML-only, uses Javascript), "none"
rendering.highlight.theme
  type: string (default: InspiredGitHub)
  Theme for syntax highlighting (if rendering.highlight is set to 'syntect')
rendering.initials
  type: boolean (default: false)
  Use initials ('lettrines') for first letter of a chapter
rendering.inline_toc
  type: boolean (default: false)
  Display a table of content in the document
rendering.inline_toc.name
  type: string (default: "{{loc_toc}}")
  Name of the table of contents if it is displayed in document
rendering.num_depth
  type: integer (default: 1)
  The  maximum heading levels that should be numbered (0: no numbering, 1: only
  chapters, ..., 6: all)
rendering.chapter
  type: string (default: not set)
  How to call chapters
rendering.part
  type: string (default: not set)
  How to call parts (or 'books', 'episodes', ...)
rendering.chapter.roman_numerals
  type: boolean (default: false)
  If set to true, display chapter number with roman numerals
rendering.part.roman_numerals
  type: boolean (default: true)
  If set to true, display part number with roman numerals
rendering.part.reset_counter
  type: boolean (default: true)
  If set to true, reset chapter number at each part
rendering.chapter.template
  type: string (default: "{{number}}. {{chapter_title}}")
  Naming scheme of chapters, for TOC
rendering.part.template
  type: string (default: "{{number}}. {{part_title}}")
  Naming scheme of parts, for TOC

SPECIAL OPTIONS
import
  type: path (default: not set)
  Import another book configuration file

HTML OPTIONS
html.icon
  type: path (default: not set)
  Path to an icon to be used for the HTML files(s)
html.highlight.theme
  type: string (default: not set)
  If set, set theme for syntax highlighting for HTML output (syntect only)
html.header
  type: string (default: not set)
  Custom header to display at the beginning of html file(s)
html.footer
  type: string (default: not set)
  Custom footer to display at the end of HTML file(s)
html.css
  type: template path (default: not set)
  Path of a stylesheet for HTML rendering
html.css.add
  type: string (default: not set)
  Some inline CSS added to the stylesheet template
html.css.colors
  type: template path (default: not set)
  Path of a stylesheet for the colors for HTML
html.js
  type: template path (default: not set)
  Path of a javascript file
html.css.print
  type: template path (default: not set)
  Path of a media print stylesheet for HTML rendering
html.highlight.js
  type: template path (default: not set)
  Set another highlight.js version than the bundled one
html.highlight.css
  type: template path (default: not set)
  Set another highlight.js CSS theme than the default one
html.side_notes
  type: boolean (default: false)
  Display footnotes as side notes in HTML/Epub (experimental)
html.escape_nb_spaces
  type: boolean (default: true)
  Replace unicode non breaking spaces with HTML entities and CSS
html.chapter.template
  type: string (default: "<h1 id = 'link-{{link}}'>{% if has_number %}<span class = 'chapter-header'>{{header}} {{number}}</span>{% if has_title %}<br />{% endif %}{% endif %}{{title}}</h1>")
  Inline template for HTML chapter formatting
html.part.template
  type: string (default: "<h2 class = 'part'>{{header}} {{number}}</h2> <h1 id = 'link-{{link}}' class = 'part'>{{title}}</h1>")
  Inline template for HTML part formatting

STANDALONE HTML OPTIONS
html.standalone.template
  type: template path (default: not set)
  Path of an HTML template for standalone HTML
html.standalone.one_chapter
  type: boolean (default: false)
  Display only one chapter at a time (with a button to display all)
html.standalone.js
  type: template path (default: not set)
  Path of a javascript file

MULTIFILE HTML OPTIONS
html.dir.template
  type: template path (default: not set)
  Path of a HTML template for multifile HTML

EPUB OPTIONS
epub.version
  type: integer (default: 2)
  EPUB version to generate (2 or 3)
epub.highlight.theme
  type: string (default: not set)
  If set, set theme for syntax highlighting for EPUB output (syntect only)
epub.css
  type: template path (default: not set)
  Path of a stylesheet for EPUB
epub.css.add
  type: string (default: not set)
  Inline CSS added to the EPUB stylesheet template
epub.chapter.xhtml
  type: template path (default: not set)
  Path of an xhtml template for each chapter
epub.titlepage.xhtml
  type: template path (default: not set)
  Path of an xhtml template for the title page
epub.toc.extras
  type: boolean (default: true)
  Add 'Title' and (if set) 'Cover' in the EPUB table of contents
epub.escape_nb_spaces
  type: boolean (default: true)
  Replace unicode non breaking spaces with HTML entities and CSS

LATEX OPTIONS
tex.cover
  type: boolean (default: false)
  Add cover to the LaTeX/PDF file
tex.highlight.theme
  type: string (default: not set)
  If set, set theme for syntax highlighting for LaTeX/PDF output (syntect only)
tex.links_as_footnotes
  type: boolean (default: true)
  Add foontotes to URL of links so they are readable when printed
tex.pageref_template
  type: string (default: "\\\\footnote{p\\\\pageref{<<key>>}}")
  Template (you can only use the '<<key>>' parameter) for the footnote (or
  something else) showing the page for the link
tex.command
  type: string (default: xelatex)
  LaTeX command to use for generating PDF
tex.escape_nb_spaces
  type: boolean (default: true)
  Replace unicode non breaking spaces with TeX code
tex.template
  type: template path (default: not set)
  Path of a LaTeX template file
tex.template.add
  type: string (default: not set)
  Inline code added in the LaTeX template
tex.class
  type: string (default: book)
  LaTeX class to use
tex.paper.size
  type: string (default: a5paper)
  Specifies the size of the page
tex.margin.left
  type: string (default: not set)
  Specifies left margin (note that with book class left and right margins are
  reversed for odd pages, thus the default value is 1.5cm for book class and
  2cm else)
tex.margin.right
  type: string (default: not set)
  Specifies right margin(note that with book class left and right margins are
  reversed for odd pages, thus the default value is 2.5cm for book class and
  2cm else)
tex.margin.top
  type: string (default: "2cm")
  Specifies top margin
tex.margin.bottom
  type: string (default: "1.5cm")
  Specifies bottom margin
tex.title
  type: boolean (default: true)
  If true, generate a title with \\\\maketitle
tex.font.size
  type: integer (default: not set)
  Specify latex font size (in pt, 10 (default), 11, or 12 are accepted)
tex.hyperref
  type: boolean (default: true)
  If disabled, don't try to find references inside the document
tex.stdpage
  type: boolean (default: false)
  If set to true, use 'stdpage' package to format a manuscript according to
  standards

RESOURCES OPTIONS
resources.files
  type: list of strings (default: not set)
  Whitespace-separated list of files to embed in e.g. EPUB file; useful for
  including e.g. fonts
resources.out_path
  type: path (default: data)
  Paths where additional resources should be copied in the EPUB file or HTML
  directory
resources.base_path
  type: path (default: not set)
  Path where to find resources (in the source tree). By default, links and
  images are relative to the Markdown file. If this is set, it will be to this
  path.
resources.base_path.links
  type: path (default: not set)
  Set base path but only for links. Useless if resources.base_path is set
resources.base_path.images
  type: path (default: .)
  Set base path but only for images. Useless if resources.base_path is set
resources.base_path.files
  type: path (default: .)
  Set base path but only for additional files. Useless if resources.base_path
  is set.
resources.base_path.templates
  type: path (default: .)
  Set base path but only for templates files. Useless if resources.base_path
  is set

INPUT OPTIONS    #[SERDE(FLATTEN)]
input.clean
  type: boolean (default: true)
  Toggle typographic cleaning of input markdown according to lang
input.clean.smart_quotes
  type: boolean (default: true)
  If enabled, tries to replace vertical quotations marks to curly ones
input.clean.ligature.dashes
  type: boolean (default: false)
  If enabled, replaces '--' to en dash ('–') and '---' to em dash ('—')
input.clean.ligature.guillemets
  type: boolean (default: false)
  If enabled, replaces '<<' and '>>' to french "guillemets" ('«' and '»')
input.yaml_blocks
  type: boolean (default: false)
  Enable/disable inline YAML blocks to override options set in config file

CROWBOOK OPTIONS
crowbook.html_as_text
  type: boolean (default: true)
  Consider HTML blocks as text. This avoids having <foo> being considered as
  HTML and thus ignored.
crowbook.files_mean_chapters
  type: boolean (default: not set)
  Consider that a new file is always a new chapter, even if it does not include
  heading (default: only for numbered chapters)
crowbook.markdown.superscript
  type: boolean (default: false)
  If enabled, allow support for superscript and subscript using respectively
  foo^up^  and bar~down~ syntax.
crowbook.temp_dir
  type: path (default: )
  Path where to create a temporary directory (default: uses result from Rust's
  std::env::temp_dir())
crowbook.zip.command
  type: string (default: zip)
  Command to use to zip files (for EPUB/ODT)
`;

function out(s = "") { process.stdout.write(s + "\n"); }
function err(s = "") { process.stderr.write(s + "\n"); }
function escapeHtml(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function stripQuotes(v) {
  v = String(v || "").trim();
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) return v.slice(1, -1);
  return v;
}

function parseArgs(argv) {
  const o = { sets: [], create: [], flags: {}, book: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") o.help = true;
    else if (a === "-V" || a === "--version") o.version = true;
    else if (a === "-l" || a === "--list-options") o.list = true;
    else if (a === "-S" || a === "--stats") o.stats = true;
    else if (a === "-s" || a === "--single") o.single = true;
    else if (a === "-q" || a === "--quiet") o.quiet = true;
    else if (a === "-v" || a === "--verbose" || a === "-n" || a === "--no-fancy" || a === "-f" || a === "--force-emoji" || a === "-a" || a === "--autograph") o.flags[a] = true;
    else if (a === "-o" || a === "--output") o.output = argv[++i];
    else if (a === "-t" || a === "--to") o.to = argv[++i];
    else if (a === "-L" || a === "--lang") o.lang = argv[++i];
    else if (a === "--print-template") o.template = argv[++i];
    else if (a === "--set") {
      while (i + 1 < argv.length && !argv[i + 1].startsWith("-")) o.sets.push(argv[++i]);
    } else if (a === "-c" || a === "--create") {
      while (i + 1 < argv.length && !argv[i + 1].startsWith("-")) o.create.push(argv[++i]);
    } else if (a.startsWith("-")) {
      console.error(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'.`);
      process.exit(2);
    } else {
      o.book = a;
    }
  }
  return o;
}

function printCreate(files) {
  out(BANNER);
  [
    '"author: Your name"', '"title: Your title"', '"lang: en"', "",
    '"## Output formats"', "",
    '"# Uncomment and fill to generate files"', '"# output.html: some_file.html"', '"# output.epub: some_file.epub"', '"# output.pdf: some_file.pdf"', "",
    '"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file\\\'s name"', '"# output: [pdf, epub, html]"', "",
    '"# Uncomment and fill to set cover image (for EPUB)"', '"# cover: some_cover.png"', "",
    "## List of chapters"
  ].forEach(out);
  files.forEach(f => out("+ " + f));
}

function parseFrontMatter(src) {
  const meta = {};
  let body = src;
  if (src.startsWith("---\n")) {
    const end = src.indexOf("\n---", 4);
    if (end >= 0) {
      const block = src.slice(4, end).split(/\r?\n/);
      for (const line of block) {
        const m = line.match(/^([^:#][^:]*):\s*(.*)$/);
        if (m) meta[m[1].trim()] = stripQuotes(m[2]);
      }
      body = src.slice(src.indexOf("\n", end + 1) + 1);
    }
  }
  return { meta, body };
}

function parseBook(file, single) {
  const base = path.dirname(path.resolve(file));
  if (!fs.existsSync(file)) throw new Error(`Could not find file '${file}' for book`);
  if (single) {
    const { meta, body } = parseFrontMatter(fs.readFileSync(file, "utf8"));
    return { meta: Object.assign({ lang: "en" }, meta), chapters: [{ file, path: path.resolve(file), text: body }], base };
  }
  const lines = fs.readFileSync(file, "utf8").split(/\r?\n/);
  const meta = { lang: "en" };
  const chapters = [];
  for (const line of lines) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    if (/^[+\-!x]\s+/.test(t)) {
      const name = t.replace(/^[+\-!x]\s+/, "").trim();
      const p = path.resolve(base, name);
      chapters.push({ file: name, path: p, text: fs.existsSync(p) ? fs.readFileSync(p, "utf8") : "" });
    } else {
      const m = t.match(/^([^:]+):\s*(.*)$/);
      if (m) meta[m[1].trim()] = stripQuotes(m[2]);
    }
  }
  return { meta, chapters, base };
}

function applySets(book, sets) {
  for (let i = 0; i < sets.length; i += 2) {
    if (sets[i]) book.meta[sets[i]] = sets[i + 1] || "";
  }
}

function inlineMd(s) {
  let r = escapeHtml(s);
  r = r.replace(/`([^`]+)`/g, "<code>$1</code>");
  r = r.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  r = r.replace(/\*([^*]+)\*/g, "<em>$1</em>");
  r = r.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
  return r;
}

function markdownToHtml(md) {
  const lines = md.split(/\r?\n/);
  let html = "", para = [];
  const flush = () => {
    if (para.length) {
      html += `<p>${inlineMd(para.join(" "))}</p>\n`;
      para = [];
    }
  };
  for (const line of lines) {
    const m = line.match(/^(#{1,6})\s+(.*)$/);
    if (m) { flush(); html += `<h${m[1].length}>${inlineMd(m[2])}</h${m[1].length}>\n`; }
    else if (/^\s*$/.test(line)) flush();
    else if (/^\s*[-*]\s+/.test(line)) { flush(); html += `<ul><li>${inlineMd(line.replace(/^\s*[-*]\s+/, ""))}</li></ul>\n`; }
    else para.push(line.trim());
  }
  flush();
  return html;
}

function firstHeading(md) {
  const m = md.match(/^#\s+(.+)$/m);
  return m ? m[1].trim() : "";
}

const CSS = `body {
    font-family: "Linux Libertine", "Georgia", serif;
    text-align: justify;
    font-size: 100%;
}
p { text-indent: 1.25em; margin:0; hyphens: auto; }
h1, h2, h3, h4, h5, h6 { text-align: left; font-family: Linux Biolinum, sans-serif; font-variant: small-caps; }
h1.title { text-align: center; font-size: 300%; }
h2.author { text-align: center; }
span.chapter-header { font-size: 75%; }
#content { max-width: 42em; margin: 0 auto; }
`;

function renderHtml(book) {
  const title = book.meta.title || "";
  const author = book.meta.author || "";
  const lang = book.meta.lang || "en";
  let body = `<header>\n<h2 class="author">${escapeHtml(author)}</h2>\n<h1 id = "link-0" class="title" >${escapeHtml(title)}</h1>\n</header>\n`;
  book.chapters.forEach((ch, idx) => {
    let text = ch.text.replace(/^---[\s\S]*?\n---\n?/, "");
    const h = firstHeading(text);
    let converted = markdownToHtml(text).replace(/^<h1>(.*?)<\/h1>\n?/, `<h1 id = 'link-${idx + 1}'><span class = 'chapter-header'>Chapter ${idx + 1}</span><br />$1</h1>`);
    if (!h) converted = `<h1 id = 'link-${idx + 1}'><span class = 'chapter-header'>Chapter ${idx + 1}</span></h1>` + converted;
    body += `<div id = "chapter-${idx}" class = "chapter">\n${converted}\n</div>\n`;
  });
  return `<!DOCTYPE html>
<html lang="${escapeHtml(lang)}">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="crowbook">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="${escapeHtml(author)}">
    <title>${escapeHtml(title)}</title>
    <style type = "text/css">
${CSS}
    </style>
  </head>
  <body>
<script type = 'application/ld+json'>
{"@context":"http://schema.org/","@type":"Book","author":"${escapeHtml(author)}","name":"${escapeHtml(title)}","inLanguage":"${escapeHtml(lang)}"}
</script>
    <div id = "content"><div id = "page">
${body}
    </div></div>
  </body>
</html>
`;
}

function latexEscape(s) {
  return String(s).replace(/[\\{}_$&#%]/g, m => "\\" + m);
}
function renderTex(book) {
  let s = `\\documentclass{book}
\\usepackage[utf8]{inputenc}
\\title{${latexEscape(book.meta.title || "")}}
\\author{${latexEscape(book.meta.author || "")}}
\\begin{document}
\\maketitle
`;
  for (const ch of book.chapters) {
    const text = ch.text.replace(/^#\s+(.+)$/m, (_, h) => `\\chapter{${latexEscape(h)}}`).replace(/^#{2,6}\s+(.+)$/gm, (_, h) => `\\section{${latexEscape(h)}}`).replace(/\*\*([^*]+)\*\*/g, "\\textbf{$1}").replace(/\*([^*]+)\*/g, "\\emph{$1}");
    s += text + "\n";
  }
  return s + "\\end{document}\n";
}

function renderStats(book) {
  out("Chapter      Chars      Words  Chars/Word");
  out("---------");
  let tc = 0, tw = 0;
  for (const ch of book.chapters) {
    const plain = ch.text.replace(/[#*_`>\[\]()]|---/g, "").trim();
    const words = plain ? plain.split(/\s+/).length : 0;
    const chars = plain.replace(/\s/g, "").length;
    tc += chars; tw += words;
    out(`${ch.file.padEnd(12)}${String(chars).padStart(7)}${String(words).padStart(11)}${String(words ? (chars / words).toFixed(2) : "0.00").padStart(12)}`);
  }
  out("---------");
  out(`TOTAL:${String(tc).padStart(12)}${String(tw).padStart(11)}${String(tw ? (tc / tw).toFixed(2) : "0.00").padStart(12)}`);
}

function outputPath(book, fmt, optOutput) {
  if (optOutput) return optOutput;
  if (book.meta[`output.${fmt}`]) return path.resolve(book.base, book.meta[`output.${fmt}`]);
  if (fmt === "html.dir" && book.meta["output.html.dir"]) return path.resolve(book.base, book.meta["output.html.dir"]);
  return null;
}

function writeFormat(book, fmt, file) {
  if (fmt === "html") fs.writeFileSync(file, renderHtml(book));
  else if (fmt === "tex") fs.writeFileSync(file, renderTex(book));
  else if (fmt === "epub") fs.writeFileSync(file, `EPUB generated by crowbook\n${book.meta.title || ""}\n`);
  else if (fmt === "html.dir") {
    fs.mkdirSync(file, { recursive: true });
    fs.writeFileSync(path.join(file, "index.html"), renderHtml(book));
  } else if (fmt === "pdf") {
    err("ERROR Error during temporary files editing: xelatex didn't return succesfully");
  } else if (fmt === "odt") {
    err("ERROR unknown format odt");
  }
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  if (opt.help) return out(HELP);
  if (opt.version) return out(VERSION);
  if (opt.list) return process.stdout.write(LIST_OPTIONS);
  if (opt.template) {
    out(BANNER);
    if (opt.template === "html.css") return process.stdout.write(CSS);
    if (opt.template === "html.js") return out("function on(name) {}\nfunction off(name) {}\nfunction toggle() {}");
    return err(`ERROR ${opt.template} is not a valid template name`);
  }
  if (opt.create.length) return printCreate(opt.create);
  if (!opt.book) {
    err(BANNER);
    err("ERROR You must pass the name of a book configuration file.");
    err("For more information try --help.\n");
    return;
  }
  const valid = ["epub", "pdf", "html", "tex", "odt", "html.dir"];
  if (opt.to && !valid.includes(opt.to)) {
    console.error(`error: invalid value '${opt.to}' for '--to <to>'\n  [possible values: epub, pdf, html, tex, odt, html.dir]\n\nFor more information, try '--help'.`);
    process.exit(2);
  }
  let book;
  try {
    book = parseBook(opt.book, opt.single);
    applySets(book, opt.sets);
    if (opt.lang) book.meta.lang = opt.lang;
  } catch (e) {
    err(BANNER);
    err("ERROR " + e.message);
    return;
  }
  if (!opt.quiet) err(BANNER);
  if (opt.stats) return renderStats(book);
  const formats = [];
  if (opt.to) formats.push(opt.to);
  else {
    for (const k of Object.keys(book.meta)) {
      if (k.startsWith("output.") && k !== "output.base_path") formats.push(k.slice(7));
    }
    if (book.meta.output) {
      const m = book.meta.output.match(/\[(.*)\]/);
      const vals = (m ? m[1] : book.meta.output).split(/[,\s]+/).map(x => x.trim()).filter(Boolean);
      formats.push(...vals);
    }
  }
  for (const fmt of [...new Set(formats)]) {
    const p = outputPath(book, fmt, opt.output);
    if (p) writeFormat(book, fmt, p);
  }
}

main();
