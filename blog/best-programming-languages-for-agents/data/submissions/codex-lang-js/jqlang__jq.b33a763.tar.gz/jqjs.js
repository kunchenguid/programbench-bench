#!/usr/bin/env node
'use strict';

const fs = require('fs');

const VERSION = 'jq-build-2b77eb1';
const BUILD = '--disable-docs --with-oniguruma=builtin --enable-static --enable-all-static --prefix=/usr/local';

function die(msg, code = 2) {
  process.stderr.write(msg + '\n');
  process.exit(code);
}

function help() {
  process.stdout.write(`jq - commandline JSON processor [version build-2b77eb1]

Usage:\tjq [options] <jq filter> [file...]
\tjq [options] --args <jq filter> [strings...]
\tjq [options] --jsonargs <jq filter> [JSON_TEXTS...]

jq is a tool for processing JSON inputs, applying the given filter to
its JSON text inputs and producing the filter's results as JSON on
standard output.

Command options:
  -n, --null-input          use \`null\` as the single input value;
  -R, --raw-input           read each line as string instead of JSON;
  -s, --slurp               read all inputs into an array and use it as
                            the single input value;
  -c, --compact-output      compact instead of pretty-printed output;
  -r, --raw-output          output strings without escapes and quotes;
      --raw-output0         implies -r and output NUL after each output;
  -j, --join-output         implies -r and output without newline after
                            each output;
  -a, --ascii-output        output strings by only ASCII characters
                            using escape sequences;
  -S, --sort-keys           sort keys of each object on output;
  -C, --color-output        colorize JSON output;
  -M, --monochrome-output   disable colored output;
      --tab                 use tabs for indentation;
      --indent n            use n spaces for indentation (max 7 spaces);
      --arg name value      set $name to the string value;
      --argjson name value  set $name to the JSON value;
      --slurpfile name file set $name to an array of JSON values read
                            from the file;
      --rawfile name file   set $name to string contents of file;
      --args                consume remaining arguments as positional
                            string values;
      --jsonargs            consume remaining arguments as positional
                            JSON values;
  -e, --exit-status         set exit status code based on the output;
  -V, --version             show the version;
  --build-configuration     show jq's build configuration;
  -h, --help                show the help;
  --                        terminates argument processing;
`);
}

class Lexer {
  constructor(s) { this.s = s; this.i = 0; this.tok = null; this.next(); }
  eof() { return this.tok.type === 'eof'; }
  isIdStart(c) { return /[A-Za-z_]/.test(c); }
  isId(c) { return /[A-Za-z0-9_]/.test(c); }
  skip() {
    while (this.i < this.s.length) {
      const c = this.s[this.i];
      if (/\s/.test(c)) this.i++;
      else if (c === '#') { while (this.i < this.s.length && this.s[this.i] !== '\n') this.i++; }
      else break;
    }
  }
  next() {
    this.skip();
    if (this.i >= this.s.length) return this.tok = {type:'eof', value:null};
    const s = this.s, c = s[this.i];
    const two = s.slice(this.i, this.i + 2);
    const ops2 = ['==','!=','<=','>=','//','+=','-=','*=','/=','%='];
    if (ops2.includes(two)) { this.i += 2; return this.tok = {type:two, value:two}; }
    if ('.,|:;()[]{}+-*/%<>?='.includes(c)) { this.i++; return this.tok = {type:c, value:c}; }
    if (c === '"' || c === "'") {
      const q = c; let j = this.i + 1, out = '';
      while (j < s.length) {
        const ch = s[j++];
        if (ch === q) break;
        if (ch === '\\') {
          const e = s[j++];
          if (e === 'u') { out += String.fromCodePoint(parseInt(s.slice(j, j + 4), 16)); j += 4; }
          else out += ({n:'\n',r:'\r',t:'\t',b:'\b',f:'\f','\\':'\\','"':'"',"'":"'"}[e] ?? e);
        } else out += ch;
      }
      this.i = j; return this.tok = {type:'str', value:out};
    }
    if (/[0-9-]/.test(c) && (c !== '-' || /[0-9]/.test(s[this.i+1] || ''))) {
      const m = s.slice(this.i).match(/^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/);
      this.i += m[0].length; return this.tok = {type:'num', value:Number(m[0])};
    }
    if (c === '$') {
      this.i++; let name = '';
      while (this.i < s.length && this.isId(s[this.i])) name += s[this.i++];
      return this.tok = {type:'var', value:name};
    }
    if (this.isIdStart(c)) {
      let name = '';
      while (this.i < s.length && this.isId(s[this.i])) name += s[this.i++];
      return this.tok = {type:'id', value:name};
    }
    throw new Error(`unexpected character ${c}`);
  }
  eat(t) { if (this.tok.type === t) { const v = this.tok; this.next(); return v; } return null; }
  expect(t) { const v = this.eat(t); if (!v) throw new Error(`expected ${t}, got ${this.tok.type}`); return v; }
}

function parse(src) {
  const lx = new Lexer(src);
  const stopped = stop => stop.includes(lx.tok.type) || (lx.tok.type === 'id' && stop.includes(lx.tok.value));
  const keywords = new Set(['then','else','end','if','elif','reduce','foreach','as','def','try','catch']);
  function expr(stop = []) { return comma(stop); }
  function comma(stop) {
    let n = pipe(stop);
    while (!stopped(stop) && lx.eat(',')) n = {t:'comma', a:n, b:pipe(stop)};
    return n;
  }
  function pipe(stop) {
    let n = alt(stop);
    while (!stopped(stop) && lx.eat('|')) n = {t:'pipe', a:n, b:alt(stop)};
    return n;
  }
  function alt(stop) {
    let n = logic(stop);
    while (!stopped(stop) && lx.eat('//')) n = {t:'alt', a:n, b:logic(stop)};
    return n;
  }
  function logic(stop) {
    let n = cmp(stop);
    while (!stopped(stop) && lx.tok.type === 'id' && ['and','or'].includes(lx.tok.value)) {
      const op = lx.tok.value; lx.next(); n = {t:'bin', op, a:n, b:cmp(stop)};
    }
    return n;
  }
  function cmp(stop) {
    let n = add(stop);
    while (!stopped(stop) && ['==','!=','<','>','<=','>='].includes(lx.tok.type)) {
      const op = lx.tok.type; lx.next(); n = {t:'bin', op, a:n, b:add(stop)};
    }
    return n;
  }
  function add(stop) {
    let n = mul(stop);
    while (!stopped(stop) && ['+','-'].includes(lx.tok.type)) {
      const op = lx.tok.type; lx.next(); n = {t:'bin', op, a:n, b:mul(stop)};
    }
    return n;
  }
  function mul(stop) {
    let n = unary(stop);
    while (!stopped(stop) && ['*','/','%'].includes(lx.tok.type)) {
      const op = lx.tok.type; lx.next(); n = {t:'bin', op, a:n, b:unary(stop)};
    }
    return n;
  }
  function unary(stop) {
    if (lx.eat('-')) return {t:'neg', x:unary(stop)};
    if (lx.tok.type === 'id' && lx.tok.value === 'not') { lx.next(); return {t:'not', x:unary(stop)}; }
    return postfix(primary(stop), stop);
  }
  function primary(stop) {
    if (lx.eat('.')) {
      if (lx.eat('.')) return {t:'recurse', x:{t:'idn'}};
      let n = {t:'idn'};
      if (lx.tok.type === 'id' && !keywords.has(lx.tok.value)) { const k = lx.tok.value; lx.next(); n = {t:'field', x:n, key:k}; lx.eat('?'); }
      else if (lx.eat('[')) {
        if (lx.eat(']')) { n = {t:'iter', x:n}; lx.eat('?'); }
        else {
          const e = expr([']',':']);
          if (lx.eat(':')) { const e2 = lx.tok.type === ']' ? null : expr([']']); lx.expect(']'); n = {t:'slice', x:n, a:e, b:e2}; }
          else { lx.expect(']'); n = {t:'index', x:n, i:e}; }
          lx.eat('?');
        }
      }
      return n;
    }
    if (lx.tok.type === 'num') { const v = lx.tok.value; lx.next(); return {t:'lit', v}; }
    if (lx.tok.type === 'str') { const v = lx.tok.value; lx.next(); return {t:'lit', v}; }
    if (lx.tok.type === 'var') { const v = lx.tok.value; lx.next(); return {t:'var', v}; }
    if (lx.tok.type === 'id') {
      const id = lx.tok.value; lx.next();
      if (id === 'null') return {t:'lit', v:null};
      if (id === 'true') return {t:'lit', v:true};
      if (id === 'false') return {t:'lit', v:false};
      if (id === 'if') {
        const c = expr(['then']); lx.expect('id');
        const th = expr(['else']); lx.expect('id');
        const el = expr(['end']); lx.expect('id');
        return {t:'if', c, th, el};
      }
      if (lx.eat('(')) {
        const args = [];
        if (!lx.eat(')')) {
          do {
            args.push(expr([',',';',')']));
            if (!(lx.eat(';') || lx.eat(','))) break;
          } while (true);
          lx.expect(')');
        }
        return {t:'call', name:id, args};
      }
      return {t:'call', name:id, args:[]};
    }
    if (lx.eat('(')) { const n = expr([')']); lx.expect(')'); return n; }
    if (lx.eat('[')) {
      if (lx.eat(']')) return {t:'arr', elems:[]};
      const e = expr([']']); lx.expect(']');
      return {t:'collect', x:e};
    }
    if (lx.eat('{')) {
      const pairs = [];
      if (!lx.eat('}')) {
        do {
          let key, val;
          if (lx.tok.type === 'str') { key = {t:'lit', v:lx.tok.value}; lx.next(); }
          else if (lx.tok.type === 'id') { const k = lx.tok.value; lx.next(); key = {t:'lit', v:k}; }
          else if (lx.eat('(')) { key = expr([')']); lx.expect(')'); }
          else throw new Error('bad object key');
          if (lx.eat(':')) val = expr([',','}']); else val = {t:'field', x:{t:'idn'}, key:key.v};
          pairs.push([key, val]);
        } while (lx.eat(','));
        lx.expect('}');
      }
      return {t:'obj', pairs};
    }
    throw new Error(`unexpected token ${lx.tok.type}`);
  }
  function postfix(n, stop) {
    for (;;) {
      if (stopped(stop)) return n;
      if (lx.tok.type === '.' && lx.s[lx.i] !== undefined) {
        lx.next();
        if (lx.tok.type === 'id' && !keywords.has(lx.tok.value)) { const k = lx.tok.value; lx.next(); n = {t:'field', x:n, key:k}; lx.eat('?'); continue; }
        if (lx.eat('[')) {
          if (lx.eat(']')) { n = {t:'iter', x:n}; lx.eat('?'); continue; }
          const e = expr([']',':']);
          if (lx.eat(':')) { const e2 = lx.tok.type === ']' ? null : expr([']']); lx.expect(']'); n = {t:'slice', x:n, a:e, b:e2}; }
          else { lx.expect(']'); n = {t:'index', x:n, i:e}; }
          lx.eat('?'); continue;
        }
      }
      if (lx.eat('[')) {
        if (lx.eat(']')) { n = {t:'iter', x:n}; lx.eat('?'); continue; }
        const e = expr([']',':']);
        if (lx.eat(':')) { const e2 = lx.tok.type === ']' ? null : expr([']']); lx.expect(']'); n = {t:'slice', x:n, a:e, b:e2}; }
        else { lx.expect(']'); n = {t:'index', x:n, i:e}; }
        lx.eat('?'); continue;
      }
      return n;
    }
  }
  const ast = expr([]);
  if (!lx.eof()) throw new Error(`unexpected ${lx.tok.type}`);
  return ast;
}

function truthy(v) { return v !== false && v !== null; }
function deepEq(a,b) { return JSON.stringify(a) === JSON.stringify(b); }
function typeOf(v) { if (v === null) return 'null'; if (Array.isArray(v)) return 'array'; return typeof v; }
function clone(v) { return v === undefined ? null : JSON.parse(JSON.stringify(v)); }

function evalAst(ast, input, env) {
  switch (ast.t) {
    case 'idn': return [input];
    case 'lit': return [ast.v];
    case 'var': return [env.vars[ast.v] ?? null];
    case 'comma': return evalAst(ast.a,input,env).concat(evalAst(ast.b,input,env));
    case 'pipe': return evalAst(ast.a,input,env).flatMap(v => evalAst(ast.b,v,env));
    case 'alt': {
      const a = evalAst(ast.a,input,env).filter(v => v !== null && v !== false);
      return a.length ? a : evalAst(ast.b,input,env);
    }
    case 'neg': return evalAst(ast.x,input,env).map(v => -v);
    case 'not': return evalAst(ast.x,input,env).map(v => !truthy(v));
    case 'if': return evalAst(ast.c,input,env).flatMap(v => evalAst(truthy(v) ? ast.th : ast.el, input, env));
    case 'bin': return bin(ast.op, evalAst(ast.a,input,env), evalAst(ast.b,input,env));
    case 'field': return evalAst(ast.x,input,env).map(v => v && typeof v === 'object' && !Array.isArray(v) ? (v[ast.key] === undefined ? null : v[ast.key]) : null);
    case 'index': return evalAst(ast.x,input,env).flatMap(v => evalAst(ast.i,input,env).map(i => idx(v,i)));
    case 'slice': return evalAst(ast.x,input,env).flatMap(v => {
      const aa = ast.a ? evalAst(ast.a,input,env)[0] : null, bb = ast.b ? evalAst(ast.b,input,env)[0] : null;
      return [slice(v, aa, bb)];
    });
    case 'iter': return evalAst(ast.x,input,env).flatMap(v => Array.isArray(v) ? v : (v && typeof v === 'object' ? Object.values(v) : []));
    case 'recurse': return evalAst(ast.x,input,env).flatMap(v => rec(v));
    case 'collect': return [[].concat(...evalAst(ast.x,input,env).map(v => [v]))];
    case 'arr': return [ast.elems.map(e => evalAst(e,input,env)[0])];
    case 'obj': {
      const o = {};
      for (const [kAst,vAst] of ast.pairs) {
        const k = String(evalAst(kAst,input,env)[0]);
        const vals = evalAst(vAst,input,env);
        o[k] = vals.length ? vals[0] : null;
      }
      return [o];
    }
    case 'call': return call(ast.name, ast.args, input, env);
  }
  throw new Error('bad ast ' + ast.t);
}

function idx(v, i) {
  if (v == null) return null;
  if (Array.isArray(v)) { let n = Number(i); if (n < 0) n = v.length + n; return v[n] === undefined ? null : v[n]; }
  if (typeof v === 'string') { let n = Number(i); if (n < 0) n = [...v].length + n; return [...v][n] ?? null; }
  if (typeof v === 'object') return v[String(i)] === undefined ? null : v[String(i)];
  return null;
}
function rec(v) {
  const out = [v];
  if (Array.isArray(v)) for (const x of v) out.push(...rec(x));
  else if (v && typeof v === 'object') for (const x of Object.values(v)) out.push(...rec(x));
  return out;
}
function slice(v,a,b) {
  if (!(Array.isArray(v) || typeof v === 'string')) return null;
  const len = v.length; let s = a == null ? 0 : Number(a), e = b == null ? len : Number(b);
  if (s < 0) s += len; if (e < 0) e += len;
  return v.slice(s,e);
}
function bin(op, as, bs) {
  const out = [];
  for (const a of as) for (const b of bs) {
    if (op === '+') out.push(addv(a,b));
    else if (op === '-') out.push(a - b);
    else if (op === '*') out.push(mulv(a,b));
    else if (op === '/') out.push(a / b);
    else if (op === '%') out.push(a % b);
    else if (op === '==') out.push(deepEq(a,b));
    else if (op === '!=') out.push(!deepEq(a,b));
    else if (op === '<') out.push(a < b);
    else if (op === '>') out.push(a > b);
    else if (op === '<=') out.push(a <= b);
    else if (op === '>=') out.push(a >= b);
    else if (op === 'and') out.push(truthy(a) && truthy(b));
    else if (op === 'or') out.push(truthy(a) || truthy(b));
  }
  return out;
}
function addv(a,b) {
  if (a == null) return b; if (b == null) return a;
  if (Array.isArray(a) && Array.isArray(b)) return a.concat(b);
  if (typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) return Object.assign({}, a, b);
  return a + b;
}
function mulv(a,b) {
  if (typeof a === 'string' && typeof b === 'number') return a.repeat(b);
  if (typeof b === 'string' && typeof a === 'number') return b.repeat(a);
  if (typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) return Object.assign({}, a, b);
  return a * b;
}

function call(name,args,input,env) {
  const avals = args.map(a => evalAst(a,input,env));
  const one = i => (avals[i] && avals[i][0]);
  if (name === 'empty') return [];
  if (name === 'length') return [input == null ? 0 : (typeof input === 'object' ? Object.keys(input).length : String(input).length)];
  if (name === 'keys' || name === 'keys_unsorted') return [input && typeof input === 'object' ? (Array.isArray(input) ? input.map((_,i)=>i) : Object.keys(input).sort()) : []];
  if (name === 'type') return [typeOf(input)];
  if (name === 'tostring') return [typeof input === 'string' ? input : JSON.stringify(input)];
  if (name === 'tonumber') return [Number(input)];
  if (name === 'floor') return [Math.floor(input)];
  if (name === 'sqrt') return [Math.sqrt(input)];
  if (name === 'abs') return [Math.abs(input)];
  if (name === 'min') return [Array.isArray(input) ? input.reduce((a,b)=>a < b ? a : b) : input];
  if (name === 'max') return [Array.isArray(input) ? input.reduce((a,b)=>a > b ? a : b) : input];
  if (name === 'add') return [Array.isArray(input) ? input.reduce((a,b)=>addv(a,b), null) : input];
  if (name === 'reverse') return [Array.isArray(input) ? [...input].reverse() : String(input).split('').reverse().join('')];
  if (name === 'first') return [Array.isArray(input) || typeof input === 'string' ? input[0] ?? null : input];
  if (name === 'last') return [Array.isArray(input) || typeof input === 'string' ? input[input.length-1] ?? null : input];
  if (name === 'sort') return [Array.isArray(input) ? [...input].sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))) : input];
  if (name === 'unique') return [Array.isArray(input) ? [...new Map(input.map(v=>[JSON.stringify(v),v])).values()] : input];
  if (name === 'flatten') return [flatten(input, args.length ? Number(one(0)) : Infinity)];
  if (name === 'range') {
    let start = 0, end, step = 1;
    if (args.length === 1) end = Number(one(0));
    else { start = Number(one(0)); end = Number(one(1)); if (args.length > 2) step = Number(one(2)); }
    const r = []; if (step > 0) for (let x=start; x<end; x+=step) r.push(x); else for (let x=start; x>end; x+=step) r.push(x);
    return r;
  }
  if (name === 'to_entries') {
    if (Array.isArray(input)) return [input.map((v,i)=>({key:i,value:v}))];
    if (input && typeof input === 'object') return [Object.keys(input).map(k=>({key:k,value:input[k]}))];
    return [[]];
  }
  if (name === 'from_entries') {
    const o = {}; for (const e of (Array.isArray(input) ? input : [])) o[e.key ?? e.Key ?? e.name ?? e.Name] = e.value ?? e.Value;
    return [o];
  }
  if (name === 'has') { const k = one(0); return [input != null && Object.prototype.hasOwnProperty.call(input, k)]; }
  if (name === 'contains') return [contains(input, one(0))];
  if (name === 'startswith') return [String(input).startsWith(String(one(0)))];
  if (name === 'endswith') return [String(input).endsWith(String(one(0)))];
  if (name === 'split') return [String(input).split(String(one(0)))];
  if (name === 'join') return [Array.isArray(input) ? input.join(String(one(0) ?? '')) : input];
  if (name === 'map') return [Array.isArray(input) ? input.flatMap(v => evalAst(args[0], v, env)) : []];
  if (name === 'select') return truthy(evalAst(args[0], input, env)[0]) ? [input] : [];
  if (name === 'del') return [delpath(clone(input), pathFromArg(args[0]))];
  if (name === 'not') return [!truthy(input)];
  if (name === 'values') return input == null ? [] : [input];
  if (name === 'arrays') return Array.isArray(input) ? [input] : [];
  if (name === 'objects') return input && typeof input === 'object' && !Array.isArray(input) ? [input] : [];
  if (name === 'numbers') return typeof input === 'number' ? [input] : [];
  if (name === 'strings') return typeof input === 'string' ? [input] : [];
  if (name === 'booleans') return typeof input === 'boolean' ? [input] : [];
  throw new Error(`${name}/0 is not defined`);
}
function contains(a,b) {
  if (typeof a === 'string') return a.includes(String(b));
  if (Array.isArray(a)) return Array.isArray(b) ? b.every(x => a.some(y => contains(y,x) || deepEq(y,x))) : a.some(x => deepEq(x,b));
  if (a && b && typeof a === 'object' && typeof b === 'object') return Object.keys(b).every(k => contains(a[k], b[k]) || deepEq(a[k], b[k]));
  return deepEq(a,b);
}
function flatten(v, depth) {
  if (!Array.isArray(v) || depth <= 0) return v;
  const out = [];
  for (const x of v) {
    if (Array.isArray(x)) out.push(...flatten(x, depth - 1));
    else out.push(x);
  }
  return out;
}
function pathFromArg(ast) {
  const p = [];
  while (ast && ast.t !== 'idn') {
    if (ast.t === 'field') { p.unshift(ast.key); ast = ast.x; }
    else if (ast.t === 'index' && ast.i.t === 'lit') { p.unshift(ast.i.v); ast = ast.x; }
    else break;
  }
  return p;
}
function delpath(v,p) {
  let o = v; for (let i=0;i<p.length-1;i++) o = o?.[p[i]];
  if (o && p.length) delete o[p[p.length-1]];
  return v;
}

function parseJsonTexts(s) {
  const vals = []; let i = 0;
  while (i < s.length) {
    while (i < s.length && /\s/.test(s[i])) i++;
    if (i >= s.length) break;
    let depth = 0, instr = false, esc = false, start = i, j = i;
    for (; j < s.length; j++) {
      const c = s[j];
      if (instr) { if (esc) esc=false; else if (c === '\\') esc=true; else if (c === '"') instr=false; continue; }
      if (c === '"') instr = true;
      else if (c === '[' || c === '{') depth++;
      else if (c === ']' || c === '}') depth--;
      else if (depth === 0 && /\s/.test(c)) break;
      if (depth === 0 && /[\]}]/.test(c)) { j++; break; }
    }
    const text = s.slice(start,j);
    vals.push(JSON.parse(text));
    i = j;
  }
  return vals;
}
function parseSeq(s) {
  if (!s.includes('\x1e')) return parseJsonTexts(s);
  return s.split('\x1e').filter(x => x.trim()).map(x => JSON.parse(x));
}
function streamVals(v, path = []) {
  const out = [];
  if (Array.isArray(v)) {
    if (v.length === 0) out.push([path, []]);
    v.forEach((x,i) => out.push(...streamVals(x, path.concat(i))));
  } else if (v && typeof v === 'object') {
    const ks = Object.keys(v);
    if (ks.length === 0) out.push([path, {}]);
    for (const k of ks) out.push(...streamVals(v[k], path.concat(k)));
  } else {
    out.push([path, v]);
  }
  return out;
}

function sortKeys(v) {
  if (Array.isArray(v)) return v.map(sortKeys);
  if (v && typeof v === 'object') {
    const o = {}; for (const k of Object.keys(v).sort()) o[k] = sortKeys(v[k]); return o;
  }
  return v;
}
function stringify(v, opt) {
  if (opt.sort) v = sortKeys(v);
  const sp = opt.compact ? 0 : (opt.tab ? '\t' : opt.indent);
  let s = JSON.stringify(v, null, sp);
  if (opt.ascii) s = s.replace(/[^\x00-\x7F]/g, c => c.codePointAt(0) <= 0xffff ? '\\u' + c.codePointAt(0).toString(16).padStart(4,'0') : c);
  return s;
}

function main() {
  const argv = process.argv.slice(2), opt = {indent:2, files:[], vars:{ARGS:{named:{},positional:[]}}};
  let filter = null, afterDash = false;
  for (let i=0;i<argv.length;i++) {
    const a = argv[i];
    if (!afterDash && a === '--') { afterDash = true; continue; }
    if (!afterDash && a.startsWith('-')) {
      if (/^-[A-Za-z]{2,}$/.test(a) && !['--help'].includes(a)) {
        argv.splice(i, 1, ...a.slice(1).split('').map(c => '-' + c));
        i--;
        continue;
      }
      if (a === '-h' || a === '--help') { help(); return; }
      if (a === '-V' || a === '--version') { console.log(VERSION); return; }
      if (a === '--build-configuration') { console.log(BUILD); return; }
      if (a === '-n' || a === '--null-input') opt.nullInput = true;
      else if (a === '-R' || a === '--raw-input') opt.rawInput = true;
      else if (a === '-s' || a === '--slurp') opt.slurp = true;
      else if (a === '-c' || a === '--compact-output') opt.compact = true;
      else if (a === '-r' || a === '--raw-output') opt.raw = true;
      else if (a === '--raw-output0') { opt.raw = true; opt.zero = true; }
      else if (a === '-j' || a === '--join-output') { opt.raw = true; opt.join = true; }
      else if (a === '-a' || a === '--ascii-output') opt.ascii = true;
      else if (a === '-S' || a === '--sort-keys') opt.sort = true;
      else if (a === '--tab') opt.tab = true;
      else if (a === '--indent') opt.indent = Math.min(7, Number(argv[++i]));
      else if (a.startsWith('--indent=')) opt.indent = Math.min(7, Number(a.slice(9)));
      else if (a === '--seq') opt.seq = true;
      else if (a === '--stream' || a === '--stream-errors') opt.stream = true;
      else if (a === '-f' || a === '--from-file') filter = fs.readFileSync(argv[++i], 'utf8');
      else if (a === '-L' || a === '--library-path') i++;
      else if (a === '--arg') { const n=argv[++i], v=argv[++i]; opt.vars[n]=v; opt.vars.ARGS.named[n]=v; }
      else if (a === '--argjson') { const n=argv[++i], v=JSON.parse(argv[++i]); opt.vars[n]=v; opt.vars.ARGS.named[n]=v; }
      else if (a === '--rawfile') { const n=argv[++i], v=fs.readFileSync(argv[++i], 'utf8'); opt.vars[n]=v; opt.vars.ARGS.named[n]=v; }
      else if (a === '--slurpfile') { const n=argv[++i], v=parseJsonTexts(fs.readFileSync(argv[++i], 'utf8')); opt.vars[n]=v; opt.vars.ARGS.named[n]=v; }
      else if (a === '--args') { if (filter == null) filter = argv[++i]; opt.vars.ARGS.positional = argv.slice(i+1); break; }
      else if (a === '--jsonargs') { if (filter == null) filter = argv[++i]; opt.vars.ARGS.positional = argv.slice(i+1).map(JSON.parse); break; }
      else if (a === '-M' || a === '-C' || a === '--color-output' || a === '--monochrome-output' || a === '--unbuffered') {}
      else if (a === '-e' || a === '--exit-status') opt.exitStatus = true;
      else die(`jq: Unknown option ${a}`);
    } else if (filter == null) filter = a;
    else opt.files.push(a);
  }
  if (filter == null) { help(); process.exit(2); }
  let ast;
  try { ast = parse(filter); } catch (e) { process.stderr.write(`jq: error: ${e.message}\n`); process.exit(3); }
  let inputs = [];
  try {
    if (opt.nullInput) inputs = [null];
    else {
      let text = '';
      if (opt.files.length) for (const f of opt.files) text += fs.readFileSync(f, 'utf8');
      else text = fs.readFileSync(0, 'utf8');
      if (opt.rawInput) inputs = opt.slurp ? [text] : text.replace(/\n$/,'').split(/\n/);
      else {
        const parsed = opt.seq ? parseSeq(text) : parseJsonTexts(text);
        inputs = opt.slurp ? [parsed] : parsed;
        if (opt.stream) inputs = inputs.flatMap(v => streamVals(v));
      }
    }
  } catch (e) { process.stderr.write(`jq: error: ${e.message}\n`); process.exit(2); }
  let any = false, last = undefined;
  try {
    for (const inp of inputs) for (const out of evalAst(ast, inp, {vars:opt.vars})) {
      any = true; last = out;
      let s = (opt.raw && typeof out === 'string') ? out : stringify(out, opt);
      if (opt.seq) process.stdout.write('\x1e');
      process.stdout.write(s);
      if (!opt.join) process.stdout.write(opt.zero ? '\0' : '\n');
    }
  } catch (e) { process.stderr.write(`jq: error: ${e.message}\n`); process.exit(5); }
  if (opt.exitStatus) process.exit(any ? (truthy(last) ? 0 : 1) : 4);
}

main();
