#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");

const VERSION = "tui-journal 0.16.1";
const HOME = process.env.HOME || os.homedir() || "/home/agent";
const DEFAULT_CONFIG_DIR = path.join(HOME, ".config", "tui-journal");

const DEFAULT_THEME = `[general.input_block_active]
fg = "LightYellow"
modifiers = ""

[general.input_block_invalid]
fg = "LightRed"
modifiers = ""

[general.input_corsur_active]
fg = "Black"
bg = "LightYellow"
modifiers = ""

[general.input_corsur_invalid]
fg = "Black"
bg = "LightRed"
modifiers = ""

[general.list_item_selected]
fg = "LightYellow"
modifiers = "BOLD"

[general.list_highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[general.list_highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = ""

[journals_list.block_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.block_inactive]
fg = "#AAAAC8"
modifiers = ""

[journals_list.block_multi_select]
fg = "Yellow"
modifiers = "BOLD | ITALIC"

[journals_list.highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = "BOLD"

[journals_list.highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = "BOLD"

[journals_list.title_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.title_inactive]
fg = "#AAAAC8"
modifiers = "BOLD"

[journals_list.title_selected]
fg = "Yellow"
modifiers = "BOLD"

[journals_list.date_priority]
fg = "LightBlue"
modifiers = ""

[journals_list.tags_default]
fg = "LightCyan"
modifiers = "DIM"

[editor.block_insert]
fg = "LightGreen"
modifiers = "BOLD"

[editor.block_visual]
fg = "Blue"
modifiers = "BOLD"

[editor.block_normal_active]
fg = "Reset"
modifiers = "BOLD"

[editor.block_normal_inactive]
fg = "#AAAAC8"
modifiers = ""

[editor.cursor_normal]
fg = "Black"
bg = "White"
modifiers = ""

[editor.cursor_insert]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[editor.cursor_visual]
fg = "Black"
bg = "Blue"
modifiers = ""

[editor.selection_style]
fg = "Black"
bg = "White"
modifiers = ""

[msgbox]
error = "LightRed"
warning = "Yellow"
info = "LightGreen"
question = "LightBlue"

`;

function stdout(s = "") {
  process.stdout.write(s);
}

function stderr(s = "") {
  process.stderr.write(s);
}

function dieError(message, code = 1) {
  stderr(`Error: ${message}\n`);
  process.exit(code);
}

function clapError(message, usage) {
  stderr(`error: ${message}\n\n${usage}\n\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function clapValueError(message) {
  stderr(`error: ${message}\n\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function parseValue(raw) {
  const v = raw.trim();
  if (v === "true") return true;
  if (v === "false") return false;
  if (/^-?\d+$/.test(v)) return Number(v);
  const m = v.match(/^"(.*)"$/);
  if (m) return m[1];
  return v;
}

function defaultConfig() {
  return {
    backend_type: "Sqlite",
    scroll_per_page: 5,
    sync_os_clipboard: false,
    history_limit: 10,
    colored_tags: true,
    datum_visibility: "show",
    app_state_dir: path.join(HOME, ".local", "state", "tui-journal"),
    export: { show_confirmation: true },
    external_editor: { auto_save: false, temp_file_extension: "txt" },
    json_backend: { file_path: path.join(HOME, "tui-journal", "entries.json") },
    sqlite_backend: { file_path: path.join(HOME, "tui-journal", "entries.db") },
  };
}

function mergeConfig(cfg, file) {
  let section = null;
  const lines = fs.readFileSync(file, "utf8").split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].replace(/#.*/, "").trim();
    if (!line) continue;
    const sm = line.match(/^\[([A-Za-z0-9_.-]+)\]$/);
    if (sm) {
      section = sm[1];
      if (!cfg[section]) cfg[section] = {};
      continue;
    }
    const kv = line.match(/^([A-Za-z0-9_.-]+)\s*=\s*(.+)$/);
    if (!kv) continue;
    const key = kv[1];
    const value = parseValue(kv[2]);
    if (key === "backend_type" && value !== "Json" && value !== "Sqlite") {
      dieError(`Failed to read configuration file. Error infos: TOML parse error at line ${i + 1}, column ${line.indexOf("=") + 3}
  |
${i + 1} | ${line}
  | ${" ".repeat(Math.max(0, line.indexOf("=") + 2))}${String(kv[2]).trim()}
unknown variant \`${value}\`, expected \`Json\` or \`Sqlite\`
`);
    }
    if (section) cfg[section][key] = value;
    else cfg[key] = value;
  }
}

function resolveConfigPath(custom) {
  if (!custom) return { dir: DEFAULT_CONFIG_DIR, file: path.join(DEFAULT_CONFIG_DIR, "config.toml"), customIsFile: false };
  if (!fs.existsSync(custom)) dieError(`Provided custom directory doesn't exit. Path: ${custom}`);
  const st = fs.statSync(custom);
  if (st.isDirectory()) return { dir: custom, file: path.join(custom, "config.toml"), customIsFile: false };
  return { dir: path.dirname(custom), file: custom, customIsFile: true };
}

function loadConfig(opts) {
  const cfg = defaultConfig();
  const loc = resolveConfigPath(opts.config);
  if (fs.existsSync(loc.file)) mergeConfig(cfg, loc.file);
  if (opts.backendType) cfg.backend_type = opts.backendType === "json" ? "Json" : "Sqlite";
  if (opts.jsonPath) cfg.json_backend.file_path = opts.jsonPath;
  if (opts.sqlitePath) cfg.sqlite_backend.file_path = opts.sqlitePath;
  return { cfg, loc };
}

function configToml(cfg) {
  return `backend_type = "${cfg.backend_type}"
scroll_per_page = ${cfg.scroll_per_page}
sync_os_clipboard = ${cfg.sync_os_clipboard}
history_limit = ${cfg.history_limit}
colored_tags = ${cfg.colored_tags}
datum_visibility = "${cfg.datum_visibility}"
app_state_dir = "${cfg.app_state_dir}"

[export]
show_confirmation = ${cfg.export.show_confirmation}

[external_editor]
auto_save = ${cfg.external_editor.auto_save}
temp_file_extension = "${cfg.external_editor.temp_file_extension}"

[json_backend]
file_path = "${cfg.json_backend.file_path}"

[sqlite_backend]
file_path = "${cfg.sqlite_backend.file_path}"
`;
}

function mainHelp() {
  return `Tui app allows writing and managing journals/notes from within the terminal With different local back-ends

Usage: executable [OPTIONS] [COMMAND]

Commands:
  print-config     Print the current settings including the paths for the back-end files [aliases: pc]
  import-journals  Import journals from the given transfer JSON file to the current back-end file [aliases: imj]
  assign-priority  Assign priority for all the entries with empty priority field [aliases: ap]
  theme            Provides commands regarding changing themes and styles of the app [aliases: style]
  help             Print this message or the help of the given subcommand(s)

Options:
  -j, --json-file-path <FILE PATH>    Sets the entries Json file path and starts using it
  -s, --sqlite-file-path <FILE PATH>  Sets the entries sqlite file path and starts using it
  -b, --backend-type <BACKEND_TYPE>   Sets the backend type and starts using it [possible values: json, sqlite]
  -c, --config <DIR PATH>             Specifies the path for the configuration directory.
                                      Configuration files is considered as root for themes file too.
                                      It still accepts the path for configuration file for backward compatibility.
                                      (default path: ${DEFAULT_CONFIG_DIR})
  -v, --verbose...                    Increases logging verbosity each use for up to 3 times
  -l, --log <FILE PATH>               Specifies a file to use for logging
                                      (default file: ${path.join(HOME, ".cache", "tui-journal", "tui-journal.log")})
  -h, --help                          Print help
  -V, --version                       Print version
`;
}

const HELPS = {
  "print-config": `Print the current settings including the paths for the back-end files

Usage: executable print-config

Options:
  -h, --help  Print help
`,
  "import-journals": `Import journals from the given transfer JSON file to the current back-end file

Usage: executable import-journals --path <FILE PATH>

Options:
  -p, --path <FILE PATH>  Path of the JSON file to import from
  -h, --help              Print help
`,
  "assign-priority": `Assign priority for all the entries with empty priority field

Usage: executable assign-priority <PRIORITY>

Arguments:
  <PRIORITY>  Priority value (Positive number)

Options:
  -h, --help  Print help
`,
  theme: `Provides commands regarding changing themes and styles of the app

Usage: executable theme <COMMAND>

Commands:
  print-path      Prints the path to the user themes file [aliases: path]
  print-default   Dumps the styles with the default values to be used as a reference and base for user custom themes [aliases: default]
  write-defaults  Creates user custom themes file if doesn't exist then writes the default styles to it [aliases: write]
  help            Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
`,
  "theme print-path": `Prints the path to the user themes file

Usage: executable theme print-path

Options:
  -h, --help  Print help
`,
  "theme print-default": `Dumps the styles with the default values to be used as a reference and base for user custom themes

Usage: executable theme print-default

Options:
  -h, --help  Print help
`,
  "theme write-defaults": `Creates user custom themes file if doesn't exist then writes the default styles to it

Usage: executable theme write-defaults

Options:
  -h, --help  Print help
`,
};

function parseArgs(argv) {
  const opts = {};
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help" || a === "-V" || a === "--version") {
      rest.push(a);
    } else if (a === "-j" || a === "--json-file-path") {
      opts.jsonPath = argv[++i];
    } else if (a === "-s" || a === "--sqlite-file-path") {
      opts.sqlitePath = argv[++i];
    } else if (a === "-b" || a === "--backend-type") {
      const v = argv[++i];
      if (v !== "json" && v !== "sqlite") clapValueError(`invalid value '${v}' for '--backend-type <BACKEND_TYPE>'\n  [possible values: json, sqlite]`);
      opts.backendType = v;
    } else if (a === "-c" || a === "--config") {
      opts.config = argv[++i];
    } else if (a === "-l" || a === "--log") {
      opts.log = argv[++i];
    } else if (a === "-v" || a === "--verbose") {
      opts.verbose = (opts.verbose || 0) + 1;
    } else if (a.startsWith("-v") && /^-v+$/.test(a)) {
      opts.verbose = (opts.verbose || 0) + a.length - 1;
    } else if (a.startsWith("-")) {
      clapError(`unexpected argument '${a}' found\n\n  tip: a similar argument exists: '--backend-type'`, "Usage: executable --backend-type <BACKEND_TYPE>");
    } else {
      rest.push(a);
    }
  }
  return { opts, rest };
}

function themePath(opts) {
  if (opts.config && fs.existsSync(opts.config) && !fs.statSync(opts.config).isDirectory()) {
    stdout("INFO: Custom config directory is ignored in themese because it's not a directory.\n");
    return path.join(DEFAULT_CONFIG_DIR, "themes.toml");
  }
  const loc = resolveConfigPath(opts.config);
  return path.join(loc.dir, "themes.toml");
}

function handleTheme(opts, args) {
  const sub = args[0];
  if (!sub || sub === "help" || sub === "-h" || sub === "--help") return stdout(HELPS.theme);
  const canon = { path: "print-path", default: "print-default", write: "write-defaults" }[sub] || sub;
  if (args.includes("-h") || args.includes("--help")) return stdout(HELPS[`theme ${canon}`] || HELPS.theme);
  if (args.length > 1) clapError(`unexpected argument '${args[1]}' found`, `Usage: executable theme ${canon}`);
  if (canon === "print-path") return stdout(themePath(opts) + "\n");
  if (canon === "print-default") return stdout(DEFAULT_THEME);
  if (canon === "write-defaults") {
    const p = themePath(opts);
    if (fs.existsSync(p)) dieError(`Themes file already exists. Path: ${p}`);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, DEFAULT_THEME);
    return stdout(`Default themes have been written to ${p}\n`);
  }
  clapError(`unrecognized subcommand '${sub}'`, "Usage: executable theme <COMMAND>");
}

function nonTtyDataError() {
  dieError("No such device or address (os error 6)");
}

function run() {
  const { opts, rest } = parseArgs(process.argv.slice(2));
  if (rest.length === 0) return nonTtyDataError();
  if (rest[0] === "-h" || rest[0] === "--help" || rest[0] === "help") return stdout(mainHelp());
  if (rest[0] === "-V" || rest[0] === "--version") return stdout(VERSION + "\n");
  const cmd = { pc: "print-config", imj: "import-journals", ap: "assign-priority", style: "theme" }[rest[0]] || rest[0];
  const args = rest.slice(1);

  if (cmd === "print-config") {
    if (args.includes("-h") || args.includes("--help")) return stdout(HELPS["print-config"]);
    if (args.length) clapError(`unexpected argument '${args[0]}' found`, "Usage: executable print-config");
    return stdout(configToml(loadConfig(opts).cfg) + "\n");
  }
  if (cmd === "theme") return handleTheme(opts, args);
  if (cmd === "import-journals") {
    if (args.includes("-h") || args.includes("--help")) return stdout(HELPS["import-journals"]);
    if (!args.includes("-p") && !args.includes("--path")) {
      clapError("the following required arguments were not provided:\n  --path <FILE PATH>", "Usage: executable import-journals --path <FILE PATH>");
    }
    return nonTtyDataError();
  }
  if (cmd === "assign-priority") {
    if (args.includes("-h") || args.includes("--help")) return stdout(HELPS["assign-priority"]);
    const val = args[0];
    if (!/^\d+$/.test(val || "")) clapValueError(`invalid value '${val}' for '<PRIORITY>': invalid digit found in string`);
    return nonTtyDataError();
  }
  clapError(`unrecognized subcommand '${cmd}'`, "Usage: executable [OPTIONS] [COMMAND]");
}

run();
