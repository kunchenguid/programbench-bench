#!/usr/bin/env node
"use strict";

const dns = require("dns");
const { spawn, execFileSync } = require("child_process");

const HELP = `Ping, but with a graph.

Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...

Arguments:
  [HOSTS_OR_COMMANDS]...  Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1

Options:
      --cmd
          Graph the execution time for a list of commands rather than pinging hosts
  -n, --watch-interval <WATCH_INTERVAL>
          Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5
  -b, --buffer <BUFFER>
          Determines the number of seconds to display in the graph [default: 30]
  -4
          Resolve ping targets to IPv4 address
  -6
          Resolve ping targets to IPv6 address
  -i, --interface <INTERFACE>
          Interface to use when pinging
  -s, --simple-graphics
          
      --vertical-margin <VERTICAL_MARGIN>
          Vertical margin around the graph (top and bottom) [default: 1]
      --horizontal-margin <HORIZONTAL_MARGIN>
          Horizontal margin around the graph (left and right) [default: 0]
  -c, --color <color>
          Assign color to a graph entry.
          
          This option can be defined more than once as a comma separated string, and the
          order which the colors are provided will be matched against the hosts or
          commands passed to gping.
          
          Hexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the
          following color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',
          'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',
          'light-blue', 'light-magenta', 'light-cyan', and 'white'
      --clear
          Clear the graph from the terminal after closing the program
      --ping-args [<PING_ARGS>...]
          Extra arguments to pass to \`ping\`. These are platform dependent
  -h, --help
          Print help
  -V, --version
          Print version
`;

const LONG_VERSION = `gping 1.20.1
commit_hash: d67d2aeb
build_time: 2026-04-17 19:59:37 +00:00
build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu`;

const COLORS = new Set([
  "black", "red", "green", "yellow", "blue", "magenta", "cyan", "gray",
  "dark-gray", "light-red", "light-green", "light-yellow", "light-blue",
  "light-magenta", "light-cyan", "white",
]);

function die(message, code = 1) {
  process.stderr.write(message.endsWith("\n") ? message : message + "\n");
  process.exit(code);
}

function clapError(message, usage) {
  let out = `error: ${message}\n\n`;
  if (usage) out += `${usage}\n\n`;
  out += "For more information, try '--help'.\n";
  die(out, 2);
}

function needValue(args, i, opt, metavar) {
  if (i + 1 >= args.length || args[i + 1] === "--") {
    clapError(`a value is required for '${opt} <${metavar}>' but none was supplied`);
  }
  return args[i + 1];
}

function parseFloatLike(value, opt, metavar) {
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(value)) {
    clapError(`invalid value '${value}' for '${opt} <${metavar}>': invalid float literal`);
  }
  return Number(value);
}

function parseIntLike(value, opt, metavar) {
  if (!/^[+-]?\d+$/.test(value)) {
    clapError(`invalid value '${value}' for '${opt} <${metavar}>': invalid digit found in string`);
  }
  return Number.parseInt(value, 10);
}

function parseColorList(value) {
  for (const raw of value.split(",")) {
    const color = raw.trim();
    if (!COLORS.has(color) && !/^#[0-9a-fA-F]{6}$/.test(color)) {
      die(`Error: Invalid color code: \`${color}\`\n\nCaused by:\n    Failed to parse Colors`);
    }
  }
}

function parseArgs(argv) {
  const opts = {
    cmd: false, ipv4: false, ipv6: false, simple: false, clear: false,
    watch: undefined, buffer: 30, vmargin: 1, hmargin: 0, iface: undefined,
    colors: [], pingArgs: [], targets: [],
  };

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") {
      opts.targets.push(...argv.slice(i + 1));
      break;
    } else if (a === "-h" || a === "--help") {
      process.stdout.write(HELP);
      process.exit(0);
    } else if (a === "-V") {
      console.log("gping 1.20.1");
      process.exit(0);
    } else if (a === "--version") {
      console.log(LONG_VERSION);
      process.exit(0);
    } else if (a === "--cmd") {
      opts.cmd = true;
    } else if (a === "-4") {
      opts.ipv4 = true;
    } else if (a === "-6") {
      opts.ipv6 = true;
    } else if (a === "-s" || a === "--simple-graphics") {
      opts.simple = true;
    } else if (a === "--clear") {
      opts.clear = true;
    } else if (a === "-n" || a === "--watch-interval") {
      const v = needValue(argv, i, "--watch-interval", "WATCH_INTERVAL");
      opts.watch = parseFloatLike(v, "--watch-interval", "WATCH_INTERVAL");
      i++;
    } else if (a === "-b" || a === "--buffer") {
      const v = needValue(argv, i, "--buffer", "BUFFER");
      opts.buffer = parseIntLike(v, "--buffer", "BUFFER");
      i++;
    } else if (a === "-i" || a === "--interface") {
      opts.iface = needValue(argv, i, "--interface", "INTERFACE");
      i++;
    } else if (a === "--vertical-margin") {
      const v = needValue(argv, i, "--vertical-margin", "VERTICAL_MARGIN");
      opts.vmargin = parseIntLike(v, "--vertical-margin", "VERTICAL_MARGIN");
      i++;
    } else if (a === "--horizontal-margin") {
      const v = needValue(argv, i, "--horizontal-margin", "HORIZONTAL_MARGIN");
      opts.hmargin = parseIntLike(v, "--horizontal-margin", "HORIZONTAL_MARGIN");
      i++;
    } else if (a === "-c" || a === "--color") {
      const v = needValue(argv, i, "--color", "color");
      parseColorList(v);
      opts.colors.push(...v.split(","));
      i++;
    } else if (a === "--ping-args") {
      opts.pingArgs.push(...argv.slice(i + 1));
      break;
    } else if (a.startsWith("--")) {
      clapError(`unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'`, "Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...");
    } else if (/^-[^-].+/.test(a)) {
      for (const ch of a.slice(1)) {
        if (ch === "4") opts.ipv4 = true;
        else if (ch === "6") opts.ipv6 = true;
        else if (ch === "s") opts.simple = true;
        else clapError(`unexpected argument '-${ch}' found`, "Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...");
      }
    } else {
      opts.targets.push(a);
    }
  }

  if (opts.ipv4 && opts.ipv6) {
    clapError("the argument '-4' cannot be used with '-6'", "Usage: executable -4 <HOSTS_OR_COMMANDS>...");
  }
  return opts;
}

function expandTarget(t) {
  const idx = t.indexOf(":");
  if (idx < 1) return t;
  const provider = t.slice(0, idx);
  const region = t.slice(idx + 1);
  if (provider === "aws") return `ec2.${region}.amazonaws.com`;
  if (provider === "gcp") return `storage.${region}.rep.googleapis.com`;
  return t;
}

function lookupAsync(name, family) {
  return new Promise((resolve, reject) => {
    dns.lookup(name, family ? { family } : {}, (err, address) => {
      if (err) reject(err);
      else resolve(address);
    });
  });
}

function dnsReason(err) {
  if (err && (err.code === "ENOTFOUND" || err.code === "EBADNAME")) return "Name or service not known";
  return "Temporary failure in name resolution";
}

function havePing() {
  try {
    execFileSync("sh", ["-lc", "command -v ping"], { stdio: "ignore" });
    return true;
  } catch (_) {
    return false;
  }
}

async function runPingMode(opts) {
  const family = opts.ipv4 ? 4 : opts.ipv6 ? 6 : 0;
  for (const raw of opts.targets) {
    const target = expandTarget(raw);
    if (!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(target) && target !== "localhost" && target !== "::1") {
      try {
        await lookupAsync(target, family);
      } catch (err) {
        die(`Error: Resolving ${target}\n\nCaused by:\n    failed to lookup address information: ${dnsReason(err)}`);
      }
    }
  }
  if (!havePing()) die("Error: Could not detect ping. Stderr: []\nStdout: []");
  if (!process.stdout.isTTY || !process.stdin.isTTY) die("Error: No such device or address (os error 6)");
  liveDisplay(opts.targets, opts);
}

function runOneCommand(command, cb) {
  const start = process.hrtime.bigint();
  const child = spawn(command, { shell: true, stdio: "ignore" });
  child.on("close", () => {
    const ms = Number(process.hrtime.bigint() - start) / 1e6;
    cb(ms);
  });
  child.on("error", () => cb(null));
}

function liveDisplay(labels, opts) {
  const interval = Math.max(20, Math.round((opts.watch ?? (opts.cmd ? 0.5 : 0.2)) * 1000));
  const samples = new Map(labels.map((l) => [l, []]));
  process.stdout.write("\x1b[?25l\x1b[2J");
  const draw = () => {
    process.stdout.write("\x1b[H");
    process.stdout.write("gping\n\n");
    for (const label of labels) {
      const arr = samples.get(label) || [];
      const last = arr.length ? arr[arr.length - 1] : null;
      const graph = arr.slice(-50).map((v) => v == null ? "x" : (opts.simple ? "." : "⣿")).join("");
      process.stdout.write(`${label.padEnd(24)} ${last == null ? "timeout" : last.toFixed(1) + " ms"} ${graph}\n`);
    }
  };
  const tick = () => {
    if (opts.cmd) {
      let pending = labels.length;
      for (const label of labels) {
        runOneCommand(label, (ms) => {
          samples.get(label).push(ms);
          if (--pending === 0) draw();
        });
      }
    } else {
      for (const label of labels) samples.get(label).push(null);
      draw();
    }
  };
  const timer = setInterval(tick, interval);
  const cleanup = () => {
    clearInterval(timer);
    if (opts.clear) process.stdout.write("\x1b[2J\x1b[H");
    process.stdout.write("\x1b[?25h");
    process.exit(0);
  };
  process.on("SIGINT", cleanup);
  process.on("SIGTERM", cleanup);
  tick();
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.targets.length === 0) {
    die("Error: At least one host or command must be given (i.e gping google.com). Use --help for a full list of arguments.");
  }
  if (opts.cmd) {
    if (!process.stdout.isTTY || !process.stdin.isTTY) die("Error: No such device or address (os error 6)");
    liveDisplay(opts.targets, opts);
  } else {
    await runPingMode(opts);
  }
}

main().catch((err) => die(`Error: ${err.message || err}`));
