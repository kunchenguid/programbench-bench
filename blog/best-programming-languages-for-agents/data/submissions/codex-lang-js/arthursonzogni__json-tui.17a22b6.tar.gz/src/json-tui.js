#!/usr/bin/env node
"use strict";

const fs = require("fs");

const RESET = "\x1b[39m\x1b[49m";
const BLUE = "\x1b[94m\x1b[49m";
const GREEN = "\x1b[92m\x1b[49m";
const CYAN = "\x1b[96m\x1b[49m";
const YELLOW = "\x1b[93m\x1b[49m";
const RED = "\x1b[91m\x1b[49m";
const BOLD = "\x1b[1m";
const NBOLD = "\x1b[22m";
const INV = "\x1b[7m";
const NINV = "\x1b[27m";

const HELP = `  json-tui {OPTIONS} [file]

    A JSON terminal UI

  OPTIONS:

      file                              A JSON file. Omit to read from stdin.
      -h, --help                        Display this help menu.
      -v, --version                     Print version.
      -k, --key, --keybinding           Display key binding.
      -f, --fullscreen                  Display the JSON in fullscreen, in an
                                        alternate buffer
      "--" can be used to terminate flag options and force all following
      arguments to be treated as positional options

    If no file is given, json-tui reads JSON from the standard input
    Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues
`;

const KEY_TABLE =
  "┌───────────┬────────────────┐\r\n" +
  `│\x1b[36m\x1b[49mkeys       ${RESET}│\x1b[36m\x1b[49maction          ${RESET}│\r\n` +
  "├───────────┼────────────────┤\r\n" +
  "│Navigate   │← ↑ ↓ →         │\r\n" +
  "│           │h j k l         │\r\n" +
  "│           │Mouse::WheelUp  │\r\n" +
  "│           │Mouse::WheelDown│\r\n" +
  "├───────────┼────────────────┤\r\n" +
  "│Toggle     │enter           │\r\n" +
  "│           │Mouse::Left     │\r\n" +
  "├───────────┼────────────────┤\r\n" +
  "│Deep       │                │\r\n" +
  "│ - Expand  │+               │\r\n" +
  "│ - Collapse│-               │\r\n" +
  "├───────────┼────────────────┤\r\n" +
  "│Exit       │Escape          │\r\n" +
  "│           │q               │\r\n" +
  "├───────────┼────────────────┤\r\n" +
  "│Navigate   │                │\r\n" +
  "│ - first   │page-up         │\r\n" +
  "│ - last    │page-down       │\r\n" +
  "│ - top     │gg              │\r\n" +
  "│ - bottom  │G               │\r\n" +
  "└───────────┴────────────────┘\x00\n";

function main() {
  const args = process.argv.slice(2);
  let file = null;
  let fullscreen = false;
  let positional = false;
  for (const arg of args) {
    if (!positional && arg === "--") {
      positional = true;
      continue;
    }
    if (!positional && (arg === "-h" || arg === "--help")) return write(HELP);
    if (!positional && (arg === "-v" || arg === "--version")) return write("1.4.1\n");
    if (!positional && (arg === "-k" || arg === "--key" || arg === "--keybinding")) return write(KEY_TABLE);
    if (!positional && (arg === "-f" || arg === "--fullscreen")) {
      fullscreen = true;
      continue;
    }
    if (!positional && arg !== "-" && arg.startsWith("-")) return fail("Invalid arguments");
    if (file !== null) return fail("Invalid arguments");
    file = arg;
  }

  let text;
  if (file === null) {
    process.stdout.write("Reading from stdin...");
    text = fs.readFileSync(0, "utf8");
  } else {
    try {
      text = fs.readFileSync(file, "utf8");
    } catch {
      return fail(`Could not open file ${file}`);
    }
  }

  let value;
  try {
    value = JSON.parse(text);
  } catch {
    process.stderr.write("\n" + parseError(text) + "\n");
    process.exitCode = 1;
    return;
  }

  runTui(value, fullscreen);
}

function write(s) {
  process.stdout.write(s);
}

function fail(s) {
  process.stderr.write(s + "\n");
  process.exitCode = 1;
}

function parseError(input) {
  if (input.length === 0) {
    return "[json.exception.parse_error.101] parse error at line 1, column 1: attempting to parse an empty input; check that your input string or stream contains the expected JSON";
  }
  const p = firstBadPosition(input);
  const loc = lineColumn(input, p.index);
  return `[json.exception.parse_error.101] parse error at line ${loc.line}, column ${loc.column}: ${p.message}`;
}

function firstBadPosition(s) {
  let i = 0;
  function skip() { while (/\s/.test(s[i] || "")) i++; }
  function bad(message, index = i) { return { message, index }; }
  function literal(word) {
    const start = i;
    let k = 0;
    for (; k < word.length && i < s.length && s[i] === word[k]; k++, i++);
    if (i - start !== word.length) {
      const end = Math.min(s.length, i + 1);
      return bad(`syntax error while parsing value - invalid literal; last read: '${s.slice(start, end)}'`, Math.max(i, start));
    }
    return null;
  }
  function value() {
    skip();
    if (i >= s.length) return bad("syntax error while parsing value - unexpected end of input; expected '[', '{', or a literal", Math.max(0, i));
    const ch = s[i];
    if (ch === "{") return object();
    if (ch === "[") return array();
    if (ch === "\"") return string();
    if (ch === "t") return literal("true");
    if (ch === "f") return literal("false");
    if (ch === "n") return literal("null");
    if (ch === "-" || /[0-9]/.test(ch)) return number();
    if (ch === "]") return bad("syntax error while parsing value - unexpected ']'; expected '[', '{', or a literal", i);
    if (ch === "}") return bad("syntax error while parsing value - unexpected '}'; expected '[', '{', or a literal", i);
    const start = i; i++;
    return bad(`syntax error while parsing value - invalid literal; last read: '${s.slice(start, i)}'`, start);
  }
  function string() {
    i++;
    while (i < s.length) {
      const ch = s[i++];
      if (ch === "\"") return null;
      if (ch === "\\") i++;
      else if (ch < " ") return bad("syntax error while parsing value - invalid string: control character must be escaped", i);
    }
    return bad("syntax error while parsing value - invalid string: missing closing quote", i);
  }
  function number() {
    const start = i;
    if (s[i] === "-") i++;
    while (/[0-9]/.test(s[i] || "")) i++;
    if (s[i] === ".") { i++; while (/[0-9]/.test(s[i] || "")) i++; }
    if (s[i] === "e" || s[i] === "E") { i++; if (s[i] === "+" || s[i] === "-") i++; while (/[0-9]/.test(s[i] || "")) i++; }
    if (i === start || (i === start + 1 && s[start] === "-")) return bad("syntax error while parsing value - invalid number", i);
    return null;
  }
  function object() {
    i++; skip();
    if (s[i] === "}") { i++; return null; }
    while (i < s.length) {
      skip();
      if (s[i] !== "\"") {
        const last = s.slice(Math.max(0, i - 1), Math.min(s.length, i + 1));
        return bad(`syntax error while parsing object key - invalid literal; last read: '${last}'; expected string literal`, i);
      }
      let e = string(); if (e) return e;
      skip(); if (s[i] !== ":") return bad("syntax error while parsing object separator - unexpected token; expected ':'", i);
      i++;
      e = value(); if (e) return e;
      skip();
      if (s[i] === "}") { i++; return null; }
      if (s[i] !== ",") return bad("syntax error while parsing object - unexpected token; expected ',' or '}'", i);
      i++; skip();
    }
    return bad("syntax error while parsing object - unexpected end of input; expected string literal", i);
  }
  function array() {
    i++; skip();
    if (s[i] === "]") { i++; return null; }
    while (i < s.length) {
      const e = value(); if (e) return e;
      skip();
      if (s[i] === "]") { i++; return null; }
      if (s[i] !== ",") return bad("syntax error while parsing array - unexpected token; expected ',' or ']'", i);
      i++; skip();
    }
    return bad("syntax error while parsing array - unexpected end of input; expected '[', '{', or a literal", i);
  }
  const e = value(); if (e) return e;
  skip();
  if (i < s.length) return bad("syntax error while parsing value - unexpected trailing token", i);
  return bad("syntax error while parsing value - invalid literal", 0);
}

function lineColumn(s, idx) {
  let line = 1, col = 1;
  for (let j = 0; j < idx; j++) {
    if (s[j] === "\n") { line++; col = 1; } else col++;
  }
  return { line, column: col };
}

function runTui(value, fullscreen) {
  const rows = render(value, 0, 0, true);
  const marked = rows.map((line, idx) => idx === 0 ? markFirst(line) : line);
  const termWidth = Math.min(Number(process.env.COLUMNS) || 80, 120);
  const maxWidth = Math.max(1, ...marked.map(visibleLen));
  const width = Math.min(termWidth, maxWidth);
  let out = "\x00\x1bP$q q\x1b\\";
  if (fullscreen) out += "\x1b[?1049h";
  out += "\x1b[?7l\x1b[?1000h\x1b[?1003h\x1b[?1015h\x1b[?1006h\x00";
  out += "\r" + marked.map((line, idx) => {
    const limited = visibleLen(line) > width ? truncateVisible(line, width) : line;
    return (idx === 0 ? "\x1b[2K" : "") + padVisible(limited, width) + (idx === marked.length - 1 ? "" : "\r");
  }).join("\n");
  const rootScalar = rows.length === 1 && !(value && typeof value === "object");
  const cursorRows = rootScalar ? -1 : rows.length - 1;
  const cursorCols = rootScalar ? 1 : (maxWidth >= termWidth ? width - 1 : width);
  out += `\x1b[${cursorRows}A\x1b[${cursorCols}D\x1b[?25l\x00`;
  process.stdout.write(out);

  const finish = () => {
    let end = `\x1b[${cursorRows}B\x1b[${cursorCols}C\x1b[?1006l\x1b[?1015l\x1b[?1003l\x1b[?1000l\x1b[?7h\x1b[?25h\x1b[1 q\x00\r\n`;
    if (fullscreen) end = "\x1b[?1049l" + end;
    process.stdout.write(end);
    process.exit(0);
  };
  if (!process.stdin.isTTY) {
    setInterval(() => {}, 1000);
    process.on("SIGTERM", finish);
    process.on("SIGINT", finish);
    return;
  }
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.on("data", (b) => {
    const s = b.toString("utf8");
    if (s === "q" || s === "\x1b" || s === "\x03") finish();
  });
}

function markFirst(line) {
  if (line.startsWith(BLUE) || line.startsWith(GREEN) || line.startsWith(CYAN) || line.startsWith(YELLOW) || line.startsWith(RED)) {
    return INV + line.replace(RESET, NINV + RESET);
  }
  if (line.startsWith(BOLD)) {
    const plain = line.replace(BOLD, "").replace(NBOLD, "");
    return INV + plain[0] + NINV + plain.slice(1);
  }
  return INV + line[0] + NINV + line.slice(1);
}

function render(v, depth, indent, root) {
  const sp = " ".repeat(indent);
  if (Array.isArray(v)) {
    if (!root && depth >= 1) return [BOLD + "[...]" + NBOLD];
    if (v.length === 0 && !root) return [BOLD + "[]" + NBOLD];
    if (v.length === 0) return [sp + "[", sp + "]"];
    const rows = [sp + "["];
    v.forEach((item, idx) => {
      const r = render(item, depth + 1, indent + 2, false);
      r.forEach((line, j) => rows.push(line + (j === r.length - 1 && idx !== v.length - 1 ? "," : "")));
    });
    rows.push(sp + "]");
    return rows;
  }
  if (v && typeof v === "object") {
    const keys = Object.keys(v).sort();
    if (!root && depth >= 2) return [BOLD + "{" + NBOLD];
    if (keys.length === 0 && !root) return [BOLD + "{}" + NBOLD];
    if (keys.length === 0) return [sp + "{", sp + "}"];
    const rows = [sp + (root ? "{" : BOLD + "{" + NBOLD)];
    keys.forEach((k, idx) => {
      const val = v[k];
      const rendered = render(val, depth + 1, indent + 2, false);
      const key = " ".repeat(indent + 2) + BLUE + JSON.stringify(k) + RESET + ": ";
      if (rendered.length === 1) {
        rows.push(key + addComma(rendered[0].trimStart(), idx !== keys.length - 1));
      } else {
        rows.push(key + rendered[0].trimStart());
        for (let i = 1; i < rendered.length; i++) rows.push(addComma(rendered[i], i === rendered.length - 1 && idx !== keys.length - 1));
      }
    });
    rows.push(sp + "}");
    return rows;
  }
  return [sp + primitive(v)];
}

function addComma(s, needed) {
  if (!needed) return s;
  return s.endsWith(NBOLD) ? s.slice(0, -NBOLD.length) + "," + NBOLD : s + ",";
}

function primitive(v) {
  if (typeof v === "string") return GREEN + JSON.stringify(v) + RESET;
  if (typeof v === "number") return CYAN + String(v) + RESET;
  if (typeof v === "boolean") return YELLOW + String(v) + RESET;
  if (v === null) return RED + "null" + RESET;
  return String(v);
}

function visibleLen(s) {
  return s.replace(/\x1b\[[0-9;?-]*[A-Za-z]/g, "").replace(/\x00/g, "").length;
}

function padVisible(s, width) {
  const len = visibleLen(s);
  return s + (len < width ? " ".repeat(width - len) : "");
}

function truncateVisible(s, width) {
  let out = "", len = 0;
  let truncated = false;
  for (let i = 0; i < s.length;) {
    if (s[i] === "\x1b") {
      const m = /^\x1b\[[0-9;?-]*[A-Za-z]/.exec(s.slice(i));
      if (m) { out += m[0]; i += m[0].length; continue; }
    }
    if (len >= width) { truncated = true; break; }
    out += s[i++];
    len++;
  }
  if (truncated && out.includes("\x1b[") && !out.endsWith(RESET) && !out.endsWith(NBOLD) && !out.endsWith(NINV)) out += RESET;
  return out;
}

main();
