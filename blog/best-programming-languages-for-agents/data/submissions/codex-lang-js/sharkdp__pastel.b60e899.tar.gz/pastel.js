#!/usr/bin/env node
'use strict';

const fs = require('fs');

const CSS = {
  aliceblue:'#f0f8ff', antiquewhite:'#faebd7', aqua:'#00ffff', aquamarine:'#7fffd4', azure:'#f0ffff',
  beige:'#f5f5dc', bisque:'#ffe4c4', black:'#000000', blanchedalmond:'#ffebcd', blue:'#0000ff',
  blueviolet:'#8a2be2', brown:'#a52a2a', burlywood:'#deb887', cadetblue:'#5f9ea0', chartreuse:'#7fff00',
  chocolate:'#d2691e', coral:'#ff7f50', cornflowerblue:'#6495ed', cornsilk:'#fff8dc', crimson:'#dc143c',
  cyan:'#00ffff', darkblue:'#00008b', darkcyan:'#008b8b', darkgoldenrod:'#b8860b', darkgray:'#a9a9a9',
  darkgreen:'#006400', darkgrey:'#a9a9a9', darkkhaki:'#bdb76b', darkmagenta:'#8b008b',
  darkolivegreen:'#556b2f', darkorange:'#ff8c00', darkorchid:'#9932cc', darkred:'#8b0000',
  darksalmon:'#e9967a', darkseagreen:'#8fbc8f', darkslateblue:'#483d8b', darkslategray:'#2f4f4f',
  darkslategrey:'#2f4f4f', darkturquoise:'#00ced1', darkviolet:'#9400d3', deeppink:'#ff1493',
  deepskyblue:'#00bfff', dimgray:'#696969', dimgrey:'#696969', dodgerblue:'#1e90ff',
  firebrick:'#b22222', floralwhite:'#fffaf0', forestgreen:'#228b22', fuchsia:'#ff00ff',
  gainsboro:'#dcdcdc', ghostwhite:'#f8f8ff', gold:'#ffd700', goldenrod:'#daa520', gray:'#808080',
  green:'#008000', greenyellow:'#adff2f', grey:'#808080', honeydew:'#f0fff0', hotpink:'#ff69b4',
  indianred:'#cd5c5c', indigo:'#4b0082', ivory:'#fffff0', khaki:'#f0e68c', lavender:'#e6e6fa',
  lavenderblush:'#fff0f5', lawngreen:'#7cfc00', lemonchiffon:'#fffacd', lightblue:'#add8e6',
  lightcoral:'#f08080', lightcyan:'#e0ffff', lightgoldenrodyellow:'#fafad2', lightgray:'#d3d3d3',
  lightgreen:'#90ee90', lightgrey:'#d3d3d3', lightpink:'#ffb6c1', lightsalmon:'#ffa07a',
  lightseagreen:'#20b2aa', lightskyblue:'#87cefa', lightslategray:'#778899',
  lightslategrey:'#778899', lightsteelblue:'#b0c4de', lightyellow:'#ffffe0', lime:'#00ff00',
  limegreen:'#32cd32', linen:'#faf0e6', magenta:'#ff00ff', maroon:'#800000',
  mediumaquamarine:'#66cdaa', mediumblue:'#0000cd', mediumorchid:'#ba55d3',
  mediumpurple:'#9370db', mediumseagreen:'#3cb371', mediumslateblue:'#7b68ee',
  mediumspringgreen:'#00fa9a', mediumturquoise:'#48d1cc', mediumvioletred:'#c71585',
  midnightblue:'#191970', mintcream:'#f5fffa', mistyrose:'#ffe4e1', moccasin:'#ffe4b5',
  navajowhite:'#ffdead', navy:'#000080', oldlace:'#fdf5e6', olive:'#808000', olivedrab:'#6b8e23',
  orange:'#ffa500', orangered:'#ff4500', orchid:'#da70d6', palegoldenrod:'#eee8aa',
  palegreen:'#98fb98', paleturquoise:'#afeeee', palevioletred:'#db7093', papayawhip:'#ffefd5',
  peachpuff:'#ffdab9', peru:'#cd853f', pink:'#ffc0cb', plum:'#dda0dd', powderblue:'#b0e0e6',
  purple:'#800080', rebeccapurple:'#663399', red:'#ff0000', rosybrown:'#bc8f8f',
  royalblue:'#4169e1', saddlebrown:'#8b4513', salmon:'#fa8072', sandybrown:'#f4a460',
  seagreen:'#2e8b57', seashell:'#fff5ee', sienna:'#a0522d', silver:'#c0c0c0',
  skyblue:'#87ceeb', slateblue:'#6a5acd', slategray:'#708090', slategrey:'#708090',
  snow:'#fffafa', springgreen:'#00ff7f', steelblue:'#4682b4', tan:'#d2b48c', teal:'#008080',
  thistle:'#d8bfd8', tomato:'#ff6347', turquoise:'#40e0d0', violet:'#ee82ee',
  wheat:'#f5deb3', white:'#ffffff', whitesmoke:'#f5f5f5', yellow:'#ffff00', yellowgreen:'#9acd32',
  transparent:'#00000000'
};
const nameByHex = {};
for (const [k,v] of Object.entries(CSS)) if (!(v in nameByHex) || !['aqua','fuchsia','gray','cyan','magenta','grey'].includes(k)) nameByHex[v] = k;
nameByHex['#00ffff']='cyan'; nameByHex['#ff00ff']='fuchsia'; nameByHex['#808080']='gray';

function clamp(x,a=0,b=1){ return Math.min(b, Math.max(a, x)); }
function mod(n,m){ return ((n % m)+m)%m; }
function byte(x){ return Math.round(clamp(x)*255); }
function hex2(n){ return Math.round(clamp(n,0,255)).toString(16).padStart(2,'0'); }
function fmt(x,d){ return Number(x).toFixed(d); }
function pct1(x){ return (x*100).toFixed(1)+'%'; }
function readStdin(){ try { return fs.readFileSync(0,'utf8'); } catch { return ''; } }
function splitInput(s){ return s.split(/\r?\n/).map(x=>x.trim()).filter(x=>x.length); }

function color(r,g,b,a=1){ return {r:clamp(r), g:clamp(g), b:clamp(b), a:clamp(a)}; }

function parseNumber(s, percentScale=1) {
  s = String(s).trim();
  if (s.endsWith('%')) return parseFloat(s)/100*percentScale;
  return parseFloat(s);
}
function parseColor(input) {
  let s = String(input ?? '').trim();
  if (s === '-') {
    const xs = splitInput(readStdin());
    if (!xs.length) throw new Error("Could not parse color ''");
    return parseColor(xs[0]);
  }
  const low = s.toLowerCase().replace(/\s+/g,'');
  if (CSS[low]) return parseHex(CSS[low]);
  let m = low.match(/^#?([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/i);
  if (m) return parseHex('#'+m[1]);
  m = s.match(/^rgba?\((.*)\)$/i);
  if (m) {
    const p = m[1].split(/\s*,\s*/);
    if (p.length !== 3 && p.length !== 4) throw new Error(`Could not parse color '${input}'`);
    return color(parseNumber(p[0],255)/255, parseNumber(p[1],255)/255, parseNumber(p[2],255)/255, p[3] == null ? 1 : parseNumber(p[3],1));
  }
  m = s.match(/^hsla?\((.*)\)$/i);
  if (m) {
    const p = m[1].split(/\s*,\s*/);
    if (p.length !== 3 && p.length !== 4) throw new Error(`Could not parse color '${input}'`);
    const c = hslToRgb(parseFloat(p[0]), parseNumber(p[1]), parseNumber(p[2]));
    c.a = p[3] == null ? 1 : parseNumber(p[3],1);
    return c;
  }
  m = s.match(/^gray\((.*)\)$/i);
  if (m) {
    const v = parseNumber(m[1],1);
    return color(v,v,v,1);
  }
  if (/^-?\d/.test(s) && s.includes(',')) {
    const p = s.split(/\s*,\s*/);
    if (p.length === 3 || p.length === 4) return color(parseNumber(p[0],255)/255, parseNumber(p[1],255)/255, parseNumber(p[2],255)/255, p[3] == null ? 1 : parseNumber(p[3],1));
  }
  throw new Error(`Could not parse color '${input}'`);
}
function parseHex(h) {
  h = h.replace('#','');
  if (h.length === 3 || h.length === 4) h = h.split('').map(ch=>ch+ch).join('');
  const r = parseInt(h.slice(0,2),16), g = parseInt(h.slice(2,4),16), b = parseInt(h.slice(4,6),16);
  const a = h.length === 8 ? parseInt(h.slice(6,8),16)/255 : 1;
  return color(r/255,g/255,b/255,a);
}
function toHex(c, alpha=true) {
  const base = '#'+hex2(c.r*255)+hex2(c.g*255)+hex2(c.b*255);
  return alpha && c.a < 0.9995 ? base+hex2(c.a*255) : base;
}
function rgbToHsl(c) {
  const r=c.r,g=c.g,b=c.b, max=Math.max(r,g,b), min=Math.min(r,g,b);
  let h=0,s=0,l=(max+min)/2;
  if (max!==min) {
    const d=max-min;
    s = l > 0.5 ? d/(2-max-min) : d/(max+min);
    if (max===r) h=(g-b)/d + (g<b?6:0);
    else if (max===g) h=(b-r)/d+2;
    else h=(r-g)/d+4;
    h*=60;
  }
  return {h:mod(h,360), s, l};
}
function hslToRgb(h,s,l,a=1) {
  h = mod(h,360)/360; s=clamp(s); l=clamp(l);
  if (s === 0) return color(l,l,l,a);
  const hue2rgb=(p,q,t)=>{ if(t<0)t+=1; if(t>1)t-=1; if(t<1/6)return p+(q-p)*6*t; if(t<1/2)return q; if(t<2/3)return p+(q-p)*(2/3-t)*6; return p; };
  const q = l < 0.5 ? l*(1+s) : l+s-l*s, p = 2*l-q;
  return color(hue2rgb(p,q,h+1/3), hue2rgb(p,q,h), hue2rgb(p,q,h-1/3), a);
}
function rgbToHsv(c) {
  const r=c.r,g=c.g,b=c.b,max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min;
  let h=0; if(d){ if(max===r)h=(g-b)/d+(g<b?6:0); else if(max===g)h=(b-r)/d+2; else h=(r-g)/d+4; h*=60; }
  return {h:mod(h,360), s:max?d/max:0, v:max};
}
function luminance(c) {
  const lin = x => x <= 0.03928 ? x/12.92 : Math.pow((x+0.055)/1.055, 2.4);
  return 0.2126*lin(c.r)+0.7152*lin(c.g)+0.0722*lin(c.b);
}
function brightness(c){ return 0.299*c.r+0.587*c.g+0.114*c.b; }

function rgbToXyz(c) {
  const f=x=>x<=0.04045?x/12.92:Math.pow((x+0.055)/1.055,2.4);
  const r=f(c.r),g=f(c.g),b=f(c.b);
  return {x:(0.4124564*r+0.3575761*g+0.1804375*b)*100, y:(0.2126729*r+0.7151522*g+0.0721750*b)*100, z:(0.0193339*r+0.1191920*g+0.9503041*b)*100};
}
function xyzToRgb(x,y,z,a=1) {
  x/=100; y/=100; z/=100;
  let r= 3.2404542*x-1.5371385*y-0.4985314*z, g=-0.9692660*x+1.8760108*y+0.0415560*z, b=0.0556434*x-0.2040259*y+1.0572252*z;
  const f=v=>v<=0.0031308?12.92*v:1.055*Math.pow(Math.max(0,v),1/2.4)-0.055;
  return color(f(r),f(g),f(b),a);
}
function rgbToLab(c) {
  const xyz=rgbToXyz(c), Xn=95.047, Yn=100, Zn=108.883;
  const f=t=>{ t/=1; return t>0.008856?Math.cbrt(t):(7.787*t+16/116); };
  const fx=f(xyz.x/Xn), fy=f(xyz.y/Yn), fz=f(xyz.z/Zn);
  return {L:116*fy-16, a:500*(fx-fy), b:200*(fy-fz)};
}
function labToRgb(L,a,b,alpha=1) {
  const Xn=95.047, Yn=100, Zn=108.883;
  const fy=(L+16)/116, fx=a/500+fy, fz=fy-b/200;
  const finv=t=>{ const t3=t*t*t; return t3>0.008856?t3:(t-16/116)/7.787; };
  return xyzToRgb(Xn*finv(fx), Yn*finv(fy), Zn*finv(fz), alpha);
}
function rgbToLch(c){ const l=rgbToLab(c); const C=Math.hypot(l.a,l.b); return {L:l.L, C, h:mod(Math.atan2(l.b,l.a)*180/Math.PI,360)}; }
function lchToRgb(L,C,h,a=1){ return labToRgb(L, C*Math.cos(h*Math.PI/180), C*Math.sin(h*Math.PI/180), a); }
function rgbToOkLab(c) {
  const f=x=>x<=0.04045?x/12.92:Math.pow((x+0.055)/1.055,2.4);
  const r=f(c.r),g=f(c.g),b=f(c.b);
  const l=Math.cbrt(0.4122214708*r+0.5363325363*g+0.0514459929*b);
  const m=Math.cbrt(0.2119034982*r+0.6806995451*g+0.1073969566*b);
  const s=Math.cbrt(0.0883024619*r+0.2817188376*g+0.6299787005*b);
  return {L:0.2104542553*l+0.7936177850*m-0.0040720468*s, a:1.9779984951*l-2.4285922050*m+0.4505937099*s, b:0.0259040371*l+0.7827717662*m-0.8086757660*s};
}
function okLabToRgb(L,A,B,alpha=1) {
  const l=Math.pow(L+0.3963377774*A+0.2158037573*B,3);
  const m=Math.pow(L-0.1055613458*A-0.0638541728*B,3);
  const s=Math.pow(L-0.0894841775*A-1.2914855480*B,3);
  let r= 4.0767416621*l-3.3077115913*m+0.2309699292*s;
  let g=-1.2684380046*l+2.6097574011*m-0.3413193965*s;
  let b=-0.0041960863*l-0.7034186147*m+1.7076147010*s;
  const enc=x=>x<=0.0031308?12.92*x:1.055*Math.pow(Math.max(0,x),1/2.4)-0.055;
  return color(enc(r),enc(g),enc(b),alpha);
}
function rgbToOkLch(c){ const o=rgbToOkLab(c); return {L:o.L, C:Math.hypot(o.a,o.b), h:mod(Math.atan2(o.b,o.a)*180/Math.PI,360)}; }

function ansi8(c) {
  const r=Math.round(c.r*255),g=Math.round(c.g*255),b=Math.round(c.b*255);
  if (r===g && g===b) {
    if (r < 8) return 16;
    if (r > 248) return 231;
    return Math.round(((r-8)/247)*24)+232;
  }
  return 16 + 36*Math.round(r/255*5) + 6*Math.round(g/255*5) + Math.round(b/255*5);
}
function hslCompact(c){
  const h=rgbToHsl(c);
  const body = `${Math.round(h.h)},${pct1(h.s)},${pct1(h.l)}`;
  return c.a < 0.9995 ? `hsla(${body},${Number(c.a.toFixed(3))})` : `hsl(${body})`;
}
function formatColor(type,c) {
  const r=Math.round(c.r*255), g=Math.round(c.g*255), b=Math.round(c.b*255);
  const alpha = c.a < 0.9995;
  if (type==='hex') return toHex(c);
  if (type==='rgb') return alpha ? `rgba(${r}, ${g}, ${b}, ${fmt(c.a,3)})` : `rgb(${r}, ${g}, ${b})`;
  if (type==='rgb-float') return alpha ? `rgba(${fmt(c.r,3)}, ${fmt(c.g,3)}, ${fmt(c.b,3)}, ${fmt(c.a,3)})` : `rgb(${fmt(c.r,3)}, ${fmt(c.g,3)}, ${fmt(c.b,3)})`;
  if (type==='rgb-r') return fmt(c.r,4); if (type==='rgb-g') return fmt(c.g,4); if (type==='rgb-b') return fmt(c.b,4);
  const hsl=rgbToHsl(c), hsv=rgbToHsv(c), lab=rgbToLab(c), lch=rgbToLch(c), ok=rgbToOkLab(c), okl=rgbToOkLch(c);
  if (type==='hsl') return alpha ? `hsla(${Math.round(hsl.h)}, ${pct1(hsl.s)}, ${pct1(hsl.l)}, ${fmt(c.a,3)})` : `hsl(${Math.round(hsl.h)}, ${pct1(hsl.s)}, ${pct1(hsl.l)})`;
  if (type==='hsl-hue') return String(Math.round(hsl.h)); if(type==='hsl-saturation')return fmt(hsl.s,4); if(type==='hsl-lightness')return fmt(hsl.l,4);
  if (type==='hsv') return alpha ? `hsva(${Math.round(hsv.h)}, ${pct1(hsv.s)}, ${pct1(hsv.v)}, ${fmt(c.a,3)})` : `hsv(${Math.round(hsv.h)}, ${pct1(hsv.s)}, ${pct1(hsv.v)})`;
  if (type==='hsv-hue') return String(Math.round(hsv.h)); if(type==='hsv-saturation')return fmt(hsv.s,4); if(type==='hsv-value')return fmt(hsv.v,4);
  if (type==='luminance') return fmt(luminance(c),3); if (type==='brightness') return fmt(brightness(c),3);
  if (type==='lab') return alpha ? `Lab(${Math.round(lab.L)}, ${Math.round(lab.a)}, ${Math.round(lab.b)}, ${fmt(c.a,3)})` : `Lab(${Math.round(lab.L)}, ${Math.round(lab.a)}, ${Math.round(lab.b)})`;
  if (type==='lab-a') return fmt(lab.a,2); if(type==='lab-b') return fmt(lab.b,2);
  if (type==='lch') return alpha ? `LCh(${Math.round(lch.L)}, ${Math.round(lch.C)}, ${Math.round(lch.h)}, ${fmt(c.a,3)})` : `LCh(${Math.round(lch.L)}, ${Math.round(lch.C)}, ${Math.round(lch.h)})`;
  if (type==='lch-lightness')return fmt(lch.L,2); if(type==='lch-chroma')return fmt(lch.C,2); if(type==='lch-hue')return fmt(lch.h,2);
  if (type==='oklab') return alpha ? `OkLab(${fmt(ok.L,4)}, ${fmt(ok.a,4)}, ${fmt(ok.b,4)}, ${fmt(c.a,3)})` : `OkLab(${fmt(ok.L,4)}, ${fmt(ok.a,4)}, ${fmt(ok.b,4)})`;
  if (type==='oklab-l')return fmt(ok.L,4); if(type==='oklab-a')return fmt(ok.a,4); if(type==='oklab-b')return fmt(ok.b,4);
  if (type==='oklch') return alpha ? `OkLCh(${fmt(okl.L,4)}, ${fmt(okl.C,4)}, ${fmt(okl.h,4)}, ${fmt(c.a,3)})` : `OkLCh(${fmt(okl.L,4)}, ${fmt(okl.C,4)}, ${fmt(okl.h,4)})`;
  if (type==='oklch-lightness')return fmt(okl.L,4); if(type==='oklch-chroma')return fmt(okl.C,4); if(type==='oklch-hue')return fmt(okl.h,4);
  if (type==='cmyk') { const k=1-Math.max(c.r,c.g,c.b); const C=k>=1?0:(1-c.r-k)/(1-k), M=k>=1?0:(1-c.g-k)/(1-k), Y=k>=1?0:(1-c.b-k)/(1-k); return `cmyk(${Math.round(C*100)}, ${Math.round(M*100)}, ${Math.round(Y*100)}, ${Math.round(k*100)})`; }
  if (type==='ansi-8bit') return `\\x1b[38;5;${ansi8(c)}m`; if(type==='ansi-24bit') return `\\x1b[38;2;${r};${g};${b}m`;
  if (type==='ansi-8bit-value') return String(ansi8(c));
  if (type==='ansi-8bit-escapecode') return `\x1b[38;5;${ansi8(c)}m`; if(type==='ansi-24bit-escapecode') return `\x1b[38;2;${r};${g};${b}m`;
  if (type==='name') return nameByHex[toHex(c,false)] || toHex(c);
  return toHex(c);
}

const formatTypes = new Set('rgb rgb-float rgb-r rgb-g rgb-b hex hsl hsl-hue hsl-saturation hsl-lightness hsv hsv-hue hsv-saturation hsv-value lch lch-lightness lch-chroma lch-hue oklch oklch-lightness oklch-chroma oklch-hue lab lab-a lab-b oklab oklab-l oklab-a oklab-b luminance brightness ansi-8bit ansi-24bit ansi-8bit-value ansi-8bit-escapecode ansi-24bit-escapecode cmyk name'.split(' '));

function colorArgs(args, start=0, min=0) {
  const rest=args.slice(start);
  if (rest.length) return rest;
  const xs=splitInput(readStdin());
  if (xs.length) return xs;
  if (min) throw new Error('missing color');
  return [];
}
function eachColor(inputs, fn) {
  const out=[];
  for (const s of inputs) out.push(fn(parseColor(s), s));
  return out;
}
function printLines(lines){ if(lines.length) process.stdout.write(lines.join('\n')+'\n'); }
function die(msg, code=1){ process.stderr.write(`[pastel error]: ${msg}\n`); process.exit(code); }

function interp(a,b,t,space) {
  if (space.toLowerCase()==='rgb') return color(Math.round((a.r+(b.r-a.r)*t)*255)/255,Math.round((a.g+(b.g-a.g)*t)*255)/255,Math.round((a.b+(b.b-a.b)*t)*255)/255,a.a+(b.a-a.a)*t);
  if (space.toLowerCase()==='hsl') {
    const x=rgbToHsl(a), y=rgbToHsl(b); let dh=((y.h-x.h+540)%360)-180;
    return hslToRgb(x.h+dh*t, x.s+(y.s-x.s)*t, x.l+(y.l-x.l)*t, a.a+(b.a-a.a)*t);
  }
  if (space.toLowerCase()==='lch') {
    const x=rgbToLch(a), y=rgbToLch(b); let dh=((y.h-x.h+540)%360)-180;
    return lchToRgb(x.L+(y.L-x.L)*t, x.C+(y.C-x.C)*t, x.h+dh*t, a.a+(b.a-a.a)*t);
  }
  if (space.toLowerCase()==='oklab') {
    const x=rgbToOkLab(a), y=rgbToOkLab(b);
    return okLabToRgb(x.L+(y.L-x.L)*t, x.a+(y.a-x.a)*t, x.b+(y.b-x.b)*t, a.a+(b.a-a.a)*t);
  }
  const x=rgbToLab(a), y=rgbToLab(b);
  return labToRgb(x.L+(y.L-x.L)*t, x.a+(y.a-x.a)*t, x.b+(y.b-x.b)*t, a.a+(b.a-a.a)*t);
}

function transformHsl(inputs, mutate) {
  return eachColor(inputs, c => { const h=rgbToHsl(c); const n=mutate(h,c); return `hsl(${Math.round(mod(n.h,360))},${pct1(clamp(n.s))},${pct1(clamp(n.l))})`; });
}
function usage(){ console.log(`A command-line tool to generate, analyze, convert and manipulate colors

Usage: executable [OPTIONS] <COMMAND>

Commands:
  color colorblind colorcheck complement darken desaturate distinct format gradient gray help lighten list mix paint pick random rotate saturate set sort-by textcolor to-gray

Options:
  -h, --help     Print help
  -V, --version  Print version`); }
function subhelp(cmd){ console.log(`Usage: executable ${cmd} [OPTIONS] [color]...\n\nRun color manipulation commands and print colors. Colors may be names, hex, rgb(...), hsl(...), gray(...), or comma-separated RGB values.`); }

function main() {
  let args=process.argv.slice(2).filter(a=>!['--force-color','-f'].includes(a) && !a.startsWith('--color-mode') && !a.startsWith('-m'));
  if (!args.length || args[0]==='--help' || args[0]==='-h') return usage();
  if (args[0]==='--version' || args[0]==='-V') return console.log('pastel 0.11.0');
  if (args[0]==='help') return args[1] ? subhelp(args[1]) : usage();
  const cmd=args.shift();
  try {
    if (cmd==='format') {
      let type='hex'; if (args[0] && formatTypes.has(args[0])) type=args.shift();
      printLines(eachColor(colorArgs(args,0), c => formatColor(type,c))); return;
    }
    if (cmd==='color') { printLines(eachColor(colorArgs(args,0), c => `${toHex(c)}\n  RGB: ${formatColor('rgb',c)}\n  HSL: ${formatColor('hsl',c)}\n  Luminance: ${formatColor('luminance',c)}`)); return; }
    if (cmd==='lighten'||cmd==='darken'||cmd==='saturate'||cmd==='desaturate') {
      const amt=parseFloat(args.shift()); const sign=(cmd==='darken'||cmd==='desaturate')?-1:1;
      printLines(transformHsl(colorArgs(args,0), h => cmd.includes('saturate') ? {...h,s:h.s+sign*amt} : {...h,l:h.l+sign*amt})); return;
    }
    if (cmd==='rotate'||cmd==='complement') {
      const deg=cmd==='complement'?180:parseFloat(args.shift());
      printLines(transformHsl(colorArgs(args,0), h => ({...h,h:h.h+deg}))); return;
    }
    if (cmd==='to-gray') {
      const inv = Y => {
        Y = clamp(Y);
        return Y <= 0.0031308 ? Y*12.92 : 1.055*Math.pow(Y,1/2.4)-0.055;
      };
      printLines(eachColor(colorArgs(args,0), c => {
        const h = rgbToHsl(c).h, l = inv(luminance(c));
        return c.a < 0.9995 ? `hsla(${Math.round(h)},0.0%,${pct1(l)},${Number(c.a.toFixed(3))})` : `hsl(${Math.round(h)},0.0%,${pct1(l)})`;
      })); return;
    }
    if (cmd==='textcolor') {
      printLines(eachColor(colorArgs(args,0), c => hslCompact(luminance(c) > 0.179 ? color(0,0,0) : color(1,1,1)))); return;
    }
    if (cmd==='gray') { const v=clamp(parseFloat(args[0])); return console.log(hslCompact(color(v,v,v))); }
    if (cmd==='gradient') {
      let n=10, space='Lab', rest=[];
      for(let i=0;i<args.length;i++){ const a=args[i]; if((a==='-n'||a==='--number')&&args[i+1]) n=parseInt(args[++i]); else if(a.startsWith('--number=')) n=parseInt(a.split('=')[1]); else if((a==='-s'||a==='--colorspace')&&args[i+1]) space=args[++i]; else if(a.startsWith('--colorspace=')) space=a.split('=')[1]; else rest.push(a); }
      const stops=rest.map(parseColor); const out=[];
      for(let i=0;i<n;i++){ const pos=n===1?0:i/(n-1), seg=Math.min(stops.length-2, Math.floor(pos*(stops.length-1))), local=pos*(stops.length-1)-seg; out.push(hslCompact(interp(stops[seg],stops[seg+1],local,space))); }
      printLines(out); return;
    }
    if (cmd==='mix') {
      let frac=0.5, space='Lab', rest=[];
      for(let i=0;i<args.length;i++){ const a=args[i]; if((a==='-f'||a==='--fraction')&&args[i+1]) frac=parseFloat(args[++i]); else if(a.startsWith('--fraction=')) frac=parseFloat(a.split('=')[1]); else if((a==='-s'||a==='--colorspace')&&args[i+1]) space=args[++i]; else if(a.startsWith('--colorspace=')) space=a.split('=')[1]; else rest.push(a); }
      const base=parseColor(rest.shift()); const others=rest.length?rest:splitInput(readStdin()); printLines(others.map(x=>hslCompact(interp(parseColor(x),base,frac,space)))); return;
    }
    if (cmd==='set') {
      const prop=args.shift(), val=parseFloat(args.shift());
      printLines(eachColor(colorArgs(args,0), c => {
        if(['red','green','blue','alpha'].includes(prop)){ let n={...c}; if(prop==='red')n.r=val/255; if(prop==='green')n.g=val/255; if(prop==='blue')n.b=val/255; if(prop==='alpha')n.a=val; return hslCompact(n); }
        const h=rgbToHsl(c); if(prop.includes('hue'))h.h=val; if(prop.includes('saturation'))h.s=val; if(prop.includes('lightness')||prop==='lightness')h.l=val; return hslCompact(hslToRgb(h.h,h.s,h.l,c.a));
      })); return;
    }
    if (cmd==='sort-by') {
      let reverse=false, unique=false, order='hue', rest=[];
      for(const a of args){ if(a==='-r'||a==='--reverse') reverse=true; else if(a==='-u'||a==='--unique') unique=true; else if(['brightness','luminance','hue','chroma','random'].includes(a)&&order==='hue') order=a; else rest.push(a); }
      let arr=colorArgs(rest,0).map(s=>parseColor(s)); if(unique){ const seen=new Set(); arr=arr.filter(c=>{const h=toHex(c); if(seen.has(h))return false; seen.add(h); return true;}); }
      const key=c=>order==='brightness'?brightness(c):order==='luminance'?luminance(c):order==='chroma'?rgbToLch(c).C:order==='random'?Math.random():rgbToHsl(c).h;
      arr.sort((a,b)=>key(a)-key(b)); if(reverse)arr.reverse(); printLines(arr.map(toHex)); return;
    }
    if (cmd==='list') { let names=Object.keys(CSS).filter(n=>n!=='transparent'&&!n.endsWith('grey')); names.sort((a,b)=>rgbToHsl(parseColor(a)).h-rgbToHsl(parseColor(b)).h); printLines(names); return; }
    if (cmd==='paint') {
      let bg=null,bold=false,italic=false,underline=false,nl=true, rest=[];
      for(let i=0;i<args.length;i++){ const a=args[i]; if((a==='-o'||a==='--on')&&args[i+1]) bg=args[++i]; else if(a==='-b'||a==='--bold')bold=true; else if(a==='-i'||a==='--italic')italic=true; else if(a==='-u'||a==='--underline')underline=true; else if(a==='-n'||a==='--no-newline')nl=false; else rest.push(a); }
      const fg=parseColor(rest.shift()); const text=rest.length?rest.join(' '):readStdin().replace(/\n$/,''); const codes=[]; if(bold)codes.push(1); if(italic)codes.push(3); if(underline)codes.push(4); codes.push(`38;2;${byte(fg.r)};${byte(fg.g)};${byte(fg.b)}`); if(bg){const c=parseColor(bg); codes.push(`48;2;${byte(c.r)};${byte(c.g)};${byte(c.b)}`);} process.stdout.write(`\x1b[${codes.join(';')}m${text}\x1b[0m${nl?'\n':''}`); return;
    }
    if (cmd==='random'||cmd==='distinct') {
      let n= cmd==='distinct' ? (parseInt(args[0])||10) : 10; for(let i=0;i<args.length;i++){ if((args[i]==='-n'||args[i]==='--number')&&args[i+1]) n=parseInt(args[i+1]); else if(args[i].startsWith('--number=')) n=parseInt(args[i].split('=')[1]); }
      const out=[]; for(let i=0;i<n;i++){ const hue=(i*137.508+Math.random()*20)%360; out.push(toHex(hslToRgb(hue,0.55+0.35*Math.random(),0.35+0.35*Math.random()))); } printLines(out); return;
    }
    if (cmd==='colorblind') {
      const type=args.shift();
      const matrices = {
        prot: [[0.56667,0.43333,0],[0.55833,0.44167,0],[0,0.24167,0.75833]],
        deuter: [[0.625,0.375,0],[0.70,0.30,0],[0,0.30,0.70]],
        trit: [[0.95,0.05,0],[0,0.43333,0.56667],[0,0.475,0.525]]
      };
      const m=matrices[type] || matrices.deuter;
      printLines(eachColor(colorArgs(args,0), c => {
        const n=color(m[0][0]*c.r+m[0][1]*c.g+m[0][2]*c.b, m[1][0]*c.r+m[1][1]*c.g+m[1][2]*c.b, m[2][0]*c.r+m[2][1]*c.g+m[2][2]*c.b, c.a);
        return hslCompact(n);
      })); return;
    }
    if (cmd==='colorcheck') { console.log('If you see smooth color gradients below, your terminal supports 24-bit colors.'); return; }
    if (cmd==='pick') { die('No color picker found'); }
    process.stderr.write(`error: unrecognized subcommand '${cmd}'\n\nUsage: executable [OPTIONS] <COMMAND>\n`); process.exit(2);
  } catch(e) {
    die(e.message || String(e));
  }
}
main();
