#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const VERSION = '1.14.0.git';

function die(msg, code = 1) {
  console.error(`ninja: error: ${msg}`);
  process.exit(code);
}

function warn(msg) {
  console.error(`ninja: warning: ${msg}`);
}

function statMtime(p) {
  try {
    return fs.statSync(p).mtimeMs;
  } catch {
    return 0;
  }
}

function exists(p) {
  try {
    fs.accessSync(p);
    return true;
  } catch {
    return false;
  }
}

function shellQuote(s) {
  if (s === '') return "''";
  if (/^[A-Za-z0-9_@%+=:,./-]+$/.test(s)) return s;
  return "'" + s.replace(/'/g, "'\\''") + "'";
}

class Scope {
  constructor(parent = null) {
    this.parent = parent;
    this.vars = new Map();
    this.rules = new Map();
  }
  getVar(name) {
    if (this.vars.has(name)) return this.vars.get(name);
    if (this.parent) return this.parent.getVar(name);
    return '';
  }
  getRule(name) {
    if (this.rules.has(name)) return this.rules.get(name);
    if (this.parent) return this.parent.getRule(name);
    return null;
  }
  setVar(k, v) { this.vars.set(k, v); }
  setRule(k, v) { this.rules.set(k, v); }
}

function stripComment(line) {
  for (let i = 0; i < line.length; i++) {
    if (line[i] === '#') {
      let dollars = 0;
      for (let j = i - 1; j >= 0 && line[j] === '$'; j--) dollars++;
      if (dollars % 2 === 0) return line.slice(0, i);
    }
  }
  return line;
}

function joinContinuations(text) {
  text = text.replace(/\r\n/g, '\n');
  let out = '';
  for (let i = 0; i < text.length; i++) {
    if (text[i] === '$' && text[i + 1] === '\n') {
      i += 2;
      while (i < text.length && (text[i] === ' ' || text[i] === '\t')) i++;
      i--;
      continue;
    }
    out += text[i];
  }
  return out;
}

function expand(str, scope, edge = null, forCommand = false) {
  let out = '';
  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    if (ch !== '$') {
      out += ch;
      continue;
    }
    if (i + 1 >= str.length) {
      out += '$';
      continue;
    }
    const n = str[++i];
    if (n === '$') out += '$';
    else if (n === ' ') out += ' ';
    else if (n === ':') out += ':';
    else if (n === '^') out += '\n';
    else if (n === '{') {
      const end = str.indexOf('}', i + 1);
      if (end < 0) {
        out += '${';
      } else {
        const name = str.slice(i + 1, end);
        out += lookup(name, scope, edge, forCommand);
        i = end;
      }
    } else if (/[A-Za-z0-9_.-]/.test(n)) {
      let name = n;
      while (i + 1 < str.length && /[A-Za-z0-9_.-]/.test(str[i + 1])) name += str[++i];
      out += lookup(name, scope, edge, forCommand);
    } else {
      out += n;
    }
  }
  return out;
}

function lookup(name, scope, edge, forCommand) {
  if (edge) {
    if (name === 'in') return edge.explicitIn.map(forCommand ? shellQuote : x => x).join(' ');
    if (name === 'in_newline') return edge.explicitIn.map(forCommand ? shellQuote : x => x).join('\n');
    if (name === 'out') return edge.explicitOut.map(forCommand ? shellQuote : x => x).join(' ');
    if (edge.bindings.has(name)) return edge.bindings.get(name);
    const ruleVal = edge.rule && edge.rule.bindings.get(name);
    if (ruleVal !== undefined) return expand(ruleVal, scope, edge, forCommand);
  }
  return scope.getVar(name);
}

function splitWords(s, scope) {
  const words = [];
  let cur = '';
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === ' ' || ch === '\t') {
      if (cur !== '') {
        words.push(expand(cur, scope));
        cur = '';
      }
      continue;
    }
    if (ch === '$' && i + 1 < s.length) {
      const n = s[++i];
      if (n === ' ') cur += ' ';
      else if (n === ':') cur += ':';
      else if (n === '$') cur += '$';
      else if (n === '^') cur += '\n';
      else if (n === '{') {
        const end = s.indexOf('}', i + 1);
        if (end < 0) cur += '${';
        else {
          cur += scope.getVar(s.slice(i + 1, end));
          i = end;
        }
      } else if (/[A-Za-z0-9_.-]/.test(n)) {
        let name = n;
        while (i + 1 < s.length && /[A-Za-z0-9_.-]/.test(s[i + 1])) name += s[++i];
        cur += scope.getVar(name);
      } else {
        cur += n;
      }
    } else {
      cur += ch;
    }
  }
  if (cur !== '') words.push(expand(cur, scope));
  return words;
}

function findBuildColon(s) {
  for (let i = 0; i < s.length; i++) {
    if (s[i] === '$') {
      i++;
      continue;
    }
    if (s[i] === ':') return i;
  }
  return -1;
}

class Manifest {
  constructor(file) {
    this.file = file;
    this.root = new Scope();
    this.edges = [];
    this.outputs = new Map();
    this.defaults = [];
    this.pools = new Map([['console', { depth: 1 }]]);
  }
  addEdge(edge) {
    this.edges.push(edge);
    for (const out of edge.outputs) {
      if (this.outputs.has(out)) die(`multiple rules generate ${out}`);
      this.outputs.set(out, edge);
    }
  }
}

function parseManifest(file) {
  const m = new Manifest(file);
  parseFile(m, path.resolve(file), m.root);
  return m;
}

function parseFile(m, file, scope) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (e) {
    die(`loading '${file}': ${e.message}`);
  }
  const dir = path.dirname(file);
  const lines = joinContinuations(text).split('\n');
  for (let i = 0; i < lines.length; i++) {
    let raw = lines[i];
    let line = stripComment(raw).replace(/[ \t]+$/, '');
    if (/^[ \t]*$/.test(line)) continue;
    if (/^[ \t]/.test(line)) die(`${file}:${i + 1}: unexpected indent`);
    if (line.startsWith('rule ')) {
      const name = line.slice(5).trim();
      const rule = { name, bindings: new Map() };
      while (i + 1 < lines.length && /^[ \t]/.test(lines[i + 1])) {
        i++;
        const b = stripComment(lines[i]).trimEnd().trimStart();
        if (b === '') continue;
        const eq = b.indexOf('=');
        if (eq < 0) die(`${file}:${i + 1}: expected variable binding`);
        rule.bindings.set(b.slice(0, eq).trim(), b.slice(eq + 1).trimStart());
      }
      scope.setRule(name, rule);
      continue;
    }
    if (line.startsWith('pool ')) {
      const name = line.slice(5).trim();
      const pool = {};
      while (i + 1 < lines.length && /^[ \t]/.test(lines[i + 1])) {
        i++;
        const b = stripComment(lines[i]).trimEnd().trimStart();
        const eq = b.indexOf('=');
        if (eq >= 0) pool[b.slice(0, eq).trim()] = expand(b.slice(eq + 1).trimStart(), scope);
      }
      m.pools.set(name, pool);
      continue;
    }
    if (line.startsWith('build ')) {
      const rest = line.slice(6);
      const colon = findBuildColon(rest);
      if (colon < 0) die(`${file}:${i + 1}: expected ':' in build statement`);
      const left = splitWords(rest.slice(0, colon), scope);
      const right = splitWords(rest.slice(colon + 1), scope);
      const explicitOut = [];
      const implicitOut = [];
      let outList = explicitOut;
      for (const w of left) {
        if (w === '|') outList = implicitOut;
        else outList.push(w);
      }
      if (right.length === 0) die(`${file}:${i + 1}: expected build command name`);
      const ruleName = right[0];
      const rule = ruleName === 'phony' ? { name: 'phony', bindings: new Map([['command', '']]) } : scope.getRule(ruleName);
      if (!rule) die(`${file}:${i + 1}: unknown build rule '${ruleName}'`);
      const explicitIn = [];
      const implicitIn = [];
      const orderOnly = [];
      const validations = [];
      let bucket = explicitIn;
      for (let j = 1; j < right.length; j++) {
        const w = right[j];
        if (w === '|') bucket = implicitIn;
        else if (w === '||') bucket = orderOnly;
        else if (w === '|@') bucket = validations;
        else bucket.push(w);
      }
      const edge = {
        ruleName, rule, scope, explicitOut, implicitOut, outputs: explicitOut.concat(implicitOut),
        explicitIn, implicitIn, orderOnly, validations, bindings: new Map(), line: i + 1,
      };
      while (i + 1 < lines.length && /^[ \t]/.test(lines[i + 1])) {
        i++;
        const b = stripComment(lines[i]).trimEnd().trimStart();
        if (b === '') continue;
        const eq = b.indexOf('=');
        if (eq < 0) die(`${file}:${i + 1}: expected variable binding`);
        edge.bindings.set(b.slice(0, eq).trim(), expand(b.slice(eq + 1).trimStart(), scope, edge));
      }
      m.addEdge(edge);
      continue;
    }
    if (line.startsWith('default ')) {
      const ds = splitWords(line.slice(8), scope);
      for (const d of ds) m.defaults.push(d);
      continue;
    }
    if (line.startsWith('include ') || line.startsWith('subninja ')) {
      const isSub = line.startsWith('subninja ');
      const p = splitWords(line.slice(isSub ? 9 : 8), scope)[0];
      const child = isSub ? new Scope(scope) : scope;
      parseFile(m, path.resolve(dir, p), child);
      continue;
    }
    const eq = line.indexOf('=');
    if (eq >= 0) {
      const k = line.slice(0, eq).trim();
      const v = expand(line.slice(eq + 1).trimStart(), scope);
      scope.setVar(k, v);
      continue;
    }
    die(`${file}:${i + 1}: unknown build file statement`);
  }
}

function commandFor(edge) {
  return expand(edge.rule.bindings.get('command') || '', edge.scope, edge, true);
}

function descFor(edge, verbose) {
  const cmd = commandFor(edge);
  if (verbose) return cmd;
  const d = edge.rule.bindings.get('description');
  return d ? expand(d, edge.scope, edge, false) : cmd;
}

function logPath(m) {
  const bd = m.root.getVar('builddir');
  return bd ? path.join(bd, '.ninja_log') : '.ninja_log';
}

function readLog(m) {
  const map = new Map();
  try {
    const txt = fs.readFileSync(logPath(m), 'utf8');
    for (const line of txt.split(/\n/)) {
      if (!line || line[0] === '#') continue;
      const parts = line.split('\t');
      if (parts.length >= 5) map.set(parts[3], parts[4]);
    }
  } catch {}
  return map;
}

function hashString(s) {
  let h1 = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h1 ^= s.charCodeAt(i);
    h1 = Math.imul(h1, 0x01000193) >>> 0;
  }
  return h1.toString(16);
}

function appendLog(m, edge) {
  const lp = logPath(m);
  const dir = path.dirname(lp);
  if (dir && dir !== '.') fs.mkdirSync(dir, { recursive: true });
  if (!exists(lp)) fs.writeFileSync(lp, '# ninja log v7\n');
  const now = Date.now();
  const h = hashString(commandFor(edge));
  for (const out of edge.outputs) fs.appendFileSync(lp, `${now}\t${now}\t${Math.floor(statMtime(out) * 1000000)}\t${out}\t${h}\n`);
}

function depsOf(edge, includeOrder = true) {
  return edge.explicitIn.concat(edge.implicitIn, includeOrder ? edge.orderOnly : []);
}

function depfileFor(edge) {
  const d = edge.bindings.get('depfile') || edge.rule.bindings.get('depfile');
  return d ? expand(d, edge.scope, edge, false) : '';
}

function parseDepfile(file) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch { return []; }
  text = text.replace(/\\\r?\n/g, ' ');
  const colon = text.indexOf(':');
  if (colon < 0) return [];
  const rhs = text.slice(colon + 1);
  const out = [];
  let cur = '';
  for (let i = 0; i < rhs.length; i++) {
    const ch = rhs[i];
    if (/\s/.test(ch)) {
      if (cur) { out.push(cur); cur = ''; }
    } else if (ch === '\\' && i + 1 < rhs.length) {
      cur += rhs[++i];
    } else {
      cur += ch;
    }
  }
  if (cur) out.push(cur);
  return out;
}

function planBuild(m, targets, opts) {
  const log = readLog(m);
  const visiting = new Set();
  const visited = new Set();
  const build = [];
  function visit(name) {
    const edge = m.outputs.get(name);
    if (!edge) {
      if (!exists(name)) die(`'${name}', needed by 'unknown', missing and no known rule to make it`);
      return false;
    }
    const key = edge.outputs[0];
    if (visited.has(key)) return edge._dirty || false;
    if (visiting.has(key)) die(`dependency cycle involving ${name}`);
    visiting.add(key);
    let dirty = false;
    for (const dep of depsOf(edge, true)) {
      const depEdge = m.outputs.get(dep);
      if (depEdge) dirty = visit(dep) || dirty;
      else if (!exists(dep) && edge.ruleName !== 'phony') die(`'${dep}', needed by '${edge.outputs[0]}', missing and no known rule to make it`);
    }
    visiting.delete(key);
    const outsMissing = edge.outputs.some(o => !exists(o));
    let oldestOut = Infinity;
    for (const o of edge.outputs) oldestOut = Math.min(oldestOut, statMtime(o) || 0);
    let newestIn = 0;
    for (const dep of edge.explicitIn.concat(edge.implicitIn, parseDepfile(depfileFor(edge)))) newestIn = Math.max(newestIn, statMtime(dep));
    if (edge.ruleName === 'phony') {
      dirty = dirty || (outsMissing && edge.explicitIn.length === 0 && edge.implicitIn.length === 0);
    } else {
      const cmdHash = hashString(commandFor(edge));
      const generator = edge.bindings.get('generator') || edge.rule.bindings.get('generator');
      dirty = dirty || outsMissing || newestIn > oldestOut || (!generator && log.get(edge.outputs[0]) !== cmdHash);
    }
    edge._dirty = dirty;
    visited.add(key);
    if (dirty && edge.ruleName !== 'phony') build.push(edge);
    for (const v of edge.validations) visit(v);
    return dirty;
  }
  for (const t of targets) {
    if (t.endsWith('^')) {
      const src = t.slice(0, -1);
      const found = m.edges.find(e => e.explicitIn.includes(src) || e.implicitIn.includes(src));
      if (!found) die(`unknown target '${t}'`);
      visit(found.outputs[0]);
    } else if (m.outputs.has(t) || exists(t)) {
      visit(t);
    } else {
      die(`unknown target '${t}'`);
    }
  }
  return build;
}

function defaultTargets(m) {
  if (m.defaults.length) return m.defaults;
  const inputs = new Set();
  for (const e of m.edges) for (const d of depsOf(e, true)) inputs.add(d);
  return m.edges.flatMap(e => e.outputs).filter(o => !inputs.has(o));
}

function runBuild(m, targets, opts) {
  const plan = planBuild(m, targets.length ? targets : defaultTargets(m), opts);
  if (!plan.length) {
    console.log('ninja: no work to do.');
    return 0;
  }
  let done = 0;
  for (const edge of plan) {
    done++;
    const label = descFor(edge, opts.verbose);
    if (!opts.quiet) console.log(`[${done}/${plan.length}] ${label}`);
    if (opts.dryRun) continue;
    for (const out of edge.outputs) {
      const d = path.dirname(out);
      if (d && d !== '.') fs.mkdirSync(d, { recursive: true });
    }
    const rsp = edge.rule.bindings.get('rspfile');
    if (rsp) {
      const rp = expand(rsp, edge.scope, edge, false);
      const content = expand(edge.rule.bindings.get('rspfile_content') || '', edge.scope, edge, false);
      fs.writeFileSync(rp, content);
      edge._rsp = rp;
    }
    const res = cp.spawnSync(commandFor(edge), { shell: true, stdio: 'pipe', encoding: 'utf8' });
    if (res.stdout) process.stdout.write(res.stdout);
    if (res.stderr) process.stderr.write(res.stderr);
    if (res.status !== 0) {
      console.error(`FAILED: ${edge.outputs.join(' ')}`);
      console.error(commandFor(edge));
      return res.status || 1;
    }
    if (edge._rsp && !opts.keeprsp) try { fs.unlinkSync(edge._rsp); } catch {}
    const depfile = depfileFor(edge);
    if (depfile && (edge.bindings.get('deps') || edge.rule.bindings.get('deps')) === 'gcc' && !opts.keepdepfile) {
      try { fs.unlinkSync(depfile); } catch {}
    }
    appendLog(m, edge);
  }
  return 0;
}

function toolTargets(m, args) {
  if (args[0] === 'all') {
    for (const e of m.edges) for (const o of e.outputs) console.log(`${o}: ${e.ruleName}`);
  } else if (args[0] === 'rule' && args[1]) {
    for (const e of m.edges) if (e.ruleName === args[1]) for (const o of e.outputs) console.log(o);
  } else if (args[0] === 'depth' || args.length === 0) {
    const maxDepth = args[0] === 'depth' ? Number(args[1] || 1) : 1;
    const roots = defaultTargets(m);
    function show(t, depth) {
      const e = m.outputs.get(t);
      const indent = '  '.repeat(depth);
      console.log(e ? `${indent}${t}: ${e.ruleName}` : `${indent}${t}`);
      if (maxDepth !== 0 && depth + 1 >= maxDepth) return;
      if (e) for (const d of depsOf(e, true)) show(d, depth + 1);
    }
    for (const r of roots) show(r, 0);
  } else {
    die(`unknown target tool mode '${args[0]}'`);
  }
}

function toolRules(m, args) {
  const d = args.includes('-d');
  const seen = new Set();
  for (const scope of [m.root]) {
    for (const [name, rule] of scope.rules) {
      if (seen.has(name)) continue;
      seen.add(name);
      const desc = rule.bindings.get('description');
      console.log(d && desc ? `${name}: ${desc}` : name);
    }
  }
  console.log('phony');
}

function collectEdges(m, target, set = new Set(), arr = []) {
  const e = m.outputs.get(target);
  if (!e || set.has(e)) return arr;
  for (const dep of depsOf(e, true)) collectEdges(m, dep, set, arr);
  set.add(e);
  if (e.ruleName !== 'phony') arr.push(e);
  return arr;
}

function toolCommands(m, args) {
  const finalOnly = args[0] === '-s';
  if (finalOnly) args = args.slice(1);
  const targets = args.length ? args : defaultTargets(m);
  let edges = [];
  for (const t of targets) edges = collectEdges(m, t, new Set(edges), edges);
  if (finalOnly && edges.length) edges = [edges[edges.length - 1]];
  for (const e of edges) console.log(commandFor(e));
}

function toolInputs(m, args) {
  args = args.filter(a => a !== '--no-shell-escape');
  const noesc = process.argv.includes('--no-shell-escape');
  const seen = new Set();
  function walk(t) {
    const e = m.outputs.get(t);
    if (!e) {
      if (!seen.has(t)) {
        seen.add(t);
        console.log(noesc ? t : shellQuote(t));
      }
      return;
    }
    for (const d of depsOf(e, true)) walk(d);
  }
  for (const t of (args.length ? args : defaultTargets(m))) walk(t);
}

function toolQuery(m, args) {
  for (const t of args) {
    const e = m.outputs.get(t);
    console.log(`${t}:`);
    if (!e) {
      console.log('  input: unknown');
      continue;
    }
    console.log(`  input: ${e.ruleName}`);
    for (const d of e.explicitIn) console.log(`    ${d}`);
    for (const d of e.implicitIn) console.log(`    | ${d}`);
    for (const d of e.orderOnly) console.log(`    || ${d}`);
    const outs = m.edges.filter(x => depsOf(x, true).includes(t));
    console.log('  outputs:');
    for (const oe of outs) for (const o of oe.outputs) console.log(`    ${o}`);
  }
}

function toolClean(m, args, opts) {
  let count = 0;
  const targets = args.filter(a => !a.startsWith('-'));
  const remove = targets.length ? targets : m.edges.flatMap(e => e.rule.bindings.get('generator') ? [] : e.outputs);
  for (const f of remove) {
    if (exists(f)) {
      if (opts.verbose || opts.dryRun) console.log(`Remove ${f}`);
      if (!opts.dryRun) fs.unlinkSync(f);
      count++;
    }
  }
  console.log(`${count} files.`);
}

function toolCompdb(m, args) {
  const expandRsp = args.includes('-x');
  const rules = new Set(args.filter(a => a !== '-x'));
  const entries = [];
  for (const e of m.edges) {
    if (!rules.has(e.ruleName)) continue;
    let command = commandFor(e);
    if (expandRsp) {
      const rsp = e.rule.bindings.get('rspfile');
      if (rsp) command = command.replace('@' + expand(rsp, e.scope, e, false), expand(e.rule.bindings.get('rspfile_content') || '', e.scope, e, false));
    }
    entries.push({ directory: process.cwd(), command, file: e.explicitIn[0] || '', output: e.explicitOut[0] || '' });
  }
  console.log(JSON.stringify(entries, null, 2));
}

function toolGraph(m, args) {
  console.log('digraph ninja {');
  for (const e of m.edges) {
    for (const o of e.outputs) console.log(`"${o}" [label="${o}"];`);
    for (const d of depsOf(e, true)) for (const o of e.outputs) console.log(`"${d}" -> "${o}";`);
  }
  console.log('}');
}

function printHelp() {
  console.log(`usage: ninja [options] [targets...]

if targets are unspecified, builds the 'default' target (see manual).

options:
  --version      print ninja version ("${VERSION}")
  -v, --verbose  show all command lines while building
  --quiet        don't show progress status, just command output

  -C DIR   change to DIR before doing anything else
  -f FILE  specify input build file [default=build.ninja]

  -j N     run N jobs in parallel (0 means infinity) [default=6 on this system]
  -k N     keep going until N jobs fail (0 means infinity) [default=1]
  -l N     do not start new jobs if the load average is greater than N
  -n       dry run (don't run commands but act like they succeeded)

  -d MODE  enable debugging (use '-d list' to list modes)
  -t TOOL  run a subtool (use '-t list' to list subtools)
    terminates toplevel options; further flags are passed to the tool
  -w FLAG  adjust warnings (use '-w list' to list warnings)`);
}

function main() {
  const args = process.argv.slice(2);
  let file = 'build.ninja';
  let tool = null;
  const opts = { verbose: false, quiet: false, dryRun: false, keeprsp: false, keepdepfile: false };
  const targets = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--version') { console.log(VERSION); return; }
    if (a === '-h' || a === '--help') { printHelp(); process.exit(1); }
    if (a === '-v' || a === '--verbose') opts.verbose = true;
    else if (a === '--quiet') opts.quiet = true;
    else if (a === '-n') opts.dryRun = true;
    else if (a === '-f') file = args[++i];
    else if (a.startsWith('-f') && a.length > 2) file = a.slice(2);
    else if (a === '-C') process.chdir(args[++i]);
    else if (a.startsWith('-C') && a.length > 2) process.chdir(a.slice(2));
    else if (a === '-j' || a === '-k' || a === '-l' || a === '-d' || a === '-w') {
      const val = args[++i];
      if (a === '-d' && val === 'list') {
        console.log("debugging modes:\n  stats        print operation counts/timing info\n  explain      explain what caused a command to execute\n  keepdepfile  don't delete depfiles after they're read by ninja\n  keeprsp      don't delete @response files on success\nmultiple modes can be enabled via -d FOO -d BAR");
        return;
      }
      if (a === '-w' && val === 'list') {
        console.log('warning flags:\n  phonycycle={err,warn}  phony build statement references itself');
        return;
      }
      if (a === '-d' && val === 'keeprsp') opts.keeprsp = true;
      if (a === '-d' && val === 'keepdepfile') opts.keepdepfile = true;
    } else if (/^-j\d+|-k\d+|-l\d+$/.test(a)) {
      continue;
    } else if (a === '-t') {
      tool = args[++i] || 'list';
      targets.push(...args.slice(i + 1));
      break;
    } else if (a.startsWith('-')) {
      die(`invalid option '${a}'`);
    } else {
      targets.push(a);
    }
  }
  if (tool === 'list') {
    console.log('ninja subtools:\n     browse  browse dependency graph in a web browser\n      clean  clean built files\n   commands  list all commands required to rebuild given targets\n     inputs  list all inputs required to rebuild given targets\nmulti-inputs  print one or more sets of inputs required to build targets\n       deps  show dependencies stored in the deps log\nmissingdeps  check deps log dependencies on generated files\n      graph  output graphviz dot file for targets\n      query  show inputs/outputs for a path\n    targets  list targets by their rule or depth in the DAG\n     compdb  dump JSON compilation database to stdout\ncompdb-targets  dump JSON compilation database for a given list of targets to stdout\n  recompact  recompacts ninja-internal data structures\n     restat  restats all outputs in the build log\n      rules  list all rules\n  cleandead  clean built files that are no longer produced by the manifest');
    return;
  }
  const m = parseManifest(file);
  if (tool) {
    if (tool === 'targets') toolTargets(m, targets);
    else if (tool === 'rules') toolRules(m, targets);
    else if (tool === 'commands') toolCommands(m, targets);
    else if (tool === 'inputs') toolInputs(m, targets);
    else if (tool === 'query') toolQuery(m, targets);
    else if (tool === 'clean' || tool === 'cleandead') toolClean(m, targets, opts);
    else if (tool === 'compdb' || tool === 'compdb-targets') toolCompdb(m, targets);
    else if (tool === 'graph') toolGraph(m, targets);
    else if (tool === 'deps' || tool === 'missingdeps' || tool === 'recompact' || tool === 'restat') return;
    else die(`unknown tool '${tool}'`);
    return;
  }
  process.exit(runBuild(m, targets, opts));
}

main();
