#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const HELP = `Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...
          Input files or directories

Options:
  -d, --depth <DEPTH>
          Depth to show

  -T, --threads <THREADS>
          Number of threads to use

      --config <FILE>
          Specify a config file to use

  -n, --number-of-lines <NUMBER>
          Number of lines of output to show. (Default is terminal_height - 10)

  -p, --full-paths
          Subdirectories will not have their path shortened

  -X, --ignore-directory <PATH>
          Exclude any file or directory with this path

  -I, --ignore-all-in-file <FILE>
          Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter

  -L, --dereference-links
          dereference sym links - Treat sym links as directories and go into them

  -x, --limit-filesystem
          Only count the files and directories on the same filesystem as the supplied directory

  -s, --apparent-size
          Use file length instead of blocks

  -r, --reverse
          Print tree upside down (biggest highest)

  -c, --no-colors
          No colors will be printed (Useful for commands like: watch)

  -C, --force-colors
          Force colors print

  -b, --no-percent-bars
          No percent bars or percentages will be displayed

  -B, --bars-on-right
          percent bars moved to right side of screen

  -z, --min-size <MIN_SIZE>
          Minimum size file to include in output

  -R, --screen-reader
          For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)

      --skip-total
          No total row will be displayed

  -f, --filecount
          Directory 'size' is number of child files instead of disk size

  -i, --ignore-hidden
          Do not display hidden files

  -v, --invert-filter <REGEX>
          Exclude filepaths matching this regex. To ignore png files type: -v "\\.png$"

  -e, --filter <REGEX>
          Only include filepaths matching this regex. For png files type: -e "\\.png$"

  -t, --file-types
          show only these file types

  -w, --terminal-width <WIDTH>
          Specify width of output overriding the auto detection of terminal width

  -P, --no-progress
          Disable the progress indication

      --print-errors
          Print path with errors

  -D, --only-dir
          Only directories will be displayed

  -F, --only-file
          Only files will be displayed. (Finds your largest files)

  -o, --output-format <FORMAT>
          Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size

          Possible values:
          - si: SI prefix (powers of 1000)
          - b:  byte (B)
          - k:  kibibyte (KiB)
          - m:  mebibyte (MiB)
          - g:  gibibyte (GiB)
          - t:  tebibyte (TiB)
          - kb: kilobyte (kB)
          - mb: megabyte (MB)
          - gb: gigabyte (GB)
          - tb: terabyte (TB)

  -S, --stack-size <STACK_SIZE>
          Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)

  -j, --output-json
          Output the directory tree as json to the current directory

  -M, --mtime <MTIME>
          +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (−∞, curr−(n+1)), n => [curr−(n+1), curr−n), and -n => (𝑐𝑢𝑟𝑟−𝑛, +∞)

  -A, --atime <ATIME>
          just like -mtime, but based on file access time

  -y, --ctime <CTIME>
          just like -mtime, but based on file change time

      --files0-from <FILES0_FROM>
          Read NUL-terminated paths from FILE (use \`-\` for stdin)

      --files-from <FILES_FROM>
          Read newline-terminated paths from FILE (use \`-\` for stdin)

      --collapse <COLLAPSE>
          Keep these directories collapsed

  -m, --filetime <FILETIME>
          Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time

          Possible values:
          - a: last accessed time
          - c: last changed time
          - m: last modified time

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const SHORT_HELP = `Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...  Input files or directories

Options:
  -d, --depth <DEPTH>              Depth to show
  -T, --threads <THREADS>          Number of threads to use
      --config <FILE>              Specify a config file to use
  -n, --number-of-lines <NUMBER>   Number of lines of output to show. (Default is terminal_height - 10)
  -p, --full-paths                 Subdirectories will not have their path shortened
  -X, --ignore-directory <PATH>    Exclude any file or directory with this path
  -I, --ignore-all-in-file <FILE>  Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter
  -L, --dereference-links          dereference sym links - Treat sym links as directories and go into them
  -x, --limit-filesystem           Only count the files and directories on the same filesystem as the supplied directory
  -s, --apparent-size              Use file length instead of blocks
  -r, --reverse                    Print tree upside down (biggest highest)
  -c, --no-colors                  No colors will be printed (Useful for commands like: watch)
  -C, --force-colors               Force colors print
  -b, --no-percent-bars            No percent bars or percentages will be displayed
  -B, --bars-on-right              percent bars moved to right side of screen
  -z, --min-size <MIN_SIZE>        Minimum size file to include in output
  -R, --screen-reader              For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)
      --skip-total                 No total row will be displayed
  -f, --filecount                  Directory 'size' is number of child files instead of disk size
  -i, --ignore-hidden              Do not display hidden files
  -v, --invert-filter <REGEX>      Exclude filepaths matching this regex. To ignore png files type: -v "\\.png$"
  -e, --filter <REGEX>             Only include filepaths matching this regex. For png files type: -e "\\.png$"
  -t, --file-types                 show only these file types
  -w, --terminal-width <WIDTH>     Specify width of output overriding the auto detection of terminal width
  -P, --no-progress                Disable the progress indication
      --print-errors               Print path with errors
  -D, --only-dir                   Only directories will be displayed
  -F, --only-file                  Only files will be displayed. (Finds your largest files)
  -o, --output-format <FORMAT>     Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size
  -S, --stack-size <STACK_SIZE>    Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)
  -j, --output-json                Output the directory tree as json to the current directory
  -M, --mtime <MTIME>              +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (−∞, curr−(n+1)), n => [curr−(n+1), curr−n), and -n => (𝑐𝑢𝑟𝑟−𝑛, +∞)
  -A, --atime <ATIME>              just like -mtime, but based on file access time
  -y, --ctime <CTIME>              just like -mtime, but based on file change time
      --files0-from <FILES0_FROM>  Read NUL-terminated paths from FILE (use \`-\` for stdin)
      --files-from <FILES_FROM>    Read newline-terminated paths from FILE (use \`-\` for stdin)
      --collapse <COLLAPSE>        Keep these directories collapsed
  -m, --filetime <FILETIME>        Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version`;

function die(msg) {
  process.stderr.write(msg + '\n');
  process.exit(1);
}

function parseArgs(argv) {
  const o = {
    paths: [], depth: Infinity, lines: null, full: false, deref: false,
    apparent: false, reverse: false, noBars: false, barsRight: false,
    minSize: 0, screen: false, skipTotal: false, filecount: false,
    ignoreHidden: false, invert: [], filter: null, fileTypes: false,
    width: Number(process.env.COLUMNS || 80), onlyDir: false, onlyFile: false,
    output: null, json: false, ignores: [], collapse: new Set(), printErrors: false,
    filetime: null, timeFilters: []
  };
  const need = (i, a) => {
    if (i + 1 >= argv.length) die(`error: a value is required for '${a}' but none was supplied`);
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '--') { o.paths.push(...argv.slice(i + 1)); break; }
    if (!a.startsWith('-') || a === '-') { o.paths.push(a); continue; }
    let val = null;
    if (a.startsWith('--') && a.includes('=')) {
      const p = a.indexOf('=');
      val = a.slice(p + 1); a = a.slice(0, p);
    }
    const get = () => val !== null ? val : need(i++, a);
    switch (a) {
      case '-h': console.log(SHORT_HELP); process.exit(0);
      case '--help': console.log(HELP); process.exit(0);
      case '-V': case '--version': console.log('Dust 1.2.3'); process.exit(0);
      case '-d': case '--depth': o.depth = Number(get()); break;
      case '-T': case '--threads': get(); break;
      case '--config': readConfig(get(), o); break;
      case '-n': case '--number-of-lines': o.lines = Number(get()); break;
      case '-p': case '--full-paths': o.full = true; break;
      case '-X': case '--ignore-directory': o.ignores.push(get()); break;
      case '-I': case '--ignore-all-in-file': readIgnoreFile(get(), o); break;
      case '-L': case '--dereference-links': o.deref = true; break;
      case '-x': case '--limit-filesystem': break;
      case '-s': case '--apparent-size': o.apparent = true; break;
      case '-r': case '--reverse': o.reverse = true; break;
      case '-c': case '--no-colors': break;
      case '-C': case '--force-colors': break;
      case '-b': case '--no-percent-bars': o.noBars = true; break;
      case '-B': case '--bars-on-right': o.barsRight = true; break;
      case '-z': case '--min-size': o.minSize = parseSize(get()); break;
      case '-R': case '--screen-reader': o.screen = true; break;
      case '--skip-total': o.skipTotal = true; break;
      case '-f': case '--filecount': o.filecount = true; break;
      case '-i': case '--ignore-hidden': o.ignoreHidden = true; break;
      case '-v': case '--invert-filter': o.invert.push(new RegExp(get())); break;
      case '-e': case '--filter': o.filter = new RegExp(get()); break;
      case '-t': case '--file-types': o.fileTypes = true; break;
      case '-w': case '--terminal-width': o.width = Number(get()); break;
      case '-P': case '--no-progress': break;
      case '--print-errors': o.printErrors = true; break;
      case '-D': case '--only-dir': o.onlyDir = true; break;
      case '-F': case '--only-file': o.onlyFile = true; break;
      case '-o': case '--output-format': o.output = get().toLowerCase(); break;
      case '-S': case '--stack-size': get(); break;
      case '-j': case '--output-json': o.json = true; break;
      case '-M': case '--mtime': o.timeFilters.push(['mtimeMs', get()]); break;
      case '-A': case '--atime': o.timeFilters.push(['atimeMs', get()]); break;
      case '-y': case '--ctime': o.timeFilters.push(['ctimeMs', get()]); break;
      case '--files-from': o.paths.push(...readPathList(get(), false)); break;
      case '--files0-from': o.paths.push(...readPathList(get(), true)); break;
      case '--collapse': o.collapse.add(get()); break;
      case '-m': case '--filetime': o.filetime = get(); break;
      default:
        if (/^-[A-Za-z]+$/.test(a) && a.length > 2) {
          const rest = a.slice(1).split('').map(ch => '-' + ch);
          argv.splice(i + 1, 0, ...rest);
        } else die(`error: unexpected argument '${a}' found`);
    }
  }
  if (o.paths.length === 0) o.paths.push('.');
  return o;
}

function readPathList(file, nul) {
  const s = file === '-' ? fs.readFileSync(0, 'utf8') : fs.readFileSync(file, 'utf8');
  return s.split(nul ? '\0' : /\r?\n/).filter(Boolean);
}

function readIgnoreFile(file, o) {
  try {
    for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
      if (line.trim()) o.invert.push(new RegExp(line.trim()));
    }
  } catch (_) {}
}

function readConfig(file, o) {
  try {
    const txt = fs.readFileSync(file, 'utf8');
    for (const raw of txt.split(/\r?\n/)) {
      const line = raw.replace(/#.*/, '').trim();
      const m = line.match(/^([A-Za-z0-9_-]+)\s*=\s*(.+)$/);
      if (!m) continue;
      const key = m[1], v = m[2].replace(/^["']|["']$/g, '').trim();
      const b = v === 'true';
      if (key === 'reverse') o.reverse = b;
      if (key === 'display-full-paths') o.full = b;
      if (key === 'display-apparent-size') o.apparent = b;
      if (key === 'no-bars') o.noBars = b;
      if (key === 'skip-total') o.skipTotal = b;
      if (key === 'ignore-hidden') o.ignoreHidden = b;
      if (key === 'output-format') o.output = v;
      if (key === 'number-of-lines') o.lines = Number(v);
    }
  } catch (_) {}
}

function parseSize(s) {
  const m = String(s).trim().match(/^([0-9]+(?:\.[0-9]+)?)([kmgt]?i?b?|[KMGT]?)$/);
  if (!m) return Number(s) || 0;
  const n = Number(m[1]);
  const u = m[2].toLowerCase().replace(/b$/, '');
  const pow2 = { k: 1024, ki: 1024, m: 1024 ** 2, mi: 1024 ** 2, g: 1024 ** 3, gi: 1024 ** 3, t: 1024 ** 4, ti: 1024 ** 4 };
  return Math.floor(n * (pow2[u] || 1));
}

function entrySize(st, o) {
  if (o.filetime) {
    const k = o.filetime === 'a' ? 'atimeMs' : o.filetime === 'c' ? 'ctimeMs' : 'mtimeMs';
    return Math.floor(st[k] / 1000);
  }
  return o.apparent ? st.size : (st.blocks || Math.ceil(st.size / 512)) * 512;
}

function passTime(st, filters) {
  const now = Date.now();
  for (const [k, expr] of filters) {
    const s = String(expr);
    const n = Number(s.replace(/^[+-]/, ''));
    const days = Math.floor((now - st[k]) / 86400000);
    if (s.startsWith('+')) { if (!(days > n)) return false; }
    else if (s.startsWith('-')) { if (!(days < n)) return false; }
    else if (days !== n) return false;
  }
  return true;
}

function shouldIgnore(p, base, o) {
  const name = path.basename(p);
  if (o.ignoreHidden && name.startsWith('.')) return true;
  if (o.ignores.some(x => x === name || x === p || p.endsWith('/' + x))) return true;
  if (o.invert.some(r => r.test(p))) return true;
  if (o.filter && !o.filter.test(p)) return true;
  return false;
}

function scan(p, o, rootBase = null, seen = new Set()) {
  let st;
  try { st = o.deref ? fs.statSync(p) : fs.lstatSync(p); }
  catch (e) { if (o.printErrors) console.error(p); return null; }
  if (shouldIgnore(p, rootBase, o) || !passTime(st, o.timeFilters)) return null;
  const abs = path.resolve(p);
  const isDir = st.isDirectory();
  const node = { path: p, name: p, base: path.basename(p) || p, isDir, children: [], own: entrySize(st, o), size: 0, count: 0 };
  if (isDir && !o.collapse.has(path.basename(p))) {
    const key = `${st.dev}:${st.ino}`;
    if (!seen.has(key)) {
      seen.add(key);
      let names = [];
      try { names = fs.readdirSync(p); } catch (e) { if (o.printErrors) console.error(p); }
      names.sort();
      for (const nm of names) {
        const ch = scan(path.join(p, nm), o, rootBase || p, seen);
        if (ch) node.children.push(ch);
      }
    }
  }
  if (o.filecount) {
    node.count = node.isDir ? node.children.reduce((a, c) => a + c.count, 0) : 1;
    node.size = node.count;
  } else if (o.filetime) {
    node.size = Math.max(node.own, ...node.children.map(c => c.size));
  } else {
    node.size = node.own + node.children.reduce((a, c) => a + c.size, 0);
  }
  return node.size < o.minSize ? null : node;
}

function flatten(node, o, depth = 0, prefix = '', out = [], isLast = true) {
  if (!node) return out;
  const kids = node.children.slice().sort((a, b) => a.size - b.size || a.base.localeCompare(b.base));
  const visibleKids = kids.filter(k => depth + 1 <= o.depth);
  if (!o.reverse) {
    for (let i = 0; i < visibleKids.length; i++) {
      flatten(visibleKids[i], o, depth + 1, prefix + (depth === 0 ? '' : (isLast ? '  ' : '│ ')), out, i === visibleKids.length - 1);
    }
  }
  const show = !(o.skipTotal && depth === 0) &&
    !(o.onlyDir && !node.isDir) && !(o.onlyFile && node.isDir && depth !== 0);
  if (show) {
    out.push({ node, depth, prefix, branch: branch(depth, isLast, o.reverse, visibleKids.length > 0) });
  }
  if (o.reverse) {
    const desc = visibleKids.slice().sort((a, b) => b.size - a.size || a.base.localeCompare(b.base));
    for (let i = 0; i < desc.length; i++) {
      flatten(desc[i], o, depth + 1, prefix + (depth === 0 ? '' : (isLast ? '  ' : '│ ')), out, i === desc.length - 1);
    }
  }
  return out;
}

function branch(depth, isLast, rev, hasKids) {
  if (depth === 0) return rev ? '└─┬ ' : '┌─┴ ';
  if (hasKids) return rev ? (isLast ? '└─┬ ' : '├─┬ ') : (isLast ? '└─┴ ' : '├─┴ ');
  return rev ? (isLast ? '└── ' : '├── ') : (isLast ? '└── ' : '├── ');
}

function displayName(n, o) {
  return o.full || o.json ? n.path : (n.base || n.path);
}

function formatSize(v, o) {
  if (o.filecount) return String(v);
  if (o.filetime) return new Date(v * 1000).toISOString().slice(0, 10);
  const fmt = o.output;
  if (fmt === 'b') return `${Math.round(v)}B`;
  const dec = ['si', 'kb', 'mb', 'gb', 'tb'].includes(fmt);
  const base = dec ? 1000 : 1024;
  const units = dec ? ['B', 'kB', 'MB', 'GB', 'TB'] : ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
  if (fmt && fmt !== 'si') {
    const idx = { k: 1, m: 2, g: 3, t: 4, kb: 1, mb: 2, gb: 3, tb: 4 }[fmt] || 0;
    if (idx === 0) return `${Math.round(v)}B`;
    return `${Math.floor(v / (base ** idx))}${['', 'K', 'M', 'G', 'T'][idx]}`;
  }
  if (v < base) return `${Math.round(v)}B`;
  let idx = 0, x = v;
  while (x >= base && idx < units.length - 1) { x /= base; idx++; }
  const num = x >= 10 ? Math.floor(x).toString() : x.toFixed(1);
  return `${num}${units[idx] === 'KiB' ? 'K' : units[idx]}`;
}

function flattenFiles(root, o) {
  const out = [];
  function walk(n, depth) {
    if (!n.isDir || n.children.length === 0) out.push({ node: n, depth, prefix: '', branch: '├── ' });
    for (const c of n.children) walk(c, depth + 1);
  }
  for (const c of root.children) walk(c, 1);
  out.sort((a, b) => a.node.size - b.node.size || a.node.base.localeCompare(b.node.base));
  if (o.reverse) out.reverse();
  out.push({ node: root, depth: 0, prefix: '', branch: o.reverse ? '└─┬ ' : '┌─┴ ' });
  return out;
}

function render(nodes, o, total) {
  if (o.lines) {
    const indexed = nodes.map((x, i) => ({ ...x, _i: i }));
    const roots = indexed.filter(x => x.depth === 0);
    const rest = indexed.filter(x => x.depth !== 0);
    if (rest.length > o.lines) {
      const top = rest.slice().sort((a, b) => b.node.size - a.node.size || a.node.base.localeCompare(b.node.base)).slice(0, o.lines);
      nodes = (o.skipTotal ? top : top.concat(roots)).sort((a, b) => o.reverse ? a._i - b._i : a._i - b._i);
    }
  }
  const sizes = nodes.map(x => formatSize(x.node.size, o));
  const sw = Math.max(1, ...sizes.map(s => s.length));
  const screenNameW = Math.max(1, ...nodes.map(x => displayName(x.node, o).length));
  const namew = Math.max(1, ...nodes.map(x => (x.prefix + x.branch + displayName(x.node, o)).length));
  for (let i = 0; i < nodes.length; i++) {
    const x = nodes[i], n = x.node;
    const size = sizes[i].padStart(sw);
    const pct = total ? Math.round((n.size / total) * 100) : 0;
    const name = x.prefix + x.branch + displayName(n, o);
    if (o.screen) {
      console.log(`${displayName(n, o).padEnd(screenNameW)} ${String(x.depth).padEnd(1)} ${size.padStart(sw)} ${String(pct).padStart(3)}%`);
    } else if (o.noBars) {
      console.log(`${size}   ${name}`);
    } else {
      const room = Math.max(1, o.width - sw - name.length - 12);
      const barLen = Math.max(1, Math.round(room * pct / 100));
      const bar = '│' + '█'.repeat(barLen).padEnd(room) + '│';
      console.log(`${size}   ${name.padEnd(namew)} ${bar} ${String(pct).padStart(3)}%`);
    }
  }
}

function toJson(node, o) {
  return {
    size: formatSize(node.size, o),
    name: node.path,
    children: node.children.slice().sort((a, b) => b.size - a.size || a.base.localeCompare(b.base)).map(c => toJson(c, o))
  };
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  if (o.fileTypes) {
    const groups = new Map();
    for (const p of o.paths) collectTypes(scan(p, o), groups);
    const root = { path: '(total)', base: '(total)', isDir: true, children: [], size: 0 };
    for (const [ext, size] of groups) root.children.push({ path: ext, base: ext, isDir: false, children: [], size });
    root.size = root.children.reduce((a, c) => a + c.size, 0);
    output(root, o);
    return;
  }
  const roots = o.paths.map(p => scan(p, o)).filter(Boolean);
  if (roots.length === 0) return;
  if (roots.length === 1) output(roots[0], o);
  else {
    const root = { path: '(total)', base: '(total)', isDir: true, children: roots, size: roots.reduce((a, r) => a + r.size, 0) };
    output(root, o);
  }
}

function output(root, o) {
  if (o.json) { console.log(JSON.stringify(toJson(root, { ...o, json: true }))); return; }
  const nodes = o.onlyFile ? flattenFiles(root, o) : flatten(root, o);
  render(nodes, o, root.size);
}

function collectTypes(n, groups) {
  if (!n) return;
  if (!n.isDir) {
    const ext = path.extname(n.base).replace(/^\./, '') || '(no extension)';
    groups.set(ext, (groups.get(ext) || 0) + n.size);
  }
  for (const c of n.children) collectTypes(c, groups);
}

main();
