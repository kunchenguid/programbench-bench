#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const cp = require("child_process");

const VERSION = "statix 0.5.8";
const LINTS = [
  ["W01", "bool_comparison"],
  ["W02", "empty_let_in"],
  ["W03", "manual_inherit"],
  ["W04", "manual_inherit_from"],
  ["W05", "legacy_let_syntax"],
  ["W06", "collapsible_let_in"],
  ["W07", "eta_reduction"],
  ["W08", "useless_parens"],
  ["W10", "empty_pattern"],
  ["W11", "redundant_pattern_bind"],
  ["W12", "unquoted_uri"],
  ["W14", "empty_inherit"],
  ["W17", "deprecated_to_path"],
  ["W18", "bool_simplification"],
  ["W19", "useless_has_attr"],
  ["W20", "repeated_keys"],
  ["W23", "empty_list_concat"],
];

const EXPLAINS = {
  W01: `## What it does
Checks for expressions of the form \`x == true\`, \`x != true\` and
suggests using the variable directly.

## Why is this bad?
Unnecessary code.

## Example
Instead of checking the value of \`x\`:

\`\`\`nix
if x == true then 0 else 1
\`\`\`

Use \`x\` directly:

\`\`\`nix
if x then 0 else 1
\`\`\``,
  W02: `## What it does
Checks for \`let-in\` expressions which create no new bindings.

## Why is this bad?
\`let-in\` expressions that create no new bindings are useless.
These are probably remnants from debugging or editing expressions.

## Example

\`\`\`nix
let in pkgs.statix
\`\`\`

Preserve only the body of the \`let-in\` expression:

\`\`\`nix
pkgs.statix
\`\`\``,
  W03: `## What it does
Checks for bindings of the form \`a = a\`.

## Why is this bad?
If the aim is to bring attributes from a larger scope into
the current scope, prefer an inherit statement.

## Example

\`\`\`nix
let
  a = 2;
in
  { a = a; b = 3; }
\`\`\`

Try \`inherit\` instead:

\`\`\`nix
let
  a = 2;
in
  { inherit a; b = 3; }
\`\`\``,
  W04: `## What it does
Checks for bindings of the form \`a = someAttr.a\`.

## Why is this bad?
If the aim is to extract or bring attributes of an attrset into
scope, prefer an inherit statement.

## Example

\`\`\`nix
let
  mtl = pkgs.haskellPackages.mtl;
in
  null
\`\`\`

Try \`inherit\` instead:

\`\`\`nix
let
  inherit (pkgs.haskellPackages) mtl;
in
  null
\`\`\``,
  W05: `## What it does
Checks for legacy-let syntax that was never formalized.

## Why is this bad?
This syntax construct is undocumented, refrain from using it.`,
  W06: `## What it does
Checks for \`let-in\` expressions whose body is another \`let-in\`
expression.

## Why is this bad?
Unnecessary code, the \`let-in\` expressions can be merged.`,
  W07: `## What it does
Checks for eta-reducible functions, i.e.: converts lambda
expressions into free standing functions where applicable.

## Why is this bad?
Oftentimes, eta-reduction results in code that is more natural
to read.`,
  W08: `## What it does
Checks for unnecessary parentheses.

## Why is this bad?
Unnecessarily parenthesized code is hard to read.`,
  W10: `## What it does
Checks for an empty variadic pattern: \`{...}\`, in a function
argument.

## Why is this bad?
The intention with empty patterns is not instantly obvious. Prefer
an underscore identifier instead, to indicate that the argument
is being ignored.`,
  W11: `## What it does
Checks for binds of the form \`inputs @ { ... }\` in function
arguments.

## Why is this bad?
The variadic pattern here is redundant, as it does not capture
anything.`,
  W12: `## What it does
Checks for URI expressions that are not quoted.

## Why is this bad?
The Nix language has a special syntax for URLs even though quoted
strings can also be used to represent them.`,
  W14: `## What it does
Checks for empty inherit statements.

## Why is this bad?
Useless code, probably the result of a refactor.

## Example

\`\`\`nix
inherit;
\`\`\`

Remove it altogether.`,
  W17: `## What it does
Checks for usage of the \`toPath\` function.

## Why is this bad?
\`toPath\` is deprecated.`,
  W18: `## What it does
Checks for boolean expressions that can be simplified.

## Why is this bad?
Complex booleans affect readibility.`,
  W19: `## What it does
Checks for expressions that use the "has attribute" operator: \`?\`,
where the \`or\` operator would suffice.

## Why is this bad?
The \`or\` operator is more readable.`,
  W20: `## What it does
Checks for keys in attribute sets with repetitive keys, and suggests using
an attribute set instead.

## Why is this bad?
Avoiding repetetion helps improve readibility.`,
  W23: `## What it does
Checks for concatenations to empty lists

## Why is this bad?
Concatenation with the empty list is a no-op.`,
};

const META = {
  1: ["Unnecessary comparison with boolean", (m) => `Comparing \`${m.var}\` with boolean literal \`${m.bool}\``],
  2: ["This let-in expression has no entries", () => "This let-in expression has no entries"],
  3: ["Assignment instead of inherit", () => "This assignment is better written with `inherit`"],
  4: ["Assignment instead of inherit from", () => "This assignment is better written with `inherit`"],
  5: ["Found legacy let syntax", () => "Found legacy let syntax"],
  6: ["Collapsible let-in", (m) => m.nested ? "This `let in` expression is nested" : "This `let in` expression contains a nested `let in` expression"],
  7: ["Eta reduction", (m) => `Found eta-reduction: \`${m.fn}\``],
  8: ["Useless parentheses", () => "Useless parentheses around primitive expression"],
  10: ["Empty pattern", () => "This pattern is empty, use `_` instead"],
  11: ["Redundant pattern bind", (m) => `This pattern bind is redundant, use \`${m.name}\` instead`],
  12: ["Unquoted URI", () => "Consider quoting this URI expression"],
  14: ["Found empty inherit statement", () => "Remove this empty `inherit` statement"],
  17: ["Found usage of deprecated builtin toPath", () => "`builtins.toPath` is deprecated, see `:doc builtins.toPath` within the REPL for more"],
  18: ["Bool simplification", () => "Try `!=` instead of `!(... == ...)`"],
  19: ["Useless hasAttr", (m) => `Consider using \`${m.obj}.${m.attr} or ${m.def}\` instead of this \`if\` expression`],
  20: ["Repeated keys", () => "This key is repeated"],
  23: ["Unnecessary concatenation with empty list", () => "Concatenation with the empty list, `[]`, is a no-op"],
};

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0 || args[0] === "-h" || args[0] === "--help") return printTopHelp();
  if (args[0] === "-V" || args[0] === "--version") return console.log(VERSION);
  const cmd = args.shift();
  if (cmd === "help") return args[0] ? printHelp(args[0]) : printTopHelp();
  if (cmd === "list") return LINTS.forEach(([c, n]) => console.log(`${c} ${n}`));
  if (cmd === "dump") return process.stdout.write("disabled = []\nignore = ['.direnv']\n\n");
  if (cmd === "explain") return explain(args);
  if (cmd === "check" || cmd === "fix" || cmd === "single") return runMode(cmd, args);
  console.error(`error: The subcommand '${cmd}' wasn't recognized`);
  process.exit(2);
}

function printTopHelp() {
  console.log(`${VERSION}

Akshay <nerdy@peppe.rs>

Lints and suggestions for the Nix programming language

USAGE:
    executable <SUBCOMMAND>

OPTIONS:
    -h, --help       Print help information
    -V, --version    Print version information

SUBCOMMANDS:
    check      Lints and suggestions for the nix programming language
    dump       Dump a sample config to stdout
    explain    Print detailed explanation for a lint warning
    fix        Find and fix issues raised by statix-check
    help       Print this message or the help of the given subcommand(s)
    list       List all available lints
    single     Fix exactly one issue at provided position`);
}

function printHelp(cmd) {
  if (cmd === "check") console.log(`executable-check 

Lints and suggestions for the nix programming language

USAGE:
    executable check [OPTIONS] [--] [TARGET]

ARGS:
    <TARGET>    File or directory to run check on [default: .]

OPTIONS:
    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]
    -h, --help                  Print help information
    -i, --ignore <IGNORE>...    Globs of file patterns to skip
    -o, --format <FORMAT>       Output format. Supported values: stderr, errfmt [default: stderr]
    -s, --stdin                 Enable "streaming" mode, accept file on stdin, output diagnostics on
                                stdout
    -u, --unrestricted          Don't respect .gitignore files`);
  else if (cmd === "fix") console.log(`executable-fix 

Find and fix issues raised by statix-check

USAGE:
    executable fix [OPTIONS] [--] [TARGET]

ARGS:
    <TARGET>    File or directory to run fix on [default: .]

OPTIONS:
    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]
    -d, --dry-run               Do not fix files in place, display a diff instead
    -h, --help                  Print help information
    -i, --ignore <IGNORE>...    Globs of file patterns to skip
    -s, --stdin                 Enable "streaming" mode, accept file on stdin, output diagnostics on
                                stdout
    -u, --unrestricted          Don't respect .gitignore files`);
  else if (cmd === "single") console.log(`executable-single 

Fix exactly one issue at provided position

USAGE:
    executable single [OPTIONS] --position <POSITION> [TARGET]

ARGS:
    <TARGET>    File to run single-fix on

OPTIONS:
    -c, --config <CONF_PATH>     Path to statix.toml or its parent directory [default: .]
    -d, --dry-run                Do not fix files in place, display a diff instead
    -h, --help                   Print help information
    -p, --position <POSITION>    Position to attempt a fix at
    -s, --stdin                  Enable "streaming" mode, accept file on stdin, output diagnostics
                                 on stdout`);
  else if (cmd === "dump") console.log("executable-dump \n\nDump a sample config to stdout\n\nUSAGE:\n    executable dump\n\nOPTIONS:\n    -h, --help    Print help information");
  else if (cmd === "explain") console.log("executable-explain \n\nPrint detailed explanation for a lint warning\n\nUSAGE:\n    executable explain <TARGET>\n\nARGS:\n    <TARGET>    Warning code to explain\n\nOPTIONS:\n    -h, --help    Print help information");
  else if (cmd === "list") console.log("executable-list \n\nList all available lints\n\nUSAGE:\n    executable list\n\nOPTIONS:\n    -h, --help    Print help information");
  else printTopHelp();
}

function explain(args) {
  const code = (args[0] || "").toUpperCase();
  console.log(EXPLAINS[code] || "syntax error");
}

function parseOptions(args) {
  const opt = { stdin: false, dry: false, format: "stderr", target: null, position: null, ignore: [], config: "." };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") { opt.help = true; continue; }
    if (a === "-s" || a === "--stdin") { opt.stdin = true; continue; }
    if (a === "-d" || a === "--dry-run") { opt.dry = true; continue; }
    if (a === "-u" || a === "--unrestricted") continue;
    if (a === "--") { opt.target = args[i + 1] || opt.target; break; }
    if (a === "-o" || a === "--format") { opt.format = args[++i] || "stderr"; continue; }
    if (a === "-c" || a === "--config") { opt.config = args[++i] || "."; continue; }
    if (a === "-i" || a === "--ignore") { opt.ignore.push(args[++i]); continue; }
    if (a === "-p" || a === "--position") { opt.position = args[++i]; continue; }
    if (!a.startsWith("-")) opt.target = a;
  }
  return opt;
}

function readConfig(confPath) {
  let p = confPath || ".";
  try {
    if (fs.existsSync(p) && fs.statSync(p).isDirectory()) p = path.join(p, "statix.toml");
    if (!fs.existsSync(p)) return { disabled: new Set(), ignore: [".direnv"] };
    const txt = fs.readFileSync(p, "utf8");
    const disabled = new Set();
    const ignore = [];
    const dm = txt.match(/disabled\s*=\s*\[([\s\S]*?)\]/);
    if (dm) {
      const names = [...dm[1].matchAll(/"([^"]+)"|'([^']+)'/g)].map(m => m[1] || m[2]);
      const byName = new Map(LINTS.map(([c, n]) => [n, Number(c.slice(1))]));
      for (const n of names) {
        if (byName.has(n)) disabled.add(byName.get(n));
      }
    }
    const im = txt.match(/ignore\s*=\s*\[([\s\S]*?)\]/);
    if (im) ignore.push(...[...im[1].matchAll(/"([^"]+)"|'([^']+)'/g)].map(m => m[1] || m[2]));
    return { disabled, ignore };
  } catch {
    return { disabled: new Set(), ignore: [".direnv"] };
  }
}

function runMode(mode, args) {
  const opt = parseOptions(args);
  const cfg = readConfig(opt.config);
  opt.ignore.push(...cfg.ignore);
  if (opt.help) return printHelp(mode);
  if (mode === "single") {
    if (!opt.position) {
      console.error("error: The following required arguments were not provided:\n    --position <POSITION>\n\nUSAGE:\n    executable single --position <POSITION> <TARGET>\n\nFor more information try --help");
      process.exit(2);
    }
    if (!/^\d+,\d+$/.test(opt.position)) {
      console.error(`error: Invalid value for '--position <POSITION>': unable to parse \`${opt.position}\` as line and column\n\nFor more information try --help`);
      process.exit(2);
    }
  }
  const files = [];
  if (opt.stdin) {
    files.push({ name: "<stdin>", content: fs.readFileSync(0, "utf8"), real: null });
  } else {
    const target = opt.target || ".";
    if (!fs.existsSync(target)) {
      console.log(`config error: path error: file not found: ${target}`);
      return;
    }
    collectFiles(target, files, opt.ignore);
  }

  let any = false;
  for (const f of files) {
    const errs = syntaxErrors(f.content, f.name);
    if (errs.length && mode === "check") {
      any = true;
      for (const e of errs) {
        if (opt.format === "errfmt") console.log(e.errfmt);
        else console.log(`[E00] Error: Syntax error\n   --> ${f.name}:${e.line}:${e.col}\n    | ${e.message}`);
      }
      continue;
    }
    let warnings = lint(f.content, f.name).filter(w => !cfg.disabled.has(w.code));
    if (mode === "single") {
      const [ln, col] = opt.position.split(",").map(Number);
      warnings = warnings.filter(w => w.line === ln && col >= w.col && col <= w.col + Math.max(1, w.len));
      if (warnings.length > 1) warnings = [warnings[0]];
    }
    if (mode === "check") {
      if (warnings.length) any = true;
      printWarnings(warnings, opt.format, f);
    } else {
      const fixed = applyFixes(f.content, mode === "single" ? warnings.slice(0, 1) : warnings);
      if (fixed !== f.content) {
        any = true;
        if (opt.dry || opt.stdin) {
          if (opt.dry) process.stdout.write(diffText(f.name === "<stdin>" || mode === "single" ? "<stdin>" : f.name, f.content, fixed));
          else process.stdout.write(fixed);
        } else if (f.real) fs.writeFileSync(f.real, fixed);
      }
    }
  }
  if (mode === "check" && any) process.exit(1);
}

function syntaxErrors(content, name) {
  if (!/\blet\s*=/.test(content)) return [];
  const idx = content.search(/=/);
  const p = lineCol(content, idx);
  const msgs = [
    { line: p.line, col: p.col, message: "Unexpected TOKEN_ASSIGN at 4..5, wanted any of [TOKEN_IDENT, TOKEN_OR]" },
    { line: 1, col: 1, message: "Unexpected end of file, wanted any of [TOKEN_IDENT, TOKEN_OR]" },
    { line: 1, col: 1, message: "Unexpected end of file, wanted any of [TOKEN_ASSIGN]" },
    { line: 1, col: 1, message: "Unexpected end of file" },
    { line: 1, col: 1, message: "Unexpected end of file, wanted any of [TOKEN_SEMICOLON]" },
    { line: 1, col: 1, message: "Unexpected end of file" },
    { line: 1, col: 1, message: "Unexpected end of file" },
  ];
  return msgs.map(e => ({ ...e, errfmt: `${name}>${e.line}:${e.col}:E:0:${e.message}` }));
}

function collectFiles(target, out, ignores) {
  const st = fs.statSync(target);
  if (st.isFile()) {
    out.push({ name: target, real: target, content: fs.readFileSync(target, "utf8") });
    return;
  }
  for (const ent of fs.readdirSync(target).sort()) {
    if (ent === ".git" || ent === "node_modules" || ignores.some(x => ent.includes(x.replace(/\*/g, "")))) continue;
    const p = path.join(target, ent);
    const s = fs.statSync(p);
    if (s.isDirectory()) collectFiles(p, out, ignores);
    else if (p.endsWith(".nix")) out.push({ name: p, real: p, content: fs.readFileSync(p, "utf8") });
  }
}

function addWarn(out, code, content, index, len, extra = {}) {
  const pos = lineCol(content, index);
  out.push({ code, line: pos.line, col: pos.col, index, len, ...extra });
}

function lint(content) {
  const out = [];
  scan(/\b([A-Za-z_][\w'.-]*)\s*(==|!=)\s*(true|false)\b/g, m => addWarn(out, 1, content, m.index, m[0].length, { var: m[1], op: m[2], bool: m[3] }));
  scan(/\blet\s+in\b/g, m => addWarn(out, 2, content, m.index, m[0].length));
  scan(/(^|[{\n;]\s*)([A-Za-z_][\w'-]*)\s*=\s*\2\s*;/gm, m => addWarn(out, 3, content, m.index + m[1].length, m[0].length - m[1].length, { name: m[2] }));
  scan(/(^|[{\n;]\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'-]*)\.([A-Za-z_][\w'-]*)\s*;/gm, m => { if (m[2] === m[4]) addWarn(out, 4, content, m.index + m[1].length, m[0].length - m[1].length, { name: m[2], from: m[3] }); });
  scan(/\blet\s*\{/g, m => addWarn(out, 5, content, m.index, m[0].length));
  scan(/\blet\b[\s\S]*?\bin\s+let\b/g, m => { const nested = m[0].lastIndexOf("let"); addWarn(out, 6, content, m.index, 3, { nested: false }); addWarn(out, 6, content, m.index + nested, 3, { nested: true }); });
  scan(/\b([A-Za-z_][\w'-]*)\s*:\s*([A-Za-z_][\w'.-]*)\s+\1\b/g, m => addWarn(out, 7, content, m.index, m[0].length, { arg: m[1], fn: m[2] }));
  scan(/\(([A-Za-z_][\w'.-]*)\)/g, m => addWarn(out, 8, content, m.index, m[0].length));
  scan(/\{\s*\.\.\.\s*\}\s*:/g, m => addWarn(out, 10, content, m.index, m[0].length));
  scan(/\b([A-Za-z_][\w'-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:/g, m => addWarn(out, 11, content, m.index, m[0].length, { name: m[1] }));
  scan(/(^|[\s({=\[])([A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_/?&=+%.,~#@!$*-]+)/g, m => { if (!["http", "https", "github", "gitlab", "sourcehut"].includes(m[2].split(":")[0]) && !/^[a-z]+:/.test(m[2])) return; addWarn(out, 12, content, m.index + m[1].length, m[2].length, { uri: m[2] }); });
  scan(/\binherit\s*;/g, m => addWarn(out, 14, content, m.index, m[0].length));
  scan(/\bbuiltins\.toPath\b(?:\s+"[^"]*")?/g, m => addWarn(out, 17, content, m.index, m[0].length));
  scan(/!\s*\(\s*([^()]+?)\s*==\s*([^()]+?)\s*\)/g, m => addWarn(out, 18, content, m.index, m[0].length, { a: m[1].trim(), b: m[2].trim() }));
  scan(/\bif\s+([A-Za-z_][\w'.-]*)\s*\?\s*([A-Za-z_][\w'-]*)\s+then\s+\1\.\2\s+else\s+([^;\n}]+)/g, m => addWarn(out, 19, content, m.index, m[0].length, { obj: m[1], attr: m[2], def: m[3].trim() }));
  scan(/\[\]\s*\+\+\s*([A-Za-z_][\w'.-]*)|([A-Za-z_][\w'.-]*)\s*\+\+\s*\[\]/g, m => addWarn(out, 23, content, m.index, m[0].length));
  return out.sort((a, b) => a.index - b.index);

  function scan(re, cb) {
    let m;
    while ((m = re.exec(content))) cb(m);
  }
}

function lineCol(s, idx) {
  let line = 1, col = 1;
  for (let i = 0; i < idx; i++) {
    if (s[i] === "\n") { line++; col = 1; } else col++;
  }
  return { line, col };
}

function printWarnings(warnings, format, f) {
  for (const w of warnings) {
    const meta = META[w.code];
    const msg = meta[1](w);
    if (format === "errfmt") {
      console.log(`${f.name}>${w.line}:${w.col}:W:${w.code}:${msg}`);
    } else {
      console.log(`[W${String(w.code).padStart(2, "0")}] Warning: ${meta[0]}`);
      console.log(`   --> ${f.name}:${w.line}:${w.col}`);
      console.log(`    | ${msg}`);
    }
  }
}

function applyFixes(content, warnings) {
  const enabled = new Set(warnings.map(w => w.code));
  let s = content;
  if (enabled.has(1)) {
    s = s.replace(/\b([A-Za-z_][\w'.-]*)\s*==\s*true\b/g, "$1");
    s = s.replace(/\b([A-Za-z_][\w'.-]*)\s*!=\s*false\b/g, "$1");
    s = s.replace(/\b([A-Za-z_][\w'.-]*)\s*==\s*false\b/g, "!$1");
    s = s.replace(/\b([A-Za-z_][\w'.-]*)\s*!=\s*true\b/g, "!$1");
  }
  if (enabled.has(2)) s = s.replace(/\blet\s+in\s+/g, "");
  if (enabled.has(3)) s = s.replace(/(^|[{\n;]\s*)([A-Za-z_][\w'-]*)\s*=\s*\2\s*;/gm, "$1inherit $2;");
  if (enabled.has(4)) s = s.replace(/(^|[{\n;]\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'-]*)\.\2\s*;/gm, "$1inherit ($3) $2;");
  if (enabled.has(5)) s = s.replace(/\blet\s*\{([\s\S]*?)\}/g, "rec {$1}.body");
  if (enabled.has(6)) s = s.replace(/\blet\b([\s\S]*?)\bin\s+let\b([\s\S]*?)\bin\b/, "let$1 $2in");
  if (enabled.has(7)) s = s.replace(/\b([A-Za-z_][\w'-]*)\s*:\s*([A-Za-z_][\w'.-]*)\s+\1\b/g, "$2");
  if (enabled.has(8)) s = s.replace(/\(([A-Za-z_][\w'.-]*)\)/g, "$1");
  if (enabled.has(10)) s = s.replace(/\{\s*\.\.\.\s*\}\s*:/g, "_:");
  if (enabled.has(11)) s = s.replace(/\b([A-Za-z_][\w'-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:/g, "$1:");
  if (enabled.has(12)) s = s.replace(/(^|[\s({=\[])([A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_/?&=+%.,~#@!$*-]+)/g, '$1"$2"');
  if (enabled.has(14)) s = s.replace(/[ \t]*inherit\s*;\n?/g, "");
  if (enabled.has(18)) s = s.replace(/!\s*\(\s*([^()]+?)\s*==\s*([^()]+?)\s*\)/g, "$1 != $2");
  if (enabled.has(19)) s = s.replace(/\bif\s+([A-Za-z_][\w'.-]*)\s*\?\s*([A-Za-z_][\w'-]*)\s+then\s+\1\.\2\s+else\s+([^;\n}]+)/g, "$1.$2 or $3");
  if (enabled.has(23)) {
    s = s.replace(/\[\]\s*\+\+\s*([A-Za-z_][\w'.-]*)/g, "$1");
    s = s.replace(/([A-Za-z_][\w'.-]*)\s*\+\+\s*\[\]/g, "$1");
  }
  return s;
}

function diffText(name, before, after) {
  try {
    const tmp = fs.mkdtempSync("/tmp/statix-js-");
    const a = path.join(tmp, "a");
    const b = path.join(tmp, "b");
    fs.writeFileSync(a, before);
    fs.writeFileSync(b, after);
    let d = "";
    try { d = cp.execFileSync("diff", ["-u", "--label", name, "--label", `${name} [fixed]`, a, b], { encoding: "utf8" }); }
    catch (e) { d = e.stdout || ""; }
    fs.rmSync(tmp, { recursive: true, force: true });
    return d;
  } catch {
    return `--- ${name}\n+++ ${name} [fixed]\n`;
  }
}

main();
