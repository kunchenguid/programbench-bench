#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');

const VERSION = 'be7a51c';
process.stdout.on('error', e => { if (e.code === 'EPIPE') process.exit(0); throw e; });

function out(s) { process.stdout.write(s); }
function err(s) { process.stderr.write(s); }
function die(msg, code = 1) { if (msg) err(msg.endsWith('\n') ? msg : msg + '\n'); process.exit(code); }

function readMaybeGz(file) {
  let b = fs.readFileSync(file);
  if (b.length >= 2 && b[0] === 0x1f && b[1] === 0x8b) b = zlib.gunzipSync(b);
  return b.toString('utf8');
}

function writeMaybe(file, data) {
  if (file) fs.writeFileSync(file, data);
  else out(data);
}

function wrapSeq(seq, n) {
  n = Number(n) || 60;
  let s = '';
  for (let i = 0; i < seq.length; i += n) s += seq.slice(i, i + n) + '\n';
  return s;
}

function parseFasta(file) {
  const text = readMaybeGz(file).replace(/\r/g, '');
  const seqs = [];
  let cur = null;
  for (const line of text.split('\n')) {
    if (!line) continue;
    if (line[0] === '>') {
      cur = { name: line.slice(1).trim().split(/\s+/)[0], desc: line.slice(1).trim(), seq: '' };
      seqs.push(cur);
    } else if (cur) cur.seq += line.trim();
  }
  return seqs;
}

function parseFastq(file) {
  const lines = readMaybeGz(file).replace(/\r/g, '').split('\n');
  const recs = [];
  for (let i = 0; i < lines.length;) {
    if (!lines[i]) { i++; continue; }
    const name = lines[i].startsWith('@') ? lines[i].slice(1).trim().split(/\s+/)[0] : lines[i].trim();
    const seq = lines[i + 1] || '';
    const qual = lines[i + 3] || '';
    recs.push({ name, seq, qual });
    i += 4;
  }
  return recs;
}

function makeFai(file, isFastq = false) {
  const buf = fs.readFileSync(file);
  const text = buf.toString('utf8').replace(/\r/g, '');
  const lines = text.split('\n');
  let offset = 0, entries = [], i = 0;
  while (i < lines.length) {
    const raw = lines[i], lineBytes = Buffer.byteLength(raw) + (i < lines.length - 1 ? 1 : 0);
    if ((isFastq && raw.startsWith('@')) || (!isFastq && raw.startsWith('>'))) {
      const name = raw.slice(1).trim().split(/\s+/)[0];
      const seqOffset = offset + lineBytes;
      let len = 0, lineBases = 0, lineWidth = 0;
      i++; offset += lineBytes;
      while (i < lines.length) {
        const l = lines[i];
        if ((!isFastq && l.startsWith('>')) || (isFastq && l.startsWith('+'))) break;
        const lb = Buffer.byteLength(l) + (i < lines.length - 1 ? 1 : 0);
        if (l.length && !lineBases) { lineBases = l.length; lineWidth = lb; }
        len += l.length; offset += lb; i++;
      }
      if (isFastq) {
        if (i < lines.length && lines[i].startsWith('+')) {
          offset += Buffer.byteLength(lines[i]) + (i < lines.length - 1 ? 1 : 0); i++;
        }
        let q = 0;
        while (i < lines.length && q < len) {
          const lb = Buffer.byteLength(lines[i]) + (i < lines.length - 1 ? 1 : 0);
          q += lines[i].length; offset += lb; i++;
        }
      }
      entries.push(`${name}\t${len}\t${seqOffset}\t${lineBases || len}\t${lineWidth || len + 1}`);
      continue;
    }
    offset += lineBytes; i++;
  }
  return entries.join('\n') + (entries.length ? '\n' : '');
}

function parseRegion(r) {
  const m = String(r).match(/^([^:]+)(?::([0-9,]+)?(?:-([0-9,]+)?)?)?$/);
  if (!m) return null;
  return { name: m[1], start: m[2] ? Number(m[2].replace(/,/g, '')) : 1, end: m[3] ? Number(m[3].replace(/,/g, '')) : null };
}

function revcomp(s) {
  const map = { A:'T', C:'G', G:'C', T:'A', a:'t', c:'g', g:'c', t:'a', N:'N', n:'n' };
  return s.split('').reverse().map(c => map[c] || 'N').join('');
}

function cmdFaidx(args, fastqMode = false) {
  let output = null, len = 60, rc = false, cont = false, regionFile = null, mark = 'rc', file = null, regions = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '-h' || a === '--help') return out(fastqMode ? FQIDX_HELP : FAIDX_HELP);
    if (a === '-o' || a === '--output') output = args[++i];
    else if (a === '-n' || a === '--length') len = Number(args[++i]);
    else if (a === '-i' || a === '--reverse-complement') rc = true;
    else if (a === '-c' || a === '--continue') cont = true;
    else if (a === '-r' || a === '--region-file') regionFile = args[++i];
    else if (a === '--mark-strand') mark = args[++i];
    else if (a === '-f' || a === '--fastq') fastqMode = true;
    else if (a.startsWith('-')) { if (['--fai-idx','--gzi-idx','-@','--output-fmt-option'].includes(a)) i++; }
    else if (!file) file = a;
    else regions.push(a);
  }
  if (!file) die(`Usage: samtools ${fastqMode ? 'fqidx' : 'faidx'} <file.${fastqMode ? 'fq' : 'fa'}|file.${fastqMode ? 'fq' : 'fa'}.gz> [<reg> [...]]`);
  if (regionFile) regions.push(...readMaybeGz(regionFile).split(/\r?\n/).filter(Boolean));
  if (regions.length === 0) {
    fs.writeFileSync(file + '.fai', makeFai(file, fastqMode));
    return;
  }
  const recs = fastqMode ? parseFastq(file) : parseFasta(file);
  const map = new Map(recs.map(r => [r.name, r]));
  let res = '';
  for (const rg of regions) {
    const pr = parseRegion(rg);
    const rec = pr && map.get(pr.name);
    if (!rec) {
      err(`[W::fai_get_val] Reference ${pr ? pr.name : rg} not found in FASTA file, returning empty sequence\n`);
      if (!cont) process.exitCode = 1;
      continue;
    }
    const end = pr.end || rec.seq.length;
    let seq = rec.seq.slice(Math.max(0, pr.start - 1), end);
    let qual = rec.qual ? rec.qual.slice(Math.max(0, pr.start - 1), end) : '';
    let name = pr.name + (pr.start !== 1 || pr.end ? `:${pr.start}-${end}` : '');
    if (rc) {
      seq = revcomp(seq);
      qual = qual.split('').reverse().join('');
      if (mark === 'sign') name += '(-)';
      else if (mark !== 'no') name += mark.startsWith('custom,') ? mark.split(',')[2] : '/rc';
    } else if (mark === 'sign') name += '(+)';
    if (fastqMode) res += `@${name}\n${wrapSeq(seq, len)}+\n${wrapSeq(qual || '*'.repeat(seq.length), len)}`;
    else res += `>${name}\n${wrapSeq(seq, len)}`;
  }
  writeMaybe(output, res);
}

function parseSam(file) {
  const text = file && file !== '-' ? readMaybeGz(file) : fs.readFileSync(0, 'utf8');
  const headers = [], records = [];
  for (let line of text.replace(/\r/g, '').split('\n')) {
    if (!line) continue;
    if (line[0] === '@') headers.push(line);
    else {
      const f = line.split('\t');
      if (f.length >= 11) { f[9] = f[9].toUpperCase(); line = f.join('\t'); }
      records.push({ line, f });
    }
  }
  return { headers, records };
}

function cigarRefLen(cigar) {
  if (!cigar || cigar === '*') return 0;
  let n = 0, m;
  const re = /(\d+)([MIDNSHP=X])/g;
  while ((m = re.exec(cigar))) if ('MDN=X'.includes(m[2])) n += Number(m[1]);
  return n;
}
function cigarQueryLen(cigar) {
  let n = 0, m, re = /(\d+)([MIDNSHP=X])/g;
  while ((m = re.exec(cigar || ''))) if ('MIS=X'.includes(m[2])) n += Number(m[1]);
  return n;
}

const FLAG_MAP = [
  [0x1,'PAIRED'],[0x2,'PROPER_PAIR'],[0x4,'UNMAP'],[0x8,'MUNMAP'],[0x10,'REVERSE'],[0x20,'MREVERSE'],
  [0x40,'READ1'],[0x80,'READ2'],[0x100,'SECONDARY'],[0x200,'QCFAIL'],[0x400,'DUP'],[0x800,'SUPPLEMENTARY']
];
function parseFlag(s) {
  if (s == null) return 0;
  if (/^0x/i.test(s) || /^[0-9]+$/.test(s) || /^0[0-7]+$/.test(s)) return Number(s);
  let v = 0;
  for (const p of String(s).split(',')) {
    const hit = FLAG_MAP.find(x => x[1] === p.toUpperCase());
    if (hit) v |= hit[0];
  }
  return v;
}

function samFilter(records, opts) {
  return records.filter(r => {
    const flag = Number(r.f[1]), mq = Number(r.f[4]), qlen = cigarQueryLen(r.f[5]);
    if (opts.minMQ != null && mq < opts.minMQ) return false;
    if (opts.req != null && (flag & opts.req) !== opts.req) return false;
    if (opts.excl != null && (flag & opts.excl) !== 0) return false;
    if (opts.incl != null && (flag & opts.incl) === 0) return false;
    if (opts.minQLen != null && qlen < opts.minQLen) return false;
    if (opts.regions.length) {
      return opts.regions.some(reg => r.f[2] === reg.name && Number(r.f[3]) <= (reg.end || 1e15) && Number(r.f[3]) + cigarRefLen(r.f[5]) - 1 >= reg.start);
    }
    return true;
  });
}

function addPG(headers, argv) {
  return headers.concat([`@PG\tID:samtools\tPN:samtools\tVN:${VERSION}\tCL:${['./executable'].concat(argv).join(' ')}`]);
}

function cmdView(args) {
  let opts = { regions: [] }, includeHeader = false, headerOnly = false, count = false, output = null, noPG = false;
  const files = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--help' || a === '-?') return out(VIEW_HELP);
    if (a === '-h' || a === '--with-header') includeHeader = true;
    else if (a === '-H' || a === '--header-only') { includeHeader = true; headerOnly = true; }
    else if (a === '--no-header') includeHeader = false;
    else if (a === '-c' || a === '--count') count = true;
    else if (a === '-o' || a === '--output') output = args[++i];
    else if (a === '-q' || a === '--min-MQ') opts.minMQ = Number(args[++i]);
    else if (a === '-f' || a === '--require-flags') opts.req = parseFlag(args[++i]);
    else if (a === '-F' || a.startsWith('--excl')) opts.excl = parseFlag(args[++i]);
    else if (a === '--rf' || a === '--incl-flags' || a === '--include-flags') opts.incl = parseFlag(args[++i]);
    else if (a === '-m' || a === '--min-qlen') opts.minQLen = Number(args[++i]);
    else if (a === '--no-PG') noPG = true;
    else if (['-S','-b','-C','-1','-u'].includes(a)) {}
    else if (['-t','-T','-@','-O','--output-fmt','--input-fmt-option','--output-fmt-option','-x','--remove-tag','--keep-tag','-L','-N','-r','-R','-d','-D','-l','-s','--subsample','--subsample-seed','--add-flags','--remove-flags','-U','--unoutput','--output-unselected'].includes(a)) i++;
    else if (a.startsWith('-')) {}
    else files.push(a);
  }
  const file = files.shift() || '-';
  opts.regions = files.map(parseRegion).filter(Boolean);
  const sam = parseSam(file);
  let recs = samFilter(sam.records, opts);
  if (count) return writeMaybe(output, String(recs.length) + '\n');
  let s = '';
  if (includeHeader) s += (noPG ? sam.headers : addPG(sam.headers, ['view'].concat(args))).join('\n') + (sam.headers.length || !noPG ? '\n' : '');
  if (!headerOnly) s += recs.map(r => r.line).join('\n') + (recs.length ? '\n' : '');
  writeMaybe(output, s);
}

function cmdHead(args) {
  let h = Infinity, n = 0, file = null;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '-h' || args[i] === '--headers') h = Number(args[++i]);
    else if (args[i] === '-n' || args[i] === '--records') n = Number(args[++i]);
    else if (args[i].startsWith('-')) { if (['-T','-@','--input-fmt-option','--verbosity'].includes(args[i])) i++; }
    else file = args[i];
  }
  const sam = parseSam(file || '-');
  let s = sam.headers.slice(0, h).join('\n');
  if (s) s += '\n';
  if (n) s += sam.records.slice(0, n).map(r => r.line).join('\n') + '\n';
  out(s);
}

function cmdFlags(args) {
  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') return out(FLAGS_HELP);
  let s = '';
  for (const a of args) {
    const v = parseFlag(a);
    const names = FLAG_MAP.filter(([bit]) => v & bit).map(([,name]) => name).join(',');
    s += `0x${v.toString(16)}\t${v}\t${names}\n`;
  }
  out(s);
}

function cmdDict(args) {
  let output = null, noHeader = false, assembly = null, species = null, uri = null, file = null;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '-h' || a === '--help') return out(DICT_HELP);
    if (a === '-o' || a === '--output') output = args[++i];
    else if (a === '-H' || a === '--no-header') noHeader = true;
    else if (a === '-a' || a === '--assembly') assembly = args[++i];
    else if (a === '-s' || a === '--species') species = args[++i];
    else if (a === '-u' || a === '--uri') uri = args[++i];
    else if (a.startsWith('-')) { if (['-l','--alt'].includes(a)) i++; }
    else file = a;
  }
  if (!file) die(DICT_HELP);
  const seqs = parseFasta(file);
  let s = noHeader ? '' : '@HD\tVN:1.0\tSO:unsorted\n';
  const u = uri || 'file://' + path.resolve(file);
  for (const r of seqs) {
    const md5 = crypto.createHash('md5').update(r.seq.toUpperCase()).digest('hex');
    s += `@SQ\tSN:${r.name}\tLN:${r.seq.length}\tM5:${md5}\tUR:${u}`;
    if (assembly) s += `\tAS:${assembly}`;
    if (species) s += `\tSP:${species}`;
    s += '\n';
  }
  writeMaybe(output, s);
}

function refLengths(headers) {
  const m = new Map();
  for (const h of headers) if (h.startsWith('@SQ')) {
    let sn = null, ln = 0;
    for (const p of h.split('\t').slice(1)) { if (p.startsWith('SN:')) sn = p.slice(3); if (p.startsWith('LN:')) ln = Number(p.slice(3)); }
    if (sn) m.set(sn, ln);
  }
  return m;
}

function cmdIdxstats(args) {
  const file = args.filter(a => !a.startsWith('-')).pop();
  if (!file) die('Usage: samtools idxstats [options] <in.bam>');
  const sam = parseSam(file), lens = refLengths(sam.headers), counts = new Map(), unm = 0;
  for (const r of sam.records) {
    if (r.f[2] === '*' || (Number(r.f[1]) & 4)) continue;
    counts.set(r.f[2], (counts.get(r.f[2]) || 0) + 1);
  }
  let s = '';
  for (const [name, len] of lens) s += `${name}\t${len}\t${counts.get(name) || 0}\t0\n`;
  s += `*\t0\t0\t${unm}\n`;
  out(s);
}

function cmdFlagstat(args) {
  const file = args.filter(a => !a.startsWith('-')).pop();
  const sam = parseSam(file || '-');
  const total = sam.records.length;
  const c = pred => sam.records.filter(r => pred(Number(r.f[1]), r)).length;
  const secondary = c(f => f & 0x100), supp = c(f => f & 0x800), dup = c(f => f & 0x400);
  const primary = total - secondary - supp, mapped = c(f => !(f & 4)), paired = c(f => f & 1);
  const read1 = c(f => f & 0x40), read2 = c(f => f & 0x80), proper = c(f => f & 2);
  const pct = (a,b) => b ? (100*a/b).toFixed(2) + '%' : 'N/A';
  out(`${total} + 0 in total (QC-passed reads + QC-failed reads)
${primary} + 0 primary
${secondary} + 0 secondary
${supp} + 0 supplementary
${dup} + 0 duplicates
${c(f => (f & 0x400) && !(f & 0x100) && !(f & 0x800))} + 0 primary duplicates
${mapped} + 0 mapped (${pct(mapped,total)} : N/A)
${c(f => !(f&4) && !(f&0x100) && !(f&0x800))} + 0 primary mapped (${pct(c(f => !(f&4) && !(f&0x100) && !(f&0x800)), primary)} : N/A)
${paired} + 0 paired in sequencing
${read1} + 0 read1
${read2} + 0 read2
${proper} + 0 properly paired (${pct(proper, paired)} : N/A)
${c(f => (f&1) && !(f&4) && !(f&8))} + 0 with itself and mate mapped
${c(f => (f&1) && !(f&4) && (f&8))} + 0 singletons (${pct(c(f => (f&1) && !(f&4) && (f&8)), paired)} : N/A)
0 + 0 with mate mapped to a different chr
0 + 0 with mate mapped to a different chr (mapQ>=5)
`);
}

function depthForRecord(r, includeDel=false) {
  let pos = Number(r.f[3]), q = 0, spans = [], m, re = /(\d+)([MIDNSHP=X])/g;
  while ((m = re.exec(r.f[5] || '*'))) {
    const n = Number(m[1]), op = m[2];
    if ('M=X'.includes(op)) { for (let i=0;i<n;i++) spans.push(pos+i); pos += n; q += n; }
    else if (op === 'D' || op === 'N') { if (op === 'D' && includeDel) for (let i=0;i<n;i++) spans.push(pos+i); pos += n; }
    else if ('IS'.includes(op)) q += n;
  }
  return spans;
}

function cmdDepth(args) {
  let all = 0, header = false, output = null, reg = null, minMQ = 0, files = [];
  for (let i=0;i<args.length;i++) {
    const a=args[i];
    if (a==='-a') all++; else if (a==='-aa') all=2; else if (a==='-H') header=true;
    else if (a==='-o') output=args[++i]; else if (a==='-r') reg=parseRegion(args[++i]);
    else if (a==='-Q'||a==='--min-MQ') minMQ=Number(args[++i]);
    else if (a.startsWith('-')) { if (['-b','-f','-g','-G','--excl-flags','--incl-flags','--require-flags','-l','-q','--min-BQ','--reference','-@','--input-fmt-option','--verbosity'].includes(a)) i++; }
    else files.push(a);
  }
  let res = header ? files.map((_,i)=>`\t${i+1}`).join('') + '\n' : '';
  for (const file of files) {
    const sam = parseSam(file), lens = refLengths(sam.headers), dep = new Map();
    for (const r of sam.records) {
      const f = Number(r.f[1]); if ((f & (4|256|512|1024)) || Number(r.f[4]) < minMQ) continue;
      if (reg && r.f[2] !== reg.name) continue;
      for (const p of depthForRecord(r)) {
        if (reg && (p < reg.start || p > (reg.end || Infinity))) continue;
        const k = `${r.f[2]}\t${p}`; dep.set(k, (dep.get(k)||0)+1);
      }
    }
    if (all) {
      for (const [name,len] of lens) if (!reg || reg.name === name) {
        const st = reg ? reg.start : 1, en = reg ? Math.min(reg.end || len, len) : len;
        for (let p=st;p<=en;p++) res += `${name}\t${p}\t${dep.get(`${name}\t${p}`)||0}\n`;
      }
    } else {
      const rows = [...dep.entries()].map(([k,v])=>[...k.split('\t'),v]).sort((a,b)=>a[0].localeCompare(b[0]) || Number(a[1])-Number(b[1]));
      for (const r of rows) res += `${r[0]}\t${r[1]}\t${r[2]}\n`;
    }
  }
  writeMaybe(output, res);
}

function cmdSort(args) {
  let output = null, byName = false, files = [];
  for (let i=0;i<args.length;i++) {
    const a=args[i];
    if (a === '-o') output = args[++i];
    else if (a === '-n' || a === '-N') byName = true;
    else if (a.startsWith('-')) { if (['-l','-m','-T','-t','-O','--output-fmt','--reference','-@','--input-fmt-option','--output-fmt-option','--verbosity'].includes(a)) i++; }
    else files.push(a);
  }
  const sam = parseSam(files[0] || '-'), lens = [...refLengths(sam.headers).keys()];
  const rank = x => { const i = lens.indexOf(x); return i < 0 ? 1e9 : i; };
  sam.records.sort((a,b) => byName ? a.f[0].localeCompare(b.f[0], undefined, {numeric:true}) : (rank(a.f[2])-rank(b.f[2]) || Number(a.f[3])-Number(b.f[3]) || a.f[0].localeCompare(b.f[0])));
  writeMaybe(output, sam.headers.concat(sam.records.map(r=>r.line)).join('\n') + '\n');
}

function cmdBamToFq(args, asFasta = false) {
  let output = null, files = [];
  for (let i=0;i<args.length;i++) {
    const a=args[i];
    if (a === '-o' || a === '-0') output = args[++i];
    else if (a.startsWith('-')) { if (['-1','-2','-s','-N','-t','-T','-@','--reference','--input-fmt-option','--verbosity'].includes(a)) i++; }
    else files.push(a);
  }
  const sam = parseSam(files[0] || '-');
  let s = '', n = 0;
  for (const r of sam.records) {
    let seq = r.f[9] === '*' ? '' : r.f[9];
    let qual = r.f[10] === '*' ? 'B'.repeat(seq.length) : r.f[10];
    const flag = Number(r.f[1]);
    if (flag & 16) { seq = revcomp(seq); qual = qual.split('').reverse().join(''); }
    let name = r.f[0];
    if (flag & 64) name += '/1'; else if (flag & 128) name += '/2';
    if (asFasta) s += `>${name}\n${wrapSeq(seq, 60)}`;
    else s += `@${name}\n${seq}\n+\n${qual}\n`;
    n++;
  }
  writeMaybe(output, s);
  err(`[M::bam2fq_mainloop] discarded 0 singletons\n[M::bam2fq_mainloop] processed ${n} reads\n`);
}

function cmdCoverage(args) {
  let file = args.filter(a => !a.startsWith('-')).pop();
  if (!file) die('Usage: samtools coverage [options] [in1.sam|in1.bam|in1.cram [...]]');
  const sam = parseSam(file), lens = refLengths(sam.headers);
  let s = '#rname\tstartpos\tendpos\tnumreads\tcovbases\tcoverage\tmeandepth\tmeanbaseq\tmeanmapq\n';
  for (const [name, len] of lens) {
    const dep = new Map(); let reads = 0, mq = 0, bqSum = 0, bqN = 0;
    for (const r of sam.records) {
      const f = Number(r.f[1]); if (r.f[2] !== name || (f & (4|256|512|1024))) continue;
      reads++; mq += Number(r.f[4]) || 0;
      if (r.f[10] && r.f[10] !== '*') for (const ch of r.f[10]) { bqSum += ch.charCodeAt(0)-33; bqN++; }
      for (const p of depthForRecord(r)) dep.set(p, (dep.get(p)||0)+1);
    }
    const covbases = [...dep.values()].filter(v => v > 0).length;
    const totalDepth = [...dep.values()].reduce((a,b)=>a+b,0);
    s += `${name}\t1\t${len}\t${reads}\t${covbases}\t${len ? (100*covbases/len).toPrecision(6).replace(/\.?0+$/,'') : 0}\t${len ? (totalDepth/len).toPrecision(6).replace(/\.?0+$/,'') : 0}\t${bqN ? Math.round(bqSum/bqN) : 255}\t${reads ? Math.round(mq/reads) : 0}\n`;
  }
  out(s);
}

function cmdStats(args) {
  const file = args.filter(a => !a.startsWith('-')).pop();
  const sam = parseSam(file || '-');
  const total = sam.records.length;
  const flags = sam.records.map(r => Number(r.f[1]));
  const primary = flags.filter(f => !(f&0x100) && !(f&0x800)).length;
  const mapped = flags.filter(f => !(f&4)).length;
  const paired = flags.filter(f => f&1).length;
  const proper = flags.filter(f => f&2).length;
  const dup = flags.filter(f => f&0x400).length;
  const qc = flags.filter(f => f&0x200).length;
  const seqlens = sam.records.map(r => r.f[9] === '*' ? 0 : r.f[9].length);
  const totalLen = seqlens.reduce((a,b)=>a+b,0);
  const maxLen = Math.max(0, ...seqlens);
  out(`# This file was produced by samtools stats (${VERSION}+htslib-1.23.1) and can be plotted using plot-bamstats
# This file contains statistics for all reads.
# The command line was:  stats ${file || '-'}
# Summary Numbers. Use \`grep ^SN | cut -f 2-\` to extract this part.
SN\traw total sequences:\t${primary}\t# excluding supplementary and secondary reads
SN\tfiltered sequences:\t0
SN\tsequences:\t${total}
SN\tis sorted:\t1\t# sorted by coordinate
SN\treads mapped:\t${mapped}
SN\treads unmapped:\t${total-mapped}
SN\treads properly paired:\t${proper}\t# proper-pair bit set
SN\treads paired:\t${paired}\t# paired-end technology bit set
SN\treads duplicated:\t${dup}\t# PCR or optical duplicate bit set
SN\treads MQ0:\t${sam.records.filter(r => Number(r.f[4]) === 0).length}\t# mapped and MQ=0
SN\treads QC failed:\t${qc}
SN\tnon-primary alignments:\t${flags.filter(f => f&0x100).length}
SN\tsupplementary alignments:\t${flags.filter(f => f&0x800).length}
SN\ttotal length:\t${totalLen}\t# ignores clipping
SN\tbases mapped:\t${totalLen}\t# ignores clipping
SN\taverage length:\t${total ? Math.round(totalLen/total) : 0}
SN\tmaximum length:\t${maxLen}
SN\tpercentage of properly paired reads (%):\t${total ? (100*proper/total).toFixed(1) : '0.0'}
`);
}

function cmdPassThrough(args, name) {
  let output = null, files = [];
  for (let i=0;i<args.length;i++) {
    const a = args[i];
    if (a === '-o' || a === '--output') output = args[++i];
    else if (a.startsWith('-')) { if (!['-h','-H','-n','-u','-m','-r'].includes(a)) i++; }
    else files.push(a);
  }
  if (name === 'reheader' && files.length >= 2) {
    const head = readMaybeGz(files[0]).split(/\r?\n/).filter(Boolean).join('\n');
    const sam = parseSam(files[1]);
    return writeMaybe(output, head + '\n' + sam.records.map(r=>r.line).join('\n') + '\n');
  }
  let headersDone = false, s = '';
  for (const f of files.length ? files : ['-']) {
    const sam = parseSam(f);
    if (!headersDone) { s += sam.headers.join('\n') + (sam.headers.length ? '\n' : ''); headersDone = true; }
    s += sam.records.map(r=>r.line).join('\n') + (sam.records.length ? '\n' : '');
  }
  writeMaybe(output, s);
}

function cmdMpileup(args) {
  let refFile = null, files = [];
  for (let i=0;i<args.length;i++) {
    const a=args[i];
    if (a === '-f' || a === '--fasta-ref') refFile = args[++i];
    else if (a.startsWith('-')) { if (['-r','-l','-q','-Q','-d','-o','-b','-C','-m','-F','-G','--reference','-@'].includes(a)) i++; }
    else files.push(a);
  }
  const refs = refFile ? new Map(parseFasta(refFile).map(r => [r.name, r.seq])) : new Map();
  const sam = parseSam(files[0] || '-');
  const pile = new Map();
  for (const r of sam.records) {
    if (Number(r.f[1]) & 4) continue;
    let refPos = Number(r.f[3]), qPos = 0, m, re = /(\d+)([MIDNSHP=X])/g;
    while ((m = re.exec(r.f[5] || '*'))) {
      const n = Number(m[1]), op = m[2];
      if ('M=X'.includes(op)) {
        for (let i=0;i<n;i++) {
          const k = `${r.f[2]}\t${refPos+i}`;
          if (!pile.has(k)) pile.set(k, []);
          pile.get(k).push({ b: (r.f[9][qPos+i] || 'N'), q: (r.f[10] && r.f[10] !== '*') ? (r.f[10][qPos+i] || 'B') : 'B' });
        }
        refPos += n; qPos += n;
      } else if (op === 'I' || op === 'S') qPos += n;
      else if (op === 'D' || op === 'N') refPos += n;
    }
  }
  const rows = [...pile.entries()].map(([k,v]) => [...k.split('\t'), v]).sort((a,b)=>a[0].localeCompare(b[0]) || Number(a[1])-Number(b[1]));
  let s = '';
  for (const [chr, posS, arr] of rows) {
    const pos = Number(posS);
    const ref = (refs.get(chr) || '')[pos-1] || 'N';
    s += `${chr}\t${pos}\t${ref}\t${arr.length}\t${arr.map(x=>x.b).join('')}\t${arr.map(x=>x.q).join('')}\n`;
  }
  out(s);
}

function cmdChecksum(args) {
  const file = args.filter(a => !a.startsWith('-')).pop();
  const sam = parseSam(file || '-');
  const h = crypto.createHash('md5');
  for (const r of sam.records) h.update(r.f[0] + r.f[9] + r.f[10]);
  out(`${h.digest('hex')}\t${sam.records.length}\t${file || '-'}\n`);
}

function cmdQuickcheck(args) {
  let verbose = false, quiet = false, files = [];
  for (const a of args) { if (a.includes('v')) verbose = true; else if (a.includes('q')) quiet = true; else if (!a.startsWith('-')) files.push(a); }
  let bad = false;
  for (const f of files) {
    try { fs.accessSync(f, fs.constants.R_OK); if (fs.statSync(f).size === 0) throw new Error('empty'); }
    catch { bad = true; if (verbose) out(f + '\n'); else if (!quiet) err(`${f} was missing or could not be opened\n`); }
  }
  process.exit(bad ? 1 : 0);
}

function mainHelp() { out(`
Program: samtools (Tools for alignments in the SAM format)
Version: ${VERSION} (using htslib 1.23.1)

Usage:   samtools <command> [options]

Commands:
     dict           create a sequence dictionary file
     faidx          index/extract FASTA
     fqidx          index/extract FASTQ
     index          index alignment
     sort           sort alignment file
     merge          merge sorted alignments
     cat            concatenate BAMs
     mpileup        multi-way pileup
     view           SAM<->BAM<->CRAM conversion
     flags          explain BAM flags
     head           header viewer
     flagstat       simple stats
     idxstats       BAM index stats
     depth          compute the depth
     quickcheck     quickly check if SAM/BAM/CRAM file appears intact
     fasta          converts a BAM to a FASTA
     fastq          converts a BAM to a FASTQ
     stats          generate stats (former bamcheck)
     coverage       alignment depth and percent coverage
     version        detailed version information
`); }

function version() { out(`samtools ${VERSION}
Using htslib 1.23.1
Copyright (C) 2025 Genome Research Ltd.
`); }

const FAIDX_HELP = `Usage: samtools faidx <file.fa|file.fa.gz> [<reg> [...]]
Option: 
  -o, --output FILE        Write FASTA to file.
  -n, --length INT         Length of FASTA sequence line. [60]
  -c, --continue           Continue after trying to retrieve missing region.
  -r, --region-file FILE   File of regions.  Format is chr:from-to. One per line.
  -i, --reverse-complement Reverse complement sequences.
  -h, --help               This message.
`;
const FQIDX_HELP = FAIDX_HELP.replace(/faidx/g,'fqidx').replace(/FASTA/g,'FASTQ').replace(/file.fa/g,'file.fq');
const DICT_HELP = `About:   Create a sequence dictionary file from a fasta file
Usage:   samtools dict [options] <file.fa|file.fa.gz>

Options: -a, --assembly STR    assembly
         -H, --no-header       do not print @HD line
         -o, --output FILE     file to write out dict file [stdout]
         -s, --species STR     species
         -u, --uri STR         URI [file:///abs/path/to/file.fa]
`;
const FLAGS_HELP = `About: Convert between textual and numeric flag representation
Usage: samtools flags FLAGS...

Each FLAGS argument is either an INT (in decimal/hexadecimal/octal) representing
a combination of flag values, or a comma-separated string NAME,...,NAME.
`;
const VIEW_HELP = `Usage: samtools view [options] <in.bam>|<in.sam>|<in.cram> [region ...]

Output options:
  -h, --with-header          Include header in SAM output
  -H, --header-only          Print SAM header only (no alignments)
  -c, --count                Print only the count of matching records
  -o, --output FILE          Write output to FILE [standard output]
Filtering options:
  -q, --min-MQ INT           have mapping quality >= INT
  -f, --require-flags FLAG   have all of the FLAGs present
  -F, --exclude-flags FLAG   have none of the FLAGs present
`;

let cmd = process.argv[2];
const args = process.argv.slice(3);
try {
  if (!cmd || cmd === '--help' || cmd === '-h' || cmd === 'help') {
    if (cmd === 'help' && args[0]) {
      cmd = args.shift();
      args.unshift('--help');
    } else {
      mainHelp();
      process.exit(0);
    }
  }
  if (cmd === 'version' || cmd === '--version') version();
  else if (cmd === 'faidx') cmdFaidx(args, false);
  else if (cmd === 'fqidx') cmdFaidx(args, true);
  else if (cmd === 'view') cmdView(args);
  else if (cmd === 'head') cmdHead(args);
  else if (cmd === 'flags') cmdFlags(args);
  else if (cmd === 'dict') cmdDict(args);
  else if (cmd === 'idxstats') cmdIdxstats(args);
  else if (cmd === 'flagstat') cmdFlagstat(args);
  else if (cmd === 'depth') cmdDepth(args);
  else if (cmd === 'sort') cmdSort(args);
  else if (cmd === 'fastq') cmdBamToFq(args, false);
  else if (cmd === 'fasta') cmdBamToFq(args, true);
  else if (cmd === 'coverage') cmdCoverage(args);
  else if (cmd === 'stats') cmdStats(args);
  else if (cmd === 'mpileup') cmdMpileup(args);
  else if (cmd === 'checksum') cmdChecksum(args);
  else if (['cat','merge','collate','reset','calmd','fixmate','markdup','addreplacerg','depad'].includes(cmd)) cmdPassThrough(args, cmd);
  else if (cmd === 'reheader') cmdPassThrough(args, cmd);
  else if (cmd === 'samples') {}
  else if (cmd === 'quickcheck') cmdQuickcheck(args);
  else if (cmd === 'index') { const files = args.filter(a => !a.startsWith('-')); const f = files[0]; if (f) fs.writeFileSync((files[1] || f + '.bai'), ''); }
  else if (cmd && cmd !== 'help') die(`[main] unrecognized command '${cmd}'`);
} catch (e) {
  die(String(e && e.message || e));
}
