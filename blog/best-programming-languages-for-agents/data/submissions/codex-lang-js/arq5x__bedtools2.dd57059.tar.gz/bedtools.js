#!/usr/bin/env node
'use strict';

const fs = require('fs');
const zlib = require('zlib');

const VERSION = 'bedtools v2.31.1';
process.stdout.on('error', err => {
  if (err && err.code === 'EPIPE') process.exit(0);
  throw err;
});

function die(msg, code = 1) {
  if (msg) process.stderr.write(String(msg).replace(/\n?$/, '\n'));
  process.exit(code);
}

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') return help();
  if (args[0] === '--version') return console.log(VERSION);
  if (args[0] === '--contact') return console.log('For help, see http://bedtools.readthedocs.io/ or https://github.com/arq5x/bedtools2');
  const cmd = args.shift();
  try {
    if (cmd === 'intersect' || cmd === 'intersectBed') return intersect(args);
    if (cmd === 'merge' || cmd === 'mergeBed') return merge(args);
    if (cmd === 'complement' || cmd === 'complementBed') return complement(args);
    if (cmd === 'genomecov' || cmd === 'genomeCoverageBed') return genomecov(args);
    if (cmd === 'sort' || cmd === 'sortBed') return sortcmd(args);
    if (cmd === 'subtract' || cmd === 'subtractBed') return subtract(args);
    if (cmd === 'coverage' || cmd === 'coverageBed') return coverage(args);
    if (cmd === 'closest' || cmd === 'closestBed') return closest(args);
    if (cmd === 'jaccard') return jaccard(args);
    if (cmd === 'window' || cmd === 'windowBed') return windowcmd(args);
    if (cmd === 'slop') return slop(args);
    if (cmd === 'flank') return flank(args);
    if (cmd === 'makewindows') return makewindows(args);
    if (cmd === 'groupby' || cmd === 'groupBy') return groupby(args);
    if (cmd === 'map') return mapcmd(args);
    if (cmd === 'sample') return samplecmd(args);
    if (cmd === 'spacing') return spacing(args);
    if (cmd === 'overlap') return overlapcmd(args);
    die(`*****ERROR: Unrecognized command: ${cmd} *****\n`);
  } catch (e) {
    die(e && e.message ? e.message : e);
  }
}

function help() {
  console.log(`bedtools is a powerful toolset for genome arithmetic.

Version:   b2e3657
Usage:     bedtools <subcommand> [options]

The bedtools sub-commands include:
    intersect     Find overlapping intervals in various ways.
    window        Find overlapping intervals within a window around an interval.
    closest       Find the closest, potentially non-overlapping interval.
    coverage      Compute the coverage over defined intervals.
    map           Apply a function to a column for each overlapping interval.
    genomecov     Compute the coverage over an entire genome.
    merge         Combine overlapping/nearby intervals into a single interval.
    complement    Extract intervals _not_ represented by an interval file.
    subtract      Remove intervals based on overlaps b/w two files.
    sort          Order the intervals in a file.
    jaccard       Calculate the Jaccard statistic b/w two sets of intervals.

[ General help ]
    --help        Print this help menu.
    --version     What version of bedtools are you using?.`);
}

function parseArgs(args, spec = {}) {
  const o = { _: [] };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (!a.startsWith('-') || a === '-') { o._.push(a); continue; }
    if (spec.multi && spec.multi.includes(a)) {
      const vals = [];
      i++;
      while (i < args.length && !args[i].startsWith('-')) vals.push(args[i++]);
      i--;
      o[a] = vals;
    } else if (spec.vals && spec.vals.includes(a)) {
      o[a] = args[++i];
    } else {
      o[a] = true;
    }
  }
  return o;
}

function readText(path) {
  if (!path || path === 'stdin' || path === '-') return fs.readFileSync(0);
  let b = fs.readFileSync(path);
  if (path.endsWith('.gz')) b = zlib.gunzipSync(b);
  return b;
}

function lines(path) {
  return readText(path).toString().split(/\r?\n/).filter(l => l.length && !l.startsWith('#') && !l.startsWith('track') && !l.startsWith('browser'));
}

function parseFile(path) {
  return lines(path).map((line, idx) => parseRec(line, idx)).filter(Boolean);
}

function parseRec(line, idx = 0) {
  const f = line.split('\t');
  if (f.length < 3) return null;
  let chrom = f[0], start = Number(f[1]), end = Number(f[2]);
  if (!Number.isFinite(end) && f.length >= 5 && Number.isFinite(Number(f[3])) && Number.isFinite(Number(f[4]))) {
    start = Number(f[3]) - 1; end = Number(f[4]); // GFF/GTF-style coordinates.
  } else if (!Number.isFinite(end) && f.length >= 5 && Number.isFinite(start)) {
    start = start - 1; end = start + Math.max(1, (f[3] || 'N').length); // VCF POS/REF.
  }
  if (!Number.isFinite(start) || !Number.isFinite(end)) return null;
  return { chrom, start, end, fields: f, line, idx };
}

function out(fields) { process.stdout.write(fields.join('\t') + '\n'); }
function cmp(a, b) { return a.chrom.localeCompare(b.chrom) || a.start - b.start || a.end - b.end; }
function ov(a, b) { return a.chrom === b.chrom ? Math.max(0, Math.min(a.end, b.end) - Math.max(a.start, b.start)) : 0; }
function len(r) { return Math.max(0, r.end - r.start); }

function readGenome(path) {
  const m = new Map(), order = [];
  for (const l of lines(path)) {
    const f = l.split(/\t| +/);
    if (f.length >= 2) { m.set(f[0], +f[1]); order.push(f[0]); }
  }
  return { m, order };
}

function passes(a, b, n, opt) {
  if (n <= 0) return false;
  const f = +(opt['-f'] || 1e-9), F = +(opt['-F'] || 1e-9);
  const af = n / Math.max(1, len(a)), bf = n / Math.max(1, len(b));
  if (opt['-s'] && strand(a) !== strand(b)) return false;
  if (opt['-S'] && strand(a) === strand(b)) return false;
  return opt['-e'] ? (af >= f || bf >= F) : (af >= f && bf >= F);
}
function strand(r) { return r.fields[5] || '.'; }

function intersect(args) {
  if (args.includes('-h')) return console.log('Tool:    bedtools intersect (aka intersectBed)\nUsage:   bedtools intersect [OPTIONS] -a <bed> -b <bed>');
  const opt = parseArgs(args, { vals: ['-a','-f','-F','-g'], multi: ['-b','-names'] });
  if (!opt['-a'] || !opt['-b']) die('***** ERROR: query and database files not specified. *****');
  const A = parseFile(opt['-a']);
  const bFiles = opt['-b'];
  const Bs = bFiles.map(parseFile);
  const labels = opt['-names'] || null;
  for (const a of A) {
    let hits = [];
    for (let bi = 0; bi < Bs.length; bi++) {
      for (const b of Bs[bi]) {
        const n = ov(a, b);
        if (passes(a, b, n, opt)) hits.push({ b, n, bi });
      }
    }
    if (opt['-sortout']) hits.sort((x,y) => cmp(x.b,y.b));
    if (opt['-c']) { out([...a.fields, String(hits.length)]); continue; }
    if (opt['-C']) {
      for (let bi = 0; bi < Bs.length; bi++) out([...a.fields, String(bi + 1), String(hits.filter(h => h.bi === bi).length)]);
      continue;
    }
    if (opt['-v']) { if (!hits.length) out(a.fields); continue; }
    if (opt['-u']) { if (hits.length) out(a.fields); continue; }
    if (!hits.length) {
      if (opt['-wao'] || opt['-loj']) out([...a.fields, '.', '-1', '-1', opt['-wao'] ? '0' : undefined].filter(x => x !== undefined));
      continue;
    }
    for (const h of hits) {
      if (opt['-wo'] || opt['-wao']) out([...a.fields, multiTag(h, bFiles, labels), ...h.b.fields, String(h.n)].filter(x => x !== null));
      else if (opt['-wa'] && opt['-wb']) out([...a.fields, multiTag(h, bFiles, labels), ...h.b.fields].filter(x => x !== null));
      else if (opt['-wa']) out(a.fields);
      else if (opt['-wb']) out([...h.b.fields]);
      else out([a.chrom, String(Math.max(a.start, h.b.start)), String(Math.min(a.end, h.b.end)), ...a.fields.slice(3)]);
    }
  }
}
function multiTag(h, files, labels) { return files.length > 1 ? (labels ? labels[h.bi] : String(h.bi + 1)) : null; }

function merge(args) {
  if (args.includes('-h')) return console.log('Tool:    bedtools merge\nUsage:   bedtools merge -i <bed>');
  const opt = parseArgs(args, { vals: ['-i','-d','-c','-o','-delim'] });
  const d = +(opt['-d'] || 0), delim = opt['-delim'] || ',';
  const recs = parseFile(opt['-i'] || opt._[0]).sort(cmp);
  const groups = [];
  let cur = null, members = [];
  for (const r of recs) {
    if (!cur || r.chrom !== cur.chrom || r.start > cur.end + d) {
      if (cur) groups.push({ cur, members });
      cur = { chrom: r.chrom, start: r.start, end: r.end }; members = [r];
    } else { cur.end = Math.max(cur.end, r.end); members.push(r); }
  }
  if (cur) groups.push({ cur, members });
  const cols = opt['-c'] ? opt['-c'].split(',').map(x => +x - 1) : [];
  const ops = opt['-o'] ? opt['-o'].split(',') : [];
  for (const g of groups) {
    const extra = [];
    if (cols.length) {
      const useOps = ops.length === 1 && cols.length > 1 ? cols.map(() => ops[0]) : ops;
      cols.forEach((c, i) => extra.push(aggregate(g.members.map(r => r.fields[c] ?? ''), useOps[i] || 'count', delim)));
    }
    out([g.cur.chrom, String(g.cur.start), String(g.cur.end), ...extra]);
  }
}

function aggregate(vals, op, delim=',') {
  const nums = vals.map(Number).filter(n => !Number.isNaN(n));
  if (op === 'count' || op === 'count_distinct') return String(op === 'count' ? vals.length : new Set(vals).size);
  if (op === 'collapse') return vals.join(delim);
  if (op === 'distinct') return [...new Set(vals)].join(delim);
  if (op === 'sum') return fmt(nums.reduce((a,b)=>a+b,0));
  if (op === 'mean' || op === 'average') return nums.length ? fmt(nums.reduce((a,b)=>a+b,0) / nums.length) : '.';
  if (op === 'min') return nums.length ? fmt(Math.min(...nums)) : '.';
  if (op === 'max') return nums.length ? fmt(Math.max(...nums)) : '.';
  if (op === 'first') return vals[0] ?? '';
  if (op === 'last') return vals[vals.length - 1] ?? '';
  return vals.join(delim);
}
function fmt(n) { return Number.isInteger(n) ? String(n) : String(+n.toFixed(6)); }

function complement(args) {
  const opt = parseArgs(args, { vals: ['-i','-g'] });
  const genome = readGenome(opt['-g']);
  const recs = parseFile(opt['-i']).sort(cmp);
  for (const chrom of genome.order) {
    let pos = 0;
    for (const r of recs.filter(x => x.chrom === chrom)) {
      if (r.start > pos) out([chrom, String(pos), String(r.start)]);
      pos = Math.max(pos, r.end);
    }
    const gl = genome.m.get(chrom);
    if (pos < gl) out([chrom, String(pos), String(gl)]);
  }
}

function segmentsByChrom(recs) {
  const by = new Map();
  for (const r of recs) { if (!by.has(r.chrom)) by.set(r.chrom, []); by.get(r.chrom).push(r); }
  for (const arr of by.values()) arr.sort((a,b)=>a.start-b.start || a.end-b.end);
  return by;
}

function covSegments(recs, chromLen = null) {
  const pts = [];
  for (const r of recs) { pts.push([r.start, 1]); pts.push([r.end, -1]); }
  pts.sort((a,b)=>a[0]-b[0] || a[1]-b[1]);
  const segs = [];
  let depth = 0, last = null;
  for (const [p, delta] of pts) {
    if (last !== null && p > last && depth > 0) segs.push({ start: last, end: p, depth });
    depth += delta; last = p;
  }
  return segs.filter(s => chromLen == null || (s.end > 0 && s.start < chromLen)).map(s => ({ start: Math.max(0,s.start), end: chromLen == null ? s.end : Math.min(chromLen,s.end), depth: s.depth }));
}

function genomecov(args) {
  const opt = parseArgs(args, { vals: ['-i','-g'] });
  const recs = parseFile(opt['-i'] || opt._[0]);
  const genome = opt['-g'] ? readGenome(opt['-g']) : null;
  const by = segmentsByChrom(recs);
  if (opt['-bg'] || opt['-bga']) {
    const chroms = genome ? genome.order : [...by.keys()].sort();
    for (const chrom of chroms) {
      const gl = genome ? genome.m.get(chrom) : null;
      const segs = covSegments(by.get(chrom) || [], gl);
      if (opt['-bga']) {
        let pos = 0;
        for (const s of segs) { if (s.start > pos) out([chrom,String(pos),String(s.start),'0']); out([chrom,String(s.start),String(s.end),String(s.depth)]); pos = s.end; }
        if (gl != null && pos < gl) out([chrom,String(pos),String(gl),'0']);
      } else for (const s of segs) out([chrom,String(s.start),String(s.end),String(s.depth)]);
    }
    return;
  }
  if (!genome) die('Error: genomecov requires -g unless bedGraph output is requested');
  const totalGenome = [...genome.m.values()].reduce((a,b)=>a+b,0);
  const hist = new Map(), chromHist = new Map();
  for (const chrom of genome.order) {
    const gl = genome.m.get(chrom), ch = new Map();
    let covered = 0;
    for (const s of covSegments(by.get(chrom) || [], gl)) { const l = s.end - s.start; ch.set(s.depth, (ch.get(s.depth)||0)+l); covered += l; }
    ch.set(0, gl - covered); chromHist.set(chrom, ch);
    for (const [d,l] of ch) hist.set(d, (hist.get(d)||0)+l);
  }
  for (const chrom of genome.order) for (const [d,l] of [...chromHist.get(chrom)].sort((a,b)=>a[0]-b[0])) out([chrom,String(d),String(l),String(genome.m.get(chrom)), frac(l/genome.m.get(chrom))]);
  for (const [d,l] of [...hist].sort((a,b)=>a[0]-b[0])) out(['genome',String(d),String(l),String(totalGenome),frac(l/totalGenome)]);
}
function frac(x) { return x === 0 ? '0' : Number(x.toPrecision(6)).toString(); }

function sortcmd(args) {
  const opt = parseArgs(args, { vals: ['-i'] });
  parseFile(opt['-i'] || opt._[0] || '-').sort(cmp).forEach(r => out(r.fields));
}

function subtract(args) {
  const opt = parseArgs(args, { vals: ['-a','-f','-F'], multi: ['-b'] });
  const A = parseFile(opt['-a']), B = (opt['-b'] || []).flatMap(parseFile);
  for (const a of A) {
    let parts = [[a.start, a.end]];
    for (const b of B) if (a.chrom === b.chrom) {
      const n = ov(a,b); if (!passes(a,b,n,opt)) continue;
      const ns = [];
      for (const [s,e] of parts) { const x = Math.max(s,b.start), y = Math.min(e,b.end); if (y <= s || x >= e) ns.push([s,e]); else { if (s < x) ns.push([s,x]); if (y < e) ns.push([y,e]); } }
      parts = ns;
    }
    for (const [s,e] of parts) if (s < e) { const f = [...a.fields]; f[1] = String(s); f[2] = String(e); out(f); }
  }
}

function coverage(args) {
  const opt = parseArgs(args, { vals: ['-a'], multi: ['-b'] });
  const A = parseFile(opt['-a']), B = (opt['-b'] || []).flatMap(parseFile);
  for (const a of A) {
    let count = 0; const pts = [];
    for (const b of B) { const n = ov(a,b); if (n > 0) { count++; pts.push([Math.max(a.start,b.start), Math.min(a.end,b.end)]); } }
    const covered = unionLen(pts), l = len(a);
    out([...a.fields, String(count), String(covered), String(l), frac(l ? covered / l : 0)]);
  }
}

function closest(args) {
  const opt = parseArgs(args, { vals: ['-a'], multi: ['-b'] });
  const A = parseFile(opt['-a']), B = (opt['-b'] || []).flatMap(parseFile);
  for (const a of A) {
    if (!B.length) { out([...a.fields, '.', '-1', '-1']); continue; }
    let best = [], bd = Infinity;
    for (const b of B) {
      if (a.chrom !== b.chrom) continue;
      const d = ov(a,b) > 0 ? 0 : (b.end <= a.start ? a.start - b.end : b.start - a.end);
      if (d < bd) { bd = d; best = [b]; } else if (d === bd) best.push(b);
    }
    if (!best.length) out([...a.fields, 'none', '-1', '-1']); else best.forEach(b => out([...a.fields, ...b.fields]));
  }
}

function jaccard(args) {
  const opt = parseArgs(args, { vals: ['-a','-b'] });
  const A = parseFile(opt['-a']).sort(cmp), B = parseFile(opt['-b']).sort(cmp);
  const inter = intersectLen(A, B), ua = mergedLen(A), ub = mergedLen(B);
  const uni = ua + ub - inter;
  console.log('intersection\tunion\tjaccard\tn_intersections');
  console.log(`${inter}\t${uni}\t${frac(uni ? inter / uni : 0)}\t${countOverlaps(A,B)}`);
}

function windowcmd(args) {
  const opt = parseArgs(args, { vals: ['-a','-w'], multi: ['-b'] });
  const w = +(opt['-w'] || 1000), A = parseFile(opt['-a']), B = (opt['-b'] || []).flatMap(parseFile);
  for (const a of A) for (const b of B) if (a.chrom === b.chrom && Math.max(0, Math.min(a.end + w, b.end) - Math.max(a.start - w, b.start)) > 0) out([...a.fields, ...b.fields]);
}

function slop(args) {
  const opt = parseArgs(args, { vals: ['-i','-g','-b','-l','-r'] });
  const genome = readGenome(opt['-g']); const b = +(opt['-b'] || 0), l = +(opt['-l'] || b), r = +(opt['-r'] || b);
  for (const x of parseFile(opt['-i'])) { const f=[...x.fields]; f[1]=String(Math.max(0,x.start-l)); f[2]=String(Math.min(genome.m.get(x.chrom) ?? Infinity,x.end+r)); out(f); }
}
function flank(args) {
  const opt = parseArgs(args, { vals: ['-i','-g','-b','-l','-r'] });
  const genome = readGenome(opt['-g']); const b = +(opt['-b'] || 0), l = +(opt['-l'] || b), r = +(opt['-r'] || b);
  for (const x of parseFile(opt['-i'])) { const gl=genome.m.get(x.chrom) ?? Infinity; if (l>0) out([x.chrom,String(Math.max(0,x.start-l)),String(x.start)]); if (r>0) out([x.chrom,String(x.end),String(Math.min(gl,x.end+r))]); }
}
function makewindows(args) {
  const opt = parseArgs(args, { vals: ['-g','-w','-s','-n','-b'] });
  const regions = opt['-b'] ? parseFile(opt['-b']).map(r=>[r.chrom,r.start,r.end]) : readGenome(opt['-g']).order.map(c=>[c,0,readGenome(opt['-g']).m.get(c)]);
  for (const [c,s,e] of regions) {
    if (opt['-n']) { const n=+opt['-n'], w=Math.ceil((e-s)/n); for(let i=0;i<n;i++) out([c,String(s+i*w),String(Math.min(e,s+(i+1)*w))]); }
    else { const w=+(opt['-w']||1), step=+(opt['-s']||w); for(let p=s;p<e;p+=step) out([c,String(p),String(Math.min(e,p+w))]); }
  }
}

function groupby(args) {
  const opt = parseArgs(args, { vals: ['-i','-g','-c','-o','-delim'] });
  const gs = (opt['-g']||'1').split(',').map(x=>+x-1), cs=(opt['-c']||'1').split(',').map(x=>+x-1), os=(opt['-o']||'count').split(',');
  const map = new Map(), delim = opt['-delim'] || ',';
  for (const r of lines(opt['-i'] || '-').map(l=>l.split('\t'))) {
    const k = gs.map(i=>r[i]??'').join('\t');
    if (!map.has(k)) map.set(k, []);
    map.get(k).push(r);
  }
  for (const [k, rows] of map) out([...k.split('\t'), ...cs.map((c,i)=>aggregate(rows.map(r=>r[c]??''), os[i]||os[0]||'count', delim))]);
}

function mapcmd(args) {
  const opt = parseArgs(args, { vals: ['-a','-c','-o','-null'], multi: ['-b'] });
  const A=parseFile(opt['-a']), B=(opt['-b']||[]).flatMap(parseFile), c=+(opt['-c']||4)-1, op=opt['-o']||'sum', nul=opt['-null']||'.';
  for (const a of A) { const vals=B.filter(b=>ov(a,b)>0).map(b=>b.fields[c]??''); out([...a.fields, vals.length ? aggregate(vals,op) : nul]); }
}
function samplecmd(args) {
  const opt = parseArgs(args, { vals: ['-i','-n','-seed'] });
  const ls=lines(opt['-i']||'-'), n=+(opt['-n']||1); ls.slice(0,n).forEach(l=>console.log(l));
}
function spacing(args) {
  const recs=parseFile(parseArgs(args,{vals:['-i']})['-i']||'-').sort(cmp); let prev=null;
  for (const r of recs) { out([...r.fields, String(prev&&prev.chrom===r.chrom ? Math.max(0,r.start-prev.end) : -1)]); prev=r; }
}
function overlapcmd(args) {
  const n = args.map(Number); console.log(Math.max(0, Math.min(n[1], n[3]) - Math.max(n[0], n[2])));
}

function unionLen(parts) {
  parts.sort((a,b)=>a[0]-b[0]||a[1]-b[1]); let total=0, cs=null, ce=null;
  for (const [s,e] of parts) { if (cs===null) { cs=s; ce=e; } else if (s<=ce) ce=Math.max(ce,e); else { total+=ce-cs; cs=s; ce=e; } }
  return total + (cs===null ? 0 : ce-cs);
}
function mergedLen(recs) { return [...segmentsByChrom(recs).values()].reduce((t,arr)=>t+unionLen(arr.map(r=>[r.start,r.end])),0); }
function intersectLen(A,B) {
  let total=0; const by=segmentsByChrom(B);
  for (const [chrom, arrA] of segmentsByChrom(A)) {
    const arrB=by.get(chrom)||[], parts=[];
    for (const a of arrA) for (const b of arrB) { const n=ov(a,b); if(n>0) parts.push([Math.max(a.start,b.start),Math.min(a.end,b.end)]); }
    total += unionLen(parts);
  }
  return total;
}
function countOverlaps(A,B) { let c=0; for(const a of A) for(const b of B) if(ov(a,b)>0)c++; return c; }

main();
