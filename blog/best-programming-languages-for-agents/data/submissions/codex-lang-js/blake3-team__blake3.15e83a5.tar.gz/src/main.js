#!/usr/bin/env node
'use strict';

const fs = require('fs');

const IV = [
  0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
  0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];
const MSG_PERMUTATION = [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8];
const CHUNK_LEN = 1024;
const BLOCK_LEN = 64;
const CHUNK_START = 1;
const CHUNK_END = 2;
const PARENT = 4;
const ROOT = 8;
const KEYED_HASH = 16;
const DERIVE_KEY_CONTEXT = 32;
const DERIVE_KEY_MATERIAL = 64;

function add(a, b) { return (a + b) >>> 0; }
function rotr(x, n) { return ((x >>> n) | (x << (32 - n))) >>> 0; }

function g(s, a, b, c, d, mx, my) {
  s[a] = add(add(s[a], s[b]), mx);
  s[d] = rotr((s[d] ^ s[a]) >>> 0, 16);
  s[c] = add(s[c], s[d]);
  s[b] = rotr((s[b] ^ s[c]) >>> 0, 12);
  s[a] = add(add(s[a], s[b]), my);
  s[d] = rotr((s[d] ^ s[a]) >>> 0, 8);
  s[c] = add(s[c], s[d]);
  s[b] = rotr((s[b] ^ s[c]) >>> 0, 7);
}

function round(s, m) {
  g(s, 0, 4, 8, 12, m[0], m[1]);
  g(s, 1, 5, 9, 13, m[2], m[3]);
  g(s, 2, 6, 10, 14, m[4], m[5]);
  g(s, 3, 7, 11, 15, m[6], m[7]);
  g(s, 0, 5, 10, 15, m[8], m[9]);
  g(s, 1, 6, 11, 12, m[10], m[11]);
  g(s, 2, 7, 8, 13, m[12], m[13]);
  g(s, 3, 4, 9, 14, m[14], m[15]);
}

function permute(m) {
  const out = new Array(16);
  for (let i = 0; i < 16; i++) out[i] = m[MSG_PERMUTATION[i]];
  return out;
}

function wordsFromBlock(buf, off, len) {
  const words = new Array(16).fill(0);
  for (let i = 0; i < len; i++) {
    words[i >> 2] |= buf[off + i] << (8 * (i & 3));
  }
  return words.map(x => x >>> 0);
}

function counterWords(counter) {
  if (typeof counter === 'bigint') {
    return [Number(counter & 0xffffffffn) >>> 0, Number((counter >> 32n) & 0xffffffffn) >>> 0];
  }
  return [counter >>> 0, Math.floor(counter / 0x100000000) >>> 0];
}

function compress(cv, blockWords, counter, blockLen, flags) {
  const [counterLo, counterHi] = counterWords(counter);
  const state = [
    cv[0], cv[1], cv[2], cv[3], cv[4], cv[5], cv[6], cv[7],
    IV[0], IV[1], IV[2], IV[3],
    counterLo, counterHi, blockLen >>> 0, flags >>> 0,
  ];
  let m = blockWords.slice();
  for (let i = 0; i < 7; i++) {
    round(state, m);
    m = permute(m);
  }
  const out = new Array(16);
  for (let i = 0; i < 8; i++) out[i] = (state[i] ^ state[i + 8]) >>> 0;
  for (let i = 0; i < 8; i++) out[i + 8] = (state[i + 8] ^ cv[i]) >>> 0;
  return out;
}

function wordsToBytes(words) {
  const out = Buffer.alloc(words.length * 4);
  for (let i = 0; i < words.length; i++) out.writeUInt32LE(words[i] >>> 0, i * 4);
  return out;
}

class Output {
  constructor(inputCv, blockWords, counter, blockLen, flags) {
    this.inputCv = inputCv.slice();
    this.blockWords = blockWords.slice();
    this.counter = counter;
    this.blockLen = blockLen;
    this.flags = flags;
  }
  chainingValue() {
    return compress(this.inputCv, this.blockWords, this.counter, this.blockLen, this.flags).slice(0, 8);
  }
  rootBytes(outLen, seekBytes = 0n) {
    const out = Buffer.alloc(outLen);
    let blockCounter = BigInt(seekBytes) / 64n;
    let offset = Number(BigInt(seekBytes) % 64n);
    let written = 0;
    while (written < outLen) {
      const block = wordsToBytes(compress(this.inputCv, this.blockWords, blockCounter, this.blockLen, this.flags | ROOT));
      const take = Math.min(outLen - written, 64 - offset);
      block.copy(out, written, offset, offset + take);
      written += take;
      blockCounter++;
      offset = 0;
    }
    return out;
  }
}

function chunkOutput(input, off, len, keyWords, chunkCounter, flags) {
  let cv = keyWords.slice();
  let blockOff = 0;
  if (len === 0) {
    return new Output(cv, wordsFromBlock(input, off, 0), chunkCounter, 0, flags | CHUNK_START | CHUNK_END);
  }
  while (blockOff + BLOCK_LEN < len) {
    const blockFlags = flags | (blockOff === 0 ? CHUNK_START : 0);
    cv = compress(cv, wordsFromBlock(input, off + blockOff, BLOCK_LEN), chunkCounter, BLOCK_LEN, blockFlags).slice(0, 8);
    blockOff += BLOCK_LEN;
  }
  const blockLen = len - blockOff;
  const blockFlags = flags | CHUNK_END | (blockOff === 0 ? CHUNK_START : 0);
  return new Output(cv, wordsFromBlock(input, off + blockOff, blockLen), chunkCounter, blockLen, blockFlags);
}

function parentOutput(leftCv, rightCv, keyWords, flags) {
  return new Output(keyWords, leftCv.concat(rightCv), 0, BLOCK_LEN, flags | PARENT);
}

function hashBytes(input, outLen = 32, opts = {}) {
  const flags = opts.flags || 0;
  const keyWords = opts.keyWords || IV;
  const seek = opts.seek || 0n;
  const chunks = Math.max(1, Math.ceil(input.length / CHUNK_LEN));
  const stack = [];
  for (let i = 0; i < chunks; i++) {
    const off = i * CHUNK_LEN;
    const len = Math.min(CHUNK_LEN, input.length - off);
    const out = chunkOutput(input, off, Math.max(0, len), keyWords, i, flags);
    let cv = out.chainingValue();
    let total = i + 1;
    while ((total & 1) === 0) {
      const left = stack.pop();
      cv = parentOutput(left, cv, keyWords, flags).chainingValue();
      total >>= 1;
    }
    stack.push(cv);
  }
  let right = stack.pop();
  while (stack.length > 0) {
    const left = stack.pop();
    right = parentOutput(left, right, keyWords, flags).chainingValue();
  }
  let root;
  if (chunks === 1) {
    root = chunkOutput(input, 0, input.length, keyWords, 0, flags);
  } else {
    // Reconstruct the final parent output from the final two CVs by reducing
    // pairwise, preserving the right-edge shape used by BLAKE3.
    const cvs = [];
    for (let i = 0; i < chunks; i++) {
      const off = i * CHUNK_LEN;
      cvs.push(chunkOutput(input, off, Math.min(CHUNK_LEN, input.length - off), keyWords, i, flags).chainingValue());
    }
    let level = cvs;
    while (level.length > 2) {
      const next = [];
      for (let i = 0; i < level.length; i += 2) {
        if (i + 1 < level.length) next.push(parentOutput(level[i], level[i + 1], keyWords, flags).chainingValue());
        else next.push(level[i]);
      }
      level = next;
    }
    root = parentOutput(level[0], level[1], keyWords, flags);
  }
  return root.rootBytes(outLen, seek);
}

function keyWordsFromBytes(key) {
  const words = [];
  for (let i = 0; i < 8; i++) words.push(key.readUInt32LE(i * 4));
  return words;
}

function deriveKeyWords(context) {
  const contextKey = hashBytes(Buffer.from(context, 'utf8'), 32, { flags: DERIVE_KEY_CONTEXT });
  return keyWordsFromBytes(contextKey);
}

function usage(long = false) {
  const extra = long ? [
    '          ',
    '          When no file is given, or when - is given, read standard input.',
    '',
  ] : [];
  return [
    'Usage: executable [OPTIONS] [FILE]...',
    '',
    'Arguments:',
    '  [FILE]...',
    '          Files to hash, or checkfiles to check',
    ...extra,
    'Options:',
    '      --keyed',
    '          Use the keyed mode, reading the 32-byte key from stdin',
    '',
    '      --derive-key <CONTEXT>',
    '          Use the key derivation mode, with the given context string',
    '          ',
    '          Cannot be used with --keyed.',
    '',
    '  -l, --length <LEN>',
    '          The number of output bytes, before hex encoding',
    '          ',
    '          [default: 32]',
    '',
    '      --seek <SEEK>',
    '          The starting output byte offset, before hex encoding',
    '          ',
    '          [default: 0]',
    '',
    '      --num-threads <NUM>',
    '          The maximum number of threads to use',
    '',
    '      --no-mmap',
    '          Disable memory mapping',
    '          ',
    '          Currently this also disables multithreading.',
    '',
    '      --no-names',
    '          Omit filenames in the output',
    '',
    '      --raw',
    '          Write raw output bytes to stdout, rather than hex',
    '          ',
    '          --no-names is implied. In this case, only a single input is allowed.',
    '',
    '      --tag',
    '          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]',
    '',
    '  -c, --check',
    '          Read BLAKE3 sums from the [FILE]s and check them',
    '',
    '      --quiet',
    '          Skip printing OK for each checked file',
    '          ',
    '          Must be used with --check.',
    '',
    '  -h, --help',
    "          Print help (see a summary with '-h')",
    '',
    '  -V, --version',
    '          Print version',
  ].join('\n');
}

function parseNum(name, value) {
  if (!/^\d+$/.test(value)) throw new Error(`error: invalid value '${value}' for '${name}': invalid digit found in string`);
  return BigInt(value);
}

function parseArgs(argv) {
  const o = { files: [], length: 32, seek: 0n, noNames: false, raw: false, tag: false, check: false, quiet: false, keyed: false, deriveKey: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') { o.files.push(...argv.slice(i + 1)); break; }
    if (a === '-h' || a === '--help') { o.help = true; continue; }
    if (a === '-V' || a === '--version') { o.version = true; continue; }
    if (a === '--keyed') { o.keyed = true; continue; }
    if (a === '--derive-key') { if (++i >= argv.length) throw new Error('error: a value is required for \'--derive-key <CONTEXT>\''); o.deriveKey = argv[i]; continue; }
    if (a === '-l' || a === '--length') { if (++i >= argv.length) throw new Error(`error: a value is required for '${a} <LEN>'`); o.length = Number(parseNum('--length <LEN>', argv[i])); continue; }
    if (a.startsWith('--length=')) { o.length = Number(parseNum('--length <LEN>', a.slice(9))); continue; }
    if (a === '--seek') { if (++i >= argv.length) throw new Error('error: a value is required for \'--seek <SEEK>\''); o.seek = parseNum('--seek <SEEK>', argv[i]); continue; }
    if (a.startsWith('--seek=')) { o.seek = parseNum('--seek <SEEK>', a.slice(7)); continue; }
    if (a === '--num-threads') { i++; continue; }
    if (a.startsWith('--num-threads=')) continue;
    if (a === '--no-mmap') continue;
    if (a === '--no-names') { o.noNames = true; continue; }
    if (a === '--raw') { o.raw = true; o.noNames = true; continue; }
    if (a === '--tag') { o.tag = true; continue; }
    if (a === '-c' || a === '--check') { o.check = true; continue; }
    if (a === '--quiet') { o.quiet = true; continue; }
    if (a !== '-' && a.startsWith('-')) throw new Error(`error: unexpected argument '${a}' found`);
    o.files.push(a);
  }
  if (o.keyed && o.deriveKey !== null) throw new Error("error: the argument '--keyed' cannot be used with '--derive-key <CONTEXT>'");
  if (o.keyed && o.files.length === 0) throw new Error('error: the following required arguments were not provided:\n  <FILE>...');
  if (o.quiet && !o.check) throw new Error('error: the following required arguments were not provided:\n  --check');
  if (o.raw && o.files.length > 1) throw new Error('Error: Only one filename can be provided when using --raw');
  return o;
}

function readStdin() {
  return fs.readFileSync(0);
}

function hashInput(buf, opts, keyWords, flags) {
  return hashBytes(buf, opts.length, { keyWords, flags, seek: opts.seek });
}

function hashFile(name, opts, keyWords, flags, stdinCache) {
  const buf = name === '-' ? stdinCache.value ?? (stdinCache.value = readStdin()) : fs.readFileSync(name);
  const digest = hashInput(buf, opts, keyWords, flags);
  if (opts.raw) {
    process.stdout.write(digest);
  } else {
    const hex = digest.toString('hex');
    if (opts.noNames) console.log(hex);
    else if (opts.tag) console.log(`BLAKE3 (${name}) = ${hex}`);
    else console.log(`${hex}  ${name}`);
  }
}

function parseCheckLine(line) {
  let m = /^BLAKE3 \((.*)\) = ([0-9a-fA-F]+)$/.exec(line);
  if (m) return { file: m[1], hex: m[2].toLowerCase() };
  m = /^([0-9a-fA-F]+)[ \t][ \t]?(?:\*?)(.+)$/.exec(line);
  if (m) return { file: m[2], hex: m[1].toLowerCase() };
  return null;
}

function checkFileList(listFile, opts, keyWords, flags, stdinCache) {
  const text = (listFile === '-' ? stdinCache.value ?? (stdinCache.value = readStdin()) : fs.readFileSync(listFile)).toString('utf8');
  let okAll = true;
  let count = 0;
  for (const line of text.split(/\r?\n/)) {
    if (line.length === 0) continue;
    const parsed = parseCheckLine(line);
    if (!parsed) {
      console.error(`${listFile}: improperly formatted BLAKE3 checksum line`);
      okAll = false;
      continue;
    }
    count++;
    let actual;
    try {
      actual = hashBytes(fs.readFileSync(parsed.file), parsed.hex.length / 2, { keyWords, flags }).toString('hex');
    } catch (e) {
      console.error(`${parsed.file}: ${e.message}`);
      okAll = false;
      continue;
    }
    if (actual === parsed.hex) {
      if (!opts.quiet) console.log(`${parsed.file}: OK`);
    } else {
      console.log(`${parsed.file}: FAILED`);
      okAll = false;
    }
  }
  if (count === 0) okAll = false;
  return okAll;
}

function main() {
  let opts;
  try {
    opts = parseArgs(process.argv.slice(2));
  } catch (e) {
    console.error(e.message);
    if (e.message.startsWith('error: unexpected')) console.error('\n  tip: to pass \'' + e.message.split("'")[1] + "' as a value, use '-- " + e.message.split("'")[1] + "'\n\nUsage: executable [OPTIONS] [FILE]...");
    else if (e.message.includes('<FILE>...')) console.error('\nUsage: executable --keyed <FILE>...\n\nFor more information, try \'--help\'.');
    else if (e.message.startsWith('error: the following required')) console.error('\nUsage: executable --check --quiet [FILE]...');
    else if (e.message.startsWith('Error:')) ;
    else console.error("\nFor more information, try '--help'.");
    process.exit(e.message.startsWith('Error:') ? 1 : 2);
  }
  if (opts.help) { console.log(usage(true)); return; }
  if (opts.version) { console.log('b3sum 1.8.4'); return; }

  let keyWords = IV;
  let flags = 0;
  let stdinCache = {};
  if (opts.keyed) {
    const stdin = readStdin();
    if (stdin.length < 32) {
      console.error(`Error: expected 32 key bytes from stdin, found ${stdin.length}`);
      process.exit(1);
    }
    if (stdin.length > 32) {
      console.error('Error: read more than 32 key bytes from stdin');
      process.exit(1);
    }
    keyWords = keyWordsFromBytes(stdin.subarray(0, 32));
    flags = KEYED_HASH;
  } else if (opts.deriveKey !== null) {
    keyWords = deriveKeyWords(opts.deriveKey);
    flags = DERIVE_KEY_MATERIAL;
  }

  const files = opts.files.length ? opts.files : ['-'];
  try {
    if (opts.check) {
      let all = true;
      for (const f of files) if (!checkFileList(f, opts, keyWords, flags, stdinCache)) all = false;
      if (!all) process.exit(1);
    } else {
      for (const f of files) hashFile(f, opts, keyWords, flags, stdinCache);
    }
  } catch (e) {
    console.error(`Error: ${e.message}`);
    process.exit(1);
  }
}

main();
