#!/usr/bin/env node
'use strict';

const fs = require('fs');

const HELP = `A high performance csv viewer with cjk/emoji support.

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          File to view

Options:
  -H, --no-headers
          Specify that the input has no header row
  -n, --number
          Prepend a column of line numbers to the table
  -t, --tsv
          Use '\\t' as delimiter for tsv
  -d, --delimiter <DELIMITER>
          Specify the field delimiter [default: ,]
  -s, --style <STYLE>
          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
          rounded, reinforced, markdown, grid]
  -p, --padding <PADDING>
          Specify padding for table cell [default: 1]
  -i, --indent <INDENT>
          Specify global indent for table [default: 0]
      --sniff <LIMIT>
          Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
          [default: 1000]
      --header-align <HEADER_ALIGN>
          Specify the alignment of the table header [default: center] [possible values: left,
          center, right]
      --body-align <BODY_ALIGN>
          Specify the alignment of the table body [default: left] [possible values: left, center,
          right]
  -P, --disable-pager
          Disable pager
  -h, --help
          Print help
  -V, --version
          Print version`;

const STYLES = new Set(['none', 'ascii', 'ascii2', 'sharp', 'rounded', 'reinforced', 'markdown', 'grid']);
const ALIGNS = new Set(['left', 'center', 'right']);

function die(msg, code = 1) {
  process.stderr.write(msg + '\n');
  process.exit(code);
}

function clapError(msg) {
  die(`error: ${msg}\n\nFor more information, try '--help'.`, 2);
}

function parseArgs(argv) {
  const opts = {
    noHeaders: false, number: false, delimiter: ',', style: 'sharp',
    padding: 1, indent: 0, sniff: 1000, headerAlign: 'center', bodyAlign: 'left',
    file: null
  };
  function need(i, name) {
    if (i + 1 >= argv.length) clapError(`a value is required for '${name} <${name.replace(/^--/, '').toUpperCase()}>' but none was supplied`);
    return argv[i + 1];
  }
  function parseNonNeg(v, name) {
    if (!/^\d+$/.test(v)) clapError(`invalid value '${v}' for '${name}': invalid digit found in string`);
    return Number(v);
  }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') { console.log(HELP); process.exit(0); }
    if (a === '-V' || a === '--version') { console.log('csview 1.3.4'); process.exit(0); }
    if (a === '-H' || a === '--no-headers') opts.noHeaders = true;
    else if (a === '-n' || a === '--number') opts.number = true;
    else if (a === '-t' || a === '--tsv') opts.delimiter = '\t';
    else if (a === '-P' || a === '--disable-pager') {}
    else if (a === '-d' || a === '--delimiter') {
      const v = need(i, '--delimiter'); i++;
      const chars = Array.from(v);
      if (chars.length === 0) clapError(`invalid value '' for '--delimiter <DELIMITER>': cannot parse char from empty string`);
      if (chars.length > 1) clapError(`invalid value '${v}' for '--delimiter <DELIMITER>': too many characters in string`);
      opts.delimiter = v;
    } else if (a === '-s' || a === '--style') {
      const v = need(i, '--style'); i++;
      if (!STYLES.has(v)) die(`error: invalid value '${v}' for '--style <STYLE>'\n  [possible values: none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid]\n\nFor more information, try '--help'.`, 2);
      opts.style = v;
    } else if (a === '-p' || a === '--padding') {
      opts.padding = parseNonNeg(need(i, '--padding'), '--padding <PADDING>'); i++;
    } else if (a === '-i' || a === '--indent') {
      opts.indent = parseNonNeg(need(i, '--indent'), '--indent <INDENT>'); i++;
    } else if (a === '--sniff') {
      opts.sniff = parseNonNeg(need(i, '--sniff'), '--sniff <LIMIT>'); i++;
    } else if (a === '--header-align') {
      const v = need(i, '--header-align'); i++;
      if (!ALIGNS.has(v)) clapError(`invalid value '${v}' for '--header-align <HEADER_ALIGN>'`);
      opts.headerAlign = v;
    } else if (a === '--body-align') {
      const v = need(i, '--body-align'); i++;
      if (!ALIGNS.has(v)) clapError(`invalid value '${v}' for '--body-align <BODY_ALIGN>'`);
      opts.bodyAlign = v;
    } else if (a.startsWith('-')) {
      die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.`, 2);
    } else if (opts.file === null) opts.file = a;
    else die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.`, 2);
  }
  return opts;
}

function parseCsv(text, delimiter) {
  if (text.length === 0) return [[]];
  const rows = [];
  const starts = [];
  let row = [], field = '', inQuotes = false, start = true;
  let line = 1, byte = 0, recordStart = 0;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i]; byte++;
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; byte++; }
        else inQuotes = false;
      } else { field += ch; if (ch === '\n') line++; }
      continue;
    }
    if (start && ch === '"') { inQuotes = true; start = false; continue; }
    start = false;
    if (ch === delimiter) { row.push(field); field = ''; start = true; continue; }
    if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') { i++; byte++; }
      starts.push(recordStart);
      rows.push(row.concat([field]));
      row = []; field = ''; start = true; line++; recordStart = byte;
      continue;
    }
    field += ch;
  }
  if (inQuotes) throw new Error(`CSV error: record ${rows.length} (line: ${line}, byte: ${byte}): unterminated quoted field`);
  if (field !== '' || row.length > 0 || !text.endsWith('\n') && !text.endsWith('\r')) {
    starts.push(recordStart);
    rows.push(row.concat([field]));
  }
  if (rows.length === 0) rows.push([]);
  const n = rows[0].length;
  for (let i = 1; i < rows.length; i++) {
    if (rows[i].length !== n) throw new Error(`CSV error: record ${i} (line: ${i + 1}, byte: ${starts[i] || 0}): found record with ${rows[i].length} fields, but the previous record has ${n} fields`);
  }
  return rows;
}

function charWidth(ch) {
  const cp = ch.codePointAt(0);
  if (ch === '\n') return 1;
  if (cp === 0) return 0;
  if (cp < 32 || (cp >= 0x7f && cp < 0xa0)) return 0;
  if (
    cp >= 0x1100 && (
      cp <= 0x115f || cp === 0x2329 || cp === 0x232a ||
      (cp >= 0x2e80 && cp <= 0xa4cf) || (cp >= 0xac00 && cp <= 0xd7a3) ||
      (cp >= 0xf900 && cp <= 0xfaff) || (cp >= 0xfe10 && cp <= 0xfe19) ||
      (cp >= 0xfe30 && cp <= 0xfe6f) || (cp >= 0xff00 && cp <= 0xff60) ||
      (cp >= 0xffe0 && cp <= 0xffe6) || (cp >= 0x1f300 && cp <= 0x1faff)
    )
  ) return 2;
  return 1;
}
function width(s) { let w = 0; for (const ch of String(s)) w += charWidth(ch); return w; }
function truncate(s, max) {
  let out = '', w = 0;
  for (const ch of String(s)) {
    const cw = charWidth(ch);
    if (w + cw > max) break;
    out += ch; w += cw;
  }
  return out;
}
function align(s, w, mode) {
  s = truncate(String(s), w);
  const diff = w - width(s);
  if (mode === 'right') return ' '.repeat(diff) + s;
  if (mode === 'center') {
    const l = Math.floor(diff / 2), r = diff - l;
    return ' '.repeat(l) + s + ' '.repeat(r);
  }
  return s + ' '.repeat(diff);
}

const BOX = {
  ascii: {v:'|', h:'-', tl:'+', tm:'+', tr:'+', ml:'+', mm:'+', mr:'+', bl:'+', bm:'+', br:'+'},
  sharp: {v:'│', h:'─', tl:'┌', tm:'┬', tr:'┐', ml:'├', mm:'┼', mr:'┤', bl:'└', bm:'┴', br:'┘'},
  rounded: {v:'│', h:'─', tl:'╭', tm:'┬', tr:'╮', ml:'├', mm:'┼', mr:'┤', bl:'╰', bm:'┴', br:'╯'},
  reinforced: {v:'│', h:'─', tl:'┏', tm:'┬', tr:'┓', ml:'├', mm:'┼', mr:'┤', bl:'┗', bm:'┴', br:'┛'},
  grid: {v:'│', h:'─', tl:'┌', tm:'┬', tr:'┐', ml:'├', mm:'┼', mr:'┤', bl:'└', bm:'┴', br:'┘'}
};

function render(records, opts) {
  let header = null, body = records.slice();
  if (!opts.noHeaders) { header = body.shift() || []; }
  if (opts.number) {
    if (header) header = ['#'].concat(header);
    body = body.map((r, i) => [String(i + 1)].concat(r));
  }
  const cols = Math.max(header ? header.length : 0, ...body.map(r => r.length), 0);
  if (header) while (header.length < cols) header.push('');
  body.forEach(r => { while (r.length < cols) r.push(''); });
  let sniffRows = [];
  if (header) sniffRows.push(header);
  const limit = opts.sniff === 0 ? body.length : opts.sniff;
  sniffRows = sniffRows.concat(body.slice(0, limit));
  if (!header && sniffRows.length === 0) sniffRows = body.slice(0, limit);
  const widths = Array(cols).fill(0);
  for (const r of sniffRows) for (let c = 0; c < cols; c++) widths[c] = Math.max(widths[c], width(r[c] || ''));

  const p = opts.padding, ind = ' '.repeat(opts.indent);
  const cellW = widths.map(w => w + p * 2);
  const makeCells = (r, mode, sep, edgeL, edgeR) => edgeL + r.map((x, c) => ' '.repeat(p) + align(x || '', widths[c], mode) + ' '.repeat(p)).join(sep) + edgeR;
  const sepLine = (b, l, m, r) => l + cellW.map(w => b.h.repeat(w)).join(m) + r;
  const out = [];

  if (opts.style === 'none') {
    const rows = (header ? [header] : []).concat(body);
    for (const r of rows) out.push(ind + makeCells(r, header && r === header ? opts.headerAlign : opts.bodyAlign, '', '', ''));
    return out.join('\n') + '\n';
  }
  if (opts.style === 'markdown') {
    if (header) {
      out.push(ind + makeCells(header, opts.headerAlign, '|', '|', '|'));
      out.push(ind + '|' + cellW.map(w => '-'.repeat(w)).join('|') + '|');
      for (const r of body) out.push(ind + makeCells(r, opts.bodyAlign, '|', '|', '|'));
    } else {
      for (const r of body) out.push(ind + makeCells(r, opts.bodyAlign, '|', '|', '|'));
    }
    return out.join('\n') + '\n';
  }
  if (opts.style === 'ascii2') {
    if (header) {
      out.push(ind + makeCells(header, opts.headerAlign, '|', ' ', ' '));
      out.push(ind + ' ' + cellW.map(w => '-'.repeat(w)).join('+') + ' ');
      for (const r of body) out.push(ind + makeCells(r, opts.bodyAlign, '|', ' ', ' '));
    } else {
      for (const r of body) out.push(ind + makeCells(r, opts.bodyAlign, '|', ' ', ' '));
    }
    return out.join('\n') + '\n';
  }
  const b = BOX[opts.style];
  out.push(ind + sepLine(b, b.tl, b.tm, b.tr));
  if (header) {
    out.push(ind + makeCells(header, opts.headerAlign, b.v, b.v, b.v));
    if (body.length) out.push(ind + sepLine(b, b.ml, b.mm, b.mr));
  }
  body.forEach((r, idx) => {
    out.push(ind + makeCells(r, opts.bodyAlign, b.v, b.v, b.v));
    if (opts.style === 'grid' && idx !== body.length - 1) out.push(ind + sepLine(b, b.ml, b.mm, b.mr));
  });
  out.push(ind + sepLine(b, b.bl, b.bm, b.br));
  return out.join('\n') + '\n';
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  let input;
  try {
    input = opts.file ? fs.readFileSync(opts.file, 'utf8') : fs.readFileSync(0, 'utf8');
  } catch (e) {
    if (e.code === 'ENOENT') die('csview: No such file or directory (os error 2)');
    die(`csview: ${e.message}`);
  }
  try {
    process.stdout.write(render(parseCsv(input, opts.delimiter), opts));
  } catch (e) {
    die(`csview: ${e.message}`);
  }
}
main();
