#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = '0.21.1';
const SCHEMA = '2024-11-02';

function help() {
  return `Summarize disk usage of the set of files, recursively for directories.

Usage: executable [OPTIONS] [FILES]...

Arguments:
  [FILES]...
          List of files and/or directories

Options:
      --json-input
          Read JSON data from stdin

      --json-output
          Print JSON data instead of an ASCII chart

  -b, --bytes-format <BYTES_FORMAT>
          How to display the numbers of bytes

          Possible values:
          - plain:  Display plain number of bytes without units
          - metric: Use metric scale, i.e. 1K = 1000B, 1M = 1000K, and so on
          - binary: Use binary scale, i.e. 1K = 1024B, 1M = 1024K, and so on

          [default: metric]

  -H, --deduplicate-hardlinks
          Detect and subtract the sizes of hardlinks from their parent directory totals

      --top-down
          Print the tree top-down instead of bottom-up

      --align-right
          Set the root of the bars to the right

  -q, --quantity <QUANTITY>
          Aspect of the files/directories to be measured

          Possible values:
          - apparent-size: Measure apparent sizes
          - block-size:    Measure block sizes (block-count * 512B)
          - block-count:   Count numbers of blocks

          [default: block-size]

  -d, --max-depth <MAX_DEPTH>
          Maximum depth to display the data. Could be either "inf" or a positive integer

          [default: 10]
          [aliases: --depth]

  -w, --total-width <TOTAL_WIDTH>
          Width of the visualization

      --column-width <TREE_WIDTH> <BAR_WIDTH>
          Maximum widths of the tree column and width of the bar column

  -m, --min-ratio <MIN_RATIO>
          Minimal size proportion required to appear

          [default: 0.01]

      --no-sort
          Do not sort the branches in the tree

  -s, --silent-errors
          Prevent filesystem error messages from appearing in stderr

  -p, --progress
          Report progress being made at the expense of performance

      --threads <THREADS>
          Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer

          [default: auto]

      --omit-json-shared-details
          Do not output \`.shared.details\` in the JSON output

      --omit-json-shared-summary
          Do not output \`.shared.summary\` in the JSON output

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;
}

function die(message, code = 2) {
  console.error(message);
  process.exit(code);
}

function parseArgs(argv) {
  const opt = {
    jsonInput: false,
    jsonOutput: false,
    bytesFormat: 'metric',
    quantity: 'block-size',
    maxDepth: 10,
    minRatio: 0.01,
    sort: true,
    topDown: false,
    alignRight: false,
    silentErrors: false,
    dedupe: false,
    omitDetails: false,
    omitSummary: false,
    totalWidth: process.stdout.columns || 132,
    treeWidth: null,
    barWidth: null,
    files: [],
  };
  const take = (i, name) => {
    if (i + 1 >= argv.length) die(`error: a value is required for '${name}'`);
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '--') {
      opt.files.push(...argv.slice(i + 1));
      break;
    } else if (a === '-h' || a === '--help') {
      console.log(help());
      process.exit(0);
    } else if (a === '-V' || a === '--version') {
      console.log(`pdu ${VERSION}`);
      process.exit(0);
    } else if (a === '--json-input') opt.jsonInput = true;
    else if (a === '--json-output') opt.jsonOutput = true;
    else if (a === '-H' || a === '--deduplicate-hardlinks' || a === '--detect-links' || a === '--dedupe-links') opt.dedupe = true;
    else if (a === '--top-down') opt.topDown = true;
    else if (a === '--align-right') opt.alignRight = true;
    else if (a === '--no-sort') opt.sort = false;
    else if (a === '-s' || a === '--silent-errors' || a === '--no-errors') opt.silentErrors = true;
    else if (a === '-p' || a === '--progress') {}
    else if (a === '--omit-json-shared-details') opt.omitDetails = true;
    else if (a === '--omit-json-shared-summary') opt.omitSummary = true;
    else if (a === '-b' || a === '--bytes-format') {
      opt.bytesFormat = take(i, a); i++;
    } else if (a.startsWith('--bytes-format=')) opt.bytesFormat = a.slice(15);
    else if (a === '-q' || a === '--quantity') {
      opt.quantity = take(i, a); i++;
    } else if (a.startsWith('--quantity=')) opt.quantity = a.slice(11);
    else if (a === '-d' || a === '--max-depth' || a === '--depth') {
      opt.maxDepth = parseDepth(take(i, a)); i++;
    } else if (a.startsWith('--max-depth=')) opt.maxDepth = parseDepth(a.slice(12));
    else if (a.startsWith('--depth=')) opt.maxDepth = parseDepth(a.slice(8));
    else if (a === '-m' || a === '--min-ratio') {
      opt.minRatio = Number(take(i, a)); i++;
    } else if (a.startsWith('--min-ratio=')) opt.minRatio = Number(a.slice(12));
    else if (a === '-w' || a === '--total-width' || a === '--width') {
      opt.totalWidth = Number(take(i, a)); i++;
    } else if (a.startsWith('--total-width=')) opt.totalWidth = Number(a.slice(14));
    else if (a.startsWith('--width=')) opt.totalWidth = Number(a.slice(8));
    else if (a === '--column-width') {
      opt.treeWidth = Number(take(i, a));
      opt.barWidth = Number(take(i + 1, a));
      i += 2;
    } else if (a === '--threads') { i++; }
    else if (a.startsWith('--threads=')) {}
    else if (a.startsWith('-')) die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [FILES]...\n\nFor more information, try '--help'.`);
    else opt.files.push(a);
  }
  if (!['plain', 'metric', 'binary'].includes(opt.bytesFormat)) die(`error: invalid value '${opt.bytesFormat}' for '--bytes-format <BYTES_FORMAT>'`);
  if (!['apparent-size', 'block-size', 'block-count'].includes(opt.quantity)) die(`error: invalid value '${opt.quantity}' for '--quantity <QUANTITY>'`);
  if (!Number.isFinite(opt.minRatio) || opt.minRatio < 0) die(`error: invalid value for '--min-ratio <MIN_RATIO>'`);
  return opt;
}

function parseDepth(s) {
  if (s === 'inf') return Infinity;
  const n = Number(s);
  if (!Number.isInteger(n) || n <= 0) die(`error: invalid value '${s}' for '--max-depth <MAX_DEPTH>': Value is neither "inf" nor a positive integer`);
  return n;
}

function nodeSize(st, opt) {
  if (opt.quantity === 'apparent-size') return Number(st.size);
  if (opt.quantity === 'block-count') return Number(st.blocks || 0);
  return Number(st.blocks || 0) * 512;
}

function hardKey(st) {
  return `${st.dev}:${st.ino}`;
}

function baseName(p, isRoot) {
  return isRoot ? p : path.basename(p);
}

function scan(p, opt, isRoot = false, shared = new Map()) {
  let st;
  try {
    st = fs.lstatSync(p);
  } catch (e) {
    if (!opt.silentErrors) console.error(`[error] symlink_metadata "${p}": ${e.message}`);
    return { name: p, size: 0, children: [], _seen: new Map(), _order: 0, _missing: true };
  }
  const own = nodeSize(st, opt);
  const node = { name: baseName(p, isRoot), size: own, children: [], _seen: new Map(), _order: 0 };
  const isHard = opt.dedupe && st.nlink > 1 && !st.isDirectory() && !st.isSymbolicLink();
  if (isHard) {
    const key = hardKey(st);
    node._seen.set(key, own);
    let rec = shared.get(key);
    if (!rec) {
      rec = { ino: Number(st.ino), size: own, links: Number(st.nlink), paths: [] };
      shared.set(key, rec);
    }
    rec.paths.push(p);
  }
  if (st.isDirectory() && !st.isSymbolicLink()) {
    let entries = [];
    try {
      entries = fs.readdirSync(p);
    } catch (e) {
      if (!opt.silentErrors) console.error(`[error] read_dir "${p}": ${e.message}`);
    }
    let total = own;
    let order = 0;
    for (const ent of entries) {
      const child = scan(path.join(p, ent), opt, false, shared);
      child._order = order++;
      node.children.push(child);
      if (opt.dedupe) {
        let childContribution = child.size;
        for (const [k, v] of child._seen.entries()) {
          if (node._seen.has(k)) childContribution -= v;
          else node._seen.set(k, v);
        }
        total += childContribution;
      } else {
        total += child.size;
      }
    }
    node.size = total;
  }
  return node;
}

function sortedChildren(children, opt) {
  const arr = children.slice();
  if (!opt.sort) return arr.reverse();
  arr.sort((a, b) => {
    if (b.size !== a.size) return b.size - a.size;
    return a.name.localeCompare(b.name);
  });
  return arr;
}

function prune(node, opt, rootSize, depth = 1) {
  const out = { name: node.name, size: node.size, children: [] };
  if (depth >= opt.maxDepth) return out;
  const kids = sortedChildren(node.children || [], opt);
  for (const c of kids) {
    const ratio = rootSize === 0 ? 0 : c.size / rootSize;
    if (c.size !== 0 && ratio < opt.minRatio) continue;
    out.children.push(prune(c, opt, rootSize, depth + 1));
  }
  return out;
}

function makeTree(opt) {
  const shared = new Map();
  const files = opt.files.length ? opt.files : ['.'];
  if (files.length === 1) return { root: scan(files[0], opt, true, shared), shared };
  const root = { name: '(total)', size: 0, children: [], _seen: new Map() };
  let order = 0;
  for (const f of files) {
    const c = scan(f, opt, true, shared);
    c._order = order++;
    root.children.push(c);
    if (opt.dedupe) {
      let contrib = c.size;
      for (const [k, v] of c._seen.entries()) {
        if (root._seen.has(k)) contrib -= v;
        else root._seen.set(k, v);
      }
      root.size += contrib;
    } else {
      root.size += c.size;
    }
  }
  return { root, shared };
}

function jsonDocument(tree, opt, shared) {
  const doc = {
    'schema-version': SCHEMA,
    pdu: VERSION,
    unit: opt.quantity === 'block-count' ? 'blocks' : 'bytes',
    tree,
  };
  if (opt.dedupe) {
    const details = Array.from(shared.values()).filter(x => x.paths.length > 1);
    const sharedSize = details.reduce((n, x) => n + x.size, 0);
    const allLinks = details.reduce((n, x) => n + x.links, 0);
    const detectedLinks = details.reduce((n, x) => n + x.paths.length, 0);
    doc.shared = {};
    if (!opt.omitDetails) doc.shared.details = details.map(x => ({ ino: x.ino, size: x.size, links: x.links, paths: x.paths.slice().reverse() }));
    if (!opt.omitSummary) doc.shared.summary = {
      inodes: details.length,
      exclusive_inodes: details.length,
      all_links: allLinks,
      detected_links: detectedLinks,
      exclusive_links: detectedLinks,
      shared_size: sharedSize,
      exclusive_shared_size: sharedSize,
    };
  }
  return doc;
}

function readStdin() {
  return fs.readFileSync(0, 'utf8');
}

function formatSize(n, opt) {
  if (opt.bytesFormat === 'plain' || opt.quantity === 'block-count') return String(Math.round(n));
  const base = opt.bytesFormat === 'binary' ? 1024 : 1000;
  const units = ['', 'K', 'M', 'G', 'T', 'P'];
  let v = n, i = 0;
  while (Math.abs(v) >= base && i < units.length - 1) { v /= base; i++; }
  if (i === 0) return String(Math.round(v));
  return `${v.toFixed(1)}${units[i]}`;
}

function flattenBottom(node, prefix = '', lines = []) {
  const kids = node.children || [];
  kids.forEach((c, i) => {
    flattenBottom(c, prefix + (i === kids.length - 1 ? '  ' : '│ '), lines);
  });
  lines.push({ node, prefix });
  return lines;
}

function flattenTop(node, prefix = '', lines = []) {
  lines.push({ node, prefix });
  const kids = node.children || [];
  kids.forEach((c, i) => flattenTop(c, prefix + (i === kids.length - 1 ? '  ' : '│ '), lines));
  return lines;
}

function chart(tree, opt) {
  const lines = opt.topDown ? flattenTop(tree) : flattenBottom(tree);
  const sizes = lines.map(x => formatSize(x.node.size, opt));
  const sizeW = Math.max(...sizes.map(s => s.length), 1);
  const treeW = opt.treeWidth || Math.min(40, Math.max(...lines.map(x => (x.prefix + x.node.name).length + 3), 1));
  const barW = opt.barWidth || Math.max(10, Math.min(118, opt.totalWidth - sizeW - treeW - 8));
  return lines.map((x, idx) => {
    const ratio = tree.size === 0 ? 0 : x.node.size / tree.size;
    const filled = Math.round(ratio * barW);
    const bar = '█'.repeat(Math.max(0, Math.min(barW, filled))) + ' '.repeat(Math.max(0, barW - filled));
    const branch = x.node === tree
      ? (opt.topDown && x.node.children.length ? '└─┬' : '┌──')
      : ((x.node.children && x.node.children.length) ? (opt.topDown ? '├─┬' : '├─┴') : '├──');
    const name = (x.prefix + branch + x.node.name).padEnd(treeW).slice(0, treeW);
    const pct = `${Math.round(ratio * 100).toString().padStart(3)}%`;
    return `${sizes[idx].padStart(sizeW)} ${name}│${bar}│${pct}`;
  }).join('\n');
}

function cleanTree(node) {
  return { name: node.name, size: node.size, children: (node.children || []).map(cleanTree) };
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  if (opt.jsonInput) {
    try {
      const doc = JSON.parse(readStdin());
      if (!doc['schema-version']) throw new Error('missing field `schema-version`');
      const tree = prune(doc.tree, opt, doc.tree.size, 1);
      if (opt.jsonOutput) console.log(JSON.stringify({ ...doc, tree }));
      else console.log(chart(tree, opt));
    } catch (e) {
      console.error(`[error] DeserializationFailure: ${e.message}`);
      process.exit(3);
    }
    return;
  }
  const { root, shared } = makeTree(opt);
  const tree = prune(root, opt, root.size, 1);
  if (opt.jsonOutput) console.log(JSON.stringify(jsonDocument(tree, opt, shared)));
  else console.log(chart(tree, opt));
}

main();
