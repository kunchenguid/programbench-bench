#!/usr/bin/env node
'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const zlib = require('zlib');
const { spawnSync } = require('child_process');

const VERSION = 'miniserve 0.32.0';
const ABOUT = 'For when you really just want to serve some files over HTTP right now!';

const shortHelp = `${ABOUT}

Usage: executable [OPTIONS] [PATH]

Arguments:
  [PATH]  Which path to serve [env: MINISERVE_PATH=]

Options:
  -v, --verbose
          Be verbose, includes emitting access logs [env: MINISERVE_VERBOSE=]
      --temp-directory <TEMP_UPLOAD_DIRECTORY>
          The path to where file uploads will be written to before being moved to their correct
          location. It's wise to make sure that this directory will be written to disk and not into
          memory [env: MINISERVER_TEMP_UPLOAD_DIRECTORY=]
      --index <INDEX>
          The name of a directory index file to serve, like "index.html" [env: MINISERVE_INDEX=]
      --spa
          Activate SPA (Single Page Application) mode [env: MINISERVE_SPA=]
      --pretty-urls
          Activate Pretty URLs mode [env: MINISERVE_PRETTY_URLS=]
  -p, --port <PORT>
          Port to use [env: MINISERVE_PORT=] [default: 8080]
  -i, --interfaces <INTERFACES>
          Interface to listen on [env: MINISERVE_INTERFACE=]
  -a, --auth <AUTH>
          Set authentication [env: MINISERVE_AUTH=]
      --auth-file <AUTH_FILE>
          Read authentication values from a file [env: MINISERVE_AUTH_FILE=]
      --route-prefix <ROUTE_PREFIX>
          Use a specific route prefix [env: MINISERVE_ROUTE_PREFIX=]
      --random-route
          Generate a random 6-hexdigit route [env: MINISERVE_RANDOM_ROUTE=]
  -P, --no-symlinks
          Hide symlinks in listing and prevent them from being followed [env: MINISERVE_NO_SYMLINKS=]
  -H, --hidden
          Show hidden files [env: MINISERVE_HIDDEN=]
  -S, --default-sorting-method <DEFAULT_SORTING_METHOD>
          Default sorting method for file list [env: MINISERVE_DEFAULT_SORTING_METHOD=] [default: name] [possible values: name, size, date]
  -O, --default-sorting-order <DEFAULT_SORTING_ORDER>
          Default sorting order for file list [env: MINISERVE_DEFAULT_SORTING_ORDER=] [default: desc] [possible values: asc, desc]
  -c, --color-scheme <COLOR_SCHEME>
          Default color scheme [env: MINISERVE_COLOR_SCHEME=] [default: squirrel] [possible values: squirrel, archlinux, zenburn, monokai]
  -d, --color-scheme-dark <COLOR_SCHEME_DARK>
          Default color scheme [env: MINISERVE_COLOR_SCHEME_DARK=] [default: archlinux] [possible values: squirrel, archlinux, zenburn, monokai]
  -q, --qrcode
          Enable QR code display [env: MINISERVE_QRCODE=]
  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]
          Enable file uploading (and optionally specify for which directory) [env: MINISERVE_ALLOWED_UPLOAD_DIR=]
      --web-upload-files-concurrency <WEB_UPLOAD_CONCURRENCY>
          Configure amount of concurrent uploads when visiting the website [env: MINISERVE_WEB_UPLOAD_CONCURRENCY=] [default: 0]
      --chmod <CHMOD>
          Set unix file permissions of uploaded files [env: MINISERVE_CHMOD=]
      --directory-size
          Enable recursive directory size calculation [env: MINISERVE_DIRECTORY_SIZE=]
  -U, --mkdir
          Enable creating directories [env: MINISERVE_MKDIR_ENABLED=]
  -m, --media-type <MEDIA_TYPE>
          Specify uploadable media types [env: MINISERVE_MEDIA_TYPE=] [possible values: image, audio, video]
  -M, --raw-media-type <MEDIA_TYPE_RAW>
          Directly specify the uploadable media type expression [env: MINISERVE_RAW_MEDIA_TYPE=]
  -o, --on-duplicate-files <ON_DUPLICATE_FILES>
          What to do if existing files with same name is present during file upload [env: MINISERVE_ON_DUPLICATE_FILES=] [default: error] [possible values: error, overwrite, rename]
  -R, --rm-files [<ALLOWED_RM_DIR>]
          Enable file and directory deletion (and optionally specify for which directory) [env: MINISERVE_ALLOWED_RM_DIR=]
  -r, --enable-tar
          Enable uncompressed tar archive generation [env: MINISERVE_ENABLE_TAR=]
  -g, --enable-tar-gz
          Enable gz-compressed tar archive generation [env: MINISERVE_ENABLE_TAR_GZ=]
  -z, --enable-zip
          Enable zip archive generation [env: MINISERVE_ENABLE_ZIP=]
  -C, --compress-response
          Compress response [env: MINISERVE_COMPRESS_RESPONSE=]
  -D, --dirs-first
          List directories first [env: MINISERVE_DIRS_FIRST=]
  -t, --title <TITLE>
          Shown instead of host in page title and heading [env: MINISERVE_TITLE=]
      --header <HEADER>
          Inserts custom headers into the responses [env: MINISERVE_HEADER=]
  -l, --show-symlink-info
          Visualize symlinks in directory listing [env: MINISERVE_SHOW_SYMLINK_INFO=]
  -F, --hide-version-footer
          Hide version footer [env: MINISERVE_HIDE_VERSION_FOOTER=]
      --hide-theme-selector
          Hide theme selector [env: MINISERVE_HIDE_THEME_SELECTOR=]
  -W, --show-wget-footer
          If enabled, display a wget command to recursively download the current directory [env: MINISERVE_SHOW_WGET_FOOTER=]
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell, zsh]
      --print-manpage
          Generate man page
      --tls-cert <TLS_CERT>
          TLS certificate to use [env: MINISERVE_TLS_CERT=]
      --tls-key <TLS_KEY>
          TLS private key to use [env: MINISERVE_TLS_KEY=]
      --readme
          Enable README.md rendering in directories [env: MINISERVE_README=]
  -I, --disable-indexing
          Disable indexing [env: MINISERVE_DISABLE_INDEXING=]
      --enable-webdav
          Enable read-only WebDAV support (PROPFIND requests) [env: MINISERVE_ENABLE_WEBDAV=]
      --size-display <SIZE_DISPLAY>
          Show served file size in exact bytes [env: MINISERVE_SIZE_DISPLAY=] [default: human] [possible values: human, exact]
      --file-external-url <FILE_EXTERNAL_URL>
          Optional external URL prepended to file links in listings [env: MINISERVE_FILE_EXTERNAL_URL=]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version`;

function fail(msg, code = 1) {
  console.error(msg);
  process.exit(code);
}

function hasEnvFlag(name) {
  const v = process.env[name];
  return v !== undefined && v !== '' && v !== '0' && v !== 'false';
}

function parseArgs(argv) {
  const o = {
    port: +(process.env.MINISERVE_PORT || 8080),
    iface: process.env.MINISERVE_INTERFACE || '0.0.0.0',
    path: process.env.MINISERVE_PATH || '.',
    index: process.env.MINISERVE_INDEX || null,
    spa: hasEnvFlag('MINISERVE_SPA'),
    pretty: hasEnvFlag('MINISERVE_PRETTY_URLS'),
    hidden: hasEnvFlag('MINISERVE_HIDDEN'),
    noSymlinks: hasEnvFlag('MINISERVE_NO_SYMLINKS'),
    upload: process.env.MINISERVE_ALLOWED_UPLOAD_DIR !== undefined,
    uploadDir: process.env.MINISERVE_ALLOWED_UPLOAD_DIR || '/',
    mkdir: hasEnvFlag('MINISERVE_MKDIR_ENABLED'),
    rm: process.env.MINISERVE_ALLOWED_RM_DIR !== undefined,
    rmDir: process.env.MINISERVE_ALLOWED_RM_DIR || '/',
    tar: hasEnvFlag('MINISERVE_ENABLE_TAR'),
    targz: hasEnvFlag('MINISERVE_ENABLE_TAR_GZ'),
    zip: hasEnvFlag('MINISERVE_ENABLE_ZIP'),
    dirsFirst: hasEnvFlag('MINISERVE_DIRS_FIRST'),
    sortMethod: process.env.MINISERVE_DEFAULT_SORTING_METHOD || 'name',
    sortOrder: process.env.MINISERVE_DEFAULT_SORTING_ORDER || 'desc',
    title: process.env.MINISERVE_TITLE || null,
    auth: [],
    headers: [],
    routePrefix: process.env.MINISERVE_ROUTE_PREFIX || '',
    randomRoute: hasEnvFlag('MINISERVE_RANDOM_ROUTE'),
    readme: hasEnvFlag('MINISERVE_README'),
    disableIndexing: hasEnvFlag('MINISERVE_DISABLE_INDEXING'),
    sizeDisplay: process.env.MINISERVE_SIZE_DISPLAY || 'human',
    fileExternalUrl: process.env.MINISERVE_FILE_EXTERNAL_URL || '',
    verbose: hasEnvFlag('MINISERVE_VERBOSE'),
    tlsCert: process.env.MINISERVE_TLS_CERT || null,
    tlsKey: process.env.MINISERVE_TLS_KEY || null,
    onDuplicate: process.env.MINISERVE_ON_DUPLICATE_FILES || 'error',
    chmod: process.env.MINISERVE_CHMOD || null,
    compress: hasEnvFlag('MINISERVE_COMPRESS_RESPONSE'),
  };
  if (process.env.MINISERVE_AUTH) o.auth.push(...process.env.MINISERVE_AUTH.split(',').filter(Boolean));
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const need = () => {
      if (i + 1 >= argv.length) fail(`error: a value is required for '${a}' but none was supplied`);
      return argv[++i];
    };
    if (a === '-h') { console.log(shortHelp); process.exit(0); }
    if (a === '--help') { console.log(longHelp()); process.exit(0); }
    if (a === '-V' || a === '--version') { console.log(VERSION); process.exit(0); }
    if (a === '--print-manpage') { console.log(manpage()); process.exit(0); }
    if (a === '--print-completions') { need(); console.log('# completion generation is not implemented in this reimplementation'); process.exit(0); }
    if (a === '-v' || a === '--verbose') o.verbose = true;
    else if (a === '-p' || a === '--port') o.port = +need();
    else if (a === '-i' || a === '--interfaces') o.iface = need();
    else if (a === '--index') o.index = need();
    else if (a === '--spa') o.spa = true;
    else if (a === '--pretty-urls') o.pretty = true;
    else if (a === '-H' || a === '--hidden') o.hidden = true;
    else if (a === '-P' || a === '--no-symlinks') o.noSymlinks = true;
    else if (a === '-u' || a === '--upload-files') { o.upload = true; if (argv[i + 1] && !argv[i + 1].startsWith('-')) o.uploadDir = argv[++i]; }
    else if (a === '-U' || a === '--mkdir') o.mkdir = true;
    else if (a === '-R' || a === '--rm-files') { o.rm = true; if (argv[i + 1] && !argv[i + 1].startsWith('-')) o.rmDir = argv[++i]; }
    else if (a === '-r' || a === '--enable-tar') o.tar = true;
    else if (a === '-g' || a === '--enable-tar-gz') o.targz = true;
    else if (a === '-z' || a === '--enable-zip') o.zip = true;
    else if (a === '-D' || a === '--dirs-first') o.dirsFirst = true;
    else if (a === '-S' || a === '--default-sorting-method') o.sortMethod = need();
    else if (a === '-O' || a === '--default-sorting-order') o.sortOrder = need();
    else if (a === '-t' || a === '--title') o.title = need();
    else if (a === '-a' || a === '--auth') o.auth.push(need());
    else if (a === '--auth-file') o.auth.push(...fs.readFileSync(need(), 'utf8').split(/\r?\n/).filter(Boolean));
    else if (a === '--header') o.headers.push(need());
    else if (a === '--route-prefix') o.routePrefix = need();
    else if (a === '--random-route') o.randomRoute = true;
    else if (a === '--tls-cert') o.tlsCert = need();
    else if (a === '--tls-key') o.tlsKey = need();
    else if (a === '--readme') o.readme = true;
    else if (a === '-I' || a === '--disable-indexing') o.disableIndexing = true;
    else if (a === '--size-display') o.sizeDisplay = need();
    else if (a === '--file-external-url') o.fileExternalUrl = need();
    else if (a === '-C' || a === '--compress-response') o.compress = true;
    else if (a === '-o' || a === '--on-duplicate-files') o.onDuplicate = need();
    else if (a === '--chmod') o.chmod = need();
    else if (['-c','--color-scheme','-d','--color-scheme-dark','--temp-directory','--web-upload-files-concurrency','-m','--media-type','-M','--raw-media-type'].includes(a)) need();
    else if (['-q','--qrcode','--directory-size','-l','--show-symlink-info','-F','--hide-version-footer','--hide-theme-selector','-W','--show-wget-footer','--enable-webdav'].includes(a)) {}
    else if (a.startsWith('-')) fail(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [PATH]\n\nFor more information, try '--help'.`);
    else o.path = a;
  }
  if (!['name', 'size', 'date'].includes(o.sortMethod)) fail(`error: invalid value '${o.sortMethod}' for '--default-sorting-method <DEFAULT_SORTING_METHOD>'\n  [possible values: name, size, date]\n\nFor more information, try '--help'.`);
  if (!['asc', 'desc'].includes(o.sortOrder)) fail(`error: invalid value '${o.sortOrder}' for '--default-sorting-order <DEFAULT_SORTING_ORDER>'\n  [possible values: asc, desc]\n\nFor more information, try '--help'.`);
  if (!['human', 'exact'].includes(o.sizeDisplay)) fail(`error: invalid value '${o.sizeDisplay}' for '--size-display <SIZE_DISPLAY>'\n  [possible values: human, exact]`);
  if (!['error', 'overwrite', 'rename'].includes(o.onDuplicate)) fail(`error: invalid value '${o.onDuplicate}' for '--on-duplicate-files <ON_DUPLICATE_FILES>'`);
  if (o.randomRoute) o.routePrefix = '/' + crypto.randomBytes(3).toString('hex');
  o.routePrefix = normalizePrefix(o.routePrefix);
  return o;
}

function longHelp() {
  return `${ABOUT}

Usage: executable [OPTIONS] [PATH]

Arguments:
  [PATH]
          Which path to serve
          
          [env: MINISERVE_PATH=]

Options:
${shortHelp.split('Options:\n')[1].replace(/\[env:/g, '          [env:')}`;
}

function manpage() {
  return `.TH miniserve 1  "miniserve 0.32.0"\n.SH NAME\nminiserve \\- ${ABOUT}\n.SH SYNOPSIS\n\\fBminiserve\\fR [OPTIONS] [PATH]\n.SH DESCRIPTION\n${ABOUT}\n.SH OPTIONS\nSee \\fBminiserve --help\\fR for the full list of options.`;
}

function normalizePrefix(p) {
  if (!p) return '';
  if (!p.startsWith('/')) p = '/' + p;
  return p.endsWith('/') && p.length > 1 ? p.slice(0, -1) : p;
}

function htmlEscape(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function decodePathname(u) {
  try { return decodeURIComponent(new URL(u, 'http://x').pathname); } catch { return '/'; }
}

function safeJoin(root, rel) {
  rel = rel.replace(/^\/+/, '');
  const p = path.resolve(root, rel);
  const r = path.resolve(root);
  if (p !== r && !p.startsWith(r + path.sep)) return null;
  return p;
}

function mime(file) {
  const e = path.extname(file).toLowerCase();
  return {
    '.html':'text/html; charset=utf-8','.htm':'text/html; charset=utf-8','.txt':'text/plain; charset=utf-8',
    '.css':'text/css','.js':'application/javascript','.json':'application/json','.svg':'image/svg+xml',
    '.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.gif':'image/gif','.webp':'image/webp',
    '.pdf':'application/pdf','.wasm':'application/wasm','.xml':'application/xml','.mp3':'audio/mpeg',
    '.mp4':'video/mp4','.zip':'application/zip','.tar':'application/tar','.gz':'application/gzip'
  }[e] || 'application/octet-stream';
}

function human(n) {
  if (n < 1024) return `${n} B`;
  const units = ['KiB', 'MiB', 'GiB', 'TiB'];
  let v = n / 1024, i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v >= 10 ? v.toFixed(0) : v.toFixed(1)} ${units[i]}`;
}

function httpDate(ms) { return new Date(ms).toUTCString(); }

function applyHeaders(res, o, extra = {}) {
  for (const h of o.headers) {
    const ix = h.indexOf(':');
    if (ix > 0) {
      const k = h.slice(0, ix).trim(), v = h.slice(ix + 1).trim();
      if (!res.hasHeader(k)) res.setHeader(k, v);
    }
  }
  for (const [k, v] of Object.entries(extra)) res.setHeader(k, v);
}

function send(res, o, status, body, type = 'text/html', headers = {}) {
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(String(body));
  res.statusCode = status;
  applyHeaders(res, o, {'content-type': type, 'content-length': buf.length, ...headers});
  if (res.req.method === 'HEAD') res.end(); else res.end(buf);
}

function errorPage(res, o, status, msg) {
  send(res, o, status, `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${status} ${msg}</title><link rel="stylesheet" href="${o.routePrefix}/__miniserve_internal/style.css"></head><body><div class="error"><p>${status} ${msg}</p><p>${htmlEscape(msg)}</p><p><a class="error-back" href="javascript:history.back()">Go back</a></p></div></body></html>`, 'text/html');
}

function authorized(req, o) {
  if (!o.auth.length) return true;
  const h = req.headers.authorization || '';
  if (!h.startsWith('Basic ')) return false;
  const decoded = Buffer.from(h.slice(6), 'base64').toString();
  const ix = decoded.indexOf(':');
  if (ix < 0) return false;
  const user = decoded.slice(0, ix), pass = decoded.slice(ix + 1);
  for (const a of o.auth) {
    const parts = a.split(':');
    if (parts[0] !== user) continue;
    if (parts.length === 2 && parts[1] === pass) return true;
    if (parts.length >= 3) {
      const dig = crypto.createHash(parts[1]).update(pass).digest('hex');
      if (dig === parts.slice(2).join(':')) return true;
    }
  }
  return false;
}

async function serveFile(req, res, o, file, displayName) {
  let st;
  try { st = await fsp.stat(file); } catch { return errorPage(res, o, 404, 'Not Found'); }
  if (req.headers['if-modified-since'] && new Date(req.headers['if-modified-since']).getTime() >= Math.floor(st.mtimeMs / 1000) * 1000) {
    res.statusCode = 304; applyHeaders(res, o, {}); return res.end();
  }
  let start = 0, end = st.size - 1, code = 200;
  if (req.headers.range) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range);
    if (m) {
      if (m[1]) start = +m[1];
      if (m[2]) end = +m[2];
      if (!m[1] && m[2]) { start = Math.max(0, st.size - (+m[2])); end = st.size - 1; }
      if (start > end || start >= st.size) {
        res.statusCode = 416;
        applyHeaders(res, o, {'content-range': `bytes */${st.size}`});
        return res.end();
      }
      code = 206;
    }
  }
  const headers = {
    'content-type': mime(file),
    'content-length': Math.max(0, end - start + 1),
    'last-modified': httpDate(st.mtimeMs),
    'etag': `"${st.ino.toString(16)}:${st.size.toString(16)}:${Math.floor(st.mtimeMs/1000).toString(16)}"`,
    'accept-ranges': 'bytes',
    'content-disposition': `inline; filename="${path.basename(displayName || file).replace(/"/g, '')}"`
  };
  if (code === 206) headers['content-range'] = `bytes ${start}-${end}/${st.size}`;
  res.statusCode = code; applyHeaders(res, o, headers);
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file, { start, end }).pipe(res);
}

async function listDir(req, res, o, dir, urlPath) {
  if (o.disableIndexing) return errorPage(res, o, 403, 'Forbidden');
  let entries = await fsp.readdir(dir, { withFileTypes: true });
  const rows = [];
  for (const e of entries) {
    if (!o.hidden && e.name.startsWith('.')) continue;
    const full = path.join(dir, e.name);
    let st;
    try { st = await fsp.lstat(full); } catch { continue; }
    if (o.noSymlinks && st.isSymbolicLink()) continue;
    const isDir = e.isDirectory();
    rows.push({ name: e.name, isDir, size: st.size, mtime: st.mtimeMs, symlink: st.isSymbolicLink() });
  }
  rows.sort((a, b) => {
    if (o.dirsFirst && a.isDir !== b.isDir) return a.isDir ? -1 : 1;
    let c = 0;
    if (o.sortMethod === 'size') c = a.size - b.size;
    else if (o.sortMethod === 'date') c = a.mtime - b.mtime;
    else c = a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
    return o.sortOrder === 'desc' ? -c : c;
  });
  const title = o.title || `${req.headers.host || 'localhost'}${urlPath === '/' ? '' : urlPath.replace(/\/$/, '')}`;
  const up = urlPath !== '/' ? `<p><a class="root" href="../">..</a></p>` : '';
  let table = '';
  for (const r of rows) {
    const href = (o.fileExternalUrl && !r.isDir ? o.fileExternalUrl.replace(/\/$/, '') : '') + encodeURIComponent(r.name) + (r.isDir ? '/' : '');
    const cls = r.isDir ? 'directory' : 'file';
    const size = r.isDir ? '-' : (o.sizeDisplay === 'exact' ? String(r.size) : human(r.size));
    table += `<tr class="entry-type-${r.isDir ? 'directory' : 'file'}"><td><p><a class="${cls}" href="${href}">${htmlEscape(r.name)}${r.isDir ? '/' : ''}</a></p></td><td class="size-cell">${size}</td><td class="date-cell">${httpDate(r.mtime)}</td></tr>`;
  }
  let readme = '';
  if (o.readme) {
    for (const name of ['README.md', 'README.txt', 'README']) {
      try {
        const txt = await fsp.readFile(path.join(dir, name), 'utf8');
        readme = `<section class="readme"><h2>${name}</h2><pre>${htmlEscape(txt)}</pre></section>`;
        break;
      } catch {}
    }
  }
  const tools = `${o.tar ? '<a href="?download=tar">Download .tar</a> ' : ''}${o.targz ? '<a href="?download=targz">Download .tar.gz</a> ' : ''}${o.zip ? '<a href="?download=zip">Download .zip</a>' : ''}`;
  const upload = o.upload ? `<form action="${o.routePrefix}/upload?path=${encodeURIComponent(urlPath)}" method="post" enctype="multipart/form-data"><input type="file" name="path" multiple><button>Upload</button></form>` : '';
  const mkdir = o.mkdir ? `<form action="${o.routePrefix}/mkdir?path=${encodeURIComponent(urlPath)}" method="post"><input name="name"><button>Make directory</button></form>` : '';
  const body = `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="icon" type="image/svg+xml" href="${o.routePrefix}/__miniserve_internal/favicon.svg"><link rel="stylesheet" href="${o.routePrefix}/__miniserve_internal/style.css"><title>${htmlEscape(title)}</title></head><body><nav></nav><div class="container"><h1 class="title">${htmlEscape(title)}</h1>${up}<div class="download">${tools}</div><div class="toolbar_box">${upload}${mkdir}</div><table><thead><tr><th><a href="?sort=name">Name</a></th><th class="size"><a href="?sort=size">Size</a></th><th class="date"><a href="?sort=date">Modified</a></th></tr></thead><tbody>${table}</tbody></table>${readme}<div class="footer">miniserve v0.32.0</div></div></body></html>`;
  send(res, o, 200, body, 'text/html; charset=utf-8');
}

function staticInternal(req, res, o, pathname) {
  if (pathname.endsWith('/style.css')) {
    return send(res, o, 200, 'body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;background:#fff;color:#323232}.container{padding:1.5rem 5rem}a.file{color:#0086b3}a.directory{font-weight:bold;color:#d02474}table{margin-top:2rem;width:100%;border-collapse:collapse}td,th{padding:.55rem .625rem;text-align:left}thead{background:#323232;color:#fff}tbody tr:nth-child(odd){background:#fbfbfb}tbody tr:nth-child(even){background:#f2f2f2}.footer{text-align:center;padding:1.5rem;color:#898989;font-size:.7em}.error{margin:2rem}.download a,button{background:#d02474;color:#fff;border:0;border-radius:.2rem;padding:.5rem;margin-right:.5rem;text-decoration:none}', 'text/css');
  }
  if (pathname.endsWith('/favicon.svg')) {
    return send(res, o, 200, '<svg xmlns="http://www.w3.org/2000/svg" width="170" height="150"><text y="100" font-size="100">m</text></svg>', 'image/svg+xml');
  }
  if (pathname.endsWith('/api')) return send(res, o, 200, '{}', 'application/json');
  return errorPage(res, o, 404, 'Not Found');
}

async function collectFiles(root, dir = root, base = path.basename(root)) {
  const out = [];
  out.push({ full: dir, rel: path.posix.join(base, path.relative(root, dir).split(path.sep).join('/')) + '/', dir: true });
  const names = await fsp.readdir(dir, { withFileTypes: true });
  for (const e of names) {
    const full = path.join(dir, e.name);
    const rel = path.posix.join(base, path.relative(root, full).split(path.sep).join('/'));
    if (e.isDirectory()) out.push(...await collectFiles(root, full, base));
    else if (e.isFile()) out.push({ full, rel, dir: false });
  }
  return out;
}

const crcTable = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (const b of buf) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

async function makeZip(root) {
  const entries = await collectFiles(root);
  const locals = [], centrals = [];
  let offset = 0;
  for (const e of entries) {
    const name = Buffer.from(e.rel);
    const data = e.dir ? Buffer.alloc(0) : await fsp.readFile(e.full);
    const crc = crc32(data);
    const local = Buffer.alloc(30 + name.length);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0, 6);
    local.writeUInt16LE(0, 8);
    local.writeUInt16LE(0, 10);
    local.writeUInt16LE(0, 12);
    local.writeUInt32LE(crc, 14);
    local.writeUInt32LE(data.length, 18);
    local.writeUInt32LE(data.length, 22);
    local.writeUInt16LE(name.length, 26);
    local.writeUInt16LE(0, 28);
    name.copy(local, 30);
    locals.push(local, data);
    const central = Buffer.alloc(46 + name.length);
    central.writeUInt32LE(0x02014b50, 0);
    central.writeUInt16LE(20, 4);
    central.writeUInt16LE(20, 6);
    central.writeUInt16LE(0, 8);
    central.writeUInt16LE(0, 10);
    central.writeUInt16LE(0, 12);
    central.writeUInt16LE(0, 14);
    central.writeUInt32LE(crc, 16);
    central.writeUInt32LE(data.length, 20);
    central.writeUInt32LE(data.length, 24);
    central.writeUInt16LE(name.length, 28);
    central.writeUInt16LE(0, 30);
    central.writeUInt16LE(0, 32);
    central.writeUInt16LE(0, 34);
    central.writeUInt16LE(0, 36);
    central.writeUInt32LE(e.dir ? 0x10 : 0, 38);
    central.writeUInt32LE(offset, 42);
    name.copy(central, 46);
    centrals.push(central);
    offset += local.length + data.length;
  }
  const centralSize = centrals.reduce((n, b) => n + b.length, 0);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);
  return Buffer.concat([...locals, ...centrals, end]);
}

async function sendArchive(req, res, o, fsPath, kind) {
  const parent = path.dirname(fsPath), base = path.basename(fsPath);
  if (kind === 'zip') {
    const buf = await makeZip(fsPath);
    return send(res, o, 200, buf, 'application/zip', {'content-disposition': `attachment; filename="${base}.zip"`, 'content-transfer-encoding': 'binary'});
  }
  const args = [];
  if (kind === 'tar') args.push('-cf', '-', base);
  else if (kind === 'targz' || kind === 'tar.gz') args.push('-czf', '-', base);
  const r = spawnSync('tar', args, { cwd: parent, encoding: null });
  if (r.status !== 0) return errorPage(res, o, 500, 'Archive generation failed');
  const ext = kind === 'targz' ? 'tar.gz' : kind;
  const type = kind === 'zip' ? 'application/zip' : (kind === 'tar' ? 'application/tar' : 'application/gzip');
  send(res, o, 200, r.stdout, type, {'content-disposition': `attachment; filename="${base}.${ext}"`, 'content-transfer-encoding': 'binary'});
}

async function parseMultipart(req, uploadRoot, o) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  const body = Buffer.concat(chunks);
  const ct = req.headers['content-type'] || '';
  const m = /boundary=(?:"([^"]+)"|([^;]+))/.exec(ct);
  if (!m) throw new Error('missing boundary');
  const boundary = Buffer.from('--' + (m[1] || m[2]));
  let pos = 0;
  while ((pos = body.indexOf(boundary, pos)) >= 0) {
    pos += boundary.length;
    if (body[pos] === 45 && body[pos + 1] === 45) break;
    if (body[pos] === 13 && body[pos + 1] === 10) pos += 2;
    const hdrEnd = body.indexOf(Buffer.from('\r\n\r\n'), pos);
    if (hdrEnd < 0) break;
    const headers = body.slice(pos, hdrEnd).toString();
    let dataStart = hdrEnd + 4;
    let next = body.indexOf(boundary, dataStart);
    if (next < 0) break;
    let data = body.slice(dataStart, Math.max(dataStart, next - 2));
    const fm = /filename="([^"]*)"/.exec(headers);
    if (fm && fm[1]) {
      let name = path.basename(fm[1]);
      let dest = safeJoin(uploadRoot, name);
      if (!dest) continue;
      if (fs.existsSync(dest)) {
        if (o.onDuplicate === 'error') throw new Error('duplicate');
        if (o.onDuplicate === 'rename') {
          const ext = path.extname(name), stem = name.slice(0, -ext.length);
          let n = 1;
          do { dest = safeJoin(uploadRoot, `${stem}-${n++}${ext}`); } while (fs.existsSync(dest));
        }
      }
      await fsp.writeFile(dest, data);
      if (o.chmod) await fsp.chmod(dest, parseInt(o.chmod, 8));
    }
    pos = next;
  }
}

async function handle(req, res, o, root) {
  res.req = req;
  if (!authorized(req, o)) {
    res.statusCode = 401;
    applyHeaders(res, o, {'www-authenticate': 'Basic realm="miniserve"'});
    return res.end('Authentication required');
  }
  let u = new URL(req.url, 'http://x');
  let pathname = decodePathname(req.url);
  if (o.routePrefix) {
    if (pathname === o.routePrefix) {
      res.statusCode = 307; applyHeaders(res, o, {'location': o.routePrefix + '/'}); return res.end();
    }
    if (!pathname.startsWith(o.routePrefix + '/')) return errorPage(res, o, 404, 'Not Found');
    pathname = pathname.slice(o.routePrefix.length) || '/';
  }
  if (o.verbose) console.error(`${new Date().toISOString()} ${req.method} ${pathname}`);
  if (pathname.startsWith('/__miniserve_internal/')) return staticInternal(req, res, o, pathname);
  if (req.method === 'POST' && pathname === '/upload' && o.upload) {
    const target = safeJoin(root, u.searchParams.get('path') || '/');
    const allowed = safeJoin(root, o.uploadDir || '/');
    if (!target || !allowed || (target !== allowed && !target.startsWith(allowed + path.sep))) return errorPage(res, o, 403, 'Forbidden');
    await parseMultipart(req, target, o);
    res.statusCode = 303; applyHeaders(res, o, {'location': (o.routePrefix || '') + (u.searchParams.get('path') || '/')}); return res.end();
  }
  if (req.method === 'POST' && pathname === '/mkdir' && o.mkdir) {
    const chunks = []; for await (const c of req) chunks.push(c);
    const form = new URLSearchParams(Buffer.concat(chunks).toString());
    const target = safeJoin(root, path.join(u.searchParams.get('path') || '/', form.get('name') || ''));
    if (target) await fsp.mkdir(target, { recursive: true });
    res.statusCode = 303; applyHeaders(res, o, {'location': (o.routePrefix || '') + (u.searchParams.get('path') || '/')}); return res.end();
  }
  let rel = pathname;
  let fsPath = safeJoin(root, rel);
  if (!fsPath) return errorPage(res, o, 404, 'Not Found');
  if (!o.hidden && rel.split('/').some(p => p.startsWith('.') && p.length > 1)) return errorPage(res, o, 400, 'Bad Request');
  let st;
  try { st = o.noSymlinks ? await fsp.lstat(fsPath) : await fsp.stat(fsPath); } catch { st = null; }
  if ((!st || !st.isFile()) && o.pretty) {
    const alt = safeJoin(root, rel.replace(/\/$/, '') + '.html');
    try { const ast = await fsp.stat(alt); if (ast.isFile()) { fsPath = alt; st = ast; } } catch {}
  }
  if (!st && o.spa && o.index) {
    const idx = safeJoin(root, o.index);
    try { const ist = await fsp.stat(idx); if (ist.isFile()) { fsPath = idx; st = ist; } } catch {}
  }
  if (!st) return errorPage(res, o, 404, 'Not Found');
  if (o.noSymlinks && st.isSymbolicLink()) return errorPage(res, o, 404, 'Not Found');
  if (st.isDirectory()) {
    if (!pathname.endsWith('/')) {
      res.statusCode = 307; applyHeaders(res, o, {'location': (o.routePrefix || '') + pathname + '/'}); return res.end();
    }
    if ((o.tar || o.targz || o.zip) && u.searchParams.has('download')) {
      const d = u.searchParams.get('download') || 'tar';
      if (d === 'tar' && o.tar) return sendArchive(req, res, o, fsPath, 'tar');
      if ((d === 'targz' || d === 'tar.gz') && o.targz) return sendArchive(req, res, o, fsPath, 'targz');
      if (d === 'zip' && o.zip) return sendArchive(req, res, o, fsPath, 'zip');
    }
    if (o.index) {
      const idx = path.join(fsPath, o.index);
      try { const ist = await fsp.stat(idx); if (ist.isFile()) return serveFile(req, res, o, idx, o.index); } catch {}
    }
    return listDir(req, res, o, fsPath, pathname);
  }
  if (req.method === 'DELETE' && o.rm) {
    const allowed = safeJoin(root, o.rmDir || '/');
    if (allowed && (fsPath === allowed || fsPath.startsWith(allowed + path.sep))) {
      await fsp.rm(fsPath, { recursive: true, force: true });
      res.statusCode = 204; applyHeaders(res, o, {}); return res.end();
    }
  }
  return serveFile(req, res, o, fsPath, path.basename(fsPath));
}

async function main() {
  const o = parseArgs(process.argv.slice(2));
  let root;
  try { root = await fsp.realpath(path.resolve(o.path)); } catch (e) {
    console.error(`${new Date().toUTCString().replace('GMT', '+0000')} [ERROR] Failed to resolve path to be served`);
    console.error(`${new Date().toUTCString().replace('GMT', '+0000')} [ERROR] caused by: ${e.message}`);
    console.error(`Error: Failed to resolve path to be served\ncaused by: ${e.message}`);
    process.exit(1);
  }
  const server = o.tlsCert && o.tlsKey
    ? https.createServer({ cert: fs.readFileSync(o.tlsCert), key: fs.readFileSync(o.tlsKey) }, (req, res) => handle(req, res, o, root).catch(e => errorPage(res, o, 500, e.message)))
    : http.createServer((req, res) => handle(req, res, o, root).catch(e => errorPage(res, o, 500, e.message)));
  server.listen(o.port, o.iface.split(',')[0], () => {
    const addr = server.address();
    console.error('miniserve v0.32.0');
    console.error(`Bound to ${addr.address}:${addr.port}`);
    console.error(`Serving path ${root}`);
    console.error('Available at (non-exhaustive list):');
    console.error(`    ${o.tlsCert ? 'https' : 'http'}://${addr.address}:${addr.port}${o.routePrefix || ''}`);
    console.error('');
  });
}

main();
