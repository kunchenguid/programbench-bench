#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');
const crypto = require('crypto');

const VERSION = '2.37.1';

for (const stream of [process.stdout, process.stderr]) {
  stream.on('error', (err) => {
    if (err && err.code === 'EPIPE') process.exit(0);
    throw err;
  });
}

function color(code, s) {
  return process.env.NO_COLOR ? s : `\x1b[${code}m${s}\x1b[0m`;
}

function logStatus(msg) {
  process.stderr.write(color('0', `direnv: ${msg}`) + '\n');
}

function logError(msg) {
  process.stderr.write(color('31', `direnv: error ${msg}`) + '\n');
}

function home() {
  return process.env.HOME || os.homedir() || '/tmp';
}

function configDir() {
  return process.env.DIRENV_CONFIG || path.join(process.env.XDG_CONFIG_HOME || path.join(home(), '.config'), 'direnv');
}

function dataDir() {
  return path.join(process.env.XDG_DATA_HOME || path.join(home(), '.local', 'share'), 'direnv');
}

function cacheDir() {
  return path.join(process.env.XDG_CACHE_HOME || path.join(home(), '.cache'), 'direnv');
}

function selfPath() {
  return process.env.DIRENV_SELF || process.argv[1] || 'direnv';
}

function shellQuote(s) {
  s = String(s);
  if (s === '') return "''";
  return "'" + s.replace(/'/g, "'\\''") + "'";
}

function bashDollarQuote(s) {
  s = String(s);
  return "$'" + s
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/\n/g, '\\n')
    .replace(/\r/g, '\\r')
    .replace(/\t/g, '\\t') + "'";
}

function fishQuote(s) {
  return "'" + String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'") + "'";
}

function pwshQuote(s) {
  return "'" + String(s).replace(/'/g, "''") + "'";
}

function ensureDir(d) {
  fs.mkdirSync(d, {recursive: true});
}

function sha256File(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function canonicalRc(arg) {
  let p = arg || '.';
  if (!path.isAbsolute(p)) p = path.resolve(process.cwd(), p);
  try {
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      const envrc = path.join(p, '.envrc');
      const env = path.join(p, '.env');
      if (fs.existsSync(envrc)) p = envrc;
      else if (fs.existsSync(env)) p = env;
      else p = envrc;
    }
  } catch {
    if (!path.basename(p).startsWith('.env')) p = path.join(p, '.envrc');
  }
  return path.resolve(p);
}

function findRc(start) {
  let dir = path.resolve(start || process.cwd());
  for (;;) {
    const envrc = path.join(dir, '.envrc');
    if (fs.existsSync(envrc)) return envrc;
    const env = path.join(dir, '.env');
    if (fs.existsSync(env)) return env;
    const parent = path.dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

function allowPath() {
  return path.join(dataDir(), 'allow.json');
}

function readAllows() {
  try {
    return JSON.parse(fs.readFileSync(allowPath(), 'utf8'));
  } catch {
    return {};
  }
}

function writeAllows(obj) {
  ensureDir(dataDir());
  fs.writeFileSync(allowPath(), JSON.stringify(obj, null, 2));
}

function isAllowed(file) {
  try {
    const allows = readAllows();
    return allows[path.resolve(file)] === sha256File(file);
  } catch {
    return false;
  }
}

function allowFile(file) {
  if (!fs.existsSync(file)) throw new Error(`${file} does not exist`);
  const allows = readAllows();
  allows[path.resolve(file)] = sha256File(file);
  writeAllows(allows);
}

function denyFile(file) {
  const allows = readAllows();
  delete allows[path.resolve(file)];
  writeAllows(allows);
}

function parseEnvBlock(buf) {
  const env = {};
  for (const item of buf.split('\0')) {
    if (!item) continue;
    const i = item.indexOf('=');
    if (i >= 0) env[item.slice(0, i)] = item.slice(i + 1);
  }
  return env;
}

function stdlib() {
  return `#!/usr/bin/env bash
shopt -s nullglob
direnv="\${DIRENV_SELF:-${selfPath().replace(/"/g, '\\"')}}"
direnv_config_dir="\${DIRENV_CONFIG:-\${XDG_CONFIG_HOME:-$HOME/.config}/direnv}"
export DIRENV_IN_ENVRC=1

log_status() { "$direnv" log --status "$*"; }
log_error() { "$direnv" log --error "$*"; }
has() { type "$1" &>/dev/null; }
join_args() { printf '%q ' "$@"; }
expand_path() {
  local p="$1" base="\${2:-$PWD}"
  if [[ "$p" = /* ]]; then (cd / && realpath -m "$p"); else (cd "$base" 2>/dev/null && realpath -m "$p"); fi
}
user_rel_path() {
  case "$1" in "$HOME"/*) printf '~/%s\\n' "\${1#"$HOME"/}" ;; "$HOME") echo '~' ;; *) echo "$1" ;; esac
}
find_up() {
  local name="\${1:-.envrc}" d="$PWD"
  while true; do
    [[ -e "$d/$name" ]] && { echo "$d/$name"; return 0; }
    [[ "$d" = / ]] && return 1
    d="\${d%/*}"; [[ -z "$d" ]] && d=/
  done
}
dotenv() {
  local f="\${1:-.env}"
  [[ -f "$f" ]] || { log_error "$f does not exist"; return 1; }
  set -a
  source "$f"
  set +a
}
dotenv_if_exists() { local f="\${1:-.env}"; [[ -f "$f" ]] && dotenv "$f" || true; }
source_env() { local f="$1"; [[ -d "$f" ]] && f="$f/.envrc"; source "$f"; }
source_env_if_exists() { [[ -f "$1" ]] && source "$1" || true; }
source_up() { local f; f="$(find_up "\${1:-.envrc}")" || return 1; source "$f"; }
source_up_if_exists() { source_up "\${1:-.envrc}" || true; }
env_vars_required() {
  local miss=0 v
  for v in "$@"; do [[ -n "\${!v:-}" ]] || { log_error "required environment variable '$v' is missing"; miss=1; }; done
  return "$miss"
}
path_add() {
  local var="$1" p; shift
  p="$(expand_path "$1")"
  if [[ -n "\${!var:-}" ]]; then export "$var=$p:\${!var}"; else export "$var=$p"; fi
}
PATH_add() { path_add PATH "$1"; }
MANPATH_add() { path_add MANPATH "$1"; }
PATH_rm() {
  local out= part pat keep
  IFS=: read -ra __parts <<< "\${PATH:-}"
  for part in "\${__parts[@]}"; do
    keep=1
    for pat in "$@"; do [[ "$part" == $pat ]] && keep=0; done
    [[ "$keep" = 1 ]] && out="\${out:+$out:}$part"
  done
  export PATH="$out"
}
load_prefix() {
  local p; p="$(expand_path "$1")"
  PATH_add "$p/bin"; MANPATH_add "$p/share/man"; path_add CPATH "$p/include"; path_add LD_LIBRARY_PATH "$p/lib"; path_add LIBRARY_PATH "$p/lib"; path_add PKG_CONFIG_PATH "$p/lib/pkgconfig"
}
direnv_layout_dir() { echo "\${direnv_layout_dir:-$PWD/.direnv}"; }
layout() {
  local t="$1"
  case "$t" in
    node) PATH_add node_modules/.bin ;;
    go) export GOPATH="$(direnv_layout_dir)/go"; PATH_add bin ;;
    julia) export JULIA_PROJECT="$PWD" ;;
    php) PATH_add vendor/bin ;;
    python|python3) local d="$(direnv_layout_dir)/python"; export VIRTUAL_ENV="$d"; PATH_add "$d/bin" ;;
    ruby) PATH_add bin ;;
    *) log_error "unknown layout type $t"; return 1 ;;
  esac
}
watch_file() { :; }
watch_dir() { :; }
watch_file_up() { find_up "$1" >/dev/null || true; }
strict_env() { set -euo pipefail; "$@"; }
unstrict_env() { set +e +u +o pipefail; "$@"; }
semver_search() {
  local dir="$1" prefix="$2" partial="$3"
  find "$dir" -maxdepth 1 -type d -name "$prefix$partial*" -printf '%f\\n' 2>/dev/null | sed "s/^$prefix//" | sort -V | tail -1
}
source_url() { source "$(fetchurl "$1" "$2")"; }
fetchurl() { "$direnv" fetchurl "$@"; }
direnv_load() { eval "$("$@")"; }
direnv_apply_dump() { source "$1"; }
`;
}

function evalRc(file) {
  const before = process.env;
  const script = `
set -e
cd ${shellQuote(path.dirname(file))}
${stdlib()}
if [[ ${shellQuote(path.basename(file))} == ".env" ]]; then dotenv ${shellQuote(file)}; else source ${shellQuote(file)}; fi
node -e 'for (const [k,v] of Object.entries(process.env)) process.stdout.write(k+"="+v+"\\0")'
`;
  const res = cp.spawnSync('/usr/bin/bash', ['-lc', script], {
    cwd: path.dirname(file),
    env: {...process.env, DIRENV_SELF: selfPath()},
    encoding: 'utf8',
    maxBuffer: 16 * 1024 * 1024,
  });
  if (res.stderr) process.stderr.write(res.stderr);
  if (res.status !== 0) return {ok: false, env: {}, added: {}, changed: {}, removed: [], status: res.status || 1};
  const after = parseEnvBlock(res.stdout);
  delete after.DIRENV_IN_ENVRC;
  delete after.DIRENV_SELF;
  delete after._;
  after.DIRENV_FILE = file;
  after.DIRENV_DIR = '-' + path.dirname(file);
  after.DIRENV_DIFF = crypto.createHash('sha1').update(JSON.stringify({file, after})).digest('base64url');
  after.DIRENV_WATCHES = crypto.createHash('sha1').update(file + ':' + sha256File(file)).digest('base64url');
  const added = {}, changed = {}, removed = [];
  const ignoredDiff = new Set(['PWD', 'SHLVL', '_', 'OLDPWD', 'DIRENV_SELF']);
  for (const [k, v] of Object.entries(after)) {
    if (ignoredDiff.has(k)) continue;
    if (!(k in before)) added[k] = v;
    else if (before[k] !== v) changed[k] = v;
  }
  for (const k of Object.keys(before)) {
    if (!(k in after) && !k.startsWith('BASH_') && !ignoredDiff.has(k)) removed.push(k);
  }
  return {ok: true, env: after, added, changed, removed, status: 0};
}

function diffSummary(d) {
  const parts = [];
  for (const k of Object.keys(d.added).sort()) if (!k.startsWith('DIRENV_')) parts.push('+' + k);
  for (const k of Object.keys(d.changed).sort()) if (!k.startsWith('DIRENV_')) parts.push('~' + k);
  for (const k of d.removed.sort()) if (!k.startsWith('DIRENV_')) parts.push('-' + k);
  return parts.join(' ');
}

function printExports(shell, d) {
  const env = d.env;
  const changedKeys = [...new Set([...Object.keys(d.added), ...Object.keys(d.changed)])];
  const keys = changedKeys.filter(k => !(k === 'PWD' || k === 'SHLVL' || k === '_'));
  if (shell === 'json') {
    const obj = {};
    for (const k of keys.sort()) obj[k] = env[k];
    process.stdout.write(JSON.stringify(obj, null, 2));
    return;
  }
  if (shell === 'bash' || shell === 'zsh') {
    for (const k of d.removed) process.stdout.write(`unset ${k};`);
    for (const k of keys) process.stdout.write(`export ${k}=${bashDollarQuote(env[k])};`);
    return;
  }
  if (shell === 'fish') {
    for (const k of d.removed) process.stdout.write(`set -e ${fishQuote(k)};`);
    for (const k of keys) process.stdout.write(`set -x -g ${fishQuote(k)} ${fishQuote(env[k])};`);
    return;
  }
  if (shell === 'tcsh') {
    for (const k of d.removed) process.stdout.write(`unsetenv ${k};`);
    for (const k of keys) process.stdout.write(`setenv ${k} ${shellQuote(env[k])};`);
    return;
  }
  if (shell === 'pwsh') {
    for (const k of d.removed) process.stdout.write(`Remove-Item Env:${k} -ErrorAction SilentlyContinue\n`);
    for (const k of keys) process.stdout.write(`$Env:${k} = ${pwshQuote(env[k])}\n`);
    return;
  }
  if (shell === 'gha') {
    for (const k of keys) process.stdout.write(`${k}=${env[k]}\n`);
    return;
  }
  if (shell === 'systemd') {
    for (const k of keys) process.stdout.write(`${k}=${env[k]}\n`);
    return;
  }
  for (const k of keys) process.stdout.write(`${k}=${env[k]}\n`);
}

function runExport(shell) {
  const allowedShells = ['vim','zsh','fish','gha','gzenv','json','murex','tcsh','bash','elvish','pwsh','systemd'];
  if (!allowedShells.includes(shell)) {
    logError(`unsupported shell '${shell}'`);
    return 1;
  }
  const rc = findRc(process.cwd());
  if (!rc) return 0;
  if (!isAllowed(rc)) {
    const fake = {env: {DIRENV_FILE: rc, DIRENV_DIR: '-' + path.dirname(rc), DIRENV_DIFF: '', DIRENV_WATCHES: ''}, added: {DIRENV_FILE: rc, DIRENV_DIR: '-' + path.dirname(rc), DIRENV_DIFF: '', DIRENV_WATCHES: ''}, changed: {}, removed: []};
    printExports(shell, fake);
    logError(`${rc} is blocked. Run \`direnv allow\` to approve its content`);
    return 1;
  }
  const d = evalRc(rc);
  if (!d.ok) return d.status;
  printExports(shell, d);
  logStatus(`loading ${rc}`);
  const s = diffSummary(d);
  if (s) logStatus(`export ${s}`);
  return 0;
}

function help() {
  process.stdout.write(`direnv v${VERSION}
Usage: direnv COMMAND [...ARGS]

Available commands
------------------
allow [PATH_TO_RC]:
  aliases: permit, grant
  Grants direnv permission to load the given .envrc or .env file.
block [PATH_TO_RC]:
  aliases: deny, disallow, revoke
  Revokes the authorization of a given .envrc or .env file.
edit [PATH_TO_RC]:
  Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow
  the file to be loaded afterwards.
exec DIR COMMAND [...ARGS]:
  Executes a command after loading the first .envrc or .env found in DIR
export SHELL:
  Loads an .envrc or .env and prints the diff in terms of exports.
  Supported SHELL values are: [vim, zsh, fish, gha, gzenv, json, murex, tcsh, bash, elvish, pwsh, systemd]
fetchurl <url> [<integrity-hash>]:
  Fetches a given URL into direnv's CAS
help [SHOW_PRIVATE]:
  Shows this help
hook SHELL:
  Used to setup the shell hook
prune:
  Removes old allowed and required files
reload:
  Triggers an env reload
status [--json]:
  Prints some debug status information
stdlib:
  Displays the stdlib available in the .envrc execution context
version [VERSION_AT_LEAST]:
  prints the version or checks that direnv is older than VERSION_AT_LEAST.
log [--status | --error] <message>:
  Logs a given message
`);
}

function hook(shell) {
  const exe = selfPath();
  if (shell === 'bash') { process.stdout.write(`
_direnv_hook() {
  local previous_exit_status=$?;
  vars="$("${exe}" export bash)";
  trap -- '' SIGINT;
  eval "$vars";
  trap - SIGINT;
  return $previous_exit_status;
};
if [[ ";\${PROMPT_COMMAND[*]:-};" != *";_direnv_hook;"* ]]; then
  if [[ "$(declare -p PROMPT_COMMAND 2>&1)" == "declare -a"* ]]; then
    PROMPT_COMMAND=(_direnv_hook "\${PROMPT_COMMAND[@]}")
  else
    PROMPT_COMMAND="_direnv_hook\${PROMPT_COMMAND:+;$PROMPT_COMMAND}"
  fi
fi
`); return 0; }
  if (shell === 'zsh') { process.stdout.write(`
_direnv_hook() {
  vars="$("${exe}" export zsh)"
  trap -- '' SIGINT
  eval "$vars"
  trap - SIGINT
}
typeset -ag precmd_functions
if (( ! \${precmd_functions[(I)_direnv_hook]} )); then
  precmd_functions=(_direnv_hook $precmd_functions)
fi
typeset -ag chpwd_functions
if (( ! \${chpwd_functions[(I)_direnv_hook]} )); then
  chpwd_functions=(_direnv_hook $chpwd_functions)
fi
`); return 0; }
  if (shell === 'fish') { process.stdout.write(`
    function __direnv_export_eval --on-event fish_prompt;
        "${exe}" export fish | source;
    end;
`); return 0; }
  if (shell === 'tcsh') { process.stdout.write(`alias precmd 'eval \`${exe} export tcsh\`'`); return 0; }
  if (shell === 'pwsh') { process.stdout.write(`$ExecutionContext.SessionState.InvokeCommand.LocationChangedAction = { Invoke-Expression "$(${exe} export pwsh)" }\n`); return 0; }
  if (shell === 'elvish') { process.stdout.write(`fn direnv:hook { eval (${exe} export elvish) }\n`); return 0; }
  if (shell === 'murex') { process.stdout.write(`event onPrompt direnv=${exe} export murex -> source\n`); return 0; }
  logError(`unsupported shell '${shell}'`);
  return 1;
}

function versionAtLeast(want) {
  const a = VERSION.split('.').map(Number), b = want.replace(/^v/, '').split('.').map(Number);
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const x = a[i] || 0, y = b[i] || 0;
    if (x < y) return false;
    if (x > y) return true;
  }
  return true;
}

function status(json) {
  const rc = findRc(process.cwd());
  if (json) {
    process.stdout.write(JSON.stringify({config: {ConfigDir: configDir(), SelfPath: selfPath()}, state: {foundRC: rc, loadedRC: process.env.DIRENV_FILE || null}}, null, 2) + '\n');
    return 0;
  }
  process.stdout.write(`direnv exec path ${selfPath()}
DIRENV_CONFIG ${configDir()}
bash_path /usr/bin/bash
disable_stdin false
warn_timeout 5s
whitelist.prefix []
whitelist.exact map[]
${process.env.DIRENV_FILE ? `Loaded RC path ${process.env.DIRENV_FILE}` : 'No .envrc or .env loaded'}
${rc ? `Found RC path ${rc}` : 'No .envrc or .env found'}
`);
  return 0;
}

function cmdExec(args) {
  if (args.length < 2) {
    logError('not enough arguments');
    return 1;
  }
  const dir = path.resolve(args[0]);
  const cmd = args[1], cmdArgs = args.slice(2);
  const rc = findRc(dir);
  let env = {...process.env};
  if (rc) {
    if (!isAllowed(rc)) {
      logError(`${rc} is blocked. Run \`direnv allow\` to approve its content`);
      return 1;
    }
    const d = evalRc(rc);
    if (!d.ok) return d.status;
    env = {...env, ...d.env};
  }
  const res = cp.spawnSync(cmd, cmdArgs, {cwd: dir, env, stdio: 'inherit'});
  if (res.error && res.error.code === 'ENOENT') {
    logError(`command '${cmd}' not found on PATH '${env.PATH || ''}'`);
    return 127;
  }
  return res.status == null ? 1 : res.status;
}

function fetchurl(args) {
  if (args.length < 1) {
    logError('not enough arguments');
    return 1;
  }
  logError('Get "' + args[0] + '": network is unavailable in this environment');
  return 1;
}

function dumpEnv() {
  for (const [k, v] of Object.entries(process.env)) {
    if (k === '_' || k === 'SHLVL') continue;
    process.stdout.write(`export ${k}=${bashDollarQuote(v)};`);
  }
  return 0;
}

function main() {
  const args = process.argv.slice(2);
  const cmd = args.shift() || 'help';
  try {
    switch (cmd) {
      case '--help': case '-h': case 'help': help(); return 0;
      case '--version': case 'version':
        if (!args[0]) { process.stdout.write(VERSION + '\n'); return 0; }
        if (versionAtLeast(args[0])) return 0;
        logError(`current version v${VERSION} is older than the desired version v${args[0].replace(/^v/, '')}`);
        return 1;
      case 'stdlib': process.stdout.write(stdlib()); return 0;
      case 'hook': return hook(args[0]);
      case 'status': return status(args[0] === '--json');
      case 'export': return runExport(args[0] || 'bash');
      case 'allow': case 'permit': case 'grant': allowFile(canonicalRc(args[0])); return 0;
      case 'deny': case 'disallow': case 'revoke': case 'block': denyFile(canonicalRc(args[0])); return 0;
      case 'reload': if (!findRc(process.cwd())) { logError('.envrc not found'); return 1; } return 0;
      case 'prune': writeAllows(readAllows()); return 0;
      case 'exec': return cmdExec(args);
      case 'edit': {
        const rc = canonicalRc(args[0]);
        const ed = process.env.EDITOR || 'vi';
        cp.spawnSync(ed, [rc], {stdio: 'inherit'});
        allowFile(rc);
        return 0;
      }
      case 'log':
        if (args[0] === '--status' || args[0] === '-status') { logStatus(args.slice(1).join(' ')); return 0; }
        if (args[0] === '--error' || args[0] === '-error') { process.stderr.write(color('31', `direnv: ${args.slice(1).join(' ')}`) + '\n'); return 0; }
        logError('invalid arguments'); return 1;
      case 'fetchurl': return fetchurl(args);
      case 'dump': return dumpEnv();
      default: logError(`command "${process.argv.slice(1).join(' ')}" not found`); return 1;
    }
  } catch (e) {
    logError(e.message || String(e));
    return 1;
  }
}

process.exitCode = main();
