#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const HELP = `trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.

Usage
\ttrdsql [OPTIONS] [SQL(SELECT...)]

Options:
  -A string           analyze the file but only suggest SQL.
  -a string           analyze the file and suggest SQL.
  -config string      configuration file location.
  -db string          specify db name of the setting.
  -dblist             display db information.
  -debug              debug print.
  -driver string      database driver.  [ mysql | postgres | sqlite3 | sqlite3_ext ]
  -dsn string         database driver specific data source name.
  -help               display usage information.
  -q string           read query from the specified file.
  -t string           read table name from the specified file.
  -version            display version information.

Input Formats:
  -icsv               CSV format for input.
  -ig                 guess format from extension. (default "true")
  -ijson              JSON format for input.
  -iltsv              LTSV format for input.
  -itbln              TBLN format for input.
  -itext              text format for input.
  -iwidth             width specification format for input.
  -iyaml              YAML format for input.

Input options:
  -id string          field delimiter for input. (default ",")
  -ih                 the first line is interpreted as column names(CSV only).
  -ijq string         jq expression string for input(JSON/JSONL only).
  -ilr int            limited number of rows to read. (default 0)
  -inull value        value(string) to convert to null on input.
  -inum               add row number column.
  -ir int             number of rows to preread. (default 1)
  -is int             skip header row. (default 0)

Output Formats:
  -oat                ASCII Table format for output.
  -ocsv               CSV format for output.
  -ojson              JSON format for output.
  -ojsonl             JSON lines format for output.
  -oltsv              LTSV format for output.
  -omd                Markdown format for output.
  -oraw               Raw format for output.
  -otbln              TBLN format for output.
  -ovf                Vertical format for output.
  -oyaml              YAML format for output.

Output options:
  -oaq                enclose all fields in quotes for output.
  -ocrlf              use CRLF for output. End each output line with '\\r\\n' instead of '\\n'.
  -od string          field delimiter for output. (default ",")
  -oh                 output column name as header.
  -onowrap            do not wrap long lines(at/md only).
  -onull value        value(string) to convert from null on output.
  -oq string          quote character for output. (default "\\"")
  -out string         output file name.
  -out-without-guess  output without guessing (when using -out).
  -oz string          output compression format. [ gz | bz2 | zstd | lz4 | xz ]

Examples:
  $ trdsql "SELECT c1,c2 FROM test.csv"
  $ trdsql -oltsv "SELECT c1,c2 FROM test.json::.items"
  $ cat test.csv | trdsql -icsv -oltsv "SELECT c1,c2 FROM -"`;

function die(msg, code = 1) {
  const d = new Date();
  const stamp = `${d.getUTCFullYear()}/${String(d.getUTCMonth()+1).padStart(2,'0')}/${String(d.getUTCDate()).padStart(2,'0')} ${String(d.getUTCHours()).padStart(2,'0')}:${String(d.getUTCMinutes()).padStart(2,'0')}:${String(d.getUTCSeconds()).padStart(2,'0')}`;
  console.error(`${stamp} ${msg}`);
  process.exit(code);
}

function parseArgs(argv) {
  const opt = { inputDelim: ',', outputDelim: ',', quote: '"', outFmt: 'csv', guess: true, header: false, outHeader: false, skip: 0, limitRead: 0, inNull: undefined, outNull: '', rownum: false };
  let sql = null;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-help' || a === '--help') { console.log(HELP); process.exit(2); }
    else if (a === '-version' || a === '--version') { console.log('trdsql version devel'); process.exit(0); }
    else if (a === '-q') opt.queryFile = argv[++i];
    else if (a === '-t') opt.table = argv[++i];
    else if (a === '-a' || a === '-A') { opt.analyze = argv[++i]; opt.analyzeOnly = a === '-A'; }
    else if (a === '-id') opt.inputDelim = argv[++i] ?? ',';
    else if (a === '-od') opt.outputDelim = argv[++i] ?? ',';
    else if (a === '-oq') opt.quote = argv[++i] ?? '"';
    else if (a === '-out') opt.outFile = argv[++i];
    else if (a === '-is') opt.skip = parseInt(argv[++i] || '0', 10) || 0;
    else if (a === '-ilr') opt.limitRead = parseInt(argv[++i] || '0', 10) || 0;
    else if (a === '-inull') opt.inNull = argv[++i];
    else if (a === '-onull') opt.outNull = argv[++i] ?? '';
    else if (a === '-ijq') opt.jq = argv[++i];
    else if (a === '-config' || a === '-db' || a === '-driver' || a === '-dsn' || a === '-oz' || a === '-ir') i++;
    else if (a === '-ih') opt.header = true;
    else if (a === '-oh') opt.outHeader = true;
    else if (a === '-inum') opt.rownum = true;
    else if (a === '-ig') opt.guess = true;
    else if (a === '-icsv') opt.inFmt = 'csv';
    else if (a === '-iltsv') opt.inFmt = 'ltsv';
    else if (a === '-ijson') opt.inFmt = 'json';
    else if (a === '-iyaml') opt.inFmt = 'yaml';
    else if (a === '-itbln') opt.inFmt = 'tbln';
    else if (a === '-itext' || a === '-iwidth') opt.inFmt = 'text';
    else if (a === '-ocsv') opt.outFmt = 'csv';
    else if (a === '-ojson') opt.outFmt = 'json';
    else if (a === '-ojsonl') opt.outFmt = 'jsonl';
    else if (a === '-oltsv') opt.outFmt = 'ltsv';
    else if (a === '-omd') opt.outFmt = 'md';
    else if (a === '-oat') opt.outFmt = 'at';
    else if (a === '-oraw') opt.outFmt = 'raw';
    else if (a === '-otbln') opt.outFmt = 'tbln';
    else if (a === '-ovf') opt.outFmt = 'vf';
    else if (a === '-oyaml') opt.outFmt = 'yaml';
    else if (a === '-oaq') opt.quoteAll = true;
    else if (a === '-ocrlf') opt.crlf = true;
    else if (a === '-onowrap' || a === '-debug' || a === '-dblist' || a === '-out-without-guess') {}
    else if (a.startsWith('-o') && a.length > 2) opt.outFmt = a.slice(2);
    else if (a.startsWith('-')) {}
    else sql = sql ? `${sql} ${a}` : a;
  }
  if (opt.queryFile) sql = fs.readFileSync(opt.queryFile, 'utf8').trim();
  return { opt, sql };
}

function splitCSV(line, delim = ',') {
  const out = []; let cur = '', q = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (q && line[i+1] === '"') { cur += '"'; i++; } else q = !q;
    } else if (ch === delim && !q) { out.push(cur); cur = ''; }
    else cur += ch;
  }
  out.push(cur);
  return out;
}

function csvEscape(v, opt) {
  if (v == null) v = opt.outNull ?? '';
  v = String(v);
  const q = opt.quote || '"', d = opt.outputDelim || ',';
  if (opt.quoteAll || v.includes(d) || v.includes('\n') || v.includes('\r') || v.includes(q)) {
    return q + v.split(q).join(q + q) + q;
  }
  return v;
}

function readInput(name, opt) {
  let srcName = name;
  if (!srcName) die('export: no query specified');
  if (srcName.includes('::')) srcName = srcName.split('::')[0];
  let text;
  if (srcName === '-') text = fs.readFileSync(0, 'utf8');
  else {
    if (!fs.existsSync(srcName)) die(`export: no such table: ${srcName} [${opt.currentSql || ''}]`);
    text = fs.readFileSync(srcName, 'utf8');
  }
  let fmt = opt.inFmt || guessFmt(srcName, text);
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  while (lines.length && lines[lines.length - 1] === '') lines.pop();
  for (let i = 0; i < opt.skip; i++) lines.shift();
  let cols = [], rows = [];
  if (fmt === 'ltsv') {
    const seen = [];
    rows = lines.map(line => {
      const r = {};
      for (const part of line.split('\t')) {
        const p = part.indexOf(':');
        if (p >= 0) { const k = part.slice(0,p); r[k] = val(part.slice(p+1), opt); if (!seen.includes(k)) seen.push(k); }
      }
      return r;
    });
    cols = seen;
  } else if (fmt === 'json') {
    let data;
    try { data = JSON.parse(text); } catch {
      data = lines.filter(Boolean).map(l => JSON.parse(l));
    }
    if (opt.jq && opt.jq.startsWith('.')) {
      for (const p of opt.jq.slice(1).split('.').filter(Boolean)) data = data ? data[p] : data;
    }
    if (!Array.isArray(data)) data = data && typeof data === 'object' ? [data] : [];
    const seen = [];
    rows = data.map(item => {
      const r = {};
      if (item && typeof item === 'object' && !Array.isArray(item)) {
        for (const [k,v] of Object.entries(item)) { r[k] = scalar(v); if (!seen.includes(k)) seen.push(k); }
      } else { r.c1 = scalar(item); if (!seen.includes('c1')) seen.push('c1'); }
      return r;
    });
    cols = seen;
  } else if (fmt === 'yaml') {
    ({ cols, rows } = parseSimpleYaml(text, opt));
  } else if (fmt === 'tbln') {
    ({ cols, rows } = parseTbln(lines, opt));
  } else {
    const parsed = lines.map(l => splitCSV(l, opt.inputDelim));
    if (parsed.length === 0) return { cols: [], rows: [], table: srcName };
    if (opt.header) { cols = parsed.shift().map(c => c || ''); }
    else cols = parsed[0].map((_, i) => `c${i+1}`);
    rows = parsed.map(a => Object.fromEntries(cols.map((c,i) => [c, val(a[i] ?? '', opt)])));
  }
  if (opt.limitRead > 0) rows = rows.slice(0, opt.limitRead);
  if (opt.rownum) {
    cols = ['rownum', ...cols];
    rows = rows.map((r, i) => Object.assign({ rownum: String(i+1) }, r));
  }
  return { cols, rows, table: srcName, fmt };
}

function val(s, opt) { return opt.inNull !== undefined && s === opt.inNull ? null : s; }
function scalar(v) { return v == null ? null : (typeof v === 'object' ? JSON.stringify(v) : String(v)); }
function guessFmt(name, text) {
  const low = String(name).toLowerCase();
  if (low.endsWith('.ltsv')) return 'ltsv';
  if (low.endsWith('.json') || low.endsWith('.jsonl')) return 'json';
  if (low.endsWith('.yaml') || low.endsWith('.yml')) return 'yaml';
  if (low.endsWith('.tbln')) return 'tbln';
  if (/^[^\n]*\t[^:\n]+:/.test(text)) return 'ltsv';
  if (/^\s*[\[{]/.test(text)) return 'json';
  return 'csv';
}

function parseSimpleYaml(text, opt) {
  const rows = []; let cur = null; const seen = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trimEnd();
    if (!line.trim()) continue;
    let m = line.match(/^\s*-\s*([^:]+):\s*(.*)$/);
    if (m) { cur = {}; rows.push(cur); cur[m[1].trim()] = val(unquote(m[2].trim()), opt); if (!seen.includes(m[1].trim())) seen.push(m[1].trim()); continue; }
    m = line.match(/^\s*([^:]+):\s*(.*)$/);
    if (m) { if (!cur) { cur = {}; rows.push(cur); } const k = m[1].trim(); cur[k] = val(unquote(m[2].trim()), opt); if (!seen.includes(k)) seen.push(k); }
  }
  return { cols: seen, rows };
}

function parseTbln(lines, opt) {
  let cols = [];
  const rows = [];
  for (const l of lines) {
    if (l.startsWith(';')) {
      if (l.includes('name:')) cols = l.split('|').slice(1, -1).map(s => s.trim()).filter(Boolean);
    } else if (l.trim().startsWith('|')) {
      const a = l.split('|').slice(1, -1).map(s => s.trim());
      if (!cols.length) cols = a.map((_,i)=>`c${i+1}`); else rows.push(Object.fromEntries(cols.map((c,i)=>[c,val(a[i]??'',opt)])));
    }
  }
  return { cols, rows };
}
function unquote(s) { return s.replace(/^['"]|['"]$/g, ''); }

function parseSQL(sql, opt) {
  const cleaned = sql.trim().replace(/;$/, '');
  let m = cleaned.match(/^select\s+([\s\S]+?)\s+from\s+("[^"]+"|'[^']+'|`[^`]+`|\S+)([\s\S]*)$/i);
  if (!m) die(`export: near "${cleaned.split(/\s+/)[0] || ''}": syntax error [${sql}]`);
  const spec = { select: splitSelect(m[1]), table: unquote(m[2]), where: null, order: null, desc: false, limit: null, group: null };
  let rest = m[3] || '';
  const lim = rest.match(/\s+limit\s+(\d+)/i); if (lim) { spec.limit = parseInt(lim[1],10); rest = rest.replace(lim[0], ''); }
  const ord = rest.match(/\s+order\s+by\s+(.+?)(?:\s+(asc|desc))?\s*$/i); if (ord) { spec.order = cleanIdent(ord[1].trim()); spec.desc = (ord[2] || '').toLowerCase() === 'desc'; rest = rest.slice(0, ord.index); }
  const grp = rest.match(/\s+group\s+by\s+(.+?)\s*$/i); if (grp) { spec.group = cleanIdent(grp[1].trim()); rest = rest.slice(0, grp.index); }
  const wh = rest.match(/\s+where\s+([\s\S]+)$/i); if (wh) spec.where = wh[1].trim();
  opt.currentSql = sql;
  return spec;
}

function splitSelect(s) {
  const parts = []; let cur = '', depth = 0, q = null;
  for (let i=0;i<s.length;i++) {
    const ch=s[i];
    if (q) { cur += ch; if (ch === q) q = null; }
    else if (ch === "'" || ch === '"' || ch === '`') { q = ch; cur += ch; }
    else if (ch === '(') { depth++; cur += ch; }
    else if (ch === ')') { depth--; cur += ch; }
    else if (ch === ',' && depth === 0) { parts.push(cur.trim()); cur=''; }
    else cur += ch;
  }
  if (cur.trim()) parts.push(cur.trim());
  return parts;
}

function cleanIdent(s) { return unquote(s.trim()).replace(/^\w+\./, ''); }

function applyQuery(data, spec) {
  let rows = data.rows.slice();
  if (spec.where) rows = rows.filter(r => evalWhere(spec.where, r));
  const agg = spec.select.some(isAgg);
  let cols, outRows;
  if (spec.group) {
    const groups = new Map();
    for (const r of rows) { const k = r[spec.group] ?? ''; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(r); }
    outRows = [];
    for (const rs of groups.values()) outRows.push(projectAgg(rs, spec.select));
    cols = Object.keys(outRows[0] || projectAgg([], spec.select));
  } else if (agg) {
    outRows = [projectAgg(rows, spec.select)];
    cols = Object.keys(outRows[0]);
  } else {
    const sel = spec.select.length === 1 && spec.select[0] === '*' ? data.cols : spec.select.map(s => parseExpr(s).name);
    cols = spec.select.length === 1 && spec.select[0] === '*' ? data.cols : spec.select.map(s => parseExpr(s).alias || parseExpr(s).name);
    outRows = rows.map(r => {
      const o = {};
      if (spec.select.length === 1 && spec.select[0] === '*') for (const c of data.cols) o[c] = r[c];
      else spec.select.forEach((s, i) => { const e = parseExpr(s); o[cols[i]] = valueOfExpr(e.name, r); });
      return o;
    });
  }
  if (spec.order) outRows.sort((a,b) => cmp(a[spec.order] ?? a[Object.keys(a).find(k => k.toLowerCase() === spec.order.toLowerCase())], b[spec.order] ?? b[Object.keys(b).find(k => k.toLowerCase() === spec.order.toLowerCase())]) * (spec.desc ? -1 : 1));
  if (spec.limit != null) outRows = outRows.slice(0, spec.limit);
  return { cols, rows: outRows };
}

function parseExpr(s) {
  const m = s.match(/^(.+?)\s+(?:as\s+)?([A-Za-z_][\w]*)$/i);
  if (m && !/\)$/.test(m[1].trim())) return { name: cleanIdent(m[1]), alias: m[2] };
  const mm = s.match(/^(.+?)\s+as\s+(.+)$/i);
  if (mm) return { name: cleanIdent(mm[1]), alias: cleanIdent(mm[2]) };
  return { name: cleanIdent(s), alias: null };
}
function valueOfExpr(name, r) {
  if (/^'.*'$|^".*"$/.test(name)) return name.slice(1,-1);
  return r[name] ?? r[Object.keys(r).find(k => k.toLowerCase() === name.toLowerCase())] ?? '';
}
function isAgg(s) { return /^(count|sum|avg|min|max)\s*\(/i.test(s.trim()); }
function projectAgg(rows, sels) {
  const o = {};
  for (const s of sels) {
    if (isAgg(s)) {
      const m = s.match(/^(\w+)\s*\(\s*([^)]+)\s*\)(?:\s+as\s+(\w+))?/i);
      const fn = m[1].toLowerCase(), col = cleanIdent(m[2]), alias = m[3] || `${fn}(${col})`;
      const vals = col === '*' ? rows : rows.map(r => r[col]).filter(v => v != null && v !== '');
      if (fn === 'count') o[alias] = String(vals.length);
      else {
        const nums = vals.map(Number).filter(n => !Number.isNaN(n));
        if (fn === 'sum') o[alias] = String(nums.reduce((a,b)=>a+b,0));
        if (fn === 'avg') o[alias] = String(nums.reduce((a,b)=>a+b,0) / (nums.length || 1));
        if (fn === 'min') o[alias] = String(vals.slice().sort(cmp)[0] ?? '');
        if (fn === 'max') o[alias] = String(vals.slice().sort(cmp).slice(-1)[0] ?? '');
      }
    } else {
      const e = parseExpr(s); o[e.alias || e.name] = rows[0] ? valueOfExpr(e.name, rows[0]) : '';
    }
  }
  return o;
}
function cmp(a,b) { a = a == null ? '' : String(a); b = b == null ? '' : String(b); return a < b ? -1 : a > b ? 1 : 0; }

function evalWhere(expr, r) {
  const parts = expr.split(/\s+and\s+/i);
  return parts.every(p => {
    const m = p.match(/^(.+?)\s+(like|is\s+not|is|>=|<=|<>|!=|=|>|<)\s+(.+)$/i);
    if (!m) return true;
    const left = valueOfExpr(cleanIdent(m[1]), r);
    const op = m[2].toLowerCase();
    let right = unquote(m[3].trim());
    if (/^null$/i.test(right)) right = null;
    if (op === '=') return String(left) === String(right);
    if (op === '!=' || op === '<>') return String(left) !== String(right);
    if (op === '>') return String(left) > String(right);
    if (op === '<') return String(left) < String(right);
    if (op === '>=') return String(left) >= String(right);
    if (op === '<=') return String(left) <= String(right);
    if (op === 'is') return (left == null || left === '') === (right == null);
    if (op === 'is not') return (left == null || left === '') !== (right == null);
    if (op === 'like') return new RegExp('^' + String(right).replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/%/g, '.*').replace(/_/g, '.') + '$').test(String(left));
    return true;
  });
}

function format(data, opt) {
  const eol = opt.crlf ? '\r\n' : '\n';
  let lines = [];
  const vals = r => data.cols.map(c => r[c]);
  if (opt.outFmt === 'json') return JSON.stringify(data.rows, null, 2) + eol;
  if (opt.outFmt === 'jsonl') return data.rows.map(r => JSON.stringify(r)).join(eol) + (data.rows.length ? eol : '');
  if (opt.outFmt === 'ltsv') return data.rows.map(r => data.cols.map(c => `${c}:${r[c] ?? opt.outNull ?? ''}`).join('\t')).join(eol) + (data.rows.length ? eol : '');
  if (opt.outFmt === 'yaml') return data.rows.map(r => data.cols.map((c,i) => `${i===0?'- ':'  '}${c}: ${r[c] ?? opt.outNull ?? ''}`).join(eol)).join(eol) + (data.rows.length ? eol : '');
  if (opt.outFmt === 'tbln') {
    lines.push(`; name: | ${data.cols.join(' | ')} |`);
    lines.push(`; type: | ${data.cols.map(()=> 'text').join(' | ')} |`);
    for (const r of data.rows) lines.push(`| ${vals(r).map(v => v ?? '').join(' | ')} |`);
    return lines.join(eol) + eol;
  }
  if (opt.outFmt === 'at' || opt.outFmt === 'md') return table(data, opt.outFmt === 'at', eol);
  if (opt.outFmt === 'vf') {
    const width = Math.max(1, ...data.cols.map(c => c.length));
    data.rows.forEach((r,i) => {
      lines.push(`---[ ${i+1}]------------------------`);
      data.cols.forEach(c => lines.push(`${c.padStart(width)} | ${r[c] ?? ''}`));
    });
    return lines.join(eol) + (lines.length ? eol : '');
  }
  if (opt.outHeader) lines.push(data.cols.map(c => csvEscape(c, opt)).join(opt.outputDelim));
  for (const r of data.rows) lines.push(vals(r).map(v => csvEscape(v, opt)).join(opt.outputDelim));
  return lines.join(eol) + (lines.length ? eol : '');
}

function table(data, ascii, eol) {
  const rows = [Object.fromEntries(data.cols.map(c => [c,c])), ...data.rows];
  const widths = data.cols.map(c => Math.max(c.length, ...rows.slice(1).map(r => String(r[c] ?? '').length)));
  const isNum = data.cols.map(c => data.rows.every(r => /^-?\d+(\.\d+)?$/.test(String(r[c] ?? ''))));
  const center = (s,w) => {
    s = String(s ?? '');
    const total = w - s.length + 2;
    const left = Math.floor(total / 2);
    const right = total - left;
    return ' '.repeat(left) + s + ' '.repeat(right);
  };
  const cell = (s,w,num) => {
    s = String(s ?? '');
    const pad = w - s.length;
    return num ? ' '.repeat(pad+1)+s+' ' : ' '+s+' '.repeat(pad+1);
  };
  const sep = ascii ? '+' + widths.map(w => '-'.repeat(w+2)).join('+') + '+' : '|' + widths.map(w => '-'.repeat(w+2)).join('|') + '|';
  const line = r => '|' + data.cols.map((c,i) => cell(r[c], widths[i], r[c] !== c && isNum[i])).join('|') + '|';
  const header = '|' + data.cols.map((c,i) => center(c, widths[i])).join('|') + '|';
  const out = [];
  if (ascii) out.push(sep);
  out.push(header);
  out.push(sep);
  for (const r of data.rows) out.push(line(r));
  if (ascii) out.push(sep);
  return out.join(eol) + eol;
}

function analyze(file, opt) {
  const data = readInput(file, opt);
  const cols = data.cols;
  let out = `The table name is ${file}.\nThe file type is ${String(data.fmt || '').toUpperCase()}.\n\n`;
  if (!opt.analyzeOnly) {
    out += 'Data types:\n' + table({ cols: ['column name','type'], rows: cols.map(c => ({'column name': c, type: 'text'})) }, true, '\n') + '\n';
    out += 'Data samples:\n' + table({ cols, rows: data.rows.slice(0,1) }, true, '\n') + '\n';
  }
  out += `Examples:\n./executable "SELECT ${cols.join(', ')} FROM ${file}"\n`;
  if (cols[0]) out += `./executable "SELECT ${cols.join(', ')} FROM ${file} WHERE ${cols[0]} = '${data.rows[0]?.[cols[0]] ?? ''}'"\n./executable "SELECT ${cols[0]}, count(${cols[0]}) FROM ${file} GROUP BY ${cols[0]}"\n./executable "SELECT ${cols.join(', ')} FROM ${file} ORDER BY ${cols[0]} LIMIT 10"\n`;
  return out;
}

function main() {
  const { opt, sql } = parseArgs(process.argv.slice(2));
  if (opt.analyze) { process.stdout.write(analyze(opt.analyze, opt)); return; }
  if (!sql && !opt.table) { console.log(HELP); process.exit(2); }
  let query = sql;
  if (!query && opt.table) query = `SELECT * FROM ${opt.table}`;
  const spec = parseSQL(query, opt);
  const data = readInput(spec.table, opt);
  const result = applyQuery(data, spec);
  const output = format(result, opt);
  if (opt.outFile) fs.writeFileSync(opt.outFile, output); else process.stdout.write(output);
}

try { main(); } catch (e) { die(`export: ${e.message}`); }
