#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = 'treemd 0.5.7';

function fullHelp() {
  return `treemd - A modern markdown viewer combining tree-based navigation with interactive TUI.

Launch without flags for interactive mode with dual-pane interface, vim-style navigation,
syntax highlighting, and real-time search. Use flags for CLI mode to extract, filter,
and analyze markdown structure.

Examples:
  treemd README.md              # Interactive TUI mode
  treemd -l README.md           # List all headings
  treemd --tree README.md       # Show heading tree
  treemd -s Installation doc.md # Extract section
  treemd --setup-completions    # Set up shell completions

Usage: executable [OPTIONS] [FILE]... [COMMAND]

Commands:
  at-line  Show heading at specific line number
  help     Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]...  Markdown file(s) to view (.md or .markdown), directory, or '-' for stdin

Options:
  -l, --list                   List all headings in the document (non-interactive)
      --tree                   Show heading tree structure with box-drawing characters (non-interactive)
      --filter <PATTERN>       Filter headings by text pattern (case-insensitive)
  -L, --level <LEVEL>          Show only headings at specific level (1-6)
  -o, --output <OUTPUT>        Output format for --list and --tree modes [default: plain] [possible values: plain, json, tree]
  -s, --section <HEADING>      Extract specific section by heading name
      --count                  Count headings by level (shows statistics)
      --setup-completions      Set up shell completions interactively
      --theme <THEME>          Set theme for TUI mode
      --color-mode <MODE>      Force color mode (auto, rgb, 256) [possible values: auto, rgb, 256]
      --no-images              Disable image rendering in TUI mode
      --images                 Enable image rendering in TUI mode (override config)
  -q, --query <EXPR>           Query expression for selecting/filtering document elements
      --query-help             Show query language documentation and examples
      --query-output <FORMAT>  Output format for query results
  -h, --help                   Print help (see more with '--help')
  -V, --version                Print version`;
}

function shortHelp() {
  return `A markdown navigator with tree-based structural navigation

Usage: executable [OPTIONS] [FILE]... [COMMAND]

Commands:
  at-line  Show heading at specific line number
  help     Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]...  Markdown file(s) to view (.md or .markdown), directory, or '-' for stdin

Options:
  -l, --list                   List all headings in the document (non-interactive)
      --tree                   Show heading tree structure with box-drawing characters (non-interactive)
      --filter <PATTERN>       Filter headings by text pattern (case-insensitive)
  -L, --level <LEVEL>          Show only headings at specific level (1-6)
  -o, --output <OUTPUT>        Output format for --list and --tree modes [default: plain] [possible values: plain, json, tree]
  -s, --section <HEADING>      Extract specific section by heading name
      --count                  Count headings by level (shows statistics)
      --setup-completions      Set up shell completions interactively
      --theme <THEME>          Set theme for TUI mode
      --color-mode <MODE>      Force color mode (auto, rgb, 256) [possible values: auto, 256, rgb]
      --no-images              Disable image rendering in TUI mode
      --images                 Enable image rendering in TUI mode (override config)
  -q, --query <EXPR>           Query expression for selecting/filtering document elements
      --query-help             Show query language documentation and examples
      --query-output <FORMAT>  Output format for query results
  -h, --help                   Print help (see more with '--help')
  -V, --version                Print version`;
}

function queryHelp() {
  return `treemd Query Language (tql)

A jq-like query language for navigating and extracting markdown structure.

ELEMENT SELECTORS
    .h, .heading    All headings (any level)
    .h1 - .h6       Headings by level
    .code           All code blocks
    .code[rust]     Code blocks by language
    .link, .a       All links
    .link[external] External links only
    .img            All images
    .table          All tables
    .list           All lists
    .blockquote     All blockquotes

FILTERS & INDEXING
    .h2[Features]       Heading containing "Features" (fuzzy)
    .h2["Installation"] Heading with exact text
    .h2[0]              First h2
    .h2[-1]             Last h2
    .h2[1:3]            h2s at index 1 and 2
    .h2[:3]             First 3 h2s

HIERARCHY
    .h1 > .h2           Direct child h2s under h1s
    .h1 >> .code        Code blocks anywhere under h1s

PIPES
    .h2 | text          Get heading text (strips ##)
    [.h2] | count       Count all h2s
    .code | lang        Get code block languages
    .link | url         Get link URLs

COLLECTION FUNCTIONS
    count, length       Count elements (alias: len, size)
    first, last         First/last element (alias: head)
    limit(n), take(n)   First n elements
    skip(n), drop(n)    Skip first n elements
    nth(n)              Get element at index
    reverse             Reverse order
    sort                Sort alphabetically
    unique              Remove duplicates
    flatten             Flatten nested arrays
    group_by(key)       Group elements by key
    min, max            Min/max numeric value
    add                 Sum numbers or concat strings

STRING FUNCTIONS
    text                Get text representation
    upper, lower        Case conversion
    trim                Strip whitespace
    split(sep)          Split by separator
    join(sep)           Join with separator
    replace(a, b)       Replace substring
    slugify             URL-friendly slug
    lines, words, chars Count lines/words/chars

FILTER FUNCTIONS
    select(cond)        Keep if condition true (alias: where, filter)
    contains(s)         Contains substring (alias: includes)
    startswith(s)       Starts with prefix
    endswith(s)         Ends with suffix
    matches(regex)      Matches regex pattern
    any, all            Check if any/all truthy
    not                 Negate boolean

CONTENT FUNCTIONS
    content             Section content (for headings)
    md                  Raw markdown
    url, href, src      Get URL/link/image source
    lang                Code block language

AGGREGATION FUNCTIONS
    stats               Document statistics
    levels              Heading count by level
    langs               Code block count by language
    types               Link types count`;
}

function parseArgs(argv) {
  const opts = { files: [], output: 'plain', queryOutput: 'plain' };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === 'at-line') { opts.command = 'at-line'; opts.line = Number(argv[++i]); continue; }
    if (a === 'help') { opts.help = true; continue; }
    if (a === '-h') { opts.shortHelp = true; continue; }
    if (a === '--help') { opts.fullHelp = true; continue; }
    if (a === '-V' || a === '--version') { opts.version = true; continue; }
    if (a === '-l' || a === '--list') { opts.list = true; continue; }
    if (a === '--tree') { opts.tree = true; continue; }
    if (a === '--count') { opts.count = true; continue; }
    if (a === '--query-help') { opts.queryHelp = true; continue; }
    if (a === '--setup-completions') { opts.setupCompletions = true; continue; }
    if (a === '--no-images' || a === '--images') continue;
    if (a === '--filter') { opts.filter = argv[++i] || ''; continue; }
    if (a === '-L' || a === '--level') { opts.level = Number(argv[++i]); continue; }
    if (a === '-o' || a === '--output') { opts.output = argv[++i] || 'plain'; continue; }
    if (a === '-s' || a === '--section') { opts.section = argv[++i] || ''; continue; }
    if (a === '-q' || a === '--query') { opts.query = argv[++i] || ''; continue; }
    if (a === '--query-output') { opts.queryOutput = argv[++i] || 'plain'; continue; }
    if (a === '--theme' || a === '--color-mode') { i++; continue; }
    if (a.startsWith('-') && a !== '-') { opts.unknown = a; continue; }
    opts.files.push(a);
  }
  return opts;
}

function readInput(files) {
  if (files.includes('-')) return fs.readFileSync(0, 'utf8');
  const md = files.filter(f => /\.(md|markdown)$/i.test(f) && fs.existsSync(f) && fs.statSync(f).isFile());
  if (md.length) return md.map(f => fs.readFileSync(f, 'utf8')).join('\n');
  if (!files.length && !process.stdin.isTTY) return '# Select a file\n';
  return '';
}

function slugify(s) {
  return String(s).toLowerCase().trim().replace(/[`*_~]/g, '').replace(/[^\w\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
}

function headingText(line) {
  const m = /^(#{1,6})[ \t]+(.+?)[ \t]*#*[ \t]*$/.exec(line);
  if (!m) return null;
  return { level: m[1].length, text: m[2].trim() };
}

function parseMarkdown(text) {
  const lines = text.replace(/\r\n/g, '\n').split('\n');
  const offsets = [];
  let off = 0;
  for (const l of lines) { offsets.push(off); off += Buffer.byteLength(l + '\n'); }
  const headings = [];
  let inFence = false;
  for (let i = 0; i < lines.length; i++) {
    if (/^```/.test(lines[i].trim())) { inFence = !inFence; continue; }
    if (inFence) continue;
    const h = headingText(lines[i]);
    if (h) headings.push({ type: 'heading', level: h.level, text: h.text, title: h.text, line: i + 1, contentLine: i + 2, offset: offsets[i] + Buffer.byteLength(lines[i] + '\n'), slug: slugify(h.text), children: [] });
  }
  for (let i = 0; i < headings.length; i++) {
    const h = headings[i];
    let ownEnd = lines.length, sectionEnd = lines.length;
    if (i + 1 < headings.length) ownEnd = headings[i + 1].line - 1;
    for (let j = i + 1; j < headings.length; j++) if (headings[j].level <= h.level) { sectionEnd = headings[j].line - 1; break; }
    h.endLine = sectionEnd;
    h.raw = lines.slice(h.line, ownEnd).join('\n').replace(/^\n+|\n+$/g, '');
    h.markdown = lines.slice(h.line - 1, sectionEnd).join('\n').replace(/\n+$/g, '');
  }
  const roots = [];
  const stack = [];
  for (const h of headings) {
    while (stack.length && stack[stack.length - 1].level >= h.level) stack.pop();
    if (stack.length) stack[stack.length - 1].children.push(h); else roots.push(h);
    stack.push(h);
  }
  const code = [], links = [], images = [], lists = [], blockquotes = [], tables = [];
  for (let i = 0; i < lines.length; i++) {
    const f = /^```([^\s`]*)/.exec(lines[i]);
    if (f) {
      const start = i + 1, lang = f[1] || null, body = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i])) body.push(lines[i++]);
      code.push({ type: 'code', language: lang, lang, content: body.join('\n'), line: start, start_line: start + 1, end_line: i });
      continue;
    }
    const bq = /^>\s?(.*)/.exec(lines[i]);
    if (bq) blockquotes.push({ type: 'blockquote', text: bq[1], content: bq[1], line: i + 1, markdown: lines[i] });
    if (/^\s*\|.*\|\s*$/.test(lines[i])) tables.push({ type: 'table', text: lines[i], content: lines[i], line: i + 1, markdown: lines[i] });
    const li = /^\s*(?:[-*+]|\d+\.)\s+(\[[ xX]\]\s+)?(.*)/.exec(lines[i]);
    if (li) lists.push({ type: 'list', text: li[2], content: li[2], checked: li[1] ? /x/i.test(li[1]) : null, line: i + 1, markdown: lines[i] });
    const re = /(!)?\[([^\]]*)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g;
    let m;
    while ((m = re.exec(lines[i]))) {
      const obj = { type: m[1] ? 'image' : 'link', text: m[2], url: m[3], href: m[3], src: m[3], title: m[4] || null, line: i + 1, markdown: m[0] };
      (m[1] ? images : links).push(obj);
    }
  }
  return { text, lines, headings, roots, code, links, images, lists, blockquotes, tables };
}

function filteredHeadings(doc, opts) {
  let hs = doc.headings.slice();
  if (opts.level) hs = hs.filter(h => h.level === opts.level);
  if (opts.filter) {
    const q = opts.filter.toLowerCase();
    hs = hs.filter(h => h.text.toLowerCase().includes(q));
  }
  return hs;
}

function headingLine(h) { return '#'.repeat(h.level) + ' ' + h.text; }

function printTree(headings) {
  const roots = [];
  const stack = [];
  const clones = new Map();
  for (const h of headings) clones.set(h, { h, children: [] });
  for (const h of headings) {
    while (stack.length && stack[stack.length - 1].h.level >= h.level) stack.pop();
    const node = clones.get(h);
    if (stack.length) stack[stack.length - 1].children.push(node); else roots.push(node);
    stack.push(node);
  }
  const out = [];
  function rec(nodes, prefix) {
    nodes.forEach((n, idx) => {
      const last = idx === nodes.length - 1;
      out.push(prefix + (last ? '└──' : '├──') + headingLine(n.h));
      rec(n.children, prefix + (last ? '   ' : '│  '));
    });
  }
  rec(roots, '');
  return out.join('\n') + (out.length ? '\n' : '');
}

function wordCount(text) {
  const m = text.match(/\b[\w'-]+\b/g);
  return m ? m.length : 0;
}

function inlineParts(s) {
  const parts = [], re = /\[([^\]]*)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g;
  let last = 0, m;
  while ((m = re.exec(s))) {
    if (m.index > last) parts.push({ type: 'text', value: s.slice(last, m.index) });
    parts.push({ type: 'link', text: m[1], url: m[2], title: m[3] || null });
    last = re.lastIndex;
  }
  if (last < s.length) parts.push({ type: 'text', value: s.slice(last) });
  return parts.length ? parts : [{ type: 'text', value: s }];
}

function blocks(raw, contentStartLine) {
  const ls = raw.split('\n');
  const bs = [];
  for (let i = 0; i < ls.length; i++) {
    if (!ls[i].trim()) continue;
    const f = /^```([^\s`]*)/.exec(ls[i]);
    if (f) {
      const body = [], start = contentStartLine + i;
      i++;
      while (i < ls.length && !/^```/.test(ls[i])) body.push(ls[i++]);
      bs.push({ type: 'code', language: f[1] || null, content: body.join('\n'), start_line: start + 1, end_line: contentStartLine + i - 1 });
      continue;
    }
    const list = [];
    let j = i;
    while (j < ls.length) {
      const li = /^\s*(?:[-*+]|\d+\.)\s+(\[[ xX]\]\s+)?(.*)/.exec(ls[j]);
      if (!li) break;
      list.push({ checked: li[1] ? /x/i.test(li[1]) : null, content: li[2], inline: inlineParts(li[2]) });
      j++;
    }
    if (list.length) { bs.push({ type: 'list', ordered: false, items: list }); i = j - 1; continue; }
    const para = [];
    while (i < ls.length && ls[i].trim() && !/^```/.test(ls[i]) && !/^\s*(?:[-*+]|\d+\.)\s+/.test(ls[i])) para.push(ls[i++]);
    i--;
    const content = para.join('\n');
    bs.push({ type: 'paragraph', content, inline: inlineParts(content) });
  }
  return bs;
}

function sectionJson(h) {
  return { id: h.slug, level: h.level, title: h.text, slug: h.slug, position: { line: h.contentLine, offset: h.offset }, content: { raw: h.raw, blocks: blocks(h.raw, h.contentLine) }, children: h.children.map(sectionJson) };
}

function documentJson(doc) {
  return { document: { metadata: { source: null, headingCount: doc.headings.length, maxDepth: doc.headings.reduce((m, h) => Math.max(m, h.level), 0), wordCount: wordCount(doc.text) }, sections: doc.roots.map(sectionJson) } };
}

function countOutput(doc) {
  const counts = {};
  for (const h of doc.headings) counts[h.level] = (counts[h.level] || 0) + 1;
  const out = ['Heading counts:'];
  for (let i = 1; i <= 6; i++) if (counts[i]) out.push(`  ${'#'.repeat(i)}: ${counts[i]}`);
  out.push('', `Total: ${doc.headings.length}`);
  return out.join('\n') + '\n';
}

function querySelect(doc, sel, base) {
  sel = sel.trim();
  const source = base || null;
  let arr = [];
  let filter = null;
  const m = /^\.([A-Za-z0-9_]+)(?:\[(.*)\])?$/.exec(sel);
  if (!m) {
    if (sel === '.') return [doc];
    return [];
  }
  const name = m[1], key = name.toLowerCase();
  filter = m[2];
  if (key === 'h' || key === 'heading') arr = doc.headings;
  else if (/^h[1-6]$/.test(key)) arr = doc.headings.filter(h => h.level === Number(key[1]));
  else if (key === 'code') arr = doc.code;
  else if (key === 'link' || key === 'a') arr = doc.links;
  else if (key === 'img' || key === 'image') arr = doc.images;
  else if (key === 'list') arr = doc.lists;
  else if (key === 'blockquote') arr = doc.blockquotes;
  else if (key === 'table') arr = doc.tables;
  if (source && source.length) {
    const ranges = source.filter(x => x.type === 'heading').map(h => [h.line, h.endLine]);
    arr = arr.filter(x => ranges.some(([a, b]) => x.line >= a && x.line <= b));
  }
  if (filter !== null && filter !== undefined) arr = applyBracketFilter(arr, filter);
  return arr;
}

function applyBracketFilter(arr, f) {
  f = f.trim();
  if (/^-?\d+$/.test(f)) {
    let idx = Number(f); if (idx < 0) idx = arr.length + idx;
    return arr[idx] ? [arr[idx]] : [];
  }
  const sm = /^(-?\d*)?:(-?\d*)?$/.exec(f);
  if (sm) {
    const s = sm[1] === '' || sm[1] == null ? 0 : Number(sm[1]);
    const e = sm[2] === '' || sm[2] == null ? arr.length : Number(sm[2]);
    return arr.slice(s < 0 ? arr.length + s : s, e < 0 ? arr.length + e : e);
  }
  let term = f.replace(/^["']|["']$/g, '');
  if (term === 'external') return arr.filter(x => /^https?:\/\//i.test(x.url || x.href || ''));
  return arr.filter(x => String(x.text || x.content || '').toLowerCase().includes(term.toLowerCase()));
}

function itemText(x) {
  if (typeof x === 'string' || typeof x === 'number') return String(x);
  if (!x) return '';
  if (x.type === 'heading') return headingLine(x);
  if (x.type === 'code') return '```' + (x.language || '') + '\n' + x.content + '\n```';
  if (x.type === 'link') return `[${x.text}](${x.url})`;
  if (x.type === 'image') return `![${x.text}](${x.url})`;
  return x.markdown || x.text || x.content || JSON.stringify(x);
}

function rawText(x) {
  if (typeof x === 'string' || typeof x === 'number') return String(x);
  if (!x) return '';
  return x.text || x.content || x.title || '';
}

function objectForJson(x) {
  if (!x || typeof x !== 'object') return x;
  if (x.type === 'heading') return { type: 'heading', level: x.level, text: x.text, line: x.line };
  if (x.type === 'code') return { type: 'code', language: x.language, content: x.content, line: x.line };
  if (x.type === 'link') return { type: 'link', text: x.text, url: x.url, line: x.line };
  if (x.type === 'image') return { type: 'image', alt: x.text, src: x.url, line: x.line };
  return x;
}

function evalQuery(doc, q) {
  let expr = q.trim();
  const hierarchy = expr.match(/^(.+?)\s*(>>|>)\s*(\.\w+(?:\[.*\])?)$/);
  if (hierarchy) {
    const parents = evalQuery(doc, hierarchy[1]);
    return querySelect(doc, hierarchy[3], parents);
  }
  let collection = false;
  const parts = expr.split('|').map(s => s.trim()).filter(Boolean);
  let first = parts.shift() || '.';
  if (/^\[.*\]$/.test(first)) { collection = true; first = first.slice(1, -1).trim(); }
  let value = querySelect(doc, first);
  if (collection) value = value.slice();
  for (const p of parts) value = applyFunction(value, p, doc);
  return value;
}

function applyFunction(value, fn, doc) {
  const name = fn.trim();
  const arg = (re) => { const m = re.exec(name); return m && m[1] ? m[1].replace(/^["']|["']$/g, '') : ''; };
  if (/^(count|length|len|size)$/.test(name)) return Array.isArray(value) ? value.length : String(value).length;
  if (name === 'first' || name === 'head') return Array.isArray(value) ? value.slice(0, 1) : value;
  if (name === 'last') return Array.isArray(value) ? value.slice(-1) : value;
  if (/^(limit|take)\(/.test(name)) return value.slice(0, Number(arg(/^[^(]+\(([-\d]+)/)));
  if (/^(skip|drop)\(/.test(name)) return value.slice(Number(arg(/^[^(]+\(([-\d]+)/)));
  if (/^nth\(/.test(name)) { const n = Number(arg(/^nth\(([-\d]+)/)); return value[n] ? [value[n]] : []; }
  if (name === 'reverse') return value.slice().reverse();
  if (name === 'sort') return value.slice().sort((a, b) => rawText(a).localeCompare(rawText(b)));
  if (name === 'unique') return [...new Map(value.map(x => [itemText(x), x])).values()];
  if (name === 'text') return value.map(rawText);
  if (name === 'content') return value.map(x => x.raw || x.content || '');
  if (name === 'md') return value.map(x => x.markdown || itemText(x));
  if (name === 'url' || name === 'href' || name === 'src') return value.map(x => x.url || x.href || x.src || '');
  if (name === 'lang') return value.map(x => x.language || x.lang || '');
  if (name === 'upper') return value.map(x => rawText(x).toUpperCase());
  if (name === 'lower') return value.map(x => rawText(x).toLowerCase());
  if (name === 'trim') return value.map(x => rawText(x).trim());
  if (name === 'slugify') return value.map(x => slugify(rawText(x)));
  if (name === 'lines') return value.map(x => rawText(x).split('\n').length);
  if (name === 'words') return value.map(x => wordCount(rawText(x)));
  if (name === 'chars') return value.map(x => rawText(x).length);
  if (/^join\(/.test(name)) return [value.map(rawText).join(arg(/^join\((.*)\)$/))];
  if (/^split\(/.test(name)) return value.flatMap(x => rawText(x).split(arg(/^split\((.*)\)$/)));
  if (/^replace\(/.test(name)) {
    const m = /^replace\(["']?([^,"']+)["']?\s*,\s*["']?([^"']*)["']?\)$/.exec(name);
    return value.map(x => rawText(x).split(m ? m[1] : '').join(m ? m[2] : ''));
  }
  if (/^(select|where|filter)\(/.test(name)) {
    const cond = name.replace(/^(select|where|filter)\(/, '').replace(/\)$/, '');
    return value.filter(x => testCond(x, cond));
  }
  if (name === 'stats') return { headings: doc.headings.length, codeBlocks: doc.code.length, links: doc.links.length, images: doc.images.length, wordCount: wordCount(doc.text) };
  if (name === 'levels') { const o = {}; doc.headings.forEach(h => o[h.level] = (o[h.level] || 0) + 1); return o; }
  if (name === 'langs') { const o = {}; doc.code.forEach(c => { const k = c.language || 'none'; o[k] = (o[k] || 0) + 1; }); return o; }
  if (name === 'types') { let internal = 0, external = 0; doc.links.forEach(l => /^https?:\/\//i.test(l.url) ? external++ : internal++); return { internal, external }; }
  return value;
}

function testCond(x, cond) {
  const s = rawText(x);
  let m;
  if ((m = /contains\(["']([^"']+)["']\)/.exec(cond)) || (m = /includes\(["']([^"']+)["']\)/.exec(cond))) return s.includes(m[1]);
  if ((m = /startswith\(["']([^"']+)["']\)/.exec(cond))) return s.startsWith(m[1]);
  if ((m = /endswith\(["']([^"']+)["']\)/.exec(cond))) return s.endsWith(m[1]);
  if ((m = /matches\(["']([^"']+)["']\)/.exec(cond))) { try { return new RegExp(m[1]).test(s); } catch { return false; } }
  return Boolean(s);
}

function outputQuery(result, fmt) {
  if (fmt === 'json-pretty' || fmt === 'jsonp') return JSON.stringify(Array.isArray(result) ? result.map(objectForJson) : result, null, 2) + '\n';
  if (fmt === 'json') return JSON.stringify(Array.isArray(result) ? result.map(objectForJson) : result) + '\n';
  if (fmt === 'jsonl') return (Array.isArray(result) ? result : [result]).map(x => JSON.stringify(objectForJson(x))).join('\n') + '\n';
  if (fmt === 'md') return (Array.isArray(result) ? result : [result]).map(x => x && x.markdown ? x.markdown : itemText(x)).join('\n\n') + '\n';
  if (fmt === 'tree') return printTree((Array.isArray(result) ? result : []).filter(x => x && x.type === 'heading'));
  return (Array.isArray(result) ? result : [result]).map(itemText).join('\n') + '\n';
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.version) return console.log(VERSION);
  if (opts.shortHelp || opts.help) return console.log(shortHelp());
  if (opts.fullHelp) return console.log(fullHelp());
  if (opts.queryHelp) return console.log(queryHelp());
  if (opts.command === 'at-line') {
    const text = readInput(opts.files);
    const doc = parseMarkdown(text);
    const h = doc.headings.filter(x => x.line <= opts.line).pop();
    if (h) process.stdout.write(headingLine(h) + '\n');
    return;
  }
  if (opts.setupCompletions) return console.log('Shell completions are not available in this build.');
  const text = readInput(opts.files);
  const doc = parseMarkdown(text);
  if (opts.query) return process.stdout.write(outputQuery(evalQuery(doc, opts.query), opts.queryOutput));
  if (opts.count) return process.stdout.write(countOutput(doc));
  if (opts.section !== undefined) {
    const target = doc.headings.find(h => h.text.toLowerCase() === opts.section.toLowerCase()) || doc.headings.find(h => h.text.toLowerCase().includes(opts.section.toLowerCase()));
    if (target) process.stdout.write(target.markdown + '\n');
    return;
  }
  if (opts.list || opts.tree) {
    const hs = filteredHeadings(doc, opts);
    if (opts.output === 'json') {
      if (opts.list) console.log(JSON.stringify(documentJson({ ...doc, headings: hs, roots: doc.roots }), null, 2));
      else console.log(JSON.stringify(hs.map(h => ({ level: h.level, text: h.text })), null, 2));
      return;
    }
    if (opts.output === 'tree' || opts.tree) return process.stdout.write(printTree(hs));
    return process.stdout.write(hs.map(headingLine).join('\n') + (hs.length ? '\n' : ''));
  }
  if (!process.stdout.isTTY) return process.stdout.write('# Select a file\n');
  return process.stdout.write('treemd interactive mode is not available in this reimplementation.\n');
}

try { main(); } catch (e) { console.error('Error: ' + e.message); process.exit(1); }
