#!/usr/bin/env node
const fs = require("fs");

const VERSION = "sd 1.0.0";

function fullHelp() {
  return `sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>
          The regexp or string (if using \`-F\`) to search for

  <REPLACE_WITH>
          What to replace each match with. Unless in string mode, you may use captured values like
          $1, $2, etc

  [FILES]...
          The path to file(s). This is optional - sd can also read from STDIN.
          
          Note: sd modifies files in-place by default. See documentation for examples.

Options:
  -p, --preview
          Display changes in a human reviewable format (the specifics of the format are likely to
          change in the future)

  -F, --fixed-strings
          Treat FIND and REPLACE_WITH args as literal strings

  -n, --max-replacements <LIMIT>
          Limit the number of replacements that can occur per file. 0 indicates unlimited
          replacements
          
          [default: 0]

  -f, --flags <FLAGS>
          Regex flags. May be combined (like \`-f mc\`).
          
          c - case-sensitive
          
          e - disable multi-line matching
          
          i - case-insensitive
          
          m - multi-line matching
          
          s - make \`.\` match newlines
          
          w - match full words only

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;
}

function shortHelp() {
  return `sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>          The regexp or string (if using \`-F\`) to search for
  <REPLACE_WITH>  What to replace each match with. Unless in string mode, you may use captured
                  values like $1, $2, etc
  [FILES]...      The path to file(s). This is optional - sd can also read from STDIN

Options:
  -p, --preview                   Display changes in a human reviewable format (the specifics of the
                                  format are likely to change in the future)
  -F, --fixed-strings             Treat FIND and REPLACE_WITH args as literal strings
  -n, --max-replacements <LIMIT>  Limit the number of replacements that can occur per file. 0
                                  indicates unlimited replacements [default: 0]
  -f, --flags <FLAGS>             Regex flags. May be combined (like \`-f mc\`).
  -h, --help                      Print help (see more with '--help')
  -V, --version                   Print version`;
}

function usage(required) {
  if (required === 0) {
    return "Usage: executable <FIND> <REPLACE_WITH> [FILES]...";
  }
  return "Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...";
}

function die(msg, code = 1) {
  process.stderr.write(msg + "\n");
  process.exit(code);
}

function parseArgs(argv) {
  const opts = { preview: false, fixed: false, limit: 0, flags: "", values: [] };
  let endOptions = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (endOptions) {
      opts.values.push(a);
      continue;
    }
    if (a === "--") {
      endOptions = true;
    } else if (a === "-h") {
      console.log(shortHelp());
      process.exit(0);
    } else if (a === "--help") {
      console.log(fullHelp());
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      console.log(VERSION);
      process.exit(0);
    } else if (a === "-p" || a === "--preview") {
      opts.preview = true;
    } else if (a === "-F" || a === "--fixed-strings") {
      opts.fixed = true;
    } else if (a === "-n" || a === "--max-replacements") {
      const val = argv[++i];
      if (val === undefined) die(`error: a value is required for '${a} <LIMIT>' but none was supplied`, 2);
      if (!/^\d+$/.test(val)) {
        die(`error: invalid value '${val}' for '--max-replacements <LIMIT>': invalid digit found in string\n\nFor more information, try '--help'.`, 2);
      }
      opts.limit = Number(val);
    } else if (a.startsWith("--max-replacements=")) {
      const val = a.slice(a.indexOf("=") + 1);
      if (!/^\d+$/.test(val)) {
        die(`error: invalid value '${val}' for '--max-replacements <LIMIT>': invalid digit found in string\n\nFor more information, try '--help'.`, 2);
      }
      opts.limit = Number(val);
    } else if (a === "-f" || a === "--flags") {
      const val = argv[++i];
      if (val === undefined) die(`error: a value is required for '${a} <FLAGS>' but none was supplied`, 2);
      opts.flags += val;
    } else if (a.startsWith("--flags=")) {
      opts.flags += a.slice(a.indexOf("=") + 1);
    } else if (a.startsWith("-")) {
      die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.`, 2);
    } else {
      opts.values.push(a);
    }
  }
  if (opts.values.length < 2) {
    const missing = opts.values.length === 0 ? "  <FIND>\n  <REPLACE_WITH>" : "  <REPLACE_WITH>";
    die(`error: the following required arguments were not provided:\n${missing}\n\n${usage(opts.values.length)}\n\nFor more information, try '--help'.`, 2);
  }
  opts.find = opts.values[0];
  opts.replace = opts.values[1];
  opts.files = opts.values.slice(2);
  return opts;
}

function escapeRegExp(s) {
  return s.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&");
}

function makeRegex(opts) {
  let pat = opts.fixed ? escapeRegExp(opts.find) : opts.find.replace(/\(\?P<([A-Za-z_][A-Za-z0-9_]*)>/g, "(?<$1>");
  if (opts.flags.includes("w")) pat = `\\b(?:${pat})\\b`;
  let flags = "g";
  if (opts.flags.includes("i") && !opts.flags.includes("c")) flags += "i";
  if (!opts.flags.includes("e")) flags += "m";
  if (opts.flags.includes("s")) flags += "s";
  try {
    return new RegExp(pat, flags);
  } catch (e) {
    die(`error: invalid regex ${e.message}`, 1);
  }
}

function expandReplacement(template, match, captures, groups) {
  let out = "";
  for (let i = 0; i < template.length; i++) {
    const ch = template[i];
    if (ch !== "$") {
      out += ch;
      continue;
    }
    const next = template[i + 1];
    if (next === "$") {
      out += "$";
      i++;
    } else if (next === "{") {
      const end = template.indexOf("}", i + 2);
      if (end >= 0) {
        const name = template.slice(i + 2, end);
        out += valueFor(name, match, captures, groups);
        i = end;
      } else {
        out += "$";
      }
    } else if (/[0-9]/.test(next || "")) {
      let j = i + 1;
      while (/[0-9]/.test(template[j] || "")) j++;
      out += valueFor(template.slice(i + 1, j), match, captures, groups);
      i = j - 1;
    } else if (/[A-Za-z_]/.test(next || "")) {
      let j = i + 1;
      while (/[A-Za-z0-9_]/.test(template[j] || "")) j++;
      out += valueFor(template.slice(i + 1, j), match, captures, groups);
      i = j - 1;
    } else {
      out += "$";
    }
  }
  return out;
}

function valueFor(key, match, captures, groups) {
  if (key === "0") return match;
  if (/^\d+$/.test(key)) return captures[Number(key) - 1] ?? "";
  return groups && Object.prototype.hasOwnProperty.call(groups, key) ? (groups[key] ?? "") : "";
}

function transform(input, re, opts) {
  let count = 0;
  return input.replace(re, function (...args) {
    if (opts.limit !== 0 && count >= opts.limit) return args[0];
    count++;
    const match = args[0];
    const hasGroups = typeof args[args.length - 1] === "object";
    const groups = hasGroups ? args[args.length - 1] : undefined;
    const captureEnd = hasGroups ? args.length - 3 : args.length - 2;
    const captures = args.slice(1, captureEnd);
    if (opts.fixed) return opts.replace;
    return expandReplacement(opts.replace, match, captures, groups);
  });
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const re = makeRegex(opts);

  if (opts.files.length === 0) {
    const input = fs.readFileSync(0, "utf8");
    process.stdout.write(transform(input, re, opts));
    return;
  }

  for (const file of opts.files) {
    let input;
    try {
      const st = fs.statSync(file);
      if (st.isDirectory()) die("error: No such device (os error 19)", 1);
      input = fs.readFileSync(file, "utf8");
    } catch (e) {
      if (e && e.code === "ENOENT") die(`error: invalid path: ${file}`, 1);
      die(`error: ${e.message}`, 1);
    }
    const output = transform(input, re, opts);
    if (opts.preview) {
      if (opts.files.length > 1) process.stdout.write(`----- FILE ${file} -----\n`);
      process.stdout.write(output);
    } else {
      fs.writeFileSync(file, output);
    }
  }
}

main();
