#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const args = process.argv.slice(2);

function out(s = "") { process.stdout.write(s.endsWith("\n") ? s : s + "\n"); }
function err(s = "") { process.stderr.write(s.endsWith("\n") ? s : s + "\n"); }
function exitError(message, code = 1) { err(message); process.exit(code); }
function hasHelp(a) { return a.includes("-h") || a.includes("--help"); }
function stripGlobal(a) {
  const r = [];
  for (let i = 0; i < a.length; i++) {
    if (["-c", "--config", "--env"].includes(a[i])) i++;
    else if (a[i] === "--var") i++;
    else if (a[i].startsWith("--config=") || a[i].startsWith("--env=") || a[i].startsWith("--var=")) {}
    else r.push(a[i]);
  }
  return r;
}
function flagValue(a, names, def) {
  for (let i = 0; i < a.length; i++) {
    for (const n of names) {
      if (a[i] === n) return a[i + 1] || "";
      if (a[i].startsWith(n + "=")) return a[i].slice(n.length + 1);
    }
  }
  return def;
}
function flagValues(a, names) {
  const vals = [];
  for (let i = 0; i < a.length; i++) {
    for (const n of names) {
      if (a[i] === n && a[i + 1]) vals.push(a[++i]);
      else if (a[i].startsWith(n + "=")) vals.push(a[i].slice(n.length + 1));
    }
  }
  return vals;
}
function positionals(a) {
  const ps = [];
  const takes = new Set(["-u","--url","--dir","--dir-format","--dev-url","--from","-f","--to","--format","--schema","-s","--config","-c","--env","--var","--baseline","--tx-mode","--exec-order","--lock-timeout","--revisions-schema","--git-base","--git-dir","--qualifier","--plan"]);
  for (let i = 0; i < a.length; i++) {
    const x = a[i];
    if (x === "--") { ps.push(...a.slice(i + 1)); break; }
    if (x.startsWith("-")) {
      if (!x.includes("=") && takes.has(x)) i++;
      continue;
    }
    ps.push(x);
  }
  return ps;
}
function unknownFlag(a, known) {
  for (const x of a) {
    if (!x.startsWith("-")) continue;
    const k = x.includes("=") ? x.split("=")[0] : x;
    if (!known.has(k)) return k;
  }
  return null;
}
function fileURLToPathish(u) {
  if (!u || u === "file://migrations") return "migrations";
  if (u.startsWith("file://")) return decodeURIComponent(u.slice(7)) || ".";
  if (u.startsWith("file:")) return decodeURIComponent(u.slice(5)) || ".";
  return u;
}
const community = `You're running the community build of Atlas, which may differ from the official version.
If this error persists, try installing the official version as a troubleshooting step:

  curl -sSf https://atlasgo.sh | sh

More installation options: https://atlasgo.io/docs#installation`;

const help = {
top: `Manage your database schema as code

Usage:
  atlas [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  help        Help about any command
  license     Display license information
  migrate     Manage versioned migration files
  schema      Work with atlas schemas.
  version     Prints this Atlas CLI version information.

Flags:
  -h, --help   help for atlas

Use "atlas [command] --help" for more information about a command.`,
schema: `The \`atlas schema\` command groups subcommands working with declarative Atlas schemas.

Usage:
  atlas schema [command]

Available Commands:
  apply       Apply an atlas schema to a target database.
  clean       Removes all objects from the connected database.
  diff        Calculate and print the diff between two schemas.
  fmt         Formats Atlas HCL files
  inspect     Inspect a database and print its schema in Atlas DDL syntax.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for schema
      --var <name>=<value>   input variables (default [])

Use "atlas schema [command] --help" for more information about a command.`,
migrate: `'atlas migrate' wraps several sub-commands for migration management.

Usage:
  atlas migrate [command]

Available Commands:
  apply       Applies pending migration files on the connected database.
  diff        Compute the diff between the migration directory and a desired state and create a new migration file.
  hash        Hash (re-)creates an integrity hash file for the migration directory.
  import      Import a migration directory from another migration management tool to the Atlas format.
  lint        Run analysis on the migration directory
  new         Creates a new empty migration file in the migration directory.
  set         Set the current version of the migration history table.
  status      Get information about the current migration status.
  validate    Validates the migration directories checksum and SQL statements.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for migrate
      --var <name>=<value>   input variables (default [])

Use "atlas migrate [command] --help" for more information about a command.`,
completion: `Generate the autocompletion script for atlas for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  atlas completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion

Use "atlas completion [command] --help" for more information about a command.`,
version: `Prints this Atlas CLI version information.

Usage:
  atlas version [flags]

Flags:
  -h, --help   help for version`,
license: `Display license information

Usage:
  atlas license [flags]

Flags:
  -h, --help   help for license`,
schemaFmt: `'atlas schema fmt' formats all ".hcl" files under the given paths using
canonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.
Unless stated otherwise, the fmt command will use the current directory.

After running, the command will print the names of the files it has formatted. If all
files in the directory are formatted, no input will be printed out.

Usage:
  atlas schema fmt [path ...] [flags]

Flags:
  -h, --help   help for fmt

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`,
schemaInspect: `'atlas schema inspect' connects to the given database and inspects its schema.
It then prints to the screen the schema of that database in Atlas DDL syntax. This output can be
saved to a file, commonly by redirecting the output to a file named with a ".hcl" suffix:

  atlas schema inspect -u "mysql://user:pass@localhost:3306/dbname" > schema.hcl

Usage:
  atlas schema inspect [flags]

Examples:
  atlas schema inspect -u "mysql://user:pass@localhost:3306/dbname"
  atlas schema inspect -u "mariadb://user:pass@localhost:3306/" --schema=schemaA,schemaB -s schemaC
  atlas schema inspect --url "postgres://user:pass@host:port/dbname?sslmode=disable"
  atlas schema inspect -u "sqlite://file:ex1.db?_fk=1"

Flags:
  -u, --url string        [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
  -s, --schema strings    set schema names
      --exclude strings   list of glob patterns used to filter resources from applying
      --format string     Go template to use to format the output
  -h, --help              help for inspect

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`,
schemaApply: `'atlas schema apply' plans and executes a database migration to bring a given
database to the state described in the provided Atlas schema. Before running the
migration, Atlas will print the migration plan and prompt the user for approval.

Usage:
  atlas schema apply [flags]

Flags:
  -u, --url string              [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --exclude strings         list of glob patterns used to filter resources from applying
      --include strings         list of glob patterns used to select which resources to keep in inspection
  -s, --schema strings          set schema names
      --dev-url string          [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dry-run                 print SQL without executing it
      --auto-approve            apply changes without prompting for approval
      --format string           Go template to use to format the output
      --tx-mode string          set transaction mode [none, file] (default "file")
      --plan string             URL to a pre-planned migration (e.g., atlas://repo/plans/name)
      --edit                    open the generated SQL in an editor
      --lock-timeout duration   set how long to wait for the database lock (default 10s)
  -h, --help                    help for apply

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`,
schemaClean: `'atlas schema clean' drops all objects in the connected database and leaves it in an empty state.
As a safety feature, 'atlas schema clean' will ask for confirmation before attempting to execute any SQL.

Usage:
  atlas schema clean [flags]

Examples:
  atlas schema clean -u "mysql://user:pass@localhost:3306/dbname"
  atlas schema clean -u "mysql://user:pass@localhost:3306/"

Flags:
  -u, --url string      [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dry-run         print SQL without executing it
      --format string   Go template to use to format the output
      --auto-approve    apply changes without prompting for approval
  -h, --help            help for clean

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`,
schemaDiff: `'atlas schema diff' reads the state of two given schema definitions, 
calculates the difference in their schemas, and prints a plan of
SQL statements to migrate the "from" database to the schema of the "to" database.

Usage:
  atlas schema diff [flags]

Flags:
  -f, --from strings      [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --to strings        [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
  -s, --schema strings    set schema names
      --exclude strings   list of glob patterns used to filter resources from applying
      --include strings   list of glob patterns used to select which resources to keep in inspection
      --format string     Go template to use to format the output
  -h, --help              help for diff

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`,
};

help.migrateNew = `'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.

Usage:
  atlas migrate new [flags] [name]

Examples:
  atlas migrate new my-new-migration

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
      --edit                edit the created migration file(s)
  -h, --help                help for new

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`;
help.migrateHash = `'atlas migrate hash' computes the integrity hash sum of the migration directory and stores it in the atlas.sum file.
This command should be used whenever a manual change in the migration directory was made.

Usage:
  atlas migrate hash [flags]

Examples:
  atlas migrate hash

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for hash

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`;
help.migrateValidate = `'atlas migrate validate' computes the integrity hash sum of the migration directory and compares it to the
atlas.sum file. If there is a mismatch it will be reported. If the --dev-url flag is given, the migration
files are executed on the connected database in order to validate SQL semantics.

Usage:
  atlas migrate validate [flags]

Examples:
  atlas migrate validate
  atlas migrate validate --dir "file:///path/to/migration/directory"
  atlas migrate validate --dir "file:///path/to/migration/directory" --dev-url "docker://mysql/8/dev"
  atlas migrate validate --env dev --dev-url "docker://postgres/15/dev?search_path=public"

Flags:
      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for validate

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`;
help.migrateStatus = `'atlas migrate status' reports information about the current status of a connected database compared to the migration directory.

Usage:
  atlas migrate status [flags]

Examples:
  atlas migrate status --url "mysql://user:pass@localhost:3306/"
  atlas migrate status --url "mysql://user:pass@localhost:3306/" --dir "file:///path/to/migration/directory"

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --format string             Go template to use to format the output
      --dir string                select migration directory using URL format (default "file://migrations")
      --dir-format string         select migration file format (default "atlas")
      --revisions-schema string   name of the schema the revisions table resides in
  -h, --help                      help for status

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`;
help.migrateApply = `'atlas migrate apply' reads the migration state of the connected database and computes what migrations are pending.
It then attempts to apply the pending migration files in the correct order onto the database. 

Usage:
  atlas migrate apply [flags] [amount]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dir string                select migration directory using URL format (default "file://migrations")
      --format string             Go template to use to format the output
      --revisions-schema string   name of the schema the revisions table resides in
      --dry-run                   print SQL without executing it
      --lock-timeout duration     set how long to wait for the database lock (default 10s)
      --baseline string           start the first migration after the given baseline version
      --tx-mode string            set transaction mode [none, file, all] (default "file")
      --exec-order string         set file execution order [linear, linear-skip, non-linear] (default "linear")
      --allow-dirty               allow start working on a non-clean database
  -h, --help                      help for apply

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`;
help.migrateDiff = `The 'atlas migrate diff' command uses the dev-database to calculate the current state of the migration directory
by executing its files. It then compares its state to the desired state and create a new migration file containing
SQL statements for moving from the current to the desired state. The desired state can be another another database,
an HCL, SQL, or ORM schema. See: https://atlasgo.io/versioned/diff

Usage:
  atlas migrate diff [flags] [name]

Flags:
      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dev-url string          [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string              select migration directory using URL format (default "file://migrations")
      --dir-format string       select migration file format (default "atlas")
  -s, --schema strings          set schema names
      --lock-timeout duration   set how long to wait for the database lock (default 10s)
      --format string           Go template to use to format the output
      --qualifier string        qualify tables with custom qualifier when working on a single schema
      --edit                    edit the generated migration file(s)
  -h, --help                    help for diff

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`;
help.migrateImport = `Import a migration directory from another migration management tool to the Atlas format.

Usage:
  atlas migrate import [flags]

Examples:
  atlas migrate import --from "file:///path/to/source/directory?format=liquibase" --to "file:///path/to/migration/directory"

Flags:
      --from string         select migration directory using URL format (default "file://migrations")
      --to string           select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for import

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`;
help.migrateLint = `Run analysis on the migration directory

Usage:
  atlas migrate lint [flags]

Flags:
      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
      --format string       Go template to use to format the output
      --latest uint         run analysis on the latest N migration files
      --git-base string     run analysis against the base Git branch
      --git-dir string      path to the repository working directory (default ".")
  -h, --help                help for lint

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`;
help.migrateSet = `'atlas migrate set' edits the revision table to consider all migrations up to and including the given version
to be applied. This command is usually used after manually making changes to the managed database.

Usage:
  atlas migrate set [flags] [version]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dir string                select migration directory using URL format (default "file://migrations")
      --dir-format string         select migration file format (default "atlas")
      --revisions-schema string   name of the schema the revisions table resides in
  -h, --help                      help for set

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`;

function formatHCL(src) {
  let s = src.replace(/\r\n/g, "\n");
  s = s.replace(/^(\s*)([A-Za-z_][\w-]*(?:\s+"[^"]+")?)\s+\{/gm, "$1$2 {");
  s = s.replace(/=\s+/g, "= ");
  s = s.replace(/[ \t]+$/gm, "");
  const lines = s.split("\n");
  let level = 0, outLines = [];
  for (let raw of lines) {
    let t = raw.trim();
    if (!t) { if (outLines[outLines.length - 1] !== "") outLines.push(""); continue; }
    t = t.replace(/^([A-Za-z_][\w-]*)\s+"([^"]+)"\s+\{$/, '$1 "$2" {');
    t = t.replace(/^([A-Za-z_][\w-]*)\s+\{$/, '$1 {');
    t = t.replace(/^([A-Za-z_][\w-]*)\s*=\s*(.+)$/, '$1 = $2');
    if (t.startsWith("}")) level = Math.max(0, level - 1);
    outLines.push("  ".repeat(level) + t);
    if (t.endsWith("{")) level++;
  }
  return outLines.join("\n").replace(/\n*$/, "\n");
}
function listHCL(p) {
  const st = fs.statSync(p);
  if (st.isDirectory()) {
    let res = [];
    for (const ent of fs.readdirSync(p)) res = res.concat(listHCL(path.join(p, ent)));
    return res;
  }
  return p.endsWith(".hcl") ? [p] : [];
}
function schemaFmt(a) {
  const bad = unknownFlag(a, new Set(["-h","--help","-c","--config","--env","--var"]));
  if (bad) exitError(`Error: unknown flag: ${bad}`);
  const ps = positionals(stripGlobal(a));
  const targets = ps.length ? ps : ["."];
  for (const t of targets) {
    for (const f of listHCL(t)) {
      const old = fs.readFileSync(f, "utf8");
      const nw = formatHCL(old);
      if (nw !== old) {
        fs.writeFileSync(f, nw);
        out(f);
      }
    }
  }
}
function migrationFiles(dir) {
  if (!fs.existsSync(dir)) throw new Error(`sql/migrate: stat ${dir}: no such file or directory`);
  return fs.readdirSync(dir).filter(f => f !== "atlas.sum" && !f.startsWith(".") && fs.statSync(path.join(dir, f)).isFile()).sort();
}
function h1(buf) { return "h1:" + crypto.createHash("sha256").update(buf).digest("base64"); }
function computeSum(dir) {
  const files = migrationFiles(dir);
  const lines = files.map(f => `${f} ${h1(fs.readFileSync(path.join(dir, f)))}`);
  const root = h1(Buffer.from(lines.join("\n") + (lines.length ? "\n" : "")));
  return [root, ...lines].join("\n") + "\n";
}
function migrateHash(a) {
  const dir = fileURLToPathish(flagValue(a, ["--dir"], "file://migrations"));
  fs.writeFileSync(path.join(dir, "atlas.sum"), computeSum(dir));
}
function migrateValidate(a) {
  const dir = fileURLToPathish(flagValue(a, ["--dir"], "file://migrations"));
  let actual;
  try { actual = computeSum(dir); } catch (e) { exitError(`Error: ${e.message}`); }
  const sumPath = path.join(dir, "atlas.sum");
  if (!fs.existsSync(sumPath)) {
    exitError("You have a checksum error in your migration directory.\nPlease check your migration files and run 'atlas migrate hash' to re-hash the contents\n\nError: checksum file not found");
  }
  const expected = fs.readFileSync(sumPath, "utf8");
  if (expected !== actual) {
    exitError("You have a checksum error in your migration directory.\n\nPlease check your migration files and run 'atlas migrate hash' to re-hash the contents\n\nError: checksum mismatch");
  }
}
function timestamp() {
  const d = new Date();
  const pad = n => String(n).padStart(2, "0");
  return d.getUTCFullYear() + pad(d.getUTCMonth()+1) + pad(d.getUTCDate()) + pad(d.getUTCHours()) + pad(d.getUTCMinutes()) + pad(d.getUTCSeconds());
}
function slug(s) { return (s || "").trim().replace(/\s+/g, "_").replace(/[^A-Za-z0-9_.-]/g, "_"); }
function migrateNew(a) {
  const dir = fileURLToPathish(flagValue(a, ["--dir"], "file://migrations"));
  fs.mkdirSync(dir, {recursive:true});
  const name = slug(positionals(stripGlobal(a))[0] || "");
  const file = path.join(dir, `${timestamp()}${name ? "_" + name : ""}.sql`);
  fs.closeSync(fs.openSync(file, "w"));
}
function migrateStatus(a) {
  const dir = fileURLToPathish(flagValue(a, ["--dir"], "file://migrations"));
  let files;
  try { files = migrationFiles(dir); } catch (e) { exitError(`Error: ${e.message}`); }
  const url = flagValue(a, ["-u","--url"], "");
  if (!url) exitError("Error: sql/sqlclient: missing driver. See: https://atlasgo.io/url");
  out(`Migration Status: OK
  -- Current Version: No migration applied yet
  -- Next Version:    ${files.length ? files[0].split("_")[0].replace(/\.sql$/, "") : "Already at latest version"}
  -- Executed Files:  0
  -- Pending Files:   ${files.length}`);
}
function readDesiredSQL(urls) {
  let sql = "";
  for (const u of urls) {
    const p = fileURLToPathish(u);
    if (!fs.existsSync(p)) continue;
    if (fs.statSync(p).isDirectory()) {
      for (const f of fs.readdirSync(p).sort()) if (f.endsWith(".sql")) sql += fs.readFileSync(path.join(p,f), "utf8") + "\n";
    } else sql += fs.readFileSync(p, "utf8") + "\n";
  }
  return sql;
}
function schemaDiff(a) {
  const to = flagValues(a, ["--to"]);
  const sql = readDesiredSQL(to);
  if (sql.trim()) out(sql.trimEnd());
}
function dbBacked(name, a) {
  if (name === "inspect" && !flagValue(a, ["-u","--url"], "")) exitError('Error: required flag(s) "url" not set');
  if (name === "clean" && a.includes("--dry-run")) exitError(`Abort: 'atlas schema clean --dry-run' is not supported by the community version.

To install the non-community version of Atlas, use the following command:

\tcurl -sSf https://atlasgo.sh | sh

Or, visit the website to see all installation options:

\thttps://atlasgo.io/docs#installation`);
  exitError("Error: sql/sqlclient: missing driver. See: https://atlasgo.io/url");
}
function completion(shell) {
  if (!shell) return out(help.completion);
  if (hasHelp(args)) return out(`Generate the autocompletion script for the ${shell} shell.

Usage:
  atlas completion ${shell} [flags]

Flags:
  -h, --help              help for ${shell}
      --no-descriptions   disable completion descriptions`);
  if (shell === "bash") out("# bash completion for atlas\n_complete_atlas(){ :; }\ncomplete -F _complete_atlas atlas");
  else if (shell === "zsh") out("#compdef atlas\n_arguments '*::arg:->args'");
  else if (shell === "fish") out("complete -c atlas -f -a 'schema migrate version license completion help'");
  else if (shell === "powershell") out("Register-ArgumentCompleter -Native -CommandName atlas -ScriptBlock { param($wordToComplete) }");
  else exitError(`Error: unknown command "${shell}" for "atlas completion"`);
}

function dispatch(a) {
  if (a[0] === "help") {
    const rest = a.slice(1);
    if (!rest.length) return out(help.top);
    return dispatch([...rest, "--help"]);
  }
  if (a.length === 0 || (a[0].startsWith("-") && hasHelp(a))) return out(help.top);
  if (a.includes("--version")) exitError("Error: unknown flag: --version");
  switch (a[0]) {
    case "version":
      if (hasHelp(a)) return out(help.version);
      if (a.some(x => x.startsWith("--format"))) exitError("Error: unknown flag: --format\n" + community);
      return out("atlas unofficial version - development\nhttps://github.com/ariga/atlas/releases/latest\nTo download an official version, visit: https://atlasgo.io/getting-started#installation");
    case "license":
      if (hasHelp(a)) return out(help.license);
      return out("LICENSE\nAtlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE.");
    case "completion":
      if (a.length === 1 || hasHelp(a) && a.length === 2) return out(help.completion);
      return completion(a[1]);
    case "schema": {
      const sub = a[1];
      const rest = a.slice(2);
      if (!sub || hasHelp(a) && a.length === 2) return out(help.schema);
      const helps = {fmt:"schemaFmt", inspect:"schemaInspect", apply:"schemaApply", clean:"schemaClean", diff:"schemaDiff"};
      if (hasHelp(rest)) return out(help[helps[sub]] || help.schema);
      if (sub === "fmt") return schemaFmt(rest);
      if (sub === "diff") return schemaDiff(rest);
      if (["inspect","apply","clean"].includes(sub)) return dbBacked(sub, rest);
      exitError(`Error: unknown command "${sub}" for "atlas schema"\nRun 'atlas schema --help' for usage.`);
    }
    case "migrate": {
      const sub = a[1];
      const rest = a.slice(2);
      if (!sub || hasHelp(a) && a.length === 2) return out(help.migrate);
      const helps = {apply:"migrateApply", diff:"migrateDiff", hash:"migrateHash", import:"migrateImport", lint:"migrateLint", new:"migrateNew", set:"migrateSet", status:"migrateStatus", validate:"migrateValidate"};
      if (hasHelp(rest)) return out(help[helps[sub]] || help.migrate);
      if (sub === "hash") return migrateHash(rest);
      if (sub === "validate") return migrateValidate(rest);
      if (sub === "new") return migrateNew(rest);
      if (sub === "status") return migrateStatus(rest);
      if (sub === "diff") return schemaDiff(rest);
      if (["apply","set","lint","import"].includes(sub)) return dbBacked(sub, rest);
      exitError(`Error: unknown command "${sub}" for "atlas migrate"\nRun 'atlas migrate --help' for usage.`);
    }
    default:
      exitError(`Error: unknown command "${a[0]}" for "atlas"\nRun 'atlas --help' for usage.`);
  }
}
try { dispatch(args); } catch (e) { exitError("Error: " + e.message); }
