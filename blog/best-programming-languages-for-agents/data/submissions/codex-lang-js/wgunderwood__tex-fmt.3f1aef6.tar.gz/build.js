const fs = require("fs");
const path = require("path");

const src = path.join(__dirname, "src", "texfmt.js");
const out = path.join(__dirname, "executable");
try { fs.unlinkSync(out); } catch {}
fs.copyFileSync(src, out);
fs.chmodSync(out, 0o755);
