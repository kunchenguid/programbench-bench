#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const cp = require("child_process");

const VERSION = "tex-fmt 0.5.6";
const DEFAULT_LISTS = ["itemize", "enumerate", "description", "inlineroman", "inventory"];
const DEFAULT_VERBATIMS = ["verbatim", "Verbatim", "lstlisting", "minted", "comment"];
const DEFAULT_NO_INDENT = ["document"];

function help() {
  return `${VERSION}

LaTeX formatter written in Rust

Usage: executable [OPTIONS] [files]...

Arguments:
  [files]...  List of files to be formatted

Options:
  -c, --check               Check formatting, do not modify files
  -p, --print               Print to stdout, do not modify files
  -f, --fail-on-change      Format files and return non-zero exit code if files are modified
  -n, --nowrap              Do not wrap long lines
  -l, --wraplen <N>         Line length for wrapping [default: 80]
  -t, --tabsize <N>         Number of characters to use as tab size [default: 2]
      --usetabs             Use tabs instead of spaces for indentation
  -s, --stdin               Process stdin as a single file, output to stdout
      --config <PATH>       Path to config file
      --noconfig            Do not read any config file
  -v, --verbose             Show info messages
  -q, --quiet               Hide warning messages
      --trace               Show trace messages
      --completion <SHELL>  Generate shell completion script [possible values: bash, elvish, fish, powershell, zsh]
      --man                 Generate a man page
      --args                Print arguments passed to tex-fmt and exit
  -r, --recursive           Recursively search for files to format
  -h, --help                Print help
  -V, --version             Print version
`;
}

function defaultOptions() {
  return {
    check: false,
    print: false,
    failOnChange: false,
    recursive: false,
    wrap: true,
    wraplen: 80,
    wrapmin: 70,
    tabsize: 2,
    tabchar: "space",
    stdin: false,
    config: null,
    noconfig: false,
    verbosity: "warn",
    lists: DEFAULT_LISTS.slice(),
    verbatims: DEFAULT_VERBATIMS.slice(),
    noIndentEnvs: DEFAULT_NO_INDENT.slice(),
    wrapChars: [],
    files: []
  };
}

function dieArg(msg) {
  process.stderr.write(`error: ${msg}\n\nUsage: executable [OPTIONS] [files]...\n\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function parseArgs(argv) {
  const opt = defaultOptions();
  const cliSet = new Set();
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") {
      opt.files.push(...argv.slice(i + 1));
      break;
    } else if (a === "-h" || a === "--help") {
      process.stdout.write(help());
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      process.stdout.write(VERSION + "\n");
      process.exit(0);
    } else if (a === "-c" || a === "--check") {
      opt.check = true; cliSet.add("check");
    } else if (a === "-p" || a === "--print") {
      opt.print = true; cliSet.add("print");
    } else if (a === "-f" || a === "--fail-on-change") {
      opt.failOnChange = true; cliSet.add("failOnChange");
    } else if (a === "-r" || a === "--recursive") {
      opt.recursive = true; cliSet.add("recursive");
    } else if (a === "-n" || a === "--nowrap") {
      opt.wrap = false; cliSet.add("wrap");
    } else if (a === "-s" || a === "--stdin") {
      opt.stdin = true; opt.print = true; opt.failOnChange = true; cliSet.add("stdin");
    } else if (a === "--usetabs") {
      opt.tabchar = "tab"; cliSet.add("tabchar");
    } else if (a === "-v" || a === "--verbose") {
      opt.verbosity = "info"; cliSet.add("verbosity");
    } else if (a === "-q" || a === "--quiet") {
      opt.verbosity = "error"; cliSet.add("verbosity");
    } else if (a === "--trace") {
      opt.verbosity = "trace"; cliSet.add("verbosity");
    } else if (a === "-l" || a === "--wraplen" || a === "-t" || a === "--tabsize" || a === "--config" || a === "--completion") {
      const v = argv[++i];
      if (v == null) dieArg(`a value is required for '${a}' but none was supplied`);
      if (a === "-l" || a === "--wraplen") { opt.wraplen = parseInt(v, 10); opt.wrapmin = opt.wraplen - 10; cliSet.add("wraplen"); }
      else if (a === "-t" || a === "--tabsize") { opt.tabsize = parseInt(v, 10); cliSet.add("tabsize"); }
      else if (a === "--config") { opt.config = v; cliSet.add("config"); }
      else { process.stdout.write(completion(v)); process.exit(0); }
    } else if (a === "--noconfig") {
      opt.noconfig = true;
    } else if (a === "--man") {
      process.stdout.write(manPage());
      process.exit(0);
    } else if (a === "--args") {
      opt.args = true;
    } else if (a.startsWith("-")) {
      dieArg(`unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'`);
    } else {
      opt.files.push(a);
    }
  }
  applyConfig(opt, cliSet);
  return opt;
}

function readConfigFile(file, opt, cliSet) {
  let txt;
  try { txt = fs.readFileSync(file, "utf8"); } catch { return; }
  for (const raw of txt.split(/\r?\n/)) {
    let line = raw.replace(/#.*/, "").trim();
    if (!line || !line.includes("=")) continue;
    const [k0, ...rest] = line.split("=");
    const key = k0.trim();
    const val = rest.join("=").trim();
    const bool = val === "true";
    const num = parseInt(val, 10);
    const str = val.replace(/^"|"$/g, "");
    const arr = [...val.matchAll(/"([^"]*)"/g)].map(m => m[1]);
    const set = (prop, value) => { if (!cliSet.has(prop)) opt[prop] = value; };
    if (key === "check") set("check", bool);
    else if (key === "print") set("print", bool);
    else if (key === "fail-on-change") set("failOnChange", bool);
    else if (key === "wrap") set("wrap", bool);
    else if (key === "wraplen") set("wraplen", num);
    else if (key === "wrapmin") set("wrapmin", num);
    else if (key === "tabsize") set("tabsize", num);
    else if (key === "tabchar") set("tabchar", str);
    else if (key === "stdin") set("stdin", bool);
    else if (key === "verbosity") set("verbosity", str);
    else if (key === "lists") opt.lists = DEFAULT_LISTS.concat(arr);
    else if (key === "verbatims") opt.verbatims = DEFAULT_VERBATIMS.concat(arr);
    else if (key === "no-indent-envs") opt.noIndentEnvs = DEFAULT_NO_INDENT.concat(arr);
    else if (key === "wrap-chars") opt.wrapChars = arr;
  }
}

function applyConfig(opt, cliSet) {
  if (opt.noconfig) return;
  if (opt.config) {
    readConfigFile(opt.config, opt, cliSet);
    return;
  }
  const cwdFile = path.join(process.cwd(), "tex-fmt.toml");
  if (fs.existsSync(cwdFile)) { readConfigFile(cwdFile, opt, cliSet); return; }
  try {
    const root = cp.execFileSync("git", ["rev-parse", "--show-toplevel"], {encoding: "utf8", stdio: ["ignore", "pipe", "ignore"]}).trim();
    const gitFile = path.join(root, "tex-fmt.toml");
    if (fs.existsSync(gitFile)) { readConfigFile(gitFile, opt, cliSet); return; }
  } catch {}
  const home = process.env.HOME || "";
  if (home) readConfigFile(path.join(home, ".config", "tex-fmt", "tex-fmt.toml"), opt, cliSet);
}

function argsPrint(opt) {
  const lines = [];
  lines.push("tex-fmt");
  const add = (k, v) => lines.push(`  ${k.padEnd(25)}${v}`);
  add("check:", String(opt.check));
  add("print:", String(opt.print));
  add("fail-on-change:", String(opt.failOnChange));
  add("wrap:", String(opt.wrap));
  add("wraplen:", String(opt.wraplen));
  add("wrapmin:", String(opt.wrapmin));
  add("tabsize:", String(opt.tabsize));
  add("tabchar:", opt.tabchar);
  add("stdin:", String(opt.stdin));
  add("config:", opt.config ? `Some(${opt.config})` : "None");
  add("verbosity:", opt.verbosity === "info" ? "info" : opt.verbosity === "trace" ? "trace" : opt.verbosity === "error" ? "error" : "warn");
  const multi = (k, arr) => {
    if (!arr.length) add(k + ":", "");
    else arr.forEach((x, i) => lines.push(`  ${i === 0 ? (k + ":").padEnd(25) : "".padEnd(27)}${x}`));
  };
  multi("lists", opt.lists);
  multi("verbatims", opt.verbatims);
  multi("no-indent-envs", opt.noIndentEnvs);
  multi("wrap-chars", opt.wrapChars);
  add("files:", opt.files.join(" "));
  return lines.join("\n") + "\n";
}

function indentUnit(opt) {
  return opt.tabchar === "tab" ? "\t" : " ".repeat(Number.isFinite(opt.tabsize) ? opt.tabsize : 2);
}

function beginEnv(line) {
  const m = line.match(/^\\begin\s*\{([^}]+)\}/);
  return m && m[1];
}
function endEnv(line) {
  const m = line.match(/^\\end\s*\{([^}]+)\}/);
  return m && m[1];
}

function wrapLine(line, contIndent, opt) {
  if (!opt.wrap || line.length <= opt.wraplen || !line.trim() || line.trim().startsWith("%")) return [line];
  const words = line.trimEnd().split(/\s+/);
  const initialIndent = (line.match(/^\s*/) || [""])[0];
  let out = [];
  let cur = initialIndent + words.shift();
  let indent = initialIndent;
  for (const w of words) {
    const limit = opt.wraplen;
    if ((cur + " " + w).length > limit && cur.trim()) {
      out.push(cur);
      indent = contIndent;
      cur = indent + w;
    } else {
      cur += " " + w;
    }
  }
  out.push(cur);
  return out;
}

function formatText(input, opt) {
  input = input.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = input.split("\n");
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  const unit = indentUnit(opt);
  const lists = new Set(opt.lists);
  const verbatims = new Set(opt.verbatims);
  const noIndent = new Set(opt.noIndentEnvs);
  const out = [];
  let depth = 0;
  let itemDepth = null;
  let off = false;
  let verbatim = null;
  const envStack = [];

  for (let raw of lines) {
    if (off) {
      out.push(raw);
      if (raw.includes("% tex-fmt: on")) off = false;
      continue;
    }
    if (verbatim) {
      out.push(raw);
      if (endEnv(raw.trim()) === verbatim) verbatim = null;
      continue;
    }
    if (raw.includes("% tex-fmt: off")) { out.push(raw.trimStart()); off = true; continue; }
    if (raw.includes("% tex-fmt: skip")) { out.push(raw); continue; }
    const t = raw.trim();
    if (t === "") { out.push(""); continue; }

    const e = endEnv(t);
    if (e) {
      const top = envStack.pop();
      if (!noIndent.has(e)) depth = Math.max(0, depth - 1);
      if (top && lists.has(top)) itemDepth = null;
    } else if (t.startsWith("}") || t === "\\]" || t === "\\)") {
      depth = Math.max(0, depth - 1);
    }

    let effectiveDepth = depth;
    let contDepth = depth;
    if (/^\\item(?:\b|\[|\{|\s|$)/.test(t)) {
      effectiveDepth = depth;
      itemDepth = depth + 1;
      contDepth = depth + 1;
    } else if (itemDepth != null && !e) {
      effectiveDepth = Math.max(depth, itemDepth);
      contDepth = effectiveDepth;
    } else if (/^\\[A-Za-z@]+\*?(?:\[[^\]]*\])?\{/.test(t) && !/^\\(begin|end)\b/.test(t)) {
      contDepth = effectiveDepth + 1;
    }

    const line = unit.repeat(effectiveDepth) + t;
    out.push(...wrapLine(line, unit.repeat(contDepth), opt));

    const b = beginEnv(t);
    if (b) {
      envStack.push(b);
      if (verbatims.has(b)) verbatim = b;
      if (!noIndent.has(b)) depth++;
      if (lists.has(b)) itemDepth = null;
    } else if (!e && (t === "{" || t === "\\[" || t === "\\(" || /^@\w+\s*\{/.test(t))) {
      depth++;
    }
  }
  return out.join("\n") + "\n";
}

function logInfo(opt, file, msg) {
  if (opt.verbosity === "info" || opt.verbosity === "trace") process.stderr.write(`INFO: tex-fmt ${file}: ${msg}. \n`);
}

function processFile(file, opt) {
  logInfo(opt, file, "Formatting started");
  let orig;
  try { orig = fs.readFileSync(file, "utf8"); }
  catch (e) { process.stderr.write(`ERROR: tex-fmt ${file}: ${e.message}. \n`); return 1; }
  const fmt = formatText(orig, opt);
  const changed = fmt !== orig;
  if (opt.check) {
    if (changed) { process.stderr.write(`ERROR: tex-fmt ${file}: Incorrect formatting. \n`); return 1; }
  } else if (opt.print) {
    process.stdout.write(fmt);
  } else {
    if (changed) fs.writeFileSync(file, fmt);
    if (opt.failOnChange && changed) return 1;
  }
  logInfo(opt, file, "Formatting complete");
  return 0;
}

function walk(start, out) {
  let st;
  try { st = fs.statSync(start); } catch { return; }
  if (st.isFile()) {
    if (/\.(tex|bib|cls|sty)$/i.test(start)) out.push(start);
    return;
  }
  if (!st.isDirectory()) return;
  const base = path.basename(start);
  if (base === ".git" || base === "node_modules" || base === "target") return;
  for (const ent of fs.readdirSync(start).sort()) walk(path.join(start, ent), out);
}

function completion(shell) {
  return `# ${shell} completion for tex-fmt\n`;
}

function manPage() {
  return `.TH TEX-FMT 1\n.SH NAME\ntex-fmt \\- LaTeX formatter written in Rust\n.SH SYNOPSIS\n.B tex-fmt\n[OPTIONS] [files]...\n`;
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  if (opt.args) { process.stdout.write(argsPrint(opt)); return; }
  if (opt.stdin) {
    const input = fs.readFileSync(0, "utf8");
    process.stdout.write(formatText(input, opt));
    return;
  }
  let files = opt.files.slice();
  if (opt.recursive) {
    const roots = files.length ? files : ["."];
    files = [];
    roots.forEach(r => walk(r, files));
  }
  if (!files.length) {
    process.stderr.write("ERROR: tex-fmt : No files specified. Provide filenames, or pass --recursive or --stdin. \n");
    process.exit(1);
  }
  let code = 0;
  for (const f of files) if (processFile(f, opt)) code = 1;
  process.exit(code);
}

main();
