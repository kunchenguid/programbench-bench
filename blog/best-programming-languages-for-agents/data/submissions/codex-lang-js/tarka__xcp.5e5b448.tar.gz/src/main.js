#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const VERSION = 'xcp 0.24.3';

function shortHelp(long=false) {
  if (long) return `A (partial) clone of the Unix \`cp\` command with progress and pluggable drivers.\n\nUsage: executable [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...\n          Path list.\n          \n          Source and destination files, or multiple source(s) to a directory.\n\nOptions:\n  -v, --verbose...\n          Verbosity.\n          \n          Can be specified multiple times to increase logging.\n\n  -r, --recursive\n          Copy directories recursively\n\n  -L, --dereference\n          Dereference symlinks in source\n          \n          Follow symlinks, possibly recursively, when copying source files.\n\n  -w, --workers <WORKERS>\n          Number of parallel workers.\n          \n          Default is 4; if the value is negative or 0 it uses the number of logical CPUs.\n          \n          [default: 4]\n\n      --block-size <BLOCK_SIZE>\n          Block size for operations.\n          \n          Accepts standard size modifiers like "M" and "GB". Actual usage internally depends on the driver.\n          \n          [default: 1MB]\n\n  -n, --no-clobber\n          Do not overwrite an existing file\n\n  -f, --force\n          Force (compatability only)\n          \n          Overwrite files; this is the default behaviour, this flag is for compatibility with \`cp\` only. See \`--no-clobber\` for the inverse flag. Using this in conjunction with \`--no-clobber\` will cause an error.\n\n      --gitignore\n          Use .gitignore if present.\n          \n          NOTE: This is fairly basic at the moment, and only honours a .gitignore in the directory root for directory copies; global or sub-directory ignores are skipped.\n\n  -g, --glob\n          Expand file patterns.\n          \n          Glob (expand) filename patterns natively (note; the shell may still do its own expansion first)\n\n      --no-progress\n          Disable progress bar\n\n      --no-perms\n          Do not copy the file permissions\n\n      --no-timestamps\n          Do not copy the file timestamps\n\n  -o, --ownership\n          Copy ownership.\n          \n          Whether to copy ownship (user/group).  This option requires root permissions or appropriate capabilities; if the attempt to copy ownership fails a warning is issued but the operation continues.\n\n      --driver <DRIVER>\n          Driver to use, defaults to 'file-parallel'.\n          \n          Currently there are 2; the default "parfile", which parallelises copies across workers at the file level, and an experimental "parblock" driver, which parellelises at the block level. See also '--block-size'.\n          \n          [default: parfile]\n\n  -T, --no-target-directory\n          Target should not be a directory.\n          \n          Analogous to cp's no-target-directory. Expected behavior is that when copying a directory to another directory, instead of creating a sub-folder in target, overwrite target.\n\n      --target-directory <TARGET_DIRECTORY>\n          Copy into a subdirectory of the target\n\n      --fsync\n          Sync each file to disk after writing\n\n      --reflink <REFLINK>\n          Reflink options.\n          \n          Whether and how to use reflinks. 'auto' (the default) will attempt to reflink and fallback to a copy if it is not possible, 'always' will return an error if it cannot reflink, and 'never' will always perform a full data copy.\n          \n          Note: when using Linux accelerated copy operations (the default when available) the kernel may choose to reflink rather than perform a fully copy regardless of this setting.\n          \n          [default: auto]\n\n      --backup <BACKUP>\n          Backup options\n          \n          Whether to create backups of overwritten files. Current options are 'none'/'off', or 'numbered', or 'auto'. Numbered backups follow the semantics of \`cp\` numbered backups (e.g. \`file.txt.~123~\`). 'auto' will only create a numbered backup if a previous backups exists. Default is 'none'.\n          \n          [default: none]\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version`;
  return `A (partial) clone of the Unix \`cp\` command with progress and pluggable drivers.\n\nUsage: executable [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  Path list\n\nOptions:\n  -v, --verbose...\n          Verbosity\n  -r, --recursive\n          Copy directories recursively\n  -L, --dereference\n          Dereference symlinks in source\n  -w, --workers <WORKERS>\n          Number of parallel workers [default: 4]\n      --block-size <BLOCK_SIZE>\n          Block size for operations [default: 1MB]\n  -n, --no-clobber\n          Do not overwrite an existing file\n  -f, --force\n          Force (compatability only)\n      --gitignore\n          Use .gitignore if present\n  -g, --glob\n          Expand file patterns\n      --no-progress\n          Disable progress bar\n      --no-perms\n          Do not copy the file permissions\n      --no-timestamps\n          Do not copy the file timestamps\n  -o, --ownership\n          Copy ownership\n      --driver <DRIVER>\n          Driver to use, defaults to 'file-parallel' [default: parfile]\n  -T, --no-target-directory\n          Target should not be a directory\n      --target-directory <TARGET_DIRECTORY>\n          Copy into a subdirectory of the target\n      --fsync\n          Sync each file to disk after writing\n      --reflink <REFLINK>\n          Reflink options [default: auto]\n      --backup <BACKUP>\n          Backup options [default: none]\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version`;
}

function die(msg, code=1) { console.error(msg); process.exit(code); }
function exists(p) { try { fs.lstatSync(p); return true; } catch { return false; } }
function statOf(p, deref) { return deref ? fs.statSync(p) : fs.lstatSync(p); }
function isDir(p) { try { return fs.statSync(p).isDirectory(); } catch { return false; } }

function parse(argv) {
  const opt = { recursive:false, dereference:false, noClobber:false, force:false, gitignore:false, glob:false, noPerms:false, noTimestamps:false, ownership:false, noTarget:false, fsync:false, targetDirectory:null, backup:'none', driver:'parfile', reflink:'auto', paths:[] };
  for (let i=0;i<argv.length;i++) {
    const a = argv[i];
    if (a === '--') { opt.paths.push(...argv.slice(i+1)); break; }
    if (a === '-h') { console.log(shortHelp(false)); process.exit(0); }
    if (a === '--help') { console.log(shortHelp(true)); process.exit(0); }
    if (a === '-V' || a === '--version') { console.log(VERSION); process.exit(0); }
    if (!a.startsWith('-') || a === '-') { opt.paths.push(a); continue; }
    const need = (name) => { if (i+1 >= argv.length) clapMissing(name); return argv[++i]; };
    if (a.startsWith('--')) {
      let [name, val] = a.includes('=') ? a.split(/=(.*)/s,2) : [a, undefined];
      switch(name) {
        case '--verbose': break;
        case '--recursive': opt.recursive = true; break;
        case '--dereference': opt.dereference = true; break;
        case '--workers': if (val===undefined) val=need('--workers <WORKERS>'); break;
        case '--block-size': if (val===undefined) val=need('--block-size <BLOCK_SIZE>'); break;
        case '--no-clobber': opt.noClobber = true; break;
        case '--force': opt.force = true; break;
        case '--gitignore': opt.gitignore = true; break;
        case '--glob': opt.glob = true; break;
        case '--no-progress': break;
        case '--no-perms': opt.noPerms = true; break;
        case '--no-timestamps': opt.noTimestamps = true; break;
        case '--ownership': opt.ownership = true; break;
        case '--driver': if (val===undefined) val=need('--driver <DRIVER>'); opt.driver = val; break;
        case '--no-target-directory': opt.noTarget = true; break;
        case '--target-directory': if (val===undefined) val=need('--target-directory <TARGET_DIRECTORY>'); opt.targetDirectory = val; break;
        case '--fsync': opt.fsync = true; break;
        case '--reflink': if (val===undefined) val=need('--reflink <REFLINK>'); opt.reflink = val; break;
        case '--backup': if (val===undefined) val=need('--backup <BACKUP>'); opt.backup = val; break;
        default: clapUnexpected(a);
      }
      continue;
    }
    for (let j=1;j<a.length;j++) {
      const c = a[j];
      if (c === 'v') continue;
      if (c === 'r' || c === 'R') opt.recursive = true;
      else if (c === 'L') opt.dereference = true;
      else if (c === 'n') opt.noClobber = true;
      else if (c === 'f') opt.force = true;
      else if (c === 'g') opt.glob = true;
      else if (c === 'o') opt.ownership = true;
      else if (c === 'T') opt.noTarget = true;
      else if (c === 'w') { const rest = a.slice(j+1); if (rest) { j=a.length; } else need('-w <WORKERS>'); break; }
      else if (c === 'h') { console.log(shortHelp(false)); process.exit(0); }
      else if (c === 'V') { console.log(VERSION); process.exit(0); }
      else clapUnexpected('-' + c);
    }
  }
  if (opt.force && opt.noClobber) die('Error: Invalid arguments: --force and --noclobber cannot be set at the same time.');
  if (!['parfile','parblock'].includes(opt.driver)) die(`error: invalid value '${opt.driver}' for '--driver <DRIVER>': Unknown driver: ${opt.driver}\n\nFor more information, try '--help'.`, 2);
  if (!['auto','always','never'].includes(opt.reflink)) die(`error: invalid value '${opt.reflink}' for '--reflink <REFLINK>': Invalid arguments: Unexpected value for 'reflink': ${opt.reflink}\n\nFor more information, try '--help'.`, 2);
  if (opt.backup === 'off') opt.backup = 'none';
  if (!['none','numbered','auto'].includes(opt.backup)) die(`error: invalid value '${opt.backup}' for '--backup <BACKUP>': Invalid arguments: Unexpected value for 'backup': ${opt.backup}\n\nFor more information, try '--help'.`, 2);
  return opt;
}
function clapUnexpected(a) { die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.`, 2); }
function clapMissing(a) { die(`error: a value is required for '${a}' but none was supplied\n\nFor more information, try '--help'.`, 2); }

function globToReg(s) {
  let out='^';
  for (let i=0;i<s.length;i++) {
    const ch=s[i];
    if (ch==='*') out+='[^/]*';
    else if (ch==='?') out+='[^/]';
    else if (ch==='[') { let k=s.indexOf(']',i+1); if(k>i){out+=s.slice(i,k+1); i=k;} else out+='\\['; }
    else out+=ch.replace(/[\\^$+?.()|{}]/g,'\\$&');
  }
  return new RegExp(out+'$');
}
function expandOne(pattern) {
  if (!/[?*[]/.test(pattern)) return [pattern];
  const parts = pattern.split(/[\\/]+/).filter(Boolean);
  let prefixes = [path.isAbsolute(pattern) ? path.parse(pattern).root : process.cwd()];
  for (const part of parts) {
    const magic = /[?*[]/.test(part);
    const next=[];
    for (const pre of prefixes) {
      if (!magic) { next.push(path.join(pre, part)); continue; }
      let entries=[]; try { entries=fs.readdirSync(pre); } catch { continue; }
      const re=globToReg(part);
      for (const e of entries) if (re.test(e)) next.push(path.join(pre,e));
    }
    prefixes=next;
  }
  return prefixes.length ? prefixes : [pattern];
}

function readGitIgnore(root) {
  const file = path.join(root, '.gitignore');
  let lines=[]; try { lines = fs.readFileSync(file,'utf8').split(/\r?\n/); } catch { return () => false; }
  const pats = lines.map(l=>l.trim()).filter(l=>l && !l.startsWith('#')).map(l => l.replace(/^\//,''));
  return (rel) => {
    rel = rel.replace(/\\/g,'/');
    const base = path.basename(rel);
    return pats.some(p => {
      if (p.endsWith('/')) p = p.slice(0,-1);
      if (!p.includes('/')) return globToReg(p).test(base) || rel.split('/').includes(p);
      return globToReg(p).test(rel);
    });
  };
}

function prepareDest(dst, opt) {
  if (!exists(dst)) return;
  if (opt.noClobber) throw new Error(`Destination Exists: Destination file exists and --no-clobber is set., ${dst}`);
  const doBackup = opt.backup === 'numbered' || (opt.backup === 'auto' && nextBackupNumber(dst) > 1);
  if (doBackup) fs.renameSync(dst, `${dst}.~${nextBackupNumber(dst)}~`);
  else rmExisting(dst);
}
function sameFile(a, b) {
  try {
    const as = fs.statSync(a), bs = fs.statSync(b);
    return as.dev === bs.dev && as.ino === bs.ino;
  } catch { return false; }
}
function nextBackupNumber(dst) {
  const dir=path.dirname(dst), base=path.basename(dst);
  let max=0;
  try { for (const e of fs.readdirSync(dir)) { const m=e.match(new RegExp('^'+escapeRe(base)+'\\.~(\\d+)~$')); if(m) max=Math.max(max, Number(m[1])); } } catch {}
  return max+1;
}
function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }
function rmExisting(p) {
  const st=fs.lstatSync(p);
  if (st.isDirectory() && !st.isSymbolicLink()) fs.rmSync(p,{recursive:true,force:true}); else fs.unlinkSync(p);
}
function ensureParent(p) { fs.mkdirSync(path.dirname(p), {recursive:true}); }
function applyMeta(src, dst, st, opt) {
  if (!opt.noPerms) { try { fs.chmodSync(dst, st.mode & 0o7777); } catch {} }
  if (!opt.noTimestamps) { try { fs.utimesSync(dst, st.atime, st.mtime); } catch {} }
  if (opt.ownership) { try { fs.chownSync(dst, st.uid, st.gid); } catch (e) { console.error(`WARN: Unable to set ownership on ${dst}: ${e.message}`); } }
}

function copyPath(src, dst, opt, rootIgnore=null, rel='') {
  if (!exists(src)) throw new Error('Invalid source: Source does not exist.');
  const st = statOf(src, opt.dereference);
  if (rootIgnore && rel && rootIgnore(rel)) return;
  if (st.isDirectory()) {
    if (!opt.recursive) throw new Error('Invalid source: Source is directory and --recursive not specified.');
    if (exists(dst) && !fs.statSync(dst).isDirectory()) prepareDest(dst, opt);
    fs.mkdirSync(dst, {recursive:true, mode: st.mode & 0o7777});
    for (const ent of fs.readdirSync(src)) {
      const childRel = rel ? `${rel}/${ent}` : ent;
      if (rootIgnore && rootIgnore(childRel)) continue;
      copyPath(path.join(src, ent), path.join(dst, ent), opt, rootIgnore, childRel);
    }
    applyMeta(src, dst, st, opt);
    return;
  }
  if (!opt.dereference && fs.lstatSync(src).isSymbolicLink()) {
    prepareDest(dst, opt);
    const target = fs.readlinkSync(src);
    fs.symlinkSync(target, dst);
    return;
  }
  if (!st.isFile()) {
    // Best effort for devices/FIFOs: create an empty placeholder rather than streaming special files.
    if (exists(dst) && sameFile(src, dst)) throw new Error(`'${src}' and '${dst}' are the same file`);
    prepareDest(dst, opt); fs.closeSync(fs.openSync(dst, 'w')); applyMeta(src,dst,st,opt); return;
  }
  if (exists(dst) && sameFile(src, dst)) throw new Error(`'${src}' and '${dst}' are the same file`);
  prepareDest(dst, opt);
  fs.copyFileSync(src, dst);
  applyMeta(src, dst, st, opt);
  if (opt.fsync) { try { const fd=fs.openSync(dst,'r'); fs.fsyncSync(fd); fs.closeSync(fd); } catch {} }
}

function main() {
  const opt = parse(process.argv.slice(2));
  if (opt.glob) opt.paths = opt.paths.flatMap(expandOne);
  let sources, destBase, targetMode = false;
  if (opt.targetDirectory !== null) { sources = opt.paths; destBase = opt.targetDirectory; targetMode = true; }
  else {
    if (opt.paths.length < 2) die('Error: Invalid arguments: Insufficient arguments');
    sources = opt.paths.slice(0,-1); destBase = opt.paths[opt.paths.length-1];
  }
  if (sources.length === 0) die('Error: Invalid arguments: Insufficient arguments');
  if (sources.length > 1 && !isDir(destBase)) die('Error: Invalid destination: Multiple sources and destination is not a directory.');
  if (targetMode && !isDir(destBase)) die('Error: Invalid destination: Target directory is not a directory.');

  for (const src of sources) {
    if (!exists(src)) die('Error: Invalid source: Source does not exist.');
    const st = statOf(src, opt.dereference);
    let dst;
    if (targetMode || (isDir(destBase) && !opt.noTarget)) dst = path.join(destBase, path.basename(src));
    else dst = destBase;
    if (opt.noTarget && isDir(destBase) && !st.isDirectory()) die(`Error: Invalid destination: Cannot overwrite directory with non-directory.`);
    const ignore = opt.gitignore && st.isDirectory() ? readGitIgnore(src) : null;
    try { copyPath(src, dst, opt, ignore, ''); }
    catch (e) {
      if (e && e.code === 'ENOENT') die('Error: Error during copy: No such file or directory (os error 2)');
      die(`Error: ${e.message}`);
    }
  }
}
main();
