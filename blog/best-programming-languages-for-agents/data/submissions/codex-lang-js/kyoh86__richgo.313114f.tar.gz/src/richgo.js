#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const COLORS = {
  black: 30, red: 31, green: 32, yellow: 33, blue: 34, magenta: 35, cyan: 36, white: 37,
  lightBlack: 90, lightRed: 91, lightGreen: 92, lightYellow: 93, lightBlue: 94,
  lightMagenta: 95, lightCyan: 96, lightWhite: 97, gray: 90, grey: 90
};

function defaultConfig() {
  return {
    labelType: "long",
    buildStyle: { bold: true, foreground: "yellow" },
    startStyle: { foreground: "lightBlack" },
    passStyle: { foreground: "green" },
    failStyle: { bold: true, foreground: "red" },
    skipStyle: { foreground: "lightBlack" },
    passPackageStyle: { foreground: "green", hide: true },
    failPackageStyle: { bold: true, foreground: "red", hide: true },
    coverThreshold: 50,
    coveredStyle: { foreground: "green" },
    uncoveredStyle: { bold: true, foreground: "yellow" },
    fileStyle: { foreground: "cyan" },
    lineStyle: { foreground: "magenta" },
    removals: [],
    leaveTestPrefix: false
  };
}

function parseScalar(v) {
  v = String(v).trim();
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
    v = v.slice(1, -1);
  }
  if (v === "true") return true;
  if (v === "false") return false;
  if (/^-?\d+(\.\d+)?$/.test(v)) return Number(v);
  return v;
}

function mergeStyleFile(cfg, file) {
  let text;
  try { text = fs.readFileSync(file, "utf8"); } catch { return; }
  let section = null;
  let listKey = null;
  for (const raw of text.split(/\r?\n/)) {
    const noComment = raw.replace(/\s+#.*$/, "");
    if (!noComment.trim()) continue;
    const indent = /^\s*/.exec(noComment)[0].length;
    const line = noComment.trim();
    if (listKey && line.startsWith("- ")) {
      if (!Array.isArray(cfg[listKey])) cfg[listKey] = [];
      cfg[listKey].push(parseScalar(line.slice(2)));
      continue;
    }
    const m = /^([A-Za-z0-9_]+):(?:\s*(.*))?$/.exec(line);
    if (!m) continue;
    const key = m[1];
    const rest = m[2] || "";
    if (indent === 0) {
      section = null;
      listKey = null;
      if (rest === "") {
        if (key === "removals") {
          cfg[key] = [];
          listKey = key;
        } else {
          if (!cfg[key] || typeof cfg[key] !== "object") cfg[key] = {};
          section = key;
        }
      } else {
        cfg[key] = parseScalar(rest);
      }
    } else if (section) {
      cfg[section][key] = parseScalar(rest);
    }
  }
}

function loadConfig() {
  const cfg = defaultConfig();
  const cwd = process.cwd();
  const homes = [];
  homes.push(cwd);
  if (process.env.RICHGO_LOCAL !== "1") {
    if (process.env.GOPATH) homes.push(process.env.GOPATH);
    if (process.env.GOROOT) homes.push(process.env.GOROOT);
    if (process.env.HOME) homes.push(process.env.HOME);
  }
  const names = [".richstyle", ".richstyle.yaml", ".richstyle.yml"];
  for (const base of homes) for (const n of names) mergeStyleFile(cfg, path.join(base, n));
  return cfg;
}

function ansiFor(style) {
  const codes = [];
  if (!style) return "";
  if (style.foreground && COLORS[style.foreground] != null) codes.push(COLORS[style.foreground]);
  if (style.background && COLORS[style.background] != null) codes.push(COLORS[style.background] + 10);
  let out = codes.length ? `\x1b[${codes.join(";")}m` : "";
  for (const c of [
    style.bold && 1,
    style.faint && 2,
    style.italic && 3,
    style.underline && 4,
    style.blinkSlow && 5,
    style.blinkRapid && 6,
    style.inverse && 7,
    style.conceal && 8,
    style.crossOut && 9
  ].filter(Boolean)) out += `\x1b[${c}m`;
  return out;
}

function color(text, style) {
  if (style && style.hide) return "";
  const a = ansiFor(style);
  return a ? a + text + "\x1b[0m" : text;
}

function label(kind, cfg) {
  if (cfg.labelType === "none") return "";
  if (cfg.labelType === "short") {
    return ({ build: "!!", start: ">", pass: "o", fail: "x", skip: "-", cover: "%" }[kind] || "  ") + "  ";
  }
  return ({ build: "BUILD", start: "START", pass: "PASS ", fail: "FAIL ", skip: "SKIP ", cover: "     " }[kind] || "     ") + "| ";
}

function cleanTestName(s, cfg) {
  s = s.trim();
  const clean = cfg.leaveTestPrefix ? s : s.replace(/^Test/, "");
  return clean.includes("/") ? "  " + clean : clean;
}

function colorFileRefs(text, cfg) {
  const resume = ansiFor(cfg.startStyle);
  return text.replace(/([A-Za-z0-9_.\/-]+\.go)(:\d+)/g, (_, f, l) => color(f, cfg.fileStyle) + color(l, cfg.lineStyle) + resume);
}

function classify(line, cfg) {
  let m;
  if ((m = /^=== RUN\s+(.+)$/.exec(line))) {
    return { kind: "start", style: cfg.startStyle, text: label("start", cfg) + cleanTestName(m[1], cfg) };
  }
  if ((m = /^--- PASS:\s+(.+)$/.exec(line))) {
    return { kind: "pass", style: cfg.passStyle, text: label("pass", cfg) + cleanTestName(m[1], cfg) };
  }
  if ((m = /^--- FAIL:\s+(.+)$/.exec(line))) {
    return { kind: "fail", style: cfg.failStyle, text: label("fail", cfg) + cleanTestName(m[1], cfg) };
  }
  if ((m = /^--- SKIP:\s+(.+)$/.exec(line))) {
    return { kind: "skip", style: cfg.skipStyle, text: label("skip", cfg) + cleanTestName(m[1], cfg) };
  }
  if (line === "PASS") return { kind: "passpkg", style: cfg.passPackageStyle, text: "PASS", packageLine: true };
  if (line === "FAIL") return { kind: "failpkg", style: cfg.failPackageStyle, text: "FAIL", packageLine: true };
  if ((m = /^ok\s+(.+?)(?:\s+(?:\d+(?:\.\d+)?s|\(cached\)))?(?:\s+coverage:\s+(.+))?$/.exec(line))) {
    return { kind: "pass", style: cfg.passStyle, text: label("pass", cfg) + m[1] + " " };
  }
  if ((m = /^FAIL(.*)$/.exec(line))) {
    return { kind: "fail", style: cfg.failStyle, text: label("fail", cfg) + m[1] };
  }
  if ((m = /^\?\s+(.+)$/.exec(line))) {
    return { kind: "skip", style: cfg.skipStyle, text: label("skip", cfg) + m[1] };
  }
  if (/coverage:\s+/.test(line)) {
    const cm = /coverage:\s+([0-9.]+)%/.exec(line);
    const pct = cm ? Number(cm[1]) : 100;
    const style = pct >= Number(cfg.coverThreshold || 0) ? cfg.coveredStyle : cfg.uncoveredStyle;
    return { kind: "cover", style, text: label("cover", cfg) + line.replace(/% of/, "0f").replace(/%/, "0f").replace(/ of/, "") };
  }
  if (/^\s+/.test(line)) {
    return { kind: "build", style: cfg.startStyle, text: "     | " + colorFileRefs(line, cfg) };
  }
  return { kind: "build", style: cfg.buildStyle, text: label("build", cfg) + line };
}

function filter() {
  const cfg = loadConfig();
  const input = fs.readFileSync(0, "utf8");
  const isTTY = !!process.stdout.isTTY;
  const lines = input.split(/\r?\n/);
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  const removals = (cfg.removals || []).map(r => { try { return new RegExp(r); } catch { return null; } }).filter(Boolean);
  for (const line of lines) {
    if (removals.some(r => r.test(line))) continue;
    if (!isTTY) {
      process.stdout.write(line + "\n");
      continue;
    }
    const c = classify(line, cfg);
    if (c.packageLine && c.style && c.style.hide) continue;
    process.stdout.write(color(c.text, c.style) + "\n");
  }
  if (!isTTY) process.stdout.write("\n");
}

function runGo(args) {
  const r = spawnSync("go", args, { stdio: "inherit" });
  if (r.error) {
    process.stderr.write('panic: exec: "go": executable file not found in $PATH\n\n');
    process.exit(2);
  }
  process.exit(r.status == null ? 1 : r.status);
}

const args = process.argv.slice(2);
if (args[0] === "testfilter") filter();
else runGo(args);
