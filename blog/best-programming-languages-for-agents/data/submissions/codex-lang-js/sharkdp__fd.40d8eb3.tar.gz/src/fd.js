#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const VERSION = 'fd 10.3.0';
const SHORT_HELP = `A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]  the search pattern (a regular expression, unless '--glob' is used; optional)
  [path]...  the root directories for the filesystem search (optional)

Options:
  -H, --hidden                     Search hidden files and directories
  -I, --no-ignore                  Do not respect .(git|fd)ignore files
  -s, --case-sensitive             Case-sensitive search (default: smart case)
  -i, --ignore-case                Case-insensitive search (default: smart case)
  -g, --glob                       Glob-based search (default: regular expression)
  -a, --absolute-path              Show absolute instead of relative paths
  -l, --list-details               Use a long listing format with file metadata
  -L, --follow                     Follow symbolic links
  -p, --full-path                  Search full abs. path (default: filename only)
  -d, --max-depth <depth>          Set maximum search depth (default: none)
  -E, --exclude <pattern>          Exclude entries that match the given glob pattern
  -t, --type <filetype>            Filter by type: file (f), directory (d/dir), symlink (l), executable (x), empty (e)
  -e, --extension <ext>            Filter by file extension
  -S, --size <size>                Limit results based on the size of files
      --changed-within <date|dur>  Filter by file modification time (newer than)
      --changed-before <date|dur>  Filter by file modification time (older than)
  -o, --owner <user:group>         Filter by owning user and/or group
      --format <fmt>               Print results according to template
  -x, --exec <cmd>...              Execute a command for each search result
  -X, --exec-batch <cmd>...        Execute a command with all search results at once
  -c, --color <when>               When to use colors [default: auto] [possible values: auto, always, never]
      --hyperlink[=<when>]         Add hyperlinks to output paths [default: never] [possible values: auto, always, never]
      --ignore-contain <name>      Ignore directories containing the named entry
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version
`;
const LONG_HELP = `A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]
          the search pattern which is either a regular expression (default) or a glob pattern (if --glob is used).

  [path]...
          The directory where the filesystem search is rooted (optional). If omitted, search the current working directory.

Options:
  -H, --hidden                     Include hidden directories and files in the search results
  -I, --no-ignore                  Show search results from ignored files and directories
      --no-ignore-vcs              Show results ignored by .gitignore files
      --no-require-git             Respect gitignore files outside git repositories
      --no-ignore-parent           Do not respect ignore files in parent directories
  -u, --unrestricted...            Alias for '--no-ignore --hidden'
  -s, --case-sensitive             Perform a case-sensitive search
  -i, --ignore-case                Perform a case-insensitive search
  -g, --glob                       Perform a glob-based search instead of a regular expression search
      --regex                      Perform a regular-expression based search
  -F, --fixed-strings              Treat the pattern as a literal string
      --and <pattern>              Add additional required search patterns
  -a, --absolute-path              Shows the full path starting from the root
  -l, --list-details               Use a detailed listing format like 'ls -l'
  -L, --follow                     Follow symbolic links
  -p, --full-path                  Match against the full path
  -0, --print0                     Separate search results by the null character
  -d, --max-depth <depth>          Limit directory traversal to a given depth
      --min-depth <depth>          Only show results starting at the given depth
      --exact-depth <depth>        Only show results at the exact given depth
  -E, --exclude <pattern>          Exclude files/directories that match the given glob pattern
      --prune                      Do not traverse into directories that match the search criteria
  -t, --type <filetype>            Filter by type: f, d, l, x, e, s, p, b, c
  -e, --extension <ext>            Filter search results by file extension
  -S, --size <size>                Limit results based on the size of files
      --changed-within <date|dur>  Filter by modification time newer than argument
      --changed-before <date|dur>  Filter by modification time older than argument
  -o, --owner <user:group>         Filter files by their user and/or group
      --format <fmt>               Print results according to template
  -x, --exec <cmd>...              Execute a command for each search result
  -X, --exec-batch <cmd>...        Execute the given command once, with all search results as arguments
      --batch-size <size>          Maximum number of arguments to pass to -X [default: 0]
      --ignore-file <path>         Add a custom ignore-file in '.gitignore' format
  -c, --color <when>               Declare when to use color: auto, always, never [default: auto]
      --hyperlink[=<when>]         Add a terminal hyperlink to a file:// url for each path
      --ignore-contain <name>      Ignore directories containing the named entry
  -j, --threads <num>              Set number of threads to use
      --max-results <count>        Limit the number of search results
  -1                               Alias for '--max-results=1'
  -q, --quiet                      Do not print anything; return 0 if at least one match
      --show-errors                Enable display of filesystem errors
  -C, --base-directory <path>      Change the current working directory
      --path-separator <separator> Set the path separator to use when printing file paths
      --search-path <search-path>  Provide paths to search
      --strip-cwd-prefix[=<when>]  Change ./ prefix behavior
      --one-file-system            Do not descend into a different file system
  -h, --help                       Print help (see a summary with '-h')
  -V, --version                    Print version

Bugs can be reported on GitHub: https://github.com/sharkdp/fd/issues
`;

function die(msg, code = 1) { console.error(msg); process.exit(code); }
function nextArg(argv, i, opt) { if (i + 1 >= argv.length) die(`error: a value is required for '${opt}' but none was supplied`); return argv[i + 1]; }
function splitLong(a) { const p = a.indexOf('='); return p >= 0 ? [a.slice(0, p), a.slice(p + 1)] : [a, null]; }

function parse(argv) {
  const o = { hidden:false, noIgnore:false, noIgnoreVcs:false, requireGit:true, caseMode:'smart', glob:false, fixed:false, absolute:false, list:false, follow:false, fullPath:false, print0:false, maxDepth:Infinity, minDepth:1, excludes:[], types:[], exts:[], size:null, changedWithin:null, changedBefore:null, owners:[], format:null, execs:[], execBatches:[], batchSize:0, color:'auto', hyperlink:'never', ignoreContain:[], maxResults:Infinity, quiet:false, showErrors:false, base:null, pathSep:path.sep, searchPaths:[], stripCwdPrefix:'auto', prune:false, and:[], ignoreFiles:[], oneFileSystem:false, positional:[] };
  for (let i=0;i<argv.length;i++) {
    let a = argv[i];
    if (a === '--') { o.positional.push(...argv.slice(i+1)); break; }
    if (a === '-x' || a === '--exec' || a === '-X' || a === '--exec-batch') {
      const batch = a === '-X' || a === '--exec-batch'; const cmd=[]; i++;
      for (; i<argv.length; i++) { if (argv[i] === ';') break; cmd.push(argv[i]); }
      if (!cmd.length) die(`error: a value is required for '${a}' but none was supplied`);
      (batch ? o.execBatches : o.execs).push(cmd); continue;
    }
    if (a.startsWith('--')) {
      let [opt, val] = splitLong(a);
      const need = () => val !== null ? val : nextArg(argv, i++, opt);
      switch(opt) {
        case '--help': console.log(LONG_HELP); process.exit(0);
        case '--version': console.log(VERSION); process.exit(0);
        case '--hidden': o.hidden=true; break; case '--no-hidden': o.hidden=false; break;
        case '--no-ignore': o.noIgnore=true; break; case '--ignore': o.noIgnore=false; break;
        case '--no-ignore-vcs': o.noIgnoreVcs=true; break; case '--ignore-vcs': o.noIgnoreVcs=false; break;
        case '--no-require-git': o.requireGit=false; break; case '--require-git': o.requireGit=true; break;
        case '--no-ignore-parent': break;
        case '--unrestricted': o.hidden=true; o.noIgnore=true; break;
        case '--case-sensitive': o.caseMode='sensitive'; break; case '--ignore-case': o.caseMode='insensitive'; break;
        case '--glob': o.glob=true; break; case '--regex': o.glob=false; break; case '--fixed-strings': o.fixed=true; break;
        case '--and': o.and.push(need()); break;
        case '--absolute-path': o.absolute=true; break; case '--relative-path': o.absolute=false; break;
        case '--list-details': o.list=true; break;
        case '--follow': o.follow=true; break; case '--no-follow': o.follow=false; break;
        case '--full-path': o.fullPath=true; break;
        case '--print0': o.print0=true; break;
        case '--max-depth': o.maxDepth=parseInt(need(),10); break;
        case '--min-depth': o.minDepth=parseInt(need(),10); break;
        case '--exact-depth': { const d=parseInt(need(),10); o.minDepth=d; o.maxDepth=d; break; }
        case '--exclude': o.excludes.push(need()); break;
        case '--prune': o.prune=true; break;
        case '--type': o.types.push(need()); break;
        case '--extension': o.exts.push(need().replace(/^\./,'')); break;
        case '--size': o.size=parseSize(need()); break;
        case '--changed-within': case '--change-newer-than': case '--newer': case '--changed-after': o.changedWithin=parseTimeArg(need()); break;
        case '--changed-before': case '--change-older-than': case '--older': o.changedBefore=parseTimeArg(need()); break;
        case '--owner': o.owners.push(need()); break;
        case '--format': o.format=need(); break;
        case '--batch-size': o.batchSize=parseInt(need(),10)||0; break;
        case '--ignore-file': o.ignoreFiles.push(need()); break;
        case '--color': o.color=need(); break;
        case '--hyperlink': o.hyperlink=val===null?'auto':val; break;
        case '--ignore-contain': o.ignoreContain.push(need()); break;
        case '--threads': i += val===null ? 1 : 0; break;
        case '--max-results': o.maxResults=parseInt(need(),10); break;
        case '--quiet': case '--has-results': o.quiet=true; o.maxResults=Math.min(o.maxResults,1); break;
        case '--show-errors': o.showErrors=true; break;
        case '--base-directory': o.base=need(); break;
        case '--path-separator': o.pathSep=need(); break;
        case '--search-path': o.searchPaths.push(need()); break;
        case '--strip-cwd-prefix': o.stripCwdPrefix=val===null?'always':val; break;
        case '--one-file-system': case '--mount': case '--xdev': o.oneFileSystem=true; break;
        default: die(`error: unexpected argument '${a}' found`);
      }
    } else if (a.startsWith('-') && a !== '-') {
      for (let j=1;j<a.length;j++) {
        const c=a[j]; const rest=a.slice(j+1); const take=()=>{ if (rest) { j=a.length; return rest; } i++; return nextArg(['',...argv.slice(i)],0,`-${c}`); };
        switch(c) {
          case 'h': console.log(SHORT_HELP); process.exit(0);
          case 'V': console.log(VERSION); process.exit(0);
          case 'H': o.hidden=true; break; case 'I': o.noIgnore=true; break; case 'u': o.hidden=true; o.noIgnore=true; break;
          case 's': o.caseMode='sensitive'; break; case 'i': o.caseMode='insensitive'; break; case 'g': o.glob=true; break; case 'F': o.fixed=true; break;
          case 'a': o.absolute=true; break; case 'l': o.list=true; break; case 'L': o.follow=true; break; case 'p': o.fullPath=true; break; case '0': o.print0=true; break;
          case 'd': o.maxDepth=parseInt(take(),10); break; case 'E': o.excludes.push(take()); break; case 't': o.types.push(take()); break; case 'e': o.exts.push(take().replace(/^\./,'')); break;
          case 'S': o.size=parseSize(take()); break; case 'o': o.owners.push(take()); break; case 'c': o.color=take(); break; case 'j': take(); break;
          case '1': o.maxResults=1; break; case 'q': o.quiet=true; o.maxResults=Math.min(o.maxResults,1); break;
          default: die(`error: unexpected argument '-${c}' found`);
        }
      }
    } else o.positional.push(a);
  }
  if (o.base) process.chdir(o.base);
  let pattern = null, roots = [];
  if (o.searchPaths.length) { roots = o.searchPaths; pattern = o.positional[0] ?? null; }
  else { pattern = o.positional.length ? o.positional[0] : null; roots = o.positional.length > 1 ? o.positional.slice(1) : ['.']; }
  o.pattern = pattern;
  o.roots = roots;
  if (!Number.isFinite(o.maxDepth) || isNaN(o.maxDepth)) o.maxDepth = Infinity;
  if (isNaN(o.minDepth)) o.minDepth = 1;
  return o;
}

function parseSize(s) {
  const m = /^([+-]?)(\d+(?:\.\d+)?)([a-zA-Z]*)$/.exec(s); if (!m) die(`error: invalid value '${s}' for '--size <size>'`);
  const mult = {b:1,'':1,k:1000,m:1e6,g:1e9,t:1e12,ki:1024,mi:1048576,gi:1073741824,ti:1099511627776}[m[3].toLowerCase()];
  if (!mult) die(`error: invalid size unit '${m[3]}'`); return {op:m[1]||'=', n:Number(m[2])*mult};
}
function parseTimeArg(s) {
  if (/^@\d+$/.test(s)) return new Date(Number(s.slice(1))*1000).getTime();
  const dur = /^(\d+(?:\.\d+)?)(ns|ms|sec|secs|second|seconds|s|min|mins|minute|minutes|h|hr|hour|hours|d|day|days|w|week|weeks|month|months|y|year|years)$/i.exec(s);
  if (dur) { const n=Number(dur[1]); const u=dur[2].toLowerCase(); let ms=1000; if(u.startsWith('ms'))ms=1; else if(u==='ns')ms=0.000001; else if(u.startsWith('min'))ms=60000; else if(u==='h'||u.startsWith('hr')||u.startsWith('hour'))ms=3600000; else if(u==='d'||u.startsWith('day'))ms=86400000; else if(u==='w'||u.startsWith('week'))ms=604800000; else if(u.startsWith('month'))ms=2629800000; else if(u==='y'||u.startsWith('year'))ms=31557600000; return Date.now()-n*ms; }
  let t = Date.parse(s.includes('T') ? s : s.replace(' ', 'T'));
  if (isNaN(t) && /^\d{4}-\d{2}-\d{2}$/.test(s)) t = Date.parse(s+'T00:00:00');
  if (isNaN(t)) die(`error: invalid date or duration '${s}'`); return t;
}

function smartInsensitive(pattern, o) { if (o.caseMode === 'insensitive') return true; if (o.caseMode === 'sensitive') return false; return !/[A-Z]/.test(pattern || '') && !o.and.some(p=>/[A-Z]/.test(p)); }
function globToRegex(glob, full=false) {
  let out=''; for (let i=0;i<glob.length;i++) { const ch=glob[i];
    if (ch==='*') { if (glob[i+1]==='*') { out += '.*'; i++; } else out += full ? '[^]*' : '[^/]*'; }
    else if (ch==='?') out += full ? '.' : '[^/]';
    else if (ch==='[') { let j=i+1; while(j<glob.length && glob[j]!==']') j++; if(j<glob.length){ out += glob.slice(i,j+1); i=j; } else out+='\\['; }
    else out += ch.replace(/[\\^$+?.()|{}]/g,'\\$&');
  } return new RegExp('^'+out+'$');
}
function makeMatcher(pattern, o) {
  if (pattern == null || pattern === '') return () => true;
  const insensitive = smartInsensitive(pattern, o); const flags = insensitive ? 'i' : '';
  if (o.fixed) { const p = insensitive ? pattern.toLowerCase() : pattern; return s => (insensitive?s.toLowerCase():s).includes(p); }
  if (o.glob) { const re = globToRegex(pattern, o.fullPath); return s => new RegExp(re.source, flags).test(s); }
  let re; try { re = new RegExp(pattern, flags); } catch(e) { die(`error: regex parse error:\n    ${pattern}\n    ${e.message}`); }
  return s => re.test(s);
}
function matchOnePattern(pattern, s, o) { const oo={...o, pattern}; return makeMatcher(pattern, oo)(s); }

function hasGit(dir) { let d=path.resolve(dir); while(true){ if(fs.existsSync(path.join(d,'.git'))) return true; const p=path.dirname(d); if(p===d) return false; d=p; } }
function loadIgnoreLines(file) { try { return fs.readFileSync(file,'utf8').split(/\r?\n/).map(l=>l.trim()).filter(l=>l && !l.startsWith('#')); } catch { return []; } }
function ignoreMatcher(lines) {
  const pats = lines.map(raw => { let neg=false, p=raw; if(p[0]==='!'){neg=true;p=p.slice(1);} p=p.replace(/^\//,''); const dirOnly=p.endsWith('/'); if(dirOnly)p=p.slice(0,-1); return {neg,dirOnly,p,re:globToRegex(p.includes('/')?p:'**/'+p, true), exact:globToRegex(p,true), base:globToRegex(p,false)}; });
  return (rel, name, isDir) => { let ignored=false; for(const pat of pats){ if(pat.dirOnly&&!isDir) continue; if(pat.base.test(name)||pat.exact.test(rel)||pat.re.test(rel)) ignored=!pat.neg; } return ignored; };
}
function makeGlobalIgnores(o, roots) {
  let lines=[];
  if (!o.noIgnore) {
    for (const f of o.ignoreFiles) lines.push(...loadIgnoreLines(f));
    const home=process.env.HOME; const xdg=process.env.XDG_CONFIG_HOME;
    if (home||xdg) lines.push(...loadIgnoreLines(path.join(xdg||path.join(home,'.config'),'fd','ignore')));
  }
  return ignoreMatcher(lines);
}

function classify(st, lst) {
  const s = lst || st;
  if (s.isSymbolicLink()) return 'l'; if (st.isDirectory()) return 'd'; if (st.isFile()) return 'f'; if (st.isSocket()) return 's'; if (st.isFIFO()) return 'p'; if (st.isBlockDevice()) return 'b'; if (st.isCharacterDevice()) return 'c'; return 'o';
}
function isEmpty(abs, st, kind) { try { if(kind==='d') return fs.readdirSync(abs).length===0; if(kind==='f') return st.size===0; } catch{} return false; }
function typeOk(abs, st, lst, o) {
  if (!o.types.length) return true; const kind=classify(st,lst); const norm=o.types.map(t=>({file:'f',f:'f',dir:'d',directory:'d',d:'d',symlink:'l',l:'l',executable:'x',x:'x',empty:'e',e:'e',socket:'s',s:'s',pipe:'p',p:'p','block-device':'b',b:'b','char-device':'c',c:'c'}[t]||t));
  const wantsEmpty=norm.includes('e'), wantsExec=norm.includes('x'); const normal=norm.filter(t=>t!=='e'&&t!=='x');
  let ok = normal.length ? normal.includes(kind) : true;
  if (wantsExec) ok = ok && kind==='f' && (st.mode & 0o111);
  if (wantsEmpty) { const limit = normal.length ? normal.includes(kind) : (kind==='f'||kind==='d'); ok = ok && limit && isEmpty(abs, st, kind); }
  return !!ok;
}
function ownerOk(st, specs) { if(!specs.length) return true; return specs.some(spec=>{ let [u,g]=spec.split(':'); const test=(val, actual)=> !val || (val[0]==='!' ? String(actual)!==val.slice(1) : String(actual)===val); return test(u,st.uid)&&test(g,st.gid); }); }
function sizeOk(st, sz) { if(!sz) return true; if(!st.isFile()) return false; if(sz.op==='+') return st.size>=sz.n; if(sz.op==='-') return st.size<=sz.n; return st.size===sz.n; }
function extOk(name, o) { if(!o.exts.length) return true; const ext=path.extname(name).replace(/^\./,''); const insensitive = o.caseMode !== 'sensitive'; return o.exts.some(e => insensitive ? ext.toLowerCase()===e.toLowerCase() : ext===e); }

function displayPath(abs, root, rel, explicitRoot, o) {
  let s;
  if (o.absolute || path.isAbsolute(root)) s = abs;
  else if (root === '.') s = (explicitRoot ? './' : '') + rel;
  else if (root.startsWith('./')) s = './' + path.join(root.slice(2), rel);
  else s = path.join(root, rel);
  if (s === '') s = '.';
  s = s.split(path.sep).join(o.pathSep);
  return s;
}
function addDirSlash(s, kind, o) { return kind==='d' && !s.endsWith(o.pathSep) ? s + o.pathSep : s; }
function shouldPrefixExec(s,o){ if(s.startsWith('/')||s.startsWith('./')||s.startsWith('../'))return s; const need = o.stripCwdPrefix==='never' || (o.stripCwdPrefix==='auto' && (o.print0||o.execs.length||o.execBatches.length)); return need ? './'+s : s; }

function search(o) {
  const results=[]; const explicitRoot = !(o.searchPaths.length) && o.positional.length > 1; const globalIgnore=makeGlobalIgnores(o,o.roots); const matcher=makeMatcher(o.pattern,o); const excludeMatchers=o.excludes.map(p=>ignoreMatcher([p]));
  for (const root0 of o.roots) {
    const root=root0; const rootAbs=path.resolve(root); const gitOk=!o.requireGit || hasGit(rootAbs); const startDev = (()=>{try{return fs.statSync(rootAbs).dev}catch{return null}})();
    const walk=(dirAbs, relDir, depth, localLines)=>{
      let entries; try { entries=fs.readdirSync(dirAbs,{withFileTypes:true}).sort((a,b)=>a.name < b.name ? -1 : (a.name > b.name ? 1 : 0)); } catch(e){ if(o.showErrors) console.error(e.message); return; }
      let lines=localLines.slice(); if(!o.noIgnore){ lines.push(...loadIgnoreLines(path.join(dirAbs,'.ignore')), ...loadIgnoreLines(path.join(dirAbs,'.fdignore'))); if(!o.noIgnoreVcs && gitOk) lines.push(...loadIgnoreLines(path.join(dirAbs,'.gitignore'))); }
      const localIgnore=ignoreMatcher(lines);
      for (const ent of entries) {
        const name=ent.name; const rel=relDir ? path.join(relDir,name) : name; const abs=path.join(dirAbs,name);
        let lst, st; try { lst=fs.lstatSync(abs); st=o.follow ? fs.statSync(abs) : lst; } catch(e){ if(o.showErrors) console.error(e.message); continue; }
        const kind=classify(st,lst); const isDir=kind==='d';
        if (!o.hidden && name.startsWith('.')) continue;
        if (!o.noIgnore && (globalIgnore(rel,name,isDir) || localIgnore(rel,name,isDir))) continue;
        if (excludeMatchers.some(m=>m(rel,name,isDir))) continue;
        if (isDir && o.ignoreContain.some(n=>fs.existsSync(path.join(abs,n)))) continue;
        if (o.oneFileSystem && startDev!==null && st.dev!==startDev) continue;
        let shown = displayPath(abs, root, rel, explicitRoot, o); shown = addDirSlash(shown, kind, o);
        const matchTarget = o.fullPath ? path.resolve(abs) : name;
        const matches = matcher(matchTarget) && o.and.every(p=>matchOnePattern(p,matchTarget,o));
        const filters = depth>=o.minDepth && typeOk(abs,st,lst,o) && extOk(name,o) && sizeOk(st,o.size) && (!o.changedWithin || st.mtimeMs > o.changedWithin) && (!o.changedBefore || st.mtimeMs < o.changedBefore) && ownerOk(st,o.owners);
        if (matches && filters) { results.push({abs, rel, shown, kind, st, name}); if(results.length>=o.maxResults) return true; }
        if (isDir && depth < o.maxDepth && !(o.prune && matches)) { if (walk(abs, rel, depth+1, lines)) return true; }
      }
      return false;
    };
    walk(rootAbs, '', 1, []); if(results.length>=o.maxResults) break;
  }
  return results;
}

function noExt(p){ const e=path.extname(p); return e ? p.slice(0,-e.length) : p; }
function substArg(arg, r, allMode=false) {
  const parent = path.dirname(r.shown)==='.' ? '.' : path.dirname(r.shown);
  const vals = {'{}':r.shown,'{/}':path.basename(r.shown.replace(/\/$/,'')),'{//}':parent,'{.}':noExt(r.shown),'{/.}':noExt(path.basename(r.shown.replace(/\/$/,'')))};
  let s=arg.replace(/\{\{/g,'\0L').replace(/\}\}/g,'\0R');
  for (const [k,v] of Object.entries(vals)) s=s.split(k).join(v);
  return s.replace(/\0L/g,'{').replace(/\0R/g,'}');
}
function hasPlaceholder(args){ return args.some(a=>/\{\}|\{\/\}|\{\/\/\}|\{\.\}|\{\/\.\}/.test(a)); }
function runExecs(results,o){
  for(const cmd of o.execs){ const base=hasPlaceholder(cmd)?cmd:cmd.concat(['{}']); for(const r0 of results){ const r={...r0, shown:shouldPrefixExec(r0.shown,o)}; const args=base.map(a=>substArg(a,r)); const res=cp.spawnSync(args[0],args.slice(1),{stdio:'inherit'}); if(res.status) process.exit(res.status||1); if(o.print0) process.stdout.write('\0'); } }
  for(const cmd of o.execBatches){ const base=hasPlaceholder(cmd)?cmd:cmd.concat(['{}']); const batchSize=o.batchSize||results.length||1; for(let i=0;i<results.length;i+=batchSize){ const batch=results.slice(i,i+batchSize); const final=[]; for(const a of base){ if(/\{\}|\{\/\}|\{\/\/\}|\{\.\}|\{\/\.\}/.test(a)){ for(const r0 of batch){ const r={...r0, shown:shouldPrefixExec(r0.shown,o)}; final.push(substArg(a,r)); } } else final.push(a); } const res=cp.spawnSync(final[0],final.slice(1),{stdio:'inherit'}); if(res.status) process.exit(res.status||1); } }
}
function formatLine(fmt,r){ return substArg(fmt,r); }
function colorize(s,r,o){ if(o.color!=='always' || process.env.NO_COLOR) return s; const code = r.kind==='d'?'34':(r.kind==='l'?'36':((r.st.mode&0o111)?'32':'0')); return `\x1b[${code}m${s}\x1b[0m`; }
function hyperlink(s,r,o){ if(o.hyperlink!=='always') return s; return `\x1b]8;;file://${r.abs}\x1b\\${s}\x1b]8;;\x1b\\`; }

function main(){ const o=parse(process.argv.slice(2)); const results=search(o); if(o.quiet) process.exit(results.length?0:1); if(o.list){ const args=results.map(r=>r.shown); if(args.length) { const res=cp.spawnSync('ls',['-ld',...args],{stdio:'inherit'}); process.exit(res.status||0); } return; } if(o.execs.length||o.execBatches.length){ runExecs(results,o); return; }
  const sep=o.print0?'\0':'\n'; for(const r of results){ let out=o.format!==null?formatLine(o.format,r):r.shown; if(o.print0) out=shouldPrefixExec(out,o); out=colorize(out,r,o); out=hyperlink(out,r,o); process.stdout.write(out+sep); }
}
main();
