#!/usr/bin/env node
'use strict';

const fs = require('fs');

const VERSION = '0.1.5';
const RESET = '\x1b[0m';

const HELP_LONG = `diffr ${VERSION}
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...
            Configure color settings for console ouput.

            There are four faces to customize:
            +----------------+--------------+----------------+
            |  line prefix   |      +       |       -        |
            +----------------+--------------+----------------+
            | common segment |    added     |    removed     |
            | unique segment | refine-added | refine-removed |
            +----------------+--------------+----------------+

            The customization allows
            - to change the foreground or background color;
            - to set or unset the attributes 'bold', 'intense', 'underline';
            - to clear all attributes.

            Customization is done passing a color_spec argument.
            This flag may be provided multiple times.

            The syntax is the following:

            color_spec = face-name + ':' + attributes
            attributes = attribute
                       | attribute + ':' + attributes
            attribute  = ('foreground' | 'background') + ':' + color
                       | (<empty> | 'no') + font-flag
                       | 'none'
            font-flag  = 'italic'
                       | 'bold'
                       | 'intense'
                       | 'underline'
            color      = 'none'
                       | [0-255]
                       | [0-255] + ',' + [0-255] + ',' + [0-255]
                       | ('black', 'blue', 'green', 'red',
                          'cyan', 'magenta', 'yellow', 'white')

            For example, the color_spec

                'refine-added:background:blue:bold'

            sets the color of unique added segments with
            a blue background, written with a bold font.

        --line-numbers <compact|aligned>
            Display line numbers. Style is optional.
            When style = 'compact', take as little width as possible.
            When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]

    -h, --help
            Prints help information

    -V, --version
            Prints version information
`;

const HELP_SHORT = `diffr ${VERSION}
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...    Configure color settings.
        --line-numbers              Display line numbers.
    -h, --help                      Prints help information
    -V, --version                   Prints version information
`;

const COLOR_NAMES = {
  black: 30, red: 31, green: 32, yellow: 33,
  blue: 34, magenta: 35, cyan: 36, white: 37,
};
const BG_NAMES = {
  black: 40, red: 41, green: 42, yellow: 43,
  blue: 44, magenta: 45, cyan: 46, white: 47,
};
const FLAG_CODES = { italic: 3, bold: 1, intense: 1, underline: 4 };
const NO_FLAG_CODES = { italic: 23, bold: 22, intense: 22, underline: 24 };

function defaultFaces() {
  return {
    added: ['32'],
    removed: ['31'],
    'refine-added': ['1', '38;2;255;255;255', '42'],
    'refine-removed': ['1', '38;2;255;255;255', '41'],
  };
}

function die(msg, code = 255) {
  process.stderr.write(msg + '\n');
  process.exit(code);
}

function parseArgs(argv) {
  const opts = { lineNumbers: false, lineStyle: 'compact', faces: defaultFaces() };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '-V' || arg === '--version') {
      process.stdout.write(`diffr ${VERSION}\n`);
      process.exit(0);
    } else if (arg === '--help') {
      process.stdout.write(HELP_LONG);
      process.exit(0);
    } else if (arg === '-h') {
      process.stdout.write(HELP_SHORT);
      process.exit(0);
    } else if (arg === '--line-numbers') {
      opts.lineNumbers = true;
      if (i + 1 < argv.length && !argv[i + 1].startsWith('-')) {
        const style = argv[++i];
        if (!['compact', 'aligned', 'fixed'].includes(style)) {
          die(`unexpected line number style: got '${style}', expected aligned|compact|fixed`);
        }
        opts.lineStyle = style;
      }
    } else if (arg === '--colors') {
      if (i + 1 >= argv.length) die('missing color spec');
      applyColorSpec(opts.faces, argv[++i]);
    } else {
      process.stderr.write(`bad argument: '${arg}'\n`);
      process.stdout.write(HELP_SHORT);
      process.exit(2);
    }
  }
  return opts;
}

function colorCode(kind, value) {
  if (value === 'none') return kind === 'foreground' ? '39' : '49';
  if (/^\d+$/.test(value)) return `${kind === 'foreground' ? 38 : 48};5;${Number(value)}`;
  const rgb = value.match(/^(\d+),(\d+),(\d+)$/);
  if (rgb) return `${kind === 'foreground' ? 38 : 48};2;${rgb[1]};${rgb[2]};${rgb[3]}`;
  const map = kind === 'foreground' ? COLOR_NAMES : BG_NAMES;
  if (Object.prototype.hasOwnProperty.call(map, value)) return String(map[value]);
  die(`unexpected color: '${value}'`);
}

function applyColorSpec(faces, spec) {
  const parts = spec.split(':');
  const face = parts.shift();
  if (!['added', 'removed', 'refine-added', 'refine-removed'].includes(face)) {
    die(`unexpected face name: got '${face}', expected added|refine-added|removed|refine-removed`);
  }
  let cur = faces[face].slice();
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i];
    if (p === 'none') {
      cur = [];
    } else if (p === 'foreground' || p === 'background') {
      if (i + 1 >= parts.length) die(`missing ${p} color`);
      cur.push(colorCode(p, parts[++i]));
    } else if (Object.prototype.hasOwnProperty.call(FLAG_CODES, p)) {
      cur.push(String(FLAG_CODES[p]));
    } else if (p.startsWith('no') && Object.prototype.hasOwnProperty.call(NO_FLAG_CODES, p.slice(2))) {
      cur.push(String(NO_FLAG_CODES[p.slice(2)]));
    } else {
      die(`unexpected attribute: '${p}'`);
    }
  }
  faces[face] = cur;
}

function styleSeq(style) {
  return style.map(s => `\x1b[${s}m`).join('');
}

function seg(text, style) {
  return RESET + styleSeq(style) + text + RESET;
}

function tokenize(s) {
  return s.match(/([A-Za-z0-9_]+|\s+|[^\sA-Za-z0-9_]+)/g) || [];
}

function lcsPairs(a, b) {
  const n = a.length, m = b.length;
  const dp = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const pairs = [];
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) {
      pairs.push([i, j]); i++; j++;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      i++;
    } else {
      j++;
    }
  }
  return pairs;
}

function refinedParts(oldText, newText) {
  const a = tokenize(oldText), b = tokenize(newText);
  const pairs = lcsPairs(a, b);
  const keepA = new Set(pairs.map(p => p[0]));
  const keepB = new Set(pairs.map(p => p[1]));
  return {
    oldParts: mergeParts(a.map((t, i) => [t, keepA.has(i)])),
    newParts: mergeParts(b.map((t, i) => [t, keepB.has(i)])),
  };
}

function mergeParts(parts) {
  const merged = [];
  for (const [text, common] of parts) {
    const last = merged[merged.length - 1];
    if (last && last[1] === common) last[0] += text;
    else merged.push([text, common]);
  }
  return merged;
}

function parseHunk(line) {
  const m = line.match(/^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/);
  if (!m) return null;
  return { oldNo: Number(m[1]), newNo: Number(m[3]) };
}

function numberPrefix(kind, oldNo, newNo, opts) {
  if (!opts.lineNumbers) return '';
  const oldS = oldNo == null ? '' : String(oldNo);
  const newS = newNo == null ? '' : String(newNo);
  if (opts.lineStyle === 'aligned' || opts.lineStyle === 'fixed') {
    return `${oldS.padStart(2)} ${newS.padStart(2)}\t`;
  }
  if (kind === '-') return `${oldS}  `;
  if (kind === '+') return `${' '.repeat(oldS.length || 2)}${newS}`;
  return `${oldS} ${newS}`;
}

function renderMinus(content, oldNo, opts, compareText) {
  const face = opts.faces.removed, refine = opts.faces['refine-removed'];
  const n = numberPrefix('-', oldNo, null, opts);
  let out = n ? RESET + styleSeq(face) + n + RESET : '';
  out += seg('-', face);
  if (compareText == null) {
    out += seg(content, refine) + seg('', face);
    return out;
  }
  const parts = refinedParts(content, compareText).oldParts;
  for (const [t, common] of parts) out += seg(t, common ? face : refine);
  out += seg('', face);
  return out;
}

function renderPlus(content, newNo, opts, compareText) {
  const face = opts.faces.added, refine = opts.faces['refine-added'];
  const n = numberPrefix('+', null, newNo, opts);
  let out = n ? RESET + styleSeq(face) + n + RESET : '';
  out += seg('+', face);
  if (compareText == null) {
    out += seg(content, refine) + seg('', face);
    return out;
  }
  const parts = refinedParts(compareText, content).newParts;
  for (const [t, common] of parts) out += seg(t, common ? face : refine);
  out += seg('', face);
  return out;
}

function renderPlain(line, oldNo, newNo, opts) {
  const p = numberPrefix(' ', oldNo, newNo, opts);
  return (p ? p + RESET : RESET) + line + RESET;
}

function processDiff(input, opts) {
  const hasFinalNewline = input.endsWith('\n');
  const lines = input.split(/\n/);
  if (hasFinalNewline) lines.pop();
  const out = [];
  let oldNo = null, newNo = null;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const h = parseHunk(line);
    if (h) {
      oldNo = h.oldNo; newNo = h.newNo;
      out.push(renderPlain(line, null, null, { ...opts, lineNumbers: false }));
      continue;
    }
    if (oldNo != null && line.startsWith('-') && !line.startsWith('---')) {
      const minus = [];
      const plus = [];
      while (i < lines.length && lines[i].startsWith('-') && !lines[i].startsWith('---')) minus.push(lines[i].slice(1)), i++;
      while (i < lines.length && lines[i].startsWith('+') && !lines[i].startsWith('+++')) plus.push(lines[i].slice(1)), i++;
      i--;
      const max = Math.max(minus.length, plus.length);
      for (let k = 0; k < max; k++) {
        if (k < minus.length) out.push(renderMinus(minus[k], oldNo++, opts, plus[k] ?? null));
        if (k < plus.length) out.push(renderPlus(plus[k], newNo++, opts, minus[k] ?? null));
      }
      continue;
    }
    if (oldNo != null && line.startsWith('+') && !line.startsWith('+++')) {
      out.push(renderPlus(line.slice(1), newNo++, opts, null));
      continue;
    }
    if (oldNo != null && (line.startsWith(' ') || line === '')) {
      out.push(renderPlain(line, oldNo++, newNo++, opts));
      continue;
    }
    out.push(renderPlain(line, null, null, { ...opts, lineNumbers: false }));
  }
  return out.join('\n') + (hasFinalNewline ? '\n' : '');
}

const opts = parseArgs(process.argv.slice(2));
const input = fs.readFileSync(0, 'utf8');
process.stdout.write(processDiff(input, opts));
