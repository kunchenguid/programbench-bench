#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const usage = (prog) => `Usage of ${prog}:
  -abspath
    \tprint absolute paths to files
  -asserts
    \tif true, check for ignored type assertion results
  -blank
    \tif true, check for errors assigned to blank identifier
  -exclude string
    \tPath to a file containing a list of functions to exclude from checking
  -excludeonly
    \tUse only excludes from -exclude file
  -ignore value
    \t[deprecated] comma-separated list of pairs of the form pkg:regex
    \t            the regex is used to ignore names within pkg.
  -ignoregenerated
    \tif true, checking of files with generated code is disabled
  -ignorepkg string
    \tcomma-separated list of package paths to ignore
  -ignoretests
    \tif true, checking of _test.go files is disabled
  -mod string
    \tmodule download mode to use: readonly or vendor. See 'go help modules' for more.
  -tags value
    \tcomma or space-separated list of build tags to include
  -verbose
    \tproduce more verbose logging
`;

const knownErrorFuncs = {
  fmt: new Set('Print Printf Println Fprint Fprintf Fprintln'.split(' ')),
  os: new Set('Chdir Chmod Chown Chtimes CopyFS DirFS Getwd Hostname Link Mkdir MkdirAll MkdirTemp Open OpenFile Pipe ReadFile Readlink Remove RemoveAll Rename Symlink Truncate WriteFile Create CreateTemp Lchown Setenv Unsetenv'.split(' ')),
  ioutil: new Set('ReadAll ReadFile WriteFile TempDir TempFile'.split(' ')),
  io: new Set('Copy CopyBuffer CopyN ReadAll ReadAtLeast ReadFull WriteString'.split(' ')),
  net: new Set('Dial DialIP DialTCP DialUDP DialUnix FileConn FileListener FilePacketConn Listen ListenIP ListenMulticastUDP ListenPacket ResolveIPAddr ResolveTCPAddr ResolveUDPAddr ResolveUnixAddr'.split(' ')),
  http: new Set('Get Head Post PostForm NewRequest NewRequestWithContext ReadRequest ReadResponse Serve ListenAndServe ListenAndServeTLS ServeContent ServeFile'.split(' ')),
  json: new Set('Compact HTMLEscape Indent Marshal MarshalIndent NewDecoder NewEncoder Unmarshal Valid'.split(' ')),
  xml: new Set('Marshal MarshalIndent Unmarshal'.split(' ')),
  binary: new Set('Read Write'.split(' ')),
  bufio: new Set('ReadString ReadBytes WriteTo'.split(' ')),
  strconv: new Set('Atoi ParseBool ParseComplex ParseFloat ParseInt ParseUint Unquote UnquoteChar'.split(' ')),
  regexp: new Set('Compile CompilePOSIX'.split(' ')),
  template: new Set('ParseFiles ParseGlob New'.split(' ')),
  url: new Set('Parse ParseRequestURI QueryUnescape PathUnescape'.split(' ')),
  time: new Set('Parse ParseDuration LoadLocation'.split(' ')),
  gzip: new Set('NewReader'.split(' ')),
  zlib: new Set('NewReader NewReaderDict'.split(' ')),
  csv: new Set('NewReader NewWriter'.split(' ')),
  sql: new Set('Open'.split(' ')),
};

const defaultIgnoredPkgs = new Set(['fmt']);
const builtins = new Set(['append', 'cap', 'clear', 'close', 'complex', 'copy', 'delete', 'imag', 'len', 'make', 'max', 'min', 'new', 'panic', 'print', 'println', 'real', 'recover']);
const keywords = new Set(['if', 'for', 'switch', 'select', 'return', 'func', 'go', 'defer', 'range']);
const commonErrorMethods = new Set('Close Write WriteAt WriteTo Read ReadAt ReadFrom Flush Sync Seek Chdir Chmod Chown Truncate Stat Readdir Readdirnames Encode Decode Scan Commit Rollback Ping Exec Query Run Start Wait Output CombinedOutput Listen Serve Shutdown SetDeadline SetReadDeadline SetWriteDeadline'.split(' '));

function parseArgs(argv) {
  const prog = process.env.ERRCHECK_PROG || argv[1];
  const opts = { abspath: false, asserts: false, blank: false, exclude: '', excludeonly: false, ignore: [], ignoregenerated: false, ignorepkg: '', ignoretests: false, mod: '', tags: [], verbose: false, pkgs: [] };
  const bools = new Set(['abspath', 'asserts', 'blank', 'excludeonly', 'ignoregenerated', 'ignoretests', 'verbose']);
  const vals = new Set(['exclude', 'ignore', 'ignorepkg', 'mod', 'tags']);
  for (let i = 2; i < argv.length; i++) {
    let a = argv[i];
    if (a === '-h' || a === '--help') {
      process.stderr.write(usage(prog));
      process.exit(2);
    }
    if (!a.startsWith('-') || a === '-') {
      opts.pkgs.push(a);
      continue;
    }
    let name = a.replace(/^-+/, '');
    let val = null;
    const eq = name.indexOf('=');
    if (eq >= 0) {
      val = name.slice(eq + 1);
      name = name.slice(0, eq);
    }
    if (bools.has(name)) {
      opts[name] = val == null ? true : val !== 'false';
    } else if (vals.has(name)) {
      if (val == null) {
        if (i + 1 >= argv.length) {
          console.error(`flag needs an argument: -${name}`);
          process.stderr.write(usage(prog));
          process.exit(2);
        }
        val = argv[++i];
      }
      if (name === 'ignore') opts.ignore.push(val);
      else if (name === 'tags') opts.tags.push(val);
      else opts[name] = val;
    } else {
      console.error(`flag provided but not defined: -${name}`);
      process.stderr.write(usage(prog));
      process.exit(2);
    }
  }
  if (!opts.pkgs.length) opts.pkgs.push('.');
  return opts;
}

function walk(dir, out) {
  let ents;
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of ents) {
    if (e.name === '.git' || e.name === 'vendor' || e.name === 'node_modules') continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (e.isFile() && e.name.endsWith('.go')) out.push(p);
  }
}

function collectFiles(args, opts) {
  const files = [];
  for (const arg of args) {
    if (arg === 'all') {
      walk(process.cwd(), files);
      continue;
    }
    if (arg.endsWith('/...')) {
      const base = arg.slice(0, -4) || '.';
      walk(path.resolve(base), files);
      continue;
    }
    const p = path.resolve(arg);
    let st;
    try { st = fs.statSync(p); } catch {
      console.error(`error: failed to check packages: ${arg}: no such file or directory`);
      process.exit(2);
    }
    if (st.isDirectory()) {
      for (const f of fs.readdirSync(p)) if (f.endsWith('.go')) files.push(path.join(p, f));
    } else if (st.isFile() && p.endsWith('.go')) files.push(p);
  }
  return files.filter((f) => !(opts.ignoretests && f.endsWith('_test.go')));
}

function isGenerated(src) {
  return src.split(/\r?\n/).slice(0, 20).some((l) => /Code generated .* DO NOT EDIT\./.test(l));
}

function buildableByTags(file, src, opts) {
  const active = new Set(['linux', 'unix', 'amd64']);
  for (const t of opts.tags.join(',').split(/[,\s]+/).filter(Boolean)) active.add(t);
  const base = path.basename(file, '.go').split('_').slice(1);
  for (const part of base) {
    if (!part || part === 'test') continue;
    if (/^(linux|darwin|windows|freebsd|openbsd|netbsd|dragonfly|solaris|aix|android|ios|js|wasip1)$/.test(part) && !active.has(part)) return false;
  }
  for (const line of src.split(/\r?\n/).slice(0, 30)) {
    const m = line.match(/^\s*\/\/go:build\s+(.+)$/);
    if (!m) continue;
    const expr = m[1].replace(/\b[A-Za-z_]\w*\b/g, (x) => active.has(x) ? 'true' : 'false').replace(/&&|\|\||!|\(|\)|\s+/g, (x) => x);
    try { return !!Function(`return (${expr})`)(); } catch { return true; }
  }
  return true;
}

function maskLine(line) {
  let out = '', quote = null, esc = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i], n = line[i + 1];
    if (!quote && c === '/' && n === '/') { out += ' '.repeat(line.length - i); break; }
    if (!quote && c === '/' && n === '*') {
      const j = line.indexOf('*/', i + 2);
      const end = j < 0 ? line.length - 1 : j + 1;
      out += ' '.repeat(end - i + 1); i = end; continue;
    }
    if (quote) {
      out += ' ';
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === quote) quote = null;
      continue;
    }
    if (c === '"' || c === '\'' || c === '`') { quote = c; out += ' '; continue; }
    out += c;
  }
  return out;
}

function parseImports(src) {
  const imports = {};
  const add = (alias, imp) => {
    if (alias === '_' || alias === '.') return;
    if (!alias) alias = path.basename(imp);
    if (alias === 'http' && imp === 'net/http') alias = 'http';
    imports[alias] = imp;
  };
  const reBlock = /import\s*\(([\s\S]*?)\)/g;
  let m;
  while ((m = reBlock.exec(src))) {
    for (const l of m[1].split(/\r?\n/)) {
      const mm = l.replace(/\/\/.*$/, '').match(/^\s*(?:(\w+)\s+)?"([^"]+)"/);
      if (mm) add(mm[1], mm[2]);
    }
  }
  const reOne = /^\s*import\s+(?:(\w+)\s+)?"([^"]+)"/gm;
  while ((m = reOne.exec(src))) add(m[1], m[2]);
  return imports;
}

function returnsError(ret) {
  return /\berror\b/.test(ret || '');
}

function collectLocalFuncs(files, opts) {
  const names = new Set();
  const methods = new Set();
  for (const f of files) {
    const src = fs.readFileSync(f, 'utf8');
    if (opts.ignoregenerated && isGenerated(src)) continue;
    if (!buildableByTags(f, src, opts)) continue;
    const flat = src.replace(/\r/g, '');
    const re = /func\s+(?:\(([^)]*)\)\s*)?([A-Za-z_]\w*)\s*\([^)]*\)\s*([^{\n]*)/g;
    let m;
    while ((m = re.exec(flat))) {
      if (!returnsError(m[3])) continue;
      if (m[1]) methods.add(m[2]);
      else names.add(m[2]);
    }
  }
  return { names, methods };
}

function loadExcludes(file) {
  const set = new Set();
  if (!file) return set;
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch (e) {
    console.error(`Could not read exclude file: open ${file}: no such file or directory`);
    process.exit(2);
  }
  for (const raw of text.split(/\r?\n/)) {
    const s = raw.trim();
    if (!s || s.startsWith('//')) continue;
    set.add(s.replace(/\([^)]*\)$/, ''));
  }
  return set;
}

function ignoredByFlags(full, pkg, name, opts, excludes) {
  if (excludes.has(full) || excludes.has(`${pkg}.${name}`) || excludes.has(name)) return true;
  const ignoredPkgs = new Set((opts.ignorepkg || '').split(',').map((s) => s.trim()).filter(Boolean));
  if (!opts.excludeonly && !opts.ignore.some((x) => x.startsWith('fmt:')) && defaultIgnoredPkgs.has(pkg)) return true;
  if (ignoredPkgs.has(pkg)) return true;
  for (const entry of opts.ignore.join(',').split(',')) {
    if (!entry) continue;
    const ix = entry.indexOf(':');
    const epkg = ix >= 0 ? entry.slice(0, ix) : '';
    const rx = ix >= 0 ? entry.slice(ix + 1) : entry;
    if (epkg && epkg !== pkg) continue;
    try { if (new RegExp(rx).test(name)) return true; } catch {}
  }
  return false;
}

function callReturnsError(call, imports, local, opts, excludes) {
  if (builtins.has(call.name) || keywords.has(call.name)) return false;
  if (call.qual) {
    const imp = imports[call.qual] || call.qual;
    const base = imp === 'net/http' ? 'http' : path.basename(imp);
    const known = knownErrorFuncs[base];
    const full = `${imp}.${call.name}`;
    if (ignoredByFlags(full, imp, call.name, opts, excludes) || ignoredByFlags(`${call.qual}.${call.name}`, call.qual, call.name, opts, excludes) || ignoredByFlags(`${base}.${call.name}`, base, call.name, opts, excludes)) return false;
    if (known && known.has(call.name)) return true;
    if (local.methods.has(call.name)) return true;
    if (!imports[call.qual] && commonErrorMethods.has(call.name)) return true;
    return false;
  }
  if (ignoredByFlags(call.name, '', call.name, opts, excludes)) return false;
  return local.names.has(call.name) || local.methods.has(call.name);
}

function findCalls(masked) {
  const calls = [];
  const re = /(?:\b([A-Za-z_]\w*)\s*\.\s*)?\b([A-Za-z_]\w*)\s*\(/g;
  let m;
  while ((m = re.exec(masked))) {
    const before = masked.slice(Math.max(0, m.index - 8), m.index);
    if (/\bfunc\s*$/.test(before)) continue;
    calls.push({ qual: m[1] || '', name: m[2], col: m.index + 1, text: m[0] });
  }
  return calls;
}

function isAssignment(masked) {
  return /(^|[^=!<>:])(:=|=)(?!=)/.test(masked);
}

function blankAssigned(masked) {
  const m = masked.match(/^([^=:+-]*?)(?::=|=)/);
  return !!(m && m[1].split(',').some((x) => x.trim() === '_'));
}

function uncheckedAssertion(masked) {
  if (!/\.\s*\(\s*[^)]+\s*\)/.test(masked)) return false;
  const m = masked.match(/^([^=:+-]*?)(?::=|=)/);
  if (!m) return true;
  const lhs = m[1].split(',').map((x) => x.trim()).filter(Boolean);
  return lhs.length < 2 || lhs[1] === '_';
}

function reportPath(f, opts) {
  const p = opts.abspath ? path.resolve(f) : path.relative(process.cwd(), f) || path.basename(f);
  return p.startsWith('..') ? f : p;
}

function analyzeFile(f, opts, local, excludes) {
  const src = fs.readFileSync(f, 'utf8');
  if (opts.ignoregenerated && isGenerated(src)) return [];
  if (!buildableByTags(f, src, opts)) return [];
  const imports = parseImports(src);
  const lines = src.split(/\r?\n/);
  const out = [];
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const masked = maskLine(raw);
    const trimmed = masked.trim();
    if (!trimmed || trimmed.startsWith('package ') || trimmed.startsWith('import ')) continue;
    if (/^func\b/.test(trimmed)) continue;
    if (/^return\b/.test(trimmed)) continue;
    const calls = findCalls(masked).filter((c) => callReturnsError(c, imports, local, opts, excludes));
    if (!calls.length) {
      if (opts.asserts && uncheckedAssertion(masked)) {
        out.push({ file: f, line: i + 1, col: masked.search(/\.\s*\(/) + 1, expr: raw.trim() });
      }
      continue;
    }
    if (isAssignment(masked)) {
      if (opts.blank && blankAssigned(masked)) out.push({ file: f, line: i + 1, col: raw.indexOf('_') + 1 || 1, expr: raw.trim() });
      if (opts.asserts && uncheckedAssertion(masked)) out.push({ file: f, line: i + 1, col: masked.search(/\.\s*\(/) + 1, expr: raw.trim() });
      continue;
    }
    for (const c of calls) out.push({ file: f, line: i + 1, col: c.col, expr: raw.trim() });
  }
  return out;
}

function main() {
  const opts = parseArgs(process.argv);
  const files = collectFiles(opts.pkgs, opts).sort();
  const excludes = loadExcludes(opts.exclude);
  const local = collectLocalFuncs(files, opts);
  let findings = [];
  for (const f of files) findings = findings.concat(analyzeFile(f, opts, local, excludes));
  for (const r of findings) console.log(`${reportPath(r.file, opts)}:${r.line}:${r.col}:\t${r.expr}`);
  process.exit(findings.length ? 1 : 0);
}

main();
