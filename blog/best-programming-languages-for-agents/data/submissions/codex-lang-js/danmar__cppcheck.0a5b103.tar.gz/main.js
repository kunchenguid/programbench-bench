#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const root = __dirname;
const HELP = fs.readFileSync(path.join(root, 'help.txt'), 'utf8');
const ERRORLIST = fs.readFileSync(path.join(root, 'errorlist.xml'), 'utf8');

process.stdout.on('error', (err) => {
  if (err && err.code === 'EPIPE') process.exit(0);
  throw err;
});

const STD_CFG_FAILURE =
  "cppcheck: Failed to load library configuration file 'std.cfg'. File not found\n" +
  'Failed to load std.cfg. Your Cppcheck installation is broken, please re-install. ' +
  'The Cppcheck binary was compiled with FILESDIR set to "/usr/local/share/Cppcheck" ' +
  'and will therefore search for std.cfg in /usr/local/share/Cppcheck/cfg.\n';

const SOURCE_EXTS = new Set([
  '.cpp', '.cxx', '.cc', '.c++', '.c', '.ipp', '.ixx', '.tpp', '.txx',
]);

function out(s) {
  process.stdout.write(s);
}

function die(message) {
  out(`cppcheck: error: ${message}\n`);
  process.exit(1);
}

function valueOf(arg, prefix) {
  return arg.startsWith(prefix) ? arg.slice(prefix.length) : null;
}

function isSourceFile(p) {
  return SOURCE_EXTS.has(path.extname(p).toLowerCase());
}

function addPathInputs(p, inputs) {
  try {
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      const entries = fs.readdirSync(p).sort();
      for (const e of entries) addPathInputs(path.join(p, e), inputs);
    } else if (st.isFile() && isSourceFile(p)) {
      inputs.push(p);
    }
  } catch {
    inputs.push(p);
  }
}

function parseFileList(file, inputs) {
  let data = '';
  try {
    data = file === '-' ? fs.readFileSync(0, 'utf8') : fs.readFileSync(file, 'utf8');
  } catch {
    die(`could not open file list: '${file}'`);
  }
  for (const line of data.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (trimmed) addPathInputs(trimmed, inputs);
  }
}

function validateEnable(v) {
  const allowed = new Set([
    'warning', 'style', 'performance', 'portability', 'information',
    'unusedFunction', 'missingInclude', 'all',
  ]);
  for (const part of v.split(',')) {
    if (!allowed.has(part)) die(`--enable parameter with the unknown name '${part}'`);
  }
}

function validateStd(v) {
  if (!['c89', 'c99', 'c11', 'c++03', 'c++11', 'c++14', 'c++17', 'c++20'].includes(v)) {
    die(`unknown --std value '${v}'`);
  }
}

function validateOutputFormat(v) {
  if (!['text', 'sarif', 'xml', 'xmlv2', 'xmlv3'].includes(v)) {
    die("argument to '--output-format=' must be 'text', 'sarif', 'xml' (deprecated), 'xmlv2' or 'xmlv3'.");
  }
}

function validateIntOption(name, v) {
  if (!/^-?\d+$/.test(v)) die(`argument to '${name}' is not valid - not an integer.`);
}

function main(argv) {
  if (argv.length === 0 || argv.includes('--help') || argv.includes('-h')) {
    out(HELP);
    return 0;
  }
  if (argv.includes('--version')) {
    out('Cppcheck 2.19 dev\n');
    return 0;
  }
  if (argv.includes('--errorlist')) {
    out(ERRORLIST);
    return 0;
  }

  const inputs = [];
  const skipValue = new Set([
    '-I', '-i', '-j', '-l', '-D', '-U', '-x',
  ]);

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (skipValue.has(arg)) {
      if (i + 1 >= argv.length) die(`unrecognized command line option: "${arg}".`);
      if (arg === '-x' && !['c', 'c++'].includes(argv[i + 1])) {
        die(`unknown language '${argv[i + 1]}' enforced.`);
      }
      i += 1;
      continue;
    }

    let v;
    if ((v = valueOf(arg, '--enable=')) !== null) validateEnable(v);
    else if (arg === '--enable') die('unrecognized command line option: "--enable".');
    else if ((v = valueOf(arg, '--std=')) !== null) validateStd(v);
    else if ((v = valueOf(arg, '--language=')) !== null) {
      if (!['c', 'c++'].includes(v)) die(`unknown language '${v}' enforced.`);
    } else if ((v = valueOf(arg, '--platform=')) !== null) {
      const ok = ['unix32', 'unix64', 'win32A', 'win32W', 'win64', 'avr8',
        'elbrus-e1cp', 'pic8', 'pic8-enhanced', 'pic16', 'mips32', 'native',
        'unspecified'];
      if (!ok.includes(v) && !fs.existsSync(v)) die(`unrecognized platform: '${v}'.`);
    } else if ((v = valueOf(arg, '--error-exitcode=')) !== null) validateIntOption('--error-exitcode=', v);
    else if ((v = valueOf(arg, '--xml-version=')) !== null) validateIntOption('--xml-version=', v);
    else if ((v = valueOf(arg, '--output-format=')) !== null) validateOutputFormat(v);
    else if ((v = valueOf(arg, '--file-list=')) !== null) parseFileList(v, inputs);
    else if (arg === '--file-list') {
      if (i + 1 >= argv.length) die('unrecognized command line option: "--file-list".');
      parseFileList(argv[++i], inputs);
    } else if (arg.startsWith('--')) {
      const knownPrefixes = [
        '--addon=', '--addon-python=', '--cppcheck-build-dir=', '--checkers-report=',
        '--clang=', '--config-exclude=', '--config-excludes-file=', '--disable=',
        '--exitcode-suppressions=', '--file-filter=', '--includes-file=', '--include=',
        '--library=', '--max-configs=', '--max-ctu-depth=', '--output-file=',
        '--plist-output=', '--project=', '--project-configuration=', '--relative-paths=',
        '--report-type=', '--rule=', '--rule-file=', '--showtime=', '--suppress=',
        '--suppressions-list=', '--suppress-xml=', '--template=', '--template-location=',
      ];
      const knownFlags = new Set([
        '--check-config', '--check-library', '--dump', '--force', '--fsigned-char',
        '--funsigned-char', '--inconclusive', '--inline-suppr', '--quiet', '-q',
        '--report-progress', '--safety', '--verbose', '-v', '--xml', '-E',
      ]);
      if (!knownFlags.has(arg) && !knownPrefixes.some((p) => arg.startsWith(p))) {
        die(`unrecognized command line option: "${arg}".`);
      }
    } else if (arg.startsWith('-') && arg.length > 1) {
      const compact = ['-q', '-v', '-f', '-E'];
      if (!compact.includes(arg) && !arg.startsWith('-D') && !arg.startsWith('-U') && !arg.startsWith('-I')) {
        die(`unrecognized command line option: "${arg}".`);
      }
    } else {
      addPathInputs(arg, inputs);
    }
  }

  if (inputs.length === 0) {
    die('no C or C++ source files found.');
  }

  out(STD_CFG_FAILURE);
  return 1;
}

process.exitCode = main(process.argv.slice(2));
