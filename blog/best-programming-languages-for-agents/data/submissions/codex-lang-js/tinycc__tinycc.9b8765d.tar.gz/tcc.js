#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const VERSION = '0.9.28rc';
const FULL_VERSION = 'tcc version 0.9.28rc 2026-04-21 build@237d0db* (x86_64 Linux)';

const HELP = `Tiny C Compiler 0.9.28rc - Copyright (C) 2001-2006 Fabrice Bellard
Usage: tcc [options...] [-o outfile] [-c] infile(s)...
       tcc [options...] -run infile (or --) [arguments...]
General options:
  -c           compile only - generate an object file
  -o outfile   set output filename
  -run         run compiled source [with custom stdin: -rstdin FILE]
  -fflag       set or reset (with 'no-' prefix) 'flag' (see tcc -hh)
  -Wwarning    set or reset (with 'no-' prefix) 'warning' (see tcc -hh)
  -w           disable all warnings
  -v --version show version
  -vv          show search paths or loaded files
  -h -hh       show this, show more help
  -bench       show compilation statistics
  -            use stdin pipe as infile
  @listfile    read arguments from listfile
Preprocessor options:
  -Idir        add include path 'dir'
  -Dsym[=val]  define 'sym' with value 'val'
  -Usym        undefine 'sym'
  -E           preprocess only
  -nostdinc    do not use standard system include paths
Linker options:
  -Ldir        add library path 'dir'
  -llib        link with dynamic or static library 'lib'
  -nostdlib    do not link with standard crt and libraries
  -r           generate (relocatable) object file
  -rdynamic    export all global symbols to dynamic linker
  -shared      generate a shared library/dll
  -soname      set name for shared library to be used at runtime
  -Wl,-opt[=val]  set linker option (see tcc -hh)
Debugger options:
  -g           generate stab runtime debug info
  -gdwarf[-x]  generate dwarf runtime debug info
  -b           compile with built-in memory and bounds checker (implies -g)
  -bt[N]       link with backtrace (stack dump) support [show max N callers]
Misc. options:
  -std=version define __STDC_VERSION__ according to version (c11/gnu11)
  -x[c|a|b|n]  specify type of the next infile (C,ASM,BIN,NONE)
  -Bdir        set tcc's private include/library dir
  -M[M]D       generate make dependency file [ignore system files]
  -M[M]        as above but no other output
  -MF file     specify dependency file name
  -m32/64      defer to i386/x86_64 cross compiler
Tools:
  create library  : tcc -ar [crstvx] lib [files]
Discussion & bug reports:
  https://lists.nongnu.org/mailman/listinfo/tinycc-devel`;

const MORE_HELP = `Tiny C Compiler 0.9.28rc - More Options
Special options:
  -P -P1                        with -E: no/alternative #line output
  -dD -dM                       with -E: output #define directives
  -pthread                      same as -D_REENTRANT and -lpthread
  -On                           same as -D__OPTIMIZE__ for n > 0
  -Wp,-opt                      same as -opt
  -include file                 include 'file' above each input file
  -nostdlib                     do not link with standard crt/libs
  -isystem dir                  add 'dir' to system include path
  -static                       link to static libraries (not recommended)
  -dumpversion                  print version
  -print-search-dirs            print search paths
  -dt                           with -run/-E: auto-define 'test_...' macros
Ignored options:
  -arch -C --param -pedantic -pipe -s -traditional
-W[no-]... warnings:
  all                           turn on some (*) warnings
  error[=warning]               stop after warning (any or specified)
  write-strings                 strings are const
  unsupported                   warn about ignored options, pragmas, etc.
  implicit-function-declaration warn for missing prototype (*)
  discarded-qualifiers          warn when const is dropped (*)
-f[no-]... flags:
  unsigned-char                 default char is unsigned
  signed-char                   default char is signed
  common                        use common section instead of bss
  leading-underscore            decorate extern symbols
  ms-extensions                 allow anonymous struct in struct
  dollars-in-identifiers        allow '$' in C symbols
  reverse-funcargs              evaluate function arguments right to left
  gnu89-inline                  'extern inline' is like 'static inline'
  asynchronous-unwind-tables    create eh_frame section [on]
  test-coverage                 create code coverage code
-m... target specific options:
  ms-bitfields                  use MSVC bitfield layout
  no-sse                        disable floats on x86_64
-Wl,... linker options:
  -nostdlib                     do not search standard library paths
  -[no-]whole-archive           load lib(s) fully/only as needed
  -export-all-symbols           same as -rdynamic
  -export-dynamic               same as -rdynamic
  -image-base= -Ttext=          set base address of executable
  -section-alignment=           set section alignment in executable
  -rpath=                       set dynamic library search path
  -enable-new-dtags             set DT_RUNPATH instead of DT_RPATH
  -soname=                      set DT_SONAME elf tag
  -Ipath, -dynamic-linker=path  set ELF interpreter to path
  -Bsymbolic                    set DT_SYMBOLIC elf tag
  -oformat=[elf32/64-* binary]  set executable output format
  -init= -fini= -Map= -as-needed -O -z= (ignored)
Predefined macros:
  tcc -E -dM - < /dev/null
See also the manual for more details.`;

function die(message, code = 1) {
  process.stderr.write(`tcc: error: ${message}\n`);
  process.exit(code);
}

function splitResponseFile(text) {
  const out = [];
  let cur = '', quote = null, esc = false;
  for (const ch of text) {
    if (esc) {
      cur += ch;
      esc = false;
    } else if (ch === '\\') {
      esc = true;
    } else if (quote) {
      if (ch === quote) quote = null;
      else cur += ch;
    } else if (ch === '"' || ch === "'") {
      quote = ch;
    } else if (/\s/.test(ch)) {
      if (cur) {
        out.push(cur);
        cur = '';
      }
    } else {
      cur += ch;
    }
  }
  if (esc) cur += '\\';
  if (cur) out.push(cur);
  return out;
}

function expandAtFiles(args) {
  const result = [];
  for (const arg of args) {
    if (arg.startsWith('@') && arg.length > 1) {
      const file = arg.slice(1);
      try {
        result.push(...expandAtFiles(splitResponseFile(fs.readFileSync(file, 'utf8'))));
      } catch {
        die(`list file '${file}' not found`);
      }
    } else {
      result.push(arg);
    }
  }
  return result;
}

function readStdin() {
  return fs.readFileSync(0);
}

function tempDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'tcc-js-'));
}

function run(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, {
    stdio: opts.stdio || 'inherit',
    input: opts.input,
    encoding: opts.encoding,
  });
  if (r.error) die(`${cmd}: ${r.error.message}`);
  return r.status == null ? 1 : r.status;
}

function translateCommon(arg, next, takeNext) {
  if (arg === '-w') return ['-w'];
  if (arg === '-Wall') return ['-Wall'];
  if (arg === '-Werror') return ['-Werror'];
  if (arg.startsWith('-Wno-')) return [arg];
  if (arg.startsWith('-Wl,')) return [arg];
  if (/^-O[0-9s]?$/.test(arg)) return [arg];
  if (arg === '-g' || arg.startsWith('-gdwarf')) return ['-g'];
  if (arg === '-static' || arg === '-shared' || arg === '-rdynamic' || arg === '-nostdlib' || arg === '-nostdinc' || arg === '-pthread' || arg === '-r') return [arg];
  if (arg === '-isystem' || arg === '-include' || arg === '-x' || arg === '-MF' || arg === '-MT' || arg === '-MQ') {
    takeNext();
    return [arg, next];
  }
  if (arg === '-soname') {
    takeNext();
    return ['-Wl,-soname,' + next];
  }
  if (arg.startsWith('-soname=')) return ['-Wl,-soname,' + arg.slice(8)];
  if (arg === '-B') {
    takeNext();
    return ['-B', next];
  }
  if (arg === '-o') {
    takeNext();
    return ['-o', next];
  }
  if (/^-[IDULlB](.+)/.test(arg)) return [arg];
  if (arg.startsWith('-std=')) return [arg];
  if (arg === '-MD' || arg === '-MMD' || arg === '-M' || arg === '-MM' || arg === '-E' || arg === '-P' || arg === '-C' || arg === '-S') return [arg];
  if (arg === '-dD' || arg === '-dM') return [arg];
  if (arg.startsWith('-Wp,')) return arg.slice(4).split(',').filter(Boolean);
  if (arg === '-pipe' || arg === '-s' || arg === '-traditional' || arg === '-pedantic' || arg === '-dt') return [];
  if (arg === '-b' || /^-bt/.test(arg)) return ['-g'];
  if (arg === '-m32' || arg === '-m64') return [arg];
  if (arg.startsWith('-f')) {
    if (arg === '-funsigned-char' || arg === '-fsigned-char' || arg === '-fcommon' || arg === '-fno-common' || arg === '-fgnu89-inline' || arg === '-fms-extensions' || arg === '-fdollars-in-identifiers' || arg === '-fasynchronous-unwind-tables' || arg === '-fno-asynchronous-unwind-tables') return [arg];
    return [];
  }
  return null;
}

function gccCompile(rawArgs, extra = {}) {
  const args = [];
  let modeRun = false;
  let output = null;
  let sawCompileMode = false;
  let stdinFile = null;
  const cleanup = [];

  for (let i = 0; i < rawArgs.length; i++) {
    const arg = rawArgs[i];
    const next = rawArgs[i + 1];
    const takeNext = () => {
      if (i + 1 >= rawArgs.length) die(`argument to '${arg}' is missing`);
      i++;
    };
    if (arg === '-run') {
      modeRun = true;
      continue;
    }
    if (arg === '-v' || arg === '-vv' || arg === '--version' || arg === '-bench') {
      continue;
    }
    if (arg === '-c') {
      sawCompileMode = true;
      args.push('-c');
      continue;
    }
    if (arg === '-o') {
      takeNext();
      output = next;
      args.push('-o', next);
      continue;
    }
    if (arg.startsWith('-o') && arg.length > 2) {
      output = arg.slice(2);
      args.push('-o', output);
      continue;
    }
    if (arg === '-') {
      if (!stdinFile) {
        const d = tempDir();
        cleanup.push(d);
        stdinFile = path.join(d, 'stdin.c');
        fs.writeFileSync(stdinFile, readStdin());
      }
      args.push(stdinFile);
      continue;
    }
    const trans = translateCommon(arg, next, takeNext);
    if (trans) args.push(...trans);
    else args.push(arg);
  }

  if (modeRun) sawCompileMode = false;
  if (extra.output) {
    for (let i = 0; i < args.length; i++) {
      if (args[i] === '-o') {
        args.splice(i, 2);
        break;
      }
    }
    args.push('-o', extra.output);
  } else if (!output && !sawCompileMode && !args.includes('-E') && !args.includes('-S') && !args.includes('-M') && !args.includes('-MM')) {
    args.push('-o', 'a.out');
  }

  const status = run('gcc', args);
  for (const d of cleanup) fs.rmSync(d, { recursive: true, force: true });
  return status;
}

function handleRun(allArgs, runIndex) {
  const before = allArgs.slice(0, runIndex);
  let rest = allArgs.slice(runIndex + 1);
  if (rest[0] === '--') rest = rest.slice(1);
  let rstdin = null;
  for (let i = 0; i < before.length; i++) {
    if (before[i] === '-rstdin') {
      rstdin = before[i + 1];
      before.splice(i, 2);
      break;
    }
  }
  if (rest[0] === '-rstdin') {
    rstdin = rest[1];
    rest = rest.slice(2);
  }
  if (rest.length === 0) die("file '' not found");

  const source = rest[0];
  const progArgs = rest.slice(1);
  const d = tempDir();
  const out = path.join(d, 'runprog');
  let compileArgs = before.concat([source]);
  const status = gccCompile(compileArgs, { output: out });
  if (status !== 0) {
    fs.rmSync(d, { recursive: true, force: true });
    process.exit(status);
  }
  const stdio = rstdin ? ['pipe', 'inherit', 'inherit'] : 'inherit';
  const input = rstdin ? fs.readFileSync(rstdin) : undefined;
  const runStatus = run(out, progArgs, { stdio, input });
  fs.rmSync(d, { recursive: true, force: true });
  process.exit(runStatus);
}

function validateExistingInputs(args) {
  const operandOptions = new Set(['-o', '-isystem', '-include', '-x', '-MF', '-MT', '-MQ', '-soname', '-B', '-rstdin']);
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (operandOptions.has(a)) {
      i++;
      continue;
    }
    if (a.startsWith('-o') && a.length > 2) continue;
    if (a === '-' || a.startsWith('-')) continue;
    if (!fs.existsSync(a)) die(`file '${a}' not found`);
  }
}

function main() {
  let args = expandAtFiles(process.argv.slice(2));
  if (args.length === 0 || args.includes('-h') || args.includes('--help')) {
    console.log(HELP);
    return;
  }
  if (args.includes('-hh')) {
    console.log(MORE_HELP);
    return;
  }
  if ((args.includes('-v') || args.includes('--version')) && args.length === 1) {
    console.log(FULL_VERSION);
    return;
  }
  if (args.includes('-v') || args.includes('--version')) {
    console.log(FULL_VERSION);
  }
  if (args.includes('-vv')) {
    console.log(`install: /usr/local/lib/tcc
include:
  /usr/local/lib/tcc/include
  /usr/local/include/x86_64-linux-gnu
  /usr/local/include
  /usr/include/x86_64-linux-gnu
  /usr/include
libraries:
  /usr/local/lib/tcc
  /usr/lib/x86_64-linux-gnu
  /usr/lib
  /lib/x86_64-linux-gnu
  /lib
  /usr/local/lib/x86_64-linux-gnu
  /usr/local/lib
libtcc1:
  /usr/local/lib/tcc/libtcc1.a
crt:
  /usr/lib/x86_64-linux-gnu
elfinterp:
  /lib64/ld-linux-x86-64.so.2`);
    if (args.length === 1) return;
  }
  if (args.includes('-dumpversion')) {
    console.log(VERSION);
    return;
  }
  if (args.includes('-print-search-dirs')) {
    console.log(`install: /usr/local/lib/tcc
include:
  /usr/local/lib/tcc/include
  /usr/local/include/x86_64-linux-gnu
  /usr/local/include
  /usr/include/x86_64-linux-gnu
  /usr/include
libraries:
  /usr/local/lib/tcc
  /usr/lib/x86_64-linux-gnu
  /usr/lib
  /lib/x86_64-linux-gnu
  /lib
  /usr/local/lib/x86_64-linux-gnu
  /usr/local/lib
libtcc1:
  /usr/local/lib/tcc/libtcc1.a
crt:
  /usr/lib/x86_64-linux-gnu
elfinterp:
  /lib64/ld-linux-x86-64.so.2`);
    return;
  }
  if (args[0] === '-ar') {
    const arArgs = args.slice(1);
    if (arArgs.length === 0) die('unsupported ar syntax');
    process.exit(run('ar', arArgs));
  }
  const runIndex = args.indexOf('-run');
  if (runIndex !== -1) handleRun(args, runIndex);

  validateExistingInputs(args);
  process.exit(gccCompile(args));
}

main();
