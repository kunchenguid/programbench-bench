#!/usr/bin/env node

const fs = require("fs");

const HELP = `Usage: executable [OPTIONS] [FILENAME]

Arguments:
  [FILENAME]  Profile data filename

Options:
      --sorted   Whether to sort the stacks by time spent
      --echo     Print data to stdout on exit. Useful when piping to other tools
      --debug    Show debug info
  -h, --help     Print help
  -V, --version  Print version
`;

function dieUsage(arg, tip) {
  process.stderr.write(`error: unexpected argument '${arg}' found\n\n`);
  if (tip) process.stderr.write(`  tip: to pass '${arg}' as a value, use '-- ${arg}'\n\n`);
  process.stderr.write("Usage: executable [OPTIONS] [FILENAME]\n\nFor more information, try '--help'.\n");
  process.exit(2);
}

function parseArgs(argv) {
  const opts = { sorted: false, echo: false, debug: false, filename: null };
  let positionalMode = false;
  for (const arg of argv) {
    if (!positionalMode && arg === "--") {
      positionalMode = true;
      continue;
    }
    if (!positionalMode && arg === "--help") {
      process.stdout.write(HELP);
      process.exit(0);
    }
    if (!positionalMode && arg === "-h") {
      process.stdout.write(HELP);
      process.exit(0);
    }
    if (!positionalMode && arg === "--version") {
      process.stdout.write("flamelens 0.3.1\n");
      process.exit(0);
    }
    if (!positionalMode && arg === "-V") {
      process.stdout.write("flamelens 0.3.1\n");
      process.exit(0);
    }
    if (!positionalMode && arg === "--sorted") {
      opts.sorted = true;
      continue;
    }
    if (!positionalMode && arg === "--echo") {
      opts.echo = true;
      continue;
    }
    if (!positionalMode && arg === "--debug") {
      opts.debug = true;
      continue;
    }
    if (!positionalMode && arg.startsWith("-")) {
      dieUsage(arg, true);
    }
    if (opts.filename === null) {
      opts.filename = arg;
    } else {
      dieUsage(arg, false);
    }
  }
  return opts;
}

function readInput(filename) {
  if (filename) {
    try {
      return fs.readFileSync(filename, "utf8");
    } catch (err) {
      const code = err && err.code === "ENOENT" ? 2 : 13;
      const kind = err && err.code === "ENOENT" ? "NotFound" : "PermissionDenied";
      const msg = err && err.code === "ENOENT" ? "No such file or directory" : (err.message || "Permission denied");
      process.stderr.write(`\nthread 'main' (${process.pid}) panicked at src/main.rs:44:47:\n`);
      process.stderr.write(`Could not read file: Os { code: ${code}, kind: ${kind}, message: "${msg}" }\n`);
      process.stderr.write("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n");
      process.exit(101);
    }
  }

  try {
    return fs.readFileSync(0, "utf8");
  } catch (_) {
    return "";
  }
}

function parseFolded(data) {
  const rows = [];
  for (const line of data.split(/\r?\n/)) {
    if (!line.trim()) continue;
    const m = line.match(/^(.*\S)\s+(-?\d+(?:\.\d+)?)\s*$/);
    if (!m) continue;
    const stack = m[1].split(";").filter(Boolean);
    const value = Number(m[2]);
    if (!stack.length || !Number.isFinite(value)) continue;
    rows.push({ line, stack, value });
  }
  return rows;
}

function buildTree(rows) {
  const root = { name: "root", value: 0, children: new Map() };
  for (const row of rows) {
    root.value += row.value;
    let node = root;
    for (const frame of row.stack) {
      if (!node.children.has(frame)) {
        node.children.set(frame, { name: frame, value: 0, children: new Map() });
      }
      node = node.children.get(frame);
      node.value += row.value;
    }
  }
  return root;
}

function ansi(code) {
  return `\x1b[${code}m`;
}

function colorFor(depth) {
  const colors = [196, 202, 208, 214, 220, 226, 190, 154, 118, 82, 46, 40, 34, 39, 45, 51, 87, 123, 159, 201];
  return colors[depth % colors.length];
}

function renderFlamegraph(data, opts) {
  const rows = parseFolded(data);
  const root = buildTree(rows);
  const width = Math.max(40, process.stdout.columns || 80);
  const height = Math.max(12, process.stdout.rows || 24);
  const lines = [];
  lines.push(`flamelens 0.3.1${opts.debug ? "  DEBUG" : ""}`);
  lines.push(`Total samples: ${root.value || 0}  Stacks: ${rows.length}${opts.sorted ? "  Sorted" : ""}`);
  lines.push("");

  const levels = [];
  function visit(node, depth, x0, span) {
    if (!levels[depth]) levels[depth] = [];
    if (depth > 0) levels[depth].push({ node, x0, span, depth });
    let children = Array.from(node.children.values());
    if (opts.sorted) children.sort((a, b) => b.value - a.value || a.name.localeCompare(b.name));
    let x = x0;
    for (const child of children) {
      const childSpan = node.value ? span * (child.value / node.value) : 0;
      visit(child, depth + 1, x, childSpan);
      x += childSpan;
    }
  }
  visit(root, 0, 0, width);

  const maxGraphRows = Math.max(4, height - 6);
  for (let d = Math.min(levels.length - 1, maxGraphRows); d >= 1; d--) {
    const cells = Array(width).fill(" ");
    const attrs = Array(width).fill(null);
    for (const item of levels[d] || []) {
      const start = Math.max(0, Math.floor(item.x0));
      const end = Math.min(width, Math.max(start + 1, Math.floor(item.x0 + item.span)));
      const label = ` ${item.node.name} ${item.node.value} `;
      for (let i = start; i < end; i++) {
        cells[i] = label[i - start] || " ";
        attrs[i] = colorFor(item.depth);
      }
    }
    let line = "";
    let active = null;
    for (let i = 0; i < width; i++) {
      if (attrs[i] !== active) {
        line += ansi("0");
        if (attrs[i] !== null) line += `\x1b[48;5;${attrs[i]}m\x1b[30m`;
        active = attrs[i];
      }
      line += cells[i];
    }
    lines.push(line + ansi("0"));
  }

  lines.push("");
  if (rows.length) {
    const top = rows.slice().sort((a, b) => b.value - a.value).slice(0, Math.max(1, height - lines.length - 2));
    for (const row of top) {
      const text = `${row.value.toString().padStart(8)}  ${row.stack.join(";")}`;
      lines.push(text.slice(0, width));
    }
  } else {
    lines.push("No folded stack samples loaded.");
  }
  lines.push("q: quit  Enter: zoom  /: search  arrows/hjkl: navigate");
  return lines.slice(0, height).join("\n");
}

function nonTtyFailure() {
  process.stderr.write('Error: Os { code: 11, kind: WouldBlock, message: "Resource temporarily unavailable" }\n');
  process.exit(1);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const data = readInput(opts.filename);

  if (opts.echo) process.stdout.write(data);

  if (!process.stdout.isTTY || !process.stdin.isTTY) {
    nonTtyFailure();
  }

  process.stdout.write("\x1b[?1049h\x1b[?25l\x1b[2J\x1b[H");
  process.stdout.write(renderFlamegraph(data, opts));
  process.stdout.write("\x1b[0m");

  if (process.stdin.setRawMode) process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.on("data", (chunk) => {
    const s = chunk.toString("utf8");
    if (s.includes("q") || s.includes("\u0003") || s.includes("\u001b")) {
      process.stdout.write("\x1b[?25h\x1b[?1049l");
      process.exit(0);
    }
  });
}

main();
