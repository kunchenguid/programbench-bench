#!/usr/bin/env node
'use strict';

const fs = require('fs');
const cp = require('child_process');

const VERSION = 'bartib 1.1.0';
const BOLD = '\x1b[1m', UNDER = '\x1b[4m', GREEN = '\x1b[32m', RESET = '\x1b[0m';

function main() {
  const argv = process.argv.slice(2);
  if (argv.includes('--version') || argv.includes('-V')) return console.log(VERSION);
  if (argv.length === 0 || argv[0] === '--help' || argv[0] === '-h') return helpTop();
  if (argv[0] === 'help') return helpSub(argv[1]);

  let file = process.env.BARTIB_FILE || '';
  let i = 0;
  if (argv[i] === '-f') { file = argv[i + 1] || ''; i += 2; }
  const cmd = argv[i++];
  const args = argv.slice(i);
  const known = new Set(['cancel','change','check','continue','current','edit','last','list','projects','report','sanity','search','start','status','stop']);
  if (!known.has(cmd)) return clapErr(`Found argument '${cmd}' which wasn't expected, or isn't valid in this context`, 'executable [OPTIONS] <SUBCOMMAND>');
  if (args.includes('--help') || args.includes('-h')) return helpSub(cmd);
  const opt = parseArgs(args);
  if (cmd === 'projects' && (args.includes('-n') || args.includes('--no-quotes'))) opt.noQuotes = true;
  if (cmd === 'start' && (!opt.description || !opt.project)) {
    return clapErr('The following required arguments were not provided:\n    --description <DESCRIPTION>\n    --project <PROJECT>', 'executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>');
  }
  if (!file) return die('Error: Please specify a file with your activity log either as -f option or as BARTIB_FILE environment variable');
  const acts = readActs(file);
  switch (cmd) {
    case 'start': return cmdStart(file, acts, opt);
    case 'stop': return cmdStop(file, acts, opt);
    case 'change': return cmdChange(file, acts, opt);
    case 'cancel': return cmdCancel(file, acts);
    case 'continue': return cmdContinue(file, acts, opt);
    case 'current': return cmdCurrent(acts);
    case 'list': return cmdList(acts, opt);
    case 'report': return cmdReport(acts, opt);
    case 'projects': return cmdProjects(acts, opt);
    case 'last': return cmdLast(acts, opt);
    case 'search': return cmdSearch(acts, opt);
    case 'check': return cmdCheck(file);
    case 'sanity': return cmdSanity(acts);
    case 'status': return cmdStatus(acts, opt);
    case 'edit': return cmdEdit(file, opt);
  }
}

function parseArgs(args) {
  const o = { _: [] };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    const next = () => args[++i] || '';
    if (a === '-d' || a === '--description' || a === '--date') {
      const v = next();
      if (a === '--date' || (a === '-d' && !('description' in o) && looksDate(v))) o.date = v;
      else o.description = v;
    } else if (a === '-p' || a === '--project') o.project = next();
    else if (a === '-t' || a === '--time') o.time = next();
    else if (a === '-n' || a === '--number') o.number = parseInt(next(), 10);
    else if (a === '--from') o.from = next();
    else if (a === '--to') o.to = next();
    else if (a === '--round') o.round = next();
    else if (a === '-e' || a === '--editor') o.editor = next();
    else if (a === '--today') o.today = true;
    else if (a === '--yesterday') o.yesterday = true;
    else if (a === '--current_week' || a === '--current-week') o.current_week = true;
    else if (a === '--last_week' || a === '--last-week') o.last_week = true;
    else if (a === '--no_grouping' || a === '--no-grouping') o.no_grouping = true;
    else if (a === '-c' || a === '--current') o.current = true;
    else if (a === '--no-quotes' || a === '-n') o.noQuotes = true;
    else if (a.startsWith('-')) clapErr(`Found argument '${a}' which wasn't expected, or isn't valid in this context`, 'executable');
    else o._.push(a);
  }
  return o;
}

function nowDate() { return new Date(); }
function pad(n) { return String(n).padStart(2, '0'); }
function datePart(d) { return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; }
function timePart(d) { return `${pad(d.getHours())}:${pad(d.getMinutes())}`; }
function dateTime(d) { return `${datePart(d)} ${timePart(d)}`; }
function todayStr() { return datePart(nowDate()); }
function parseDT(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/.exec(s || '');
  if (!m) return null;
  return new Date(+m[1], +m[2]-1, +m[3], +m[4], +m[5], 0, 0);
}
function dtForTime(t) {
  if (!t) return nowDate();
  if (!/^\d{1,2}:\d{2}$/.test(t)) {
    console.log(`Can not parse "${t}" as time. Argument for -t/--time is ignored (input contains invalid characters)`);
    return nowDate();
  }
  const [h, m] = t.split(':').map(Number);
  const d = nowDate(); d.setHours(h, m, 0, 0); return d;
}
function looksDate(s) { return /^\d{4}-\d{2}-\d{2}$/.test(s || ''); }
function parseDateArg(v, flag) {
  if (!v) return null;
  if (!looksDate(v)) {
    console.log(`Can not parse "${v}" as date. Argument for ${flag} is ignored (input contains invalid characters)`);
    return null;
  }
  return v;
}
function durationMin(a, end) {
  const e = end || nowDate();
  return Math.max(0, Math.floor((e - a.start) / 60000));
}
function roundedDurationMin(a, opt) {
  if (!opt || !opt.round || !a.end) return durationMin(a, a.end);
  const m = /^(\d+)(m|h)$/.exec(opt.round);
  if (!m) return durationMin(a, a.end);
  const step = +m[1] * (m[2] === 'h' ? 60 : 1);
  const round = d => new Date(Math.round(d.getTime() / (step * 60000)) * step * 60000);
  return Math.max(0, Math.floor((round(a.end) - round(a.start)) / 60000));
}
function fmtDur(min) {
  if (min < 1) return '<1m';
  const h = Math.floor(min / 60), m = min % 60;
  if (h && m) return `${h}h ${pad(m)}m`;
  if (h) return `${h}h 00m`;
  return `${m}m`;
}
function lineOf(a) {
  return a.end ? `${dateTime(a.start)} - ${dateTime(a.end)} | ${a.project} | ${a.desc}` : `${dateTime(a.start)} | ${a.project} | ${a.desc}`;
}
function parseLine(line, idx) {
  let m = /^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}) - (\d{4}-\d{2}-\d{2} \d{2}:\d{2}) \| (.*?) \| (.*)$/.exec(line);
  if (m) return { start: parseDT(m[1]), end: parseDT(m[2]), project: m[3], desc: m[4], line: idx + 1, raw: line };
  m = /^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}) \| (.*?) \| (.*)$/.exec(line);
  if (m) return { start: parseDT(m[1]), end: null, project: m[2], desc: m[3], line: idx + 1, raw: line };
  return { error: true, raw: line, line: idx + 1 };
}
function readActs(file) {
  try {
    const text = fs.readFileSync(file, 'utf8');
    return text.split(/\r?\n/).filter(Boolean).map(parseLine).filter(a => !a.error && a.start);
  } catch {
    return [];
  }
}
function writeActs(file, acts) { fs.writeFileSync(file, acts.map(lineOf).join('\n') + (acts.length ? '\n' : '')); }
function running(acts) { return acts.filter(a => !a.end); }

function cmdStart(file, acts, opt) {
  const t = dtForTime(opt.time);
  for (const a of running(acts)) a.end = t;
  const a = { start: t, end: null, project: opt.project, desc: opt.description };
  acts.push(a); writeActs(file, acts);
  console.log(`Started activity: "${a.desc}" (${a.project}) at ${dateTime(a.start)}`);
}
function cmdStop(file, acts, opt) {
  const rs = running(acts);
  if (!rs.length) return die('Error: No activity has been started before.');
  const t = dtForTime(opt.time);
  for (const a of rs) {
    a.end = t;
    console.log(`Stopped activity: "${a.desc}" (${a.project}) started at ${dateTime(a.start)} (${fmtDur(durationMin(a, a.end))})`);
  }
  writeActs(file, acts);
}
function cmdChange(file, acts, opt) {
  const t = dtForTime(opt.time);
  for (const a of running(acts)) a.end = t;
  const last = acts.filter(a => a.end).slice(-1)[0] || acts[acts.length-1];
  const desc = opt.description || (last && last.desc);
  const project = opt.project || (last && last.project);
  if (!desc || !project) return die('Error: No activity has been started before.');
  const a = { start: t, end: null, project, desc };
  acts.push(a); writeActs(file, acts);
  console.log(`Changed activity: "${a.desc}" (${a.project}) started at ${dateTime(a.start)}`);
}
function cmdCancel(file, acts) {
  const rs = running(acts);
  if (!rs.length) return die('Error: No activity is currently running.');
  for (const a of rs) console.log(`Canceled activity: "${a.desc}" (${a.project}) started at ${dateTime(a.start)}`);
  writeActs(file, acts.filter(a => a.end));
}
function cmdContinue(file, acts, opt) {
  if (!acts.length) return die('Error: No activity has been started before.');
  const n = opt._.length ? parseInt(opt._[0], 10) : 0;
  const closed = acts.filter(a => a.end);
  const source = closed.slice().reverse()[n] || acts.slice().reverse()[n];
  if (!source) return die(`Error: No activity with number ${n}`);
  const t = dtForTime(opt.time);
  for (const a of running(acts)) a.end = t;
  const a = { start: t, end: null, project: opt.project || source.project, desc: opt.description || source.desc };
  acts.push(a); writeActs(file, acts);
  console.log(`Started activity: "${a.desc}" (${a.project}) at ${dateTime(a.start)}`);
}
function cmdCurrent(acts) {
  const rs = running(acts);
  if (!rs.length) return console.log('No Activity is currently running');
  console.log(`\n${UNDER}Started At      ${RESET} ${UNDER}Description${RESET} ${UNDER}Project${RESET} ${UNDER}Duration${RESET} `);
  for (const a of rs) console.log(`${dateTime(a.start)} ${a.desc} ${a.project} ${fmtDur(durationMin(a))}`);
}
function filterActs(acts, opt) {
  let xs = acts.slice();
  let d = parseDateArg(opt.date, '-d/--date');
  if (opt.today) d = todayStr();
  if (opt.yesterday) { const y = nowDate(); y.setDate(y.getDate()-1); d = datePart(y); }
  if (d) xs = xs.filter(a => datePart(a.start) === d);
  const from = parseDateArg(opt.from, '--from'), to = parseDateArg(opt.to, '--to');
  if (from) xs = xs.filter(a => datePart(a.start) >= from);
  if (to) xs = xs.filter(a => datePart(a.start) <= to);
  if (opt.project) xs = xs.filter(a => a.project === opt.project);
  if (opt.current_week || opt.last_week) {
    const n = nowDate(), dow = (n.getDay()+6)%7;
    const monday = new Date(n); monday.setDate(n.getDate()-dow); const start = datePart(monday);
    const endDate = new Date(monday); endDate.setDate(monday.getDate()+6); const end = datePart(endDate);
    if (opt.current_week) xs = xs.filter(a => datePart(a.start) >= start && datePart(a.start) <= end);
    else { const s = new Date(monday); s.setDate(s.getDate()-7); const e = new Date(monday); e.setDate(e.getDate()-1); xs = xs.filter(a => datePart(a.start) >= datePart(s) && datePart(a.start) <= datePart(e)); }
  }
  if (Number.isFinite(opt.number)) xs = xs.slice(-opt.number);
  return xs;
}
function cmdList(acts, opt) {
  const xs = filterActs(acts, opt);
  if (!xs.length) return console.log('No activity to display');
  console.log(`\n${UNDER}${opt.no_grouping ? 'Started         ' : 'Started'}${RESET} ${UNDER}Stopped${RESET} ${UNDER}Description${RESET} ${UNDER}Project${RESET} ${UNDER}Duration${RESET} `);
  let last = null;
  for (const a of xs) {
    const day = datePart(a.start);
    if (!opt.no_grouping && !opt.date && xs.some(b => datePart(b.start) !== day) && day !== last) {
      if (last !== null) console.log('');
      const sum = xs.filter(b => datePart(b.start) === day).reduce((s,b)=>s+roundedDurationMin(b,opt),0);
      console.log(`\n${BOLD}${day}\t${fmtDur(sum)}${RESET}`);
      last = day;
    }
    const started = opt.no_grouping ? dateTime(a.start) : timePart(a.start);
    const stopped = a.end ? timePart(a.end) : '-';
    const row = `${started} ${stopped.padEnd(7)} ${a.desc.padEnd(11)} ${a.project.padEnd(7)} ${fmtDur(roundedDurationMin(a,opt))}`;
    console.log(a.end ? row : `${GREEN}${row}${RESET}`);
  }
  console.log('');
}
function cmdReport(acts, opt) {
  const xs = filterActs(acts, opt);
  if (!xs.length) return console.log('No activity to display');
  const byP = new Map();
  for (const a of xs) {
    if (!byP.has(a.project)) byP.set(a.project, new Map());
    const m = byP.get(a.project);
    m.set(a.desc, (m.get(a.desc) || 0) + roundedDurationMin(a, opt));
  }
  let total = 0; console.log('');
  for (const p of [...byP.keys()].sort()) {
    const m = byP.get(p);
    const psum = [...m.values()].reduce((a,b)=>a+b,0); total += psum;
    console.log(`${BOLD}${p}${'.'.repeat(Math.max(3, 12 - p.length))} ${fmtDur(psum)}${RESET}`);
    for (const d of [...m.keys()].sort()) console.log(`    ${d}${'.'.repeat(Math.max(1, 8 - d.length))} ${fmtDur(m.get(d))}`);
    console.log('');
  }
  console.log(`${BOLD}Total${'.'.repeat(7)} ${fmtDur(total)}${RESET}`);
  console.log('');
}
function cmdProjects(acts, opt) {
  let xs = opt.current ? running(acts) : acts;
  const ps = [...new Set(xs.map(a => a.project))].sort();
  for (const p of ps) console.log(opt.noQuotes ? p : `"${p}"`);
}
function cmdLast(acts, opt) {
  const n = Number.isFinite(opt.number) ? opt.number : 10;
  const uniq = [];
  for (let i = acts.length - 1; i >= 0; i--) {
    const a = acts[i], key = `${a.desc}\0${a.project}`;
    if (!uniq.some(x => x.key === key)) uniq.push({ key, a, idx: uniq.length });
    if (uniq.length >= n) break;
  }
  if (!uniq.length) return console.log('No activity to display');
  console.log(`\n${UNDER} # ${RESET} ${UNDER}Description${RESET} ${UNDER}Project${RESET} `);
  uniq.reverse().forEach((x, j) => console.log(`[${uniq.length-1-j}] ${x.a.desc.padEnd(11)} ${x.a.project}`));
  console.log('');
}
function cmdSearch(acts, opt) {
  const term = (opt._[0] || '').toLowerCase();
  const matches = [];
  for (let i = acts.length - 1, n = 0; i >= 0; i--, n++) {
    const a = acts[i];
    if (!term || a.desc.toLowerCase().includes(term) || a.project.toLowerCase().includes(term)) matches.push({ a, n });
  }
  if (!matches.length) return console.log('No activity to display');
  console.log(`\n${UNDER} # ${RESET} ${UNDER}Description${RESET} ${UNDER}Project${RESET} `);
  matches.reverse().forEach(x => console.log(`[${x.n}] ${x.a.desc.padEnd(11)} ${x.a.project}`));
  console.log('');
}
function cmdCheck(file) {
  let lines = [];
  try { lines = fs.readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean); } catch {}
  const bad = lines.map(parseLine).filter(a => a.error);
  if (!bad.length) return console.log('All lines in the file have been successfully parsed as activities.');
  console.log(`Found ${bad.length} line(s) with parsing errors\n`);
  for (const b of bad) console.log(`${b.raw}\n  -> could not parse activity (Line: ${b.line})`);
  process.exitCode = 1;
}
function cmdSanity(acts) {
  let bad = false;
  for (const a of acts) {
    if (!a.end || a.end < a.start) {
      bad = true;
      console.log(`Activity has negative duration\n${a.desc} (Started: ${dateTime(a.start)}, Ended: ${a.end ? dateTime(a.end) : '--'}, Line: ${a.line || 1})\n`);
    }
  }
  if (!bad) console.log('No unusual activities.');
}
function cmdStatus(acts, opt) {
  if (opt.project) acts = acts.filter(a => a.project === opt.project);
  cmdCurrent(acts);
  console.log('');
  cmdReport(acts, { today: true, project: opt.project });
}
function cmdEdit(file, opt) {
  const ed = opt.editor || process.env.EDITOR;
  if (!ed) return die('Error: Please specify an editor with -e option or EDITOR environment variable');
  cp.spawnSync(ed, [file], { stdio: 'inherit', shell: true });
}
function helpTop() { console.log(`${VERSION}
Nikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>
A simple timetracker

USAGE:
    executable [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]

SUBCOMMANDS:
    cancel      cancels all currently running activities
    change      changes the current activity
    check       checks file and reports parsing errors
    continue    continues a previous activity
    current     lists all currently running activities
    edit        opens the activity log in an editor
    help        Prints this message or the help of the given subcommand(s)
    last        displays the descriptions and projects of recent activities
    list        list recent activities
    projects    list all projects
    report      reports duration of tracked activities
    sanity      checks sanity of bartib log
    search      search for existing descriptions and projects
    start       starts a new activity
    status      shows current status and time reports for today, current week, and current month
    stop        stops all currently running activities

To get help for a specific subcommand, run \`bartib [SUBCOMMAND] --help\`.
To get started, view the \`start\` help with \`bartib start --help\``); }
function helpSub(cmd) {
  const map = {
    start: ['starts a new activity','executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>','\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)'],
    stop: ['stops all currently running activities','executable stop [OPTIONS]','\nOPTIONS:\n    -t, --time <TIME>    the time for changing the activity status (HH:MM)'],
    change: ['changes the current activity','executable change [OPTIONS]','\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)'],
    continue: ['continues a previous activity','executable continue [OPTIONS] [NUMBER]','\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)\n\nARGS:\n    <NUMBER>    the number of the activity to continue (see subcommand `last`) [default: 0]'],
    list: ['list recent activities','executable list [FLAGS] [OPTIONS]',"\nFLAGS:\n        --current_week    show activities of the current week\n    -h, --help            Prints help information\n        --last_week       show activities of the last week\n        --no_grouping     do not group activities by date in list\n        --today           show activities of the current day\n        --yesterday       show yesterdays' activities\n\nOPTIONS:\n    -d, --date <DATE>          show activities of a certain date only\n        --from <FROM_DATE>     begin of date range (inclusive)\n    -n, --number <NUMBER>      maximum number of activities to display\n    -p, --project <PROJECT>    do list activities for this project only\n        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or hours. E.g. 15m or 4h\n        --to <TO_DATE>         end of date range (inclusive)"],
    report: ['reports duration of tracked activities','executable report [FLAGS] [OPTIONS]',"\nFLAGS:\n        --current_week    show activities of the current week\n    -h, --help            Prints help information\n        --last_week       show activities of the last week\n        --today           show activities of the current day\n        --yesterday       show yesterdays' activities\n\nOPTIONS:\n    -d, --date <DATE>          show activities of a certain date only\n        --from <FROM_DATE>     begin of date range (inclusive)\n    -p, --project <PROJECT>    do report activities for this project only\n        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or hours. E.g. 15m or 4h\n        --to <TO_DATE>         end of date range (inclusive)"],
    projects: ['list all projects','executable projects [FLAGS]','\nFLAGS:\n    -c, --current      prints currently running projects only\n    -h, --help         Prints help information\n    -n, --no-quotes    prints projects without quotes'],
    last: ['displays the descriptions and projects of recent activities','executable last [OPTIONS]','\nOPTIONS:\n    -n, --number <NUMBER>    maximum number of lines to display [default: 10]'],
    search: ['search for existing descriptions and projects','executable search <SEARCH_TERM>','\nARGS:\n    <SEARCH_TERM>    the search term [default: \'\']'],
    current: ['lists all currently running activities','executable current',''],
    cancel: ['cancels all currently running activities','executable cancel',''],
    check: ['checks file and reports parsing errors','executable check',''],
    sanity: ['checks sanity of bartib log','executable sanity',''],
    edit: ['opens the activity log in an editor','executable edit [OPTIONS]','\nOPTIONS:\n    -e <editor>        the command to start your preferred text editor [env: EDITOR=]'],
    status: ['shows current status and time reports for today, current week, and current month','executable status [OPTIONS]','\nOPTIONS:\n    -p, --project <PROJECT>    show status for this project only']
  };
  const h = map[cmd] || ['Prints this message or the help of the given subcommand(s)','executable help [SUBCOMMAND]',''];
  console.log(`executable-${cmd || 'help'} \n${h[0]}\n\nUSAGE:\n    ${h[1]}\n\nFLAGS:\n    -h, --help    Prints help information${h[2]}`);
}
function clapErr(msg, usage) {
  console.error(`error: ${msg}\n\nUSAGE:\n    ${usage}\n\nFor more information try --help`);
  process.exit(1);
}
function die(msg) { console.error(msg); process.exit(1); }
main();
