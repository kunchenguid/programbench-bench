#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");

const HELP = `
USAGE: 

   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                 string containing two space-seprated positive integers>]
                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                 [-h] <Array of strings> ...


Where: 

   -i <path to directory>,  --replaydirectory <path to directory>
     The path to directory for replay output.

   -s <positive integer>,  --seed <positive integer>
     The seed for the map generator.

   -d <a string containing two space-seprated positive integers>, 
      --dimensions <a string containing two space-seprated positive
      integers>
     The dimensions of the map.

   -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>
     Create a map that will accommodate n players [SINGLE PLAYER MODE
     ONLY].

   -r,  --noreplay
     Turns off the replay generation.

   -t,  --timeout
     Causes game environment to ignore timeouts (give all bots infinite
     time).

   -o,  --override
     Overrides player-sent names using cmd args [SERVER ONLY].

   -q,  --quiet
     Runs game in quiet mode, producing machine-parsable output.

   --,  --ignore_rest
     Ignores the rest of the labeled arguments following this flag.

   --version
     Displays version information and exits.

   -h,  --help
     Displays usage information and exits.

   <Array of strings>  (accepted multiple times)
     Start commands for bots.


   Halite Game Environment
`;

function briefUsage() {
  return `Brief USAGE: 
   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                 string containing two space-seprated positive integers>]
                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                 [-h] <Array of strings> ...

For complete USAGE and HELP type: 
   ./executable --help
`;
}

function parsePositiveInt(s) {
  if (!/^[0-9]+$/.test(String(s))) return null;
  const n = Number(s);
  return n > 0 && Number.isSafeInteger(n) ? n : null;
}

function parseArgs(argv) {
  const opts = {
    replayDir: ".",
    seed: null,
    dimensions: null,
    nplayers: null,
    noreplay: false,
    timeout: false,
    override: false,
    quiet: false,
    bots: [],
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") return { help: true, opts };
    if (a === "--version") return { version: true, opts };
    if (a === "--" || a === "--ignore_rest") {
      opts.bots.push(...argv.slice(i + 1));
      break;
    }
    if (a === "-i" || a === "--replaydirectory") {
      if (i + 1 >= argv.length) return { error: `PARSE ERROR: Argument: ${a}\n             Missing argument value\n\n${briefUsage()}` };
      opts.replayDir = argv[++i];
      continue;
    }
    if (a === "-s" || a === "--seed") {
      const val = argv[++i];
      const n = parsePositiveInt(val);
      if (n == null) return { error: `PARSE ERROR: Argument: -s (--seed)\n             Couldn't read argument value from string '${val}'\n\n${briefUsage()}` };
      opts.seed = n >>> 0;
      continue;
    }
    if (a === "-d" || a === "--dimensions") {
      const val = argv[++i];
      const parts = String(val || "").trim().split(/\s+/).filter(Boolean);
      if (parts.length !== 2 || parsePositiveInt(parts[0]) == null || parsePositiveInt(parts[1]) == null) {
        return { error: `PARSE ERROR: Argument: -d (--dimensions)\n             Couldn't read argument value from string '${val}'\n\n${briefUsage()}` };
      }
      opts.dimensions = [Number(parts[0]), Number(parts[1])];
      continue;
    }
    if (a === "-n" || a === "--nplayers") {
      const val = argv[++i];
      const n = parsePositiveInt(val);
      if (n == null) return { error: `PARSE ERROR: Argument: -n (--nplayers)\n             Couldn't read argument value from string '${val}'\n\n${briefUsage()}` };
      opts.nplayers = n;
      continue;
    }
    if (a === "-r" || a === "--noreplay") { opts.noreplay = true; continue; }
    if (a === "-t" || a === "--timeout") { opts.timeout = true; continue; }
    if (a === "-o" || a === "--override") { opts.override = true; continue; }
    if (a === "-q" || a === "--quiet") { opts.quiet = true; continue; }
    opts.bots.push(a);
  }
  return { opts };
}

function rng(seed) {
  let x = (seed >>> 0) || 1;
  return () => {
    x = (Math.imul(1664525, x) + 1013904223) >>> 0;
    return x / 0x100000000;
  };
}

function dimsFor(opts, commands) {
  const accommodated = opts.nplayers || commands.length;
  if (opts.dimensions) {
    let [w, h] = opts.dimensions;
    if (commands.length > 1) {
      if (w % 2) w--;
      if (h % 2) h--;
      w = Math.max(4, w);
      h = Math.max(4, h);
    }
    return [w, h];
  }
  if (opts.nplayers) {
    const table = { 1: [35, 35], 2: [20, 20], 3: [20, 20], 4: [18, 18], 5: [20, 15], 6: [18, 12] };
    return table[opts.nplayers] || [30, 30];
  }
  if (commands.length === 1) return [30, 30];
  if (commands.length === 2) return [34, 34];
  if (commands.length === 3) return [36, 24];
  if (commands.length === 4) return [32, 32];
  if (commands.length === 5) return [40, 30];
  return [36, 24];
}

function makeMap(w, h, players, seed) {
  const rand = rng(seed || ((Date.now() / 1000) >>> 0));
  const prod = [];
  const owners = new Array(w * h).fill(0);
  const strength = [];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const edge = Math.min(x, y, w - 1 - x, h - 1 - y);
      prod.push(Math.max(1, Math.min(15, 1 + Math.floor(rand() * 9) + (edge % 4))));
      strength.push(25 + Math.floor(rand() * 180));
    }
  }
  const starts = startPositions(w, h, players);
  starts.forEach((p, i) => {
    const idx = p[1] * w + p[0];
    owners[idx] = i + 1;
    strength[idx] = 100;
  });
  return { prod, owners, strength };
}

function startPositions(w, h, n) {
  const pts = [];
  if (n === 1) pts.push([Math.floor(w / 2), Math.floor(h / 2)]);
  else if (n === 2) pts.push([Math.floor(w / 4), Math.floor(h / 2)], [Math.floor(3 * w / 4), Math.floor(h / 2)]);
  else if (n === 3) pts.push([Math.floor(w / 2), Math.floor(h / 4)], [Math.floor(w / 4), Math.floor(3 * h / 4)], [Math.floor(3 * w / 4), Math.floor(3 * h / 4)]);
  else {
    pts.push([Math.floor(w / 4), Math.floor(h / 4)], [Math.floor(3 * w / 4), Math.floor(h / 4)], [Math.floor(w / 4), Math.floor(3 * h / 4)], [Math.floor(3 * w / 4), Math.floor(3 * h / 4)]);
    if (n >= 5) pts.push([Math.floor(w / 2), Math.floor(h / 2)]);
    if (n >= 6) pts.push([Math.floor(w / 2), Math.floor(h / 4)]);
  }
  return pts.slice(0, n);
}

function encodeOwners(owners) {
  const out = [];
  for (let i = 0; i < owners.length;) {
    const owner = owners[i];
    let c = 1;
    while (i + c < owners.length && owners[i + c] === owner) c++;
    out.push(c, owner);
    i += c;
  }
  return out;
}

function frameLine(map) {
  return encodeOwners(map.owners).concat(map.strength).join(" ") + " ";
}

function applyMoves(map, w, h, player, line) {
  const toks = String(line || "").trim().split(/\s+/).filter(Boolean).map(Number);
  for (let i = 0; i + 2 < toks.length; i += 3) {
    const x = toks[i], y = toks[i + 1], d = toks[i + 2];
    if (!Number.isInteger(x) || !Number.isInteger(y) || x < 0 || y < 0 || x >= w || y >= h) continue;
    const src = y * w + x;
    if (map.owners[src] !== player || d === 0) continue;
    let nx = x, ny = y;
    if (d === 1) ny = (y + h - 1) % h;
    else if (d === 2) nx = (x + 1) % w;
    else if (d === 3) ny = (y + 1) % h;
    else if (d === 4) nx = (x + w - 1) % w;
    else continue;
    const dst = ny * w + nx;
    const moving = map.strength[src];
    if (moving <= 0) continue;
    map.strength[src] = 0;
    if (map.owners[dst] === player) {
      map.strength[dst] = Math.min(255, map.strength[dst] + moving);
    } else if (moving > map.strength[dst]) {
      map.owners[dst] = player;
      map.strength[dst] = moving - map.strength[dst];
    } else {
      map.strength[dst] -= moving;
      if (map.strength[dst] === 0) map.owners[dst] = 0;
    }
  }
}

function grow(map) {
  for (let i = 0; i < map.owners.length; i++) {
    if (map.owners[i] > 0) map.strength[i] = Math.min(255, map.strength[i] + map.prod[i]);
  }
}

function score(map, player) {
  let cells = 0, strength = 0;
  for (let i = 0; i < map.owners.length; i++) {
    if (map.owners[i] === player) { cells++; strength += map.strength[i]; }
  }
  return { cells, strength };
}

function readlineFrom(proc) {
  let buf = "";
  const lines = [];
  proc.stdout.setEncoding("utf8");
  proc.stdout.on("data", d => {
    buf += d;
    const parts = buf.split(/\r?\n/);
    buf = parts.pop();
    for (const l of parts) lines.push(l);
  });
  return () => lines.shift();
}

async function waitForLine(next, ms) {
  const start = Date.now();
  while (Date.now() - start < ms) {
    const l = next();
    if (l !== undefined) return l;
    await new Promise(r => setTimeout(r, 5));
  }
  return null;
}

async function main() {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed.help) { process.stdout.write(HELP); return 0; }
  if (parsed.version) { console.log("\n./executable  version: 1.2\n"); return 0; }
  if (parsed.error) { process.stderr.write(parsed.error); return 1; }
  const opts = parsed.opts;
  if (opts.nplayers != null && (opts.nplayers < 1 || opts.nplayers > 6)) {
    for (const b of opts.bots) console.log(b);
    console.error("\nA map can only accommodate between 1 and 6 players.\n");
    return 1;
  }
  if (opts.bots.length < 1) {
    console.error("Please provide the launch command string for at least one bot.\nUse the --help flag for usage details.");
    return 1;
  }

  for (const b of opts.bots) console.log(b);
  const seed = opts.seed == null ? ((Date.now() / 1000) >>> 0) : opts.seed;
  const [w, h] = dimsFor(opts, opts.bots);
  console.log(`${w} ${h}`);
  const turns = Math.max(1, Math.floor(Math.min(w, h) * 10 + (opts.nplayers === 6 ? 26 : 0)));
  const map = makeMap(w, h, Math.min(opts.bots.length, 6), seed);
  const prodLine = map.prod.join(" ") + " ";
  let curFrame = frameLine(map);

  const bots = opts.bots.map((cmd, i) => {
    const child = spawn(cmd, { shell: true, stdio: ["pipe", "pipe", "pipe"] });
    child.stderr.setEncoding("utf8");
    const bot = { cmd, id: i + 1, child, next: readlineFrom(child), err: "", name: cmd, alive: true, lastAlive: 0 };
    child.stderr.on("data", d => { bot.err += d; });
    child.on("error", e => { bot.err += String(e.message || e); });
    return bot;
  });

  for (const b of bots) {
    b.child.stdin.write(`${b.id}\n${w} ${h} \n${prodLine}\n${curFrame}\n`);
    if (!opts.quiet) console.log(`Init Message sent to player ${b.id}.`);
  }
  for (const b of bots) {
    const name = await waitForLine(b.next, opts.timeout ? 5000 : 1000);
    if (name == null) {
      b.alive = false;
      b.failedInit = true;
      b.name = b.err.trim().split(/\r?\n/)[0] || b.cmd;
      if (!opts.quiet) console.log(`Init Message received from player ${b.id}, ${b.name}.`);
    } else {
      b.name = opts.override ? b.cmd : (name.trim() || b.cmd);
      if (!opts.quiet) console.log(`Init Message received from player ${b.id}, ${b.name}.`);
    }
  }

  for (let t = 1; t <= turns; t++) {
    if (!opts.quiet) console.log(`Turn ${t}`);
    const moves = [];
    for (const b of bots) {
      if (!b.alive) {
        if (b.failedInit && !b.failureAnnounced && !opts.quiet) {
          console.log(`Bot #${b.id} timeout or error (Unix) 0`);
          b.failureAnnounced = true;
        }
        moves.push("");
        continue;
      }
      b.child.stdin.write(`${curFrame}\n`);
      const line = await waitForLine(b.next, opts.timeout ? 5000 : 1000);
      if (line == null) {
        b.alive = false;
        if (!opts.quiet) console.log(`Bot #${b.id} timeout or error (Unix) 0`);
        moves.push("");
      } else {
        b.lastAlive = t;
        moves.push(line);
      }
    }
    moves.forEach((m, i) => { if (bots[i].alive) applyMoves(map, w, h, i + 1, m); });
    grow(map);
    curFrame = frameLine(map);
  }
  for (const b of bots) {
    try { b.child.stdin.end(); } catch (_) {}
    try { b.child.kill(); } catch (_) {}
  }

  const ranked = bots.slice().sort((a, b) => {
    const sb = score(map, b.id), sa = score(map, a.id);
    return sb.cells - sa.cells || sb.strength - sa.strength || b.lastAlive - a.lastAlive || a.id - b.id;
  });
  const rankById = new Map(ranked.map((b, i) => [b.id, i + 1]));
  if (!opts.noreplay) {
    if (!opts.quiet) console.log(`Map seed was ${seed}`);
    const replayName = `${Math.floor(Math.random() * 2147483647)}-${seed}.hlt`;
    const replayPath = path.join(opts.replayDir || ".", replayName);
    try {
      fs.mkdirSync(path.dirname(replayPath), { recursive: true });
      fs.writeFileSync(replayPath, JSON.stringify({ width: w, height: h, seed, players: bots.map(b => b.name) }));
    } catch (_) {}
    if (!opts.quiet) console.log(`Opening a file at ${replayPath}`);
  }

  if (opts.quiet) {
    for (const b of bots) console.log(`${b.id} ${rankById.get(b.id)} ${b.lastAlive || turns}`);
    console.log(" ");
  } else {
    for (const b of bots) {
      console.log(`Player #${b.id}, ${b.name}, came in rank #${rankById.get(b.id)} and was last alive on frame #${b.lastAlive || turns}!`);
    }
  }
  return 0;
}

main().then(code => process.exit(code)).catch(err => {
  console.error(err && err.stack ? err.stack : String(err));
  process.exit(1);
});
