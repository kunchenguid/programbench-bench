#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const BLUE = '\x1b[0;34m';
const RED = '\x1b[0;31m';
const RESET = '\x1b[0m';

function home() { return process.env.HOME || process.cwd(); }
function configDir() { return process.env.XDG_CONFIG_HOME || path.join(home(), '.config'); }
function dataDir() { return process.env.XDG_DATA_HOME || path.join(home(), '.local', 'share'); }
function cfgPath() { return path.join(configDir(), 'jot', 'config'); }
function vaultsPath() { return path.join(dataDir(), 'jot', 'vaults'); }
function color(s) { return `${BLUE}${s}${RESET}`; }
function err(s) { console.log(`${RED}error${RESET}: ${s}`); }
function mkdirp(p) { fs.mkdirSync(p, { recursive: true }); }
function exists(p) { try { fs.accessSync(p); return true; } catch { return false; } }

function parseTomlLike(text) {
  const out = {};
  let section = null;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const sm = line.match(/^\[([^\]]+)\]$/);
    if (sm) { section = sm[1]; out[section] ||= {}; continue; }
    const m = line.match(/^([A-Za-z0-9_.-]+)\s*=\s*(.*)$/);
    if (!m) continue;
    let v = m[2].trim();
    if ((v.startsWith("'") && v.endsWith("'")) || (v.startsWith('"') && v.endsWith('"'))) v = v.slice(1, -1);
    else if (v === 'true') v = true;
    else if (v === 'false') v = false;
    else if (v === '[]') v = [];
    if (section) out[section][m[1]] = v; else out[m[1]] = v;
  }
  return out;
}

function ensureState() {
  mkdirp(path.dirname(cfgPath()));
  mkdirp(path.dirname(vaultsPath()));
  if (!exists(cfgPath())) fs.writeFileSync(cfgPath(), "editor = 'nvim'\nconflict = true\n");
  if (!exists(vaultsPath())) fs.writeFileSync(vaultsPath(), '[vaults]\n');
  mkdirp(path.join(home(), '.cache', 'rosetta'));
}

function readConfig() { ensureState(); return parseTomlLike(fs.readFileSync(cfgPath(), 'utf8')); }
function writeConfig(c) {
  fs.writeFileSync(cfgPath(), `editor = '${c.editor ?? 'nvim'}'\nconflict = ${String(c.conflict ?? true)}\n`);
}
function readVaults() {
  ensureState();
  const raw = fs.readFileSync(vaultsPath(), 'utf8');
  const p = parseTomlLike(raw);
  return { current: p.current || '', vaults: p.vaults || {} };
}
function writeVaults(st) {
  let s = '';
  if (st.current) s += `current = '${st.current}'\n\n`;
  s += '[vaults]\n';
  for (const name of Object.keys(st.vaults)) s += `${name} = '${st.vaults[name]}'\n`;
  fs.writeFileSync(vaultsPath(), s);
}
function vaultRoot(name, loc) { return path.join(loc, name); }
function vaultDataPath(name, loc) { return path.join(vaultRoot(name, loc), '.jot', 'data'); }
function readVaultData(name, loc) {
  const f = vaultDataPath(name, loc);
  if (!exists(f)) return { name, location: loc, folder: '', history: [] };
  return parseTomlLike(fs.readFileSync(f, 'utf8'));
}
function writeVaultData(d) {
  const f = vaultDataPath(d.name, d.location);
  mkdirp(path.dirname(f));
  fs.writeFileSync(f, `name = '${d.name}'\nlocation = '${d.location}'\nfolder = '${d.folder || ''}'\nhistory = []\n`);
}
function currentVault() {
  const st = readVaults();
  if (!st.current || !st.vaults[st.current]) return null;
  const d = readVaultData(st.current, st.vaults[st.current]);
  return { st, name: st.current, loc: st.vaults[st.current], data: d, root: vaultRoot(st.current, st.vaults[st.current]) };
}
function currentDir(v) { return path.join(v.root, v.data.folder || ''); }
function cleanName(n, ext) { return n.endsWith(ext) ? n.slice(0, -ext.length) : n; }
function itemPath(v, type, name) {
  const base = currentDir(v);
  if (isNote(type)) return path.join(base, cleanName(name, '.md') + '.md');
  return path.join(base, name);
}
function isNote(t) { return t === 'note' || t === 'nt'; }
function isFolder(t) { return t === 'folder' || t === 'fd'; }
function isVault(t) { return t === 'vault' || t === 'vl'; }
function typeName(t) { return isNote(t) ? 'note' : isFolder(t) ? 'folder' : isVault(t) ? 'vault' : t; }
function requireVault() {
  const v = currentVault();
  if (!v) { err('not inside a vault'); return null; }
  return v;
}
function relFolder(v, p) {
  const next = path.normalize(path.join(currentDir(v), p));
  const root = path.resolve(v.root);
  const resolved = path.resolve(next);
  if (resolved === root) return '';
  if (!resolved.startsWith(root + path.sep)) return false;
  return path.relative(root, resolved);
}

function banner() {
  console.log(`${BLUE}________      _____ 
______(_)_______  /_
_____  /_  __ \\  __/
____  / / /_/ / /_  
___  /  \\____/\\__/  
/___/         ᵥ₀.₁.₂  
${RESET}         

usage: jt <command>

${BLUE}commands:${RESET}

create items
    ${color('vault')}, ${color('vl')}       create a vault or list vaults
    create items in current folder
        ${color('note')}, ${color('nt')}        create a note 
        ${color('folder')}, ${color('fd')}      create a folder

interact with items
    ${color('enter')}, ${color('en')}       enter a vault
    ${color('open')}, ${color('op')}        open a note from current folder
    ${color('opdir')}, ${color('od')}       open current folder in file explorer
    ${color('chdir')}, ${color('cd')}       change folder within current vault
    ${color('list')}, ${color('ls')}        list items in current folder

perform fs operations on items
    ${color('remove')}, ${color('rm')}      remove an item 
    ${color('rename')}, ${color('rn')}      rename an item 
    ${color('move')}, ${color('mv')}        move an item to a new location
    ${color('vmove')}, ${color('vm')}       move an item to a different vault

config
    ${color('config')}, ${color('cf')}      display, set or open config

get help 
    use ${color('help')} or ${color('-h')} and ${color('--help')} flags along with a command to get corresponding help`);
}

const helps = {
  vault: `executable-vault \ncreate a vault or list vaults\n\nUSAGE:\n    jt vault\n    jt vault -l\n    jt vault <vault name> <vault location>\n\nARGS:\n    <vault name>        name for new vault\n    <vault location>    absolute path to location of new vault\n\nOPTIONS:\n    -l            show vaults' location\n    -h, --help    Print help information`,
  note: `executable-note \ncreate a note\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nARGS:\n    <note name>    name for new note (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information`,
  folder: `executable-folder \ncreate a folder\n\nUSAGE:\n    jt folder\n    jt folder [folder name]\n\nARGS:\n    <folder name>    name for new folder (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information`,
  enter: `executable-enter \nenter a vault\n\nUSAGE:\n    executable enter <vault name>\n\nARGS:\n    <vault name>    name of the vault to enter\n\nOPTIONS:\n    -h, --help    Print help information`,
  open: `executable-open \nopen a note (from the current folder)\n\nUSAGE:\n    executable open <note name>\n\nARGS:\n    <note name>    name of note to be opened\n\nOPTIONS:\n    -h, --help    Print help information`,
  opdir: `executable-opdir \nopen current folder in file explorer\n\nUSAGE:\n    executable opdir\n\nOPTIONS:\n    -h, --help    Print help information`,
  chdir: `executable-chdir \nchange folder within current vault\n\nUSAGE:\n    executable chdir <folder path>\n\nARGS:\n    <folder path>    path to folder to switch to (from current folder)\n\nOPTIONS:\n    -h, --help    Print help information`,
  list: `executable-list \nlist items in current folder\n\nUSAGE:\n    executable list [item type]\n\nARGS:\n    <item type>    \n\nOPTIONS:\n    -h, --help    Print help information`,
  remove: `executable-remove \nremove an item\n\nUSAGE:\n    executable remove <item type> <name>\n\nARGS:\n    <item type>    remove a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be removed\n\nOPTIONS:\n    -h, --help    Print help information`,
  rename: `executable-rename \nrename an item\n\nUSAGE:\n    executable rename <item type> <name> <new name>\n\nARGS:\n    <item type>    rename a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be renamed\n    <new name>     new name of item\n\nOPTIONS:\n    -h, --help    Print help information`,
  move: `executable-move \nmove an item\n\nUSAGE:\n    executable move <item type> <name> <new location>\n\nARGS:\n    <item type>       move a vault (or vl) | note (or nt) | folder (or fd)\n    <name>            name of item to be moved\n    <new location>    path to new location of item (current folder as root in case of note or\n                      folder)\n\nOPTIONS:\n    -h, --help    Print help information`,
  vmove: `executable-vmove \nmove notes and folders to a different vault\n\nUSAGE:\n    executable vmove <item type> <name> <vault name>\n\nARGS:\n    <item type>     move a note (or nt) | folder (or fd)\n    <name>          name of item to be moved\n    <vault name>    name of vault to move the item to\n\nOPTIONS:\n    -h, --help    Print help information`,
  config: `executable-config \ndisplay, set or open config\n\nUSAGE:\n    jt config <config type>\n    jt config <config type> [config value]\n\nARGS:\n    <config type>     name of config item to display or set\n    <config value>    pass a value if config needs to be updated\n\nOPTIONS:\n    -h, --help    Print help information`,
};
function showHelp(cmd) { console.log(helps[cmd] || ''); }

function commandVault(args) {
  const st = readVaults();
  if (args[0] === '-l') {
    for (const n of Object.keys(st.vaults).sort()) console.log(`   ${n} \t ${st.vaults[n]}`);
    return;
  }
  if (args.length === 0) {
    for (const n of Object.keys(st.vaults).sort()) console.log(`   ${n}`);
    return;
  }
  if (args.length < 2) return clapMissing('<vault location>', 'jt vault\n    jt vault -l\n    jt vault <vault name> <vault location>');
  const [name, loc] = args;
  if (!path.isAbsolute(loc)) { err('vault location should be an absolute path'); return; }
  if (st.vaults[name]) { err(`vault ${name} already exists`); return; }
  const root = vaultRoot(name, loc);
  mkdirp(path.join(root, '.jot'));
  st.vaults[name] = loc;
  writeVaults(st);
  writeVaultData({ name, location: loc, folder: '' });
  console.log(`vault ${color(name)} created`);
}

function createItem(type, name) {
  const v = requireVault(); if (!v) return;
  const p = itemPath(v, type, name);
  if (exists(p)) { err(`a ${typeName(type)} named ${name} already exists in this location`); return; }
  if (isNote(type)) fs.writeFileSync(p, '');
  else mkdirp(p);
  console.log(`${typeName(type)} ${color(name)} created`);
}

function commandEnter(args) {
  const st = readVaults();
  const name = args[0];
  if (!name) return clapMissing('<vault name>', 'executable enter <vault name>');
  if (!st.vaults[name]) { err(`vault ${name} doesn't exist`); return; }
  st.current = name; writeVaults(st);
  console.log(`entered ${color(name)}`);
}

function tree(dir, label, filter) {
  console.log(label);
  let items = [];
  try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  const cmp = (a, b) => {
    if (a.isFile() !== b.isFile()) return a.isFile() ? -1 : 1;
    if (a.name === '.jot') return 1;
    if (b.name === '.jot') return -1;
    return a.name.localeCompare(b.name);
  };
  items = items.filter(d => {
    if (filter === 'note') return d.isFile() && d.name.endsWith('.md');
    if (filter === 'folder') return d.isDirectory();
    if (d.name.startsWith('.')) return false;
    return (d.isDirectory() || (d.isFile() && d.name.endsWith('.md')));
  }).sort(cmp);
  function rec(base, entries, prefix) {
    entries.forEach((d, i) => {
      const last = i === entries.length - 1;
      const stem = d.isFile() && d.name.endsWith('.md') ? d.name.slice(0, -3) : d.name;
      const shown = d.isFile() ? color(stem) : stem;
      console.log(prefix + (last ? '└── ' : '├── ') + shown);
      if (d.isDirectory() && filter !== 'note') {
        let kids = fs.readdirSync(path.join(base, d.name), { withFileTypes: true })
          .filter(k => filter === 'folder' ? k.isDirectory() : ((k.isDirectory() && !k.name.startsWith('.')) || (k.isFile() && k.name.endsWith('.md') && !k.name.startsWith('.'))))
          .sort(cmp);
        rec(path.join(base, d.name), kids, prefix + (last ? '    ' : '│   '));
      }
    });
  }
  rec(dir, items, '');
}

function commandList(args) {
  const v = requireVault(); if (!v) return;
  const f = args[0];
  const filter = isNote(f) ? 'note' : isFolder(f) ? 'folder' : '';
  tree(currentDir(v), v.data.folder ? `${v.name} > ${v.data.folder}` : v.name, filter);
}

function commandChdir(args) {
  const v = requireVault(); if (!v) return;
  const p = args[0];
  if (!p) return clapMissing('<folder path>', 'executable chdir <folder path>');
  const rel = relFolder(v, p);
  if (rel === false) { err('path crosses the bounds of vault'); return; }
  const target = path.join(v.root, rel);
  if (!exists(target) || !fs.statSync(target).isDirectory() || rel === '') {
    if (p === '..' && (v.data.folder || '') !== '') {
      v.data.folder = rel; writeVaultData(v.data); console.log('folder changed'); return;
    }
    if (rel === '' && p !== '/') { v.data.folder = ''; writeVaultData(v.data); console.log('folder changed'); return; }
    err(p === '/' ? 'path crosses the bounds of vault' : "couldn't find the path specified"); return;
  }
  v.data.folder = rel; writeVaultData(v.data); console.log('folder changed');
}

function commandRemove(args) {
  const [type, name] = args;
  if (isVault(type)) {
    const st = readVaults();
    if (!st.vaults[name]) { err(`vault ${name} doesn't exist`); return; }
    fs.rmSync(vaultRoot(name, st.vaults[name]), { recursive: true, force: true });
    delete st.vaults[name]; if (st.current === name) st.current = '';
    writeVaults(st); console.log(`vault ${color(name)} removed`); return;
  }
  const v = requireVault(); if (!v) return;
  const p = itemPath(v, type, name);
  if (!exists(p)) { err(`${typeName(type)} ${name} doesn't exist`); return; }
  fs.rmSync(p, { recursive: true, force: true });
  console.log(`${typeName(type)} ${color(name)} removed`);
}

function commandRename(args) {
  const [type, name, nn] = args;
  if (isVault(type)) {
    const st = readVaults(); if (!st.vaults[name]) { err(`vault ${name} doesn't exist`); return; }
    fs.renameSync(vaultRoot(name, st.vaults[name]), vaultRoot(nn, st.vaults[name]));
    const loc = st.vaults[name]; delete st.vaults[name]; st.vaults[nn] = loc; if (st.current === name) st.current = nn;
    writeVaults(st); writeVaultData({ name: nn, location: loc, folder: '' });
    console.log(`vault ${color(name)} renamed to ${color(nn)}`); return;
  }
  const v = requireVault(); if (!v) return;
  const oldp = itemPath(v, type, name), newp = itemPath(v, type, nn);
  if (!exists(oldp)) { err(`${typeName(type)} ${name} doesn't exist`); return; }
  if (exists(newp)) { err(`a ${typeName(type)} named ${nn} already exists in this location`); return; }
  fs.renameSync(oldp, newp); console.log(`${typeName(type)} ${color(name)} renamed to ${color(nn)}`);
}

function commandMove(args) {
  const [type, name, loc] = args;
  if (isVault(type)) {
    const st = readVaults(); if (!st.vaults[name]) { err(`vault ${name} doesn't exist`); return; }
    if (!path.isAbsolute(loc)) { err('vault location should be an absolute path'); return; }
    mkdirp(loc); fs.renameSync(vaultRoot(name, st.vaults[name]), vaultRoot(name, loc));
    st.vaults[name] = loc; writeVaults(st); writeVaultData({ name, location: loc, folder: '' });
    console.log(`vault ${color(name)} moved`); return;
  }
  const v = requireVault(); if (!v) return;
  const src = itemPath(v, type, name);
  const rel = relFolder(v, loc);
  if (rel === false || loc.startsWith('/')) { err("couldn't find the path specified"); return; }
  const destDir = path.join(v.root, rel);
  if (!exists(src)) { err(`${typeName(type)} ${name} doesn't exist`); return; }
  if (!exists(destDir) || !fs.statSync(destDir).isDirectory()) { err("couldn't find the path specified"); return; }
  fs.renameSync(src, path.join(destDir, path.basename(src)));
  console.log(`${typeName(type)} ${color(name)} moved`);
}

function commandVmove(args) {
  const [type, name, target] = args;
  const v = requireVault(); if (!v) return;
  const st = readVaults();
  if (!st.vaults[target]) { err(`vault ${target} doesn't exist`); return; }
  const src = itemPath(v, type, name);
  if (!exists(src)) { err(`${typeName(type)} ${name} doesn't exist`); return; }
  const dest = path.join(vaultRoot(target, st.vaults[target]), path.basename(src));
  fs.renameSync(src, dest);
  console.log(`${typeName(type)} ${color(name)} moved to vault ${color(target)}`);
}

function commandOpen(args) {
  const v = requireVault(); if (!v) return;
  const p = itemPath(v, 'note', args[0] || '');
  if (!exists(p)) { err(`note ${args[0]} doesn't exist`); return; }
  const ed = readConfig().editor || 'nvim';
  try { cp.spawnSync(ed, [p], { stdio: 'inherit' }); } catch {}
}
function commandOpdir() {
  const v = requireVault(); if (!v) return;
  const opener = process.platform === 'darwin' ? 'open' : 'xdg-open';
  try { cp.spawnSync(opener, [currentDir(v)], { stdio: 'inherit' }); } catch {}
}
function commandConfig(args) {
  const c = readConfig();
  if (args.length === 0) {
    const ed = c.editor || 'nvim';
    try { cp.spawnSync(ed, [cfgPath()], { stdio: 'inherit' }); } catch {}
    return;
  }
  const key = args[0];
  if (args.length === 1) {
    if (!(key in c)) { err(`config ${key} doesn't exist`); return; }
    console.log(`${key}: ${color(String(c[key]))}`); return;
  }
  let val = args.slice(1).join(' ');
  if (key === 'conflict') val = val === 'true';
  c[key] = val; writeConfig(c);
  console.log(`set ${color(key)} to ${color(String(val))}`);
}

function clapMissing(arg, usage) {
  const body = Array.isArray(arg) ? arg.map(a => `    ${a}`).join('\n') : `    ${arg}`;
  console.error(`error: The following required arguments were not provided:\n${body}\n\nUSAGE:\n    ${usage}\n\nFor more information try --help`);
  process.exitCode = 2;
}

function main() {
  const aliases = { vl: 'vault', nt: 'note', fd: 'folder', en: 'enter', op: 'open', od: 'opdir', cd: 'chdir', ls: 'list', rm: 'remove', rn: 'rename', mv: 'move', vm: 'vmove', cf: 'config' };
  let args = process.argv.slice(2);
  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') { banner(); if (args.length === 0) process.exitCode = 2; return; }
  if (args[0] === 'help') { const c = aliases[args[1]] || args[1]; if (c && helps[c]) showHelp(c); else banner(); return; }
  let cmd = aliases[args[0]] || args[0]; args = args.slice(1);
  if (args.includes('--help') || args.includes('-h')) { if (helps[cmd]) showHelp(cmd); else console.error(`error: The subcommand '--help' wasn't recognized\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help`), process.exitCode = 2; return; }
  switch (cmd) {
    case 'vault': return commandVault(args);
    case 'note': if (!args[0]) return clapMissing('<note name>', 'jt note\n    jt note [note name]'); return createItem('note', args[0]);
    case 'folder': if (!args[0]) return clapMissing('<folder name>', 'jt folder\n    jt folder [folder name]'); return createItem('folder', args[0]);
    case 'enter': return commandEnter(args);
    case 'open': if (!args[0]) return clapMissing('<note name>', 'executable open <note name>'); return commandOpen(args);
    case 'opdir': return commandOpdir();
    case 'chdir': return commandChdir(args);
    case 'list': return commandList(args);
    case 'remove':
      if (args.length < 2) return clapMissing(args.length === 0 ? ['<item type>', '<name>'] : '<name>', 'executable remove <item type> <name>');
      return commandRemove(args);
    case 'rename':
      if (args.length < 3) return clapMissing(args.length === 0 ? ['<item type>', '<name>', '<new name>'] : args.length === 1 ? ['<name>', '<new name>'] : '<new name>', 'executable rename <item type> <name> <new name>');
      return commandRename(args);
    case 'move':
      if (args.length < 3) return clapMissing(args.length === 0 ? ['<item type>', '<name>', '<new location>'] : args.length === 1 ? ['<name>', '<new location>'] : '<new location>', 'executable move <item type> <name> <new location>');
      return commandMove(args);
    case 'vmove':
      if (args.length < 3) return clapMissing(args.length === 0 ? ['<item type>', '<name>', '<vault name>'] : args.length === 1 ? ['<name>', '<vault name>'] : '<vault name>', 'executable vmove <item type> <name> <vault name>');
      return commandVmove(args);
    case 'config': return commandConfig(args);
    default:
      console.error(`error: Found argument '${cmd}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help`);
      process.exitCode = 2;
  }
}
main();
