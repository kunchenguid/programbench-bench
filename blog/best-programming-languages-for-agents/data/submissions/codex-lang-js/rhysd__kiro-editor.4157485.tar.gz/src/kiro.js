#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = '0.4.3';

function programName() {
  return process.env.KIRO_ARG0 || process.argv[1] || './executable';
}

function helpText() {
  const p = programName();
  return `${p}: A tiny UTF-8 terminal text editor

Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.
Specify file paths to edit as a command argument or run without argument to
start to write a new text.
Help can show up with key mapping Ctrl-?.

Usage:
    ${p} [options] [FILES...]

Mappings:
    Ctrl-Q                        : Quit
    Ctrl-S                        : Save to file
    Ctrl-O                        : Open text buffer
    Ctrl-X                        : Next text buffer
    Alt-X                         : Previous text buffer
    Ctrl-P or UP                  : Move cursor up
    Ctrl-N or DOWN                : Move cursor down
    Ctrl-F or RIGHT               : Move cursor right
    Ctrl-B or LEFT                : Move cursor left
    Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line
    Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line
    Ctrl-[ or Ctrl-V or PAGE DOWN : Next page
    Ctrl-] or Alt-V or PAGE UP    : Previous page
    Alt-F or Ctrl-RIGHT           : Move cursor to next word
    Alt-B or Ctrl-LEFT            : Move cursor to previous word
    Alt-N or Ctrl-DOWN            : Move cursor to next paragraph
    Alt-P or Ctrl-UP              : Move cursor to previous paragraph
    Alt-<                         : Move cursor to top of file
    Alt->                         : Move cursor to bottom of file
    Ctrl-H or BACKSPACE           : Delete character
    Ctrl-D or DELETE              : Delete next character
    Ctrl-W                        : Delete a word
    Ctrl-J                        : Delete until head of line
    Ctrl-K                        : Delete until end of line
    Ctrl-U                        : Undo last change
    Ctrl-R                        : Redo last undo change
    Ctrl-G                        : Search text
    Ctrl-M                        : New line
    Ctrl-L                        : Refresh screen
    Ctrl-?                        : Show this help

Options:
    -v, --version       Print version
    -h, --help          Print this help

`;
}

function optionError(kind, opt) {
  const msg = kind === 'arg'
    ? `Error: Option '${opt}' does not take an argument. Please see --help for more details`
    : `Error: Unrecognized option: '${opt}'. Please see --help for more details`;
  process.stderr.write(msg + '\n');
  process.exit(1);
}

function parseArgs(argv) {
  const files = [];
  let help = false;
  let version = false;
  let options = true;
  for (const arg of argv) {
    if (options && arg === '--') {
      options = false;
      continue;
    }
    if (options && arg.startsWith('--') && arg.length > 2) {
      const body = arg.slice(2);
      const eq = body.indexOf('=');
      const name = eq === -1 ? body : body.slice(0, eq);
      if ((name === 'help' || name === 'version') && eq !== -1) optionError('arg', name);
      if (name === 'help') help = true;
      else if (name === 'version') version = true;
      else optionError('unknown', name);
      continue;
    }
    if (options && arg.startsWith('-') && arg.length > 1) {
      for (const ch of arg.slice(1)) {
        if (ch === 'h') help = true;
        else if (ch === 'v') version = true;
        else optionError('unknown', ch);
      }
      continue;
    }
    files.push(arg);
  }
  return { files, help, version };
}

class Buffer {
  constructor(file) {
    this.file = file || null;
    this.lines = [''];
    this.cx = 0;
    this.cy = 0;
    this.rowoff = 0;
    this.coloff = 0;
    this.dirty = false;
    if (file) this.open(file);
  }

  open(file) {
    const text = fs.readFileSync(file, 'utf8');
    this.file = file;
    this.lines = text.split(/\n/);
    if (this.lines.length > 1 && this.lines[this.lines.length - 1] === '') this.lines.pop();
    if (this.lines.length === 0) this.lines = [''];
    this.cx = 0;
    this.cy = 0;
    this.dirty = false;
  }

  current() {
    return this.lines[this.cy] ?? '';
  }

  clamp() {
    if (this.cy < 0) this.cy = 0;
    if (this.cy >= this.lines.length) this.cy = this.lines.length - 1;
    const len = this.current().length;
    if (this.cx < 0) this.cx = 0;
    if (this.cx > len) this.cx = len;
  }

  insert(s) {
    const line = this.current();
    this.lines[this.cy] = line.slice(0, this.cx) + s + line.slice(this.cx);
    this.cx += s.length;
    this.dirty = true;
  }

  newline() {
    const line = this.current();
    this.lines[this.cy] = line.slice(0, this.cx);
    this.lines.splice(this.cy + 1, 0, line.slice(this.cx));
    this.cy++;
    this.cx = 0;
    this.dirty = true;
  }

  backspace() {
    if (this.cx > 0) {
      const line = this.current();
      this.lines[this.cy] = line.slice(0, this.cx - 1) + line.slice(this.cx);
      this.cx--;
      this.dirty = true;
    } else if (this.cy > 0) {
      const prevLen = this.lines[this.cy - 1].length;
      this.lines[this.cy - 1] += this.current();
      this.lines.splice(this.cy, 1);
      this.cy--;
      this.cx = prevLen;
      this.dirty = true;
    }
  }

  del() {
    const line = this.current();
    if (this.cx < line.length) {
      this.lines[this.cy] = line.slice(0, this.cx) + line.slice(this.cx + 1);
      this.dirty = true;
    } else if (this.cy < this.lines.length - 1) {
      this.lines[this.cy] += this.lines[this.cy + 1];
      this.lines.splice(this.cy + 1, 1);
      this.dirty = true;
    }
  }

  save() {
    if (!this.file) return false;
    fs.writeFileSync(this.file, this.lines.join('\n'));
    this.dirty = false;
    return true;
  }
}

class Editor {
  constructor(files) {
    this.buffers = files.length ? files.map((f) => new Buffer(f)) : [new Buffer(null)];
    this.index = 0;
    this.message = 'HELP: Ctrl-S = save | Ctrl-Q = quit | Ctrl-? = help';
    this.running = true;
  }

  get buf() {
    return this.buffers[this.index];
  }

  size() {
    return {
      cols: Math.max(20, process.stdout.columns || 80),
      rows: Math.max(5, process.stdout.rows || 24),
    };
  }

  scroll() {
    const b = this.buf;
    const { cols, rows } = this.size();
    const textRows = rows - 2;
    if (b.cy < b.rowoff) b.rowoff = b.cy;
    if (b.cy >= b.rowoff + textRows) b.rowoff = b.cy - textRows + 1;
    if (b.cx < b.coloff) b.coloff = b.cx;
    if (b.cx >= b.coloff + cols) b.coloff = b.cx - cols + 1;
  }

  draw() {
    this.scroll();
    const b = this.buf;
    const { cols, rows } = this.size();
    const textRows = rows - 2;
    let out = '\x1b[?25l\x1b[H';
    for (let y = 0; y < textRows; y++) {
      const fileRow = y + b.rowoff;
      if (fileRow >= b.lines.length) {
        out += '~';
      } else {
        out += b.lines[fileRow].slice(b.coloff, b.coloff + cols).replace(/\t/g, '    ');
      }
      out += '\x1b[K\r\n';
    }
    const name = b.file ? path.basename(b.file) : '[No Name]';
    const dirty = b.dirty ? '(modified)' : '';
    const left = ` ${name} ${dirty}`;
    const right = ` ${b.cy + 1}/${b.lines.length} `;
    const pad = Math.max(0, cols - left.length - right.length);
    out += '\x1b[7m' + (left + ' '.repeat(pad) + right).slice(0, cols) + '\x1b[m\r\n';
    out += (this.message || '').slice(0, cols) + '\x1b[K';
    const cx = b.cx - b.coloff + 1;
    const cy = b.cy - b.rowoff + 1;
    out += `\x1b[${Math.max(1, cy)};${Math.max(1, cx)}H\x1b[?25h`;
    process.stdout.write(out);
  }

  quit() {
    this.running = false;
    process.stdout.write('\x1b[?25h\x1b[H\x1b[2J');
    process.exit(0);
  }

  showHelp() {
    process.stdout.write('\x1b[H\x1b[2J' + helpText());
    this.message = 'Press any key to return';
  }

  handle(data) {
    const s = data.toString('utf8');
    const b = this.buf;
    if (s === '\x11') this.quit();
    else if (s === '\x13') this.message = b.save() ? 'File saved' : 'No file name';
    else if (s === '\x18') { this.index = (this.index + 1) % this.buffers.length; this.message = ''; }
    else if (s === '\x1bx') { this.index = (this.index + this.buffers.length - 1) % this.buffers.length; this.message = ''; }
    else if (s === '\x7f' || s === '\b') b.backspace();
    else if (s === '\x04' || s === '\x1b[3~') b.del();
    else if (s === '\r' || s === '\n') b.newline();
    else if (s === '\x01' || s === '\x1b[H' || s === '\x1b[1~') b.cx = 0;
    else if (s === '\x05' || s === '\x1b[F' || s === '\x1b[4~') b.cx = b.current().length;
    else if (s === '\x10' || s === '\x1b[A') { b.cy--; b.clamp(); }
    else if (s === '\x0e' || s === '\x1b[B') { b.cy++; b.clamp(); }
    else if (s === '\x02' || s === '\x1b[D') { if (b.cx > 0) b.cx--; else if (b.cy > 0) { b.cy--; b.cx = b.current().length; } }
    else if (s === '\x06' || s === '\x1b[C') { if (b.cx < b.current().length) b.cx++; else if (b.cy < b.lines.length - 1) { b.cy++; b.cx = 0; } }
    else if (s === '\x0c') this.message = '';
    else if (s === '\x7f' || s === '\x1b[3~') b.del();
    else if (s === '\x1f') this.showHelp();
    else if (/^[\x20-\x7e]+$/.test(s)) b.insert(s);
    else if ([...s].every((ch) => ch >= ' ' && ch !== '\x7f')) b.insert(s);
    b.clamp();
    if (this.running) this.draw();
  }

  run() {
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', (d) => this.handle(d));
    process.on('SIGINT', () => this.quit());
    process.on('SIGTERM', () => this.quit());
    process.stdout.write('\x1b[?1049h\x1b[H\x1b[2J');
    this.draw();
  }
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.version) {
    process.stdout.write(VERSION + '\n');
    return;
  }
  if (args.help) {
    process.stdout.write(helpText());
    return;
  }
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    process.stderr.write('Error: Inappropriate ioctl for device (os error 25)\n');
    process.exit(1);
  }
  try {
    new Editor(args.files).run();
  } catch (e) {
    process.stderr.write('Error: ' + e.message + '\n');
    process.exit(1);
  }
}

main();
