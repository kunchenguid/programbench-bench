#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const VERSION = '2.6.0-g87c9c25';

const HELP = `tig ${VERSION} 

Usage: tig        [options] [revs] [--] [paths]
   or: tig log    [options] [revs] [--] [paths]
   or: tig show   [options] [revs] [--] [paths]
   or: tig reflog [options] [revs]
   or: tig blame  [options] [rev] [--] path
   or: tig grep   [options] [pattern]
   or: tig refs   [options]
   or: tig stash  [options]
   or: tig status
   or: tig <      [git command output]

Options:
  +<number>       Select line <number> in the first view
  -v, --version   Show version and exit
  -h, --help      Show help message and exit
  -C <path>       Start in <path>
`;

function writeStdout(s) { process.stdout.write(s); }
function die(msg, code = 1) { process.stderr.write(`tig: ${msg}\n`); process.exit(code); }

function run(cmd, args, opts = {}) {
  const res = spawnSync(cmd, args, {
    cwd: opts.cwd || process.cwd(),
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  if (res.error) die(res.error.message);
  if (res.stdout) process.stdout.write(res.stdout);
  if (res.stderr) process.stderr.write(res.stderr);
  process.exit(res.status == null ? 1 : res.status);
}

function parseArgs(argv) {
  const args = argv.slice();
  let cwd = process.cwd();
  const rest = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '-C') {
      const p = args[++i];
      if (p) {
        const next = path.resolve(cwd, p);
        try {
          const st = fs.statSync(next);
          if (!st.isDirectory()) die(`Failed to change directory to ${p}`);
        } catch (_) {
          die(`Failed to change directory to ${p}`);
        }
        cwd = next;
      }
      continue;
    }
    rest.push(a);
  }
  return { cwd, args: rest };
}

function main() {
  const parsed = parseArgs(process.argv.slice(2));
  const args = parsed.args;

  if (args.includes('-h') || args.includes('--help')) {
    writeStdout(HELP);
    return;
  }
  if (args.includes('-v') || args.includes('--version')) {
    writeStdout(`tig version ${VERSION}\nncursesw version 6.3.20211021\n`);
    return;
  }

  if (args.some(a => /^\+/.test(a) && !/^\+\d+$/.test(a))) {
    die('No revisions match the given arguments.');
  }

  // The reference program is an ncurses application. In the cleanroom's
  // non-interactive executions it fails before opening any view with this
  // diagnostic, even for pager input.
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    die('Failed to open tty for input');
  }

  const cleaned = args.filter(a => !/^\+\d+$/.test(a));
  const sub = cleaned[0];
  const tail = cleaned.slice(1);

  switch (sub) {
    case 'status':
      run('git', ['status', '--short'], { cwd: parsed.cwd });
      break;
    case 'log':
      run('git', ['log', '--oneline', '--decorate', ...tail], { cwd: parsed.cwd });
      break;
    case 'show':
      run('git', ['show', ...tail], { cwd: parsed.cwd });
      break;
    case 'reflog':
      run('git', ['reflog', ...tail], { cwd: parsed.cwd });
      break;
    case 'blame':
      run('git', ['blame', ...tail], { cwd: parsed.cwd });
      break;
    case 'grep':
      run('git', ['grep', ...tail], { cwd: parsed.cwd });
      break;
    case 'refs':
      run('git', ['show-ref', ...tail], { cwd: parsed.cwd });
      break;
    case 'stash':
      run('git', ['stash', 'list', ...tail], { cwd: parsed.cwd });
      break;
    default:
      run('git', ['log', '--oneline', '--decorate', ...cleaned], { cwd: parsed.cwd });
  }
}

main();
