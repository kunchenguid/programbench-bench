#!/usr/bin/env node
'use strict';

const fs = require('fs');

const USAGE = `Usage:
    go test ./... -json | tparse [options...]
    go test [packages...] -json | tparse [options...]
    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out

Options:
    -h                 Show help.
    -v                 Show version.
    -all               Display table event for pass and skip. (Failed items always displayed)
    -pass              Display table for passed tests.
    -skip              Display table for skipped tests.
    -notests           Display packages containing no test files or empty test files.
    -smallscreen       Split subtest names vertically to fit on smaller screens.
    -slow              Number of slowest tests to display. Default is 0, display all.
    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.
    -nocolor           Disable all colors. (NO_COLOR also supported)
    -format            The output format for tables [basic, plain, markdown]. Default is basic.
    -file              Read test output from a file.
    -follow            Follow raw output from go test to stdout.
    -follow-output     Write raw output from go test to a file (takes precedence over -follow).
    -include-timestamp Include timestamps in follow output. 
    -progress          Print a single summary line for each package. Useful for long running test suites.
    -compare           Compare against a previous test output file. (experimental)
    -trimpath          Remove path prefix from package names in output, simplifying their display.`;

function dieFlag(name) {
  process.stderr.write(`flag provided but not defined: ${name}\n${USAGE}\n`);
  process.exit(2);
}

function parseArgs(argv) {
  const opts = {
    all: false, pass: false, skip: false, notests: false, smallscreen: false,
    slow: 0, sort: 'name', nocolor: false, format: 'basic', file: null,
    follow: false, followOutput: null, includeTimestamp: false, progress: false,
    compare: null, trimpath: null,
  };
  const needValue = new Set(['-slow', '-sort', '-format', '-file', '-follow-output', '-compare', '-trimpath']);
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    let val = null;
    if (a.includes('=') && a.startsWith('-')) {
      const p = a.indexOf('=');
      val = a.slice(p + 1);
      a = a.slice(0, p);
    }
    const getVal = () => {
      if (val !== null) return val;
      if (i + 1 >= argv.length) return '';
      return argv[++i];
    };
    switch (a) {
      case '-h':
      case '--help':
        process.stdout.write(USAGE + '\n');
        process.exit(0);
      case '-v':
        process.stdout.write('tparse version: (devel)\n');
        process.exit(0);
      case '-all': opts.all = true; break;
      case '-pass': opts.pass = true; break;
      case '-skip': opts.skip = true; break;
      case '-notests': opts.notests = true; break;
      case '-smallscreen': opts.smallscreen = true; break;
      case '-nocolor': opts.nocolor = true; break;
      case '-follow': opts.follow = true; break;
      case '-include-timestamp': opts.includeTimestamp = true; break;
      case '-progress': opts.progress = true; break;
      case '-slow': opts.slow = parseInt(getVal(), 10) || 0; break;
      case '-sort': opts.sort = getVal(); break;
      case '-format': opts.format = getVal(); break;
      case '-file': opts.file = getVal(); break;
      case '-follow-output': opts.followOutput = getVal(); break;
      case '-compare': opts.compare = getVal(); break;
      case '-trimpath': opts.trimpath = getVal(); break;
      default:
        if (a.startsWith('-')) dieFlag(a);
        else dieFlag(a);
    }
    if (val !== null && needValue.has(a) && val === '') {}
  }
  if (!['basic', 'plain', 'markdown'].includes(opts.format)) {
    process.stderr.write(`invalid option:"${opts.format}". The -format flag must be one of: basic, plain or markdown\n`);
    process.exit(0);
  }
  if (!['name', 'elapsed', 'cover'].includes(opts.sort)) {
    process.stderr.write(`invalid option:"${opts.sort}". The -sort flag must be one of: name, elapsed or cover\n`);
    process.exit(0);
  }
  return opts;
}

function readAllStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch { return ''; }
}

function displayPkg(pkg, opts) {
  if (!pkg) return '';
  let out = pkg;
  if (opts.trimpath && out.startsWith(opts.trimpath)) out = out.slice(opts.trimpath.length);
  if (opts.smallscreen) {
    const parts = out.split('/').filter(Boolean);
    if (parts.length) out = parts[parts.length - 1];
  }
  return out;
}

function basePkg(pkg) {
  const parts = String(pkg || '').split('/').filter(Boolean);
  return parts[parts.length - 1] || pkg || '';
}

function parseEvents(text, opts, followWriter) {
  const packages = new Map();
  let parsable = 0;
  const getPkg = (name) => {
    if (!packages.has(name)) {
      packages.set(name, {
        name, action: '', elapsed: 0, cover: '--', pass: 0, fail: 0, skip: 0,
        tests: new Map(), failOutput: [], output: [], noTest: null, order: packages.size,
      });
    }
    return packages.get(name);
  };

  for (const line of text.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let ev;
    try { ev = JSON.parse(line); } catch { continue; }
    if (!ev || typeof ev !== 'object' || !ev.Action || !ev.Package) continue;
    parsable++;
    const pkg = getPkg(ev.Package);
    const output = ev.Output || '';
    if (output) {
      pkg.output.push(output);
      if (opts.follow || opts.followOutput) {
        const raw = opts.includeTimestamp && ev.Time ? `${ev.Time} ${output}` : output;
        if (followWriter) followWriter.write(raw); else process.stdout.write(raw);
      }
      const m = output.match(/coverage:\s+([0-9.]+%)\s+of statements/);
      if (m) pkg.cover = m[1];
      if (/\[no test files\]/.test(output)) pkg.noTest = '[no test files]';
      if (/\[no tests to run\]/.test(output)) pkg.noTest = '[no tests to run]';
    }
    if (ev.Test) {
      if (!pkg.tests.has(ev.Test)) {
        pkg.tests.set(ev.Test, { pkg: ev.Package, name: ev.Test, action: '', elapsed: 0, output: [], order: pkg.tests.size });
      }
      const t = pkg.tests.get(ev.Test);
      if (output) t.output.push(output);
      if (['pass', 'fail', 'skip'].includes(ev.Action)) {
        if (!t.action) pkg[ev.Action]++;
        else if (t.action !== ev.Action) { pkg[t.action] = Math.max(0, pkg[t.action] - 1); pkg[ev.Action]++; }
        t.action = ev.Action;
        t.elapsed = Number(ev.Elapsed || 0);
      }
    } else if (['pass', 'fail', 'skip'].includes(ev.Action)) {
      pkg.action = ev.Action;
      pkg.elapsed = Number(ev.Elapsed || 0);
      if (ev.Action === 'skip' && pkg.noTest == null && pkg.tests.size === 0) pkg.noTest = '[no test files]';
      if (opts.progress && !pkg.noTest?.includes('no test files')) {
        const status = ev.Action.toUpperCase();
        const suffix = pkg.noTest ? ` ${pkg.noTest}` : '';
        process.stdout.write(`[${status}]\t${pkg.elapsed.toFixed(2).padStart(9)}s\t${displayPkg(pkg.name, opts)}${suffix}\n`);
      }
    }
  }
  if (followWriter) followWriter.end();
  return { packages: Array.from(packages.values()), parsable };
}

function visibleLen(s) { return String(s).length; }
function pad(s, w, align = 'left') {
  s = String(s);
  const n = Math.max(0, w - visibleLen(s));
  if (align === 'right') return ' '.repeat(n) + s;
  if (align === 'center') return ' '.repeat(Math.floor(n / 2)) + s + ' '.repeat(Math.ceil(n / 2));
  return s + ' '.repeat(n);
}

function table(rows, headers, opts, aligns = []) {
  if (opts.format === 'markdown') return markdownTable(rows, headers);
  if (opts.format === 'plain') return plainTable(rows, headers, aligns);
  return boxTable(rows, headers, aligns);
}

function colWidths(rows, headers) {
  return headers.map((h, i) => Math.max(visibleLen(h), ...rows.map(r => visibleLen(r[i] ?? ''))));
}

function boxTable(rows, headers, aligns = []) {
  const widths = colWidths(rows, headers);
  const fmtRow = (r) => '│ ' + r.map((c, i) => pad(c ?? '', widths[i], aligns[i] || 'left')).join(' │ ') + ' │';
  const sep = (l, m, r, ch) => l + widths.map(w => ch.repeat(w + 2)).join(m) + r;
  return [
    sep('╭', '┬', '╮', '─'),
    fmtRow(headers),
    sep('├', '┼', '┤', '─'),
    ...rows.map(fmtRow),
    sep('╰', '┴', '╯', '─'),
  ].join('\n') + '\n';
}

function plainTable(rows, headers, aligns = []) {
  const widths = colWidths(rows, headers);
  const fmt = r => '  ' + r.map((c, i) => pad(c ?? '', widths[i], aligns[i] || 'left')).join('   ') + '  ';
  return [fmt(headers), fmt(headers.map(() => '')), ...rows.map(fmt)].join('\n') + '\n';
}

function markdownTable(rows, headers) {
  const widths = colWidths(rows, headers);
  const fmt = r => '| ' + r.map((c, i) => pad(c ?? '', widths[i], 'left')).join(' | ') + ' |';
  const sep = '|-' + widths.map(w => '-'.repeat(w)).join('-|-') + '-|';
  return [fmt(headers), sep, ...rows.map(fmt)].join('\n') + '\n';
}

function banner(status, pkg) {
  const msg = `   ${status}  package: ${pkg}   `;
  const w = msg.length;
  return `┏${'━'.repeat(w)}┓\n┃${msg}┃\n┗${'━'.repeat(w)}┛\n`;
}

function cleanFailOutput(t) {
  const markers = [];
  const lines = [];
  for (const o of t.output) {
    for (const raw of o.split(/\n/)) {
      if (!raw) continue;
      if (/^=== RUN/.test(raw)) continue;
      if (/^--- FAIL:/.test(raw)) { markers.push(raw); continue; }
      if (/^--- PASS:/.test(raw) || /^--- SKIP:/.test(raw)) continue;
      lines.push(raw);
    }
  }
  return markers.concat(lines).join('\n');
}

function sortTests(tests, sort) {
  const arr = tests.slice();
  if (sort === 'elapsed') arr.sort((a, b) => (a.pkg === b.pkg ? b.elapsed - a.elapsed : b.elapsed - a.elapsed));
  else arr.sort((a, b) => (a.pkg === b.pkg ? a.order - b.order : a.pkg.localeCompare(b.pkg)));
  return arr;
}

function sortPkgs(pkgs, sort) {
  const arr = pkgs.slice();
  if (sort === 'elapsed') arr.sort((a, b) => b.elapsed - a.elapsed);
  else if (sort === 'cover') arr.sort((a, b) => parseFloat(b.cover) - parseFloat(a.cover));
  else arr.sort((a, b) => displayPkg(a.name, currentOpts).localeCompare(displayPkg(b.name, currentOpts)));
  return arr;
}

let currentOpts = null;

function summarize(packages, opts) {
  currentOpts = opts;
  const realPkgs = packages.filter(p => !(p.noTest && !opts.notests && p.tests.size === 0));
  let out = '';

  let tests = [];
  for (const p of packages) {
    for (const t of p.tests.values()) {
      if (!t.action) continue;
      if (opts.all || (opts.pass && (t.action === 'pass' || t.action === 'fail')) || (opts.skip && (t.action === 'skip' || t.action === 'fail'))) tests.push(t);
    }
  }
  if (opts.slow > 0) tests = tests.sort((a, b) => b.elapsed - a.elapsed).slice(0, opts.slow);
  else tests = sortTests(tests, opts.sort);
  if (tests.length) {
    if (opts.format === 'markdown') {
      const byPkg = new Map();
      for (const t of tests) {
        if (!byPkg.has(t.pkg)) byPkg.set(t.pkg, []);
        byPkg.get(t.pkg).push(t);
      }
      for (const [pkgName, list] of byPkg) {
        const pc = list.filter(t => t.action === 'pass').length;
        const sc = list.filter(t => t.action === 'skip').length;
        const fc = list.filter(t => t.action === 'fail').length;
        out += `## 📦 Package **\`${displayPkg(pkgName, opts)}\`**\n\n`;
        out += `Tests: ✓ ${pc} passed | ${sc} skipped | ${fc} failed\n\n<details>\n\n<summary>Click for test summary</summary>\n\n`;
        out += table(list.map(t => [`  ${t.action.toUpperCase()}  `, `  ${t.elapsed.toFixed(2)}   `, t.name]), ['Status', 'Elapsed', 'Test'], opts);
        out += '</details>\n\n\n';
      }
    } else {
      const rows = [];
      let lastPkg = null;
      for (const t of tests) {
        if (lastPkg !== null && lastPkg !== t.pkg) rows.push(['', '', '', '']);
        rows.push([`  ${t.action.toUpperCase()}  `, ` ${t.elapsed.toFixed(2)}  `, t.name, displayPkg(t.pkg, opts)]);
        lastPkg = t.pkg;
      }
      out += table(rows, ['Status', 'Elapsed', 'Test', 'Package'], opts, ['center', 'center', 'left', 'left']);
    }
  }

  for (const p of packages.filter(p => p.action === 'fail')) {
    out += banner('FAIL', p.name) + '\n';
    const failTexts = [];
    for (const t of p.tests.values()) if (t.action === 'fail') failTexts.push(cleanFailOutput(t));
    out += failTexts.filter(Boolean).join('\n\n') + '\n\n';
  }
  for (const p of packages.filter(p => p.action === 'pass' && p.fail > 0)) {
    out += banner('PASS', p.name) + '\n\n';
    const failTexts = [];
    for (const t of p.tests.values()) if (t.action === 'fail') failTexts.push(cleanFailOutput(t));
    out += failTexts.filter(Boolean).join('\n\n') + '\n\n';
  }

  const rows = [];
  for (const p of sortPkgs(packages, opts.sort)) {
    if (p.noTest && !opts.notests && p.tests.size === 0) continue;
    if (p.noTest && p.tests.size === 0) {
      rows.push([' NOTEST ', ' 0.00s ', displayPkg(p.name, opts), ' -- ', ' -- ', ' -- ', ' -- ']);
      rows.push(['', '', p.noTest, '', '', '', '']);
    } else {
      const st = (p.action || (p.fail ? 'fail' : 'pass')).toUpperCase();
      rows.push([`  ${st}  `, ` ${p.elapsed.toFixed(2)}s `, displayPkg(p.name, opts), ` ${p.cover} `, ` ${p.pass}  `, ` ${p.fail}  `, ` ${p.skip}  `]);
    }
  }
  if (rows.length) {
    if (opts.format === 'markdown') out += table(rows, ['Status', 'Elapsed', 'Package', 'Cover', 'Pass', 'Fail', 'Skip'], opts);
    else out += table(rows, ['Status', 'Elapsed', 'Package', 'Cover', 'Pass', 'Fail', 'Skip'], opts, ['center','center','left','center','center','center','center']);
  }
  return out;
}

function compareOutput(current, opts) {
  if (!opts.compare) return '';
  let prevText = '';
  try { prevText = fs.readFileSync(opts.compare, 'utf8'); } catch { return `failed to read compare file: ${opts.compare}\n`; }
  const prev = parseEvents(prevText, {...opts, follow: false, followOutput: null}, null);
  const prevFails = new Set();
  for (const p of prev.packages) for (const t of p.tests.values()) if (t.action === 'fail') prevFails.add(`${p.name}/${t.name}`);
  const curFails = new Set();
  for (const p of current.packages) for (const t of p.tests.values()) if (t.action === 'fail') curFails.add(`${p.name}/${t.name}`);
  const fixed = [...prevFails].filter(x => !curFails.has(x));
  const added = [...curFails].filter(x => !prevFails.has(x));
  if (!fixed.length && !added.length) return '';
  let s = '\nComparison:\n';
  for (const x of added) s += `  NEW FAIL: ${x}\n`;
  for (const x of fixed) s += `  FIXED: ${x}\n`;
  return s;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  let text = '';
  try {
    text = opts.file ? fs.readFileSync(opts.file, 'utf8') : readAllStdin();
  } catch (e) {
    process.stderr.write(e.message + '\n');
    process.exit(1);
  }
  let followWriter = null;
  if (opts.followOutput) followWriter = fs.createWriteStream(opts.followOutput);
  const parsed = parseEvents(text, opts, followWriter);
  if (parsed.parsable === 0) {
    process.stderr.write('no parsable events: Make sure to run go test with -json flag\n');
    process.exit(1);
  }
  let out = summarize(parsed.packages, opts);
  out += compareOutput(parsed, opts);
  process.stdout.write(out);
  const failed = parsed.packages.some(p => p.action === 'fail');
  process.exit(failed ? 1 : 0);
}

main();
