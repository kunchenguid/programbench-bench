#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const HELP = `
Usage: ag [FILE-TYPE] [OPTIONS] PATTERN [PATH]

  Recursively search for PATTERN in PATH.
  Like grep or ack, but faster.

Example:
  ag -i foo /bar/

Output Options:
     --ackmate            Print results in AckMate-parseable format
  -A --after [LINES]      Print lines after match (Default: 2)
  -B --before [LINES]     Print lines before match (Default: 2)
     --[no]break          Print newlines between matches in different files
                          (Enabled by default)
  -c --count              Only print the number of matches in each file.
                          (This often differs from the number of matching lines)
     --[no]color          Print color codes in results (Enabled by default)
     --color-line-number  Color codes for line numbers (Default: 1;33)
     --color-match        Color codes for result match numbers (Default: 30;43)
     --color-path         Color codes for path names (Default: 1;32)
     --column             Print column numbers in results
     --[no]filename       Print file names (Enabled unless searching a single file)
  -H --[no]heading        Print file names before each file's matches
                          (Enabled by default)
  -C --context [LINES]    Print lines before and after matches (Default: 2)
     --[no]group          Same as --[no]break --[no]heading
  -g --filename-pattern PATTERN
                          Print filenames matching PATTERN
  -l --files-with-matches Only print filenames that contain matches
                          (don't print the matching lines)
  -L --files-without-matches
                          Only print filenames that don't contain matches
     --print-all-files    Print headings for all files searched, even those that
                          don't contain matches
     --[no]numbers        Print line numbers. Default is to omit line numbers
                          when searching streams
  -o --only-matching      Prints only the matching part of the lines
     --print-long-lines   Print matches on very long lines (Default: >2k characters)
     --passthrough        When searching a stream, print all lines even if they
                          don't match
     --silent             Suppress all log messages, including errors
     --stats              Print stats (files scanned, time taken, etc.)
     --stats-only         Print stats and nothing else.
                          (Same as --count when searching a single file)
     --vimgrep            Print results like vim's :vimgrep /pattern/g would
                          (it reports every match on the line)
  -0 --null --print0      Separate filenames with null (for 'xargs -0')

Search Options:
  -a --all-types          Search all files (doesn't include hidden files
                          or patterns from ignore files)
  -D --debug              Ridiculous debugging (probably not useful)
     --depth NUM          Search up to NUM directories deep (Default: 25)
  -f --follow             Follow symlinks
  -F --fixed-strings      Alias for --literal for compatibility with grep
  -G --file-search-regex  PATTERN Limit search to filenames matching PATTERN
     --hidden             Search hidden files (obeys .*ignore files)
  -i --ignore-case        Match case insensitively
     --ignore PATTERN     Ignore files/directories matching PATTERN
                          (literal file/directory names also allowed)
     --ignore-dir NAME    Alias for --ignore for compatibility with ack.
  -m --max-count NUM      Skip the rest of a file after NUM matches (Default: 10,000)
     --one-device         Don't follow links to other devices.
  -p --path-to-ignore STRING
                          Use .ignore file at STRING
  -Q --literal            Don't parse PATTERN as a regular expression
  -s --case-sensitive     Match case sensitively
  -S --smart-case         Match case insensitively unless PATTERN contains
                          uppercase characters (Enabled by default)
     --search-binary      Search binary files for matches
  -t --all-text           Search all text files (doesn't include hidden files)
  -u --unrestricted       Search all files (ignore .ignore, .gitignore, etc.;
                          searches binary and hidden files as well)
  -U --skip-vcs-ignores   Ignore VCS ignore files
                          (.gitignore, .hgignore; still obey .ignore)
  -v --invert-match
  -w --word-regexp        Only match whole words
  -W --width NUM          Truncate match lines after NUM characters
  -z --search-zip         Search contents of compressed (e.g., gzip) files

File Types:
The search can be restricted to certain types of files. Example:
  ag --html needle
  - Searches for 'needle' in files with suffix .htm, .html, .shtml or .xhtml.

For a list of supported file types run:
  ag --list-file-types

ag was originally created by Geoff Greer. More information (and the latest release)
can be found at http://geoff.greer.fm/ag`;

const TYPE_TEXT = `The following file types are supported:
  --actionscript
      .as  .mxml

  --ada
      .ada  .adb  .ads

  --asciidoc
      .adoc  .ad  .asc  .asciidoc

  --asm
      .asm  .s

  --cc
      .c  .h  .xs

  --cpp
      .cpp  .cc  .C  .cxx  .m  .hpp  .hh  .h  .H  .hxx  .tpp

  --csharp
      .cs

  --css
      .css

  --go
      .go

  --html
      .htm  .html  .shtml  .xhtml

  --java
      .java  .properties

  --js
      .es6  .js  .jsx  .vue

  --json
      .json

  --markdown
      .markdown  .mdown  .mdwn  .mkdn  .mkd  .md

  --md
      .markdown  .mdown  .mdwn  .mkdn  .mkd  .md

  --perl
      .pl  .pm  .pm6  .pod  .t

  --php
      .php  .phpt  .php3  .php4  .php5  .phtml

  --python
      .py

  --ruby
      .rb  .rhtml  .rjs  .rxml  .erb  .rake  .spec

  --rust
      .rs

  --shell
      .sh  .bash  .csh  .tcsh  .ksh  .zsh  .fish

  --ts
      .ts  .tsx

  --xml
      .xml  .dtd  .xsl  .xslt  .xsd  .ent  .tld  .plist  .wsdl

  --yaml
      .yaml  .yml
`;

const typeMap = {
  actionscript:['.as','.mxml'], ada:['.ada','.adb','.ads'], asciidoc:['.adoc','.ad','.asc','.asciidoc'],
  asm:['.asm','.s'], cc:['.c','.h','.xs'], c:['.c','.h'], h:['.h'], cpp:['.cpp','.cc','.C','.cxx','.m','.hpp','.hh','.h','.H','.hxx','.tpp'],
  csharp:['.cs'], css:['.css'], go:['.go'], html:['.htm','.html','.shtml','.xhtml'], java:['.java','.properties'],
  js:['.es6','.js','.jsx','.vue'], json:['.json'], markdown:['.markdown','.mdown','.mdwn','.mkdn','.mkd','.md'], md:['.markdown','.mdown','.mdwn','.mkdn','.mkd','.md'],
  perl:['.pl','.pm','.pm6','.pod','.t'], php:['.php','.phpt','.php3','.php4','.php5','.phtml'], python:['.py'], py:['.py'],
  ruby:['.rb','.rhtml','.rjs','.rxml','.erb','.rake','.spec'], rust:['.rs'], rs:['.rs'], shell:['.sh','.bash','.csh','.tcsh','.ksh','.zsh','.fish'],
  ts:['.ts','.tsx'], xml:['.xml','.dtd','.xsl','.xslt','.xsd','.ent','.tld','.plist','.wsdl'], yaml:['.yaml','.yml']
};

function out(s='') { process.stdout.write(s + '\n'); }
function err(s='') { process.stderr.write(s + '\n'); }
function escapeRe(s) { return s.replace(/[\\^$.*+?()[\]{}|]/g, '\\$&'); }
function nextVal(args, i, def) {
  if (i + 1 < args.length && !args[i + 1].startsWith('-')) return [args[i + 1], i + 1];
  return [def, i];
}

const opt = {
  ignoreCase: null, smart: true, literal: false, word: false, invert: false,
  after: 0, before: 0, column: false, count: false, filesWith: false, filesWithout: false,
  only: false, vimgrep: false, print0: false, numbers: null, filename: null,
  hidden: false, unrestricted: false, allTypes: false, allText: false, norecurse: false,
  depth: 25, maxCount: 10000, fileRegex: null, filenamePattern: false, typeExts: null,
  passthrough: false, width: null, searchBinary: false, silent: false, ignores: []
};
const positional = [];
const args = process.argv.slice(2);
for (let i = 0; i < args.length; i++) {
  let a = args[i];
  if (a === '--') { positional.push(...args.slice(i + 1)); break; }
  if (!a.startsWith('-') || a === '-') { positional.push(a); continue; }
  if (a === '--help' || a === '-h') { out(HELP); process.exit(0); }
  if (a === '--version' || a === '-V') { out('ag version 2.2.0\n\nFeatures:\n  +jit +lzma +zlib'); process.exit(0); }
  if (a === '--list-file-types') {
    try { process.stdout.write(fs.readFileSync(path.join(__dirname, 'type-list.txt'), 'utf8')); }
    catch { process.stdout.write(TYPE_TEXT); }
    process.exit(0);
  }
  if (a in {'--nocolor':1,'--color':1,'--nogroup':1,'--group':1,'--noheading':1,'--heading':1,'-H':1,'--break':1,'--nobreak':1,'--ackmate':1,'--stats':1,'--stats-only':1,'--pager':1,'--nopager':1,'--parallel':1,'--print-long-lines':1,'--mmap':1,'--nommap':1,'--multiline':1,'--nomultiline':1,'--workers':1,'--one-device':1,'--affinity':1,'--noaffinity':1,'--search-zip':1}) {
    if (['--pager','--workers'].includes(a)) i++;
    continue;
  }
  if (a === '-i' || a === '--ignore-case') { opt.ignoreCase = true; opt.smart = false; continue; }
  if (a === '-s' || a === '--case-sensitive') { opt.ignoreCase = false; opt.smart = false; continue; }
  if (a === '-S' || a === '--smart-case') { opt.smart = true; continue; }
  if (a === '-Q' || a === '--literal' || a === '-F' || a === '--fixed-strings') { opt.literal = true; continue; }
  if (a === '-w' || a === '--word-regexp') { opt.word = true; continue; }
  if (a === '-v' || a === '--invert-match') { opt.invert = true; continue; }
  if (a === '-c' || a === '--count') { opt.count = true; continue; }
  if (a === '-l' || a === '--files-with-matches') { opt.filesWith = true; continue; }
  if (a === '-L' || a === '--files-without-matches') { opt.filesWithout = true; continue; }
  if (a === '-o' || a === '--only-matching') { opt.only = true; continue; }
  if (a === '--vimgrep') { opt.vimgrep = true; opt.column = true; continue; }
  if (a === '--column') { opt.column = true; continue; }
  if (a === '--numbers') { opt.numbers = true; continue; }
  if (a === '--nonumbers') { opt.numbers = false; continue; }
  if (a === '--filename') { opt.filename = true; continue; }
  if (a === '--nofilename') { opt.filename = false; continue; }
  if (a === '-0' || a === '--null' || a === '--print0') { opt.print0 = true; continue; }
  if (a === '--hidden') { opt.hidden = true; continue; }
  if (a === '-u' || a === '--unrestricted') { opt.unrestricted = true; opt.hidden = true; opt.searchBinary = true; continue; }
  if (a === '-a' || a === '--all-types') { opt.allTypes = true; continue; }
  if (a === '-t' || a === '--all-text') { opt.allText = true; continue; }
  if (a === '-n' || a === '--norecurse') { opt.norecurse = true; opt.depth = 0; continue; }
  if (a === '-r' || a === '--recurse') { opt.norecurse = false; continue; }
  if (a === '-f' || a === '--follow') continue;
  if (a === '--search-binary') { opt.searchBinary = true; continue; }
  if (a === '--passthrough' || a === '--passthru') { opt.passthrough = true; continue; }
  if (a === '--silent') { opt.silent = true; continue; }
  if (a === '-A' || a === '--after') { let r = nextVal(args, i, '2'); opt.after = +r[0] || 0; i = r[1]; continue; }
  if (a.startsWith('-A') && a.length > 2) { opt.after = +a.slice(2) || 0; continue; }
  if (a === '-B' || a === '--before') { let r = nextVal(args, i, '2'); opt.before = +r[0] || 0; i = r[1]; continue; }
  if (a.startsWith('-B') && a.length > 2) { opt.before = +a.slice(2) || 0; continue; }
  if (a === '-C' || a === '--context') { let r = nextVal(args, i, '2'); opt.before = opt.after = +r[0] || 0; i = r[1]; continue; }
  if (a.startsWith('-C') && a.length > 2) { opt.before = opt.after = +a.slice(2) || 0; continue; }
  if (a === '-m' || a === '--max-count') { opt.maxCount = +(args[++i] || 0) || Infinity; continue; }
  if (a === '--depth') { opt.depth = +(args[++i] || 0); continue; }
  if (a === '-W' || a === '--width') { opt.width = +(args[++i] || 0) || null; continue; }
  if (a === '-G' || a === '--file-search-regex') { opt.fileRegex = new RegExp(args[++i] || ''); continue; }
  if (a === '-g' || a === '--filename-pattern') { opt.filenamePattern = true; positional.push(args[++i] || ''); continue; }
  if (a === '--ignore' || a === '--ignore-dir') { opt.ignores.push(args[++i] || ''); continue; }
  if (a === '-p' || a === '--path-to-ignore') {
    try {
      const body = fs.readFileSync(args[++i] || '', 'utf8');
      opt.ignores.push(...body.split(/\r?\n/).map(x => x.trim()).filter(x => x && !x.startsWith('#')));
    } catch {}
    continue;
  }
  if (a === '--color-line-number' || a === '--color-match' || a === '--color-path') { i++; continue; }
  if (a.startsWith('--') && typeMap[a.slice(2)]) { opt.typeExts = typeMap[a.slice(2)]; continue; }
  const self = path.basename(process.argv[1]) === 'app.js' ? './executable' : process.argv[1];
  err(`${self}: unrecognized option '${a}'`);
  out(HELP);
  process.exit(1);
}

if (positional.length === 0) {
  if (!opt.silent) err('ERR: What do you want to search for?');
  process.exit(1);
}

const pattern = positional[0];
const paths = positional.slice(1);
const stdinMode = paths.length === 0 && !process.stdin.isTTY;
const rootPaths = paths.length ? paths : ['.'];

let source = opt.literal ? escapeRe(pattern) : pattern;
if (opt.word) source = `\\b(?:${source})\\b`;
let flags = 'g';
const hasUpper = /[A-Z]/.test(pattern);
if (opt.ignoreCase === true || (opt.smart && !hasUpper)) flags += 'i';
let re;
try { re = new RegExp(source, flags); } catch(e) { if (!opt.silent) err(`ERR: ${e.message}`); process.exit(1); }
const fileNameRe = opt.filenamePattern ? re : null;

function shouldSkipName(name) {
  if (opt.unrestricted) return false;
  if (!opt.hidden && name.startsWith('.')) return true;
  if (['.git','.hg','.svn','node_modules'].includes(name)) return true;
  return false;
}
function globToRe(glob) {
  let g = glob.trim();
  if (!g || g.startsWith('#')) return null;
  g = g.replace(/^\//, '').replace(/\/$/, '');
  return new RegExp('(^|/)' + escapeRe(g).replace(/\\\*/g, '[^/]*').replace(/\\\?/g, '[^/]') + '($|/)');
}
function loadIgnorePatterns(dir, parent) {
  if (opt.unrestricted || opt.allTypes) return parent;
  const pats = parent.slice();
  for (const name of ['.ignore', '.gitignore', '.hgignore']) {
    const f = path.join(dir, name);
    try {
      const body = fs.readFileSync(f, 'utf8');
      pats.push(...body.split(/\r?\n/).map(globToRe).filter(Boolean));
    } catch {}
  }
  return pats;
}
function ignoredByPatterns(p, patterns) {
  if (opt.unrestricted || opt.allTypes) return false;
  const rp = rel(p);
  return patterns.some(re => re.test(rp) || re.test(path.basename(p)));
}
function isBinary(buf) {
  const n = Math.min(buf.length, 8192);
  for (let i = 0; i < n; i++) if (buf[i] === 0) return true;
  return false;
}
function walk(p, depth=0, acc=[], patterns=opt.ignores.map(globToRe).filter(Boolean)) {
  let st;
  try { st = fs.statSync(p); } catch { return acc; }
  if (st.isDirectory()) {
    if (depth > 0 && shouldSkipName(path.basename(p))) return acc;
    if (depth > 0 && ignoredByPatterns(p, patterns)) return acc;
    if (opt.norecurse && depth > 0) return acc;
    if (opt.depth >= 0 && depth > opt.depth) return acc;
    const nextPatterns = loadIgnorePatterns(p, patterns);
    let entries = [];
    try { entries = fs.readdirSync(p).sort(); } catch { return acc; }
    for (const e of entries) walk(path.join(p, e), depth + 1, acc, nextPatterns);
  } else if (st.isFile()) {
    const base = path.basename(p);
    if (shouldSkipName(base)) return acc;
    if (ignoredByPatterns(p, patterns)) return acc;
    if (opt.fileRegex && !opt.fileRegex.test(p)) return acc;
    if (opt.typeExts && !opt.typeExts.includes(path.extname(p))) return acc;
    acc.push(p);
  }
  return acc;
}
function allFiles() {
  let files = [];
  for (const p of rootPaths) files = files.concat(walk(p));
  return files;
}
function rel(p) {
  const r = path.relative(process.cwd(), p);
  return r || p;
}
function readText(p) {
  let buf;
  try { buf = fs.readFileSync(p); } catch { return null; }
  if (!opt.searchBinary && !opt.allTypes && !opt.allText && isBinary(buf)) return null;
  return buf.toString('utf8').replace(/\r\n/g, '\n');
}
function matchesInLine(line) {
  re.lastIndex = 0;
  const out = [];
  let m;
  while ((m = re.exec(line)) !== null) {
    out.push({text: m[0], index: m.index});
    if (m[0].length === 0) re.lastIndex++;
  }
  return out;
}
function lineMatches(line) {
  const ok = matchesInLine(line).length > 0;
  return opt.invert ? !ok : ok;
}
function prefix(file, lineNo, col, sep=':') {
  if (file !== null && opt.numbers !== false && lineNo !== null) {
    let s = file + ':' + lineNo;
    if (opt.column && col !== null) s += ':' + col;
    return s + sep;
  }
  let parts = [];
  if (file !== null) parts.push(file);
  if (opt.numbers !== false && lineNo !== null) parts.push(String(lineNo));
  if (opt.column && col !== null) parts.push(String(col));
  return parts.length ? parts.join(':') + sep : '';
}
function truncate(s) { return opt.width && s.length > opt.width ? s.slice(0, opt.width) : s; }

let found = false;
let printed = false;
if (stdinMode) {
  const text = fs.readFileSync(0, 'utf8').replace(/\r\n/g, '\n');
  const lines = text.endsWith('\n') ? text.slice(0, -1).split('\n') : text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const ms = matchesInLine(lines[i]);
    const ok = opt.invert ? ms.length === 0 : ms.length > 0;
    if (ok || opt.passthrough) {
      found ||= ok;
      const ln = opt.numbers ? i + 1 : null;
      if (opt.only && ok && !opt.invert) for (const m of ms) out(prefix(null, ln, m.index + 1) + m.text);
      else out(prefix(null, ln, ms[0] ? ms[0].index + 1 : null) + truncate(lines[i]));
    }
  }
  process.exit(found ? 0 : 1);
}

const files = allFiles();
const singleInputFile = paths.length === 1 && (() => { try { return fs.statSync(paths[0]).isFile(); } catch { return false; } })();
const showFile = opt.filename === true || (opt.filename !== false && !singleInputFile);

if (opt.filenamePattern) {
  const sep = opt.print0 ? '\0' : '\n';
  const names = files.map(rel).filter(f => { fileNameRe.lastIndex = 0; return fileNameRe.test(f); });
  if (names.length) process.stdout.write(names.join(sep) + sep);
  process.exit(names.length ? 0 : 1);
}

for (const f of files) {
  const text = readText(f);
  if (text === null) continue;
  const lines = text.endsWith('\n') ? text.slice(0, -1).split('\n') : text.split('\n');
  const fileLabel = showFile ? rel(f) : null;
  const matchLines = [];
  let matchCount = 0;
  for (let i = 0; i < lines.length; i++) {
    const ms = matchesInLine(lines[i]);
    const ok = opt.invert ? ms.length === 0 : ms.length > 0;
    if (ok) {
      matchLines.push({i, ms});
      matchCount += opt.invert ? 1 : ms.length;
      if (matchLines.length >= opt.maxCount) break;
    }
  }
  if (matchLines.length) found = true;
  if (opt.filesWith || opt.filesWithout) {
    if ((opt.filesWith && matchLines.length) || (opt.filesWithout && !matchLines.length)) {
      process.stdout.write(rel(f) + (opt.print0 ? '\0' : '\n'));
      printed = true;
    }
    continue;
  }
  if (opt.count) {
    if (matchLines.length) out((showFile ? rel(f) + ':' : '') + matchCount);
    continue;
  }
  if (!matchLines.length) continue;
  if (opt.only && !opt.invert) {
    for (const ml of matchLines) {
      for (const m of ml.ms) out(prefix(fileLabel, ml.i + 1, m.index + 1) + m.text);
    }
    continue;
  }
  if (opt.vimgrep && !opt.invert) {
    for (const ml of matchLines) {
      for (const m of ml.ms) out(prefix(fileLabel, ml.i + 1, m.index + 1) + truncate(lines[ml.i]));
    }
    continue;
  }
  const emit = new Map();
  for (const ml of matchLines) {
    for (let j = Math.max(0, ml.i - opt.before); j <= Math.min(lines.length - 1, ml.i + opt.after); j++) {
      const isM = j === ml.i || matchLines.some(x => x.i === j);
      if (!emit.has(j)) emit.set(j, isM);
    }
  }
  for (const j of Array.from(emit.keys()).sort((a,b)=>a-b)) {
    const isM = emit.get(j);
    const ms = matchesInLine(lines[j]);
    const col = ms[0] ? ms[0].index + 1 : null;
    out(prefix(fileLabel, j + 1, col, isM ? ':' : '-') + truncate(lines[j]));
  }
}
process.exit((found || printed) ? 0 : 1);
