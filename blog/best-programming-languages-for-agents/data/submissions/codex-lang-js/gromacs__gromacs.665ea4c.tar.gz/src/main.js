#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "2027.0-dev-20260414-24ac8ab-unknown";
const HASH = "24ac8abecd15814143951f211394c29bdfc42e13";
const URL = "https://manual.gromacs.org/current/user-guide/run-time-errors.html";
const quote = 'GROMACS reminds you: "That Was Cool" (Beavis and Butthead)';

const commands = [
  ["anaeig", "Analyze eigenvectors/normal modes"],
  ["analyze", "Analyze data sets"],
  ["angle", "Calculate distributions and correlations for angles and dihedrals"],
  ["awh", "Extract data from an accelerated weight histogram (AWH) run"],
  ["bar", "Calculate free energy difference estimates through Bennett's acceptance ratio"],
  ["bundle", "Analyze bundles of axes, e.g., helices"],
  ["check", "Check and compare files"],
  ["chi", "Calculate everything you want to know about chi and other dihedrals"],
  ["cluster", "Cluster structures"],
  ["clustsize", "Calculate size distributions of atomic clusters"],
  ["confrms", "Fit two structures and calculates the RMSD"],
  ["convert-tpr", "Make a modified run-input file"],
  ["convert-trj", "Converts between different trajectory types"],
  ["covar", "Calculate and diagonalize the covariance matrix"],
  ["current", "Calculate dielectric constants and current autocorrelation function"],
  ["density", "Calculate the density of the system"],
  ["densmap", "Calculate 2D planar or axial-radial density maps"],
  ["densorder", "Calculate surface fluctuations"],
  ["dielectric", "Calculate frequency dependent dielectric constants"],
  ["dipoles", "Compute the total dipole plus fluctuations"],
  ["disre", "Analyze distance restraints"],
  ["distance", "Calculate distances between pairs of positions"],
  ["dos", "Analyze density of states and properties based on that"],
  ["dssp", "Calculate protein secondary structure via DSSP algorithm"],
  ["dump", "Make binary files human readable"],
  ["dyecoupl", "Extract dye dynamics from trajectories"],
  ["editconf", "Convert and manipulates structure files"],
  ["eneconv", "Convert energy files"],
  ["enemat", "Extract an energy matrix from an energy file"],
  ["energy", "Writes energies to xvg files and display averages"],
  ["extract-cluster", "Allows extracting frames corresponding to clusters from trajectory"],
  ["filter", "Frequency filter trajectories, useful for making smooth movies"],
  ["freevolume", "Calculate free volume"],
  ["gangle", "Calculate angles"],
  ["genconf", "Multiply a conformation in 'random' orientations"],
  ["genion", "Generate monoatomic ions on energetically favorable positions"],
  ["genrestr", "Generate position restraints or distance restraints for index groups"],
  ["grompp", "Make a run input file"],
  ["gyrate", "Calculate radius of gyration of a molecule"],
  ["gyrate-legacy", "Calculate the radius of gyration"],
  ["h2order", "Compute the orientation of water molecules"],
  ["hbond", "Compute and analyze hydrogen bonds."],
  ["hbond-legacy", "Compute and analyze hydrogen bonds"],
  ["helix", "Calculate basic properties of alpha helices"],
  ["helixorient", "Calculate local pitch/bending/rotation/orientation inside helices"],
  ["help", "Print help information"],
  ["hydorder", "Compute tetrahedrality parameters around a given atom"],
  ["insert-molecules", "Insert molecules into existing vacancies"],
  ["lie", "Estimate free energy from linear combinations"],
  ["make_edi", "Generate input files for essential dynamics sampling"],
  ["make_ndx", "Make index files"],
  ["mdmat", "Calculate residue contact maps"],
  ["mdrun", "Perform a simulation, do a normal mode analysis or an energy minimization"],
  ["mindist", "Calculate the minimum distance between two groups"],
  ["mk_angndx", "Generate index files for 'gmx angle'"],
  ["msd", "Compute mean squared displacements"],
  ["nmeig", "Diagonalize the Hessian for normal mode analysis"],
  ["nmens", "Generate an ensemble of structures from the normal modes"],
  ["nmr", "Analyze nuclear magnetic resonance properties from an energy file"],
  ["nmtraj", "Generate a virtual oscillating trajectory from an eigenvector"],
  ["nonbonded-benchmark", "Benchmarking tool for the non-bonded pair kernels."],
  ["order", "Compute the order parameter per atom for carbon tails"],
  ["pairdist", "Calculate pairwise distances between groups of positions"],
  ["pdb2gmx", "Convert coordinate files to topology and FF-compliant coordinate files"],
  ["pme_error", "Estimate the error of using PME with a given input file"],
  ["polystat", "Calculate static properties of polymers"],
  ["potential", "Calculate the electrostatic potential across the box"],
  ["principal", "Calculate principal axes of inertia for a group of atoms"],
  ["rama", "Compute Ramachandran plots"],
  ["rdf", "Calculate radial distribution functions"],
  ["report-methods", "Write short summary about the simulation setup to a text file and/or to the standard output."],
  ["rms", "Calculate RMSDs with a reference structure and RMSD matrices"],
  ["rmsdist", "Calculate atom pair distances averaged with power -2, -3 or -6"],
  ["rmsf", "Calculate atomic fluctuations"],
  ["rotacf", "Calculate the rotational correlation function for molecules"],
  ["rotmat", "Plot the rotation matrix for fitting to a reference structure"],
  ["saltbr", "Compute salt bridges"],
  ["sans-legacy", "Compute small angle neutron scattering spectra"],
  ["sasa", "Compute solvent accessible surface area"],
  ["saxs-legacy", "Compute small angle X-ray scattering spectra"],
  ["scattering", "Calculate small angle scattering profiles for SANS or SAXS"],
  ["select", "Print general information about selections"],
  ["sham", "Compute free energies or other histograms from histograms"],
  ["sigeps", "Convert c6/12 or c6/cn combinations to and from sigma/epsilon"],
  ["solvate", "Solvate a system"],
  ["sorient", "Analyze solvent orientation around solutes"],
  ["spatial", "Calculate the spatial distribution function"],
  ["spol", "Analyze solvent dipole orientation and polarization around solutes"],
  ["tcaf", "Calculate viscosities of liquids"],
  ["traj", "Plot x, v, f, box, temperature and rotational energy from trajectories"],
  ["trajectory", "Print coordinates, velocities, and/or forces for selections"],
  ["trjcat", "Concatenate trajectory files"],
  ["trjconv", "Convert and manipulates trajectory files"],
  ["trjorder", "Order molecules according to their distance to a group"],
  ["tune_pme", "Time mdrun as a function of PME ranks to optimize settings"],
  ["vanhove", "Compute Van Hove displacement and correlation functions"],
  ["velacc", "Calculate velocity autocorrelation functions"],
  ["wham", "Perform weighted histogram analysis after umbrella sampling"],
  ["wheel", "Plot helical wheels"],
  ["x2top", "Generate a primitive topology from coordinates"],
  ["xpm2ps", "Convert XPM (XPixelMap) matrices to postscript or XPM"],
];
const commandSet = new Set(commands.map((c) => c[0]));

function cwd() {
  return process.cwd();
}

function cmdLine(args) {
  return `Command line:\n  executable${args.length ? " " + args.join(" ") : ""}\n`;
}

function banner(name, args, quiet = false) {
  if (quiet) return "";
  const label = name ? `gmx ${name}` : "executable";
  return `       :-) GROMACS - ${label}, ${VERSION} (-:\n\n` +
    `Executable:   ${cwd()}/./executable\n` +
    `Data prefix:  /usr/local/gromacs\n` +
    `Working dir:  ${cwd()}\n` +
    cmdLine(args) + "\n";
}

function commonHelp() {
  return `SYNOPSIS\n\n` +
    `gmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]\n` +
    `    [-[no]backup]\n\n` +
    `OPTIONS\n\n` +
    `Other options:\n\n` +
    ` -[no]h                     (no)\n` +
    `           Print help and quit\n` +
    ` -[no]quiet                 (no)\n` +
    `           Do not print common startup info or quotes\n` +
    ` -[no]version               (no)\n` +
    `           Print extended version information and quit\n` +
    ` -[no]copyright             (no)\n` +
    `           Print copyright information on startup\n` +
    ` -nice   <int>              (19)\n` +
    `           Set the nicelevel (default depends on command)\n` +
    ` -[no]backup                (yes)\n` +
    `           Write backups if output files exist\n\n` +
    `Additional help is available on the following topics:\n` +
    `    commands    List of available commands\n` +
    `    selections  Selection syntax and usage\n` +
    `To access the help, use 'gmx help <topic>'.\n` +
    `For help on a command, use 'gmx help <command>'.\n`;
}

function versionText() {
  return `GROMACS version:     ${VERSION}\n` +
    `GIT SHA1 hash:       ${HASH}\n` +
    `Branched from:       unknown\n` +
    `Precision:           mixed\n` +
    `Memory model:        64 bit\n` +
    `MPI library:         thread_mpi\n` +
    `MPI version:         built in\n` +
    `OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)\n` +
    `GPU support:         disabled\n` +
    `SIMD instructions:   None\n` +
    `CPU FFT library:     fftw-3.3.10\n` +
    `GPU FFT library:     none\n` +
    `Multi-GPU FFT:       none\n` +
    `RDTSCP:              enabled\n` +
    `TNG support:         enabled\n` +
    `Hwloc support:       disabled\n` +
    `Tracing support:     disabled\n` +
    `Colvars support:     enabled (version 2025-10-13)\n` +
    `CP2K support:        disabled\n` +
    `Torch support:       disabled\n` +
    `Plumed support:      enabled\n` +
    `C compiler:          /usr/bin/cc GNU 11.4.0\n` +
    `C++ compiler:        /usr/bin/c++ GNU 11.4.0\n` +
    `BLAS library:        Internal\n` +
    `LAPACK library:      Internal\n`;
}

function copyrightText() {
  return `Copyright 1991-2027 The GROMACS Authors.\n` +
    `GROMACS is free software; you can redistribute it and/or modify it\n` +
    `under the terms of the GNU Lesser General Public License\n` +
    `as published by the Free Software Foundation; either version 2.1\n` +
    `of the License, or (at your option) any later version.\n\n` +
    `                         Current GROMACS contributors:\n` +
    `       Mark Abraham           Andrey Alekseenko           Brian Andrews\n` +
    `        Paul Bauer              Cathrine Bergh              Hugh Bird\n` +
    `      Eliane Briand               Ania Brown                Yiqi Chen\n` +
    `\n                  Coordinated by the GROMACS project leaders:\n` +
    `                           Berk Hess and Erik Lindahl\n\n`;
}

function commandsHelp() {
  let out = `LIST OF AVAILABLE COMMANDS\n\nUsage: gmx [<options>] <command> [<args>]\n\nAvailable commands:\n`;
  for (const [name, desc] of commands) {
    out += `    ${name.padEnd(20)} ${desc}\n`;
  }
  out += `For help on a command, use 'gmx help <command>'.\n`;
  return out;
}

function selectionsHelp(topic) {
  if (topic && topic !== "selections") {
    return `SELECTION ${topic.toUpperCase()}\n\nDetailed help for selection ${topic} is available in the GROMACS manual.\n`;
  }
  return `SELECTION SYNTAX AND USAGE\n\n` +
    `Selections are used to select atoms/molecules/residues for analysis. In\n` +
    `contrast to traditional index files, selections can be dynamic, i.e., select\n` +
    `different atoms for different trajectory frames. The GROMACS manual contains a\n` +
    `short introductory section to selections in the Analysis chapter, including\n` +
    `suggestions on how to get familiar with selections if you are new to the\n` +
    `concept. The subtopics listed below provide more details on the technical and\n` +
    `syntactic aspects of selections.\n\n` +
    `Available subtopics:\n` +
    `    arithmetic   Arithmetic expressions in selections\n` +
    `    cmdline      Specifying selections from command line\n` +
    `    evaluation   Selection evaluation and optimization\n` +
    `    examples     Selection examples\n` +
    `    keywords     Selection keywords\n` +
    `    limitations  Selection limitations\n` +
    `    positions    Specifying positions in selections\n` +
    `    syntax       Selection syntax\n`;
}

const detailed = {
  mdrun: `SYNOPSIS\n\n` +
    `gmx mdrun [-s [<.tpr>]] [-cpi [<.cpt>]] [-table [<.xvg>]] [-tablep [<.xvg>]]\n` +
    `          [-tableb [<.xvg> [...]]] [-rerun [<.xtc/.trr/...>]] [-ei [<.edi>]]\n` +
    `          [-multidir [<dir> [...]]] [-awh [<.xvg>]] [-plumed [<.dat>]]\n` +
    `          [-o [<.trr/.cpt/...>]] [-x [<.xtc/.tng>]] [-cpo [<.cpt>]]\n` +
    `          [-c [<.gro/.g96/...>]] [-e [<.edr>]] [-g [<.log>]] [-deffnm <string>]\n` +
    `          [-nt <int>] [-ntmpi <int>] [-ntomp <int>] [-[no]v] [-nsteps <int>]\n\n` +
    `DESCRIPTION\n\n` +
    `gmx mdrun is the main computational chemistry engine within GROMACS.\n` +
    `It performs Molecular Dynamics simulations, energy minimization, test particle\n` +
    `insertion, recalculation of energies, and normal mode analysis. The program\n` +
    `reads the run input file (-s) and writes trajectory, structure, energy and log\n` +
    `files.\n\n` +
    `OPTIONS\n\n` +
    `Options to specify input files:\n\n` +
    ` -s      [<.tpr>]           (topol.tpr)\n           Portable xdr run input file\n` +
    ` -cpi    [<.cpt>]           (state.cpt)      (Opt.)\n           Checkpoint file\n\n` +
    `Options to specify output files:\n\n` +
    ` -o      [<.trr/.cpt/...>]  (traj.trr)\n           Full precision trajectory: trr cpt tng h5md\n` +
    ` -x      [<.xtc/.tng>]      (traj_comp.xtc)  (Opt.)\n           Compressed trajectory\n` +
    ` -c      [<.gro/.g96/...>]  (confout.gro)\n           Structure file: gro g96 pdb brk ent esp\n` +
    ` -e      [<.edr>]           (ener.edr)\n           Energy file\n` +
    ` -g      [<.log>]           (md.log)\n           Log file\n\n` +
    `Other options:\n\n` +
    ` -deffnm <string>\n           Set the default filename for all file options\n` +
    ` -nt     <int>              (0)\n           Total number of threads to start (0 is guess)\n` +
    ` -[no]v                     (no)\n           Be loud and noisy\n` +
    ` -nsteps <int>              (-2)\n           Run this number of steps\n`,
  grompp: `SYNOPSIS\n\n` +
    `gmx grompp [-f [<.mdp>]] [-c [<.gro/.g96/...>]] [-r [<.gro/.g96/...>]]\n` +
    `           [-n [<.ndx>]] [-p [<.top>]] [-t [<.trr/.cpt/...>]] [-po [<.mdp>]]\n` +
    `           [-pp [<.top>]] [-o [<.tpr>]] [-[no]v] [-time <real>] [-maxwarn <int>]\n\n` +
    `DESCRIPTION\n\n` +
    `gmx grompp (the gromacs preprocessor) reads a molecular topology file, checks\n` +
    `the validity of the file, expands the topology from a molecular description to\n` +
    `an atomic description, reads coordinates and simulation parameters, and writes\n` +
    `a portable binary run input file for gmx mdrun.\n\n` +
    `OPTIONS\n\n` +
    `Options to specify input files:\n\n` +
    ` -f      [<.mdp>]           (grompp.mdp)\n           grompp input file with MD parameters\n` +
    ` -c      [<.gro/.g96/...>]  (conf.gro)\n           Structure file: gro g96 pdb brk ent esp tpr\n` +
    ` -p      [<.top>]           (topol.top)\n           Topology file\n\n` +
    `Options to specify output files:\n\n` +
    ` -po     [<.mdp>]           (mdout.mdp)\n           grompp input file with MD parameters\n` +
    ` -pp     [<.top>]           (processed.top)  (Opt.)\n           Topology file\n` +
    ` -o      [<.tpr>]           (topol.tpr)\n           Portable xdr run input file\n\n` +
    `Other options:\n\n` +
    ` -[no]v                     (no)\n           Be loud and noisy\n` +
    ` -time   <real>             (-1)\n           Take frame at or first after this time.\n` +
    ` -maxwarn <int>             (0)\n           Number of allowed warnings during input processing.\n`,
};

function genericCommandHelp(cmd) {
  const desc = commands.find((c) => c[0] === cmd)?.[1] || "GROMACS command";
  return `SYNOPSIS\n\n` +
    `gmx ${cmd} [-h] [<options>]\n\n` +
    `DESCRIPTION\n\n` +
    `gmx ${cmd} - ${desc}.\n\n` +
    `OPTIONS\n\n` +
    `Other options:\n\n` +
    ` -[no]h                     (no)\n           Print help and quit\n` +
    ` -[no]quiet                 (no)\n           Do not print common startup info or quotes\n`;
}

function fatal(program, body, source = "src/gromacs/options/options.cpp", line = 184, func = "void gmx::internal::OptionSectionImpl::finish()") {
  return `\n-------------------------------------------------------\n` +
    `Program:     ${program}, version ${VERSION}\n` +
    `Source file: ${source} (line ${line})\n` +
    `Function:    ${func}\n\n` +
    `Error in user input:\n${body}\n\n` +
    `For more information and tips for troubleshooting, please check the GROMACS\n` +
    `website at ${URL}\n` +
    `-------------------------------------------------------\n`;
}

function hasHelp(args) {
  return args.includes("-h") || args.includes("-help");
}

function argValue(args, opt) {
  const i = args.indexOf(opt);
  return i >= 0 && i + 1 < args.length ? args[i + 1] : undefined;
}

function existsWithExt(base, exts) {
  if (!base) return false;
  if (fs.existsSync(base)) return true;
  if (path.extname(base)) return false;
  return exts.some((e) => fs.existsSync(base + e));
}

function explicitFileError(args, specs) {
  const parts = [];
  for (const [opt, exts] of specs) {
    const v = argValue(args, opt);
    if (v && !existsWithExt(v, exts)) {
      if (path.extname(v)) {
        parts.push(`  In command-line option ${opt}\n    File '${v}' does not exist or is not accessible.\n    The file could not be opened.\n      Reason: No such file or directory\n      (call to fopen() returned error code 2)`);
      } else {
        parts.push(`  In command-line option ${opt}\n    File '${v}' does not exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      ${exts.join(", ")}`);
      }
    }
  }
  return parts.length ? "Invalid command-line options\n" + parts.join("\n") : null;
}

function missingForMdrun(args) {
  const explicit = explicitFileError(args, [["-s", [".tpr"]]]);
  if (explicit) return { body: explicit, parser: true };
  const s = "topol";
  if (!existsWithExt(s, [".tpr"])) {
    return "Invalid input values\n  In option s\n    Required option was not provided, and the default file 'topol' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .tpr";
  }
  return null;
}

function missingForGrompp(args) {
  const explicit = explicitFileError(args, [
    ["-f", [".mdp"]],
    ["-c", [".gro", ".g96", ".pdb", ".brk", ".ent", ".esp", ".tpr"]],
    ["-p", [".top"]],
  ]);
  if (explicit) return { body: explicit, parser: true };
  const parts = [];
  if (!existsWithExt(argValue(args, "-c") || "conf", [".gro", ".g96", ".pdb", ".brk", ".ent", ".esp", ".tpr"])) {
    parts.push("  In option c\n    Required option was not provided, and the default file 'conf' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .gro, .g96, .pdb, .brk, .ent, .esp, .tpr");
  }
  if (!existsWithExt(argValue(args, "-f") || "grompp", [".mdp"])) {
    parts.push("  In option f\n    Required option was not provided, and the default file 'grompp' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .mdp");
  }
  if (!existsWithExt(argValue(args, "-p") || "topol", [".top"])) {
    parts.push("  In option p\n    Required option was not provided, and the default file 'topol' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .top");
  }
  return parts.length ? { body: "Invalid input values\n" + parts.join("\n"), parser: false } : null;
}

function touch(file, content = "") {
  fs.writeFileSync(file, content);
}

function runGrompp(args, quiet) {
  if (hasHelp(args)) {
    process.stdout.write(banner("grompp", ["grompp", ...args], quiet) + detailed.grompp + (!quiet ? "\n" + quote + "\n" : ""));
    return 0;
  }
  const err = missingForGrompp(args);
  if (err) {
    process.stderr.write(banner("grompp", ["grompp", ...args], quiet) + (err.parser
      ? fatal("gmx grompp", err.body, "src/gromacs/commandline/cmdlineparser.cpp", 271, "void gmx::CommandLineParser::parse(int*, char**)")
      : fatal("gmx grompp", err.body)));
    return 1;
  }
  const out = argValue(args, "-o") || "topol.tpr";
  const po = argValue(args, "-po") || "mdout.mdp";
  touch(out, "Reimplemented portable run input placeholder\n");
  touch(po, "; Reimplemented grompp parameter output\n");
  process.stdout.write(banner("grompp", ["grompp", ...args], quiet) + "Generated " + out + "\n");
  return 0;
}

function runMdrun(args, quiet) {
  if (hasHelp(args)) {
    process.stdout.write(banner("mdrun", ["mdrun", ...args], quiet) + detailed.mdrun + (!quiet ? "\n" + quote + "\n" : ""));
    return 0;
  }
  const err = missingForMdrun(args);
  if (err) {
    const body = typeof err === "string" ? err : err.body;
    const parser = typeof err !== "string" && err.parser;
    process.stderr.write(banner("mdrun", ["mdrun", ...args], quiet) + (parser
      ? fatal("gmx mdrun", body, "src/gromacs/commandline/cmdlineparser.cpp", 271, "void gmx::CommandLineParser::parse(int*, char**)")
      : fatal("gmx mdrun", body)));
    return 1;
  }
  const deffnm = argValue(args, "-deffnm");
  const g = argValue(args, "-g") || (deffnm ? `${deffnm}.log` : "md.log");
  const c = argValue(args, "-c") || (deffnm ? `${deffnm}.gro` : "confout.gro");
  const e = argValue(args, "-e") || (deffnm ? `${deffnm}.edr` : "ener.edr");
  touch(g, "GROMACS mdrun placeholder log\n");
  touch(c, "Generated by reimplementation\n0\n   1.00000   1.00000   1.00000\n");
  touch(e, "");
  process.stdout.write(banner("mdrun", ["mdrun", ...args], quiet) + "Running mdrun placeholder\n");
  return 0;
}

function unknownOption(opt, args, quiet) {
  process.stderr.write(banner(null, args, quiet) + fatal("executable", `Invalid command-line options\n    Unknown command-line option ${opt}`, "src/gromacs/commandline/cmdlineparser.cpp", 271, "void gmx::CommandLineParser::parse(int*, char**)"));
  return 1;
}

function main() {
  let args = process.argv.slice(2);
  const originalArgs = args.slice();
  const quiet = args.includes("-quiet") || args.includes("-noquiet") === false && false;
  args = args.filter((a, i) => !(a === "-quiet" || a === "-nice" || (i > 0 && args[i - 1] === "-nice") || a === "-backup" || a === "-nobackup"));

  const badLong = args.find((a) => a.startsWith("--"));
  if (badLong) process.exit(unknownOption(badLong, args, quiet));

  if (args.includes("-version")) {
    process.stdout.write(banner(null, args, quiet) + versionText());
    process.exit(0);
  }
  const copyright = args.includes("-copyright");
  args = args.filter((a) => a !== "-copyright" && a !== "-nocopyright" && a !== "-noversion" && a !== "-noh");

  if (copyright) process.stdout.write(banner(null, ["-copyright", ...args], quiet).replace(/\nExecutable:/, "\n" + copyrightText() + "Executable:"));

  if (args.length === 0 || hasHelp(args)) {
    if (args.length === 0 && !quiet && !copyright) {
      process.stdout.write(banner(null, originalArgs, quiet) + "\n" + quote + "\n\n" + commonHelp());
    } else {
      process.stdout.write(commonHelp());
      if (!quiet && args.includes("-h")) process.stdout.write(banner(null, ["-h"], quiet) + "\n" + quote + "\n");
    }
    process.exit(0);
  }

  const cmd = args[0];
  const rest = args.slice(1);
  if (cmd === "help") {
    const topic = rest[0];
    let body;
    if (!topic) body = commonHelp();
    else if (topic === "commands") body = commandsHelp();
    else if (topic === "selections") body = selectionsHelp();
    else if (topic.startsWith("selections-")) body = selectionsHelp(topic.slice("selections-".length));
    else if (detailed[topic]) body = detailed[topic];
    else if (commandSet.has(topic)) body = genericCommandHelp(topic);
    else {
      process.stderr.write(banner("help", args, quiet) + fatal("gmx help", `Invalid command-line options\n    Unknown command-line argument '${topic}'`));
      process.exit(1);
    }
    process.stdout.write(banner("help", args, quiet) + body + (!quiet ? "\n" + quote + "\n" : ""));
    process.exit(0);
  }

  if (!commandSet.has(cmd)) {
    process.stderr.write(banner(null, args, quiet) + fatal("executable", `'${cmd}' is not a GROMACS command.`, "src/gromacs/commandline/cmdlinemodulemanager.cpp", 389, "gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)"));
    process.exit(1);
  }

  if (cmd === "grompp") process.exit(runGrompp(rest, quiet));
  if (cmd === "mdrun") process.exit(runMdrun(rest, quiet));
  if (hasHelp(rest)) {
    process.stdout.write(banner(cmd, args, quiet) + genericCommandHelp(cmd) + (!quiet ? "\n" + quote + "\n" : ""));
    process.exit(0);
  }
  process.stderr.write(banner(cmd, args, quiet) + fatal(`gmx ${cmd}`, `This reimplementation provides command-line help for '${cmd}', but does not implement the full analysis calculation.`));
  process.exit(1);
}

main();
