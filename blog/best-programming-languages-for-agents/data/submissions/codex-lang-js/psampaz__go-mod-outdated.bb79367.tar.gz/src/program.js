#!/usr/bin/env node
'use strict';

const fs = require('fs');

const HEADERS = ['MODULE', 'VERSION', 'NEW VERSION', 'DIRECT', 'VALID TIMESTAMPS'];

function usage(stream = process.stdout) {
  stream.write(`Usage of ./executable:\n`);
  stream.write(`  -ci\n    \tNon-zero exit code when at least one outdated dependency was found\n`);
  stream.write(`  -direct\n    \tList only direct modules\n`);
  stream.write(`  -style string\n    \tOutput style, pass 'markdown' for a Markdown table (default "default")\n`);
  stream.write(`  -update\n    \tList only modules with updates\n`);
}

function parseFlags(argv) {
  const opts = { ci: false, direct: false, update: false, style: 'default' };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '-h' || a === '-help' || a === '--help') {
      usage(process.stdout);
      process.exit(0);
    }
    if (!a.startsWith('-')) continue;
    let name = a;
    let val = null;
    const eq = a.indexOf('=');
    if (eq >= 0) {
      name = a.slice(0, eq);
      val = a.slice(eq + 1);
    }
    if (name === '-ci' || name === '-direct' || name === '-update') {
      const key = name.slice(1);
      if (val === null) opts[key] = true;
      else opts[key] = !(val === 'false' || val === '0');
    } else if (name === '-style') {
      if (val === null) {
        i++;
        if (i >= argv.length) {
          process.stderr.write('flag needs an argument: -style\n');
          usage(process.stderr);
          process.exit(2);
        }
        val = argv[i];
      }
      opts.style = val;
    } else {
      process.stderr.write(`flag provided but not defined: ${name}\n`);
      usage(process.stderr);
      process.exit(2);
    }
  }
  return opts;
}

function logError(err) {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  const stamp = `${d.getUTCFullYear()}/${pad(d.getUTCMonth() + 1)}/${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
  process.stderr.write(`${stamp} ${err.message || err}\n`);
}

function nextJsonValue(s, pos) {
  while (pos < s.length && /\s/.test(s[pos])) pos++;
  if (pos >= s.length) return null;
  const start = pos;
  const first = s[pos];
  if (first !== '{' && first !== '[') {
    // Let JSON.parse produce a useful error for primitives or malformed input.
    let end = pos;
    while (end < s.length && !/\s/.test(s[end])) end++;
    return { text: s.slice(pos, end), next: end };
  }
  let depth = 0, inStr = false, esc = false;
  for (; pos < s.length; pos++) {
    const ch = s[pos];
    if (inStr) {
      if (esc) esc = false;
      else if (ch === '\\') esc = true;
      else if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') inStr = true;
    else if (ch === '{' || ch === '[') depth++;
    else if (ch === '}' || ch === ']') {
      depth--;
      if (depth === 0) return { text: s.slice(start, pos + 1), next: pos + 1 };
    }
  }
  return { text: s.slice(start), next: s.length };
}

function parseInput(input) {
  const mods = [];
  let pos = 0;
  while (true) {
    const item = nextJsonValue(input, pos);
    if (!item) break;
    pos = item.next;
    try {
      const v = JSON.parse(item.text);
      if (v && !Array.isArray(v) && typeof v === 'object') mods.push(v);
      else throw new Error(`json: cannot unmarshal ${Array.isArray(v) ? 'array' : typeof v} into Go value of type mod.Module`);
    } catch (e) {
      logError(e);
      return { mods: [], ok: false };
    }
  }
  return { mods, ok: true };
}

function parseGoTime(t) {
  if (!t) return null;
  const ms = Date.parse(t);
  if (!Number.isFinite(ms)) throw new Error(`parsing time "${t}" as "2006-01-02T15:04:05Z07:00": cannot parse "${t}" as "2006"`);
  return ms;
}

function isOutdated(m) { return !!m.Update; }
function isDirect(m) { return !m.Indirect; }

function validTimestamps(m) {
  if (!m.Update || !m.Time) return true;
  const cur = parseGoTime(m.Time);
  // The original panics when Update exists, module time exists, and Update.Time is missing.
  if (!m.Update.Time) return true;
  const upd = parseGoTime(m.Update.Time);
  return upd >= cur;
}

function center(text, width) {
  text = String(text);
  const total = width - text.length;
  const left = Math.floor(total / 2);
  const right = total - left;
  return ' '.repeat(left) + text + ' '.repeat(right);
}
function left(text, width) {
  text = String(text);
  return text + ' '.repeat(width - text.length);
}

function render(rows, style) {
  if (rows.length === 0) return '';
  const widths = HEADERS.map(h => h.length);
  rows.forEach(r => r.forEach((c, i) => { widths[i] = Math.max(widths[i], String(c).length); }));
  const sep = '+' + widths.map(w => '-'.repeat(w + 2)).join('+') + '+\n';
  const mdSep = '|' + widths.map(w => '-'.repeat(w + 2)).join('|') + '|\n';
  const header = '|' + HEADERS.map((h, i) => ' ' + center(h, widths[i]) + ' ').join('|') + '|\n';
  const body = rows.map(r => '|' + r.map((c, i) => ' ' + left(c, widths[i]) + ' ').join('|') + '|\n').join('');
  if (style === 'markdown') return header + mdSep + body;
  return sep + header + sep + body + sep;
}

function main() {
  const opts = parseFlags(process.argv.slice(2));
  const input = fs.readFileSync(0, 'utf8');
  const parsed = parseInput(input);
  if (!parsed.ok) process.exit(0);

  const selected = [];
  let outdatedCount = 0;
  for (const m of parsed.mods) {
    if (opts.direct && !isDirect(m)) continue;
    if (opts.update && !isOutdated(m)) continue;
    let valid;
    try { valid = validTimestamps(m); }
    catch (e) { logError(e); process.exit(0); }
    if (isOutdated(m)) outdatedCount++;
    selected.push([
      m.Path || '',
      m.Version || '',
      (m.Update && m.Update.Version) || '',
      String(isDirect(m)),
      String(valid),
    ]);
  }
  const out = render(selected, opts.style);
  if (out) process.stdout.write(out);
  process.exit(opts.ci && outdatedCount > 0 ? 1 : 0);
}

main();
