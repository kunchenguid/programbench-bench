#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const start = Date.now();
const VERSION = '0.10.0';

const HELP = `a conventional changelog for the rest of us

Usage: executable [OPTIONS]

Options:
  -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,
                          e.g. https://github.com/thoughtram/clog)
  -f, --from <COMMIT>     e.g. 12a8546
  -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible
                          values: markdown, json]
  -M, --major             Increment major version by one (Sets minor and patch to 0)
  -g, --git-dir <PATH>    Local .git directory (defaults to "$(pwd)/.git")
  -w, --work-tree <PATH>  Local working tree of the git project (defaults to "$(pwd)")
  -m, --minor             Increment minor version by one (Sets patch to 0)
  -p, --patch             Increment patch version by one
  -s, --subtitle <STR>    
  -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]
  -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)
  -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]
  -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with
                          --outfile)
      --setversion <VER>  e.g. 1.0.1
  -F, --from-latest-tag   use latest tag as start (instead of --from)
  -l, --link-style <STR>  The style of repository link to generate [default: github] [possible
                          values: github, gitlab, stash, cgit]
  -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the
                          same file for both --infile and --outfile and should not be used in
                          conjunction with either)
  -h, --help              Print help
  -V, --version           Print version


If your .git directory is a child of your project directory (most common, such as /myproject/.git)
AND not in the current working directory (i.e you need to use --work-tree or --git-dir) you only
need to specify either the --work-tree (i.e. /myproject) OR --git-dir (i.e. /myproject/.git), you
don't need to use both.

If using the --config to specify a clog configuration TOML file NOT in the current working directory
(meaning you need to use --work-tree or --git-dir) AND the TOML file is inside your project
directory (i.e. /myproject/.clog.toml) you do not need to use --work-tree or --git-dir.`;

function die(msg) {
  console.log(`\x1b[1;31merror:\x1b[0m ${msg}`);
  process.exit(1);
}

function parseArgs(argv) {
  const out = { format: 'markdown', to: 'HEAD', config: '.clog.toml', linkStyle: 'github' };
  const needs = new Set(['-r','--repository','-f','--from','-T','--format','-g','--git-dir','-w','--work-tree','-s','--subtitle','-t','--to','-o','--outfile','-c','--config','-i','--infile','--setversion','-l','--link-style','-C','--changelog']);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const val = () => {
      if (i + 1 >= argv.length) die(`a value is required for '${a}' but none was supplied`);
      return argv[++i];
    };
    if (a === '-h' || a === '--help') out.help = true;
    else if (a === '-V' || a === '--version') out.version = true;
    else if (a === '-M' || a === '--major') out.major = true;
    else if (a === '-m' || a === '--minor') out.minor = true;
    else if (a === '-p' || a === '--patch') out.patch = true;
    else if (a === '-F' || a === '--from-latest-tag') out.fromLatestTag = true;
    else if (needs.has(a)) {
      const v = val();
      if (a === '-r' || a === '--repository') out.repository = v;
      else if (a === '-f' || a === '--from') out.from = v;
      else if (a === '-T' || a === '--format') out.format = v;
      else if (a === '-g' || a === '--git-dir') out.gitDir = v;
      else if (a === '-w' || a === '--work-tree') out.workTree = v;
      else if (a === '-s' || a === '--subtitle') out.subtitle = v;
      else if (a === '-t' || a === '--to') out.to = v;
      else if (a === '-o' || a === '--outfile') out.outfile = v;
      else if (a === '-c' || a === '--config') out.config = v;
      else if (a === '-i' || a === '--infile') out.infile = v;
      else if (a === '--setversion') out.setversion = v;
      else if (a === '-l' || a === '--link-style') out.linkStyle = v;
      else if (a === '-C' || a === '--changelog') { out.changelog = v; out.infile = v; out.outfile = v; }
    } else if (a.startsWith('-')) die(`unexpected argument '${a}' found`);
  }
  return out;
}

function readConfig(file) {
  const cfg = { sections: {}, aliases: {} };
  if (!file || !fs.existsSync(file)) return cfg;
  let section = '';
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    let line = raw.replace(/#.*/, '').trim();
    if (!line) continue;
    const sm = line.match(/^\[([^\]]+)\]$/);
    if (sm) { section = sm[1].trim(); continue; }
    const m = line.match(/^([A-Za-z0-9_.-]+|"[^"]+")\s*=\s*(.+)$/);
    if (!m) continue;
    const key = m[1].replace(/^"|"$/g, '');
    let v = m[2].trim().replace(/,$/, '');
    if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
    if (v === 'true') v = true;
    if (v === 'false') v = false;
    if (section === 'clog') {
      if (key === 'repository') cfg.repository = v;
      else if (key === 'from-latest-tag') cfg.fromLatestTag = v;
      else if (key === 'subtitle') cfg.subtitle = v;
      else if (key === 'link-style') cfg.linkStyle = v;
      else if (key === 'changelog') cfg.changelog = v;
    } else if (section === 'sections' || section === 'sections.custom') {
      cfg.sections[key] = String(v);
    } else if (section === 'aliases') {
      cfg.aliases[key] = String(v);
    }
  }
  return cfg;
}

function git(args, opt) {
  const gitArgs = [];
  if (opt.gitDir) gitArgs.push(`--git-dir=${opt.gitDir}`);
  if (opt.workTree) gitArgs.push(`--work-tree=${opt.workTree}`);
  gitArgs.push(...args);
  try { return cp.execFileSync('git', gitArgs, { cwd: opt.workTree || process.cwd(), encoding: 'utf8', stdio: ['ignore','pipe','ignore'] }).trimEnd(); }
  catch (_) { return ''; }
}

function latestTag(opt) {
  return git(['describe', '--tags', '--abbrev=0', opt.to || 'HEAD'], opt) || '';
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function parseVersion(s) {
  if (!s) return null;
  const m = String(s).trim().match(/^(v?)(\d+)\.(\d+)\.(\d+)/);
  if (!m) return null;
  return { prefix: m[1], major: +m[2], minor: +m[3], patch: +m[4] };
}
function fmtVer(v) { return v ? `${v.prefix}${v.major}.${v.minor}.${v.patch}` : null; }

function versionFromChangelog(text) {
  if (!text) return null;
  const m = text.match(/<a name="([^"]+)"/i) || text.match(/^#{2,3}\s+v?(\d+\.\d+\.\d+)/m);
  return m ? m[1] : null;
}

function determineVersion(opt, cfg, oldText) {
  if (opt.setversion) return opt.setversion;
  const inc = opt.major || opt.minor || opt.patch;
  if (!inc) return null;
  let base = parseVersion(versionFromChangelog(oldText)) || parseVersion(latestTag(opt));
  if (!base) die('Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.');
  if (opt.major) { base.major++; base.minor = 0; base.patch = 0; }
  else if (opt.minor) { base.minor++; base.patch = 0; }
  else if (opt.patch) base.patch++;
  return fmtVer(base);
}

const defaultNames = {
  feat: 'Features', feature: 'Features', features: 'Features',
  fix: 'Bug Fixes', bugfix: 'Bug Fixes', bug: 'Bug Fixes',
  docs: 'Documentation', doc: 'Documentation', documentation: 'Documentation',
  style: 'Style Fixes', perf: 'Performance', performance: 'Performance',
  refactor: 'Code Refactoring', test: 'Tests', tests: 'Tests', chore: 'Chores', build: 'Build', ci: 'Continuous Integration'
};
const order = ['Breaking Changes','Features','Bug Fixes','Documentation','Performance','Code Refactoring','Style Fixes','Tests','Build','Continuous Integration','Chores'];

function repoLink(repo, style, kind, id) {
  if (!repo) return id;
  const r = repo.replace(/\.git$/, '').replace(/\/$/, '');
  if (kind === 'commit') {
    if (style === 'gitlab' || style === 'github') return `${r}/commit/${id}`;
    if (style === 'stash') return `${r}/commits/${id}`;
    if (style === 'cgit') return `${r}/commit/?id=${id}`;
  }
  if (kind === 'issue') {
    if (style === 'gitlab') return `${r}/issues/${id}`;
    if (style === 'stash') return `${r}/browse/${id}`;
    if (style === 'cgit') return `${r}/issues/${id}`;
    return `${r}/issues/${id}`;
  }
  return r;
}

function parseCommit(subject, body, hash, cfg, opt) {
  let s = subject.trim();
  let type = '', scope = '', title = s;
  let m = s.match(/^([A-Za-z][\w-]*)(?:\(([^)]*)\))?(!)?:\s*(.+)$/);
  if (!m) m = s.match(/^([A-Za-z][\w-]*)(?:\(([^)]*)\))?\s+(.+)$/);
  if (m) {
    type = m[1].toLowerCase(); scope = m[2] || ''; title = m[4] || m[3] || title;
  }
  if (cfg.aliases[type]) type = cfg.aliases[type].toLowerCase();
  let section = cfg.sections[type] || defaultNames[type];
  const breaking = /BREAKING[ -]CHANGE/i.test(body) || /^\w+(\([^)]*\))?!:/.test(s);
  if (breaking) section = 'Breaking Changes';
  if (!section) return null;
  const short = hash.slice(0, 8);
  const link = opt.repository ? `[${short}](${repoLink(opt.repository, opt.linkStyle, 'commit', hash)})` : short;
  let extra = ` (${link}`;
  const issues = [];
  const re = /(?:close[sd]?|fix(?:e[sd])?|resolve[sd]?)\s+#(\d+)/ig;
  let im;
  while ((im = re.exec(body + '\n' + subject))) if (!issues.includes(im[1])) issues.push(im[1]);
  for (const issue of issues) {
    extra += `, closes [#${issue}](${repoLink(opt.repository, opt.linkStyle, 'issue', issue)})`;
  }
  extra += ')';
  const prefix = scope ? `**${scope}**: ` : '';
  return { section, line: `* ${prefix}${title}${extra}` };
}

function commits(opt, cfg) {
  let from = opt.from;
  if (opt.fromLatestTag || cfg.fromLatestTag) from = latestTag(opt);
  const range = from ? `${from}..${opt.to || 'HEAD'}` : (opt.to || 'HEAD');
  const raw = git(['log', '--no-merges', '--pretty=format:%H%x1f%s%x1f%b%x1e', range], opt);
  if (!raw) return [];
  const out = [];
  for (const rec of raw.split('\x1e')) {
    if (!rec.trim()) continue;
    const [hash, subject, body = ''] = rec.replace(/^\n+/, '').split('\x1f');
    if (hash && subject) out.push(parseCommit(subject, body, hash, cfg, opt));
  }
  return out.filter(Boolean);
}

function markdown(header, groups) {
  let out = `<a name="${header.version || ''}"></a>\n## ${header.version || ''} ${header.subtitle || ''} (${header.date})\n\n`;
  const keys = Object.keys(groups).sort((a,b) => {
    const ia = order.indexOf(a), ib = order.indexOf(b);
    return (ia < 0 ? 999 : ia) - (ib < 0 ? 999 : ib) || a.localeCompare(b);
  });
  for (const k of keys) {
    out += `\n#### ${k}\n\n`;
    for (const line of groups[k]) out += `${line}\n`;
  }
  return out + '\n';
}

function rustishJson(header, groups) {
  const sections = Object.keys(groups).length ? Object.fromEntries(Object.entries(groups).map(([k,v]) => [k, v])) : null;
  const ver = header.version == null ? 'None' : `Some("${String(header.version).replace(/"/g, '\\"')}")`;
  const sub = header.subtitle == null ? 'null' : `"${String(header.subtitle).replace(/"/g, '\\"')}"`;
  if (!sections) return `{"header":{"version":${ver},"patch_version":false,"subtitle":${sub},"date":"${header.date}"},"sections":null}`;
  return JSON.stringify({ header: { version: header.version, patch_version: false, subtitle: header.subtitle || null, date: header.date }, sections });
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) { console.log(HELP); return; }
  if (args.version) { console.log(`clog ${VERSION}`); return; }
  if (!['markdown','json'].includes(args.format)) die(`invalid value '${args.format}' for '--format <STR>'`);

  const cfg = readConfig(args.config);
  const opt = { ...cfg, ...args, fromLatestTag: args.fromLatestTag || cfg.fromLatestTag, linkStyle: args.linkStyle || cfg.linkStyle || 'github' };
  if (opt.changelog && !args.infile) opt.infile = opt.changelog;
  let oldText = '';
  if (opt.infile && fs.existsSync(opt.infile)) oldText = fs.readFileSync(opt.infile, 'utf8');
  const version = determineVersion(opt, cfg, oldText);
  const header = { version, subtitle: opt.subtitle || null, date: today() };
  const groups = {};
  for (const c of commits(opt, cfg)) {
    if (!groups[c.section]) groups[c.section] = [];
    groups[c.section].push(c.line);
  }
  let out = opt.format === 'json' ? rustishJson(header, groups) : markdown(header, groups);
  if (oldText && opt.format === 'markdown') out += oldText.replace(/^\n+/, '');
  if (opt.outfile) fs.writeFileSync(opt.outfile, out);
  else process.stdout.write(out);
  console.log(`changelog written. (took ${Date.now() - start} ms)`);
}

main();
