#!/usr/bin/env node
'use strict';

const { execFileSync, spawnSync } = require('child_process');
const path = require('path');

const HELP = `A TUI tool to visualize Git commit graphs with branch genealogy

Usage: executable

Options:
  -h, --help     Print help
  -V, --version  Print version`;

function out(s) { process.stdout.write(s + '\n'); }
function err(s) { process.stderr.write(s + '\n'); }

function parseArgs(argv) {
  if (argv.length === 0) return 'run';
  if (argv.length === 1 && (argv[0] === '-h' || argv[0] === '--help')) return 'help';
  if (argv.length === 1 && (argv[0] === '-V' || argv[0] === '--version')) return 'version';
  const a = argv[0];
  if (a.startsWith('--help=')) {
    const v = a.slice('--help='.length);
    err(`error: unexpected value '${v}' for '--help' found; no more were expected\n`);
    err('Usage: executable --help\n');
    err("For more information, try '--help'.");
  } else {
    err(`error: unexpected argument '${a}' found\n`);
    err('Usage: executable\n');
    err("For more information, try '--help'.");
  }
  process.exit(2);
}

function git(args, opts = {}) {
  try {
    return execFileSync('git', args, {
      cwd: opts.cwd || process.cwd(),
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', opts.quiet ? 'ignore' : 'pipe'],
      maxBuffer: 32 * 1024 * 1024,
    }).replace(/\n$/, '');
  } catch (e) {
    if (opts.optional) return null;
    throw e;
  }
}

function ensureRepo() {
  const root = git(['rev-parse', '--show-toplevel'], { optional: true, quiet: true });
  if (!root) {
    err('Error: Git repository not found. Please run inside a Git repository.\n');
    err('Caused by:');
    err("    could not find repository at '.'; class=Repository (6); code=NotFound (-3)");
    process.exit(1);
  }
  return root;
}

function ttyCheck() {
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    err('Error: No such device or address (os error 6)');
    process.exit(1);
  }
}

function stripAnsi(s) { return s.replace(/\x1b\[[0-9;?]*[ -/]*[@-~]/g, ''); }
function width(s) { return Array.from(stripAnsi(s)).length; }
function clip(s, n) {
  if (n <= 0) return '';
  let plain = stripAnsi(s);
  const chars = Array.from(plain);
  if (chars.length <= n) return s + ' '.repeat(n - chars.length);
  return chars.slice(0, Math.max(0, n - 1)).join('') + '…';
}
function esc(s) { return `\x1b[${s}m`; }
const reset = '\x1b[39m\x1b[49m\x1b[59m\x1b[0m';
const fg = n => `\x1b[38;5;${n}m`;
const bg = n => `\x1b[48;5;${n}m`;
const bold = '\x1b[1m';
const normal = '\x1b[22m';

function loadBranches() {
  const text = git(['for-each-ref', 'refs/heads', 'refs/remotes', '--format=%(objectname)%09%(refname:short)'], { optional: true, quiet: true }) || '';
  const map = new Map();
  for (const line of text.split('\n').filter(Boolean)) {
    const [sha, name] = line.split('\t');
    if (!sha || !name || name.endsWith('/HEAD')) continue;
    if (!map.has(sha)) map.set(sha, []);
    map.get(sha).push(name);
  }
  return map;
}

function loadCommits(branches) {
  const fmt = '%x1e%H%x1f%h%x1f%ad%x1f%an%x1f%ae%x1f%s';
  const text = git(['log', '--graph', 'HEAD', '--branches', '--remotes', '--topo-order', '--date=short', `--pretty=format:${fmt}`, '-n', '500'], { optional: true, quiet: true }) || '';
  const rows = [];
  for (const line of text.split('\n')) {
    const i = line.indexOf('\x1e');
    if (i < 0) continue;
    const graph = line.slice(0, i).trimEnd();
    const parts = line.slice(i + 1).split('\x1f');
    if (parts.length < 6) continue;
    const [sha, short, date, author, email, subject] = parts;
    rows.push({ graph, sha, short, date, author, email, subject, branches: branches.get(sha) || [] });
  }
  const dirty = (git(['status', '--porcelain'], { optional: true, quiet: true }) || '')
    .split('\n').some(l => l && !l.startsWith('??'));
  if (dirty) rows.unshift({ dirty: true, graph: '●', sha: '', short: '', date: '', author: '', email: '', subject: 'uncommitted changes', branches: [] });
  return rows;
}

function currentBranch() {
  return git(['branch', '--show-current'], { optional: true, quiet: true }) || 'HEAD';
}
function currentHead() {
  return git(['rev-parse', 'HEAD'], { optional: true, quiet: true }) || '';
}

function repoName(root) {
  return path.basename(root) || root;
}

function commitDetail(commit) {
  if (!commit || commit.dirty) return { detail: ['Uncommitted changes'], files: ['Working tree has staged or unstaged changes.'] };
  const full = git(['show', '-s', '--format=%H%x1f%an <%ae>%x1f%ad%x1f%P%x1f%B', '--date=format:%Y-%m-%d %H:%M:%S', commit.sha], { optional: true, quiet: true }) || '';
  const [sha, author, date, parents, body] = full.split('\x1f');
  const detail = [
    `${bold}Commit:${normal} ${fg(3)}${sha || commit.sha}${fg(7)}`,
    `${bold}Author:${normal} ${fg(4)}${author || commit.author}${fg(7)}`,
    `${bold}Date:  ${normal} ${fg(8)}${date || commit.date}${fg(7)}`,
    `${bold}Parent:${normal} ${fg(8)}${(parents || '').split(' ').filter(Boolean).map(p => p.slice(0, 7)).join(' ') || '-'}${fg(7)}`,
    '',
    ...(body || commit.subject).trim().split('\n'),
  ];
  const stats = git(['show', '--numstat', '--format=', '--find-renames', commit.sha], { optional: true, quiet: true }) || '';
  const files = [];
  let add = 0, del = 0, count = 0;
  for (const line of stats.split('\n').filter(Boolean).slice(0, 50)) {
    const [a, d, file] = line.split('\t');
    const ai = a === '-' ? 0 : parseInt(a || '0', 10);
    const di = d === '-' ? 0 : parseInt(d || '0', 10);
    add += ai; del += di; count++;
    files.push(`${fg(2)} ${ai || ' '} ${fg(7)}${file || ''} ${fg(2)}+${ai}${fg(1)} -${di}${fg(7)}`);
  }
  return { detail, files: [`${bold}${count} files changed${normal} ${fg(2)}+${add}${fg(1)} -${del}${fg(7)}`, '', ...files] };
}

function border(title, w) {
  const t = title ? ` ${title} ` : '';
  return `${fg(8)}┌${t}${'─'.repeat(Math.max(0, w - 2 - width(t)))}┐${fg(7)}`;
}
function bottom(w) { return `${fg(8)}└${'─'.repeat(Math.max(0, w - 2))}┘${fg(7)}`; }
function cell(s, w) {
  const inner = width(s) === w - 2 ? s : clip(s, w - 2);
  return `${fg(8)}│${fg(7)}${inner}${fg(8)}│${fg(7)}`;
}

function render(state) {
  const cols = Math.max(60, process.stdout.columns || 120);
  const rows = Math.max(20, process.stdout.rows || 40);
  const listH = Math.max(8, rows - 13);
  const bottomH = rows - listH - 1;
  const commits = state.commits;
  if (state.selected >= commits.length) state.selected = Math.max(0, commits.length - 1);
  const selected = commits[state.selected];
  const { detail, files } = commitDetail(selected);
  let s = '\x1b[1;1H';
  s += border('Commits', cols);
  for (let i = 0; i < listH - 2; i++) {
    const idx = state.offset + i;
    const c = commits[idx];
    let line = '';
    if (c) {
      const labels = c.branches.length ? `[${c.branches[0]}${c.branches.length > 1 ? ` +${c.branches.length - 1}` : ''}] ` : '';
      const graph = c.graph || '●';
      line = `${fg(idx === state.selected ? 12 : 2)}${graph.replace(/\*/g, '●')}${fg(7)} ${fg(2)}${labels}${fg(7)}${c.subject}`;
      const right = `${fg(8)}${c.date || ''}${fg(6)}  ${c.author || ''}${fg(3)}  ${c.short || ''}${fg(7)}`;
      const room = cols - 2 - width(right) - 1;
      line = clip(line, room) + ' ' + right;
    }
    if (idx === state.selected) line = `${bold}${fg(0)}${bg(8)}${clip(' ' + stripAnsi(line), cols - 2)}${reset}`;
    s += `\x1b[${i + 2};1H` + cell(line, cols);
  }
  s += `\x1b[${listH};1H` + bottom(cols);
  const paneY = listH + 1;
  const paneH = Math.max(5, bottomH - 1);
  const leftW = Math.floor(cols / 2);
  const rightW = cols - leftW;
  s += `\x1b[${paneY};1H${border('Commit Detail', leftW)}${border('Changed Files', rightW)}`;
  for (let i = 0; i < paneH - 2; i++) {
    s += `\x1b[${paneY + 1 + i};1H${cell(detail[i] || '', leftW)}${cell(files[i] || '', rightW)}`;
  }
  s += `\x1b[${paneY + paneH - 1};1H${bottom(leftW)}${bottom(rightW)}`;
  const bar = `${bold}${fg(0)}${bg(5)} ${state.repo} ${reset} ${fg(0)}${bg(2)} ${state.branch} ${reset} ${bold}${fg(0)}${bg(6)} j/k ${reset}move ${bold}${fg(0)}${bg(6)} Enter ${reset}checkout ${bold}${fg(0)}${bg(6)} b ${reset}branch ${bold}${fg(0)}${bg(6)} f ${reset}fetch ${bold}${fg(0)}${bg(6)} ? ${reset}help ${bold}${fg(0)}${bg(6)} q ${reset}quit`;
  s += `\x1b[${rows};1H${clip(bar, cols)}`;
  process.stdout.write(s + reset + '\x1b[?25l');
}

function runTui(root) {
  const state = { root, repo: repoName(root), branch: currentBranch(), selected: 0, offset: 0, commits: loadCommits(loadBranches()) };
  const head = currentHead();
  const headIndex = state.commits.findIndex(c => c.sha === head);
  if (headIndex >= 0) state.selected = headIndex;
  process.stdout.write('\x1b[?1049h\x1b[2J\x1b[?25l');
  if (process.stdin.setRawMode) process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.setEncoding('utf8');
  const cleanup = (code = 0) => {
    try { if (process.stdin.setRawMode) process.stdin.setRawMode(false); } catch {}
    process.stdout.write(reset + '\x1b[?25h\x1b[?1049l');
    process.exit(code);
  };
  process.on('SIGINT', () => cleanup(0));
  process.on('SIGTERM', () => cleanup(0));
  const move = n => {
    state.selected = Math.max(0, Math.min(state.commits.length - 1, state.selected + n));
    const visible = Math.max(1, (process.stdout.rows || 40) - 15);
    if (state.selected < state.offset) state.offset = state.selected;
    if (state.selected >= state.offset + visible) state.offset = state.selected - visible + 1;
  };
  process.stdin.on('data', ch => {
    if (ch === 'q' || ch === '\u001b' || ch === '\u0003') cleanup(0);
    else if (ch === 'j' || ch === '\u001b[B') move(1);
    else if (ch === 'k' || ch === '\u001b[A') move(-1);
    else if (ch === 'g' || ch === '\u001b[H') { state.selected = 0; state.offset = 0; }
    else if (ch === 'G' || ch === '\u001b[F') { state.selected = Math.max(0, state.commits.length - 1); move(0); }
    else if (ch === 'R' || ch === 'r') { state.branch = currentBranch(); state.commits = loadCommits(loadBranches()); }
    else if (ch === 'f') spawnSync('git', ['fetch', 'origin'], { cwd: root, stdio: 'ignore' });
    render(state);
  });
  render(state);
  setInterval(() => render(state), 10000).unref();
}

const mode = parseArgs(process.argv.slice(2));
if (mode === 'help') { out(HELP); process.exit(0); }
if (mode === 'version') { out('keifu 0.2.3'); process.exit(0); }
const root = ensureRepo();
ttyCheck();
runTui(root);
