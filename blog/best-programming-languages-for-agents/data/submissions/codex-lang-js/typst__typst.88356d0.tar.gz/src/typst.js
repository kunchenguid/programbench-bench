#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const VERSION = "0.14.2";
const HASH = "ccc34be7";

function out(s = "") { process.stdout.write(String(s) + "\n"); }
function err(s = "") { process.stderr.write(String(s) + "\n"); }
function die(message, code = 1) { err(message); process.exit(code); }
function has(args, ...names) { return args.some(a => names.includes(a)); }

const mainHelp = `Typst ${VERSION} (${HASH})

Usage: executable [OPTIONS] <COMMAND>

Commands:
  compile      Compiles an input file into a supported output format [aliases:
               c]
  watch        Watches an input file and recompiles on changes [aliases: w]
  init         Initializes a new project from a template
  eval         Evaluates a piece of Typst code, optionally in the context of a
               document
  fonts        Lists all discovered fonts in system and custom font paths
  completions  Generates shell completion scripts
  info         Displays debugging information about Typst
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>  Whether to use color. When set to \`auto\` if the terminal
                       to supports it [default: auto] [possible values: auto,
                       always, never]
      --cert <CERT>    Path to a custom CA certificate to use when making
                       network requests [env: TYPST_CERT=]
  -h, --help           Print help
  -V, --version        Print version

Resources:
  Tutorial:                 https://typst.app/docs/tutorial/
  Reference documentation:  https://typst.app/docs/reference/
  Templates & Packages:     https://typst.app/universe/
  Forum for questions:      https://forum.typst.app/`;

const welcome = `Welcome to Typst, we are glad to have you here! ❤️

If you are new to Typst, start with the tutorial at https://typst.app/docs/tutorial/.
To get a quick start with your first project, choose a template on https://typst.app/universe/.

Here are the most important commands you will be using:

- Compile a file once: typst compile file.typ
- Compile a file on every change: typst watch file.typ
- Set up a project from a template: typst init @preview/<TEMPLATE>

Learn more about these commands by running typst help.

If you have a question, we and our community would be glad to help you out on
the Typst Forum at https://forum.typst.app/.

Happy Typsting!`;

const compileHelp = `Compiles an input file into a supported output format

Usage: executable compile [OPTIONS] <INPUT> [OUTPUT]

Arguments:
  <INPUT>   Path to input Typst file. Use \`-\` to read input from stdin
  [OUTPUT]  Path to output file (PDF, PNG, SVG, or HTML). Use \`-\` to write
            output to stdout

Options:
  -f, --format <FORMAT>
          The format of the output file, inferred from the extension by default
          [possible values: pdf, png, svg, html]
      --root <DIR>
          Configures the project root (for absolute paths) [env: TYPST_ROOT=]
      --input <key=value>
          Add a string key-value pair visible through \`sys.inputs\`
      --font-path <DIR>
          Adds additional directories that are recursively searched for fonts
          [env: TYPST_FONT_PATHS=]
      --ignore-system-fonts
          Ensures system fonts won't be searched, unless explicitly included via
          \`--font-path\` [env: TYPST_IGNORE_SYSTEM_FONTS=]
      --ignore-embedded-fonts
          Ensures fonts embedded into Typst won't be considered [env:
          TYPST_IGNORE_EMBEDDED_FONTS=]
      --package-path <DIR>
          Custom path to local packages, defaults to system-dependent location
          [env: TYPST_PACKAGE_PATH=]
      --package-cache-path <DIR>
          Custom path to package cache, defaults to system-dependent location
          [env: TYPST_PACKAGE_CACHE_PATH=]
      --creation-timestamp <UNIX_TIMESTAMP>
          The document's creation date formatted as a UNIX timestamp [env:
          SOURCE_DATE_EPOCH=]
      --pages <PAGES>
          Which pages to export. When unspecified, all pages are exported
      --pdf-standard <PDF_STANDARD>
          One (or multiple comma-separated) PDF standards that Typst will
          enforce conformance with [possible values: 1.4, 1.5, 1.6, 1.7, 2.0,
          a-1b, a-1a, a-2b, a-2u, a-2a, a-3b, a-3u, a-3a, a-4, a-4f, a-4e, ua-1]
      --no-pdf-tags
          By default, even when not producing a \`PDF/UA-1\` document, a tagged
          PDF document is written to provide a baseline of accessibility
      --ppi <PPI>
          The PPI (pixels per inch) to use for PNG export [default: 144]
      --deps <PATH>
          File path to which a list of current compilation's dependencies will
          be written. Use \`-\` to write to stdout
      --deps-format <DEPS_FORMAT>
          File format to use for dependencies [default: json] [possible values:
          json, zero, make]
  -j, --jobs <JOBS>
          Number of parallel jobs spawned during compilation. Defaults to number
          of CPUs. Setting it to 1 disables parallelism
      --features <FEATURES>
          Enables in-development features that may be changed or removed at any
          time [env: TYPST_FEATURES=] [possible values: html, a11y-extras]
      --diagnostic-format <DIAGNOSTIC_FORMAT>
          The format to emit diagnostics in [default: human] [possible values:
          human, short]
      --open [<VIEWER>]
          Opens the output file with the default viewer or a specific program
          after compilation. Ignored if output is stdout
      --timings [<OUTPUT_JSON>]
          Produces performance timings of the compilation process.
          (experimental)
  -h, --help
          Print help (see more with '--help')`;

const evalHelp = `Evaluates a piece of Typst code, optionally in the context of a document

Usage: executable eval [OPTIONS] <EXPRESSION>

Arguments:
  <EXPRESSION>          The piece of Typst code to evaluate

Options:
      --in <IN>         A file in whose context to evaluate the code. Can be used to
                        introspect the document. Use \`-\` to read input from stdin
      --target <TARGET> The target to compile for [default: paged] [possible values:
                        paged, html]
      --format <FORMAT> The format to serialize in [default: json] [possible values:
                        json, yaml]
      --pretty          Whether to pretty-print the serialized output.
  -h, --help            Print help (see a summary with '-h')`;

const fontsHelp = `Lists all discovered fonts in system and custom font paths

Usage: executable fonts [OPTIONS]

Options:
      --font-path <DIR>        Adds additional directories that are recursively
                               searched for fonts [env: TYPST_FONT_PATHS=]
      --ignore-system-fonts    Ensures system fonts won't be searched, unless
                               explicitly included via \`--font-path\` [env:
                               TYPST_IGNORE_SYSTEM_FONTS=]
      --ignore-embedded-fonts  Ensures fonts embedded into Typst won't be
                               considered [env: TYPST_IGNORE_EMBEDDED_FONTS=]
      --variants               Also lists style variants of each font family
  -h, --help                   Print help (see more with '--help')`;

function stripGlobalOptions(args) {
  const res = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--color" || a === "--cert") i++;
    else if (a.startsWith("--color=") || a.startsWith("--cert=")) {}
    else res.push(a);
  }
  return res;
}

function readStdin() {
  try { return fs.readFileSync(0, "utf8"); } catch { return ""; }
}

function textFromTypst(src) {
  let s = src.replace(/\r\n/g, "\n");
  s = s.replace(/#set\s+[^\n]+/g, "");
  s = s.replace(/#let\s+([A-Za-z_]\w*)\s*=\s*([^\n]+)/g, "");
  s = s.replace(/#([A-Za-z_]\w*)/g, "$1");
  s = s.replace(/\$([^$]+)\$/g, "$1");
  s = s.replace(/\[([^\]]*)\]/g, "$1");
  s = s.replace(/\*([^*\n]+)\*/g, "$1");
  s = s.replace(/_([^_\n]+)_/g, "$1");
  s = s.replace(/^={1,6}\s*/gm, "");
  s = s.replace(/^- /gm, "• ");
  s = s.replace(/`([^`]+)`/g, "$1");
  s = s.replace(/#[a-zA-Z_][\w.]*\((?:[^()]|\([^()]*\))*\)/g, "");
  return s.split("\n").map(x => x.trim()).filter(Boolean).join("\n");
}

function escapeXml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[c]));
}

function renderSvg(src) {
  const lines = textFromTypst(src).split("\n").filter(Boolean);
  const body = lines.map((l, i) => `<text x="70" y="${90 + i * 22}" font-family="serif" font-size="${i === 0 && /^=/.test(l) ? 20 : 14}" fill="#000000">${escapeXml(l)}</text>`).join("\n  ");
  return `<svg viewBox="0 0 595.275590551 841.88976378" width="595.275590551pt" height="841.88976378pt" xmlns="http://www.w3.org/2000/svg">
  <path fill="#ffffff" d="M0 0h595.275590551v841.88976378H0z"/>
  ${body || `<text x="70" y="90" font-family="serif" font-size="14"></text>`}
</svg>
`;
}

function renderHtml(src) {
  const lines = textFromTypst(src).split("\n");
  const html = lines.map(l => `<p>${escapeXml(l)}</p>`).join("\n");
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Typst document</title></head>
<body>
${html}
</body></html>
`;
}

function renderPdf(src) {
  const text = textFromTypst(src).replace(/[()\\]/g, "\\$&").split("\n").slice(0, 40);
  const content = `BT /F1 12 Tf 72 760 Td ${text.map((l, i) => `${i ? "0 -18 Td " : ""}(${l}) Tj`).join(" ")} ET`;
  const objs = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Times-Roman >>",
    `<< /Length ${Buffer.byteLength(content)} >>\nstream\n${content}\nendstream`
  ];
  let pdf = "%PDF-1.7\n";
  const offsets = [0];
  objs.forEach((o, i) => { offsets.push(Buffer.byteLength(pdf)); pdf += `${i + 1} 0 obj\n${o}\nendobj\n`; });
  const xref = Buffer.byteLength(pdf);
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i < offsets.length; i++) pdf += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  pdf += `trailer << /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(pdf, "binary");
}

function pngChunk(type, data) {
  const t = Buffer.from(type);
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(Buffer.concat([t, data])));
  return Buffer.concat([len, t, data, crc]);
}

function crc32(buf) {
  let c = ~0;
  for (const b of buf) {
    c ^= b;
    for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xEDB88320 & -(c & 1));
  }
  return (~c) >>> 0;
}

function renderPng() {
  const sig = Buffer.from([137,80,78,71,13,10,26,10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(1, 0); ihdr.writeUInt32BE(1, 4); ihdr[8] = 8; ihdr[9] = 6;
  const idat = zlib.deflateSync(Buffer.from([0, 255, 255, 255, 255]));
  return Buffer.concat([sig, pngChunk("IHDR", ihdr), pngChunk("IDAT", idat), pngChunk("IEND", Buffer.alloc(0))]);
}

function parseCompileArgs(args) {
  const positional = [];
  const opts = { format: null, deps: null, depsFormat: "json", features: "" };
  const needValue = new Set(["-f", "--format", "--root", "--input", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "--pages", "--pdf-standard", "--ppi", "--deps", "--deps-format", "-j", "--jobs", "--features", "--diagnostic-format", "--timings", "--port"]);
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") { opts.help = true; continue; }
    if (a === "--open" || a === "--timings") { if (args[i + 1] && !args[i + 1].startsWith("-")) i++; continue; }
    if (a.startsWith("--format=")) opts.format = a.split("=", 2)[1];
    else if (a.startsWith("--deps=")) opts.deps = a.split("=", 2)[1];
    else if (a.startsWith("--deps-format=")) opts.depsFormat = a.split("=", 2)[1];
    else if (a.startsWith("--features=")) opts.features = a.split("=", 2)[1];
    else if (a === "-f" || a === "--format") opts.format = args[++i];
    else if (a === "--deps") opts.deps = args[++i];
    else if (a === "--deps-format") opts.depsFormat = args[++i];
    else if (a === "--features") opts.features = args[++i];
    else if (needValue.has(a)) i++;
    else if (a.startsWith("-")) {}
    else positional.push(a);
  }
  opts.input = positional[0]; opts.output = positional[1];
  return opts;
}

function commandCompile(args, watch = false) {
  const opts = parseCompileArgs(args);
  if (opts.help) return out(compileHelp + (watch ? "\n      --no-serve\n          Disables the built-in HTTP server for HTML export\n      --no-reload\n          Disables the injected live reload script for HTML export\n      --port <PORT>\n          The port where HTML is served" : ""));
  if (!opts.input) die("error: the following required arguments were not provided:\n  <INPUT>\n\nUsage: executable compile <INPUT> [OUTPUT]\n\nFor more information, try '--help'.", 2);
  const src = opts.input === "-" ? readStdin() : fs.readFileSync(opts.input, "utf8");
  let output = opts.output || (opts.input === "-" ? "-" : opts.input.replace(/\.[^.]*$/, "") + ".pdf");
  let fmt = opts.format || (output === "-" ? "pdf" : path.extname(output).slice(1).toLowerCase()) || "pdf";
  if (!["pdf", "png", "svg", "html"].includes(fmt)) die(`error: unknown output format: ${fmt}`, 1);
  if (fmt === "html" && !String(opts.features || process.env.TYPST_FEATURES || "").split(",").includes("html")) {
    die("error: html export is only available when `--features html` is passed\n = hint: html export is under active development and incomplete\n = hint: see https://github.com/typst/typst/issues/5512 for more information", 1);
  }
  let data;
  if (fmt === "svg") data = Buffer.from(renderSvg(src));
  else if (fmt === "html") data = Buffer.from(renderHtml(src));
  else if (fmt === "png") data = renderPng();
  else data = renderPdf(src);
  if (opts.deps) {
    const deps = opts.depsFormat === "make" ? `${output}: ${opts.input}\n` : opts.depsFormat === "zero" ? `${opts.input}\0` : JSON.stringify({ input: opts.input, includes: [] }) + "\n";
    if (opts.deps === "-") process.stdout.write(deps); else fs.writeFileSync(opts.deps, deps);
  }
  if (output === "-") process.stdout.write(data); else fs.writeFileSync(output, data);
  if (watch) out("watching for changes...");
}

function toYaml(v) {
  if (Array.isArray(v)) return v.map(x => `- ${JSON.stringify(x)}`).join("\n") + "\n";
  if (v && typeof v === "object") return Object.entries(v).map(([k, val]) => `${k}: ${JSON.stringify(val)}`).join("\n") + "\n";
  return `${JSON.stringify(v)}\n`;
}

function evalExpr(expr) {
  let e = expr.trim();
  if (/^\[.*\]$/s.test(e)) return { func: "text", text: e.slice(1, -1) };
  e = e.replace(/\bcalc\.pow\s*\(/g, "Math.pow(");
  e = e.replace(/\bcalc\.sqrt\s*\(/g, "Math.sqrt(");
  e = e.replace(/\bstr\s*\(/g, "String(");
  e = e.replace(/\brange\s*\(\s*([^,]+)\s*,\s*([^)]+)\)/g, (_, a, b) => `Array.from({length:Math.max(0,(${b})-(${a}))},(_,i)=>i+(${a}))`);
  if (/^\((.*)\)$/.test(e) && e.includes(",")) e = `[${e.slice(1, -1)}]`;
  if (!/^[\d\s+\-*/%().,\[\]"'A-Za-z_{}:<>!=&|?]+$/.test(e)) throw new Error("unsupported expression");
  return Function(`"use strict"; return (${e});`)();
}

function commandEval(args) {
  if (has(args, "-h", "--help")) return out(evalHelp);
  let format = "json", pretty = false, expr = null;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "--format") format = args[++i];
    else if (a.startsWith("--format=")) format = a.split("=", 2)[1];
    else if (a === "--pretty") pretty = true;
    else if (["--in", "--target", "--root", "--input", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "-j", "--jobs", "--features", "--diagnostic-format"].includes(a)) i++;
    else if (!a.startsWith("-") && expr === null) expr = a;
  }
  if (expr === null) die("error: the following required arguments were not provided:\n  <EXPRESSION>\n\nUsage: executable eval <EXPRESSION>\n\nFor more information, try '--help'.", 2);
  try {
    const val = evalExpr(expr);
    out(format === "yaml" ? toYaml(val).trimEnd() : JSON.stringify(val, null, pretty ? 2 : 0));
  } catch (e) {
    die(`error: failed to evaluate expression\n = ${e.message}`, 1);
  }
}

function commandFonts(args) {
  if (has(args, "-h", "--help")) return out(fontsHelp);
  const families = ["DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", "Libertinus Serif", "New Computer Modern", "New Computer Modern Math"];
  if (has(args, "--variants")) families.forEach(f => out(`${f}\n  Regular\n  Bold\n  Italic`));
  else families.forEach(out);
}

function commandInfo(args) {
  if (has(args, "-h", "--help")) return out(`Displays debugging information about Typst

Usage: executable info [OPTIONS]

Options:
  -f, --format <FORMAT>  The format to serialize in, if it should be
                         machine-readable [possible values: json, yaml]
      --pretty           Whether to pretty-print the serialized output
  -h, --help             Print help (see more with '--help')`);
  const json = args.includes("--format") ? args[args.indexOf("--format") + 1] === "json" : args.includes("-f") ? args[args.indexOf("-f") + 1] === "json" : args.includes("--format=json");
  if (json) return out(JSON.stringify({ version: VERSION, commit: HASH, target: "x86_64-unknown-linux-gnu" }, null, has(args, "--pretty") ? 2 : 0));
  out(`Version ${VERSION} (${HASH}, linux on x86_64)

Build settings
  self-update off (Update Typst via \`typst update\`)
  http-server on  (Serve HTML via \`typst watch\`)

Features
  html        off (Experimental HTML support)
  a11y-extras off (Experimental accessibility additions)

Fonts
  Custom font paths <none>
  System fonts   on
  Embedded fonts on

Packages
  Package path       /home/agent/.local/share/typst/packages
  Package cache path /home/agent/.cache/typst/packages`);
}

function commandInit(args) {
  if (has(args, "-h", "--help")) return out(`Initializes a new project from a template

Usage: executable init [OPTIONS] <TEMPLATE> [DIR]

Arguments:
  <TEMPLATE>  The template to use, e.g. \`@preview/charged-ieee\`
  [DIR]       The project directory, defaults to the template's name

Options:
      --package-path <DIR>        Custom path to local packages, defaults to system-dependent location
      --package-cache-path <DIR>  Custom path to package cache, defaults to system-dependent location
  -h, --help                      Print help (see more with '--help')`);
  const pos = args.filter(a => !a.startsWith("-"));
  if (!pos[0]) die("error: the following required arguments were not provided:\n  <TEMPLATE>", 2);
  const dir = pos[1] || pos[0].split("/").pop().replace(/^@/, "") || "typst-project";
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, "main.typ"), "= Title\n\nStart writing here.\n");
  out(`Successfully created project in ${dir}`);
}

function commandCompletions(args) {
  if (has(args, "-h", "--help") || args.length === 0) return out(`Generates shell completion scripts

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate completions for [possible values: bash, elvish,
           fish, powershell, zsh]

Options:
  -h, --help  Print help`);
  out(`# completion script for ${args[0]}`);
}

function main() {
  let args = stripGlobalOptions(process.argv.slice(2));
  if (args.length === 0) return out(welcome);
  if (has(args, "-V", "--version")) return out(`typst ${VERSION} (${HASH})`);
  if (has(args, "-h", "--help") && (args[0] === "-h" || args[0] === "--help")) return out(mainHelp);
  let cmd = args.shift();
  if (cmd === "help") {
    if (!args[0]) return out(mainHelp);
    cmd = args[0];
    args = ["--help"];
  }
  if (cmd === "compile" || cmd === "c") return commandCompile(args);
  if (cmd === "watch" || cmd === "w") return commandCompile(args, true);
  if (cmd === "eval") return commandEval(args);
  if (cmd === "fonts") return commandFonts(args);
  if (cmd === "info") return commandInfo(args);
  if (cmd === "init") return commandInit(args);
  if (cmd === "completions") return commandCompletions(args);
  die(`error: unrecognized subcommand '${cmd}'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.`, 2);
}

main();
