#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const VERSION = 'argc 1.23.0';

function die(msg, code = 1) {
  process.stderr.write(msg + '\n');
  process.exit(code);
}

function baseName(file) {
  return path.basename(file).replace(/\.[^.]+$/, '');
}

function idFromName(name) {
  return name.replace(/^[+-]+/, '').replace(/[^A-Za-z0-9]+/g, '_').replace(/^_+|_+$/g, '').toLowerCase();
}

function cmdNameFromFn(fn) {
  return fn.split('::').map(s => s.replace(/_/g, '-')).join(' ');
}

function fnFromCmdPath(names) {
  return names.map(s => s.replace(/-/g, '_')).join('::');
}

function shQuote(s) {
  s = String(s ?? '');
  if (s === '') return "''";
  if (/^[A-Za-z0-9_@%+=:,./-]+$/.test(s)) return s;
  return "'" + s.replace(/'/g, "'\\''") + "'";
}

function arrLiteral(values) {
  return `( ${values.map(shQuote).join(' ')} )`;
}

function runFunc(file, fn) {
  try {
    const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
    const kept = [];
    for (const line of lines) {
      if (line.includes('argc --argc-eval')) break;
      kept.push(line);
    }
    const out = cp.execFileSync('bash', ['-lc', `${kept.join('\n')}\n${fn}`], {encoding: 'utf8'});
    return out.trim().split(/\r?\n/).filter(Boolean);
  } catch {
    return [];
  }
}

function parseSpec(raw) {
  let spec = raw;
  const obj = {raw, default: null, choice: null, skipChoice: false, required: false, multiple: false, delimiter: null, terminated: false};
  const b = spec.match(/^(.*)\[(.*)\]$/);
  if (b) {
    spec = b[1];
    let body = b[2];
    if (body.startsWith('?')) { obj.skipChoice = true; body = body.slice(1); }
    if (body.startsWith('=')) { obj.default = body.slice(1).split('|')[0]; body = body.slice(1); }
    if (/^`.*`$/.test(body)) obj.choiceFn = body.slice(1, -1);
    else obj.choice = body.split('|').filter(Boolean);
  }
  const eq = spec.match(/^(.*?)=(.*)$/);
  if (eq) {
    spec = eq[1];
    obj.default = eq[2];
    if (/^`.*`$/.test(obj.default)) obj.defaultFn = obj.default.slice(1, -1);
  }
  if (spec.endsWith('~')) { obj.terminated = true; spec = spec.slice(0, -1); }
  if (spec.endsWith(',')) { obj.delimiter = ','; spec = spec.slice(0, -1); }
  if (spec.endsWith('*') || spec.endsWith('+') || spec.endsWith('!')) {
    const c = spec.slice(-1);
    spec = spec.slice(0, -1);
    obj.multiple = c === '*' || c === '+';
    obj.required = c === '+' || c === '!';
  }
  obj.name = spec;
  return obj;
}

function parseParam(tag, body, file) {
  const parts = body.trim().split(/\s+/).filter(Boolean);
  const names = [];
  while (parts.length && /^[+-]/.test(parts[0]) && !/^<.*>$/.test(parts[0])) names.push(parts.shift());
  if (!names.length && parts.length) names.push(parts.shift());
  const notations = [];
  while (parts.length && /^<.*>$/.test(parts[0])) notations.push(parts.shift().slice(1, -1));
  let env = null;
  if (parts.length && (parts[0] === '$$' || /^\$[A-Za-z_]/.test(parts[0]))) env = parts.shift();
  const describe = parts.join(' ');
  const parsedNames = names.map(parseSpec);
  const primary = parsedNames.find(n => n.name.startsWith('--')) || parsedNames.find(n => n.name.startsWith('+') && n.name.length > 2) || parsedNames[parsedNames.length - 1];
  const p = {
    tag, describe, names: parsedNames.map(n => n.name), rawNames: names,
    id: idFromName(primary.name), long_name: null, short_name: null, flag: tag === 'flag',
    notations, required: primary.required, multiple_occurs: primary.multiple,
    delimiter: primary.delimiter, terminated: primary.terminated, default: primary.default,
    defaultFn: primary.defaultFn, choice: primary.choice, choiceFn: primary.choiceFn,
    skipChoice: primary.skipChoice, num_args: [tag === 'flag' ? 0 : 1, tag === 'flag' ? 0 : 1],
    env,
  };
  for (const n of parsedNames) {
    if (n.name.length === 2 && /^[+-]./.test(n.name)) p.short_name = n.name;
    else if (n.name.length > 0) p.long_name = n.name;
  }
  if (!p.long_name && p.short_name) p.id = idFromName(p.short_name);
  if (notations.length) {
    let min = 0, max = 0;
    for (const no of notations) {
      if (no.endsWith('*')) max = 9999;
      else if (no.endsWith('+')) { min++; max = 9999; }
      else if (no.endsWith('?')) max++;
      else { min++; max++; }
    }
    p.num_args = [min, max];
    if (max > 1 || max === 9999) p.multiple_values = true;
  } else if (tag === 'option') {
    p.num_args = [1, 1];
  }
  if (p.choiceFn) p.choice = runFunc(file, p.choiceFn);
  if (p.defaultFn) p.default = runFunc(file, p.defaultFn)[0] || null;
  return p;
}

function makeCommand(name, fn, describe = '') {
  return {name, fn, describe, long: [], aliases: [], flags: [], args: [], envs: [], subs: [], meta: {}, parent: null};
}

function getOrCreate(root, words, fn) {
  let cur = root;
  for (let i = 0; i < words.length; i++) {
    let sub = cur.subs.find(s => s.name === words[i]);
    if (!sub) {
      sub = makeCommand(words[i], i === words.length - 1 ? fn : null);
      sub.parent = cur;
      cur.subs.push(sub);
    }
    cur = sub;
  }
  if (fn) cur.fn = fn;
  return cur;
}

function applyBlock(root, target, block, file) {
  let cmdTag = null;
  for (const item of block.items) {
    if (item.tag === 'describe') target.describe = item.body;
    else if (item.tag === 'cmd') { cmdTag = item.body || ''; target.describe = cmdTag; }
    else if (item.tag === 'alias') target.aliases.push(...item.body.split(/[,\s]+/).filter(Boolean));
    else if (item.tag === 'meta') {
      const [k, ...v] = item.body.split(/\s+/);
      target.meta[k] = v.join(' ') || true;
    } else if (item.tag === 'flag' || item.tag === 'option') target.flags.push(parseParam(item.tag, item.body, file));
    else if (item.tag === 'arg') {
      const p = parseParam(item.tag, item.body, file);
      p.id = idFromName(p.names[0]);
      p.notation = (p.notations[0] || p.id.toUpperCase()).replace(/[!*+=~,].*$/, '');
      p.multiple = p.multiple_occurs;
      target.args.push(p);
    } else if (item.tag === 'env') target.envs.push(item.body);
  }
}

function readBlocks(file) {
  const text = fs.readFileSync(file, 'utf8');
  const lines = text.split(/\r?\n/);
  const blocks = [];
  let comments = [];
  function flush(nextFn) {
    if (!comments.length) return;
    const items = [];
    let last = null;
    for (const raw of comments) {
      const c = raw.replace(/^\s*#\s?/, '');
      const m = c.match(/^@(\S+)\s*(.*)$/);
      if (m) { last = {tag: m[1], body: m[2].trim(), extra: []}; items.push(last); }
      else if (last && c.trim()) last.body += (last.body ? '\n' : '') + c.trim();
    }
    if (items.length) blocks.push({fn: nextFn, items});
    comments = [];
  }
  for (const line of lines) {
    if (/^\s*#/.test(line)) { comments.push(line); continue; }
    const m = line.match(/^\s*(?:function\s+)?([A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)?|[A-Za-z_][A-Za-z0-9_-]*)\s*(?:\(\))?\s*\{/);
    if (m) { flush(m[1]); continue; }
    if (/\S/.test(line)) flush(null);
  }
  flush(null);
  return blocks;
}

function parseFile(file) {
  const root = makeCommand(baseName(file), null);
  const text = fs.readFileSync(file, 'utf8');
  for (const block of readBlocks(file)) {
    const hasCmd = block.items.some(i => i.tag === 'cmd');
    if (hasCmd && block.fn) {
      const words = cmdNameFromFn(block.fn).split(/\s+/);
      const cmd = getOrCreate(root, words, block.fn);
      applyBlock(root, cmd, block, file);
    } else {
      applyBlock(root, root, block, file);
      if (block.fn === 'main') root.fn = 'main';
    }
  }
  if (!root.fn && /^\s*(?:function\s+)?main\s*(?:\(\))?\s*\{/m.test(text)) root.fn = 'main';
  addBuiltins(root, true);
  inherit(root);
  return root;
}

function addBuiltins(cmd, isRoot = false) {
  for (const sub of cmd.subs) addBuiltins(sub, false);
  if (!cmd.flags.some(f => f.id === 'help')) cmd.flags.push({tag:'flag', id:'help', long_name:'--help', short_name:'-h', names:['--help','-h'], describe:isRoot?'':'Print help', flag:true, notations:[], required:false, multiple_occurs:false, num_args:[0,0]});
  if (isRoot && !cmd.flags.some(f => f.id === 'version')) cmd.flags.push({tag:'flag', id:'version', long_name:'--version', short_name:'-V', names:['--version','-V'], describe:'', flag:true, notations:[], required:false, multiple_occurs:false, num_args:[0,0]});
}

function inherit(cmd) {
  for (const sub of cmd.subs) {
    if (cmd.meta['inherit-flag-options']) {
      const inherited = cmd.flags.filter(f => !['help','version'].includes(f.id)).map(f => ({...f, inherited:true}));
      sub.flags = [...inherited, ...sub.flags];
      sub.meta['inherit-flag-options'] = true;
    }
    inherit(sub);
  }
}

function usage(cmd, root) {
  const parts = [root.name];
  const chain = [];
  let c = cmd;
  while (c && c.parent) { chain.unshift(c.name); c = c.parent; }
  parts.push(...chain);
  if (cmd.subs.length) parts.push('<COMMAND>');
  if (cmd.flags.some(f => !['help','version'].includes(f.id))) parts.push('[OPTIONS]');
  for (const a of cmd.args) {
    let n = a.notation || a.id.toUpperCase();
    if (a.multiple) n += '...';
    parts.push(a.required ? `<${n}>` : `[${n}]`);
  }
  return parts.join(' ');
}

function optDisplay(f) {
  let names = [];
  if (f.short_name) names.push(f.short_name);
  if (f.long_name) names.push(f.long_name);
  if (!names.length && f.names) names = f.names;
  let s = names.join(', ');
  if (!f.flag) {
    let n = f.notations && f.notations.length ? f.notations.join(' ').replace(/[?*+]>/g, '>') : f.id.toUpperCase();
    if (f.multiple_occurs) n = `[${f.id.toUpperCase()}]...`;
    else n = `<${n}>`;
    s += ' ' + n;
  }
  return s;
}

function helpText(cmd, root) {
  const out = [];
  if (cmd.describe) out.push(cmd.describe, '');
  out.push('USAGE: ' + usage(cmd, root), '');
  if (cmd.args.length) {
    out.push('ARGS:');
    const labels = cmd.args.map(a => (a.required ? `<${a.notation}${a.multiple?'...':''}>` : `[${a.notation}${a.multiple?'...':''}]`));
    const w = Math.max(...labels.map(s => s.length));
    cmd.args.forEach((a, i) => out.push(`  ${labels[i].padEnd(w)}  ${a.describe || ''}`.trimEnd()));
    out.push('');
  }
  if (cmd.flags.length && cmd.flags.some(f => f.id !== 'version' || root === cmd)) {
    out.push('OPTIONS:');
    const flags = cmd.flags.filter(f => !(f.id === 'version' && cmd !== root));
    const labels = flags.map(optDisplay);
    const w = Math.max(...labels.map(s => s.length));
    flags.forEach((f, i) => {
      let desc = f.describe || (f.id === 'help' ? 'Print help' : f.id === 'version' ? 'Print version' : '');
      if (f.choice && f.choice.length && !f.skipChoice) desc += `${desc?' ':''}[possible values: ${f.choice.join(', ')}]`;
      if (f.default) desc += `${desc?' ':''}[default: ${f.default}]`;
      out.push(`  ${labels[i].padEnd(w)}  ${desc}`.trimEnd());
    });
    out.push('');
  }
  if (cmd.subs.length) {
    out.push('COMMANDS:');
    const labels = cmd.subs.map(s => s.name);
    const w = Math.max(...labels.map(s => s.length));
    cmd.subs.forEach(s => {
      let d = s.describe || '';
      if (s.aliases.length) d += `${d?' ':''}[aliases: ${s.aliases.join(', ')}]`;
      out.push(`  ${s.name.padEnd(w)}  ${d}`.trimEnd());
    });
    out.push('');
  }
  return out.join('\n');
}

function errorEval(lines) {
  return `command cat >&2 <<-'EOF' \n${lines.join('\n')}\nEOF\nexit 1`;
}

function printHelpEval(cmd, root) {
  return `command cat >&2 <<-'EOF' \n${helpText(cmd, root)}\nEOF\nexit 0`;
}

function findSub(root, args) {
  let cmd = root, consumed = [];
  while (args.length) {
    const hit = cmd.subs.find(s => s.name === args[0] || s.aliases.includes(args[0]));
    if (!hit) break;
    consumed.push(args.shift());
    cmd = hit;
  }
  return {cmd, consumed};
}

function optionMaps(cmd) {
  const m = new Map();
  for (const f of cmd.flags) for (const n of (f.names || [f.short_name, f.long_name]).filter(Boolean)) m.set(n, f);
  return m;
}

function parseArgs(root, argv) {
  const def = root.subs.find(s => s.meta['default-subcommand']);
  if (def && argv.length && !argv[0].startsWith('-') && !root.subs.some(s => s.name === argv[0] || s.aliases.includes(argv[0]))) {
    argv = [def.name, ...argv];
  }
  const original = [root.name, ...argv];
  const work = argv.slice();
  const {cmd, consumed} = findSub(root, work);
  const maps = optionMaps(cmd);
  const vals = {}, pos = [];
  for (const f of cmd.flags) {
    if (f.default) vals[f.id] = f.multiple_occurs ? [f.default] : f.default;
    else if (f.env) {
      const envName = f.env === '$$' ? f.id.toUpperCase() : f.env.replace(/^\$/, '');
      if (process.env[envName]) vals[f.id] = process.env[envName];
    }
  }
  function addVal(f, v) {
    if (f.flag) {
      vals[f.id] = v;
      return;
    }
    if (f.delimiter && typeof v === 'string') {
      const parts = v.split(f.delimiter).filter(x => x !== '');
      if (!Array.isArray(vals[f.id])) vals[f.id] = [];
      vals[f.id].push(...parts);
    } else if (f.multiple_occurs || f.multiple_values) {
      if (!Array.isArray(vals[f.id])) vals[f.id] = [];
      vals[f.id].push(v);
    } else vals[f.id] = v;
  }
  for (let i = 0; i < work.length; i++) {
    let a = work[i];
    if (a === '--') { pos.push(...work.slice(i + 1)); break; }
    if ((a === '-h' || a === '--help' || a === '+help') && maps.has(a)) return {help: true, cmd};
    if ((a === '-V' || a === '--version') && cmd === root) return {version: true, cmd};
    if (/^-[A-Za-z]{2,}$/.test(a) && root.meta['combine-shorts']) {
      const chars = a.slice(1).split('').map(ch => '-' + ch);
      if (chars.every(ch => maps.has(ch) && maps.get(ch).flag)) {
        chars.forEach(ch => addVal(maps.get(ch), (Number(vals[maps.get(ch).id]) || 0) + 1));
        continue;
      }
    }
    let name = a, attached = null;
    const eq = a.match(/^([^=]+)=(.*)$/);
    if (eq) { name = eq[1]; attached = eq[2]; }
    let f = maps.get(name);
    if (!f) {
      f = [...maps.values()].find(x => x.names && x.names.some(n => x.prefixed && a.startsWith(n)));
    }
    if (f && /^[+-]/.test(name)) {
      if (f.flag) addVal(f, (Number(vals[f.id]) || 0) + 1);
      else {
        const count = f.num_args ? f.num_args[1] : 1;
        if (f.terminated) {
          addVal(f, work.slice(i + 1));
          i = work.length;
        } else if (attached !== null) addVal(f, attached);
        else if (count > 1 && count < 9999) {
          for (let k = 0; k < count; k++) addVal(f, work[++i]);
        } else if (count === 9999) {
          while (i + 1 < work.length && !/^[+-]/.test(work[i + 1])) addVal(f, work[++i]);
        } else addVal(f, work[++i]);
      }
    } else pos.push(a);
  }
  let pi = 0;
  for (const a of cmd.args) {
    if (a.default) vals[a.id] = a.default;
    if (a.env) {
      const envName = a.env === '$$' ? a.id.toUpperCase() : a.env.replace(/^\$/, '');
      if (process.env[envName]) vals[a.id] = process.env[envName];
    }
    if (a.terminated) { vals[a.id] = pos.slice(pi); pi = pos.length; }
    else if (a.multiple) {
      const remainDefs = cmd.args.slice(cmd.args.indexOf(a) + 1).filter(x => !x.multiple).length;
      vals[a.id] = pos.slice(pi, pos.length - remainDefs);
      pi = pos.length - remainDefs;
    } else if (pi < pos.length) vals[a.id] = pos[pi++];
  }
  const missing = [];
  for (const f of cmd.flags) if (f.required && (vals[f.id] == null || (Array.isArray(vals[f.id]) && !vals[f.id].length))) missing.push(`${f.long_name || f.short_name} <${f.id.toUpperCase()}>${f.multiple_occurs?'...':''}`);
  for (const a of cmd.args) if (a.required && (vals[a.id] == null || (Array.isArray(vals[a.id]) && !vals[a.id].length))) missing.push(`<${a.notation}>${a.multiple?'...':''}`);
  if (missing.length) return {error: ['error: the following required arguments were not provided:', ...missing.map(s => '  ' + s)], cmd};
  const bad = [];
  function chk(p) {
    if (!p.choice || p.skipChoice) return;
    const vs = Array.isArray(vals[p.id]) ? vals[p.id] : [vals[p.id]];
    for (const v of vs) if (v != null && !p.choice.includes(String(v))) bad.push(`error: invalid value '${v}' for '${p.long_name || p.id}'`);
  }
  cmd.flags.forEach(chk); cmd.args.forEach(chk);
  if (bad.length) return {error: bad, cmd};
  return {cmd, vals, pos, original, consumed};
}

function emitEval(file, argv) {
  const root = parseFile(file);
  const r = parseArgs(root, argv);
  if (r.help) return printHelpEval(r.cmd, root);
  if (r.version) return `command cat >&2 <<-'EOF' \n${VERSION}\nEOF\nexit 0`;
  if (r.error) return errorEval(r.error);
  const lines = [];
  const varsForBase64 = [];
  for (const [k, v] of Object.entries(r.vals)) {
    if (v == null || (Array.isArray(v) && !v.length)) continue;
    if (Array.isArray(v)) lines.push(`argc_${k}=${arrLiteral(v)}`);
    else lines.push(`argc_${k}=${shQuote(v)}`);
  }
  lines.push(`argc__args=${arrLiteral(r.original)}`);
  if (r.cmd.fn) lines.push(`argc__fn=${shQuote(r.cmd.fn)}`);
  lines.push(`argc__positionals=${arrLiteral(r.pos)}`);
  const assign = lines.join('\n');
  const flat = lines.map(l => l.replace(/\n/g, '')).join(';');
  const b64 = Buffer.from(flat).toString('base64');
  const call = [];
  call.push(`export ARGC_VARS=${b64}`);
  call.push(assign);
  if (r.cmd.fn) {
    call.push('if declare -F _argc_before >/dev/null; then _argc_before; fi');
    call.push(`${r.cmd.fn} ${r.pos.map(shQuote).join(' ')}`.trim());
    call.push('argc__status=$?');
    call.push('if declare -F _argc_after >/dev/null; then _argc_after; fi');
    call.push('return $argc__status 2>/dev/null || exit $argc__status');
  }
  return call.join('\n');
}

function toExport(cmd, root) {
  return {
    name: cmd.name, describe: cmd.describe || null, version: null, aliases: cmd.aliases,
    flag_options: cmd.flags.map(f => ({
      id:f.id,long_name:f.long_name||null,short_name:f.short_name||null,describe:f.describe||'',flag:!!f.flag,notations:f.notations||[],required:!!f.required,
      multiple_values:!!f.multiple_values,multiple_occurs:!!f.multiple_occurs,num_args:f.num_args||[0,0],delimiter:f.delimiter||null,terminated:!!f.terminated,
      prefixed:!!f.prefixed,assigned:!!f.assigned,default:f.default||null,choice:f.choice||null,env:f.env||null,inherited:!!f.inherited
    })),
    positionals: cmd.args.map(a => ({id:a.id,describe:a.describe||'',notation:a.notation,required:!!a.required,multiple:!!a.multiple,delimiter:a.delimiter||null,terminated:!!a.terminated,default:a.default||null,choice:a.choice||null,env:a.env||null})),
    envs: [], subcommands: cmd.subs.map(s => toExport(s, root)), command_fn: cmd.fn || null
  };
}

function compgen(file, args) {
  const root = parseFile(file);
  const r = findSub(root, args.slice());
  const last = args[args.length - 1] || '';
  const rows = [];
  if (last.startsWith('-') || args.length === 0) {
    for (const f of r.cmd.flags) {
      if (f.long_name) rows.push(`${f.long_name} ${f.describe || (f.id === 'help' ? 'Print help' : f.id === 'version' ? 'Print version' : '')}`);
    }
  } else {
    for (const s of r.cmd.subs) rows.push(`${s.name} ${s.describe || ''}`);
  }
  return rows.join('\n');
}

function exportScript(file, out) {
  const src = fs.readFileSync(file, 'utf8');
  const self = process.argv[1] || 'argc';
  const pre = `#!/usr/bin/env bash\n# generated by argc compatibility clone\n`;
  fs.writeFileSync(out, pre + src.replace(/eval "\$\(argc --argc-eval "\$0" "\$@"\)"/g, `eval "$(${self} --argc-eval "$0" "$@")"`));
  fs.chmodSync(out, 0o755);
}

function main() {
  const argv = process.argv.slice(2);
  const cmd = argv.shift();
  if (cmd === '--argc-help') {
    process.stdout.write('A bash cli framework, also a bash-based command runner - https://github.com/sigoden/argc\n\nUSAGE:\n    argc --argc-eval <FILE> <ARGS~>            Use `eval "$(argc --argc-eval "$0" "$@")"`\n    argc --argc-create <RECIPES~>              Create a boilerplate argcfile\n    argc --argc-run <FILE> <ARGS~>             Run an argc-based script\n    argc --argc-build <FILE> <OUTPATH?>        Generate bashscript without argc dependency\n    argc --argc-mangen <FILE> <OUTDIR>         Generate man pages\n    argc --argc-completions <SHELL> <CMDS>     Generate shell completion scripts\n    argc --argc-compgen <SHELL> <FILE> <ARGS>  Generate completion candidates\n    argc --argc-export <FILE>                  Export command line definitions as json\n    argc --argc-parallel <FILE> <ARGS~>        Run functions in parallel\n    argc --argc-script-path                    Print current argcfile path\n    argc --argc-shell-path                     Print current shell path\n    argc --argc-help                           Print help information\n    argc --argc-version                        Print version information\n');
  } else if (cmd === '--argc-version') process.stdout.write(VERSION + '\n');
  else if (cmd === '--argc-shell-path') process.stdout.write('/usr/bin/bash\n');
  else if (cmd === '--argc-script-path') die('Argcfile not found.');
  else if (cmd === '--argc-eval') {
    const file = argv.shift(); if (!file) die('error: missing FILE');
    process.stdout.write(emitEval(file, argv) + '\n');
  } else if (cmd === '--argc-export') {
    const file = argv.shift(); if (!file) die('error: missing FILE');
    process.stdout.write(JSON.stringify(toExport(parseFile(file)), null, 2) + '\n');
  } else if (cmd === '--argc-compgen') {
    argv.shift(); const file = argv.shift(); if (!file) die('error: missing FILE');
    const out = compgen(file, argv); if (out) process.stdout.write(out + '\n');
  } else if (cmd === '--argc-run') {
    const file = argv.shift(); if (!file) die('error: missing FILE');
    const code = emitEval(file, argv);
    cp.spawnSync('bash', ['-lc', `source ${shQuote(file)} >/dev/null; eval ${shQuote(code)}`], {stdio:'inherit'});
  } else if (cmd === '--argc-parallel') {
    const file = argv.shift(); if (!file) die('error: missing FILE');
    const groups = [[]];
    for (const a of argv) {
      if (a === ':::') groups.push([]);
      else groups[groups.length - 1].push(a);
    }
    const text = fs.readFileSync(file, 'utf8').split(/\r?\n/);
    const kept = [];
    for (const line of text) {
      if (line.includes('argc --argc-eval')) break;
      kept.push(line);
    }
    const assigns = process.env.ARGC_VARS ? Buffer.from(process.env.ARGC_VARS, 'base64').toString('utf8') : '';
    let status = 0;
    for (const g of groups.filter(x => x.length)) {
      const [fn, ...rest] = g;
      const script = `${kept.join('\n')}\n${assigns}\n${fn} ${rest.map(shQuote).join(' ')}`;
      const r = cp.spawnSync('bash', ['-lc', script], {stdio:'inherit'});
      if (r.status) status = r.status;
    }
    process.exit(status);
  } else if (cmd === '--argc-build' || cmd === '--argc-export-script') {
    const file = argv.shift(); const out = argv.shift() || path.basename(file);
    const target = fs.existsSync(out) && fs.statSync(out).isDirectory() ? path.join(out, path.basename(file)) : out;
    exportScript(file, target);
  } else if (cmd === '--argc-mangen') {
    const file = argv.shift(); const dir = argv.shift() || '.';
    fs.mkdirSync(dir, {recursive:true});
    const root = parseFile(file);
    fs.writeFileSync(path.join(dir, `${root.name}.1`), `.TH ${root.name.toUpperCase()} 1\n.SH NAME\n${root.name} - ${root.describe || ''}\n.SH SYNOPSIS\n${usage(root, root)}\n`);
  } else if (cmd === '--argc-completions') {
    process.stdout.write('# argc completion compatibility stub\n');
  } else if (cmd === '--argc-create') {
    const recipes = argv.length ? argv : ['hello'];
    process.stdout.write(recipes.map(r => `# @cmd\n${r.replace(/-/g, '_')}() {\n    :;\n}`).join('\n'));
  } else {
    die('Argcfile not found, try `argc --argc-help` for help.');
  }
}

main();
