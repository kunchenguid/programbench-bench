#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const VERSION = "commit-93cc85d16ab60ba8d646458fe0233778317b22a3";
const DEFAULT_CONFIG = "/home/agent/.caps-log/config.ini";
const DEFAULT_LOG_DIR = "/home/agent/.caps-log/day/";

function help() {
  return `Captain's Log (caps-log)! A CLI journalig tool.
Version: ${VERSION}
Allowed options:
  -h [ --help ]         show this message
  -c [ --config ] arg   override the default config file path 
                        (${DEFAULT_CONFIG})
  --log-dir-path arg    path where log files are stored
  --log-name-format arg format in which log entry markdown files are saved
  --sunday-start        have the calendar display sunday as first day of the 
                        week
  --first-line-section  override the default behaviour of ignoring sections 
                        (lines starting with \`#\`) in the first line of a log 
                        entry file
  --password arg        password for encrypted log repositories or to be used 
                        with --encrypt/--decrypt
  --encrypt             apply encryption to all logs in log dir path (needs 
                        --password)
  --decrypt             apply decryption to all logs in log dir path (needs 
                        --password)
`;
}

function fail(message) {
  console.log("Captain's log encountered an error: ");
  console.log(" " + message);
  process.exitCode = 1;
}

function parseArgs(argv) {
  const opts = {
    config: DEFAULT_CONFIG,
    logDir: undefined,
    logNameFormat: "d%y_%m_%d.md",
    sundayStart: false,
    firstLineSection: false,
    password: undefined,
    encrypt: false,
    decrypt: false,
    help: false,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const need = (name) => {
      if (i + 1 >= argv.length || argv[i + 1].startsWith("-")) {
        throw new Error(`the required argument for option '${name}' is missing`);
      }
      return argv[++i];
    };
    if (a === "-h" || a === "--help") opts.help = true;
    else if (a === "-c" || a === "--config") opts.config = need(a);
    else if (a === "--log-dir-path") opts.logDir = need(a);
    else if (a === "--log-name-format") opts.logNameFormat = need(a);
    else if (a === "--sunday-start") opts.sundayStart = true;
    else if (a === "--first-line-section") opts.firstLineSection = true;
    else if (a === "--password") opts.password = need(a);
    else if (a === "--encrypt") opts.encrypt = true;
    else if (a === "--decrypt") opts.decrypt = true;
    else throw new Error(`unrecognised option '${a}'`);
  }
  return opts;
}

function readConfig(file) {
  if (!fs.existsSync(file)) {
    throw new Error(`Failed to open file: ${file}`);
  }
  const cfg = {};
  let section = "";
  const text = fs.readFileSync(file, "utf8");
  for (const raw of text.split(/\r?\n/)) {
    let line = raw.replace(/\s+#.*$/, "").trim();
    if (!line || line.startsWith("#") || line.startsWith(";")) continue;
    const sec = line.match(/^\[([^\]]+)\]$/);
    if (sec) {
      section = sec[1] + ".";
      continue;
    }
    const eq = line.indexOf("=");
    if (eq !== -1) cfg[section + line.slice(0, eq).trim()] = line.slice(eq + 1).trim();
  }
  return cfg;
}

function resolveOptions(opts, cfg) {
  if (!opts.logDir) opts.logDir = cfg["log-dir-path"] || DEFAULT_LOG_DIR;
  if (cfg["log-filename-format"] && opts.logNameFormat === "d%y_%m_%d.md") {
    opts.logNameFormat = cfg["log-filename-format"];
  }
  if (!opts.password && cfg.password) opts.password = cfg.password;
  if (cfg["sunday-start"] === "true") opts.sundayStart = true;
  if (cfg["first-line-section"] === "true") opts.firstLineSection = true;
}

function markerFor(password) {
  return crypto.createHash("sha256").update("caps-log:" + password).digest().subarray(0, 18);
}

function deriveKey(password) {
  return crypto.createHash("sha256").update(password).digest();
}

function isProbablyLogFile(name) {
  return /\.md$/i.test(name) || /^\d{2,4}[_-]\d{1,2}[_-]\d{1,2}/.test(name) || /^d\d{2,4}[_-]\d{1,2}[_-]\d{1,2}/.test(name);
}

function cryptFile(file, password, decrypt) {
  const data = fs.readFileSync(file);
  if (data.length === 0) return;
  const key = deriveKey(password);
  if (decrypt && data.subarray(0, 4).toString() === "CLG1") {
    const iv = data.subarray(4, 20);
    const body = data.subarray(20);
    const decipher = crypto.createDecipheriv("aes-256-ctr", key, iv);
    fs.writeFileSync(file, Buffer.concat([decipher.update(body), decipher.final()]));
  } else if (!decrypt && data.subarray(0, 4).toString() !== "CLG1") {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv("aes-256-ctr", key, iv);
    fs.writeFileSync(file, Buffer.concat([Buffer.from("CLG1"), iv, cipher.update(data), cipher.final()]));
  }
}

function applyCrypto(opts) {
  if (!opts.password) {
    throw new Error(`Password must be provided when ${opts.encrypt ? "encrypting" : "decrypting"} logs!`);
  }
  console.log("Applying crypto...");
  const marker = path.join(opts.logDir, ".cle");
  const hasMarker = fs.existsSync(marker);
  if ((opts.encrypt && hasMarker) || (opts.decrypt && !hasMarker)) {
    throw new Error("Already applied");
  }
  let entries;
  try {
    entries = fs.readdirSync(opts.logDir, { withFileTypes: true });
  } catch (e) {
    if (e && e.code === "ENOENT") {
      throw new Error(`filesystem error: directory iterator cannot open directory: No such file or directory [${opts.logDir}]`);
    }
    throw e;
  }
  for (const ent of entries) {
    if (ent.isFile() && ent.name !== ".cle" && isProbablyLogFile(ent.name)) {
      try {
        cryptFile(path.join(opts.logDir, ent.name), opts.password, opts.decrypt);
      } catch (_) {
        // The original reports password problems only when opening the app; crypto mode is forgiving.
      }
    }
  }
  if (opts.encrypt) fs.writeFileSync(marker, markerFor(opts.password));
  else fs.unlinkSync(marker);
}

function parseLogDate(name) {
  const m = name.match(/^d?(\d{2}|\d{4})[_-](\d{1,2})[_-](\d{1,2})/);
  if (!m) return null;
  let y = Number(m[1]);
  if (y < 100) y += 2000;
  const mon = Number(m[2]);
  const day = Number(m[3]);
  if (mon < 1 || mon > 12 || day < 1 || day > 31) return null;
  return { y, mon, day };
}

function loadLogs(dir, firstLineSection) {
  const out = [];
  let entries = [];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (_) {
    return out;
  }
  for (const ent of entries) {
    if (!ent.isFile()) continue;
    const date = parseLogDate(ent.name);
    if (!date) continue;
    let text = "";
    try {
      text = fs.readFileSync(path.join(dir, ent.name), "utf8");
    } catch (_) {}
    const sections = [];
    const tags = [];
    const lines = text.split(/\r?\n/);
    let current = "<root section>";
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if ((i > 0 || firstLineSection) && /^#\s+/.test(line)) {
        current = line.replace(/^#\s+/, "").trim();
        sections.push(current);
      } else if (/^\*\s+/.test(line)) {
        const tag = line.replace(/^\*\s+/, "").replace(/\s*\(.*$/, "").replace(/:.*$/, "").trim();
        if (tag) tags.push({ tag, section: current });
      }
    }
    out.push({ ...date, name: ent.name, text, sections, tags });
  }
  return out;
}

function pad2(n) {
  return String(n).padStart(2, "0");
}

function daysInMonth(year, month) {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

function weekday(year, month, day, sundayStart) {
  const d = new Date(Date.UTC(year, month - 1, day)).getUTCDay();
  return sundayStart ? d : (d + 6) % 7;
}

function monthBlock(year, month, sundayStart, logDays, today) {
  const names = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const header = sundayStart ? " S  M  T  W  T  F  S " : " M  T  W  T  F  S  S ";
  const lines = [`╭${names[month - 1].padEnd(19, "─")}╮`, `│${header}│`];
  let line = "│";
  for (let i = 0; i < weekday(year, month, 1, sundayStart); i++) line += "   ";
  for (let d = 1; d <= daysInMonth(year, month); d++) {
    let s = String(d).padStart(2, " ");
    if (today && today.y === year && today.mon === month && today.day === d) s = `\x1b[31m${s}\x1b[39m`;
    else if (logDays.has(`${year}-${month}-${d}`)) s = `\x1b[32m${s}\x1b[39m`;
    const w = weekday(year, month, d, sundayStart);
    if (w >= 5) s = `\x1b[34m${s}\x1b[39m`;
    line += s + " ";
    if (w === 6 && d !== daysInMonth(year, month)) {
      lines.push(line.padEnd(22, " ") + "│");
      line = "│";
    }
  }
  lines.push(line.padEnd(22, " ") + "│");
  while (lines.length < 8) lines.push("│                     │");
  lines.push("╰─────────────────────╯");
  return lines;
}

function renderTui(opts) {
  const now = new Date();
  const today = { y: now.getFullYear(), mon: now.getMonth() + 1, day: now.getDate() };
  const logs = loadLogs(opts.logDir, opts.firstLineSection);
  const yearLogs = logs.filter((l) => l.y === today.y);
  const logDays = new Set(yearLogs.map((l) => `${l.y}-${l.mon}-${l.day}`));
  const sections = [...new Set(logs.flatMap((l) => l.sections))];
  const tags = [...new Set(logs.flatMap((l) => l.tags.map((t) => t.tag)))];
  const lines = [];
  lines.push(`       \x1b[1m\x1b[4mToday is: ${pad2(today.day)}. ${pad2(today.mon)}. ${today.y}.  | There are ${yearLogs.length} log entries for year ${today.y}.\x1b[22m\x1b[24m        `);
  lines.push("╭Sections───────────╮ ╭Tags──────────────╮ ╭" + String(today.y).padEnd(21, "─") + "╮");
  const maxMenu = Math.max(1, sections.length, tags.length, 10);
  const months = [];
  for (let m = 1; m <= 12; m++) months.push(monthBlock(today.y, m, opts.sundayStart, logDays, today));
  for (let i = 0; i < maxMenu; i++) {
    const s = i === 0 ? (sections[0] || "<select none>") : (sections[i] || "");
    const t = i === 0 ? (tags[0] || "<select none>") : (tags[i] || "");
    const mline = (months[0][i] || months[1][i - 9] || "").slice(0, 80);
    lines.push(`│${(i === 0 ? "> " : "  ") + s}`.padEnd(20, " ") + `│ │${(i === 0 ? "> " : "  ") + t}`.padEnd(19, " ") + "│ " + mline);
  }
  lines.push("╰───────────────────╯ ╰──────────────────╯");
  lines.push("╭──────────────────────────────────────────────────────────────────────────────╮");
  lines.push(`│                         \x1b[4mlog preview for ${pad2(today.day)}. ${pad2(today.mon)}. ${String(today.y).slice(2)}. \x1b[24m                         │`);
  lines.push("╰──────────────────────────────────────────────────────────────────────────────╯");
  return "\x1b[?1049h\x1b[?25l" + lines.join("\n") + "\n";
}

function main() {
  let opts;
  try {
    opts = parseArgs(process.argv.slice(2));
  } catch (e) {
    fail(e.message);
    return;
  }
  if (opts.help) {
    process.stdout.write(help());
    return;
  }
  try {
    const cfg = readConfig(opts.config);
    resolveOptions(opts, cfg);
    if (opts.encrypt || opts.decrypt) {
      applyCrypto(opts);
      return;
    }
    process.stdout.write(renderTui(opts));
    if (process.stdin.isTTY) {
      process.stdin.setRawMode(true);
      process.stdin.resume();
      process.stdin.on("data", (buf) => {
        if (buf.includes(3) || buf.toString() === "q") {
          process.stdout.write("\x1b[?25h\x1b[?1049l");
          process.exit(0);
        }
      });
    } else {
      setInterval(() => {}, 1000);
    }
  } catch (e) {
    fail(e.message);
  }
}

main();
