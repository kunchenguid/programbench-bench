#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = 'v0.0.0-SNAPSHOT';

const CHECKERS = [
  ['appendAssign', 'diagnostic'],
  ['appendCombine', 'performance'],
  ['argOrder', 'diagnostic'],
  ['assignOp', 'style'],
  ['badCall', 'diagnostic'],
  ['badCond', 'diagnostic'],
  ['badLock', 'diagnostic experimental'],
  ['badRegexp', 'diagnostic experimental'],
  ['badSorting', 'diagnostic experimental'],
  ['badSyncOnceFunc', 'diagnostic experimental'],
  ['boolExprSimplify', 'style experimental'],
  ['builtinShadow', 'style opinionated'],
  ['builtinShadowDecl', 'diagnostic experimental'],
  ['captLocal', 'style'],
  ['caseOrder', 'diagnostic'],
  ['codegenComment', 'diagnostic'],
  ['commentFormatting', 'style'],
  ['commentedOutCode', 'diagnostic experimental'],
  ['commentedOutImport', 'style experimental'],
  ['defaultCaseOrder', 'style'],
  ['deferInLoop', 'diagnostic experimental'],
  ['deferUnlambda', 'style experimental'],
  ['deprecatedComment', 'diagnostic'],
  ['docStub', 'style experimental'],
  ['dupArg', 'diagnostic'],
  ['dupBranchBody', 'diagnostic'],
  ['dupCase', 'diagnostic'],
  ['dupImport', 'style experimental'],
  ['dupOption', 'diagnostic experimental'],
  ['dupSubExpr', 'diagnostic'],
  ['dynamicFmtString', 'diagnostic experimental'],
  ['elseif', 'style'],
  ['emptyDecl', 'diagnostic experimental'],
  ['emptyFallthrough', 'style experimental'],
  ['emptyStringTest', 'style experimental'],
  ['equalFold', 'performance experimental'],
  ['evalOrder', 'diagnostic experimental'],
  ['exitAfterDefer', 'diagnostic'],
  ['exposedSyncMutex', 'style experimental'],
  ['externalErrorReassign', 'diagnostic experimental'],
  ['filepathJoin', 'diagnostic experimental'],
  ['flagDeref', 'diagnostic'],
  ['flagName', 'diagnostic'],
  ['hexLiteral', 'style experimental'],
  ['httpNoBody', 'style experimental'],
  ['hugeParam', 'performance'],
  ['ifElseChain', 'style'],
  ['importShadow', 'style opinionated'],
  ['indexAlloc', 'performance'],
  ['initClause', 'style opinionated experimental'],
  ['mapKey', 'diagnostic'],
  ['methodExprCall', 'style experimental'],
  ['nestingReduce', 'style opinionated experimental'],
  ['newDeref', 'style'],
  ['nilValReturn', 'diagnostic experimental'],
  ['octalLiteral', 'style experimental opinionated'],
  ['offBy1', 'diagnostic'],
  ['paramTypeCombine', 'style opinionated'],
  ['preferDecodeRune', 'performance experimental'],
  ['preferFilepathJoin', 'style experimental'],
  ['preferFprint', 'performance experimental'],
  ['preferStringWriter', 'performance experimental'],
  ['preferWriteByte', 'performance experimental opinionated'],
  ['ptrToRefParam', 'style opinionated experimental'],
  ['rangeAppendAll', 'diagnostic experimental'],
  ['rangeExprCopy', 'performance'],
  ['rangeValCopy', 'performance'],
  ['redundantSprint', 'style experimental'],
  ['regexpMust', 'style'],
  ['regexpPattern', 'diagnostic experimental'],
  ['regexpSimplify', 'style experimental opinionated'],
  ['returnAfterHttpError', 'diagnostic experimental'],
  ['ruleguard', 'style experimental'],
  ['singleCaseSwitch', 'style'],
  ['sliceClear', 'performance experimental'],
  ['sloppyLen', 'diagnostic'],
  ['sloppyReassign', 'diagnostic experimental'],
  ['sloppyTypeAssert', 'diagnostic'],
  ['sortSlice', 'diagnostic experimental'],
  ['sprintfQuotedString', 'diagnostic experimental'],
  ['sqlQuery', 'diagnostic experimental'],
  ['stringConcatSimplify', 'style experimental'],
  ['stringXbytes', 'performance'],
  ['stringsCompare', 'style experimental'],
  ['switchTrue', 'style'],
  ['syncMapLoadAndDelete', 'diagnostic experimental'],
  ['timeExprSimplify', 'style experimental'],
  ['todoCommentWithoutDetail', 'style opinionated experimental'],
  ['tooManyResultsChecker', 'style opinionated experimental'],
  ['truncateCmp', 'diagnostic experimental'],
  ['typeAssertChain', 'style experimental'],
  ['typeDefFirst', 'style experimental'],
  ['typeSwitchVar', 'style'],
  ['typeUnparen', 'style opinionated'],
  ['uncheckedInlineErr', 'diagnostic experimental'],
  ['underef', 'style'],
  ['unlabelStmt', 'style experimental'],
  ['unlambda', 'style'],
  ['unnamedResult', 'style opinionated experimental'],
  ['unnecessaryBlock', 'style opinionated experimental'],
  ['unnecessaryDefer', 'diagnostic experimental'],
  ['unslice', 'style'],
  ['valSwap', 'style'],
  ['weakCond', 'diagnostic experimental'],
  ['whyNoLint', 'style experimental'],
  ['wrapperFunc', 'style'],
  ['yodaStyleExpr', 'style experimental'],
  ['zeroByteRepeat', 'performance'],
];

const DEFAULT_ENABLE = 'appendAssign,argOrder,assignOp,badCall,badCond,captLocal,caseOrder,codegenComment,commentFormatting,defaultCaseOrder,deprecatedComment,dupArg,dupBranchBody,dupCase,dupSubExpr,elseif,exitAfterDefer,flagDeref,flagName,ifElseChain,mapKey,newDeref,offBy1,regexpMust,singleCaseSwitch,sloppyLen,sloppyTypeAssert,switchTrue,typeSwitchVar,underef,unlambda,unslice,valSwap,wrapperFunc';

const CHECK_HELP = `Usage of go-critic:
  -@captLocal.paramsOnly
    \twhether to restrict checker to params only (default true)
  -@commentedOutCode.minLength int
    \tmin length of the comment that triggers a warning (default 15)
  -@elseif.skipBalanced
    \twhether to skip balanced if-else pairs (default true)
  -@hugeParam.sizeThreshold int
    \tsize in bytes that makes the warning trigger (default 80)
  -@ifElseChain.minThreshold int
    \tmin number of if-else blocks that makes the warning trigger (default 2)
  -@nestingReduce.bodyWidth int
    \tmin number of statements inside a branch to trigger a warning (default 5)
  -@rangeExprCopy.sizeThreshold int
    \tsize in bytes that makes the warning trigger (default 512)
  -@rangeExprCopy.skipTestFuncs
    \twhether to check test functions (default true)
  -@rangeValCopy.sizeThreshold int
    \tsize in bytes that makes the warning trigger (default 128)
  -@rangeValCopy.skipTestFuncs
    \twhether to check test functions (default true)
  -@ruleguard.debug string
    \tenable debug for the specified named rules group
  -@ruleguard.disable string
    \tcomma-separated list of disabled groups or skip empty to enable everything
  -@ruleguard.enable string
    \tcomma-separated list of enabled groups or skip empty to enable everything (default "<all>")
  -@ruleguard.failOn string
    \tDetermines the behavior when an error occurs while parsing ruleguard files.
    \tIf flag is not set, log error and skip rule files that contain an error.
    \tIf flag is set, the value must be a comma-separated list of error conditions.
    \t* 'import': rule refers to a package that cannot be loaded.
    \t* 'dsl':    gorule file does not comply with the ruleguard DSL.
  -@ruleguard.failOnError
    \tdeprecated, use failOn param; if set to true, identical to failOn='all', otherwise failOn=''
  -@ruleguard.rules string
    \tcomma-separated list of gorule file paths. Glob patterns such as 'rules-*.go' may be specified
  -@tooManyResultsChecker.maxResults int
    \tmaximum number of results (default 5)
  -@truncateCmp.skipArchDependent
    \twhether to skip int/uint/uintptr types (default true)
  -@underef.skipRecvDeref
    \twhether to skip (*x).method() calls where x is a pointer receiver (default true)
  -@unnamedResult.checkExported
    \twhether to check exported functions
  -checkGenerated
    \twhether to check generated files
  -checkTests
    \twhether to check test files (default true)
  -concurrency int
    \thow many concurrent checkers to run (default is runtime.GOMAXPROCS(0)) (default 14)
  -cpuprofile string
    \twrite CPU profile to the specified file
  -disable string
    \tcomma-separated list of checkers to be disabled. Can include #tags
  -enable string
    \tcomma-separated list of enabled checkers. Can include #tags (default "${DEFAULT_ENABLE}")
  -enableAll
    \tidentical to -enable with all checkers listed. If true, -enable is ignored
  -exitCode int
    \texit code to be used when lint issues are found (default 1)
  -go string
    \tselect the Go version to target. Leave as string for the latest
  -memprofile string
    \twrite memory profile to the specified file
  -shorterErrLocation
    \twhether to replace error location prefix with $GOROOT and $GOPATH (default true)
  -v\twhether to print output useful during linter debugging`;

const DOCS = {
  appendAssign: `Detects suspicious append result assignments.

Non-compliant code:
p.positives = append(p.negatives, x)
p.negatives = append(p.negatives, y)

Compliant code:
p.positives = append(p.positives, x)
p.negatives = append(p.negatives, y)`,
  elseif: `Detects else with nested if statement that can be replaced with else-if.

Non-compliant code:
if cond1 {
} else {
\tif x := cond2; x {
\t}
}

Compliant code:
if cond1 {
} else if x := cond2; x {
}

Checker parameters:
  -@elseif.skipBalanced bool
    \twhether to skip balanced if-else pairs (default true)`,
  hugeParam: `Detects params that incur excessive amount of copying.

Non-compliant code:
func f(x [1024]int) {}

Compliant code:
func f(x *[1024]int) {}

Checker parameters:
  -@hugeParam.sizeThreshold int
    \tsize in bytes that makes the warning trigger (default 80)`,
  unslice: `Detects slice expressions that can be simplified to sliced expression itself.

Non-compliant code:
copy(b[:], values...)

Compliant code:
copy(b, values...)`,
};

function print(s = '') {
  process.stdout.write(String(s) + '\n');
}

function eprint(s = '') {
  process.stderr.write(String(s) + '\n');
}

function topHelp() {
  print(`Usage:

    go-critic <command> [arguments...]

The commands are:

    check             run linter over specified targets
    doc               get installed checkers documentation
    help              shows help message
    version           shows version of the application

Version: ${VERSION}
`);
}

function docCommand(args) {
  if (args[0] === '-help' || args[0] === '--help') {
    print('Usage of go-critic:');
    print('flag: help requested');
    return 0;
  }
  if (args.length > 1) {
    print('expected 0 or 1 positional arguments');
    return 1;
  }
  if (args.length === 0) {
    for (const [name, tags] of CHECKERS) print(`${name} [${tags}]`);
    return 0;
  }
  const name = args[0];
  const entry = CHECKERS.find(([n]) => n === name);
  if (!entry) {
    print(`checker with name "${name}" not found`);
    return 1;
  }
  const tags = entry[1].split(' ').join(' ');
  print(`${name} checker documentation`);
  print('URL: https://github.com/go-critic/go-critic/checkers');
  print(`Tags: [${tags}]`);
  print();
  print(DOCS[name] || `Documentation for ${name} checker is not available in this build.`);
  return 0;
}

function isBoolFlag(name) {
  return new Set([
    'checkGenerated', 'checkTests', 'enableAll', 'shorterErrLocation', 'v',
    '@captLocal.paramsOnly', '@elseif.skipBalanced', '@rangeExprCopy.skipTestFuncs',
    '@rangeValCopy.skipTestFuncs', '@ruleguard.failOnError',
    '@truncateCmp.skipArchDependent', '@underef.skipRecvDeref',
    '@unnamedResult.checkExported',
  ]).has(name);
}

function isValueFlag(name) {
  return new Set([
    'concurrency', 'cpuprofile', 'disable', 'enable', 'exitCode', 'go',
    'memprofile', '@commentedOutCode.minLength', '@hugeParam.sizeThreshold',
    '@ifElseChain.minThreshold', '@nestingReduce.bodyWidth',
    '@rangeExprCopy.sizeThreshold', '@rangeValCopy.sizeThreshold',
    '@ruleguard.debug', '@ruleguard.disable', '@ruleguard.enable',
    '@ruleguard.failOn', '@ruleguard.rules', '@tooManyResultsChecker.maxResults',
  ]).has(name);
}

function parseCheckArgs(args) {
  const positional = [];
  let exitCode = 1;
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '-help' || arg === '--help' || arg === '-h') {
      print(CHECK_HELP);
      print('parse args: flag: help requested');
      return { done: true, code: 1 };
    }
    if (!arg.startsWith('-') || arg === '-') {
      positional.push(arg);
      continue;
    }
    const body = arg.slice(1);
    const eq = body.indexOf('=');
    const name = eq >= 0 ? body.slice(0, eq) : body;
    if (isBoolFlag(name)) continue;
    if (isValueFlag(name)) {
      let value = eq >= 0 ? body.slice(eq + 1) : null;
      if (value === null) {
        i++;
        value = args[i];
      }
      if (name === 'exitCode') {
        const parsed = Number.parseInt(value, 10);
        if (Number.isFinite(parsed)) exitCode = parsed;
      }
      continue;
    }
    eprint(`flag provided but not defined: -${name}`);
    print(CHECK_HELP);
    print(`parse args: flag provided but not defined: -${name}`);
    return { done: true, code: 1 };
  }
  return { positional, exitCode };
}

function commandExists(cmd) {
  const dirs = (process.env.PATH || '').split(path.delimiter);
  for (const dir of dirs) {
    try {
      fs.accessSync(path.join(dir, cmd), fs.constants.X_OK);
      return true;
    } catch (_) {}
  }
  return false;
}

function checkCommand(args) {
  const parsed = parseCheckArgs(args);
  if (parsed.done) return parsed.code;
  if (!commandExists('go')) {
    print('load packages: err: go command required, not found: exec: "go": executable file not found in $PATH: stderr: ');
    return 1;
  }
  return runSimpleLint(parsed.positional, parsed.exitCode);
}

function collectGoFiles(targets) {
  if (targets.length === 0) targets = ['.'];
  const out = [];
  function walk(p) {
    if (!fs.existsSync(p)) return;
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      for (const ent of fs.readdirSync(p)) {
        if (ent === '.git' || ent === 'node_modules') continue;
        walk(path.join(p, ent));
      }
    } else if (p.endsWith('.go')) out.push(p);
  }
  for (const t of targets) {
    if (t === './...') walk('.');
    else if (t.endsWith('/...')) walk(t.slice(0, -4) || '.');
    else walk(t);
  }
  return out.sort();
}

function runSimpleLint(targets, lintExitCode) {
  const files = collectGoFiles(targets);
  let issues = 0;
  for (const file of files) {
    const lines = fs.readFileSync(file, 'utf8').split(/\n/);
    lines.forEach((line, idx) => {
      const n = idx + 1;
      const m = line.match(/\b(\w+)\s*=\s*append\((\w+)\s*,/);
      if (m && m[1] !== m[2]) {
        print(`${file}:${n}:1: appendAssign: append result not assigned to the same slice`);
        issues++;
      }
      if (/\bcopy\([^,\]]+\[:\]\s*,/.test(line)) {
        print(`${file}:${n}:1: unslice: could simplify ${line.trim().match(/copy\(([^,]+)/)?.[1] || 'slice'}[:] to ${line.trim().match(/copy\(([^,\[]+)/)?.[1] || 'slice'}`);
        issues++;
      }
    });
  }
  return issues ? lintExitCode : 0;
}

function unknownCommand(cmd) {
  const suggestion = cmd.includes('help') || cmd.startsWith('-') ? 'help' : 'doc';
  print(`"${cmd}" unknown command, did you mean "${suggestion}"?`);
  print('Run "go-critic help" for usage.');
  print();
  print(`no such command "${cmd}"`);
  return 0;
}

function main(argv) {
  if (argv.length === 0) {
    print('no args provided');
    return 0;
  }
  const [cmd, ...args] = argv;
  switch (cmd) {
    case 'help':
      topHelp();
      return 0;
    case 'version':
      print(`go-critic version: ${VERSION}`);
      print();
      return 0;
    case 'doc':
      return docCommand(args);
    case 'check':
      return checkCommand(args);
    default:
      return unknownCommand(cmd);
  }
}

process.exitCode = main(process.argv.slice(2));
