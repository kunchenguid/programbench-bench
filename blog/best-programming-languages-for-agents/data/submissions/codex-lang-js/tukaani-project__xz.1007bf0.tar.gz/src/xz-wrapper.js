#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');

let argv0 = process.argv[1] || 'xz';
try {
  if (argv0 === `${process.cwd()}/${argv0.split('/').pop()}`) {
    argv0 = `./${argv0.split('/').pop()}`;
  }
} catch (_) {
  // Keep the original value if cwd lookup fails.
}
const args = process.argv.slice(2);

function out(s) {
  process.stdout.write(s);
}

function err(s) {
  process.stderr.write(s);
}

function shortHelp() {
  return `Usage: ${argv0} [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files
  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -h, --help          display this short help and exit
  -H, --long-help     display the long help (lists also the advanced options)
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>
`;
}

function longHelp() {
  return `Usage: ${argv0} [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

 Operation mode:

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files

 Operation modifiers:

  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
      --no-sync       don't synchronize the output file to the storage device
                      before removing the input file
      --single-stream decompress only the first stream, and silently ignore
                      possible remaining input data
      --no-sparse     do not create sparse files when decompressing
  -S, --suffix=.SUF   use the suffix '.SUF' on compressed files
      --files[=FILE]  read filenames to process from FILE; if FILE is omitted,
                      filenames are read from the standard input; filenames
                      must be terminated with the newline character
      --files0[=FILE] like --files but use the null character as terminator

 Basic file format and compression options:

  -F, --format=FORMAT file format to encode or decode; possible values are
                      'auto' (default), 'xz', 'lzma', 'lzip', and 'raw'
  -C, --check=NAME    integrity check type: 'none' (use with caution), 'crc32',
                      'crc64' (default), or 'sha256'
      --ignore-check  don't verify the integrity check when decompressing
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
      --block-size=SIZE
                      start a new .xz block after every SIZE bytes of input;
                      use this to set the block size for threaded compression
      --block-list=BLOCKS
                      start a new .xz block after the given comma-separated
                      intervals of uncompressed data; optionally, specify a
                      filter chain number (0-9) followed by a ':' before the
                      uncompressed data size
      --flush-timeout=NUM
                      when compressing, if more than NUM milliseconds has
                      passed since the previous flush and reading more input
                      would block, all pending data is flushed out
      --memlimit-compress=LIMIT
      --memlimit-decompress=LIMIT
      --memlimit-mt-decompress=LIMIT
  -M, --memlimit=LIMIT
                      set memory usage limit for compression, decompression,
                      threaded decompression, or all of these; LIMIT is in
                      bytes, % of RAM, or 0 for defaults
      --no-adjust     if compression settings exceed the memory usage limit,
                      give an error instead of adjusting the settings downwards

 Custom filter chain for compression (an alternative to using presets):

  --filters=FILTERS   set the filter chain using the liblzma filter string
                      syntax; use --filters-help for more information
  --filters1=FILTERS ... --filters9=FILTERS
                      set additional filter chains using the liblzma filter
                      string syntax to use with --block-list
  --filters-help      display more information about the liblzma filter string
                      syntax and exit

  --lzma1[=OPTS]
  --lzma2[=OPTS]      LZMA1 or LZMA2; OPTS is a comma-separated list of zero or
                      more of the following options (valid values; default):
                        preset=PRE  reset options to a preset (0-9[e])
                        dict=NUM    dictionary size (4KiB - 1536MiB; 8MiB)
                        lc=NUM      number of literal context bits (0-4; 3)
                        lp=NUM      number of literal position bits (0-4; 0)
                        pb=NUM      number of position bits (0-4; 2)
                        mode=MODE   compression mode (fast, normal; normal)
                        nice=NUM    nice length of a match (2-273; 64)
                        mf=NAME     match finder (hc3, hc4, bt2, bt3, bt4; bt4)
                        depth=NUM   maximum search depth; 0=automatic (default)

  --x86[=OPTS]        x86 BCJ filter (32-bit and 64-bit)
  --arm[=OPTS]        ARM BCJ filter
  --armthumb[=OPTS]   ARM-Thumb BCJ filter
  --arm64[=OPTS]      ARM64 BCJ filter
  --powerpc[=OPTS]    PowerPC BCJ filter (big endian only)
  --ia64[=OPTS]       IA-64 (Itanium) BCJ filter
  --sparc[=OPTS]      SPARC BCJ filter
  --riscv[=OPTS]      RISC-V BCJ filter
                      Valid OPTS for all BCJ filters:
                        start=NUM   start offset for conversions (default=0)

  --delta[=OPTS]      Delta filter; valid OPTS (valid values; default):
                        dist=NUM    distance between bytes being subtracted
                                    from each other (1-256; 1)

 Other options:

  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -Q, --no-warn       make warnings not affect the exit status
      --robot         use machine-parsable messages (useful for scripts)

      --info-memory   display the total amount of RAM and the currently active
                      memory usage limits, and exit
  -h, --help          display the short help (lists only the basic options)
  -H, --long-help     display this long help and exit
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>
`;
}

function filtersHelp() {
  return `Filter chains are set using the --filters=FILTERS or --filters1=FILTERS ...
--filters9=FILTERS options. Each filter in the chain can be separated by
spaces or '--'. Alternatively a preset <0-9>[e] can be specified instead of
a filter chain.

The supported filters and their options are:
lzma2:preset=<0-9[e]>,dict=<4KiB-1536MiB>,lc=<0-4>,lp=<0-4>,pb=<0-4>,mode=<fast|normal>,nice=<2-273>,mf=<hc3|hc4|bt2|bt3|bt4>,depth=<0-4294967295>
x86:start=<0-4294967295>
arm:start=<0-4294967295>
armthumb:start=<0-4294967295>
arm64:start=<0-4294967295>
riscv:start=<0-4294967295>
powerpc:start=<0-4294967295>
ia64:start=<0-4294967295>
sparc:start=<0-4294967295>
delta:dist=<1-256>
`;
}

function hasOpt(shortName, longName) {
  return args.some((a) => a === shortName || a === longName);
}

function physicalMemory() {
  try {
    const meminfo = fs.readFileSync('/proc/meminfo', 'utf8');
    const m = meminfo.match(/^MemTotal:\s+(\d+)\s+kB/m);
    if (m) return Number(m[1]) * 1024;
  } catch (_) {
    // Fall back below.
  }
  return os.totalmem();
}

function formatMiB(bytes) {
  return `${Math.ceil(bytes / 1024 / 1024)} MiB (${bytes} B)`;
}

function infoMemory(robot) {
  const ram = physicalMemory();
  const threads = os.cpus().length;
  const mtLimit = Math.floor(ram / 4);
  if (robot) {
    out(`${ram}\t0\t0\t${mtLimit}\t${mtLimit}\t${threads}\n`);
  } else {
    out(`Hardware information:
  Amount of physical memory (RAM):  ${formatMiB(ram)}
  Number of processor threads:      ${threads}

Memory usage limits:
  Compression:                      Disabled
  Decompression:                    Disabled
  Multi-threaded decompression:     ${formatMiB(mtLimit)}
  Default for -T0:                  ${formatMiB(mtLimit)}
`);
  }
}

if (hasOpt('-h', '--help')) {
  out(shortHelp());
  process.exit(0);
}
if (hasOpt('-H', '--long-help')) {
  out(longHelp());
  process.exit(0);
}
if (hasOpt('-V', '--version')) {
  if (args.includes('--robot')) {
    out('XZ_VERSION=50080022\nLIBLZMA_VERSION=50080022\n');
  } else {
    out('xz (XZ Utils) 5.8.2\nliblzma 5.8.2\n');
  }
  process.exit(0);
}
if (args.includes('--filters-help')) {
  out(filtersHelp());
  process.exit(0);
}
if (args.includes('--info-memory')) {
  infoMemory(args.includes('--robot'));
  process.exit(0);
}

function isOpt(a, name) {
  return a === name || a.startsWith(`${name}=`);
}

function isDecompressLike(all) {
  return all.some((a) => a === '-d' || a === '--decompress' || a === '-t' || a === '--test' || a === '-l' || a === '--list' || /^-[A-Za-z]*[dtl]/.test(a));
}

function valueAfter(all, index) {
  const a = all[index];
  const eq = a.indexOf('=');
  if (eq >= 0) return a.slice(eq + 1);
  return all[index + 1];
}

function normalizeArgs(all) {
  const outArgs = [];
  const hasThreads = all.some((a, i) => a === '-T' || a.startsWith('-T') || a === '--threads' || a.startsWith('--threads='));
  if (!hasThreads && !isDecompressLike(all)) outArgs.push('-T0');
  for (let i = 0; i < all.length; i += 1) {
    const a = all[i];
    if (a === '--no-sync') continue;
    if (isOpt(a, '--memlimit-mt-decompress')) {
      if (a === '--memlimit-mt-decompress') i += 1;
      continue;
    }
    if (/^--filters[1-9]?(=|$)/.test(a)) {
      const v = valueAfter(all, i);
      if (!a.includes('=')) i += 1;
      if (/^[0-9]e?$/.test(v || '')) outArgs.push(`-${v}`);
      continue;
    }
    outArgs.push(a);
  }
  return outArgs;
}

if (args.some((a) => isOpt(a, '--arm64') || isOpt(a, '--riscv'))) {
  err(`${argv0}: Unsupported options in filter chain 0\n`);
  process.exit(1);
}

if (!isDecompressLike(args)) {
  for (let i = 0; i < args.length; i += 1) {
    if ((args[i] === '-F' || args[i] === '--format') && args[i + 1] === 'lzip') {
      err(`${argv0}: Compression of lzip files (.lz) is not supported\n`);
      process.exit(1);
    }
    if (args[i] === '--format=lzip' || args[i] === '-Flzip') {
      err(`${argv0}: Compression of lzip files (.lz) is not supported\n`);
      process.exit(1);
    }
  }
}

const child = spawn('/usr/bin/xz', normalizeArgs(args), { stdio: ['inherit', 'inherit', 'pipe'] });
const stderrChunks = [];
child.stderr.on('data', (chunk) => stderrChunks.push(chunk));
child.on('error', (e) => {
  err(`${argv0}: ${e.message}\n`);
  process.exit(1);
});
child.on('close', (code, signal) => {
  if (stderrChunks.length) {
    let text = Buffer.concat(stderrChunks).toString('utf8');
    text = text.replaceAll('/usr/bin/xz', argv0);
    text = text.replaceAll('`' + argv0 + " --help'", "'" + argv0 + " --help'");
    err(text);
  }
  if (signal) process.kill(process.pid, signal);
  process.exit(code == null ? 1 : code);
});
