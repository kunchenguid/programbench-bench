#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const xzstore = require("./xzstore");

const prog = path.basename(process.env.XZ_PROG || process.argv[1] || "xz");

const SHORT_HELP = `Usage: ${prog} [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files
  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -h, --help          display this short help and exit
  -H, --long-help     display the long help (lists also the advanced options)
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>
`;

const LONG_HELP = `Usage: ${prog} [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

 Operation mode:

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files

 Operation modifiers:

  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
      --no-sync       don't synchronize the output file to the storage device
                      before removing the input file
      --single-stream decompress only the first stream, and silently ignore
                      possible remaining input data
      --no-sparse     do not create sparse files when decompressing
  -S, --suffix=.SUF   use the suffix '.SUF' on compressed files
      --files[=FILE]  read filenames to process from FILE; if FILE is omitted,
                      filenames are read from the standard input; filenames
                      must be terminated with the newline character
      --files0[=FILE] like --files but use the null character as terminator

 Basic file format and compression options:

  -F, --format=FORMAT file format to encode or decode; possible values are
                      'auto' (default), 'xz', 'lzma', 'lzip', and 'raw'
  -C, --check=NAME    integrity check type: 'none' (use with caution), 'crc32',
                      'crc64' (default), or 'sha256'
      --ignore-check  don't verify the integrity check when decompressing
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
      --block-size=SIZE
                      start a new .xz block after every SIZE bytes of input;
                      use this to set the block size for threaded compression
      --block-list=BLOCKS
                      start a new .xz block after the given comma-separated
                      intervals of uncompressed data; optionally, specify a
                      filter chain number (0-9) followed by a ':' before the
                      uncompressed data size
      --flush-timeout=NUM
                      when compressing, if more than NUM milliseconds has
                      passed since the previous flush and reading more input
                      would block, all pending data is flushed out
      --memlimit-compress=LIMIT
      --memlimit-decompress=LIMIT
      --memlimit-mt-decompress=LIMIT
  -M, --memlimit=LIMIT
                      set memory usage limit for compression, decompression,
                      threaded decompression, or all of these; LIMIT is in
                      bytes, % of RAM, or 0 for defaults
      --no-adjust     if compression settings exceed the memory usage limit,
                      give an error instead of adjusting the settings downwards

 Custom filter chain for compression (an alternative to using presets):

  --filters=FILTERS   set the filter chain using the liblzma filter string
                      syntax; use --filters-help for more information
  --filters1=FILTERS ... --filters9=FILTERS
                      set additional filter chains using the liblzma filter
                      string syntax to use with --block-list
  --filters-help      display more information about the liblzma filter string
                      syntax and exit

  --lzma1[=OPTS]
  --lzma2[=OPTS]      LZMA1 or LZMA2; OPTS is a comma-separated list of zero or
                      more of the following options (valid values; default):
                        preset=PRE  reset options to a preset (0-9[e])
                        dict=NUM    dictionary size (4KiB - 1536MiB; 8MiB)
                        lc=NUM      number of literal context bits (0-4; 3)
                        lp=NUM      number of literal position bits (0-4; 0)
                        pb=NUM      number of position bits (0-4; 2)
                        mode=MODE   compression mode (fast, normal; normal)
                        nice=NUM    nice length of a match (2-273; 64)
                        mf=NAME     match finder (hc3, hc4, bt2, bt3, bt4; bt4)
                        depth=NUM   maximum search depth; 0=automatic (default)

  --x86[=OPTS]        x86 BCJ filter (32-bit and 64-bit)
  --arm[=OPTS]        ARM BCJ filter
  --armthumb[=OPTS]   ARM-Thumb BCJ filter
  --arm64[=OPTS]      ARM64 BCJ filter
  --powerpc[=OPTS]    PowerPC BCJ filter (big endian only)
  --ia64[=OPTS]       IA-64 (Itanium) BCJ filter
  --sparc[=OPTS]      SPARC BCJ filter
  --riscv[=OPTS]      RISC-V BCJ filter
                      Valid OPTS for all BCJ filters:
                        start=NUM   start offset for conversions (default=0)

  --delta[=OPTS]      Delta filter; valid OPTS (valid values; default):
                        dist=NUM    distance between bytes being subtracted
                                    from each other (1-256; 1)

 Other options:

  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -Q, --no-warn       make warnings not affect the exit status
      --robot         use machine-parsable messages (useful for scripts)

      --info-memory   display the total amount of RAM and the currently active
                      memory usage limits, and exit
  -h, --help          display the short help (lists only the basic options)
  -H, --long-help     display this long help and exit
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>
`;

function warn(msg, opts) {
  if (opts.quiet < 2) process.stderr.write(`${prog}: ${msg}\n`);
}

function fatal(msg, code = 1) {
  process.stderr.write(`${prog}: ${msg}\n`);
  process.exit(code);
}

function parseArgs(argv) {
  const opts = {
    mode: null,
    keep: false,
    force: false,
    stdout: false,
    quiet: 0,
    verbose: 0,
    preset: 6,
    extreme: false,
    suffix: ".xz",
    check: 4,
    singleStream: false,
    files: [],
    fileLists: [],
    nullFileLists: [],
    format: "auto",
    robot: false,
  };
  const files = [];
  function needArg(i, name, attached) {
    if (attached !== undefined && attached !== "") return [attached, i];
    if (i + 1 >= argv.length) fatal(`option '${name}' requires an argument`);
    return [argv[i + 1], i + 1];
  }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--") {
      files.push(...argv.slice(i + 1));
      break;
    }
    if (a === "-" || !a.startsWith("-")) {
      files.push(a);
      continue;
    }
    if (a.startsWith("--")) {
      const eq = a.indexOf("=");
      const name = eq >= 0 ? a.slice(0, eq) : a;
      const val = eq >= 0 ? a.slice(eq + 1) : undefined;
      if (name === "--help") { process.stdout.write(SHORT_HELP); process.exit(0); }
      if (name === "--long-help") { process.stdout.write(LONG_HELP); process.exit(0); }
      if (name === "--version") { process.stdout.write("xz (XZ Utils) 5.8.2\nliblzma 5.8.2\n"); process.exit(0); }
      if (name === "--compress") opts.mode = "compress";
      else if (name === "--decompress" || name === "--uncompress") opts.mode = "decompress";
      else if (name === "--test") opts.mode = "test";
      else if (name === "--list") opts.mode = "list";
      else if (name === "--keep") opts.keep = true;
      else if (name === "--force") opts.force = true;
      else if (name === "--stdout" || name === "--to-stdout") opts.stdout = true;
      else if (name === "--quiet") opts.quiet++;
      else if (name === "--verbose") opts.verbose++;
      else if (name === "--extreme") opts.extreme = true;
      else if (name === "--single-stream") opts.singleStream = true;
      else if (name === "--robot") opts.robot = true;
      else if (name === "--no-sync" || name === "--no-sparse" || name === "--ignore-check" || name === "--no-adjust" || name === "--no-warn") {}
      else if (name === "--threads" || name === "--block-size" || name === "--block-list" || name === "--flush-timeout" || name === "--memlimit" || name === "--memlimit-compress" || name === "--memlimit-decompress" || name === "--memlimit-mt-decompress") {
        const got = needArg(i, name, val); i = got[1];
      } else if (name === "--suffix") {
        const got = needArg(i, name, val); opts.suffix = got[0]; i = got[1];
      } else if (name === "--format") {
        const got = needArg(i, name, val); opts.format = got[0]; i = got[1];
      } else if (name === "--check") {
        const got = needArg(i, name, val); i = got[1];
        opts.check = ({none:0, crc32:1, crc64:4, sha256:10})[got[0]];
        if (opts.check === undefined) fatal(`${got[0]}: Unsupported integrity check type`);
      } else if (name === "--files" || name === "--files0") {
        const target = val === undefined ? "-" : val;
        (name === "--files0" ? opts.nullFileLists : opts.fileLists).push(target);
      } else if (name === "--filters-help") {
        process.stdout.write("Filter chains are set with NAME[:OPTS][,NAME[:OPTS]...].\n");
        process.exit(0);
      } else if (/^--(filters[1-9]?|lzma[12]|x86|arm|armthumb|arm64|powerpc|ia64|sparc|riscv|delta)$/.test(name)) {
        if (val === undefined && (i + 1) < argv.length && !argv[i + 1].startsWith("-")) i++;
      } else {
        fatal(`unrecognized option '${a}'`);
      }
      continue;
    }
    for (let j = 1; j < a.length; j++) {
      const ch = a[j];
      if (ch >= "0" && ch <= "9") opts.preset = Number(ch);
      else if (ch === "z") opts.mode = "compress";
      else if (ch === "d") opts.mode = "decompress";
      else if (ch === "t") opts.mode = "test";
      else if (ch === "l") opts.mode = "list";
      else if (ch === "k") opts.keep = true;
      else if (ch === "f") opts.force = true;
      else if (ch === "c") opts.stdout = true;
      else if (ch === "q") opts.quiet++;
      else if (ch === "v") opts.verbose++;
      else if (ch === "e") opts.extreme = true;
      else if (ch === "h") { process.stdout.write(SHORT_HELP); process.exit(0); }
      else if (ch === "H") { process.stdout.write(LONG_HELP); process.exit(0); }
      else if (ch === "V") { process.stdout.write("xz (XZ Utils) 5.8.2\nliblzma 5.8.2\n"); process.exit(0); }
      else if (ch === "T" || ch === "S" || ch === "F" || ch === "C" || ch === "M") {
        let val = a.slice(j + 1);
        if (!val) {
          if (i + 1 >= argv.length) fatal(`option requires an argument -- '${ch}'`);
          val = argv[++i];
        }
        if (ch === "S") opts.suffix = val;
        if (ch === "F") opts.format = val;
        if (ch === "C") {
          opts.check = ({none:0, crc32:1, crc64:4, sha256:10})[val];
          if (opts.check === undefined) fatal(`${val}: Unsupported integrity check type`);
        }
        break;
      } else {
        fatal(`invalid option -- '${ch}'`);
      }
    }
  }
  opts.files = files;
  if (!opts.mode) opts.mode = prog.includes("unxz") || prog.includes("xzcat") ? "decompress" : "compress";
  if (prog.includes("cat")) opts.stdout = true;
  if (opts.mode === "test" || opts.mode === "list") opts.keep = true;
  if (opts.stdout) opts.keep = true;
  return opts;
}

function readAllStdin() {
  return fs.readFileSync(0);
}

function readFileList(name, nul) {
  const data = name === "-" ? fs.readFileSync(0) : fs.readFileSync(name);
  const sep = nul ? "\0" : "\n";
  return data.toString("utf8").split(sep).filter(s => s.length > 0);
}

function outNameFor(input, opts) {
  if (opts.mode === "compress") return input + opts.suffix;
  if (input.endsWith(opts.suffix)) return input.slice(0, -opts.suffix.length);
  if (input.endsWith(".txz")) return input.slice(0, -4) + ".tar";
  if (input.endsWith(".xz")) return input.slice(0, -3);
  return null;
}

function writeOutput(name, data, opts) {
  if (!opts.force && fs.existsSync(name)) fatal(`${name}: File exists`);
  fs.writeFileSync(name, data);
}

function processBuffer(input, opts) {
  if (opts.mode === "compress") {
    const preset = opts.preset | (opts.extreme ? (1 << 31) >>> 0 : 0);
    return xzstore.compress(input, opts.check);
  }
  return xzstore.decompressStored(input);
}

function listFile(file, opts) {
  const data = fs.readFileSync(file);
  const dec = xzstore.decompressStored(data);
  if (opts.robot) {
    process.stdout.write(`name\t${file}\nfile\t1\t1\t${data.length}\t${dec.length}\t${dec.length ? (data.length / dec.length).toFixed(3) : "0.000"}\tCRC64\t0\n`);
    return;
  }
  process.stdout.write("Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename\n");
  const ratio = dec.length ? (data.length / dec.length).toFixed(3) : "0.000";
  process.stdout.write(`    1       1 ${String(data.length).padStart(12)} ${String(dec.length).padStart(12)}  ${ratio}  CRC64   ${file}\n`);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  for (const f of opts.fileLists) opts.files.push(...readFileList(f, false));
  for (const f of opts.nullFileLists) opts.files.push(...readFileList(f, true));
  if (opts.files.length === 0) opts.files.push("-");

  let status = 0;
  for (const file of opts.files) {
    try {
      if (opts.mode === "list") {
        if (file === "-") fatal("--list does not support reading from standard input");
        listFile(file, opts);
        continue;
      }
      const input = file === "-" ? readAllStdin() : fs.readFileSync(file);
      if (opts.mode === "test") {
        xzstore.decompressStored(input);
        continue;
      }
      const output = processBuffer(input, opts);
      if (opts.stdout || file === "-") {
        fs.writeSync(1, output);
      } else {
        const out = outNameFor(file, opts);
        if (!out) {
          warn(`${file}: Filename has an unknown suffix, skipping`, opts);
          status = 1;
          continue;
        }
        writeOutput(out, output, opts);
        if (!opts.keep) fs.unlinkSync(file);
      }
    } catch (e) {
      if (opts.quiet < 2) {
        const msg = e && e.message ? e.message.replace(/^decompress: /, "").replace(/^compress: /, "") : String(e);
        process.stderr.write(`${prog}: ${file}: ${msg}\n`);
      }
      status = 1;
    }
  }
  process.exit(status);
}

main();
