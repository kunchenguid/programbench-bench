"use strict";

const CRC32 = new Uint32Array(256);
for (let i = 0; i < 256; i++) {
  let c = i;
  for (let j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
  CRC32[i] = c >>> 0;
}

const CRC64 = new BigUint64Array(256);
const CRC64_POLY = 0xC96C5795D7870F42n;
for (let i = 0; i < 256; i++) {
  let c = BigInt(i);
  for (let j = 0; j < 8; j++) c = (c & 1n) ? (CRC64_POLY ^ (c >> 1n)) : (c >> 1n);
  CRC64[i] = c;
}

function crc32(buf, start = 0, end = buf.length) {
  let c = 0xFFFFFFFF;
  for (let i = start; i < end; i++) c = CRC32[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

function crc64(buf, start = 0, end = buf.length) {
  let c = 0xFFFFFFFFFFFFFFFFn;
  for (let i = start; i < end; i++) c = CRC64[Number((c ^ BigInt(buf[i])) & 0xFFn)] ^ (c >> 8n);
  return c ^ 0xFFFFFFFFFFFFFFFFn;
}

function u32le(n) {
  const b = Buffer.alloc(4);
  b.writeUInt32LE(n >>> 0, 0);
  return b;
}

function u64le(n) {
  const b = Buffer.alloc(8);
  let x = BigInt(n);
  for (let i = 0; i < 8; i++) {
    b[i] = Number(x & 0xFFn);
    x >>= 8n;
  }
  return b;
}

function vli(n) {
  let x = BigInt(n);
  const out = [];
  do {
    let b = Number(x & 0x7Fn);
    x >>= 7n;
    if (x) b |= 0x80;
    out.push(b);
  } while (x);
  return Buffer.from(out);
}

function pad4(parts) {
  const len = parts.reduce((a, b) => a + b.length, 0);
  const pad = (4 - (len & 3)) & 3;
  if (pad) parts.push(Buffer.alloc(pad));
}

function blockHeader() {
  const body = [Buffer.from([0x00, 0x21, 0x01, 0x16])];
  let preCrcLen = 1 + body.reduce((a, b) => a + b.length, 0);
  const preCrcPad = (4 - (preCrcLen & 3)) & 3;
  if (preCrcPad) body.push(Buffer.alloc(preCrcPad));
  const bodyBuf = Buffer.concat(body);
  const size = 1 + bodyBuf.length + 4;
  const header = Buffer.concat([Buffer.from([size / 4 - 1]), bodyBuf]);
  return Buffer.concat([header, u32le(crc32(header))]);
}

function lzma2Stored(data) {
  const parts = [];
  for (let pos = 0; pos < data.length; ) {
    const n = Math.min(65536, data.length - pos);
    const ctl = pos === 0 ? 0x01 : 0x02;
    parts.push(Buffer.from([ctl, ((n - 1) >>> 8) & 0xFF, (n - 1) & 0xFF]));
    parts.push(data.subarray(pos, pos + n));
    pos += n;
  }
  parts.push(Buffer.from([0x00]));
  return Buffer.concat(parts);
}

function compress(data, check = 4) {
  if (!Buffer.isBuffer(data)) data = Buffer.from(data);
  const flags = Buffer.from([0x00, check === 0 ? 0x00 : 0x04]);
  const header = Buffer.concat([Buffer.from([0xFD, 0x37, 0x7A, 0x58, 0x5A, 0x00]), flags, u32le(crc32(flags))]);
  const bh = blockHeader();
  const comp = lzma2Stored(data);
  const blockParts = [bh, comp];
  const unpadded = bh.length + comp.length + (check === 0 ? 0 : 8);
  pad4(blockParts);
  if (check !== 0) blockParts.push(u64le(crc64(data)));
  const block = Buffer.concat(blockParts);
  const indexParts = [Buffer.from([0x00]), vli(1), vli(unpadded), vli(data.length)];
  pad4(indexParts);
  const indexBody = Buffer.concat(indexParts);
  const index = Buffer.concat([indexBody, u32le(crc32(indexBody))]);
  const backward = Buffer.alloc(4);
  backward.writeUInt32LE(index.length / 4 - 1, 0);
  const footerFlags = flags;
  const footerCrcData = Buffer.concat([backward, footerFlags]);
  const footer = Buffer.concat([u32le(crc32(footerCrcData)), backward, footerFlags, Buffer.from([0x59, 0x5A])]);
  return Buffer.concat([header, block, index, footer]);
}

function readVli(buf, pos) {
  let n = 0n, shift = 0n;
  for (;;) {
    if (pos >= buf.length) throw new Error("Unexpected end of input");
    const b = buf[pos++];
    n |= BigInt(b & 0x7F) << shift;
    if ((b & 0x80) === 0) return [Number(n), pos];
    shift += 7n;
  }
}

function decompressStored(data) {
  if (!Buffer.isBuffer(data)) data = Buffer.from(data);
  if (data.length < 24 || !data.subarray(0, 6).equals(Buffer.from([0xFD,0x37,0x7A,0x58,0x5A,0x00]))) {
    throw new Error("File format not recognized");
  }
  const check = data[7] & 0x0F;
  let pos = 12;
  const out = [];
  for (;;) {
    if (pos >= data.length) throw new Error("Unexpected end of input");
    const hs = data[pos];
    if (hs === 0) break;
    const hlen = (hs + 1) * 4;
    const hcrc = data.readUInt32LE(pos + hlen - 4);
    if (crc32(data, pos, pos + hlen - 4) !== hcrc) throw new Error("Compressed data is corrupt");
    const filterId = data[pos + 2];
    if (filterId !== 0x21) throw new Error("Unsupported options");
    pos += hlen;
    for (;;) {
      const ctl = data[pos++];
      if (ctl === 0x00) break;
      if (ctl !== 0x01 && ctl !== 0x02) throw new Error("Unsupported compressed data");
      if (pos + 2 > data.length) throw new Error("Unexpected end of input");
      const n = ((data[pos] << 8) | data[pos + 1]) + 1;
      pos += 2;
      if (pos + n > data.length) throw new Error("Unexpected end of input");
      out.push(data.subarray(pos, pos + n));
      pos += n;
    }
    while (pos & 3) pos++;
    if (check === 4) pos += 8;
    else if (check !== 0) throw new Error("Unsupported check type");
  }
  return Buffer.concat(out);
}

module.exports = { compress, decompressStored, crc32, crc64 };
