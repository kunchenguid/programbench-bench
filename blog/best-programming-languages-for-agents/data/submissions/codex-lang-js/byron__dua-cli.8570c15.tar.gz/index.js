#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const GREEN = '\x1b[32m';
const CYAN = '\x1b[36m';
const RESET = '\x1b[39m';
const VERSION = 'dua 2.32.2';

function usage() {
  return `A tool to learn about disk usage, fast!

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

Commands:
  interactive  Launch the terminal user interface [aliases: i]
  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [INPUT]...
          One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -t, --threads <THREADS>
          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread
          
          [default: 0]

  -f, --format <FORMAT>
          The format with which to print byte counts
          
          [default: binary]
          [possible values: metric, binary, bytes, gb, gib, mb, mib]

  -A, --apparent-size
          Display apparent size instead of disk usage

  -l, --count-hard-links
          Count hard-linked files each time they are seen

  -x, --stay-on-filesystem
          If set, we will not cross filesystems or traverse mount points

  -i, --ignore-dirs <IGNORE_DIRS>
          One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path.
          
          Hence, they will only be ignored if they are eventually reached as part of the traversal.
          
          [default: /proc /dev /sys /run]

      --log-file <LOG_FILE>
          Write a log file with debug information, including panics

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;
}

function aggregateHelp() {
  return `Aggregate the consumed space of one or more directories or files

Usage: executable aggregate [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
      --stats     If set, print additional statistics about the file traversal to stderr
      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending
      --no-total  If set, no total column will be computed for multiple inputs
  -h, --help      Print help`;
}

function interactiveHelp() {
  return `Launch the terminal user interface

Usage: executable interactive [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -e, --no-entry-check  Do not check entries for presence when listing a directory to avoid slugging performance on slow filesystems
  -h, --help            Print help`;
}

function completionsHelp() {
  return `Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate a completions-script for [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help  Print help`;
}

function dieArg(msg, code = 2) {
  console.error(msg);
  process.exit(code);
}

function invalidValue(value, what, possible) {
  dieArg(`error: invalid value '${value}' for '${what}'
  [possible values: ${possible.join(', ')}]

For more information, try '--help'.`);
}

function unexpected(arg) {
  dieArg(`error: unexpected argument '${arg}' found

  tip: to pass '${arg}' as a value, use '-- ${arg}'

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

For more information, try '--help'.`);
}

function parse(argv) {
  const opts = {
    format: 'binary',
    apparent: false,
    countHardLinks: false,
    stayFs: false,
    ignoreDirs: ['/proc', '/dev', '/sys', '/run'],
    threads: '0',
    sub: 'aggregate',
    inputs: [],
    stats: false,
    noSort: false,
    noTotal: false,
  };
  const globalsAllowed = true;
  let i = 0;
  while (i < argv.length) {
    const a = argv[i];
    if (a === '--') {
      opts.inputs.push(...argv.slice(i + 1));
      break;
    }
    if (a === 'help') {
      const target = argv[i + 1];
      if (target === 'aggregate' || target === 'a') console.log(aggregateHelp());
      else if (target === 'interactive' || target === 'i') console.log(interactiveHelp());
      else if (target === 'completions') console.log(completionsHelp());
      else console.log(usage());
      process.exit(0);
    }
    if (a === '-h' || a === '--help') {
      console.log(usage());
      process.exit(0);
    }
    if (a === '-V' || a === '--version') {
      console.log(VERSION);
      process.exit(0);
    }
    if (a === 'aggregate' || a === 'a' || a === 'interactive' || a === 'i' || a === 'completions') {
      opts.sub = (a === 'a') ? 'aggregate' : (a === 'i') ? 'interactive' : a;
      i++;
      break;
    }
    if (a === '-A' || a === '--apparent-size') opts.apparent = true;
    else if (a === '-l' || a === '--count-hard-links') opts.countHardLinks = true;
    else if (a === '-x' || a === '--stay-on-filesystem') opts.stayFs = true;
    else if (a === '-t' || a === '--threads') opts.threads = argv[++i] ?? dieArg("error: a value is required for '--threads <THREADS>'");
    else if (a.startsWith('--threads=')) opts.threads = a.slice(10);
    else if (a === '-f' || a === '--format') opts.format = argv[++i] ?? dieArg("error: a value is required for '--format <FORMAT>'");
    else if (a.startsWith('--format=')) opts.format = a.slice(9);
    else if (a === '-i' || a === '--ignore-dirs') opts.ignoreDirs.push(argv[++i] ?? '');
    else if (a.startsWith('--ignore-dirs=')) opts.ignoreDirs.push(a.slice(14));
    else if (a === '--log-file') i++;
    else if (a.startsWith('-')) unexpected(a);
    else opts.inputs.push(a);
    i++;
  }

  const formats = ['metric', 'binary', 'bytes', 'gb', 'gib', 'mb', 'mib'];
  if (!formats.includes(opts.format)) invalidValue(opts.format, '--format <FORMAT>', formats);

  if (opts.sub === 'aggregate') {
    while (i < argv.length) {
      const a = argv[i];
      if (a === '-h' || a === '--help') {
        console.log(aggregateHelp());
        process.exit(0);
      } else if (a === '--stats') opts.stats = true;
      else if (a === '--no-sort') opts.noSort = true;
      else if (a === '--no-total') opts.noTotal = true;
      else if (a.startsWith('-')) unexpected(a);
      else opts.inputs.push(a);
      i++;
    }
  } else if (opts.sub === 'interactive') {
    while (i < argv.length) {
      const a = argv[i];
      if (a === '-h' || a === '--help') {
        console.log(interactiveHelp());
        process.exit(0);
      } else if (a === '-e' || a === '--no-entry-check') {
        // Accepted for compatibility.
      } else if (a.startsWith('-')) unexpected(a);
      else opts.inputs.push(a);
      i++;
    }
  } else if (opts.sub === 'completions') {
    if (argv[i] === '-h' || argv[i] === '--help') {
      console.log(completionsHelp());
      process.exit(0);
    }
    opts.shell = argv[i];
    if (!opts.shell) dieArg(`error: the following required arguments were not provided:
  <SHELL>

Usage: executable completions <SHELL>

For more information, try '--help'.`);
  }
  return opts;
}

function blocksSize(st, apparent) {
  if (apparent) return Number(st.size);
  return Number(st.blocks || 0) * 512;
}

function inodeKey(st) {
  return `${Number(st.dev)}:${Number(st.ino)}`;
}

function makeWalker(opts) {
  const seen = new Set();
  const rootDev = new Map();
  const stats = { entries: 0, smallest: null, largest: 0 };

  function note(size) {
    stats.entries++;
    if (stats.smallest === null || size < stats.smallest) stats.smallest = size;
    if (size > stats.largest) stats.largest = size;
  }

  function shouldCount(st, isDir) {
    if (opts.countHardLinks || isDir || st.nlink <= 1) return true;
    const key = inodeKey(st);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }

  function walk(p, isRoot = false, baseDev = null) {
    let st;
    try {
      st = fs.lstatSync(p);
    } catch (e) {
      return { size: 0, errors: 1, isDir: false, missing: true };
    }
    const isSym = st.isSymbolicLink();
    const isDir = st.isDirectory();
    if (isSym && !isRoot) return null;
    let total = shouldCount(st, isDir) ? blocksSize(st, opts.apparent) : 0;
    let errors = 0;
    if (!isDir) {
      note(total);
      return { size: total, errors, isDir: false };
    }
    const myDev = Number(st.dev);
    const effectiveBase = baseDev ?? myDev;
    note(total);
    let names;
    try {
      names = fs.readdirSync(p);
    } catch (e) {
      return { size: total, errors: errors + 1, isDir: true };
    }
    for (const name of names) {
      const child = path.join(p, name);
      if (opts.ignoreDirs.includes(path.resolve(child))) continue;
      let cst;
      try {
        cst = fs.lstatSync(child);
      } catch (e) {
        errors++;
        continue;
      }
      if (cst.isSymbolicLink()) continue;
      if (opts.stayFs && Number(cst.dev) !== effectiveBase) continue;
      const res = walk(child, false, effectiveBase);
      if (res) {
        total += res.size;
        errors += res.errors;
      }
    }
    return { size: total, errors, isDir: true };
  }

  return { walk, stats };
}

function defaultInputs() {
  try {
    return fs.readdirSync('.').filter(n => {
      try { return !fs.lstatSync(n).isSymbolicLink(); } catch { return true; }
    });
  } catch {
    return [];
  }
}

function entriesForDirectory(dir, opts, walker) {
  let names;
  try {
    names = fs.readdirSync(dir);
  } catch {
    return [];
  }
  const out = [];
  for (const name of names) {
    const full = path.join(dir, name);
    let st;
    try { st = fs.lstatSync(full); } catch { continue; }
    if (st.isSymbolicLink()) continue;
    const res = walker.walk(full);
    if (!res) continue;
    out.push({ label: name, size: res.size, errors: res.errors, isDir: res.isDir });
  }
  return out;
}

function formatSize(bytes, fmt) {
  if (fmt === 'bytes') return `${String(Math.round(bytes)).padStart(10)} b`;
  if (fmt === 'gb') return `${(bytes / 1e9).toFixed(2).padStart(7)} GB`;
  if (fmt === 'gib') return `${(bytes / 1073741824).toFixed(2).padStart(6)} GiB`;
  if (fmt === 'mb') return `${(bytes / 1e6).toFixed(2).padStart(9)} MB`;
  if (fmt === 'mib') return `${(bytes / 1048576).toFixed(2).padStart(8)} MiB`;
  const base = fmt === 'metric' ? 1000 : 1024;
  const units = fmt === 'metric' ? [' B', 'KB', 'MB', 'GB', 'TB'] : ['  B', 'KiB', 'MiB', 'GiB', 'TiB'];
  if (bytes === 0) return fmt === 'metric' ? '      0  B' : '      0   B';
  let val = bytes;
  let idx = 0;
  while (idx < units.length - 1 && val > base) {
    val /= base;
    idx++;
  }
  if (idx === 0) {
    const unit = fmt === 'metric' ? '  B' : '   B';
    return `${String(Math.round(bytes)).padStart(7)}${unit}`;
  }
  return `${val.toFixed(2).padStart(7)} ${units[idx]}`;
}

function printRows(rows, opts, printTotal) {
  if (!opts.noSort) rows.sort((a, b) => (a.size - b.size) || a.label.localeCompare(b.label));
  let total = 0;
  let hadErrors = false;
  for (const row of rows) {
    total += row.size;
    if (row.errors) hadErrors = true;
    const label = row.isDir ? `${CYAN}${row.label}${RESET}` : row.label;
    const err = row.errors ? `  <${row.errors} IO Error${row.errors === 1 ? '' : 's'}>` : '';
    console.log(`${GREEN}${formatSize(row.size, opts.format)}${RESET} ${label}${err}`);
  }
  if (printTotal && rows.length > 1 && !opts.noTotal) {
    console.log(`${GREEN}${formatSize(total, opts.format)}${RESET} total`);
  }
  return hadErrors ? 1 : 0;
}

function aggregate(opts) {
  const walker = makeWalker(opts);
  let inputs = opts.inputs.length ? opts.inputs : defaultInputs();
  let rows = [];
  if (inputs.length === 1) {
    let st = null;
    try { st = fs.lstatSync(inputs[0]); } catch {}
    if (st && st.isDirectory()) {
      rows = entriesForDirectory(inputs[0], opts, walker);
      const status = printRows(rows, opts, true);
      if (opts.stats) printStats(walker.stats);
      return status;
    }
  }
  for (const input of inputs) {
    const res = walker.walk(input, true);
    rows.push({ label: input, size: res ? res.size : 0, errors: res ? res.errors : 1, isDir: res ? (res.isDir || res.missing) : true });
  }
  const status = printRows(rows, opts, rows.length > 1);
  if (opts.stats) printStats(walker.stats);
  return status;
}

function printStats(stats) {
  const smallest = stats.smallest === null ? 0 : stats.smallest;
  console.error(`Statistics { entries_traversed: ${stats.entries}, smallest_file_in_bytes: ${smallest}, largest_file_in_bytes: ${stats.largest} }`);
}

function completions(shell) {
  const shells = ['bash', 'elvish', 'fish', 'powershell', 'zsh'];
  if (!shells.includes(shell)) {
    dieArg(`error: invalid value '${shell}' for '<SHELL>'
  [possible values: bash, elvish, fish, powershell, zsh]

  tip: a similar value exists: 'bash'

For more information, try '--help'.`);
  }
  if (shell === 'bash') console.log('_dua() {\n    COMPREPLY=()\n}\ncomplete -F _dua dua');
  else if (shell === 'zsh') console.log('#compdef dua\n\n_arguments "*:file:_files"');
  else if (shell === 'fish') console.log('complete -c dua -s h -l help\ncomplete -c dua -s V -l version');
  else if (shell === 'elvish') console.log('\nuse builtin;\nset edit:completion:arg-completer[dua] = {|@words| }');
  else console.log("\nusing namespace System.Management.Automation\nRegister-ArgumentCompleter -Native -CommandName 'dua' -ScriptBlock { }");
  return 0;
}

function main() {
  const opts = parse(process.argv.slice(2));
  if (opts.sub === 'interactive') {
    console.error('Error: Interactive mode requires a connected terminal');
    process.exit(1);
  }
  if (opts.sub === 'completions') process.exit(completions(opts.shell));
  process.exit(aggregate(opts));
}

main();
