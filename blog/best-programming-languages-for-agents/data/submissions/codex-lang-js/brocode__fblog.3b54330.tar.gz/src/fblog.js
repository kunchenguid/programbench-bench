#!/usr/bin/env node
'use strict';

const fs = require('fs');

const ESC='\x1b[';
const reset=ESC+'0m';
const bold=s=>ESC+'1m'+s+reset;
const dim=s=>ESC+'2m'+s+reset;
const color=(c,s)=>ESC+c+'m'+s+reset;
const boldColor=(c,s)=>ESC+'1;'+c+'m'+s+reset;
const rgb=(r,g,b,s)=>ESC+`38;2;${r};${g};${b}m`+s+reset;
const boldRgb=(r,g,b,s)=>ESC+`1;38;2;${r};${g};${b}m`+s+reset;

const defaults = {
  message_keys:['short_message','msg','message'],
  time_keys:['timestamp','time','@timestamp'],
  level_keys:['level','severity','log.level','loglevel'],
  dump_all_exclude:[],
  always_print_fields:[],
  level_map:{},
  main_line_format:'{{bold(fixed_size 19 fblog_timestamp)}} {{level_style (uppercase (fixed_size 5 fblog_level))}}:{{#if fblog_prefix}} {{bold(cyan fblog_prefix)}}{{/if}} {{fblog_message}}',
  additional_value_format:'{{bold (color_rgb 150 150 150 (min_size 25 key))}}: {{value}}'
};

function usage() { return `json log viewer

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]

Options:
  -a, --additional-value <additional-value>
          adds additional values
      --config-file <config-file>
          configuration file to load
  -m, --message-key <message-key>
          Adds an additional key to detect the message in the log entry. The first matching key will be assigned to \`fblog_message\`.
      --print-lua
          Prints lua init expressions. Used for fblog debugging.
  -t, --time-key <time-key>
          Adds an additional key to detect the time in the log entry. The first matching key will be assigned to \`fblog_timestamp\`.
  -l, --level-key <level-key>
          Adds an additional key to detect the level in the log entry. The first matching key will be assigned to \`fblog_level\`.
      --map-level <from=to>
          Rewrite the log level from one value to another.
  -d, --dump-all
          dumps all values
  -x, --excluded-value <excluded-value>
          Excludes values (--dump-all is enabled implicitly)
  -p, --with-prefix
          consider all text before opening curly brace as prefix
  -f, --filter <filter>
          lua expression to filter log entries. \`message ~= nil and string.find(message, "text.*") ~= nil\`
      --no-implicit-filter-return-statement
          if you pass a filter expression 'return' is automatically prepended. Pass this switch to disable the implicit return.
      --main-line-format <main-line-format>
          Formats the main fblog output. All log values can be used. fblog provides sanitized variables starting with \`fblog_\`.
      --additional-value-format <additional-value-format>
          Formats the additional value fblog output.
  -s, --substitute
          Enable substitution of placeholders in the log messages with their corresponding values from the context.
  -c, --context-key <context-key>
          Use this key as the source of substitutions for the message. Value can either be an array ({1}) or an object ({key}).
  -F, --placeholder-format <placeholder-format>
          The format that should be used for substituting values in the message, where the key is the literal word \`key\`. Example: [[key]] or \${key}.
  -h, --help
          Print help
  -V, --version
          Print version`; }

function parseArgs(argv) {
  const o={additional:[], excluded:[], messageKeys:[], timeKeys:[], levelKeys:[], mapLevel:{}, dumpAll:false, prefix:false, substitute:false, contextKey:'context', placeholderFormat:'{key}', input:'-', configFile:null, filter:null, mainLineFormat:null, additionalValueFormat:null, printLua:false};
  for (let i=0;i<argv.length;i++) {
    const a=argv[i];
    const need=()=>{ if (i+1>=argv.length) { console.error(`error: a value is required for '${a}'`); process.exit(2); } return argv[++i]; };
    if (a==='-h'||a==='--help') { console.log(usage()); process.exit(0); }
    else if (a==='-V'||a==='--version') { console.log('fblog 4.17.0'); process.exit(0); }
    else if (a==='-a'||a==='--additional-value') o.additional.push(need());
    else if (a==='--config-file') o.configFile=need();
    else if (a==='-m'||a==='--message-key') o.messageKeys.push(need());
    else if (a==='-t'||a==='--time-key') o.timeKeys.push(need());
    else if (a==='-l'||a==='--level-key') o.levelKeys.push(need());
    else if (a==='--map-level') { const v=need(); const p=v.indexOf('='); if(p>=0)o.mapLevel[v.slice(0,p)]=v.slice(p+1); }
    else if (a==='-d'||a==='--dump-all') o.dumpAll=true;
    else if (a==='-x'||a==='--excluded-value') { o.excluded.push(need()); o.dumpAll=true; }
    else if (a==='-p'||a==='--with-prefix') o.prefix=true;
    else if (a==='-f'||a==='--filter') o.filter=need();
    else if (a==='--no-implicit-filter-return-statement') {}
    else if (a==='--main-line-format') o.mainLineFormat=need();
    else if (a==='--additional-value-format') o.additionalValueFormat=need();
    else if (a==='-s'||a==='--substitute') o.substitute=true;
    else if (a==='-c'||a==='--context-key') o.contextKey=need();
    else if (a==='-F'||a==='--placeholder-format') o.placeholderFormat=need();
    else if (a==='--print-lua') o.printLua=true;
    else if (a.startsWith('-')) { console.error(`error: unexpected argument '${a}' found`); process.exit(2); }
    else o.input=a;
  }
  return o;
}

function parseToml(path) {
  const cfg={level_map:{}}; let section='';
  let text; try { text=fs.readFileSync(path,'utf8'); } catch { return cfg; }
  for (const raw of text.split(/\r?\n/)) {
    let line=raw.replace(/#.*/,'').trim(); if(!line) continue;
    const sec=line.match(/^\[(.+)\]$/); if(sec){section=sec[1]; continue;}
    const m=line.match(/^([A-Za-z0-9_.-]+)\s*=\s*(.*)$/); if(!m) continue;
    const key=m[1]; let val=m[2].trim();
    if (val.startsWith('[')) {
      try { val=JSON.parse(val.replace(/'/g,'"')); } catch { val=[]; }
    } else if ((val.startsWith('"')&&val.endsWith('"'))||(val.startsWith("'")&&val.endsWith("'"))) val=val.slice(1,-1);
    if(section==='level_map') cfg.level_map[key]=String(val); else cfg[key]=val;
  }
  return cfg;
}

function mergeConfig(opts) {
  let cfg=JSON.parse(JSON.stringify(defaults));
  const candidates=[];
  if (opts.configFile) candidates.push(opts.configFile); else candidates.push('fblog.toml');
  for (const p of candidates) if (fs.existsSync(p)) Object.assign(cfg, parseToml(p));
  cfg.message_keys=[...opts.messageKeys, ...(cfg.message_keys||defaults.message_keys)];
  cfg.time_keys=[...opts.timeKeys, ...(cfg.time_keys||defaults.time_keys)];
  cfg.level_keys=[...opts.levelKeys, ...(cfg.level_keys||defaults.level_keys)];
  cfg.level_map=Object.assign({}, cfg.level_map||{}, opts.mapLevel);
  if (opts.mainLineFormat) cfg.main_line_format=opts.mainLineFormat;
  if (opts.additionalValueFormat) cfg.additional_value_format=opts.additionalValueFormat;
  return cfg;
}

function getTop(obj, keys) { for (const k of keys) if (obj && Object.prototype.hasOwnProperty.call(obj,k)) return obj[k]; return undefined; }
function pathParts(path) { return path.split('>').map(s=>s.trim()).filter(Boolean); }
function getPath(obj, path) {
  let cur=obj;
  for (const part0 of pathParts(path)) {
    let part=part0, m;
    while ((m=part.match(/^([^\[]*)\[(\d+)\](.*)$/))) {
      if (m[1]) { cur=cur?.[m[1]]; }
      cur=cur?.[Number(m[2])]; part=m[3];
    }
    if (part) cur=cur?.[part];
  }
  return cur;
}

function normTime(v) {
  if (v===undefined || v===null) return ''.padEnd(19,' ');
  let s=String(v);
  if (/^\d{12,}$/.test(s)) return new Date(Number(s)).toISOString().slice(0,19);
  if (/^\d{4}-\d{2}-\d{2}T/.test(s)) { const d=new Date(s); if(!isNaN(d)) return d.toISOString().slice(0,19); }
  return fixed(s,19,false);
}
function fixed(s,n,left=true){ s=String(s); if(s.length>n)return s.slice(0,n); return left?s.padStart(n,' '):s.padEnd(n,' '); }
function levelStyle(levelText, rawLevel) {
  const l=String(rawLevel||'').toLowerCase();
  let c='35';
  if(l==='trace') c='36'; else if(l==='debug') c='34'; else if(l==='info') c='32'; else if(l==='warn') c='33'; else if(l==='error') c='31'; else if(l==='fatal') c='35';
  return boldColor(c, levelText);
}
function displayLevel(level) { const up=String(level===undefined?'UNKNOWN':level).toUpperCase(); return fixed(up,5,true); }

function prettyVal(v, quoteString=false) {
  if (v===undefined) return '';
  if (typeof v==='string') return quoteString ? JSON.stringify(v) : color('1;33', v);
  if (typeof v==='number') return color('1;36', String(v));
  if (typeof v==='boolean') return color(v?'1;32':'1;31', String(v));
  if (Array.isArray(v)) return dim('[')+v.map(x=>prettyVal(x,false)).join(dim(', '))+dim(']');
  if (v && typeof v==='object') {
    return dim('{')+Object.keys(v).sort().map(k=>color('35',k)+dim(': ')+prettyVal(v[k],false)).join(dim(', '))+dim('}');
  }
  return String(v);
}
function plainVal(v, quote=false) {
  if (typeof v==='string') return quote ? JSON.stringify(v) : v;
  if (v===undefined) return '';
  if (v && typeof v==='object') return JSON.stringify(v);
  return String(v);
}
function minSize(s,n){ s=String(s); return s.length<n ? s.padStart(n,' ') : s; }
function addLine(key, val, quote=false) { return bold(rgb(150,150,150,minSize(key,25)))+': '+plainVal(val, quote); }

function flatten(obj, prefix='', out=[], fromArray=false, arrayNested=false) {
  if (Array.isArray(obj)) {
    obj.forEach((v,i)=>flatten(v, `${prefix}[${arrayNested ? i + 1 : i}]`, out, true, arrayNested || Array.isArray(v)));
  } else if (obj && typeof obj==='object') {
    for (const k of Object.keys(obj).sort()) {
      const p=prefix ? `${prefix} > ${k}` : k;
      flatten(obj[k], p, out, false, false);
    }
  } else out.push({key:prefix, value:obj, quote:fromArray && typeof obj==='string'});
  return out;
}
function additionalEntries(obj, spec) {
  const v=getPath(obj,spec); const out=[];
  if (Array.isArray(v)) flatten(v,spec,out,true,false); else if (v && typeof v==='object') flatten(v,spec,out,false); else out.push({key:spec,value:v,quote:false});
  return out;
}

function evalFilter(expr, obj) {
  if (!expr) return true;
  const env={...obj};
  // common fblog/Lua subset: ==, ~=, nil, and/or, comparisons, string.find(var,"pat") ~= nil
  let e=expr.trim().replace(/^return\s+/, '');
  e=e.replace(/\bnil\b/g,'undefined').replace(/\band\b/g,'&&').replace(/\bor\b/g,'||').replace(/~=/g,'!==');
  e=e.replace(/string\.find\(([^,]+),\s*"([^"]*)"\)/g, '(__find($1,"$2"))');
  const proxy = new Proxy(env, {
    has: () => true,
    get: (target, key) => key === Symbol.unscopables ? undefined : target[key]
  });
  const finder=(s,p)=>{ if(s==null)return undefined; return new RegExp(p).test(String(s)) ? 1 : undefined; };
  try { return !!Function('__env','__find',`with(__env){ return (${e}); }`)(proxy, finder); } catch { return false; }
}

function substitute(msg, ctx, fmt) {
  if (!ctx || typeof msg!=='string') return msg;
  const token = fmt.replace(/[.*+?^${}()|[\]\\]/g,'\\$&').replace('key','(.+?)');
  const re = new RegExp(token,'g');
  return msg.replace(re, (all,key)=>{
    let val = Array.isArray(ctx) ? ctx[Number(key)] : ctx[key];
    if (val===undefined) return dim('{')+color('1;31',key)+dim('}');
    return prettyVal(val,false);
  });
}

function renderCustom(fmt, vars) {
  // A small template fallback for simple custom formats: {{name}} replacements.
  return fmt.replace(/\{\{\s*([A-Za-z0-9_. >\[\]-]+)\s*\}\}/g, (_,k)=>plainVal(vars[k.trim()] ?? getPath(vars.__obj,k.trim())));
}

function processLine(line, opts, cfg) {
  if (line.endsWith('\r')) line=line.slice(0,-1);
  let jsonText=line, prefix='';
  if (opts.prefix) { const idx=line.indexOf('{'); if(idx>0){ prefix=line.slice(0,idx).trimEnd(); jsonText=line.slice(idx); } }
  let obj;
  try { obj=JSON.parse(jsonText); } catch { return boldRgb(255,135,22,'??? >')+' '+line; }
  if (!obj || typeof obj!=='object' || Array.isArray(obj)) return boldRgb(255,135,22,'??? >')+' '+line;
  if (!evalFilter(opts.filter, obj)) return null;
  let msg=getTop(obj,cfg.message_keys); if (msg===undefined) msg=jsonText;
  let rawLevel=getTop(obj,cfg.level_keys); if (rawLevel!==undefined && cfg.level_map[String(rawLevel)]!==undefined) rawLevel=cfg.level_map[String(rawLevel)];
  const t=normTime(getTop(obj,cfg.time_keys));
  if (opts.substitute) msg=substitute(msg, getPath(obj, opts.contextKey), opts.placeholderFormat);
  let main;
  if (cfg.main_line_format !== defaults.main_line_format) main=renderCustom(cfg.main_line_format,{...obj,fblog_timestamp:t,fblog_level:rawLevel??'UNKNOWN',fblog_message:msg,fblog_prefix:prefix,__obj:obj});
  else main=bold(t)+' '+levelStyle(displayLevel(rawLevel), rawLevel??'UNKNOWN')+':'+(prefix?' '+bold(color('36',prefix)):'')+' '+msg;
  const lines=[main];
  let fields=[];
  if (opts.dumpAll) fields=flatten(obj).filter(e=>!opts.excluded.includes(e.key));
  for (const a of [...(cfg.always_print_fields||[]), ...opts.additional]) fields.push(...additionalEntries(obj,a));
  for (const e of fields) if (e.value!==undefined) {
    if (cfg.additional_value_format !== defaults.additional_value_format) {
      lines.push(renderCustom(cfg.additional_value_format,{key:e.key,value:plainVal(e.value,e.quote),__obj:obj}));
    } else lines.push(addLine(e.key,e.value,e.quote));
  }
  return lines.join('\n');
}

function main(){
  const opts=parseArgs(process.argv.slice(2)); const cfg=mergeConfig(opts);
  if(opts.printLua){ return; }
  const input = opts.input==='-' ? fs.readFileSync(0,'utf8') : fs.readFileSync(opts.input,'utf8');
  const outs=[];
  for (const line of input.split(/\n/)) { if(line==='') continue; const r=processLine(line,opts,cfg); if(r!==null) outs.push(r); }
  if (outs.length) process.stdout.write(outs.join('\n')+'\n');
}
main();
