#!/usr/bin/env node
'use strict';

const { spawnSync } = require('child_process');
const fs = require('fs');

const HELP_LONG = `Automatically trims your tracking branches whose upstream branches are merged or stray.
\`git-trim\` is a missing companion to the \`git fetch --prune\` and a proper, safer, faster alternative to your \`<bash oneliner HERE>\`.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks \`git symbolic-ref refs/remotes/*/HEAD\`] [config: trim.bases]
          
          The default value is a branch that tracks \`git symbolic-ref refs/remotes/*/HEAD\`. They might not be reflected correctly when the HEAD branch of your remote repository is changed. You can see the changed HEAD branch name with \`git remote show <remote>\` and apply it to your local repository with \`git remote set-head <remote> --auto\`.

  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. \`release-*\`, \`feature/*\`) of branches that should never be deleted. [config: trim.protected]

      --no-update
          Do not update remotes [config: trim.update]

      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]

      --no-confirm
          Do not ask confirm [config: trim.confirm]

      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]

  -d, --delete <DELETE>
          Comma separated values of \`<delete range>[:<remote name>]\`. Delete range is one of the \`merged, merged-local, merged-remote, stray, diverged, local, remote\`. \`:<remote name>\` is only necessary to a \`<delete range>\` when the range is applied to remote branches. You can use \`*\` as \`<remote name>\` to delete a range of branches from all remotes. [default : \`merged:origin\`] [config: trim.delete]
          
          \`merged\` implies \`merged-local,merged-remote\`.
          
          \`merged-local\` will delete merged tracking local branches. \`merged-remote:<remote>\` will delete merged upstream branches from \`<remote>\`. \`stray\` will delete tracking local branches, which is not merged, but the upstream is gone. \`diverged:<remote>\` will delete merged tracking local branches, and their upstreams from \`<remote>\` even if the upstreams are not merged and diverged from local ones. \`local\` will delete non-tracking merged local branches. \`remote:<remote>\` will delete non-upstream merged remote tracking branches. Use with caution when you are using other than \`merged\`. It might lose changes, and even nuke repositories.

      --dry-run
          Do not delete branches, show what branches will be deleted

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const HELP_SHORT = `Automatically trims your tracking branches whose upstream branches are merged or stray.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks \`git symbolic-ref refs/remotes/*/HEAD\`] [config: trim.bases]
  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. \`release-*\`, \`feature/*\`) of branches that should never be deleted. [config: trim.protected]
      --no-update
          Do not update remotes [config: trim.update]
      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]
      --no-confirm
          Do not ask confirm [config: trim.confirm]
      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]
  -d, --delete <DELETE>
          Comma separated values of \`<delete range>[:<remote name>]\`. Delete range is one of the \`merged, merged-local, merged-remote, stray, diverged, local, remote\`. \`:<remote name>\` is only necessary to a \`<delete range>\` when the range is applied to remote branches. You can use \`*\` as \`<remote name>\` to delete a range of branches from all remotes. [default : \`merged:origin\`] [config: trim.delete]
      --dry-run
          Do not delete branches, show what branches will be deleted
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version`;

function out(s = '') { process.stdout.write(s + '\n'); }
function err(s = '') { process.stderr.write(s + '\n'); }

function git(args, opts = {}) {
  const r = spawnSync('git', args, {
    encoding: 'utf8',
    input: opts.input || undefined,
    stdio: opts.inherit ? 'inherit' : ['pipe', 'pipe', 'pipe'],
  });
  return r;
}

function gitText(args) {
  const r = git(args);
  if (r.status !== 0) return null;
  return (r.stdout || '').replace(/\s+$/, '');
}

function config(name) {
  const r = git(['config', '--get', name]);
  if (r.status !== 0) return null;
  return (r.stdout || '').trim();
}

function parseArgs(argv) {
  const opt = {
    bases: undefined, protected: undefined, update: undefined, updateInterval: undefined,
    confirm: undefined, detach: undefined, del: undefined, dryRun: false,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const need = (name) => {
      if (i + 1 >= argv.length || argv[i + 1].startsWith('-')) {
        err(`error: a value is required for '${name}' but none was supplied\n`);
        err(`For more information, try '--help'.`);
        process.exit(2);
      }
      return argv[++i];
    };
    if (a === '--help') { out(HELP_LONG); process.exit(0); }
    else if (a === '-h') { out(HELP_SHORT); process.exit(0); }
    else if (a === '--version' || a === '-V') { out('git-trim 0.4.4'); process.exit(0); }
    else if (a === '-b' || a === '--bases') opt.bases = need(a === '-b' ? '--bases <BASES>' : '--bases <BASES>');
    else if (a.startsWith('--bases=')) opt.bases = a.slice(8);
    else if (a === '-p' || a === '--protected') opt.protected = need('--protected <PROTECTED>');
    else if (a.startsWith('--protected=')) opt.protected = a.slice(12);
    else if (a === '--no-update') opt.update = false;
    else if (a === '--update-interval') opt.updateInterval = need('--update-interval <UPDATE_INTERVAL>');
    else if (a.startsWith('--update-interval=')) opt.updateInterval = a.slice(18);
    else if (a === '--no-confirm') opt.confirm = false;
    else if (a === '--no-detach') opt.detach = false;
    else if (a === '-d' || a === '--delete') opt.del = need('--delete <DELETE>');
    else if (a.startsWith('--delete=')) opt.del = a.slice(9);
    else if (a === '--dry-run') opt.dryRun = true;
    else {
      err(`error: unexpected argument '${a}' found\n`);
      err(`Usage: executable [OPTIONS]\n`);
      err(`For more information, try '--help'.`);
      process.exit(2);
    }
  }
  return opt;
}

function splitList(v) {
  if (!v) return [];
  return v.split(',').map(s => s.trim()).filter(Boolean);
}

function boolConfig(v, dflt) {
  if (v == null || v === '') return dflt;
  return /^(true|yes|on|1)$/i.test(v);
}

function getRefs() {
  const fmt = '%(refname)%00%(refname:short)%00%(objectname)%00%(upstream:short)%00%(upstream:track)%00%(symref)';
  const r = git(['for-each-ref', `--format=${fmt}`, 'refs/heads', 'refs/remotes']);
  if (r.status !== 0) throw new Error((r.stderr || r.stdout || '').trim());
  const locals = [], remotes = [], symrefs = [];
  for (const line of (r.stdout || '').split('\n')) {
    if (!line) continue;
    const [refname, short, oid, upstream, track, symref] = line.split('\0');
    const item = { refname, short, oid, upstream, track, symref };
    if (symref) symrefs.push(item);
    else if (refname.startsWith('refs/heads/')) locals.push(item);
    else if (refname.startsWith('refs/remotes/') && !short.endsWith('/HEAD')) remotes.push(item);
  }
  return { locals, remotes, symrefs };
}

function remoteOf(short) {
  const i = short.indexOf('/');
  return i < 0 ? '' : short.slice(0, i);
}

function branchNameOfRemote(short) {
  const i = short.indexOf('/');
  return i < 0 ? short : short.slice(i + 1);
}

function isAncestor(a, b) {
  if (!a || !b) return false;
  return git(['merge-base', '--is-ancestor', a, b]).status === 0;
}

function globToRegex(p) {
  let s = '^';
  for (const ch of p) {
    if (ch === '*') s += '.*';
    else if (ch === '?') s += '.';
    else s += ch.replace(/[|\\{}()[\]^$+?.]/g, '\\$&');
  }
  return new RegExp(s + '$');
}

function parseDelete(spec) {
  const ranges = { mergedLocal: false, stray: false, local: false, mergedRemote: new Set(), diverged: new Set(), remote: new Set() };
  for (const raw of splitList(spec || 'merged:origin')) {
    const [kind, rem] = raw.split(':');
    const remote = rem || '';
    if (kind === 'merged') {
      ranges.mergedLocal = true;
      ranges.mergedRemote.add(remote || 'origin');
    } else if (kind === 'merged-local') ranges.mergedLocal = true;
    else if (kind === 'merged-remote') ranges.mergedRemote.add(remote || 'origin');
    else if (kind === 'stray') ranges.stray = true;
    else if (kind === 'diverged') ranges.diverged.add(remote || 'origin');
    else if (kind === 'local') ranges.local = true;
    else if (kind === 'remote') ranges.remote.add(remote || 'origin');
  }
  return ranges;
}

function remoteAllowed(set, r) {
  return set.has('*') || set.has(r);
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (git(['rev-parse', '--git-dir']).status !== 0) {
    err("Error: could not find repository at '.'; class=Repository (6); code=NotFound (-3)");
    process.exit(1);
  }

  const cfgUpdate = config('trim.update');
  const cfgConfirm = config('trim.confirm');
  const cfgDetach = config('trim.detach');
  const cfgBases = config('trim.bases');
  const cfgProt = config('trim.protected');
  const cfgDelete = config('trim.delete');
  const cfgInterval = config('trim.updateInterval');

  const update = args.update !== undefined ? args.update : boolConfig(cfgUpdate, true);
  const confirm = args.confirm !== undefined ? args.confirm : boolConfig(cfgConfirm, true);
  const detach = args.detach !== undefined ? args.detach : boolConfig(cfgDetach, true);
  const updateInterval = Number(args.updateInterval ?? cfgInterval ?? '5');
  const protectedPatterns = splitList(args.protected ?? cfgProt);
  const protectedRegex = protectedPatterns.map(globToRegex);
  const del = parseDelete(args.del ?? cfgDelete);

  if (update) {
    let doFetch = true;
    const gitDir = gitText(['rev-parse', '--git-dir']);
    const stamp = gitDir ? `${gitDir}/git-trim-update` : null;
    if (stamp && updateInterval > 0) {
      try {
        const st = fs.statSync(stamp);
        doFetch = ((Date.now() - st.mtimeMs) / 1000) >= updateInterval;
      } catch (_) {}
    }
    if (doFetch) {
      git(['fetch', '--all', '--prune'], { inherit: true });
      if (stamp) { try { fs.closeSync(fs.openSync(stamp, 'w')); } catch (_) {} }
    }
  }

  const refs = getRefs();
  const localsByName = new Map(refs.locals.map(x => [x.short, x]));
  const remotesByName = new Map(refs.remotes.map(x => [x.short, x]));
  const baseRemoteShorts = new Set();
  const baseLocalNames = new Set();
  const baseTargets = [];

  const baseSpecs = splitList(args.bases ?? cfgBases);
  if (baseSpecs.length) {
    for (const b of baseSpecs) {
      const loc = localsByName.get(b);
      const rem = remotesByName.get(b);
      if (loc) {
        baseLocalNames.add(loc.short);
        if (loc.upstream) baseRemoteShorts.add(loc.upstream);
        baseTargets.push(loc.upstream || loc.short);
      } else if (rem) {
        baseRemoteShorts.add(rem.short);
        baseTargets.push(rem.short);
      } else {
        baseTargets.push(b);
      }
    }
  } else {
    for (const s of refs.symrefs) {
      if (s.refname.startsWith('refs/remotes/') && s.short.endsWith('/HEAD')) {
        const target = s.symref.replace(/^refs\/remotes\//, '');
        baseRemoteShorts.add(target);
        baseTargets.push(target);
        for (const loc of refs.locals) if (loc.upstream === target) baseLocalNames.add(loc.short);
      }
    }
  }
  if (baseTargets.length === 0 && localsByName.has('main')) {
    baseLocalNames.add('main'); baseTargets.push('main');
  } else if (baseTargets.length === 0 && localsByName.has('master')) {
    baseLocalNames.add('master'); baseTargets.push('master');
  }

  const isMerged = (ref) => baseTargets.some(b => isAncestor(ref.short, b));
  const current = (gitText(['branch', '--show-current']) || '').trim();
  const deleteLocal = [];
  const deleteRemote = [];
  const remainLocal = [];
  const remainRemote = [];
  let foot = 1;
  const foots = new Map();
  const footnote = (msg) => {
    if (!foots.has(msg)) foots.set(msg, foot++);
    return `*${foots.get(msg)}`;
  };

  for (const loc of refs.locals.sort((a,b) => a.short.localeCompare(b.short))) {
    const merged = isMerged(loc);
    const protIdx = protectedRegex.findIndex(r => r.test(loc.short));
    const prot = protIdx >= 0 ? protectedPatterns[protIdx] : null;
    const gone = loc.upstream && /\[gone\]/.test(loc.track || '');
    const tracking = !!loc.upstream || gone;
    let delThis = false;
    let suffix = '';
    if (baseLocalNames.has(loc.short)) suffix = '[base]';
    else if (prot && merged) suffix = `[merged, but: protected by a pattern \`${prot}\`]`;
    else if (prot) suffix = `[protected by a pattern \`${prot}\`]`;
    else if (tracking && merged && del.mergedLocal) delThis = true;
    else if (tracking && gone && !merged && del.stray) delThis = true;
    else if (!tracking && merged && del.local) delThis = true;
    else if (tracking && merged) suffix = '[merged, but: delete range `merged-local` was not given]';
    else if (!tracking) suffix = footnote("Set an upstream to make it a tracking branch or add `--delete 'local'` flag.");
    else suffix = footnote("Add `--delete 'merged:*'` flag.");
    if (loc.short === current && delThis) {
      if (detach) git(['checkout', '--detach'], { inherit: true });
      else delThis = false;
    }
    if (delThis) deleteLocal.push(loc);
    else remainLocal.push({ name: loc.short, suffix });
  }

  for (const rem of refs.remotes.sort((a,b) => a.short.localeCompare(b.short))) {
    const rname = remoteOf(rem.short);
    const merged = isMerged(rem);
    let delThis = false;
    let suffix = '';
    if (baseRemoteShorts.has(rem.short)) suffix = '[base]';
    else if (merged && remoteAllowed(del.mergedRemote, rname)) delThis = true;
    else if (merged && remoteAllowed(del.remote, rname)) delThis = true;
    else if (merged) suffix = footnote("Add `--delete 'merged:*'` flag.");
    else suffix = footnote("Add `--delete 'remote:*'` flag.");
    if (delThis) deleteRemote.push(rem);
    else remainRemote.push({ name: rem.short, suffix });
  }

  out('Branches that will remain:');
  out('  local branches:');
  for (const r of remainLocal) out(`    ${r.name}${r.suffix ? ' ' + r.suffix : ''}`);
  out('  remote references:');
  for (const r of remainRemote) out(`    ${r.name}${r.suffix ? ' ' + r.suffix : ''}`);
  if (foots.size) {
    out('  Some branches are skipped. Consider following to scan them:');
    for (const [msg, n] of foots) out(`    *${n}: ${msg}`);
  }
  out('');

  if (deleteLocal.length) {
    out('Delete merged local branches:');
    for (const b of deleteLocal) out(`  - ${b.short}${b.upstream ? '' : ' (non-tracking)'}`);
  }
  if (deleteRemote.length) {
    out('Delete merged remote refs:');
    for (const b of deleteRemote) out(`  - ${remoteOf(b.short)}, refs/heads/${branchNameOfRemote(b.short)}`);
  }

  if (!args.dryRun && confirm && (deleteLocal.length || deleteRemote.length)) {
    process.stdout.write('Delete above branches? [y/N] ');
    const answer = fs.readFileSync(0, 'utf8').trim().toLowerCase();
    if (answer !== 'y' && answer !== 'yes') process.exit(0);
  }

  for (const b of deleteLocal) {
    if (args.dryRun) out(`Delete branch ${b.short} (dry run).`);
    else git(['branch', '-d', b.short], { inherit: true });
  }
  for (const b of deleteRemote) {
    const cmd = ['push'];
    if (args.dryRun) cmd.push('--dry-run');
    cmd.push(remoteOf(b.short), '--delete', branchNameOfRemote(b.short));
    git(cmd, { inherit: true });
  }
}

try {
  main();
} catch (e) {
  err(`Error: ${e.message}`);
  process.exit(1);
}
