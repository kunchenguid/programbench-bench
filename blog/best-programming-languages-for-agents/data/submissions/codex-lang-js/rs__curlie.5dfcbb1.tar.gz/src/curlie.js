#!/usr/bin/env node
const { spawnSync } = require("child_process");

const argv = process.argv.slice(2);
const prog = "./executable";

const valueOptions = new Set([
  "-A", "--user-agent", "-b", "--cookie", "-c", "--cookie-jar", "-d", "--data",
  "--data-ascii", "--data-binary", "--data-raw", "--data-urlencode", "-D",
  "--dump-header", "-e", "--referer", "-F", "--form", "--form-string", "-H",
  "--header", "-K", "--config", "-o", "--output", "-r", "--range", "-T",
  "--upload-file", "-u", "--user", "-X", "--request", "--connect-timeout",
  "--max-time", "--max-redirs", "--proxy", "-x", "--cacert", "--capath",
  "--cert", "-E", "--key", "--resolve", "--connect-to", "--url"
]);

function runCurl(args, opts = {}) {
  const res = spawnSync("curl", args, {
    input: opts.input,
    encoding: "utf8",
    maxBuffer: 1024 * 1024 * 64
  });
  return res;
}

function writeHelp(category) {
  const args = category === undefined ? ["--help", "all"] : ["--help", category];
  const res = runCurl(args);
  const out = (res.stdout || "").replace(
    /^Usage: curl \[options\.\.\.\] <url>/,
    `Usage: ${prog} [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]`
  );
  process.stdout.write(out);
  if (res.stderr) process.stderr.write(res.stderr);
  process.exit(res.status || 0);
}

if (argv.length === 0) writeHelp(undefined);

for (let i = 0; i < argv.length; i++) {
  if (argv[i] === "--version" || argv[i] === "-V") {
    const res = runCurl(["--version"]);
    process.stdout.write(res.stdout || "");
    process.stderr.write(res.stderr || "");
    process.exit(res.status || 0);
  }
  if (argv[i] === "--help" || argv[i] === "-h") {
    writeHelp(argv[i + 1] || "");
  }
}

function isUrl(s) {
  return /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(s) || /^localhost([/:]|$)/.test(s);
}

function shellQuote(a) {
  if (/^\{.*\}$/.test(a)) return a;
  if (/^[A-Za-z0-9_./:@%+=,?&-]+$/.test(a)) return a;
  return `"${String(a).replace(/(["\\$`])/g, "\\$1")}"`;
}

function parseJsonLiteral(s) {
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}

let showCurl = false;
let pretty = false;
let formMode = false;
let method = null;
let url = null;
let curlOpts = [];
let headers = [];
let extras = [];
let query = [];
let data = {};
let hasData = false;

const tokens = [];
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === "--curl") {
    showCurl = true;
  } else if (a === "--pretty") {
    pretty = true;
  } else if (a === "--form") {
    formMode = true;
  } else {
    tokens.push(a);
  }
}

for (let i = 0; i < tokens.length; i++) {
  const a = tokens[i];

  if (a.startsWith("-")) {
    curlOpts.push(a);
    if (valueOptions.has(a) && i + 1 < tokens.length) {
      curlOpts.push(tokens[++i]);
    }
    continue;
  }

  if (!url && !method && /^[A-Z][A-Z0-9_-]*$/.test(a)) {
    method = a;
    continue;
  }

  if (!url && (isUrl(a) || !a.includes("=") && !a.includes(":"))) {
    url = a;
    continue;
  }

  if (!url) {
    extras.push(a);
    continue;
  }

  const eqeq = a.indexOf("==");
  const coleq = a.indexOf(":=");
  const eq = a.indexOf("=");
  const colon = a.indexOf(":");

  if (eqeq > 0) {
    query.push([a.slice(0, eqeq), a.slice(eqeq + 2)]);
  } else if (coleq > 0) {
    data[a.slice(0, coleq)] = parseJsonLiteral(a.slice(coleq + 2));
    hasData = true;
  } else if (eq > 0) {
    const k = a.slice(0, eq);
    const v = a.slice(eq + 1);
    if (formMode) {
      extras.push("-F", `${k}=${v}`);
    } else {
      data[k] = v;
      hasData = true;
    }
  } else if (colon >= 0) {
    headers.push(a);
  } else {
    extras.push(a);
  }
}

if (url && query.length) {
  const sep = url.includes("?") ? "&" : "?";
  const q = query.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
  url += sep + q;
}

const curlArgs = [];
if (method) curlArgs.push("-X", method);
curlArgs.push(...curlOpts);
for (const h of headers) curlArgs.push("-H", h);
if (formMode) {
  curlArgs.push(...extras);
} else if (hasData) {
  curlArgs.push("-d", JSON.stringify(data));
  curlArgs.push(...extras);
} else {
  curlArgs.push(...extras);
}
if (url) curlArgs.push(url);
curlArgs.push("-s", "-S");
if (pretty) curlArgs.push("-v");
if (!hasData && !formMode && !curlOpts.some((x) => /^(-d|--data|-F|--form)/.test(x))) {
  curlArgs.push("-d@-");
}
if (!formMode) curlArgs.push("-H", "Content-Type: application/json");
curlArgs.push("-H", "Accept: application/json, */*");

if (showCurl) {
  if (url) process.stderr.write(`${url}\n`);
  process.stdout.write(`curl ${curlArgs.map(shellQuote).join(" ")}\n`);
  process.exit(0);
}

if (url) process.stderr.write(`${url}\n`);
const res = runCurl(curlArgs);
let stdout = res.stdout || "";
let stderr = res.stderr || "";

if (pretty && stdout) {
  try {
    stdout = JSON.stringify(JSON.parse(stdout), null, 4) + "\n";
  } catch {
    // Leave non-JSON responses unchanged.
  }
}

process.stdout.write(stdout);
process.stderr.write(stderr);
process.exit(res.status || 0);
