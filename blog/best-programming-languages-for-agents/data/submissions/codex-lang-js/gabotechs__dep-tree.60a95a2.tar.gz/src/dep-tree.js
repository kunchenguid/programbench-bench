#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "dep-tree version v0.23.4";

function main() {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed.help) return printHelp(parsed.command);
  if (parsed.version) return console.log(VERSION);
  try {
    if (parsed.command === "help") return printHelp(parsed.positionals[0]);
    if (parsed.command === "config") return writeConfig(parsed.flags.config || ".dep-tree.yml");
    if (parsed.command === "check") return cmdCheck(parsed);
    if (parsed.command === "explain") return cmdExplain(parsed);
    if (parsed.command === "tree") return cmdTree(parsed);
    if (parsed.command === "entropy" || !parsed.command) return cmdEntropy(parsed);
    return cmdEntropy(parsed);
  } catch (err) {
    console.error("Error: " + err.message);
    process.exitCode = 1;
  }
}

function parseArgs(args) {
  const commands = new Set(["entropy", "tree", "check", "explain", "config", "help"]);
  const flags = { only: [], exclude: [] };
  let command = null;
  const positionals = [];
  let help = false, version = false;
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (!command && commands.has(a)) { command = a; continue; }
    if (a === "-h" || a === "--help") { help = true; continue; }
    if (a === "-v" || a === "--version") { version = true; continue; }
    if (a === "-c" || a === "--config") { flags.config = args[++i]; continue; }
    if (a.startsWith("--config=")) { flags.config = a.slice(9); continue; }
    if (a === "--json") { flags.json = true; continue; }
    if (a === "--unwrap-exports") { flags.unwrapExports = true; continue; }
    if (a === "--no-browser-open") { flags.noBrowserOpen = true; continue; }
    if (a === "--enable-gui") { flags.enableGui = true; continue; }
    if (a === "--render-path") { flags.renderPath = args[++i]; continue; }
    if (a.startsWith("--render-path=")) { flags.renderPath = a.slice(14); continue; }
    if (a === "--only") { flags.only.push(args[++i]); continue; }
    if (a.startsWith("--only=")) { flags.only.push(a.slice(7)); continue; }
    if (a === "--exclude") { flags.exclude.push(args[++i]); continue; }
    if (a.startsWith("--exclude=")) { flags.exclude.push(a.slice(10)); continue; }
    if (a === "-l" || a === "--overlap-left") { flags.overlapLeft = true; continue; }
    if (a === "-r" || a === "--overlap-right") { flags.overlapRight = true; continue; }
    if (a === "--js-tsconfig-paths" || a === "--js-workspaces" || a === "--python-exclude-conditional-imports") {
      flags[a.slice(2)] = true; continue;
    }
    if (a.startsWith("-")) throw new Error("unknown flag: " + a);
    positionals.push(a);
  }
  return { command, flags, positionals, help, version };
}

function printHelp(cmd) {
  const global = `Global Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)`;
  if (cmd === "tree") return console.log(`Render the dependency tree starting from the provided entrypoint

Usage:
  dep-tree tree [flags]

Flags:
  -h, --help   help for tree
      --json   render the dependency tree in a machine readable json format

${global}`);
  if (cmd === "check") return console.log(`Checks that the dependency rules defined in the configuration file are not broken

Usage:
  dep-tree check [flags]

Flags:
  -h, --help   help for check

${global}`);
  if (cmd === "explain") return console.log(`Shows all the dependencies between two parts of the code

Usage:
  dep-tree explain [flags]

Flags:
  -h, --help            help for explain
  -l, --overlap-left    When there's an overlap between the files at the left and the right, keep the ones at the left
  -r, --overlap-right   When there's an overlap between the files at the right

${global}`);
  if (cmd === "entropy") return console.log(`(default) Renders a 3d force-directed graph in the browser

Usage:
  dep-tree entropy [flags]

Flags:
      --enable-gui           Enables a GUI for changing rendering settings
  -h, --help                 help for entropy
      --no-browser-open      Disable the automatic browser open while rendering entropy
      --render-path string   Sets the output path of the rendered html file

${global}`);
  console.log(`
      ____         _ __       _
     |  _ \\   ___ |  _ \\    _| |_  _ __  ___   ___
     | | | | / _ \\| |_) |  |_   _||  __|/ _ \\ / _ \\
     | |_| ||  __/| .__/     | |  | |  |  __/|  __/
     |____/  \\__| |_|        | \\__|_|   \\___| \\___|

Usage:
  dep-tree [command]

Examples:
$ dep-tree src/index.ts
$ dep-tree entropy src/index.ts
$ dep-tree tree package/main.py --unwrap-exports
$ dep-tree check

Visualize your dependencies graphically
  entropy     (default) Renders a 3d force-directed graph in the browser
  tree        Render the dependency tree starting from the provided entrypoint

Check your dependencies against your own rules
  check       Checks that the dependency rules defined in the configuration file are not broken

Display what are the dependencies between two portions of code
  explain     Shows all the dependencies between two parts of the code

Additional Commands:
  config      Generates a sample config in case that there's not already one present
  help        Help about any command

Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
  -h, --help                                 help for dep-tree
  -v, --version                              version for dep-tree

Use "dep-tree [command] --help" for more information about a command.`);
}

function writeConfig(file) {
  if (fs.existsSync(file)) throw new Error(file + " already exists");
  fs.writeFileSync(file, SAMPLE_CONFIG, { mode: 0o600 });
}

function cmdTree(parsed) {
  const roots = parsed.positionals;
  if (!roots.length) throw new Error("requires at least 1 arg(s), only received 0");
  const graph = buildGraph(roots, parsed);
  const tree = {};
  for (const r of roots) tree[displayPath(resolveFile(r, process.cwd()) || abs(r))] = buildTree(resolveFile(r, process.cwd()) || abs(r), graph, new Set());
  const out = { tree, circularDependencies: graph.circular, errors: graph.errors };
  if (parsed.flags.json) console.log(JSON.stringify(out, null, 2));
  else console.log(renderTree(tree));
}

function cmdExplain(parsed) {
  if (parsed.positionals.length < 2) throw new Error("accepts 2 arg(s), received " + parsed.positionals.length);
  const left = listFiles([parsed.positionals[0]], parsed);
  const right = listFiles([parsed.positionals[1]], parsed);
  const lset = new Set(left), rset = new Set(right);
  if (parsed.flags.overlapLeft) for (const f of left) if (rset.has(f)) rset.delete(f);
  if (parsed.flags.overlapRight) for (const f of right) if (lset.has(f)) lset.delete(f);
  const graph = buildGraph(left, parsed, true);
  const lines = [];
  for (const from of left) for (const to of (graph.edges.get(from) || [])) if (rset.has(to)) lines.push(formatDep(from, to));
  lines.sort();
  if (lines.length) console.log(lines.join("\n"));
}

function cmdCheck(parsed) {
  const config = loadConfig(parsed.flags.config || ".dep-tree.yml");
  parsed.config = config;
  const roots = (config.check && config.check.entrypoints) || [];
  if (!roots.length) throw new Error("no entrypoints configured");
  const graph = buildGraph(roots, parsed);
  const violations = [];
  const aliases = (config.check && config.check.aliases) || {};
  for (const [from, tos] of graph.edges.entries()) {
    for (const to of tos) {
      const fd = displayPath(from), td = displayPath(to);
      let denied = false;
      for (const rule of rulesFor(config.check && config.check.deny, fd, aliases)) {
        if (rule.patterns.some(p => matchGlob(td, p))) {
          violations.push({ from: fd, to: td, reason: rule.reason });
          denied = true;
        }
      }
      if (denied) continue;
      const allowRules = rulesFor(config.check && config.check.allow, fd, aliases);
      for (const rule of allowRules) {
        if (!rule.patterns.some(p => matchGlob(td, p))) violations.push({ from: fd, to: td, reason: rule.reason });
      }
    }
  }
  if (!(config.check && config.check.allowCircularDependencies)) {
    for (const cyc of graph.circular) violations.push({ circular: cyc });
  }
  if (violations.length) {
    console.error("Error: Check failed, the following dependencies are not allowed:");
    for (const v of violations) {
      if (v.circular) console.error("- circular dependency: " + v.circular.join(" -> "));
      else {
        console.error(`- ${v.from} -> ${v.to}`);
        if (v.reason) console.error("  " + v.reason);
      }
    }
    process.exitCode = 1;
  }
}

function rulesFor(map, file, aliases) {
  const out = [];
  if (!map) return out;
  for (const [pat, val] of Object.entries(map)) {
    if (!matchGlob(file, pat)) continue;
    let reason, patterns;
    if (Array.isArray(val)) patterns = val;
    else { patterns = val.to || []; reason = val.reason; }
    const expanded = [];
    for (const p of patterns) {
      if (aliases[p]) expanded.push(...aliases[p]);
      else if (p && typeof p === "object") { expanded.push(p.to); if (!reason) reason = p.reason; }
      else expanded.push(p);
    }
    out.push({ patterns: expanded.filter(Boolean), reason });
  }
  return out;
}

function cmdEntropy(parsed) {
  const render = parsed.flags.renderPath || "dep-tree.html";
  fs.writeFileSync(render, "<!doctype html><html><head><meta charset=\"utf-8\"><title>dep-tree</title></head><body><h1>dep-tree</h1></body></html>\n");
  console.log("Rendered entropy graph at " + render);
}

function buildGraph(roots, parsed, exhaustive=false) {
  const edges = new Map(), errors = {}, circular = [];
  const queue = [];
  for (const r of roots) {
    const resolved = resolveFile(r, process.cwd());
    if (resolved) queue.push(resolved);
  }
  if (exhaustive) for (const f of roots) if (!queue.includes(f)) queue.push(f);
  const seen = new Set();
  while (queue.length) {
    const file = queue.shift();
    if (seen.has(file) || !fs.existsSync(file) || !isSource(file)) continue;
    seen.add(file);
    const deps = parseDeps(file).map(d => resolveImport(file, d)).filter(Boolean);
    edges.set(file, unique(deps).filter(f => includeFile(f, parsed)));
    for (const d of edges.get(file)) if (!seen.has(d)) queue.push(d);
  }
  for (const [f, ds] of edges.entries()) for (const d of ds) if (!edges.has(d) && fs.existsSync(d) && isSource(d)) edges.set(d, []);
  detectCycles(edges, circular);
  return { edges, errors, circular };
}

function parseDeps(file) {
  const text = safeRead(file);
  const ext = path.extname(file);
  if ([".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"].includes(ext)) return parseJs(text);
  if (ext === ".py") return parsePy(text);
  if (ext === ".go") return parseGo(text);
  if (ext === ".rs") return parseRs(text);
  return [];
}

function parseJs(s) {
  const out = [];
  let m;
  const re = /\bimport\s+(?:[^'"()]*?\s+from\s*)?["']([^"']+)["']|(?:\bexport\s+[^"']*?\s+from\s*["']([^"']+)["'])|\brequire\s*\(\s*["']([^"']+)["']\s*\)/g;
  while ((m = re.exec(s))) out.push(m[1] || m[2] || m[3]);
  return out.filter(x => x.startsWith(".") || x.startsWith("/"));
}

function parsePy(s) {
  const out = [];
  for (const line of s.split(/\n/)) {
    const t = line.trim();
    if (t.startsWith("#")) continue;
    let m = /^import\s+([A-Za-z0-9_.,\s]+)/.exec(t);
    if (m) for (const p of m[1].split(",")) out.push(p.trim().split(/\s+/)[0]);
    m = /^from\s+([.\w]+)\s+import\s+(.+)/.exec(t);
    if (m) {
      const base = m[1], names = m[2].split(",").map(x => x.trim().split(/\s+/)[0]);
      if (base.startsWith(".")) {
        if (names.length) for (const n of names) out.push(n === "*" ? base : base + (base === "." ? "" : ".") + n);
      } else {
        out.push(base);
        for (const n of names) if (/^[a-z_][A-Za-z0-9_]*$/.test(n)) out.push(base + "." + n);
      }
    }
  }
  return out;
}

function parseGo(s) {
  const out = [];
  let m;
  const block = /import\s*\(([\s\S]*?)\)/g;
  while ((m = block.exec(s))) {
    const re = /"([^"]+)"/g; let q;
    while ((q = re.exec(m[1]))) out.push(q[1]);
  }
  const single = /import\s+(?:[\w.]+\s+)?"([^"]+)"/g;
  while ((m = single.exec(s))) out.push(m[1]);
  return out;
}

function parseRs(s) {
  const out = [];
  let m;
  const re = /\b(?:pub\s+)?mod\s+([A-Za-z_][A-Za-z0-9_]*)\s*;/g;
  while ((m = re.exec(s))) out.push("mod:" + m[1]);
  return out;
}

function resolveImport(from, spec) {
  const ext = path.extname(from);
  if (ext === ".py") return resolvePy(from, spec);
  if (ext === ".go") return resolveGo(spec);
  if (ext === ".rs") return resolveRs(from, spec);
  return resolveFile(spec, path.dirname(from));
}

function resolvePy(from, spec) {
  let base;
  if (spec.startsWith(".")) {
    const dots = spec.match(/^\.+/)[0].length;
    const rest = spec.slice(dots).replace(/\./g, "/");
    base = path.resolve(path.dirname(from), "../".repeat(Math.max(0, dots - 1)), rest);
  } else {
    base = path.resolve(process.cwd(), spec.replace(/\./g, "/"));
  }
  return resolveFile(base, "/");
}

function resolveGo(spec) {
  let module = "";
  if (fs.existsSync("go.mod")) {
    const m = /module\s+(\S+)/.exec(safeRead("go.mod"));
    if (m) module = m[1];
  }
  if (module && spec.startsWith(module + "/")) spec = spec.slice(module.length + 1);
  const dir = path.resolve(process.cwd(), spec);
  if (fs.existsSync(dir) && fs.statSync(dir).isDirectory()) {
    const files = fs.readdirSync(dir).filter(f => f.endsWith(".go") && !f.endsWith("_test.go")).sort();
    if (files.length) return path.join(dir, files[0]);
  }
  return resolveFile(spec, process.cwd());
}

function resolveRs(from, spec) {
  if (!spec.startsWith("mod:")) return null;
  const name = spec.slice(4);
  const dir = path.dirname(from);
  return resolveFile(name, dir);
}

function resolveFile(spec, base) {
  let p = path.isAbsolute(spec) ? spec : path.resolve(base, spec);
  const candidates = [p];
  for (const e of [".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".py", ".go", ".rs"]) candidates.push(p + e);
  for (const e of ["index.js", "index.ts", "__init__.py", "mod.rs"]) candidates.push(path.join(p, e));
  for (const c of candidates) if (fs.existsSync(c) && fs.statSync(c).isFile()) return path.resolve(c);
  return null;
}

function listFiles(patterns, parsed) {
  const all = walk(process.cwd()).filter(isSource).filter(f => includeFile(f, parsed));
  const out = [];
  for (const p of patterns) {
    const resolved = resolveFile(p, process.cwd());
    if (resolved) out.push(resolved);
    else out.push(...all.filter(f => matchGlob(displayPath(f), p)));
  }
  return unique(out).sort((a,b) => displayPath(a).localeCompare(displayPath(b)));
}

function includeFile(file, parsed) {
  const d = displayPath(file);
  const only = [...(parsed.flags.only || []), ...((parsed.config && parsed.config.only) || [])];
  const exclude = [...(parsed.flags.exclude || []), ...((parsed.config && parsed.config.exclude) || [])];
  if (only.length && !only.some(p => matchGlob(d, p))) return false;
  if (exclude.some(p => matchGlob(d, p))) return false;
  return true;
}

function buildTree(file, graph, stack) {
  if (stack.has(file)) return null;
  const deps = graph.edges.get(file) || [];
  if (!deps.length) return null;
  const next = new Set(stack); next.add(file);
  const obj = {};
  for (const d of deps.sort((a,b)=>displayPath(a).localeCompare(displayPath(b)))) obj[displayPath(d)] = buildTree(d, graph, next);
  return obj;
}

function detectCycles(edges, circular) {
  const visiting = new Set(), visited = new Set(), stack = [];
  function dfs(n) {
    if (visiting.has(n)) {
      const i = stack.indexOf(n);
      if (i >= 0) circular.push(stack.slice(i).concat(n).map(displayPath));
      return;
    }
    if (visited.has(n)) return;
    visiting.add(n); stack.push(n);
    for (const d of edges.get(n) || []) dfs(d);
    stack.pop(); visiting.delete(n); visited.add(n);
  }
  for (const n of edges.keys()) dfs(n);
}

function renderTree(tree, indent="") {
  const lines = [];
  for (const [k, v] of Object.entries(tree)) {
    lines.push(indent + k);
    if (v) lines.push(renderTree(v, indent + "  "));
  }
  return lines.filter(Boolean).join("\n");
}

function formatDep(from, to) {
  if (path.extname(from) === ".go") return `${goPkg(from)}@${displayPath(from)} -> ${goPkg(to)}@${displayPath(to)}`;
  return `${displayPath(from)} -> ${displayPath(to)}`;
}

function goPkg(file) {
  const m = /^\s*package\s+(\w+)/m.exec(safeRead(file));
  return m ? m[1] : path.basename(path.dirname(file));
}

function displayPath(file) {
  const cwd = process.cwd();
  let r = path.relative(cwd, file);
  if (!r.startsWith("..") && !path.isAbsolute(r)) return slash(r);
  return slash(path.relative(path.dirname(cwd), file));
}

function abs(p) { return path.resolve(process.cwd(), p); }
function slash(p) { return p.split(path.sep).join("/"); }
function unique(a) { return [...new Set(a)]; }
function safeRead(f) { try { return fs.readFileSync(f, "utf8"); } catch { return ""; } }
function isSource(f) { return /\.(js|jsx|ts|tsx|mjs|cjs|py|go|rs)$/.test(f); }
function walk(dir) {
  const out = [];
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if ([".git", "node_modules", "target", "dist", "build"].includes(ent.name)) continue;
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) out.push(...walk(p));
    else out.push(p);
  }
  return out;
}

function matchGlob(file, pattern) {
  pattern = slash(String(pattern || ""));
  file = slash(file);
  let re = "";
  for (let i = 0; i < pattern.length; i++) {
    const ch = pattern[i], next = pattern[i + 1];
    if (ch === "*" && next === "*") {
      if (pattern[i + 2] === "/") { re += "(?:.*/)?"; i += 2; }
      else { re += ".*"; i++; }
    } else if (ch === "*") re += "[^/]*";
    else re += /[.+^${}()|[\]\\]/.test(ch) ? "\\" + ch : ch;
  }
  re = "^" + re + "$";
  return new RegExp(re).test(file);
}

function loadConfig(file) {
  if (!fs.existsSync(file)) throw new Error("open " + file + ": no such file or directory");
  return parseYaml(safeRead(file));
}

function parseYaml(text) {
  const rows = text.split(/\r?\n/).map((raw, idx) => {
    const noComment = raw.replace(/\s+#.*$/, "");
    return { raw: noComment, indent: noComment.match(/^ */)[0].length, text: noComment.trim(), idx };
  }).filter(r => r.text && !r.text.startsWith("#"));
  function parseBlock(start, indent) {
    const isArr = rows[start] && rows[start].indent === indent && rows[start].text.startsWith("- ");
    const value = isArr ? [] : {};
    let i = start;
    while (i < rows.length) {
      const r = rows[i];
      if (r.indent < indent) break;
      if (r.indent > indent) { i++; continue; }
      if (isArr) {
        if (!r.text.startsWith("- ")) break;
        const body = r.text.slice(2).trim();
        if (body.includes(":")) {
          const [k, v] = splitKeyVal(body);
          const obj = {};
          if (v === "") {
            const child = parseBlock(i + 1, nextIndent(i + 1, r.indent));
            obj[unquote(k)] = child.value; i = child.i;
          } else { obj[unquote(k)] = parseYamlValue(v); i++; }
          while (i < rows.length && rows[i].indent > r.indent) {
            const rr = rows[i];
            if (rr.indent !== r.indent + 2 || rr.text.startsWith("- ")) { i++; continue; }
            const [kk, vv] = splitKeyVal(rr.text);
            if (vv === "") {
              const child = parseBlock(i + 1, nextIndent(i + 1, rr.indent));
              obj[unquote(kk)] = child.value; i = child.i;
            } else { obj[unquote(kk)] = parseYamlValue(vv); i++; }
          }
          value.push(obj);
        } else { value.push(parseYamlValue(body)); i++; }
      } else {
        if (r.text.startsWith("- ")) break;
        const [k, v] = splitKeyVal(r.text);
        if (v === "") {
          const child = parseBlock(i + 1, nextIndent(i + 1, r.indent));
          value[unquote(k)] = child.value; i = child.i;
        } else { value[unquote(k)] = parseYamlValue(v); i++; }
      }
    }
    return { value, i };
  }
  function nextIndent(i, fallback) { return rows[i] ? rows[i].indent : fallback + 2; }
  return parseBlock(0, rows[0] ? rows[0].indent : 0).value;
}

function splitKeyVal(s) {
  const i = s.indexOf(":");
  if (i < 0) return [s, ""];
  return [s.slice(0, i), s.slice(i + 1).trim()];
}
function parseYamlValue(v) {
  if (v === "true") return true;
  if (v === "false") return false;
  if (v === "[]" ) return [];
  return unquote(v);
}
function unquote(s) {
  s = String(s).trim();
  if ((s.startsWith("'") && s.endsWith("'")) || (s.startsWith('"') && s.endsWith('"'))) return s.slice(1, -1);
  return s;
}
const SAMPLE_CONFIG = `# Files that should be completely ignored by dep-tree.
exclude:
  - 'some-glob-pattern/**/*.ts'

only:
  - 'some-glob-pattern/**/*.ts'

unwrapExports: false

check:
  entrypoints:
    - src/index.ts
  allowCircularDependencies: false
  allow:
    'src/products/**':
      - 'src/products/**'
      - 'src/helpers/**'
  deny:
    'src/products/**':
      - 'src/users/**'
  aliases:
    'common':
      - 'src/helpers/**'
      - 'src/utils/**'

js:
  workspaces: true
  tsConfigPaths: true

python:
  excludeConditionalImports: false

rust:
`;

main();
