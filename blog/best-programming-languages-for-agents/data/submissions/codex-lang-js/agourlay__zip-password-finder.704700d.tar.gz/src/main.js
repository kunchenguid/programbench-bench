#!/usr/bin/env node
'use strict';

const fs = require('fs');
const crypto = require('crypto');
const zlib = require('zlib');

const VERSION = 'zip-password-finder 0.10.3';
const HELP = `Find the password of protected ZIP files

Usage: executable [OPTIONS] --inputFile <inputFile>

Options:
  -i, --inputFile <inputFile>                    path to zip input file
  -w, --workers <workers>                        number of workers
  -p, --passwordDictionary <passwordDictionary>  path to a password dictionary file
  -c, --charset <charset>                        charset to use to generate password [default: lud]
      --charsetFile <charsetFile>                path to a charset file
      --minPasswordLen <minPasswordLen>          minimum password length [default: 1]
      --maxPasswordLen <maxPasswordLen>          maximum password length [default: 10]
      --fileNumber <fileNumber>                  file number in the zip archive [default: 0]
  -s, --startingPassword <startingPassword>      password to start from
  -h, --help                                     Print help
  -V, --version                                  Print version`;

function die(msg, code = 1) {
  console.error(msg);
  process.exit(code);
}

function parseArgs(argv) {
  const opts = { charset: 'lud', minPasswordLen: 1, maxPasswordLen: 10, fileNumber: 0 };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    let inlineValue = null;
    if (a.startsWith('--') && a.includes('=')) {
      const pos = a.indexOf('=');
      inlineValue = a.slice(pos + 1);
      a = a.slice(0, pos);
    }
    if (a === '-h' || a === '--help') {
      console.log(HELP);
      process.exit(0);
    }
    if (a === '-V' || a === '--version') {
      console.log(VERSION);
      process.exit(0);
    }
    const takes = {
      '-i': 'inputFile', '--inputFile': 'inputFile',
      '-w': 'workers', '--workers': 'workers',
      '-p': 'passwordDictionary', '--passwordDictionary': 'passwordDictionary',
      '-c': 'charset', '--charset': 'charset',
      '--charsetFile': 'charsetFile',
      '--minPasswordLen': 'minPasswordLen',
      '--maxPasswordLen': 'maxPasswordLen',
      '--fileNumber': 'fileNumber',
      '-s': 'startingPassword', '--startingPassword': 'startingPassword'
    };
    if (!Object.prototype.hasOwnProperty.call(takes, a)) {
      console.error(`error: unexpected argument '${a}' found\n`);
      console.error('Usage: executable [OPTIONS] --inputFile <inputFile>\n');
      console.error("For more information, try '--help'.");
      process.exit(2);
    }
    if (inlineValue === null) {
      if (i + 1 >= argv.length) die(`error: a value is required for '${a}' but none was supplied`, 2);
      inlineValue = argv[++i];
    }
    opts[takes[a]] = inlineValue;
  }
  if (!opts.inputFile) {
    console.error('error: the following required arguments were not provided:');
    console.error('  --inputFile <inputFile>\n');
    console.error('Usage: executable --inputFile <inputFile>\n');
    console.error("For more information, try '--help'.");
    process.exit(2);
  }
  for (const k of ['workers', 'minPasswordLen', 'maxPasswordLen', 'fileNumber']) {
    if (opts[k] !== undefined && typeof opts[k] === 'string') {
      if (!/^\d+$/.test(opts[k])) {
        console.error(`error: invalid value '${opts[k]}' for '--${k} <${k}>': invalid digit found in string\n`);
        console.error("For more information, try '--help'.");
        process.exit(2);
      }
      opts[k] = Number(opts[k]);
    }
  }
  if (!fs.existsSync(opts.inputFile)) die(`CLI argument error - "'inputFile' does not exist"`);
  if (opts.passwordDictionary && !fs.existsSync(opts.passwordDictionary)) die(`CLI argument error - "'passwordDictionary' does not exist"`);
  if (opts.charsetFile && !fs.existsSync(opts.charsetFile)) die(`CLI argument error - "'charsetFile' does not exist"`);
  return opts;
}

function u16(b, o) { return b.readUInt16LE(o); }
function u32(b, o) { return b.readUInt32LE(o); }

function parseZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 0x10000 - 22); i--) {
    if (u32(buf, i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('EOCD not found');
  const total = u16(buf, eocd + 10);
  let off = u32(buf, eocd + 16);
  const entries = [];
  for (let n = 0; n < total && off + 46 <= buf.length; n++) {
    if (u32(buf, off) !== 0x02014b50) break;
    const flags = u16(buf, off + 8);
    const method = u16(buf, off + 10);
    const modTime = u16(buf, off + 12);
    const crc = u32(buf, off + 16);
    const compSize = u32(buf, off + 20);
    const uncompSize = u32(buf, off + 24);
    const nameLen = u16(buf, off + 28);
    const extraLen = u16(buf, off + 30);
    const commentLen = u16(buf, off + 32);
    const localOffset = u32(buf, off + 42);
    const name = buf.slice(off + 46, off + 46 + nameLen).toString();
    const extra = buf.slice(off + 46 + nameLen, off + 46 + nameLen + extraLen);
    entries.push({ flags, method, modTime, crc, compSize, uncompSize, localOffset, name, extra });
    off += 46 + nameLen + extraLen + commentLen;
  }
  return entries;
}

function localDataOffset(buf, entry) {
  const o = entry.localOffset;
  if (u32(buf, o) !== 0x04034b50) throw new Error('Bad local header');
  return o + 30 + u16(buf, o + 26) + u16(buf, o + 28);
}

function findExtra(extra, id) {
  for (let o = 0; o + 4 <= extra.length;) {
    const hid = u16(extra, o);
    const len = u16(extra, o + 2);
    const start = o + 4;
    if (hid === id) return extra.slice(start, start + len);
    o = start + len;
  }
  return null;
}

let crcTable = null;
function makeCrcTable() {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
}
function crc32(buf) {
  if (!crcTable) crcTable = makeCrcTable();
  let c = 0xffffffff;
  for (const byte of buf) c = crcTable[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function crc32Update(c, byte) {
  if (!crcTable) crcTable = makeCrcTable();
  return (crcTable[(c ^ byte) & 0xff] ^ (c >>> 8)) >>> 0;
}

function initKeys(password) {
  const keys = { k0: 0x12345678, k1: 0x23456789, k2: 0x34567890 };
  keys.update = (byte) => {
    keys.k0 = crc32Update(keys.k0, byte);
    keys.k1 = (Math.imul((keys.k1 + (keys.k0 & 0xff)) >>> 0, 134775813) + 1) >>> 0;
    keys.k2 = crc32Update(keys.k2, keys.k1 >>> 24);
  };
  for (const byte of Buffer.from(password)) keys.update(byte);
  return keys;
}

function decryptZipCrypto(data, password) {
  const keys = initKeys(password);
  return decryptZipCryptoWithKeys(data, keys);
}

function decryptZipCryptoWithKeys(data, keys) {
  const out = Buffer.allocUnsafe(data.length);
  for (let i = 0; i < data.length; i++) {
    const temp = ((keys.k2 & 0xffff) | 2) >>> 0;
    const keyByte = ((Math.imul(temp, temp ^ 1) >>> 8) & 0xff) >>> 0;
    const plain = data[i] ^ keyByte;
    out[i] = plain;
    keys.update(plain);
  }
  return out;
}

function decryptZipCryptoHeader(data, password) {
  const keys = initKeys(password);
  const out = decryptZipCryptoWithKeys(data.slice(0, 12), keys);
  return { out, keys };
}

function checkZipCrypto(buf, entry, password) {
  const start = localDataOffset(buf, entry);
  const encrypted = buf.slice(start, start + entry.compSize);
  if (encrypted.length < 12) return false;
  const header = decryptZipCryptoHeader(encrypted, password);
  const checkByte = (entry.flags & 0x08) ? (entry.modTime >>> 8) & 0xff : (entry.crc >>> 24) & 0xff;
  if (header.out[11] !== checkByte) return false;
  const body = decryptZipCryptoWithKeys(encrypted.slice(12), header.keys);
  try {
    let plain;
    if (entry.method === 0) plain = body;
    else if (entry.method === 8) plain = zlib.inflateRawSync(body);
    else return true;
    return crc32(plain) === entry.crc >>> 0;
  } catch (_) {
    return false;
  }
}

function checkAes(buf, entry, password) {
  const extra = findExtra(entry.extra, 0x9901);
  if (!extra || extra.length < 7) return false;
  const strength = extra[4];
  const saltLen = strength === 1 ? 8 : strength === 2 ? 12 : strength === 3 ? 16 : 0;
  const keyLen = strength === 1 ? 16 : strength === 2 ? 24 : strength === 3 ? 32 : 0;
  if (!saltLen) return false;
  const start = localDataOffset(buf, entry);
  const salt = buf.slice(start, start + saltLen);
  const verifier = buf.slice(start + saltLen, start + saltLen + 2);
  if (verifier.length !== 2) return false;
  const material = crypto.pbkdf2Sync(Buffer.from(password), salt, 1000, keyLen * 2 + 2, 'sha1');
  return material.slice(keyLen * 2, keyLen * 2 + 2).equals(verifier);
}

function checkPassword(buf, entry, password) {
  if ((entry.flags & 1) === 0) return password === '';
  if (entry.method === 99 || findExtra(entry.extra, 0x9901)) return checkAes(buf, entry, password);
  return checkZipCrypto(buf, entry, password);
}

const SETS = {
  l: 'abcdefghijklmnopqrstuvwxyz',
  u: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
  d: '0123456789',
  h: '0123456789abcdef',
  H: '0123456789ABCDEF',
  s: ' !"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
};

function buildCharset(opts) {
  if (opts.charsetFile) return fs.readFileSync(opts.charsetFile, 'utf8').replace(/\r?\n/g, '');
  let out = '';
  for (const ch of opts.charset || 'lud') out += SETS[ch] || ch;
  return Array.from(new Set(Array.from(out))).join('');
}

function* brute(charset, minLen, maxLen, start) {
  const chars = Array.from(charset);
  let skipping = !!start;
  for (let len = minLen; len <= maxLen; len++) {
    if (chars.length === 0) return;
    const idx = Array(len).fill(0);
    while (true) {
      const pw = idx.map(i => chars[i]).join('');
      if (!skipping || pw === start) {
        skipping = false;
        yield pw;
      }
      let p = len - 1;
      while (p >= 0 && idx[p] === chars.length - 1) { idx[p] = 0; p--; }
      if (p < 0) break;
      idx[p]++;
    }
  }
}

function formatElapsed(ns) {
  let n = BigInt(ns);
  const sec = n / 1000000000n; n %= 1000000000n;
  const ms = n / 1000000n; n %= 1000000n;
  const us = n / 1000n; n %= 1000n;
  const parts = [];
  if (sec) parts.push(`${sec}s`);
  if (ms) parts.push(`${ms}ms`);
  if (us) parts.push(`${us}us`);
  if (n || parts.length === 0) parts.push(`${n}ns`);
  return parts.join(' ');
}

function main() {
  const startTime = process.hrtime.bigint();
  const opts = parseArgs(process.argv.slice(2));
  let buf, entries;
  try {
    buf = fs.readFileSync(opts.inputFile);
    entries = parseZip(buf);
  } catch (e) {
    die(String(e.message || e));
  }
  if (opts.fileNumber < 0 || opts.fileNumber >= entries.length) die(`File number not found within archive error - '${opts.fileNumber}'`);
  const entry = entries[opts.fileNumber];
  let found = null;
  const tryPw = (pw) => {
    if (checkPassword(buf, entry, pw)) { found = pw; return true; }
    return false;
  };

  if (opts.passwordDictionary) {
    const lines = fs.readFileSync(opts.passwordDictionary, 'utf8').split(/\r?\n/);
    for (const line of lines) {
      if (line === '' && lines.indexOf(line) === lines.length - 1) continue;
      if (tryPw(line)) break;
    }
  } else {
    const charset = buildCharset(opts);
    for (const pw of brute(charset, opts.minPasswordLen, opts.maxPasswordLen, opts.startingPassword)) {
      if (tryPw(pw)) break;
    }
  }
  console.log(`Time elapsed: ${formatElapsed(process.hrtime.bigint() - startTime)}`);
  console.log(found === null ? 'Password not found' : `Password found:${found}`);
}

main();
