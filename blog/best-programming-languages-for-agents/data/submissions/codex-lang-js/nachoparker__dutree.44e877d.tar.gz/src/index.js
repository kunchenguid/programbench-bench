#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

const HELP = `Usage: ./executable [options] <path> [<path>..]

Options:
    -d, --depth [DEPTH] show directories up to depth N (def 1)
    -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)
    -s, --summary       equivalent to -da, or -d1 -a1M
    -u, --usage         report real disk usage instead of file size
    -b, --bytes         print sizes in bytes
    -f, --files-only    skip directories for a fast local overview
    -x, --exclude NAME  exclude matching files or directories
    -H, --no-hidden     exclude hidden files
    -A, --ascii         ASCII characters only, no colors
    -h, --help          show help
    -v, --version       print version number`;

function parseSize(s) {
  if (s == null || s === '') return 1;
  const m = /^([0-9]+)([KkMmGg]?)$/.exec(s);
  if (!m) return null;
  let n = Number(m[1]);
  const unit = m[2].toUpperCase();
  if (unit === 'K') n *= 1024;
  if (unit === 'M') n *= 1024 * 1024;
  if (unit === 'G') n *= 1024 * 1024 * 1024;
  return n;
}

function parseArgs(argv) {
  const opt = {
    depth: Infinity,
    aggr: null,
    usage: false,
    bytes: false,
    filesOnly: false,
    noHidden: false,
    ascii: false,
    excludes: [],
    paths: [],
  };

  function needValue(i, name) {
    if (i + 1 >= argv.length) {
      console.error(`missing argument for '${name}'`);
      process.exit(1);
    }
    return argv[i + 1];
  }

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') {
      opt.paths.push(...argv.slice(i + 1));
      break;
    }
    if (!a.startsWith('-') || a === '-') {
      opt.paths.push(a);
      continue;
    }
    if (a === '-h' || a === '--help') {
      console.log(HELP);
      process.exit(0);
    }
    if (a === '-v' || a === '--version') {
      console.log('dutree version 0.2.18');
      process.exit(0);
    }
    if (a === '-s' || a === '--summary') {
      opt.depth = 1;
      opt.aggr = 1024 * 1024;
      continue;
    }
    if (a === '-u' || a === '--usage') { opt.usage = true; continue; }
    if (a === '-b' || a === '--bytes') { opt.bytes = true; continue; }
    if (a === '-f' || a === '--files-only') { opt.filesOnly = true; continue; }
    if (a === '-H' || a === '--no-hidden') { opt.noHidden = true; continue; }
    if (a === '-A' || a === '--ascii') { opt.ascii = true; continue; }
    if (a === '-d' || a === '--depth') {
      if (i + 1 < argv.length && /^[0-9]+$/.test(argv[i + 1])) opt.depth = Number(argv[++i]);
      else opt.depth = 1;
      continue;
    }
    if (a.startsWith('--depth=')) {
      const v = a.slice(8);
      if (!/^[0-9]+$/.test(v)) { console.error(`invalid argument '${v}'`); process.exit(1); }
      opt.depth = Number(v);
      continue;
    }
    if (a === '-a' || a === '--aggr') {
      const v = needValue(i, a);
      const n = parseSize(v);
      if (n == null) { console.error(`invalid argument '${v}'`); process.exit(1); }
      opt.aggr = n;
      i++;
      continue;
    }
    if (a.startsWith('--aggr=')) {
      const v = a.slice(7);
      const n = parseSize(v);
      if (n == null) { console.error(`invalid argument '${v}'`); process.exit(1); }
      opt.aggr = n;
      continue;
    }
    if (a === '-x' || a === '--exclude') {
      opt.excludes.push(needValue(i, a));
      i++;
      continue;
    }
    if (a.startsWith('--exclude=')) {
      opt.excludes.push(a.slice(10));
      continue;
    }
    if (/^-d[0-9]+$/.test(a)) { opt.depth = Number(a.slice(2)); continue; }
    if (/^-a[0-9]+[KkMmGg]?$/.test(a)) { opt.aggr = parseSize(a.slice(2)); continue; }
    if (a === '-da') { opt.depth = 1; opt.aggr = 1; continue; }
    if (a.length > 2 && a.startsWith('-') && !a.startsWith('--')) {
      let handled = true;
      for (const ch of a.slice(1)) {
        if (ch === 'u') opt.usage = true;
        else if (ch === 'b') opt.bytes = true;
        else if (ch === 'f') opt.filesOnly = true;
        else if (ch === 'H') opt.noHidden = true;
        else if (ch === 'A') opt.ascii = true;
        else if (ch === 's') { opt.depth = 1; opt.aggr = 1024 * 1024; }
        else { handled = false; break; }
      }
      if (handled) continue;
    }
    console.log(HELP);
    console.error(`Unrecognized option: '${a.replace(/^-+/, '')}'`);
    process.exit(1);
  }
  if (opt.paths.length === 0) opt.paths.push('.');
  return opt;
}

function baseName(p) {
  const resolved = path.basename(p.replace(/[\/]+$/, ''));
  return resolved || p;
}

function isExcluded(name, opt) {
  if (opt.noHidden && name.startsWith('.')) return true;
  return opt.excludes.some((ex) => name.includes(ex));
}

function nodeSize(st, opt) {
  return opt.usage ? Number(st.blocks || 0) * 512 : Number(st.size);
}

function scan(p, opt, isRoot = false) {
  let st;
  try {
    st = fs.lstatSync(p);
  } catch (_) {
    throw new Error(`path ${p} doesn't exist`);
  }
  const name = isRoot ? baseName(p) : path.basename(p);
  const n = { name, path: p, isDir: st.isDirectory(), size: nodeSize(st, opt), children: [], order: 0 };
  if (!st.isDirectory()) return n;

  if (opt.filesOnly && !isRoot) return n;
  let entries = [];
  try { entries = fs.readdirSync(p); } catch (_) { return n; }
  let order = 0;
  for (const ent of entries) {
    if (isExcluded(ent, opt)) continue;
    const childPath = path.join(p, ent);
    let childSt;
    try { childSt = fs.lstatSync(childPath); } catch (_) { continue; }
    if (opt.filesOnly && childSt.isDirectory()) continue;
    const child = scan(childPath, opt, false);
    child.order = order++;
    n.size += child.size;
    n.children.push(child);
  }
  n.children.sort((a, b) => (b.size - a.size) || (a.order - b.order));
  return n;
}

function human(n, bytes) {
  if (bytes) return `${n} B`;
  const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
  let v = n;
  let u = 0;
  while (v >= 1024 && u < units.length - 1) { v /= 1024; u++; }
  if (u === 0) return `${n} B`;
  return `${v.toFixed(2)} ${units[u]}`;
}

function makeBar(size, maxSize, ascii) {
  const filled = maxSize > 0 ? Math.floor((size / maxSize) * 32) : 0;
  const ch = ascii ? '#' : '█';
  return ' '.repeat(32 - filled) + ch.repeat(filled);
}

function lineFor(prefix, branch, node, parentSize, barText) {
  const label = `${prefix}${branch}${node.name}`;
  const display = label.length > 25 ? label.slice(0, 25) : label.padEnd(25, ' ');
  const pct = parentSize > 0 ? Math.floor((node.size * 100) / parentSize) : 0;
  return `${display} │ ${barText}│ ${String(pct).padStart(3)}% ${human(node.size, globalOpts.bytes).padStart(12)}`;
}

function visibleChildren(node, depth, opt) {
  let children = node.children.slice();
  if (opt.aggr != null) {
    const keep = [];
    let agg = 0;
    let firstOrder = Infinity;
    for (const c of children) {
      if (c.size < opt.aggr) {
        agg += c.size;
        firstOrder = Math.min(firstOrder, c.order);
      } else keep.push(c);
    }
    if (agg > 0) keep.push({ name: '<aggregated>', size: agg, isDir: false, children: [], order: firstOrder });
    children = keep.sort((a, b) => (b.size - a.size) || (a.order - b.order));
  }
  if (depth <= 0) return [];
  return children;
}

let globalOpts;

function printTree(root, opt) {
  globalOpts = opt;
  console.log(`[ ${root.name} ${human(root.size, opt.bytes)} ]`);

  function rec(node, prefix, depthLeft, inheritedBar = null) {
    const kids = visibleChildren(node, depthLeft, opt);
    const maxSize = kids.reduce((m, k) => Math.max(m, k.size), 0);
    kids.forEach((child, idx) => {
      const last = idx === kids.length - 1;
      const branch = last ? '└─ ' : '├─ ';
      const useBranch = opt.ascii ? branch : branch;
      const childBar = inheritedBar == null ? makeBar(child.size, maxSize, opt.ascii) : inheritedBar;
      console.log(lineFor(prefix, useBranch, child, node.size, childBar));
      if (child.children && child.children.length && depthLeft > 1) {
        rec(child, prefix + (last ? '   ' : '│  '), depthLeft - 1, childBar);
      }
    });
  }
  rec(root, '', Number.isFinite(opt.depth) ? opt.depth : 1000000);
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  let roots = [];
  try {
    roots = opt.paths.map((p) => scan(p, opt, true));
  } catch (e) {
    console.error(e.message);
    process.exit(1);
  }
  let root;
  if (roots.length === 1) root = roots[0];
  else {
    root = { name: '<collection>', size: roots.reduce((s, r) => s + r.size, 0), children: roots, isDir: true };
    roots.forEach((r, i) => { r.order = i; });
    root.children.sort((a, b) => (b.size - a.size) || (a.order - b.order));
  }
  printTree(root, opt);
}

main();
