#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "deadnix 1.3.1";
const HELP = `Find dead code in .nix files

Usage: executable [OPTIONS] [FILE_PATHS]...

Arguments:
  [FILE_PATHS]...  .nix files, or directories with .nix files inside [default: .]

Options:
  -l, --no-lambda-arg                  Don't check lambda parameter arguments
  -L, --no-lambda-pattern-names        Don't check lambda attrset pattern names (don't break nixpkgs callPackage)
  -_, --no-underscore                  Don't check any bindings that start with a _
                                       (Lambda arguments starting with _ are not checked anyway.)
  -W, --warn-used-underscore           Warn if bindings are referenced that start with '_'
  -q, --quiet                          Don't print dead code report
  -e, --edit                           Remove unused code and write to source file
  -h, --hidden                         Recurse into hidden subdirectories and process hidden .*.nix files
      --help                           
  -f, --fail                           Exit with 1 if unused code has been found
  -o, --output-format <OUTPUT_FORMAT>  Output format to use [default: human-readable] [possible values: human-readable, json]
      --exclude <EXCLUDES>...          Files to exclude from analysis
  -V, --version                        Print version`;

const KEYWORDS = new Set(["let", "in", "rec", "inherit", "with", "if", "then", "else", "assert", "or", "true", "false", "null"]);

function usageError(msg) {
  console.error(`error: ${msg}\n\nUsage: executable [OPTIONS] [FILE_PATHS]...\n\nFor more information, try '--help'.`);
  process.exit(2);
}

function parseArgs(argv) {
  const opt = {
    lambdaArg: true,
    lambdaPattern: true,
    underscore: true,
    warnUsedUnderscore: false,
    quiet: false,
    edit: false,
    hidden: false,
    fail: false,
    format: "human-readable",
    excludes: [],
    paths: [],
  };
  let positional = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (positional) {
      opt.paths.push(a);
    } else if (a === "--") {
      positional = true;
    } else if (a === "--help") {
      console.log(HELP);
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      console.log(VERSION);
      process.exit(0);
    } else if (a === "-l" || a === "--no-lambda-arg") opt.lambdaArg = false;
    else if (a === "-L" || a === "--no-lambda-pattern-names") opt.lambdaPattern = false;
    else if (a === "-_") opt.underscore = false;
    else if (a === "--no-underscore") opt.underscore = false;
    else if (a === "-W" || a === "--warn-used-underscore") opt.warnUsedUnderscore = true;
    else if (a === "-q" || a === "--quiet") opt.quiet = true;
    else if (a === "-e" || a === "--edit") opt.edit = true;
    else if (a === "-h" || a === "--hidden") opt.hidden = true;
    else if (a === "-f" || a === "--fail") opt.fail = true;
    else if (a === "-o" || a === "--output-format") {
      const v = argv[++i];
      if (!v) usageError("a value is required for '--output-format <OUTPUT_FORMAT>'");
      if (v !== "human-readable" && v !== "json") {
        console.error(`error: invalid value '${v}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human-readable, json]\n\nFor more information, try '--help'.`);
        process.exit(2);
      }
      opt.format = v;
    } else if (a === "--exclude") {
      while (argv[i + 1] && !argv[i + 1].startsWith("-")) opt.excludes.push(argv[++i]);
    } else if (a.startsWith("-")) {
      usageError(`unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'`);
    } else opt.paths.push(a);
  }
  if (opt.paths.length === 0) opt.paths.push(".");
  return opt;
}

function collectFiles(inputs, opt) {
  const out = [];
  const excludes = opt.excludes.map((e) => path.resolve(e));
  function excluded(p) {
    const r = path.resolve(p);
    return excludes.some((e) => r === e || r.startsWith(e + path.sep));
  }
  function walk(p) {
    if (excluded(p)) return;
    let st;
    try { st = fs.statSync(p); } catch { return; }
    const base = path.basename(p);
    if (!opt.hidden && base.startsWith(".") && p !== ".") return;
    if (st.isDirectory()) {
      const ents = fs.readdirSync(p).sort();
      const scored = ents.map((ent) => {
        const full = path.join(p, ent);
        let isDir = false;
        try { isDir = fs.statSync(full).isDirectory(); } catch {}
        const hidden = ent.startsWith(".");
        return { ent, full, score: (isDir ? 2 : 0) + (hidden ? 1 : 0) };
      }).sort((a, b) => a.score - b.score || a.ent.localeCompare(b.ent));
      for (const ent of scored) walk(ent.full);
    } else if (st.isFile() && p.endsWith(".nix")) out.push(p);
  }
  for (const p of inputs) walk(p);
  return out;
}

function maskStrings(src) {
  const a = src.split("");
  for (let i = 0; i < a.length; i++) {
    if (a[i] === '"') {
      a[i] = " ";
      i++;
      while (i < a.length) {
        if (a[i] === "\\" && i + 1 < a.length) { a[i] = " "; a[++i] = " "; i++; continue; }
        if (a[i] === "$" && a[i + 1] === "{") {
          i += 2;
          let depth = 1;
          while (i < a.length && depth > 0) {
            if (a[i] === "{") depth++;
            else if (a[i] === "}") depth--;
            i++;
          }
          continue;
        }
        const q = a[i] === '"';
        a[i] = a[i] === "\n" ? "\n" : " ";
        if (q) break;
        i++;
      }
    } else if (a[i] === "'" && a[i + 1] === "'") {
      a[i] = " "; a[i + 1] = " "; i += 2;
      while (i < a.length) {
        if (a[i] === "$" && a[i + 1] === "{") {
          i += 2;
          let depth = 1;
          while (i < a.length && depth > 0) {
            if (a[i] === "{") depth++;
            else if (a[i] === "}") depth--;
            i++;
          }
          continue;
        }
        const end = a[i] === "'" && a[i + 1] === "'";
        a[i] = a[i] === "\n" ? "\n" : " ";
        if (end) { a[i + 1] = " "; i++; break; }
        i++;
      }
    }
  }
  return a.join("");
}

function tokenize(src) {
  src = maskStrings(src);
  const t = [];
  let i = 0, line = 1, col = 1;
  const adv = (s) => { for (const ch of s) { if (ch === "\n") { line++; col = 1; } else col++; } i += s.length; };
  const add = (type, value, start, startLine, startCol) => t.push({ type, value, start, end: i, line: startLine, col: startCol });
  while (i < src.length) {
    const ch = src[i];
    if (/\s/.test(ch)) { adv(ch); continue; }
    if (ch === "#") { while (i < src.length && src[i] !== "\n") adv(src[i]); continue; }
    const start = i, sl = line, sc = col;
    if (/[A-Za-z_]/.test(ch)) {
      let s = ch; adv(ch);
      while (i < src.length && /[A-Za-z0-9_'-]/.test(src[i])) { s += src[i]; adv(src[i]); }
      add(KEYWORDS.has(s) ? "kw" : "id", s, start, sl, sc);
      continue;
    }
    if (ch === "." && src.slice(i, i + 3) === "...") { adv("..."); add("sym", "...", start, sl, sc); continue; }
    adv(ch); add("sym", ch, start, sl, sc);
  }
  return t;
}

function lineStarts(src) {
  const starts = [0];
  for (let i = 0; i < src.length; i++) if (src[i] === "\n") starts.push(i + 1);
  return starts;
}

function posToLineCol(starts, idx) {
  let lo = 0, hi = starts.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (starts[mid] <= idx) lo = mid + 1; else hi = mid - 1;
  }
  const line = hi + 1;
  return { line, column: idx - starts[hi] + 1 };
}

function matching(tokens) {
  const pairs = new Map(), stack = [];
  const opens = { "(": ")", "{": "}", "[": "]" };
  const closes = new Set(Object.values(opens));
  tokens.forEach((tok, i) => {
    if (tok.type === "sym" && opens[tok.value]) stack.push([tok.value, i]);
    else if (tok.type === "sym" && closes.has(tok.value)) {
      for (let j = stack.length - 1; j >= 0; j--) {
        if (opens[stack[j][0]] === tok.value) {
          const oi = stack[j][1];
          pairs.set(oi, i); pairs.set(i, oi);
          stack.splice(j, 1);
          break;
        }
      }
    }
  });
  return pairs;
}

function isSkipped(lines, line) {
  return line > 1 && /deadnix:\s*skip/.test(lines[line - 2]);
}

function analyze(src, opt) {
  const tokens = tokenize(src);
  const pairs = matching(tokens);
  const starts = lineStarts(src);
  const lines = src.split(/\n/);
  const decls = [];
  const refs = [];
  let order = 0;
  function addDecl(tok, kind, scopeStart, scopeEnd) {
    if (!tok || tok.type !== "id") return;
    if (!opt.underscore && tok.value.startsWith("_")) return;
    if (isSkipped(lines, tok.line)) return;
    decls.push({ name: tok.value, kind, tok, scopeStart, scopeEnd, used: false, order: order++ });
  }
  for (let i = 0; i < tokens.length; i++) if (tokens[i].type === "id") refs.push({ name: tokens[i].value, tok: tokens[i], idx: i });

  function findLetIn(i, end) {
    let depth = 0;
    for (let j = i + 1; j < end; j++) {
      const tok = tokens[j];
      if (tok.type === "kw" && tok.value === "let") depth++;
      else if (tok.type === "kw" && tok.value === "in") {
        if (depth === 0) return j;
        depth--;
      }
    }
    return -1;
  }
  function scanLet(i, end) {
    const inIdx = findLetIn(i, end);
    if (inIdx < 0) return;
    let depth = 0;
    for (let j = i + 1; j < inIdx; j++) {
      const tok = tokens[j];
      if (tok.type === "sym" && "({[".includes(tok.value)) depth++;
      else if (tok.type === "sym" && ")}]".includes(tok.value)) depth = Math.max(0, depth - 1);
      else if (tok.type === "kw" && tok.value === "inherit" && depth === 0) {
        let k = j + 1;
        if (tokens[k] && tokens[k].value === "(") k = (pairs.get(k) ?? k) + 1;
        for (; k < inIdx && tokens[k] && tokens[k].value !== ";"; k++) {
          if (tokens[k].type === "id") addDecl(tokens[k], "let binding", i + 1, end);
        }
        j = k;
      } else if (tok.type === "id" && depth === 0) {
        let k = j + 1;
        while (tokens[k] && tokens[k].value === ".") k += 2;
        if (tokens[k] && tokens[k].value === "=") addDecl(tok, "let binding", i + 1, end);
      }
    }
  }
  for (let i = 0; i < tokens.length; i++) if (tokens[i].type === "kw" && tokens[i].value === "let") scanLet(i, tokens.length);

  function scanLambdaAt(colonIdx) {
    const prev = tokens[colonIdx - 1];
    if (!prev) return;
    let open = -1, close = -1, atName = null;
    const lambdaEnd = (() => {
      if (tokens[colonIdx + 1] && tokens[colonIdx + 1].type === "kw" && tokens[colonIdx + 1].value === "let") return tokens.length;
      let depth = 0;
      for (let k = colonIdx + 1; k < tokens.length; k++) {
        const v = tokens[k].value;
        if (["(", "{", "["].includes(v)) depth++;
        else if ([")", "}", "]"].includes(v)) {
          if (depth === 0) return k - 1;
          depth--;
        } else if (depth === 0 && (v === ";" || v === ",")) return k - 1;
      }
      return tokens.length;
    })();
    if ((prev.value === "}" && pairs.has(colonIdx - 1)) ||
        (prev.type === "id" && tokens[colonIdx - 2] && tokens[colonIdx - 2].value === "@" &&
         tokens[colonIdx - 3] && tokens[colonIdx - 3].value === "}" && pairs.has(colonIdx - 3))) {
      close = prev.value === "}" ? colonIdx - 1 : colonIdx - 3;
      open = pairs.get(close);
      if (tokens[open - 2] && tokens[open - 1] && tokens[open - 1].value === "@" && tokens[open - 2].type === "id") atName = tokens[open - 2];
      if (tokens[close + 1] && tokens[close + 1].value === "@" && tokens[close + 2] && tokens[close + 2].type === "id") atName = tokens[close + 2];
      if (opt.lambdaPattern) {
        let pdepth = 0;
        for (let k = open + 1; k < close; k++) {
          if (["(", "{", "["].includes(tokens[k].value)) pdepth++;
          else if ([")", "}", "]"].includes(tokens[k].value)) pdepth = Math.max(0, pdepth - 1);
          if (pdepth === 0 && tokens[k].type === "id" && tokens[k - 1] && ["{", ","].includes(tokens[k - 1].value) && tokens[k + 1] && [",", "?", "}"].includes(tokens[k + 1].value)) {
            if (!tokens[k].value.startsWith("_")) addDecl(tokens[k], "lambda pattern", open + 1, lambdaEnd);
          }
        }
        if (atName && !atName.value.startsWith("_")) addDecl(atName, "lambda pattern", open + 1, lambdaEnd);
      }
    } else if (prev.type === "id" && opt.lambdaArg && !prev.value.startsWith("_")) {
      addDecl(prev, "lambda argument", colonIdx + 1, lambdaEnd);
    }
  }
  for (let i = 0; i < tokens.length; i++) if (tokens[i].value === ":") scanLambdaAt(i);

  const declStarts = new Set(decls.map((d) => d.tok.start));
  for (const r of refs) {
    if (declStarts.has(r.tok.start)) continue;
    let best = null;
    for (const d of decls) {
      if (d.name !== r.name) continue;
      if (r.tok.start === d.tok.start) continue;
      if (r.idx < d.scopeStart || r.idx > d.scopeEnd) continue;
      if (!best || d.scopeStart >= best.scopeStart) best = d;
    }
    if (best) best.used = true;
  }

  const results = [];
  for (const d of decls.sort((a, b) => a.tok.start - b.tok.start)) {
    if (d.used) continue;
    const p = posToLineCol(starts, d.tok.start);
    const e = posToLineCol(starts, d.tok.end);
    results.push({ column: p.column, endColumn: e.column, line: p.line, message: `Unused ${d.kind}: ${d.name}` });
  }
  if (opt.warnUsedUnderscore) {
    for (const r of refs) if (r.name.startsWith("_")) {
      const p = posToLineCol(starts, r.tok.start), e = posToLineCol(starts, r.tok.end);
      results.push({ column: p.column, endColumn: e.column, line: p.line, message: `Used underscore-prefixed binding: ${r.name}` });
    }
  }
  results.sort((a, b) => a.line - b.line || a.column - b.column || a.message.localeCompare(b.message));
  return results;
}

function renderHuman(file, results, src) {
  if (!results.length) return "";
  const lines = src.split(/\n/);
  let s = `${process.env.NO_COLOR ? "Warning:" : "\x1b[33mWarning:\x1b[0m"} Unused declarations were found.\n`;
  s += `    ╭─[${file}:${results[0].line}:1]\n`;
  const byLine = new Map();
  for (const r of results) { if (!byLine.has(r.line)) byLine.set(r.line, []); byLine.get(r.line).push(r); }
  for (const [ln, rs] of byLine) {
    s += `${String(ln).padStart(3)} │${lines[ln - 1] ?? ""}\n`;
    for (const r of rs) s += `    │${" ".repeat(Math.max(0, r.column - 1))}╰${"─".repeat(Math.max(1, r.endColumn - r.column - 1))} ${r.message}\n`;
  }
  return s.replace(/\n$/, "");
}

function editFile(file, results) {
  if (!results.length) return;
  let lines = fs.readFileSync(file, "utf8").split(/\n/);
  const removeLines = new Set(results.filter((r) => r.message.startsWith("Unused let binding:")).map((r) => r.line));
  lines = lines.filter((_, i) => !removeLines.has(i + 1));
  fs.writeFileSync(file, lines.join("\n"));
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  const files = collectFiles(opt.paths, opt);
  let any = false;
  for (const file of files) {
    const src = fs.readFileSync(file, "utf8");
    const results = analyze(src, opt);
    if (results.length) any = true;
    if (opt.edit) editFile(file, results);
    if (!opt.quiet && results.length) {
      if (opt.format === "json") console.log(JSON.stringify({ file, results }));
      else console.log(renderHuman(file, results, src));
    }
  }
  process.exit(any && opt.fail ? 1 : 0);
}

main();
