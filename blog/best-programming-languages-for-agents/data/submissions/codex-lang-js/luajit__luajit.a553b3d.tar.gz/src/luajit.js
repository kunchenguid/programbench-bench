#!/usr/bin/env node
"use strict";
const fs = require("fs");
const path = require("path");

const VERSION = "LuaJIT 2.1.1772570160 -- Copyright (C) 2005-2026 Mike Pall. https://luajit.org/";
const HELP = `usage: ./executable [options]... [script [args]...].
Available options are:
  -e chunk  Execute string 'chunk'.
  -l name   Require library 'name'.
  -b ...    Save or list bytecode.
  -j cmd    Perform LuaJIT control command.
  -O[opt]   Control LuaJIT optimizations.
  -i        Enter interactive mode after executing 'script'.
  -v        Show version information.
  -E        Ignore environment variables.
  --        Stop handling options.
  -         Execute stdin and stop handling options.`;

class LuaError extends Error { constructor(msg) { super(msg); this.name = "LuaError"; } }
class ReturnSignal { constructor(values) { this.values = values; } }
class BreakSignal {}

class LuaTable {
  constructor(init) { this.map = new Map(); if (init) for (const [k, v] of init) this.set(k, v); }
  key(k) { return typeof k + ":" + String(k); }
  get(k) { return this.map.get(this.key(k)); }
  set(k, v) { const kk = this.key(k); if (v === null || v === undefined) this.map.delete(kk); else this.map.set(kk, v); }
  len() { let n = 0; while (this.get(n + 1) !== undefined) n++; return n; }
  entries() { const out = []; for (const [kk, v] of this.map) { const p = kk.indexOf(":"); let t = kk.slice(0, p), s = kk.slice(p + 1); out.push([t === "number" ? Number(s) : t === "boolean" ? s === "true" : s, v]); } return out; }
}
const NIL = undefined;
const isTruthy = v => v !== undefined && v !== false;
const luaType = v => v === undefined ? "nil" : v instanceof LuaTable ? "table" : v && v.__luaFunction ? "function" : typeof v === "number" ? "number" : typeof v === "string" ? "string" : typeof v === "boolean" ? "boolean" : typeof v === "function" ? "function" : "userdata";
const toLuaString = v => v === undefined ? "nil" : v === true ? "true" : v === false ? "false" : v instanceof LuaTable ? `table: 0x${(v._id ||= (++toLuaString.id)).toString(16).padStart(8,"0")}` : String(v);
toLuaString.id = 1000;
const num = v => { if (typeof v === "number") return v; const n = Number(v); if (!Number.isNaN(n)) return n; throw new LuaError("attempt to perform arithmetic on a " + luaType(v) + " value"); };

class Env {
  constructor(parent=null) { this.parent = parent; this.vars = Object.create(null); }
  define(k,v) { this.vars[k]=v; }
  hasLocal(k) { return Object.prototype.hasOwnProperty.call(this.vars,k); }
  get(k) { if (this.hasLocal(k)) return this.vars[k]; if (this.parent) return this.parent.get(k); return undefined; }
  set(k,v) { if (this.hasLocal(k)) this.vars[k]=v; else if (this.parent) this.parent.set(k,v); else this.vars[k]=v; }
}

class Lexer {
  constructor(src) { this.s=src.replace(/^\uFEFF/,""); this.i=0; this.tokens=[]; this.lex(); this.tokens.push({t:"eof",v:"<eof>",line:this.line}); this.p=0; }
  peek(n=0){return this.s[this.i+n];}
  adv(){return this.s[this.i++];}
  lex() {
    this.line=1; const kw = new Set("and break do else elseif end false for function if in local nil not or repeat return then true until while".split(" "));
    while (this.i < this.s.length) {
      let c=this.peek();
      if (c===" "||c==="\t"||c==="\r"||c==="\f"||c==="\v") { this.i++; continue; }
      if (c==="\n") { this.line++; this.i++; continue; }
      if (c==="-" && this.peek(1)==="-") { this.i+=2; if (this.peek()==="[" && this.peek(1)==="[") this.longString(true); else while (this.i<this.s.length && this.peek()!=="\n") this.i++; continue; }
      if (/[A-Za-z_]/.test(c)) { let st=this.i++; while (/[A-Za-z0-9_]/.test(this.peek()||"")) this.i++; let v=this.s.slice(st,this.i); this.tokens.push({t:kw.has(v)?v:"name",v,line:this.line}); continue; }
      if (/[0-9]/.test(c) || (c==="." && /[0-9]/.test(this.peek(1)||""))) { let st=this.i++; if (c==="0" && (this.peek()==="x"||this.peek()==="X")) { this.i++; while (/[0-9A-Fa-f.]/.test(this.peek()||"")) this.i++; } else { while (/[0-9.]/.test(this.peek()||"")) this.i++; if ((this.peek()==="e"||this.peek()==="E")) { this.i++; if (this.peek()==="+"||this.peek()==="-") this.i++; while (/[0-9]/.test(this.peek()||"")) this.i++; } } this.tokens.push({t:"number",v:Number(this.s.slice(st,this.i)),line:this.line}); continue; }
      if (c==="'" || c === '"') { this.tokens.push({t:"string",v:this.string(),line:this.line}); continue; }
      if (c==="[" && this.peek(1)==="[") { this.tokens.push({t:"string",v:this.longString(false),line:this.line}); continue; }
      let two=this.s.slice(this.i,this.i+2), three=this.s.slice(this.i,this.i+3);
      if (three==="...") { this.i+=3; this.tokens.push({t:"...",v:"...",line:this.line}); continue; }
      if (["==","~=","<=",">=",".."].includes(two)) { this.i+=2; this.tokens.push({t:two,v:two,line:this.line}); continue; }
      this.i++; this.tokens.push({t:c,v:c,line:this.line});
    }
  }
  string(){ const q=this.adv(); let r=""; while(this.i<this.s.length){ let c=this.adv(); if(c===q) return r; if(c==="\\"){ let e=this.adv(); const m={n:"\n",r:"\r",t:"\t",a:"\x07",b:"\b",f:"\f",v:"\v","\\":"\\",'"':'"',"'":"'"}; if(/[0-9]/.test(e)){ let ds=e; for(let k=0;k<2&&/[0-9]/.test(this.peek()||"");k++) ds+=this.adv(); r+=String.fromCharCode(Number(ds)); } else r+=m[e]!==undefined?m[e]:e; } else { if(c==="\n") this.line++; r+=c; }} throw new LuaError("unfinished string near '<eof>'"); }
  longString(skip){ this.i+=2; let st=this.i, end=this.s.indexOf("]]",this.i); if(end<0) end=this.s.length; this.i=end+2; const val=this.s.slice(st,end); this.line += (val.match(/\n/g)||[]).length; return skip?undefined:val; }
  tok(){return this.tokens[this.p];}
  next(){return this.tokens[this.p++];}
  eat(t){ if(this.tok().t===t){this.p++; return true;} return false; }
  expect(t){ const x=this.next(); if(x.t!==t) throw new LuaError(`unexpected symbol near '${x.v}'`); return x; }
}

class Parser {
  constructor(src){ this.l=new Lexer(src); }
  parse(){ return {type:"block", body:this.block(new Set(["eof"]))}; }
  block(until){ const b=[]; while(!until.has(this.l.tok().t)){ if(this.l.eat(";")) continue; b.push(this.stat()); } return b; }
  stat(){ const t=this.l.tok().t;
    if(t==="local"){ this.l.next(); if(this.l.eat("function")){ const n=this.l.expect("name").v; return {type:"localfunc",name:n,func:this.funcbody()}; } const names=[this.l.expect("name").v]; while(this.l.eat(",")) names.push(this.l.expect("name").v); let ex=[]; if(this.l.eat("=")) ex=this.explist(); return {type:"local",names,ex}; }
    if(t==="function"){ this.l.next(); const v=this.varname(); return {type:"funcassign",v,func:this.funcbody(v.method)}; }
    if(t==="if"){ this.l.next(); const clauses=[]; clauses.push([this.exp(), (this.l.expect("then"), this.block(new Set(["elseif","else","end"])))]); while(this.l.eat("elseif")) clauses.push([this.exp(), (this.l.expect("then"), this.block(new Set(["elseif","else","end"])))]); let els=[]; if(this.l.eat("else")) els=this.block(new Set(["end"])); this.l.expect("end"); return {type:"if",clauses,els}; }
    if(t==="while"){ this.l.next(); const e=this.exp(); this.l.expect("do"); const body=this.block(new Set(["end"])); this.l.expect("end"); return {type:"while",e,body}; }
    if(t==="do"){ this.l.next(); const body=this.block(new Set(["end"])); this.l.expect("end"); return {type:"do",body}; }
    if(t==="repeat"){ this.l.next(); const body=this.block(new Set(["until"])); this.l.expect("until"); return {type:"repeat",body,e:this.exp()}; }
    if(t==="for"){ this.l.next(); const n=this.l.expect("name").v; if(this.l.eat("=")){ const a=this.exp(); this.l.expect(","); const b=this.exp(); let c={type:"num",v:1}; if(this.l.eat(",")) c=this.exp(); this.l.expect("do"); const body=this.block(new Set(["end"])); this.l.expect("end"); return {type:"fornum",n,a,b,c,body}; } const names=[n]; while(this.l.eat(",")) names.push(this.l.expect("name").v); this.l.expect("in"); const ex=this.explist(); this.l.expect("do"); const body=this.block(new Set(["end"])); this.l.expect("end"); return {type:"forin",names,ex,body}; }
    if(t==="return"){ this.l.next(); return {type:"return",ex:this.l.tok().t==="end"||this.l.tok().t==="eof"?[]:this.explist()}; }
    if(t==="break"){ this.l.next(); return {type:"break"}; }
    const first=this.suffixed(); if(first.type==="call") return {type:"callstat",call:first}; const vars=[first]; while(this.l.eat(",")) vars.push(this.suffixed()); this.l.expect("="); return {type:"assign",vars,ex:this.explist()};
  }
  varname(){ let v={type:"var",name:this.l.expect("name").v}; while(this.l.tok().t==="."||this.l.tok().t===":"){ const sep=this.l.next().t, n=this.l.expect("name").v; v={type:"index",obj:v,key:{type:"str",v:n}}; if(sep===":"){ v.method=n; break; } } return v; }
  funcbody(method){ this.l.expect("("); const params=[]; let vararg=false; if(!this.l.eat(")")){ if(method) params.push("self"); do { if(this.l.eat("...")) { vararg=true; break; } params.push(this.l.expect("name").v); } while(this.l.eat(",")); this.l.expect(")"); } const body=this.block(new Set(["end"])); this.l.expect("end"); return {type:"func",params,vararg,body}; }
  explist(){ const a=[this.exp()]; while(this.l.eat(",")) a.push(this.exp()); return a; }
  exp(p=0){ const prec={or:1,and:2,"==":3,"~=":3,"<":3,">":3,"<=":3,">=":3,"..":4,"+":5,"-":5,"*":6,"/":6,"%":6,"^":8}; let e; const t=this.l.tok().t; if(t==="not"||t==="#"||t==="-"){ this.l.next(); e={type:"un",op:t,e:this.exp(7)}; } else e=this.primary();
    while(true){ const op=this.l.tok().t, pr=prec[op]; if(!pr||pr<=p) break; this.l.next(); e={type:"bin",op,a:e,b:this.exp(op==="^"||op===".." ? pr-1 : pr)}; } return e; }
  primary(){ const t=this.l.next(); if(t.t==="number") return {type:"num",v:t.v}; if(t.t==="string") return {type:"str",v:t.v}; if(t.t==="nil") return {type:"nil"}; if(t.t==="true"||t.t==="false") return {type:"bool",v:t.t==="true"}; if(t.t==="...") return {type:"vararg"}; if(t.t==="function") return this.funcbody(); if(t.t==="{") return this.table(); if(t.t==="("){ const e=this.exp(); this.l.expect(")"); return this.suffix(e); } if(t.t==="name") return this.suffix({type:"var",name:t.v}); throw new LuaError(`unexpected symbol near '${t.v}'`); }
  table(){ const fields=[]; let idx=1; if(!this.l.eat("}")){ do { if(this.l.eat("[")){ const k=this.exp(); this.l.expect("]"); this.l.expect("="); fields.push([k,this.exp()]); } else if(this.l.tok().t==="name" && this.l.tokens[this.l.p+1]?.t==="="){ const k={type:"str",v:this.l.next().v}; this.l.expect("="); fields.push([k,this.exp()]); } else fields.push([{type:"num",v:idx++},this.exp()]); } while(this.l.eat(",")||this.l.eat(";")); this.l.expect("}"); } return {type:"table",fields}; }
  suffixed(){ return this.suffix(this.primaryNoSuffix()); }
  primaryNoSuffix(){ const t=this.l.next(); if(t.t==="name") return {type:"var",name:t.v}; if(t.t==="("){ const e=this.exp(); this.l.expect(")"); return e; } throw new LuaError(`unexpected symbol near '${t.v}'`); }
  suffix(e){ while(true){ if(this.l.eat(".")) e={type:"index",obj:e,key:{type:"str",v:this.l.expect("name").v}}; else if(this.l.eat("[")){ e={type:"index",obj:e,key:this.exp()}; this.l.expect("]"); } else if(this.l.eat(":")){ const m=this.l.expect("name").v; e=this.call({type:"index",obj:e,key:{type:"str",v:m}},m); } else if(["(","{","string"].includes(this.l.tok().t)) e=this.call(e,null); else break; } return e; }
  call(fn,method){ let args=[]; if(this.l.eat("(")){ if(!this.l.eat(")")){ args=this.explist(); this.l.expect(")"); } } else if(this.l.tok().t==="string") args=[{type:"str",v:this.l.next().v}]; else args=[this.tableAfterOpen()]; return {type:"call",fn,args,method}; }
  tableAfterOpen(){ this.l.expect("{"); return this.table(); }
}

function makeFunc(ast, env) {
  const f = function(args) { const e=new Env(env); ast.params.forEach((p,i)=>e.define(p,args[i])); e.define("arg", new LuaTable(args.slice(ast.params.length).map((v,i)=>[i+1,v]))); e.define("...", args.slice(ast.params.length)); try { execBlock(ast.body,e); } catch(x) { if(x instanceof ReturnSignal) return x.values; throw x; } return []; };
  f.__luaFunction = true; return f;
}
function vals(ex, env){ const out=[]; ex.forEach((e,i)=>{ const v=evalExp(e,env); if(i===ex.length-1 && Array.isArray(v)&&v.__multi) out.push(...v); else out.push(Array.isArray(v)&&v.__multi?v[0]:v); }); return out; }
function multi(a){ a.__multi=true; return a; }
function evalExp(e, env){ switch(e.type){
  case "num":case "str":case "bool": return e.v; case "nil": return undefined; case "var": return env.get(e.name); case "vararg": { const v=env.get("...")||[]; return multi(v.slice()); }
  case "table": { const t=new LuaTable(); for(const [k,v] of e.fields) t.set(evalExp(k,env), evalExp(v,env)); return t; }
  case "func": return makeFunc(e,env); case "index": { const o=evalExp(e.obj,env), k=evalExp(e.key,env); if (o instanceof LuaTable) return o.get(k); if (typeof o === "string") { const st = env.get("string"); if (st instanceof LuaTable) return st.get(k); } return o && o[k]; }
  case "un": { const v=evalExp(e.e,env); if(e.op==="not") return !isTruthy(v); if(e.op==="#") return v instanceof LuaTable ? v.len() : String(v??"").length; if(e.op==="-") return -num(v); }
  case "bin": { if(e.op==="and"){ const a=evalExp(e.a,env); return isTruthy(a)?evalExp(e.b,env):a; } if(e.op==="or"){ const a=evalExp(e.a,env); return isTruthy(a)?a:evalExp(e.b,env); } const a=evalExp(e.a,env), b=evalExp(e.b,env); if(e.op==="+") return num(a)+num(b); if(e.op==="-") return num(a)-num(b); if(e.op==="*") return num(a)*num(b); if(e.op==="/") return num(a)/num(b); if(e.op==="%") return num(a)%num(b); if(e.op==="^") return Math.pow(num(a),num(b)); if(e.op==="..") return toLuaString(a)+toLuaString(b); if(e.op==="==") return a===b; if(e.op==="~=") return a!==b; if(e.op==="<") return a<b; if(e.op===">") return a>b; if(e.op==="<=") return a<=b; if(e.op===">=") return a>=b; }
  case "call": return multi(call(e,env));
} }
function assign(v, val, env){ if(v.type==="var") env.set(v.name,val); else if(v.type==="index"){ const o=evalExp(v.obj,env), k=evalExp(v.key,env); if(o instanceof LuaTable) o.set(k,val); else o[k]=val; } else throw new LuaError("syntax error"); }
function call(c, env){ let fn=evalExp(c.fn,env); let args=vals(c.args,env); if(c.method && c.fn.type==="index") args.unshift(evalExp(c.fn.obj,env)); if(fn && fn.__luaFunction) return fn(args); if(typeof fn==="function") { const r=fn(...args); return Array.isArray(r)&&r.__multi ? r : (Array.isArray(r)?r:[r]); } throw new LuaError("attempt to call a " + luaType(fn) + " value"); }
function execBlock(body, env){ for(const s of body) exec(s,env); }
function exec(s, env){ switch(s.type){
  case "local": { const vs=vals(s.ex,env); s.names.forEach((n,i)=>env.define(n,vs[i])); break; }
  case "localfunc": env.define(s.name,undefined); env.set(s.name,makeFunc(s.func,env)); break;
  case "funcassign": assign(s.v,makeFunc(s.func,env),env); break;
  case "assign": { const vs=vals(s.ex,env); s.vars.forEach((v,i)=>assign(v,vs[i],env)); break; }
  case "callstat": call(s.call,env); break;
  case "return": throw new ReturnSignal(vals(s.ex,env));
  case "break": throw new BreakSignal();
  case "if": { for(const [c,b] of s.clauses) if(isTruthy(evalExp(c,env))){ execBlock(b,new Env(env)); return; } if(s.els.length) execBlock(s.els,new Env(env)); break; }
  case "do": execBlock(s.body,new Env(env)); break;
  case "while": while(isTruthy(evalExp(s.e,env))) { try{ execBlock(s.body,new Env(env)); } catch(x){ if(x instanceof BreakSignal) break; throw x; } } break;
  case "repeat": do { try{ execBlock(s.body,new Env(env)); } catch(x){ if(x instanceof BreakSignal) break; throw x; } } while(!isTruthy(evalExp(s.e,env))); break;
  case "fornum": { const step=num(evalExp(s.c,env)); for(let i=num(evalExp(s.a,env)), lim=num(evalExp(s.b,env)); step>=0?i<=lim:i>=lim; i+=step){ const e=new Env(env); e.define(s.n,i); try{execBlock(s.body,e);}catch(x){if(x instanceof BreakSignal)break;throw x;} } break; }
  case "forin": { const iter=vals(s.ex,env)[0]; let rows=[]; if(iter&&iter.kind==="ipairs"){ for(let i=1;i<=iter.t.len();i++) rows.push([i,iter.t.get(i)]); } else if(iter&&iter.kind==="pairs") rows=iter.t.entries(); for(const row of rows){ const e=new Env(env); s.names.forEach((n,i)=>e.define(n,row[i])); try{execBlock(s.body,e);}catch(x){if(x instanceof BreakSignal)break;throw x;} } break; }
} }

function stdEnv(scriptArgs, scriptName) {
  const g=new Env(); const arg=new LuaTable(); arg.set(0,scriptName); scriptArgs.forEach((a,i)=>arg.set(i+1,a)); g.define("arg",arg); g.define("_VERSION","Lua 5.1");
  const print=(...a)=>{ process.stdout.write(a.map(toLuaString).join("\t")+"\n"); };
  const loadChunk = (src, chunkName="=(load)") => { const ast = new Parser(String(src)).parse(); const f = function(args) { const e = new Env(g); e.define("...", args || []); try { execBlock(ast.body, e); } catch(x) { if (x instanceof ReturnSignal) return x.values; throw x; } return []; }; f.__luaFunction = true; return f; };
  Object.assign(g.vars,{print,type:luaType,tostring:toLuaString,tonumber:(v,b)=>{const n=b?parseInt(v,b):Number(v);return Number.isNaN(n)?undefined:n;},assert:(v,m)=>{if(!isTruthy(v))throw new LuaError(m||"assertion failed!");return v;},error:(m)=>{throw new LuaError(toLuaString(m));},ipairs:t=>({kind:"ipairs",t}),pairs:t=>({kind:"pairs",t}),next:(t,k)=>{const es=t.entries(); let idx=k===undefined?0:es.findIndex(e=>e[0]===k)+1; return multi(es[idx]||[]);},unpack:(t,i=1,j)=>{j=j||t.len(); const r=[]; for(let k=i;k<=j;k++)r.push(t.get(k)); return multi(r);},select:(n,...a)=>n==="#"?a.length:multi(a.slice(n-1)),pcall:(fn,...a)=>{try{return multi([true,...(fn.__luaFunction?fn(a):[fn(...a)])]);}catch(e){return multi([false,e.message]);}},loadstring:(s,n)=>{try{return loadChunk(s,n);}catch(e){return multi([undefined,e.message]);}},load:(f,n)=>{try{return loadChunk(typeof f==="function"?f():f,n);}catch(e){return multi([undefined,e.message]);}},loadfile:(p)=>{try{return loadChunk(fs.readFileSync(p,"utf8"),"@"+p);}catch(e){return multi([undefined,e.message]);}},dofile:(p)=>{const fn=loadChunk(fs.readFileSync(p,"utf8"),"@"+p); return multi(fn([]));},rawequal:(a,b)=>a===b,rawget:(t,k)=>t.get(k),rawset:(t,k,v)=>{t.set(k,v);return t;}});
  const math=new LuaTable(); for(const k of Object.getOwnPropertyNames(Math)) if(typeof Math[k]==="function") math.set(k, (...a)=>Math[k](...a.map(num))); math.set("pi",Math.PI); math.set("huge",Infinity); math.set("random", (a,b)=> a===undefined?Math.random(): b===undefined?Math.floor(Math.random()*a)+1:Math.floor(Math.random()*(b-a+1))+a); g.define("math",math);
  const luaPat = p => {
    p = String(p); let r = "";
    for (let i = 0; i < p.length; i++) {
      const c = p[i];
      if (c === "%") {
        const n = p[++i]; const m = {d:"\\d", a:"[A-Za-z]", s:"\\s", w:"[A-Za-z0-9_]", l:"[a-z]", u:"[A-Z]"};
        r += m[n] || n.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&");
      } else if ("^$.*+?()[]".includes(c)) r += c;
      else r += c.replace(/[\\{}|]/g, "\\$&");
    }
    return r;
  };
  const string=new LuaTable(); string.set("len",s=>String(s).length); string.set("sub",(s,i,j)=>{s=String(s); i=i<0?s.length+i+1:i; j=j===undefined?s.length:(j<0?s.length+j+1:j); return s.slice(i-1,j);}); string.set("lower",s=>String(s).toLowerCase()); string.set("upper",s=>String(s).toUpperCase()); string.set("rep",(s,n)=>String(s).repeat(n)); string.set("reverse",s=>String(s).split("").reverse().join("")); string.set("byte",(s,i=1)=>String(s).charCodeAt(i-1)); string.set("char",(...a)=>String.fromCharCode(...a)); string.set("find",(s,p,init=1,plain)=>{s=String(s); const sub=s.slice(init-1); if(plain){const ix=sub.indexOf(String(p)); return ix<0?undefined:multi([init+ix,init+ix+String(p).length-1]);} const m=sub.match(new RegExp(luaPat(p))); return !m?undefined:multi([init+m.index,init+m.index+m[0].length-1,...m.slice(1)]);}); string.set("match",(s,p)=>{const m=String(s).match(new RegExp(luaPat(p))); return !m?undefined:(m.length>1?multi(m.slice(1)):m[0]);}); string.set("gsub",(s,p,r)=>{let n=0; const out=String(s).replace(new RegExp(luaPat(p),"g"),(...m)=>{n++; return typeof r==="function"?r(m[0]):String(r);}); return multi([out,n]);}); string.set("format",(fmt,...a)=>fmt.replace(/%[sdqifg]/g,m=>{const v=a.shift(); return m==="%q"?JSON.stringify(String(v)):m==="%d"||m==="%i"?String(Math.trunc(num(v))):m==="%f"||m==="%g"?String(num(v)):String(v);})); g.define("string",string);
  const table=new LuaTable(); table.set("insert",(t,pos,v)=>{ if(v===undefined){v=pos;pos=t.len()+1;} for(let i=t.len()+1;i>pos;i--)t.set(i,t.get(i-1)); t.set(pos,v);}); table.set("remove",(t,pos)=>{pos=pos||t.len(); const v=t.get(pos); for(let i=pos;i<t.len();i++)t.set(i,t.get(i+1)); t.set(t.len(),undefined); return v;}); table.set("concat",(t,sep="",i=1,j)=>{j=j||t.len(); const r=[]; for(let k=i;k<=j;k++)r.push(toLuaString(t.get(k))); return r.join(sep);}); table.set("sort",(t)=>{const a=[]; for(let i=1;i<=t.len();i++)a.push(t.get(i)); a.sort(); a.forEach((v,i)=>t.set(i+1,v));}); g.define("table",table);
  const osT=new LuaTable([["clock",()=>process.uptime()],["time",()=>Math.floor(Date.now()/1000)],["date",(f,t)=>{const d=new Date((t||Date.now()/1000)*1000); return f==="*t"?new LuaTable([["year",d.getFullYear()],["month",d.getMonth()+1],["day",d.getDate()],["hour",d.getHours()],["min",d.getMinutes()],["sec",d.getSeconds()]]):d.toString();}],["getenv",n=>process.env[n]],["exit",c=>process.exit(c||0)]]);
  g.define("os",osT); const io=new LuaTable([["write",(...a)=>{process.stdout.write(a.map(toLuaString).join(""));}],["read",()=>fs.readFileSync(0,"utf8")]]);
  g.define("io",io); const packageT=new LuaTable([["loaded",new LuaTable()]]); g.define("package",packageT);
  const requireFn=(name)=>{ if(g.get(name)) return g.get(name); if(name==="jit"){ const jit=new LuaTable([["version",VERSION.split(" -- ")[0]],["version_num",20100],["os","Linux"],["arch",process.arch],["on",()=>{}],["off",()=>{}],["flush",()=>{}],["status",()=>multi([true])]]); g.define("jit",jit); return jit;} if(name==="ffi"){ const ffi=new LuaTable([["cdef",()=>{}],["typeof",s=>s],["new",()=>new LuaTable()],["cast",(t,v)=>v],["string",v=>String(v)],["sizeof",()=>8],["C",new LuaTable()]]); g.define("ffi",ffi); return ffi;} throw new LuaError(`module '${name}' not found`); }; g.define("require",requireFn);
  return g;
}

function runChunk(src, name, env) { try { execBlock(new Parser(src).parse().body, env); return 0; } catch(e) { if(e instanceof LuaError) { console.error(`./executable: ${name}: ${e.message}`); return 1; } throw e; } }
function main(argv) {
  let chunks=[], libs=[], script=null, sargs=[], stop=false;
  for(let i=0;i<argv.length;i++){ const a=argv[i]; if(stop){script=a;sargs=argv.slice(i+1);break;} if(a==="--"){stop=true;continue;} if(a==="-"){script="-";sargs=argv.slice(i+1);break;} if(a==="-h"||a==="--help"){console.log(HELP);return 1;} if(a==="-v"){console.log(VERSION);continue;} if(a==="-E"||a==="-i"||a.startsWith("-O")||a.startsWith("-j")) continue; if(a==="-b"||a.startsWith("-b")){console.error("./executable: unknown luaJIT command or jit.* modules not installed");return 1;} if(a==="-e"){chunks.push(argv[++i]||"");continue;} if(a.startsWith("-e")&&a.length>2){chunks.push(a.slice(2));continue;} if(a==="-l"){libs.push(argv[++i]);continue;} if(a.startsWith("-l")&&a.length>2){libs.push(a.slice(2));continue;} if(a.startsWith("-")){console.error(`./executable: unrecognized option '${a}'`);return 1;} script=a;sargs=argv.slice(i+1);break; }
  const env=stdEnv(sargs,script); for(const l of libs) env.get("require")(l);
  for(const c of chunks){ const rc=runChunk(c,"(command line):1",env); if(rc) return rc; }
  if(script){ const src=script==="-"?fs.readFileSync(0,"utf8"):fs.readFileSync(script,"utf8"); return runChunk(src,script,env); }
  if(chunks.length===0 && process.stdin.isTTY){ process.stdout.write(VERSION+"\n"); }
  return 0;
}
process.exitCode = main(process.argv.slice(2));
