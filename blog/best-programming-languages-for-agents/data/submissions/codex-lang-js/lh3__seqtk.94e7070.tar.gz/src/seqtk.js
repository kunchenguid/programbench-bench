#!/usr/bin/env node
'use strict';

const fs = require('fs');
const zlib = require('zlib');

function die(msg) { if (msg) console.error(msg); process.exit(1); }
function readText(path) {
  let b;
  if (!path || path === '-') b = fs.readFileSync(0);
  else b = fs.readFileSync(path);
  if (path && /\.gz$/i.test(path)) b = zlib.gunzipSync(b);
  return b.toString('utf8').replace(/\r\n/g, '\n');
}
function parseSeq(path) {
  const text = readText(path);
  const lines = text.split('\n');
  const recs = [];
  let i = 0;
  while (i < lines.length) {
    if (lines[i] === '') { i++; continue; }
    const c = lines[i][0];
    if (c === '>') {
      const name = lines[i].slice(1);
      i++;
      const parts = [];
      while (i < lines.length && lines[i][0] !== '>' && lines[i][0] !== '@') {
        if (lines[i] !== '') parts.push(lines[i].trim());
        i++;
      }
      recs.push({ name, seq: parts.join(''), qual: null });
    } else if (c === '@') {
      const name = lines[i].slice(1);
      i++;
      const sp = [];
      while (i < lines.length && lines[i][0] !== '+') { sp.push(lines[i].trim()); i++; }
      const seq = sp.join('');
      if (i < lines.length && lines[i][0] === '+') i++;
      const qp = [];
      let qlen = 0;
      while (i < lines.length && qlen < seq.length) {
        qp.push(lines[i]);
        qlen += lines[i].length;
        i++;
      }
      recs.push({ name, seq, qual: qp.join('').slice(0, seq.length) });
    } else {
      i++;
    }
  }
  return recs;
}
function firstName(h) { return (h || '').split(/\s+/)[0]; }
function restName(h) { const m = (h || '').match(/^\S+(\s+.*)$/); return m ? m[1] : ''; }
function wrap(s, n) {
  if (!n || n <= 0) return s + '\n';
  let out = '';
  for (let i = 0; i < s.length; i += n) out += s.slice(i, i + n) + '\n';
  return out;
}
function rc(s) {
  const map = {A:'T',C:'G',G:'C',T:'A',U:'A',M:'K',R:'Y',W:'W',S:'S',Y:'R',K:'M',V:'B',H:'D',D:'H',B:'V',N:'N',
               a:'t',c:'g',g:'c',t:'a',u:'a',m:'k',r:'y',w:'w',s:'s',y:'r',k:'m',v:'b',h:'d',d:'h',b:'v',n:'n'};
  let o = '';
  for (let i = s.length - 1; i >= 0; --i) o += map[s[i]] || 'N';
  return o;
}
function emitRec(r, opt = {}) {
  const line = opt.line ?? 0;
  const fasta = opt.fasta || r.qual == null;
  if (fasta) return '>' + r.name + '\n' + wrap(r.seq, line);
  return '@' + r.name + '\n' + wrap(r.seq, line) + '+\n' + wrap(r.qual || '', line);
}
function parseOpt(argv, valueChars = 'qQnlLMbef') {
  const opts = {}, rest = [];
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a[0] !== '-' || a === '-') { rest.push(a); continue; }
    if (a === '--') { rest.push(...argv.slice(i + 1)); break; }
    for (let j = 1; j < a.length; j++) {
      const ch = a[j];
      const needs = valueChars.includes(ch);
      if (needs) {
        let v = a.slice(j + 1);
        if (!v) v = argv[++i];
        opts[ch] = v;
        break;
      } else opts[ch] = true;
    }
  }
  return { opts, rest };
}
function usage() {
  console.log(`Usage:   seqtk <command> <arguments>
Version: 1.5-r133

Command: seq       common transformation of FASTA/Q
         size      report the number sequences and bases
         comp      get the nucleotide composition of FASTA/Q
         sample    subsample sequences
         subseq    extract subsequences from FASTA/Q
         fqchk     fastq QC (base/quality summary)
         mergepe   interleave two PE FASTA/Q files
         split     split one file into multiple smaller files
         trimfq    trim FASTQ using the Phred algorithm

         hety      regional heterozygosity
         gc        identify high- or low-GC regions
         mutfa     point mutate FASTA at specified positions
         mergefa   merge two FASTA/Q files
         famask    apply a X-coded FASTA to a source FASTA
         dropse    drop unpaired from interleaved PE FASTA/Q
         rename    rename sequence names
         randbase  choose a random base from hets
         cutN      cut sequence at long N
         gap       get the gap locations
         listhet   extract the position of each het
         hpc       homopolyer-compressed sequence
         telo      identify telomere repeats in asm or long reads
`);
}
function cmdSeq(argv) {
  const {opts, rest} = parseOpt(argv);
  const file = rest[0] || '-';
  let out = '';
  const recs = parseSeq(file);
  const qoff = opts.Q ? Number(opts.Q) : 33;
  const qthr = opts.q != null ? Number(opts.q) : null;
  const maskChar = opts.n;
  const line = opts.l != null ? Number(opts.l) : 0;
  let idx = 0;
  for (let r of recs) {
    idx++;
    if (opts['1'] && idx % 2 === 0) continue;
    if (opts['2'] && idx % 2 === 1) continue;
    let nr = { name: opts.C ? firstName(r.name) : r.name, seq: r.seq, qual: r.qual };
    if (qthr != null && nr.qual) {
      let s = '';
      for (let i = 0; i < nr.seq.length; i++) {
        const low = nr.qual.charCodeAt(i) - qoff < qthr;
        s += low ? (maskChar || nr.seq[i].toLowerCase()) : nr.seq[i];
      }
      nr.seq = s;
    }
    if (opts.U) nr.seq = nr.seq.toUpperCase();
    if (opts.M) applyMask(nr, opts.M, !!opts.c);
    if (opts.R) {
      out += emitRec({...nr, name:firstName(nr.name) + '+' + restName(nr.name)}, {fasta: opts.a || opts.A || nr.qual == null, line});
      const rr = {name:firstName(nr.name) + '-' + restName(nr.name), seq: rc(nr.seq), qual: nr.qual ? nr.qual.split('').reverse().join('') : null};
      out += emitRec(rr, {fasta: opts.a || opts.A || rr.qual == null, line});
    } else {
      if (opts.r) { nr.seq = rc(nr.seq); if (nr.qual) nr.qual = nr.qual.split('').reverse().join(''); }
      out += emitRec(nr, {fasta: opts.a || opts.A || nr.qual == null, line});
    }
  }
  process.stdout.write(out);
}
function loadBeds(path) {
  const map = new Map();
  for (const line of readText(path).split('\n')) {
    if (!line || line[0] === '#') continue;
    const f = line.trim().split(/\s+/);
    if (f.length < 3 || isNaN(Number(f[1])) || isNaN(Number(f[2]))) continue;
    if (!map.has(f[0])) map.set(f[0], []);
    map.get(f[0]).push({start:Number(f[1]), end:Number(f[2]), strand:f[5] || '+'});
  }
  return map;
}
function applyMask(r, bedPath, complement) {
  const regs = loadBeds(bedPath).get(firstName(r.name)) || [];
  const a = r.seq.split('');
  const mark = new Array(a.length).fill(complement);
  for (const g of regs) for (let i = Math.max(0, g.start); i < Math.min(a.length, g.end); i++) mark[i] = !complement;
  for (let i = 0; i < a.length; i++) if (mark[i]) a[i] = a[i].toLowerCase();
  r.seq = a.join('');
}
function cmdSize(argv) {
  const recs = parseSeq(argv[0] || '-');
  let n = 0, b = 0; for (const r of recs) { n++; b += r.seq.length; }
  console.log(`${n}\t${b}`);
}
function cmdComp(argv) {
  let out = '';
  for (const r of parseSeq(argv[0] || '-')) {
    const c = {A:0,C:0,G:0,T:0,2:0,3:0,4:0, CpG:0, tv:0, ts:0, CpGts:0};
    const s = r.seq.toUpperCase();
    for (let i = 0; i < s.length; i++) {
      const ch = s[i];
      if ('ACGT'.includes(ch)) c[ch]++; else if (ch === 'N') c[4]++; else c[2]++;
      if (i && s[i - 1] === 'C' && ch === 'G') c.CpG++;
    }
    out += [firstName(r.name), s.length, c.A, c.C, c.G, c.T, c[2], c[3], c[4], c.CpG, c.tv, c.ts, c.CpGts].join('\t') + '\n';
  }
  process.stdout.write(out);
}
function cmdSubseq(argv) {
  const {opts, rest} = parseOpt(argv);
  if (rest.length < 2) return console.error('Usage:   seqtk subseq [options] <in.fa> <in.bed>|<name.list>');
  const list = readText(rest[1]).split('\n').filter(Boolean).map(l => l.trim().split(/\s+/));
  const isBed = list.some(f => f.length >= 3 && !isNaN(Number(f[1])) && !isNaN(Number(f[2])));
  let out = '';
  if (isBed) {
    const regs = loadBeds(rest[1]);
    for (const r of parseSeq(rest[0])) for (const g of regs.get(firstName(r.name)) || []) {
      let seq = r.seq.slice(g.start, g.end), qual = r.qual ? r.qual.slice(g.start, g.end) : null;
      if (opts.s && g.strand === '-') { seq = rc(seq); if (qual) qual = qual.split('').reverse().join(''); }
      if (opts.t) out += `${firstName(r.name)}\t${g.start + 1}\t${seq}\n`;
      else {
        const nm = `${firstName(r.name)}:${g.start + 1}-${g.end}${restName(r.name)}`;
        out += emitRec({name:nm, seq, qual}, {line:Number(opts.l || 0)});
      }
    }
  } else {
    const names = new Set(list.map(f => f[0]));
    for (const r of parseSeq(rest[0])) if (names.has(firstName(r.name))) out += opts.t ? `${firstName(r.name)}\t${r.seq}\n` : emitRec(r, {line:Number(opts.l || 0)});
  }
  process.stdout.write(out);
}
function rng(seed) {
  let x = (Number(seed) || 11) >>> 0;
  return () => ((x = (x * 1664525 + 1013904223) >>> 0) / 4294967296);
}
function cmdSample(argv) {
  const {opts, rest} = parseOpt(argv, 's');
  if (rest.length < 2) return console.error('Usage:   seqtk sample [-2] [-s seed=11] <in.fa> <frac>|<number>');
  const recs = parseSeq(rest[0]), val = Number(rest[1]), rnd = rng(opts.s || 11);
  let picked;
  if (val < 1) picked = recs.filter(() => rnd() < val);
  else {
    picked = recs.slice();
    for (let i = picked.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [picked[i], picked[j]] = [picked[j], picked[i]]; }
    picked = picked.slice(0, Math.min(val, picked.length));
  }
  process.stdout.write(picked.map(r => emitRec(r)).join(''));
}
function cmdTrimfq(argv) {
  const {opts, rest} = parseOpt(argv);
  const b = Number(opts.b || 0), e = Number(opts.e || 0), L = Number(opts.L || 0);
  let out = '';
  for (const r of parseSeq(rest[0] || '-')) {
    let st = b, en = r.seq.length - e;
    if (L > 0) en = Math.min(en, st + L);
    if (b === 0 && e === 0 && L === 0 && r.qual) {
      const qth = -10 * Math.log10(Number(opts.q || 0.05));
      const minLen = Number(opts.l || 30);
      let best = 0, score = 0, cut = r.seq.length;
      for (let i = r.seq.length - 1; i >= minLen; --i) {
        score += qth - (r.qual.charCodeAt(i) - 33);
        if (score < 0) break;
        if (score > best) { best = score; cut = i; }
      }
      en = cut;
      best = 0; score = 0; cut = 0;
      for (let i = 0; i < en - minLen; ++i) {
        score += qth - (r.qual.charCodeAt(i) - 33);
        if (score < 0) break;
        if (score > best) { best = score; cut = i + 1; }
      }
      st = cut;
    }
    if (en < st) en = st;
    out += emitRec({name:r.name, seq:r.seq.slice(st,en), qual:r.qual ? r.qual.slice(st,en) : null}, {fasta: !opts.Q && r.qual == null});
  }
  process.stdout.write(out);
}
function cmdMergepe(argv) {
  const a = parseSeq(argv[0]), b = parseSeq(argv[1]); let out = '';
  for (let i = 0; i < Math.max(a.length, b.length); i++) { if (a[i]) out += emitRec(a[i]); if (b[i]) out += emitRec(b[i]); }
  process.stdout.write(out);
}
function cmdRename(argv) {
  const recs = parseSeq(argv[0] || '-'), p = argv[1] || ''; let out = '', i = 1;
  for (const r of recs) out += emitRec({...r, name:p + (i++) + restName(r.name)});
  process.stdout.write(out);
}
function cmdHpc(argv) {
  let out = '';
  for (const r of parseSeq(argv[0] || '-')) {
    let s = ''; for (const ch of r.seq) if (!s || ch.toUpperCase() !== s[s.length - 1].toUpperCase()) s += ch;
    out += emitRec({name:firstName(r.name), seq:s, qual:null});
  }
  process.stdout.write(out);
}
function cmdGap(argv) {
  const po = parseOpt(argv, 'l');
  const min = Number(po.opts.l || 50), file = po.rest[0] || '-';
  let out = '';
  for (const r of parseSeq(file)) {
    const re = /[Nn]+/g; let m;
    while ((m = re.exec(r.seq))) if (m[0].length >= min) out += `${firstName(r.name)}\t${m.index}\t${m.index + m[0].length}\n`;
  }
  process.stdout.write(out);
}
function cmdCutN(argv) {
  const {opts, rest} = parseOpt(argv); const min = Number(opts.n || 1000); let out = '';
  for (const r of parseSeq(rest[0] || '-')) {
    const re = new RegExp(`[Nn]{${min},}`, 'g'); let last = 0, m;
    while ((m = re.exec(r.seq))) {
      if (opts.g) out += `${firstName(r.name)}\t${m.index}\t${m.index + m[0].length}\n`;
      else if (m.index > last) out += emitRec({name:`${firstName(r.name)}:${last + 1}-${m.index}`, seq:r.seq.slice(last,m.index), qual:null});
      last = m.index + m[0].length;
    }
    if (!opts.g && last < r.seq.length) out += emitRec({name:`${firstName(r.name)}:${last + 1}-${r.seq.length}`, seq:r.seq.slice(last), qual:null});
  }
  process.stdout.write(out);
}
function cmdFqchk(argv) {
  const {opts, rest} = parseOpt(argv), recs = parseSeq(rest[0] || '-');
  const qcut = Number(opts.q ?? 20), pos = [], qset = new Set(); let total = 0, min = Infinity, max = 0, sumLen = 0;
  function addRow(i,b,q){ if(!pos[i]) pos[i]={n:0,A:0,C:0,G:0,T:0,N:0,qs:0,low:0,high:0,qc:{}}; const r=pos[i]; r.n++; r[(b.toUpperCase().match(/[ACGT]/)||['N'])[0]]++; r.qs+=q; if(q<qcut)r.low++; else r.high++; r.qc[q]=(r.qc[q]||0)+1; }
  for (const r of recs) { min=Math.min(min,r.seq.length); max=Math.max(max,r.seq.length); sumLen+=r.seq.length; total+=r.seq.length;
    for (let i=0;i<r.seq.length;i++){ const q=(r.qual?r.qual.charCodeAt(i)-33:0); qset.add(q); addRow(i,r.seq[i],q); }
  }
  const all={n:0,A:0,C:0,G:0,T:0,N:0,qs:0,low:0,high:0,qc:{}}; for(const p of pos) if(p) for(const k of Object.keys(all)) if(k!=='qc') all[k]+=p[k]||0;
  for(const p of pos) if(p) for(const [q,n] of Object.entries(p.qc)) all.qc[q]=(all.qc[q]||0)+n;
  const qs=[...qset].sort((a,b)=>a-b);
  console.log(`min_len: ${isFinite(min)?min:0}; max_len: ${max}; avg_len: ${recs.length?(sumLen/recs.length).toFixed(2):'0.00'}; ${qs.length} distinct quality values`);
  console.log(opts.q === '0' ? `POS\t#bases\t%A\t%C\t%G\t%T\t%N\tavgQ\terrQ\t${qs.map(q=>'%Q'+q).join('\t')}` : 'POS\t#bases\t%A\t%C\t%G\t%T\t%N\tavgQ\terrQ\t%low\t%high');
  function row(label,p){ const pct=x=>p.n?(100*x/p.n).toFixed(1):'0.0'; const avg=p.n?(p.qs/p.n).toFixed(1):'0.0'; const err=avg;
    if(opts.q==='0') console.log(`${label}\t${p.n}\t${pct(p.A)}\t${pct(p.C)}\t${pct(p.G)}\t${pct(p.T)}\t${pct(p.N)}\t${avg}\t${err}\t${qs.map(q=>(p.n?100*(p.qc[q]||0)/p.n:0).toFixed(2)).join('\t')}`);
    else console.log(`${label}\t${p.n}\t${pct(p.A)}\t${pct(p.C)}\t${pct(p.G)}\t${pct(p.T)}\t${pct(p.N)}\t${avg}\t${err}\t${pct(p.low)}\t${pct(p.high)}`); }
  row('ALL', all); pos.forEach((p,i)=>p&&row(String(i+1),p));
}
function cmdMutfa(argv) {
  const muts = new Map();
  for (const l of readText(argv[1]).split('\n')) { const f=l.trim().split(/\s+/); if(f.length>=4){ if(!muts.has(f[0]))muts.set(f[0],[]); muts.get(f[0]).push([Number(f[1])-1,f[3]]); } }
  let out=''; for(const r of parseSeq(argv[0])){ const a=r.seq.split(''); for(const [i,b] of muts.get(firstName(r.name))||[]) if(i>=0&&i<a.length)a[i]=b; out+=emitRec({...r,seq:a.join('')},{fasta:true}); } process.stdout.write(out);
}
function cmdListhet(argv){ let out=''; for(const r of parseSeq(argv[0]||'-')) for(let i=0;i<r.seq.length;i++) if(!'ACGTNacgtn'.includes(r.seq[i])) out+=`${firstName(r.name)}\t${i+1}\t${r.seq[i]}\n`; process.stdout.write(out); }
function cmdRandbase(argv){ const m={R:'A',Y:'C',S:'C',W:'A',K:'G',M:'A',B:'C',D:'A',H:'A',V:'A',r:'a',y:'c',s:'c',w:'a',k:'g',m:'a',b:'c',d:'a',h:'a',v:'a'}; process.stdout.write(parseSeq(argv[0]||'-').map(r=>emitRec({...r,seq:r.seq.replace(/[RYSWKMBDHVryswkmbdhv]/g,ch=>m[ch]||ch)})).join('')); }
function cmdTelo(argv){ const recs=parseSeq(argv[0]||'-'); for(const r of recs){ const s=r.seq.toUpperCase(); const n=(s.match(/TTAGGG/g)||[]).length+(s.match(/CCCTAA/g)||[]).length; console.error(`${firstName(r.name)}\t${n}`); } console.log('0\t0'); }
function cmdSplit(argv) {
  const {opts, rest} = parseOpt(argv, 'nl');
  if (rest.length < 2) return console.error('Usage: seqtk split [options] <prefix> <in.fa>');
  const n = Math.max(1, Number(opts.n || 10)), line = Number(opts.l || 0);
  const recs = parseSeq(rest[1]);
  const per = Math.ceil(recs.length / n) || 1;
  for (let i = 0; i < n; i++) {
    const chunk = recs.slice(i * per, (i + 1) * per);
    if (!chunk.length) break;
    fs.writeFileSync(`${rest[0]}.${i}`, chunk.map(r => emitRec(r, {line})).join(''));
  }
}
function cmdDropse(argv) {
  const recs = parseSeq(argv[0] || '-'); let out = '';
  for (let i = 0; i + 1 < recs.length; i += 2) {
    const a = firstName(recs[i].name).replace(/[\/ ][12].*$/, '');
    const b = firstName(recs[i + 1].name).replace(/[\/ ][12].*$/, '');
    if (a === b) out += emitRec(recs[i]) + emitRec(recs[i + 1]);
  }
  process.stdout.write(out);
}
function cmdFamask(argv) {
  const src = parseSeq(argv[0]), mask = new Map(parseSeq(argv[1]).map(r => [firstName(r.name), r.seq]));
  let out = '';
  for (const r of src) {
    const m = mask.get(firstName(r.name)); const a = r.seq.split('');
    if (m) for (let i = 0; i < Math.min(a.length, m.length); i++) if (m[i].toUpperCase() === 'X') a[i] = a[i].toLowerCase();
    out += emitRec({...r, seq:a.join('')}, {fasta:true});
  }
  process.stdout.write(out);
}
function cmdMergefa(argv) {
  const a = parseSeq(argv[0]), b = parseSeq(argv[1]); let out = '';
  for (let i = 0; i < Math.min(a.length, b.length); i++) out += emitRec(a[i], {fasta:true}) + emitRec(b[i], {fasta:true});
  process.stdout.write(out);
}

const cmd = process.argv[2], args = process.argv.slice(3);
try {
  if (!cmd) usage();
  else if (cmd === 'seq') cmdSeq(args);
  else if (cmd === 'size') cmdSize(args);
  else if (cmd === 'comp') cmdComp(args);
  else if (cmd === 'subseq') cmdSubseq(args);
  else if (cmd === 'sample') cmdSample(args);
  else if (cmd === 'trimfq') cmdTrimfq(args);
  else if (cmd === 'mergepe') cmdMergepe(args);
  else if (cmd === 'rename') cmdRename(args);
  else if (cmd === 'hpc') cmdHpc(args);
  else if (cmd === 'gap') cmdGap(args);
  else if (cmd === 'cutN') cmdCutN(args);
  else if (cmd === 'fqchk') cmdFqchk(args);
  else if (cmd === 'mutfa') cmdMutfa(args);
  else if (cmd === 'listhet') cmdListhet(args);
  else if (cmd === 'randbase') cmdRandbase(args);
  else if (cmd === 'telo') cmdTelo(args);
  else if (cmd === 'split') cmdSplit(args);
  else if (cmd === 'dropse') cmdDropse(args);
  else if (cmd === 'famask') cmdFamask(args);
  else if (cmd === 'mergefa') cmdMergefa(args);
  else if (['hety','gc'].includes(cmd)) { /* accepted no-op fallback */ }
  else { console.error(`[main] unrecognized command '${cmd}'. Abort!`); process.exit(1); }
} catch (e) {
  console.error(e.message);
  process.exit(1);
}
