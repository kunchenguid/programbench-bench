#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

process.stdout.on('error', err => {
  if (err && err.code === 'EPIPE') process.exit(0);
  throw err;
});

const VERSION_TEXT = `FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,
Christiaan Keet and Claudio Matsuoka
Internet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012

FIGlet, along with the various FIGlet fonts and documentation, may be
freely copied and distributed.

If you use FIGlet, please send an e-mail message to <info@figlet.org>.

The latest version of FIGlet is available from the web site,
\thttp://www.figlet.org/

Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]
              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]
              [ -C controlfile ] [ -I infocode ] [ message ]`;

const USAGE = `Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]
              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]
              [ -C controlfile ] [ -I infocode ] [ message ]`;

function failUsage(opt) {
  process.stderr.write(`./executable: invalid option -- '${opt}'\n${USAGE}\n`);
  process.exit(0);
}

function parseArgs(argv) {
  const opts = {
    fontDir: '/usr/local/share/figlet',
    fontName: 'standard',
    width: 80,
    justify: 'auto',
    direction: 'auto',
    paragraph: false,
    layoutOverride: null,
    german: false,
    info: -1,
    messages: [],
    controlFiles: [],
  };
  const needArg = new Set(['d', 'f', 'm', 'w', 'C', 'I']);
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--') {
      opts.messages.push(...argv.slice(i + 1));
      break;
    }
    if (!arg.startsWith('-') || arg === '-') {
      opts.messages.push(...argv.slice(i));
      break;
    }
    for (let j = 1; j < arg.length; j++) {
      const ch = arg[j];
      let val = null;
      if (needArg.has(ch)) {
        if (j + 1 < arg.length) {
          val = arg.slice(j + 1);
          j = arg.length;
        } else {
          i++;
          if (i >= argv.length) failUsage(ch);
          val = argv[i];
        }
      }
      switch (ch) {
        case 'd': opts.fontDir = val; break;
        case 'f': opts.fontName = val.replace(/\.(flf|tlf)$/i, ''); break;
        case 'm': {
          const n = parseInt(val, 10);
          if (n === -1) opts.layoutOverride = 'full';
          else if (n === 0) opts.layoutOverride = 'kern';
          else if (n === -2) opts.layoutOverride = 'default-smush';
          else opts.layoutOverride = Number.isFinite(n) ? n : null;
          break;
        }
        case 'w': opts.width = Math.max(1, parseInt(val, 10) || 80); break;
        case 'C': opts.controlFiles.push(val); break;
        case 'I': opts.info = parseInt(val, 10); break;
        case 'c': opts.justify = 'center'; break;
        case 'l': opts.justify = 'left'; break;
        case 'r': opts.justify = 'right'; break;
        case 'x': opts.justify = 'auto'; break;
        case 'L': opts.direction = 'ltr'; break;
        case 'R': opts.direction = 'rtl'; break;
        case 'X': opts.direction = 'auto'; break;
        case 'p': opts.paragraph = true; break;
        case 'n': opts.paragraph = false; break;
        case 'D': opts.german = true; break;
        case 'E': opts.german = false; break;
        case 'N': opts.controlFiles = []; break;
        case 's': opts.layoutOverride = 'default-smush'; break;
        case 'S': opts.layoutOverride = 63; break;
        case 'k': opts.layoutOverride = 'kern'; break;
        case 'W': opts.layoutOverride = 'full'; break;
        case 'o': opts.layoutOverride = 'overlap'; break;
        case 't': opts.width = parseInt(process.env.COLUMNS || '80', 10) || opts.width; break;
        case 'v': opts.info = 0; break;
        default: failUsage(ch);
      }
    }
  }
  return opts;
}

function findFont(opts) {
  const raw = opts.fontName;
  const candidates = [];
  if (path.isAbsolute(raw) || raw.includes('/')) {
    candidates.push(raw, raw + '.flf', raw + '.tlf');
  } else {
    candidates.push(
      path.join(opts.fontDir, raw),
      path.join(opts.fontDir, raw + '.flf'),
      path.join(opts.fontDir, raw + '.tlf'),
      raw,
      raw + '.flf',
      raw + '.tlf',
      path.join(__dirname, '..', 'fonts', raw + '.flf'),
      path.join(__dirname, '..', 'fonts', raw + '.tlf'),
      path.join(__dirname, '..', 'assets', raw + '.flf'),
      path.join(__dirname, '..', 'assets', raw + '.tlf')
    );
  }
  for (const file of candidates) {
    try {
      if (fs.statSync(file).isFile()) return file;
    } catch (_) {}
  }
  return null;
}

function parseFont(file) {
  const text = fs.readFileSync(file, 'latin1').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const lines = text.split('\n');
  const header = lines[0].split(/\s+/);
  if (!/^[ft]lf2a/.test(header[0])) throw new Error('bad font');
  const hardblank = header[0][5];
  const height = parseInt(header[1], 10);
  const oldLayout = parseInt(header[4], 10);
  const comments = parseInt(header[5], 10) || 0;
  const printDirection = parseInt(header[6] || '0', 10) || 0;
  const fullLayout = header.length > 7 ? parseInt(header[7], 10) : null;
  let idx = 1 + comments;
  const chars = new Map();
  for (let code = 32; code <= 126 && idx < lines.length; code++) {
    chars.set(code, readChar(lines, idx, height));
    idx += height;
  }
  const required = [196, 214, 220, 228, 246, 252, 223];
  for (const code of required) {
    if (idx + height <= lines.length) {
      chars.set(code, readChar(lines, idx, height));
      idx += height;
    }
  }
  while (idx < lines.length) {
    const m = lines[idx].match(/^\s*(?:0[xX]([0-9a-fA-F]+)|0([0-7]+)|(-?\d+))\s*$/);
    if (!m) { idx++; continue; }
    const code = m[1] ? parseInt(m[1], 16) : m[2] ? parseInt(m[2], 8) : parseInt(m[3], 10);
    idx++;
    if (idx + height <= lines.length) {
      chars.set(code, readChar(lines, idx, height));
      idx += height;
    }
  }
  return { hardblank, height, oldLayout, fullLayout, printDirection, chars };
}

function readChar(lines, start, height) {
  const out = [];
  for (let i = 0; i < height; i++) {
    let s = lines[start + i] || '';
    const mark = s[s.length - 1];
    let end = s.length - 1;
    while (end >= 0 && s[end] === mark) end--;
    out.push(s.slice(0, end + 1));
  }
  return out;
}

function effectiveLayout(font, opts) {
  if (opts.layoutOverride === 'full') return { type: 'full', rules: 0 };
  if (opts.layoutOverride === 'kern') return { type: 'kern', rules: 0 };
  if (opts.layoutOverride === 'overlap') return { type: 'overlap', rules: 0 };
  if (typeof opts.layoutOverride === 'number') return { type: 'smush', rules: opts.layoutOverride };
  let layout = font.oldLayout;
  if (layout === -1) return { type: 'full', rules: 0 };
  if (layout === 0) return { type: 'kern', rules: 0 };
  return { type: 'smush', rules: layout > 0 ? layout : 63 };
}

function visibleLen(s, hardblank) {
  return s.replaceAll(hardblank, ' ').length;
}

function canSmush(a, b, rules, hardblank) {
  if (a === ' ') return b;
  if (b === ' ') return a;
  if (rules === 0) return null;
  if ((rules & 1) && a === b && a !== hardblank) return a;
  if (rules & 2) {
    const set = '|/\\[]{}()<>';
    if (a === '_' && set.includes(b)) return b;
    if (b === '_' && set.includes(a)) return a;
  }
  if (rules & 4) {
    const groups = ['|', '/\\', '[]', '{}', '()', '<>'];
    const ia = groups.findIndex(g => g.includes(a));
    const ib = groups.findIndex(g => g.includes(b));
    if (ia >= 0 && ib >= 0 && ia !== ib) return ia > ib ? a : b;
  }
  if ((rules & 8) && '[]{}()'.includes(a) && '[]{}()'.includes(b)) {
    if ((a === '[' && b === ']') || (a === ']' && b === '[') ||
        (a === '{' && b === '}') || (a === '}' && b === '{') ||
        (a === '(' && b === ')') || (a === ')' && b === '(')) return '|';
  }
  if (rules & 16) {
    if (a === '/' && b === '\\') return '|';
    if (a === '\\' && b === '/') return 'Y';
    if (a === '>' && b === '<') return 'X';
  }
  if ((rules & 32) && a === hardblank && b === hardblank) return hardblank;
  return null;
}

function charAt(s, i) {
  return i >= 0 && i < s.length ? s[i] : ' ';
}

function fitting(cur, glyph, layout, hardblank) {
  if (layout.type === 'full') return 0;
  let max = Infinity;
  for (let row = 0; row < cur.length; row++) {
    const left = cur[row];
    const right = glyph[row] || '';
    if (!left.length || !right.length) {
      max = Math.min(max, 0);
      continue;
    }
    let trailing = 0;
    while (trailing < left.length && left[left.length - 1 - trailing] === ' ') trailing++;
    let leading = 0;
    while (leading < right.length && right[leading] === ' ') leading++;
    let amount = trailing + leading;
    const a = charAt(left, left.length - trailing - 1);
    const b = charAt(right, leading);
    if (layout.type === 'overlap') amount += 1;
    else if (layout.type === 'smush' && canSmush(a, b, layout.rules, hardblank) !== null) amount += 1;
    max = Math.min(max, amount);
  }
  return max === Infinity ? 0 : max;
}

function appendGlyph(cur, glyph, layout, hardblank) {
  const overlap = fitting(cur, glyph, layout, hardblank);
  const out = [];
  for (let row = 0; row < cur.length; row++) {
    const left = cur[row];
    const right = glyph[row] || '';
    if (overlap <= 0) {
      out[row] = left + right;
      continue;
    }
    let prefix = left.slice(0, Math.max(0, left.length - overlap));
    let mid = '';
    for (let k = 0; k < overlap; k++) {
      const a = charAt(left, left.length - overlap + k);
      const b = charAt(right, k);
      mid += canSmush(a, b, layout.type === 'smush' ? layout.rules : 0, hardblank) || (b === ' ' ? a : b);
    }
    out[row] = prefix + mid + right.slice(overlap);
  }
  return out;
}

function normalizeInput(s, opts) {
  if (opts.german) {
    s = s.replaceAll('[', 'Ä').replaceAll('\\', 'Ö').replaceAll(']', 'Ü')
         .replaceAll('{', 'ä').replaceAll('|', 'ö').replaceAll('}', 'ü')
         .replaceAll('~', 'ß');
  }
  if (!opts.paragraph) return s;
  let out = '';
  for (let i = 0; i < s.length; i++) {
    if (s[i] === '\n' && s[i - 1] !== '\n' && s[i + 1] !== ' ' && s[i + 1] !== '\n' && s[i + 1] !== undefined) out += ' ';
    else out += s[i];
  }
  return out;
}

function renderLine(text, font, opts) {
  const direction = opts.direction === 'auto' ? (font.printDirection === 1 ? 'rtl' : 'ltr') : opts.direction;
  const layout = effectiveLayout(font, opts);
  const chars = Array.from(text);
  if (direction === 'rtl') chars.reverse();
  const renderedLines = [];
  let cur = Array(font.height).fill('');
  let lastBreak = -1;
  let states = [];
  function flush() {
    renderedLines.push(cur);
    cur = Array(font.height).fill('');
    lastBreak = -1;
    states = [];
  }
  for (let idx = 0; idx < chars.length; idx++) {
    const cp = chars[idx].codePointAt(0);
    const glyph = font.chars.get(cp) || font.chars.get(0) || font.chars.get(32);
    const next = appendGlyph(cur, glyph, layout, font.hardblank);
    const width = Math.max(...next.map(s => visibleLen(s, font.hardblank)));
    if (opts.width === 1 && cp !== 32 && cur.some(s => s.length)) {
      flush();
      idx--;
      continue;
    }
    if (opts.width > 1 && width > opts.width && cur.some(s => s.length)) {
      if (lastBreak >= 0) {
        const keep = states[lastBreak].after;
        renderedLines.push(keep);
        const rest = chars.slice(states[lastBreak].index + 1, idx + 1).join('').trimStart();
        cur = Array(font.height).fill('');
        lastBreak = -1;
        states = [];
        const rerender = renderLine(rest, font, { ...opts, width: 1000000 });
        cur = rerender[0] || Array(font.height).fill('');
      } else {
        flush();
        idx--;
      }
      continue;
    }
    cur = next;
    states.push({ index: idx, after: cur.slice() });
    if (cp === 32) lastBreak = states.length - 1;
  }
  renderedLines.push(cur);
  return renderedLines;
}

function justifyBlock(block, font, opts) {
  const direction = opts.direction === 'auto' ? (font.printDirection === 1 ? 'rtl' : 'ltr') : opts.direction;
  const just = opts.justify === 'auto' ? (direction === 'rtl' ? 'right' : 'left') : opts.justify;
  if (just === 'left') return block;
  const width = Math.max(...block.map(s => visibleLen(s, font.hardblank)));
  return block.map(line => {
    const pad = Math.max(0, opts.width - width);
    if (just === 'right') return ' '.repeat(pad) + line;
    return ' '.repeat(Math.floor(pad / 2)) + line;
  });
}

function render(text, font, opts) {
  const blocks = [];
  for (const line of normalizeInput(text, opts).split('\n')) {
    for (const block of renderLine(line, font, opts)) {
      blocks.push(...justifyBlock(block, font, opts).map(s => s.replaceAll(font.hardblank, ' ')));
    }
  }
  return blocks.join('\n') + '\n';
}

function info(opts) {
  if (opts.info === 0) return VERSION_TEXT + '\n';
  if (opts.info === 1) return '20205\n';
  if (opts.info === 2) return opts.fontDir + '\n';
  if (opts.info === 3) return opts.fontName + '\n';
  if (opts.info === 4) return String(opts.width) + '\n';
  if (opts.info === 5) return 'flf2 tlf2\n';
  if (opts.info > 0) return '';
  return null;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const inf = info(opts);
  if (inf !== null) {
    process.stdout.write(inf);
    return;
  }
  const file = findFont(opts);
  if (!file) {
    process.stderr.write(`executable: ${opts.fontName}: Unable to open font file\n`);
    return;
  }
  let input;
  if (opts.messages.length) input = opts.messages.join(' ');
  else input = fs.readFileSync(0, 'utf8');
  const font = parseFont(file);
  process.stdout.write(render(input, font, opts));
}

main();
