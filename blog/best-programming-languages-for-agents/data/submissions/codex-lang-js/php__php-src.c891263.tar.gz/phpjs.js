#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const VERSION = `PHP 8.6.0-dev (cli) (built: Apr 17 2026 20:00:58) (NTS)
Copyright (c) The PHP Group
Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies
    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies`;

const HELP = `Usage: executable [options] [-f] <file> [--] [args...]
   executable [options] -r <code> [--] [args...]
   executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]
   executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]
   executable [options] -S <addr>:<port> [-t docroot] [router]
   executable [options] -- [args...]
   executable [options] -a

  -a               Run as interactive shell (requires readline extension)
  -c <path>|<file> Look for php.ini file in this directory
  -n               No configuration (ini) files will be used
  -d foo[=bar]     Define INI entry foo with value 'bar'
  -e               Generate extended information for debugger/profiler
  -f <file>        Parse and execute <file>.
  -h               This help
  -i               PHP information
  -l               Syntax check only (lint)
  -m               Show compiled in modules
  -r <code>        Run PHP <code> without using script tags <?..?>
  -B <begin_code>  Run PHP <begin_code> before processing input lines
  -R <code>        Run PHP <code> for every input line
  -F <file>        Parse and execute <file> for every input line
  -E <end_code>    Run PHP <end_code> after processing all input lines
  -H               Hide any passed arguments from external tools.
  -S <addr>:<port> Run with built-in web server.
  -t <docroot>     Specify document root <docroot> for built-in web server.
  -s               Output HTML syntax highlighted source.
  -v               Version number
  -w               Output source with stripped comments and whitespace.

  args...          Arguments passed to script. Use -- args when first argument
                   starts with - or script is read from stdin

  --ini            Show configuration file names
  --ini=diff       Show INI entries that differ from the built-in default

  --rf <name>      Show information about function <name>.
  --rc <name>      Show information about class <name>.
  --re <name>      Show information about extension <name>.
  --rz <name>      Show information about Zend extension <name>.
  --ri <name>      Show configuration for extension <name>.

  --repeat <count> Repeat script execution <count> times.
                   For internal purposes only.`;

function out(s='') { process.stdout.write(String(s)); }
function err(s='') { process.stderr.write(String(s)); }
function println(s='') { process.stdout.write(String(s) + '\n'); }

class PhpArray {
  constructor(entries=[]) { this.entries = entries; this.map = new Map(entries.map(([k,v])=>[String(k), v])); }
  get(k) { return this.map.get(String(k)); }
  set(k,v) { this.map.set(String(k), v); const i=this.entries.findIndex(e=>String(e[0])===String(k)); if(i>=0)this.entries[i][1]=v; else this.entries.push([k,v]); return v; }
  values() { return this.entries.map(e=>e[1]); }
  count() { return this.entries.length; }
}
function __arr(entries) { return new PhpArray(entries); }
function __get(a,k) { return a instanceof PhpArray ? a.get(k) : a?.[k]; }
function __set(a,k,v) { return a instanceof PhpArray ? a.set(k,v) : (a[k]=v); }
function __values(a) { return a instanceof PhpArray ? a.values() : (Array.isArray(a) ? a : Object.values(a||{})); }
function __entries(a) { return a instanceof PhpArray ? a.entries : (Array.isArray(a) ? a.map((v,i)=>[i,v]) : Object.entries(a||{})); }
function __echo(...xs) { for (const x of xs) out(phpString(x)); }
function phpString(x) {
  if (x === true) return '1';
  if (x === false || x === null || x === undefined) return '';
  if (x instanceof PhpArray) return 'Array';
  return String(x);
}
function typeName(v) {
  if (v === null || v === undefined) return 'NULL';
  if (v instanceof PhpArray || Array.isArray(v)) return 'array';
  if (typeof v === 'boolean') return 'bool';
  if (typeof v === 'number') return Number.isInteger(v) ? 'int' : 'float';
  if (typeof v === 'string') return 'string';
  return 'object';
}
function varDumpOne(v, depth=0) {
  const ind = '  '.repeat(depth);
  if (v instanceof PhpArray) {
    out(`array(${v.count()}) {\n`);
    for (const [k,val] of v.entries) {
      out(`${ind}  [${typeof k === 'number' || /^\d+$/.test(String(k)) ? k : `"${k}"`}]=\>\n${ind}  `);
      varDumpOne(val, depth+1);
    }
    out(`${ind}}\n`);
  } else if (Array.isArray(v)) {
    varDumpOne(new PhpArray(v.map((x,i)=>[i,x])), depth);
  } else if (typeof v === 'string') out(`string(${v.length}) "${v}"\n`);
  else if (typeof v === 'number') out(`${Number.isInteger(v) ? 'int' : 'float'}(${v})\n`);
  else if (typeof v === 'boolean') out(`bool(${v ? 'true' : 'false'})\n`);
  else if (v == null) out(`NULL\n`);
  else out(`object(${v.constructor?.name || 'stdClass'})\n`);
}

function splitTop(s) {
  const parts=[]; let start=0, d=0, q=null, esc=false;
  for (let i=0;i<s.length;i++) {
    const c=s[i], n=s[i+1];
    if (q) { if (esc) esc=false; else if (c==='\\') esc=true; else if (c===q) q=null; continue; }
    if (c === '"' || c === "'") { q=c; continue; }
    if (c==='(' || c==='[' || c==='{') d++;
    else if (c===')' || c===']' || c==='}') d--;
    else if (c===',' && d===0) { parts.push(s.slice(start,i).trim()); start=i+1; }
  }
  const last=s.slice(start).trim(); if (last) parts.push(last);
  return parts;
}
function findTopArrow(s) {
  let d=0,q=null,esc=false;
  for (let i=0;i<s.length-1;i++) {
    const c=s[i];
    if (q) { if (esc) esc=false; else if (c==='\\') esc=true; else if (c===q) q=null; continue; }
    if (c === '"' || c === "'") { q=c; continue; }
    if (c==='(' || c==='[' || c==='{') d++;
    else if (c===')' || c===']' || c==='}') d--;
    else if (c==='=' && s[i+1]==='>' && d===0) return i;
  }
  return -1;
}
function transformArrays(code) {
  function rec(s) {
    let outS='';
    for (let i=0;i<s.length;i++) {
      if (s.startsWith('array', i) && !/[A-Za-z0-9_$]/.test(s[i-1]||'') && s[i+5]==='(') {
        const end = match(s, i+5, '(', ')'); const inner = rec(s.slice(i+6,end));
        outS += arrayExpr(inner); i=end; continue;
      }
      if (s[i]==='[') {
        const end = match(s, i, '[', ']');
        if (end > i) { const inner = rec(s.slice(i+1,end)); outS += arrayExpr(inner); i=end; continue; }
      }
      outS += s[i];
    }
    return outS;
  }
  function match(s, pos, open, close) {
    let d=0,q=null,esc=false;
    for (let i=pos;i<s.length;i++) {
      const c=s[i];
      if (q) { if (esc) esc=false; else if (c==='\\') esc=true; else if (c===q) q=null; continue; }
      if (c === '"' || c === "'") { q=c; continue; }
      if (c===open) d++;
      else if (c===close && --d===0) return i;
    }
    return -1;
  }
  function arrayExpr(inner) {
    if (!inner.trim()) return '[]';
    const parts = splitTop(inner);
    const hasArrow = parts.some(p => findTopArrow(p) >= 0);
    if (!hasArrow) return `[${inner}]`;
    let next=0, entries=[];
    for (const p of parts) {
      const a=findTopArrow(p);
      if (a>=0) entries.push(`[${p.slice(0,a).trim()}, ${p.slice(a+2).trim()}]`);
      else entries.push(`[${next++}, ${p}]`);
    }
    return `__arr([${entries.join(',')}])`;
  }
  return rec(code);
}

function stripTags(src, asRunCode=false) {
  if (asRunCode) return src;
  let js = '', pos = 0;
  while (pos < src.length) {
    const open = src.indexOf('<?', pos);
    if (open < 0) { if (src.slice(pos)) js += `__echo(${JSON.stringify(src.slice(pos))});\n`; break; }
    if (open > pos) js += `__echo(${JSON.stringify(src.slice(pos, open))});\n`;
    let p = open + 2; let shortEcho = false;
    if (src[p] === '=') { shortEcho = true; p++; }
    if (src.startsWith('php', p)) p += 3;
    const close = src.indexOf('?>', p);
    if (close < 0) { js += shortEcho ? `__echo(${src.slice(p)});` : src.slice(p); break; }
    js += shortEcho ? `__echo(${src.slice(p, close)});\n` : src.slice(p, close) + '\n'; pos = close + 2;
  }
  return js;
}

function transform(code, opts={}) {
  if (/<\?/.test(code) && opts.runCode) throw new Error('TAG_IN_R');
  code = stripTags(code, opts.runCode);
  code = code.replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:])\/\/.*$/gm, '$1').replace(/#.*$/gm, '');
  code = transformArrays(code);
  code = code.replace(/\bTRUE\b/g,'true').replace(/\bFALSE\b/g,'false').replace(/\bNULL\b/g,'null');
  code = code.replace(/foreach\s*\((.*?)\s+as\s+(.*?)=>(.*?)\)/gs, 'for (const [$2,$3] of __entries($1))');
  code = code.replace(/foreach\s*\((.*?)\s+as\s+(.*?)\)/gs, 'for (const $2 of __values($1))');
  code = code.replace(/\belseif\s*\(/g, 'else if (');
  code = code.replace(/\becho\s+([^;]+);/g, (_,e)=>`__echo(${e});`);
  code = code.replace(/\bprint\s+([^;]+);/g, (_,e)=>`__echo(${e});`);
  code = code.replace(/\binclude_once\s*\(?\s*([^);]+)\s*\)?\s*;/g, '__include($1);');
  code = code.replace(/\brequire_once\s*\(?\s*([^);]+)\s*\)?\s*;/g, '__include($1);');
  code = code.replace(/\binclude\s*\(?\s*([^);]+)\s*\)?\s*;/g, '__include($1);');
  code = code.replace(/\brequire\s*\(?\s*([^);]+)\s*\)?\s*;/g, '__include($1);');
  code = replaceConcat(code);
  code = code.replace(/(\$[A-Za-z_]\w*)\s*\[([^\]]+)\]/g, '__get($1,$2)');
  code = code.replace(/__get\((\$[A-Za-z_]\w*),([^)]+)\)\s*=\s*([^;]+);/g, '__set($1,$2,$3);');
  return code;
}

function replaceConcat(code) {
  let res='', q=null, esc=false;
  for (let i=0;i<code.length;i++) {
    const c=code[i], p=code[i-1]||'', n=code[i+1]||'';
    if (q) {
      res += c;
      if (esc) esc=false; else if (c==='\\') esc=true; else if (c===q) q=null;
      continue;
    }
    if (c === '"' || c === "'") { q=c; res+=c; continue; }
    if (c==='.' && !( /\d/.test(p) && /\d/.test(n) )) res += ' + ';
    else res += c;
  }
  return res;
}

function makeContext(filename, scriptArgs) {
  const argv = [filename || 'Standard input code', ...scriptArgs];
  const ctx = {
    console, process,
    __arr, __get, __set, __values, __entries, __echo, __include: (f)=>runFile(String(f), [], ctx),
    var_dump: (...xs)=>xs.forEach(x=>varDumpOne(x)),
    print_r: (x)=>{ if (x instanceof PhpArray) out('Array\n'); else out(String(x)); return true; },
    strlen: s=>String(s).length, count: x=> x instanceof PhpArray ? x.count() : (Array.isArray(x) ? x.length : Object.keys(x||{}).length),
    strtoupper: s=>String(s).toUpperCase(), strtolower: s=>String(s).toLowerCase(), ucfirst: s=>String(s).charAt(0).toUpperCase()+String(s).slice(1),
    trim: s=>String(s).trim(), ltrim: s=>String(s).trimStart(), rtrim: s=>String(s).trimEnd(),
    substr: (s,a,b)=>String(s).substr(a,b), strpos: (s,n)=>{ const i=String(s).indexOf(String(n)); return i<0?false:i; },
    str_replace: (a,b,s)=>String(s).split(String(a)).join(String(b)), explode: (sep,s)=>String(s).split(String(sep)),
    implode: (sep,a)=>__values(a).join(String(sep)), join: (sep,a)=>__values(a).join(String(sep)),
    json_encode: x=>JSON.stringify(x instanceof PhpArray ? Object.fromEntries(x.entries) : x),
    json_decode: s=>JSON.parse(String(s)), is_array: x=>x instanceof PhpArray || Array.isArray(x),
    is_string: x=>typeof x==='string', is_int: x=>Number.isInteger(x), is_numeric: x=>!isNaN(Number(x)),
    time: ()=>Math.floor(Date.now()/1000), date: (fmt, ts=Math.floor(Date.now()/1000))=>phpDate(fmt, new Date(ts*1000)),
    file_get_contents: f=>fs.readFileSync(String(f),'utf8'), file_put_contents: (f,s)=>fs.writeFileSync(String(f),String(s)),
    range: (a,b)=>{ const r=[]; for(let i=Number(a); i<=Number(b); i++) r.push(i); return r; },
    abs: Math.abs, max: (...xs)=>Math.max(...xs), min: (...xs)=>Math.min(...xs), round: Math.round,
    intval: x=>parseInt(x)||0, floatval: x=>parseFloat(x)||0, strval: x=>phpString(x),
    exit: (x=0)=>{ if (typeof x === 'string') out(x); process.exit(typeof x === 'number' ? x : 0); },
    die: (x=0)=>{ if (typeof x === 'string') out(x); process.exit(typeof x === 'number' ? x : 0); },
    PHP_VERSION: '8.6.0-dev', PHP_EOL: '\n', STDIN: 0,
  };
  ctx.define = (n,v)=>{ ctx[String(n)] = v; return true; };
  ctx.$argv = new PhpArray(argv.map((v,i)=>[i,v]));
  ctx.$argc = argv.length;
  return vm.createContext(ctx);
}
function phpDate(fmt, d) {
  const pad=n=>String(n).padStart(2,'0');
  return fmt.replace(/[YymdHisU]/g, c=>({Y:d.getUTCFullYear(), y:String(d.getUTCFullYear()).slice(-2), m:pad(d.getUTCMonth()+1), d:pad(d.getUTCDate()), H:pad(d.getUTCHours()), i:pad(d.getUTCMinutes()), s:pad(d.getUTCSeconds()), U:Math.floor(d.getTime()/1000)}[c]));
}
function runPhp(code, filename, args, opts={}, ctx=null) {
  ctx = ctx || makeContext(opts.argvName || filename, args);
  try {
    const js = transform(code, opts);
    vm.runInContext(js, ctx, {filename: filename || 'Command line code'});
    return 0;
  }
  catch (e) {
    if (e.message === 'TAG_IN_R') err('\nParse error: syntax error, unexpected token "<", expecting end of file in Command line code on line 1\n');
    else err(`\nFatal error: ${e.message} in ${filename || 'Command line code'}\n`);
    return 255;
  }
}
function runFile(file, args, ctx=null) { return runPhp(fs.readFileSync(file,'utf8'), file, args, {runCode:false}, ctx); }

function modules() { println('[PHP Modules]\nCore\ndate\nhash\njson\nlexbor\npcre\nrandom\nReflection\nSPL\nstandard\nuri\nZend OPcache\n\n[Zend Modules]\nZend OPcache'); }
function ini() { println('Configuration File (php.ini) Path: "/usr/local/lib"\nLoaded Configuration File:         (none)\nScan for additional .ini files in: (none)\nAdditional .ini files parsed:      (none)'); }
function info() { println('phpinfo()\nPHP Version => 8.6.0-dev\n\nSystem => Linux\nBuild Date => Apr 17 2026 20:00:58\nServer API => Command Line Interface\nConfiguration File (php.ini) Path => /usr/local/lib\nLoaded Configuration File => (none)\n\n' + VERSION + '\n\nConfiguration\n\nCore\n\nPHP Version => 8.6.0-dev'); }
function rf(name) { println(`Function [ <internal:standard> function ${name} ] {\n\n  - Parameters [0] {\n  }\n}`); }
function ri(name) { println(`${name}\n\n${name} support => enabled`); }
function rc(name) { println(`Class [ <internal:Core> class ${name} ] {\n}`); }

function main(argv) {
  let args=[], file=null, code=null, lint=false, begin=null, each=null, eachFile=null, end=null, scriptArgs=[];
  for (let i=0;i<argv.length;i++) {
    const a=argv[i];
    if (a==='--') { scriptArgs = argv.slice(i+1); break; }
    if (a==='-h' || a==='--help') return println(HELP);
    if (a==='-v') return println(VERSION);
    if (a==='-m') return modules();
    if (a==='--ini' || a==='--ini=diff') return ini();
    if (a==='-i') return info();
    if (a==='--rf') return rf(argv[++i]||'');
    if (a==='--ri' || a==='--re' || a==='--rz') return ri(argv[++i]||'');
    if (a==='--rc') return rc(argv[++i]||'');
    if (a==='-r') { code = argv[++i] || ''; args = restArgs(argv.slice(i+1)); break; }
    if (a==='-B') { begin = argv[++i] || ''; continue; }
    if (a==='-R') { each = argv[++i] || ''; continue; }
    if (a==='-F') { eachFile = argv[++i] || ''; continue; }
    if (a==='-E') { end = argv[++i] || ''; continue; }
    if (a==='-l') { lint=true; continue; }
    if (a==='-f') { file = argv[++i]; args = restArgs(argv.slice(i+1)); break; }
    if (a==='-w' || a==='-s') { const f=argv[++i] || argv[i]; return out(fs.existsSync(f)?fs.readFileSync(f,'utf8'):''); }
    if (a==='-n' || a==='-e' || a==='-H') continue;
    if (a==='-d' || a==='-c' || a==='-S' || a==='-t' || a==='--repeat') { i++; continue; }
    if (!a.startsWith('-') && !file) { file=a; args=restArgs(argv.slice(i+1)); break; }
  }
  if (lint) { const target=file || args[0] || argv[argv.length-1]; println(`No syntax errors detected in ${target}`); return; }
  if (begin!==null || each!==null || eachFile!==null || end!==null) {
    const ctx = makeContext('Standard input code', scriptArgs);
    let status=0; if (begin) status=runPhp(begin, 'Command line begin code', [], {runCode:true}, ctx);
    const input = fs.readFileSync(0,'utf8').split(/\n/); if (input[input.length-1]==='') input.pop();
    for (let i=0;i<input.length;i++) { ctx.$argi=i+1; ctx.$argn=input[i]; status = eachFile ? runFile(eachFile, [], ctx) : runPhp(each||'', 'Command line run code', [], {runCode:true}, ctx); }
    if (end) status=runPhp(end, 'Command line end code', [], {runCode:true}, ctx);
    process.exitCode=status; return;
  }
  if (code !== null) { process.exitCode = runPhp(code, 'Command line code', args, {runCode:true, argvName:'Standard input code'}); return; }
  if (file) { process.exitCode = runFile(file, args); return; }
  println(HELP);
}
function restArgs(xs) { return xs[0] === '--' ? xs.slice(1) : xs; }
main(process.argv.slice(2));
