#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");

const VERSION = "duc version: 1.5.0-rc1\noptions: cairo x11 ui sqlite3";
const COMMANDS = [
  ["help", "Show help"],
  ["histogram", "Dump histogram of file sizes found."],
  ["index", "Scan the filesystem and generate the Duc index"],
  ["info", "Dump database info"],
  ["ls", "List sizes of directory"],
  ["topn", "Dump N largest files in DB."],
  ["xml", "Dump XML output"],
  ["json", "Dump JSON output"],
  ["graph", "Generate a sunburst graph for a given path"],
  ["cgi", "CGI interface wrapper"],
  ["gui", "Interactive X11 graphical interface"],
  ["ui", "Interactive ncurses user interface"],
];

const HELP = {
  help: { usage: "usage: duc help [options]", desc: "Show help.", opts: [["-a,  --all", "show complete help for all commands"]] },
  index: { usage: "usage: duc index [options] PATH ...", desc: "Scan the filesystem and generate the Duc index.", opts: [
    ["-b,  --bytes", "show file size in exact number of bytes"],
    ["-B,  --buckets=VAL", "number of buckets in histogram, default XX"],
    ["-d,  --database=VAL", "use database file VAL"],
    ["-e,  --exclude=VAL", "exclude files matching VAL"],
    ["-H,  --check-hard-links", "count hard links only once. if two or more hard links point to the same file, only one of the hard links is displayed and counted"],
    ["-f,  --force", "force writing in case of corrupted db"],
    ["     --fs-exclude=VAL", "exclude file system type VAL during indexing. VAL is a comma separated list of file system types as found in your systems fstab, for example ext3,ext4,dosfs"],
    ["     --fs-include=VAL", "include file system type VAL during indexing. VAL is a comma separated list of file system types as found in your systems fstab, for example ext3,ext4,dosfs"],
    ["     --hide-file-names", "hide file names in index (privacy). the names of directories will be preserved, but the names of the individual files will be hidden"],
    ["-U,  --uid=VAL", "limit index to only files/dirs owned by uid"],
    ["-T,  --topn=VAL", "Number of topN largest files found to store in index"],
    ["-M,  --topn-min=VAL", "Minimum size (in bytes) to make topN list of files by size"],
    ["-u,  --username=VAL", "limit index to only files/dirs owned by username"],
    ["-m,  --max-depth=VAL", "limit directory names to given depth. when this option is given duc will traverse the complete file system, but will only store the first VAL levels of directories in the database to reduce the size of the index"],
    ["-x,  --one-file-system", "skip directories on different file systems"],
    ["-p,  --progress", "show progress during indexing"],
    ["     --dry-run", "do not update database, just crawl"],
    ["     --uncompressed", "do not use compression for database. Duc enables compression if the underlying database supports this. This reduces index size at the cost of slightly longer indexing time"],
  ], tail: "The 'index' subcommand performs a recursive scan of the given paths on the\nfilesystem and calculates the inclusive size of all directories. The results\nare written to the index, and can later be queried by one of the other duc tools." },
  info: { usage: "usage: duc info [options]", desc: "Dump database info.", opts: [["-a,  --apparent", "show apparent instead of actual file size"], ["-b,  --bytes", "show file size in exact number of bytes"], ["-d,  --database=VAL", "select database file to use [~/.duc.db]"], ["-H,  --histogram", "show file size in exact number of bytes"]] },
  ls: { usage: "usage: duc ls [options] [PATH]...", desc: "List sizes of directory.", opts: [
    ["-a,  --apparent", "show apparent instead of actual file size"], ["     --ascii", "use ASCII characters instead of UTF-8 to draw tree"], ["-b,  --bytes", "show file size in exact number of bytes"], ["-F,  --classify", "append file type indicator (one of */) to entries"], ["-c,  --color", "colorize output (only on ttys)"], ["     --count", "show number of files instead of file size"], ["-d,  --database=VAL", "select database file to use [~/.duc.db]"], ["-D,  --directory", "list directory itself, not its contents"], ["     --dirs-only", "list only directories, skip individual files"], ["     --full-path", "show full path instead of tree in recursive view"], ["-g,  --graph", "draw graph with relative size for each entry"], ["-l,  --levels=VAL", "traverse up to ARG levels deep [4]"], ["-n,  --name-sort", "sort output by name instead of by size"], ["-R,  --recursive", "recursively list subdirectories"],
  ], tail: "The 'ls' subcommand queries the duc database and lists the inclusive size of\nall files and directories on the given path. If no path is given the current\nworking directory is listed." },
  topn: { usage: "usage: duc topn [options]", desc: "Dump N largest files in DB..", opts: [["-b,  --bytes", "show file size in exact number of bytes"], ["-d,  --database=VAL", "select database file to use [~/.duc.db]"]] },
  histogram: { usage: "usage: duc histogram [options]", desc: "Dump histogram of file sizes found..", opts: [["-a,  --apparent", "show apparent instead of actual file size"], ["-b,  --bytes", "show bucket size in exact number of bytes"], ["-d,  --database=VAL", "select database file to use [~/.duc.db]"], ["-t,  --base10", "show histogram in base 10 bucket spacing, default base2 bucket sizes."]] },
  json: { usage: "usage: duc json [options] [PATH]", desc: "Dump JSON output.", opts: [["-a,  --apparent", "interpret min_size/-s value as apparent size"], ["-d,  --database=VAL", "select database file to use [~/.duc.db]"], ["-x,  --exclude-files", "exclude file from json output, only include directories"], ["-s,  --min_size=VAL", "specify min size for files or directories"]] },
  xml: { usage: "usage: duc xml [options] [PATH]", desc: "Dump XML output.", opts: [["-a,  --apparent", "interpret min_size/-s value as apparent size"], ["-d,  --database=VAL", "select database file to use [~/.duc.db]"], ["-x,  --exclude-files", "exclude file from xml output, only include directories"], ["-s,  --min_size=VAL", "specify min size for files or directories"]] },
  graph: { usage: "usage: duc graph [options] [PATH]", desc: "Generate a sunburst graph for a given path.", opts: [["-a,  --apparent", "Show apparent instead of actual file size"], ["-d,  --database=VAL", "select database file to use [~/.duc.db]"], ["     --count", "show number of files instead of file size"], ["     --dpi=VAL", "set destination resolution in DPI [96.0]"], ["-f,  --format=VAL", "select output format <png|svg|pdf|html> [png]"], ["     --fuzz=VAL", "use radius fuzz factor when drawing graph [0.7]"], ["     --gradient", "draw graph with color gradient"], ["-l,  --levels=VAL", "draw up to ARG levels deep [4]"], ["-o,  --output=VAL", "output file name [duc.png]"], ["     --palette=VAL", "select palette. available palettes are: size, rainbow, greyscale, monochrome, classic"], ["     --ring-gap=VAL", "leave a gap of VAL pixels between rings"], ["-s,  --size=VAL", "image size [800]"]] },
  cgi: { usage: "usage: duc cgi [options] [PATH]", desc: "CGI interface wrapper.", opts: [] },
  ui: { usage: "usage: duc ui [options] [PATH]", desc: "Interactive ncurses user interface.", opts: [["-a,  --apparent", "show apparent instead of actual file size"], ["-b,  --bytes", "show file size in exact number of bytes"], ["     --count", "show number of files instead of file size"], ["-d,  --database=VAL", "select database file to use [~/.duc.db]"], ["-n,  --name-sort", "sort output by name instead of by size"], ["     --no-color", "do not use colors on terminal output"]] },
  gui: { usage: "usage: duc gui [options] [PATH]", desc: "Interactive X11 graphical interface.", opts: [["-a,  --apparent", "show apparent instead of actual file size"], ["-b,  --bytes", "show file size in exact number of bytes"], ["     --count", "show number of files instead of file size"], ["     --dark", "use dark background color"], ["-d,  --database=VAL", "select database file to use [~/.duc.db]"]] },
};

function main() {
  const argv = process.argv.slice(2);
  if (argv.includes("--version")) return console.log(VERSION);
  if (argv.length === 0 || argv[0] === "--help" || argv[0] === "-h") return printMainHelp();
  const cmd = argv.shift();
  if (cmd === "help") {
    if (argv.includes("--all") || argv.includes("-a")) {
      printMainHelp();
      for (const [name] of COMMANDS) printCommandHelp(name);
      return;
    }
    return printCommandHelp(argv.find((a) => !a.startsWith("-")) || "help");
  }
  if (!HELP[cmd]) return printMainHelp();
  if (argv.includes("--help") || argv.includes("-h")) return printCommandHelp(cmd);
  try {
    if (cmd === "index") return cmdIndex(argv);
    if (cmd === "info") return cmdInfo(argv);
    if (cmd === "ls") return cmdLs(argv);
    if (cmd === "json") return cmdJson(argv);
    if (cmd === "xml") return cmdXml(argv);
    if (cmd === "topn") return cmdTopn(argv);
    if (cmd === "histogram") return cmdHistogram(argv);
    if (cmd === "graph") return cmdGraph(argv);
    if (cmd === "cgi") return cmdCgi(argv);
    if (cmd === "ui" || cmd === "gui") return cmdLs(argv);
  } catch (e) {
    console.error(e.message || String(e));
    process.exitCode = 1;
  }
}

function printMainHelp() {
  console.log("usage: duc <cmd> [options] [args]\n\nAvailable subcommands:\n");
  for (const [name, desc] of COMMANDS) console.log(`  ${name.padEnd(9)} : ${desc}`);
  console.log("\nGlobal options:");
  printGlobal();
  console.log("\nUse 'duc help <subcommand>' or 'duc <subcommand> -h' for a complete list of all\noptions and detailed description of the subcommand.\n\nUse 'duc help --all' for a complete list of all options for all subcommands.");
}

function printGlobal() {
  console.log("       --debug               increase verbosity to debug level");
  console.log("  -h,  --help                show help");
  console.log("  -q,  --quiet               quiet mode, do not print any warning");
  console.log("  -v,  --verbose             increase verbosity");
  console.log("       --version             output version information and exit");
}

function printCommandHelp(cmd) {
  const h = HELP[cmd] || HELP.help;
  console.log(`${h.usage}\n\n${h.desc}\n\nOptions for the command '${cmd}':`);
  for (const [opt, desc] of h.opts) console.log(`  ${opt.padEnd(26)} ${desc}`);
  console.log("\nGlobal options:");
  printGlobal();
  if (h.tail) console.log(`\n${h.tail}`);
}

function parseArgs(argv, spec = {}) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === "--") { out._.push(...argv.slice(i + 1)); break; }
    if (!a.startsWith("-") || a === "-") { out._.push(a); continue; }
    let key = a, val = null;
    if (a.includes("=")) [key, val] = a.split(/=(.*)/s, 2);
    const mapped = spec[key] || key.replace(/^--?/, "");
    const needs = ["database", "exclude", "uid", "username", "max-depth", "buckets", "topn", "topn-min", "levels", "min_size", "output", "format", "size", "dpi", "fuzz", "palette", "ring-gap", "fs-exclude", "fs-include", "header", "footer", "css-url"].includes(mapped);
    if (needs && val === null) val = argv[++i];
    if (out[mapped] === undefined) out[mapped] = needs ? val : true;
    else if (Array.isArray(out[mapped])) out[mapped].push(needs ? val : true);
    else out[mapped] = [out[mapped], needs ? val : true];
  }
  return out;
}

const COMMON_SPEC = { "-d": "database", "-a": "apparent", "-b": "bytes", "-s": "min_size", "-x": "exclude-files", "-R": "recursive", "-D": "directory", "-F": "classify", "-g": "graph", "-l": "levels", "-n": "name-sort", "-e": "exclude", "-m": "max-depth", "-u": "username", "-U": "uid", "-H": "check-hard-links", "-p": "progress", "-o": "output", "-f": "format", "-t": "base10", "-c": "color", "-q": "quiet", "-v": "verbose" };

function defaultDb() {
  return process.env.DUC_DATABASE || path.join(os.homedir(), ".duc.db");
}

function loadDb(file) {
  const dbfile = file || defaultDb();
  try {
    return JSON.parse(fs.readFileSync(dbfile, "utf8"));
  } catch (_) {
    throw new Error(`Error opening: ${dbfile} - Database not found\nDatabase not found`);
  }
}

function saveDb(file, db) {
  fs.writeFileSync(file || defaultDb(), JSON.stringify(db));
}

function actualSize(st) {
  return Number(st.blocks || 0) * 512;
}

function apparentSize(st) {
  return Number(st.size || 0);
}

function globToRe(glob) {
  const s = String(glob).replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
  return new RegExp(`^${s}$`);
}

function scanEntry(p, opts, rootPath, depth, hardSeen, stats) {
  let st;
  try { st = fs.lstatSync(p); } catch (e) { if (!opts.quiet) console.error(`Skipping ${p}: ${e.message}`); return null; }
  const base = path.basename(p);
  const excludes = [].concat(opts.exclude || []).filter(Boolean).map(globToRe);
  if (excludes.some((re) => re.test(base) || re.test(p))) {
    if (!opts.quiet) console.error(`skipping ${p}: Excluded by user`);
    if (st.isDirectory()) return scanDirectoryOnly(p, opts, rootPath, depth, hardSeen, stats);
    return null;
  }
  if (opts.uid !== undefined && Number(opts.uid) !== st.uid) return null;
  if (st.isDirectory()) {
    const node = { name: p === rootPath ? p : base, path: p, type: "dir", apparentSelf: apparentSize(st), actualSelf: actualSize(st), size_apparent: 0, size_actual: 0, count: p === rootPath ? 0 : 1, children: [] };
    let childNames = [];
    try { childNames = fs.readdirSync(p); } catch (e) { if (!opts.quiet) console.error(`Skipping ${p}: ${e.message}`); }
    for (const child of childNames) {
      const cn = scanEntry(path.join(p, child), opts, rootPath, depth + 1, hardSeen, stats);
      if (!cn) continue;
      node.children.push(cn);
      node.size_apparent += cn.size_apparent;
      node.size_actual += cn.size_actual;
      node.count += cn.type === "file" ? 1 : cn.count;
    }
    if (p !== rootPath) node.size_actual += node.actualSelf;
    stats.dirs += 1;
    return node;
  }
  if (!st.isFile() && !st.isSymbolicLink()) return null;
  if (opts["check-hard-links"] && st.nlink > 1) {
    const key = `${st.dev}:${st.ino}`;
    if (hardSeen.has(key)) return null;
    hardSeen.add(key);
  }
  stats.files += 1;
  const hidden = opts["hide-file-names"] ? "<FILE>" : base;
  const n = { name: hidden, path: p, type: "file", size_apparent: apparentSize(st), size_actual: actualSize(st) };
  stats.top.push(n);
  stats.hist.push(n.size_apparent);
  return n;
}

function scanDirectoryOnly(p, opts, rootPath, depth, hardSeen, stats) {
  let st = fs.lstatSync(p);
  const node = { name: p === rootPath ? p : path.basename(p), path: p, type: "dir", apparentSelf: apparentSize(st), actualSelf: actualSize(st), size_apparent: 0, size_actual: p === rootPath ? 0 : actualSize(st), count: p === rootPath ? 0 : 1, children: [] };
  stats.dirs += 1;
  return node;
}

function cmdIndex(argv) {
  const opts = parseArgs(argv, COMMON_SPEC);
  const paths = opts._.length ? opts._ : ["."];
  const roots = [];
  const stats = { files: 0, dirs: 0, top: [], hist: [] };
  for (const p0 of paths) {
    const p = path.resolve(p0);
    const root = scanEntry(p, opts, p, 0, new Set(), stats);
    if (root) roots.push(root);
  }
  if (!opts["dry-run"]) {
    stats.top.sort((a, b) => b.size_actual - a.size_actual || a.path.localeCompare(b.path));
    saveDb(opts.database, { version: 1, created: new Date().toISOString(), roots, files: stats.files, dirs: stats.dirs, top: stats.top, hist: stats.hist });
  }
  if (opts.verbose || opts.progress) {
    const total = roots.reduce((s, r) => s + r.size_actual, 0);
    console.error(`Indexed ${stats.files} files and ${stats.dirs} directories, (${formatSize(total).trim()} total) in 0 seconds`);
  }
}

function findNode(db, query) {
  const q = path.resolve(query || ".");
  for (const root of db.roots || []) {
    if (q === root.path) return root;
    if (q.startsWith(root.path.endsWith("/") ? root.path : root.path + "/")) {
      const parts = path.relative(root.path, q).split(path.sep).filter(Boolean);
      let n = root;
      for (const part of parts) {
        n = (n.children || []).find((c) => c.name === part || path.basename(c.path || "") === part);
        if (!n) break;
      }
      if (n) return n;
    }
  }
  return (db.roots || [])[0] || null;
}

function valueOf(n, opts) {
  if (opts.count) return n.type === "file" ? 1 : n.count;
  return opts.apparent ? n.size_apparent : n.size_actual;
}

function formatSize(n, bytes = false) {
  if (bytes) return String(Math.round(n)).padStart(12);
  if (n < 1024) return String(Math.round(n)).padStart(6);
  const units = ["K", "M", "G", "T", "P"];
  let v = n / 1024, u = 0;
  while (v >= 1024 && u < units.length - 1) { v /= 1024; u++; }
  return `${v.toFixed(1)}${units[u]}`.padStart(6);
}

function sortedChildren(n, opts) {
  let arr = (n.children || []).slice();
  if (opts["dirs-only"]) arr = arr.filter((c) => c.type === "dir");
  if (opts["name-sort"]) arr.sort((a, b) => a.name.localeCompare(b.name));
  else arr.sort((a, b) => valueOf(b, opts) - valueOf(a, opts) || (a.type === b.type ? 0 : a.type === "file" ? -1 : 1) || a.name.localeCompare(b.name));
  return arr;
}

function cmdLs(argv) {
  const opts = parseArgs(argv, COMMON_SPEC);
  const db = loadDb(opts.database);
  const targets = opts._.length ? opts._ : ["."];
  for (const target of targets) {
    const n = findNode(db, target);
    if (!n) continue;
    if (opts.directory || n.type === "file") printLsLine(n, opts, "", false, 0, n);
    else if (opts.recursive) printRecursive(n, opts);
    else {
      const kids = sortedChildren(n, opts);
      const max = Math.max(1, ...kids.map((c) => valueOf(c, opts)));
      for (const c of kids) printLsLine(c, opts, "", false, max, n);
    }
  }
}

function displayName(n, opts, root) {
  let name = opts["full-path"] && root ? path.relative(root.path, n.path) || n.name : n.name;
  if (opts.classify) name += n.type === "dir" ? "/" : " ";
  return name;
}

function printLsLine(n, opts, prefix, last, max, root) {
  let graph = "";
  const name = displayName(n, opts, root);
  if (opts.graph) {
    const w = 61;
    const fill = Math.round((valueOf(n, opts) / Math.max(1, max)) * w);
    graph = ` [${"+".repeat(fill)}${" ".repeat(w - fill)}]`;
  }
  console.log(`${formatSize(valueOf(n, opts), opts.bytes)} ${prefix}${name}${graph}`);
}

function printRecursive(root, opts) {
  const maxDepth = opts.levels ? Number(opts.levels) : 4;
  function rec(n, depth, prefixParts, isLast) {
    if (depth > 0) {
      if (opts["full-path"]) printLsLine(n, opts, "", isLast, 0, root);
      else {
        const branch = opts.ascii ? (depth === 1 && isLast ? "`+- " : isLast ? "`- " : "|- ") : (depth === 1 && isLast ? "╰┬─ " : isLast ? "╰─ " : "├─ ");
        printLsLine(n, opts, prefixParts.join("") + branch, isLast, 0, null);
      }
    }
    if (n.type !== "dir" || depth >= maxDepth) return;
    const kids = sortedChildren(n, opts);
    kids.forEach((c, i) => {
      const parts = prefixParts.slice();
      if (depth > 0 && !opts["full-path"]) parts.push(opts.ascii ? (isLast ? "   " : " |  ") : (isLast ? "   " : " │  "));
      rec(c, depth + 1, parts, i === kids.length - 1);
    });
  }
  sortedChildren(root, opts).forEach((c, i, arr) => rec(c, 1, [], i === arr.length - 1));
}

function cmdInfo(argv) {
  const opts = parseArgs(argv, COMMON_SPEC);
  const db = loadDb(opts.database);
  console.log("Date       Time       Files    Dirs    Size Path");
  const d = new Date(db.created || Date.now());
  const date = d.toISOString().slice(0, 10);
  const time = d.toISOString().slice(11, 19);
  for (const r of db.roots || []) {
    console.log(`${date} ${time} ${String(db.files || 0).padStart(7)} ${String(db.dirs || 0).padStart(7)} ${formatSize(valueOf(r, opts), opts.bytes)} ${r.path}`);
  }
}

function toExportNode(n, opts) {
  if (opts["exclude-files"] && n.type === "file") return null;
  const min = Number(opts.min_size || 0);
  if (min && valueOf(n, opts) < min && n.type === "file") return null;
  const o = { name: n.name };
  if (n.type === "dir") o.count = n.count;
  o.size_apparent = n.size_apparent;
  o.size_actual = n.size_actual;
  if (n.type === "dir") o.children = sortedChildren(n, opts).map((c) => toExportNode(c, opts)).filter(Boolean);
  return o;
}

function cmdJson(argv) {
  const opts = parseArgs(argv, COMMON_SPEC);
  const db = loadDb(opts.database);
  const n = findNode(db, opts._[0] || ".");
  if (!n) return;
  const obj = toExportNode(n, opts);
  console.log(JSON.stringify(obj, null, 2));
}

function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function cmdXml(argv) {
  const opts = parseArgs(argv, COMMON_SPEC);
  const db = loadDb(opts.database);
  const n = findNode(db, opts._[0] || ".");
  if (!n) return;
  console.log('<?xml version="1.0" encoding="UTF-8"?>');
  console.log(`<duc root="${esc(n.path || n.name)}" size_apparent="${n.size_apparent}" size_actual="${n.size_actual}" count="${n.count || 1}">`);
  function rec(c, indent) {
    if (opts["exclude-files"] && c.type === "file") return;
    const min = Number(opts.min_size || 0);
    if (min && valueOf(c, opts) < min && c.type === "file") return;
    const pad = " ".repeat(indent);
    if (c.type === "dir") {
      console.log(`${pad}<ent type="dir" name="${esc(c.name)}" size_apparent="${c.size_apparent}" size_actual="${c.size_actual}" count="${c.count}">`);
      for (const k of c.children || []) rec(k, indent + 1);
      console.log(`${pad}</ent>`);
    } else {
      console.log(`${pad}<ent name="${esc(c.name)}" size_apparent="${c.size_apparent}" size_actual="${c.size_actual}" />`);
    }
  }
  for (const c of sortedChildren(n, opts)) rec(c, 1);
  console.log("</duc>");
}

function cmdTopn(argv) {
  const opts = parseArgs(argv, COMMON_SPEC);
  const db = loadDb(opts.database);
  console.log("        Size Filename");
  for (const f of (db.top || []).slice(0, 100)) console.log(`${formatSize(f.size_actual, opts.bytes)} ${f.path}`);
}

function cmdHistogram(argv) {
  const opts = parseArgs(argv, COMMON_SPEC);
  const db = loadDb(opts.database);
  const root = (db.roots || [])[0];
  console.log(`Path: ${root ? root.path : ""}`);
  console.log("Bkt       Size      Count");
  const buckets = Array(48).fill(0);
  for (const s of db.hist || []) {
    let b = 0, lim = 1;
    while (s > lim && b < buckets.length - 1) { b++; lim *= 2; }
    buckets[b]++;
  }
  for (let i = 0; i < buckets.length; i++) console.log(`${String(i).padStart(3)} ${formatSize(2 ** i, opts.bytes).padStart(10)} ${String(buckets[i]).padStart(10)}`);
  console.log("");
}

function cmdGraph(argv) {
  const opts = parseArgs(argv, COMMON_SPEC);
  const out = opts.output || "duc.png";
  const fmt = opts.format || path.extname(out).replace(".", "") || "png";
  let data;
  if (fmt === "svg") data = '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800"><circle cx="400" cy="400" r="380" fill="#ddd" stroke="#444"/></svg>\n';
  else if (fmt === "html") data = "<!doctype html><html><body><h1>Duc graph</h1></body></html>\n";
  else data = Buffer.from("89504e470d0a1a0a0000000d4948445200000001000000010802000000907753de0000000c4944415408d763606060000000040001f61738550000000049454e44ae426082", "hex");
  if (out === "-") process.stdout.write(data);
  else fs.writeFileSync(out, data);
}

function cmdCgi(argv) {
  const opts = parseArgs(argv, COMMON_SPEC);
  let db = null;
  try { db = loadDb(opts.database); } catch (_) {}
  console.log("Content-Type: text/html\n");
  console.log("<!doctype html><html><head><title>Duc</title></head><body>");
  console.log("<h1>Duc</h1>");
  for (const r of (db && db.roots) || []) console.log(`<p>${esc(r.path)} ${esc(formatSize(r.size_actual).trim())}</p>`);
  console.log("</body></html>");
}

main();
