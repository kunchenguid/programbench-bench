#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const HELP = `Usage: executable [<files> ...] [flags]

Chroma is a general purpose syntax highlighting library and corresponding
command, for Go.

Arguments:
  [<files> ...]    Files to highlight.

Flags:
  -h, --help               Show context-sensitive help.
      --version            Show version.
      --list               List lexers, styles and formatters.
      --unbuffered         Do not buffer output.
      --trace              Trace lexer states as they are traversed.
      --check              Do not format, check for tokenisation errors instead.
      --filename=STRING    Filename to use for selecting a lexer when reading
                           from stdin.
      --fail               Exit silently with status 1 if no specific lexer was
                           found.

Select lexer and style:
  -l, --lexer="autodetect"    Lexer to use when formatting or path to an XML
                              file to load.
  -s, --style="swapoff"       Style to use for formatting or path to an XML file
                              to load.

Output format:
  -f, --formatter="terminal"    Formatter to use.
      --json                    Convenience flag to use JSON formatter.
      --html                    Convenience flag to use HTML formatter.
      --svg                     Convenience flag to use SVG formatter.

HTML formatter options:
  --html-prefix=PREFIX             HTML CSS class prefix.
  --html-styles                    Output HTML CSS styles.
  --html-all-styles                Output all HTML CSS styles, including
                                   redundant ones.
  --html-only                      Output HTML fragment.
  --html-inline-styles             Output HTML with inline styles (no classes).
  --html-tab-width=8               Set the HTML tab width.
  --html-lines                     Include line numbers in output.
  --html-lines-table               Split line numbers and code in a HTML table
  --html-lines-style=STRING        Style for line numbers.
  --html-highlight=N[:M][,...]     Highlight these lines.
  --html-highlight-style=STRING    Style used for highlighting lines.
  --html-base-line=1               Base line number.
  --html-prevent-surrounding-pre
                                   Prevent the surrounding pre tag.
  --html-linkable-lines            Make the line numbers linkable and be a link
                                   to themselves.
`;

const LEXERS = [
  ['ABAP', 'abap', '*.abap *.ABAP', 'text/x-abap'],
  ['Bash', 'bash sh ksh zsh shell', '*.sh *.bash .bashrc bashrc', 'application/x-sh application/x-shellscript'],
  ['C', 'c', '*.c *.h', 'text/x-chdr text/x-csrc'],
  ['C#', 'csharp c#', '*.cs', 'text/x-csharp'],
  ['C++', 'cpp c++', '*.cpp *.hpp *.cc *.hh *.cxx *.hxx *.C *.H', 'text/x-c++hdr text/x-c++src'],
  ['CSS', 'css', '*.css', 'text/css'],
  ['Diff', 'diff udiff', '*.diff *.patch', 'text/x-diff'],
  ['Docker', 'docker dockerfile', 'Dockerfile*', 'text/x-dockerfile-config'],
  ['Go', 'go golang', '*.go', 'text/x-gosrc'],
  ['HTML', 'html', '*.html *.htm *.xhtml', 'text/html'],
  ['INI', 'ini cfg dosini', '*.ini *.cfg', 'text/x-ini'],
  ['Java', 'java', '*.java', 'text/x-java'],
  ['JavaScript', 'js javascript', '*.js *.jsm *.mjs *.cjs', 'application/javascript text/javascript'],
  ['JSON', 'json', '*.json', 'application/json'],
  ['Lua', 'lua', '*.lua', 'text/x-lua'],
  ['Makefile', 'make makefile mf bsdmake', 'Makefile makefile GNUmakefile *.mak', 'text/x-makefile'],
  ['markdown', 'markdown md', '*.md *.markdown *.mkd', 'text/x-markdown'],
  ['Perl', 'perl pl', '*.pl *.pm *.t', 'text/x-perl'],
  ['PHP', 'php php3 php4 php5', '*.php *.php3 *.php4 *.php5', 'text/x-php'],
  ['plaintext', 'text plain no-highlight', '*.txt', 'text/plain'],
  ['Python', 'python py sage', '*.py *.pyw', 'text/x-python'],
  ['Ruby', 'ruby rb', '*.rb *.rbw Rakefile Gemfile', 'text/x-ruby'],
  ['Rust', 'rust rs', '*.rs', 'text/rust'],
  ['SQL', 'sql', '*.sql', 'text/x-sql'],
  ['TOML', 'toml', '*.toml', 'text/x-toml'],
  ['TypeScript', 'ts typescript', '*.ts *.tsx', 'application/typescript'],
  ['XML', 'xml', '*.xml *.xsl *.rss *.svg', 'text/xml application/xml image/svg+xml'],
  ['YAML', 'yaml yml', '*.yaml *.yml', 'text/x-yaml'],
  ['Zig', 'zig', '*.zig *.zon', 'text/zig'],
];

const STYLES = 'abap algol algol_nu arduino ashen aura-theme-dark aura-theme-dark-soft autumn average base16-snazzy borland bw catppuccin-frappe catppuccin-latte catppuccin-macchiato catppuccin-mocha colorful darcula doom-one doom-one2 dracula emacs evergarden friendly fruity github github-dark gruvbox gruvbox-light hr_high_contrast hrdark igor kanagawa-dragon kanagawa-lotus kanagawa-wave lovelace manni modus-operandi modus-vivendi monokai monokailight murphy native nord nordic onedark onesenterprise paraiso-dark paraiso-light pastie perldoc pygments rainbow_dash rose-pine rose-pine-dawn rose-pine-moon rpgle rrt solarized-dark solarized-dark256 solarized-light swapoff tango tokyonight-day tokyonight-moon tokyonight-night tokyonight-storm trac vim vs vulcan witchhazel xcode xcode-dark'.split(' ');
const FORMATTERS = ['html', 'json', 'noop', 'svg', 'terminal', 'terminal16', 'terminal16m', 'terminal256', 'terminal8', 'tokens'];
const STYLE_OK = new Set(STYLES.filter(s => s !== 'swapoff'));
const KNOWN_LEXERS = new Set(['go','golang','python','py','javascript','js','typescript','ts','rust','rs','c','cpp','c++','java','bash','sh','ruby','rb','json','html','xml','css','yaml','yml','toml','ini','makefile','markdown','md','php','perl','pl','lua','zig','sql','diff','plaintext','text','plain']);

function die(msg, code = 80) {
  process.stderr.write(`executable: error: ${msg}\n`);
  process.exit(code);
}

function parseArgs(argv) {
  const opts = {
    files: [], lexer: 'autodetect', style: 'swapoff', formatter: 'terminal',
    filename: '', fail: false, check: false, list: false, htmlStyles: false,
    htmlOnly: false, htmlLines: false, htmlInline: false, htmlPrefix: '',
    htmlBaseLine: 1, svg: false,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const need = (name) => {
      if (i + 1 >= argv.length) die(`${name}: expected argument`);
      return argv[++i];
    };
    if (a === '-h' || a === '--help') { process.stdout.write(HELP); process.exit(0); }
    else if (a === '--version') { process.stdout.write('?-?-?\n'); process.exit(0); }
    else if (a === '--list') opts.list = true;
    else if (a === '--unbuffered' || a === '--trace') {}
    else if (a === '--check') opts.check = true;
    else if (a === '--fail') opts.fail = true;
    else if (a === '--json') opts.formatter = 'json';
    else if (a === '--html') opts.formatter = 'html';
    else if (a === '--svg') opts.formatter = 'svg';
    else if (a === '--html-styles' || a === '--html-all-styles') opts.htmlStyles = true;
    else if (a === '--html-only') opts.htmlOnly = true;
    else if (a === '--html-lines' || a === '--html-lines-table' || a === '--html-linkable-lines') opts.htmlLines = true;
    else if (a === '--html-inline-styles') opts.htmlInline = true;
    else if (a === '--html-prevent-surrounding-pre') opts.htmlOnly = true;
    else if (a.startsWith('--html-prefix=')) opts.htmlPrefix = a.slice(14);
    else if (a === '--html-prefix') opts.htmlPrefix = need('--html-prefix');
    else if (a.startsWith('--html-base-line=')) opts.htmlBaseLine = parseInt(a.slice(17), 10) || 1;
    else if (a === '--html-base-line') opts.htmlBaseLine = parseInt(need('--html-base-line'), 10) || 1;
    else if (a.startsWith('--filename=')) opts.filename = a.slice(11);
    else if (a === '--filename') opts.filename = need('--filename');
    else if (a === '-l' || a === '--lexer') opts.lexer = need(a);
    else if (a.startsWith('--lexer=')) opts.lexer = a.slice(8);
    else if (a === '-s' || a === '--style') opts.style = need(a);
    else if (a.startsWith('--style=')) opts.style = a.slice(8);
    else if (a === '-f' || a === '--formatter') opts.formatter = need(a);
    else if (a.startsWith('--formatter=')) opts.formatter = a.slice(12);
    else if (a.startsWith('--html-tab-width') || a.startsWith('--html-lines-style') || a.startsWith('--html-highlight') || a.startsWith('--html-highlight-style')) {
      if (!a.includes('=') && i + 1 < argv.length && !argv[i + 1].startsWith('-')) i++;
    } else if (a.startsWith('-')) die(`unknown flag ${a}`);
    else opts.files.push(a);
  }
  return opts;
}

function listAll() {
  let out = 'lexers:\n';
  for (const [name, aliases, filenames, mimes] of LEXERS) {
    out += `  ${name}\n`;
    if (aliases) out += `    aliases: ${aliases}\n`;
    if (filenames) out += `    filenames: ${filenames}\n`;
    if (mimes) out += `    mimetypes: ${mimes}\n`;
  }
  out += `\nstyles: ${STYLES.join(' ')}\n`;
  out += `formatters: ${FORMATTERS.join(' ')}\n`;
  process.stdout.write(out);
}

function detectLexer(file, explicit) {
  if (explicit && explicit !== 'autodetect') {
    const x = explicit.toLowerCase();
    if (!KNOWN_LEXERS.has(x)) return 'plaintext';
    return ({golang:'go', py:'python', js:'javascript', ts:'typescript', rs:'rust', 'c++':'cpp', sh:'bash', rb:'ruby', yml:'yaml', md:'markdown', text:'plaintext', plain:'plaintext', pl:'perl'})[x] || x;
  }
  const base = path.basename(file || '').toLowerCase();
  const ext = path.extname(base).slice(1);
  if (base === 'makefile' || base === 'gnumakefile') return 'makefile';
  const map = {go:'go', py:'python', js:'javascript', mjs:'javascript', cjs:'javascript', ts:'typescript', tsx:'typescript', json:'json', rs:'rust', rb:'ruby', sh:'bash', bash:'bash', zsh:'bash', c:'c', h:'c', cpp:'cpp', cc:'cpp', cxx:'cpp', hpp:'cpp', java:'java', html:'html', htm:'html', css:'css', md:'markdown', markdown:'markdown', yml:'yaml', yaml:'yaml', xml:'xml', toml:'toml', sql:'sql', php:'php', pl:'perl', lua:'lua', zig:'zig', txt:'plaintext', diff:'diff', patch:'diff'};
  return map[ext] || 'plaintext';
}

const wordRules = {
  go: {kw: ['break','default','func','interface','select','case','defer','go','map','struct','chan','else','goto','package','switch','const','fallthrough','if','range','type','continue','for','import','return','var'], builtins: ['append','bool','byte','cap','close','complex','complex64','complex128','copy','delete','error','false','float32','float64','imag','int','int8','int16','int32','int64','iota','len','make','new','nil','panic','print','println','real','recover','rune','string','true','uint','uint8','uint16','uint32','uint64','uintptr']},
  python: {kw: ['and','as','assert','async','await','break','class','continue','def','del','elif','else','except','finally','for','from','global','if','import','in','is','lambda','nonlocal','not','or','pass','raise','return','try','while','with','yield','False','None','True'], builtins: ['print','len','range','str','int','float','list','dict','set','tuple','open','super']},
  javascript: {kw: ['break','case','catch','class','const','continue','debugger','default','delete','do','else','export','extends','finally','for','function','if','import','in','instanceof','let','new','return','super','switch','this','throw','try','typeof','var','void','while','with','yield','async','await','of','static'], builtins: ['console','Math','JSON','Array','Object','String','Number','Boolean','Promise','Date']},
  typescript: {kw: ['abstract','any','as','async','await','boolean','break','case','catch','class','const','continue','debugger','declare','default','delete','do','else','enum','export','extends','finally','for','from','function','if','implements','import','in','instanceof','interface','let','module','namespace','new','number','of','private','protected','public','readonly','return','static','string','super','switch','this','throw','try','type','typeof','var','void','while','with','yield'], builtins: ['console','Math','JSON','Array','Object','String','Number','Boolean','Promise','Date']},
  rust: {kw: ['as','async','await','break','const','continue','crate','dyn','else','enum','extern','false','fn','for','if','impl','in','let','loop','match','mod','move','mut','pub','ref','return','self','Self','static','struct','super','trait','true','type','unsafe','use','where','while'], builtins: ['String','Vec','Option','Result','Some','None','Ok','Err']},
  c: {kw: ['auto','break','case','char','const','continue','default','do','double','else','enum','extern','float','for','goto','if','inline','int','long','register','restrict','return','short','signed','sizeof','static','struct','switch','typedef','union','unsigned','void','volatile','while'], builtins: ['printf','scanf','malloc','free']},
  cpp: {kw: ['alignas','alignof','auto','bool','break','case','catch','char','class','const','constexpr','continue','decltype','default','delete','do','double','else','enum','explicit','extern','false','float','for','friend','goto','if','inline','int','long','namespace','new','noexcept','nullptr','operator','private','protected','public','return','short','signed','sizeof','static','struct','switch','template','this','throw','true','try','typedef','typename','union','unsigned','using','virtual','void','volatile','while'], builtins: ['std','cout','cin','endl','printf']},
  java: {kw: ['abstract','assert','boolean','break','byte','case','catch','char','class','const','continue','default','do','double','else','enum','extends','final','finally','float','for','if','implements','import','instanceof','int','interface','long','native','new','package','private','protected','public','return','short','static','strictfp','super','switch','synchronized','this','throw','throws','transient','try','void','volatile','while'], builtins: ['System','String','Integer','Long','Math']},
  bash: {kw: ['if','then','else','elif','fi','for','while','do','done','case','esac','function','in','select','until'], builtins: ['echo','printf','cd','exit','export','read','test']},
  ruby: {kw: ['BEGIN','END','alias','and','begin','break','case','class','def','defined?','do','else','elsif','end','ensure','false','for','if','in','module','next','nil','not','or','redo','rescue','retry','return','self','super','then','true','undef','unless','until','when','while','yield'], builtins: ['puts','print','p','require']},
};

function push(tokens, type, value) {
  if (!value) return;
  const last = tokens[tokens.length - 1];
  if (last && last.type === type) last.value += value;
  else tokens.push({type, value});
}

function tokenize(code, lexer) {
  if (lexer === 'plaintext') return [{type: 'Text', value: code}];
  if (lexer === 'json') return simpleJsonTokens(code);
  if (lexer === 'html' || lexer === 'xml') return markupTokens(code);
  if (lexer === 'css') return cssTokens(code);
  if (lexer === 'yaml' || lexer === 'toml' || lexer === 'ini') return configTokens(code);
  const rules = wordRules[lexer] || wordRules[lexer === 'cpp' ? 'cpp' : 'javascript'] || {kw: [], builtins: []};
  const kw = new Set(rules.kw || []), bi = new Set(rules.builtins || []);
  const tokens = [];
  let i = 0, expectFunc = false;
  while (i < code.length) {
    const s = code.slice(i);
    const mWs = s.match(/^\s+/);
    if (mWs) { push(tokens, lexer === 'python' ? 'Text' : 'TextWhitespace', mWs[0]); i += mWs[0].length; continue; }
    if (s.startsWith('//')) { const v = s.match(/^\/\/[^\n]*/)[0]; push(tokens, 'CommentSingle', v); i += v.length; continue; }
    if (s.startsWith('#') && lexer !== 'c' && lexer !== 'cpp') { const v = s.match(/^#[^\n]*/)[0]; push(tokens, 'CommentSingle', v); i += v.length; continue; }
    if (s.startsWith('/*')) { const end = code.indexOf('*/', i + 2); const v = code.slice(i, end < 0 ? code.length : end + 2); push(tokens, 'CommentMultiline', v); i += v.length; continue; }
    const mStr = s.match(/^(`(?:\\[\s\S]|[^`])*`|'(?:\\[\s\S]|[^'\\])*'|"(?:\\[\s\S]|[^"\\])*")/);
    if (mStr) {
      const doubleString = mStr[0][0] === '"' && ['javascript', 'typescript', 'python', 'json'].includes(lexer);
      push(tokens, doubleString ? 'LiteralStringDouble' : 'LiteralString', mStr[0]);
      i += mStr[0].length; continue;
    }
    const mNum = s.match(/^(0x[0-9a-fA-F]+|\d+\.\d+|\d+)/);
    if (mNum) { push(tokens, mNum[0].includes('.') ? 'LiteralNumberFloat' : 'LiteralNumberInteger', mNum[0]); i += mNum[0].length; continue; }
    const mWord = s.match(/^[A-Za-z_][A-Za-z0-9_]*/);
    if (mWord) {
      const w = mWord[0];
      let type = 'Name';
      if (lexer === 'go' && w === 'package') type = 'KeywordNamespace';
      else if (lexer === 'go' && (w === 'func' || w === 'var' || w === 'const' || w === 'type')) type = 'KeywordDeclaration';
      else if ((lexer === 'javascript' || lexer === 'typescript') && ['const','let','var','function','class','import','export'].includes(w)) type = 'KeywordReserved';
      else if (kw.has(w)) type = 'Keyword';
      else if (bi.has(w)) type = 'NameBuiltin';
      else if (expectFunc) type = 'NameFunction';
      else type = (lexer === 'go' || lexer === 'javascript' || lexer === 'typescript') ? 'NameOther' : 'Name';
      push(tokens, type, w);
      expectFunc = (w === 'func' || w === 'def' || w === 'function' || w === 'fn');
      i += w.length; continue;
    }
    const mOp = s.match(/^(==|!=|<=|>=|:=|\+\+|--|&&|\|\||[-+*\/%=<>!&|^~]+)/);
    if (mOp) { push(tokens, 'Operator', mOp[0]); i += mOp[0].length; continue; }
    const p = s.match(/^[()[\]{}.,;:]+/);
    if (p) { push(tokens, 'Punctuation', p[0]); i += p[0].length; continue; }
    push(tokens, 'Text', code[i]); i++;
  }
  return tokens;
}

function simpleJsonTokens(code) {
  const tokens = []; let i = 0;
  while (i < code.length) {
    const s = code.slice(i);
    const ws = s.match(/^\s+/); if (ws) { push(tokens, 'TextWhitespace', ws[0]); i += ws[0].length; continue; }
    const st = s.match(/^"(?:\\[\s\S]|[^"\\])*"/); if (st) { push(tokens, 'LiteralStringDouble', st[0]); i += st[0].length; continue; }
    const n = s.match(/^-?\d+(?:\.\d+)?/); if (n) { push(tokens, n[0].includes('.') ? 'LiteralNumberFloat' : 'LiteralNumberInteger', n[0]); i += n[0].length; continue; }
    const k = s.match(/^(true|false|null)\b/); if (k) { push(tokens, 'KeywordConstant', k[0]); i += k[0].length; continue; }
    push(tokens, 'Punctuation', code[i]); i++;
  }
  return tokens;
}

function markupTokens(code) {
  const tokens = []; let i = 0;
  while (i < code.length) {
    if (code.startsWith('<!--', i)) { const e = code.indexOf('-->', i + 4); const v = code.slice(i, e < 0 ? code.length : e + 3); push(tokens, 'Comment', v); i += v.length; }
    else if (code[i] === '<') { const e = code.indexOf('>', i + 1); const v = code.slice(i, e < 0 ? code.length : e + 1); push(tokens, 'NameTag', v); i += v.length; }
    else { const e = code.indexOf('<', i); const v = code.slice(i, e < 0 ? code.length : e); push(tokens, 'Text', v); i += v.length; }
  }
  return tokens;
}

function cssTokens(code) {
  const tokens = [];
  for (const part of code.split(/(\s+|\/\*[\s\S]*?\*\/|#[\w-]+|[{}:;,.>+~()[\]]|"(?:\\.|[^"])*"|'(?:\\.|[^'])*')/g)) {
    if (!part) continue;
    if (/^\s+$/.test(part)) push(tokens, 'TextWhitespace', part);
    else if (part.startsWith('/*')) push(tokens, 'CommentMultiline', part);
    else if (/^["']/.test(part)) push(tokens, 'LiteralString', part);
    else if (/^[{}:;,.>+~()[\]]$/.test(part)) push(tokens, 'Punctuation', part);
    else push(tokens, 'NameTag', part);
  }
  return tokens;
}

function configTokens(code) {
  const tokens = [];
  for (const line of code.match(/[^\n]*\n?|$/g)) {
    if (!line) continue;
    const m = line.match(/^(\s*)([A-Za-z0-9_.-]+)(\s*[:=])?(.*)$/);
    if (m && m[2]) { push(tokens, 'TextWhitespace', m[1]); push(tokens, 'NameAttribute', m[2]); if (m[3]) push(tokens, 'Punctuation', m[3]); push(tokens, 'LiteralString', m[4]); }
    else push(tokens, 'Text', line);
  }
  return tokens;
}

const cls = {Keyword:'k', KeywordConstant:'kc', KeywordDeclaration:'kd', KeywordNamespace:'kn', KeywordReserved:'kr', Name:'n', NameOther:'nx', NameFunction:'nf', NameBuiltin:'nb', NameAttribute:'na', NameTag:'nt', LiteralString:'s', LiteralStringDouble:'s2', LiteralNumberInteger:'mi', LiteralNumberFloat:'mf', CommentSingle:'c1', CommentMultiline:'cm', Comment:'c', Operator:'o', Punctuation:'p', TextWhitespace:'w', Text:'', Error:'err'};
const ansi = {Keyword:'\x1b[1m\x1b[31m', KeywordDeclaration:'\x1b[1m\x1b[31m', KeywordNamespace:'\x1b[1m\x1b[31m', KeywordReserved:'\x1b[1m\x1b[31m', NameFunction:'\x1b[35m', NameBuiltin:'\x1b[35m', LiteralString:'\x1b[34m', LiteralStringDouble:'\x1b[34m', LiteralNumberInteger:'\x1b[36m', LiteralNumberFloat:'\x1b[36m', CommentSingle:'\x1b[32m', CommentMultiline:'\x1b[32m', Operator:'\x1b[36m', Punctuation:'\x1b[30m', NameOther:'\x1b[30m', TextWhitespace:'\x1b[1m\x1b[37m'};

function escHtml(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&#34;'); }
function escJson(s) { return JSON.stringify(s); }
function plain(tokens) { return tokens.map(t => t.value).join(''); }

function formatJson(tokens) {
  return '[\n' + tokens.map(t => `  {"type":"${t.type}","value":${escJson(t.value)}}`).join(',\n') + '\n]\n';
}
function formatTokens(tokens) {
  return tokens.map(t => `&Token{${t.type}, ${escJson(t.value)}}`).join('\n') + (tokens.length ? '\n' : '');
}
function formatTerminal(tokens) {
  return tokens.map(t => ansi[t.type] ? ansi[t.type] + t.value + '\x1b[0m' : t.value).join('');
}
function cssText() {
  return `/* Background */ .bg { background-color: #f7f7f7; }
/* PreWrapper */ .chroma { background-color: #f7f7f7; -webkit-text-size-adjust: none; }
/* Error */ .chroma .err { color: #f6f8fa; background-color: #82071e }
/* Line */ .chroma .line { display: flex; }
/* Keyword */ .chroma .k { color: #cf222e }
/* KeywordDeclaration */ .chroma .kd { color: #cf222e }
/* KeywordNamespace */ .chroma .kn { color: #cf222e }
/* KeywordReserved */ .chroma .kr { color: #cf222e }
/* NameOther */ .chroma .nx { color: #1f2328 }
/* NameFunction */ .chroma .nf { color: #6639ba }
/* NameBuiltin */ .chroma .nb { color: #6639ba }
/* LiteralString */ .chroma .s { color: #0a3069 }
/* LiteralStringDouble */ .chroma .s2 { color: #0a3069 }
/* LiteralNumberInteger */ .chroma .mi { color: #0550ae }
/* CommentSingle */ .chroma .c1 { color: #6e7781 }
/* Operator */ .chroma .o { color: #0550ae }
/* Punctuation */ .chroma .p { color: #1f2328 }
/* TextWhitespace */ .chroma .w { color: #bbbbbb }
`;
}
function formatHtml(tokens, opts) {
  if (opts.htmlStyles) return cssText();
  const render = (t, v) => {
    const c = cls[t.type] || '';
    const e = escHtml(v);
    return c ? `<span class="${opts.htmlPrefix || ''}${c}">${e}</span>` : e;
  };
  const lines = [''];
  for (const t of tokens) {
    const parts = t.value.split('\n');
    for (let i = 0; i < parts.length; i++) {
      if (i > 0) {
        lines[lines.length - 1] += render(t, '\n');
        lines.push('');
      }
      if (parts[i]) lines[lines.length - 1] += render(t, parts[i]);
    }
  }
  const wrappedLines = lines.map((l, idx) => {
    if (idx === lines.length - 1 && l === '') return '';
    const ln = opts.htmlLines ? `<span class="ln">${opts.htmlBaseLine + idx}</span>` : '';
    return `<span class="line">${ln}<span class="cl">${l}</span></span>`;
  }).join('');
  const frag = opts.htmlOnly ? `<pre class="chroma"><code>${wrappedLines}</code></pre>\n` : `<html>\n<style type="text/css">\n${cssText()}</style><body><pre class="chroma"><code>${wrappedLines}</code></pre></body>\n</html>\n`;
  return frag;
}
function formatSvg(tokens) {
  const text = escHtml(plain(tokens));
  return `<?xml version="1.0" encoding="UTF-8"?>\n<svg width="800px" height="200px" xmlns="http://www.w3.org/2000/svg"><rect width="100%" height="100%" fill="#f7f7f7"/><text x="10" y="20" font-family="monospace" font-size="14">${text}</text></svg>\n`;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.list) { listAll(); return; }
  if (!FORMATTERS.includes(opts.formatter)) die(`--formatter must be one of "html","json","noop","svg","terminal","terminal16","terminal16m","terminal256","terminal8","tokens" but got "${opts.formatter}"`);
  if (opts.style && !STYLE_OK.has(opts.style) && !fs.existsSync(opts.style)) die(`open ${opts.style}: no such file or directory`, 1);
  if (opts.check) return;
  let inputs = [];
  if (opts.files.length) {
    for (const f of opts.files) {
      let st;
      try { st = fs.statSync(f); } catch (e) { die(`[<files> ...]: stat ${path.resolve(f)}: no such file or directory`); }
      if (st.isDirectory()) die(`[<files> ...]: ${path.resolve(f)} is a directory`);
      let content;
      try { content = fs.readFileSync(f, 'utf8'); } catch (e) { die(`open ${f}: ${e.message}`, 1); }
      inputs.push({name: f, content});
    }
  } else {
    inputs.push({name: opts.filename || '', content: fs.readFileSync(0, 'utf8')});
  }
  let out = '';
  for (const inp of inputs) {
    const lexer = detectLexer(inp.name, opts.lexer);
    if (opts.fail && lexer === 'plaintext' && opts.lexer === 'autodetect') process.exit(1);
    const tokens = tokenize(inp.content, lexer);
    if (opts.formatter === 'json') out += formatJson(tokens);
    else if (opts.formatter === 'tokens') out += formatTokens(tokens);
    else if (opts.formatter === 'noop') out += plain(tokens);
    else if (opts.formatter === 'html') out += formatHtml(tokens, opts);
    else if (opts.formatter === 'svg') out += formatSvg(tokens);
    else out += formatTerminal(tokens);
  }
  process.stdout.write(out);
}

main();
