#!/usr/bin/env node
'use strict';

const fs = require('fs');
const cp = require('child_process');

const VERSION = '0.68.0 (5676da4a)';
const HELP = `fzf is an interactive filter program for any kind of list.

It implements a "fuzzy" matching algorithm, so you can quickly type in patterns
with omitted characters and still get the results you want.

Project URL: https://github.com/junegunn/fzf
Author: Junegunn Choi <junegunn.c@gmail.com>

* See man page for more information: fzf --man

Usage: fzf [options]

  SEARCH
    -e, --exact              Enable exact-match
    +x, --no-extended        Disable extended-search mode
    -i, --ignore-case        Case-insensitive match
    +i, --no-ignore-case     Case-sensitive match
        --smart-case         Smart-case match (default)
    --scheme=SCHEME          Scoring scheme [default|path|history]
    -n, --nth=N[,..]         Comma-separated list of field index expressions
                             for limiting search scope. Each can be a non-zero
                             integer or a range expression ([BEGIN]..[END]).
    --with-nth=N[,..]        Transform the presentation of each line using
                             field index expressions
    --accept-nth=N[,..]      Define which fields to print on accept
    -d, --delimiter=STR      Field delimiter regex (default: AWK-style)
    +s, --no-sort            Do not sort the result
    --literal                Do not normalize latin script letters
    --tail=NUM               Maximum number of items to keep in memory
    --disabled               Do not perform search
    --tiebreak=CRI[,..]      Comma-separated list of sort criteria to apply
                             when the scores are tied
                             [length|chunk|pathname|begin|end|index] (default: length)

  INPUT/OUTPUT
    --read0                  Read input delimited by ASCII NUL characters
    --print0                 Print output delimited by ASCII NUL characters
    --ansi                   Enable processing of ANSI color codes
    --sync                   Synchronous search for multi-staged filtering

  GLOBAL STYLE
    --style=PRESET           Apply a style preset [default|minimal|full[:BORDER_STYLE]
    --color=COLSPEC          Base scheme (dark|light|base16|bw) and/or custom colors
    --no-color               Disable colors
    --no-bold                Do not use bold text

  SCRIPTING
    -q, --query=STR          Start the finder with the given query
    -1, --select-1           Automatically select the only match
    -0, --exit-0             Exit immediately when there's no match
    -f, --filter=STR         Print matches for the initial query and exit
    --print-query            Print query as the first line
    --expect=KEYS            Comma-separated list of keys to complete fzf

  HELP
    --version                Display version information and exit
    --help                   Show this message
    --man                    Show man page

  ENVIRONMENT VARIABLES
    FZF_DEFAULT_COMMAND      Default command to use when input is tty
    FZF_DEFAULT_OPTS         Default options (e.g. '--layout=reverse --info=inline')
    FZF_DEFAULT_OPTS_FILE    Location of the file to read default options from
    FZF_API_KEY              X-API-Key header for HTTP server (--listen)
`;

function shellWords(s) {
  const out = []; let cur = '', quote = null, esc = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (esc) { cur += ch; esc = false; continue; }
    if (ch === '\\' && quote !== "'") { esc = true; continue; }
    if (quote) { if (ch === quote) quote = null; else cur += ch; continue; }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (/\s/.test(ch)) { if (cur.length) { out.push(cur); cur = ''; } continue; }
    cur += ch;
  }
  if (esc) cur += '\\';
  if (cur.length) out.push(cur);
  return out;
}

function expandArgs(argv) {
  let defaults = [];
  if (process.env.FZF_DEFAULT_OPTS_FILE) {
    try { defaults.push(...shellWords(fs.readFileSync(process.env.FZF_DEFAULT_OPTS_FILE, 'utf8'))); } catch {}
  }
  if (process.env.FZF_DEFAULT_OPTS) defaults.push(...shellWords(process.env.FZF_DEFAULT_OPTS));
  return defaults.concat(argv);
}

function parse(argv) {
  const opts = {
    filter: null, query: '', exact: false, extended: true, caseMode: 'smart', sort: true,
    read0: false, print0: false, ansi: false, printQuery: false, expect: false,
    nth: null, acceptNth: null, delimiter: null, tac: false, tail: null, disabled: false,
    scheme: 'default', tiebreak: ['length','index'], bash:false, zsh:false, fish:false, man:false,
    select1:false, exit0:false, raw:false
  };
  const need = (i,a) => { if (i + 1 >= argv.length) die(`missing required argument for ${a}`); return argv[i+1]; };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i], val;
    const eq = a.indexOf('=');
    if (eq > 0 && a.startsWith('--')) { val = a.slice(eq + 1); a = a.slice(0, eq); }
    switch (a) {
      case '--help': opts.help = true; break;
      case '--version': opts.version = true; break;
      case '--man': opts.man = true; break;
      case '--bash': opts.bash = true; break;
      case '--zsh': opts.zsh = true; break;
      case '--fish': opts.fish = true; break;
      case '-f': case '--filter': opts.filter = val ?? need(i,a); if (val === undefined) i++; break;
      case '-q': case '--query': opts.query = val ?? need(i,a); if (val === undefined) i++; break;
      case '-e': case '--exact': opts.exact = true; break;
      case '+x': case '--no-extended': opts.extended = false; break;
      case '-x': case '--extended': opts.extended = true; break;
      case '-i': case '--ignore-case': opts.caseMode = 'ignore'; break;
      case '+i': case '--no-ignore-case': opts.caseMode = 'respect'; break;
      case '--smart-case': opts.caseMode = 'smart'; break;
      case '+s': case '--no-sort': opts.sort = false; break;
      case '-n': case '--nth': opts.nth = val ?? need(i,a); if (val === undefined) i++; break;
      case '--accept-nth': opts.acceptNth = val ?? need(i,a); if (val === undefined) i++; break;
      case '--with-nth': opts.withNth = val ?? need(i,a); if (val === undefined) i++; break;
      case '-d': case '--delimiter': opts.delimiter = val ?? need(i,a); if (val === undefined) i++; break;
      case '--scheme': opts.scheme = val ?? need(i,a); if (val === undefined) i++; if (!['default','path','history'].includes(opts.scheme)) die(`invalid scoring scheme: ${opts.scheme} (expected: default|path|history)`); if (opts.scheme === 'history') opts.tiebreak = ['index']; if (opts.scheme === 'path') opts.tiebreak = ['pathname','length','index']; break;
      case '--tiebreak': opts.tiebreak = (val ?? need(i,a)).split(',').filter(Boolean); if (val === undefined) i++; break;
      case '--read0': opts.read0 = true; break;
      case '--print0': opts.print0 = true; break;
      case '--ansi': opts.ansi = true; break;
      case '--print-query': opts.printQuery = true; break;
      case '--expect': opts.expect = true; if (val === undefined && i + 1 < argv.length && !argv[i+1].startsWith('-')) i++; break;
      case '-1': case '--select-1': opts.select1 = true; break;
      case '-0': case '--exit-0': opts.exit0 = true; break;
      case '--tac': opts.tac = true; break;
      case '--tail': opts.tail = parseInt(val ?? need(i,a), 10); if (val === undefined) i++; break;
      case '--disabled': opts.disabled = true; break;
      case '--raw': opts.raw = true; break;
      default:
        if (a.startsWith('-') || a.startsWith('+')) {
          const takes = ['--height','--min-height','--tmux','--layout','--margin','--padding','--border','--border-label','--border-label-pos','--multi','-m','--preview','--preview-window','--bind','--color','--style','--header','--header-lines','--prompt','--info','--listen','--walker','--walker-root','--walker-skip','--history','--history-size','--preview-border','--preview-label','--preview-label-pos','--header-border','--footer','--footer-border','--input-border','--list-border','--gap','--gap-line','--pointer','--marker','--ellipsis','--tabstop','--scrollbar'];
          if (takes.includes(a) && val === undefined && i + 1 < argv.length && !argv[i+1].startsWith('-')) i++;
          else if (!takes.includes(a) && !['--sync','--no-color','--no-bold','--literal','--cycle','--wrap','--track','--no-multi-line','--keep-right','--no-hscroll','--no-input','--header-first','--no-separator','--no-scrollbar','--reverse'].includes(a)) die(`unknown option: ${a}`);
        }
    }
  }
  if (opts.filter === null && opts.query && (opts.select1 || opts.exit0)) opts.filter = opts.query;
  return opts;
}

function die(msg) { console.error(msg); process.exit(2); }
function stripAnsi(s) { return s.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, ''); }
function normalize(s, opts) { return opts.ansi ? stripAnsi(s) : s; }
function caseFold(s, query, opts) {
  const ignore = opts.caseMode === 'ignore' || (opts.caseMode === 'smart' && !/[A-Z]/.test(query));
  return ignore ? s.toLowerCase() : s;
}

function splitItems(buf, read0) {
  const sep = read0 ? '\0' : '\n';
  let parts = buf.split(sep);
  if (parts.length && parts[parts.length - 1] === '') parts.pop();
  return parts;
}

function splitFields(line, delim) {
  if (!delim) {
    const m = [...line.matchAll(/\S+/g)];
    return m.map(x => ({text:x[0], start:x.index, end:x.index + x[0].length}));
  }
  let re;
  try { re = new RegExp(delim, 'g'); } catch { re = new RegExp(escapeRegExp(delim), 'g'); }
  const fields = []; let last = 0, m;
  while ((m = re.exec(line)) !== null) {
    fields.push({text:line.slice(last, m.index), start:last, end:m.index});
    last = m.index + (m[0].length || 1);
    if (m[0].length === 0) re.lastIndex++;
  }
  fields.push({text:line.slice(last), start:last, end:line.length});
  return fields;
}
function escapeRegExp(s){return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
function parseExpr(expr) {
  expr = expr.trim();
  const r = expr.match(/^(-?\d*)\.\.(-?\d*)$/);
  if (r) return {range:true, a:r[1] ? parseInt(r[1],10) : null, b:r[2] ? parseInt(r[2],10) : null};
  return {range:false, a:parseInt(expr,10)};
}
function idx(n, len) { if (n == null) return null; return n > 0 ? n - 1 : len + n; }
function exprText(line, expr, delim, strip=true) {
  if (expr === 'n') return '';
  const fields = splitFields(line, delim), len = fields.length, pe = parseExpr(expr);
  if (!pe.range) { const i = idx(pe.a, len); return (i >= 0 && i < len) ? fields[i].text.trim() : ''; }
  let a = pe.a == null ? 0 : idx(pe.a, len), b = pe.b == null ? len - 1 : idx(pe.b, len);
  a = Math.max(0, a); b = Math.min(len - 1, b);
  if (a > b || a >= len || b < 0) return '';
  const s = line.slice(fields[a].start, fields[b].end);
  return strip ? s.trim() : s;
}
function transform(line, spec, delim, ordinal) {
  if (!spec) return line;
  if (spec.includes('{')) return spec.replace(/\\?\{([^{}]+)\}/g, (m,e) => m.startsWith('\\') ? m.slice(1) : (e === 'n' ? String(ordinal) : exprText(line,e,delim,true)));
  return spec.split(',').map(e => exprText(line,e,delim,false)).join(' ').trim();
}
function nthText(line, spec, delim) {
  if (!spec) return line;
  return spec.split(',').map(e => exprText(line,e,delim,false)).join(' ').trim();
}

function splitTerms(q) {
  const out = []; let cur = '', esc = false;
  for (const ch of q) {
    if (esc) { cur += ch; esc = false; continue; }
    if (ch === '\\') { esc = true; continue; }
    if (/\s/.test(ch)) { if (cur) { out.push(cur); cur = ''; } continue; }
    cur += ch;
  }
  if (esc) cur += '\\'; if (cur) out.push(cur); return out;
}
function fuzzy(hay, needle) {
  if (needle === '') return {ok:true, score:0, begin:0, end:0};
  let pos = -1, begin = -1, last = -1, gaps = 0;
  for (const c of needle) {
    const p = hay.indexOf(c, pos + 1);
    if (p < 0) return {ok:false};
    if (begin < 0) begin = p;
    if (last >= 0) gaps += p - last - 1;
    last = p; pos = p;
  }
  return {ok:true, begin, end:last, score:1000 + (begin === 0 ? 50 : 0) - gaps * 10 - hay.length};
}
function exactMatch(hay, needle, mode) {
  let p;
  if (mode === 'prefix') p = hay.startsWith(needle) ? 0 : -1;
  else if (mode === 'suffix') p = hay.endsWith(needle) ? hay.length - needle.length : -1;
  else p = hay.indexOf(needle);
  return p >= 0 ? {ok:true, begin:p, end:p + needle.length - 1, score:1200 - p * 6 - Math.max(0, hay.length - needle.length)} : {ok:false};
}
function matchLine(text, query, opts) {
  if (opts.disabled || query === '') return {ok:true, score:0, begin:0, end:0};
  const terms = opts.extended ? splitTerms(query) : [query];
  let score = 0, begin = 1e9, end = -1;
  for (let term of terms) {
    let inv = false, exact = opts.exact || !opts.extended, mode = 'contains';
    if (opts.extended && term.startsWith('!')) { inv = true; exact = true; term = term.slice(1); }
    if (opts.extended && term.startsWith("'")) { exact = true; term = term.slice(1); }
    if (opts.extended && term.startsWith('^')) { exact = true; mode = 'prefix'; term = term.slice(1); }
    if (opts.extended && term.endsWith('$')) { exact = true; mode = mode === 'prefix' ? 'contains' : 'suffix'; term = term.slice(0,-1); }
    const h = caseFold(text, term, opts), n = caseFold(term, term, opts);
    const r = exact ? exactMatch(h,n,mode) : fuzzy(h,n);
    if (inv) { if (r.ok) return {ok:false}; else continue; }
    if (!r.ok) return {ok:false};
    score += r.score; begin = Math.min(begin, r.begin); end = Math.max(end, r.end);
  }
  return {ok:true, score, begin:begin===1e9?0:begin, end};
}
function cmp(a,b, opts) {
  if (b.score !== a.score) return b.score - a.score;
  for (const t of opts.tiebreak) {
    if (t === 'length' && a.text.length !== b.text.length) return a.text.length - b.text.length;
    if (t === 'begin' && a.begin !== b.begin) return a.begin - b.begin;
    if (t === 'end' && a.end !== b.end) return a.end - b.end;
    if (t === 'pathname') { const ap=a.text.lastIndexOf('/'), bp=b.text.lastIndexOf('/'); if (ap !== bp) return bp - ap; }
    if (t === 'index' && a.index !== b.index) return a.index - b.index;
  }
  return a.index - b.index;
}

function integration(shell) {
  if (shell === 'bash') return '### key-bindings.bash ###\n#     ____      ____\n#    / __/___  / __/\n#   / /_/_  / / /_\n#  / __/ / /_/ __/\n';
  if (shell === 'zsh') return '# fzf zsh integration\n';
  return '# fzf fish integration\n';
}
function showMan() {
  const p = '/workspace/man/man1/fzf.1';
  try { process.stdout.write(fs.readFileSync(p)); } catch { process.stdout.write(HELP); }
}

function main() {
  const opts = parse(expandArgs(process.argv.slice(2)));
  if (opts.help) { process.stdout.write(HELP); return; }
  if (opts.version) { console.log(VERSION); return; }
  if (opts.man) { showMan(); return; }
  if (opts.bash || opts.zsh || opts.fish) { process.stdout.write(integration(opts.bash?'bash':opts.zsh?'zsh':'fish')); return; }

  let input = '';
  try { input = fs.readFileSync(0, 'utf8'); } catch {}
  if (!input && process.stdin.isTTY && process.env.FZF_DEFAULT_COMMAND) {
    try { input = cp.execSync(process.env.FZF_DEFAULT_COMMAND, {encoding:'utf8', shell:'/bin/sh'}); } catch {}
  }
  let items = splitItems(input, opts.read0);
  if (Number.isFinite(opts.tail) && opts.tail >= 0 && items.length > opts.tail) items = items.slice(items.length - opts.tail);
  if (opts.tac) items.reverse();
  const query = opts.filter !== null ? opts.filter : opts.query;
  const rows = [];
  items.forEach((line, i) => {
    const mtext = nthText(normalize(line, opts), opts.nth, opts.delimiter);
    const r = matchLine(mtext, query, opts);
    if (r.ok || opts.raw) rows.push({line, text:mtext, index:i, score:r.ok?r.score:-1e9, begin:r.begin||0, end:r.end||0, matched:r.ok});
  });
  const matched = rows.filter(r => r.matched);
  if ((opts.filter !== null || opts.select1 || opts.exit0) && matched.length === 0) {
    if (opts.printQuery) process.stdout.write(query + (opts.print0?'\0':'\n'));
    process.exit(1);
  }
  let outRows = opts.raw ? rows : matched;
  if (opts.sort && query !== '') outRows = outRows.slice().sort((a,b)=>cmp(a,b,opts));
  const sep = opts.print0 ? '\0' : '\n';
  const out = [];
  if (opts.printQuery) out.push(query);
  if (opts.expect && opts.filter === null) out.push('');
  for (const r of outRows) out.push(opts.acceptNth ? transform(r.line, opts.acceptNth, opts.delimiter, r.index) : r.line);
  if (out.length) process.stdout.write(out.join(sep) + sep);
  process.exit(outRows.length ? 0 : 1);
}
main();
