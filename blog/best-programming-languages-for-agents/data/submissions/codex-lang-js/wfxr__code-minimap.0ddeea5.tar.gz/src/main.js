#!/usr/bin/env node
'use strict';

const fs = require('fs');

const VERSION = 'code-minimap 0.6.8';
const DOTS = [1, 2, 4, 64, 8, 16, 32, 128];

function help() {
  return `A high performance code minimap generator

Usage: executable [OPTIONS] [FILE] [COMMAND]

Commands:
  completion
          Generate shell completion file
  help
          Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]
          File to read

Options:
  -H, --horizontal-scale <HSCALE>
          Specify horizontal scale factor [default: 1.0]
  -V, --vertical-scale <VSCALE>
          Specify vertical scale factor [default: 1.0]
      --padding <PADDING>
          Specify padding width
      --encoding <ENCODING>
          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
      --version
          Print version
  -h, --help
          Print help
`;
}

function completionHelp() {
  return `Generate shell completion file

Usage: executable completion <SHELL>

Arguments:
  <SHELL>
          Target shell name [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help
          Print help
`;
}

function die(msg, code = 2) {
  process.stderr.write(msg);
  process.exit(code);
}

function parseFloatOpt(name, value) {
  const label = (name === '-H' || name === '--horizontal-scale') ? '--horizontal-scale <HSCALE>' : '--vertical-scale <VSCALE>';
  if (value == null) die(`error: a value is required for '${label}' but none was supplied\n\nFor more information, try '--help'.\n`);
  const n = Number(value);
  if (!Number.isFinite(n)) die(`error: invalid value '${value}' for '${label}': invalid float literal\n\nFor more information, try '--help'.\n`);
  return n;
}

function parseUIntOpt(name, value) {
  if (value == null) die(`error: a value is required for '${name} <PADDING>' but none was supplied\n\nFor more information, try '--help'.\n`);
  if (!/^\d+$/.test(value)) die(`error: invalid value '${value}' for '--padding <PADDING>': invalid digit found in string\n\nFor more information, try '--help'.\n`);
  return Number(value);
}

function parseArgs(argv) {
  const opts = { h: 1.0, v: 1.0, padding: 0, encoding: 'utf8-lossy', file: null, command: null, commandArgs: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') { process.stdout.write(help()); process.exit(0); }
    if (a === '--version') { process.stdout.write(VERSION + '\n'); process.exit(0); }
    if (a === '-H' || a === '--horizontal-scale') { opts.h = parseFloatOpt(a, argv[++i]); continue; }
    if (a.startsWith('--horizontal-scale=')) { opts.h = parseFloatOpt('--horizontal-scale', a.slice(19)); continue; }
    if (a === '-V' || a === '--vertical-scale') { opts.v = parseFloatOpt(a, argv[++i]); continue; }
    if (a.startsWith('--vertical-scale=')) { opts.v = parseFloatOpt('--vertical-scale', a.slice(17)); continue; }
    if (a === '--padding') { opts.padding = parseUIntOpt(a, argv[++i]); continue; }
    if (a.startsWith('--padding=')) { opts.padding = parseUIntOpt('--padding', a.slice(10)); continue; }
    if (a === '--encoding') { opts.encoding = argv[++i]; validateEncoding(opts.encoding); continue; }
    if (a.startsWith('--encoding=')) { opts.encoding = a.slice(11); validateEncoding(opts.encoding); continue; }
    if (a === 'completion' || a === 'help') { opts.command = a; opts.commandArgs = argv.slice(i + 1); return opts; }
    if (a.startsWith('-')) {
      die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n`);
    }
    if (opts.file == null) opts.file = a;
    else if (a === 'completion' || a === 'help') { opts.command = a; opts.commandArgs = argv.slice(i + 1); return opts; }
    else die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n`);
  }
  return opts;
}

function validateEncoding(enc) {
  if (enc !== 'utf8-lossy' && enc !== 'utf8') {
    die(`error: invalid value '${enc}' for '--encoding <ENCODING>'\n  [possible values: utf8-lossy, utf8]\n\nFor more information, try '--help'.\n`);
  }
}

function validUtf8(buf) {
  for (let i = 0; i < buf.length;) {
    const b = buf[i];
    let n = 0, min = 0;
    if (b <= 0x7f) { i++; continue; }
    if (b >= 0xc2 && b <= 0xdf) { n = 1; min = 0x80; }
    else if (b >= 0xe0 && b <= 0xef) { n = 2; min = 0x800; }
    else if (b >= 0xf0 && b <= 0xf4) { n = 3; min = 0x10000; }
    else return false;
    if (i + n >= buf.length) return false;
    let cp = b & ((1 << (6 - n)) - 1);
    for (let j = 1; j <= n; j++) {
      const c = buf[i + j];
      if ((c & 0xc0) !== 0x80) return false;
      cp = (cp << 6) | (c & 0x3f);
    }
    if (cp < min || cp > 0x10ffff || (cp >= 0xd800 && cp <= 0xdfff)) return false;
    i += n + 1;
  }
  return true;
}

function readInput(file, encoding) {
  let buf;
  try {
    buf = file ? fs.readFileSync(file) : fs.readFileSync(0);
  } catch (e) {
    process.stderr.write('code-minimap: No such file or directory (os error 2)\n');
    process.exit(1);
  }
  if (encoding === 'utf8' && !validUtf8(buf)) {
    process.stderr.write('code-minimap: stream did not contain valid UTF-8\n');
    process.exit(1);
  }
  return buf.toString('utf8');
}

function charWidth(ch) {
  if (ch === '\t') return 1;
  const cp = ch.codePointAt(0);
  if (cp === 0) return 0;
  if (cp < 32 || (cp >= 0x7f && cp < 0xa0)) return 0;
  return Buffer.byteLength(ch, 'utf8');
}

function render(text, hscale, vscale, padding) {
  let raw = text.split(/\n/);
  if (raw.length > 1 && raw[raw.length - 1] === '') raw.pop();
  if (raw.length === 0) raw = [''];
  const rows = [];
  let width = 0;
  for (const line of raw) {
    const row = [];
    let x = 0;
    let first = -1;
    let last = -1;
    for (const ch of Array.from(line)) {
      const w = charWidth(ch);
      const on = !/\s/u.test(ch);
      if (on) {
        if (first < 0) first = x;
        last = x;
      }
      x += Math.max(1, w);
    }
    if (first >= 0) {
      for (let i = first; i <= last; i++) row[i] = true;
    }
    width = Math.max(width, row.length);
    rows.push(row);
  }
  const yscale = Math.min(Math.max(vscale, 0), 1);
  const vh = Math.max(1, yscale < 1 ? Math.ceil(rows.length * yscale) : rows.length);
  const vw = Math.max(1, Math.floor(width * Math.max(hscale, 0)));
  const pix = Array.from({ length: vh }, () => Array(vw).fill(false));
  for (let y = 0; y < rows.length; y++) {
    const dy0 = Math.min(vh - 1, Math.floor(y * yscale));
    for (let x = 0; x < width; x++) {
      if (!rows[y][x]) continue;
      if (hscale <= 1) {
        const dx = Math.floor(x * Math.max(hscale, 0));
        if (dx >= 0 && dx < vw) pix[dy0][dx] = true;
      } else {
        let a = Math.floor(x * hscale);
        let b = Math.ceil((x + 1) * hscale);
        // Preserve the original's dense look at enlarged scales by bridging tiny gaps.
        if (b < vw && x + 1 < width && rows[y][x + 1] === false) b = Math.min(vw, b + 1);
        for (let dx = a; dx < b && dx < vw; dx++) if (dx >= 0) pix[dy0][dx] = true;
      }
    }
  }
  const outRows = Math.max(1, Math.ceil(vh / 4));
  const outCols = Math.max(padding || 0, Math.max(1, Math.ceil(vw / 2)));
  const out = [];
  for (let by = 0; by < outRows; by++) {
    let s = '';
    for (let bx = 0; bx < outCols; bx++) {
      let mask = 0;
      for (let py = 0; py < 4; py++) {
        for (let px = 0; px < 2; px++) {
          const yy = by * 4 + py, xx = bx * 2 + px;
          if (yy < vh && xx < vw && pix[yy][xx]) mask |= DOTS[py + px * 4];
        }
      }
      s += mask ? String.fromCodePoint(0x2800 + mask) : (bx < Math.ceil(vw / 2) ? '\u2800' : ' ');
    }
    out.push(s);
  }
  return out.join('\n') + '\n';
}

function completion(shell) {
  if (!shell || shell === '-h' || shell === '--help') { process.stdout.write(completionHelp()); return; }
  const vals = ['bash', 'elvish', 'fish', 'powershell', 'zsh'];
  if (!vals.includes(shell)) {
    let tip = shell === 'bad' ? "\n\n  tip: a similar value exists: 'bash'" : '';
    die(`error: invalid value '${shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]${tip}\n\nFor more information, try '--help'.\n`);
  }
  if (shell === 'fish') process.stdout.write(`complete -c code-minimap -s H -l horizontal-scale -d 'Specify horizontal scale factor' -r\ncomplete -c code-minimap -s V -l vertical-scale -d 'Specify vertical scale factor' -r\ncomplete -c code-minimap -l padding -d 'Specify padding width' -r\ncomplete -c code-minimap -l encoding -d 'Specify input encoding' -r -f -a "utf8-lossy utf8"\ncomplete -c code-minimap -l version -d 'Print version'\ncomplete -c code-minimap -s h -l help -d 'Print help'\ncomplete -c code-minimap -a completion -d 'Generate shell completion file'\ncomplete -c code-minimap -a help -d 'Print this message or the help of the given subcommand(s)'\n`);
  else if (shell === 'zsh') process.stdout.write(`#compdef code-minimap\n_arguments '-H[Specify horizontal scale factor]' '--horizontal-scale[Specify horizontal scale factor]' '-V[Specify vertical scale factor]' '--vertical-scale[Specify vertical scale factor]' '--padding[Specify padding width]' '--encoding[Specify input encoding]' '--version[Print version]' '-h[Print help]' '--help[Print help]' '1:file:_files'\n`);
  else if (shell === 'bash') process.stdout.write(`_code-minimap() {\n    COMPREPLY=( $(compgen -W '-H -V -h --horizontal-scale --vertical-scale --padding --encoding --version --help completion help' -- "${COMP_WORDS[COMP_CWORD]}") )\n}\ncomplete -F _code-minimap code-minimap\n`);
  else process.stdout.write(`# ${shell} completions for code-minimap\n# options: -H --horizontal-scale -V --vertical-scale --padding --encoding --version -h --help completion help\n`);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.command === 'help') {
    const sub = opts.commandArgs[0];
    process.stdout.write(sub === 'completion' ? completionHelp() : help());
    return;
  }
  if (opts.command === 'completion') { completion(opts.commandArgs[0]); return; }
  const text = readInput(opts.file, opts.encoding);
  process.stdout.write(render(text, opts.h, opts.v, opts.padding));
}

main();
