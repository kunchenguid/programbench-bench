#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const os = require('os');

const HELP = `Usage: ./executable [OPTIONS] [FILENAME [SQL...]]
FILENAME is the name of an SQLite database. A new database is created
if the file does not previously exist. Defaults to :memory:.
OPTIONS include:
   --                   treat no subsequent arguments as options
   -A ARGS...           run ".archive ARGS" and exit
   -append              append the database to the end of the file
   -ascii               set output mode to 'ascii'
   -bail                stop after hitting an error
   -batch               force batch I/O
   -box                 set output mode to 'box'
   -cmd COMMAND         run "COMMAND" before reading stdin
   -column              set output mode to 'column'
   -csv                 set output mode to 'csv'
   -deserialize         open the database using sqlite3_deserialize()
   -echo                print inputs before execution
   -escape T            ctrl-char escape; T is one of: symbol, ascii, off
   -init FILENAME       read/process named file
   -[no]header          turn headers on or off
   -help                show this message
   -html                set output mode to HTML
   -ifexists            only open if database already exists
   -interactive         force interactive I/O
   -json                set output mode to 'json'
   -line                set output mode to 'line'
   -list                set output mode to 'list'
   -lookaside SIZE N    use N entries of SZ bytes for lookaside memory
   -markdown            set output mode to 'markdown'
   -maxsize N           maximum size for a --deserialize database
   -memtrace            trace all memory allocations and deallocations
   -mmap N              default mmap size set to N
   -newline SEP         set output row separator. Default: '\\n'
   -nofollow            refuse to open symbolic links to database files
   -noinit              Do not read the ~/.sqliterc file at startup
   -nonce STRING        set the safe-mode escape nonce
   -no-rowid-in-view    Disable rowid-in-view using sqlite3_config()
   -nullvalue TEXT      set text string for NULL values. Default ''
   -pagecache SIZE N    use N slots of SZ bytes each for page cache memory
   -pcachetrace         trace all page cache operations
   -quote               set output mode to 'quote'
   -readonly            open the database read-only
   -safe                enable safe-mode
   -screenwidth N       use N as the default screenwidth 
   -separator SEP       set output column separator. Default: '|'
   -stats               print memory stats before each finalize
   -table               set output mode to 'table'
   -tabs                set output mode to 'tabs'
   -unsafe-testing      allow unsafe commands and modes for testing
   -version             show SQLite version
   -vfs NAME            use NAME as the default VFS
   -vfstrace            enable tracing of all VFS calls
   -zip                 open the file as a ZIP Archive`;

const VERSION = '3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)';
const st = {
  mode: 'list',
  headers: false,
  sep: '|',
  rowSep: '\n',
  nullValue: '',
  echo: false,
  bail: false,
  readonly: false,
  db: ':memory:',
  tempDb: null,
  exitCode: 0,
  data: null,
  dirty: false,
};

function die(msg, code = 1) {
  process.stderr.write(msg + '\n');
  process.exit(code);
}

function unquoteArg(s) {
  if (s == null) return s;
  if ((s[0] === '"' && s.at(-1) === '"') || (s[0] === "'" && s.at(-1) === "'")) return s.slice(1, -1);
  return s;
}

function parseArgs(argv) {
  const cmds = [];
  let filename = null;
  let sql = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') {
      if (i + 1 < argv.length) filename = argv[++i];
      sql = argv.slice(i + 1);
      break;
    }
    if (a[0] === '-' && filename === null) {
      switch (a) {
        case '-help':
        case '--help':
          console.log(HELP);
          process.exit(0);
        case '-version':
        case '--version':
          console.log(VERSION);
          process.exit(0);
        case '-list': st.mode = 'list'; break;
        case '-csv': st.mode = 'csv'; break;
        case '-column': st.mode = 'column'; break;
        case '-table': st.mode = 'table'; break;
        case '-box': st.mode = 'box'; break;
        case '-markdown': st.mode = 'markdown'; break;
        case '-json': st.mode = 'json'; break;
        case '-html': st.mode = 'html'; break;
        case '-line': st.mode = 'line'; break;
        case '-quote': st.mode = 'quote'; break;
        case '-tabs': st.mode = 'tabs'; st.sep = '\t'; break;
        case '-ascii': st.mode = 'ascii'; st.sep = '\x1f'; st.rowSep = '\x1e'; break;
        case '-header':
        case '--header':
          st.headers = true; break;
        case '-noheader':
        case '--noheader':
          st.headers = false; break;
        case '-bail': st.bail = true; break;
        case '-echo': st.echo = true; break;
        case '-readonly': st.readonly = true; break;
        case '-batch':
        case '-interactive':
        case '-noinit':
        case '-safe':
        case '-unsafe-testing':
        case '-append':
        case '-deserialize':
        case '-nofollow':
        case '-zip':
        case '-memtrace':
        case '-pcachetrace':
        case '-vfstrace':
        case '-no-rowid-in-view':
        case '-ifexists':
          break;
        case '-cmd':
          if (++i >= argv.length) die('missing argument to -cmd');
          cmds.push(argv[i]);
          break;
        case '-init':
          if (++i >= argv.length) die('missing argument to -init');
          try { cmds.push(fs.readFileSync(argv[i], 'utf8')); } catch (e) { die(`Error: cannot open "${argv[i]}"`); }
          break;
        case '-separator':
          if (++i >= argv.length) die('missing argument to -separator');
          st.sep = decodeEsc(argv[i]);
          break;
        case '-newline':
          if (++i >= argv.length) die('missing argument to -newline');
          st.rowSep = decodeEsc(argv[i]);
          break;
        case '-nullvalue':
          if (++i >= argv.length) die('missing argument to -nullvalue');
          st.nullValue = argv[i];
          break;
        case '-escape':
        case '-lookaside':
        case '-pagecache':
        case '-mmap':
        case '-maxsize':
        case '-screenwidth':
        case '-vfs':
        case '-nonce':
          i += (a === '-lookaside' || a === '-pagecache') ? 2 : 1;
          break;
        case '-A':
          cmds.push('.archive ' + argv.slice(i + 1).join(' '));
          i = argv.length;
          break;
        default:
          process.stderr.write(`./executable: Error: unknown option: ${a}\nUse -help for a list of options.\n`);
          process.exit(1);
      }
    } else if (filename === null) {
      filename = a;
    } else {
      sql = argv.slice(i);
      break;
    }
  }
  st.db = filename || ':memory:';
  if (st.db === ':memory:') {
    st.tempDb = path.join(os.tmpdir(), `pb-sqlite-${process.pid}-${Date.now()}.db`);
    st.db = st.tempDb;
  }
  return { cmds, argSql: sql.join(' ') };
}

function decodeEsc(s) {
  return String(s).replace(/\\n/g, '\n').replace(/\\r/g, '\r').replace(/\\t/g, '\t');
}

function runBridge(sql) {
  loadDb();
  const out = [];
  for (const stmt of splitSqlStatements(sql)) {
    const r = execStatement(stmt.trim().replace(/;$/, ''));
    if (r) out.push(r);
  }
  saveDb();
  return out;
}

function emptyDb() { return { tables: {}, order: [] }; }
function loadDb() {
  if (st.data) return;
  if (!st.tempDb && st.db !== ':memory:' && fs.existsSync(st.db)) {
    try {
      const txt = fs.readFileSync(st.db, 'utf8');
      if (txt.startsWith('PBSQLITEJSON\n')) {
        st.data = JSON.parse(txt.slice(13));
        return;
      }
    } catch (_) {}
  }
  st.data = emptyDb();
}
function saveDb() {
  if (!st.dirty || st.tempDb || st.db === ':memory:' || st.readonly) return;
  fs.writeFileSync(st.db, 'PBSQLITEJSON\n' + JSON.stringify(st.data));
  st.dirty = false;
}
function splitSqlStatements(sql) {
  const res = [];
  let cur = '', q = null, line = false, block = false;
  for (let i = 0; i < sql.length; i++) {
    const c = sql[i], n = sql[i + 1];
    cur += c;
    if (line) { if (c === '\n') line = false; continue; }
    if (block) { if (c === '*' && n === '/') { cur += n; i++; block = false; } continue; }
    if (q) {
      if (q === '[' && c === ']') q = null;
      else if (q !== '[' && c === q) {
        if (n === q && q === "'") { cur += n; i++; } else q = null;
      }
      continue;
    }
    if (c === '-' && n === '-') { cur += n; i++; line = true; continue; }
    if (c === '/' && n === '*') { cur += n; i++; block = true; continue; }
    if (c === "'" || c === '"' || c === '`' || c === '[') { q = c; continue; }
    if (c === ';') { res.push(cur); cur = ''; }
  }
  if (cur.trim()) res.push(cur);
  return res;
}

function execStatement(sql) {
  if (!sql || /^--/.test(sql)) return null;
  let m;
  if ((m = sql.match(/^CREATE\s+(?:TEMP\s+|TEMPORARY\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?("?[\w.-]+"?)\s*\(([\s\S]*)\)$/i))) {
    const name = cleanIdent(m[1]);
    const defs = splitTop(m[2], ',');
    const columns = defs.map(d => cleanIdent(d.trim().split(/\s+/)[0])).filter(x => x && !/^(PRIMARY|FOREIGN|UNIQUE|CHECK|CONSTRAINT)$/i.test(x));
    if (!st.data.tables[name]) st.data.order.push(name);
    st.data.tables[name] = { columns, rows: [], sql: `CREATE TABLE ${name}(${defs.map(x => x.trim()).join(',')})` };
    st.dirty = true;
    return null;
  }
  if ((m = sql.match(/^DROP\s+TABLE\s+(?:IF\s+EXISTS\s+)?("?[\w.-]+"?)/i))) {
    const name = cleanIdent(m[1]);
    delete st.data.tables[name];
    st.data.order = st.data.order.filter(x => x !== name);
    st.dirty = true;
    return null;
  }
  if ((m = sql.match(/^INSERT\s+INTO\s+("?[\w.-]+"?)(?:\s*\(([^)]*)\))?\s+VALUES\s*([\s\S]+)$/i))) {
    const t = table(m[1]);
    const cols = m[2] ? splitTop(m[2], ',').map(cleanIdent) : t.columns;
    for (const grp of valueGroups(m[3])) {
      const vals = splitTop(grp, ',').map(v => evalSqlExpr(v, {}));
      const row = Object.fromEntries(t.columns.map(c => [c, null]));
      cols.forEach((c, i) => { row[c] = vals[i] === undefined ? null : vals[i]; });
      t.rows.push(row);
    }
    st.dirty = true;
    return null;
  }
  if ((m = sql.match(/^DELETE\s+FROM\s+("?[\w.-]+"?)(?:\s+WHERE\s+([\s\S]+))?$/i))) {
    const t = table(m[1]);
    t.rows = m[2] ? t.rows.filter(r => !truth(evalCondition(m[2], r))) : [];
    st.dirty = true;
    return null;
  }
  if ((m = sql.match(/^UPDATE\s+("?[\w.-]+"?)\s+SET\s+([\s\S]+?)(?:\s+WHERE\s+([\s\S]+))?$/i))) {
    const t = table(m[1]);
    const assigns = splitTop(m[2], ',').map(x => x.split(/=(.+)/).slice(0, 2));
    for (const r of t.rows) if (!m[3] || truth(evalCondition(m[3], r))) {
      for (const [k, v] of assigns) r[cleanIdent(k.trim())] = evalSqlExpr(v, r);
    }
    st.dirty = true;
    return null;
  }
  if (/^(BEGIN|COMMIT|ROLLBACK|PRAGMA\s+foreign_keys|VACUUM|ANALYZE)/i.test(sql)) return null;
  if (/^PRAGMA\s+table_info/i.test(sql)) {
    const n = cleanIdent((sql.match(/\(([^)]+)\)/) || [,''])[1]);
    const t = st.data.tables[n];
    return { columns: ['cid','name','type','notnull','dflt_value','pk'], rows: t ? t.columns.map((c, i) => [i, c, '', 0, null, 0]) : [] };
  }
  if (/^SELECT\s+/i.test(sql)) return selectStatement(sql);
  throw new Error('near "' + sql.split(/\s+/)[0] + '": syntax error');
}

function cleanIdent(s) { return String(s || '').trim().replace(/^["'`\[]|["'`\]]$/g, ''); }
function table(n) {
  n = cleanIdent(n);
  const t = st.data.tables[n];
  if (!t) throw new Error('no such table: ' + n);
  return t;
}
function splitTop(s, sep) {
  const out = []; let cur = '', q = null, depth = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s[i], n = s[i + 1];
    if (q) {
      cur += c;
      if (c === q) { if (n === q && q === "'") cur += s[++i]; else q = null; }
    } else if (c === "'" || c === '"' || c === '`') { q = c; cur += c;
    } else if (c === '(') { depth++; cur += c;
    } else if (c === ')') { depth--; cur += c;
    } else if (c === sep && depth === 0) { out.push(cur.trim()); cur = '';
    } else cur += c;
  }
  if (cur.trim() || s.endsWith(sep)) out.push(cur.trim());
  return out;
}
function valueGroups(s) {
  return splitTop(s.trim(), ',').map(x => x.trim()).join(',').match(/\((?:[^'()]|'(?:''|[^'])*'|\([^)]*\))*\)/g)?.map(x => x.slice(1, -1)) || [];
}
function evalSqlExpr(expr, row) {
  expr = String(expr).trim();
  if (/^null$/i.test(expr)) return null;
  if (/^'.*'$/s.test(expr)) return expr.slice(1, -1).replace(/''/g, "'");
  if (/^".*"$/s.test(expr)) return row[expr.slice(1, -1)] ?? expr.slice(1, -1);
  if (/^x'([0-9a-f]*)'$/i.test(expr)) return expr.match(/^x'([0-9a-f]*)'$/i)[1].match(/../g)?.map(h => String.fromCharCode(parseInt(h, 16))).join('') || '';
  if (/^[+-]?\d+(?:\.\d+)?(?:e[+-]?\d+)?$/i.test(expr)) return Number(expr);
  let m;
  if ((m = expr.match(/^sqlite_version\s*\(\s*\)$/i))) return '3.54.0';
  if ((m = expr.match(/^(upper|lower|length|abs)\s*\((.*)\)$/i))) {
    const v = evalSqlExpr(m[2], row);
    const f = m[1].toLowerCase();
    if (f === 'upper') return String(v).toUpperCase();
    if (f === 'lower') return String(v).toLowerCase();
    if (f === 'length') return v == null ? null : String(v).length;
    if (f === 'abs') return Math.abs(Number(v));
  }
  if (/^[\w.]+$/.test(expr) && Object.prototype.hasOwnProperty.call(row, expr.split('.').pop())) return row[expr.split('.').pop()];
  if (expr.includes('||')) return splitTop(expr.replace(/\|\|/g, '\u0000'), '\u0000').map(x => cell(evalSqlExpr(x, row))).join('');
  const js = expr.replace(/<>/g, '!=').replace(/\bAND\b/ig, '&&').replace(/\bOR\b/ig, '||')
    .replace(/(?<![<>=!])=(?!=)/g, '==')
    .replace(/\b([A-Za-z_]\w*)\b/g, (x) => Object.prototype.hasOwnProperty.call(row, x) ? JSON.stringify(row[x]) : x);
  try { return Function(`return (${js})`)(); } catch (_) { return expr; }
}
function evalCondition(expr, row) { return evalSqlExpr(expr, row); }
function truth(v) { return !!v && v !== '0'; }

function selectStatement(sql) {
  const union = splitUnionAll(sql);
  if (union.length > 1) {
    const parts = union.map(selectStatement);
    return { columns: parts[0].columns, rows: parts.flatMap(p => p.rows) };
  }
  const m = sql.match(/^SELECT\s+([\s\S]+?)(?:\s+FROM\s+("?[\w.-]+"?))?(?:\s+WHERE\s+([\s\S]+?))?(?:\s+ORDER\s+BY\s+([\s\S]+?))?(?:\s+LIMIT\s+(\d+))?$/i);
  if (!m) throw new Error('near "SELECT": syntax error');
  const list = splitTop(m[1], ',');
  let rows = m[2] ? table(m[2]).rows.slice() : [{}];
  if (m[3]) rows = rows.filter(r => truth(evalCondition(m[3], r)));
  if (m[4]) {
    const key = cleanIdent(m[4].trim().split(/\s+/)[0]);
    rows.sort((a, b) => (a[key] > b[key]) - (a[key] < b[key]));
  }
  if (m[5]) rows = rows.slice(0, Number(m[5]));
  if (list.length === 1 && /^\s*count\s*\(\s*\*\s*\)\s*(?:as\s+(\w+))?\s*$/i.test(list[0])) {
    const name = (list[0].match(/as\s+(\w+)/i) || [,'count(*)'])[1];
    return { columns: [name], rows: [[rows.length]] };
  }
  if (list.length === 1 && list[0].trim() === '*') {
    const t = table(m[2]);
    return { columns: t.columns, rows: rows.map(r => t.columns.map(c => r[c])) };
  }
  const columns = list.map(item => {
    let mm = item.match(/\s+AS\s+("?[\w.-]+"?)\s*$/i);
    if (mm) return cleanIdent(mm[1]);
    mm = item.match(/\s+("?[\w.-]+"?)\s*$/);
    if (mm && !/[+\-*\/()']/.test(item.slice(0, mm.index))) return cleanIdent(mm[1]);
    return item.trim();
  });
  const exprs = list.map((item, i) => item.replace(/\s+AS\s+("?[\w.-]+"?)\s*$/i, '').replace(new RegExp(`\\s+${columns[i]}$`), '').trim());
  return { columns, rows: rows.map(r => exprs.map(e => evalSqlExpr(e, r))) };
}

function splitUnionAll(sql) {
  const out = []; let cur = '', q = null, depth = 0;
  for (let i = 0; i < sql.length; i++) {
    const rest = sql.slice(i);
    const c = sql[i], n = sql[i + 1];
    if (!q && depth === 0 && /^UNION\s+ALL\b/i.test(rest)) {
      out.push(cur.trim());
      cur = '';
      i += rest.match(/^UNION\s+ALL\b/i)[0].length - 1;
      continue;
    }
    cur += c;
    if (q) {
      if (c === q) { if (n === q && q === "'") cur += sql[++i]; else q = null; }
    } else if (c === "'" || c === '"' || c === '`') q = c;
    else if (c === '(') depth++;
    else if (c === ')') depth--;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function splitLinesScript(text) {
  const items = [];
  let sql = '';
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trimEnd();
    if (line.trimStart().startsWith('.')) {
      if (sql.trim()) { items.push({ type: 'sql', text: sql }); sql = ''; }
      items.push({ type: 'dot', text: line.trim() });
    } else {
      sql += raw + '\n';
      if (sqliteComplete(sql)) {
        items.push({ type: 'sql', text: sql });
        sql = '';
      }
    }
  }
  if (sql.trim()) items.push({ type: 'sql', text: sql });
  return items;
}

function sqliteComplete(sql) {
  let q = null, esc = false, line = false, block = false;
  let lastSemi = false;
  for (let i = 0; i < sql.length; i++) {
    const c = sql[i], n = sql[i + 1];
    if (line) { if (c === '\n') line = false; continue; }
    if (block) { if (c === '*' && n === '/') { block = false; i++; } continue; }
    if (q) {
      if (q === '[' && c === ']') q = null;
      else if (q !== '[' && c === q) {
        if (n === q && q === "'") i++;
        else q = null;
      }
      continue;
    }
    if (c === '-' && n === '-') { line = true; i++; continue; }
    if (c === '/' && n === '*') { block = true; i++; continue; }
    if (c === "'" || c === '"' || c === '`' || c === '[') { q = c; continue; }
    if (!/\s/.test(c)) lastSemi = c === ';';
  }
  return lastSemi && !q && !block;
}

function display(result) {
  if (!result.columns.length) return;
  const cols = result.columns;
  const rows = result.rows;
  switch (st.mode) {
    case 'csv': return writeCsv(cols, rows);
    case 'json': return writeJson(cols, rows);
    case 'html': return writeHtml(cols, rows);
    case 'line': return writeLine(cols, rows);
    case 'quote': return writeQuote(rows);
    case 'column': return writeColumn(cols, rows, st.headers);
    case 'table': return writeTable(cols, rows, 'ascii');
    case 'box': return writeTable(cols, rows, 'box');
    case 'markdown': return writeMarkdown(cols, rows);
    case 'tabs': return writeList(rows, '\t');
    case 'ascii': return writeList(rows, '\x1f', '\x1e');
    case 'list':
    default: return writeList(rows, st.sep, st.rowSep, st.headers ? cols : null);
  }
}

function cell(v) { return v === null ? st.nullValue : String(v); }
function width(s) { return [...String(s)].length; }
function pad(s, n, left) {
  s = String(s);
  const p = ' '.repeat(Math.max(0, n - width(s)));
  return left ? p + s : s + p;
}
function isNum(v) { return typeof v === 'number'; }

function writeList(rows, sep, rowSep = '\n', header = null) {
  if (header) process.stdout.write(header.join(sep) + rowSep);
  for (const r of rows) process.stdout.write(r.map(cell).join(sep) + rowSep);
}

function csvField(v) {
  if (v === null) return '';
  const s = String(v);
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
function writeCsv(cols, rows) {
  if (st.headers) process.stdout.write(cols.map(csvField).join(',') + '\r\n');
  for (const r of rows) process.stdout.write(r.map(csvField).join(',') + '\r\n');
}

function writeJson(cols, rows) {
  const arr = rows.map(r => Object.fromEntries(cols.map((c, i) => [c, r[i]])));
  if (arr.length === 0) process.stdout.write('[]\n');
  else {
    process.stdout.write('[');
    arr.forEach((x, i) => process.stdout.write((i ? ',\n' : '') + JSON.stringify(x)));
    process.stdout.write(']\n');
  }
}

function htmlEsc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function writeHtml(cols, rows) {
  if (st.headers) {
    process.stdout.write('<TR>\n');
    for (const c of cols) process.stdout.write(`<TH>${htmlEsc(c)}\n`);
    process.stdout.write('</TR>\n');
  }
  for (const r of rows) {
    process.stdout.write('<TR>\n');
    for (const v of r) process.stdout.write(`<TD>${htmlEsc(v === null ? 'null' : v)}\n`);
    process.stdout.write('</TR>\n');
  }
}

function writeLine(cols, rows) {
  let max = Math.max(0, ...cols.map(width));
  for (const r of rows) {
    cols.forEach((c, i) => process.stdout.write(`${pad(c, max, true)} = ${cell(r[i])}\n`));
    process.stdout.write('\n');
  }
}

function sqlQuote(v) {
  if (v === null) return 'NULL';
  if (typeof v === 'number') return String(v);
  return "'" + String(v).replace(/'/g, "''") + "'";
}
function writeQuote(rows) {
  for (const r of rows) process.stdout.write(r.map(sqlQuote).join(',') + '\n');
}

function matrix(cols, rows) {
  const data = [cols, ...rows.map(r => r.map(cell))];
  const w = cols.map((_, i) => Math.max(...data.map(r => width(r[i]))));
  return { data, w };
}
function writeColumn(cols, rows, headersOn = st.headers) {
  const { w } = matrix(cols, rows);
  if (headersOn) {
    process.stdout.write(cols.map((c, i) => pad(c, w[i], false)).join('  ') + '\n');
    process.stdout.write(w.map(n => '-'.repeat(n)).join('  ') + '\n');
  }
  for (const r of rows) process.stdout.write(r.map((v, i) => pad(cell(v), w[i], !isNum(v))).join('  ') + '\n');
}

function writeTable(cols, rows, kind) {
  const { w } = matrix(cols, rows);
  const chars = kind === 'box'
    ? ['╭','┬','╮','├','┼','┤','╰','┴','╯','│','─','╞','╪','╡','═']
    : ['+','+','+','+','+','+','+','+','+','|','-','+','+','+','='];
  const border = (l, m, r, fill) => l + w.map(n => fill.repeat(n + 2)).join(m) + r + '\n';
  process.stdout.write(border(chars[0], chars[1], chars[2], chars[10]));
  process.stdout.write(chars[9] + cols.map((c, i) => ' ' + pad(c, w[i], false) + ' ').join(chars[9]) + chars[9] + '\n');
  process.stdout.write(kind === 'box' ? border(chars[11], chars[12], chars[13], chars[14]) : border(chars[3], chars[4], chars[5], chars[10]));
  for (const r of rows) process.stdout.write(chars[9] + r.map((v, i) => ' ' + pad(cell(v), w[i], !isNum(v)) + ' ').join(chars[9]) + chars[9] + '\n');
  process.stdout.write(border(chars[6], chars[7], chars[8], chars[10]));
}

function writeMarkdown(cols, rows) {
  const { w } = matrix(cols, rows);
  process.stdout.write('| ' + cols.map((c, i) => pad(c, w[i], false)).join(' | ') + ' |\n');
  process.stdout.write('|' + w.map(n => '-'.repeat(n + 2)).join('|') + '|\n');
  for (const r of rows) process.stdout.write('| ' + r.map((v, i) => pad(cell(v), w[i], !isNum(v))).join(' | ') + ' |\n');
}

function query(sql) { return runBridge(sql); }
function firstRows(sql) { const r = query(sql); return r.length ? r[r.length - 1].rows : []; }

function dot(line) {
  const parts = line.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
  const cmd = parts[0].slice(1);
  const args = parts.slice(1).map(unquoteArg);
  switch (cmd) {
    case 'help':
      process.stdout.write(`.archive ...             Manage SQL archives
.bail on|off             Stop after hitting an error.  Default OFF
.cd DIRECTORY            Change the working directory to DIRECTORY
.databases               List names and files of attached databases
.dump ?OBJECTS?          Render database content as SQL
.echo on|off             Turn command echo on or off
.exit ?CODE?             Exit this program with return-code CODE
.headers on|off          Turn display of headers on or off
.help ?-all? ?PATTERN?   Show help text for PATTERN
.import FILE TABLE       Import data from FILE into TABLE
.indexes ?PATTERN?       Show names of indexes matching PATTERN
.mode ?MODE? ?OPTIONS?   Set output mode
.nullvalue STRING        Use STRING in place of NULL values
.open ?OPTIONS? ?FILE?   Close existing database and reopen FILE
.output ?FILE?           Send output to FILE or stdout if FILE is omitted
.quit                    Exit this program
.read FILE               Read input from FILE or command output
.schema ?PATTERN?        Show the CREATE statements matching PATTERN
.separator COL ?ROW?     Change the column and row separators
.tables ?PATTERN?        List names of tables matching LIKE pattern
`);
      break;
    case 'mode':
      if (!args.length) process.stdout.write(`.mode ${st.mode}\n`);
      else {
        st.mode = args[0];
        if (st.mode === 'tabs') st.sep = '\t';
        if (st.mode === 'ascii') { st.sep = '\x1f'; st.rowSep = '\x1e'; }
      }
      break;
    case 'headers':
    case 'header':
      if (!args.length) process.stdout.write('Usage: .headers on|off\n');
      else st.headers = /^(on|yes|1|true)$/i.test(args[0]);
      break;
    case 'bail':
      if (args.length) st.bail = /^(on|yes|1|true)$/i.test(args[0]);
      break;
    case 'echo':
      if (args.length) st.echo = /^(on|yes|1|true)$/i.test(args[0]);
      break;
    case 'nullvalue':
      st.nullValue = args.join(' ');
      break;
    case 'separator':
      if (args[0]) st.sep = decodeEsc(args[0]);
      if (args[1]) st.rowSep = decodeEsc(args[1]);
      break;
    case 'tables': {
      loadDb();
      let names = st.data.order.filter(n => !n.startsWith('sqlite_'));
      if (args[0]) names = names.filter(n => like(n, args[0]));
      if (names.length) process.stdout.write(names.sort().join('     ') + '\n');
      break;
    }
    case 'indexes': {
      break;
    }
    case 'schema':
    case 'fullschema': {
      loadDb();
      let names = st.data.order.slice();
      if (args[0]) names = names.filter(n => like(n, args[0]));
      for (const n of names) process.stdout.write(String(st.data.tables[n].sql).replace(/;?\s*$/, ';') + '\n');
      break;
    }
    case 'databases':
      process.stdout.write(`main: "${st.tempDb ? '' : (st.db === ':memory:' ? '' : path.resolve(st.db))}" r/w\n`);
      break;
    case 'dump':
      dumpDb(args);
      break;
    case 'read':
      if (!args[0]) throw new Error('missing file');
      executeScript(fs.readFileSync(args[0], 'utf8'));
      break;
    case 'open':
      st.db = args.at(-1) || ':memory:';
      break;
    case 'cd':
      process.chdir(args[0] || os.homedir());
      break;
    case 'exit':
    case 'quit':
      process.exit(args[0] ? Number(args[0]) : st.exitCode);
      break;
    default:
      process.stderr.write(`Error: unknown command or invalid arguments:  "${line}". Enter ".help" for help\n`);
      if (st.bail) process.exit(1);
  }
}

function dumpDb(args) {
  loadDb();
  process.stdout.write('PRAGMA foreign_keys=OFF;\nBEGIN TRANSACTION;\n');
  let names = st.data.order.slice();
  if (args[0]) names = names.filter(n => like(n, args[0]));
  for (const name of names) {
    const t = st.data.tables[name];
    process.stdout.write(String(t.sql).replace(/;?\s*$/, ';') + '\n');
    for (const r of t.rows) process.stdout.write(`INSERT INTO ${sqlQuoteIdent(name)} VALUES(${t.columns.map(c => sqlQuote(r[c])).join(',')});\n`);
  }
  process.stdout.write('COMMIT;\n');
}
function sqlQuoteIdent(s) { return '"' + String(s).replace(/"/g, '""') + '"'; }
function like(s, pat) {
  const re = '^' + String(pat).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/%/g, '.*').replace(/_/g, '.') + '$';
  return new RegExp(re, 'i').test(s);
}

function executeSql(sql, source) {
  if (st.echo) process.stdout.write(sql.trimEnd() + '\n');
  try {
    for (const r of runBridge(sql)) display(r);
  } catch (e) {
    const loc = source ? `near line ${source}` : 'in 2nd command line argument';
    process.stderr.write(`Parse error ${loc}: ${e.message}\n`);
    st.exitCode = 1;
    if (st.bail) process.exit(1);
  }
}

function executeScript(text) {
  let lineNo = 1;
  for (const item of splitLinesScript(text)) {
    if (item.type === 'dot') dot(item.text);
    else executeSql(item.text, lineNo);
    lineNo += item.text.split(/\n/).length - 1;
  }
}

function main() {
  const { cmds, argSql } = parseArgs(process.argv.slice(2));
  for (const c of cmds) executeScript(c + (c.endsWith('\n') ? '' : '\n'));
  if (argSql) executeScript(argSql + '\n');
  else {
    let input = '';
    try { input = fs.readFileSync(0, 'utf8'); } catch (_) {}
    if (input) executeScript(input);
  }
  if (st.tempDb) { try { fs.unlinkSync(st.tempDb); } catch (_) {} }
  process.exit(st.exitCode);
}

main();
