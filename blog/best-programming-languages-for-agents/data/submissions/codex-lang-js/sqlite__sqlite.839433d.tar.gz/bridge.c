#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct sqlite3 sqlite3;
typedef struct sqlite3_stmt sqlite3_stmt;

#define SQLITE_OK 0
#define SQLITE_ROW 100
#define SQLITE_DONE 101
#define SQLITE_INTEGER 1
#define SQLITE_FLOAT 2
#define SQLITE_TEXT 3
#define SQLITE_BLOB 4
#define SQLITE_NULL 5
#define SQLITE_OPEN_READONLY 0x00000001
#define SQLITE_OPEN_READWRITE 0x00000002
#define SQLITE_OPEN_CREATE 0x00000004

static int (*p_open_v2)(const char*, sqlite3**, int, const char*);
static int (*p_close)(sqlite3*);
static const char *(*p_errmsg)(sqlite3*);
static int (*p_prepare_v2)(sqlite3*, const char*, int, sqlite3_stmt**, const char**);
static int (*p_step)(sqlite3_stmt*);
static int (*p_finalize)(sqlite3_stmt*);
static int (*p_column_count)(sqlite3_stmt*);
static const char *(*p_column_name)(sqlite3_stmt*, int);
static int (*p_column_type)(sqlite3_stmt*, int);
static long long (*p_column_int64)(sqlite3_stmt*, int);
static double (*p_column_double)(sqlite3_stmt*, int);
static const unsigned char *(*p_column_text)(sqlite3_stmt*, int);
static const void *(*p_column_blob)(sqlite3_stmt*, int);
static int (*p_column_bytes)(sqlite3_stmt*, int);
static const char *(*p_libversion)(void);

static void *sym(void *h, const char *name) {
  void *p = dlsym(h, name);
  if (!p) {
    fprintf(stderr, "missing sqlite symbol: %s\n", name);
    exit(99);
  }
  return p;
}

static void load_sqlite(void) {
  void *h = dlopen("libsqlite3.so.0", RTLD_NOW);
  if (!h) h = dlopen("libsqlite3.so", RTLD_NOW);
  if (!h) {
    fprintf(stderr, "cannot load libsqlite3\n");
    exit(99);
  }
  p_open_v2 = sym(h, "sqlite3_open_v2");
  p_close = sym(h, "sqlite3_close");
  p_errmsg = sym(h, "sqlite3_errmsg");
  p_prepare_v2 = sym(h, "sqlite3_prepare_v2");
  p_step = sym(h, "sqlite3_step");
  p_finalize = sym(h, "sqlite3_finalize");
  p_column_count = sym(h, "sqlite3_column_count");
  p_column_name = sym(h, "sqlite3_column_name");
  p_column_type = sym(h, "sqlite3_column_type");
  p_column_int64 = sym(h, "sqlite3_column_int64");
  p_column_double = sym(h, "sqlite3_column_double");
  p_column_text = sym(h, "sqlite3_column_text");
  p_column_blob = sym(h, "sqlite3_column_blob");
  p_column_bytes = sym(h, "sqlite3_column_bytes");
  p_libversion = sym(h, "sqlite3_libversion");
}

static char *read_all_stdin(void) {
  size_t cap = 8192, len = 0;
  char *buf = malloc(cap + 1);
  if (!buf) exit(99);
  for (;;) {
    if (len == cap) {
      cap *= 2;
      buf = realloc(buf, cap + 1);
      if (!buf) exit(99);
    }
    size_t n = fread(buf + len, 1, cap - len, stdin);
    len += n;
    if (n == 0) break;
  }
  buf[len] = 0;
  return buf;
}

static void json_str(const char *s, int n) {
  putchar('"');
  for (int i = 0; i < n; i++) {
    unsigned char c = (unsigned char)s[i];
    if (c == '"' || c == '\\') {
      putchar('\\'); putchar(c);
    } else if (c == '\n') {
      fputs("\\n", stdout);
    } else if (c == '\r') {
      fputs("\\r", stdout);
    } else if (c == '\t') {
      fputs("\\t", stdout);
    } else if (c < 32) {
      printf("\\u%04x", c);
    } else {
      putchar(c);
    }
  }
  putchar('"');
}

static void json_cstr(const char *s) {
  json_str(s ? s : "", s ? (int)strlen(s) : 0);
}

static int blank_sql(const char *z, const char *end) {
  while (z && z < end && *z) {
    if (*z!=' ' && *z!='\n' && *z!='\r' && *z!='\t' && *z!=';') return 0;
    z++;
  }
  return 1;
}

int main(int argc, char **argv) {
  load_sqlite();
  if (argc >= 2 && strcmp(argv[1], "--version") == 0) {
    puts(p_libversion());
    return 0;
  }
  if (argc < 2) {
    fprintf(stderr, "usage: bridge DBPATH [--readonly]\n");
    return 2;
  }
  char *sql = read_all_stdin();
  sqlite3 *db = NULL;
  int flags = (argc >= 3 && strcmp(argv[2], "--readonly") == 0)
    ? SQLITE_OPEN_READONLY
    : (SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE);
  int rc = p_open_v2(argv[1], &db, flags, NULL);
  if (rc != SQLITE_OK) {
    fprintf(stderr, "%s\n", db ? p_errmsg(db) : "cannot open database");
    if (db) p_close(db);
    free(sql);
    return 1;
  }
  const char *tail = sql;
  int idx = 0;
  while (tail && *tail) {
    sqlite3_stmt *stmt = NULL;
    const char *next = NULL;
    rc = p_prepare_v2(db, tail, -1, &stmt, &next);
    if (rc != SQLITE_OK) {
      fprintf(stdout, "{\"error\":");
      json_cstr(p_errmsg(db));
      fprintf(stdout, ",\"index\":%d}\n", idx + 1);
      p_close(db);
      free(sql);
      return 1;
    }
    if (!stmt) {
      if (!next || next == tail) break;
      tail = next;
      if (blank_sql(tail, tail + strlen(tail))) break;
      continue;
    }
    int cols = p_column_count(stmt);
    fprintf(stdout, "{\"columns\":[");
    for (int i = 0; i < cols; i++) {
      if (i) putchar(',');
      json_cstr(p_column_name(stmt, i));
    }
    fputs("],\"rows\":[", stdout);
    int row = 0;
    while ((rc = p_step(stmt)) == SQLITE_ROW) {
      if (row++) putchar(',');
      putchar('[');
      for (int i = 0; i < cols; i++) {
        if (i) putchar(',');
        int t = p_column_type(stmt, i);
        if (t == SQLITE_NULL) {
          fputs("null", stdout);
        } else if (t == SQLITE_INTEGER) {
          printf("%lld", p_column_int64(stmt, i));
        } else if (t == SQLITE_FLOAT) {
          printf("%.17g", p_column_double(stmt, i));
        } else if (t == SQLITE_BLOB) {
          const unsigned char *b = p_column_blob(stmt, i);
          int n = p_column_bytes(stmt, i);
          putchar('"');
          for (int j = 0; j < n; j++) printf("\\u%04x", b[j]);
          putchar('"');
        } else {
          const unsigned char *s = p_column_text(stmt, i);
          int n = p_column_bytes(stmt, i);
          json_str((const char*)s, n);
        }
      }
      putchar(']');
    }
    fputs("]}\n", stdout);
    int frc = p_finalize(stmt);
    if (rc != SQLITE_DONE || frc != SQLITE_OK) {
      fprintf(stdout, "{\"error\":");
      json_cstr(p_errmsg(db));
      fprintf(stdout, ",\"index\":%d}\n", idx + 1);
      p_close(db);
      free(sql);
      return 1;
    }
    idx++;
    if (!next || next == tail) break;
    tail = next;
  }
  p_close(db);
  free(sql);
  return 0;
}
