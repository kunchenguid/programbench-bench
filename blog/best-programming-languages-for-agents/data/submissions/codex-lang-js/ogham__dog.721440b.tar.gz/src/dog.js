#!/usr/bin/env node
'use strict';

const fs = require('fs');
const dgram = require('dgram');
const net = require('net');
const tls = require('tls');
const https = require('https');

const HELP = `dog ● command-line DNS client

Usage:
  dog [OPTIONS] [--] <arguments>

Examples:
  dog example.net                          Query a domain using default settings
  dog example.net MX                       ...looking up MX records instead
  dog example.net MX @1.1.1.1              ...using a specific nameserver instead
  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP
  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments

Query options:
  <arguments>              Human-readable host names, nameservers, types, or classes
  -q, --query=HOST         Host name or domain name to query
  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)
  -n, --nameserver=ADDR    Address of the nameserver to send packets to
  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)

Sending options:
  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)
  --txid=NUMBER            Set the transaction ID to a specific value
  -Z=TWEAKS                Set uncommon protocol-level tweaks

Protocol options:
  -U, --udp                Use the DNS protocol over UDP
  -T, --tcp                Use the DNS protocol over TCP
  -S, --tls                Use the DNS-over-TLS protocol
  -H, --https              Use the DNS-over-HTTPS protocol

Output options:
  -1, --short              Short mode: display nothing but the first result
  -J, --json               Display the output as JSON
  --color, --colour=WHEN   When to colourise the output (always, automatic, never)
  --seconds                Do not format durations, display them as seconds
  --time                   Print how long the response took to arrive

Meta options:
  -?, --help               Print list of command-line options
  -v, --version            Print version information`;

const VERSION = `dog ● command-line DNS client
v0.2.0-pre [d3a34280] built on 2026-04-17 (pre-release!)
mhttps://dns.lookup.dog/`;

const TYPES = {
  A: 1, NS: 2, CNAME: 5, SOA: 6, PTR: 12, HINFO: 13, MX: 15, TXT: 16, AAAA: 28,
  SRV: 33, NAPTR: 35, OPT: 41, SSHFP: 44, TLSA: 52, CAA: 257,
  AFSDB: 18, ANY: 255, AXFR: 252, IXFR: 251
};
const TYPE_NAMES = Object.fromEntries(Object.entries(TYPES).map(([k, v]) => [v, k]));
const CLASSES = { IN: 1, CH: 3, HS: 4 };
const CLASS_NAMES = { 1: 'IN', 3: 'CH', 4: 'HS' };

function dieOptions(msg) {
  console.error(`dog: Invalid options: ${msg}`);
  process.exit(3);
}

function splitOpt(arg) {
  const i = arg.indexOf('=');
  return i === -1 ? [arg, null] : [arg.slice(0, i), arg.slice(i + 1)];
}

function parseArgs(argv) {
  const cfg = {
    queries: [], types: [], classes: [], nameservers: [],
    protocol: 'udp', short: false, json: false, color: 'automatic',
    seconds: false, time: false, edns: 'hide', txid: null, tweaks: new Set()
  };
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '--') { positional.push(...argv.slice(i + 1)); break; }
    if (a === '-?' || a === '--help') { console.log(HELP); process.exit(0); }
    if (a === '-v' || a === '--version') { console.log(VERSION); process.exit(0); }
    const need = (name) => {
      if (i + 1 >= argv.length) dieOptions(`Option '${name}' needs a value`);
      return argv[++i];
    };
    if (a === '-q' || a === '--query') cfg.queries.push(need(a));
    else if (a.startsWith('--query=')) cfg.queries.push(a.slice(8));
    else if (a === '-t' || a === '--type') cfg.types.push(parseType(need(a)));
    else if (a.startsWith('--type=')) cfg.types.push(parseType(a.slice(7)));
    else if (a === '-n' || a === '--nameserver') cfg.nameservers.push(parseNs(need(a)));
    else if (a.startsWith('--nameserver=')) cfg.nameservers.push(parseNs(a.slice(13)));
    else if (a === '--class') cfg.classes.push(parseClass(need(a)));
    else if (a.startsWith('--class=')) cfg.classes.push(parseClass(a.slice(8)));
    else if (a === '--edns') cfg.edns = parseEdns(need(a));
    else if (a.startsWith('--edns=')) cfg.edns = parseEdns(a.slice(7));
    else if (a === '--txid') cfg.txid = parseTxid(need(a));
    else if (a.startsWith('--txid=')) cfg.txid = parseTxid(a.slice(7));
    else if (a === '-Z') cfg.tweaks.add(parseTweak(need(a)));
    else if (a.startsWith('-Z=')) cfg.tweaks.add(parseTweak(a.slice(3)));
    else if (a === '-U' || a === '--udp') cfg.protocol = 'udp';
    else if (a === '-T' || a === '--tcp') cfg.protocol = 'tcp';
    else if (a === '-S' || a === '--tls') cfg.protocol = 'tls';
    else if (a === '-H' || a === '--https') cfg.protocol = 'https';
    else if (a === '-1' || a === '--short') cfg.short = true;
    else if (a === '-J' || a === '--json') cfg.json = true;
    else if (a === '--seconds') cfg.seconds = true;
    else if (a === '--time') cfg.time = true;
    else if (a === '--color' || a === '--colour') cfg.color = parseColor(need(a));
    else if (a.startsWith('--color=') || a.startsWith('--colour=')) cfg.color = parseColor(splitOpt(a)[1]);
    else if (a.startsWith('-')) dieOptions(`Unrecognized option: '${a.replace(/^-+/, '')}'`);
    else positional.push(a);
  }
  for (const p of positional) {
    if (p.startsWith('@')) cfg.nameservers.push(parseNs(p.slice(1)));
    else if (TYPES[p.toUpperCase()] !== undefined) cfg.types.push(parseType(p));
    else if (CLASSES[p.toUpperCase()] !== undefined) cfg.classes.push(parseClass(p));
    else cfg.queries.push(p);
  }
  if (cfg.queries.length === 0) { console.log(HELP); process.exit(3); }
  if (cfg.types.length === 0) cfg.types.push({ name: 'A', code: 1 });
  if (cfg.classes.length === 0) cfg.classes.push({ name: 'IN', code: 1 });
  if (cfg.nameservers.length === 0) cfg.nameservers.push(defaultNs(cfg.protocol));
  return cfg;
}

function parseType(s) {
  const u = String(s).toUpperCase();
  if (TYPES[u] === undefined) dieOptions(`Invalid query type "${s}"`);
  return { name: u, code: TYPES[u] };
}
function parseClass(s) {
  const u = String(s).toUpperCase();
  if (CLASSES[u] === undefined) dieOptions(`Invalid query class "${s}"`);
  return { name: u, code: CLASSES[u] };
}
function parseEdns(s) {
  if (!['disable', 'hide', 'show'].includes(s)) dieOptions(`Invalid EDNS setting "${s}"`);
  return s;
}
function parseColor(s) {
  if (!['always', 'automatic', 'never'].includes(s)) return 'automatic';
  return s;
}
function parseTxid(s) {
  if (!/^\d+$/.test(s) || Number(s) < 0 || Number(s) > 65535) dieOptions(`Invalid transaction ID "${s}"`);
  return Number(s);
}
function parseTweak(s) {
  if (s === 'aa' || s === 'ad' || s === 'cd' || /^bufsize=\d+$/.test(s)) return s;
  dieOptions(`Invalid protocol tweak "${s}"`);
}
function parseNs(s) {
  if (/^https?:\/\//i.test(s)) return { host: s, port: 443, raw: s };
  let host = s, port = null;
  if (s.startsWith('[')) {
    const j = s.indexOf(']');
    host = s.slice(1, j);
    if (s[j + 1] === ':') port = Number(s.slice(j + 2));
  } else {
    const idx = s.lastIndexOf(':');
    if (idx > -1 && s.indexOf(':') === idx) {
      host = s.slice(0, idx);
      port = Number(s.slice(idx + 1));
    }
  }
  return { host, port: port || 53, raw: s };
}
function defaultNs(protocol) {
  if (protocol === 'https') return parseNs('https://1.1.1.1/dns-query');
  try {
    const text = fs.readFileSync('/etc/resolv.conf', 'utf8');
    const m = text.match(/^\s*nameserver\s+(\S+)/m);
    if (m) return parseNs(m[1]);
  } catch (_) {}
  return parseNs('1.1.1.1');
}

function encodeName(name) {
  const clean = name.endsWith('.') ? name.slice(0, -1) : name;
  if (!clean) return Buffer.from([0]);
  return Buffer.concat(clean.split('.').map(p => {
    const b = Buffer.from(p);
    return Buffer.concat([Buffer.from([b.length]), b]);
  }).concat([Buffer.from([0])]));
}

function buildQuery(qname, qtype, qclass, cfg) {
  const id = cfg.txid ?? Math.floor(Math.random() * 65536);
  let flags = 0x0100;
  if (cfg.tweaks.has('aa')) flags |= 0x0400;
  if (cfg.tweaks.has('ad')) flags |= 0x0020;
  if (cfg.tweaks.has('cd')) flags |= 0x0010;
  const q = Buffer.concat([encodeName(qname), u16(qtype), u16(qclass)]);
  const extra = [];
  if (cfg.edns !== 'disable') {
    let size = 4096;
    for (const t of cfg.tweaks) if (t.startsWith('bufsize=')) size = Number(t.slice(8));
    extra.push(Buffer.concat([Buffer.from([0]), u16(41), u16(size), Buffer.alloc(6)]));
  }
  const h = Buffer.alloc(12);
  h.writeUInt16BE(id, 0); h.writeUInt16BE(flags, 2); h.writeUInt16BE(1, 4);
  h.writeUInt16BE(0, 6); h.writeUInt16BE(0, 8); h.writeUInt16BE(extra.length, 10);
  return Buffer.concat([h, q, ...extra]);
}
function u16(n) { const b = Buffer.alloc(2); b.writeUInt16BE(n); return b; }

function sendUdp(packet, ns) {
  return new Promise((resolve, reject) => {
    const s = dgram.createSocket(net.isIPv6(ns.host) ? 'udp6' : 'udp4');
    const timer = setTimeout(() => { s.close(); reject(new Error('Timed out')); }, 5000);
    s.once('error', e => { clearTimeout(timer); s.close(); reject(e); });
    s.once('message', msg => { clearTimeout(timer); s.close(); resolve(msg); });
    s.connect(ns.port, ns.host, () => s.send(packet));
  });
}
function sendTcp(packet, ns, secure = false) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    const sock = secure ? tls.connect({ host: ns.host, port: ns.port || 853, servername: ns.host, rejectUnauthorized: false })
                        : net.connect({ host: ns.host, port: ns.port || 53 });
    const timer = setTimeout(() => { sock.destroy(); reject(new Error('Timed out')); }, 7000);
    sock.once('error', e => { clearTimeout(timer); reject(e); });
    sock.on('data', c => {
      chunks.push(c);
      const all = Buffer.concat(chunks);
      if (all.length >= 2 && all.length >= 2 + all.readUInt16BE(0)) {
        clearTimeout(timer); sock.end(); resolve(all.subarray(2, 2 + all.readUInt16BE(0)));
      }
    });
    sock.once(secure ? 'secureConnect' : 'connect', () => sock.write(Buffer.concat([u16(packet.length), packet])));
  });
}
function sendHttps(packet, ns) {
  return new Promise((resolve, reject) => {
    const url = new URL(ns.raw);
    const req = https.request({
      method: 'POST', hostname: url.hostname, port: url.port || 443, path: url.pathname + url.search,
      rejectUnauthorized: false, headers: { 'content-type': 'application/dns-message', 'accept': 'application/dns-message', 'content-length': packet.length }
    }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.setTimeout(7000, () => req.destroy(new Error('Timed out')));
    req.on('error', reject);
    req.end(packet);
  });
}

function readName(buf, off, seen = new Set()) {
  const labels = [];
  let jumped = false, end = off;
  while (off < buf.length) {
    const len = buf[off];
    if ((len & 0xc0) === 0xc0) {
      const ptr = ((len & 0x3f) << 8) | buf[off + 1];
      if (seen.has(ptr)) return ['.', off + 2];
      seen.add(ptr);
      if (!jumped) end = off + 2;
      off = ptr; jumped = true; continue;
    }
    off++;
    if (len === 0) { if (!jumped) end = off; break; }
    labels.push(buf.subarray(off, off + len).toString());
    off += len;
    if (!jumped) end = off;
  }
  return [(labels.join('.') || '') + '.', end];
}

function parsePacket(buf) {
  const counts = { qd: buf.readUInt16BE(4), an: buf.readUInt16BE(6), ns: buf.readUInt16BE(8), ar: buf.readUInt16BE(10) };
  let off = 12;
  const queries = [];
  for (let i = 0; i < counts.qd; i++) {
    let r = readName(buf, off); off = r[1];
    const type = buf.readUInt16BE(off), cls = buf.readUInt16BE(off + 2); off += 4;
    queries.push({ name: r[0], class: CLASS_NAMES[cls] || String(cls), type: TYPE_NAMES[type] || String(type) });
  }
  const readRR = () => {
    let r = readName(buf, off); off = r[1];
    const type = buf.readUInt16BE(off), cls = buf.readUInt16BE(off + 2), ttl = buf.readUInt32BE(off + 4), len = buf.readUInt16BE(off + 8);
    off += 10;
    const start = off, end = off + len; off = end;
    const name = r[0], typeName = TYPE_NAMES[type] || String(type), className = CLASS_NAMES[cls] || String(cls);
    return { name, class: className, ttl, type: typeName, data: decodeRdata(buf, start, end, type) };
  };
  const answers = [], authorities = [], additionals = [];
  for (let i = 0; i < counts.an; i++) answers.push(readRR());
  for (let i = 0; i < counts.ns; i++) authorities.push(readRR());
  for (let i = 0; i < counts.ar; i++) additionals.push(readRR());
  return { queries, answers, authorities, additionals };
}

function decodeRdata(buf, start, end, type) {
  const raw = [...buf.subarray(start, end)];
  try {
    if (type === 1 && end - start === 4) return { address: raw.join('.') };
    if (type === 28 && end - start === 16) return { address: formatIPv6(buf.subarray(start, end)) };
    if ([2, 5, 12].includes(type)) return { domain: readName(buf, start)[0] };
    if (type === 15) return { preference: buf.readUInt16BE(start), exchange: readName(buf, start + 2)[0] };
    if (type === 16) {
      const texts = []; let p = start;
      while (p < end) { const l = buf[p++]; texts.push(buf.subarray(p, p + l).toString()); p += l; }
      return { strings: texts };
    }
    if (type === 6) {
      let a = readName(buf, start), b = readName(buf, a[1]); let p = b[1];
      return { mname: a[0], rname: b[0], serial: buf.readUInt32BE(p), refresh: buf.readUInt32BE(p + 4), retry: buf.readUInt32BE(p + 8), expire: buf.readUInt32BE(p + 12), minimum: buf.readUInt32BE(p + 16) };
    }
    if (type === 33) return { priority: buf.readUInt16BE(start), weight: buf.readUInt16BE(start + 2), port: buf.readUInt16BE(start + 4), target: readName(buf, start + 6)[0] };
    if (type === 257) {
      const flags = buf[start], tagLen = buf[start + 1], tag = buf.subarray(start + 2, start + 2 + tagLen).toString(), value = buf.subarray(start + 2 + tagLen, end).toString();
      return { flags, tag, value };
    }
  } catch (_) {}
  return { bytes: raw };
}

function formatIPv6(b) {
  const parts = [];
  for (let i = 0; i < 16; i += 2) parts.push(b.readUInt16BE(i).toString(16));
  let bestStart = -1, bestLen = 0;
  for (let i = 0; i < parts.length;) {
    if (parts[i] !== '0') { i++; continue; }
    let j = i; while (j < parts.length && parts[j] === '0') j++;
    if (j - i > bestLen) { bestStart = i; bestLen = j - i; }
    i = j;
  }
  if (bestLen > 1) {
    const left = parts.slice(0, bestStart).join(':'), right = parts.slice(bestStart + bestLen).join(':');
    return `${left}::${right}`.replace(/^:/, '::').replace(/:$/, '::');
  }
  return parts.join(':');
}

function rrValue(rr, json = false) {
  const d = rr.data;
  if (d.address) return d.address;
  if (d.domain) return json ? d.domain : `"${d.domain}"`;
  if (d.exchange) return `${d.preference} "${d.exchange}"`;
  if (d.strings) return d.strings.map(s => `"${s}"`).join(' ');
  if (d.mname) return `"${d.mname}" "${d.rname}" ${d.serial} ${duration(d.refresh)} ${duration(d.retry)} ${duration(d.expire)} ${duration(d.minimum)}`;
  if (d.target) return `${d.priority} ${d.weight} ${d.port} "${d.target}"`;
  if (d.tag) return `${d.flags} ${d.tag} "${d.value}"`;
  if (d.bytes) return d.bytes.join(' ');
  return JSON.stringify(d);
}
function duration(s, secondsOnly = false) {
  if (secondsOnly) return String(s);
  if (s % 3600 === 0 && s >= 3600) return `${s / 3600}h00m00s`;
  if (s >= 60) return `${Math.floor(s / 60)}m${String(s % 60).padStart(2, '0')}s`;
  return `${s}s`;
}
function color(s, code, enabled) { return enabled ? `\x1b[${code}m${s}\x1b[0m` : s; }

function printText(responses, cfg) {
  const all = responses.flatMap(r => r.answers);
  if (cfg.short) {
    if (all.length === 0) { console.error('No results'); process.exitCode = 2; return; }
    console.log(rrValue(all[0], true));
    return;
  }
  const useColor = cfg.color === 'always';
  for (const rr of all) {
    const left = `${color(rr.type, '1;32', useColor)} ${color(rr.name, '1;34', useColor)} ${duration(rr.ttl, cfg.seconds)}`;
    console.log(`${left}   ${rrValue(rr)}`);
  }
}

function jsonReady(resp) {
  return resp;
}

async function main() {
  const cfg = parseArgs(process.argv.slice(2));
  const responses = [];
  const started = Date.now();
  let hadError = false, firstError = null;
  for (const q of cfg.queries) for (const t of cfg.types) for (const c of cfg.classes) for (const ns of cfg.nameservers) {
    const packet = buildQuery(q, t.code, c.code, cfg);
    try {
      let reply;
      if (cfg.protocol === 'tcp') reply = await sendTcp(packet, ns, false);
      else if (cfg.protocol === 'tls') reply = await sendTcp(packet, { ...ns, port: ns.port || 853 }, true);
      else if (cfg.protocol === 'https') reply = await sendHttps(packet, ns);
      else reply = await sendUdp(packet, ns);
      responses.push(parsePacket(reply));
    } catch (e) {
      hadError = true; firstError = firstError || e;
    }
  }
  if (cfg.json) {
    console.log(JSON.stringify({ responses: responses.map(jsonReady) }));
    if (hadError) console.error(JSON.stringify({ error: true, error_phase: 'network', error_message: cleanErr(firstError) }));
  } else {
    if (hadError) console.error(`Error [network]: ${cleanErr(firstError)}`);
    printText(responses, cfg);
  }
  if (cfg.time) console.log(`Ran in ${Date.now() - started}ms`);
  if (hadError && !cfg.short) process.exitCode = 1;
}
function cleanErr(e) {
  const m = e && e.message ? e.message : String(e);
  if (/ECONNREFUSED/.test(m)) return 'Connection refused (os error 111)';
  if (/ENETUNREACH/.test(m)) return 'Network is unreachable (os error 101)';
  return m;
}

main().catch(e => { console.error(`Error [network]: ${cleanErr(e)}`); process.exit(1); });
