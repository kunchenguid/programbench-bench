#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');

const VERSION = `ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers`;
const BUILD = `built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)`;
const CONFIG = `configuration: --disable-ffplay --disable-ffprobe`;
const LIBS = [
  `libavutil      60. 25.100 / 60. 25.100`,
  `libavcodec     62. 23.103 / 62. 23.103`,
  `libavformat    62.  9.101 / 62.  9.101`,
  `libavdevice    62.  2.100 / 62.  2.100`,
  `libavfilter    11. 12.100 / 11. 12.100`,
  `libswscale      9.  3.100 /  9.  3.100`,
  `libswresample   6.  2.100 /  6.  2.100`,
];

const HELP = `Universal media converter
usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...

Getting help:
    -h      -- print basic options
    -h long -- print more options
    -h full -- print all options (including all format and codec specific options, very long)
    -h type=name -- print all options for the named decoder/encoder/demuxer/muxer/filter/bsf/protocol
    See man ffmpeg for detailed description of the options.

Per-stream options can be followed by :<stream_spec> to apply that option to specific streams only. <stream_spec> can be a stream index, or v/a/s for video/audio/subtitle (see manual for full syntax).

Print help / information / capabilities:
-L                  show license
-license            show license
-h <topic>          show help
-version            show version
-muxers             show available muxers
-demuxers           show available demuxers
-devices            show available devices
-decoders           show available decoders
-encoders           show available encoders
-filters            show available filters
-pix_fmts           show available pixel formats
-layouts            show standard channel layouts
-sample_fmts        show available audio sample formats

Global options (affect whole program instead of just one file):
-v <loglevel>       set logging level
-y                  overwrite output files
-n                  never overwrite output files
-print_graphs       print execution graph data to stderr
-print_graphs_file <filename>  write execution graph data to the specified file
-print_graphs_format <format>  set the output printing format (available formats are: default, compact, csv, flat, ini, json, xml, mermaid, mermaidhtml)
-stats              print progress report during encoding

Per-file options (input and output):
-f <fmt>            force container format (auto-detected otherwise)
-t <duration>       stop transcoding after specified duration
-to <time_stop>     stop transcoding after specified time is reached
-ss <time_off>      start transcoding at specified time


Per-file options (output-only):
-metadata[:<spec>] <key=value>  add metadata

Per-stream options:
-c[:<stream_spec>] <codec>  select encoder/decoder ('copy' to copy stream without reencoding)
-filter[:<stream_spec>] <filter_graph>  apply specified filters to audio/video

Video options:
-r[:<stream_spec>] <rate>  override input framerate/convert to given output framerate (Hz value, fraction or abbreviation)
-aspect[:<stream_spec>] <aspect>  set aspect ratio (4:3, 16:9 or 1.3333, 1.7777)
-vn                 disable video
-vcodec <codec>     alias for -c:v (select encoder/decoder for video streams)
-vf <filter_graph>  alias for -filter:v (apply filters to video streams)
-b <bitrate>        video bitrate (please use -b:v)

Audio options:
-aq <quality>       set audio quality (codec-specific)
-ar[:<stream_spec>] <rate>  set audio sampling rate (in Hz)
-ac[:<stream_spec>] <channels>  set number of audio channels
-an                 disable audio
-acodec <codec>     alias for -c:a (select encoder/decoder for audio streams)
-ab <bitrate>       alias for -b:a (select bitrate for audio streams)
-af <filter_graph>  alias for -filter:a (apply filters to audio streams)

Subtitle options:
-sn                 disable subtitle
-scodec <codec>     alias for -c:s (select encoder/decoder for subtitle streams)
`;

const LICENSE = `ffmpeg is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

ffmpeg is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with ffmpeg; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA`;

const FORMATS = [
  ['D  ', 'aac', 'raw ADTS AAC (Advanced Audio Coding)'],
  ['DE ', 'ac3', 'raw AC-3'],
  [' E ', 'adts', 'ADTS AAC (Advanced Audio Coding)'],
  ['DE ', 'aiff', 'Audio IFF'],
  ['DE ', 'alaw', 'PCM A-law'],
  ['DE ', 'apng', 'Animated Portable Network Graphics'],
  ['DE ', 'asf', 'ASF (Advanced / Active Streaming Format)'],
  ['DE ', 'ass', 'SSA (SubStation Alpha) subtitle'],
  ['DE ', 'au', 'Sun AU'],
  ['DE ', 'avi', 'AVI (Audio Video Interleaved)'],
  [' E ', 'crc', 'CRC testing'],
  ['DE ', 'data', 'raw data'],
  [' E ', 'ffmetadata', 'FFmpeg metadata in text'],
  [' E ', 'flac', 'raw FLAC'],
  [' E ', 'flv', 'FLV (Flash Video)'],
  [' E ', 'framecrc', 'framecrc testing'],
  [' E ', 'framehash', 'Per-frame hash testing'],
  [' E ', 'framemd5', 'Per-frame MD5 testing'],
  ['DE ', 'gif', 'CompuServe Graphics Interchange Format (GIF)'],
  [' E ', 'hash', 'Hash testing'],
  ['DE ', 'h264', 'raw H.264 video'],
  ['DE ', 'image2', 'image2 sequence'],
  ['DE ', 'matroska,webm', 'Matroska / WebM'],
  ['DE ', 'mov,mp4,m4a,3gp,3g2,mj2', 'QuickTime / MOV'],
  ['DE ', 'mp3', 'MP3 (MPEG audio layer 3)'],
  [' E ', 'mp4', 'MP4 (MPEG-4 Part 14)'],
  ['DE ', 'mpeg', 'MPEG-PS (MPEG-2 Program Stream)'],
  ['DE ', 'mpegts', 'MPEG-TS (MPEG-2 Transport Stream)'],
  [' E ', 'null', 'raw null video'],
  ['DE ', 'ogg', 'Ogg'],
  ['DE ', 'rawvideo', 'raw video'],
  ['DE ', 's16le', 'PCM signed 16-bit little-endian'],
  ['DE ', 'u16le', 'PCM unsigned 16-bit little-endian'],
  ['DE ', 'wav', 'WAV / WAVE (Waveform Audio)'],
  ['DE ', 'webm', 'WebM'],
  ['DE ', 'yuv4mpegpipe', 'YUV4MPEG pipe'],
];

const ENCODERS = [
  ['V....D', 'bmp', 'BMP (Windows and OS/2 bitmap)'],
  ['V....D', 'gif', 'GIF (Graphics Interchange Format)'],
  ['V.....', 'h264_v4l2m2m', 'V4L2 mem2mem H.264 encoder wrapper (codec h264)'],
  ['VF...D', 'mjpeg', 'MJPEG (Motion JPEG)'],
  ['V.S..D', 'mpeg4', 'MPEG-4 part 2'],
  ['V....D', 'pam', 'PAM (Portable AnyMap) image'],
  ['V....D', 'pbm', 'PBM (Portable BitMap) image'],
  ['V....D', 'pgm', 'PGM (Portable GrayMap) image'],
  ['VF...D', 'png', 'PNG (Portable Network Graphics) image'],
  ['V....D', 'ppm', 'PPM (Portable PixelMap) image'],
  ['VF...D', 'rawvideo', 'raw video'],
  ['V.....', 'wrapped_avframe', 'AVFrame to AVPacket passthrough'],
  ['A....D', 'aac', 'AAC (Advanced Audio Coding)'],
  ['A....D', 'ac3', 'ATSC A/52A (AC-3)'],
  ['A....D', 'flac', 'FLAC (Free Lossless Audio Codec)'],
  ['A....D', 'mp2', 'MP2 (MPEG audio layer 2)'],
  ['A....D', 'pcm_alaw', 'PCM A-law / G.711 A-law'],
  ['A....D', 'pcm_mulaw', 'PCM mu-law / G.711 mu-law'],
  ['A....D', 'pcm_s16le', 'PCM signed 16-bit little-endian'],
  ['A....D', 'pcm_u8', 'PCM unsigned 8-bit'],
  ['A....D', 'vorbis', 'Vorbis'],
  ['S.....', 'ass', 'ASS (Advanced SubStation Alpha) subtitle'],
  ['S.....', 'srt', 'SubRip subtitle'],
];

const DECODERS = [
  ['V....D', 'h264', 'H.264 / AVC / MPEG-4 AVC / MPEG-4 part 10'],
  ['V....D', 'mpeg4', 'MPEG-4 part 2'],
  ['V....D', 'png', 'PNG (Portable Network Graphics) image'],
  ['VF...D', 'rawvideo', 'raw video'],
  ['A....D', 'aac', 'AAC (Advanced Audio Coding)'],
  ['A....D', 'flac', 'FLAC (Free Lossless Audio Codec)'],
  ['A....D', 'mp3', 'MP3 (MPEG audio layer 3)'],
  ['A....D', 'pcm_s16le', 'PCM signed 16-bit little-endian'],
  ['S.....', 'ass', 'ASS (Advanced SubStation Alpha) subtitle'],
  ['S.....', 'srt', 'SubRip subtitle'],
];

const FILTERS = [
  ['..', 'anull', 'A->A', 'Pass the source unchanged to the output.'],
  ['..', 'aresample', 'A->A', 'Resample audio data.'],
  ['..', 'atrim', 'A->A', 'Pick one continuous section from the input, drop the rest.'],
  ['..', 'volume', 'A->A', 'Change input volume.'],
  ['..', 'aevalsrc', '|->A', 'Generate an audio signal generated by an expression.'],
  ['..', 'anullsrc', '|->A', 'Null audio source, return empty audio frames.'],
  ['..', 'sine', '|->A', 'Generate sine wave audio signal.'],
  ['T.', 'scale', 'V->V', 'Scale the input video size and/or convert the image format.'],
  ['..', 'crop', 'V->V', 'Crop the input video.'],
  ['T.', 'drawtext', 'V->V', 'Draw text on top of video frames using libfreetype library.'],
  ['..', 'format', 'V->V', 'Convert the input video to one of the specified pixel formats.'],
  ['..', 'fps', 'V->V', 'Force constant framerate.'],
  ['..', 'hflip', 'V->V', 'Horizontally flip the input video.'],
  ['..', 'null', 'V->V', 'Pass the source unchanged to the output.'],
  ['..', 'testsrc', '|->V', 'Generate test pattern.'],
  ['..', 'testsrc2', '|->V', 'Generate another test pattern.'],
  ['..', 'color', '|->V', 'Provide an uniformly colored input.'],
  ['..', 'nullsrc', '|->V', 'Null video source, return unprocessed video frames.'],
];

function banner(indent = true) {
  const p = indent ? '  ' : '';
  return [VERSION, p + BUILD, p + CONFIG, ...LIBS.map(l => p + l)].join('\n');
}
function out(s = '') { process.stdout.write(s.endsWith('\n') ? s : s + '\n'); }
function err(s = '') { process.stderr.write(s.endsWith('\n') ? s : s + '\n'); }
function exitWith(code, msg) {
  if (msg) err(msg);
  process.exit(code);
}
function formatList(rows, mode) {
  const filtered = rows.filter(r => mode === 'all' || (mode === 'mux' ? r[0][1] === 'E' : r[0][0] === 'D'));
  return filtered.map(([flags, name, desc]) => ` ${flags} ${name.padEnd(15)} ${desc}`).join('\n');
}
function printFormats(mode) {
  out(`Formats:
 D.. = Demuxing supported
 .E. = Muxing supported
 ..d = Is a device
 ---
${formatList(FORMATS, mode)}`);
}
function printEncDec(title, rows) {
  out(`${title}:
 V..... = Video
 A..... = Audio
 S..... = Subtitle
 .F.... = Frame-level multithreading
 ..S... = Slice-level multithreading
 ...X.. = Codec is experimental
 ....B. = Supports draw_horiz_band
 .....D = Supports direct rendering method 1
 ------
${rows.map(([f,n,d]) => ` ${f} ${n.padEnd(20)} ${d}`).join('\n')}`);
}
function parseDuration(v, def = 1) {
  if (!v) return def;
  if (/^\d+(\.\d+)?$/.test(v)) return Number(v);
  const m = String(v).match(/^(?:(\d+):)?(?:(\d+):)?(\d+(?:\.\d+)?)$/);
  if (!m) return def;
  const a = m[1] ? Number(m[1]) : 0, b = m[2] ? Number(m[2]) : 0, c = Number(m[3]);
  return m[2] ? a * 3600 + b * 60 + c : m[1] ? a * 60 + c : c;
}
function parseRate(v, def = 44100) {
  if (!v) return def;
  const m = String(v).match(/(?:sample_rate|s|r)=([0-9]+)/);
  return m ? Number(m[1]) : (/^[0-9]+$/.test(v) ? Number(v) : def);
}
function parseSize(s, def = [320, 240]) {
  const m = String(s || '').match(/(?:size|s)=([0-9]+)x([0-9]+)/) || String(s || '').match(/([0-9]+)x([0-9]+)/);
  return m ? [Number(m[1]), Number(m[2])] : def;
}
function parseColor(s) {
  const m = String(s || '').match(/(?:color|c)=([^:]+)/);
  const name = m ? m[1].toLowerCase() : String(s || '').split(/[=:]/)[1] || 'black';
  const table = { black:[0,0,0], white:[255,255,255], red:[255,0,0], green:[0,128,0], blue:[0,0,255], yellow:[255,255,0] };
  if (table[name]) return table[name];
  const hx = name.match(/^0x([0-9a-f]{6})$/i) || name.match(/^#?([0-9a-f]{6})$/i);
  if (hx) return [parseInt(hx[1].slice(0,2),16), parseInt(hx[1].slice(2,4),16), parseInt(hx[1].slice(4,6),16)];
  return [0,0,0];
}
function makeWav(duration, rate, channels, sineHz) {
  const samples = Math.max(1, Math.floor(duration * rate));
  const dataSize = samples * channels * 2;
  const b = Buffer.alloc(44 + dataSize);
  b.write('RIFF', 0); b.writeUInt32LE(36 + dataSize, 4); b.write('WAVEfmt ', 8);
  b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(channels, 22);
  b.writeUInt32LE(rate, 24); b.writeUInt32LE(rate * channels * 2, 28);
  b.writeUInt16LE(channels * 2, 32); b.writeUInt16LE(16, 34); b.write('data', 36);
  b.writeUInt32LE(dataSize, 40);
  for (let i = 0; i < samples; i++) {
    const val = sineHz ? Math.round(Math.sin(2 * Math.PI * sineHz * i / rate) * 32767 * 0.125) : 0;
    for (let ch = 0; ch < channels; ch++) b.writeInt16LE(val, 44 + (i * channels + ch) * 2);
  }
  return b;
}
function makePPM(w, h, source) {
  const header = Buffer.from(`P6\n${w} ${h}\n255\n`);
  const pix = Buffer.alloc(w * h * 3);
  const color = source.startsWith('color') ? parseColor(source) : null;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 3;
    if (color) { pix[i]=color[0]; pix[i+1]=color[1]; pix[i+2]=color[2]; }
    else { pix[i] = (x * 255 / Math.max(1,w-1))|0; pix[i+1] = (y * 255 / Math.max(1,h-1))|0; pix[i+2] = ((x+y) % 256); }
  }
  return Buffer.concat([header, pix]);
}
function imagePixels(w, h, source) {
  const pix = Buffer.alloc(w * h * 3);
  const color = source.startsWith('color') ? parseColor(source) : null;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 3;
    if (color) { pix[i]=color[0]; pix[i+1]=color[1]; pix[i+2]=color[2]; }
    else { pix[i] = (x * 255 / Math.max(1,w-1))|0; pix[i+1] = (y * 255 / Math.max(1,h-1))|0; pix[i+2] = ((x+y) % 256); }
  }
  return pix;
}
function pngChunk(type, data) {
  const len = Buffer.alloc(4), name = Buffer.from(type);
  len.writeUInt32BE(data.length, 0);
  const crc = crc32(Buffer.concat([name, data]));
  const c = Buffer.alloc(4); c.writeUInt32BE(crc >>> 0, 0);
  return Buffer.concat([len, name, data, c]);
}
function crc32(buf) {
  let c = ~0;
  for (const b of buf) {
    c ^= b;
    for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xedb88320 & -(c & 1));
  }
  return ~c;
}
function makePNG(w, h, source) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  const pix = imagePixels(w, h, source);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 3 + 1)] = 0;
    pix.copy(raw, y * (w * 3 + 1) + 1, y * w * 3, (y + 1) * w * 3);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]), pngChunk('IHDR', ihdr), pngChunk('IDAT', zlib.deflateSync(raw)), pngChunk('IEND', Buffer.alloc(0))]);
}
function extName(file) {
  return path.extname(file).replace('.', '').toLowerCase();
}
function parseArgs(argv) {
  const st = { inputs: [], outputs: [], fmtNext: null, y: false, n: false, hide: false, duration: null, rate: 44100, channels: 1, codec: null, frames: 1, size: [320,240], quiet: false };
  const takes = new Set(['-f','-i','-t','-to','-ss','-ar','-ac','-r','-s','-c','-codec','-vcodec','-acodec','-filter','-vf','-af','-metadata','-b','-ab','-aq','-aspect','-frames:v','-vframes','-frames','-map','-pix_fmt','-threads','-loglevel','-v','-safe','-stream_loop','-loop','-itsoffset','-probesize','-analyzeduration','-preset','-crf','-profile:v','-level','-movflags','-video_size','-framerate']);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-hide_banner') st.hide = true;
    else if (a === '-y') st.y = true;
    else if (a === '-n') st.n = true;
    else if (a === '-f') st.fmtNext = argv[++i] || '';
    else if (a === '-i') st.inputs.push({ fmt: st.fmtNext, value: argv[++i] || '' }), st.fmtNext = null;
    else if (a === '-t' || a === '-to') st.duration = parseDuration(argv[++i], 1);
    else if (a === '-ar') st.rate = parseRate(argv[++i], st.rate);
    else if (a === '-ac') st.channels = Math.max(1, Number(argv[++i] || 1));
    else if (a === '-s') st.size = parseSize(argv[++i], st.size);
    else if (a === '-frames:v' || a === '-vframes' || a === '-frames') st.frames = Math.max(1, Number(argv[++i] || 1));
    else if (a === '-c' || a === '-codec' || a === '-vcodec' || a === '-acodec') st.codec = argv[++i] || '';
    else if (a === '-loglevel' || a === '-v') { const v = argv[++i] || ''; if (v === 'quiet') st.quiet = true; }
    else if (takes.has(a) || /^-(filter|metadata|c|codec|b|frames):/.test(a)) i++;
    else if (a === '-' || /^pipe:(0|1)?$/.test(a)) {
      st.outputs.push({ fmt: st.fmtNext, value: a });
      st.fmtNext = null;
    } else if (a.startsWith('-')) {
      // Common no-argument switches not relevant to this small implementation.
      if (a.includes('no_such') || a.includes('unknown')) return { error: a.replace(/^-+/, '') };
      if (!['-stats','-nostdin','-vn','-an','-sn','-shortest','-nostats','-benchmark','-copyts','-copytb','-accurate_seek'].includes(a)) {
        if (argv[i + 1] && !argv[i + 1].startsWith('-')) i++;
      }
    } else st.outputs.push({ fmt: st.fmtNext, value: a }), st.fmtNext = null;
  }
  return st;
}
function runJob(argv) {
  const st = parseArgs(argv);
  if (st.error) {
    err(banner(true));
    err(`Unrecognized option '${st.error}'.`);
    err('Error splitting the argument list: Option not found');
    process.exit(8);
  }
  if (!st.inputs.length && !st.outputs.length) {
    err(banner(true));
    err('Universal media converter');
    err("usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...\n");
    err("Use -h to get full help or, even better, run 'man ffmpeg'");
    return;
  }
  if (!st.outputs.length) exitWith(234, 'At least one output file must be specified');
  const input = st.inputs[0] || { fmt:'', value:'' };
  const source = input.value || '';
  if (input.value && input.value !== '-' && input.fmt !== 'lavfi' && input.fmt !== 'concat' && !/^(sine|anullsrc|aevalsrc|testsrc|testsrc2|color|nullsrc)/.test(input.value) && !fs.existsSync(input.value)) {
    err(st.hide ? '' : banner(true));
    exitWith(1, `${input.value}: No such file or directory`);
  }
  for (const o of st.outputs) {
    const file = o.value;
    const fmt = (o.fmt || '').toLowerCase() || extName(file);
    if (file !== '-' && fs.existsSync(file) && !st.y) {
      if (st.n) exitWith(1, `File '${file}' already exists. Exiting.`);
      exitWith(1, `File '${file}' already exists. Overwrite? [y/N] Not overwriting - exiting`);
    }
    let data = Buffer.alloc(0);
    const duration = st.duration ?? parseDuration(source.match(/duration=([^:]+)/)?.[1], 1);
    if (fmt === 'null' || file === '/dev/null') {
      if (!st.quiet) err('Output file is empty, nothing was encoded');
      continue;
    } else if (fmt === 'hash' || fmt === 'md5') {
      const h = crypto.createHash('md5').update(source).digest('hex');
      const line = `MD5=${h}\n`;
      if (file === '-' || file === 'pipe:' || file === 'pipe:1') process.stdout.write(line); else fs.writeFileSync(file, line);
      continue;
    } else if (fmt === 'framemd5' || fmt === 'framehash' || fmt === 'framecrc') {
      const line = `#format: frame checksums\n0,          0,          0,        1,        0, ${crypto.createHash('md5').update(source).digest('hex')}\n`;
      if (file === '-' || file === 'pipe:' || file === 'pipe:1') process.stdout.write(line); else fs.writeFileSync(file, line);
      continue;
    } else if (fmt === 'wav' || fmt === 's16le' || /sine|anullsrc|aevalsrc/.test(source)) {
      const hz = Number(source.match(/frequency=([0-9.]+)/)?.[1] || source.match(/f=([0-9.]+)/)?.[1] || 0);
      data = fmt === 's16le' ? makeWav(duration, st.rate, st.channels, hz).subarray(44) : makeWav(duration, st.rate, st.channels, hz);
    } else if (fmt === 'png') {
      const [w,h] = parseSize(source, st.size);
      data = makePNG(w, h, source);
    } else if (['ppm','pnm','pam','pgm','pbm'].includes(fmt) || /testsrc|color|nullsrc/.test(source)) {
      const [w,h] = parseSize(source, st.size);
      data = makePPM(w, h, source);
    } else if (input.fmt === 'concat' && input.value && fs.existsSync(input.value)) {
      const list = fs.readFileSync(input.value, 'utf8').split(/\r?\n/);
      const bufs = [];
      for (const line of list) {
        const m = line.match(/^file\s+['"]?(.+?)['"]?$/);
        if (m) {
          const p = path.resolve(path.dirname(input.value), m[1]);
          if (fs.existsSync(p)) bufs.push(fs.readFileSync(p));
        }
      }
      data = Buffer.concat(bufs);
    } else if (st.codec === 'copy' && input.value && fs.existsSync(input.value)) {
      data = fs.readFileSync(input.value);
    } else if (input.value === '-') {
      data = fs.readFileSync(0);
    } else if (input.value && fs.existsSync(input.value)) {
      data = fs.readFileSync(input.value);
    } else {
      data = Buffer.from('');
    }
    if (file === '-' || file === 'pipe:' || file === 'pipe:1') process.stdout.write(data); else fs.writeFileSync(file, data);
    if (!st.quiet && !st.hide) err(banner(true));
    if (!st.quiet) err(`size=${String(Math.ceil(data.length / 1024)).padStart(8)}KiB time=00:00:${duration.toFixed(2).padStart(5,'0')} bitrate=N/A speed=1x`);
  }
}

function main() {
  const argv = process.argv.slice(2);
  const first = argv[0];
  if (!argv.length) {
    err(banner(true)); err('Universal media converter'); err("usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...\n"); err("Use -h to get full help or, even better, run 'man ffmpeg'"); return;
  }
  const info = new Set(['-h','--help','-help','-version','--version','-L','-license','--license','-formats','-muxers','-demuxers','-encoders','-decoders','-codecs','-filters','-pix_fmts','-sample_fmts','-layouts','-devices','-protocols','-buildconf','-bsfs','-hwaccels','-colors']);
  const key = info.has(first) ? first : (first === '-hide_banner' && info.has(argv[1]) ? argv[1] : null);
  if (key) {
    if (!['-version','--version'].includes(key) && first !== '-hide_banner') out(banner(true));
    if (key === '-version' || key === '--version') out(banner(false) + '\n\nExiting with exit code 0');
    else if (key === '-h' || key === '--help' || key === '-help') {
      const topic = argv[first === '-hide_banner' ? 2 : 1] || '';
      if (topic.includes('=')) out(`Help for ${topic}

Common options:
  -h                 show help
  -i <input>         input file
  -f <format>        force format
  -c <codec>         codec name
  -t <duration>      record or transcode duration`);
      else out(HELP + '\n\nExiting with exit code 0');
    }
    else if (key === '-L' || key === '-license' || key === '--license') out(LICENSE);
    else if (key === '-formats') printFormats('all');
    else if (key === '-muxers') printFormats('mux');
    else if (key === '-demuxers') printFormats('demux');
    else if (key === '-encoders') printEncDec('Encoders', ENCODERS);
    else if (key === '-decoders') printEncDec('Decoders', DECODERS);
    else if (key === '-codecs') { printEncDec('Codecs', DECODERS.concat(ENCODERS)); }
    else if (key === '-filters') out(`Filters:
  T.. = Timeline support
  .S. = Slice threading
  A = Audio input/output
  V = Video input/output
  N = Dynamic number and/or type of input/output
  | = Source or sink filter
  ------
${FILTERS.map(([f,n,io,d]) => ` ${f} ${n.padEnd(17)} ${io.padEnd(10)} ${d}`).join('\n')}`);
    else if (key === '-pix_fmts') out(`Pixel formats:
I.... = Supported Input  format for conversion
.O... = Supported Output format for conversion
..H.. = Hardware accelerated format
...P. = Paletted format
....B = Bitstream format
FLAGS NAME            NB_COMPONENTS BITS_PER_PIXEL BIT_DEPTHS
-----
IO... yuv420p                3             12      8-8-8
IO... yuyv422                3             16      8-8-8
IO... rgb24                  3             24      8-8-8
IO... bgr24                  3             24      8-8-8
IO... gray                   1              8      8
IO... rgba                   4             32      8-8-8-8
IO... bgra                   4             32      8-8-8-8`);
    else if (key === '-sample_fmts') out(`name   depth
u8        8
s16      16
s32      32
flt      32
dbl      64
u8p       8
s16p     16
s32p     32
fltp     32
dblp     64`);
    else if (key === '-layouts') out(`Individual channels:
NAME           DESCRIPTION
FL             front left
FR             front right
FC             front center
LFE            low frequency

Standard channel layouts:
NAME           DECOMPOSITION
mono           FC
stereo         FL+FR
2.1            FL+FR+LFE
5.1            FL+FR+FC+LFE+BL+BR`);
    else if (key === '-devices') printFormats('all');
    else if (key === '-protocols') out(`Supported file protocols:
Input:
  async
  cache
  concat
  data
  file
  pipe
Output:
  file
  pipe`);
    else if (key === '-buildconf') out(CONFIG.replace('configuration: ', '  '));
    else if (key === '-bsfs') out(`Bitstream filters:
aac_adtstoasc
av1_frame_merge
av1_frame_split
dump_extra
h264_mp4toannexb
hevc_mp4toannexb
null
vp9_superframe`);
    else if (key === '-hwaccels') out(`Hardware acceleration methods:
vdpau
cuda
vaapi
qsv
drm
opencl
vulkan`);
    else if (key === '-colors') out(`AliceBlue              #F0F8FF
Black                  #000000
Blue                   #0000FF
Green                  #008000
Red                    #FF0000
White                  #FFFFFF
Yellow                 #FFFF00`);
    return;
  }
  runJob(argv);
}
main();
