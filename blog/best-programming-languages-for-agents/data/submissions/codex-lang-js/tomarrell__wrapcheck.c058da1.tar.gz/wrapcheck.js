#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const HELP = `wrapcheck: Checks that errors returned from external packages are wrapped

Usage: wrapcheck [-flag] [package]


Flags:
  -V\tprint version and exit
  -all
    \tno effect (deprecated)
  -c int
    \tdisplay offending line with this many lines of context (default -1)
  -cpuprofile string
    \twrite CPU profile to this file
  -debug string
    \tdebug flags, any subset of "fpstv"
  -diff
    \twith -fix, don't update the files, but print a unified diff
  -fix
    \tapply all suggested fixes
  -flags
    \tprint analyzer flags in JSON
  -json
    \temit JSON output
  -memprofile string
    \twrite memory profile to this file
  -source
    \tno effect (deprecated)
  -tags string
    \tno effect (deprecated)
  -test
    \tindicates whether test files should be analyzed, too (default true)
  -trace string
    \twrite trace log to this file
  -v\tno effect (deprecated)`;

const FLAGS_JSON = [
  { Name: "V", Bool: true, Usage: "print version and exit" },
  { Name: "all", Bool: true, Usage: "no effect (deprecated)" },
  { Name: "c", Bool: false, Usage: "display offending line with this many lines of context" },
  { Name: "diff", Bool: true, Usage: "with -fix, don't update the files, but print a unified diff" },
  { Name: "flags", Bool: true, Usage: "print analyzer flags in JSON" },
  { Name: "json", Bool: true, Usage: "emit JSON output" },
  { Name: "source", Bool: true, Usage: "no effect (deprecated)" },
  { Name: "tags", Bool: false, Usage: "no effect (deprecated)" },
  { Name: "test", Bool: true, Usage: "indicates whether test files should be analyzed, too" },
  { Name: "v", Bool: true, Usage: "no effect (deprecated)" },
];

const DEFAULT_IGNORE_SIGS = [
  ".Errorf(",
  "errors.New(",
  "errors.Unwrap(",
  "errors.Join(",
  ".Wrap(",
  ".Wrapf(",
  ".WithMessage(",
  ".WithMessagef(",
  ".WithStack(",
];

function parseArgs(argv) {
  const opts = {
    json: false,
    flags: false,
    test: true,
    context: -1,
    packages: [],
    unknown: null,
    version: null,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help" || a === "-h" || a === "help") opts.help = true;
    else if (a === "-json") opts.json = true;
    else if (a === "-flags") opts.flags = true;
    else if (a === "-all" || a === "-source" || a === "-v" || a === "-fix" || a === "-diff") {}
    else if (a === "-test=false") opts.test = false;
    else if (a === "-test=true" || a === "-test") opts.test = true;
    else if (a.startsWith("-c=")) opts.context = Number(a.slice(3));
    else if (a === "-c") opts.context = Number(argv[++i] || "-1");
    else if (a.startsWith("-tags=") || a.startsWith("-debug=") || a.startsWith("-cpuprofile=") || a.startsWith("-memprofile=") || a.startsWith("-trace=")) {}
    else if (["-tags", "-debug", "-cpuprofile", "-memprofile", "-trace"].includes(a)) i++;
    else if (a === "-V") opts.version = "bad";
    else if (a.startsWith("-V=")) opts.version = a.slice(3);
    else if (a.startsWith("-")) opts.unknown = a;
    else opts.packages.push(a);
  }
  return opts;
}

function loadConfig(start) {
  const cfg = {
    ignoreSigs: null,
    extraIgnoreSigs: [],
    ignoreSigRegexps: [],
    ignorePackageGlobs: [],
    ignoreInterfaceRegexps: [],
    reportInternalErrors: false,
  };
  const files = [];
  let dir = path.resolve(start);
  for (;;) {
    files.push(path.join(dir, ".wrapcheck.yaml"));
    const p = path.dirname(dir);
    if (p === dir) break;
    dir = p;
  }
  if (process.env.HOME) files.push(path.join(process.env.HOME, ".wrapcheck.yaml"));
  const file = files.find((f) => fs.existsSync(f));
  if (!file) return cfg;
  const lines = fs.readFileSync(file, "utf8").split(/\r?\n/);
  let key = null;
  for (const raw of lines) {
    const noComment = raw.replace(/\s+#.*$/, "");
    const mKey = noComment.match(/^([A-Za-z][A-Za-z0-9]*):\s*(.*)$/);
    if (mKey) {
      key = mKey[1];
      const val = mKey[2].trim();
      if (key === "reportInternalErrors") cfg.reportInternalErrors = val === "true";
      else if (val && val !== "[]") {
        cfg[key] = val.replace(/^\[|\]$/g, "").split(",").map((s) => unquote(s.trim())).filter(Boolean);
      }
      continue;
    }
    const mItem = noComment.match(/^\s*-\s*(.*)$/);
    if (mItem && key && Array.isArray(cfg[key])) cfg[key].push(unquote(mItem[1].trim()));
  }
  return cfg;
}

function unquote(s) {
  return s.replace(/^['"]|['"]$/g, "");
}

function readModule(root) {
  let dir = path.resolve(root);
  for (;;) {
    const gomod = path.join(dir, "go.mod");
    if (fs.existsSync(gomod)) {
      const m = fs.readFileSync(gomod, "utf8").match(/^\s*module\s+(\S+)/m);
      return { root: dir, module: m ? m[1] : "" };
    }
    const p = path.dirname(dir);
    if (p === dir) return { root: path.resolve(root), module: "" };
    dir = p;
  }
}

function collectPackageDirs(patterns, cwd) {
  if (patterns.length === 0) return [];
  const dirs = new Set();
  for (const pat of patterns) {
    const abs = path.resolve(cwd, pat);
    if (pat.endsWith("/...")) {
      const base = path.resolve(cwd, pat.slice(0, -4));
      walkDirs(base, (d) => {
        if (hasGoFiles(d)) dirs.add(d);
      });
    } else if (fs.existsSync(abs) && fs.statSync(abs).isDirectory()) {
      if (hasGoFiles(abs)) dirs.add(abs);
    } else if (fs.existsSync(abs) && abs.endsWith(".go")) {
      dirs.add(path.dirname(abs));
    }
  }
  return Array.from(dirs).sort();
}

function walkDirs(dir, cb) {
  if (!fs.existsSync(dir)) return;
  const base = path.basename(dir);
  if (base === ".git" || base === "vendor" || base === "testdata" || base === "node_modules") return;
  cb(dir);
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (ent.isDirectory()) walkDirs(path.join(dir, ent.name), cb);
  }
}

function hasGoFiles(dir) {
  try {
    return fs.readdirSync(dir).some((f) => f.endsWith(".go"));
  } catch {
    return false;
  }
}

function stripComments(src) {
  return src.replace(/\/\*[\s\S]*?\*\//g, (m) => "\n".repeat((m.match(/\n/g) || []).length))
    .replace(/\/\/.*$/gm, "");
}

function parseImports(src) {
  const imports = new Map();
  const add = (alias, imp) => {
    if (alias === "_" || alias === ".") return;
    const name = alias || path.basename(imp);
    imports.set(name, imp);
  };
  for (const m of src.matchAll(/import\s*\(([\s\S]*?)\)/g)) {
    for (const line of m[1].split(/\r?\n/)) {
      const mm = line.trim().match(/^(?:(\w+|\.)\s+)?"([^"]+)"/);
      if (mm) add(mm[1], mm[2]);
    }
  }
  for (const m of src.matchAll(/import\s+(?:(\w+|\.)\s+)?"([^"]+)"/g)) add(m[1], m[2]);
  return imports;
}

function findFunctions(src) {
  const out = [];
  const re = /func\s+(?:\([^)]+\)\s*)?(\w+)\s*\([^)]*\)\s*([^{]*)\{/g;
  let m;
  while ((m = re.exec(src))) {
    const returns = m[2] || "";
    let depth = 1, i = re.lastIndex;
    for (; i < src.length && depth > 0; i++) {
      if (src[i] === "{") depth++;
      else if (src[i] === "}") depth--;
    }
    out.push({ name: m[1], returns, start: re.lastIndex, end: i - 1 });
    re.lastIndex = i;
  }
  return out;
}

function lineCol(src, idx) {
  let line = 1, last = -1;
  for (let i = 0; i < idx; i++) {
    if (src.charCodeAt(i) === 10) { line++; last = i; }
  }
  return { line, col: idx - last };
}

function lineText(src, line) {
  return src.split(/\r?\n/)[line - 1] || "";
}

function globToRe(glob) {
  const esc = glob.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
  return new RegExp("^" + esc + "$");
}

function ignoredSignature(sig, importPath, cfg) {
  const ignores = cfg.ignoreSigs ? cfg.ignoreSigs : DEFAULT_IGNORE_SIGS.concat(cfg.extraIgnoreSigs || []);
  if (ignores.some((s) => sig.includes(s))) return true;
  if ((cfg.ignoreSigRegexps || []).some((r) => {
    try { return new RegExp(r).test(sig); } catch { return false; }
  })) return true;
  if ((cfg.ignorePackageGlobs || []).some((g) => globToRe(g).test(importPath))) return true;
  return false;
}

function isInternalImport(imp, mod) {
  if (!imp) return true;
  if (mod.module && (imp === mod.module || imp.startsWith(mod.module + "/"))) return true;
  return !imp.includes(".");
}

function callInfo(expr, imports, mod, cfg) {
  let m = expr.match(/\b([A-Za-z_]\w*)\.([A-Za-z_]\w*)\s*\(/);
  if (m && imports.has(m[1])) {
    const imp = imports.get(m[1]);
    const sig = `${m[1]}.${m[2]}(`;
    if ((!isInternalImport(imp, mod) || cfg.reportInternalErrors) && !ignoredSignature(sig, imp, cfg)) return { sig, imp };
  }
  m = expr.match(/\b([A-Za-z_]\w*)\.([A-Za-z_]\w*)\s*\{[^}]*\}\.([A-Za-z_]\w*)\s*\(/);
  if (m && imports.has(m[1])) {
    const imp = imports.get(m[1]);
    const sig = `${m[1]}.${m[2]}.${m[3]}(`;
    if ((!isInternalImport(imp, mod) || cfg.reportInternalErrors) && !ignoredSignature(sig, imp, cfg)) return { sig, imp };
  }
  return null;
}

function analyzeFile(file, mod, cfg, opts) {
  const original = fs.readFileSync(file, "utf8");
  const src = stripComments(original);
  const imports = parseImports(src);
  const diags = [];
  for (const fn of findFunctions(src)) {
    if (!/\berror\b/.test(fn.returns)) continue;
    const body = src.slice(fn.start, fn.end);
    const vars = new Map();
    const lines = body.split(/\r?\n/);
    let offset = fn.start;
    for (const line of lines) {
      const assign = line.match(/\b(?:if\s+)?(?:[\w,\s_]+,\s*)?([A-Za-z_]\w*)\s*(?::=|=)\s*(.+?)(?:;|$)/);
      if (assign) {
        const ci = callInfo(assign[2], imports, mod, cfg);
        if (ci) vars.set(assign[1], ci);
      }
      let ret;
      const retRe = /\breturn\s+([^;\n}]*)/g;
      while ((ret = retRe.exec(line))) {
        const expr = ret[1].trim();
        if (!expr || expr === "nil") continue;
        if (/fmt\.Errorf\s*\(|errors\.(Join|New)\s*\(|Wrapf?\s*\(|WithMessagef?\s*\(/.test(expr)) continue;
        let ci = callInfo(expr, imports, mod, cfg);
        let name = null;
        if (!ci) {
          for (const part of expr.split(",")) {
            const v = part.trim();
            if (vars.has(v)) { ci = vars.get(v); name = v; break; }
          }
        }
        if (ci) {
          const idx = offset + ret.index;
          const pos = lineCol(src, idx);
          const message = name ?
            `error returned from external package is unwrapped: sig: ${ci.sig}` :
            `error returned from external package is unwrapped: sig: ${ci.sig}`;
          diags.push({ file, line: pos.line, col: pos.col, message, source: lineText(original, pos.line) });
        }
      }
      offset += line.length + 1;
    }
  }
  return diags;
}

function analyze(dirs, opts) {
  const all = [];
  for (const dir of dirs) {
    const mod = readModule(dir);
    const cfg = loadConfig(dir);
    for (const f of fs.readdirSync(dir).sort()) {
      if (!f.endsWith(".go")) continue;
      if (!opts.test && f.endsWith("_test.go")) continue;
      all.push(...analyzeFile(path.join(dir, f), mod, cfg, opts));
    }
  }
  return all;
}

function outputDiagnostics(diags, opts) {
  if (opts.json) {
    const obj = {};
    for (const d of diags) {
      const key = "command-line-arguments";
      if (!obj[key]) obj[key] = { wrapcheck: [] };
      obj[key].wrapcheck.push({ posn: `${d.file}:${d.line}:${d.col}`, message: d.message });
    }
    console.log(JSON.stringify(obj, null, "\t"));
    return;
  }
  for (const d of diags) {
    console.log(`${d.file}:${d.line}:${d.col}: ${d.message}`);
    if (opts.context >= 0) {
      const lines = fs.readFileSync(d.file, "utf8").split(/\r?\n/);
      const lo = Math.max(1, d.line - opts.context);
      const hi = Math.min(lines.length, d.line + opts.context);
      for (let n = lo; n <= hi; n++) console.log(`${n}\t${lines[n - 1]}`);
    }
  }
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.unknown) {
    console.error(`flag provided but not defined: ${opts.unknown}`);
    console.log(HELP);
    process.exit(2);
  }
  if (opts.help) { console.log(HELP); return; }
  if (opts.version !== null) {
    if (opts.version !== "full") {
      console.error(`wrapcheck: unsupported flag value: -V=${opts.version === "bad" ? "true" : opts.version} (use -V=full)`);
      process.exit(1);
    }
    console.error("wrapcheck: open /workspace/executable: permission denied");
    process.exit(1);
  }
  if (opts.flags) { console.log(JSON.stringify(FLAGS_JSON, null, "\t")); return; }
  if (opts.packages.length === 0) { console.log(HELP); process.exit(1); }
  const dirs = collectPackageDirs(opts.packages, process.cwd());
  const diags = analyze(dirs, opts);
  outputDiagnostics(diags, opts);
  process.exit(diags.length ? 3 : 0);
}

try {
  main();
} catch (e) {
  console.error(`wrapcheck: ${e.message}`);
  process.exit(1);
}
