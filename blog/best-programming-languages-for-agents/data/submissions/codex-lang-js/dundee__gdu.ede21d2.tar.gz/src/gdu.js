#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");
const child_process = require("child_process");

const HELP = `Pretty fast disk usage analyzer written in Go.

Gdu is intended primarily for SSD disks where it can fully utilize parallel processing.
However HDDs work as well, but the performance gain is not so huge.

Usage:
  gdu [directory_to_scan] [flags]

Flags:
      --archive-browsing              Enable browsing of zip/jar archives
      --collapse-path                 Collapse single-child directory chains
      --config-file string            Read config from file (default is $HOME/.gdu.yaml)
  -D, --db string                     Store analysis in database (*.sqlite for SQLite, *.badger for BadgerDB)
      --depth int                     Show directory structure up to specified depth in non-interactive mode (0 means the flag is ignored)
      --enable-profiling              Enable collection of profiling data and provide it on http://localhost:6060/debug/pprof/
  -E, --exclude-type strings          File types to exclude (e.g., --exclude-type yaml,json)
  -L, --follow-symlinks               Follow symlinks for files, i.e. show the size of the file to which symlink points to (symlinks to directories are not followed)
  -h, --help                          help for gdu
  -i, --ignore-dirs strings           Paths to ignore (separated by comma). Can be absolute or relative to current directory (default [/proc,/dev,/sys,/run])
  -I, --ignore-dirs-pattern strings   Path patterns to ignore (separated by comma)
  -X, --ignore-from string            Read path patterns to ignore from file
  -f, --input-file string             Import analysis from JSON file
  -l, --log-file string               Path to a logfile (default "/dev/null")
      --max-age string                Include files with mtime no older than DURATION (e.g., 7d, 2h30m, 1y2mo)
  -m, --max-cores int                 Set max cores that Gdu will use. ${os.cpus().length} cores available (default ${os.cpus().length})
      --min-age string                Include files with mtime at least DURATION old (e.g., 30d, 1w)
      --mouse                         Use mouse
  -c, --no-color                      Do not use colorized output
  -x, --no-cross                      Do not cross filesystem boundaries
      --no-delete                     Do not allow deletions
  -H, --no-hidden                     Ignore hidden directories (beginning with dot)
      --no-prefix                     Show sizes as raw numbers without any prefixes (SI or binary) in non-interactive mode
  -p, --no-progress                   Do not show progress in non-interactive mode
      --no-spawn-shell                Do not allow spawning shell
  -u, --no-unicode                    Do not use Unicode symbols (for size bar)
  -n, --non-interactive               Do not run in interactive mode
  -o, --output-file string            Export all info into file as JSON
  -r, --read-from-storage             Use existing database instead of re-scanning
      --reverse-sort                  Reverse sorting order (smallest to largest) in non-interactive mode
      --sequential                    Use sequential scanning (intended for rotating HDDs)
  -A, --show-annexed-size             Use apparent size of git-annex'ed files in case files are not present locally (real usage is zero)
  -a, --show-apparent-size            Show apparent size
  -d, --show-disks                    Show all mounted disks
  -k, --show-in-kib                   Show sizes in KiB (or kB with --si) in non-interactive mode
  -C, --show-item-count               Show number of items in directory
  -M, --show-mtime                    Show latest mtime of items in directory
  -B, --show-relative-size            Show relative size
      --si                            Show sizes with decimal SI prefixes (kB, MB, GB) instead of binary prefixes (KiB, MiB, GiB)
      --since string                  Include files with mtime >= WHEN. WHEN accepts RFC3339 timestamp (e.g., 2025-08-11T01:00:00-07:00) or date only YYYY-MM-DD (calendar-day compare; includes the whole day)
  -s, --summarize                     Show only a total in non-interactive mode
  -t, --top int                       Show only top X largest files in non-interactive mode
  -T, --type strings                  File types to include (e.g., --type yaml,json)
      --until string                  Include files with mtime <= WHEN. WHEN accepts RFC3339 timestamp or date only YYYY-MM-DD
  -v, --version                       Print version
      --write-config                  Write current configuration to file`;

const CONFIG = `style:
    footer:
        text-color: '#000000'
        background-color: '#2479D0'
        number-color: '#FFFFFF'
    selected-row:
        text-color: ""
        background-color: ""
    result-row:
        number-color: '#e67100'
        directory-color: '#3498db'
    header:
        text-color: '#000000'
        background-color: '#2479D0'
        hidden: false
sorting:
    by: ""
    order: ""
log-file: /dev/null
input-file: ""
output-file: ""
ignore-from-file: ""
ignore-dirs:
    - /proc
    - /dev
    - /sys
    - /run
ignore-dir-patterns: []
type: []
exclude-type: []
max-cores: ${os.cpus().length}
top: 0
depth: 0
sequential-scanning: false
show-apparent-size: false
show-relative-size: false
show-annexed-size: false
show-item-count: false
show-mtime: false
no-color: false
mouse: false
non-interactive: false
no-progress: false
no-unicode: false
no-cross: false
no-hidden: false
no-delete: false
no-spawn-shell: false
follow-symlinks: false
profiling: false
read-from-storage: false
db: ""
summarize: false
use-si-prefix: false
no-prefix: false
show-in-kib: false
reverse-sort: false
change-cwd: false
delete-in-background: false
delete-in-parallel: false
since: ""
until: ""
max-age: ""
min-age: ""
archive-browsing: false
collapse-path: false
`;

function defaults() {
  return {
    apparent: false, noPrefix: false, kib: false, si: false, summarize: false,
    depth: 0, top: 0, reverse: false, output: "", input: "", config: "",
    showDisks: false, writeConfig: false, noHidden: false, follow: false,
    types: [], excludeTypes: [], ignoreDirs: ["/proc", "/dev", "/sys", "/run"],
    ignorePatterns: [], since: null, until: null, minAge: null, maxAge: null,
    nonInteractive: false, paths: []
  };
}

const valueFlags = new Set(["D","i","I","X","f","l","m","o","t","T","E"]);
const boolFlags = new Set(["L","h","c","x","H","p","u","n","r","A","a","d","k","C","M","B","s","v"]);
const longValue = new Set(["config-file","db","depth","exclude-type","ignore-dirs","ignore-dirs-pattern","ignore-from","input-file","log-file","max-age","max-cores","min-age","output-file","since","top","type","until"]);
const longBool = new Set(["archive-browsing","collapse-path","enable-profiling","follow-symlinks","help","mouse","no-color","no-cross","no-delete","no-hidden","no-prefix","no-progress","no-spawn-shell","no-unicode","non-interactive","read-from-storage","reverse-sort","sequential","show-annexed-size","show-apparent-size","show-disks","show-in-kib","show-item-count","show-mtime","show-relative-size","si","summarize","version","write-config"]);

function parseArgs(argv) {
  const o = defaults();
  function setFlag(name, val) {
    switch (name) {
      case "h": case "help": o.help = true; break;
      case "v": case "version": o.version = true; break;
      case "a": case "show-apparent-size": o.apparent = true; break;
      case "n": case "non-interactive": o.nonInteractive = true; break;
      case "p": case "no-progress": break;
      case "s": case "summarize": o.summarize = true; break;
      case "d": case "show-disks": o.showDisks = true; break;
      case "k": case "show-in-kib": o.kib = true; break;
      case "H": case "no-hidden": o.noHidden = true; break;
      case "L": case "follow-symlinks": o.follow = true; break;
      case "reverse-sort": o.reverse = true; break;
      case "no-prefix": o.noPrefix = true; break;
      case "si": o.si = true; break;
      case "write-config": o.writeConfig = true; break;
      case "depth": o.depth = parseInt(val || "0", 10) || 0; break;
      case "t": case "top": o.top = parseInt(val || "0", 10) || 0; break;
      case "o": case "output-file": o.output = val; break;
      case "f": case "input-file": o.input = val; break;
      case "config-file": o.config = val; break;
      case "i": case "ignore-dirs": o.ignoreDirs = splitList(val); break;
      case "I": case "ignore-dirs-pattern": o.ignorePatterns.push(...splitList(val)); break;
      case "X": case "ignore-from": readIgnoreFile(o, val); break;
      case "T": case "type": o.types.push(...splitList(val).map(normExt)); break;
      case "E": case "exclude-type": o.excludeTypes.push(...splitList(val).map(normExt)); break;
      case "since": o.since = parseWhen(val, false); break;
      case "until": o.until = parseWhen(val, true); break;
      case "min-age": o.minAge = Date.now() - parseDuration(val); break;
      case "max-age": o.maxAge = Date.now() - parseDuration(val); break;
      default: break;
    }
  }
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === "--") { o.paths.push(...argv.slice(i + 1)); break; }
    if (a.startsWith("--")) {
      let name = a.slice(2), val = null;
      const eq = name.indexOf("=");
      if (eq >= 0) { val = name.slice(eq + 1); name = name.slice(0, eq); }
      if (longValue.has(name)) {
        if (val === null) val = argv[++i];
        setFlag(name, val || "");
      } else if (longBool.has(name)) {
        setFlag(name, true);
      } else {
        throw new Error(`unknown flag: --${name}`);
      }
    } else if (a.startsWith("-") && a !== "-") {
      const s = a.slice(1);
      for (let j = 0; j < s.length; j++) {
        const ch = s[j];
        if (valueFlags.has(ch)) {
          let val = s.slice(j + 1);
          if (!val) val = argv[++i];
          setFlag(ch, val || "");
          break;
        }
        if (!boolFlags.has(ch)) throw new Error(`unknown shorthand flag: '${ch}' in -${s}`);
        setFlag(ch, true);
      }
    } else {
      o.paths.push(a);
    }
  }
  return o;
}

function splitList(s) { return String(s || "").split(",").filter(x => x.length > 0); }
function normExt(s) { return String(s || "").replace(/^\./, "").toLowerCase(); }
function extOf(name) {
  const b = path.basename(name);
  const i = b.lastIndexOf(".");
  return i > 0 ? b.slice(i + 1).toLowerCase() : "";
}
function readIgnoreFile(o, file) {
  try { o.ignorePatterns.push(...fs.readFileSync(file, "utf8").split(/\r?\n/).filter(Boolean)); } catch (_) {}
}

function parseWhen(s, endOfDay) {
  if (!s) return null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return new Date(s + (endOfDay ? "T23:59:59.999" : "T00:00:00")).getTime();
  const t = Date.parse(s);
  return Number.isFinite(t) ? t : null;
}
function parseDuration(s) {
  let total = 0;
  const re = /(\d+)(y|mo|w|d|h|m|s)/g;
  let m;
  while ((m = re.exec(String(s || "")))) {
    const n = parseInt(m[1], 10);
    const unit = m[2];
    total += n * ({ y:365, mo:30, w:7, d:1 }[unit] || 0) * 86400000;
    if (unit === "h") total += n * 3600000;
    if (unit === "m") total += n * 60000;
    if (unit === "s") total += n * 1000;
  }
  return total;
}

function scan(root, opts, isRoot = true) {
  let lst;
  try { lst = fs.lstatSync(root); } catch (e) { throw new Error(`stat ${root}: ${e.message.split(": ").pop()}`); }
  const name = isRoot ? path.resolve(root) : path.basename(root);
  const mtime = Math.floor(lst.mtimeMs / 1000);
  const isSym = lst.isSymbolicLink();
  let st = lst;
  if (isSym && opts.follow) {
    try {
      const target = fs.statSync(root);
      if (!target.isDirectory()) st = target;
    } catch (_) {}
  }
  const isDir = st.isDirectory() && !(isSym && !opts.follow);
  const apparent = isSym && st === lst ? Buffer.byteLength(fs.readlinkSync(root)) : st.size;
  const disk = isSym && st === lst ? 0 : (st.blocks || Math.ceil(st.size / 4096) * 8) * 512;
  if (!isDir) {
    if (!fileAllowed(root, st.mtimeMs, opts)) return null;
    return { name, path: path.resolve(root), isDir: false, symlink: isSym, asize: apparent, dsize: disk, mtime, children: [] };
  }
  if (!isRoot && shouldIgnoreDir(root, opts)) return null;
  const node = { name, path: path.resolve(root), isDir: true, symlink: false, asize: apparent, dsize: disk, selfAsize: apparent, selfDsize: disk, mtime, children: [], empty: false };
  let names = [];
  try { names = fs.readdirSync(root); } catch (_) { node.error = true; }
  for (const ent of names) {
    const p = path.join(root, ent);
    if (opts.noHidden && ent.startsWith(".")) {
      try { if (fs.lstatSync(p).isDirectory()) continue; } catch (_) {}
    }
    const child = scan(p, opts, false);
    if (child) {
      node.children.push(child);
      node.asize += child.asize;
      node.dsize += child.dsize;
      if (child.mtime > node.mtime) node.mtime = child.mtime;
    }
  }
  node.empty = node.children.length === 0;
  return node;
}

function fileAllowed(p, mtimeMs, opts) {
  const e = extOf(p);
  if (opts.types.length && !opts.types.includes(e)) return false;
  if (opts.excludeTypes.includes(e)) return false;
  if (opts.since !== null && mtimeMs < opts.since) return false;
  if (opts.until !== null && mtimeMs > opts.until) return false;
  if (opts.minAge !== null && mtimeMs > opts.minAge) return false;
  if (opts.maxAge !== null && mtimeMs < opts.maxAge) return false;
  return true;
}
function shouldIgnoreDir(p, opts) {
  const abs = path.resolve(p);
  for (const d of opts.ignoreDirs) {
    if (!d) continue;
    const cmp = path.isAbsolute(d) ? path.resolve(d) : path.resolve(process.cwd(), d);
    if (abs === cmp || path.basename(abs) === d) return true;
  }
  return opts.ignorePatterns.some(pat => {
    try { return new RegExp(pat).test(abs); } catch (_) { return abs.includes(pat); }
  });
}

function sizeOf(n, opts) { return opts.apparent ? n.asize : n.dsize; }
function fmtSize(n, opts) {
  if (opts.noPrefix) return String(n).padStart(10);
  if (opts.kib) {
    const v = n / 1024;
    return `${v.toFixed(1)} ${opts.si ? "kB" : "KiB"}`.padStart(10);
  }
  const base = opts.si ? 1000 : 1024;
  const units = opts.si ? ["B","kB","MB","GB","TB","PB"] : ["B","KiB","MiB","GiB","TiB","PiB"];
  let v = n, u = 0;
  while (Math.abs(v) >= base && u < units.length - 1) { v /= base; u++; }
  const text = u === 0 ? `${Math.round(v)} B` : `${v.toFixed(1)} ${units[u]}`;
  return text.padStart(10);
}
function flag(n, imported = false) {
  if (n.symlink) return "@";
  if (!imported && n.isDir && n.empty) return "e";
  if (n.error) return "!";
  return " ";
}
function displayName(n, root, mode) {
  if (mode === "depth" || mode === "top") return n.path;
  if (n === root) return path.basename(n.path) || n.path;
  return n.isDir ? "/" + n.name : n.name;
}
function line(n, opts, root, mode, imported) {
  const f = mode === "children" || mode === "summary" ? flag(n, imported) : " ";
  return `${f}${fmtSize(sizeOf(n, opts), opts)} ${displayName(n, root, mode)}`;
}
function nameDesc(a, b) {
  if (a.name === b.name) return 0;
  return a.name < b.name ? 1 : -1;
}
function sortNodes(a, b, opts, useDisplaySize = false) {
  const d = (useDisplaySize ? sizeOf(b, opts) - sizeOf(a, opts) : b.dsize - a.dsize);
  let r = d || nameDesc(a, b);
  return opts.reverse ? -r : r;
}
function collectFiles(n, out = []) {
  if (!n.isDir) out.push(n);
  for (const c of n.children || []) collectFiles(c, out);
  return out;
}
function depthList(n, opts, maxDepth, cur = 0, out = []) {
  out.push(n);
  if (cur >= maxDepth) return out;
  const kids = [...(n.children || [])].sort((a, b) => sortNodes(a, b, opts));
  for (const c of kids) depthList(c, opts, maxDepth, cur + 1, out);
  return out;
}
function printTree(root, opts, imported = false) {
  if (!root) return;
  let nodes;
  let mode = "children";
  if (opts.summarize) nodes = [root];
  else if (opts.top > 0) {
    mode = "top";
    nodes = collectFiles(root).sort((a, b) => sortNodes(a, b, opts, true)).slice(0, opts.top);
  } else if (opts.depth > 0) {
    mode = "depth";
    nodes = depthList(root, opts, opts.depth);
  } else {
    nodes = [...(root.children || [])].sort((a, b) => sortNodes(a, b, opts));
  }
  for (const n of nodes) console.log(line(n, opts, root, mode, imported));
}

function exportJson(root, file) {
  const meta = { progname: "gdu", progver: "dev", timestamp: Math.floor(Date.now() / 1000) };
  fs.writeFileSync(file, JSON.stringify([1,2,meta,toJsonNode(root)]) + "\n");
}
function toJsonNode(n) {
  if (!n.isDir) {
    const o = { name: n.name, asize: n.asize, dsize: n.dsize, mtime: n.mtime };
    if (n.symlink) o.notreg = true;
    return o;
  }
  return [{ name: n.name, mtime: n.mtime }, ...n.children.map(toJsonNode)];
}
function importJson(file) {
  const data = JSON.parse(fs.readFileSync(file, "utf8"));
  return fromJsonNode(data[3], true, "");
}
function fromJsonNode(x, root, parent) {
  if (Array.isArray(x)) {
    const head = x[0] || {};
    const full = root ? head.name : path.join(parent, head.name);
    const n = { name: root ? path.basename(head.name) || head.name : head.name, path: full, isDir: true, symlink: false, asize: 0, dsize: 0, mtime: head.mtime || 0, children: [], empty: false };
    try { const st = fs.existsSync(full) ? fs.lstatSync(full) : null; if (st) { n.asize = st.size; n.dsize = (st.blocks || 8) * 512; } } catch (_) {}
    for (let i = 1; i < x.length; i++) {
      const c = fromJsonNode(x[i], false, full);
      n.children.push(c); n.asize += c.asize; n.dsize += c.dsize; if (c.mtime > n.mtime) n.mtime = c.mtime;
    }
    n.empty = n.children.length === 0;
    return n;
  }
  const full = path.join(parent, x.name);
  return { name: x.name, path: full, isDir: false, symlink: !!x.notreg, asize: x.asize || 0, dsize: x.dsize || 0, mtime: x.mtime || 0, children: [] };
}

function showVersion() {
  console.log("Version:\t dev");
  console.log("Built time:\t Fri Apr 17 19:59:35 UTC 2026");
  console.log("Built user:\t root");
}
function showDisks() {
  try {
    const out = child_process.execSync("df -h --output=source,size,used,avail,pcent,target", { encoding: "utf8" }).trimEnd().split(/\r?\n/);
    console.log("   Device      Size      Used      Free Used% Mount point");
    for (const row of out.slice(1)) {
      const cols = row.trim().split(/\s+/);
      if (cols.length >= 6) console.log(`${cols[0].padStart(9)} ${cols[1].padStart(9)} ${cols[2].padStart(9)} ${cols[3].padStart(9)} ${cols[4].padStart(5)} ${cols.slice(5).join(" ")}`);
    }
  } catch (_) {
    console.log("   Device      Size      Used      Free Used% Mount point");
  }
}

function main() {
  let opts;
  try { opts = parseArgs(process.argv.slice(2)); } catch (e) { console.error("Error: " + e.message); process.exit(1); }
  if (opts.help) { console.log(HELP); return; }
  if (opts.version) { showVersion(); return; }
  if (opts.writeConfig) {
    const file = opts.config || path.join(os.homedir(), ".gdu.yaml");
    try { fs.writeFileSync(file, CONFIG); } catch (_) {}
  }
  if (opts.showDisks) { showDisks(); return; }
  try {
    const root = opts.input ? importJson(opts.input) : scan(opts.paths[0] || ".", opts, true);
    if (opts.output) exportJson(root, opts.output);
    printTree(root, opts, !!opts.input);
  } catch (e) {
    console.error("Error: " + e.message);
    process.exit(1);
  }
}

main();
