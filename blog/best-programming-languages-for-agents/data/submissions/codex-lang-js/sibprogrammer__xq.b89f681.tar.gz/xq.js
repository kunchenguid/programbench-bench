#!/usr/bin/env node
'use strict';

const fs = require('fs');

const HELP = `Command-line XML and HTML beautifier and content extractor

Usage:
  xq [flags]

Flags:
  -a, --attr string      Extract an attribute value instead of node content for provided CSS query
  -c, --color            Force colorful output
      --compact          Compact JSON output (no indentation)
  -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)
  -e, --extract string   Extract a single node from XML
  -h, --help             Print this help message
  -m, --html             Use HTML formatter
  -i, --in-place         Format file in place
      --indent int       Use the given number of spaces for indentation (default 2)
  -j, --json             Output the result as JSON
      --no-color         Disable colorful output
  -n, --node             Return the node content instead of text
  -q, --query string     Extract the node(s) using CSS selector
      --tab              Use tabs for indentation
  -v, --version          Print version information
  -x, --xpath string     Extract the node(s) from XML
`;

function die(msg) {
  process.stderr.write(`Error: ${msg}\n`);
  process.exit(1);
}

function parseArgs(argv) {
  const o = { indent: 2, depth: -1, files: [], color: false };
  const need = (name, i) => {
    if (i + 1 >= argv.length) die(`flag needs an argument: ${name}`);
    return argv[i + 1];
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') o.help = true;
    else if (a === '-v' || a === '--version') o.version = true;
    else if (a === '-c' || a === '--color') o.color = true;
    else if (a === '--no-color') o.color = false;
    else if (a === '--compact') o.compact = true;
    else if (a === '-m' || a === '--html') o.html = true;
    else if (a === '-i' || a === '--in-place') o.inPlace = true;
    else if (a === '-j' || a === '--json') o.json = true;
    else if (a === '-n' || a === '--node') o.node = true;
    else if (a === '--tab') o.tab = true;
    else if (a === '--indent') {
      const val = need(a, i++);
      if (!/^-?\d+$/.test(val)) die(`invalid argument "${val}" for "--indent" flag: strconv.ParseInt: parsing "${val}": invalid syntax`);
      o.indent = parseInt(val, 10);
    } else if (a === '-d' || a === '--depth') {
      const val = need(a, i++);
      if (!/^-?\d+$/.test(val)) die(`invalid argument "${val}" for "--depth" flag: strconv.ParseInt: parsing "${val}": invalid syntax`);
      o.depth = parseInt(val, 10);
    } else if (a === '-x' || a === '--xpath') o.xpath = need(a, i++);
    else if (a === '-e' || a === '--extract') o.extract = need(a, i++);
    else if (a === '-q' || a === '--query') o.query = need(a, i++);
    else if (a === '-a' || a === '--attr') o.attr = need(a, i++);
    else if (a.startsWith('--')) die(`unknown flag: ${a}`);
    else if (a.startsWith('-') && a.length > 1) {
      const chars = a.slice(1).split('');
      for (const c of chars) {
        if (c === 'h') o.help = true;
        else if (c === 'v') o.version = true;
        else if (c === 'c') o.color = true;
        else if (c === 'm') o.html = true;
        else if (c === 'i') o.inPlace = true;
        else if (c === 'j') o.json = true;
        else if (c === 'n') o.node = true;
        else die(`unknown shorthand flag: '${c}' in ${a}`);
      }
    } else o.files.push(a);
  }
  return o;
}

function decode(s) {
  return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&apos;/g, "'");
}

function escText(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function escAttr(s) {
  return escText(s).replace(/"/g, '&quot;');
}

function attrsToString(attrs) {
  return Object.keys(attrs).map(k => ` ${k}="${escAttr(attrs[k])}"`).join('');
}

function parseAttrs(s) {
  const attrs = {};
  const re = /([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>/]+)))?/g;
  let m;
  while ((m = re.exec(s))) attrs[m[1]] = decode(m[2] ?? m[3] ?? m[4] ?? '');
  return attrs;
}

const VOID_HTML = new Set(['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']);

function parseDoc(input, html = false) {
  const root = { type: 'document', children: [], parent: null };
  const stack = [root];
  const token = /<!--[\s\S]*?-->|<!\[CDATA\[[\s\S]*?\]\]>|<\?[\s\S]*?\?>|<![^>]*>|<\/?[A-Za-z_:\-][^>]*>/g;
  let last = 0, m;
  while ((m = token.exec(input))) {
    addText(input.slice(last, m.index));
    const t = m[0];
    if (t.startsWith('<!--')) {
      cur().children.push({ type: 'comment', text: t.slice(4, -3), parent: cur() });
    } else if (t.startsWith('<![CDATA[')) {
      cur().children.push({ type: 'text', text: t.slice(9, -3), parent: cur() });
    } else if (t.startsWith('<?')) {
      cur().children.push({ type: 'pi', raw: t, parent: cur() });
    } else if (t.startsWith('</')) {
      const name = t.slice(2, -1).trim().toLowerCase();
      for (let i = stack.length - 1; i > 0; i--) {
        if (stack[i].name.toLowerCase() === name) { stack.length = i + 1; break; }
      }
      if (stack.length > 1 && stack[stack.length - 1].name.toLowerCase() === name) stack.pop();
    } else if (t.startsWith('<!')) {
      cur().children.push({ type: 'decl', raw: t, parent: cur() });
    } else {
      const selfClose = /\/\s*>$/.test(t);
      const body = t.slice(1, t.length - (selfClose ? 2 : 1)).trim();
      const sp = body.search(/\s/);
      const name = sp < 0 ? body : body.slice(0, sp);
      const attrPart = sp < 0 ? '' : body.slice(sp + 1);
      const node = { type: 'element', name, attrs: parseAttrs(attrPart), children: [], parent: cur(), selfClosing: selfClose };
      cur().children.push(node);
      if (!selfClose && !(html && VOID_HTML.has(name.toLowerCase()))) stack.push(node);
    }
    last = token.lastIndex;
  }
  addText(input.slice(last));
  return root;

  function cur() { return stack[stack.length - 1]; }
  function addText(s) {
    if (!s) return;
    if (/\S/.test(s)) cur().children.push({ type: 'text', text: decode(s), parent: cur() });
  }
}

function cleanText(s) {
  return s.replace(/\r/g, '').split('\n').map(x => x.trim()).filter(Boolean).join('\n').replace(/[ \t]+/g, ' ').trim();
}

function textContent(n) {
  if (n.type === 'text') return cleanText(n.text);
  if (!n.children) return '';
  const vals = [];
  for (const c of n.children) {
    if (c.type === 'comment' || c.type === 'pi' || c.type === 'decl') continue;
    const v = textContent(c);
    if (v) vals.push(v);
  }
  return vals.join('\n');
}

function selectedText(n) {
  return textContent(n).replace(/\n+/g, ' ');
}

function renderNode(n, opts = {}) {
  if (n.type === 'document') return n.children.map(c => renderNode(c, opts)).filter(Boolean).join('\n');
  if (n.type === 'text') return cleanText(n.text);
  if (n.type === 'comment') return `<!--${n.text}-->`;
  if (n.type === 'pi' || n.type === 'decl') return n.raw;
  const a = attrsToString(n.attrs);
  if (n.children.length === 0) return n.selfClosing ? `<${n.name}${a}/>` : `<${n.name}${a}></${n.name}>`;
  const inner = n.children.map(c => renderNode(c, opts)).filter(Boolean).join('');
  return `<${n.name}${a}>${inner}</${n.name}>`;
}

function formatDoc(doc, opts) {
  const lines = [];
  const unit = opts.tab ? '\t' : ' '.repeat(opts.indent);
  for (const c of doc.children) fmt(c, 0);
  let out = lines.join('\n');
  if (opts.color) out = colorize(out);
  return out + (out ? '\n' : '');

  function ind(d) { return unit.repeat(d); }
  function fmt(n, d) {
    if (n.type === 'text') {
      const t = cleanText(n.text);
      if (t) lines.push(ind(d) + escText(t));
      return;
    }
    if (n.type === 'comment') { lines.push(ind(d) + `<!--${n.text}-->`); return; }
    if (n.type === 'pi' || n.type === 'decl') { lines.push(ind(d) + n.raw); return; }
    if (n.type !== 'element') return;
    const a = attrsToString(n.attrs);
    const meaningful = n.children.filter(c => c.type !== 'text' || cleanText(c.text));
    if (meaningful.length === 0) {
      if (opts.html && VOID_HTML.has(n.name.toLowerCase())) lines.push(ind(d) + `<${n.name}${a}/>`);
      else if (n.selfClosing) lines.push(ind(d) + `<${n.name}${a}/>`);
      else lines.push(ind(d) + `<${n.name}${a}></${n.name}>`);
      return;
    }
    if (meaningful.length === 1 && meaningful[0].type === 'text') {
      lines.push(ind(d) + `<${n.name}${a}>${escText(cleanText(meaningful[0].text))}</${n.name}>`);
      return;
    }
    if (opts.html && VOID_HTML.has(n.name.toLowerCase())) {
      lines.push(ind(d) + `<${n.name}${a}/>`);
      return;
    }
    const hasText = meaningful.some(c => c.type === 'text');
    const hasElem = meaningful.some(c => c.type === 'element');
    if (hasText && hasElem) {
      const start = lines.length;
      lines.push(ind(d) + `<${n.name}${a}>`);
      for (const c of meaningful) fmt(c, d + 1);
      lines.push(ind(d) + `</${n.name}>`);
      compactMixed(lines, start, ind(d + 1));
    } else {
      lines.push(ind(d) + `<${n.name}${a}>`);
      for (const c of meaningful) fmt(c, d + 1);
      lines.push(ind(d) + `</${n.name}>`);
    }
  }
}

function compactMixed(lines, start, childIndent) {
  const chunk = lines.slice(start);
  if (chunk.length < 4) return;
  const open = chunk[0], close = chunk[chunk.length - 1].trim();
  const middle = chunk.slice(1, -1);
  if (!middle.some(l => l.trim().startsWith('<'))) return;
  if (middle[0] && !middle[0].trim().startsWith('<')) {
    chunk[0] = `${open}${middle[0].trim()}`;
    middle.shift();
  }
  if (middle.length && !middle[middle.length - 1].trim().startsWith('<')) {
    const tail = middle.pop().trim();
    if (middle.length) middle[middle.length - 1] = `${middle[middle.length - 1]} ${tail}${close}`;
    else chunk[0] = `${chunk[0]}${tail}${close}`;
    lines.splice(start, lines.length - start, chunk[0], ...middle);
  } else {
    lines.splice(start, lines.length - start, chunk[0], ...middle, lines[start + chunk.length - 1]);
  }
}

function colorize(s) {
  return s
    .replace(/(<!--)([\s\S]*?)(-->)/g, '\x1b[94m$1\x1b[0m\x1b[94m$2\x1b[0m\x1b[94m$3\x1b[0m')
    .replace(/(<\/?[\w:.-]+)/g, '\x1b[33m$1\x1b[0m')
    .replace(/(\/?>)/g, '\x1b[33m$1\x1b[0m')
    .replace(/(\?>)/g, '\x1b[33m$1\x1b[0m')
    .replace(/(\s[\w:.-]+)=("[^"]*")/g, '$1\x1b[32m=$2\x1b[0m');
}

function elements(n) {
  const out = [];
  walk(n);
  return out;
  function walk(x) {
    if (x.type === 'element') out.push(x);
    if (x.children) x.children.forEach(walk);
  }
}

function elementChildren(n) {
  return (n.children || []).filter(c => c.type === 'element');
}

function xpath(doc, expr) {
  expr = expr.trim();
  const attrOnly = expr.match(/^(.*)\/@([\w:.-]+)$/);
  const attr = attrOnly && attrOnly[2];
  if (attrOnly) expr = attrOnly[1];
  let nodes = [];
  if (expr.startsWith('//')) {
    const name = expr.slice(2);
    nodes = elements(doc).filter(e => name === '*' || e.name === name);
  } else if (expr.startsWith('/')) {
    let cur = [doc];
    for (const part of expr.split('/').filter(Boolean)) {
      cur = cur.flatMap(n => elementChildren(n).filter(e => part === '*' || e.name === part));
    }
    nodes = cur;
  } else {
    nodes = elements(doc).filter(e => e.name === expr);
  }
  if (attr) return nodes.map(n => ({ type: 'value', value: n.attrs[attr] })).filter(v => v.value !== undefined);
  return nodes;
}

function parseSelector(q) {
  return q.replace(/\s*>\s*/g, ' > ').trim().split(/\s+/).filter(Boolean);
}

function matchSimple(e, s) {
  let tag = s.match(/^[\w:-]+|\*/);
  if (tag && tag[0] !== '*' && e.name.toLowerCase() !== tag[0].toLowerCase()) return false;
  const id = s.match(/#([\w:-]+)/);
  if (id && e.attrs.id !== id[1]) return false;
  const classes = [...s.matchAll(/\.([\w:-]+)/g)].map(m => m[1]);
  const have = (e.attrs.class || '').split(/\s+/);
  if (classes.some(c => !have.includes(c))) return false;
  for (const m of s.matchAll(/\[([\w:-]+)(?:=(?:"([^"]*)"|'([^']*)'|([^\]]+)))?\]/g)) {
    const val = m[2] ?? m[3] ?? m[4];
    if (!(m[1] in e.attrs)) return false;
    if (val !== undefined && e.attrs[m[1]] !== val) return false;
  }
  return true;
}

function cssQuery(doc, q) {
  const toks = parseSelector(q);
  let current = [doc], combinator = ' ';
  for (const tok of toks) {
    if (tok === '>') { combinator = '>'; continue; }
    const next = [];
    for (const base of current) {
      const cand = combinator === '>' ? elementChildren(base) : elements(base).filter(e => e !== base);
      next.push(...cand.filter(e => matchSimple(e, tok)));
    }
    current = [...new Set(next)];
    combinator = ' ';
  }
  return current;
}

function toJsonElement(e, maxDepth, depth = 0) {
  if (maxDepth >= 0 && depth >= maxDepth) return textContent(e);
  const attrs = Object.keys(e.attrs || {}).sort();
  const kids = elementChildren(e);
  const directText = (e.children || []).filter(c => c.type === 'text').map(c => cleanText(c.text)).filter(Boolean);
  if (!attrs.length && !kids.length) return directText.length ? directText.join('\n') : {};
  const obj = {};
  if (directText.length && attrs.length && !kids.length) obj['#text'] = directText.join('\n');
  for (const k of attrs) obj[`@${k}`] = e.attrs[k];
  if (directText.length && (!attrs.length || kids.length)) obj['#text'] = directText.join('\n');
  const groups = {};
  for (const k of kids) (groups[k.name] ||= []).push(k);
  for (const name of Object.keys(groups).sort()) {
    const arr = groups[name].map(ch => toJsonElement(ch, maxDepth, depth + 1));
    obj[name] = arr.length === 1 ? arr[0] : arr;
  }
  return obj;
}

function jsonDoc(doc, opts) {
  const obj = {};
  for (const e of elementChildren(doc)) obj[e.name] = toJsonElement(e, opts.depth, 0);
  if (opts.compact) return JSON.stringify(obj).replace(/:/g, ': ').replace(/,/g, ',') + '\n';
  return stringifyPretty(obj, 0) + '\n';
}

function stringifyPretty(v, depth) {
  const sp = '  '.repeat(depth), sp1 = '  '.repeat(depth + 1);
  if (Array.isArray(v)) {
    if (!v.length) return '[]';
    return '[\n' + v.map(x => sp1 + stringifyPretty(x, depth + 1)).join(',\n') + '\n' + sp + ']';
  }
  if (v && typeof v === 'object') {
    const keys = Object.keys(v);
    if (!keys.length) return '{\n\n' + sp + '}';
    return '{\n' + keys.map(k => sp1 + JSON.stringify(k) + ': ' + stringifyPretty(v[k], depth + 1)).join(',\n') + '\n' + sp + '}';
  }
  return JSON.stringify(v);
}

function outputSelection(nodes, opts) {
  const vals = [];
  for (const n of nodes) {
    if (n.type === 'value') vals.push(n.value);
    else if (opts.attr) {
      if (n.attrs[opts.attr] !== undefined) vals.push(n.attrs[opts.attr]);
    } else if (opts.node) vals.push(formatDoc({ type: 'document', children: [n] }, { ...opts, color: false }).trimEnd());
    else vals.push(selectedText(n));
  }
  return vals.filter(v => v !== undefined && v !== '').join('\n') + (vals.length ? '\n' : '');
}

function readAllStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch { return ''; }
}

function processInput(input, opts) {
  const doc = parseDoc(input, opts.html);
  if (opts.json) return jsonDoc(doc, opts);
  if (opts.xpath || opts.extract) {
    let nodes = xpath(doc, opts.xpath || opts.extract);
    if (opts.extract) nodes = nodes.slice(0, 1);
    return outputSelection(nodes, opts);
  }
  if (opts.query) return outputSelection(cssQuery(doc, opts.query), opts);
  return formatDoc(doc, opts);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  let stdinHasData = false;
  if (!opts.files.length) {
    try {
      const st = fs.fstatSync(0);
      stdinHasData = st.isFIFO() || st.isFile();
    } catch {}
  }
  if (opts.help) { process.stdout.write(HELP); return; }
  if (opts.version) { process.stdout.write('xq version 1.4.0\n'); return; }
  if (!opts.files.length && !stdinHasData) { process.stdout.write(HELP); return; }
  const files = opts.files.length ? opts.files : [null];
  let all = '';
  for (const f of files) {
    let input;
    if (f === null) input = readAllStdin();
    else {
      try { input = fs.readFileSync(f, 'utf8'); }
      catch { die(`open ${f}: no such file or directory`); }
    }
    const out = processInput(input, opts);
    if (opts.inPlace && f) fs.writeFileSync(f, out);
    else all += out;
  }
  process.stdout.write(all);
}

main();
