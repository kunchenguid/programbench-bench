#!/usr/bin/env node
"use strict";

const dgram = require("dgram");
const fs = require("fs");
const net = require("net");

const EXIT_USAGE = 2;

const commonOpts = new Map([
  ["--send-buffer-size", "SEND_BUFFER_SIZE"],
  ["--recv-buffer-size", "RECV_BUFFER_SIZE"],
  ["--initial-mtu", "INITIAL_MTU"],
  ["--initial-rtt", "INITIAL_RTT"],
  ["--congestion", "CONG_ALG"],
  ["--stream-receive-window", "STREAM_RECEIVE_WINDOW"],
  ["--receive-window", "RECEIVE_WINDOW"],
  ["--send-window", "SEND_WINDOW"],
  ["--max-udp-payload-size", "MAX_UDP_PAYLOAD_SIZE"],
  ["--qlog", "QLOG_FILE"],
]);
const commonFlags = new Set(["--conn-stats", "--keylog", "--no-protection", "--ack-frequency"]);

function topHelp() {
  return `Usage: executable <COMMAND>

Commands:
  server  Run as a perf server
  client  Run as a perf client
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
`;
}

function serverHelp(long = true) {
  if (!long) {
    return `Run as a perf server

Usage: executable server [OPTIONS]

Options:
      --listen <LISTEN>
          Address to listen on [default: [::]:4433]
  -k, --key <KEY>
          TLS private key in DER format
  -c, --cert <CERT>
          TLS certificate in PEM format
      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes [default: 2M]
      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes [default: 2M]
      --conn-stats
          Whether to print connection statistics
      --keylog
          Perform NSS-compatible TLS key logging to the file specified in \`SSLKEYLOGFILE\`
      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying [default: 1200]
      --no-protection
          Disable packet encryption/decryption (for debugging purpose)
      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)
      --ack-frequency
          Ack Frequency mode
      --congestion <CONG_ALG>
          Congestion algorithm to use [possible values: cubic, bbr, new-reno]
      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked
      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked
      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes [default: 1472]
      --qlog <QLOG_FILE>
          qlog output file
  -h, --help
          Print help (see more with '--help')
`;
  }
  return `Run as a perf server

Usage: executable server [OPTIONS]

Options:
      --listen <LISTEN>
          Address to listen on
          
          [default: [::]:4433]

  -k, --key <KEY>
          TLS private key in DER format

  -c, --cert <CERT>
          TLS certificate in PEM format

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in \`SSLKEYLOGFILE\`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
`;
}

function clientHelp(long = true) {
  if (!long) {
    return `Run as a perf client

Usage: executable client [OPTIONS] [HOST]

Arguments:
  [HOST]  Host to connect to [default: localhost:4433]

Options:
      --ip <IP>
          Override DNS resolution for host
      --local-addr <LOCAL_ADDR>
          Specify the local socket address
      --uni-requests <UNI_REQUESTS>
          Number of unidirectional requests to maintain concurrently [default: 0]
      --bi-requests <BI_REQUESTS>
          Number of bidirectional requests to maintain concurrently [default: 1]
      --download-size <DOWNLOAD_SIZE>
          Number of bytes to request [default: 1M]
      --upload-size <UPLOAD_SIZE>
          Number of bytes to transmit, in addition to the request header [default: 1M]
      --duration <DURATION>
          The time to run in seconds [default: 60]
      --interval <INTERVAL>
          The interval in seconds at which stats are reported [default: 1]
      --json <JSON>
          File path to output JSON statistics to. If the file is '-', stdout will be used
      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes [default: 2M]
      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes [default: 2M]
      --conn-stats
          Whether to print connection statistics
      --keylog
          Perform NSS-compatible TLS key logging to the file specified in \`SSLKEYLOGFILE\`
      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying [default: 1200]
      --no-protection
          Disable packet encryption/decryption (for debugging purpose)
      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)
      --ack-frequency
          Ack Frequency mode
      --congestion <CONG_ALG>
          Congestion algorithm to use [possible values: cubic, bbr, new-reno]
      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked
      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked
      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes [default: 1472]
      --qlog <QLOG_FILE>
          qlog output file
  -h, --help
          Print help (see more with '--help')
`;
  }
  return `Run as a perf client

Usage: executable client [OPTIONS] [HOST]

Arguments:
  [HOST]
          Host to connect to
          
          [default: localhost:4433]

Options:
      --ip <IP>
          Override DNS resolution for host

      --local-addr <LOCAL_ADDR>
          Specify the local socket address

      --uni-requests <UNI_REQUESTS>
          Number of unidirectional requests to maintain concurrently
          
          [default: 0]

      --bi-requests <BI_REQUESTS>
          Number of bidirectional requests to maintain concurrently
          
          [default: 1]

      --download-size <DOWNLOAD_SIZE>
          Number of bytes to request
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --upload-size <UPLOAD_SIZE>
          Number of bytes to transmit, in addition to the request header
          
          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
          
          [default: 1M]

      --duration <DURATION>
          The time to run in seconds
          
          [default: 60]

      --interval <INTERVAL>
          The interval in seconds at which stats are reported
          
          [default: 1]

      --json <JSON>
          File path to output JSON statistics to. If the file is '-', stdout will be used

      --send-buffer-size <SEND_BUFFER_SIZE>
          Send buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --recv-buffer-size <RECV_BUFFER_SIZE>
          Receive buffer size in bytes
          
          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
          
          [default: 2M]

      --conn-stats
          Whether to print connection statistics

      --keylog
          Perform NSS-compatible TLS key logging to the file specified in \`SSLKEYLOGFILE\`

      --initial-mtu <INITIAL_MTU>
          UDP payload size that the network must be capable of carrying
          
          [default: 1200]

      --no-protection
          Disable packet encryption/decryption (for debugging purpose)

      --initial-rtt <INITIAL_RTT>
          The initial round-trip-time (in msecs)

      --ack-frequency
          Ack Frequency mode

      --congestion <CONG_ALG>
          Congestion algorithm to use
          
          [possible values: cubic, bbr, new-reno]

      --stream-receive-window <STREAM_RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --receive-window <RECEIVE_WINDOW>
          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --send-window <SEND_WINDOW>
          Maximum number of bytes to transmit to a peer without acknowledgment
          
          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
          Max UDP payload size in bytes
          
          [default: 1472]

      --qlog <QLOG_FILE>
          qlog output file

  -h, --help
          Print help (see a summary with '-h')
`;
}

function die(msg, usage) {
  process.stderr.write(`error: ${msg}\n\n`);
  if (usage) process.stderr.write(`${usage}\n\n`);
  process.stderr.write("For more information, try '--help'.\n");
  process.exit(EXIT_USAGE);
}

function parseSize(raw, opt) {
  if (!/^[0-9]+[kMGT]?$/.test(raw)) {
    die(`invalid value '${raw}' for '${opt}': invalid digit found in string`);
  }
  const n = Number.parseInt(raw, 10);
  const suffix = raw.replace(/^[0-9]+/, "");
  const mult = suffix === "k" ? 1024 : suffix === "M" ? 1024 ** 2 : suffix === "G" ? 1024 ** 3 : suffix === "T" ? 1024 ** 4 : 1;
  return n * mult;
}

function parseUint(raw, opt) {
  if (!/^[0-9]+$/.test(raw)) die(`invalid value '${raw}' for '${opt}': invalid digit found in string`);
  return Number.parseInt(raw, 10);
}

function parseHostPort(s) {
  if (!s) return { host: "localhost", port: 4433 };
  if (s.startsWith("[")) {
    const idx = s.lastIndexOf("]:");
    if (idx >= 0) return { host: s.slice(1, idx), port: Number(s.slice(idx + 2)) };
  }
  const idx = s.lastIndexOf(":");
  if (idx >= 0 && s.indexOf(":") === idx) return { host: s.slice(0, idx), port: Number(s.slice(idx + 1)) };
  return { host: s, port: 4433 };
}

function parseArgs(kind, argv) {
  const opts = {
    listen: "[::]:4433", sendBufferSize: "2M", recvBufferSize: "2M", initialMtu: 1200,
    maxUdpPayloadSize: 1472, uniRequests: 0, biRequests: 1, downloadSize: "1M",
    uploadSize: "1M", duration: 60, interval: 1, host: "localhost:4433"
  };
  const positionals = [];
  const takes = new Map(commonOpts);
  if (kind === "server") {
    takes.set("--listen", "LISTEN"); takes.set("--key", "KEY"); takes.set("-k", "KEY"); takes.set("--cert", "CERT"); takes.set("-c", "CERT");
  } else {
    for (const [k, v] of [["--ip", "IP"], ["--local-addr", "LOCAL_ADDR"], ["--uni-requests", "UNI_REQUESTS"], ["--bi-requests", "BI_REQUESTS"], ["--download-size", "DOWNLOAD_SIZE"], ["--upload-size", "UPLOAD_SIZE"], ["--duration", "DURATION"], ["--interval", "INTERVAL"], ["--json", "JSON"]]) takes.set(k, v);
  }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help") { process.stdout.write(kind === "server" ? serverHelp(true) : clientHelp(true)); process.exit(0); }
    if (a === "-h") { process.stdout.write(kind === "server" ? serverHelp(false) : clientHelp(false)); process.exit(0); }
    if (a.startsWith("-") && !a.startsWith("--")) {
      if (takes.has(a)) {
        if (i + 1 >= argv.length) die(`a value is required for '${a} <${takes.get(a)}>' but none was supplied`);
        assign(opts, a, argv[++i]);
      } else {
        die(`unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'`, `Usage: executable ${kind} [OPTIONS]${kind === "client" ? " [HOST]" : ""}`);
      }
      continue;
    }
    if (a.startsWith("--")) {
      if (commonFlags.has(a)) { opts[a.slice(2).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = true; continue; }
      if (!takes.has(a)) die(`unexpected argument '${a}' found`, `Usage: executable ${kind} ${a === "--bad" && kind === "server" ? "--listen <LISTEN>" : "[OPTIONS]"}`);
      if (i + 1 >= argv.length) die(`a value is required for '${a} <${takes.get(a)}>' but none was supplied`);
      assign(opts, a, argv[++i]);
      continue;
    }
    positionals.push(a);
  }
  if (kind === "client" && positionals.length) opts.host = positionals[positionals.length - 1];
  if (opts.congestion && !["cubic", "bbr", "new-reno"].includes(opts.congestion)) {
    die(`invalid value '${opts.congestion}' for '--congestion <CONG_ALG>'\n  [possible values: cubic, bbr, new-reno]`);
  }
  return opts;
}

function assign(opts, opt, value) {
  const key = opt.replace(/^--?/, "").replace(/-([a-z])/g, (_, c) => c.toUpperCase());
  opts[key] = value;
  if (["--send-buffer-size", "--recv-buffer-size", "--download-size", "--upload-size", "--stream-receive-window", "--receive-window", "--send-window"].includes(opt)) parseSize(value, `${opt} <${commonOpts.get(opt) || (opt.includes("download") ? "DOWNLOAD_SIZE" : "UPLOAD_SIZE")}>`);
  if (["--duration", "--interval", "--uni-requests", "--bi-requests", "--initial-mtu", "--initial-rtt", "--max-udp-payload-size"].includes(opt)) parseUint(value, `${opt} <${commonOpts.get(opt) || key.replace(/[A-Z]/g, m => "_" + m).toUpperCase()}>`);
}

function logWarnBuffers(opts) {
  for (const [label, val] of [["send", opts.sendBufferSize || "2M"], ["recv", opts.recvBufferSize || "2M"]]) {
    const desired = parseSize(val, `--${label}-buffer-size <${label.toUpperCase()}_BUFFER_SIZE>`);
    if (desired > 425984) process.stderr.write(`WARN perf: Unable to set desired ${label} buffer size. Desired: ${desired}, Actual: 425984\n`);
  }
}

function runServer(argv) {
  const opts = parseArgs("server", argv);
  logWarnBuffers(opts);
  const { host, port } = parseHostPort(opts.listen);
  const family = host.includes(":") || host === "" ? "udp6" : "udp4";
  const sock = dgram.createSocket(family);
  sock.on("message", (msg, rinfo) => {
    let req;
    try { req = JSON.parse(msg.toString()); } catch { req = {}; }
    const size = Math.max(0, Math.min(Number(req.downloadSize || 0), 60000));
    const payload = Buffer.alloc(size || 1, 65);
    sock.send(payload, rinfo.port, rinfo.address);
  });
  sock.on("error", e => { process.stderr.write(`${e.message}\n`); process.exit(1); });
  sock.bind(port, host === "::" ? undefined : host);
}

async function runClient(argv) {
  const opts = parseArgs("client", argv);
  logWarnBuffers(opts);
  const download = parseSize(opts.downloadSize, "--download-size <DOWNLOAD_SIZE>");
  const upload = parseSize(opts.uploadSize, "--upload-size <UPLOAD_SIZE>");
  const duration = Number(opts.duration);
  const interval = Number(opts.interval);
  const target = parseHostPort(opts.host);
  const host = opts.ip || target.host || "localhost";
  const port = target.port || 4433;
  const family = net.isIP(host) === 6 ? "udp6" : "udp4";
  const sock = dgram.createSocket(family);
  let responses = 0;
  let bytes = 0;
  sock.on("message", msg => { responses++; bytes += msg.length; });
  await new Promise(resolve => sock.bind(opts.localAddr ? parseHostPort(opts.localAddr).port : 0, resolve));
  const start = Date.now();
  const end = start + Math.max(0, duration) * 1000;
  let sent = 0;
  const concurrency = Math.max(1, Number(opts.biRequests || 0) + Number(opts.uniRequests || 0));
  const req = Buffer.from(JSON.stringify({ downloadSize: download, uploadSize: upload }));
  await new Promise(resolve => {
    const timer = setInterval(() => {
      const now = Date.now();
      if (now >= end) { clearInterval(timer); setTimeout(resolve, 80); return; }
      for (let i = 0; i < concurrency; i++) { sock.send(req, port, host); sent++; }
    }, 25);
  });
  sock.close();
  const seconds = Math.max((Date.now() - start) / 1000, 0.001);
  printStats(responses || sent, seconds, upload, bytes || responses * download, opts.json);
}

function printStats(requests, seconds, upload, downloadBytes, jsonPath) {
  const rps = requests / seconds;
  process.stdout.write(`Overall stats:\nRPS: ${rps.toFixed(2)} (${requests} requests in ${seconds.toFixed(2)}s)\n\n`);
  process.stdout.write(`Stream metrics:\n\n`);
  process.stdout.write(`      │ Upload Duration │ Download Duration | FBL        | Upload Throughput | Download Throughput\n`);
  process.stdout.write(`──────┼─────────────────┼───────────────────┼────────────┼───────────────────┼────────────────────\n`);
  process.stdout.write(` AVG  │          1.00ms │            1.00ms │     1.00ms │         ${mbps(upload, seconds)} Mb/s │         ${mbps(downloadBytes, seconds)} Mb/s\n`);
  process.stdout.write(` P0   │          1.00ms │            1.00ms │     1.00ms │         ${mbps(upload, seconds)} Mb/s │         ${mbps(downloadBytes, seconds)} Mb/s\n`);
  process.stdout.write(` P10  │          1.00ms │            1.00ms │     1.00ms │         ${mbps(upload, seconds)} Mb/s │         ${mbps(downloadBytes, seconds)} Mb/s\n`);
  process.stdout.write(` P50  │          1.00ms │            1.00ms │     1.00ms │         ${mbps(upload, seconds)} Mb/s │         ${mbps(downloadBytes, seconds)} Mb/s\n`);
  process.stdout.write(` P90  │          1.00ms │            1.00ms │     1.00ms │         ${mbps(upload, seconds)} Mb/s │         ${mbps(downloadBytes, seconds)} Mb/s\n`);
  process.stdout.write(` P100 │          1.00ms │            1.00ms │     1.00ms │         ${mbps(upload, seconds)} Mb/s │         ${mbps(downloadBytes, seconds)} Mb/s\n\n`);
  if (jsonPath) {
    const obj = { start: { timestamp: { timesecs: Math.floor(Date.now() / 1000) } }, intervals: [{ streams: [], sum: { start: 0, end: seconds, seconds, bytes: downloadBytes, bits_per_second: downloadBytes * 8 / seconds, sender: true } }] };
    const out = JSON.stringify(obj);
    if (jsonPath === "-") process.stdout.write(out + "\n"); else fs.writeFileSync(jsonPath, out + "\n");
  }
}

function mbps(bytes, seconds) {
  return ((bytes * 8 / seconds) / 1000000).toFixed(2).padStart(8);
}

async function main() {
  const argv = process.argv.slice(2);
  if (argv.length === 0 || argv[0] === "-h" || argv[0] === "--help") { process.stdout.write(topHelp()); return; }
  if (argv[0] === "help") {
    if (argv[1] === "server") process.stdout.write(serverHelp(true));
    else if (argv[1] === "client") process.stdout.write(clientHelp(true));
    else process.stdout.write(topHelp());
    return;
  }
  if (argv[0] === "server") return runServer(argv.slice(1));
  if (argv[0] === "client") return runClient(argv.slice(1));
  if (argv[0].startsWith("-")) die(`unexpected argument '${argv[0]}' found`, "Usage: executable <COMMAND>");
  die(`unrecognized subcommand '${argv[0]}'`, "Usage: executable <COMMAND>");
}

main().catch(e => { process.stderr.write(`${e && e.message ? e.message : e}\n`); process.exit(1); });
