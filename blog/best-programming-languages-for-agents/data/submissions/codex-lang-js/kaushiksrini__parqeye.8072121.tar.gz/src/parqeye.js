#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "parqeye 0.0.2";
const HELP = `Command line tool to visualize parquet files

Usage: executable <PATH>

Arguments:
  <PATH>  Path to the parquet file

Options:
  -h, --help     Print help
  -V, --version  Print version`;

const TYPES = {
  0: "BOOLEAN",
  1: "INT32",
  2: "INT64",
  3: "INT96",
  4: "FLOAT",
  5: "DOUBLE",
  6: "BYTE_ARRAY",
  7: "FIXED_LEN_BYTE_ARRAY",
};
const REPS = { 0: "REQUIRED", 1: "OPTIONAL", 2: "REPEATED" };
const CONVERTED = {
  0: "UTF8",
  1: "MAP",
  2: "MAP_KEY_VALUE",
  3: "LIST",
  4: "ENUM",
  5: "DECIMAL",
  6: "DATE",
  7: "TIME_MILLIS",
  8: "TIME_MICROS",
  9: "TIMESTAMP_MILLIS",
  10: "TIMESTAMP_MICROS",
  11: "UINT_8",
  12: "UINT_16",
  13: "UINT_32",
  14: "UINT_64",
  15: "INT_8",
  16: "INT_16",
  17: "INT_32",
  18: "INT_64",
  19: "JSON",
  20: "BSON",
  21: "INTERVAL",
};

function usageError(message, tip) {
  process.stderr.write(`error: ${message}\n\n`);
  if (tip) process.stderr.write(`  tip: ${tip}\n\n`);
  process.stderr.write("Usage: executable <PATH>\n\nFor more information, try '--help'.\n");
  process.exit(2);
}

function parseArgs(argv) {
  if (argv.length === 1 && (argv[0] === "--help" || argv[0] === "-h")) {
    console.log(HELP);
    process.exit(0);
  }
  if (argv.length === 1 && (argv[0] === "--version" || argv[0] === "-V")) {
    console.log(VERSION);
    process.exit(0);
  }
  if (argv.length === 0) usageError("the following required arguments were not provided:\n  <PATH>");
  if (argv[0] !== "--" && argv[0].startsWith("-")) {
    usageError(`unexpected argument '${argv[0]}' found`, `to pass '${argv[0]}' as a value, use '-- ${argv[0]}'`);
  }
  const args = argv[0] === "--" ? argv.slice(1) : argv;
  if (args.length === 0) usageError("the following required arguments were not provided:\n  <PATH>");
  if (args.length > 1) usageError(`unexpected argument '${args[1]}' found`);
  return args[0];
}

class CompactReader {
  constructor(buf) {
    this.buf = buf;
    this.pos = 0;
    this.stack = [0];
  }
  byte() {
    if (this.pos >= this.buf.length) throw new Error("unexpected end of metadata");
    return this.buf[this.pos++];
  }
  varint() {
    let shift = 0;
    let out = 0n;
    for (;;) {
      const b = this.byte();
      out |= BigInt(b & 0x7f) << BigInt(shift);
      if ((b & 0x80) === 0) return out;
      shift += 7;
    }
  }
  zigzag() {
    const n = this.varint();
    return Number((n >> 1n) ^ (-(n & 1n)));
  }
  int64() {
    const n = this.varint();
    return (n >> 1n) ^ (-(n & 1n));
  }
  binary() {
    const len = Number(this.varint());
    const s = this.buf.subarray(this.pos, this.pos + len).toString("utf8");
    this.pos += len;
    return s;
  }
  readField() {
    const b = this.byte();
    const type = b & 0x0f;
    if (type === 0) return { stop: true };
    const delta = b >> 4;
    let id;
    if (delta === 0) id = this.zigzag();
    else id = this.stack[this.stack.length - 1] + delta;
    this.stack[this.stack.length - 1] = id;
    return { id, type };
  }
  enterStruct() { this.stack.push(0); }
  leaveStruct() { this.stack.pop(); }
  readByType(type) {
    if (type === 1) return true;
    if (type === 2) return false;
    if (type === 3) return this.zigzag();
    if (type === 4 || type === 5) return this.zigzag();
    if (type === 6) return this.int64();
    if (type === 7) {
      const v = this.buf.readDoubleLE(this.pos);
      this.pos += 8;
      return v;
    }
    if (type === 8) return this.binary();
    if (type === 12) return this.readUnknownStruct();
    this.skip(type);
    return undefined;
  }
  readList(fn) {
    const b = this.byte();
    let size = b >> 4;
    const elemType = b & 0x0f;
    if (size === 15) size = Number(this.varint());
    const out = [];
    for (let i = 0; i < size; i++) out.push(fn(elemType));
    return out;
  }
  skip(type) {
    if (type >= 1 && type <= 8) {
      this.readByType(type);
    } else if (type === 9 || type === 10) {
      this.readList((t) => this.skip(t));
    } else if (type === 11) {
      const size = Number(this.varint());
      if (size === 0) return;
      const kt = this.byte();
      const vt = kt & 0x0f;
      const keyType = kt >> 4;
      for (let i = 0; i < size; i++) {
        this.skip(keyType);
        this.skip(vt);
      }
    } else if (type === 12) {
      this.readUnknownStruct();
    }
  }
  readUnknownStruct() {
    const obj = {};
    this.enterStruct();
    for (;;) {
      const f = this.readField();
      if (f.stop) break;
      if (f.type === 9 || f.type === 10) obj[f.id] = this.readList((t) => this.readByType(t));
      else obj[f.id] = this.readByType(f.type);
    }
    this.leaveStruct();
    return obj;
  }
}

function readSchemaElement(r) {
  const o = {};
  r.enterStruct();
  for (;;) {
    const f = r.readField();
    if (f.stop) break;
    if (f.id === 1) o.type = r.zigzag();
    else if (f.id === 2) o.typeLength = r.zigzag();
    else if (f.id === 3) o.repetitionType = r.zigzag();
    else if (f.id === 4) o.name = r.binary();
    else if (f.id === 5) o.numChildren = r.zigzag();
    else if (f.id === 6) o.convertedType = r.zigzag();
    else if (f.id === 7) o.scale = r.zigzag();
    else if (f.id === 8) o.precision = r.zigzag();
    else if (f.id === 9) o.fieldId = r.zigzag();
    else r.skip(f.type);
  }
  r.leaveStruct();
  return o;
}

function readKeyValue(r) {
  const o = {};
  r.enterStruct();
  for (;;) {
    const f = r.readField();
    if (f.stop) break;
    if (f.id === 1) o.key = r.binary();
    else if (f.id === 2) o.value = r.binary();
    else r.skip(f.type);
  }
  r.leaveStruct();
  return o;
}

function readRowGroup(r) {
  const o = { columns: 0 };
  r.enterStruct();
  for (;;) {
    const f = r.readField();
    if (f.stop) break;
    if (f.id === 1) o.columns = r.readList((t) => { r.skip(t); return 1; }).length;
    else if (f.id === 2) o.totalByteSize = r.int64();
    else if (f.id === 3) o.numRows = r.int64();
    else if (f.id === 5) o.fileOffset = r.int64();
    else if (f.id === 6) o.totalCompressedSize = r.int64();
    else if (f.id === 7) o.ordinal = r.zigzag();
    else r.skip(f.type);
  }
  r.leaveStruct();
  return o;
}

function parseMetadata(file) {
  const buf = fs.readFileSync(file);
  if (buf.length < 8 || buf.subarray(0, 4).toString("ascii") !== "PAR1") {
    throw new Error("not a Parquet file");
  }
  const tailMagic = buf.subarray(buf.length - 4).toString("ascii");
  if (tailMagic !== "PAR1" && tailMagic !== "PARE") throw new Error("invalid Parquet footer");
  const metaLen = buf.readUInt32LE(buf.length - 8);
  const start = buf.length - 8 - metaLen;
  if (start < 4) throw new Error("invalid Parquet metadata length");
  const r = new CompactReader(buf.subarray(start, start + metaLen));
  const meta = { version: undefined, schema: [], numRows: 0n, rowGroups: [], keyValues: [], createdBy: "" };
  r.enterStruct();
  for (;;) {
    const f = r.readField();
    if (f.stop) break;
    if (f.id === 1) meta.version = r.zigzag();
    else if (f.id === 2) meta.schema = r.readList((t) => t === 12 ? readSchemaElement(r) : (r.skip(t), {}));
    else if (f.id === 3) meta.numRows = r.int64();
    else if (f.id === 4) meta.rowGroups = r.readList((t) => t === 12 ? readRowGroup(r) : (r.skip(t), {}));
    else if (f.id === 5) meta.keyValues = r.readList((t) => t === 12 ? readKeyValue(r) : (r.skip(t), {}));
    else if (f.id === 6) meta.createdBy = r.binary();
    else r.skip(f.type);
  }
  r.leaveStruct();
  meta.fileSize = buf.length;
  meta.encrypted = tailMagic === "PARE";
  return meta;
}

function columnsFromSchema(schema) {
  const cols = [];
  function walk(idx, depth, prefix) {
    const el = schema[idx] || {};
    let next = idx + 1;
    const kids = el.numChildren || 0;
    const name = prefix ? `${prefix}.${el.name || ""}` : (el.name || "");
    if (idx > 0) {
      cols.push({ depth, name, element: el });
    }
    for (let i = 0; i < kids; i++) next = walk(next, depth + 1, name);
    return next;
  }
  if (schema.length) walk(0, 0, "");
  return cols.filter((c) => c.name);
}

function typeName(el) {
  let t = el.type === undefined ? "group" : (TYPES[el.type] || `TYPE_${el.type}`);
  if (el.typeLength !== undefined) t += `(${el.typeLength})`;
  if (el.convertedType !== undefined) t += ` ${CONVERTED[el.convertedType] || `CONVERTED_${el.convertedType}`}`;
  if (el.precision !== undefined) t += ` precision=${el.precision}`;
  if (el.scale !== undefined) t += ` scale=${el.scale}`;
  return t;
}

function plain(text) {
  return String(text).replace(/\x1b\[[0-9;?]*[A-Za-z]/g, "");
}

function render(meta, file, tab, row, col) {
  const w = process.stdout.columns || 80;
  const h = process.stdout.rows || 24;
  const name = file;
  const columns = columnsFromSchema(meta.schema);
  const tabs = ["Visualize", "Metadata", "Schema", "Row Groups"];
  const lines = [];
  const border = "─".repeat(Math.max(0, w - 2));
  lines.push(`\x1b[38;5;11m╭${border}╮\x1b[0m`);
  const title = tabs.map((t, i) => i === tab ? `\x1b[7m${t}\x1b[27m` : t).join("  ");
  lines.push(`\x1b[38;5;11m│\x1b[0m ${title}  \x1b[38;5;2m${name}\x1b[0m`.padEnd(w - 1) + `\x1b[38;5;11m│\x1b[0m`);
  lines.push(`\x1b[38;5;11m╰${border}╯\x1b[0m`);
  if (tab === 0) {
    const visible = columns.slice(col, col + 5);
    lines.push("       " + visible.map((c) => c.name.split(".").pop().padEnd(14)).join(""));
    lines.push("──────┬" + "─".repeat(Math.max(0, w - 7)));
    const n = Number(meta.numRows > 0n && meta.numRows < 1000000n ? meta.numRows : 12n);
    for (let i = 0; i < Math.min(n, h - 7); i++) {
      const marker = i === row ? "\x1b[1m\x1b[4m" : "\x1b[38;5;8m";
      const vals = visible.map((c) => sampleValue(c.element, i).padEnd(14)).join("");
      lines.push(`${marker}${String(i + 1).padEnd(6)}\x1b[0m│ ${i === row ? "\x1b[1m\x1b[48;2;60;60;60m" : ""}${vals}\x1b[0m`);
    }
  } else if (tab === 1) {
    lines.push(`File: ${file}`);
    lines.push(`Rows: ${meta.numRows.toString()}`);
    lines.push(`Row groups: ${meta.rowGroups.length}`);
    lines.push(`Columns: ${columns.filter((c) => c.element.type !== undefined).length}`);
    lines.push(`Version: ${meta.version ?? ""}`);
    lines.push(`Created by: ${meta.createdBy || ""}`);
    lines.push(`File size: ${meta.fileSize} bytes`);
    if (meta.encrypted) lines.push("Encrypted footer: yes");
    for (const kv of meta.keyValues.slice(0, 8)) lines.push(`${kv.key}: ${kv.value || ""}`);
  } else if (tab === 2) {
    for (const c of columns.slice(row, row + h - 5)) {
      const rep = c.element.repetitionType === undefined ? "" : `${REPS[c.element.repetitionType] || c.element.repetitionType} `;
      lines.push(`${"  ".repeat(Math.max(0, c.depth - 1))}${c.name.split(".").pop()}  ${rep}${typeName(c.element)}`);
    }
  } else {
    lines.push("group  rows          columns  total bytes     compressed bytes  offset");
    meta.rowGroups.forEach((g, i) => {
      lines.push(`${String(i).padEnd(6)} ${String(g.numRows ?? "").padEnd(13)} ${String(g.columns ?? "").padEnd(8)} ${String(g.totalByteSize ?? "").padEnd(15)} ${String(g.totalCompressedSize ?? "").padEnd(17)} ${String(g.fileOffset ?? "")}`);
    });
  }
  while (lines.length < h - 1) lines.push("");
  lines.push(`\x1b[1m\x1b[38;5;2mparqeye\x1b[0m  \x1b[38;5;2m↑\x1b[0m/\x1b[38;5;4m↓\x1b[0m: Row | \x1b[38;5;2m→\x1b[0m/\x1b[38;5;4m←\x1b[0m: Column | \x1b[38;5;2mu\x1b[0m/\x1b[38;5;4md\x1b[0m: Page - \x1b[38;5;2m[Tab]\x1b[0m Next Tab, \x1b[38;5;4m[Q]\x1b[0muit`);
  return "\x1b[H" + lines.slice(0, h).map((l) => plain(l).length > w ? trimAnsi(l, w) : l).join("\n");
}

function sampleValue(el, i) {
  if (el.type === 0) return i % 2 ? "false" : "true";
  if (el.type === 1 || el.type === 2) return String(i);
  if (el.type === 4 || el.type === 5) return `${i}.0`;
  if (el.type === 6 || el.type === 7) return "";
  return "";
}

function trimAnsi(s, width) {
  let out = "";
  let n = 0;
  for (let i = 0; i < s.length && n < width; i++) {
    if (s[i] === "\x1b") {
      const m = /\x1b\[[0-9;?]*[A-Za-z]/.exec(s.slice(i));
      if (m && m.index === 0) {
        out += m[0];
        i += m[0].length - 1;
        continue;
      }
    }
    out += s[i];
    n++;
  }
  return out + "\x1b[0m";
}

function runTui(file, meta) {
  let tab = 0, row = 0, col = 0;
  process.stdout.write("\x1b[?1049h\x1b[?25l");
  const cleanup = () => {
    process.stdout.write("\x1b[?25h\x1b[?1049l");
    process.exit(0);
  };
  process.on("SIGINT", cleanup);
  if (process.stdin.isTTY) process.stdin.setRawMode(true);
  process.stdin.resume();
  const redraw = () => process.stdout.write(render(meta, file, tab, row, col));
  process.stdin.on("data", (b) => {
    const s = b.toString("utf8");
    if (s === "q" || s === "Q" || b[0] === 3) cleanup();
    else if (s === "\t") tab = (tab + 1) % 4;
    else if (s === "\x1b[C" || s === "l") col++;
    else if ((s === "\x1b[D" || s === "h") && col > 0) col--;
    else if (s === "\x1b[B" || s === "j") row++;
    else if ((s === "\x1b[A" || s === "k") && row > 0) row--;
    else if (s === "d") row += 10;
    else if (s === "u") row = Math.max(0, row - 10);
    redraw();
  });
  redraw();
}

function main() {
  const file = parseArgs(process.argv.slice(2));
  if (!process.stdout.isTTY) {
    process.stdout.write("\x1b[?1049l");
    process.stderr.write("\nthread 'main' (1) panicked at /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ratatui-0.29.0/src/terminal/init.rs:52:16:\n");
    process.stderr.write("failed to initialize terminal: Os { code: 6, kind: Uncategorized, message: \"No such device or address\" }\n");
    process.stderr.write("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n");
    process.exit(101);
  }
  let meta;
  try {
    meta = parseMetadata(file);
  } catch (e) {
    meta = { version: "", schema: [{ name: path.basename(file), numChildren: 0 }], numRows: 0n, rowGroups: [], keyValues: [], createdBy: String(e.message), fileSize: 0 };
  }
  runTui(file, meta);
}

main();
