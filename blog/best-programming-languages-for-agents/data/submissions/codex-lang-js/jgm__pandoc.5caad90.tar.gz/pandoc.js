#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const INPUT_FORMATS = `asciidoc
biblatex
bibtex
bits
commonmark
commonmark_x
creole
csljson
csv
djot
docbook
docx
dokuwiki
endnotexml
epub
fb2
gfm
haddock
html
ipynb
jats
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
mdoc
mediawiki
muse
native
odt
opml
org
pod
pptx
ris
rst
rtf
t2t
textile
tikiwiki
tsv
twiki
typst
vimwiki
xlsx
xml`;

const OUTPUT_FORMATS = `ansi
asciidoc
asciidoc_legacy
asciidoctor
bbcode
bbcode_fluxbb
bbcode_hubzilla
bbcode_phpbb
bbcode_steam
bbcode_xenforo
beamer
biblatex
bibtex
chunkedhtml
commonmark
commonmark_x
context
csljson
djot
docbook
docbook4
docbook5
docx
dokuwiki
dzslides
epub
epub2
epub3
fb2
gfm
haddock
html
html4
html5
icml
ipynb
jats
jats_archiving
jats_articleauthoring
jats_publishing
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
markua
mediawiki
ms
muse
native
odt
opendocument
opml
org
pdf
plain
pptx
revealjs
rst
rtf
s5
slideous
slidy
tei
texinfo
textile
typst
vimdoc
xml
xwiki
zimwiki`;

const HELP = `executable [OPTIONS] [FILES]
  -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT                                          
  -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT                                           
  -o FILE               --output=FILE                                                         
                        --data-dir=DIRECTORY                                                  
  -M KEY[:VALUE]        --metadata=KEY[:VALUE]                                                
                        --metadata-file=FILE                                                  
  -d FILE               --defaults=FILE                                                       
                        --file-scope[=true|false]                                             
                        --sandbox[=true|false]                                                
  -s[true|false]        --standalone[=true|false]                                             
                        --template=FILE                                                       
  -V KEY[:VALUE]        --variable=KEY[:VALUE]                                                
                        --variable-json=KEY[:JSON]                                            
                        --wrap=auto|none|preserve                                             
                        --ascii[=true|false]                                                  
                        --toc[=true|false], --table-of-contents[=true|false]                  
                        --toc-depth=NUMBER                                                    
  -N[true|false]        --number-sections[=true|false]                                        
  -H FILE               --include-in-header=FILE                                              
  -B FILE               --include-before-body=FILE                                            
  -A FILE               --include-after-body=FILE                                             
                        --no-highlight                                                        
                        --highlight-style=STYLE|FILE                                          
  -F PROGRAM            --filter=PROGRAM                                                      
  -L SCRIPTPATH         --lua-filter=SCRIPTPATH                                               
  -C                    --citeproc                                                            
                        --list-input-formats                                                  
                        --list-output-formats                                                 
                        --list-extensions[=FORMAT]                                            
                        --list-highlight-languages                                            
                        --list-highlight-styles                                               
  -D FORMAT             --print-default-template=FORMAT                                       
                        --print-default-data-file=FILE                                        
                        --print-highlight-style=STYLE|FILE                                    
  -v                    --version                                                             
  -h                    --help                                                                
`;

const VERSION = `pandoc 3.9.0.2
Features: +server +lua
Scripting engine: Lua 5.4
User data directory: /home/agent/.local/share/pandoc
Copyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org
This is free software; see the source for copying conditions. There is no
warranty, not even for merchantability or fitness for a particular purpose.
`;

function die(msg, code = 1) {
  process.stderr.write(msg.endsWith('\n') ? msg : msg + '\n');
  process.exit(code);
}

function stripExt(fmt) {
  return (fmt || '').split('+')[0].split('-')[0].toLowerCase();
}

function htmlEscape(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function attrEscape(s) {
  return htmlEscape(s).replace(/"/g, '&quot;');
}

function slugify(s) {
  return s.toLowerCase().replace(/<[^>]*>/g, '').replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '-');
}

function inlineHtml(s) {
  let out = htmlEscape(s);
  out = out.replace(/`([^`]+)`/g, '<code>$1</code>');
  out = out.replace(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g, (_m, alt, src, title) =>
    `<img src="${attrEscape(src)}" alt="${attrEscape(alt)}"${title ? ` title="${attrEscape(title)}"` : ''} />`);
  out = out.replace(/\[([^\]]+)\]\(([^)\s]+)(?:\s+"([^"]*)")?\)/g, (_m, text, href, title) =>
    `<a href="${attrEscape(href)}"${title ? ` title="${attrEscape(title)}"` : ''}>${text}</a>`);
  out = out.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  out = out.replace(/__([^_]+)__/g, '<strong>$1</strong>');
  out = out.replace(/\*([^*\n]+)\*/g, '<em>$1</em>');
  out = out.replace(/_([^_\n]+)_/g, '<em>$1</em>');
  return out;
}

function stripMarkdownInline(s) {
  return s
    .replace(/!\[([^\]]*)\]\([^)]+\)/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/[`*_~]/g, '');
}

function parseMarkdown(text) {
  text = text.replace(/\r\n?/g, '\n');
  text = extractYamlMeta(text).text;
  const lines = text.split('\n');
  const blocks = [];
  let i = 0;
  while (i < lines.length) {
    if (/^\s*$/.test(lines[i])) { i++; continue; }
    if (i + 1 < lines.length && /^=+\s*$/.test(lines[i + 1]) && lines[i].trim()) {
      blocks.push({ type: 'header', level: 1, text: lines[i].trim() }); i += 2; continue;
    }
    if (i + 1 < lines.length && /^-+\s*$/.test(lines[i + 1]) && lines[i].trim()) {
      blocks.push({ type: 'header', level: 2, text: lines[i].trim() }); i += 2; continue;
    }
    const hm = /^(#{1,6})\s+(.*?)(?:\s+#+)?$/.exec(lines[i]);
    if (hm) { blocks.push({ type: 'header', level: hm[1].length, text: hm[2].trim() }); i++; continue; }
    if (/^```/.test(lines[i]) || /^~~~/.test(lines[i])) {
      const fence = lines[i].slice(0, 3); const info = lines[i].slice(3).trim(); i++;
      const buf = [];
      while (i < lines.length && !lines[i].startsWith(fence)) buf.push(lines[i++]);
      if (i < lines.length) i++;
      blocks.push({ type: 'code', text: buf.join('\n'), info });
      continue;
    }
    if (/^\s{0,3}([-+*])\s+/.test(lines[i])) {
      const items = [];
      while (i < lines.length) {
        const m = /^\s{0,3}([-+*])\s+(.*)$/.exec(lines[i]);
        if (!m) break;
        items.push(m[2]); i++;
      }
      blocks.push({ type: 'ul', items }); continue;
    }
    if (/^\s{0,3}\d+[.)]\s+/.test(lines[i])) {
      const items = [];
      while (i < lines.length) {
        const m = /^\s{0,3}\d+[.)]\s+(.*)$/.exec(lines[i]);
        if (!m) break;
        items.push(m[1]); i++;
      }
      blocks.push({ type: 'ol', items }); continue;
    }
    if (/^\s{0,3}>\s?/.test(lines[i])) {
      const qs = [];
      while (i < lines.length && /^\s{0,3}>\s?/.test(lines[i])) qs.push(lines[i++].replace(/^\s{0,3}>\s?/, ''));
      blocks.push({ type: 'blockquote', blocks: parseMarkdown(qs.join('\n')) }); continue;
    }
    if (/^( {4}|\t)/.test(lines[i])) {
      const buf = [];
      while (i < lines.length && (/^( {4}|\t)/.test(lines[i]) || /^\s*$/.test(lines[i]))) buf.push(lines[i++].replace(/^( {4}|\t)/, ''));
      blocks.push({ type: 'code', text: buf.join('\n').replace(/\n+$/, ''), info: '' }); continue;
    }
    if (/^\s{0,3}([-*_])(?:\s*\1){2,}\s*$/.test(lines[i])) { blocks.push({ type: 'hr' }); i++; continue; }
    if (lines[i].includes('|') && i + 1 < lines.length && /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(lines[i + 1])) {
      const headers = splitTableRow(lines[i]); i += 2;
      const rows = [];
      while (i < lines.length && lines[i].includes('|') && !/^\s*$/.test(lines[i])) rows.push(splitTableRow(lines[i++]));
      blocks.push({ type: 'table', headers, rows }); continue;
    }
    const para = [];
    while (i < lines.length && !/^\s*$/.test(lines[i])) {
      if (para.length && (/^(#{1,6})\s+/.test(lines[i]) || /^\s{0,3}([-+*]|\d+[.)])\s+/.test(lines[i]))) break;
      para.push(lines[i++]);
    }
    blocks.push({ type: 'para', text: para.join('\n').trim() });
  }
  return blocks;
}

function extractYamlMeta(text) {
  const meta = {};
  if (!text.startsWith('---\n')) return { meta, text };
  const end = text.indexOf('\n---', 4);
  if (end < 0) return { meta, text };
  const raw = text.slice(4, end).split(/\n/);
  for (const line of raw) {
    const m = /^([A-Za-z0-9_-]+):\s*(.*)$/.exec(line);
    if (m) meta[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
  return { meta, text: text.slice(text.indexOf('\n', end + 1) + 1) };
}

function splitTableRow(line) {
  return line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(x => x.trim());
}

function blocksToHtml(blocks, opts = {}) {
  const nums = [0, 0, 0, 0, 0, 0];
  return blocks.map(b => {
    if (b.type === 'header') {
      let text = inlineHtml(b.text);
      if (opts.numberSections) {
        nums[b.level - 1]++; for (let j = b.level; j < nums.length; j++) nums[j] = 0;
        text = nums.slice(0, b.level).filter(Boolean).join('.') + ' ' + text;
      }
      return `<h${b.level} id="${attrEscape(slugify(b.text))}">${text}</h${b.level}>`;
    }
    if (b.type === 'para') return `<p>${inlineHtml(b.text).replace(/\n/g, '\n')}</p>`;
    if (b.type === 'ul') return `<ul>\n${b.items.map(x => `<li>${inlineHtml(x)}</li>`).join('\n')}\n</ul>`;
    if (b.type === 'ol') return `<ol>\n${b.items.map(x => `<li>${inlineHtml(x)}</li>`).join('\n')}\n</ol>`;
    if (b.type === 'code') return `<pre><code>${htmlEscape(b.text)}\n</code></pre>`;
    if (b.type === 'blockquote') return `<blockquote>\n${blocksToHtml(b.blocks, opts)}\n</blockquote>`;
    if (b.type === 'table') return `<table>\n<thead>\n<tr>${b.headers.map(h => `<th>${inlineHtml(h)}</th>`).join('')}</tr>\n</thead>\n<tbody>\n${b.rows.map(r => `<tr>${r.map(c => `<td>${inlineHtml(c)}</td>`).join('')}</tr>`).join('\n')}\n</tbody>\n</table>`;
    if (b.type === 'hr') return '<hr />';
    return '';
  }).filter(Boolean).join('\n');
}

function blocksToPlain(blocks) {
  const parts = [];
  for (const b of blocks) {
    if (b.type === 'header' || b.type === 'para') parts.push(stripMarkdownInline(b.text).replace(/\n/g, ' '));
    else if (b.type === 'ul') parts.push(b.items.map(x => '- ' + stripMarkdownInline(x)).join('\n'));
    else if (b.type === 'ol') parts.push(b.items.map((x, i) => `${i + 1}. ${stripMarkdownInline(x)}`).join('\n'));
    else if (b.type === 'code') parts.push(b.text);
    else if (b.type === 'blockquote') parts.push(blocksToPlain(b.blocks));
    else if (b.type === 'table') parts.push([b.headers.join('\t'), ...b.rows.map(r => r.join('\t'))].join('\n'));
  }
  return parts.join('\n\n');
}

function blocksToMarkdown(blocks) {
  const parts = [];
  for (const b of blocks) {
    if (b.type === 'header') parts.push('#'.repeat(b.level) + ' ' + b.text);
    else if (b.type === 'para') parts.push(b.text);
    else if (b.type === 'ul') parts.push(b.items.map(x => '- ' + x).join('\n'));
    else if (b.type === 'ol') parts.push(b.items.map((x, i) => `${i + 1}. ${x}`).join('\n'));
    else if (b.type === 'code') parts.push('```' + (b.info || '') + '\n' + b.text + '\n```');
    else if (b.type === 'blockquote') parts.push(blocksToMarkdown(b.blocks).split('\n').map(l => '> ' + l).join('\n'));
    else if (b.type === 'table') parts.push('| ' + b.headers.join(' | ') + ' |\n|' + b.headers.map(() => '---').join('|') + '|\n' + b.rows.map(r => '| ' + r.join(' | ') + ' |').join('\n'));
    else if (b.type === 'hr') parts.push('---');
  }
  return parts.join('\n\n');
}

function inlinesFor(s) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|\[[^\]]+\]\([^)]+\)|`[^`]+`|\s+|[^\s]+)/g;
  let m;
  while ((m = re.exec(s))) {
    const tok = m[0];
    if (/^\s+$/.test(tok)) out.push({ t: 'Space' });
    else if (/^\*\*.*\*\*$/.test(tok)) out.push({ t: 'Strong', c: [{ t: 'Str', c: tok.slice(2, -2) }] });
    else if (/^\*.*\*$/.test(tok)) out.push({ t: 'Emph', c: [{ t: 'Str', c: tok.slice(1, -1) }] });
    else {
      const lm = /^\[([^\]]+)\]\(([^)]+)\)$/.exec(tok);
      if (lm) out.push({ t: 'Link', c: [['', [], []], [{ t: 'Str', c: lm[1] }], [lm[2].split(/\s+/)[0], '']] });
      else out.push({ t: 'Str', c: tok.replace(/`/g, '') });
    }
  }
  while (out[0] && out[0].t === 'Space') out.shift();
  while (out[out.length - 1] && out[out.length - 1].t === 'Space') out.pop();
  return out;
}

function blocksToJson(blocks) {
  function block(b) {
    if (b.type === 'header') return { t: 'Header', c: [b.level, [slugify(b.text), [], []], inlinesFor(b.text)] };
    if (b.type === 'para') return { t: 'Para', c: inlinesFor(b.text) };
    if (b.type === 'ul') return { t: 'BulletList', c: b.items.map(x => [{ t: 'Plain', c: inlinesFor(x) }]) };
    if (b.type === 'ol') return { t: 'OrderedList', c: [[1, { t: 'Decimal' }, { t: 'Period' }], b.items.map(x => [{ t: 'Plain', c: inlinesFor(x) }])] };
    if (b.type === 'code') return { t: 'CodeBlock', c: [['', [], []], b.text] };
    if (b.type === 'blockquote') return { t: 'BlockQuote', c: b.blocks.map(block) };
    if (b.type === 'table') return { t: 'Table', c: [['', [], []], null, [], [], b.rows] };
    if (b.type === 'hr') return { t: 'HorizontalRule' };
    return { t: 'Para', c: [] };
  }
  return JSON.stringify({ 'pandoc-api-version': [1, 23, 1, 1], meta: {}, blocks: blocks.map(block) });
}

function htmlToMarkdown(html) {
  let s = html.replace(/\r\n?/g, '\n');
  s = s.replace(/<h([1-6])[^>]*>([\s\S]*?)<\/h\1>/gi, (_m, n, t) => '\n\n' + '#'.repeat(+n) + ' ' + htmlText(t) + '\n\n');
  s = s.replace(/<p[^>]*>([\s\S]*?)<\/p>/gi, (_m, t) => '\n\n' + htmlText(t) + '\n\n');
  s = s.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, (_m, t) => '- ' + htmlText(t) + '\n');
  s = s.replace(/<br\s*\/?>/gi, '\n');
  s = s.replace(/<\/?(ul|ol|div|section|article|body|html)[^>]*>/gi, '\n');
  return s.replace(/<[^>]+>/g, '').replace(/\n{3,}/g, '\n\n').trimEnd();
}

function htmlText(s) {
  return s
    .replace(/<em[^>]*>([\s\S]*?)<\/em>/gi, '*$1*')
    .replace(/<strong[^>]*>([\s\S]*?)<\/strong>/gi, '**$1**')
    .replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, '`$1`')
    .replace(/<a\s+[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi, '[$2]($1)')
    .replace(/<[^>]+>/g, '')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').trim();
}

function standaloneHtml(body, meta) {
  const title = meta.title || '';
  return `<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="" xml:lang="">
<head>
  <meta charset="utf-8" />
  <meta name="generator" content="pandoc" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <title>${htmlEscape(title)}</title>
</head>
<body>
${title ? `<header id="title-block-header">\n<h1 class="title">${htmlEscape(title)}</h1>\n</header>\n` : ''}${body}
</body>
</html>`;
}

function parseArgs(argv) {
  const opts = { from: 'markdown', to: 'html', files: [], meta: {}, variables: {}, standalone: false, numberSections: false, toc: false, explicitFrom: false, explicitTo: false };
  const needsVal = new Set(['-f','-r','--from','--read','-t','-w','--to','--write','-o','--output','-M','--metadata','-V','--variable','-D','--print-default-template','--print-default-data-file','--print-highlight-style','--list-extensions','--template','--data-dir','--metadata-file','-d','--defaults','-H','--include-in-header','-B','--include-before-body','-A','--include-after-body']);
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    let val = null;
    if (a.startsWith('--') && a.includes('=')) { const p = a.indexOf('='); val = a.slice(p + 1); a = a.slice(0, p); }
    if (/^-[fr]..+/.test(a)) { opts.from = a.slice(2); opts.explicitFrom = true; continue; }
    if (/^-[tw]..+/.test(a)) { opts.to = a.slice(2); opts.explicitTo = true; continue; }
    if (/^-o.+/.test(a)) { opts.output = a.slice(2); continue; }
    if (/^-[MV].+/.test(a)) {
      const raw = a.slice(2); const idx = raw.indexOf(':'); const idx2 = raw.indexOf('=');
      const cut = idx >= 0 ? idx : idx2;
      if (cut >= 0) opts.meta[raw.slice(0, cut)] = raw.slice(cut + 1); else opts.meta[raw] = true;
      continue;
    }
    if (a === '-h' || a === '--help') opts.help = true;
    else if (a === '-v' || a === '--version') opts.version = true;
    else if (a === '--list-input-formats') opts.listInput = true;
    else if (a === '--list-output-formats') opts.listOutput = true;
    else if (a === '--list-highlight-styles') opts.listHighlightStyles = true;
    else if (a === '--list-highlight-languages') opts.listHighlightLanguages = true;
    else if (a === '--list-extensions') opts.listExtensions = 'markdown';
    else if (a === '--bash-completion') opts.bashCompletion = true;
    else if (a === '-s' || a === '--standalone') opts.standalone = val === null ? true : val !== 'false';
    else if (a.startsWith('-s') && a !== '-s') opts.standalone = a.slice(2) !== 'false';
    else if (a === '--toc' || a === '--table-of-contents') opts.toc = val === null ? true : val !== 'false';
    else if (a === '-N' || a === '--number-sections') opts.numberSections = val === null ? true : val !== 'false';
    else if (a.startsWith('-N') && a !== '-N') opts.numberSections = a.slice(2) !== 'false';
    else if (needsVal.has(a)) {
      if (val === null) val = argv[++i];
      if (val === undefined) die(`${a} requires an argument`);
      if (['-f','-r','--from','--read'].includes(a)) { opts.from = val; opts.explicitFrom = true; }
      else if (['-t','-w','--to','--write'].includes(a)) { opts.to = val; opts.explicitTo = true; }
      else if (['-o','--output'].includes(a)) opts.output = val;
      else if (['-M','--metadata','-V','--variable'].includes(a)) {
        const idx = val.indexOf(':'); const idx2 = val.indexOf('=');
        const cut = idx >= 0 ? idx : idx2;
        if (cut >= 0) opts.meta[val.slice(0, cut)] = val.slice(cut + 1);
        else opts.meta[val] = true;
      } else if (['-D','--print-default-template'].includes(a)) opts.defaultTemplate = val;
      else if (a === '--print-default-data-file') opts.defaultDataFile = val;
      else if (a === '--print-highlight-style') opts.printHighlightStyle = val;
      else if (a === '--list-extensions') opts.listExtensions = val || 'markdown';
    } else if (a.startsWith('-') && a !== '-') {
      // Accepted but ignored common pandoc switches.
    } else opts.files.push(a);
  }
  if (opts.output && !opts.explicitTo) {
    const ext = path.extname(opts.output).replace(/^\./, '').toLowerCase();
    const map = { md: 'markdown', markdown: 'markdown', txt: 'plain', text: 'plain', html: 'html', htm: 'html', json: 'json', tex: 'latex', latex: 'latex' };
    if (map[ext]) opts.to = map[ext];
  }
  if (opts.files.length && !opts.explicitFrom) {
    const ext = path.extname(opts.files[0]).replace(/^\./, '').toLowerCase();
    const map = { md: 'markdown', markdown: 'markdown', html: 'html', htm: 'html', csv: 'csv', tsv: 'tsv', json: 'json', tex: 'latex' };
    if (map[ext]) opts.from = map[ext];
  }
  return opts;
}

function readInput(files) {
  if (!files.length || (files.length === 1 && files[0] === '-')) return fs.readFileSync(0, 'utf8');
  return files.map(f => fs.readFileSync(f, 'utf8')).join('\n');
}

function convert(input, opts) {
  const from = stripExt(opts.from), to = stripExt(opts.to);
  let md = input;
  const yaml = extractYamlMeta(input);
  opts.meta = Object.assign({}, yaml.meta, opts.meta);
  if (from === 'html' || from === 'html4' || from === 'html5') md = htmlToMarkdown(input);
  else if (from === 'csv' || from === 'tsv') md = delimitedToMarkdown(input, from === 'tsv' ? '\t' : ',');
  else if (from === 'json') {
    try {
      const j = JSON.parse(input); md = (j.blocks || []).map(b => {
        if (b.t === 'Header') return '#'.repeat(b.c[0]) + ' ' + stringifyInlines(b.c[2]);
        if (b.t === 'Para' || b.t === 'Plain') return stringifyInlines(b.c);
        return '';
      }).filter(Boolean).join('\n\n');
    } catch { md = input; }
  }
  const blocks = parseMarkdown(md);
  let out;
  if (['html','html4','html5','revealjs','s5','slidy','slideous','dzslides'].includes(to)) {
    out = blocksToHtml(blocks, opts);
    if (opts.toc) out = tocHtml(blocks) + (out ? '\n' + out : '');
    if (opts.standalone) out = standaloneHtml(out, opts.meta);
  } else if (to === 'plain' || to === 'ansi') out = blocksToPlain(blocks);
  else if (['markdown','markdown_strict','markdown_mmd','markdown_phpextra','markdown_github','gfm','commonmark','commonmark_x'].includes(to)) out = blocksToMarkdown(blocks);
  else if (to === 'json') out = blocksToJson(blocks);
  else if (to === 'native') out = 'Pandoc (Meta {unMeta = fromList []}) ' + JSON.stringify(JSON.parse(blocksToJson(blocks)).blocks);
  else if (to === 'latex' || to === 'beamer') out = blocks.map(b => b.type === 'header' ? `${b.level === 1 ? '\\section' : b.level === 2 ? '\\subsection' : '\\subsubsection'}{${stripMarkdownInline(b.text)}}` : b.type === 'para' ? stripMarkdownInline(b.text) : '').filter(Boolean).join('\n\n');
  else out = blocksToMarkdown(blocks);
  return out.endsWith('\n') ? out : out + '\n';
}

function delimitedToMarkdown(input, sep) {
  const rows = input.trim().split(/\r?\n/).map(l => parseDelimitedLine(l, sep));
  if (!rows.length) return '';
  return '| ' + rows[0].join(' | ') + ' |\n|' + rows[0].map(() => '---').join('|') + '|\n' +
    rows.slice(1).map(r => '| ' + r.join(' | ') + ' |').join('\n');
}

function parseDelimitedLine(line, sep) {
  const out = []; let cur = ''; let q = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
    else if (ch === '"') q = !q;
    else if (ch === sep && !q) { out.push(cur); cur = ''; }
    else cur += ch;
  }
  out.push(cur);
  return out;
}

function tocHtml(blocks) {
  const items = blocks.filter(b => b.type === 'header').map(b => `<li><a href="#${attrEscape(slugify(b.text))}">${htmlEscape(stripMarkdownInline(b.text))}</a></li>`);
  return items.length ? `<nav id="TOC" role="doc-toc">\n<ul>\n${items.join('\n')}\n</ul>\n</nav>` : '';
}

function stringifyInlines(xs) {
  return (xs || []).map(x => x.t === 'Space' ? ' ' : x.t === 'Str' ? x.c : Array.isArray(x.c) ? stringifyInlines(x.c.flat ? x.c.flat(2).filter(y => y && y.t) : []) : '').join('');
}

function defaultTemplate(fmt) {
  if (/html/.test(fmt)) return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="generator" content="pandoc" />
  <title>$title$</title>
</head>
<body>
$body$
</body>
</html>
`;
  if (/latex/.test(fmt)) return `$if(title)$
\\title{$title$}
$endif$
\\begin{document}
$body$
\\end{document}
`;
  return '$body$\n';
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) return process.stdout.write(HELP);
  if (opts.version) return process.stdout.write(VERSION);
  if (opts.listInput) return process.stdout.write(INPUT_FORMATS + '\n');
  if (opts.listOutput) return process.stdout.write(OUTPUT_FORMATS + '\n');
  if (opts.listHighlightStyles) return process.stdout.write('pygments\ntango\nespresso\nzenburn\nkate\nmonochrome\nbreezedark\nhaddock\n');
  if (opts.listHighlightLanguages) return process.stdout.write('abc\nactionscript\nada\nagda\napache\nasn1\nasp\nats\nawk\nbash\nbibtex\nc\ncpp\ncss\ndefault\nhtml\njavascript\njson\nlua\nmarkdown\npython\nxml\nyaml\n');
  if (opts.listExtensions) return process.stdout.write('+smart\n+emoji\n+tex_math_dollars\n+fenced_code_blocks\n+footnotes\n+tables\n+pipe_tables\n+strikeout\n+header_attributes\n+link_attributes\n+raw_html\n');
  if (opts.defaultTemplate) return process.stdout.write(defaultTemplate(opts.defaultTemplate));
  if (opts.defaultDataFile) return process.stdout.write('');
  if (opts.printHighlightStyle) return process.stdout.write('{\n  "text-color": null,\n  "background-color": null\n}\n');
  if (opts.bashCompletion) return process.stdout.write('');
  const input = readInput(opts.files);
  const out = convert(input, opts);
  if (opts.output) fs.writeFileSync(opts.output, out);
  else process.stdout.write(out);
}

try { main(); } catch (e) { die(`executable: ${e.message || e}`); }
