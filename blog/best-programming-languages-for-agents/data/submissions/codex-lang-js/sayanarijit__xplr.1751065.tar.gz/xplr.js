#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "xplr 1.1.0";
const VARIANTS = [
  "ExplorePwd", "ExplorePwdAsync", "ExploreParentsAsync", "TryCompletePath",
  "ClearScreen", "Refresh", "FocusNext", "FocusNextSelection",
  "FocusNextByRelativeIndex", "FocusNextByRelativeIndexFromInput",
  "FocusPrevious", "FocusPreviousSelection", "FocusPreviousByRelativeIndex",
  "FocusPreviousByRelativeIndexFromInput", "FocusFirst", "FocusLast",
  "FocusPath", "FocusPathFromInput", "FocusByIndex", "FocusByIndexFromInput",
  "FocusByFileName", "ScrollUp", "ScrollDown", "ScrollUpHalf",
  "ScrollDownHalf", "ChangeDirectory", "Enter", "Back", "LastVisitedPath",
  "NextVisitedPath", "PreviousVisitedDeepBranch", "NextVisitedDeepBranch",
  "FollowSymlink", "SetVroot", "UnsetVroot", "ToggleVroot", "ResetVroot",
  "SetInputPrompt", "UpdateInputBuffer", "UpdateInputBufferFromKey",
  "BufferInput", "BufferInputFromKey", "SetInputBuffer",
  "RemoveInputBufferLastCharacter", "RemoveInputBufferLastWord",
  "ResetInputBuffer", "SwitchMode", "SwitchModeKeepingInputBuffer",
  "SwitchModeBuiltin", "SwitchModeBuiltinKeepingInputBuffer",
  "SwitchModeCustom", "SwitchModeCustomKeepingInputBuffer", "PopMode",
  "PopModeKeepingInputBuffer", "SwitchLayout", "SwitchLayoutBuiltin",
  "SwitchLayoutCustom", "Call", "Call0", "CallSilently", "CallSilently0",
  "BashExec", "BashExec0", "BashExecSilently", "BashExecSilently0",
  "CallLua", "CallLuaSilently", "LuaEval", "LuaEvalSilently", "Select",
  "SelectAll", "SelectPath", "UnSelect", "UnSelectAll", "UnSelectPath",
  "ToggleSelection", "ToggleSelectAll", "ToggleSelectionByPath",
  "ClearSelection", "AddNodeFilter", "RemoveNodeFilter", "ToggleNodeFilter",
  "AddNodeFilterFromInput", "RemoveNodeFilterFromInput",
  "RemoveLastNodeFilter", "ResetNodeFilters", "ClearNodeFilters",
  "AddNodeSorter", "RemoveNodeSorter", "ReverseNodeSorter",
  "ToggleNodeSorter", "ReverseNodeSorters", "RemoveLastNodeSorter",
  "ResetNodeSorters", "ClearNodeSorters", "Search", "SearchFromInput",
  "SearchFuzzy", "SearchFuzzyFromInput", "SearchFuzzyUnordered",
  "SearchFuzzyUnorderedFromInput", "SearchRegex", "SearchRegexFromInput",
  "SearchRegexUnordered", "SearchRegexUnorderedFromInput",
  "ToggleSearchAlgorithm", "EnableSearchOrder", "DisableSearchOrder",
  "ToggleSearchOrder", "AcceptSearch", "CancelSearch", "EnableMouse",
  "DisableMouse", "ToggleMouse", "StartFifo", "StopFifo", "ToggleFifo",
  "LogInfo", "LogSuccess", "LogWarning", "LogError", "Debug", "Quit",
  "PrintPwdAndQuit", "PrintFocusPathAndQuit", "PrintSelectionAndQuit",
  "PrintResultAndQuit", "PrintAppStateAndQuit", "Terminate",
];

const SIMPLE_STRING_KEYS = new Set([
  "FocusPath", "FocusPathFromInput", "FocusByFileName", "ChangeDirectory",
  "SetVroot", "SetInputPrompt", "UpdateInputBuffer", "BufferInput",
  "SetInputBuffer", "SwitchMode", "SwitchModeBuiltin", "SwitchModeCustom",
  "SwitchLayout", "SwitchLayoutBuiltin", "SwitchLayoutCustom", "BashExec",
  "BashExec0", "BashExecSilently", "BashExecSilently0", "CallLua",
  "CallLuaSilently", "LuaEval", "LuaEvalSilently", "SelectPath",
  "UnSelectPath", "ToggleSelectionByPath", "AddNodeFilter",
  "RemoveNodeFilter", "ToggleNodeFilter", "Search", "SearchFuzzy",
  "SearchFuzzyUnordered", "SearchRegex", "SearchRegexUnordered", "LogInfo",
  "LogSuccess", "LogWarning", "LogError", "Debug",
]);

const NUMBER_KEYS = new Set([
  "FocusByIndex", "FocusNextByRelativeIndex", "FocusPreviousByRelativeIndex",
]);

const HELP = `${VERSION}
Arijit Basu <hi@arijitbasu.in>
A hackable, minimal, fast TUI file explorer

USAGE:
    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...

FLAGS:
  -                            Reads new-line (\\n) separated paths from stdin
  --                           Denotes the end of command-line flags and options
      --force-focus            Focuses on the given <PATH>, even if it is a directory
  -h, --help                   Prints help information
  -m, --pipe-msg-in            Helps safely passing messages to the active xplr
                                 session, use %%, %s and %q as the placeholders
  -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of
                                 passing to the active xplr session
      --print-pwd-as-result    Prints the present working directory when quitting
                                 with \`PrintResultAndQuit\`
      --read-only              Enables read-only mode (config.general.read_only)
      --read0                  Reads paths separated using the null character (\\0)
      --write0                 Prints paths separated using the null character (\\0)
  -0  --null                   Combines --read0 and --write0
  -V, --version                Prints version information

OPTIONS:
  -c, --config <PATH>             Specifies a custom config file (default is
                                    "$HOME/.config/xplr/init.lua")
  -C, --extra-config <PATH>...    Specifies extra config files to load
      --on-load <MESSAGE>...      Sends messages when xplr loads
      --vroot <PATH>              Treats the specified path as the virtual root

ARGS:
  <PATH>            Path to focus on, or enter if directory, (default is \`.\`)
  <SELECTION>...    Paths to select, requires <PATH> to be set explicitly
`;

function die(msg) {
  process.stderr.write(`error: ${msg}\n`);
  process.exit(1);
}

function invalidArg(arg) {
  die(`invalid argument: "${arg}", try \`-- "${arg}"\` or \`--help\``);
}

function jsonString(s) {
  return JSON.stringify(String(s));
}

function renderTemplate(fmt, values) {
  let out = "";
  let vi = 0;
  for (let i = 0; i < fmt.length; i++) {
    if (fmt[i] !== "%") {
      out += fmt[i];
      continue;
    }
    const col = i + 1;
    const n = fmt[++i];
    if (n === undefined) out += "%";
    else if (n === "%") out += "%";
    else if (n === "q" || n === "s") {
      if (vi >= values.length) die(`xplr -m: placeholder missing value at column ${col}`);
      out += n === "q" ? jsonString(values[vi++]) : values[vi++];
    } else if (n === "*") {
      const kind = fmt[++i];
      if (kind !== "q" && kind !== "s") out += `%*${kind || ""}`;
      else {
        const rest = values.slice(vi);
        vi = values.length;
        out += rest.map(v => kind === "q" ? jsonString(v) : v).join(", ");
      }
    } else {
      out += `%${n}`;
    }
  }
  if (vi < values.length) die("xplr -m: too many positional values, not enough positional placeholders");
  return out;
}

function splitTopLevel(s) {
  const parts = [];
  let cur = "", depth = 0, quote = null, esc = false;
  for (const ch of s) {
    if (quote) {
      cur += ch;
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === quote) quote = null;
    } else if (ch === '"' || ch === "'") {
      quote = ch; cur += ch;
    } else if (ch === "[" || ch === "{") {
      depth++; cur += ch;
    } else if (ch === "]" || ch === "}") {
      depth--; cur += ch;
    } else if (ch === "," && depth === 0) {
      parts.push(cur.trim()); cur = "";
    } else {
      cur += ch;
    }
  }
  if (cur.trim() !== "") parts.push(cur.trim());
  return parts;
}

function parseScalar(s) {
  s = s.trim();
  if (s === "") return "";
  if (s[0] === '"' || s[0] === "'") {
    try {
      if (s[0] === '"') return JSON.parse(s);
      return s.slice(1, -1).replace(/''/g, "'");
    } catch (_) {
      return s.slice(1, -1);
    }
  }
  if (/^-?\d+$/.test(s)) return Number(s);
  if (s === "true") return true;
  if (s === "false") return false;
  if (s[0] === "[") return splitTopLevel(s.slice(1, -1)).map(parseScalar);
  if (s[0] === "{") return parseInlineMap(s);
  return s;
}

function parseInlineMap(s) {
  const obj = {};
  const body = s.trim().replace(/^\{/, "").replace(/\}$/, "");
  for (const part of splitTopLevel(body)) {
    const idx = findColon(part);
    if (idx < 0) continue;
    let key = part.slice(0, idx).trim();
    key = key.replace(/^["']|["']$/g, "");
    obj[key] = parseScalar(part.slice(idx + 1));
  }
  return obj;
}

function findColon(s) {
  let depth = 0, quote = null, esc = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quote) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === quote) quote = null;
    } else if (ch === '"' || ch === "'") quote = ch;
    else if (ch === "[" || ch === "{") depth++;
    else if (ch === "]" || ch === "}") depth--;
    else if (ch === ":" && depth === 0) return i;
  }
  return -1;
}

function parseMessage(src) {
  const s = src.trim();
  if (VARIANTS.includes(s)) return s;
  if (s.startsWith("{")) {
    const m = parseInlineMap(s);
    const keys = Object.keys(m);
    if (keys.length === 1 && VARIANTS.includes(keys[0])) return { [keys[0]]: normalizePayload(keys[0], m[keys[0]]) };
  }
  const idx = findColon(s);
  if (idx < 0) unknownVariant(s);
  const key = s.slice(0, idx).trim();
  const raw = s.slice(idx + 1).trim();
  if (!VARIANTS.includes(key)) unknownVariant(s);
  if (raw.includes(": ") && !(raw.startsWith("{") || raw.startsWith("[") || raw.startsWith('"') || raw.startsWith("'"))) {
    die(`xplr -m: yaml: mapping values are not allowed in this context at line 1 column ${idx + raw.indexOf(": ") + 3}`);
  }
  return { [key]: normalizePayload(key, parseScalar(raw)) };
}

function normalizePayload(key, value) {
  if (NUMBER_KEYS.has(key)) return Number(value);
  if (key === "Call" || key === "Call0" || key === "CallSilently" || key === "CallSilently0") {
    if (!value || typeof value !== "object" || Array.isArray(value) || value.command == null) {
      die(`missing field \`command\` at line 1 column ${String(value).length + key.length + 10}`);
    }
    if (!Array.isArray(value.args)) value.args = [];
    return value;
  }
  if (SIMPLE_STRING_KEYS.has(key)) return String(value);
  return value;
}

function unknownVariant(s) {
  const col = Math.max(1, s.length + 1);
  die(`unknown variant \`${s}\`, expected one of \`${VARIANTS.join("`, `")}\` at line 1 column ${col}`);
}

function handleMsg(print, fmt, values) {
  if (!fmt) die(`usage: xplr ${print ? "-M" : "-m"} FORMAT [ARGUMENT]...`);
  const rendered = renderTemplate(fmt, values);
  const msg = parseMessage(rendered);
  const out = JSON.stringify(msg);
  if (print || !process.env.XPLR_PIPE_MSG_IN) {
    process.stdout.write(out + "\n");
  } else {
    die("failed to detect delimmiter");
  }
}

function checkPathExists(p) {
  const full = path.resolve(process.cwd(), p);
  if (!fs.existsSync(full)) die(`path doesn't exist: ${full}`);
}

function main(argv) {
  let positional = [];
  let endFlags = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!endFlags && a === "--") { endFlags = true; continue; }
    if (!endFlags && (a === "-h" || a === "--help")) { process.stdout.write(HELP); return; }
    if (!endFlags && (a === "-V" || a === "--version")) { process.stdout.write(VERSION + "\n"); return; }
    if (!endFlags && (a === "-M" || a === "--print-msg-in")) return handleMsg(true, argv[i + 1], argv.slice(i + 2));
    if (!endFlags && (a === "-m" || a === "--pipe-msg-in")) return handleMsg(false, argv[i + 1], argv.slice(i + 2));
    if (!endFlags && (a === "-c" || a === "--config")) {
      const v = argv[++i];
      if (!v) die("usage: xplr --config PATH");
      checkPathExists(v);
      continue;
    }
    if (!endFlags && (a === "-C" || a === "--extra-config" || a === "--vroot" || a === "--on-load")) {
      const v = argv[++i];
      if (!v) die(`usage: xplr ${a} PATH`);
      if (a !== "--on-load") checkPathExists(v);
      continue;
    }
    if (!endFlags && ["--force-focus", "--print-pwd-as-result", "--read-only", "--read0", "--write0", "-0", "--null", "-"].includes(a)) {
      continue;
    }
    if (!endFlags && a.startsWith("-")) invalidArg(a);
    positional.push(a);
  }
  if (positional.length > 0) checkPathExists(positional[0]);
  die("No such device or address (os error 6)");
}

main(process.argv.slice(2));
