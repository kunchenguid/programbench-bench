#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');

const VERSION = '0.2.7';
const DEFAULT_FOOTER = '<div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>';

const defaults = {
  name: 'Home', tagline: '', url: '', https: null, footer: DEFAULT_FOOTER,
  language: 'en', pagination: 10, pages_title: 'Pages', tags_title: 'Tags',
  archives_title: 'Archive', streams_title: 'Streams', series_title: 'Series',
  authors_title: 'Authors', enable_search: false, enable_related_content: true,
  content_path: 'content', templates_path: 'templates', static_path: 'static',
  media_path: 'media', default_date_format: '%b %e, %Y', toc: false,
  json_feed: false, show_next_prev_links: true, publish_md: false,
  source_repository: null, image_provider: null, theme: null,
  build_sitemap: true, publish_urls_json: true, enable_shortcodes: true,
  shortcode_pattern: null, skip_image_resize: false,
  menu: [['Tags','tags.html'], ['Archive','archive.html'], ['Authors','authors.html']]
};

function usage() {
  return `Marmite is the easiest static site generator.

Usage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]

Arguments:
  <INPUT_FOLDER>   Input folder containing markdown files
  [OUTPUT_FOLDER]  Output folder to generate the site [default: \`input_folder/site\`]

Options:
  -v, --verbose...          Verbosity level (0-4)
  -w, --watch               Detect changes and rebuild the site automatically
      --serve               Serve the site with a built-in HTTP server
      --bind <BIND>         Address to bind the server [default: 0.0.0.0:8000]
  -c, --config <CONFIG>     Path to custom configuration file [default: marmite.yaml]
      --init-templates      Initialize templates in the project
      --start-theme <THEME> Initialize a theme
      --set-theme <THEME>   Set a theme from URL or local folder
      --generate-config     Generate the configuration file
      --init-site           Init a new site with sample content and default configuration
      --force               Force rebuild
      --shortcodes          List all available shortcodes
      --show-urls           Show all site URLs organized by content type
      --new <NEW>           Create a new post with the given title
  -e                        Edit the file in the default editor
  -p                        Set the new content as a page
  -t <TAGS>                 Set the tags for the new content
      --name <NAME>         Site name [default: "Home" or value from config file]
      --tagline <TAGLINE>   Site tagline
      --url <URL>           Site url
      --https <HTTPS>       Use HTTPS [possible values: true, false]
      --footer <FOOTER>     Site footer
      --language <LANGUAGE> Site main language 2 letter code
      --pagination <N>      Number of posts per page
      --enable-search <B>   Enable search
      --toc <B>             Show Table of Contents
      --json-feed <B>       Generate JSON Feed
      --publish-md <B>      Publish markdown source files alongside HTML
  -h, --help                Print help
  -V, --version             Print version`;
}

function parseArgs(argv) {
  const o = { input: null, output: null, config: null, tags: '', page: false, bind: '0.0.0.0:8000' };
  const positional = [];
  const valueFlags = new Set(['--bind','--config','-c','--start-theme','--set-theme','--new','-t','--name','--tagline','--url','--https','--footer','--language','--pagination','--enable-search','--enable-related-content','--content-path','--templates-path','--static-path','--media-path','--default-date-format','--colorscheme','--toc','--json-feed','--show-next-prev-links','--publish-md','--source-repository','--image-provider','--theme','--build-sitemap','--publish-urls-json','--enable-shortcodes','--shortcode-pattern','--skip-image-resize']);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') o.help = true;
    else if (a === '-V' || a === '--version') o.version = true;
    else if (a === '-p') o.page = true;
    else if (a === '-e') o.edit = true;
    else if (a === '--serve') o.serve = true;
    else if (a === '--watch') o.watch = true;
    else if (a === '--generate-config') o.generateConfig = true;
    else if (a === '--init-site') o.initSite = true;
    else if (a === '--init-templates') o.initTemplates = true;
    else if (a === '--shortcodes') o.shortcodes = true;
    else if (a === '--show-urls') o.showUrls = true;
    else if (a === '--force') o.force = true;
    else if (a.startsWith('-v')) o.verbose = (o.verbose || 0) + a.length - 1;
    else if (valueFlags.has(a)) {
      const v = argv[++i];
      if (v == null) die(`error: a value is required for '${a}'`);
      const key = a.replace(/^--?/, '').replace(/-/g, '_');
      if (a === '-c') o.config = v;
      else if (a === '-t') o.tags = v;
      else o[key] = v;
    } else if (a.startsWith('--')) die(`error: unexpected argument '${a}' found`);
    else positional.push(a);
  }
  o.input = positional[0] || null;
  o.output = positional[1] || null;
  return o;
}

function die(msg, code=2) { console.error(msg); process.exit(code); }
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function slugify(s) { return String(s || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/^\d{4}-\d{2}-\d{2}-/,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'') || 'post'; }
function bool(v) { return v === true || String(v).toLowerCase() === 'true'; }

function parseYamlValue(v) {
  v = String(v ?? '').trim();
  if (v === 'null' || v === '~') return null;
  if (v === 'true') return true;
  if (v === 'false') return false;
  if (/^-?\d+$/.test(v)) return parseInt(v, 10);
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) return v.slice(1, -1);
  if (v.startsWith('[') && v.endsWith(']')) return v.slice(1,-1).split(',').map(x => parseYamlValue(x.trim())).filter(x => x !== '');
  return v;
}

function parseSimpleYaml(text) {
  const out = {};
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/^([A-Za-z0-9_-]+):\s*(.*)$/);
    if (!m) continue;
    const key = m[1].replace(/-/g,'_');
    if (m[2].trim() !== '') {
      out[key] = parseYamlValue(m[2]);
      continue;
    }
    const arr = [];
    let j = i + 1;
    for (; j < lines.length; j++) {
      const lm = lines[j].match(/^\s*-\s+(.*)$/);
      if (!lm) break;
      arr.push(parseYamlValue(lm[1]));
    }
    if (arr.length) {
      out[key] = arr;
      i = j - 1;
    } else {
      out[key] = '';
    }
  }
  return out;
}

function loadConfig(input, opts) {
  const cfg = {...defaults};
  const file = opts.config ? path.resolve(opts.config) : path.join(input, 'marmite.yaml');
  if (fs.existsSync(file)) {
    Object.assign(cfg, parseSimpleYaml(fs.readFileSync(file, 'utf8')));
  }
  for (const k of Object.keys(opts)) {
    if (k in cfg && opts[k] != null) cfg[k] = ['https','enable_search','enable_related_content','toc','json_feed','show_next_prev_links','publish_md','build_sitemap','publish_urls_json','enable_shortcodes','skip_image_resize'].includes(k) ? bool(opts[k]) : (k === 'pagination' ? parseInt(opts[k],10) : opts[k]);
  }
  if (!cfg.language) cfg.language = 'en';
  if (!Array.isArray(cfg.menu) || cfg.menu.some(x => !Array.isArray(x))) cfg.menu = defaults.menu;
  return cfg;
}

function splitFrontMatter(text) {
  if (!text.startsWith('---\n') && !text.startsWith('---\r\n')) return [{}, text];
  const end = text.indexOf('\n---', 4);
  if (end < 0) return [{}, text];
  const fm = {};
  Object.assign(fm, parseSimpleYaml(text.slice(4, end)));
  const bodyStart = text.indexOf('\n', end + 1) + 1;
  return [fm, text.slice(bodyStart)];
}

function inlineMd(s) {
  return esc(s)
    .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1">')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>')
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>');
}

function markdown(md) {
  const lines = md.replace(/\r\n/g, '\n').split('\n');
  let out = [], para = [], inUl = false, inOl = false, code = null, codebuf = [];
  const flushPara = () => { if (para.length) { out.push(`<p>${inlineMd(para.join(' '))}</p>`); para=[]; } };
  const closeLists = () => { if (inUl) { out.push('</ul>'); inUl=false; } if (inOl) { out.push('</ol>'); inOl=false; } };
  for (const line of lines) {
    const fence = line.match(/^```(.*)$/);
    if (fence) {
      if (code !== null) { out.push(`<pre><code>${esc(codebuf.join('\n'))}</code></pre>`); code=null; codebuf=[]; }
      else { flushPara(); closeLists(); code = fence[1] || ''; }
      continue;
    }
    if (code !== null) { codebuf.push(line); continue; }
    if (!line.trim()) { flushPara(); closeLists(); continue; }
    const h = line.match(/^(#{1,6})\s+(.*)$/);
    if (h) { flushPara(); closeLists(); const id=slugify(h[2]); out.push(`<h${h[1].length}><a href="#${id}" aria-hidden="true" class="anchor" id="${id}"></a>${inlineMd(h[2])}</h${h[1].length}>`); continue; }
    const ul = line.match(/^\s*[-*+]\s+(.*)$/);
    if (ul) { flushPara(); if (!inUl) { closeLists(); out.push('<ul>'); inUl=true; } out.push(`<li>${inlineMd(ul[1])}</li>`); continue; }
    const ol = line.match(/^\s*\d+\.\s+(.*)$/);
    if (ol) { flushPara(); if (!inOl) { closeLists(); out.push('<ol>'); inOl=true; } out.push(`<li>${inlineMd(ol[1])}</li>`); continue; }
    const bq = line.match(/^>\s?(.*)$/);
    if (bq) { flushPara(); closeLists(); out.push(`<blockquote><p>${inlineMd(bq[1])}</p></blockquote>`); continue; }
    para.push(line.trim());
  }
  flushPara(); closeLists();
  if (code !== null) out.push(`<pre><code>${esc(codebuf.join('\n'))}</code></pre>`);
  return out.join('\n') + (out.length ? '\n' : '');
}

function plain(md) {
  return md.replace(/```[\s\S]*?```/g,'').replace(/[#>*_`~\[\]()!-]/g,' ').replace(/\s+/g,' ').trim();
}
function fmtDate(d) {
  if (!d) return '';
  const mons = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${mons[d.getUTCMonth()]} ${String(d.getUTCDate()).padStart(2,' '), d.getUTCDate().toString().padStart(2,' ')} , ${d.getUTCFullYear()}`.replace(' ,', ',');
}
function isoDate(d) { return d ? d.toISOString().replace('.000Z','+00:00') : ''; }
function rfcDate(d) { return d ? d.toUTCString() : new Date().toUTCString(); }

function discover(input, cfg) {
  const contentDir = fs.existsSync(path.join(input, cfg.content_path)) ? path.join(input, cfg.content_path) : input;
  const files = [];
  function walk(dir) {
    for (const ent of fs.readdirSync(dir, {withFileTypes:true})) {
      const p = path.join(dir, ent.name);
      if (ent.isDirectory() && !['site','templates','static','media','.git'].includes(ent.name)) walk(p);
      else if (ent.isFile() && /\.md$/i.test(ent.name)) files.push(p);
    }
  }
  walk(contentDir);
  const items = [];
  for (const file of files) {
    const base = path.basename(file);
    const text = fs.readFileSync(file, 'utf8');
    const [fm, bodyRaw] = splitFrontMatter(text);
    if (base.startsWith('_') && base !== '_404.md') continue;
    const body = bodyRaw.replace(/^\s*#\s+.*\n?/, '');
    const title = fm.title || ((bodyRaw.match(/^\s*#\s+(.+)$/m)||[])[1]) || slugify(base.replace(/\.md$/,'')).replace(/-/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
    const filenameDate = (base.match(/^(\d{4})-(\d{2})-(\d{2})-/)||[]).slice(1).join('-');
    const dateStr = fm.date || filenameDate || null;
    const date = dateStr ? new Date(String(dateStr).slice(0,10) + 'T00:00:00Z') : null;
    const tags = Array.isArray(fm.tags) ? fm.tags.map(String) : (fm.tags ? String(fm.tags).split(',').map(s=>s.trim()).filter(Boolean) : []);
    const slug = slugify(fm.slug || title || base.replace(/\.md$/,''));
    const desc = fm.description || fm.excerpt || plain(body).slice(0, 240);
    const page = bool(fm.page) || bool(fm.html_page) || !date;
    items.push({file, base, fm, body, raw: bodyRaw, html: markdown(body), title, date, dateStr, tags, slug, desc, page, url: `/${slug}.html`});
  }
  items.sort((a,b) => (b.date?.getTime()||0) - (a.date?.getTime()||0) || a.title.localeCompare(b.title));
  return items;
}

function layout(cfg, title, body, feeds='') {
  const menu = (cfg.menu || defaults.menu).map(m => `<li><a class="menu-item secondary" href="/${esc(m[1])}">${esc(m[0])}</a></li>`).join('\n');
  return `<!DOCTYPE html>
<html lang="${esc(cfg.language || 'en')}">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark" />
    <meta name="generator" content="Marmite" />
    <meta property="og:title" content="${esc(title || cfg.name)}">
    <meta property="og:description" content="${esc(cfg.tagline || '')}">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="${esc(cfg.name)}">
    <title>${esc(title === cfg.name ? cfg.name : `${title} | ${cfg.name}`)}</title>
    <link rel="stylesheet" type="text/css" href="/static/pico.min.css">
    <link rel="stylesheet" type="text/css" href="/static/marmite.css">
    <link rel="stylesheet" type="text/css" href="/static/custom.css">
${feeds}
</head>
<body>
    <main class="container">
        <header class="header-content"><nav class="header-nav"><ul class="header-name"><li><hgroup class="h-card"><h2><a href="/" class="contrast p-name u-url">${esc(cfg.name)}</a></h2>${cfg.tagline ? `<p>${esc(cfg.tagline)}</p>` : ''}</hgroup></li></ul><button id="menu-toggle" class="hamburger">&#9776;</button><ul class="header-menu" id="header-menu">${menu}<div class="underline"></div></ul></nav></header>
        <section class="main-content">
${body}
        </section>
        <footer class="footer-content grid">${cfg.footer || DEFAULT_FOOTER}</footer>
    </main>
    <script src="/static/marmite.js"></script>
    <script src="/static/custom.js"></script>
</body>
</html>
`;
}

function contentPage(cfg, item) {
  const date = item.date ? `<span class="content-date"><small> ${fmtDate(item.date)} - &#10710; 1 min</small></span>` : '';
  const tags = item.tags.map(t => `<li><a href="/tag-${slugify(t)}.html" class="p-category">${esc(t)}</a></li>`).join('\n');
  return layout(cfg, item.title, `<article class="h-entry">
  <data class="p-name" value="${esc(item.title)}"></data>
  <a class="u-url" href="${item.url}" style="display: none;"></a>
  ${item.date ? `<time class="dt-published" datetime="${isoDate(item.date)}" style="display: none;">${fmtDate(item.date)}</time>` : ''}
  <div class="content-title" id="title"><h1>${esc(item.title)}</h1>${date}</div>
  <div class="content-html e-content">${item.html}</div>
  <footer class="data-tags-footer"><div class="date-tags-container"><div class="content-date">${date}</div><ul class="content-tags">${tags}</ul></div></footer>
</article>`, feedLinks([]));
}

function listItem(it) {
  return `<article class="content-list-item h-entry">
  <h2 class="p-name" style="display: none;">${esc(it.title)}</h2>
  <a class="u-url" href="${it.url}" style="display: none;"></a>
  ${it.date ? `<time class="dt-published" datetime="${isoDate(it.date)}" style="display: none;">${fmtDate(it.date)}</time>` : ''}
  <div class="content-title-wrapper"><h2 class="content-title"><a href="${it.url}">${esc(it.title)}</a></h2></div>
  <p class="content-excerpt p-summary">${esc(it.desc)} <a class="secondary" href="${it.url}">read more &rarr;</a></p>
  <footer class="data-tags-footer">${it.date ? `<span class="content-date"><a class="secondary" href="${it.url}">${fmtDate(it.date)}</a></span>` : ''}<ul class="content-tags overflow-auto">${it.tags.map(t=>`<li><a href="/tag-${slugify(t)}.html" class="p-category">${esc(t)}</a></li>`).join('')}</ul></footer>
</article>`;
}
function listPage(cfg, title, items) { return layout(cfg, title, `<h1>${esc(title)}</h1>\n<div class="content-list h-feed"><div class="left">\n${items.map(listItem).join('\n')}\n</div></div>`, feedLinks([])); }
function feedLinks(feeds) { return feeds.map(f => `    <link rel="alternate" type="application/rss+xml" title="${esc(f.title)}" href="${esc(f.href)}">`).join('\n'); }

function rss(cfg, title, items, href) {
  const base = absoluteBase(cfg);
  const last = items[0]?.date || new Date();
  return `<?xml version="1.0" encoding="utf-8"?><rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/"><channel><title>${esc(title)}</title><link>${esc(base)}</link><description>${esc(cfg.tagline||'')}</description><pubDate>${rfcDate(last)}</pubDate><lastBuildDate>${rfcDate(new Date())}</lastBuildDate><generator>marmite</generator>${items.map(it=>`<item><title>${esc(it.title)}</title><link>${esc(base + it.url)}</link><description><![CDATA["${it.desc}"]]></description>${it.tags.map(t=>`<category>${esc(t)}</category>`).join('')}<guid>${esc(base + it.url)}</guid>${it.date ? `<pubDate>${rfcDate(it.date)}</pubDate>` : ''}<source url="${esc(base)}">${esc(href)}</source><content:encoded><![CDATA[${it.html}]]></content:encoded></item>`).join('')}</channel></rss>`;
}
function absoluteBase(cfg) {
  if (!cfg.url) return 'http://';
  if (/^https?:\/\//.test(cfg.url)) return cfg.url.replace(/\/$/,'');
  return `${cfg.https === false ? 'http' : 'https'}://${cfg.url}`.replace(/\/$/,'');
}

function urlsObject(cfg, posts, pages, tags, years) {
  const tagUrls = tags.map(t=>`/tag-${slugify(t)}.html`);
  const archiveUrls = years.map(y=>`/archive-${y}.html`);
  const feeds = ['/index.rss', ...tags.map(t=>`/tag-${slugify(t)}.rss`), ...years.map(y=>`/archive-${y}.rss`)];
  const pag = ['/pages-1.html', ...tags.map(t=>`/tag-${slugify(t)}-1.html`), ...years.map(y=>`/archive-${y}-1.html`)];
  const obj = {posts: posts.map(p=>p.url), pages: [...pages.map(p=>p.url), '/pages.html'], tags: [...tagUrls, '/tags.html'], authors: [], series: [], streams: ['/streams.html'], archives: [...archiveUrls, '/archive.html'], feeds, pagination: pag, file_mappings: [], misc: ['/index.html']};
  obj.summary = {posts: obj.posts.length, pages: obj.pages.length, tags: obj.tags.length, authors:0, series:0, streams:1, archives:obj.archives.length, feeds:obj.feeds.length, pagination:obj.pagination.length, file_mappings:0, misc:1, total:0, meta:{url:cfg.url||'', absolute_urls:!!cfg.url}};
  obj.summary.total = Object.entries(obj.summary).filter(([k,v])=>typeof v==='number' && k!=='total').reduce((a,[,v])=>a+v,0);
  return obj;
}

function writeStatic(out) {
  const dir = path.join(out, 'static'); fs.mkdirSync(path.join(dir, 'colorschemes'), {recursive:true});
  const files = {
    'pico.min.css': 'body{font-family:system-ui,sans-serif;margin:0}.container{max-width:980px;margin:auto;padding:1rem}a{color:#0b62a3}.header-nav{display:flex;justify-content:space-between}.header-menu{display:flex;gap:1rem;list-style:none}.content-tags{display:flex;gap:.5rem;list-style:none;padding:0}',
    'marmite.css': '.content-list-item{margin:2rem 0}.content-date{color:#666}.footer-content{margin-top:3rem;border-top:1px solid #ddd;padding-top:1rem}.hamburger{display:none}',
    'custom.css': '', 'marmite.js': '', 'custom.js': '', 'search.js': '', 'robots.txt': 'User-agent: *\nAllow: /\n'
  };
  for (const [n,c] of Object.entries(files)) fs.writeFileSync(path.join(dir,n), c);
  for (const n of ['default','catppuccin','clean','dracula','github','gruvbox','iceberg','minimal','minimal_wb','monokai','nord','one','solarized','typewriter']) fs.writeFileSync(path.join(dir,'colorschemes',`${n}.css`), '');
  for (const n of ['favicon.ico','logo.png','avatar-placeholder.png','Atkinson-Hyperlegible-Regular-102.woff']) fs.writeFileSync(path.join(dir,n), '');
}

function build(input, output, opts={}) {
  if (!fs.existsSync(input)) { console.error(`[${new Date().toISOString()} ERROR marmite] Input folder does not exist: "${input}"`); process.exit(1); }
  const cfg = loadConfig(input, opts);
  fs.mkdirSync(output, {recursive:true});
  const items = discover(input, cfg);
  const posts = items.filter(i=>!i.page);
  const pages = items.filter(i=>i.page);
  for (const it of items) {
    fs.writeFileSync(path.join(output, `${it.slug}.html`), contentPage(cfg, it));
    if (cfg.publish_md) fs.copyFileSync(it.file, path.join(output, path.basename(it.file)));
  }
  const tags = [...new Set(posts.flatMap(p=>p.tags))];
  const years = [...new Set(posts.filter(p=>p.date).map(p=>p.date.getUTCFullYear()))].sort((a,b)=>b-a);
  fs.writeFileSync(path.join(output,'index.html'), listPage(cfg, cfg.name, posts));
  fs.writeFileSync(path.join(output,'index-1.html'), fs.readFileSync(path.join(output,'index.html')));
  fs.writeFileSync(path.join(output,'pages.html'), listPage(cfg, cfg.pages_title, pages));
  fs.writeFileSync(path.join(output,'pages-1.html'), fs.readFileSync(path.join(output,'pages.html')));
  fs.writeFileSync(path.join(output,'archive.html'), listPage(cfg, cfg.archives_title, posts));
  fs.writeFileSync(path.join(output,'tags.html'), layout(cfg, cfg.tags_title, `<h1>${esc(cfg.tags_title)}</h1><ul>${tags.map(t=>`<li><a href="/tag-${slugify(t)}.html">${esc(t)}</a> (${posts.filter(p=>p.tags.includes(t)).length})</li>`).join('')}</ul>`));
  for (const title of ['authors','streams','series']) fs.writeFileSync(path.join(output,`${title}.html`), layout(cfg, title[0].toUpperCase()+title.slice(1), `<h1>${title[0].toUpperCase()+title.slice(1)}</h1>`));
  fs.writeFileSync(path.join(output,'404.html'), layout(cfg, '404', '<h1>404</h1><p>Page not found</p>'));
  for (const t of tags) {
    const arr = posts.filter(p=>p.tags.includes(t)); const s = slugify(t);
    fs.writeFileSync(path.join(output,`tag-${s}.html`), listPage(cfg, `Posts tagged with '${t}'`, arr));
    fs.writeFileSync(path.join(output,`tag-${s}-1.html`), fs.readFileSync(path.join(output,`tag-${s}.html`)));
    fs.writeFileSync(path.join(output,`tag-${s}.rss`), rss(cfg, `tag: ${t}`, arr, `tag-${s}`));
  }
  for (const y of years) {
    const arr = posts.filter(p=>p.date && p.date.getUTCFullYear() === y);
    fs.writeFileSync(path.join(output,`archive-${y}.html`), listPage(cfg, `Posts from '${y}'`, arr));
    fs.writeFileSync(path.join(output,`archive-${y}-1.html`), fs.readFileSync(path.join(output,`archive-${y}.html`)));
    fs.writeFileSync(path.join(output,`archive-${y}.rss`), rss(cfg, `year: ${y}`, arr, `archive-${y}`));
  }
  fs.writeFileSync(path.join(output,'index.rss'), rss(cfg, cfg.name, posts, 'index'));
  const urls = urlsObject(cfg, posts, pages, tags, years);
  if (cfg.publish_urls_json) fs.writeFileSync(path.join(output,'urls.json'), JSON.stringify(urls, null, 2));
  if (cfg.build_sitemap) fs.writeFileSync(path.join(output,'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${Object.values(urls).filter(Array.isArray).flat().map(u=>`  <url>\n    <loc>${esc(u)}</loc>\n  </url>`).join('\n')}\n</urlset>`);
  fs.writeFileSync(path.join(output,'robots.txt'), 'User-agent: *\nAllow: /\n');
  fs.writeFileSync(path.join(output,'marmite.json'), JSON.stringify({marmite_version: VERSION, posts: posts.length, pages: pages.length, generated_at: new Date().toString(), timestamp: Math.floor(Date.now()/1000), elapsed_time: 0, config: cfg}, null, 2));
  writeStatic(output);
  return {cfg, posts, pages, tags, years, urls};
}

function configYaml() {
  return `name: Home
tagline: ''
url: ''
https: null
footer: ${DEFAULT_FOOTER}
language: ''
pagination: 10
pages_title: Pages
tags_title: Tags
tags_content_title: Posts tagged with '$tag'
archives_title: Archive
archives_content_title: Posts from '$year'
streams_title: Streams
streams_content_title: Posts from '$stream'
series_title: Series
series_content_title: Posts from '$series' series
default_author: ''
authors_title: Authors
enable_search: false
enable_related_content: false
search_title: ''
content_path: content
site_path: ''
templates_path: templates
static_path: static
media_path: media
default_date_format: '%b %e, %Y'
menu:
- - Tags
  - tags.html
- - Archive
  - archive.html
- - Authors
  - authors.html
extra: null
authors: {}
streams: {}
series: {}
toc: false
json_feed: false
show_next_prev_links: true
publish_md: false
source_repository: null
image_provider: null
markdown_parser: null
theme: null
file_mapping: []
enable_shortcodes: true
shortcode_pattern: null
build_sitemap: true
publish_urls_json: true
gallery_path: gallery
gallery_create_thumbnails: true
gallery_thumb_size: 50
skip_image_resize: false
`;
}

function initSite(input) {
  fs.mkdirSync(path.join(input,'content'), {recursive:true});
  fs.writeFileSync(path.join(input,'marmite.yaml'), configYaml());
  const today = new Date().toISOString().slice(0,10);
  fs.writeFileSync(path.join(input,'content',`${today}-welcome.md`), `---\ntitle: Welcome\ndate: ${today}\ntags: [marmite]\n---\n# Welcome\n\nThis is your first Marmite post.\n`);
  fs.writeFileSync(path.join(input,'content','about.md'), '---\ntitle: About\npage: true\n---\n# About\n\nAbout this site.\n');
  fs.writeFileSync(path.join(input,'content','_404.md'), '# 404\n');
  for (const name of ['_announce.md','_comments.md','_hero.md','_markdown_footer.md','_markdown_header.md','_references.md','_sidebar.example.md']) {
    fs.writeFileSync(path.join(input,'content',name), '');
  }
  fs.writeFileSync(path.join(input,'custom.css'), '');
  fs.writeFileSync(path.join(input,'custom.js'), '');
}

function newPost(input, opts) {
  const title = opts.new;
  const today = new Date().toISOString().slice(0,10);
  const slug = slugify(title);
  const dir = fs.existsSync(path.join(input, 'content')) ? path.join(input,'content') : input;
  fs.mkdirSync(dir, {recursive:true});
  const file = path.join(dir, `${opts.page ? slug : `${today}-${slug}`}.md`);
  const tags = opts.tags ? `[${opts.tags.split(',').map(s=>s.trim()).filter(Boolean).join(', ')}]` : '[]';
  fs.writeFileSync(file, `---\ntitle: ${title}\n${opts.page ? 'page: true\n' : `date: ${today}\ntags: ${tags}\n`}---\n# ${title}\n\n`);
  console.log(file);
}

function shortcodes() {
  console.log(`Shortcodes:
Enabled: true
Pattern: <!-- \\.(\\w+)(?:\\s+([^-][\\s\\S]*?))?\\s*-->

Reusable blocks of content that can be used in your markdown files.
================
Examples based on your configuration:
  <!-- .youtube -->
  <!-- .youtube param=value -->
  <!-- .gallery -->
  <!-- .gallery param=value -->
  <!-- .card -->
  <!-- .card param=value -->

Available shortcodes:
  - authors: Display a list of all authors with post counts. Params: ord=desc, items=0
  - card: Display a card for content based on slug with optional parameter overrides
  - gallery: Display a gallery of images
  - pages: Display a list of all pages. Params: ord=asc, items=0
  - posts: Display a list of recent posts. Params: ord=desc, items=10
  - series: Display a list of all content series with post counts. Params: ord=desc, items=0
  - socials: Display social network links
  - spotify: Embed Spotify content with custom dimensions
  - streams: Display a list of all content streams with post counts. Params: ord=desc, items=0
  - tags: Display a list of all tags with post counts. Params: ord=desc, items=0
  - toc: Display table of contents for the current content
  - youtube: Embed a YouTube video`);
}

function serve(dir, bind) {
  const [host, portStr] = bind.includes(':') ? bind.split(':') : ['0.0.0.0', bind];
  const port = parseInt(portStr || '8000', 10);
  http.createServer((req,res)=>{
    let p = decodeURIComponent(req.url.split('?')[0]);
    if (p === '/') p = '/index.html';
    const f = path.join(dir, p);
    if (!f.startsWith(path.resolve(dir))) { res.writeHead(403); return res.end('Forbidden'); }
    fs.readFile(f, (err,data)=>{ if(err){res.writeHead(404);res.end('Not found');} else {res.end(data);} });
  }).listen(port, host === '0.0.0.0' ? undefined : host, () => console.log(`Serving ${dir} at http://${host}:${port}`));
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) return console.log(usage());
  if (opts.version) return console.log(`marmite ${VERSION}`);
  if (!opts.input) die(`error: the following required arguments were not provided:\n  <INPUT_FOLDER>\n\nUsage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nFor more information, try '--help'.`);
  const input = path.resolve(opts.input);
  if (opts.generateConfig) { fs.mkdirSync(input,{recursive:true}); fs.writeFileSync(path.join(input,'marmite.yaml'), configYaml()); console.error(`[${new Date().toISOString()} INFO  marmite::config] Config file generated: ${path.join(input,'marmite.yaml')}`); return; }
  if (opts.initSite) { fs.mkdirSync(input,{recursive:true}); initSite(input); console.error(`[${new Date().toISOString()} INFO  marmite::site] Site initialized in ${input}`); return; }
  if (opts.new) return newPost(input, opts);
  if (!fs.existsSync(input)) { console.error(`[${new Date().toISOString()} ERROR marmite] Input folder does not exist: "${input}"`); process.exit(1); }
  if (opts.shortcodes) return shortcodes();
  const output = path.resolve(opts.output || path.join(input, 'site'));
  const result = build(input, output, opts);
  if (opts.showUrls) console.log(JSON.stringify(result.urls, null, 2));
  if (opts.serve || opts.watch) serve(output, opts.bind);
}
main();
