#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const voidTags = new Set(["area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"]);
const blockTags = new Set(["address","article","aside","blockquote","body","center","dd","details","dialog","div","dl","dt","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hr","html","li","main","nav","ol","p","pre","section","table","tbody","td","tfoot","th","thead","tr","ul"]);

function parseArgs(argv) {
  const opts = { input: null, output: null, overwrite: false, domain: "", strong: "**", strike: false, table: false, include: [], exclude: [], headerPromotion: false };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    const next = () => {
      if (i + 1 >= argv.length) die(`missing value for ${a}`);
      return argv[++i];
    };
    if (a === "--help") opts.help = true;
    else if (a === "-v" || a === "--version") opts.version = true;
    else if (a === "--input") opts.input = next();
    else if (a.startsWith("--input=")) opts.input = a.slice(8);
    else if (a === "--output") opts.output = next();
    else if (a.startsWith("--output=")) opts.output = a.slice(9);
    else if (a === "--output-overwrite") opts.overwrite = true;
    else if (a === "--domain") opts.domain = next();
    else if (a.startsWith("--domain=")) opts.domain = a.slice(9);
    else if (a === "--exclude-selector") opts.exclude.push(next());
    else if (a.startsWith("--exclude-selector=")) opts.exclude.push(a.slice(19));
    else if (a === "--include-selector") opts.include.push(next());
    else if (a.startsWith("--include-selector=")) opts.include.push(a.slice(19));
    else if (a === "--opt-strong-delimiter") opts.strong = next();
    else if (a.startsWith("--opt-strong-delimiter=")) opts.strong = a.slice(23);
    else if (a === "--plugin-strikethrough") opts.strike = true;
    else if (a === "--plugin-table") opts.table = true;
    else if (a === "--opt-table-header-promotion") opts.headerPromotion = true;
    else if (a.startsWith("--opt-table-")) {
      if (!a.includes("=") && i + 1 < argv.length && !argv[i + 1].startsWith("-")) i++;
    } else if (a.startsWith("-")) {
      console.error(`\nerror: unknown flag: ${a}\n`);
      process.exit(1);
    } else {
      opts.input = a;
    }
  }
  if (opts.strong !== "**" && opts.strong !== "__") opts.strong = "**";
  return opts;
}

function help() {
  return `
# html2markdown - convert html to markdown [version dev]

Convert HTML to Markdown. Even works with entire websites!

## Flags

    -v, --version
        show the version of html2markdown and exit

    --help

    --input PATH
        Input file, directory, or glob pattern (instead of stdin)

    --output PATH
        Output file or directory (instead of stdout)

    --output-overwrite
        Replace existing files

    --domain
        The url of the web page, used to convert relative links to absolute links.

    --exclude-selector
        css query selector to exclude parts of the input

    --include-selector
        css query selector to only include parts of the input

    --opt-strong-delimiter
        "**" or "__" (default: "**")

    --plugin-strikethrough
        enable the plugin ~~strikethrough~~

    --plugin-table
        enable the plugin table
`;
}

function version() {
  return `html2markdown

GitVersion:  dev
GitCommit:   none
BuildDate:   unknown
`;
}

function die(msg) {
  console.error(`\nerror: ${msg}\n`);
  process.exit(1);
}

function decodeEntities(s) {
  const named = { amp: "&", quot: "\"", apos: "'", nbsp: " ", copy: "(c)", reg: "(r)", trade: "(tm)", mdash: "-", ndash: "-", hellip: "...", lt: "&lt;", gt: "&gt;" };
  return s.replace(/&(#x[0-9a-fA-F]+|#[0-9]+|[a-zA-Z][a-zA-Z0-9]+);?/g, (m, e) => {
    if (e[0] === "#") {
      const n = e[1] && e[1].toLowerCase() === "x" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(n) ? String.fromCodePoint(n) : m;
    }
    return Object.prototype.hasOwnProperty.call(named, e) ? named[e] : m;
  });
}

function parseAttrs(s) {
  const attrs = {};
  const re = /([^\s"'=<>\/]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g;
  let m;
  while ((m = re.exec(s))) attrs[m[1].toLowerCase()] = decodeEntities(m[2] ?? m[3] ?? m[4] ?? "");
  return attrs;
}

function parseHTML(html) {
  const root = { type: "root", tag: "root", attrs: {}, children: [] };
  const stack = [root];
  let i = 0;
  while (i < html.length) {
    const lt = html.indexOf("<", i);
    if (lt < 0) {
      addText(html.slice(i));
      break;
    }
    if (lt > i) addText(html.slice(i, lt));
    if (html.startsWith("<!--", lt)) {
      const end = html.indexOf("-->", lt + 4);
      i = end < 0 ? html.length : end + 3;
      continue;
    }
    if (/^<!\[CDATA\[/i.test(html.slice(lt))) {
      const end = html.indexOf("]]>", lt + 9);
      addText(end < 0 ? html.slice(lt + 9) : html.slice(lt + 9, end));
      i = end < 0 ? html.length : end + 3;
      continue;
    }
    const gt = html.indexOf(">", lt + 1);
    if (gt < 0) {
      addText(html.slice(lt));
      break;
    }
    let raw = html.slice(lt + 1, gt).trim();
    i = gt + 1;
    if (!raw || raw[0] === "!" || raw[0] === "?") continue;
    if (raw[0] === "/") {
      const tag = raw.slice(1).trim().split(/\s+/)[0].toLowerCase();
      for (let j = stack.length - 1; j > 0; j--) {
        if (stack[j].tag === tag) {
          stack.length = j;
          break;
        }
      }
      continue;
    }
    const self = raw.endsWith("/");
    if (self) raw = raw.slice(0, -1).trim();
    const sp = raw.search(/\s/);
    const tag = (sp < 0 ? raw : raw.slice(0, sp)).toLowerCase();
    const attrRaw = sp < 0 ? "" : raw.slice(sp + 1);
    const node = { type: "element", tag, attrs: parseAttrs(attrRaw), children: [] };
    stack[stack.length - 1].children.push(node);
    if (tag === "script" || tag === "style") {
      const close = new RegExp(`</${tag}\\s*>`, "i").exec(html.slice(i));
      i = close ? i + close.index + close[0].length : html.length;
    } else if (!self && !voidTags.has(tag)) stack.push(node);
  }
  function addText(t) {
    if (t) stack[stack.length - 1].children.push({ type: "text", text: decodeEntities(t) });
  }
  return root;
}

function matches(node, sel) {
  if (!node || node.type !== "element") return false;
  sel = sel.trim();
  if (!sel) return false;
  if (sel[0] === "#") return node.attrs.id === sel.slice(1);
  if (sel[0] === ".") return (` ${node.attrs.class || ""} `).includes(` ${sel.slice(1)} `);
  const mm = sel.match(/^([a-zA-Z0-9_-]+)?(?:#([a-zA-Z0-9_-]+))?(?:\.([a-zA-Z0-9_-]+))?$/);
  if (!mm) return false;
  if (mm[1] && node.tag !== mm[1].toLowerCase()) return false;
  if (mm[2] && node.attrs.id !== mm[2]) return false;
  if (mm[3] && !(` ${node.attrs.class || ""} `).includes(` ${mm[3]} `)) return false;
  return true;
}

function filterTree(root, opts) {
  function clone(n) {
    if (n.type === "text") return n;
    if (opts.exclude.some(s => matches(n, s))) return null;
    return { ...n, children: n.children.map(clone).filter(Boolean) };
  }
  let r = clone(root);
  if (opts.include.length) {
    const found = [];
    walk(r, n => { if (opts.include.some(s => matches(n, s))) found.push(n); });
    r = { type: "root", tag: "root", attrs: {}, children: found };
  }
  return r;
}

function walk(n, fn) {
  fn(n);
  if (n.children) n.children.forEach(c => walk(c, fn));
}

function normalizeInline(s) {
  return s.replace(/[ \t\r\n]+/g, " ");
}

function escapeText(s) {
  return s
    .replace(/\\/g, "\\\\")
    .replace(/\*\*/g, "\\*\\*")
    .replace(/__/g, "\\_\\_")
    .replace(/`/g, "\\`")
    .replace(/^\s*([#>*+-]|\d+[.)])\s/gm, "\\$1 ")
    .replace(/^(\s*)([-=]{1,3})\s*$/gm, "$1\\$2");
}

function absUrl(u, domain) {
  if (!u || !domain || /^[a-z][a-z0-9+.-]*:/i.test(u) || u.startsWith("#") || u.startsWith("mailto:")) return u || "";
  try { return new URL(u, domain).toString(); } catch { return u; }
}

function render(root, opts) {
  const ctx = { opts, list: [], inPre: false };
  return cleanBlock(renderChildren(root, ctx)).trim() + "\n";
}

function renderChildren(node, ctx) {
  return (node.children || []).map(c => renderNode(c, ctx)).join("");
}

function inlineChildren(node, ctx) {
  return renderChildren(node, ctx).replace(/[ \t\r]+(?!\n)/g, " ").trim();
}

function cleanBlock(s) {
  return s.replace(/\n{3,}/g, "\n\n");
}

function renderNode(n, ctx) {
  if (n.type === "text") return ctx.inPre ? n.text : escapeText(normalizeInline(n.text));
  const tag = n.tag;
  if (tag === "script" || tag === "style" || tag === "head" || tag === "title" || tag === "meta") return "";
  if (/^h[1-6]$/.test(tag)) return "\n\n" + "#".repeat(Number(tag[1])) + " " + inlineChildren(n, ctx) + "\n\n";
  if (tag === "p") return "\n\n" + inlineChildren(n, ctx) + "\n\n";
  if (tag === "br") return "  \n";
  if (tag === "hr") return "\n\n* * *\n\n";
  if (tag === "strong" || tag === "b") return ctx.opts.strong + inlineChildren(n, ctx) + ctx.opts.strong;
  if (tag === "em" || tag === "i") return "*" + inlineChildren(n, ctx) + "*";
  if (tag === "code") {
    const t = textContent(n);
    if (ctx.inPre) return t;
    const ticks = t.includes("`") ? "``" : "`";
    return ticks + t + ticks;
  }
  if (tag === "pre") {
    const old = ctx.inPre; ctx.inPre = true;
    let t = textContent(n).replace(/^\n+|\n+$/g, "");
    ctx.inPre = old;
    return "\n\n```\n" + t + "\n```\n\n";
  }
  if (tag === "a") {
    const label = inlineChildren(n, ctx) || n.attrs.href || "";
    const href = absUrl(n.attrs.href || "", ctx.opts.domain);
    return href ? `[${label}](${href})` : label;
  }
  if (tag === "img") return `![${escapeText(n.attrs.alt || "")}](${absUrl(n.attrs.src || "", ctx.opts.domain)})`;
  if ((tag === "del" || tag === "s" || tag === "strike") && ctx.opts.strike) return "~~" + inlineChildren(n, ctx) + "~~";
  if (tag === "blockquote") {
    const body = cleanBlock(renderChildren(n, ctx)).trim().split("\n").map(line => line ? `> ${line}` : "> ").join("\n");
    return "\n\n" + body + "\n\n";
  }
  if (tag === "ul" || tag === "ol") {
    ctx.list.push({ tag, index: 1 });
    const out = "\n\n" + (n.children || []).filter(c => c.type === "element" && c.tag === "li").map(li => renderLi(li, ctx)).join("");
    ctx.list.pop();
    return out + "\n";
  }
  if (tag === "li") return renderLi(n, ctx);
  if (tag === "table" && ctx.opts.table) return renderTable(n, ctx);
  if (tag === "tr" || tag === "td" || tag === "th" || tag === "tbody" || tag === "thead" || tag === "tfoot") return renderChildren(n, ctx);
  if (blockTags.has(tag)) return "\n\n" + cleanBlock(renderChildren(n, ctx)).trim() + "\n\n";
  return renderChildren(n, ctx);
}

function renderLi(n, ctx) {
  const level = Math.max(0, ctx.list.length - 1);
  const list = ctx.list[ctx.list.length - 1] || { tag: "ul", index: 1 };
  const marker = list.tag === "ol" ? `${list.index++}. ` : "- ";
  const nested = [];
  const inlineKids = [];
  for (const c of n.children || []) {
    if (c.type === "element" && (c.tag === "ul" || c.tag === "ol")) nested.push(c);
    else inlineKids.push(c);
  }
  const fake = { children: inlineKids };
  let body = cleanBlock(renderChildren(fake, ctx)).trim();
  const indent = "  ".repeat(level);
  let out = indent + marker + body.replace(/\n/g, "\n" + indent + "  ") + "\n";
  for (const child of nested) out += "\n" + renderNode(child, ctx).trimEnd() + "\n";
  return out;
}

function textContent(n) {
  if (n.type === "text") return n.text;
  return (n.children || []).map(textContent).join("");
}

function findAll(n, tags, out = []) {
  if (n.type === "element" && tags.has(n.tag)) out.push(n);
  (n.children || []).forEach(c => findAll(c, tags, out));
  return out;
}

function renderTable(n, ctx) {
  if ((n.attrs.role || "").toLowerCase() === "presentation" && !ctx.opts.presentationTables) {
    return "\n\n" + findAll(n, new Set(["td","th"])).map(c => inlineChildren(c, ctx)).join("\n") + "\n\n";
  }
  const rows = findAll(n, new Set(["tr"])).map(tr => (tr.children || []).filter(c => c.type === "element" && (c.tag === "td" || c.tag === "th")));
  if (!rows.length) return "";
  const width = Math.max(...rows.map(r => r.length));
  const cells = rows.map(r => Array.from({ length: width }, (_, i) => inlineChildren(r[i] || { children: [] }, ctx).replace(/\n/g, "<br>")));
  let header = rows[0].some(c => c.tag === "th") || ctx.opts.headerPromotion;
  if (!header) return "\n\n" + cells.map(r => r.join(" ")).join("\n") + "\n\n";
  const lens = Array.from({ length: width }, (_, i) => Math.max(1, ...cells.map(r => (r[i] || "").length)));
  const row = r => "| " + r.map((c, i) => c + " ".repeat(lens[i] - c.length)).join(" | ") + " |";
  const sep = "|" + lens.map(l => "-".repeat(l + 2)).join("|") + "|";
  return "\n\n" + [row(cells[0]), sep, ...cells.slice(1).map(row)].join("\n") + "\n\n";
}

function convert(html, opts) {
  return render(filterTree(parseHTML(html), opts), opts);
}

function expandInputs(pattern) {
  if (!pattern) return [];
  if (!/[?*[\]]/.test(pattern)) {
    const st = fs.statSync(pattern);
    if (st.isDirectory()) return fs.readdirSync(pattern).filter(f => /\.html?$/i.test(f)).map(f => path.join(pattern, f)).sort();
    return [pattern];
  }
  const dir = path.dirname(pattern);
  const base = path.basename(pattern).replace(/[.+^${}()|\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
  const re = new RegExp("^" + base + "$");
  return fs.readdirSync(dir === "." ? "." : dir).filter(f => re.test(f)).map(f => path.join(dir, f)).sort();
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) return process.stdout.write(help());
  if (opts.version) return process.stdout.write(version());
  if (!opts.input) {
    const input = fs.readFileSync(0, "utf8");
    const out = convert(input, opts);
    if (opts.output) writeOut(opts.output, out, opts);
    else process.stdout.write(out);
    return;
  }
  const files = expandInputs(opts.input);
  if (files.length > 1) {
    if (!opts.output) die("output must be a directory when input is a directory or glob pattern");
    fs.mkdirSync(opts.output, { recursive: true });
    for (const f of files) {
      const outPath = path.join(opts.output, path.basename(f).replace(/\.[^.]*$/, ".md"));
      writeOut(outPath, convert(fs.readFileSync(f, "utf8"), opts), opts);
    }
  } else {
    const out = convert(fs.readFileSync(files[0], "utf8"), opts);
    if (opts.output) writeOut(opts.output, out, opts);
    else process.stdout.write(out);
  }
}

function writeOut(p, data, opts) {
  if (fs.existsSync(p) && !opts.overwrite) die(`output file already exists: ${p}`);
  fs.writeFileSync(p, data);
}

main();
