#!/usr/bin/env node
'use strict';

const fs = require('fs');

const HELP = `Usage: ./executable [-][ytjcrneikhv]

Convert between YAML, TOML, JSON, and HCL.
Preserves map order.

-x[x]  Convert using stdin. Valid options:
          -yj, -y = YAML to JSON (default)
          -yy     = YAML to YAML
          -yt     = YAML to TOML
          -yc     = YAML to HCL
          -tj, -t = TOML to JSON
          -ty     = TOML to YAML
          -tt     = TOML to TOML
          -tc     = TOML to HCL
          -jj     = JSON to JSON
          -jy, -r = JSON to YAML
          -jt     = JSON to TOML
          -jc     = JSON to HCL
          -cy     = HCL to YAML
          -ct     = HCL to TOML
          -cj, -c = HCL to JSON
          -cc     = HCL to HCL
-n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)
-e     Escape HTML (JSON out only)
-i     Indent output (JSON or TOML out only)
-k     Attempt to parse keys as objects or numeric types (YAML out only)
-h     Show this help message
-v     Show version`;

function die(msg) { console.log(HELP); console.log(); console.log('Error: ' + msg); process.exit(1); }
function version() { console.log('v0.0.0'); process.exit(0); }

function parseFlags(argv) {
  let chars = '';
  for (const a of argv) {
    if (a === '-h' || a === 'h') { console.log(HELP); process.exit(0); }
    if (a === '-v' || a === 'v') version();
    if (a.startsWith('-')) chars += a.slice(1); else chars += a;
  }
  if (!chars) chars = 'y';
  const valid = new Set('ytjcrneikhv'.split(''));
  const bad = [...chars].filter(c => !valid.has(c));
  if (bad.length) die('invalid flags specified: ' + bad.join(' '));
  if (chars.includes('h')) { console.log(HELP); process.exit(0); }
  if (chars.includes('v')) version();
  const opts = { noStringSpecial:false, escapeHtml:false, indent:false, keyParse:false };
  for (const c of chars) {
    if (c === 'n') opts.noStringSpecial = true;
    if (c === 'e') opts.escapeHtml = true;
    if (c === 'i') opts.indent = true;
    if (c === 'k') opts.keyParse = true;
  }
  const convChars = [...chars].filter(c => 'ytjcr'.includes(c));
  let from = 'y', to = 'j';
  if (convChars.length === 1) {
    const c = convChars[0];
    if (c === 'y') { from = 'y'; to = 'j'; }
    if (c === 't') { from = 't'; to = 'j'; }
    if (c === 'j') { from = 'j'; to = 'j'; }
    if (c === 'c') { from = 'c'; to = 'j'; }
    if (c === 'r') { from = 'j'; to = 'y'; }
  } else if (convChars.length >= 2) {
    from = convChars[0]; to = convChars[1];
    if (from === 'r') from = 'j';
    if (to === 'r') to = 'y';
  }
  const ok = new Set(['yj','yy','yt','yc','tj','ty','tt','tc','jj','jy','jt','jc','cy','ct','cj','cc']);
  if (!ok.has(from + to)) die('invalid conversion specified');
  if (opts.indent && !'jt'.includes(to)) die('flag -i only valid for JSON or TOML output');
  return { from, to, opts };
}

function stripComment(s) {
  let q = null, out = '';
  for (let i=0;i<s.length;i++) {
    const ch = s[i];
    if (q) { out += ch; if (ch === q && s[i-1] !== '\\') q = null; }
    else if (ch === '"' || ch === "'") { q = ch; out += ch; }
    else if (ch === '#') break;
    else out += ch;
  }
  return out;
}

function parseScalar(s) {
  s = String(s).trim();
  if (s === '') return '';
  if ((s[0] === '"' && s.at(-1) === '"') || (s[0] === "'" && s.at(-1) === "'")) {
    if (s[0] === '"') { try { return JSON.parse(s); } catch {} }
    return s.slice(1,-1);
  }
  if (s === 'true') return true; if (s === 'false') return false;
  if (['null','~'].includes(s)) return null;
  if (/^[-+]?\.?(inf|Inf|INF)$/.test(s) || /^[-+]?(nan|NaN|NAN)$/.test(s)) return s;
  if (/^[-+]?\d+(\.\d+)?([eE][-+]?\d+)?$/.test(s)) return Number(s);
  if ((s[0] === '[' && s.at(-1) === ']') || (s[0] === '{' && s.at(-1) === '}')) return parseInline(s);
  return s;
}

function splitTop(s, sep=',') {
  const parts=[]; let cur='', depth=0, q=null;
  for (let i=0;i<s.length;i++) {
    const ch=s[i];
    if (q) { cur+=ch; if (ch===q && s[i-1] !== '\\') q=null; }
    else if (ch==='"'||ch==="'") { q=ch; cur+=ch; }
    else if (ch==='['||ch==='{') { depth++; cur+=ch; }
    else if (ch===']'||ch==='}') { depth--; cur+=ch; }
    else if (ch===sep && depth===0) { parts.push(cur.trim()); cur=''; }
    else cur+=ch;
  }
  if (cur.trim() || s.trim()==='') parts.push(cur.trim());
  return parts.filter(p => p.length || s.trim()==='');
}
function parseInline(s) {
  s=s.trim();
  if (s[0] === '[') {
    const inner=s.slice(1,-1).trim(); if (!inner) return [];
    return splitTop(inner).map(parseScalar);
  }
  const inner=s.slice(1,-1).trim(); const o={}; if (!inner) return o;
  for (const p of splitTop(inner)) {
    const idx = topIndex(p, ':') >= 0 ? topIndex(p, ':') : topIndex(p, '=');
    if (idx >= 0) o[cleanKey(p.slice(0,idx))] = parseScalar(p.slice(idx+1));
  }
  return o;
}
function topIndex(s, target) { let depth=0,q=null; for(let i=0;i<s.length;i++){const ch=s[i]; if(q){if(ch===q&&s[i-1] !== '\\')q=null;} else if(ch==='"'||ch==="'")q=ch; else if(ch==='['||ch==='{')depth++; else if(ch===']'||ch==='}')depth--; else if(ch===target&&depth===0)return i;} return -1; }
function cleanKey(k) { k=k.trim(); if ((k[0]==='"'&&k.at(-1)==='"')||(k[0]==="'"&&k.at(-1)==="'")) return parseScalar(k); return k; }

function yamlLines(input) {
  return input.replace(/\r/g,'').split('\n').map(raw => ({raw, indent:(raw.match(/^ */)||[''])[0].length, text:stripComment(raw).trim()})).filter(l => l.text && l.text !== '---' && l.text !== '...');
}
function parseYaml(input) {
  const lines = yamlLines(input); let i=0;
  function node(indent) {
    if (i >= lines.length) return {};
    if (lines[i].indent < indent) return {};
    if (lines[i].text.startsWith('- ')) return arr(indent);
    return obj(indent);
  }
  function arr(indent) {
    const a=[];
    while (i<lines.length && lines[i].indent===indent && lines[i].text.startsWith('- ')) {
      let rest=lines[i].text.slice(2).trim(); i++;
      if (!rest) a.push(node(indent+2));
      else if (/^[^:]+:\s*/.test(rest) && !rest.startsWith('{')) {
        const o={}; assignYaml(o, rest, indent+2);
        while (i<lines.length && lines[i].indent>=indent+2 && !lines[i].text.startsWith('- ')) {
          if (lines[i].indent===indent+2) { assignYaml(o, lines[i].text, indent+4); i++; }
          else break;
        }
        a.push(o);
      } else a.push(parseScalar(rest));
    }
    return a;
  }
  function obj(indent) {
    const o={};
    while (i<lines.length && lines[i].indent===indent && !lines[i].text.startsWith('- ')) {
      const text=lines[i].text; i++; assignYaml(o, text, indent+2);
    }
    return o;
  }
  function assignYaml(o, text, childIndent) {
    const idx=topIndex(text, ':'); if (idx<0) return;
    const key=cleanKey(text.slice(0,idx)); const val=text.slice(idx+1).trim();
    o[key] = val ? parseScalar(val) : node(childIndent);
  }
  return node(lines[0]?.indent || 0);
}

function parseToml(input) {
  const root={}; let cur=root;
  for (let raw of input.replace(/\r/g,'').split('\n')) {
    let line=stripComment(raw).trim(); if(!line) continue;
    let m=line.match(/^\[\[\s*([^\]]+)\s*\]\]$/);
    if (m) { const path=m[1].split('.').map(cleanKey); let p=root; for(let j=0;j<path.length-1;j++) p=p[path[j]] ||= {}; const k=path.at(-1); (p[k] ||= []).push({}); cur=p[k].at(-1); continue; }
    m=line.match(/^\[\s*([^\]]+)\s*\]$/);
    if (m) { cur=root; for(const part of m[1].split('.').map(cleanKey)) cur=cur[part] ||= {}; continue; }
    const idx=topIndex(line,'='); if(idx>=0) cur[cleanKey(line.slice(0,idx))]=parseScalar(line.slice(idx+1));
  }
  return root;
}

function parseHcl(input) {
  const root={}; const stack=[root];
  const lines=input.replace(/\r/g,'').split('\n');
  for (let raw of lines) {
    let line=stripComment(raw).trim(); if(!line) continue;
    if (line === '}') { if(stack.length>1) stack.pop(); continue; }
    if (line.endsWith('{')) {
      let head=line.slice(0,-1).trim(); const parts=head.match(/"[^"]*"|'[^']*'|\S+/g)||[];
      const name=cleanKey(parts[0]||''); let obj={}; let cur=stack.at(-1);
      if (parts.length > 1) {
        cur[name] ||= {}; let p=cur[name];
        for(let i=1;i<parts.length;i++){ const lab=cleanKey(parts[i]); if(i===parts.length-1){ p[lab] ||= {}; obj=p[lab]; } else p=p[lab] ||= {}; }
      } else { (cur[name] ||= []).push(obj); }
      stack.push(obj); continue;
    }
    const idx=topIndex(line,'='); if(idx>=0) stack.at(-1)[cleanKey(line.slice(0,idx))]=parseScalar(line.slice(idx+1));
  }
  return root;
}

function q(s) { return JSON.stringify(String(s)); }
function isObj(v) { return v && typeof v === 'object' && !Array.isArray(v); }
function yamlScalar(v, forceQuote=false) { if (v === null) return 'null'; if (typeof v === 'string') return !forceQuote && /^[A-Za-z0-9_.\/-]+$/.test(v) && !/^(true|false|null|~|[-+]?\d)/.test(v) ? v : q(v); return String(v); }
function dumpYaml(v, indent=0) {
  const sp=' '.repeat(indent); let out='';
  if (Array.isArray(v)) for (const item of v) {
    if (isObj(item)) {
      const entries = Object.entries(item);
      if (!entries.length) out += sp + '- {}\n';
      else {
        const [k,val] = entries[0];
        if (isObj(val) || Array.isArray(val)) out += sp + '- ' + k + ':\n' + dumpYaml(val, indent+4);
        else out += sp + '- ' + k + ': ' + yamlScalar(val, true) + '\n';
        for (const [kk,vv] of entries.slice(1)) {
          if (isObj(vv) || Array.isArray(vv)) out += ' '.repeat(indent+2) + kk + ':\n' + dumpYaml(vv, indent+4);
          else out += ' '.repeat(indent+2) + kk + ': ' + yamlScalar(vv, true) + '\n';
        }
      }
    } else if (Array.isArray(item)) out += sp + '- \n' + dumpYaml(item, indent+2);
    else out += sp + '- ' + yamlScalar(item) + '\n';
  } else if (isObj(v)) for (const [k,val] of Object.entries(v)) {
    if (isObj(val) || Array.isArray(val)) out += sp + k + ':\n' + dumpYaml(val, indent+2);
    else out += sp + k + ': ' + yamlScalar(val) + '\n';
  } else out += sp + yamlScalar(v) + '\n';
  return out;
}
function tomlScalar(v) { if (typeof v === 'string') return q(v); if (Array.isArray(v)) return '[' + v.map(tomlScalar).join(', ') + ']'; if (v === null) return '""'; return String(v); }
function dumpToml(obj, indentMode=false) {
  const lines=[];
  function table(o, path) {
    for (const [k,v] of Object.entries(o)) if (!isObj(v) && !(Array.isArray(v)&&v.some(isObj))) lines.push(`${k} = ${tomlScalar(v)}`);
    for (const [k,v] of Object.entries(o)) {
      if (isObj(v)) { lines.push(`[${[...path,k].join('.')}]`); table(v,[...path,k]); }
      else if (Array.isArray(v) && v.some(isObj)) for (const item of v) { lines.push(`[[${[...path,k].join('.')}]]`); table(item,[...path,k]); }
    }
  }
  table(obj,[]);
  if (indentMode) return lines.map(l => l && !l.startsWith('[') ? '  '+l : l).join('\n') + '\n';
  return lines.join('\n') + '\n';
}
function hclScalar(v) { if (typeof v === 'string') return q(v); if (Array.isArray(v) && !v.some(isObj)) return '[' + v.map(hclScalar).join(', ') + ']'; if (v === null) return 'null'; return String(v); }
function dumpHcl(obj, indent=0) {
  const sp=' '.repeat(indent); let out='';
  for (const [k,v] of Object.entries(obj)) {
    if (Array.isArray(v) && v.every(isObj)) { for (const it of v) out += `${sp}${q(k)} = {\n${dumpHcl(it, indent+2)}${sp}}\n\n`; }
    else if (isObj(v)) out += `${sp}${q(k)} = {\n${dumpHcl(v, indent+2)}${sp}}\n\n`;
    else out += `${sp}${q(k)} = ${hclScalar(v)}\n\n`;
  }
  return out.replace(/\n\n$/,'\n');
}

function main() {
  const {from,to,opts}=parseFlags(process.argv.slice(2));
  const input=fs.readFileSync(0,'utf8'); let data;
  try {
    if (from==='j') data=JSON.parse(input || 'null');
    else if (from==='y') data=parseYaml(input);
    else if (from==='t') data=parseToml(input);
    else data=parseHcl(input);
    let out='';
    if (to==='j') { out=JSON.stringify(data,null,opts.indent?2:0); if(opts.escapeHtml) out=out.replace(/[<>&]/g, c => ({'<':'\\u003c','>':'\\u003e','&':'\\u0026'}[c])); out+='\n'; }
    else if (to==='y') out=dumpYaml(data);
    else if (to==='t') out=dumpToml(isObj(data)?data:{value:data}, opts.indent);
    else out=dumpHcl(isObj(data)?data:{value:data});
    process.stdout.write(out);
  } catch (e) { console.error(e && e.message ? e.message : String(e)); process.exit(1); }
}
main();
