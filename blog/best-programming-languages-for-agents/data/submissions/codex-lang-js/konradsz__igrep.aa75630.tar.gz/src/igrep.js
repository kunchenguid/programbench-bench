#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = 'igrep 1.3.0';

const EDITORS = [
  'vim', 'neovim', 'nvim', 'nano', 'code', 'vscode', 'code-insiders',
  'emacs', 'emacsclient', 'hx', 'helix', 'subl', 'sublime-text', 'micro',
  'intellij', 'goland', 'pycharm', 'less', 'fresh',
];
const THEMES = ['light', 'dark'];
const VIEWERS = ['none', 'vertical', 'horizontal'];
const SORTS = ['path', 'modified', 'created', 'accessed'];

function printHelp() {
  process.stdout.write(`Interactive Grep

Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

Arguments:
  <PATTERN>   Regular expression used for searching
  [PATHS]...  Files or directories to search. Directories are searched recursively. If not specified, searching starts from current directory

Options:
      --editor <EDITOR>
          Text editor used to open selected match [possible values: vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh]
      --custom-command <CUSTOM_COMMAND>
          Custom command used to open selected match. Must contain {file_name} and {line_number} tokens [env: IGREP_CUSTOM_EDITOR=]
      --theme <THEME>
          UI color theme [default: dark] [possible values: light, dark]
  -i, --ignore-case
          Searches case insensitively
  -S, --smart-case
          Searches case insensitively if the pattern is all lowercase. Search case sensitively otherwise
  -., --hidden
          Search hidden files and directories. By default, hidden files and directories are skipped
  -L, --follow
          Follow symbolic links while traversing directories
  -w, --word-regexp
          Only show matches surrounded by word boundaries
  -F, --fixed-strings
          Exact matches with no regex. Useful when searching for a string full of delimiters
  -U, --multiline
          Search with pattern contains newline character ('\\n')
  -g, --glob <GLOB>
          Include files and directories for searching that match the given glob. Multiple globs may be provided
      --type-list
          Show all supported file types and their corresponding globs
  -t, --type <TYPE_MATCHING>
          Only search files matching TYPE. Multiple types may be provided
  -T, --type-not <TYPE_NOT>
          Do not search files matching TYPE-NOT. Multiple types-not may be provided
      --context-viewer <CONTEXT_VIEWER>
          Context viewer position at startup [default: none] [possible values: none, vertical, horizontal]
      --sort <SORT_BY>
          Sort results, see ripgrep for details [possible values: path, modified, created, accessed]
      --sortr <SORT_BY_REVERSE>
          Sort results reverse, see ripgrep for details [possible values: path, modified, created, accessed]
  -h, --help
          Print help
  -V, --version
          Print version
`);
}

function usageForErrors() {
  return 'Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...';
}

function exitErr(text, code = 2) {
  process.stderr.write(text);
  process.exit(code);
}

function invalidValue(value, option, metavar, possible) {
  exitErr(`error: invalid value '${value}' for '${option} <${metavar}>'\n  [possible values: ${possible.join(', ')}]\n\nFor more information, try '--help'.\n`);
}

function unexpected(arg) {
  exitErr(`error: unexpected argument '${arg}' found\n\n  tip: to pass '${arg}' as a value, use '-- ${arg}'\n\n${usageForErrors()}\n\nFor more information, try '--help'.\n`);
}

function missingOptionValue(option, metavar) {
  exitErr(`error: a value is required for '${option} <${metavar}>' but none was supplied\n\nFor more information, try '--help'.\n`);
}

function countToken(s, token) {
  return (s.match(new RegExp(token.replace(/[{}]/g, '\\$&'), 'g')) || []).length;
}

function validateCustomCommand(command) {
  if (!command) return;
  if (command.trim().split(/\s+/).length < 2) {
    exitErr(`Error: Incorrect editor command: '${command}'\n\nCaused by:\n    Expected program and its arguments\n`, 1);
  }
  const fileCount = countToken(command, '{file_name}');
  const lineCount = countToken(command, '{line_number}');
  if (fileCount !== 1) {
    exitErr(`Error: Incorrect editor command: '${command}'\n\nCaused by:\n    Expected one occurrence of '{file_name}'.\n`, 1);
  }
  if (lineCount !== 1) {
    exitErr(`Error: Incorrect editor command: '${command}'\n\nCaused by:\n    Expected one occurrence of '{line_number}'.\n`, 1);
  }
}

function loadTypes() {
  return fs.readFileSync(path.join(__dirname, '..', 'type-list.txt'), 'utf8');
}

function typeNames() {
  return new Set(loadTypes().trimEnd().split('\n').map((line) => line.split(':', 1)[0]));
}

function main() {
  const args = process.argv.slice(2);
  if (args.includes('--help') || args.includes('-h')) {
    printHelp();
    return;
  }
  if (args.includes('--version') || args.includes('-V')) {
    process.stdout.write(`${VERSION}\n`);
    return;
  }

  const types = typeNames();
  let typeList = false;
  let pattern = null;
  let afterDashDash = false;
  let customCommand = process.env.IGREP_CUSTOM_EDITOR || '';

  for (let i = 0; i < args.length; i += 1) {
    const arg = args[i];
    if (afterDashDash) {
      if (pattern === null) pattern = arg;
      continue;
    }
    if (arg === '--') {
      afterDashDash = true;
      continue;
    }
    if (arg === '--type-list') {
      typeList = true;
      continue;
    }
    if (arg === '--ignore-case' || arg === '-i' || arg === '--smart-case' || arg === '-S' ||
        arg === '--hidden' || arg === '-.' || arg === '--follow' || arg === '-L' ||
        arg === '--word-regexp' || arg === '-w' || arg === '--fixed-strings' || arg === '-F' ||
        arg === '--multiline' || arg === '-U') {
      continue;
    }
    if (arg === '--editor') {
      const val = args[++i];
      if (val === undefined) missingOptionValue('--editor', 'EDITOR');
      if (!EDITORS.includes(val)) invalidValue(val, '--editor', 'EDITOR', EDITORS);
      continue;
    }
    if (arg === '--theme') {
      const val = args[++i];
      if (val === undefined) missingOptionValue('--theme', 'THEME');
      if (!THEMES.includes(val)) invalidValue(val, '--theme', 'THEME', THEMES);
      continue;
    }
    if (arg === '--context-viewer') {
      const val = args[++i];
      if (val === undefined) missingOptionValue('--context-viewer', 'CONTEXT_VIEWER');
      if (!VIEWERS.includes(val)) invalidValue(val, '--context-viewer', 'CONTEXT_VIEWER', VIEWERS);
      continue;
    }
    if (arg === '--sort' || arg === '--sortr') {
      const metavar = arg === '--sort' ? 'SORT_BY' : 'SORT_BY_REVERSE';
      const val = args[++i];
      if (val === undefined) missingOptionValue(arg, metavar);
      if (!SORTS.includes(val)) invalidValue(val, arg, metavar, SORTS);
      continue;
    }
    if (arg === '--custom-command') {
      const val = args[++i];
      if (val === undefined) missingOptionValue('--custom-command', 'CUSTOM_COMMAND');
      customCommand = val;
      continue;
    }
    if (arg === '--glob' || arg === '-g') {
      if (args[++i] === undefined) missingOptionValue(arg, 'GLOB');
      continue;
    }
    if (arg === '--type' || arg === '-t' || arg === '--type-not' || arg === '-T') {
      const val = args[++i];
      if (val === undefined) missingOptionValue(arg, arg.includes('not') || arg === '-T' ? 'TYPE_NOT' : 'TYPE_MATCHING');
      if (!types.has(val)) exitErr(`Error: unrecognized file type: ${val}\n`, 1);
      continue;
    }
    if (arg.startsWith('--')) unexpected(arg);
    if (arg.startsWith('-') && pattern === null) unexpected(arg);
    if (pattern === null) pattern = arg;
  }

  validateCustomCommand(customCommand);

  if (typeList) {
    if (pattern !== null) {
      exitErr(`error: the argument '--type-list' cannot be used with '<PATTERN>'\n\nUsage: executable --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n`);
    }
    process.stdout.write(loadTypes());
    return;
  }

  if (pattern === null) {
    exitErr(`error: the following required arguments were not provided:\n  --type-list\n  <PATTERN>\n\nUsage: executable --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n`);
  }

  process.stderr.write('Error: Inappropriate ioctl for device (os error 25)\n');
  process.exit(1);
}

main();
