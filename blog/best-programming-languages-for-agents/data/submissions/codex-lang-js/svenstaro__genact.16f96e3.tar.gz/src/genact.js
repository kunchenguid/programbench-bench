#!/usr/bin/env node
'use strict';

const VERSION = '1.5.1';
const MODULES = [
  'ansible', 'bootlog', 'botnet', 'bruteforce', 'cargo', 'cc', 'composer',
  'cryptomining', 'docker_build', 'docker_image_rm', 'download', 'julia',
  'kernel_compile', 'memdump', 'mkinitcpio', 'rkhunter', 'simcity',
  'terraform', 'uv', 'weblog', 'wpt',
];
const SHELLS = ['bash', 'elvish', 'fish', 'powershell', 'zsh'];

let seed = Date.now() ^ process.pid;
function rand() {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 0x100000000;
}
function pick(xs) { return xs[Math.floor(rand() * xs.length)]; }
function int(min, max) { return Math.floor(rand() * (max - min + 1)) + min; }
function hex(n) {
  let s = '';
  for (let i = 0; i < n; i++) s += '0123456789abcdef'[int(0, 15)];
  return s;
}
function ip() { return `${int(1, 223)}.${int(0, 255)}.${int(0, 255)}.${int(1, 254)}`; }

function help() {
  return `A nonsense activity generator

Usage: executable [OPTIONS]

Options:
  -l, --list-modules
          List available modules
  -m, --modules <MODULES>
          Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,
          composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,
          memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]
  -s, --speed-factor <SPEED_FACTOR>
          Global speed factor [default: 1]
  -i, --instant-print-lines <INSTANT_PRINT_LINES>
          Instantly print this many lines [default: 0]
      --inhibit
          Keep the computer awake and the display on while genact is running
      --exit-after-time <EXIT_AFTER_TIME>
          Exit after running for this long (format example: 2h10min)
      --exit-after-modules <EXIT_AFTER_MODULES>
          Exit after running this many modules
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,
          zsh]
      --print-manpage
          Generate man page
  -h, --help
          Print help
  -V, --version
          Print version
`;
}

function listModules() {
  return `Available modules:\n${MODULES.map((m) => `  ${m}`).join('\n')}\n`;
}

function manpage() {
  const modBullets = MODULES.map((m) => `.IP \\(bu 2\n${m}`).join('\n');
  const shellBullets = SHELLS.map((s) => `.IP \\(bu 2\n${s}`).join('\n');
  return `.ie \\n(.g .ds Aq \\(aq
.el .ds Aq '
.TH genact 1  "genact ${VERSION}" 
.SH NAME
genact \\- A nonsense activity generator
.SH SYNOPSIS
\\fBgenact\\fR [\\fB\\-l\\fR|\\fB\\-\\-list\\-modules\\fR] [\\fB\\-m\\fR|\\fB\\-\\-modules\\fR] [\\fB\\-s\\fR|\\fB\\-\\-speed\\-factor\\fR] [\\fB\\-i\\fR|\\fB\\-\\-instant\\-print\\-lines\\fR] [\\fB\\-\\-inhibit\\fR] [\\fB\\-\\-exit\\-after\\-time\\fR] [\\fB\\-\\-exit\\-after\\-modules\\fR] [\\fB\\-\\-print\\-completions\\fR] [\\fB\\-\\-print\\-manpage\\fR] [\\fB\\-h\\fR|\\fB\\-\\-help\\fR] [\\fB\\-V\\fR|\\fB\\-\\-version\\fR] 
.SH DESCRIPTION
A nonsense activity generator
.SH OPTIONS
.TP
\\fB\\-l\\fR, \\fB\\-\\-list\\-modules\\fR
List available modules
.TP
\\fB\\-m\\fR, \\fB\\-\\-modules\\fR \\fI<MODULES>\\fR
Run only these modules
.br

.br
\\fIPossible values:\\fR
.RS 14
${modBullets}
.RE
.TP
\\fB\\-s\\fR, \\fB\\-\\-speed\\-factor\\fR \\fI<SPEED_FACTOR>\\fR [default: 1]
Global speed factor
.TP
\\fB\\-i\\fR, \\fB\\-\\-instant\\-print\\-lines\\fR \\fI<INSTANT_PRINT_LINES>\\fR [default: 0]
Instantly print this many lines
.TP
\\fB\\-\\-inhibit\\fR
Keep the computer awake and the display on while genact is running
.TP
\\fB\\-\\-exit\\-after\\-time\\fR \\fI<EXIT_AFTER_TIME>\\fR
Exit after running for this long (format example: 2h10min)
.TP
\\fB\\-\\-exit\\-after\\-modules\\fR \\fI<EXIT_AFTER_MODULES>\\fR
Exit after running this many modules
.TP
\\fB\\-\\-print\\-completions\\fR \\fI<shell>\\fR
Generate completion file for a shell
.br

.br
\\fIPossible values:\\fR
.RS 14
${shellBullets}
.RE
.TP
\\fB\\-\\-print\\-manpage\\fR
Generate man page
.TP
\\fB\\-h\\fR, \\fB\\-\\-help\\fR
Print help
.TP
\\fB\\-V\\fR, \\fB\\-\\-version\\fR
Print version
.SH VERSION
v${VERSION}
.SH AUTHORS
Sven\\-Hendrik Haase <svenstaro@gmail.com>
`;
}

function completions(shell) {
  if (shell === 'fish') {
    return `complete -c genact -s m -l modules -d 'Run only these modules' -r -f -a "${MODULES.map((m) => `${m}\\t''`).join('\n')}"
complete -c genact -s s -l speed-factor -d 'Global speed factor' -r
complete -c genact -s i -l instant-print-lines -d 'Instantly print this many lines' -r
complete -c genact -l exit-after-time -d 'Exit after running for this long (format example: 2h10min)' -r
complete -c genact -l exit-after-modules -d 'Exit after running this many modules' -r
complete -c genact -l print-completions -d 'Generate completion file for a shell' -r -f -a "${SHELLS.map((s) => `${s}\\t''`).join('\n')}"
complete -c genact -s l -l list-modules -d 'List available modules'
complete -c genact -l inhibit -d 'Keep the computer awake and the display on while genact is running'
complete -c genact -l print-manpage -d 'Generate man page'
complete -c genact -s h -l help -d 'Print help'
complete -c genact -s V -l version -d 'Print version'
`;
  }
  if (shell === 'zsh') return `#compdef genact\n_arguments '*:: :->genact' '-h[Print help]' '--help[Print help]' '-V[Print version]' '--version[Print version]'\n`;
  if (shell === 'powershell') return `using namespace System.Management.Automation\nusing namespace System.Management.Automation.Language\nRegister-ArgumentCompleter -Native -CommandName 'genact' -ScriptBlock { param($wordToComplete) @('-l','--list-modules','-m','--modules','-h','--help','-V','--version') }\n`;
  if (shell === 'elvish') return `edit:completion:arg-completer[genact] = {|@words| put -- -l --list-modules -m --modules -h --help -V --version }\n`;
  return `_genact() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="$2"
    prev="$3"
    cmd="genact"
    opts="-l -m -s -i -h -V --list-modules --modules --speed-factor --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage --help --version"
    case "\${prev}" in
        --modules|-m)
            COMPREPLY=($(compgen -W "${MODULES.join(' ')}" -- "\${cur}"))
            return 0
            ;;
        --print-completions)
            COMPREPLY=($(compgen -W "${SHELLS.join(' ')}" -- "\${cur}"))
            return 0
            ;;
    esac
    COMPREPLY=( $(compgen -W "\${opts}" -- "\${cur}") )
    return 0
}
complete -F _genact -o nosort -o bashdefault -o default genact
`;
}

function die(message) {
  process.stderr.write(message);
  process.exitCode = 2;
}

function possible(kind) {
  const vals = kind === 'shell' ? SHELLS : MODULES;
  return `  [possible values: ${vals.join(', ')}]\n`;
}

function parseDuration(s) {
  let pos = 0, total = 0;
  const re = /(\d+(?:\.\d+)?)(h|hr|hrs|hour|hours|min|m|sec|secs|s|ms|millis|milliseconds)?/gy;
  while (pos < s.length) {
    re.lastIndex = pos;
    const m = re.exec(s);
    if (!m) return null;
    const n = Number(m[1]);
    const unit = m[2] || 's';
    const mult = unit.startsWith('h') ? 3600000 : unit.startsWith('min') || unit === 'm' ? 60000 : unit === 'ms' || unit.startsWith('milli') ? 1 : 1000;
    total += n * mult;
    pos = re.lastIndex;
  }
  return total;
}

function parseArgs(argv) {
  const opt = { modules: [], speed: 1, instant: 0, exitAfterModules: null, exitAfterTime: null, inhibit: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const take = (name) => {
      if (i + 1 >= argv.length) {
        die(`error: a value is required for '${name} <${name.toUpperCase().replace(/^--/, '').replace(/-/g, '_')}>' but none was supplied\n\nFor more information, try '--help'.\n`);
        return null;
      }
      return argv[++i];
    };
    if (a === '-h' || a === '--help') return { action: 'help' };
    if (a === '-V' || a === '--version') return { action: 'version' };
    if (a === '-l' || a === '--list-modules') return { action: 'list' };
    if (a === '--print-manpage') return { action: 'manpage' };
    if (a === '--inhibit') { opt.inhibit = true; continue; }
    if (a === '-m' || a === '--modules') {
      const v = take(a); if (v == null) return null;
      if (!MODULES.includes(v)) {
        die(`error: invalid value '${v}' for '--modules <MODULES>'\n${possible('module')}${v.includes(',') ? "\n  tip: a similar value exists: '" + v.split(',')[0] + "'\n" : ''}\nFor more information, try '--help'.\n`);
        return null;
      }
      opt.modules.push(v); continue;
    }
    if (a === '-s' || a === '--speed-factor') {
      const v = take(a); if (v == null) return null;
      const n = Number(v);
      if (!Number.isFinite(n)) { die(`error: invalid value '${v}' for '--speed-factor <SPEED_FACTOR>': invalid float literal\n\nFor more information, try '--help'.\n`); return null; }
      opt.speed = n; continue;
    }
    if (a === '-i' || a === '--instant-print-lines') {
      const v = take(a); if (v == null) return null;
      if (!/^\d+$/.test(v)) { die(`error: invalid value '${v}' for '--instant-print-lines <INSTANT_PRINT_LINES>': invalid digit found in string\n\nFor more information, try '--help'.\n`); return null; }
      opt.instant = Number(v); continue;
    }
    if (a === '--exit-after-modules') {
      const v = take(a); if (v == null) return null;
      if (!/^\d+$/.test(v)) { die(`error: invalid value '${v}' for '--exit-after-modules <EXIT_AFTER_MODULES>': invalid digit found in string\n\nFor more information, try '--help'.\n`); return null; }
      opt.exitAfterModules = Number(v); continue;
    }
    if (a === '--exit-after-time') {
      const v = take(a); if (v == null) return null;
      const ms = parseDuration(v);
      if (ms == null) { die(`error: invalid value '${v}' for '--exit-after-time <EXIT_AFTER_TIME>': expected number at 0\n\nFor more information, try '--help'.\n`); return null; }
      opt.exitAfterTime = ms; continue;
    }
    if (a === '--print-completions') {
      const v = take(a); if (v == null) return null;
      if (!SHELLS.includes(v)) { die(`error: invalid value '${v}' for '--print-completions <shell>'\n${possible('shell')}\nFor more information, try '--help'.\n`); return null; }
      return { action: 'completions', shell: v };
    }
    die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n`);
    return null;
  }
  return { action: 'run', opt };
}

function ccLine() {
  const dirs = ['drivers/gpu/drm/amd/amdgpu', 'drivers/net/wireless/intel/iwlwifi/pcie', 'arch/x86/kernel', 'arch/arm/kernel', 'fs/xfs/libxfs', 'sound/soc/fsl', 'lib', 'drivers/usb/musb'];
  const objs = ['arch/alpha/kernel/core_titan.o', 'arch/arm/kernel/ptrace.o', 'arch/arm/mm/fault.o', 'drivers/gpu/drm/i915/display.o', 'fs/ext4/inode.o'];
  return `clang -c -Os -Wall -Wextra -Wno-unknown-pragmas -pipe -mtune=generic ${Array.from({length: 9}, () => '-I' + pick(dirs)).join(' ')} -DNDEBUG -D_REENTRANT -o ${pick(objs)}`;
}

function moduleLine(name, i) {
  switch (name) {
    case 'ansible': return pick([`TASK [${pick(['common', 'web', 'db', 'deploy'])} : ${pick(['Gathering Facts', 'Install packages', 'Template config', 'Restart service'])}] ${pick(['ok', 'changed'])}: [${pick(['web01', 'db01', 'cache02'])}]`, `PLAY [${pick(['all', 'webservers', 'database'])}] ${'*'.repeat(70)}`]);
    case 'bootlog': return pick([`${ip()}`, `x86/fpu: Supporting XSAVE feature 0x${hex(3)}: 'SSE registers'`, 'MAC Framework successfully initialized', `usb ${int(1, 5)}-${int(1, 4)}: new high-speed USB device number ${int(2, 9)} using xhci_hcd`]);
    case 'botnet': return `Establishing connections: ${String(i).padStart(4)}/${int(900, 2400)}`;
    case 'bruteforce': return `Trying ${pick(['admin', 'root', 'oracle', 'deploy'])}:${hex(int(5, 10))} on ${ip()} ... ${pick(['failed', 'denied', 'timeout'])}`;
    case 'cargo': return `${pick(['\x1b[1;32m Downloading\x1b[0m', '\x1b[1;32m   Compiling\x1b[0m'])} ${pick(['serde', 'tokio', 'rand', 'openblas', 'farmhash', 'durationfmt'])} v${int(0, 3)}.${int(0, 20)}.${int(0, 12)}`;
    case 'cc': return ccLine();
    case 'composer': return `${pick(['Installing', 'Downloading', 'Updating'])} ${pick(['symfony/console', 'psr/log', 'monolog/monolog', 'doctrine/lexer'])} (${int(1, 4)}.${int(0, 9)}.${int(0, 9)})`;
    case 'cryptomining': return `[${new Date().toISOString().slice(11, 19)}] accepted: ${int(100, 999)}/${int(1000, 9000)} (${(rand() * 80 + 20).toFixed(2)} MH/s) yes!`;
    case 'docker_build': return `Step ${int(1, 14)}/14 : ${pick(['FROM ubuntu:22.04', 'RUN apt-get update', 'COPY . /src', 'RUN make -j8', 'CMD ["app"]'])}`;
    case 'docker_image_rm': return `Untagged: ${pick(['backend', 'frontend', 'postgres', 'redis'])}:${pick(['latest', 'dev', 'old'])}\nDeleted: sha256:${hex(64)}`;
    case 'download': return `${pick(['kernel.tar.xz', 'dataset.bin', 'backup.img'])} ${int(1, 99)}% [${'='.repeat(int(3, 20))}>${' '.repeat(int(1, 10))}] ${int(1, 999)}KB/s`;
    case 'julia': return `[${int(1, 9)}] ${pick(['Precompiling project...', 'Resolving package versions...', 'Building GR -> ~/.julia/packages/GR', 'Testing LinearAlgebra'])}`;
    case 'kernel_compile': return `${pick(['CC', 'LD', 'AR', 'GEN'])} ${pick(['kernel/sched/core.o', 'drivers/net/ethernet/e1000e/netdev.o', 'fs/btrfs/inode.o', 'arch/x86/boot/bzImage'])}`;
    case 'memdump': return `${hex(8)}  ${Array.from({length: 16}, () => hex(2)).join(' ')}  |${Array.from({length: 16}, () => pick('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.'.split(''))).join('')}|`;
    case 'mkinitcpio': return `  -> ${pick(['Running build hook: [base]', 'Generating module dependencies', 'Creating gzip-compressed initcpio image', 'Build complete'])}`;
    case 'rkhunter': return `[${pick([' OK ', 'WARN'])}] ${pick(['Checking system commands', 'Checking for rootkits', 'Performing filesystem checks', 'Checking network ports'])}`;
    case 'simcity': return `${pick(['Building road', 'Zoning residential area', 'Collecting taxes', 'Dispatching fire department'])} at ${int(0, 128)},${int(0, 128)}`;
    case 'terraform': return `${pick(['aws_instance.web', 'module.vpc.aws_subnet.public', 'aws_security_group.app'])}: ${pick(['Refreshing state...', 'Creating...', 'Still creating...', 'Creation complete after ' + int(1, 20) + 's'])}`;
    case 'uv': return `${pick(['Resolved', 'Prepared', 'Installed'])} ${int(1, 87)} packages in ${int(10, 900)}ms`;
    case 'weblog': return `${ip()} - - [${new Date().toUTCString()}] "${pick(['GET', 'POST', 'PUT'])} /${pick(['index.html', 'api/v1/users', 'assets/app.js', 'login'])} HTTP/1.1" ${pick([200, 200, 301, 404, 500])} ${int(100, 9000)}`;
    case 'wpt': return `${pick(['Chrome', 'Firefox', 'Safari'])}: ${pick(['PASS', 'FAIL', 'TIMEOUT'])} ${pick(['css/css-grid/grid-layout.html', 'html/semantics/forms/form-submit.html', 'fetch/api/basic/request.html'])}`;
    default: return `${name}: ${i}`;
  }
}

async function runModules(opt) {
  const mods = opt.modules.length ? opt.modules : MODULES.slice().sort(() => rand() - 0.5);
  const maxModules = opt.exitAfterModules == null ? mods.length : Math.max(0, opt.exitAfterModules);
  const start = Date.now();
  let done = 0;
  for (const m of mods) {
    if (done >= maxModules) break;
    const lines = opt.instant > 0 ? opt.instant : (opt.exitAfterTime != null ? 100000 : 80);
    for (let i = 0; i < lines; i++) {
      if (opt.exitAfterTime != null && Date.now() - start >= opt.exitAfterTime) return;
      const out = moduleLine(m, i);
      for (const line of String(out).split('\n')) process.stdout.write(line + '\n');
      if (opt.instant <= 0) {
        const delay = Math.max(1, Math.min(200, 60 / Math.max(0.01, opt.speed)));
        await new Promise((r) => setTimeout(r, delay));
      }
    }
    process.stdout.write('Saving work to disk...\n');
    done++;
  }
}

async function main() {
  const parsed = parseArgs(process.argv.slice(2));
  if (!parsed) return;
  switch (parsed.action) {
    case 'help': process.stdout.write(help()); return;
    case 'version': process.stdout.write(`genact ${VERSION}\n`); return;
    case 'list': process.stdout.write(listModules()); return;
    case 'manpage': process.stdout.write(manpage()); return;
    case 'completions': process.stdout.write(completions(parsed.shell)); return;
    case 'run': await runModules(parsed.opt); return;
  }
}

main().catch((err) => {
  process.stderr.write(String(err && err.stack || err) + '\n');
  process.exit(1);
});
