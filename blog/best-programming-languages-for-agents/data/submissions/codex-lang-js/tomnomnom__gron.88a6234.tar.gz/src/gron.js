#!/usr/bin/env node
'use strict';

const fs = require('fs');
const http = require('http');
const https = require('https');

const HELP = `Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable

Usage:
  gron [OPTIONS] [FILE|URL|-]

Options:
  -u, --ungron     Reverse the operation (turn assignments back into JSON)
  -v, --values     Print just the values of provided assignments
  -c, --colorize   Colorize output (default on tty)
  -m, --monochrome Monochrome (don't colorize output)
  -s, --stream     Treat each line of input as a separate JSON object
  -k, --insecure   Disable certificate validation
  -x, --proxy      Set proxy configuration
      --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.
  -j, --json       Represent gron data as JSON stream
      --no-sort    Don't sort output (faster)
      --version    Print version information

Exit Codes:
  0\tOK
  1\tFailed to open file
  2\tFailed to read input
  3\tFailed to form statements
  4\tFailed to fetch URL
  5\tFailed to parse statements
  6\tFailed to encode JSON

Examples:
  gron /tmp/apiresponse.json
  gron http://jsonplaceholder.typicode.com/users/1 
  curl -s http://jsonplaceholder.typicode.com/users/1 | gron
  gron http://jsonplaceholder.typicode.com/users/1 | grep company | gron --ungron`;

function usageError(msg) {
  if (msg) process.stderr.write(msg + '\n');
  process.stderr.write(HELP + '\n');
}

function parseArgs(argv) {
  const opts = {
    ungron: false,
    values: false,
    color: process.stdout.isTTY,
    stream: false,
    json: false,
    sort: true,
    insecure: false,
    proxy: null,
    noproxy: null,
    input: null,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-u' || a === '--ungron') opts.ungron = true;
    else if (a === '-v' || a === '--values') opts.values = true;
    else if (a === '-c' || a === '--colorize') opts.color = true;
    else if (a === '-m' || a === '--monochrome') opts.color = false;
    else if (a === '-s' || a === '--stream') opts.stream = true;
    else if (a === '-j' || a === '--json') opts.json = true;
    else if (a === '-k' || a === '--insecure') opts.insecure = true;
    else if (a === '--no-sort') opts.sort = false;
    else if (a === '--version') {
      process.stdout.write('gron version dev\n');
      process.exit(0);
    } else if (a === '-h' || a === '--help') {
      process.stdout.write(HELP + '\n');
      process.exit(0);
    } else if (a === '-x' || a === '--proxy') {
      if (i + 1 >= argv.length) {
        usageError('flag needs an argument: ' + a);
        process.exit(2);
      }
      opts.proxy = argv[++i];
    } else if (a === '--noproxy') {
      if (i + 1 >= argv.length) {
        usageError('flag needs an argument: ' + a);
        process.exit(2);
      }
      opts.noproxy = argv[++i];
    } else if (a.startsWith('-') && a !== '-') {
      usageError('flag provided but not defined: ' + a);
      process.exit(2);
    } else if (opts.input == null) {
      opts.input = a;
    } else {
      usageError('too many arguments');
      process.exit(2);
    }
  }
  return opts;
}

function readStdin() {
  return fs.readFileSync(0, 'utf8');
}

function fetchUrl(url, insecure) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https://') ? https : http;
    const req = lib.get(url, { rejectUnauthorized: !insecure }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        fetchUrl(new URL(res.headers.location, url).toString(), insecure).then(resolve, reject);
        return;
      }
      if (res.statusCode < 200 || res.statusCode >= 300) {
        res.resume();
        reject(new Error('status ' + res.statusCode));
        return;
      }
      res.setEncoding('utf8');
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => resolve(data));
    });
    req.on('error', reject);
  });
}

async function readInput(opts) {
  if (!opts.input || opts.input === '-') return readStdin();
  if (/^https?:\/\//.test(opts.input)) {
    try {
      return await fetchUrl(opts.input, opts.insecure);
    } catch (e) {
      process.stderr.write('failed to fetch URL: ' + e.message + '\n');
      process.exit(4);
    }
  }
  try {
    return fs.readFileSync(opts.input, 'utf8');
  } catch (e) {
    process.stderr.write('open ' + opts.input + ': ' + e.message + '\n');
    process.exit(1);
  }
}

function stableJson(v, pretty) {
  const s = JSON.stringify(v, null, pretty ? 2 : 0);
  return s.replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
}

function isContainer(v) {
  return v !== null && typeof v === 'object';
}

function pathString(path) {
  let out = 'json';
  for (const p of path) {
    if (typeof p === 'number') {
      out += '[' + p + ']';
    } else if (/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(p)) {
      out += '.' + p;
    } else {
      out += '[' + stableJson(p, false) + ']';
    }
  }
  return out;
}

function segmentString(p) {
  if (typeof p === 'number') return '[' + p + ']';
  if (/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(p)) return '.' + p;
  return '[' + stableJson(p, false) + ']';
}

function comparePaths(a, b) {
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) {
    if (typeof a[i] === 'number' && typeof b[i] === 'number') {
      if (a[i] !== b[i]) return a[i] - b[i];
      continue;
    }
    const sa = segmentString(a[i]);
    const sb = segmentString(b[i]);
    if (sa < sb) return -1;
    if (sa > sb) return 1;
  }
  return a.length - b.length;
}

function flatten(value, path, rows, sortKeys) {
  const rowValue = Array.isArray(value) ? [] : (value !== null && typeof value === 'object' ? {} : value);
  rows.push({ path: path.slice(), value: rowValue });
  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i++) flatten(value[i], path.concat(i), rows, sortKeys);
  } else if (value !== null && typeof value === 'object') {
    let keys = Object.keys(value);
    if (sortKeys) {
      keys = keys.sort((a, b) => comparePaths(path.concat(a), path.concat(b)));
    }
    for (const k of keys) flatten(value[k], path.concat(k), rows, sortKeys);
  }
}

function colorizePath(path) {
  return pathString(path).replace(/([A-Za-z_$][A-Za-z0-9_$]*|"(?:\\.|[^"\\])*")/g, '\x1b[34;1m$1\x1b[0;22m');
}

function colorizeValue(v) {
  const raw = stableJson(v, false);
  if (typeof v === 'string') return '\x1b[33m' + raw + '\x1b[0m';
  if (typeof v === 'number') return '\x1b[31m' + raw + '\x1b[0m';
  if (typeof v === 'boolean' || v === null) return '\x1b[36m' + raw + '\x1b[0m';
  return '\x1b[35m' + raw + '\x1b[0m';
}

function printRows(rows, opts) {
  if (opts.sort) {
    rows.sort((a, b) => comparePaths(a.path, b.path));
  }
  const lines = [];
  for (const row of rows) {
    if (opts.values) {
      if (!isContainer(row.value)) lines.push(formatValuePlain(row.value));
      continue;
    }
    if (opts.json) {
      lines.push(stableJson([row.path, row.value], false));
    } else if (opts.color) {
      lines.push(colorizePath(row.path) + ' = ' + colorizeValue(row.value) + ';');
    } else {
      lines.push(pathString(row.path) + ' = ' + stableJson(row.value, false) + ';');
    }
  }
  process.stdout.write(lines.join('\n') + (lines.length ? '\n' : ''));
}

function formatValuePlain(v) {
  return typeof v === 'string' ? v : stableJson(v, false);
}

function parseJsonInput(text, stream) {
  try {
    if (!stream) return JSON.parse(text);
    const arr = [];
    for (const line of text.split(/\r?\n/)) {
      if (line.trim() === '') continue;
      arr.push(JSON.parse(line));
    }
    return arr;
  } catch (e) {
    process.stderr.write('invalid character ' + (e.message || 'in JSON') + '\n');
    process.exit(2);
  }
}

function parsePath(lhs) {
  lhs = lhs.trim();
  if (!lhs.startsWith('json')) throw new Error('invalid statement');
  let i = 4;
  const path = [];
  while (i < lhs.length) {
    if (/\s/.test(lhs[i])) {
      i++;
    } else if (lhs[i] === '.') {
      i++;
      const m = /^[A-Za-z_$][A-Za-z0-9_$]*/.exec(lhs.slice(i));
      if (!m) throw new Error('invalid statement');
      path.push(m[0]);
      i += m[0].length;
    } else if (lhs[i] === '[') {
      i++;
      if (lhs[i] === '"' || lhs[i] === "'") {
        const quote = lhs[i];
        let j = i + 1;
        let esc = false;
        while (j < lhs.length) {
          const ch = lhs[j];
          if (esc) esc = false;
          else if (ch === '\\') esc = true;
          else if (ch === quote) break;
          j++;
        }
        if (j >= lhs.length) throw new Error('invalid statement');
        let keyText = lhs.slice(i, j + 1);
        if (quote === "'") keyText = '"' + keyText.slice(1, -1).replace(/"/g, '\\"') + '"';
        path.push(JSON.parse(keyText));
        i = j + 1;
      } else {
        const m = /^\d+/.exec(lhs.slice(i));
        if (!m) throw new Error('invalid statement');
        path.push(Number(m[0]));
        i += m[0].length;
      }
      while (/\s/.test(lhs[i])) i++;
      if (lhs[i] !== ']') throw new Error('invalid statement');
      i++;
    } else {
      throw new Error('invalid statement');
    }
  }
  return path;
}

function parseAssignmentLine(line) {
  const eq = line.indexOf('=');
  if (eq < 0) throw new Error('invalid statement');
  const lhs = line.slice(0, eq);
  let rhs = line.slice(eq + 1).trim();
  if (rhs.endsWith(';')) rhs = rhs.slice(0, -1).trim();
  return { path: parsePath(lhs), value: JSON.parse(rhs) };
}

function ensureRootForPath(root, path) {
  if (root !== undefined) return root;
  return typeof path[0] === 'number' ? [] : {};
}

function assignPath(root, path, value) {
  if (path.length === 0) return value;
  root = ensureRootForPath(root, path);
  let cur = root;
  for (let i = 0; i < path.length; i++) {
    const key = path[i];
    const last = i === path.length - 1;
    if (last) {
      cur[key] = value;
      return root;
    }
    const nextKey = path[i + 1];
    if (cur[key] === undefined || cur[key] === null || typeof cur[key] !== 'object') {
      cur[key] = typeof nextKey === 'number' ? [] : {};
    }
    cur = cur[key];
  }
  return root;
}

function normalizeArrays(v) {
  if (Array.isArray(v)) {
    for (let i = 0; i < v.length; i++) {
      if (!(i in v) || v[i] === undefined) v[i] = null;
      else normalizeArrays(v[i]);
    }
  } else if (v && typeof v === 'object') {
    for (const k of Object.keys(v)) normalizeArrays(v[k]);
  }
}

function sortedForJson(v) {
  if (Array.isArray(v)) return v.map(sortedForJson);
  if (v && typeof v === 'object') {
    const out = {};
    for (const k of Object.keys(v).sort()) out[k] = sortedForJson(v[k]);
    return out;
  }
  return v;
}

function ungron(text, opts) {
  let root;
  try {
    if (opts.json) {
      for (const line of text.split(/\r?\n/)) {
        if (line.trim() === '') continue;
        const pair = JSON.parse(line);
        root = assignPath(root, pair[0], pair[1]);
      }
    } else {
      for (const line of text.split(/\r?\n/)) {
        if (line.trim() === '') continue;
        const stmt = parseAssignmentLine(line);
        root = assignPath(root, stmt.path, stmt.value);
      }
    }
  } catch (e) {
    process.stderr.write('failed to parse statements: ' + e.message + '\n');
    process.exit(5);
  }
  if (root === undefined) root = {};
  normalizeArrays(root);
  try {
    process.stdout.write(stableJson(sortedForJson(root), true) + '\n');
  } catch (e) {
    process.stderr.write('failed to encode JSON: ' + e.message + '\n');
    process.exit(6);
  }
}

function printValues(text, opts) {
  if (opts.json) return;
  const lines = [];
  try {
    for (const line of text.split(/\r?\n/)) {
      if (line.trim() === '') continue;
      const stmt = parseAssignmentLine(line);
      if (!isContainer(stmt.value)) lines.push(formatValuePlain(stmt.value));
    }
  } catch (e) {
    return;
  }
  process.stdout.write(lines.join('\n') + (lines.length ? '\n' : ''));
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  const text = await readInput(opts);
  if (opts.values) {
    if (!opts.input || opts.input === '-') printValues(text, opts);
    return;
  }
  if (opts.ungron) {
    ungron(text, opts);
    return;
  }
  const data = parseJsonInput(text, opts.stream);
  const rows = [];
  flatten(data, [], rows, opts.sort);
  printRows(rows, opts);
}

main().catch((e) => {
  process.stderr.write(e.stack + '\n');
  process.exit(2);
});
