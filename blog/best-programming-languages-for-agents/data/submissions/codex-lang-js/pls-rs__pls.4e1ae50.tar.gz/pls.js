#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const os = require('os');

const VERSION = 'pls 0.0.1-beta.9';
const DETS = ['dev','ino','nlink','typ','perm','oct','user','uid','group','gid','size','blocks','btime','ctime','mtime','atime','git','none','std','all'];
const TYPES = ['dir','symlink','fifo','socket','block-device','char-device','file','none','all'];
const SORTS = ['dev','ino','nlink','typ','cat','user','uid','group','gid','size','blocks','btime','ctime','mtime','atime','name','cname','ext','inode_','nlinks_','typ_','cat_','user_','uid_','group_','gid_','size_','blocks_','btime_','ctime_','mtime_','atime_','name_','cname_','ext_','none'];
const BOOL = ['true','false'];

function shortHelp() {
  return `pls is a prettier and powerful ls(1) for the pros.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  the paths to list, each of which may be a file or directory [default: .]

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

Detail view:
  -d, --det <DETAILS>    the data points to show about each node [default: none] [possible values:
                         dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
                         btime, ctime, mtime, atime, git, none, std, all]
  -H, --header <HEADER>  show headers above columnar data [default: true] [possible values: true,
                         false]
  -u, --unit <UNIT>      the type of units to use for the node sizes [default: binary] [possible
                         values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>  display node names in multiple columns [default: false] [possible values: true,
                     false]
  -D, --down <DOWN>  display node names column-first [default: false] [possible values: true, false]

Presentation:
  -i, --icon <ICON>          display icons next to node names [default: true] [possible values:
                             true, false]
  -S, --suffix <SUFFIX>      display node type suffixes after the node name [default: true]
                             [possible values: true, false]
  -l, --sym <SYM>            show symlink targets [default: true] [possible values: true, false]
  -c, --collapse <COLLAPSE>  show dependent nodes as children of their principal nodes [default:
                             true] [possible values: true, false]
  -a, --align <ALIGN>        align items accounting for leading dots [default: true] [possible
                             values: true, false]

Filtering:
  -t, --typ <TYPES>        the set of node types to include in the output [default: all] [possible
                           values: dir, symlink, fifo, socket, block-device, char-device, file,
                           none, all]
  -I, --imp <IMP>          the importance cutoff to dim or hide unimportant files [default: 0]
  -e, --exclude <EXCLUDE>  the pattern of files to selectively hide from the output
  -o, --only <ONLY>        the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>  the set of fields to sort by, trailing \`_\` reverses the direction
                           [default: cat cname] [possible values: dev, ino, nlink, typ, cat, user,
                           uid, group, gid, size, blocks, btime, ctime, mtime, atime, name, cname,
                           ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_, gid_, size_,
                           blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]`;
}

function longHelp() {
  return `pls is a prettier and powerful ls(1) for the pros.

Read docs: https://pls.cli.rs/
Get source: https://github.com/pls-rs/pls/
Sponsor: https://github.com/sponsors/dhruvkb/

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          the paths to list, each of which may be a file or directory
          
          [default: .]

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Detail view:
  -d, --det <DETAILS>
          the data points to show about each node
          
          [default: none]
          [possible values: dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
          btime, ctime, mtime, atime, git, none, std, all]

  -H, --header <HEADER>
          show headers above columnar data
          
          [default: true]
          [possible values: true, false]

  -u, --unit <UNIT>
          the type of units to use for the node sizes
          
          [default: binary]
          [possible values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>
          display node names in multiple columns
          
          [default: false]
          [possible values: true, false]

  -D, --down <DOWN>
          display node names column-first
          
          [default: false]
          [possible values: true, false]

Presentation:
  -i, --icon <ICON>
          display icons next to node names
          
          [default: true]
          [possible values: true, false]

  -S, --suffix <SUFFIX>
          display node type suffixes after the node name
          
          [default: true]
          [possible values: true, false]

  -l, --sym <SYM>
          show symlink targets
          
          [default: true]
          [possible values: true, false]

  -c, --collapse <COLLAPSE>
          show dependent nodes as children of their principal nodes
          
          [default: true]
          [possible values: true, false]

  -a, --align <ALIGN>
          align items accounting for leading dots
          
          [default: true]
          [possible values: true, false]

Filtering:
  -t, --typ <TYPES>
          the set of node types to include in the output
          
          [default: all]
          [possible values: dir, symlink, fifo, socket, block-device, char-device, file, none, all]

  -I, --imp <IMP>
          the importance cutoff to dim or hide unimportant files
          
          [default: 0]

  -e, --exclude <EXCLUDE>
          the pattern of files to selectively hide from the output

  -o, --only <ONLY>
          the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>
          the set of fields to sort by, trailing \`_\` reverses the direction
          
          [default: cat cname]
          [possible values: dev, ino, nlink, typ, cat, user, uid, group, gid, size, blocks, btime,
          ctime, mtime, atime, name, cname, ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_,
          gid_, size_, blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]`;
}

function die(msg, code = 2) { console.error(msg); process.exit(code); }
function needValue(args, i, opt, metav) {
  if (i + 1 >= args.length || args[i+1].startsWith('-')) die(`error: a value is required for '${opt} <${metav}>' but none was supplied\n\nFor more information, try '--help'.`);
  return args[i+1];
}
function invalid(opt, meta, val, vals) {
  die(`error: invalid value '${val}' for '${opt} <${meta}>'\n  [possible values: ${vals.join(', ')}]\n\nFor more information, try '--help'.`);
}
function parseBool(opt, val) {
  if (!BOOL.includes(val)) invalid(opt, optName(opt), val, BOOL);
  return val === 'true';
}
function optName(opt) {
  return ({'--grid':'GRID','-g':'GRID','--down':'DOWN','-D':'DOWN','--icon':'ICON','-i':'ICON','--suffix':'SUFFIX','-S':'SUFFIX','--sym':'SYM','-l':'SYM','--collapse':'COLLAPSE','-c':'COLLAPSE','--align':'ALIGN','-a':'ALIGN','--header':'HEADER','-H':'HEADER'})[opt] || 'VALUE';
}

function parseArgs(argv) {
  const o = { det: [], header: true, unit: 'binary', icon: true, suffix: true, sym: true, typ: [], imp: 0, exclude: null, only: null, sorts: [], paths: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h') { console.log(shortHelp()); process.exit(0); }
    if (a === '--help') { console.log(longHelp()); process.exit(0); }
    if (a === '-V' || a === '--version') { console.log(VERSION); process.exit(0); }
    if (a === '--') { o.paths.push(...argv.slice(i+1)); break; }
    if (a.startsWith('-')) {
      const bools = {'-H':'header','--header':'header','-g':'grid','--grid':'grid','-D':'down','--down':'down','-i':'icon','--icon':'icon','-S':'suffix','--suffix':'suffix','-l':'sym','--sym':'sym','-c':'collapse','--collapse':'collapse','-a':'align','--align':'align'};
      if (a in bools) { const v = needValue(argv, i, a, optName(a)); o[bools[a]] = parseBool(a, v); i++; continue; }
      if (a === '-d' || a === '--det') { const v = needValue(argv, i, a, 'DETAILS'); if (!DETS.includes(v)) invalid(a, 'DETAILS', v, DETS); o.det.push(v); i++; continue; }
      if (a === '-u' || a === '--unit') { const v = needValue(argv, i, a, 'UNIT'); if (!['binary','decimal','none'].includes(v)) invalid(a, 'UNIT', v, ['binary','decimal','none']); o.unit = v; i++; continue; }
      if (a === '-t' || a === '--typ') { const v = needValue(argv, i, a, 'TYPES'); if (!TYPES.includes(v)) invalid(a, 'TYPES', v, TYPES); o.typ.push(v); i++; continue; }
      if (a === '-I' || a === '--imp') { o.imp = parseInt(needValue(argv, i, a, 'IMP'), 10) || 0; i++; continue; }
      if (a === '-e' || a === '--exclude') { o.exclude = compileRegex(needValue(argv, i, a, 'EXCLUDE'), a, 'EXCLUDE'); i++; continue; }
      if (a === '-o' || a === '--only') { o.only = compileRegex(needValue(argv, i, a, 'ONLY'), a, 'ONLY'); i++; continue; }
      if (a === '-s' || a === '--sort') { const v = needValue(argv, i, a, 'SORT_BASES'); if (!SORTS.includes(v)) invalid(a, 'SORT_BASES', v, SORTS); o.sorts.push(v); i++; continue; }
      die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.`);
    } else o.paths.push(a);
  }
  if (!o.paths.length) o.paths = ['.'];
  if (!o.det.length) o.det = ['none'];
  if (!o.typ.length) o.typ = ['all'];
  if (!o.sorts.length) o.sorts = ['cat','cname'];
  return o;
}

function compileRegex(pat, opt, meta) {
  try { return new RegExp(pat); }
  catch (e) {
    console.error(`error: invalid value '${pat}' for '${opt} <${meta}>': regex parse error:\n    ${pat}\n    ^\nerror: ${e.message.replace(/^Invalid regular expression: .*: /, '')}\n\nFor more information, try '--help'.`);
    process.exit(2);
  }
}

const users = readMap('/etc/passwd', 2, 0);
const groups = readMap('/etc/group', 2, 0);
function readMap(file, idIdx, nameIdx) {
  const m = new Map();
  try {
    for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
      const p = line.split(':'); if (p.length > idIdx) m.set(Number(p[idIdx]), p[nameIdx]);
    }
  } catch {}
  return m;
}

function classify(st) {
  if (st.isDirectory()) return ['dir','d',1];
  if (st.isSymbolicLink()) return ['symlink','l',3];
  if (st.isFIFO()) return ['fifo','p',4];
  if (st.isSocket()) return ['socket','s',5];
  if (st.isBlockDevice()) return ['block-device','b',6];
  if (st.isCharacterDevice()) return ['char-device','c',7];
  return ['file','f',2];
}
function perms(mode) {
  const tri = n => `${n&4?'r':'-'}${n&2?'w':'-'}${n&1?'x':'-'}`;
  return `${tri((mode>>6)&7)} ${tri((mode>>3)&7)} ${tri(mode&7)}`;
}
function suffix(type) { return {dir:'/', symlink:'@', fifo:'|', socket:'=', file:''}[type] || ''; }
function icon(type, name) {
  if (type === 'dir') return '\uf07b ';
  if (type === 'symlink') return '\udb80\udf39 ';
  if (type === 'fifo') return '\udb81\udfe5 ';
  if (name.endsWith('.md')) return '\uf48a ';
  if (type === 'file' && name.includes('.')) return '\ue612 ';
  return '  ';
}
function targetIcon() { return '\udb80\udc54'; }

function collect(p, includeSelf=false) {
  try {
    const st = fs.lstatSync(p);
    if (st.isDirectory() && !includeSelf) {
      return fs.readdirSync(p).map(n => {
        const node = makeNode(path.join(p,n), n);
        node.inDir = true;
        return node;
      });
    }
    return [makeNode(p, p)];
  } catch (e) {
    return {error: osError(e)};
  }
}
function makeNode(full, display) {
  const st = fs.lstatSync(full);
  const [type, typ, cat] = classify(st);
  let tgt = null;
  if (type === 'symlink') { try { tgt = fs.readlinkSync(full); } catch {} }
  return { full, name: display, base: path.basename(display), st, type, typ, cat, target: tgt, user: users.get(st.uid) || String(st.uid), group: groups.get(st.gid) || String(st.gid) };
}

function filterSort(nodes, o) {
  const allowed = new Set(o.typ.includes('all') ? TYPES.filter(x => !['none','all'].includes(x)) : o.typ);
  nodes = nodes.filter(n => allowed.has(n.type));
  if (o.imp > 0) nodes = nodes.filter(n => !n.base.startsWith('.'));
  if (o.only) nodes = nodes.filter(n => o.only.test(n.base));
  if (o.exclude) nodes = nodes.filter(n => !o.exclude.test(n.base));
  return nodes.sort((a,b) => {
    for (const s0 of o.sorts) {
      if (s0 === 'none') continue;
      let rev = s0.endsWith('_'), s = rev ? s0.slice(0,-1) : s0;
      if (s === 'inode') s = 'ino'; if (s === 'nlinks') s = 'nlink';
      let av = key(a,s), bv = key(b,s);
      let c = typeof av === 'string' ? av.localeCompare(bv) : av - bv;
      if (c) return rev ? -c : c;
    }
    return 0;
  });
}
function key(n, s) {
  if (s === 'cat') return n.cat;
  if (s === 'name') return n.base;
  if (s === 'cname') return n.base.replace(/^\.+/, '').toLowerCase();
  if (s === 'ext') return path.extname(n.base).toLowerCase();
  if (s === 'typ') return n.typ;
  if (s === 'user') return n.user;
  if (s === 'group') return n.group;
  if (s === 'btime') return n.st.birthtimeMs; if (s === 'ctime') return n.st.ctimeMs; if (s === 'mtime') return n.st.mtimeMs; if (s === 'atime') return n.st.atimeMs;
  if (s === 'blocks') return n.st.blocks || 0;
  if (s === 'size') return n.st.size;
  if (s === 'ino') return n.st.ino;
  if (s === 'nlink') return n.st.nlink;
  if (s === 'dev') return n.st.dev;
  if (s === 'uid') return n.st.uid; if (s === 'gid') return n.st.gid;
  return 0;
}

function dateFmt(d) {
  const mons = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  let h = d.getHours(), ap = h >= 12 ? 'pm' : 'am';
  h = h % 12; if (h === 0) h = 12;
  return `${d.getFullYear()}-${mons[d.getMonth()]}-${String(d.getDate()).padStart(2,'0')} ${String(h).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}${ap}`;
}
function sizeFmt(n, unit) {
  if (unit === 'none') return `${n} B`;
  const base = unit === 'decimal' ? 1000 : 1024;
  const units = unit === 'decimal' ? ['B','kB','MB','GB','TB'] : ['B','KiB','MiB','GiB','TiB'];
  let v = n, i = 0;
  while (v >= base && i < units.length-1) { v /= base; i++; }
  return i === 0 ? `${v.toFixed(1)}   B` : `${v.toFixed(1)} ${units[i]}`;
}

const COL = {
  dev:['Device', n=>String(n.st.dev)], ino:['inode', n=>String(n.st.ino)], nlink:['Link#', n=>String(n.st.nlink)],
  typ:['T', n=>n.typ], perm:['Permissions', n=>perms(n.st.mode)], oct:['SUGO', n=>(n.st.mode&0o777).toString(8)],
  user:['User', n=>n.user], uid:['UID', n=>String(n.st.uid)], group:['Group', n=>n.group], gid:['GID', n=>String(n.st.gid)],
  size:['Size', (n,o)=> n.type === 'dir' ? '' : sizeFmt(n.st.size, o.unit)], blocks:['Blocks', n=>String(n.st.blocks || 0)],
  btime:['Created', n=>dateFmt(n.st.birthtime)], ctime:['Changed', n=>dateFmt(n.st.ctime)], mtime:['Modified', n=>dateFmt(n.st.mtime)], atime:['Accessed', n=>dateFmt(n.st.atime)],
  git:['Git', n=>'']
};
function detList(dets) {
  if (dets.includes('none')) return [];
  let out = [];
  for (const d of dets) {
    if (d === 'std') out.push('nlink','typ','perm','user','group','size','mtime');
    else if (d === 'all') out.push('dev','ino','nlink','typ','perm','oct','user','uid','group','gid','size','blocks','btime','ctime','mtime','atime','git');
    else out.push(d);
  }
  return [...new Set(out)];
}
function nameText(n,o) {
  let nm = (o.icon ? icon(n.type, n.base) : (n.inDir ? ' ' : '')) + n.base + (o.suffix ? suffix(n.type) : '');
  if (n.type === 'symlink' && o.sym && n.target) nm += ` ${targetIcon()} ${n.target}`;
  return nm;
}
function osError(e) {
  if (e && e.code === 'ENOENT') return 'No such file or directory (os error 2)';
  if (e && e.code === 'EACCES') return 'Permission denied (os error 13)';
  return e && e.message ? e.message : String(e);
}
function render(nodes,o) {
  const dets = detList(o.det);
  if (!dets.length) return nodes.map(n => nameText(n,o)).join('\n') + (nodes.length ? '\n' : '');
  const rows = nodes.map(n => {
    const vals = dets.map(d => COL[d][1](n,o));
    vals.push(nameText(n,o));
    return vals;
  });
  const heads = dets.map(d => COL[d][0]); heads.push('Name');
  const widths = heads.map((h,i) => Math.max(h.length, ...rows.map(r => String(r[i]).length)));
  const lines = [];
  if (o.header) lines.push(heads.map((h,i)=> i===heads.length-1 ? h : h.padStart(widths[i])).join(' '));
  for (const r of rows) lines.push(r.map((v,i)=> i===r.length-1 ? v : String(v).padStart(widths[i])).join(' '));
  return lines.join('\n') + (lines.length ? '\n' : '');
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  let chunks = [];
  const multi = o.paths.length > 1;
  for (const p of o.paths) {
    const got = collect(p, false);
    if (got.error) {
      chunks.push(`${p}:\n\terror: ${got.error}\n`);
      continue;
    }
    let nodes = filterSort(got,o);
    if (multi && got.length && fs.lstatSync(p).isDirectory()) chunks.push(`${p}:\n` + render(nodes,o));
    else chunks.push(render(nodes,o));
  }
  process.stdout.write(chunks.join(multi ? '\n' : ''));
}
main();
