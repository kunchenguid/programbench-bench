#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const HELP = `Sloth 0.1
Mitchell Hynes. <mshynes@mun.ca>
A toy for rendering 3D objects in the command line

USAGE:
    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -x, --yaw <x>      Sets the object's static X rotation (in radians)
    -y, --pitch <y>    Sets the object's static Y rotation (in radians)
    -z, --roll <z>     Sets the object's static Z rotation (in radians)

ARGS:
    <input filename(s)>...    Sets the input file to render

SUBCOMMANDS:
    help     Prints this message or the help of the given subcommand(s)
    image    Generates a colorless terminal output as lines of text`;

const IMAGE_HELP = `executable-image 
Mitchell Hynes <mitchell.hynes@ecumene.xyz>
Generates a colorless terminal output as lines of text

USAGE:
    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>

FLAGS:
        --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -j, --webify <frame count>    Generates a portable JS based render of your object for the web
    -h <height>                   Sets the height of the image to generate
    -w <width>                    Sets the width of the image to generate
    -x, --yaw <x>                 Sets the object's static X rotation (in radians)
    -y, --pitch <y>               Sets the object's static Y rotation (in radians)
    -z, --roll <z>                Sets the object's static Z rotation (in radians)`;

function dieMissing() {
  console.error(`error: The following required arguments were not provided:
    <input filename(s)>...

USAGE:
    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

For more information try --help`);
  process.exit(1);
}

function parseArgs(argv) {
  const opts = { yaw: 0, pitch: 0, roll: 0, bw: false, width: null, height: null, webify: 0, image: false, files: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help") return opts.image ? { imageHelp: true } : { help: true };
    if (a === "-h" && !opts.image) return { help: true };
    if (a === "help") return { help: true };
    if (a === "--version" || a === "-V") return { version: true };
    if (a === "image") { opts.image = true; continue; }
    if (a === "-b") { opts.bw = true; continue; }
    if (a === "-x" || a === "--yaw") { opts.yaw = Number(argv[++i] || 0); continue; }
    if (a === "-y" || a === "--pitch") { opts.pitch = Number(argv[++i] || 0); continue; }
    if (a === "-z" || a === "--roll") { opts.roll = Number(argv[++i] || 0); continue; }
    if (opts.image && a === "--help") return { imageHelp: true };
    if (opts.image && a === "-w") { opts.width = Math.max(1, Number(argv[++i] || 0) | 0); continue; }
    if (opts.image && a === "-h") { opts.height = Math.max(1, Number(argv[++i] || 0) | 0); continue; }
    if (opts.image && (a === "-j" || a === "--webify")) { opts.webify = Math.max(1, Number(argv[++i] || 0) | 0); continue; }
    if (a.startsWith("-")) continue;
    // The README shows quoted multiple filenames as one argument.
    opts.files.push(...a.split(/\s+/).filter(Boolean));
  }
  return opts;
}

function loadMaterials(file) {
  const colors = {};
  try {
    const text = fs.readFileSync(file, "utf8");
    let name = null;
    for (const raw of text.split(/\r?\n/)) {
      const p = raw.trim().split(/\s+/);
      if (p[0] === "newmtl") name = p.slice(1).join(" ");
      if (p[0] === "Kd" && name) colors[name] = p.slice(1, 4).map(v => Math.max(0, Math.min(255, Math.round(Number(v) * 255))));
    }
  } catch (_) {}
  return colors;
}

function parseOBJ(file) {
  const text = fs.readFileSync(file, "utf8");
  const base = path.dirname(file);
  const verts = [];
  let material = null;
  let materials = {};
  const tris = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line[0] === "#") continue;
    const p = line.split(/\s+/);
    if (p[0] === "mtllib") materials = { ...materials, ...loadMaterials(path.join(base, p.slice(1).join(" "))) };
    else if (p[0] === "usemtl") material = p.slice(1).join(" ");
    else if (p[0] === "v") verts.push([Number(p[1]), Number(p[2]), Number(p[3])]);
    else if (p[0] === "f") {
      const idx = p.slice(1).map(s => {
        const n = Number(s.split("/")[0]);
        return n < 0 ? verts.length + n : n - 1;
      }).filter(n => Number.isFinite(n) && verts[n]);
      for (let i = 1; i + 1 < idx.length; i++) {
        tris.push({ v: [verts[idx[0]], verts[idx[i]], verts[idx[i + 1]]], color: materials[material] || [255, 255, 0] });
      }
    }
  }
  return tris;
}

function parseSTL(file) {
  const text = fs.readFileSync(file, "utf8");
  const verts = [];
  const tris = [];
  for (const raw of text.split(/\r?\n/)) {
    const p = raw.trim().split(/\s+/);
    if (p[0] === "vertex") {
      verts.push([Number(p[1]), Number(p[2]), Number(p[3])]);
      if (verts.length === 3) {
        tris.push({ v: [verts[0], verts[1], verts[2]], color: [255, 255, 0] });
        verts.length = 0;
      }
    }
  }
  return tris;
}

function loadModel(files) {
  let tris = [];
  for (const f of files) {
    const ext = path.extname(f).toLowerCase();
    try {
      if (ext === ".obj") tris = tris.concat(parseOBJ(f));
      else if (ext === ".stl") tris = tris.concat(parseSTL(f));
      else tris = tris.concat(parseOBJ(f));
    } catch (e) {
      console.error(`filename: [${f}] couldn't load, ${e.message}`);
      process.exit(1);
    }
  }
  if (!tris.length) {
    console.error("No renderable geometry found");
    process.exit(1);
  }
  return tris;
}

function rotate(p, opts) {
  let [x, y, z] = p;
  let c = Math.cos(opts.yaw), s = Math.sin(opts.yaw);
  [y, z] = [y * c - z * s, y * s + z * c];
  c = Math.cos(opts.pitch); s = Math.sin(opts.pitch);
  [x, z] = [x * c + z * s, -x * s + z * c];
  c = Math.cos(opts.roll); s = Math.sin(opts.roll);
  [x, y] = [x * c - y * s, x * s + y * c];
  return [x, y, z];
}

function charFor(light) {
  if (light > 0.78) return "#";
  if (light > 0.52) return "*";
  if (light > 0.28) return "-";
  return ".";
}

function render(tris, opts, extraRot = 0) {
  const width = opts.width || 80;
  const height = opts.height || Math.max(10, Math.floor(width / 2));
  const localOpts = { ...opts, pitch: opts.pitch + extraRot };
  const rtris = tris.map(t => ({ v: t.v.map(p => rotate(p, localOpts)), color: t.color }));
  const pts = rtris.flatMap(t => t.v);
  const minX = Math.min(...pts.map(p => p[0])), maxX = Math.max(...pts.map(p => p[0]));
  const minY = Math.min(...pts.map(p => p[1])), maxY = Math.max(...pts.map(p => p[1]));
  const minZ = Math.min(...pts.map(p => p[2])), maxZ = Math.max(...pts.map(p => p[2]));
  const sx = (width - 1) / Math.max(1e-9, maxX - minX);
  const sy = (height - 1) / Math.max(1e-9, maxY - minY);
  const scale = Math.min(sx, sy) * 0.92;
  const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
  const grid = Array.from({ length: height }, () => Array.from({ length: width }, () => ({ ch: " ", z: -Infinity, color: [0, 0, 0] })));
  const project = p => [Math.round((p[0] - cx) * scale + width / 2), Math.round(height / 2 - (p[1] - cy) * scale), p[2]];
  for (const t of rtris) {
    const a = t.v[0], b = t.v[1], c = t.v[2];
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
    const vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
    const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
    const norm = Math.hypot(nx, ny, nz) || 1;
    const light = Math.max(0.15, Math.min(1, (nz / norm + 1) / 2));
    const pp = t.v.map(project);
    const xs = pp.map(p => p[0]), ys = pp.map(p => p[1]);
    const loX = Math.max(0, Math.min(...xs)), hiX = Math.min(width - 1, Math.max(...xs));
    const loY = Math.max(0, Math.min(...ys)), hiY = Math.min(height - 1, Math.max(...ys));
    const den = (pp[1][1] - pp[2][1]) * (pp[0][0] - pp[2][0]) + (pp[2][0] - pp[1][0]) * (pp[0][1] - pp[2][1]);
    if (Math.abs(den) < 1e-9) continue;
    for (let y = loY; y <= hiY; y++) for (let x = loX; x <= hiX; x++) {
      const w1 = ((pp[1][1] - pp[2][1]) * (x - pp[2][0]) + (pp[2][0] - pp[1][0]) * (y - pp[2][1])) / den;
      const w2 = ((pp[2][1] - pp[0][1]) * (x - pp[2][0]) + (pp[0][0] - pp[2][0]) * (y - pp[2][1])) / den;
      const w3 = 1 - w1 - w2;
      if (w1 >= -0.01 && w2 >= -0.01 && w3 >= -0.01) {
        const z = w1 * pp[0][2] + w2 * pp[1][2] + w3 * pp[2][2];
        if (z >= grid[y][x].z) {
          const color = opts.bw ? [255, 255, 255] : t.color.map(v => Math.round(v * light));
          grid[y][x] = { ch: charFor(light), z, color };
        }
      }
    }
  }
  return grid;
}

function ansi(grid) {
  return grid.map(row => row.map(cell => {
    const [r, g, b] = cell.color;
    return `\x1b[48;2;25;25;25m\x1b[38;2;${r};${g};${b}m${cell.ch}\x1b[49m\x1b[39m`;
  }).join("")).join("\n") + "\n";
}

function htmlFrame(grid) {
  return grid.map(row => row.map(cell => {
    const [r, g, b] = cell.color;
    return `<span style="color:rgb(${r},${g},${b})">${cell.ch}`;
  }).join("")).join("\n");
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) { console.log(HELP); return; }
  if (args.imageHelp) { console.log(IMAGE_HELP); return; }
  if (args.version) { console.log("Sloth 0.1"); return; }
  if (!args.files || !args.files.length) dieMissing();
  if (args.image && !args.width) {
    console.error("error: The following required arguments were not provided:\n    -w <width>");
    process.exit(1);
  }
  const tris = loadModel(args.files);
  if (args.webify) {
    const frames = [];
    for (let i = 0; i < args.webify; i++) frames.push("`\n" + htmlFrame(render(tris, args, i * Math.PI * 2 / args.webify)) + "`");
    console.log("let frames = [\n" + frames.join(",\n") + "];");
  } else {
    process.stdout.write(ansi(render(tris, args)));
  }
}

main();
