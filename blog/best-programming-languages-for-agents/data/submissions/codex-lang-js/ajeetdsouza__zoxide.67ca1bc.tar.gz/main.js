#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const VERSION = '0.9.9';
const AUTHOR = "Ajeet D'Souza <98ajeet@gmail.com>";
const URL = 'https://github.com/ajeetdsouza/zoxide';

function out(s = '') { process.stdout.write(s + '\n'); }
function err(s = '') { process.stderr.write(s + '\n'); }
function exit(code) { process.exitCode = code; }

function envBlock() {
  return `Environment variables:
  _ZO_DATA_DIR          Path for zoxide data files
  _ZO_ECHO              Print the matched directory before navigating to it when set to 1
  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded
  _ZO_FZF_OPTS          Custom flags to pass to fzf
  _ZO_MAXAGE            Maximum total age after which entries start getting deleted
  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths`;
}

const helps = {
  root: `zoxide ${VERSION}
${AUTHOR}
${URL}

A smarter cd command for your terminal

Usage:
  executable <COMMAND>

Commands:
  add     Add a new directory or increment its rank
  edit    Edit the database
  import  Import entries from another application
  init    Generate shell configuration
  query   Search for a directory in the database
  remove  Remove a directory from the database

Options:
  -h, --help     Print help
  -V, --version  Print version

${envBlock()}`,
  add: `zoxide-add ${VERSION}
${AUTHOR}
${URL}

Add a new directory or increment its rank

Usage:
  executable add [OPTIONS] <PATHS>...

Arguments:
  <PATHS>...  

Options:
  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't
  -h, --help           Print help
  -V, --version        Print version

${envBlock()}`,
  query: `zoxide-query ${VERSION}
${AUTHOR}
${URL}

Search for a directory in the database

Usage:
  executable query [OPTIONS] [KEYWORDS]...

Arguments:
  [KEYWORDS]...  

Options:
  -a, --all              Show unavailable directories
  -i, --interactive      Use interactive selection
  -l, --list             List all matching directories
  -s, --score            Print score with results
      --exclude <path>   Exclude the current directory
      --base-dir <path>  Only search within this directory
  -h, --help             Print help
  -V, --version          Print version

${envBlock()}`,
  remove: `zoxide-remove ${VERSION}
${AUTHOR}
${URL}

Remove a directory from the database

Usage:
  executable remove [PATHS]...

Arguments:
  [PATHS]...  

Options:
  -h, --help     Print help
  -V, --version  Print version

${envBlock()}`,
  import: `zoxide-import ${VERSION}
${AUTHOR}
${URL}

Import entries from another application

Usage:
  executable import [OPTIONS] --from <FROM> <PATH>

Arguments:
  <PATH>  

Options:
      --from <FROM>  Application to import from [possible values: autojump, z]
      --merge        Merge into existing database
  -h, --help         Print help
  -V, --version      Print version

${envBlock()}`,
  edit: `zoxide-edit ${VERSION}
${AUTHOR}
${URL}

Edit the database

Usage:
  executable edit

Options:
  -h, --help     Print help
  -V, --version  Print version

${envBlock()}`,
  init: `zoxide-init ${VERSION}
${AUTHOR}
${URL}

Generate shell configuration

Usage:
  executable init [OPTIONS] <SHELL>

Arguments:
  <SHELL>  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]

Options:
      --no-cmd       Prevents zoxide from defining the \`z\` and \`zi\` commands
      --cmd <CMD>    Changes the prefix of the \`z\` and \`zi\` commands [default: z]
      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]
  -h, --help         Print help
  -V, --version      Print version

${envBlock()}`
};

function dataDir() {
  if (process.env._ZO_DATA_DIR) return process.env._ZO_DATA_DIR;
  if (process.env.XDG_DATA_HOME) return path.join(process.env.XDG_DATA_HOME, 'zoxide');
  return path.join(os.homedir(), '.local', 'share', 'zoxide');
}
function dbPath() { return path.join(dataDir(), 'db.zo'); }

function readDb() {
  try {
    const raw = fs.readFileSync(dbPath(), 'utf8');
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) return parsed;
    if (Array.isArray(parsed.entries)) return parsed.entries;
  } catch (_) {}
  return [];
}

function writeDb(entries) {
  fs.mkdirSync(dataDir(), { recursive: true });
  fs.writeFileSync(dbPath(), JSON.stringify({ version: 3, entries }, null, 2) + '\n');
}

function absPath(p) {
  const expanded = p === '~' ? os.homedir() : p.startsWith('~/') ? path.join(os.homedir(), p.slice(2)) : p;
  let resolved = path.resolve(expanded);
  if (process.env._ZO_RESOLVE_SYMLINKS === '1') {
    try { resolved = fs.realpathSync(resolved); } catch (_) {}
  }
  return resolved;
}

function unavailable(p) {
  try { return !fs.statSync(p).isDirectory(); } catch (_) { return true; }
}

function globToRe(glob) {
  let s = '^';
  for (const ch of glob) {
    if (ch === '*') s += '.*';
    else if ('\\^$+?.()|{}[]'.includes(ch)) s += '\\' + ch;
    else s += ch;
  }
  return new RegExp(s + '$');
}

function excluded(p) {
  const spec = process.env._ZO_EXCLUDE_DIRS;
  if (!spec) return false;
  return spec.split(path.delimiter).filter(Boolean).some(g => globToRe(absPath(g)).test(p));
}

function addEntry(entries, p, rank) {
  const now = Math.floor(Date.now() / 1000);
  const old = entries.find(e => e.path === p);
  if (old) {
    old.rank = Number(old.rank || 0) + rank;
    old.lastAccessed = now;
  } else {
    entries.push({ path: p, rank, lastAccessed: now });
  }
}

function parseScore(s) {
  const n = Number(s);
  if (!Number.isFinite(n)) return null;
  return n;
}

function commandAdd(argv) {
  if (argv.includes('-h') || argv.includes('--help')) return out(helps.add);
  if (argv.includes('-V') || argv.includes('--version')) return out(`zoxide-add ${VERSION}`);
  let score = 1, paths = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') { paths.push(...argv.slice(i + 1)); break; }
    if (a === '-s' || a === '--score') {
      if (i + 1 >= argv.length) return err(`error: a value is required for '${a} <SCORE>' but none was supplied\n\nFor more information, try '--help'.`), exit(2);
      const v = parseScore(argv[++i]);
      if (v === null) return err(`error: invalid value '${argv[i]}' for '--score <SCORE>': invalid float literal\n\nFor more information, try '--help'.`), exit(2);
      score = v;
    } else if (a.startsWith('-')) {
      return err(`error: unexpected argument '${a}' found\n\nUsage: executable add [OPTIONS] <PATHS>...\n\nFor more information, try '--help'.`), exit(2);
    } else paths.push(a);
  }
  if (!paths.length) return err(`error: the following required arguments were not provided:\n  <PATHS>...\n\nUsage: executable add <PATHS>...\n\nFor more information, try '--help'.`), exit(2);
  const db = readDb();
  for (const raw of paths) {
    const p = absPath(raw);
    if (unavailable(p)) { err(`zoxide: not a directory: ${p}`); exit(1); continue; }
    if (!excluded(p)) addEntry(db, p, score);
  }
  writeDb(ageDb(db));
}

function ageDb(entries) {
  const maxAge = Number(process.env._ZO_MAXAGE || 10000);
  if (!Number.isFinite(maxAge) || maxAge <= 0) return entries;
  let total = entries.reduce((a, e) => a + Number(e.rank || 0), 0);
  if (total > maxAge) {
    const factor = maxAge * 0.9 / total;
    entries.forEach(e => e.rank *= factor);
  }
  return entries.filter(e => e.rank > 0.01);
}

function isSubsequence(q, s) {
  q = q.toLowerCase(); s = s.toLowerCase();
  let j = 0;
  for (let i = 0; i < s.length && j < q.length; i++) if (s[i] === q[j]) j++;
  return j === q.length;
}

function matches(e, keywords) {
  const p = e.path.toLowerCase();
  return keywords.every(k => {
    const q = k.toLowerCase();
    if (q === '/') return true;
    if (q.endsWith('/')) return p.split('/').some(part => part.startsWith(q.slice(0, -1)));
    return p.includes(q) || isSubsequence(q, p);
  });
}

function ranked(entries, keywords, opts) {
  let res = entries.filter(e => opts.all || !unavailable(e.path));
  if (opts.exclude) res = res.filter(e => path.resolve(e.path) !== path.resolve(opts.exclude));
  if (opts.baseDir) {
    const b = path.resolve(opts.baseDir);
    res = res.filter(e => e.path === b || e.path.startsWith(b + path.sep));
  }
  res = res.filter(e => matches(e, keywords));
  res.sort((a, b) => (Number(b.rank) - Number(a.rank)) || (Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0)) || a.path.localeCompare(b.path));
  return res;
}

function scoreText(e) {
  const val = Number(e.rank || 0) * 4;
  return val.toFixed(1).padStart(6, ' ') + ' ' + e.path;
}

function commandQuery(argv) {
  if (argv.includes('-h') || argv.includes('--help')) return out(helps.query);
  if (argv.includes('-V') || argv.includes('--version')) return out(`zoxide-query ${VERSION}`);
  const opts = { all: false, list: false, score: false, interactive: false };
  const keywords = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') { keywords.push(...argv.slice(i + 1)); break; }
    if (a === '-a' || a === '--all') opts.all = true;
    else if (a === '-l' || a === '--list') opts.list = true;
    else if (a === '-s' || a === '--score') opts.score = true;
    else if (a === '-i' || a === '--interactive') opts.interactive = true;
    else if (a === '--exclude' || a === '--base-dir') {
      if (i + 1 >= argv.length) return err(`error: a value is required for '${a} <path>' but none was supplied\n\nFor more information, try '--help'.`), exit(2);
      opts[a === '--exclude' ? 'exclude' : 'baseDir'] = absPath(argv[++i]);
    } else if (a.startsWith('-')) {
      return err(`error: unexpected argument '${a}' found\n\nUsage: executable query [OPTIONS] [KEYWORDS]...\n\nFor more information, try '--help'.`), exit(2);
    } else keywords.push(a);
  }
  let res = ranked(readDb(), keywords.map(absLikeKeyword), opts);
  if (opts.interactive && res.length) {
    const input = res.map(e => scoreText(e)).join('\n') + '\n';
    try {
      const fzf = cp.spawnSync('fzf', { input, encoding: 'utf8', shell: false, env: { ...process.env, FZF_DEFAULT_OPTS: process.env._ZO_FZF_OPTS || '' } });
      if (fzf.status === 0 && fzf.stdout.trim()) {
        const line = fzf.stdout.trim().replace(/^\s*\d+(?:\.\d+)?\s+/, '');
        return out(line);
      }
      exit(1); return;
    } catch (_) {}
  }
  if (!res.length) {
    if (!opts.list) { err('zoxide: no match found'); exit(1); }
    return;
  }
  if (opts.list) res.forEach(e => out(opts.score ? scoreText(e) : e.path));
  else out(opts.score ? scoreText(res[0]) : res[0].path);
}

function absLikeKeyword(k) {
  if (k.startsWith('/') || k === '~' || k.startsWith('~/') || k === '.' || k === '..') return absPath(k);
  return k;
}

function commandRemove(argv) {
  if (argv.includes('-h') || argv.includes('--help')) return out(helps.remove);
  if (argv.includes('-V') || argv.includes('--version')) return out(`zoxide-remove ${VERSION}`);
  const paths = argv[0] === '--' ? argv.slice(1) : argv;
  let db = readDb();
  if (!paths.length) {
    db = db.filter(e => !unavailable(e.path));
    writeDb(db);
    return;
  }
  let bad = false;
  for (const raw of paths) {
    const p = absPath(raw);
    const before = db.length;
    db = db.filter(e => e.path !== p);
    if (db.length === before) { err(`zoxide: path not found in database: ${p}`); bad = true; }
  }
  writeDb(db);
  if (bad) exit(1);
}

function commandImport(argv) {
  if (argv.includes('-h') || argv.includes('--help')) return out(helps.import);
  if (argv.includes('-V') || argv.includes('--version')) return out(`zoxide-import ${VERSION}`);
  let from = null, merge = false, file = null;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--merge') merge = true;
    else if (a === '--from') from = argv[++i];
    else if (a.startsWith('--from=')) from = a.slice(7);
    else if (!file) file = a;
    else return err(`error: unexpected argument '${a}' found\n\nUsage: executable import [OPTIONS] --from <FROM> <PATH>\n\nFor more information, try '--help'.`), exit(2);
  }
  if (!from || !file) return err(`error: the following required arguments were not provided:\n  --from <FROM>\n  <PATH>\n\nUsage: executable import --from <FROM> <PATH>\n\nFor more information, try '--help'.`), exit(2);
  if (!['z', 'autojump'].includes(from)) return err(`error: invalid value '${from}' for '--from <FROM>'\n  [possible values: autojump, z]\n\nFor more information, try '--help'.`), exit(2);
  let db = merge ? readDb() : [];
  try {
    const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean);
    for (const line of lines) {
      let p, r;
      if (from === 'z') {
        const parts = line.split('|');
        if (parts.length < 2) continue;
        p = parts[0]; r = Number(parts[1]);
      } else {
        const parts = line.trim().split(/\s+/);
        if (parts.length < 2) continue;
        if (Number.isFinite(Number(parts[0]))) { r = Number(parts[0]); p = parts.slice(1).join(' '); }
        else { p = parts[0]; r = Number(parts[1]); }
      }
      if (Number.isFinite(r) && p && !unavailable(p)) addEntry(db, absPath(p), r);
    }
    writeDb(db);
  } catch (e) {
    err('zoxide: import error');
    err('');
    err('Caused by:');
    err(`    ${e.message}`);
    exit(1);
  }
}

function commandEdit(argv) {
  if (argv.includes('-h') || argv.includes('--help')) return out(helps.edit);
  if (argv.includes('-V') || argv.includes('--version')) return out(`zoxide-edit ${VERSION}`);
  fs.mkdirSync(dataDir(), { recursive: true });
  if (!fs.existsSync(dbPath())) writeDb([]);
  const editor = process.env.EDITOR || process.env.VISUAL || 'vi';
  const r = cp.spawnSync(editor, [dbPath()], { stdio: 'inherit', shell: true });
  exit(r.status || 0);
}

function initScript(shell, opts) {
  const cmd = opts.cmd || 'z';
  const zi = cmd + 'i';
  if (shell === 'posix' || shell === 'bash' || shell === 'zsh') {
    return `# shellcheck shell=sh
__zoxide_pwd() {
    \\command pwd -L
}
__zoxide_cd() {
    \\command cd "$@"
}
__zoxide_hook() {
    \\command zoxide add -- "$(__zoxide_pwd)"
}
__zoxide_z() {
    if [ "$#" -eq 0 ]; then
        __zoxide_cd ~
    elif [ "$#" -eq 1 ] && [ -d "$1" ]; then
        __zoxide_cd "$1"
    else
        __zoxide_result="$(\\command zoxide query --exclude "$(__zoxide_pwd)" -- "$@")" && __zoxide_cd "$__zoxide_result"
    fi
}
__zoxide_zi() {
    __zoxide_result="$(\\command zoxide query --interactive -- "$@")" && __zoxide_cd "$__zoxide_result"
}
${opts.noCmd ? '' : `${cmd}() { __zoxide_z "$@"; }\n${zi}() { __zoxide_zi "$@"; }`}
`;
  }
  if (shell === 'fish') return `function __zoxide_pwd\n    builtin pwd -L\nend\nfunction __zoxide_hook --on-variable PWD\n    command zoxide add -- (__zoxide_pwd)\nend\nfunction __zoxide_z\n    set -l result (command zoxide query --exclude (__zoxide_pwd) -- $argv); and cd $result\nend\n${opts.noCmd ? '' : `alias ${cmd}=__zoxide_z\nalias ${zi}='zoxide query --interactive'`}\n`;
  if (shell === 'powershell') return `function global:__zoxide_hook { zoxide add "--" (Get-Location).Path }\nfunction global:__zoxide_z { zoxide query -- $args | Set-Location }\n${opts.noCmd ? '' : `Set-Alias ${cmd} __zoxide_z\nfunction global:${zi} { zoxide query --interactive -- $args | Set-Location }`}\n`;
  if (shell === 'nushell') return `# Code generated by zoxide. DO NOT EDIT.\ndef --env --wrapped __zoxide_z [...rest: string] { cd (^zoxide query -- ...$rest | str trim) }\n${opts.noCmd ? '' : `alias ${cmd} = __zoxide_z\nalias ${zi} = __zoxide_z`}\n`;
  return `# zoxide initialization for ${shell}\n# Add directories with: zoxide add -- "$PWD"\n`;
}

function commandInit(argv) {
  if (argv.includes('-h') || argv.includes('--help')) return out(helps.init);
  if (argv.includes('-V') || argv.includes('--version')) return out(`zoxide-init ${VERSION}`);
  const opts = { cmd: 'z', hook: 'pwd', noCmd: false };
  let shell = null;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--no-cmd') opts.noCmd = true;
    else if (a === '--cmd') opts.cmd = argv[++i];
    else if (a.startsWith('--cmd=')) opts.cmd = a.slice(6);
    else if (a === '--hook') opts.hook = argv[++i];
    else if (a.startsWith('--hook=')) opts.hook = a.slice(7);
    else if (!shell) shell = a;
    else return err(`error: unexpected argument '${a}' found\n\nUsage: executable init [OPTIONS] <SHELL>\n\nFor more information, try '--help'.`), exit(2);
  }
  const shells = ['bash', 'elvish', 'fish', 'nushell', 'posix', 'powershell', 'tcsh', 'xonsh', 'zsh'];
  if (!shell) return err(`error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable init [OPTIONS] <SHELL>\n\nFor more information, try '--help'.`), exit(2);
  if (!shells.includes(shell)) return err(`error: invalid value '${shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nFor more information, try '--help'.`), exit(2);
  out(initScript(shell, opts).replace(/\n$/, ''));
}

function main() {
  const argv = process.argv.slice(2);
  if (argv.length === 0 || argv[0] === '-h' || argv[0] === '--help') { out(helps.root); if (argv.length === 0) exit(2); return; }
  if (argv[0] === '-V' || argv[0] === '--version') return out(`zoxide ${VERSION}`);
  const cmd = argv.shift();
  if (cmd === 'add') return commandAdd(argv);
  if (cmd === 'query') return commandQuery(argv);
  if (cmd === 'remove') return commandRemove(argv);
  if (cmd === 'import') return commandImport(argv);
  if (cmd === 'edit') return commandEdit(argv);
  if (cmd === 'init') return commandInit(argv);
  err(`error: unrecognized subcommand '${cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.`);
  exit(2);
}

main();
