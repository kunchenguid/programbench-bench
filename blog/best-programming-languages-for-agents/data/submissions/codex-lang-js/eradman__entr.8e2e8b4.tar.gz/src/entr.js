#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const RELEASE = '5.7';

function base() {
  return path.basename(process.env.ENTR_ARG0 || process.argv[1] || 'entr');
}

function usage(extra) {
  if (extra) process.stderr.write(extra);
  process.stderr.write(`release: ${RELEASE}\n`);
  process.stderr.write('usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames\n');
  process.stderr.write('hint: use -h to display option summary\n');
}

function help() {
  process.stderr.write(`release: ${RELEASE}
usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames
summary:
    -a  Do not consolidate events
    -c  Clear screen before execution
    -d  Track files added or removed from directories
    -n  Non-interactive mode
    -p  Wait for first event
    -r  Run as a background process, use signal to restart
    -s  Evaluate using a shell
    -x  Format exit status
    -z  Exit after the utility completes
docs:
    man entr
`);
}

function parseArgs(argv) {
  const opts = {
    a: false, c: 0, d: 0, n: false, p: false, r: false, s: false, x: 0, z: false,
  };
  let i = 0;
  for (; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--') {
      i++;
      break;
    }
    if (!arg.startsWith('-') || arg === '-') break;
    if (arg === '-h') {
      help();
      process.exit(1);
    }
    for (let j = 1; j < arg.length; j++) {
      const ch = arg[j];
      if (!(ch in opts)) {
        usage(`${base()}: invalid option -- '${ch}'\n`);
        process.exit(1);
      }
      if (ch === 'c' || ch === 'd' || ch === 'x') opts[ch]++;
      else opts[ch] = true;
    }
  }
  const cmd = argv.slice(i);
  if (cmd.length === 0) {
    usage();
    process.exit(1);
  }
  if (opts.s && cmd.length !== 1) {
    process.stderr.write(`${base()}: -s requires commands to be formatted as a single argument\n`);
    process.exit(1);
  }
  return { opts, cmd };
}

function readStdin() {
  try {
    return fs.readFileSync(0, 'utf8')
      .split(/\n/)
      .map((s) => s.replace(/\r$/, ''))
      .filter((s) => s.length > 0);
  } catch {
    return [];
  }
}

function validateFiles(names) {
  const out = [];
  for (const name of names) {
    try {
      fs.statSync(name);
      out.push(name);
    } catch {
      process.stderr.write(`${base()}: unable to stat '${name}'\n`);
    }
  }
  if (out.length === 0) {
    process.stderr.write(`${base()}: No regular files to watch\n`);
    process.exit(1);
  }
  return out;
}

function setupStatusScript() {
  const statusPath = process.env.ENTR_STATUS_SCRIPT
    || path.join(process.env.HOME || '.', '.entr', 'status.awk');
  if (!fs.existsSync(statusPath)) {
    fs.mkdirSync(path.dirname(statusPath), { recursive: true, mode: 0o700 });
    fs.writeFileSync(statusPath,
      '# http://eradman.com/entrproject/status-filters.html\n'
      + '/^signal/ { print $3, "terminated by signal", $2; }\n'
      + '/^exit/ { print $3, "returned exit code", $2; }\n',
      { mode: 0o640 });
    process.stderr.write(`entr: created '${statusPath}'\n`);
  }
  process.stderr.write(`awk: not an option: -S\n${base()}: status process terminated\n`);
  process.exit(0);
}

function clearScreen(level) {
  if (level <= 0) return;
  if (level >= 2) process.stdout.write('\x1b[2J\x1b[3J\x1b[H');
  else process.stdout.write('\x1b[2J\x1b[H');
}

function envForChild() {
  return { ...process.env, PAGER: process.env.PAGER || '/bin/cat' };
}

function statusFrom(code, signal) {
  if (typeof code === 'number') return code;
  const signals = {
    SIGHUP: 129, SIGINT: 130, SIGQUIT: 131, SIGTERM: 143,
    SIGUSR1: 138, SIGUSR2: 140,
  };
  return signals[signal] || 1;
}

function commandFor(opts, cmd, triggerFile) {
  const first = triggerFile || '';
  if (opts.s) {
    const shell = process.env.SHELL || '/bin/sh';
    return { file: shell, args: ['-c', cmd[0], first], shellMode: true };
  }
  return {
    file: cmd[0],
    args: cmd.slice(1).map((a) => (a === '/_' ? first : a)),
    shellMode: false,
  };
}

function runOnce(opts, cmd, triggerFile, cb) {
  clearScreen(opts.c);
  const spec = commandFor(opts, cmd, triggerFile);
  const child = spawn(spec.file, spec.args, {
    stdio: 'inherit',
    env: envForChild(),
    detached: !!opts.r,
  });
  child.on('error', (err) => {
    const msg = err && err.code === 'ENOENT' ? 'No such file or directory' : (err.message || String(err));
    process.stderr.write(`${base()}: exec ${spec.file}: ${msg}\n`);
    cb(1);
  });
  child.on('exit', (code, signal) => cb(statusFrom(code, signal)));
  return child;
}

function unique(list) {
  return [...new Set(list)];
}

function watchedPaths(files, opts) {
  const paths = [...files];
  if (opts.d > 0) {
    for (const f of files) {
      const st = fs.statSync(f);
      paths.push(st.isDirectory() ? f : path.dirname(f) || '.');
    }
  }
  return unique(paths);
}

function snapshotDir(dir, includeDot) {
  try {
    return new Set(fs.readdirSync(dir).filter((n) => includeDot || !n.startsWith('.')));
  } catch {
    return new Set();
  }
}

function firstFile(files) {
  return files[0];
}

function main() {
  const { opts, cmd } = parseArgs(process.argv.slice(2));
  const files = validateFiles(readStdin());
  const defaultTrigger = firstFile(files);

  if (opts.x > 0) setupStatusScript();

  let running = false;
  let child = null;
  let pending = false;
  let exiting = false;
  const dirSnapshots = new Map();

  const invoke = (trigger) => {
    if (exiting) return;
    const tf = trigger || defaultTrigger;
    if (running) {
      pending = !!opts.a;
      if (opts.r && child && child.pid) {
        const sig = `SIG${process.env.ENTR_RESTART_SIGNAL || 'TERM'}`;
        try { process.kill(-child.pid, sig); } catch { try { child.kill(sig); } catch {} }
      }
      return;
    }
    running = true;
    child = runOnce(opts, cmd, tf, (status) => {
      running = false;
      child = null;
      if (opts.z) {
        exiting = true;
        process.exit(status);
      }
      if (pending) {
        pending = false;
        invoke(tf);
      }
    });
  };

  const quit = (code = 0) => {
    exiting = true;
    if (child && child.pid) {
      try { process.kill(opts.r ? -child.pid : child.pid, 'SIGTERM'); } catch {}
    }
    process.exit(code);
  };

  process.on('SIGINT', () => quit(0));
  process.on('SIGTERM', () => quit(0));

  if (!opts.n && !process.stdin.isTTY) {
    // The reference fails early in non-interactive contexts only after validation.
    process.stderr.write(`${base()}: unable to get terminal attributes, use '-n' to run non-interactively\n`);
    process.exit(1);
  }

  if (opts.z) {
    if (opts.p) {
      // Keep watching below; exit after the delayed first run.
    } else {
      invoke(defaultTrigger);
      return;
    }
  } else if (!opts.p) {
    invoke(defaultTrigger);
  }

  const watches = [];
  const schedule = (name) => {
    if (exiting) return;
    invoke(name ? path.resolve(name) : defaultTrigger);
  };

  for (const p of watchedPaths(files, opts)) {
    try {
      const st = fs.statSync(p);
      if (st.isDirectory()) dirSnapshots.set(path.resolve(p), snapshotDir(p, opts.d > 1));
      watches.push(fs.watch(p, { persistent: true }, (event, filename) => {
        if (opts.d > 0 && st.isDirectory()) {
          const key = path.resolve(p);
          const oldSet = dirSnapshots.get(key) || new Set();
          const now = snapshotDir(p, opts.d > 1);
          let changed = oldSet.size !== now.size;
          if (!changed) {
            for (const n of now) if (!oldSet.has(n)) { changed = true; break; }
          }
          dirSnapshots.set(key, now);
          if (changed) {
            process.stderr.write(`${base()}: directory altered\n`);
            quit(2);
          }
        }
        if (st.isDirectory()) schedule(filename ? path.join(p, filename.toString()) : p);
        else schedule(p);
      }));
    } catch {
      // Validation already reported initial stat failures. Ignore watch races.
    }
  }

  if (!opts.n && process.stdin.isTTY) {
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', (buf) => {
      const s = buf.toString();
      if (s === 'q' || buf[0] === 3) quit(0);
      if (s === ' ') schedule(defaultTrigger);
    });
  }

  if (watches.length === 0) quit(1);
}

main();
