#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const VERSION = '*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***';

const HELP = `${VERSION}

Compress or decompress the INPUT file(s); reads from STDIN if INPUT is \`-\` or not provided.

Usage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]

Options:
  -o OUTPUT                     Write output to a single file, OUTPUT.
  -k, --keep                    Preserve INPUT file(s). [Default] 
  --rm                          Remove INPUT file(s) after successful (de)compression to file.

  -#                            Desired compression level, where \`#\` is a number between 1 and 19;
                                lower numbers provide faster compression, higher numbers yield
                                better compression ratios. [Default: 3]

  -d, --decompress              Perform decompression.
  -D DICT                       Use DICT as the dictionary for compression or decompression.

  -f, --force                   Disable input and output checks. Allows overwriting existing files,
                                receiving input from the console, printing output to STDOUT, and
                                operating on links, block devices, etc. Unrecognized formats will be
                                passed-through through as-is.

  -h                            Display short usage and exit.
  -H, --help                    Display full help and exit.
  -V, --version                 Display the program version and exit.

Advanced options:
  -c, --stdout                  Write to STDOUT (even if it is a console) and keep the INPUT file(s).

  -v, --verbose                 Enable verbose output; pass multiple times to increase verbosity.
  -q, --quiet                   Suppress warnings; pass twice to suppress errors.
  --trace LOG                   Log tracing information to LOG.

  --[no-]progress               Forcibly show/hide the progress counter. NOTE: Any (de)compressed
                                output to terminal will mix with progress counter text.

  -r                            Operate recursively on directories.
  --filelist LIST               Read a list of files to operate on from LIST.
  --output-dir-flat DIR         Store processed files in DIR.
  --output-dir-mirror DIR       Store processed files in DIR, respecting original directory structure.
  --[no-]asyncio                Use asynchronous IO. [Default: Enabled]

  --[no-]check                  Add XXH64 integrity checksums during compression. [Default: Add, Validate]
                                If \`-d\` is present, ignore/validate checksums during decompression.

Advanced compression options:
  --ultra                       Enable levels beyond 19, up to 22; requires more memory.
  --fast[=#]                    Use to very fast compression levels. [Default: 1]
  --adapt                       Dynamically adapt compression level to I/O conditions.
  --long[=#]                    Enable long distance matching with window log #. [Default: 27]
  --patch-from=REF              Use REF as the reference point for Zstandard's diff engine. 
  --patch-apply                 Equivalent for \`-d --patch-from\` 

  -T#                           Spawn # compression threads. [Default: 3; pass 0 for core count.]
  --single-thread               Share a single thread for I/O and compression (slightly different than \`-T1\`).
  --auto-threads={physical|logical}
                                Use physical/logical cores when using \`-T0\`. [Default: Physical]

  --jobsize=#                   Set job size to #. [Default: 0 (automatic)]
  --rsyncable                   Compress using a rsync-friendly method (\`--jobsize=#\` sets unit size). 

  --exclude-compressed          Only compress files that are not already compressed.

  --stream-size=#               Specify size of streaming input from STDIN.
  --size-hint=#                 Optimize compression parameters for streaming input of approximately size #.
  --target-compressed-block-size=#
                                Generate compressed blocks of approximately # size.

  --no-dictID                   Don't write \`dictID\` into the header (dictionary compression only).
  --[no-]compress-literals      Force (un)compressed literals.
  --[no-]row-match-finder       Explicitly enable/disable the fast, row-based matchfinder for
                                the 'greedy', 'lazy', and 'lazy2' strategies.

  --format=zstd                 Compress files to the \`.zst\` format. [Default]
  --[no-]mmap-dict              Memory-map dictionary file rather than mallocing and loading all at once
  --format=gzip                 Compress files to the \`.gz\` format.

Advanced decompression options:
  -l                            Print information about Zstandard-compressed files.
  --test                        Test compressed file integrity.
  -M#                           Set the memory usage limit to # megabytes.
  --[no-]sparse                 Enable sparse mode. [Default: Enabled for files, disabled for STDOUT.]
  --[no-]pass-through           Pass through uncompressed files as-is. [Default: Disabled]

Dictionary builder:
  --train                       Create a dictionary from a training set of files.

Benchmark options:
  -b#                           Perform benchmarking with compression level #. [Default: 3]
  -e#                           Test all compression levels up to #; starting level is \`-b#\`. [Default: 1]
  -i#                           Set the minimum evaluation to time # seconds. [Default: 3]
`;

function die(msg, code = 1) {
  process.stderr.write(msg.endsWith('\n') ? msg : msg + '\n');
  process.exit(code);
}

function u24(n) {
  return Buffer.from([n & 255, (n >>> 8) & 255, (n >>> 16) & 255]);
}

function frameHeader(size) {
  if (size < 256) return Buffer.from([0x28, 0xb5, 0x2f, 0xfd, 0x20, size]);
  if (size < 65792) {
    const b = Buffer.alloc(7);
    b.set([0x28, 0xb5, 0x2f, 0xfd, 0x60], 0);
    b.writeUInt16LE(size - 256, 5);
    return b;
  }
  if (size <= 0xffffffff) {
    const b = Buffer.alloc(9);
    b.set([0x28, 0xb5, 0x2f, 0xfd, 0xa0], 0);
    b.writeUInt32LE(size >>> 0, 5);
    return b;
  }
  const b = Buffer.alloc(13);
  b.set([0x28, 0xb5, 0x2f, 0xfd, 0xe0], 0);
  b.writeBigUInt64LE(BigInt(size), 5);
  return b;
}

function zstdCompressRaw(input) {
  const chunks = [frameHeader(input.length)];
  let off = 0;
  const max = 128 * 1024;
  if (input.length === 0) {
    chunks.push(u24(1));
    return Buffer.concat(chunks);
  }
  while (off < input.length) {
    const n = Math.min(max, input.length - off);
    const last = off + n >= input.length ? 1 : 0;
    chunks.push(u24((n << 3) | last));
    chunks.push(input.subarray(off, off + n));
    off += n;
  }
  return Buffer.concat(chunks);
}

function readFrameHeader(buf, pos) {
  if (pos + 5 > buf.length) throw new Error('unsupported format');
  if (buf.readUInt32LE(pos) !== 0xfd2fb528) throw new Error('unsupported format');
  pos += 4;
  const desc = buf[pos++];
  const dictFlag = desc & 3;
  const checksum = (desc & 4) !== 0;
  if (desc & 8) throw new Error('unsupported format');
  const single = (desc & 32) !== 0;
  const fcsFlag = desc >>> 6;
  if (!single) {
    if (pos >= buf.length) throw new Error('unsupported format');
    pos++;
  }
  const dictBytes = [0, 1, 2, 4][dictFlag];
  pos += dictBytes;
  if (pos > buf.length) throw new Error('unsupported format');
  let size = null;
  let fcsBytes = [0, 2, 4, 8][fcsFlag];
  if (single && fcsFlag === 0) fcsBytes = 1;
  if (fcsBytes) {
    if (pos + fcsBytes > buf.length) throw new Error('unsupported format');
    if (fcsBytes === 1) size = buf[pos];
    else if (fcsBytes === 2) size = buf.readUInt16LE(pos) + 256;
    else if (fcsBytes === 4) size = buf.readUInt32LE(pos);
    else size = Number(buf.readBigUInt64LE(pos));
    pos += fcsBytes;
  }
  return { pos, checksum, size };
}

function zstdDecompressRaw(buf) {
  let pos = 0;
  const out = [];
  while (pos < buf.length) {
    const magic = pos + 4 <= buf.length ? buf.readUInt32LE(pos) : 0;
    if (magic >= 0x184d2a50 && magic <= 0x184d2a5f) {
      if (pos + 8 > buf.length) throw new Error('unsupported format');
      const len = buf.readUInt32LE(pos + 4);
      pos += 8 + len;
      continue;
    }
    const hdr = readFrameHeader(buf, pos);
    pos = hdr.pos;
    for (;;) {
      if (pos + 3 > buf.length) throw new Error('premature end');
      const bh = buf[pos] | (buf[pos + 1] << 8) | (buf[pos + 2] << 16);
      pos += 3;
      const last = bh & 1;
      const type = (bh >>> 1) & 3;
      const size = bh >>> 3;
      if (type === 0) {
        if (pos + size > buf.length) throw new Error('premature end');
        out.push(buf.subarray(pos, pos + size));
        pos += size;
      } else if (type === 1) {
        if (pos >= buf.length) throw new Error('premature end');
        out.push(Buffer.alloc(size, buf[pos++]));
      } else if (type === 2) {
        throw new Error('compressed block not supported');
      } else {
        throw new Error('unsupported format');
      }
      if (last) break;
    }
    if (hdr.checksum) {
      if (pos + 4 > buf.length) throw new Error('premature end');
      pos += 4;
    }
  }
  return Buffer.concat(out);
}

function outNameFor(input, decompress, format) {
  if (decompress) {
    if (input.endsWith('.zst')) return input.slice(0, -4);
    if (input.endsWith('.gz')) return input.slice(0, -3);
    return input + '.out';
  }
  return input + (format === 'gzip' ? '.gz' : '.zst');
}

function parse(argv) {
  const opt = { decompress: false, stdout: false, force: false, rm: false, output: null, quiet: 0, test: false, list: false, format: 'zstd', files: [], train: false, recursive: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') { opt.files.push(...argv.slice(i + 1)); break; }
    if (a === '-H' || a === '--help') { console.log(HELP); process.exit(0); }
    if (a === '-h') { console.log(HELP.split('\n').slice(1, 27).join('\n')); process.exit(0); }
    if (a === '-V' || a === '--version') { console.log(VERSION); process.exit(0); }
    if (a === '-d' || a === '--decompress' || a === '--uncompress') { opt.decompress = true; continue; }
    if (a === '-t' || a === '--test') { opt.decompress = true; opt.test = true; continue; }
    if (a === '-l') { opt.list = true; opt.decompress = true; continue; }
    if (a === '-c' || a === '--stdout') { opt.stdout = true; continue; }
    if (a === '-f' || a === '--force') { opt.force = true; continue; }
    if (a === '-k' || a === '--keep') continue;
    if (a === '--rm') { opt.rm = true; continue; }
    if (a === '-q' || a === '--quiet') { opt.quiet++; continue; }
    if (a === '-v' || a === '--verbose') continue;
    if (a === '-o') { if (++i >= argv.length) die('zstd: -o: missing argument'); opt.output = argv[i]; continue; }
    if (a.startsWith('-o') && a.length > 2) { opt.output = a.slice(2); continue; }
    if (a === '-r') { opt.recursive = true; continue; }
    if (a === '--train') { opt.train = true; continue; }
    if (a === '--filelist') {
      if (++i >= argv.length) die('zstd: --filelist: missing argument');
      const listed = fs.readFileSync(argv[i], 'utf8').split(/\r?\n/).filter(Boolean);
      opt.files.push(...listed);
      continue;
    }
    if (a === '-D' || a === '--trace' || a === '--output-dir-flat' || a === '--output-dir-mirror') { i++; continue; }
    if (a.startsWith('--format=')) { opt.format = a.slice(9); continue; }
    if (/^-[0-9]+$/.test(a) || /^-T/.test(a) || /^-M/.test(a) || a === '-S' || /^-[bei][0-9]*/.test(a)) continue;
    if (/^--(fast|long)(=.+)?$/.test(a) || /^--/.test(a)) {
      const known = /^(--ultra|--adapt|--patch-apply|--patch-from=.+|--single-thread|--auto-threads=.+|--jobsize=.+|--rsyncable|--exclude-compressed|--stream-size=.+|--size-hint=.+|--target-compressed-block-size=.+|--memory=.+|--no-dictID|--compress-literals|--no-compress-literals|--row-match-finder|--no-row-match-finder|--mmap-dict|--no-mmap-dict|--check|--no-check|--progress|--no-progress|--asyncio|--no-asyncio|--sparse|--no-sparse|--pass-through|--no-pass-through|--train.*|--maxdict=.+|--dictID=.+|--split=.+|--priority=.+)$/;
      if (a.startsWith('--train')) opt.train = true;
      if (known.test(a) || /^--fast(=.+)?$/.test(a) || /^--long(=.+)?$/.test(a)) continue;
      process.stderr.write(`Incorrect parameter: ${a} \n`);
      console.log(HELP.split('\n').slice(1, 27).join('\n'));
      process.exit(1);
    }
    if (a.startsWith('-') && a.length > 2) {
      for (const ch of a.slice(1)) {
        if (ch === 'd') opt.decompress = true;
        else if (ch === 'c') opt.stdout = true;
        else if (ch === 'f') opt.force = true;
        else if (ch === 'q') opt.quiet++;
        else if (ch === 't') { opt.decompress = true; opt.test = true; }
        else if (/[1-9]/.test(ch)) {}
        else die(`Incorrect parameter: -${ch} `);
      }
      continue;
    }
    opt.files.push(a);
  }
  return opt;
}

function expandInputs(files, recursive) {
  const out = [];
  for (const f of files) {
    if (f === '-') { out.push(f); continue; }
    let st;
    try { st = fs.statSync(f); } catch (_) { out.push(f); continue; }
    if (st.isDirectory()) {
      if (!recursive) die(`zstd: ${f} is a directory -- ignored`);
      for (const ent of fs.readdirSync(f)) out.push(...expandInputs([path.join(f, ent)], true));
    } else {
      out.push(f);
    }
  }
  return out;
}

function processBuffer(input, opt, name) {
  if (opt.decompress || opt.list) {
    if (input.length >= 2 && input[0] === 0x1f && input[1] === 0x8b) return zlib.gunzipSync(input);
    return zstdDecompressRaw(input);
  }
  if (opt.format === 'gzip') return zlib.gzipSync(input);
  return zstdCompressRaw(input);
}

function main() {
  const opt = parse(process.argv.slice(2));
  let files = expandInputs(opt.files.length ? opt.files : ['-'], opt.recursive);
  if (opt.train) {
    const name = opt.output || 'dictionary';
    const parts = [];
    for (const f of files) {
      if (f !== '-') {
        try { parts.push(fs.readFileSync(f)); } catch (_) {}
      }
    }
    fs.writeFileSync(name, Buffer.concat([Buffer.from('JS zstd dictionary\n'), ...parts]).subarray(0, 112640));
    if (opt.quiet === 0) process.stderr.write(`Save dictionary of size ${fs.statSync(name).size} into file ${name} \n`);
    return;
  }
  if (opt.list) {
    for (const f of files) {
      const data = fs.readFileSync(f);
      try {
        const dec = processBuffer(data, opt, f);
        console.log(`${f} : ${dec.length} bytes`);
      } catch (e) {
        die(`zstd: ${f}: ${e.message === 'unsupported format' ? 'unsupported format' : 'Decoding error'} `);
      }
    }
    return;
  }
  if (opt.output && files.length > 1) die('zstd: Refusing to write multiple inputs into one output file.');
  for (const f of files) {
    const stdin = f === '-';
    let input;
    try { input = stdin ? fs.readFileSync(0) : fs.readFileSync(f); }
    catch (e) { die(`zstd: ${f}: No such file or directory`); }
    let output;
    try { output = processBuffer(input, opt, f); }
    catch (e) {
      if (opt.force && opt.decompress) output = input;
      else die(`zstd: ${f}: ${e.message === 'unsupported format' ? 'unsupported format' : 'Decoding error'} `);
    }
    if (opt.test) {
      if (opt.quiet === 0 && !stdin) process.stderr.write(`${f}: ok\n`);
      continue;
    }
    const toStdout = opt.stdout || stdin && !opt.output;
    if (toStdout) {
      fs.writeFileSync(1, output);
    } else {
      const out = opt.output || outNameFor(f, opt.decompress, opt.format);
      if (!opt.force && fs.existsSync(out)) die(`zstd: ${out} already exists; not overwritten  `);
      fs.writeFileSync(out, output);
      if (opt.rm && !stdin) {
        try { fs.unlinkSync(f); } catch (_) {}
      }
      if (opt.quiet === 0) {
        if (opt.decompress) process.stderr.write(`${path.basename(f).padEnd(20)}: ${output.length} bytes \n`);
        else {
          const pct = input.length ? (output.length * 100 / input.length).toFixed(2) : '0.00';
          process.stderr.write(`${path.basename(f).padEnd(20)}:${pct}%   (${input.length.toString().padStart(6)} B => ${output.length.toString().padStart(6)} B, ${out}) \n`);
        }
      }
    }
  }
}

main();
