#include <dlfcn.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ZSTD_CONTENTSIZE_UNKNOWN ((unsigned long long)-1)
#define ZSTD_CONTENTSIZE_ERROR ((unsigned long long)-2)

typedef size_t (*fn_compressBound)(size_t);
typedef size_t (*fn_compress)(void *, size_t, const void *, size_t, int);
typedef void *(*fn_createCCtx)(void);
typedef size_t (*fn_freeCCtx)(void *);
typedef size_t (*fn_compress_usingDict)(void *, void *, size_t, const void *, size_t, const void *, size_t, int);
typedef unsigned long long (*fn_getFrameContentSize)(const void *, size_t);
typedef unsigned long long (*fn_findDecompressedSize)(const void *, size_t);
typedef size_t (*fn_findFrameCompressedSize)(const void *, size_t);
typedef size_t (*fn_decompress)(void *, size_t, const void *, size_t);
typedef void *(*fn_createDCtx)(void);
typedef size_t (*fn_freeDCtx)(void *);
typedef size_t (*fn_decompress_usingDict)(void *, void *, size_t, const void *, size_t, const void *, size_t);
typedef unsigned (*fn_isError)(size_t);
typedef const char *(*fn_getErrorName)(size_t);

static fn_compressBound p_compressBound;
static fn_compress p_compress;
static fn_createCCtx p_createCCtx;
static fn_freeCCtx p_freeCCtx;
static fn_compress_usingDict p_compress_usingDict;
static fn_getFrameContentSize p_getFrameContentSize;
static fn_findDecompressedSize p_findDecompressedSize;
static fn_findFrameCompressedSize p_findFrameCompressedSize;
static fn_decompress p_decompress;
static fn_createDCtx p_createDCtx;
static fn_freeDCtx p_freeDCtx;
static fn_decompress_usingDict p_decompress_usingDict;
static fn_isError p_isError;
static fn_getErrorName p_getErrorName;

static void *need(void *lib, const char *name) {
    void *sym = dlsym(lib, name);
    if (!sym) {
        fprintf(stderr, "zstd_helper: missing symbol %s\n", name);
        exit(2);
    }
    return sym;
}

static void load_zstd(void) {
    void *lib = dlopen("libzstd.so.1", RTLD_NOW);
    if (!lib) {
        fprintf(stderr, "zstd_helper: cannot load libzstd.so.1: %s\n", dlerror());
        exit(2);
    }
    p_compressBound = (fn_compressBound)need(lib, "ZSTD_compressBound");
    p_compress = (fn_compress)need(lib, "ZSTD_compress");
    p_createCCtx = (fn_createCCtx)need(lib, "ZSTD_createCCtx");
    p_freeCCtx = (fn_freeCCtx)need(lib, "ZSTD_freeCCtx");
    p_compress_usingDict = (fn_compress_usingDict)need(lib, "ZSTD_compress_usingDict");
    p_getFrameContentSize = (fn_getFrameContentSize)need(lib, "ZSTD_getFrameContentSize");
    p_findDecompressedSize = (fn_findDecompressedSize)need(lib, "ZSTD_findDecompressedSize");
    p_findFrameCompressedSize = (fn_findFrameCompressedSize)need(lib, "ZSTD_findFrameCompressedSize");
    p_decompress = (fn_decompress)need(lib, "ZSTD_decompress");
    p_createDCtx = (fn_createDCtx)need(lib, "ZSTD_createDCtx");
    p_freeDCtx = (fn_freeDCtx)need(lib, "ZSTD_freeDCtx");
    p_decompress_usingDict = (fn_decompress_usingDict)need(lib, "ZSTD_decompress_usingDict");
    p_isError = (fn_isError)need(lib, "ZSTD_isError");
    p_getErrorName = (fn_getErrorName)need(lib, "ZSTD_getErrorName");
}

static unsigned char *read_all(FILE *f, size_t *size) {
    size_t cap = 65536, len = 0;
    unsigned char *buf = (unsigned char *)malloc(cap);
    if (!buf) {
        perror("malloc");
        exit(2);
    }
    for (;;) {
        if (len == cap) {
            cap *= 2;
            unsigned char *nb = (unsigned char *)realloc(buf, cap);
            if (!nb) {
                perror("realloc");
                free(buf);
                exit(2);
            }
            buf = nb;
        }
        size_t n = fread(buf + len, 1, cap - len, f);
        len += n;
        if (n == 0) {
            if (ferror(f)) {
                perror("read");
                free(buf);
                exit(2);
            }
            break;
        }
    }
    *size = len;
    return buf;
}

static unsigned char *read_file(const char *path, size_t *size) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "zstd_helper: %s: %s\n", path, strerror(errno));
        exit(2);
    }
    unsigned char *buf = read_all(f, size);
    fclose(f);
    return buf;
}

static int write_all(const unsigned char *buf, size_t size) {
    return fwrite(buf, 1, size, stdout) == size ? 0 : 2;
}

static int do_compress(int argc, char **argv) {
    int level = argc > 2 ? atoi(argv[2]) : 3;
    const char *dict_path = argc > 3 ? argv[3] : "-";
    size_t src_size = 0, dict_size = 0;
    unsigned char *src = read_all(stdin, &src_size);
    unsigned char *dict = NULL;
    if (dict_path && strcmp(dict_path, "-") != 0) dict = read_file(dict_path, &dict_size);
    size_t bound = p_compressBound(src_size);
    unsigned char *dst = (unsigned char *)malloc(bound ? bound : 1);
    if (!dst) {
        perror("malloc");
        return 2;
    }
    size_t got;
    if (dict) {
        void *ctx = p_createCCtx();
        got = p_compress_usingDict(ctx, dst, bound, src, src_size, dict, dict_size, level);
        p_freeCCtx(ctx);
    } else {
        got = p_compress(dst, bound, src, src_size, level);
    }
    if (p_isError(got)) {
        fprintf(stderr, "%s\n", p_getErrorName(got));
        return 1;
    }
    int rc = write_all(dst, got);
    free(dst);
    free(src);
    free(dict);
    return rc;
}

static int do_decompress(int argc, char **argv) {
    const char *dict_path = argc > 2 ? argv[2] : "-";
    size_t src_size = 0, dict_size = 0;
    unsigned char *src = read_all(stdin, &src_size);
    unsigned char *dict = NULL;
    if (dict_path && strcmp(dict_path, "-") != 0) dict = read_file(dict_path, &dict_size);

    unsigned long long total = p_findDecompressedSize(src, src_size);
    if (total == ZSTD_CONTENTSIZE_ERROR || total == ZSTD_CONTENTSIZE_UNKNOWN) {
        total = p_getFrameContentSize(src, src_size);
    }
    if (total == ZSTD_CONTENTSIZE_ERROR) {
        fprintf(stderr, "unsupported format\n");
        return 3;
    }
    if (total == ZSTD_CONTENTSIZE_UNKNOWN) {
        fprintf(stderr, "could not determine decompressed size\n");
        return 1;
    }

    unsigned char *dst = (unsigned char *)malloc((size_t)total + 1);
    if (!dst) {
        perror("malloc");
        return 2;
    }
    size_t got;
    if (dict) {
        void *ctx = p_createDCtx();
        got = p_decompress_usingDict(ctx, dst, (size_t)total, src, src_size, dict, dict_size);
        p_freeDCtx(ctx);
    } else {
        got = p_decompress(dst, (size_t)total, src, src_size);
    }
    if (p_isError(got)) {
        fprintf(stderr, "%s\n", p_getErrorName(got));
        return 1;
    }
    int rc = write_all(dst, got);
    free(dst);
    free(src);
    free(dict);
    return rc;
}

static int do_info(void) {
    size_t src_size = 0;
    unsigned char *src = read_all(stdin, &src_size);
    unsigned long long total = p_findDecompressedSize(src, src_size);
    if (total == ZSTD_CONTENTSIZE_ERROR || total == ZSTD_CONTENTSIZE_UNKNOWN) {
        total = p_getFrameContentSize(src, src_size);
    }
    if (total == ZSTD_CONTENTSIZE_ERROR) {
        fprintf(stderr, "unsupported format\n");
        return 3;
    }
    printf("%llu %zu\n", total, src_size);
    free(src);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: zstd_helper c|d|i ...\n");
        return 2;
    }
    load_zstd();
    if (strcmp(argv[1], "c") == 0) return do_compress(argc, argv);
    if (strcmp(argv[1], "d") == 0) return do_decompress(argc, argv);
    if (strcmp(argv[1], "i") == 0) return do_info();
    fprintf(stderr, "usage: zstd_helper c|d|i ...\n");
    return 2;
}
