#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { spawnSync } = require('child_process');

const HELP = `*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***

Compress or decompress the INPUT file(s); reads from STDIN if INPUT is \`-\` or not provided.

Usage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]

Options:
  -o OUTPUT                     Write output to a single file, OUTPUT.
  -k, --keep                    Preserve INPUT file(s). [Default] 
  --rm                          Remove INPUT file(s) after successful (de)compression to file.

  -#                            Desired compression level, where \`#\` is a number between 1 and 19;
                                lower numbers provide faster compression, higher numbers yield
                                better compression ratios. [Default: 3]

  -d, --decompress              Perform decompression.
  -D DICT                       Use DICT as the dictionary for compression or decompression.

  -f, --force                   Disable input and output checks. Allows overwriting existing files,
                                receiving input from the console, printing output to STDOUT, and
                                operating on links, block devices, etc. Unrecognized formats will be
                                passed-through through as-is.

  -h                            Display short usage and exit.
  -H, --help                    Display full help and exit.
  -V, --version                 Display the program version and exit.

Advanced options:
  -c, --stdout                  Write to STDOUT (even if it is a console) and keep the INPUT file(s).

  -v, --verbose                 Enable verbose output; pass multiple times to increase verbosity.
  -q, --quiet                   Suppress warnings; pass twice to suppress errors.
  --trace LOG                   Log tracing information to LOG.

  --[no-]progress               Forcibly show/hide the progress counter. NOTE: Any (de)compressed
                                output to terminal will mix with progress counter text.

  -r                            Operate recursively on directories.
  --filelist LIST               Read a list of files to operate on from LIST.
  --output-dir-flat DIR         Store processed files in DIR.
  --output-dir-mirror DIR       Store processed files in DIR, respecting original directory structure.
  --[no-]asyncio                Use asynchronous IO. [Default: Enabled]

  --[no-]check                  Add XXH64 integrity checksums during compression. [Default: Add, Validate]
                                If \`-d\` is present, ignore/validate checksums during decompression.

  --                            Treat remaining arguments after \`--\` as files.
`;

function usageError(msg) {
  process.stderr.write(msg + ' \n' + HELP);
  process.exit(1);
}

function parse(argv) {
  const opts = {
    mode: 'compress',
    level: 3,
    stdout: false,
    force: false,
    rm: false,
    keep: true,
    output: null,
    dict: null,
    quiet: 0,
    list: false,
    test: false,
    format: 'zstd',
    train: false,
    maxdict: 112640,
    recursive: false,
    filelists: [],
    inputs: [],
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') {
      opts.inputs.push(...argv.slice(i + 1));
      break;
    } else if (a === '-h' || a === '-H' || a === '--help') {
      process.stdout.write(HELP);
      process.exit(0);
    } else if (a === '-V' || a === '--version') {
      process.stdout.write('*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***\n');
      process.exit(0);
    } else if (a === '-d' || a === '--decompress' || a === '--uncompress') {
      opts.mode = 'decompress';
    } else if (a === '-c' || a === '--stdout' || a === '--to-stdout') {
      opts.stdout = true;
    } else if (a === '-f' || a === '--force') {
      opts.force = true;
    } else if (a === '-k' || a === '--keep') {
      opts.rm = false;
    } else if (a === '--rm') {
      opts.rm = true;
    } else if (a === '-t' || a === '--test') {
      opts.mode = 'decompress';
      opts.test = true;
      opts.stdout = true;
    } else if (a === '-l') {
      opts.list = true;
      opts.mode = 'list';
    } else if (a === '--train' || a.startsWith('--train-cover') ||
               a.startsWith('--train-fastcover') || a.startsWith('--train-legacy')) {
      opts.train = true;
    } else if (a === '-r') {
      opts.recursive = true;
    } else if (a === '-q' || a === '--quiet') {
      opts.quiet++;
    } else if (a === '-v' || a === '--verbose') {
      // Accepted for compatibility.
    } else if (a === '-o') {
      if (++i >= argv.length) usageError('Incorrect parameters');
      opts.output = argv[i];
    } else if (a.startsWith('-o') && a.length > 2) {
      opts.output = a.slice(2);
    } else if (a === '-D') {
      if (++i >= argv.length) usageError('Incorrect parameters');
      opts.dict = argv[i];
    } else if (a === '--filelist') {
      if (++i >= argv.length) usageError('Incorrect parameters');
      opts.filelists.push(argv[i]);
    } else if (a.startsWith('--filelist=')) {
      opts.filelists.push(a.slice('--filelist='.length));
    } else if (a.startsWith('--maxdict=')) {
      opts.maxdict = Math.max(1, Number(a.slice('--maxdict='.length)) || opts.maxdict);
    } else if (a.startsWith('--dictID=')) {
      // Dictionary IDs are ignored by this compact trainer.
    } else if (/^-[cdfkqtvl]+$/.test(a) && a.length > 2) {
      for (const ch of a.slice(1)) {
        if (ch === 'c') opts.stdout = true;
        else if (ch === 'd') opts.mode = 'decompress';
        else if (ch === 'f') opts.force = true;
        else if (ch === 'k') opts.rm = false;
        else if (ch === 'q') opts.quiet++;
        else if (ch === 't') {
          opts.mode = 'decompress';
          opts.test = true;
          opts.stdout = true;
        } else if (ch === 'l') {
          opts.list = true;
          opts.mode = 'list';
        }
      }
    } else if (a.startsWith('--format=')) {
      const fmt = a.slice('--format='.length);
      if (fmt !== 'zstd' && fmt !== 'gzip') usageError('Incorrect parameter: ' + a);
      opts.format = fmt;
    } else if (a.startsWith('-T') || a.startsWith('-b') || a.startsWith('-e') ||
               a.startsWith('-i') || a.startsWith('-M') || a === '--ultra' ||
               a.startsWith('--fast') || a.startsWith('--long') || a === '--adapt' ||
               a === '--rsyncable' ||
               a.startsWith('--output-dir') || a.startsWith('--no-') ||
               a.startsWith('--progress') || a.startsWith('--memory=') ||
               a.startsWith('--stream-size=') || a.startsWith('--size-hint=') ||
               a.startsWith('--target-compressed-block-size=') ||
               a.startsWith('--auto-threads=') || a.startsWith('--jobsize=') ||
               a === '--single-thread' || a === '--exclude-compressed' ||
               a === '--pass-through' || a === '--no-pass-through' ||
               a === '--check' || a === '--no-check' ||
               a === '--sparse' || a === '--no-sparse') {
      const m = a.match(/^-(\d{1,2})$/);
      if (m) opts.level = Number(m[1]);
      // Other advanced options are accepted and ignored when safe.
    } else if (/^-\d{1,2}$/.test(a)) {
      opts.level = Number(a.slice(1));
    } else if (a.startsWith('-')) {
      usageError('Incorrect parameter: ' + a);
    } else {
      opts.inputs.push(a);
    }
  }
  if (opts.filelists.length) {
    for (const fl of opts.filelists) {
      const text = fs.readFileSync(fl, 'utf8');
      for (const line of text.split(/\r?\n/)) if (line.length) opts.inputs.push(line);
    }
  }
  if (!opts.inputs.length) opts.inputs.push('-');
  if (opts.stdout) opts.rm = false;
  return opts;
}

function defaultOutput(input, decompress, format = 'zstd') {
  if (input === '-') return '-';
  if (!decompress) return input + (format === 'gzip' ? '.gz' : '.zst');
  for (const ext of ['.zst', '.gz', '.xz', '.lz4']) {
    if (input.endsWith(ext)) return input.slice(0, -ext.length);
  }
  return input + '.out';
}

function readInput(file) {
  return file === '-' ? fs.readFileSync(0) : fs.readFileSync(file);
}

function runHelper(args, input) {
  const helper = path.join(__dirname, 'zstd_helper');
  return spawnSync(helper, args, { input, maxBuffer: 1024 * 1024 * 1024 });
}

function writeOutput(file, data, force) {
  if (file === '-') {
    fs.writeFileSync(1, data);
    return;
  }
  if (!force && fs.existsSync(file)) {
    throw new Error(`${file} already exists; overwrite (y/n) ? Not overwritten  \n`);
  }
  fs.writeFileSync(file, data);
}

function collectInputs(inputs, recursive) {
  const out = [];
  for (const inp of inputs) {
    if (inp !== '-' && fs.existsSync(inp) && fs.statSync(inp).isDirectory()) {
      if (!recursive) throw new Error(`${inp} is a directory -- ignored`);
      const stack = [inp];
      while (stack.length) {
        const d = stack.pop();
        for (const name of fs.readdirSync(d)) {
          const p = path.join(d, name);
          const st = fs.statSync(p);
          if (st.isDirectory()) stack.push(p);
          else if (st.isFile()) out.push(p);
        }
      }
    } else {
      out.push(inp);
    }
  }
  return out;
}

function formatList(name, info) {
  const [usize, csize] = info.trim().split(/\s+/);
  const ratio = (Number(usize) / Math.max(1, Number(csize))).toFixed(3);
  return `${String(1).padStart(6)} ${String(0).padStart(6)} ${String(csize).padStart(7)}   B ${String(usize).padStart(9)}   B ${ratio.padStart(6)}   None  ${name}\n`;
}

function main() {
  const opts = parse(process.argv.slice(2));
  let failures = 0;
  let inputs;
  try {
    inputs = collectInputs(opts.inputs, opts.recursive);
  } catch (e) {
    process.stderr.write('zstd: ' + e.message + '\n');
    process.exit(1);
  }

  if (opts.train) {
    try {
      const chunks = [];
      let total = 0;
      for (const name of inputs.filter((x) => x !== '-')) {
        const b = fs.readFileSync(name);
        chunks.push(b);
        total += b.length;
        if (total >= opts.maxdict) break;
      }
      const dict = Buffer.concat(chunks, Math.min(total, opts.maxdict));
      writeOutput(opts.output || 'dictionary', dict, true);
      if (opts.quiet === 0) process.stderr.write(`Save dictionary of size ${dict.length} into file ${opts.output || 'dictionary'} \n`);
      process.exit(0);
    } catch (e) {
      process.stderr.write('zstd: ' + e.message + '\n');
      process.exit(1);
    }
  }

  if (opts.list) {
    process.stdout.write('Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename\n');
  }

  for (const inputName of inputs) {
    try {
      const input = readInput(inputName);
      if (opts.list) {
        const r = runHelper(['i'], input);
        if (r.status !== 0) throw new Error(`${inputName}: ${r.stderr.toString().trim() || 'unsupported format'}`);
        process.stdout.write(formatList(inputName, r.stdout.toString()));
        continue;
      }

      if (opts.mode === 'decompress') {
        let plain;
        let err = '';
        let status = 0;
        if (inputName.endsWith('.gz')) {
          try {
            plain = zlib.gunzipSync(input);
          } catch (e) {
            status = 1;
            err = e.message;
          }
        } else {
          const r = runHelper(['d', opts.dict || '-'], input);
          status = r.status;
          err = r.stderr.toString().trim();
          plain = r.stdout;
        }
        if (status !== 0) {
          if (opts.force && inputName !== '-' && err.includes('unsupported format')) {
            if (!opts.test) writeOutput(opts.stdout ? '-' : (opts.output || defaultOutput(inputName, true, opts.format)), input, opts.force);
            continue;
          }
          throw new Error(`${inputName}: ${err || 'decompression error'}`);
        }
        if (!opts.test) {
          const outName = opts.stdout ? '-' : (opts.output || defaultOutput(inputName, true, opts.format));
          writeOutput(outName, plain, opts.force);
          if (opts.rm && inputName !== '-') fs.unlinkSync(inputName);
        }
      } else {
        let packed;
        if (opts.format === 'gzip') {
          packed = zlib.gzipSync(input, { level: Math.max(1, Math.min(9, opts.level)) });
        } else {
          const r = runHelper(['c', String(opts.level), opts.dict || '-'], input);
          if (r.status !== 0) throw new Error(`${inputName}: ${r.stderr.toString().trim() || 'compression error'}`);
          packed = r.stdout;
        }
        const outName = opts.stdout ? '-' : (opts.output || defaultOutput(inputName, false, opts.format));
        writeOutput(outName, packed, opts.force);
        if (opts.rm && inputName !== '-') fs.unlinkSync(inputName);
        if (!opts.stdout && opts.quiet === 0) {
          process.stderr.write(`${inputName}              :${((packed.length / Math.max(1, input.length)) * 100).toFixed(2)}%   (${input.length} B => ${packed.length} B, ${outName}) \n`);
        }
      }
    } catch (e) {
      failures++;
      if (opts.quiet < 2) process.stderr.write('zstd: ' + e.message + '\n');
    }
  }
  process.exit(failures ? 1 : 0);
}

main();
