#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');

const VERSION = '5.2';

const HELP = `usage: nnn [OPTIONS] [PATH]

The unorthodox terminal file manager.

positional args:
  PATH   start dir/file [default: .]

optional args:
 -a      auto NNN_FIFO
 -A      no dir auto-enter during filter
 -b key  open bookmark key (trumps -s/S)
 -B      use bsdtar for archives
 -c      cli-only NNN_OPENER (trumps -e)
 -C      8-color scheme
 -d      detail mode
 -D      dirs in context color
 -e      text in $VISUAL/$EDITOR/vi
 -E      internal edits in EDITOR
 -f      use history file
 -F val  fifo mode [0:preview 1:explore]
 -g      regex filters
 -H      show hidden files
 -i      show current file info
 -J      no auto-advance on selection
 -K      detect key collision and exit
 -l val  set scroll lines
 -n      type-to-nav mode
 -N      use native prompt
 -o      open files only on Enter
 -p file selection file [-:stdout]
 -P key  run plugin key
 -Q      no quit confirmation
 -r      use advcpmv patched cp, mv
 -R      no rollover at edges
 -s name load session by name
 -S      persistent session
 -t secs timeout to lock
 -T key  sort order [a/d/e/r/s/t/v]
 -u      use selection (no prompt)
 -U      show user and group
 -V      show version
 -x      notis, selection sync, xterm title
 -z      in order fuzzy filters
 -0      null separator in picker mode
 -h      show help

v5.2
BSD 2-Clause
https://github.com/jarun/nnn
`;

const FLAG_OPTS = new Set('aAcBCdDeEfgHiJKnNoQrRSuUVxz0'.split(''));
const ARG_OPTS = new Set(['b', 'F', 'l', 'p', 'P', 's', 't', 'T']);

function progName() {
  const a = process.argv[1] || 'nnn';
  if (a.includes('/')) {
    const cwd = process.cwd();
    const abs = path.resolve(a);
    if (abs.startsWith(cwd + path.sep)) return './' + path.relative(cwd, abs);
  }
  return a;
}

function usageError(msg) {
  process.stderr.write(`${progName()}: ${msg}\n`);
  process.stdout.write(HELP);
  process.exit(1);
}

function parseArgs(argv) {
  const opts = {};
  const paths = [];
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--') {
      paths.push(...argv.slice(i + 1));
      break;
    }
    if (!arg.startsWith('-') || arg === '-') {
      paths.push(arg);
      continue;
    }
    for (let j = 1; j < arg.length; j++) {
      const ch = arg[j];
      if (ch === 'h') {
        process.stdout.write(HELP);
        process.exit(0);
      }
      if (ch === 'V') {
        process.stdout.write(`${VERSION}\n`);
        process.exit(0);
      }
      if (ARG_OPTS.has(ch)) {
        let val = arg.slice(j + 1);
        if (!val) {
          if (i + 1 >= argv.length) usageError(`option requires an argument -- '${ch}'`);
          val = argv[++i];
        }
        opts[ch] = val;
        break;
      }
      if (!FLAG_OPTS.has(ch)) usageError(`invalid option -- '${ch}'`);
      opts[ch] = true;
    }
  }
  return { opts, start: paths[0] || '.' };
}

function ensureStart(target) {
  let p = path.resolve(target);
  try {
    const st = fs.statSync(p);
    if (st.isDirectory()) return { dir: p, focus: null };
    return { dir: path.dirname(p), focus: path.basename(p) };
  } catch {
    if (target.endsWith('/') || target.endsWith(path.sep)) {
      fs.mkdirSync(p, { recursive: true });
      return { dir: p, focus: null };
    }
    const dir = path.dirname(p);
    fs.mkdirSync(dir, { recursive: true });
    return { dir, focus: path.basename(p), missing: true };
  }
}

function modeString(st) {
  const type = st.isDirectory() ? 'd' : st.isSymbolicLink() ? 'l' : '-';
  const bits = ['USR', 'GRP', 'OTH'].map((who, idx) => {
    const shift = (2 - idx) * 3;
    return ((st.mode >> (shift + 2)) & 1 ? 'r' : '-') +
      ((st.mode >> (shift + 1)) & 1 ? 'w' : '-') +
      ((st.mode >> shift) & 1 ? 'x' : '-');
  }).join('');
  return type + bits;
}

function sizeString(n) {
  const units = ['B', 'K', 'M', 'G', 'T'];
  let v = n;
  let u = 0;
  while (v >= 1024 && u < units.length - 1) {
    v /= 1024;
    u++;
  }
  if (u === 0) return `${v}B`;
  return `${Math.round(v)}${units[u]}`;
}

function listEntries(dir, showHidden, sortKey) {
  let names = [];
  try {
    names = fs.readdirSync(dir);
  } catch (err) {
    process.stderr.write(`${err.message}\n`);
    process.exit(1);
  }
  if (!showHidden) names = names.filter(n => !n.startsWith('.'));
  const entries = names.map(name => {
    const full = path.join(dir, name);
    let st;
    try {
      st = fs.lstatSync(full);
    } catch {
      st = null;
    }
    return { name, full, st, isDir: st ? st.isDirectory() : false };
  });
  const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
  entries.sort((a, b) => {
    if (sortKey === 's' && a.st && b.st) return b.st.size - a.st.size || collator.compare(a.name, b.name);
    if (sortKey === 't' && a.st && b.st) return b.st.mtimeMs - a.st.mtimeMs || collator.compare(a.name, b.name);
    if (sortKey === 'e') return collator.compare(path.extname(a.name), path.extname(b.name)) || collator.compare(a.name, b.name);
    if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
    return collator.compare(a.name, b.name);
  });
  if (sortKey === 'r') entries.reverse();
  return entries;
}

function renderPlain(dir, entries, focus, opts) {
  if (entries.length === 0) {
    process.stderr.write('0 entries\n');
    return;
  }
  process.stdout.write(`${dir}\n`);
  entries.forEach((e, idx) => {
    const mark = e.name === focus || (!focus && idx === 0) ? '>' : ' ';
    const suffix = e.isDir ? '/' : '';
    if (opts.d && e.st) {
      process.stdout.write(`${mark} ${modeString(e.st)} ${sizeString(e.st.size).padStart(4)} ${e.name}${suffix}\n`);
    } else {
      process.stdout.write(`${mark} ${e.name}${suffix}\n`);
    }
  });
}

function statusLine(entry, index, total) {
  if (!entry || !entry.st) return `${index + 1}/${total}`;
  const d = entry.st.mtime;
  const stamp = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  const ext = entry.isDir ? '' : ` ${path.extname(entry.name)}`;
  return `${index + 1}/${total}  ${stamp} ${modeString(entry.st)} ${sizeString(entry.st.size)}${ext}`;
}

function renderScreen(dir, entries, focus, opts) {
  const cols = process.stdout.columns || 80;
  let index = Math.max(0, entries.findIndex(e => e.name === focus));
  if (index < 0) index = 0;
  const lines = [];
  lines.push('\x1b[?1049h\x1b[?25l\x1b[H\x1b[2J');
  lines.push('\x1b[7m1\x1b[27m 2 3 4 5 6 7 8 \x1b[4m' + dir + '\x1b[24m');
  const height = Math.max(5, (process.stdout.rows || 24) - 3);
  entries.slice(0, height).forEach((e, i) => {
    const sel = i === index;
    const suffix = e.isDir ? '/' : '';
    lines.push(`${sel ? '\x1b[7m' : ''} ${e.name}${suffix}\x1b[27m`);
  });
  if (entries.length === 0) lines.push('0 entries');
  const active = entries[index];
  lines.push('\x1b[' + (process.stdout.rows || 24) + ';1H' + statusLine(active, index, entries.length || 1).slice(0, cols));
  process.stdout.write(lines.join('\r\n'));
}

function exitScreen() {
  process.stdout.write('\x1b[?25h\x1b[?1049l');
}

function writeSelection(selFile, selected, nul) {
  if (!selFile || !selected) return;
  const text = selected.full + (nul ? '\0' : '\n');
  if (selFile === '-') process.stdout.write(text);
  else fs.appendFileSync(selFile, text);
}

function runInteractive(dir, entries, focus, opts) {
  let index = Math.max(0, entries.findIndex(e => e.name === focus));
  if (index < 0) index = 0;
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    renderPlain(dir, entries, focus, opts);
    return;
  }
  renderScreen(dir, entries, focus, opts);
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.on('data', buf => {
    const s = buf.toString('utf8');
    if (s.includes('q') || s.includes('\x03') || s === '\x1b') {
      process.stdin.setRawMode(false);
      exitScreen();
      process.exit(0);
    }
    if (s === '\r' || s === '\n' || s === ' ') {
      writeSelection(opts.p, entries[index], Boolean(opts['0']));
      if (opts.p) {
        process.stdin.setRawMode(false);
        exitScreen();
        process.exit(0);
      }
    }
    if (s === 'j' || s === '\x1b[B') index = Math.min(entries.length - 1, index + 1);
    if (s === 'k' || s === '\x1b[A') index = Math.max(0, index - 1);
    renderScreen(dir, entries, entries[index] && entries[index].name, opts);
  });
  process.stdin.on('end', () => {
    process.stdin.setRawMode(false);
    exitScreen();
    process.exit(0);
  });
}

function maybeRunPlugin(opts) {
  if (!opts.P) return false;
  const pluginHome = process.env.NNN_PLUG || path.join(os.homedir(), '.config', 'nnn', 'plugins');
  const script = path.join(pluginHome, opts.P);
  if (!fs.existsSync(script)) return false;
  const child = spawn(script, { stdio: 'inherit', shell: true });
  child.on('exit', code => process.exit(code || 0));
  return true;
}

function main() {
  const { opts, start } = parseArgs(process.argv.slice(2));
  if (opts.K) process.exit(0);
  if (maybeRunPlugin(opts)) return;
  const target = ensureStart(start);
  const entries = listEntries(target.dir, Boolean(opts.H), opts.T);
  runInteractive(target.dir, entries, target.focus, opts);
}

main();
