#!/usr/bin/env node
'use strict';

const fs = require('fs');

const HELP = `tuc 1.3.0
Cut text (or bytes) where a delimiter matches, then keep the desired parts.

USAGE:
    tuc [FLAGS] [OPTIONS] < input
    tuc [FLAGS] [OPTIONS] filepath

FLAGS:
    -g, --greedy-delimiter        Match consecutive delimiters as if it was one
    -p, --compress-delimiter      Print only the first delimiter of a sequence
    -s, --only-delimited          Print only lines containing the delimiter
    -V, --version                 Print version information
    -z, --zero-terminated         Line delimiter is NUL (\\0), not LF (\\n)
    -h, --help                    Print this help and exit
    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
    -j, --(no-)join               Print selected parts with delimiter in between
    --json                        Print fields as a JSON array of strings
    --no-mmap                     Disable memory mapping

OPTIONS:
    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.
    -b, --bytes <bounds>          Same as --fields, but it keeps bytes
    -c, --characters <bounds>     Same as --fields, but it keeps characters
    -l, --lines <bounds>          Same as --fields, but it keeps lines
    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text
                                  [default: \\t]
    -e, --regex <some regex>      Use a regular expression as delimiter
    -r, --replace-delimiter <new> Replace the delimiter with the provided text.
    -t, --trim <type>             Trim the delimiter (greedy). Valid values are
                                  (l|L)eft, (r|R)ight, (b|B)oth
        --fallback-oob <fallback> Generic fallback output for any field that
                                  cannot be found (oob stands for out of bound).
    -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.
`;

function die(msg) {
  process.stderr.write(msg + '\n');
  process.exit(1);
}

function nextArg(args, i, opt) {
  if (i + 1 >= args.length) die(`tuc: option '${opt}' requires an argument`);
  return args[i + 1];
}

function parseArgs(argv) {
  const o = {
    mode: 'fields', bounds: '1:', delim: '\t', regex: null, greedy: false,
    compress: false, onlyDelimited: false, zero: false, complement: false,
    join: null, replace: null, trim: null, fallback: undefined, json: false,
    file: null,
    explicitJoin: false, explicitNoJoin: false,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h') { process.stdout.write(HELP); process.exit(0); }
    else if (a === '--version' || a === '-V') { process.stdout.write('tuc 1.3.0\n'); process.exit(0); }
    else if (a === '-g' || a === '--greedy-delimiter') o.greedy = true;
    else if (a === '-p' || a === '--compress-delimiter') o.compress = true;
    else if (a === '-s' || a === '--only-delimited') o.onlyDelimited = true;
    else if (a === '-z' || a === '--zero-terminated') o.zero = true;
    else if (a === '-m' || a === '--complement') o.complement = true;
    else if (a === '-j' || a === '--join') { o.join = true; o.explicitJoin = true; }
    else if (a === '--no-join') { o.join = false; o.explicitNoJoin = true; }
    else if (a === '--json') o.json = true;
    else if (a === '--no-mmap') {}
    else if (a === '-M' || a === '--fixed-memory') { i++; }
    else if (a === '-f' || a === '--fields') { o.mode = 'fields'; o.bounds = nextArg(argv, i, a); i++; }
    else if (a === '-b' || a === '--bytes') { o.mode = 'bytes'; o.bounds = nextArg(argv, i, a); i++; }
    else if (a === '-c' || a === '--characters') { o.mode = 'chars'; o.bounds = nextArg(argv, i, a); i++; }
    else if (a === '-l' || a === '--lines') { o.mode = 'lines'; o.bounds = nextArg(argv, i, a); if (o.join === null) o.join = true; i++; }
    else if (a === '-d' || a === '--delimiter') { o.delim = nextArg(argv, i, a); i++; }
    else if (a === '-e' || a === '--regex') { o.regex = nextArg(argv, i, a); i++; }
    else if (a === '-r' || a === '--replace-delimiter') { o.replace = nextArg(argv, i, a); o.join = true; i++; }
    else if (a === '-t' || a === '--trim') { o.trim = nextArg(argv, i, a).toLowerCase(); o.greedy = true; i++; }
    else if (a === '--fallback-oob') { o.fallback = nextArg(argv, i, a); i++; }
    else if (a.startsWith('-')) die(`tuc: unexpected arguments: ["${a}"]\nTry 'tuc --help' for more information.`);
    else if (o.file === null) o.file = a;
    else die(`tuc: unexpected arguments: ["${a}"]\nTry 'tuc --help' for more information.`);
  }
  if (o.join === null) o.join = false;
  if (o.explicitJoin && o.explicitNoJoin) die("tuc: runtime error. It's not possible to use --join and --no-join simultaneously");
  if (o.mode === 'lines') o.join = true;
  if (o.regex && o.join && o.replace === null) die('tuc: runtime error. Cannot use --regex and --join without --replace-delimiter');
  return o;
}

function parseNum(s, whole) {
  if (!/^-?\d+$/.test(s)) throw new Error(`Not a number \`${s}\``);
  const n = Number(s);
  if (n === 0) throw new Error('Zero is not a valid field');
  return n < 0 ? whole + n + 1 : n;
}

function isFormatSpec(s) {
  return /(^|[^{])\{\-?\d+/.test(s);
}

function parseBounds(spec, whole) {
  if (isFormatSpec(spec)) return { format: true, spec };
  const out = [];
  for (const raw of spec.split(',')) {
    if (raw === '') continue;
    let part = raw, fb;
    const eq = raw.indexOf('=');
    if (eq >= 0) { part = raw.slice(0, eq); fb = raw.slice(eq + 1); }
    const colon = part.indexOf(':');
    if (colon >= 0) {
      const a = part.slice(0, colon), b = part.slice(colon + 1);
      out.push({
        type: 'range',
        startRaw: a === '' ? null : a,
        endRaw: b === '' ? null : b,
        fallback: fb,
      });
    } else {
      out.push({ type: 'single', raw: part, fallback: fb });
    }
  }
  return { format: false, items: out };
}

function resolveItem(item, len) {
  if (item.type === 'single') return [parseNum(item.raw, len)];
  const start = item.startRaw === null ? 1 : parseNum(item.startRaw, len);
  const end = item.endRaw === null ? len : parseNum(item.endRaw, len);
  const arr = [];
  const step = start <= end ? 1 : -1;
  for (let i = start; step > 0 ? i <= end : i >= end; i += step) arr.push(i);
  return arr;
}

function selectParts(parts, spec, opts, sepForJoin) {
  const len = parts.length;
  const parsed = parseBounds(spec, len);
  if (parsed.format) {
    if (opts.json) die('tuc: runtime error. Cannot format fields when using --json');
    return formatOutput(parsed.spec, parts, opts);
  }
  let values = [];
  for (const item of parsed.items) {
    let idxs = resolveItem(item, len);
    if (opts.complement) {
      const set = new Set(idxs.filter(x => x >= 1 && x <= len));
      idxs = [];
      for (let i = 1; i <= len; i++) if (!set.has(i)) idxs.push(i);
    }
    for (const idx of idxs) {
      if (idx >= 1 && idx <= len) values.push(parts[idx - 1]);
      else if (item.type === 'single') {
        const fb = item.fallback !== undefined ? item.fallback : opts.fallback;
        if (fb !== undefined) values.push(fb);
        else die(`Error: Out of bounds: ${idx}`);
      }
    }
  }
  if (opts.json) return JSON.stringify(values);
  return opts.join ? values.join(sepForJoin) : values.join('');
}

function formatOutput(fmt, parts, opts) {
  let out = '';
  for (let i = 0; i < fmt.length; i++) {
    if (fmt[i] === '{') {
      if (fmt[i + 1] === '{') { out += '{'; i++; continue; }
      const j = fmt.indexOf('}', i + 1);
      if (j < 0) out += fmt[i];
      else {
        const inner = fmt.slice(i + 1, j);
        let field = inner, fb;
        const eq = inner.indexOf('=');
        if (eq >= 0) { field = inner.slice(0, eq); fb = inner.slice(eq + 1); }
        let idx;
        try { idx = parseNum(field, parts.length); } catch (e) { die(`failed to parse '${fmt}': ${e.message}`); }
        if (idx >= 1 && idx <= parts.length) out += parts[idx - 1];
        else {
          const val = fb !== undefined ? fb : opts.fallback;
          if (val !== undefined) out += val; else die(`Error: Out of bounds: ${idx}`);
        }
        i = j;
      }
    } else if (fmt[i] === '}' && fmt[i + 1] === '}') { out += '}'; i++; }
    else out += fmt[i];
  }
  return out;
}

function regexSplitWithDelims(s, reSrc) {
  const re = new RegExp(reSrc, 'g');
  const parts = [], delims = [];
  let last = 0, m;
  while ((m = re.exec(s)) !== null) {
    if (m[0] === '') { re.lastIndex++; continue; }
    parts.push(s.slice(last, m.index));
    delims.push(m[0]);
    last = m.index + m[0].length;
  }
  parts.push(s.slice(last));
  return { parts, delims };
}

function splitFields(line, opts) {
  if (opts.regex) return regexSplitWithDelims(line, opts.regex);
  let d = opts.delim;
  if (d === '') d = '\t';
  const parts = [];
  const delims = [];
  let i = 0, start = 0;
  while (true) {
    const at = line.indexOf(d, i);
    if (at < 0) break;
    parts.push(line.slice(start, at));
    let end = at + d.length;
    if (opts.greedy || opts.compress) {
      while (line.slice(end, end + d.length) === d) end += d.length;
    }
    delims.push(opts.compress ? d : line.slice(at, end));
    start = end;
    i = end;
  }
  parts.push(line.slice(start));
  return { parts, delims };
}

function recordSplit(text, sep) {
  const raw = text.split(sep);
  if (raw.length && raw[raw.length - 1] === '') raw.pop();
  return raw;
}

function processFields(input, opts) {
  const sep = opts.zero ? '\0' : '\n';
  let out = '';
  for (const line of recordSplit(input.toString('utf8'), sep)) {
    const { parts, delims } = splitFields(line, opts);
    if (delims.length === 0 && opts.onlyDelimited) continue;
    let joinSep = opts.replace !== null ? opts.replace : opts.delim;
    if (!opts.regex && opts.replace === null && (opts.greedy || opts.compress) && delims.length) joinSep = delims[0];
    const selected = selectParts(parts, opts.bounds, opts, joinSep);
    out += selected + sep;
  }
  return Buffer.from(out, 'utf8');
}

function processChars(input, opts) {
  const sep = opts.zero ? '\0' : '\n';
  let out = '';
  for (const line of recordSplit(input.toString('utf8'), sep)) {
    const parts = Array.from(line);
    out += selectParts(parts, opts.bounds, opts, opts.replace !== null ? opts.replace : '') + sep;
  }
  return Buffer.from(out, 'utf8');
}

function processBytes(input, opts) {
  const parts = Array.from(input);
  const parsed = parseBounds(opts.bounds, parts.length);
  if (parsed.format) die('tuc: runtime error. Cannot format fields when using bytes');
  const vals = [];
  for (const item of parsed.items) {
    let idxs = resolveItem(item, parts.length);
    if (opts.complement) {
      const set = new Set(idxs.filter(x => x >= 1 && x <= parts.length));
      idxs = [];
      for (let i = 1; i <= parts.length; i++) if (!set.has(i)) idxs.push(i);
    }
    for (const idx of idxs) {
      if (idx >= 1 && idx <= parts.length) vals.push(parts[idx - 1]);
      else if (item.type === 'single') {
        const fb = item.fallback !== undefined ? item.fallback : opts.fallback;
        if (fb !== undefined) return Buffer.from(fb);
        die(`Error: Out of bounds: ${idx}`);
      }
    }
  }
  return Buffer.from(vals);
}

function processLines(input, opts) {
  const sep = opts.zero ? '\0' : '\n';
  const text = input.toString('utf8');
  const lines = recordSplit(text, sep);
  const selected = selectParts(lines, opts.bounds, opts, sep);
  return Buffer.from(selected + (opts.join ? sep : ''), 'utf8');
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  let input;
  if (opts.file) {
    if (!fs.existsSync(opts.file)) die(`tuc: runtime error. The file "${opts.file}" does not exist`);
    input = fs.readFileSync(opts.file);
  } else {
    input = fs.readFileSync(0);
  }
  try {
    let out;
    if (opts.mode === 'bytes') out = processBytes(input, opts);
    else if (opts.mode === 'chars') out = processChars(input, opts);
    else if (opts.mode === 'lines') out = processLines(input, opts);
    else out = processFields(input, opts);
    process.stdout.write(out);
  } catch (e) {
    if (String(e.message || '').startsWith('Not a number') || String(e.message || '').startsWith('Zero is')) {
      die(`failed to parse '${opts.bounds}': ${e.message}`);
    }
    die(e.message || String(e));
  }
}

main();
