#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawnSync } = require("child_process");
const zlib = require("zlib");

const VERSION = "codesnap-cli 0.13.1";
const GREEN = "\x1b[32m";
const RED = "\x1b[31m";
const YELLOW = "\x1b[33m";
const RESET = "\x1b[0m";

const HELP_LONG = `CLI tools for generating beautiful code snapshots

Usage: codesnap [OPTIONS] --output <OUTPUT>

Options:
  -f, --from-file <FROM_FILE>
          Path to the file to snapshot

  -c, --from-code [<Code>]
          Code snippet for snapshot

  -i, --from-image [<Image>]
          

      --from-clipboard
          

  -o, --output <OUTPUT>
          Output path for the snapshot. Available value:
          
          - clipboard: Copy the snapshot to clipboard - file path: Save the snapshot to the file path
          
          Currently CodeSnap supports SVG format and PNG format If output is directory, CodeSnap will generate a temporary file name to save the snapshot to the directory.

      --silent
          

  -e, --execute <EXECUTE>...
          Executing a command and taking the output as the code snippet

      --skip
          Skip run the command to get output, just take the command as the input

      --range <RANGE>
          You can set the range of the code snippet to display for example, display the 3rd to 5th: 3:5 The syntax is similar to the range in Python or Golang, so basically you can use 3: to represent the 3rd to the end, or use :5 to represent the start to the 5th. This option is useful when you use the \`from_file\` option as the input, and you just want to display part of the code snippet

      --code-font-family <CODE_FONT_FAMILY>
          Font family for the code snippet

      --code-theme <CODE_THEME>
          Code theme for the code snippet

      --has-breadcrumbs <HAS_BREADCRUMBS>
          Breadcrumbs is a useful and unique feature in CodeSnap, it shows the path of the file so that users can know where the code snippet comes from
          
          [default: false]
          [possible values: true, false]

      --has-line-number
          

      --breadcrumbs-separator <BREADCRUMBS_SEPARATOR>
          Breadcrumbs separator is the character to separate the path in breadcrumbs Default is \`/\`

      --breadcrumbs-font-family <BREADCRUMBS_FONT_FAMILY>
          Breadcrumbs font family

      --breadcrumbs-color <BREADCRUMBS_COLOR>
          Breadcrumbs font color

      --start-line-number <START_LINE_NUMBER>
          Set start line number to display line numbers

      --line-number-color <LINE_NUMBER_COLOR>
          Line number font color
          
          [default: #495162]

  -d, --delete-line <DELETE_LINE>...
          Delete lines will be marked with a red line

      --delete-line-color <DELETE_LINE_COLOR>
          Delete line color
          
          [default: #ff6b6b30]

  -a, --add-line <ADD_LINE>...
          New lines will be marked with a green line

      --add-line-color <ADD_LINE_COLOR>
          New line color
          
          [default: #2ecc7130]

      --highlight-range <HIGHLIGHT_RANGE>
          Convenient version of \`--raw-highlight-lines\` option, you can set the highlight range with a simple syntax, for example, highlight the 3rd to 5th lines: 3:5

      --relative-highlight-range
          

      --highlight-range-color <HIGHLIGHT_RANGE_COLOR>
          Highlight color for the highlighted code lines
          
          [default: #ffffff10]

      --raw-highlight-lines <RAW_HIGHLIGHT_LINES>
          CodeSnap allows users to highlight multiple lines with custom highlight color in the code snippet The content of highlight_lines is JSON string, for example highlight the first line and the 3rd to 5th lines: "[ [1, "#ff0000"], [3, 5, "#00ff00"] ]"

  -l, --language <LANGUAGE>
          Set the language of the code snippet, If you using the \`file\` option, CodeSnap will automatically detect the language from the file extension

      --file-path <FILE_PATH>
          Used to detect the language of the code snippet, if you want to set language manually, use \`--language\` or \`-l\` option

  -w, --watermark <WATERMARK>
          Set watermark for the code snippet

      --watermark-font-family <WATERMARK_FONT_FAMILY>
          Watermark font family

      --watermark-color <WATERMARK_COLOR>
          Watermark font color

      --shadow-radius <SHADOW_RADIUS>
          Set window shadow radius

      --shadow-color <SHADOW_COLOR>
          

      --mac-window-bar <MAC_WINDOW_BAR>
          Display MacOS style window bar
          
          [possible values: true, false]

      --has-border
          Display window border

      --border-color <BORDER_COLOR>
          Window border color
          
          [default: #ffffff30]

      --margin-x <MARGIN_X>
          Set horizontal margin of window

      --margin-y <MARGIN_Y>
          Set vertical margin of window

      --title <TITLE>
          Set title of the window

      --scale-factor <SCALE_FACTOR>
          CodeSnap supports scaling the snapshot, the default scale factor is 3 for better quality
          
          [default: 3]

      --title-font-family <TITLE_FONT_FAMILY>
          Title font family

      --title-color <TITLE_COLOR>
          Title font color

      --background <BACKGROUND>
          Set background color of the snapshot

      --type <TYPE>
          [default: image]
          [possible values: ascii, image]

      --config <CONFIG>
          

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const takesValue = new Set([
  "-f", "--from-file", "-c", "--from-code", "-i", "--from-image", "-o", "--output",
  "--range", "--code-font-family", "--code-theme", "--has-breadcrumbs",
  "--breadcrumbs-separator", "--breadcrumbs-font-family", "--breadcrumbs-color",
  "--start-line-number", "--line-number-color", "--delete-line-color",
  "--add-line-color", "--highlight-range", "--highlight-range-color",
  "--raw-highlight-lines", "-l", "--language", "--file-path", "-w",
  "--watermark", "--watermark-font-family", "--watermark-color", "--shadow-radius",
  "--shadow-color", "--mac-window-bar", "--border-color", "--margin-x",
  "--margin-y", "--title", "--scale-factor", "--title-font-family",
  "--title-color", "--background", "--type", "--config"
]);

function main() {
  const args = process.argv.slice(2);
  if (args.includes("-V") || args.includes("--version")) {
    console.log(VERSION);
    return;
  }
  if (args.length === 0 || args.includes("--help") || args.includes("-h")) {
    console.log(HELP_LONG);
    return;
  }

  let opts;
  try {
    opts = parseArgs(args);
  } catch (err) {
    clapError(err.message);
  }

  if (!opts.output) {
    const used = opts.fromCode !== undefined ? " --from-code [<Code>]" : "";
    console.error("error: the following required arguments were not provided:");
    console.error("  --output <OUTPUT>");
    console.error("");
    console.error(`Usage: codesnap --output <OUTPUT>${used}`);
    console.error("");
    console.error("For more information, try '--help'.");
    process.exit(2);
  }

  if (opts.type === "ascii") {
    if (!opts.silent) console.log(`${YELLOW}[WARN]${RESET} ASCII snapshot only supports copying to clipboard`);
    if (opts.output === "clipboard") return;
    return;
  }

  let code = "";
  let sourcePath = opts.filePath || "";
  try {
    if (opts.fromFile) {
      sourcePath = opts.fromFile;
      code = fs.readFileSync(opts.fromFile, "utf8");
    } else if (opts.execute.length) {
      code = opts.skip ? opts.execute.join(" ") : runCommand(opts.execute);
    } else if (opts.fromCode !== undefined) {
      code = opts.fromCode || "";
    } else if (opts.fromImage) {
      sourcePath = opts.fromImage;
      code = `[Image] ${opts.fromImage}`;
    } else if (opts.fromClipboard) {
      code = "";
    } else {
      code = "";
    }
  } catch (err) {
    error(err.message);
  }

  code = applyRange(code, opts.range);

  let out = opts.output;
  if (out === "clipboard") {
    if (!opts.silent) console.log(`${GREEN}[SUCCESS]${RESET} Snapshot copied to clipboard successful!`);
    return;
  }
  if (existsDir(out)) error("Unsupported output format");
  const ext = path.extname(out).toLowerCase();
  if (![".svg", ".png", ".html", ".htm"].includes(ext)) error("Unsupported output format");
  fs.mkdirSync(path.dirname(path.resolve(out)), { recursive: true });

  const rendered = render(code, opts, sourcePath);
  if (ext === ".png") {
    fs.writeFileSync(out, makePng(rendered.width, rendered.height, rendered.lines, opts));
  } else if (ext === ".html" || ext === ".htm") {
    fs.writeFileSync(out, renderHtml(code, opts, sourcePath));
  } else {
    fs.writeFileSync(out, rendered.svg);
  }
  if (!opts.silent) console.log(`${GREEN}[SUCCESS]${RESET} Snapshot saved to ${out} successful!`);
}

function parseArgs(args) {
  const opts = { execute: [], addLine: [], deleteLine: [], type: "image", startLineNumber: 1 };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-e" || a === "--execute") {
      i++;
      while (i < args.length && !args[i].startsWith("-")) opts.execute.push(args[i++]);
      i--;
    } else if (a === "-a" || a === "--add-line") {
      opts.addLine.push(args[++i]);
    } else if (a === "-d" || a === "--delete-line") {
      opts.deleteLine.push(args[++i]);
    } else if (a === "--from-clipboard") {
      opts.fromClipboard = true;
    } else if (a === "--skip" || a === "--silent" || a === "--has-line-number" || a === "--has-border" || a === "--relative-highlight-range") {
      opts[a.slice(2).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = true;
    } else if (takesValue.has(a)) {
      const v = args[++i];
      if (v === undefined) throw new Error(`a value is required for '${a} <${a.replace(/^-+/, "").toUpperCase()}>' but none was supplied`);
      assign(opts, a, v);
    } else {
      // The real clap parser is strict; keeping stray words is useful for `-c` shell quoting mistakes.
      if (opts.fromCode !== undefined) opts.fromCode += (opts.fromCode ? " " : "") + a;
      else throw new Error(`unexpected argument '${a}' found`);
    }
  }
  return opts;
}

function assign(opts, key, value) {
  const map = {
    "-f": "fromFile", "--from-file": "fromFile", "-c": "fromCode", "--from-code": "fromCode",
    "-i": "fromImage", "--from-image": "fromImage", "-o": "output", "--output": "output",
    "-l": "language", "--language": "language", "-w": "watermark", "--watermark": "watermark"
  };
  const name = map[key] || key.slice(2).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
  opts[name] = value;
}

function clapError(msg) {
  console.error(`error: ${msg}`);
  console.error("");
  console.error("Usage: codesnap [OPTIONS] --output <OUTPUT>");
  console.error("");
  console.error("For more information, try '--help'.");
  process.exit(2);
}

function error(msg) {
  msg = String(msg).replace(/^ENOENT: no such file or directory, open .+$/, "No such file or directory (os error 2)");
  console.error(`${RED}[ERROR]${RESET} ${msg}`);
  process.exit(1);
}

function existsDir(p) {
  try { return fs.statSync(p).isDirectory(); } catch { return false; }
}

function runCommand(argv) {
  if (argv.length === 0) return "";
  const res = spawnSync(argv[0], argv.slice(1), { encoding: "utf8", shell: false });
  if (res.error) throw res.error;
  return (res.stdout || "") + (res.stderr || "");
}

function applyRange(text, range) {
  if (!range) return text;
  const lines = splitLines(text);
  const m = /^(\d*)?:(\d*)?$/.exec(range);
  if (!m) return text;
  const start = m[1] ? Math.max(1, parseInt(m[1], 10)) : 1;
  const end = m[2] ? Math.max(start, parseInt(m[2], 10)) : lines.length;
  return lines.slice(start - 1, end).join("\n");
}

function splitLines(text) {
  const out = String(text).replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  if (out.length > 1 && out[out.length - 1] === "") out.pop();
  return out.length ? out : [""];
}

function render(code, opts, sourcePath) {
  const lines = splitLines(code);
  const font = opts.codeFontFamily || "Monaco, Menlo, Consolas, monospace";
  const marginX = parseInt(opts.marginX || "56", 10);
  const marginY = parseInt(opts.marginY || "56", 10);
  const lineHeight = 26;
  const codeSize = 18;
  const numberPad = opts.hasLineNumber ? 58 : 0;
  const maxLen = Math.max(12, ...lines.map((l) => visibleLen(l)));
  const titleHeight = opts.title || truthy(opts.macWindowBar) ? 44 : 0;
  const breadHeight = truthy(opts.hasBreadcrumbs) && sourcePath ? 28 : 0;
  const waterHeight = opts.watermark ? 34 : 0;
  const width = Math.max(420, marginX * 2 + numberPad + maxLen * 10 + 44);
  const height = Math.max(180, marginY * 2 + titleHeight + breadHeight + lines.length * lineHeight + waterHeight + 28);
  const bg = opts.background || "#1f2430";
  const panel = "#282c34";
  let y = marginY;
  const parts = [];
  parts.push(`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`);
  parts.push(`<rect width="100%" height="100%" fill="${escAttr(bg)}"/>`);
  parts.push(`<rect x="${marginX}" y="${marginY}" width="${width - marginX * 2}" height="${height - marginY * 2}" rx="12" fill="${panel}"${opts.hasBorder ? ` stroke="${escAttr(opts.borderColor || "#ffffff30")}"` : ""}/>`);
  if (truthy(opts.macWindowBar)) {
    parts.push(`<circle cx="${marginX + 28}" cy="${y + 22}" r="6" fill="#ff5f57"/><circle cx="${marginX + 48}" cy="${y + 22}" r="6" fill="#ffbd2e"/><circle cx="${marginX + 68}" cy="${y + 22}" r="6" fill="#28c840"/>`);
  }
  if (opts.title) {
    parts.push(`<text x="${width / 2}" y="${y + 29}" text-anchor="middle" font-family="${escAttr(opts.titleFontFamily || font)}" font-size="16" fill="${escAttr(opts.titleColor || "#d8dee9")}">${esc(opts.title)}</text>`);
  }
  y += titleHeight;
  if (truthy(opts.hasBreadcrumbs) && sourcePath) {
    const sep = opts.breadcrumbsSeparator || "/";
    const crumb = sourcePath.split(/[\\/]/).filter(Boolean).join(sep);
    parts.push(`<text x="${marginX + 24}" y="${y + 18}" font-family="${escAttr(opts.breadcrumbsFontFamily || font)}" font-size="14" fill="${escAttr(opts.breadcrumbsColor || "#8f98aa")}">${esc(crumb)}</text>`);
    y += breadHeight;
  }
  const lineStart = parseInt(opts.startLineNumber || "1", 10);
  const highlights = expandLineSpecs(opts.highlightRange).concat(expandRawHighlights(opts.rawHighlightLines));
  const adds = new Set(opts.addLine.flatMap(expandLineSpecs));
  const dels = new Set(opts.deleteLine.flatMap(expandLineSpecs));
  lines.forEach((line, idx) => {
    const n = idx + 1;
    const cy = y + idx * lineHeight;
    if (highlights.includes(n)) parts.push(`<rect x="${marginX + 12}" y="${cy + 2}" width="${width - marginX * 2 - 24}" height="${lineHeight}" fill="${escAttr(opts.highlightRangeColor || "#ffffff10")}"/>`);
    if (adds.has(n)) parts.push(`<rect x="${marginX + 12}" y="${cy + 2}" width="${width - marginX * 2 - 24}" height="${lineHeight}" fill="${escAttr(opts.addLineColor || "#2ecc7130")}"/>`);
    if (dels.has(n)) parts.push(`<rect x="${marginX + 12}" y="${cy + 2}" width="${width - marginX * 2 - 24}" height="${lineHeight}" fill="${escAttr(opts.deleteLineColor || "#ff6b6b30")}"/>`);
    if (opts.hasLineNumber) parts.push(`<text x="${marginX + 24}" y="${cy + 22}" font-family="${escAttr(font)}" font-size="${codeSize}" fill="${escAttr(opts.lineNumberColor || "#495162")}">${lineStart + idx}</text>`);
    parts.push(`<text x="${marginX + 24 + numberPad}" y="${cy + 22}" font-family="${escAttr(font)}" font-size="${codeSize}" fill="#d8dee9">${esc(line || " ")}</text>`);
  });
  if (opts.watermark) {
    parts.push(`<text x="${width - marginX - 24}" y="${height - marginY - 18}" text-anchor="end" font-family="${escAttr(opts.watermarkFontFamily || font)}" font-size="16" fill="${escAttr(opts.watermarkColor || "#8f98aa")}">${esc(opts.watermark)}</text>`);
  }
  parts.push(`</svg>`);
  return { svg: parts.join(""), width, height, lines };
}

function renderHtml(code, opts, sourcePath) {
  const title = opts.title || (sourcePath ? path.basename(sourcePath) : "CodeSnap");
  const lines = splitLines(code).map(esc).join("\n");
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title><style>body{margin:0;background:${opts.background || "#1f2430"};padding:48px}pre{background:#282c34;color:#d8dee9;padding:28px;border-radius:12px;font:16px/1.5 Monaco,Menlo,Consolas,monospace;white-space:pre-wrap}</style></head><body><pre>${lines}</pre></body></html>\n`;
}

function makePng(width, height, lines, opts) {
  const w = Math.min(Math.max(width, 1), 1800);
  const h = Math.min(Math.max(height, 1), 1400);
  const bg = parseColor(opts.background || "#1f2430");
  const panel = parseColor("#282c34");
  const data = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    const row = y * (w * 4 + 1);
    data[row] = 0;
    for (let x = 0; x < w; x++) {
      const inPanel = x > 45 && x < w - 45 && y > 45 && y < h - 45;
      const c = inPanel ? panel : bg;
      const i = row + 1 + x * 4;
      data[i] = c[0]; data[i + 1] = c[1]; data[i + 2] = c[2]; data[i + 3] = 255;
    }
  }
  return Buffer.concat([
    Buffer.from("89504e470d0a1a0a", "hex"),
    chunk("IHDR", Buffer.concat([u32(w), u32(h), Buffer.from([8, 6, 0, 0, 0])])),
    chunk("IDAT", zlib.deflateSync(data)),
    chunk("IEND", Buffer.alloc(0))
  ]);
}

function chunk(type, data) {
  const t = Buffer.from(type);
  const crc = crc32(Buffer.concat([t, data]));
  return Buffer.concat([u32(data.length), t, data, u32(crc)]);
}

function u32(n) {
  const b = Buffer.alloc(4);
  b.writeUInt32BE(n >>> 0, 0);
  return b;
}

function crc32(buf) {
  let c = ~0;
  for (const byte of buf) {
    c ^= byte;
    for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xedb88320 & -(c & 1));
  }
  return ~c >>> 0;
}

function parseColor(s) {
  const m = /^#?([0-9a-f]{6})/i.exec(String(s));
  if (!m) return [31, 36, 48];
  return [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16));
}

function expandRawHighlights(raw) {
  if (!raw) return [];
  try {
    return JSON.parse(raw).flatMap((entry) => Array.isArray(entry) ? expandLineSpec(entry.length >= 3 ? `${entry[0]}:${entry[1]}` : String(entry[0])) : []);
  } catch {
    return [];
  }
}

function expandLineSpecs(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value.flatMap(expandLineSpec);
  return expandLineSpec(value);
}

function expandLineSpec(spec) {
  const s = String(spec);
  if (s.includes(":")) {
    const [a, b] = s.split(":");
    const start = a ? parseInt(a, 10) : 1;
    const end = b ? parseInt(b, 10) : start;
    const out = [];
    for (let i = start; i <= end; i++) out.push(i);
    return out;
  }
  const n = parseInt(s, 10);
  return Number.isFinite(n) ? [n] : [];
}

function truthy(v) {
  return v === true || v === "true" || v === "1";
}

function visibleLen(s) {
  return String(s).replace(/\t/g, "    ").length;
}

function esc(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;" }[c]));
}

function escAttr(s) {
  return esc(s).replace(/'/g, "&#39;");
}

main();
