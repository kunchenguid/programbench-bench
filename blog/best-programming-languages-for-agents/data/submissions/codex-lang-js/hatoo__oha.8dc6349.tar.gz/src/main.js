#!/usr/bin/env node
'use strict';

const fs = require('fs');
const http = require('http');
const https = require('https');
const net = require('net');
const { URL } = require('url');

const VERSION = 'oha 1.12.1';

const HELP = `Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.

Usage: executable [OPTIONS] <URL>

Arguments:
  <URL>  Target URL or file with multiple URLs.

Options:
  -n <N_REQUESTS>
          Number of requests to run. Accepts plain numbers or suffixes: k = 1,000, m = 1,000,000 (e.g. 10k, 1m). [default: 200]
  -c <N_CONNECTIONS>
          Number of connections to run concurrently. You may should increase limit to number of open files for larger \`-c\`. [default: 50]
  -p <N_HTTP2_PARALLEL>
          Number of parallel requests to send on HTTP/2. \`oha\` will run c * p concurrent workers in total. [default: 1]
  -z <DURATION>
          Duration of application to send requests.
          On HTTP/1, When the duration is reached, ongoing requests are aborted and counted as "aborted due to deadline"
          You can change this behavior with \`-w\` option.
          Currently, on HTTP/2, When the duration is reached, ongoing requests are waited. \`-w\` option is ignored.
          Examples: -z 10s -z 3m.
  -w, --wait-ongoing-requests-after-deadline
          When the duration is reached, ongoing requests are waited
  -q <QUERY_PER_SECOND>
          Rate limit for all, in queries per second (QPS)
      --burst-delay <BURST_DURATION>
          Introduce delay between a predefined number of requests.
          Note: If qps is specified, burst will be ignored
      --burst-rate <BURST_REQUESTS>
          Rates of requests for burst. Default is 1
          Note: If qps is specified, burst will be ignored
      --rand-regex-url
          Generate URL by rand_regex crate but dot is disabled for each query e.g. http://127.0.0.1/[a-z][a-z][0-9]. Currently dynamic scheme, host and port with keep-alive do not work well. See https://docs.rs/rand_regex/latest/rand_regex/struct.Regex.html for details of syntax.
      --urls-from-file
          Read the URLs to query from a file
      --max-repeat <MAX_REPEAT>
          A parameter for the '--rand-regex-url'. The max_repeat parameter gives the maximum extra repeat counts the x*, x+ and x{n,} operators will become. [default: 4]
      --dump-urls <DUMP_URLS>
          Dump target Urls <DUMP_URLS> times to debug --rand-regex-url
      --latency-correction
          Correct latency to avoid coordinated omission problem. It's ignored if -q is not set.
      --no-tui
          No realtime tui
      --fps <FPS>
          Frame per second for tui. [default: 16]
  -m, --method <METHOD>
          HTTP method [default: GET]
  -H <HEADERS>
          Custom HTTP header. Examples: -H "foo: bar"
      --proxy-header <PROXY_HEADERS>
          Custom Proxy HTTP header. Examples: --proxy-header "foo: bar"
  -t <TIMEOUT>
          Timeout for each request. Default to infinite.
      --connect-timeout <CONNECT_TIMEOUT>
          Timeout for establishing a new connection. Default to 5s. [default: 5s]
  -A <ACCEPT_HEADER>
          HTTP Accept Header.
  -d <BODY_STRING>
          HTTP request body.
  -D <BODY_PATH>
          HTTP request body from file.
  -Z <BODY_PATH_LINES>
          HTTP request body from file line by line.
  -F, --form <FORM>
          Specify HTTP multipart POST data (curl compatible). Examples: -F 'name=value' -F 'file=@path/to/file'
  -T <CONTENT_TYPE>
          Content-Type.
  -a <BASIC_AUTH>
          Basic authentication (username:password), or AWS credentials (access_key:secret_key)
      --aws-session <AWS_SESSION>
          AWS session token
      --aws-sigv4 <AWS_SIGV4>
          AWS SigV4 signing params (format: aws:amz:region:service)
  -x <PROXY>
          HTTP proxy
      --proxy-http-version <PROXY_HTTP_VERSION>
          HTTP version to connect to proxy. Available values 0.9, 1.0, 1.1, 2.
      --proxy-http2
          Use HTTP/2 to connect to proxy. Shorthand for --proxy-http-version=2
      --http-version <HTTP_VERSION>
          HTTP version. Available values 0.9, 1.0, 1.1, 2, 3
      --http2
          Use HTTP/2. Shorthand for --http-version=2
      --host <HOST>
          HTTP Host header
      --disable-compression
          Disable compression.
  -r, --redirect <REDIRECT>
          Limit for number of Redirect. Set 0 for no redirection. Redirection isn't supported for HTTP/2. [default: 10]
      --disable-keepalive
          Disable keep-alive, prevents re-use of TCP connections between different HTTP requests. This isn't supported for HTTP/2.
      --no-pre-lookup
          *Not* perform a DNS lookup at beginning to cache it
      --ipv6
          Lookup only ipv6.
      --ipv4
          Lookup only ipv4.
      --cacert <CACERT>
          (TLS) Use the specified certificate file to verify the peer. Native certificate store is used even if this argument is specified.
      --cert <CERT>
          (TLS) Use the specified client certificate file. --key must be also specified
      --key <KEY>
          (TLS) Use the specified client key file. --cert must be also specified
      --insecure
          Accept invalid certs.
      --connect-to <CONNECT_TO>
          Override DNS resolution and default port numbers with strings like 'example.org:443:localhost:8443'
          Note: if used several times for the same host:port:target_host:target_port, a random choice is made
      --no-color
          Disable the color scheme. [env: NO_COLOR=]
      --unix-socket <UNIX_SOCKET>
          Connect to a unix socket instead of the domain in the URL. Only for non-HTTPS URLs.
      --stats-success-breakdown
          Include a response status code successful or not successful breakdown for the time histogram and distribution statistics
      --db-url <DB_URL>
          Write succeeded requests to sqlite database url E.G test.db
      --debug
          Perform a single request and dump the request and response
  -o, --output <OUTPUT>
          Output file to write the results to. If not specified, results are written to stdout.
      --output-format <OUTPUT_FORMAT>
          Output format [default: text] [possible values: text, json, csv, quiet]
  -u, --time-unit <TIME_UNIT>
          Time unit to be used. If not specified, the time unit is determined automatically. This option affects only text format. [possible values: ns, us, ms, s, m, h]
  -h, --help
          Print help
  -V, --version
          Print version`;

function die(msg, code = 2) {
  process.stderr.write(msg + '\n');
  process.exit(code);
}

function parseCount(s, name) {
  if (!/^\d+(?:[kKmM])?$/.test(s || '')) die(`error: invalid value '${s}' for '${name}': invalid digit found in string\n\nFor more information, try '--help'.`);
  const suffix = s.slice(-1).toLowerCase();
  const base = suffix === 'k' || suffix === 'm' ? Number(s.slice(0, -1)) : Number(s);
  return base * (suffix === 'k' ? 1000 : suffix === 'm' ? 1000000 : 1);
}

function parseDuration(s, defMs = null) {
  if (s == null) return defMs;
  const m = String(s).match(/^(\d+(?:\.\d+)?)(ns|us|µs|ms|s|m|h)?$/);
  if (!m) die(`error: invalid value '${s}' for duration\n\nFor more information, try '--help'.`);
  const n = Number(m[1]);
  const u = m[2] || 's';
  return n * ({ ns: 1e-6, us: 1e-3, 'µs': 1e-3, ms: 1, s: 1000, m: 60000, h: 3600000 }[u]);
}

function need(args, i, opt) {
  if (i + 1 >= args.length) die(`error: a value is required for '${opt} <${opt.replace(/^-+/, '').toUpperCase()}>' but none was supplied\n\nFor more information, try '--help'.`);
  return args[i + 1];
}

function parseArgs(argv) {
  const opts = {
    n: 200, c: 50, p: 1, method: 'GET', headers: [], proxyHeaders: [], timeout: 0,
    connectTimeout: 5000, accept: null, body: null, contentType: null, auth: null,
    redirects: 10, outputFormat: 'text', output: null, timeUnit: null, noTui: false,
    debug: false, urlsFromFile: false, randRegexUrl: false, dumpUrls: null,
    maxRepeat: 4, qps: null, burstDelay: null, burstRate: 1, duration: null,
    insecure: false, host: null, disableKeepalive: false, unixSocket: null,
    connectTo: [], ipv4: false, ipv6: false, wait: false
  };
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '--') { positional.push(...argv.slice(i + 1)); break; }
    if (a === '-h' || a === '--help') { console.log(HELP); process.exit(0); }
    if (a === '-V' || a === '--version') { console.log(VERSION); process.exit(0); }
    if (!a.startsWith('-') || a === '-') { positional.push(a); continue; }
    let val = null;
    if (a.startsWith('--') && a.includes('=')) {
      const idx = a.indexOf('=');
      val = a.slice(idx + 1);
      a = a.slice(0, idx);
    }
    const take = (name) => val != null ? val : need(argv, i++, name);
    switch (a) {
      case '-n': opts.n = parseCount(take('-n'), '-n <N_REQUESTS>'); break;
      case '-c': opts.c = parseCount(take('-c'), '-c <N_CONNECTIONS>'); break;
      case '-p': opts.p = parseCount(take('-p'), '-p <N_HTTP2_PARALLEL>'); break;
      case '-z': opts.duration = parseDuration(take('-z')); break;
      case '-w': case '--wait-ongoing-requests-after-deadline': opts.wait = true; break;
      case '-q': opts.qps = Number(take('-q')); break;
      case '--burst-delay': opts.burstDelay = parseDuration(take('--burst-delay')); break;
      case '--burst-rate': opts.burstRate = parseCount(take('--burst-rate'), '--burst-rate <BURST_REQUESTS>'); break;
      case '--rand-regex-url': opts.randRegexUrl = true; break;
      case '--urls-from-file': opts.urlsFromFile = true; break;
      case '--max-repeat': opts.maxRepeat = parseCount(take('--max-repeat'), '--max-repeat <MAX_REPEAT>'); break;
      case '--dump-urls': opts.dumpUrls = parseCount(take('--dump-urls'), '--dump-urls <DUMP_URLS>'); break;
      case '--latency-correction': opts.latencyCorrection = true; break;
      case '--no-tui': opts.noTui = true; break;
      case '--fps': opts.fps = Number(take('--fps')); break;
      case '-m': case '--method': opts.method = take(a).toUpperCase(); break;
      case '-H': opts.headers.push(take('-H')); break;
      case '--proxy-header': opts.proxyHeaders.push(take('--proxy-header')); break;
      case '-t': opts.timeout = parseDuration(take('-t')); break;
      case '--connect-timeout': opts.connectTimeout = parseDuration(take('--connect-timeout')); break;
      case '-A': opts.accept = take('-A'); break;
      case '-d': opts.body = Buffer.from(take('-d')); break;
      case '-D': opts.body = fs.readFileSync(take('-D')); break;
      case '-Z': opts.bodyLines = fs.readFileSync(take('-Z'), 'utf8').split(/\r?\n/).filter(Boolean); break;
      case '-F': case '--form': opts.form = opts.form || []; opts.form.push(take(a)); break;
      case '-T': opts.contentType = take('-T'); break;
      case '-a': opts.auth = take('-a'); break;
      case '--aws-session': opts.awsSession = take('--aws-session'); break;
      case '--aws-sigv4': opts.awsSigv4 = take('--aws-sigv4'); break;
      case '-x': opts.proxy = take('-x'); break;
      case '--proxy-http-version': opts.proxyHttpVersion = take('--proxy-http-version'); break;
      case '--proxy-http2': opts.proxyHttpVersion = '2'; break;
      case '--http-version': opts.httpVersion = take('--http-version'); break;
      case '--http2': opts.httpVersion = '2'; break;
      case '--host': opts.host = take('--host'); break;
      case '--disable-compression': opts.disableCompression = true; break;
      case '-r': case '--redirect': opts.redirects = parseCount(take(a), `${a} <REDIRECT>`); break;
      case '--disable-keepalive': opts.disableKeepalive = true; break;
      case '--no-pre-lookup': opts.noPreLookup = true; break;
      case '--ipv6': opts.ipv6 = true; break;
      case '--ipv4': opts.ipv4 = true; break;
      case '--cacert': opts.cacert = take('--cacert'); break;
      case '--cert': opts.cert = take('--cert'); break;
      case '--key': opts.key = take('--key'); break;
      case '--insecure': opts.insecure = true; break;
      case '--connect-to': opts.connectTo.push(take('--connect-to')); break;
      case '--no-color': opts.noColor = true; break;
      case '--unix-socket': opts.unixSocket = take('--unix-socket'); break;
      case '--stats-success-breakdown': opts.statsSuccessBreakdown = true; break;
      case '--db-url': opts.dbUrl = take('--db-url'); break;
      case '--debug': opts.debug = true; opts.n = 1; opts.c = 1; break;
      case '-o': case '--output': opts.output = take(a); break;
      case '--output-format':
        opts.outputFormat = take('--output-format');
        if (!['text', 'json', 'csv', 'quiet'].includes(opts.outputFormat)) {
          die(`error: invalid value '${opts.outputFormat}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: text, json, csv, quiet]\n\nFor more information, try '--help'.`);
        }
        break;
      case '-u': case '--time-unit':
        opts.timeUnit = take(a);
        if (!['ns', 'us', 'ms', 's', 'm', 'h'].includes(opts.timeUnit)) die(`error: invalid value '${opts.timeUnit}' for '--time-unit <TIME_UNIT>'\n  [possible values: ns, us, ms, s, m, h]\n\nFor more information, try '--help'.`);
        break;
      default:
        die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.`);
    }
  }
  if (positional.length === 0) {
    console.log(HELP);
    process.exit(0);
  }
  if (positional.length > 1) die(`error: unexpected argument '${positional[1]}' found\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.`);
  opts.target = positional[0];
  return opts;
}

function randInt(n) { return Math.floor(Math.random() * n); }

function randomFromRegex(pattern, maxRepeat = 4) {
  let out = '';
  for (let i = 0; i < pattern.length; i++) {
    const ch = pattern[i];
    if (ch === '[') {
      const j = pattern.indexOf(']', i + 1);
      if (j > i) {
        const cls = pattern.slice(i + 1, j);
        const chars = [];
        for (let k = 0; k < cls.length; k++) {
          if (k + 2 < cls.length && cls[k + 1] === '-') {
            for (let c = cls.charCodeAt(k); c <= cls.charCodeAt(k + 2); c++) chars.push(String.fromCharCode(c));
            k += 2;
          } else chars.push(cls[k]);
        }
        let reps = 1;
        const next = pattern[j + 1];
        if (next === '*' || next === '+') { reps = randInt(maxRepeat + 1) + (next === '+' ? 1 : 0); i = j + 1; }
        else if (next === '{') {
          const e = pattern.indexOf('}', j + 2);
          if (e > 0) {
            const [a, b] = pattern.slice(j + 2, e).split(',').map(x => x === '' ? null : Number(x));
            const min = a ?? 0, max = b ?? (min + maxRepeat);
            reps = min + randInt(Math.max(1, max - min + 1)); i = e;
          } else i = j;
        } else i = j;
        for (let r = 0; r < reps; r++) out += chars[randInt(chars.length)] || '';
        continue;
      }
    }
    if (ch === '\\' && i + 1 < pattern.length) out += pattern[++i];
    else out += ch;
  }
  return out;
}

function chooseUrl(opts) {
  if (opts.urlsFromFile) return opts.urls[randInt(opts.urls.length)];
  if (opts.randRegexUrl) return randomFromRegex(opts.target, opts.maxRepeat);
  return opts.target;
}

function headerObject(opts, urlObj, body) {
  const h = {};
  h['accept'] = opts.accept || '*/*';
  if (!opts.disableCompression) h['accept-encoding'] = 'gzip, compress, deflate, br';
  h['user-agent'] = 'oha/1.12.1';
  if (opts.contentType) h['content-type'] = opts.contentType;
  if (opts.auth) h['authorization'] = 'Basic ' + Buffer.from(opts.auth).toString('base64');
  for (const line of opts.headers) {
    const idx = line.indexOf(':');
    if (idx >= 0) h[line.slice(0, idx).trim().toLowerCase()] = line.slice(idx + 1).trim();
  }
  h['host'] = opts.host || urlObj.host;
  if (body && body.length) h['content-length'] = String(body.length);
  return h;
}

function connectionErrorMessage(err) {
  if (!err) return 'unknown error';
  if (err.code === 'ECONNREFUSED') return 'Connection refused (os error 111)';
  if (err.code === 'ENOTFOUND') return 'dns error: failed to lookup address information';
  if (err.code === 'ETIMEDOUT' || err.code === 'ESOCKETTIMEDOUT') return 'operation timed out';
  if (err.code === 'ECONNRESET') return 'Connection reset by peer (os error 104)';
  return err.message || String(err);
}

function bodyForRequest(opts, index) {
  if (opts.bodyLines && opts.bodyLines.length) return Buffer.from(opts.bodyLines[index % opts.bodyLines.length]);
  if (opts.form && opts.form.length) {
    const boundary = '------------------------oha';
    const chunks = [];
    for (const f of opts.form) {
      const eq = f.indexOf('=');
      const name = eq >= 0 ? f.slice(0, eq) : f;
      const val = eq >= 0 ? f.slice(eq + 1) : '';
      chunks.push(`--${boundary}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${val}\r\n`);
    }
    chunks.push(`--${boundary}--\r\n`);
    opts.contentType = `multipart/form-data; boundary=${boundary}`;
    return Buffer.from(chunks.join(''));
  }
  return opts.body || null;
}

function formatDebugRequest(opts, urlObj, headers, body) {
  const lines = [
    'Request {',
    `    method: ${opts.method},`,
    `    uri: ${urlObj.pathname || '/'}${urlObj.search || ''},`,
    '    version: HTTP/1.1,',
    '    headers: {'
  ];
  for (const [k, v] of Object.entries(headers)) {
    if (k === 'content-length') continue;
    lines.push(`        "${k}": "${v}",`);
  }
  lines.push('    },', '    body: Full {');
  if (body && body.length) lines.push('        data: Some(', `            b"${body.toString().replace(/\\/g, '\\\\').replace(/"/g, '\\"')}",`, '        ),');
  else lines.push('        data: None,');
  lines.push('    },', '}');
  return lines.join('\n') + '\n';
}

function formatDebugResponse(res, body) {
  const lines = ['Response {', `    status: ${res.statusCode},`, '    version: HTTP/1.1,', '    headers: {'];
  for (const [k, v] of Object.entries(res.headers)) lines.push(`        "${k}": "${Array.isArray(v) ? v.join(', ') : v}",`);
  lines.push('    },', `    body: b"${body.toString().replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n')}",`, '}');
  return lines.join('\n') + '\n';
}

function requestOnce(opts, index, redirectsLeft = opts.redirects) {
  return new Promise((resolve) => {
    const target = chooseUrl(opts);
    let urlObj;
    try { urlObj = new URL(target); } catch (e) { resolve({ ok: false, error: `builder error: invalid uri (${target})`, duration: 0, bytes: 0 }); return; }
    const body = bodyForRequest(opts, index);
    const headers = headerObject(opts, urlObj, body);
    if (opts.debug) process.stdout.write(formatDebugRequest(opts, urlObj, headers, body));
    const start = process.hrtime.bigint();
    let firstByte = null;
    const lib = urlObj.protocol === 'https:' ? https : http;
    const reqOpts = {
      protocol: urlObj.protocol,
      hostname: urlObj.hostname,
      port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
      path: (urlObj.pathname || '/') + (urlObj.search || ''),
      method: opts.method,
      headers,
      timeout: opts.timeout || undefined,
      rejectUnauthorized: !opts.insecure,
      family: opts.ipv4 ? 4 : opts.ipv6 ? 6 : undefined,
      agent: opts.disableKeepalive ? false : undefined,
      socketPath: opts.unixSocket || undefined
    };
    const req = lib.request(reqOpts, (res) => {
      const chunks = [];
      res.on('data', (c) => { if (firstByte == null) firstByte = process.hrtime.bigint(); chunks.push(c); });
      res.on('end', async () => {
        const end = process.hrtime.bigint();
        const buf = Buffer.concat(chunks);
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirectsLeft > 0) {
          const next = new URL(res.headers.location, urlObj).toString();
          const old = opts.target; opts.target = next;
          const r = await requestOnce(opts, index, redirectsLeft - 1);
          opts.target = old; resolve(r); return;
        }
        if (opts.debug) process.stdout.write(formatDebugResponse(res, buf));
        const dur = Number(end - start) / 1e9;
        const respDelay = firstByte ? Number(firstByte - start) / 1e9 : dur;
        resolve({ ok: res.statusCode >= 200 && res.statusCode < 300, status: res.statusCode, duration: dur, responseDelay: respDelay, bytes: buf.length, error: null, start });
      });
    });
    req.on('timeout', () => req.destroy(Object.assign(new Error('operation timed out'), { code: 'ETIMEDOUT' })));
    req.on('error', (err) => {
      const end = process.hrtime.bigint();
      const msg = connectionErrorMessage(err);
      if (opts.debug) process.stdout.write(`Error: ${msg}\n`);
      resolve({ ok: false, error: msg, duration: Number(end - start) / 1e9, responseDelay: 0, bytes: 0, start });
    });
    if (body && body.length) req.write(body);
    req.end();
  });
}

async function runLoad(opts) {
  if (opts.urlsFromFile) opts.urls = fs.readFileSync(opts.target, 'utf8').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  if (opts.dumpUrls != null) {
    let s = '';
    if (opts.urlsFromFile) opts.urls = fs.readFileSync(opts.target, 'utf8').split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    for (let i = 0; i < opts.dumpUrls; i++) s += chooseUrl(opts) + '\n';
    return s;
  }
  if (opts.debug) {
    await requestOnce(opts, 0);
    return '';
  }
  const total = opts.duration != null ? Infinity : opts.n;
  const concurrency = opts.c * opts.p;
  const results = [];
  const started = process.hrtime.bigint();
  if (concurrency <= 0) return formatOutput(opts, [], Number(process.hrtime.bigint() - started) / 1e9);
  let launched = 0, active = 0, done = false;
  const deadline = opts.duration != null ? Date.now() + opts.duration : Infinity;
  const interval = opts.qps ? 1000 / opts.qps : null;
  let nextLaunch = Date.now();
  return await new Promise((resolve) => {
    const maybe = () => {
      if ((launched >= total || Date.now() >= deadline) && active === 0) {
        done = true;
        const ended = process.hrtime.bigint();
        resolve(formatOutput(opts, results, Number(ended - started) / 1e9));
        return;
      }
      while (!done && active < concurrency && launched < total && Date.now() < deadline) {
        const now = Date.now();
        if (interval && now < nextLaunch) { setTimeout(maybe, Math.max(1, nextLaunch - now)); return; }
        if (interval) nextLaunch = Math.max(nextLaunch + interval, now);
        const idx = launched++;
        active++;
        requestOnce(opts, idx).then(r => { results.push(r); active--; maybe(); });
      }
    };
    maybe();
  });
}

function pct(sorted, p) {
  if (!sorted.length) return null;
  const idx = Math.ceil((p / 100) * sorted.length) - 1;
  return sorted[Math.max(0, Math.min(sorted.length - 1, idx))];
}

function unitValue(sec, unit) {
  switch (unit) {
    case 'ns': return [sec * 1e9, 'ns'];
    case 'us': return [sec * 1e6, 'us'];
    case 'ms': return [sec * 1e3, 'ms'];
    case 's': return [sec, 's'];
    case 'm': return [sec / 60, 'm'];
    case 'h': return [sec / 3600, 'h'];
    default:
      if (sec < 1e-6) return [sec * 1e9, 'ns'];
      if (sec < 1e-3) return [sec * 1e6, 'us'];
      if (sec < 1) return [sec * 1e3, 'ms'];
      return [sec, 's'];
  }
}

function fmtTime(sec, unit) {
  if (sec == null) return 'NaN ns';
  if (sec === Infinity) return 'inf ns';
  if (sec === -Infinity) return '-inf ns';
  const [v, u] = unitValue(sec, unit);
  return `${v.toFixed(4)} ${u}`;
}

function fmtBytes(n) {
  if (!Number.isFinite(n)) return 'NaN';
  if (n < 1024) return `${Math.round(n)} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(2)} KiB`;
  return `${(n / 1024 / 1024).toFixed(2)} MiB`;
}

function summarize(results, totalSec) {
  const successes = results.filter(r => r.ok);
  const durations = successes.map(r => r.duration).sort((a, b) => a - b);
  const totalData = successes.reduce((a, r) => a + r.bytes, 0);
  const avg = durations.length ? durations.reduce((a, b) => a + b, 0) / durations.length : null;
  const hist = {};
  if (durations.length) {
    const min = durations[0], max = durations[durations.length - 1];
    const step = (max - min) / 10 || 0;
    for (let i = 0; i <= 10; i++) {
      const edge = min + step * i;
      hist[edge] = 0;
    }
    for (const d of durations) {
      const bucket = step ? Math.min(10, Math.floor((d - min) / step)) : 0;
      const key = Object.keys(hist)[bucket];
      hist[key]++;
    }
  } else {
    hist.NaN = 0;
  }
  const status = {}, errors = {};
  for (const r of results) {
    if (r.status) status[r.status] = (status[r.status] || 0) + 1;
    if (r.error) errors[r.error] = (errors[r.error] || 0) + 1;
  }
  const pcts = {};
  for (const p of [10, 25, 50, 75, 90, 95, 99, 99.9, 99.99]) pcts[`p${p}`] = pct(durations, p);
  return { successes, durations, totalData, avg, hist, status, errors, pcts, totalSec };
}

function formatJson(results, totalSec) {
  const s = summarize(results, totalSec);
  const obj = {
    summary: {
      successRate: results.length ? s.successes.length / results.length : null,
      total: totalSec,
      slowest: s.durations.length ? s.durations[s.durations.length - 1] : null,
      fastest: s.durations.length ? s.durations[0] : null,
      average: s.avg,
      requestsPerSec: totalSec ? results.length / totalSec : null,
      totalData: s.totalData,
      sizePerRequest: s.successes.length ? s.totalData / s.successes.length : null,
      sizePerSec: totalSec ? s.totalData / totalSec : null
    },
    responseTimeHistogram: s.hist,
    latencyPercentiles: s.pcts,
    rps: { mean: null, stddev: null, max: null, min: null, percentiles: { p10: null, p25: null, p50: null, p75: null, p90: null, p95: null, p99: null, 'p99.9': null, 'p99.99': null } },
    details: {
      DNSDialup: { average: null, fastest: null, slowest: null },
      DNSLookup: { average: null, fastest: null, slowest: null }
    },
    statusCodeDistribution: s.status,
    errorDistribution: s.errors
  };
  return JSON.stringify(obj, null, 2) + '\n';
}

function formatCsv(results) {
  let out = 'request-start,DNS,DNS+dialup,Response-delay,request-duration,bytes,status\n';
  let first = results[0] && results[0].start ? results[0].start : process.hrtime.bigint();
  for (const r of results) {
    if (!r.status) continue;
    const st = r.start ? Number(r.start - first) / 1e9 : 0;
    out += `${st},0,0,${r.responseDelay || r.duration},${r.duration},${r.bytes},${r.status}\n`;
  }
  return out;
}

function formatText(opts, results, totalSec) {
  const s = summarize(results, totalSec);
  const successRate = results.length ? (s.successes.length / results.length * 100) : NaN;
  const slowest = s.durations.length ? s.durations[s.durations.length - 1] : -Infinity;
  const fastest = s.durations.length ? s.durations[0] : Infinity;
  const avg = s.avg;
  let out = '';
  out += 'Summary:\n';
  out += `  Success rate:\t${Number.isNaN(successRate) ? 'NaN' : successRate.toFixed(2)}%\n`;
  out += `  Total:\t${fmtTime(totalSec, opts.timeUnit)}\n`;
  out += `  Slowest:\t${fmtTime(slowest, opts.timeUnit)}\n`;
  out += `  Fastest:\t${fmtTime(fastest, opts.timeUnit)}\n`;
  out += `  Average:\t${fmtTime(avg, opts.timeUnit)}\n`;
  out += `  Requests/sec:\t${(totalSec ? results.length / totalSec : 0).toFixed(4)}\n\n`;
  out += `  Total data:\t${fmtBytes(s.totalData)}\n`;
  out += `  Size/request:\t${s.successes.length ? fmtBytes(s.totalData / s.successes.length) : 'NaN'}\n`;
  out += `  Size/sec:\t${fmtBytes(totalSec ? s.totalData / totalSec : 0)}\n\n`;
  out += 'Response time histogram:\n';
  if (s.durations.length) {
    const maxCount = Math.max(...Object.values(s.hist));
    for (const [edge, count] of Object.entries(s.hist)) {
      const bar = '■'.repeat(maxCount ? Math.round(count / maxCount * 32) : 0);
      out += `${fmtTime(Number(edge), opts.timeUnit).padStart(13)} [${count}] |${bar}\n`;
    }
  } else {
    for (let i = 0; i < 11; i++) out += '    NaN ns [0] |\n';
  }
  out += '\nResponse time distribution:\n';
  for (const p of [10, 25, 50, 75, 90, 95, 99, 99.9, 99.99]) out += `  ${p.toFixed(2)}% in ${fmtTime(s.pcts[`p${p}`], opts.timeUnit)}\n`;
  out += '\n\nDetails (average, fastest, slowest):\n';
  out += '  DNS+dialup:\tNaN ns, inf ns, -inf ns\n';
  out += '  DNS-lookup:\tNaN ns, inf ns, -inf ns\n\n';
  out += 'Status code distribution:\n';
  for (const [code, count] of Object.entries(s.status).sort((a, b) => Number(a[0]) - Number(b[0]))) out += `  [${code}] ${count} responses\n`;
  if (Object.keys(s.errors).length) {
    out += '\nError distribution:\n';
    for (const [err, count] of Object.entries(s.errors)) out += `  [${count}] ${err}\n`;
  }
  return out;
}

function formatOutput(opts, results, totalSec) {
  if (opts.outputFormat === 'quiet') return '';
  if (opts.outputFormat === 'json') return formatJson(results, totalSec);
  if (opts.outputFormat === 'csv') return formatCsv(results);
  return formatText(opts, results, totalSec);
}

(async () => {
  try {
    const opts = parseArgs(process.argv.slice(2));
    const out = await runLoad(opts);
    if (opts.output) fs.writeFileSync(opts.output, out);
    else process.stdout.write(out);
  } catch (e) {
    process.stderr.write((e && e.stack) ? e.stack + '\n' : String(e) + '\n');
    process.exit(1);
  }
})();
