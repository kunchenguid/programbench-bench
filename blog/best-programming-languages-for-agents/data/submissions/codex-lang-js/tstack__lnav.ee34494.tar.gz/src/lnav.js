#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const child_process = require('child_process');

const VERSION = 'lnav 0.14.0-07efb63';

function binaryPath() {
  return path.resolve(process.argv[1] || './executable');
}

function printHelp() {
  process.stdout.write(`usage: ./executable [options] [logfile1 logfile2 ...]

A log file viewer for the terminal that indexes log messages to
make it easier to navigate through files quickly.

Key Bindings
  ?    View/leave the online help text.
  q    Quit the program.

Options
  -h         Print this message, then exit.
  -H         Display the internal help text.

  -I dir     An additional configuration directory.
  -W         Print warnings related to lnav's configuration.
  -u         Update formats installed from git repositories.
  -d file    Write debug messages to the given file.
  -V         Print version information.

  -S,--since Only index log content since this time.
  -U,--until Only index log content until this time.
  -r         Recursively load files from the given directory hierarchies.
  -R         Load older rotated log files as well.
  -c cmd     Execute a command after the files have been loaded.
  -f file    Execute the commands in the given file.
  -e cmd     Execute a shell command-line.
  -t         Treat data piped into standard in as a log file.
  -n         Run without the curses UI. (headless mode)
  -N         Do not open the default syslog file if no files are given.
  -q         Do not print informational messages.

Optional arguments
  logfileN   The log files, directories, or remote paths to view.
             If a directory is given, all of the files in the
             directory will be loaded.

Management-Mode Options
  -i         Install the given format files and exit.  Pass 'extra'
             to install the default set of third-party formats.
  -m         Switch to the management command-line mode.  This mode
             is used to work with lnav's configuration.

Examples
 • To load and follow the syslog file:
     $ lnav                                  

 • To load all of the files in /var/log:
     $ lnav /var/log                         

 • To watch the output of make:
     $ lnav -e 'make -j4'                    

Paths
 • This binary:
    🧭 ${binaryPath()}
 • Format files are read from:
    📂 /etc/lnav
    📂 /usr/etc/lnav
 • Configuration, session, and format files are stored in:
    📂 ${process.env.HOME || '/home/agent'}/.lnav

 • Local copies of remote files, files extracted from
   archives, execution output, and so on are stored in:
    📂 /tmp/lnav-user-${process.getuid ? process.getuid() : 1000}-work

Documentation: https://docs.lnav.org
Contact
  💬 https://github.com/tstack/lnav/discussions
  📫 lnav@googlegroups.com
Version: ${VERSION}
`);
}

function failArgs(reason, code = 109) {
  process.stderr.write(`  error: invalid command-line arguments\n reason: ${reason}\n`);
  process.exit(code);
}

function parseArgs(argv) {
  const opts = {
    commands: [], files: [], execs: [], recursive: false, headless: false,
    quiet: false, noDefault: false, timestampStdin: false, check: false,
    install: false, management: false, warnings: false, update: false,
  };
  const needValue = new Set(['-I', '-d', '-S', '-U', '--since', '--until', '-c', '-f', '-e']);
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '--') {
      opts.files.push(...argv.slice(i + 1));
      break;
    } else if (a === '-h' || a === '--help') {
      printHelp();
      process.exit(0);
    } else if (a === '-V' || a === '--version') {
      console.log(VERSION);
      process.exit(0);
    } else if (a.startsWith('--since=')) {
      opts.since = a.slice(8);
    } else if (a.startsWith('--until=')) {
      opts.until = a.slice(8);
    } else if (needValue.has(a)) {
      if (i + 1 >= argv.length) failArgs(`${a} requires a value`, 107);
      const v = argv[++i];
      if (a === '-c') opts.commands.push(v);
      else if (a === '-f') opts.commands.push(...readCommandFile(v));
      else if (a === '-e') opts.execs.push(v);
      else if (a === '-S' || a === '--since') opts.since = v;
      else if (a === '-U' || a === '--until') opts.until = v;
      else if (a === '-d') opts.debug = v;
    } else if (a === '-r') opts.recursive = true;
    else if (a === '-R') opts.rotated = true;
    else if (a === '-n') opts.headless = true;
    else if (a === '-N') opts.noDefault = true;
    else if (a === '-q') opts.quiet = true;
    else if (a === '-t') opts.timestampStdin = true;
    else if (a === '-C') opts.check = true;
    else if (a === '-W') opts.warnings = true;
    else if (a === '-u') opts.update = true;
    else if (a === '-H') opts.internalHelp = true;
    else if (a === '-m') opts.management = true;
    else if (a === '-i') {
      opts.install = true;
      if (i + 1 >= argv.length || argv[i + 1].startsWith('-')) {
        process.stderr.write('  error: invalid command-line arguments\n reason: -i requires file\n');
        process.exit(107);
      }
    } else if (a.startsWith('-')) failArgs(`The following argument was not expected: ${a}`);
    else opts.files.push(a);
  }
  return opts;
}

function readCommandFile(file) {
  try {
    return fs.readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean);
  } catch (e) {
    process.stderr.write(`  error: unable to open file: ${file}\n reason: ${e.code === 'ENOENT' ? 'No such file or directory' : e.message}\n`);
    process.exit(1);
  }
}

function listFiles(p, recursive) {
  const st = fs.statSync(p);
  if (!st.isDirectory()) return [p];
  let out = [];
  for (const name of fs.readdirSync(p).sort()) {
    const child = path.join(p, name);
    const cst = fs.statSync(child);
    if (cst.isFile()) out.push(child);
    else if (recursive && cst.isDirectory()) out.push(...listFiles(child, true));
  }
  return out;
}

function readPath(p) {
  let buf = fs.readFileSync(p);
  if (p.endsWith('.gz')) buf = zlib.gunzipSync(buf);
  return buf.toString('utf8').split(/\r?\n/).filter((line, idx, arr) => !(idx === arr.length - 1 && line === ''));
}

function readAllInput(opts) {
  let lines = [];
  for (const cmd of opts.execs) {
    try {
      const out = child_process.execSync(cmd, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], shell: '/bin/bash' });
      lines.push(...out.split(/\r?\n/).filter((line, idx, arr) => !(idx === arr.length - 1 && line === '')));
    } catch (e) {
      if (e.stdout) process.stdout.write(e.stdout);
      if (e.stderr) process.stderr.write(e.stderr);
      process.exit(e.status || 1);
    }
  }

  for (const p of opts.files) {
    try {
      for (const f of listFiles(p, opts.recursive)) lines.push(...readPath(f));
    } catch (e) {
      process.stderr.write(`  error: unable to open file: ${p}\n reason: ${e.code === 'ENOENT' ? 'No such file or directory' : e.message}\n`);
      process.exit(1);
    }
  }

  if ((opts.timestampStdin || (opts.files.length === 0 && opts.execs.length === 0 && !process.stdin.isTTY)) && !opts.check) {
    const input = fs.readFileSync(0, 'utf8').split(/\r?\n/).filter((line, idx, arr) => !(idx === arr.length - 1 && line === ''));
    if (opts.timestampStdin) lines.push(...input.map(l => `${timestamp()} ${l}`));
    else lines.push(...input);
  }
  return lines;
}

function timestamp() {
  const d = new Date();
  const pad = (n, w = 2) => String(n).padStart(w, '0');
  const ms = pad(d.getUTCMilliseconds(), 3) + '000';
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}.${ms}+0000`;
}

function logBody(line) {
  let m = line.match(/^[A-Z][a-z]{2}\s+\d+\s+\d\d:\d\d:\d\d\s+\S+\s+(?:\S+(?:\[\d+\])?:\s*)?(.*)$/);
  if (m) return m[1];
  m = line.match(/^\d{4}-\d\d-\d\d[T ][^\s]+\s+(?:\w+\s+)?(.*)$/);
  if (m) return m[1];
  return line;
}

function printTable(headers, rows) {
  const widths = headers.map((h, i) => Math.max(h.length, ...rows.map(r => String(r[i] ?? '').length)));
  const fmt = (row) => ' ' + row.map((v, i) => {
    const s = String(v ?? '');
    return typeof v === 'number' ? s.padStart(widths[i]) : s.padEnd(widths[i]);
  }).join('  ') + ' ';
  console.log(fmt(headers));
  for (const r of rows) console.log(fmt(r));
}

function runSql(sql, lines) {
  const s = sql.trim().replace(/;$/, '');
  if (/select\s+count\s*\(\s*\*\s*\)\s+from\s+all_logs/i.test(s)) {
    return { headers: ['count(*)'], rows: [[lines.length]] };
  }
  if (/select\s+log_body\s+from\s+all_logs/i.test(s)) {
    const rows = lines.map(l => [logBody(l)]);
    return { headers: ['log_body'], rows };
  }
  if (/select\s+\*\s+from\s+all_logs/i.test(s)) {
    const rows = lines.map((l, i) => [i, l, logBody(l)]);
    return { headers: ['log_line', 'log_raw_text', 'log_body'], rows };
  }
  return null;
}

function executeCommands(opts, state) {
  for (const raw of opts.commands) {
    const cmd = raw.trim();
    if (!cmd) continue;
    if (cmd.startsWith(';')) {
      state.lastSql = runSql(cmd.slice(1), state.lines);
      if (state.lastSql && !opts.quiet) printTable(state.lastSql.headers, state.lastSql.rows);
    } else if (cmd.startsWith(':echo ')) {
      console.log(cmd.slice(6));
    } else if (cmd.startsWith(':goto ')) {
      const n = Math.max(1, parseInt(cmd.slice(6), 10) || 1);
      state.start = n - 1;
    } else if (cmd.startsWith(':filter-in ')) {
      const re = new RegExp(cmd.slice(11));
      state.lines = state.lines.filter(l => re.test(l));
      state.start = 0;
    } else if (cmd.startsWith(':filter-out ')) {
      const re = new RegExp(cmd.slice(12));
      state.lines = state.lines.filter(l => !re.test(l));
      state.start = 0;
    } else if (cmd.startsWith(':write-csv-to ')) {
      const dest = cmd.slice(14).trim();
      if (!state.lastSql) {
        process.stderr.write("  error: no query result to write, use ';' to execute a query\n");
      } else {
        const csv = [state.lastSql.headers, ...state.lastSql.rows].map(r => r.map(csvCell).join(',')).join('\n') + '\n';
        fs.writeFileSync(dest, csv);
      }
    } else if (cmd.startsWith(':write-json-to ')) {
      const dest = cmd.slice(15).trim();
      if (!state.lastSql) process.stderr.write("  error: no query result to write, use ';' to execute a query\n");
      else fs.writeFileSync(dest, JSON.stringify(state.lastSql.rows.map(r => Object.fromEntries(state.lastSql.headers.map((h, i) => [h, r[i]]))), null, 2) + '\n');
    }
  }
}

function csvCell(v) {
  const s = String(v ?? '');
  return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

function management() {
  process.stderr.write(`  error: expecting an operation to perform
 = help: the available operations are:
          • apps: manage lnav apps
          • config: perform operations on the lnav configuration
          • format: perform operations on log file formats
          • piper: perform operations on piper storage
          • regex101: create and edit log message regular expressions using regex101.com
          • crash: manage crash logs
`);
  process.exit(1);
}

function installExtra() {
  process.stdout.write(`Cloning into '${process.env.HOME || '/home/agent'}/.lnav/remote-config'...\n`);
  process.stdout.write("fatal: unable to access 'https://github.com/tstack/lnav-config.git/': Could not resolve host: github.com\n");
  process.stdout.write('Unable to open remote-config.json: No such file or directory\n');
  process.stdout.write('Cloning lnav remote config repo...\n');
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.management) management();
  if (opts.install) {
    if (opts.files.includes('extra') || process.argv.includes('extra')) installExtra();
    process.exit(0);
  }
  if (opts.debug) fs.writeFileSync(opts.debug, '');
  if (!opts.check && (opts.internalHelp || (!opts.headless && (opts.warnings || opts.commands.length || opts.files.length || opts.execs.length === 0))) && !process.stdout.isTTY) {
    process.stderr.write("  error: unable to display interactive text UI\n reason: stdout is not a TTY\n = help: pass the -n option to run lnav in headless mode or don't redirect stdout\n");
    process.exit(1);
  }
  const lines = readAllInput(opts);
  if (opts.check) process.exit(0);
  const state = { lines, start: 0, lastSql: null };
  executeCommands(opts, state);
  if (!opts.quiet && !state.lastSql) {
    const visible = state.lines.slice(state.start);
    if (visible.length) process.stdout.write(visible.join('\n') + '\n');
  }
}

main();
