#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const http = require("http");
const https = require("https");

const HELP = `Fast directory scanning and scraping tool

Usage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>

Arguments:
  [uri]
          The URI of the host to scan, optionally supports basic auth with
          http://user:pass@host:port

Options:
  -u, --uri <uri>
          Additional hosts to scan [aliases: url]
  -U, --uri-file <uri-file>
          The filename of a file containing a list of URIs to scan - cookies and
          headers set will be applied to all URIs [aliases: url-file]
      --verb <http_verb>
          Specify which HTTP verb to use
           [default: get] [possible values: get, head, post]
  -w, --wordlist <wordlist>
          Sets which wordlist to use, defaults to dirble_wordlist.txt in the same
          folder as the executable
  -p, --prefixes <prefixes>...
          Provides comma separated prefixes to extend queries with
  -P, --prefix-file <prefix-file>
          The name of a file containing extensions to extend queries with, one
          per line
  -x, --extensions <extensions>...
          Provides comma separated extensions to extend queries with
  -X, --extension-file <extension-file>
          The name of a file containing extensions to extend queries with, one
          per line
      --ext-sub
          Indicates whether the string "%EXT%" in a wordlist file should be 
          substituted with the current extension
  -f, --force-extension
          Only scan with provided extensions
  -k, --ignore-cert
          Ignore the certificate validity for HTTPS
      --show-htaccess
          Enable display of items containing .ht when they return 403 responses
      --timeout <timeout>
          Maximum time to wait for a response before giving up, given in seconds
           [default: 5]
      --max-errors <max_errors>
          The number of consecutive errors a thread can have before it exits,
          set to 0 to disable [default: 5]
      --json-file <json_file>
          Sets a file to write JSON output to [aliases: oJ]
      --no-color
          Disable coloring of terminal output
  -o, --output-file <output_file>
          Sets the file to write the report to [aliases: oN]
      --xml-file <xml_file>
          Sets a file to write XML output to [aliases: oX]
      --hide-lengths <length_blacklist>...
          Specify length ranges to hide, e.g. --hide-lengths 348,500-700
      --output-all <output_all>
          Stores all output types respectively as .txt, .json and .xml [aliases: oA]
      --burp
          Sets the proxy to use the default burp proxy values
          (http://localhost:8080)
      --no-proxy
          Disables proxy use even if there is a system proxy
      --proxy <proxy>
          The proxy address to use, including type and port, can also include a
          username and password in the form 
          "http://username:password@proxy_url:proxy_port"
  -t, --max-threads <max-threads>
          Sets the maximum number of request threads that will be spawned [default: 10]
  -T, --wordlist-split <wordlist_split>
          The number of threads to run for each folder/extension combo [default: 3]
  -z, --throttle <milliseconds>
          Time each thread will wait between requests, given in milliseconds
      --username <username>
          Sets the username to authenticate with
      --password <password>
          Sets the password to authenticate with
  -l, --scan-listable
          Scan listable directories
      --max-recursion-depth <max_recursion_depth>
          Sets the maximum directory depth to recurse to, 0 will disable
          recursion
  -r, --disable-recursion
          Disable discovered subdirectory scanning
      --scrape-listable
          Enable scraping of listable directories for urls, often produces large
          amounts of output
  -a, --user-agent <user_agent>
          Set the user-agent provided with requests, by default it isn't set
  -c, --cookie <cookie>
          Provide a cookie in the form "name=value", can be used multiple times
  -H, --header <header>
          Provide an arbitrary header in the form "header:value" - headers with
          no value must end in a semicolon
  -S, --silent
          Don't output information during the scan, only output the report at
          the end.
  -v, --verbose...
          Increase the verbosity level. Use twice for full verbosity.
  -B, --code-blacklist <code_blacklist>...
          Provide a comma separated list of response codes to not show in output
      --disable-validator
          Disable automatic detection of not found codes
  -W, --code-whitelist <code_whitelist>...
          Provide a comma separated list of response codes to show in output,
          also disables detection of not found codes
      --scan-401
          Scan folders even if they return 401 - Unauthorized frequently
      --scan-403
          Scan folders if they return 403 - Forbidden frequently
  -h, --help
          Print help
  -V, --version
          Print version

OUTPUT FORMAT:
    + [url] - File
    D [url] - Directory
    L [url] - Listable Directory

EXAMPLE USE:
    - Run against a website using the default dirble_wordlist.txt from the
      current directory:
        dirble [address]

    - Run with a different wordlist and including .php and .html extensions:
        dirble [address] -w example_wordlist.txt -x .php,.html

    - With listable directory scraping enabled:
        dirble [address] --scrape-listable

    - Providing a list of extensions and a list of URIs:
        dirble [address] -X wordlists/web.lst -U uri-list.txt

    - Providing multiple hosts to scan via command line:
        dirble [address] -u [address] -u [address]`;

const VERSION = "Dirble 1.4.2 (commit d520c82, build 2026-04-17)";

function die(msg, code = 2) {
  process.stderr.write(msg + "\n");
  process.exit(code);
}

function parseNum(name, value) {
  if (!/^\d+$/.test(String(value))) {
    die(`error: invalid value '${value}' for '--${name} <${name.replaceAll("-", "_")}>': invalid digit found in string\n\nFor more information, try '--help'.`);
  }
  return Number(value);
}

function need(args, i, flag) {
  if (i + 1 >= args.length) die(`error: a value is required for '${flag} <${flag.replace(/^--?/, "")}>' but none was supplied\n\nFor more information, try '--help'.`);
  return args[i + 1];
}

function splitValues(v) {
  return String(v).split(",").map(s => s.trim()).filter(Boolean);
}

function parseArgs(argv) {
  const opt = {
    uris: [], uriFiles: [], wordlist: null, verb: "get", prefixes: [], extensions: [],
    extSub: false, forceExtension: false, ignoreCert: false, showHtaccess: false,
    timeout: 5, maxErrors: 5, jsonFile: null, outputFile: null, xmlFile: null,
    outputAll: null, maxThreads: 10, wordlistSplit: 3, throttle: 0, username: null,
    password: null, scanListable: false, maxRecursionDepth: 5, disableRecursion: false,
    scrapeListable: false, userAgent: null, cookies: [], headers: {}, silent: false,
    verbose: 0, codeBlacklist: [], codeWhitelist: [], disableValidator: false,
    hideLengths: [], scan401: false, scan403: false
  };
  let positional = null;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help" || a === "-h") { console.log(HELP); process.exit(0); }
    if (a === "--version" || a === "-V") { console.log(VERSION); process.exit(0); }
    if (a === "--") { if (i + 1 < argv.length) positional = argv[++i]; continue; }
    if (a === "-u" || a === "--uri" || a === "--url") opt.uris.push(need(argv, i++, a));
    else if (a === "-U" || a === "--uri-file" || a === "--url-file") opt.uriFiles.push(need(argv, i++, a));
    else if (a === "--verb") {
      opt.verb = need(argv, i++, a).toLowerCase();
      if (!["get", "head", "post"].includes(opt.verb)) {
        const tip = opt.verb === "put" ? "\n\n  tip: a similar value exists: 'post'" : "";
        die(`error: invalid value '${opt.verb}' for '--verb <http_verb>'\n  [possible values: get, head, post]${tip}\n\nFor more information, try '--help'.`);
      }
    } else if (a === "-w" || a === "--wordlist") opt.wordlist = need(argv, i++, a);
    else if (a === "-p" || a === "--prefixes") opt.prefixes.push(...splitValues(need(argv, i++, a)));
    else if (a === "-P" || a === "--prefix-file") opt.prefixes.push(...readLines(need(argv, i++, a)));
    else if (a === "-x" || a === "--extensions") opt.extensions.push(...splitValues(need(argv, i++, a)).map(normExt));
    else if (a === "-X" || a === "--extension-file") opt.extensions.push(...readLines(need(argv, i++, a)).map(normExt));
    else if (a === "--ext-sub") opt.extSub = true;
    else if (a === "-f" || a === "--force-extension") opt.forceExtension = true;
    else if (a === "-k" || a === "--ignore-cert") opt.ignoreCert = true;
    else if (a === "--show-htaccess") opt.showHtaccess = true;
    else if (a === "--timeout") opt.timeout = parseNum("timeout", need(argv, i++, a));
    else if (a === "--max-errors") opt.maxErrors = parseNum("max-errors", need(argv, i++, a));
    else if (a === "--json-file" || a === "--oJ") opt.jsonFile = need(argv, i++, a);
    else if (a === "--no-color") {}
    else if (a === "-o" || a === "--output-file" || a === "--oN") opt.outputFile = need(argv, i++, a);
    else if (a === "--xml-file" || a === "--oX") opt.xmlFile = need(argv, i++, a);
    else if (a === "--hide-lengths") opt.hideLengths.push(...parseRanges(need(argv, i++, a)));
    else if (a === "--output-all" || a === "--oA") opt.outputAll = need(argv, i++, a);
    else if (a === "--burp" || a === "--no-proxy" || a === "--proxy") { if (a === "--proxy") i++; }
    else if (a === "-t" || a === "--max-threads") opt.maxThreads = parseNum("max-threads", need(argv, i++, a));
    else if (a === "-T" || a === "--wordlist-split") opt.wordlistSplit = parseNum("wordlist-split", need(argv, i++, a));
    else if (a === "-z" || a === "--throttle") opt.throttle = parseNum("throttle", need(argv, i++, a));
    else if (a === "--username") opt.username = need(argv, i++, a);
    else if (a === "--password") opt.password = need(argv, i++, a);
    else if (a === "-l" || a === "--scan-listable") opt.scanListable = true;
    else if (a === "--max-recursion-depth") opt.maxRecursionDepth = parseNum("max-recursion-depth", need(argv, i++, a));
    else if (a === "-r" || a === "--disable-recursion") opt.disableRecursion = true;
    else if (a === "--scrape-listable") opt.scrapeListable = true;
    else if (a === "-a" || a === "--user-agent") opt.userAgent = need(argv, i++, a);
    else if (a === "-c" || a === "--cookie") opt.cookies.push(need(argv, i++, a));
    else if (a === "-H" || a === "--header") addHeader(opt, need(argv, i++, a));
    else if (a === "-S" || a === "--silent") opt.silent = true;
    else if (a === "-v" || a === "--verbose") opt.verbose++;
    else if (a.startsWith("-v") && /^-v+$/.test(a)) opt.verbose += a.length - 1;
    else if (a === "-B" || a === "--code-blacklist") opt.codeBlacklist.push(...splitValues(need(argv, i++, a)).map(Number));
    else if (a === "-W" || a === "--code-whitelist") { opt.codeWhitelist.push(...splitValues(need(argv, i++, a)).map(Number)); opt.disableValidator = true; }
    else if (a === "--disable-validator") opt.disableValidator = true;
    else if (a === "--scan-401") opt.scan401 = true;
    else if (a === "--scan-403") opt.scan403 = true;
    else if (a.startsWith("-")) die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>\n\nFor more information, try '--help'.`);
    else if (positional === null) positional = a;
    else die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>\n\nFor more information, try '--help'.`);
  }
  if (positional) opt.uris.unshift(positional);
  if (opt.uriFiles.length) {
    for (const f of opt.uriFiles) opt.uris.push(...readLines(f));
  }
  if (opt.uris.length === 0) { console.log(HELP); process.exit(2); }
  if (opt.outputAll) {
    opt.outputFile = opt.outputAll + ".txt";
    opt.jsonFile = opt.outputAll + ".json";
    opt.xmlFile = opt.outputAll + ".xml";
  }
  return opt;
}

function readLines(file) {
  return fs.readFileSync(file, "utf8").split(/\r?\n/).map(s => s.trim()).filter(s => s && !s.startsWith("#"));
}

function normExt(e) {
  return e;
}

function addHeader(opt, h) {
  if (h.endsWith(";") && !h.includes(":")) opt.headers[h.slice(0, -1)] = "";
  else {
    const idx = h.indexOf(":");
    if (idx >= 0) opt.headers[h.slice(0, idx).trim()] = h.slice(idx + 1).trim();
  }
}

function parseRanges(v) {
  return splitValues(v).map(x => {
    const [a, b] = x.split("-");
    return [Number(a), b === undefined ? Number(a) : Number(b)];
  }).filter(r => !Number.isNaN(r[0]) && !Number.isNaN(r[1]));
}

function normalizeUri(u) {
  let url;
  try { url = new URL(u); } catch (e) {
    die(`error: invalid value '${u}' for '[uri]': ${e.message}\n\nFor more information, try '--help'.`);
  }
  if (!url.pathname.endsWith("/")) url.pathname += "/";
  url.search = "";
  url.hash = "";
  return url.toString();
}

function panicReadWordlist(file) {
  try { return readLines(file); } catch (e) {
    process.stderr.write(`\nthread 'main' (100) panicked at src/wordlist.rs:112:37:\ncalled \`Result::unwrap()\` on an \`Err\` value: Os { code: ${e.errno === -2 ? 2 : 13}, kind: ${e.code === "ENOENT" ? "NotFound" : "PermissionDenied"}, message: "${e.code === "ENOENT" ? "No such file or directory" : e.message}" }\nnote: run with \`RUST_BACKTRACE=1\` environment variable to display a backtrace\n`);
    process.exit(101);
  }
}

function candidates(words, opt) {
  const prefixes = opt.prefixes.length ? opt.prefixes : [""];
  const exts = opt.extensions.length ? opt.extensions : [];
  const out = [];
  for (const p of prefixes) for (const w of words) {
    if (opt.extSub && w.includes("%EXT%") && exts.length) {
      for (const e of exts) out.push(p + w.replaceAll("%EXT%", e));
      continue;
    }
    if (!opt.forceExtension) out.push(p + w);
    for (const e of exts) {
      const clean = w.endsWith("/") ? w.slice(0, -1) : w;
      if (clean.includes("%EXT%")) continue;
      out.push(p + clean + e);
    }
  }
  return out;
}

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

async function requestUrl(url, opt, redirects = 5) {
  const mod = url.startsWith("https:") ? https : http;
  return new Promise(resolve => {
    let done = false;
    const u = new URL(url);
    const headers = Object.assign({}, opt.headers);
    if (opt.userAgent) headers["User-Agent"] = opt.userAgent;
    if (opt.cookies.length) headers.Cookie = opt.cookies.join("; ");
    if (opt.username || opt.password) {
      headers.Authorization = "Basic " + Buffer.from(`${opt.username || ""}:${opt.password || ""}`).toString("base64");
    } else if (u.username || u.password) {
      headers.Authorization = "Basic " + Buffer.from(`${decodeURIComponent(u.username)}:${decodeURIComponent(u.password)}`).toString("base64");
      u.username = ""; u.password = "";
    }
    const req = mod.request(u, {
      method: opt.verb.toUpperCase(),
      headers,
      rejectUnauthorized: !opt.ignoreCert,
      timeout: opt.timeout * 1000
    }, res => {
      let chunks = [];
      res.on("data", d => chunks.push(d));
      res.on("end", () => {
        if (done) return; done = true;
        const body = Buffer.concat(chunks);
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && redirects > 0) {
          resolve(requestUrl(new URL(res.headers.location, url).toString(), opt, redirects - 1));
          return;
        }
        resolve({ ok: true, code: res.statusCode || 0, size: Number(res.headers["content-length"] || body.length || 0), body: body.toString("utf8"), headers: res.headers, finalUrl: url });
      });
    });
    req.on("timeout", () => req.destroy(new Error("Timeout was reached")));
    req.on("error", err => { if (!done) { done = true; resolve({ ok: false, error: err.message }); } });
    if (opt.verb === "post") req.write("");
    req.end();
  });
}

function randomPath(n) {
  const s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let r = "";
  for (let i = 0; i < n; i++) r += s[Math.floor(Math.random() * s.length)];
  return r;
}

async function validateBase(base, opt) {
  if (opt.disableValidator) return new Set([404]);
  const codes = [];
  for (const n of [10, 20, 30]) {
    const url = joinUrl(base, randomPath(n));
    const r = await requestUrl(url, opt);
    if (!r.ok) {
      if (!opt.silent) console.log(`Curl error after requesting ${url} : [7] Could not connect to server (${r.error})`);
      continue;
    }
    codes.push(r.code);
  }
  if (codes.length === 0) {
    if (!opt.silent) console.log(`[WARN] ${base} errored too often during validation, skipping scanning`);
    return null;
  }
  const first = codes[0];
  if (!opt.silent) console.log(`[INFO] Detected nonexistent paths for ${base} are (CODE:${first})`);
  return new Set(codes);
}

function joinUrl(base, item) {
  const b = base.endsWith("/") ? base : base + "/";
  return new URL(item.replace(/^\/+/, ""), b).toString();
}

function isListable(body) {
  return /<title>\s*Index of /i.test(body) || /Directory Listing/i.test(body);
}

function resultLine(r) {
  const k = r.is_listable ? "L" : (r.is_directory ? "D" : "+");
  const redir = r.redirect_url ? `|REDIRECT:${r.redirect_url}` : "";
  return `${k} ${r.url} (CODE:${r.code}|SIZE:${r.size}${redir})`;
}

function visibleConsole(r, opt) {
  if (r.url.includes(".ht") && r.code === 403 && !opt.showHtaccess) return false;
  return !hideLen(r.size, opt);
}

function hideLen(size, opt) {
  return opt.hideLengths.some(([a, b]) => size >= a && size <= b);
}

function allowed(r, notFoundCodes, opt) {
  if (!r.ok) return false;
  if (opt.codeWhitelist.length && !opt.codeWhitelist.includes(r.code)) return false;
  if (opt.codeBlacklist.includes(r.code)) return false;
  if (!opt.disableValidator && notFoundCodes && notFoundCodes.has(r.code)) return false;
  if (r.code >= 400 && ![401, 403].includes(r.code)) return false;
  return true;
}

async function scanBase(base, words, opt, depth = 0, all = []) {
  const notFound = await validateBase(base, opt);
  if (notFound === null) return all;
  const dirs = [];
  for (const item of candidates(words, opt)) {
    if (opt.throttle) await delay(opt.throttle);
    const url = joinUrl(base, item);
    const resp = await requestUrl(url, opt);
    if (!allowed(resp, notFound, opt)) continue;
    const loc = "";
    let isDir = item.endsWith("/") || (resp.finalUrl || url).endsWith("/");
    let finalUrl = resp.finalUrl || url;
    if (isDir && !finalUrl.endsWith("/")) finalUrl += "/";
    const rec = { url: finalUrl, code: resp.code, size: resp.size, is_directory: isDir, is_listable: opt.scanListable && isDir && isListable(resp.body || ""), redirect_url: loc, found_from_listable: false };
    all.push(rec);
    if (!opt.silent && visibleConsole(rec, opt)) console.log(resultLine(rec));
    if (isDir && !opt.disableRecursion && depth < opt.maxRecursionDepth && dirs.length < 50) dirs.push(finalUrl);
  }
  for (const d of dirs) await scanBase(d, words, opt, depth + 1, all);
  return all;
}

function textReport(results, bases, opt) {
  let s = "";
  for (const b of bases) s += `Dirble Scan Report for ${b}:\n`;
  const files = results.filter(r => !r.is_directory && visibleConsole(r, opt)).sort((a, b) => a.url.localeCompare(b.url));
  const dirs = results.filter(r => r.is_directory && visibleConsole(r, opt)).sort((a, b) => a.url.localeCompare(b.url));
  for (const r of files) s += resultLine(r) + "\n";
  if (files.length || dirs.length) s += "\n";
  for (const r of dirs) s += resultLine(r) + "\n\n";
  return s;
}

function sortedResults(results) {
  const cmp = (a, b) => a.url.localeCompare(b.url);
  return results.filter(r => !r.is_directory).sort(cmp).concat(results.filter(r => r.is_directory).sort(cmp));
}

function jsonReport(results) {
  return "[" + sortedResults(results).map(r => JSON.stringify(r)).join(",\n") + "]";
}

function esc(s) { return String(s).replaceAll("&", "&amp;").replaceAll("\"", "&quot;").replaceAll("<", "&lt;").replaceAll(">", "&gt;"); }

function xmlReport(results) {
  let s = `<?xml version="1.0" encoding="UTF-8"?>\n<dirble_scan>\n`;
  for (const r of sortedResults(results)) {
    s += `<path url="${esc(r.url)}" code="${r.code}" content_len="${r.size}" is_directory="${r.is_directory}" is_listable="${r.is_listable}" redirect_url="${esc(r.redirect_url)}" found_from_listable="${r.found_from_listable}"/>\n`;
  }
  return s + `</dirble_scan>`;
}

(async function main() {
  const opt = parseArgs(process.argv.slice(2));
  const wordlist = opt.wordlist || path.join(path.dirname(process.argv[1]), "dirble_wordlist.txt");
  const words = panicReadWordlist(wordlist);
  const bases = opt.uris.map(normalizeUri);
  const results = [];
  for (const b of bases) await scanBase(b, words, opt, 0, results);
  if (opt.outputFile) fs.writeFileSync(opt.outputFile, textReport(results, bases, opt));
  if (opt.jsonFile) fs.writeFileSync(opt.jsonFile, jsonReport(results));
  if (opt.xmlFile) fs.writeFileSync(opt.xmlFile, xmlReport(results));
})().catch(e => { process.stderr.write(String(e.stack || e) + "\n"); process.exit(1); });
