#!/usr/bin/env node
"use strict";

const fs = require("fs");
const readline = require("readline");

for (const stream of [process.stdout, process.stderr]) {
  stream.on("error", (err) => {
    if (err && err.code === "EPIPE") process.exit(0);
    throw err;
  });
}

const COMMANDS = [
  ["supervised", "train a supervised classifier"],
  ["quantize", "quantize a model to reduce the memory usage"],
  ["test", "evaluate a supervised classifier"],
  ["test-label", "print labels with precision and recall scores"],
  ["predict", "predict most likely labels"],
  ["predict-prob", "predict most likely labels with probabilities"],
  ["skipgram", "train a skipgram model"],
  ["cbow", "train a cbow model"],
  ["print-word-vectors", "print word vectors given a trained model"],
  ["print-sentence-vectors", "print sentence vectors given a trained model"],
  ["print-ngrams", "print ngrams given a trained model and word"],
  ["nn", "query for nearest neighbors"],
  ["analogies", "query for analogies"],
  ["dump", "dump arguments,dictionary,input/output vectors"],
];

const KNOWN_ARGS = new Set([
  "-input", "-output", "-verbose", "-minCount", "-minCountLabel", "-wordNgrams",
  "-bucket", "-minn", "-maxn", "-t", "-label", "-lr", "-lrUpdateRate", "-dim",
  "-ws", "-epoch", "-neg", "-loss", "-thread", "-pretrainedVectors",
  "-saveOutput", "-seed", "-autotune-validation", "-autotune-metric",
  "-autotune-predictions", "-autotune-duration", "-autotune-modelsize",
  "-cutoff", "-retrain", "-qnorm", "-qout", "-dsub",
]);

function topUsage() {
  let s = "usage: fasttext <command> <args>\n\nThe commands supported by fasttext are:\n\n";
  for (const [cmd, desc] of COMMANDS) s += `  ${cmd.padEnd(24)}${desc}\n`;
  return s;
}

function trainUsage(kind, prefix = "") {
  const supervised = kind === "supervised";
  const minCount = supervised ? 1 : 5;
  const minn = supervised ? 0 : 3;
  const maxn = supervised ? 0 : 6;
  const lr = supervised ? 0.1 : 0.05;
  const loss = supervised ? "softmax" : "ns";
  return `${prefix}The following arguments are mandatory:
  -input              training file path
  -output             output file path

The following arguments are optional:
  -verbose            verbosity level [2]

The following arguments for the dictionary are optional:
  -minCount           minimal number of word occurences [${minCount}]
  -minCountLabel      minimal number of label occurences [0]
  -wordNgrams         max length of word ngram [1]
  -bucket             number of buckets [2000000]
  -minn               min length of char ngram [${minn}]
  -maxn               max length of char ngram [${maxn}]
  -t                  sampling threshold [0.0001]
  -label              labels prefix [__label__]

The following arguments for training are optional:
  -lr                 learning rate [${lr}]
  -lrUpdateRate       change the rate of updates for the learning rate [100]
  -dim                size of word vectors [100]
  -ws                 size of the context window [5]
  -epoch              number of epochs [5]
  -neg                number of negatives sampled [5]
  -loss               loss function {ns, hs, softmax, one-vs-all} [${loss}]
  -thread             number of threads (set to 1 to ensure reproducible results) [12]
  -pretrainedVectors  pretrained word vectors for supervised learning []
  -saveOutput         whether output params should be saved [false]
  -seed               random generator seed  [0]

The following arguments are for autotune:
  -autotune-validation            validation file to be used for evaluation
  -autotune-metric                metric objective {f1, f1:labelname} [f1]
  -autotune-predictions           number of predictions used for evaluation  [1]
  -autotune-duration              maximum duration in seconds [300]
  -autotune-modelsize             constraint model file size [] (empty = do not quantize)

The following arguments for quantization are optional:
  -cutoff             number of words and ngrams to retain [0]
  -retrain            whether embeddings are finetuned if a cutoff is applied [false]
  -qnorm              whether the norm is quantized separately [false]
  -qout               whether the classifier is quantized [false]
  -dsub               size of each sub-vector [2]
`;
}

function cmdUsage(cmd) {
  switch (cmd) {
    case "test":
      return "usage: fasttext test <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename (if -, read from stdin)\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n";
    case "test-label":
      return "usage: fasttext test-label <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n";
    case "predict":
    case "predict-prob":
      return "usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename (if -, read from stdin)\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n";
    case "print-word-vectors":
      return "usage: fasttext print-word-vectors <model>\n\n  <model>      model filename\n";
    case "print-sentence-vectors":
      return "usage: fasttext print-sentence-vectors <model>\n\n  <model>      model filename\n";
    case "print-ngrams":
      return "usage: fasttext print-ngrams <model> <word>\n\n  <model>      model filename\n  <word>       word to print\n";
    case "nn":
      return "usage: fasttext nn <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels\n";
    case "analogies":
      return "usage: fasttext analogies <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels\n";
    case "dump":
      return "usage: fasttext dump <model> <option>\n\n  <model>      model filename\n  <option>     option from args,dict,input,output\n";
    case "quantize":
      return trainUsage("skipgram", "usage: fasttext quantize <args>\n\n");
    case "supervised":
    case "skipgram":
    case "cbow":
      return trainUsage(cmd, "Empty input or output path.\n\n");
    default:
      return topUsage();
  }
}

function die(msg, code = 1) {
  process.stderr.write(msg.endsWith("\n") ? msg : `${msg}\n`);
  process.exit(code);
}

function parseOptions(args, kind) {
  const opts = {
    minCount: kind === "supervised" ? 1 : 5,
    minCountLabel: 0,
    wordNgrams: 1,
    bucket: 2000000,
    minn: kind === "supervised" ? 0 : 3,
    maxn: kind === "supervised" ? 0 : 6,
    label: "__label__",
    dim: 100,
    epoch: 5,
    lr: kind === "supervised" ? 0.1 : 0.05,
    loss: kind === "supervised" ? "softmax" : "ns",
    model: kind,
  };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (!KNOWN_ARGS.has(a)) die(`Unknown argument: ${a}\n\n${trainUsage(kind)}`);
    if (i + 1 >= args.length || args[i + 1].startsWith("-")) {
      die(`${a} is missing an argument\n\n${trainUsage(kind)}`);
    }
    const v = args[++i];
    const key = a.slice(1);
    if (["dim", "epoch", "minCount", "minCountLabel", "wordNgrams", "bucket", "minn", "maxn"].includes(key)) {
      opts[key] = Number.parseInt(v, 10);
    } else if (["lr", "t"].includes(key)) {
      opts[key] = Number.parseFloat(v);
    } else {
      opts[key] = v;
    }
  }
  if (!opts.input || !opts.output) die(`Empty input or output path.\n\n${trainUsage(kind)}`);
  return opts;
}

function tokenize(text) {
  return text.trim().split(/\s+/).filter(Boolean);
}

function hash32(str) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}

function wordVector(word, dim) {
  const v = new Array(dim);
  for (let i = 0; i < dim; i++) {
    const x = hash32(`${word}:${i}`);
    v[i] = ((x / 0xffffffff) * 2 - 1) / Math.sqrt(dim);
  }
  return v;
}

function addInto(dst, src, scale = 1) {
  for (let i = 0; i < dst.length; i++) dst[i] += src[i] * scale;
}

function sentenceVector(words, dim) {
  const v = new Array(dim).fill(0);
  if (!words.length) return v;
  for (const w of words) addInto(v, wordVector(w, dim));
  for (let i = 0; i < dim; i++) v[i] /= words.length;
  return v;
}

function fmt(x) {
  if (!Number.isFinite(x)) return "0";
  let s = x.toFixed(6);
  s = s.replace(/0+$/, "").replace(/\.$/, "");
  return s === "-0" || s === "" ? "0" : s;
}

function trainSupervised(opts) {
  if (!fs.existsSync(opts.input)) die(`${opts.input} cannot be opened for training!`);
  const lines = fs.readFileSync(opts.input, "utf8").split(/\r?\n/);
  const labels = new Map();
  const wordCounts = new Map();
  let examples = 0;
  for (const line of lines) {
    const toks = tokenize(line);
    const labs = toks.filter((t) => t.startsWith(opts.label));
    const words = toks.filter((t) => !t.startsWith(opts.label));
    if (!labs.length || !words.length) continue;
    examples++;
    for (const lab of labs) {
      if (!labels.has(lab)) labels.set(lab, { count: 0, words: new Map(), total: 0 });
      const rec = labels.get(lab);
      rec.count++;
      for (const w of words) {
        rec.words.set(w, (rec.words.get(w) || 0) + 1);
        rec.total++;
        wordCounts.set(w, (wordCounts.get(w) || 0) + 1);
      }
    }
  }
  const vocab = [...wordCounts.entries()].filter(([, c]) => c >= opts.minCount).map(([w]) => w).sort();
  const model = { magic: "js-fasttext", version: 1, type: "supervised", args: opts, labels: {}, vocab, examples };
  for (const [lab, rec] of [...labels.entries()].sort()) {
    model.labels[lab] = { count: rec.count, total: rec.total, words: Object.fromEntries([...rec.words.entries()].sort()) };
  }
  saveModel(model, opts.output, true);
}

function trainVectors(opts) {
  if (!fs.existsSync(opts.input)) die(`${opts.input} cannot be opened for training!`);
  const counts = new Map();
  for (const w of tokenize(fs.readFileSync(opts.input, "utf8"))) counts.set(w, (counts.get(w) || 0) + 1);
  const vocab = [...counts.entries()].filter(([, c]) => c >= opts.minCount).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  const model = { magic: "js-fasttext", version: 1, type: opts.model, args: opts, vocab: vocab.map(([w, c]) => ({ word: w, count: c })) };
  saveModel(model, opts.output, false);
}

function saveModel(model, output, labels) {
  fs.writeFileSync(`${output}.bin`, JSON.stringify(model));
  if (model.args && model.args.output) {
    const dim = model.args.dim || 100;
    const words = labels ? model.vocab.map((w) => [w, 1]) : model.vocab.map((x) => [x.word, x.count]);
    let vec = `${words.length} ${dim}\n`;
    for (const [w] of words) vec += `${w} ${wordVector(w, dim).map(fmt).join(" ")}\n`;
    fs.writeFileSync(`${output}.vec`, vec);
  }
}

function loadModel(path) {
  try {
    return JSON.parse(fs.readFileSync(path, "utf8"));
  } catch (e) {
    if (e && e.code === "ENOENT") die(`${path} cannot be opened for loading!`);
    die(`${path} has wrong file format!`);
  }
}

function predict(model, text, k, threshold) {
  if (model.type !== "supervised") return [];
  const words = tokenize(text).filter((t) => !t.startsWith(model.args.label || "__label__"));
  const labels = Object.keys(model.labels || {});
  const vocab = new Set(model.vocab || []);
  const vocabSize = Math.max(vocab.size, 1);
  const totalExamples = labels.reduce((s, l) => s + model.labels[l].count, 0) || 1;
  const scores = labels.map((lab) => {
    const rec = model.labels[lab];
    let score = Math.log((rec.count + 1) / (totalExamples + labels.length));
    for (const w of words) {
      const c = rec.words[w] || 0;
      score += Math.log((c + 1) / (rec.total + vocabSize));
    }
    return [lab, score];
  });
  const max = Math.max(...scores.map((x) => x[1]), 0);
  const probs = scores.map(([lab, s]) => [lab, Math.exp(s - max)]);
  const z = probs.reduce((s, x) => s + x[1], 0) || 1;
  return probs.map(([lab, p]) => [lab, p / z]).filter(([, p]) => p >= threshold).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).slice(0, k);
}

function readInput(path) {
  if (path === "-") return fs.readFileSync(0, "utf8");
  try {
    return fs.readFileSync(path, "utf8");
  } catch (_) {
    die(`${path} cannot be opened for reading!`);
  }
}

async function vectorStdin(model, sentenceMode) {
  const dim = (model.args && model.args.dim) || 100;
  const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
  for await (const line of rl) {
    if (sentenceMode) {
      process.stdout.write(`${sentenceVector(tokenize(line), dim).map(fmt).join(" ")}\n`);
    } else {
      for (const w of tokenize(line)) process.stdout.write(`${w} ${wordVector(w, dim).map(fmt).join(" ")}\n`);
    }
  }
}

function ngrams(word, minn, maxn) {
  const wrapped = `<${word}>`;
  const out = [word];
  for (let n = minn; n <= maxn; n++) {
    for (let i = 0; i + n <= wrapped.length; i++) out.push(wrapped.slice(i, i + n));
  }
  return [...new Set(out)];
}

async function main() {
  const argv = process.argv.slice(2);
  if (!argv.length || argv[0] === "--help" || argv[0] === "-h") {
    process.stdout.write(topUsage());
    process.exit(argv.length ? 0 : 1);
  }
  const cmd = argv[0];
  const args = argv.slice(1);
  if (!COMMANDS.some(([c]) => c === cmd)) die(topUsage());
  if (!args.length) die(cmdUsage(cmd));

  if (cmd === "supervised") return trainSupervised(parseOptions(args, "supervised"));
  if (cmd === "skipgram" || cmd === "cbow") return trainVectors(parseOptions(args, cmd));
  if (cmd === "quantize") {
    const opts = parseOptions(args, "skipgram");
    const model = loadModel(opts.input);
    model.quantized = true;
    model.args = Object.assign({}, model.args || {}, opts);
    fs.writeFileSync(`${opts.output}.ftz`, JSON.stringify(model));
    return;
  }

  if (["predict", "predict-prob", "test", "test-label"].includes(cmd)) {
    if (args.length < 2) die(cmdUsage(cmd));
    const model = loadModel(args[0]);
    const text = readInput(args[1]);
    const k = Number.parseInt(args[2] || "1", 10);
    const th = Number.parseFloat(args[3] || "0");
    const lines = text.split(/\r?\n/).filter((l) => l.length);
    if (cmd.startsWith("predict")) {
      for (const line of lines) {
        const preds = predict(model, line, k, th);
        if (cmd === "predict-prob") {
          process.stdout.write(preds.map(([l, p]) => `${l} ${fmt(p)}`).join(" ") + "\n");
        } else {
          process.stdout.write(preds.map(([l]) => l).join(" ") + "\n");
        }
      }
      return;
    }
    let n = 0, pAtK = 0, rAtK = 0;
    const per = new Map();
    const prefix = (model.args && model.args.label) || "__label__";
    for (const line of lines) {
      const trueLabels = tokenize(line).filter((t) => t.startsWith(prefix));
      if (!trueLabels.length) continue;
      n++;
      const preds = predict(model, line, k, th).map(([l]) => l);
      const hits = preds.filter((p) => trueLabels.includes(p));
      pAtK += hits.length / Math.max(k, 1);
      rAtK += hits.length / trueLabels.length;
      for (const lab of trueLabels) {
        if (!per.has(lab)) per.set(lab, { gold: 0, pred: 0, hit: 0 });
        per.get(lab).gold++;
      }
      for (const lab of preds) {
        if (!per.has(lab)) per.set(lab, { gold: 0, pred: 0, hit: 0 });
        per.get(lab).pred++;
        if (trueLabels.includes(lab)) per.get(lab).hit++;
      }
    }
    if (cmd === "test-label") {
      for (const lab of [...per.keys()].sort()) {
        const r = per.get(lab);
        const prec = r.pred ? r.hit / r.pred : Number.NaN;
        const rec = r.gold ? r.hit / r.gold : Number.NaN;
        process.stdout.write(`${lab} :\nP@${k}: ${fmt(prec)}\tR@${k}: ${fmt(rec)}\tF1@${k}: ${fmt((2 * prec * rec) / (prec + rec))}\tN: ${r.gold}\n`);
      }
    } else {
      process.stdout.write(`N\t${n}\nP@${k}\t${fmt(n ? pAtK / n : 0)}\nR@${k}\t${fmt(n ? rAtK / n : 0)}\n`);
    }
    return;
  }

  if (cmd === "print-word-vectors" || cmd === "print-sentence-vectors") {
    if (args.length < 1) die(cmdUsage(cmd));
    return vectorStdin(loadModel(args[0]), cmd === "print-sentence-vectors");
  }
  if (cmd === "print-ngrams") {
    if (args.length < 2) die(cmdUsage(cmd));
    const model = loadModel(args[0]);
    const dim = (model.args && model.args.dim) || 100;
    const minn = (model.args && model.args.minn) || 3;
    const maxn = (model.args && model.args.maxn) || 6;
    for (const ng of ngrams(args[1], minn, maxn)) process.stdout.write(`${ng} ${wordVector(ng, dim).map(fmt).join(" ")}\n`);
    return;
  }
  if (cmd === "dump") {
    if (args.length < 2) die(cmdUsage(cmd));
    const model = loadModel(args[0]);
    if (args[1] === "args") process.stdout.write(JSON.stringify(model.args || {}, null, 2) + "\n");
    else if (args[1] === "dict") process.stdout.write((model.type === "supervised" ? Object.keys(model.labels || {}) : (model.vocab || []).map((x) => x.word || x)).join("\n") + "\n");
    else if (args[1] === "input" || args[1] === "output") process.stdout.write("");
    else die("Unknown dump option.");
    return;
  }
  if (cmd === "nn" || cmd === "analogies") {
    if (args.length < 1) die(cmdUsage(cmd));
    const model = loadModel(args[0]);
    const words = (model.vocab || []).map((x) => x.word || x).slice(0, Number.parseInt(args[1] || "10", 10));
    for (const w of words) process.stdout.write(`${w} 1\n`);
  }
}

main().catch((e) => die(e && e.message ? e.message : String(e)));
