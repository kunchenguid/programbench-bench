#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "3.0.0-20260303205914-9926ea38658f";

function help() {
  return `Usage of ./executable:
  -apply-to-generated-files
\tApply imports sorting and formatting(if the option is set) to generated files. Generated file is a file with first comment which starts with comment '// Code generated'. Optional parameter.
  -company-prefixes string
\tCompany package prefixes which will be placed after 3rd-party group by default(if defined). Values should be comma-separated. Optional parameters.
  -excludes string
\tExclude files or dirs, example: '.git/,proto/*.go'.
  -file-path string
\tDeprecated. Put file name as an argument(last item) of command line.
  -format
\tOption will perform additional formatting. Optional parameter.
  -imports-order string
\tYour imports groups can be sorted in your way. 
\tstd - std import group; 
\tgeneral - libs for general purpose; 
\tcompany - inter-org or your company libs(if you set '-company-prefixes'-option, then 4th group will be split separately. In other case, it will be the part of general purpose libs); 
\tproject - your local project dependencies;
\tblanked - imports with "_" alias;
\tdotted - imports with "." alias.
\tOptional parameter. (default "std,general,company,project")
  -list-diff
\tOption will list files whose formatting differs from goimports-reviser. Optional parameter.
  -local string
\tDeprecated
  -output string
\tCan be "file", "write" or "stdout". Whether to write the formatted content back to the file or to stdout. When "write" together with "-list-diff" will list the file name and write back to the file. Optional parameter. (default "file")
  -project-name string
\tYour project name(ex.: github.com/incu6us/goimports-reviser). Optional parameter.
  -recursive
\tApply rules recursively if target is a directory. In case of ./... execution will be recursively applied by default. Optional parameter.
  -rm-unused
\tRemove unused imports. Optional parameter.
  -separate-named
\tOption will separate named imports from the rest of the imports, per group. Optional parameter.
  -set-alias
\tSet alias for versioned package names, like 'github.com/go-pg/pg/v9'. In this case import will be set as 'pg "github.com/go-pg/pg/v9"'. Optional parameter.
  -set-exit-status
\tset the exit status to 1 if a change is needed/made. Optional parameter.
  -use-cache
\tUse cache to improve performance. Optional parameter.
  -version
\tShow version information
  -version-only
\tShow only the version string`;
}

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}/${p(d.getUTCMonth() + 1)}/${p(d.getUTCDate())} ${p(d.getUTCHours())}:${p(d.getUTCMinutes())}:${p(d.getUTCSeconds())}`;
}

function log(msg) {
  console.error(`${stamp()} ${msg}`);
}

function parseArgs(argv) {
  const opts = {
    applyGenerated: false,
    companyPrefixes: "",
    excludes: "",
    filePath: "",
    format: false,
    importsOrder: "std,general,company,project",
    listDiff: false,
    local: "",
    output: "file",
    projectName: "",
    recursive: false,
    rmUnused: false,
    separateNamed: false,
    setAlias: false,
    setExitStatus: false,
    useCache: false,
    targets: [],
  };
  const stringFlags = new Set(["-company-prefixes", "-excludes", "-file-path", "-imports-order", "-local", "-output", "-project-name"]);
  const boolMap = {
    "-apply-to-generated-files": "applyGenerated",
    "-format": "format",
    "-list-diff": "listDiff",
    "-recursive": "recursive",
    "-rm-unused": "rmUnused",
    "-separate-named": "separateNamed",
    "-set-alias": "setAlias",
    "-set-exit-status": "setExitStatus",
    "-use-cache": "useCache",
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help" || a === "-h") {
      console.log(help());
      process.exit(0);
    }
    if (a === "-version") {
      console.log(`version: ${VERSION}\nbuilt with: go1.26.0\ntag: v${VERSION}\ncommit: n/a\nsource: github.com/incu6us/goimports-reviser/v3`);
      process.exit(0);
    }
    if (a === "-version-only") {
      console.log(VERSION);
      process.exit(0);
    }
    if (a.startsWith("-")) {
      const eq = a.indexOf("=");
      const name = eq >= 0 ? a.slice(0, eq) : a;
      if (stringFlags.has(name)) {
        const val = eq >= 0 ? a.slice(eq + 1) : argv[++i];
        if (val === undefined) die(`flag needs an argument: ${name}`, 2, true);
        const key = name.slice(1).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
        opts[key] = val;
      } else if (boolMap[name]) {
        opts[boolMap[name]] = true;
      } else {
        console.error(`flag provided but not defined: ${name}`);
        console.error(help());
        process.exit(2);
      }
    } else {
      opts.targets.push(a);
    }
  }
  if (opts.filePath && opts.targets.length === 0) opts.targets.push(opts.filePath);
  if (!["file", "write", "stdout"].includes(opts.output)) {
    console.error(help());
    log(`output value is not valid: ${opts.output}`);
    process.exit(1);
  }
  return opts;
}

function die(msg, code = 1, usage = false) {
  if (usage) console.error(help());
  log(msg);
  process.exit(code);
}

function findModule(start) {
  let dir = fs.statSync(start).isDirectory() ? start : path.dirname(start);
  while (true) {
    const p = path.join(dir, "go.mod");
    if (fs.existsSync(p)) {
      const m = fs.readFileSync(p, "utf8").match(/^\s*module\s+(\S+)/m);
      if (m) return m[1];
    }
    const next = path.dirname(dir);
    if (next === dir) return "";
    dir = next;
  }
}

function globToRegExp(g) {
  let s = g.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*\*/g, ".*").replace(/\*/g, "[^/]*");
  return new RegExp(`(^|/)${s}`);
}

function collectTargets(targets, opts) {
  if (targets.length === 0) die("no file(s) or directory(ies) specified on input", 1, true);
  const excludes = opts.excludes.split(",").map((s) => s.trim()).filter(Boolean).map(globToRegExp);
  const out = [];
  const excluded = (p) => excludes.some((re) => re.test(p.replace(/\\/g, "/")));
  const walk = (p, rec) => {
    if (excluded(p)) return;
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      for (const ent of fs.readdirSync(p)) {
        if (ent === ".git") continue;
        const child = path.join(p, ent);
        if (fs.statSync(child).isDirectory()) {
          if (rec) walk(child, rec);
        } else if (child.endsWith(".go") && !child.endsWith("_test.go") && !excluded(child)) {
          out.push(path.resolve(child));
        }
      }
    } else {
      out.push(path.resolve(p));
    }
  };
  for (const t of targets) {
    if (t.endsWith("/...") || t === "./...") {
      walk(path.resolve(t.replace(/\/\.\.\.$/, "").replace(/^\.\.\.$/, ".")), true);
    } else {
      walk(path.resolve(t), opts.recursive);
    }
  }
  return [...new Set(out)];
}

function isGenerated(src) {
  const firstComment = src.match(/^\s*(\/\/[^\n]*|\/\*[\s\S]*?\*\/)/);
  return !!(firstComment && firstComment[1].startsWith("// Code generated"));
}

function parseImportLine(line) {
  let t = line.trim().replace(/;$/, "").trim();
  const m = t.match(/^(?:(\w+|\.|_)\s+)?("([^"]+)")(\s*\/\/.*)?$/);
  if (!m) return null;
  let comment = m[4] || "";
  if (comment) comment = " " + comment.trim().replace(/^\/\/\s*/, "// ");
  return { alias: m[1] || "", quote: m[2], path: m[3], comment };
}

function aliasForVersion(p) {
  const parts = p.split("/");
  if (!/^v[2-9]\d*$/.test(parts[parts.length - 1] || "")) return "";
  const prev = parts[parts.length - 2] || "";
  return prev.replace(/[^A-Za-z0-9_]/g, "");
}

function packageName(imp) {
  if (imp.alias && imp.alias !== "." && imp.alias !== "_") return imp.alias;
  const parts = imp.path.split("/");
  let base = parts[parts.length - 1];
  if (/^v[0-9]+$/.test(base) && parts.length > 1) base = parts[parts.length - 2];
  return base.replace(/[^A-Za-z0-9_]/g, "");
}

function removeUnused(imports, body) {
  return imports.filter((imp) => {
    if (imp.alias === "_" || imp.alias === ".") return true;
    const name = packageName(imp);
    return new RegExp(`\\b${name}\\b`).test(body);
  });
}

function classify(imp, opts, order) {
  if (order.includes("blanked") && imp.alias === "_") return "blanked";
  if (order.includes("dotted") && imp.alias === ".") return "dotted";
  const first = imp.path.split("/")[0];
  if (!first.includes(".")) return "std";
  const company = opts.companyPrefixes.split(",").map((s) => s.trim()).filter(Boolean);
  if (opts.projectName && (imp.path === opts.projectName || imp.path.startsWith(opts.projectName + "/"))) return "project";
  if (company.some((p) => imp.path === p || imp.path.startsWith(p + "/"))) return "company";
  return "general";
}

function renderImports(imports, opts) {
  if (imports.length === 0) return "";
  if (imports.length === 1) {
    const imp = imports[0];
    const prefix = imp.alias ? imp.alias + " " : "";
    return `import ${prefix}${imp.quote}${imp.comment}`;
  }
  const order = opts.importsOrder.split(",").map((s) => s.trim()).filter(Boolean);
  const groups = new Map();
  for (const imp of imports) {
    const g = classify(imp, opts, order);
    if (!groups.has(g)) groups.set(g, []);
    groups.get(g).push(imp);
  }
  const blocks = [];
  for (const name of order) {
    const arr = groups.get(name) || [];
    if (arr.length === 0) continue;
    arr.sort((a, b) => a.path.localeCompare(b.path) || a.alias.localeCompare(b.alias));
    if (opts.separateNamed) {
      const plain = arr.filter((x) => !x.alias || x.alias === "_" || x.alias === ".");
      const named = arr.filter((x) => x.alias && x.alias !== "_" && x.alias !== ".");
      if (plain.length) blocks.push(plain);
      if (named.length) blocks.push(named);
    } else {
      blocks.push(arr);
    }
  }
  for (const [name, arr] of groups.entries()) {
    if (!order.includes(name) && arr.length) blocks.push(arr);
  }
  const lines = ["import ("];
  blocks.forEach((arr, idx) => {
    if (idx > 0) lines.push("");
    for (const imp of arr) {
      const prefix = imp.alias ? imp.alias + " " : "";
      lines.push(`\t${prefix}${imp.quote}${imp.comment}`);
    }
  });
  lines.push(")");
  return lines.join("\n");
}

function basicFormat(src) {
  let s = src.replace(/\r\n/g, "\n");
  s = s.replace(/[ \t]+$/gm, "");
  s = s.replace(/^(package\s+\w+)\n+(import\b)/m, "$1\n\n$2");
  s = s.replace(/^(package\s+\w+)\n(import\b)/m, "$1\n\n$2");
  s = s.replace(/\)\n+(func\b)/g, ")\n\n$1");
  s = s.replace(/^(import\s+[^\n]+)\n(func\b)/m, "$1\n\n$2");
  s = s.replace(/}\n(func\b)/g, "}\n\n$1");
  s = s.replace(/\bfunc\s+([A-Za-z_][\w]*)\s*\(\s*\)\s*\{/g, "func $1() {");
  s = s.replace(/\{([^\n{};]+)\}/g, (_, inner) => `{ ${inner.trim()} }`);
  s = s.replace(/\bif\s+([^{\n]+)\{/g, "if $1 {");
  s = s.replace(/\bfor\s+([^{\n]*)\{/g, "for $1 {");
  s = s.replace(/;[ \t]*/g, "; ");
  s = s.replace(/\n{3,}/g, "\n\n");
  if (!s.endsWith("\n")) s += "\n";
  return s;
}

function rewrite(src, opts) {
  if (!opts.applyGenerated && isGenerated(src)) return src;
  let result = src;
  const importRe = /(^|\n)import\s*(?:"[^"]+"|\([\s\S]*?\))/m;
  const m = importRe.exec(result);
  if (!m) return basicFormat(result);
  const start = m.index + (m[1] ? 1 : 0);
  const end = m.index + m[0].length;
  const decl = result.slice(start, end);
  let imports = [];
  if (/^import\s*"/.test(decl)) {
    const imp = parseImportLine(decl.replace(/^import\s*/, ""));
    if (imp) imports.push(imp);
  } else {
    const inner = decl.replace(/^import\s*\(/, "").replace(/\)\s*$/, "");
    for (const rawLine of inner.split(/\n|;/)) {
      const imp = parseImportLine(rawLine);
      if (imp) imports.push(imp);
    }
  }
  if (opts.setAlias) {
    imports = imports.map((imp) => {
      if (!imp.alias) {
        const a = aliasForVersion(imp.path);
        if (a) return { ...imp, alias: a };
      }
      return imp;
    });
  }
  const bodyForUse = result.slice(end);
  if (opts.rmUnused) imports = removeUnused(imports, bodyForUse);
  const rendered = renderImports(imports, opts);
  result = result.slice(0, start) + rendered + result.slice(end);
  return basicFormat(result);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const files = collectTargets(opts.targets, opts);
  log(`Paths: [${files.join(" ")}]`);
  let anyChanged = false;
  for (const file of files) {
    log(`Processing ${file}`);
    let projectName = opts.projectName || findModule(file);
    if (!projectName) {
      die(`Could not determine project name for path ${file}: open go.mod: no such file or directory`);
    }
    const fileOpts = { ...opts, projectName };
    const before = fs.readFileSync(file, "utf8");
    const after = rewrite(before, fileOpts);
    const changed = before !== after;
    if (changed) anyChanged = true;
    if (opts.listDiff && changed) console.log(file);
    if (opts.output === "stdout") {
      process.stdout.write(after);
    } else if (opts.output === "write" || opts.output === "file") {
      if (changed && (!opts.listDiff || opts.output === "write")) fs.writeFileSync(file, after);
    }
  }
  if (opts.setExitStatus && anyChanged) process.exit(1);
}

main();
