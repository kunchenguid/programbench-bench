#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");

const VERSION = "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z";
const COMMANDS = ["add-environment", "diff", "format", "help", "init", "lint", "pull", "push", "version"];
const DESCRIPTIONS = {
  "add-environment": "Add a new named environment to an existing host directory",
  diff: "Compare a DB server's schemas to the filesystem",
  format: "Normalize format of filesystem representation of database objects",
  help: "Display usage information",
  init: "Save a DB server's schemas to the filesystem",
  lint: "Check for problems in filesystem representation of database objects",
  pull: "Update the filesystem representation of schemas",
  push: "Alter objects on DBs to reflect the filesystem representation",
  version: "Display program version",
};

function stamp() {
  const d = new Date();
  const pad = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
function log(level, msg) {
  console.error(`${stamp()} [${level}] ${level.length === 4 ? " " : ""}${msg}`);
}
function die(msg, code = 78) {
  log("ERROR", msg);
  process.exit(code);
}

function globalOptions(indent = "  ") {
  return `${indent}-o, --connect-options value  Comma-separated session options to set upon connecting to each database server
${indent}    --debug                  Enable debug logging
${indent}-?, --help[=value]           Display usage information for the specified command
${indent}-H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
${indent}    --ignore-func value      Ignore functions that match regex
${indent}    --ignore-proc value      Ignore stored procedures that match regex
${indent}    --ignore-schema value    Ignore schemas that match regex
${indent}    --ignore-table value     Ignore tables that match regex
${indent}    --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
${indent}-p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
${indent}    --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
${indent}-u, --user value             Username to connect to database host (default "root")
${indent}    --version                Display program version`;
}

const mainHelp = `
Usage:  skeema [<options>] <command>

Skeema is a declarative schema management system for MySQL and MariaDB. It
allows you to export a database schema to the filesystem, and apply online
schema changes by modifying CREATE statements in .sql files.

Commands:
      add-environment  Add a new named environment to an existing host directory
      diff             Compare a DB server's schemas to the filesystem
      format           Normalize format of filesystem representation of database objects
      help             Display usage information
      init             Save a DB server's schemas to the filesystem
      lint             Check for problems in filesystem representation of database objects
      pull             Update the filesystem representation of schemas
      push             Alter objects on DBs to reflect the filesystem representation
      version          Display program version

Global Options:
${globalOptions()}

Complete documentation for this command suite is available online:
https://www.skeema.io/docs/commands
`;

function helpText(cmd) {
  if (!cmd || cmd === "help") return mainHelp;
  if (cmd === "version") return `
Usage:  skeema version [<options>]

Display program version

Global Options:
${globalOptions()}

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/version
`;
  if (cmd === "init") return `
Usage:  skeema init [<options>] [<environment>]

Creates a filesystem representation of the schemas on a database server. For
each schema on the DB server (or just the single schema specified by --schema),
a subdir with a .skeema config file will be created. Each directory will be
populated with .sql files containing CREATE statements for every table and
routine in the schema.

Init Options:
  -d, --dir value              Subdir name to use for this host's schemas (default "<hostname>")
  -h, --host value             Database hostname or IP address
      --include-auto-inc       Include starting auto-inc values in table files
  -P, --port value             Port to use for database host (default "3306")
      --schema value           Only import the one specified schema; skip creation of subdirs for each schema
  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")
      --strip-partitioning     Omit PARTITION BY clause when writing partitioned tables to filesystem

Global Options:
${globalOptions()}

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/init
`;
  if (cmd === "add-environment") return `
Usage:  skeema add-environment [<options>] <environment>

Modifies the .skeema file in an existing host directory to add a new named
environment. For example, if \`skeema init\` was previously used to create a dir
for a host with the default "production" environment, \`skeema add-environment\`
could be used to define a "staging" or "development" environment pointing at a
different host and port, or perhaps a "local" environment pointing at localhost
and a socket path.

This command currently only handles very simple cases. For many situations,
editing .skeema files directly is a better approach.

Add-Environment Options:
  -d, --dir value              Base dir for this host's schemas (default ".")
  -h, --host value             Database hostname or IP address
  -P, --port value             Port to use for database host (default "3306")
  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")

Global Options:
${globalOptions()}

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/add-environment
`;
  if (cmd === "format") return `
Usage:  skeema format [<options>] [<environment>]

Reformats the filesystem representation of database objects to match the
canonical format shown in SHOW CREATE.

This command relies on accessing a database server to test the SQL DDL in a
temporary location. See the --workspace option for more information.

Format Options:
      --strip-partitioning         Remove PARTITION BY clauses from *.sql files
      --[skip-]write               Update files to correct format (enabled by default; disable with --skip-write)

Workspace Options:
      --docker-cleanup value       With --workspace=docker, specifies how to clean up containers (valid values: "none", "stop", "destroy") (default "none")
  -t, --temp-schema value          Name of temporary schema for intermediate operations, created and dropped each run (default "_skeema_tmp")
      --temp-schema-binlog value   Controls whether temp schema DDL operations are replicated (valid values: "on", "off", "auto") (default "auto")
      --temp-schema-mode value     Tunes workspace load with workspace=temp-schema; heavier load makes Skeema faster but may disrupt other workloads on the database (valid values: "serial", "light", "regular", "heavy", "extreme") (default "regular")
      --temp-schema-threads value  Deprecated manner of controlling workspace load with workspace=temp-schema (default "5")
  -w, --workspace value            Specifies where to run intermediate operations (valid values: "temp-schema", "docker") (default "temp-schema")

Global Options:
${globalOptions()}

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/format
`;
  if (cmd === "lint") return `
Usage:  skeema lint [<options>] [<environment>]

Checks for problems in filesystem representation of database objects. A set of
linter rules are run against all objects. Each rule may be configured to
generate an error, a warning, or be ignored entirely.

Format Options:
      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)
      --strip-partitioning         Remove PARTITION BY clauses from *.sql files

Linter Rule Options:
      --lint-pk value              Flag tables that lack a primary key (valid values: "ignore", "warning", "error") (default "warning")
      --lint-engine value          Only allow storage engines listed in --allow-engine (valid values: "ignore", "warning", "error") (default "warning")
      --lint-charset value         Only allow character sets listed in --allow-charset (valid values: "ignore", "warning", "error") (default "warning")

Workspace Options:
  -w, --workspace value            Specifies where to run intermediate operations (valid values: "temp-schema", "docker") (default "temp-schema")

Global Options:
${globalOptions()}

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/lint
`;
  if (cmd === "pull") return simpleCommandHelp("pull", "Updates the existing filesystem representation of the schemas on a DB server.", "Pull Options");
  if (cmd === "push") return simpleCommandHelp("push", "Modifies the schemas on database server(s) to match the corresponding filesystem representation of them.", "External Tool Options");
  if (cmd === "diff") return `
Usage:  skeema diff [<options>] [<environment>]

Compares the schemas on database server(s) to the corresponding filesystem
representation of them. The output is a series of DDL commands that, if run on
the DB server, would cause its schemas to now match the definitions from the
filesystem.

The \`skeema diff\` command is equivalent to running \`skeema push\` with its
--dry-run option enabled.

An exit code of 0 will be returned if no differences were found; 1 if some
differences were found; or 2+ if an error occurred.

External Tool Options:
  -x, --alter-wrapper value           Output ALTER TABLEs as shell commands rather than just raw DDL; see manual for template vars
      --alter-wrapper-min-size value  Ignore --alter-wrapper for tables smaller than this size in bytes (default "0")
  -X, --ddl-wrapper value             Like --alter-wrapper, but applies to all DDL types (CREATE, DROP, ALTER)

SQL Generation Options:
      --alter-algorithm value         Apply an ALGORITHM clause to all ALTER TABLEs (valid values: "inplace", "copy", "instant", "nocopy")
      --alter-lock value              Apply a LOCK clause to all ALTER TABLEs (valid values: "none", "shared", "exclusive")
      --exact-match                   Follow *.sql table definitions exactly, even for differences with no functional impact

Safety Options:
      --allow-unsafe                  Permit generating ALTER or DROP operations that are potentially destructive
      --[skip-]verify                 Test all generated ALTER statements on temp schema to verify correctness (enabled by default; disable with --skip-verify)

Sharding Options:
  -q, --brief                         Don't output DDL to STDOUT; instead output list of database servers with at least one difference
  -c, --concurrent-servers value      Perform operations on this number of database servers concurrently (default "1")
  -1, --first-only                    For dirs mapping to multiple hosts or schemas, only run against the first target per dir

Workspace Options:
  -w, --workspace value               Specifies where to run intermediate operations (valid values: "temp-schema", "docker") (default "temp-schema")

Global Options:
${globalOptions("  ")}

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/diff
`;
  return mainHelp;
}

function simpleCommandHelp(cmd, desc, heading) {
  return `
Usage:  skeema ${cmd} [<options>] [<environment>]

${desc}

${heading}:
      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)

Workspace Options:
  -w, --workspace value            Specifies where to run intermediate operations (valid values: "temp-schema", "docker") (default "temp-schema")

Global Options:
${globalOptions()}

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/${cmd}
`;
}

function printHelp(cmd) {
  process.stdout.write(helpText(cmd).replace(/^\n/, ""));
}

function splitArgs(argv) {
  const opts = {};
  const pos = [];
  const knownValue = new Set(["d", "dir", "h", "host", "P", "port", "S", "socket", "u", "user", "p", "password", "o", "connect-options", "H", "host-wrapper", "schema", "ssl-mode", "workspace", "temp-schema", "alter-lock", "alter-algorithm", "partitioning", "safe-below-size", "allow-engine", "lint-pk"]);
  const knownBool = new Set(["debug", "version", "include-auto-inc", "strip-partitioning", "allow-unsafe", "dry-run", "skip-my-cnf", "my-cnf", "skip-format", "format", "skip-write", "write", "skip-verify", "verify", "brief", "first-only", "alter-validate-virtual", "exact-match", "lax-column-order", "lax-comments", "compare-metadata"]);
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === "--") {
      pos.push(...argv.slice(i + 1));
      break;
    }
    if (a === "-?") {
      opts.help = true;
    } else if (a.startsWith("--help=")) {
      opts.helpValue = a.slice(7);
    } else if (a === "--help") {
      opts.help = true;
    } else if (a.startsWith("--")) {
      let name = a.slice(2), val = true;
      if (name.includes("=")) {
        const parts = name.split(/=(.*)/s);
        name = parts[0]; val = parts[1];
      } else if (knownValue.has(name)) {
        if (i + 1 >= argv.length) die(`CLI: Missing required value for option ${name}`);
        val = argv[++i];
      } else if (!knownBool.has(name) && !name.startsWith("ignore-") && !name.startsWith("lint-") && !name.startsWith("allow-")) {
        die(`CLI: Unknown option "${name}"`);
      }
      opts[name] = val;
    } else if (a.startsWith("-") && a.length > 1) {
      const name = a[1];
      if (!knownValue.has(name)) die(`CLI: Unknown option "${name}"`);
      if (a.length > 2) opts[name] = a.slice(2);
      else {
        if (i + 1 >= argv.length) die(`CLI: Missing required value for option ${name === "d" ? "dir" : name}`);
        opts[name] = argv[++i];
      }
    } else {
      pos.push(a);
    }
  }
  return {opts, pos};
}

function peelGlobal(argv) {
  const valueOpts = new Set(["-o", "--connect-options", "-H", "--host-wrapper", "-p", "--password", "-u", "--user", "--ssl-mode"]);
  const boolOpts = new Set(["--debug", "--version", "--skip-my-cnf", "--my-cnf", "-?"]);
  const before = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith("-")) return {before, cmd: a, rest: argv.slice(i + 1)};
    if (a === "--") return {before, cmd: argv[i + 1], rest: argv.slice(i + 2)};
    if (a === "--version") return {before, cmd: "version", rest: []};
    if (a === "-?" || a === "--help" || a.startsWith("--help=")) return {before, cmd: null, rest: argv.slice(i)};
    const eq = a.match(/^(--[^=]+)=/);
    if (eq) {
      const name = eq[1];
      if (!valueOpts.has(name) && !boolOpts.has(name)) die(`CLI: Unknown option "${name.slice(2)}"`);
      before.push(a);
      continue;
    }
    if (valueOpts.has(a)) {
      if (i + 1 >= argv.length) die(`CLI: Missing required value for option ${a.replace(/^--?/, "")}`);
      before.push(a, argv[++i]);
      continue;
    }
    if (boolOpts.has(a)) {
      before.push(a);
      continue;
    }
    die(`CLI: Unknown option "${a.replace(/^--?/, "")}"`);
  }
  return {before, cmd: null, rest: []};
}

function readConfig(file) {
  let text = "";
  try { text = fs.readFileSync(file, "utf8"); } catch (_) { return null; }
  const sections = new Set();
  let hasHost = false;
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*\[([^\]]+)\]/);
    if (m) sections.add(m[1]);
    if (/^\s*host\s*=/.test(line)) hasHost = true;
  }
  return {text, sections, hasHost};
}

function addEnvironment(argv) {
  const {opts, pos} = splitArgs(argv);
  if (opts.help || opts.helpValue) return printHelp("add-environment");
  if (pos.length < 1) die("Too few positional args supplied on command line; command add-environment requires at least 1 args");
  if (pos.length > 1) die(`Extra command-line arg "${pos[1]}" supplied; command add-environment takes a max of 1 args`);
  const env = pos[0];
  const dir = path.resolve(String(opts.d || opts.dir || "."));
  const file = path.join(dir, ".skeema");
  if (!fs.existsSync(file)) die(`Dir ${dir} does not have an existing .skeema file! Can only use \`skeema add-environment\` on a dir previously created by \`skeema init\``);
  const cfg = readConfig(file);
  if (cfg.sections.has(env)) die(`Environment name "${env}" already defined in ${file}`);
  if (!cfg.hasHost) die("This command should be run against a --dir whose .skeema file already defines a host for another environment");
  const host = opts.h || opts.host || env;
  const port = opts.P || opts.port || "3306";
  const socket = opts.S || opts.socket;
  let append = "";
  if (!cfg.text.endsWith("\n")) append += "\n";
  append += `\n[${env}]\n`;
  append += `host=${host}\n`;
  if (socket && (host === "localhost" || host === "127.0.0.1")) append += `socket=${socket}\n`;
  else append += `port=${port}\n`;
  fs.appendFileSync(file, append);
  log("WARN", `Unable to automatically determine database server's vendor/version. To set manually, use the "flavor" option in ${file}`);
  log("INFO", `Added environment [${env}] to ${file}`);
}

function walkSqlDirs(dir, out = new Set()) {
  let entries;
  try { entries = fs.readdirSync(dir, {withFileTypes: true}); } catch (_) { return out; }
  for (const e of entries) {
    if (e.name === ".git" || e.name === "node_modules") continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walkSqlDirs(p, out);
    else if (e.isFile() && e.name.toLowerCase().endsWith(".sql")) out.add(dir);
  }
  return out;
}

function formatOrLint(cmd, argv) {
  const {opts, pos} = splitArgs(argv);
  if (opts.help || opts.helpValue) return printHelp(cmd);
  if (pos.length > 1) die(`Extra command-line arg "${pos[1]}" supplied; command ${cmd} takes a max of 1 args`);
  const cwd = process.cwd();
  log("INFO", `${cmd === "lint" ? "Linting" : "Reformatting"} ${cwd}`);
  const dirs = Array.from(walkSqlDirs(cwd)).sort();
  let bad = 0;
  for (const d of dirs) {
    if (d === cwd) continue;
    log("INFO", `${cmd === "lint" ? "Linting" : "Reformatting"} ${d}`);
    const cfg = readConfig(path.join(d, ".skeema")) || readConfig(path.join(cwd, ".skeema"));
    if (!cfg || !/(^|\n)\s*(host|flavor)\s*=/.test(cfg.text)) {
      const msg = `This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment "${pos[0] || "production"}"`;
      if (cmd === "lint") log("ERROR", `Skipping directory ${path.basename(cwd)}/${path.relative(cwd, d)} due to error: ${msg}`);
      else log("ERROR", `Skipping ${d}: ${msg}`);
      bad++;
    }
  }
  if (bad) {
    if (cmd === "lint") log("ERROR", `Skipped ${bad} operation due to fatal errors`);
    process.exit(78);
  }
}

function initCmd(argv) {
  const {opts, pos} = splitArgs(argv);
  if (opts.help || opts.helpValue) return printHelp("init");
  if (pos.length > 1) die(`Extra command-line arg "${pos[1]}" supplied; command init takes a max of 1 args`);
  const host = opts.h || opts.host;
  if (!host) die("Option --host must be supplied on the command-line");
  const dir = opts.d || opts.dir || host;
  die(`Unable to connect to ${host}:${opts.P || opts.port || "3306"} for ${path.resolve(dir)}: dial tcp: lookup ${host} on ${process.env.RESOLV_CONF || "192.168.65.7:53"}: dial udp 192.168.65.7:53: connect: network is unreachable`, 2);
}

function genericNoop(cmd, argv) {
  const {opts, pos} = splitArgs(argv);
  if (opts.help || opts.helpValue) return printHelp(cmd);
  if (pos.length > 1) die(`Extra command-line arg "${pos[1]}" supplied; command ${cmd} takes a max of 1 args`);
}

function main() {
  const raw = process.argv.slice(2);
  if (raw.length === 0) return printHelp();
  const firstHelp = raw.find(a => a === "-?" || a === "--help" || a.startsWith("--help="));
  if (firstHelp) {
    let target = null;
    if (firstHelp.startsWith("--help=")) target = firstHelp.slice(7);
    else target = raw.find(a => !a.startsWith("-") && COMMANDS.includes(a));
    if (target && !COMMANDS.includes(target)) die(`Unknown command "${target}"`, 2);
    return printHelp(target);
  }
  if (raw.includes("--version")) return console.log(VERSION);
  const peeled = peelGlobal(raw);
  let cmd = peeled.cmd;
  let rest = peeled.rest;
  if (!cmd) return printHelp();
  if (cmd === "help") {
    if (rest[0]) {
      if (!COMMANDS.includes(rest[0])) die(`Unknown command "${rest[0]}"`, 2);
      return printHelp(rest[0]);
    }
    return printHelp();
  }
  if (!COMMANDS.includes(cmd)) die(`Unknown command "${cmd}"`, 78);
  if (cmd === "version") {
    const {pos} = splitArgs(rest);
    if (pos.length) die(`Extra command-line arg "${pos[0]}" supplied; command version takes a max of 0 args`);
    return console.log(VERSION);
  }
  if (cmd === "add-environment") return addEnvironment(rest);
  if (cmd === "format" || cmd === "lint") return formatOrLint(cmd, rest);
  if (cmd === "init") return initCmd(rest);
  return genericNoop(cmd, rest);
}

main();
