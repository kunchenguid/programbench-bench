#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const VERSION = "hostctl version dev";
const BANNER = [
  "##################################################################",
  "# Content under this line is handled by hostctl. DO NOT EDIT.",
  "##################################################################",
];

function die(msg, code = 1) {
  console.error(`[✖] error: ${msg}`);
  process.exit(code);
}

function rootHelp() {
  return `
hostctl is a CLI tool to manage your hosts file with ease.
You can have multiple profiles, enable/disable exactly what
you need each time with a simple interface.

Usage:
  hostctl [command]

Available Commands:
  add         Add content to a profile in your hosts file.
  backup      Creates a backup copy of your hosts file
  disable     Disable a profile from your hosts file.
  enable      Enable a profile on your hosts file.
  help        Help about any command
  list        Shows a detailed list of profiles on your hosts file.
  remove      Remove a profile from your hosts file.
  replace     Replace content to a profile in your hosts file.
  restore     Restore hosts file content from a backup file.
  status      Shows a list of profile names and statuses on your hosts file.
  sync        Sync some system IPs with a profile.
  toggle      Change status of a profile on your hosts file.

Flags:
  -c, --column strings     Column names to show on lists. comma separated
  -h, --help               help for hostctl
      --host-file string   Hosts file path (default "/etc/hosts")
      --no-color           force colorless output
  -o, --out string         Output type (table|raw|markdown|json) (default "table")
  -q, --quiet              Run command without output
      --raw                Output without borders (same as -o raw)
  -v, --version            version for hostctl

Use "hostctl [command] --help" for more information about a command.
`.trimStart();
}

const HELPS = {
  add: `
Reads from a file and set content to a profile in your hosts file.
If the profile already exists it will be added to it.

Usage:
  hostctl add [profiles] [flags]
  hostctl add [command]

Available Commands:
  domains     Add content in your hosts file.

Flags:
  -f, --from string     file to read
  -h, --help            help for add
  -w, --wait duration   Enables a profile for a specific amount of time. (example: 5m, 1h) (default -1ns)
`,
  replace: `
Reads from a file and set content to a profile in your hosts file.
If the profile already exists it will be overwritten.

Usage:
  hostctl replace [profile] [flags]

Flags:
  -f, --from string   file to read
  -h, --help          help for replace
`,
  remove: `
Completely remove a profile content from your hosts file.
It cannot be undone unless you have a backup and restore it.

If you want to remove a profile but would like to use it later,
use 'hosts disable' instead.

Usage:
  hostctl remove [profiles] [flags]
  hostctl remove [command]

Aliases:
  remove, rm [profiles] [flags]

Available Commands:
  domains     Remove domains from your hosts file.

Flags:
      --all    Remove all profiles
  -h, --help   help for remove
`,
  enable: `
Enables an existing profile.
It will be listed as "on" while it is enabled.

Usage:
  hostctl enable [profiles] [flags]

Flags:
      --all             Enable all profiles
  -h, --help            help for enable
      --only            Disable all other profiles
  -w, --wait duration   Enables a profile for a specific amount of time (default -1ns)
`,
  disable: `
Disable a profile from your hosts file without removing it.
It will be listed as "off" while it is disabled.

Usage:
  hostctl disable [profiles] [flags]

Flags:
      --all             Disable all profiles
  -h, --help            help for disable
      --only            Enable all other profiles
  -w, --wait duration   Enables a profile for a specific amount of time (default -1ns)
`,
  toggle: `
Alternates between on/off status of an existing profile.

Usage:
  hostctl toggle [flags]

Flags:
  -h, --help            help for toggle
  -w, --wait duration   Toggles a profile for a specific amount of time (default -1ns)
`,
  status: `
Shows a list of unique profile names on your hosts file with its status.

The "default" profile is always on and will be skipped.

Usage:
  hostctl status [profiles] [flags]

Flags:
  -h, --help   help for status
`,
  list: `
Shows a detailed list of profiles on your hosts file with name, ip and host name.
You can filter by profile name.

The "default" profile is all the content that is not handled by hostctl tool.

Usage:
  hostctl list [profiles] [flags]
  hostctl list [command]

Available Commands:
  disabled    Shows list of disabled profiles on your hosts file.
  enabled     Shows list of enabled profiles on your hosts file.

Flags:
  -h, --help   help for list
`,
  backup: `
Creates a backup copy of your hosts file with the date in .YYYYMMDD
as extension.

Usage:
  hostctl backup [flags]

Flags:
  -h, --help          help for backup
      --path string   A path to save the backup (default "/workspace")
`,
  restore: `
Reads from a file and replace the content of your hosts file.

WARNING: the complete hosts file will be overwritten with the backup data.

Usage:
  hostctl restore [flags]

Flags:
      --from string   The file to restore from
  -h, --help          help for restore
`,
  sync: `
Reads IPs and names from some local system and sync it with a profile in your hosts file.

Usage:
  hostctl sync [command]

Available Commands:
  docker         Sync your Docker containers IPs with a profile.
  docker-compose Sync your docker-compose containers IPs with a profile.

Flags:
  -h, --help            help for sync
  -w, --wait duration   Enables a profile for a specific amount of time (default -1ns)
`,
};

function globalFlags() {
  return `
Global Flags:
  -c, --column strings     Column names to show on lists. comma separated
      --host-file string   Hosts file path (default "/etc/hosts")
      --no-color           force colorless output
  -o, --out string         Output type (table|raw|markdown|json) (default "table")
  -q, --quiet              Run command without output
      --raw                Output without borders (same as -o raw)
`;
}

function printHelp(cmd) {
  if (!cmd) return console.log(rootHelp());
  if (cmd === "add domains" || cmd === "add domain") {
    return console.log(`
Set content in your hosts file.
If the profile already exists it will be added to it.

Usage:
  hostctl add domains [profile] [domains] [flags]

Aliases:
  domains, domain [profile] [domains] [flags]

Flags:
  -h, --help        help for domains
      --ip string   domains ip (default "127.0.0.1")
${globalFlags()}  -w, --wait duration      Enables a profile for a specific amount of time. (example: 5m, 1h) (default -1ns)
`.trimStart());
  }
  if (cmd === "remove domains" || cmd === "remove domain") {
    return console.log(`
Completely remove domains from your hosts file.
It cannot be undone unless you have a backup and restore it.

Usage:
  hostctl remove domains [profile] [domains] [flags]

Aliases:
  domains, domain [profile] [domains] [flags]

Flags:
  -h, --help   help for domains
${globalFlags()}`.trimStart());
  }
  if (cmd === "list enabled" || cmd === "list on") {
    return console.log(`
Shows a detailed list of enabled profiles on your hosts file with name, ip and host name.

Usage:
  hostctl list enabled [flags]

Aliases:
  enabled, on

Flags:
  -h, --help   help for enabled
${globalFlags()}`.trimStart());
  }
  if (cmd === "list disabled" || cmd === "list off") {
    return console.log(`
Shows a detailed list of disabled profiles on your hosts file with name, ip and host name.

Usage:
  hostctl list disabled [flags]

Aliases:
  disabled, off

Flags:
  -h, --help   help for disabled
${globalFlags()}`.trimStart());
  }
  if (cmd === "sync docker") {
    return console.log(`
Reads from Docker the list of containers and add names and IPs to a profile in your hosts file.

Usage:
  hostctl sync docker [profile] [flags]

Flags:
  -d, --domain string    domain where your docker containers will be added (default "loc")
  -h, --help             help for docker
      --network string   Filter containers from a specific network
${globalFlags()}  -w, --wait duration      Enables a profile for a specific amount of time (default -1ns)
`.trimStart());
  }
  if (cmd === "sync docker-compose") {
    return console.log(`
Reads from a docker-compose.yml file  the list of containers and add names and IPs to a profile in your hosts file.

Usage:
  hostctl sync docker-compose [profile] [flags]

Flags:
      --compose-file string   path to docker-compose.yml
  -d, --domain string         domain where your docker containers will be added (default "loc")
  -h, --help                  help for docker-compose
      --network string        Filter containers from a specific network
      --prefix                keep project name prefix from domain name
      --project-name string   docker compose project name
${globalFlags()}  -w, --wait duration      Enables a profile for a specific amount of time (default -1ns)
`.trimStart());
  }
  const base = HELPS[cmd];
  if (base) console.log((base + globalFlags()).trimStart());
  else console.log(rootHelp());
}

function parseArgs(argv) {
  const opts = { hostFile: "/etc/hosts", out: "table", columns: null, quiet: false };
  const args = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--host-file") opts.hostFile = argv[++i];
    else if (a.startsWith("--host-file=")) opts.hostFile = a.slice(12);
    else if (a === "-o" || a === "--out") opts.out = argv[++i];
    else if (a.startsWith("--out=")) opts.out = a.slice(6);
    else if (a === "--raw") opts.out = "raw";
    else if (a === "-c" || a === "--column") opts.columns = argv[++i].split(",");
    else if (a.startsWith("--column=")) opts.columns = a.slice(9).split(",");
    else if (a === "-q" || a === "--quiet") opts.quiet = true;
    else if (a === "--no-color") {}
    else args.push(a);
  }
  return { opts, args };
}

function readHosts(file) {
  let text = "";
  try { text = fs.readFileSync(file, "utf8"); } catch { text = ""; }
  const lines = text.replace(/\r\n/g, "\n").split("\n");
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  const marker = BANNER[1];
  let idx = lines.findIndex(l => l.trim() === marker);
  let unmanaged = idx >= 1 ? lines.slice(0, idx - 1) : lines.slice();
  while (unmanaged.length && unmanaged[unmanaged.length - 1] === "") unmanaged.pop();
  const managedLines = idx >= 1 ? lines.slice(idx + 2) : [];
  const profiles = [];
  let cur = null;
  for (const line of managedLines) {
    let m = line.match(/^# profile\.(on|off)\s+(.+)$/);
    if (m) {
      cur = { name: m[2].trim(), status: m[1], entries: [] };
      profiles.push(cur);
      continue;
    }
    if (!cur) continue;
    if (line.trim() === "# end") { cur = null; continue; }
    let raw = line;
    if (cur.status === "off") raw = raw.replace(/^#\s?/, "");
    const ent = parseHostLine(raw);
    if (ent) cur.entries.push(...ent);
  }
  return { unmanaged, profiles };
}

function parseHostLine(line) {
  const beforeComment = line.split(/\s+#/)[0].trim();
  if (!beforeComment || beforeComment.startsWith("#")) return null;
  const parts = beforeComment.split(/\s+/).filter(Boolean);
  if (parts.length < 2) return null;
  const ip = parts[0];
  return parts.slice(1).map(host => ({ ip, host }));
}

function readEntriesFromFile(file) {
  if (!file) die("missing file to read");
  return fs.readFileSync(file, "utf8").split(/\r?\n/).flatMap(line => parseHostLine(line) || []);
}

function writeHosts(file, state) {
  const out = [];
  out.push(...state.unmanaged);
  out.push("", ...BANNER, "");
  state.profiles.forEach((p, i) => {
    if (i > 0) out.push("");
    out.push(`# profile.${p.status} ${p.name}`);
    for (const e of p.entries) out.push(`${p.status === "off" ? "# " : ""}${e.ip} ${e.host}`);
    out.push("# end");
  });
  fs.writeFileSync(file, out.join("\n") + "\n");
}

function profileRows(state, includeDefault = true) {
  const rows = [];
  if (includeDefault) {
    for (const line of state.unmanaged) {
      const ents = parseHostLine(line) || [];
      for (const e of ents) rows.push({ Profile: "default", Status: "on", IP: e.ip, Host: e.host });
    }
  }
  for (const p of state.profiles) {
    for (const e of p.entries) rows.push({ Profile: p.name, Status: p.status, IP: e.ip, Host: e.host });
  }
  return rows;
}

function statusRows(state, names) {
  return state.profiles
    .filter(p => !names.length || names.includes(p.name))
    .map(p => ({ Profile: p.name, Status: p.status }));
}

function selectColumns(rows, cols) {
  const map = { profile: "Profile", status: "Status", ip: "IP", domain: "Host", host: "Host" };
  const selected = (cols && cols.length) ? cols.map(c => map[c.toLowerCase()] || c) : null;
  return { rows, keys: selected || (rows[0] && "IP" in rows[0] ? ["Profile", "Status", "IP", "Host"] : ["Profile", "Status"]) };
}

function headerFor(k) { return k === "Host" ? "DOMAIN" : k.toUpperCase(); }
function valueFor(r, k) { return String(r[k] ?? ""); }
function center(s, width) {
  const left = Math.floor((width - s.length) / 2);
  const right = width - s.length - left;
  return " ".repeat(left) + s + " ".repeat(right);
}

function printInfo(opts) {
  if (!opts.quiet && opts.out !== "json") console.log(`[ℹ] Using hosts file: ${opts.hostFile}\n`);
}

function printRows(rows, opts, defaultKeys) {
  const keys = (opts.columns ? selectColumns(rows, opts.columns).keys : defaultKeys);
  if (opts.out === "json") {
    console.log(JSON.stringify(rows.map(r => {
      const o = {};
      for (const k of keys) o[k] = r[k] ?? "";
      return o;
    })));
    return;
  }
  if (rows.length === 0) return;
  const headers = keys.map(headerFor);
  const widths = headers.map((h, i) => Math.max(h.length, ...rows.map(r => valueFor(r, keys[i]).length)));
  if (opts.out === "raw") {
    console.log(headers.map((h, i) => h.padEnd(widths[i])).join("\t"));
    for (const r of rows) console.log(keys.map((k, i) => valueFor(r, k).padEnd(widths[i])).join("\t"));
    return;
  }
  if (opts.out === "markdown") {
    const rowLine = vals => `| ${vals.map((v, i) => String(v).padEnd(widths[i])).join(" | ")} |`;
    console.log(`| ${headers.map((h, i) => center(h, widths[i])).join(" | ")} |`);
    console.log(rowLine(widths.map(w => "-".repeat(w))));
    let last = null;
    for (const r of rows) {
      if (last !== null && r.Profile !== last) console.log(rowLine(widths.map(w => "-".repeat(w))));
      console.log(rowLine(keys.map(k => valueFor(r, k))));
      last = r.Profile;
    }
    return;
  }
  const border = "+" + widths.map(w => "-".repeat(w + 2)).join("+") + "+";
  const rowLine = vals => `| ${vals.map((v, i) => String(v).padEnd(widths[i])).join(" | ")} |`;
  console.log(border);
  console.log(`| ${headers.map((h, i) => center(h, widths[i])).join(" | ")} |`);
  console.log(border);
  let last = null;
  for (const r of rows) {
    if (last !== null && r.Profile !== last) console.log(border);
    console.log(rowLine(keys.map(k => valueFor(r, k))));
    last = r.Profile;
  }
  console.log(border);
}

function findProfile(state, name) {
  return state.profiles.find(p => p.name === name);
}

function parseLocalFlags(args) {
  const flags = {};
  const rest = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-f" || a === "--from") flags.from = args[++i];
    else if (a.startsWith("--from=")) flags.from = a.slice(7);
    else if (a === "--ip") flags.ip = args[++i];
    else if (a.startsWith("--ip=")) flags.ip = a.slice(5);
    else if (a === "--all") flags.all = true;
    else if (a === "--only") flags.only = true;
    else if (a === "--path") flags.path = args[++i];
    else if (a.startsWith("--path=")) flags.path = a.slice(7);
    else if (a === "-w" || a === "--wait" || a === "-d" || a === "--domain" || a === "--network" || a === "--compose-file" || a === "--project-name") i++;
    else if (a === "--prefix") flags.prefix = true;
    else rest.push(a);
  }
  return { flags, rest };
}

function ensureProfiles(state, names) {
  for (const n of names) if (!findProfile(state, n)) die("unknown profile name");
}

function cmdAdd(state, opts, args) {
  if (args[0] === "domains" || args[0] === "domain") {
    const { flags, rest } = parseLocalFlags(args.slice(1));
    const name = rest.shift();
    if (!name) die("missing profile name");
    if (!rest.length) die("missing domains");
    const p = findProfile(state, name) || (state.profiles.push({ name, status: "on", entries: [] }), state.profiles[state.profiles.length - 1]);
    const ip = flags.ip || "127.0.0.1";
    p.entries.push(...rest.map(host => ({ ip, host })));
    writeHosts(opts.hostFile, state);
    printInfo(opts);
    if (opts.out !== "json") console.log(`[✔] Domains '${rest.join(", ")}' added.\n`);
    printRows(p.entries.map(e => ({ Profile: name, Status: p.status, IP: e.ip, Host: e.host })), opts, ["Profile", "Status", "IP", "Host"]);
    return;
  }
  const { flags, rest } = parseLocalFlags(args);
  const names = rest;
  if (!names.length) die("missing profile name");
  const entries = readEntriesFromFile(flags.from);
  for (const name of names) {
    const p = findProfile(state, name) || (state.profiles.push({ name, status: "on", entries: [] }), state.profiles[state.profiles.length - 1]);
    p.entries.push(...entries);
  }
  writeHosts(opts.hostFile, state);
  printInfo(opts);
  const rows = names.flatMap(n => (findProfile(state, n) || { entries: [] }).entries.map(e => ({ Profile: n, Status: findProfile(state, n).status, IP: e.ip, Host: e.host })));
  printRows(rows, opts, ["Profile", "Status", "IP", "Host"]);
}

function cmdReplace(state, opts, args) {
  const { flags, rest } = parseLocalFlags(args);
  const name = rest[0];
  if (!name) die("missing profile name");
  const entries = readEntriesFromFile(flags.from);
  let p = findProfile(state, name);
  if (!p) { p = { name, status: "on", entries: [] }; state.profiles.push(p); }
  p.entries = entries;
  writeHosts(opts.hostFile, state);
  printInfo(opts);
  printRows(p.entries.map(e => ({ Profile: name, Status: p.status, IP: e.ip, Host: e.host })), opts, ["Profile", "Status", "IP", "Host"]);
}

function cmdRemove(state, opts, args) {
  if (args[0] === "domains" || args[0] === "domain") {
    const { rest } = parseLocalFlags(args.slice(1));
    const name = rest.shift();
    if (!name) die("missing profile name");
    const p = findProfile(state, name);
    if (!p) die("unknown profile name");
    p.entries = p.entries.filter(e => !rest.includes(e.host));
    if (p.entries.length === 0) state.profiles = state.profiles.filter(x => x !== p);
    writeHosts(opts.hostFile, state);
    printInfo(opts);
    if (opts.out !== "json") console.log(`[✔] Profile '${name}' removed.\n`);
    return;
  }
  const { flags, rest } = parseLocalFlags(args);
  const names = flags.all ? state.profiles.map(p => p.name) : rest;
  if (!names.length) die("missing profile name");
  ensureProfiles(state, names);
  state.profiles = state.profiles.filter(p => !names.includes(p.name));
  writeHosts(opts.hostFile, state);
  printInfo(opts);
  if (opts.out !== "json") console.log(`[✔] Profile(s) '${names.join(", ")}' removed.\n`);
}

function cmdSetStatus(state, opts, args, mode) {
  const { flags, rest } = parseLocalFlags(args);
  const names = flags.all ? state.profiles.map(p => p.name) : rest;
  if (!names.length) die("missing profile name");
  ensureProfiles(state, names);
  if (flags.only) {
    for (const p of state.profiles) p.status = names.includes(p.name) ? (mode === "enable" ? "on" : "off") : (mode === "enable" ? "off" : "on");
  } else {
    for (const p of state.profiles) if (names.includes(p.name)) p.status = mode === "toggle" ? (p.status === "on" ? "off" : "on") : (mode === "enable" ? "on" : "off");
  }
  writeHosts(opts.hostFile, state);
  printInfo(opts);
  const rows = profileRows(state, false).filter(r => names.includes(r.Profile) || flags.all);
  printRows(rows, opts, ["Profile", "Status", "IP", "Host"]);
}

function main() {
  const parsed = parseArgs(process.argv.slice(2));
  const { opts, args } = parsed;
  if (!args.length || args.includes("--help") || args.includes("-h")) {
    const topic = args[0] === "help" ? args.slice(1).join(" ") : args.filter(a => a !== "--help" && a !== "-h").join(" ");
    printHelp(topic.trim());
    return;
  }
  if (args[0] === "--version" || args[0] === "-v") return console.log(VERSION);
  if (args[0] === "help") return printHelp(args.slice(1).join(" "));
  const cmd = args.shift();
  if (cmd === "sync") return printHelp(args.join(" ") ? `sync ${args.join(" ")}` : "sync");
  const state = readHosts(opts.hostFile);
  if (cmd === "add") return cmdAdd(state, opts, args);
  if (cmd === "replace") return cmdReplace(state, opts, args);
  if (cmd === "remove" || cmd === "rm") return cmdRemove(state, opts, args);
  if (cmd === "enable") return cmdSetStatus(state, opts, args, "enable");
  if (cmd === "disable") return cmdSetStatus(state, opts, args, "disable");
  if (cmd === "toggle") return cmdSetStatus(state, opts, args, "toggle");
  if (cmd === "status") {
    const { rest } = parseLocalFlags(args);
    printInfo(opts);
    return printRows(statusRows(state, rest), opts, ["Profile", "Status"]);
  }
  if (cmd === "list") {
    const sub = args[0];
    if (sub === "enabled" || sub === "on" || sub === "disabled" || sub === "off") args.shift();
    const { rest } = parseLocalFlags(args);
    printInfo(opts);
    let rows = profileRows(state, true);
    if (sub === "enabled" || sub === "on") rows = rows.filter(r => r.Profile === "default" || r.Status === "on");
    if (sub === "disabled" || sub === "off") rows = rows.filter(r => r.Profile === "default" || r.Status === "off");
    if (rest.length) rows = rows.filter(r => rest.includes(r.Profile));
    return printRows(rows, opts, ["Profile", "Status", "IP", "Host"]);
  }
  if (cmd === "backup") {
    const { flags } = parseLocalFlags(args);
    const dir = flags.path || "/workspace";
    const d = new Date();
    const stamp = `${d.getUTCFullYear()}${String(d.getUTCMonth() + 1).padStart(2, "0")}${String(d.getUTCDate()).padStart(2, "0")}`;
    const dest = path.join(dir, `${path.basename(opts.hostFile)}.${stamp}`);
    fs.copyFileSync(opts.hostFile, dest);
    printInfo(opts);
    if (opts.out !== "json") console.log(`[✔] Backup '${dest}' created.`);
    return;
  }
  if (cmd === "restore") {
    const { flags } = parseLocalFlags(args);
    if (!flags.from) die("missing file to restore");
    fs.copyFileSync(flags.from, opts.hostFile);
    printInfo(opts);
    if (opts.out !== "json") console.log(`[✔] File '${flags.from}' restored.`);
    return;
  }
  die(`unknown command "${cmd}"`);
}

main();
