#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const HELP = `executable

  Usage:
    executable [git-arg]

  Positional Variables: 
    git-arg   Panel to focus upon opening lazygit. Accepted values (based on git terminology): status, branch, log, stash. Ignored if --filter arg is passed.
  Flags: 
    -h --help               Displays help with available flag, subcommand, and positional value parameters.
    -p --path               Path of git repo. (equivalent to --work-tree=<path> --git-dir=<path>/.git/)
    -f --filter             Path to filter on in \`git log -- <path>\`. When in filter mode, the commits, reflog, and stash are filtered based on the given path, and some operations are restricted
    -v --version            Print the current version
    -d --debug              Run in debug mode with logging (see --logs flag below). Use the LOG_LEVEL env var to set the log level (debug/info/warn/error)
    -l --logs               Tail lazygit logs (intended to be used when \`lazygit --debug\` is called in a separate terminal tab)
       --profile            Start the profiler and serve it on http port 6060. See CONTRIBUTING.md for more info.
    -c --config             Print the default config
    -cd --print-config-dir   Print the config directory
    -ucd --use-config-dir     override default config directory with provided directory
    -w --work-tree          equivalent of the --work-tree git argument
    -g --git-dir            equivalent of the --git-dir git argument
    -ucf --use-config-file    Comma separated list to custom config file(s)
    -sm --screen-mode        The initial screen-mode, which determines the size of the focused panel. Valid options: 'normal' (default), 'half', 'full'
`;

const VERSION = 'commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1';
const VALUE_FLAGS = new Set(['-p', '--path', '-f', '--filter', '-ucd', '--use-config-dir', '-w', '--work-tree', '-g', '--git-dir', '-ucf', '--use-config-file', '-sm', '--screen-mode']);
const BOOL_FLAGS = new Set(['-h', '--help', '-v', '--version', '-d', '--debug', '-l', '--logs', '--profile', '-c', '--config', '-cd', '--print-config-dir']);
const VALID_POSITIONAL = new Set(['status', 'branch', 'log', 'stash']);

function write(s) {
  process.stdout.write(s.endsWith('\n') ? s : `${s}\n`);
}

function failParse(message) {
  process.stdout.write(`${HELP}\n${message}\n`);
  process.exit(2);
}

function flagName(flag) {
  return flag.replace(/^-+/, '');
}

function configDir(opts) {
  if (opts.useConfigDir) return opts.useConfigDir;
  if (process.env.XDG_CONFIG_HOME) return path.join(process.env.XDG_CONFIG_HOME, 'lazygit');
  return path.join(process.env.HOME || '', '.config', 'lazygit');
}

function stateDir() {
  if (process.env.XDG_STATE_HOME) return path.join(process.env.XDG_STATE_HOME, 'lazygit');
  return path.join(process.env.HOME || '', '.local', 'state', 'lazygit');
}

function timestamp() {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function parse(argv) {
  const opts = { positionals: [], values: {} };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg.startsWith('-')) {
      if (VALUE_FLAGS.has(arg)) {
        if (i + 1 >= argv.length) failParse(`Expected a following arg for flag ${flagName(arg)}, but it did not exist.`);
        opts.values[arg] = argv[++i];
        if (arg === '-ucd' || arg === '--use-config-dir') opts.useConfigDir = opts.values[arg];
        if (arg === '-p' || arg === '--path') opts.repoPath = opts.values[arg];
        if (arg === '-w' || arg === '--work-tree') opts.workTree = opts.values[arg];
        if (arg === '-g' || arg === '--git-dir') opts.gitDir = opts.values[arg];
        if (arg === '-f' || arg === '--filter') opts.filter = opts.values[arg];
      } else if (BOOL_FLAGS.has(arg)) {
        opts.values[arg] = true;
      } else {
        if (i + 1 >= argv.length) failParse(`Expected a following arg for flag ${flagName(arg)}, but it did not exist.`);
        failParse(`Unknown arguments supplied:  ${flagName(arg)} ${argv[i + 1]}`);
      }
    } else {
      opts.positionals.push(arg);
    }
  }
  if (opts.positionals.length > 1) failParse(`Unexpected argument: ${opts.positionals[1]}`);
  return opts;
}

function hasFlag(opts, ...flags) {
  return flags.some(f => opts.values[f]);
}

function isGitRepo(dir, opts) {
  const args = [];
  if (opts.workTree) args.push(`--work-tree=${opts.workTree}`);
  if (opts.gitDir) args.push(`--git-dir=${opts.gitDir}`);
  args.push('rev-parse', '--is-inside-work-tree');
  const res = spawnSync('git', args, { cwd: dir, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
  return res.status === 0 && res.stdout.trim() === 'true';
}

function runApp(opts) {
  const target = opts.repoPath || opts.workTree || process.cwd();
  if (opts.repoPath && !isGitRepo(target, opts)) {
    console.log(`${timestamp()} ${opts.repoPath} is not a valid git repository.`);
    process.exit(1);
  }
  if (!isGitRepo(target, opts)) {
    process.stdout.write('Not in a git repository. Create a new git repository? (y/N): ');
    console.log('Must open lazygit in a git repository. No valid recent repositories. Exiting.');
    process.exit(1);
  }
  if (!process.env.TERM) {
    console.log(`${timestamp()} An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues\n`);
    console.log('*fmt.wrapError terminal entry not found: term not set');
    process.exit(1);
  }
  console.log('lazygit requires an interactive terminal.');
  process.exit(1);
}

function main() {
  const opts = parse(process.argv.slice(2));
  if (hasFlag(opts, '-h', '--help')) return write(HELP);
  if (hasFlag(opts, '-v', '--version')) return write(VERSION);
  if (hasFlag(opts, '-c', '--config')) {
    process.stdout.write(fs.readFileSync(path.join(__dirname, '..', 'default_config.yml'), 'utf8'));
    return;
  }
  if (hasFlag(opts, '-cd', '--print-config-dir')) return write(configDir(opts));
  if (hasFlag(opts, '-l', '--logs')) {
    const logPath = path.join(stateDir(), 'development.log');
    console.log(`Tailing log file ${logPath}\n`);
    if (!fs.existsSync(logPath)) {
      console.log(`${timestamp()} Log file does not exist. Run \`lazygit --debug\` first to create the log file`);
      process.exit(1);
    }
    process.stdout.write(fs.readFileSync(logPath, 'utf8'));
    return;
  }
  const pos = opts.positionals[0];
  if (pos && !VALID_POSITIONAL.has(pos)) {
    console.log(`${timestamp()} Invalid git arg value: '${pos}'. Must be one of the following values: status, branch, log, stash. e.g. 'lazygit status'. See 'lazygit --help'.`);
    process.exit(1);
  }
  runApp(opts);
}

main();
