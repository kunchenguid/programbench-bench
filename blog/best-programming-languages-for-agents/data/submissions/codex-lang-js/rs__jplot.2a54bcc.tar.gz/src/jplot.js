#!/usr/bin/env node
"use strict";

const http = require("http");
const https = require("https");

const HELP = `Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:

OPTIONS:
  -interval duration
    \tWhen url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)
  -rows int
    \tLimits the height of the graph output.
  -steps int
    \tNumber of values to plot. (default 100)
  -url string
    \tURL to fetch every second. Read JSON objects from stdin if not specified.

FIELD_SPEC: [<option>[,<option>...]:]path
  option:
    - counter: Computes the difference with the last value. The value must increase monotonically.
    - marker: When the value is none-zero, a vertical line is drawn.
  path:
    JSON field path (eg: field.sub-field).
`;

function terminalProbe() {
  if (!process.env.TERM_PROGRAM) {
    process.stdout.write("\x1b[c");
  }
}

function printUsage() {
  process.stdout.write(HELP);
}

function flagError(message) {
  process.stdout.write(message + "\n");
  printUsage();
  process.exit(2);
}

function parseIntFlag(name, value) {
  if (value === undefined || value === "" || !/^-?\d+$/.test(value)) {
    flagError(`invalid value "${value === undefined ? "" : value}" for flag -${name}: parse error`);
  }
  return Number.parseInt(value, 10);
}

function parseDuration(value) {
  if (value === undefined || value === "") {
    flagError(`invalid value "" for flag -interval: parse error`);
  }
  const m = String(value).match(/^([0-9]+(?:\.[0-9]+)?)(ns|us|µs|ms|s|m|h)?$/);
  if (!m) {
    flagError(`invalid value "${value}" for flag -interval: parse error`);
  }
  const n = Number(m[1]);
  const unit = m[2] || "ns";
  const mult = { ns: 1e-6, us: 1e-3, "µs": 1e-3, ms: 1, s: 1000, m: 60000, h: 3600000 }[unit];
  return Math.max(0, Math.round(n * mult));
}

function parseArgs(argv) {
  const opts = { interval: 1000, rows: 0, steps: 100, url: "" };
  const specs = [];
  for (let i = 0; i < argv.length; i++) {
    let arg = argv[i];
    if (arg === "-h" || arg === "--help" || arg === "-help") {
      printUsage();
      process.exit(0);
    }
    if (arg === "--") {
      specs.push(...argv.slice(i + 1));
      break;
    }
    if (!arg.startsWith("-") || arg === "-") {
      specs.push(arg);
      continue;
    }
    const original = arg;
    while (arg.startsWith("--")) arg = arg.slice(1);
    let value;
    const eq = arg.indexOf("=");
    if (eq >= 0) {
      value = arg.slice(eq + 1);
      arg = arg.slice(0, eq);
    }
    const name = arg.slice(1);
    if (!["interval", "rows", "steps", "url"].includes(name)) {
      const shown = original.replace(/^--/, "-");
      flagError(`flag provided but not defined: ${shown}`);
    }
    if (value === undefined) {
      i++;
      value = argv[i];
    }
    if (value === undefined) {
      process.stdout.write(`flag needs an argument: -${name}\n`);
      printUsage();
      process.exit(2);
    }
    if (name === "interval") opts.interval = parseDuration(value);
    else if (name === "rows") opts.rows = parseIntFlag(name, value);
    else if (name === "steps") opts.steps = parseIntFlag(name, value);
    else opts.url = value === undefined ? "" : String(value);
  }
  return { opts, specs };
}

function parseFieldPart(text) {
  let opts = [];
  let path = text;
  const colon = text.indexOf(":");
  if (colon >= 0) {
    const prefix = text.slice(0, colon);
    const candidate = prefix.split(",").filter(Boolean);
    if (candidate.every((x) => x === "counter" || x === "marker")) {
      opts = candidate;
      path = text.slice(colon + 1);
    }
  }
  return {
    raw: text,
    path,
    label: path || text,
    counter: opts.includes("counter"),
    marker: opts.includes("marker"),
    last: undefined,
    values: [],
    markers: [],
  };
}

function parseSpecs(specs) {
  return specs.map((group) => group.split("+").map(parseFieldPart));
}

function lookup(obj, path) {
  if (!path) return undefined;
  let cur = obj;
  for (const part of path.split(".")) {
    if (cur == null || typeof cur !== "object" || !Object.prototype.hasOwnProperty.call(cur, part)) {
      return undefined;
    }
    cur = cur[part];
  }
  return cur;
}

function numericValue(v) {
  if (typeof v === "number") return Number.isFinite(v) ? v : undefined;
  if (typeof v === "string" && v.trim() !== "") {
    const n = Number(v);
    return Number.isFinite(n) ? n : undefined;
  }
  if (typeof v === "boolean") return v ? 1 : 0;
  return undefined;
}

function ingest(groups, obj, steps) {
  for (const group of groups) {
    for (const field of group) {
      const raw = numericValue(lookup(obj, field.path));
      let val = raw;
      if (field.counter) {
        if (field.last === undefined || raw === undefined) {
          val = 0;
        } else {
          val = raw - field.last;
          if (val < 0) val = 0;
        }
        if (raw !== undefined) field.last = raw;
      }
      field.values.push(val === undefined ? 0 : val);
      field.markers.push(Boolean(field.marker && raw));
      if (field.values.length > steps) field.values.shift();
      if (field.markers.length > steps) field.markers.shift();
    }
  }
}

function formatNum(n) {
  if (!Number.isFinite(n)) return "0";
  if (Math.abs(n) >= 1000 || (Math.abs(n) > 0 && Math.abs(n) < 0.01)) return n.toExponential(2);
  if (Math.abs(n - Math.round(n)) < 1e-9) return String(Math.round(n));
  return n.toFixed(2).replace(/\.?0+$/, "");
}

const SYMBOLS = " ▁▂▃▄▅▆▇█";

function sparkline(values, width) {
  const vals = values.slice(-width);
  if (vals.length === 0) return "";
  const max = Math.max(...vals, 0);
  if (max <= 0) return " ".repeat(vals.length);
  return vals.map((v) => SYMBOLS[Math.max(0, Math.min(8, Math.ceil((v / max) * 8)))]).join("");
}

function render(groups, options) {
  const width = Math.max(10, Math.min(options.steps || 100, Number(process.env.COLUMNS || 80) - 28));
  const maxRows = options.rows > 0 ? options.rows : Infinity;
  let printed = 0;
  const lines = [];
  groups.forEach((group, gi) => {
    if (printed >= maxRows) return;
    if (groups.length > 1) {
      lines.push(`graph ${gi + 1}`);
      printed++;
      if (printed >= maxRows) return;
    }
    for (const field of group) {
      if (printed >= maxRows) break;
      const vals = field.values;
      const last = vals.length ? vals[vals.length - 1] : 0;
      const max = vals.length ? Math.max(...vals) : 0;
      let marks = "";
      if (field.markers.some(Boolean)) {
        marks = " " + field.markers.slice(-width).map((m) => (m ? "|" : " ")).join("");
      }
      const label = field.label.length > 18 ? field.label.slice(0, 17) + "…" : field.label;
      lines.push(`${label.padEnd(18)} ${formatNum(last).padStart(8)} ${sparkline(vals, width)}${marks}`);
      printed++;
    }
  });
  process.stdout.write(lines.join("\n") + (lines.length ? "\n" : ""));
}

function readStdin() {
  return new Promise((resolve) => {
    let data = "";
    process.stdin.setEncoding("utf8");
    process.stdin.on("data", (chunk) => { data += chunk; });
    process.stdin.on("end", () => resolve(data));
    if (process.stdin.isTTY) resolve("");
  });
}

function fetchURL(url) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith("https:") ? https : http;
    const req = lib.get(url, (res) => {
      let data = "";
      res.setEncoding("utf8");
      res.on("data", (chunk) => { data += chunk; });
      res.on("end", () => {
        if (res.statusCode && res.statusCode >= 400) reject(new Error(`status code ${res.statusCode}`));
        else resolve(data);
      });
    });
    req.on("error", reject);
    req.setTimeout(10000, () => {
      req.destroy(new Error("request timeout"));
    });
  });
}

function parseObjects(text) {
  const trimmed = text.trim();
  if (!trimmed) return [];
  const objects = [];
  for (const line of trimmed.split(/\r?\n/)) {
    if (!line.trim()) continue;
    objects.push(JSON.parse(line));
  }
  return objects;
}

async function main() {
  terminalProbe();
  const { opts, specs } = parseArgs(process.argv.slice(2));
  if (specs.length === 0) {
    printUsage();
    process.exit(1);
  }
  const groups = parseSpecs(specs);
  try {
    let text;
    if (opts.url) {
      text = await fetchURL(opts.url);
    } else {
      text = await readStdin();
      if (!text.trim()) {
        process.stdout.write("jplot:  neither --url nor stdin is provided\n");
        process.exit(1);
      }
    }
    const objects = parseObjects(text);
    for (const obj of objects) ingest(groups, obj, Math.max(1, opts.steps));
    render(groups, opts);
  } catch (err) {
    process.stdout.write(`jplot:  Data source error:  input error: ${err.message}\n`);
    process.exit(1);
  }
}

main();
