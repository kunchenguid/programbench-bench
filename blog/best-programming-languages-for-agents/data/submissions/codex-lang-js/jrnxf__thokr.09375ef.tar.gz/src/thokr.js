#!/usr/bin/env node
"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");

const VERSION = "thokr 0.4.1";
const ABOUT = "sleek typing tui with visualized results and historical logging";

const HELP = `${VERSION}
${ABOUT}

USAGE:
    executable [OPTIONS]

OPTIONS:
    -f, --full-sentences <NUMBER_OF_SENTENCES>
            number of sentences to use in test

    -h, --help
            Print help information

    -l, --supported-language <SUPPORTED_LANGUAGE>
            language to pull words from [default: english] [possible values: english, english1k,
            english10k]

    -p, --prompt <PROMPT>
            custom prompt to use

    -s, --number-of-secs <NUMBER_OF_SECS>
            number of seconds to run test

    -V, --version
            Print version information

    -w, --number-of-words <NUMBER_OF_WORDS>
            number of words to use in test [default: 15]
`;

const COMMON_WORDS = `
the be to of and a in that have i it for not on with he as you do at this but
his by from they we say her she or an will my one all would there their what so
up out if about who get which go me when make can like time no just him know
take people into year your good some could them see other than then now look
only come its over think also back after use two how our work first well way
even new want because any these give day most us is are was were has had did
been being am may might must shall should where why many much very through
before right too means old place same great tell men small every found still
between name own under last never left while next few got both group often run
important until children side feet car mile night walk white sea began grow took
river four carry state once book hear stop without second later miss idea enough
eat face watch far indian real almost let above girl sometimes mountain cut young
talk soon list song leave family body music color stand sun questions fish area
mark dog horse birds problem complete room knew since ever piece told usually
didnt friends easy heard order red door sure become top ship across today during
short better best however low hours black products happened whole measure remember
early waves reached listen wind rock space covered fast several hold himself
toward five step morning passed vowel true hundred against pattern numeral table
north slowly money map farm pulled draw voice seen cold cried plan notice south
sing war ground fall king town unit figure certain field travel wood fire upon
done english road half ten fly gave box finally wait correct oh quickly person
became shown minutes strong verb stars front feel fact inches street decided
contain course surface produce building ocean class note nothing rest carefully
scientists inside wheels stay green known island week less machine base ago stood
plane system behind ran round boat game force brought understand warm common
bring explain dry though language shape deep thousands yes clear equation yet
government filled heat full hot check object rule among noun power cannot able
six size dark ball material special heavy fine pair circle include built cant
matter square syllables perhaps bill felt suddenly test direction center farmers
ready anything divided general energy subject europe moon region return believe
dance members picked simple cells paint mind love cause rain exercise eggs train
blue wish drop developed window difference distance heart sit sum summer wall
forest probably legs sat main winter wide written length reason kept interest
arms brother race present beautiful store job edge past sign record finished
discovered wild happy beside gone sky grass million west lay weather root
instruments meet third months paragraph raised represent soft whether clothes
flowers shall teacher held describe drive cross speak solve appear metal son
either ice sleep village factors result jumped snow ride care floor hill pushed
baby buy century outside everything tall already instead phrase soil bed copy free
hope spring case laughed nation quite type themselves temperature bright lead
everyone method section lake consonant within dictionary hair age amount scale
pounds although per broken moment tiny possible gold milk quiet natural lot stone
act build middle speed count cat someone sail rolled bear wonder smiled angle
fraction africa killed melody bottom trip hole poor lets fight surprise french
died beat exactly remain dress iron couldnt fingers row least catch climbed wrote
shouted continued itself else plains gas england burning design joined foot law
ears glass youre grew skin valley cents key president brown trouble cool cloud
lost sent symbols wear bad save experiment engine alone drawing east choose
single touch information express mouth yard equal decimal yourself control
practice report straight rise statement stick party seeds suppose woman coast
bank period wire pay clean visit bit whose received garden please strange caught
fell team god captain direct ring serve child desert increase history cost maybe
business separate break uncle hunting flow lady students human art feeling supply
corner electric insects crops tone hit sand doctor provide thus wont cook bones
tail board modern compound mine wasnt fit addition belong safe soldiers guess
silent trade rather compare crowd poem enjoy elements indicate except expect flat
interesting sense string blow famous value wings movement pole exciting branches
thick blood lie spot bell fun loud consider suggested thin position entered fruit
tied rich dollars send sight chief japanese stream planets rhythm eight science
major observe tube necessary weight meat lifted process army hat property particular
swim terms current park sell shoulder industry wash block spread cattle wife
sharp company radio well action capital factories settled yellow isnt southern
truck fair printed wouldnt ahead chance born level triangle molecules france
repeated column western church sister oxygen plural various agreed opposite wrong
chart prepared pretty solution fresh shop suffix especially shoes actually nose
afraid dead sugar adjective fig office huge gun similar death score forward
stretched experience rose allow fear workers washington greek women bought led
march northern create difficult match win doesnt steel total deal determine
evening rope cotton apple details entire corn substances smell tools conditions
cows track arrived located sir seat division effect underline view sad ugly boring
busy late worse friendly brave calm grand honest kind lucky neat proud quick rare
sharp smooth useful wise angry basic daily empty final gross local major novel
prime rough solid spare thick upper vital weekly yearly
`.trim().split(/\s+/);

function die(message, usage) {
  process.stderr.write(`error: ${message}\n\n`);
  if (usage) process.stderr.write(`${usage}\n\n`);
  process.stderr.write("For more information try --help\n");
  process.exit(2);
}

function parseUIntValue(flagName, value) {
  if (!/^\d+$/.test(value)) {
    die(`Invalid value "${value}" for '${flagName}': invalid digit found in string`, null);
  }
  return Number(value);
}

function nextValue(args, i, flag, display) {
  if (i + 1 >= args.length) {
    die(`The argument '${display}' requires a value but none was supplied`, "USAGE:\n    executable [OPTIONS]");
  }
  if (args[i + 1].startsWith("-")) {
    const v = args[i + 1];
    die(`Found argument '${v}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply \`${v}\` as a value rather than a flag, use \`-- ${v}\``, "USAGE:\n    executable [OPTIONS]");
  }
  return args[i + 1];
}

function parseArgs(argv) {
  const opts = { words: 15, lang: "english", prompt: null, sentences: null, seconds: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") {
      process.stdout.write(HELP);
      process.exit(0);
    }
    if (a === "-V" || a === "--version") {
      process.stdout.write(`${VERSION}\n`);
      process.exit(0);
    }
    if (a === "--") {
      if (i + 1 < argv.length) {
        const v = argv[i + 1];
        const hint = v.startsWith("-") ? `\n\n\tIf you tried to supply \`${v}\` as a value rather than a flag, use \`-- ${v}\`` : "";
        die(`Found argument '${v}' which wasn't expected, or isn't valid in this context${hint}`, "USAGE:\n    executable [OPTIONS]");
      }
      continue;
    }

    let val;
    if (a === "-w" || a === "--number-of-words" || a.startsWith("-w=") || a.startsWith("--number-of-words=")) {
      if (a.includes("=")) val = a.slice(a.indexOf("=") + 1);
      else { val = nextValue(argv, i, a, "--number-of-words <NUMBER_OF_WORDS>"); i++; }
      opts.words = parseUIntValue("--number-of-words <NUMBER_OF_WORDS>", val);
    } else if (a === "-s" || a === "--number-of-secs" || a.startsWith("-s=") || a.startsWith("--number-of-secs=")) {
      if (a.includes("=")) val = a.slice(a.indexOf("=") + 1);
      else { val = nextValue(argv, i, a, "--number-of-secs <NUMBER_OF_SECS>"); i++; }
      opts.seconds = parseUIntValue("--number-of-secs <NUMBER_OF_SECS>", val);
    } else if (a === "-f" || a === "--full-sentences" || a.startsWith("-f=") || a.startsWith("--full-sentences=")) {
      if (a.includes("=")) val = a.slice(a.indexOf("=") + 1);
      else { val = nextValue(argv, i, a, "--full-sentences <NUMBER_OF_SENTENCES>"); i++; }
      opts.sentences = parseUIntValue("--full-sentences <NUMBER_OF_SENTENCES>", val);
    } else if (a === "-p" || a === "--prompt" || a.startsWith("-p=") || a.startsWith("--prompt=")) {
      if (a.includes("=")) val = a.slice(a.indexOf("=") + 1);
      else { val = nextValue(argv, i, a, "--prompt <PROMPT>"); i++; }
      opts.prompt = val;
    } else if (a === "-l" || a === "--supported-language" || a.startsWith("-l=") || a.startsWith("--supported-language=")) {
      if (a.includes("=")) val = a.slice(a.indexOf("=") + 1);
      else { val = nextValue(argv, i, a, "--supported-language <SUPPORTED_LANGUAGE>"); i++; }
      if (!["english", "english1k", "english10k"].includes(val)) {
        die(`"${val}" isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'\n\t[possible values: english, english1k, english10k]`, "USAGE:\n    executable --supported-language <SUPPORTED_LANGUAGE>");
      }
      opts.lang = val;
    } else if (/^-[A-Za-z]+$/.test(a) && a.length > 2) {
      if (i + 1 < argv.length) {
        die(`Found argument '${argv[i + 1]}' which wasn't expected, or isn't valid in this context`, "USAGE:\n    executable [OPTIONS]");
      }
      die(`Found argument '${a}' which wasn't expected, or isn't valid in this context`, "USAGE:\n    executable [OPTIONS]");
    } else {
      const hint = a.startsWith("-") ? `\n\n\tIf you tried to supply \`${a}\` as a value rather than a flag, use \`-- ${a}\`` : "";
      die(`Found argument '${a}' which wasn't expected, or isn't valid in this context${hint}`, "USAGE:\n    executable [OPTIONS]");
    }
  }
  return opts;
}

function randInt(n) {
  return Math.floor(Math.random() * n);
}

function makePrompt(opts) {
  if (opts.prompt !== null) return opts.prompt;
  if (opts.sentences !== null) {
    const sentences = [];
    for (let s = 0; s < opts.sentences; s++) {
      const len = 7 + randInt(7);
      const words = [];
      for (let i = 0; i < len; i++) words.push(COMMON_WORDS[randInt(COMMON_WORDS.length)]);
      words[0] = words[0].charAt(0).toUpperCase() + words[0].slice(1);
      sentences.push(`${words.join(" ")}.`);
    }
    return sentences.join(" ");
  }
  const words = [];
  for (let i = 0; i < opts.words; i++) words.push(COMMON_WORDS[randInt(COMMON_WORDS.length)]);
  return words.join(" ");
}

function two(n) {
  return String(n).padStart(2, "0");
}

function dateForLog(d) {
  const wd = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][d.getDay()];
  const mo = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][d.getMonth()];
  return `${wd} ${mo} ${two(d.getDate())} ${two(d.getHours())}:${two(d.getMinutes())}:${two(d.getSeconds())} ${d.getFullYear()}`;
}

function appendLog(prompt, seconds, elapsed, wpm, accuracy, stddev) {
  const dir = path.join(os.homedir(), ".config", "thokr");
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, "log.csv");
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, "date,num_words,num_secs,elapsed_secs,wpm,accuracy,std_dev\n");
  }
  const numWords = prompt.trim() ? prompt.trim().split(/\s+/).length : 0;
  const secField = seconds === null || seconds === undefined ? "" : String(seconds);
  fs.appendFileSync(file, `${dateForLog(new Date())},${numWords},${secField},${elapsed.toFixed(2)},${wpm},${Math.round(accuracy)},${stddev.toFixed(2)}\n`);
}

function clearAndDraw(prompt, typed, done, stats) {
  const cols = process.stdout.columns || 80;
  const rows = process.stdout.rows || 24;
  let out = "\x1b[2J";
  const line = renderPrompt(prompt, typed);
  const plainLen = prompt.length;
  const row = Math.max(2, Math.floor(rows / 2));
  const col = Math.max(1, Math.floor((cols - plainLen) / 2));
  out += `\x1b[${row};${col}H${line}`;
  if (done) {
    const info = `${stats.wpm} wpm   ${Math.round(stats.accuracy)}% acc   ${stats.stddev.toFixed(2)} sd`;
    out += `\x1b[${Math.min(rows, row + 4)};${Math.max(1, Math.floor((cols - info.length) / 2))}H\x1b[1m${info}\x1b[22m`;
    const hint = "(r)etry / (n)ew / (esc)ape";
    out += `\x1b[${Math.min(rows, row + 6)};${Math.max(1, Math.floor((cols - hint.length) / 2))}H\x1b[3m${hint}\x1b[23m`;
  }
  process.stdout.write(out);
}

function renderPrompt(prompt, typed) {
  let out = "\x1b[1m";
  for (let i = 0; i < prompt.length; i++) {
    if (i < typed.length) {
      out += typed[i] === prompt[i] ? "\x1b[38;5;2m" : "\x1b[38;5;1m";
      out += escapeText(prompt[i]);
    } else if (i === typed.length) {
      out += "\x1b[39m\x1b[4m\x1b[2m" + escapeText(prompt[i]) + "\x1b[24m\x1b[22m";
    } else {
      out += "\x1b[39m" + escapeText(prompt[i]);
    }
  }
  return out + "\x1b[0m";
}

function escapeText(s) {
  if (s === "\n") return " ";
  return s.replace(/\x1b/g, "");
}

function runTui(opts) {
  if (!process.stdin.isTTY) {
    process.stderr.write("error: stdin must be a tty\n\nUSAGE:\n    thokr [OPTIONS]\n\nFor more information try --help\n");
    process.exit(2);
  }

  let prompt = makePrompt(opts);
  let typed = "";
  let started = null;
  let done = false;
  let timer = null;
  let stats = null;

  function finish() {
    if (done) return;
    done = true;
    const now = Date.now();
    const elapsed = started ? Math.max(0, (now - started) / 1000) : 0;
    let correct = 0;
    for (let i = 0; i < typed.length; i++) if (typed[i] === prompt[i]) correct++;
    const accuracy = typed.length ? (correct / typed.length) * 100 : 100;
    const minutes = elapsed / 60;
    const wpmNum = minutes > 0 ? (typed.length / 5) / minutes : Infinity;
    const wpm = !Number.isFinite(wpmNum) || elapsed.toFixed(2) === "0.00" ? "inf" : String(Math.round(wpmNum));
    stats = { elapsed, wpm, accuracy, stddev: 0 };
    appendLog(prompt, opts.seconds, elapsed, wpm, accuracy, 0);
    clearAndDraw(prompt, typed, true, stats);
  }

  function reset(newPrompt) {
    typed = "";
    started = null;
    done = false;
    stats = null;
    if (timer) clearTimeout(timer);
    timer = null;
    if (newPrompt && opts.prompt === null) prompt = makePrompt(opts);
    clearAndDraw(prompt, typed, false, null);
  }

  process.stdout.write("\x1b[?1049h\x1b[?25l");
  process.stdin.setRawMode(true);
  process.stdin.resume();
  clearAndDraw(prompt, typed, false, null);

  const cleanup = (code) => {
    if (timer) clearTimeout(timer);
    process.stdin.setRawMode(false);
    process.stdout.write("\x1b[?1049l\x1b[?25h");
    process.exit(code);
  };

  process.on("SIGINT", () => cleanup(0));

  process.stdin.on("data", (buf) => {
    const s = buf.toString("utf8");
    if (done) {
      if (s === "\x1b" || s === "\u0003" || s === "q") cleanup(0);
      if (s.toLowerCase() === "r") reset(false);
      if (s.toLowerCase() === "n") reset(true);
      return;
    }
    if (s === "\x1b" || s === "\u0003") cleanup(0);
    if (s === "\x7f" || s === "\b") {
      typed = typed.slice(0, -1);
      clearAndDraw(prompt, typed, false, null);
      return;
    }
    if (s === "\x1b[D") {
      reset(false);
      return;
    }
    if (s === "\x1b[C") {
      reset(true);
      return;
    }
    for (const ch of s) {
      if (ch < " " && ch !== "\n" && ch !== "\r" && ch !== "\t") continue;
      if (!started) {
        started = Date.now();
        if (opts.seconds !== null) timer = setTimeout(finish, opts.seconds * 1000);
      }
      typed += ch === "\r" ? "\n" : ch;
      if (typed.length >= prompt.length) {
        finish();
        return;
      }
    }
    clearAndDraw(prompt, typed, false, null);
  });
}

runTui(parseArgs(process.argv.slice(2)));
