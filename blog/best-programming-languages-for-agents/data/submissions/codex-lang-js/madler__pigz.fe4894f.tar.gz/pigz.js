#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const VERSION = "pigz 2.8";
const LICENSE = `pigz 2.8
Copyright (C) 2007-2023 Mark Adler
Subject to the terms of the zlib license.
No warranty is provided or implied.
`;

const HELP = `Usage: pigz [options] [files ...]
  will compress files in place, adding the suffix '.gz'. If no files are
  specified, stdin will be compressed to stdout. pigz does what gzip does,
  but spreads the work over multiple processors and cores when compressing.

Options:
  -0 to -9, -11        Compression level (level 11, zopfli, is much slower)
  --fast, --best       Compression levels 1 and 9 respectively
  -A, --alias xxx      Use xxx as the name for any --zip entry from stdin
  -b, --blocksize mmm  Set compression block size to mmmK (default 128K)
  -c, --stdout         Write all processed output to stdout (won't delete)
  -C, --comment ccc    Put comment ccc in the gzip or zip header
  -d, --decompress     Decompress the compressed input
  -f, --force          Force overwrite, compress .gz, links, and to terminal
  -F  --first          Do iterations first, before block split for -11
  -h, --help           Display a help screen and quit
  -H, --huffman        Use only Huffman coding for compression
  -i, --independent    Compress blocks independently for damage recovery
  -I, --iterations n   Number of iterations for -11 optimization
  -J, --maxsplits n    Maximum number of split blocks for -11
  -k, --keep           Do not delete original file after processing
  -K, --zip            Compress to PKWare zip (.zip) single entry format
  -l, --list           List the contents of the compressed input
  -L, --license        Display the pigz license and quit
  -m, --no-time        Do not store or restore mod time
  -M, --time           Store or restore mod time
  -n, --no-name        Do not store or restore file name or mod time
  -N, --name           Store or restore file name and mod time
  -O  --oneblock       Do not split into smaller blocks for -11
  -p, --processes n    Allow up to n compression threads (default is the
                       number of online processors, or 8 if unknown)
  -q, --quiet          Print no messages, even on error
  -r, --recursive      Process the contents of all subdirectories
  -R, --rsyncable      Input-determined block locations for rsync
  -S, --suffix .sss    Use suffix .sss instead of .gz (for compression)
  -t, --test           Test the integrity of the compressed input
  -U, --rle            Use run-length encoding for compression
  -v, --verbose        Provide more verbose output
  -V  --version        Show the version of pigz
  -Y  --synchronous    Force output file write to permanent storage
  -z, --zlib           Compress to zlib (.zz) instead of gzip format
  --                   All arguments after "--" are treated as files
`;

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (const b of buf) c = CRC_TABLE[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function adler32(buf) {
  let a = 1, b = 0;
  for (const x of buf) {
    a = (a + x) % 65521;
    b = (b + a) % 65521;
  }
  return (((b << 16) | a) >>> 0);
}

function splitWords(s) {
  if (!s) return [];
  const out = [];
  let cur = "", quote = null, esc = false;
  for (const ch of s) {
    if (esc) { cur += ch; esc = false; continue; }
    if (ch === "\\") { esc = true; continue; }
    if (quote) {
      if (ch === quote) quote = null; else cur += ch;
      continue;
    }
    if (ch === "'" || ch === '"') { quote = ch; continue; }
    if (/\s/.test(ch)) { if (cur) { out.push(cur); cur = ""; } continue; }
    cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

function defaults() {
  return {
    decompress: path.basename(process.argv[1]).includes("unpigz"),
    stdout: false, keep: false, force: false, quiet: false, recursive: false,
    verbose: 0, list: false, test: false, zip: false, zlibFmt: false,
    suffix: ".gz", level: 6, name: true, time: true, comment: null, alias: "-",
    huffman: false, rle: false, sync: false, files: []
  };
}

function needArg(args, i, opt) {
  if (i + 1 >= args.length) throw new Error(`option requires an argument -- ${opt}`);
  return args[i + 1];
}

function parse(args) {
  const opts = defaults();
  const all = [...splitWords(process.env.GZIP || ""), ...splitWords(process.env.PIGZ || ""), ...args];
  for (let i = 0; i < all.length; i++) {
    const a = all[i];
    if (a === "--") { opts.files.push(...all.slice(i + 1)); break; }
    if (!a.startsWith("-") || a === "-") { opts.files.push(a); continue; }
    if (a === "--help") { console.log(HELP); process.exit(0); }
    if (a === "--version") { console.log(VERSION); process.exit(0); }
    if (a === "--license") { process.stdout.write(LICENSE); process.exit(0); }
    const longMap = {
      "--fast": ["level", 1], "--best": ["level", 9], "--stdout": ["stdout", true],
      "--to-stdout": ["stdout", true], "--decompress": ["decompress", true],
      "--uncompress": ["decompress", true], "--force": ["force", true],
      "--huffman": ["huffman", true], "--independent": ["independent", true],
      "--keep": ["keep", true], "--zip": ["zip", true], "--list": ["list", true],
      "--no-time": ["time", false], "--time": ["time", true], "--no-name": ["name", false, "time", false],
      "--name": ["name", true, "time", true], "--quiet": ["quiet", true],
      "--silent": ["quiet", true], "--recursive": ["recursive", true],
      "--rsyncable": ["rsyncable", true], "--test": ["test", true],
      "--rle": ["rle", true], "--verbose": ["verbose", 1], "--zlib": ["zlibFmt", true],
      "--synchronous": ["sync", true], "--first": ["first", true], "--oneblock": ["oneblock", true]
    };
    const argLong = ["--alias", "--blocksize", "--comment", "--processes", "--suffix", "--iterations", "--maxsplits"];
    if (a.startsWith("--") && a.includes("=")) {
      const [k, v] = a.split(/=(.*)/s, 2);
      all.splice(i, 1, k, v);
      i--;
      continue;
    }
    if (a in longMap) {
      const m = longMap[a];
      opts[m[0]] = m[1];
      if (m.length > 2) opts[m[2]] = m[3];
      continue;
    }
    if (argLong.includes(a)) {
      const v = needArg(all, i, a);
      if (a === "--alias") opts.alias = v;
      else if (a === "--comment") opts.comment = v;
      else if (a === "--suffix") opts.suffix = v;
      i++;
      continue;
    }
    for (let j = 1; j < a.length; j++) {
      const ch = a[j];
      if (/[1-9]/.test(ch) || ch === "0") {
        if (ch === "1" && a[j + 1] === "1") { opts.level = 9; j++; }
        else opts.level = Number(ch);
      } else if (ch === "A" || ch === "b" || ch === "C" || ch === "I" || ch === "J" || ch === "p" || ch === "S") {
        let v = a.slice(j + 1);
        if (!v) { v = needArg(all, i, ch); i++; }
        if (ch === "A") opts.alias = v;
        else if (ch === "C") opts.comment = v;
        else if (ch === "S") opts.suffix = v;
        break;
      } else if (ch === "c") opts.stdout = true;
      else if (ch === "d") opts.decompress = true;
      else if (ch === "f") opts.force = true;
      else if (ch === "h") { console.log(HELP); process.exit(0); }
      else if (ch === "H") opts.huffman = true;
      else if (ch === "i") opts.independent = true;
      else if (ch === "k") opts.keep = true;
      else if (ch === "K") opts.zip = true;
      else if (ch === "l") opts.list = true;
      else if (ch === "L") { process.stdout.write(LICENSE); process.exit(0); }
      else if (ch === "m") opts.time = false;
      else if (ch === "M") opts.time = true;
      else if (ch === "n") { opts.name = false; opts.time = false; }
      else if (ch === "N") { opts.name = true; opts.time = true; }
      else if (ch === "q") opts.quiet = true;
      else if (ch === "r") opts.recursive = true;
      else if (ch === "R") opts.rsyncable = true;
      else if (ch === "t") opts.test = true;
      else if (ch === "U") opts.rle = true;
      else if (ch === "v") opts.verbose++;
      else if (ch === "V") { console.log(opts.verbose ? `${VERSION}\nzlib ${process.versions.zlib}` : VERSION); process.exit(0); }
      else if (ch === "Y") opts.sync = true;
      else if (ch === "z") opts.zlibFmt = true;
      else if (ch === "F" || ch === "O") {}
      else throw new Error(`invalid option -- ${ch}`);
    }
  }
  if (opts.list || opts.test) opts.decompress = true;
  if (opts.zip) opts.zlibFmt = false;
  return opts;
}

function warn(opts, msg) {
  if (!opts.quiet) process.stderr.write(`${path.basename(process.argv[1])}: ${msg}\n`);
}

function readStdin() {
  return fs.readFileSync(0);
}

function writeAll(fd, buf) {
  fs.writeSync(fd, buf, 0, buf.length);
}

function cString(s) {
  return Buffer.from(String(s).replace(/\0/g, ""), "utf8");
}

function gzipBuffer(input, opts, meta) {
  const flgName = opts.name && meta.name;
  const flgComment = opts.comment != null;
  let flags = (flgName ? 8 : 0) | (flgComment ? 16 : 0);
  const header = Buffer.alloc(10);
  header[0] = 0x1f; header[1] = 0x8b; header[2] = 8; header[3] = flags;
  header.writeUInt32LE(opts.time && meta.mtime ? Math.floor(meta.mtime) : 0, 4);
  header[8] = opts.level === 9 ? 2 : (opts.level === 1 ? 4 : 0);
  header[9] = 3;
  const parts = [header];
  if (flgName) parts.push(cString(path.basename(meta.name)), Buffer.from([0]));
  if (flgComment) parts.push(cString(opts.comment), Buffer.from([0]));
  const strategy = opts.huffman ? zlib.constants.Z_HUFFMAN_ONLY : (opts.rle ? zlib.constants.Z_RLE : zlib.constants.Z_DEFAULT_STRATEGY);
  parts.push(zlib.deflateRawSync(input, { level: opts.level, strategy }));
  const trailer = Buffer.alloc(8);
  trailer.writeUInt32LE(crc32(input), 0);
  trailer.writeUInt32LE(input.length >>> 0, 4);
  parts.push(trailer);
  return Buffer.concat(parts);
}

function dosTime(date) {
  const d = date || new Date();
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
  const day = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time: time & 0xffff, date: day & 0xffff };
}

function zipBuffer(input, opts, meta) {
  const filename = cString(meta.name ? path.basename(meta.name) : opts.alias || "-");
  const comment = opts.comment == null ? Buffer.alloc(0) : cString(opts.comment);
  const deflated = zlib.deflateRawSync(input, { level: opts.level });
  const crc = crc32(input);
  const dt = dosTime(opts.time && meta.mtime ? new Date(meta.mtime * 1000) : new Date(0));
  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(0, 6);
  local.writeUInt16LE(8, 8); local.writeUInt16LE(dt.time, 10); local.writeUInt16LE(dt.date, 12);
  local.writeUInt32LE(crc, 14); local.writeUInt32LE(deflated.length, 18); local.writeUInt32LE(input.length >>> 0, 22);
  local.writeUInt16LE(filename.length, 26); local.writeUInt16LE(0, 28);
  const central = Buffer.alloc(46);
  central.writeUInt32LE(0x02014b50, 0); central.writeUInt16LE(0x031e, 4); central.writeUInt16LE(20, 6);
  central.writeUInt16LE(0, 8); central.writeUInt16LE(8, 10); central.writeUInt16LE(dt.time, 12); central.writeUInt16LE(dt.date, 14);
  central.writeUInt32LE(crc, 16); central.writeUInt32LE(deflated.length, 20); central.writeUInt32LE(input.length >>> 0, 24);
  central.writeUInt16LE(filename.length, 28); central.writeUInt16LE(0, 30); central.writeUInt16LE(comment.length, 32);
  central.writeUInt16LE(0, 34); central.writeUInt16LE(0, 36); central.writeUInt32LE(0, 38); central.writeUInt32LE(0, 42);
  const centralStart = local.length + filename.length + deflated.length;
  const centralSize = central.length + filename.length + comment.length;
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(0, 4); end.writeUInt16LE(0, 6);
  end.writeUInt16LE(1, 8); end.writeUInt16LE(1, 10); end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(centralStart, 16); end.writeUInt16LE(0, 20);
  return Buffer.concat([local, filename, deflated, central, filename, comment, end]);
}

function zlibBuffer(input, opts) {
  const strategy = opts.huffman ? zlib.constants.Z_HUFFMAN_ONLY : (opts.rle ? zlib.constants.Z_RLE : zlib.constants.Z_DEFAULT_STRATEGY);
  return zlib.deflateSync(input, { level: opts.level, strategy });
}

function parseGzip(buf) {
  if (buf.length < 18 || buf[0] !== 0x1f || buf[1] !== 0x8b || buf[2] !== 8) return null;
  const flags = buf[3];
  let off = 10;
  if (flags & 4) { if (off + 2 > buf.length) return null; off += 2 + buf.readUInt16LE(off); }
  let name = null, comment = null;
  if (flags & 8) { const end = buf.indexOf(0, off); if (end < 0) return null; name = buf.slice(off, end).toString(); off = end + 1; }
  if (flags & 16) { const end = buf.indexOf(0, off); if (end < 0) return null; comment = buf.slice(off, end).toString(); off = end + 1; }
  if (flags & 2) off += 2;
  const crc = buf.readUInt32LE(buf.length - 8);
  const size = buf.readUInt32LE(buf.length - 4);
  return { type: "gzip", name, comment, mtime: buf.readUInt32LE(4), compressed: Math.max(0, buf.length - off - 8), original: size, crc };
}

function parseZip(buf) {
  if (buf.length < 30 || buf.readUInt32LE(0) !== 0x04034b50) return null;
  const method = buf.readUInt16LE(8);
  const csize = buf.readUInt32LE(18), usize = buf.readUInt32LE(22);
  const nlen = buf.readUInt16LE(26), xlen = buf.readUInt16LE(28);
  const name = buf.slice(30, 30 + nlen).toString();
  return { type: "zip", method, name, dataOff: 30 + nlen + xlen, compressed: csize, original: usize, total: buf.length };
}

function decompressBuffer(buf) {
  const gz = parseGzip(buf);
  if (gz) return { data: zlib.gunzipSync(buf), meta: gz };
  const zp = parseZip(buf);
  if (zp) {
    const payload = buf.slice(zp.dataOff, zp.dataOff + zp.compressed);
    const data = zp.method === 0 ? payload : zlib.inflateRawSync(payload);
    return { data, meta: zp };
  }
  try { return { data: zlib.inflateSync(buf), meta: { type: "zlib", compressed: buf.length, original: null } }; }
  catch (_) { return { data: zlib.gunzipSync(buf), meta: { type: "gzip", compressed: buf.length, original: null } }; }
}

function collectFiles(inputs, recursive, opts) {
  if (inputs.length === 0) return ["-"];
  const out = [];
  for (const f of inputs) {
    if (f === "-") { out.push(f); continue; }
    let st;
    try { st = fs.lstatSync(f); } catch (_) { warn(opts, `skipping: ${f} does not exist`); process.exitCode = 1; continue; }
    if (st.isDirectory()) {
      if (!recursive) { warn(opts, `skipping: ${f} is a directory`); process.exitCode = 1; continue; }
      for (const ent of fs.readdirSync(f)) out.push(...collectFiles([path.join(f, ent)], recursive, opts));
    } else out.push(f);
  }
  return out;
}

function outNameCompress(file, opts) {
  if (opts.zip) return file + ".zip";
  if (opts.zlibFmt) return file + ".zz";
  return file + opts.suffix;
}

function outNameDecompress(file, opts, meta) {
  if (opts.name && meta && meta.name) return path.join(path.dirname(file), path.basename(meta.name));
  if (file.endsWith(opts.suffix)) return file.slice(0, -opts.suffix.length);
  if (file.endsWith(".gz") || file.endsWith(".zz")) return file.slice(0, -3);
  if (file.endsWith(".tgz")) return file.slice(0, -4) + ".tar";
  if (file.endsWith(".zip")) return file.slice(0, -4);
  return file + ".out";
}

function maybeWriteFile(out, data, opts) {
  if (!opts.force && fs.existsSync(out)) throw new Error(`${out} exists -- skipping`);
  fs.writeFileSync(out, data);
  if (opts.sync) {
    const fd = fs.openSync(out, "r");
    try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  }
}

function compressOne(file, opts) {
  const stdin = file === "-";
  if (!stdin && !opts.force && !opts.stdout && file.endsWith(opts.suffix)) {
    warn(opts, `skipping: ${file} ends with ${opts.suffix}`);
    return;
  }
  let input, st = null;
  if (stdin) input = readStdin();
  else { st = fs.statSync(file); input = fs.readFileSync(file); }
  const meta = { name: stdin ? null : file, mtime: st ? Math.floor(st.mtimeMs / 1000) : 0 };
  const out = opts.zip ? zipBuffer(input, opts, { name: stdin ? opts.alias : file, mtime: meta.mtime }) :
    opts.zlibFmt ? zlibBuffer(input, opts) : gzipBuffer(input, opts, meta);
  if (opts.stdout || stdin) {
    if (opts.verbose && !stdin) process.stderr.write(`${file} to <stdout> \n`);
    writeAll(1, out);
  } else {
    const name = outNameCompress(file, opts);
    maybeWriteFile(name, out, opts);
    try { fs.chmodSync(name, st.mode & 0o777); fs.utimesSync(name, st.atime, st.mtime); } catch (_) {}
    if (!opts.keep) fs.unlinkSync(file);
    if (opts.verbose) process.stderr.write(`${file} to ${name} \n`);
  }
}

function listOne(file, opts, first) {
  const buf = file === "-" ? readStdin() : fs.readFileSync(file);
  const gz = parseGzip(buf), zp = parseZip(buf);
  let compressed = buf.length, original = 0, name = file;
  if (gz) { compressed = gz.compressed; original = gz.original; name = gz.name || (file === "-" ? "<stdin>" : outNameDecompress(file, { ...opts, name: false }, null)); }
  else if (zp) { compressed = zp.compressed; original = zp.original; name = zp.name || file; }
  else {
    const data = zlib.inflateSync(buf);
    original = data.length;
  }
  if (first) console.log("compressed   original reduced  name");
  const red = original ? ((1 - compressed / original) * 100).toFixed(1) : "  0.0";
  console.log(`${String(compressed).padStart(10)} ${String(original).padStart(10)} ${String(red).padStart(6)}%  ${name}`);
}

function decompressOne(file, opts) {
  const stdin = file === "-";
  const buf = stdin ? readStdin() : fs.readFileSync(file);
  const { data, meta } = decompressBuffer(buf);
  if (opts.test) {
    if (opts.verbose && !opts.quiet) process.stderr.write(`${stdin ? "<stdin>" : file}: OK\n`);
    return;
  }
  if (opts.stdout || stdin) writeAll(1, data);
  else {
    const out = outNameDecompress(file, opts, meta);
    maybeWriteFile(out, data, opts);
    if (!opts.keep) fs.unlinkSync(file);
    if (opts.verbose) process.stderr.write(`${file} to ${out} \n`);
  }
}

function main() {
  let opts;
  try { opts = parse(process.argv.slice(2)); }
  catch (e) { process.stderr.write(`${path.basename(process.argv[1])}: ${e.message}\n`); process.exit(1); }
  const files = collectFiles(opts.files, opts.recursive, opts);
  let listFirst = true;
  for (const f of files) {
    try {
      if (opts.list) { listOne(f, opts, listFirst); listFirst = false; }
      else if (opts.decompress) decompressOne(f, opts);
      else compressOne(f, opts);
    } catch (e) {
      warn(opts, `${f}: ${e.message}`);
      process.exitCode = 1;
    }
  }
}

main();
