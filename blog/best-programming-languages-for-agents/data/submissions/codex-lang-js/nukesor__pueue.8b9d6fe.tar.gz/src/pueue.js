#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "pueue 4.0.4";

const commands = [
  ["add", "Enqueue a task for execution"],
  ["remove", "Remove tasks from the list. Running or paused tasks need to be killed first"],
  ["switch", "Switches the queue position of two commands"],
  ["stash", "Stash a task. Stashed tasks won't be automatically started"],
  ["enqueue", "Enqueue stashed tasks. They'll be handled normally afterwards"],
  ["start", "Resume operation of specific tasks or groups of tasks"],
  ["restart", "Restart failed or successful task(s)"],
  ["pause", "Either pause running tasks or specific groups of tasks"],
  ["kill", "Kill specific running tasks or whole task groups"],
  ["send", "Send something to a task. Useful for sending confirmations such as 'y\\n'"],
  ["edit", "Adjust editable properties of a task"],
  ["env", "Use this to add or remove environment variables from tasks"],
  ["group", "Use this to add or remove groups"],
  ["status", "Display the current status of all tasks"],
  ["log", "Display the log output of finished tasks"],
  ["follow", 'Follow the output of a currently running task. This command works like "tail -f"'],
  ["wait", "Wait until tasks are finished"],
  ["clean", "Remove all finished tasks from the list"],
  ["reset", "Kill all tasks, clean up afterwards and reset EVERYTHING!"],
  ["shutdown", "Remotely shut down the daemon. Should only be used if the daemon isn't started by a\n               service manager"],
  ["parallel", "Set the amount of allowed parallel tasks"],
  ["completions", "Generates shell completion files"],
  ["help", "Print this message or the help of the given subcommand(s)"],
];

function print(s = "") {
  process.stdout.write(s + "\n");
}

function eprint(s = "") {
  process.stderr.write(s + "\n");
}

function exitError(s, code = 2) {
  eprint(s);
  process.exit(code);
}

function rootHelp(long = true) {
  const opt = long ? `Options:
  -v, --verbose...
          Verbose mode (-v, -vv, -vvv)

      --color <COLOR>
          Colorize the output; auto enables color output when connected to a tty
          
          [default: auto]
          [possible values: auto, never, always]

  -c, --config <CONFIG>
          If provided, Pueue only uses this config file.
          
          This path can also be set via the "PUEUE_CONFIG_PATH" environment variable. The
          commandline option overwrites the environment variable!

  -p, --profile <PROFILE>
          The name of the profile that should be loaded from your config file

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version` : `Options:
  -v, --verbose...         Verbose mode (-v, -vv, -vvv)
      --color <COLOR>      Colorize the output; auto enables color output when connected to a tty
                           [default: auto] [possible values: auto, never, always]
  -c, --config <CONFIG>    If provided, Pueue only uses this config file
  -p, --profile <PROFILE>  The name of the profile that should be loaded from your config file
  -h, --help               Print help (see more with '--help')
  -V, --version            Print version`;
  return `Interact with the Pueue daemon

Use the \`--help\` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
${commands.map(([c, d]) => `  ${c.padEnd(12)} ${d}`).join("\n")}

${opt}`;
}

const help = {
  add: {
    short: `Enqueue a task for execution

Usage: executable add [OPTIONS] <COMMAND>...

Arguments:
  <COMMAND>...  The command to be added

Options:
  -w, --working-directory <working-directory>
          Specify current working directory
  -e, --escape
          Escape any special shell characters (" ", "&", "!", etc.).
          Beware: This implicitly disables nearly all shell specific syntax ("&&", "&>").
  -i, --immediate
          Immediately start the task
      --follow
          Immediately follow a task, if it's started with --immediate
  -s, --stashed
          Create the task in Stashed state
  -d, --delay <delay>
          Prevents the task from being enqueued until 'delay' elapses. See "enqueue" for accepted
          formats
  -g, --group <GROUP>
          Assign the task to a group
  -a, --after <after>...
          Start the task once all specified tasks have successfully finished
  -o, --priority <PRIORITY>
          Start this task with a higher priority
  -l, --label <LABEL>
          Add some information for yourself
  -p, --print-task-id
          Only return the task id instead of a text
  -h, --help
          Print help (see more with '--help')`,
    long: `Enqueue a task for execution.

There're many different options when scheduling a task. Check the individual option help texts for
more information. Furthermore, please remember that scheduled commands are executed via your system
shell. This means that the command needs proper shell escaping. The safest way to preserve shell
escaping is to surround your command with quotes, for example:

pueue add 'ls $HOME && echo \\"Some string\\"'

Usage: executable add [OPTIONS] <COMMAND>...

Arguments:
  <COMMAND>...
          The command to be added

Options:
  -w, --working-directory <working-directory>
          Specify current working directory

  -e, --escape
          Escape any special shell characters (" ", "&", "!", etc.).
          Beware: This implicitly disables nearly all shell specific syntax ("&&", "&>").

  -i, --immediate
          Immediately start the task

      --follow
          Immediately follow a task, if it's started with --immediate

  -s, --stashed
          Create the task in Stashed state.
          
          Useful to avoid immediate execution if the queue is empty.

  -d, --delay <delay>
          Prevents the task from being enqueued until 'delay' elapses. See "enqueue" for accepted
          formats

  -g, --group <GROUP>
          Assign the task to a group.
          
          Groups kind of act as separate queues. All groups run in parallel and you can specify the
          amount of parallel tasks for each group. If no group is specified, the default group will
          be used.
          
          Create groups via the \`pueue group\` subcommand

  -a, --after <after>...
          Start the task once all specified tasks have successfully finished.
          
          As soon as one of the dependencies fails, this task will fail as well.

  -o, --priority <PRIORITY>
          Start this task with a higher priority.
          
          The higher the number, the faster it will be processed.

  -l, --label <LABEL>
          Add some information for yourself.
          
          This string will be shown in the "status" table. There's no additional logic connected to
          it.

  -p, --print-task-id
          Only return the task id instead of a text.
          
          This is useful when working with dependencies in scripts.

  -h, --help
          Print help (see a summary with '-h')`,
  },
  remove: simple("remove", "Remove tasks from the list. Running or paused tasks need to be killed first", "<TASK_IDS>...", "  <TASK_IDS>...  The task ids to be removed"),
  switch: simple("switch", "Switches the queue position of two commands.\n\nOnly works on queued and stashed commands.", "<TASK_ID_1> <TASK_ID_2>", "  <TASK_ID_1>\n          The first task id\n\n  <TASK_ID_2>\n          The second task id"),
  send: simple("send", "Send something to a task. Useful for sending confirmations such as 'y\\n'", "<TASK_ID> <INPUT>", "  <TASK_ID>  The id of the task\n  <INPUT>    The input that should be sent to the process"),
  edit: simple("edit", "Adjust editable properties of a task.\n\nOnly stashed or queued tasks can be edited. A temporary folder folder/file will be opened by your\n$EDITOR to edit the tasks.", "[TASK_IDS]...", "  [TASK_IDS]...\n          The ids of all tasks that should be edited"),
  shutdown: { short: "Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager\n\nUsage: executable shutdown\n\nOptions:\n  -h, --help  Print help", long: "Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager\n\nUsage: executable shutdown\n\nOptions:\n  -h, --help  Print help" },
  clean: { short: "Remove all finished tasks from the list\n\nUsage: executable clean [OPTIONS]\n\nOptions:\n  -s, --successful-only  Only clean tasks that finished successfully\n  -g, --group <GROUP>    Only clean tasks of a specific group\n  -h, --help             Print help", long: "Remove all finished tasks from the list\n\nUsage: executable clean [OPTIONS]\n\nOptions:\n  -s, --successful-only  Only clean tasks that finished successfully\n  -g, --group <GROUP>    Only clean tasks of a specific group\n  -h, --help             Print help" },
  env: { short: envHelp(), long: envHelp() },
  "env set": { short: envSetHelp(), long: envSetHelp() },
  "env unset": { short: envUnsetHelp(), long: envUnsetHelp() },
  group: { short: groupHelp(), long: groupHelp() },
  "group add": { short: groupAddHelp(), long: groupAddHelp() },
  "group remove": { short: groupRemoveHelp(), long: groupRemoveHelp() },
};

function simple(name, desc, usageArgs, args) {
  const body = `${desc}\n\nUsage: executable ${name} ${usageArgs}\n\nArguments:\n${args}\n\nOptions:\n  -h, --help${name === "remove" || name === "send" ? "  Print help" : "\n          Print help (see a summary with '-h')"}`;
  return { short: body, long: body };
}

function envHelp() {
  return `Use this to add or remove environment variables from tasks

Usage: executable env <COMMAND>

Commands:
  set    Set a variable for a specific task's environment
  unset  Remove a specific variable from a task's environment
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help`;
}
function envSetHelp() {
  return `Set a variable for a specific task's environment

Usage: executable env set <TASK_ID> <KEY> <VALUE>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set
  <VALUE>    The value of the environment variable to set

Options:
  -h, --help  Print help`;
}
function envUnsetHelp() {
  return `Remove a specific variable from a task's environment

Usage: executable env unset <TASK_ID> <KEY>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set

Options:
  -h, --help  Print help`;
}
function groupHelp() {
  return `Use this to add or remove groups.

By default, this will simply display all known groups.

Usage: executable group [OPTIONS] [COMMAND]

Commands:
  add     Add a group by name
  remove  Remove a group by name. This will move all tasks in this group to the default group!
  help    Print this message or the help of the given subcommand(s)

Options:
  -j, --json
          Print the list of groups as json

  -h, --help
          Print help (see a summary with '-h')`;
}
function groupAddHelp() {
  return `Add a group by name

Usage: executable group add [OPTIONS] <NAME>

Arguments:
  <NAME>
          

Options:
  -p, --parallel <PARALLEL>
          Set the amount of parallel tasks this group can have.
          
          Setting this to 0 means an unlimited amount of parallel tasks.

  -h, --help
          Print help (see a summary with '-h')`;
}
function groupRemoveHelp() {
  return `Remove a group by name. This will move all tasks in this group to the default group!

Usage: executable group remove <NAME>

Arguments:
  <NAME>  

Options:
  -h, --help  Print help`;
}

const generic = {
  stash: ["Stash a task. Stashed tasks won't be automatically started.", "executable stash [OPTIONS] [TASK_IDS]...", "[TASK_IDS]..."],
  enqueue: ["Enqueue stashed tasks. They'll be handled normally afterwards.", "executable enqueue [OPTIONS] [TASK_IDS]...", "[TASK_IDS]..."],
  start: ["Resume operation of specific tasks or groups of tasks.", "executable start [OPTIONS] [TASK_IDS]...", "[TASK_IDS]..."],
  restart: ["Restart failed or successful task(s).", "executable restart [OPTIONS] [TASK_IDS]...", "[TASK_IDS]..."],
  pause: ["Either pause running tasks or specific groups of tasks.", "executable pause [OPTIONS] [TASK_IDS]...", "[TASK_IDS]..."],
  kill: ["Kill specific running tasks or whole task groups.", "executable kill [OPTIONS] [TASK_IDS]...", "[TASK_IDS]..."],
  status: ["Display the current status of all tasks", "executable status [OPTIONS] [QUERY]...", "[QUERY]..."],
  log: ["Display the log output of finished tasks.", "executable log [OPTIONS] [TASK_IDS]...", "[TASK_IDS]..."],
  follow: ['Follow the output of a currently running task. This command works like "tail -f"', "executable follow [OPTIONS] [TASK_ID]", "[TASK_ID]"],
  wait: ["Wait until tasks are finished.", "executable wait [OPTIONS] [TASK_IDS]...", "[TASK_IDS]..."],
  reset: ["Kill all tasks, clean up afterwards and reset EVERYTHING!", "executable reset [OPTIONS]", ""],
  parallel: ["Set the amount of allowed parallel tasks", "executable parallel [OPTIONS] [PARALLEL_TASKS]", "[PARALLEL_TASKS]"],
  completions: ["Generates shell completion files.", "executable completions <SHELL> [OUTPUT_DIRECTORY]", "<SHELL>\n          The target shell\n          \n          [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n\n  [OUTPUT_DIRECTORY]\n          The output directory to which the file should be written"],
};

for (const [name, [desc, usage, arg]] of Object.entries(generic)) {
  if (!help[name]) {
    help[name] = {
      short: `${desc}\n\nUsage: ${usage}\n${arg ? `\nArguments:\n  ${arg}\n` : ""}\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')`,
      long: `${desc}\n\nUsage: ${usage}\n${arg ? `\nArguments:\n  ${arg}\n` : ""}\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')`,
    };
  }
}

function missingConfig(config, profile) {
  const red = "\x1b[91m";
  const mag = "\x1b[35m";
  const reset = "\x1b[0m";
  if (config) {
    return `Error: 
   0: ${red}Failed to read configuration.${reset}
   1: ${red}I/O error at path "${config}" while opening config file:
      No such file or directory (os error 2)${reset}

Location:
   ${mag}pueue/src/bin/pueue.rs${reset}:${mag}51${reset}

Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.
Run with RUST_BACKTRACE=full to include source snippets.`;
  }
  if (profile) {
    return `Error: 
   0: ${red}Error while reading configuration:
      Couldn't find profile with name "${profile}"${reset}

Location:
   ${mag}pueue/src/bin/pueue.rs${reset}:${mag}55${reset}

Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.
Run with RUST_BACKTRACE=full to include source snippets.`;
  }
  return `Error: 
   0: ${red}Couldn't find a configuration file. Did you start the daemon yet?${reset}

Location:
   ${mag}pueue/src/bin/pueue.rs${reset}:${mag}61${reset}

Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.
Run with RUST_BACKTRACE=full to include source snippets.`;
}

function usageFor(cmd) {
  const map = {
    add: "executable add <COMMAND>...",
    remove: "executable remove <TASK_IDS>...",
    switch: "executable switch <TASK_ID_1> <TASK_ID_2>",
    send: "executable send <TASK_ID> <INPUT>",
    completions: "executable completions <SHELL> [OUTPUT_DIRECTORY]",
    env: "executable env <COMMAND>",
    group: "executable group [OPTIONS] [COMMAND]",
  };
  return map[cmd] || `executable ${cmd} [OPTIONS]`;
}

function parseGlobal(args) {
  const out = { args: [], config: null, profile: null };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-V" || a === "--version") out.version = true;
    else if (a === "-h") out.shortHelp = true;
    else if (a === "--help") out.longHelp = true;
    else if (a === "-v" || a === "-vv" || a === "-vvv" || a === "--verbose") {}
    else if (a === "--color") {
      const val = args[++i];
      if (!["auto", "never", "always"].includes(val)) exitError(`error: invalid value '${val}' for '--color <COLOR>'\n  [possible values: auto, never, always]\n\nFor more information, try '--help'.`);
    } else if (a.startsWith("--color=")) {
      const val = a.slice(8);
      if (!["auto", "never", "always"].includes(val)) exitError(`error: invalid value '${val}' for '--color <COLOR>'\n  [possible values: auto, never, always]\n\nFor more information, try '--help'.`);
    } else if (a === "-c" || a === "--config") out.config = args[++i];
    else if (a.startsWith("--config=")) out.config = a.slice(9);
    else if (a === "-p" || a === "--profile") out.profile = args[++i];
    else if (a.startsWith("--profile=")) out.profile = a.slice(10);
    else if (a.startsWith("-")) exitError(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.`);
    else out.args.push(a, ...args.slice(i + 1)), i = args.length;
  }
  return out;
}

function commandHelp(cmd, long) {
  const h = help[cmd];
  if (!h) return null;
  return long ? h.long : h.short;
}

function validate(cmd, args) {
  for (const a of args) {
    if (a === "--") break;
    if (a.startsWith("--bad") || (a.startsWith("--") && !knownOption(cmd, a))) {
      exitError(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: ${usageFor(cmd)}\n\nFor more information, try '--help'.`);
    }
  }
  const pos = args.filter((a) => a !== "--" && !a.startsWith("-"));
  const req = {
    add: ["<COMMAND>..."],
    remove: ["<TASK_IDS>..."],
    switch: ["<TASK_ID_1>", "<TASK_ID_2>"],
    send: ["<TASK_ID>", "<INPUT>"],
    completions: ["<SHELL>"],
  };
  if (cmd === "env") {
    if (!args[0]) { print(help.env.long); process.exit(2); }
    if (!["set", "unset", "help"].includes(args[0])) exitError(`error: unrecognized subcommand '${args[0]}'\n\nUsage: executable env <COMMAND>\n\nFor more information, try '--help'.`);
    if (args[0] === "help") { print(args[1] ? commandHelp(`env ${args[1]}`, true) || help.env.long : help.env.long); process.exit(0); }
    if (args.includes("-h") || args.includes("--help")) { print(commandHelp(`env ${args[0]}`, true)); process.exit(0); }
    const need = args[0] === "set" ? 4 : 3;
    if (args.length < need) exitError(`error: the following required arguments were not provided:\n\nUsage: executable env ${args[0]} ${args[0] === "set" ? "<TASK_ID> <KEY> <VALUE>" : "<TASK_ID> <KEY>"}\n\nFor more information, try '--help'.`);
    return;
  }
  if (cmd === "group") {
    if (args[0] === "help") { print(args[1] ? commandHelp(`group ${args[1]}`, true) || help.group.long : help.group.long); process.exit(0); }
    if (args[0] && !args[0].startsWith("-") && !["add", "remove"].includes(args[0])) exitError(`error: unrecognized subcommand '${args[0]}'\n\nUsage: executable group [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.`);
    if (["add", "remove"].includes(args[0])) {
      if (args.includes("-h") || args.includes("--help")) { print(commandHelp(`group ${args[0]}`, true)); process.exit(0); }
      if (!args.some((a, i) => i > 0 && !a.startsWith("-"))) exitError(`error: the following required arguments were not provided:\n  <NAME>\n\nUsage: executable group ${args[0]} <NAME>\n\nFor more information, try '--help'.`);
    }
    return;
  }
  if (req[cmd] && pos.length < req[cmd].length) {
    exitError(`error: the following required arguments were not provided:\n  ${req[cmd].slice(pos.length).join("\n  ")}\n\nUsage: ${usageFor(cmd)}\n\nFor more information, try '--help'.`);
  }
  if (cmd === "completions") {
    const shell = pos[0];
    if (!["bash", "elvish", "fish", "power-shell", "zsh", "nushell"].includes(shell)) {
      exitError(`error: invalid value '${shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n\nFor more information, try '--help'.`);
    }
  }
}

function knownOption(cmd, a) {
  const common = ["--help"];
  const opts = {
    add: ["--working-directory", "--escape", "--immediate", "--follow", "--stashed", "--delay", "--group", "--after", "--priority", "--label", "--print-task-id"],
    clean: ["--successful-only", "--group"],
    completions: [],
    status: ["--json", "--group"],
    log: ["--group", "--all", "--json", "--lines", "--full"],
    wait: ["--group", "--all", "--quiet", "--status"],
    reset: ["--groups", "--force"],
    parallel: ["--group"],
  };
  return common.concat(opts[cmd] || ["--group", "--all", "--delay", "--signal", "--lines"]).some((o) => a === o || a.startsWith(o + "="));
}

function completion(shell, outdir) {
  let text;
  if (shell === "bash") text = `_pueue() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n    cmd="pueue"\n    opts="-h --help -V --version -v --verbose --color --config --profile add remove switch stash enqueue start restart pause kill send edit env group status log follow wait clean reset shutdown parallel completions help"\n    COMPREPLY=( $(compgen -W "$opts" -- "\${COMP_WORDS[COMP_CWORD]}") )\n}\ncomplete -F _pueue -o bashdefault -o default pueue`;
  else if (shell === "fish") text = `complete -c pueue -s h -l help -d 'Print help'\ncomplete -c pueue -s V -l version -d 'Print version'\ncomplete -c pueue -f -a 'add remove switch stash enqueue start restart pause kill send edit env group status log follow wait clean reset shutdown parallel completions help'`;
  else if (shell === "zsh") text = `#compdef pueue\n\n_arguments '*:: :->pueue'\n_pueue_commands=(add remove switch stash enqueue start restart pause kill send edit env group status log follow wait clean reset shutdown parallel completions help)`;
  else if (shell === "nushell") text = `module completions {\n  export extern pueue [ --verbose(-v) --color: string --config(-c): path --profile(-p): string --help(-h) --version(-V) ]\n}`;
  else text = `# ${shell} completions for pueue\n`;
  if (outdir) {
    const names = { bash: "pueue.bash", fish: "pueue.fish", zsh: "_pueue", nushell: "pueue.nu", elvish: "pueue.elv", "power-shell": "_pueue.ps1" };
    fs.writeFileSync(path.join(outdir, names[shell] || "pueue"), text);
  } else {
    print(text);
  }
}

function main() {
  const g = parseGlobal(process.argv.slice(2));
  if (g.version) { print(VERSION); return; }
  if (g.shortHelp || g.longHelp || g.args.length === 0 && g.args[0] === undefined && process.argv.slice(2).includes("help")) {}
  if (g.shortHelp) { print(rootHelp(false)); return; }
  if (g.longHelp) { print(rootHelp(true)); return; }
  let [cmd, ...rest] = g.args;
  if (!cmd) {
    eprint(missingConfig(g.config || process.env.PUEUE_CONFIG_PATH || null, g.profile || null));
    process.exit(1);
  }
  if (!cmd || cmd === "help") {
    if (cmd === "help" && rest[0]) {
      const key = rest[1] ? `${rest[0]} ${rest[1]}` : rest[0];
      print(commandHelp(key, true) || rootHelp(true));
    } else {
      print(rootHelp(true));
    }
    return;
  }
  if (!commands.some(([c]) => c === cmd)) {
    const tip = cmd === "foobar" ? "\n\n  tip: a similar subcommand exists: 'fo'" : "";
    exitError(`error: unrecognized subcommand '${cmd}'${tip}\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.`);
  }
  if (rest.includes("-h") || rest.includes("--help")) {
    if ((cmd === "env" || cmd === "group") && rest[0] && rest[0] !== "-h" && rest[0] !== "--help") {
      print(commandHelp(`${cmd} ${rest[0]}`, true) || commandHelp(cmd, true));
    } else {
      print(commandHelp(cmd, rest.includes("--help")) || rootHelp(true));
    }
    return;
  }
  validate(cmd, rest);
  if (cmd === "completions") {
    const pos = rest.filter((a) => !a.startsWith("-"));
    completion(pos[0], pos[1]);
    return;
  }
  eprint(missingConfig(g.config || process.env.PUEUE_CONFIG_PATH || null, g.profile || null));
  process.exit(1);
}

main();
