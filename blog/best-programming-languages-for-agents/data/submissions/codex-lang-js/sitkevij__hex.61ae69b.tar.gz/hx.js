#!/usr/bin/env node
'use strict';

const fs = require('fs');

const HELP = `Futuristic take on hexdump, made in Rust.


Usage: executable [OPTIONS] [INPUTFILE]

Arguments:
  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin

Options:
  -c, --cols <columns>        Set column length
  -l, --len <len>             Set <len> bytes to read
  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]
  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]
  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]
  -u, --func <func_length>    Set function wave length
  -p, --places <func_places>  Set function wave output decimal places
  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]
  -h, --help                  Print help
  -V, --version               Print version`;

function die(msg, code = 1) {
  process.stderr.write(msg + '\n');
  process.exit(code);
}

function clapUnexpected(arg) {
  die(`error: unexpected argument '${arg}' found

  tip: to pass '${arg}' as a value, use '-- ${arg}'

Usage: executable [OPTIONS] [INPUTFILE]

For more information, try '--help'.`, 2);
}

function invalidValue(opt, name, val, values) {
  die(`error: invalid value '${val}' for '--${name} <${opt}>'
  [possible values: ${values.join(', ')}]

For more information, try '--help'.`, 2);
}

function parseIntOpt(flag, long, val) {
  if (val === undefined || val.startsWith('-') || !/^\d+$/.test(val)) {
    if (val && val.startsWith('-')) clapUnexpected(val);
    const kind = val === undefined || val === '' ? 'Empty' : 'InvalidDigit';
    process.stderr.write(`${flag}, --${long} <integer> expected. ParseIntError { kind: ${kind} }\n`);
    die('error: invalid digit found in string', 1);
  }
  return Number(val);
}

function parseArgs(argv) {
  const expanded = [];
  for (const a of argv) {
    const m = a.match(/^-([clfupta r])(.+)$/);
    if (m && m[1] !== 'h' && m[1] !== 'V') {
      expanded.push('-' + m[1], m[2]);
    } else {
      expanded.push(a);
    }
  }
  argv = expanded;
  const o = { cols: 10, len: null, format: 'x', color: null, array: null, func: null, places: 4, prefix: true, input: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = () => argv[++i];
    if (a === '-h' || a === '--help') { process.stdout.write(HELP + '\n'); process.exit(0); }
    if (a === '-V' || a === '--version') { process.stdout.write('hx 0.7.0\n'); process.exit(0); }
    if (a === '-c' || a === '--cols') o.cols = parseIntOpt('-c', 'cols', next());
    else if (a.startsWith('--cols=')) o.cols = parseIntOpt('-c', 'cols', a.slice(7));
    else if (a === '-l' || a === '--len') o.len = parseIntOpt('-l', 'len', next());
    else if (a.startsWith('--len=')) o.len = parseIntOpt('-l', 'len', a.slice(6));
    else if (a === '-u' || a === '--func') o.func = parseIntOpt('-u', 'func', next());
    else if (a.startsWith('--func=')) o.func = parseIntOpt('-u', 'func', a.slice(7));
    else if (a === '-p' || a === '--places') o.places = parseIntOpt('-p', 'places', next());
    else if (a.startsWith('--places=')) o.places = parseIntOpt('-p', 'places', a.slice(9));
    else if (a === '-f' || a === '--format') {
      o.format = next();
      if (!['o', 'x', 'X', 'b'].includes(o.format)) invalidValue('format', 'format', o.format, ['o', 'x', 'X', 'b']);
    } else if (a.startsWith('--format=')) {
      o.format = a.slice(9);
      if (!['o', 'x', 'X', 'b'].includes(o.format)) invalidValue('format', 'format', o.format, ['o', 'x', 'X', 'b']);
    } else if (a === '-a' || a === '--array') {
      o.array = next();
      if (!['r', 'c', 'g', 'p', 'k', 'j', 's', 'f'].includes(o.array)) invalidValue('array_format', 'array', o.array, ['r', 'c', 'g', 'p', 'k', 'j', 's', 'f']);
    } else if (a.startsWith('--array=')) {
      o.array = a.slice(8);
      if (!['r', 'c', 'g', 'p', 'k', 'j', 's', 'f'].includes(o.array)) invalidValue('array_format', 'array', o.array, ['r', 'c', 'g', 'p', 'k', 'j', 's', 'f']);
    } else if (a === '-t' || a === '--color') {
      const v = next();
      if (!['0', '1'].includes(v)) invalidValue('color', 'color', v, ['0', '1']);
      o.color = v === '1';
    } else if (a.startsWith('--color=')) {
      const v = a.slice(8);
      if (!['0', '1'].includes(v)) invalidValue('color', 'color', v, ['0', '1']);
      o.color = v === '1';
    } else if (a === '-r' || a === '--prefix') {
      const v = next();
      if (!['0', '1'].includes(v)) invalidValue('prefix', 'prefix', v, ['0', '1']);
      o.prefix = v === '1';
    } else if (a.startsWith('--prefix=')) {
      const v = a.slice(9);
      if (!['0', '1'].includes(v)) invalidValue('prefix', 'prefix', v, ['0', '1']);
      o.prefix = v === '1';
    } else if (a.startsWith('-')) {
      clapUnexpected(a);
    } else if (o.input === null) {
      o.input = a;
    } else {
      clapUnexpected(a);
    }
  }
  if (o.color === null) o.color = process.env.NO_COLOR === undefined;
  if (o.cols <= 0) o.cols = 1;
  return o;
}

function readInput(o) {
  let b;
  if (o.input) {
    try { b = fs.readFileSync(o.input); }
    catch (e) {
      if (e.code === 'ENOENT') die('error: No such file or directory (os error 2)', 1);
      if (e.code === 'EACCES') die('error: Permission denied (os error 13)', 1);
      die(`error: ${e.message}`, 1);
    }
  } else {
    try { b = fs.readFileSync(0); }
    catch { b = Buffer.alloc(0); }
  }
  if (o.len !== null && o.len > 0) b = b.subarray(0, o.len);
  return b;
}

function byteToken(byte, fmt, prefix) {
  if (fmt === 'x' || fmt === 'X') {
    const s = byte.toString(16).padStart(2, '0');
    return (prefix ? '0x' : '') + (fmt === 'X' ? s.toUpperCase() : s);
  }
  if (fmt === 'o') return (prefix ? '0o' : '') + byte.toString(8).padStart(4, '0');
  return (prefix ? '0b' : '') + byte.toString(2).padStart(8, '0');
}

function cellWidth(fmt, prefix) {
  return byteToken(0, fmt, prefix).length + 1;
}

function colorize(s, byte, on) {
  return on ? `\x1b[38;5;${byte}m${s}\x1b[0m` : s;
}

function visible(byte) {
  return byte >= 0x20 && byte <= 0x7e ? String.fromCharCode(byte) : '.';
}

function dump(o, bytes) {
  const cw = cellWidth(o.format, o.prefix);
  const out = [];
  const rows = Math.floor(bytes.length / o.cols) + 1;
  for (let row = 0; row < rows; row++) {
    const off = row * o.cols;
    const chunk = bytes.subarray(off, Math.min(off + o.cols, bytes.length));
    let line = '0x' + off.toString(16).padStart(6, '0') + ': ';
    for (let i = 0; i < o.cols; i++) {
      if (i < chunk.length) {
        const tok = byteToken(chunk[i], o.format, o.prefix);
        line += colorize(tok, chunk[i], o.color) + ' ';
      } else {
        line += ' '.repeat(cw);
      }
    }
    for (const b of chunk) line += colorize(visible(b), b, o.color);
    out.push(line);
  }
  out.push('   bytes: ' + bytes.length);
  process.stdout.write(out.join('\n') + '\n');
}

function hex(byte) {
  return '0x' + byte.toString(16).padStart(2, '0');
}

function arrayBytes(kind, bytes) {
  if (!['r', 'c'].includes(kind) && bytes.length && bytes[bytes.length - 1] === 10) {
    return bytes.subarray(0, bytes.length - 1);
  }
  return bytes;
}

function formattedList(bytes, sep, trailingEveryLine) {
  const parts = [];
  for (let i = 0; i < bytes.length; i += 10) {
    const chunk = Array.from(bytes.subarray(i, i + 10), hex).join(sep);
    const tail = (i + 10 < bytes.length || trailingEveryLine) ? sep.trimEnd() + ' ' : '';
    parts.push('    ' + chunk + tail);
  }
  if (parts.length === 0) parts.push('    ');
  return parts.join('\n');
}

function arrayOut(kind, original) {
  const bytes = arrayBytes(kind, original);
  const n = bytes.length;
  let s = '';
  if (kind === 'r') s = `let ARRAY: [u8; ${n}] = [\n${formattedList(bytes, ', ', false)}\n];`;
  else if (kind === 'c') s = `unsigned char ARRAY[${n}] = {\n${formattedList(bytes, ', ', false)}\n};`;
  else if (kind === 'g') s = `a := [${n}]byte{\n${formattedList(bytes, ', ', true)}\n}`;
  else if (kind === 'p') s = `a = [\n${formattedList(bytes, ', ', false)}\n]`;
  else if (kind === 'k') s = `val a = byteArrayOf(\n${formattedList(bytes, ', ', false)}\n)`;
  else if (kind === 'j') s = `byte[] a = new byte[]{\n${formattedList(bytes, ', ', false)}\n};`;
  else if (kind === 's') s = `let a: [UInt8] = [\n${formattedList(bytes, ', ', false)}\n]`;
  else if (kind === 'f') {
    const lines = [];
    for (let i = 0; i < n; i += 10) {
      const chunk = Array.from(bytes.subarray(i, i + 10), b => hex(b) + 'uy').join('; ');
      const tail = i + 10 < n ? '; ' : '';
      lines.push('    ' + chunk + tail);
    }
    if (!lines.length) lines.push('    ');
    s = `let a = [|\n${lines.join('\n')}\n|]`;
  }
  process.stdout.write(s + '\n');
}

function funcOut(len, places) {
  let s = '';
  for (let i = 0; i < len; i++) {
    s += Math.sin(i * Math.PI / (2 * len)).toFixed(places) + ',';
  }
  process.stdout.write(s + (len ? '\n' : ''));
}

const opts = parseArgs(process.argv.slice(2));
if (opts.func !== null) {
  funcOut(opts.func, opts.places);
} else {
  const bytes = readInput(opts);
  if (opts.array) arrayOut(opts.array, bytes);
  else dump(opts, bytes);
}
