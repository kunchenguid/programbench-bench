#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const VERSION = `calcurse 4.8.2 -- text-based organizer

Copyright (c) 2004-2023 calcurse Development Team.
This is free software; see the source for copying conditions.`;

const HELP = `Usage:
calcurse [-D <directory>] [-C <directory>] [-c <calendar file>]
calcurse -Q [--from <date>] [--to <date>] [--days <number>]
calcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]
calcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon

Operations in command line mode:
  -Q, --query   Print items in a given query range
  -G, --grep    Grep items from the data files
  -P, --purge   Read items and write them back
Query short forms:
-a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>

Note that filter, format and day-range options affect input or output:
  --filter-*              Filter items loaded by -Q, -G, -P and -x
  --format-*              Rewrite output from -Q, -G and --dump-imported
  --from <date>           Limit day range of -Q.
  --to <date>             Limit day range of -Q.
  --days <number>         Limit day range of -Q.

  --limit, -l <number>    Limit number of query results
  --search, -S <regexp>   Match regular expression in queries
Consult the man page for details.

Miscellaneous:
  -c, --calendar <file>   The calendar data file to use
  -C, --confdir <dir>     The configuration directory to use
  --daemon                Run notification daemon in the background
  -D, --datadir <dir>     The data directory to use
  -g, --gc                Run the garbage collector
  -h, --help              Show this help text
  -i, --import <file>     Import iCal data from file
  -q, --quiet             Suppress import/export result message
  --read-only             Do not save configuration or data files
  --status                Display status of running instances
  -v, --version           Show version information
  -x, --export[<format>]  Export to stdout in ical (default) or pcal format

For more information, type '?' from within calcurse, or read the manpage.
Submit feature requests and suggestions to <misc@calcurse.org>.
Submit bug reports to <bugs@calcurse.org>.`;

function pad(n) { return String(n).padStart(2, '0'); }
function ymd(d) { return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; }
function mdY(d) { return `${pad(d.getMonth()+1)}/${pad(d.getDate())}/${d.getFullYear()}`; }
function outDate(d) { return `${pad(d.getMonth()+1)}/${pad(d.getDate())}/${String(d.getFullYear()).slice(-2)}`; }
function hm(d) { return `${pad(d.getHours())}:${pad(d.getMinutes())}`; }
function startOfDay(d) { return new Date(d.getFullYear(), d.getMonth(), d.getDate()); }
function addDays(d,n) { const x = new Date(d); x.setDate(x.getDate()+n); return x; }
function addMonths(d,n) { const x = new Date(d); x.setMonth(x.getMonth()+n); return x; }
function addYears(d,n) { const x = new Date(d); x.setFullYear(x.getFullYear()+n); return x; }
function cmpDay(a,b) { return ymd(a).localeCompare(ymd(b)); }
function sha(s) { return crypto.createHash('sha1').update(s || '').digest('hex'); }
function esc(s) { return String(s||'').replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;'); }
function unesc(s) { return String(s||'').replace(/\\n/g,'\n').replace(/\\([,;\\])/g,'$1'); }

function parseArgs(argv) {
  const o = { args: [], inputFmt: 1, op: null, filters: {}, formats: {}, quiet: false };
  for (let i=0;i<argv.length;i++) {
    let a = argv[i];
    const need = () => argv[++i];
    if (a === '-h' || a === '--help') o.op = 'help';
    else if (a === '-v' || a === '--version') o.op = 'version';
    else if (a === '--status') o.op = 'status';
    else if (a === '-Q' || a === '--query') o.op = 'query';
    else if (a === '-G' || a === '--grep') o.op = 'grep';
    else if (a === '-P' || a === '--purge') o.op = 'purge';
    else if (a === '-g' || a === '--gc') o.op = 'gc';
    else if (a === '--daemon') o.op = 'daemon';
    else if (a === '-a' || a === '--appointment') { o.op = 'query'; o.filters.type = 'cal'; o.from = 'today'; o.to = 'today'; }
    else if (a === '-n' || a === '--next') { o.op = 'next'; o.filters.type = 'apt,recur-apt'; }
    else if (a === '-d' || a === '--day') { const v=need(); o.op='query'; o.filters.type='cal'; if (/^-?\d+$/.test(v)) o.days=Number(v); else { o.from=v; o.to=v; } }
    else if (a.startsWith('-r') && a !== '--read-only') { o.op='query'; o.filters.type='cal'; o.days = a.length>2 ? Number(a.slice(2)) : (argv[i+1] && !argv[i+1].startsWith('-') ? Number(need()) : 1); }
    else if (a.startsWith('--range')) { o.op='query'; o.filters.type='cal'; const p=a.split('=')[1]; o.days = p ? Number(p) : (argv[i+1] && !argv[i+1].startsWith('-') ? Number(need()) : 1); }
    else if (a.startsWith('-s')) { o.op='query'; o.filters.type='cal'; o.from = a.length>2 ? a.slice(2) : (argv[i+1] && !argv[i+1].startsWith('-') ? need() : 'today'); }
    else if (a.startsWith('--startday')) { o.op='query'; o.filters.type='cal'; o.from = a.includes('=') ? a.split('=')[1] : (argv[i+1] && !argv[i+1].startsWith('-') ? need() : 'today'); }
    else if (a.startsWith('-t')) { o.op='query'; o.filters.type='todo'; const v=a.length>2?a.slice(2):(argv[i+1] && !argv[i+1].startsWith('-') ? need() : null); if (v!=null) { o.filters.priority=Number(v); if (Number(v)===0) o.filters.completed=true; else o.filters.uncompleted=true; } }
    else if (a.startsWith('--todo')) { o.op='query'; o.filters.type='todo'; const v=a.includes('=')?a.split('=')[1]:(argv[i+1] && !argv[i+1].startsWith('-') ? need() : null); if (v!=null) o.filters.priority=Number(v); }
    else if (a === '-i' || a === '--import') { o.op='import'; o.importFile=need(); }
    else if (a.startsWith('-x')) { o.op='export'; o.exportFmt = a.length>2 ? a.slice(2) : (argv[i+1] && !argv[i+1].startsWith('-') ? need() : 'ical'); }
    else if (a.startsWith('--export')) { o.op='export'; o.exportFmt = a.includes('=') ? a.split('=')[1] : (argv[i+1] && !argv[i+1].startsWith('-') ? need() : 'ical'); }
    else if (a === '-D' || a === '--datadir') o.datadir = need();
    else if (a === '-C' || a === '--confdir') o.confdir = need();
    else if (a === '-c' || a === '--calendar') o.calendar = need();
    else if (a === '-q' || a === '--quiet') o.quiet = true;
    else if (a === '--read-only') o.readOnly = true;
    else if (a === '--from') o.from = need();
    else if (a === '--to') o.to = need();
    else if (a === '--days') o.days = Number(need());
    else if (a === '--input-datefmt') o.inputFmt = Number(need());
    else if (a === '--output-datefmt') o.outputFmt = need();
    else if (a === '-l' || a === '--limit') o.limit = Number(need());
    else if (a === '-S' || a === '--search' || a === '--filter-pattern') o.filters.pattern = need();
    else if (a === '--filter-type') o.filters.type = need();
    else if (a === '--filter-priority') o.filters.priority = Number(need());
    else if (a === '--filter-completed') o.filters.completed = true;
    else if (a === '--filter-uncompleted') o.filters.uncompleted = true;
    else if (a === '--filter-invert') o.filters.invert = true;
    else if (a.startsWith('--filter-')) o.filters[a.slice(9)] = need();
    else if (a.startsWith('--format-')) o.formats[a.slice(9)] = need();
    else if (a === '--dump-imported') o.dumpImported = true;
    else if (a === '--export-uid') o.exportUid = true;
    else if (a.startsWith('-')) { console.error(`./executable: unrecognized option '${a}'\n${HELP.split('\n').slice(0,5).join('\n')}\nTry \`calcurse -h' for more information.`); process.exit(1); }
    else o.args.push(a);
  }
  return o;
}

function dirs(o) {
  const home = process.env.HOME || '.';
  let datadir = o.datadir || (fs.existsSync(path.join(home,'.calcurse')) ? path.join(home,'.calcurse') : path.join(home,'.local/share/calcurse'));
  return { datadir, aptFile: o.calendar || path.join(datadir,'apts'), todoFile: path.join(datadir,'todo'), notesDir: path.join(datadir,'notes') };
}

function parseDate(s, fmt=1) {
  if (!s) return startOfDay(new Date());
  s = String(s).toLowerCase();
  const today = startOfDay(new Date());
  if (s === 'today' || s === 'now') return today;
  if (s === 'tomorrow') return addDays(today,1);
  if (s === 'yesterday') return addDays(today,-1);
  const w = ['sun','mon','tue','wed','thu','fri','sat'].indexOf(s.slice(0,3));
  if (w >= 0) { let diff = (w - today.getDay() + 7) % 7; return addDays(today,diff); }
  const m = s.match(/^(\d{1,4})[-\/](\d{1,2})[-\/](\d{1,4})(?:\s+(\d{1,2}):(\d{2}))?$/);
  if (!m) throw new Error(`invalid date: ${s}`);
  let y, mo, d;
  if (fmt === 4 || m[1].length === 4) { y=+m[1]; mo=+m[2]; d=+m[3]; }
  else if (fmt === 2) { d=+m[1]; mo=+m[2]; y=+m[3]; }
  else if (fmt === 3) { y=+m[1]; mo=+m[2]; d=+m[3]; }
  else { mo=+m[1]; d=+m[2]; y=+m[3]; }
  if (y < 100) y += 2000;
  return new Date(y, mo-1, d, +(m[4]||0), +(m[5]||0));
}

function parseCalDate(s) {
  const m = s.match(/(\d{2})\/(\d{2})\/(\d{4})(?: @ (\d{2}):(\d{2}))?/);
  return new Date(+m[3], +m[1]-1, +m[2], +(m[4]||0), +(m[5]||0));
}

function load(o) {
  const d = dirs(o), items = [];
  if (fs.existsSync(d.todoFile)) for (const line of fs.readFileSync(d.todoFile,'utf8').split(/\n/)) {
    if (!line.trim()) continue;
    const m = line.match(/^\[(-?)(\d+)\](?:>([0-9a-f]+))?\s?(.*)$/);
    if (m) items.push({ kind:'todo', priority:+m[2], completed:!!m[1], note:m[3]||'', msg:m[4]||'', raw:line });
  }
  if (fs.existsSync(d.aptFile)) for (const line of fs.readFileSync(d.aptFile,'utf8').split(/\n/)) {
    if (!line.trim()) continue;
    let m = line.match(/^(\d{2}\/\d{2}\/\d{4}) @ (\d{2}:\d{2}) -> (\d{2}\/\d{2}\/\d{4}) @ (\d{2}:\d{2})(?: \{([^}]+)\})?(?:>([0-9a-f]+))? ?\|(.*)$/);
    if (m) { items.push({ kind:m[5]?'recur-apt':'apt', start:parseCalDate(`${m[1]} @ ${m[2]}`), end:parseCalDate(`${m[3]} @ ${m[4]}`), recur:m[5]||'', note:m[6]||'', msg:m[7]||'', raw:line }); continue; }
    m = line.match(/^(\d{2}\/\d{2}\/\d{4}) \[(\d+)\](?: \{([^}]+)\})?(?: >([0-9a-f]+))? ?(.*)$/);
    if (m) items.push({ kind:m[3]?'recur-event':'event', start:parseCalDate(m[1]), days:+m[2], recur:m[3]||'', note:m[4]||'', msg:m[5]||'', raw:line });
  }
  return { items, ...d };
}

function save(data, items) {
  fs.mkdirSync(path.dirname(data.aptFile), {recursive:true});
  fs.mkdirSync(path.dirname(data.todoFile), {recursive:true});
  const todos = items.filter(x=>x.kind==='todo').map(rawLine).join('\n');
  const apts = items.filter(x=>x.kind!=='todo').map(rawLine).join('\n');
  fs.writeFileSync(data.todoFile, todos + (todos?'\n':''));
  fs.writeFileSync(data.aptFile, apts + (apts?'\n':''));
}

function rawLine(x) {
  if (x.raw) return x.raw;
  if (x.kind === 'todo') return `[${x.completed?'-':''}${x.priority||0}]${x.note?'>'+x.note:''} ${x.msg}`;
  if (x.kind.includes('apt')) return `${mdY(x.start)} @ ${hm(x.start)} -> ${mdY(x.end)} @ ${hm(x.end)}${x.recur?' {'+x.recur+'}':''}${x.note?'>'+x.note:''}|${x.msg}`;
  return `${mdY(x.start)} [${x.days||1}]${x.recur?' {'+x.recur+'}':''}${x.note?' >'+x.note:''} ${x.msg}`;
}

function typeSet(s) {
  if (!s) return null;
  const out = new Set();
  for (const p of s.split(',')) {
    if (p === 'cal') ['event','apt','recur-event','recur-apt'].forEach(x=>out.add(x));
    else if (p === 'recur') ['recur-event','recur-apt'].forEach(x=>out.add(x));
    else out.add(p);
  }
  return out;
}

function matches(x,o) {
  let ok = true, ts = typeSet(o.filters.type);
  if (ts && !ts.has(x.kind)) ok=false;
  if (o.filters.pattern) { try { if (!new RegExp(o.filters.pattern).test(x.msg)) ok=false; } catch { ok=false; } }
  if (x.kind==='todo') {
    if (o.filters.priority != null && x.priority !== o.filters.priority) ok=false;
    if (o.filters.completed && !x.completed) ok=false;
    if (o.filters.uncompleted && x.completed) ok=false;
  }
  if (o.filters.hash) {
    const neg = o.filters.hash.startsWith('!'), h = neg ? o.filters.hash.slice(1) : o.filters.hash;
    const has = itemHash(x).startsWith(h); if (neg ? has : !has) ok=false;
  }
  return o.filters.invert ? !ok : ok;
}

function itemHash(x) { return sha(rawLine(x)); }

function occurrences(x, from, to) {
  const res = [];
  const add = (s,e) => { if (cmpDay(s,to)<=0 && cmpDay(e,from)>=0) res.push({item:x,start:s,end:e}); };
  const dur = x.kind.includes('apt') ? x.end - x.start : (x.days||1)*86400000;
  const untilM = (x.recur||'').match(/-> (\d{2}\/\d{2}\/\d{4})/);
  const until = untilM ? parseCalDate(untilM[1]) : null;
  const freqM = (x.recur||'').match(/^(\d+)([DWMY])/);
  if (!freqM) { add(x.start, x.kind.includes('apt') ? x.end : addDays(x.start,(x.days||1)-1)); return res; }
  let cur = new Date(x.start), step = +freqM[1], freq = freqM[2], guard=0;
  const ex = new Set([...(x.recur||'').matchAll(/!(\d{2}\/\d{2}\/\d{4})/g)].map(m=>ymd(parseCalDate(m[1]))));
  while (guard++ < 5000 && (!until || cmpDay(cur, until) <= 0) && cmpDay(cur,to) <= 0) {
    if (!ex.has(ymd(cur))) {
      const end = x.kind.includes('apt') ? new Date(cur.getTime()+dur) : addDays(cur,(x.days||1)-1);
      add(cur,end);
    }
    if (freq==='D') cur=addDays(cur,step); else if (freq==='W') cur=addDays(cur,7*step); else if (freq==='M') cur=addMonths(cur,step); else cur=addYears(cur,step);
  }
  return res;
}

function formatItem(x, occ, o, query=true) {
  const key = x.kind.replace('recur-','recur-');
  let fmt = o.formats[key] || (query ? (x.kind==='todo' ? '%p. %m\n' : x.kind.includes('apt') ? ' - %S -> %E\n\t%m\n' : ' * %m\n') : '%(raw)');
  const refDay = occ.day || occ.start;
  const startText = x.kind === 'todo' ? '' : (sameDay(refDay, occ.start) ? hm(occ.start) : '..:..');
  const endText = x.kind === 'todo' ? '' : (sameDay(refDay, occ.end) ? hm(occ.end) : '..:..');
  return fmt.replace(/%\(hash\)/g,itemHash(x)).replace(/%\(raw\)/g,rawLine(x)).replace(/%S/g, startText)
    .replace(/%E/g, endText).replace(/%s/g, Math.floor((occ.start||0)/1000)).replace(/%e/g, Math.floor((occ.end||0)/1000))
    .replace(/%d/g, Math.floor((occ.end-occ.start)/1000)).replace(/%p/g, x.priority ?? 0).replace(/%m/g, x.msg).replace(/%n/g, x.note||'').replace(/\\n/g,'\n').replace(/\\t/g,'\t');
}
function sameDay(a,b){ return ymd(a)===ymd(b); }

function query(o) {
  const data = load(o), today = startOfDay(new Date());
  let from = o.from ? parseDate(o.from,o.inputFmt) : today, to;
  if (o.days != null) { const n=o.days||1; if (n<0) { to=from; from=addDays(from,n+1); } else to=addDays(from,n-1); }
  else to = o.to ? parseDate(o.to,o.inputFmt) : from;
  from=startOfDay(from); to=startOfDay(to);
  let out='', count=0;
  const incTodo = !o.filters.type || typeSet(o.filters.type).has('todo');
  if (incTodo) {
    const todos = data.items.filter(x=>x.kind==='todo' && matches(x,o));
    if (todos.length) { out += 'to do:\n'; for (const t of todos) if (!o.limit || count++<o.limit) out += formatItem(t,{start:today,end:today},o,true); out += '\n'; }
  }
  const incCal = !o.filters.type || [...typeSet(o.filters.type)||[]].some(t=>t!=='todo');
  if (incCal) for (let d=from; cmpDay(d,to)<=0; d=addDays(d,1)) {
    let day = [];
    for (const it of data.items.filter(x=>x.kind!=='todo' && matches(x,o))) {
      for (const occ of occurrences(it,d,d)) if (cmpDay(d,occ.start)>=0 && cmpDay(d,occ.end)<=0) { occ.day = new Date(d); day.push({it,occ}); }
    }
    day.sort((a,b)=> {
      const ac = sameDay(a.occ.start, d) ? 0 : 1, bc = sameDay(b.occ.start, d) ? 0 : 1;
      return ac-bc || (a.occ.start-b.occ.start) || a.it.msg.localeCompare(b.it.msg);
    });
    if (day.length) {
      out += `${outDate(d)}:\n`;
      for (const z of day) if (!o.limit || count++<o.limit) out += formatItem(z.it,z.occ,o,true);
      out += '\n';
    }
  }
  process.stdout.write(out);
}

function grep(o) {
  const data = load(o); let out='';
  for (const it of data.items.filter(x=>matches(x,o))) out += formatItem(it,{start:it.start||new Date(),end:it.end||new Date()},o,false) + (/%\(raw\)/.test(o.formats[it.kind]||'')||Object.keys(o.formats).length===0?'\n':'');
  process.stdout.write(out);
}

function parseIcsDate(v) {
  const m = v.match(/(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})?)?/);
  if (!m) return null;
  return new Date(+m[1], +m[2]-1, +m[3], +(m[4]||0), +(m[5]||0), +(m[6]||0));
}
function parseDur(s) {
  const m = (s||'').match(/P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  return m ? (((+m[1]||0)*86400+(+m[2]||0)*3600+(+m[3]||0)*60+(+m[4]||0))*1000) : 0;
}
function unfoldIcs(txt) { return txt.replace(/\r/g,'').replace(/\n[ \t]/g,''); }
function importIcs(o) {
  const txt = unfoldIcs(fs.readFileSync(o.importFile,'utf8'));
  const data = load(o), items = [...data.items], imported=[];
  for (const block of txt.match(/BEGIN:(VEVENT|VTODO)[\s\S]*?END:\1/g)||[]) {
    const typ = block.match(/BEGIN:(\w+)/)[1];
    const props = {};
    for (const ln of block.split(/\n/)) {
      const p = ln.indexOf(':'); if (p<0) continue;
      const name = ln.slice(0,p).split(';')[0].toUpperCase();
      props[name] = props[name] ? props[name]+'\n'+ln.slice(p+1) : ln.slice(p+1);
    }
    const msg = unesc(props.SUMMARY || '').replace(/\n.*/s,'') || 'Empty description';
    let note = '';
    const desc = [props.DESCRIPTION, props.COMMENT, props.LOCATION].filter(Boolean).map(unesc).join('\n');
    if (desc) { note = sha(desc); try { fs.mkdirSync(data.notesDir,{recursive:true}); fs.writeFileSync(path.join(data.notesDir,note), desc); } catch {} }
    if (typ === 'VTODO') {
      const st = (props.STATUS||'').toUpperCase()==='COMPLETED';
      const it = {kind:'todo', priority:+(props.PRIORITY||0), completed:st, note, msg};
      items.push(it); imported.push(it);
    } else {
      const start = parseIcsDate(props.DTSTART||''); if (!start) continue;
      const isDate = /DTSTART;VALUE=DATE/.test(block);
      let end = props.DTEND ? parseIcsDate(props.DTEND) : new Date(start.getTime() + parseDur(props.DURATION));
      if (!end || +end === +start) end = isDate ? addDays(start,1) : new Date(start);
      let recur = '';
      if (props.RRULE) {
        const r = props.RRULE, f=(r.match(/FREQ=([^;]+)/)||[])[1], interval=+(r.match(/INTERVAL=(\d+)/)||[])[1]||1;
        const code = {DAILY:'D',WEEKLY:'W',MONTHLY:'M',YEARLY:'Y'}[f]||'D';
        let until = r.match(/UNTIL=([^;]+)/); let count = +(r.match(/COUNT=(\d+)/)||[])[1]||0;
        let u = until ? parseIcsDate(until[1]) : (count ? advance(start, code, interval*(count-1)) : addYears(start,10));
        recur = `${interval}${code} -> ${mdY(u)}`;
        const ex = [...block.matchAll(/EXDATE[^:]*:([^\n]+)/g)].flatMap(m=>m[1].split(',')).map(parseIcsDate).filter(Boolean);
        if (ex.length) recur += ' ' + ex.map(d=>'!'+mdY(d)).join(' ');
      }
      if (isDate) {
        const days = Math.max(1, Math.round((startOfDay(end)-startOfDay(start))/86400000));
        const it = {kind:recur?'recur-event':'event', start:startOfDay(start), days, recur, note, msg};
        items.push(it); imported.push(it);
      } else {
        const it = {kind:recur?'recur-apt':'apt', start, end, recur, note, msg};
        items.push(it); imported.push(it);
      }
    }
  }
  if (!o.readOnly) save(data, items);
  if (o.dumpImported) for (const it of imported) process.stdout.write(rawLine(it)+'\n');
}
function advance(d,code,n){ return code==='D'?addDays(d,n):code==='W'?addDays(d,7*n):code==='M'?addMonths(d,n):addYears(d,n); }

function exportIcs(o) {
  const data = load(o); let out='BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//calcurse//NONSGML v4.8.2//EN\n';
  for (const x of data.items.filter(it=>matches(it,o))) {
    if (x.kind==='todo') out += `BEGIN:VTODO\nPRIORITY:${x.priority||0}\nSUMMARY:${esc(x.msg)}\nEND:VTODO\n`;
    else {
      out += 'BEGIN:VEVENT\n';
      if (x.kind.includes('event')) out += `DTSTART;VALUE=DATE:${x.start.getFullYear()}${pad(x.start.getMonth()+1)}${pad(x.start.getDate())}\n`;
      else out += `DTSTART:${x.start.getFullYear()}${pad(x.start.getMonth()+1)}${pad(x.start.getDate())}T${pad(x.start.getHours())}${pad(x.start.getMinutes())}00\nDURATION:PT${Math.max(0,Math.round((x.end-x.start)/60000))}M\n`;
      if (x.recur) {
        const m=x.recur.match(/^(\d+)([DWMY]) -> (\d{2})\/(\d{2})\/(\d{4})/), freq={D:'DAILY',W:'WEEKLY',M:'MONTHLY',Y:'YEARLY'};
        if (m) out += `RRULE:FREQ=${freq[m[2]]};INTERVAL=${m[1]};UNTIL=${m[5]}${m[3]}${m[4]}\n`;
      } else if (x.kind.includes('event') && (x.days||1)>1) out += `RRULE:FREQ=DAILY;UNTIL:${ymd(addDays(x.start,(x.days||1)-1)).replace(/-/g,'')}\n`;
      out += `SUMMARY:${esc(x.msg)}\nEND:VEVENT\n`;
    }
  }
  out += 'END:VCALENDAR\n';
  process.stdout.write(out);
}

function next(o) {
  const data=load(o), now=new Date(), limit=new Date(now.getTime()+86400000);
  let arr=[]; for (const it of data.items.filter(x=>x.kind.includes('apt'))) for (const occ of occurrences(it,now,limit)) if (occ.start>=now) arr.push({it,occ});
  arr.sort((a,b)=>a.occ.start-b.occ.start); if (!arr[0]) return;
  const mins=Math.round((arr[0].occ.start-now)/60000), h=Math.floor(mins/60), m=mins%60;
  process.stdout.write(`[${h}:${pad(m)}] ${arr[0].it.msg}\n`);
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  try {
    if (!o.op) return;
    if (o.op==='help') console.log(HELP);
    else if (o.op==='version') console.log(VERSION);
    else if (o.op==='status') console.log('calcurse is not running');
    else if (o.op==='gc' || o.op==='daemon') return;
    else if (o.op==='query') query(o);
    else if (o.op==='grep') grep(o);
    else if (o.op==='purge') { const d=load(o); save(d,d.items.filter(x=>!matches(x,o))); }
    else if (o.op==='import') importIcs(o);
    else if (o.op==='export') exportIcs(o);
    else if (o.op==='next') next(o);
  } catch(e) { console.error(`args.c: 797: ${e.message}`); process.exit(1); }
}
main();
