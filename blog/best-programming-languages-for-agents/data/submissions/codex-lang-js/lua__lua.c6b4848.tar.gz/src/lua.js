#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const child_process = require("child_process");

class LuaError extends Error {}
const NIL = null;
const isNil = v => v === null || v === undefined;
const truthy = v => v !== false && !isNil(v);
const multi = v => v instanceof Multi ? v.vals : [v];
const first = v => v instanceof Multi ? (v.vals[0] ?? NIL) : v;
class Multi { constructor(vals) { this.vals = vals; } }

class LuaTable {
  constructor() { this.map = new Map(); this.id = LuaTable.next++; }
  key(k) { return typeof k + ":" + String(k); }
  rawget(k) { return this.map.get(this.key(k)) ?? NIL; }
  rawset(k, v) { if (isNil(v)) this.map.delete(this.key(k)); else this.map.set(this.key(k), v); }
  len() { let n = 0; while (!isNil(this.rawget(n + 1))) n++; return n; }
  keys() { const out = []; for (const [kk, v] of this.map) { const p = kk.indexOf(":"); let t = kk.slice(0,p), s = kk.slice(p+1); out.push([t === "number" ? Number(s) : t === "boolean" ? s === "true" : s, v]); } return out; }
}
LuaTable.next = 1;

function luaStr(v) {
  if (isNil(v)) return "nil";
  if (v === true) return "true";
  if (v === false) return "false";
  if (typeof v === "number") return Number.isInteger(v) ? String(v) : String(v);
  if (typeof v === "string") return v;
  if (v instanceof LuaTable) return `table: 0x${(0x555555500000 + v.id * 0x120).toString(16)}`;
  if (typeof v === "function" || v instanceof LuaFunction) return `function: 0x${(0x555555600000 + (v.id || 1) * 0x120).toString(16)}`;
  return String(v);
}
function luaType(v) {
  if (isNil(v)) return "nil";
  if (v instanceof LuaTable) return "table";
  if (v instanceof LuaFunction || typeof v === "function") return "function";
  if (typeof v === "number") return "number";
  if (typeof v === "string") return "string";
  if (typeof v === "boolean") return "boolean";
  return typeof v;
}
function toNum(v) {
  if (typeof v === "number") return v;
  if (typeof v === "string" && v.trim() !== "" && !Number.isNaN(Number(v))) return Number(v);
  throw new LuaError(`attempt to perform arithmetic on a ${luaType(v)} value`);
}

class Lexer {
  constructor(src) { this.src = src.replace(/^\uFEFF/, ""); this.i = 0; this.line = 1; this.buf = null; }
  eof() { return this.i >= this.src.length; }
  peekc(n=0) { return this.src[this.i+n] || ""; }
  nextc() { const c = this.src[this.i++] || ""; if (c === "\n") this.line++; return c; }
  skip() {
    for (;;) {
      while (/\s/.test(this.peekc())) this.nextc();
      if (this.peekc() === "-" && this.peekc(1) === "-") {
        this.i += 2;
        if (this.peekc() === "[" && this.peekc(1) === "[") { this.i += 2; while (!this.eof() && !(this.peekc()==="]"&&this.peekc(1)==="]")) this.nextc(); if (!this.eof()) this.i += 2; }
        else while (!this.eof() && this.peekc() !== "\n") this.nextc();
      } else break;
    }
  }
  token() {
    this.skip();
    const line = this.line;
    if (this.eof()) return {t:"eof", line};
    const c = this.peekc(), two = c + this.peekc(1), three = two + this.peekc(2);
    const ops3 = ["...","//="]; const ops2 = ["==","~=","<=",">=","..","//","<<",">>","::"];
    if (ops3.includes(three)) { this.i += 3; return {t:three,line}; }
    if (ops2.includes(two)) { this.i += 2; return {t:two,line}; }
    if (c === "." && /\d/.test(this.peekc(1)) || /\d/.test(c)) {
      let s = "";
      if (c === "0" && /[xX]/.test(this.peekc(1))) { s += this.nextc()+this.nextc(); while (/[0-9a-fA-F.]/.test(this.peekc())) s += this.nextc(); return {t:"num",v:Number(s),line}; }
      while (/\d/.test(this.peekc())) s += this.nextc();
      if (this.peekc() === "." && this.peekc(1) !== ".") { s += this.nextc(); while (/\d/.test(this.peekc())) s += this.nextc(); }
      if (/[eE]/.test(this.peekc())) { s += this.nextc(); if (/[+-]/.test(this.peekc())) s += this.nextc(); while (/\d/.test(this.peekc())) s += this.nextc(); }
      return {t:"num",v:Number(s),line};
    }
    if (/[A-Za-z_]/.test(c)) {
      let s = ""; while (/[A-Za-z0-9_]/.test(this.peekc())) s += this.nextc();
      const kw = new Set("and break do else elseif end false for function goto if in local nil not or repeat return then true until while".split(" "));
      return {t: kw.has(s) ? s : "id", v:s, line};
    }
    if (c === "'" || c === '"') {
      const q = this.nextc(); let s = "";
      while (!this.eof() && this.peekc() !== q) {
        let ch = this.nextc();
        if (ch === "\\") { const e = this.nextc(); const m = {n:"\n",t:"\t",r:"\r",a:"\x07",b:"\b",f:"\f",v:"\v","\\":"\\","'":"'","\"":"\""}; ch = m[e] ?? e; }
        s += ch;
      }
      if (this.peekc() === q) this.nextc();
      return {t:"str",v:s,line};
    }
    if (c === "[" && this.peekc(1) === "[") {
      this.i += 2; let s = ""; while (!this.eof() && !(this.peekc()==="]"&&this.peekc(1)==="]")) s += this.nextc(); if (!this.eof()) this.i += 2; return {t:"str",v:s,line};
    }
    this.i++; return {t:c,line};
  }
  peek() { if (!this.buf) this.buf = this.token(); return this.buf; }
  next() { const t = this.peek(); this.buf = null; return t; }
  accept(t) { if (this.peek().t === t) return this.next(); return null; }
  expect(t) { const x = this.next(); if (x.t !== t) throw new LuaError(`syntax error near '${x.t}'`); return x; }
}

class Parser {
  constructor(src) { this.l = new Lexer(src); }
  parse() { const body = this.block(new Set(["eof"])); this.l.expect("eof"); return {k:"block",body}; }
  block(stops) { const a=[]; while (!stops.has(this.l.peek().t)) { if (this.l.accept(";")) continue; a.push(this.stat()); } return a; }
  stat() {
    const t = this.l.peek().t;
    if (t === "return") { this.l.next(); const ex = (this.l.peek().t==="end"||this.l.peek().t==="eof"||this.l.peek().t==="else"||this.l.peek().t==="elseif"||this.l.peek().t==="until") ? [] : this.explist(); this.l.accept(";"); return {k:"return",ex}; }
    if (t === "break") { this.l.next(); return {k:"break"}; }
    if (t === "do") { this.l.next(); const body=this.block(new Set(["end"])); this.l.expect("end"); return {k:"do",body}; }
    if (t === "while") { this.l.next(); const c=this.expr(); this.l.expect("do"); const b=this.block(new Set(["end"])); this.l.expect("end"); return {k:"while",c,b}; }
    if (t === "repeat") { this.l.next(); const b=this.block(new Set(["until"])); this.l.expect("until"); return {k:"repeat",b,c:this.expr()}; }
    if (t === "if") return this.ifstat();
    if (t === "for") return this.forstat();
    if (t === "function") { this.l.next(); const name=this.funcname(); const fn=this.funcbody(); if (name.method && fn.k === "func") fn.ps.unshift("self"); return {k:"assign",vars:[name],ex:[fn]}; }
    if (t === "local") return this.localstat();
    const p = this.prefix();
    if (p.k === "call") return {k:"call",e:p};
    const vars=[p]; while (this.l.accept(",")) vars.push(this.prefix());
    this.l.expect("="); return {k:"assign",vars,ex:this.explist()};
  }
  localstat() {
    this.l.expect("local");
    if (this.l.accept("function")) { const n=this.l.expect("id").v; const fn=this.funcbody(); return {k:"local",names:[n],ex:[fn]}; }
    const names=[this.l.expect("id").v]; while (this.l.accept(",")) names.push(this.l.expect("id").v);
    const ex=this.l.accept("=") ? this.explist() : []; return {k:"local",names,ex};
  }
  ifstat() {
    this.l.expect("if"); const clauses=[]; clauses.push([this.expr(), (this.l.expect("then"), this.block(new Set(["elseif","else","end"])))]);
    while (this.l.accept("elseif")) clauses.push([this.expr(), (this.l.expect("then"), this.block(new Set(["elseif","else","end"])))]);
    let els=[]; if (this.l.accept("else")) els=this.block(new Set(["end"])); this.l.expect("end"); return {k:"if",clauses,els};
  }
  forstat() {
    this.l.expect("for"); const n=this.l.expect("id").v;
    if (this.l.accept("=")) { const a=this.expr(); this.l.expect(","); const b=this.expr(); let c={k:"num",v:1}; if (this.l.accept(",")) c=this.expr(); this.l.expect("do"); const body=this.block(new Set(["end"])); this.l.expect("end"); return {k:"fornum",n,a,b,c,body}; }
    const names=[n]; while (this.l.accept(",")) names.push(this.l.expect("id").v); this.l.expect("in"); const ex=this.explist(); this.l.expect("do"); const body=this.block(new Set(["end"])); this.l.expect("end"); return {k:"forin",names,ex,body};
  }
  funcname() { let e={k:"var",n:this.l.expect("id").v}; while (this.l.accept(".")) e={k:"idx",obj:e,key:{k:"str",v:this.l.expect("id").v}}; if (this.l.accept(":")) e={k:"idx",obj:e,key:{k:"str",v:this.l.expect("id").v},method:true}; return e; }
  funcbody() { this.l.expect("("); const ps=[]; let va=false; if (!this.l.accept(")")) { do { if (this.l.accept("...")) { va=true; break; } ps.push(this.l.expect("id").v); } while (this.l.accept(",")); this.l.expect(")"); } const body=this.block(new Set(["end"])); this.l.expect("end"); return {k:"func",ps,va,body}; }
  explist() { const a=[this.expr()]; while (this.l.accept(",")) a.push(this.expr()); return a; }
  expr(p=0) {
    let e=this.unary();
    const prec={or:1,and:2,"<":3,">":3,"<=":3,">=":3,"~=":3,"==":3,"|":4,"~":5,"&":6,"<<":7,">>":7,"..":8,"+":9,"-":9,"*":10,"/":10,"//":10,"%":10,"^":12};
    for (;;) { const op=this.l.peek().t, q=prec[op]; if (!q || q<=p) break; this.l.next(); const r=this.expr((op==="^"||op==="..")?q-1:q); e={k:"bin",op,l:e,r}; }
    return e;
  }
  unary() { const t=this.l.peek().t; if (t==="not"||t==="-"||t==="#"||t==="~") { this.l.next(); return {k:"un",op:t,e:this.expr(11)}; } return this.simple(); }
  simple() {
    const t=this.l.peek();
    if (this.l.accept("nil")) return {k:"nil"}; if (this.l.accept("true")) return {k:"bool",v:true}; if (this.l.accept("false")) return {k:"bool",v:false};
    if (t.t==="num") { this.l.next(); return {k:"num",v:t.v}; } if (t.t==="str") { this.l.next(); return {k:"str",v:t.v}; }
    if (this.l.accept("...")) return {k:"vararg"}; if (this.l.accept("function")) return this.funcbody(); if (this.l.peek().t==="{") return this.table();
    return this.prefix();
  }
  table() {
    this.l.expect("{"); const fields=[]; let arr=1;
    while (!this.l.accept("}")) {
      if (this.l.accept("[")) { const key=this.expr(); this.l.expect("]"); this.l.expect("="); fields.push({key,val:this.expr()}); }
      else if (this.l.peek().t==="id" && this.l.src?.[0] !== "" && (()=>{ const save=this.l.buf; return true; })()) {
        const id=this.l.next(); if (this.l.accept("=")) fields.push({key:{k:"str",v:id.v},val:this.expr()}); else { this.l.buf=id; fields.push({key:{k:"num",v:arr++},val:this.expr()}); }
      } else fields.push({key:{k:"num",v:arr++},val:this.expr()});
      if (!this.l.accept(",") && !this.l.accept(";")) {
        if (this.l.accept("}")) break;
      }
    }
    return {k:"table",fields};
  }
  prefix() {
    let e;
    if (this.l.accept("(")) { e=this.expr(); this.l.expect(")"); }
    else e={k:"var",n:this.l.expect("id").v};
    for (;;) {
      if (this.l.accept(".")) e={k:"idx",obj:e,key:{k:"str",v:this.l.expect("id").v}};
      else if (this.l.accept("[")) { e={k:"idx",obj:e,key:this.expr()}; this.l.expect("]"); }
      else if (this.l.accept(":")) { const m=this.l.expect("id").v; e=this.call({k:"idx",obj:e,key:{k:"str",v:m}}, e); }
      else if (["(","{","str"].includes(this.l.peek().t)) e=this.call(e,null);
      else break;
    }
    return e;
  }
  call(fn,self) {
    let args=[];
    if (this.l.accept("(")) { if (!this.l.accept(")")) { args=this.explist(); this.l.expect(")"); } }
    else if (this.l.peek().t==="{") args=[this.table()];
    else { const s=this.l.expect("str"); args=[{k:"str",v:s.v}]; }
    return {k:"call",fn,args,self};
  }
}

class Env {
  constructor(parent=null) { this.parent=parent; this.vars=Object.create(null); }
  get(n) { return Object.prototype.hasOwnProperty.call(this.vars,n) ? this.vars[n] : this.parent ? this.parent.get(n) : NIL; }
  set(n,v) { if (Object.prototype.hasOwnProperty.call(this.vars,n) || !this.parent) this.vars[n]=v; else this.parent.set(n,v); }
  local(n,v=NIL) { this.vars[n]=v; }
}
class LuaFunction {
  constructor(ps, va, body, env) { this.ps=ps; this.va=va; this.body=body; this.env=env; this.id=LuaFunction.next++; }
  call(args, interp) {
    const e=new Env(this.env); this.ps.forEach((p,i)=>e.local(p,args[i]??NIL)); e.local("...", new Multi(args.slice(this.ps.length)));
    const r=interp.execBlock(this.body,e); return r && r.kind==="return" ? r.vals : [];
  }
}
LuaFunction.next=1;

class Interp {
  constructor(argv) { this.global=new Env(); this.setup(argv); }
  setup(argv) {
    const g=this.global, def=(n,f)=>g.local(n,f);
    def("_VERSION","Lua 5.5");
    def("print", (...a)=>{ process.stdout.write(a.map(luaStr).join("\t")+"\n"); return []; });
    def("tostring", v=>luaStr(v)); def("tonumber",(v,b)=>{ if (isNil(v)) return NIL; const n=parseInt(String(v), b||10); return Number.isNaN(n)?NIL:n; });
    def("type", luaType); def("assert",(v,msg)=>{ if(!truthy(v)) throw new LuaError(luaStr(msg||"assertion failed!")); return [v]; });
    def("error", msg=>{ throw new LuaError(luaStr(msg)); }); def("select",(idx,...a)=>idx==="#"?a.length:a.slice(Number(idx)-1));
    def("pcall",(fn,...a)=>{ try { return [true,...this.call(fn,a)]; } catch(e){ return [false, e.message]; } });
    def("pairs", t=>this.iterPairs(t)); def("ipairs", t=>this.iterIPairs(t)); def("next",(t,k)=>this.next(t,k));
    def("rawget",(t,k)=>t.rawget(k)); def("rawset",(t,k,v)=>{t.rawset(k,v); return t;}); def("rawequal",(a,b)=>a===b); def("rawlen",v=>v instanceof LuaTable?v.len():String(v).length);
    const argt=new LuaTable(); argv.forEach((v,i)=>argt.rawset(i,v)); def("arg",argt);
    const math=this.tbl({abs:Math.abs,acos:Math.acos,asin:Math.asin,atan:Math.atan,ceil:Math.ceil,cos:Math.cos,deg:x=>x*180/Math.PI,exp:Math.exp,floor:Math.floor,fmod:(a,b)=>a%b,log:Math.log,max:(...a)=>Math.max(...a),min:(...a)=>Math.min(...a),modf:x=>[Math.trunc(x),x-Math.trunc(x)],rad:x=>x*Math.PI/180,random:(a,b)=>isNil(a)?Math.random():isNil(b)?Math.floor(Math.random()*a)+1:Math.floor(Math.random()*(b-a+1))+a,randomseed:()=>[],sin:Math.sin,sqrt:Math.sqrt,tan:Math.tan,pi:Math.PI,huge:Infinity});
    def("math",math);
    const string=this.tbl({len:s=>String(s).length,lower:s=>String(s).toLowerCase(),upper:s=>String(s).toUpperCase(),reverse:s=>[...String(s)].reverse().join(""),sub:(s,i,j)=>{s=String(s);i=this.pos(i,s.length);j=isNil(j)?s.length:this.pos(j,s.length);return s.slice(i-1,j);},byte:(s,i=1,j=i)=>{s=String(s); const r=[]; for(let p=this.pos(i,s.length);p<=this.pos(j,s.length);p++) r.push(s.charCodeAt(p-1)??NIL); return r;},char:(...a)=>String.fromCharCode(...a),rep:(s,n,sep="")=>Array(Number(n)).fill(String(s)).join(sep),format:(fmt,...a)=>this.format(fmt,a),find:(s,p,init=1,plain)=>{s=String(s);p=String(p); const ix=s.indexOf(p,this.pos(init,s.length)-1); return ix<0?[NIL]:[ix+1,ix+p.length];},match:(s,p)=>{const m=String(s).match(new RegExp(String(p))); return m?m[0]:NIL;},gsub:(s,p,r)=>String(s).split(String(p)).join(String(r))});
    def("string",string);
    const table=this.tbl({concat:(t,sep="",i=1,j)=>{j=isNil(j)?t.len():j;let a=[];for(let k=i;k<=j;k++)a.push(luaStr(t.rawget(k)));return a.join(sep);},insert:(t,pos,v)=>{ if(isNil(v)){v=pos;pos=t.len()+1;} for(let i=t.len()+1;i>pos;i--)t.rawset(i,t.rawget(i-1)); t.rawset(pos,v); return [];},remove:(t,pos)=>{pos=pos||t.len(); const v=t.rawget(pos); for(let i=pos;i<t.len();i++)t.rawset(i,t.rawget(i+1)); t.rawset(t.len(),NIL); return v;},sort:(t)=>{let a=[];for(let i=1;i<=t.len();i++)a.push(t.rawget(i));a.sort();a.forEach((v,i)=>t.rawset(i+1,v));}});
    def("table",table);
    def("require", name=>{ try { const code=fs.readFileSync(String(name).replace(/\./g,"/")+".lua","utf8"); return this.run(code,String(name)); } catch { return true; } });
    const io=this.tbl({write:(...a)=>{process.stdout.write(a.map(luaStr).join(""));return [];},read:(...a)=>this.ioRead(...a),open:(p,m="r")=>this.fileObj(p,m),lines:(p)=>this.lines(p),stdin:NIL,stdout:NIL,stderr:NIL});
    def("io",io);
    def("dofile",(p)=>this.run(fs.readFileSync(p,"utf8"),p)); def("loadfile",(p)=>{try{return this.load(fs.readFileSync(p,"utf8"),p);}catch(e){return [NIL,e.message];}});
    def("load",(s,n)=>this.load(String(s),n||"=(load)"));
    def("os",this.tbl({clock:()=>process.uptime(),date:(f)=>{const d=new Date();return !f||f==="%c"?d.toString():d.toISOString();},time:()=>Math.floor(Date.now()/1000),exit:(c=0)=>process.exit(c===true?0:Number(c)||0),getenv:n=>process.env[n]??NIL,execute:cmd=>{try{child_process.execSync(cmd,{stdio:"inherit"});return [true,"exit",0];}catch(e){return [NIL,"exit",e.status||1];}},remove:p=>{try{fs.unlinkSync(p);return true;}catch(e){return [NIL,e.message];}},rename:(a,b)=>{try{fs.renameSync(a,b);return true;}catch(e){return [NIL,e.message];}},tmpname:()=>"/tmp/lua_"+Math.random().toString(36).slice(2)}));
    def("_G", this.envTable(g));
  }
  tbl(o) { const t=new LuaTable(); for (const [k,v] of Object.entries(o)) t.rawset(k,v); return t; }
  envTable(env) { const t=new LuaTable(); t.rawget=k=>env.get(k); t.rawset=(k,v)=>env.set(k,v); return t; }
  pos(i,len){ i=Number(i); return i<0?len+i+1:i; }
  format(fmt,args){ let i=0; return String(fmt).replace(/%([%sdifq])/g,(m,c)=>c==="%"?"%":c==="q"?JSON.stringify(luaStr(args[i++])):c==="s"?luaStr(args[i++]):String(Number(args[i++]))); }
  ioRead(){ const s=fs.readFileSync(0,"utf8"); return s.length?s:NIL; }
  fileObj(p,m){ const obj={path:String(p),mode:String(m),closed:false}; const t=this.tbl({read:()=>{try{return fs.readFileSync(obj.path,"utf8");}catch{return NIL;}},write:(self,...a)=>{fs.appendFileSync(obj.path,a.map(luaStr).join(""));return true;},close:()=>{obj.closed=true;return true;},lines:()=>this.lines(obj.path)}); return t; }
  lines(p){ const lines=fs.readFileSync(p,"utf8").split(/\r?\n/); let i=0; return ()=>i<lines.length-1?lines[i++]:NIL; }
  iterPairs(t){ const keys=t.keys(); let i=0; return [()=>i<keys.length?keys[i++]:[NIL], NIL, NIL]; }
  iterIPairs(t){ let i=0; return [()=>{i++; const v=t.rawget(i); return isNil(v)?[NIL]:[i,v];}, NIL, NIL]; }
  next(t,k){ const keys=t.keys(); let ix=isNil(k)?0:keys.findIndex(x=>x[0]===k)+1; return ix>=0&&ix<keys.length?keys[ix]:[NIL]; }
  load(src,name){ const ast=new Parser(src).parse(); const fn=new LuaFunction([],true,ast.body,this.global); return (...a)=>fn.call(a,this); }
  run(src,name="=(command line)") { const fn=this.load(src,name); const r=this.call(fn,[]); return new Multi(r); }
  call(fn,args){ if (fn instanceof LuaFunction) return fn.call(args,this); if (typeof fn==="function") { const r=fn(...args); return r instanceof Multi?r.vals:Array.isArray(r)?r:[r].filter(v=>v!==undefined); } throw new LuaError(`attempt to call a ${luaType(fn)} value`); }
  evalList(ex,env){ const out=[]; ex.forEach((e,i)=>{ const v=this.eval(e,env); const m=(i===ex.length-1)?multi(v):[first(v)]; out.push(...m); }); return out; }
  execBlock(body,env){ for (const s of body) { const r=this.exec(s,env); if (r) return r; } return null; }
  exec(s,env){
    if(s.k==="return") return {kind:"return",vals:this.evalList(s.ex,env)}; if(s.k==="break") return {kind:"break"};
    if(s.k==="do") return this.execBlock(s.body,new Env(env));
    if(s.k==="call"){ this.eval(s.e,env); return null; }
    if(s.k==="local"){ const vals=this.evalList(s.ex,env); s.names.forEach((n,i)=>env.local(n,vals[i]??NIL)); return null; }
    if(s.k==="assign"){ const vals=this.evalList(s.ex,env); s.vars.forEach((v,i)=>this.assign(v, vals[i]??NIL, env)); return null; }
    if(s.k==="if"){ for(const [c,b] of s.clauses) if(truthy(first(this.eval(c,env)))) return this.execBlock(b,new Env(env)); return this.execBlock(s.els,new Env(env)); }
    if(s.k==="while"){ while(truthy(first(this.eval(s.c,env)))) { const r=this.execBlock(s.b,new Env(env)); if(r?.kind==="break") break; if(r) return r; } return null; }
    if(s.k==="repeat"){ do { const r=this.execBlock(s.b,new Env(env)); if(r?.kind==="break") break; if(r) return r; } while(!truthy(first(this.eval(s.c,env)))); return null; }
    if(s.k==="fornum"){ const a=toNum(first(this.eval(s.a,env))), b=toNum(first(this.eval(s.b,env))), c=toNum(first(this.eval(s.c,env))); for(let i=a;c>=0?i<=b:i>=b;i+=c){ const e=new Env(env); e.local(s.n,i); const r=this.execBlock(s.body,e); if(r?.kind==="break") break; if(r) return r; } return null; }
    if(s.k==="forin"){ const vals=this.evalList(s.ex,env); const gen=vals[0], st=vals[1], ctrl=vals[2]; let c=ctrl; for(;;){ const r=this.call(gen,[st,c]); if(isNil(r[0])) break; c=r[0]; const e=new Env(env); s.names.forEach((n,i)=>e.local(n,r[i]??NIL)); const rr=this.execBlock(s.body,e); if(rr?.kind==="break") break; if(rr) return rr; } return null; }
  }
  assign(v,val,env){ if(v.k==="var") env.set(v.n,val); else if(v.k==="idx"){ const o=first(this.eval(v.obj,env)); o.rawset(first(this.eval(v.key,env)),val); } else throw new LuaError("syntax error"); }
  eval(e,env){
    switch(e.k){
      case"nil":return NIL; case"bool":case"num":case"str":return e.v; case"var":return env.get(e.n); case"vararg":return env.get("...");
      case"func":return new LuaFunction(e.ps,e.va,e.body,env);
      case"table":{ const t=new LuaTable(); for(const f of e.fields) t.rawset(first(this.eval(f.key,env)), first(this.eval(f.val,env))); return t; }
      case"idx":{ const o=first(this.eval(e.obj,env)); if(isNil(o)) throw new LuaError("attempt to index a nil value"); if(typeof o==="string"){ const st=env.get("string"); return st.rawget(first(this.eval(e.key,env))); } return o.rawget(first(this.eval(e.key,env))); }
      case"call":{ const fn=first(this.eval(e.fn,env)); let args=this.evalList(e.args,env); if(e.self) args.unshift(first(this.eval(e.self,env))); return new Multi(this.call(fn,args)); }
      case"un":{ const v=first(this.eval(e.e,env)); if(e.op==="not")return !truthy(v); if(e.op==="-")return -toNum(v); if(e.op==="#")return v instanceof LuaTable?v.len():String(v).length; if(e.op==="~")return ~toNum(v); }
      case"bin": return this.bin(e.op, first(this.eval(e.l,env)), () => first(this.eval(e.r,env)));
    }
  }
  bin(op,a,rb){ if(op==="and") return truthy(a)?rb():a; if(op==="or") return truthy(a)?a:rb(); const b=rb(); switch(op){case"+":return toNum(a)+toNum(b);case"-":return toNum(a)-toNum(b);case"*":return toNum(a)*toNum(b);case"/":return toNum(a)/toNum(b);case"//":return Math.floor(toNum(a)/toNum(b));case"%":return toNum(a)%toNum(b);case"^":return Math.pow(toNum(a),toNum(b));case"..":return luaStr(a)+luaStr(b);case"==":return a===b;case"~=":return a!==b;case"<":return a<b;case">":return a>b;case"<=":return a<=b;case">=":return a>=b;case"&":return toNum(a)&toNum(b);case"|":return toNum(a)|toNum(b);case"~":return toNum(a)^toNum(b);case"<<":return toNum(a)<<toNum(b);case">>":return toNum(a)>>toNum(b);} }
}

function usage() {
  process.stderr.write("usage: ./executable [options] [script [args]]\nAvailable options are:\n  -e stat   execute string 'stat'\n  -i        enter interactive mode after executing 'script'\n  -l mod    require library 'mod' into global 'mod'\n  -l g=mod  require library 'mod' into global 'g'\n  -v        show version information\n  -E        ignore environment variables\n  -W        turn warnings on\n  --        stop handling options\n  -         stop handling options and execute stdin\n");
}
function main() {
  const av=process.argv.slice(2), acts=[]; let script=null, sargs=[], interactive=false;
  for(let i=0;i<av.length;i++){ const a=av[i]; if(a==="--help"){usage();process.exit(1);} if(a==="--"){script=av[++i];sargs=av.slice(i+1);break;} if(a==="-"){script="-";sargs=av.slice(i+1);break;} if(a==="-v"){console.log("Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio"); continue;} if(a==="-i"){interactive=true;continue;} if(a==="-E"||a==="-W")continue; if(a==="-e"){acts.push(["e",av[++i]||""]);continue;} if(a.startsWith("-e")){acts.push(["e",a.slice(2)]);continue;} if(a==="-l"){acts.push(["l",av[++i]||""]);continue;} if(a.startsWith("-l")){acts.push(["l",a.slice(2)]);continue;} if(a.startsWith("-")){process.stderr.write(`./executable: unrecognized option '${a}'\n`);usage();process.exit(1);} script=a;sargs=av.slice(i+1);break; }
  const interp=new Interp([script||"",...sargs]);
  try {
    for(const [k,v] of acts){ if(k==="e") interp.run(v,"=(command line)"); else { const [g,m]=v.includes("=")?v.split("="):[v,v]; interp.global.set(g, first(interp.call(interp.global.get("require"),[m]))); } }
    if(script){ const code=script==="-"?fs.readFileSync(0,"utf8"):fs.readFileSync(script,"utf8"); interp.run(code, script); }
    else if(acts.length===0 || interactive){ if(process.stdin.isTTY) process.stderr.write("> "); const code=fs.readFileSync(0,"utf8"); if(code.trim()) interp.run(code,"=stdin"); }
  } catch(e) { process.stderr.write(`./executable: ${e.message}\n`); process.exit(1); }
}
if (require.main === module) main();
