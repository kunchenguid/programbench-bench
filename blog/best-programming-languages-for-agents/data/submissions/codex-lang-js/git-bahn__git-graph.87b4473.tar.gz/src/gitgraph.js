#!/usr/bin/env node
const {execFileSync, spawnSync} = require('child_process');
const fs = require('fs');
const path = require('path');

const VERSION = 'git-graph 0.7.0';

const HELP_LONG = `Structured Git graphs for your branching model.
    https://github.com/mlange-42/git-graph

EXAMPES:
    git-graph                   -> Show graph
    git-graph --style round     -> Show graph in a different style
    git-graph --model <model>   -> Show graph using a certain <model>
    git-graph model --list      -> List available branching models
    git-graph model             -> Show repo's current branching models
    git-graph model <model>     -> Permanently set model <model> for this repo

Usage: executable [OPTIONS] [COMMAND]

Commands:
  model  Prints or permanently sets the branching model for a repository.
  help   Print this message or the help of the given subcommand(s)

Options:
  -p, --path <path>
          Open repository from this path or above. Default '.'

      --skip-repo-owner-validation
          Skip owner validation for the repository.
          This will turn off libgit2's owner validation, which may increase security risks.
          Please do not disable this validation for repositories you do not trust.

  -m, --model <model>
          Branching model. Available presets are [simple|git-flow|none].
          Default: git-flow. 
          Permanently set the model for a repository with
          > git-graph model <model>

  -n, --max-count <n>
          Maximum number of commits

      --color <color>
          Specify when colors should be used. One of [auto|always|never].
          Default: auto.

      --no-color
          Print without colors. Missing color support should be detected
          automatically (e.g. when piping to a file).
          Overrides option '--color'

  -w, --wrap [<wrap>...]
          Line wrapping for formatted commit text. Default: 'auto 0 8'
          Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
          Examples:
              git-graph --wrap auto
              git-graph --wrap auto 0 8
              git-graph --wrap none
              git-graph --wrap 80
              git-graph --wrap 80 0 8
          'auto' uses the terminal's width if on a terminal.

  -f, --format <format>
          Commit format. One of [oneline|short|medium|full|"<string>"].
            (First character can be used as abbreviation, e.g. '-f m')
          Formatting placeholders for "<string>":
              %n    newline
              %H    commit hash
              %h    abbreviated commit hash
              %P    parent commit hashes
              %p    abbreviated parent commit hashes
              %d    refs (branches, tags)
              %s    commit summary
              %b    commit message body
              %B    raw body (subject and body)
              %an   author name
              %ae   author email
              %ad   author date
              %as   author date in short format 'YYYY-MM-DD'
              %cn   committer name
              %ce   committer email
              %cd   committer date
              %cs   committer date in short format 'YYYY-MM-DD'
              
              If you add a + (plus sign) after % of a placeholder,
                 a line-feed is inserted immediately before the expansion if
                 and only if the placeholder expands to a non-empty string.
              If you add a - (minus sign) after % of a placeholder, all
                 consecutive line-feeds immediately preceding the expansion are
                 deleted if and only if the placeholder expands to an empty string.
              If you add a ' ' (space) after % of a placeholder, a space is
                 inserted immediately before the expansion if and only if
                 the placeholder expands to a non-empty string.
          
              See also the respective git help: https://git-scm.com/docs/pretty-formats
          

  -r, --reverse
          Reverse the order of commits.

  -l, --local
          Show only local branches, no remotes.

      --svg
          Render graph as SVG instead of text-based.

  -d, --debug
          Additional debug output and graphics.

  -S, --sparse
          Print a less compact graph: merge lines point to target lines
          rather than merge commits.

  -s, --style <style>
          Output style. One of [normal/thin|round|bold|double|ascii].
            (First character can be used as abbreviation, e.g. '-s r')

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const HELP_SHORT = `Structured Git graphs for your branching model.
    https://github.com/mlange-42/git-graph

EXAMPES:
    git-graph                   -> Show graph
    git-graph --style round     -> Show graph in a different style
    git-graph --model <model>   -> Show graph using a certain <model>
    git-graph model --list      -> List available branching models
    git-graph model             -> Show repo's current branching models
    git-graph model <model>     -> Permanently set model <model> for this repo

Usage: executable [OPTIONS] [COMMAND]

Commands:
  model  Prints or permanently sets the branching model for a repository.
  help   Print this message or the help of the given subcommand(s)

Options:
  -p, --path <path>                 Open repository from this path or above. Default '.'
      --skip-repo-owner-validation  Skip owner validation for the repository.
                                    This will turn off libgit2's owner validation, which may increase security risks.
                                    Please do not disable this validation for repositories you do not trust.
  -m, --model <model>               Branching model. Available presets are [simple|git-flow|none].
                                    Default: git-flow. 
                                    Permanently set the model for a repository with
                                    > git-graph model <model>
  -n, --max-count <n>               Maximum number of commits
      --color <color>               Specify when colors should be used. One of [auto|always|never].
                                    Default: auto.
      --no-color                    Print without colors. Missing color support should be detected
                                    automatically (e.g. when piping to a file).
                                    Overrides option '--color'
  -w, --wrap [<wrap>...]            Line wrapping for formatted commit text. Default: 'auto 0 8'
                                    Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
                                    For examples, consult 'git-graph --help'
  -f, --format <format>             Commit format. One of [oneline|short|medium|full|"<string>"].
                                      (First character can be used as abbreviation, e.g. '-f m')
                                    Default: oneline.
                                    For placeholders supported in "<string>", consult 'git-graph --help'
  -r, --reverse                     Reverse the order of commits.
  -l, --local                       Show only local branches, no remotes.
      --svg                         Render graph as SVG instead of text-based.
  -d, --debug                       Additional debug output and graphics.
  -S, --sparse                      Print a less compact graph: merge lines point to target lines
                                    rather than merge commits.
  -s, --style <style>               Output style. One of [normal/thin|round|bold|double|ascii].
                                      (First character can be used as abbreviation, e.g. '-s r')
  -h, --help                        Print help (see more with '--help')
  -V, --version                     Print version`;

const MODEL_HELP = `Prints or permanently sets the branching model for a repository.

Usage: executable model [OPTIONS] [model]

Arguments:
  [model]  The branching model to be used. Available presets are [simple|git-flow|none].
           When not given, prints the currently set model.

Options:
  -l, --list  List all available branching models.
  -h, --help  Print help`;

function die(msg, code=1) { console.error(msg); process.exit(code); }
function git(cwd, args, opts={}) {
  try { return execFileSync('git', args, {cwd, encoding:'utf8', stdio:['ignore','pipe', opts.stderr || 'pipe']}); }
  catch(e) { if (opts.allow) return null; throw e; }
}
function repoRoot(p) {
  const out = git(p, ['rev-parse','--show-toplevel'], {allow:true});
  if (out == null) return null;
  return out.trim();
}
function validModel(m) { return ['none','simple','git-flow'].includes(m) || fs.existsSync(path.join(process.env.HOME||'.','.config','git-graph','models',m+'.toml')); }

function parse(argv) {
  const o = {path:'.', model:null, max:null, style:'normal', format:'oneline', reverse:false, local:false, svg:false, noColor:false, color:'auto', debug:false, sparse:false, cmd:null, cmdArgs:[]};
  for (let i=0;i<argv.length;i++) {
    const a=argv[i];
    if (a==='help') { o.cmd='help'; continue; }
    if (a==='model') { o.cmd='model'; o.cmdArgs=argv.slice(i+1); break; }
    if (a==='-h') { console.log(HELP_SHORT); process.exit(0); }
    if (a==='--help') { console.log(HELP_LONG); process.exit(0); }
    if (a==='-V'||a==='--version') { console.log(VERSION); process.exit(0); }
    if (a==='-p'||a==='--path') o.path=argv[++i];
    else if (a.startsWith('--path=')) o.path=a.slice(7);
    else if (a==='-m'||a==='--model') o.model=argv[++i];
    else if (a.startsWith('--model=')) o.model=a.slice(8);
    else if (a==='-n'||a==='--max-count') o.max=argv[++i];
    else if (a.startsWith('--max-count=')) o.max=a.slice(12);
    else if (a==='-s'||a==='--style') o.style=argv[++i];
    else if (a.startsWith('--style=')) o.style=a.slice(8);
    else if (a==='-f'||a==='--format') o.format=argv[++i];
    else if (a.startsWith('--format=')) o.format=a.slice(9);
    else if (a==='-r'||a==='--reverse') o.reverse=true;
    else if (a==='-l'||a==='--local') o.local=true;
    else if (a==='--svg') o.svg=true;
    else if (a==='--debug'||a==='-d') o.debug=true;
    else if (a==='--sparse'||a==='-S') o.sparse=true;
    else if (a==='--no-color') o.noColor=true;
    else if (a==='--color') o.color=argv[++i];
    else if (a.startsWith('--color=')) o.color=a.slice(8);
    else if (a==='--wrap'||a==='-w') { while (argv[i+1] && !argv[i+1].startsWith('-')) i++; }
    else if (a==='--skip-repo-owner-validation') {}
    else if (a.startsWith('-')) die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.`,2);
    else die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.`,2);
  }
  return o;
}

function modelCmd(opts) {
  let args=opts.cmdArgs, list=false, model=null;
  for (let i=0;i<args.length;i++) {
    const a=args[i];
    if (a==='-h'||a==='--help') { console.log(MODEL_HELP); return; }
    if (a==='-l'||a==='--list') list=true;
    else if (a.startsWith('-')) die(`error: unexpected argument '${a}' found`,2);
    else model=a;
  }
  if (list) { console.log('none\nsimple\ngit-flow'); return; }
  const root=repoRoot(opts.path);
  if (!root) die(`ERROR: could not find repository at '${opts.path}'\n       Navigate into a repository before running git-graph, or use option --path`);
  if (!model) {
    const v=git(root,['config','--get','git-graph.model'],{allow:true});
    process.stdout.write(v==null ? 'No branching model set' : v.trim());
    return;
  }
  if (!validModel(model)) die(`ERROR: No branching model named '${model}' found in ${process.env.HOME||'/home/agent'}/.config/git-graph/models\n       Available models are: none, simple, git-flow`);
  git(root,['config','git-graph.model',model]);
  process.stdout.write(`Branching model set to '${model}'`);
}

function collectRefs(cwd) {
  const map = new Map();
  const out = git(cwd, ['for-each-ref','--format=%(objectname)%09%(refname:short)%09%(refname)%09%(HEAD)','refs/heads','refs/remotes','refs/tags'], {allow:true}) || '';
  for (const line of out.trim().split(/\n/).filter(Boolean)) {
    const [sha, short, full, head] = line.split('\t');
    if (!map.has(sha)) map.set(sha, []);
    let txt = short;
    if (full.startsWith('refs/remotes/') && short.endsWith('/HEAD')) continue;
    if (full.startsWith('refs/tags/')) txt = '[' + short + ']';
    else if (head === '*') txt = 'HEAD -> ' + short;
    map.get(sha).push({txt, tag: full.startsWith('refs/tags/'), head: head==='*'});
  }
  for (const arr of map.values()) arr.sort((a,b)=>(a.tag-b.tag)||(b.head-a.head)||a.txt.localeCompare(b.txt));
  return map;
}

function commitData(cwd, shas) {
  const m=new Map();
  if (!shas.length) return m;
  const fmt = ['%H','%h','%P','%p','%s','%b','%B','%an','%ae','%ad','%as','%ar','%cn','%ce','%cd','%cs','%cr'].join('%x1f')+'%x1e';
  const out=git(cwd,['log','--date=default','--format='+fmt, ...shas]);
  for (const rec of out.split('\x1e')) {
    if (!rec.trim()) continue;
    const f=rec.replace(/^\n/,'').split('\x1f');
    m.set(f[0], {H:f[0],h:f[1],P:f[2],p:f[3],s:f[4],b:f[5]||'',B:f[6]||'',an:f[7],ae:f[8],ad:f[9],as:f[10],ar:f[11],cn:f[12],ce:f[13],cd:f[14],cs:f[15],cr:f[16]});
  }
  return m;
}

function refText(refs, sha) {
  const arr=refs.get(sha)||[];
  if (!arr.length) return '';
  const branches=arr.filter(x=>!x.tag).map(x=>x.txt);
  const tags=arr.filter(x=>x.tag).map(x=>x.txt);
  let parts=[];
  if (branches.length) parts.push('('+branches.join(', ')+')');
  parts.push(...tags);
  return ' '+parts.join(' ');
}

function applyPlaceholders(fmt, c, refs) {
  const vals = {H:c.H,h:c.h,P:c.P,p:c.p,d:refText(refs,c.H),s:c.s,b:c.b.trimEnd(),B:c.B.trimEnd(),an:c.an,ae:c.ae,ad:c.ad,as:c.as,ar:c.ar,cn:c.cn,ce:c.ce,cd:c.cd,cs:c.cs,cr:c.cr,n:'\n'};
  return fmt.replace(/%([+\- ])?(H|h|P|p|d|s|b|B|an|ae|ad|as|ar|cn|ce|cd|cs|cr|n)/g, (all, mod, key, off, str) => {
    const v=vals[key] ?? '';
    if (mod==='+') return v ? '\n'+v : '';
    if (mod===' ') return v ? ' '+v : '';
    if (mod==='-') return v ? v : '';
    return v;
  });
}

function formatCommit(fmt, c, refs) {
  const dec=refText(refs,c.H);
  const merge = c.p && c.p.includes(' ') ? 'Merge: '+c.p+'\n' : '';
  const body = c.b.trimEnd();
  const indented = '    '+c.s + (body ? '\n\n' + body.split('\n').map(l=>'    '+l).join('\n') : '');
  const f=fmt.toLowerCase();
  if (f==='oneline'||f==='o') return `${c.h}${dec} ${c.s}`;
  if (f==='short'||f==='s') return `commit ${c.H}${dec}\n${merge}Author: ${c.an} <${c.ae}>\n\n${indented}\n`;
  if (f==='medium'||f==='m') return `commit ${c.H}${dec}\n${merge}Author: ${c.an} <${c.ae}>\nDate:   ${c.ad}\n\n${indented}\n`;
  if (f==='full'||f==='f') return `commit ${c.H}${dec}\n${merge}Author: ${c.an} <${c.ae}>\nCommit: ${c.cn} <${c.ce}>\nDate:   ${c.ad}\n\n${indented}\n`;
  return applyPlaceholders(fmt, c, refs);
}

function styleChars(style) {
  const k = (style||'normal')[0];
  if (k==='a') return {star:'*', merge:'o', v:'|', h:'-', l:"'", r:'.'};
  if (k==='b') return {star:'●', merge:'○', v:'┃', h:'━', l:'┛', r:'┓'};
  if (k==='d') return {star:'●', merge:'○', v:'║', h:'═', l:'╝', r:'╗'};
  if (k==='r') return {star:'●', merge:'○', v:'│', h:'─', l:'╯', r:'╮'};
  return {star:'●', merge:'○', v:'│', h:'─', l:'┘', r:'┐'};
}
function transformPrefix(p, isMerge, style) {
  const ch=styleChars(style);
  let s=p.replace(/\*/g, isMerge ? ch.merge : ch.star).replace(/\|/g,ch.v).replace(/-/g,ch.h).replace(/\\/g,ch.r).replace(/\//g,'┌').replace(/_/g,ch.h);
  if (isMerge && !s.includes('<')) s = s.replace(ch.merge, ch.merge + '<' + ch.r);
  if (style[0]==='a') s=s.replace(/┌/g,'.');
  else s=s.replace(/┌/g,'┌');
  return s;
}
function contPrefix(p, style) {
  const ch=styleChars(style);
  return p.replace(/[●○*o]/, ch.v).replace(/\*/g,ch.v).replace(/o/g,ch.v);
}

function svg(cwd, opts) {
  const rev = git(cwd, ['rev-list','--topo-order','--all'].concat(opts.max?['--max-count='+opts.max]:[]), {allow:true}) || '';
  const shas=rev.trim().split(/\n/).filter(Boolean);
  const h=Math.max(45, shas.length*30+15), w=30;
  let out=`<svg height="${h}" viewBox="0 0 ${w} ${h}" width="${w}" xmlns="http://www.w3.org/2000/svg">\n`;
  shas.forEach((sha,i)=>{ const y=15+i*30; if(i>0) out+=`<line stroke="blue" stroke-width="2" x1="15" x2="15" y1="${y-30}" y2="${y}"/>\n`; out+=`<circle cx="15" cy="${y}" fill="blue" r="4" stroke="blue" stroke-width="1"/>\n`; });
  out+='</svg>\n'; process.stdout.write(out);
}

function graph(opts) {
  const root=repoRoot(opts.path);
  if (!root) die(`ERROR: could not find repository at '${opts.path}'\n       Navigate into a repository before running git-graph, or use option --path`);
  const model=opts.model || (git(root,['config','--get','git-graph.model'],{allow:true})||'git-flow').trim() || 'git-flow';
  if (!validModel(model)) die(`ERROR: No branching model named '${model}' found in ${process.env.HOME||'/home/agent'}/.config/git-graph/models\n       Available models are: none, simple, git-flow`);
  if (opts.svg) return svg(root, opts);
  const args=['log','--graph','--topo-order'];
  if (opts.local) args.push('--branches','--tags');
  else args.push('--all');
  args.push('--format=%x02%H');
  if (opts.max) args.push('--max-count='+opts.max);
  if (opts.reverse) args.push('--reverse');
  let raw=git(root,args,{allow:true}) || '';
  const shas=[...raw.matchAll(/\x02([0-9a-f]{40})/g)].map(m=>m[1]);
  const data=commitData(root, shas);
  const refs=collectRefs(root);
  const lines=[];
  for (const line of raw.split('\n')) {
    if (line==='') continue;
    const idx=line.indexOf('\x02');
    if (idx>=0) {
      const pre=line.slice(0,idx);
      const sha=line.slice(idx+1).trim();
      const c=data.get(sha); if(!c) continue;
      const isMerge=(c.P||'').includes(' ');
      let gp=transformPrefix(pre, isMerge, opts.style);
      // Make single-lane output very close to the original.
      if (gp.trim()===(isMerge?styleChars(opts.style).merge:styleChars(opts.style).star)) gp=' '+gp.trim()+'  ';
      const formatted=formatCommit(opts.format,c,refs).replace(/\n+$/,'');
      const parts=formatted.split('\n');
      lines.push(gp + parts[0]);
      const cp=contPrefix(gp, opts.style);
      for (let i=1;i<parts.length;i++) lines.push(cp + parts[i]);
    } else {
      if (opts.max) continue;
      const t=transformPrefix(line,false,opts.style).replace(/\\/g,styleChars(opts.style).r).replace(/\//g,styleChars(opts.style).l);
      if (t.trim()) lines.push(t);
    }
  }
  process.stdout.write(lines.join('\n') + (lines.length?'\n':''));
}

function main(){
  const opts=parse(process.argv.slice(2));
  if (opts.cmd==='help') { console.log(HELP_LONG); return; }
  if (opts.cmd==='model') return modelCmd(opts);
  graph(opts);
}
main();
