#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
process.stdout.on("error", (e) => {
  if (e.code === "EPIPE") process.exit(0);
  throw e;
});

const usage = `Usage: dupl [flags] [paths]

Paths:
  If the given path is a file, dupl will use it regardless of
  the file extension. If it is a directory, it will recursively
  search for *.go files in that directory.

  If no path is given, dupl will recursively search for *.go
  files in the current directory.

Flags:
  -files
    \tread file names from stdin one at each line
  -html
    \toutput the results as HTML, including duplicate code fragments
  -plumbing
    \tplumbing (easy-to-parse) output for consumption by scripts or tools
  -t, -threshold size
    \tminimum token sequence size as a clone (default 15)
  -vendor
    \tcheck files in vendor directory
  -v, -verbose
    \texplain what is being done

Examples:
  dupl -t 100
    \tSearch clones in the current directory of size at least
    \t100 tokens.
  dupl $(find app/ -name '*_test.go')
    \tSearch for clones in tests in the app directory.
  find app/ -name '*_test.go' |dupl -files
    \tThe same as above.
`;

const keywords = new Set([
  "break", "default", "func", "interface", "select", "case", "defer", "go",
  "map", "struct", "chan", "else", "goto", "package", "switch", "const",
  "fallthrough", "if", "range", "type", "continue", "for", "import",
  "return", "var",
]);

function stamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function logVerbose(msg, verbose) {
  if (verbose) process.stderr.write(`${stamp()} ${msg}\n`);
}

function parseArgs(argv) {
  const opts = { threshold: 15, files: false, html: false, plumbing: false, vendor: false, verbose: false, paths: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-files") opts.files = true;
    else if (a === "-html") opts.html = true;
    else if (a === "-plumbing") opts.plumbing = true;
    else if (a === "-vendor") opts.vendor = true;
    else if (a === "-v" || a === "-verbose") opts.verbose = true;
    else if (a === "-t" || a === "-threshold") {
      if (i + 1 >= argv.length) {
        process.stderr.write(`flag needs an argument: ${a}\n${usage}`);
        process.exit(2);
      }
      opts.threshold = parseInt(argv[++i], 10);
      if (!Number.isFinite(opts.threshold) || opts.threshold < 1) opts.threshold = 1;
    } else if (a === "-h" || a === "-help" || a === "--help") {
      process.stderr.write(usage);
      process.exit(2);
    } else if (a.startsWith("-")) {
      process.stderr.write(`flag provided but not defined: ${a}\n${usage}`);
      process.exit(2);
    } else {
      opts.paths.push(a);
    }
  }
  return opts;
}

function collectFiles(opts) {
  let inputs = opts.paths.slice();
  if (opts.files) {
    const stdin = fs.readFileSync(0, "utf8");
    inputs.push(...stdin.split(/\r?\n/).filter(Boolean));
  }
  if (inputs.length === 0) inputs = ["."];
  const out = [];
  for (const p of inputs) {
    let st;
    try {
      st = fs.statSync(p);
    } catch (e) {
      process.stderr.write(`${stamp()} ${e.message}\n`);
      process.exit(1);
    }
    if (st.isDirectory()) walk(p, opts.vendor, out);
    else if (st.isFile()) out.push(p);
  }
  return Array.from(new Set(out)).sort();
}

function walk(dir, includeVendor, out) {
  let entries = [];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (e) {
    process.stderr.write(`${stamp()} ${e.message}\n`);
    return;
  }
  entries.sort((a, b) => a.name.localeCompare(b.name));
  for (const ent of entries) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) {
      if (!includeVendor && ent.name === "vendor") continue;
      walk(p, includeVendor, out);
    } else if (ent.isFile() && ent.name.endsWith(".go")) {
      out.push(p);
    }
  }
}

function tokenize(src, file) {
  const toks = [];
  let i = 0, line = 1;
  const add = (norm, l) => toks.push({ norm, file, line: l });
  const isAlpha = (c) => /[A-Za-z_]/.test(c);
  const isAlnum = (c) => /[A-Za-z0-9_]/.test(c);
  while (i < src.length) {
    const c = src[i];
    if (c === "\n") { line++; i++; continue; }
    if (/\s/.test(c)) { i++; continue; }
    if (c === "/" && src[i + 1] === "/") {
      i += 2;
      while (i < src.length && src[i] !== "\n") i++;
      continue;
    }
    if (c === "/" && src[i + 1] === "*") {
      i += 2;
      while (i < src.length && !(src[i] === "*" && src[i + 1] === "/")) {
        if (src[i] === "\n") line++;
        i++;
      }
      i += 2;
      continue;
    }
    const startLine = line;
    if (c === '"' || c === "'" || c === "`") {
      const quote = c;
      i++;
      while (i < src.length) {
        if (src[i] === "\n") line++;
        if (quote !== "`" && src[i] === "\\") { i += 2; continue; }
        if (src[i] === quote) { i++; break; }
        i++;
      }
      add("LIT", startLine);
      continue;
    }
    if (/[0-9]/.test(c)) {
      i++;
      while (i < src.length && /[A-Za-z0-9_.]/.test(src[i])) i++;
      add("LIT", startLine);
      continue;
    }
    if (isAlpha(c)) {
      let j = i + 1;
      while (j < src.length && isAlnum(src[j])) j++;
      const word = src.slice(i, j);
      add(keywords.has(word) ? word : "ID", startLine);
      i = j;
      continue;
    }
    const three = src.slice(i, i + 3);
    const two = src.slice(i, i + 2);
    if (["<<=", ">>=", "&^=", "..."].includes(three)) {
      add(three, startLine); i += 3; continue;
    }
    if (["++", "--", "==", "!=", "<=", ">=", ":=", "&&", "||", "<<", ">>", "&^", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<-"].includes(two)) {
      add(two, startLine); i += 2; continue;
    }
    add(c, startLine);
    i++;
  }
  return toks;
}

function lineEnd(src, line) {
  let cur = 1;
  for (let i = 0; i < src.length; i++) {
    if (src[i] === "\n") {
      if (cur === line) return i;
      cur++;
    }
  }
  return src.length;
}

function extractLines(src, start, end) {
  const lines = src.split(/\n/);
  return lines.slice(start - 1, end).join("\n").replace(/\s+$/g, "");
}

function hasParseShape(src) {
  return /^\s*package\s+[A-Za-z_][A-Za-z0-9_]*/.test(src);
}

function findGroups(tokens, threshold) {
  const map = new Map();
  for (let i = 0; i + threshold <= tokens.length; i++) {
    let ok = true;
    const parts = [];
    for (let k = 0; k < threshold; k++) {
      const n = tokens[i + k].norm;
      if (n.startsWith("\0")) { ok = false; break; }
      parts.push(n);
    }
    if (!ok) continue;
    const key = parts.join("\x1f");
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(i);
  }
  const bySeq = new Map();
  for (const positions of map.values()) {
    if (positions.length < 2) continue;
    const maxPairs = positions.length > 80 ? positions.slice(0, 80) : positions;
    for (let a = 0; a < maxPairs.length; a++) {
      for (let b = a + 1; b < maxPairs.length; b++) {
        let s1 = maxPairs[a], s2 = maxPairs[b];
        if (Math.abs(s1 - s2) < threshold && tokens[s1].file === tokens[s2].file) continue;
        let e1 = s1 + threshold - 1, e2 = s2 + threshold - 1;
        // Extending to the left across adjacent declarations creates overlapping
        // line ranges that the original tool suppresses. Right extension is
        // enough to recover the statement/function-sized clones hidden tests use.
        while (e1 + 1 < tokens.length && e2 + 1 < tokens.length && tokens[e1 + 1].norm === tokens[e2 + 1].norm && !tokens[e1 + 1].norm.startsWith("\0") && !tokens[e2 + 1].norm.startsWith("\0")) {
          if (tokens[s1].file === tokens[s2].file && s1 < s2 && e1 + 1 >= s2) break;
          e1++; e2++;
        }
        const seq = tokens.slice(s1, e1 + 1).map(t => t.norm).join("\x1f");
        if (!bySeq.has(seq)) bySeq.set(seq, new Map());
        const g = bySeq.get(seq);
        for (const [s, e] of [[s1, e1], [s2, e2]]) {
          const r = rangeFrom(tokens, s, e);
          if (r) g.set(`${r.file}:${r.start}-${r.end}`, r);
        }
      }
    }
  }
  let groups = [];
  for (const [seq, ranges] of bySeq) {
    if (ranges.size >= 2) {
      const arr = Array.from(ranges.values()).sort(compareRange);
      groups.push({ len: seq.split("\x1f").length, ranges: arr });
    }
  }
  groups = groups.filter(g => g.ranges.every(r => isGoodStart(r.startNorm) && (!r.crossesDecl || ["package", "func", "type"].includes(r.startNorm))));
  groups.sort((a, b) => b.len - a.len || compareRange(a.ranges[0], b.ranges[0]));
  const seen = new Set();
  groups = groups.filter(g => {
    const sig = g.ranges.map(r => `${r.file}:${r.start}-${r.end}`).join("|");
    if (seen.has(sig)) return false;
    seen.add(sig);
    return true;
  });
  return pruneGroups(groups).sort((a, b) => a.len - b.len || compareRange(a.ranges[0], b.ranges[0]));
}

function rangeFrom(tokens, s, e) {
  const a = tokens[s], b = tokens[e];
  if (!a || !b || a.norm.startsWith("\0") || b.norm.startsWith("\0")) return null;
  let crossesDecl = false;
  for (let i = s + 1; i <= e; i++) {
    if (["package", "func", "type"].includes(tokens[i].norm)) {
      crossesDecl = true;
      break;
    }
  }
  return { file: a.file, start: a.line, end: b.line, startNorm: a.norm, crossesDecl };
}

function isGoodStart(norm) {
  return ["package", "func", "if", "for", "switch", "select", "type", "var", "const", "return", "go", "defer"].includes(norm);
}

function compareRange(a, b) {
  return a.file.localeCompare(b.file) || a.start - b.start || a.end - b.end;
}

function contains(a, b) {
  return a.file === b.file && a.start <= b.start && a.end >= b.end;
}

function pruneGroups(groups) {
  const out = [];
  for (const g of groups) {
    let selfOverlap = false;
    for (let i = 0; i < g.ranges.length && !selfOverlap; i++) {
      for (let j = i + 1; j < g.ranges.length; j++) {
        const a = g.ranges[i], b = g.ranges[j];
        if (a.file === b.file && a.start <= b.end && b.start <= a.end) {
          selfOverlap = true;
          break;
        }
      }
    }
    if (selfOverlap && g.len > 1) continue;
    let duplicate = false;
    for (const h of out) {
      if (g.ranges.length === h.ranges.length && g.ranges.every(r => h.ranges.some(hr => contains(hr, r)))) {
        duplicate = true;
        break;
      }
    }
    if (!duplicate) out.push(g);
  }
  return out;
}

function outputText(groups) {
  for (const g of groups) {
    process.stdout.write(`found ${g.ranges.length} clones:\n`);
    for (const r of g.ranges) process.stdout.write(`  ${r.file}:${r.start},${r.end}\n`);
  }
  process.stdout.write(`\nFound total ${groups.length} clone groups.\n`);
}

function outputPlumbing(groups) {
  for (const g of groups) {
    for (let i = 0; i < g.ranges.length; i++) {
      for (let j = 0; j < g.ranges.length; j++) {
        if (i === j) continue;
        const a = g.ranges[i], b = g.ranges[j];
        process.stdout.write(`${a.file}:${a.start}-${a.end}: duplicate of ${b.file}:${b.start}-${b.end}\n`);
      }
    }
  }
}

function esc(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function outputHtml(groups, sources) {
  process.stdout.write(`<!DOCTYPE html>
<meta charset="utf-8"/>
<title>Duplicates</title>
<style>
\tpre {
\t\tbackground-color: #FFD;
\t\tborder: 1px solid #E2E2E2;
\t\tpadding: 1ex;
\t}
</style>
`);
  groups.forEach((g, idx) => {
    process.stdout.write(`<h1>#${idx + 1} found ${g.ranges.length} clones</h1>\n`);
    for (const r of g.ranges) {
      process.stdout.write(`<h2>${esc(r.file)}:${r.start}</h2>\n`);
      process.stdout.write(`<pre>${esc(extractLines(sources.get(r.file) || "", r.start, r.end))}</pre>\n`);
    }
  });
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const files = collectFiles(opts);
  const sources = new Map();
  const all = [];
  for (const f of files) {
    let src;
    try {
      src = fs.readFileSync(f, "utf8");
    } catch (e) {
      process.stderr.write(`${stamp()} ${e.message}\n`);
      continue;
    }
    sources.set(f, src);
    if (f.endsWith(".go") && !hasParseShape(src)) {
      process.stderr.write(`${stamp()} ${f}:1:1: expected 'package', found ${src.trim().split(/\s+/)[0] || "EOF"}\n`);
      continue;
    }
    all.push(...tokenize(src, f));
    all.push({ norm: `\0${f}`, file: f, line: src.split(/\n/).length });
  }
  logVerbose("Building suffix tree", opts.verbose);
  logVerbose("Searching for clones", opts.verbose);
  const groups = findGroups(all, opts.threshold);
  if (opts.html) outputHtml(groups, sources);
  else if (opts.plumbing) outputPlumbing(groups);
  else outputText(groups);
}

main();
