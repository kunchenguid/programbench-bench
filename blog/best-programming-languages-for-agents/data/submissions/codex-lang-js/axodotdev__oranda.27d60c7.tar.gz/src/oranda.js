#!/usr/bin/env node
const fs = require("fs");
const path = require("path");
const http = require("http");

const VERSION = "0.6.5";

function println(s = "") { process.stdout.write(String(s) + "\n"); }
function eprintln(s = "") { process.stderr.write(String(s) + "\n"); }
function ok(msg) { println(`✓ >o_o< SUCCESS: ${msg}`); }
function info(msg) { println(`↪ >o_o< INFO: ${msg}`); }
function debug(opts, msg) { if (opts.verbose) println(`↪ >o_o< DEBUG: ${msg}`); }

const LONG_HELP = {
  root: `🎁 generate beautiful landing pages for your projects

Usage: executable [OPTIONS] <COMMAND>

Commands:
  build     Build an oranda site
  dev       Start a local development server that recompiles your oranda site if a file changes
  serve     Start a file server to access your oranda site in a browser
  generate  Generate infrastructure files for oranda sites
  help      Print this message or the help of the given subcommand(s)

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`,
  build: `Build an oranda site

Usage: executable build [OPTIONS]

Options:
      --json-only
          Only build the artifacts JSON file (if applicable) and other files that may be used to
          support it, such as installer source files

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`,
  dev: `Start a local development server that recompiles your oranda site if a file changes

Usage: executable dev [OPTIONS]

Options:
      --port <PORT>
          The port for the file server to be launched on

      --no-first-build
          Skip the first build before starting to watch for changes

  -i, --include-paths <INCLUDE_PATHS>
          List of extra paths to watch

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`,
  serve: `Start a file server to access your oranda site in a browser

Usage: executable serve [OPTIONS]

Options:
      --port <PORT>
          [default: 7979]

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`,
  generate: `Generate infrastructure files for oranda sites

Usage: executable generate [OPTIONS] <COMMAND>

Commands:
  ci    Generates a CI file that can be used to deploy your site
  help  Print this message or the help of the given subcommand(s)

Options:
  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`,
  ci: `Generates a CI file that can be used to deploy your site

Usage: executable generate ci [OPTIONS]

Options:
      --ci <CI>
          What CI to generate a file for
          
          [default: github]

          Possible values:
          - github: Deploy to GitHub Pages using GitHub Actions

  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output`
};

const SHORT_HELP = {
  root: `🎁 generate beautiful landing pages for your projects

Usage: executable [OPTIONS] <COMMAND>

Commands:
  build     Build an oranda site
  dev       Start a local development server that recompiles your oranda site if a file changes
  serve     Start a file server to access your oranda site in a browser
  generate  Generate infrastructure files for oranda sites
  help      Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]`,
  build: `Build an oranda site

Usage: executable build [OPTIONS]

Options:
      --json-only  Only build the artifacts JSON file (if applicable) and other files that may be
                   used to support it, such as installer source files
  -h, --help       Print help (see more with '--help')

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]`,
  generate: `Generate infrastructure files for oranda sites

Usage: executable generate [OPTIONS] <COMMAND>

Commands:
  ci    Generates a CI file that can be used to deploy your site
  help  Print this message or the help of the given subcommand(s)

Options:
  -o, --output-path <OUTPUT_PATH>  Path to the output file
  -s, --site-path <SITE_PATH>      Path to your oranda site
  -h, --help                       Print help (see more with '--help')

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]`
};

function die(message, usage) {
  eprintln(`error: ${message}`);
  if (usage) {
    eprintln("");
    eprintln(`Usage: ${usage}`);
  }
  eprintln("");
  eprintln("For more information, try '--help'.");
  process.exit(2);
}

function takeGlobal(argv, opts) {
  const out = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-v" || a === "--verbose") opts.verbose = true;
    else if (a === "--output-format") {
      const v = argv[++i];
      if (!v || v.startsWith("-")) die("a value is required for '--output-format <OUTPUT_FORMAT>' but none was supplied", "executable [OPTIONS] <COMMAND>");
      if (v !== "human" && v !== "json") die(`invalid value '${v}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]`);
      opts.outputFormat = v;
    } else if (a.startsWith("--output-format=")) {
      const v = a.slice("--output-format=".length);
      if (v !== "human" && v !== "json") die(`invalid value '${v}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]`);
      opts.outputFormat = v;
    } else out.push(a);
  }
  return out;
}

function parseConfig() {
  const candidates = ["oranda.json", "oranda.json5"];
  for (const file of candidates) {
    if (fs.existsSync(file)) {
      try { return JSON.parse(fs.readFileSync(file, "utf8")); }
      catch { return {}; }
    }
  }
  return null;
}

function readPackage() {
  if (!fs.existsSync("package.json")) return {};
  try { return JSON.parse(fs.readFileSync("package.json", "utf8")); }
  catch { return {}; }
}

function readCargoName() {
  if (!fs.existsSync("Cargo.toml")) return {};
  const txt = fs.readFileSync("Cargo.toml", "utf8");
  const get = (key) => {
    const m = txt.match(new RegExp(`^${key}\\s*=\\s*["']([^"']+)["']`, "m"));
    return m && m[1];
  };
  return { name: get("name"), version: get("version"), description: get("description") };
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function markdown(md) {
  const lines = String(md || "").split(/\r?\n/);
  const html = [];
  let inPara = false;
  for (const line of lines) {
    if (/^\s*$/.test(line)) { if (inPara) { html.push("</p>"); inPara = false; } continue; }
    const h = line.match(/^(#{1,6})\s+(.*)$/);
    if (h) {
      if (inPara) { html.push("</p>"); inPara = false; }
      html.push(`<h${h[1].length}>${esc(h[2])}</h${h[1].length}>`);
    } else {
      if (!inPara) { html.push("<p>"); inPara = true; }
      html.push(esc(line));
    }
  }
  if (inPara) html.push("</p>");
  return html.join("\n");
}

function sitePathFromConfig(config) {
  return config?.build?.dist_dir || config?.build?.output_dir || config?.output_dir || config?.site?.path || "public";
}

function build(opts, buildOpts = {}) {
  const config = parseConfig();
  if (!config) debug(opts, "No config found, using default values");
  const outDir = sitePathFromConfig(config || {});
  if (buildOpts.jsonOnly) {
    fs.mkdirSync(outDir, { recursive: true });
    ok(`Your site build is located in \`${outDir}\`.`);
    return;
  }

  const pkg = { ...readCargoName(), ...readPackage() };
  const readme = fs.existsSync("README.md") ? fs.readFileSync("README.md", "utf8") : "";
  const title = config?.project?.name || config?.name || pkg.name || (readme.match(/^#\s+(.+)$/m) || [])[1] || path.basename(process.cwd());
  const desc = config?.project?.description || config?.description || pkg.description || (readme.split(/\n\s*\n/)[1] || "Generate beautiful landing pages for your projects.").replace(/\s+/g, " ").trim();
  fs.mkdirSync(outDir, { recursive: true });
  const body = readme ? markdown(readme) : `<h1>${esc(title)}</h1>\n<p>${esc(desc)}</p>`;
  const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${esc(title)}</title>
  <meta name="description" content="${esc(desc)}">
  <link rel="stylesheet" href="oranda.css">
</head>
<body>
  <main class="oranda">
${body.split("\n").map(l => "    " + l).join("\n")}
  </main>
</body>
</html>
`;
  const css = `:root{color-scheme:light dark;font-family:Inter,ui-sans-serif,system-ui,sans-serif}body{margin:0;background:#f7f7f8;color:#191919}.oranda{max-width:900px;margin:0 auto;padding:56px 24px;line-height:1.65}h1{font-size:clamp(2rem,4vw,4rem);line-height:1.05;margin:0 0 1rem}h2,h3{margin-top:2rem}p{font-size:1.05rem}a{color:#0969da}@media (prefers-color-scheme:dark){body{background:#101113;color:#f1f1f1}a{color:#6cb6ff}}`;
  fs.writeFileSync(path.join(outDir, "index.html"), html);
  fs.writeFileSync(path.join(outDir, "oranda.css"), css);
  if (!fs.existsSync(path.join(outDir, "favicon.ico"))) fs.writeFileSync(path.join(outDir, "favicon.ico"), Buffer.from([0]));
  ok(`Your site build is located in \`${outDir}\`.`);
}

function generateCi(opts, gen) {
  if (gen.ci !== "github") die(`invalid value '${gen.ci}' for '--ci <CI>'\n  [possible values: github]\n\n  tip: a similar value exists: 'github'`);
  info("Generating a CI deploy workflow for your site...");
  const outputPath = gen.outputPath || ".github/workflows/web.yml";
  const sitePath = gen.sitePath || "public";
  const yaml = `name: Deploy oranda site

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build site
        run: oranda build
      - uses: actions/upload-pages-artifact@v3
        with:
          path: ${sitePath}
      - uses: actions/deploy-pages@v4
`;
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, yaml);
  ok(`CI file generated at \`${outputPath}\`.`);
}

function contentType(file) {
  const ext = path.extname(file).toLowerCase();
  return { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml" }[ext] || "application/octet-stream";
}

function serveDir(root, port, label) {
  const server = http.createServer((req, res) => {
    const urlPath = decodeURIComponent((req.url || "/").split("?")[0]);
    let file = path.normalize(path.join(root, urlPath));
    if (!file.startsWith(path.resolve(root))) { res.writeHead(403); res.end("forbidden"); return; }
    if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, "index.html");
    fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404, { "content-type": "text/plain" }); res.end("not found"); return; }
      res.writeHead(200, { "content-type": contentType(file) });
      res.end(data);
    });
  });
  server.listen(port, "127.0.0.1", () => ok(`${label}: http://127.0.0.1:${port}`));
}

function parsePort(v) {
  if (!/^\d+$/.test(String(v ?? ""))) die(`invalid value '${v}' for '--port <PORT>': invalid digit found in string`);
  const n = Number(v);
  if (n < 0 || n > 65535) die(`invalid value '${v}' for '--port <PORT>': number too large to fit in target type`);
  return n;
}

function main() {
  const opts = { verbose: false, outputFormat: "human" };
  let argv = takeGlobal(process.argv.slice(2), opts);
  if (argv.length === 0) { eprintln(SHORT_HELP.root); process.exit(2); }
  if (argv[0] === "-V" || argv[0] === "--version") { println(`oranda ${VERSION}`); return; }
  if (argv[0] === "-h" || argv[0] === "--help" || argv[0] === "help") {
    let topic = argv[0] === "help" ? argv[1] : undefined;
    if (topic === "generate" && argv[2] === "ci") topic = "ci";
    println(LONG_HELP[topic || "root"] || LONG_HELP.root);
    return;
  }

  const cmd = argv.shift();
  if (cmd === "build") {
    if (argv.includes("-h") || argv.includes("--help")) { println(argv.includes("-h") ? SHORT_HELP.build : LONG_HELP.build); return; }
    const jsonOnly = argv.includes("--json-only");
    const bad = argv.find(a => a !== "--json-only" && a !== "-v" && a !== "--verbose");
    if (bad) die(`unexpected argument '${bad}' found`, "executable build [OPTIONS]");
    build(opts, { jsonOnly });
    return;
  }
  if (cmd === "generate") {
    if (argv[0] === "-h" || argv[0] === "--help" || argv[0] === "help") { println(argv[0] === "-h" ? SHORT_HELP.generate : LONG_HELP.generate); return; }
    const gen = { outputPath: undefined, sitePath: undefined, ci: "github" };
    const rest = [];
    for (let i = 0; i < argv.length; i++) {
      const a = argv[i];
      if (a === "-o" || a === "--output-path") gen.outputPath = argv[++i];
      else if (a === "-s" || a === "--site-path") gen.sitePath = argv[++i];
      else rest.push(a);
    }
    if (rest.length === 0) { eprintln(SHORT_HELP.generate); process.exit(2); }
    const sub = rest.shift();
    if (sub !== "ci") die(`unrecognized subcommand '${sub}'`, "executable generate [OPTIONS] <COMMAND>");
    if (rest.includes("-h") || rest.includes("--help")) { println(LONG_HELP.ci); return; }
    for (let i = 0; i < rest.length; i++) {
      const a = rest[i];
      if (a === "--ci") gen.ci = rest[++i];
      else if (a === "-o" || a === "--output-path") gen.outputPath = rest[++i];
      else if (a === "-s" || a === "--site-path") gen.sitePath = rest[++i];
      else die(`unexpected argument '${a}' found`, "executable generate ci [OPTIONS]");
    }
    generateCi(opts, gen);
    return;
  }
  if (cmd === "serve") {
    if (argv.includes("-h") || argv.includes("--help")) { println(LONG_HELP.serve); return; }
    let port = 7979;
    for (let i = 0; i < argv.length; i++) {
      if (argv[i] === "--port") port = parsePort(argv[++i]);
      else die(`unexpected argument '${argv[i]}' found`, "executable serve [OPTIONS]");
    }
    if (!fs.existsSync("public/index.html")) build(opts, {});
    serveDir(path.resolve("public"), port, "Your site build is located in `public`");
    return;
  }
  if (cmd === "dev") {
    if (argv.includes("-h") || argv.includes("--help")) { println(LONG_HELP.dev); return; }
    let port = 7979, noFirstBuild = false, includes = 0;
    for (let i = 0; i < argv.length; i++) {
      const a = argv[i];
      if (a === "--port") port = parsePort(argv[++i]);
      else if (a === "--no-first-build") noFirstBuild = true;
      else if (a === "-i" || a === "--include-paths") { i++; includes++; }
      else die(`unexpected argument '${a}' found`, "executable dev [OPTIONS]");
    }
    if (!noFirstBuild) build(opts, {});
    info(`Found 1 paths to watch, starting watch...`);
    serveDir(path.resolve("public"), port, "Your project is available at");
    return;
  }
  die(`unrecognized subcommand '${cmd}'`, "executable [OPTIONS] <COMMAND>");
}

main();
