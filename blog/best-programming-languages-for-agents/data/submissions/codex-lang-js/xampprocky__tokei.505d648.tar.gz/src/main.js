#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = 'tokei 14.0.0 compiled with serialization support: json';

const LANGS = [
  ['ABNF',['abnf']], ['AWK',['awk']], ['ABAP',['abap']], ['ActionScript',['as']],
  ['Ada',['ada','adb','ads','pad']], ['Agda',['agda']], ['Alex',['x']], ['Alloy',['als']],
  ['APL',['apl','aplf','apls']], ['Arduino C++',['ino']], ['AsciiDoc',['adoc','asciidoc']],
  ['ASN.1',['asn1']], ['ASP',['asa','asp']], ['Assembly',['asm']], ['GNU Style Assembly',['s']],
  ['Astro',['astro']], ['ATS',['dats','hats','sats','atxt']], ['AutoHotKey',['ahk']],
  ['Autoconf',['in']], ['Automake',['am']], ['BASH',['bash']], ['Batch',['bat','btm','cmd']],
  ['Bazel',['bzl','bazel','bzlmod']], ['Bicep',['bicep','bicepparam']], ['C',['c','ec','pgc']],
  ['C3',['c3']], ['C Header',['h']], ['CMake',['cmake']], ['C#',['cs','csx']],
  ['C Shell',['csh']], ['Cabal',['cabal']], ['Clojure',['clj']], ['ClojureC',['cljc']],
  ['ClojureScript',['cljs']], ['COBOL',['cob','cbl','ccp','cobol','cpy']],
  ['CoffeeScript',['coffee','cjsx']], ['ColdFusion',['cfm']], ['Coq',['v']],
  ['C++',['cc','cpp','cxx','c++','pcc','tpp']], ['C++ Header',['hh','hpp','hxx','inl','ipp']],
  ['Crystal',['cr']], ['CSS',['css']], ['CUDA',['cu']], ['CUE',['cue']],
  ['Cython',['pyx','pxd','pxi']], ['D',['d']], ['Dart',['dart']], ['Dhall',['dhall']],
  ['Dockerfile',['dockerfile','dockerignore']], ['Elisp',['el']], ['Elixir',['ex','exs']],
  ['Elm',['elm']], ['Erlang',['erl','hrl']], ['F#',['fs','fsi','fsx']],
  ['Fish',['fish']], ['Fortran Legacy',['f','for','ftn']], ['Fortran Modern',['f90','f95','f03','f08']],
  ['GDB',['gdb']], ['GdScript',['gd']], ['Gherkin',['feature']], ['Gleam',['gleam']],
  ['GLSL',['glsl','vert','tesc','tese','geom','frag','comp']], ['Go',['go']], ['GraphQL',['graphql','gql']],
  ['Groovy',['groovy','gradle']], ['Hamlet',['hamlet']], ['Handlebars',['hbs','handlebars']],
  ['Haskell',['hs','lhs']], ['Haxe',['hx']], ['HCL',['hcl','tf']], ['HTML',['html','htm']],
  ['Idris',['idr','lidr']], ['INI',['ini']], ['Isabelle',['thy']], ['Java',['java']],
  ['JavaScript',['js','mjs','cjs']], ['JSON',['json','jsonl']], ['JSX',['jsx']],
  ['Julia',['jl']], ['Julius',['julius']], ['Just',['just']], ['Kotlin',['kt','kts']],
  ['Less',['less']], ['Lisp',['lisp','lsp','cl']], ['LLVM',['ll']], ['Lua',['lua']],
  ['Makefile',['makefile','mk','mak']], ['Markdown',['md','markdown']], ['MDX',['mdx']],
  ['Meson',['meson']], ['Mustache',['mustache']], ['Nim',['nim','nims']], ['Nix',['nix']],
  ['Objective-C',['m']], ['Objective-C++',['mm']], ['OCaml',['ml','mli']],
  ['OpenSCAD',['scad']], ['Org',['org']], ['Pascal',['pas','pp','inc']], ['Perl',['pl','pm','pod']],
  ['PHP',['php','php3','php4','php5','phtml']], ['PowerShell',['ps1','psm1','psd1']],
  ['Processing',['pde']], ['Prolog',['pro','prolog']], ['Protocol Buffers',['proto']],
  ['Python',['py','pyw']], ['QML',['qml']], ['R',['r','R']], ['Racket',['rkt']],
  ['ReStructuredText',['rst']], ['RON',['ron']], ['Ruby',['rb','rake','gemspec']],
  ['Rust',['rs']], ['Sass',['sass','scss']], ['Scala',['scala','sc']], ['Scheme',['scm','ss']],
  ['Shell',['sh']], ['Solidity',['sol']], ['SQL',['sql']], ['Svelte',['svelte']],
  ['SVG',['svg']], ['Swift',['swift']], ['SystemVerilog',['sv','svh']], ['TCL',['tcl']],
  ['TeX',['tex','sty']], ['Plain Text',['text','txt']], ['Thrift',['thrift']], ['TOML',['toml']],
  ['TSX',['tsx']], ['Twig',['twig']], ['TypeScript',['ts','mts','cts']], ['Vala',['vala']],
  ['VBScript',['vbs']], ['Verilog',['vg','vh']], ['VHDL',['vhd','vhdl']], ['Vim Script',['vim']],
  ['Visual Basic',['vb']], ['Visual Studio Solution',['sln']], ['Vue',['vue']], ['WebAssembly',['wat','wast']],
  ['Wolfram',['nb','wl']], ['XSL',['xsl','xslt']], ['XAML',['xaml']], ['XML',['xml']],
  ['YAML',['yaml','yml']], ['Zig',['zig']], ['Zsh',['zsh']]
];

const EXT = new Map();
for (const [name, exts] of LANGS) for (const e of exts) EXT.set(e.toLowerCase(), name);
const NAME = new Map();
for (const [name] of LANGS) NAME.set(name.toLowerCase().replace(/[^a-z0-9]/g,''), name);

const COMMENT = {
  Rust: {line:['//'], block:[['/*','*/']]}, C: {line:['//'], block:[['/*','*/']]},
  'C Header': {line:['//'], block:[['/*','*/']]}, 'C++': {line:['//'], block:[['/*','*/']]},
  'C++ Header': {line:['//'], block:[['/*','*/']]}, Java: {line:['//'], block:[['/*','*/']]},
  JavaScript: {line:['//'], block:[['/*','*/']]}, TypeScript: {line:['//'], block:[['/*','*/']]},
  JSX: {line:['//'], block:[['/*','*/'],['{/*','*/}']]}, TSX: {line:['//'], block:[['/*','*/'],['{/*','*/}']]},
  Go: {line:['//'], block:[['/*','*/']]}, Swift: {line:['//'], block:[['/*','*/']]},
  Kotlin: {line:['//'], block:[['/*','*/']]}, Scala: {line:['//'], block:[['/*','*/']]},
  PHP: {line:['//','#'], block:[['/*','*/']]}, CSS: {line:[], block:[['/*','*/']]},
  Sass: {line:['//'], block:[['/*','*/']]}, Python: {line:['#'], block:[]},
  Ruby: {line:['#'], block:[]}, Perl: {line:['#'], block:[]}, Shell: {line:['#'], block:[]},
  BASH: {line:['#'], block:[]}, Zsh: {line:['#'], block:[]}, Fish: {line:['#'], block:[]},
  Makefile: {line:['#'], block:[]}, YAML: {line:['#'], block:[]}, TOML: {line:['#'], block:[]},
  R: {line:['#'], block:[]}, PowerShell: {line:['#'], block:[['<#','#>']]},
  Lua: {line:['--'], block:[['--[[',']]']]}, Haskell: {line:['--'], block:[['{-','-}']]},
  SQL: {line:['--'], block:[['/*','*/']]}, HTML: {line:[], block:[['<!--','-->']]},
  XML: {line:[], block:[['<!--','-->']]}, SVG: {line:[], block:[['<!--','-->']]},
  Markdown: {line:[], block:[['<!--','-->']]}, JSON: {line:[], block:[]}
};

const MARKUP_COMMENT_ONLY = new Set(['Markdown','Plain Text','ReStructuredText','Org','AsciiDoc']);
const DATA_AS_CODE = new Set(['JSON','TOML','YAML','INI','RON']);

function wcwidth(s) { return [...s].length; }
function padLeft(n, w) { return String(n).padStart(w); }
function padRight(s, w) {
  s = String(s);
  const len = wcwidth(s);
  return len >= w ? s : s + ' '.repeat(w - len);
}
function fmtNum(n, style) {
  const s = String(n);
  if (style === 'commas') return s.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  if (style === 'dots') return s.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  if (style === 'underscores') return s.replace(/\B(?=(\d{3})+(?!\d))/g, '_');
  return s;
}

function parseArgs(argv) {
  const o = {inputs:[], exclude:[], files:false, hidden:false, languages:false, output:null, streaming:null,
    sort:null, rsort:null, types:null, input:null, compact:false, numFormat:'plain', verbose:0, columns:null,
    noIgnore:false, noIgnoreDot:false, noIgnoreVcs:false, noIgnoreParent:false};
  for (let i=0;i<argv.length;i++) {
    let a = argv[i];
    if (a === '--') { o.inputs.push(...argv.slice(i+1)); break; }
    if (!a.startsWith('-') || a === '-') { o.inputs.push(a); continue; }
    if (a === '-h' || a === '--help') o.help = true;
    else if (a === '-V' || a === '--version') o.version = true;
    else if (a === '-f' || a === '--files') o.files = true;
    else if (a === '-l' || a === '--languages') o.languages = true;
    else if (a === '--hidden') o.hidden = true;
    else if (a === '-C' || a === '--compact') o.compact = true;
    else if (a === '--no-ignore') { o.noIgnore = o.noIgnoreDot = o.noIgnoreVcs = o.noIgnoreParent = true; }
    else if (a === '--no-ignore-dot') o.noIgnoreDot = true;
    else if (a === '--no-ignore-vcs') o.noIgnoreVcs = true;
    else if (a === '--no-ignore-parent') o.noIgnoreParent = true;
    else if (a.startsWith('-v') && /^-v+$/.test(a)) o.verbose += a.length - 1;
    else if (a === '-e' || a === '--exclude') o.exclude.push(argv[++i] || '');
    else if (a.startsWith('--exclude=')) o.exclude.push(a.slice(10));
    else if (a === '-o' || a === '--output') o.output = argv[++i];
    else if (a.startsWith('--output=')) o.output = a.slice(9);
    else if (a === '--streaming') o.streaming = argv[++i];
    else if (a.startsWith('--streaming=')) o.streaming = a.slice(12);
    else if (a === '-s' || a === '--sort') o.sort = argv[++i];
    else if (a.startsWith('--sort=')) o.sort = a.slice(7);
    else if (a === '-r' || a === '--rsort') o.rsort = argv[++i];
    else if (a.startsWith('--rsort=')) o.rsort = a.slice(8);
    else if (a === '-t' || a === '--types' || a === '--type') o.types = argv[++i];
    else if (a.startsWith('--types=')) o.types = a.slice(8);
    else if (a === '-i' || a === '--input') o.input = argv[++i];
    else if (a.startsWith('--input=')) o.input = a.slice(8);
    else if (a === '-n' || a === '--num-format') o.numFormat = argv[++i] || 'plain';
    else if (a.startsWith('--num-format=')) o.numFormat = a.slice(13);
    else if (a === '-c' || a === '--columns') o.columns = Number(argv[++i] || 0);
    else if (a.startsWith('--columns=')) o.columns = Number(a.slice(10));
    else die(`error: unexpected argument '${a}' found\n\nFor more information, try '--help'.`, 2);
  }
  if (!o.inputs.length) o.inputs = ['.'];
  return o;
}

function die(msg, code=1) { console.error(msg); process.exit(code); }

function help() {
  console.log(`Count your code, quickly.
Support this project on GitHub Sponsors: https://github.com/sponsors/XAMPPRocky

Usage: executable [OPTIONS] [input]...

Arguments:
  [input]...  The path(s) to the file or directory to be counted. (default current directory)

Options:
  -c, --columns <columns>              Sets a strict column width of the output, only available for
                                       terminal output.
  -e, --exclude <exclude>              Ignore all files & directories matching the pattern.
  -f, --files                          Will print out statistics on individual files.
  -i, --input <file_input>             Gives statistics from a previous tokei run. Can be given a
                                       file path, or "stdin" to read from stdin.
      --hidden                         Count hidden files.
  -l, --languages                      Prints out supported languages and their extensions.
      --no-ignore                      Don't respect ignore files (.gitignore, .ignore, etc.). This
                                       implies --no-ignore-parent, --no-ignore-dot, and
                                       --no-ignore-vcs.
  -o, --output <output>                Outputs Tokei in a specific format. Compile with additional
                                       features for more format support.
      --streaming <streaming>          prints the (language, path, lines, blanks, code, comments)
                                       records as simple lines or as Json for batch processing
                                       [possible values: simple, json]
  -s, --sort <sort>                    Sort languages based on column [possible values: files,
                                       lines, blanks, code, comments]
  -r, --rsort <rsort>                  Reverse sort languages based on column [possible values:
                                       files, lines, blanks, code, comments]
  -t, --types <types>                  Filters output by language type, separated by a comma. i.e.
                                       -t=Rust,Markdown
  -C, --compact                        Do not print statistics about embedded languages.
  -n, --num-format <num_format_style>  Format of printed numbers, i.e., plain (1234, default),
                                       commas (1,234), dots (1.234), or underscores (1_234). Cannot
                                       be used with --output. [possible values: commas, dots, plain,
                                       underscores]
  -v, --verbose...                     Set log output level:
                                                               1: to show unknown file extensions,
                                                               2: reserved for future debugging,
                                                               3: enable file level trace. Not
                                                               recommended on multiple files
  -h, --help                           Print help
  -V, --version                        Print version`);
}

function printLanguages() {
  const width = 72;
  console.log('━'.repeat(width));
  console.log(`┃ ${padRight('Language',37)} Extensions${' '.repeat(20)}┃`);
  console.log(`┃${'━'.repeat(width-2)}┃`);
  for (const [name, exts] of LANGS) {
    let e = exts.join(', ');
    if (wcwidth(e) > 30) e = e.slice(0,27) + '...';
    console.log(`┃ ${padRight(name,37)} ${padRight(e,30)} ┃`);
  }
  console.log('━'.repeat(width));
}

function languageFor(file) {
  const base = path.basename(file);
  const lower = base.toLowerCase();
  if (lower === 'makefile' || lower === 'gnumakefile') return 'Makefile';
  if (lower === 'dockerfile') return 'Dockerfile';
  if (lower === 'rakefile' || lower === 'gemfile') return 'Ruby';
  if (lower === 'justfile') return 'Just';
  const ext = path.extname(lower).replace(/^\./,'');
  return EXT.get(ext) || null;
}

function normalizeType(s) {
  return NAME.get(String(s).toLowerCase().replace(/[^a-z0-9]/g,'')) || s;
}

function shouldExclude(p, opts) {
  const base = path.basename(p);
  if (!opts.hidden && base.startsWith('.') && base !== '.') return true;
  const rel = path.relative(process.cwd(), p);
  for (const pat of opts.exclude) {
    if (!pat) continue;
    if (globMatch(rel, pat) || globMatch(base, pat) || rel.includes(pat.replace(/^\*\//,''))) return true;
  }
  return false;
}

function globMatch(name, pat) {
  pat = pat.replace(/\\/g,'/');
  name = name.replace(/\\/g,'/');
  const re = '^' + pat.split('').map(ch => {
    if (ch === '*') return '.*';
    if (ch === '?') return '.';
    return ch.replace(/[|\\{}()[\]^$+?.]/g, '\\$&');
  }).join('') + '$';
  return new RegExp(re).test(name);
}

function readIgnoreFile(dir, opts) {
  if (opts.noIgnore) return [];
  const pats = [];
  const files = [];
  if (!opts.noIgnoreVcs) files.push('.gitignore');
  if (!opts.noIgnoreDot) files.push('.ignore','.tokeignore');
  for (const f of files) {
    const fp = path.join(dir, f);
    try {
      for (const line of fs.readFileSync(fp,'utf8').split(/\r?\n/)) {
        const t = line.trim();
        if (t && !t.startsWith('#') && !t.startsWith('!')) pats.push(t);
      }
    } catch {}
  }
  return pats;
}

function collect(inputs, opts) {
  const out = [];
  const walk = (p, inherited) => {
    let st;
    try { st = fs.lstatSync(p); } catch { return; }
    if (shouldExclude(p, opts)) return;
    if (st.isSymbolicLink()) {
      try { st = fs.statSync(p); } catch { return; }
    }
    const base = path.basename(p);
    for (const pat of inherited) {
      if (globMatch(base, pat) || globMatch(path.relative(process.cwd(), p), pat) || (pat.endsWith('/') && base === pat.slice(0,-1))) return;
    }
    if (st.isDirectory()) {
      if (['.git','.hg','.svn','node_modules','target'].includes(base) && !opts.hidden) return;
      const pats = inherited.concat(readIgnoreFile(p, opts));
      let entries = [];
      try { entries = fs.readdirSync(p).sort(); } catch { return; }
      for (const e of entries) walk(path.join(p,e), pats);
    } else if (st.isFile()) {
      const lang = languageFor(p);
      if (lang) out.push(path.resolve(p));
      else if (opts.verbose) console.error(`WARN  tokei::language_type > Unknown extension: ${path.extname(p).replace('.','')}`);
    }
  };
  for (const i of inputs) walk(path.resolve(i), []);
  return out;
}

function stripStrings(line) {
  let out = '', quote = null, esc = false;
  for (let i=0;i<line.length;i++) {
    const c = line[i];
    if (quote) {
      out += ' ';
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === quote) quote = null;
    } else if (c === '"' || c === "'" || c === '`') {
      quote = c; out += ' ';
    } else out += c;
  }
  return out;
}

function classifyLine(line, lang, state) {
  if (line.trim() === '') return 'blanks';
  if (MARKUP_COMMENT_ONLY.has(lang)) return 'comments';
  const spec = COMMENT[lang] || {line:['#'], block:[]};
  let probe = stripStrings(line);
  let hasCode = false, hasComment = false;
  let i = 0;
  while (i < probe.length) {
    if (state.blockEnd) {
      hasComment = true;
      const end = probe.indexOf(state.blockEnd, i);
      if (end < 0) return hasCode ? 'code' : 'comments';
      i = end + state.blockEnd.length;
      state.blockEnd = null;
      continue;
    }
    if (/\s/.test(probe[i])) { i++; continue; }
    let matched = false;
    for (const [start, end] of spec.block || []) {
      if (probe.startsWith(start, i)) {
        hasComment = true; matched = true;
        const j = probe.indexOf(end, i + start.length);
        if (j < 0) { state.blockEnd = end; return hasCode ? 'code' : 'comments'; }
        i = j + end.length;
        break;
      }
    }
    if (matched) continue;
    if ((spec.line || []).some(x => probe.startsWith(x, i))) {
      hasComment = true;
      break;
    }
    hasCode = true;
    i++;
  }
  if (hasCode) return 'code';
  if (hasComment) return 'comments';
  return DATA_AS_CODE.has(lang) ? 'code' : 'code';
}

function countFile(file) {
  const lang = languageFor(file);
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch { return null; }
  text = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const raw = text.length ? text.split('\n') : [];
  if (raw.length && raw[raw.length-1] === '') raw.pop();
  if (lang === 'Markdown' || lang === 'MDX') return countMarkdown(file, lang, raw);
  return {language: lang, name: path.resolve(file), stats: countLines(raw, lang)};
}

function countLines(raw, lang) {
  const state = {};
  const stats = {blanks:0, code:0, comments:0, blobs:{}};
  for (const line of raw) stats[classifyLine(line, lang, state)]++;
  return stats;
}

function fenceLanguage(info) {
  const token = String(info || '').trim().split(/\s+/)[0].replace(/[{}]/g,'').toLowerCase();
  if (!token) return null;
  if (EXT.has(token)) return EXT.get(token);
  return NAME.get(token.replace(/[^a-z0-9]/g,'')) || null;
}

function countMarkdown(file, lang, raw) {
  const stats = {blanks:0, code:0, comments:0, blobs:{}};
  let inFence = false, fence = '', childLang = null, child = [];
  const finishChild = () => {
    if (childLang) {
      const cs = countLines(child, childLang);
      if (!stats.blobs[childLang]) stats.blobs[childLang] = {blanks:0, code:0, comments:0, blobs:{}};
      addStats(stats.blobs[childLang], cs);
    }
    child = []; childLang = null;
  };
  for (const line of raw) {
    const m = line.match(/^\s*(```+|~~~+)\s*([^`]*)$/);
    if (m) {
      if (inFence && m[1][0] === fence[0]) { finishChild(); inFence = false; fence = ''; }
      else if (!inFence) { inFence = true; fence = m[1]; childLang = fenceLanguage(m[2]); }
      stats.comments++;
      continue;
    }
    if (inFence && childLang) child.push(line);
    else if (inFence) stats.comments++;
    else stats[classifyLine(line, lang, {})]++;
  }
  if (inFence) finishChild();
  return {language: lang, name: path.resolve(file), stats};
}

function emptyLang() { return {blanks:0, code:0, comments:0, reports:[], children:{}, inaccurate:false}; }
function addStats(a, s) { a.blanks += s.blanks; a.code += s.code; a.comments += s.comments; }
function lines(s) { return s.blanks + s.code + s.comments; }

function aggregate(reports, opts) {
  const types = opts.types ? new Set(opts.types.split(',').map(x => normalizeType(x.trim())).filter(Boolean)) : null;
  const by = new Map();
  for (const r of reports) {
    if (types && !types.has(r.language)) continue;
    if (!by.has(r.language)) by.set(r.language, emptyLang());
    const l = by.get(r.language);
    addStats(l, r.stats); l.reports.push({stats:r.stats, name:r.name});
    for (const [childLang, childStats] of Object.entries(r.stats.blobs || {})) {
      if (!l.children[childLang]) l.children[childLang] = [];
      l.children[childLang].push({stats:childStats, name:r.name});
    }
  }
  return by;
}

function mergeInput(by, opts) {
  if (!opts.input) return;
  let text = '';
  try { text = opts.input === 'stdin' ? fs.readFileSync(0,'utf8') : fs.readFileSync(opts.input,'utf8'); } catch { return; }
  try {
    const obj = JSON.parse(text);
    for (const [lang, v] of Object.entries(obj)) {
      if (lang === 'Total') continue;
      if (!by.has(lang)) by.set(lang, emptyLang());
      const l = by.get(lang);
      addStats(l, v);
      if (Array.isArray(v.reports)) l.reports.push(...v.reports);
    }
  } catch {}
}

function sortedEntries(by, opts) {
  const arr = [...by.entries()];
  const key = opts.sort || opts.rsort;
  arr.sort((a,b) => {
    let d;
    if (key === 'files') d = b[1].reports.length - a[1].reports.length;
    else if (key === 'lines') d = lines(b[1]) - lines(a[1]);
    else if (key === 'blanks' || key === 'code' || key === 'comments') d = b[1][key] - a[1][key];
    else d = a[0].localeCompare(b[0]);
    if (d === 0) d = a[0].localeCompare(b[0]);
    return opts.rsort && key ? -d : d;
  });
  return arr;
}

function outputJson(by, opts) {
  const obj = {};
  const total = emptyLang();
  total.children = {};
  for (const [lang, l] of sortedEntries(by, opts)) {
    obj[lang] = l;
    addStats(total, l);
    for (const reps of Object.values(l.children || {})) for (const r of reps) addStats(total, r.stats);
    total.children[lang] = l.reports;
  }
  obj.Total = total;
  console.log(JSON.stringify(obj));
}

function outputStreaming(reports, opts) {
  const by = aggregate(reports, opts);
  const filtered = [];
  const allowed = new Set(by.keys());
  for (const r of reports) if (allowed.has(r.language)) filtered.push(r);
  if (opts.streaming === 'simple') {
    console.log(`# ${padRight('language',47)} ${padRight('path',44)} ${padLeft('lines',12)} ${padLeft('code',12)} ${padLeft('comments',12)} ${padLeft('blanks',12)}`);
    console.log(`${'#'.repeat(10)} ${'#'.repeat(80)} ${'#'.repeat(12)} ${'#'.repeat(12)} ${'#'.repeat(12)} ${'#'.repeat(12)}`);
    for (const r of filtered) console.log(`${padLeft(r.language,10)} ${padRight(r.name,80)} ${padLeft(lines(r.stats),12)} ${padLeft(r.stats.code,12)} ${padLeft(r.stats.comments,12)} ${padLeft(r.stats.blanks,12)}`);
  } else if (opts.streaming === 'json') {
    for (const r of filtered) console.log(JSON.stringify({language:r.language, stats:{name:r.name, stats:r.stats}}));
  } else die(`error: invalid value '${opts.streaming}' for '--streaming <streaming>'`, 2);
}

function outputTable(by, opts) {
  const width = opts.columns && opts.columns > 40 ? opts.columns : 81;
  const line = '━'.repeat(width);
  const mid = '─'.repeat(width);
  const nameW = Math.max(14, width - 63);
  const header = ` ${padRight('Language',nameW)} ${padLeft('Files',8)} ${padLeft('Lines',12)} ${padLeft('Code',12)} ${padLeft('Comments',12)} ${padLeft('Blanks',12)}`;
  console.log(line);
  console.log(header);
  console.log(line);
  const total = {files:0, blanks:0, code:0, comments:0};
  for (const [lang, l] of sortedEntries(by, opts)) {
    total.files += l.reports.length; addStats(total, l);
    console.log(` ${padRight(lang,nameW)} ${padLeft(fmtNum(l.reports.length,opts.numFormat),8)} ${padLeft(fmtNum(lines(l),opts.numFormat),12)} ${padLeft(fmtNum(l.code,opts.numFormat),12)} ${padLeft(fmtNum(l.comments,opts.numFormat),12)} ${padLeft(fmtNum(l.blanks,opts.numFormat),12)}`);
    if (!opts.compact) {
      for (const [childLang, reps] of Object.entries(l.children || {}).sort((a,b)=>a[0].localeCompare(b[0]))) {
        const cs = {blanks:0, code:0, comments:0};
        for (const r of reps) addStats(cs, r.stats);
        console.log(` |- ${padRight(childLang,nameW-3)} ${padLeft(fmtNum(reps.length,opts.numFormat),8)} ${padLeft(fmtNum(lines(cs),opts.numFormat),12)} ${padLeft(fmtNum(cs.code,opts.numFormat),12)} ${padLeft(fmtNum(cs.comments,opts.numFormat),12)} ${padLeft(fmtNum(cs.blanks,opts.numFormat),12)}`);
        addStats(total, cs);
      }
      if (Object.keys(l.children || {}).length) {
        const all = {blanks:l.blanks, code:l.code, comments:l.comments};
        for (const reps of Object.values(l.children)) for (const r of reps) addStats(all, r.stats);
        console.log(` ${padRight('(Total)',nameW)} ${' '.repeat(8)} ${padLeft(fmtNum(lines(all),opts.numFormat),12)} ${padLeft(fmtNum(all.code,opts.numFormat),12)} ${padLeft(fmtNum(all.comments,opts.numFormat),12)} ${padLeft(fmtNum(all.blanks,opts.numFormat),12)}`);
      }
    } else {
      for (const reps of Object.values(l.children || {})) for (const r of reps) addStats(total, r.stats);
    }
    if (opts.files) {
      console.log(mid);
      const reps = [...l.reports].sort((a,b)=>a.name.localeCompare(b.name));
      for (const r of reps) {
        let nm = r.name;
        if (wcwidth(nm) > nameW + 9) nm = nm.slice(0, nameW + 6) + '...';
        console.log(` ${padRight(nm,nameW+9)} ${padLeft(fmtNum(lines(r.stats),opts.numFormat),12)} ${padLeft(fmtNum(r.stats.code,opts.numFormat),12)} ${padLeft(fmtNum(r.stats.comments,opts.numFormat),12)} ${padLeft(fmtNum(r.stats.blanks,opts.numFormat),12)}`);
      }
      console.log(mid);
    }
  }
  console.log(line);
  console.log(` ${padRight('Total',nameW)} ${padLeft(fmtNum(total.files,opts.numFormat),8)} ${padLeft(fmtNum(lines(total),opts.numFormat),12)} ${padLeft(fmtNum(total.code,opts.numFormat),12)} ${padLeft(fmtNum(total.comments,opts.numFormat),12)} ${padLeft(fmtNum(total.blanks,opts.numFormat),12)}`);
  console.log(line);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) return help();
  if (opts.version) return console.log(VERSION);
  if (opts.languages) return printLanguages();
  if (opts.output && opts.output !== 'json') {
    die(`error: invalid value '${opts.output}' for '--output <output>': This version of tokei was compiled without any '${opts.output}' serialization support, to enable serialization, reinstall tokei with the features flag.\n\nFor more information, try '--help'.`, 2);
  }
  if (opts.output && opts.numFormat !== 'plain') die("error: the argument '--output <output>' cannot be used with '--num-format <num_format_style>'", 2);
  const files = collect(opts.inputs, opts);
  const reports = files.map(countFile).filter(Boolean);
  if (opts.streaming) return outputStreaming(reports, opts);
  const by = aggregate(reports, opts);
  mergeInput(by, opts);
  if (opts.output === 'json') return outputJson(by, opts);
  outputTable(by, opts);
}

main();
