#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = '0.1.10';

function usage() {
  console.log('Usage: elfcat <filename>');
  console.log('Writes <filename>.html to CWD.');
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function hex(n) {
  const x = typeof n === 'bigint' ? n : BigInt(n);
  return '0x' + x.toString(16);
}

function dec(n) {
  return (typeof n === 'bigint' ? n : BigInt(n)).toString(10);
}

function sizeText(n) {
  const b = Number(n);
  if (!Number.isFinite(b) || b < 1024) return `${b} B`;
  const units = ['KiB', 'MiB', 'GiB', 'TiB'];
  let v = b / 1024, i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  const s = v >= 10 ? v.toFixed(1) : v.toFixed(1);
  return `${s} ${units[i]} (${b} B)`;
}

function num(n, titleHex = true) {
  return `<span class='number' title='${titleHex ? hex(n) : dec(n)}'>${dec(n)}</span>`;
}

function readCString(buf, off) {
  if (off < 0 || off >= buf.length) return '';
  let end = off;
  while (end < buf.length && buf[end] !== 0) end++;
  return buf.slice(off, end).toString('utf8').replace(/\0/g, '');
}

function parseElf(buf) {
  if (buf.length < 16) throw new Error("file is smaller than ELF header's e_ident");
  if (!(buf[0] === 0x7f && buf[1] === 0x45 && buf[2] === 0x4c && buf[3] === 0x46)) {
    throw new Error('mismatched magic: not an ELF file');
  }
  const cls = buf[4], data = buf[5];
  if (cls !== 1 && cls !== 2) throw new Error('unknown ELF class');
  if (data !== 1 && data !== 2) throw new Error('unknown ELF data encoding');
  const le = data === 1;
  const need = cls === 2 ? 64 : 52;
  if (buf.length < need) throw new Error('file is smaller than ELF header');
  const u16 = o => le ? buf.readUInt16LE(o) : buf.readUInt16BE(o);
  const u32 = o => le ? buf.readUInt32LE(o) : buf.readUInt32BE(o);
  const u64 = o => le ? buf.readBigUInt64LE(o) : buf.readBigUInt64BE(o);
  const addr = o => cls === 2 ? u64(o) : BigInt(u32(o));
  let e;
  if (cls === 2) {
    e = {type:u16(16), machine:u16(18), version:u32(20), entry:u64(24), phoff:u64(32), shoff:u64(40),
      flags:u32(48), ehsize:u16(52), phentsize:u16(54), phnum:u16(56), shentsize:u16(58), shnum:u16(60), shstrndx:u16(62)};
  } else {
    e = {type:u16(16), machine:u16(18), version:u32(20), entry:BigInt(u32(24)), phoff:BigInt(u32(28)), shoff:BigInt(u32(32)),
      flags:u32(36), ehsize:u16(40), phentsize:u16(42), phnum:u16(44), shentsize:u16(46), shnum:u16(48), shstrndx:u16(50)};
  }
  const ph = [];
  for (let i = 0; i < e.phnum; i++) {
    const o = Number(e.phoff) + i * e.phentsize;
    if (o + e.phentsize > buf.length) break;
    if (cls === 2) ph.push({type:u32(o), flags:u32(o+4), offset:u64(o+8), vaddr:u64(o+16), paddr:u64(o+24), filesz:u64(o+32), memsz:u64(o+40), align:u64(o+48)});
    else ph.push({type:u32(o), offset:BigInt(u32(o+4)), vaddr:BigInt(u32(o+8)), paddr:BigInt(u32(o+12)), filesz:BigInt(u32(o+16)), memsz:BigInt(u32(o+20)), flags:u32(o+24), align:BigInt(u32(o+28))});
  }
  const sh = [];
  for (let i = 0; i < e.shnum; i++) {
    const o = Number(e.shoff) + i * e.shentsize;
    if (o + e.shentsize > buf.length) break;
    if (cls === 2) sh.push({nameOff:u32(o), type:u32(o+4), flags:u64(o+8), addr:u64(o+16), offset:u64(o+24), size:u64(o+32), link:u32(o+40), info:u32(o+44), addralign:u64(o+48), entsize:u64(o+56)});
    else sh.push({nameOff:u32(o), type:u32(o+4), flags:BigInt(u32(o+8)), addr:BigInt(u32(o+12)), offset:BigInt(u32(o+16)), size:BigInt(u32(o+20)), link:u32(o+24), info:u32(o+28), addralign:BigInt(u32(o+32)), entsize:BigInt(u32(o+36))});
  }
  const strhdr = sh[e.shstrndx];
  if (strhdr) {
    const base = Number(strhdr.offset), end = Math.min(buf.length, base + Number(strhdr.size));
    const strtab = buf.slice(base, end);
    for (const s of sh) s.name = readCString(strtab, s.nameOff);
  } else {
    for (const s of sh) s.name = '';
  }
  return {cls, data, osabi:buf[7], e, ph, sh};
}

const etype = {0:'None (NONE)',1:'Relocatable file (REL)',2:'Executable file (EXEC)',3:'Shared object file (DYN)',4:'Core file (CORE)'};
const machine = {0:'No machine',3:'x86',8:'MIPS',20:'PowerPC',40:'ARM',50:'IA-64',62:'x86-64',183:'AArch64',243:'RISC-V'};
const ptype = {0:'NULL',1:'LOAD',2:'DYNAMIC',3:'INTERP',4:'NOTE',5:'SHLIB',6:'PHDR',7:'TLS',0x6474e550:'GNU_EH_FRAME',0x6474e551:'GNU_STACK',0x6474e552:'GNU_RELRO',0x6474e553:'GNU_PROPERTY'};
const shtype = {0:'NULL',1:'PROGBITS',2:'SYMTAB',3:'STRTAB',4:'RELA',5:'HASH',6:'DYNAMIC',7:'NOTE',8:'NOBITS',9:'REL',10:'SHLIB',11:'DYNSYM',14:'INIT_ARRAY',15:'FINI_ARRAY',16:'PREINIT_ARRAY',17:'GROUP',18:'SYMTAB_SHNDX',0x6ffffff6:'GNU_HASH',0x6fffffff:'GNU_VERSYM',0x6ffffffe:'GNU_VERNEED',0x6ffffffd:'GNU_VERDEF'};
function osabi(n) { return ({0:'SysV',1:'HP-UX',2:'NetBSD',3:'Linux',6:'Solaris',7:'AIX',8:'IRIX',9:'FreeBSD',12:'OpenBSD'}[n]) || String(n); }
function phFlags(f) { return `${f & 4 ? 'R' : ''}${f & 2 ? 'W' : ''}${f & 1 ? 'X' : ''}` || '0'; }
function shFlags(f) {
  const b = BigInt(f); let s = '';
  if (b & 1n) s += 'W'; if (b & 2n) s += 'A'; if (b & 4n) s += 'X'; if (b & 0x10n) s += 'M'; if (b & 0x20n) s += 'S'; if (b & 0x40n) s += 'I'; if (b & 0x80n) s += 'L'; if (b & 0x100n) s += 'O'; if (b & 0x200n) s += 'G'; if (b & 0x400n) s += 'T';
  return s || '0';
}

function bytesHtml(buf) {
  let offsets = '', bytes = '', ascii = '';
  for (let i = 0; i < buf.length; i += 16) {
    offsets += i.toString(16) + '\n';
    const row = buf.slice(i, i + 16);
    bytes += Array.from(row, b => b.toString(16).padStart(2, '0')).join(' ');
    bytes += '\n';
    ascii += Array.from(row, b => b >= 32 && b < 127 ? String.fromCharCode(b) : '.').join('') + '\n';
  }
  return `<div id='offsets'>${esc(offsets)}</div>\n<div id='bytes'>${esc(bytes)}</div>\n<div id='ascii'>${esc(ascii)}</div>`;
}

function htmlReport(file, buf, elf) {
  const name = path.basename(file);
  const e = elf.e;
  const phRows = elf.ph.map((p, i) => `<table class='itable' id='info_phdr${i}'>
<th colspan='2' class='phdr_itable'>Program header ${i}</th>
<tr><td>Type:</td><td>${esc(ptype[p.type] || hex(p.type))}</td></tr>
<tr><td>Flags:</td><td>${phFlags(p.flags)}</td></tr>
<tr><td>Offset in file:</td><td>${num(p.offset)}</td></tr>
<tr><td>Size in file:</td><td>${num(p.filesz)}${Number(p.filesz) >= 1024 ? ' (' + sizeText(p.filesz).split(' (')[0] + ')' : ''}</td></tr>
<tr><td>Vaddr in memory:</td><td>${num(p.vaddr)}</td></tr>
<tr><td>Size in memory:</td><td>${num(p.memsz)}</td></tr>
<tr><td>Alignment:</td><td>${num(p.align)}</td></tr>
</table>`).join('\n');
  const shRows = elf.sh.map((s, i) => `<table class='itable' id='info_shdr${i}'>
<th colspan='2' class='shdr_itable'>Section header ${i}</th>
<tr><td>Index:</td><td>${i}</td></tr>
<tr><td>Name:</td><td>${esc(s.name || '')}</td></tr>
<tr><td>Type:</td><td>${esc(shtype[s.type] || hex(s.type))}</td></tr>
<tr><td>Flags:</td><td>${shFlags(s.flags)}</td></tr>
<tr><td>Vaddr in memory:</td><td>${num(s.addr)}</td></tr>
<tr><td>Offset in file:</td><td>${num(s.offset)}</td></tr>
<tr><td>Size in file:</td><td>${num(s.size)}</td></tr>
<tr><td>Linked section:</td><td>${s.link}</td></tr>
<tr><td>Extra info:</td><td>${num(s.info)}</td></tr>
<tr><td>Alignment:</td><td>${num(s.addralign)}</td></tr>
<tr><td>Size of entries:</td><td>${num(s.entsize)}</td></tr>
</table>`).join('\n');
  return `<!doctype html>
<html>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=900, initial-scale=1'>
<title>${esc(name)}</title>
<style>
html{font-family:monospace} table{border-collapse:collapse;margin:.5em 0} td,th{padding:.12em .5em;text-align:left;vertical-align:top}
#rightmenu{float:right;text-align:right}.right_hidden{display:none;text-align:left}.number{color:#040}.legend_rect{display:inline-block;width:1em;height:1em;border:1px solid #000;margin-right:.4em}
#offsets,#bytes,#ascii{display:inline-block;white-space:pre;vertical-align:top;border:1px solid #aaa;padding:.25em;margin-top:1em}
#offsets{text-align:right;border-right:0}#bytes{width:47ch;word-break:break-word}#ascii{width:16ch}.itable{display:inline-table;border:1px solid #aaa;margin:.4em}.phdr_itable{background:#eb9}.shdr_itable{background:#9be}
.ident{background:#e99}.ehdr{background:#99e}.phdr{background:#eb9}.shdr{background:#9be}.segment{background:#f99}.section{background:#f9f}
</style>
</head>
<body>
<div id='rightmenu'>
<a id='credits' href='https://github.com/rbakbashev/elfcat'>generated with elfcat ${VERSION}</a>
<button id='settings_toggle'>Settings</button> <button id='help_toggle'>Help</button>
<div class='right_hidden' id='settings'><label for='arrow_opacity_range'>Arrow opacity:</label><input type='range' id='arrow_opacity_range' min='0' max='100' value='100'></div>
<div class='right_hidden' id='help'><p>The leftmost column shows offsets within the file. The middle column is the file dump. It has ELF structs, sections and segments highlighted. Some fields that reference areas in the file are clickable and connected with arrows. The rightmost column shows printable ASCII characters corresponding to the file bytes.</p>
<p>Legend</p><ul><li><span class='legend_rect ident'></span>ELF Identification</li><li><span class='legend_rect ehdr'></span>ELF Header</li><li><span class='legend_rect phdr'></span>Program Header</li><li><span class='legend_rect shdr'></span>Section Header</li><li><span class='legend_rect segment'></span>Segment</li><li><span class='legend_rect section'></span>Section</li></ul></div>
</div>
<table>
<tr class='fileinfo_file_name'><td>File name:</td><td>${esc(name)}</td></tr>
<tr class='fileinfo_file_size'><td>File size:</td><td>${sizeText(buf.length)}</td></tr>
<tr class='fileinfo_class'><td>Object class:</td><td>${elf.cls === 2 ? '64-bit' : '32-bit'}</td></tr>
<tr class='fileinfo_data'><td>Data encoding:</td><td>${elf.data === 1 ? 'Little endian' : 'Big endian'}</td></tr>
<tr class='fileinfo_abi'><td>ABI:</td><td>${esc(osabi(elf.osabi))}</td></tr>
<tr class='fileinfo_e_type'><td>Type:</td><td>${esc(etype[e.type] || hex(e.type))}</td></tr>
<tr class='fileinfo_e_machine'><td>Architecture:</td><td>${esc(machine[e.machine] || String(e.machine))}</td></tr>
<tr class='fileinfo_e_entry'><td>Entrypoint:</td><td><span class='number' title='${dec(e.entry)}'>${hex(e.entry)}</span></td></tr>
<tr class='fileinfo_ph'><td>Program headers:</td><td><span title='${hex(e.phnum)}' class='number fileinfo_e_phnum'>${e.phnum}</span> * <span title='${hex(e.phentsize)}' class='number fileinfo_e_phentsize'>${e.phentsize}</span> @ <span title='${hex(e.phoff)}' class='number fileinfo_e_phoff'>${dec(e.phoff)}</span></td></tr>
<tr class='fileinfo_sh'><td>Section headers:</td><td><span title='${hex(e.shnum)}' class='number fileinfo_e_shnum'>${e.shnum}</span> * <span title='${hex(e.shentsize)}' class='number fileinfo_e_shentsize'>${e.shentsize}</span> @ <span title='${hex(e.shoff)}' class='number fileinfo_e_shoff'>${dec(e.shoff)}</span></td></tr>
</table>
${bytesHtml(buf)}
<div class='infotables'>${phRows}\n${shRows}</div>
<script>
function toggleVisibility(elem){elem.style.display=(elem.style.display==='none'||elem.style.display==='')?'block':'none'}
document.getElementById('settings_toggle').onclick=function(){toggleVisibility(document.getElementById('settings'));document.getElementById('help').style.display='none'}
document.getElementById('help_toggle').onclick=function(){toggleVisibility(document.getElementById('help'));document.getElementById('settings').style.display='none'}
</script>
</body>
</html>
`;
}

function main(argv) {
  if (argv.length !== 3) {
    usage();
    return argv.length === 2 ? 1 : 1;
  }
  const arg = argv[2];
  if (arg === '--help' || arg === '-h') { usage(); return 0; }
  if (arg === '--version' || arg === '-V' || arg === '-v') { console.log(`elfcat ${VERSION}`); return 0; }
  let buf;
  try {
    buf = fs.readFileSync(arg);
  } catch (e) {
    console.error(`Failed to read file "${arg}": ${readErrorMessage(e)}`);
    return 1;
  }
  let elf;
  try {
    elf = parseElf(buf);
  } catch (e) {
    console.error(`Failed to parse ELF: ${e.message}`);
    return 1;
  }
  const out = path.basename(arg) + '.html';
  fs.writeFileSync(out, htmlReport(arg, buf, elf));
  return 0;
}

function readErrorMessage(e) {
  const table = {
    ENOENT: 'No such file or directory (os error 2)',
    EACCES: 'Permission denied (os error 13)',
    EISDIR: 'Is a directory (os error 21)',
    ENOTDIR: 'Not a directory (os error 20)',
  };
  return table[e.code] || e.message;
}

process.exitCode = main(process.argv);
