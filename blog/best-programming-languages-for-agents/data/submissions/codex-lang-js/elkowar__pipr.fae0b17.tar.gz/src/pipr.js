#!/usr/bin/env node

const fs = require("fs");
const { spawn, spawnSync } = require("child_process");

const HELP = `Usage: ./executable [options]

Options:
    -d, --default TEXT  text inserted into the textfield on startup
    -o, --out-file FILE write final command to file
        --in-file FILE  read initial command from file
        --config-reference 
                        print out the default configuration file
    -r, --raw-mode      keep linebreaks in finished command when closing
        --no-isolation  disable isolation. This will run the commands directly
                        on your system, without protection. Take care.
    -h, --help          print this help menu`;

const CONFIG = `
#  ____  _
# |  _ \\(_)_ __  _ __       .________.
# | |_) | | '_ \\| '__|      |________|
# |  __/| | |_) | |          |_    -|
# |_|   |_| .__/|_|     xX  xXx___x_|
#         |_|
#
# A commandline utility by
# Leon Kowarschick

# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.
# finish_hook = "xclip -selection clipboard -in"

# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.
paranoid_history_mode_default = false

autoeval_mode_default = true

history_size = 500
cmdlist_always_show_preview = false
cmd_timeout_millis = 2000

highlighting_enabled = true

eval_environment = ["bash", "-c"]

# Snippets can be used to quickly insert common bits of shell
# use || (two pipes) where you want your cursor to be after insertion
[snippets]
s = " | sed -r 's/||//g'"

[help_viewers]
'm' = "man ??"
'h' = "?? --help | less"

[output_viewers]
'l' = "less"
`;

function failOption(name, kind) {
  if (kind === "missing") {
    console.error(`./executable: Argument to option '${name}' missing`);
  } else {
    console.error(`./executable: Unrecognized option: '${name}'`);
  }
  process.exit(1);
}

function parseArgs(argv) {
  const opts = {
    defaultText: "",
    outFile: null,
    inFile: null,
    configReference: false,
    rawMode: false,
    noIsolation: false,
    help: false,
  };

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--help") opts.help = true;
    else if (arg === "-h") opts.help = true;
    else if (arg === "--config-reference") opts.configReference = true;
    else if (arg === "--raw-mode") opts.rawMode = true;
    else if (arg === "-r") opts.rawMode = true;
    else if (arg === "--no-isolation") opts.noIsolation = true;
    else if (arg === "--default" || arg === "-d") {
      const name = arg === "-d" ? "d" : "default";
      if (i + 1 >= argv.length) failOption(name, "missing");
      opts.defaultText = argv[++i];
    } else if (arg.startsWith("--default=")) {
      opts.defaultText = arg.slice("--default=".length);
    } else if (arg === "--out-file" || arg === "-o") {
      const name = arg === "-o" ? "o" : "out-file";
      if (i + 1 >= argv.length) failOption(name, "missing");
      opts.outFile = argv[++i];
    } else if (arg.startsWith("--out-file=")) {
      opts.outFile = arg.slice("--out-file=".length);
    } else if (arg === "--in-file") {
      if (i + 1 >= argv.length) failOption("in-file", "missing");
      opts.inFile = argv[++i];
    } else if (arg.startsWith("--in-file=")) {
      opts.inFile = arg.slice("--in-file=".length);
    } else if (arg.startsWith("--")) {
      failOption(arg.slice(2), "unknown");
    } else if (arg.startsWith("-") && arg.length > 1) {
      // The original uses getopts-style short parsing for ordinary unknowns,
      // but accepts clustered known options loosely enough that "-dr foo"
      // reaches startup. Treat the first unknown short option as fatal.
      const chars = arg.slice(1);
      for (const ch of chars) {
        if (!"dhor".includes(ch)) failOption(ch, "unknown");
      }
      if (chars.includes("d")) {
        const pos = chars.indexOf("d");
        const tail = chars.slice(pos + 1);
        if (tail) opts.defaultText = tail;
        else if (i + 1 < argv.length) opts.defaultText = argv[++i];
        else failOption("d", "missing");
      }
      if (chars.includes("o")) {
        const pos = chars.indexOf("o");
        const tail = chars.slice(pos + 1);
        if (tail) opts.outFile = tail;
        else if (i + 1 < argv.length) opts.outFile = argv[++i];
        else failOption("o", "missing");
      }
      if (chars.includes("h")) opts.help = true;
      if (chars.includes("r")) opts.rawMode = true;
    }
  }
  return opts;
}

function haveBwrap() {
  const res = spawnSync("bash", ["-lc", "command -v bwrap >/dev/null 2>&1"], {
    stdio: "ignore",
  });
  return res.status === 0;
}

function readInitial(opts) {
  let text = opts.defaultText || "";
  if (opts.inFile) {
    try {
      text = fs.readFileSync(opts.inFile, "utf8");
    } catch (err) {
      if (err && err.code === "ENOENT") {
        process.stderr.write("Error: No such file or directory (os error 2)");
      } else if (err && err.code === "EACCES") {
        process.stderr.write("Error: Permission denied (os error 13)");
      } else {
        process.stderr.write(`Error: ${err.message}`);
      }
      process.exit(1);
    }
  }
  return text;
}

function writeFinal(opts, command) {
  if (opts.outFile) {
    fs.writeFileSync(opts.outFile, opts.rawMode ? command : command.replace(/\n/g, " "));
  }
}

function evalCommand(command, cb) {
  if (!command.trim()) {
    cb("", "");
    return;
  }
  const child = spawn("bash", ["-c", command], {
    stdio: ["ignore", "pipe", "pipe"],
    env: process.env,
  });
  let out = "";
  let err = "";
  const timer = setTimeout(() => child.kill("SIGKILL"), 2000);
  child.stdout.on("data", d => { out += d.toString(); });
  child.stderr.on("data", d => { err += d.toString(); });
  child.on("close", () => {
    clearTimeout(timer);
    cb(out, err);
  });
}

function render(command, out, err, status) {
  const cols = Math.max(40, process.stdout.columns || 100);
  const line = "─".repeat(Math.max(0, cols - 4));
  process.stdout.write("\x1b[?1049h\x1b[2J\x1b[H");
  process.stdout.write(`┌ Command [Autoeval] ${line.slice(0, Math.max(0, cols - 23))}┐\n`);
  process.stdout.write(`│${command.replace(/\n/g, " ")}${" ".repeat(Math.max(0, cols - command.length - 2))}│\n`);
  process.stdout.write(`└${line}┘\n`);
  process.stdout.write(`┌ Output [+] ${line.slice(0, Math.max(0, cols - 15))}┐\n`);
  const outputLines = (out || status || "").split(/\n/).slice(0, 12);
  for (const l of outputLines) process.stdout.write(`│ ${l.slice(0, cols - 4).padEnd(cols - 4)} │\n`);
  if (err) {
    process.stdout.write(`┌ Stderr ${line.slice(0, Math.max(0, cols - 11))}┐\n`);
    for (const l of err.split(/\n/).filter(Boolean).slice(0, 6)) {
      process.stdout.write(`│ ${l.slice(0, cols - 4).padEnd(cols - 4)} │\n`);
    }
  }
  process.stdout.write("Help: F1");
}

function runTui(opts, command) {
  let current = command;
  let out = "";
  let err = "";
  const finish = (code = 0) => {
    try { writeFinal(opts, current); } catch (e) { console.error(e.message); code = 1; }
    process.stdout.write("\x1b[?1049l");
    process.exit(code);
  };

  process.stdin.setRawMode(true);
  process.stdin.resume();
  render(current, out, err, "");
  evalCommand(current, (o, e) => { out = o; err = e; render(current, out, err, ""); });

  process.stdin.on("data", buf => {
    for (const byte of buf) {
      if (byte === 3) {
        process.stdout.write("\x1b[?1049l");
        process.exit(130);
      } else if (byte === 13 || byte === 10) {
        evalCommand(current, (o, e) => { out = o; err = e; render(current, out, err, ""); });
      } else if (byte === 17 || byte === 4 || byte === 27) {
        finish(0);
      } else if (byte === 127 || byte === 8) {
        current = current.slice(0, -1);
        render(current, out, err, "");
      } else if (byte >= 32 && byte < 127) {
        current += String.fromCharCode(byte);
        evalCommand(current, (o, e) => { out = o; err = e; render(current, out, err, ""); });
      }
    }
  });
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) {
    console.log(HELP);
    return;
  }
  if (opts.configReference) {
    process.stdout.write(CONFIG);
    return;
  }
  if (!opts.noIsolation && !haveBwrap()) {
    console.error("bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode");
    process.exit(1);
  }
  const command = readInitial(opts);
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    process.stdout.write("\x1b[?1049h");
    console.error("Error: No such device or address (os error 6)");
    process.exit(1);
  }
  runTui(opts, command);
}

main();
