#!/usr/bin/env node
'use strict';

const fs = require('fs');
const { spawnSync, spawn } = require('child_process');

const RESET = '\x1b[0m';
const GROUPS = new Set(['numbers', 'urls', 'pointers', 'dates', 'paths', 'quotes', 'key-value-pairs', 'uuids', 'ip-addresses', 'processes', 'json']);
const COLOR = { red: 31, green: 32, yellow: 33, blue: 34, magenta: 35, cyan: 36 };

function c(code, s) { return `\x1b[${code}m${s}${RESET}`; }
function escRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

function help(long) {
  if (long) {
    return `A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          Filepath

Options:
  -f, --follow
          Follow the contents of a file

  -p, --print
          Print the output to stdout

      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file

  -e, --exec <EXEC>
          Run command and view the output in a pager

      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
          
          [possible values: red, green, yellow, blue, magenta, cyan]

      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)

      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. \`--pager="ov -f [FILE]"\`)
          
          [env: TAILSPIN_PAGER=]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
`;
  }
  return `A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]  Filepath

Options:
  -f, --follow
          Follow the contents of a file
  -p, --print
          Print the output to stdout
      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file
  -e, --exec <EXEC>
          Run command and view the output in a pager
      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
          quotes, key-value-pairs, uuids, ip-addresses, processes, json]
      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
          quotes, key-value-pairs, uuids, ip-addresses, processes, json]
      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)
      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. \`--pager="ov -f [FILE]"\`) [env:
          TAILSPIN_PAGER=]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
`;
}

function parse(argv) {
  const o = { print: false, follow: false, file: null, highlights: [], enable: null, disable: new Set(), builtin: true, exec: null, pager: null, config: null };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    const take = () => {
      if (i + 1 >= argv.length) die(`error: a value is required for '${a}' but none was supplied\n\nFor more information, try '--help'.`, 2);
      return argv[++i];
    };
    if (a === '-h') { process.stdout.write(help(false)); process.exit(0); }
    if (a === '--help') { process.stdout.write(help(true)); process.exit(0); }
    if (a === '-V' || a === '--version') { console.log('tspin 5.6.0'); process.exit(0); }
    if (a === '-p' || a === '--print') { o.print = true; continue; }
    if (a === '-f' || a === '--follow') { o.follow = true; continue; }
    if (a === '--disable-builtin-keywords') { o.builtin = false; continue; }
    if (a === '--') {
      if (i + 1 < argv.length) setFile(o, argv[++i]);
      if (i + 1 < argv.length) dieUnexpected(argv[i + 1]);
      break;
    }
    let val = null;
    for (const opt of ['--config-path', '--exec', '--highlight', '--enable', '--disable', '--pager']) {
      if (a === opt) { val = take(); a = opt; break; }
      if (a.startsWith(opt + '=')) { val = a.slice(opt.length + 1); a = opt; break; }
    }
    if (a === '--config-path') { o.config = val; continue; }
    if (a === '--exec' || a === '-e') { o.exec = val ?? take(); continue; }
    if (a === '--pager') { o.pager = val; continue; }
    if (a === '--highlight') { addHighlight(o, val); continue; }
    if (a === '--enable') { o.enable = parseGroups(val, '--enable <ENABLED_HIGHLIGHTERS>'); continue; }
    if (a === '--disable') { for (const g of parseGroups(val, '--disable <DISABLED_HIGHLIGHTERS>')) o.disable.add(g); continue; }
    if (a === '-e') { o.exec = take(); continue; }
    if (a.startsWith('-')) dieUnexpected(a);
    setFile(o, a);
  }
  if (o.enable && o.disable.size) die('Error:   × cannot both enable and disable highlighters\n', 1);
  if (o.config && !fs.existsSync(o.config)) die('Error:   × could not find the TOML file\n', 1);
  return o;
}

function die(s, code) { process.stderr.write(s.endsWith('\n') ? s : s + '\n'); process.exit(code); }
function dieUnexpected(a) {
  die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.`, 2);
}
function setFile(o, f) { if (o.file) dieUnexpected(f); o.file = f; }

function parseGroups(s, opt) {
  const out = new Set();
  for (const p of String(s || '').split(',').filter(Boolean)) {
    if (!GROUPS.has(p)) die(`error: invalid value '${p}' for '${opt}'\n  [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids, ip-addresses, processes, json]\n\nFor more information, try '--help'.`, 2);
    out.add(p);
  }
  return out;
}

function addHighlight(o, spec) {
  const m = /^([^:]+):(.*)$/.exec(spec || '');
  if (!m) die(`error: invalid value '${spec}' for '--highlight <COLOR_WORD>': Expected format COLOR:word1,word2,... found \`${spec}\`\n\nFor more information, try '--help'.`, 2);
  if (!(m[1] in COLOR)) die(`error: invalid value '${spec}' for '--highlight <COLOR_WORD>': invalid variant: ${m[1]}\n\nFor more information, try '--help'.`, 2);
  for (const w of m[2].split(',').filter(Boolean)) o.highlights.push({ word: w, color: COLOR[m[1]] });
}

function enabled(o, g) {
  if (o.enable) return o.enable.has(g);
  return !o.disable.has(g);
}

function tokenizeAnsiAware(line) {
  const tokens = [];
  let i = 0, plain = '';
  while (i < line.length) {
    if (line[i] === '\x1b') {
      if (plain) { tokens.push({ ansi: false, s: plain }); plain = ''; }
      const end = line.indexOf(RESET, i + 1);
      if (end >= 0) { tokens.push({ ansi: true, s: line.slice(i, end + RESET.length) }); i = end + RESET.length; continue; }
      const j = line.indexOf('m', i);
      if (j >= 0) { tokens.push({ ansi: true, s: line.slice(i, j + 1) }); i = j + 1; continue; }
    }
    plain += line[i++];
  }
  if (plain) tokens.push({ ansi: false, s: plain });
  return tokens;
}

function applyPlain(line, re, fn) {
  return tokenizeAnsiAware(line).map(t => t.ansi ? t.s : t.s.replace(re, fn)).join('');
}

function highlight(line, o) {
  let s = line;

  if (enabled(o, 'quotes')) s = applyPlain(s, /"([^"\\]|\\.)*"/g, m => c('33', m));
  if (enabled(o, 'urls')) {
    s = applyPlain(s, /\b(https?|ftp):\/\/([A-Za-z0-9.-]+)((?:\/[^\s"'<>]*)?)/g,
      (m, proto, host, path) => c('2;31', proto) + '://' + c('2;34', host) + (path ? c('34', path) : c('34', '')));
  }
  if (enabled(o, 'dates')) {
    s = applyPlain(s, /\b(\d{4})-(\d{2})-(\d{2})([T ])(\d{2}):(\d{2}):(\d{2})(?:([.,])(\d+))?(Z)?\b/g,
      (m, y, mo, d, sep, h, mi, se, dot, frac, z) => c('35', y)+c('2','-')+c('35',mo)+c('2','-')+c('35',d)+c('31',sep)+c('34',h)+c('2',':')+c('34',mi)+c('2',':')+c('34',se)+(dot?c('2',dot)+c('34',frac):'')+(z?c('31',z):''));
    s = applyPlain(s, /\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|Mon|Tue|Wed|Thu|Fri|Sat|Sun)\b/g, m => c('35', m));
    s = applyPlain(s, /\b(\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?\b/g,
      (m, h, mi, se, frac) => c('34',h)+c('2',':')+c('34',mi)+c('2',':')+c('34',se)+(frac?c('2','.')+c('34',frac):''));
  }
  if (enabled(o, 'key-value-pairs')) {
    s = applyPlain(s, /\b([A-Za-z_][A-Za-z0-9_.-]*)(=)/g, (m, k, eq) => c('2', k) + c('37', eq));
  }
  if (enabled(o, 'paths')) {
    s = applyPlain(s, /(^|[\s(])((?:\.{0,2}\/|\/)[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._-]+)*)/g,
      (m, pre, p) => pre + p.replace(/\/|[^/]+/g, part => part === '/' ? c('33', '/') : c('32', part)));
  }
  if (enabled(o, 'uuids')) {
    s = applyPlain(s, /\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b/g,
      m => m.replace(/[0-9]+|[a-fA-F]+|-/g, part => part === '-' ? c('31', '-') : c(/[a-fA-F]/.test(part) ? '3;35' : '3;34', part)));
  }
  if (enabled(o, 'ip-addresses')) {
    s = applyPlain(s, /\b(?:\d{1,3}\.){3}\d{1,3}\b/g, m => m.replace(/\d+|\./g, x => x === '.' ? c('31','.') : c('3;34', x)));
  }
  if (enabled(o, 'pointers')) {
    s = applyPlain(s, /\b0x[0-9a-fA-F]+\b/g, m => m.replace(/0|x|[a-fA-F]+|\d+/g, x => x === 'x' ? c('31','x') : c(/[a-fA-F]/.test(x) ? '3;35' : '3;34', x)));
  }
  if (enabled(o, 'numbers')) {
    s = applyPlain(s, /(?<![A-Za-z0-9_])\d+(?:\.\d+)?(?![A-Za-z0-9_])/g, m => c('36', m));
  }

  if (o.builtin) {
    const sev = { ERROR: 31, WARN: 33, INFO: 37, DEBUG: 32 };
    s = applyPlain(s, /\b(ERROR|WARN|INFO|DEBUG|TRACE)\b/g, m => m === 'TRACE' ? c('2', m) : c(String(sev[m]), m));
    const rest = { GET: '42;30', POST: '43;30', PUT: '45;30', PATCH: '45;30', DELETE: '41;30' };
    s = applyPlain(s, /\b(GET|POST|PUT|PATCH|DELETE)\b/g, m => c(rest[m], ` ${m} `));
    s = applyPlain(s, /\b(true|false|null)\b/g, m => c('3;31', m));
  }

  for (const h of o.highlights) {
    s = applyPlain(s, new RegExp(escRe(h.word), 'g'), m => c(String(h.color), m));
  }
  return s;
}

function processText(txt, o) {
  const hasFinal = txt.endsWith('\n');
  const lines = txt.replace(/\n$/, '').split('\n');
  const out = lines.map(l => highlight(l, o)).join('\n');
  return out + (hasFinal ? '\n' : '');
}

function readStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch { return ''; }
}

function runFollow(file, o) {
  if (!file) die('Error:   × --follow requires a file\n', 1);
  let data = '';
  try { data = fs.readFileSync(file, 'utf8'); } catch (e) { die(`Error:   ⚠ ${c('33', file)}: ${e.code === 'ENOENT' ? 'No such file or directory' : e.message}\n`, 1); }
  process.stdout.write(processText(data, o));
  fs.watchFile(file, { interval: 500 }, () => {
    let now = '';
    try { now = fs.readFileSync(file, 'utf8'); } catch { return; }
    if (now.length > data.length) process.stdout.write(processText(now.slice(data.length), o));
    data = now;
  });
}

function main() {
  const o = parse(process.argv.slice(2));
  let input = '';
  if (o.exec) {
    const r = spawnSync(o.exec, { shell: true, encoding: 'utf8' });
    input = (r.stdout || '') + (r.stderr || '');
  } else if (o.file) {
    if (o.follow) return runFollow(o.file, o);
    try { input = fs.readFileSync(o.file, 'utf8'); }
    catch (e) { die(`Error:   ⚠ ${c('33', o.file)}: ${e.code === 'ENOENT' ? 'No such file or directory' : e.message}\n`, 1); }
  } else {
    input = readStdin();
  }
  process.stdout.write(processText(input, o));
}

main();
