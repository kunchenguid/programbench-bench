#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawnSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const DATA = path.join(ROOT, 'data');

function data(name) {
  return fs.readFileSync(path.join(DATA, name), 'utf8');
}

function write(s) {
  process.stdout.write(s);
}

function ewrite(s) {
  process.stderr.write(s);
}

function shellSplit(s) {
  if (!s) return [];
  const out = [];
  let cur = '';
  let quote = null;
  let esc = false;
  for (const ch of s) {
    if (esc) {
      cur += ch;
      esc = false;
    } else if (ch === '\\') {
      esc = true;
    } else if (quote) {
      if (ch === quote) quote = null;
      else cur += ch;
    } else if (ch === '"' || ch === "'") {
      quote = ch;
    } else if (/\s/.test(ch)) {
      if (cur) {
        out.push(cur);
        cur = '';
      }
    } else {
      cur += ch;
    }
  }
  if (cur) out.push(cur);
  return out;
}

const valueOptions = new Set([
  '--nonprintable-notation', '--binary', '--language', '-l', '--fallback-syntax',
  '--fallback-language', '--highlight-line', '-H', '--file-name', '--diff-context',
  '--tabs', '--wrap', '--terminal-width', '--color', '--italic-text',
  '--decorations', '--paging', '--pager', '--map-syntax', '-m', '--ignored-suffix',
  '--theme', '--theme-light', '--theme-dark', '--squeeze-limit', '--strip-ansi',
  '--style', '--line-range', '-r', '--completion', '--config-file',
]);

function parseArgv(argv) {
  const opts = {
    files: [],
    lineRanges: [],
    style: null,
    plain: 0,
    number: false,
    showAll: false,
    notation: 'unicode',
    binary: 'no-printing',
    tabs: process.env.BAT_TABS ? Number(process.env.BAT_TABS) : 4,
    squeeze: false,
    squeezeLimit: null,
    color: 'auto',
    decorations: 'auto',
    stripAnsi: 'never',
    quietEmpty: false,
    unbuffered: false,
    fileName: null,
    terminalWidth: 80,
    command: null,
    completion: null,
  };
  if (process.env.BAT_STYLE) opts.style = process.env.BAT_STYLE;
  if (process.env.BAT_PAGING === 'never') opts.paging = 'never';

  const args = [...shellSplit(process.env.BAT_OPTS || ''), ...argv];
  let onlyFiles = false;
  for (let i = 0; i < args.length; i++) {
    let a = args[i];
    if (onlyFiles) {
      opts.files.push(a);
      continue;
    }
    if (a === '--') {
      onlyFiles = true;
      continue;
    }
    if (i === 0 && ['cache'].includes(a)) {
      opts.command = a;
      opts.commandArgs = args.slice(1);
      break;
    }
    if (!a.startsWith('-') || a === '-') {
      opts.files.push(a);
      continue;
    }
    let val = null;
    const eq = a.indexOf('=');
    if (eq > 0) {
      val = a.slice(eq + 1);
      a = a.slice(0, eq);
    }
    const need = (name) => {
      if (val !== null) return val;
      if (i + 1 >= args.length) dieUsage(`error: a value is required for '${name} <${name.replace(/^--?/, '').toUpperCase()}>'\n`, 2);
      return args[++i];
    };
    if (a === '-h' || a === '--help') opts.help = a;
    else if (a === '-V' || a === '--version') opts.version = true;
    else if (a === '--list-languages' || a === '-L') opts.listLanguages = true;
    else if (a === '--list-themes') opts.listThemes = true;
    else if (a === '--acknowledgements') opts.acknowledgements = true;
    else if (a === '--diagnostic') opts.diagnostic = true;
    else if (a === '--generate-config-file') opts.generateConfig = true;
    else if (a === '--config-file') opts.printConfig = true;
    else if (a === '-A' || a === '--show-all') opts.showAll = true;
    else if (a === '-n' || a === '--number') opts.number = true;
    else if (a === '-p' || a === '--plain') opts.plain++;
    else if (/^-p+$/.test(a)) opts.plain += a.length - 1;
    else if (a === '-P') opts.paging = 'never';
    else if (a === '-S' || a === '--chop-long-lines') opts.wrap = 'never';
    else if (a === '-s' || a === '--squeeze-blank') opts.squeeze = true;
    else if (a === '-u' || a === '--unbuffered') opts.unbuffered = true;
    else if (a === '-E' || a === '--quiet-empty') opts.quietEmpty = true;
    else if (a === '-d' || a === '--diff' || a === '-f' || a === '--force-colorization' || a === '--set-terminal-title') {
      if (a === '-f' || a === '--force-colorization') {
        opts.color = 'always';
        opts.decorations = 'always';
      }
    } else if (['-l', '--language', '--fallback-syntax', '--fallback-language', '-H', '--highlight-line', '--diff-context', '--wrap', '--terminal-width', '--pager', '-m', '--map-syntax', '--ignored-suffix', '--theme', '--theme-light', '--theme-dark', '--strip-ansi', '--italic-text'].includes(a)) {
      const v = need(a);
      if (a === '--terminal-width') opts.terminalWidth = parseWidth(v);
      if (a === '--strip-ansi') opts.stripAnsi = v;
    } else if (a === '--file-name') opts.fileName = need(a);
    else if (a === '--tabs') opts.tabs = Number(need(a));
    else if (a === '--nonprintable-notation') opts.notation = need(a);
    else if (a === '--binary') opts.binary = need(a);
    else if (a === '--color') opts.color = validate(a, need(a), ['auto', 'never', 'always']);
    else if (a === '--decorations') opts.decorations = validate(a, need(a), ['auto', 'never', 'always']);
    else if (a === '--paging') opts.paging = validate(a, need(a), ['auto', 'never', 'always', 'never']);
    else if (a === '--style') opts.style = need(a);
    else if (a === '-r' || a === '--line-range') opts.lineRanges.push(need(a));
    else if (a === '--squeeze-limit') opts.squeezeLimit = Number(need(a));
    else if (a === '--completion') opts.completion = validate(a, need(a), ['bash', 'fish', 'zsh', 'ps1']);
    else if (a.startsWith('-') && a.length > 2 && !a.startsWith('--')) {
      for (const ch of a.slice(1)) {
        if (ch === 'A') opts.showAll = true;
        else if (ch === 'n') opts.number = true;
        else if (ch === 'p') opts.plain++;
        else if (ch === 's') opts.squeeze = true;
        else if (ch === 'u') opts.unbuffered = true;
        else if (ch === 'E') opts.quietEmpty = true;
        else if (ch === 'P') opts.paging = 'never';
        else dieUnexpected(a);
      }
    } else {
      dieUnexpected(a);
    }
  }
  return opts;
}

function validate(opt, value, allowed) {
  if (!allowed.includes(value)) {
    ewrite(`error: invalid value '${value}' for '${opt} <when>'\n  [possible values: ${allowed.join(', ')}]\n`);
    process.exit(2);
  }
  return value;
}

function dieUnexpected(a) {
  ewrite(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [FILE]...\n       executable <COMMAND>\n`);
  process.exit(2);
}

function dieUsage(msg, code) {
  ewrite(msg);
  process.exit(code);
}

function parseWidth(v) {
  const n = Number(String(v).replace(/^[+-]/, ''));
  return Number.isFinite(n) && n > 0 ? n : 80;
}

function configPath() {
  if (process.env.BAT_CONFIG_PATH) return process.env.BAT_CONFIG_PATH;
  const xdg = process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config');
  return path.join(xdg, 'bat', 'config');
}

function defaultConfigText() {
  return `# This is \`bat\`s configuration file. Each line either contains a comment or\n# a command-line option that you want to pass to \`bat\` by default. You can\n# run \`bat --help\` to get a list of all possible configuration options.\n\n# Specify desired highlighting theme (e.g. \"TwoDark\"). Run \`bat --list-themes\`\n# for a list of all available themes\n#--theme=\"TwoDark\"\n\n# Enable this to use italic text on the terminal. This is not supported on all\n# terminal emulators (like tmux, by default):\n#--italic-text=always\n\n# Uncomment the following line to disable automatic paging:\n#--paging=never\n\n# Uncomment the following line if you are using less version >= 551 and want to\n# enable mouse scrolling support in \`bat\` when running inside tmux. This might\n# disable text selection, unless you press shift.\n#--pager=\"less --RAW-CONTROL-CHARS --quit-if-one-screen --mouse\"\n\n# Syntax mappings: map a certain filename pattern to a language.\n#   Example 1: use the C++ syntax for Arduino .ino files\n#   Example 2: Use \".gitignore\"-style highlighting for \".ignore\" files\n#--map-syntax \"*.ino:C++\"\n#--map-syntax \".ignore:Git Ignore\"\n`;
}

function main() {
  const opts = parseArgv(process.argv.slice(2));
  if (opts.command === 'cache') return cache(opts.commandArgs || []);
  if (opts.version) return write('bat 0.26.1 (610b77c)\n');
  if (opts.help === '-h') return write(data('short-help.txt'));
  if (opts.help === '--help') return write(data('long-help.txt'));
  if (opts.listLanguages) return write(data('languages.txt'));
  if (opts.listThemes) return write(data('themes.txt'));
  if (opts.acknowledgements) return write(data('acknowledgements.txt'));
  if (opts.completion) return write(data(`completion-${opts.completion}.txt`));
  if (opts.printConfig) return write(configPath() + '\n');
  if (opts.generateConfig) {
    const p = configPath();
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, defaultConfigText());
    return write(`Success! Config file written to ${p}\n`);
  }
  if (opts.diagnostic) return diagnostic();
  return printFiles(opts);
}

function cache(args) {
  if (args.includes('-h') || args.includes('--help')) return write(`Modify the syntax-definition and theme cache\n\nUsage: executable cache [OPTIONS]\n\nOptions:\n  -h, --help\n          Print help\n\n  -b, --build\n          Initialize (or update) the syntax/theme cache by loading from the source directory\n          (default: the configuration directory).\n\n  -c, --clear\n          Remove the cached syntax definitions and themes.\n\n      --source <dir>\n          Use a different directory to load syntaxes and themes from.\n\n      --target <dir>\n          Use a different directory to store the cached syntax and theme set.\n\n      --blank\n          Create completely new syntax and theme sets (instead of appending to the default sets).\n\n      --acknowledgements\n          Build acknowledgements.bin.\n`);
  if (args.includes('--clear') || args.includes('-c')) return;
  if (args.includes('--build') || args.includes('-b')) return;
}

function diagnostic() {
  write(`#### Software version\n\nbat 0.26.1 (610b77c)\n\n#### Operating system\n\n- OS: Linux (Ubuntu 22.04)\n- Kernel: ${os.release()}\n\n#### Command-line\n\n\`\`\`bash\n${process.argv.map((a, i) => i ? a : './executable').join(' ')} \n\`\`\`\n\n#### Environment variables\n\n\`\`\`bash\n`);
  for (const k of ['BAT_CACHE_PATH','BAT_CONFIG_PATH','BAT_OPTS','BAT_PAGER','BAT_PAGING','BAT_STYLE','BAT_TABS','BAT_THEME','BAT_WIDTH','BAT_THEME_DARK','BAT_THEME_LIGHT','COLORTERM','LANG','LC_ALL','LESS','MANPAGER','NO_COLOR','PAGER','SHELL','TERM','XDG_CACHE_HOME','XDG_CONFIG_HOME']) {
    write(`${k}=${process.env[k] || '<not set>'}\n`);
  }
  write('```\n');
}

function readStdin() {
  try {
    return fs.readFileSync(0);
  } catch {
    return Buffer.alloc(0);
  }
}

function printFiles(opts) {
  const files = opts.files.length ? opts.files : ['-'];
  let status = 0;
  let anyOutput = false;
  for (const f of files) {
    let buf;
    let display = f;
    if (f === '-') {
      buf = readStdin();
      display = opts.fileName || 'STDIN';
    } else {
      try {
        const st = fs.statSync(f);
        if (st.isDirectory()) {
          ewrite(`\x1b[31m[bat error]\x1b[0m: '${f}' is a directory.\n`);
          status = 1;
          continue;
        }
        buf = fs.readFileSync(f);
      } catch (err) {
        const msg = err && err.code === 'ENOENT' ? 'No such file or directory (os error 2)' : (err.message || String(err));
        ewrite(`\x1b[31m[bat error]\x1b[0m: '${f}': ${msg}\n`);
        status = 1;
        continue;
      }
    }
    if (opts.quietEmpty && buf.length === 0) continue;
    if (!opts.showAll && opts.binary !== 'as-text' && buf.includes(0)) {
      ewrite(`\x1b[31m[bat error]\x1b[0m: '${f}': input was detected as binary. Use '--binary=as-text' or '-A' to display it.\n`);
      status = 1;
      continue;
    }
    let text = buf.toString('utf8');
    if (opts.stripAnsi === 'always' || opts.stripAnsi === 'auto') text = text.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '');
    let lines = toLines(text);
    lines = applyRanges(lines, opts.lineRanges);
    lines = squeeze(lines, opts);
    if (opts.showAll) lines = lines.map(l => ({ ...l, text: visible(l.text, l.nl, opts), nl: false }));
    const rendered = render(lines, opts, display, f, buf.length);
    if (rendered.length) anyOutput = true;
    write(rendered);
  }
  process.exit(status);
}

function toLines(text) {
  if (text.length === 0) return [];
  const parts = text.match(/[^\n]*(?:\n|$)/g) || [];
  const out = [];
  for (const p of parts) {
    if (p === '') continue;
    const nl = p.endsWith('\n');
    out.push({ text: nl ? p.slice(0, -1) : p, nl });
  }
  return out;
}

function parseRange(spec, count) {
  let ctx = 0;
  let s = spec;
  const ctxMatch = s.match(/^(.*)::(\d+)$/) || s.match(/^(.*):(\d+)$/);
  if (ctxMatch && s.split(':').length === 3) {
    s = ctxMatch[1];
    ctx = Number(ctxMatch[2]);
  }
  let start = 1, end = count;
  if (/^-?\d+$/.test(s)) start = end = Number(s);
  else {
    const [a, b] = s.split(':');
    if (a) start = Number(a);
    if (b) {
      if (b.startsWith('+')) end = start + Number(b.slice(1));
      else end = Number(b);
    }
  }
  if (start < 0) start = count + start + 1;
  if (end < 0) end = count + end + 1;
  start = Math.max(1, start - ctx);
  end = Math.min(count, end + ctx);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) return null;
  return [start, end];
}

function applyRanges(lines, ranges) {
  if (!ranges.length) return lines;
  const selected = [];
  for (const r of ranges) {
    const p = parseRange(r, lines.length);
    if (!p) continue;
    for (let i = p[0]; i <= p[1]; i++) if (i >= 1 && i <= lines.length) selected.push(lines[i - 1]);
  }
  return selected;
}

function squeeze(lines, opts) {
  const limit = opts.squeeze ? (opts.squeezeLimit || 1) : opts.squeezeLimit;
  if (!limit) return lines;
  const out = [];
  let blanks = 0;
  for (const l of lines) {
    if (l.text === '') {
      blanks++;
      if (blanks <= limit) out.push(l);
    } else {
      blanks = 0;
      out.push(l);
    }
  }
  return out;
}

const controlPictures = {
  0: '␀', 1: '␁', 2: '␂', 3: '␃', 4: '␄', 5: '␅', 6: '␆', 7: '␇',
  8: '␈', 9: '␉', 10: '␊', 11: '␋', 12: '␌', 13: '␍', 14: '␎', 15: '␏',
  16: '␐', 17: '␑', 18: '␒', 19: '␓', 20: '␔', 21: '␕', 22: '␖', 23: '␗',
  24: '␘', 25: '␙', 26: '␚', 27: '␛', 28: '␜', 29: '␝', 30: '␞', 31: '␟', 127: '␡'
};

function visible(s, hadNl, opts) {
  let col = 0;
  let out = '';
  for (const ch of s) {
    const code = ch.codePointAt(0);
    if (ch === '\t') {
      if (opts.tabs === 0) out += '\t';
      else {
        const width = opts.tabs > 0 ? opts.tabs - (col % opts.tabs) : 4;
        out += width <= 2 ? '↹' : '├' + '─'.repeat(Math.max(0, width - 2)) + '┤';
        col += width;
        continue;
      }
    } else if (ch === ' ') out += '·';
    else if (code < 32 || code === 127) out += opts.notation === 'caret' ? caret(code) : controlPictures[code];
    else out += ch;
    col++;
  }
  if (hadNl) out += opts.notation === 'caret' ? '^J' : '␊';
  return out;
}

function caret(code) {
  if (code === 127) return '^?';
  return '^' + String.fromCharCode(code + 64);
}

function styleSet(opts) {
  if (opts.plain || opts.style === 'plain') return new Set();
  if (opts.number) return new Set(['numbers']);
  const s = opts.style || 'auto';
  if (s === 'auto' || s === 'default') return process.stdout.isTTY || opts.decorations === 'always' ? new Set(['numbers','grid','header-filename']) : new Set();
  if (s === 'full') return new Set(['numbers','grid','header-filename','header-filesize','rule']);
  const set = new Set();
  for (const part of s.split(',')) {
    const p = part.trim();
    if (p === 'header') set.add('header-filename');
    else if (p) set.add(p);
  }
  return set;
}

function render(lines, opts, display, filePath, size) {
  const st = styleSet(opts);
  let out = '';
  const useDecor = opts.decorations === 'always' || (opts.decorations === 'auto' && process.stdout.isTTY);
  if (useDecor && (st.has('header-filename') || st.has('header-filesize') || st.has('rule'))) {
    const w = Math.max(20, opts.terminalWidth || 80);
    out += '─────┬' + '─'.repeat(Math.max(0, w - 6)) + '\n';
    if (st.has('header-filename')) out += `     │ File: ${display}\n`;
    if (st.has('header-filesize')) out += `     │ Size: ${formatSize(size)}\n`;
    out += '─────┼' + '─'.repeat(Math.max(0, w - 6)) + '\n';
  }
  const numberLines = st.has('numbers') || opts.number;
  const grid = useDecor && st.has('grid') && !opts.number;
  for (let i = 0; i < lines.length; i++) {
    let prefix = '';
    if (numberLines) prefix += String(i + 1).padStart(4, ' ') + (grid ? ' │ ' : ' ');
    else if (grid) prefix += '     │ ';
    out += prefix + colorize(lines[i].text, opts) + (lines[i].nl === false ? '' : '\n');
  }
  if (useDecor && (st.has('header-filename') || st.has('header-filesize') || st.has('rule'))) {
    const w = Math.max(20, opts.terminalWidth || 80);
    out += '─────┴' + '─'.repeat(Math.max(0, w - 6)) + '\n';
  }
  return out;
}

function colorize(s, opts) {
  if (opts.color !== 'always') return s;
  return s.replace(/\b(function|const|let|var|if|else|return|class|import|from|def|fn)\b/g, '\x1b[35m$1\x1b[0m');
}

function formatSize(n) {
  if (n < 1000) return `${n} B`;
  if (n < 1000000) return `${(n / 1000).toFixed(1)} KB`;
  return `${(n / 1000000).toFixed(1)} MB`;
}

main();
