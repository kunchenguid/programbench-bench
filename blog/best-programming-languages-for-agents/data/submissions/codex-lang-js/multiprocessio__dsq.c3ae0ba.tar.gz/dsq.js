#!/usr/bin/env node
const fs = require('fs');
const zlib = require('zlib');

function usage() {
  console.log(`dsq (Version latest) - commandline SQL engine for data files

Usage:  dsq [file...] $query
        dsq $file [query]
        cat $file | dsq -s $filetype [query]
        dsq $file -f $queryfile

dsq is a tool for running SQL on one or more data files. It uses
SQLite's SQL dialect. Files as tables are accessible via "{N}" where N
is the 0-based index of the file in the commandline.

The shorthand "{}" is replaced with "{0}".

Examples:

    # This simply dumps the CSV as JSON
    $ dsq test.csv

    # This dumps the first 10 rows of the parquet file as JSON.
    $ dsq data.parquet "SELECT * FROM {} LIMIT 10"

    # This joins two datasets of differing origin types (CSV and JSON).
    $ dsq testdata/join/users.csv testdata/join/ages.json \\
          "select {0}.name, {1}.age from {0} join {1} on {0}.id = {1}.id"

See the repo for more details: https://github.com/multiprocessio/dsq`);
}

function parseArgs(argv) {
  const opts = { pretty: false, schema: false, stdinFormat: null, queryFile: null, interactive: false, cache: false };
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') { opts.help = true; }
    else if (a === '--version' || a === '-v') { opts.version = true; }
    else if (a === '-p' || a === '--pretty') opts.pretty = true;
    else if (a === '--schema') opts.schema = true;
    else if (a === '-i' || a === '--interactive') opts.interactive = true;
    else if (a === '-C' || a === '--cache') opts.cache = true;
    else if (a === '-s' || a === '--source') opts.stdinFormat = argv[++i];
    else if (a === '-f' || a === '--file') opts.queryFile = argv[++i];
    else rest.push(a);
  }
  return { opts, rest };
}

function extFormat(path, fallback) {
  if (fallback) return fallback.toLowerCase();
  const m = /\.([^.\/]+)$/.exec(path || '');
  return m ? m[1].toLowerCase() : 'csv';
}

function parseCsv(text, delim) {
  const rows = [];
  let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') {
        if (text[i + 1] === '"') { cur += '"'; i++; } else q = false;
      } else cur += c;
    } else if (c === '"') q = true;
    else if (c === delim) { row.push(cur); cur = ''; }
    else if (c === '\n') { row.push(cur); rows.push(row); row = []; cur = ''; }
    else if (c !== '\r') cur += c;
  }
  if (cur.length || row.length) { row.push(cur); rows.push(row); }
  while (rows.length && rows[rows.length - 1].every(x => x === '')) rows.pop();
  if (!rows.length) return [];
  const header = rows[0].map((h, i) => h || `column${i + 1}`);
  return rows.slice(1).map(r => {
    const o = {};
    header.forEach((h, i) => { o[h] = r[i] == null ? '' : r[i]; });
    return o;
  });
}

function parseLogfmt(text) {
  return text.split(/\r?\n/).filter(Boolean).map(line => {
    const o = {};
    const re = /([A-Za-z0-9_.-]+)=("(?:[^"\\]|\\.)*"|\S*)/g;
    let m;
    while ((m = re.exec(line))) {
      let v = m[2];
      if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1).replace(/\\"/g, '"');
      o[m[1]] = v;
    }
    return o;
  });
}

function parseData(text, fmt) {
  fmt = (fmt || 'csv').toLowerCase();
  if (fmt === 'tsv' || fmt === 'tab') return parseCsv(text, '\t');
  if (fmt === 'csv' || fmt === 'txt') return parseCsv(text, ',');
  if (fmt === 'logfmt') return parseLogfmt(text);
  if (fmt === 'json' || fmt === 'ndjson' || fmt === 'jsonl') {
    const s = text.trim();
    if (!s) return [];
    try {
      const v = JSON.parse(s);
      if (Array.isArray(v)) return v.map(x => normalizeRow(x));
      if (v && typeof v === 'object') {
        const vals = Object.values(v);
        if (vals.length && vals.every(x => x && typeof x === 'object' && !Array.isArray(x))) return vals.map(x => normalizeRow(x));
        return [normalizeRow(v)];
      }
    } catch (_) {}
    return s.split(/\r?\n/).filter(Boolean).map(line => normalizeRow(JSON.parse(line)));
  }
  throw new Error(`unsupported file type: ${fmt}`);
}

function parseFile(path, forcedFormat) {
  const fmt = extFormat(path, forcedFormat);
  if (fmt === 'xlsx') return parseXlsx(fs.readFileSync(path));
  if (fmt === 'ods') return parseOds(fs.readFileSync(path));
  return parseData(fs.readFileSync(path, 'utf8'), fmt);
}

function unzipEntries(buf) {
  const out = {};
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 66000); i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) return out;
  const count = buf.readUInt16LE(eocd + 10), cdOffset = buf.readUInt32LE(eocd + 16);
  let p = cdOffset;
  for (let n = 0; n < count && p < buf.length; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) break;
    const method = buf.readUInt16LE(p + 10), comp = buf.readUInt32LE(p + 20);
    const nameLen = buf.readUInt16LE(p + 28), extraLen = buf.readUInt16LE(p + 30), commentLen = buf.readUInt16LE(p + 32);
    const local = buf.readUInt32LE(p + 42), name = buf.slice(p + 46, p + 46 + nameLen).toString();
    const lnameLen = buf.readUInt16LE(local + 26), lextraLen = buf.readUInt16LE(local + 28);
    const start = local + 30 + lnameLen + lextraLen;
    const data = buf.slice(start, start + comp);
    out[name] = method === 0 ? data : method === 8 ? zlib.inflateRawSync(data) : Buffer.alloc(0);
    p += 46 + nameLen + extraLen + commentLen;
  }
  return out;
}

function xmlText(s) {
  return s.replace(/<[^>]+>/g, '').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
}

function colIndex(ref) {
  const m = /^([A-Z]+)/.exec(ref || 'A'); let n = 0;
  for (const ch of m[1]) n = n * 26 + ch.charCodeAt(0) - 64;
  return n - 1;
}

function rowsToObjects(rows) {
  while (rows.length && rows[rows.length - 1].every(x => x === '' || x == null)) rows.pop();
  if (!rows.length) return [];
  const header = rows[0].map((h, i) => h == null || h === '' ? `column${i + 1}` : String(h));
  return rows.slice(1).map(r => {
    const o = {};
    header.forEach((h, i) => { o[h] = r[i] == null ? '' : r[i]; });
    return o;
  });
}

function parseXlsx(buf) {
  const zip = unzipEntries(buf);
  const shared = [];
  const ss = zip['xl/sharedStrings.xml']?.toString('utf8') || '';
  for (const m of ss.matchAll(/<si\b[\s\S]*?<\/si>/g)) shared.push(xmlText([...m[0].matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g)].map(x => x[1]).join('')));
  const sheetName = zip['xl/worksheets/sheet1.xml'] ? 'xl/worksheets/sheet1.xml' : Object.keys(zip).find(k => /^xl\/worksheets\/sheet\d+\.xml$/.test(k));
  if (!sheetName) return [];
  const xml = zip[sheetName].toString('utf8'), rows = [];
  for (const rm of xml.matchAll(/<row\b[\s\S]*?<\/row>/g)) {
    const arr = [];
    for (const cm of rm[0].matchAll(/<c\b([^>]*)>([\s\S]*?)<\/c>/g)) {
      const attrs = cm[1], body = cm[2];
      const r = /r="([^"]+)"/.exec(attrs), t = /t="([^"]+)"/.exec(attrs);
      const idx = colIndex(r && r[1]);
      const vm = /<v[^>]*>([\s\S]*?)<\/v>/.exec(body);
      const im = /<is\b[\s\S]*?<\/is>/.exec(body);
      let val = vm ? xmlText(vm[1]) : im ? xmlText(im[0]) : '';
      if (t && t[1] === 's') val = shared[Number(val)] ?? val;
      arr[idx] = val;
    }
    rows.push(arr.map(x => x ?? ''));
  }
  return rowsToObjects(rows);
}

function parseOds(buf) {
  const zip = unzipEntries(buf);
  const xml = zip['content.xml']?.toString('utf8') || '';
  const table = /<table:table\b[\s\S]*?<\/table:table>/.exec(xml)?.[0] || xml;
  const rows = [];
  for (const rm of table.matchAll(/<table:table-row\b([^>]*)>([\s\S]*?)<\/table:table-row>/g)) {
    const repeatRow = Number(/table:number-rows-repeated="(\d+)"/.exec(rm[1])?.[1] || 1);
    const arr = [];
    for (const cm of rm[2].matchAll(/<table:table-cell\b([^>]*)>([\s\S]*?)<\/table:table-cell>/g)) {
      const rep = Math.min(Number(/table:number-columns-repeated="(\d+)"/.exec(cm[1])?.[1] || 1), 100);
      const valAttr = /office:value="([^"]*)"/.exec(cm[1])?.[1];
      const val = valAttr != null ? valAttr : xmlText(cm[2]);
      for (let i = 0; i < rep; i++) arr.push(val);
    }
    for (let i = 0; i < Math.min(repeatRow, 100); i++) rows.push([...arr]);
  }
  return rowsToObjects(rows.filter(r => r.some(x => x !== '')));
}

function normalizeRow(x) {
  if (!x || typeof x !== 'object' || Array.isArray(x)) return { value: x };
  return { ...x };
}

function inferScalar(v) {
  if (v === null || v === undefined) return 'null';
  if (typeof v === 'boolean') return 'bool';
  if (typeof v === 'number') return Number.isInteger(v) ? 'int' : 'float';
  return 'string';
}

function schema(rows) {
  const obj = {};
  for (const r of rows) for (const [k, v] of Object.entries(r)) if (!obj[k]) obj[k] = { kind: 'scalar', scalar: inferScalar(v) };
  return { kind: 'array', array: { kind: 'object', object: obj } };
}

function splitComma(s) {
  const out = []; let cur = '', depth = 0, quote = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (quote) { cur += c; if (c === quote && s[i - 1] !== '\\') quote = null; }
    else if (c === '"' || c === "'") { quote = c; cur += c; }
    else if (c === '(') { depth++; cur += c; }
    else if (c === ')') { depth--; cur += c; }
    else if (c === ',' && depth === 0) { out.push(cur.trim()); cur = ''; }
    else cur += c;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function findClause(sql, words, start) {
  const lower = sql.toLowerCase(); let depth = 0, quote = null;
  for (let i = start || 0; i < sql.length; i++) {
    const c = sql[i];
    if (quote) { if (c === quote && sql[i - 1] !== '\\') quote = null; continue; }
    if (c === '"' || c === "'") { quote = c; continue; }
    if (c === '(') depth++; else if (c === ')') depth--;
    if (depth === 0) {
      for (const w of words) {
        if (lower.startsWith(w, i) && (i === 0 || /\s/.test(sql[i - 1])) && (i + w.length === sql.length || /\s/.test(sql[i + w.length]))) return { word: w, index: i };
      }
    }
  }
  return null;
}

function parseQuery(q) {
  q = q.trim().replace(/;$/, '').replace(/\{\}/g, '{0}').replace(/\{(\d+)\}/g, 't$1');
  if (!/^select\s/i.test(q)) q = `select * from t0`;
  const from = findClause(q, ['from'], 0);
  if (!from) return { select: q.replace(/^select\s+/i, ''), from: 't0' };
  const select = q.slice(6, from.index).trim();
  const rest = q.slice(from.index + 4).trim();
  const marks = [];
  for (const w of ['where', 'group by', 'order by', 'limit']) {
    const m = findClause(rest, [w], 0); if (m) marks.push(m);
  }
  marks.sort((a, b) => a.index - b.index);
  const baseEnd = marks[0] ? marks[0].index : rest.length;
  const spec = { select, fromPart: rest.slice(0, baseEnd).trim() };
  if (/^distinct\s+/i.test(spec.select)) { spec.distinct = true; spec.select = spec.select.replace(/^distinct\s+/i, ''); }
  for (let i = 0; i < marks.length; i++) {
    const end = marks[i + 1] ? marks[i + 1].index : rest.length;
    spec[marks[i].word.replace(/ /g, '')] = rest.slice(marks[i].index + marks[i].word.length, end).trim();
  }
  return spec;
}

function toNum(v) {
  if (typeof v === 'number') return v;
  if (typeof v === 'string' && v.trim() !== '' && !isNaN(Number(v))) return Number(v);
  return v;
}

function get(row, name) {
  name = name.replace(/^["'`]|["'`]$/g, '');
  if (Object.prototype.hasOwnProperty.call(row, name)) return row[name];
  const short = name.split('.').pop();
  return row[short];
}

function like(v, pat) {
  const re = '^' + String(pat).replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/%/g, '.*').replace(/_/g, '.') + '$';
  return new RegExp(re, 'i').test(String(v));
}

function evalExpr(expr, row) {
  expr = expr.trim();
  if (/^(?:t\d+\.)?[A-Za-z_][\w]*$/.test(expr) || /^`[^`]+`$/.test(expr)) return get(row, expr.replace(/`/g, ''));
  let m = /^(.+?)\s+like\s+(.+)$/i.exec(expr);
  if (m) return like(evalExpr(m[1], row), evalExpr(m[2], row));
  let js = '', i = 0;
  while (i < expr.length) {
    const c = expr[i];
    if (/\s/.test(c)) { js += c; i++; continue; }
    if (c === "'" || c === '"') {
      const q = c; let s = c; i++;
      while (i < expr.length) { s += expr[i]; if (expr[i] === q && expr[i - 1] !== '\\') { i++; break; } i++; }
      js += s; continue;
    }
    if (c === '`') {
      let j = i + 1; while (j < expr.length && expr[j] !== '`') j++;
      js += `toNum(get(row, ${JSON.stringify(expr.slice(i + 1, j))}))`;
      i = j + 1; continue;
    }
    const op2 = expr.slice(i, i + 2);
    if (op2 === '>=' || op2 === '<=' || op2 === '!=' || op2 === '<>') { js += op2 === '<>' ? '!=' : op2; i += 2; continue; }
    if (c === '=') { js += '=='; i++; continue; }
    if (/[(),+\-*\/<>]/.test(c)) { js += c; i++; continue; }
    if (/[0-9]/.test(c)) {
      let j = i + 1; while (j < expr.length && /[0-9.]/.test(expr[j])) j++;
      js += expr.slice(i, j); i = j; continue;
    }
    if (/[A-Za-z_`]/.test(c)) {
      let j = i + 1; while (j < expr.length && /[A-Za-z0-9_.`]/.test(expr[j])) j++;
      const id = expr.slice(i, j);
      if (/^(and|or)$/i.test(id)) js += id.toLowerCase() === 'and' ? '&&' : '||';
      else if (/^not$/i.test(id)) js += '!';
      else if (/^(null)$/i.test(id)) js += 'null';
      else js += `toNum(get(row, ${JSON.stringify(id.replace(/`/g, ''))}))`;
      i = j; continue;
    }
    js += c; i++;
  }
  return Function('row', 'get', 'toNum', `return (${js});`)(row, get, toNum);
}

function parseSelectItem(item) {
  let m = /^(.+?)\s+as\s+([A-Za-z_][\w]*)$/i.exec(item);
  if (m) return { expr: m[1].trim(), alias: m[2] };
  m = /^(.+?)\s+([A-Za-z_][\w]*)$/.exec(item);
  if (m && !/[)\w]$/.test(m[1].trim().split(/\s+/).pop())) return { expr: m[1].trim(), alias: m[2] };
  return { expr: item.trim(), alias: null };
}

function outputName(expr, alias) {
  if (alias) return alias;
  if (/^`[^`]+`$/.test(expr.trim())) return expr.trim().slice(1, -1);
  const m = /^(?:t\d+\.)?([A-Za-z_][\w]*)$/.exec(expr.trim());
  return m ? m[1] : expr.trim();
}

function aggregate(expr, rows) {
  let m = /^(count|sum|avg|min|max)\s*\((.*?)\)$/i.exec(expr.trim());
  if (!m) return undefined;
  const fn = m[1].toLowerCase(), arg = m[2].trim();
  if (fn === 'count') return arg === '*' ? rows.length : rows.filter(r => evalExpr(arg, r) != null).length;
  const vals = rows.map(r => evalExpr(arg, r)).filter(v => v != null);
  if (fn === 'sum' || fn === 'avg') {
    const ns = vals.map(Number).filter(n => !isNaN(n));
    const sum = ns.reduce((a, b) => a + b, 0);
    return fn === 'sum' ? sum : (ns.length ? sum / ns.length : null);
  }
  vals.sort((a, b) => String(a).localeCompare(String(b), undefined, { numeric: true }));
  return fn === 'min' ? vals[0] : vals[vals.length - 1];
}

function execute(query, tables) {
  const spec = parseQuery(query);
  let rows = buildFrom(spec.fromPart || 't0', tables);
  if (spec.where) rows = rows.filter(r => !!evalExpr(spec.where, r));
  const items = splitComma(spec.select).map(parseSelectItem);
  const hasAgg = items.some(it => /^(count|sum|avg|min|max)\s*\(/i.test(it.expr));
  const preOrder = spec.orderby && !spec.groupby && !hasAgg ? parseOrder(spec.orderby) : null;
  if (preOrder) sortRows(rows, preOrder.expr, preOrder.desc);
  if (spec.groupby || hasAgg) {
    const groups = new Map(), gexprs = spec.groupby ? splitComma(spec.groupby) : ['__all__'];
    for (const r of rows) {
      const key = spec.groupby ? JSON.stringify(gexprs.map(e => evalExpr(e, r))) : '__all__';
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(r);
    }
    rows = [...groups.values()].map(grp => project(items, grp[0], grp));
  } else {
    rows = rows.map(r => project(items, r, null));
  }
  if (spec.orderby && !preOrder) {
    const ord = parseOrder(spec.orderby);
    sortRows(rows, ord.expr, ord.desc);
  }
  if (spec.distinct) {
    const seen = new Set();
    rows = rows.filter(r => { const k = JSON.stringify(r); if (seen.has(k)) return false; seen.add(k); return true; });
  }
  if (spec.limit) rows = rows.slice(0, Number(spec.limit.match(/\d+/)?.[0] || rows.length));
  return rows;
}

function parseOrder(orderby) {
  const parts = orderby.trim().split(/\s+/);
  const desc = /^desc$/i.test(parts[parts.length - 1]);
  const expr = desc || /^asc$/i.test(parts[parts.length - 1]) ? parts.slice(0, -1).join(' ') : orderby.trim();
  return { expr, desc };
}

function sortRows(rows, expr, desc) {
  rows.sort((a, b) => {
    let va, vb;
    try { va = evalExpr(expr, a); vb = evalExpr(expr, b); } catch (_) { va = get(a, expr); vb = get(b, expr); }
    const c = String(va).localeCompare(String(vb), undefined, { numeric: true });
    return desc ? -c : c;
  });
}

function buildFrom(fromPart, tables) {
  const join = /^t(\d+)\s+join\s+t(\d+)\s+on\s+(.+)$/i.exec(fromPart);
  if (!join) return qualify(tables[(/^t(\d+)/i.exec(fromPart) || [0, 0])[1]] || [], Number((/^t(\d+)/i.exec(fromPart) || [0, 0])[1]));
  const aidx = Number(join[1]), bidx = Number(join[2]), cond = join[3];
  const left = qualify(tables[aidx] || [], aidx), right = qualify(tables[bidx] || [], bidx), out = [];
  for (const l of left) for (const r of right) {
    const row = { ...l, ...r };
    for (const [k, v] of Object.entries(l)) if (!k.includes('.') && !(k in r)) row[k] = v;
    if (evalExpr(cond, row)) out.push(row);
  }
  return out;
}

function qualify(rows, idx) {
  return rows.map(r => {
    const o = {};
    for (const [k, v] of Object.entries(r)) { o[k] = v; o[`t${idx}.${k}`] = v; }
    return o;
  });
}

function project(items, row, group) {
  if (items.length === 1 && items[0].expr === '*') {
    const o = {};
    for (const [k, v] of Object.entries(row)) if (!/^t\d+\./.test(k)) o[k] = v;
    return o;
  }
  const o = {};
  for (const it of items) {
    const agg = group ? aggregate(it.expr, group) : undefined;
    o[outputName(it.expr, it.alias)] = agg !== undefined ? agg : evalExpr(it.expr, row);
  }
  return o;
}

function jsonOut(rows) {
  if (rows.length === 0) return '[]';
  return '[' + rows.map(r => JSON.stringify(r)).join(',\n') + ']';
}

function prettyOut(rows) {
  const cols = [...new Set(rows.flatMap(r => Object.keys(r)))].sort();
  const widths = cols.map(c => Math.max(c.length, ...rows.map(r => String(r[c] ?? '').length)));
  const line = '+' + widths.map(w => '-'.repeat(w + 2)).join('+') + '+';
  const fmt = vals => '| ' + vals.map((v, i) => {
    const s = String(v ?? ''); const pad = ' '.repeat(widths[i] - s.length);
    return /^-?\d+(\.\d+)?$/.test(s) ? pad + s : s + pad;
  }).join(' | ') + ' |';
  return [line, fmt(cols), line, ...rows.map(r => fmt(cols.map(c => r[c]))), line, `(${rows.length} ${rows.length === 1 ? 'row' : 'rows'})`].join('\n');
}

function main() {
  try {
    const { opts, rest } = parseArgs(process.argv.slice(2));
    if (opts.help) { usage(); return; }
    if (opts.version) { console.log('dsq latest'); return; }
    if (opts.interactive) { console.error('interactive mode is not supported in this build'); process.exit(1); }
    let query = opts.queryFile ? fs.readFileSync(opts.queryFile, 'utf8') : null;
    const files = [];
    for (const a of rest) {
      if (query == null && /^select\b/i.test(a.trim())) query = a;
      else files.push(a);
    }
    const tables = [];
    if (files.length) {
      for (const f of files) tables.push(parseFile(f));
    } else {
      const input = fs.readFileSync(0, 'utf8');
      tables.push(parseData(input, opts.stdinFormat || 'json'));
    }
    if (opts.schema) { console.log(JSON.stringify(schema(tables[0]), null, 2)); return; }
    const rows = execute(query || 'select * from t0', tables);
    console.log(opts.pretty ? prettyOut(rows) : jsonOut(rows));
  } catch (e) {
    console.error(e.message || String(e));
    process.exit(1);
  }
}

main();
