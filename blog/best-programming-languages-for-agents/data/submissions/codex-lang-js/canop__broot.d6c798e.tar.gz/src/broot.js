#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");

const VERSION = "1.54.0";

const LONG_WITH_VALUE = new Set([
  "conf", "max-depth", "outcmd", "verb-output", "cmd", "color", "height",
  "set-install-state", "print-shell-function", "listen", "write-default-conf",
  "send",
]);
const FLAGS = new Set([
  "help", "version", "dates", "no-dates", "only-folders", "no-only-folders",
  "show-root-fs", "show-git-info", "no-show-git-info", "git-status", "hidden",
  "no-hidden", "git-ignored", "no-git-ignored", "permissions", "no-permissions",
  "sizes", "no-sizes", "sort-by-count", "sort-by-date", "sort-by-size",
  "sort-by-type", "tree", "no-tree", "sort-by-type-dirs-first",
  "sort-by-type-dirs-last", "no-sort", "whale-spotting", "no-whale-spotting",
  "trim-root", "no-trim-root", "install", "listen-auto", "get-root",
]);
const SHORT = {
  d: "dates", D: "no-dates", f: "only-folders", F: "no-only-folders",
  g: "show-git-info", G: "no-show-git-info", h: "hidden", H: "no-hidden",
  i: "git-ignored", I: "no-git-ignored", p: "permissions", P: "no-permissions",
  s: "sizes", S: "no-sizes", w: "whale-spotting", W: "no-whale-spotting",
  t: "trim-root", T: "no-trim-root", c: "cmd",
};

function die(msg, usage = false) {
  console.error(msg);
  if (usage) console.error("\nUsage: executable [OPTIONS] [ROOT]");
  process.exitCode = 2;
  return null;
}

function parseArgs(argv) {
  const opts = { root: null, flags: {}, values: {} };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === "--") {
      if (i + 1 < argv.length) opts.root = argv[++i];
      continue;
    }
    if (a.startsWith("--")) {
      let name = a.slice(2), val = null;
      const eq = name.indexOf("=");
      if (eq >= 0) {
        val = name.slice(eq + 1);
        name = name.slice(0, eq);
      }
      if (LONG_WITH_VALUE.has(name)) {
        if (val === null) {
          if (i + 1 >= argv.length) return die(`error: a value is required for '--${name} <${valueName(name)}>' but none was supplied`);
          val = argv[++i];
        }
        opts.values[name] = val;
      } else if (FLAGS.has(name)) {
        opts.flags[name] = true;
      } else {
        return die(`error: unexpected argument '--${name}' found\n\n  tip: to pass '--${name}' as a value, use '-- --${name}'`, true);
      }
    } else if (a.startsWith("-") && a !== "-") {
      const letters = a.slice(1);
      for (let j = 0; j < letters.length; j++) {
        const ch = letters[j];
        if (ch === "V") return die("error: unexpected argument '-V' found\n\n  tip: to pass '-V' as a value, use '-- -V'", true);
        const name = SHORT[ch];
        if (!name) return die(`error: unexpected argument '-${ch}' found`, true);
        if (name === "cmd") {
          let val = letters.slice(j + 1);
          if (!val) {
            if (i + 1 >= argv.length) return die("error: a value is required for '--cmd <cmd>' but none was supplied");
            val = argv[++i];
          }
          opts.values.cmd = val;
          break;
        }
        opts.flags[name] = true;
      }
    } else if (!opts.root) {
      opts.root = a;
    } else {
      return die(`error: unexpected argument '${a}' found`, true);
    }
  }
  return opts;
}

function valueName(name) {
  return {
    "conf": "paths", "max-depth": "MAX_DEPTH", "outcmd": "path",
    "verb-output": "verb-output", "cmd": "cmd", "color": "color",
    "height": "height", "set-install-state": "state",
    "print-shell-function": "shell", "listen": "socket",
    "write-default-conf": "path", "send": "socket",
  }[name] || name;
}

function validate(opts) {
  const color = opts.values.color;
  if (color && !["auto", "yes", "no"].includes(color)) {
    return die(`error: invalid value '${color}' for '--color <color>'\n  [possible values: auto, yes, no]`);
  }
  for (const k of ["max-depth", "height"]) {
    if (opts.values[k] && !/^\d+$/.test(opts.values[k])) {
      const err = /\D/.test(opts.values[k]) ? "invalid digit found in string" : "number too large";
      return die(`error: invalid value '${opts.values[k]}' for '--${k} <${valueName(k)}>': ${err}`);
    }
  }
  const state = opts.values["set-install-state"];
  if (state && !["undefined", "refused", "installed"].includes(state)) {
    return die(`error: invalid value '${state}' for '--set-install-state <state>'\n  [possible values: undefined, refused, installed]`);
  }
  return true;
}

function help() {
  process.stdout.write(`                   \x1b[1m\x1b[4mbroot\x1b[0m\x1b[1m\x1b[4m \x1b[0m\x1b[1m\x1b[4m${VERSION}\x1b[0m


\x1b[1mbroot\x1b[0m lets you explore file hierarchies with a 
tree-like view, manipulate and preview files, 
launch actions, and define your own shortcuts.

\x1b[1mbroot\x1b[0m is best launched as \x1b[48;5;235m\x1b[38;5;249mbr\x1b[49m\x1b[39m: this shell function 
gives you access to more commands, especially \x1b[48;5;235m\x1b[38;5;249mcd.\x1b[49m\x1b[39m 
The br shell function is interactively installed 
on first broot launch.

Flags and options can be classically passed on 
launch but also written in the configuration file.
Each flag has a counter-flag so that you can 
cancel at command line a flag which has been set 
in the configuration file.

Complete documentation and tips at 
https://dystroy.org/broot

\x1b[1mUsage: \x1b[0m \x1b[48;5;235m\x1b[38;5;249mbroot\x1b[49m\x1b[39m\x1b[48;5;235m\x1b[38;5;249m [options]\x1b[49m\x1b[39m\x1b[48;5;235m\x1b[38;5;249m [ROOT]\x1b[49m\x1b[39m

• ROOT : Root Directory

\x1b[1mOptions:\x1b[0m
  --help                     Print help information
  --version                  print the version
  --conf <paths>             Semicolon separated paths to specific config files
  -d, --dates                Show the last modified date of files and directories
  -f, --only-folders         Only show folders
  --max-depth <MAX_DEPTH>    Only show trees up to a certain depth
  -h, --hidden               Show hidden files
  -p, --permissions          Show permissions
  -s, --sizes                Show the size of files and directories
  --sort-by-size             Sort by size (only show one level of the tree)
  -w, --whale-spotting       Sort by size, show ignored and hidden files
  -c, --cmd <cmd>            Semicolon separated commands to execute
  --color <color>            Whether to have styles and colors [auto, yes, no]
  --height <height>          Height (if you don't want to fill the screen or for file export)
  --print-shell-function <shell>
  --write-default-conf <path>
  --send <socket>
`);
}

function shellFunction(shell) {
  if (shell === "bash" || shell === "zsh") return `
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like \`cd\`,
# have no useful effect if executed in a subshell.
function br {
    local cmd cmd_file code
    cmd_file=$(mktemp)
    if broot --outcmd "$cmd_file" "$@"; then
        cmd=$(<"$cmd_file")
        command rm -f "$cmd_file"
        eval "$cmd"
    else
        code=$?
        command rm -f "$cmd_file"
        return "$code"
    fi
}

`;
  if (shell === "fish") return `
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like \`cd\`,
# have no useful effect if executed in a subshell.
function br --wraps=broot
    set -l cmd_file (mktemp)
    if broot --outcmd $cmd_file $argv
        source $cmd_file
        rm -f $cmd_file
    else
        set -l code $status
        rm -f $cmd_file
        return $code
    end
end

`;
  if (shell === "nushell" || shell === "nu") return `# Launch broot
export def --env br [file?: path] {
    let path = (mktemp)
    broot --outcmd $path $file
    if ($path | path exists) { source $path; rm -f $path }
}
`;
  return `Unknown shell: ${shell}\n`;
}

function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const ent of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, ent.name);
    const d = path.join(dst, ent.name);
    if (ent.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}

function modeString(st) {
  const type = st.isDirectory() ? "d" : st.isSymbolicLink() ? "l" : "-";
  const bits = [
    0o400, 0o200, 0o100, 0o040, 0o020, 0o010, 0o004, 0o002, 0o001,
  ];
  const chars = ["r", "w", "x", "r", "w", "x", "r", "w", "x"];
  return type + bits.map((b, i) => (st.mode & b) ? chars[i] : "-").join("");
}

function humanSize(n) {
  if (n < 1000) return String(n);
  const units = ["K", "M", "G", "T"];
  let v = n, u = "";
  for (const unit of units) {
    v /= 1000; u = unit;
    if (v < 1000) break;
  }
  return v >= 10 ? `${Math.round(v)}${u}` : `${Math.round(v * 10) / 10}${u}`;
}

function formatDate(ms) {
  const d = new Date(ms);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${y}/${m}/${day} ${hh}:${mm}`;
}

function listEntries(dir, opts, depth) {
  let ents = [];
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return []; }
  const showHidden = opts.flags.hidden || opts.flags["whale-spotting"] || opts.flags["git-status"];
  ents = ents.filter(e => showHidden || !e.name.startsWith("."));
  ents = ents.map(e => {
    const p = path.join(dir, e.name);
    let st; try { st = fs.lstatSync(p); } catch { return null; }
    return { name: e.name, path: p, st, isDir: st.isDirectory() };
  }).filter(Boolean);
  if (opts.flags["only-folders"]) ents = ents.filter(e => e.isDir);
  const cmpName = (a, b) => a.name.localeCompare(b.name);
  if (opts.flags["sort-by-size"] || opts.flags["whale-spotting"]) ents.sort((a, b) => sizeOf(b.path) - sizeOf(a.path) || cmpName(a, b));
  else if (opts.flags["sort-by-date"]) ents.sort((a, b) => b.st.mtimeMs - a.st.mtimeMs || cmpName(a, b));
  else if (opts.flags["sort-by-type"] || opts.flags["sort-by-type-dirs-first"]) ents.sort((a, b) => Number(b.isDir) - Number(a.isDir) || cmpName(a, b));
  else if (opts.flags["sort-by-type-dirs-last"]) ents.sort((a, b) => Number(a.isDir) - Number(b.isDir) || cmpName(a, b));
  else if (!opts.flags["no-sort"]) ents.sort(cmpName);
  return ents;
}

function sizeOf(p) {
  let st; try { st = fs.lstatSync(p); } catch { return 0; }
  if (!st.isDirectory()) return st.size;
  let sum = 0;
  for (const e of listEntries(p, { flags: { hidden: true }, values: {} }, 0)) sum += sizeOf(e.path);
  return sum;
}

function tree(root, opts) {
  root = path.resolve(root || process.cwd());
  const maxDepth = opts.values["max-depth"] ? Number(opts.values["max-depth"]) : Infinity;
  const lines = [];
  const rootLabel = opts.flags["trim-root"] ? path.basename(root) || root : root;
  lines.push(rootLabel);
  function add(dir, prefix, depth) {
    if (depth >= maxDepth) return;
    const ents = listEntries(dir, opts, depth);
    ents.forEach((e, idx) => {
      const last = idx === ents.length - 1;
      const branch = last ? "└──" : "├──";
      const nextPrefix = prefix + (last ? "   " : "│  ");
      let meta = "";
      if (opts.flags.permissions) meta += modeString(e.st) + " ";
      if (opts.flags.sizes || opts.flags["whale-spotting"]) meta += String(humanSize(sizeOf(e.path))).padStart(4) + " ";
      if (opts.flags.dates) meta += formatDate(e.st.mtimeMs) + " ";
      lines.push(`${meta}${prefix}${branch}${e.name}`);
      if (e.isDir && !opts.flags["sort-by-count"] && !opts.flags["sort-by-date"] && !opts.flags["sort-by-size"] && !opts.flags["sort-by-type"] && !opts.flags["sort-by-type-dirs-first"] && !opts.flags["sort-by-type-dirs-last"]) {
        add(e.path, nextPrefix, depth + 1);
      }
    });
  }
  if (!opts.flags["no-tree"]) add(root, "", 0);
  return lines.join("\n") + "\n";
}

function findFirst(root, pattern, opts) {
  if (!pattern || pattern.startsWith(":")) return path.resolve(root);
  const needle = pattern.replace(/^\/|\/$/g, "").toLowerCase();
  let best = null;
  function walk(dir) {
    for (const e of listEntries(dir, { flags: { hidden: true }, values: {} }, 0)) {
      if (!best && e.name.toLowerCase().includes(needle)) best = e.path;
      if (e.isDir && !best) walk(e.path);
    }
  }
  walk(root);
  return best || path.resolve(root);
}

function runCmd(opts) {
  const root = path.resolve(opts.root || process.cwd());
  const sep = process.env.BROOT_CMD_SEPARATOR || ";";
  const cmds = String(opts.values.cmd || "").split(sep).map(s => s.trim()).filter(Boolean);
  let selected = root;
  for (const c of cmds) {
    if (c === ":pt" || c === ":print_tree") process.stdout.write(tree(root, opts));
    else if (c === ":pp" || c === ":print_path") process.stdout.write(selected + "\n");
    else if (c === ":prp" || c === ":print_relative_path") process.stdout.write((path.relative(root, selected) || ".") + "\n");
    else if (c === ":q" || c === ":quit") return;
    else if (c === ":cd") {
      const d = fs.existsSync(selected) && fs.statSync(selected).isDirectory() ? selected : path.dirname(selected);
      if (opts.values.outcmd) fs.writeFileSync(opts.values.outcmd, `cd ${JSON.stringify(d)}\n`);
      return;
    } else if (!c.startsWith(":")) selected = findFirst(root, c, opts);
  }
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (!opts || !validate(opts)) return;
  if (opts.flags.help) return help();
  if (opts.flags.version || opts.values.version) return console.log(`broot ${VERSION}`);
  if (opts.values["print-shell-function"]) return process.stdout.write(shellFunction(opts.values["print-shell-function"]));
  if (opts.values["write-default-conf"]) {
    const candidates = [
      path.join(__dirname, "resources", "default-conf"),
      path.join(__dirname, "..", "resources", "default-conf"),
    ];
    const src = candidates.find(p => fs.existsSync(p));
    if (!src) {
      console.error("Default configuration files not found");
      process.exitCode = 1;
      return;
    }
    copyDir(src, opts.values["write-default-conf"]);
    return;
  }
  if (opts.values["set-install-state"]) {
    const dir = path.join(os.homedir(), ".config", "broot", "launcher");
    fs.mkdirSync(dir, { recursive: true });
    if (opts.values["set-install-state"] === "refused") fs.writeFileSync(path.join(dir, "refused"), "");
    return;
  }
  if (opts.values.cmd) return runCmd(opts);
  if (opts.values.outcmd) fs.writeFileSync(opts.values.outcmd, "");
  process.stderr.write("Termimad Error : IO error: No such device or address (os error 6)\n");
  process.exitCode = 1;
}

main();
