#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const readline = require('readline');
const child_process = require('child_process');

const VERSION = '0.10.0';
const ARCHIVE = new Set(['7z','bz2','bzip2','gz','gzip','lz','rar','tar','xz','zip']);
const AUDIO = new Set(['aac','aiff','amr','flac','gsm','m4a','m4b','m4p','mp3','ogg','wav','wma']);
const BOOK = new Set(['azw3','chm','djv','djvu','epub','fb2','mobi','pdf']);
const DOC = new Set(['accdb','doc','docm','docx','dot','dotm','dotx','mdb','odp','ods','odt','pdf','potm','potx','ppt','pptm','pptx','rtf','xlm','xls','xlsm','xlsx','xlt','xltm','xltx','xps']);
const FONT = new Set(['eot','fon','otc','otf','ttc','ttf','woff','woff2']);
const IMAGE = new Set(['bmp','exr','gif','heic','jpeg','jpg','jxl','png','psb','psd','svg','tga','tiff','webp']);
const SOURCE = new Set(['asm','awk','bas','c','cc','ceylon','clj','coffee','cpp','cs','d','dart','elm','erl','go','gradle','groovy','h','hh','hpp','java','jl','js','jsp','jsx','kt','kts','lua','nim','pas','php','pl','pm','py','rb','rs','scala','sol','swift','tcl','ts','tsx','vala','vb','zig']);
const VIDEO = new Set(['3gp','avi','flv','m4p','m4v','mkv','mov','mp4','mpeg','mpg','webm','wmv']);

let showErrors = true;
let noColor = false;
const userCache = new Map(), groupCache = new Map();

function color(s, c) { return noColor ? s : `\x1b[${c}m${s}\x1b[0m`; }

function help() {
  console.log(`fselect ${color(VERSION, '33')}
Find files with SQL-like queries.
${color('https://github.com/jhspetersson/fselect', '4;36')}

Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]

Files Detected as Archives: .7z, .bz2, .bzip2, .gz, .gzip, .lz, .rar, .tar, .xz, .zip
Files Detected as Audio: .aac, .aiff, .amr, .flac, .gsm, .m4a, .m4b, .m4p, .mp3, .ogg, .wav, .wma
Files Detected as Book: .azw3, .chm, .djv, .djvu, .epub, .fb2, .mobi, .pdf
Files Detected as Document: .accdb, .doc, .docm, .docx, .dot, .dotm, .dotx, .mdb, .odp, .ods, .odt, .pdf, .potm, .potx, .ppt, .pptm, .pptx, .rtf, .xlm, .xls, .xlsm, .xlsx, .xlt, .xltm, .xltx, .xps
Files Detected as Fonts: .eot, .fon, .otc, .otf, .ttc, .ttf, .woff, .woff2
Files Detected as Image: .bmp, .exr, .gif, .heic, .jpeg, .jpg, .jxl, .png, .psb, .svg, .tga, .tiff, .webp
Files Detected as Source Code: .asm, .awk, .bas, .c, .cc, .cpp, .cs, .dart, .go, .h, .hpp, .java, .js, .jsx, .kt, .lua, .php, .pl, .py, .rb, .rs, .scala, .sh, .swift, .ts, .tsx, .zig
Files Detected as Video: .3gp, .avi, .flv, .m4p, .m4v, .mkv, .mov, .mp4, .mpeg, .mpg, .webm, .wmv

Path Options:
    mindepth                        Minimum depth to search
    maxdepth | depth                Maximum depth to search
    archives | arc                  Whether to search archives
    symlinks | sym                  Whether to follow symlinks
    gitignore | git                 Search respects .gitignore files found
    dfs                             Depth-first search mode
    bfs                             Breadth-first search mode (default)
    as                              Alias for the root path

Column Options:
    name, filename, ext, path, abspath, dir, absdir, size, fsize, hsize
    uid, gid, user, group, created, accessed, modified, mode
    is_dir, is_file, is_symlink, is_pipe, is_char, is_block, is_socket
    permissions, file type shortcuts, hashes, mime, line_count, is_text, is_binary

Functions:
    LOWER, UPPER, INITCAP, LENGTH, CONCAT, CONCAT_WS, SUBSTR, REPLACE, TRIM
    ABS, POWER, SQRT, LOG, LN, EXP, FLOOR, CEIL, ROUND, HEX, OCT, BIN
    CURRENT_DATE, CURRENT_TIME, CURRENT_TIMESTAMP, YEAR, MONTH, DAY
    MIN, MAX, AVG, SUM, COUNT

Format:
    tabs                            Tab-separated values (default)
    lines                           One item per line
    list                            Entire output onto a single line for xargs
    csv                             Comma-separated values
    json                            JSON format
    html                            HTML format

Interactive mode:
    help            Get usage help
    pwd             Print the current working directory
    cd PATH         Change the current working directory to PATH
    errors [ON|OFF] Toggle whether errors are shown or not
    exit | quit     Exit fselect`);
}

function tokenize(q) {
  const out = [];
  let i = 0;
  while (i < q.length) {
    const ch = q[i];
    if (/\s/.test(ch)) { i++; continue; }
    if (ch === "'" || ch === '"' || ch === '`') {
      const quote = ch; let s = ''; i++;
      while (i < q.length) {
        if (q[i] === '\\' && i + 1 < q.length) { s += q[i + 1]; i += 2; continue; }
        if (q[i] === quote) { i++; break; }
        s += q[i++];
      }
      out.push({t:'str', v:s}); continue;
    }
    const three = q.slice(i, i + 3), two = q.slice(i, i + 2);
    if (['===','!==','!=~','!~='].includes(three)) { out.push({t:'op', v:three}); i += 3; continue; }
    if (['>=','<=','!=','<>','==','=~','~='].includes(two)) { out.push({t:'op', v:two}); i += 2; continue; }
    if ('(),{}'.includes(ch)) { out.push({t:ch, v:ch}); i++; continue; }
    if ('+-*/'.includes(ch) && (i === 0 || /\s/.test(q[i - 1])) && (i + 1 === q.length || /\s/.test(q[i + 1]))) {
      out.push({t:ch, v:ch}); i++; continue;
    }
    if ('=<>'.includes(ch)) { out.push({t:'op', v:ch}); i++; continue; }
    let s = '';
    while (i < q.length) {
      const c = q[i];
      if (/\s/.test(c) || '(),{}=<>'.includes(c)) break;
      if ('+-*/'.includes(c) && (i === 0 || /\s/.test(q[i - 1])) && (i + 1 === q.length || /\s/.test(q[i + 1]))) break;
      s += q[i++];
    }
    out.push({t:'word', v:s});
  }
  return out;
}

function low(tok) { return tok && String(tok.v).toLowerCase(); }
function isWord(tok, w) { return tok && (tok.t === 'word' || tok.t === 'str') && low(tok) === w; }
function findClause(tokens, words, start=0) {
  let depth = 0;
  for (let i = start; i < tokens.length; i++) {
    const t = tokens[i].v;
    if (t === '(' || t === '{') depth++;
    else if (t === ')' || t === '}') depth--;
    if (depth === 0 && words.every((w, j) => isWord(tokens[i + j], w))) return i;
  }
  return -1;
}
function firstClause(tokens, start, clauses) {
  let best = tokens.length, name = null;
  for (const c of clauses) {
    const p = findClause(tokens, c.split(' '), start);
    if (p >= 0 && p < best) { best = p; name = c; }
  }
  return {pos: best, name};
}

function splitTop(tokens, sep=',') {
  const parts = []; let cur = [], depth = 0;
  for (const t of tokens) {
    if (t.v === '(' || t.v === '{') depth++;
    if (t.v === ')' || t.v === '}') depth--;
    if (depth === 0 && t.v === sep) { if (cur.length) parts.push(cur); cur = []; }
    else cur.push(t);
  }
  if (cur.length) parts.push(cur);
  return parts;
}

function parseQuery(q) {
  let tokens = tokenize(q);
  if (isWord(tokens[0], 'select')) tokens = tokens.slice(1);
  const clauses = ['from','where','group by','order by','limit','offset','into'];
  const first = firstClause(tokens, 0, clauses).pos;
  let colTokens = tokens.slice(0, first);
  if (!colTokens.length) throw new Error('query: could not parse tokens at the end of the query');
  let columns = splitTop(colTokens).map(parseExpr);
  if (columns.length === 1 && !colTokens.some(t => t.v === ',')) {
    const simple = splitColumnsWithoutCommas(colTokens);
    if (simple.length > 1) columns = simple.map(parseExpr);
  }
  let roots = [{path:'.', mindepth:1, maxdepth:Infinity, symlinks:false, dfs:false}];
  let where = null, group = [], order = [], limit = null, offset = 0, format = 'tabs';
  let pos = first;
  while (pos < tokens.length) {
    if (isWord(tokens[pos], 'from')) {
      const next = firstClause(tokens, pos + 1, clauses.filter(c => c !== 'from')).pos;
      roots = parseRoots(tokens.slice(pos + 1, next)); pos = next;
    } else if (isWord(tokens[pos], 'where')) {
      const next = firstClause(tokens, pos + 1, ['group by','order by','limit','offset','into']).pos;
      where = new ExprParser(tokens.slice(pos + 1, next)).parse(); pos = next;
    } else if (isWord(tokens[pos], 'group') && isWord(tokens[pos+1], 'by')) {
      const next = firstClause(tokens, pos + 2, ['order by','limit','offset','into']).pos;
      group = splitTop(tokens.slice(pos + 2, next)).map(parseExpr); pos = next;
    } else if (isWord(tokens[pos], 'order') && isWord(tokens[pos+1], 'by')) {
      const next = firstClause(tokens, pos + 2, ['limit','offset','into']).pos;
      order = parseOrder(tokens.slice(pos + 2, next)); pos = next;
    } else if (isWord(tokens[pos], 'limit')) {
      limit = Number(tokens[pos + 1]?.v || 0); pos += 2;
    } else if (isWord(tokens[pos], 'offset')) {
      offset = Number(tokens[pos + 1]?.v || 0); pos += 2;
    } else if (isWord(tokens[pos], 'into')) {
      format = String(tokens[pos + 1]?.v || 'tabs').toLowerCase(); pos += 2;
    } else {
      throw new Error('query: could not parse tokens at the end of the query\n' + tokens.slice(pos).map(t => t.v).join(' '));
    }
  }
  return {columns, roots, where, group, order, limit, offset, format};
}

function splitColumnsWithoutCommas(tokens) {
  const res = []; let cur = [], depth = 0;
  for (const t of tokens) {
    if (t.v === '(' || t.v === '{') depth++;
    if (t.v === ')' || t.v === '}') depth--;
    if (depth === 0 && cur.length && (t.t === 'word' || t.t === 'str')) { res.push(cur); cur = [t]; }
    else cur.push(t);
  }
  if (cur.length) res.push(cur);
  return res;
}

function parseRoots(tokens) {
  const roots = [];
  for (const part of splitTop(tokens)) {
    if (!part.length) continue;
    const r = {path:null, mindepth:1, maxdepth:Infinity, symlinks:false, dfs:false};
    for (let i = 0; i < part.length; i++) {
      const w = low(part[i]);
      if (['mindepth'].includes(w)) r.mindepth = Number(part[++i]?.v || 0);
      else if (['maxdepth','depth'].includes(w)) r.maxdepth = Number(part[++i]?.v || Infinity);
      else if (['symlinks','sym'].includes(w)) r.symlinks = true;
      else if (w === 'dfs') r.dfs = true;
      else if (w === 'bfs') r.dfs = false;
      else if (['archives','arc','gitignore','git','nogitignore','nogit','hgignore','hg','dockerignore','docker','regexp','rx'].includes(w)) {}
      else if (w === 'as') { i++; }
      else if (!r.path) r.path = part[i].v;
      else r.path += ' ' + part[i].v;
    }
    if (!r.path) r.path = '.';
    roots.push(r);
  }
  return roots.length ? roots : [{path:'.', mindepth:1, maxdepth:Infinity, symlinks:false, dfs:false}];
}

function parseOrder(tokens) {
  return splitTop(tokens).map(p => {
    let dir = 'asc';
    if (p.length && ['asc','desc'].includes(low(p[p.length - 1]))) dir = low(p.pop());
    return {expr: parseExpr(p), dir};
  });
}

class ExprParser {
  constructor(tokens) { this.tokens = tokens; this.i = 0; }
  peek() { return this.tokens[this.i]; }
  take() { return this.tokens[this.i++]; }
  matchWord(w) { if (isWord(this.peek(), w)) { this.i++; return true; } return false; }
  parse() { return this.parseOr(); }
  parseOr() {
    let n = this.parseAnd();
    while (this.matchWord('or')) n = {type:'or', left:n, right:this.parseAnd()};
    return n;
  }
  parseAnd() {
    let n = this.parseCmp();
    while (this.matchWord('and')) n = {type:'and', left:n, right:this.parseCmp()};
    return n;
  }
  parseCmp() {
    let l = this.parseAdd();
    if (this.matchWord('between')) {
      const a = this.parseAdd(); this.matchWord('and'); const b = this.parseAdd();
      return {type:'between', left:l, a, b};
    }
    if (this.matchWord('in')) {
      let vals = [];
      if (this.peek()?.v === '(' || this.peek()?.v === '{') {
        this.take(); const inner = [];
        while (this.peek() && this.peek().v !== ')' && this.peek().v !== '}') inner.push(this.take());
        this.take(); vals = splitTop(inner).map(parseExpr);
      } else vals = [this.parseAdd()];
      return {type:'in', left:l, vals};
    }
    let op = null;
    if (this.peek()?.t === 'op') op = this.take().v;
    else if (['eq','eeq','ne','ene','lt','lte','le','gt','gte','ge','regexp','rx','notrx','like','notlike'].includes(low(this.peek()))) op = low(this.take());
    if (op) return {type:'cmp', op, left:l, right:this.parseAdd()};
    return l;
  }
  parseAdd() {
    let n = this.parseMul();
    while (this.peek() && ['+','-'].includes(this.peek().v)) {
      const op = this.take().v; n = {type:'arith', op, left:n, right:this.parseMul()};
    }
    return n;
  }
  parseMul() {
    let n = this.parseUnary();
    while (this.peek() && ['*','/'].includes(this.peek().v)) {
      const op = this.take().v; n = {type:'arith', op, left:n, right:this.parseUnary()};
    }
    return n;
  }
  parseUnary() {
    if (this.matchWord('not')) return {type:'not', expr:this.parseUnary()};
    if (this.peek()?.v === '-') { this.take(); return {type:'neg', expr:this.parseUnary()}; }
    return this.parsePrimary();
  }
  parsePrimary() {
    const t = this.take();
    if (!t) return {type:'literal', value:''};
    if (t.v === '(' || t.v === '{') {
      const n = this.parseOr();
      if (this.peek() && (this.peek().v === ')' || this.peek().v === '}')) this.take();
      return n;
    }
    if ((t.t === 'word' || t.t === 'str') && (this.peek()?.v === '(' || this.peek()?.v === '{')) {
      this.take();
      const args = []; let cur = [], depth = 0;
      while (this.peek()) {
        const p = this.peek();
        if (depth === 0 && (p.v === ')' || p.v === '}')) { if (cur.length) args.push(parseExpr(cur)); this.take(); break; }
        if (depth === 0 && p.v === ',') { args.push(parseExpr(cur)); cur = []; this.take(); continue; }
        if (p.v === '(' || p.v === '{') depth++;
        if (p.v === ')' || p.v === '}') depth--;
        cur.push(this.take());
      }
      return {type:'func', name:t.v, args};
    }
    if (t.t === 'str') return {type:'literal', value:t.v};
    const v = t.v;
    if (/^\d+(\.\d+)?([kmgt]i?b?|b)?$/i.test(v)) return {type:'literal', value:parseSize(v)};
    if (/^(true|false)$/i.test(v)) return {type:'literal', value:/^true$/i.test(v)};
    if (v === '*') return {type:'star'};
    if (/^\d+$/.test(v)) return {type:'literal', value:Number(v)};
    return {type:'ident', name:v};
  }
}

function parseExpr(tokens) { return new ExprParser(tokens).parse(); }

function walkRoot(rootSpec) {
  let root = expandHome(rootSpec.path);
  let absRoot;
  try { absRoot = fs.realpathSync(root); }
  catch (e) { if (showErrors) console.error(`${color(root, '33')}: could not canonicalize path: ${e.message}`); process.exitCode = 1; return []; }
  const out = [], q = [];
  function add(abs, rel, depth) {
    let lst;
    try { lst = fs.lstatSync(abs); } catch (e) { if (showErrors) console.error(`${abs}: ${e.message}`); return; }
    let st = lst;
    if (rootSpec.symlinks && lst.isSymbolicLink()) { try { st = fs.statSync(abs); } catch {} }
    if (depth >= rootSpec.mindepth) out.push({abs, rel, root:absRoot, lstat:lst, stat:st, depth});
    if ((st.isDirectory() || (lst.isDirectory && lst.isDirectory())) && depth < rootSpec.maxdepth) q.push({abs, rel, depth});
  }
  q.push({abs:absRoot, rel:'', depth:0});
  while (q.length) {
    const cur = rootSpec.dfs ? q.pop() : q.shift();
    let names; try { names = fs.readdirSync(cur.abs); } catch (e) { if (showErrors) console.error(`${cur.abs}: ${e.message}`); continue; }
    for (const name of names) add(path.join(cur.abs, name), cur.rel ? cur.rel + '/' + name : name, cur.depth + 1);
  }
  return out;
}

function expandHome(p) { return p === '~' ? os.homedir() : p.startsWith('~/') ? path.join(os.homedir(), p.slice(2)) : p; }
function basenameNoExt(n) { const e = path.extname(n); return e ? n.slice(0, -e.length) : n; }
function ext(n) { const e = path.extname(n); return e ? e.slice(1) : ''; }
function dirRel(r) { const d = path.posix.dirname(r.rel); return d === '.' ? '' : d; }
function fmtDate(ms) {
  const d = new Date(ms);
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
function modeString(st) {
  const m = st.mode, type = st.isDirectory()? 'd' : st.isSymbolicLink?.()? 'l' : st.isFIFO?.()? 'p' : st.isSocket?.()? 's' : st.isBlockDevice?.()? 'b' : st.isCharacterDevice?.()? 'c' : '-';
  const bits = [[0o400,'r'],[0o200,'w'],[0o100,'x'],[0o040,'r'],[0o020,'w'],[0o010,'x'],[0o004,'r'],[0o002,'w'],[0o001,'x']];
  let s = type + bits.map(([b,c]) => (m & b) ? c : '-').join('');
  if (m & 0o4000) s = s.slice(0,3) + (m & 0o100 ? 's' : 'S') + s.slice(4);
  if (m & 0o2000) s = s.slice(0,6) + (m & 0o010 ? 's' : 'S') + s.slice(7);
  if (m & 0o1000) s = s.slice(0,9) + (m & 0o001 ? 't' : 'T');
  return s;
}
function idName(id, kind) {
  const cache = kind === 'user' ? userCache : groupCache;
  if (cache.has(id)) return cache.get(id);
  try {
    const cmd = kind === 'user' ? `getent passwd ${id}` : `getent group ${id}`;
    const out = child_process.execSync(cmd, {encoding:'utf8', stdio:['ignore','pipe','ignore']}).trim();
    const name = out.split(':')[0] || String(id); cache.set(id, name); return name;
  } catch { cache.set(id, String(id)); return String(id); }
}
function humanSize(n) {
  const units = ['B','KiB','MiB','GiB','TiB']; let v = Number(n), i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return (i === 0 ? String(v) : (Number.isInteger(v) ? String(v) : v.toFixed(1).replace(/\.0$/,''))) + units[i];
}
function parseSize(s) {
  const m = String(s).match(/^(\d+(?:\.\d+)?)([kmgt]?)(i?b?|b)?$/i);
  if (!m) return s;
  const pow = {k:1,m:2,g:3,t:4}[(m[2] || '').toLowerCase()] || 0;
  return Number(m[1]) * Math.pow(1024, pow);
}
function mimeFor(e, rec) {
  e = e.toLowerCase();
  if (rec.stat.isDirectory()) return 'inode/directory';
  if (rec.stat.size === 0) return 'text/plain';
  const map = {txt:'text/plain',md:'text/plain',js:'application/javascript',json:'application/json',html:'text/html',htm:'text/html',css:'text/css',csv:'text/csv',svg:'image/svg+xml',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',pdf:'application/pdf',zip:'application/zip',gz:'application/gzip',tar:'application/x-tar',mp3:'audio/mpeg',mp4:'video/mp4'};
  return map[e] || 'application/octet-stream';
}
function readSmall(abs, max=65536) {
  try { const fd = fs.openSync(abs, 'r'); const b = Buffer.alloc(max); const n = fs.readSync(fd, b, 0, max, 0); fs.closeSync(fd); return b.slice(0, n); } catch { return Buffer.alloc(0); }
}
function lineCount(rec) {
  if (rec.stat.isDirectory()) return '';
  const b = readSmall(rec.abs, 10 * 1024 * 1024);
  let c = 0; for (const x of b) if (x === 10) c++;
  return c;
}
function hashFile(abs, alg) { try { return crypto.createHash(alg).update(fs.readFileSync(abs)).digest('hex'); } catch { return ''; } }

function col(rec, name) {
  const n = String(name).toLowerCase();
  const st = rec.stat, lst = rec.lstat, base = path.posix.basename(rec.rel), ex = ext(base).toLowerCase(), m = st.mode;
  switch (n) {
    case 'name': return base;
    case 'filename': case 'fname': return basenameNoExt(base);
    case 'ext': case 'extension': return ext(base);
    case 'path': return rec.rel;
    case 'abspath': return rec.abs;
    case 'dir': case 'directory': case 'dirname': return dirRel(rec);
    case 'absdir': return path.dirname(rec.abs);
    case 'size': return st.size;
    case 'fsize': case 'hsize': return humanSize(st.size);
    case 'uid': return st.uid;
    case 'gid': return st.gid;
    case 'user': return idName(st.uid, 'user');
    case 'group': return idName(st.gid, 'group');
    case 'created': return fmtDate(st.birthtimeMs);
    case 'accessed': return fmtDate(st.atimeMs);
    case 'modified': return fmtDate(st.mtimeMs);
    case 'atime': return Math.floor(st.atimeMs / 1000);
    case 'mtime': return Math.floor(st.mtimeMs / 1000);
    case 'ctime': return Math.floor(st.ctimeMs / 1000);
    case 'device': return st.dev; case 'rdev': return st.rdev; case 'inode': return st.ino; case 'blocks': return (st.blocks || 0) * 2; case 'hardlinks': return st.nlink;
    case 'mode': return modeString(lst);
    case 'is_dir': return st.isDirectory();
    case 'is_file': return st.isFile();
    case 'is_symlink': return lst.isSymbolicLink();
    case 'is_pipe': case 'is_fifo': return st.isFIFO();
    case 'is_char': case 'is_character': return st.isCharacterDevice();
    case 'is_block': return st.isBlockDevice();
    case 'is_socket': return st.isSocket();
    case 'is_hidden': return base.startsWith('.');
    case 'user_read': return !!(m & 0o400); case 'user_write': return !!(m & 0o200); case 'user_exec': return !!(m & 0o100); case 'user_all': case 'user_rwx': return (m & 0o700) === 0o700;
    case 'group_read': return !!(m & 0o040); case 'group_write': return !!(m & 0o020); case 'group_exec': return !!(m & 0o010); case 'group_all': case 'group_rwx': return (m & 0o070) === 0o070;
    case 'other_read': return !!(m & 0o004); case 'other_write': return !!(m & 0o002); case 'other_exec': return !!(m & 0o001); case 'other_all': case 'other_rwx': return (m & 0o007) === 0o007;
    case 'suid': case 'is_suid': return !!(m & 0o4000); case 'sgid': case 'is_sgid': return !!(m & 0o2000); case 'sticky': case 'is_sticky': return !!(m & 0o1000);
    case 'is_empty': if (st.isDirectory()) { try { return fs.readdirSync(rec.abs).length === 0; } catch { return false; } } return st.size === 0;
    case 'is_shebang': return st.isFile() && readSmall(rec.abs, 2).toString() === '#!';
    case 'line_count': return lineCount(rec);
    case 'mime': return mimeFor(ex, rec);
    case 'is_text': { const b = readSmall(rec.abs, 4096); return !st.isDirectory() && !b.includes(0); }
    case 'is_binary': { const b = readSmall(rec.abs, 4096); return !st.isDirectory() && b.includes(0); }
    case 'is_archive': return ARCHIVE.has(ex); case 'is_audio': return AUDIO.has(ex); case 'is_book': return BOOK.has(ex); case 'is_doc': return DOC.has(ex); case 'is_font': return FONT.has(ex); case 'is_image': return IMAGE.has(ex); case 'is_source': return SOURCE.has(ex); case 'is_video': return VIDEO.has(ex);
    case 'sha1': return st.isFile() ? hashFile(rec.abs, 'sha1') : '';
    case 'sha2_256': case 'sha256': return st.isFile() ? hashFile(rec.abs, 'sha256') : '';
    case 'sha2_512': case 'sha512': return st.isFile() ? hashFile(rec.abs, 'sha512') : '';
    case 'width': case 'height': case 'duration': case 'bitrate': case 'mp3_bitrate': case 'mp3_freq': case 'freq': return '';
    default:
      if (n.startsWith('exif_') || n.startsWith('mp3_') || ['title','artist','album','genre','has_xattrs','xattr_count','extattrs','has_extattrs','acl','has_acl','default_acl','has_default_acl','has_capabilities','has_caps','capabilities','caps'].includes(n)) return '';
      return name;
  }
}

function evalExpr(node, rec, rows) {
  if (!node) return true;
  switch (node.type) {
    case 'literal': return node.value;
    case 'star': return '*';
    case 'ident': return col(rec, node.name);
    case 'and': return truth(evalExpr(node.left, rec, rows)) && truth(evalExpr(node.right, rec, rows));
    case 'or': return truth(evalExpr(node.left, rec, rows)) || truth(evalExpr(node.right, rec, rows));
    case 'not': return !truth(evalExpr(node.expr, rec, rows));
    case 'neg': return -Number(evalExpr(node.expr, rec, rows));
    case 'arith': { const a = Number(evalExpr(node.left, rec, rows)), b = Number(evalExpr(node.right, rec, rows)); return node.op === '+' ? a+b : node.op === '-' ? a-b : node.op === '*' ? a*b : a/b; }
    case 'cmp': return compare(evalExpr(node.left, rec, rows), node.op, evalExpr(node.right, rec, rows));
    case 'between': { const v = evalExpr(node.left, rec, rows), a = evalExpr(node.a, rec, rows), b = evalExpr(node.b, rec, rows); return cmp(v,a) >= 0 && cmp(v,b) <= 0; }
    case 'in': { const v = evalExpr(node.left, rec, rows); return node.vals.some(x => cmp(v, evalExpr(x, rec, rows)) === 0); }
    case 'func': return evalFunc(node.name, node.args.map(a => evalExpr(a, rec, rows)), rec, rows, node.args);
    default: return '';
  }
}
function truth(v) { return v === true || v === 1 || v === '1' || (typeof v === 'string' && v.toLowerCase() === 'true'); }
function cmp(a, b) {
  const na = Number(a), nb = Number(b);
  if (a !== '' && b !== '' && !Number.isNaN(na) && !Number.isNaN(nb)) return na === nb ? 0 : na < nb ? -1 : 1;
  a = String(a); b = String(b); return a === b ? 0 : a < b ? -1 : 1;
}
function globRe(pat) {
  const esc = String(pat).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.');
  return new RegExp('^' + esc + '$');
}
function likeRe(pat) {
  const esc = String(pat).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/%/g, '.*').replace(/_/g, '.');
  return new RegExp('^' + esc + '$');
}
function compare(a, op, b) {
  op = String(op).toLowerCase();
  const da = parseDateValue(a), db = parseDateSpec(b);
  if (da && db) {
    if (['=','==','eq','===','eeq'].includes(op)) return da >= db.start && da <= db.end;
    if (['!=','<>','ne','!==','ene'].includes(op)) return !(da >= db.start && da <= db.end);
    const t = da.getTime(), lo = db.start.getTime(), hi = db.end.getTime();
    if (['<','lt'].includes(op)) return t < lo;
    if (['<=','lte','le'].includes(op)) return t <= hi;
    if (['>','gt'].includes(op)) return t > hi;
    if (['>=','gte','ge'].includes(op)) return t >= lo;
  }
  if (['=','==','eq'].includes(op)) return /[*?]/.test(String(b)) ? globRe(b).test(String(a)) : cmp(a,b) === 0;
  if (['===','eeq'].includes(op)) return String(a) === String(b);
  if (['!=','<>','ne'].includes(op)) return /[*?]/.test(String(b)) ? !globRe(b).test(String(a)) : cmp(a,b) !== 0;
  if (['!==','ene'].includes(op)) return String(a) !== String(b);
  if (['<','lt'].includes(op)) return cmp(a,b) < 0;
  if (['<=','lte','le'].includes(op)) return cmp(a,b) <= 0;
  if (['>','gt'].includes(op)) return cmp(a,b) > 0;
  if (['>=','gte','ge'].includes(op)) return cmp(a,b) >= 0;
  if (['~=','=~','regexp','rx'].includes(op)) { try { return new RegExp(String(b)).test(String(a)); } catch { return false; } }
  if (['!=~','!~=','notrx'].includes(op)) { try { return !new RegExp(String(b)).test(String(a)); } catch { return true; } }
  if (op === 'like') return likeRe(b).test(String(a));
  if (op === 'notlike') return !likeRe(b).test(String(a));
  return false;
}
function parseDateValue(v) {
  if (typeof v !== 'string') return null;
  const m = v.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2})(?::(\d{2})(?::(\d{2}))?)?)?$/);
  if (!m) return null;
  return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4] || 0), Number(m[5] || 0), Number(m[6] || 0));
}
function parseDateSpec(v) {
  const s = String(v).toLowerCase();
  const now = new Date();
  const day = d => ({start:new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0,0,0), end:new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23,59,59,999)});
  if (s === 'today') return day(now);
  if (s === 'yesterday') { const d = new Date(now); d.setDate(d.getDate() - 1); return day(d); }
  if (s === 'tomorrow') { const d = new Date(now); d.setDate(d.getDate() + 1); return day(d); }
  const m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ t](\d{1,2})(?::(\d{1,2})(?::(\d{1,2}))?)?)?$/);
  if (!m) return null;
  const y = Number(m[1]), mo = Number(m[2]) - 1, d = Number(m[3]);
  const h = m[4] == null ? null : Number(m[4]), mi = m[5] == null ? null : Number(m[5]), se = m[6] == null ? null : Number(m[6]);
  const start = new Date(y, mo, d, h ?? 0, mi ?? 0, se ?? 0, 0);
  const end = new Date(y, mo, d, h ?? 23, mi ?? 59, se ?? 59, 999);
  return {start, end};
}

function evalFunc(name, vals, rec, rows, argNodes) {
  const n = String(name).toLowerCase();
  const s = x => x == null ? '' : String(x);
  if (['lower','lowercase','lcase'].includes(n)) return s(vals[0]).toLowerCase();
  if (['upper','uppercase','ucase'].includes(n)) return s(vals[0]).toUpperCase();
  if (n === 'initcap') return s(vals[0]).replace(/\b\w/g, c => c.toUpperCase());
  if (['length','len'].includes(n)) return s(vals[0]).length;
  if (['to_base64','base64'].includes(n)) return Buffer.from(s(vals[0])).toString('base64');
  if (n === 'from_base64') return Buffer.from(s(vals[0]), 'base64').toString();
  if (n === 'concat') return vals.map(s).join('');
  if (n === 'concat_ws') return vals.slice(1).map(s).join(s(vals[0]));
  if (['substr','substring'].includes(n)) return s(vals[0]).substr((Number(vals[1]) || 1) - 1, vals[2] == null ? undefined : Number(vals[2]));
  if (n === 'replace') return s(vals[0]).split(s(vals[1])).join(s(vals[2]));
  if (n === 'trim') return s(vals[0]).trim(); if (n === 'ltrim') return s(vals[0]).trimStart(); if (n === 'rtrim') return s(vals[0]).trimEnd();
  if (n === 'contains') { try { return fs.readFileSync(rec.abs).includes(Buffer.from(s(vals[0]))); } catch { return false; } }
  if (n === 'coalesce') return vals.find(v => v !== '' && v != null) ?? '';
  if (n === 'abs') return Math.abs(Number(vals[0])); if (['power','pow'].includes(n)) return Math.pow(Number(vals[0]), Number(vals[1]));
  if (n === 'sqrt') return Math.sqrt(Number(vals[0])); if (n === 'log') return Math.log(Number(vals[0])) / Math.log(Number(vals[1] || 10)); if (n === 'ln') return Math.log(Number(vals[0]));
  if (n === 'exp') return Math.exp(Number(vals[0])); if (n === 'floor') return Math.floor(Number(vals[0])); if (['ceil','ceiling'].includes(n)) return Math.ceil(Number(vals[0]));
  if (n === 'round') { const d = Number(vals[1] || 0); const m = Math.pow(10, d); return Math.round(Number(vals[0]) * m) / m; }
  if (n === 'hex') return Number(vals[0]).toString(16); if (n === 'oct') return Number(vals[0]).toString(8); if (n === 'bin') return Number(vals[0]).toString(2); if (n === 'pi') return Math.PI;
  if (['format_size','format_filesize'].includes(n)) return humanSize(Number(vals[0]));
  const now = new Date(); const p = x => String(x).padStart(2,'0');
  if (['current_date','cur_date','curdate'].includes(n)) return `${now.getFullYear()}-${p(now.getMonth()+1)}-${p(now.getDate())}`;
  if (['current_time','cur_time','curtime'].includes(n)) return `${p(now.getHours())}:${p(now.getMinutes())}:${p(now.getSeconds())}`;
  if (['current_timestamp','now'].includes(n)) return fmtDate(now.getTime());
  const d = vals[0] instanceof Date ? vals[0] : new Date(s(vals[0]).replace(' ', 'T'));
  if (n === 'year') return d.getFullYear(); if (n === 'month') return d.getMonth()+1; if (n === 'day') return d.getDate();
  if (['count','sum','min','max','avg'].includes(n)) return aggregate(n, argNodes[0], rows);
  if (n === 'current_uid') return process.getuid?.() ?? ''; if (n === 'current_gid') return process.getgid?.() ?? ''; if (n === 'current_user') return os.userInfo().username;
  return '';
}
function aggregate(n, arg, rows) {
  if (n === 'count') return rows.length;
  const vals = rows.map(r => Number(evalExpr(arg, r, rows))).filter(v => !Number.isNaN(v));
  if (!vals.length) return '';
  if (n === 'sum') return vals.reduce((a,b)=>a+b,0);
  if (n === 'min') return Math.min(...vals);
  if (n === 'max') return Math.max(...vals);
  if (n === 'avg') return vals.reduce((a,b)=>a+b,0) / vals.length;
}
function hasAggregate(node) {
  if (!node || typeof node !== 'object') return false;
  if (node.type === 'func' && ['count','sum','min','max','avg'].includes(String(node.name).toLowerCase())) return true;
  return Object.values(node).some(v => Array.isArray(v) ? v.some(hasAggregate) : hasAggregate(v));
}

function runQuery(q) {
  const query = parseQuery(q);
  let rows = [];
  for (const r of query.roots) rows.push(...walkRoot(r));
  if (query.where) rows = rows.filter(r => truth(evalExpr(query.where, r, rows)));
  if (query.group.length) {
    const groups = new Map();
    for (const r of rows) {
      const key = query.group.map(g => String(evalExpr(g, r, rows))).join('\x1f');
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(r);
    }
    rows = [...groups.values()].map(g => ({groupRows:g, proxy:g[0]}));
  }
  if (query.order.length) {
    rows.sort((a,b) => {
      for (const o of query.order) {
        const ra = a.proxy || a, rb = b.proxy || b;
        let av, bv;
        if (o.expr.type === 'literal' && Number.isInteger(o.expr.value) && query.columns[o.expr.value - 1]) {
          av = evalExpr(query.columns[o.expr.value - 1], ra, a.groupRows || rows);
          bv = evalExpr(query.columns[o.expr.value - 1], rb, b.groupRows || rows);
        } else { av = evalExpr(o.expr, ra, a.groupRows || rows); bv = evalExpr(o.expr, rb, b.groupRows || rows); }
        const c = cmp(av,bv); if (c) return o.dir === 'desc' ? -c : c;
      }
      return 0;
    });
  }
  const aggregateOnly = !query.group.length && query.columns.some(hasAggregate);
  if (aggregateOnly) rows = rows.length ? [{proxy:rows[0], groupRows:rows}] : [{proxy:null, groupRows:[]}];
  if (query.offset) rows = rows.slice(query.offset);
  if (query.limit != null) rows = rows.slice(0, query.limit);
  const table = rows.map(r => {
    const rec = r.proxy || r, scope = r.groupRows || rows;
    return query.columns.map(c => stringify(evalExpr(c, rec, scope)));
  });
  output(table, query);
}

function stringify(v) { return v == null ? '' : String(v); }
function label(expr) {
  if (expr.type === 'ident') return expr.name.charAt(0).toUpperCase() + expr.name.slice(1).toLowerCase();
  if (expr.type === 'func') return expr.name.toUpperCase();
  return 'Value';
}
function csvCell(s) { return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }
function output(table, query) {
  const fmt = query.format;
  if (fmt === 'json') {
    const names = query.columns.map(label);
    process.stdout.write(JSON.stringify(table.map(r => Object.fromEntries(r.map((v,i) => [names[i], v])))));
  } else if (fmt === 'csv') {
    process.stdout.write(table.map(r => r.map(csvCell).join(',')).join('\n') + (table.length ? '\n' : ''));
  } else if (fmt === 'list') {
    process.stdout.write(table.flat().join('\0') + (table.length ? '\0' : ''));
  } else if (fmt === 'lines') {
    process.stdout.write(table.flat().join('\n') + (table.length ? '\n' : ''));
  } else if (fmt === 'html') {
    const esc = s => s.replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
    process.stdout.write('<table>\n' + table.map(r => '<tr>' + r.map(c => `<td>${esc(c)}</td>`).join('') + '</tr>').join('\n') + '\n</table>\n');
  } else {
    process.stdout.write(table.map(r => r.join('\t')).join('\n') + (table.length ? '\n' : ''));
  }
}

function interactive() {
  help();
  const rl = readline.createInterface({input:process.stdin, output:process.stdout, terminal:false});
  rl.on('line', line => {
    const s = line.trim();
    if (!s) return;
    if (['exit','quit'].includes(s.toLowerCase())) { rl.close(); return; }
    if (s.toLowerCase() === 'help') { help(); return; }
    if (s.toLowerCase() === 'pwd') { console.log(process.cwd()); return; }
    if (s.toLowerCase().startsWith('cd ')) { try { process.chdir(s.slice(3).trim()); } catch (e) { console.error(e.message); } return; }
    if (s.toLowerCase().startsWith('errors')) { const v = s.split(/\s+/)[1]; showErrors = v ? v.toLowerCase() !== 'off' : !showErrors; return; }
    try { runQuery(s); } catch (e) { console.error(e.message); }
  });
}

function main() {
  const args = process.argv.slice(2);
  const qparts = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (['--help','-h','--version','-V'].includes(a)) { help(); return; }
    if (['--nocolor','--no-color'].includes(a)) { noColor = true; continue; }
    if (a === '--no-errors') { showErrors = false; continue; }
    if (a === '--config') { i++; continue; }
    if (a === '--us-dates') continue;
    if (['--interactive','-i'].includes(a)) { interactive(); return; }
    qparts.push(a);
  }
  if (!qparts.length) { help(); return; }
  try { runQuery(qparts.join(' ')); } catch (e) { if (showErrors) console.error(e.message); }
}
main();
