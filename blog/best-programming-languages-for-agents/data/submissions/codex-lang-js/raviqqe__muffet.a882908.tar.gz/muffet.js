#!/usr/bin/env node
"use strict";

const http = require("http");
const https = require("https");
const { URL } = require("url");

const VERSION = "2.11.1";

function usage() {
  return `Usage:
  executable [options] <url>

Application Options:
      --accepted-status-codes=<codes>       Accepted HTTP response status codes
                                            (e.g. '200..300,403') (default:
                                            200..300)
  -b, --buffer-size=<size>                  HTTP response buffer size in bytes
                                            (default: 4096)
  -c, --max-connections=<count>             Maximum number of HTTP connections
                                            (default: 512)
      --max-connections-per-host=<count>    Maximum number of HTTP connections
                                            per host (default: 512)
      --max-response-body-size=<size>       Maximum response body size to read
                                            (default: 10000000)
  -e, --exclude=<pattern>...                Exclude URLs matched with given
                                            regular expressions
  -i, --include=<pattern>...                Include URLs matched with given
                                            regular expressions
      --follow-robots-txt                   Follow robots.txt when scraping
                                            pages
      --follow-sitemap-xml                  Scrape only pages listed in
                                            sitemap.xml (deprecated)
      --header=<header>...                  Custom headers
  -f, --ignore-fragments                    Ignore URL fragments
      --max-retries=<count>                 Maximum retry count for network
                                            errors (default: 0)
      --dns-resolver=<address>              Custom DNS resolver
      --format=[text|json|junit]            Output format (default: text)
      --json                                Output results in JSON (deprecated)
      --experimental-verbose-json           Include successful results in JSON
                                            (deprecated)
      --junit                               Output results as JUnit XML file
                                            (deprecated)
  -r, --max-redirections=<count>            Maximum number of redirections
                                            (default: 64)
      --rate-limit=<rate>                   Max requests per second
  -t, --timeout=<seconds>                   Timeout for HTTP requests in
                                            seconds (default: 10)
  -v, --verbose                             Show successful results too
      --proxy=<host>                        HTTP proxy host
      --skip-tls-verification               Skip TLS certificate verification
      --one-page-only                       Only check links found in the given
                                            URL
      --color=[auto|always|never]           Color output (default: auto)
  -h, --help                                Show this help
      --version                             Show version`;
}

function parseArgs(argv) {
  const opts = {
    accepted: "200..300",
    maxBody: 10000000,
    timeout: 10,
    maxRedirects: 64,
    format: "text",
    verbose: false,
    ignoreFragments: false,
    onePageOnly: false,
    headers: {},
    include: [],
    exclude: [],
    skipTls: false,
    followSitemap: false,
    followRobots: false,
  };
  const urls = [];
  const needsValue = new Set([
    "accepted-status-codes", "buffer-size", "max-connections",
    "max-connections-per-host", "max-response-body-size", "exclude",
    "include", "header", "max-retries", "dns-resolver", "format",
    "max-redirections", "rate-limit", "timeout", "proxy", "color",
  ]);
  const aliases = { b: "buffer-size", c: "max-connections", e: "exclude", i: "include", f: "ignore-fragments", r: "max-redirections", t: "timeout", v: "verbose", h: "help" };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === "--") {
      urls.push(...argv.slice(i + 1));
      break;
    } else if (a.startsWith("--")) {
      let name, val;
      const eq = a.indexOf("=");
      if (eq >= 0) {
        name = a.slice(2, eq);
        val = a.slice(eq + 1);
      } else {
        name = a.slice(2);
      }
      if (!knownLong(name)) throw new Error(`unknown flag \`${name}'`);
      if (needsValue.has(name) && val === undefined) {
        if (i + 1 >= argv.length) throw new Error(`expected argument for flag \`${name}'`);
        val = argv[++i];
      }
      applyOpt(opts, name, val === undefined ? true : val);
    } else if (a.startsWith("-") && a.length > 1) {
      const letters = a.slice(1);
      for (let j = 0; j < letters.length; j++) {
        const ch = letters[j];
        const name = aliases[ch];
        if (!name) throw new Error(`unknown flag \`${ch}'`);
        let val = true;
        if (needsValue.has(name)) {
          if (j + 1 < letters.length) {
            val = letters.slice(j + 1);
            j = letters.length;
          } else {
            if (i + 1 >= argv.length) throw new Error(`expected argument for flag \`${ch}'`);
            val = argv[++i];
          }
        }
        applyOpt(opts, name, val);
      }
    } else {
      urls.push(a);
    }
  }
  if (opts.help) return { opts, urls };
  if (opts.version) return { opts, urls };
  if (urls.length !== 1) throw new Error("invalid number of arguments");
  opts.root = normalizeInputUrl(urls[0]);
  opts.acceptedPred = parseAccepted(opts.accepted);
  opts.includeRe = opts.include.map((p) => new RegExp(p));
  opts.excludeRe = opts.exclude.map((p) => new RegExp(p));
  return { opts, urls };
}

function knownLong(name) {
  return [
    "accepted-status-codes", "buffer-size", "max-connections",
    "max-connections-per-host", "max-response-body-size", "exclude",
    "include", "follow-robots-txt", "follow-sitemap-xml", "header",
    "ignore-fragments", "max-retries", "dns-resolver", "format", "json",
    "experimental-verbose-json", "junit", "max-redirections", "rate-limit",
    "timeout", "verbose", "proxy", "skip-tls-verification", "one-page-only",
    "color", "help", "version",
  ].includes(name);
}

function applyOpt(opts, name, value) {
  switch (name) {
    case "help": opts.help = true; break;
    case "version": opts.version = true; break;
    case "accepted-status-codes": opts.accepted = String(value); break;
    case "max-response-body-size": opts.maxBody = parseInt(value, 10); break;
    case "timeout": opts.timeout = parseFloat(value); break;
    case "max-redirections": opts.maxRedirects = parseInt(value, 10); break;
    case "format": opts.format = String(value); break;
    case "json": opts.format = "json"; break;
    case "junit": opts.format = "junit"; break;
    case "verbose": opts.verbose = true; break;
    case "ignore-fragments": opts.ignoreFragments = true; break;
    case "one-page-only": opts.onePageOnly = true; break;
    case "exclude": opts.exclude.push(String(value)); break;
    case "include": opts.include.push(String(value)); break;
    case "header": {
      const s = String(value);
      const k = s.indexOf(":");
      if (k >= 0) opts.headers[s.slice(0, k).trim()] = s.slice(k + 1).trim();
      break;
    }
    case "skip-tls-verification": opts.skipTls = true; break;
    case "follow-sitemap-xml": opts.followSitemap = true; break;
    case "follow-robots-txt": opts.followRobots = true; break;
    default: break;
  }
}

function normalizeInputUrl(s) {
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = "http://" + s;
  return new URL(s).toString();
}

function parseAccepted(spec) {
  const parts = String(spec).split(",").filter(Boolean);
  const ranges = parts.map((p) => {
    const m = p.match(/^(\d+)\.\.(\d+)$/);
    if (m) return [parseInt(m[1], 10), parseInt(m[2], 10) - 1];
    const n = parseInt(p, 10);
    return [n, n];
  });
  return (code) => ranges.some(([a, b]) => code >= a && code <= b);
}

function canonicalUrl(u, ignoreFragments) {
  const x = new URL(u);
  if (ignoreFragments) x.hash = "";
  return x.toString();
}

function sameOrigin(a, b) {
  const x = new URL(a), y = new URL(b);
  return x.protocol === y.protocol && x.hostname === y.hostname && portOf(x) === portOf(y);
}

function portOf(u) {
  if (u.port) return u.port;
  return u.protocol === "https:" ? "443" : "80";
}

function shouldConsider(url, opts) {
  if (!/^https?:\/\//i.test(url)) return false;
  if (opts.includeRe.length && !opts.includeRe.some((r) => r.test(url))) return false;
  if (opts.excludeRe.some((r) => r.test(url))) return false;
  return true;
}

function fetchUrl(url, opts, redirectsLeft) {
  return new Promise((resolve) => {
    const u = new URL(url);
    const lib = u.protocol === "https:" ? https : http;
    const reqOpts = {
      method: "GET",
      headers: Object.assign({ "User-Agent": "muffet/2.11.1" }, opts.headers),
      timeout: Math.max(1, opts.timeout * 1000),
      rejectUnauthorized: !opts.skipTls,
    };
    const req = lib.request(u, reqOpts, (res) => {
      const code = res.statusCode || 0;
      if ([301, 302, 303, 307, 308].includes(code) && res.headers.location && redirectsLeft > 0) {
        res.resume();
        const next = new URL(res.headers.location, url).toString();
        fetchUrl(next, opts, redirectsLeft - 1).then(resolve);
        return;
      }
      const chunks = [];
      let size = 0;
      res.on("data", (chunk) => {
        size += chunk.length;
        if (size <= opts.maxBody) chunks.push(chunk);
      });
      res.on("end", () => resolve({
        url,
        status: code,
        headers: res.headers,
        body: Buffer.concat(chunks).toString("utf8"),
      }));
    });
    req.on("timeout", () => {
      req.destroy(new Error("timeout"));
    });
    req.on("error", (err) => resolve({ url, error: networkError(err, u) }));
    req.end();
  });
}

function networkError(err, u) {
  if (err && err.message === "timeout") return "request timeout";
  if (err && err.code === "ENOTFOUND") return `lookup ${u.hostname}: no such host`;
  if (err && err.code === "ECONNREFUSED") return `error when dialing ${u.host}: dial tcp ${u.host}: connect: connection refused`;
  if (err && err.code === "ECONNRESET") return "connection reset by peer";
  return err && err.message ? err.message : String(err);
}

function isHtml(headers) {
  const ct = String(headers["content-type"] || "").toLowerCase();
  return ct.includes("text/html") || ct.includes("application/xhtml+xml");
}

function extractLinks(html, base) {
  const out = [];
  const attrRe = /\b(?:href|src|action|poster|cite|data|formaction)\s*=\s*("([^"]*)"|'([^']*)'|([^\s"'`=<>]+))/gi;
  let m;
  while ((m = attrRe.exec(html))) {
    const raw = (m[2] ?? m[3] ?? m[4] ?? "").trim();
    addRaw(out, raw, base);
  }
  const srcsetRe = /\bsrcset\s*=\s*("([^"]*)"|'([^']*)'|([^\s"'`=<>]+))/gi;
  while ((m = srcsetRe.exec(html))) {
    const raw = (m[2] ?? m[3] ?? m[4] ?? "").trim();
    for (const part of raw.split(",")) addRaw(out, part.trim().split(/\s+/)[0], base);
  }
  return [...new Set(out)];
}

function addRaw(out, raw, base) {
  if (!raw || raw.startsWith("javascript:") || raw.startsWith("mailto:") || raw.startsWith("tel:")) return;
  try {
    out.push(new URL(htmlDecode(raw), base).toString());
  } catch (_) {
  }
}

function htmlDecode(s) {
  return s.replace(/&amp;/g, "&").replace(/&quot;/g, "\"").replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
}

function idsIn(html) {
  const ids = new Set();
  const re = /\b(?:id|name)\s*=\s*("([^"]*)"|'([^']*)'|([^\s"'`=<>]+))/gi;
  let m;
  while ((m = re.exec(html))) ids.add(htmlDecode(m[2] ?? m[3] ?? m[4] ?? ""));
  return ids;
}

async function crawl(opts) {
  const root = canonicalUrl(opts.root, opts.ignoreFragments);
  const rootResp = await fetchUrl(root, opts, opts.maxRedirects);
  if (rootResp.error) throw new Error(`failed to fetch root page: ${rootResp.error}`);
  if (!opts.acceptedPred(rootResp.status)) throw new Error(`failed to fetch root page: ${rootResp.status}`);
  if (!isHtml(rootResp.headers)) throw new Error("root page has invalid content type");

  const pages = [];
  const pageMap = new Map();
  const checked = new Map();
  const idCache = new Map();
  const disallowed = opts.followRobots ? await readRobots(root, opts) : [];
  const seeds = opts.followSitemap ? await readSitemap(root, opts) : [root];
  const queue = [];
  const queued = new Set();
  for (const seed of seeds.length ? seeds : [root]) {
    const clean = canonicalUrl(seed, opts.ignoreFragments);
    if (!sameOrigin(root, clean) || isDisallowed(clean, disallowed)) continue;
    queued.add(clean);
    queue.push({ url: clean, resp: clean === root ? rootResp : undefined });
  }

  while (queue.length) {
    const item = queue.shift();
    const pageUrl = item.url;
    const resp = item.resp || await fetchUrl(pageUrl, opts, opts.maxRedirects);
    if (resp.error || !opts.acceptedPred(resp.status) || !isHtml(resp.headers)) continue;
    const page = { url: pageUrl, links: [] };
    pages.push(page);
    const pageIds = idsIn(resp.body);
    pageMap.set(pageUrl, { page, ids: pageIds });
    idCache.set(pageUrl, pageIds);
    const links = extractLinks(resp.body, pageUrl);
    for (const link0 of links) {
      let link = canonicalUrl(link0, opts.ignoreFragments);
      if (!shouldConsider(link, opts)) continue;
      if (isDisallowed(link, disallowed)) continue;
      const target = new URL(link);
      const targetNoHash = new URL(link);
      targetNoHash.hash = "";
      const targetBase = targetNoHash.toString();
      if (!opts.ignoreFragments && target.hash) {
        const id = decodeURIComponent(target.hash.slice(1));
        let ids = idCache.get(targetBase);
        let baseResult = checked.get(targetBase);
        if (!ids) {
          if (targetBase === pageUrl) {
            ids = pageIds;
          } else {
            const r = await fetchUrl(targetBase, opts, opts.maxRedirects);
            if (r.error) baseResult = { url: targetBase, error: r.error };
            else if (!opts.acceptedPred(r.status)) baseResult = { url: targetBase, error: String(r.status) };
            else baseResult = { url: targetBase, status: r.status, headers: r.headers, body: r.body };
            checked.set(targetBase, baseResult);
            ids = baseResult.status && isHtml(baseResult.headers || {}) ? idsIn(baseResult.body || "") : new Set();
          }
          idCache.set(targetBase, ids);
        }
        if (baseResult && baseResult.error) {
          page.links.push({ url: link, error: baseResult.error });
        } else if (!ids.has(id)) {
          page.links.push({ url: link, error: `id #${id} not found` });
        } else {
          page.links.push({ url: link, status: 200 });
        }
        if (!opts.onePageOnly && sameOrigin(root, targetBase) && baseResult && baseResult.status && isHtml(baseResult.headers || {}) && !queued.has(targetBase)) {
          queued.add(targetBase);
          queue.push({ url: targetBase, resp: baseResult });
        }
        continue;
      }
      let result = checked.get(link);
      if (!result) {
        const r = await fetchUrl(link, opts, opts.maxRedirects);
        if (r.error) result = { url: link, error: r.error };
        else if (!opts.acceptedPred(r.status)) result = { url: link, error: String(r.status) };
        else result = { url: link, status: r.status, headers: r.headers, body: r.body };
        checked.set(link, result);
      }
      page.links.push(result.error ? { url: link, error: result.error } : { url: link, status: result.status });
      if (!opts.onePageOnly && sameOrigin(root, link) && result.status && isHtml(result.headers || {}) && !queued.has(link)) {
        queued.add(link);
        queue.push({ url: link, resp: result });
      }
    }
  }
  return pages;
}

async function readSitemap(root, opts) {
  try {
    const u = new URL(root);
    const sitemap = new URL("/sitemap.xml", u).toString();
    const r = await fetchUrl(sitemap, opts, opts.maxRedirects);
    if (r.error || !opts.acceptedPred(r.status)) return [];
    const locs = [];
    const re = /<loc>\s*([^<]+?)\s*<\/loc>/gi;
    let m;
    while ((m = re.exec(r.body || ""))) {
      try {
        locs.push(canonicalUrl(htmlDecode(m[1].trim()), opts.ignoreFragments));
      } catch (_) {
      }
    }
    return locs;
  } catch (_) {
    return [];
  }
}

async function readRobots(root, opts) {
  try {
    const robots = new URL("/robots.txt", root).toString();
    const r = await fetchUrl(robots, opts, opts.maxRedirects);
    if (r.error || !opts.acceptedPred(r.status)) return [];
    const rules = [];
    let applies = false;
    for (const line0 of String(r.body || "").split(/\r?\n/)) {
      const line = line0.replace(/#.*/, "").trim();
      if (!line) continue;
      const k = line.indexOf(":");
      if (k < 0) continue;
      const name = line.slice(0, k).trim().toLowerCase();
      const value = line.slice(k + 1).trim();
      if (name === "user-agent") applies = value === "*" || /muffet/i.test(value);
      if (applies && name === "disallow" && value) rules.push(value);
    }
    return rules;
  } catch (_) {
    return [];
  }
}

function isDisallowed(url, rules) {
  if (!rules.length) return false;
  const p = new URL(url).pathname;
  return rules.some((r) => p.startsWith(r));
}

function hasFailures(pages) {
  return pages.some((p) => p.links.some((l) => l.error));
}

function outputText(pages, opts) {
  const lines = [];
  for (const p of pages) {
    const links = opts.verbose ? p.links : p.links.filter((l) => l.error);
    if (!links.length && !opts.verbose) continue;
    lines.push(p.url);
    for (const l of links) {
      lines.push(`\t${l.error || l.status}\t${l.url}`);
    }
  }
  if (lines.length) process.stdout.write(lines.join("\n") + "\n");
}

function outputJson(pages, opts) {
  const arr = pages.map((p) => ({
    url: p.url,
    links: (opts.verbose ? p.links : p.links.filter((l) => l.error)).map((l) => l.error ? { url: l.url, error: l.error } : { url: l.url, status: l.status }),
  })).filter((p) => opts.verbose || p.links.length);
  process.stdout.write(JSON.stringify(arr) + "\n");
}

function escXml(s) {
  return String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function outputJunit(pages) {
  const lines = ['<?xml version="1.0" encoding="UTF-8"?>', "<testsuites>"];
  for (const p of pages) {
    const failures = p.links.filter((l) => l.error).length;
    if (!p.links.length) {
      lines.push(`  <testsuite name="${escXml(p.url)}" tests="0" failures="0" skipped="0"></testsuite>`);
      continue;
    }
    lines.push(`  <testsuite name="${escXml(p.url)}" tests="${p.links.length}" failures="${failures}" skipped="0">`);
    for (const l of p.links) {
      lines.push(`    <testcase name="${escXml(l.url)}" classname="${escXml(p.url)}">` + (l.error ? "" : "</testcase>"));
      if (l.error) {
        lines.push(`      <failure message="${escXml(l.error)}"></failure>`);
        lines.push("    </testcase>");
      }
    }
    lines.push("  </testsuite>");
  }
  lines.push("</testsuites>");
  process.stdout.write(lines.join("\n") + "\n");
}

(async function main() {
  let parsed;
  try {
    parsed = parseArgs(process.argv.slice(2));
  } catch (e) {
    console.error(e.message);
    process.exit(1);
  }
  const { opts } = parsed;
  if (opts.help) {
    console.log(usage());
    return;
  }
  if (opts.version) {
    console.log(VERSION);
    return;
  }
  if (!["text", "json", "junit"].includes(opts.format)) {
    console.error(`invalid choice \`${opts.format}' (choose from "text", "json", "junit")`);
    process.exit(1);
  }
  try {
    const pages = await crawl(opts);
    if (opts.format === "json") outputJson(pages, opts);
    else if (opts.format === "junit") outputJunit(pages);
    else outputText(pages, opts);
    process.exit(hasFailures(pages) ? 1 : 0);
  } catch (e) {
    console.error(e.message);
    process.exit(1);
  }
})();
