#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const VERSION = 'rhit 2.0.4';
const DEFAULT_FIELDS = ['date','status','ref','path'];
const ALL_FIELDS = ['date','time','method','status','ip','ref','path'];
const MONTHS = {Jan:'01',Feb:'02',Mar:'03',Apr:'04',May:'05',Jun:'06',Jul:'07',Aug:'08',Sep:'09',Oct:'10',Nov:'11',Dec:'12'};
const FIELD_ALIASES = {d:'date',date:'date',t:'time',time:'time',m:'method',method:'method',s:'status',status:'status',i:'ip',ip:'ip',r:'ref',ref:'ref',referer:'ref',referrer:'ref',p:'path',path:'path',a:'all',all:'all'};

function usage(color=true){
  return `${VERSION}\n\nRhit analyzes your nginx logs.\n\nUsage: rhit [options] [FILES]\n\nOptions:\n  --help                 Print help information\n  --version              Print the version\n  --color <color>        Whether to have styles and colors [auto, yes, no]\n  -k, --key <KEY>        Key used in sorting and histogram, hits or bytes\n  -l, --length <LENGTH>  Detail level, from 0 to 6\n  -f, --fields <FIELDS>  Comma separated list of hit fields to display\n  -c, --changes          Add tables with changes\n  -d, --date <DATE>      Filter dates\n  -i, --ip <IP>          Ip address filter\n  -m, --method <METHOD>  HTTP method filter\n  -p, --path <PATH>      Pattern for path filtering\n  -r, --referer <REF>    Referer filter\n  -s, --status <STATUS>  Status filter\n  -t, --time <TIME>      Filter time of day\n  -a, --all              Show all paths, including resources\n      --no-name-check    Try to open all files\n  -o, --output <OUTPUT>  tables, raw, csv, or json\n      --silent-load      Don't print anything during load\n`;
}

function die(msg, code=1){ console.error(msg); process.exit(code); }
function cliError(msg){ console.error(msg); process.exit(2); }

function parseArgs(argv){
  const opt = {color:'auto', key:'hits', length:1, fields:null, changes:false, all:false, noNameCheck:false, output:'tables', silent:false, files:[], filters:{}};
  const need = new Set(['--color','-k','--key','-l','--length','-f','--fields','-d','--date','-i','--ip','-m','--method','-p','--path','-r','--referer','--referrer','-s','--status','-t','--time','-o','--output']);
  for(let i=0;i<argv.length;i++){
    let a=argv[i];
    if(a==='--'){ opt.files.push(...argv.slice(i+1)); break; }
    let val=null;
    if(a.startsWith('--') && a.includes('=')){ const parts=a.split('='); a=parts.shift(); val=parts.join('='); }
    const take=()=>{ if(val!==null) return val; if(i+1>=argv.length) cliError(`error: a value is required for '${a}'`); return argv[++i]; };
    if(a==='--help'){ process.stdout.write(usage()); process.exit(0); }
    else if(a==='--version'){ console.log(VERSION); process.exit(0); }
    else if(a==='--color') opt.color=take();
    else if(a==='-k'||a==='--key') opt.key=normKey(take());
    else if(a==='-l'||a==='--length') opt.length=parseInt(take(),10)||0;
    else if(a==='-f'||a==='--fields') opt.fields=take();
    else if(a==='-c'||a==='--changes') opt.changes=true;
    else if(a==='-a'||a==='--all') opt.all=true;
    else if(a==='--no-name-check') opt.noNameCheck=true;
    else if(a==='--silent-load') opt.silent=true;
    else if(a==='-o'||a==='--output') opt.output=normOutput(take());
    else if(a==='-d'||a==='--date') opt.filters.date=take();
    else if(a==='-i'||a==='--ip') opt.filters.ip=take();
    else if(a==='-m'||a==='--method') opt.filters.method=take();
    else if(a==='-p'||a==='--path') opt.filters.path=take();
    else if(a==='-r'||a==='--referer'||a==='--referrer') opt.filters.ref=take();
    else if(a==='-s'||a==='--status') opt.filters.status=take();
    else if(a==='-t'||a==='--time') opt.filters.time=take();
    else if(a.startsWith('-')) cliError(`error: unexpected argument '${a}' found\n\nUsage: executable --color <color> --silent-load [FILES]...`);
    else opt.files.push(a);
  }
  if(!['auto','yes','no'].includes(opt.color)) cliError(`error: invalid value '${opt.color}' for '--color <color>'`);
  if(opt.length<0) opt.length=0; if(opt.length>6) opt.length=6;
  return opt;
}
function normOutput(v){ const m={t:'tables',table:'tables',tables:'tables',r:'raw',raw:'raw',c:'csv',csv:'csv',j:'json',json:'json'}; if(!m[v]) cliError(`error: invalid value '${v}' for '--output <OUTPUT>': unrecognized output "${v}"`); return m[v]; }
function normKey(v){ const m={h:'hits',hits:'hits',b:'bytes',bytes:'bytes'}; if(!m[v]) cliError(`error: invalid value '${v}' for '--key <KEY>': unrecognized key "${v}"`); return m[v]; }

function discover(inputs, noNameCheck){
  if(inputs.length===0) inputs = ['/var/log/nginx/access.log','/var/log/nginx/access.log.1','/var/log/nginx'];
  const out=[];
  for(const p of inputs){
    if(!fs.existsSync(p)) { if(inputs.length===1) die(`Error: PathNotFound("${p}")`); else continue; }
    const st=fs.statSync(p);
    if(st.isDirectory()) walk(p,out,noNameCheck); else if(okName(p,noNameCheck)) out.push(p);
  }
  out.sort();
  return out;
}
function walk(dir,out,noNameCheck){
  for(const ent of fs.readdirSync(dir).sort()){
    const p=path.join(dir,ent); let st; try{st=fs.statSync(p)}catch{continue}
    if(st.isDirectory()) walk(p,out,noNameCheck); else if(okName(p,noNameCheck)) out.push(p);
  }
}
function okName(p,no){ if(no) return true; const b=path.basename(p); return /access.*\.log(\.\d+)?(\.gz)?$/.test(b)||/\.log(\.gz)?$/.test(b)||/access\.log/.test(b); }

function parseLine(line){
  const re=/^(\S+)\s+\S+\s+\S+\s+\[(\d{1,2})\/([A-Za-z]{3})\/(\d{4}):(\d\d):(\d\d):(\d\d)\s+([^\]]+)\]\s+"([^"]*)"\s+(\d{3})\s+(\S+)\s+"([^"]*)"(?:\s+"([^"]*)")?.*$/;
  const m=line.match(re); if(!m) return null;
  const req=m[9]; let method='none', reqPath=req;
  const rm=req.match(/^(\S+)\s+(\S+)(?:\s+HTTP\/[^\s]+)?$/);
  if(rm){ method=rm[1]; reqPath=rm[2]; }
  const mon=MONTHS[m[3]]||'01';
  const bytes=m[11]==='-'?0:parseInt(m[11],10)||0;
  return {raw:line, date:`${m[4]}/${mon}/${pad(m[2])}`, time:`${m[5]}:${m[6]}:${m[7]}`, remote_addr:m[1], ip:m[1], method, path:reqPath, status:m[10], bytes_sent:bytes, bytes, referer:m[12], ref:m[12]};
}
function pad(s){ return String(s).padStart(2,'0'); }
function readLogs(files){
  const hits=[];
  for(const f of files){
    let buf=fs.readFileSync(f); if(f.endsWith('.gz')) buf=zlib.gunzipSync(buf);
    const text=buf.toString('utf8');
    for(const line of text.split(/\r?\n/)){ if(!line) continue; const h=parseLine(line); if(h) hits.push(h); }
  }
  hits.sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)||a.raw.localeCompare(b.raw));
  return hits;
}

function makeRegexFilter(expr){
  if(expr==null) return ()=>true;
  expr=String(expr);
  // comma separated terms are AND, except positive status handled elsewhere
  const terms = splitTop(expr, ',').filter(Boolean).map(s=>s.trim());
  return value => terms.every(t=>evalPatternExpr(t, String(value)));
}
function splitTop(s, sep){ let a=[],cur='',depth=0,esc=false; for(const ch of s){ if(esc){cur+=ch;esc=false;continue} if(ch==='\\'){cur+=ch;esc=true;continue} if(ch==='(') depth++; else if(ch===')'&&depth>0) depth--; if(ch===sep&&depth===0){a.push(cur);cur=''} else cur+=ch; } a.push(cur); return a; }
function evalPatternExpr(expr, value){
  expr=expr.trim(); if(!expr) return true;
  if(expr.startsWith('!') && !expr.startsWith('!(')){ return !testRegex(expr.slice(1).trim(), value); }
  // simple support for documented boolean expressions
  const or=splitTop(expr,'|'); if(or.length>1) return or.some(x=>evalPatternExpr(x,value));
  const and=splitTop(expr,'&'); if(and.length>1) return and.every(x=>evalPatternExpr(x,value));
  if(expr.startsWith('!')) return !evalPatternExpr(expr.slice(1), value);
  if(expr.startsWith('(')&&expr.endsWith(')')) return evalPatternExpr(expr.slice(1,-1), value);
  return testRegex(expr, value);
}
function testRegex(pat, value){ try{ return new RegExp(pat).test(value); }catch{ return value.includes(pat); } }

function statusFilter(expr){
  if(!expr) return ()=>true;
  const terms=expr.split(',').map(s=>s.trim()).filter(Boolean);
  return h=>{
    const s=parseInt(h.status,10); let hasPos=terms.some(t=>!t.startsWith('!')); let ok=!hasPos;
    for(let t of terms){ const neg=t.startsWith('!'); if(neg)t=t.slice(1); const match=statusTerm(t,s,h.status); if(neg&&match)return false; if(!neg&&match)ok=true; }
    return ok;
  };
}
function statusTerm(t,n,s){ if(/^\dxx$/i.test(t)) return Math.floor(n/100)===parseInt(t[0]); const m=t.match(/^(\d+)-(\d+)$/); if(m)return n>=+m[1]&&n<=+m[2]; return s===t; }
function methodFilter(expr){ if(!expr) return ()=>true; let neg=expr.startsWith('!'); if(neg)expr=expr.slice(1); return h=> neg ? h.method!==expr : h.method===expr; }
function dateNum(h){ return +(h.date.replace(/\//g,'')+h.time.replace(/:/g,'')); }
function parseDateBound(s,end=false){
  const [d,t=''] = s.split(/[T ]/); const parts=d.split('/').filter(Boolean); let y=parts[0]||'0000', mo=parts[1]||(end?'12':'01'), da=parts[2]||(end?'31':'01');
  if(parts.length===1 && parts[0].length<=2){ y='0000'; mo=parts[0]; da=end?'31':'01'; }
  if(parts.length===2 && parts[0].length<=2){ y='0000'; mo=parts[0]; da=parts[1]; }
  const tp=t.split(':').filter(Boolean); const hh=tp[0]||(end?'23':'00'), mi=tp[1]||(end?'59':'00'), ss=tp[2]||(end?'59':'00');
  return +(String(y).padStart(4,'0')+pad(mo)+pad(da)+pad(hh)+pad(mi)+pad(ss));
}
function dateFilter(expr){
  if(!expr) return ()=>true; let neg=false; if(expr.startsWith('!')){neg=true;expr=expr.slice(1)}
  let fn;
  if(expr.startsWith('>')){ const b=parseDateBound(expr.slice(1), true); fn=h=>dateNum(h)>b; }
  else if(expr.startsWith('<')){ const b=parseDateBound(expr.slice(1), false); fn=h=>dateNum(h)<b; }
  else if(expr.includes('-')){ const [a,b]=expr.split('-',2); const lo=parseDateBound(a,false), hi=parseDateBound(b,true); fn=h=>dateNum(h)>=lo&&dateNum(h)<=hi; }
  else { const lo=parseDateBound(expr,false), hi=parseDateBound(expr,true); fn=h=>dateNum(h)>=lo&&dateNum(h)<=hi; }
  return h=>neg?!fn(h):fn(h);
}
function timeSec(t){ const p=t.split(':').map(Number); return (p[0]||0)*3600+(p[1]||0)*60+(p[2]||0); }
function parseTime(s,end=false){ const p=s.split(':').map(Number); return (p[0]||0)*3600+((p[1]??(end?59:0))*60)+(p[2]??(end?59:0)); }
function timeFilter(expr){
  if(!expr) return ()=>true; let fn;
  if(expr.startsWith('>')){ const b=parseTime(expr.slice(1),true); fn=h=>timeSec(h.time)>b; }
  else if(expr.startsWith('<')){ const b=parseTime(expr.slice(1),false); fn=h=>timeSec(h.time)<b; }
  else if(expr.includes('-')){ const [a,b]=expr.split('-',2); const lo=parseTime(a,false), hi=parseTime(b,true); fn=h=>timeSec(h.time)>=lo&&timeSec(h.time)<=hi; }
  else { const lo=parseTime(expr,false), hi=parseTime(expr,true); fn=h=>timeSec(h.time)>=lo&&timeSec(h.time)<=hi; }
  return fn;
}
function applyFilters(hits,opt){
  const fs=[dateFilter(opt.filters.date), timeFilter(opt.filters.time), makeRegexFilter(opt.filters.ip), methodFilter(opt.filters.method), makeRegexFilter(opt.filters.path), makeRegexFilter(opt.filters.ref), statusFilter(opt.filters.status)];
  return hits.filter(h=>fs[0](h)&&fs[1](h)&&fs[2](h.ip)&&fs[3](h)&&fs[4](h.path)&&fs[5](h.ref)&&fs[6](h));
}
function csvEscape(v){ v=String(v); return '"'+v.replace(/"/g,'""')+'"'; }
function outputRaw(hits){ console.log(hits.map(h=>h.raw).join('\n')+(hits.length?'':'')); }
function outputCsv(hits){ console.log('date,time,remote address,method,path,status,bytes sent,referer'); for(const h of hits) console.log(`${h.date},${h.time},${h.ip},${h.method},${csvEscape(h.path)},${h.status},${h.bytes},${csvEscape(h.ref)}`); }
function outputJson(hits){ const arr=hits.map(h=>({date:h.date,time:h.time,remote_addr:h.ip,method:h.method,path:h.path,status:h.status,bytes_sent:h.bytes,referer:h.ref})); console.log(JSON.stringify(arr,null,2)); }

function parseFields(spec){
  if(!spec) return DEFAULT_FIELDS.slice();
  let fields = /^[+-]/.test(spec) ? DEFAULT_FIELDS.slice() : [];
  const parts=spec.split(/(?=[+-])|[,]+|\+/).filter(Boolean);
  for(let raw of parts){
    let op='set'; if(raw[0]==='+'||raw[0]==='-'){op=raw[0]; raw=raw.slice(1);} raw=raw.trim(); if(!raw)continue;
    let f=FIELD_ALIASES[raw]||FIELD_ALIASES[raw.toLowerCase()]; if(!f) continue;
    const list=f==='all'?ALL_FIELDS: [f];
    if(op==='-' || raw.startsWith('-')) fields=fields.filter(x=>!list.includes(x)); else for(const x of list){ fields=fields.filter(y=>y!==x); fields.push(x); }
  }
  return fields.length?fields:DEFAULT_FIELDS.slice();
}
function isResource(p){ return /\.(css|js|png|jpe?g|gif|svg|ico|webp|woff2?|ttf|map|txt|xml|pdf|zip|gz|tar|tgz)$/i.test(p); }
function outputTables(hits,opt){
  const total=hits.length, bytes=hits.reduce((a,h)=>a+h.bytes,0); const dates=hits.map(h=>h.date).sort();
  if(total) console.log(`${total} hit${total===1?'':'s'} and ${bytes} from ${dates[0]} to ${dates[dates.length-1]}`); else console.log('0 hits');
  for(const f of parseFields(opt.fields)){
    if(f==='date') histDate(hits,opt); else if(f==='time') histTime(hits,opt); else tableField(hits,f,opt);
  }
}
function statMap(hits, keyFn){ const m=new Map(); for(const h of hits){ const k=keyFn(h); if(k==='-'&&false)continue; const o=m.get(k)||{value:k,hits:0,bytes:0}; o.hits++; o.bytes+=h.bytes; m.set(k,o);} return [...m.values()]; }
function sortStats(arr,opt){ const key=opt.key==='bytes'?'bytes':'hits'; arr.sort((a,b)=>b[key]-a[key]||String(a.value).localeCompare(String(b.value))); return arr; }
function limitFor(l){ return [5,10,20,50,100,200,100000][l]||10; }
function tableField(hits,f,opt){
  let label={status:'HTTP status codes',ip:'remote IP addresses',ref:'referrers',path:'paths',method:'methods'}[f]||f;
  let col={status:'status',ip:'IP address',ref:'referrer',path:'path',method:'method'}[f]||f;
  let rows=statMap(hits,h=>f==='ip'?h.ip:f==='ref'?h.ref:f==='path'?h.path:h[f]);
  if(f==='ref') rows=rows.filter(r=>r.value!=='-');
  if(f==='path'&&!opt.all) rows=rows.filter(r=>!isResource(r.value));
  rows=sortStats(rows,opt).slice(0,limitFor(opt.length));
  const extra=f==='path'&&!opt.all?' (excluding resources like images, css, etc.)':'';
  console.log(`${rows.length} ${label}${extra}. `);
  simpleTable(['#',col,'hits','%','bytes'], rows.map((r,i)=>[String(i+1),String(r.value),String(r.hits), pct(r.hits,hits.length), String(r.bytes)]));
}
function histDate(hits,opt){ const rows=sortStats(statMap(hits,h=>h.date),{key:'hits'}); simpleTable(['date','hits','bytes'], rows.map(r=>[r.value,String(r.hits),String(r.bytes)])); }
function histTime(hits,opt){ const arr=[]; for(let i=0;i<24;i++)arr.push({value:String(i),hits:0,bytes:0}); for(const h of hits){ const i=parseInt(h.time.slice(0,2),10); arr[i].hits++; arr[i].bytes+=h.bytes; } simpleTable(['hour','hits','bytes'], arr.map(r=>[r.value,String(r.hits),String(r.bytes)])); }
function pct(n,d){ return d?((n*100/d).toFixed(1)+'%'):'0.0%'; }
function simpleTable(headers, rows){
  const widths=headers.map((h,i)=>Math.max(String(h).length,...rows.map(r=>String(r[i]??'').length)));
  const border=(l,m,r)=>l+widths.map(w=>'─'.repeat(w+2)).join(m)+r;
  console.log(border('┌','┬','┐')); console.log('│'+headers.map((h,i)=>' '+String(h).padEnd(widths[i])+' ').join('│')+'│'); console.log(border('├','┼','┤'));
  for(const row of rows) console.log('│'+row.map((c,i)=>' '+String(c).padEnd(widths[i])+' ').join('│')+'│');
  console.log(border('└','┴','┘'));
}

function main(){
  const opt=parseArgs(process.argv.slice(2));
  const files=discover(opt.files,opt.noNameCheck);
  const hits=applyFilters(readLogs(files),opt);
  if(opt.output==='raw') outputRaw(hits); else if(opt.output==='csv') outputCsv(hits); else if(opt.output==='json') outputJson(hits); else outputTables(hits,opt);
}
main();
