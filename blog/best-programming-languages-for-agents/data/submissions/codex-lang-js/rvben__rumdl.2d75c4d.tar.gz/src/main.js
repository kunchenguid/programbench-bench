#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "0.1.13";
const RULES = [
["MD001","heading-increment","heading","Heading levels should only increment by one level at a time",false],
["MD003","heading-style","heading","Heading style",true],
["MD004","ul-style","list","Use consistent style for unordered list markers",true],
["MD005","list-indent","list","List indentation should be consistent",true],
["MD007","ul-indent","list","Unordered list indentation",true],
["MD009","no-trailing-spaces","whitespace","Trailing spaces should be removed",true],
["MD010","no-hard-tabs","whitespace","No tabs",true],
["MD011","no-reversed-links","link","Reversed link syntax",true],
["MD012","no-multiple-blanks","whitespace","Multiple consecutive blank lines",true],
["MD013","line-length","whitespace","Line length should not be excessive",true],
["MD014","commands-show-output","code-block","Commands in code blocks should show output",false],
["MD018","no-missing-space-atx","heading","No space after hash in heading",true],
["MD019","no-multiple-space-atx","heading","Multiple spaces after hash in heading",true],
["MD020","no-missing-space-closed-atx","heading","No space inside hashes on closed heading",true],
["MD021","no-multiple-space-closed-atx","heading","Multiple spaces inside hashes on closed heading",true],
["MD022","blanks-around-headings","heading","Headings should be surrounded by blank lines",true],
["MD023","heading-start-left","heading","Headings must start at the beginning of the line",true],
["MD024","no-duplicate-heading","heading","Multiple headings with the same content",false],
["MD025","single-title","heading","Multiple top-level headings in the same document",true],
["MD026","no-trailing-punctuation","heading","Trailing punctuation in heading",true],
["MD027","no-multiple-space-blockquote","blockquote","Multiple spaces after quote marker (>)",true],
["MD028","no-blanks-blockquote","blockquote","Blank line inside blockquote",false],
["MD029","ol-prefix","list","Ordered list marker value",true],
["MD030","list-marker-space","list","Spaces after list markers should be consistent",true],
["MD031","blanks-around-fences","code-block","Fenced code blocks should be surrounded by blank lines",true],
["MD032","blanks-around-lists","list","Lists should be surrounded by blank lines",true],
["MD033","no-inline-html","html","Inline HTML is not allowed",false],
["MD034","no-bare-urls","link","No bare URLs - wrap URLs in angle brackets",true],
["MD035","hr-style","other","Horizontal rule style",true],
["MD036","no-emphasis-as-heading","emphasis","Emphasis should not be used instead of a heading",true],
["MD037","no-space-in-emphasis","other","Spaces inside emphasis markers",true],
["MD038","no-space-in-code","other","Spaces inside code span elements",true],
["MD039","no-space-in-links","other","Spaces inside link text",true],
["MD040","fenced-code-language","code-block","Code blocks should have a language specified",false],
["MD041","first-line-heading","heading","First line in file should be a top level heading",false],
["MD042","no-empty-links","link","No empty links",false],
["MD043","required-headings","heading","Required heading structure",false],
["MD044","proper-names","other","Proper names should have the correct capitalization",true],
["MD045","no-alt-text","link","Images should have alternate text (alt text)",false],
["MD046","code-block-style","code-block","Code blocks should use a consistent style",true],
["MD047","single-trailing-newline","whitespace","Files should end with a single newline character",true],
["MD048","code-fence-style","code-block","Code fence style should be consistent",true],
["MD049","emphasis-style","other","Emphasis style should be consistent",true],
["MD050","strong-style","other","Strong emphasis style should be consistent",true],
["MD051","link-fragments","link","Link fragments should reference valid headings",false],
["MD052","reference-links-images","link","Reference links and images should use a reference that exists",false],
["MD053","link-image-reference-definitions","link","Link and image reference definitions should be needed",true],
["MD054","link-image-style","link","Link and image style should be consistent",false],
["MD055","table-pipe-style","other","Table pipe style should be consistent",true],
["MD056","table-column-count","other","Table column count should be consistent",false],
["MD057","existing-relative-links","link","Relative links should point to existing files",false],
["MD058","blanks-around-tables","other","Tables should be surrounded by blank lines",true],
["MD059","descriptive-link-text","link","Link text should be descriptive",false],
["MD060","table-column-alignment","other","Table columns should be consistently aligned",true],
["MD061","forbidden-terms","other","Forbidden terms",false],
["MD062","no-whitespace-in-link-destination","link","Link destination should not have leading or trailing whitespace",true],
["MD063","heading-capitalization","heading","Heading capitalization",true],
["MD064","no-multiple-spaces","whitespace","Multiple consecutive spaces",true],
["MD065","blanks-around-hrs","other","Horizontal rules should be surrounded by blank lines",true],
["MD066","footnote-validation","other","Footnote validation",false],
["MD067","footnote-order","other","Footnote definitions should appear in order of first reference",true],
["MD068","no-empty-footnotes","other","Footnote definitions should not be empty",false],
["MD069","no-duplicate-list-markers","list","Duplicate list markers",true],
["MD070","nested-code-fence","code-block","Nested code fence collision - use longer fence to avoid premature closure",false],
["MD071","blanks-after-frontmatter","front-matter","Blank line after frontmatter",true],
["MD072","frontmatter-key-sort","other","Frontmatter keys should be sorted alphabetically",true],
["MD073","toc","other","Table of Contents should match document headings",false],
];
const RULE = Object.fromEntries(RULES.map(r => [r[0], {id:r[0], name:r[1], category:r[2], desc:r[3], fixable:r[4]}]));
const ERROR_RULES = new Set(["MD001","MD011","MD024","MD025","MD042","MD045","MD051","MD057","MD066","MD068"]);
const OPT_IN = new Set(["MD060","MD063","MD072","MD073"]);

function parseArgs(argv) {
  const opts = {_:[]};
  for (let i=0;i<argv.length;i++) {
    let a = argv[i];
    if (a === "--") { opts._.push(...argv.slice(i+1)); break; }
    if (!a.startsWith("-") || a === "-") { opts._.push(a); continue; }
    let key = a.replace(/^-+/,"");
    let val = true;
    const eq = key.indexOf("=");
    if (eq >= 0) { val = key.slice(eq+1); key = key.slice(0,eq); }
    else if (!["h","help","V","version","fix","diff","check","list-rules","verbose","profile","statistics","quiet","silent","stdin","stderr","watch","force-exclude","no-cache","no-config","isolated","no-exclude","show-full-path","defaults","no-defaults","pyproject","fixable","explain","list-categories"].includes(key) && argv[i+1] && !argv[i+1].startsWith("-")) val = argv[++i];
    if (key === "d") key = "disable";
    if (key === "e" || key === "rules") key = "enable";
    if (key === "f") key = "fix";
    if (key === "l") key = "list-rules";
    if (key === "o" || key === "output") key = "output-format";
    if (key === "q") key = "quiet";
    if (key === "s") key = "silent";
    opts[key] = opts[key] === undefined ? val : [].concat(opts[key], val);
  }
  return opts;
}
function splitList(v) { return v ? String(Array.isArray(v)?v.join(","):v).split(",").map(s=>s.trim().toUpperCase()).filter(Boolean) : []; }
function rel(p) { return path.relative(process.cwd(), p).replace(/\\/g,"/") || p; }
function readConfig(opts) {
  const c = {enable:[], disable:[], lineLength:80, exclude:[], outputFormat:null};
  if (opts["no-config"] || opts.isolated) return c;
  let file = opts.config || [".rumdl.toml","rumdl.toml","pyproject.toml"].find(f => fs.existsSync(f));
  if (!file || !fs.existsSync(file)) return c;
  c.file = path.resolve(file);
  const txt = fs.readFileSync(file,"utf8");
  const arr = (name) => { const m = txt.match(new RegExp(`${name.replace("-","[-_]")}\\s*=\\s*\\[([^\\]]*)\\]`,"i")); return m ? [...m[1].matchAll(/"([^"]+)"|'([^']+)'|([A-Za-z0-9_-]+)/g)].map(x => (x[1]||x[2]||x[3]).toUpperCase()) : []; };
  c.enable = arr("enable"); c.disable = arr("disable"); c.exclude = arr("exclude").map(x=>x.toLowerCase());
  let m = txt.match(/line[-_]length\s*=\s*(\d+)/i); if (m) c.lineLength = +m[1];
  m = txt.match(/output[-_]format\s*=\s*["']?([A-Za-z-]+)/i); if (m) c.outputFormat = m[1];
  return c;
}
function enabledRules(opts, config) {
  let set = new Set(RULES.map(r=>r[0]).filter(id => !OPT_IN.has(id)));
  const en = splitList(opts.enable).concat(config.enable || []);
  const dis = splitList(opts.disable).concat(splitList(opts["extend-disable"])).concat(config.disable || []);
  const exen = splitList(opts["extend-enable"]);
  if (en.length) set = new Set(en.filter(id=>RULE[id]));
  for (const id of exen) if (RULE[id]) set.add(id);
  for (const id of dis) set.delete(id);
  return set;
}
function isMarkdown(f) { return /\.(md|markdown|mdown|mkd|mkdn|mdx|qmd)$/i.test(f); }
function walk(p, out=[]) {
  if (!fs.existsSync(p)) return out;
  const st = fs.statSync(p);
  if (st.isDirectory()) {
    for (const n of fs.readdirSync(p)) {
      if ([".git","node_modules",".rumdl_cache"].includes(n)) continue;
      walk(path.join(p,n), out);
    }
  } else if (isMarkdown(p)) out.push(p);
  return out;
}
function lineCol(text, idx) {
  const before = text.slice(0, idx).split("\n");
  return [before.length, before[before.length-1].length+1];
}
function add(issues, file, line, col, rule, msg, fixableOverride) {
  issues.push({file, line, column:col, rule, message:msg, severity:ERROR_RULES.has(rule)?"error":"warning", fixable:fixableOverride ?? RULE[rule].fixable, fix:null});
}
function headingInfo(line) {
  let m = line.match(/^(\s*)(#{1,6})(\s*)(.*?)(\s+#+\s*)?$/);
  if (!m) return null;
  return {indent:m[1].length, level:m[2].length, spaces:m[3].length, text:(m[4]||"").trim()};
}
function slug(s) { return s.toLowerCase().replace(/[`*_~[\]()]/g,"").replace(/[^\w\s-]/g,"").trim().replace(/\s+/g,"-"); }
function lintText(file, text, active, config) {
  const issues = [], lines = text.split(/\n/), headings = [], slugs = new Set(), refs = new Set();
  let inFence = false, firstH1 = false, blankRun = 0, firstContent = false, prevHeadingLevel = 0;
  lines.forEach((line, i) => {
    const n = i+1, raw = line.replace(/\r$/,"");
    const trimmed = raw.trim();
    const fence = raw.match(/^\s*(```+|~~~+)(.*)$/);
    if (fence) {
      if (active.has("MD031") && i>0 && lines[i-1].trim()!=="" && !inFence) add(issues,file,n,1,"MD031","Fenced code blocks should be surrounded by blank lines");
      if (active.has("MD040") && !inFence && fence[2].trim()==="") add(issues,file,n,1,"MD040","Fenced code block should have a language specified",false);
      inFence = !inFence; return;
    }
    const h = headingInfo(raw);
    if (active.has("MD009")) { const m = raw.match(/( +)$/); if (m && m[1].length !== 2) add(issues,file,n,raw.length-m[1].length+1,"MD009",`${m[1].length} trailing spaces found`); }
    if (active.has("MD010")) { const c = raw.indexOf("\t"); if (c>=0) add(issues,file,n,c+1,"MD010","Found tab for alignment, use spaces instead"); }
    if (trimmed==="") { blankRun++; if (active.has("MD012") && blankRun>1) add(issues,file,n,1,"MD012","Multiple consecutive blank lines between content"); return; } else blankRun = 0;
    if (!firstContent) { firstContent = true; if (active.has("MD041") && !/^#\s+/.test(raw) && !/^---\s*$/.test(raw)) add(issues,file,n,1,"MD041","First line in file should be a level 1 heading",false); }
    if (h) {
      headings.push({line:n, level:h.level, text:h.text}); slugs.add(slug(h.text));
      if (active.has("MD023") && h.indent) add(issues,file,n,1,"MD023","Headings must start at the beginning of the line");
      if (active.has("MD018") && h.spaces===0 && h.text) add(issues,file,n,h.level+1,"MD018",`No space after ${"#".repeat(h.level)} in heading`);
      if (active.has("MD019") && h.spaces>1) add(issues,file,n,h.level+1,"MD019",`Multiple spaces after ${"#".repeat(h.level)} in heading`);
      if (active.has("MD001") && prevHeadingLevel && h.level > prevHeadingLevel+1) add(issues,file,n,1,"MD001","Heading levels should only increment by one level at a time",false);
      prevHeadingLevel = h.level;
      if (active.has("MD022")) { if (i>0 && lines[i-1].trim()!=="" ) add(issues,file,n,1,"MD022","Headings should be surrounded by blank lines"); if (i<lines.length-1 && lines[i+1].trim()!=="" ) add(issues,file,n,1,"MD022","Headings should be surrounded by blank lines"); }
      if (active.has("MD025") && h.level===1) { if (firstH1) add(issues,file,n,1,"MD025","Multiple top-level headings (level 1) in the same document"); firstH1 = true; }
      if (active.has("MD026") && /[.,;:!?]$/.test(h.text)) add(issues,file,n,raw.length,"MD026","Trailing punctuation in heading");
    }
    if (!inFence && active.has("MD013") && config.lineLength>0 && raw.length > config.lineLength && !/^https?:\/\//.test(trimmed) && !/^\|.*\|$/.test(trimmed)) add(issues,file,n,config.lineLength+1,"MD013",`Line length [Expected: ${config.lineLength}; Actual: ${raw.length}]`);
    if (!inFence && active.has("MD030")) { const m = raw.match(/^(\s*)([-+*]|\d+[.)])( {2,})(\S)/); if (m) add(issues,file,n,m[1].length+m[2].length+1,"MD030",`Spaces after list markers (Expected: 1; Actual: ${m[3].length})`); }
    if (!inFence && active.has("MD032") && /^(\s*)([-+*]|\d+[.)])\s+/.test(raw)) { if (i>0 && lines[i-1].trim()!=="" && !/^(\s*)([-+*]|\d+[.)])\s+/.test(lines[i-1])) add(issues,file,n,1,"MD032","Lists should be surrounded by blank lines"); }
    if (!inFence && active.has("MD033")) { const m = raw.match(/<([A-Za-z][A-Za-z0-9-]*)(\s|>|\/)/); if (m && !/^<https?:/.test(raw.slice(m.index))) add(issues,file,n,m.index+1,"MD033",`Inline HTML found: <${m[1]}>`,false); }
    if (!inFence && active.has("MD034")) { const re = /(^|[\s(])(https?:\/\/[^\s<>)]+)/g; let m; while ((m=re.exec(raw))) add(issues,file,n,m.index+m[1].length+1,"MD034",`URL without angle brackets or link formatting: '${m[2].replace(/[.,;:]$/,"")}'`); }
    if (!inFence && active.has("MD042")) { const re = /!?\[[^\]]*\]\(\s*\)/g; let m; while ((m=re.exec(raw))) if (!m[0].startsWith("!")) add(issues,file,n,m.index+1,"MD042",`Empty link found: ${m[0]}`,false); }
    if (!inFence && active.has("MD045")) { const re = /!\[\s*\]\([^)]+\)/g; let m; while ((m=re.exec(raw))) add(issues,file,n,m.index+1,"MD045","Images should have alternate text (alt text)",false); }
    if (!inFence && active.has("MD011")) { const re = /\(([^)\s]+)\)\[([^\]]+)\]/g; let m; while ((m=re.exec(raw))) add(issues,file,n,m.index+1,"MD011",`Reversed link syntax found: ${m[0]}`); }
    if (!inFence && active.has("MD064")) { const m = raw.match(/\S {2,}\S/); if (m && !h && !/^(\s*)([-+*]|\d+[.)])\s+/.test(raw)) add(issues,file,n,m.index+2,"MD064","Multiple consecutive spaces in content"); }
    const rd = raw.match(/^\s*\[([^\]]+)\]:/); if (rd) refs.add(rd[1].toLowerCase());
  });
  if (active.has("MD047") && text.length && !text.endsWith("\n")) add(issues,file,lines.length,lines[lines.length-1].length,"MD047","Files should end with a single newline character");
  if (active.has("MD024")) {
    const seen = new Set(); for (const h of headings) { const k = h.text.toLowerCase(); if (seen.has(k)) add(issues,file,h.line,1,"MD024",`Multiple headings with the same content: ${h.text}`,false); seen.add(k); }
  }
  if (active.has("MD051")) {
    lines.forEach((raw,i)=>{ const re = /\[[^\]]+\]\(#([^)]+)\)/g; let m; while((m=re.exec(raw))) if (!slugs.has(decodeURIComponent(m[1]).toLowerCase())) add(issues,file,i+1,m.index+1,"MD051",`Link fragment should reference a valid heading: #${m[1]}`,false); });
  }
  return issues.sort((a,b)=>a.line-b.line||a.column-b.column||a.rule.localeCompare(b.rule));
}
function fixText(text) {
  let lines = text.split("\n").map(l => l.replace(/\t/g,"    ").replace(/ {3,}$/,""));
  lines = lines.map(l => l.replace(/^(\s*#{1,6})(\S)/, "$1 $2").replace(/^(\s*#{1,6}) {2,}(\S)/, "$1 $2").replace(/^(\s*[-+*]|\s*\d+[.)]) {2,}(\S)/, "$1 $2").replace(/(^|[\s(])(https?:\/\/[^\s<>)]+)/g, (m,p,u)=>`${p}<${u.replace(/[.,;:]$/,"")}>${/[.,;:]$/.test(u)?u.slice(-1):""}`));
  const out = []; let blanks = 0; for (const l of lines) { if (l.trim()==="") { blanks++; if (blanks<=1) out.push(""); } else { blanks=0; out.push(l); } }
  return out.join("\n").replace(/\n*$/,"\n");
}
function formatIssues(issues, opts) {
  const fmt = opts["output-format"] || opts.output || "text";
  if (fmt === "json") return JSON.stringify(issues.map(jsonIssue), null, 2);
  if (fmt === "json-lines") return issues.map(i=>JSON.stringify(jsonIssue(i))).join("\n");
  if (fmt === "github") return issues.map(i=>`::${i.severity==="error"?"error":"warning"} file=${i.file},line=${i.line},col=${i.column}::[${i.rule}] ${i.message}`).join("\n");
  if (fmt === "pylint") return issues.map(i=>`${i.file}:${i.line}:${i.column}: ${i.rule} ${i.message}`).join("\n");
  return issues.map(i=>`${i.file}:${i.line}:${i.column}: [${i.rule}] ${i.message}${i.fixable && fmt!=="concise" ? (opts.fix ? " [fixed]" : " [*]") : ""}`).join("\n");
}
function jsonIssue(i) { return {file:i.file,line:i.line,column:i.column,rule:i.rule,message:i.message,severity:i.severity,fixable:i.fixable,fix:null}; }
function collectFiles(paths, opts, config) {
  if (opts.stdin || paths.includes("-")) return [];
  const ps = paths.length ? paths : ["."];
  let files = ps.flatMap(p => walk(path.resolve(p)));
  const excl = splitList(opts.exclude).map(s=>s.toLowerCase()).concat(config.exclude||[]);
  if (excl.length && !opts["no-exclude"]) files = files.filter(f => !excl.some(e => rel(f).toLowerCase().includes(e.replace(/\*/g,""))));
  return [...new Set(files)].sort();
}
function checkCommand(argv, isFmt=false) {
  const opts = parseArgs(argv); if (isFmt) opts.fix = true;
  if (opts.help || opts.h) return helpCheck();
  if (opts["list-rules"]) return listRules();
  const config = readConfig(opts); if (!opts["output-format"] && config.outputFormat) opts["output-format"] = config.outputFormat;
  const active = enabledRules(opts, config), files = collectFiles(opts._, opts, config);
  let all = [];
  const stdinMode = opts.stdin || opts._.includes("-");
  if (stdinMode) {
    const text = fs.readFileSync(0,"utf8"); const fn = opts["stdin-filename"] || "stdin.md";
    const issues = lintText(fn, text, active, config); all.push(...issues);
    if (opts.fix) process.stdout.write(fixText(text));
  } else {
    for (const f of files) {
      let text = fs.readFileSync(f,"utf8");
      const before = lintText(rel(f), text, active, config);
      all.push(...before);
      if (opts.fix && before.some(i=>i.fixable)) fs.writeFileSync(f, fixText(text));
    }
  }
  if (!opts.silent && !(stdinMode && opts.fix)) {
    const body = formatIssues(all, opts); if (body) (opts.stderr?process.stderr:process.stdout).write(body+"\n");
    const jsonish = ["json","json-lines","sarif","junit"].includes(opts["output-format"]);
    if (!jsonish && !opts.quiet) {
      if (all.length) {
        const fixed = all.filter(i=>i.fixable).length;
        const countPhrase = opts.fix ? `Fixed ${fixed}/${all.length}` : `Found ${all.length}`;
        console.log(`\n${opts.fix?"Fixed":"Issues"}: ${countPhrase} issue${all.length===1?"":"s"} in ${Math.max(1, files.length || 1)} file${(files.length||1)===1?"":"s"} (0ms)`);
      }
      else console.log(`Success: no issues found in ${files.length || 1} file${(files.length||1)===1?"":"s"}`);
      if (all.length && !opts.fix) { const f = all.filter(i=>i.fixable).length; if (f) console.log(`Run \`rumdl fmt\` to automatically fix ${f} of the ${all.length} issues`); }
      if (opts.statistics && all.length) stats(all);
    }
  }
  const failOn = opts["fail-on"] || "any";
  const fail = failOn==="never" ? false : failOn==="error" ? all.some(i=>i.severity==="error") : all.length>0;
  process.exitCode = fail ? 1 : 0;
}
function stats(all){ const m={}; for(const i of all){m[i.rule]??={n:0,f:0};m[i.rule].n++; if(i.fixable)m[i.rule].f++;} console.log("\nRule Violation Statistics:"); console.log("Rule     Violations   Fixable  Percentage"); console.log("--------------------------------------------------"); for(const [r,v] of Object.entries(m)) console.log(`${r.padEnd(8)} ${String(v.n).padEnd(12)} ${String(v.f||"-").padEnd(8)} ${(v.n*100/all.length).toFixed(1)}%`); console.log("--------------------------------------------------"); console.log(`Total    ${String(all.length).padEnd(12)} ${String(all.filter(i=>i.fixable).length).padEnd(8)} 100.0%`); }
function listRules() { console.log("Available rules:"); for (const r of RULES) console.log(`  ${r[0]} - ${r[3]}`); console.log(`\nTotal: ${RULES.length} rules`); }
function ruleCommand(argv) {
  const opts = parseArgs(argv); if (opts.help) return console.log("Show information about a rule or list all rules\n\nUsage: executable rule [OPTIONS] [RULE]");
  if (opts["list-categories"]) { const cats={}; for(const r of RULES) cats[r[2]]=(cats[r[2]]||0)+1; console.log("Available categories:"); Object.keys(cats).sort().forEach(c=>console.log(`  ${c} (${cats[c]} rules)`)); return; }
  let rows = RULES.filter(r => (!opts.fixable || r[4]) && (!opts.category || r[2]===opts.category));
  const q = opts._[0] && opts._[0].toUpperCase();
  if (q) rows = rows.filter(r => r[0]===q || r[1].toUpperCase()===q);
  const fmt = opts["output-format"] || "text";
  if (fmt==="json") return console.log(JSON.stringify(rows.map(ruleJson), null, 2));
  if (fmt==="json-lines") return console.log(rows.map(r=>JSON.stringify(ruleJson(r))).join("\n"));
  if (!q) return listRules();
  const r = rows[0]; if (!r) { console.error(`Rule not found: ${opts._[0]}`); process.exitCode=1; return; }
  console.log(`${r[0]} - ${r[3]}\n\nName: ${r[1]}\nCategory: ${r[2]}\nFix: ${r[4] ? "Fix is always available." : "No automatic fix available."}\nDocumentation: https://rumdl.dev/${r[0].toLowerCase()}/`);
}
function ruleJson(r){ return {name:r[1], code:r[0], description:r[3], category:r[2], fixable:r[4]}; }
function configCommand(argv) {
  const opts = parseArgs(argv); const cfg = readConfig(opts); const sub=opts._[0];
  if (sub==="file") return console.log(cfg.file || "");
  if (sub==="get") { const k=opts._[1]||""; const vals={"global.enable":cfg.enable,"global.disable":cfg.disable,"global.line_length":cfg.lineLength,"MD013.line_length":cfg.lineLength}; const v=vals[k]; return console.log(Array.isArray(v)?JSON.stringify(v):String(v??"")); }
  if (opts.output==="json" || opts["output-format"]==="json") return console.log(JSON.stringify({global:{enable:cfg.enable,disable:cfg.disable,exclude:cfg.exclude,respect_gitignore:true,flavor:"Standard"},MD013:{"line-length":cfg.lineLength}}, null, 2));
  console.log(`[global]\nenable = []                                                                                                                                                                      [from default]\ndisable = []                                                                                                                                                                     [from default]\nexclude = []                                                                                                                                                                     [from default]\ninclude = []                                                                                                                                                                     [from default]\nrespect_gitignore = true                                                                                                                                                         [from default]\nflavor = Standard                                                                                                                                                                [from default]\n\n[MD013]\nline-length = ${cfg.lineLength}                                                                                                                                                                  [from default]`);
}
function initCommand(argv) {
  const opts = parseArgs(argv); const file = opts.pyproject ? "pyproject.toml" : ".rumdl.toml";
  if (fs.existsSync(file)) { console.error(`Configuration file already exists: ${file}`); process.exitCode=1; return; }
  fs.writeFileSync(file, opts.pyproject ? "[tool.rumdl]\nline_length = 80\ndisable = []\n" : "[global]\nline-length = 80\ndisable = []\n\n# [MD013]\n# line-length = 100\n");
  console.log(`Created ${file}`);
}
function explainCommand(argv) { const id=(argv.find(a=>!a.startsWith("-"))||"").toUpperCase(); if (!RULE[id]) return ruleCommand(argv); console.log(`${id} - ${RULE[id].desc}\n\nAliases: \`${RULE[id].name}\`\n\nWhat this rule does\n\nChecks Markdown documents for ${RULE[id].desc.toLowerCase()}.\n\nConfiguration\n\nSee https://rumdl.dev/${id.toLowerCase()}/ for full documentation.`); }
function helpMain(){ console.log(`A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  check        Lint Markdown files and print warnings/errors\n  fmt          Format Markdown files (alias for check --fix)\n  init         Initialize a new configuration file\n  rule         Show information about a rule or list all rules\n  explain      Explain a rule with detailed information and examples\n  config       Show configuration or query a specific key\n  server       Start the Language Server Protocol server\n  schema       Generate or check JSON schema for rumdl.toml\n  import       Import and convert markdownlint configuration files\n  vscode       Install the rumdl VS Code extension\n  completions  Generate shell completion scripts\n  clean        Clear the cache\n  version      Show version information\n  help         Print this message or the help of the given subcommand(s)\n\nOptions:\n      --color <COLOR>    Control colored output: auto, always, never [default: auto]\n      --config <CONFIG>  Path to configuration file\n      --no-config        Ignore all configuration files and use built-in defaults\n      --isolated         Ignore all configuration files (alias for --no-config)\n  -h, --help             Print help\n  -V, --version          Print version`); }
function helpCheck(){ console.log("Lint Markdown files and print warnings/errors\n\nUsage: executable check [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  Files or directories to lint (use '-' for stdin)\n\nOptions:\n  -f, --fix          Fix issues automatically where possible\n      --diff         Show diff of what would be fixed instead of fixing files\n      --check        Exit with code 1 if any formatting changes would be made (for CI)\n  -l, --list-rules   List all available rules\n  -d, --disable <DISABLE>  Disable specific rules (comma-separated)\n  -e, --enable <ENABLE>    Enable only specific rules (comma-separated)\n  -o, --output <OUTPUT>    Output format: text (default) or json\n  -h, --help         Print help"); }
function schemaCommand(argv){ const o=parseArgs(argv); const schema={title:"rumdl configuration",type:"object",properties:{global:{type:"object"},MD013:{type:"object",properties:{"line-length":{type:"integer"}}}}}; console.log(JSON.stringify(schema,null,2)); }
function completions(argv){ const shell=argv.find(a=>!a.startsWith("-"))||"bash"; console.log(`# ${shell} completions for rumdl\ncomplete -W "check fmt init rule explain config server schema import vscode completions clean version help" rumdl executable`); }

function main() {
  const argv = process.argv.slice(2), opts=parseArgs(argv);
  if (!argv.length || opts.help || opts.h) return helpMain();
  if (opts.version || opts.V) return console.log(`rumdl ${VERSION}`);
  const cmd = argv[0], rest = argv.slice(1);
  if (cmd==="check") return checkCommand(rest);
  if (cmd==="fmt") return checkCommand(rest, true);
  if (cmd==="rule") return ruleCommand(rest);
  if (cmd==="explain") return explainCommand(rest);
  if (cmd==="config") return configCommand(rest);
  if (cmd==="init") return initCommand(rest);
  if (cmd==="version") return console.log(`rumdl ${VERSION}`);
  if (cmd==="schema") return schemaCommand(rest);
  if (cmd==="completions") return completions(rest);
  if (cmd==="clean") { fs.rmSync(".rumdl_cache",{recursive:true,force:true}); return console.log("Cache cleared"); }
  if (cmd==="server") { console.error("Language server mode is not available in this reimplementation"); return; }
  if (cmd==="import") { console.log("# Converted markdownlint configuration\n[global]\ndisable = []"); return; }
  if (cmd==="vscode") { console.log("VS Code extension installation is not available in this environment"); return; }
  if (cmd==="help") return helpMain();
  console.error(`error: unrecognized command '${cmd}'\n\nUsage: executable [OPTIONS] <COMMAND>`); process.exitCode=2;
}
main();
