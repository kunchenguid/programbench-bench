#!/usr/bin/env node
'use strict';

const os = require('os');
const path = require('path');

const HELP = `A simple terminal UI for search and replace, ala VS Code

Usage: executable [OPTIONS]

Options:
  -p, --project-root <PATH>  Path to the project root [default: .]
  -h, --help                 Print help
  -V, --version              Print version
`;

function configDir() {
  const xdg = process.env.XDG_CONFIG_HOME;
  const home = os.homedir() || process.env.HOME || '';
  return path.join(xdg && xdg.length ? xdg : path.join(home, '.config'), 'serpl');
}

function versionText() {
  return `serpl 0.3.4- (2026-04-20)

Authors: Yassine Bridi <ybridi@gmail.com>

Config directory: ${configDir()}
`;
}

function usageFor(args) {
  if (args.length === 1 && (args[0] === '-V' || args[0] === '--version')) {
    return 'Usage: executable --version';
  }
  return 'Usage: executable [OPTIONS]';
}

function printCliError(message, args) {
  process.stderr.write(`error: ${message}\n\n${usageFor(args)}\n\nFor more information, try '--help'.\n`);
  process.exitCode = 2;
}

function parse(argv) {
  const args = argv.slice(2);
  let projectRoot = '.';
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '-h' || arg === '--help') return { mode: 'help' };
    if (arg === '-V' || arg === '--version') {
      return { mode: 'version' };
    }
    if (arg === '--version=1') {
      return { mode: 'error', message: "unexpected value '1' for '--version' found; no more were expected", args: ['--version'] };
    }
    if (arg.startsWith('--version=')) {
      const value = arg.slice('--version='.length);
      return { mode: 'error', message: `unexpected value '${value}' for '--version' found; no more were expected`, args: ['--version'] };
    }
    if (arg === '-p' || arg === '--project-root') {
      if (i + 1 >= args.length) {
        return { mode: 'error', message: "a value is required for '--project-root <PATH>' but none was supplied", args };
      }
      projectRoot = args[++i];
      continue;
    }
    if (arg.startsWith('--project-root=')) {
      projectRoot = arg.slice('--project-root='.length);
      continue;
    }
    if (arg.startsWith('-p') && arg.length > 2) {
      projectRoot = arg.slice(2);
      continue;
    }
    if (arg.startsWith('-V') && arg.length > 2) {
      return { mode: 'version' };
    }
    return { mode: 'error', message: `unexpected argument '${arg}' found`, args };
  }

  return { mode: 'run', projectRoot };
}

function fatalNonTty() {
  process.stderr.write('serpl error: Something went wrong\n');
  process.stderr.write('Error: \n');
  process.stderr.write('   0: \x1b[91mResource temporarily unavailable (os error 11)\x1b[0m\n');
  process.exitCode = 1;
}

function enterAltScreen() {
  process.stdout.write('\x1b[?1049h\x1b[?25l\x1b[39m\x1b[49m\x1b[59m\x1b[0m\x1b[?25h\x1b[2;2H');
}

function leaveAltScreen() {
  process.stdout.write('\x1b[39m\x1b[49m\x1b[59m\x1b[0m\x1b[?1049l\x1b[?25h');
}

function runTui() {
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    fatalNonTty();
    return;
  }

  enterAltScreen();
  if (process.stdin.setRawMode) process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.on('data', (buf) => {
    for (const byte of buf) {
      if (byte === 3 || byte === 4 || byte === 26) {
        if (process.stdin.setRawMode) process.stdin.setRawMode(false);
        leaveAltScreen();
        process.exit(byte === 3 ? 130 : 0);
      }
      if (byte === 2) {
        process.stdout.write('\x1b[?25l\x1b[39m\x1b[49m\x1b[59m\x1b[0m');
      }
    }
  });
  const timer = setInterval(() => {
    process.stdout.write('\x1b[39m\x1b[49m\x1b[59m\x1b[0m\x1b[?25h\x1b[2;2H');
  }, 120);
  timer.unref();
}

const result = parse(process.argv);
if (result.mode === 'help') {
  process.stdout.write(HELP);
} else if (result.mode === 'version') {
  process.stdout.write(versionText());
} else if (result.mode === 'error') {
  printCliError(result.message, result.args);
} else {
  runTui(result.projectRoot);
}
