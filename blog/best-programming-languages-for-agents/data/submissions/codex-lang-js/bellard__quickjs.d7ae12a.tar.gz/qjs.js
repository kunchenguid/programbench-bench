#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const util = require('util');
const childProcess = require('child_process');

const VERSION = '2025-09-13';

function help() {
  process.stdout.write(`QuickJS version ${VERSION}
usage: qjs [options] [file [args]]
-h  --help         list options
-e  --eval EXPR    evaluate EXPR
-i  --interactive  go to interactive mode
-m  --module       load as ES6 module (default=autodetect)
    --script       load as ES6 script (default=autodetect)
    --strict       force strict mode
-I  --include file include an additional file
    --std          make 'std' and 'os' available to the loaded script
-T  --trace        trace memory allocation
-d  --dump         dump the memory usage stats
    --memory-limit n  limit the memory usage to 'n' bytes (SI suffixes allowed)
    --stack-size n    limit the stack size to 'n' bytes (SI suffixes allowed)
    --no-unhandled-rejection  ignore unhandled promise rejections
-s                    strip all the debug info
    --strip-source    strip the source code
-q  --quit         just instantiate the interpreter and quit
`);
}

function die(msg, code = 1) {
  process.stderr.write(msg);
  process.exit(code);
}

function qjsString(value) {
  if (typeof value === 'string') return value;
  return util.inspect(value, {
    colors: false,
    depth: 4,
    compact: true,
    breakLength: Infinity,
    sorted: false,
  });
}

function printLine(...args) {
  process.stdout.write(args.map(qjsString).join(' ') + '\n');
}

function printfFormat(fmt, args) {
  let ai = 0;
  return String(fmt).replace(/%([-+ #0]*)(\d+)?(?:\.(\d+))?([sdifxX%])/g, (m, flags, width, prec, type) => {
    if (type === '%') return '%';
    const val = args[ai++];
    let out;
    if (type === 's') out = String(val);
    else if (type === 'd' || type === 'i') out = String(Number(val) < 0 ? Math.ceil(Number(val)) : Math.floor(Number(val)));
    else if (type === 'f') out = Number(val).toFixed(prec == null ? 6 : Number(prec));
    else if (type === 'x' || type === 'X') {
      out = (Number(val) >>> 0).toString(16);
      if (type === 'X') out = out.toUpperCase();
    } else {
      out = String(val);
    }
    if (width) {
      const w = Number(width);
      const padChar = flags.includes('0') && !flags.includes('-') ? '0' : ' ';
      if (out.length < w) {
        const pad = padChar.repeat(w - out.length);
        out = flags.includes('-') ? out + pad : pad + out;
      }
    }
    return out;
  });
}

function makeStd() {
  const std = {
    SEEK_SET: 0,
    SEEK_CUR: 1,
    SEEK_END: 2,
    Error,
    printf(fmt, ...args) {
      const s = printfFormat(fmt, args);
      process.stdout.write(s);
      return s.length;
    },
    sprintf(fmt, ...args) {
      return printfFormat(fmt, args);
    },
    puts(s) {
      process.stdout.write(String(s));
      return 0;
    },
    loadFile(name) {
      try {
        return fs.readFileSync(String(name), 'utf8');
      } catch {
        return null;
      }
    },
    readFile(name) {
      return fs.readFileSync(String(name), 'utf8');
    },
    strerror(errno) {
      const map = {
        1: 'Operation not permitted',
        2: 'No such file or directory',
        5: 'Input/output error',
        13: 'Permission denied',
        17: 'File exists',
        22: 'Invalid argument',
      };
      return map[Number(errno)] || 'Unknown error';
    },
    exit(code = 0) {
      process.exit(Number(code) || 0);
    },
    gc() {
      if (global.gc) global.gc();
    },
    getenv(name) {
      return Object.prototype.hasOwnProperty.call(process.env, String(name)) ? process.env[String(name)] : undefined;
    },
    setenv(name, value) {
      process.env[String(name)] = String(value);
    },
    unsetenv(name) {
      delete process.env[String(name)];
    },
    getenviron() {
      return { ...process.env };
    },
    parseExtJSON(s) {
      return JSON.parse(String(s));
    },
    tmpfile() {
      const name = path.join('/tmp', `qjs-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}`);
      fs.writeFileSync(name, '');
      return makeFile(name, 'w+');
    },
    open(name, flags = 'r') {
      try {
        return makeFile(String(name), String(flags));
      } catch {
        return null;
      }
    },
    popen(cmd, flags = 'r') {
      const output = childProcess.execSync(String(cmd), { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
      return makeMemoryFile(output);
    },
  };
  return std;
}

function makeMemoryFile(data) {
  let pos = 0;
  return {
    getline() {
      if (pos >= data.length) return null;
      const next = data.indexOf('\n', pos);
      if (next < 0) {
        const s = data.slice(pos);
        pos = data.length;
        return s;
      }
      const s = data.slice(pos, next + 1);
      pos = next + 1;
      return s;
    },
    readAsString() {
      const s = data.slice(pos);
      pos = data.length;
      return s;
    },
    close() {
      return 0;
    },
  };
}

function makeFile(name, flags) {
  const mode = flags.includes('w') ? 'w+' : flags.includes('a') ? 'a+' : 'r';
  const fd = fs.openSync(name, mode);
  let pos = 0;
  return {
    puts(s) {
      const b = Buffer.from(String(s));
      fs.writeSync(fd, b, 0, b.length, null);
      return 0;
    },
    readAsString() {
      const s = fs.readFileSync(name, 'utf8').slice(pos);
      pos += s.length;
      return s;
    },
    getline() {
      const s = fs.readFileSync(name, 'utf8');
      if (pos >= s.length) return null;
      const next = s.indexOf('\n', pos);
      if (next < 0) {
        const out = s.slice(pos);
        pos = s.length;
        return out;
      }
      const out = s.slice(pos, next + 1);
      pos = next + 1;
      return out;
    },
    close() {
      fs.closeSync(fd);
      return 0;
    },
  };
}

function makeOs() {
  return {
    platform: process.platform,
    open: (p, flags = 0, mode = 0o666) => {
      const mapFlags = typeof flags === 'string' ? flags : ((Number(flags) & 2) ? 'r+' : 'r');
      return fs.openSync(String(p), mapFlags, Number(mode));
    },
    close: (fd) => { fs.closeSync(Number(fd)); return 0; },
    seek: (fd, offset, whence = 0) => Number(offset),
    read: (fd, buffer, offset = 0, length) => {
      const len = length == null ? (buffer.byteLength || buffer.length || 0) - Number(offset) : Number(length);
      const b = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer.buffer || buffer);
      return fs.readSync(Number(fd), b, Number(offset), len, null);
    },
    write: (fd, buffer, offset = 0, length) => {
      const b = typeof buffer === 'string' ? Buffer.from(buffer) : Buffer.from(buffer.buffer || buffer);
      const len = length == null ? b.length - Number(offset) : Number(length);
      return fs.writeSync(Number(fd), b, Number(offset), len, null);
    },
    isatty: (fd) => {
      if (Number(fd) === 0) return !!process.stdin.isTTY;
      if (Number(fd) === 1) return !!process.stdout.isTTY;
      if (Number(fd) === 2) return !!process.stderr.isTTY;
      return false;
    },
    getcwd: () => process.cwd(),
    chdir: (d) => { process.chdir(String(d)); return 0; },
    readdir: (d) => fs.readdirSync(String(d)),
    remove: (p) => { fs.unlinkSync(String(p)); return 0; },
    rename: (a, b) => { fs.renameSync(String(a), String(b)); return 0; },
    mkdir: (p, mode = 0o777) => { fs.mkdirSync(String(p), { mode: Number(mode), recursive: false }); return 0; },
    realpath: (p) => fs.realpathSync(String(p)),
    readlink: (p) => fs.readlinkSync(String(p)),
    symlink: (target, p) => { fs.symlinkSync(String(target), String(p)); return 0; },
    stat: (p) => statArray(fs.statSync(String(p))),
    lstat: (p) => statArray(fs.lstatSync(String(p))),
    sleep: (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, Math.max(0, Number(ms))),
    setTimeout: (fn, ms) => setTimeout(fn, ms),
    clearTimeout: (id) => clearTimeout(id),
    exec: (cmd) => childProcess.spawnSync(Array.isArray(cmd) ? cmd[0] : String(cmd), Array.isArray(cmd) ? cmd.slice(1) : [], { stdio: 'inherit' }).status || 0,
  };
}

function statArray(st) {
  return [st.dev, st.ino, st.mode, st.nlink, st.uid, st.gid, st.rdev, st.size, Math.floor(st.atimeMs), Math.floor(st.mtimeMs), Math.floor(st.ctimeMs)];
}

function makeContext(scriptArgs, exposeStd) {
  const std = makeStd();
  const os = makeOs();
  const sandbox = {
    console: { log: printLine, error: (...args) => process.stderr.write(args.map(qjsString).join(' ') + '\n') },
    print: printLine,
    scriptArgs,
    globalThis: undefined,
    BigInt,
    setTimeout,
    clearTimeout,
    Promise,
  };
  sandbox.globalThis = sandbox;
  if (exposeStd) {
    sandbox.std = std;
    sandbox.os = os;
  }
  const ctx = vm.createContext(sandbox);
  return { ctx, std, os };
}

function formatError(err) {
  if (err && err.stack) return String(err.stack).replace(/\n    at evalmachine\.<anonymous>/g, '\n    at <eval>');
  return String(err);
}

function runScript(code, filename, env, strict) {
  const src = strict ? `"use strict";\n${code}` : code;
  const script = new vm.Script(src, { filename });
  return script.runInContext(env.ctx);
}

async function runModule(file, env) {
  if (typeof vm.SourceTextModule !== 'function') {
    throw new Error('module support requires --experimental-vm-modules');
  }
  const seen = new Map();
  const load = async (specifier, referrer) => {
    if (specifier === 'std' || specifier === 'os') {
      const obj = specifier === 'std' ? env.std : env.os;
      const names = Object.keys(obj).filter((k) => /^[A-Za-z_$][\w$]*$/.test(k));
      const mod = new vm.SyntheticModule(names, function () {
        for (const name of names) this.setExport(name, obj[name]);
      }, { context: env.ctx, identifier: specifier });
      await mod.link(() => {});
      await mod.evaluate();
      return mod;
    }
    const base = referrer && referrer.identifier && referrer.identifier.startsWith('file://')
      ? path.dirname(new URL(referrer.identifier).pathname)
      : process.cwd();
    let resolved = specifier.startsWith('.') || specifier.startsWith('/')
      ? path.resolve(base, specifier)
      : specifier;
    if (!path.extname(resolved) && fs.existsSync(resolved + '.js')) resolved += '.js';
    if (!fs.existsSync(resolved)) throw new Error(`Cannot find module '${specifier}'`);
    if (seen.has(resolved)) return seen.get(resolved);
    const source = fs.readFileSync(resolved, 'utf8');
    const mod = new vm.SourceTextModule(source, {
      context: env.ctx,
      identifier: new URL(`file://${resolved}`).href,
      initializeImportMeta(meta) {
        meta.url = new URL(`file://${resolved}`).href;
      },
    });
    seen.set(resolved, mod);
    await mod.link(load);
    await mod.evaluate();
    return mod;
  };
  await load(path.resolve(file), null);
}

function parse(argv) {
  const opts = { includes: [], evals: [], mode: 'auto', strict: false, std: false, dump: false, trace: false, interactive: false, quit: false };
  let i = 0;
  for (; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') { i++; break; }
    if (a === '-h' || a === '--help') { opts.help = true; continue; }
    if (a === '-q' || a === '--quit') { opts.quit = true; continue; }
    if (a === '-i' || a === '--interactive') { opts.interactive = true; continue; }
    if (a === '-m' || a === '--module') { opts.mode = 'module'; continue; }
    if (a === '--script') { opts.mode = 'script'; continue; }
    if (a === '--strict') { opts.strict = true; continue; }
    if (a === '--std') { opts.std = true; continue; }
    if (a === '-d' || a === '--dump') { opts.dump = true; continue; }
    if (a === '-T' || a === '--trace') { opts.trace = true; continue; }
    if (a === '-s' || a === '--strip-source') continue;
    if (a === '--no-unhandled-rejection') continue;
    if (a === '-e' || a === '--eval') {
      if (i + 1 >= argv.length) die('qjs: missing expression for -e\n', 2);
      opts.evals.push(argv[++i]);
      continue;
    }
    if (a === '-I' || a === '--include') {
      if (i + 1 >= argv.length) die('expecting filename', 1);
      opts.includes.push(argv[++i]);
      continue;
    }
    if (a === '--memory-limit' || a === '--stack-size') {
      if (i + 1 >= argv.length) die(`qjs: missing argument for ${a}\n`, 2);
      i++;
      continue;
    }
    if (a.startsWith('-') && a !== '-') {
      process.stderr.write(`qjs: unknown option '${a}'\n`);
      help();
      process.exit(1);
    }
    break;
  }
  opts.file = argv[i];
  opts.args = argv.slice(i);
  if (opts.evals.length) opts.args = argv.slice(i);
  return opts;
}

async function main() {
  const opts = parse(process.argv.slice(2));
  if (opts.help) {
    help();
    process.exit(1);
  }
  if (opts.quit) process.exit(0);
  if (opts.trace) process.stderr.write('');

  const scriptArgs = opts.evals.length ? opts.args : (opts.file ? opts.args : []);
  const env = makeContext(scriptArgs, opts.std);

  try {
    for (const inc of opts.includes) {
      const code = fs.readFileSync(inc, 'utf8');
      runScript(code, inc, env, opts.strict);
    }
    for (const expr of opts.evals) runScript(expr, '<cmdline>', env, opts.strict);

    if (opts.file && !opts.evals.length) {
      let code;
      try {
        code = fs.readFileSync(opts.file, 'utf8');
      } catch {
        die(`${opts.file}: No such file or directory\n`, 1);
      }
      const moduleMode = opts.mode === 'module' || (opts.mode === 'auto' && (opts.file.endsWith('.mjs') || /^\s*(import|export)\s/m.test(code)));
      if (moduleMode) await runModule(path.resolve(opts.file), env);
      else runScript(code, opts.file, env, opts.strict);
    } else if (!opts.evals.length && (opts.interactive || !process.stdin.isTTY)) {
      const input = fs.readFileSync(0, 'utf8');
      if (input) runScript(input, '<stdin>', env, opts.strict);
    }

    if (opts.dump) {
      process.stdout.write(`QuickJS memory usage -- ${VERSION} version, 64-bit, malloc limit: -1\n\n`);
    }
  } catch (err) {
    process.stderr.write(formatError(err) + '\n');
    process.exit(1);
  }
}

main();
