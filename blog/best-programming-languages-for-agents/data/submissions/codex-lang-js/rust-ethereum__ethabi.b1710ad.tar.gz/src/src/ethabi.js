#!/usr/bin/env node
'use strict';

const fs = require('fs');

const VERSION = '18.0.0';

function out(s = '') { process.stdout.write(s + '\n'); }
function die(msg) { process.stderr.write(`Error: ${msg}\n`); process.exit(1); }

function cleanHex(s) {
  if (s.startsWith('0x') || s.startsWith('0X')) s = s.slice(2);
  if (s.length % 2) throw new Error('Hex parsing error: Odd number of digits\n\nCaused by:\n    Odd number of digits');
  if (!/^[0-9a-fA-F]*$/.test(s)) throw new Error('Invalid data');
  return s.toLowerCase();
}
function hexToBuf(s) { return Buffer.from(cleanHex(s), 'hex'); }
function pad32(hex, left = true) {
  if (hex.length > 64) throw new Error('Invalid data');
  return left ? hex.padStart(64, '0') : hex.padEnd(64, '0');
}
function word(n) { return BigInt(n).toString(16).padStart(64, '0'); }
function ceil32(n) { return Math.ceil(n / 32) * 32; }

function parseType(s) {
  const arrays = [];
  while (s.endsWith(']')) {
    const i = s.lastIndexOf('[');
    const v = s.slice(i + 1, -1);
    arrays.unshift(v === '' ? null : Number(v));
    s = s.slice(0, i);
  }
  let base = { kind: s, bits: null, size: null };
  let m;
  if ((m = s.match(/^uint(\d*)$/))) base = { kind: 'uint', bits: Number(m[1] || '256') };
  else if ((m = s.match(/^int(\d*)$/))) base = { kind: 'int', bits: Number(m[1] || '256') };
  else if ((m = s.match(/^bytes(\d+)$/))) base = { kind: 'fixedBytes', size: Number(m[1]) };
  else if (!['bool', 'address', 'string', 'bytes'].includes(s)) throw new Error(`Invalid type: ${s}`);
  let t = base;
  for (const len of arrays) t = { kind: 'array', len, elem: t };
  return t;
}
function canonical(t) {
  if (t.kind === 'array') return canonical(t.elem) + '[' + (t.len == null ? '' : t.len) + ']';
  if (t.kind === 'uint') return 'uint' + t.bits;
  if (t.kind === 'int') return 'int' + t.bits;
  if (t.kind === 'fixedBytes') return 'bytes' + t.size;
  return t.kind;
}
function isDynamic(t) {
  if (t.kind === 'string' || t.kind === 'bytes') return true;
  if (t.kind === 'array') return t.len == null || isDynamic(t.elem);
  return false;
}

function splitArray(s) {
  s = s.trim();
  if (!s.startsWith('[') || !s.endsWith(']')) throw new Error('Invalid data');
  const inner = s.slice(1, -1).trim();
  if (!inner) return [];
  const out = [];
  let depth = 0, start = 0;
  for (let i = 0; i < inner.length; i++) {
    const c = inner[i];
    if (c === '[') depth++;
    else if (c === ']') depth--;
    else if (c === ',' && depth === 0) {
      out.push(inner.slice(start, i).trim());
      start = i + 1;
    }
  }
  out.push(inner.slice(start).trim());
  return out;
}

function parseAtom(t, s, lenient) {
  if (t.kind === 'bool') {
    if (s === 'true' || s === '1') return true;
    if (s === 'false' || s === '0') return false;
    throw new Error('Invalid data');
  }
  if (t.kind === 'uint') {
    let n;
    if (lenient) n = BigInt(s);
    else n = BigInt('0x' + cleanHex(s));
    if (n < 0n || n >= (1n << BigInt(t.bits))) throw new Error('Invalid data');
    return n;
  }
  if (t.kind === 'int') {
    let n = lenient ? BigInt(s) : BigInt('0x' + cleanHex(s));
    if (!lenient && n >= (1n << BigInt(t.bits - 1))) n -= (1n << BigInt(t.bits));
    if (n < -(1n << BigInt(t.bits - 1)) || n >= (1n << BigInt(t.bits - 1))) throw new Error('Invalid data');
    return n;
  }
  if (t.kind === 'address') {
    const h = cleanHex(s);
    if (h.length !== 40) throw new Error('Invalid data');
    return h;
  }
  if (t.kind === 'fixedBytes') {
    const h = cleanHex(s);
    if (h.length !== t.size * 2) throw new Error('Invalid data');
    return h;
  }
  if (t.kind === 'bytes') return cleanHex(s);
  if (t.kind === 'string') return Buffer.from(s, 'utf8').toString('hex');
  throw new Error('Invalid data');
}

function parseValue(t, s, lenient) {
  if (t.kind === 'array') {
    const parts = splitArray(s);
    if (t.len != null && parts.length !== t.len) throw new Error('Invalid data');
    return parts.map(p => parseValue(t.elem, p, lenient));
  }
  return parseAtom(t, s, lenient);
}

function encodePrimitive(t, v) {
  if (t.kind === 'bool') return word(v ? 1 : 0);
  if (t.kind === 'uint') return word(v);
  if (t.kind === 'int') {
    let n = v;
    if (n < 0) n = (1n << 256n) + n;
    return n.toString(16).padStart(64, '0');
  }
  if (t.kind === 'address') return pad32(v);
  if (t.kind === 'fixedBytes') return pad32(v, false);
  throw new Error('Invalid data');
}
function encodeDynamicBytes(hex) {
  return word(hex.length / 2) + hex.padEnd(ceil32(hex.length / 2) * 2, '0');
}
function encodeSingle(t, v) {
  if (t.kind === 'string' || t.kind === 'bytes') return encodeDynamicBytes(v);
  if (t.kind === 'array') {
    const body = encodeTuple(Array(v.length).fill(t.elem), v);
    return (t.len == null ? word(v.length) : '') + body;
  }
  return encodePrimitive(t, v);
}
function encodeTuple(types, vals) {
  let head = '', tail = '';
  const headSize = types.length * 32;
  for (let i = 0; i < types.length; i++) {
    if (isDynamic(types[i])) {
      head += word(headSize + tail.length / 2);
      tail += encodeSingle(types[i], vals[i]);
    } else {
      head += encodeSingle(types[i], vals[i]);
    }
  }
  return head + tail;
}
function encodeParams(typeStrings, valueStrings, lenient) {
  if (typeStrings.length !== valueStrings.length) throw new Error('Invalid data');
  const types = typeStrings.map(parseType);
  const vals = types.map((t, i) => parseValue(t, valueStrings[i], lenient));
  return encodeTuple(types, vals);
}

function readWord(buf, off) {
  if (off + 32 > buf.length) throw new Error('Invalid data');
  return BigInt('0x' + buf.subarray(off, off + 32).toString('hex'));
}
function decodeSingle(t, buf, off, base = 0) {
  if (isDynamic(t)) return decodeAt(t, buf, base + Number(readWord(buf, off)));
  return decodeAt(t, buf, off);
}
function decodeAt(t, buf, off) {
  if (t.kind === 'bool') return readWord(buf, off) !== 0n;
  if (t.kind === 'uint') return readWord(buf, off);
  if (t.kind === 'int') {
    let n = readWord(buf, off);
    if (n >= (1n << 255n)) n -= (1n << 256n);
    return n;
  }
  if (t.kind === 'address') return buf.subarray(off + 12, off + 32).toString('hex');
  if (t.kind === 'fixedBytes') return buf.subarray(off, off + t.size).toString('hex');
  if (t.kind === 'bytes' || t.kind === 'string') {
    const len = Number(readWord(buf, off));
    const h = buf.subarray(off + 32, off + 32 + len);
    return t.kind === 'string' ? h.toString('utf8') : h.toString('hex');
  }
  if (t.kind === 'array') {
    let len = t.len, pos = off;
    if (len == null) { len = Number(readWord(buf, off)); pos += 32; }
    const arr = [];
    for (let i = 0; i < len; i++) arr.push(decodeSingle(t.elem, buf, pos + i * 32, pos));
    return arr;
  }
  throw new Error('Invalid data');
}
function decodeTuple(types, hex) {
  const buf = hexToBuf(hex);
  return types.map((t, i) => decodeSingle(t, buf, i * 32, 0));
}
function formatValue(t, v) {
  if (t.kind === 'array') return '[' + v.map(x => formatValue(t.elem, x)).join(',') + ']';
  if (t.kind === 'bool') return v ? 'true' : 'false';
  if (t.kind === 'uint' || t.kind === 'int') return (v < 0n ? '-' + (-v).toString(16) : v.toString(16));
  return String(v);
}

// Keccak-256, implemented with BigInt lanes. Ethereum uses Keccak padding, not FIPS SHA3.
const RC = [
  1n,0x8082n,0x800000000000808an,0x8000000080008000n,0x808bn,0x80000001n,
  0x8000000080008081n,0x8000000000008009n,0x8an,0x88n,0x80008009n,0x8000000an,
  0x8000808bn,0x800000000000008bn,0x8000000000008089n,0x8000000000008003n,
  0x8000000000008002n,0x8000000000000080n,0x800an,0x800000008000000an,
  0x8000000080008081n,0x8000000000008080n,0x80000001n,0x8000000080008008n
];
const ROT = [0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14];
const MASK = (1n << 64n) - 1n;
function rol(x, n) { n = BigInt(n); return ((x << n) | (x >> (64n - n))) & MASK; }
function keccakF(s) {
  for (const rc of RC) {
    const c = Array(5).fill(0n), d = Array(5).fill(0n);
    for (let x = 0; x < 5; x++) c[x] = s[x] ^ s[x+5] ^ s[x+10] ^ s[x+15] ^ s[x+20];
    for (let x = 0; x < 5; x++) d[x] = c[(x+4)%5] ^ rol(c[(x+1)%5], 1);
    for (let i = 0; i < 25; i++) s[i] = (s[i] ^ d[i % 5]) & MASK;
    const b = Array(25);
    for (let x = 0; x < 5; x++) for (let y = 0; y < 5; y++) {
      const i = x + 5*y;
      b[y + 5*((2*x + 3*y) % 5)] = rol(s[i], ROT[i]);
    }
    for (let x = 0; x < 5; x++) for (let y = 0; y < 5; y++) {
      s[x+5*y] = (b[x+5*y] ^ ((~b[((x+1)%5)+5*y]) & b[((x+2)%5)+5*y])) & MASK;
    }
    s[0] = (s[0] ^ rc) & MASK;
  }
}
function keccak256Hex(str) {
  const rate = 136;
  const msg = Array.from(Buffer.from(str, 'utf8'));
  msg.push(0x01);
  while ((msg.length % rate) !== rate - 1) msg.push(0);
  msg.push(0x80);
  const s = Array(25).fill(0n);
  for (let off = 0; off < msg.length; off += rate) {
    for (let i = 0; i < rate / 8; i++) {
      let lane = 0n;
      for (let j = 0; j < 8; j++) lane |= BigInt(msg[off + i*8 + j]) << (8n * BigInt(j));
      s[i] ^= lane;
    }
    keccakF(s);
  }
  const bytes = [];
  for (let i = 0; bytes.length < 32; i++) for (let j = 0; j < 8 && bytes.length < 32; j++) bytes.push(Number((s[i] >> (8n*BigInt(j))) & 255n));
  return Buffer.from(bytes).toString('hex');
}

function loadAbi(path) { return JSON.parse(fs.readFileSync(path, 'utf8')); }
function signature(item) {
  return `${item.name}(${(item.inputs || []).map(x => x.type).join(',')})`;
}
function findItem(abi, kind, nameOrSig) {
  const matches = abi.filter(x => x.type === kind && (signature(x) === nameOrSig || x.name === nameOrSig));
  if (!matches.length) throw new Error(`${kind === 'event' ? 'Event' : 'Function'} not found`);
  if (matches.length > 1 && !nameOrSig.includes('(')) throw new Error(`More than one ${kind} found for name ${nameOrSig}`);
  return matches[0];
}

function help(args) {
  const s = args.join(' ');
  if (!s) return out(`ethabi-cli ${VERSION}\nEthereum ABI coder\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    decode    Decode ABI call result\n    encode    Encode ABI call\n    help      Prints this message or the help of the given subcommand(s)`);
  if (s === 'encode') return out(`executable-encode ${VERSION}\nEncode ABI call\n\nUSAGE:\n    executable encode <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    help        Prints this message or the help of the given subcommand(s)\n    params      Specify types of input params inline`);
  if (s === 'decode') return out(`executable-decode ${VERSION}\nDecode ABI call result\n\nUSAGE:\n    executable decode <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    help        Prints this message or the help of the given subcommand(s)\n    log         Decode event log\n    params      Specify types of input params inline`);
  if (s === 'encode params') return out(`executable-encode-params ${VERSION}\nSpecify types of input params inline\n\nUSAGE:\n    executable encode params [FLAGS] [OPTIONS]\n\nFLAGS:\n    -h, --help       \n            Prints help information\n\n    -l, --lenient    \n            Allow short representation of input params (numbers are in decimal form)\n\n    -V, --version    \n            Prints version information\n\n\nOPTIONS:\n    -v <type-or-param> <type-or-param>        \n            Pairs of types directly followed by params in the form:\n            \n            -v <type1> <param1> -v <type2> <param2> ...`);
  if (s === 'encode function') return out(`executable-encode-function ${VERSION}\nLoad function from JSON ABI file\n\nUSAGE:\n    executable encode function [FLAGS] [OPTIONS] <abi-path> <function-name-or-signature>\n\nFLAGS:\n    -h, --help       Prints help information\n    -l, --lenient    Allow short representation of input params\n    -V, --version    Prints version information\n\nOPTIONS:\n    -p <params>...        \n\nARGS:\n    <abi-path>                      \n    <function-name-or-signature>    `);
  if (s === 'decode params') return out(`executable-decode-params ${VERSION}\nSpecify types of input params inline\n\nUSAGE:\n    executable decode params [OPTIONS] <data>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -t <type>...        \n\nARGS:\n    <data>    `);
  if (s === 'decode function') return out(`executable-decode-function ${VERSION}\nLoad function from JSON ABI file\n\nUSAGE:\n    executable decode function <abi-path> <function-name-or-signature> <data>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <abi-path>                      \n    <function-name-or-signature>    \n    <data>                          `);
  if (s === 'decode log') return out(`executable-decode-log ${VERSION}\nDecode event log\n\nUSAGE:\n    executable decode log [OPTIONS] <abi-path> <event-name-or-signature> <data>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -l <topic>...        \n\nARGS:\n    <abi-path>                   \n    <event-name-or-signature>    \n    <data>                       `);
}

function main(argv) {
  try {
    if (argv.length === 0 || argv[0] === '-h' || argv[0] === '--help') return help([]);
    if (argv[0] === '-V' || argv[0] === '--version') return out(`ethabi-cli ${VERSION}`);
    if (argv[0] === 'help') return help(argv.slice(1));
    if ((argv[1] === '-h' || argv[1] === '--help') || (argv[2] === '-h' || argv[2] === '--help')) return help(argv.filter(x => !x.startsWith('-')));
    if (argv[0] === 'encode' && argv[1] === 'params') {
      let lenient = false, ts = [], vs = [];
      for (let i = 2; i < argv.length; i++) {
        if (argv[i] === '-l' || argv[i] === '--lenient') lenient = true;
        else if (argv[i] === '-v') { ts.push(argv[++i]); vs.push(argv[++i]); }
      }
      return out(encodeParams(ts, vs, lenient));
    }
    if (argv[0] === 'encode' && argv[1] === 'function') {
      let lenient = false, ps = [], rest = [];
      for (let i = 2; i < argv.length; i++) {
        if (argv[i] === '-l' || argv[i] === '--lenient') lenient = true;
        else if (argv[i] === '-p') ps.push(argv[++i]);
        else rest.push(argv[i]);
      }
      const item = findItem(loadAbi(rest[0]), 'function', rest[1]);
      const types = item.inputs.map(x => x.type);
      return out(keccak256Hex(signature(item)).slice(0, 8) + encodeParams(types, ps, lenient));
    }
    if (argv[0] === 'decode' && argv[1] === 'params') {
      const ts = []; let data = null;
      for (let i = 2; i < argv.length; i++) {
        if (argv[i] === '-t') ts.push(argv[++i]); else data = argv[i];
      }
      const types = ts.map(parseType), vals = decodeTuple(types, cleanHex(data || ''));
      types.forEach((t, i) => out(`${canonical(t)} ${formatValue(t, vals[i])}`));
      return;
    }
    if (argv[0] === 'decode' && argv[1] === 'function') {
      const item = findItem(loadAbi(argv[2]), 'function', argv[3]);
      const types = (item.outputs || []).map(x => parseType(x.type));
      const vals = decodeTuple(types, cleanHex(argv[4] || ''));
      types.forEach((t, i) => out(`${canonical(t)} ${formatValue(t, vals[i])}`));
      return;
    }
    if (argv[0] === 'decode' && argv[1] === 'log') {
      const topics = []; let rest = [];
      for (let i = 2; i < argv.length; i++) {
        if (argv[i] === '-l') topics.push(argv[++i]); else rest.push(argv[i]);
      }
      const item = findItem(loadAbi(rest[0]), 'event', rest[1]);
      const indexed = item.inputs.filter(x => x.indexed);
      const plain = item.inputs.filter(x => !x.indexed);
      const dataVals = decodeTuple(plain.map(x => parseType(x.type)), cleanHex(rest[2] || ''));
      if (!item.anonymous && topics.length === indexed.length + 1) topics.shift();
      let ti = 0, di = 0;
      for (const input of item.inputs) {
        const t = parseType(input.type);
        if (input.indexed) {
          const vals = decodeTuple([t], cleanHex(topics[ti++] || ''));
          out(`${canonical(t)} ${formatValue(t, vals[0])}`);
        } else {
          out(`${canonical(t)} ${formatValue(t, dataVals[di++])}`);
        }
      }
      return;
    }
    die('Invalid command');
  } catch (e) {
    die(e.message || String(e));
  }
}

main(process.argv.slice(2));
