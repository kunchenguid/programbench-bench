#!/usr/bin/env node
"use strict";

const fs = require("fs");

const HELP = `ov is a feature rich pager(such as more/less).
It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).

Usage:
  ov [flags] [FILE]...

Flags:
Short   Long                                    Purpose
  -l, --align                                   align the output columns for better readability
  -C, --alternate-rows                          alternately change the line color
      --caption string                          custom caption
  -i, --case-sensitive                          case-sensitive in search
  -d, --column-delimiter character              column delimiter character (default ",")
  -c, --column-mode                             column mode
      --column-rainbow                          column mode to rainbow
      --column-width                            column mode for width
      --completion string                       generate completion script [bash|zsh|fish|powershell]
      --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)
      --converter string                        converter [es|raw|align] (default "es")
      --debug                                   debug mode
      --disable-column-cycle                    disable column cycling
      --disable-mouse                           disable mouse support
  -e, --exec                                    command execution result instead of file
  -X, --exit-write                              output the current screen when exiting
  -a, --exit-write-after int                    number after the current lines when exiting
  -b, --exit-write-before int                   number before the current lines when exiting
      --filter string                           filter search pattern
  -A, --follow-all                              follow multiple files and show the most recently updated one
  -f, --follow-mode                             monitor file and display new content as it is written
      --follow-name                             follow mode to monitor by file name
      --follow-section                          section-by-section follow mode
      --force-screen                            display screen even when redirecting output
  -H, --header int                              number of header lines to be displayed constantly
  -Y, --header-column int                       number of columns to display as a vertical header
  -h, --help                                    help for ov
      --help-key                                display key bind information
      --hide-other-section                      hide other section
      --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default "10%")
      --incsearch[=true|false]                  incremental search (default true)
  -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']
  -n, --line-number                             line number mode
      --list-view-modes                         list available view modes defined in the configuration file
      --memory-limit int                        number of chunks to limit in memory (default -1)
      --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)
  -M, --multi-color strings                     comma separated words(regexp) to color .e.g. "ERROR,WARNING"
      --non-match-filter string                 filter non match search pattern
      --notify-eof int                          notify at the end of the file
      --pattern string                          search pattern
  -p, --plain                                   disable original decoration
  -F, --quit-if-one-screen                      quit if the output fits on one screen
  -r, --raw                                     raw escape sequences without processing
      --regexp-search                           regular expression search
      --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)
      --section-delimiter regexp                regexp for section delimiter .e.g. "^#"
      --section-header                          enable section-delimiter line as Header
      --section-header-num int                  number of section header lines (default 1)
      --section-start int                       section start position
      --set-terminal-title                      set terminal title
      --skip-extract                            skip extracting compressed files
      --skip-lines int                          skip the number of lines
      --smart-case-sensitive                    smart case-sensitive in search
      --status-line[=true|false]                status line (default true)
  -x, --tab-width int                           tab stop width (default 8)
  -v, --version                                 display version information
  -y, --vertical-header int                     number of characters to display as a vertical header
  -m, --view-mode string                        apply predefined settings for a specific mode
  -T, --watch seconds                           watch mode interval(seconds)
  -w, --wrap[=true|false]                       wrap mode (default true)
`;

const HELP_KEY = `ov is a feature rich pager
 Key                            Action

\tGeneral
 [Escape], [q]                  * quit
 [ctrl+c]                       * cancel
 [Q]                            * output screen and quit
 [ctrl+q]                       * set output screen and quit
 [alt+shift+F8]                 * set output original screen and quit
 [ctrl+z]                       * suspend
 [alt+v]                        * edit current document
 [h], [ctrl+F1], [ctrl+alt+c]   * display help screen
 [ctrl+F2], [ctrl+alt+e]        * display log screen
 [ctrl+l]                       * screen sync
 [ctrl+f]                       * follow mode toggle
 [ctrl+a]                       * follow all mode toggle
 [ctrl+F8], [ctrl+alt+r]        * enable/disable mouse
 [S]                            * save buffer to file

\tMoving
 [Enter], [Down], [ctrl+n]      * forward by one line
 [Up], [ctrl+p]                 * backward by one line
 [Home]                         * go to top of document
 [End]                          * go to end of document
 [PageDown], [ctrl+v]           * forward by page
 [PageUp], [ctrl+b]             * backward by page
 [ctrl+d]                       * forward a half page
 [ctrl+u]                       * backward a half page
 [left]                         * scroll left
 [right]                        * scroll right
 [ctrl+left]                    * scroll left half screen
 [ctrl+right]                   * scroll right half screen
 [alt+left]                     * scroll left specified width
 [alt+right]                    * scroll right specified width
 [shift+Home]                   * go to beginning of line
 [shift+End]                    * go to end of line
 [g]                            * go to line(input number or \`.n\` or \`n%\` allowed)
 [,]                            * go to mark number(input number allowed)

\tSidebar
 [alt+h]                        * show/hide help in sidebar
 [alt+m]                        * show mark list in sidebar
 [alt+l]                        * show document list in sidebar
 [shift+Up]                     * scroll up in sidebar
 [shift+Down]                   * scroll down in sidebar
 [shift+Left]                   * scroll left in sidebar
 [shift+Right]                  * scroll right in sidebar

\tMove document
 []]                            * next document
 [[]                            * previous document
 [ctrl+k]                       * close current document
 [K]                            * close all filtered documents

\tMark position
 [m]                            * mark current position
 [M]                            * remove mark current position
 [ctrl+delete]                  * remove all mark
 [>]                            * move to next marked position
 [<]                            * move to previous marked position
 [*]                            * mark by pattern mode

\tSearch
 [/]                            * forward search mode
 [?]                            * backward search mode
 [n]                            * repeat forward search
 [N]                            * repeat backward search
 [&]                            * filter search mode

\tChange display
 [w], [W]                       * wrap/nowrap toggle
 [c]                            * column mode toggle
 [alt+o]                        * column width toggle
 [ctrl+r]                       * column rainbow toggle
 [C]                            * alternate rows of style toggle
 [G]                            * line number toggle
 [ctrl+e]                       * original decoration toggle(plain)
 [alt+f]                        * align columns
 [alt+r]                        * raw output
 [alt+shift+F9]                 * ruler toggle
 [ctrl+F10]                     * status line toggle

\tChange Display with Input
 [p], [P]                       * view mode selection
 [d]                            * column delimiter string
 [H]                            * number of header lines
 [ctrl+s]                       * number of skip lines
 [t]                            * TAB width
 [.]                            * multi color highlight
 [j]                            * jump target(\`.n\` or \`n%\` or \`section\` allowed)
 [alt+t]                        * convert type selection
 [y]                            * number of vertical header
 [Y]                            * number of header column

\tColumn operation
 [F]                            * header column fixed toggle
 [s]                            * shrink column toggle(align mode only)
 [alt+a]                        * right align column toggle(align mode only)

\tSection operation
 [alt+d]                        * section delimiter regular expression
 [ctrl+F3], [alt+s]             * section start position
 [space]                        * next section
 [^]                            * previous section
 [9]                            * last section
 [F2]                           * follow section mode toggle
 [F7]                           * number of section header lines
 [alt+-]                        * hide "other" section toggle

\tClose and reload
 [ctrl+F9], [ctrl+alt+s]        * close file
 [F5], [ctrl+alt+l]             * reload file
 [F4], [ctrl+alt+w]             * watch mode
 [ctrl+w]                       * set watch interval

\tKey binding when typing
 [alt+c]                        * case-sensitive toggle
 [alt+s]                        * smart case-sensitive toggle
 [alt+r]                        * regular expression search toggle
 [alt+i]                        * incremental search toggle
 [!]                            * non-match toggle
 [Up]                           * previous candidate
 [Down]                         * next candidate
 [ctrl+c]                       * copy to clipboard
 [ctrl+v]                       * paste from clipboard

`;

const BOOL_LONG = new Set([
  "align", "alternate-rows", "case-sensitive", "column-mode", "column-rainbow",
  "column-width", "debug", "disable-column-cycle", "disable-mouse", "exec",
  "exit-write", "follow-all", "follow-mode", "follow-name", "follow-section",
  "force-screen", "help", "help-key", "hide-other-section", "line-number",
  "list-view-modes", "plain", "quit-if-one-screen", "raw", "regexp-search",
  "section-header", "set-terminal-title", "skip-extract",
  "smart-case-sensitive", "version"
]);

const VALUE_LONG = new Set([
  "caption", "column-delimiter", "completion", "config", "converter",
  "exit-write-after", "exit-write-before", "filter", "header",
  "header-column", "hscroll-width", "jump-target", "memory-limit",
  "memory-limit-file", "multi-color", "non-match-filter", "notify-eof",
  "pattern", "ruler", "section-delimiter", "section-header-num",
  "section-start", "skip-lines", "tab-width", "vertical-header", "view-mode",
  "watch"
]);

const OPTIONAL_BOOL_LONG = new Set(["incsearch", "status-line", "wrap"]);
const SHORT_BOOL = new Set(["l", "C", "i", "c", "e", "X", "A", "f", "h", "n", "p", "F", "r", "v", "w"]);
const SHORT_VALUE = new Set(["d", "a", "b", "H", "Y", "j", "M", "x", "y", "m", "T"]);

function write(s) {
  process.stdout.write(s);
}

function fail(msg) {
  process.stderr.write(`Error: ${msg}\n`);
  process.exit(1);
}

function completion(shell) {
  if (!["bash", "zsh", "fish", "powershell"].includes(shell)) {
    fail("requires one of the arguments bash/zsh/fish/powershell");
  }
  if (shell === "zsh") {
    return `#compdef ov\ncompdef _ov ov\n\n# zsh completion for ov                                   -*- shell-script -*-\n`;
  }
  return `# ${shell} completion for ov                                   -*- shell-script -*-\n`;
}

function parse(argv) {
  const files = [];
  const opts = Object.create(null);
  for (let i = 0; i < argv.length; i++) {
    let arg = argv[i];
    if (arg === "--") {
      files.push(...argv.slice(i + 1));
      break;
    }
    if (arg.startsWith("--") && arg.length > 2) {
      let name = arg.slice(2);
      let value = null;
      const eq = name.indexOf("=");
      if (eq !== -1) {
        value = name.slice(eq + 1);
        name = name.slice(0, eq);
      }
      if (BOOL_LONG.has(name)) {
        if (value !== null && value === "false") {
          continue;
        }
        opts[name] = value === null ? true : value;
        continue;
      }
      if (OPTIONAL_BOOL_LONG.has(name)) {
        opts[name] = value === null ? true : value;
        continue;
      }
      if (VALUE_LONG.has(name)) {
        if (value === null) {
          if (i + 1 >= argv.length) fail(`flag needs an argument: --${name}`);
          value = argv[++i];
        }
        opts[name] = value;
        continue;
      }
      fail(`unknown flag: --${name}`);
    }
    if (arg.startsWith("-") && arg.length > 1) {
      const chars = arg.slice(1);
      if (chars.length > 1 && !SHORT_VALUE.has(chars[0])) {
        for (const ch of chars) {
          if (!SHORT_BOOL.has(ch)) fail(`unknown shorthand flag: '${ch}' in -${ch}`);
          opts[shortName(ch)] = true;
        }
        continue;
      }
      const ch = chars[0];
      if (SHORT_BOOL.has(ch)) {
        opts[shortName(ch)] = true;
        if (chars.length > 1) files.push(chars.slice(1));
        continue;
      }
      if (SHORT_VALUE.has(ch)) {
        let value = chars.length > 1 ? chars.slice(1) : null;
        if (value === null) {
          if (i + 1 >= argv.length) fail(`flag needs an argument: -${ch}`);
          value = argv[++i];
        }
        opts[shortName(ch)] = value;
        continue;
      }
      fail(`unknown shorthand flag: '${ch}' in -${ch}`);
    }
    files.push(arg);
  }
  return { opts, files };
}

function shortName(ch) {
  return {
    l: "align", C: "alternate-rows", i: "case-sensitive", d: "column-delimiter",
    c: "column-mode", e: "exec", X: "exit-write", a: "exit-write-after",
    b: "exit-write-before", A: "follow-all", f: "follow-mode", H: "header",
    Y: "header-column", h: "help", j: "jump-target", n: "line-number",
    M: "multi-color", p: "plain", F: "quit-if-one-screen", r: "raw",
    x: "tab-width", v: "version", y: "vertical-header", m: "view-mode",
    T: "watch", w: "wrap"
  }[ch] || ch;
}

function main() {
  const { opts, files } = parse(process.argv.slice(2));
  if (opts.help) return write(HELP);
  if (opts.version) return write("ov version dev rev:HEAD\n");
  if (opts["help-key"]) return write(HELP_KEY);
  if (opts["list-view-modes"]) return write("general\n");
  if (Object.prototype.hasOwnProperty.call(opts, "completion")) {
    return write(completion(opts.completion));
  }

  if (files.length > 0) {
    const file = files[0];
    try {
      const data = fs.readFileSync(file);
      process.stdout.write(data);
    } catch (err) {
      process.stderr.write(`Error: open ${file}: no such file or directory\n`);
      process.exit(1);
    }
    return;
  }

  try {
    const data = fs.readFileSync(0);
    process.stdout.write(data);
  } catch (_) {
    return;
  }
}

main();
