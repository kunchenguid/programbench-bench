#!/usr/bin/env node
"use strict";

const fs = require("fs");

const HELP = `Usage: executable [OPTIONS]

Options:
  -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]
  -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]
  -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]
  -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]
  -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]
  -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]
      --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
      --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
      --show-ortho        show keyboard in ortholinear format
      --nokb              pass this flag to disable the keyboard layout display.
      --cat               the most important flag. don't practice alone.
  -h, --help              Print help
`;

const VALUE_META = {
  n: "<2|3|4|w|file>",
  top: "<1-200>",
  combi: "<1-200>",
  rep: "<number>",
  wpm: "<number>",
  acc: "<0-100>",
  "emu-in": "<layout>",
  "emu-out": "<layout>",
};

const LONG_TO_KEY = {
  "--n": "n",
  "--top": "top",
  "--combi": "combi",
  "--rep": "rep",
  "--wpm": "wpm",
  "--acc": "acc",
  "--emu-in": "emuIn",
  "--emu-out": "emuOut",
};

const SHORT_TO_LONG = {
  "-n": "--n",
  "-t": "--top",
  "-c": "--combi",
  "-r": "--rep",
  "-w": "--wpm",
  "-a": "--acc",
};

const BIGRAMS = "th he in er an re on at en nd ti es or te of ed is it al ar st to nt ng se ha as ou io le ve co me de hi ri ro ic ne ea ra ce li ch ll be ma si om ur".split(" ");
const TRIGRAMS = "the and ing ion tio ent ati for her ter hat tha ere ate his con res ver all ons nce men ith ted ers pro thi wit are ess not ive was ect rea com eve per int est sta cti ica ist ear ain one our".split(" ");
const TETRAGRAMS = "tion ther with here ould ight have hich whic this thin they atio ever from ough were hing ment ions that ther over ding pres nter comp able heth ines cons ally ater ally comm ence tive".split(" ");
const WORDS = "the of and to in a is that for it as was with be by on not he i this are or his from at which but have an they you were all we can her has there been if more when will would who so no out up what about into than them could only other new some time these two may then do first any my now such like our over man me even most made after also did many before must through back years where much your way well down should because each just those people mr how too little state good very make world still own see men work long get here between both life being under never day same another know while last might us great old year off come since against go came right used take three".split(" ");

function clapError(message) {
  process.stderr.write(`error: ${message}\n\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function unexpected(arg) {
  process.stderr.write(`error: unexpected argument '${arg}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function needValue(flag, meta) {
  process.stderr.write(`error: a value is required for '${flag} ${meta}' but none was supplied\n\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function parseNumber(value, flag, meta) {
  if (!/^[0-9]+$/.test(value)) {
    clapError(`invalid value '${value}' for '${flag} ${meta}': invalid digit found in string`);
  }
  return Number(value);
}

function parseArgs(argv) {
  const opts = { n: "2", top: 50, combi: 2, rep: 3, wpm: 40, acc: 94, emuIn: "", emuOut: "", showOrtho: false, nokb: false, cat: false };
  for (let i = 0; i < argv.length; i++) {
    let arg = argv[i];
    if (arg === "-h" || arg === "--help") {
      process.stdout.write(HELP);
      process.exit(0);
    }
    if (arg === "--show-ortho") { opts.showOrtho = true; continue; }
    if (arg === "--nokb") { opts.nokb = true; continue; }
    if (arg === "--cat") { opts.cat = true; continue; }

    let value = null;
    if (arg.startsWith("--") && arg.includes("=")) {
      const parts = arg.split(/=(.*)/s);
      arg = parts[0];
      value = parts[1];
    } else if (/^-[ntcrwa][^\s]+/.test(arg) && !SHORT_TO_LONG[arg]) {
      const f = arg.slice(0, 2);
      value = arg.slice(2);
      arg = f;
    }
    if (SHORT_TO_LONG[arg]) arg = SHORT_TO_LONG[arg];
    if (LONG_TO_KEY[arg]) {
      const name = arg.slice(2);
      if (value === null) {
        if (i + 1 >= argv.length) needValue(arg, VALUE_META[name]);
        if (argv[i + 1].startsWith("-")) unexpected(argv[i + 1]);
        value = argv[++i];
      }
      const key = LONG_TO_KEY[arg];
      if (["top", "combi", "rep", "wpm", "acc"].includes(key)) {
        opts[key] = parseNumber(value, arg, VALUE_META[name]);
      } else {
        opts[key] = value;
      }
      continue;
    }
    unexpected(arg);
  }
  return opts;
}

function validate(opts) {
  if (opts.top < 1 || opts.top > 200) die("Invalid argument for top. Use a number between 1 and 200.");
  if (opts.combi < 1 || opts.combi > 200) die("Invalid argument for combi. Use a number between 1 and 200.");
  if (opts.acc < 0 || opts.acc > 100) die("Invalid argument for acc. Use a number between 0 and 100.");
  if ((opts.emuIn && !opts.emuOut) || (!opts.emuIn && opts.emuOut)) die("You need to specify both emu_in and emu_out.");
}

function die(msg) {
  process.stderr.write(msg + "\n");
  process.exit(1);
}

function loadPool(n) {
  if (n === "2") return BIGRAMS;
  if (n === "3") return TRIGRAMS;
  if (n === "4") return TETRAGRAMS;
  if (n === "w") return WORDS;
  if (!fs.existsSync(n)) die(`File not found: ${n}`);
  const body = fs.readFileSync(n, "utf8");
  return body.split(/[,\n\r\t ]+/).map(s => s.trim()).filter(Boolean);
}

function shuffle(a) {
  const out = a.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

function makeLesson(pool, opts) {
  const candidates = pool.slice(0, Math.min(opts.top, pool.length || 1));
  const chosen = [];
  for (let i = 0; i < opts.combi; i++) chosen.push(candidates[Math.floor(Math.random() * candidates.length)] || "");
  const lesson = [];
  for (const item of chosen) for (let r = 0; r < opts.rep; r++) lesson.push(item);
  return shuffle(lesson).join(" ");
}

const LAYOUTS = {
  qwerty: ["qwertyuiop", "asdfghjkl", "zxcvbnm"],
  qwertz: ["qwertzuiop", "asdfghjkl", "yxcvbnm"],
  azerty: ["azertyuiop", "qsdfghjklm", "wxcvbn"],
  dvorak: ["',.pyfgcrl", "aoeuidhtns", ";qjkxbmwvz"],
  colemak: ["qwfpgjluy", "arstdhneio", "zxcvbkm"],
  colemakdh: ["qwfpbjluy", "arstgmneio", "zxcdvkh"],
};

function keyboard(layout, ortho) {
  const rows = LAYOUTS[layout] || LAYOUTS.qwerty;
  if (ortho) return rows.map(r => r.split("").map(c => `[${c}]`).join(" ")).join("\n");
  return rows.map((r, i) => " ".repeat(i * 2) + r.split("").map(c => `[${c}]`).join(" ")).join("\n");
}

function draw(state) {
  const { opts, target, typed, pool, done, message } = state;
  const correct = [...typed].filter((c, i) => c === target[i]).length;
  const acc = typed.length ? Math.floor((correct / typed.length) * 100) : 100;
  const elapsed = state.started ? Math.max(0.001, (Date.now() - state.started) / 60000) : 0;
  const wpm = state.started ? Math.floor((typed.length / 5) / elapsed) : 0;
  const displayTarget = target.split("").map((c, i) => {
    if (i >= typed.length) return c;
    return typed[i] === c ? `\x1b[32m${c}\x1b[0m` : `\x1b[31m${c}\x1b[0m`;
  }).join("");
  process.stdout.write("\x1b[2J\x1b[H\x1b[?25l");
  process.stdout.write("ngrrram\n\n");
  if (opts.cat) process.stdout.write(" /\\_/\\\\\n( o.o )\n > ^ <\n\n");
  process.stdout.write(displayTarget + "\n\n");
  process.stdout.write(typed + "\n\n");
  process.stdout.write(`wpm: ${wpm}/${opts.wpm}   acc: ${acc}/${opts.acc}%   ngrams: ${pool.length}\n`);
  if (!opts.nokb) process.stdout.write("\n" + keyboard(opts.emuOut || "qwerty", opts.showOrtho) + "\n");
  if (message) process.stdout.write("\n" + message + "\n");
  if (done) process.stdout.write("\nPress q or Ctrl-C to quit, space/enter for another lesson.\n");
}

function runTui(opts, pool) {
  if (!process.stdin.isTTY) {
    process.stderr.write('\x1b[?1049hError: Os { code: 6, kind: Uncategorized, message: "No such device or address" }\n');
    process.exit(1);
  }
  process.stdout.write("\x1b[?1049h");
  process.stdin.setRawMode(true);
  process.stdin.resume();
  process.stdin.setEncoding("utf8");
  const state = { opts, pool, target: makeLesson(pool, opts), typed: "", started: 0, done: false, message: "" };
  const cleanup = (code = 0) => {
    try { process.stdin.setRawMode(false); } catch (_) {}
    process.stdout.write("\x1b[?25h\x1b[?1049l");
    process.exit(code);
  };
  process.on("SIGINT", () => cleanup(0));
  process.stdin.on("data", ch => {
    if (ch === "\u0003" || ch === "q" && state.done) cleanup(0);
    if (state.done && (ch === " " || ch === "\r" || ch === "\n")) {
      state.target = makeLesson(pool, opts);
      state.typed = "";
      state.started = 0;
      state.done = false;
      state.message = "";
      draw(state);
      return;
    }
    if (state.done) return;
    if (ch === "\u007f" || ch === "\b") {
      state.typed = state.typed.slice(0, -1);
    } else if (ch.length === 1 && ch >= " " && ch <= "~") {
      if (!state.started) state.started = Date.now();
      state.typed += ch;
    }
    if (state.typed.length >= state.target.length) {
      const correct = [...state.typed].filter((c, i) => c === state.target[i]).length;
      const acc = Math.floor((correct / state.typed.length) * 100);
      const elapsed = Math.max(0.001, (Date.now() - state.started) / 60000);
      const wpm = Math.floor((state.typed.length / 5) / elapsed);
      state.done = true;
      state.message = (wpm >= opts.wpm && acc >= opts.acc) ? "Success!" : "Try again.";
    }
    draw(state);
  });
  draw(state);
}

const opts = parseArgs(process.argv.slice(2));
validate(opts);
const pool = loadPool(opts.n);
runTui(opts, pool);
