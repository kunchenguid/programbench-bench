#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "srgn 0.14.1";

function printHelp(long = false) {
  const msg = long ? `A grep-like tool which understands source code syntax and allows for manipulation in
addition to search

Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]

Arguments:
  [SCOPE]
          Scope to apply to, as a regular expression pattern.

          [default: .*]

Options:
      --completions <SHELL>  Print shell completions for the given shell.
  -h, --help                 Print help (see a summary with '-h')
  -V, --version              Print version

Composable Actions:
  -u, --upper        Uppercase anything in scope.
  -l, --lower        Lowercase anything in scope.
  -t, --titlecase    Titlecase anything in scope.
  -n, --normalize    Normalize anything in scope, and throw away marks.
  -g, --german       Perform substitutions on German words.
  -S, --symbols      Perform substitutions on symbols, such as '!=' to '≠', '->' to '→'.
  [REPLACEMENT]      Replace anything in scope with this value.

Standalone Actions (only usable alone):
  -d, --delete       Delete anything in scope.
  -s, --squeeze      Squeeze consecutive occurrences of scope into one.

Options (global):
  -G, --glob <GLOB>  Glob of files to work on (instead of reading stdin).
  -i, --invert       Undo the effects of passed actions, where applicable.
  -L, --literal-string
      --fail-any
      --fail-none
      --dry-run
      --fail-no-files
      --only-matching
      --line-numbers
      --count

Language scopes:
      --python <PYTHON>      Scope Python code using a prepared query.
      --rust <RUST>          Scope Rust code using a prepared query.
      --go <GO>              Scope Go code using a prepared query.
      --typescript <TS>      Scope TypeScript code using a prepared query.
      --c <C>                Scope C code using a prepared query.
      --csharp <CSHARP>      Scope C# code using a prepared query.
      --hcl <HCL>            Scope HCL code using a prepared query.
` : `A grep-like tool which understands source code syntax and allows for manipulation in
addition to search

Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]

Arguments:
  [SCOPE]  Scope to apply to, as a regular expression pattern. [default: .*]

Options:
      --completions <SHELL>  Print shell completions for the given shell.
  -h, --help                 Print help (see more with '--help')
  -V, --version              Print version

Composable Actions:
  -u, --upper        Uppercase anything in scope.
  -l, --lower        Lowercase anything in scope.
  -t, --titlecase    Titlecase anything in scope.
  -n, --normalize    Normalize anything in scope.
  -g, --german       Perform substitutions on German words.
  -S, --symbols      Perform substitutions on symbols.
  [REPLACEMENT]      Replace anything in scope with this value.

Standalone Actions (only usable alone):
  -d, --delete       Delete anything in scope.
  -s, --squeeze      Squeeze consecutive occurrences of scope into one.
`;
  process.stdout.write(msg);
}

function die(msg, code = 2) {
  process.stderr.write(msg + "\n");
  process.exit(code);
}

function parseArgs(argv) {
  const o = {
    actions: [], standalone: null, invert: false, literal: false, glob: null,
    failAny: false, failNone: false, failNoFiles: false, dryRun: false,
    onlyMatching: false, lineNumbers: false, count: false, sorted: false,
    files: false, filesWithMatches: false,
    hidden: false, germanNaive: false, germanPreferOriginal: false,
    langs: [], queries: [], positional: [], replacement: undefined,
  };
  const needsValue = new Set(["--glob", "-G", "--stdin-detection", "--stdout-detection", "--threads",
    "--python", "--py", "--rust", "--rs", "--go", "--typescript", "--ts", "--c", "--csharp", "--cs", "--hcl",
    "--python-query", "--rust-query", "--go-query", "--typescript-query", "--c-query", "--csharp-query", "--hcl-query",
    "--python-query-file", "--rust-query-file", "--go-query-file", "--typescript-query-file", "--c-query-file", "--csharp-query-file", "--hcl-query-file",
    "--completions"]);
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === "--") {
      o.replacement = argv.slice(i + 1).join(" ");
      break;
    }
    if (a === "-h") { printHelp(false); process.exit(0); }
    if (a === "--help") { printHelp(true); process.exit(0); }
    if (a === "-V" || a === "--version") { console.log(VERSION); process.exit(0); }
    if (a === "--completions") {
      const sh = argv[++i] || "";
      console.log(completion(sh));
      process.exit(0);
    }
    if (needsValue.has(a)) {
      const val = argv[++i];
      if (val === undefined) die(`error: a value is required for '${a}' but none was supplied\n\nFor more information, try '--help'.`);
      storeValue(o, a, val);
      continue;
    }
    if (a.startsWith("--")) {
      if (a.startsWith("--glob=")) { o.glob = a.slice(7); continue; }
      if (a === "--upper") o.actions.push("upper");
      else if (a === "--lower") o.actions.push("lower");
      else if (a === "--titlecase") o.actions.push("titlecase");
      else if (a === "--normalize") o.actions.push("normalize");
      else if (a === "--german") o.actions.push("german");
      else if (a === "--symbols") o.actions.push("symbols");
      else if (a === "--delete") o.standalone = "delete";
      else if (a === "--squeeze" || a === "--squeeze-repeats") o.standalone = "squeeze";
      else if (a === "--invert") o.invert = true;
      else if (a === "--literal-string") o.literal = true;
      else if (a === "--fail-any") o.failAny = true;
      else if (a === "--fail-none") o.failNone = true;
      else if (a === "--fail-no-files") o.failNoFiles = true;
      else if (a === "--dry-run") o.dryRun = true;
      else if (a === "--only-matching") o.onlyMatching = true;
      else if (a === "--line-numbers") o.lineNumbers = true;
      else if (a === "--count") o.count = true;
      else if (a === "--files") o.files = true;
      else if (a === "--files-with-matches") o.filesWithMatches = true;
      else if (a === "--sorted") o.sorted = true;
      else if (a === "--hidden") o.hidden = true;
      else if (a === "--gitignored" || a === "--join-language-scopes") {}
      else if (a === "--german-naive") o.germanNaive = true;
      else if (a === "--german-prefer-original") o.germanPreferOriginal = true;
      else die(`error: unexpected argument '${a}' found\n\nFor more information, try '--help'.`);
      continue;
    }
    if (a.startsWith("-") && a.length > 1) {
      if (a === "-G") { o.glob = argv[++i]; continue; }
      for (let j = 1; j < a.length; j++) {
        const c = a[j];
        if (c === "u") o.actions.push("upper");
        else if (c === "l") o.actions.push("lower");
        else if (c === "t") o.actions.push("titlecase");
        else if (c === "n") o.actions.push("normalize");
        else if (c === "g") o.actions.push("german");
        else if (c === "S") o.actions.push("symbols");
        else if (c === "d") o.standalone = "delete";
        else if (c === "s") o.standalone = "squeeze";
        else if (c === "i") o.invert = true;
        else if (c === "L") o.literal = true;
        else if (c === "H" || c === "j" || c === "v") {}
        else die(`error: unexpected argument '-${c}' found\n\nFor more information, try '--help'.`);
      }
      continue;
    }
    o.positional.push(a);
  }
  if (process.env.UPPER) o.actions.push("upper");
  if (process.env.LOWER) o.actions.push("lower");
  if (process.env.TITLECASE) o.actions.push("titlecase");
  if (process.env.NORMALIZE) o.actions.push("normalize");
  if (process.env.REPLACE && o.replacement === undefined) o.replacement = process.env.REPLACE;
  if (process.env.SQUEEZE) o.standalone = "squeeze";
  if (process.env.INVERT) o.invert = true;
  if (process.env.LITERAL_STRING) o.literal = true;
  o.scope = o.positional[0] ?? ".*";
  if ((o.standalone === "delete" || o.standalone === "squeeze") && o.positional.length === 0) {
    die(`error: the following required arguments were not provided:\n  <SCOPE>\n\nUsage: executable --${o.standalone} <SCOPE> [-- <REPLACEMENT>]\n\nFor more information, try '--help'.`);
  }
  if (o.standalone && (o.replacement !== undefined || o.actions.length)) {
    die(`error: the argument '--${o.standalone}' cannot be used with other actions\n\nFor more information, try '--help'.`);
  }
  return o;
}

function storeValue(o, key, val) {
  if (key === "-G" || key === "--glob") o.glob = val;
  else if (key === "--completions") {}
  else if (["--stdin-detection", "--stdout-detection", "--threads"].includes(key)) {}
  else if (key.includes("query")) o.queries.push({ key, val });
  else o.langs.push({ lang: key.replace(/^--?/, ""), value: val });
}

function completion(shell) {
  if (shell === "bash") return `_srgn() {\n    COMPREPLY=()\n}\ncomplete -F _srgn srgn`;
  if (shell === "fish") return "complete -c srgn -s h -l help";
  if (shell === "zsh") return "#compdef srgn\n_arguments '*::arg:_files'";
  return "";
}

function makeRegex(scope, literal = false) {
  const pat = literal ? escapeRegExp(scope) : scope;
  try { return new RegExp(pat, "gmu"); }
  catch (e) { die(`Error: ${e.message}`, 1); }
}

function escapeRegExp(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

function collectMatches(text, re) {
  const out = [];
  re.lastIndex = 0;
  let m;
  while ((m = re.exec(text)) !== null) {
    out.push({ start: m.index, end: m.index + m[0].length, text: m[0], match: m });
    if (m[0].length === 0) re.lastIndex++;
  }
  return out;
}

function replaceScoped(text, re, fn) {
  return text.replace(re, (...args) => {
    const whole = args[0];
    if (whole.length === 0) return whole;
    return fn(whole, args);
  });
}

function applyReplacement(template, args) {
  const whole = args[0];
  const offset = args[args.length - 3];
  const input = args[args.length - 2];
  const hasGroups = typeof args[args.length - 1] === "object";
  const groups = hasGroups ? args[args.length - 1] : {};
  const caps = args.slice(1, hasGroups ? -3 : -2);
  return template.replace(/\$(\$|&|\d+|[A-Za-z_][A-Za-z0-9_]*)/g, (m, name) => {
    if (name === "$") return "$";
    if (name === "&") return whole;
    if (/^\d+$/.test(name)) return caps[Number(name) - 1] ?? "";
    return groups[name] ?? "";
  });
}

function transformOne(s, action, opts) {
  if (action === "upper") return s.toLocaleUpperCase();
  if (action === "lower") return s.toLocaleLowerCase();
  if (action === "titlecase") return s.replace(/\p{L}[\p{L}\p{M}'-]*/gu, w => w[0].toLocaleUpperCase() + w.slice(1).toLocaleLowerCase());
  if (action === "normalize") return s.normalize("NFD").replace(/\p{M}/gu, "");
  if (action === "symbols") return symbols(s, opts.invert);
  if (action === "german") return german(s, opts);
  return s;
}

function symbols(s, invert) {
  const pairs = [
    ["!=", "≠"], ["->", "→"], ["<-", "←"], [">=", "≥"], ["<=", "≤"],
    ["...", "…"], ["+-", "±"], ["*", "×"], ["/", "÷"],
  ];
  for (const [a, b] of pairs) s = s.split(invert ? b : a).join(invert ? a : b);
  return s;
}

function german(s, opts) {
  if (!opts.germanNaive) {
    const known = new Map([
      ["Bruecken", "Brücken"], ["bruecken", "brücken"], ["Gruesse", "Grüße"], ["gruesse", "grüße"],
      ["Abenteuergruesse", "Abenteuergrüße"], ["Kuesse", "Küsse"], ["Fuesse", "Füße"],
      ["Strasse", "Straße"], ["strasse", "straße"], ["Mass", "Maß"], ["mass", "maß"],
    ]);
    return s.replace(/\p{L}+/gu, w => known.get(w) || w);
  }
  return s.replace(/Ae/g, "Ä").replace(/Oe/g, "Ö").replace(/Ue/g, "Ü")
    .replace(/ae/g, "ä").replace(/oe/g, "ö").replace(/ue/g, "ü")
    .replace(/ss/g, "ß");
}

function lineInfo(text, start, end) {
  let line = 1, lastNl = -1;
  for (let i = 0; i < start; i++) if (text[i] === "\n") { line++; lastNl = i; }
  let lineEnd = text.indexOf("\n", start);
  if (lineEnd < 0) lineEnd = text.length;
  return { line, colStart: start - lastNl - 1, colEnd: end - lastNl - 1, lineText: text.slice(lastNl + 1, lineEnd) };
}

function searchOutput(text, matches, opts, file = "(stdin)") {
  if (opts.count) return String(matches.length) + "\n";
  if (matches.length === 0) return "";
  if (opts.onlyMatching) {
    if (opts.lineNumbers) {
      return matches.map(m => {
        const li = lineInfo(text, m.start, m.end);
        return `${file}:${li.line}:${li.colStart}-${li.colEnd}:${m.text}`;
      }).join("\n") + "\n";
    }
    const byLine = new Map();
    for (const m of matches) {
      const li = lineInfo(text, m.start, m.end);
      const key = li.line;
      if (!byLine.has(key)) byLine.set(key, { li, ranges: [] });
      byLine.get(key).ranges.push(`${li.colStart}-${li.colEnd}`);
    }
    return [...byLine.values()].map(({ li, ranges }) => `${file}:${ranges.join(";")}:${li.lineText}`).join("\n") + "\n";
  }
  const byLine = new Map();
  for (const m of matches) {
    const li = lineInfo(text, m.start, m.end);
    const key = li.line;
    if (!byLine.has(key)) byLine.set(key, { li, ranges: [] });
    byLine.get(key).ranges.push(`${li.colStart}-${li.colEnd}`);
  }
  return [...byLine.values()].map(({ li, ranges }) => {
    const loc = opts.lineNumbers ? `${file}:${li.line}:${ranges.join(";")}` : `${file}:${ranges.join(";")}`;
    return `${loc}:${li.lineText}`;
  }).join("\n") + "\n";
}

function rangesForLanguage(text, langs) {
  if (!langs.length) return [{ start: 0, end: text.length }];
  let ranges = [];
  for (const { lang, value } of langs) ranges.push(...languageRanges(text, lang, value));
  if (!ranges.length) return [];
  ranges.sort((a, b) => a.start - b.start || b.end - a.end);
  const merged = [];
  for (const r of ranges) {
    const last = merged[merged.length - 1];
    if (last && r.start <= last.end) last.end = Math.max(last.end, r.end);
    else merged.push({ ...r });
  }
  return merged;
}

function languageRanges(text, lang, value) {
  const v = value.split("~")[0];
  if (lang === "python" || lang === "py") return pythonRanges(text, v);
  if (lang === "rust" || lang === "rs") return genericRanges(text, v, "rust");
  if (lang === "go") return genericRanges(text, v, "go");
  if (lang === "typescript" || lang === "ts") return genericRanges(text, v, "ts");
  if (lang === "c" || lang === "csharp" || lang === "cs") return genericRanges(text, v, "c");
  if (lang === "hcl") return genericRanges(text, v, "hcl");
  return [{ start: 0, end: text.length }];
}

function pythonRanges(text, v) {
  const ranges = [];
  if (v === "comments") return regexRanges(text, /#[^\n]*/g);
  if (v === "strings" || v === "doc-strings") return regexRanges(text, /("""[\s\S]*?"""|'''[\s\S]*?'''|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')/g);
  if (v === "imports") return regexRanges(text, /^\s*(?:from\s+[\w.]+\s+import\s+[\w.*, ]+|import\s+[\w., ]+)/gm);
  if (v === "function-names") return regexRanges(text, /(?<=^\s*def\s+)[A-Za-z_][A-Za-z0-9_]*/gm);
  if (v === "function-calls") return regexRanges(text, /\b[A-Za-z_][A-Za-z0-9_]*(?=\s*\()/g);
  if (v === "identifiers" || v === "variable-identifiers" || v === "types") return regexRanges(text, /\b[A-Za-z_][A-Za-z0-9_]*\b/g);
  if (v === "class") return indentBlocks(text, /^\s*class\s+/);
  if (["def", "async-def", "methods", "class-methods", "static-methods"].includes(v)) return indentBlocks(text, /^\s*(?:async\s+)?def\s+/);
  if (["with", "try"].includes(v)) return indentBlocks(text, new RegExp("^\\s*" + v + "\\b"));
  if (v === "lambda") return regexRanges(text, /lambda\b[^\n]*/g);
  if (v === "globals") return regexRanges(text, /^[A-Za-z_][A-Za-z0-9_]*\s*=/gm);
  return [{ start: 0, end: text.length }];
}

function genericRanges(text, v, lang) {
  if (v.includes("comment")) return regexRanges(text, /\/\/[^\n]*|#[^\n]*|\/\*[\s\S]*?\*\//g);
  if (v.includes("string")) return regexRanges(text, /`[\s\S]*?`|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g);
  if (["imports", "uses", "includes", "usings"].includes(v)) return regexRanges(text, /^\s*(?:use|import|using|#include)\b[^\n]*/gm);
  if (v.includes("identifier") || v === "function" || v === "function-def" || v === "call-expression") return regexRanges(text, /\b[A-Za-z_][A-Za-z0-9_]*\b/g);
  const kw = {
    "struct": "\\bstruct\\b", "enum": "\\benum\\b", "class": "\\bclass\\b", "interface": "\\binterface\\b",
    "fn": "\\bfn\\b", "func": "\\bfunc\\b", "method": "\\bfunc\\b|\\bfn\\b", "trait": "\\btrait\\b",
    "impl": "\\bimpl\\b", "mod": "\\bmod\\b", "type-def": "\\b(?:type|struct|enum|union)\\b",
    "const": "\\bconst\\b", "var": "\\bvar\\b", "let": "\\blet\\b", "type-alias": "\\btype\\b",
    "resource": "\\bresource\\b", "variable": "\\bvariable\\b", "data": "\\bdata\\b", "output": "\\boutput\\b",
    "provider": "\\bprovider\\b", "module": "\\bmodule\\b", "locals": "\\blocals\\b", "terraform": "\\bterraform\\b",
  }[v.replace(/^(pub|priv|async|unsafe|extern|const|free|init|sync)-/, "")];
  if (kw) return braceOrLineBlocks(text, new RegExp(kw));
  return [{ start: 0, end: text.length }];
}

function regexRanges(text, re) {
  const out = [];
  let m; re.lastIndex = 0;
  while ((m = re.exec(text)) !== null) { out.push({ start: m.index, end: m.index + m[0].length }); if (!m[0]) re.lastIndex++; }
  return out;
}

function indentBlocks(text, headerRe) {
  const ranges = [], lines = text.match(/^.*(?:\n|$)/gm) || [];
  let pos = 0;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i], start = pos, indent = (line.match(/^\s*/) || [""])[0].length;
    if (headerRe.test(line)) {
      let end = start + line.length, jpos = end;
      for (let j = i + 1; j < lines.length; j++) {
        const l = lines[j], blank = /^\s*$/.test(l), ind = (l.match(/^\s*/) || [""])[0].length;
        if (!blank && ind <= indent) break;
        end = jpos + l.length; jpos += l.length;
      }
      ranges.push({ start, end });
    }
    pos += line.length;
  }
  return ranges;
}

function braceOrLineBlocks(text, re) {
  const ranges = [];
  let m; re.lastIndex = 0;
  while ((m = re.exec(text)) !== null) {
    const s = m.index;
    const brace = text.indexOf("{", s);
    const nl = text.indexOf("\n", s);
    if (brace >= 0 && (nl < 0 || brace < nl + 120)) {
      let depth = 0, e = brace;
      for (; e < text.length; e++) {
        if (text[e] === "{") depth++;
        else if (text[e] === "}" && --depth === 0) { e++; break; }
      }
      ranges.push({ start: s, end: e });
    } else {
      ranges.push({ start: s, end: nl < 0 ? text.length : nl });
    }
  }
  return ranges;
}

function filterMatchesByRanges(matches, ranges) {
  return matches.filter(m => ranges.some(r => m.start >= r.start && m.end <= r.end));
}

function processText(text, opts, file = "(stdin)") {
  const re = makeRegex(opts.scope, opts.literal);
  const langRanges = rangesForLanguage(text, opts.langs);
  const allMatches = filterMatchesByRanges(collectMatches(text, re), langRanges);
  if (opts.failAny && allMatches.length) throw new Error("Some input was in scope");
  if (opts.failNone && !allMatches.length) throw new Error("No input was in scope");
  if (opts.standalone === "delete") return { output: replaceScopedInRanges(text, re, langRanges, () => ""), changed: allMatches.length > 0, matches: allMatches };
  if (opts.standalone === "squeeze") {
    const sq = makeRegex(`(?:${opts.literal ? escapeRegExp(opts.scope) : opts.scope})+`, false);
    return { output: replaceScopedInRanges(text, sq, langRanges, x => {
      const m = makeRegex(opts.scope, opts.literal).exec(x);
      return m ? m[0] : x;
    }), changed: allMatches.length > 0, matches: allMatches };
  }
  const hasActions = opts.replacement !== undefined || opts.actions.length > 0;
  if (!hasActions) {
    if (opts.onlyMatching || opts.lineNumbers || opts.langs.length || opts.count) {
      const searchOpts = { ...opts, lineNumbers: opts.lineNumbers || opts.langs.length > 0 };
      return { output: searchOutput(text, allMatches, searchOpts, file), changed: false, matches: allMatches };
    }
    process.stderr.write(`[${new Date().toISOString()} ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.\n`);
    return { output: text, changed: false, matches: allMatches };
  }
  const out = replaceScopedInRanges(text, re, langRanges, (x, args) => {
    let value = opts.replacement !== undefined ? applyReplacement(opts.replacement, args) : x;
    for (const action of opts.actions) value = transformOne(value, action, opts);
    return value;
  });
  return { output: out, changed: out !== text, matches: allMatches };
}

function replaceScopedInRanges(text, re, ranges, fn) {
  if (ranges.length === 1 && ranges[0].start === 0 && ranges[0].end === text.length) return replaceScoped(text, re, fn);
  let out = "", pos = 0;
  for (const r of ranges) {
    out += text.slice(pos, r.start);
    out += replaceScoped(text.slice(r.start, r.end), re, fn);
    pos = r.end;
  }
  out += text.slice(pos);
  return out;
}

function walk(dir, opts, out = []) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (!opts.hidden && ent.name.startsWith(".")) continue;
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(p, opts, out);
    else if (ent.isFile()) out.push(p);
  }
  return out;
}

function globToRegex(glob) {
  let s = escapeRegExp(glob).replace(/\\\*\\\*/g, ".*").replace(/\\\*/g, "[^/]*").replace(/\\\?/g, ".");
  return new RegExp("^" + s + "$");
}

function filesFor(opts) {
  let files = walk(process.cwd(), opts).map(p => path.relative(process.cwd(), p));
  if (opts.glob) {
    const gr = globToRegex(opts.glob);
    files = files.filter(f => gr.test(f) || gr.test(path.basename(f)));
  } else if (opts.langs.length) {
    const exts = [".py", ".rs", ".go", ".ts", ".tsx", ".c", ".h", ".cs", ".tf", ".hcl"];
    files = files.filter(f => exts.includes(path.extname(f)));
  }
  if (opts.sorted) files.sort();
  return files;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  try {
    if (opts.glob || opts.files || opts.filesWithMatches || (opts.langs.length && process.stdin.isTTY)) {
      const files = filesFor(opts);
      if (opts.failNoFiles && files.length === 0) throw new Error("No files found");
      if (opts.files) {
        process.stdout.write(files.join("\n") + (files.length ? "\n" : ""));
        return;
      }
      for (const f of files) {
        const text = fs.readFileSync(f, "utf8");
        const res = processText(text, opts, f);
        const hasActions = opts.standalone || opts.replacement !== undefined || opts.actions.length;
        if (hasActions) {
          if (opts.dryRun) {
            if (res.changed) process.stdout.write(`--- ${f}\n+++ ${f}\n${res.output}`);
          } else {
            fs.writeFileSync(f, res.output);
            if (res.changed) process.stdout.write(f + "\n");
          }
        } else {
          if (opts.filesWithMatches) {
            if (res.matches.length) process.stdout.write(f + "\n");
          } else if (!opts.onlyMatching && !opts.lineNumbers && !opts.langs.length && !opts.count) {
            // File mode without actions is only diagnostic in srgn; it does not dump files.
          } else {
            process.stdout.write(res.output);
          }
        }
      }
    } else {
      const input = fs.readFileSync(0, "utf8");
      const res = processText(input, opts);
      process.stdout.write(res.output);
    }
  } catch (e) {
    process.stderr.write(`Error: Error applying: ${e.message}\n`);
    process.exit(1);
  }
}

main();
