#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

function usage() {
  console.log(`Usage: ./executable [options] myservice.wsdl
  -d string
    \tDirectory under which package directory will be created (default "./")
  -i\tSkips TLS Verification
  -make-public
    \tMake the generated types public/exported (default true)
  -o string
    \tFile where the generated code will be saved (default "myservice.go")
  -p string
    \tPackage under which code will be generated (default "myservice")
  -v\tShows gowsdl version`);
}

function parseArgs(argv) {
  const opts = { d: './', o: 'myservice.go', p: 'myservice', insecure: false, version: false, makePublic: true, files: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h') { usage(); process.exit(0); }
    if (a === '-v') { opts.version = true; continue; }
    if (a === '-i') { opts.insecure = true; continue; }
    if (a === '-make-public') { opts.makePublic = true; continue; }
    if (a.startsWith('-make-public=')) { opts.makePublic = a.split('=')[1] !== 'false'; continue; }
    if (a === '-d' || a === '-o' || a === '-p') {
      if (i + 1 >= argv.length) { console.error(`flag needs an argument: ${a}`); usage(); process.exit(2); }
      opts[a.slice(1)] = argv[++i]; continue;
    }
    if (a.startsWith('-')) {
      console.error(`flag provided but not defined: ${a}`);
      usage(); process.exit(2);
    }
    opts.files.push(a);
  }
  return opts;
}

function decodeEntities(s) {
  return String(s || '').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
}

function attrsOf(s) {
  const attrs = {};
  const re = /([A-Za-z_][\w:.-]*)\s*=\s*("([^"]*)"|'([^']*)')/g;
  let m;
  while ((m = re.exec(s))) attrs[m[1]] = decodeEntities(m[3] !== undefined ? m[3] : m[4]);
  return attrs;
}

function local(n) { return (n || '').split(':').pop(); }
function stripPrefix(n) { return local(n); }

function parseXml(xml) {
  const root = { name: '#root', attrs: {}, children: [], text: '' };
  const stack = [root];
  const re = /<!--[\s\S]*?-->|<!\[CDATA\[[\s\S]*?\]\]>|<\?[\s\S]*?\?>|<!DOCTYPE[\s\S]*?>|<[^>]+>|[^<]+/g;
  let m;
  while ((m = re.exec(xml))) {
    const tok = m[0];
    if (tok.startsWith('<!--') || tok.startsWith('<?') || tok.startsWith('<!DOCTYPE')) continue;
    if (tok.startsWith('<![CDATA[')) {
      stack[stack.length - 1].text += tok.slice(9, -3);
      continue;
    }
    if (!tok.startsWith('<')) {
      stack[stack.length - 1].text += decodeEntities(tok);
      continue;
    }
    if (/^<\//.test(tok)) { if (stack.length > 1) stack.pop(); continue; }
    const selfClose = /\/>$/.test(tok);
    const inner = tok.slice(1, selfClose ? -2 : -1).trim();
    if (!inner) continue;
    const sp = inner.search(/\s/);
    const name = sp < 0 ? inner : inner.slice(0, sp);
    const attrText = sp < 0 ? '' : inner.slice(sp + 1);
    const node = { name, attrs: attrsOf(attrText), children: [], text: '', parent: stack[stack.length - 1] };
    stack[stack.length - 1].children.push(node);
    if (!selfClose) stack.push(node);
  }
  return root;
}

function descendants(n, lname) {
  const out = [];
  (function walk(x) {
    for (const c of x.children || []) {
      if (local(c.name) === lname) out.push(c);
      walk(c);
    }
  })(n);
  return out;
}
function child(n, lname) { return (n.children || []).find(c => local(c.name) === lname); }
function children(n, lname) { return (n.children || []).filter(c => local(c.name) === lname); }
function directSchemaContainers(n) {
  return children(n, 'sequence').concat(children(n, 'all'), children(n, 'choice'), children(n, 'complexContent').flatMap(directSchemaContainers), children(n, 'extension').flatMap(directSchemaContainers));
}

function goName(s) {
  s = String(s || '').replace(/[_\-.]+/g, ' ');
  const parts = s.split(/(?=[A-Z])|\s+/).filter(Boolean);
  let r = parts.map(p => p.charAt(0).toUpperCase() + p.slice(1)).join('');
  r = r.replace(/[^A-Za-z0-9]/g, '');
  if (!r) r = 'Value';
  if (/^[0-9]/.test(r)) r = 'N' + r;
  const initialisms = ['XML'];
  for (const init of initialisms) r = r.replace(new RegExp(init[0] + init.slice(1).toLowerCase(), 'g'), init);
  return r;
}
function unexport(s) { const n = goName(s); return n.charAt(0).toLowerCase() + n.slice(1); }

function schemaNamespace(schema, defNs) { return schema?.attrs?.targetNamespace || defNs || ''; }

function collectDocs(n) {
  const d = child(n, 'annotation');
  if (!d) return [];
  return descendants(d, 'documentation').map(x => x.text.trim()).filter(Boolean);
}

function elementFields(parent) {
  const fields = [];
  const containers = directSchemaContainers(parent);
  const scan = containers.length ? containers : [parent];
  for (const c of scan) {
    for (const e of children(c, 'element')) fields.push(e);
    for (const g of children(c, 'group')) for (const e of descendants(g, 'element')) fields.push(e);
  }
  return fields;
}

function typeBase(t) { return stripPrefix(t || 'string'); }
function primitiveGo(t, pointer, many) {
  const b = typeBase(t);
  let g;
  if (['string','token','normalizedString','language','Name','NCName','NMTOKEN','ID','IDREF','anyURI'].includes(b)) g = 'string';
  else if (['int','integer','short','byte','unsignedByte','unsignedShort'].includes(b)) g = 'int32';
  else if (['long','unsignedInt','unsignedLong','nonNegativeInteger','positiveInteger','nonPositiveInteger','negativeInteger'].includes(b)) g = 'int64';
  else if (b === 'float') g = 'float32';
  else if (['double','decimal'].includes(b)) g = 'float64';
  else if (b === 'boolean') g = 'bool';
  else if (b === 'date') g = 'soap.XSDDate';
  else if (['dateTime','time'].includes(b)) g = 'soap.XSDDateTime';
  else if (b === 'base64Binary') g = '[]byte';
  else if (b === 'anyType') g = 'AnyType';
  else g = goName(b);
  const isPrimitive = !/^[A-Z]/.test(g) || g.startsWith('soap.') || g === '[]byte';
  if (!many && pointer && !isPrimitive) g = '*' + g;
  if (many) g = '[]' + (isPrimitive ? g : '*' + g);
  return g;
}

function analyze(doc) {
  const defs = descendants(doc, 'definitions')[0] || descendants(doc, 'description')[0] || doc;
  const targetNs = defs.attrs.targetNamespace || '';
  const schemas = descendants(defs, 'schema');
  const types = new Map(), elems = new Map(), elemToType = new Map(), simpleEnums = new Map(), simpleAliases = new Map(), order = [];

  for (const schema of schemas) {
    const ns = schemaNamespace(schema, targetNs);
    for (const st of children(schema, 'simpleType')) {
      const name = st.attrs.name; if (!name) continue;
      const rest = descendants(st, 'restriction')[0];
      const base = rest?.attrs?.base || 'string';
      const enums = rest ? children(rest, 'enumeration').map(e => ({ value: e.attrs.value || '', docs: collectDocs(e) })) : [];
      if (enums.length) simpleEnums.set(name, { name, base, enums });
      else simpleAliases.set(name, base);
    }
    for (const ct of children(schema, 'complexType')) {
      const name = ct.attrs.name; if (!name) continue;
      types.set(name, { name, node: ct, ns, xmlName: null, docs: collectDocs(ct) });
    }
    for (const el of children(schema, 'element')) {
      const name = el.attrs.name || el.attrs.ref; if (!name) continue;
      elems.set(stripPrefix(name), { node: el, ns });
      const t = el.attrs.type ? stripPrefix(el.attrs.type) : stripPrefix(name);
      elemToType.set(stripPrefix(name), t);
      if (!el.attrs.type) {
        const ct = child(el, 'complexType');
        const st = child(el, 'simpleType');
        if (ct) types.set(stripPrefix(name), { name: stripPrefix(name), node: ct, ns, xmlName: stripPrefix(name), docs: collectDocs(el) });
        if (st) {
          const rest = descendants(st, 'restriction')[0];
          const enums = rest ? children(rest, 'enumeration').map(e => ({ value: e.attrs.value || '', docs: collectDocs(e) })) : [];
          if (enums.length) simpleEnums.set(stripPrefix(name), { name: stripPrefix(name), base: rest?.attrs?.base || 'string', enums });
          else simpleAliases.set(stripPrefix(name), rest?.attrs?.base || 'string');
        }
      } else if (types.has(t)) {
        const rec = types.get(t);
        if (!rec.xmlName) rec.xmlName = stripPrefix(name);
      } else if (!types.has(t) && !simpleEnums.has(stripPrefix(name)) && !simpleAliases.has(stripPrefix(name))) {
        if (!/^[A-Z]/.test(primitiveGo(t, false, false)) || primitiveGo(t, false, false).startsWith('soap.')) {
          simpleAliases.set(stripPrefix(name), el.attrs.type);
        }
      }
    }
    for (const n of schema.children || []) {
      const ln = local(n.name);
      if (ln === 'element' && n.attrs.name) order.push({ kind: 'element', name: stripPrefix(n.attrs.name) });
      if (ln === 'complexType' && n.attrs.name) order.push({ kind: 'complexType', name: stripPrefix(n.attrs.name) });
      if (ln === 'simpleType' && n.attrs.name) order.push({ kind: 'simpleType', name: stripPrefix(n.attrs.name) });
    }
  }

  const messages = new Map();
  for (const msg of descendants(defs, 'message')) {
    const part = descendants(msg, 'part')[0];
    messages.set(msg.attrs.name, stripPrefix(part?.attrs?.element || part?.attrs?.type || ''));
  }
  const soapActions = new Map();
  for (const b of descendants(defs, 'binding')) {
    for (const op of children(b, 'operation')) {
      const so = children(op, 'operation').find(x => x.name.includes(':')) || child(op, 'operation');
      if (so?.attrs?.soapAction !== undefined) soapActions.set(op.attrs.name, so.attrs.soapAction);
    }
  }
  const portTypes = [];
  for (const pt of descendants(defs, 'portType')) {
    const ops = [];
    for (const op of children(pt, 'operation')) {
      const inMsg = stripPrefix(child(op, 'input')?.attrs?.message || '');
      const outMsg = stripPrefix(child(op, 'output')?.attrs?.message || '');
      ops.push({ name: op.attrs.name, input: messages.get(inMsg) || goName(op.attrs.name), output: messages.get(outMsg) || (goName(op.attrs.name) + 'Response'), action: soapActions.get(op.attrs.name) || "''" });
    }
    if (ops.length) portTypes.push({ name: pt.attrs.name || 'Service', ops });
  }
  return { targetNs, types, elems, elemToType, simpleEnums, simpleAliases, portTypes, order };
}

function fieldFromElement(e, model) {
  const raw = stripPrefix(e.attrs.name || e.attrs.ref || 'Value');
  const max = e.attrs.maxOccurs || '';
  const many = max === 'unbounded' || (/^\d+$/.test(max) && Number(max) > 1);
  let t = e.attrs.type ? stripPrefix(e.attrs.type) : raw;
  if (!e.attrs.type && child(e, 'complexType')) {
    const ct = child(e, 'complexType');
    const sc = descendants(ct, 'simpleContent')[0];
    if (sc) {
      const ext = descendants(sc, 'extension')[0];
      let inner = 'struct {\n\t\tValue string `xml:",chardata" json:"-,"`\n\n';
      for (const a of descendants(sc, 'attribute')) {
        const raw = stripPrefix(a.attrs.name || a.attrs.ref || 'attr');
        inner += `\t\t${goName(raw)} ${primitiveGo(a.attrs.type || 'string', false, false)} \`xml:"${model.targetNs} ${raw},attr,omitempty" json:"${raw},omitempty"\`\n`;
      }
      inner += '\t}';
      return { raw, name: goName(raw), type: (many ? '[]' : '') + inner, docs: collectDocs(e), attr: e.attrs };
    }
  }
  if (!e.attrs.type && child(e, 'simpleType')) {
    const rest = descendants(child(e, 'simpleType'), 'restriction')[0];
    t = rest?.attrs?.base || 'string';
  }
  const pointer = e.attrs.minOccurs === '0' || model.types.has(t);
  return { raw, name: goName(raw), type: primitiveGo(t, pointer, many), docs: collectDocs(e), attr: e.attrs };
}

function renderStruct(name, rec, model) {
  let out = '';
  const docs = rec.docs || [];
  for (const d of docs) out += `// ${d.replace(/\s+/g, ' ')}\n`;
  out += `type ${goName(name)} struct {\n`;
  if (rec.xmlName) out += `\tXMLName xml.Name \`xml:"${rec.ns} ${rec.xmlName}"\`\n\n`;
  const fields = elementFields(rec.node).map(e => fieldFromElement(e, model));
  const attrs = children(rec.node, 'attribute').filter(a => a.attrs.name || a.attrs.ref);
  for (const f of fields) {
    for (const d of f.docs) out += `\t// ${d.replace(/\s+/g, ' ')}\n\n`;
    out += `\t${f.name} ${f.type} \`xml:"${f.raw},omitempty" json:"${f.raw},omitempty"\`\n\n`;
  }
  for (const a of attrs) {
    const raw = stripPrefix(a.attrs.name || a.attrs.ref || 'attr');
    const t = primitiveGo(a.attrs.type || 'string', a.attrs.use !== 'required', false);
    for (const d of collectDocs(a)) out += `\t// ${d.replace(/\s+/g, ' ')}\n\n`;
    out += `\t${goName(raw)} ${t} \`xml:"${rec.ns} ${raw},attr,omitempty" json:"${raw},omitempty"\`\n\n`;
  }
  out = out.replace(/\n\n$/, '\n');
  return out + '}\n\n';
}

function renderAlias(name, base) {
  const g = primitiveGo(base, false, false);
  let out = `type ${goName(name)} ${g}\n\n`;
  if (g === 'soap.XSDDateTime' || g === 'soap.XSDDate') {
    out += `func (xdt ${goName(name)}) MarshalXML(e *xml.Encoder, start xml.StartElement) error {\n\treturn ${g}(xdt).MarshalXML(e, start)\n}\n\n`;
    out += `func (xdt *${goName(name)}) UnmarshalXML(d *xml.Decoder, start xml.StartElement) error {\n\treturn (*${g})(xdt).UnmarshalXML(d, start)\n}\n\n`;
  }
  return out;
}

function renderEnum(name, rec) {
  let out = `type ${goName(name)} ${primitiveGo(rec.base, false, false)}\n\nconst (\n\n`;
  for (const en of rec.enums) {
    for (const d of en.docs) out += `\t// ${d.replace(/\s+/g, ' ')}\n`;
    out += `\t${goName(name)}${goName(en.value)} ${goName(name)} = "${en.value}"\n\n`;
  }
  return out.replace(/\n\n$/, '\n') + ')\n\n';
}

function renderClient(model, pkg) {
  let out = `// Code generated by gowsdl DO NOT EDIT.\n\npackage ${pkg}\n\nimport (\n\t"context"\n\t"encoding/xml"\n\t"github.com/hooklift/gowsdl/soap"\n\t"time"\n)\n\n// against "unused imports"\nvar _ time.Time\nvar _ xml.Name\n\ntype AnyType struct {\n\tInnerXML string \`xml:",innerxml"\`\n}\n\ntype AnyURI string\n\ntype NCName string\n\n`;
  const rendered = new Set();
  for (const ent of model.order.filter(e => e.kind === 'element')) {
    const name = ent.name, t = model.elemToType.get(name);
    if (rendered.has(name)) continue;
    if (model.types.has(name)) { out += renderStruct(name, model.types.get(name), model); rendered.add(name); }
    else if (model.simpleEnums.has(name)) { out += renderEnum(name, model.simpleEnums.get(name)); rendered.add(name); }
    else if (model.simpleAliases.has(name)) { out += renderAlias(name, model.simpleAliases.get(name)); rendered.add(name); }
    else if (model.elems.has(name) && !model.types.has(t)) { const er = model.elems.get(name); out += renderStruct(name, { name, node: er.node, ns: er.ns, xmlName: name, docs: collectDocs(er.node) }, model); rendered.add(name); }
  }
  for (const ent of model.order.filter(e => e.kind !== 'element')) {
    const name = ent.name;
    if (rendered.has(name)) continue;
    if (model.simpleEnums.has(name)) { out += renderEnum(name, model.simpleEnums.get(name)); rendered.add(name); }
    else if (model.simpleAliases.has(name)) { out += renderAlias(name, model.simpleAliases.get(name)); rendered.add(name); }
    else if (model.types.has(name)) { out += renderStruct(name, model.types.get(name), model); rendered.add(name); }
  }
  for (const [name, rec] of model.simpleEnums) { if (!rendered.has(name)) { out += renderEnum(name, rec); rendered.add(name); } }
  for (const [name, base] of model.simpleAliases) { if (!rendered.has(name)) { out += renderAlias(name, base); rendered.add(name); } }
  for (const [name, rec] of model.types) { if (!rendered.has(name)) { out += renderStruct(name, rec, model); rendered.add(name); } }
  for (const [ename, er] of model.elems) {
    const t = model.elemToType.get(ename);
    if (!rendered.has(ename) && !model.types.has(t) && !model.simpleEnums.has(ename) && !model.simpleAliases.has(ename)) {
      out += renderStruct(ename, { name: ename, node: er.node, ns: er.ns, xmlName: ename, docs: collectDocs(er.node) }, model);
      rendered.add(ename);
    }
  }
  for (const pt of model.portTypes) {
    const iface = goName(pt.name);
    out += `type ${iface} interface {\n`;
    for (const op of pt.ops) {
      out += `\t${goName(op.name)}(request *${goName(op.input)}) (*${goName(op.output)}, error)\n\n`;
      out += `\t${goName(op.name)}Context(ctx context.Context, request *${goName(op.input)}) (*${goName(op.output)}, error)\n\n`;
    }
    out = out.replace(/\n\n$/, '\n');
    out += `}\n\n`;
    const recv = unexport(pt.name);
    out += `type ${recv} struct {\n\tclient *soap.Client\n}\n\n`;
    out += `func New${iface}(client *soap.Client) ${iface} {\n\treturn &${recv}{\n\t\tclient: client,\n\t}\n}\n\n`;
    for (const op of pt.ops) {
      out += `func (service *${recv}) ${goName(op.name)}Context(ctx context.Context, request *${goName(op.input)}) (*${goName(op.output)}, error) {\n\tresponse := new(${goName(op.output)})\n\terr := service.client.CallContext(ctx, "${op.action}", request, response)\n\tif err != nil {\n\t\treturn nil, err\n\t}\n\n\treturn response, nil\n}\n\n`;
      out += `func (service *${recv}) ${goName(op.name)}(request *${goName(op.input)}) (*${goName(op.output)}, error) {\n\treturn service.${goName(op.name)}Context(\n\t\tcontext.Background(),\n\t\trequest,\n\t)\n}\n\n`;
    }
  }
  return out.replace(/\n+$/, '\n');
}

function backtick(s) { return s.replace(/`/g, '` + "`" + `'); }

function renderServer(model, pkg, wsdl) {
  const requests = [];
  for (const pt of model.portTypes) for (const op of pt.ops) requests.push({ req: goName(op.input), resp: goName(op.output) });
  let out = `// Code generated by gowsdl DO NOT EDIT.\n\npackage ${pkg}\n\nimport (\n\t"encoding/xml"\n\t"errors"\n\t"fmt"\n\t"net/http"\n\t"reflect"\n\t"strings"\n)\n\nvar wsdl = \`${backtick(wsdl)}\`\n\nvar WSDLUndefinedError = errors.New("Server was unable to process request. --> Object reference not set to an instance of an object.")\n\ntype SOAPEnvelopeRequest struct {\n\tXMLName xml.Name \`xml:"http://schemas.xmlsoap.org/soap/envelope/ Envelope"\`\n\tBody    SOAPBodyRequest\n}\n\ntype SOAPBodyRequest struct {\n\tXMLName xml.Name \`xml:"http://schemas.xmlsoap.org/soap/envelope/ Body"\`\n\n`;
  for (const r of requests) out += `\t${r.req} *${r.req} \`xml:,omitempty\`\n`;
  out += `}\n\ntype SOAPEnvelopeResponse struct {\n\tXMLName    xml.Name \`xml:"soap:Envelope"\`\n\tPrefixSoap string   \`xml:"xmlns:soap,attr"\`\n\tPrefixXsi  string   \`xml:"xmlns:xsi,attr"\`\n\tPrefixXsd  string   \`xml:"xmlns:xsd,attr"\`\n\n\tBody SOAPBodyResponse\n}\n\nfunc NewSOAPEnvelopResponse() *SOAPEnvelopeResponse {\n\treturn &SOAPEnvelopeResponse{\n\t\tPrefixSoap: "http://schemas.xmlsoap.org/soap/envelope/",\n\t\tPrefixXsd:  "http://www.w3.org/2001/XMLSchema",\n\t\tPrefixXsi:  "http://www.w3.org/2001/XMLSchema-instance",\n\t}\n}\n\ntype Fault struct {\n\tXMLName xml.Name \`xml:"SOAP-ENV:Fault"\`\n\tSpace   string   \`xml:"xmlns:SOAP-ENV,omitempty,attr"\`\n\n\tCode   string \`xml:"faultcode,omitempty"\`\n\tString string \`xml:"faultstring,omitempty"\`\n\tActor  string \`xml:"faultactor,omitempty"\`\n\tDetail string \`xml:"detail,omitempty"\`\n}\n\ntype SOAPBodyResponse struct {\n\tXMLName xml.Name \`xml:"soap:Body"\`\n\tFault   *Fault   \`xml:",omitempty"\`\n\n`;
  for (const r of requests) out += `\t${r.req} *${r.resp} \`xml:",omitempty"\`\n`;
  out += `}\n\n`;
  for (const r of requests) out += `func (service *SOAPBodyRequest) ${r.req}Func(request *${r.req}) (*${r.resp}, error) {\n\treturn nil, WSDLUndefinedError\n}\n\n`;
  out += `func (service *SOAPEnvelopeRequest) call(w http.ResponseWriter, r *http.Request) {\n\tw.Header().Add("Content-Type", "text/xml; charset=utf-8")\n\tval := reflect.ValueOf(&service.Body).Elem()\n\tn := val.NumField()\n\tvar field reflect.Value\n\tvar name string\n\tfind := false\n\n\tif r.Method == http.MethodGet {\n\t\tw.Write([]byte(wsdl))\n\t\treturn\n\t}\n\n\tresp := NewSOAPEnvelopResponse()\n\tdefer func() {\n\t\tif r := recover(); r != nil {\n\t\t\tresp.Body.Fault = &Fault{}\n\t\t\tresp.Body.Fault.Space = "http://schemas.xmlsoap.org/soap/envelope/"\n\t\t\tresp.Body.Fault.Code = "soap:Server"\n\t\t\tresp.Body.Fault.Detail = fmt.Sprintf("%v", r)\n\t\t\tresp.Body.Fault.String = fmt.Sprintf("%v", r)\n\t\t}\n\t\txml.NewEncoder(w).Encode(resp)\n\t}()\n\n\theader := r.Header.Get("Content-Type")\n\tif strings.Index(header, "application/soap+xml") >= 0 {\n\t\tpanic("Could not find an appropriate Transport Binding to invoke.")\n\t}\n\n\terr := xml.NewDecoder(r.Body).Decode(service)\n\tif err != nil {\n\t\tpanic(err)\n\t}\n\n\tfor i := 0; i < n; i++ {\n\t\tfield = val.Field(i)\n\t\tname = val.Type().Field(i).Name\n\t\tif field.Kind() != reflect.Ptr {\n\t\t\tcontinue\n\t\t}\n\t\tif field.IsNil() {\n\t\t\tcontinue\n\t\t}\n\t\tif field.IsValid() {\n\t\t\tfind = true\n\t\t\tbreak\n\t\t}\n\t}\n\n\tif !find {\n\t\tpanic(WSDLUndefinedError)\n\t} else {\n\t\tm := val.Addr().MethodByName(name + "Func")\n\t\tif !m.IsValid() {\n\t\t\tpanic(WSDLUndefinedError)\n\t\t}\n\n\t\tvals := m.Call([]reflect.Value{field})\n\t\tif vals[1].IsNil() {\n\t\t\treflect.ValueOf(&resp.Body).Elem().FieldByName(name).Set(vals[0])\n\t\t} else {\n\t\t\tpanic(vals[1].Interface())\n\t\t}\n\t}\n\n}\n\nfunc Endpoint(w http.ResponseWriter, r *http.Request) {\n\trequest := SOAPEnvelopeRequest{}\n\trequest.call(w, r)\n}\n`;
  return out;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.version) { console.log('🍀  v0.5.0'); if (!opts.files.length) return; }
  if (!opts.files.length) { usage(); return; }
  const input = opts.files[0];
  const full = path.resolve(process.cwd(), input);
  console.log(`🍀  Reading file ${full}`);
  let wsdl;
  try { wsdl = fs.readFileSync(full, 'utf8'); } catch (e) { console.log(`🍀  ${e.message}`); process.exit(1); }
  const model = analyze(parseXml(wsdl));
  const dir = path.join(opts.d, opts.p);
  const outFile = path.join(dir, opts.o);
  const serverFile = path.join(dir, 'server' + opts.o);
  try {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir);
    fs.writeFileSync(outFile, renderClient(model, opts.p));
    fs.writeFileSync(serverFile, renderServer(model, opts.p, wsdl));
  } catch (e) {
    console.log(`🍀  ${e.message}`);
    process.exit(1);
  }
  console.log('🍀  Done 👍');
}
main();
