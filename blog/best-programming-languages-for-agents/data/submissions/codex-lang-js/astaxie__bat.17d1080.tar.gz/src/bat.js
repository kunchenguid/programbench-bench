#!/usr/bin/env node
const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const HELP = `bat is a Go implemented CLI cURL-like tool for humans.

Usage:

\tbat [flags] [METHOD] URL [ITEM [ITEM]]

flags:
  -a, -auth=USER[:PASS]       Pass a username:password pair as the argument
  -b, -bench=false            Sends bench requests to URL
  -b.N=1000                   Number of requests to run
  -b.C=100                    Number of requests to run concurrently
  -body=""                    Send RAW data as body
  -f, -form=false             Submitting the data as a form
  -j, -json=true              Send the data in a JSON object
  -p, -pretty=true            Print Json Pretty Format
  -i, -insecure=false         Allow connections to SSL sites without certs
  -proxy=PROXY_URL            Proxy with host and port
  -print="A"                  String specifying what the output should contain, default will print all information
         "H" request headers
         "B" request body
         "h" response headers
         "b" response body
  -v, -version=true           Show Version Number

METHOD:
  bat defaults to either GET (if there is no request data) or POST (with request data).

URL:
  The only information needed to perform a request is a URL. The default scheme is http://,
  which can be omitted from the argument; example.org works just fine.

ITEM:
  Can be any of:
    Query string   key=value
    Header         key:value
    Post data      key=value
    File upload    key@/path/file

Example:

\tbat beego.me

more help information please refer to https://github.com/astaxie/bat
`;

const METHODS = new Set(["GET","POST","PUT","DELETE","PATCH","HEAD","OPTIONS"]);

function boolVal(v) { return v === true || v === "true" || v === "1"; }
function defaultFlags() { return { auth:"", bench:false, bN:1000, bC:100, body:"", form:false, json:true, pretty:true, insecure:false, proxy:"", print:"A", version:false, download:false }; }
function flagError(name) { process.stderr.write(`flag provided but not defined: ${name}\n` + HELP); process.exit(2); }

function parseArgs(argv) {
  const flags = defaultFlags();
  const pos = [];
  const aliases = {"a":"auth","auth":"auth","b":"bench","bench":"bench","b.N":"bN","b.C":"bC","body":"body","f":"form","form":"form","j":"json","json":"json","p":"pretty","pretty":"pretty","i":"insecure","insecure":"insecure","proxy":"proxy","print":"print","v":"version","version":"version","download":"download"};
  const bools = new Set(["bench","form","json","pretty","insecure","version","download"]);
  const strings = new Set(["auth","body","proxy","print"]);
  const ints = new Set(["bN","bC"]);
  for (let i=0;i<argv.length;i++) {
    let a = argv[i];
    if (a === "--help" || a === "-h") { process.stdout.write(HELP); process.exit(0); }
    if (!a.startsWith("-") || a === "-") { pos.push(a); continue; }
    let raw = a.replace(/^-+/, "");
    let val = true;
    const eq = raw.indexOf("=");
    if (eq >= 0) { val = raw.slice(eq+1); raw = raw.slice(0, eq); }
    const key = aliases[raw];
    if (!key) flagError("-" + raw);
    if ((strings.has(key) || ints.has(key)) && val === true) {
      if (i + 1 >= argv.length) { process.stderr.write(`flag needs an argument: -${raw}\n` + HELP); process.exit(2); }
      val = argv[++i];
    }
    if (bools.has(key)) flags[key] = boolVal(val);
    else if (ints.has(key)) flags[key] = parseInt(val,10) || 0;
    else flags[key] = String(val);
  }
  return {flags, pos};
}

function splitItems(items) {
  const headers = {};
  const data = [];
  for (const it of items) {
    const ci = it.indexOf(":");
    const ei = it.indexOf("=");
    const ai = it.indexOf("@");
    if (ci > 0 && (ei < 0 || ci < ei) && (ai < 0 || ci < ai)) {
      headers[it.slice(0,ci)] = it.slice(ci+1);
    } else if (ei > 0) {
      data.push([it.slice(0,ei), it.slice(ei+1)]);
    }
  }
  return {headers, data};
}

function normalizeUrl(s) {
  if (!/^https?:\/\//i.test(s)) s = "http://" + s;
  return new URL(s);
}

function buildRequest(pos, flags) {
  if (flags.version) { process.stdout.write("Version: 0.1.0\n"); process.exit(2); }
  if (pos.length < 1) { process.stdout.write(HELP); process.exit(2); }
  let method = "";
  let urlArg, itemStart;
  if (METHODS.has(pos[0].toUpperCase()) && pos.length >= 2) { method = pos[0].toUpperCase(); urlArg = pos[1]; itemStart = 2; }
  else { urlArg = pos[0]; itemStart = 1; }
  const items = pos.slice(itemStart);
  const {headers, data} = splitItems(items);
  const url = normalizeUrl(urlArg);
  if (!method) method = (data.length || flags.body) ? "POST" : "GET";
  let body = null;
  const explicitGet = method === "GET" && data.length && itemStart === 2;
  if (explicitGet) {
    for (const [k,v] of data) url.searchParams.append(k, v);
  } else if (flags.body) {
    body = flags.body;
  } else if (data.length && method !== "GET") {
    if (flags.form) {
      body = data.map(([k,v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
      headers["Content-Type"] = "application/x-www-form-urlencoded";
    } else {
      const obj = {};
      for (const [k,v] of data) obj[k] = v;
      body = JSON.stringify(obj) + "\n";
      headers["Content-Type"] = "application/json";
    }
  }
  const reqHeaders = {"User-Agent":"bat/0.1.0", "Accept":"application/json", "Accept-Encoding":"gzip, deflate", ...headers};
  if (flags.auth) reqHeaders["Authorization"] = "Basic " + Buffer.from(flags.auth).toString("base64");
  if (body != null) reqHeaders["Content-Length"] = Buffer.byteLength(body);
  return {method, url, headers:reqHeaders, body};
}

function requestOnce(spec, flags) {
  return new Promise((resolve, reject) => {
    const isHttps = spec.url.protocol === "https:";
    const lib = isHttps ? https : http;
    const opts = {method:spec.method, hostname:spec.url.hostname, port: spec.url.port || (isHttps?443:80), path: spec.url.pathname + spec.url.search, headers: spec.headers, rejectUnauthorized: !flags.insecure};
    const req = lib.request(opts, res => {
      const chunks=[];
      res.on("data", c => chunks.push(c));
      res.on("end", () => {
        let buf = Buffer.concat(chunks);
        const enc = String(res.headers["content-encoding"] || "").toLowerCase();
        try { if (enc.includes("gzip")) buf = zlib.gunzipSync(buf); else if (enc.includes("deflate")) buf = zlib.inflateSync(buf); } catch {}
        resolve({statusCode:res.statusCode, statusMessage:res.statusMessage, headers:res.headers, body:buf});
      });
    });
    req.on("error", reject);
    if (spec.body != null) req.write(spec.body);
    req.end();
  });
}

function printBody(resp, flags) {
  const text = resp.body.toString();
  const ct = String(resp.headers["content-type"] || "");
  if (flags.pretty && ct.includes("json")) {
    try { process.stdout.write("\n" + JSON.stringify(JSON.parse(text), null, 2) + "\n"); return; } catch {}
  }
  process.stdout.write(text);
}
function color(c,s){ return `\x1b[${c}m${s}\x1b[0m`; }
function filenameFrom(resp, url) {
  const cd = resp.headers["content-disposition"] || "";
  const m = /filename="?([^";]+)"?/i.exec(cd);
  if (m) return path.basename(m[1]);
  const b = path.basename(url.pathname);
  return b || "index.html";
}
async function download(spec, flags) {
  const resp = await requestOnce(spec, flags);
  process.stdout.write(`${color(95,"HTTP/1.1")} ${color(92,`${resp.statusCode} ${resp.statusMessage || ""}`.trim())}\n`);
  for (const [k,v] of Object.entries(resp.headers)) {
    const name = k.split("-").map(p=>p.charAt(0).toUpperCase()+p.slice(1)).join("-");
    process.stdout.write(`${color(90,name)} : ${color(96,String(v))}\n`);
  }
  const fn = filenameFrom(resp, spec.url);
  fs.writeFileSync(fn, resp.body);
  process.stdout.write(`\nDownloading to "${fn}"\n`);
  const n = resp.body.length;
  process.stdout.write(`\r${n} B / ${n} B [=========================================================================================] 100.00 %\n`);
}

async function bench(spec, flags) {
  const total = Math.max(1, flags.bN|0), conc = Math.max(1, flags.bC|0);
  let done=0, bytes=0, codes={}, times=[];
  const startAll = Date.now();
  async function worker(){ while(done < total){ done++; const t=Date.now(); try{ const r=await requestOnce(spec, flags); times.push((Date.now()-t)/1000); bytes += r.body.length; codes[r.statusCode]=(codes[r.statusCode]||0)+1; }catch(e){ codes[0]=(codes[0]||0)+1; times.push((Date.now()-t)/1000); } } }
  await Promise.all(Array.from({length:Math.min(conc,total)}, worker));
  const elapsed = Math.max(0.0001,(Date.now()-startAll)/1000);
  times.sort((a,b)=>a-b);
  const sum = times.reduce((a,b)=>a+b,0), avg=sum/times.length;
  process.stdout.write(`\nSummary:\n  Total:\t${elapsed.toFixed(4)} secs.\n  Slowest:\t${(times[times.length-1]||0).toFixed(4)} secs.\n  Fastest:\t${(times[0]||0).toFixed(4)} secs.\n  Average:\t${avg.toFixed(4)} secs.\n  Requests/sec:\t${(total/elapsed).toFixed(4)}\n  Total Data Received:\t${bytes} bytes.\n  Response Size per Request:\t${Math.round(bytes/total)} bytes.\n\nStatus code distribution:\n`);
  for (const k of Object.keys(codes).sort()) process.stdout.write(`  [${k}]\t${codes[k]} responses\n`);
}

(async function main(){
  const {flags,pos} = parseArgs(process.argv.slice(2));
  let spec;
  try { spec = buildRequest(pos, flags); }
  catch(e) { process.stderr.write(String(e.message || e) + "\n"); process.exit(1); }
  try {
    if (flags.bench) await bench(spec, flags);
    else if (flags.download) await download(spec, flags);
    else printBody(await requestOnce(spec, flags), flags);
  } catch (e) {
    const now = new Date();
    const stamp = now.toISOString().replace("T"," ").replace("Z","");
    process.stderr.write(`${stamp} bat.go:215: can\x27t get the url ${spec.method[0]+spec.method.slice(1).toLowerCase()} "${spec.url.href}": ${e.message}\n`);
  }
})();
