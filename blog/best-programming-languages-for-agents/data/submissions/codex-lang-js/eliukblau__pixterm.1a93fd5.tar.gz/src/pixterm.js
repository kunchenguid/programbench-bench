#!/usr/bin/env node
"use strict";

const fs = require("fs");
const zlib = require("zlib");
const http = require("http");
const https = require("https");

const VERSION = "1.3.2";
const LOGO = `   ___  _____  ____
  / _ \\/  _/ |/_/ /____ ______ _      Made with love by Eliuk Blau
 / ___// /_>  </ __/ -_) __/  ' \\ https://github.com/eliukblau/pixterm
/_/  /___/_/|_|\\__/\\__/_/ /_/_/_/                ${VERSION}
`;

const HELP = `${LOGO}
USAGE:

  executable [options] image/url

  Supported image formats: JPEG, PNG, GIF, BMP, TIFF, WebP.
  Supported URL protocols: HTTP, HTTPS.

OPTIONS:

  -credits
    \tshow some love to contributors <3
  -d mode
    \tdithering mode:
    \t   0 - no dithering (default)
    \t   1 - with blocks
    \t   2 - with chars
  -go
    \toutput Go code to 'fmt.Print()' the image
  -m color
    \tmatte color for transparency or background
    \t(optional, hex format, default: 000000)
  -nobg
    \tdisable background color
    \t(optional, only in dithering mode, ignores matte color)
  -s method
    \tscale method:
    \t   0 - resize (default)
    \t   1 - fill
    \t   2 - fit
  -tc columns
    \tterminal columns (optional, >=2; when piping, default: 80)
  -tr rows
    \tterminal rows (optional, >=2; when piping, default: 24)
  -version
    \tshow PIXterm version
  -help
\tprints this message :D LOL
`;

const CREDITS = `${LOGO}
CONTRIBUTORS:

  > @disq - https://github.com/disq
      + Original code for image transparency support.

  > @timob - https://github.com/timob
      + Fix for ANSIpixel type: use 8bit color component for output.

  > @HongjiangHuang - https://github.com/HongjiangHuang
      + Original code for image download support.

  > @brutestack - https://github.com/brutestack
      + Color support for Windows (Command Prompt & PowerShell).
      + Original code for disable background color in dithering mode.
      + Original code for output Go code to 'fmt.Print()' the image.

  > @diamondburned - https://github.com/diamondburned
      + NewFromImage() & NewScaledFromImage() for ANSImage API.

  > @MichaelMure - https://github.com/MichaelMure
      + More conventional 'go.mod' file at repository.

  > @Calinou - https://github.com/Calinou
      + Use HTTPS URLs everywhere.
      + Other awesome contributions.

  > @danirod - https://github.com/danirod
  > @Xpktro - https://github.com/Xpktro
      + Moral support.
`;

function die(msg, code = 1) {
  process.stdout.write(LOGO + "\n");
  const d = new Date();
  const stamp = `${d.getUTCFullYear()}/${String(d.getUTCMonth() + 1).padStart(2, "0")}/${String(d.getUTCDate()).padStart(2, "0")} ${String(d.getUTCHours()).padStart(2, "0")}:${String(d.getUTCMinutes()).padStart(2, "0")}:${String(d.getUTCSeconds()).padStart(2, "0")}`;
  process.stderr.write(`[PIXTERM ERROR] ${stamp} ${msg}\n`);
  process.exit(code);
}

function parseArgs(argv) {
  const o = { d: 0, s: 0, matte: [0, 0, 0], nobg: false, go: false, tc: 80, tr: 24, path: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-help" || a === "--help") { process.stdout.write(HELP + "\n"); process.exit(0); }
    if (a === "-version") { process.stdout.write(VERSION + "\n"); process.exit(0); }
    if (a === "-credits") { process.stdout.write(CREDITS); process.exit(0); }
    if (a === "-go") { o.go = true; continue; }
    if (a === "-nobg") { o.nobg = true; continue; }
    if (a === "-d" || a === "-s" || a === "-tc" || a === "-tr" || a === "-m") {
      const v = argv[++i];
      if (v == null) usageExit();
      if (a === "-d") { o.d = Number(v); if (![0, 1, 2].includes(o.d)) usageExit(); }
      else if (a === "-s") { o.s = Number(v); if (![0, 1, 2].includes(o.s)) usageExit(); }
      else if (a === "-tc") { o.tc = Number(v); if (!Number.isInteger(o.tc) || o.tc < 2) usageExit(); }
      else if (a === "-tr") { o.tr = Number(v); if (!Number.isInteger(o.tr) || o.tr < 2) usageExit(); }
      else {
        if (!/^[0-9a-fA-F]{6}$/.test(v)) die(`matte color : ${v} is not a hex-color`, 2);
        o.matte = [parseInt(v.slice(0, 2), 16), parseInt(v.slice(2, 4), 16), parseInt(v.slice(4, 6), 16)];
      }
      continue;
    }
    if (a.startsWith("-")) usageExit();
    if (o.path) usageExit();
    o.path = a;
  }
  if (!o.path) usageExit();
  return o;
}

function usageExit() {
  process.stdout.write(HELP + "\n");
  process.exit(2);
}

function crcTable() {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
}
const CRC = crcTable();
function crc32(buf) {
  let c = 0xffffffff;
  for (const b of buf) c = CRC[(c ^ b) & 255] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function decodePNG(buf) {
  if (buf.length < 8 || buf.toString("binary", 1, 4) !== "PNG") throw new Error("image: unknown format");
  let off = 8, w = 0, h = 0, bit = 0, color = 0, interlace = 0, palette = null, trns = null;
  const idat = [];
  while (off + 8 <= buf.length) {
    const len = buf.readUInt32BE(off); off += 4;
    const typ = buf.toString("ascii", off, off + 4); off += 4;
    const data = buf.subarray(off, off + len); off += len + 4;
    if (typ === "IHDR") { w = data.readUInt32BE(0); h = data.readUInt32BE(4); bit = data[8]; color = data[9]; interlace = data[12]; }
    else if (typ === "PLTE") { palette = data; }
    else if (typ === "tRNS") { trns = data; }
    else if (typ === "IDAT") { idat.push(data); }
    else if (typ === "IEND") break;
  }
  if (bit !== 8 || interlace !== 0) throw new Error("png: unsupported format");
  const channels = ({0:1, 2:3, 3:1, 4:2, 6:4})[color];
  if (!channels) throw new Error("png: unsupported format");
  const bpp = channels;
  const stride = w * bpp;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const out = Buffer.alloc(w * h * 4);
  let p = 0;
  let prev = Buffer.alloc(stride);
  for (let y = 0; y < h; y++) {
    const filter = raw[p++];
    const scan = Buffer.from(raw.subarray(p, p + stride)); p += stride;
    for (let x = 0; x < stride; x++) {
      const a = x >= bpp ? scan[x - bpp] : 0;
      const b = prev[x] || 0;
      const c = x >= bpp ? prev[x - bpp] : 0;
      if (filter === 1) scan[x] = (scan[x] + a) & 255;
      else if (filter === 2) scan[x] = (scan[x] + b) & 255;
      else if (filter === 3) scan[x] = (scan[x] + Math.floor((a + b) / 2)) & 255;
      else if (filter === 4) scan[x] = (scan[x] + paeth(a, b, c)) & 255;
      else if (filter !== 0) throw new Error("png: bad filter");
    }
    for (let x = 0; x < w; x++) {
      let r, g, b, a = 255;
      const si = x * channels;
      if (color === 6) { r = scan[si]; g = scan[si + 1]; b = scan[si + 2]; a = scan[si + 3]; }
      else if (color === 2) {
        r = scan[si]; g = scan[si + 1]; b = scan[si + 2];
        if (trns && r === trns.readUInt16BE(0) && g === trns.readUInt16BE(2) && b === trns.readUInt16BE(4)) a = 0;
      } else if (color === 0) {
        r = g = b = scan[si];
        if (trns && r === trns.readUInt16BE(0)) a = 0;
      } else if (color === 4) { r = g = b = scan[si]; a = scan[si + 1]; }
      else {
        const idx = scan[si], pi = idx * 3;
        if (!palette || pi + 2 >= palette.length) throw new Error("png: bad palette");
        r = palette[pi]; g = palette[pi + 1]; b = palette[pi + 2]; a = trns && idx < trns.length ? trns[idx] : 255;
      }
      const di = (y * w + x) * 4;
      out[di] = r; out[di + 1] = g; out[di + 2] = b; out[di + 3] = a;
    }
    prev = scan;
  }
  return { width: w, height: h, data: out };
}

function paeth(a, b, c) {
  const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
  return pa <= pb && pa <= pc ? a : (pb <= pc ? b : c);
}

function decodeBMP(buf) {
  if (buf.toString("ascii", 0, 2) !== "BM") throw new Error("image: unknown format");
  const pixOff = buf.readUInt32LE(10), dib = buf.readUInt32LE(14);
  const w = buf.readInt32LE(18), hh = buf.readInt32LE(22), h = Math.abs(hh);
  const bpp = buf.readUInt16LE(28), comp = buf.readUInt32LE(30);
  if (comp !== 0 || ![24, 32].includes(bpp)) throw new Error("bmp: unsupported format");
  const row = Math.floor((bpp * w + 31) / 32) * 4;
  const out = Buffer.alloc(w * h * 4);
  for (let y = 0; y < h; y++) {
    const sy = hh > 0 ? h - 1 - y : y;
    for (let x = 0; x < w; x++) {
      const si = pixOff + sy * row + x * (bpp / 8);
      const di = (y * w + x) * 4;
      out[di] = buf[si + 2]; out[di + 1] = buf[si + 1]; out[di + 2] = buf[si]; out[di + 3] = bpp === 32 ? buf[si + 3] : 255;
    }
  }
  return { width: w, height: h, data: out };
}

function decodeImage(buf) {
  if (buf.length >= 8 && buf[0] === 137 && buf[1] === 80) return decodePNG(buf);
  if (buf.length >= 2 && buf.toString("ascii", 0, 2) === "BM") return decodeBMP(buf);
  throw new Error("image: unknown format");
}

function composite(c, matte) {
  const a = c[3] / 255;
  return [
    Math.round(c[0] * a + matte[0] * (1 - a)),
    Math.round(c[1] * a + matte[1] * (1 - a)),
    Math.round(c[2] * a + matte[2] * (1 - a)),
    255
  ];
}

function getPixel(img, x, y) {
  x = Math.max(0, Math.min(img.width - 1, x));
  y = Math.max(0, Math.min(img.height - 1, y));
  const i = (Math.floor(y) * img.width + Math.floor(x)) * 4;
  return [img.data[i], img.data[i + 1], img.data[i + 2], img.data[i + 3]];
}

function sample(img, x, y, matte) {
  const x0 = Math.floor(x), y0 = Math.floor(y), x1 = x0 + 1, y1 = y0 + 1;
  const fx = x - x0, fy = y - y0;
  const p00 = composite(getPixel(img, x0, y0), matte), p10 = composite(getPixel(img, x1, y0), matte);
  const p01 = composite(getPixel(img, x0, y1), matte), p11 = composite(getPixel(img, x1, y1), matte);
  const out = [0, 0, 0, 255];
  for (let i = 0; i < 3; i++) {
    const a = p00[i] * (1 - fx) + p10[i] * fx;
    const b = p01[i] * (1 - fx) + p11[i] * fx;
    out[i] = Math.round(a * (1 - fy) + b * fy);
  }
  return out;
}

function resize(img, tw, th, method, matte) {
  const out = new Array(tw * th);
  let scaleX = img.width / tw, scaleY = img.height / th, ox = 0, oy = 0;
  if (method === 1 || method === 2) {
    const s = method === 1 ? Math.min(scaleX, scaleY) : Math.max(scaleX, scaleY);
    scaleX = scaleY = s;
    ox = (img.width - tw * s) / 2;
    oy = (img.height - th * s) / 2;
  }
  for (let y = 0; y < th; y++) {
    for (let x = 0; x < tw; x++) {
      const sx = ox + (x + 0.5) * scaleX - 0.5;
      const sy = oy + (y + 0.5) * scaleY - 0.5;
      if (method === 2 && (sx < 0 || sy < 0 || sx > img.width - 1 || sy > img.height - 1)) out[y * tw + x] = [...matte, 255];
      else out[y * tw + x] = sample(img, sx, sy, matte);
    }
  }
  return { width: tw, height: th, pixels: out };
}

function escFg(c) { return `\x1b[38;2;${c[0]};${c[1]};${c[2]}m`; }
function escBg(c) { return `\x1b[48;2;${c[0]};${c[1]};${c[2]}m`; }
function lum(c) { return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]; }

function renderNormal(r) {
  let s = "";
  for (let y = 0; y < r.height; y += 2) {
    for (let x = 0; x < r.width; x++) {
      const top = r.pixels[y * r.width + x];
      const bot = r.pixels[Math.min(y + 1, r.height - 1) * r.width + x];
      s += escBg(top) + escFg(bot) + "▄";
    }
    s += "\x1b[0m\n";
  }
  return s;
}

function renderDither(r, mode, matte, nobg) {
  const blocks = [" ", "░", "▒", "▓", "█"];
  const chars = " .,:;irsXA253hMHGS#9B&@";
  let s = "";
  for (let y = 0; y < r.height; y++) {
    for (let x = 0; x < r.width; x++) {
      const c = r.pixels[y * r.width + x];
      const l = lum(c) / 255;
      if (!nobg) s += escBg(matte);
      s += escFg(c);
      if (mode === 1) s += blocks[Math.max(0, Math.min(4, Math.round(l * 4)))];
      else s += chars[Math.max(0, Math.min(chars.length - 1, Math.round(l * (chars.length - 1))))];
    }
    s += "\x1b[0m\n";
  }
  return s;
}

function goWrap(text) {
  return text.split("\n").filter((_, i, a) => i < a.length - 1).map(line =>
    `fmt.Print("${line.replace(/\\/g, "\\\\").replace(/"/g, "\\\"").replace(/\x1b/g, "\\033")}\\n")\n`
  ).join("");
}

function readUrl(url) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith("https://") ? https : http;
    lib.get(url, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return resolve(readUrl(res.headers.location));
      if (res.statusCode !== 200) return reject(new Error(`Get "${url}": ${res.statusCode}`));
      const chunks = [];
      res.on("data", d => chunks.push(d));
      res.on("end", () => resolve(Buffer.concat(chunks)));
    }).on("error", reject);
  });
}

(async function main() {
  const opt = parseArgs(process.argv.slice(2));
  let buf;
  try {
    if (/^https?:\/\//.test(opt.path)) buf = await readUrl(opt.path);
    else buf = fs.readFileSync(opt.path);
    const img = decodeImage(buf);
    const targetH = opt.d === 0 ? opt.tr * 2 : opt.tr;
    const r = resize(img, opt.tc, targetH, opt.s, opt.matte);
    const text = opt.d === 0 ? renderNormal(r) : renderDither(r, opt.d, opt.matte, opt.nobg);
    process.stdout.write(opt.go ? goWrap(text) : text);
  } catch (e) {
    if (e && e.code === "ENOENT" && !/^https?:\/\//.test(opt.path)) die(`open ${opt.path}: no such file or directory`);
    die(e && e.message ? e.message : String(e));
  }
})();
