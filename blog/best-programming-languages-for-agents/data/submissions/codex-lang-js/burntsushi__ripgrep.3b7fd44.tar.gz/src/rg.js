#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const cp = require("child_process");

const VERSION = `ripgrep 14.1.1 (rev 719e15af5e)`;

const TYPE_GLOBS = {
  js: ["*.js", "*.jsx", "*.mjs", "*.cjs"],
  javascript: ["*.js", "*.jsx", "*.mjs", "*.cjs"],
  ts: ["*.ts", "*.tsx"],
  typescript: ["*.ts", "*.tsx"],
  py: ["*.py", "*.pyw"],
  python: ["*.py", "*.pyw"],
  rust: ["*.rs"],
  rs: ["*.rs"],
  c: ["*.c", "*.h"],
  cpp: ["*.cc", "*.cpp", "*.cxx", "*.hpp", "*.hh", "*.hxx"],
  h: ["*.h", "*.hpp", "*.hh", "*.hxx"],
  go: ["*.go"],
  java: ["*.java"],
  md: ["*.md", "*.markdown"],
  markdown: ["*.md", "*.markdown"],
  json: ["*.json"],
  html: ["*.html", "*.htm"],
  css: ["*.css"],
  sh: ["*.sh", "*.bash", "*.zsh"],
  toml: ["*.toml"],
  yaml: ["*.yaml", "*.yml"],
  xml: ["*.xml"],
  txt: ["*.txt"],
};

function shortHelp() {
  return `${VERSION}
Andrew Gallant <jamslam@gmail.com>

ripgrep (rg) recursively searches the current directory for lines matching
a regex pattern. By default, ripgrep will respect gitignore rules and
automatically skip hidden files/directories and binary files.

Use -h for short descriptions and --help for more details.

Project home page: https://github.com/BurntSushi/ripgrep

USAGE:
  rg [OPTIONS] PATTERN [PATH ...]

POSITIONAL ARGUMENTS:
  <PATTERN>   A regular expression used for searching.
  <PATH>...   A file or directory to search.

INPUT OPTIONS:
  -e, --regexp=PATTERN            A pattern to search for.
  -f, --file=PATTERNFILE          Search for patterns from the given file.

SEARCH OPTIONS:
  -F, --fixed-strings             Treat all patterns as literals.
  -i, --ignore-case               Case insensitive search.
  -v, --invert-match              Invert matching.
  -x, --line-regexp               Show matches surrounded by line boundaries.
  -S, --smart-case                Smart case search.
  -a, --text                      Search binary files as if they were text.
  -w, --word-regexp               Show matches surrounded by word boundaries.

FILTER OPTIONS:
  -g, --glob=GLOB                 Include or exclude file paths.
  -., --hidden                    Search hidden files and directories.
  -d, --max-depth=NUM             Descend at most NUM directories.
  -t, --type=TYPE                 Only search files matching TYPE.
  -T, --type-not=TYPE             Do not search files matching TYPE.
  -u, --unrestricted              Reduce the level of "smart" filtering.

OUTPUT OPTIONS:
  -A, --after-context=NUM         Show NUM lines after each match.
  -B, --before-context=NUM        Show NUM lines before each match.
  -C, --context=NUM               Show NUM lines before and after each match.
  --column                        Show column numbers.
  -n, --line-number               Show line numbers.
  -N, --no-line-number            Suppress line numbers.
  -0, --null                      Print a NUL byte after file paths.
  -o, --only-matching             Print only matched parts of a line.
  -q, --quiet                     Do not print anything to stdout.
  -r, --replace=TEXT              Replace matches with the given text.
  --sort=SORTBY                   Sort results in ascending order.
  --vimgrep                       Print results in a vim compatible format.
  -H, --with-filename             Print the file path with each matching line.
  -I, --no-filename               Never print the path with each matching line.

OUTPUT MODES:
  -c, --count                     Show count of matching lines for each file.
  --count-matches                 Show count of every match for each file.
  -l, --files-with-matches        Print the paths with at least one match.
  --files-without-match           Print the paths that contain zero matches.
  --json                          Show search results in a JSON Lines format.

OTHER BEHAVIORS:
  --files                         Print each file that would be searched.
  --type-list                     Show all supported file types.
  -V, --version                   Print ripgrep's version.
`;
}

function versionText() {
  return `${VERSION}

features:-pcre2
simd(compile):+SSE2,-SSSE3,-AVX2
simd(runtime):+SSE2,+SSSE3,+AVX2

PCRE2 is not available in this build of ripgrep.
`;
}

function die(msg, code = 2) {
  process.stderr.write(`rg: ${msg}\n`);
  process.exit(code);
}

function nextArg(args, i, flag) {
  if (i + 1 >= args.length) die(`The argument '${flag}' requires a value but none was supplied`);
  return args[i + 1];
}

function defaultOpts() {
  return {
    patterns: [], patternFiles: [], paths: [], globs: [], types: [], notTypes: [],
    fixed: false, ignoreCase: false, smartCase: false, invert: false, word: false, line: false,
    hidden: false, unrestricted: 0, text: false, maxDepth: Infinity, maxCount: Infinity,
    files: false, typeList: false, count: false, countMatches: false, filesWithMatches: false,
    filesWithoutMatch: false, json: false, lineNumber: false, noLineNumber: false, column: false,
    withFilename: null, onlyMatching: false, quiet: false, null: false, replace: null, byteOffset: false,
    before: 0, after: 0, passthru: false, sort: null, sortr: null, trim: false,
    noMessages: false, includeZero: false, stats: false, vimgrep: false, color: "never", generate: null,
  };
}

function parseArgs(argv) {
  if (process.env.RIPGREP_CONFIG_PATH && !argv.includes("--no-config")) {
    try {
      const cfg = fs.readFileSync(process.env.RIPGREP_CONFIG_PATH, "utf8")
        .split(/\r?\n/).map(s => s.trim()).filter(s => s && !s.startsWith("#"));
      argv = cfg.concat(argv);
    } catch (_) {}
  }
  const o = defaultOpts();
  let positionalMode = false;
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (positionalMode) { o.paths.push(a); continue; }
    if (a === "--") { positionalMode = true; continue; }
    if (a === "-h" || a === "--help") { process.stdout.write(shortHelp()); process.exit(0); }
    if (a === "-V" || a === "--version") { process.stdout.write(versionText()); process.exit(0); }
    if (a === "--pcre2-version") die("PCRE2 is not available in this build of ripgrep.");
    if (a === "--type-list") { o.typeList = true; continue; }
    if (a === "--files") { o.files = true; continue; }
    if (a.startsWith("--")) {
      const eq = a.indexOf("=");
      const name = eq >= 0 ? a.slice(0, eq) : a;
      const val = eq >= 0 ? a.slice(eq + 1) : null;
      const need = () => val !== null ? val : (i++, nextArg(argv, i - 1, name));
      switch (name) {
        case "--regexp": o.patterns.push(need()); break;
        case "--file": o.patternFiles.push(need()); break;
        case "--fixed-strings": o.fixed = true; break;
        case "--ignore-case": o.ignoreCase = true; break;
        case "--case-sensitive": o.ignoreCase = false; o.smartCase = false; break;
        case "--smart-case": o.smartCase = true; break;
        case "--invert-match": o.invert = true; break;
        case "--word-regexp": o.word = true; break;
        case "--line-regexp": o.line = true; break;
        case "--hidden": o.hidden = true; break;
        case "--unrestricted": o.unrestricted++; break;
        case "--text": o.text = true; break;
        case "--binary": o.text = true; break;
        case "--glob": o.globs.push(need()); break;
        case "--iglob": o.globs.push(need()); break;
        case "--type": o.types.push(need()); break;
        case "--type-not": o.notTypes.push(need()); break;
        case "--max-depth": o.maxDepth = Number(need()); break;
        case "--max-count": o.maxCount = Number(need()); break;
        case "--count": o.count = true; break;
        case "--count-matches": o.countMatches = true; o.count = false; break;
        case "--files-with-matches": o.filesWithMatches = true; break;
        case "--files-without-match": o.filesWithoutMatch = true; break;
        case "--json": o.json = true; o.stats = true; break;
        case "--line-number": o.lineNumber = true; break;
        case "--no-line-number": o.noLineNumber = true; break;
        case "--column": o.column = true; break;
        case "--byte-offset": o.byteOffset = true; break;
        case "--with-filename": o.withFilename = true; break;
        case "--no-filename": o.withFilename = false; break;
        case "--only-matching": o.onlyMatching = true; break;
        case "--quiet": o.quiet = true; break;
        case "--null": o.null = true; break;
        case "--replace": o.replace = need(); break;
        case "--after-context": o.after = Number(need()); break;
        case "--before-context": o.before = Number(need()); break;
        case "--context": o.before = o.after = Number(need()); break;
        case "--passthru": case "--passthrough": o.passthru = true; break;
        case "--sort": o.sort = need(); break;
        case "--sortr": o.sortr = need(); break;
        case "--sort-files": o.sort = "path"; break;
        case "--trim": o.trim = true; break;
        case "--no-messages": o.noMessages = true; break;
        case "--include-zero": o.includeZero = true; break;
        case "--stats": o.stats = true; break;
        case "--vimgrep": o.vimgrep = true; o.lineNumber = true; o.column = true; break;
        case "--color": o.color = need(); break;
        case "--colors": need(); break;
        case "--no-ignore": case "--no-ignore-vcs": case "--no-ignore-dot": case "--no-config":
        case "--mmap": case "--no-mmap": case "--crlf": case "--no-crlf": case "--multiline":
        case "--multiline-dotall": case "--no-unicode": case "--unicode": case "--null-data":
        case "--no-heading": case "--heading": case "--block-buffered": case "--line-buffered":
        case "--search-zip": case "--no-search-zip": case "--follow": case "--no-ignore-messages":
        case "--debug": case "--trace": case "--auto-hybrid-regex": case "--pcre2":
          if (val !== null) { /* accepted no-op */ }
          break;
        case "--engine":
        case "--encoding":
        case "--pre":
        case "--pre-glob":
        case "--dfa-size-limit":
        case "--regex-size-limit":
        case "--max-filesize":
        case "--path-separator":
        case "--context-separator":
        case "--field-context-separator":
        case "--field-match-separator":
        case "--type-add":
        case "--type-clear":
        case "--threads":
        case "--generate":
          o.generate = need(); break;
        case "--max-columns":
          need(); break;
        default: die(`unrecognized flag ${a}`);
      }
      continue;
    }
    if (a.startsWith("-") && a !== "-") {
      for (let j = 1; j < a.length; j++) {
        const c = a[j];
        const rest = a.slice(j + 1);
        const needShort = () => {
          if (rest) { j = a.length; return rest; }
          i++; return nextArg(argv, i - 1, `-${c}`);
        };
        switch (c) {
          case "e": o.patterns.push(needShort()); break;
          case "f": o.patternFiles.push(needShort()); break;
          case "F": o.fixed = true; break;
          case "i": o.ignoreCase = true; break;
          case "s": o.ignoreCase = false; o.smartCase = false; break;
          case "S": o.smartCase = true; break;
          case "v": o.invert = true; break;
          case "w": o.word = true; break;
          case "x": o.line = true; break;
          case ".": o.hidden = true; break;
          case "u": o.unrestricted++; break;
          case "a": o.text = true; break;
          case "g": o.globs.push(needShort()); break;
          case "t": o.types.push(needShort()); break;
          case "T": o.notTypes.push(needShort()); break;
          case "d": o.maxDepth = Number(needShort()); break;
          case "m": o.maxCount = Number(needShort()); break;
          case "c": o.count = true; break;
          case "l": o.filesWithMatches = true; break;
          case "n": o.lineNumber = true; break;
          case "N": o.noLineNumber = true; break;
          case "b": o.byteOffset = true; break;
          case "H": o.withFilename = true; break;
          case "I": o.withFilename = false; break;
          case "o": o.onlyMatching = true; break;
          case "q": o.quiet = true; break;
          case "0": o.null = true; break;
          case "r": o.replace = needShort(); break;
          case "A": o.after = Number(needShort()); break;
          case "B": o.before = Number(needShort()); break;
          case "C": o.before = o.after = Number(needShort()); break;
          case "p": o.color = "always"; o.lineNumber = true; break;
          case "P": break;
          case "z": break;
          case "L": break;
          case "U": break;
          case "E": needShort(); break;
          case "M": needShort(); break;
          case "j": needShort(); break;
          default: die(`unrecognized flag -${c}`);
        }
      }
      continue;
    }
    if (o.patterns.length === 0 && o.patternFiles.length === 0 && !o.files && !o.typeList) {
      o.patterns.push(a);
    } else {
      o.paths.push(a);
    }
  }
  for (const pf of o.patternFiles) {
    const txt = pf === "-" ? fs.readFileSync(0, "utf8") : fs.readFileSync(pf, "utf8");
    for (const line of txt.split(/\r?\n/)) {
      if (line.endsWith("\r")) o.patterns.push(line.slice(0, -1));
      else if (line.length || txt.endsWith("\n")) o.patterns.push(line);
    }
  }
  if (o.generate) {
    if (o.generate === "man") process.stdout.write(".TH RG 1\n.SH NAME\nrg \\- recursively search current directory\n");
    else process.stdout.write(`# completion for rg (${o.generate})\n`);
    process.exit(0);
  }
  if (!o.files && !o.typeList && o.patterns.length === 0) {
    die("ripgrep requires at least one pattern to execute a search");
  }
  if (o.unrestricted >= 2) o.hidden = true;
  if (o.unrestricted >= 3) o.text = true;
  return o;
}

function escapeRegex(s) { return s.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&"); }

function compileRegex(o) {
  if (o.patterns.length === 0) return null;
  const flags = "g" + ((o.ignoreCase || (o.smartCase && !o.patterns.some(p => /[A-Z]/.test(p)))) ? "i" : "");
  let parts = o.patterns.map(p => o.fixed ? escapeRegex(p) : p);
  if (o.word) parts = parts.map(p => `(?<![A-Za-z0-9_])(?:${p})(?![A-Za-z0-9_])`);
  if (o.line) parts = parts.map(p => `^(?:${p})$`);
  try {
    return new RegExp(parts.length === 1 ? parts[0] : `(?:${parts.join("|")})`, flags);
  } catch (e) {
    process.stderr.write(`rg: regex parse error:\n    ${parts[0] || ""}\nerror: ${e.message}\n`);
    process.exit(2);
  }
}

function globToRe(glob) {
  let neg = false;
  if (glob.startsWith("!")) { neg = true; glob = glob.slice(1); }
  let s = "^";
  for (let i = 0; i < glob.length; i++) {
    const ch = glob[i];
    if (ch === "*") {
      if (glob[i + 1] === "*") { s += ".*"; i++; }
      else s += "[^/]*";
    } else if (ch === "?") s += "[^/]";
    else if (ch === "/") s += "\\/";
    else s += escapeRegex(ch);
  }
  s += "$";
  return { neg, re: new RegExp(s) };
}

function matchesAnyGlob(rel, globs) {
  if (!globs.length) return true;
  let hasPositive = globs.some(g => !g.neg);
  let ok = !hasPositive;
  for (const g of globs) {
    if (g.re.test(rel) || g.re.test(path.basename(rel))) ok = g.neg ? false : true;
  }
  return ok;
}

function ignoredBy(rel, globs) {
  let ignored = false;
  for (const g of globs) {
    if (g.re.test(rel) || g.re.test(path.basename(rel))) ignored = !g.neg;
  }
  return ignored;
}

function isHiddenName(name) { return name.startsWith(".") && name !== "." && name !== ".."; }

function loadIgnorePatterns(dir) {
  const pats = [];
  for (const name of [".ignore", ".rgignore", ".gitignore"]) {
    const p = path.join(dir, name);
    try {
      const txt = fs.readFileSync(p, "utf8");
      for (let line of txt.split(/\r?\n/)) {
        line = line.trim();
        if (!line || line.startsWith("#")) continue;
        pats.push(globToRe(line.replace(/^\//, "").replace(/\/$/, "")));
      }
    } catch (_) {}
  }
  return pats;
}

function typeMatches(file, types) {
  if (!types.length) return true;
  const base = path.basename(file);
  return types.some(t => (TYPE_GLOBS[t] || []).some(g => globToRe(g).re.test(base)));
}

function walk(start, displayRoot, o, out, depth = 0, inheritedIgnores = []) {
  let st;
  try { st = fs.statSync(start); } catch (e) { if (!o.noMessages) process.stderr.write(`rg: ${start}: ${e.message}\n`); return; }
  const name = path.basename(start);
  if (depth > 0 && !o.hidden && isHiddenName(name)) return;
  if (st.isDirectory()) {
    if (depth > o.maxDepth) return;
    const ignores = o.unrestricted >= 1 ? inheritedIgnores : inheritedIgnores.concat(loadIgnorePatterns(start));
    let ents;
    try { ents = fs.readdirSync(start); } catch (e) { if (!o.noMessages) process.stderr.write(`rg: ${start}: ${e.message}\n`); return; }
    for (const ent of ents) {
      const full = path.join(start, ent);
      const rel = path.relative(displayRoot.base, full).split(path.sep).join("/");
      if (ignores.length && ignoredBy(rel, ignores)) continue;
      walk(full, displayRoot, o, out, depth + 1, ignores);
    }
  } else if (st.isFile()) {
    const rel = path.relative(displayRoot.base, start).split(path.sep).join("/");
    let disp = rel || path.basename(start);
    if (displayRoot.dotPrefix && !disp.startsWith(".")) disp = `./${disp}`;
    const gRel = disp.replace(/^\.\//, "");
    if (!matchesAnyGlob(gRel, o._globs)) return;
    if (!typeMatches(start, o.types) || (o.notTypes.length && typeMatches(start, o.notTypes))) return;
    out.push({ full: start, display: disp, stat: st });
  }
}

function collectFiles(o) {
  const hadExplicitPaths = o.paths.length > 0;
  const paths = hadExplicitPaths ? o.paths : ["."];
  const files = [];
  for (const p of paths) {
    if (p === "-") {
      files.push({ full: "-", display: "<stdin>", stdin: true, stat: { mtimeMs: 0, atimeMs: 0, birthtimeMs: 0 } });
      continue;
    }
    const full = path.resolve(p);
    let st;
    try { st = fs.statSync(full); } catch (e) { if (!o.noMessages) process.stderr.write(`rg: ${p}: ${e.message}\n`); continue; }
    if (st.isDirectory()) {
      walk(full, { base: full, dotPrefix: hadExplicitPaths && (p === "." || p.startsWith("./")) }, o, files);
    } else if (st.isFile()) {
      files.push({ full, display: p, stat: st });
    }
  }
  if (o.sort === "path" || o.sort === "none" || o.sort === "modified" || o.sort === "accessed" || o.sort === "created") {
    files.sort((a, b) => sortCmp(a, b, o.sort));
  } else if (o.sortr) {
    files.sort((a, b) => -sortCmp(a, b, o.sortr));
  }
  return files;
}

function sortCmp(a, b, by) {
  if (by === "modified") return a.stat.mtimeMs - b.stat.mtimeMs || a.display.localeCompare(b.display);
  if (by === "accessed") return a.stat.atimeMs - b.stat.atimeMs || a.display.localeCompare(b.display);
  if (by === "created") return a.stat.birthtimeMs - b.stat.birthtimeMs || a.display.localeCompare(b.display);
  return a.display.localeCompare(b.display);
}

function isBinary(buf) {
  const n = Math.min(buf.length, 8192);
  for (let i = 0; i < n; i++) if (buf[i] === 0) return true;
  return false;
}

function splitLines(s) {
  const raw = s.split(/\n/);
  if (raw.length && raw[raw.length - 1] === "") raw.pop();
  return raw.map(x => x.endsWith("\r") ? x.slice(0, -1) : x);
}

function execMatches(re, line) {
  const ms = [];
  re.lastIndex = 0;
  let m;
  while ((m = re.exec(line)) !== null) {
    ms.push({ text: m[0], index: m.index });
    if (m[0] === "") re.lastIndex++;
  }
  return ms;
}

function substReplacement(rep, m) {
  return rep.replace(/\$\$|\$(\d+)|\$\{(\d+)\}/g, (x, a, b) => {
    if (x === "$$") return "$";
    return m[Number(a || b)] || "";
  });
}

function prefixFor(file, lineNo, col, byte, useFile, sep = ":") {
  let p = "";
  if (useFile) p += file + sep;
  if (byte !== null) p += byte + sep;
  if (lineNo !== null) p += lineNo + sep;
  if (col !== null) p += col + sep;
  return p;
}

function searchOne(file, content, re, o, useFile) {
  const lines = splitLines(content);
  const results = [];
  let matchedLines = 0, matchCount = 0, emittedForMax = 0;
  const matchedLineSet = new Set();
  let byteBase = 0;
  for (let i = 0; i < lines.length; i++) {
    const line = o.trim ? lines[i].replace(/^[ \t]+/, "") : lines[i];
    const ms = execMatches(re, line);
    let ok = ms.length > 0;
    if (o.invert) ok = !ok;
    if (ok) {
      matchedLineSet.add(i);
      matchedLines++;
      matchCount += o.invert ? 1 : ms.length;
      if (matchedLines <= o.maxCount) {
        if (o.onlyMatching && !o.invert) {
          for (const m of ms) results.push({ lineNo: i + 1, col: m.index + 1, byte: byteBase + Buffer.byteLength(line.slice(0, m.index)), text: o.replace !== null ? substReplacement(o.replace, [m.text]) : m.text, match: true });
        } else {
          let text = line;
          if (o.replace !== null && !o.invert) text = line.replace(re, (...args) => substReplacement(o.replace, args));
          results.push({ lineNo: i + 1, col: ms[0] ? ms[0].index + 1 : 1, byte: byteBase + (ms[0] ? Buffer.byteLength(line.slice(0, ms[0].index)) : 0), text, match: true });
        }
      }
      emittedForMax++;
    } else if (o.passthru) {
      results.push({ lineNo: i + 1, col: null, byte: byteBase, text: line, match: false });
    }
    byteBase += Buffer.byteLength(lines[i]) + 1;
  }
  if ((o.before || o.after) && !o.onlyMatching && !o.count && !o.countMatches) {
    const want = new Set();
    for (const idx of matchedLineSet) {
      for (let j = Math.max(0, idx - o.before); j <= Math.min(lines.length - 1, idx + o.after); j++) want.add(j);
    }
    const contextual = Array.from(want).sort((a, b) => a - b).map(i => ({
      lineNo: i + 1, col: null, text: o.trim ? lines[i].replace(/^[ \t]+/, "") : lines[i], match: matchedLineSet.has(i)
    }));
    return { matched: matchedLines > 0, matchedLines, matchCount, results: contextual };
  }
  return { matched: matchedLines > 0, matchedLines, matchCount, results };
}

function printJson(type, obj) {
  process.stdout.write(JSON.stringify(Object.assign({ type }, obj)) + "\n");
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  o._globs = o.globs.map(globToRe);
  if (o.typeList) {
    for (const k of Object.keys(TYPE_GLOBS).sort()) process.stdout.write(`${k}:${TYPE_GLOBS[k].join(",")}\n`);
    return;
  }
  const files = collectFiles(o);
  if (o.files) {
    for (const f of files) process.stdout.write(f.display + (o.null ? "\0" : "\n"));
    return;
  }
  const re = compileRegex(o);
  let stdinStat = null;
  try { stdinStat = fs.fstatSync(0); } catch (_) {}
  const pipedStdin = stdinStat && !stdinStat.isCharacterDevice();
  let useStdin = o.paths.length === 0 && pipedStdin;
  const useFileDefault = o.withFilename !== null ? o.withFilename : (!useStdin && (files.length !== 1 || o.paths.length === 0));
  let any = false, searched = 0, filesWith = 0, totalMatchedLines = 0;
  const inputs = [];
  if (useStdin) {
    inputs.push({ full: "-", display: "<stdin>", stdin: true });
  } else {
    inputs.push(...files);
  }
  for (const f of inputs) {
    let buf;
    try { buf = f.stdin ? fs.readFileSync(0) : fs.readFileSync(f.full); }
    catch (e) { if (!o.noMessages) process.stderr.write(`rg: ${f.display}: ${e.message}\n`); continue; }
    if (!o.text && !f.stdin && isBinary(buf)) continue;
    searched++;
    const content = buf.toString("utf8");
    const r = searchOne(f.display, content, re, o, useFileDefault);
    if (r.matched) { any = true; filesWith++; }
    totalMatchedLines += r.matchedLines;
    if (o.quiet && r.matched) process.exit(0);
    if (o.json) {
      if (r.matched) printJson("begin", { data: { path: { text: f.display } } });
      for (const row of r.results.filter(x => x.match)) {
        printJson("match", { data: { path: { text: f.display }, lines: { text: row.text + "\n" }, line_number: row.lineNo, absolute_offset: 0, submatches: [{ match: { text: row.text }, start: Math.max(0, row.col - 1), end: Math.max(0, row.col - 1) + row.text.length }] } });
      }
      if (r.matched) printJson("end", { data: { path: { text: f.display }, binary_offset: null, stats: {} } });
      continue;
    }
    if (o.filesWithMatches || o.filesWithoutMatch) {
      if ((o.filesWithMatches && r.matched) || (o.filesWithoutMatch && !r.matched)) process.stdout.write(f.display + (o.null ? "\0" : "\n"));
      continue;
    }
    if (o.count || o.countMatches) {
      const n = o.countMatches || (o.count && o.onlyMatching) ? r.matchCount : r.matchedLines;
      if (n > 0 || o.includeZero) process.stdout.write((useFileDefault ? `${f.display}:` : "") + n + "\n");
      continue;
    }
    for (const row of r.results) {
      if (!row.match && !o.passthru && !(o.before || o.after)) continue;
      const lineNo = (o.lineNumber && !o.noLineNumber) || o.vimgrep ? row.lineNo : null;
      const col = (o.column || o.vimgrep) && row.match ? row.col : null;
      const byte = o.byteOffset && row.match ? (row.byte || 0) : null;
      process.stdout.write(prefixFor(f.display, lineNo, col, byte, useFileDefault) + row.text + "\n");
    }
  }
  if (o.json) printJson("summary", { data: { elapsed_total: { human: "0.000s", nanos: 0, secs: 0 }, stats: { bytes_searched: 0, bytes_printed: 0, matched_lines: totalMatchedLines, matches: totalMatchedLines, searches: searched, searches_with_match: filesWith } } });
  if (o.stats && !o.json && !o.filesWithMatches && !o.filesWithoutMatch && !o.files) {
    process.stdout.write(`\n${totalMatchedLines} matched lines\n${filesWith} files contained matches\n${searched} files searched\n0.000000 seconds spent searching\n`);
  }
  process.exit(any ? 0 : 1);
}

main();
