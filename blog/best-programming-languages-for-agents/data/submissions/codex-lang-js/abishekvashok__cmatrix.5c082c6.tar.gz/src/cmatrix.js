#!/usr/bin/env node
"use strict";

const fs = require("fs");

const HELP = ` Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
`;

const VERSION = ` CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)
Email: abishekvashok@gmail.com
Web: https://github.com/abishekvashok/cmatrix
`;

const VALID_COLORS = new Map([
  ["green", 32],
  ["red", 31],
  ["blue", 34],
  ["white", 37],
  ["yellow", 33],
  ["cyan", 36],
  ["magenta", 35],
  ["black", 30],
]);

const MATRIX_CHARS =
  "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*()[]{}<>/\\|=-+;:";
const JAPANESEish = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ";

function printHelp() {
  process.stdout.write(HELP);
}

function parseArgs(argv) {
  const opts = {
    async: false,
    bold: 0,
    japanese: false,
    oldStyle: false,
    screensaver: false,
    x: false,
    linux: false,
    force: false,
    lock: false,
    rainbow: false,
    lambda: false,
    change: false,
    delay: 4,
    colorName: "green",
    color: 32,
    message: null,
    tty: null,
  };

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--help" || arg === "--version") {
      printHelp();
      process.exit(0);
    }
    if (!arg.startsWith("-") || arg === "-") {
      printHelp();
      process.exit(0);
    }
    for (let j = 1; j < arg.length; j++) {
      const ch = arg[j];
      switch (ch) {
        case "a": opts.async = true; break;
        case "b": opts.bold = Math.max(opts.bold, 1); break;
        case "B": opts.bold = 2; break;
        case "c": opts.japanese = true; break;
        case "f": opts.force = true; break;
        case "h":
        case "?":
          printHelp();
          process.exit(0);
          break;
        case "l": opts.linux = true; break;
        case "L": opts.lock = true; break;
        case "o": opts.oldStyle = true; break;
        case "n": opts.bold = 0; break;
        case "s": opts.screensaver = true; break;
        case "x": opts.x = true; break;
        case "V":
          process.stdout.write(VERSION);
          process.exit(0);
          break;
        case "r": opts.rainbow = true; break;
        case "m": opts.lambda = true; break;
        case "k": opts.change = true; break;
        case "u": {
          const value = j < arg.length - 1 ? arg.slice(j + 1) : argv[++i];
          if (value === undefined) {
            printHelp();
            process.exit(0);
          }
          opts.delay = parseInt(value, 10);
          if (Number.isNaN(opts.delay)) opts.delay = 0;
          j = arg.length;
          break;
        }
        case "C": {
          const value = j < arg.length - 1 ? arg.slice(j + 1) : argv[++i];
          if (value === undefined) {
            printHelp();
            process.exit(0);
          }
          const color = VALID_COLORS.get(String(value).toLowerCase());
          if (color === undefined) {
            process.stdout.write(" Invalid color selection\n Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n");
            process.exit(0);
          }
          opts.colorName = String(value).toLowerCase();
          opts.color = color;
          j = arg.length;
          break;
        }
        case "M": {
          const value = j < arg.length - 1 ? arg.slice(j + 1) : argv[++i];
          if (value === undefined) {
            printHelp();
            process.exit(0);
          }
          opts.message = String(value);
          j = arg.length;
          break;
        }
        case "t": {
          const value = j < arg.length - 1 ? arg.slice(j + 1) : argv[++i];
          if (value === undefined) {
            printHelp();
            process.exit(0);
          }
          opts.tty = String(value);
          j = arg.length;
          break;
        }
        default:
          printHelp();
          process.exit(0);
      }
    }
  }
  if (opts.lock && !opts.message) opts.message = "Computer locked.";
  return opts;
}

function terminalLooksUsable() {
  const term = process.env.TERM || "unknown";
  return term !== "unknown" && term !== "dumb";
}

function size() {
  const cols = process.stdout.columns || parseInt(process.env.COLUMNS || "80", 10) || 80;
  const rows = process.stdout.rows || parseInt(process.env.LINES || "24", 10) || 24;
  return { cols, rows };
}

function write(s) {
  process.stdout.write(s);
}

function setupTerminal() {
  write("\x1b[?1049h\x1b[22;0;0t\x1b[1;24r\x1b(B\x1b[m\x1b[4l\x1b[?7h\x1b[?25l\x1b[39;49m\x1b[39;49m\x1b(B\x1b[m\x1b[H\x1b[2J");
  if (process.stdin.isTTY) {
    try {
      process.stdin.setRawMode(true);
    } catch (_) {}
  }
  process.stdin.resume();
}

let cleaned = false;
function cleanup(exitCode) {
  if (cleaned) return;
  cleaned = true;
  if (process.stdin.isTTY) {
    try {
      process.stdin.setRawMode(false);
    } catch (_) {}
  }
  write("\x1b[?12l\x1b[?25h\x1b[H\x1b[2J\x1b[24;1H\x1b[?1049l\x1b[23;0;0t\r\x1b[?1l\x1b>");
  process.exit(exitCode);
}

function lcg(seed) {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 0x100000000;
  };
}

function colorFor(opts, col, row, tick) {
  if (!opts.rainbow) return opts.color;
  const colors = [31, 33, 32, 36, 34, 35, 37];
  return colors[(col + row + tick) % colors.length];
}

function charFor(opts, rnd) {
  if (opts.lambda) return "λ";
  const alphabet = opts.japanese ? JAPANESEish : MATRIX_CHARS;
  return alphabet[Math.floor(rnd() * alphabet.length) % alphabet.length];
}

function drawFrame(opts, state, rnd) {
  const { cols, rows } = size();
  const tick = state.tick++;
  if (tick === 0) {
    write(`\x1b[${opts.color}m`);
    for (let r = 1; r <= rows; r++) {
      write((r === 1 ? "" : `\r\x1b[${r}d`) + " ".repeat(cols));
    }
  }

  let out = "";
  const density = opts.oldStyle ? 0.11 : 0.07;
  const speed = opts.async ? 1 + (tick % 3) : 1;
  for (let col = 1; col <= cols; col += 2) {
    if (rnd() > density) continue;
    const head = (Math.floor((tick * speed + state.offsets[col]) % (rows + 12)) - 6);
    const trail = opts.oldStyle ? 8 : 14;
    for (let k = 0; k < trail; k++) {
      const row = head - k;
      if (row < 1 || row > rows) continue;
      const color = k === 0 ? 37 : colorFor(opts, col, row, tick);
      const bold = opts.bold === 2 || (opts.bold === 1 && rnd() > 0.82);
      const text = k === 0 && !opts.japanese && !opts.lambda ? " " : charFor(opts, rnd);
      out += `\x1b[${row};${col}H\x1b[${bold ? "1;" : ""}${color}m${text}`;
    }
  }

  if (opts.message) {
    const msg = opts.message;
    const row = Math.max(1, Math.floor(rows / 2));
    const col = Math.max(1, Math.floor((cols - msg.length) / 2));
    out += `\x1b[${row};${col}H\x1b[37m${msg}`;
  }
  write(out);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (!terminalLooksUsable()) {
    process.stderr.write("Error opening terminal: unknown.\n");
    process.exit(1);
  }

  let initialInput = Buffer.alloc(0);
  if (!process.stdin.isTTY) {
    try {
      initialInput = fs.readFileSync(0);
    } catch (_) {
      initialInput = Buffer.alloc(0);
    }
  }

  setupTerminal();
  const rnd = lcg(Date.now() ^ process.pid);
  const { cols } = size();
  const state = { tick: 0, offsets: Array.from({ length: cols + 2 }, () => Math.floor(rnd() * 80)) };

  const handleInput = (buf) => {
    for (const b of buf) {
      const ch = String.fromCharCode(b);
      if (opts.screensaver || ch === "q") cleanup(0);
      if (ch === "a") opts.async = !opts.async;
      else if (ch === "b") opts.bold = 1;
      else if (ch === "B") opts.bold = 2;
      else if (ch === "n") opts.bold = 0;
      else if (ch >= "0" && ch <= "9") opts.delay = ch.charCodeAt(0) - 48;
      else if (ch === "!") opts.color = 31;
      else if (ch === "@") opts.color = 32;
      else if (ch === "#") opts.color = 33;
      else if (ch === "$") opts.color = 34;
      else if (ch === "%") opts.color = 35;
      else if (ch === "^") opts.color = 36;
      else if (ch === "&") opts.color = 37;
      else if (ch === ")") opts.color = 30;
    }
  };

  if (initialInput.length) handleInput(initialInput);
  process.stdin.on("data", handleInput);

  process.on("SIGINT", () => cleanup(0));
  process.on("SIGTERM", () => cleanup(0));
  process.on("SIGHUP", () => cleanup(0));

  const loop = () => {
    drawFrame(opts, state, rnd);
    setTimeout(loop, Math.max(5, 15 + opts.delay * 10));
  };
  setTimeout(loop, 0);
}

main();
