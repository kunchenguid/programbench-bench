const fs=require('fs');
fs.writeFileSync('executable',"#!/bin/bash\nDIR=\"$(cd \"$(dirname \"$0\")\" && pwd)\"\nexec node \"$DIR/src/jp2a.js\" \"$@\"\n");
fs.chmodSync('executable',0o755);
