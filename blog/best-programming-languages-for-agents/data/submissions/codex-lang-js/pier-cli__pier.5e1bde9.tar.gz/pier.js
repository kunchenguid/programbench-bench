#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const VERSION = 'pier 0.1.6';

const MAIN_HELP = `pier 0.1.6
Benjamin Scholtz, Isak Johansson
A simple script management CLI

USAGE:
    executable [FLAGS] [OPTIONS] <alias> [args]...
    executable [FLAGS] [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       
            Prints help information

    -V, --version    
            Prints version information

    -v, --verbose    
            The level of verbosity


OPTIONS:
    -c, --config-file <path>    
            Sets a custom config file.
            
            DEFAULT PATH is otherwise determined in this order:
            
            - $PIER_CONFIG_PATH (environment variable if set)
            
            - pier.toml (in the current directory)
            
            - $XDG_CONFIG_HOME/pier/config.toml
            
            - $XDG_CONFIG_HOME/pier/config
            
            - $XDG_CONFIG_HOME/pier.toml
            
            - $HOME/.pier.toml
            
            - $HOME/.pier
            
             [env: PIER_CONFIG_PATH=]

ARGS:
    <alias>      
            The alias or name for the script.

    <args>...    
            The positional arguments to send to script.


SUBCOMMANDS:
    add            Add a new script to config.
    config-init    alias: init - Add a config file.
    copy           alias: cp - Copy existing alias to the new one
    edit           Edit a script matching alias.
    help           Prints this message or the help of the given subcommand(s)
    list           alias: ls - List scripts
    move           alias: mv, rename - Move/rename existing alias to the new one
    remove         alias: rm - Remove a script matching alias.
    run            Run a script matching alias.
    show           Show a script matching alias.`;

const HELPS = {
  add: `executable-add 0.1.6
Add a new script to config.

USAGE:
    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]

FLAGS:
    -f, --force      Allows to overwrite the existing script
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -a, --alias <alias>                The alias or name for the script.
    -d, --description <description>    The description for the script.
    -t, --tag <tags>...                Set which tags the script belongs to.

ARGS:
    <command>    The command/script content to be executed. If this argument is not found it will open your $EDITOR
                 for you to enter the script into.`,
  'config-init': `executable-config-init 0.1.6
alias: init - Add a config file.

USAGE:
    executable config-init

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information`,
  copy: `executable-copy 0.1.6
alias: cp - Copy existing alias to the new one

USAGE:
    executable copy <from-alias> <to-alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <from-alias>    The alias of the script that will be copied.
    <to-alias>      The new alias of the copy of the script.`,
  edit: `executable-edit 0.1.6
Edit a script matching alias.

USAGE:
    executable edit <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.`,
  list: `executable-list 0.1.6
alias: ls - List scripts

Display options are determined by priority in this order:

1. List only aliases

2. Show full command

3. Command display with (cli option)

4. Command display with (config option)

USAGE:
    executable list [FLAGS] [OPTIONS]

FLAGS:
    -l, --cmd_full        
            Display the full command.

    -h, --help            
            Prints help information

    -q, --list_aliases    
            Only displays aliases of the scripts.

    -V, --version         
            Prints version information


OPTIONS:
    -c, --cmd_width <cmd-width>    
            The max number of characters to display from the command.

    -t, --tag <tags>...            
            Filter based on tags.`,
  move: `executable-move 0.1.6
alias: mv, rename - Move/rename existing alias to the new one

USAGE:
    executable move [FLAGS] <from-alias> <to-alias>

FLAGS:
    -f, --force      Allows to overwrite the existing script
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <from-alias>    The alias of the script that will be moved.
    <to-alias>      The new alias of the script.`,
  remove: `executable-remove 0.1.6
alias: rm - Remove a script matching alias.

USAGE:
    executable remove <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.`,
  run: `executable-run 0.1.6
Run a script matching alias.

USAGE:
    executable run <alias> [args]...

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>      The alias or name for the script.
    <args>...    The positional arguments to send to script.`,
  show: `executable-show 0.1.6
Show a script matching alias.

USAGE:
    executable show <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.`
};

function println(s = '') { process.stdout.write(s + '\n'); }
function eprintln(s = '') { process.stderr.write(s + '\n'); }
function die(msg, code = 1) { eprintln(msg); process.exit(code); }

function unquote(v) {
  v = v.trim();
  if ((v.startsWith("'") && v.endsWith("'")) || (v.startsWith('"') && v.endsWith('"'))) {
    const q = v[0];
    let s = v.slice(1, -1);
    if (q === '"') s = s.replace(/\\n/g, '\n').replace(/\\"/g, '"').replace(/\\\\/g, '\\');
    return s.replace(/\\'/g, "'");
  }
  return v;
}

function tomlQuote(s) {
  return "'" + String(s).replace(/'/g, "\\'") + "'";
}

function findConfigPath(opts) {
  if (opts.configFile) return opts.configFile;
  if (process.env.PIER_CONFIG_PATH) return process.env.PIER_CONFIG_PATH;
  const candidates = [];
  candidates.push(path.join(process.cwd(), 'pier.toml'));
  const xdg = process.env.XDG_CONFIG_HOME || path.join(os.homedir(), '.config');
  candidates.push(path.join(xdg, 'pier', 'config.toml'));
  candidates.push(path.join(xdg, 'pier', 'config'));
  candidates.push(path.join(xdg, 'pier.toml'));
  candidates.push(path.join(os.homedir(), '.pier.toml'));
  candidates.push(path.join(os.homedir(), '.pier'));
  for (const c of candidates) if (fs.existsSync(c)) return c;
  return candidates[0];
}

function readConfig(file) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (err) {
    const msg = err && err.code === 'ENOENT' ? 'No such file or directory (os error 2)' : err.message;
    die(`error: Unable to read config from file ${file}: ${msg} `);
  }
  const cfg = { scripts: {}, default: {} };
  let cur = null;
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].trim();
    if (!line || line.startsWith('#')) continue;
    const sec = line.match(/^\[scripts\.([^\]]+)\]$/);
    if (sec) {
      cur = cfg.scripts[sec[1]] = cfg.scripts[sec[1]] || {};
      continue;
    }
    if (line === '[default]') {
      cur = cfg.default;
      continue;
    }
    if (!cur) continue;
    const m = line.match(/^([A-Za-z0-9_-]+)\s*=\s*(.*)$/);
    if (!m) continue;
    const key = m[1];
    let val = m[2].trim();
    if (val === '[') {
      const arr = [];
      while (++i < lines.length) {
        const t = lines[i].trim();
        if (t === ']') break;
        const item = t.replace(/,$/, '').trim();
        if (item) arr.push(unquote(item));
      }
      cur[key] = arr;
    } else if (val.startsWith('[') && val.endsWith(']')) {
      cur[key] = val.slice(1, -1).split(',').map(x => unquote(x)).filter(Boolean);
    } else {
      cur[key] = unquote(val);
    }
  }
  return cfg;
}

function writeConfig(file, cfg) {
  let out = '';
  for (const alias of Object.keys(cfg.scripts).sort()) {
    const s = cfg.scripts[alias] || {};
    out += `[scripts.${alias}]\n`;
    out += `command = ${tomlQuote(s.command || '')}\n`;
    if (s.description) out += `description = ${tomlQuote(s.description)}\n`;
    if (s.tags && s.tags.length) {
      out += 'tags = [\n';
      for (const t of s.tags) out += `    ${tomlQuote(t)},\n`;
      out += ']\n';
    }
    out += '\n';
  }
  out += '[default]\n';
  fs.writeFileSync(file, out);
}

function parseGlobal(argv) {
  const opts = { configFile: null, verbose: 0 };
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-c' || a === '--config-file') opts.configFile = argv[++i];
    else if (a === '-v' || a === '--verbose') opts.verbose++;
    else {
      rest.push(...argv.slice(i));
      break;
    }
  }
  return { opts, rest };
}

function needScript(cfg, alias) {
  if (!alias || !cfg.scripts[alias]) die(`error: AliasNotFound: No script found by alias ${alias}`);
  return cfg.scripts[alias];
}

function ensureCanWrite(cfg, alias, force) {
  if (cfg.scripts[alias] && !force) die(`error: AliasAlreadyExists:  ${alias}`);
}

function table(rows) {
  const headers = ['Alias', 'Tags', 'Command', 'Description'];
  const widths = headers.map(h => h.length);
  for (const r of rows) {
    widths[0] = Math.max(widths[0], r[0].length);
    widths[1] = Math.max(widths[1], r[1].length);
    widths[2] = Math.max(widths[2], r[2].length);
    widths[3] = Math.max(widths[3], r[3].length);
  }
  const lineLen = widths.reduce((a, b) => a + b, 0) + 15;
  const bar = '≖'.repeat(lineLen);
  const fmt = (r) => `⋮ ${r[0].padEnd(widths[0])} ⋮ ${r[1].padEnd(widths[1])} ⋮ ${r[2].padEnd(widths[2])} ⋮ ${r[3].padEnd(widths[3])} ⋮`;
  println(bar);
  println(fmt(headers));
  println(bar);
  for (const r of rows) println(fmt(r));
  println(bar);
}

function cmdList(argv, cfg) {
  let aliasesOnly = false, full = false, width = null;
  const tags = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') return println(HELPS.list);
    if (a === '-V' || a === '--version') return println(VERSION);
    if (a === '-q' || a === '--list_aliases') aliasesOnly = true;
    else if (a === '-l' || a === '--cmd_full') full = true;
    else if (a === '-c' || a === '--cmd_width') width = parseInt(argv[++i], 10);
    else if (a === '-t' || a === '--tag') tags.push(argv[++i]);
  }
  if (cfg.default) {
    if (!aliasesOnly && (cfg.default.list_aliases === 'true' || cfg.default.list_aliases === true)) aliasesOnly = true;
    if (!full && (cfg.default.cmd_full === 'true' || cfg.default.cmd_full === true)) full = true;
  }
  if (!full && width == null && cfg.default && cfg.default.cmd_width) {
    width = parseInt(cfg.default.cmd_width, 10);
  }
  if (!full && width == null && cfg.default && cfg.default.command_width) {
    width = parseInt(cfg.default.command_width, 10);
  }
  const aliases = Object.keys(cfg.scripts).sort().filter(a => {
    if (!tags.length) return true;
    const have = cfg.scripts[a].tags || [];
    return tags.some(t => have.includes(t));
  });
  if (aliasesOnly) {
    for (const a of aliases) println(a);
    return;
  }
  const rows = aliases.map(a => {
    const s = cfg.scripts[a];
    let cmd = s.command || '';
    if (!full && width && width >= 0) cmd = cmd.slice(0, width);
    return [a, (s.tags || []).join(','), cmd, s.description || ''];
  });
  table(rows);
}

function cmdAdd(argv, cfg, cfgFile) {
  let alias = null, description = null, force = false, command = null;
  const tags = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') return println(HELPS.add);
    if (a === '-V' || a === '--version') return println(VERSION);
    if (a === '-f' || a === '--force') force = true;
    else if (a === '-a' || a === '--alias') alias = argv[++i];
    else if (a === '-d' || a === '--description') description = argv[++i];
    else if (a === '-t' || a === '--tag') tags.push(argv[++i]);
    else if (a === '--') {
      command = argv.slice(i + 1).join(' ');
      break;
    }
    else if (!command) command = a;
    else die(`error: Found argument '${a}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFor more information try --help`);
  }
  if (!alias) die('error: The following required arguments were not provided:\n    --alias <alias>\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFor more information try --help');
  ensureCanWrite(cfg, alias, force);
  if (command == null) {
    const editor = process.env.EDITOR;
    if (!editor) command = '';
    else {
      const tmp = path.join(os.tmpdir(), `pier-${process.pid}.tmp`);
      spawnSync(editor, [tmp], { stdio: 'inherit' });
      command = fs.existsSync(tmp) ? fs.readFileSync(tmp, 'utf8').trimEnd() : '';
      try { fs.unlinkSync(tmp); } catch (_) {}
    }
  }
  cfg.scripts[alias] = { command };
  if (description) cfg.scripts[alias].description = description;
  if (tags.length) cfg.scripts[alias].tags = tags;
  writeConfig(cfgFile, cfg);
  println(`Added ${alias}`);
}

function cmdRun(argv, cfg) {
  if (argv[0] === '-h' || argv[0] === '--help') return println(HELPS.run);
  if (argv[0] === '-V' || argv[0] === '--version') return println(VERSION);
  const alias = argv[0];
  const s = needScript(cfg, alias);
  const res = spawnSync('/bin/bash', ['-c', s.command || '', alias, ...argv.slice(1)], { stdio: 'inherit', cwd: process.cwd(), env: process.env });
  if (res.signal) process.kill(process.pid, res.signal);
  process.exit(res.status == null ? 1 : res.status);
}

function main() {
  const { opts, rest } = parseGlobal(process.argv.slice(2));
  if (!rest.length || rest[0] === '-h' || rest[0] === '--help') return println(MAIN_HELP);
  if (rest[0] === '-V' || rest[0] === '--version') return println(VERSION);
  if (rest[0] === 'help') {
    const k = normalize(rest[1] || '');
    return println(k && HELPS[k] ? HELPS[k] : MAIN_HELP);
  }
  const cfgFile = findConfigPath(opts);
  const sub = normalize(rest[0]);
  if (sub === 'config-init') {
    if (rest[1] === '-h' || rest[1] === '--help') return println(HELPS['config-init']);
    if (rest[1] === '-V' || rest[1] === '--version') return println(VERSION);
    if (fs.existsSync(cfgFile)) die(`error: Cannot initialize config at ${cfgFile}, file already exists.`);
    fs.mkdirSync(path.dirname(cfgFile), { recursive: true });
    fs.writeFileSync(cfgFile, "[scripts.hello-pier]\ncommand = 'echo Hello, Pier!'\ndescription = 'This is an example command.'\n\n[default]\n");
    return println('Added hello-pier');
  }
  const cfg = readConfig(cfgFile);
  if (sub === 'list') return cmdList(rest.slice(1), cfg);
  if (sub === 'add') return cmdAdd(rest.slice(1), cfg, cfgFile);
  if (sub === 'run') return cmdRun(rest.slice(1), cfg);
  if (sub === 'show') {
    if (rest[1] === '-h' || rest[1] === '--help') return println(HELPS.show);
    if (rest[1] === '-V' || rest[1] === '--version') return println(VERSION);
    return println(needScript(cfg, rest[1]).command || '');
  }
  if (sub === 'remove') {
    if (rest[1] === '-h' || rest[1] === '--help') return println(HELPS.remove);
    const alias = rest[1]; needScript(cfg, alias); delete cfg.scripts[alias]; writeConfig(cfgFile, cfg); return println(`Removed ${alias}`);
  }
  if (sub === 'copy') {
    if (rest[1] === '-h' || rest[1] === '--help') return println(HELPS.copy);
    const from = rest[1], to = rest[2]; const s = needScript(cfg, from); ensureCanWrite(cfg, to, false);
    cfg.scripts[to] = JSON.parse(JSON.stringify(s)); writeConfig(cfgFile, cfg); return println(`Copy from alias ${from} to new alias ${to}`);
  }
  if (sub === 'move') {
    if (rest[1] === '-h' || rest[1] === '--help') return println(HELPS.move);
    let force = false; let args = rest.slice(1);
    if (args[0] === '-f' || args[0] === '--force') { force = true; args = args.slice(1); }
    const from = args[0], to = args[1]; const s = needScript(cfg, from); ensureCanWrite(cfg, to, force);
    cfg.scripts[to] = s; delete cfg.scripts[from]; writeConfig(cfgFile, cfg); return println(`Move from alias ${from} to new alias ${to}`);
  }
  if (sub === 'edit') {
    if (rest[1] === '-h' || rest[1] === '--help') return println(HELPS.edit);
    const alias = rest[1]; const s = needScript(cfg, alias);
    const editor = process.env.EDITOR || 'vi';
    const tmp = path.join(os.tmpdir(), `pier-${process.pid}.tmp`);
    fs.writeFileSync(tmp, s.command || '');
    spawnSync(editor, [tmp], { stdio: 'inherit' });
    s.command = fs.readFileSync(tmp, 'utf8').trimEnd();
    try { fs.unlinkSync(tmp); } catch (_) {}
    writeConfig(cfgFile, cfg);
    return;
  }
  return cmdRun(rest, cfg);
}

function normalize(s) {
  if (s === 'ls') return 'list';
  if (s === 'cp') return 'copy';
  if (s === 'mv' || s === 'rename') return 'move';
  if (s === 'rm') return 'remove';
  if (s === 'init') return 'config-init';
  return s;
}

main();
