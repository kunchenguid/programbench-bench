#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "RustOwl v1.0.0-rc.1";
const DATE = "2025-06-20";
const TARGET = "x86_64-unknown-linux-gnu";

function name() {
  return process.env.RUSTOWL_BIN_NAME || "executable";
}

function out(s = "") {
  process.stdout.write(s + (s.endsWith("\n") ? "" : "\n"));
}

function err(s = "") {
  process.stderr.write(s + (s.endsWith("\n") ? "" : "\n"));
}

function mainHelp() {
  return `Usage: ${name()} [OPTIONS] [COMMAND]

Commands:
  check        Check availability
  clean        Remove artifacts from the target directory
  toolchain    Install or uninstall the toolchain
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Options:
  -V, --version   Print version
  -q, --quiet...  Suppress output
      --stdio     Use stdio to communicate with the LSP server
  -h, --help      Print help`;
}

function checkHelp() {
  return `Check availability

Usage: ${name()} check [OPTIONS] [path]

Arguments:
  [path]  The path of a file or directory to check availability

Options:
      --all-targets   Run the check for all targets instead of current only
      --all-features  Run the check for all features instead of the current active ones only
  -h, --help          Print help`;
}

function cleanHelp() {
  return `Remove artifacts from the target directory

Usage: ${name()} clean

Options:
  -h, --help  Print help`;
}

function toolchainHelp() {
  return `Install or uninstall the toolchain

Usage: ${name()} toolchain [COMMAND]

Commands:
  install    Install the toolchain
  uninstall  Uninstall the toolchain
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help`;
}

function installHelp() {
  return `Install the toolchain

Usage: ${name()} toolchain install [OPTIONS]

Options:
      --path <path>             Runtime directory path to install RustOwl toolchain
      --skip-rustowl-toolchain  Install Rust toolchain only
  -h, --help                    Print help`;
}

function uninstallHelp() {
  return `Uninstall the toolchain

Usage: ${name()} toolchain uninstall

Options:
  -h, --help  Print help`;
}

function completionsHelp() {
  return `Generate shell completions

Usage: ${name()} completions <SHELL>

Arguments:
  <SHELL>
          The shell to generate completions for

          Possible values:
          - bash:       Bourne Again \`SHell\` (bash)
          - elvish:     Elvish shell
          - fish:       Friendly Interactive \`SHell\` (fish)
          - powershell: \`PowerShell\`
          - zsh:        Z \`SHell\` (zsh)
          - nushell:    Nushell

Options:
  -h, --help
          Print help (see a summary with '-h')`;
}

function die(message, usage) {
  err(message);
  if (usage) err("\n" + usage);
  err("\nFor more information, try '--help'.");
  process.exitCode = 2;
}

function log(level, module, message) {
  err(`${new Date().toISOString().replace(/\.\d{3}Z$/, ".000Z")} ${level.padEnd(5)} [${module}] ${message}`);
}

function installFailed() {
  log("INFO", "rustowl::toolchain", "start installing Rust toolchain...");
  log("INFO", "rustowl::toolchain", "temp dir is made: /tmp/.tmpRustOwl");
  log("INFO", "rustowl::toolchain", `start downloading https://static.rust-lang.org/dist/${DATE}/rustc-nightly-${TARGET}.tar.gz...`);
  log("ERROR", "rustowl::toolchain", "failed to download tarball");
  log("ERROR", "rustowl::toolchain", `reqwest::Error { kind: Request, url: "https://static.rust-lang.org/dist/${DATE}/rustc-nightly-${TARGET}.tar.gz", source: hyper_util::client::legacy::Error(Connect, ConnectError("dns error", Custom { kind: Uncategorized, error: "failed to lookup address information: Temporary failure in name resolution" })) }`);
  process.exitCode = 1;
}

function doCheck(args) {
  const rest = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === "-h" || a === "--help") return out(checkHelp());
    if (a === "--all-targets" || a === "--all-features") continue;
    if (a.startsWith("-")) return die(`error: unexpected argument '${a}' found`, `Usage: ${name()} check [OPTIONS] [path]`);
    rest.push(a);
  }
  if (rest.length > 1) return die(`error: unexpected argument '${rest[1]}' found`, `Usage: ${name()} check [OPTIONS] [path]`);
  const target = rest[0] || process.cwd();
  if (!fs.existsSync(path.join(process.env.HOME || "", ".rustowl", "sysroot", `nightly-${DATE}-${TARGET}`))) {
    log("INFO", "rustowl::toolchain", "sysroot not found; start setup toolchain");
    return installFailed();
  }
  if (!target.endsWith(".rs")) {
    log("WARN", "rustowl::toolchain", "cargo not found; fallback");
    log("WARN", "rustowl::toolchain", "rustowlc not found; fallback");
    log("WARN", "rustowl::lsp::analyze", `Invalid analysis target: ${target}`);
    log("ERROR", "rustowl", "Analyze failed");
    process.exitCode = 1;
    return;
  }
  log("INFO", "rustowl::lsp::backend", "stop running analysis processes");
  log("INFO", "rustowl::lsp::backend", "start analysis");
  log("INFO", "rustowl::lsp::backend", "analyze 1 packages...");
  log("WARN", "rustowl::toolchain", "rustowlc not found; fallback");
  log("INFO", "rustowl::lsp::analyze", `start analyzing ${target}`);
  log("INFO", "rustowl::lsp::analyze", "stdout closed");
  log("ERROR", "rustowl", "Analyze failed");
  process.exitCode = 1;
}

function doToolchain(args) {
  if (args.length === 0) return;
  const cmd = args[0];
  if (cmd === "-h" || cmd === "--help" || cmd === "help") {
    if (args[1] === "install") return out(installHelp());
    if (args[1] === "uninstall") return out(uninstallHelp());
    return out(toolchainHelp());
  }
  if (cmd === "install") {
    for (let i = 1; i < args.length; i++) {
      if (args[i] === "-h" || args[i] === "--help") return out(installHelp());
      if (args[i] === "--path") {
        if (!args[i + 1]) return die("error: a value is required for '--path <path>' but none was supplied");
        i++;
        continue;
      }
      if (args[i] === "--skip-rustowl-toolchain") continue;
      return die(`error: unexpected argument '${args[i]}' found`, `Usage: ${name()} toolchain install [OPTIONS]`);
    }
    return installFailed();
  }
  if (cmd === "uninstall") {
    if (args[1] === "-h" || args[1] === "--help") return out(uninstallHelp());
    if (args.length > 1) return die(`error: unexpected argument '${args[1]}' found`, `Usage: ${name()} toolchain uninstall`);
    log("INFO", "rustowl::toolchain", `remove sysroot: ${(process.env.HOME || "/home/agent")}/.rustowl/sysroot/nightly-${DATE}-${TARGET}`);
    return;
  }
  die(`error: unrecognized subcommand '${cmd}'`, `Usage: ${name()} toolchain [COMMAND]`);
}

function completion(shell) {
  const shells = ["bash", "elvish", "fish", "powershell", "zsh", "nushell"];
  if (!shell) return die("error: the following required arguments were not provided:\n  <SHELL>", `Usage: ${name()} completions <SHELL>`);
  if (!shells.includes(shell)) return die(`error: invalid value '${shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh, nushell]\n\n  tip: a similar value exists: 'bash'`);
  if (shell === "bash") return out(`_rustowl() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n    cmd=""\n    opts="-V --version -q --quiet --stdio -h --help check clean toolchain completions help"\n}\ncomplete -F _rustowl -o bashdefault -o default rustowl`);
  if (shell === "fish") return out(`complete -c rustowl -s V -l version -d 'Print version'\ncomplete -c rustowl -s q -l quiet -d 'Suppress output'\ncomplete -c rustowl -l stdio -d 'Use stdio to communicate with the LSP server'\ncomplete -c rustowl -f -a "check" -d 'Check availability'\ncomplete -c rustowl -f -a "clean" -d 'Remove artifacts from the target directory'`);
  if (shell === "zsh") return out(`#compdef rustowl\n\n_rustowl() {\n    _arguments '-V[Print version]' '--version[Print version]' '--stdio[Use stdio to communicate with the LSP server]' ':: :_rustowl_commands'\n}\n_rustowl "$@"`);
  if (shell === "powershell") return out(`using namespace System.Management.Automation\nusing namespace System.Management.Automation.Language\nRegister-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock {}`);
  if (shell === "elvish") return out(`edit:completion:arg-completer[rustowl] = {|@words| put check clean toolchain completions help }`);
  return out(`extern "rustowl" [\n  --version(-V)\n  --quiet(-q)\n  --stdio\n]`);
}

function sendRpc(obj) {
  const body = JSON.stringify(obj);
  process.stdout.write(`Content-Length: ${Buffer.byteLength(body)}\r\n\r\n${body}`);
}

function stdio() {
  err(VERSION);
  err("This is an LSP server. You can use --help flag to show help.");
  const input = fs.readFileSync(0, "utf8");
  const re = /Content-Length:\s*(\d+)\r\n\r\n/g;
  let m;
  while ((m = re.exec(input))) {
    const len = Number(m[1]);
    const start = re.lastIndex;
    const raw = input.slice(start, start + len);
    re.lastIndex = start + len;
    let msg;
    try { msg = JSON.parse(raw); } catch { continue; }
    if (msg.id === undefined) continue;
    if (msg.method === "initialize") sendRpc({ jsonrpc: "2.0", error: { code: -32800, message: "Canceled" }, id: msg.id });
    else if (msg.method === "shutdown") sendRpc({ jsonrpc: "2.0", error: { code: -32002, message: "Server not initialized" }, id: msg.id });
    else sendRpc({ jsonrpc: "2.0", error: { code: -32601, message: "Method not found" }, id: msg.id });
  }
}

function run() {
  let args = process.argv.slice(2);
  let i = 0;
  while (i < args.length && ["-q", "-qq", "-qqq", "--quiet"].includes(args[i])) i++;
  args = args.slice(i);
  if (args.includes("--stdio")) return stdio();
  if (args.length === 0) {
    err(VERSION);
    err("This is an LSP server. You can use --help flag to show help.");
    return;
  }
  const first = args[0];
  if (first === "-h" || first === "--help" || first === "help" && args.length === 1) return out(mainHelp());
  if (first === "-V" || first === "--version") return out(VERSION);
  if (first === "help") {
    if (args[1] === "check") return out(checkHelp());
    if (args[1] === "clean") return out(cleanHelp());
    if (args[1] === "toolchain" && args[2] === "install") return out(installHelp());
    if (args[1] === "toolchain" && args[2] === "uninstall") return out(uninstallHelp());
    if (args[1] === "toolchain") return out(toolchainHelp());
    if (args[1] === "completions") return out(completionsHelp());
    return die(`error: unrecognized subcommand '${args[1]}'`, `Usage: ${name()} [OPTIONS] [COMMAND]`);
  }
  if (first === "check") return doCheck(args.slice(1));
  if (first === "clean") {
    if (args[1] === "-h" || args[1] === "--help") return out(cleanHelp());
    if (args.length > 1) return die(`error: unexpected argument '${args[1]}' found`, `Usage: ${name()} clean`);
    return;
  }
  if (first === "toolchain") return doToolchain(args.slice(1));
  if (first === "completions") {
    if (args[1] === "-h" || args[1] === "--help") return out(completionsHelp());
    return completion(args[1]);
  }
  if (first.startsWith("-")) return die(`error: unexpected argument '${first}' found`, `Usage: ${name()} [OPTIONS] [COMMAND]`);
  return die(`error: unrecognized subcommand '${first}'`, `Usage: ${name()} [OPTIONS] [COMMAND]`);
}

run();
