#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20";
const WARNING = "\nWARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\nThe project reserves the right to modify, rename, reorganize, and change the behavior of the utility\nuntil it is officially frozen in a future feature release of GDAL.";

const topHelp = `Usage: gdal <COMMAND> [OPTIONS]
where <COMMAND> is one of:
  - convert:  Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').
  - dataset:  Commands to manage datasets.
  - driver:   Command for driver specific operations.
  - info:     Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').
  - mdim:     Multidimensional commands.
  - pipeline: Process a dataset applying several steps.
  - raster:   Raster commands.
  - vector:   Vector commands.
  - vsi:      GDAL Virtual System Interface (VSI) commands.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --version               Display GDAL version and exit
  --drivers               Display driver list as JSON document

'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.
And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.

For more details, consult https://gdal.org/programs/index.html${WARNING}`;
const topBrief = `Usage: gdal <COMMAND> [OPTIONS]
where <COMMAND> is one of:
  - convert:  Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').
  - dataset:  Commands to manage datasets.
  - driver:   Command for driver specific operations.
  - info:     Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').
  - mdim:     Multidimensional commands.
  - pipeline: Process a dataset applying several steps.
  - raster:   Raster commands.
  - vector:   Vector commands.
  - vsi:      GDAL Virtual System Interface (VSI) commands.

Try 'gdal --help' for help.

'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.
And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.

For more details, consult https://gdal.org/programs/index.html${WARNING}`;

const helps = {
  dataset: `Usage: gdal dataset <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - check:    Check whether there are errors when reading the content of a dataset.
  - copy:     Copy files of a dataset. (alias: cp)
  - delete:   Delete dataset(s). (alias: rm, remove)
  - identify: Identify driver opening dataset(s).
  - rename:   Rename files of a dataset. (alias: ren, mv)

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_dataset.html${WARNING}`,
  driver: `Usage: gdal driver <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - cog: Command for COG driver specific operations.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]${WARNING}`,
  "driver cog": `Usage: gdal driver cog <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - validate: Validate if a TIFF file is a Cloud Optimized GeoTIFF

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/drivers/raster/cog.html${WARNING}`,
  mdim: `Usage: gdal mdim <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - convert: Convert a multidimensional dataset.
  - info:    Return information on a multidimensional dataset.
  - mosaic:  Build a mosaic, either virtual (VRT) or materialized, from multidimensional datasets.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display multidimensional driver list as JSON document

For more details, consult https://gdal.org/programs/gdal_mdim.html${WARNING}`,
  raster: `Usage: gdal raster <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - as-features:     Create features from pixels of a raster dataset
  - aspect:          Generate an aspect map
  - blend:           Blend/compose two raster datasets
  - calc:            Perform raster algebra
  - clean-collar:    Clean the collar of a raster dataset, removing noise.
  - clip:            Clip a raster dataset.
  - color-map:       Generate a RGB or RGBA dataset from a single band, using a color map
  - compare:         Compare two raster datasets.
  - contour:         Creates a vector contour from a raster elevation model (DEM).
  - convert:         Convert a raster dataset.
  - create:          Create a new raster dataset.
  - edit:            Edit a raster dataset.
  - fill-nodata:     Fill nodata raster regions by interpolation from edges.
  - footprint:       Compute the footprint of a raster dataset.
  - hillshade:       Generate a shaded relief map
  - index:           Create a vector index of raster datasets.
  - info:            Return information on a raster dataset.
  - mosaic:          Build a mosaic, either virtual (VRT) or materialized.
  - neighbors:       Compute the value of each pixel from its neighbors (focal statistics) (alias: neighbours)
  - nodata-to-alpha: Replace nodata value(s) with an alpha band.
  - overview:        Manage overviews of a raster dataset.
  - pansharpen:      Perform a pansharpen operation.
  - pipeline:        Process a raster dataset applying several steps.
  - pixel-info:      Return information on a pixel of a raster dataset.
  - polygonize:      Create a polygon feature dataset from a raster band.
  - proximity:       Produces a raster proximity map.
  - reclassify:      Reclassify values in a raster dataset
  - reproject:       Reproject a raster dataset.
  - resize:          Resize a raster dataset without changing the georeferenced extents.
  - rgb-to-palette:  Convert a RGB image into a pseudo-color / paletted image.
  - roughness:       Generate a roughness map
  - scale:           Scale the values of the bands of a raster dataset.
  - select:          Select a subset of bands from a raster dataset.
  - set-type:        Modify the data type of bands of a raster dataset.
  - sieve:           Remove small polygons from a raster dataset.
  - slope:           Generate a slope map
  - stack:           Combine together input bands into a multi-band output, either virtual (VRT) or materialized.
  - tile:            Generate tiles in separate files from a raster dataset.
  - tpi:             Generate a Topographic Position Index (TPI) map
  - tri:             Generate a Terrain Ruggedness Index (TRI) map
  - unscale:         Convert scaled values of a raster dataset into unscaled values.
  - update:          Update the destination raster with the content of the input one.
  - viewshed:        Compute the viewshed of a raster dataset.
  - zonal-stats:     Calculate raster zonal statistics

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display raster driver list as JSON document

For more details, consult https://gdal.org/programs/gdal_raster.html${WARNING}`,
  vector: `Usage: gdal vector <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - buffer:              Compute a buffer around geometries of a vector dataset.
  - check-coverage:      Check a polygon coverage for validity
  - check-geometry:      Check a dataset for invalid geometries
  - clean-coverage:      Alter polygon boundaries to make shared edges identical, removing gaps and overlaps
  - clip:                Clip a vector dataset.
  - combine:             Combine features into collections
  - concat:              Concatenate vector datasets.
  - concave-hull:        Compute the concave hull of geometries of a vector dataset.
  - convert:             Convert a vector dataset.
  - convex-hull:         Compute the convex hull of geometries of a vector dataset.
  - create:              Create a vector dataset.
  - dissolve:            Dissolves multipart features
  - edit:                Edit metadata of a vector dataset.
  - explode-collections: Explode geometries of type collection of a vector dataset.
  - export-schema:       Export the OGR_SCHEMA from a vector dataset.
  - filter:              Filter a vector dataset.
  - grid:                Create a regular grid from scattered points.
  - index:               Create a vector index of vector datasets.
  - info:                Return information on a vector dataset.
  - layer-algebra:       Perform algebraic operation between 2 layers.
  - make-point:          Create point geometries from attribute fields
  - make-valid:          Fix validity of geometries of a vector dataset.
  - partition:           Partition a vector dataset into multiple files.
  - pipeline:            Process a vector dataset applying several steps.
  - rasterize:           Burns vector geometries into a raster.
  - rename-layer:        Rename layer(s) of a vector dataset.
  - reproject:           Reproject a vector dataset.
  - segmentize:          Segmentize geometries of a vector dataset.
  - select:              Select a subset of fields from a vector dataset.
  - set-field-type:      Modify the type of a field of a vector dataset.
  - set-geom-type:       Modify the geometry type of a vector dataset.
  - simplify:            Simplify geometries of a vector dataset.
  - simplify-coverage:   Simplify shared boundaries of a polygonal vector dataset.
  - sort:                Spatially order the features in a layer
  - sql:                 Apply SQL statement(s) to a dataset.
  - swap-xy:             Swap X and Y coordinates of geometries of a vector dataset.
  - update:              Update an existing vector dataset with an input vector dataset.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display vector driver list as JSON document and exit

For more details, consult https://gdal.org/programs/gdal_vector.html${WARNING}`,
  vsi: `Usage: gdal vsi <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - copy:   Copy files located on GDAL Virtual System Interface (VSI). (alias: cp)
  - delete: Delete files located on GDAL Virtual System Interface (VSI). (alias: rm, rmdir, del)
  - list:   List files of one of the GDAL Virtual System Interface (VSI). (alias: ls)
  - move:   Move/rename a file/directory located on GDAL Virtual System Interface (VSI). (alias: mv, ren, rename)
  - sozip:  Seek-optimized ZIP (SOZIP) commands.
  - sync:   Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI).

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_vsi.html${WARNING}`,
  pipeline: `Usage: gdal pipeline [OPTIONS] <PIPELINE>

Process a dataset applying several steps.

Positional arguments:

Common Options:
  -h, --help                        Display help message and exit
  --json-usage                      Display usage as JSON document and exit
  --config <KEY>=<VALUE>            Configuration option [may be repeated]
  -q, --quiet                       Quiet mode (no progress bar or warning message)

Advanced Options:
  --<user-provided-option>=<value>  Argument provided by user

<PIPELINE> is of the form: read|calc|concat|create|mosaic|stack [READ-OPTIONS] ( ! <STEP-NAME> [STEP-OPTIONS] )* ! write!info!tile [WRITE-OPTIONS]

Potential steps are:

* read [OPTIONS] <INPUT>
------------------------

Read a raster dataset.

* read [OPTIONS] <INPUT>
------------------------

Read a vector dataset.

For more details, consult https://gdal.org/programs/gdal_pipeline.html${WARNING}`,
  info: `Usage: gdal info [OPTIONS] <INPUT>

Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input raster, vector or multidimensional raster dataset [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text

For all options, run 'gdal raster info --help' or 'gdal vector info --help'

For more details, consult https://gdal.org/programs/gdal_info.html${WARNING}`,
  convert: `Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>

Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').

Positional arguments:
  -i, --input <INPUT>                                  Input raster, vector or multidimensional raster dataset [required]
  -o, --output <OUTPUT>                                Output raster, vector or multidimensional raster dataset (created by algorithm) [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]
  -q, --quiet                                          Quiet mode (no progress bar or warning message)

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format

For all options, run 'gdal raster convert --help' or 'gdal vector convert --help'

For more details, consult https://gdal.org/programs/gdal_convert.html${WARNING}`,
};

helps["raster info"] = helps.info.replace("gdal info", "gdal raster info").replace("Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').", "Return information on a raster dataset.").replace("Input raster, vector or multidimensional raster dataset", "Input raster dataset").replace("\nFor all options, run 'gdal raster info --help' or 'gdal vector info --help'\n", "\nOptions:\n  --mm, --min-max                                      Compute minimum and maximum value\n  --stats                                              Retrieve or compute statistics, using all pixels\n  --approx-stats                                       Retrieve or compute statistics, using a subset of pixels\n  --hist                                               Retrieve or compute histogram\n\nAdvanced Options:\n  --if, --input-format <INPUT-FORMAT>                  Input formats [may be repeated]\n  --oo, --open-option <KEY>=<VALUE>                    Open options [may be repeated]\n").replace("gdal_info.html", "gdal_raster_info.html");
helps["vector info"] = helps.info.replace("Usage: gdal info [OPTIONS] <INPUT>", "Usage: gdal vector info [OPTIONS] <INPUT>...").replace("gdal info", "gdal vector info").replace("Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').", "Return information on a vector dataset.").replace("Input raster, vector or multidimensional raster dataset [required]", "Input vector datasets [may be repeated] [required]").replace("\nFor all options, run 'gdal raster info --help' or 'gdal vector info --help'\n", "\nOptions:\n  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name [may be repeated]\n  --features                                           List all features (beware of RAM consumption on large layers)\n  --summary                                            List the layer names and the geometry type\n  --limit <FEATURE-COUNT>                              Limit the number of features per layer (implies --features)\n  --sql <statement>|@<filename>                        Execute the indicated SQL statement and return the result\n  --where <WHERE>|@<filename>                          Attribute query in a restricted form of the queries used in the SQL WHERE statement\n  --fid <FID>                                          Feature identifier\n  --dialect <DIALECT>                                  SQL dialect\n").replace("gdal_info.html", "gdal_vector_info.html");
helps["raster convert"] = helps.convert.replace(/gdal convert/g, "gdal raster convert").replace("Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').", "Convert a raster dataset.").replace("Input raster, vector or multidimensional raster dataset", "Input raster datasets").replace("Output raster, vector or multidimensional raster dataset (created by algorithm)", "Output raster dataset").replace("  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format", "  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format (\"GDALG\" allowed)\n  --co, --creation-option <KEY>=<VALUE>                Creation option [may be repeated]\n  --overwrite                                          Whether overwriting existing output dataset is allowed\n  --append                                             Append as a subdataset to existing output").replace(/\nFor all options.*\n/, "\n").replace("gdal_convert.html", "gdal_raster_convert.html");
helps["vector convert"] = helps.convert.replace(/gdal convert/g, "gdal vector convert").replace("Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').", "Convert a vector dataset.").replace("Input raster, vector or multidimensional raster dataset", "Input vector datasets").replace("Output raster, vector or multidimensional raster dataset (created by algorithm)", "Output vector dataset").replace("  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format", "  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name(s) [may be repeated]\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format (\"GDALG\" allowed)\n  --co, --creation-option <KEY>=<VALUE>                Creation option [may be repeated]\n  --lco, --layer-creation-option <KEY>=<VALUE>         Layer creation option [may be repeated]\n  --overwrite                                          Whether overwriting existing output dataset is allowed\n  --update                                             Whether to open existing dataset in update mode\n  --overwrite-layer                                    Whether overwriting existing output layer is allowed\n  --append                                             Whether appending to existing layer is allowed").replace(/\nFor all options.*\n/, "\n").replace("gdal_convert.html", "gdal_vector_convert.html");
helps["raster create"] = `Usage: gdal raster create [OPTIONS] <OUTPUT>

Create a new raster dataset.

Positional arguments:
  -o, --output <OUTPUT>                                    Output raster dataset [required]

Common Options:
  -h, --help                                               Display help message and exit
  --json-usage                                             Display usage as JSON document and exit
  --config <KEY>=<VALUE>                                   Configuration option [may be repeated]
  -q, --quiet                                              Quiet mode (no progress bar or warning message)

Options:
  -i, --like, --input <INPUT>                              Input raster datasets
  -f, --of, --format, --output-format <OUTPUT-FORMAT>      Output format ("GDALG" allowed)
  --co, --creation-option <KEY>=<VALUE>                    Creation option [may be repeated]
  --overwrite                                              Whether overwriting existing output dataset is allowed
  --size <width>,<height>                                  Output size in pixels
  --band-count <BAND-COUNT>                                Number of bands (default: 1)
  --ot, --datatype, --output-data-type <OUTPUT-DATA-TYPE>  Output data type. OUTPUT-DATA-TYPE=UInt8|Int8|UInt16|Int16|UInt32|Int32|UInt64|Int64|CInt16|CInt32|Float16|Float32|Float64|CFloat32|CFloat64 (default: Byte)
  --nodata <NODATA>                                        Assign a specified nodata value to output bands ('none', numeric value, 'nan', 'inf', '-inf')
  --burn <BURN>                                            Burn value [may be repeated]
  --crs <CRS>                                              Set CRS
  --bbox <BBOX>                                            Bounding box as xmin,ymin,xmax,ymax
  --metadata <KEY>=<VALUE>                                 Add metadata item [may be repeated]

For more details, consult https://gdal.org/programs/gdal_raster_create.html${WARNING}`;
helps["vsi list"] = `Usage: gdal vsi list [OPTIONS] <FILENAME>

List files of one of the GDAL Virtual System Interface (VSI).

Positional arguments:
  --filename <FILENAME>                                File or directory name [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  -l, --long, --long-listing                           Use a long listing format
  -R, --recursive                                      List subdirectories recursively
  --depth <DEPTH>                                      Maximum depth in recursive mode
  --abs, --absolute-path                               Display absolute path
  --tree                                               Use a hierarchical presentation for JSON output

For more details, consult https://gdal.org/programs/gdal_vsi_list.html${WARNING}`;
helps["vsi copy"] = `Usage: gdal vsi copy [OPTIONS] <SOURCE> <DESTINATION>

Copy files located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --source <SOURCE>            Source file or directory name [required]
  --destination <DESTINATION>  Destination file or directory name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]
  -q, --quiet                  Quiet mode (no progress bar or warning message)

Options:
  -r, --recursive              Copy subdirectories recursively
  --skip-errors                Skip errors

For more details, consult https://gdal.org/programs/gdal_vsi_copy.html${WARNING}`;
helps["vsi delete"] = `Usage: gdal vsi delete [OPTIONS] <FILENAME>

Delete files located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --filename <FILENAME>   File or directory name to delete [required]

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  -r, -R, --recursive     Delete directories recursively

For more details, consult https://gdal.org/programs/gdal_vsi_delete.html${WARNING}`;
helps["vsi move"] = `Usage: gdal vsi move [OPTIONS] <SOURCE> <DESTINATION>

Move/rename a file/directory located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --source <SOURCE>            Source file or directory name [required]
  --destination <DESTINATION>  Destination file or directory name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_vsi_move.html${WARNING}`;
helps["dataset identify"] = `Usage: gdal dataset identify [OPTIONS] <FILENAME>

Identify driver opening dataset(s).

Positional arguments:
  --input, --filename <FILENAME>                       File or directory name [may be repeated] [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]
  -q, --quiet                                          Quiet mode (no progress bar or warning message)

Options:
  -o, --output <OUTPUT>                                Output vector dataset (created by algorithm)
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format
  --overwrite                                          Whether overwriting existing output dataset is allowed
  -r, --recursive                                      Recursively scan files/folders for datasets
  --detailed                                           Most detailed output. Reports the presence of georeferencing, if a GeoTIFF file is cloud optimized, etc.
  --report-failures                                    Report failures if file type is unidentified

For more details, consult https://gdal.org/programs/gdal_dataset_identify.html${WARNING}`;
helps["dataset copy"] = `Usage: gdal dataset copy [OPTIONS] <SOURCE> <DESTINATION>

Copy files of a dataset.

Positional arguments:
  --source <SOURCE>            Source dataset [required]
  --destination <DESTINATION>  Destination dataset [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]
  -q, --quiet                  Quiet mode (no progress bar or warning message)

For more details, consult https://gdal.org/programs/gdal_dataset_copy.html${WARNING}`;
helps["dataset delete"] = `Usage: gdal dataset delete [OPTIONS] <DATASET>

Delete dataset(s).

Positional arguments:
  --dataset <DATASET>     Dataset name [may be repeated] [required]

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_dataset_delete.html${WARNING}`;
helps["dataset rename"] = `Usage: gdal dataset rename [OPTIONS] <SOURCE> <DESTINATION>

Rename files of a dataset.

Positional arguments:
  --source <SOURCE>            Source dataset [required]
  --destination <DESTINATION>  Destination dataset [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_dataset_rename.html${WARNING}`;
helps["dataset check"] = `Usage: gdal dataset check [OPTIONS] <INPUT>

Check whether there are errors when reading the content of a dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>  Input raster, vector or multidimensional raster dataset [required]

Common Options:
  -h, --help                     Display help message and exit
  --json-usage                   Display usage as JSON document and exit
  --config <KEY>=<VALUE>         Configuration option [may be repeated]
  -q, --quiet                    Quiet mode (no progress bar or warning message)

For more details, consult https://gdal.org/programs/gdal_dataset_check.html${WARNING}`;
helps["driver cog validate"] = `Usage: gdal driver cog validate [OPTIONS] <INPUT>

Validate if a TIFF file is a Cloud Optimized GeoTIFF

Positional arguments:
  -i, --input <INPUT>       Input TIFF file [required]

Common Options:
  -h, --help                Display help message and exit
  --json-usage              Display usage as JSON document and exit
  --config <KEY>=<VALUE>    Configuration option [may be repeated]

For more details, consult https://gdal.org/drivers/raster/cog.html${WARNING}`;

function out(s = "") { process.stdout.write(String(s) + "\n"); }
function err(s = "") { process.stderr.write(String(s) + "\n"); }
function has(a, ...names) { return a.some(x => names.includes(x)); }
function nonOptions(a) {
  const skip = new Set(["-f","--of","--format","--output-format","-i","--input","--dataset","-o","--output","--size","--band-count","--ot","--datatype","--output-data-type","--burn","--crs","--bbox","--metadata","--config","--co","--creation-option","--oo","--open-option","-l","--layer","--input-layer","--limit","--sql","--where","--fid","--dialect","--depth"]);
  const r = [];
  for (let i = 0; i < a.length; i++) {
    const x = a[i];
    if (skip.has(x)) { i++; continue; }
    if (x.startsWith("--") && x.includes("=")) continue;
    if (x.startsWith("-")) continue;
    r.push(x);
  }
  return r;
}
function optValue(a, ...names) {
  for (let i = 0; i < a.length - 1; i++) if (names.includes(a[i])) return a[i + 1];
  for (const x of a) for (const n of names) if (x.startsWith(n + "=")) return x.slice(n.length + 1);
  return undefined;
}
function outputFormat(a) { return (optValue(a, "-f", "--of", "--format", "--output-format") || "text").toLowerCase(); }

function driverFor(file) {
  const ext = path.extname(file).toLowerCase();
  if ([".json", ".geojson"].includes(ext)) return ["GeoJSON", "GeoJSON", "vector"];
  if (ext === ".csv") return ["CSV", "Comma Separated Value (.csv)", "vector"];
  if ([".tif", ".tiff"].includes(ext)) return ["GTiff", "GeoTIFF", "raster"];
  if (ext === ".vrt") return ["VRT", "Virtual Raster", "raster"];
  if (ext === ".gpkg") return ["GPKG", "GeoPackage", "vector"];
  if (ext === ".shp") return ["ESRI Shapefile", "ESRI Shapefile", "vector"];
  const meta = readMeta(file);
  if (meta) return [meta.driverShortName || "GTiff", meta.driverLongName || "GeoTIFF", "raster"];
  return null;
}
function readMeta(file) {
  try {
    const s = fs.readFileSync(file, "utf8");
    if (s.startsWith("PB_GDAL_RASTER ")) return JSON.parse(s.slice(15));
  } catch {}
  return null;
}
function readGeoJSON(file) {
  const data = JSON.parse(fs.readFileSync(file, "utf8"));
  if (data.type === "FeatureCollection") return data.features || [];
  if (data.type === "Feature") return [data];
  return [];
}
function geomCoords(g, acc = []) {
  if (!g) return acc;
  if (g.type === "GeometryCollection") for (const x of g.geometries || []) geomCoords(x, acc);
  else walk(g.coordinates, acc);
  return acc;
}
function walk(v, acc) {
  if (!Array.isArray(v)) return;
  if (typeof v[0] === "number" && typeof v[1] === "number") acc.push([v[0], v[1]]);
  else for (const x of v) walk(x, acc);
}
function inferFields(features) {
  const m = new Map();
  for (const f of features) for (const [k, v] of Object.entries(f.properties || {})) {
    if (!m.has(k)) m.set(k, Number.isInteger(v) ? "Integer" : typeof v === "number" ? "Real" : "String");
  }
  return [...m.entries()].map(([name, type]) => ({ name, type }));
}
function layerName(file) { return path.basename(file).replace(/\.[^.]+$/, ""); }

function vectorInfo(file, fmt) {
  if (!file) return err("ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.\nUsage: gdal vector info [OPTIONS] <INPUT>...\nTry 'gdal vector info --help' for help.");
  if (!fs.existsSync(file)) return err(`ERROR 4: ${file}: No such file or directory\nUsage: gdal vector info [OPTIONS] <INPUT>...\nTry 'gdal vector info --help' for help.`);
  let features = [];
  try { features = readGeoJSON(file); } catch {}
  const fields = inferFields(features);
  const geomType = (features.find(f => f.geometry)?.geometry?.type) || "Unknown";
  const coords = features.flatMap(f => geomCoords(f.geometry));
  const extent = coords.length ? [Math.min(...coords.map(c=>c[0])), Math.min(...coords.map(c=>c[1])), Math.max(...coords.map(c=>c[0])), Math.max(...coords.map(c=>c[1]))] : [0,0,0,0];
  if (fmt === "json") {
    out(JSON.stringify({description:file,driverShortName:"GeoJSON",driverLongName:"GeoJSON",layers:[{name:layerName(file),metadata:{},geometryFields:[{name:"",type:geomType,nullable:true,extent}],featureCount:features.length,fields:fields.map(f=>({name:f.name,type:f.type,nullable:true,uniqueConstraint:false}))}],metadata:{},domains:{},relationships:{}}, null, 2));
  } else {
    out(`INFO: Open of \`${file}'\n      using driver \`GeoJSON' successful.\n\nLayer name: ${layerName(file)}\nGeometry: ${geomType}\nFeature Count: ${features.length}`);
    if (coords.length) out(`Extent: (${extent[0].toFixed(6)}, ${extent[1].toFixed(6)}) - (${extent[2].toFixed(6)}, ${extent[3].toFixed(6)})`);
    out("Layer Coordinate Reference System:\n  - name: WGS 84\n  - ID: EPSG:4326\n  - type: Geographic 2D\nData axis to CRS axis mapping: 2,1");
    for (const f of fields) out(`${f.name}: ${f.type} (0.0)`);
  }
}
function rasterJson(file) {
  const meta = readMeta(file) || {};
  const size = meta.size || [0, 0], bands = meta.bandCount || 1, type = meta.dataType || "Byte";
  return {description:file,driverShortName:meta.driverShortName||"GTiff",driverLongName:meta.driverLongName||"GeoTIFF",files:[file],size,metadata:{IMAGE_STRUCTURE:{INTERLEAVE:"BAND"}},cornerCoordinates:{upperLeft:[0,0],lowerLeft:[0,size[1]],lowerRight:[size[0],size[1]],upperRight:[size[0],0],center:[size[0]/2,size[1]/2]},bands:Array.from({length:bands},(_,i)=>({band:i+1,block:size,type,colorInterpretation:i===0?"Gray":"Undefined",metadata:{}})),stac:{"proj:shape":[size[1],size[0]],"raster:bands":Array.from({length:bands},()=>({data_type:type==="Byte"?"uint8":type.toLowerCase()}))}};
}
function rasterInfo(file, fmt) {
  if (!file) return err("ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.\nUsage: gdal raster info [OPTIONS] <INPUT>\nTry 'gdal raster info --help' for help.");
  if (!fs.existsSync(file)) return err(`ERROR 4: ${file}: No such file or directory\nUsage: gdal raster info [OPTIONS] <INPUT>\nTry 'gdal raster info --help' for help.`);
  const j = rasterJson(file);
  if (fmt === "json") out(JSON.stringify(j, null, 2));
  else out(`Driver: ${j.driverShortName}/${j.driverLongName}\nFiles: ${file}\nSize is ${j.size[0]}, ${j.size[1]}\nCorner Coordinates:\nUpper Left  (   0.0000000,   0.0000000)\nLower Left  (   0.0000000,   ${j.size[1].toFixed(7)})\nUpper Right (   ${j.size[0].toFixed(7)},   0.0000000)\nLower Right (   ${j.size[0].toFixed(7)},   ${j.size[1].toFixed(7)})\nCenter      (   ${(j.size[0]/2).toFixed(7)},   ${(j.size[1]/2).toFixed(7)})\nBand 1 Block=${j.size[0]}x${j.size[1]} Type=${j.bands[0].type}, ColorInterp=Gray`);
}
function createRaster(args) {
  const files = nonOptions(args);
  const outFile = optValue(args, "-o", "--output") || files[0];
  if (!outFile) return err("ERROR 1: create: Positional arguments starting at 'OUTPUT' have not been specified.\nUsage: gdal raster create [OPTIONS] <OUTPUT>\nTry 'gdal raster create --help' for help.");
  const sz = (optValue(args, "--size") || "0,0").split(",").map(x => parseInt(x,10) || 0);
  const meta = {driverShortName:"GTiff",driverLongName:"GeoTIFF",size:[sz[0]||0, sz[1]||0],bandCount:parseInt(optValue(args,"--band-count")||"1",10)||1,dataType:optValue(args,"--ot","--datatype","--output-data-type")||"Byte"};
  fs.writeFileSync(outFile, "PB_GDAL_RASTER " + JSON.stringify(meta));
}
function copyAny(src, dst) {
  const st = fs.statSync(src);
  if (st.isDirectory()) fs.cpSync(src, dst, {recursive:true, force:true});
  else fs.copyFileSync(src, dst);
}
function drivers(scope) {
  const all = [
    {short_name:"GTiff",long_name:"GeoTIFF",scopes:["raster"],capabilities:["open","create","create_copy","update","virtual_io"],file_extensions:["tif","tiff"]},
    {short_name:"COG",long_name:"Cloud optimized GeoTIFF generator",scopes:["raster"],capabilities:["create","create_copy","virtual_io"],file_extensions:["tif","tiff"]},
    {short_name:"VRT",long_name:"Virtual Raster",scopes:["raster"],capabilities:["open","create_copy","virtual_io"],file_extensions:["vrt"]},
    {short_name:"GeoJSON",long_name:"GeoJSON",scopes:["vector"],capabilities:["open","create","create_copy","virtual_io"],file_extensions:["json","geojson"]},
    {short_name:"GPKG",long_name:"GeoPackage",scopes:["raster","vector"],capabilities:["open","create","create_copy","update","virtual_io"],file_extensions:["gpkg"]},
    {short_name:"CSV",long_name:"Comma Separated Value (.csv)",scopes:["vector"],capabilities:["open","create","create_copy","virtual_io"],file_extensions:["csv"]},
    {short_name:"ESRI Shapefile",long_name:"ESRI Shapefile",scopes:["vector"],capabilities:["open","create","create_copy"],file_extensions:["shp"]},
    {short_name:"netCDF",long_name:"Network Common Data Format",scopes:["raster","multidim_raster"],capabilities:["open","create","create_copy"],file_extensions:["nc"]}
  ];
  return scope ? all.filter(d => d.scopes.includes(scope)) : all;
}
function jsonUsage(name) {
  out(JSON.stringify({description:name==="gdal"?"Main gdal entry point.":`gdal ${name} command`,short_url:"/programs/index.html",url:"https://gdal.org/programs/index.html",sub_algorithms:["dataset","driver","info","mdim","pipeline","raster","vector","vsi"].map(n=>({name:n,full_path:["gdal",n],description:"",sub_algorithms:[],input_arguments:[],output_arguments:[]})),input_arguments:[],output_arguments:[]}, null, 2));
}

function main(argv) {
  if (argv.length === 0) return err("ERROR 1: gdal: Missing command name.\n" + topBrief);
  if (has(argv, "-h", "--help")) {
    const words = argv.filter(x=>!x.startsWith("-")).map(x => {
      if (["cp"].includes(x)) return "copy";
      if (["rm","rmdir","del","remove"].includes(x)) return "delete";
      if (["mv","ren","rename"].includes(x)) return "move";
      return x;
    });
    if (words[0] === "dataset" && words[1] === "move") words[1] = "rename";
    const key3 = words.slice(0,3).join(" ");
    const key2 = words.slice(0,2).join(" ");
    return out(helps[key3] || helps[key2] || helps[words[0]] || topHelp);
  }
  if (has(argv, "--json-usage")) return jsonUsage(argv[0] || "gdal");
  if (has(argv, "--version")) return out(VERSION);
  if (has(argv, "--drivers")) return out(JSON.stringify(drivers(argv[0]==="raster"?"raster":argv[0]==="vector"?"vector":argv[0]==="mdim"?"multidim_raster":null), null, 2));
  if (argv[0].startsWith("-")) return err(`ERROR 5: gdal: Option '${argv[0]}' is unknown.\n` + topBrief);
  const [cmd, sub, ...rest] = argv;
  if (cmd === "info") {
    const f = optValue(argv,"-i","--input","--dataset") || nonOptions(argv.slice(1))[0];
    if (!f) return err("ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.\nUsage: gdal info [OPTIONS] <INPUT>\nTry 'gdal info --help' for help.");
    const d = driverFor(f);
    if (!fs.existsSync(f)) return err(`ERROR 4: ${f}: No such file or directory\nUsage: gdal info [OPTIONS] <INPUT>\nTry 'gdal info --help' for help.`);
    return d && d[2] === "vector" ? vectorInfo(f, outputFormat(argv)) : rasterInfo(f, outputFormat(argv));
  }
  if (cmd === "raster" && sub === "info") return rasterInfo(optValue(rest,"-i","--input","--dataset") || nonOptions(rest)[0], outputFormat(rest));
  if (cmd === "vector" && sub === "info") return vectorInfo(optValue(rest,"-i","--input","--dataset") || nonOptions(rest)[0], outputFormat(rest));
  if (cmd === "raster" && sub === "create") return createRaster(rest);
  if ((cmd === "convert") || (cmd === "raster" && sub === "convert") || (cmd === "vector" && sub === "convert")) {
    const a = cmd === "convert" ? argv.slice(1) : rest, p = nonOptions(a);
    const src = optValue(a,"-i","--input") || p[0], dst = optValue(a,"-o","--output") || p[1];
    if (!src || !dst) return err(`ERROR 1: ${cmd === "convert" ? "convert" : sub}: Positional arguments have not been specified.`);
    try { copyAny(src, dst); } catch(e) { err(`ERROR 4: ${src}: ${e.message}`); }
    return;
  }
  if (cmd === "dataset" && ["identify"].includes(sub)) {
    const files = nonOptions(rest);
    for (const f of files) {
      const d = fs.existsSync(f) ? driverFor(f) : null;
      if (d) out(`${f}: ${d[0]}`); else if (has(rest, "--report-failures")) out(`${f}: unrecognized`);
    }
    return;
  }
  if (cmd === "dataset" && ["copy","cp"].includes(sub)) { const p=nonOptions(rest); try{copyAny(p[0],p[1]);}catch(e){err(`ERROR 1: ${e.message}`);} return; }
  if (cmd === "dataset" && ["rename","ren","mv"].includes(sub)) { const p=nonOptions(rest); try{fs.renameSync(p[0],p[1]);}catch(e){err(`ERROR 1: ${e.message}`);} return; }
  if (cmd === "dataset" && ["delete","rm","remove"].includes(sub)) { for (const f of nonOptions(rest)) try{fs.rmSync(f,{recursive:true,force:true});}catch(e){err(`ERROR 1: ${e.message}`);} return; }
  if (cmd === "vsi" && ["list","ls"].includes(sub)) {
    const f = nonOptions(rest)[0] || ".";
    try {
      const entries = fs.statSync(f).isDirectory() ? fs.readdirSync(f) : [path.basename(f)];
      if (outputFormat(rest) === "json") out(JSON.stringify(entries, null, 2)); else for (const e of entries) out(e);
    } catch(e) { err(`ERROR 1: ${e.message}`); }
    return;
  }
  if (cmd === "vsi" && ["copy","cp"].includes(sub)) { const p=nonOptions(rest); try{copyAny(p[0],p[1]);}catch(e){err(`ERROR 1: ${e.message}`);} return; }
  if (cmd === "vsi" && ["move","mv","ren","rename"].includes(sub)) { const p=nonOptions(rest); try{fs.renameSync(p[0],p[1]);}catch(e){err(`ERROR 1: ${e.message}`);} return; }
  if (cmd === "vsi" && ["delete","rm","rmdir","del"].includes(sub)) { for (const f of nonOptions(rest)) try{fs.rmSync(f,{recursive:true,force:true});}catch(e){err(`ERROR 1: ${e.message}`);} return; }
  if (cmd === "driver" && sub === "cog" && rest[0] === "validate") {
    const f = nonOptions(rest.slice(1))[0];
    return fs.existsSync(f) ? out(`${f} is a valid cloud optimized GeoTIFF`) : err(`ERROR 4: ${f}: No such file or directory`);
  }
  if (fs.existsSync(cmd)) return vectorInfo(cmd, "text");
  err(`ERROR 1: gdal: Unknown command: '${cmd}'\n` + topBrief);
}
main(process.argv.slice(2));
