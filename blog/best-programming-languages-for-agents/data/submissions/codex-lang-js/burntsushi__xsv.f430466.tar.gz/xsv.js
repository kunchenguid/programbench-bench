#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const COMMANDS = [
  ['cat', 'Concatenate by row or column'],
  ['count', 'Count records'],
  ['fixlengths', 'Makes all records have same length'],
  ['flatten', 'Show one field per line'],
  ['fmt', 'Format CSV output (change field delimiter)'],
  ['frequency', 'Show frequency tables'],
  ['headers', 'Show header names'],
  ['help', 'Show this usage message.'],
  ['index', 'Create CSV index for faster access'],
  ['input', 'Read CSV data with special quoting rules'],
  ['join', 'Join CSV files'],
  ['partition', 'Partition CSV data based on a column value'],
  ['sample', 'Randomly sample CSV data'],
  ['reverse', 'Reverse rows of CSV data'],
  ['search', 'Search CSV data with regexes'],
  ['select', 'Select columns from CSV'],
  ['slice', 'Slice records from CSV'],
  ['sort', 'Sort CSV data'],
  ['split', 'Split CSV data into many files'],
  ['stats', 'Compute basic statistics'],
  ['table', 'Align CSV data into columns'],
];

const HELP = `Usage:
    xsv <command> [<args>...]
    xsv [options]

Options:
    --list        List all commands available.
    -h, --help    Display this message
    <command> -h  Display the command help message
    --version     Print version info and exit

Commands:
${COMMANDS.map(([c, d]) => `    ${c.padEnd(11)} ${d}`).join('\n')}`;

const COMMAND_HELP = {
  count: `Prints a count of the number of records in the CSV data.

Usage:
    xsv count [options] [<input>]`,
  headers: `Prints the fields of the first row in the CSV data.

Usage:
    xsv headers [options] [<input>...]`,
  select: `Select columns from CSV data efficiently.

Usage:
    xsv select [options] [--] <selection> [<input>]`,
  slice: `Returns the rows in the range specified (starting at 0, half-open interval).

Usage:
    xsv slice [options] [<input>]`,
  search: `Filters CSV data by whether the given regex matches a row.

Usage:
    xsv search [options] <regex> [<input>]`,
  sort: `Sorts CSV data lexicographically.

Usage:
    xsv sort [options] [<input>]`,
  table: `Outputs CSV data as a table with columns in alignment.

Usage:
    xsv table [options] [<input>]`,
};

function die(msg, code = 1) {
  process.stderr.write(msg + '\n');
  process.exit(code);
}

function parseArgs(argv, cmd = '') {
  const opts = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') {
      opts._.push(...argv.slice(i + 1));
      break;
    } else if (a === '-h' || a === '--help') opts.help = true;
    else if (a === '-n' || a === '--no-headers') opts.noHeaders = true;
    else if (a === '-o' || a === '--output') opts.output = argv[++i];
    else if (a === '-d' || a === '--delimiter') opts.delimiter = decodeArg(argv[++i]);
    else if (a === '-j' && cmd === 'headers' || a === '--just-names') opts.justNames = true;
    else if (a === '--intersect') opts.intersect = true;
    else if (a === '--select' || (a === '-s' && ['frequency','search','sort','stats'].includes(cmd))) opts.select = argv[++i];
    else if (a === '--start' || (a === '-s' && cmd === 'slice')) opts.start = argv[++i];
    else if (a === '--end' || a === '-e') opts.end = argv[++i];
    else if (a === '--len' || (a === '-l' && cmd === 'slice')) opts.len = argv[++i];
    else if (a === '--index' || (a === '-i' && cmd === 'slice')) opts.index = argv[++i];
    else if (a === '-N' || a === '--numeric') opts.numeric = true;
    else if (a === '-R' || a === '--reverse') opts.reverse = true;
    else if (a === '--ignore-case' || (a === '-i' && cmd === 'search')) opts.ignoreCase = true;
    else if (a === '-v' || a === '--invert-match') opts.invert = true;
    else if (a === '--no-case') opts.noCase = true;
    else if (a === '--left') opts.left = true;
    else if (a === '--right') opts.right = true;
    else if (a === '--full') opts.full = true;
    else if (a === '--cross') opts.cross = true;
    else if (a === '--nulls') opts.nulls = true;
    else if (a === '--no-nulls') opts.noNulls = true;
    else if (a === '--asc' || a === '-a') opts.asc = true;
    else if (a === '--limit' || (a === '-l' && cmd === 'frequency')) opts.limit = argv[++i];
    else if (a === '--length' || (a === '-l' && cmd === 'fixlengths')) opts.length = argv[++i];
    else if (a === '--size' || (a === '-s' && cmd === 'split')) opts.size = argv[++i];
    else if (a === '--pad' || (a === '-p' && cmd === 'cat')) opts.pad = true;
    else if (a === '--filename') opts.filename = argv[++i];
    else if (a === '--prefix-length' || (a === '-p' && cmd === 'partition')) opts.prefixLength = argv[++i];
    else if (a === '--drop') opts.drop = true;
    else if (a === '--seed') opts.seed = argv[++i];
    else if (a === '-w' || a === '--width') opts.width = argv[++i];
    else if (a === '-p' && cmd === 'table') opts.pad = argv[++i];
    else if (a === '-c' || a === '--condense') opts.condense = argv[++i];
    else if (a === '--separator') opts.separator = argv[++i];
    else if (a === '-t' || a === '--out-delimiter') opts.outDelimiter = decodeArg(argv[++i]);
    else if (a === '--crlf') opts.crlf = true;
    else if (a === '--ascii') opts.ascii = true;
    else if (a === '--quote') opts.quote = decodeArg(argv[++i]);
    else if (a === '--quote-always') opts.quoteAlways = true;
    else if (a === '--escape') opts.escape = decodeArg(argv[++i]);
    else if (a === '--no-quoting') opts.noQuoting = true;
    else if (a === '--everything') opts.everything = true;
    else if (a === '--mode') opts.mode = true;
    else if (a === '--cardinality') opts.cardinality = true;
    else if (a === '--median') opts.median = true;
    else if (a === '-j' || a === '--jobs') opts.jobs = argv[++i];
    else opts._.push(a);
  }
  return opts;
}

function decodeArg(s) {
  if (s == null) return s;
  if (s === '\\t') return '\t';
  if (s === '\\0') return '\0';
  return s;
}

function readInput(file) {
  if (file) return fs.readFileSync(file, 'utf8');
  return fs.readFileSync(0, 'utf8');
}

function writeOutput(s, opts = {}) {
  if (opts.output) fs.writeFileSync(opts.output, s);
  else process.stdout.write(s);
}

function parseCSV(text, opt = {}) {
  const delim = opt.delimiter ?? ',';
  const quote = opt.noQuoting ? null : (opt.quote ?? '"');
  const esc = opt.escape;
  const rows = [];
  let row = [], field = '', inq = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inq) {
      if (esc && ch === esc && i + 1 < text.length) field += text[++i];
      else if (ch === quote) {
        if (!esc && text[i + 1] === quote) { field += quote; i++; }
        else inq = false;
      } else field += ch;
    } else {
      if (quote && ch === quote && field === '') inq = true;
      else if (ch === delim) { row.push(field); field = ''; }
      else if (ch === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
      else if (ch === '\r') {
        if (text[i + 1] === '\n') i++;
        row.push(field); rows.push(row); row = []; field = '';
      } else field += ch;
    }
  }
  if (field.length || row.length || text.length && !/[\r\n]$/.test(text)) {
    row.push(field);
    rows.push(row);
  }
  return rows;
}

function csvQuote(v, opt = {}) {
  v = v == null ? '' : String(v);
  const delim = opt.delimiter ?? ',';
  const quote = opt.quote ?? '"';
  if (opt.noQuoting) return v;
  const must = opt.quoteAlways || v.includes(delim) || v.includes('\n') || v.includes('\r') || v.includes(quote);
  if (!must) return v;
  if (opt.escape) return quote + v.replaceAll(opt.escape, opt.escape + opt.escape).replaceAll(quote, opt.escape + quote) + quote;
  return quote + v.replaceAll(quote, quote + quote) + quote;
}

function writeCSV(rows, opt = {}) {
  const delim = opt.outDelimiter ?? opt.delimiter ?? ',';
  const eol = opt.crlf ? '\r\n' : '\n';
  return rows.map(r => r.map(v => csvQuote(v, {...opt, delimiter: delim})).join(delim)).join(eol) + (rows.length ? eol : '');
}

function dataRows(rows, noHeaders) {
  return noHeaders ? [null, rows] : [rows[0] || [], rows.slice(1)];
}

function splitSelection(s) {
  const out = []; let cur = '', q = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === '"') { q = !q; cur += ch; }
    else if (ch === ',' && !q) { out.push(cur); cur = ''; }
    else cur += ch;
  }
  out.push(cur);
  return out.filter(x => x.length);
}

function nameIndex(headers, name, occurrence = 1) {
  let seen = 0;
  for (let i = 0; i < headers.length; i++) {
    if (headers[i] === name && ++seen === occurrence) return i;
  }
  return -1;
}

function parseOneSelector(tok, headers, width) {
  tok = tok.trim();
  if (tok.startsWith('"') && tok.endsWith('"')) tok = tok.slice(1, -1).replace(/""/g, '"');
  let occ = 1;
  const m = tok.match(/^(.*)\[(\d+)\]$/);
  if (m) { tok = m[1]; occ = parseInt(m[2], 10); }
  if (/^\d+$/.test(tok)) return parseInt(tok, 10) - 1;
  if (tok === '') return -1;
  const idx = headers ? nameIndex(headers, tok, occ) : -1;
  if (idx >= 0) return idx;
  return -1;
}

function findRangeDash(tok) {
  let q = false;
  for (let i = 0; i < tok.length; i++) {
    if (tok[i] === '"') q = !q;
    else if (tok[i] === '-' && !q) return i;
  }
  return -1;
}

function selectIndices(sel, headers, width) {
  if (!sel) return [...Array(width).keys()];
  let invert = false;
  if (sel.startsWith('!')) { invert = true; sel = sel.slice(1); }
  const indices = [];
  for (const raw of splitSelection(sel)) {
    const dash = findRangeDash(raw);
    if (dash >= 0) {
      const a = raw.slice(0, dash).trim(), b = raw.slice(dash + 1).trim();
      let start = a ? parseOneSelector(a, headers, width) : 0;
      let end = b ? parseOneSelector(b, headers, width) : width - 1;
      if (start < 0) start = 0;
      if (end < 0) end = width - 1;
      const step = start <= end ? 1 : -1;
      for (let i = start; step > 0 ? i <= end : i >= end; i += step) indices.push(i);
    } else {
      const idx = parseOneSelector(raw, headers, width);
      if (idx >= 0) indices.push(idx);
    }
  }
  if (invert) {
    const drop = new Set(indices);
    return [...Array(width).keys()].filter(i => !drop.has(i));
  }
  return indices;
}

function readRows(file, opts) {
  return parseCSV(readInput(file), opts);
}

function padGet(row, i) { return i < row.length ? row[i] : ''; }

function main() {
  const argv = process.argv.slice(2);
  if (argv.length === 0 || argv[0] === '-h' || argv[0] === '--help' || argv[0] === 'help') return console.log(HELP);
  if (argv[0] === '--version') return console.log('0.13.0');
  if (argv[0] === '--list') return console.log('Installed commands:\n' + COMMANDS.map(([c, d]) => `    ${c.padEnd(11)} ${d}`).join('\n') + '\n');
  const cmd = argv.shift();
  const opts = parseArgs(argv, cmd);
  if (opts.help) return console.log(COMMAND_HELP[cmd] || HELP);
  try {
    if (cmd === 'count') return cmdCount(opts);
    if (cmd === 'headers') return cmdHeaders(opts);
    if (cmd === 'select') return cmdSelect(opts);
    if (cmd === 'slice') return cmdSlice(opts);
    if (cmd === 'search') return cmdSearch(opts);
    if (cmd === 'sort') return cmdSort(opts);
    if (cmd === 'reverse') return cmdReverse(opts);
    if (cmd === 'frequency') return cmdFrequency(opts);
    if (cmd === 'stats') return cmdStats(opts);
    if (cmd === 'flatten') return cmdFlatten(opts);
    if (cmd === 'table') return cmdTable(opts);
    if (cmd === 'fmt' || cmd === 'input') return cmdFmt(opts);
    if (cmd === 'fixlengths') return cmdFixlengths(opts);
    if (cmd === 'cat') return cmdCat(opts);
    if (cmd === 'join') return cmdJoin(opts);
    if (cmd === 'sample') return cmdSample(opts);
    if (cmd === 'split') return cmdSplit(opts);
    if (cmd === 'partition') return cmdPartition(opts);
    if (cmd === 'index') return cmdIndex(opts);
    die(`Unrecognized command '${cmd}'.`);
  } catch (e) {
    die(e.message || String(e));
  }
}

function cmdCount(opts) {
  const rows = readRows(opts._[0], opts);
  console.log(String(Math.max(0, rows.length - (opts.noHeaders ? 0 : 1))));
}

function cmdHeaders(opts) {
  const files = opts._;
  const all = (files.length ? files : [null]).map(f => (readRows(f, opts)[0] || []));
  let h = all[0] || [];
  if (opts.intersect) {
    h = h.filter(x => all.every(a => a.includes(x)));
  }
  const just = opts.justNames || files.length > 1 || opts.intersect;
  const out = just ? h.map(x => x + '\n').join('') : h.map((x, i) => `${String(i + 1).padEnd(4)}${x}\n`).join('');
  process.stdout.write(out);
}

function cmdSelect(opts) {
  const sel = opts._[0]; if (!sel) die('Selection required.');
  const file = opts._[1];
  const rows = readRows(file, opts);
  const [headers] = dataRows(rows, opts.noHeaders);
  const width = Math.max(...rows.map(r => r.length), 0);
  const idx = selectIndices(sel, opts.noHeaders ? null : headers, width);
  writeOutput(writeCSV(rows.map(r => idx.map(i => padGet(r, i))), opts), opts);
}

function cmdSlice(opts) {
  const rows = readRows(opts._[0], opts);
  const [headers, body] = dataRows(rows, opts.noHeaders);
  let start = opts.index != null ? Number(opts.index) : Number(opts.start || 0);
  let end = opts.index != null ? start + 1 : (opts.len != null ? start + Number(opts.len) : (opts.end != null ? Number(opts.end) : body.length));
  const out = (opts.noHeaders ? [] : [headers]).concat(body.slice(start, end));
  writeOutput(writeCSV(out, opts), opts);
}

function cmdSearch(opts) {
  const regexArg = opts._[0]; if (regexArg == null) die('Regex required.');
  const file = opts._[1];
  const rows = readRows(file, opts);
  const [headers, body] = dataRows(rows, opts.noHeaders);
  const width = Math.max(...rows.map(r => r.length), 0);
  const idx = opts.select ? selectIndices(opts.select, opts.noHeaders ? null : headers, width) : [...Array(width).keys()];
  const re = new RegExp(regexArg, opts.ignoreCase ? 'i' : '');
  const filtered = body.filter(r => {
    const m = idx.some(i => re.test(padGet(r, i)));
    return opts.invert ? !m : m;
  });
  writeOutput(writeCSV((opts.noHeaders ? [] : [headers]).concat(filtered), opts), opts);
}

function rowKey(row, idx) { return idx.map(i => padGet(row, i)); }

function cmpVals(a, b, numeric) {
  if (numeric) {
    const na = parseFloat(a), nb = parseFloat(b);
    if (!Number.isNaN(na) || !Number.isNaN(nb)) {
      if (Number.isNaN(na)) return -1;
      if (Number.isNaN(nb)) return 1;
      if (na !== nb) return na - nb;
    }
  }
  return String(a).localeCompare(String(b), 'en', {sensitivity: 'variant'});
}

function cmdSort(opts) {
  const rows = readRows(opts._[0], opts);
  const [headers, body] = dataRows(rows, opts.noHeaders);
  const width = Math.max(...rows.map(r => r.length), 0);
  const idx = opts.select ? selectIndices(opts.select, opts.noHeaders ? null : headers, width) : [...Array(width).keys()];
  body.sort((ra, rb) => {
    for (let i of idx) {
      const c = cmpVals(padGet(ra, i), padGet(rb, i), opts.numeric);
      if (c) return opts.reverse ? -c : c;
    }
    return 0;
  });
  writeOutput(writeCSV((opts.noHeaders ? [] : [headers]).concat(body), opts), opts);
}

function cmdReverse(opts) {
  const rows = readRows(opts._[0], opts);
  const [headers, body] = dataRows(rows, opts.noHeaders);
  body.reverse();
  writeOutput(writeCSV((opts.noHeaders ? [] : [headers]).concat(body), opts), opts);
}

function cmdFrequency(opts) {
  const rows = readRows(opts._[0], opts);
  const [headers, body] = dataRows(rows, opts.noHeaders);
  const width = Math.max(...rows.map(r => r.length), 0);
  const idx = opts.select ? selectIndices(opts.select, opts.noHeaders ? null : headers, width) : [...Array(width).keys()];
  const limit = opts.limit == null ? 10 : Number(opts.limit);
  const out = [['field', 'value', 'count']];
  for (const i of idx) {
    const m = new Map();
    for (const r of body) {
      const v = padGet(r, i);
      if (opts.noNulls && v === '') continue;
      m.set(v, (m.get(v) || 0) + 1);
    }
    let vals = [...m.entries()].sort((a, b) => opts.asc ? a[1] - b[1] : b[1] - a[1]);
    if (limit > 0) vals = vals.slice(0, limit);
    const field = opts.noHeaders ? String(i + 1) : padGet(headers, i);
    for (const [v, c] of vals) out.push([field, v, String(c)]);
  }
  writeOutput(writeCSV(out, opts), opts);
}

function inferType(values) {
  const non = values.filter(v => v !== '');
  if (non.length === 0) return 'NULL';
  if (non.every(v => /^[-+]?\d+$/.test(v))) return 'Integer';
  if (non.every(v => v !== '' && !Number.isNaN(Number(v)))) return 'Float';
  return 'Unicode';
}

function stddev(nums) {
  const n = nums.length; if (!n) return '';
  const mean = nums.reduce((a,b)=>a+b,0) / n;
  return Math.sqrt(nums.reduce((a,b)=>a+(b-mean)*(b-mean),0) / n);
}

function cmdStats(opts) {
  const rows = readRows(opts._[0], opts);
  const [headers, body] = dataRows(rows, opts.noHeaders);
  const width = Math.max(...rows.map(r => r.length), 0);
  const idx = opts.select ? selectIndices(opts.select, opts.noHeaders ? null : headers, width) : [...Array(width).keys()];
  const extras = opts.everything || opts.mode || opts.cardinality || opts.median;
  const head = ['field','type','sum','min','max','min_length','max_length','mean','stddev'];
  if (opts.everything || opts.median) head.push('median');
  if (opts.everything || opts.mode) head.push('mode');
  if (opts.everything || opts.cardinality) head.push('cardinality');
  const out = [head];
  for (const i of idx) {
    const vals = body.map(r => padGet(r, i));
    const type = inferType(vals);
    const nums = vals.filter(v => v !== '' && !Number.isNaN(Number(v))).map(Number);
    const non = vals.filter(v => v !== '');
    const lens = vals.map(v => [...v].length);
    const sum = nums.length ? nums.reduce((a,b)=>a+b,0) : '';
    const mean = nums.length ? sum / (opts.nulls ? vals.length : nums.length) : '';
    const sortedVals = [...non].sort();
    const min = sortedVals[0] ?? '';
    const max = sortedVals[sortedVals.length - 1] ?? '';
    const row = [opts.noHeaders ? String(i + 1) : padGet(headers, i), type, fmtNum(sum), min, max, String(lens.length ? Math.min(...lens) : 0), String(lens.length ? Math.max(...lens) : 0), fmtNum(mean), fmtStd(stddev(opts.nulls ? vals.map(v => Number(v) || 0) : nums))];
    if (opts.everything || opts.median) {
      const sn = [...nums].sort((a,b)=>a-b);
      row.push(sn.length ? fmtNum(sn.length % 2 ? sn[(sn.length-1)/2] : (sn[sn.length/2-1]+sn[sn.length/2])/2) : '');
    }
    if (opts.everything || opts.mode) {
      const m = new Map(); for (const v of non) m.set(v, (m.get(v)||0)+1);
      row.push([...m.entries()].sort((a,b)=>b[1]-a[1] || a[0].localeCompare(b[0]))[0]?.[0] || '');
    }
    if (opts.everything || opts.cardinality) row.push(String(new Set(non).size));
    out.push(row);
  }
  writeOutput(writeCSV(out, opts), opts);
}

function fmtNum(n) {
  return n === '' || n == null || Number.isNaN(n) ? '' : String(n);
}

function fmtStd(n) {
  return n === '' || n == null || Number.isNaN(n) ? '' : Number(n.toPrecision(16)).toString();
}

function cmdFlatten(opts) {
  const rows = readRows(opts._[0], opts);
  const [headers, body] = dataRows(rows, opts.noHeaders);
  const labels = opts.noHeaders ? null : headers;
  const sep = opts.separator ?? '#';
  const cond = opts.condense == null ? null : Number(opts.condense);
  const width = Math.max(...rows.map(r => r.length), 0);
  const names = [...Array(width).keys()].map(i => labels ? padGet(labels, i) : String(i + 1));
  const pad = Math.max(...names.map(x => x.length), 0) + 2;
  let out = '';
  body.forEach((r, ri) => {
    for (let i = 0; i < width; i++) out += names[i].padEnd(pad) + condense(padGet(r, i), cond) + '\n';
    if (sep && ri !== body.length - 1) out += sep + '\n';
  });
  process.stdout.write(out);
}

function condense(s, n) {
  if (n == null || [...s].length <= n) return s;
  return [...s].slice(0, Math.max(0, n)).join('');
}

function cmdTable(opts) {
  const rows = readRows(opts._[0], opts);
  const minw = Number(opts.width || 2), pad = Number(opts.pad || 2), cond = opts.condense == null ? null : Number(opts.condense);
  const outRows = rows.map(r => r.map(v => condense(v, cond)));
  const width = Math.max(...outRows.map(r => r.length), 0);
  const colw = [...Array(width).keys()].map(i => Math.max(minw, ...outRows.map(r => (r[i] || '').length)));
  let out = '';
  for (const r of outRows) {
    out += [...Array(width).keys()].map((i) => {
      const v = r[i] || '';
      return i === width - 1 ? v : v.padEnd(colw[i] + pad);
    }).join('').replace(/\s+$/,'') + '\n';
  }
  writeOutput(out, opts);
}

function cmdFmt(opts) {
  if (opts.ascii) { opts.outDelimiter = '\x1f'; opts.crlf = false; }
  const rows = readRows(opts._[0], opts);
  writeOutput(writeCSV(rows, opts), opts);
}

function cmdFixlengths(opts) {
  const rows = readRows(opts._[0], opts);
  const len = opts.length != null ? Number(opts.length) : Math.max(1, ...rows.map(r => {
    let n = r.length; while (n > 0 && r[n-1] === '') n--; return n;
  }));
  const out = rows.map(r => [...Array(len).keys()].map(i => padGet(r, i)));
  writeOutput(writeCSV(out, opts), opts);
}

function cmdCat(opts) {
  const mode = opts._[0]; const files = opts._.slice(1);
  if (mode === 'rows') {
    const out = [];
    files.forEach((f, fi) => {
      const rows = readRows(f, opts);
      if (!opts.noHeaders && fi > 0) out.push(...rows.slice(1));
      else out.push(...rows);
    });
    writeOutput(writeCSV(out, opts), opts);
  } else if (mode === 'columns') {
    const sets = files.map(f => readRows(f, opts));
    const n = opts.pad === true ? Math.max(...sets.map(s => s.length)) : Math.min(...sets.map(s => s.length));
    const out = [];
    for (let i = 0; i < n; i++) out.push(sets.flatMap(s => s[i] || []));
    writeOutput(writeCSV(out, opts), opts);
  } else die('Expected rows or columns.');
}

function makeJoinKey(row, idx, opts) {
  const vals = idx.map(i => padGet(row, i).trim());
  if (!opts.nulls && vals.some(v => v === '')) return null;
  return (opts.noCase ? vals.map(v => v.toLowerCase()) : vals).join('\0');
}

function cmdJoin(opts) {
  const [cols1, f1, cols2, f2] = opts._;
  if (opts.cross) return cmdCrossJoin(opts, f1 || opts._[0], f2 || opts._[1]);
  const r1 = readRows(f1, opts), r2 = readRows(f2, opts);
  const [h1, b1] = dataRows(r1, opts.noHeaders), [h2, b2] = dataRows(r2, opts.noHeaders);
  const i1 = selectIndices(cols1, opts.noHeaders ? null : h1, Math.max(...r1.map(r => r.length), 0));
  const i2 = selectIndices(cols2, opts.noHeaders ? null : h2, Math.max(...r2.map(r => r.length), 0));
  const map = new Map();
  b2.forEach((r, pos) => {
    const k = makeJoinKey(r, i2, opts); if (k == null) return;
    if (!map.has(k)) map.set(k, []);
    map.get(k).push([r, pos]);
  });
  const matched2 = new Set();
  const out = opts.noHeaders ? [] : [h1.concat(h2)];
  for (const a of b1) {
    const k = makeJoinKey(a, i1, opts);
    const ms = k == null ? null : map.get(k);
    if (ms && ms.length) {
      for (const [b, pos] of ms) { matched2.add(pos); out.push(a.concat(b)); }
    } else if (opts.left || opts.full) out.push(a.concat(Array(h2.length || (r2[0] || []).length).fill('')));
  }
  if (opts.right || opts.full) {
    const pad = Array(h1.length || (r1[0] || []).length).fill('');
    b2.forEach((b, pos) => { if (!matched2.has(pos)) out.push(pad.concat(b)); });
  }
  writeOutput(writeCSV(out, opts), opts);
}

function cmdCrossJoin(opts, f1, f2) {
  const r1 = readRows(f1, opts), r2 = readRows(f2, opts);
  const [h1, b1] = dataRows(r1, opts.noHeaders), [h2, b2] = dataRows(r2, opts.noHeaders);
  const out = opts.noHeaders ? [] : [h1.concat(h2)];
  for (const a of b1) for (const b of b2) out.push(a.concat(b));
  writeOutput(writeCSV(out, opts), opts);
}

function rng(seed) {
  let x = (Number(seed) || Date.now()) >>> 0;
  return () => ((x = (1664525 * x + 1013904223) >>> 0) / 0x100000000);
}

function cmdSample(opts) {
  const n = Number(opts._[0]); const rows = readRows(opts._[1], opts);
  const [headers, body] = dataRows(rows, opts.noHeaders);
  const rand = rng(opts.seed);
  const arr = body.map((r, i) => [rand(), i, r]).sort((a,b)=>a[0]-b[0]).slice(0, n).sort((a,b)=>a[1]-b[1]).map(x=>x[2]);
  writeOutput(writeCSV((opts.noHeaders ? [] : [headers]).concat(arr), opts), opts);
}

function safeName(v) {
  return (v || '').replace(/[^A-Za-z0-9._-]+/g, '_') || '_';
}

function cmdSplit(opts) {
  const [outdir, file] = opts._; fs.mkdirSync(outdir, {recursive: true});
  const rows = readRows(file, opts); const [headers, body] = dataRows(rows, opts.noHeaders);
  const size = Number(opts.size || 500), tmpl = opts.filename || '{}.csv';
  for (let i = 0; i < body.length; i += size) {
    const chunk = (opts.noHeaders ? [] : [headers]).concat(body.slice(i, i + size));
    fs.writeFileSync(path.join(outdir, tmpl.replace('{}', String(i))), writeCSV(chunk, opts));
  }
}

function cmdPartition(opts) {
  const [col, outdir, file] = opts._; fs.mkdirSync(outdir, {recursive: true});
  const rows = readRows(file, opts); const [headers, body] = dataRows(rows, opts.noHeaders);
  const idx = selectIndices(col, opts.noHeaders ? null : headers, Math.max(...rows.map(r=>r.length), 0))[0] || 0;
  const tmpl = opts.filename || '{}.csv', groups = new Map();
  for (const r of body) {
    let key = padGet(r, idx); if (opts.prefixLength) key = key.slice(0, Number(opts.prefixLength));
    const name = tmpl.replace('{}', safeName(key));
    if (!groups.has(name)) groups.set(name, []);
    groups.get(name).push(opts.drop ? r.filter((_, i) => i !== idx) : r);
  }
  for (const [name, rs] of groups) {
    const head = opts.noHeaders ? [] : [opts.drop ? headers.filter((_, i) => i !== idx) : headers];
    fs.writeFileSync(path.join(outdir, name), writeCSV(head.concat(rs), opts));
  }
}

function cmdIndex(opts) {
  const input = opts._[0]; if (!input) die('Input required.');
  const out = opts.output || input + '.idx';
  const rows = readRows(input, opts);
  fs.writeFileSync(out, JSON.stringify({rows: rows.length}) + '\n');
}

main();
