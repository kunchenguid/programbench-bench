#!/usr/bin/env node
'use strict';

const fs = require('fs');
const { spawnSync } = require('child_process');

const HELP = `A command-line benchmarking tool.

Usage: executable [OPTIONS] <command>...

Arguments:
  <command>...
          The command to benchmark. This can be the name of an executable, a
          command line like "grep -i todo" or a shell command like "sleep 0.5 &&
          echo test". The latter is only available if the shell is not
          explicitly disabled via '--shell=none'. If multiple commands are
          given, hyperfine will show a comparison of the respective runtimes.

Options:
  -w, --warmup <NUM>
          Perform NUM warmup runs before the actual benchmark. This can be used
          to fill (disk) caches for I/O-heavy programs.
  -m, --min-runs <NUM>
          Perform at least NUM runs for each command (default: 10).
  -M, --max-runs <NUM>
          Perform at most NUM runs for each command. By default, there is no
          limit.
  -r, --runs <NUM>
          Perform exactly NUM runs for each command. If this option is not
          specified, hyperfine automatically determines the number of runs.
  -s, --setup <CMD>
          Execute CMD before each set of timing runs.
      --reference <CMD>
          The reference command for the relative comparison of results.
      --reference-name <CMD>
          Give a meaningful name to the reference command.
  -p, --prepare <CMD>
          Execute CMD before each timing run.
  -C, --conclude <CMD>
          Execute CMD after each timing run.
  -c, --cleanup <CMD>
          Execute CMD after the completion of all benchmarking runs for each
          individual command to be benchmarked.
  -P, --parameter-scan <VAR> <MIN> <MAX>
          Perform benchmark runs for each value in the range MIN..MAX.
  -D, --parameter-step-size <DELTA>
          This argument requires --parameter-scan to be specified as well.
  -L, --parameter-list <VAR> <VALUES>
          Perform benchmark runs for each value in the comma-separated list
          VALUES.
  -S, --shell <SHELL>
          Set the shell to use for executing benchmarked commands.
  -N
          An alias for '--shell=none'.
  -i, --ignore-failure[=<MODE>]
          Ignore failures of the benchmarked programs.
      --style <TYPE>
          Set output style type (default: auto).
      --sort <METHOD>
          Specify the sort order of the speed comparison summary and the
          exported tables for markup formats (Markdown, AsciiDoc, org-mode).
  -u, --time-unit <UNIT>
          Set the time unit to be used. Possible values: microsecond,
          millisecond, second.
      --export-asciidoc <FILE>
          Export the timing summary statistics as an AsciiDoc table.
      --export-csv <FILE>
          Export the timing summary statistics as CSV.
      --export-json <FILE>
          Export the timing summary statistics and timings of individual runs
          as JSON.
      --export-markdown <FILE>
          Export the timing summary statistics as a Markdown table.
      --export-orgmode <FILE>
          Export the timing summary statistics as an Emacs org-mode table.
      --show-output
          Print the stdout and stderr of the benchmark instead of suppressing it.
      --output <WHERE>
          Control where the output of the benchmark is redirected.
      --input <WHERE>
          Control where the input of the benchmark comes from.
  -n, --command-name <NAME>
          Give a meaningful name to a command.
  -h, --help
          Print help
  -V, --version
          Print version
`;

function die(msg, usage = true) {
  console.error(msg);
  if (usage) console.error('\nFor more information, try \'--help\'.');
  process.exit(1);
}

function nextValue(args, i, opt) {
  if (i + 1 >= args.length) die(`error: a value is required for '${opt}'`);
  return [args[i + 1], i + 1];
}

function parseArgs(argv) {
  const o = {
    warmup: 0, minRuns: 10, maxRuns: null, runs: null, setup: [],
    prepare: [], conclude: [], cleanup: [], scans: [], lists: [],
    step: 1, shell: 'default', ignoreFailure: null, style: 'auto',
    sort: 'auto', unit: null, exports: {}, showOutput: false,
    outputs: [], input: 'null', names: [], commands: [],
    reference: null, referenceName: null,
  };
  const valOpts = new Set(['--warmup','--min-runs','--max-runs','--runs','--setup','--prepare','--conclude','--cleanup','--shell','--style','--sort','--time-unit','--export-asciidoc','--export-csv','--export-json','--export-markdown','--export-orgmode','--output','--input','--command-name','--parameter-step-size','--reference','--reference-name']);
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '--') { o.commands.push(...argv.slice(i + 1)); break; }
    if (!a.startsWith('-') || a === '-') { o.commands.push(a); continue; }
    let attached = null;
    if (a.startsWith('--') && a.includes('=')) [a, attached] = a.split(/=(.*)/s, 2);
    const get = () => {
      if (attached !== null) return attached;
      const r = nextValue(argv, i, a); i = r[1]; return r[0];
    };
    if (a === '-h' || a === '--help') { console.log(HELP.trimEnd()); process.exit(0); }
    else if (a === '-V' || a === '--version') { console.log('hyperfine 1.20.0'); process.exit(0); }
    else if (a === '-N') o.shell = 'none';
    else if (a === '-i' || a === '--ignore-failure') o.ignoreFailure = attached !== null ? attached : 'all';
    else if (a === '-w' || a === '--warmup') o.warmup = parseInt(get(), 10);
    else if (a === '-m' || a === '--min-runs') o.minRuns = parseInt(get(), 10);
    else if (a === '-M' || a === '--max-runs') o.maxRuns = parseInt(get(), 10);
    else if (a === '-r' || a === '--runs') o.runs = parseInt(get(), 10);
    else if (a === '-s' || a === '--setup') o.setup.push(get());
    else if (a === '-p' || a === '--prepare') o.prepare.push(get());
    else if (a === '-C' || a === '--conclude') o.conclude.push(get());
    else if (a === '-c' || a === '--cleanup') o.cleanup.push(get());
    else if (a === '-S' || a === '--shell') o.shell = get();
    else if (a === '--style') o.style = get();
    else if (a === '--sort') o.sort = get();
    else if (a === '-u' || a === '--time-unit') o.unit = get();
    else if (a === '--export-asciidoc') o.exports.asciidoc = get();
    else if (a === '--export-csv') o.exports.csv = get();
    else if (a === '--export-json') o.exports.json = get();
    else if (a === '--export-markdown') o.exports.markdown = get();
    else if (a === '--export-orgmode') o.exports.orgmode = get();
    else if (a === '--show-output') o.showOutput = true;
    else if (a === '--output') o.outputs.push(get());
    else if (a === '--input') o.input = get();
    else if (a === '-n' || a === '--command-name') o.names.push(get());
    else if (a === '--reference') o.reference = get();
    else if (a === '--reference-name') o.referenceName = get();
    else if (a === '-D' || a === '--parameter-step-size') o.step = parseFloat(get());
    else if (a === '-P' || a === '--parameter-scan') {
      const v = get(), min = get(), max = get();
      o.scans.push({ var: v, min, max });
    } else if (a === '-L' || a === '--parameter-list') {
      const v = get(), values = get();
      o.lists.push({ var: v, values: values.split(',') });
    } else if (valOpts.has(a)) get();
    else die(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] <command>...`, false);
  }
  if (o.showOutput && o.style !== 'auto') die(`error: the argument '--style <TYPE>' cannot be used with '--show-output'\n\nUsage: executable --style <TYPE> <command>...`, false);
  if (o.commands.length === 0) die("error: the following required arguments were not provided:\n  <command>...\n\nUsage: executable <command>...", false);
  return o;
}

function shellSplit(s) {
  const out = []; let cur = '', q = null, esc = false;
  for (const ch of s) {
    if (esc) { cur += ch; esc = false; continue; }
    if (ch === '\\' && q !== "'") { esc = true; continue; }
    if (q) { if (ch === q) q = null; else cur += ch; continue; }
    if (ch === '"' || ch === "'") { q = ch; continue; }
    if (/\s/.test(ch)) { if (cur) { out.push(cur); cur = ''; } continue; }
    cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

function runCommand(command, opts, iter, outputWhere) {
  const env = { ...process.env, HYPERFINE_ITERATION: String(iter) };
  let stdio = ['ignore', 'ignore', 'ignore'];
  let inputFd, outFd;
  if (opts.input && opts.input !== 'null') { inputFd = fs.openSync(opts.input, 'r'); stdio[0] = inputFd; }
  if (opts.showOutput || outputWhere === 'inherit') stdio = [stdio[0], 'inherit', 'inherit'];
  else if (outputWhere && outputWhere !== 'null' && outputWhere !== 'pipe') { outFd = fs.openSync(outputWhere, 'a'); stdio[1] = outFd; stdio[2] = outFd; }
  else if (outputWhere === 'pipe') { stdio[1] = 'pipe'; stdio[2] = 'pipe'; }
  const startUsage = process.resourceUsage();
  const start = process.hrtime.bigint();
  let r;
  if (opts.shell === 'none') {
    const parts = shellSplit(command);
    r = spawnSync(parts[0], parts.slice(1), { stdio, env });
  } else {
    let shell = opts.shell === 'default' ? '/bin/sh' : opts.shell;
    const parts = shellSplit(shell);
    r = spawnSync(parts[0], [...parts.slice(1), '-c', command], { stdio, env });
  }
  const end = process.hrtime.bigint();
  const endUsage = process.resourceUsage();
  if (inputFd) fs.closeSync(inputFd);
  if (outFd) fs.closeSync(outFd);
  const code = r.status === null || r.status === undefined ? 1 : r.status;
  const user = (endUsage.userCPUTime - startUsage.userCPUTime) / 1e6;
  const system = (endUsage.systemCPUTime - startUsage.systemCPUTime) / 1e6;
  return { time: Number(end - start) / 1e9, code, user, system, rss: r.resourceUsage?.maxRSS ? r.resourceUsage.maxRSS * 1024 : 0 };
}

function runHook(command, opts, iter) {
  if (!command) return;
  const hookOpts = { ...opts, showOutput: opts.showOutput };
  const r = runCommand(command, hookOpts, iter, opts.showOutput ? 'inherit' : 'null');
  if (r.code !== 0) process.exit(r.code);
}

function mean(xs) { return xs.reduce((a, b) => a + b, 0) / xs.length; }
function median(xs) { const a = [...xs].sort((x, y) => x - y); const n = a.length; return n % 2 ? a[(n - 1) / 2] : (a[n / 2 - 1] + a[n / 2]) / 2; }
function stddev(xs) { if (xs.length < 2) return 0; const m = mean(xs); return Math.sqrt(xs.reduce((s, x) => s + (x - m) ** 2, 0) / (xs.length - 1)); }

function valuesForScan(scan, step) {
  const min = Number(scan.min), max = Number(scan.max);
  const dec = Math.max(decimals(scan.min), decimals(scan.max), decimals(String(step)));
  const vals = [];
  for (let x = min; x <= max + Math.abs(step) / 1e6; x += step) vals.push(x.toFixed(dec).replace(/\.?0+$/, ''));
  return vals;
}
function decimals(s) { const m = String(s).match(/\.(\d+)/); return m ? m[1].length : 0; }

function combinations(params) {
  let rows = [{}];
  for (const p of params) {
    const next = [];
    for (const row of rows) for (const v of p.values) next.push({ ...row, [p.var]: v });
    rows = next;
  }
  return rows;
}
function subst(s, row) {
  let r = s;
  for (const [k, v] of Object.entries(row)) r = r.split(`{${k}}`).join(v);
  return r;
}
function expand(opts) {
  const params = [];
  for (const s of opts.scans) params.push({ var: s.var, values: valuesForScan(s, opts.step) });
  for (const l of opts.lists) params.push(l);
  const rows = params.length ? combinations(params) : [{}];
  const commands = [];
  for (const row of rows) for (const c of opts.commands) commands.push({ command: subst(c, row), row });
  return commands;
}

function ignored(code, mode) {
  if (code === 0) return true;
  if (!mode || mode === 'all' || mode === 'all-non-zero') return !!mode;
  return mode.split(',').map(x => parseInt(x, 10)).includes(code);
}

function fmtTime(sec, unit) {
  let u = unit;
  if (!u) u = sec < 0.001 ? 'microsecond' : sec < 1 ? 'millisecond' : 'second';
  const scale = u === 'microsecond' ? 1e6 : u === 'millisecond' ? 1e3 : 1;
  const label = u === 'microsecond' ? 'µs' : u === 'millisecond' ? 'ms' : 's';
  return { value: sec * scale, label };
}
function f1(x) { return x >= 100 ? x.toFixed(0) : x >= 10 ? x.toFixed(1) : x.toFixed(1); }
function pad(s, n) { s = String(s); return s.length >= n ? s : ' '.repeat(n - s.length) + s; }

function resultFor(cmdObj, idx, opts, total) {
  const cmd = cmdObj.command;
  if (opts.style !== 'none') console.log(`Benchmark ${idx + 1}: ${opts.names[idx] || cmd}`);
  const runs = opts.runs || Math.max(opts.minRuns, 10);
  const outputWhere = opts.outputs.length ? (opts.outputs[idx] || opts.outputs[0]) : (opts.showOutput ? 'inherit' : 'null');
  const prep = opts.prepare[idx] || opts.prepare[0];
  const concl = opts.conclude[idx] || opts.conclude[0];
  for (const s of opts.setup) runHook(subst(s, cmdObj.row), opts, 0);
  for (let i = 0; i < opts.warmup; i++) runCommand(cmd, opts, i + 1, outputWhere);
  const times = [], codes = [], mem = []; let user = 0, system = 0;
  for (let i = 0; i < runs; i++) {
    runHook(subst(prep || '', cmdObj.row), opts, i + 1);
    const r = runCommand(cmd, opts, i + 1, outputWhere);
    runHook(subst(concl || '', cmdObj.row), opts, i + 1);
    if (!ignored(r.code, opts.ignoreFailure)) {
      console.error(`Error: Command terminated with non-zero exit code ${r.code} in the ${i === 0 ? 'first' : ordinal(i + 1)} benchmark run. Use the '-i'/'--ignore-failure' option if you want to ignore this. Alternatively, use the '--show-output' option to debug what went wrong.`);
      process.exit(1);
    }
    times.push(r.time); codes.push(r.code); mem.push(r.rss); user += r.user; system += r.system;
  }
  for (const c of opts.cleanup) runHook(subst(c, cmdObj.row), opts, 0);
  const res = { command: opts.names[idx] || cmd, originalCommand: cmd, mean: mean(times), stddev: stddev(times), median: median(times), user: user / runs, system: system / runs, min: Math.min(...times), max: Math.max(...times), times, memory_usage_byte: mem, exit_codes: codes };
  if (opts.style !== 'none') printResult(res, runs, opts);
  if (times.some(t => t < 0.005) && opts.shell !== 'none') console.error(" \n  Warning: Command took less than 5 ms to complete. Note that the results might be inaccurate because hyperfine can not calibrate the shell startup time much more precise than this limit. You can try to use the `-N`/`--shell=none` option to disable the shell completely.");
  if (codes.some(c => c !== 0)) console.error("  Warning: Ignoring non-zero exit code.");
  return res;
}
function ordinal(n) { return n + (n === 2 ? 'second' : n === 3 ? 'third' : 'th'); }

function printResult(r, runs, opts) {
  const tm = fmtTime(r.mean, opts.unit), sd = fmtTime(r.stddev, opts.unit), mn = fmtTime(r.min, opts.unit), mx = fmtTime(r.max, opts.unit);
  if (runs === 1) {
    console.log(`  Time (abs ≡):       ${pad(f1(tm.value), 6)} ${tm.label}               [User: ${f1(r.user * 1000)} ms, System: ${f1(r.system * 1000)} ms]`);
    console.log(' ');
  } else {
    console.log(`  Time (mean ± σ):    ${pad(f1(tm.value), 6)} ${tm.label} ± ${pad(f1(sd.value), 5)} ${tm.label}    [User: ${f1(r.user * 1000)} ms, System: ${f1(r.system * 1000)} ms]`);
    console.log(`  Range (min … max):  ${pad(f1(mn.value), 6)} ${tm.label} … ${pad(f1(mx.value), 5)} ${tm.label}    ${runs} runs`);
    console.log(' ');
  }
}

function sorted(results, opts, forMarkup = false) {
  if (opts.sort === 'command' || (opts.sort === 'auto' && forMarkup)) return [...results];
  return [...results].sort((a, b) => a.mean - b.mean);
}

function printSummary(results, opts) {
  if (results.length < 2 || opts.style === 'none') return;
  const s = sorted(results, opts);
  const base = opts.reference ? (s.find(r => r.originalCommand === opts.reference || r.command === opts.reference) || s[0]) : s[0];
  console.log('Summary');
  for (const r of s) {
    if (r === base) continue;
    const rel = r.mean / base.mean;
    const err = rel * Math.sqrt((r.stddev / r.mean) ** 2 + (base.stddev / base.mean) ** 2);
    console.log(`  ${base.command} ran`);
    console.log(`    ${f2(rel)} ± ${f2(err)} times faster than ${r.command}`);
  }
}
function f2(x) { return Number.isFinite(x) ? x.toFixed(2) : 'inf'; }

function jsonResults(results) {
  return JSON.stringify({ results: results.map(r => ({
    command: r.command, mean: r.mean, stddev: r.stddev, median: r.median, user: r.user, system: r.system,
    min: r.min, max: r.max, times: r.times, memory_usage_byte: r.memory_usage_byte, exit_codes: r.exit_codes
  })) }, null, 2) + '\n';
}
function csv(results) {
  const esc = s => /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  return 'command,mean,stddev,median,user,system,min,max\n' + results.map(r => [esc(r.command), r.mean, r.stddev, r.median, r.user, r.system, r.min, r.max].join(',')).join('\n') + '\n';
}
function rels(results) {
  const best = Math.min(...results.map(r => r.mean));
  return new Map(results.map(r => [r, { rel: r.mean / best, err: (r.stddev / r.mean) || 0 }]));
}
function tableRows(results, opts) {
  const rs = rels(results);
  return sorted(results, opts, true).map(r => {
    const tm = fmtTime(r.mean, opts.unit), mn = fmtTime(r.min, opts.unit), mx = fmtTime(r.max, opts.unit), sd = fmtTime(r.stddev, opts.unit);
    const rr = rs.get(r);
    return { cmd: r.command, label: tm.label, mean: `${f1(tm.value)} ± ${f1(sd.value)}`, min: f1(mn.value), max: f1(mx.value), rel: rr.rel === 1 ? '1.00' : `${f2(rr.rel)} ± ${f2(rr.err)}` };
  });
}
function markdown(results, opts) {
  const rows = tableRows(results, opts), u = rows[0]?.label || 's';
  return `| Command | Mean [${u}] | Min [${u}] | Max [${u}] | Relative |\n|:---|---:|---:|---:|---:|\n` + rows.map(r => `| \`${r.cmd}\` | ${r.mean} | ${r.min} | ${r.max} | ${r.rel} |`).join('\n') + '\n';
}
function asciidoc(results, opts) {
  const rows = tableRows(results, opts), u = rows[0]?.label || 's';
  return `[cols="<,>,>,>,>"]\n|===\n| Command \n| Mean [${u}] \n| Min [${u}] \n| Max [${u}] \n| Relative \n\n` + rows.map(r => `| \`${r.cmd}\` \n| ${r.mean} \n| ${r.min} \n| ${r.max} \n| ${r.rel} `).join('\n') + '\n|===\n';
}
function orgmode(results, opts) {
  const rows = tableRows(results, opts), u = rows[0]?.label || 's';
  return `| Command  |  Mean [${u}] |  Min [${u}] |  Max [${u}] |  Relative |\n|--+--+--+--+--|\n` + rows.map(r => `| =${r.cmd}=  |  ${r.mean} |  ${r.min} |  ${r.max} |  ${r.rel} |`).join('\n') + '\n';
}

function writeExports(results, opts) {
  if (opts.exports.json) fs.writeFileSync(opts.exports.json, jsonResults(results));
  if (opts.exports.csv) fs.writeFileSync(opts.exports.csv, csv(results));
  if (opts.exports.markdown) fs.writeFileSync(opts.exports.markdown, markdown(results, opts));
  if (opts.exports.asciidoc) fs.writeFileSync(opts.exports.asciidoc, asciidoc(results, opts));
  if (opts.exports.orgmode) fs.writeFileSync(opts.exports.orgmode, orgmode(results, opts));
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  const cmds = expand(opts);
  const results = cmds.map((c, i) => resultFor(c, i, opts, cmds.length));
  printSummary(results, opts);
  writeExports(results, opts);
}
main();
