#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "ambr 0.6.0";
const VCS_DIRS = new Set([".git", ".hg", ".svn", ".bzr"]);

function help() {
  return `${VERSION}

USAGE:
    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...

FLAGS:
        --key-from-file        Use file contents of KEYWORD as keyword for search
        --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement
        --verbose              Verbose message
    -r, --regex                Enable regular expression search
        --column               Enable column output
        --row                  Enable row output
        --binary               Enable binary file search
        --statistics           Enable statistics output
        --skipped              Enable skipped file output
        --preserve-time        Enable timestamp preserve
        --no-interactive       Disable interactive replace
        --no-recursive         Disable recursive directory search
        --no-symlink           Disable symbolic link follow
        --no-color             Disable colored output
        --no-file              Disable filename output
        --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip
        --no-skip-gitignore    Disable .gitignore skip
        --no-fixed-order       Disable output order guarantee
        --no-parent-ignore     Disable .*ignore file search at parent directories
        --tbm                  [Experimental] Enable TBM matcher
        --sse                  [Experimental] Enable SSE 4.2
    -h, --help                 Prints help information
    -V, --version              Prints version information

OPTIONS:
        --max-threads <NUM>          Number of max threads [default: 4]
        --size-per-thread <BYTES>    File size per one thread [default: 1048576]
        --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]
        --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]

ARGS:
    <KEYWORD>        Keyword for search
    <REPLACEMENT>    Keyword for replace
    <PATHS>...       Search paths`;
}

function parseArgs(argv) {
  const opts = {
    regex: false, column: false, row: false, binary: false, statistics: false,
    skipped: false, preserveTime: false, interactive: true, recursive: true,
    symlink: true, color: true, file: true, skipVcs: true, skipGitignore: true,
    fixedOrder: true, parentIgnore: true, keyFromFile: false, repFromFile: false,
    verbose: false, maxThreads: "4", binCheckBytes: 256
  };
  const positional = [];
  const needValue = new Set(["--max-threads", "--size-per-thread", "--bin-check-bytes", "--mmap-bytes"]);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") return { help: true };
    if (a === "-V" || a === "--version") return { version: true };
    if (a === "-r" || a === "--regex") opts.regex = true;
    else if (a === "--column") opts.column = true;
    else if (a === "--row") opts.row = true;
    else if (a === "--binary") opts.binary = true;
    else if (a === "--statistics") opts.statistics = true;
    else if (a === "--skipped") opts.skipped = true;
    else if (a === "--preserve-time") opts.preserveTime = true;
    else if (a === "--no-interactive") opts.interactive = false;
    else if (a === "--no-recursive") opts.recursive = false;
    else if (a === "--no-symlink") opts.symlink = false;
    else if (a === "--no-color") opts.color = false;
    else if (a === "--no-file") opts.file = false;
    else if (a === "--no-skip-vcs") opts.skipVcs = false;
    else if (a === "--no-skip-gitignore") opts.skipGitignore = false;
    else if (a === "--no-fixed-order") opts.fixedOrder = false;
    else if (a === "--no-parent-ignore") opts.parentIgnore = false;
    else if (a === "--key-from-file") opts.keyFromFile = true;
    else if (a === "--rep-from-file") opts.repFromFile = true;
    else if (a === "--verbose") opts.verbose = true;
    else if (a === "--tbm" || a === "--sse") {}
    else if (needValue.has(a)) {
      if (i + 1 >= argv.length) die(`error: The argument '${a} <${a.includes("threads") ? "NUM" : "BYTES"}>' requires a value but none was supplied`);
      const val = argv[++i];
      if (a === "--max-threads") opts.maxThreads = val;
      if (a === "--bin-check-bytes") opts.binCheckBytes = parseInt(val, 10) || 256;
    } else if (a.startsWith("--")) {
      die(`error: Found argument '${a}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...\n\nFor more information try --help`);
    } else {
      positional.push(a);
    }
  }
  if (positional.length < 2) {
    die("error: The following required arguments were not provided:\n    <KEYWORD>\n    <REPLACEMENT>\n\nUSAGE:\n    executable <KEYWORD> <REPLACEMENT> --bin-check-bytes <BYTES> --max-threads <NUM> --mmap-bytes <BYTES> --size-per-thread <BYTES>\n\nFor more information try --help");
  }
  opts.keyword = positional[0];
  opts.replacement = positional[1];
  opts.paths = positional.slice(2);
  if (opts.paths.length === 0) opts.paths = ["."];
  if (opts.keyFromFile) opts.keyword = fs.readFileSync(opts.keyword, "utf8");
  if (opts.repFromFile) opts.replacement = fs.readFileSync(opts.replacement, "utf8");
  return opts;
}

function die(msg) {
  process.stderr.write(msg + "\n");
  process.exit(1);
}

function loadIgnore(dir) {
  const file = path.join(dir, ".gitignore");
  if (!fs.existsSync(file)) return [];
  try {
    return fs.readFileSync(file, "utf8").split(/\r?\n/).map(s => s.trim()).filter(s => s && !s.startsWith("#"));
  } catch {
    return [];
  }
}

function ignoredBy(patterns, name, rel) {
  for (const pat0 of patterns) {
    let pat = pat0.replace(/^\//, "");
    if (pat.endsWith("/")) pat = pat.slice(0, -1);
    if (!pat) continue;
    if (pat.includes("*")) {
      const re = new RegExp("^" + pat.split("*").map(escapeRegExp).join(".*") + "$");
      if (re.test(name) || re.test(rel)) return true;
    } else if (name === pat || rel === pat || rel.startsWith(pat + path.sep)) {
      return true;
    }
  }
  return false;
}

function collect(paths, opts) {
  const files = [];
  const skipped = [];
  function walk(p, inherited) {
    let st;
    try {
      st = opts.symlink ? fs.statSync(p) : fs.lstatSync(p);
    } catch (e) {
      skipped.push([p, e.message]);
      return;
    }
    const base = path.basename(p);
    if (st.isDirectory()) {
      if (opts.skipVcs && VCS_DIRS.has(base)) {
        skipped.push([p, "vcs"]);
        return;
      }
      const localPatterns = opts.skipGitignore ? inherited.concat(loadIgnore(p)) : inherited;
      let entries = [];
      try { entries = fs.readdirSync(p); } catch (e) { skipped.push([p, e.message]); return; }
      entries.sort();
      for (const ent of entries) {
        if (ent === "." || ent === "..") continue;
        const child = path.join(p, ent);
        if (opts.skipGitignore && ignoredBy(localPatterns, ent, ent)) {
          skipped.push([child, "gitignore"]);
          continue;
        }
        if (opts.recursive) walk(child, localPatterns);
        else {
          try { if (fs.statSync(child).isFile()) files.push(child); } catch {}
        }
      }
    } else if (st.isFile()) {
      files.push(p);
    }
  }
  for (const p of paths) walk(p, []);
  return { files, skipped };
}

function isBinary(file, bytes) {
  try {
    const fd = fs.openSync(file, "r");
    const buf = Buffer.alloc(bytes);
    const n = fs.readSync(fd, buf, 0, bytes, 0);
    fs.closeSync(fd);
    for (let i = 0; i < n; i++) if (buf[i] === 0) return true;
  } catch {
    return false;
  }
  return false;
}

function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function buildRegex(opts) {
  if (opts.regex) return new RegExp(opts.keyword, "gu");
  return new RegExp(escapeRegExp(opts.keyword), "gu");
}

function expandReplacement(rep, match) {
  if (!match) return rep;
  return rep.replace(/\$(\d+)|\$\{([^}]+)\}|\$([A-Za-z_][A-Za-z0-9_]*)/g, (all, num, braced, named) => {
    const key = num || braced || named;
    if (/^\d+$/.test(key)) return match[Number(key)] ?? "";
    return (match.groups && match.groups[key]) ?? "";
  });
}

function prefix(file, lineNo, col, opts) {
  if (!opts.file) return "";
  let out = file + ": ";
  const parts = [];
  if (opts.row) parts.push(String(lineNo));
  if (opts.column) parts.push(String(col));
  if (parts.length) out = file + ": " + parts.join(":") + ":";
  return out;
}

function readAnswer() {
  const chunks = [];
  const buf = Buffer.alloc(1);
  try {
    while (true) {
      const n = fs.readSync(0, buf, 0, 1, null);
      if (n <= 0) break;
      const ch = buf.toString("utf8", 0, n);
      if (ch === "\n" || ch === "\r") break;
      chunks.push(ch);
    }
    return chunks.join("").trim();
  } catch {
    return chunks.join("").trim();
  }
}

function processFile(file, opts, stats) {
  if (!opts.binary && isBinary(file, opts.binCheckBytes)) {
    stats.skipped.push([file, "binary"]);
    return;
  }
  let text;
  let stat;
  try {
    stat = fs.statSync(file);
    text = fs.readFileSync(file, "utf8");
  } catch (e) {
    stats.skipped.push([file, e.message]);
    return;
  }
  const re = buildRegex(opts);
  let changed = "";
  let last = 0;
  let any = false;
  let all = !opts.interactive;
  let quit = false;
  let lineNo = 1;
  let lineStart = 0;

  for (let m; (m = re.exec(text)) !== null;) {
    if (m[0] === "") {
      re.lastIndex++;
      continue;
    }
    any = true;
    while (lineStart <= m.index) {
      const nl = text.indexOf("\n", lineStart);
      if (nl === -1 || nl >= m.index) break;
      lineNo++;
      lineStart = nl + 1;
    }
    const lineEnd0 = text.indexOf("\n", m.index);
    const lineEnd = lineEnd0 === -1 ? text.length : lineEnd0;
    const line = text.slice(lineStart, lineEnd);
    const col = m.index - lineStart;
    const replacement = opts.regex ? expandReplacement(opts.replacement, m) : opts.replacement;
    let doReplace = all;
    if (opts.interactive && !all) {
      const preview = line.slice(0, col) + replacement + line.slice(col + m[0].length);
      const p = prefix(file, lineNo, col, opts);
      process.stdout.write(p + line + "\n");
      const spaces = " ".repeat(Math.max(0, p.length - 4));
      process.stdout.write(spaces + "-> " + preview + "\n");
      process.stdout.write("Replace keyword? [Y]es/[n]o/[a]ll/[q]uit: ");
      const ans = readAnswer().toLowerCase();
      if (ans === "a" || ans === "all") { all = true; doReplace = true; process.stdout.write((ans ? ans : "") + "\n"); }
      else if (ans === "q" || ans === "quit") { quit = true; process.stdout.write((ans ? ans : "") + "\n"); }
      else if (ans === "n" || ans === "no") { doReplace = false; process.stdout.write((ans ? ans : "") + "\n"); }
      else { doReplace = true; process.stdout.write((ans ? ans : "") + "\n"); }
    }
    if (quit) break;
    if (doReplace) {
      changed += text.slice(last, m.index) + replacement;
      last = m.index + m[0].length;
      stats.replacements++;
    }
  }
  if (stats.replacements && any) {
    changed += text.slice(last);
    if (changed !== text) {
      fs.writeFileSync(file, changed);
      if (opts.preserveTime && stat) fs.utimesSync(file, stat.atime, stat.mtime);
      stats.filesChanged++;
    }
  }
}

function printStats(opts, stats) {
  if (!opts.statistics) return;
  process.stdout.write(`
Statistics
  Max threads: ${opts.maxThreads}

  Consumed time ( busy / total )
    Find     : 0s / 0.001s
    Match00  : 0s / 0.001s
    Sort     : 0s / 0.001s
    Replace  : 0s / 0.001s

`);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) { console.log(help()); return; }
  if (opts.version) { console.log(VERSION); return; }
  const stats = { replacements: 0, filesChanged: 0, skipped: [] };
  const found = collect(opts.paths, opts);
  stats.skipped.push(...found.skipped);
  for (const file of found.files) processFile(file, opts, stats);
  if (opts.skipped) {
    for (const [f, why] of stats.skipped) process.stdout.write(`${f}: skipped (${why})\n`);
  }
  printStats(opts, stats);
}

main();
