#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = `Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team
Universal Ctags is derived from Exuberant Ctags.
Exuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert
  Compiled: Apr 20 2026, 16:52:56
  URL: https://ctags.io/
  Output version: 1.1
  Optional compiled features: +wildcards, +regex, +iconv, +option-directory, +xpath, +json, +interactive, +sandbox, +yaml, +packcc, +optscript`;

const HELP = `${VERSION}

Usage: executable [options] [file(s)]

Input/Output Options
  --exclude=<pattern>
       Exclude files and directories matching <pattern>.
  --filter[=(yes|no)]
       Behave as a filter, reading file names from standard input and
       writing tags to standard output [no].
  --recurse[=(yes|no)]
       Recurse into directories supplied on command line [no].
  -R   Equivalent to --recurse.
  -L <file>
       A list of input file names is read from the specified <file>.
  --append[=(yes|no)]
       Should tags should be appended to existing tag file [no]?
  -a   Append the tags to an existing tag file.
  -f <tagfile>
       Write tags to specified <tagfile>. Value of "-" writes tags to stdout
       ["tags"; or "TAGS" when -e supplied].
  -o   Alternative for -f.

Output Format Options
  --format=(1|2)
       Force output of specified tag file format [2].
  --output-format=(u-ctags|e-ctags|etags|xref|json)
      Specify the output format. [u-ctags]
  -e   Output tag file for use with Emacs.
  -x   Print a tabular cross reference file to standard output.
  --sort=(yes|no|foldcase)
       Should tags be sorted (optionally ignoring case) [yes]?
  -u   Equivalent to --sort=no.

Language Selection and Mapping Options
  --language-force=(<language>|auto)
       Force all files to be interpreted using specified <language>.
  --languages=[+|-](<list>|all)
       Restrict files scanned for tags to those mapped to languages.

Tags File Contents Options
  --excmd=(number|pattern|mix|combine)
       Uses the specified type of EX command to locate tags [mix].
  -n   Equivalent to --excmd=number.
  -N   Equivalent to --excmd=pattern.
  --fields=[+|-][<flags>|*]
       Include selected extension fields (<flags>: "aCeEfFikKlmnNpPrRsStxzZ") [fks].

Listing Options
  --list-features
       Output list of compiled features.
  --list-kinds[=(<language>|all)]
       Output a list of all tag kinds for specified <language> or all.
  --list-languages
       Output list of supported languages.
  --list-output-formats
       Output list of output formats.

Miscellaneous Options
  --help
       Print this option summary.
  -?   Print this option summary.
  --license
       Print details of software license.
  --print-language
       Don't make tags file but just print the guessed language name for input file.
  --totals[=(yes|no|extra)]
       Print statistics about input and tag files [no].
  --version[=<language>]
       Print version identifier of the program to standard output.
  -V   Equivalent to --verbose.`;

const LANGS = ["Abaqus","Abc","Ada","AnsiblePlaybook","Ant","Asciidoc","Asm","Asp","Autoconf","AutoIt","Automake","Awk","Basic","Bats","BETA","BibLaTeX","BibTeX","C","C#","C++","Cargo [disabled]","Clojure","CMake","Cobol","CSS","Ctags","CUDA","D","Diff","DosBatch","DTD","Elixir","Elm","EmacsLisp","Erlang","Fortran","Go","Haskell","HTML","Java","JavaProperties","JavaScript","JSON","Julia","Kotlin","Lua","M4","Make","Markdown","MatLab","Meson","ObjectiveC","OCaml","Pascal","Perl","PHP","Python","R","Rake","RMarkdown","Ruby","Rust","Scala","Scheme","Sh","SQL","SystemVerilog","Tcl","Tex","TypeScript","Vera","Verilog","Vim","XML","Yaml"];
const KIND_LISTS = {
  Python: ["c  classes","f  functions","m  class members","v  variables","I  name referring a module defined in other file","i  modules","Y  name referring a class/variable/function/module defined in other module","z  function parameters [off]","l  local variables [off]"],
  JavaScript: ["f  functions","c  classes","m  methods","p  properties","C  constants","v  global variables","g  generators","G  getters","S  setters","M  fields"],
  TypeScript: ["f  functions","c  classes","m  methods","p  properties","C  constants","v  global variables","i  interfaces","e  enumerators","E  enumerations"],
  C: ["d  macro definitions","e  enumerators (values inside an enumeration)","f  function definitions","g  enumeration names","h  included header files","l  local variables [off]","m  struct, and union members","p  function prototypes [off]","s  structure names","t  typedefs","u  union names","v  variable definitions","x  external and forward variable declarations [off]"],
  "C++": ["c  classes","d  macro definitions","e  enumerators (values inside an enumeration)","f  function definitions","g  enumeration names","m  class, struct, and union members","n  namespaces","p  function prototypes [off]","s  structure names","t  typedefs","u  union names","v  variable definitions"],
  Java: ["c  classes","e  enum constants","f  fields","i  interfaces","m  methods","p  packages"],
  Go: ["p  packages","f  functions","m  methods","s  structs","i  interfaces","t  types","v  variables","c  constants"],
  Ruby: ["c  classes","f  methods","m  modules","F  singleton methods","C  constants"],
  PHP: ["c  classes","f  functions","i  interfaces","m  methods","v  variables","d  constant definitions"],
  Rust: ["n  modules","s  structures","u  unions","g  enumerations","f  functions","m  macros","t  type aliases","i  traits","c  implementations","v  static variables"]
};
const KIND_NAMES = {c:"class", f:"function", m:"member", v:"variable", C:"constant", p:"property", G:"getter", S:"setter", M:"field", d:"macro", e:"enumerator", g:"enum", s:"struct", t:"typedef", u:"union", n:"namespace", i:"interface", E:"enum", I:"namespace"};

function parseArgs(argv) {
  const opt = { files: [], tagfile: "tags", output: "u-ctags", sort: "yes", recurse: false, append: false, printLanguage: false, filter: false, totals: false, forceLang: null, excmd: "pattern", listKind: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help" || a === "-?") return { action: "help" };
    if (a.startsWith("--version")) return { action: "version" };
    if (a === "--license") return { action: "license" };
    if (a === "--list-languages") return { action: "langs" };
    if (a === "--list-features") return { action: "features" };
    if (a === "--list-output-formats") return { action: "formats" };
    if (a.startsWith("--list-kinds")) { opt.listKind = valueOf(a, argv, () => "all"); return { action: "kinds", opt }; }
    if (a === "-f" || a === "-o") opt.tagfile = argv[++i] || "";
    else if (a.startsWith("-f") && a.length > 2) opt.tagfile = a.slice(2);
    else if (a.startsWith("--output-format=")) opt.output = a.split("=")[1];
    else if (a === "-x") { opt.output = "xref"; opt.tagfile = "-"; }
    else if (a === "-e") { opt.output = "etags"; opt.tagfile = opt.tagfile === "tags" ? "TAGS" : opt.tagfile; }
    else if (a === "-R" || a.startsWith("--recurse")) opt.recurse = !a.endsWith("=no");
    else if (a === "-a" || a.startsWith("--append")) opt.append = !a.endsWith("=no");
    else if (a === "-u" || a === "--sort=no") opt.sort = "no";
    else if (a === "--sort=foldcase") opt.sort = "foldcase";
    else if (a === "-n" || a === "--excmd=number") opt.excmd = "number";
    else if (a === "-N" || a === "--excmd=pattern") opt.excmd = "pattern";
    else if (a === "--print-language") opt.printLanguage = true;
    else if (a.startsWith("--filter")) opt.filter = !a.endsWith("=no");
    else if (a.startsWith("--totals")) opt.totals = !a.endsWith("=no");
    else if (a.startsWith("--language-force=")) opt.forceLang = normLang(a.split("=")[1]);
    else if (a === "-L") opt.files.push(...readList(argv[++i]));
    else if (a.startsWith("-L") && a.length > 2) opt.files.push(...readList(a.slice(2)));
    else if (a.startsWith("--")) continue;
    else if (a.startsWith("-") && a.length > 1) continue;
    else opt.files.push(a);
  }
  return { action: "run", opt };
}

function valueOf(arg, argv, def) {
  const eq = arg.indexOf("=");
  return eq >= 0 ? arg.slice(eq + 1) : def();
}
function readStdin() { try { return fs.readFileSync(0, "utf8"); } catch { return ""; } }
function readList(file) { return (file === "-" ? readStdin() : safeRead(file)).split(/\r?\n/).map(s => s.trim()).filter(Boolean); }
function safeRead(file) { try { return fs.readFileSync(file, "utf8"); } catch { return ""; } }

function main() {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed.action === "help") return console.log(HELP);
  if (parsed.action === "version") return console.log(VERSION);
  if (parsed.action === "license") return console.log("Universal Ctags is licensed under the GNU General Public License version 2 or later.");
  if (parsed.action === "langs") return console.log(LANGS.join("\n"));
  if (parsed.action === "features") return console.log("#NAME             DESCRIPTION\niconv             can convert input/output encodings\ninteractive       accepts source code from stdin\njson              supports json format output\noption-directory  TO BE WRITTEN\noptscript         can use the interpreter\npackcc            has peg based parser(s)\nregex             can use regular expression based pattern matching\nsandbox           linked with code for system call level sandbox\nwildcards         can use glob matching\nxpath             linked with library for parsing xml input\nyaml              linked with library for parsing yaml input");
  if (parsed.action === "formats") return console.log("#OFORMAT DEFAULT AVAILABLE NULLTAG \ne-ctags       no       yes      no \netags         no       yes      no \njson          no       yes     yes \nu-ctags      yes       yes      no \nxref          no       yes     yes ");
  if (parsed.action === "kinds") return console.log(kinds(parsed.opt.listKind));
  run(parsed.opt);
}

function run(opt) {
  if (opt.filter) opt.files.push(...readStdin().split(/\r?\n/).filter(Boolean));
  let files = expandFiles(opt.files.length ? opt.files : ["."], opt.recurse);
  if (opt.printLanguage) {
    process.stdout.write(files.map(f => `${f}: ${languageFor(f, opt.forceLang) || "NONE"}`).join("\n") + (files.length ? "\n" : ""));
    return;
  }
  const start = Date.now();
  let tags = [];
  let lines = 0;
  for (const file of files) {
    const text = safeRead(file);
    if (text === "") continue;
    lines += text.split(/\n/).length - (text.endsWith("\n") ? 1 : 0);
    tags.push(...parseFile(file, text, languageFor(file, opt.forceLang)));
  }
  if (opt.sort !== "no") tags.sort((a, b) => cmpName(opt.sort === "foldcase" ? a.name.toLowerCase() : a.name, opt.sort === "foldcase" ? b.name.toLowerCase() : b.name) || cmpName(a.path, b.path) || cmpName(a.pattern, b.pattern) || a.line - b.line);
  let out = "";
  if (opt.output === "json") out = tags.map(jsonLine).join("\n") + (tags.length ? "\n" : "");
  else if (opt.output === "xref") out = tags.map(xrefLine).join("\n") + (tags.length ? "\n" : "");
  else if (opt.output === "etags" || opt.output === "e-ctags") out = etags(files, tags);
  else out = (opt.tagfile !== "-" ? header(files, tags) : "") + tags.map(t => tagLine(t, opt)).join("\n") + (tags.length || opt.tagfile !== "-" ? "\n" : "");
  if (opt.tagfile === "-") process.stdout.write(out);
  else fs.writeFileSync(opt.tagfile, (opt.append && fs.existsSync(opt.tagfile) ? fs.readFileSync(opt.tagfile, "utf8") : "") + out);
  if (opt.totals) process.stderr.write(`${files.length} file, ${lines} lines (0 kB) scanned in ${((Date.now() - start)/1000).toFixed(1)} seconds\n${tags.length} tags added to tag file\n${tags.length} tags sorted in 0.00 seconds\n`);
}

function expandFiles(inputs, recurse) {
  const out = [];
  for (const f of inputs) {
    try {
      const st = fs.statSync(f);
      if (st.isDirectory()) {
        if (recurse) for (const ent of fs.readdirSync(f)) out.push(...expandFiles([path.join(f, ent)], true));
      } else if (st.isFile()) out.push(f);
    } catch {}
  }
  return out;
}

function normLang(l) {
  if (!l || l === "auto") return null;
  const low = l.toLowerCase();
  if (low === "c++" || low === "cpp") return "C++";
  if (low === "javascript" || low === "js") return "JavaScript";
  if (low === "typescript" || low === "ts") return "TypeScript";
  return l[0].toUpperCase() + l.slice(1).toLowerCase();
}
function languageFor(file, forced) {
  if (forced) return forced;
  const base = path.basename(file), ext = path.extname(base).toLowerCase();
  if ([".c", ".h"].includes(ext)) return "C";
  if ([".cc", ".cpp", ".cxx", ".hpp", ".hh", ".hxx"].includes(ext)) return "C++";
  if (ext === ".py" || base === "SConstruct") return "Python";
  if (ext === ".js" || ext === ".mjs" || ext === ".cjs") return "JavaScript";
  if (ext === ".ts" || ext === ".tsx") return "TypeScript";
  if (ext === ".java") return "Java";
  if (ext === ".go") return "Go";
  if (ext === ".rb" || base === "Rakefile") return "Ruby";
  if (ext === ".php") return "PHP";
  if (ext === ".rs") return "Rust";
  if ([".sh", ".bash", ".zsh"].includes(ext)) return "Sh";
  return null;
}

function parseFile(file, text, lang) {
  const lines = text.replace(/\r\n/g, "\n").split("\n");
  if (lang === "Python") return parsePython(file, lines);
  if (lang === "JavaScript" || lang === "TypeScript") return parseJS(file, lines, lang);
  if (lang === "C" || lang === "C++") return parseC(file, lines, lang);
  if (lang === "Java") return parseJava(file, lines);
  if (lang === "Go") return parseGo(file, lines);
  if (lang === "Ruby") return parseRuby(file, lines);
  if (lang === "PHP") return parsePHP(file, lines);
  if (lang === "Rust") return parseRust(file, lines);
  if (lang === "Sh") return parseSh(file, lines);
  return [];
}
function tag(file, lines, i, name, kind, fields = {}) { return { name, path: file, line: i + 1, pattern: fields.patternOverride || lines[i] || "", kind, fields, lang: fields.lang }; }
function cmpName(a, b) { return Buffer.compare(Buffer.from(a), Buffer.from(b)); }

function parsePython(file, lines) {
  const tags = [], stack = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i], trim = line.trim(); if (!trim || trim.startsWith("#")) continue;
    const ind = line.match(/^\s*/)[0].length;
    while (stack.length && ind <= stack[stack.length - 1].indent) stack.pop();
    let m;
    if ((m = trim.match(/^class\s+([A-Za-z_]\w*)/))) { tags.push(tag(file, lines, i, m[1], "c")); stack.push({ name: m[1], indent: ind, kind: "class" }); }
    else if ((m = trim.match(/^(?:async\s+)?def\s+([A-Za-z_]\w*)\s*\(/))) {
      const cls = stack.slice().reverse().find(s => s.kind === "class");
      tags.push(tag(file, lines, i, m[1], cls ? "m" : "f", cls ? { scopeKind: "class", scope: cls.name } : {}));
    } else if (ind === 0 && (m = trim.match(/^([A-Za-z_]\w*)\s*[:=]/)) && !/^(if|for|while|with|return)\b/.test(trim)) tags.push(tag(file, lines, i, m[1], "v"));
  }
  return tags;
}

function parseJS(file, lines, lang) {
  const tags = [], stack = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i], trim = line.trim(); if (!trim || trim.startsWith("//")) continue;
    while (stack.length && braceDepth(lines, stack[stack.length - 1].start, i) <= 0 && i > stack[stack.length - 1].start) stack.pop();
    let m, cls = stack[stack.length - 1];
    if ((m = trim.match(/^(?:export\s+default\s+|export\s+)?class\s+([A-Za-z_$][\w$]*)/))) { tags.push(tag(file, lines, i, m[1], "c")); stack.push({ name: m[1], start: i }); continue; }
    if ((m = trim.match(/^(?:export\s+)?(?:async\s+)?function\*?\s+([A-Za-z_$][\w$]*)\s*\(/))) tags.push(tag(file, lines, i, m[1], "f"));
    else if ((m = trim.match(/^(?:export\s+)?(const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>/))) tags.push(tag(file, lines, i, m[2], "f"));
    else if ((m = trim.match(/^(?:export\s+)?(const|let|var)\s+([A-Za-z_$][\w$]*)\b/))) tags.push(tag(file, lines, i, m[2], m[1] === "const" ? "C" : "v"));
    else if ((m = trim.match(/^module\.exports\s*=/))) tags.push(tag(file, lines, i, "module.exports", "p"));
    if (cls && (m = trim.match(/^(?:async\s+)?(?:get\s+|set\s+)?([A-Za-z_$][\w$]*|constructor)\s*\(/))) {
      const kind = trim.startsWith("get ") ? "G" : trim.startsWith("set ") ? "S" : "m";
      tags.push(tag(file, lines, i, m[1], kind, { scopeKind: "class", scope: cls.name }));
    }
    if ((m = trim.match(/^module\.exports\s*=\s*\{\s*([^}]+)\}/))) for (const n of m[1].split(",").map(s => s.trim().split(/\s+as\s+|:/).pop().trim()).filter(Boolean)) tags.push(tag(file, lines, i, n, "p", { scopeKind: "property", scope: "module.exports" }));
  }
  return tags;
}
function braceDepth(lines, start, end) { let d = 0; for (let i = start; i <= end; i++) for (const ch of lines[i]) { if (ch === "{") d++; else if (ch === "}") d--; } return d; }

function parseC(file, lines, lang) {
  const tags = [];
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i], trim = l.trim(); if (!trim || trim.startsWith("//")) continue;
    let m;
    if ((m = trim.match(/^(#\s*define\s+([A-Za-z_]\w*))(\s|$)/))) tags.push(tag(file, lines, i, m[2], "d", { fileScope: true, patternOverride: m[1].replace(/^#\s*/, "#") + (m[3] ? " " : ""), noPatternEnd: !!m[3] }));
    if ((m = trim.match(/\b(struct|union)\s+([A-Za-z_]\w*)\b/))) {
      const scopeKind = m[1], scope = m[2];
      tags.push(tag(file, lines, i, scope, scopeKind === "struct" ? "s" : "u", { fileScope: true }));
      const body = trim.match(/\{([^}]*)\}/);
      if (body) {
        const re = /\b([A-Za-z_][\w:<>\s\*&]*)\s+([A-Za-z_]\w*)\s*(?:;|,)/g;
        let mm; while ((mm = re.exec(body[1]))) tags.push(tag(file, lines, i, mm[2], "m", { scopeKind, scope, typeref: cleanType(mm[1]), fileScope: true }));
      }
    }
    if ((m = trim.match(/\benum\s+([A-Za-z_]\w*)\b/))) {
      tags.push(tag(file, lines, i, m[1], "g", { fileScope: true }));
      const body = trim.match(/\{([^}]*)\}/); if (body) for (const e of body[1].split(",").map(x => x.trim().split("=")[0].trim()).filter(Boolean)) tags.push(tag(file, lines, i, e, "e", { scopeKind: "enum", scope: m[1], fileScope: true }));
    }
    if ((m = trim.match(/^typedef\s+(struct|union|enum)?\s*([A-Za-z_]\w*)?.*\b([A-Za-z_]\w*)\s*;$/))) tags.push(tag(file, lines, i, m[3], "t", { fileScope: true, typeref: m[1] && m[2] ? `${m[1]}:${m[2]}` : undefined }));
    if ((m = trim.match(/^(?:static\s+|extern\s+|inline\s+|virtual\s+|constexpr\s+)*([A-Za-z_][\w:<>\s\*&]+?)\s+([A-Za-z_]\w*)\s*\([^;]*\)\s*(?:\{|$)/)) && !/^(if|for|while|switch)\b/.test(trim)) tags.push(tag(file, lines, i, m[2], "f", { typeref: cleanType(m[1]), fileScope: /\bstatic\b/.test(trim) }));
    else if ((m = trim.match(/^(?:static\s+|extern\s+)?([A-Za-z_][\w:<>\s\*&]+?)\s+([A-Za-z_]\w*)\s*(?:=\s*[^;]+)?;$/))) tags.push(tag(file, lines, i, m[2], "v", { typeref: cleanType(m[1]), fileScope: /\bstatic\b/.test(trim) }));
  }
  return tags;
}
function cleanType(s) { return "typename:" + s.replace(/\s+/g, " ").trim().replace(/\s*\*+$/, ""); }

function parseJava(file, lines) {
  const tags = [], stack = [];
  for (let i = 0; i < lines.length; i++) {
    const trim = lines[i].trim(); let m;
    while (stack.length && braceDepth(lines, stack[stack.length - 1].start, i) <= 0 && i > stack[stack.length - 1].start) stack.pop();
    if ((m = trim.match(/^package\s+([\w.]+)\s*;/))) tags.push(tag(file, lines, i, m[1], "p"));
    if ((m = trim.match(/\b(class|interface|enum)\s+([A-Za-z_]\w*)/))) {
      const k = m[1] === "interface" ? "i" : "c"; tags.push(tag(file, lines, i, m[2], k));
      const container = { name: m[2], start: i, kind: m[1] }; stack.push(container);
      const body = trim.match(/\{(.*)\}/);
      if (body && (m = body[1].match(/\b([A-Za-z_]\w*)\s*\([^;{]*\)\s*;/))) tags.push(tag(file, lines, i, m[1], "m", { scopeKind: container.kind, scope: container.name }));
    }
    else if (stack.length && (m = trim.match(/(?:public|private|protected)?\s*([A-Za-z_]\w*)\s*\([^;]*\)\s*(?:\{|;)/)) && m[1] === stack[stack.length - 1].name) tags.push(tag(file, lines, i, m[1], "m", { scopeKind: "class", scope: stack[stack.length - 1].name }));
    else if ((m = trim.match(/(?:public|private|protected|static|final|native|synchronized|\s)+[\w<>\[\]]+\s+([A-Za-z_]\w*)\s*\([^;]*\)\s*(?:\{|;)/))) tags.push(tag(file, lines, i, m[1], "m", stack.length ? { scopeKind: stack[stack.length - 1].kind, scope: stack[stack.length - 1].name } : {}));
    else if ((m = trim.match(/((?:public|private|protected|static|final|\s)+)[\w<>\[\]]+\s+([A-Za-z_]\w*)\s*(?:=.*)?;/))) tags.push(tag(file, lines, i, m[2], "f", stack.length ? { scopeKind: "class", scope: stack[stack.length - 1].name, fileScope: /\bprivate\b/.test(m[1]) } : {}));
  }
  return tags;
}
function parseGo(file, lines) { const tags=[]; let pkg=""; for(let i=0;i<lines.length;i++){const t=lines[i].trim();let m;if((m=t.match(/^package\s+(\w+)/))){pkg=m[1];tags.push(tag(file,lines,i,m[1],"p"));}else if((m=t.match(/^func\s+\(([^)]*)\)\s*([A-Za-z_]\w*)\s*\([^)]*\)\s*([A-Za-z_]\w*)?/))){const typ=(m[1].trim().split(/\s+/).pop()||"").replace(/^\*/,"");tags.push(tag(file,lines,i,m[2],"f",typ?{scopeKind:"struct",scope:`${pkg}.${typ}`,typeref:m[3]?`typename:${m[3]}`:undefined}:{}));}else if((m=t.match(/^func\s+([A-Za-z_]\w*)\s*\(/)))tags.push(tag(file,lines,i,m[1],"f",pkg?{scopeKind:"package",scope:pkg}:{}));else if((m=t.match(/^type\s+([A-Za-z_]\w*)\s+(struct|interface)?/))){tags.push(tag(file,lines,i,m[1],m[2]==="struct"?"s":m[2]==="interface"?"i":"t",pkg?{scopeKind:"package",scope:pkg}:{}));const body=t.match(/\{(.*)\}/);if(body&&m[2]==="struct"){let mm;const re=/\b([A-Za-z_]\w*)\s+([A-Za-z_]\w*)/g;while((mm=re.exec(body[1])))tags.push(tag(file,lines,i,mm[1],"m",{scopeKind:"struct",scope:`${pkg}.${m[1]}`,typeref:`typename:${mm[2]}`}));}if(body&&m[2]==="interface"){let mm;const re=/\b([A-Za-z_]\w*)\s*\([^)]*\)\s*([A-Za-z_]\w*)?/g;while((mm=re.exec(body[1])))tags.push(tag(file,lines,i,mm[1],"n",{scopeKind:"interface",scope:`${pkg}.${m[1]}`,typeref:`typename:${mm[2]||""}`}));}}else if((m=t.match(/^(var|const)\s+([A-Za-z_]\w*)\s*([A-Za-z_]\w*)?/)))tags.push(tag(file,lines,i,m[2],m[1]==="const"?"c":"v",pkg?{scopeKind:"package",scope:pkg,typeref:m[3]?`typename:${m[3]}`:undefined}:{}));} return tags; }
function parseRuby(file, lines) { const tags=[]; const stack=[]; const full=()=>stack.map(s=>s.name).join("."); for(let i=0;i<lines.length;i++){const t=lines[i].trim();let m;if(/^end\b/.test(t)){stack.pop();continue;} if((m=t.match(/^class\s+([A-Z]\w*(?:::\w+)*)/))){const sc=stack.length?{scopeKind:"module",scope:full()}:{};tags.push(tag(file,lines,i,m[1],"c",sc));stack.push({kind:"class",name:m[1].split("::").pop()});}else if((m=t.match(/^module\s+([A-Z]\w*(?:::\w+)*)/))){tags.push(tag(file,lines,i,m[1],"m"));stack.push({kind:"module",name:m[1].split("::").pop()});}else if((m=t.match(/^def\s+self\.([A-Za-z_]\w*[!?=]?)/)))tags.push(tag(file,lines,i,m[1],"S",stack.length?{scopeKind:stack[stack.length-1].kind,scope:full()}:{}));else if((m=t.match(/^def\s+([A-Za-z_]\w*[!?=]?)/)))tags.push(tag(file,lines,i,m[1],"f",stack.length?{scopeKind:stack[stack.length-1].kind,scope:full()}:{}));else if((m=t.match(/^([A-Z]\w*)\s*=/)))tags.push(tag(file,lines,i,m[1],"C",stack.length?{scopeKind:stack[stack.length-1].kind,scope:full()}:{}));} return tags; }
function parsePHP(file, lines) { const tags=[]; for(let i=0;i<lines.length;i++){const t=lines[i].trim();let m;if((m=t.match(/^(?:abstract\s+|final\s+)?class\s+(\w+)/)))tags.push(tag(file,lines,i,m[1],"c"));else if((m=t.match(/^interface\s+(\w+)/)))tags.push(tag(file,lines,i,m[1],"i"));else if((m=t.match(/^function\s+(\w+)\s*\(/)))tags.push(tag(file,lines,i,m[1],"f"));else if((m=t.match(/^\$([A-Za-z_]\w*)\s*=/)))tags.push(tag(file,lines,i,m[1],"v"));} return tags; }
function parseRust(file, lines) { const tags=[]; for(let i=0;i<lines.length;i++){const t=lines[i].trim();let m;if((m=t.match(/^(?:pub\s+)?(mod|struct|enum|trait|fn|type|static)\s+([A-Za-z_]\w*)/))){const k={mod:"n",struct:"s",enum:"g",trait:"i",fn:"f",type:"t",static:"v"}[m[1]];tags.push(tag(file,lines,i,m[2],k));}else if((m=t.match(/^macro_rules!\s+([A-Za-z_]\w*)/)))tags.push(tag(file,lines,i,m[1],"m"));} return tags; }
function parseSh(file, lines) { const tags=[]; for(let i=0;i<lines.length;i++){const t=lines[i].trim();let m;if((m=t.match(/^([A-Za-z_]\w*)\s*\(\)\s*\{/))||(m=t.match(/^function\s+([A-Za-z_]\w*)/)))tags.push(tag(file,lines,i,m[1],"f"));} return tags; }

function tagLine(t, opt) {
  const ex = opt.excmd === "number" ? t.line : `/^${escapePattern(t.pattern)}${t.fields.noPatternEnd ? "" : "$"}/`;
  const fields = [];
  if (t.fields.scopeKind && t.fields.scope) fields.push(`${t.fields.scopeKind}:${t.fields.scope}`);
  if (t.fields.typeref) fields.push(`typeref:${t.fields.typeref}`);
  if (t.fields.fileScope) fields.push("file:");
  return `${t.name}\t${t.path}\t${ex};"\t${t.kind}${fields.length ? "\t" + fields.join("\t") : ""}`;
}
function escapePattern(s) { return s.replace(/\\/g, "\\\\").replace(/\//g, "\\/").replace(/\$/g, "\\$"); }
function jsonLine(t) {
  const o = {_type:"tag", name:t.name, path:t.path, pattern:`/^${escapePattern(t.pattern)}$/`, kind:KIND_NAMES[t.kind] || t.kind};
  if (t.fields.scope) { o.scope = t.fields.scope; o.scopeKind = t.fields.scopeKind; }
  return JSON.stringify(o).replace(/:/g, ": ");
}
function xrefLine(t) { return `${t.name.padEnd(16)} ${(KIND_NAMES[t.kind] || t.kind).padEnd(13)} ${String(t.line).padStart(4)} ${t.path.padEnd(16)} ${t.pattern.trim()}`; }
function header(files, tags) {
  const langs = [...new Set(files.map(f => languageFor(f)).filter(Boolean))];
  const lines = [
    "!_TAG_FILE_FORMAT\t2\t/extended format; --format=1 will not append ;\" to lines/",
    "!_TAG_FILE_SORTED\t1\t/0=unsorted, 1=sorted, 2=foldcase/",
    "!_TAG_OUTPUT_MODE\tu-ctags\t/u-ctags or e-ctags/",
    "!_TAG_OUTPUT_VERSION\t1.1\t/current.age/",
    "!_TAG_PROGRAM_AUTHOR\tUniversal Ctags Team\t//",
    "!_TAG_PROGRAM_NAME\tUniversal Ctags\t/Derived from Exuberant Ctags/",
    "!_TAG_PROGRAM_URL\thttps://ctags.io/\t/official site/",
    "!_TAG_PROGRAM_VERSION\t6.2.0\t/d922013/"
  ];
  for (const l of langs) lines.push(`!_TAG_PARSER_VERSION!${l}\t1.1\t/current.age/`);
  return lines.join("\n") + "\n";
}
function etags(files, tags) {
  let out = "";
  for (const f of files) {
    const ts = tags.filter(t => t.path === f);
    const body = ts.map(t => `${t.pattern.trim()}\x7f${t.name}\x01${t.line},0`).join("\n") + (ts.length ? "\n" : "");
    out += `\f\n${f},${Buffer.byteLength(body)}\n${body}`;
  }
  return out;
}
function kinds(lang) {
  if (!lang || lang === "all") return Object.entries(KIND_LISTS).map(([l, ks]) => ks.map(k => `${l} ${k}`).join("\n")).join("\n");
  return (KIND_LISTS[normLang(lang)] || ["f  functions"]).join("\n");
}

main();
