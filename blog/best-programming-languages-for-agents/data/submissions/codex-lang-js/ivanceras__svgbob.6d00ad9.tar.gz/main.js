#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const HELP = `svgbob 0.7.6
SvgBobRus is an ascii to svg converter

USAGE:
    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -s               parse an inline string
    -V, --version    Prints version information

OPTIONS:
        --background <background>        backdrop background will be filled with this color (default: 'white')
        --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')
        --font-family <font-family>      text will be rendered with this font (default: 'arial')
        --font-size <font-size>          text will be rendered with this font size (default: 14)
    -o, --output <output>                where to write svg output [default: STDOUT]
        --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor
                                         (default: 1)
        --stroke-color <stroke-color>    stroke color for all lines (default: 'black')
        --stroke-width <stroke-width>    stroke width for all lines (default: 2)

ARGS:
    <input>    svgbob text file or inline string to parse [default: STDIN]

SUBCOMMANDS:
    build    Batch convert files to svg.
    help     Prints this message or the help of the given subcommand(s)`;

const BUILD_HELP = `executable-build 0.0.1
Batch convert files to svg.

USAGE:
    executable build [OPTIONS]

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -i, --input <input>      set input file pattern like: *.bob or dir/*.bob
    -o, --outdir <outdir>    set dir of svg files`;

function die(msg, code = 1) { console.error(msg); process.exit(code); }
function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function n(v) { return Number.isInteger(v) ? String(v) : String(Number(v.toFixed(3))); }
function scaled(v, scale) { return n(v * scale); }

function parseArgs(argv) {
  const opts = {
    background: 'white', fillColor: 'black', strokeColor: 'black',
    fontFamily: 'Iosevka Fixed, monospace', fontSize: '14', strokeWidth: '2',
    scale: 1, output: null, inline: false, input: null, rest: []
  };
  if (argv[0] === 'help') { console.log(argv[1] === 'build' ? BUILD_HELP : HELP); process.exit(0); }
  if (argv[0] === 'build') return { build: true, buildArgs: argv.slice(1), opts };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--') { opts.rest.push(...argv.slice(i + 1)); break; }
    if (a === '-h' || a === '--help') { console.log(HELP); process.exit(0); }
    if (a === '-V' || a === '--version') { console.log('svgbob 0.7.6'); process.exit(0); }
    if (a === '-s') { opts.inline = true; continue; }
    if (a === '-o' || a === '--output') { opts.output = argv[++i]; continue; }
    if (a === '--background') { opts.background = argv[++i]; continue; }
    if (a === '--fill-color') { opts.fillColor = argv[++i]; continue; }
    if (a === '--stroke-color') { opts.strokeColor = argv[++i]; continue; }
    if (a === '--font-family') { opts.fontFamily = argv[++i]; continue; }
    if (a === '--font-size') { opts.fontSize = argv[++i]; continue; }
    if (a === '--stroke-width') { opts.strokeWidth = argv[++i]; continue; }
    if (a === '--scale') { opts.scale = parseFloat(argv[++i] || '1') || 1; continue; }
    if (!opts.input) opts.input = a; else opts.rest.push(a);
  }
  if (!opts.input && opts.rest.length) opts.input = opts.rest.join(' ');
  return { opts };
}

function style(opts) {
  return `<style>.svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {
  stroke: ${opts.strokeColor};
  stroke-width: ${opts.strokeWidth};
  stroke-opacity: 1;
  fill-opacity: 1;
  stroke-linecap: round;
  stroke-linejoin: miter;
}

.svgbob text {
  white-space: pre;
  fill: ${opts.strokeColor};
  font-family: ${opts.fontFamily};
  font-size: ${opts.fontSize}px;
}

.svgbob rect.backdrop {
  stroke: none;
  fill: ${opts.background};
}

.svgbob .broken {
  stroke-dasharray: 8;
}

.svgbob .filled {
  fill: ${opts.fillColor};
}

.svgbob .bg_filled {
  fill: ${opts.background};
  stroke-width: 1;
}

.svgbob .nofill {
  fill: ${opts.background};
}

.svgbob .end_marked_arrow {
  marker-end: url(#arrow);
}

.svgbob .start_marked_arrow {
  marker-start: url(#arrow);
}

.svgbob .end_marked_diamond {
  marker-end: url(#diamond);
}

.svgbob .start_marked_diamond {
  marker-start: url(#diamond);
}

.svgbob .end_marked_circle {
  marker-end: url(#circle);
}

.svgbob .start_marked_circle {
  marker-start: url(#circle);
}

.svgbob .end_marked_open_circle {
  marker-end: url(#open_circle);
}

.svgbob .start_marked_open_circle {
  marker-start: url(#open_circle);
}

.svgbob .end_marked_big_open_circle {
  marker-end: url(#big_open_circle);
}

.svgbob .start_marked_big_open_circle {
  marker-start: url(#big_open_circle);
}

</style>`;
}

function defs() { return `  <defs>
    <marker id="arrow" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,0 0,4 4,2 0,0"></polygon>
    </marker>
    <marker id="diamond" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,2 2,0 4,2 2,4 0,2"></polygon>
    </marker>
    <marker id="circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="filled"></circle>
    </marker>
    <marker id="open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="bg_filled"></circle>
    </marker>
    <marker id="big_open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="3" class="bg_filled"></circle>
    </marker>
  </defs>`; }

function toLines(input) {
  return String(input).replace(/\\n/g, '\n').replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/\n+$/,'').split('\n');
}
function ch(lines, r, c) { return (lines[r] && c >= 0 && c < lines[r].length) ? lines[r][c] : ' '; }
function mark(mask, r, c) { if (!mask[r]) mask[r] = new Set(); mask[r].add(c); }
function used(mask, r, c) { return mask[r] && mask[r].has(c); }

function render(input, opts) {
  const lines = toLines(input);
  if (lines.length === 1 && lines[0] === '') lines[0] = '';
  const maxLen = Math.max(0, ...lines.map(l => l.length));
  const width = (maxLen + 1) * 8 * opts.scale;
  const height = (lines.length + 1) * 16 * opts.scale;
  const out = [];
  const add = (row, col, svg, pri = 1) => out.push({row, col, pri, svg});
  const mask = [];

  // Rectangles formed by +---+ / |   | / +---+.
  for (let r = 0; r < lines.length; r++) {
    const line = lines[r];
    for (let c = 0; c < line.length; c++) {
      if (line[c] !== '+') continue;
      for (let c2 = c + 2; c2 < line.length; c2++) {
        if (line[c2] !== '+') continue;
        const top = line.slice(c + 1, c2);
        if (!/^-+$/.test(top)) continue;
        for (let r2 = r + 2; r2 < lines.length; r2++) {
          if (ch(lines, r2, c) !== '+' || ch(lines, r2, c2) !== '+') continue;
          if (!/^-+$/.test(lines[r2].slice(c + 1, c2))) continue;
          let ok = true;
          for (let rr = r + 1; rr < r2; rr++) if (ch(lines, rr, c) !== '|' || ch(lines, rr, c2) !== '|') ok = false;
          if (!ok) continue;
          add(r, c, `  <rect x="${scaled(c*8+4,opts.scale)}" y="${scaled(r*16+8,opts.scale)}" width="${scaled((c2-c)*8,opts.scale)}" height="${scaled((r2-r)*16,opts.scale)}" class="solid nofill" rx="0"></rect>`, 0);
          for (let cc = c; cc <= c2; cc++) { mark(mask,r,cc); mark(mask,r2,cc); }
          for (let rr = r; rr <= r2; rr++) { mark(mask,rr,c); mark(mask,rr,c2); }
          break;
        }
      }
    }
  }

  for (let r = 0; r < lines.length; r++) {
    const line = lines[r];
    let c = 0;
    while (c < line.length) {
      if (used(mask,r,c)) { c++; continue; }
      const rest = line.slice(c);
      const arrow = rest.match(/^(<)?(-{2,})(>)?/);
      if (arrow && (arrow[1] || arrow[3] || arrow[2].length >= 2)) {
        const left = !!arrow[1], right = !!arrow[3], len = arrow[0].length;
        const y = r*16 + 8;
        let x1 = c*8, x2 = (c+len)*8;
        if (left) { add(r, c, `  <polygon points="${scaled(x1+8,opts.scale)},${scaled(y-4,opts.scale)} ${scaled(x1,opts.scale)},${scaled(y,opts.scale)} ${scaled(x1+8,opts.scale)},${scaled(y+4,opts.scale)}" class="filled"></polygon>`); x1 += 8; }
        if (right) { add(r, c + (left ? 1 : 0), `  <line x1="${scaled(x1,opts.scale)}" y1="${scaled(y,opts.scale)}" x2="${scaled(x2-8,opts.scale)}" y2="${scaled(y,opts.scale)}" class="solid"></line>`); add(r, c+len-1, `  <polygon points="${scaled(x2-8,opts.scale)},${scaled(y-4,opts.scale)} ${scaled(x2,opts.scale)},${scaled(y,opts.scale)} ${scaled(x2-8,opts.scale)},${scaled(y+4,opts.scale)}" class="filled"></polygon>`); }
        else add(r, c, `  <line x1="${scaled(x1,opts.scale)}" y1="${scaled(y,opts.scale)}" x2="${scaled(x2,opts.scale)}" y2="${scaled(y,opts.scale)}" class="solid"></line>`);
        for (let i=0;i<len;i++) mark(mask,r,c+i); c += len; continue;
      }
      if (line[c] === '-' || line[c] === '+') {
        let e = c; while (e < line.length && !used(mask,r,e) && (line[e] === '-' || line[e] === '+')) e++;
        if (e - c >= 2 || line.slice(c,e).includes('-')) {
          const pad = line[c] === '+' || line[e-1] === '+' ? 4 : 0;
          add(r, c, `  <line x1="${scaled(c*8+pad,opts.scale)}" y1="${scaled(r*16+8,opts.scale)}" x2="${scaled(e*8-pad,opts.scale)}" y2="${scaled(r*16+8,opts.scale)}" class="solid"></line>`);
          for (let i=c;i<e;i++) mark(mask,r,i);
        }
        c = e; continue;
      }
      c++;
    }
  }

  for (let c = 0; c < maxLen; c++) {
    let r = 0;
    while (r < lines.length) {
      if (used(mask,r,c) || ch(lines,r,c) !== '|') { r++; continue; }
      let e = r; while (e < lines.length && !used(mask,e,c) && ch(lines,e,c) === '|') e++;
      add(r, c, `  <line x1="${scaled(c*8+4,opts.scale)}" y1="${scaled(r*16,opts.scale)}" x2="${scaled(c*8+4,opts.scale)}" y2="${scaled(e*16,opts.scale)}" class="solid"></line>`);
      for (let rr=r; rr<e; rr++) mark(mask,rr,c);
      r = e;
    }
  }

  const textChars = /[^\s+\-|<>\\/]/;
  for (let r = 0; r < lines.length; r++) {
    let c = 0;
    while (c < lines[r].length) {
      while (c < lines[r].length && (used(mask,r,c) || !textChars.test(lines[r][c]))) c++;
      const start = c;
      while (c < lines[r].length && !used(mask,r,c) && textChars.test(lines[r][c])) c++;
      if (c > start) add(r, start, `  <text x="${scaled(start*8+2,opts.scale)}" y="${scaled(r*16+12,opts.scale)}" >${esc(lines[r].slice(start,c))}</text>`, 0);
    }
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${n(width)}" height="${n(height)}" class="svgbob">
  ${style(opts)}
${defs()}
  <rect class="backdrop" x="0" y="0" width="${n(width)}" height="${n(height)}"></rect>
${out.sort((a,b)=>a.row-b.row || a.col-b.col || a.pri-b.pri).map(e=>e.svg).join('\n')}${out.length ? '\n' : ''}</svg>`;
}

function expandPattern(pattern) {
  if (!pattern) return [];
  if (!pattern.includes('*')) return [pattern];
  const dir = path.dirname(pattern) === '.' ? '.' : path.dirname(pattern);
  const base = path.basename(pattern).replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
  const re = new RegExp('^' + base + '$');
  return fs.readdirSync(dir).filter(f => re.test(f)).map(f => path.join(dir, f));
}
function runBuild(args) {
  if (args.includes('-h') || args.includes('--help')) { console.log(BUILD_HELP); return; }
  if (args.includes('-V') || args.includes('--version')) { console.log('executable-build 0.0.1'); return; }
  let input = null, outdir = '.';
  for (let i=0;i<args.length;i++) { if (args[i]==='-i'||args[i]==='--input') input=args[++i]; else if (args[i]==='-o'||args[i]==='--outdir') outdir=args[++i]; }
  if (!input) die('error: The following required arguments were not provided:\n    --input <input>');
  fs.mkdirSync(outdir, {recursive:true});
  for (const file of expandPattern(input)) {
    const svg = render(fs.readFileSync(file,'utf8'), parseArgs([]).opts);
    fs.writeFileSync(path.join(outdir, path.basename(file).replace(/\.[^.]*$/, '') + '.svg'), svg);
  }
}

(function main(){
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed.build) return runBuild(parsed.buildArgs);
  const opts = parsed.opts;
  let input = '';
  if (opts.inline) input = opts.input || '';
  else if (opts.input) input = fs.readFileSync(opts.input, 'utf8');
  else input = fs.readFileSync(0, 'utf8');
  const svg = render(input, opts);
  if (opts.output) fs.writeFileSync(opts.output, svg); else process.stdout.write(svg + '\n');
})();
