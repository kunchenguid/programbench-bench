#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const YAML = require('../vendor/yaml');

const VERSION = 'yq (https://github.com/mikefarah/yq/) version v4.52.5';

function main() {
  try {
    const opts = parseArgs(process.argv.slice(2));
    if (opts.help) return printHelp(opts.command, opts.commandSpecified);
    if (opts.version) return console.log(VERSION);
    if (opts.fromFile) opts.expression = fs.readFileSync(opts.fromFile, 'utf8').trim();
    if (opts.expressionFlag) opts.expression = opts.expressionFlag;
    if (!opts.expression) opts.expression = '.';

    let docs = [];
    if (opts.nullInput) {
      docs = [{ value: null, text: '', file: null, index: 0, fileIndex: 0, format: 'yaml' }];
    } else {
      const files = opts.files.length ? opts.files : ['-'];
      let fileIndex = 0;
      for (const file of files) {
        const text = file === '-' ? fs.readFileSync(0, 'utf8') : fs.readFileSync(file, 'utf8');
        const format = normalizeFormat(opts.inputFormat === 'auto' ? detectInput(file, opts.inputFormat) : opts.inputFormat);
        const values = parseInput(text, format, opts);
        values.forEach((value, index) => docs.push({ value, text, file, index, fileIndex, format }));
        fileIndex++;
      }
    }

    if (opts.evalAll) {
      docs = [{ value: docs.map(d => d.value), docs, text: docs.map(d => d.text).join('\n'), file: opts.files[0] || null, index: 0, fileIndex: 0, format: docs[0]?.format || 'yaml' }];
      if (/ireduce\s*\(\s*\{\}\s*;\s*\.\s*\*\s*\$item\s*\)/.test(opts.expression)) {
        const merged = docs[0].docs.reduce((acc, d) => deepMerge(acc, d.value), {});
        return outputAll([merged], opts, docs[0]);
      }
      const m = opts.expression.match(/select\((?:fileIndex|fi)\s*==\s*(\d+)\)\s*\*\s*select\((?:fileIndex|fi)\s*==\s*(\d+)\)/);
      if (m) {
        const a = docs[0].docs.find(d => d.fileIndex === Number(m[1]))?.value;
        const b = docs[0].docs.find(d => d.fileIndex === Number(m[2]))?.value;
        return outputAll([deepMerge(a, b)], opts, docs[0]);
      }
    }

    if (opts.inplace) {
      if (!opts.files.length || opts.files[0] === '-') throw new Error('write in place flag only applicable when giving an expression and at least one file');
      const first = parseInput(fs.readFileSync(opts.files[0], 'utf8'), normalizeFormat(opts.inputFormat === 'auto' ? detectInput(opts.files[0]) : opts.inputFormat), opts)[0];
      const changed = applyExpression(opts.expression, first, { opts, doc: { file: opts.files[0], fileIndex: 0, index: 0 } });
      const val = changed.length ? changed[0] : first;
      fs.writeFileSync(opts.files[0], formatValue(val, { ...opts, outputFormat: normalizeFormat(opts.outputFormat === 'auto' ? detectOutput(opts.files[0], 'yaml') : opts.outputFormat), unwrap: false }) + (isScalar(val) ? '\n' : ''));
      return;
    }

    let outputs = [];
    for (const doc of docs) {
      let res;
      if (isIdentity(opts.expression) && doc.text && opts.outputFormat === 'auto' && doc.format === 'yaml') {
        res = [{ __rawYqText: doc.text.trimEnd() }];
      } else {
        res = applyExpression(opts.expression, doc.value, { opts, doc });
      }
      outputs.push(...res);
    }
    if (opts.exitStatus && (!outputs.length || outputs.some(v => v == null || v === false))) process.exitCode = 1;
    outputAll(outputs, opts, docs[0]);
  } catch (err) {
    console.error('Error: ' + (err && err.message ? err.message : String(err)));
    process.exit(1);
  }
}

function parseArgs(args) {
  const opts = {
    command: 'eval', evalAll: false, inputFormat: 'auto', outputFormat: 'auto', indent: 2,
    nullInput: false, inplace: false, pretty: false, unwrap: true, files: [], expression: null,
    expressionFlag: null, fromFile: null, exitStatus: false, nul: false, propertiesSeparator: ' = ',
    csvSeparator: ',', shellKeySeparator: '_', noDoc: false
  };
  if (['eval', 'e', 'eval-all', 'ea'].includes(args[0])) {
    opts.commandSpecified = true;
    opts.command = args.shift();
    opts.evalAll = opts.command === 'eval-all' || opts.command === 'ea';
  } else if (args[0] === 'help') {
    opts.help = true; opts.command = args[1] || 'yq'; return opts;
  } else if (args[0] === 'completion') {
    opts.completion = args[1] || 'bash'; return opts;
  }
  const positionals = [];
  for (let i = 0; i < args.length; i++) {
    let a = args[i];
    const next = () => {
      if (a.includes('=')) return a.slice(a.indexOf('=') + 1);
      return args[++i];
    };
    if (a === '--') { positionals.push(...args.slice(i + 1)); break; }
    else if (a === '-h' || a === '--help') opts.help = true;
    else if (a === '-V' || a === '--version') opts.version = true;
    else if (a === '-n' || a === '--null-input') opts.nullInput = true;
    else if (a === '-i' || a === '--inplace') opts.inplace = true;
    else if (a === '-P' || a === '--prettyPrint') opts.pretty = true;
    else if (a === '-r' || a === '--unwrapScalar') opts.unwrap = true;
    else if (a === '-e' || a === '--exit-status') opts.exitStatus = true;
    else if (a === '-0' || a === '--nul-output') opts.nul = true;
    else if (a === '-N' || a === '--no-doc') opts.noDoc = true;
    else if (a === '-M' || a === '--no-colors' || a === '-C' || a === '--colors' || a === '-v' || a === '--verbose') {}
    else if (a === '-p' || a === '--input-format' || a.startsWith('-p=') || a.startsWith('--input-format=')) opts.inputFormat = normalizeFormat(next());
    else if (a.startsWith('-p') && a.length > 2) opts.inputFormat = normalizeFormat(a.slice(2));
    else if (a === '-o' || a === '--output-format' || a.startsWith('-o=') || a.startsWith('--output-format=')) opts.outputFormat = normalizeFormat(next());
    else if (a.startsWith('-o') && a.length > 2) opts.outputFormat = normalizeFormat(a.slice(2));
    else if (a === '-I' || a === '--indent' || a.startsWith('-I=') || a.startsWith('--indent=')) opts.indent = Number(next()) || 2;
    else if (a === '--expression' || a.startsWith('--expression=')) opts.expressionFlag = next();
    else if (a === '--from-file' || a.startsWith('--from-file=')) opts.fromFile = next();
    else if (a === '--properties-separator' || a.startsWith('--properties-separator=')) opts.propertiesSeparator = next();
    else if (a === '--csv-separator' || a.startsWith('--csv-separator=')) opts.csvSeparator = next();
    else if (a === '--shell-key-separator' || a.startsWith('--shell-key-separator=')) opts.shellKeySeparator = next();
    else if (a.startsWith('-')) {
      if (a === '-f' || a === '-s' || a === '--front-matter' || a === '--split-exp' || a === '--split-exp-file') i++;
    } else positionals.push(a);
  }
  if (opts.completion) return opts;
  if (positionals.length) {
    if (opts.expressionFlag) opts.files = positionals;
    else if (looksLikeExpression(positionals[0]) || opts.nullInput) {
      opts.expression = positionals[0]; opts.files = positionals.slice(1);
    } else {
      opts.expression = '.'; opts.files = positionals;
    }
  }
  return opts;
}

function normalizeFormat(f) {
  const map = { y: 'yaml', a: 'auto', j: 'json', p: 'props', c: 'csv', t: 'tsv', x: 'xml', s: 'shell', h: 'hcl', l: 'lua', i: 'ini', ky: 'yaml', kyaml: 'yaml', properties: 'props' };
  return map[f] || f || 'auto';
}

function detectInput(file) {
  if (!file || file === '-') return 'yaml';
  const ext = path.extname(file).toLowerCase();
  return ({ '.json': 'json', '.yaml': 'yaml', '.yml': 'yaml', '.xml': 'xml', '.csv': 'csv', '.tsv': 'tsv', '.properties': 'props', '.props': 'props', '.toml': 'toml', '.ini': 'ini' })[ext] || 'yaml';
}

function detectOutput(file, fallback) {
  const fmt = detectInput(file);
  return fmt === 'json' ? 'json' : (fallback || 'yaml');
}

function looksLikeExpression(s) {
  return s === '.' || s.startsWith('.') || s.startsWith('[') || s.startsWith('{') || /^[a-zA-Z_][\w-]*\s*(\(|$)/.test(s) || /[=|+*]/.test(s);
}

function parseInput(text, format, opts) {
  if (format === 'json') return [JSON.parse(text || 'null')];
  if (format === 'csv' || format === 'tsv') return [parseDelimited(text, format === 'tsv' ? '\t' : opts.csvSeparator)];
  if (format === 'props' || format === 'ini') return [parseProperties(text)];
  if (format === 'xml') return [parseXml(text)];
  if (format === 'base64') return [Buffer.from(text.trim(), 'base64').toString('utf8')];
  if (format === 'uri') return [decodeURIComponent(text.trim().replace(/\+/g, '%20'))];
  const docs = YAML.parseAllDocuments(text || 'null', { prettyErrors: false });
  return docs.length ? docs.map(d => d.toJS()) : [null];
}

function parseDelimited(text, sep) {
  const rows = text.trimEnd().split(/\r?\n/).filter(Boolean).map(line => splitCsv(line, sep));
  if (!rows.length) return [];
  const headers = rows[0];
  return rows.slice(1).map(r => Object.fromEntries(headers.map((h, i) => [h, autoScalar(r[i] ?? '')])));
}

function splitCsv(line, sep) {
  const out = []; let cur = '', q = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
    else if (ch === '"') q = !q;
    else if (ch === sep && !q) { out.push(cur); cur = ''; }
    else cur += ch;
  }
  out.push(cur); return out;
}

function parseProperties(text) {
  const root = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#') || line.startsWith('!')) continue;
    const m = line.match(/^([^:=]+?)\s*(?:=|:)\s*(.*)$/);
    if (!m) continue;
    setPath(root, m[1].trim().split('.').map(p => /^\d+$/.test(p) ? Number(p) : p), autoScalar(m[2].trim()));
  }
  return root;
}

function parseXml(text) {
  text = text.replace(/<\?[\s\S]*?\?>/g, '').replace(/<![\s\S]*?>/g, '').trim();
  const stack = [{ name: null, obj: {} }];
  const re = /<([^>]+)>|([^<]+)/g; let m;
  while ((m = re.exec(text))) {
    if (m[2]) {
      const val = m[2].trim();
      if (val) stack[stack.length - 1].obj['+content'] = autoScalar(val);
      continue;
    }
    let tag = m[1].trim();
    if (tag.startsWith('/')) {
      const child = stack.pop();
      addXmlChild(stack[stack.length - 1].obj, child.name, child.obj);
    } else {
      const self = tag.endsWith('/'); if (self) tag = tag.slice(0, -1).trim();
      const parts = tag.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
      const name = parts.shift();
      const obj = {};
      for (const p of parts) {
        const eq = p.indexOf('=');
        if (eq > 0) obj['+@' + p.slice(0, eq)] = p.slice(eq + 1).replace(/^['"]|['"]$/g, '');
      }
      if (self) addXmlChild(stack[stack.length - 1].obj, name, obj);
      else stack.push({ name, obj });
    }
  }
  return stack[0].obj;
}

function addXmlChild(parent, name, value) {
  if (value && typeof value === 'object' && Object.keys(value).length === 1 && value['+content'] !== undefined) value = value['+content'];
  if (parent[name] === undefined) parent[name] = value;
  else if (Array.isArray(parent[name])) parent[name].push(value);
  else parent[name] = [parent[name], value];
}

function applyExpression(expr, input, ctx) {
  expr = expr.trim();
  const assign = findTopLevelAssignment(expr);
  if (assign >= 0) {
    const left = expr.slice(0, assign).trim();
    const right = expr.slice(assign + 1).trim();
    const root = clone(input == null ? {} : input);
    setPath(root, parsePath(left), evalSingle(right, root, ctx));
    return [root];
  }
  const parts = splitTop(expr, '|');
  let vals = [input];
  for (const part of parts) {
    vals = vals.flatMap(v => evalMany(part.trim(), v, ctx));
  }
  return vals;
}

function evalMany(expr, input, ctx) {
  if (!expr || expr === '.') return [input];
  if (expr.startsWith('[') && expr.endsWith(']') && !isLiteralArray(expr)) return [applyExpression(expr.slice(1, -1).trim(), input, ctx)];
  if (expr.startsWith('select(') && expr.endsWith(')')) return truthy(evalSingle(expr.slice(7, -1), input, ctx)) ? [input] : [];
  if (/^\.[\w"'\[\].-]+$/.test(expr) || expr.includes('[]')) return getPathMany(input, parsePath(expr));
  return [evalSingle(expr, input, ctx)];
}

function evalSingle(expr, input, ctx) {
  expr = expr.trim();
  const plus = findTopLevelOp(expr, '+');
  if (plus >= 0) return evalSingle(expr.slice(0, plus), input, ctx) + evalSingle(expr.slice(plus + 1), input, ctx);
  const mult = findTopLevelOp(expr, '*');
  if (mult >= 0) return deepMerge(evalSingle(expr.slice(0, mult), input, ctx), evalSingle(expr.slice(mult + 1), input, ctx));
  const eq = expr.match(/^(.+?)\s*==\s*(.+)$/);
  if (eq) return evalSingle(eq[1], input, ctx) === evalSingle(eq[2], input, ctx);
  if (expr === 'length') return Array.isArray(input) || typeof input === 'string' ? input.length : input && typeof input === 'object' ? Object.keys(input).length : 0;
  if (expr === 'keys') return input && typeof input === 'object' ? Object.keys(input) : [];
  if (expr === 'fileIndex' || expr === 'fi') return ctx.doc.fileIndex || 0;
  if (expr === 'documentIndex' || expr === 'di') return ctx.doc.index || 0;
  let m = expr.match(/^strenv\(([^)]+)\)$/) || expr.match(/^env\(([^)]+)\)$/);
  if (m) return process.env[m[1]] ?? '';
  m = expr.match(/^load\(["'](.+)["']\)$/);
  if (m) return parseInput(fs.readFileSync(m[1], 'utf8'), detectInput(m[1]), ctx.opts)[0];
  if (expr === '.' || expr.startsWith('.')) return getPathMany(input, parsePath(expr))[0] ?? null;
  if (/^["']/.test(expr)) return expr.slice(1, -1);
  if (/^-?\d+(\.\d+)?$/.test(expr)) return Number(expr);
  if (expr === 'true') return true;
  if (expr === 'false') return false;
  if (expr === 'null' || expr === '~') return null;
  if ((expr.startsWith('{') && expr.endsWith('}')) || isLiteralArray(expr)) return YAML.parse(expr);
  return expr;
}

function parsePath(expr) {
  expr = expr.trim();
  if (expr === '.') return [];
  if (expr.startsWith('.')) expr = expr.slice(1);
  const out = []; let cur = '';
  for (let i = 0; i < expr.length; i++) {
    const ch = expr[i];
    if (ch === '.') { if (cur) { out.push(cur); cur = ''; } }
    else if (ch === '[') {
      if (cur) { out.push(cur); cur = ''; }
      const end = expr.indexOf(']', i); const inside = expr.slice(i + 1, end);
      out.push(inside === '' ? { expand: true } : Number(inside));
      i = end;
    } else cur += ch;
  }
  if (cur) out.push(cur.replace(/^["']|["']$/g, ''));
  return out;
}

function getPathMany(value, parts) {
  let vals = [value];
  for (const p of parts) {
    const next = [];
    for (const v of vals) {
      if (p && p.expand) {
        if (Array.isArray(v)) next.push(...v);
        else if (v && typeof v === 'object') next.push(...Object.values(v));
      } else if (v != null && v[p] !== undefined) next.push(v[p]);
      else next.push(null);
    }
    vals = next;
  }
  return vals;
}

function setPath(root, parts, val) {
  let cur = root;
  for (let i = 0; i < parts.length; i++) {
    const p = parts[i], last = i === parts.length - 1, n = parts[i + 1];
    if (last) cur[p] = val;
    else {
      if (cur[p] == null) cur[p] = typeof n === 'number' ? [] : {};
      cur = cur[p];
    }
  }
  return root;
}

function outputAll(values, opts, firstDoc) {
  const sep = opts.nul ? '\0' : '\n';
  const pieces = values.map(v => formatValue(v, opts, firstDoc));
  if (!pieces.length) return;
  const text = pieces.join(sep);
  process.stdout.write(text);
  if (!opts.nul && !text.endsWith('\n')) process.stdout.write('\n');
}

function formatValue(v, opts, firstDoc) {
  if (v && typeof v === 'object' && Object.prototype.hasOwnProperty.call(v, '__rawYqText')) return v.__rawYqText;
  const fmt = normalizeFormat(opts.outputFormat === 'auto' ? (firstDoc ? detectOutput(firstDoc.file, firstDoc.format) : 'yaml') : opts.outputFormat);
  if (fmt === 'json') return JSON.stringify(v, null, opts.indent);
  if (fmt === 'props') return flatten(v, '.', opts.propertiesSeparator).join('\n');
  if (fmt === 'shell') return flatten(v, opts.shellKeySeparator, '=').join('\n');
  if (fmt === 'csv' || fmt === 'tsv') return toDelimited(v, fmt === 'tsv' ? '\t' : opts.csvSeparator);
  if (fmt === 'xml') return toXml(v);
  if (fmt === 'base64') return Buffer.from(String(v ?? '')).toString('base64');
  if (fmt === 'uri') return encodeURIComponent(String(v ?? '')).replace(/%20/g, '+');
  if (opts.unwrap && isScalar(v)) return v === null || v === undefined ? 'null' : String(v);
  return YAML.stringify(v, { indent: opts.indent, lineWidth: 0 }).trimEnd();
}

function flatten(v, sep, kv, prefix = '') {
  if (Array.isArray(v)) return v.flatMap((x, i) => flatten(x, sep, kv, prefix ? prefix + sep + i : String(i)));
  if (v && typeof v === 'object') return Object.keys(v).flatMap(k => flatten(v[k], sep, kv, prefix ? prefix + sep + k : k));
  return [prefix + kv + String(v === undefined ? 'null' : v)];
}

function toDelimited(v, sep) {
  if (!Array.isArray(v)) throw new Error((sep === '\t' ? 'tsv' : 'csv') + ' encoding only works for arrays, got: !!map');
  if (!v.length) return '';
  const keys = Object.keys(v[0] || {});
  const esc = x => {
    x = String(x ?? '');
    return /[",\n\r\t]/.test(x) ? '"' + x.replace(/"/g, '""') + '"' : x;
  };
  return [keys.join(sep), ...v.map(r => keys.map(k => esc(r[k])).join(sep))].join('\n');
}

function toXml(v, name = null) {
  if (name == null && v && typeof v === 'object' && !Array.isArray(v)) return Object.keys(v).map(k => toXml(v[k], k)).join('');
  if (Array.isArray(v)) return v.map(x => toXml(x, name)).join('');
  const attrs = []; let content = '';
  if (v && typeof v === 'object') {
    for (const [k, x] of Object.entries(v)) {
      if (k.startsWith('+@')) attrs.push(`${k.slice(2)}="${escapeXml(x)}"`);
      else if (k === '+content') content += escapeXml(x);
      else content += toXml(x, k);
    }
  } else content = escapeXml(v ?? '');
  return `<${name}${attrs.length ? ' ' + attrs.join(' ') : ''}>${content}</${name}>`;
}

function autoScalar(s) {
  if (s === 'true') return true; if (s === 'false') return false; if (s === 'null' || s === '~') return null;
  if (/^-?\d+(\.\d+)?$/.test(s)) return Number(s);
  return s;
}

function isScalar(v) { return v == null || typeof v !== 'object'; }
function clone(v) { return v == null ? v : JSON.parse(JSON.stringify(v)); }
function truthy(v) { return !(v === false || v === null || v === undefined); }
function isIdentity(e) { return e.trim() === '.'; }
function isLiteralArray(e) { return e.startsWith('[') && e.endsWith(']') && !e.includes('|') && !e.includes('select('); }
function escapeXml(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

function deepMerge(a, b) {
  if (Array.isArray(a) && Array.isArray(b)) return b.slice();
  if (a && b && typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) {
    const out = clone(a);
    for (const [k, v] of Object.entries(b)) out[k] = k in out ? deepMerge(out[k], v) : clone(v);
    return out;
  }
  return clone(b);
}

function splitTop(s, op) {
  const out = []; let start = 0, depth = 0, quote = null;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (quote) { if (ch === quote && s[i - 1] !== '\\') quote = null; }
    else if (ch === '"' || ch === "'") quote = ch;
    else if ('([{'.includes(ch)) depth++;
    else if (')]}'.includes(ch)) depth--;
    else if (ch === op && depth === 0) { out.push(s.slice(start, i)); start = i + 1; }
  }
  out.push(s.slice(start)); return out;
}

function findTopLevelAssignment(s) {
  for (let i = 0, depth = 0, quote = null; i < s.length; i++) {
    const ch = s[i];
    if (quote) { if (ch === quote && s[i - 1] !== '\\') quote = null; }
    else if (ch === '"' || ch === "'") quote = ch;
    else if ('([{'.includes(ch)) depth++;
    else if (')]}'.includes(ch)) depth--;
    else if (ch === '=' && s[i + 1] !== '=' && s[i - 1] !== '=' && depth === 0) return i;
  }
  return -1;
}

function findTopLevelOp(s, op) {
  for (let i = 0, depth = 0, quote = null; i < s.length; i++) {
    const ch = s[i];
    if (quote) { if (ch === quote && s[i - 1] !== '\\') quote = null; }
    else if (ch === '"' || ch === "'") quote = ch;
    else if ('([{'.includes(ch)) depth++;
    else if (')]}'.includes(ch)) depth--;
    else if (ch === op && depth === 0) return i;
  }
  return -1;
}

function printHelp(command, commandSpecified) {
  const topLevel = !commandSpecified;
  if (!topLevel && (command === 'eval' || command === 'e')) {
    console.log('Usage:\n  yq eval [expression] [yaml_file1]... [flags]\n\nAliases:\n  eval, e');
  } else if (!topLevel && (command === 'eval-all' || command === 'ea')) {
    console.log('Usage:\n  yq eval-all [expression] [yaml_file1]... [flags]\n\nAliases:\n  eval-all, ea');
  } else {
    console.log(`yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) 
See https://mikefarah.gitbook.io/yq/ for detailed documentation and examples.

Usage:
  yq [flags]
  yq [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  eval        (default) Apply the expression to each document in each yaml file in sequence
  eval-all    Loads _all_ yaml documents of _all_ yaml files and runs expression once
  help        Help about any command

Flags:
  -h, --help                  help for yq
  -i, --inplace               update the file in place
  -n, --null-input            Don't read input, simply evaluate the expression given
  -o, --output-format string  output format type
  -p, --input-format string   parse format for input
  -V, --version               Print version information and quit`);
  }
}

main();
