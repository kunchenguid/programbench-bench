#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');

const VERSION = 'v1.13.0';

const HELP = `
  walk v1.13.0

  Usage: walk [path]

    arrows, hjkl  Move cursor
    enter         Enter directory
    backspace     Exit directory
    space         Toggle preview
    esc, q        Exit with cd
    ctrl+c        Exit without cd
    /             Fuzzy search
    d, delete     Delete file or dir
    y             Copy to clipboard
    .             Hide hidden files
    ?             Show help

  Flags:

    --icons        display icons
    --dir-only     show dirs only
    --hide-hidden  hide hidden files
    --preview      display preview
    --with-border  preview with border
    --fuzzy        fuzzy mode

`;

function hasArg(flag) {
  return process.argv.slice(2).includes(flag);
}

function firstPathArg(args) {
  for (const arg of args) {
    if (arg === '--icons' || arg === '--dir-only' || arg === '--hide-hidden' ||
        arg === '--preview' || arg === '--with-border' || arg === '--fuzzy') {
      continue;
    }
    if (arg === '--help' || arg === '-h' || arg === '--version' || arg === '-v') {
      continue;
    }
    return arg;
  }
  return '.';
}

function panicNoTTY() {
  process.stderr.write('panic: could not open a new TTY: open /dev/tty: no such device or address\n\n');
  process.stderr.write('goroutine 1 [running]:\n');
  process.stderr.write('main.main()\n\t/workspace/main.go:135 +0x87d\n');
  process.exit(2);
}

function displayWidth(s) {
  let n = 0;
  for (const ch of s) n += ch.codePointAt(0) > 0x7f ? 2 : 1;
  return n;
}

function padRight(s, width) {
  const len = displayWidth(s);
  return s + ' '.repeat(Math.max(0, width - len));
}

function iconFor(entry) {
  if (entry.isDirectory()) return ' ';
  if (entry.isSymbolicLink()) return ' ';
  const ext = path.extname(entry.name).toLowerCase();
  const map = {
    '.md': ' ', '.markdown': ' ', '.js': ' ', '.json': ' ',
    '.html': ' ', '.css': ' ', '.py': ' ', '.go': ' ',
    '.rs': ' ', '.sh': ' ', '.png': ' ', '.jpg': ' ',
    '.jpeg': ' ', '.gif': ' ', '.yml': ' ', '.yaml': ' ',
    '.toml': ' ', '.txt': ' ', '.log': ' '
  };
  return map[ext] || ' ';
}

class Walk {
  constructor(opts) {
    this.dir = path.resolve(opts.start);
    this.selected = 0;
    this.showIcons = opts.icons;
    this.dirOnly = opts.dirOnly;
    this.hideHidden = opts.hideHidden;
    this.preview = opts.preview;
    this.withBorder = opts.withBorder;
    this.fuzzy = opts.fuzzy;
    this.files = [];
    this.linesDrawn = 0;
    this.alt = this.preview || this.withBorder;
    this.done = false;
  }

  load() {
    try {
      const entries = fs.readdirSync(this.dir, {withFileTypes: true})
        .filter(e => !this.hideHidden || !e.name.startsWith('.'))
        .filter(e => !this.dirOnly || e.isDirectory())
        .sort((a, b) => a.name.localeCompare(b.name));
      this.files = entries;
      if (this.selected >= this.files.length) this.selected = Math.max(0, this.files.length - 1);
    } catch (err) {
      this.files = [];
      this.error = err.message;
    }
  }

  selectedEntry() {
    return this.files[this.selected];
  }

  selectedPathForExit() {
    const e = this.selectedEntry();
    if (e && e.isDirectory()) return path.join(this.dir, e.name);
    return this.dir;
  }

  lineFor(entry, width) {
    let name = entry.name + (entry.isDirectory() ? '/' : '');
    if (this.showIcons) name = iconFor(entry) + name;
    return padRight(name, width);
  }

  renderHelpBox() {
    return [
      '╭────────────────────────────────────────────╮',
      '│ arrows/hjkl move, enter opens directories │',
      '│ q or esc exits, ctrl+c cancels, . hides   │',
      '╰────────────────────────────────────────────╯'
    ];
  }

  renderPreview(entry, width) {
    if (!entry) return [];
    const p = path.join(this.dir, entry.name);
    if (entry.isDirectory()) {
      try {
        return fs.readdirSync(p).slice(0, 12).map(x => '  ' + x);
      } catch (_) {
        return [];
      }
    }
    try {
      const data = fs.readFileSync(p);
      const text = data.toString('utf8');
      if (text.includes('\u0000')) return ['binary file'];
      return text.split(/\r?\n/).slice(0, 12).map(x => x.slice(0, Math.max(1, width)));
    } catch (_) {
      return [];
    }
  }

  render() {
    this.load();
    const cols = process.stdout.columns || 80;
    const rows = process.stdout.rows || 24;
    const out = [];
    if (this.linesDrawn > 0) out.push(`\x1b[${this.linesDrawn}A`);
    const header = this.preview && this.selectedEntry()
      ? `${this.dir}  ${this.selectedEntry().name}${this.selectedEntry().isDirectory() ? '/' : ''}`
      : this.dir;
    out.push('\r' + header.slice(Math.max(0, header.length - cols)) + '\x1b[K\n');
    if (this.error) {
      const msg = ` open ${this.dir}: ${this.error.replace(/^.*?: /, '')} `;
      const border = '─'.repeat(displayWidth(msg));
      out.push(`╭${border}╮\x1b[K\n`);
      out.push(`│${msg}│\x1b[K\n`);
      out.push(`╰${border}╯\x1b[K`);
      this.linesDrawn = 4;
      process.stderr.write(out.join(''));
      return;
    }
    const maxName = Math.max(0, ...this.files.map(e => displayWidth((this.showIcons ? iconFor(e) : '') + e.name + (e.isDirectory() ? '/' : ''))));
    const listWidth = this.preview ? Math.min(Math.max(maxName + 8, 18), Math.floor(cols * 0.45)) : maxName;
    const visible = Math.min(this.files.length, rows - 2);
    for (let i = 0; i < visible; i++) {
      const entry = this.files[i];
      let line = this.lineFor(entry, listWidth);
      if (i === this.selected) line = '\x1b[7m' + line + '\x1b[0m';
      if (this.preview) {
        const prev = i === 0 ? this.renderPreview(this.selectedEntry(), cols - listWidth - 3)[0] || '' : (this.renderPreview(this.selectedEntry(), cols - listWidth - 3)[i] || '');
        line += '  ' + prev;
      }
      out.push(line + '\x1b[K\n');
    }
    out.push('\x1b[K');
    this.linesDrawn = 2 + visible;
    process.stderr.write(out.join(''));
  }

  cleanup() {
    const out = [];
    if (this.linesDrawn > 1) out.push(`\x1b[${this.linesDrawn - 1}A`);
    for (let i = 0; i < Math.max(0, this.linesDrawn - 1); i++) out.push('\n');
    out.push('\x1b[K\x1b[80D\x1b[2K\r');
    out.push('\x1b[?2004l\x1b[?25h\x1b[?1002l\x1b[?1003l\x1b[?1006l');
    if (this.alt) out.push('\x1b[?1049l\x1b[?25h');
    process.stderr.write(out.join(''));
  }

  exit(withPath) {
    if (this.done) return;
    this.done = true;
    try { process.stdin.setRawMode(false); } catch (_) {}
    this.cleanup();
    if (withPath) process.stdout.write(this.selectedPathForExit() + '\n');
    process.exit(withPath ? 0 : 130);
  }

  enter() {
    const e = this.selectedEntry();
    if (e && e.isDirectory()) {
      this.dir = path.join(this.dir, e.name);
      this.selected = 0;
    } else if (e) {
      const editor = process.env.WALK_EDITOR || process.env.EDITOR;
      if (editor) {
        try { childProcess.spawnSync(editor, [path.join(this.dir, e.name)], {stdio: 'inherit'}); } catch (_) {}
      }
    }
    this.render();
  }

  upDir() {
    const old = this.dir;
    this.dir = path.dirname(this.dir);
    const base = path.basename(old);
    this.load();
    const idx = this.files.findIndex(e => e.name === base);
    this.selected = idx >= 0 ? idx : 0;
    this.render();
  }

  removeSelected() {
    const e = this.selectedEntry();
    if (!e) return;
    const p = path.join(this.dir, e.name);
    try {
      const cmd = process.env.WALK_REMOVE_CMD;
      if (cmd) childProcess.spawnSync(cmd, [p], {stdio: 'ignore', shell: true});
      else fs.rmSync(p, {recursive: true, force: true});
    } catch (_) {}
    this.render();
  }

  handle(data) {
    let s = data.toString('utf8');
    s = s.replace(/\x1b\][\s\S]*?(?:\x07|\x1b\\)/g, '');
    s = s.replace(/\x1b\[\d+;\d+R/g, '');
    if (s.length > 1 && !s.startsWith('\x1b[')) {
      for (const ch of s) this.handle(Buffer.from(ch));
      return;
    }
    if (s === '\u0003') this.exit(false);
    if (s === 'q' || s === '\u001b') this.exit(true);
    if (s === '?' ) {
      process.stderr.write('\n' + this.renderHelpBox().join('\n') + '\n');
      return;
    }
    if (s === 'j' || s === '\u001b[B') {
      if (this.files.length) this.selected = Math.min(this.files.length - 1, this.selected + 1);
      return this.render();
    }
    if (s === 'k' || s === '\u001b[A') {
      if (this.files.length) this.selected = Math.max(0, this.selected - 1);
      return this.render();
    }
    if (s === 'h' || s === '\u007f' || s === '\b') return this.upDir();
    if (s === 'l' || s === '\r' || s === '\n') return this.enter();
    if (s === ' ') {
      this.preview = !this.preview;
      if (this.preview && !this.alt) {
        this.alt = true;
        process.stderr.write('\x1b[?1049h\x1b[2J\x1b[H');
      }
      return this.render();
    }
    if (s === '.') {
      this.hideHidden = !this.hideHidden;
      this.selected = 0;
      return this.render();
    }
    if (s === 'd' || s === '\u001b[3~') return this.removeSelected();
    if (s === '\u001b[H' || s === '\u001b[1~') {
      this.selected = 0;
      return this.render();
    }
    if (s === '\u001b[F' || s === '\u001b[4~') {
      this.selected = Math.max(0, this.files.length - 1);
      return this.render();
    }
  }

  run() {
    process.stderr.write('\x1b]11;?\x1b\\\x1b[6n');
    if (this.alt) process.stderr.write('\x1b[?25l\x1b[?1049h\x1b[2J\x1b[H');
    process.stderr.write('\x1b[?25l\x1b[?2004h');
    this.render();
    process.stdin.setEncoding('utf8');
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', d => this.handle(d));
  }
}

function main() {
  const args = process.argv.slice(2);
  if (hasArg('--version') || hasArg('-v')) {
    process.stdout.write(VERSION + '\n');
    process.exit(0);
  }
  if (hasArg('--help')) {
    process.stderr.write(HELP);
    process.exit(args[0] === '--help' ? 0 : 1);
  }
  if (hasArg('-h')) {
    process.stderr.write(HELP);
    process.exit(1);
  }
  if (!process.stdin.isTTY) panicNoTTY();
  const start = firstPathArg(args);
  const app = new Walk({
    start,
    icons: hasArg('--icons'),
    dirOnly: hasArg('--dir-only'),
    hideHidden: hasArg('--hide-hidden'),
    preview: hasArg('--preview'),
    withBorder: hasArg('--with-border'),
    fuzzy: hasArg('--fuzzy')
  });
  app.run();
}

main();
