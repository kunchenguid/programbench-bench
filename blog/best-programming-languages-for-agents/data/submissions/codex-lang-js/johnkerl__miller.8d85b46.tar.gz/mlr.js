#!/usr/bin/env node
'use strict';

const fs = require('fs');

const VERSION = 'mlr 6.16.0';
const VERBS = new Set('altkv bar bootstrap case cat check clean-whitespace count-distinct count count-similar cut decimate fill-down fill-empty filter flatten format-values fraction gap grep group-by group-like gsub having-fields head histogram json-parse json-stringify join label latin1-to-utf8 least-frequent merge-fields most-frequent nest nothing put regularize remove-empty-columns rename reorder repeat reshape sample sec2gmtdate sec2gmt seqgen shuffle skip-trivial-records sort sort-within-records sparsify split ssub stats1 stats2 step sub summary surv tac tail tee template top utf8-to-latin1 unflatten uniq unspace unsparsify'.split(' '));

function usage() {
  return `Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}

If zero file names are provided, standard input is read, e.g.
  mlr --csv sort -f shape example.csv

Output of one verb may be chained as input to another using "then", e.g.
  mlr --csv stats1 -a min,mean,max -f quantity then sort -f color example.csv

Please see 'mlr help topics' for more information.
Please also see https://miller.readthedocs.io`;
}

function help(args) {
  const topic = args[0] || 'topics';
  if (topic === 'topics') return `Type 'mlr help {topic}' for any of the following:
Essentials:
  mlr help topics
  mlr help basic-examples
  mlr help file-formats
Flags:
  mlr help flags
Verbs:
  mlr help list-verbs
  mlr help usage-verbs
  mlr help verb
Functions:
  mlr help list-functions
Keywords:
  mlr help list-keywords
Shorthands:
  mlr -g = mlr help flags
  mlr -l = mlr help list-verbs
  mlr -L = mlr help usage-verbs
  mlr -f = mlr help list-functions
  mlr -k = mlr help list-keywords`;
  if (topic === 'list-verbs') return [...VERBS].join('\n');
  if (topic === 'basic-examples') return `mlr --icsv --opprint cat example.csv
mlr --icsv --opprint sort -f shape example.csv
mlr --icsv --opprint sort -f shape -nr index example.csv
mlr --icsv --opprint cut -f flag,shape example.csv
mlr --csv filter '$color == "red"' example.csv
mlr --icsv --ojson put '$ratio = $quantity / $rate' example.csv
mlr --icsv --opprint --from example.csv sort -nr index then cut -f shape,quantity`;
  if (topic === 'file-formats') return `CSV/CSV-lite: comma-separated values with separate header line
TSV: same but with tabs in places of commas
JSON (array of objects)
JSON Lines (sequence of one-line objects)
PPRINT: pretty-printed tabular
DKVP: delimited key-value pairs (Miller default format)
NIDX: implicitly numerically indexed`;
  if (topic === 'flags' || topic === 'flag') return `FILE-FORMAT FLAGS
--csv, --icsv, --ocsv, --tsv, --itsv, --otsv, --dkvp, --idkvp, --odkvp,
--json, --ijson, --ojson, --jsonl, --ijsonl, --ojsonl, --opprint
--from {filename} Read input from filename before verbs.`;
  if (topic === 'verb' && args[1]) return verbHelp(args[1]);
  return `No help available for "${args.join(' ')}"`;
}

function verbHelp(v) {
  if (v === 'cut') return `cut
Usage: mlr cut [options]
Passes through input records with specified fields included/excluded.
Options:
 -f {a,b,c} Comma-separated field names for cut, e.g. a,b,c.
 -o Retain fields in the order specified here in the argument list.
 -x|--complement  Exclude, rather than include, field names specified by -f.
-h|--help Show this message.`;
  if (v === 'sort') return `sort
Usage: mlr sort {flags}
Sorts records primarily by the first specified field, secondarily by the second field, and so on.
Options:
-f fields lexical ascending
-r fields lexical descending
-n fields numerical ascending
-nr fields numerical descending
-h|--help Show this message.`;
  if (v === 'stats1') return `stats1
Usage: mlr stats1 [options]
Computes univariate statistics for one or more given fields, accumulated across the input record stream.
Options:
-a {sum,count,mean,min,max,...}
-f {a,b,c}
-g {d,e,f}`;
  return `${v}\nUsage: mlr ${v} [options]`;
}

function die(msg, code = 1) {
  console.error(msg);
  process.exit(code);
}

function parseArgs(argv) {
  const cfg = { ifmt: 'dkvp', ofmt: 'dkvp', headerlessIn: false, headerlessOut: false, files: [], verbs: [], fs: ',', ors: '\n' };
  let i = 0;
  while (i < argv.length) {
    const a = argv[i];
    if (a === '--csv' || a === '-c' || a === '--c2c') { cfg.ifmt = cfg.ofmt = 'csv'; i++; }
    else if (a === '--icsv') { cfg.ifmt = 'csv'; i++; }
    else if (a === '--ocsv') { cfg.ofmt = 'csv'; i++; }
    else if (a === '--tsv') { cfg.ifmt = cfg.ofmt = 'tsv'; i++; }
    else if (a === '--itsv') { cfg.ifmt = 'tsv'; i++; }
    else if (a === '--otsv') { cfg.ofmt = 'tsv'; i++; }
    else if (a === '--dkvp' || a === '--d2d') { cfg.ifmt = cfg.ofmt = 'dkvp'; i++; }
    else if (a === '--idkvp') { cfg.ifmt = 'dkvp'; i++; }
    else if (a === '--odkvp') { cfg.ofmt = 'dkvp'; i++; }
    else if (a === '--json') { cfg.ifmt = cfg.ofmt = 'json'; i++; }
    else if (a === '--ijson') { cfg.ifmt = 'json'; i++; }
    else if (a === '--ojson') { cfg.ofmt = 'json'; i++; }
    else if (a === '--jsonl') { cfg.ifmt = cfg.ofmt = 'jsonl'; i++; }
    else if (a === '--ijsonl') { cfg.ifmt = 'jsonl'; i++; }
    else if (a === '--ojsonl') { cfg.ofmt = 'jsonl'; i++; }
    else if (a === '--opprint' || a === '--pprint') { cfg.ofmt = 'pprint'; i++; }
    else if (a === '--ipprint') { cfg.ifmt = 'pprint'; i++; }
    else if (a === '--from') { cfg.files.push(argv[i + 1]); i += 2; }
    else if (a === '-N') { cfg.headerlessIn = cfg.headerlessOut = true; i++; }
    else if (a === '--implicit-csv-header' || a === '--headerless-csv-input' || a === '--hi') { cfg.headerlessIn = true; i++; }
    else if (a === '--headerless-csv-output' || a === '--ho') { cfg.headerlessOut = true; i++; }
    else if (a === '--fs' || a === '--ifs' || a === '--ofs') { cfg.fs = argv[i + 1]; i += 2; }
    else if (a === '--help' || a === '-h') { console.log(usage()); process.exit(0); }
    else if (a === '--version') { console.log(VERSION); process.exit(0); }
    else if (a === 'version') { console.log('mlr version 6.16.0 for linux/amd64/go1.24.0'); process.exit(0); }
    else if (a === 'help') { console.log(help(argv.slice(i + 1))); process.exit(0); }
    else break;
  }
  if (i >= argv.length) { console.log(usage()); process.exit(0); }
  while (i < argv.length) {
    const name = argv[i++];
    if (!VERBS.has(name)) { cfg.files.push(name, ...argv.slice(i)); break; }
    const opts = [];
    while (i < argv.length && argv[i] !== 'then') {
      if (VERBS.has(argv[i])) break;
      const tok = argv[i];
      if ((name === 'filter' || name === 'put') && opts.length === 0 && !tok.startsWith('-')) {
        opts.push(tok); i++; continue;
      }
      if (tok.startsWith('-')) {
        opts.push(tok); i++;
        if (optionTakesArg(tok) && i < argv.length && argv[i] !== 'then') opts.push(argv[i++]);
      } else {
        cfg.files.push(tok); i++;
      }
    }
    cfg.verbs.push({ name, opts });
    if (argv[i] === 'then') i++;
  }
  if (cfg.verbs.length === 0) cfg.verbs.push({ name: 'cat', opts: [] });
  return cfg;
}

function optionTakesArg(opt) {
  return !['-x', '--complement', '-o', '-b', '-s', '-i', '-v', '--help', '-h'].includes(opt);
}

function splitCSVLine(line, sep) {
  const out = [];
  let s = '', q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (q) {
      if (c === '"' && line[i + 1] === '"') { s += '"'; i++; }
      else if (c === '"') q = false;
      else s += c;
    } else {
      if (c === '"') q = true;
      else if (c === sep) { out.push(s); s = ''; }
      else s += c;
    }
  }
  out.push(s);
  return out;
}

function parseInput(text, cfg) {
  if (!text) return [];
  if (cfg.ifmt === 'csv' || cfg.ifmt === 'tsv') {
    const sep = cfg.ifmt === 'tsv' ? '\t' : ',';
    const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n').filter((l, idx, arr) => !(idx === arr.length - 1 && l === ''));
    if (lines.length === 0) return [];
    let headers, start;
    if (cfg.headerlessIn) { headers = splitCSVLine(lines[0], sep).map((_, i) => String(i + 1)); start = 0; }
    else { headers = splitCSVLine(lines[0], sep); start = 1; }
    return lines.slice(start).map(line => {
      const vals = splitCSVLine(line, sep);
      const r = {};
      vals.forEach((v, i) => { r[headers[i] || String(i + 1)] = v; });
      headers.slice(vals.length).forEach(h => { r[h] = ''; });
      return r;
    });
  }
  if (cfg.ifmt === 'json' || cfg.ifmt === 'jsonl') {
    if (cfg.ifmt === 'jsonl') return text.split(/\r?\n/).filter(Boolean).map(x => flatten(JSON.parse(x)));
    const obj = JSON.parse(text);
    return (Array.isArray(obj) ? obj : [obj]).map(flatten);
  }
  if (cfg.ifmt === 'pprint') {
    const lines = text.trimEnd().split(/\r?\n/);
    if (lines.length === 0) return [];
    const headers = lines[0].trim().split(/\s+/);
    return lines.slice(1).filter(Boolean).map(line => {
      const vals = line.trim().split(/\s+/);
      const r = {};
      vals.forEach((v, i) => { r[headers[i] || String(i + 1)] = v; });
      return r;
    });
  }
  return text.split(/\r?\n/).filter(Boolean).map(line => {
    const r = {};
    splitCSVLine(line, ',').forEach((part, idx) => {
      const eq = part.indexOf('=');
      if (eq >= 0) r[part.slice(0, eq)] = part.slice(eq + 1);
      else r[String(idx + 1)] = part;
    });
    return r;
  });
}

function flatten(obj, prefix = '', out = {}) {
  if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
    for (const [k, v] of Object.entries(obj)) flatten(v, prefix ? `${prefix}.${k}` : k, out);
  } else out[prefix] = obj == null ? '' : String(obj);
  return out;
}

function readAll(files) {
  if (!files || files.length === 0) return fs.readFileSync(0, 'utf8');
  return files.map(f => fs.readFileSync(f, 'utf8')).join('');
}

function keysUnion(records) {
  const seen = new Set(), keys = [];
  for (const r of records) for (const k of Object.keys(r)) if (!seen.has(k)) { seen.add(k); keys.push(k); }
  return keys;
}

function csvEscape(v, sep) {
  v = valueString(v);
  if (v.includes('"') || v.includes('\n') || v.includes('\r') || v.includes(sep)) return `"${v.replace(/"/g, '""')}"`;
  return v;
}

function valueString(v) {
  if (v == null) return '';
  return String(v);
}

function jsonValue(v) {
  if (v === '' || v == null) return '';
  if (/^-?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(String(v))) return Number(v);
  return String(v);
}

function formatOutput(records, cfg) {
  if (cfg.ofmt === 'json') {
    const objs = records.map(r => Object.fromEntries(Object.entries(r).map(([k, v]) => [k, jsonValue(v)])));
    if (objs.length === 0) return '[]\n';
    const chunks = objs.map(o => {
      const lines = JSON.stringify(o, null, 2).split('\n');
      return lines.join('\n');
    });
    return '[\n' + chunks.join(',\n') + '\n]\n';
  }
  if (cfg.ofmt === 'jsonl') return records.map(r => JSON.stringify(Object.fromEntries(Object.entries(r).map(([k, v]) => [k, jsonValue(v)])))).join('\n') + (records.length ? '\n' : '');
  if (cfg.ofmt === 'csv' || cfg.ofmt === 'tsv') {
    const sep = cfg.ofmt === 'tsv' ? '\t' : ',';
    const keys = keysUnion(records);
    const lines = [];
    if (!cfg.headerlessOut && keys.length) lines.push(keys.map(k => csvEscape(k, sep)).join(sep));
    for (const r of records) lines.push(keys.map(k => csvEscape(r[k] ?? '', sep)).join(sep));
    return lines.join('\n') + (lines.length ? '\n' : '');
  }
  if (cfg.ofmt === 'pprint') {
    const keys = keysUnion(records);
    if (keys.length === 0) return '';
    const widths = keys.map(k => Math.max(k.length, ...records.map(r => valueString(r[k] ?? '').length)));
    const line = arr => arr.map((v, i) => valueString(v).padEnd(widths[i])).join(' ').replace(/\s+$/, '');
    return [line(keys), ...records.map(r => line(keys.map(k => r[k] ?? '')))].join('\n') + '\n';
  }
  return records.map(r => Object.entries(r).map(([k, v]) => `${k}=${valueString(v)}`).join(',')).join('\n') + (records.length ? '\n' : '');
}

function getOpt(opts, names, def = null) {
  for (let i = 0; i < opts.length; i++) if (names.includes(opts[i])) return opts[i + 1] ?? def;
  return def;
}
function hasOpt(opts, names) { return opts.some(o => names.includes(o)); }
function splitFields(s) { return s ? s.split(',').filter(Boolean) : []; }

function applyVerb(records, verb) {
  const o = verb.opts;
  if (o.includes('--help') || o.includes('-h')) { console.log(verbHelp(verb.name)); process.exit(0); }
  switch (verb.name) {
    case 'cat': return records;
    case 'nothing': return [];
    case 'head': return records.slice(0, Number(getOpt(o, ['-n'], '10')));
    case 'tail': return records.slice(-Number(getOpt(o, ['-n'], '10')));
    case 'tac': return [...records].reverse();
    case 'cut': return cut(records, o);
    case 'sort': return sortRecords(records, o);
    case 'stats1': return stats1(records, o);
    case 'filter': return records.filter(r => evalExpr(o.join(' '), r));
    case 'put': return put(records, o.join(' '));
    case 'count': return count(records, o);
    case 'count-distinct': return countDistinct(records, o);
    case 'uniq': return uniq(records, o);
    case 'group-by': return groupBy(records, o);
    case 'label': return label(records, o);
    case 'rename': return rename(records, o);
    case 'reorder': return reorder(records, o);
    case 'regularize': return regularize(records);
    case 'skip-trivial-records': return records.filter(r => Object.values(r).some(v => v !== ''));
    case 'grep': return grep(records, o);
    default: return records;
  }
}

function cut(records, opts) {
  const fields = splitFields(getOpt(opts, ['-f'], ''));
  const comp = hasOpt(opts, ['-x', '--complement']);
  const order = hasOpt(opts, ['-o']);
  return records.map(r => {
    const out = {};
    const ks = order && !comp ? fields : Object.keys(r);
    for (const k of ks) {
      const inc = fields.includes(k);
      if ((!comp && inc && Object.prototype.hasOwnProperty.call(r, k)) || (comp && !inc)) out[k] = r[k];
    }
    return out;
  });
}

function sortRecords(records, opts) {
  const specs = [];
  for (let i = 0; i < opts.length; i++) {
    const flag = opts[i];
    if (['-f', '-r', '-n', '-nf', '-nr'].includes(flag)) {
      for (const f of splitFields(opts[++i])) specs.push({ f, flag });
    }
  }
  return records.map((r, i) => ({ r, i })).sort((a, b) => {
    for (const s of specs) {
      const av = a.r[s.f], bv = b.r[s.f];
      if (av == null && bv == null) continue;
      if (av == null) return 1;
      if (bv == null) return -1;
      let c;
      if (s.flag.startsWith('-n')) c = Number(av) - Number(bv);
      else c = String(av).localeCompare(String(bv));
      if (c !== 0) return (s.flag === '-r' || s.flag === '-nr') ? -Math.sign(c) : Math.sign(c);
    }
    return a.i - b.i;
  }).map(x => x.r);
}

function stats1(records, opts) {
  const accs = splitFields(getOpt(opts, ['-a'], 'count'));
  const fields = splitFields(getOpt(opts, ['-f'], ''));
  const groups = splitFields(getOpt(opts, ['-g'], ''));
  const buckets = new Map();
  for (const r of records) {
    const key = groups.map(g => r[g] ?? '').join('\x1f');
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(r);
  }
  const out = [];
  for (const [key, rows] of buckets) {
    const rec = {};
    groups.forEach((g, i) => { rec[g] = key.split('\x1f')[i]; });
    for (const f of fields) {
      const vals = rows.map(r => r[f]).filter(v => v !== undefined && v !== '');
      const nums = vals.map(Number).filter(n => !Number.isNaN(n));
      for (const a of accs) rec[`${f}_${a}`] = stat(a, vals, nums);
    }
    out.push(rec);
  }
  return out;
}

function stat(a, vals, nums) {
  if (a === 'count') return vals.length;
  if (a === 'sum') return nums.reduce((x, y) => x + y, 0);
  if (a === 'mean') return nums.length ? nums.reduce((x, y) => x + y, 0) / nums.length : '';
  if (a === 'min') return nums.length === vals.length ? Math.min(...nums) : vals.sort()[0] ?? '';
  if (a === 'max') return nums.length === vals.length ? Math.max(...nums) : vals.sort().slice(-1)[0] ?? '';
  if (a === 'distinct_count') return new Set(vals).size;
  if (a === 'mode' || a === 'antimode') {
    const m = new Map(); vals.forEach(v => m.set(v, (m.get(v) || 0) + 1));
    let best = '', bc = a === 'mode' ? -1 : Infinity;
    for (const v of vals) { const c = m.get(v); if ((a === 'mode' && c > bc) || (a === 'antimode' && c < bc)) { best = v; bc = c; } }
    return best;
  }
  if (/^p\d/.test(a) || a === 'median') {
    const p = a === 'median' ? 50 : Number(a.slice(1));
    nums.sort((x, y) => x - y);
    return nums.length ? nums[Math.ceil((p / 100) * nums.length) - 1] : '';
  }
  return '';
}

function evalExpr(expr, r) {
  if (!expr) return true;
  let js = expr.replace(/\$([A-Za-z_][A-Za-z0-9_.]*)/g, (_, k) => `field(r,${JSON.stringify(k)})`);
  js = js.replace(/\band\b/g, '&&').replace(/\bor\b/g, '||');
  try { return !!Function('r', 'field', `return (${js});`)(r, field); } catch { return false; }
}

function field(r, k) {
  const v = r[k];
  if (v == null) return '';
  if (/^-?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(String(v))) return Number(v);
  return v;
}

function put(records, expr) {
  const parts = expr.split(';').map(s => s.trim()).filter(Boolean);
  return records.map(r => {
    const out = { ...r };
    for (const p of parts) {
      const m = p.match(/^\$([A-Za-z_][A-Za-z0-9_.]*)\s*=\s*(.*)$/);
      if (!m) continue;
      let js = m[2].replace(/\$([A-Za-z_][A-Za-z0-9_.]*)/g, (_, k) => `field(out,${JSON.stringify(k)})`);
      try { out[m[1]] = Function('out', 'field', `return (${js});`)(out, field); } catch { out[m[1]] = ''; }
    }
    return out;
  });
}

function count(records, opts) {
  const groups = splitFields(getOpt(opts, ['-g'], ''));
  if (!groups.length) return [{ count: records.length }];
  const m = new Map();
  for (const r of records) {
    const k = groups.map(g => r[g] ?? '').join('\x1f');
    m.set(k, (m.get(k) || 0) + 1);
  }
  return [...m.entries()].map(([k, c]) => {
    const rec = {}; k.split('\x1f').forEach((v, i) => rec[groups[i]] = v); rec.count = c; return rec;
  });
}

function countDistinct(records, opts) {
  const fields = splitFields(getOpt(opts, ['-f'], ''));
  const groups = splitFields(getOpt(opts, ['-g'], ''));
  const m = new Map();
  for (const r of records) {
    const g = groups.map(x => r[x] ?? '').join('\x1f');
    if (!m.has(g)) m.set(g, new Set());
    m.get(g).add(fields.map(f => r[f] ?? '').join('\x1e'));
  }
  return [...m.entries()].map(([k, set]) => {
    const rec = {}; groups.forEach((g, i) => rec[g] = k.split('\x1f')[i]); rec.count = set.size; return rec;
  });
}

function uniq(records, opts) {
  const fields = splitFields(getOpt(opts, ['-f'], ''));
  const seen = new Set(), out = [];
  for (const r of records) {
    const ks = fields.length ? fields : Object.keys(r);
    const key = ks.map(k => `${k}=${r[k] ?? ''}`).join('\x1f');
    if (!seen.has(key)) { seen.add(key); out.push(r); }
  }
  return out;
}

function groupBy(records, opts) {
  const fields = splitFields(getOpt(opts, ['-f'], opts[0] || ''));
  return sortRecords(records, ['-f', fields.join(',')]);
}

function label(records, opts) {
  const names = splitFields(opts.join(','));
  return records.map(r => {
    const out = {}, vals = Object.values(r);
    vals.forEach((v, i) => out[names[i] || String(i + 1)] = v);
    return out;
  });
}

function rename(records, opts) {
  const pairs = splitFields(getOpt(opts, ['-f'], opts[0] || '')).map(x => x.split(',')).flat();
  const map = new Map();
  for (let i = 0; i + 1 < pairs.length; i += 2) map.set(pairs[i], pairs[i + 1]);
  return records.map(r => {
    const out = {};
    for (const [k, v] of Object.entries(r)) out[map.get(k) || k] = v;
    return out;
  });
}

function reorder(records, opts) {
  const fields = splitFields(getOpt(opts, ['-f'], ''));
  return records.map(r => {
    const out = {};
    for (const f of fields) if (f in r) out[f] = r[f];
    for (const [k, v] of Object.entries(r)) if (!(k in out)) out[k] = v;
    return out;
  });
}

function regularize(records) {
  const keys = keysUnion(records);
  return records.map(r => {
    const out = {};
    keys.forEach(k => { out[k] = r[k] ?? ''; });
    return out;
  });
}

function grep(records, opts) {
  const invert = hasOpt(opts, ['-v']);
  const pat = opts.filter(x => x !== '-v')[0] || '';
  const re = new RegExp(pat);
  return records.filter(r => invert !== re.test(Object.values(r).join(' ')));
}

function main() {
  const cfg = parseArgs(process.argv.slice(2));
  let records = parseInput(readAll(cfg.files), cfg);
  for (const v of cfg.verbs) records = applyVerb(records, v);
  process.stdout.write(formatOutput(records, cfg));
}

main();
