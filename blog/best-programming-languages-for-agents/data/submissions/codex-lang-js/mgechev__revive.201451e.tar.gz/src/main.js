#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = "a75b67b";
const COMMIT = "a75b67b73b9edb91dfc9f302dd108fa9d3ea5b05";
const VALID_FORMATTERS = new Set(["default", "json", "ndjson", "friendly", "stylish", "checkstyle", "sarif", "plain", "unix"]);

function usage() {
  return `
 _ __ _____   _(_)__  _____
| '__/ _ \\ \\ / / \\ \\ / / _ \\
| | |  __/\\ V /| |\\ V /  __/
|_|  \\___| \\_/ |_| \\_/ \\___|

Example:
  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...

Usage of ./executable:
  -config string
    \tpath to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)
  -exclude value
    \tlist of globs which specify files to be excluded (i.e. -exclude foo/...)
  -formatter string
    \tformatter to be used for the output (i.e. -formatter stylish)
  -max_open_files int
    \tmaximum number of open files at the same time
  -set_exit_status
    \tset exit status to 1 if any issues are found, overwrites errorCode and warningCode in config
  -version
    \tget revive version
`;
}

function parseArgs(argv) {
  const opts = { formatter: "default", excludes: [], setExitStatus: false, packages: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help" || a === "-h" || a === "help") opts.help = true;
    else if (a === "-version") opts.version = true;
    else if (a === "-set_exit_status") opts.setExitStatus = true;
    else if (a === "-config") opts.config = argv[++i] || "";
    else if (a.startsWith("-config=")) opts.config = a.slice(8);
    else if (a === "-formatter") opts.formatter = argv[++i] || "";
    else if (a.startsWith("-formatter=")) opts.formatter = a.slice(11);
    else if (a === "-exclude") opts.excludes.push(argv[++i] || "");
    else if (a.startsWith("-exclude=")) opts.excludes.push(a.slice(9));
    else if (a === "-max_open_files") i++;
    else if (a.startsWith("-max_open_files=")) {}
    else if (a.startsWith("-")) opts.unknown = a;
    else opts.packages.push(a);
  }
  return opts;
}

function parseConfig(file) {
  const cfg = { rules: new Map(), severity: "warning", confidence: 0.8, errorCode: 0, warningCode: 0 };
  if (!file) {
    const candidates = [];
    if (process.env.XDG_CONFIG_HOME) candidates.push(path.join(process.env.XDG_CONFIG_HOME, "revive.toml"));
    if (process.env.HOME) candidates.push(path.join(process.env.HOME, "revive.toml"));
    file = candidates.find((f) => fs.existsSync(f));
    if (!file) {
      cfg.defaultMissing = true;
      cfg.rules.set("var-naming", { severity: "warning" });
      return cfg;
    }
  }
  let text;
  try { text = fs.readFileSync(file, "utf8"); } catch (_) {
    throw new Error("cannot read the config file");
  }
  let currentRule = null;
  for (const raw of text.split(/\r?\n/)) {
    let line = raw.replace(/#.*/, "").trim();
    if (!line) continue;
    const sec = line.match(/^\[rule\.([A-Za-z0-9_-]+)\]$/);
    if (sec) {
      currentRule = sec[1];
      if (!cfg.rules.has(currentRule)) cfg.rules.set(currentRule, { severity: cfg.severity });
      continue;
    }
    const kv = line.match(/^([A-Za-z0-9_-]+)\s*=\s*(.+)$/);
    if (!kv) continue;
    let val = kv[2].trim().replace(/^"|"$/g, "");
    const key = kv[1];
    if (currentRule) {
      const r = cfg.rules.get(currentRule);
      if (/^disabled$/i.test(key) && /^true$/i.test(val)) cfg.rules.delete(currentRule);
      else if (key === "severity") r.severity = val;
      else if (key === "arguments") r.arguments = val;
    } else if (key === "severity") cfg.severity = val;
    else if (key === "confidence") cfg.confidence = Number(val) || cfg.confidence;
    else if (key === "errorCode") cfg.errorCode = Number(val) || 0;
    else if (key === "warningCode") cfg.warningCode = Number(val) || 0;
  }
  return cfg;
}

function walk(dir, out) {
  let ents;
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (_) { return; }
  for (const e of ents) {
    if (e.name === "vendor" || e.name === ".git") continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (e.isFile() && p.endsWith(".go")) out.push(p);
  }
}

function filesFromPackages(pkgs) {
  if (!pkgs.length) pkgs = ["."];
  const out = [];
  for (const p0 of pkgs) {
    const recursive = p0.endsWith("/...");
    const p = recursive ? p0.slice(0, -4) || "." : p0;
    let st;
    try { st = fs.statSync(p); } catch (_) { continue; }
    if (st.isFile() && p.endsWith(".go")) out.push(p);
    else if (st.isDirectory()) {
      if (recursive) walk(p, out);
      else for (const n of fs.readdirSync(p)) if (n.endsWith(".go")) out.push(path.join(p, n));
    }
  }
  return out.sort();
}

function globToRegex(glob) {
  let s = glob.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*\*/g, ".*").replace(/\*/g, "[^/]*");
  s = s.replace(/\/\.\.\./g, "(?:/.*)?");
  return new RegExp("^" + s + "$");
}

function isExcluded(file, patterns) {
  return patterns.some((p) => globToRegex(p).test(file) || globToRegex(p).test("./" + file));
}

function posFor(text, index) {
  const pre = text.slice(0, index);
  const parts = pre.split(/\n/);
  return { offset: index, line: parts.length, column: parts[parts.length - 1].length + 1 };
}

function issue(file, text, idx, endIdx, rule, msg, severity = "warning", category = "lint") {
  const s = posFor(text, idx);
  const e = posFor(text, endIdx == null ? idx : endIdx);
  return {
    Severity: severity,
    Failure: msg,
    RuleName: rule,
    Category: category,
    Position: {
      Start: { Filename: file, Offset: s.offset, Line: s.line, Column: s.column },
      End: { Filename: file, Offset: e.offset, Line: e.line, Column: e.column }
    },
    Confidence: 1,
    ReplacementLine: ""
  };
}

function lineStartOffsets(text) {
  const arr = [0];
  for (let i = 0; i < text.length; i++) if (text[i] === "\n") arr.push(i + 1);
  return arr;
}

function addLineIssue(list, file, text, starts, lineNo, col, rule, msg, sev, cat) {
  const idx = (starts[lineNo - 1] || 0) + col - 1;
  list.push(issue(file, text, idx, idx + 1, rule, msg, sev, cat));
}

function commentsBefore(lines, lineIdx) {
  for (let i = lineIdx - 1; i >= 0; i--) {
    const t = lines[i].trim();
    if (!t) continue;
    return t.startsWith("//") || t.startsWith("/*");
  }
  return false;
}

function disabledLines(text) {
  const disabled = new Set();
  const rulesByLine = new Map();
  const lines = text.split(/\r?\n/);
  let all = false;
  const ruleDisabled = new Set();
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/\/\/\s*revive:(disable|enable)(?:-next-line)?(?::([A-Za-z0-9_-]+))?/);
    if (!m) continue;
    const rule = m[2];
    if (m[0].includes("disable-next-line")) {
      const line = i + 2;
      if (rule) {
        if (!rulesByLine.has(line)) rulesByLine.set(line, new Set());
        rulesByLine.get(line).add(rule);
      } else disabled.add(line);
    } else if (m[1] === "disable") {
      if (rule) ruleDisabled.add(rule); else all = true;
    } else if (m[1] === "enable") {
      if (rule) ruleDisabled.delete(rule); else all = false;
    }
    if (all) disabled.add(i + 1);
    for (const r of ruleDisabled) {
      if (!rulesByLine.has(i + 1)) rulesByLine.set(i + 1, new Set());
      rulesByLine.get(i + 1).add(r);
    }
  }
  return { disabled, rulesByLine };
}

function lintFile(file, cfg) {
  const text = fs.readFileSync(file, "utf8");
  const lines = text.split(/\r?\n/);
  const starts = lineStartOffsets(text);
  const out = [];
  const has = (r) => cfg.rules.has(r);
  const sev = (r) => (cfg.rules.get(r) || {}).severity || cfg.severity || "warning";
  const pkg = text.match(/^\s*package\s+([A-Za-z_][A-Za-z0-9_]*)/m);

  if (has("package-comments") && pkg) {
    const lineIdx = text.slice(0, pkg.index).split(/\n/).length - 1;
    if (!commentsBefore(lines, lineIdx)) out.push(issue(file, text, pkg.index, pkg.index + pkg[0].length, "package-comments", "should have a package comment", sev("package-comments"), "comments"));
  }
  if (has("blank-imports") || has("dot-imports")) {
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const blank = line.match(/^\s*_\s+"[^"]+"/);
      const dot = line.match(/^\s*\.\s+"[^"]+"/);
      if (blank && has("blank-imports") && !(pkg && pkg[1] === "main") && !/\/\/|\/\*/.test(line)) addLineIssue(out, file, text, starts, i + 1, line.indexOf("_") + 1, "blank-imports", "a blank import should be only in a main or test package, or have a comment justifying it", sev("blank-imports"), "imports");
      if (dot && has("dot-imports")) addLineIssue(out, file, text, starts, i + 1, line.indexOf(".") + 1, "dot-imports", "should not use dot imports", sev("dot-imports"), "imports");
    }
  }
  if (has("exported")) {
    const re = /(^|\n)(func|type|var|const)\s+(?:\([^)]*\)\s*)?([A-Z][A-Za-z0-9_]*)/g;
    let m;
    while ((m = re.exec(text))) {
      const base = m.index + m[1].length;
      const idx = m[2] === "func" ? base : text.indexOf(m[3], base);
      const lineIdx = text.slice(0, idx).split(/\n/).length - 1;
      if (commentsBefore(lines, lineIdx)) continue;
      const kind = m[2] === "func" ? "function" : m[2];
      out.push(issue(file, text, idx, base + m[0].trim().length, "exported", `exported ${kind} ${m[3]} should have comment or be unexported`, sev("exported"), "comments"));
    }
  }
  if (has("increment-decrement")) {
    const re = /\b([A-Za-z_][A-Za-z0-9_]*)\s*\+=\s*1\b/g;
    let m; while ((m = re.exec(text))) out.push(issue(file, text, m.index, m.index + m[0].length, "increment-decrement", `should replace ${m[0]} with ${m[1]}++`, sev("increment-decrement"), "style"));
  }
  if (has("error-strings")) {
    const re = /return\s+(?:errors\.New\("([^"]*)"\)|fmt\.Errorf\("([^"]*)")/g;
    let m; while ((m = re.exec(text))) {
      const s = m[1] || m[2] || "";
      if (/^[A-Z]/.test(s) || /[.!?:]$/.test(s)) out.push(issue(file, text, m.index, m.index + m[0].length, "error-strings", "error strings should not be capitalized or end with punctuation or a newline", sev("error-strings"), "errors"));
    }
  }
  if (has("error-naming")) {
    const re = /\b(var|const)\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?:errors\.New|fmt\.Errorf)/g;
    let m; while ((m = re.exec(text))) {
      if (/^[a-z_]/.test(m[2]) && !/^err[A-Z_]/.test(m[2])) out.push(issue(file, text, m.index, m.index + m[0].length, "error-naming", `error var ${m[2]} should have name of the form errFoo`, sev("error-naming"), "errors"));
    }
  }
  if (has("empty-block")) {
    const re = /\{\s*\}/g;
    let m; while ((m = re.exec(text))) {
      const before = text.slice(Math.max(0, m.index - 30), m.index);
      if (/struct\s*$|interface\s*$/.test(before)) continue;
      out.push(issue(file, text, m.index + 1, m.index + 2, "empty-block", "this block is empty, you can remove it", sev("empty-block"), "style"));
    }
  }
  if (has("unreachable-code")) {
    for (let i = 0; i < lines.length - 1; i++) {
      if (/^\s*(return|panic\(|break|continue)\b/.test(lines[i]) && lines.slice(i + 1).find((l) => l.trim())) {
        const nextIdx = i + 1 + lines.slice(i + 1).findIndex((l) => l.trim());
        if (!/^\s*}/.test(lines[nextIdx])) addLineIssue(out, file, text, starts, i + 1, lines[i].search(/\S/) + 1, "unreachable-code", "unreachable code after this statement", sev("unreachable-code"), "logic");
      }
    }
  }
  if (has("unused-parameter")) {
    const re = /func\s+(?:[A-Za-z_][A-Za-z0-9_]*\s*)?\(([^)]*)\)/g;
    let m; while ((m = re.exec(text))) {
      const bodyStart = text.indexOf("{", re.lastIndex);
      const bodyEnd = bodyStart >= 0 ? text.indexOf("\n}", bodyStart) : -1;
      const body = bodyStart >= 0 ? text.slice(bodyStart, bodyEnd >= 0 ? bodyEnd : text.length) : "";
      for (const pm of m[1].split(",")) {
        const mm = pm.trim().match(/^([A-Za-z_][A-Za-z0-9_]*)\s+/);
        if (mm && mm[1] !== "_" && !new RegExp("\\b" + mm[1] + "\\b").test(body)) {
          const idx = text.indexOf(mm[1], m.index);
          out.push(issue(file, text, idx, idx + mm[1].length, "unused-parameter", `parameter '${mm[1]}' seems to be unused, consider removing or renaming it as _`, sev("unused-parameter"), "unused"));
        }
      }
    }
  }
  if (has("line-length-limit")) {
    const arg = (cfg.rules.get("line-length-limit").arguments || "").match(/\d+/);
    const limit = arg ? Number(arg[0]) : 80;
    lines.forEach((l, i) => { if (l.length > limit) addLineIssue(out, file, text, starts, i + 1, limit + 1, "line-length-limit", `line is ${l.length} characters`, sev("line-length-limit"), "style"); });
  }

  const dis = disabledLines(text);
  return out.filter((it) => !dis.disabled.has(it.Position.Start.Line) && !(dis.rulesByLine.get(it.Position.Start.Line) || new Set()).has(it.RuleName));
}

function sortIssues(issues, mode) {
  return issues.sort((a, b) => a.Position.Start.Filename.localeCompare(b.Position.Start.Filename) || a.Position.Start.Line - b.Position.Start.Line || a.Position.Start.Column - b.Position.Start.Column || a.RuleName.localeCompare(b.RuleName));
}

function xmlEscape(s) { return s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

function format(issues, formatter) {
  if (formatter === "json") return JSON.stringify(sortIssues(issues, formatter));
  if (formatter === "ndjson") return sortIssues(issues, formatter).map((i) => JSON.stringify(i)).join("\n") + (issues.length ? "\n" : "");
  if (formatter === "unix") return sortIssues(issues, formatter).map((i) => `${i.Position.Start.Filename}:${i.Position.Start.Line}:${i.Position.Start.Column}: [${i.RuleName}] ${i.Failure}`).join("\n") + (issues.length ? "\n" : "");
  if (formatter === "plain") return sortIssues(issues, formatter).map((i) => `${i.Position.Start.Filename}:${i.Position.Start.Line}:${i.Position.Start.Column}: ${i.Failure} https://revive.run/r#${i.RuleName}`).join("\n") + (issues.length ? "\n" : "");
  if (formatter === "checkstyle") {
    const by = new Map();
    for (const i of sortIssues(issues, formatter)) { if (!by.has(i.Position.Start.Filename)) by.set(i.Position.Start.Filename, []); by.get(i.Position.Start.Filename).push(i); }
    let s = "<?xml version='1.0' encoding='UTF-8'?>\n<checkstyle version=\"5.0\">\n";
    for (const [f, arr] of by) {
      s += `    <file name="${xmlEscape(f)}">\n`;
      for (const i of arr) s += `      <error line="${i.Position.Start.Line}" column="${i.Position.Start.Column}" message="${xmlEscape(i.Failure)} (confidence 1)" severity="${i.Severity}" source="revive/${i.RuleName}"/>\n`;
      s += "    </file>\n";
    }
    return s + "</checkstyle>\n";
  }
  if (formatter === "sarif") {
    return JSON.stringify({ version: "2.1.0", runs: [{ tool: { driver: { name: "revive" } }, results: sortIssues(issues, formatter).map((i) => ({ ruleId: i.RuleName, level: i.Severity === "error" ? "error" : "warning", message: { text: i.Failure }, locations: [{ physicalLocation: { artifactLocation: { uri: i.Position.Start.Filename }, region: { startLine: i.Position.Start.Line, startColumn: i.Position.Start.Column } } }] })) }] }, null, 2);
  }
  if (formatter === "stylish") {
    const by = new Map();
    for (const i of sortIssues(issues, formatter)) { if (!by.has(i.Position.Start.Filename)) by.set(i.Position.Start.Filename, []); by.get(i.Position.Start.Filename).push(i); }
    let s = "";
    for (const [f, arr] of by) {
      s += `${f}\n`;
      for (const i of arr) s += `  (${i.Position.Start.Line}, ${i.Position.Start.Column})  https://revive.run/r#${i.RuleName.padEnd(16)} ${i.Failure}\n`;
      s += "\n";
    }
    const e = issues.filter((i) => i.Severity === "error").length, w = issues.length - e;
    return s + `\n ✖ ${issues.length} problems (${e} errors) (${w} warnings)\n`;
  }
  if (formatter === "friendly") {
    let s = "";
    for (const i of sortIssues(issues, formatter)) s += `  ${i.Severity === "error" ? "✘" : "⚠"}  https://revive.run/r#${i.RuleName}  ${i.Failure}\n  ${i.Position.Start.Filename}:${i.Position.Start.Line}:${i.Position.Start.Column}\n\n`;
    const e = issues.filter((i) => i.Severity === "error").length, w = issues.length - e;
    s += `⚠ ${issues.length} problems (${e} errors, ${w} warnings)\n\n`;
    const counts = new Map();
    for (const i of issues) counts.set(i.RuleName, (counts.get(i.RuleName) || 0) + 1);
    if (w) s += "Warnings:\n" + [...counts].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).map(([k, v]) => `  ${v}  ${k}`).join("\n") + "\n";
    return s;
  }
  return sortIssues(issues, formatter).map((i) => `${i.Position.Start.Filename}:${i.Position.Start.Line}:${i.Position.Start.Column}: ${i.Failure}`).join("\n") + (issues.length ? "\n" : "");
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) { process.stdout.write(usage()); return 0; }
  if (opts.version) { process.stdout.write(`Version:\t${VERSION}\nCommit:\t\t${COMMIT}\nBuilt\t\t2026-04-17 19:59 UTC by build.sh\n`); return 0; }
  if (!VALID_FORMATTERS.has(opts.formatter)) { process.stderr.write(`formatting - getting formatter: unknown formatter ${opts.formatter}\n`); return 1; }
  let cfg;
  try { cfg = parseConfig(opts.config); } catch (e) { process.stderr.write(e.message + "\n"); return 1; }
  if (cfg.rules.has("var-naming")) {
    process.stderr.write('initializing revive - getting lint rules: cannot configure rule: "var-naming": load std packages: err: go command required, not found: exec: "go": executable file not found in $PATH: stderr: \n');
    return opts.config ? 1 : 0;
  }
  const files = filesFromPackages(opts.packages).filter((f) => !isExcluded(f, opts.excludes));
  let issues = [];
  for (const f of files) issues = issues.concat(lintFile(f, cfg));
  process.stdout.write(format(issues, opts.formatter));
  if (!issues.length) return 0;
  if (opts.setExitStatus) return 1;
  if (issues.some((i) => i.Severity === "error") && cfg.errorCode) return cfg.errorCode;
  if (cfg.warningCode) return cfg.warningCode;
  return 0;
}

process.exitCode = main();
