#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = 'rnr 0.5.1';

function out(s, opts = {}) {
  if (!opts.silent) process.stdout.write(s + '\n');
}
function err(s) { process.stderr.write(s + '\n'); }

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0 || args[0] === '--help' || args[0] === '-h') return helpTop();
  if (args[0] === '--version' || args[0] === '-V') { console.log(VERSION); return 0; }
  const cmd = args.shift();
  try {
    if (cmd === 'regex') return cmdRegex(args);
    if (cmd === 'to-ascii') return cmdAscii(args);
    if (cmd === 'from-file') return cmdFromFile(args);
    if (cmd === 'help') {
      if (!args[0]) return helpTop();
      if (args[0] === 'regex') return helpRegex();
      if (args[0] === 'to-ascii') return helpAscii();
      if (args[0] === 'from-file') return helpFromFile();
    }
    err(`error: unrecognized subcommand '${cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.`);
    return 2;
  } catch (e) {
    err(e && e.message ? e.message : String(e));
    return 1;
  }
}

function helpTop() {
  console.log(`RnR is a command-line tool to rename multiple files and directories that
supports regular expressions


Usage: executable <COMMAND>

Commands:
  regex      Rename files and directories using a regular expression
  from-file  Read operations from a dump file
  to-ascii   Replace file name UTF-8 chars with ASCII chars representation
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version`);
  return 0;
}

function commonOptsText(extra) {
  return `Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file${extra}
  -h, --help                       Print help`;
}

function helpRegex() {
  console.log(`Rename files and directories using a regular expression

Usage: executable regex [OPTIONS] <EXPRESSION> <REPLACEMENT> <PATH(S)>...

Arguments:
  <EXPRESSION>   Expression to match (can be a regex)
  <REPLACEMENT>  Expression replacement (use single quotes for capture groups)
  <PATH(S)>...   Target paths

Options:
  -n, --dry-run
          Only show what would be done (default mode)
  -f, --force
          Make actual changes to files
  -b, --backup
          Generate file backups before renaming
  -s, --silent
          Do not print any information
      --color <COLOR>
          Set color output mode [default: auto] [possible values: always, never, auto]
      --dump
          Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>
          Set the dump file prefix [default: rnr-]
      --no-dump
          Do not dump operations into a file
  -l, --replace-limit <LIMIT>
          Limit of replacements, all matches if set to 0
  -t, --replace-transform <REPLACE_TRANSFORM>
          Apply a transformation to replacements including captured groups [possible values: upper, lower, ascii]
  -D, --include-dirs
          Rename matching directories
  -r, --recursive
          Recursive mode
  -d, --max-depth <LEVEL>
          Set max depth in recursive mode
  -x, --hidden
          Include hidden files and directories
  -h, --help
          Print help`);
  return 0;
}

function helpFromFile() {
  console.log(`Read operations from a dump file

Usage: executable from-file [OPTIONS] <DUMPFILE>

Arguments:
  <DUMPFILE>  

${commonOptsText(`
  -u, --undo                       Undo the operations from the dump file`)}`);
  return 0;
}

function helpAscii() {
  console.log(`Replace file name UTF-8 chars with ASCII chars representation

Usage: executable to-ascii [OPTIONS] <PATH(S)>...

Arguments:
  <PATH(S)>...  Target paths

${commonOptsText(`
  -D, --include-dirs               Rename matching directories
  -r, --recursive                  Recursive mode
  -d, --max-depth <LEVEL>          Set max depth in recursive mode
  -x, --hidden                     Include hidden files and directories`)}`);
  return 0;
}

function parseCommon(args, spec) {
  const opts = { force:false, dryRun:true, backup:false, silent:false, dump:false, noDump:false,
    dumpPrefix:'rnr-', includeDirs:false, recursive:false, hidden:false, maxDepth:Infinity,
    replaceLimit:null, transform:null, undo:false };
  const pos = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '-h' || a === '--help') opts.help = true;
    else if (a === '-n' || a === '--dry-run') { opts.dryRun = true; opts.force = false; }
    else if (a === '-f' || a === '--force') { opts.force = true; opts.dryRun = false; }
    else if (a === '-b' || a === '--backup') opts.backup = true;
    else if (a === '-s' || a === '--silent') opts.silent = true;
    else if (a === '--dump') opts.dump = true;
    else if (a === '--no-dump') opts.noDump = true;
    else if (a === '--dump-prefix') opts.dumpPrefix = args[++i] || '';
    else if (a === '--color') i++;
    else if ((a === '-D' || a === '--include-dirs') && spec.tree) opts.includeDirs = true;
    else if ((a === '-r' || a === '--recursive') && spec.tree) opts.recursive = true;
    else if ((a === '-x' || a === '--hidden') && spec.tree) opts.hidden = true;
    else if ((a === '-d' || a === '--max-depth') && spec.tree) opts.maxDepth = Number(args[++i] || 0);
    else if ((a === '-l' || a === '--replace-limit') && spec.regex) opts.replaceLimit = Number(args[++i] || 0);
    else if ((a === '-t' || a === '--replace-transform') && spec.regex) opts.transform = args[++i];
    else if ((a === '-u' || a === '--undo') && spec.undo) opts.undo = true;
    else if (a.startsWith('-') && a !== '-') throw new Error(`error: unexpected argument '${a}' found`);
    else pos.push(a);
  }
  return {opts, pos};
}

function cmdRegex(args) {
  const {opts, pos} = parseCommon(args, {tree:true, regex:true});
  if (opts.help || pos.length < 3) return helpRegex() || (pos.length < 3 ? 2 : 0);
  const [expr, repl, ...targets] = pos;
  let re;
  try { re = new RegExp(expr, 'gu'); } catch (_) { re = new RegExp(expr, 'g'); }
  const ops = collect(targets, opts).map(p => {
    const base = path.basename(p);
    const next = replaceLimited(base, re, repl, opts);
    return next !== base ? {source:p, target:withDir(p, next)} : null;
  }).filter(Boolean);
  return perform(ops, opts);
}

function cmdAscii(args) {
  const {opts, pos} = parseCommon(args, {tree:true});
  if (opts.help || pos.length < 1) return helpAscii() || (pos.length < 1 ? 2 : 0);
  const ops = collect(pos, opts).map(p => {
    const base = path.basename(p);
    const next = toAscii(base);
    return next !== base ? {source:p, target:withDir(p, next)} : null;
  }).filter(Boolean);
  return perform(ops, opts);
}

function cmdFromFile(args) {
  const {opts, pos} = parseCommon(args, {undo:true});
  if (opts.help || pos.length !== 1) return helpFromFile() || (pos.length !== 1 ? 2 : 0);
  const data = JSON.parse(fs.readFileSync(pos[0], 'utf8'));
  let ops = (data.operations || []).map(o => opts.undo ? {source:o.target, target:o.source} : o);
  return perform(ops, opts);
}

function collect(targets, opts) {
  const res = [];
  const seen = new Set();
  function add(p, depth, explicit) {
    if (!explicit && !opts.hidden && path.basename(p).startsWith('.')) return;
    let st;
    try { st = fs.lstatSync(p); } catch (_) { return; }
    if (st.isDirectory()) {
      if (opts.recursive && depth < opts.maxDepth) {
        let names = [];
        try { names = fs.readdirSync(p); } catch (_) {}
        for (const n of names) add(joinDisplay(p, n), depth + 1, false);
      }
      if (opts.includeDirs) push(p);
    } else {
      push(p);
    }
  }
  function push(p) {
    if (!seen.has(p)) { seen.add(p); res.push(p); }
  }
  for (const t of targets) add(t, 0, true);
  return res;
}

function joinDisplay(parent, child) {
  if (parent === '.') return './' + child;
  if (parent.startsWith('./')) return './' + path.join(parent.slice(2), child);
  return path.join(parent, child);
}

function withDir(src, base) {
  const dir = path.dirname(src);
  if (src.startsWith('./') && dir === '.') return './' + base;
  if (src.startsWith('./') && dir.startsWith('./')) return './' + path.join(dir.slice(2), base);
  return path.join(dir, base);
}

function replaceLimited(str, re, repl, opts) {
  let count = 0;
  const lim = opts.replaceLimit === null ? 1 : opts.replaceLimit;
  re.lastIndex = 0;
  return str.replace(re, (...m) => {
    if (lim > 0 && count >= lim) return m[0];
    count++;
    let r = repl.replace(/\$(\d+)/g, (_, n) => m[Number(n)] || '');
    if (opts.transform === 'upper') r = r.toUpperCase();
    else if (opts.transform === 'lower') r = r.toLowerCase();
    else if (opts.transform === 'ascii') r = toAscii(r);
    return r;
  });
}

function toAscii(s) {
  const map = {
    'ß':'ss','ẞ':'SS','æ':'ae','Æ':'AE','œ':'oe','Œ':'OE','ø':'o','Ø':'O','ð':'d','Ð':'D',
    'þ':'th','Þ':'Th','ł':'l','Ł':'L','đ':'d','Đ':'D','ħ':'h','ı':'i','ĸ':'k','ŋ':'n','Ŋ':'N'
  };
  let r = '';
  for (const ch of s.normalize('NFKD')) {
    if (map[ch]) r += map[ch];
    else if (/[\u0300-\u036f]/u.test(ch)) {}
    else if (ch.charCodeAt(0) < 128) r += ch;
  }
  return r;
}

function perform(rawOps, opts) {
  const ops = rawOps.filter(o => o.source !== o.target);
  if (!ops.length) {
    if (opts.dryRun) out('This is a DRY-RUN', opts);
    maybeDump(ops, opts);
    return 0;
  }
  const targets = new Map();
  for (const o of ops) {
    const k = path.resolve(o.target);
    if (targets.has(k)) {
      out('This is a DRY-RUN', opts);
      err('Error: Files will have the same name\n');
      for (const x of ops) err(`${x.source}->${x.target}`);
      return 1;
    }
    targets.set(k, o.source);
  }
  if (opts.dryRun) out('This is a DRY-RUN', opts);
  if (!opts.force) {
    for (const o of ops) out(`${o.source} -> ${o.target}`, opts);
  } else {
    const ordered = ops.slice().sort((a, b) => depth(b.source) - depth(a.source));
    for (const o of ordered) {
      try {
        if (opts.backup) backup(o.source, opts);
        out(`${o.source} -> ${o.target}`, opts);
        fs.renameSync(o.source, o.target);
      } catch (e) {
        err(`Error: Cannot rename ${o.source} -> ${o.target}`);
        err(e.message);
        maybeDump(ops, opts);
        return 1;
      }
    }
  }
  maybeDump(ops, opts);
  return 0;
}

function depth(p) { return path.normalize(p).split(path.sep).length; }

function backup(src, opts) {
  let dst = src + '.bk';
  let i = 1;
  while (fs.existsSync(dst)) dst = src + `.bk${i++}`;
  fs.copyFileSync(src, dst);
  out(`Info:  Backup created - ${src} -> ${dst}`, opts);
}

function maybeDump(ops, opts) {
  if (opts.noDump) return;
  if (!opts.force && !opts.dump) return;
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  const name = `${opts.dumpPrefix}${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}.json`;
  const body = {
    date: `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`,
    operations: ops.map(o => ({source:o.source, target:o.target}))
  };
  fs.writeFileSync(name, JSON.stringify(body, null, 2) + '\n');
}

process.exitCode = main();
