#!/usr/bin/env node
const fs = require('fs');

function usage(){console.log(`Usage: executable [OPTIONS] [QUERY]

Arguments:
  [QUERY]
          The query

Options:
  -f, --file <FILE>
          Optionally reads from a file instead of Stdin

  -m, --format <FORMAT>
          DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output

  -o, --output <OUTPUT>
          Set output format. Options: 
          - \`json\`,
          - \`logfmt\`
          - \`format=<rust format string>\` (eg. -o format='{src} => {dst}'
          - \`legacy\` The original output format, auto aligning [k=v]

  -a, --alias-dir <ALIAS_DIR>
          Specifies an alternative directory to use for aliases. Defaults to \`.agrind-aliases\` in all parent directories.

      --no-alias
          Disables aliases

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

For more details + docs, see https://github.com/rcoh/angle-grinder`)}
function version(){console.log('ag 0.19.6')}

let args=process.argv.slice(2), file=null, output='legacy', query=null, aliasDir=null, noAlias=false;
for(let i=0;i<args.length;i++){
  let a=args[i];
  if(a==='-h'||a==='--help'){usage();process.exit(0)}
  if(a==='-V'||a==='--version'){version();process.exit(0)}
  if(a==='-f'||a==='--file'){file=args[++i];continue}
  if(a.startsWith('--file=')){file=a.slice(7);continue}
  if(a==='-o'||a==='--output'){output=args[++i];continue}
  if(a.startsWith('--output=')){output=a.slice(9);continue}
  if(a==='-m'||a==='--format'){output='format='+args[++i];continue}
  if(a.startsWith('--format=')){output='format='+a.slice(9);continue}
  if(a==='-a'||a==='--alias-dir'){aliasDir=args[++i];continue}
  if(a==='--no-alias'){noAlias=true;continue}
  if(!query) query=a; else query += ' '+a;
}
if(!query) query='*';
let input = file ? fs.readFileSync(file,'utf8') : fs.readFileSync(0,'utf8');
let lines = input.length? input.replace(/\r\n/g,'\n').replace(/\n$/,'').split('\n') : [];

function splitTop(s, sep=',') { let out=[], cur='', q=null, depth=0; for(let i=0;i<s.length;i++){let c=s[i]; if(q){cur+=c; if(c===q && s[i-1] !== '\\') q=null; continue} if(c==='"'||c==="'"){q=c;cur+=c;continue} if(c==='('||c==='['||c==='{') depth++; if(c===')'||c===']'||c==='}') depth--; if(c===sep && depth===0){out.push(cur.trim());cur=''} else cur+=c;} if(cur.trim()||s.endsWith(sep)) out.push(cur.trim()); return out;}
function splitPipe(s){let out=[],cur='',q=null; for(let i=0;i<s.length;i++){let c=s[i]; if(q){cur+=c;if(c===q&&s[i-1]!=='\\')q=null;continue} if(c==='"'||c==="'"){q=c;cur+=c;continue} if(c==='|'){out.push(cur.trim());cur=''} else cur+=c;} out.push(cur.trim()); return out;}
function unquote(s){s=s.trim(); if((s[0]==='"'&&s.at(-1)==='"')||(s[0]==="'"&&s.at(-1)==="'")) return s.slice(1,-1).replace(/\\"/g,'"').replace(/\\n/g,'\n'); return s;}
function valToString(v){ if(v===undefined||v===null) return 'None'; if(Array.isArray(v)) return '['+v.map(valToString).join(', ')+']'; if(typeof v==='object') return JSON.stringify(v); return String(v); }
function convert(v,noconvert=false){ if(v===undefined) return null; if(noconvert) return String(v); let s=String(v); if(s==='') return ''; if(/^[-+]?\d+$/.test(s)) return Number(s); if(/^[-+]?(\d+\.\d*|\d*\.\d+)([eE][-+]?\d+)?$/.test(s)||/^[-+]?\d+[eE][-+]?\d+$/.test(s)) return Number(s); if(s==='true')return true; if(s==='false')return false; if(s==='null'||s==='None') return null; return s;}
function flatten(obj,prefix='',out={}){ if(obj&&typeof obj==='object'&&!Array.isArray(obj)){ for(let k of Object.keys(obj)){ let key=prefix?prefix+'.'+k:k; if(obj[k]&&typeof obj[k]==='object'&&!Array.isArray(obj[k])) flatten(obj[k],key,out); else out[key]=obj[k]; }} return out; }
function getField(row, path){ if(path==='_raw') return row._raw; path=path.trim(); if(path.startsWith('["')) path=path.slice(2,-2); let cur=row.fields; let re=/([^\.\[\]]+)|(\[(-?\d+)\])/g, m; while((m=re.exec(path))){ if(m[1]){ if(cur&&Object.prototype.hasOwnProperty.call(cur,m[1])) cur=cur[m[1]]; else return null; } else { let idx=Number(m[3]); if(!Array.isArray(cur)) return null; if(idx<0) idx=cur.length+idx; cur=cur[idx]; }} return cur===undefined?null:cur;}
function setField(row,k,v){row.fields[k.trim()]=v}

function tokenizeExpr(s){let re=/\s*(=>|==|!=|<>|<=|>=|&&|\|\||[()+\-*\/,!<>]|"(?:\\.|[^"])*"|'(?:\\.|[^'])*'|\d+\.\d+|\d+|\["[^"]+"\]|[A-Za-z_][A-Za-z0-9_\.\[\]-]*)/g; let a=[],m; while((m=re.exec(s))){a.push(m[1])} return a;}
function evalExpr(expr,row){
  expr=expr.trim();
  const funcs={abs:Math.abs,acos:Math.acos,asin:Math.asin,atan:Math.atan,atan2:Math.atan2,cbrt:Math.cbrt,ceil:Math.ceil,cos:Math.cos,cosh:Math.cosh,exp:Math.exp,expm1:Math.expm1,floor:Math.floor,hypot:Math.hypot,log:Math.log,log10:Math.log10,log1p:Math.log1p,round:Math.round,sin:Math.sin,sinh:Math.sinh,sqrt:Math.sqrt,tan:Math.tan,tanh:Math.tanh,toDegrees:x=>Number(x)*180/Math.PI,toRadians:x=>Number(x)*Math.PI/180,concat:(...a)=>a.map(valToString).join(''),contains:(a,b)=>String(a??'').includes(String(b??'')),length:a=>String(a??'').length,now:()=>new Date().toISOString(),num:a=>Number(a),parseDate:a=>new Date(a).toISOString(),parseHex:a=>parseInt(String(a),16),substring:(s,a,b)=>String(s??'').substring(Number(a),b===undefined?undefined:Number(b)),toLowerCase:s=>String(s??'').toLowerCase(),toUpperCase:s=>String(s??'').toUpperCase(),isNull:v=>v==null,isEmpty:v=>v==null||v==='',isBlank:v=>v==null||String(v).trim()==='',isNumeric:v=>v!==null&&v!==''&&!isNaN(Number(v)),if:(c,a,b)=>c?a:b};
  let toks=tokenizeExpr(expr), js=[];
  for(let i=0;i<toks.length;i++){let t=toks[i]; let low=t.toLowerCase();
    if(low==='and') js.push('&&'); else if(low==='or') js.push('||'); else if(t==='<>') js.push('!=');
    else if(/^['"]/.test(t)||/^\d/.test(t)||['(',')','+','-','*','/','<','>','<=','>=','==','!=','&&','||','!',','].includes(t)) js.push(t);
    else if(t.startsWith('["')) js.push(`get(${JSON.stringify(t)})`);
    else if(toks[i+1]==='(') js.push(t==='if'?'iff':`funcs[${JSON.stringify(t)}]`);
    else js.push(`get(${JSON.stringify(t)})`);
  }
  try { const get=(p)=>getField(row,p); const iff=funcs.if; return Function('get','funcs','iff',`return (${js.join(' ')});`)(get,funcs,iff); } catch(e){ return null; }
}

function parseLogfmt(s){ let obj={}; let re=/([^\s=]+)(?:=([^\s"]+|"(?:\\.|[^"])*"))?/g,m,any=false; while((m=re.exec(s))){ any=true; let v=m[2]; if(v===undefined) v=null; else {v=unquote(v); v=convert(v);} obj[m[1]]=v; } return any?obj:null; }
function patternToRegex(p){ let names=[]; let rx='^'; let parts=p.split('*'); for(let i=0;i<parts.length;i++){ rx+=parts[i].replace(/[.*+?^${}()|[\]\\]/g,'\\$&').replace(/\s+/g,'\\s+'); if(i<parts.length-1){names.push(null); rx+='(.*)';}} rx+='$'; return {rx:new RegExp(rx), count:names.length};}
function regexFromRust(r){ return r.replace(/\(\?P<([A-Za-z_][A-Za-z0-9_]*)>/g,'(?<$1>'); }

function loadAliases(){
  if(noAlias) return {};
  let dirs=[];
  if(aliasDir) dirs.push(aliasDir);
  else {
    let d=process.cwd();
    while(true){ dirs.push(d+'/.agrind-aliases'); let nd=require('path').dirname(d); if(nd===d) break; d=nd; }
  }
  let aliases={};
  for(let d of dirs){
    try{
      for(let f of fs.readdirSync(d)){
        let txt=fs.readFileSync(require('path').join(d,f),'utf8');
        let km=txt.match(/keyword\s*=\s*"([^"]+)"/);
        let tm=txt.match(/template\s*=\s*"""([\s\S]*?)"""/) || txt.match(/template\s*=\s*"([^"]*)"/);
        if(km&&tm) aliases[km[1]]=tm[1].trim();
      }
    }catch(e){}
  }
  return aliases;
}
let parts=splitPipe(query), filter=parts.shift()||'*';
let aliases=loadAliases();
parts=parts.flatMap(p=>aliases[p.trim()] ? splitPipe(aliases[p.trim()]) : [p]);
let rows=lines.filter(l=>matchFilter(filter,l)).map(l=>({_raw:l, fields:{}}));
function filterTokens(s){
  let out=[], i=0;
  while(i<s.length){
    if(/\s/.test(s[i])){i++; continue;}
    if(s[i]==='('||s[i]===')'){out.push(s[i++]); continue;}
    if(s[i]==='"'){
      let j=i+1, v='';
      while(j<s.length){ if(s[j]==='"'&&s[j-1] !== '\\') break; v+=s[j++]; }
      out.push({type:'lit', v:v.replace(/\\"/g,'"')}); i=j+1; continue;
    }
    let j=i; while(j<s.length && !/\s|\(|\)/.test(s[j])) j++;
    let w=s.slice(i,j), u=w.toUpperCase();
    if(u==='AND'||u==='OR'||u==='NOT') out.push(u); else out.push({type:'wild', v:w});
    i=j;
  }
  return out;
}
function matchFilter(f,line){
  f=f.trim(); if(f==='*'||f==='') return true;
  const toks=filterTokens(f); let pos=0;
  const lit=s=>line.includes(s);
  const wild=p=>{let pat=p.replace(/[.+?^${}()|[\]\\]/g,'\\$&').replace(/\*/g,'.*'); return new RegExp(pat,'i').test(line)};
  function primary(){ let t=toks[pos++]; if(t==='('){let v=orExpr(); if(toks[pos]===')') pos++; return v;} if(t==='NOT') return !primary(); if(!t) return false; return t.type==='lit'?lit(t.v):wild(t.v); }
  function andExpr(){ let v=primary(); while(toks[pos]==='AND') {pos++; v=primary()&&v;} return v; }
  function orExpr(){ let v=andExpr(); while(toks[pos]==='OR') {pos++; v=andExpr()||v;} return v; }
  try{return !!orExpr();} catch(e){return line.toLowerCase().includes(f.replace(/\*/g,'').toLowerCase());}
}
let aggregateSpec=null, sortSpec=null;
for(let op of parts){ if(!op) continue;
  if(op==='json'||op.startsWith('json ')){ let m=op.match(/^json(?:\s+from\s+(.+))?/); rows=rows.flatMap(r=>{let src=m&&m[1]?getField(r,m[1]):r._raw; try{let o=JSON.parse(String(src)); return [{_raw:r._raw,fields:{...r.fields,...flatten(o)}}]}catch(e){return []}}); continue; }
  if(op==='logfmt'||op.startsWith('logfmt ')){ let m=op.match(/^logfmt(?:\s+from\s+(.+))?/); rows=rows.flatMap(r=>{let src=m&&m[1]?getField(r,m[1]):r._raw; let o=parseLogfmt(String(src)); return o?[{_raw:r._raw,fields:{...r.fields,...o}}]:[]}); continue; }
  if(op.startsWith('parse regex ')){ let m=op.match(/^parse\s+regex\s+(["'])(.*?)\1(?:\s+from\s+([^\s]+))?(.*)$/); if(m){let re=new RegExp(regexFromRust(m[2])); let nodrop=/\bnodrop\b/.test(m[4]); rows=rows.flatMap(r=>{let src=m[3]?getField(r,m[3]):r._raw; let mm=re.exec(String(src)); if(!mm) return nodrop?[r]:[]; let nf={...r.fields}; for(let [k,v] of Object.entries(mm.groups||{})) nf[k]=convert(v); return [{_raw:r._raw,fields:nf}]});} continue; }
  if(op.startsWith('parse ')){ let m=op.match(/^parse\s+(["'])(.*?)\1(?:\s+from\s+([^\s]+))?\s+as\s+(.+)$/); if(m){let tail=m[4], nodrop=/\bnodrop\b/.test(tail), noconvert=/\bnoconvert\b/.test(tail); tail=tail.replace(/\b(nodrop|noconvert)\b/g,'').trim(); let names=splitTop(tail).map(x=>x.trim()).filter(Boolean); let pr=patternToRegex(m[2]); rows=rows.flatMap(r=>{let src=m[3]?getField(r,m[3]):r._raw; let mm=pr.rx.exec(String(src)); if(!mm) return nodrop?[r]:[]; let nf={...r.fields}; for(let i=0;i<names.length;i++) nf[names[i]]=convert(mm[i+1]??'',noconvert); return [{_raw:r._raw,fields:nf}]});} continue; }
  if(op.startsWith('split')){ let m=op.match(/^split(?:\(([^)]*)\))?(?:\s+on\s+(["'])(.*?)\2)?(?:\s+as\s+(.+))?/); if(m){let inp=m[1], sep=m[3]??',', out=(m[4]||inp||'_split').trim(); rows=rows.map(r=>{let src=inp?getField(r,inp):r._raw; return {_raw:r._raw,fields:{...r.fields,[out]:String(src??'').split(sep).map(x=>x.trim()).filter(x=>x!==''||sep!== ' ')}}});} continue; }
  if(op.startsWith('fields')){ let rest=op.replace(/^fields\s*/,'').trim(); let mode='except'; if(rest.startsWith('+')||rest.startsWith('only')){mode='only'; rest=rest.replace(/^(\+|only)\s*/,'')} else if(rest.startsWith('-')||rest.startsWith('except')){mode='except'; rest=rest.replace(/^(\-|except)\s*/,'')} let names=splitTop(rest).map(x=>x.trim()); rows=rows.map(r=>{let nf={}; if(mode==='only'){for(let n of names) nf[n]=getField(r,n)} else {nf={...r.fields}; for(let n of names) delete nf[n]} return {_raw:r._raw,fields:nf}}); continue; }
  if(op.startsWith('where ')){ let e=op.slice(6); rows=rows.filter(r=>!!evalExpr(e,r)); continue; }
  if(op.startsWith('limit ')){ let n=Number(op.slice(6).trim()); rows=n>=0?rows.slice(0,n):rows.slice(n); continue; }
  if(op.startsWith('sort by ')){ sortSpec=op.slice(8).trim(); continue; }
  let asMatch=op.match(/^(.*?)\s+as\s+([A-Za-z_][A-Za-z0-9_]*)$/); if(asMatch && !/^(count|sum|min|max|average|avg|p\d+|pct\d+|count_distinct|total)\b/.test(op)){ let e=asMatch[1], name=asMatch[2]; rows=rows.map(r=>{let nf={...r.fields}; nf[name]=evalExpr(e,r); return {_raw:r._raw,fields:nf}}); continue; }
  if(/^(count|sum|min|max|average|avg|p\d+|pct\d+|count_distinct|total)\b/.test(op)){ aggregateSpec=op; continue; }
}

if(aggregateSpec){ rows=aggregate(rows,aggregateSpec); rows.sort((a,b)=>{let ak=Object.values(a.fields), bk=Object.values(b.fields); for(let i=0;i<Math.min(ak.length,bk.length);i++){ if(ak[i]<bk[i]) return -1; if(ak[i]>bk[i]) return 1;} return ak.length-bk.length;}); }
if(sortSpec){ let desc=/\bdesc\b/i.test(sortSpec), asc=/\basc\b/i.test(sortSpec); let exprs=splitTop(sortSpec.replace(/\b(asc|desc)\b/ig,'').trim()); rows.sort((a,b)=>{for(let e of exprs){let av=evalExpr(e,a), bv=evalExpr(e,b); if(av==null) av=getField(a,e); if(bv==null) bv=getField(b,e); if(av<bv) return desc?1:-1; if(av>bv) return desc?-1:1;} return 0;}); }

function aggregate(inRows,spec){ let by=[]; let bm=spec.match(/\s+by\s+(.+)$/); if(bm){by=splitTop(bm[1]).map(s=>s.trim()); spec=spec.slice(0,bm.index).trim();}
 let ags=splitTop(spec).map(s=>{let name=null; let m=s.match(/^(.*?)\s+as\s+([A-Za-z_][A-Za-z0-9_]*)$/); if(m){s=m[1].trim(); name=m[2];} let f=s.match(/^([A-Za-z_][A-Za-z0-9_]*|p\d+|pct\d+)(?:\((.*)\))?$/); return {raw:s,fn:f?f[1]:'count',arg:f?f[2]:null,name};});
 let groups=new Map(); for(let r of inRows){let keyVals=by.map(b=>evalExpr(b,r)??getField(r,b)); let key=JSON.stringify(keyVals); if(!groups.has(key)) groups.set(key,{keyVals, rows:[]}); groups.get(key).rows.push(r);} if(by.length===0&&!groups.size) groups.set('[]',{keyVals:[],rows:[]});
 let out=[]; for(let g of groups.values()){let fields={}; by.forEach((b,i)=>fields[b]=g.keyVals[i]); for(let a of ags){let fn=a.fn, arg=a.arg; let col=a.name || (fn==='count'?'_count':fn==='sum'?'_sum':fn==='average'||fn==='avg'?'_average':fn==='min'?'_min':fn==='max'?'_max':fn.startsWith('pct')?'p'+fn.slice(3):fn==='count_distinct'?'_count_distinct':fn); if(fn==='count'){ if(arg) fields[col]=g.rows.filter(r=>!!evalExpr(arg,r)).length; else fields[col]=g.rows.length; } else if(fn==='sum'||fn==='min'||fn==='max'||fn==='average'||fn==='avg'||/^p\d+$/.test(fn)||/^pct\d+$/.test(fn)){ let vals=g.rows.map(r=>Number(evalExpr(arg,r)??getField(r,arg))).filter(Number.isFinite).sort((a,b)=>a-b); if(fn==='sum') fields[col]=vals.reduce((x,y)=>x+y,0); else if(fn==='min') fields[col]=vals.length?vals[0]:null; else if(fn==='max') fields[col]=vals.length?vals.at(-1):null; else if(fn==='average'||fn==='avg') fields[col]=vals.length?vals.reduce((x,y)=>x+y,0)/vals.length:null; else {let p=Number(fn.replace(/\D/g,'')); let idx=Math.max(0,Math.ceil(vals.length*p/100)-1); fields[col]=vals.length?vals[idx]:null;} } else if(fn==='count_distinct'){let set=new Set(g.rows.map(r=>valToString(evalExpr(arg,r)??getField(r,arg)))); fields[col]=set.size;} else if(fn==='total'){let sum=0; for(let r of g.rows){let v=Number(evalExpr(arg,r)??getField(r,arg)); if(Number.isFinite(v)) sum+=v;} fields[col]=sum;} }
 out.push({_raw:'',fields}); } return out; }

function emit(rows){ if(output==='json'){ for(let r of rows) console.log(JSON.stringify(r.fields)); return;} if(output==='logfmt'){ for(let r of rows) console.log(Object.keys(r.fields).sort().map(k=>`${k}=${valToString(r.fields[k])}`).join(' ')); return;} if(output.startsWith('format=')){let fmt=output.slice(7); for(let r of rows) console.log(fmt.replace(/\{([^}]+)\}/g,(_,k)=>valToString(getField(r,k)))); return;}
 let hasFields=rows.some(r=>Object.keys(r.fields).length); if(!hasFields){for(let r of rows) console.log(r._raw); return;} if(rows.length && rows.every(r=>r._raw==='' )) return table(rows); for(let r of rows){let ks=Object.keys(r.fields).sort(); console.log(ks.map(k=>('['+k+'='+valToString(r.fields[k])+']').padEnd(Math.max(8, k.length+valToString(r.fields[k]).length+4))).join('        '));}}
function table(rows){ let cols=[]; for(let r of rows) for(let k of Object.keys(r.fields)) if(!cols.includes(k)) cols.push(k); let widths=cols.map(c=>Math.max(c.length,...rows.map(r=>valToString(r.fields[c]).length))); console.log(cols.map((c,i)=>c.padEnd(widths[i])).join('        ')); console.log('-'.repeat(Math.max(14, widths.reduce((a,b)=>a+b,0)+8*(cols.length-1)))); for(let r of rows) console.log(cols.map((c,i)=>valToString(r.fields[c]).padEnd(widths[i])).join('        '));}
emit(rows);
