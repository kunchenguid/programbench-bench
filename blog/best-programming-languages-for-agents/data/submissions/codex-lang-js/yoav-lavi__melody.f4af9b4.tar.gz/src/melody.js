#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = 'melody_cli 0.20.0';

function help() {
  return `A CLI wrapping the Melody language compiler

Usage: executable [OPTIONS] [INPUT_FILE_PATH]

Arguments:
  [INPUT_FILE_PATH]  Read from a file
                     Use '-' and or pipe input to read from stdin

Options:
  -o, --output <OUTPUT_FILE_PATH>           Write to a file
  -n, --no-color                            Print output with no color
  -r, --repl                                Start the Melody REPL
      --generate-completions <completions>  Outputs completions for the selected shell
                                            To use, write the output to the appropriate location for your shell
  -t, --test <test>                         Test the compiled regex against a string
  -f, --test-file <test-file>               Test the compiled regex against the contents of a file
  -h, --help                                Print help
  -V, --version                             Print version`;
}

function completion(shell) {
  const opts = '-o --output -n --no-color -r --repl --generate-completions -t --test -f --test-file -h --help -V --version';
  if (shell === 'fish') {
    return opts.split(' ').map(o => `complete -c melody -l ${o.replace(/^--?/, '')}`).join('\n') + '\n';
  }
  if (shell === 'zsh') {
    return '#compdef melody\n_arguments "*:file:_files" "-o[output]" "--output[output]" "-n[no color]" "--no-color" "-r[repl]" "--generate-completions" "-t[test]" "--test" "-f[test file]" "--test-file" "-h[help]" "--help" "-V[version]" "--version"\n';
  }
  return `_melody() {
    local cur
    COMPREPLY=()
    cur="\${COMP_WORDS[COMP_CWORD]}"
    COMPREPLY=( $(compgen -W "${opts}" -- "$cur") )
}
complete -F _melody melody
`;
}

class ParseError extends Error {
  constructor(message, pos) {
    super(message);
    this.pos = pos || 0;
  }
}

class Parser {
  constructor(input) {
    this.s = input;
    this.i = 0;
  }

  eof() {
    this.skip();
    return this.i >= this.s.length;
  }

  skip() {
    for (;;) {
      while (this.i < this.s.length && /\s/.test(this.s[this.i])) this.i++;
      if (this.s.startsWith('//', this.i)) {
        this.i += 2;
        while (this.i < this.s.length && this.s[this.i] !== '\n') this.i++;
        continue;
      }
      if (this.s.startsWith('/*', this.i)) {
        const end = this.s.indexOf('*/', this.i + 2);
        this.i = end < 0 ? this.s.length : end + 2;
        continue;
      }
      break;
    }
  }

  word(w) {
    this.skip();
    if (!this.s.startsWith(w, this.i)) return false;
    const before = this.i > 0 ? this.s[this.i - 1] : '';
    const after = this.s[this.i + w.length] || '';
    if (/[A-Za-z0-9_-]/.test(before) || /[A-Za-z0-9_-]/.test(after)) return false;
    this.i += w.length;
    return true;
  }

  char(c) {
    this.skip();
    if (this.s[this.i] === c) {
      this.i++;
      return true;
    }
    return false;
  }

  number() {
    this.skip();
    const m = /^[0-9]+/.exec(this.s.slice(this.i));
    if (!m) return null;
    this.i += m[0].length;
    return Number(m[0]);
  }

  ident() {
    this.skip();
    const m = /^[A-Za-z_][A-Za-z0-9_-]*/.exec(this.s.slice(this.i));
    if (!m) return null;
    this.i += m[0].length;
    return m[0];
  }

  parseRoot(untilBrace = false) {
    let out = '';
    this.skip();
    while (this.i < this.s.length) {
      this.skip();
      if (untilBrace && this.s[this.i] === '}') break;
      if (this.i >= this.s.length) break;
      out += this.expr();
      this.char(';');
      this.skip();
    }
    return out;
  }

  expr() {
    this.skip();
    const pos = this.i;
    let q = this.quantifier();
    if (q) return this.applyQuant(this.atom(), q);
    if (this.word('not')) return this.negated();
    return this.atom(pos);
  }

  quantifier() {
    const save = this.i;
    if (this.word('some')) {
      if (this.word('of')) return '+';
    } else if (this.word('any')) {
      if (this.word('of')) return '*';
    } else if (this.word('option')) {
      if (this.word('of')) return '?';
    } else if (this.word('over')) {
      const n = this.number();
      if (n !== null && this.word('of')) return `{${n + 1},}`;
    } else {
      const n = this.number();
      if (n !== null) {
        const save2 = this.i;
        if (this.word('to')) {
          const m = this.number();
          if (m !== null && this.word('of')) {
            if (n > m) throw new Error('usage of an invalid quantifier range');
            return `{${n},${m}}`;
          }
        }
        this.i = save2;
        if (this.word('of')) return `{${n}}`;
      }
    }
    this.i = save;
    return null;
  }

  atom(posForError) {
    this.skip();
    if (this.s[this.i] === '"' || this.s[this.i] === "'") return escapeRegex(this.quoted(this.s[this.i]));
    if (this.s[this.i] === '`') return this.quoted('`');
    if (this.s[this.i] === '<') return this.symbol(false);
    if (this.word('match')) return '(?:' + this.block() + ')';
    if (this.word('either')) return '(?:' + this.alternatives() + ')';
    if (this.word('capture')) {
      const name = this.ident();
      const body = this.block();
      return name ? `(?<${name}>${body})` : `(${body})`;
    }
    if (this.word('ahead')) return '(?=' + this.block() + ')';
    if (this.word('behind')) return '(?<=' + this.block() + ')';
    throw new ParseError('expected root', posForError ?? this.i);
  }

  negated() {
    this.skip();
    if (this.word('ahead')) return '(?!' + this.block() + ')';
    if (this.word('behind')) return '(?<!' + this.block() + ')';
    if (this.s[this.i] === '<') return this.symbol(true);
    throw new ParseError('expected amount, class_content, or assertion_type', this.i);
  }

  block() {
    if (!this.char('{')) throw new ParseError('expected block', this.i);
    const body = this.parseRoot(true);
    if (!this.char('}')) throw new ParseError('expected }', this.i);
    return body;
  }

  alternatives() {
    if (!this.char('{')) throw new ParseError('expected block', this.i);
    const parts = [];
    this.skip();
    while (this.i < this.s.length && this.s[this.i] !== '}') {
      parts.push(this.expr());
      this.char(';');
      this.skip();
    }
    if (!this.char('}')) throw new ParseError('expected }', this.i);
    return parts.join('|');
  }

  quoted(q) {
    let out = '';
    const start = this.i;
    this.i++;
    while (this.i < this.s.length) {
      const c = this.s[this.i++];
      if (c === q) return out;
      if (c === '\\' && this.i < this.s.length) {
        const n = this.s[this.i++];
        const map = { n: '\n', r: '\r', t: '\t', f: '\f', v: '\v', 0: '\0' };
        out += Object.prototype.hasOwnProperty.call(map, n) ? map[n] : n;
      } else {
        out += c;
      }
    }
    throw new ParseError('expected root', start);
  }

  symbol(neg) {
    const start = this.i;
    const end = this.s.indexOf('>', this.i + 1);
    if (end < 0) throw new ParseError('expected symbol', start);
    const name = this.s.slice(this.i + 1, end).trim();
    this.i = end + 1;
    const positive = {
      char: '.', space: ' ', whitespace: '\\s', digit: '\\d', word: '\\w',
      newline: '\\n', tab: '\\t', return: '\\r', feed: '\\f', null: '\\0',
      boundary: '\\b', backspace: '[\\b]', start: '^', end: '$',
      alphabetic: '[a-zA-Z]', alphanumeric: '[a-zA-Z0-9]'
    };
    const negative = {
      space: '[^ ]', whitespace: '\\S', digit: '\\D', word: '\\W',
      newline: '[^\\n]', tab: '[^\\t]', return: '[^\\r]', feed: '[^\\f]',
      null: '[^\\0]', backspace: '[^\\b]', boundary: '\\B',
      alphabetic: '[^a-zA-Z]', alphanumeric: '[^a-zA-Z0-9]'
    };
    const table = neg ? negative : positive;
    if (Object.prototype.hasOwnProperty.call(table, name)) return table[name];
    throw new Error('usage of an unrecognized symbol');
  }

  applyQuant(atom, q) {
    if (atom === '^' || atom === '$') return atom + q;
    if (isSimple(atom)) return atom + q;
    return '(?:' + atom + ')' + q;
  }
}

function isSimple(atom) {
  if (/^\\[AbBdDsSwWfnrt0]$/.test(atom)) return true;
  if (/^\[[^\]]+\]$/.test(atom)) return true;
  if (atom === '.' || atom === ' ') return true;
  if (atom.length === 1) return true;
  if (/^\\.$/.test(atom)) return true;
  return atom.startsWith('(?:') || atom.startsWith('(?=') || atom.startsWith('(?<') || atom.startsWith('(');
}

function escapeRegex(s) {
  return s.replace(/[\\^$.*+?()[\]{}|]/g, '\\$&').replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t').replace(/\f/g, '\\f').replace(/\0/g, '\\0');
}

function compile(src) {
  const p = new Parser(src);
  const out = p.parseRoot(false);
  if (!p.eof()) throw new ParseError('expected EOI', p.i);
  return out;
}

function formatParseError(err, src) {
  if (!(err instanceof ParseError)) return 'Error: ' + err.message;
  const before = src.slice(0, err.pos);
  const line = before.split('\n').length;
  const col = before.length - before.lastIndexOf('\n');
  const text = src.split(/\r?\n/)[line - 1] || '';
  return `Error:  --> ${line}:${col}
  |
${line} | ${text}
  | ${' '.repeat(Math.max(0, col - 1))}^---
  |
  = ${err.message}`;
}

function readStdin() {
  try {
    return fs.readFileSync(0, 'utf8');
  } catch {
    return '';
  }
}

function parseArgs(argv) {
  const opts = { input: null, output: null, test: null, testFile: null, noColor: false, repl: false, completions: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') opts.help = true;
    else if (a === '-V' || a === '--version') opts.version = true;
    else if (a === '-n' || a === '--no-color') opts.noColor = true;
    else if (a === '-r' || a === '--repl') opts.repl = true;
    else if (a === '-o' || a === '--output') opts.output = argv[++i];
    else if (a === '-t' || a === '--test') opts.test = argv[++i] ?? '';
    else if (a === '-f' || a === '--test-file') opts.testFile = argv[++i];
    else if (a === '--generate-completions') opts.completions = argv[++i] || 'bash';
    else if (!opts.input) opts.input = a;
  }
  return opts;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) return process.stdout.write(help() + '\n');
  if (opts.version) return process.stdout.write(VERSION + '\n');
  if (opts.completions) return process.stdout.write(completion(opts.completions));
  if (opts.repl) {
    process.stdout.write('Melody REPL\n');
    return;
  }
  let src;
  try {
    if (!opts.input || opts.input === '-') src = readStdin();
    else {
      try {
        src = fs.readFileSync(opts.input, 'utf8');
      } catch {
        throw new Error(`unable read file at path ${opts.input}`);
      }
    }
    const regex = compile(src);
    if (opts.output) fs.writeFileSync(opts.output, regex + '\n');
    else if (opts.test !== null || opts.testFile) {
      let target;
      if (opts.testFile) {
        try {
          target = fs.readFileSync(opts.testFile, 'utf8');
        } catch {
          throw new Error(`unable read file at path ${opts.testFile}`);
        }
      } else {
        target = opts.test;
      }
      const label = opts.testFile ? opts.testFile : `'${opts.test}'`;
      const matched = new RegExp(regex).test(target);
      process.stdout.write(`${label} ${matched ? 'matched' : 'did not match'}\n`);
    } else {
      process.stdout.write(regex + '\n');
    }
  } catch (err) {
    process.stderr.write(formatParseError(err, src || '') + '\n');
    process.exit(65);
  }
}

main();
