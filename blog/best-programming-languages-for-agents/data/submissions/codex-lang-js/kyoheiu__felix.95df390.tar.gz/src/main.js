#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");
const cp = require("child_process");
const zlib = require("zlib");

const HELP = `# felix v2.16.1
A simple TUI file manager with vim-like keymapping.

## Usage
\`fx\` => Show items in the current directory.
\`fx <directory path>\` => Show items in the path.
Both relative and absolute path available.

## Options
\`--help\` | \`-h\`   => Print help.
\`--log\`  | \`-l\`   => Launch the app, automatically generating a log file.
\`--init\`          => Returns a shell script that can be sourcedfor
                     for shell integration.

## Manual
j / <Down>         :Go down.
k / <Up>           :Go up.
<C-d>              :Go down 1/2 page.
<C-u>>             :Go up 1/2 page.
h / <Left>         :Go to the parent directory if exists.
l / <Right> / <CR> :Open item or change directory.
gg                 :Go to the top.
G                  :Go to the bottom.
z<CR>              :Go to the home directory.
z {keyword}<CR>    :Jump to a directory that matches the keyword.
                    (zoxide required)
<C-o>              :Jump backward.
<C-i>              :Jump forward.
i{file name}<CR>   :Create a new empty file.
I{dir name}<CR>    :Create a new empty directory.
o                  :Open item in a new window.
e                  :Unpack archive/compressed file.
dd                 :Delete and yank item.
yy                 :Yank item.
p                  :Put yanked item(s) from register zero
                    in the current directory.
:reg               :Show registers. To hide it, press v.
"ayy               :Yank item to register a.
"add               :Delete and yank item to register a.
"Ayy               :Append item to register a.
"Add               :Delete and append item to register a.
"ap                :Put item(s) from register a.
V                  :Switch to the linewise visual mode.
  - y              :In the visual mode, yank selected item(s).
  - d              :In the visual mode, delete and yank selected item(s).
  - "ay            :In the visual mode, yank items to register a.
  - "ad            :In the visual mode, delete and yank items to register a.
  - "Ay            :In the visual mode, append items to register a.
  - "Ad            :In the visual mode, delete and append items to register a.
  - c              :Rename selected items in default editor.
u                  :Undo put/delete/rename.
<C-r>              :Redo put/delete/rename.
v                  :Toggle whether to show the preview.
s                  :Toggle between vertical / horizontal split in the preview mode.
<Alt-j>
 / <Alt-<Down>>    :Scroll down the preview text.
<Alt-k> 
 / <Alt-<Up>>      :Scroll up the preview text.
<BS>               :Toggle whether to show hidden items.
t                  :Toggle the sort order (name <-> modified time).
c                  :Switch to the rename mode.
/{keyword}         :Search items by a keyword.
n                  :Go forward to the item that matches the keyword.
N                  :Go backward to the item that matches the keyword.
:                  :Switch to the command line.
  - <C-r>a         :In the command line, paste item name in register a.
:cd<CR>            :Go to the home directory.
:cd {path}<CR>     :Go to the path.
:e<CR>             :Reload the current directory.
:config<CR>        :Go to the directory that contains the config file if exists.
:trash<CR>         :Go to the trash directory.
:empty<CR>         :Empty the trash directory.
:h<CR>             :Show help.
:q<CR>             :Exit.
:{command}         :Execute a command e.g. :zip test *.md
<Esc>              :Return to the normal mode.
<C-h>              :Works as Backspace after \`i\`, \`I\`, \`c\`, \`/\`, \`:\` and \`z\`.
ZZ                 :Exit without cd to last working directory
                    (if \`match_vim_exit_behavior\` is \`false\`).
ZQ                 :cd into the last working directory and exit
                    (if shell setting is ready and \`match_vim_exit_behavior is \`false\`).

## Preview feature
By default, text files and directories can be previewed.
To preview images, you need to install chafa (>= v1.10.0).
Please see https://hpjansson.org/chafa/

## Configuration

*Both \`config.yaml\` and \`config.yml\` work.*

### Linux
config file    : $XDG_CONFIG_HOME/felix/config.yaml(config.yml)
trash directory: $XDG_DATA_HOME/felix/trash
log files      : $XDG_DATA_HOME/felix/log

### macOS
On macOS, felix looks for the config file in the following locations:

1. \`$HOME/Library/Application Support/felix/config.yaml(config.yml)\`
2. \`$HOME/.config/felix/config.yaml\`

trash directory: $HOME/Library/Application Support/felix/trash
log files      : $HOME/Library/Application Support/felix/log

### Windows
config file     : $PROFILE\\\\AppData\\\\Roaming\\\\felix\\\\config.yaml(config.yml)
trash directory : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\trash
log files       : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\log

For more details, visit https://github.com/kyoheiu/felix
`;

const INIT = `# To be eval'ed in the calling shell
  eval "$(
    if [ -n "$XDG_RUNTIME_DIR" ]; then
      runtime_dir="$XDG_RUNTIME_DIR/felix"
    elif [ -n "$TMPDIR" ]; then
      runtime_dir="$TMPDIR/felix"
    else
      runtime_dir=/tmp/felix
    fi

    mkdir -p "$runtime_dir"

    # Clean up leftover LWD files
    find "$runtime_dir" -type f -and -mmin +1 -delete

    cat << EOF
fx() {
  local RUNTIME_DIR="$runtime_dir"
  SHELL_PID=\\$\\$ command fx "\\$@"

  if [ -f "\\$RUNTIME_DIR/\\$\\$" ]; then
    cd "\\$(cat "\\$RUNTIME_DIR/\\$\\$")"
    rm "\\$RUNTIME_DIR/\\$\\$"
  fi
}
EOF
  )"
`;

function configBase() {
  return process.env.XDG_DATA_HOME || process.env.XDG_CONFIG_HOME || path.join(os.homedir(), ".config");
}

function ensureConfig(log) {
  const base = path.join(configBase(), "felix");
  fs.mkdirSync(path.join(base, "trash"), { recursive: true });
  const cfg = path.join(base, "config.yaml");
  if (!fs.existsSync(cfg)) fs.writeFileSync(cfg, "", "utf8");
  if (log) {
    const dir = path.join(base, "log");
    fs.mkdirSync(dir, { recursive: true });
    const d = new Date();
    const pad = n => String(n).padStart(2, "0");
    const name = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}-${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}.log`;
    fs.writeFileSync(path.join(dir, name), "", "utf8");
  }
  return base;
}

function invalidPath(p) {
  process.stdout.write("\n");
  console.error(`Invalid path: ${p}\n\`fx -h\` shows help.`);
}

function modePerm(st) {
  return (st.mode & 0o777).toString(8).padStart(3, "0");
}

function properSize(n) {
  if (n < 1000) return `${n}B`;
  if (n < 1000000) return `${Math.round(n / 1000)}KB`;
  if (n < 1000000000) return `${Math.round(n / 1000000)}MB`;
  return `${Math.round(n / 1000000000)}GB`;
}

function mtime(st) {
  const d = st.mtime;
  const pad = n => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function color(code, s) { return `\x1b[38;5;${code}m${s}\x1b[0m`; }
function extName(name, st) {
  if (st.isDirectory()) return "";
  if (name.endsWith(".tar.gz")) return "tar.gz";
  const e = path.extname(name);
  return e ? e.slice(1) : "";
}

function listDir(dir, showHidden, sortTime) {
  let names = [];
  try { names = fs.readdirSync(dir); } catch { return []; }
  if (!showHidden) names = names.filter(n => !n.startsWith("."));
  const out = [];
  for (const name of names) {
    const p = path.join(dir, name);
    let st, lst;
    try { lst = fs.lstatSync(p); st = fs.statSync(p); } catch { continue; }
    out.push({ name, path: p, st, lst, ext: extName(name, st) });
  }
  out.sort((a, b) => {
    if (sortTime) return b.st.mtimeMs - a.st.mtimeMs || a.name.localeCompare(b.name);
    if (a.st.isDirectory() !== b.st.isDirectory()) return a.st.isDirectory() ? -1 : 1;
    const an = a.name.toLowerCase(), bn = b.name.toLowerCase();
    return an < bn ? -1 : an > bn ? 1 : (a.name < b.name ? -1 : a.name > b.name ? 1 : 0);
  });
  return out;
}

class App {
  constructor(start) {
    this.dir = path.resolve(start);
    this.index = 0;
    this.skip = 0;
    this.showHidden = true;
    this.sortTime = false;
    this.preview = false;
    this.list = [];
    this.pending = "";
    this.register = [];
    this.deleted = [];
    this.message = "";
    this.mode = "normal";
    this.buffer = "";
    this.history = [];
    this.redoDirs = [];
  }
  cols() { return process.stdout.columns || 0; }
  rows() { return process.stdout.rows || 0; }
  enter() {
    if (!process.stdout.isTTY || !process.stdin.isTTY || !this.cols() || !this.rows()) {
      console.error("Error: Cannot detect terminal size");
      return false;
    }
    if (this.cols() < 4 || this.rows() < 4) {
      console.error("Error: Too small window size");
      return false;
    }
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.setEncoding("utf8");
    process.stdout.write("\x1b7\x1b[?25l\x1b[?1049h");
    this.reload();
    this.render();
    process.stdin.on("data", s => this.onData(s));
    return true;
  }
  exit(writeLwd) {
    if (writeLwd && process.env.SHELL_PID) {
      const base = process.env.XDG_RUNTIME_DIR ? path.join(process.env.XDG_RUNTIME_DIR, "felix") : path.join(process.env.TMPDIR || "/tmp", "felix");
      try { fs.mkdirSync(base, { recursive: true }); fs.writeFileSync(path.join(base, process.env.SHELL_PID), this.dir); } catch {}
    }
    try { process.stdin.setRawMode(false); } catch {}
    process.stdout.write("\x1b[?1049l\x1b8\x1b[?25h");
    process.exit(0);
  }
  reload() {
    this.list = listDir(this.dir, this.showHidden, this.sortTime);
    if (this.index >= this.list.length) this.index = Math.max(0, this.list.length - 1);
    if (this.index < 0) this.index = 0;
    const max = Math.max(1, this.rows() - 3);
    if (this.index < this.skip) this.skip = this.index;
    if (this.index >= this.skip + max) this.skip = this.index - max + 1;
  }
  render() {
    const rows = this.rows(), cols = this.cols();
    let s = "\x1b[2J\x1b[1;1H" + color(6, " " + this.dir);
    const max = Math.max(0, rows - 3);
    for (let i = 0; i < max && this.skip + i < this.list.length; i++) {
      const item = this.list[this.skip + i];
      const y = 3 + i;
      const c = item.st.isDirectory() ? 14 : (item.lst.mode & 0o111 ? 1 : 15);
      const mark = this.skip + i === this.index ? ">" : " ";
      let name = item.name.slice(0, Math.max(1, cols - 25));
      let line = `\x1b[${y};1H${mark}\x1b[${y};3H${color(c, name)}`;
      const t = mtime(item.st);
      line += `\x1b[1000D\x1b[${Math.max(1, cols - 16)}C ${t}\x1b[0m`;
      s += line;
    }
    if (this.message || this.mode !== "normal") {
      s += `\x1b[2;2H\x1b[2K${this.mode === "normal" ? this.message : this.prompt() + this.buffer}`;
    }
    const item = this.list[this.index];
    let footer = this.list.length ? ` ${this.index + 1}/${this.list.length} ` : " 0/0";
    if (item) {
      if (item.ext) footer += `${item.ext} `;
      footer += `${properSize(item.st.size)} ${modePerm(item.st)}`;
    }
    s += `\x1b[${rows};1H\x1b[2K\x1b[0m\x1b[7m${footer.padEnd(cols, " ").slice(0, cols)}\x1b[0m`;
    const cy = 3 + (this.index - this.skip);
    s += `\x1b[${Math.max(3, Math.min(rows - 1, cy))};1H`;
    process.stdout.write(s);
  }
  prompt() {
    return this.mode === "cmd" ? ":" : this.mode === "file" ? "i" : this.mode === "dir" ? "I" : this.mode === "search" ? "/" : this.mode === "rename" ? "c" : "";
  }
  setMsg(m) { this.message = m; this.render(); }
  move(delta) {
    if (!this.list.length) return;
    this.index = Math.max(0, Math.min(this.list.length - 1, this.index + delta));
    this.reload(); this.render();
  }
  open() {
    const item = this.list[this.index];
    if (!item) return;
    if (item.st.isDirectory()) {
      this.history.push(this.dir); this.redoDirs = [];
      this.dir = item.path; this.index = 0; this.skip = 0; this.reload(); this.render();
    } else {
      this.setMsg("Cannot open item.");
    }
  }
  parent() {
    const p = path.dirname(this.dir);
    if (p !== this.dir) { this.dir = p; this.index = 0; this.skip = 0; this.reload(); this.render(); }
  }
  onData(chunk) {
    for (const ch of [...chunk]) this.key(ch);
  }
  key(ch) {
    if (this.mode !== "normal") return this.editKey(ch);
    if (ch === "\x03") return this.exit(false);
    if (ch === "\r") return this.open();
    if (ch === "\x1b") { this.pending = ""; return; }
    if (ch === "j" || ch === "B") return this.move(1);
    if (ch === "k" || ch === "A") return this.move(-1);
    if (ch === "l" || ch === "C") return this.open();
    if (ch === "h" || ch === "D") return this.parent();
    if (ch === "G") { this.index = Math.max(0, this.list.length - 1); this.reload(); return this.render(); }
    if (ch === "g") { if (this.pending === "g") { this.pending = ""; this.index = 0; this.skip = 0; this.render(); } else this.pending = "g"; return; }
    if (ch === "\x04") return this.move(Math.floor(this.rows() / 2));
    if (ch === "\x15") return this.move(-Math.floor(this.rows() / 2));
    if (ch === "\x7f") { this.showHidden = !this.showHidden; this.reload(); return this.render(); }
    if (ch === "t") { this.sortTime = !this.sortTime; this.reload(); return this.render(); }
    if (ch === "v" || ch === "s" || ch === "V") { this.preview = !this.preview; return this.render(); }
    if (ch === "i") return this.startMode("file");
    if (ch === "I") return this.startMode("dir");
    if (ch === "c") return this.startMode("rename");
    if (ch === "/") return this.startMode("search");
    if (ch === ":") return this.startMode("cmd");
    if (ch === "y") { if (this.pending === "y") { this.pending = ""; return this.yank(false); } this.pending = "y"; return; }
    if (ch === "d") { if (this.pending === "d") { this.pending = ""; return this.yank(true); } this.pending = "d"; return; }
    if (ch === "p") return this.put();
    if (ch === "e") return this.unpack();
    if (ch === "Z") { if (this.pending === "Z") return this.exit(false); this.pending = "Z"; return; }
    this.pending = "";
  }
  startMode(m) { this.mode = m; this.buffer = ""; this.message = ""; this.render(); }
  editKey(ch) {
    if (ch === "\x1b") { this.mode = "normal"; this.buffer = ""; return this.render(); }
    if (ch === "\x7f" || ch === "\b") { this.buffer = this.buffer.slice(0, -1); return this.render(); }
    if (ch === "\r") {
      const m = this.mode, b = this.buffer.trim();
      this.mode = "normal"; this.buffer = "";
      if (m === "cmd") return this.command(b);
      if (m === "file" && b) { try { fs.closeSync(fs.openSync(path.join(this.dir, b), "a")); this.reload(); this.setMsg("Created."); } catch (e) { this.setMsg(String(e.message)); } return; }
      if (m === "dir" && b) { try { fs.mkdirSync(path.join(this.dir, b), { recursive: false }); this.reload(); this.setMsg("Created."); } catch (e) { this.setMsg(String(e.message)); } return; }
      if (m === "rename" && b && this.list[this.index]) { try { fs.renameSync(this.list[this.index].path, path.join(this.dir, b)); this.reload(); this.setMsg("Renamed."); } catch (e) { this.setMsg(String(e.message)); } return; }
      if (m === "search" && b) { const i = this.list.findIndex(x => x.name.includes(b)); if (i >= 0) this.index = i; this.reload(); this.render(); return; }
      return this.render();
    }
    if (ch >= " ") { this.buffer += ch; this.render(); }
  }
  command(b) {
    if (b === "q") return this.exit(false);
    if (b === "h") { this.message = HELP.split("\n")[0]; return this.render(); }
    if (b === "e") { this.reload(); return this.render(); }
    if (b === "cd" || b === "z") { this.dir = os.homedir(); this.index = 0; this.skip = 0; this.reload(); return this.render(); }
    if (b.startsWith("cd ")) { const p = path.resolve(this.dir, b.slice(3).trim()); if (fs.existsSync(p) && fs.statSync(p).isDirectory()) { this.dir = p; this.index = 0; this.skip = 0; this.reload(); return this.render(); } return this.setMsg("Invalid path."); }
    if (b === "trash") { const p = path.join(configBase(), "felix", "trash"); fs.mkdirSync(p, { recursive: true }); this.dir = p; this.index = 0; this.skip = 0; this.reload(); return this.render(); }
    if (b === "empty") { const p = path.join(configBase(), "felix", "trash"); try { for (const n of fs.readdirSync(p)) rmrf(path.join(p, n)); } catch {} this.reload(); return this.render(); }
    if (b) { try { cp.execSync(b, { cwd: this.dir, stdio: "ignore", shell: "/bin/bash" }); this.reload(); this.setMsg("Done."); } catch { this.setMsg("Command failed."); } }
    else this.render();
  }
  yank(del) {
    const item = this.list[this.index]; if (!item) return;
    this.register = [item.path];
    if (del) { try { const trash = path.join(configBase(), "felix", "trash"); fs.mkdirSync(trash, { recursive: true }); const dest = unique(path.join(trash, item.name)); fs.renameSync(item.path, dest); this.register = [dest]; this.deleted.push({ from: item.path, to: dest }); this.reload(); this.setMsg("Deleted."); } catch (e) { this.setMsg(String(e.message)); } }
    else this.setMsg("Yanked.");
  }
  put() {
    for (const src of this.register) {
      try { copyRecursive(src, unique(path.join(this.dir, path.basename(src).replace(/_\d+$/, "")))); } catch (e) { this.message = String(e.message); }
    }
    this.reload(); this.setMsg(this.message || "Put.");
  }
  unpack() {
    const item = this.list[this.index]; if (!item || item.st.isDirectory()) return;
    this.setMsg("Unpacking...");
    try {
      extractArchive(item.path, unique(path.join(this.dir, item.name + "_1")));
      this.reload(); this.setMsg("Unpacked. [0.00s]");
    } catch (e) {
      this.setMsg("Cannot unpack.");
    }
  }
}

function rmrf(p) { fs.rmSync(p, { recursive: true, force: true }); }
function unique(p) {
  if (!fs.existsSync(p)) return p;
  let i = 1;
  while (fs.existsSync(`${p}_${i}`)) i++;
  return `${p}_${i}`;
}
function copyRecursive(src, dst) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    fs.mkdirSync(dst, { recursive: true });
    for (const n of fs.readdirSync(src)) copyRecursive(path.join(src, n), path.join(dst, n));
  } else fs.copyFileSync(src, dst);
}

function extractArchive(file, dest) {
  fs.mkdirSync(dest, { recursive: true });
  if (file.endsWith(".tar")) return cp.execFileSync("tar", ["-xf", file, "-C", dest]);
  if (file.endsWith(".tar.gz") || file.endsWith(".tgz")) return cp.execFileSync("tar", ["-xzf", file, "-C", dest]);
  if (file.endsWith(".tar.xz") || file.endsWith(".txz")) return cp.execFileSync("tar", ["-xJf", file, "-C", dest]);
  if (file.endsWith(".gz")) {
    const out = path.join(dest, path.basename(file, ".gz"));
    fs.writeFileSync(out, zlib.gunzipSync(fs.readFileSync(file)));
    return;
  }
  if (file.endsWith(".zip")) return extractZip(file, dest);
  throw new Error("unsupported");
}

function extractZip(file, dest) {
  const b = fs.readFileSync(file);
  let off = 0;
  while (off + 30 <= b.length && b.readUInt32LE(off) === 0x04034b50) {
    const method = b.readUInt16LE(off + 8);
    const csize = b.readUInt32LE(off + 18);
    const nlen = b.readUInt16LE(off + 26);
    const elen = b.readUInt16LE(off + 28);
    const name = b.slice(off + 30, off + 30 + nlen).toString();
    const start = off + 30 + nlen + elen;
    const data = b.slice(start, start + csize);
    const out = path.join(dest, name);
    if (name.endsWith("/")) fs.mkdirSync(out, { recursive: true });
    else {
      fs.mkdirSync(path.dirname(out), { recursive: true });
      let raw;
      if (method === 0) raw = data;
      else if (method === 8) raw = zlib.inflateRawSync(data);
      else if (method === 12) raw = cp.execFileSync("bzip2", ["-dc"], { input: data });
      else throw new Error("zip method");
      fs.writeFileSync(out, raw);
    }
    off = start + csize;
  }
}

function run(start, log) {
  ensureConfig(log);
  if (!fs.existsSync(start)) return invalidPath(start);
  try {
    if (!fs.statSync(start).isDirectory()) {
      console.error("Path should be directory.\n`fx -h` shows help.");
      return;
    }
  } catch {
    return invalidPath(start);
  }
  const app = new App(start);
  app.enter();
}

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0) return run(process.cwd(), false);
  if (args.length === 1) {
    if (args[0] === "-h" || args[0] === "--help") return process.stdout.write(HELP);
    if (args[0] === "--init") return process.stdout.write(INIT);
    if (args[0] === "-l" || args[0] === "--log") return run(process.cwd(), true);
    return run(args[0], false);
  }
  if (args.length === 2 && (args[0] === "-l" || args[0] === "--log")) return run(args[1], true);
  return process.stdout.write(HELP);
}

main();
