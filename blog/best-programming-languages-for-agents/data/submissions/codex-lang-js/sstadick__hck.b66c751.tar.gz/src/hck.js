#!/usr/bin/env node
"use strict";

const fs = require("fs");
const zlib = require("zlib");

function usage(longForm) {
  const extra = longForm ? [
    "* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`",
    "",
  ] : [];
  return extra.concat([
    "Usage: executable [OPTIONS] [INPUT]...",
    "",
    "Arguments:",
    "  [INPUT]...  Input files to parse, defaults to stdin",
    "",
    "Options:",
    "  -o, --output <OUTPUT>                 Output file to write to, defaults to stdout",
    "  -d, --delimiter <DELIMITER>           Delimiter to use on input files [default: \\s+]",
    "  -L, --delim-is-literal                Treat the delimiter as a string literal",
    "  -I, --use-input-delim                 Use the input delimiter as the output delimiter if literal",
    "  -D, --output-delimiter <DELIMITER>    Delimiter string to use on outputs [default: \"\\t\"]",
    "  -f, --fields <FIELDS>                 Fields to keep in the output",
    "  -e, --exclude <EXCLUDE>               Fields to exclude from the output",
    "  -E, --exclude-header <HEADER>         Headers to exclude from the output",
    "  -F, --header-field <HEADER>           Header field to select",
    "  -r, --header-is-regex                 Treat header fields as regexes",
    "  -z, --try-decompress                  Try to decompress input files by extension",
    "  -Z, --try-compress                    Try to gzip compress the output",
    "      --crlf                            Support CRLF newlines",
    "  -h, --help                            Print help (see more with '--help')",
    "  -V, --version                         Print version",
  ]).join("\n") + "\n";
}

function die(message, code = 1) {
  const ts = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
  process.stderr.write(`[${ts} ERROR hck] ${message}\n`);
  process.exit(code);
}

function cliError(message) {
  process.stderr.write(`error: ${message}\n\nFor more information, try '--help'.\n`);
  process.exit(2);
}

function parseArgs(argv) {
  const opt = {
    delimiter: "\\s+",
    literal: false,
    useInputDelim: false,
    outDelim: "\t",
    output: null,
    fields: null,
    exclude: null,
    headerFields: [],
    excludeHeaders: [],
    headerRegex: false,
    decompress: false,
    compress: false,
    crlf: false,
    inputs: [],
  };
  const takesValue = new Set(["o", "d", "D", "f", "e", "E", "F", "t", "l"]);
  const longMap = {
    "--output": "o",
    "--delimiter": "d",
    "--output-delimiter": "D",
    "--fields": "f",
    "--exclude": "e",
    "--exclude-header": "E",
    "--header-field": "F",
    "--compression-threads": "t",
    "--compression-level": "l",
  };
  function setVal(k, v) {
    if (v === undefined) cliError(`a value is required for '--${nameFor(k)} <${paramFor(k)}>' but none was supplied`);
    if (k === "o") opt.output = v;
    else if (k === "d") opt.delimiter = v;
    else if (k === "D") opt.outDelim = v;
    else if (k === "f") opt.fields = v;
    else if (k === "e") opt.exclude = v;
    else if (k === "E") opt.excludeHeaders.push(v);
    else if (k === "F") opt.headerFields.push(v);
  }
  function nameFor(k) {
    return {o: "output", d: "delimiter", D: "output-delimiter", f: "fields", e: "exclude", E: "exclude-header", F: "header-field", t: "compression-threads", l: "compression-level"}[k] || k;
  }
  function paramFor(k) {
    return {o: "OUTPUT", d: "DELIMITER", D: "OUTPUT_DELIMITER", f: "FIELDS", e: "EXCLUDE", E: "EXCLUDE_HEADER", F: "HEADER_FIELD", t: "COMPRESSION_THREADS", l: "COMPRESSION_LEVEL"}[k] || "VALUE";
  }

  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === "--") {
      opt.inputs.push(...argv.slice(i + 1));
      break;
    }
    if (a === "-h") { process.stdout.write(usage(false)); process.exit(0); }
    if (a === "--help") { process.stdout.write(usage(true)); process.exit(0); }
    if (a === "-V" || a === "--version") { process.stdout.write("hck git:23bebe8-modified\n"); process.exit(0); }
    if (a === "--no-mmap") continue;
    if (a === "--crlf") { opt.crlf = true; continue; }
    if (a === "--delim-is-literal") { opt.literal = true; continue; }
    if (a === "--use-input-delim") { opt.useInputDelim = true; continue; }
    if (a === "--header-is-regex") { opt.headerRegex = true; continue; }
    if (a === "--try-decompress") { opt.decompress = true; continue; }
    if (a === "--try-compress") { opt.compress = true; continue; }
    if (a.startsWith("--")) {
      const eq = a.indexOf("=");
      const name = eq >= 0 ? a.slice(0, eq) : a;
      if (longMap[name]) {
        const k = longMap[name];
        const v = eq >= 0 ? a.slice(eq + 1) : argv[++i];
        if (k === "t" || k === "l") continue;
        setVal(k, v);
        continue;
      }
      process.stderr.write(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n`);
      process.exit(2);
    }
    if (a.startsWith("-") && a !== "-") {
      let rest = a.slice(1);
      for (let j = 0; j < rest.length; j++) {
        const c = rest[j];
        if (c === "L") opt.literal = true;
        else if (c === "I") opt.useInputDelim = true;
        else if (c === "r") opt.headerRegex = true;
        else if (c === "z") opt.decompress = true;
        else if (c === "Z") opt.compress = true;
        else if (takesValue.has(c)) {
          const v = j + 1 < rest.length ? rest.slice(j + 1) : argv[++i];
          if (c !== "t" && c !== "l") setVal(c, v);
          break;
        } else {
          process.stderr.write(`error: unexpected argument '-${c}' found\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n`);
          process.exit(2);
        }
      }
      continue;
    }
    opt.inputs.push(a);
  }
  if (opt.useInputDelim && opt.literal && opt.outDelim === "\t") opt.outDelim = opt.delimiter;
  return opt;
}

function parseRanges(spec) {
  if (!spec) return null;
  const ranges = [];
  for (const raw of spec.split(",")) {
    const part = raw.trim();
    if (!part) continue;
    let m;
    if ((m = part.match(/^(\d+)$/))) {
      const n = Number(m[1]);
      if (n < 1) die(`Fields and positions are numbered from 1: ${n}`);
      ranges.push([n, n]);
    } else if ((m = part.match(/^(\d+)-(\d+)$/))) {
      const lo = Number(m[1]), hi = Number(m[2]);
      if (lo < 1) die(`Fields and positions are numbered from 1: ${lo}`);
      if (hi < lo) die(`High end of range less than low end of range: ${part}`);
      ranges.push([lo, hi]);
    } else if ((m = part.match(/^(\d+)-$/))) {
      const lo = Number(m[1]);
      if (lo < 1) die(`Fields and positions are numbered from 1: ${lo}`);
      ranges.push([lo, Infinity]);
    } else if ((m = part.match(/^-(\d+)$/))) {
      const hi = Number(m[1]);
      if (hi < 1) die(`Fields and positions are numbered from 1: ${hi}`);
      ranges.push([1, hi]);
    } else {
      die(`Failed to parse field: ${part}`);
    }
  }
  return ranges;
}

function indicesFromRanges(ranges, len) {
  const out = [];
  const seen = new Set();
  if (!ranges) {
    for (let i = 0; i < len; i++) out.push(i);
    return out;
  }
  for (const [lo, hi0] of ranges) {
    const hi = Math.min(hi0, len);
    for (let n = lo; n <= hi; n++) {
      const idx = n - 1;
      if (!seen.has(idx)) { seen.add(idx); out.push(idx); }
    }
  }
  return out;
}

function makeSplitter(opt) {
  if (opt.literal) return line => opt.delimiter === "" ? [line] : line.split(opt.delimiter);
  let re;
  try {
    const pattern = opt.crlf && opt.delimiter === "\\s+" ? "[ \\t\\f\\v]+" : opt.delimiter;
    re = new RegExp(pattern, "g");
  } catch (e) {
    die(e.message);
  }
  return line => {
    const out = [];
    let last = 0;
    re.lastIndex = 0;
    let m;
    while ((m = re.exec(line)) !== null) {
      out.push(line.slice(last, m.index));
      last = m.index + m[0].length;
      if (m[0].length === 0) re.lastIndex++;
    }
    out.push(line.slice(last));
    return out;
  };
}

function headerMatches(headers, selectors, regexMode) {
  const out = [];
  const seen = new Set();
  let any = false;
  const missing = [];
  for (const sel of selectors) {
    let matched = false;
    let re = null;
    if (regexMode) {
      try { re = new RegExp(sel); } catch (e) { die(e.message); }
    }
    for (let i = 0; i < headers.length; i++) {
      const ok = regexMode ? re.test(headers[i]) : headers[i] === sel;
      if (ok) {
        matched = true;
        any = true;
        if (!seen.has(i)) { seen.add(i); out.push(i); }
      }
    }
    if (!matched) missing.push(sel);
  }
  if (selectors.length && !any) die("No headers matched");
  if (missing.length) die(`Header not found: ${missing[0]}`);
  return out;
}

function excludedHeaderSet(headers, selectors, regexMode) {
  const set = new Set();
  for (const sel of selectors) {
    let re = null;
    if (regexMode) {
      try { re = new RegExp(sel); } catch (e) { die(e.message); }
    }
    for (let i = 0; i < headers.length; i++) {
      if (regexMode ? re.test(headers[i]) : headers[i] === sel) set.add(i);
    }
  }
  return set;
}

function readInput(path, opt) {
  try {
    let b = path ? fs.readFileSync(path) : fs.readFileSync(0);
    if (path && opt.decompress && /\.gz$/i.test(path)) b = zlib.gunzipSync(b);
    return b.toString("utf8");
  } catch (e) {
    if (e && e.code === "ENOENT") die("No such file or directory (os error 2)");
    if (e && e.code === "EISDIR") die("Is a directory (os error 21)");
    die(e.message);
  }
}

function processText(text, opt, state) {
  const split = makeSplitter(opt);
  const lines = text.split(/\n/);
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  const out = [];
  for (let line of lines) {
    if (!opt.crlf && line.endsWith("\r")) line = line.slice(0, -1);
    const fields = split(line);
    if (!state.headerDone && (opt.headerFields.length || opt.excludeHeaders.length)) {
      state.headerDone = true;
      const base = opt.fields ? indicesFromRanges(parseRanges(opt.fields), fields.length) : (opt.headerFields.length ? [] : indicesFromRanges(null, fields.length));
      const hsel = headerMatches(fields, opt.headerFields, opt.headerRegex);
      state.headerExcludes = excludedHeaderSet(fields, opt.excludeHeaders, opt.headerRegex);
      state.headerSelected = [];
      const seen = new Set();
      for (const i of base.concat(hsel)) {
        if (!seen.has(i)) { seen.add(i); state.headerSelected.push(i); }
      }
      if (!opt.fields && !opt.headerFields.length) state.headerSelected = indicesFromRanges(null, fields.length);
    }
    let selected;
    if (state.headerDone && (opt.headerFields.length || opt.excludeHeaders.length)) {
      selected = state.headerSelected.slice();
    } else {
      selected = indicesFromRanges(parseRanges(opt.fields), fields.length);
    }
    const ex = parseRanges(opt.exclude);
    const excluded = new Set();
    if (ex) for (const i of indicesFromRanges(ex, fields.length)) excluded.add(i);
    if (state.headerExcludes) for (const i of state.headerExcludes) excluded.add(i);
    const vals = [];
    for (const i of selected) if (!excluded.has(i)) vals.push(i < fields.length ? fields[i] : "");
    if (selected.length > 0 && vals.length === 0) continue;
    out.push(vals.join(opt.outDelim));
  }
  return out.join("\n") + (out.length ? "\n" : "");
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  const state = { headerDone: false, headerSelected: null, headerExcludes: null };
  let result = "";
  if (opt.inputs.length === 0) {
    result += processText(readInput(null, opt), opt, state);
  } else {
    for (const p of opt.inputs) result += processText(readInput(p, opt), opt, state);
  }
  let outBuf = Buffer.from(result, "utf8");
  if (opt.compress) outBuf = zlib.gzipSync(outBuf, { level: 6 });
  if (opt.output) fs.writeFileSync(opt.output, outBuf);
  else process.stdout.write(outBuf);
}

main();
