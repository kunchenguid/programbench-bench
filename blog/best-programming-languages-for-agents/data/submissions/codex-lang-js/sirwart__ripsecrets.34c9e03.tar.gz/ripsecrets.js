#!/usr/bin/env node

const fs = require("fs");
const path = require("path");

const HELP_LONG = `ripsecrets searches files and directories recursively for secret API keys.
It's primarily designed to be used as a pre-commit to prevent committing
secrets into version control.

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...
          Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install \`ripsecrets\` as a pre-commit hook automatically in git directory provided

      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit

      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line

      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const HELP_SHORT = `A command-line tool to prevent committing secret keys into your source code

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...  Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install \`ripsecrets\` as a pre-commit hook automatically in git directory provided
      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit
      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line
      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version`;

function parseArgs(argv) {
  const opts = {
    install: false,
    strictIgnore: false,
    onlyMatching: false,
    additional: [],
    paths: [],
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help") {
      console.log(HELP_LONG);
      process.exit(0);
    } else if (a === "-h") {
      console.log(HELP_SHORT);
      process.exit(0);
    } else if (a === "--version" || a === "-V") {
      console.log("ripsecrets 0.1.11");
      process.exit(0);
    } else if (a === "--install-pre-commit") {
      opts.install = true;
    } else if (a === "--strict-ignore") {
      opts.strictIgnore = true;
    } else if (a === "--only-matching") {
      opts.onlyMatching = true;
    } else if (a === "--additional-pattern") {
      if (i + 1 >= argv.length) {
        console.error("error: a value is required for '--additional-pattern <ADDITIONAL_PATTERNS>' but none was supplied");
        process.exit(2);
      }
      opts.additional.push(argv[++i]);
    } else if (a.startsWith("--additional-pattern=")) {
      opts.additional.push(a.slice("--additional-pattern=".length));
    } else if (a.startsWith("-") && a !== "-") {
      console.error(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [Source files]...\n\nFor more information, try '--help'.`);
      process.exit(2);
    } else {
      opts.paths.push(a);
    }
  }
  if (opts.paths.length === 0) opts.paths.push(".");
  return opts;
}

function findGitDir(start) {
  let cur = path.resolve(start || ".");
  try {
    const st = fs.statSync(cur);
    if (st.isFile()) cur = path.dirname(cur);
  } catch (_) {}
  while (true) {
    const gd = path.join(cur, ".git");
    if (fs.existsSync(gd)) return gd;
    const parent = path.dirname(cur);
    if (parent === cur) return null;
    cur = parent;
  }
}

function installHook(paths) {
  const gd = findGitDir(paths[0] || ".");
  if (!gd) {
    console.error("Error: .git directory not found");
    process.exit(2);
  }
  const hooks = path.join(gd, "hooks");
  fs.mkdirSync(hooks, { recursive: true });
  const hook = path.join(hooks, "pre-commit");
  const content = "ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n";
  if (fs.existsSync(hook)) {
    try {
      if (fs.readFileSync(hook, "utf8") === content) {
        console.error("Error: pre-commit hook has already been installed");
        process.exit(2);
      }
    } catch (_) {}
  }
  fs.writeFileSync(hook, content, { mode: 0o744 });
  fs.chmodSync(hook, 0o744);
}

function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function compileGlob(pat) {
  let anchored = pat.startsWith("/");
  if (anchored) pat = pat.slice(1);
  let dirOnly = pat.endsWith("/");
  if (dirOnly) pat = pat.slice(0, -1);
  let out = "";
  for (let i = 0; i < pat.length; i++) {
    const c = pat[i];
    if (c === "*") out += "[^/]*";
    else if (c === "?") out += "[^/]";
    else out += escapeRe(c);
  }
  if (!pat.includes("/")) out = `(?:^|/)${out}`;
  else if (anchored) out = `^${out}`;
  else out = `(?:^|/)${out}`;
  if (dirOnly) out += "(?:/|$)";
  else out += "$";
  return new RegExp(out);
}

function loadIgnore(start) {
  const root = process.cwd();
  const file = path.join(root, ".secretsignore");
  const res = { root, patterns: [], neg: [], secrets: new Set() };
  if (!fs.existsSync(file)) return res;
  let inSecrets = false;
  for (const raw of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    if (line === "[secrets]") {
      inSecrets = true;
      continue;
    }
    if (line.startsWith("[") && line.endsWith("]")) {
      inSecrets = false;
      continue;
    }
    if (inSecrets) res.secrets.add(line);
    else if (line.startsWith("!")) res.neg.push(compileGlob(line.slice(1)));
    else res.patterns.push(compileGlob(line));
  }
  return res;
}

function isIgnored(file, ignore) {
  let rel = path.relative(ignore.root, path.resolve(file)).split(path.sep).join("/");
  if (rel.startsWith("..")) return false;
  let ignored = false;
  for (const re of ignore.patterns) if (re.test(rel)) ignored = true;
  for (const re of ignore.neg) if (re.test(rel)) ignored = false;
  return ignored;
}

function entropy(s) {
  if (!s) return 0;
  const counts = new Map();
  for (const ch of s) counts.set(ch, (counts.get(ch) || 0) + 1);
  let e = 0;
  for (const n of counts.values()) {
    const p = n / s.length;
    e -= p * Math.log2(p);
  }
  return e;
}

function worthwhileSecret(s) {
  if (!s || s.length < 8) return false;
  if (/^[a-z]+$/.test(s) || /^[A-Z]+$/.test(s) || /^[0-9]+$/.test(s)) return false;
  return entropy(s) >= 3.2;
}

function tokenPatterns() {
  return [
    /(?:aws_access_key_id|AWS_ACCESS_KEY_ID)\s*(?::|=>|=)\s*["']?(AKIA[0-9A-Z]{16})["']?/g,
    /(?:aws_secret_access_key|AWS_SECRET_ACCESS_KEY)\s*(?::|=>|=)\s*["']?([A-Za-z0-9/+=]{40})["']?/g,
    /(xox[a-z]-[A-Za-z0-9-]+)/g,
    /(https:\/\/hooks\.slack\.com\/services\/[A-Za-z0-9_\/-]+)/g,
    /(sk_(?:live|test)_[A-Za-z0-9]{16,})/g,
    /(npm_[A-Za-z0-9]{36})/g,
    /(AIza[0-9A-Za-z\-_]{35})/g,
    /(SG\.[A-Za-z0-9_\-]{16,32}\.[A-Za-z0-9_\-]{43})/g,
    /(gh[pousr]_[A-Za-z0-9_]{36,})/g,
    /(github_pat_[A-Za-z0-9_]{20,})/g,
    /(glpat-[A-Za-z0-9_\-]{20,})/g,
    /(key-[0-9a-fA-F]{32})/g,
    /(-----BEGIN (?:RSA |DSA |EC |OPENSSH |PGP )?PRIVATE KEY(?: BLOCK)?-----)/g,
  ];
}

function compileAdditional(patterns) {
  const out = [];
  for (const p of patterns) {
    try {
      out.push(new RegExp(p, "g"));
    } catch (e) {
      console.error(`Invalid regex pattern: ${p}`);
    }
  }
  return out;
}

function firstMatch(line, builtins, additional) {
  for (const re of builtins) {
    re.lastIndex = 0;
    const m = re.exec(line);
    if (m) {
      const candidate = m[1] || m[0];
      if (candidate.startsWith("sk_") && !worthwhileSecret(candidate)) continue;
      return candidate;
    }
  }
  for (const re of additional) {
    re.lastIndex = 0;
    const m = re.exec(line);
    if (!m) continue;
    const candidate = m.length > 1 ? m[1] : m[0];
    if (m.length > 1 && !worthwhileSecret(candidate)) continue;
    return candidate;
  }
  return null;
}

function collectFiles(input, ignore, strictForInput) {
  const files = [];
  function childDisplay(parent, child) {
    if (parent === ".") return `./${child}`;
    if (parent.startsWith("./")) return `${parent}/${child}`;
    return path.join(parent, child);
  }
  function walk(p, display, top) {
    let st;
    try {
      st = fs.statSync(p);
    } catch (e) {
      console.error(`${p}: ${e.message}`);
      return;
    }
    const base = path.basename(p);
    if (base === ".git" || base === "node_modules") return;
    if ((!top || strictForInput) && isIgnored(p, ignore)) return;
    if (st.isDirectory()) {
      let entries = [];
      try {
        entries = fs.readdirSync(p).sort();
      } catch (_) {
        return;
      }
      for (const ent of entries) walk(path.join(p, ent), childDisplay(display, ent), false);
    } else if (st.isFile()) {
      files.push({ path: p, display });
    }
  }
  walk(input, input, true);
  return files;
}

function scanFile(file, display, builtins, additional, onlyMatching, ignoredSecrets) {
  let buf;
  try {
    buf = fs.readFileSync(file);
  } catch (_) {
    return false;
  }
  if (buf.includes(0)) return false;
  const text = buf.toString("utf8");
  let found = false;
  const lines = text.split(/\n/);
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].replace(/\r$/, "");
    const m = firstMatch(line, builtins, additional);
    if (m && !ignoredSecrets.has(m)) {
      console.log(`${display}:${i + 1}:${onlyMatching ? m : line}`);
      found = true;
    }
  }
  return found;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.install) {
    installHook(opts.paths);
    return;
  }
  const builtins = tokenPatterns();
  const additional = compileAdditional(opts.additional);
  let any = false;
  for (const input of opts.paths) {
    const ignore = loadIgnore(input);
    for (const file of collectFiles(input, ignore, opts.strictIgnore)) {
      if (scanFile(file.path, file.display, builtins, additional, opts.onlyMatching, ignore.secrets)) any = true;
    }
  }
  process.exit(any ? 1 : 0);
}

main();
