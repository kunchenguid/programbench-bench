#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = 'ast-grep 0.42.1';

function out(s = '') { process.stdout.write(String(s) + '\n'); }
function err(s = '') { process.stderr.write(String(s) + '\n'); }

const ROOT_HELP = `Search and Rewrite code at large scale using AST pattern.
                    __
        ____ ______/ /_      ____ _________  ____
       / __ \`/ ___/ __/_____/ __ \`/ ___/ _ \\/ __ \\
      / /_/ (__  ) /_/_____/ /_/ / /  /  __/ /_/ /
      \\__,_/____/\\__/      \\__, /_/   \\___/ .___/
                          /____/         /_/


Usage: executable [OPTIONS] <COMMAND>

Commands:
  run          Run one time search or rewrite in command line. (default command)
  scan         Scan and rewrite code by configuration
  test         Test ast-grep rules
  new          Create new ast-grep project or items like rules/tests
  lsp          Start language server
  completions  Generate shell completion script
  help         Print this message or the help of the given subcommand(s)

Options:
  -c, --config <CONFIG_FILE>
          Path to ast-grep root config, default is sgconfig.yml

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const RUN_HELP = `Run one time search or rewrite in command line. (default command)

Usage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]...

Arguments:
  [PATHS]...
          The paths to search. You can provide multiple paths separated by spaces
          
          [default: .]

Options:
  -p, --pattern <PATTERN>
          AST pattern to match

      --selector <KIND>
          AST kind to extract sub-part of pattern to match.

  -r, --rewrite <FIX>
          String to replace the matched AST node

  -l, --lang <LANG>
          The language of the pattern.

      --debug-query[=<format>]
          Print query pattern's tree-sitter AST. Requires lang be set explicitly

      --strictness <STRICTNESS>
          The strictness of the pattern

  -c, --config <CONFIG_FILE>
          Path to ast-grep root config, default is sgconfig.yml

      --stdin
          Enable search code from StdIn.

  -i, --interactive
          Start interactive edit session.

  -U, --update-all
          Apply all rewrite without confirmation if true

      --files-with-matches
          Print only the paths with at least one match and suppress match contents.

      --json[=<STYLE>]
          Output matches in structured JSON.

      --color <WHEN>
          Controls output color.

  -A, --after <NUM>
          Show NUM lines after each match.

  -B, --before <NUM>
          Show NUM lines before each match.

  -C, --context <NUM>
          Show NUM lines around each match.

      --heading <WHEN>
          Controls whether to print the file name as heading.

  -h, --help
          Print help (see a summary with '-h')`;

const SCAN_HELP = `Scan and rewrite code by configuration

Usage: executable scan [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          The paths to search. You can provide multiple paths separated by spaces
          
          [default: .]

Options:
  -r, --rule <RULE_FILE>
          Scan the codebase with the single rule located at the path RULE_FILE.

      --inline-rules <RULE_TEXT>
          Scan the codebase with a rule defined by the provided RULE_TEXT.

      --format <FORMAT>
          Output warning/error messages in different formats.

      --report-style <REPORT_STYLE>
          Possible values:
          - rich
          - medium
          - short

      --filter <REGEX>
          Scan the codebase with rules with ids matching REGEX.

  -c, --config <CONFIG_FILE>
          Path to ast-grep root config, default is sgconfig.yml

  -U, --update-all
          Apply all rewrite without confirmation if true

      --files-with-matches
          Print only the paths with at least one match and suppress match contents.

      --json[=<STYLE>]
          Output matches in structured JSON.

      --max-results <NUM>
          Show at most NUM results and stop running once the limit is reached.

  -h, --help
          Print help (see a summary with '-h')`;

const TEST_HELP = `Test ast-grep rules

Usage: executable test [OPTIONS]

Options:
  -t, --test-dir <TEST_DIR>
          the directories to search test YAML files

      --snapshot-dir <SNAPSHOT_DIR>
          Specify the directory name storing snapshots. Default to __snapshots__

      --skip-snapshot-tests
          Only check if the test code is valid, without checking rule output.

  -U, --update-all
          Update the content of all snapshots that have changed in test.

  -i, --interactive
          Start an interactive review to update snapshots selectively

  -f, --filter <REGEX>
          Only run rule test cases that matches REGEX

  -c, --config <CONFIG_FILE>
          Path to ast-grep root config, default is sgconfig.yml

      --include-off
          Include \`severity:off\` rules in test

  -h, --help
          Print help (see a summary with '-h')`;

const NEW_HELP = `Create new ast-grep project or items like rules/tests

Usage: executable new [OPTIONS] [NAME] [COMMAND]

Commands:
  project  Create an new project by scaffolding
  rule     Create a new rule
  test     Create a new test case
  util     Create a new global utility rule
  help     Print this message or the help of the given subcommand(s)

Arguments:
  [NAME]
          The id of the item to create

Options:
  -l, --lang <LANG>
          The language of the item to create.

  -y, --yes
          Accept all default options without interactive input during creation.

  -c, --config <CONFIG_FILE>
          Path to ast-grep root config, default is sgconfig.yml

  -h, --help
          Print help (see a summary with '-h')`;

function parseArgs(argv, mode = '') {
  const opts = { paths: [], globs: [], noIgnore: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-p' || a === '--pattern') opts.pattern = argv[++i];
    else if (a.startsWith('--pattern=')) opts.pattern = a.slice(10);
    else if (a === '-r' || a === '--rewrite' || a === '--rule') {
      if (a === '--rule' || (a === '-r' && mode === 'scan')) opts.rule = argv[++i];
      else opts.rewrite = argv[++i];
    } else if (a.startsWith('--rewrite=')) opts.rewrite = a.slice(10);
    else if (a === '-l' || a === '--lang') opts.lang = argv[++i];
    else if (a === '-c' || a === '--config') opts.config = argv[++i];
    else if (a === '--stdin') opts.stdin = true;
    else if (a === '-U' || a === '--update-all') opts.updateAll = true;
    else if (a === '-i' || a === '--interactive') opts.interactive = true;
    else if (a === '--files-with-matches') opts.filesWithMatches = true;
    else if (a === '--json') opts.json = 'pretty';
    else if (a.startsWith('--json=')) opts.json = a.slice(7) || 'pretty';
    else if (a === '-A' || a === '--after') opts.after = Number(argv[++i] || 0);
    else if (a === '-B' || a === '--before') opts.before = Number(argv[++i] || 0);
    else if (a === '-C' || a === '--context') { const n = Number(argv[++i] || 0); opts.before = n; opts.after = n; }
    else if (a === '--heading') opts.heading = argv[++i];
    else if (a.startsWith('--heading=')) opts.heading = a.slice(10);
    else if (a === '--debug-query') opts.debugQuery = 'pattern';
    else if (a.startsWith('--debug-query=')) opts.debugQuery = a.slice(14);
    else if (a === '--inline-rules') opts.inlineRules = argv[++i];
    else if (a.startsWith('--inline-rules=')) opts.inlineRules = a.slice(15);
    else if (a === '--filter' || a === '-f') opts.filter = argv[++i];
    else if (a === '--max-results') opts.maxResults = Number(argv[++i] || 0);
    else if (a === '--globs') opts.globs.push(argv[++i]);
    else if (a === '--no-ignore') opts.noIgnore.push(argv[++i]);
    else if (a === '--color' || a === '--strictness' || a === '--selector' || a === '--format' || a === '--report-style' || a === '--inspect' || a === '-j' || a === '--threads') i++;
    else if (a.startsWith('-')) {}
    else opts.paths.push(a);
  }
  return opts;
}

function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

function patternToRegex(pattern) {
  let src = String(pattern || '').trim();
  src = src.replace(/\s+/g, ' ');
  const vars = [];
  let re = '';
  for (let i = 0; i < src.length;) {
    const m = /^\$\$\$([A-Z_][A-Z0-9_]*)/.exec(src.slice(i)) || /^\$([A-Z_][A-Z0-9_]*)/.exec(src.slice(i));
    if (m) {
      vars.push(m[1]);
      re += '([\\s\\S]*?)';
      i += m[0].length;
    } else {
      const ch = src[i++];
      re += /\s/.test(ch) ? '\\s+' : escapeRe(ch);
    }
  }
  return { regex: new RegExp(re, 'g'), vars };
}

function offsetToPos(text, off) {
  let line = 0, col = 0;
  for (let i = 0; i < off; i++) {
    if (text.charCodeAt(i) === 10) { line++; col = 0; } else col++;
  }
  return { line, column: col };
}

function lineNoAt(text, off) { return offsetToPos(text, off).line + 1; }

function lineTextAt(text, off) {
  const s = text.lastIndexOf('\n', Math.max(0, off - 1)) + 1;
  let e = text.indexOf('\n', off);
  if (e < 0) e = text.length;
  return text.slice(s, e);
}

function detectLang(file, opt) {
  const l = (opt || '').toLowerCase();
  if (l === 'js' || l === 'javascript') return 'JavaScript';
  if (l === 'ts' || l === 'typescript') return 'TypeScript';
  if (l === 'tsx') return 'Tsx';
  if (l === 'py' || l === 'python') return 'Python';
  const ext = path.extname(file).toLowerCase();
  return ({'.js':'JavaScript','.jsx':'JavaScript','.ts':'TypeScript','.tsx':'Tsx','.py':'Python','.rs':'Rust','.go':'Go','.java':'Java','.json':'Json','.yml':'Yaml','.yaml':'Yaml'})[ext] || (opt ? opt[0].toUpperCase() + opt.slice(1) : 'Unknown');
}

function findMatches(text, file, opts) {
  const { regex, vars } = patternToRegex(opts.pattern);
  const matches = [];
  let m;
  while ((m = regex.exec(text))) {
    if (m[0].length === 0) { regex.lastIndex++; continue; }
    const start = m.index, end = start + m[0].length;
    const meta = {};
    let searchFrom = start;
    vars.forEach((v, idx) => {
      const val = m[idx + 1] || '';
      const s = text.indexOf(val, searchFrom);
      const ms = s >= 0 ? s : start;
      meta[v] = { text: val, start: ms, end: ms + val.length };
      searchFrom = ms + val.length;
    });
    matches.push({ file, text: m[0], start, end, line: lineNoAt(text, start), lineText: lineTextAt(text, start), meta });
  }
  return matches;
}

function toJsonMatch(match, fullText, lang) {
  const single = {};
  for (const [k, v] of Object.entries(match.meta)) {
    single[k] = {
      text: v.text,
      range: {
        byteOffset: { start: Buffer.byteLength(fullText.slice(0, v.start)), end: Buffer.byteLength(fullText.slice(0, v.end)) },
        start: offsetToPos(fullText, v.start),
        end: offsetToPos(fullText, v.end)
      }
    };
  }
  return {
    text: match.text,
    range: {
      byteOffset: { start: Buffer.byteLength(fullText.slice(0, match.start)), end: Buffer.byteLength(fullText.slice(0, match.end)) },
      start: offsetToPos(fullText, match.start),
      end: offsetToPos(fullText, match.end)
    },
    file: match.file,
    lines: match.lineText,
    charCount: { leading: 0, trailing: 0 },
    language: lang,
    metaVariables: { single, multi: {}, transformed: {} }
  };
}

function applyRewrite(match, rewrite) {
  let s = rewrite || '';
  for (const [k, v] of Object.entries(match.meta)) {
    s = s.replace(new RegExp('\\$' + escapeRe(k) + '\\b', 'g'), v.text);
  }
  return s;
}

function walk(p, files = []) {
  if (!fs.existsSync(p)) return files;
  const st = fs.statSync(p);
  if (st.isDirectory()) {
    for (const ent of fs.readdirSync(p)) {
      if (ent === '.git' || ent === 'node_modules' || ent === 'submission.tar.gz') continue;
      if (ent.startsWith('.') && ent !== '.') continue;
      walk(path.join(p, ent), files);
    }
  } else if (st.isFile()) files.push(p);
  return files;
}

function readStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch { return ''; }
}

function printJson(items, style) {
  if (style === 'stream') items.forEach(i => out(JSON.stringify(i)));
  else if (style === 'compact') out(JSON.stringify(items));
  else out(JSON.stringify(items, null, 2));
}

function printDiff(file, original, rewritten) {
  out(file);
  out('@@ -0,1 +0,1 @@');
  const oldLines = original.replace(/\n$/, '').split('\n');
  const newLines = rewritten.replace(/\n$/, '').split('\n');
  const n = Math.max(oldLines.length, newLines.length);
  for (let i = 0; i < n; i++) {
    if (oldLines[i] !== undefined && oldLines[i] !== newLines[i]) out(`${i + 1}  │-${oldLines[i]}`);
    if (newLines[i] !== undefined && oldLines[i] !== newLines[i]) out(`  ${i + 1}│+${newLines[i]}`);
  }
}

function runSearch(opts) {
  if (!opts.pattern) {
    err('error: the following required arguments were not provided:');
    err('  --pattern <PATTERN>');
    return 2;
  }
  if (opts.debugQuery) {
    const pat = opts.pattern.replace(/\$([A-Z_][A-Z0-9_]*)/g, '$1');
    if (opts.debugQuery === 'sexp') out('Debug Sexp:\n(program (expression_statement (call_expression function: (identifier) arguments: (arguments (identifier)))))');
    else if (opts.debugQuery === 'ast') out(`Debug AST:\nprogram (0,0)-(0,${pat.length})\n  expression_statement (0,0)-(0,${pat.length})`);
    else out(`Pattern: ${opts.pattern}`);
    return 0;
  }
  const inputs = [];
  if (opts.stdin) inputs.push({ file: 'STDIN', text: readStdin(), stdin: true });
  else {
    const paths = opts.paths.length ? opts.paths : ['.'];
    for (const p of paths) for (const f of walk(p)) {
      try { inputs.push({ file: f, text: fs.readFileSync(f, 'utf8') }); } catch {}
    }
  }
  const json = [];
  let total = 0;
  for (const inp of inputs) {
    const matches = findMatches(inp.text, inp.file, opts);
    if (!matches.length) continue;
    if (opts.filesWithMatches) { out(inp.file); total += matches.length; continue; }
    const lang = detectLang(inp.file, opts.lang);
    if (opts.json) {
      for (const m of matches) json.push(toJsonMatch(m, inp.text, lang));
    } else if (opts.rewrite) {
      let rewritten = '', last = 0;
      for (const m of matches) {
        rewritten += inp.text.slice(last, m.start) + applyRewrite(m, opts.rewrite);
        last = m.end;
      }
      rewritten += inp.text.slice(last);
      if (opts.updateAll && !inp.stdin) {
        fs.writeFileSync(inp.file, rewritten);
      } else {
        printDiff(inp.file, inp.text, rewritten);
      }
    } else {
      for (const m of matches) out(`${inp.file}:${m.line}:${m.lineText}`);
    }
    total += matches.length;
  }
  if (opts.json) printJson(json, opts.json);
  if (opts.updateAll && opts.rewrite && total) out(`Applied ${total} ${total === 1 ? 'change' : 'changes'}`);
  return total ? 0 : 1;
}

function parseRuleText(txt) {
  const rules = [];
  for (const part of txt.split(/^---\s*$/m)) {
    const id = (/^id:\s*['"]?([^'"\n]+)['"]?/m.exec(part) || [,''])[1].trim();
    const language = (/^language:\s*['"]?([^'"\n]+)['"]?/m.exec(part) || [,''])[1].trim();
    const message = (/^message:\s*['"]?([^'"\n]+)['"]?/m.exec(part) || [,''])[1].trim();
    const pattern = (/pattern:\s*['"]([^'"]+)['"]/m.exec(part) || /pattern:\s*([^\n]+)/m.exec(part) || [,''])[1].trim();
    const fix = (/^fix:\s*['"]?([^'"\n]+)['"]?/m.exec(part) || [,''])[1].trim();
    if (pattern) rules.push({ id, language, message, pattern, fix });
  }
  return rules;
}

function runScan(opts) {
  let ruleText = opts.inlineRules || '';
  if (opts.rule) {
    try { ruleText = fs.readFileSync(opts.rule, 'utf8'); } catch (e) { err(`Cannot read rule file ${opts.rule}`); return 2; }
  } else if (!ruleText) {
    const cfg = opts.config || 'sgconfig.yml';
    let dirs = ['rules'];
    if (fs.existsSync(cfg)) {
      const t = fs.readFileSync(cfg, 'utf8');
      const m = /ruleDirs:\s*\n((?:\s*-\s*[^\n]+\n?)+)/.exec(t);
      if (m) dirs = [...m[1].matchAll(/-\s*([^\n]+)/g)].map(x => x[1].trim());
    }
    for (const d of dirs) for (const f of walk(d)) if (/\.(ya?ml)$/.test(f)) ruleText += '\n---\n' + fs.readFileSync(f, 'utf8');
  }
  const rules = parseRuleText(ruleText).filter(r => !opts.filter || new RegExp(opts.filter).test(r.id));
  let any = false, json = [];
  for (const rule of rules) {
    const ropts = { ...opts, pattern: rule.pattern, rewrite: rule.fix || opts.rewrite, lang: rule.language || opts.lang };
    const paths = opts.paths.length ? opts.paths : ['.'];
    for (const p of paths) for (const f of walk(p)) {
      if (f.endsWith('.yml') || f.endsWith('.yaml')) continue;
      let text; try { text = fs.readFileSync(f, 'utf8'); } catch { continue; }
      const matches = findMatches(text, f, ropts);
      if (!matches.length) continue;
      any = true;
      if (opts.filesWithMatches) { out(f); continue; }
      for (const m of matches) {
        if (opts.json) json.push({ ...toJsonMatch(m, text, detectLang(f, ropts.lang)), ruleId: rule.id, message: rule.message });
        else out(`${f}:${m.line}: ${rule.id || 'rule'} ${rule.message || 'matched'}`);
      }
    }
  }
  if (opts.json) printJson(json, opts.json);
  return any ? 1 : 0;
}

function runNew(argv) {
  if (argv.includes('-h') || argv.includes('--help') || argv[0] === 'help') { out(NEW_HELP); return 0; }
  const opts = parseArgs(argv);
  const words = argv.filter(a => !a.startsWith('-') && a !== opts.lang && a !== opts.config);
  const name = words[0] || '';
  const kind = words[1] || (['project','rule','test','util'].includes(name) ? name : 'project');
  const id = ['project','rule','test','util'].includes(name) ? (words[1] || 'example') : (name || 'example');
  if (kind === 'project') {
    out('Creating a new ast-grep project...');
    fs.mkdirSync('rules', { recursive: true }); fs.mkdirSync('rule-tests', { recursive: true }); fs.mkdirSync('utils', { recursive: true });
    if (!fs.existsSync('sgconfig.yml')) fs.writeFileSync('sgconfig.yml', 'ruleDirs:\n  - rules\n\ntestConfigs:\n  - testDir: rule-tests\n\nutilDirs:\n  - utils\n');
    fs.writeFileSync('rules/.gitkeep', ''); fs.writeFileSync('rule-tests/.gitkeep', ''); fs.writeFileSync('utils/.gitkeep', '');
    out('Your new ast-grep project has been created!');
  } else if (kind === 'rule') {
    fs.mkdirSync('rules', { recursive: true });
    fs.writeFileSync(path.join('rules', `${id}.yml`), `id: ${id}\nlanguage: ${opts.lang || 'JavaScript'}\nrule:\n  pattern: TODO\nmessage: TODO\n`);
    out(`Created rule ${id}`);
  } else if (kind === 'test') {
    fs.mkdirSync('rule-tests', { recursive: true });
    fs.writeFileSync(path.join('rule-tests', `${id}.yml`), `id: ${id}\nvalid:\n  - code: ''\ninvalid:\n  - code: ''\n`);
    out(`Created test ${id}`);
  } else if (kind === 'util') {
    fs.mkdirSync('utils', { recursive: true });
    fs.writeFileSync(path.join('utils', `${id}.yml`), `id: ${id}\nrule:\n  pattern: TODO\n`);
    out(`Created util ${id}`);
  }
  return 0;
}

function completions(shell) {
  if (!shell || shell === 'bash') out('_ast_grep() { COMPREPLY=(); }\ncomplete -F _ast_grep executable');
  else if (shell === 'fish') out('complete -c executable -f');
  else if (shell === 'zsh') out('#compdef executable\n_arguments "1: :((run scan test new lsp completions help))"');
  else out('');
  return 0;
}

function main() {
  let argv = process.argv.slice(2);
  if (!argv.length || ((argv[0] === '--help' || argv[0] === '-h') && argv.length === 1)) { out(ROOT_HELP); return 0; }
  if (argv.includes('--version') || argv.includes('-V')) { out(VERSION); return 0; }
  let cmd = argv[0];
  const commands = new Set(['run','scan','test','new','lsp','completions','help']);
  if (!commands.has(cmd)) cmd = 'run'; else argv = argv.slice(1);
  if (cmd === 'help') { out(ROOT_HELP); return 0; }
  if ((argv.includes('--help') || argv.includes('-h')) && cmd === 'run') { out(RUN_HELP); return 0; }
  if ((argv.includes('--help') || argv.includes('-h')) && cmd === 'scan') { out(SCAN_HELP); return 0; }
  if ((argv.includes('--help') || argv.includes('-h')) && cmd === 'test') { out(TEST_HELP); return 0; }
  if ((argv.includes('--help') || argv.includes('-h')) && cmd === 'new') { out(NEW_HELP); return 0; }
  if (cmd === 'run') return runSearch(parseArgs(argv, 'run'));
  if (cmd === 'scan') return runScan(parseArgs(argv, 'scan'));
  if (cmd === 'test') { out('No test cases found'); return 0; }
  if (cmd === 'new') return runNew(argv);
  if (cmd === 'lsp') { err('language server is not available in this reimplementation'); return 1; }
  if (cmd === 'completions') return completions(argv.find(a => !a.startsWith('-')));
  return 0;
}

process.exitCode = main();
