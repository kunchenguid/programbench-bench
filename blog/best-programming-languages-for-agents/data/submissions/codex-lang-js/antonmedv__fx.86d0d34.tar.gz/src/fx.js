#!/usr/bin/env node
const fs = require('fs');
const vm = require('vm');

const VERSION = '39.2.0';
const HELP = `
  fx ${VERSION}
    Terminal JSON viewer

  Usage
    fx data.json
    fx data.json .field
    curl ... | fx

  Flags
    -h, --help            print help
    -v, --version         print version
    --themes              print themes
    --comp <shell>        print completion script
    -r, --raw             treat input as a raw string
    -s, --slurp           read all inputs into an array
    --yaml                parse input as YAML
    --toml                parse input as TOML
    --strict              strict mode
    --no-inline           disable inlining in output
    --game-of-life        play the game of life

  More info
    https://fx.wtf

  Author
    Anton Medvedev <anton@medv.io>
`;

function out(s='') { process.stdout.write(String(s) + '\n'); }
function err(s='') { process.stderr.write(String(s) + '\n'); }

function printHelp(){ process.stdout.write(HELP); }
function printThemes(){
  for (let i=0;i<10;i++) {
    out(`export FX_THEME="${i}"`);
    out('{');
    out('  "string": "Fox jumps over the lazy dog",');
    out('  "number": 1234567890,');
    out('  "boolean": true,');
    out('  "null": null,');
    out('  "collapsed": {"preview":…}');
    out('}');
  }
}
function printComp(shell){
  if (shell === 'bash') out('complete -o filenames -C fx fx');
  else if (shell === 'fish') out("complete --command fx --arguments '(COMP_FISH=(commandline -cp) fx)'");
  else if (shell === 'zsh') process.stdout.write([
    '#compdef fx', '', '_fx() {', '    local -a reply',
    '    reply=("${(@f)$(COMP_ZSH="${LBUFFER}" fx)}")',
    '    compadd -- ${reply[@]}', '}', 'compdef _fx fx', ''
  ].join('\n'));
  else out('unknown shell type');
}

function ttyPanic(){
  err('panic: could not open a new TTY: open /dev/tty: no such device or address');
  err('');
  err('goroutine 1 [running]:');
  err('main.main()');
  err('\t/workspace/main.go:317 +0x191e');
  process.exit(2);
}

function splitTopLevelObjects(s){
  const vals=[]; let start=-1, depth=0, inStr=false, esc=false;
  for (let i=0;i<s.length;i++){
    const c=s[i];
    if (inStr){ if(esc) esc=false; else if(c==='\\') esc=true; else if(c==='"') inStr=false; continue; }
    if (c==='"'){ inStr=true; if(start<0) start=i; continue; }
    if ('[{'.includes(c)){ if(depth===0) start=i; depth++; }
    else if (']}'.includes(c)){ depth--; if(depth===0 && start>=0){ vals.push(s.slice(start,i+1)); start=-1; } }
  }
  return vals;
}

function parseScalar(v){
  v = String(v).trim();
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) return v.slice(1,-1);
  if (v === 'true') return true; if (v === 'false') return false; if (v === 'null' || v === '~') return null;
  if (/^-?\d+(\.\d+)?$/.test(v)) return Number(v);
  return v;
}
function parseYaml(s){
  const lines=s.replace(/\r/g,'').split('\n').filter(l=>l.trim() && !l.trim().startsWith('#'));
  const obj={}; let curKey=null;
  for (const line of lines){
    const m=line.match(/^\s*([A-Za-z0-9_-]+):\s*(.*)$/);
    if (m){ curKey=m[1]; obj[curKey]=m[2] ? parseScalar(m[2]) : []; continue; }
    const a=line.match(/^\s*-\s*(.*)$/); if(a && curKey) obj[curKey].push(parseScalar(a[1]));
  }
  return obj;
}
function parseToml(s){
  const obj={}; let section=obj;
  for (let line of s.replace(/\r/g,'').split('\n')){
    line=line.trim(); if(!line || line.startsWith('#')) continue;
    const sm=line.match(/^\[([^\]]+)\]$/); if(sm){ section=obj[sm[1]]={}; continue; }
    const i=line.indexOf('='); if(i>=0) section[line.slice(0,i).trim()] = parseScalar(line.slice(i+1));
  }
  return obj;
}
function parseInputs(text, opts){
  if (opts.raw) return opts.slurp ? text.split(/\n/).filter(x=>x.length) : [text];
  if (opts.yaml) return [parseYaml(text)];
  if (opts.toml) return [parseToml(text)];
  const trimmed=text.trim(); if(!trimmed) return [];
  let pieces=[];
  if (/\n/.test(trimmed)) {
    const lines=trimmed.split(/\n+/).filter(Boolean);
    let ok=true;
    for (const l of lines){ try { pieces.push(JSON.parse(l)); } catch { ok=false; break; } }
    if (ok) return opts.slurp ? [pieces] : pieces;
  }
  try { const one=JSON.parse(trimmed); return opts.slurp ? [Array.isArray(one)?one:[one]] : [one]; } catch(e) {}
  const chunks=splitTopLevelObjects(trimmed);
  if (chunks.length){ pieces=chunks.map(c=>JSON.parse(c)); return opts.slurp ? [pieces] : pieces; }
  throw new SyntaxError('invalid character');
}
function format(v){
  if (v === undefined) return 'undefined';
  if (typeof v === 'string') return v;
  if (typeof v === 'number' || typeof v === 'boolean' || v === null) return String(v);
  return JSON.stringify(v, null, 2);
}
function syntaxError(expr, msg, pos=0){
  err(''); err(`  ${expr}`); err(`  ${' '.repeat(Math.max(0,pos))}^${'^'.repeat(Math.max(0,expr.length-pos-1))}`); err(''); err(msg); process.exit(1);
}
function dotToJs(expr){
  if (expr === '.[]') return 'x';
  return 'x' + expr.replace(/\.([A-Za-z_$][\w$-]*)/g, (_,k)=> /^[A-Za-z_$][\w$]*$/.test(k) ? `?.${k}` : `?.[${JSON.stringify(k)}]`);
}
function compile(expr){
  expr = expr.trim();
  if (!expr) return x=>x;
  if (expr.includes('|')) syntaxError(expr, 'Unexpected token | ', expr.indexOf('|'));
  let code;
  if (expr.startsWith('.')) code = dotToJs(expr);
  else if (/^\s*(x|this)\s*=>/.test(expr)) code = `(${expr})(x)`;
  else if (expr === 'keys') code = 'Object.keys(x)';
  else if (expr === 'values') code = 'Object.values(x)';
  else if (expr === 'entries') code = 'Object.entries(x)';
  else if (/^(map|filter|find|every|some|reduce|flatMap|sort|reverse|slice|join)\s*\(/.test(expr)) code = `x.${expr}`;
  else code = expr;
  if (!/^\s*(x|this)\s*=>/.test(expr)) code = code.replace(/\bthis\b/g, 'x');
  return function(x){
    const sandbox = {x, console, JSON, Math, Object, Array, Number, String, Boolean, Date, RegExp, undefined};
    sandbox.globalThis = sandbox;
    return vm.runInNewContext(code, sandbox, {timeout:1000});
  };
}
function applyFilters(v, filters){ for (const f of filters) v = compile(f)(v); return v; }

function main(){
  const argv=process.argv.slice(2), opts={raw:false,slurp:false,yaml:false,toml:false};
  const args=[]; let comp=null;
  for(let i=0;i<argv.length;i++){
    const a=argv[i];
    if(a==='-h'||a==='--help') return printHelp();
    if(a==='-v'||a==='--version') return out(VERSION);
    if(a==='--themes') return printThemes();
    if(a==='--comp'){ comp=argv[++i]||''; return printComp(comp); }
    if(a==='-r'||a==='--raw') opts.raw=true; else if(a==='-s'||a==='--slurp') opts.slurp=true;
    else if(a==='--yaml') opts.yaml=true; else if(a==='--toml') opts.toml=true;
    else if(a==='--strict'||a==='--no-inline'||a==='--game-of-life') {}
    else if(a.startsWith('-') && a !== '-') {}
    else args.push(a);
  }
  let files=[], filters=[];
  for(const a of args){ if(files.length===0 && !a.startsWith('.') && fs.existsSync(a) && fs.statSync(a).isFile()) files.push(a); else filters.push(a); }
  let input='';
  if(files.length) input = files.map(f=>fs.readFileSync(f,'utf8')).join('\n');
  else { try { input = fs.readFileSync(0,'utf8'); } catch { input=''; } }
  if(filters.length===0 && !opts.slurp) ttyPanic();
  let values;
  try { values=parseInputs(input, opts); } catch(e){ ttyPanic(); }
  for (const val of values){
    try { out(format(applyFilters(val, filters))); }
    catch(e){ syntaxError(filters.join(' '), `${e.name}: ${e.message}`, 0); }
  }
}
main();
