#!/usr/bin/env node
const fs = require('fs');

const VERSION = 'htmlq 0.4.0';
const VOID = new Set(['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']);

class Node {
  constructor(type, name = '', attrs = {}, data = '') {
    this.type = type;
    this.name = name;
    this.attrs = attrs;
    this.data = data;
    this.children = [];
    this.parent = null;
  }
}

function usage() {
  return `htmlq 0.4.0
Michael Maclean <michael@mgdm.net>
Runs CSS selectors on HTML

USAGE:
    executable [FLAGS] [OPTIONS] [--] [selector]...

FLAGS:
    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to
                               the value of --base, if supplied
    -h, --help                 Prints help information
    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace
    -p, --pretty               Pretty-print the serialised output
    -t, --text                 Output only the contents of text nodes inside selected elements
    -V, --version              Prints version information

OPTIONS:
    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements
    -b, --base <base>                   Use this URL as the base for links
    -f, --filename <FILE>               The input file. Defaults to stdin
    -o, --output <FILE>                 The output file. Defaults to stdout
    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple
                                        times

ARGS:
    <selector>...    The CSS expression to select [default: html]
`;
}

function parseArgs(argv) {
  const opts = { text:false, pretty:false, ignoreWhitespace:false, detectBase:false, attr:null, base:null, filename:null, output:null, remove:[], selectors:[] };
  let end = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (end) { opts.selectors.push(a); continue; }
    if (a === '--') { end = true; continue; }
    if (a === '-h' || a === '--help') { opts.help = true; continue; }
    if (a === '-V' || a === '--version') { opts.version = true; continue; }
    if (a === '-t' || a === '--text') { opts.text = true; continue; }
    if (a === '-p' || a === '--pretty') { opts.pretty = true; continue; }
    if (a === '-w' || a === '--ignore-whitespace') { opts.ignoreWhitespace = true; continue; }
    if (a === '-B' || a === '--detect-base') { opts.detectBase = true; continue; }
    if (a === '-a' || a === '--attribute') { if (++i >= argv.length) dieArg(`The argument '${a} <attribute>' requires a value but none was supplied`); opts.attr = argv[i]; continue; }
    if (a.startsWith('--attribute=')) { opts.attr = a.slice(12); continue; }
    if (a === '-b' || a === '--base') { if (++i >= argv.length) dieArg(`The argument '${a} <base>' requires a value but none was supplied`); opts.base = argv[i]; continue; }
    if (a.startsWith('--base=')) { opts.base = a.slice(7); continue; }
    if (a === '-f' || a === '--filename') { if (++i >= argv.length) dieArg(`The argument '${a} <FILE>' requires a value but none was supplied`); opts.filename = argv[i]; continue; }
    if (a.startsWith('--filename=')) { opts.filename = a.slice(11); continue; }
    if (a === '-o' || a === '--output') { if (++i >= argv.length) dieArg(`The argument '${a} <FILE>' requires a value but none was supplied`); opts.output = argv[i]; continue; }
    if (a.startsWith('--output=')) { opts.output = a.slice(9); continue; }
    if (a === '-r' || a === '--remove-nodes') { if (++i >= argv.length) dieArg(`The argument '${a} <SELECTOR>' requires a value but none was supplied`); opts.remove.push(argv[i]); continue; }
    if (a.startsWith('--remove-nodes=')) { opts.remove.push(a.slice(15)); continue; }
    if (a.startsWith('-') && a !== '-') dieArg(`Found argument '${a}' which wasn't expected, or isn't valid in this context`);
    opts.selectors.push(a);
  }
  if (opts.selectors.length === 0) opts.selectors = ['html'];
  return opts;
}

function dieArg(msg) {
  process.stderr.write(`error: ${msg}\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [--] [selector]...\n\nFor more information try --help\n`);
  process.exit(1);
}

function add(parent, child) { child.parent = parent; parent.children.push(child); return child; }

function parseAttrs(s) {
  const attrs = {};
  const re = /([A-Za-z_:][-A-Za-z0-9_:.]*)(?:\s*=\s*("[^"]*"|'[^']*'|[^\s"'=<>`]+))?/g;
  let m;
  while ((m = re.exec(s))) {
    let v = m[2] == null ? '' : m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    attrs[m[1].toLowerCase()] = decodeEntities(v);
  }
  return attrs;
}

function parseHTML(input) {
  const root = new Node('root');
  let stack = [root];
  const re = /<!--[^]*?-->|<![^>]*>|<[^>]+>|[^<]+/g;
  let m;
  while ((m = re.exec(input))) {
    const tok = m[0];
    const parent = stack[stack.length - 1];
    if (tok.startsWith('<!--') || /^<!/i.test(tok)) continue;
    if (tok[0] !== '<') { add(parent, new Node('text', '', {}, decodeEntities(tok))); continue; }
    if (/^<\//.test(tok)) {
      const name = tok.replace(/^<\/?\s*/, '').replace(/\s*>$/, '').toLowerCase();
      for (let j = stack.length - 1; j > 0; j--) {
        if (stack[j].name === name) { stack.length = j; break; }
      }
      continue;
    }
    const selfClose = /\/\s*>$/.test(tok);
    const inner = tok.slice(1, tok.length - (selfClose ? 2 : 1)).trim();
    const mm = inner.match(/^([^\s/>]+)/);
    if (!mm) continue;
    const name = mm[1].toLowerCase();
    const rest = inner.slice(mm[0].length);
    const el = add(parent, new Node('element', name, parseAttrs(rest)));
    if (!selfClose && !VOID.has(name)) stack.push(el);
  }
  return normalizeDocument(root);
}

function normalizeDocument(root) {
  let html = root.children.find(n => n.type === 'element' && n.name === 'html');
  if (!html) {
    html = new Node('element', 'html');
    const body = new Node('element', 'body');
    const head = new Node('element', 'head');
    for (const ch of root.children) { ch.parent = body; body.children.push(ch); }
    head.parent = html; body.parent = html; html.children = [head, body]; root.children = [html]; html.parent = root;
    return root;
  }
  const hasHead = html.children.some(n => n.type === 'element' && n.name === 'head');
  const hasBody = html.children.some(n => n.type === 'element' && n.name === 'body');
  if (!hasHead) { const h = new Node('element','head'); h.parent = html; html.children.unshift(h); }
  if (!hasBody) {
    const b = new Node('element','body'); b.parent = html;
    const moved = html.children.filter(n => !(n.type === 'element' && (n.name === 'head' || n.name === 'body')));
    html.children = html.children.filter(n => !moved.includes(n));
    for (const ch of moved) { ch.parent = b; b.children.push(ch); }
    html.children.push(b);
  }
  return root;
}

const ENT = { amp:'&', lt:'<', gt:'>', quot:'"', apos:"'", nbsp:'\u00a0' };
function decodeEntities(s) { return s.replace(/&(#x[0-9a-f]+|#\d+|[a-zA-Z][a-zA-Z0-9]+);/g, (m, e) => {
  if (e[0] === '#') { const n = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2),16) : parseInt(e.slice(1),10); return Number.isFinite(n) ? String.fromCodePoint(n) : m; }
  return ENT[e] ?? m;
}); }
function escText(s) { return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function escAttr(s) { return escText(String(s)).replace(/"/g,'&quot;'); }

function serialize(n) {
  if (n.type === 'text') return escText(n.data);
  if (n.type !== 'element') return n.children.map(serialize).join('');
  const attrs = Object.keys(n.attrs).sort().map(k => `${k}="${escAttr(n.attrs[k])}"`).join(' ');
  const open = attrs ? `<${n.name} ${attrs}>` : `<${n.name}>`;
  if (VOID.has(n.name)) return open;
  return open + n.children.map(serialize).join('') + `</${n.name}>`;
}

function pretty(n, depth=0) {
  if (n.type === 'text') return escText(n.data);
  if (n.type !== 'element') return n.children.map(c => pretty(c, depth)).join('');
  const ind = '  '.repeat(depth);
  const attrs = Object.keys(n.attrs).sort().map(k => `${k}="${escAttr(n.attrs[k])}"`).join(' ');
  const open = attrs ? `<${n.name} ${attrs}>` : `<${n.name}>`;
  if (VOID.has(n.name)) return `\n${ind}${open}`;
  if (n.children.length === 0) return `\n${ind}${open}</${n.name}>`;
  const onlyText = n.children.every(c => c.type === 'text');
  if (onlyText) return `\n${ind}${open}${n.children.map(serialize).join('')}</${n.name}>`;
  return `\n${ind}${open}` + n.children.map(c => c.type === 'text' ? escText(c.data) : pretty(c, depth + 1)).join('') + `\n${ind}</${n.name}>`;
}

function allElements(root) { const out=[]; (function rec(n){ for (const c of n.children||[]) { if (c.type === 'element') { out.push(c); rec(c); } } })(root); return out; }
function prevElement(n) { if (!n.parent) return null; const a = n.parent.children.filter(c=>c.type==='element'); const i = a.indexOf(n); return i > 0 ? a[i-1] : null; }
function elementIndex(n, sameType=false) { if (!n.parent) return 0; const a = n.parent.children.filter(c=>c.type==='element' && (!sameType || c.name===n.name)); return a.indexOf(n)+1; }

function splitGroups(sel) { return splitTop(sel, ',').map(s=>s.trim()).filter(Boolean); }
function splitTop(s, sep) {
  const out=[]; let cur='', q=null, br=0, par=0;
  for (let i=0;i<s.length;i++) { const ch=s[i];
    if (q) { cur+=ch; if (ch===q) q=null; continue; }
    if (ch==='"'||ch==="'") { q=ch; cur+=ch; continue; }
    if (ch==='[') br++; else if (ch===']') br--; else if (ch==='(') par++; else if (ch===')') par--;
    if (ch===sep && br===0 && par===0) { out.push(cur); cur=''; } else cur+=ch;
  }
  out.push(cur); return out;
}

function tokenizeSelector(s) {
  const toks=[]; let cur='', comb=' ', q=null, br=0, par=0;
  function push(){ if(cur.trim()){ toks.push({comb, comp:parseCompound(cur.trim())}); cur=''; comb=' '; } }
  for (let i=0;i<s.length;i++) { const ch=s[i];
    if (q) { cur+=ch; if (ch===q) q=null; continue; }
    if (ch==='"'||ch==="'") { q=ch; cur+=ch; continue; }
    if (ch==='[') br++; else if (ch===']') br--; else if (ch==='(') par++; else if (ch===')') par--;
    if (br===0 && par===0 && (ch==='>' || ch==='+' || ch==='~')) { push(); comb=ch; while (s[i+1]===' ') i++; continue; }
    if (br===0 && par===0 && /\s/.test(ch)) { push(); while (/\s/.test(s[i+1]||'')) i++; continue; }
    cur+=ch;
  }
  push(); if (toks.length) toks[0].comb = null; return toks;
}

function parseCompound(s) {
  const c = { tag:null, id:null, classes:[], attrs:[], pseudos:[], not:null };
  let i=0; const tag = s.match(/^([A-Za-z][\w-]*|\*)/); if (tag) { c.tag = tag[1].toLowerCase(); i = tag[0].length; }
  while (i < s.length) {
    const ch=s[i];
    if (ch === '#') { const m=s.slice(i+1).match(/^[-\w:.]+/); c.id=m?m[0]:''; i += 1 + (m?m[0].length:0); continue; }
    if (ch === '.') { const m=s.slice(i+1).match(/^[-\w:.]+/); c.classes.push(m?m[0]:''); i += 1 + (m?m[0].length:0); continue; }
    if (ch === '[') { const j=findClose(s,i,'[',']'); const body=s.slice(i+1,j).trim(); c.attrs.push(parseAttrSel(body)); i=j+1; continue; }
    if (ch === ':') { const m=s.slice(i+1).match(/^[-\w]+/); const name=m?m[0]:''; i += 1+name.length; let arg=null; if (s[i]==='(') { const j=findClose(s,i,'(',')'); arg=s.slice(i+1,j).trim(); i=j+1; } if (name==='not' && arg) c.not=parseCompound(arg); else c.pseudos.push({name,arg}); continue; }
    i++;
  }
  return c;
}
function findClose(s,i,open,close){ let q=null,d=0; for(let j=i;j<s.length;j++){ const ch=s[j]; if(q){ if(ch===q) q=null; continue;} if(ch==='"'||ch==="'"){q=ch; continue;} if(ch===open)d++; if(ch===close&&--d===0)return j;} return s.length-1; }
function parseAttrSel(b){ const m=b.match(/^([^\s~|^$*!=]+)\s*(?:([~|^$*]?=)\s*(.*))?$/); if(!m) return {name:b.toLowerCase(),op:null,val:null}; let v=m[3]; if(v!=null){ v=v.trim(); if((v[0]==='"'&&v.at(-1)==='"')||(v[0]==="'"&&v.at(-1)==="'")) v=v.slice(1,-1); v=decodeEntities(v); } return {name:m[1].toLowerCase(),op:m[2]||null,val:v}; }

function matchCompound(n,c){
  if(n.type!=='element') return false;
  if(c.tag && c.tag !== '*' && n.name !== c.tag) return false;
  if(c.id != null && n.attrs.id !== c.id) return false;
  const cls=(n.attrs.class||'').split(/\s+/).filter(Boolean);
  for(const cl of c.classes) if(!cls.includes(cl)) return false;
  for(const a of c.attrs){ if(!(a.name in n.attrs)) return false; if(a.op){ const v=n.attrs[a.name]; const x=a.val; if(a.op==='=' && v!==x) return false; if(a.op==='~=' && !v.split(/\s+/).includes(x)) return false; if(a.op==='|=' && !(v===x || v.startsWith(x+'-'))) return false; if(a.op==='^=' && !v.startsWith(x)) return false; if(a.op==='$=' && !v.endsWith(x)) return false; if(a.op==='*=' && !v.includes(x)) return false; } }
  if(c.not && matchCompound(n,c.not)) return false;
  for(const p of c.pseudos){
    if(p.name==='first-child' && elementIndex(n)!==1) return false;
    else if(p.name==='last-child' && n.parent && elementIndex(n)!==n.parent.children.filter(c=>c.type==='element').length) return false;
    else if(p.name==='first-of-type' && elementIndex(n,true)!==1) return false;
    else if(p.name==='nth-child') { const idx=elementIndex(n); if(!nthMatches(idx,p.arg)) return false; }
    else if(p.name==='nth-of-type') { const idx=elementIndex(n,true); if(!nthMatches(idx,p.arg)) return false; }
    else if(p.name==='empty' && n.children.length) return false;
    else if(p.name==='root' && (!n.parent || n.parent.type!=='root')) return false;
    else return false;
  }
  return true;
}
function nthMatches(idx,arg){ arg=(arg||'').replace(/\s+/g,'').toLowerCase(); if(arg==='odd') return idx%2===1; if(arg==='even') return idx%2===0; if(/^\d+$/.test(arg)) return idx===Number(arg); const m=arg.match(/^([+-]?\d*)n([+-]?\d+)?$/); if(!m)return false; let a=m[1]; if(a===''||a==='+')a=1; else if(a==='-')a=-1; else a=Number(a); const b=m[2]?Number(m[2]):0; return a===0 ? idx===b : (idx-b)/a>=0 && Number.isInteger((idx-b)/a); }

function matchesTokens(n,toks,idx=toks.length-1){
  if(idx<0) return true; if(!matchCompound(n,toks[idx].comp)) return false; if(idx===0) return true;
  const comb=toks[idx].comb;
  if(comb==='>') return n.parent && n.parent.type==='element' && matchesTokens(n.parent,toks,idx-1);
  if(comb==='+') { const p=prevElement(n); return p && matchesTokens(p,toks,idx-1); }
  if(comb==='~') { let p=prevElement(n); while(p){ if(matchesTokens(p,toks,idx-1)) return true; p=prevElement(p); } return false; }
  let p=n.parent; while(p && p.type==='element'){ if(matchesTokens(p,toks,idx-1)) return true; p=p.parent; } return false;
}
function select(root, selector){ const seen=new Set(), out=[]; for(const g of splitGroups(selector)){ const toks=tokenizeSelector(g); for(const e of allElements(root)){ if(matchesTokens(e,toks) && !seen.has(e)){ seen.add(e); out.push(e); } } } return out; }

function removeNodes(root, selector){ let count=0; for(const n of select(root, selector)){ if(n.parent){ const i=n.parent.children.indexOf(n); if(i>=0){ n.parent.children.splice(i,1); count++; } n.parent=null; } } return count; }
function textContent(n){ if(n.type==='text') return n.data; return (n.children||[]).map(textContent).join(''); }
function textNodes(n,out=[]){ if(n.type==='text') out.push(n); else for(const c of n.children||[]) textNodes(c,out); return out; }
function detectBase(root){ const b=select(root,'base[href]')[0]; return b ? b.attrs.href : null; }
function maybeUrl(value, attr, base){ if(attr !== 'href' || !base) return value; try { return new URL(value, base).toString(); } catch { return value; } }

function main(){
  const opts=parseArgs(process.argv.slice(2));
  if(opts.help){ process.stdout.write(usage()); return; }
  if(opts.version){ process.stdout.write(VERSION+'\n'); return; }
  let input;
  try { input = opts.filename ? fs.readFileSync(opts.filename,'utf8') : fs.readFileSync(0,'utf8'); } catch(e) { process.stderr.write(`should have opened input file: ${e.message}\n`); process.exit(101); }
  const root=parseHTML(input);
  let removedAny = false;
  for(const r of opts.remove) if (removeNodes(root,r) > 0) removedAny = true;
  const base = opts.detectBase ? (detectBase(root) || opts.base) : opts.base;
  let output='';
  if (removedAny) {
    if(opts.output) fs.writeFileSync(opts.output, ''); else process.stdout.write('');
    return;
  }
  for(const sel of [opts.selectors.join(' ')]){
    for(const n of select(root, sel)){
      if(opts.attr){ if(opts.attr in n.attrs) output += maybeUrl(n.attrs[opts.attr], opts.attr, base) + '\n'; }
      else if(opts.text){
        if(opts.ignoreWhitespace){ for(const t of textNodes(n)) if(!/^\s*$/.test(t.data)) output += t.data + '\n'; output += '\n'; }
        else output += textContent(n) + '\n';
      } else output += (opts.pretty ? pretty(n) : serialize(n)) + '\n';
    }
  }
  if(opts.output) fs.writeFileSync(opts.output, output); else process.stdout.write(output);
}

main();
