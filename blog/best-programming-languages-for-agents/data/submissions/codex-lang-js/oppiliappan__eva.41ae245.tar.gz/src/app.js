#!/usr/bin/env node
'use strict';

const VERSION = 'eva 0.3.1';

class CalcError extends Error { constructor(kind, message) { super(message); this.kind = kind; } }

function help() {
  return `Calculator REPL similar to bc(1)\n\nUsage: executable [OPTIONS] [INPUT]\n\nArguments:\n  [INPUT]  Optional expression string to run eva in command mode\n\nOptions:\n  -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]\n  -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]\n  -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]\n  -h, --help                     Print help\n  -V, --version                  Print version`;
}

function parseArgs(argv) {
  const opts = { fix: 10, base: 10, angle: 'degree', input: null };
  let stop = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!stop && a === '--') { stop = true; continue; }
    if (!stop && (a === '-h' || a === '--help')) { opts.help = true; return opts; }
    if (!stop && (a === '-V' || a === '--version')) { opts.version = true; return opts; }
    if (!stop && (a === '-f' || a === '--fix')) {
      const v = argv[++i]; const n = Number(v);
      if (!Number.isInteger(n) || n < 1 || n > 64) throwArg(`error: invalid value '${v}' for '--fix <FIX>': ${v} is not in 1..=64\n\nFor more information, try '--help'.`);
      opts.fix = n; continue;
    }
    if (!stop && (a === '-b' || a === '--base')) {
      const v = argv[++i]; const n = Number(v);
      if (!Number.isInteger(n) || n < 1 || n > 36) throwArg(`error: invalid value '${v}' for '--base <RADIX>': ${v} is not in 1..=36\n\nFor more information, try '--help'.`);
      opts.base = n; continue;
    }
    if (!stop && (a === '-a' || a === '--angle_unit')) {
      const v = argv[++i];
      if (!['degree','radian','gradian'].includes(v)) throwArg(`error: invalid value '${v}' for '--angle_unit <angle_unit>'\n\nFor more information, try '--help'.`);
      opts.angle = v; continue;
    }
    if (!stop && a.startsWith('-')) {
      throwArg(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.`);
    }
    if (opts.input == null) opts.input = a;
    else throwArg(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.`);
  }
  return opts;
}
function throwArg(s) { const e = new Error(s); e.arg = true; throw e; }

function tokenize(s) {
  const raw = [];
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (/\s/.test(c)) { i++; continue; }
    if (/[0-9.]/.test(c)) {
      let j = i, dots = 0;
      while (j < s.length && /[0-9.]/.test(s[j])) { if (s[j] === '.') dots++; j++; }
      const text = s.slice(i, j);
      if (dots > 1 || text === '.') throw new CalcError('parser', 'Invalid number');
      raw.push({t:'num', v:Number(text), text}); i = j; continue;
    }
    if (/[A-Za-z_]/.test(c)) {
      let j = i;
      while (j < s.length && /[A-Za-z_]/.test(s[j])) j++;
      raw.push({t:'id', v:s.slice(i,j)}); i = j; continue;
    }
    if (c === '*' && s[i+1] === '*') { raw.push({t:'op', v:'^'}); i += 2; continue; }
    if ('+-*/^(),'.includes(c)) { raw.push({t: c === ',' ? 'comma' : (c === '(' || c === ')' ? c : 'op'), v:c}); i++; continue; }
    throw new CalcError('parser', 'Unexpected token');
  }
  const out = [];
  function begins(tok) { return tok && (tok.t === 'num' || tok.t === 'id' || tok.t === '('); }
  function ends(tok) { return tok && (tok.t === 'num' || tok.t === 'id' || tok.t === ')'); }
  for (let k = 0; k < raw.length; k++) {
    const prev = out[out.length-1], cur = raw[k];
    const idCall = prev && prev.t === 'id' && cur.t === '(' && isFunction(prev.v);
    if (ends(prev) && begins(cur) && !idCall) out.push({t:'op', v:'*', implicit:true});
    out.push(cur);
  }
  return out;
}

function isFunction(n) { return Object.prototype.hasOwnProperty.call(functions, n); }

class Parser {
  constructor(tokens, ctx) { this.tokens = tokens; this.pos = 0; this.ctx = ctx; }
  peek() { return this.tokens[this.pos]; }
  eat(t, v) { const p = this.peek(); if (p && p.t === t && (v == null || p.v === v)) { this.pos++; return p; } return null; }
  parse() { const v = this.expr(); return v; }
  expr() { let v = this.term(); while (true) { if (this.eat('op','+')) v += this.term(); else if (this.eat('op','-')) v -= this.term(); else return v; } }
  term() { let v = this.power(); while (true) { if (this.eat('op','*')) v *= this.power(); else if (this.eat('op','/')) { const d = this.power(); if (d === 0) throw new CalcError('math','Divide by zero error!'); v /= d; } else return v; } }
  power() { let v = this.unary(); if (this.eat('op','^')) v = Math.pow(v, this.power()); return checkNum(v); }
  unary() { if (this.eat('op','+')) return this.unary(); if (this.eat('op','-')) return -this.unary(); return this.primary(); }
  primary() {
    const tok = this.peek();
    if (!tok) throw new CalcError('parser','Too many operators, too few operands');
    if (this.eat('num')) return tok.v;
    if (this.eat('(')) { const v = this.expr(); this.eat(')'); return v; }
    if (this.eat('id')) {
      const name = tok.v;
      if (name === '_') return this.ctx.prev || 0;
      if (name === 'pi') return Math.PI;
      if (name === 'e') return Math.E;
      if (isFunction(name)) {
        if (!this.eat('(')) throw new CalcError('parser','Function requires parentheses');
        const args = [];
        if (!this.eat(')')) {
          args.push(this.expr());
          while (this.eat('comma')) args.push(this.expr());
          this.eat(')');
        }
        return callFunc(name, args, this.ctx);
      }
      throw new CalcError('parser', 'Too many operators, too few operands');
    }
    throw new CalcError('parser','Too many operators, too few operands');
  }
}

const functions = {
  sin:1, cos:1, tan:1, csc:1, sec:1, cot:1, sinh:1, cosh:1, tanh:1,
  asin:1, acos:1, atan:1, acsc:1, asec:1, acot:1,
  ln:1, log2:1, log10:1, sqrt:1, ceil:1, floor:1, abs:1,
  log:2, nroot:2
};
function rad(x, ctx) { return ctx.angle === 'radian' ? x : x * Math.PI / 180; }
function domain(ok) { if (!ok) throw new CalcError('domain','Out of bounds!'); }
function callFunc(n, a, ctx) {
  const need = functions[n]; if (a.length !== need) throw new CalcError('parser','Wrong number of arguments');
  let x = a[0], y = a[1], r;
  switch(n) {
    case 'sin': r = Math.sin(rad(x,ctx)); break; case 'cos': r = Math.cos(rad(x,ctx)); break; case 'tan': r = Math.tan(rad(x,ctx)); break;
    case 'csc': r = 1/Math.sin(rad(x,ctx)); break; case 'sec': r = 1/Math.cos(rad(x,ctx)); break; case 'cot': r = 1/Math.tan(rad(x,ctx)); break;
    case 'sinh': r = Math.sinh(x); break; case 'cosh': r = Math.cosh(x); break; case 'tanh': r = Math.tanh(x); break;
    case 'asin': domain(x >= -1 && x <= 1); r = Math.asin(x); break; case 'acos': domain(x >= -1 && x <= 1); r = Math.acos(x); break; case 'atan': r = Math.atan(x); break;
    case 'acsc': domain(Math.abs(x) >= 1); r = Math.asin(1/x); break; case 'asec': domain(Math.abs(x) >= 1); r = Math.acos(1/x); break; case 'acot': r = Math.atan(1/x); break;
    case 'ln': domain(x > 0); r = Math.log(x); break; case 'log2': domain(x > 0); r = Math.log2(x); break; case 'log10': domain(x > 0); r = Math.log10(x); break;
    case 'sqrt': domain(x >= 0); r = Math.sqrt(x); break; case 'ceil': r = Math.ceil(x); break; case 'floor': r = Math.floor(x); break; case 'abs': r = Math.abs(x); break;
    case 'log': domain(x > 0 && y > 0 && y !== 1); r = Math.log(x)/Math.log(y); break;
    case 'nroot': domain(!(x < 0 && Math.abs(y % 2) < 1e-12)); r = Math.pow(x, 1/y); break;
  }
  return checkNum(r);
}
function checkNum(v) { if (Number.isNaN(v)) throw new CalcError('domain','Out of bounds!'); if (!Number.isFinite(v)) throw new CalcError('math','Divide by zero error!'); return Math.abs(v) < 5e-15 ? 0 : v; }
function evaluate(s, ctx) { const p = new Parser(tokenize(s), ctx); const v = p.parse(); return checkNum(v); }

function digit(n) { return n < 10 ? String(n) : String.fromCharCode(55+n); }
function toBase(v, base) {
  if (base === 10) return null;
  if (base === 1) return ''.padStart(Math.max(0, Math.floor(v)), '1') + '.0';
  const neg = v < 0; v = Math.abs(v);
  let int = Math.floor(v + 1e-12);
  let s = '';
  if (int === 0) s = '0';
  while (int > 0) { s = digit(int % base) + s; int = Math.floor(int / base); }
  const groups = [];
  while (s.length > 3) { groups.unshift(s.slice(-3)); s = s.slice(0,-3); }
  groups.unshift(s);
  while (groups.length < 4) groups.unshift('');
  const padded = groups.map((g,i)=> (g === '' && i === 0) ? ' ' : g.padStart(3,' ')).join(',');
  return (neg ? '-' : '') + padded + '.0';
}
function format(v, opts) { const b = toBase(v, opts.base); if (b != null) return b; return v.toFixed(opts.fix).replace(/^-0\.0+$/, m => m.slice(1)); }
function printError(e) { if (e.kind === 'math') console.log(`Math Error: ${e.message}`); else if (e.kind === 'domain') console.log(`Domain Error: ${e.message}`); else console.log(`Parser Error: ${e.message}`); }

function run() {
  let opts;
  try { opts = parseArgs(process.argv.slice(2)); } catch(e) { if (e.arg) { console.error(e.message); process.exit(2); } throw e; }
  if (opts.help) { console.log(help()); return; }
  if (opts.version) { console.log(VERSION); return; }
  const ctx = { angle: opts.angle, prev: 0 };
  if (opts.input != null) {
    try { const v = evaluate(opts.input, ctx); console.log(format(v, opts)); } catch(e) { printError(e); }
  } else {
    console.log('No previous history.');
    const fs = require('fs');
    const data = fs.readFileSync(0, 'utf8');
    for (const line of data.split(/\r?\n/)) {
      if (line.length === 0) continue;
      try { const v = evaluate(line, ctx); ctx.prev = v; console.log(format(v, opts)); } catch(e) { printError(e); }
    }
  }
}
run();
