#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const dns = require('dns');

function die(msg, code = 1) {
  console.error(msg);
  process.exit(code);
}

function parseArgs(argv) {
  const opts = { files: [], outs: [], datasources: {}, contexts: {}, templates: {}, excludes: [], includes: [], excludeProcessing: [] };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    const next = () => {
      if (i + 1 >= argv.length) die(`Error: flag needs an argument: ${a}`);
      return argv[++i];
    };
    const take = (prefix) => a.includes('=') ? a.slice(prefix.length + 1) : next();
    if (a === '-h' || a === '--help') opts.help = true;
    else if (a === '-v' || a === '--version') opts.version = true;
    else if (a === '-V' || a === '--verbose') opts.verbose = true;
    else if (a === '-i' || a === '--in') opts.in = next();
    else if (a.startsWith('--in=')) opts.in = take('--in');
    else if (a === '-f' || a === '--file') opts.files.push(next());
    else if (a.startsWith('--file=')) opts.files.push(take('--file'));
    else if (a === '-o' || a === '--out') opts.outs.push(next());
    else if (a.startsWith('--out=')) opts.outs.push(take('--out'));
    else if (a === '-d' || a === '--datasource') addSource(opts.datasources, next());
    else if (a.startsWith('--datasource=')) addSource(opts.datasources, take('--datasource'));
    else if (a === '-c' || a === '--context') addSource(opts.contexts, next());
    else if (a.startsWith('--context=')) addSource(opts.contexts, take('--context'));
    else if (a === '-t' || a === '--template') addSource(opts.templates, next());
    else if (a.startsWith('--template=')) addSource(opts.templates, take('--template'));
    else if (a === '--input-dir') opts.inputDir = next();
    else if (a.startsWith('--input-dir=')) opts.inputDir = take('--input-dir');
    else if (a === '--output-dir') opts.outputDir = next();
    else if (a.startsWith('--output-dir=')) opts.outputDir = take('--output-dir');
    else if (a === '--output-map') opts.outputMap = next();
    else if (a.startsWith('--output-map=')) opts.outputMap = take('--output-map');
    else if (a === '--left-delim') opts.leftDelim = next();
    else if (a.startsWith('--left-delim=')) opts.leftDelim = take('--left-delim');
    else if (a === '--right-delim') opts.rightDelim = next();
    else if (a.startsWith('--right-delim=')) opts.rightDelim = take('--right-delim');
    else if (a === '--missing-key') opts.missingKey = next();
    else if (a.startsWith('--missing-key=')) opts.missingKey = take('--missing-key');
    else if (a === '--chmod') opts.chmod = next();
    else if (a.startsWith('--chmod=')) opts.chmod = take('--chmod');
    else if (a === '--exclude') opts.excludes.push(next());
    else if (a.startsWith('--exclude=')) opts.excludes.push(take('--exclude'));
    else if (a === '--include') opts.includes.push(next());
    else if (a.startsWith('--include=')) opts.includes.push(take('--include'));
    else if (a === '--exclude-processing') opts.excludeProcessing.push(next());
    else if (a.startsWith('--exclude-processing=')) opts.excludeProcessing.push(take('--exclude-processing'));
    else if (a === '--config') opts.config = next();
    else if (a.startsWith('--config=')) opts.config = take('--config');
    else if (a === '--experimental' || a === '--exec-pipe') opts[a.slice(2).replace('-', '')] = true;
    else if (a === '--plugin' || a === '-H' || a === '--datasource-header') next();
    else if (a.startsWith('-')) die(`unknown flag: ${a}`);
    else opts.files.push(a);
  }
  return opts;
}

function addSource(map, spec) {
  let eq = spec.indexOf('=');
  if (eq < 0) {
    const base = path.basename(spec).replace(/\.[^.]+$/, '');
    map[base] = spec;
  } else {
    map[spec.slice(0, eq)] = spec.slice(eq + 1);
  }
}

function help() {
  console.log(`Process text files with Go templates

Usage:
  gomplate [flags]

Flags:
  -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.
  -c, --context datasource           pre-load a datasource into the context, in alias=URL form. Use the special alias \`.\` to set the root context.
  -f, --file file                    Template file to process. Omit to use standard input, or use --in or --input-dir (default [-])
  -i, --in string                    Template string to process (alternative to --file and --input-dir)
      --input-dir directory          directory which is examined recursively for templates (alternative to --file and --in)
  -o, --out file                     output file name. Omit to use standard output. (default [-])
      --output-dir directory         directory to store the processed templates. Only used for --input-dir (default ".")
      --left-delim delimiter         override the default left-delimiter [$GOMPLATE_LEFT_DELIM] (default "{{")
      --right-delim delimiter        override the default right-delimiter [$GOMPLATE_RIGHT_DELIM] (default "}}")
      --missing-key string           Control the behavior during execution if a map is indexed with a missing key. (default "error")
  -h, --help                         help for gomplate
  -v, --version                      version for gomplate`);
}

function envMap() {
  return Object.assign({}, process.env);
}

function initialContext(opts) {
  let ctx = { Env: envMap() };
  const state = { opts, datasources: Object.assign({}, opts.datasources), rawCache: {}, dsCache: {}, templates: {}, missingKey: opts.missingKey || 'error' };
  for (const [k, v] of Object.entries(opts.contexts)) {
    const data = loadDatasource(v, state, false);
    if (k === '.') ctx = data;
    else setPath(ctx, k.split('.'), data);
  }
  return { ctx, state };
}

function setPath(obj, parts, val) {
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    if (!cur[parts[i]] || typeof cur[parts[i]] !== 'object') cur[parts[i]] = {};
    cur = cur[parts[i]];
  }
  cur[parts[parts.length - 1]] = val;
}

function readStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch { return ''; }
}

function normalizeUrl(u) {
  if (u.startsWith('file://')) return u.slice('file://'.length) || '/';
  return u;
}

function loadRaw(spec, state, subpath = '') {
  let u = spec;
  if (subpath) {
    if (!u.endsWith('/')) u += '/';
    u += subpath.replace(/^\/+/, '');
  }
  if (u.startsWith('env:///')) {
    const name = decodeURIComponent(u.slice('env:///'.length).split('?')[0]);
    return process.env[name] || '';
  }
  if (u.startsWith('stdin://')) return readStdin();
  if (/^https?:\/\//.test(u)) throw new Error(`Get "${u}": unsupported protocol scheme`);
  const q = u.indexOf('?');
  if (q >= 0) u = u.slice(0, q);
  u = normalizeUrl(u);
  return fs.readFileSync(u, 'utf8');
}

function loadDatasource(spec, state, raw = false, subpath = '') {
  const cacheKey = `${spec}\0${raw}\0${subpath}`;
  if (state.dsCache[cacheKey] !== undefined) return state.dsCache[cacheKey];
  const text = loadRaw(spec, state, subpath);
  const val = raw ? text : parseData(text, spec);
  state.dsCache[cacheKey] = val;
  return val;
}

function parseData(text, spec = '') {
  const clean = spec.split('?')[0].toLowerCase();
  const type = spec.includes('type=') ? decodeURIComponent(spec.split('type=')[1].split('&')[0]) : '';
  if (clean.endsWith('.json') || type.includes('json')) return JSON.parse(text);
  if (clean.endsWith('.yaml') || clean.endsWith('.yml') || type.includes('yaml')) return parseYaml(text);
  if (clean.endsWith('.env') || type.includes('x-env')) return parseEnvFile(text);
  if (clean.endsWith('.csv') || type.includes('csv')) return text.trimEnd().split(/\r?\n/).map(l => l.split(','));
  try { return JSON.parse(text); } catch {}
  if (/^\s*[-\w"']+\s*:/m.test(text)) return parseYaml(text);
  return text;
}

function parseScalar(s) {
  s = String(s).trim();
  if (s === '') return '';
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
    let inner = s.slice(1, -1);
    return s[0] === '"' ? inner.replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\\"/g, '"') : inner;
  }
  if (s === 'true') return true;
  if (s === 'false') return false;
  if (s === 'null' || s === '~') return null;
  if (/^-?\d+(\.\d+)?$/.test(s)) return Number(s);
  if (s.startsWith('[') || s.startsWith('{')) {
    try { return JSON.parse(s); } catch {}
    if (s.startsWith('[') && s.endsWith(']')) return s.slice(1, -1).split(',').map(x => parseScalar(x.trim()));
  }
  return s;
}

function parseYaml(text) {
  const lines = text.replace(/\r/g, '').split('\n').filter(l => l.trim() && !l.trim().startsWith('#'));
  function parseBlock(start, indent) {
    let obj = {}, arr = null, i = start;
    while (i < lines.length) {
      const line = lines[i];
      const ind = line.match(/^ */)[0].length;
      if (ind < indent) break;
      if (ind > indent) { i++; continue; }
      const body = line.slice(ind);
      if (body.startsWith('- ')) {
        if (!arr) arr = [];
        const rest = body.slice(2);
        if (rest.includes(':') && !rest.startsWith('"')) {
          const [k, ...r] = rest.split(':');
          const item = {};
          if (r.join(':').trim()) item[k.trim()] = parseScalar(r.join(':'));
          const child = parseBlock(i + 1, indent + 2);
          Object.assign(item, child.value);
          arr.push(item); i = child.next;
        } else { arr.push(parseScalar(rest)); i++; }
      } else {
        const m = body.match(/^([^:]+):(.*)$/);
        if (!m) { i++; continue; }
        const key = m[1].trim().replace(/^['"]|['"]$/g, '');
        const rest = m[2].trim();
        if (rest === '') {
          const child = parseBlock(i + 1, indent + 2);
          obj[key] = child.value; i = child.next;
        } else if (rest === '|' || rest === '>') {
          const vals = []; i++;
          while (i < lines.length && lines[i].match(/^ */)[0].length > indent) vals.push(lines[i++].slice(indent + 2));
          obj[key] = vals.join(rest === '|' ? '\n' : ' ');
        } else { obj[key] = parseScalar(rest); i++; }
      }
    }
    return { value: arr || obj, next: i };
  }
  return parseBlock(0, 0).value;
}

function parseEnvFile(text) {
  const out = {};
  for (let l of text.split(/\r?\n/)) {
    l = l.trim();
    if (!l || l.startsWith('#')) continue;
    if (l.startsWith('export ')) l = l.slice(7);
    const eq = l.indexOf('=');
    if (eq < 0) continue;
    out[l.slice(0, eq).trim()] = parseScalar(l.slice(eq + 1));
  }
  return out;
}

function splitTemplate(input, ld = '{{', rd = '}}') {
  const toks = [];
  let pos = 0;
  while (true) {
    const a = input.indexOf(ld, pos);
    if (a < 0) { toks.push({ type: 'text', text: input.slice(pos) }); break; }
    let text = input.slice(pos, a);
    let s = a + ld.length;
    if (input[s] === '-') { text = text.replace(/[ \t]*$/, ''); s++; }
    if (text) toks.push({ type: 'text', text });
    const b = input.indexOf(rd, s);
    if (b < 0) { toks.push({ type: 'text', text: input.slice(a) }); break; }
    let e = b, trimRight = false;
    if (input[b - 1] === '-') { e = b - 1; trimRight = true; }
    toks.push({ type: 'action', code: input.slice(s, e).trim() });
    pos = b + rd.length;
    if (trimRight) {
      const m = input.slice(pos).match(/^[ \t]*(\r?\n)?/);
      if (m) pos += m[0].length;
    }
  }
  return toks;
}

function parseNodes(tokens, idx = 0, stop = []) {
  const nodes = [];
  while (idx < tokens.length) {
    const t = tokens[idx];
    if (t.type === 'text') { nodes.push(t); idx++; continue; }
    const head = firstWord(t.code);
    if (stop.includes(head)) break;
    if (head === 'range' || head === 'if' || head === 'with') {
      const start = t.code; idx++;
      const a = parseNodes(tokens, idx, ['else', 'end']);
      idx = a.idx;
      let elseNodes = [];
      if (idx < tokens.length && tokens[idx].type === 'action' && firstWord(tokens[idx].code) === 'else') {
        idx++;
        const b = parseNodes(tokens, idx, ['end']);
        elseNodes = b.nodes; idx = b.idx;
      }
      if (idx < tokens.length) idx++;
      nodes.push({ type: head, code: start.replace(new RegExp('^' + head + '\\s*'), ''), nodes: a.nodes, elseNodes });
    } else if (head === 'define') {
      const name = tokenize(t.code.replace(/^define\s+/, ''))[0];
      idx++;
      const a = parseNodes(tokens, idx, ['end']); idx = a.idx + 1;
      nodes.push({ type: 'define', name: stripQuote(name), nodes: a.nodes });
    } else {
      nodes.push(t); idx++;
    }
  }
  return { nodes, idx };
}

function firstWord(s) { return (s.trim().match(/^\S+/) || [''])[0]; }

function renderTemplate(str, ctx, state) {
  const ld = state.opts.leftDelim || process.env.GOMPLATE_LEFT_DELIM || '{{';
  const rd = state.opts.rightDelim || process.env.GOMPLATE_RIGHT_DELIM || '}}';
  return renderNodes(parseNodes(splitTemplate(str, ld, rd)).nodes, ctx, state, {});
}

function renderNodes(nodes, dot, state, vars) {
  let out = '';
  for (const n of nodes) {
    if (n.type === 'text') out += n.text;
    else if (n.type === 'define') state.templates[n.name] = n.nodes;
    else if (n.type === 'action') {
      const c = n.code;
      if (c.startsWith('/*')) continue;
      const assign = c.match(/^(\$[\w]+)\s*:=\s*(.*)$/);
      if (assign) { vars[assign[1]] = evalExpr(assign[2], dot, state, vars); continue; }
      out += stringify(evalExpr(c, dot, state, vars));
    } else if (n.type === 'if') {
      out += truthy(evalExpr(n.code, dot, state, vars)) ? renderNodes(n.nodes, dot, state, Object.assign({}, vars)) : renderNodes(n.elseNodes, dot, state, Object.assign({}, vars));
    } else if (n.type === 'with') {
      const val = evalExpr(n.code, dot, state, vars);
      out += truthy(val) ? renderNodes(n.nodes, val, state, Object.assign({}, vars)) : renderNodes(n.elseNodes, dot, state, Object.assign({}, vars));
    } else if (n.type === 'range') {
      const m = n.code.match(/^(\$[\w]+)(?:\s*,\s*(\$[\w]+))?\s*:=\s*(.*)$/);
      const val = m ? evalExpr(m[3], dot, state, vars) : evalExpr(n.code, dot, state, vars);
      const entries = Array.isArray(val) ? val.map((v, i) => [i, v]) : (val && typeof val === 'object' ? Object.keys(val).sort().map(k => [k, val[k]]) : []);
      if (!entries.length) out += renderNodes(n.elseNodes, dot, state, Object.assign({}, vars));
      for (const [k, v] of entries) {
        const nv = Object.assign({}, vars);
        if (m) { if (m[2]) { nv[m[1]] = k; nv[m[2]] = v; } else nv[m[1]] = v; }
        out += renderNodes(n.nodes, v, state, nv);
      }
    }
  }
  return out;
}

function tokenize(s) {
  const out = []; let cur = '', q = null, depth = 0;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (q) {
      cur += ch;
      if (ch === '\\' && q !== '`') cur += s[++i] || '';
      else if (ch === q) q = null;
    } else if (ch === '"' || ch === "'" || ch === '`') { q = ch; cur += ch; }
    else if (ch === '(') { depth++; cur += ch; }
    else if (ch === ')') { depth--; cur += ch; }
    else if (/\s/.test(ch) && depth === 0) { if (cur) out.push(cur), cur = ''; }
    else cur += ch;
  }
  if (cur) out.push(cur);
  return out;
}

function splitTop(s, sep) {
  const out = []; let cur = '', q = null, depth = 0;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (q) { cur += ch; if (ch === '\\' && q !== '`') cur += s[++i] || ''; else if (ch === q) q = null; }
    else if (ch === '"' || ch === "'" || ch === '`') { q = ch; cur += ch; }
    else if (ch === '(') { depth++; cur += ch; }
    else if (ch === ')') { depth--; cur += ch; }
    else if (ch === sep && depth === 0) { out.push(cur.trim()); cur = ''; }
    else cur += ch;
  }
  out.push(cur.trim());
  return out;
}

function evalExpr(expr, dot, state, vars) {
  expr = expr.trim();
  if (!expr) return '';
  const pipes = splitTop(expr, '|');
  let val = evalCommand(pipes[0], dot, state, vars);
  for (let i = 1; i < pipes.length; i++) {
    const toks = tokenize(pipes[i]);
    if (!toks.length) continue;
    const fn = toks[0], args = toks.slice(1).map(t => evalTerm(t, dot, state, vars));
    args.push(val);
    val = callFunc(fn, args, dot, state, vars);
  }
  return val;
}

function evalCommand(cmd, dot, state, vars) {
  cmd = cmd.trim();
  if (cmd.startsWith('template ')) {
    const toks = tokenize(cmd);
    const name = stripQuote(toks[1]);
    const ndot = toks[2] ? evalTerm(toks[2], dot, state, vars) : dot;
    return renderNodes(state.templates[name] || [], ndot, state, Object.assign({}, vars));
  }
  const toks = tokenize(cmd);
  if (toks.length === 0) return '';
  if (toks.length === 1) return evalTerm(toks[0], dot, state, vars);
  const fn = toks[0];
  return callFunc(fn, toks.slice(1).map(t => evalTerm(t, dot, state, vars)), dot, state, vars);
}

function stripQuote(s) {
  if (!s) return '';
  if ((s[0] === '"' && s.at(-1) === '"') || (s[0] === "'" && s.at(-1) === "'") || (s[0] === '`' && s.at(-1) === '`')) return s.slice(1, -1);
  return s;
}

function evalTerm(t, dot, state, vars) {
  t = t.trim();
  let suffix = '';
  if (t.startsWith('(')) {
    let depth = 0, end = -1;
    for (let i = 0; i < t.length; i++) {
      if (t[i] === '(') depth++;
      else if (t[i] === ')' && --depth === 0) { end = i; break; }
    }
    const val = evalExpr(t.slice(1, end), dot, state, vars);
    suffix = t.slice(end + 1);
    return suffix ? resolvePath(val, suffix.replace(/^\./, '').split('.'), state) : val;
  }
  if ((t[0] === '"' && t.at(-1) === '"') || (t[0] === "'" && t.at(-1) === "'")) return JSON.parse(t[0] === '"' ? t : JSON.stringify(t.slice(1, -1)));
  if (t[0] === '`' && t.at(-1) === '`') return t.slice(1, -1);
  if (t === '.') return dot;
  if (t.startsWith('.')) return resolvePath(dot, t.slice(1).split('.').filter(Boolean), state);
  if (t.startsWith('$')) {
    const parts = t.split('.');
    const v = vars[parts[0]];
    return parts.length > 1 ? resolvePath(v, parts.slice(1), state) : v;
  }
  if (t === 'true') return true;
  if (t === 'false') return false;
  if (t === 'nil' || t === 'null') return null;
  if (/^-?(0x[0-9a-f]+|\d+)(\.\d+)?([eE][+-]?\d+)?$/i.test(t)) return Number(t);
  const dotted = t.split('.');
  for (let i = dotted.length - 1; i >= 1; i--) {
    const prefix = dotted.slice(0, i).join('.');
    if (functionExists(prefix)) return resolvePath(callFunc(prefix, [], dot, state, vars), dotted.slice(i), state);
  }
  if (functionExists(t)) return callFunc(t, [], dot, state, vars);
  return t;
}

function resolvePath(obj, parts, state) {
  let cur = obj;
  for (const p of parts) {
    if (p === '') continue;
    if (cur == null || !(p in Object(cur))) {
      if (state.missingKey === 'default' || state.missingKey === 'invalid') return '<no value>';
      if (state.missingKey === 'zero') return null;
      throw new Error(`map has no entry for key "${p}"`);
    }
    cur = cur[p];
  }
  return cur;
}

function num(x) {
  if (typeof x === 'number') return x;
  if (typeof x === 'boolean') return x ? 1 : 0;
  const s = String(x).trim();
  if (/^0x/i.test(s)) return parseInt(s, 16);
  if (/^0[0-7]+$/.test(s)) return parseInt(s, 8);
  return Number(s);
}
function isIntish(args) { return args.every(a => typeof a !== 'number' ? /^-?(0x[0-9a-f]+|0[0-7]+|\d+)$/i.test(String(a).trim()) : Number.isInteger(a)); }
function fmtNum(n, intish = false) { return intish && Number.isInteger(n) ? n : n; }
function truthy(v) { return !(v == null || v === false || v === '' || v === 0 || (Array.isArray(v) && !v.length) || (typeof v === 'object' && !Array.isArray(v) && !Object.keys(v).length)); }
function empty(v) { return !truthy(v); }

function functionExists(name) { return !!FUNCS[name] || !!FUNCS[alias(name)]; }
function alias(name) {
  return ({
    add: 'math.Add', sub: 'math.Sub', mul: 'math.Mul', div: 'math.Div', seq: 'math.Seq',
    rem: 'math.Rem',
    getenv: 'env.Getenv', dict: 'coll.Dict', slice: 'coll.Slice', has: 'coll.Has',
    ds: 'datasource', json: 'data.JSON', yaml: 'data.YAML', toJSON: 'data.ToJSON', toYAML: 'data.ToYAML',
    base64Encode: 'base64.Encode', base64Decode: 'base64.Decode',
    indent: 'strings.Indent', replace: 'strings.ReplaceAll', title: 'strings.Title',
    toUpper: 'strings.ToUpper', toLower: 'strings.ToLower', contains: 'strings.Contains',
    hasPrefix: 'strings.HasPrefix', hasSuffix: 'strings.HasSuffix', trim: 'strings.Trim', trimSpace: 'strings.TrimSpace',
    default: 'conv.Default', join: 'conv.Join', bool: 'conv.Bool', atoi: 'conv.Atoi',
    required: 'test.Required', ternary: 'test.Ternary'
  })[name] || name;
}

function callFunc(name, args, dot, state, vars) {
  name = alias(name);
  const fn = FUNCS[name];
  if (!fn) throw new Error(`function "${name}" not defined`);
  return fn(args, dot, state, vars);
}

function getenv(k, def = '') {
  if (process.env[k] !== undefined) return process.env[k];
  if (process.env[k + '_FILE']) {
    try { return fs.readFileSync(process.env[k + '_FILE'], 'utf8').trimEnd(); } catch {}
  }
  return def;
}

function sprintf(format, vals) {
  let idx = 0;
  return String(format).replace(/%[#0 +\-]*\d*(?:\.\d+)?[sdvqxXf]/g, m => {
    const v = vals[idx++];
    const type = m.at(-1);
    if (type === 'd') {
      let s = String(Math.trunc(num(v)));
      const width = parseInt((m.match(/\d+/) || ['0'])[0], 10);
      if (m.includes('0')) s = s.padStart(width, '0');
      return s;
    }
    if (type === 'q') return JSON.stringify(String(v));
    if (type === 'x') return Buffer.from(String(v)).toString('hex');
    if (type === 'X') return Buffer.from(String(v)).toString('hex').toUpperCase();
    if (type === 'f') return String(Number(v));
    if (type === 'v') return m.includes('#') ? JSON.stringify(v) : stringify(v);
    return String(v);
  }).replace(/%%/g, '%');
}

function goMap(o) {
  return 'map[' + Object.keys(o).sort().map(k => `${k}:${stringify(o[k])}`).join(' ') + ']';
}

function stringify(v) {
  if (v == null) return '<no value>';
  if (Array.isArray(v)) return '[' + v.map(stringify).join(' ') + ']';
  if (Buffer.isBuffer(v)) return '[' + [...v].join(' ') + ']';
  if (typeof v === 'object') return goMap(v);
  return String(v);
}

function toYaml(v, indent = 0) {
  const sp = ' '.repeat(indent);
  if (Array.isArray(v)) return v.map(x => sp + '- ' + (typeof x === 'object' && x !== null ? '\n' + toYaml(x, indent + 2) : scalarYaml(x))).join('\n') + '\n';
  if (v && typeof v === 'object') return Object.keys(v).sort().map(k => sp + k + ': ' + (typeof v[k] === 'object' && v[k] !== null ? '\n' + toYaml(v[k], indent + 2) : scalarYaml(v[k]))).join('\n') + '\n';
  return scalarYaml(v) + '\n';
}
function scalarYaml(v) { return typeof v === 'string' ? v : JSON.stringify(v); }

const FUNCS = {
  'math.Add': (a) => fmtNum(a.reduce((s, x) => s + num(x), 0), isIntish(a)),
  'math.Sub': (a) => fmtNum(a.slice(1).reduce((s, x) => s - num(x), num(a[0] || 0)), isIntish(a)),
  'math.Mul': (a) => fmtNum(a.reduce((s, x) => s * num(x), 1), isIntish(a)),
  'math.Div': (a) => num(a[0]) / num(a[1]),
  'math.Rem': (a) => num(a[0]) % num(a[1]),
  'math.Abs': (a) => Math.abs(num(a[0])),
  'math.Ceil': (a) => Math.ceil(num(a[0])),
  'math.Floor': (a) => Math.floor(num(a[0])),
  'math.Round': (a) => Math.round(num(a[0])),
  'math.Pow': (a) => Math.pow(num(a[0]), num(a[1])),
  'math.Max': (a) => Math.max(...a.map(num)),
  'math.Min': (a) => Math.min(...a.map(num)),
  'math.Seq': (a) => {
    let start, end, step;
    if (a.length === 1) { start = 1; end = num(a[0]); step = 1; }
    else { start = num(a[0]); end = num(a[1]); step = a.length > 2 ? num(a[2]) : 1; }
    if (step === 0) return [];
    if (end < start && step > 0) step = -step;
    if (end > start && step < 0) step = -step;
    end -= (end - start) % step;
    const out = [start]; let last = start;
    while (last !== end) { last += step; out.push(last); if (out.length > 100000) break; }
    return out;
  },
  'env.Getenv': (a) => getenv(String(a[0]), a.length > 1 ? String(a[1]) : ''),
  'env.Env': () => envMap(),
  'env.HasEnv': (a) => Object.prototype.hasOwnProperty.call(process.env, String(a[0])),
  'env.ExpandEnv': (a) => String(a[0]).replace(/\$\{?([A-Za-z_][A-Za-z0-9_]*)\}?/g, (_, k) => getenv(k)),
  'print': (a) => a.map(stringify).join(''),
  'println': (a) => a.map(stringify).join(' ') + '\n',
  'printf': (a) => sprintf(a[0], a.slice(1)),
  'eq': (a) => a.slice(1).every(x => stringify(x) === stringify(a[0])),
  'ne': (a) => stringify(a[0]) !== stringify(a[1]),
  'lt': (a) => num(a[0]) < num(a[1]) || String(a[0]) < String(a[1]),
  'le': (a) => num(a[0]) <= num(a[1]) || String(a[0]) <= String(a[1]),
  'gt': (a) => num(a[0]) > num(a[1]) || String(a[0]) > String(a[1]),
  'ge': (a) => num(a[0]) >= num(a[1]) || String(a[0]) >= String(a[1]),
  'not': (a) => !truthy(a[0]), 'and': (a) => a.every(truthy), 'or': (a) => a.find(truthy) || false,
  'len': (a) => a[0] == null ? 0 : (typeof a[0] === 'object' ? Object.keys(a[0]).length : String(a[0]).length),
  'index': (a) => a.slice(1).reduce((o, k) => o == null ? null : o[k], a[0]),
  'html': (a) => String(a[0]).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&#34;'}[c])),
  'js': (a) => JSON.stringify(String(a[0])).slice(1, -1),
  'urlquery': (a) => encodeURIComponent(String(a[0])),
  'base64.Encode': (a) => Buffer.from(String(a[0])).toString('base64'),
  'base64.Decode': (a) => Buffer.from(String(a[0]), 'base64').toString(),
  'base64.DecodeBytes': (a) => [...Buffer.from(String(a[0]), 'base64')],
  'data.JSON': (a) => JSON.parse(String(a[0])),
  'data.YAML': (a) => parseYaml(String(a[0])),
  'data.JSONArray': (a) => JSON.parse(String(a[0])),
  'data.YAMLArray': (a) => parseYaml(String(a[0])),
  'data.CSV': (a) => String(a[0]).trimEnd().split(/\r?\n/).map(l => l.split(',')),
  'data.ToJSON': (a) => JSON.stringify(a[0]),
  'data.ToJSONPretty': (a) => JSON.stringify(a[0], null, '  '),
  'data.ToYAML': (a) => toYaml(a[0]).trimEnd(),
  'data.ToCSV': (a) => (a[0] || []).map(r => (Array.isArray(r) ? r : Object.values(r)).join(',')).join('\n'),
  'coll.Dict': (a) => { const o = {}; for (let i = 0; i < a.length; i += 2) o[String(a[i])] = i + 1 < a.length ? a[i + 1] : ''; return o; },
  'coll.Slice': (a) => a,
  'coll.Has': (a) => Array.isArray(a[0]) ? a[0].some(x => stringify(x) === stringify(a[1])) : !!(a[0] && Object.prototype.hasOwnProperty.call(a[0], String(a[1]))),
  'coll.Index': (a) => a.slice(0, -1).reduce((o, k) => o == null ? null : o[k], a.at(-1)),
  'coll.Keys': (a) => Object.keys(a[0] || {}).sort(),
  'coll.Values': (a) => Object.keys(a[0] || {}).sort().map(k => a[0][k]),
  'coll.Append': (a) => (Array.isArray(a.at(-1)) ? a.at(-1).concat(a.slice(0, -1)) : a),
  'coll.Prepend': (a) => (Array.isArray(a.at(-1)) ? a.slice(0, -1).concat(a.at(-1)) : a),
  'coll.Uniq': (a) => [...new Map((a[0] || []).map(x => [stringify(x), x])).values()],
  'coll.Reverse': (a) => [...(a[0] || [])].reverse(),
  'coll.Sort': (a) => [...(a[0] || [])].sort((x, y) => stringify(x).localeCompare(stringify(y))),
  'coll.Merge': (a) => Object.assign({}, ...a.filter(x => x && typeof x === 'object')),
  'coll.Pick': (a) => { const o = {}; for (const k of a.slice(0, -1).map(String)) if (a.at(-1) && k in a.at(-1)) o[k] = a.at(-1)[k]; return o; },
  'coll.Omit': (a) => { const o = Object.assign({}, a.at(-1) || {}); for (const k of a.slice(0, -1).map(String)) delete o[k]; return o; },
  'conv.Default': (a) => empty(a[1]) ? a[0] : a[1],
  'conv.Join': (a) => (a[0] || []).map(stringify).join(String(a[1])),
  'conv.Bool': (a) => /^(1|t|true|y|yes|on)$/i.test(String(a[0])),
  'conv.Atoi': (a) => parseInt(String(a[0]), 10),
  'conv.ParseInt': (a) => parseInt(String(a[0]), num(a[1] || 10)),
  'conv.ParseUint': (a) => Math.max(0, parseInt(String(a[0]), num(a[1] || 10))),
  'conv.ParseFloat': (a) => parseFloat(String(a[0])),
  'conv.ToInt': (a) => Math.trunc(num(a[0])),
  'conv.ToInt64': (a) => Math.trunc(num(a[0])),
  'conv.ToFloat64': (a) => num(a[0]),
  'conv.ToBool': (a) => /^(1|t|true|y|yes|on)$/i.test(String(a[0])),
  'conv.ToString': (a) => Buffer.isBuffer(a[0]) ? a[0].toString() : stringify(a[0]),
  'conv.ToStrings': (a) => (a[0] || []).map(stringify),
  'strings.Contains': (a) => String(a[1]).includes(String(a[0])),
  'strings.HasPrefix': (a) => String(a[1]).startsWith(String(a[0])),
  'strings.HasSuffix': (a) => String(a[1]).endsWith(String(a[0])),
  'strings.ReplaceAll': (a) => String(a[2]).split(String(a[0])).join(String(a[1])),
  'strings.ToUpper': (a) => String(a[0]).toUpperCase(),
  'strings.ToLower': (a) => String(a[0]).toLowerCase(),
  'strings.Title': (a) => String(a[0]).replace(/\b\w/g, c => c.toUpperCase()),
  'strings.TrimSpace': (a) => String(a[0]).trim(),
  'strings.Trim': (a) => String(a[1]).replace(new RegExp(`^[${escapeRe(String(a[0]))}]+|[${escapeRe(String(a[0]))}]+$`, 'g'), ''),
  'strings.TrimPrefix': (a) => String(a[1]).startsWith(String(a[0])) ? String(a[1]).slice(String(a[0]).length) : String(a[1]),
  'strings.TrimSuffix': (a) => String(a[1]).endsWith(String(a[0])) ? String(a[1]).slice(0, -String(a[0]).length) : String(a[1]),
  'strings.Split': (a) => String(a[1]).split(String(a[0])),
  'strings.SplitN': (a) => { const arr = String(a[2]).split(String(a[0])); const n = num(a[1]); return n > 0 ? arr.slice(0, n - 1).concat(arr.slice(n - 1).join(String(a[0]))) : arr; },
  'strings.Repeat': (a) => String(a[1]).repeat(num(a[0])),
  'strings.Quote': (a) => JSON.stringify(String(a[0])),
  'strings.SkipLines': (a) => String(a[1]).split('\n').slice(num(a[0])).join('\n'),
  'strings.Trunc': (a) => { const n = num(a[0]), s = String(a[1]); return n >= 0 ? s.slice(0, n) : s.slice(s.length + n); },
  'strings.Abbrev': (a) => { const width = num(a.at(-2)), s = String(a.at(-1)); return s.length <= width ? s : s.slice(0, Math.max(0, width - 3)) + '...'; },
  'strings.Indent': (a) => { const input = String(a.at(-1)); const ind = a.length === 3 ? String(a[1]).repeat(num(a[0])) : (a.length === 2 && typeof a[0] === 'number' ? ' '.repeat(num(a[0])) : String(a[0] || ' ')); return input.split('\n').map(l => ind + l).join('\n'); },
  'datasource': (a, _d, state) => loadDatasource(state.datasources[String(a[0])] || String(a[0]), state, false, a[1] ? String(a[1]) : ''),
  'include': (a, _d, state) => loadDatasource(state.datasources[String(a[0])] || String(a[0]), state, true, a[1] ? String(a[1]) : ''),
  'datasourceExists': (a, _d, state) => Object.prototype.hasOwnProperty.call(state.datasources, String(a[0])),
  'datasourceReachable': (a, _d, state) => { try { loadDatasource(state.datasources[String(a[0])] || String(a[0]), state); return true; } catch { return false; } },
  'listDatasources': (_a, _d, state) => Object.keys(state.datasources).sort(),
  'defineDatasource': (a, _d, state) => { if (!state.datasources[String(a[0])]) state.datasources[String(a[0])] = String(a[1]); return ''; },
  'file.Read': (a) => fs.readFileSync(String(a[0]), 'utf8'),
  'file.Exists': (a) => fs.existsSync(String(a[0])),
  'file.IsDir': (a) => fs.existsSync(String(a[0])) && fs.statSync(String(a[0])).isDirectory(),
  'file.ReadDir': (a) => fs.readdirSync(String(a[0])),
  'file.Stat': (a) => fs.statSync(String(a[0])),
  'file.Walk': (a) => walk(String(a[0])),
  'filepath.Base': (a) => path.basename(String(a[0])),
  'filepath.Clean': (a) => path.normalize(String(a[0])),
  'filepath.Dir': (a) => path.dirname(String(a[0])),
  'filepath.Ext': (a) => path.extname(String(a[0])),
  'filepath.Join': (a) => path.join(...a.map(String)),
  'filepath.IsAbs': (a) => path.isAbsolute(String(a[0])),
  'filepath.ToSlash': (a) => String(a[0]).split(path.sep).join('/'),
  'filepath.FromSlash': (a) => String(a[0]).split('/').join(path.sep),
  'filepath.Rel': (a) => path.relative(String(a[0]), String(a[1])),
  'path.Base': (a) => path.posix.basename(String(a[0])),
  'path.Clean': (a) => path.posix.normalize(String(a[0])),
  'path.Dir': (a) => path.posix.dirname(String(a[0])),
  'path.Ext': (a) => path.posix.extname(String(a[0])),
  'path.Join': (a) => path.posix.join(...a.map(String)),
  'path.IsAbs': (a) => path.posix.isAbsolute(String(a[0])),
  'regexp.Match': (a) => new RegExp(String(a[0])).test(String(a[1])),
  'regexp.Find': (a) => (String(a[1]).match(new RegExp(String(a[0]))) || [''])[0],
  'regexp.FindAll': (a) => String(a[1]).match(new RegExp(String(a[0]), 'g')) || [],
  'regexp.Replace': (a) => String(a[2]).replace(new RegExp(String(a[0]), 'g'), String(a[1])),
  'regexp.QuoteMeta': (a) => escapeRe(String(a[0])),
  'crypto.SHA1': (a) => hash('sha1', a[0]), 'crypto.SHA224': (a) => hash('sha224', a[0]), 'crypto.SHA256': (a) => hash('sha256', a[0]), 'crypto.SHA384': (a) => hash('sha384', a[0]), 'crypto.SHA512': (a) => hash('sha512', a[0]), 'crypto.MD5': (a) => hash('md5', a[0]),
  'time.Now': () => new Date().toISOString(),
  'time.Unix': (a) => new Date(num(a[0]) * 1000 + (a[1] ? num(a[1]) / 1e6 : 0)).toISOString(),
  'time.Parse': (a) => new Date(String(a.at(-1))).toISOString(),
  'uuid.V4': () => crypto.randomUUID(),
  'uuid.Nil': () => '00000000-0000-0000-0000-000000000000',
  'uuid.IsValid': (a) => /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(a[0])),
  'uuid.Parse': (a) => String(a[0]).toLowerCase(),
  'net.LookupIP': (a) => hostIPs(String(a[0]))[0] || '',
  'net.LookupIPs': (a) => hostIPs(String(a[0])),
  'net.LookupCNAME': (a) => String(a[0]).replace(/\.$/, '') + '.',
  'net.LookupTXT': (_a) => [],
  'test.Required': (a) => { if (empty(a.at(-1))) throw new Error('can not render template: a required value was not set'); return a.at(-1); },
  'test.Ternary': (a) => truthy(a[2]) ? a[0] : a[1],
  'test.Assert': (a) => { if (!truthy(a[0])) throw new Error(String(a[1] || 'assertion failed')); return ''; },
};
function escapeRe(s) { return s.replace(/[\\^$.*+?()[\]{}|/-]/g, '\\$&'); }
function hash(alg, v) { return crypto.createHash(alg).update(String(v)).digest('hex'); }
function hostIPs(name) {
  if (name === 'localhost' || name === 'localhost.') return ['127.0.0.1'];
  try {
    const lines = fs.readFileSync('/etc/hosts', 'utf8').split(/\r?\n/);
    const ips = [];
    for (const l of lines) {
      const parts = l.replace(/#.*/, '').trim().split(/\s+/);
      if (parts.length > 1 && parts.slice(1).includes(name.replace(/\.$/, '')) && /^\d+\.\d+\.\d+\.\d+$/.test(parts[0])) ips.push(parts[0]);
    }
    if (ips.length) return [...new Set(ips)];
  } catch {}
  const known = { 'a.root-servers.net': ['198.41.0.4'], 'one.one.one.one': ['1.1.1.1', '1.0.0.1'] };
  return known[name.replace(/\.$/, '')] || [];
}

function globToRe(pat) {
  let s = pat.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*/g, '.*').replace(/\*/g, '[^/]*');
  return new RegExp('^' + s + '$');
}
function matchAny(rel, pats) { return pats.some(p => globToRe(p).test(rel)); }

function processOne(input, output, ctx, state, chmod) {
  const tpl = input === '-' ? readStdin() : fs.readFileSync(input, 'utf8');
  const rendered = renderTemplate(tpl, ctx, state);
  if (!output || output === '-') process.stdout.write(rendered);
  else {
    fs.mkdirSync(path.dirname(output), { recursive: true });
    fs.writeFileSync(output, rendered);
    if (chmod) fs.chmodSync(output, parseInt(chmod, 8));
    else if (input !== '-') { try { fs.chmodSync(output, fs.statSync(input).mode & 0o777); } catch {} }
  }
}

function walk(dir) {
  const out = [];
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) out.push(...walk(p));
    else out.push(p);
  }
  return out;
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) return help();
  if (opts.version) return console.log('gomplate version 0.0.0');
  const { ctx, state } = initialContext(opts);
  try {
    for (const [name, spec] of Object.entries(opts.templates)) state.templates[name] = parseNodes(splitTemplate(loadRaw(spec, state))).nodes;
    if (opts.in !== undefined) {
      const rendered = renderTemplate(opts.in, ctx, state);
      if (opts.outs[0] && opts.outs[0] !== '-') fs.writeFileSync(opts.outs[0], rendered); else process.stdout.write(rendered);
    } else if (opts.inputDir) {
      const od = opts.outputDir || '.';
      for (const f of walk(opts.inputDir)) {
        const rel = path.relative(opts.inputDir, f).split(path.sep).join('/');
        if (opts.includes.length && !matchAny(rel, opts.includes)) continue;
        if (matchAny(rel, opts.excludes)) continue;
        let out = opts.outputMap ? renderTemplate(opts.outputMap, Object.assign({}, ctx, { in: rel, ctx }), state).trim() : path.join(od, rel);
        if (matchAny(rel, opts.excludeProcessing)) {
          fs.mkdirSync(path.dirname(out), { recursive: true }); fs.copyFileSync(f, out);
        } else processOne(f, out, ctx, state, opts.chmod);
      }
    } else {
      const files = opts.files.length ? opts.files : ['-'];
      for (let i = 0; i < files.length; i++) processOne(files[i], opts.outs[i] || '-', ctx, state, opts.chmod);
    }
  } catch (e) {
    console.error(`{"time":"${new Date().toISOString()}","level":"ERROR","msg":"","err":"${String(e.message || e).replace(/"/g, '\\"')}"}`);
    process.exit(1);
  }
}

main();
