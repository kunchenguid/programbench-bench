#!/usr/bin/env node
'use strict';

const fs = require('fs');

const HELP = `Shellharden: The corrective bash syntax highlighter.

Usage:
\tshellharden [options] [files]
\tcat files | shellharden [options] ''

Shellharden is a syntax highlighter and a tool to semi-automate the rewriting
of scripts to ShellCheck conformance, mainly focused on quoting.

The default mode of operation is like \`cat\`, but with syntax highlighting in
foreground colors and suggestive changes in background colors.

Options:
\t--suggest         Output a colored diff suggesting changes.
\t--syntax          Output syntax highlighting with ANSI colors.
\t--syntax-suggest  Diff with syntax highlighting (default mode).
\t--transform       Output suggested changes.
\t--check           No output; exit with 2 if changes are suggested.
\t--replace         Replace file contents with suggested changes.
\t--                Don't treat further arguments as options.
\t-h|--help         Show help text.
\t--version         Show version.

The changes suggested by Shellharden inhibits word splitting and indirect
pathname expansion. This will make your script ShellCheck compliant in terms of
quoting. Whether your script will work afterwards is a different question:
If your script was using those features on purpose, it obviously won't anymore!

Every script is possible to write without using word splitting or indirect
pathname expansion, but it may involve doing things differently.
See the accompanying file how_to_do_things_safely_in_bash.md or online:
https://github.com/anordal/shellharden/blob/master/how_to_do_things_safely_in_bash.md
`;

function isNameStart(c) { return /[A-Za-z_]/.test(c || ''); }
function isName(c) { return /[A-Za-z0-9_]/.test(c || ''); }
function isSpace(c) { return c === ' ' || c === '\t' || c === '\r' || c === '\n'; }
function isOp(c) { return ';&|()<>'.includes(c || ''); }

function parseBrace(s, i) {
  let depth = 1, j = i + 2, quote = null;
  for (; j < s.length; j++) {
    const c = s[j], n = s[j + 1];
    if (quote) {
      if (c === '\\') j++;
      else if (c === quote) quote = null;
      continue;
    }
    if (c === '\'' || c === '"' || c === '`') { quote = c; continue; }
    if (c === '$' && n === '{') { depth++; j++; continue; }
    if (c === '}') {
      depth--;
      if (depth === 0) return j + 1;
    }
  }
  return i + 2;
}

function parseParen(s, i) {
  let depth = 1, j = i + 2, quote = null;
  for (; j < s.length; j++) {
    const c = s[j], n = s[j + 1];
    if (quote) {
      if (c === '\\') j++;
      else if (c === quote) quote = null;
      continue;
    }
    if (c === '\'' || c === '"' || c === '`') { quote = c; continue; }
    if (c === '$' && n === '(') { depth++; j++; continue; }
    if (c === '(') { depth++; continue; }
    if (c === ')') {
      depth--;
      if (depth === 0) return j + 1;
    }
  }
  return i + 2;
}

function parseBacktick(s, i) {
  let j = i + 1;
  for (; j < s.length; j++) {
    if (s[j] === '\\') j++;
    else if (s[j] === '`') return j + 1;
  }
  return i + 1;
}

function parseDollar(s, i) {
  if (s[i] !== '$') return null;
  const n = s[i + 1];
  if (n === '{') return { end: parseBrace(s, i), text: s.slice(i, parseBrace(s, i)), kind: 'var' };
  if (n === '(') return { end: parseParen(s, i), text: s.slice(i, parseParen(s, i)), kind: 'cmd' };
  if (isNameStart(n)) {
    let j = i + 2;
    while (isName(s[j])) j++;
    return { end: j, text: s.slice(i, j), kind: 'var' };
  }
  if (n && '@*#?$!-_0123456789'.includes(n)) return { end: i + 2, text: s.slice(i, i + 2), kind: 'var' };
  return null;
}

function tokenBefore(line, pos) {
  let i = pos - 1;
  while (i >= 0 && isSpace(line[i])) i--;
  let end = i + 1;
  while (i >= 0 && !isSpace(line[i]) && !isOp(line[i])) i--;
  return line.slice(i + 1, end);
}

function atAssignmentRhs(line, tokenStart, pos) {
  let i = pos - 1;
  while (i >= 0 && !isSpace(line[i]) && !';|&()'.includes(line[i])) {
    if (line[i] === '=') {
      const left = line.slice(i - 1 >= 0 ? line.lastIndexOf(' ', i) + 1 : 0, i);
      return /^[A-Za-z_][A-Za-z0-9_]*(\[[^\]]*\])?$/.test(left);
    }
    i--;
  }
  return false;
}

function startsHereDoc(line, pos) {
  return line.slice(pos, pos + 2) === '<<';
}

function detectHeredoc(line) {
  const m = line.match(/<<-?\s*['"]?([A-Za-z_][A-Za-z0-9_]*)['"]?/);
  return m ? m[1] : null;
}

function needsNoQuote(text) {
  return /^\$(?:[?#$!])$/.test(text) || /^\$\{#.*\}$/.test(text) || /^\$\(\(/.test(text);
}

function braceArrayExpansion(text) {
  const m = text.match(/^\$([A-Za-z_][A-Za-z0-9_]*)$/);
  return m ? '${' + m[1] + '[@]}' : text;
}

function quoteExpansion(text, context, simplifyBrace = true) {
  if (needsNoQuote(text)) return text;
  const simpleBrace = text.match(/^\$\{([A-Za-z_][A-Za-z0-9_]*)\}$/);
  if (simpleBrace && simplifyBrace) text = '$' + simpleBrace[1];
  if (text === '$*') return '"$@"';
  if (context === 'for-in') return '"' + braceArrayExpansion(text) + '"';
  if (text.startsWith('$(')) {
    const inner = text.slice(2, -1).trim();
    if (/^(pwd|dirs \+0)$/.test(inner)) return '"$PWD"';
  }
  if (text.startsWith('`')) {
    const inner = text.slice(1, -1).trim();
    if (/^(pwd|dirs \+0)$/.test(inner)) return '"$PWD"';
    return '"$(' + inner.replace(/"/g, '\\"') + ')"';
  }
  return '"' + text + '"';
}

function transformTestLine(line) {
  let out = line;
  out = out.replace(/(^|[^\[])\[\s+-n\s+(\$[A-Za-z_][A-Za-z0-9_]*|\$\{[^}]+\})\s+\]/g, (m, p, v) => `${p}[ ${quoteExpansion(v)} != "" ]`);
  out = out.replace(/(^|[^\[])\[\s+-z\s+(\$[A-Za-z_][A-Za-z0-9_]*|\$\{[^}]+\})\s+\]/g, (m, p, v) => `${p}[ ${quoteExpansion(v)} = "" ]`);
  out = out.replace(/(^|[^\[])\[\s+x(\$[A-Za-z_][A-Za-z0-9_]*|\$\{[^}]+\})\s*=\s*x?([^\] ;]+)\s+\]/g, (m, p, v, rhs) => {
    if (rhs.startsWith('x')) rhs = rhs.slice(1);
    return p + '[ ' + quoteExpansion(v) + ' = ' + rhs + ' ]';
  });
  out = out.replace(/(^|[^\[])\[\s*(\$[A-Za-z_][A-Za-z0-9_]*|\$\{[^}]+\})\s*([!=]=?)\s*([^\]\s]+)\s+\]/g,
    (m, p, v, op, rhs) => p + '[ ' + quoteExpansion(v) + ' ' + op.replace('==', '=') + ' ' + rhs + ' ]');
  return out;
}

function transformLine(line, heredocState) {
  if (heredocState.active) {
    if (line.trim() === heredocState.tag) heredocState.active = false;
    return line;
  }
  const hd = detectHeredoc(line);
  let firstPass = transformTestLine(line);
  let out = '';
  let quote = null, tokenStart = 0, wordHadQuote = false, inDoubleBracket = false;
  let context = null;
  for (let i = 0; i < firstPass.length;) {
    const c = firstPass[i], n = firstPass[i + 1];
    if (!quote && c === '#' && (i === 0 || isSpace(firstPass[i - 1]))) {
      out += firstPass.slice(i);
      break;
    }
    if (!quote && c === '[' && n === '[') inDoubleBracket = true;
    if (!quote && c === ']' && n === ']') inDoubleBracket = false;
    if (!quote && (isSpace(c) || isOp(c))) {
      if (c === ';' || c === '|' || c === '&' || c === '(' || c === ')') context = null;
      out += c; i++;
      tokenStart = i; wordHadQuote = false;
      continue;
    }
    if (!quote && c === '\'' ) {
      quote = '\''; wordHadQuote = true; out += c; i++; continue;
    }
    if (quote === '\'') {
      out += c; i++;
      if (c === '\'') quote = null;
      continue;
    }
    if (c === '"') {
      quote = quote === '"' ? null : '"';
      wordHadQuote = true; out += c; i++; continue;
    }
    if (quote === '"') {
      out += c;
      if (c === '\\' && i + 1 < firstPass.length) { out += firstPass[i + 1]; i += 2; }
      else i++;
      continue;
    }
    if (c === '`') {
      const end = parseBacktick(firstPass, i);
      const text = firstPass.slice(i, end);
      if (!wordHadQuote && !inDoubleBracket && !atAssignmentRhs(firstPass, tokenStart)) out += quoteExpansion(text);
      else out += text;
      i = end; continue;
    }
    if (c === '$') {
      const p = parseDollar(firstPass, i);
      if (p) {
        const before = tokenBefore(firstPass, tokenStart);
        const forIn = before === 'in' || /\bfor\s+\w+\s+in\s*$/.test(firstPass.slice(0, tokenStart));
        const commandName = tokenStart === 0 || /^[\s;|&({]*$/.test(firstPass.slice(0, tokenStart));
        const exportAssign = /\b(?:export|local|declare|readonly)\s+[^;&|]*=$/.test(firstPass.slice(0, i));
        const isCaseWord = /\bcase\s+$/.test(firstPass.slice(0, tokenStart));
        const shouldQuote = !wordHadQuote && !inDoubleBracket && !atAssignmentRhs(firstPass, tokenStart, i) && !exportAssign && !isCaseWord;
        const next = firstPass[p.end] || '';
        const wholeWord = i === tokenStart && (!next || isSpace(next) || isOp(next));
        if (shouldQuote) out += quoteExpansion(p.text, forIn ? 'for-in' : null, wholeWord);
        else out += p.text;
        i = p.end; continue;
      }
    }
    out += c;
    i++;
  }
  out = out.replace(/\[\$([^ ]+?) != ""\]/g, '[ "$$$1" != "" ]');
  out = out.replace(/\[\$([^ ]+?) = ""\]/g, '[ "$$$1" = "" ]');
  if (hd) heredocState.active = true, heredocState.tag = hd;
  return out;
}

function transform(input) {
  const heredocState = { active: false, tag: null };
  return input.split(/(\n)/).reduce((acc, part, idx, arr) => {
    if (part === '\n') return acc + part;
    return acc + transformLine(part, heredocState);
  }, '');
}

function colorize(input, suggest) {
  let base = suggest ? transform(input) : input;
  base = base.replace(/(^|\n)(#![^\n]*)/g, '$1\x1b[0;1;3;38;2;120;144;96m$2\x1b[m');
  base = base.replace(/\b(if|then|fi|for|in|do|done|case|esac|while|until|else|elif|function)\b/g, '\x1b[0;1m$1\x1b[m');
  base = base.replace(/(\$\{[^}]+\}|\$[A-Za-z_][A-Za-z0-9_]*|\$[@*#?$!]|\$\d|\$\([^)]*\)|`[^`]*`)/g, '\x1b[0;38;2;63;127;207m$1\x1b[m');
  return base;
}

function readInput(files) {
  if (files.length === 0 || (files.length === 1 && files[0] === '')) {
    return [{ name: '', data: fs.readFileSync(0, 'utf8') }];
  }
  return files.map(name => ({ name, data: fs.readFileSync(name, 'utf8') }));
}

function main() {
  let mode = 'syntax-suggest';
  const files = [];
  let stop = false;
  for (const arg of process.argv.slice(2)) {
    if (!stop && arg === '--') { stop = true; continue; }
    if (!stop && arg.startsWith('-') && arg !== '') {
      if (arg === '-h' || arg === '--help') { process.stdout.write(HELP); return 0; }
      if (arg === '--version') { console.log('4.3.1'); return 0; }
      if (['--suggest','--syntax','--syntax-suggest','--transform','--check','--replace'].includes(arg)) {
        mode = arg.slice(2); continue;
      }
      console.error(arg + ': No such option.');
      return 3;
    }
    files.push(arg);
  }
  let inputs;
  try { inputs = readInput(files); }
  catch (e) {
    if (e.code === 'ENOENT') console.error((e.path || '') + ': No such file or directory (os error 2)');
    else console.error((e.path || '') + ': ' + e.message);
    return 1;
  }
  if (mode === 'replace') {
    let changed = false;
    for (const item of inputs) {
      const t = transform(item.data);
      if (item.name === '') process.stdout.write(t);
      else if (t !== item.data) { fs.writeFileSync(item.name, t); changed = true; }
    }
    return 0;
  }
  const outputs = inputs.map(x => {
    if (mode === 'transform' || mode === 'check') return transform(x.data);
    if (mode === 'syntax') return colorize(x.data, false);
    return colorize(x.data, true);
  });
  if (mode === 'check') return outputs.some((o, i) => o !== inputs[i].data) ? 2 : 0;
  process.stdout.write(outputs.join(''));
  return 0;
}

process.exitCode = main();
