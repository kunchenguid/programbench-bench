#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = '*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***';
const HELP = `${VERSION}
Usage : 
      executable [arg] [input] [output] 

input   : a filename 
          with no FILE, or when FILE is - or stdin, read standard input
Arguments : 
 -1     : fast compression (default) 
 -12    : slowest compression level 
 -T#    : use # threads for compression (default:0==auto) 
 -d     : decompression (default for .lz4 extension)
 -f     : overwrite output without prompting 
 -k     : preserve source files(s)  (default) 
--rm    : remove source file(s) after successful de/compression 
 -h/-H  : display help/long help and exit 

Advanced arguments :
 -V     : display Version number and exit 
 -v     : verbose mode 
 -q     : suppress warnings; specify twice to suppress errors too
 -c     : force write to standard output, even if it is the console
 -t     : test compressed file integrity
 -m     : multiple input files (implies automatic output filenames)
 -r     : operate recursively on directories (sets also -m) 
 -l     : compress using Legacy format (Linux kernel compression)
 -z     : force compression 
 -D FILE: use FILE as dictionary (compression & decompression)
 -B#    : cut file into blocks of size # bytes [32+] 
                     or predefined block size [4-7] (default: 7) 
 -BI    : Block Independence (default) 
 -BD    : Block dependency (improves compression ratio) 
 -BX    : enable block checksum (default:disabled) 
--no-frame-crc : disable stream checksum (default:enabled) 
--content-size : compressed frame includes original size (default:not present)
--list FILE : lists information about .lz4 files (useful for files compressed with --content-size flag)
--[no-]sparse  : sparse mode (default:enabled on file, disabled on stdout)
--favor-decSpeed: compressed files decompress faster, but are less compressed 
--fast[=#]: switch to ultra fast compression level (default: 1)
--best  : same as -12
Benchmark arguments : 
 -b#    : benchmark file(s), using # compression level (default : 1) 
 -e#    : test all compression levels from -bX to # (default : 1)
 -i#    : minimum evaluation time in seconds (default : 3s) 
`;

function rotl(x, r) { return ((x << r) | (x >>> (32 - r))) >>> 0; }
function readU32(buf, p) { return (buf[p] | (buf[p + 1] << 8) | (buf[p + 2] << 16) | (buf[p + 3] << 24)) >>> 0; }
function writeU32(v) {
  const b = Buffer.alloc(4);
  b.writeUInt32LE(v >>> 0, 0);
  return b;
}

function xxhash32(input, seed = 0) {
  const PRIME1 = 0x9E3779B1, PRIME2 = 0x85EBCA77, PRIME3 = 0xC2B2AE3D, PRIME4 = 0x27D4EB2F, PRIME5 = 0x165667B1;
  let p = 0;
  const len = input.length;
  let h;
  if (len >= 16) {
    let v1 = (seed + PRIME1 + PRIME2) >>> 0;
    let v2 = (seed + PRIME2) >>> 0;
    let v3 = seed >>> 0;
    let v4 = (seed - PRIME1) >>> 0;
    const limit = len - 16;
    while (p <= limit) {
      v1 = Math.imul(rotl((v1 + Math.imul(readU32(input, p), PRIME2)) >>> 0, 13), PRIME1) >>> 0; p += 4;
      v2 = Math.imul(rotl((v2 + Math.imul(readU32(input, p), PRIME2)) >>> 0, 13), PRIME1) >>> 0; p += 4;
      v3 = Math.imul(rotl((v3 + Math.imul(readU32(input, p), PRIME2)) >>> 0, 13), PRIME1) >>> 0; p += 4;
      v4 = Math.imul(rotl((v4 + Math.imul(readU32(input, p), PRIME2)) >>> 0, 13), PRIME1) >>> 0; p += 4;
    }
    h = (rotl(v1, 1) + rotl(v2, 7) + rotl(v3, 12) + rotl(v4, 18)) >>> 0;
  } else {
    h = (seed + PRIME5) >>> 0;
  }
  h = (h + len) >>> 0;
  while (p + 4 <= len) {
    h = (h + Math.imul(readU32(input, p), PRIME3)) >>> 0;
    h = Math.imul(rotl(h, 17), PRIME4) >>> 0;
    p += 4;
  }
  while (p < len) {
    h = (h + Math.imul(input[p], PRIME5)) >>> 0;
    h = Math.imul(rotl(h, 11), PRIME1) >>> 0;
    p++;
  }
  h ^= h >>> 15;
  h = Math.imul(h, PRIME2) >>> 0;
  h ^= h >>> 13;
  h = Math.imul(h, PRIME3) >>> 0;
  h ^= h >>> 16;
  return h >>> 0;
}

function compressFrame(data, opts = {}) {
  const flg = opts.contentSize ? 0x6c : 0x64;
  const bd = 0x40;
  const desc = opts.contentSize ? Buffer.alloc(10) : Buffer.from([flg, bd]);
  if (opts.contentSize) {
    desc[0] = flg; desc[1] = bd;
    desc.writeBigUInt64LE(BigInt(data.length), 2);
  }
  const hc = (xxhash32(desc) >>> 8) & 0xff;
  const chunks = [Buffer.from([0x04, 0x22, 0x4d, 0x18]), desc, Buffer.from([hc])];
  const blockSize = 64 * 1024;
  for (let p = 0; p < data.length; p += blockSize) {
    const chunk = data.subarray(p, Math.min(data.length, p + blockSize));
    chunks.push(writeU32((chunk.length | 0x80000000) >>> 0), chunk);
  }
  chunks.push(Buffer.from([0, 0, 0, 0]), writeU32(xxhash32(data)));
  return Buffer.concat(chunks);
}

function compressBlockLiterals(data) {
  const len = data.length;
  const extras = [];
  let tokenLit = len;
  if (tokenLit >= 15) {
    tokenLit = 15;
    let rem = len - 15;
    while (rem >= 255) { extras.push(255); rem -= 255; }
    extras.push(rem);
  }
  return Buffer.concat([Buffer.from([tokenLit << 4]), Buffer.from(extras), data]);
}

function compressLegacy(data) {
  const chunks = [Buffer.from([0x02, 0x21, 0x4c, 0x18])];
  const blockSize = 8 * 1024 * 1024;
  for (let p = 0; p < data.length; p += blockSize) {
    const block = compressBlockLiterals(data.subarray(p, Math.min(data.length, p + blockSize)));
    chunks.push(writeU32(block.length), block);
  }
  return Buffer.concat(chunks);
}

function decompressBlock(block, outParts, outLen) {
  let ip = 0;
  const out = [];
  let op = 0;
  if (outParts.length) {
    const prev = Buffer.concat(outParts);
    for (const byte of prev) out.push(byte);
    op = out.length;
  }
  const base = op;
  while (ip < block.length) {
    const token = block[ip++];
    let litLen = token >>> 4;
    if (litLen === 15) {
      let s;
      do {
        if (ip >= block.length) throw new Error('Malformed input');
        s = block[ip++];
        litLen += s;
      } while (s === 255);
    }
    if (ip + litLen > block.length) throw new Error('Malformed input');
    for (let i = 0; i < litLen; i++) out[op++] = block[ip++];
    if (ip >= block.length) break;
    if (ip + 2 > block.length) throw new Error('Malformed input');
    const offset = block[ip] | (block[ip + 1] << 8); ip += 2;
    if (offset === 0 || offset > op) throw new Error('Malformed input');
    let matchLen = token & 15;
    if (matchLen === 15) {
      let s;
      do {
        if (ip >= block.length) throw new Error('Malformed input');
        s = block[ip++];
        matchLen += s;
      } while (s === 255);
    }
    matchLen += 4;
    for (let i = 0; i < matchLen; i++) out[op] = out[op - offset], op++;
  }
  return Buffer.from(out.slice(base));
}

function decompressFrame(buf, testOnly = false) {
  let p = 0;
  const outputs = [];
  while (p < buf.length) {
    if (p + 4 > buf.length) throw new Error('Unrecognized header');
    const magic = readU32(buf, p); p += 4;
    if (magic === 0x184C2102) {
      while (p < buf.length) {
        if (p + 4 > buf.length) throw new Error('Malformed legacy stream');
        const size = readU32(buf, p); p += 4;
        if (p + size > buf.length) throw new Error('Malformed legacy stream');
        outputs.push(decompressBlock(buf.subarray(p, p + size), []));
        p += size;
      }
      continue;
    }
    if (magic === 0x184D2A50) {
      if (p + 4 > buf.length) throw new Error('Malformed input');
      const size = readU32(buf, p); p += 4;
      if (p + size > buf.length) throw new Error('Malformed input');
      outputs.push(buf.subarray(p, p + size));
      p += size;
      continue;
    }
    if (magic < 0x184D2A50 || magic > 0x184D2A5F) {
      if (magic !== 0x184D2204) throw new Error('Unrecognized header');
      if (p + 3 > buf.length) throw new Error('Malformed input');
      const flg = buf[p++], bd = buf[p++];
      const hasBlockChecksum = (flg & 0x10) !== 0;
      const hasContentSize = (flg & 0x08) !== 0;
      const hasContentChecksum = (flg & 0x04) !== 0;
      const hasDictId = (flg & 0x01) !== 0;
      if ((flg >>> 6) !== 1) throw new Error('Unsupported frame');
      const descStart = p - 2;
      let expectedSize = null;
      if (hasContentSize) {
        if (p + 8 > buf.length) throw new Error('Malformed input');
        expectedSize = Number(buf.readBigUInt64LE(p));
        p += 8;
      }
      if (hasDictId) p += 4;
      if (p >= buf.length) throw new Error('Malformed input');
      const givenHc = buf[p++];
      const calcHc = (xxhash32(buf.subarray(descStart, p - 1)) >>> 8) & 0xff;
      if (givenHc !== calcHc) throw new Error('Header checksum mismatch');
      const independent = (flg & 0x20) !== 0;
      const frameParts = [];
      while (true) {
        if (p + 4 > buf.length) throw new Error('Malformed input');
        let blockSize = readU32(buf, p); p += 4;
        if (blockSize === 0) break;
        const raw = (blockSize & 0x80000000) !== 0;
        blockSize &= 0x7fffffff;
        if (p + blockSize > buf.length) throw new Error('Malformed input');
        const block = buf.subarray(p, p + blockSize); p += blockSize;
        if (hasBlockChecksum) p += 4;
        if (raw) frameParts.push(Buffer.from(block));
        else frameParts.push(decompressBlock(block, independent ? [] : frameParts));
      }
      const frame = Buffer.concat(frameParts);
      if (expectedSize !== null && frame.length !== expectedSize) throw new Error('Content size mismatch');
      if (hasContentChecksum) {
        if (p + 4 > buf.length) throw new Error('Malformed input');
        const got = readU32(buf, p); p += 4;
        if (got !== xxhash32(frame)) throw new Error('Content checksum mismatch');
      }
      if (!testOnly) outputs.push(frame);
    } else {
      if (p + 4 > buf.length) throw new Error('Malformed skippable frame');
      const size = readU32(buf, p); p += 4 + size;
    }
  }
  return Buffer.concat(outputs);
}

function parseArgs(argv) {
  const opts = { mode: null, stdout: false, test: false, force: false, quiet: 0, multiple: false, rm: false, contentSize: false, list: false, legacy: false, benchmark: false };
  const files = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h' || a === '-H') opts.help = true;
    else if (a === '-V' || a === '--version') opts.version = true;
    else if (a === '--rm') opts.rm = true;
    else if (a === '--content-size') opts.contentSize = true;
    else if (a === '--no-frame-crc' || a === '--sparse' || a === '--no-sparse' || a === '--best' || a.startsWith('--fast') || a === '--favor-decSpeed') {}
    else if (a === '--list') { opts.list = true; opts.mode = 'list'; if (argv[i + 1]) files.push(argv[++i]); }
    else if (a.startsWith('-') && a !== '-') {
      if (a.startsWith('-D') && a.length === 2) i++;
      for (let j = 1; j < a.length; j++) {
        const c = a[j];
        if (c === 'd') opts.mode = 'decompress';
        else if (c === 'z') opts.mode = 'compress';
        else if (c === 't') { opts.mode = 'decompress'; opts.test = true; }
        else if (c === 'c') opts.stdout = true;
        else if (c === 'f') opts.force = true;
        else if (c === 'q') opts.quiet++;
        else if (c === 'm' || c === 'r') opts.multiple = true;
        else if (c === 'l') opts.legacy = true;
        else if (c === 'b') { opts.benchmark = true; break; }
        else if (c === 'B' || c === 'T' || c === 'e' || c === 'i') break;
      }
    } else {
      files.push(a);
    }
  }
  return { opts, files };
}

function readInput(name) {
  if (!name || name === '-') return fs.readFileSync(0);
  return fs.readFileSync(name);
}
function outputName(input, mode) {
  if (!input || input === '-') return null;
  if (mode === 'decompress') return input.endsWith('.lz4') ? input.slice(0, -4) : input + '.out';
  return input + '.lz4';
}
function writeOutput(name, data) {
  if (!name || name === '-' || name === 'stdout') fs.writeFileSync(1, data);
  else if (name === 'null') {}
  else fs.writeFileSync(name, data);
}

function listFile(file) {
  const data = fs.readFileSync(file);
  const out = decompressFrame(data);
  console.log('Frames  Type  Block  Compressed  Uncompressed  Ratio  Filename');
  console.log(`1       LZ4   -      ${data.length}          ${out.length}            ${(data.length * 100 / Math.max(out.length, 1)).toFixed(2)}%  ${file}`);
}

function main() {
  const { opts, files } = parseArgs(process.argv.slice(2));
  if (opts.version) { console.log(VERSION); return; }
  if (opts.help) { process.stdout.write(HELP); return; }
  try {
    if (opts.list) {
      const targets = files.length ? files : ['-'];
      for (const f of targets) listFile(f);
      return;
    }
    if (opts.benchmark) {
      console.log('Benchmark mode is not available in this JavaScript build.');
      return;
    }
    const targets = files.length ? files.slice() : ['-'];
    if (opts.multiple) {
      for (const f of targets) processOne(opts, [f]);
    } else {
      processOne(opts, targets);
    }
  } catch (e) {
    if (opts.quiet < 2) console.error(`executable: ${e.message}`);
    process.exit(1);
  }
}

function processOne(opts, files) {
  const input = files[0] || '-';
  let mode = opts.mode;
  if (!mode) mode = input !== '-' && input.endsWith('.lz4') ? 'decompress' : 'compress';
  const data = readInput(input);
  if (mode === 'decompress') {
    const out = decompressFrame(data, opts.test);
    if (!opts.test) {
      const dest = opts.stdout ? '-' : (files[1] || outputName(input, mode));
      writeOutput(dest, out);
    }
    if (opts.rm && input !== '-') fs.unlinkSync(input);
  } else {
    const out = opts.legacy ? compressLegacy(data) : compressFrame(data, opts);
    const dest = opts.stdout ? '-' : (files[1] || outputName(input, mode));
    writeOutput(dest, out);
    if (opts.rm && input !== '-') fs.unlinkSync(input);
  }
}

main();
