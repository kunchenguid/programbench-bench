#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const VERSION = 'onefetch 2.25.0';
const HELP = `Command-line Git information tool

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]
          Run as if onefetch was started in <input> instead of the current working directory

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

INFO:
  -d, --disabled-fields <FIELD>...
          Allows you to disable FIELD(s) from appearing in the output

      --no-title
          Hides the title

      --number-of-authors <NUM>
          Maximum NUM of authors to be shown
          
          [default: 3]

      --number-of-languages <NUM>
          Maximum NUM of languages to be shown
          
          [default: 6]

      --number-of-file-churns <NUM>
          Maximum NUM of file churns to be shown
          
          [default: 3]

      --churn-pool-size <NUM>
          Minimum NUM of commits from HEAD used to compute the churn summary
          
          By default, the actual value is non-deterministic due to time-based computation and will
          be displayed under the info title "Churn (NUM)"

  -e, --exclude <EXCLUDE>...
          Ignore all files & directories matching EXCLUDE

      --no-bots[=<REGEX>]
          Exclude [bot] commits. Use <REGEX> to override the default pattern

      --no-merges
          Ignores merge commits

  -E, --email
          Show the email address of each author

      --http-url
          Display repository URL as HTTP

      --hide-token
          Hide token in repository URL

      --include-hidden
          Count hidden files and directories

  -T, --type <TYPE>...
          Filters output by language type
          
          [default: programming markup]
          [possible values: programming, markup, prose, data]

TEXT FORMATTING:
  -t, --text-colors <X>...
          Changes the text colors (X X X...)
          
          Goes in order of title, ~, underline, subtitle, colon, and info
          
          For example:
          
          '--text-colors 9 10 11 12 13 14'

  -z, --iso-time
          Use ISO 8601 formatted timestamps

      --number-separator <SEPARATOR>
          Which thousands SEPARATOR to use
          
          [default: plain]
          [possible values: plain, comma, space, underscore]

      --no-bold
          Turns off bold formatting

ASCII:
      --ascii-input <STRING>
          Takes a non-empty STRING as input to replace the ASCII logo
          
          It is possible to pass a generated STRING by command substitution
          
          For example:
          
          '--ascii-input "$(fortune | cowsay -W 25)"'

  -c, --ascii-colors <X>...
          Colors (X X X...) to print the ascii art

  -a, --ascii-language <LANGUAGE>
          Which LANGUAGE's ascii art to print

      --true-color <WHEN>
          Specify when to use true color
          
          If set to auto: true color will be enabled if supported by the terminal
          
          [default: auto]
          [possible values: auto, never, always]

IMAGE:
  -i, --image <IMAGE>
          Path to the IMAGE file

      --image-protocol <PROTOCOL>
          Which image PROTOCOL to use
          
          [possible values: kitty, sixel, iterm]

      --color-resolution <VALUE>
          VALUE of color resolution to use with SIXEL backend
          
          [default: 64]
          [possible values: 16, 32, 64, 128, 256]

VISUALS:
      --no-color-palette
          Hides the color palette

      --no-art
          Hides the ascii art or image if provided

      --nerd-fonts
          Use Nerd Font icons
          
          Replaces language chips with Nerd Font icons

DEVELOPER:
  -o, --output <FORMAT>
          Outputs Onefetch in a specific format
          
          [possible values: json, yaml]

      --generate <SHELL>
          If provided, outputs the completion file for given SHELL
          
          [possible values: bash, elvish, fish, powershell, zsh]

OTHER:
  -l, --languages
          Prints out supported languages

  -p, --package-managers
          Prints out supported package managers
`;

const LANG_LIST = ['ABNF','ABAP','Ada','Agda','Arduino C++','Assembly','ATS','AutoHotKey','BASH','C','CMake','C#','Ceylon','Clojure','CoffeeScript','ColdFusion','Coq','C++','Crystal','CSS','CUDA','D','Dart','Dockerfile','Emacs Lisp','Elixir','Elm','Emojicode','Erlang','F#','Fish','Forth','FORTRAN Legacy','FORTRAN Modern','GDScript','GLSL','Go','GraphQL','Groovy','Haskell','Haxe','HCL','HLSL','HolyC','HTML','Idris','Java','JavaScript','JSON','Jsonnet','JSX','Julia','Jupyter Notebooks','Kotlin','LLVM','Lean','Common Lisp','Lua','Makefile','Markdown','Modelica','Nim','Nix','OCaml','Objective-C','Odin','OpenSCAD','Org','Oz','Pascal','Perl','PHP','PowerShell','Processing','Prolog','Protocol Buffers','PureScript','Python','QML','R','Racket','Ruby','Rust','Scala','Shell','SQL','Svelte','Swift','TOML','TSX','TypeScript','Vim script','Vue','XML','YAML','Zig'];
const PKG_LIST = ['Npm','Cargo'];
const EXT = {
  '.js':['JavaScript','programming'], '.mjs':['JavaScript','programming'], '.cjs':['JavaScript','programming'], '.jsx':['JSX','programming'], '.ts':['TypeScript','programming'], '.tsx':['TSX','programming'],
  '.py':['Python','programming'], '.rs':['Rust','programming'], '.go':['Go','programming'], '.c':['C','programming'], '.h':['C','programming'], '.cpp':['C++','programming'], '.cc':['C++','programming'], '.hpp':['C++','programming'],
  '.java':['Java','programming'], '.rb':['Ruby','programming'], '.php':['PHP','programming'], '.swift':['Swift','programming'], '.kt':['Kotlin','programming'], '.scala':['Scala','programming'], '.sh':['Shell','programming'], '.bash':['BASH','programming'],
  '.html':['HTML','markup'], '.htm':['HTML','markup'], '.css':['CSS','programming'], '.scss':['CSS','programming'], '.md':['Markdown','prose'], '.markdown':['Markdown','prose'], '.xml':['XML','data'], '.json':['JSON','data'], '.yml':['YAML','data'], '.yaml':['YAML','data'], '.toml':['TOML','data'], '.sql':['SQL','data'], '.vue':['Vue','programming'], '.svelte':['Svelte','programming']
};
const SPECIAL = {'Dockerfile':['Dockerfile','programming'], 'Makefile':['Makefile','programming'], 'CMakeLists.txt':['CMake','programming']};

function runGit(args, cwd, ok=false) {
  try { return cp.execFileSync('git', args, {cwd, encoding:'utf8', stdio:['ignore','pipe','pipe']}).trimEnd(); }
  catch (e) { if (ok) return ''; throw e; }
}
function parseArgs(argv) {
  const o = {input:null, output:null, disabled:new Set(), noTitle:false, noArt:false, email:false, httpUrl:false, hideToken:false, includeHidden:false, iso:false, noMerges:false, noBots:null, excludes:[], nAuthors:3, nLangs:6, nChurn:3, churnPool:null, numSep:'plain', types:new Set(['programming','markup'])};
  for (let i=0;i<argv.length;i++) {
    const a=argv[i];
    if (a==='-h'||a==='--help') { o.help=true; continue; }
    if (a==='-V'||a==='--version') { o.version=true; continue; }
    if (a==='-l'||a==='--languages') { o.languages=true; continue; }
    if (a==='-p'||a==='--package-managers') { o.packages=true; continue; }
    if (a==='--no-title') { o.noTitle=true; continue; }
    if (a==='--no-art') { o.noArt=true; continue; }
    if (a==='--no-color-palette'||a==='--nerd-fonts'||a==='--no-bold') { continue; }
    if (a==='-E'||a==='--email') { o.email=true; continue; }
    if (a==='--http-url') { o.httpUrl=true; continue; }
    if (a==='--hide-token') { o.hideToken=true; continue; }
    if (a==='--include-hidden') { o.includeHidden=true; continue; }
    if (a==='-z'||a==='--iso-time') { o.iso=true; continue; }
    if (a==='--no-merges') { o.noMerges=true; continue; }
    if (a.startsWith('--no-bots')) { o.noBots = a.includes('=') ? a.slice(a.indexOf('=')+1) : '\\[bot\\]|bot$'; continue; }
    if (a==='-o'||a==='--output') { o.output=argv[++i]; continue; }
    if (a==='-d'||a==='--disabled-fields') { while (argv[i+1] && !argv[i+1].startsWith('-')) o.disabled.add(argv[++i].toLowerCase()); continue; }
    if (a==='-e'||a==='--exclude') { while (argv[i+1] && !argv[i+1].startsWith('-')) o.excludes.push(argv[++i]); continue; }
    if (a==='--number-of-authors') { o.nAuthors=Number(argv[++i]||3); continue; }
    if (a==='--number-of-languages') { o.nLangs=Number(argv[++i]||6); continue; }
    if (a==='--number-of-file-churns') { o.nChurn=Number(argv[++i]||3); continue; }
    if (a==='--churn-pool-size') { o.churnPool=Number(argv[++i]||0); continue; }
    if (a==='--number-separator') { o.numSep=argv[++i]||'plain'; continue; }
    if (a==='-T'||a==='--type') { o.types.clear(); while (argv[i+1] && !argv[i+1].startsWith('-')) o.types.add(argv[++i]); continue; }
    if (['-t','--text-colors','-c','--ascii-colors'].includes(a)) { while (argv[i+1] && !argv[i+1].startsWith('-')) i++; continue; }
    if (['--ascii-input','-a','--ascii-language','--true-color','-i','--image','--image-protocol','--color-resolution','--generate'].includes(a)) { const val=argv[++i]||''; if(a==='--generate'){console.log(`# ${val} completion for onefetch`); process.exit(0);} continue; }
    if (a.startsWith('-')) dieArg(a);
    if (o.input===null) o.input=a; else dieArg(a);
  }
  return o;
}
function dieArg(a){ console.error(`error: unexpected argument '${a}' found\n\n  tip: to pass '${a}' as a value, use '-- ${a}'\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.`); process.exit(2); }
function hidden(p){ return p.split('/').some(x=>x.startsWith('.') && x!=='.'); }
function excluded(p, patterns){ return patterns.some(g => p===g || p.includes(g) || (g.endsWith('/') && p.startsWith(g)) || new RegExp('^'+g.replace(/[.+^${}()|[\]\\]/g,'\\$&').replace(/\*/g,'.*')+'$').test(p)); }
function langOf(file){ const b=path.basename(file); if(SPECIAL[b]) return SPECIAL[b]; const e=path.extname(file); return EXT[e]||null; }
function countLoc(full, lang){
  let s; try{s=fs.readFileSync(full,'utf8');}catch{return 0;}
  let n=0; const slash = !['Markdown','JSON','YAML','TOML'].includes(lang);
  for (const line of s.split(/\r?\n/)) { const t=line.trim(); if(!t) continue; if(slash && (t.startsWith('//')||t.startsWith('#')||t.startsWith('/*')||t.startsWith('*'))) continue; n++; }
  return n;
}
function fmtNum(n, sep){ const s=String(n); if(sep==='comma') return s.replace(/\B(?=(\d{3})+(?!\d))/g, ','); if(sep==='space') return s.replace(/\B(?=(\d{3})+(?!\d))/g, ' '); if(sep==='underscore') return s.replace(/\B(?=(\d{3})+(?!\d))/g, '_'); return s; }
function fmtSize(bytes){ if(bytes<1024) return `${bytes} B`; const units=['KiB','MiB','GiB']; let v=bytes/1024,i=0; while(v>=1024&&i<units.length-1){v/=1024;i++;} return `${v.toFixed(v<10?2:1).replace(/\.0$/,'')} ${units[i]}`; }
function relTime(sec, iso){ if(!sec) return ''; const d=new Date(sec*1000); if(iso) return d.toISOString(); const diff=Math.max(0, Math.floor(Date.now()/1000-sec)); if(diff<2) return 'now'; if(diff<60) return `${diff} seconds ago`; const m=Math.floor(diff/60); if(m<60) return m===1?'a minute ago':`${m} minutes ago`; const h=Math.floor(m/60); if(h<24) return h===1?'an hour ago':`${h} hours ago`; const days=Math.floor(h/24); if(days<30) return days===1?'a day ago':`${days} days ago`; const mo=Math.floor(days/30); if(mo<12) return mo===1?'a month ago':`${mo} months ago`; const y=Math.floor(days/365); return y===1?'a year ago':`${y} years ago`; }
function repoUrl(cwd,o){ let u=runGit(['config','--get','remote.origin.url'], cwd, true); if(!u) return ''; if(o.httpUrl && u.startsWith('git@')) { const m=u.match(/^git@([^:]+):(.+)$/); if(m) u=`https://${m[1]}/${m[2]}`; } if(o.hideToken) u=u.replace(/https:\/\/[^/@]+@/,'https://'); return u; }
function repoName(url){ if(!url) return ''; let u=url.replace(/\.git$/,''); return path.basename(u); }
function build(o){
  const input=o.input||'.'; let root;
  try { root=runGit(['-C',input,'rev-parse','--show-toplevel'], process.cwd()); } catch(e) { console.error(`Error: Could not find a git repository in '${input}' or in any of its parents`); process.exit(1); }
  const gitArgs = []; if(o.noMerges) gitArgs.push('--no-merges');
  const name=runGit(['config','--get','user.name'], root, true) || process.env.USER || '';
  const gitVer=cp.execFileSync('git',['--version'],{encoding:'utf8'}).trim();
  const url=repoUrl(root,o);
  const head=runGit(['rev-parse','--short=7','HEAD'], root, true);
  const branch=runGit(['branch','--show-current'], root, true);
  const refs=branch?[branch]:[];
  const porcelain=runGit(['status','--porcelain'], root, true).split('\n').filter(Boolean);
  let added=0,deleted=0,modified=0; for(const l of porcelain){ if(l[0]==='A'||l[1]==='A'||l.startsWith('??')) added++; if(l[0]==='D'||l[1]==='D') deleted++; if(l[0]==='M'||l[1]==='M') modified++; }
  let files=runGit(['ls-files'], root, true).split('\n').filter(Boolean).filter(f=>(o.includeHidden||!hidden(f))&&!excluded(f,o.excludes));
  let bytes=0, loc=0, langs=new Map();
  for(const f of files){ const full=path.join(root,f); try{bytes+=fs.statSync(full).size;}catch{} const l=langOf(f); if(l && o.types.has(l[1])) { const c=countLoc(full,l[0]); if(c>0){ loc+=c; langs.set(l[0],(langs.get(l[0])||0)+c); } } }
  let langArr=[...langs.entries()].map(([language,lines])=>({language, percentage: totalPct(lines,loc)})).sort((a,b)=>b.percentage-a.percentage||a.language.localeCompare(b.language)).slice(0,o.nLangs);
  const logFmt='%an%x00%ae'; let logArgs=['log',...gitArgs,'--format='+logFmt];
  let authorLines=runGit(logArgs, root, true).split('\n').filter(Boolean);
  if(o.noBots){ const re=new RegExp(o.noBots,'i'); authorLines=authorLines.filter(l=>!re.test(l)); }
  const amap=new Map(); for(const l of authorLines){ const [an,ae]=l.split('\x00'); const k=an+'\x00'+ae; if(!amap.has(k)) amap.set(k,{name:an,email:o.email?ae:null,nbrOfCommits:0}); amap.get(k).nbrOfCommits++; }
  const totalCommits=authorLines.length || Number(runGit(['rev-list','--count','HEAD'], root, true)||0);
  const authors=[...amap.values()].sort((a,b)=>b.nbrOfCommits-a.nbrOfCommits||a.name.localeCompare(b.name)).map(a=>({...a, contribution: totalCommits?Math.round(a.nbrOfCommits*100/totalCommits):0}));
  const first=Number(runGit(['log','--reverse','--format=%ct','-n','1'], root, true).split('\n')[0]||0);
  const last=Number(runGit(['log','-n','1','--format=%ct'], root, true)||0);
  const commitCount=Number(runGit(['rev-list','--count','HEAD'], root, true)||0);
  const pool=o.churnPool||Math.min(commitCount, Math.max(1, Math.min(200, commitCount>1?1:commitCount)));
  const churnMap=new Map(); const churnOut=runGit(['log',`-${pool}`,'--name-only','--format='], root, true).split('\n').filter(Boolean);
  for(const f of churnOut){ if(files.includes(f)) churnMap.set(f,(churnMap.get(f)||0)+1); }
  const churn=[...churnMap.entries()].map(([filePath,nbrOfCommits])=>({filePath,nbrOfCommits})).sort((a,b)=>b.nbrOfCommits-a.nbrOfCommits||a.filePath.localeCompare(b.filePath)).slice(0,o.nChurn);
  const lic=detectLicense(root);
  const data={ title:{gitUsername:name,gitVersion:gitVer}, infoFields:[] };
  const add=(key,obj,names)=>{ if(!names.some(n=>o.disabled.has(n.toLowerCase()))) data.infoFields.push({[key]:obj}); };
  add('ProjectInfo',{repoName:repoName(url),numberOfBranches:0,numberOfTags:Number(runGit(['tag','--list'],root,true).split('\n').filter(Boolean).length||0)},['project']);
  add('DescriptionInfo',{description:null},['description']);
  add('HeadInfo',{headRefs:{shortCommitId:head,refs}},['head']);
  add('PendingInfo',{added,deleted,modified},['pending']);
  add('VersionInfo',{version:''},['version']);
  add('CreatedInfo',{creationDate:relTime(first,o.iso)},['created']);
  add('LanguagesInfo',{languagesWithPercentage:langArr},['languages','language']);
  add('DependenciesInfo',{dependencies:detectDeps(root)},['dependencies']);
  add('AuthorsInfo',{authors:authors.slice(0,o.nAuthors)},['authors','author']);
  add('LastChangeInfo',{lastChange:relTime(last,o.iso)},['last change','last-change','lastchange']);
  add('ContributorsInfo',{totalNumberOfAuthors:authors.length},['contributors']);
  add('UrlInfo',{repoUrl:url},['url']);
  add('CommitsInfo',{numberOfCommits:commitCount,isShallow:fs.existsSync(path.join(root,'.git','shallow'))},['commits']);
  if(churn.length) add('ChurnInfo',{file_churns:churn,churn_pool_size:pool},['churn']);
  add('LocInfo',{linesOfCode:loc},['lines of code','loc','code']);
  add('SizeInfo',{repoSize:fmtSize(bytes),fileCount:files.length},['size']);
  add('LicenseInfo',{license:lic},['license']);
  return data;
}
function totalPct(lines,total){ return total?Math.round(lines*1000/total)/10:0; }
function detectLicense(root){ for(const n of ['LICENSE','LICENSE.md','LICENSE.txt','COPYING']){ const p=path.join(root,n); if(fs.existsSync(p)){ const t=fs.readFileSync(p,'utf8'); if(/Permission is hereby granted, free of charge/.test(t)) return 'MIT'; if(/Apache License/.test(t)) return 'Apache-2.0'; if(/GNU GENERAL PUBLIC LICENSE/i.test(t)) return 'GPL'; } } return ''; }
function detectDeps(root){ return ''; }
function jsonOut(data){ return JSON.stringify(data,null,2).replace(/(\"percentage\": )(\d+)([,\n])/g, '$1$2.0$3'); }
function yamlOut(data){ return toYaml(data).replace(/(percentage: )(\d+)(\n)/g, '$1$2.0$3'); }
function toYaml(v, indent=0){ const sp=' '.repeat(indent); if(v===null) return 'null'; if(typeof v==='string') return v===''?"''":v; if(typeof v==='number'||typeof v==='boolean') return String(v); if(Array.isArray(v)){ if(!v.length) return '[]'; return v.map(x=> typeof x==='object'&&x!==null ? `${sp}- ${objFirstYaml(x, indent+2)}` : `${sp}- ${toYaml(x, indent+2)}`).join('\n'); } if(typeof v==='object'){ return Object.entries(v).map(([k,val])=> complex(val) ? `${sp}${k}:\n${toYaml(val,indent+2)}` : `${sp}${k}: ${toYaml(val,indent+2)}`).join('\n'); } return String(v); }
function complex(v){ return v && typeof v==='object'; }
function objFirstYaml(o, indent){ const entries=Object.entries(o); if(entries.length===0) return '{}'; const [k,v]=entries[0]; let s=complex(v) ? `${k}:\n${toYaml(v,indent+2)}` : `${k}: ${toYaml(v,indent)}`; for(const [kk,vv] of entries.slice(1)) s+= complex(vv) ? `\n${' '.repeat(indent)}${kk}:\n${toYaml(vv,indent+2)}` : `\n${' '.repeat(indent)}${kk}: ${toYaml(vv,indent)}`; return s; }
function render(data,o){ const rows=[]; if(!o.noTitle) rows.push(`${data.title.gitUsername} ~ ${data.title.gitVersion}`); for(const item of data.infoFields){ const k=Object.keys(item)[0], v=item[k]; if(k==='HeadInfo') rows.push(`HEAD: ${v.headRefs.shortCommitId}${v.headRefs.refs.length?' ('+v.headRefs.refs.join(', ')+')':''}`); else if(k==='PendingInfo' && (v.added||v.deleted||v.modified)) rows.push(`Pending: ${v.added? v.added+'+ ':''}${v.deleted? v.deleted+'- ':''}${v.modified? v.modified+'~':''}`.trim()); else if(k==='CreatedInfo') rows.push(`Created: ${v.creationDate}`); else if(k==='LanguagesInfo') rows.push(`Languages: ${v.languagesWithPercentage.map(x=>`${x.language} (${x.percentage.toFixed(1)} %)`).join(', ')}`); else if(k==='AuthorsInfo') rows.push(`${v.authors.length>1?'Authors':'Author'}: ${v.authors.map(a=>`${a.contribution}% ${a.name} ${a.nbrOfCommits}`).join(', ')}`); else if(k==='LastChangeInfo') rows.push(`Last change: ${v.lastChange}`); else if(k==='CommitsInfo') rows.push(`Commits: ${fmtNum(v.numberOfCommits,o.numSep)}${v.isShallow?' (shallow)':''}`); else if(k==='ChurnInfo') { rows.push(`Churn (${v.churn_pool_size}): ${v.file_churns[0]?.filePath||''} ${v.file_churns[0]?.nbrOfCommits||''}`); for(const c of v.file_churns.slice(1)) rows.push(`           ${c.filePath} ${c.nbrOfCommits}`); } else if(k==='LocInfo') rows.push(`Lines of code: ${fmtNum(v.linesOfCode,o.numSep)}`); else if(k==='SizeInfo') rows.push(`Size: ${v.repoSize} (${v.fileCount} files)`); else if(k==='LicenseInfo' && v.license) rows.push(`License: ${v.license}`); else if(k==='UrlInfo' && v.repoUrl) rows.push(`Repo: ${v.repoUrl}`); else if(k==='DependenciesInfo' && v.dependencies) rows.push(`Dependencies: ${v.dependencies}`); }
  console.log(rows.join('\n'));
}
function main(){ const o=parseArgs(process.argv.slice(2)); if(o.help){process.stdout.write(HELP);return;} if(o.version){console.log(VERSION);return;} if(o.languages){console.log(LANG_LIST.join('\n'));return;} if(o.packages){console.log(PKG_LIST.join('\n'));return;} const data=build(o); if(o.output==='json') console.log(jsonOut(data)); else if(o.output==='yaml') console.log(yamlOut(data)); else render(data,o); }
main();
