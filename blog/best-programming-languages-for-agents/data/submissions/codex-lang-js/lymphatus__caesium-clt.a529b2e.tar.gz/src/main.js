#!/usr/bin/env node
"use strict";

const fs = require("fs");
const fsp = fs.promises;
const path = require("path");
const sharp = require("sharp");

const VERSION = "caesiumclt 1.3.0";

const HELP_LONG = `A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...
          Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality

      --lossless
          Use lossless compression (may increase file size for some formats)

      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)

      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)

      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)

      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image

      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image

      --no-upscale
          Prevents upscaling of the image when resizing

  -o, --output <OUTPUT>
          Output directory path

      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)

      --format <FORMAT>
          Convert to the selected output format or keep the original
          
          [default: original]
          [possible values: jpeg, png, gif, webp, tiff, original]

      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression
          
          [default: 3]

      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files
          
          [default: auto]
          [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]

      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)

      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)

  -e, --exif
          Keep EXIF metadata during compression

      --keep-dates
          Preserve original file timestamps

      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag

      --suffix <SUFFIX>
          Add suffix to output filenames

  -R, --recursive
          Scan subfolders recursively when input is a directory

  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)

  -d, --dry-run
          Simulate compression without writing files

      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors)
          
          [default: 0]

  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files

          Possible values:
          - all:    Always overwrite existing files
          - never:  Never overwrite existing files
          - bigger: Overwrite only if the existing file is bigger
          
          [default: all]

      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes

  -Q, --quiet
          Suppress all output

      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all
          
          [default: 1]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`;

const HELP_SHORT = `A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...  Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality
      --lossless
          Use lossless compression (may increase file size for some formats)
      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)
      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)
      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)
      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image
      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image
      --no-upscale
          Prevents upscaling of the image when resizing
  -o, --output <OUTPUT>
          Output directory path
      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)
      --format <FORMAT>
          Convert to the selected output format or keep the original [default: original] [possible values: jpeg, png, gif, webp, tiff, original]
      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression [default: 3]
      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files [default: auto] [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]
      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)
      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)
  -e, --exif
          Keep EXIF metadata during compression
      --keep-dates
          Preserve original file timestamps
      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag
      --suffix <SUFFIX>
          Add suffix to output filenames
  -R, --recursive
          Scan subfolders recursively when input is a directory
  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)
  -d, --dry-run
          Simulate compression without writing files
      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors) [default: 0]
  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files [default: all] [possible values: all, never, bigger]
      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes
  -Q, --quiet
          Suppress all output
      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all [default: 1]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version`;

const extToFormat = new Map([
  [".jpg", "jpeg"], [".jpeg", "jpeg"], [".png", "png"], [".gif", "gif"],
  [".webp", "webp"], [".tif", "tiff"], [".tiff", "tiff"],
]);
const inputExts = new Set([".jpg", ".jpeg", ".png", ".gif", ".webp"]);
const formatExt = { jpeg: ".jpg", png: ".png", gif: ".gif", webp: ".webp", tiff: ".tiff" };

function die(message, code = 2) {
  process.stderr.write(message + "\n");
  process.exit(code);
}

function clapError(body) {
  die(`error: ${body}\n\nFor more information, try '--help'.`, 2);
}

function parseNum(name, value) {
  if (value == null || value.startsWith("-")) clapError(`a value is required for '${name} <${name.replace(/^--/, "").replaceAll("-", "_").toUpperCase()}>'`);
  const n = Number(value);
  if (!Number.isFinite(n)) clapError(`invalid value '${value}' for '${name}'`);
  return Math.trunc(n);
}

function parseSize(s) {
  const m = String(s).trim().match(/^([0-9]+(?:\.[0-9]+)?)([kmgt]?i?b?)?$/i);
  if (!m) return NaN;
  const units = { "": 1, b: 1, k: 1000, kb: 1000, m: 1000 ** 2, mb: 1000 ** 2, g: 1000 ** 3, gb: 1000 ** 3,
    kib: 1024, mib: 1024 ** 2, gib: 1024 ** 3 };
  return Math.floor(Number(m[1]) * (units[m[2].toLowerCase()] ?? NaN));
}

function parseArgs(argv) {
  const o = {
    files: [], format: "original", pngOptLevel: 3, overwrite: "all", verbose: 1,
    suffix: "", threads: 0, jpegChromaSubsampling: "auto",
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = () => argv[++i];
    if (a === "--help") { console.log(HELP_LONG); process.exit(0); }
    else if (a === "-h") { console.log(HELP_SHORT); process.exit(0); }
    else if (a === "-V" || a === "--version") { console.log(VERSION); process.exit(0); }
    else if (a === "-q" || a === "--quality") o.quality = parseNum("--quality", next());
    else if (a === "--lossless") o.lossless = true;
    else if (a === "--max-size") o.maxSize = next();
    else if (a === "--width") o.width = Math.max(0, parseNum("--width", next()));
    else if (a === "--height") o.height = Math.max(0, parseNum("--height", next()));
    else if (a === "--long-edge") o.longEdge = Math.max(0, parseNum("--long-edge", next()));
    else if (a === "--short-edge") o.shortEdge = Math.max(0, parseNum("--short-edge", next()));
    else if (a === "--no-upscale") o.noUpscale = true;
    else if (a === "-o" || a === "--output") o.output = next();
    else if (a === "--same-folder-as-input") o.sameFolder = true;
    else if (a === "--format") o.format = next();
    else if (a === "--png-opt-level") o.pngOptLevel = parseNum("--png-opt-level", next());
    else if (a === "--jpeg-chroma-subsampling") o.jpegChromaSubsampling = next();
    else if (a === "--jpeg-baseline") o.jpegBaseline = true;
    else if (a === "--zopfli") o.zopfli = true;
    else if (a === "-e" || a === "--exif") o.exif = true;
    else if (a === "--keep-dates") o.keepDates = true;
    else if (a === "--strip-icc") o.stripIcc = true;
    else if (a === "--suffix") o.suffix = next() ?? "";
    else if (a === "-R" || a === "--recursive") o.recursive = true;
    else if (a === "-S" || a === "--keep-structure") o.keepStructure = true;
    else if (a === "-d" || a === "--dry-run") o.dryRun = true;
    else if (a === "--threads") o.threads = parseNum("--threads", next());
    else if (a === "-O" || a === "--overwrite") o.overwrite = next();
    else if (a === "--min-savings") o.minSavings = next();
    else if (a === "-Q" || a === "--quiet") { o.quiet = true; o.verbose = 0; }
    else if (a === "--verbose") o.verbose = parseNum("--verbose", next());
    else if (a.startsWith("-")) clapError(`unexpected argument '${a}' found`);
    else o.files.push(a);
  }
  validate(o);
  return o;
}

function validate(o) {
  const modes = [o.quality !== undefined, !!o.lossless, o.maxSize !== undefined].filter(Boolean).length;
  const dests = [o.output !== undefined, !!o.sameFolder].filter(Boolean).length;
  if (modes === 0 || dests === 0) {
    const missing = [];
    if (modes === 0) missing.push("  <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>");
    if (dests === 0) missing.push("  <--output <OUTPUT>|--same-folder-as-input>");
    die(`error: the following required arguments were not provided:\n${missing.join("\n")}\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n\nFor more information, try '--help'.`, 2);
  }
  if (modes > 1) {
    const pair = o.quality !== undefined && o.lossless ? "'--quality <QUALITY>' cannot be used with '--lossless'" : "compression arguments cannot be used together";
    die(`error: the argument ${pair}\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...\n\nFor more information, try '--help'.`, 2);
  }
  if (dests > 1) clapError("the argument '--output <OUTPUT>' cannot be used with '--same-folder-as-input'");
  if (o.quality !== undefined && (o.quality < 0 || o.quality > 100)) clapError(`invalid value '${o.quality}' for '--quality <QUALITY>': Quality must be between 0 and 100, but got ${o.quality}`);
  if (!["jpeg", "png", "gif", "webp", "tiff", "original"].includes(o.format)) clapError(`invalid value '${o.format}' for '--format <FORMAT>'\n  [possible values: jpeg, png, gif, webp, tiff, original]`);
  if (o.pngOptLevel < 0 || o.pngOptLevel > 6) clapError(`invalid value '${o.pngOptLevel}' for '--png-opt-level <PNG_OPT_LEVEL>': PNG optimization level must be between 0 and 6, but got ${o.pngOptLevel}`);
  if (!["4:4:4", "4:2:2", "4:2:0", "4:1:1", "auto"].includes(o.jpegChromaSubsampling)) clapError(`invalid value '${o.jpegChromaSubsampling}' for '--jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>'`);
  if (!["all", "never", "bigger"].includes(o.overwrite)) clapError(`invalid value '${o.overwrite}' for '--overwrite <OVERWRITE>'\n  [possible values: all, never, bigger]`);
}

async function collectInputs(args, recursive) {
  const out = [];
  for (const input of args) {
    let st;
    try { st = await fsp.stat(input); } catch { continue; }
    if (st.isDirectory()) {
      const base = path.resolve(input);
      const walk = async (dir) => {
        for (const ent of await fsp.readdir(dir, { withFileTypes: true })) {
          const p = path.join(dir, ent.name);
          if (ent.isDirectory()) {
            if (recursive) await walk(p);
          } else if (ent.isFile() && inputExts.has(path.extname(ent.name).toLowerCase())) {
            out.push({ path: p, root: base });
          }
        }
      };
      await walk(input);
    } else if (st.isFile() && inputExts.has(path.extname(input).toLowerCase())) {
      out.push({ path: input, root: path.dirname(path.resolve(input)) });
    }
  }
  return out;
}

function human(n) {
  const sign = n < 0 ? "-" : "";
  let v = Math.abs(n);
  const units = ["B", "KiB", "MiB", "GiB"];
  let u = 0;
  while (v >= 1024 && u < units.length - 1) { v /= 1024; u++; }
  if (u === 0) return `${sign}${Math.round(v)} B`;
  return `${sign}${v.toFixed(1)} ${units[u]}`;
}

function outputPath(item, o) {
  const src = item.path;
  const inExt = path.extname(src);
  const inFmt = extToFormat.get(inExt.toLowerCase()) || "jpeg";
  const fmt = o.format === "original" ? inFmt : o.format;
  const ext = o.format === "original" ? inExt : formatExt[fmt];
  const name = path.basename(src, inExt) + (o.suffix || "") + ext;
  if (o.sameFolder) return path.join(path.dirname(src), name);
  const relDir = o.keepStructure ? path.dirname(path.relative(item.root, path.resolve(src))) : "";
  return path.join(o.output, relDir === "." ? "" : relDir, name);
}

function resizeOptions(meta, o) {
  const width = meta.width || 0, height = meta.height || 0;
  if (o.width || o.height) return { width: o.width || undefined, height: o.height || undefined, fit: "inside", withoutEnlargement: !!o.noUpscale };
  if (o.longEdge && width && height) return width >= height ? { width: o.longEdge, withoutEnlargement: !!o.noUpscale } : { height: o.longEdge, withoutEnlargement: !!o.noUpscale };
  if (o.shortEdge && width && height) return width <= height ? { width: o.shortEdge, withoutEnlargement: !!o.noUpscale } : { height: o.shortEdge, withoutEnlargement: !!o.noUpscale };
  return null;
}

function applyFormat(img, fmt, o, q) {
  if (fmt === "jpeg") {
    let chromaSubsampling = "4:2:0";
    if (o.jpegChromaSubsampling !== "auto") chromaSubsampling = o.jpegChromaSubsampling;
    return img.jpeg({ quality: q, progressive: !o.jpegBaseline, chromaSubsampling, mozjpeg: false });
  }
  if (fmt === "png") {
    return img.png({ quality: q, compressionLevel: Math.max(0, Math.min(9, o.pngOptLevel + 3)), palette: !o.lossless && q < 100 });
  }
  if (fmt === "webp") return img.webp({ quality: q, lossless: !!o.lossless });
  if (fmt === "gif") return img.gif();
  if (fmt === "tiff") return img.tiff({ quality: q });
  return img;
}

async function renderBuffer(src, out, o, qualityOverride) {
  const inFmt = extToFormat.get(path.extname(src).toLowerCase()) || "jpeg";
  const fmt = o.format === "original" ? inFmt : o.format;
  let img = sharp(src, { animated: inFmt === "gif" }).rotate();
  const meta = await img.metadata();
  const r = resizeOptions(meta, o);
  if (r) img = img.resize(r);
  if ((o.exif || o.keepDates) && !o.stripIcc) img = img.keepMetadata();
  const q = qualityOverride ?? (o.lossless ? 100 : (o.quality ?? 80));
  img = applyFormat(img, fmt, o, q);
  return img.toBuffer();
}

async function bufferForMaxSize(src, out, o) {
  const target = parseSize(o.maxSize);
  if (!Number.isFinite(target) || target <= 0) return renderBuffer(src, out, o, 1);
  let best = null;
  for (let lo = 1, hi = 100, iter = 0; lo <= hi && iter < 8; iter++) {
    const mid = Math.floor((lo + hi) / 2);
    const b = await renderBuffer(src, out, o, mid);
    if (b.length <= target) { best = b; lo = mid + 1; } else hi = mid - 1;
  }
  return best || renderBuffer(src, out, o, 1);
}

function savingsThreshold(o, original) {
  if (!o.minSavings) return 0;
  const s = String(o.minSavings).trim();
  if (s.endsWith("%")) return original * (Number.parseFloat(s) / 100);
  const n = parseSize(s);
  return Number.isFinite(n) ? n : 0;
}

async function processOne(item, o) {
  const src = item.path;
  const out = outputPath(item, o);
  const original = (await fsp.stat(src)).size;
  if (o.dryRun) return { src, out, original, output: original, status: "success" };
  let buf;
  try { buf = o.maxSize !== undefined ? await bufferForMaxSize(src, out, o) : await renderBuffer(src, out, o); }
  catch (e) { return { src, out, original, output: original, status: "error", error: e.message }; }
  const threshold = savingsThreshold(o, original);
  if (threshold && original - buf.length < threshold) return { src, out, original, output: original, status: "skipped" };
  try {
    const exists = fs.existsSync(out);
    if (exists && o.overwrite === "never") return { src, out, original, output: original, status: "skipped" };
    if (exists && o.overwrite === "bigger" && (await fsp.stat(out)).size <= buf.length) return { src, out, original, output: original, status: "skipped" };
    await fsp.mkdir(path.dirname(out), { recursive: true });
    await fsp.writeFile(out, buf);
    if (o.keepDates) {
      const st = await fsp.stat(src);
      await fsp.utimes(out, st.atime, st.mtime).catch(() => {});
    }
    return { src, out, original, output: buf.length, status: "success" };
  } catch (e) {
    return { src, out, original, output: original, status: "error", error: e.message };
  }
}

function printSummary(results, o) {
  if (o.quiet || o.verbose === 0) return;
  const total = results.length;
  const success = results.filter(r => r.status === "success").length;
  const skipped = results.filter(r => r.status === "skipped").length;
  const errors = results.filter(r => r.status === "error").length;
  if (o.verbose >= 3) {
    for (const r of results) {
      if (r.status === "success") {
        const delta = r.output - r.original;
        const pct = r.original ? (delta / r.original) * 100 : 0;
        console.log(`[Success] ${r.src} -> ${r.out}`);
        console.log(`${human(r.original)} -> ${human(r.output)} [${delta >= 0 ? "+" : ""}${human(delta)} | ${delta >= 0 ? "+" : ""}${pct.toFixed(2)}%]\n`);
      } else if (r.status === "skipped") console.log(`[Skipped] ${r.src}`);
      else console.log(`[Error] ${r.src}: ${r.error}`);
    }
  } else if (o.verbose >= 2) {
    for (const r of results) if (r.status !== "success") console.log(`[${r.status === "error" ? "Error" : "Skipped"}] ${r.src}${r.error ? `: ${r.error}` : ""}`);
  }
  const input = results.reduce((a, r) => a + r.original, 0);
  const output = results.reduce((a, r) => a + r.output, 0);
  const delta = output - input;
  const pct = input ? (delta / input) * 100 : 0;
  console.log(`Compressed ${total} files (${success} success, ${skipped} skipped, ${errors} errors)`);
  console.log(`${human(input)} -> ${human(output)} [${delta >= 0 ? "+" : ""}${human(delta)} | ${delta >= 0 ? "+" : ""}${pct.toFixed(2)}%]`);
}

(async function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.files.length === 0) process.exit(0);
  const inputs = await collectInputs(opts.files, opts.recursive);
  if (inputs.length === 0) {
    if (!opts.quiet && opts.verbose !== 0) console.log("Unable to compute the base path for the files.");
    process.exit(255);
  }
  const results = [];
  for (const item of inputs) results.push(await processOne(item, opts));
  printSummary(results, opts);
  process.exit(0);
})().catch(e => {
  console.error(e && e.message ? e.message : String(e));
  process.exit(255);
});
