#!/usr/bin/env node
'use strict';

const HELP = `usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] 
    -s            Show seconds                                   
    -S            Screensaver mode                               
    -x            Show box                                       
    -c            Set the clock at the center of the terminal    
    -C [0-7]      Set the clock color                            
    -b            Use bold colors                                
    -t            Set the hour in 12h format                     
    -u            Use UTC time                                   
    -T tty        Display the clock on the specified terminal    
    -r            Do rebound the clock                           
    -f format     Set the date format                            
    -n            Don't quit on keypress                         
    -v            Show tty-clock version                         
    -i            Show some info about tty-clock                 
    -h            Show this page                                 
    -D            Hide date                                      
    -B            Enable blinking colon                          
    -d delay      Set the delay between two redraws of the clock. Default 1s. 
    -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns.
`;

const DIGITS = {
  '0': [1, 1, 0, 1, 1, 1, 1],
  '1': [0, 0, 0, 1, 0, 0, 1],
  '2': [1, 0, 1, 1, 1, 1, 0],
  '3': [1, 0, 1, 1, 0, 1, 1],
  '4': [0, 1, 1, 1, 0, 0, 1],
  '5': [1, 1, 1, 0, 0, 1, 1],
  '6': [1, 1, 1, 0, 1, 1, 1],
  '7': [1, 0, 0, 1, 0, 0, 1],
  '8': [1, 1, 1, 1, 1, 1, 1],
  '9': [1, 1, 1, 1, 0, 1, 1],
};

function usageError(ch, needsArg) {
  const name = process.env.TTY_CLOCK_ARGV0 || process.argv[1] || './executable';
  process.stderr.write(`${name}: ${needsArg ? 'option requires an argument' : 'invalid option'} -- '${ch}'\n`);
  process.stdout.write(HELP);
  process.exit(0);
}

function parseArgs(argv) {
  const opt = {
    seconds: false, screensaver: false, box: false, center: false,
    color: 2, bold: false, twelve: false, utc: false, rebound: false,
    fmt: '%F', noquit: false, hideDate: false, blink: false,
    delay: 1, nsdelay: 0, tty: null,
  };
  const need = new Set(['C', 'f', 'd', 'a', 'T']);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith('-') || a === '-') continue;
    for (let j = 1; j < a.length; j++) {
      const ch = a[j];
      if (ch === '-') usageError('-', false);
      if (need.has(ch)) {
        let val = a.slice(j + 1);
        if (!val) {
          if (i + 1 >= argv.length) usageError(ch, true);
          val = argv[++i];
        }
        if (ch === 'C') opt.color = /^[0-7]$/.test(val) ? Number(val) : Number(val) || 0;
        if (ch === 'f') opt.fmt = val;
        if (ch === 'd') opt.delay = Math.max(0, Number(val) || 0);
        if (ch === 'a') opt.nsdelay = Math.max(0, Number(val) || 0);
        if (ch === 'T') opt.tty = val;
        break;
      }
      switch (ch) {
        case 's': opt.seconds = true; break;
        case 'S': opt.screensaver = true; break;
        case 'x': opt.box = true; break;
        case 'c': opt.center = true; break;
        case 'b': opt.bold = true; break;
        case 't': opt.twelve = true; break;
        case 'u': opt.utc = true; break;
        case 'r': opt.rebound = true; break;
        case 'n': opt.noquit = true; break;
        case 'D': opt.hideDate = true; break;
        case 'B': opt.blink = true; break;
        case 'v': process.stdout.write('TTY-Clock 2 © devel version\n'); process.exit(0);
        case 'i': process.stdout.write('TTY-Clock 2 © by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)\n'); process.exit(0);
        case 'h': process.stdout.write(HELP); process.exit(0);
        default: usageError(ch, false);
      }
    }
  }
  return opt;
}

function pad(n) { return String(n).padStart(2, '0'); }
function parts(d, utc) {
  const g = utc ? 'getUTC' : 'get';
  return {
    Y: d[`${g}FullYear`](), m: d[`${g}Month`]() + 1, d: d[`${g}Date`](),
    H: d[`${g}Hours`](), M: d[`${g}Minutes`](), S: d[`${g}Seconds`](),
    w: d[`${g}Day`](),
  };
}
function strftime(fmt, date, utc) {
  const p = parts(date, utc);
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const mons = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  return fmt.replace(/%[aAbBcdDeFHImMpRrSTYy%]/g, m => {
    switch (m) {
      case '%%': return '%';
      case '%Y': return String(p.Y);
      case '%y': return pad(p.Y % 100);
      case '%m': return pad(p.m);
      case '%d': return pad(p.d);
      case '%e': return String(p.d).padStart(2, ' ');
      case '%F': return `${p.Y}-${pad(p.m)}-${pad(p.d)}`;
      case '%H': return pad(p.H);
      case '%I': { const h = p.H % 12 || 12; return pad(h); }
      case '%M': return pad(p.M);
      case '%S': return pad(p.S);
      case '%p': return p.H < 12 ? 'AM' : 'PM';
      case '%T': return `${pad(p.H)}:${pad(p.M)}:${pad(p.S)}`;
      case '%R': return `${pad(p.H)}:${pad(p.M)}`;
      case '%D': return `${pad(p.m)}/${pad(p.d)}/${pad(p.Y % 100)}`;
      case '%a': return days[p.w].slice(0, 3);
      case '%A': return days[p.w];
      case '%b': case '%h': return mons[p.m - 1].slice(0, 3);
      case '%B': return mons[p.m - 1];
      case '%c': return date.toString();
      case '%r': { const h = p.H % 12 || 12; return `${pad(h)}:${pad(p.M)}:${pad(p.S)} ${p.H < 12 ? 'AM' : 'PM'}`; }
      default: return m;
    }
  });
}

function timeString(date, opt) {
  const p = parts(date, opt.utc);
  let h = p.H;
  if (opt.twelve) h = h % 12 || 12;
  let s = `${pad(h)}:${pad(p.M)}`;
  if (opt.seconds) s += `:${pad(p.S)}`;
  return s;
}

function glyph(ch, colonOn) {
  if (ch === ':') return [
    [false],
    [colonOn],
    [false],
    [colonOn],
    [false],
  ];
  const seg = DIGITS[ch] || DIGITS['0'];
  const row = (left, mid, right) => [Boolean(left), Boolean(mid), Boolean(right)];
  return [
    row(0, seg[0], 0),
    row(seg[1], 0, seg[3]),
    row(0, seg[2], 0),
    row(seg[4], 0, seg[6]),
    row(0, seg[5], 0),
  ];
}

function drawDigitCells(text, colonOn) {
  const lines = [[], [], [], [], []];
  for (const ch of text) {
    const g = glyph(ch, colonOn);
    for (let i = 0; i < 5; i++) lines[i].push(...g[i], false);
  }
  return lines;
}

function esc(s) { process.stdout.write(s); }
function move(r, c) { return `\x1b[${Math.max(1, r)};${Math.max(1, c)}H`; }

function render(opt, pos) {
  const rows = process.stdout.rows || 24;
  const cols = process.stdout.columns || 80;
  const now = new Date();
  const text = timeString(now, opt);
  const clock = drawDigitCells(text, !opt.blink || now.getSeconds() % 2 === 0);
  const date = opt.hideDate ? '' : strftime(opt.fmt, now, opt.utc);
  const clockWidth = Math.max(...clock.map(l => l.length)) * 2;
  const width = Math.max(clockWidth, date.length) + (opt.box ? 4 : 0);
  const height = clock.length + (date ? 1 : 0) + (opt.box ? 2 : 0);
  let y = opt.center ? Math.floor((rows - height) / 2) + 1 : pos.y;
  let x = opt.center ? Math.floor((cols - width) / 2) + 1 : pos.x;
  y = Math.max(1, Math.min(rows, y));
  x = Math.max(1, Math.min(cols, x));
  const fg = 30 + ((opt.color >= 0 && opt.color <= 7) ? opt.color : 2);
  const bg = 40 + ((opt.color >= 0 && opt.color <= 7) ? opt.color : 2);
  const bold = opt.bold ? '\x1b[1m' : '';
  const rowToAnsi = row => row.map(active => active ? `${bold}\x1b[${bg}m  \x1b[49m\x1b[0m` : '  ').join('');
  let out = '\x1b[H\x1b[2J';
  if (opt.box) {
    const inner = width - 2;
    out += move(y, x) + '+' + '-'.repeat(inner) + '+';
    for (let r = 1; r < height - 1; r++) out += move(y + r, x) + '|' + ' '.repeat(inner) + '|';
    out += move(y + height - 1, x) + '+' + '-'.repeat(inner) + '+';
  }
  const ox = x + (opt.box ? 2 : 0);
  const oy = y + (opt.box ? 1 : 0);
  clock.forEach((row, i) => {
    out += move(oy + i, ox) + rowToAnsi(row);
  });
  if (date) {
    const dx = ox + Math.max(0, Math.floor((clockWidth - date.length) / 2));
    out += move(oy + clock.length + (opt.box ? 0 : 1), dx) + bold + `\x1b[${fg}m` + date + '\x1b[39m\x1b[0m';
  }
  esc(out);
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  if (!process.env.TERM || process.env.TERM === 'unknown') {
    process.stderr.write('Error opening terminal: unknown.\n');
    process.exit(1);
  }
  if (opt.tty) {
    try {
      const fs = require('fs');
      const st = fs.statSync(opt.tty);
      if (!st.isCharacterDevice()) throw new Error('not tty');
    } catch {
      process.stderr.write(`${opt.tty}: No such file or directory\n`);
      process.exit(1);
    }
  }
  const pos = { x: 1, y: 1, dx: 1, dy: 1 };
  const cleanup = () => {
    esc('\x1b[?12l\x1b[?25h\x1b[?1049l\x1b[?1l\x1b>');
  };
  process.on('exit', cleanup);
  process.on('SIGINT', () => process.exit(0));
  process.on('SIGTERM', () => process.exit(0));
  esc('\x1b[?1049h\x1b[?25l\x1b[?1h\x1b=');
  if (process.stdin.isTTY) {
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', b => {
      const s = b.toString().toLowerCase();
      if ((opt.screensaver || s.includes('q')) && !opt.noquit) process.exit(0);
      for (const ch of s) {
        if (ch >= '0' && ch <= '7') opt.color = Number(ch);
        if (ch === 'b') opt.bold = !opt.bold;
        if (ch === 'x') opt.box = !opt.box;
        if (ch === 'c') opt.center = !opt.center;
        if (ch === 'r') opt.rebound = !opt.rebound;
        if (ch === 's') opt.seconds = !opt.seconds;
        if (ch === 't') opt.twelve = !opt.twelve;
        if (!opt.center && ch === 'h') pos.x--;
        if (!opt.center && ch === 'l') pos.x++;
        if (!opt.center && ch === 'k') pos.y--;
        if (!opt.center && ch === 'j') pos.y++;
      }
    });
  }
  const tick = () => {
    if (opt.rebound && !opt.center) {
      const rows = process.stdout.rows || 24, cols = process.stdout.columns || 80;
      pos.x += pos.dx; pos.y += pos.dy;
      if (pos.x <= 1 || pos.x >= cols - 35) pos.dx *= -1;
      if (pos.y <= 1 || pos.y >= rows - 8) pos.dy *= -1;
    }
    render(opt, pos);
  };
  tick();
  const ms = Math.max(10, Math.round(opt.delay * 1000 + opt.nsdelay / 1000000));
  setInterval(tick, ms);
}

main();
