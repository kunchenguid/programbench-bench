#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = 'svd2rust 0.37.1 (e29353d 2026-03-03)';

const OPTS = [
  ['-i <FILE>', 'Input SVD file'],
  ['-o, --output-dir <PATH>', 'Directory to place generated files'],
  ['-c, --config <TOML_FILE>', 'Config TOML file'],
  ['    --settings <YAML_FILE>', 'Target-specific settings YAML file'],
  ['    --edition <YEAR>', 'Rust edition of generated code'],
  ['    --target <ARCH>', 'Target architecture'],
  ['    --atomics', 'Generate atomic register modification API'],
  ['    --atomics-feature <FEATURE>', 'add feature gating for atomic register modification API'],
  ['    --ignore-groups', "Don't add alternateGroup name as prefix to register name"],
  ['    --keep-list', 'Keep lists when generating code of dimElement, instead of trying to generate arrays'],
  ['-g, --generic-mod', 'Push generic mod in separate file'],
  ['    --feature-group', 'Use group_name of peripherals as feature'],
  ['    --feature-peripheral', 'Use independent cfg feature flags for each peripheral'],
  ['-f, --ident-format <ident_format>', 'Specify `-f type:prefix:case:suffix` to change default ident formatting.\n          Allowed values of `type` are ["cluster_accessor", "peripheral_mod", "enum_value_accessor", "enum_name", "cluster", "peripheral_singleton", "field_accessor", "register_mod", "register_accessor", "field_writer", "enum_read_name", "register_spec", "enum_value", "register", "peripheral", "field_reader", "cluster_mod", "interrupt", "peripheral_spec", "enum_write_name", "peripheral_feature"].\n          Allowed cases are `unchanged` (\'\'), `pascal` (\'p\'), `constant` (\'c\') and `snake` (\'s\').\n          '],
  ['    --ident-formats-theme <THEME>', 'A set of `ident_format` settings. `new` or `legacy`'],
  ['    --field-names-for-enums', 'Use field name for enumerations even when enumeratedValues has a name'],
  ['    --max-cluster-size', 'Use array increment for cluster size'],
  ['    --impl-debug', 'implement Debug for readable blocks and registers'],
  ['    --impl-debug-feature <FEATURE>', 'Add feature gating for block and register debug implementation'],
  ['    --impl-defmt <FEATURE>', 'Add automatic defmt implementation for enumerated values'],
  ['-m, --make-mod', 'Create mod.rs instead of lib.rs, without inner attributes'],
  ['    --skip-crate-attributes', 'Do not generate crate attributes'],
  ['-s, --strict', 'Make advanced checks due to parsing SVD'],
  ['    --source-type <source_type>', 'Specify file/stream format'],
  ['    --reexport-core-peripherals', 'For Cortex-M target reexport peripherals from cortex-m crate'],
  ['    --reexport-interrupt', 'Reexport interrupt macro from cortex-m-rt like crates'],
  ['-b, --base-address-shift <base_address_shift>', "Add offset to all base addresses on all peripherals in the SVD file.\n          Useful for soft-cores where the peripheral address range isn't necessarily fixed.\n          Ignore this option if you are not building your own FPGA based soft-cores."],
  ['-l, --log <log_level>', 'Choose which messages to log (overrides RUST_LOG)\n          \n          [possible values: off, error, warn, info, debug, trace]'],
  ['-h, --help', "Print help (see a summary with '-h')"],
  ['-V, --version', 'Print version'],
];

function help() {
  let s = 'Generate a Rust API from SVD files\n\nUsage: executable [OPTIONS]\n\nOptions:\n';
  for (const [flag, desc] of OPTS) {
    s += `  ${flag}\n`;
    for (const line of desc.split('\n')) s += `          ${line}\n`;
    s += '\n';
  }
  return s.replace(/\n$/, '');
}

function die(msg, code = 1) {
  process.stderr.write(msg + '\n');
  process.exit(code);
}

function clapError(msg, usage = 'Usage: executable [OPTIONS]') {
  die(`error: ${msg}\n\n${usage}\n\nFor more information, try '--help'.`, 2);
}

function parseArgs(argv) {
  const cfg = { outputDir: '.', genericMod: false, makeMod: false, skipAttrs: false, baseShift: 0, log: 'info' };
  const takes = new Set(['-i', '-o', '--output-dir', '-c', '--config', '--settings', '--edition', '--target', '--atomics-feature', '-f', '--ident-format', '--ident-formats-theme', '--impl-debug-feature', '--impl-defmt', '--source-type', '-b', '--base-address-shift', '-l', '--log']);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') { console.log(help()); process.exit(0); }
    if (a === '-V' || a === '--version') { console.log(VERSION); process.exit(0); }
    let opt = a, val = null;
    if (a.startsWith('--') && a.includes('=')) [opt, val] = a.split(/=(.*)/s, 2);
    if (takes.has(opt)) {
      if (val === null) {
        if (i + 1 >= argv.length || argv[i + 1].startsWith('-')) clapError(`a value is required for '${opt}${opt === '-i' ? ' <FILE>' : ''}' but none was supplied`);
        val = argv[++i];
      }
      if (opt === '-i') cfg.input = val;
      else if (opt === '-o' || opt === '--output-dir') cfg.outputDir = val;
      else if (opt === '-b' || opt === '--base-address-shift') cfg.baseShift = parseNum(val);
      else if (opt === '-l' || opt === '--log') cfg.log = val;
      continue;
    }
    if (['--atomics', '--ignore-groups', '--keep-list', '-g', '--generic-mod', '--feature-group', '--feature-peripheral', '--field-names-for-enums', '--max-cluster-size', '--impl-debug', '-m', '--make-mod', '--skip-crate-attributes', '-s', '--strict', '--reexport-core-peripherals', '--reexport-interrupt'].includes(a)) {
      if (a === '-g' || a === '--generic-mod') cfg.genericMod = true;
      if (a === '-m' || a === '--make-mod') cfg.makeMod = true;
      if (a === '--skip-crate-attributes') cfg.skipAttrs = true;
      continue;
    }
    if (a.startsWith('-')) clapError(`unexpected argument '${a}' found`);
    cfg.input = a;
  }
  return cfg;
}

function log(level, msg) {
  if (level !== 'off') process.stderr.write(msg + '\n');
}

function parseNum(s) {
  if (s == null || s === '') return 0;
  let t = String(s).replace(/_/g, '');
  if (/^#/.test(t)) t = '0x' + t.slice(1);
  const n = Number(t);
  return Number.isFinite(n) ? n : parseInt(t, 0) || 0;
}

function stripXml(xml) {
  return xml.replace(/<\?xml[\s\S]*?\?>/g, '').replace(/<!--[\s\S]*?-->/g, '');
}

function node(name, text = '', attrs = {}) { return { name, text, attrs, children: [] }; }

function parseXml(xml) {
  xml = stripXml(xml);
  const root = node('#root');
  const stack = [root];
  const re = /<([^>]+)>|([^<]+)/g;
  let m;
  while ((m = re.exec(xml))) {
    if (m[2]) { stack[stack.length - 1].text += decode(m[2]); continue; }
    let tag = m[1].trim();
    if (!tag || tag.startsWith('!')) continue;
    if (tag.startsWith('/')) { if (stack.length > 1) stack.pop(); continue; }
    const self = tag.endsWith('/');
    if (self) tag = tag.slice(0, -1).trim();
    const parts = tag.match(/^([^\s]+)([\s\S]*)$/);
    const n = node(local(parts[1]), '', attrs(parts[2] || ''));
    stack[stack.length - 1].children.push(n);
    if (!self) stack.push(n);
  }
  return root.children.find(c => c.name === 'device') || root.children[0] || null;
}

function attrs(s) {
  const out = {};
  s.replace(/([:\w-]+)\s*=\s*"([^"]*)"/g, (_, k, v) => { out[local(k)] = decode(v); return ''; });
  return out;
}
function local(n) { return n.includes(':') ? n.split(':').pop() : n; }
function decode(s) { return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&apos;/g, "'"); }
function children(n, name) { return (n && n.children || []).filter(c => c.name === name); }
function child(n, name) { return children(n, name)[0] || null; }
function text(n, name, def = '') { const c = child(n, name); return c ? c.text.trim() : def; }

function identRaw(s) { return (s || '').trim().replace(/%s/g, '').replace(/\[[^\]]+\]/g, '').replace(/[^A-Za-z0-9_]/g, '_').replace(/^_+|_+$/g, '') || 'unnamed'; }
function words(s) { return identRaw(s).split(/_+|(?=[A-Z][a-z])/).filter(Boolean); }
function pascal(s) { return words(s).map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('') || 'Unnamed'; }
function snake(s) { return words(s).map(w => w.toLowerCase()).join('_') || 'unnamed'; }
function upper(s) { return snake(s).toUpperCase(); }
function hex(n) {
  let h = Math.max(0, n >>> 0).toString(16);
  if (h.length > 4) h = h.replace(/\B(?=(?:[0-9a-f]{4})+$)/g, '_');
  return '0x' + h;
}
function sizeType(bits) { bits = Number(bits) || 32; if (bits <= 8) return 'u8'; if (bits <= 16) return 'u16'; if (bits <= 32) return 'u32'; return 'u64'; }
function accessShort(a) { a = (a || 'read-write').toLowerCase(); if (a.includes('write') && !a.includes('read')) return 'w'; if (a.includes('read') && !a.includes('write')) return 'r'; return 'rw'; }

function parseDevice(dev) {
  const cpu = child(dev, 'cpu');
  const perRoot = child(dev, 'peripherals');
  const interrupts = [];
  const peripherals = children(perRoot, 'peripheral').map(p => parsePeripheral(p, interrupts));
  return {
    name: text(dev, 'name', 'device'),
    description: text(dev, 'description', ''),
    width: parseNum(text(dev, 'width', '32')),
    nvic: parseNum(text(cpu, 'nvicPrioBits', '0')),
    peripherals,
    interrupts,
  };
}

function parsePeripheral(p, interrupts) {
  for (const it of children(p, 'interrupt')) interrupts.push({ name: text(it, 'name'), value: parseNum(text(it, 'value')), description: text(it, 'description') });
  const regs = [];
  const rr = child(p, 'registers');
  if (rr) for (const c of rr.children) {
    if (c.name === 'register') regs.push(parseRegister(c));
    if (c.name === 'cluster') {
      for (const r of children(c, 'register')) {
        const pr = parseRegister(r);
        pr.name = text(c, 'name') + '_' + pr.name;
        pr.offset += parseNum(text(c, 'addressOffset', '0'));
        regs.push(pr);
      }
    }
  }
  return { name: text(p, 'name'), description: text(p, 'description'), groupName: text(p, 'groupName'), base: parseNum(text(p, 'baseAddress')), registers: regs };
}

function parseRegister(r) {
  const fields = [];
  const fr = child(r, 'fields');
  if (fr) for (const f of children(fr, 'field')) fields.push(parseField(f));
  return { name: text(r, 'name'), displayName: text(r, 'displayName'), description: text(r, 'description'), offset: parseNum(text(r, 'addressOffset')), size: parseNum(text(r, 'size', '32')), access: text(r, 'access', 'read-write'), reset: parseNum(text(r, 'resetValue', '0')), fields };
}

function parseField(f) {
  let off = text(f, 'bitOffset'), wid = text(f, 'bitWidth');
  const range = text(f, 'bitRange');
  if ((!off || !wid) && range) {
    const m = range.match(/\[(\d+):(\d+)\]/);
    if (m) { off = String(Math.min(+m[1], +m[2])); wid = String(Math.abs(+m[1] - +m[2]) + 1); }
  }
  if ((!off || !wid) && text(f, 'lsb')) { off = text(f, 'lsb'); wid = String(parseNum(text(f, 'msb')) - parseNum(off) + 1); }
  const evs = [];
  for (const evc of children(f, 'enumeratedValues')) for (const ev of children(evc, 'enumeratedValue')) evs.push({ name: text(ev, 'name'), value: parseNum(text(ev, 'value', '0')), description: text(ev, 'description') || text(ev, 'name') });
  return { name: text(f, 'name'), description: text(f, 'description'), offset: parseNum(off || '0'), width: parseNum(wid || '1'), access: text(f, 'access'), enums: evs };
}

const GENERIC = `#[allow(unused_imports)] use generic::*;\n#[doc = r"Common register and bit access and modify traits"] pub mod generic {\nuse core::marker;\npub trait PeripheralSpec { type RB; const ADDRESS: usize; const NAME: &'static str; }\npub struct Periph<PER: PeripheralSpec>{ _marker: marker::PhantomData<PER> }\nimpl<PER: PeripheralSpec> Periph<PER>{ pub const PTR:*const PER::RB=PER::ADDRESS as *const _; pub const fn ptr()->*const PER::RB{Self::PTR} pub unsafe fn steal()->Self{Self{_marker:marker::PhantomData}} }\nimpl<PER: PeripheralSpec> core::ops::Deref for Periph<PER>{ type Target=PER::RB; fn deref(&self)->&Self::Target{ unsafe{&*Self::PTR} } }\npub trait RegisterSpec{ type Ux: Copy + Default; }\npub trait Readable: RegisterSpec{} pub trait Writable: RegisterSpec{ type Safety; } pub trait Resettable: RegisterSpec{ const RESET_VALUE: Self::Ux; }\npub struct R<REG:RegisterSpec>{ bits: REG::Ux } impl<REG:RegisterSpec> R<REG>{ pub const fn bits(&self)->REG::Ux{self.bits} }\npub struct W<REG:RegisterSpec>{ pub bits: REG::Ux } impl<REG:Writable> W<REG>{ pub unsafe fn bits(&mut self,bits:REG::Ux)->&mut Self{self.bits=bits; self} }\npub struct Reg<REG:RegisterSpec>{ _marker: marker::PhantomData<REG> } impl<REG:RegisterSpec> Reg<REG>{ pub fn as_ptr(&self)->*mut REG::Ux{core::ptr::null_mut()} }\nimpl<REG:Readable> Reg<REG>{ pub fn read(&self)->R<REG>{R{bits:Default::default()}} }\nimpl<REG:Writable+Resettable> Reg<REG>{ pub fn reset(&self){} pub fn write<F>(&self, mut f:F)->REG::Ux where F:FnMut(&mut W<REG>)->&mut W<REG>{ let mut w=W{bits:REG::RESET_VALUE}; f(&mut w); w.bits } pub fn write_with_zero<F>(&self, mut f:F)->REG::Ux where F:FnMut(&mut W<REG>)->&mut W<REG>{ let mut w=W{bits:Default::default()}; f(&mut w); w.bits } }\nimpl<REG:Readable+Writable> Reg<REG>{ pub fn modify<F>(&self, mut f:F)->REG::Ux where F:FnMut(&R<REG>,&mut W<REG>)->&mut W<REG>{ let r=R{bits:Default::default()}; let mut w=W{bits:Default::default()}; f(&r,&mut w); w.bits } }\npub struct Safe; pub struct Unsafe;\npub struct FieldReader<FI=u8>{ bits:u64, _m: marker::PhantomData<FI> } impl<FI> FieldReader<FI>{ pub const fn new(bits:u64)->Self{Self{bits,_m:marker::PhantomData}} pub const fn bits(&self)->u64{self.bits} }\npub type BitReader<FI=bool> = FieldReader<FI>;\npub struct FieldWriter<'a,REG,const WI:u8,FI=u8,Safety=Unsafe> where REG:Writable+RegisterSpec{ w:&'a mut W<REG>, o:u8, _m:marker::PhantomData<(FI,Safety)> } impl<'a,REG,const WI:u8,FI,Safety> FieldWriter<'a,REG,WI,FI,Safety> where REG:Writable+RegisterSpec{ pub fn new(w:&'a mut W<REG>,o:u8)->Self{Self{w,o,_m:marker::PhantomData}} pub unsafe fn bits(self,_value:u64)->&'a mut W<REG>{self.w} }\npub type BitWriter<'a,REG,FI=bool> = FieldWriter<'a,REG,1,FI>;\n}\n`;

function render(dev, cfg) {
  let s = '';
  if (!cfg.skipAttrs && !cfg.makeMod) s += `#![doc = "Peripheral access API for ${upper(dev.name)} microcontrollers (generated using svd2rust v0.37.1 (e29353d 2026-03-03))"]\n#![allow(non_camel_case_types)]\n#![allow(non_snake_case)]\n#![no_std]\n`;
  s += `#[doc = r"Number available in the NVIC for configuring priority"] pub const NVIC_PRIO_BITS: u8 = ${dev.nvic || 0};\n`;
  if (cfg.genericMod) s += 'pub mod generic;\n#[allow(unused_imports)] use generic::*;\n'; else s += GENERIC;
  s += renderInterrupts(dev.interrupts);
  for (const p of dev.peripherals) s += renderPeripheral(p, cfg);
  s += renderPeripherals(dev.peripherals);
  return s;
}

function renderInterrupts(ints) {
  let s = '#[doc = r"Enumeration of all the interrupts."]\n#[derive(Copy, Clone, Debug, PartialEq, Eq)]\npub enum Interrupt {\n';
  for (const it of ints) s += `    #[doc = "${esc(it.description || it.name)}"]\n    ${pascal(it.name)} = ${it.value},\n`;
  s += '}\n';
  return s;
}

function renderPeripheral(p, cfg) {
  const typeName = pascal(p.name), spec = `${typeName}Spec`, mod = snake(p.name);
  let s = `#[doc = "${esc(p.description || p.name)}"] pub type ${typeName} = crate::generic::Periph<${spec}>;\n`;
  s += `pub struct ${spec}; impl crate::generic::PeripheralSpec for ${spec} { type RB = ${mod}::RegisterBlock; const ADDRESS: usize = ${hex((p.base + cfg.baseShift) >>> 0)}; const NAME: &'static str = "${typeName}"; }\n`;
  s += `#[doc = "${esc(p.description || p.name)}"] pub mod ${mod} {\n`;
  s += '#[repr(C)]\n#[doc = "Register block"]\npub struct RegisterBlock {\n';
  let last = 0, res = 0;
  for (const r of p.registers.sort((a,b)=>a.offset-b.offset)) {
    if (r.offset > last) { s += `    _reserved${res}: [u8; ${r.offset - last}],\n`; res++; }
    s += `    ${snake(r.name)}: ${pascal(r.name)},\n`;
    last = r.offset + Math.max(1, r.size / 8);
  }
  s += '}\nimpl RegisterBlock {\n';
  for (const r of p.registers) s += `    #[doc = "${hex(r.offset)} - ${esc(r.description)}"] pub const fn ${snake(r.name)}(&self) -> &${pascal(r.name)} { &self.${snake(r.name)} }\n`;
  s += '}\n';
  for (const r of p.registers) s += renderRegister(r);
  s += '}\n';
  return s;
}

function renderRegister(r) {
  const Rn = pascal(r.name), mod = snake(r.name), spec = `${Rn}Spec`, ux = sizeType(r.size), acc = accessShort(r.access), desc = r.description || '';
  let s = `#[doc = "${esc(r.name)} (${acc}) register accessor: ${esc(desc)}"]\n#[doc(alias = "${esc(r.name)}")] pub type ${Rn} = crate::generic::Reg<${mod}::${spec}>;\n`;
  s += `#[doc = "${esc(desc)}"] pub mod ${mod} {\n`;
  if (acc.includes('r')) s += `pub type R = crate::generic::R<${spec}>;\n`;
  if (acc.includes('w')) s += `pub type W = crate::generic::W<${spec}>;\n`;
  for (const f of r.fields) s += renderFieldTypes(f);
  if (acc.includes('r')) {
    s += 'impl R {\n';
    for (const f of r.fields) s += renderFieldReader(f);
    s += '}\n';
  }
  if (acc.includes('w')) {
    s += 'impl W {\n';
    for (const f of r.fields) s += renderFieldWriter(f, spec);
    s += '}\n';
  }
  s += `#[doc = "${esc(desc)}"] pub struct ${spec}; impl crate::generic::RegisterSpec for ${spec} { type Ux = ${ux}; }\n`;
  if (acc.includes('r')) s += `impl crate::generic::Readable for ${spec} {}\n`;
  if (acc.includes('w')) s += `impl crate::generic::Writable for ${spec} { type Safety = crate::generic::Unsafe; }\n`;
  if (acc.includes('w')) s += `impl crate::generic::Resettable for ${spec} { const RESET_VALUE: ${ux} = ${hex(r.reset)}; }\n`;
  s += '}\n';
  return s;
}

function renderFieldTypes(f) {
  const n = pascal(f.name), desc = esc(f.description || '');
  let s = '';
  if (f.enums.length) {
    s += `#[derive(Clone, Copy, Debug, PartialEq, Eq)]\n#[repr(u8)] pub enum ${n} {\n`;
    for (const ev of f.enums) s += `    #[doc = "${esc(ev.description || ev.name)}"] ${pascal(ev.name)} = ${ev.value},\n`;
    s += `}\nimpl From<${n}> for u8 { fn from(v:${n})->Self{v as _} }\n`;
    s += `#[doc = "Field \`${esc(f.name)}\` reader - ${desc}"] pub type ${n}R = crate::generic::FieldReader<${n}>;\n`;
    s += `#[doc = "Field \`${esc(f.name)}\` writer - ${desc}"] pub type ${n}W<'a, REG> = crate::generic::FieldWriter<'a, REG, ${f.width}, ${n}> where REG: crate::generic::Writable + crate::generic::RegisterSpec;\n`;
  } else if (f.width === 1) {
    s += `#[doc = "Field \`${esc(f.name)}\` reader - ${desc}"] pub type ${n}R = crate::generic::BitReader;\n`;
    s += `#[doc = "Field \`${esc(f.name)}\` writer - ${desc}"] pub type ${n}W<'a, REG> = crate::generic::BitWriter<'a, REG> where REG: crate::generic::Writable + crate::generic::RegisterSpec;\n`;
  } else {
    s += `#[doc = "Field \`${esc(f.name)}\` reader - ${desc}"] pub type ${n}R = crate::generic::FieldReader;\n`;
    s += `#[doc = "Field \`${esc(f.name)}\` writer - ${desc}"] pub type ${n}W<'a, REG> = crate::generic::FieldWriter<'a, REG, ${f.width}> where REG: crate::generic::Writable + crate::generic::RegisterSpec;\n`;
  }
  return s;
}
function renderFieldReader(f) {
  const n = pascal(f.name), m = snake(f.name), mask = f.width >= 64 ? 'u64::MAX' : String((1n << BigInt(f.width)) - 1n);
  if (f.width === 1) return `    #[doc = "Bit ${f.offset} - ${esc(f.description)}"] pub fn ${m}(&self) -> ${n}R { ${n}R::new(((self.bits() as u64 >> ${f.offset}) & 1) != 0 as u64) }\n`.replace('& 1) != 0 as u64', '& 1');
  return `    #[doc = "Bits ${f.offset}:${f.offset + f.width - 1} - ${esc(f.description)}"] pub fn ${m}(&self) -> ${n}R { ${n}R::new(((self.bits() as u64 >> ${f.offset}) & ${mask}) as u64) }\n`;
}
function renderFieldWriter(f, spec) {
  return `    #[doc = "Bits ${f.offset}:${f.offset + f.width - 1} - ${esc(f.description)}"] pub fn ${snake(f.name)}(&mut self) -> ${pascal(f.name)}W<'_, ${spec}> { ${pascal(f.name)}W::new(self, ${f.offset}) }\n`;
}

function renderPeripherals(peripherals) {
  let s = '#[doc = r"All the peripherals."]\n#[allow(non_snake_case)] pub struct Peripherals {\n';
  for (const p of peripherals) s += `    #[doc = "${esc(p.name)}"] pub ${snake(p.name)}: ${pascal(p.name)},\n`;
  s += '}\nimpl Peripherals { pub unsafe fn steal() -> Self { Self {\n';
  for (const p of peripherals) s += `    ${snake(p.name)}: ${pascal(p.name)}::steal(),\n`;
  s += '} } }\n';
  return s;
}

function esc(s) { return String(s || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n'); }

function main() {
  const cfg = parseArgs(process.argv.slice(2));
  log(cfg.log, '[INFO  svd2rust] Parsing device from SVD file');
  let xml = '';
  try { xml = cfg.input ? fs.readFileSync(cfg.input, 'utf8') : fs.readFileSync(0, 'utf8'); }
  catch (e) { die(`[ERROR svd2rust] Cannot open the SVD file\n    \n    Caused by:\n        ${e.message}`, 1); }
  const root = parseXml(xml);
  if (!root) die('[ERROR svd2rust] Error parsing SVD XML file\n    \n    Caused by:\n        the document does not have a root node', 1);
  let dev;
  try { dev = parseDevice(root); } catch (e) { die(`[ERROR svd2rust] Error parsing SVD XML file\n    \n    Caused by:\n        ${e.message}`, 1); }
  log(cfg.log, '[INFO  svd2rust] Rendering device');
  for (const p of dev.peripherals) for (const r of p.registers) if (!r.description) log(cfg.log, `[WARN  svd2rust::generate::register] Missing description for register ${r.name}`);
  const out = cfg.outputDir || '.';
  const mainName = cfg.makeMod ? 'mod.rs' : 'lib.rs';
  fs.writeFileSync(path.join(out, mainName), render(dev, cfg));
  if (cfg.genericMod) fs.writeFileSync(path.join(out, 'generic.rs'), GENERIC.replace(/^#\[allow[\s\S]*?pub mod generic \{\n/, '').replace(/\n}\n$/, '\n'));
  fs.writeFileSync(path.join(out, 'build.rs'), '#![doc = r"Builder file for Peripheral access crate generated by svd2rust tool"]\nfn main() { println!("cargo:rerun-if-changed=build.rs"); }\n');
  fs.writeFileSync(path.join(out, 'device.x'), renderDeviceX(dev.interrupts));
}

function renderDeviceX(ints) {
  let s = '/* Linker script generated by svd2rust */\n';
  for (const it of ints.sort((a,b)=>a.value-b.value)) s += `PROVIDE(${pascal(it.name)} = DefaultHandler);\n`;
  return s;
}

main();
