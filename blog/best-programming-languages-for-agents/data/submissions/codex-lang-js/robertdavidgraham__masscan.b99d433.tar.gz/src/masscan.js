#!/usr/bin/env node
"use strict";

const fs = require("fs");

const VERSION = `
Masscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )
Compiled on: Apr 17 2026 19:59:25
Compiler: gcc 11.4.0
OS: Linux
CPU: x86 (64 bits)
GIT version: unknown`;

const SHORT_HELP = `usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]

examples:
    masscan -p80,8000-8100 10.0.0.0/8 --rate=10000
        scan some web ports on 10.x.x.x at 10kpps

    masscan --nmap
        list those options that are compatible with nmap

    masscan -p80 10.0.0.0/8 --banners -oB <filename>
        save results of scan in binary format to <filename>

    masscan --open --banners --readscan <filename> -oX <savefile>
        read binary scan results in <filename> and save them as xml in <savefile>`;

const LONG_HELP = `usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]
MASSCAN is a fast port scanner. The primary input parameters are the
IP addresses/ranges you want to scan, and the port numbers. An example
is the following, which scans the 10.x.x.x network for web servers:

    masscan 10.0.0.0/8 -p80

The program auto-detects network interface/adapter settings. If this
fails, you'll have to set these manually. The following is an
example of all the parameters that are needed:

    --adapter-ip 192.168.10.123
    --adapter-mac 00-11-22-33-44-55
    --router-mac 66-55-44-33-22-11

Parameters can be set either via the command-line or config-file. The
names are the same for both. Thus, the above adapter settings would
appear as follows in a configuration file:

    adapter-ip = 192.168.10.123
    adapter-mac = 00-11-22-33-44-55
    router-mac = 66-55-44-33-22-11

All single-dash parameters have a spelled out double-dash equivalent,
so '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).
To use the config file, type:

    masscan -c <filename>

To generate a config-file from the current settings, use the --echo
option. This stops the program from actually running, and just echoes
the current configuration instead. This is a useful way to generate
your first config file, or see a list of parameters you didn't know
about. I suggest you try it now:

    masscan -p1234 --echo`;

const NMAP_HELP = `Masscan (https://github.com/robertdavidgraham/masscan)
Usage: masscan [Options] -p{Target-Ports} {Target-IP-Ranges}
TARGET SPECIFICATION:
  Can pass only IPv4/IPv6 address, CIDR networks, or ranges (non-nmap style)
  Ex: 10.0.0.0/8, 192.168.0.1, 10.0.0.1-10.0.0.254
  -iL <inputfilename>: Input from list of hosts/networks
  --exclude <host1[,host2][,host3],...>: Exclude hosts/networks
  --excludefile <exclude_file>: Exclude list from file
  --randomize-hosts: Randomize order of hosts (default)
HOST DISCOVERY:
  -Pn: Treat all hosts as online (default)
  -n: Never do DNS resolution (default)
SCAN TECHNIQUES:
  -sS: TCP SYN (always on, default)
SERVICE/VERSION DETECTION:
  --banners: get the banners of the listening service if available. The
    default timeout for waiting to receive data is 30 seconds.
PORT SPECIFICATION AND SCAN ORDER:
  -p <port ranges>: Only scan specified ports
    Ex: -p22; -p1-65535; -p 111,137,80,139,8080
TIMING AND PERFORMANCE:
  --max-rate <number>: Send packets no faster than <number> per second
  --connection-timeout <number>: time in seconds a TCP connection will
    timeout while waiting for banner data from a port.
FIREWALL/IDS EVASION AND SPOOFING:
  -S/--source-ip <IP_Address>: Spoof source address
  -e <iface>: Use specified interface
  -g/--source-port <portnum>: Use given port number
  --ttl <val>: Set IP time-to-live field
  --spoof-mac <mac address/prefix/vendor name>: Spoof your MAC address
OUTPUT:
  --output-format <format>: Sets output to binary/list/unicornscan/json/ndjson/grepable/xml
  --output-file <file>: Write scan results to file. If --output-format is
     not given default is xml
  -oL/-oJ/-oD/-oG/-oB/-oX/-oU <file>: Output scan in List/JSON/nDjson/Grepable/Binary/XML/Unicornscan format,
     respectively, to the given filename. Shortcut for
     --output-format <format> --output-file <file>
  -v: Increase verbosity level (use -vv or more for greater effect)
  -d: Increase debugging level (use -dd or more for greater effect)
  --open: Only show open (or possibly open) ports
  --packet-trace: Show all packets sent and received
  --iflist: Print host interfaces and routes (for debugging)
  --append-output: Append to rather than clobber specified output files
  --resume <filename>: Resume an aborted scan
MISC:
  --send-eth: Send using raw ethernet frames (default)
  -V: Print version number
  -h: Print this help summary page.
EXAMPLES:
  masscan -v -sS 192.168.0.0/16 10.0.0.0/8 -p 80
  masscan 23.0.0.0/0 -p80 --banners -output-format binary --output-filename internet.scan
  masscan --open --banners --readscan internet.scan -oG internet_scan.grepable
SEE (https://github.com/robertdavidgraham/masscan) FOR MORE HELP`;

function defaultCfg() {
  return {
    seed: randomSeed(),
    rate: "100",
    shard: "1/1",
    ports: "",
    ranges: [],
    excludes: [],
    excludefiles: [],
    includefiles: [],
    outputFilename: "",
    outputFormat: "",
    outputAppend: false,
    banners: false,
    adapter: "",
    adapterIp: "",
    adapterPort: "",
    adapterMac: "",
    routerMac: "",
    echo: false,
    readscan: "",
    wait: "",
    ping: false,
    iflist: false,
    regress: false,
    selftest: false,
    open: false,
  };
}

function randomSeed() {
  const hi = BigInt(Math.floor(Math.random() * 0xffffffff));
  const lo = BigInt(Math.floor(Math.random() * 0xffffffff));
  return String((hi << 32n) | lo);
}

function pcapFail() {
  console.error("[-] FAIL: failed to load libpcap shared library");
  console.error("    [hint]: you must install libpcap or WinPcap");
}

function needArg(args, i, opt) {
  if (i + 1 >= args.length) {
    console.error(`FAIL: ${opt}: expected parameter`);
    process.exit(1);
  }
  return args[i + 1];
}

function normalizeMac(s) {
  return s.replace(/:/g, "-").toLowerCase();
}

function isTarget(s) {
  if (s.includes(":")) return /^[0-9a-fA-F:.\/-]+$/.test(s);
  return /^(\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?$/.test(s) ||
         /^(\d{1,3}\.){3}\d{1,3}-(\d{1,3}\.){3}\d{1,3}$/.test(s) ||
         /^(\d{1,3}\.){3}\d{1,3}-\d{1,3}$/.test(s);
}

function validatePorts(portSpec) {
  if (!portSpec) return true;
  const items = portSpec.split(",");
  for (const raw of items) {
    let x = raw;
    if (/^[TUSOI]:/i.test(x)) x = x.slice(2);
    if (x === "") continue;
    for (const n of x.split("-")) {
      if (n === "") continue;
      const v = Number(n);
      if (!Number.isInteger(v) || v < 0 || v > 65535) {
        console.error(`[-] FAIL: bad target port: ${n}`);
        console.error("    Hint: a port is a number [0..65535]");
        process.exit(1);
      }
    }
  }
}

function canonicalPorts(spec) {
  if (!spec) return "";
  const out = [];
  for (const item of spec.split(",")) {
    if (/^T:/i.test(item)) out.push(item.slice(2));
    else if (/^U:/i.test(item)) out.push("U:" + item.slice(2));
    else if (/^S:/i.test(item)) out.push("S:" + item.slice(2));
    else if (/^O:/i.test(item)) out.push("O:" + item.slice(2));
    else if (/^I:/i.test(item)) out.push("I:" + item.slice(2));
    else out.push(item);
  }
  return out.filter(Boolean).join(",");
}

function setKey(cfg, key, val) {
  const k = key.replace(/^--?/, "").toLowerCase();
  switch (k) {
    case "p":
    case "ports":
      cfg.ports = canonicalPorts(val);
      validatePorts(cfg.ports);
      break;
    case "range":
    case "ranges":
      cfg.ranges.push(...String(val).split(",").filter(Boolean));
      break;
    case "rate":
    case "max-rate":
      cfg.rate = String(val);
      break;
    case "seed":
      cfg.seed = String(val);
      break;
    case "shard":
    case "shards":
      cfg.shard = String(val);
      break;
    case "banners":
      cfg.banners = truthy(val);
      break;
    case "adapter":
    case "interface":
    case "e":
      cfg.adapter = String(val);
      break;
    case "adapter-ip":
    case "source-ip":
    case "s":
      cfg.adapterIp = String(val);
      break;
    case "adapter-port":
    case "source-port":
    case "g":
      cfg.adapterPort = String(val);
      break;
    case "adapter-mac":
    case "spoof-mac":
      cfg.adapterMac = normalizeMac(String(val));
      break;
    case "router-mac":
    case "router-mac-ipv4":
      cfg.routerMac = normalizeMac(String(val));
      break;
    case "output-filename":
    case "output-file":
      cfg.outputFilename = String(val);
      if (!cfg.outputFormat) cfg.outputFormat = "xml";
      break;
    case "output-format":
      cfg.outputFormat = String(val).toLowerCase();
      break;
    case "output-append":
    case "append-output":
      cfg.outputAppend = truthy(val);
      break;
    case "exclude":
      cfg.excludes.push(...String(val).split(",").filter(Boolean));
      break;
    case "excludefile":
    case "exclude-file":
      cfg.excludefiles.push(String(val));
      break;
    case "includefile":
    case "include-file":
    case "il":
      cfg.includefiles.push(String(val));
      break;
    case "wait":
      cfg.wait = String(val);
      break;
    case "ping":
      cfg.ping = truthy(val);
      if (!cfg.ports.includes("I:0")) cfg.ports = cfg.ports ? cfg.ports + ",I:0" : "I:0";
      break;
    case "open":
      cfg.open = truthy(val);
      break;
    default:
      break;
  }
}

function truthy(v) {
  if (v === undefined || v === null || v === "") return true;
  return !/^(false|no|0)$/i.test(String(v));
}

function readConfig(cfg, file) {
  let text;
  try {
    text = fs.readFileSync(file, "utf8");
  } catch (e) {
    console.error(`[-] ${file}: ${e.code === "ENOENT" ? "No such file or directory" : e.message}`);
    process.exit(1);
  }
  for (const line0 of text.split(/\r?\n/)) {
    let line = line0.replace(/#.*/, "").trim();
    if (!line) continue;
    let m = line.match(/^([^=\s]+)\s*=\s*(.*)$/);
    if (m) setKey(cfg, m[1], m[2].trim());
  }
}

function parse(args) {
  const cfg = defaultCfg();
  for (let i = 0; i < args.length; i++) {
    let a = args[i];
    if (a.startsWith("--") && a.includes("=")) {
      const idx = a.indexOf("=");
      args.splice(i, 1, a.slice(0, idx), a.slice(idx + 1));
      a = args[i];
    }
    if (a === "--help") {
      console.log(LONG_HELP);
      process.exit(1);
    } else if (a === "-h") {
      console.log(SHORT_HELP);
      process.exit(1);
    } else if (a === "--nmap") {
      console.log(NMAP_HELP + "\n");
      process.exit(1);
    } else if (a === "--version" || a === "-V") {
      console.log(VERSION);
      process.exit(1);
    } else if (a === "--echo") {
      cfg.echo = true;
    } else if (a === "--iflist") {
      cfg.iflist = true;
    } else if (a === "--selftest" || a === "--regress") {
      cfg.regress = true;
    } else if (a === "-p" || a === "--ports") {
      setKey(cfg, "ports", needArg(args, i, a)); i++;
    } else if (a.startsWith("-p") && a.length > 2) {
      setKey(cfg, "ports", a.slice(2));
    } else if (a === "-c" || a === "--conf" || a === "--config") {
      readConfig(cfg, needArg(args, i, a)); i++;
    } else if (a === "-iL" || a === "--include-file") {
      setKey(cfg, "include-file", needArg(args, i, a)); i++;
    } else if (a === "--exclude" || a === "--excludefile" || a === "--exclude-file" ||
               a === "--rate" || a === "--max-rate" || a === "--seed" ||
               a === "--shard" || a === "--shards" || a === "--adapter-ip" ||
               a === "--source-ip" || a === "-S" || a === "--adapter-port" ||
               a === "--source-port" || a === "-g" || a === "--adapter-mac" ||
               a === "--router-mac" || a === "--spoof-mac" || a === "--interface" ||
               a === "-e" || a === "--output-format" || a === "--output-filename" ||
               a === "--output-file" || a === "--wait" || a === "--connection-timeout" ||
               a === "--ttl" || a === "--resume" || a === "--readscan") {
      const v = needArg(args, i, a); i++;
      if (a === "--readscan") cfg.readscan = v;
      else setKey(cfg, a, v);
    } else if (/^-o[XLJGBDU]$/.test(a)) {
      const map = { X: "xml", L: "list", J: "json", G: "grepable", B: "binary", D: "ndjson", U: "unicornscan" };
      cfg.outputFormat = map[a[2]];
      cfg.outputFilename = needArg(args, i, a); i++;
    } else if (a === "--banners" || a === "--append-output" || a === "--open" ||
               a === "--ping" || a === "-Pn" || a === "-n" || a === "-sS" ||
               a === "--send-eth" || a === "--randomize-hosts" || a === "--packet-trace" ||
               /^-[vd]+$/.test(a)) {
      setKey(cfg, a, true);
    } else if (a.startsWith("-")) {
      if (/^-[A-Za-z]$/.test(a)) {
      console.error(`FAIL: unknown option: --${a.slice(1)}`);
      } else {
        console.error(`FAIL: unknown option: ${a}`);
      }
      console.error(' [hint] try "--help"');
      console.error(' [hint] ...or, to list nmap-compatible options, try "--nmap"');
      process.exit(1);
    } else if (isTarget(a)) {
      cfg.ranges.push(a);
    } else {
      console.error(`FAIL: unknown command-line parameter "${a}"`);
      console.error(` [hint] did you want "--${a}"?`);
      process.exit(1);
    }
  }
  return cfg;
}

function checkFiles(cfg) {
  for (const f of cfg.excludefiles) {
    if (!fs.existsSync(f)) {
      console.error("[-] FAIL: parsing IP addresses");
      console.error(`[-] ${f}: No such file or directory`);
      process.exit(1);
    }
  }
  for (const f of cfg.includefiles) {
    if (!fs.existsSync(f)) {
      console.error(`[-] ${f}: No such file or directory`);
      process.exit(1);
    }
    const text = fs.readFileSync(f, "utf8");
    for (const line of text.split(/\r?\n/)) {
      const t = line.replace(/#.*/, "").trim();
      if (t) cfg.ranges.push(t);
    }
  }
}

function echoCfg(cfg) {
  pcapFail();
  console.log(`seed = ${cfg.seed}`);
  const n = Number(cfg.rate);
  const r = Number.isFinite(n) ? String(Math.trunc(n)) : cfg.rate;
  console.log(`rate = ${r}${" ".repeat(Math.max(1, 10 - r.length))}`);
  console.log(`shard = ${cfg.shard}`);
  if (cfg.banners) console.log("banners = true");
  console.log("nocapture = servername");
  console.log("nocapture = servername");
  console.log("");
  const hasOutput = cfg.outputFilename || cfg.outputFormat || cfg.outputAppend;
  if (hasOutput) {
    if (cfg.outputFilename) console.log(`output-filename = ${cfg.outputFilename}`);
    if (cfg.outputFormat) console.log(`output-format = ${cfg.outputFormat}`);
    if (cfg.outputAppend) console.log("output-append = true");
    console.log("");
  } else {
    console.log("");
  }
  if (cfg.adapter) console.log(`adapter = ${cfg.adapter}`);
  if (cfg.adapterIp) console.log(`adapter-ip = ${cfg.adapterIp}`);
  if (cfg.adapterPort) console.log(`adapter-port = ${cfg.adapterPort}`);
  if (cfg.adapterMac) console.log(`adapter-mac = ${cfg.adapterMac}`);
  if (cfg.routerMac) {
    console.log(`router-mac-ipv4 = ${cfg.routerMac}`);
    console.log(`router-mac-ipv6 = ${cfg.routerMac}`);
  }
  console.log("# TARGET SELECTION (IP, PORTS, EXCLUDES)");
  console.log(`ports = ${cfg.ports}`);
  for (const rge of cfg.ranges) console.log(`range = ${rge}`);
  for (const ex of cfg.excludes) console.log(`exclude = ${ex}`);
  for (const f of cfg.excludefiles) console.log(`excludefile = ${f}`);
}

function createOutput(cfg) {
  if (cfg.outputFilename) {
    fs.writeFileSync(cfg.outputFilename, "");
  }
}

function readscan(cfg) {
  pcapFail();
  if (!cfg.readscan) {
    console.error("[-] FAIL: --readscan");
    return;
  }
  if (!fs.existsSync(cfg.readscan)) {
    console.error("[-] FAIL: --readscan");
    console.error(`[-] ${cfg.readscan}: No such file or directory`);
    return;
  }
  console.error(`[+] --readscan ${cfg.readscan}`);
  createOutput(cfg);
  const buf = fs.readFileSync(cfg.readscan);
  if (buf.length === 0) {
    console.error(`[-] ${cfg.readscan}: Success`);
    return;
  }
  const hdr = buf.slice(0, 12).toString("latin1");
  if (!hdr.startsWith("masscan/1.1")) {
    console.error(`[-] ${cfg.readscan}: unknown file format (expeced "masscan/1.1")`);
  }
}

function main() {
  const args = process.argv.slice(2);
  const cfg = parse(args);
  checkFiles(cfg);
  if (cfg.regress) {
    pcapFail();
    console.log("regression test: success!");
    process.exit(0);
  }
  if (cfg.iflist) {
    pcapFail();
    console.log("libpcap not loaded");
    process.exit(0);
  }
  if (cfg.echo) {
    echoCfg(cfg);
    process.exit(0);
  }
  if (cfg.readscan !== "") {
    readscan(cfg);
    process.exit(0);
  }
  pcapFail();
  if (args.length === 0 || cfg.ports === "" || cfg.ranges.length === 0) {
    console.log(SHORT_HELP);
    process.exit(1);
  }
  createOutput(cfg);
  console.error("[-] FAIL: could not determine default interface");
  console.error('    [hint] try "--interface ethX"');
  process.exit(1);
}

main();
