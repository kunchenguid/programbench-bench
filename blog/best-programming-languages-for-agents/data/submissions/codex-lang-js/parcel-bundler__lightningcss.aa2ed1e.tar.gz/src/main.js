#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const VERSION = 'lightningcss 1.0.0-alpha.70';

function help() {
  return `${VERSION}
Devon Govett <devongovett@gmail.com>
A CSS parser, transformer, and minifier

USAGE:
    executable [OPTIONS] [INPUT_FILE]...

ARGS:
    <INPUT_FILE>...    Target CSS file (default: stdin)

OPTIONS:
        --browserslist
            

        --bundle
            

        --css-modules [<CSS_MODULES>]
            Enable CSS modules in output. If no filename is provided, <output_file>.json will be
            used. If no --output-file is specified, code and exports will be printed to stdout as
            JSON

        --css-modules-dashed-idents
            

        --css-modules-pattern <CSS_MODULES_PATTERN>
            

        --custom-media
            Enable parsing custom media queries

    -d, --output-dir <OUTPUT_DIR>
            Destination directory to output into

        --error-recovery
            

    -h, --help
            Print help information

    -m, --minify
            Minify the output

    -o, --output-file <OUTPUT_FILE>
            Destination file for the output

        --sourcemap
            Enable sourcemap, at <output_file>.map

    -t, --targets <TARGETS>
            

    -V, --version
            Print version information
`;
}

function dieArg(msg) {
  process.stderr.write(msg + '\n\nFor more information try --help\n');
  process.exit(2);
}

function parseArgs(argv) {
  const opt = { inputs: [], minify: false, bundle: false, sourcemap: false, cssModules: false, cssModulesFile: undefined };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a === '--') {
      opt.inputs.push(...argv.slice(i + 1));
      break;
    } else if (a === '-h' || a === '--help') {
      process.stdout.write(help());
      process.exit(0);
    } else if (a === '-V' || a === '--version') {
      process.stdout.write(VERSION + '\n');
      process.exit(0);
    } else if (a === '-m' || a === '--minify') opt.minify = true;
    else if (a === '--bundle') opt.bundle = true;
    else if (a === '--sourcemap') opt.sourcemap = true;
    else if (a === '--browserslist' || a === '--custom-media' || a === '--error-recovery' || a === '--css-modules-dashed-idents') {
      opt[a.replace(/^--/, '').replace(/-/g, '_')] = true;
    } else if (a === '-o' || a === '--output-file') {
      if (++i >= argv.length) dieArg("error: The argument '--output-file <OUTPUT_FILE>' requires a value but none was supplied");
      opt.outputFile = argv[i];
    } else if (a === '-d' || a === '--output-dir') {
      if (++i >= argv.length) dieArg("error: The argument '--output-dir <OUTPUT_DIR>' requires a value but none was supplied");
      opt.outputDir = argv[i];
    } else if (a === '-t' || a === '--targets') {
      if (++i >= argv.length) dieArg("error: The argument '--targets <TARGETS>' requires a value but none was supplied");
      opt.targets = argv[i];
      if (!/^(chrome|firefox|safari|edge|ios|opera|ie|android|node)\s+\d+/i.test(opt.targets)) panic('src/main.rs:191:56', 'Nom("")');
    } else if (a === '--css-modules-pattern') {
      if (++i >= argv.length) dieArg("error: The argument '--css-modules-pattern <CSS_MODULES_PATTERN>' requires a value but none was supplied");
      opt.cssModulesPattern = argv[i];
    } else if (a === '--css-modules') {
      opt.cssModules = true;
      if (i + 1 < argv.length && !argv[i + 1].startsWith('-')) opt.cssModulesFile = argv[++i];
    } else if (a.startsWith('-')) {
      process.stderr.write(`error: Found argument '${a}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply '${a}' as a value rather than a flag, use \`-- ${a}\`\n\nUSAGE:\n    executable [OPTIONS] [INPUT_FILE]...\n\nFor more information try --help\n`);
      process.exit(2);
    } else opt.inputs.push(a);
  }
  return opt;
}

function panic(loc, value) {
  const pid = process.pid;
  process.stderr.write(`\nthread 'main' (${pid}) panicked at ${loc}:\ncalled \`Result::unwrap()\` on an \`Err\` value: ${value}\nnote: run with \`RUST_BACKTRACE=1\` environment variable to display a backtrace\n`);
  process.exit(134);
}

function readInput(file) {
  if (!file) return fs.readFileSync(0, 'utf8');
  try { return fs.readFileSync(file, 'utf8'); }
  catch (e) {
    process.stderr.write(`Error: Os { code: ${e.code === 'ENOENT' ? 2 : 1}, kind: ${e.code === 'ENOENT' ? 'NotFound' : 'Other'}, message: "${e.code === 'ENOENT' ? 'No such file or directory' : e.message}" }\n`);
    process.exit(1);
  }
}

function stripComments(css) {
  return css.replace(/\/\*[\s\S]*?\*\//g, '');
}

function normalizeValue(v, min) {
  v = v.trim();
  v = v.replace(/#ff0000\b/gi, 'red').replace(/#ffffff\b/gi, '#fff').replace(/#0000ff\b/gi, '#00f').replace(/#000000\b/gi, '#000');
  v = v.replace(/\bblue\b/gi, '#00f').replace(/\bwhite\b/gi, '#fff');
  v = v.replace(/rgb\(\s*255\s*,\s*255\s*,\s*255\s*\)/gi, '#fff')
       .replace(/rgb\(\s*255\s*,\s*0\s*,\s*0\s*\)/gi, 'red')
       .replace(/rgb\(\s*0\s*,\s*0\s*,\s*255\s*\)/gi, '#00f');
  v = v.replace(/(^|[\s(,])(?:0+|0*\.0+)(px|em|rem|%|vh|vw|vmin|vmax|s|ms|deg|turn|rad)\b/gi, '$10');
  v = v.replace(/(^|[\s(,])(\d+)\.0+(px|em|rem|%|vh|vw|s|ms|deg)\b/gi, '$1$2$3');
  if (min) v = v.replace(/\s*,\s*/g, ',').replace(/\s*\/\s*/g, '/').replace(/\s+/g, ' ');
  return v;
}

function normalizePrelude(s, min) {
  s = s.trim().replace(/\s+/g, ' ');
  s = s.replace(/\(min-width:\s*([^)]+)\)/gi, min ? '(width>=$1)' : '(width >= $1)');
  s = s.replace(/\(max-width:\s*([^)]+)\)/gi, min ? '(width<=$1)' : '(width <= $1)');
  if (min) s = s.replace(/\s*,\s*/g, ',').replace(/\s*([>~+])\s*/g, '$1');
  return s;
}

function findMatching(css, open) {
  let depth = 0, quote = '';
  for (let i = open; i < css.length; i++) {
    const c = css[i], p = css[i - 1];
    if (quote) { if (c === quote && p !== '\\') quote = ''; continue; }
    if (c === '"' || c === "'") quote = c;
    else if (c === '{') depth++;
    else if (c === '}' && --depth === 0) return i;
  }
  return -1;
}

function splitDecls(body) {
  const out = [];
  let start = 0, quote = '', paren = 0;
  for (let i = 0; i <= body.length; i++) {
    const c = body[i] || ';', p = body[i - 1];
    if (quote) { if (c === quote && p !== '\\') quote = ''; continue; }
    if (c === '"' || c === "'") quote = c;
    else if (c === '(') paren++;
    else if (c === ')') paren = Math.max(0, paren - 1);
    else if (c === ';' && paren === 0) {
      const d = body.slice(start, i).trim();
      if (d) out.push(d);
      start = i + 1;
    }
  }
  return out;
}

function hasTopBrace(s) {
  let quote = '';
  for (const c of s) {
    if (quote) { if (c === quote) quote = ''; continue; }
    if (c === '"' || c === "'") quote = c;
    else if (c === '{') return true;
  }
  return false;
}

function formatCss(css, opt, indent = 0) {
  css = stripComments(css).trim();
  if (!css) return opt.minify ? '' : '\n';
  if (opt.minify) return minifyCss(css);
  let out = '', i = 0, pad = '  '.repeat(indent);
  while (i < css.length) {
    while (/\s/.test(css[i])) i++;
    if (i >= css.length) break;
    const semi = css.indexOf(';', i), brace = css.indexOf('{', i);
    if (semi !== -1 && (brace === -1 || semi < brace)) {
      out += pad + normalizePrelude(css.slice(i, semi), false) + ';\n\n';
      i = semi + 1;
      continue;
    }
    if (brace === -1) break;
    const pre = normalizePrelude(css.slice(i, brace), false);
    const close = findMatching(css, brace);
    if (close < 0) panic('src/main.rs:187:45', 'Error { kind: EndOfInput, loc: None }');
    const body = css.slice(brace + 1, close).trim();
    out += pad + pre + ' {\n';
    if (hasTopBrace(body)) {
      const inner = formatCss(body, opt, indent + 1).replace(/\n+$/,'');
      if (inner) out += inner + '\n';
    } else {
      for (const d of splitDecls(body)) {
        const k = d.indexOf(':');
        if (k < 0) panic('src/main.rs:187:45', 'Error { kind: UnexpectedToken(Ident("red")), loc: Some(ErrorLocation { filename: "stdin", line: 0, column: 0 }) }');
        const prop = d.slice(0, k).trim();
        let val = normalizeValue(d.slice(k + 1), false);
        if (prop === 'composes') continue;
        out += pad + '  ' + prop + ': ' + val + ';\n';
      }
    }
    out += pad + '}\n\n';
    i = close + 1;
  }
  return out;
}

function minifyCss(css) {
  css = stripComments(css);
  css = css.replace(/@import\s+([^;]+);/g, (_, v) => `@import ${v.trim()};`);
  let prev;
  do {
    prev = css;
    css = css.replace(/([^{};]+)\{([^{}]*)\}/g, (_, sel, body) => {
      const decls = splitDecls(body).map(d => {
        const k = d.indexOf(':');
        if (k < 0) return '';
        const prop = d.slice(0, k).trim();
        if (prop === 'composes') return '';
        return prop + ':' + normalizeValue(d.slice(k + 1), true);
      }).filter(Boolean).join(';');
      return normalizePrelude(sel, true) + '{' + decls + '}';
    });
  } while (css !== prev);
  return css.replace(/\s+/g, ' ')
    .replace(/\s*([{}:;,])\s*/g, '$1')
    .replace(/@media\s*\((min-width|max-width):([^)]*)\)/gi, (_, k, v) => k.toLowerCase() === 'min-width' ? `@media (width>=${v.trim()})` : `@media (width<=${v.trim()})`)
    .replace(/;}/g, '}')
    .replace(/\s*,\s*/g, ',')
    .trim();
}

function bundle(css, base, seen = new Set()) {
  return css.replace(/@import\s+(?:url\()?["']([^"')]+)["']\)?\s*;/g, (m, rel) => {
    const p = path.resolve(base || '.', rel);
    if (seen.has(p)) return '';
    seen.add(p);
    try { return bundle(fs.readFileSync(p, 'utf8'), path.dirname(p), seen); }
    catch { return m; }
  });
}

function scopedName(file, local, pattern) {
  const h = crypto.createHash('sha1').update(path.resolve(file || 'stdin') + ':' + local).digest('base64url').replace(/[-_]/g, '').slice(0, 6) || 'hash';
  const name = path.basename(file || 'stdin').replace(/\.module(?=\.)/, '').replace(/\.[^.]+$/, '').replace(/[^a-zA-Z0-9_]/g, '-');
  if (pattern) return pattern.replace(/\[hash\]/g, h).replace(/\[local\]/g, local).replace(/\[name\]/g, name);
  return `${h}_${local}`;
}

function applyCssModules(css, file, opt) {
  const exports = {};
  const map = new Map();
  const get = (n, ref = false) => {
    if (!map.has(n)) map.set(n, scopedName(file, n, opt.cssModulesPattern));
    exports[n] = exports[n] || { composes: [], isReferenced: false, name: map.get(n) };
    if (ref) exports[n].isReferenced = true;
    return map.get(n);
  };
  css = css.replace(/:global\(([^)]+)\)/g, '$1');
  css = css.replace(/\.([_a-zA-Z][\w-]*)/g, (_, n) => '.' + get(n));
  css = css.replace(/#([_a-zA-Z][\w-]*)/g, (_, n) => '#' + get(n));
  css = css.replace(/@keyframes\s+([_a-zA-Z][\w-]*)/g, (_, n) => '@keyframes ' + get(n, true));
  css = css.replace(/animation(?:-name)?\s*:\s*([^;{}]+)/g, (m, v) => {
    let nv = v.replace(/\b([_a-zA-Z][\w-]*)\b/g, (tok) => map.has(tok) || exports[tok] ? get(tok, true) : tok);
    nv = nv.replace(/^([_a-zA-Z][\w-]*)\s+((?:\d*\.?\d+)(?:ms|s)\b.*)$/i, '$2 $1');
    return m.split(':')[0] + ': ' + nv;
  });
  css = css.replace(/\s*composes\s*:[^;{}]+;?/g, '');
  const ordered = {};
  for (const k of Object.keys(exports).sort()) ordered[k] = exports[k];
  return { css, exports: ordered };
}

function sourceMap(outFile, sources, contents) {
  return JSON.stringify({ version: 3, mappings: '', sources: sources.map(s => s || 'stdin'), sourcesContent: contents, names: [] });
}

function processOne(file, opt) {
  let css = readInput(file);
  const original = css;
  if (opt.bundle) css = bundle(css, file ? path.dirname(path.resolve(file)) : process.cwd());
  let exports = null;
  if (opt.cssModules) {
    const r = applyCssModules(css, file, opt);
    css = r.css; exports = r.exports;
  }
  const code = formatCss(css, opt);
  return { code, exports, original };
}

function main() {
  const opt = parseArgs(process.argv.slice(2));
  if (opt.inputs.length > 1 && !opt.outputDir) {
    process.stderr.write('Cannot output to stdout with multiple inputs. Use --output-dir instead.\n');
    process.exit(1);
  }
  if (opt.outputDir) fs.mkdirSync(opt.outputDir, { recursive: true });
  const inputs = opt.inputs.length ? opt.inputs : [undefined];
  for (const input of inputs) {
    const result = processOne(input, opt);
    let code = result.code;
    if (opt.cssModules && !opt.outputFile && !opt.outputDir) {
      process.stdout.write(JSON.stringify({ code, exports: result.exports }));
      continue;
    }
    let outFile = opt.outputFile;
    if (opt.outputDir) outFile = path.join(opt.outputDir, path.basename(input || 'stdin.css'));
    if (outFile) {
      if (opt.sourcemap) code += `\n/*# sourceMappingURL=${path.basename(outFile)}.map */`;
      fs.writeFileSync(outFile, code);
      if (opt.cssModules) fs.writeFileSync(opt.cssModulesFile || outFile + '.json', JSON.stringify(result.exports));
      if (opt.sourcemap) fs.writeFileSync(outFile + '.map', sourceMap(outFile, [input], [result.original]));
    } else {
      process.stdout.write(code);
    }
  }
}

main();
