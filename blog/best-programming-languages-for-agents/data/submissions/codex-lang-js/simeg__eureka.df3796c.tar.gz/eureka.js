#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const readline = require('readline');
const { spawnSync } = require('child_process');

const GREEN_BOLD = '\x1b[0m\x1b[1m\x1b[32m';
const YELLOW = '\x1b[0m\x1b[33m';
const RED = '\x1b[0m\x1b[31m';
const RESET = '\x1b[0m';

function homeDir() {
  return process.env.HOME || os.homedir();
}

function configPath() {
  const base = process.env.XDG_CONFIG_HOME || path.join(homeDir(), '.config');
  return path.join(base, 'eureka', 'config.json');
}

function ensureRosettaCache() {
  try {
    fs.mkdirSync(path.join(homeDir(), '.cache', 'rosetta'), { recursive: true });
  } catch (_) {
  }
}

function error(message) {
  console.error(` ERROR eureka > ${message}`);
}

function readConfig() {
  const content = fs.readFileSync(configPath(), 'utf8');
  return JSON.parse(content);
}

function printHelp() {
  console.log(`Input and store your ideas without leaving the terminal

Usage: executable [OPTIONS]

Options:
      --clear-config  Clear your stored configuration
  -v, --view          View ideas with your $PAGER env variable. If unset use less
  -h, --help          Print help
  -V, --version       Print version`);
}

function parseArgs(args) {
  let clear = false;
  let view = false;
  for (const arg of args) {
    if (arg === '--clear-config') clear = true;
    else if (arg === '-v' || arg === '--view') view = true;
    else if (arg === '-h' || arg === '--help') return { help: true };
    else if (arg === '-V' || arg === '--version') return { version: true };
    else {
      console.error(`error: unexpected argument '${arg}' found

Usage: executable [OPTIONS]

For more information, try '--help'.`);
      process.exit(2);
    }
  }
  return { clear, view };
}

let rl;
let pipedInput;

function question(label) {
  return new Promise((resolve) => {
    process.stdout.write(`${GREEN_BOLD}${label}\n${RESET}> `);
    if (!process.stdin.isTTY) {
      if (!pipedInput) {
        try {
          pipedInput = fs.readFileSync(0, 'utf8').split(/\r?\n/);
        } catch (_) {
          pipedInput = [''];
        }
      }
      resolve(pipedInput.length ? pipedInput.shift() : '');
      return;
    }
    if (!rl) {
      rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: false });
    }
    rl.question('', (answer) => {
      resolve(answer);
    });
  });
}

async function firstSetup() {
  console.log(`${YELLOW}############################################################
####                  First Time Setup                  ####
############################################################

This tool requires you to have a repository with a README.md
in the root folder. The markdown file is where your ideas
will be stored.

Once first time setup has completed, simply run Eureka again
to begin writing down ideas.
        \n${RESET}`);

  while (true) {
    const repo = await question('Absolute path to your idea repo');
    if (!path.isAbsolute(repo.trim())) {
      console.log(`${RED}Path must be absolute\n${RESET}`);
      continue;
    }
    fs.mkdirSync(path.dirname(configPath()), { recursive: true });
    fs.writeFileSync(configPath(), JSON.stringify({ repo: repo.trim() }));
    console.log('First time setup complete. Happy ideation!');
    return;
  }
}

function run(cmd, args, opts = {}) {
  return spawnSync(cmd, args, {
    cwd: opts.cwd,
    stdio: opts.stdio || 'inherit',
    env: process.env,
    encoding: 'utf8',
  });
}

function runGit(repo, args, quiet = false) {
  return spawnSync('git', args, {
    cwd: repo,
    stdio: quiet ? ['ignore', 'pipe', 'pipe'] : 'inherit',
    encoding: 'utf8',
  });
}

function gitError(res) {
  const text = ((res.stderr || '') + (res.stdout || '')).trim().split('\n').filter(Boolean).pop();
  const all = ((res.stderr || '') + (res.stdout || ''));
  if (!text) return 'git command failed';
  if (text.includes('user.name')) return "config value 'user.name' was not found; class=Config (7); code=NotFound (-3)";
  if (all.includes("'origin'") || all.includes('origin')) return "remote 'origin' does not exist; class=Config (7); code=NotFound (-3)";
  return text.replace(/^fatal: /, '');
}

async function capture() {
  let cfg;
  try {
    cfg = readConfig();
  } catch (e) {
    if (e.code === 'ENOENT') return firstSetup();
    error(e.message);
    return;
  }
  if (!cfg || typeof cfg.repo !== 'string') {
    error('missing field `repo` at line 1 column 2');
    return;
  }

  let summary = '';
  while (!summary.trim()) {
    summary = await question('>> Idea summary');
  }

  const readme = path.join(cfg.repo, 'README.md');
  const editor = process.env.EDITOR || process.env.VISUAL || 'vi';
  run(editor, [readme]);

  console.log('Adding and committing your new idea to main..');
  let res = runGit(cfg.repo, ['rev-parse', '--verify', 'main'], true);
  if (res.status !== 0) {
    res = runGit(cfg.repo, ['checkout', '-b', 'main'], true);
  } else {
    res = runGit(cfg.repo, ['checkout', 'main'], true);
  }
  if (res.status !== 0) {
    error(gitError(res));
    return;
  }

  res = runGit(cfg.repo, ['add', 'README.md'], true);
  if (res.status !== 0) {
    error(gitError(res));
    return;
  }
  res = runGit(cfg.repo, ['commit', '-m', summary.trim()], true);
  if (res.status !== 0) {
    error(gitError(res));
    return;
  }
  console.log('Added and committed!');
  console.log('Pushing your new idea..');
  res = runGit(cfg.repo, ['push', 'origin', 'main'], true);
  if (res.status !== 0) {
    error(gitError(res));
  }
}

function viewIdeas() {
  try {
    const cfg = readConfig();
    if (!cfg || typeof cfg.repo !== 'string') {
      error('missing field `repo` at line 1 column 2');
      return;
    }
    const pager = process.env.PAGER || 'less';
    const readme = path.join(cfg.repo, 'README.md');
    const res = run(pager, [readme], { stdio: 'inherit' });
    if (res.error) error(res.error.message);
  } catch (e) {
    error(e.message);
  }
}

function clearConfig() {
  try {
    fs.unlinkSync(configPath());
  } catch (e) {
    error(e.message);
  }
}

async function main() {
  ensureRosettaCache();
  const args = parseArgs(process.argv.slice(2));
  if (args.help) return printHelp();
  if (args.version) return console.log('eureka 2.0.0');
  if (args.clear) return clearConfig();
  if (args.view) return viewIdeas();
  return capture();
}

main().catch((e) => error(e.message));
