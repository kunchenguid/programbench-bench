#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const ZERO = '0001-01-01T00:00:00Z';
const STATUSES = ['active', 'paused', 'pending', 'resolved', 'template'];
const LIST_COMMANDS = new Set([
  'next', 'show-open', 'show-active', 'show-paused', 'show-resolved',
  'show-templates', 'show-unorganised'
]);
const COMMANDS = new Set([
  ...LIST_COMMANDS, 'add', 'template', 'log', 'start', 'stop', 'done',
  'context', 'modify', 'edit', 'note', 'undo', 'sync', 'open', 'git',
  'remove', 'show-projects', 'show-tags', 'bash-completion',
  'fish-completion', 'zsh-completion', 'powershell-completion', 'help',
  'version'
]);

function repoDir() {
  return process.env.DSTASK_GIT_REPO || path.join(os.homedir(), '.dstask');
}

function now() {
  return new Date().toISOString();
}

function ensureRepo() {
  const repo = repoDir();
  const existed = fs.existsSync(repo);
  fs.mkdirSync(repo, { recursive: true });
  for (const d of STATUSES) fs.mkdirSync(path.join(repo, d), { recursive: true });
  if (!fs.existsSync(path.join(repo, '.git'))) {
    spawnSync('git', ['-C', repo, 'init'], { stdio: 'inherit' });
    process.stdout.write('\nAdd a remote repository with:\n\n\tdstask git remote add origin <repo>\n\n');
  }
  return { repo, newlyCreated: !existed };
}

function idsPath(repo) {
  return path.join(repo, '.dstask-js-ids.json');
}

function contextPath(repo) {
  return path.join(repo, '.dstask-js-context.json');
}

function loadIds(repo) {
  try {
    return JSON.parse(fs.readFileSync(idsPath(repo), 'utf8'));
  } catch {
    return { next: 1, ids: {} };
  }
}

function saveIds(repo, ids) {
  fs.writeFileSync(idsPath(repo), JSON.stringify(ids, null, 2));
}

function loadContext(repo) {
  try {
    return JSON.parse(fs.readFileSync(contextPath(repo), 'utf8'));
  } catch {
    return { tags: [], project: '' };
  }
}

function saveContext(repo, ctx) {
  fs.writeFileSync(contextPath(repo), JSON.stringify(ctx, null, 2));
}

function esc(v) {
  return String(v ?? '').replace(/\\/g, '\\\\').replace(/\n/g, '\\n');
}

function unesc(v) {
  return String(v ?? '').replace(/\\n/g, '\n').replace(/\\\\/g, '\\');
}

function yaml(task) {
  const tags = task.tags.length ? task.tags.map(t => `- ${t}`).join('\n') : '[]';
  return [
    `summary: ${esc(task.summary)}`,
    `notes: ${esc(task.notes)}`,
    'tags:',
    tags,
    `project: ${esc(task.project)}`,
    `priority: ${task.priority}`,
    'delegatedto: ""',
    'subtasks: []',
    'dependencies: []',
    `created: ${task.created}`,
    `resolved: ${task.resolved}`,
    `due: ${task.due}`,
    ''
  ].join('\n');
}

function parseYaml(txt) {
  const t = {
    summary: '', notes: '', tags: [], project: '', priority: 'P2',
    created: ZERO, resolved: ZERO, due: ZERO
  };
  const lines = txt.split(/\r?\n/);
  let inTags = false;
  for (const line of lines) {
    if (line === 'tags:') {
      inTags = true;
      continue;
    }
    if (inTags && line.startsWith('- ')) {
      t.tags.push(line.slice(2).trim());
      continue;
    }
    if (inTags && line && !line.startsWith('- ')) inTags = false;
    const m = line.match(/^([a-z]+):\s*(.*)$/);
    if (!m) continue;
    if (m[1] in t) t[m[1]] = unesc(m[2].replace(/^"(.*)"$/, '$1'));
  }
  return t;
}

function taskFile(repo, status, uuid) {
  return path.join(repo, status, `${uuid}.yml`);
}

function loadTasks(repo) {
  const ids = loadIds(repo);
  const tasks = [];
  for (const status of STATUSES) {
    const dir = path.join(repo, status);
    if (!fs.existsSync(dir)) continue;
    for (const name of fs.readdirSync(dir)) {
      if (!name.endsWith('.yml')) continue;
      const uuid = name.slice(0, -4);
      const task = parseYaml(fs.readFileSync(path.join(dir, name), 'utf8'));
      task.uuid = uuid;
      task.status = status;
      task.id = status === 'resolved' ? 0 : (ids.ids[uuid] || 0);
      tasks.push(task);
    }
  }
  tasks.sort(taskCompare);
  return tasks;
}

function priorityValue(p) {
  return ({ P0: 0, P1: 1, P2: 2, P3: 3 })[p] ?? 2;
}

function taskCompare(a, b) {
  const pa = priorityValue(a.priority) - priorityValue(b.priority);
  if (pa) return pa;
  const ca = String(a.created).localeCompare(String(b.created));
  if (ca) return ca;
  return String(a.summary).localeCompare(String(b.summary));
}

function publicTask(t) {
  return {
    uuid: t.uuid,
    status: t.status === 'template' ? 'pending' : t.status,
    id: t.id || 0,
    summary: t.summary,
    notes: t.notes || '',
    tags: t.tags || [],
    project: t.project || '',
    priority: t.priority || 'P2',
    created: t.created || ZERO,
    resolved: t.resolved || ZERO,
    due: t.due || ZERO
  };
}

function printJson(items) {
  process.stdout.write(JSON.stringify(items.map(publicTask), null, 2));
}

function parseSpec(args) {
  const spec = { summary: [], addTags: [], remTags: [], project: undefined, priority: undefined, due: undefined, note: [] };
  let note = false;
  for (const a of args) {
    if (a === '/') {
      note = true;
      continue;
    }
    if (note) {
      spec.note.push(a);
      continue;
    }
    if (/^\+[^\s+]+/.test(a)) spec.addTags.push(a.slice(1));
    else if (/^-[^\s-]+/.test(a)) spec.remTags.push(a.slice(1));
    else if (/^project:/.test(a)) spec.project = a.slice(8);
    else if (/^-project:/.test(a)) spec.project = '';
    else if (/^priority:P[0-3]$/i.test(a)) spec.priority = a.slice(9).toUpperCase();
    else if (/^P[0-3]$/i.test(a)) spec.priority = a.toUpperCase();
    else if (/^due:/.test(a)) spec.due = dateValue(a.slice(4));
    else if (/^template:\d+$/.test(a)) spec.template = Number(a.slice(9));
    else spec.summary.push(a);
  }
  return spec;
}

function dateValue(v) {
  if (!v) return ZERO;
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return `${v}T00:00:00Z`;
  return v;
}

function matches(t, spec) {
  for (const tag of spec.addTags) if (!t.tags.includes(tag)) return false;
  for (const tag of spec.remTags) if (t.tags.includes(tag)) return false;
  if (spec.project !== undefined && t.project !== spec.project) return false;
  if (spec.priority && t.priority !== spec.priority) return false;
  if (spec.due && t.due !== spec.due) return false;
  const text = spec.summary.join(' ').toLowerCase();
  if (text && !(`${t.summary}\n${t.notes}`.toLowerCase().includes(text))) return false;
  return true;
}

function applyContext(args, repo) {
  const noContext = args.includes('--');
  const filtered = args.filter(a => a !== '--');
  if (noContext) return filtered;
  const ctx = loadContext(repo);
  const prefix = [];
  for (const tag of ctx.tags || []) prefix.push(`+${tag}`);
  if (ctx.project) prefix.push(`project:${ctx.project}`);
  return [...prefix, ...filtered];
}

function commit(repo, message) {
  spawnSync('git', ['-C', repo, 'add', '-A'], { stdio: 'ignore' });
  const r = spawnSync('git', [
    '-C', repo, '-c', 'user.name=dstask', '-c', 'user.email=dstask@example.invalid',
    'commit', '-m', message
  ], { encoding: 'utf8' });
  if (r.status === 0) {
    process.stdout.write(`\x1b[38;5;245m${r.stdout}\x1b[0m`);
  }
}

function writeTask(repo, task) {
  fs.mkdirSync(path.join(repo, task.status), { recursive: true });
  fs.writeFileSync(taskFile(repo, task.status, task.uuid), yaml(task));
}

function removeTaskFile(repo, task) {
  const p = taskFile(repo, task.status, task.uuid);
  if (fs.existsSync(p)) fs.unlinkSync(p);
}

function assignId(repo, uuid) {
  const ids = loadIds(repo);
  if (!ids.ids[uuid]) ids.ids[uuid] = ids.next++;
  saveIds(repo, ids);
  return ids.ids[uuid];
}

function findByIds(repo, ids) {
  const wanted = new Set(ids.map(Number));
  return loadTasks(repo).filter(t => wanted.has(t.id));
}

function createTask(repo, args, status) {
  const useContext = !args.includes('--');
  args = args.filter(a => a !== '--');
  let spec = parseSpec(args);
  const ctx = useContext ? loadContext(repo) : { tags: [], project: '' };
  const tags = [...new Set([...(ctx.tags || []), ...spec.addTags])].filter(t => !spec.remTags.includes(t));
  const summary = spec.summary.join(' ').trim();
  const t = {
    uuid: crypto.randomUUID(),
    status,
    summary,
    notes: spec.note.join(' '),
    tags,
    project: spec.project !== undefined ? spec.project : (ctx.project || ''),
    priority: spec.priority || 'P2',
    created: now(),
    resolved: status === 'resolved' ? now() : ZERO,
    due: spec.due || ZERO
  };
  t.id = status === 'resolved' ? 0 : assignId(repo, t.uuid);
  writeTask(repo, t);
  const verb = status === 'template' ? 'Added template' : status === 'resolved' ? 'Logged' : 'Added';
  process.stdout.write(`\n${verb} ${t.id || ''}${t.id ? ': ' : ''}${t.summary}\n`);
  commit(repo, `${verb} ${t.id || ''}${t.id ? ': ' : ''}${t.summary}`.trim());
}

function list(repo, command, args) {
  const raw = args.filter(a => a !== '--');
  const noCtx = args.includes('--');
  let tasks = loadTasks(repo);
  if (command === 'next' || command === 'show-open') tasks = tasks.filter(t => !['resolved', 'template'].includes(t.status));
  if (command === 'show-active') tasks = tasks.filter(t => t.status === 'active');
  if (command === 'show-paused') tasks = tasks.filter(t => t.status === 'paused');
  if (command === 'show-resolved') tasks = tasks.filter(t => t.status === 'resolved');
  if (command === 'show-templates') tasks = tasks.filter(t => t.status === 'template');
  if (command === 'show-unorganised') tasks = tasks.filter(t => !['resolved', 'template'].includes(t.status) && !t.project && (!t.tags || t.tags.length === 0));
  if (!noCtx && ['next', 'show-open'].includes(command)) {
    const ctxSpec = parseSpec(applyContext([], repo));
    tasks = tasks.filter(t => matches(t, ctxSpec));
  }
  if (raw.length) {
    const spec = parseSpec(raw);
    tasks = tasks.filter(t => matches(t, spec));
  }
  printJson(tasks);
}

function mutateStatus(repo, targets, newStatus, verb) {
  for (const t of targets) {
    removeTaskFile(repo, t);
    t.status = newStatus;
    if (newStatus === 'resolved') t.resolved = now();
    writeTask(repo, t);
    process.stdout.write(`\n${verb} ${t.id}: ${t.summary}\n`);
    commit(repo, `${verb} ${t.id}: ${t.summary}`);
  }
}

function modifyTasks(repo, targets, args) {
  const spec = parseSpec(args);
  for (const t of targets) {
    for (const tag of spec.addTags) if (!t.tags.includes(tag)) t.tags.push(tag);
    t.tags = t.tags.filter(tag => !spec.remTags.includes(tag));
    if (spec.project !== undefined) t.project = spec.project;
    if (spec.priority) t.priority = spec.priority;
    if (spec.due) t.due = spec.due;
    writeTask(repo, t);
    process.stdout.write(`\nModified ${t.id}: ${t.summary}\n`);
    commit(repo, `Modified ${t.id}: ${t.summary}`);
  }
}

function showTags(repo) {
  const tags = new Set();
  for (const t of loadTasks(repo)) if (t.status !== 'resolved') for (const tag of t.tags) tags.add(tag);
  process.stdout.write([...tags].sort().join('\n'));
}

function showProjects(repo) {
  const projects = new Map();
  for (const t of loadTasks(repo)) {
    if (!t.project) continue;
    const p = projects.get(t.project) || {
      name: t.project, taskCount: 0, resolvedCount: 0, active: false,
      created: t.created, resolved: ZERO, priority: t.priority
    };
    p.taskCount++;
    if (t.status === 'resolved') p.resolvedCount++;
    if (t.status === 'active') p.active = true;
    if (String(t.created) < String(p.created)) p.created = t.created;
    if (priorityValue(t.priority) < priorityValue(p.priority)) p.priority = t.priority;
    projects.set(t.project, p);
  }
  process.stdout.write(JSON.stringify([...projects.values()].sort((a, b) => a.name.localeCompare(b.name)), null, 2));
}

function showOne(task) {
  if (!task) {
    printJson([]);
    return;
  }
  printJson([task]);
}

function help(cmd) {
  if (cmd === 'add') {
    process.stdout.write(`Usage: dstask add [template:<id>] [task summary] [--]\nExample: dstask add Fix main web page 500 error +bug P1 project:website\n\nAdd a task, returning the git commit output which contains the task ID, used\nlater to reference the task.\n\nTags, project and priority can be added anywhere within the task summary.\n\nAdd -- to ignore the current context. / can be used when adding tasks to note\nany words after.\n`);
    return;
  }
  if (cmd === 'modify') {
    process.stdout.write(`Usage: dstask <id...> modify <filter>\nUsage: dstask modify <filter>\nExample: dstask 34 modify -work +home project:workbench -project:website\n\nModify the attributes of the given tasks, specified by ID. If no ID is given,\nthe operation will be performed to all tasks in the current context subject to\nconfirmation.\n\nModifiable attributes: tags, project and priority.\n`);
    return;
  }
  process.stdout.write(`Usage: dstask [id...] <cmd> [task summary/filter]\n\nWhere [task summary] is text with tags/project/priority specified. Tags are\nspecified with + (or - for filtering) eg: +work. The project is specified with\na project:g prefix eg: project:dstask -- no quotes. Priorities run from P3\n(low), P2 (default) to P1 (high) and P0 (critical). Text can also be specified\nfor a substring search of description and notes.\n\nCmd and IDs can be swapped, multiple IDs can be specified for batch\noperations.\n\nrun "dstask help <cmd>" for command specific help.\n\nAvailable commands:\n\nnext              : Show most important tasks (priority, creation date -- truncated and default)\nadd               : Add a task\ntemplate          : Add a task template\nlog               : Log a task (already resolved)\nstart             : Change task status to active\nnote              : Append to or edit note for a task\nstop              : Change task status to pending\ndone              : Resolve a task\ncontext           : Set global context for task list and new tasks (use "none" to set no context)\nmodify            : Change task attributes specified on command line\nedit              : Edit task with text editor\nundo              : Undo last n commits\nsync              : Pull then push to git repository, automatic merge commit.\nopen              : Open all URLs found in summary/annotations\ngit               : Pass a command to git in the repository. Used for push/pull.\nremove            : Remove a task (use to remove tasks added by mistake)\nshow-projects     : List projects with completion status\nshow-tags         : List tags in use\nshow-active       : Show tasks that have been started\nshow-paused       : Show tasks that have been started then stopped\nshow-open         : Show all non-resolved tasks (without truncation)\nshow-resolved     : Show resolved tasks\nshow-templates    : Show task templates\nshow-unorganised  : Show untagged tasks with no projects (global context)\nbash-completion   : Print bash completion script to stdout\nfish-completion   : Print fish completion script to stdout\nzsh-completion    : Print zsh completion script to stdout\nhelp              : Get help on any command or show this message\nversion           : Show dstask version information\n`);
}

function completions(shell) {
  if (shell === 'bash') process.stdout.write('complete -W "add next start stop done modify remove show-open show-resolved show-tags show-projects context help version" dstask\n');
  else if (shell === 'fish') process.stdout.write('complete -c dstask -f\n');
  else if (shell === 'zsh') process.stdout.write('#compdef dstask\n_arguments "*: :((add next start stop done modify remove show-open show-resolved show-tags show-projects context help version))"\n');
  else process.stdout.write('');
}

function main() {
  const { repo } = ensureRepo();
  let args = process.argv.slice(2);
  if (args[0] === '--help') args = ['next', '--help'];
  if (args[0] === '--version') args = ['version'];
  if (args[0] === 'help') return help(args[1]);
  if (args[0] === 'version') return process.stdout.write('Version: Unknown\nGit commit: Unknown\nBuild date: Unknown\n');
  if (args[0] === 'bash-completion') return completions('bash');
  if (args[0] === 'fish-completion') return completions('fish');
  if (args[0] === 'zsh-completion') return completions('zsh');
  if (args[0] === 'powershell-completion') return completions('powershell');

  if (args[0] === 'git') {
    const r = spawnSync('git', ['-C', repo, ...args.slice(1)], { stdio: 'inherit' });
    process.exit(r.status ?? 0);
  }
  if (args[0] === 'sync') {
    spawnSync('git', ['-C', repo, 'pull'], { stdio: 'inherit' });
    const r = spawnSync('git', ['-C', repo, 'push'], { stdio: 'inherit' });
    process.exit(r.status ?? 0);
  }
  if (args[0] === 'undo') {
    const n = Number(args[1] || 1);
    const r = spawnSync('git', ['-C', repo, 'reset', '--hard', `HEAD~${n}`], { stdio: 'inherit' });
    process.exit(r.status ?? 0);
  }

  if (args[0] === 'context') {
    if (args.length === 1) {
      const ctx = loadContext(repo);
      process.stdout.write([...ctx.tags.map(t => `+${t}`), ctx.project ? `project:${ctx.project}` : ''].filter(Boolean).join(' '));
      return;
    }
    if (args[1] === 'none' || args[1] === '--') {
      saveContext(repo, { tags: [], project: '' });
      return;
    }
    const spec = parseSpec(args.slice(1));
    if (spec.summary.length) {
      process.stderr.write('\x1b[31mcontext cannot contain text\x1b[0m\n');
      process.exit(1);
    }
    saveContext(repo, { tags: spec.addTags, project: spec.project || '' });
    return;
  }

  if (!args.length || args[0] === 'next' || args[0] === '--help') return list(repo, 'next', args[0] === 'next' ? args.slice(1) : args);
  if (args[0] === 'show-tags') return showTags(repo);
  if (args[0] === 'show-projects') return showProjects(repo);
  if (LIST_COMMANDS.has(args[0])) return list(repo, args[0], args.slice(1));
  if (args[0] === 'add') return createTask(repo, args.slice(1), 'pending');
  if (args[0] === 'template') return createTask(repo, args.slice(1), 'template');
  if (args[0] === 'log') return createTask(repo, args.slice(1), 'resolved');

  let ids = [];
  while (args.length && /^\d+$/.test(args[0])) ids.push(Number(args.shift()));
  let cmd = args[0];
  if (COMMANDS.has(cmd)) {
    args.shift();
    while (args.length && /^\d+$/.test(args[0])) ids.push(Number(args.shift()));
  } else if (ids.length && COMMANDS.has(args[0])) {
    cmd = args.shift();
  }
  if (!cmd && ids.length === 1) return showOne(findByIds(repo, ids)[0]);
  if (!COMMANDS.has(cmd) && ids.length === 0) return list(repo, 'next', process.argv.slice(2));
  const targets = findByIds(repo, ids);
  if (cmd === 'start') return mutateStatus(repo, targets, 'active', 'Started');
  if (cmd === 'stop') return mutateStatus(repo, targets, 'paused', 'Stopped');
  if (cmd === 'done') return mutateStatus(repo, targets, 'resolved', 'Resolved');
  if (cmd === 'remove') {
    for (const t of targets) {
      process.stdout.write(`${t.id}: ${t.summary}\n\nRemoved: ${t.id}: ${t.summary}\n`);
      removeTaskFile(repo, t);
      commit(repo, `Removed: ${t.id}: ${t.summary}`);
    }
    return;
  }
  if (cmd === 'modify') return modifyTasks(repo, targets, args);
  if (cmd === 'note') {
    const extra = args.join(' ');
    for (const t of targets) {
      if (extra) t.notes = t.notes ? `${t.notes}\n${extra}` : extra;
      writeTask(repo, t);
      if (extra) commit(repo, `Noted ${t.id}: ${t.summary}`);
    }
    return;
  }
  if (cmd === 'edit') return modifyTasks(repo, targets, args);
  if (cmd === 'open') {
    const urls = [];
    for (const t of targets) {
      const text = `${t.summary}\n${t.notes}`;
      const m = text.match(/https?:\/\/\S+/g);
      if (m) urls.push(...m);
    }
    process.stdout.write(urls.join('\n'));
    return;
  }
  if (ids.length === 1) return showOne(targets[0]);
  list(repo, 'next', args);
}

main();
