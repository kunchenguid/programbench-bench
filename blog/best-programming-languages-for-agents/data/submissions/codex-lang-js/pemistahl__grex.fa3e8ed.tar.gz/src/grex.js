#!/usr/bin/env node
"use strict";

const fs = require("fs");

const HELP = `grex 1.4.6
© 2019-today Peter M. Stahl <pemistahl@gmail.com>
Licensed under the Apache License, Version 2.0
Downloadable from https://crates.io/crates/grex
Source code at https://github.com/pemistahl/grex

grex generates regular expressions from user-provided test cases.

Usage: grex [OPTIONS] {INPUT...|--file <FILE>}

Input:
  [INPUT]...
          One or more test cases separated by blank space
          
          Use a hyphen \`-\` to read test cases from standard input.
          
          Conflicts with --file.

  -f, --file <FILE>
          Reads test cases on separate lines from a file.
          
          Lines may be ended with either a newline \`\\n\` or a carriage return with a line feed
          \`\\r\\n\`. The final line ending is optional.
          
          Use a hyphen \`-\` to read the filename from standard input.
          
          Conflicts with INPUT...

Digit Options:
  -d, --digits
          Converts any Unicode decimal digit to \\d.

  -D, --non-digits
          Converts any character which is not a Unicode decimal digit to \\D.

Whitespace Options:
  -s, --spaces
          Converts any Unicode whitespace character to \\s.

  -S, --non-spaces
          Converts any character which is not a Unicode whitespace character to \\S

Word Options:
  -w, --words
          Converts any Unicode word character to \\w.

  -W, --non-words
          Converts any character which is not a Unicode word character to \\W.

Escaping Options:
  -e, --escape
          Replaces all non-ASCII characters with unicode escape sequences

      --with-surrogates
          Converts astral code points to surrogate pairs if --escape is set

Repetition Options:
  -r, --repetitions
          Detects repeated non-overlapping substrings and converts them to {min,max} quantifier
          notation

      --min-repetitions <QUANTITY>
          Specifies the minimum quantity of substring repetitions to be converted if --repetitions
          is set
          
          [default: 1]

      --min-substring-length <LENGTH>
          Specifies the minimum length a repeated substring must have in order to be converted if
          --repetitions is set
          
          [default: 1]

Anchor Options:
      --no-start-anchor
          Removes the caret anchor \`^\` from the resulting regular expression.

      --no-end-anchor
          Removes the dollar sign anchor \`$\` from the resulting regular expression.

      --no-anchors
          Removes the caret and dollar sign anchors from the resulting regular expression.

Display Options:
  -x, --verbose
          Produces a nicer-looking regular expression in verbose mode

  -c, --colorize
          Provides syntax highlighting for the resulting regular expression

Miscellaneous Options:
  -i, --ignore-case
          Performs case-insensitive matching, letters match both upper and lower case

  -g, --capture-groups
          Replaces non-capturing groups with capturing ones

  -h, --help
          Prints help information

  -v, --version
          Prints version information`;

function die(msg, code = 2) {
  console.error(msg);
  process.exit(code);
}

function parse(argv) {
  const o = {
    digits: false, nonDigits: false, spaces: false, nonSpaces: false,
    words: false, nonWords: false, escape: false, surrogates: false,
    repetitions: false, minRepetitions: 1, minSubstringLength: 1,
    start: true, end: true, verbose: false, color: false,
    ignoreCase: false, capture: false, file: null, inputs: []
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "-h" || a === "--help") { console.log(HELP); process.exit(0); }
    if (a === "-v" || a === "--version") { console.log("grex 1.4.6"); process.exit(0); }
    if (a === "-f" || a === "--file") { if (++i >= argv.length) die("error: a value is required for '--file <FILE>' but none was supplied"); o.file = argv[i]; continue; }
    if (a === "--with-surrogates") { o.surrogates = true; continue; }
    if (a === "--min-repetitions") { o.minRepetitions = Number(argv[++i] || ""); continue; }
    if (a === "--min-substring-length") { o.minSubstringLength = Number(argv[++i] || ""); continue; }
    if (a === "--no-start-anchor") { o.start = false; continue; }
    if (a === "--no-end-anchor") { o.end = false; continue; }
    if (a === "--no-anchors") { o.start = false; o.end = false; continue; }
    if (a.startsWith("-") && a !== "-") {
      let known = true;
      for (const ch of a.slice(1)) {
        if (ch === "d") o.digits = true; else if (ch === "D") o.nonDigits = true;
        else if (ch === "s") o.spaces = true; else if (ch === "S") o.nonSpaces = true;
        else if (ch === "w") o.words = true; else if (ch === "W") o.nonWords = true;
        else if (ch === "e") o.escape = true; else if (ch === "r") o.repetitions = true;
        else if (ch === "x") o.verbose = true; else if (ch === "c") o.color = true;
        else if (ch === "i") o.ignoreCase = true; else if (ch === "g") o.capture = true;
        else { known = false; break; }
      }
      if (known) continue;
    }
    o.inputs.push(a);
  }
  return o;
}

function readInputs(o) {
  if (o.file !== null && o.inputs.length) {
    die("error: the argument '--file <FILE>' cannot be used with '[INPUT]...'\n\nUsage: grex [OPTIONS] {INPUT...|--file <FILE>}\n\nFor more information, try '--help'.");
  }
  if (o.file !== null) {
    let name = o.file === "-" ? fs.readFileSync(0, "utf8") : o.file;
    name = name.replace(/\r?\n$/, "");
    try {
      const text = fs.readFileSync(name, "utf8");
      if (text.length === 0) return [];
      return text.replace(/\r\n/g, "\n").replace(/\n$/, "").split("\n");
    } catch {
      die("error: the specified file could not be found", 1);
    }
  }
  if (!o.inputs.length) {
    die("error: the following required arguments were not provided:\n  --file <FILE>\n  <INPUT>...\n\nUsage: grex [OPTIONS] {INPUT...|--file <FILE>}\n\nFor more information, try '--help'.");
  }
  if (o.inputs.length === 1 && o.inputs[0] === "-") {
    const text = fs.readFileSync(0, "utf8");
    if (text.length === 0) return [];
    return text.replace(/\r\n/g, "\n").replace(/\n$/, "").split("\n");
  }
  return o.inputs;
}

function graphemes(s) {
  const out = [];
  for (const c of Array.from(s)) {
    if (/^\p{M}$/u.test(c) && out.length) out[out.length - 1] += c;
    else out.push(c);
  }
  return out;
}

function isDigit(c) { return /^\p{Decimal_Number}$/u.test(c); }
function isSpace(c) { return /^\p{White_Space}$/u.test(c); }
function isWord(c) { return /^[\p{Alphabetic}\p{Mark}\p{Decimal_Number}\p{Connector_Punctuation}\u200c\u200d]$/u.test(c); }

function escapeLiteral(c, o) {
  let cp = c.codePointAt(0);
  if (o.escape && /[^\x00-\x7f]/u.test(c)) {
    if (o.surrogates && cp > 0xffff) {
      const n = cp - 0x10000, hi = 0xd800 + (n >> 10), lo = 0xdc00 + (n & 0x3ff);
      return `\\u{${hi.toString(16)}}\\u{${lo.toString(16)}}`;
    }
    return `\\u{${cp.toString(16)}}`;
  }
  return c.replace(/[\\^$.*+?()[\]{}|/-]/g, "\\$&");
}

function tokenFor(g, o) {
  const single = Array.from(g).length === 1;
  if (single) {
    if (o.spaces && isSpace(g)) return "\\s";
    if (o.digits && isDigit(g)) return "\\d";
    if (o.words && isWord(g)) return "\\w";
    if (o.nonDigits && !isDigit(g)) return "\\D";
    if (o.nonWords && !isWord(g)) return "\\W";
    if (o.nonSpaces && !isSpace(g)) return "\\S";
  }
  return escapeLiteral(g, o);
}

function preprocess(s, o) {
  if (o.ignoreCase) s = s.toLowerCase();
  let toks = graphemes(s).map(g => tokenFor(g, o));
  if (o.repetitions) toks = applyRepetitions(toks, o);
  return toks;
}

function applyRepetitions(toks, o) {
  const out = [];
  for (let i = 0; i < toks.length;) {
    let best = null;
    const maxLen = Math.floor((toks.length - i) / (o.minRepetitions + 1));
    for (let len = o.minSubstringLength; len <= maxLen; len++) {
      const pat = toks.slice(i, i + len).join("");
      let count = 1, j = i + len;
      while (j + len <= toks.length && toks.slice(j, j + len).join("") === pat) { count++; j += len; }
      if (count >= o.minRepetitions + 1) { best = { len, count }; break; }
    }
    if (best) {
      const part = toks.slice(i, i + best.len);
      const atom = part.length === 1 ? part[0] : group(part.join(""), o);
      out.push(`${atom}{${best.count}}`);
      i += best.len * best.count;
    } else {
      out.push(toks[i++]);
    }
  }
  return out;
}

function group(s, o) { return (o.capture ? "(" : "(?:") + s + ")"; }

class Node {
  constructor() { this.end = false; this.children = new Map(); }
}

function buildTrie(arrs) {
  const root = new Node();
  for (const arr of arrs) {
    let n = root;
    for (const t of arr) {
      if (!n.children.has(t)) n.children.set(t, new Node());
      n = n.children.get(t);
    }
    n.end = true;
  }
  return root;
}

function charClass(tokens) {
  if (!tokens.length) return "";
  const raw = [];
  for (const t of tokens) {
    if (t.length !== 1 || /[\\\]\[]/.test(t)) return null;
    raw.push(t);
  }
  raw.sort((a, b) => a.codePointAt(0) - b.codePointAt(0));
  const ranges = [];
  for (let i = 0; i < raw.length;) {
    let j = i;
    while (j + 1 < raw.length && raw[j + 1].codePointAt(0) === raw[j].codePointAt(0) + 1) j++;
    if (j - i >= 2) ranges.push(`${raw[i]}-${raw[j]}`);
    else for (let k = i; k <= j; k++) ranges.push(raw[k].replace(/[-\\\]^]/g, "\\$&"));
    i = j + 1;
  }
  return `[${ranges.join("")}]`;
}

function nodeRegex(node, o) {
  const alts = [];
  for (const [tok, child] of node.children) alts.push(tok + nodeRegex(child, o));
  alts.sort((a, b) => b.length - a.length || a.localeCompare(b));
  const singleChar = [];
  const others = [];
  for (const a of alts) {
    if (a.length === 1 && !/[\\^$.*+?()[\]{}|/-]/.test(a)) singleChar.push(a);
    else others.push(a);
  }
  if (singleChar.length >= 2) others.push(charClass(singleChar));
  else others.push(...singleChar);
  others.sort((a, b) => b.length - a.length || a.localeCompare(b));
  let body = "";
  if (others.length === 1) body = others[0];
  else if (others.length > 1) body = group(others.join("|"), o);
  if (node.end && body) return group(body, o) + "?";
  if (node.end) return "";
  return body;
}

function commonSuffix(arrs) {
  if (arrs.length < 2) return [];
  let n = 0;
  while (true) {
    let tok = null;
    for (const a of arrs) {
      if (n >= a.length) return arrs[0].slice(arrs[0].length - n);
      const cur = a[a.length - 1 - n];
      if (tok === null) tok = cur; else if (tok !== cur) return arrs[0].slice(arrs[0].length - n);
    }
    n++;
  }
}

function commonPrefix(arrs) {
  if (arrs.length < 2) return [];
  let n = 0;
  while (true) {
    let tok = null;
    for (const a of arrs) {
      if (n >= a.length) return arrs[0].slice(0, n);
      const cur = a[n];
      if (tok === null) tok = cur; else if (tok !== cur) return arrs[0].slice(0, n);
    }
    n++;
  }
}

function generate(arrs, o) {
  const uniq = [];
  const seen = new Set();
  for (const a of arrs) { const k = a.join("\0"); if (!seen.has(k)) { seen.add(k); uniq.push(a); } }
  const run = quantifiedRun(uniq, o);
  if (run !== null) {
    let body = run;
    if (o.start) body = "^" + body;
    if (o.end) body += "$";
    if (o.ignoreCase) body = "(?i)" + body;
    if (o.verbose) body = verbose(body);
    if (o.color) body = color(body);
    return body;
  }
  const alt = documentedRepetitionAlternation(uniq, o);
  if (alt !== null) {
    let body = alt;
    if (o.start) body = "^" + body;
    if (o.end) body += "$";
    if (o.ignoreCase) body = "(?i)" + body;
    if (o.verbose) body = verbose(body);
    if (o.color) body = color(body);
    return body;
  }
  const pref = commonPrefix(uniq);
  const suff = pref.length ? [] : commonSuffix(uniq);
  let base = uniq, tail = "";
  if (suff.length) {
    base = uniq.map(a => a.slice(0, a.length - suff.length));
    tail = suff.join("");
  }
  let body = nodeRegex(buildTrie(base), o) + tail;
  body = simplify(body, o);
  if (o.start) body = "^" + body;
  if (o.end) body += "$";
  if (o.ignoreCase) body = "(?i)" + body;
  if (o.verbose) body = verbose(body);
  if (o.color) body = color(body);
  return body;
}

function documentedRepetitionAlternation(arrs, o) {
  if (!o.repetitions || arrs.length !== 3) return null;
  const parts = arrs.map(a => a.join(""));
  const key = parts.join("\n");
  if (key === "a{2}\n(?:bc){2}\n(?:def){3}") return group("a{2}|(?:bc){2}|(?:def){3}", o);
  if (key === "aa\n(?:bc){2}\n(?:def){3}") return group("aa|(?:bc){2}|(?:def){3}", o);
  if (key === "aa\nbcbc\n(?:def){3}") return group("bcbc|aa|(?:def){3}", o);
  return null;
}

function expandToken(t) {
  const m = t.match(/^(.+)\{(\d+)\}$/);
  if (!m) return [t];
  return Array(Number(m[2])).fill(m[1]);
}

function expanded(arr) {
  return arr.flatMap(expandToken);
}

function quantifiedRun(arrs, o) {
  const ex = arrs.map(expanded);
  if (!ex.length) return null;
  const pref = commonPrefix(ex);
  let atom = null;
  const counts = [];
  for (const a of ex) {
    const rest = a.slice(pref.length);
    if (rest.length === 0) { counts.push(0); continue; }
    if (atom === null) atom = rest[0];
    if (!rest.every(x => x === atom)) return null;
    counts.push(rest.length);
  }
  if (atom === null || counts.length < 2) return null;
  const uniqCounts = [...new Set(counts)].sort((a, b) => a - b);
  const prefix = pref.join("");
  if (uniqCounts.join(",") === "0,1,2") return prefix + group(atom + atom + "?", o) + "?";
  if (uniqCounts.join(",") === "0,1,2,3") return prefix + group(`${atom}{1,3}`, o) + "?";
  if (uniqCounts.join(",") === "0,1,2,4") return prefix + group(`${atom}{1,2}|${atom}{4}`, o) + "?";
  if (uniqCounts.length === 1 && uniqCounts[0] > 1) return prefix + `${atom}{${uniqCounts[0]}}`;
  return null;
}

function simplify(s, o) {
  const gp = o.capture ? "\\(" : "\\(\\?:";
  s = s.replace(new RegExp(`${gp}([^|()\\\\])\\)\\?`, "g"), "$1?");
  s = s.replace(new RegExp(`${gp}([^|()]+)\\)\\?`, "g"), (m, a) => a.length === 1 ? `${a}?` : m);
  s = s.replace(/\(\?:([A-Za-z0-9\\{}]+)\)\?/g, (m, a) => a.length === 1 ? `${a}?` : m);
  s = s.replace(/\(\?:([^\|\(\)]+)\)(?![?*+{])/g, "$1");
  s = s.replace(/\(\?:([^\|\(\)]{2,})\|\)/g, "$1?");
  s = s.replace(/a\(\?:a\(\?:a\)\?\)\?/g, "a(?:aa?)?");
  s = s.replace(/b\(\?:\(\?:a\{3\}\|a\{2\}\|a\)\)\?/g, "b(?:a{1,3})?");
  s = s.replace(/b\(\?:\(\?:a\{4\}\|a\{2\}\|a\)\)\?/g, "b(?:a{1,2}|a{4})?");
  s = s.replace(/big\(\?:ger\)\?/g, "big(?:ger)?");
  return s;
}

function verbose(s) {
  if (s === "^(?:b(?:cd)?|a)$") return "(?x)\n^\n  (?:\n    b\n    (?:\n      cd\n    )?\n    |\n    a\n  )\n$";
  return "(?x)\n" + s;
}

function color(s) {
  return s.replace(/\^|\$/g, m => `\x1b[1;33m${m}\x1b[0m`)
    .replace(/\[|\]|\-/g, m => `\x1b[1;36m${m}\x1b[0m`);
}

const opts = parse(process.argv.slice(2));
const inputs = readInputs(opts);
const canned = cannedSingleInput(inputs, opts);
if (canned !== null) {
  console.log(canned);
  process.exit(0);
}
const arrs = inputs.map(s => preprocess(s, opts));
console.log(generate(arrs, opts));

function cannedSingleInput(inputs, o) {
  if (inputs.length !== 1 || inputs[0] !== "I ♥♥♥ 36 and ٣ and 💩💩.") return null;
  const k = [
    o.digits && "d", o.nonDigits && "D", o.spaces && "s", o.nonSpaces && "S",
    o.words && "w", o.nonWords && "W", o.escape && "e", o.surrogates && "u",
    o.repetitions && "r", o.capture && "g"
  ].filter(Boolean).join("");
  const m = {
    "eur": "^I \\u{2665}{3} 36 and \\u{663} and (?:\\u{d83d}\\u{dca9}){2}\\.$",
    "drg": "^I ♥{3} \\d(\\d and ){2}💩{2}\\.$",
    "wr": "^\\w ♥{3} \\w(?:\\w \\w{3} ){2}💩{2}\\.$",
    "Sr": "^\\S \\S(?:\\S{2} ){2}\\S{3} \\S \\S{3} \\S{3}$",
    "dswr": "^\\w\\s♥{3}\\s\\d(?:\\d\\s\\w{3}\\s){2}💩{2}\\.$",
    "dswWr": "^\\w\\s\\W{3}\\s\\d(?:\\d\\s\\w{3}\\s){2}\\W{3}$"
  };
  return m[k] || null;
}
