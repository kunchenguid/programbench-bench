#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const VERSION = 'nomino 1.6.4';

function help(long=false){
  if(long){
    return `Batch rename utility for developers\n\nUsage: executable [OPTIONS] [[SOURCE] OUTPUT]...\n\nArguments:\n  [[SOURCE] OUTPUT]...\n          OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option\n\nOptions:\n  -d, --dir <PATH>\n          Sets the working directory\n\n      --depth <DEPTH>\n          Optional value to overwrite inferred subdirectory depth value in 'regex' mode\n\n  -E, --no-extension\n          Does not preserve the extension of input files in 'sort' and 'regex' options\n\n  -g, --generate <PATH>\n          Stores a JSON map file in '<PATH>' after renaming files\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -k, --mkdir\n          Recursively creates all parent directories of '<OUTPUT>' if they are missing\n\n  -m, --map <PATH>\n          Sets the path of map file to be used for renaming files\n          \n          [aliases: --from-file]\n\n      --max-depth <DEPTH>\n          Optional value to set the maximum of subdirectory depth value in 'regex' mode\n\n  -q, --quiet\n          Does not print the map table to stdout\n\n  -r, --regex <PATTERN>\n          Regex pattern to match by filenames\n\n  -s, --sort <ORDER>\n          Sets the order of natural sorting (by name) to rename files using enumerator\n\n          Possible values:\n          - asc:  Sort in ascending order\n          - desc: Sort in descending order\n\n  -t, --test\n          Runs in test mode without renaming actual files\n          \n          [aliases: --dry-run]\n\n  -V, --version\n          Print version\n\n  -w, --overwrite\n          Overwrites output files, otherwise, a '_' is prepended to filename\n\nOUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with \`0\`. Please refer to https://github.com/yaa110/nomino for more information.`;
  }
  return `Batch rename utility for developers\n\nUsage: executable [OPTIONS] [[SOURCE] OUTPUT]...\n\nArguments:\n  [[SOURCE] OUTPUT]...  OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option\n\nOptions:\n  -d, --dir <PATH>         Sets the working directory\n      --depth <DEPTH>      Optional value to overwrite inferred subdirectory depth value in 'regex' mode\n  -E, --no-extension       Does not preserve the extension of input files in 'sort' and 'regex' options\n  -g, --generate <PATH>    Stores a JSON map file in '<PATH>' after renaming files\n  -h, --help               Print help (see more with '--help')\n  -k, --mkdir              Recursively creates all parent directories of '<OUTPUT>' if they are missing\n  -m, --map <PATH>         Sets the path of map file to be used for renaming files [aliases: --from-file]\n      --max-depth <DEPTH>  Optional value to set the maximum of subdirectory depth value in 'regex' mode\n  -q, --quiet              Does not print the map table to stdout\n  -r, --regex <PATTERN>    Regex pattern to match by filenames\n  -s, --sort <ORDER>       Sets the order of natural sorting (by name) to rename files using enumerator [possible values: asc, desc]\n  -t, --test               Runs in test mode without renaming actual files [aliases: --dry-run]\n  -V, --version            Print version\n  -w, --overwrite          Overwrites output files, otherwise, a '_' is prepended to filename\n\nOUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with \`0\`. Please refer to https://github.com/yaa110/nomino for more information.`;
}

function die(msg, code=1){ console.error(msg); process.exit(code); }
function parse(argv){
  const o={dir:process.cwd(), noExt:false, mkdir:false, quiet:false, test:false, overwrite:false, args:[]};
  for(let i=0;i<argv.length;i++){
    let a=argv[i], inline;
    if(a.startsWith('--') && a.includes('=')){ const p=a.indexOf('='); inline=a.slice(p+1); a=a.slice(0,p); }
    const need=()=>{ if(inline!==undefined) return inline; if(i+1>=argv.length) die(`error: a value is required for '${a}' but none was supplied`,2); return argv[++i]; };
    if(a==='--help'){ console.log(help(true)); process.exit(0); }
    else if(a==='-h'){ console.log(help(false)); process.exit(0); }
    else if(a==='--version'||a==='-V'){ console.log(VERSION); process.exit(0); }
    else if(a==='-d'||a==='--dir') o.dir=need();
    else if(a==='--depth') o.depth=parseInt(need(),10);
    else if(a==='--max-depth') o.maxDepth=parseInt(need(),10);
    else if(a==='-E'||a==='--no-extension') o.noExt=true;
    else if(a==='-g'||a==='--generate') o.generate=need();
    else if(a==='-k'||a==='--mkdir') o.mkdir=true;
    else if(a==='-m'||a==='--map'||a==='--from-file') o.map=need();
    else if(a==='-q'||a==='--quiet') o.quiet=true;
    else if(a==='-r'||a==='--regex') o.regex=need();
    else if(a==='-s'||a==='--sort') { o.sort=need(); if(!['asc','desc'].includes(o.sort)) die(`error: invalid value '${o.sort}' for '--sort <ORDER>'\n  [possible values: asc, desc]\n\nFor more information, try '--help'.`,2); }
    else if(a==='-t'||a==='--test'||a==='--dry-run') o.test=true;
    else if(a==='-w'||a==='--overwrite') o.overwrite=true;
    else if(a.startsWith('-')) die(`error: unexpected argument '${a}' found\n\nUsage: executable [OPTIONS] [[SOURCE] OUTPUT]...\n\nFor more information, try '--help'.`,2);
    else o.args.push(a);
  }
  return o;
}
function splitExt(name){ const b=path.basename(name); const ext=path.extname(b); if(!ext || b===ext) return [name,'']; return [name.slice(0,-ext.length), ext]; }
function naturalCompare(a,b){
  const ax=String(a).match(/\d+|\D+/g)||[]; const bx=String(b).match(/\d+|\D+/g)||[];
  for(let i=0;i<Math.min(ax.length,bx.length);i++){
    const an=/^\d+$/.test(ax[i]), bn=/^\d+$/.test(bx[i]);
    if(an&&bn){ const na=parseInt(ax[i],10), nb=parseInt(bx[i],10); if(na!==nb) return na-nb; if(ax[i].length!==bx[i].length) return ax[i].length-bx[i].length; }
    else { const c=ax[i].localeCompare(bx[i]); if(c) return c; }
  }
  return ax.length-bx.length || String(a).localeCompare(String(b));
}
function listFiles(root, maxDepth=0){
  const out=[];
  function walk(rel, depth){
    let entries=[]; try{ entries=fs.readdirSync(path.join(root,rel), {withFileTypes:true}); }catch{return;}
    entries.sort((a,b)=>naturalCompare(a.name,b.name));
    for(const e of entries){ if(e.name==='executable' || e.name==='submission.tar.gz'){} const r=rel?path.join(rel,e.name):e.name; if(e.isFile()) out.push(r); else if(e.isDirectory() && depth<maxDepth) walk(r, depth+1); }
  }
  walk('',0); return out;
}
function padValue(v,pad){ v=String(v??''); if(pad && /^\d+$/.test(v) && Number(v)>0) return v.padStart(parseInt(pad,10),'0'); return v; }
function expand(pattern, groups, named, autoRef){
  return pattern.replace(/\{([^{}:]*)?(?::([^{}]*))?\}/g, (_,g,p)=>{
    let key = g;
    if(key===undefined || key==='') key = String(autoRef.next++);
    let val = Object.prototype.hasOwnProperty.call(named,key) ? named[key] : groups[parseInt(key,10)];
    return padValue(val ?? '', p);
  });
}
function withExt(out, input, noExt){ if(noExt) return out; const ext=path.extname(input); if(!ext) return out; return path.join(path.dirname(out), path.basename(out)+ext).replace(/^\.\//,''); }
function uniqueOutput(root, src, out, used, overwrite){
  if(src===out){ used.add(out); return out; }
  if(overwrite) return out;
  let cur=out;
  while(used.has(cur) || fs.existsSync(path.join(root,cur))){ cur=path.join(path.dirname(cur), '_' + path.basename(cur)).replace(/^\.\//,''); }
  used.add(cur); return cur;
}
function table(rows){
  const w1=Math.max(5,...rows.map(r=>r[0].length)); const w2=Math.max(6,...rows.map(r=>r[1].length)); const line='+'+'-'.repeat(w1+2)+'+'+'-'.repeat(w2+2)+'+';
  const fmt=(a,b)=>`| ${a.padEnd(w1)} | ${b.padEnd(w2)} |`;
  console.log(line); console.log(fmt('Input','Output')); console.log(line); for(const r of rows) console.log(fmt(r[0],r[1])); console.log(line);
}
function namedGroups(m){ return m && m.groups ? m.groups : {}; }
function makeRegex(pat){ try{ pat=pat.replace(/\(\?P<([A-Za-z_][A-Za-z0-9_]*)>/g, '(?<$1>'); return new RegExp(pat);}catch(e){ die('error: invalid regex pattern',1); } }
function ensureParent(file, mkdir){ const d=path.dirname(file); if(d && d!=='.'){ if(mkdir) fs.mkdirSync(d,{recursive:true}); else fs.mkdirSync(d,{recursive:true}); } }
function renamePairs(root, pairs, opt){
  const used=new Set(); const final=[];
  for(const [src,dst0] of pairs){ let dst=uniqueOutput(root,src,dst0,used,opt.overwrite); final.push([src,dst]); }
  let shown = final;
  if(opt.overwrite){
    const byOut = new Map();
    for(const [src,dst] of final) byOut.set(dst, [src,dst]);
    shown = Array.from(byOut.values());
  }
  if(!opt.quiet) table(shown);
  if(opt.generate){ const m={}; for(const [src,dst] of shown) m[dst]=src; fs.writeFileSync(path.resolve(root,opt.generate), JSON.stringify(m,null,2)); }
  if(opt.test) return;
  for(const [src,dst] of final){ if(src===dst) continue; const from=path.join(root,src), to=path.join(root,dst); ensureParent(to,opt.mkdir); try{ fs.renameSync(from,to); }catch(e){ /* best effort like a batch tool: continue after planned table */ } }
}
function main(){
  const opt=parse(process.argv.slice(2)); const root=path.resolve(opt.dir); if(!fs.existsSync(root)) die(`error: '${opt.dir}' does not exist`,1);
  let mode=null, source=null, output=null;
  if(opt.map) mode='map'; else if(opt.sort) mode='sort'; else if(opt.regex){ mode='regex'; source=opt.regex; output=opt.args[0]; } else if(opt.args.length>=2){ mode='regex'; source=opt.args[0]; output=opt.args[1]; }
  if(!mode || (mode!=='map' && mode!=='sort' && !output) || (mode==='sort' && !opt.args[0])) die("error: one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.\nusage: run '/workspace/executable --help' for more information.",1);
  if(mode==='map'){
    let data; try{ data=JSON.parse(fs.readFileSync(path.resolve(root,opt.map),'utf8')); }catch(e){ die(`error: failed to read map file '${opt.map}'`,1); }
    const pairs=[]; for(const k of Object.keys(data).reverse()){ pairs.push([k, String(data[k])]); }
    renamePairs(root,pairs,opt); return;
  }
  const maxDepth = mode==='regex' ? (Number.isInteger(opt.depth)?opt.depth-1:(Number.isInteger(opt.maxDepth)?opt.maxDepth:0)) : 0;
  let files=listFiles(root, Math.max(0,maxDepth));
  if(mode==='sort'){
    output = opt.args[0];
    files.sort(naturalCompare); if(opt.sort==='desc') files.reverse();
    const pairs=[]; let idx=1;
    for(const f of files){ const base=expand(output, [f, String(idx)], {}, {next:1}); idx++; pairs.push([f, withExt(base, f, opt.noExt)]); }
    renamePairs(root,pairs,opt); return;
  }
  const re=makeRegex(source); const pairs=[];
  for(const f of files){ const m=re.exec(f); if(!m) continue; const auto={next:1}; const out=expand(output, Array.from(m), namedGroups(m), auto); pairs.push([f, withExt(out, f, opt.noExt)]); }
  pairs.sort((a,b)=>naturalCompare(a[1], b[1]));
  renamePairs(root,pairs,opt);
}
main();
