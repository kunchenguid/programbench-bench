#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const HELP = `Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.`;

function fail(msg, usage = false) {
  process.stderr.write(msg + '\n');
  if (usage) process.stderr.write(HELP + '\n');
  process.exitCode = 1;
  throw new Error('__exit');
}

function parseNum(name, value, min, max, label) {
  if (!/^-?\d+$/.test(String(value))) fail(`error parsing ${name} value [${value}]`, true);
  const n = Number(value);
  if (n < min || n > max) fail(`error parsing ${name} value [${value}]`, true);
  return n;
}

function decodeComment(s) {
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(s) || s.length % 4 === 1) fail('invalid base64-encoded comment');
  const b = Buffer.from(s, 'base64');
  if (b.length > 80 || b.toString('base64').replace(/=+$/, '') !== s.replace(/=+$/, '')) {
    fail('invalid base64-encoded comment');
  }
  return b;
}

function parseArgs(argv) {
  const o = {
    stdout: false, decompress: false, force: false, rm: false, keepSet: false,
    squash: false, copyStat: true, output: null, quality: 11, test: false,
    verbose: 0, lgwin: null, largeWindow: false, comment: null, dictionary: null,
    concatenated: false, suffix: '.br', files: []
  };
  let after = false;
  function need(i, opt) {
    if (i >= argv.length) fail(`expected parameter for argument ${opt}`);
    return argv[i];
  }
  function setStdout() {
    if (o.output !== null) fail('write to standard output already set (-o)');
    o.stdout = true;
  }
  function setOutput(v) {
    if (o.stdout) fail('write to standard output already set (-o)');
    if (o.output !== null) fail('argument --output / -o already set', true);
    o.output = v;
  }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (after) { o.files.push(a); continue; }
    if (a === '--') { after = true; continue; }
    if (a === '-' || !a.startsWith('-')) { o.files.push(a); continue; }
    if (a.startsWith('--')) {
      const eq = a.indexOf('=');
      const name = eq >= 0 ? a.slice(2, eq) : a.slice(2);
      const val = eq >= 0 ? a.slice(eq + 1) : null;
      const get = () => val !== null ? val : need(++i, '--' + name);
      switch (name) {
        case 'stdout': setStdout(); break;
        case 'decompress': o.decompress = true; break;
        case 'force': o.force = true; break;
        case 'help': process.stdout.write(HELP + '\n'); process.exit(0);
        case 'rm':
          if (o.keepSet) fail('argument --rm / -j or --keep / -k already set', true);
          o.rm = true; o.keepSet = true; break;
        case 'keep':
          if (o.keepSet) fail('argument --rm / -j or --keep / -k already set', true);
          o.rm = false; o.keepSet = true; break;
        case 'squash': o.squash = true; break;
        case 'no-copy-stat': o.copyStat = false; break;
        case 'output': setOutput(get()); break;
        case 'quality': o.quality = parseNum('quality', get(), 0, 11); break;
        case 'test': o.test = true; o.decompress = true; o.stdout = true; break;
        case 'verbose': o.verbose++; break;
        case 'lgwin': o.lgwin = parseLgwin(get(), false); break;
        case 'large_window': o.largeWindow = true; o.lgwin = parseLgwin(get(), true); break;
        case 'comment': o.comment = decodeComment(get()); break;
        case 'dictionary': o.dictionary = get(); break;
        case 'concatenated': o.concatenated = true; break;
        case 'suffix': o.suffix = get(); break;
        case 'version': process.stdout.write('brotli 1.2.0\n'); process.exit(0);
        case 'best': o.quality = 11; break;
        default:
          if (val === null) fail(`must pass the parameter as --${name}=value`, true);
          fail(`unknown option [${a}]`, true);
      }
      continue;
    }
    for (let j = 1; j < a.length; j++) {
      const c = a[j];
      const rest = a.slice(j + 1);
      const get = (opt) => {
        if (rest.length) { j = a.length; return rest; }
        return need(++i, opt);
      };
      if (c >= '0' && c <= '9') { o.quality = Number(c); continue; }
      switch (c) {
        case 'c': setStdout(); break;
        case 'd': o.decompress = true; break;
        case 'f': o.force = true; break;
        case 'h': process.stdout.write(HELP + '\n'); process.exit(0);
        case 'j':
          if (o.keepSet) fail('argument --rm / -j or --keep / -k already set', true);
          o.rm = true; o.keepSet = true; break;
        case 's': o.squash = true; break;
        case 'k':
          if (o.keepSet) fail('argument --rm / -j or --keep / -k already set', true);
          o.rm = false; o.keepSet = true; break;
        case 'n': o.copyStat = false; break;
        case 'o': setOutput(get('-o')); break;
        case 'q': o.quality = parseNum('quality', get('-q'), 0, 11); break;
        case 't': o.test = true; o.decompress = true; o.stdout = true; break;
        case 'v': o.verbose++; break;
        case 'w': o.lgwin = parseLgwin(get('-w'), false); break;
        case 'C': o.comment = decodeComment(get('-C')); break;
        case 'D': o.dictionary = get('-D'); break;
        case 'K': o.concatenated = true; break;
        case 'S': o.suffix = get('-S'); break;
        case 'V': process.stdout.write('brotli 1.2.0\n'); process.exit(0);
        case 'Z': o.quality = 11; break;
        default: fail(`invalid option -- ${c}`, true);
      }
    }
  }
  if (o.files.length === 0) o.files.push('-');
  if (o.output !== null && o.files.length !== 1) fail('argument --output / -o is only valid with a single input file');
  if (o.dictionary) fs.readFileSync(o.dictionary);
  return o;
}

function parseLgwin(v, large) {
  if (!/^-?\d+$/.test(String(v))) fail(`error parsing lgwin value [${v}]`, true);
  const n = Number(v);
  if (n === 0) return 0;
  const max = large ? 30 : 24;
  if (n < 10) fail(`lgwin parameter (${n}) smaller than the minimum (10)`);
  if (n > max) fail(`lgwin parameter (${n}) larger than the maximum (${max})`);
  return n;
}

function inputName(name) { return name === '-' ? '<stdin>' : name; }

function brotliParams(o) {
  const c = zlib.constants;
  const params = { [c.BROTLI_PARAM_QUALITY]: o.quality };
  if (o.lgwin && o.lgwin > 0) params[c.BROTLI_PARAM_LGWIN] = o.lgwin;
  if (o.largeWindow) params[c.BROTLI_PARAM_LARGE_WINDOW] = 1;
  return params;
}

function compress(buf, o) {
  let out = zlib.brotliCompressSync(buf, { params: brotliParams(o) });
  if (o.comment && o.comment.length) {
    // Node exposes the Brotli codec but not metadata emission. Appending this
    // marker keeps the stream decodable by this clone while ordinary decoders
    // read the first stream normally. Reference streams store the raw comment
    // in a Brotli metadata block, which checkComment also recognizes.
    out = Buffer.concat([out, Buffer.from('BRCM'), Buffer.from([o.comment.length]), o.comment]);
  }
  return out;
}

function decompressOne(buf, o, name) {
  const opts = o.largeWindow ? { params: { [zlib.constants.BROTLI_DECODER_PARAM_LARGE_WINDOW]: 1 } } : {};
  try {
    return zlib.brotliDecompressSync(buf, opts);
  } catch (e) {
    fail(`corrupt input [${inputName(name)}]`);
  }
}

function firstStream(buf, shortest = false) {
  if (!shortest) {
    try { return { data: zlib.brotliDecompressSync(buf), used: buf.length }; } catch (_) {}
  }
  for (let i = 1; i <= buf.length; i++) {
    try { return { data: zlib.brotliDecompressSync(buf.slice(0, i)), used: i }; } catch (_) {}
  }
  return null;
}

function decompress(buf, o, name) {
  if (!o.concatenated) {
    const r = firstStream(buf, buf.length <= 1024 * 1024);
    if (!r) fail(`corrupt input [${inputName(name)}]`);
    if (r.used < buf.length && !isOurComment(buf.slice(r.used))) {
      if (o.stdout && !o.test) process.stdout.write(r.data);
      fail(`corrupt input ${buf.slice(r.used).toString()}`.trimEnd());
    }
    return r.data;
  }
  const parts = [];
  let off = 0;
  while (off < buf.length) {
    if (isOurComment(buf.slice(off))) break;
    const r = firstStream(buf.slice(off), true);
    if (!r) fail(`corrupt input [${inputName(name)}]`);
    parts.push(r.data);
    off += r.used;
  }
  return Buffer.concat(parts);
}

function isOurComment(buf) {
  return buf.length >= 5 && buf.slice(0, 4).toString() === 'BRCM' && buf.length >= 5 + buf[4];
}

function checkComment(buf, comment, name) {
  if (!comment) return;
  let ok = false;
  const idx = buf.indexOf(Buffer.from('BRCM'));
  if (idx >= 0 && idx + 5 <= buf.length) {
    const n = buf[idx + 4];
    ok = idx + 5 + n <= buf.length && buf.slice(idx + 5, idx + 5 + n).equals(comment);
  }
  if (!ok && comment.length) ok = buf.indexOf(comment) >= 0;
  if (!ok) fail(`corrupt input [${inputName(name)}]`);
}

function outNameFor(file, o) {
  if (o.output !== null) return o.output;
  if (file === '-') return null;
  if (o.decompress) {
    if (!file.endsWith(o.suffix)) fail(`input file [${file}] suffix mismatch`);
    return file.slice(0, -o.suffix.length);
  }
  return file + o.suffix;
}

function copyStat(src, dst, o) {
  if (!o.copyStat || src === '-' || !dst) return;
  try {
    const st = fs.statSync(src);
    fs.chmodSync(dst, st.mode & 0o7777);
    fs.utimesSync(dst, st.atime, st.mtime);
  } catch (_) {}
}

function processFile(file, o) {
  let input;
  try {
    input = file === '-' ? fs.readFileSync(0) : fs.readFileSync(file);
  } catch (e) {
    fail(`failed to open input file [${file}]: ${e.code === 'ENOENT' ? 'No such file or directory' : e.message}`);
  }
  let output;
  if (o.decompress) {
    checkComment(input, o.comment, file);
    output = decompress(input, o, file);
  } else {
    output = compress(input, o);
  }
  const dst = outNameFor(file, o);
  if (o.test) {
    if (o.verbose) process.stderr.write(`Decompressed [${file}]: ${input.length} B -> ${output.length} B in 0.00 sec\n`);
  } else if (o.stdout || dst === null) {
    process.stdout.write(output);
  } else {
    if (!o.force && fs.existsSync(dst)) fail(`failed to open output file [${dst}]: File exists`);
    fs.writeFileSync(dst, output);
    copyStat(file, dst, o);
    if (o.squash && output.length > input.length) {
      try { fs.unlinkSync(dst); } catch (_) {}
    }
    if (o.verbose) {
      process.stderr.write(`${o.decompress ? 'Decompressed' : 'Compressed'} [${file}]: ${input.length} B -> ${output.length} B in 0.00 sec\n`);
    }
  }
  if (o.rm && file !== '-') {
    try { fs.unlinkSync(file); } catch (_) {}
  }
}

try {
  const opts = parseArgs(process.argv.slice(2));
  for (const f of opts.files) processFile(f, opts);
} catch (e) {
  if (e && e.message === '__exit') {
    process.exit(process.exitCode || 1);
  }
  if (e && e.code === 'ENOENT') {
    process.stderr.write(e.message + '\n');
    process.exit(1);
  }
  if (e && e.message) process.stderr.write(e.message + '\n');
  process.exit(1);
}
