#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const HELP = `Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.`;

function die(msg, usage = false) {
  if (msg) process.stderr.write(msg + '\n');
  if (usage) process.stderr.write(HELP + '\n');
  process.exit(1);
}

function parseIntStrict(s) {
  if (!/^-?\d+$/.test(String(s))) return null;
  return Number(s);
}

function readStdin() {
  return fs.readFileSync(0);
}

function writeAll(fd, buf) {
  let off = 0;
  while (off < buf.length) off += fs.writeSync(fd, buf, off, buf.length - off);
}

function parseArgs(argv) {
  const o = {
    stdout: false, decompress: false, force: false, rm: false, keep: true,
    copyStat: true, output: null, quality: 11, test: false, verbose: false,
    lgwin: 24, largeWindow: null, comment: null, dictionary: null,
    concatenated: false, suffix: '.br', files: []
  };
  const seen = new Set();
  let after = false;

  function setOnce(key, val, label) {
    if (seen.has(key)) die(`argument ${label} already set`, true);
    seen.add(key);
    o[key] = val;
  }
  function needValue(argv, idx, opt) {
    if (idx + 1 >= argv.length) die(`expected parameter for argument ${opt}`, true);
    return argv[idx + 1];
  }
  function setQuality(v) {
    const n = parseIntStrict(v);
    if (n === null || n < 0 || n > 11) die(`error parsing quality value [${v}]`);
    o.quality = n;
  }
  function setLgwin(v, large) {
    const n = parseIntStrict(v);
    if (n === null) die(`error parsing lgwin value [${v}]`);
    const min = large ? 10 : 10, max = large ? 30 : 24;
    if (n !== 0 && n < min) die(`lgwin parameter (${n}) smaller than the minimum (${min})`, true);
    if (n > max) die(`lgwin parameter (${n}) larger than the maximum (${max})`, true);
    if (large) o.largeWindow = n; else o.lgwin = n;
  }

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (after) { o.files.push(a); continue; }
    if (a === '--') { after = true; continue; }
    if (a === '-' || !a.startsWith('-')) { o.files.push(a); continue; }

    if (a.startsWith('--')) {
      let name = a, value = null;
      const eq = a.indexOf('=');
      if (eq >= 0) { name = a.slice(0, eq); value = a.slice(eq + 1); }
      const takes = new Set(['--output','--quality','--lgwin','--large_window','--comment','--dictionary','--suffix']);
      if (value === null && takes.has(name)) {
        value = needValue(argv, i, name);
        i++;
      } else if (value === null && !['--stdout','--decompress','--force','--help','--rm','--keep','--no-copy-stat','--test','--verbose','--concatenated','--version','--best'].includes(name)) {
        die(`must pass the parameter as ${name}=value`, true);
      }
      switch (name) {
        case '--stdout': setOnce('stdout', true, '--stdout / -c'); break;
        case '--decompress': setOnce('decompress', true, '--decompress / -d'); break;
        case '--force': setOnce('force', true, '--force / -f'); break;
        case '--help': process.stderr.write(HELP + '\n'); process.exit(0);
        case '--rm': o.rm = true; o.keep = false; break;
        case '--keep': o.rm = false; o.keep = true; break;
        case '--no-copy-stat': o.copyStat = false; break;
        case '--output': setOnce('output', value, '--output / -o'); break;
        case '--quality': setQuality(value); break;
        case '--test': setOnce('test', true, '--test / -t'); o.decompress = true; o.stdout = true; break;
        case '--verbose': setOnce('verbose', true, '--verbose / -v'); break;
        case '--lgwin': setLgwin(value, false); break;
        case '--large_window': setLgwin(value, true); break;
        case '--comment': o.comment = Buffer.from(value, 'base64'); if (o.comment.length > 80) die('comment too long'); break;
        case '--dictionary': o.dictionary = value; break;
        case '--concatenated': o.concatenated = true; break;
        case '--suffix': setOnce('suffix', value, '--suffix / -S'); break;
        case '--version': process.stdout.write('brotli 1.2.0\n'); process.exit(0);
        case '--best': o.quality = 11; break;
        default: die(`unknown option: ${name}`, true);
      }
      continue;
    }

    for (let j = 1; j < a.length; j++) {
      const ch = a[j];
      const rest = a.slice(j + 1);
      if (/[0-9]/.test(ch)) { setQuality(ch); continue; }
      switch (ch) {
        case 'c': setOnce('stdout', true, '--stdout / -c'); break;
        case 'd': setOnce('decompress', true, '--decompress / -d'); break;
        case 'f': setOnce('force', true, '--force / -f'); break;
        case 'h': process.stderr.write(HELP + '\n'); process.exit(0);
        case 'j': o.rm = true; o.keep = false; break;
        case 's': setOnce('squash', true, '--squash / -s'); o.squash = true; break;
        case 'k': o.rm = false; o.keep = true; break;
        case 'n': o.copyStat = false; break;
        case 'o':
        case 'q':
        case 'w':
        case 'C':
        case 'D':
        case 'S': {
          let val = rest;
          if (!val) { val = needValue(argv, i, '-' + ch); i++; }
          if (ch === 'o') setOnce('output', val, '--output / -o');
          if (ch === 'q') setQuality(val);
          if (ch === 'w') setLgwin(val, false);
          if (ch === 'C') { o.comment = Buffer.from(val, 'base64'); if (o.comment.length > 80) die('comment too long'); }
          if (ch === 'D') o.dictionary = val;
          if (ch === 'S') setOnce('suffix', val, '--suffix / -S');
          j = a.length;
          break;
        }
        case 't': setOnce('test', true, '--test / -t'); o.decompress = true; o.stdout = true; break;
        case 'v': setOnce('verbose', true, '--verbose / -v'); break;
        case 'K': o.concatenated = true; break;
        case 'V': process.stdout.write('brotli 1.2.0\n'); process.exit(0);
        case 'Z': o.quality = 11; break;
        default: die(`unknown option: -${ch}`, true);
      }
    }
  }
  if (o.files.length === 0) o.files.push('-');
  if (o.output && o.files.length !== 1) die('argument --output / -o is only allowed with a single input file');
  return o;
}

function compress(buf, o) {
  const params = { [zlib.constants.BROTLI_PARAM_QUALITY]: o.quality };
  const win = o.largeWindow ?? o.lgwin;
  if (win && win !== 0) params[zlib.constants.BROTLI_PARAM_LGWIN] = Math.min(win, 24);
  return zlib.brotliCompressSync(buf, { params });
}

function decodeOne(buf, start) {
  for (let end = start + 1; end <= buf.length; end++) {
    try {
      return { data: zlib.brotliDecompressSync(buf.subarray(start, end)), end };
    } catch (_) {
      // Keep looking for the Brotli stream end marker. This path is mainly for
      // concatenated inputs; normal single-member files usually succeed at EOF.
    }
  }
  throw new Error('Decompression failed');
}

function decompress(buf, concatenated) {
  const first = decodeOne(buf, 0);
  if (!concatenated) return { data: first.data, trailing: first.end < buf.length };
  const chunks = [first.data];
  let pos = first.end;
  while (pos < buf.length) {
    const next = decodeOne(buf, pos);
    chunks.push(next.data);
    pos = next.end;
  }
  return { data: Buffer.concat(chunks), trailing: false };
}

function outNameFor(file, o) {
  if (o.output) return o.output;
  if (o.stdout || o.test) return null;
  if (o.decompress) {
    if (!file.endsWith(o.suffix)) die(`input file [${file}] suffix mismatch`);
    return file.slice(0, -o.suffix.length);
  }
  return file + o.suffix;
}

function readInput(file) {
  if (file === '-') return { data: readStdin(), label: 'con', stat: null };
  try {
    return { data: fs.readFileSync(file), label: file, stat: fs.statSync(file) };
  } catch (e) {
    const reason = e.code === 'ENOENT' ? 'No such file or directory' : e.message;
    die(`failed to open input file [${file}]: ${reason}`);
  }
}

function writeOutput(file, data, out, o, srcStat) {
  if (out === null) {
    if (!o.test) writeAll(1, data);
    return;
  }
  if (!o.force && fs.existsSync(out)) die(`failed to open output file [${out}]: File exists`);
  fs.writeFileSync(out, data);
  if (o.copyStat && srcStat) {
    try { fs.chmodSync(out, srcStat.mode & 0o7777); } catch (_) {}
    try { fs.utimesSync(out, srcStat.atime, srcStat.mtime); } catch (_) {}
  }
}

function fmtBytes(n) {
  return `${n} B`;
}

function main() {
  const o = parseArgs(process.argv.slice(2));
  if (o.dictionary) {
    try { fs.accessSync(o.dictionary, fs.constants.R_OK); } catch (e) {
      const reason = e.code === 'ENOENT' ? 'No such file or directory' : e.message;
      die(`failed to open dictionary file [${o.dictionary}]: ${reason}`);
    }
  }
  let ok = true;
  for (const file of o.files) {
    const start = Date.now();
    try {
      const inp = readInput(file);
      const out = outNameFor(file, o);
      const decoded = o.decompress ? decompress(inp.data, o.concatenated) : null;
      const result = o.decompress ? decoded.data : compress(inp.data, o);
      if (o.squash && out && !o.decompress && result.length > inp.data.length) {
        try { fs.unlinkSync(out); } catch (_) {}
      } else {
        writeOutput(file, result, out, o, inp.stat);
      }
      if (o.rm && file !== '-') {
        try { fs.unlinkSync(file); } catch (_) {}
      }
      if (o.verbose) {
        const verb = o.decompress ? 'Decompressed' : 'Compressed';
        const elapsed = ((Date.now() - start) / 1000).toFixed(2);
        process.stderr.write(`${verb} [${inp.label}]: ${fmtBytes(inp.data.length)} -> ${fmtBytes(result.length)} in ${elapsed} sec\n`);
      }
      if (o.decompress && o.comment && o.comment.length && inp.data.indexOf(o.comment) < 0) {
        process.stderr.write(`corrupt input [${file === '-' ? 'con' : file}]\n`);
        ok = false;
      }
      if (decoded && decoded.trailing) {
        process.stderr.write(`corrupt input [${file === '-' ? 'con' : file}]\n`);
        ok = false;
      }
    } catch (e) {
      ok = false;
      if (e && e.code === 'ERR__ERROR_FORMAT_CL_SPACE') {
        process.stderr.write(`corrupt input [${file === '-' ? 'con' : file}]\n`);
      } else if (e && /Decompression failed|brotli|unexpected end of file/i.test(String(e.message || e))) {
        process.stderr.write(`corrupt input [${file === '-' ? 'con' : file}]\n`);
      } else if (e && e.__printed) {
      } else {
        process.stderr.write((e && e.message ? e.message : String(e)) + '\n');
      }
    }
  }
  process.exit(ok ? 0 : 1);
}

main();
