#!/usr/bin/env node
"use strict";

const fs = require("fs");

const REL = "Rel. 9.9.0, September 15th, 2026";
const A0 = 6378137.0;
const E2_WGS84 = 0.0066943799901413165;
const DEG = Math.PI / 180;
const RAD = 180 / Math.PI;

const PROJ_LIST = [
  ["adams_hemi", "Adams Hemisphere in a Square"],
  ["adams_ws1", "Adams World in a Square I"],
  ["adams_ws2", "Adams World in a Square II"],
  ["aea", "Albers Equal Area"],
  ["aeqd", "Azimuthal Equidistant"],
  ["affine", "Affine transformation"],
  ["airy", "Airy"],
  ["aitoff", "Aitoff"],
  ["alsk", "Modified Stereographic of Alaska"],
  ["apian", "Apian Globular I"],
  ["august", "August Epicycloidal"],
  ["axisswap", "Axis ordering"],
  ["bacon", "Bacon Globular"],
  ["bertin1953", "Bertin 1953"],
  ["bipc", "Bipolar conic of western hemisphere"],
  ["boggs", "Boggs Eumorphic"],
  ["bonne", "Bonne (Werner lat_1=90)"],
  ["calcofi", "Cal Coop Ocean Fish Invest Lines/Stations"],
  ["cart", "Geodetic/cartesian conversions"],
  ["cass", "Cassini"],
  ["cc", "Central Cylindrical"],
  ["ccon", "Central Conic"],
  ["cea", "Equal Area Cylindrical"],
  ["chamb", "Chamberlin Trimetric"],
  ["collg", "Collignon"],
  ["col_urban", "Colombia Urban"],
  ["comill", "Compact Miller"],
  ["crast", "Craster Parabolic (Putnins P4)"],
  ["defmodel", "Deformation model"],
  ["deformation", "Kinematic grid shift"],
  ["denoy", "Denoyer Semi-Elliptical"],
  ["airocean", "Airocean"],
  ["eck1", "Eckert I"],
  ["eck2", "Eckert II"],
  ["eck3", "Eckert III"],
  ["eck4", "Eckert IV"],
  ["eck5", "Eckert V"],
  ["eck6", "Eckert VI"],
  ["eqearth", "Equal Earth"],
  ["eqc", "Equidistant Cylindrical (Plate Carree)"],
  ["eqdc", "Equidistant Conic"],
  ["euler", "Euler"],
  ["etmerc", "Extended Transverse Mercator"],
  ["fahey", "Fahey"],
  ["fouc", "Foucaut"],
  ["fouc_s", "Foucaut Sinusoidal"],
  ["gall", "Gall (Gall Stereographic)"],
  ["geoc", "Geocentric Latitude"],
  ["geogoffset", "Geographic Offset"],
  ["geos", "Geostationary Satellite View"],
  ["gins8", "Ginsburg VIII (TsNIIGAiK)"],
  ["gn_sinu", "General Sinusoidal Series"],
  ["gnom", "Gnomonic"],
  ["goode", "Goode Homolosine"],
  ["gridshift", "Generic grid shift"],
  ["gs48", "Modified Stereographic of 48 U.S."],
  ["gs50", "Modified Stereographic of 50 U.S."],
  ["guyou", "Guyou"],
  ["hammer", "Hammer & Eckert-Greifendorff"],
  ["hatano", "Hatano Asymmetrical Equal Area"],
  ["healpix", "HEALPix"],
  ["igh", "Interrupted Goode Homolosine"],
  ["imw_p", "International Map of the World Polyconic"],
  ["isea", "Icosahedral Snyder Equal Area"],
  ["kav5", "Kavraisky V"],
  ["kav7", "Kavraisky VII"],
  ["krovak", "Krovak"],
  ["labrd", "Laborde"],
  ["laea", "Lambert Azimuthal Equal Area"],
  ["lagrng", "Lagrange"],
  ["larr", "Larrivee"],
  ["lask", "Laskowski"],
  ["latlong", "Lat/long (Geodetic alias)"],
  ["latlon", "Lat/long (Geodetic alias)"],
  ["lonlat", "Lat/long (Geodetic)"],
  ["longlat", "Lat/long (Geodetic alias)"],
  ["lcc", "Lambert Conformal Conic"],
  ["lcca", "Lambert Conformal Conic Alternative"],
  ["leac", "Lambert Equal Area Conic"],
  ["lee_os", "Lee Oblated Stereographic"],
  ["loxim", "Loximuthal"],
  ["lsat", "Space oblique for LANDSAT"],
  ["mbt_s", "McBryde-Thomas Flat-Polar Sine"],
  ["mbt_fps", "McBryde-Thomas Flat-Pole Sine (No. 2)"],
  ["mbtfpp", "McBride-Thomas Flat-Polar Parabolic"],
  ["mbtfpq", "McBryde-Thomas Flat-Polar Quartic"],
  ["mbtfps", "McBryde-Thomas Flat-Polar Sinusoidal"],
  ["merc", "Mercator"],
  ["mill", "Miller Cylindrical"],
  ["misrsom", "Space oblique for MISR"],
  ["moll", "Mollweide"],
  ["molobadekas", "Molodensky-Badekas transform"],
  ["molodensky", "Molodensky transform"],
  ["murd1", "Murdoch I"],
  ["murd2", "Murdoch II"],
  ["murd3", "Murdoch III"],
  ["natearth", "Natural Earth"],
  ["natearth2", "Natural Earth 2"],
  ["nell", "Nell"],
  ["nell_h", "Nell-Hammer"],
  ["nicol", "Nicolosi Globular"],
  ["nsper", "Near-sided perspective"],
  ["nzmg", "New Zealand Map Grid"],
  ["ob_tran", "General Oblique Transformation"],
  ["ocea", "Oblique Cylindrical Equal Area"],
  ["oea", "Oblated Equal Area"],
  ["omerc", "Oblique Mercator"],
  ["ortel", "Ortelius Oval"],
  ["ortho", "Orthographic"],
  ["patterson", "Patterson Cylindrical"],
  ["pipeline", "Transformation pipeline manager"],
  ["poly", "Polyconic (American)"],
  ["pop", "Retrieve coordinate value from pipeline stack"],
  ["push", "Save coordinate value on pipeline stack"],
  ["putp1", "Putnins P1"],
  ["putp2", "Putnins P2"],
  ["putp3", "Putnins P3"],
  ["putp3p", "Putnins P3'"],
  ["putp4p", "Putnins P4'"],
  ["putp5", "Putnins P5"],
  ["putp5p", "Putnins P5'"],
  ["putp6", "Putnins P6"],
  ["putp6p", "Putnins P6'"],
  ["qua_aut", "Quartic Authalic"],
  ["robin", "Robinson"],
  ["rouss", "Roussilhe Stereographic"],
  ["rpoly", "Rectangular Polyconic"],
  ["sch", "Spherical Cross-track Height"],
  ["set", "Set coordinate value"],
  ["sinu", "Sinusoidal (Sanson-Flamsteed)"],
  ["somerc", "Swiss. Obl. Mercator"],
  ["stere", "Stereographic"],
  ["sterea", "Oblique Stereographic Alternative"],
  ["gstmerc", "Gauss-Schreiber Transverse Mercator"],
  ["tcc", "Transverse Central Cylindrical"],
  ["times", "Times"],
  ["tissot", "Tissot"],
  ["tmerc", "Transverse Mercator"],
  ["tobmerc", "Tobler-Mercator"],
  ["topocentric", "Geocentric/Topocentric conversion"],
  ["tpeqd", "Two Point Equidistant"],
  ["tpers", "Tilted perspective"],
  ["unitconvert", "Unit conversion"],
  ["ups", "Universal Polar Stereographic"],
  ["urm5", "Urmaev V"],
  ["urmfps", "Urmaev Flat-Polar Sinusoidal"],
  ["utm", "Universal Transverse Mercator (UTM)"],
  ["vandg", "van der Grinten (I)"],
  ["vandg2", "van der Grinten II"],
  ["vandg3", "van der Grinten III"],
  ["vandg4", "van der Grinten IV"],
  ["vertoffset", "Vertical Offset and Slope"],
  ["vitk1", "Vitkovsky I"],
  ["vgridshift", "Vertical grid shift"],
  ["wag1", "Wagner I (Kavrayskiy VI)"],
  ["wag2", "Wagner II"],
  ["wag3", "Wagner III"],
  ["wag4", "Wagner IV"],
  ["wag5", "Wagner V"],
  ["wag6", "Wagner VI"],
  ["wag7", "Wagner VII"],
  ["webmerc", "Web Mercator / Pseudo Mercator"],
  ["weren", "Werenskiold I"],
  ["wink1", "Winkel I"],
  ["wink2", "Winkel II"],
  ["wintri", "Winkel Tripel"],
  ["xyzgridshift", "Geocentric grid shift"],
];

const ELLPS = [
  ["MERIT", "a=6378137.0      rf=298.257       MERIT 1983"],
  ["SGS85", "a=6378136.0      rf=298.257       Soviet Geodetic System 85"],
  ["GRS80", "a=6378137.0      rf=298.257222101 GRS 1980(IUGG, 1980)"],
  ["IAU76", "a=6378140.0      rf=298.257       IAU 1976"],
  ["airy", "a=6377563.396    rf=299.3249646   Airy 1830"],
  ["APL4.9", "a=6378137.0      rf=298.25        Appl. Physics. 1965"],
  ["NWL9D", "a=6378145.0      rf=298.25        Naval Weapons Lab., 1965"],
  ["mod_airy", "a=6377340.189    b=6356034.446    Modified Airy"],
  ["bessel", "a=6377397.155    rf=299.1528128   Bessel 1841"],
  ["clrk66", "a=6378206.4      b=6356583.8      Clarke 1866"],
  ["WGS84", "a=6378137.0      rf=298.257223563 WGS 84"],
  ["sphere", "a=6370997.0      b=6370997.0      Normal Sphere (r=6370997)"],
];

const UNITS = [
  ["mm", "0.001                millimetre"],
  ["cm", "0.01                 centimetre"],
  ["m", "1                    metre"],
  ["ft", "0.3048               foot"],
  ["us-ft", "0.304800609601219    US survey foot"],
  ["kmi", "1852                 nautical mile"],
  ["km", "1000                 kilometre"],
  ["mi", "1609.344             Statute mile"],
  ["yd", "0.9144               yard"],
];

function fatal(msg, code = 1) {
  process.stdout.write(`${REL}\n<executable>: \n${msg}\nprogram abnormally terminated\n`);
  process.exit(code);
}

function usage() {
  process.stdout.write(`${REL}\nusage: executable [-bdeEfiIlmorsStTvVwW [args]] [+opt[=arg] ...] [file ...]\n`);
}

function parseArgs(argv) {
  const st = {
    opts: {}, files: [], inverse: false, echo: false, rin: false, sout: false,
    fmt: null, decimals: 2, mult: 1, err: "*", verbose: false,
  };
  for (let i = 0; i < argv.length; i++) {
    let a = argv[i];
    if (a.startsWith("--")) fatal(`invalid option: --`);
    if (a.startsWith("+")) {
      const s = a.slice(1);
      const j = s.indexOf("=");
      st.opts[j < 0 ? s : s.slice(0, j)] = j < 0 ? true : s.slice(j + 1);
      continue;
    }
    if (a.startsWith("-") && a.length > 1) {
      const chars = a.slice(1);
      if (chars === "l") { printProjList(); process.exit(0); }
      if (chars.startsWith("l") && chars.length > 1) {
        const what = chars.slice(1);
        if (what === "p") { printProjList(); process.exit(0); }
        if (what === "e") { printEllps(); process.exit(0); }
        if (what === "u") { printUnits(); process.exit(0); }
        fatal(`invalid list option: ${chars}`);
      }
      for (let k = 0; k < chars.length; k++) {
        const c = chars[k];
        if (c === "I" || c === "i") st.inverse = true;
        else if (c === "E") st.echo = true;
        else if (c === "r") st.rin = true;
        else if (c === "s") st.sout = true;
        else if (c === "V") st.verbose = true;
        else if (c === "f" || c === "m" || c === "d" || c === "e" || c === "w" || c === "W") {
          let val = chars.slice(k + 1);
          if (!val) val = argv[++i];
          if (val == null) fatal(`missing argument for -${c}`);
          if (c === "f") st.fmt = val;
          else if (c === "m") st.mult = Number(val);
          else if (c === "d") st.decimals = Number(val);
          else if (c === "e") st.err = val;
          k = chars.length;
        } else if ("bdoStTv".includes(c)) {
          // Accepted for compatibility; most affect binary/geodetic formatting in full PROJ.
        } else {
          fatal(`invalid option: -${c}`);
        }
      }
    } else {
      st.files.push(a);
    }
  }
  return st;
}

function printProjList() {
  for (const [id, desc] of PROJ_LIST) console.log(`${id} : ${desc}`);
}
function printEllps() {
  for (const [id, rest] of ELLPS) console.log(`${id.padStart(9)} ${rest}`);
}
function printUnits() {
  for (const [id, rest] of UNITS) console.log(`${id.padStart(12)} ${rest}`);
}

function numOpt(o, name, def) {
  if (o[name] === undefined || o[name] === true) return def;
  return Number(o[name]);
}

function makeCtx(opts) {
  let a = A0, e2 = E2_WGS84;
  if (opts.R !== undefined) { a = Number(opts.R); e2 = 0; }
  if (opts.a !== undefined) a = Number(opts.a);
  if (opts.b !== undefined) {
    const b = Number(opts.b);
    e2 = Math.max(0, 1 - (b * b) / (a * a));
  }
  if (opts.ellps === "sphere") e2 = 0;
  if (opts.es !== undefined) e2 = Number(opts.es);
  const e = Math.sqrt(Math.max(0, e2));
  return {
    proj: String(opts.proj || ""),
    a, e2, e,
    k0: numOpt(opts, "k_0", numOpt(opts, "k", 1)),
    x0: numOpt(opts, "x_0", 0),
    y0: numOpt(opts, "y_0", 0),
    lon0: numOpt(opts, "lon_0", 0) * DEG,
    lat0: numOpt(opts, "lat_0", 0) * DEG,
    lat1: numOpt(opts, "lat_1", 0) * DEG,
    lat2: numOpt(opts, "lat_2", 0) * DEG,
    latTs: numOpt(opts, "lat_ts", 0) * DEG,
    zone: opts.zone ? Number(opts.zone) : null,
    south: opts.south !== undefined,
  };
}

function init(st) {
  const p = st.opts.proj;
  if (!p) {
    usage();
    process.exit(0);
  }
  if (["longlat", "latlong", "latlon", "lonlat"].includes(String(p))) {
    fatal("can't initialize operations that produce angular output coordinates", 3);
  }
  const supported = new Set(["merc", "webmerc", "eqc", "utm", "tmerc", "sinu", "moll", "eck4", "cea", "laea", "aeqd", "ortho", "gnom", "stere", "lcc", "aea"]);
  if (!supported.has(String(p))) {
    process.stdout.write(`proj_create: unrecognized format / unknown name\n`);
    fatal("projection initialization failure\ncause: Unknown error (code 2)", 3);
  }
  const ctx = makeCtx(st.opts);
  if (ctx.proj === "utm") {
    ctx.k0 = 0.9996;
    ctx.lon0 = ((ctx.zone || 31) * 6 - 183) * DEG;
    ctx.x0 = 500000;
    ctx.y0 = ctx.south ? 10000000 : 0;
  }
  return ctx;
}

function adjlon(x) {
  x = (x + Math.PI) % (2 * Math.PI);
  if (x < 0) x += 2 * Math.PI;
  return x - Math.PI;
}

function mlfn(phi, a, e2) {
  const e4 = e2 * e2, e6 = e4 * e2;
  return a * ((1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi
    - (3 * e2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * Math.sin(2 * phi)
    + (15 * e4 / 256 + 45 * e6 / 1024) * Math.sin(4 * phi)
    - (35 * e6 / 3072) * Math.sin(6 * phi));
}

function invMlfn(M, a, e2) {
  let phi = M / (a * (1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 * e2 * e2 / 256));
  for (let i = 0; i < 8; i++) {
    const d = (mlfn(phi, a, e2) - M) / (a * (1 - e2) / Math.pow(1 - e2 * Math.sin(phi) ** 2, 1.5));
    phi -= d;
    if (Math.abs(d) < 1e-12) break;
  }
  return phi;
}

function tmForward(lon, lat, c) {
  const a = c.a, e2 = c.e2, ep2 = e2 / (1 - e2);
  const sin = Math.sin(lat), cos = Math.cos(lat), tan = Math.tan(lat);
  const N = a / Math.sqrt(1 - e2 * sin * sin);
  const T = tan * tan, C = ep2 * cos * cos, A = adjlon(lon - c.lon0) * cos;
  const M = mlfn(lat, a, e2) - mlfn(c.lat0, a, e2);
  const x = c.x0 + c.k0 * N * (A + (1 - T + C) * A ** 3 / 6 + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * A ** 5 / 120);
  const y = c.y0 + c.k0 * (M + N * tan * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A ** 4 / 24 + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * A ** 6 / 720));
  return [x, y];
}

function tmInverse(x, y, c) {
  const a = c.a, e2 = c.e2, ep2 = e2 / (1 - e2);
  const M = (y - c.y0) / c.k0 + mlfn(c.lat0, a, e2);
  const fp = invMlfn(M, a, e2);
  const sin = Math.sin(fp), cos = Math.cos(fp), tan = Math.tan(fp);
  const C1 = ep2 * cos * cos, T1 = tan * tan;
  const N1 = a / Math.sqrt(1 - e2 * sin * sin);
  const R1 = a * (1 - e2) / Math.pow(1 - e2 * sin * sin, 1.5);
  const D = (x - c.x0) / (N1 * c.k0);
  const lat = fp - (N1 * tan / R1) * (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * ep2) * D ** 4 / 24 + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * ep2 - 3 * C1 * C1) * D ** 6 / 720);
  const lon = c.lon0 + (D - (1 + 2 * T1 + C1) * D ** 3 / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * ep2 + 24 * T1 * T1) * D ** 5 / 120) / cos;
  return [lon, lat];
}

function lccParams(c) {
  let p1 = c.lat1 || c.lat0 || 33 * DEG, p2 = c.lat2 || p1;
  const n = Math.abs(p1 - p2) < 1e-12 ? Math.sin(p1) :
    Math.log(Math.cos(p1) / Math.cos(p2)) / Math.log(Math.tan(Math.PI / 4 + p2 / 2) / Math.tan(Math.PI / 4 + p1 / 2));
  const F = Math.cos(p1) * Math.pow(Math.tan(Math.PI / 4 + p1 / 2), n) / n;
  const rho0 = c.a * F / Math.pow(Math.tan(Math.PI / 4 + c.lat0 / 2), n);
  return { n, F, rho0 };
}

function aeaParams(c) {
  let p1 = c.lat1 || 29.5 * DEG, p2 = c.lat2 || 45.5 * DEG;
  const n = (Math.sin(p1) + Math.sin(p2)) / 2;
  const C = Math.cos(p1) ** 2 + 2 * n * Math.sin(p1);
  const rho0 = c.a * Math.sqrt(C - 2 * n * Math.sin(c.lat0)) / n;
  return { n, C, rho0 };
}

function project(lon, lat, c) {
  const dl = adjlon(lon - c.lon0);
  const R = c.a;
  switch (c.proj) {
    case "merc": {
      if (Math.abs(lat) >= Math.PI / 2 || Math.abs(lon) > 10) return null;
      const k = Math.cos(c.latTs) / Math.sqrt(1 - c.e2 * Math.sin(c.latTs) ** 2);
      const s = Math.sin(lat);
      const y = c.e ? R * k * Math.log(Math.tan(Math.PI / 4 + lat / 2) * Math.pow((1 - c.e * s) / (1 + c.e * s), c.e / 2))
        : R * k * Math.log(Math.tan(Math.PI / 4 + lat / 2));
      return [c.x0 + R * k * dl, c.y0 + y];
    }
    case "webmerc":
      return [c.x0 + R * dl, c.y0 + R * Math.log(Math.tan(Math.PI / 4 + lat / 2))];
    case "eqc":
      return [c.x0 + R * dl * Math.cos(c.latTs), c.y0 + mlfn(lat, c.a, c.e2) - mlfn(c.lat0, c.a, c.e2)];
    case "utm":
    case "tmerc":
      if (Math.abs(lat) > Math.PI / 2 || Math.abs(lon) > 10) return null;
      return tmForward(lon, lat, c);
    case "sinu":
      return [c.x0 + R * dl * Math.cos(lat), c.y0 + mlfn(lat, c.a, c.e2) - mlfn(c.lat0, c.a, c.e2)];
    case "cea": {
      const k = Math.cos(c.latTs || 0);
      if (c.e) {
        const s = Math.sin(lat);
        const q = (1 - c.e2) * (s / (1 - c.e2 * s * s) - (1 / (2 * c.e)) * Math.log((1 - c.e * s) / (1 + c.e * s)));
        return [c.x0 + R * k * dl, c.y0 + R * q / (2 * k)];
      }
      return [c.x0 + R * k * dl, c.y0 + R * Math.sin(lat) / k];
    }
    case "moll": {
      let th = lat;
      for (let i = 0; i < 12; i++) {
        const d = -(2 * th + Math.sin(2 * th) - Math.PI * Math.sin(lat)) / (2 + 2 * Math.cos(2 * th));
        th += d; if (Math.abs(d) < 1e-12) break;
      }
      return [c.x0 + R * 2 * Math.SQRT2 / Math.PI * dl * Math.cos(th), c.y0 + R * Math.SQRT2 * Math.sin(th)];
    }
    case "eck4": {
      let th = lat / 2;
      const rhs = (2 + Math.PI / 2) * Math.sin(lat);
      for (let i = 0; i < 12; i++) {
        const d = -(th + Math.sin(th) * Math.cos(th) + 2 * Math.sin(th) - rhs) / (2 * Math.cos(th) * (1 + Math.cos(th)));
        th += d; if (Math.abs(d) < 1e-12) break;
      }
      return [
        c.x0 + R * 2 / Math.sqrt(Math.PI * (4 + Math.PI)) * dl * (1 + Math.cos(th)),
        c.y0 + R * 2 * Math.sqrt(Math.PI / (4 + Math.PI)) * Math.sin(th),
      ];
    }
    case "aeqd":
    case "laea":
    case "ortho":
    case "gnom":
    case "stere": {
      const sp0 = Math.sin(c.lat0), cp0 = Math.cos(c.lat0), sp = Math.sin(lat), cp = Math.cos(lat), cosc = sp0 * sp + cp0 * cp * Math.cos(dl);
      let k;
      if (c.proj === "ortho") k = 1;
      else if (c.proj === "gnom") k = 1 / cosc;
      else if (c.proj === "stere") k = 2 / (1 + cosc);
      else if (c.proj === "laea") k = Math.sqrt(2 / (1 + cosc));
      else { const cc = Math.acos(Math.max(-1, Math.min(1, cosc))); k = Math.abs(cc) < 1e-12 ? 1 : cc / Math.sin(cc); }
      return [c.x0 + R * k * cp * Math.sin(dl), c.y0 + R * k * (cp0 * sp - sp0 * cp * Math.cos(dl))];
    }
    case "lcc": {
      const p = lccParams(c);
      const rho = R * p.F / Math.pow(Math.tan(Math.PI / 4 + lat / 2), p.n);
      const th = p.n * dl;
      return [c.x0 + rho * Math.sin(th), c.y0 + p.rho0 - rho * Math.cos(th)];
    }
    case "aea": {
      const p = aeaParams(c);
      const rho = R * Math.sqrt(p.C - 2 * p.n * Math.sin(lat)) / p.n;
      const th = p.n * dl;
      return [c.x0 + rho * Math.sin(th), c.y0 + p.rho0 - rho * Math.cos(th)];
    }
    default:
      return null;
  }
}

function inverse(x, y, c) {
  switch (c.proj) {
    case "merc": {
      const k = Math.cos(c.latTs) / Math.sqrt(1 - c.e2 * Math.sin(c.latTs) ** 2);
      const lon = c.lon0 + (x - c.x0) / (c.a * k);
      let lat = Math.PI / 2 - 2 * Math.atan(Math.exp(-(y - c.y0) / (c.a * k)));
      if (c.e) {
        for (let i = 0; i < 10; i++) {
          const s = Math.sin(lat);
          const nlat = Math.PI / 2 - 2 * Math.atan(Math.exp(-(y - c.y0) / (c.a * k)) * Math.pow((1 - c.e * s) / (1 + c.e * s), c.e / 2));
          if (Math.abs(nlat - lat) < 1e-14) break;
          lat = nlat;
        }
      }
      return [lon, lat];
    }
    case "webmerc":
      return [c.lon0 + (x - c.x0) / c.a, Math.PI / 2 - 2 * Math.atan(Math.exp(-(y - c.y0) / c.a))];
    case "eqc":
      return [c.lon0 + (x - c.x0) / (c.a * Math.cos(c.latTs)), invMlfn(y - c.y0 + mlfn(c.lat0, c.a, c.e2), c.a, c.e2)];
    case "utm":
    case "tmerc":
      return tmInverse(x, y, c);
    default:
      return null;
  }
}

function parseCoord(s) {
  s = String(s).trim();
  let hemi = 1;
  if (/[SWsw]$/.test(s)) hemi = -1;
  s = s.replace(/[NSEWnsew]$/, "");
  const m = s.match(/^([+-]?\d+(?:\.\d*)?)(?:d(?:(\d+(?:\.\d*)?)')?(?:(\d+(?:\.\d*)?)")?)?$/);
  if (m) {
    const sign = m[1].startsWith("-") ? -1 : 1;
    const d = Math.abs(Number(m[1])), mi = Number(m[2] || 0), sec = Number(m[3] || 0);
    return hemi * sign * (d + mi / 60 + sec / 3600);
  }
  return Number(s) * hemi;
}

function formatDMS(deg, isLon) {
  const hemi = deg < 0 ? (isLon ? "W" : "S") : (isLon ? "E" : "N");
  let v = Math.abs(deg);
  let d = Math.floor(v + 1e-12);
  v = (v - d) * 60;
  let m = Math.floor(v + 1e-12);
  let s = (v - m) * 60;
  s = Math.round(s * 1000) / 1000;
  if (s >= 60) { s -= 60; m++; }
  if (m >= 60) { m -= 60; d++; }
  if (s === 0 && m === 0) return `${d}d${hemi}`;
  if (s === 0) return `${d}d${m}'${hemi}`;
  return `${d}d${m}'${s.toFixed(3).replace(/\.?0+$/, "")}"${hemi}`;
}

function fmtNum(v, st) {
  v *= st.mult;
  if (Math.abs(v) < 0.5 * Math.pow(10, -Math.max(0, st.decimals || 0))) v = 0;
  if (st.fmt) {
    const m = st.fmt.match(/^%\.([0-9]+)f$/);
    if (m) {
      if (Math.abs(v) < 0.5 * Math.pow(10, -Number(m[1]))) v = 0;
      return v.toFixed(Number(m[1]));
    }
  }
  return v.toFixed(st.decimals);
}

function handleLine(line, st, ctx) {
  if (line.length === 0) return "";
  if (/^\s*#/.test(line)) return line;
  const parts = line.trim().split(/\s+/);
  if (parts.length < 2) return line;
  const a = parseCoord(parts[0]), b = parseCoord(parts[1]);
  if (!Number.isFinite(a) || !Number.isFinite(b)) return `${st.err}\t${st.err}`;
  const c1 = st.rin ? b : a, c2 = st.rin ? a : b;
  let out;
  if (st.inverse) {
    out = inverse(c1, c2, ctx);
    if (!out || !Number.isFinite(out[0]) || !Number.isFinite(out[1])) return `${st.err}\t${st.err}`;
    let vals = [formatDMS(out[0] * RAD, true), formatDMS(out[1] * RAD, false)];
    if (st.sout) vals = [vals[1], vals[0]];
    return (st.echo ? `${parts[0]} ${parts[1]}\t` : "") + vals.join("\t") + (parts.length > 2 ? " " + parts.slice(2).join(" ") : "");
  }
  out = project(c1 * DEG, c2 * DEG, ctx);
  if (!out || !Number.isFinite(out[0]) || !Number.isFinite(out[1])) {
    process.stderr.write(`${ctx.proj}: Invalid ${Math.abs(c2) > 90 ? "latitude" : "longitude"}\n`);
    return `${st.err}\t${st.err}`;
  }
  let vals = [fmtNum(out[0], st), fmtNum(out[1], st)];
  if (st.sout) vals = [vals[1], vals[0]];
  return (st.echo ? `${parts[0]} ${parts[1]}\t` : "") + vals.join("\t") + (parts.length > 2 ? " " + parts.slice(2).join(" ") : "");
}

function verboseOnce(ctx, line, st) {
  const pnames = { merc: "Mercator", utm: "Universal Transverse Mercator (UTM)", tmerc: "Transverse Mercator" };
  process.stdout.write(`#${pnames[ctx.proj] || ctx.proj}\n# +proj=${ctx.proj}\n#Final Earth figure: ${ctx.e2 ? "ellipsoid" : "sphere"}\n`);
  const out = handleLine(line, st, ctx);
  process.stdout.write(out + "\n");
}

function main() {
  const st = parseArgs(process.argv.slice(2));
  const ctx = init(st);
  let text = "";
  if (st.files.length) {
    for (const f of st.files) {
      try { text += fs.readFileSync(f, "utf8"); }
      catch (e) { process.stdout.write(`${REL}\n<executable>: \nSys errno: 2: No such file or directory\ninput file: ${f}\n`); }
    }
  } else {
    text = fs.readFileSync(0, "utf8");
  }
  const lines = text.split(/\r?\n/);
  if (lines.length && lines[lines.length - 1] === "") lines.pop();
  if (st.verbose && lines.length) {
    verboseOnce(ctx, lines[0], st);
    return;
  }
  for (const line of lines) process.stdout.write(handleLine(line, st, ctx) + "\n");
}

main();
