#!/usr/bin/env node
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const HELP = `nsh 0.4.2
A command-line shell that focuses on performance and productivity.

USAGE:
    executable [FLAGS] [OPTIONS] [FILE]

FLAGS:
    -h, --help       Prints help information
    -l, --login      Behave like a login shell
        --norc       Don't load nshrc
        --version    Print the version

OPTIONS:
    -c <command>        The command to be executed

ARGS:
    <FILE>    The file to be executed`;

function usageForUnexpected(arg) {
  return `error: Found argument '${arg}' which wasn't expected, or isn't valid in this context

USAGE:
    executable [FLAGS] [OPTIONS] [FILE]

For more information try --help`;
}

function usageMissingC() {
  return `error: The argument '-c <command>' requires a value but none was supplied

USAGE:
    executable -c <command>

For more information try --help`;
}

function parseArgs(argv) {
  const out = { command: null, file: null, norc: false, login: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') {
      console.log(HELP);
      process.exit(0);
    }
    if (a === '--version') {
      console.log('0.4.2');
      process.exit(0);
    }
    if (a === '--norc') {
      out.norc = true;
      continue;
    }
    if (a === '-l' || a === '--login') {
      out.login = true;
      continue;
    }
    if (a === '-lc') {
      out.login = true;
      if (i + 1 >= argv.length) {
        process.stderr.write(usageMissingC());
        process.exit(1);
      }
      out.command = argv[++i];
      continue;
    }
    if (a === '-c') {
      if (i + 1 >= argv.length) {
        process.stderr.write(usageMissingC());
        process.exit(1);
      }
      out.command = argv[++i];
      continue;
    }
    if (a.startsWith('-c') && a.length > 2) {
      out.command = a.slice(2);
      continue;
    }
    if (a.startsWith('-')) {
      console.error(usageForUnexpected(a));
      process.exit(1);
    }
    if (out.file === null) {
      out.file = a;
      continue;
    }
    console.error(usageForUnexpected(a));
    process.exit(1);
  }
  return out;
}

function rcPath() {
  const xdg = process.env.XDG_CONFIG_HOME;
  if (xdg) {
    const p = path.join(xdg, 'nsh', 'nshrc');
    if (fs.existsSync(p)) return p;
  }
  const home = process.env.HOME || os.homedir();
  if (home) {
    const p = path.join(home, '.nshrc');
    if (fs.existsSync(p)) return p;
  }
  return null;
}

function shellQuote(s) {
  return "'" + String(s).replace(/'/g, "'\\''") + "'";
}

function makePrelude(opts) {
  const lines = [
    'shopt -s expand_aliases',
    'command_not_found_handle() {',
    '  printf "nsh: command not found \\`%s\\047\\n" "$1" >&2',
    '  return 1',
    '}',
    'cd() {',
    '  if [ "$#" -eq 0 ]; then',
    '    builtin cd "$HOME" 2>/dev/null || { printf "nsh: cd: No such file or directory (os error 2): \\`%s\\047\\n" "$HOME" >&2; return 1; }',
    '  else',
    '    builtin cd "$@" 2>/dev/null || { printf "nsh: cd: No such file or directory (os error 2): \\`%s\\047\\n" "$1" >&2; return 1; }',
    '  fi',
    '}'
  ];
  if (!opts.norc) {
    const rc = rcPath();
    if (rc) lines.push(`. ${shellQuote(rc)}`);
  }
  return lines.join('\n') + '\n';
}

function runScript(body, opts) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nsh-'));
  const script = path.join(tmp, 'run.sh');
  fs.writeFileSync(script, makePrelude(opts) + body, { mode: 0o700 });
  const res = spawnSync('/bin/bash', ['--noprofile', '--norc', script], {
    stdio: 'inherit',
    env: process.env
  });
  try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (_) {}
  if (res.error) {
    console.error(res.error.message);
    return 1;
  }
  return typeof res.status === 'number' ? res.status : 1;
}

function runFile(file, opts) {
  if (!fs.existsSync(file)) {
    console.error(`nsh: panicked at src/main.rs:114:34:
failed to open the file: Os { code: 2, kind: NotFound, message: "No such file or directory" }
nsh: Something went wrong. Check out ~/.nsh.log and please file this bug on GitHub: https://github.com/nuta/nsh/issues`);
    return 101;
  }
  return runScript(`. ${shellQuote(path.resolve(file))}\n`, opts);
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.command !== null) {
    process.exit(runScript(opts.command + '\n', opts));
  }
  if (opts.file !== null) {
    process.exit(runFile(opts.file, opts));
  }
  if (!process.stdout.isTTY) {
    console.error('nsh: warning: stdout is not a tty');
    process.exit(0);
  }
  process.exit(runScript('', opts));
}

main();
