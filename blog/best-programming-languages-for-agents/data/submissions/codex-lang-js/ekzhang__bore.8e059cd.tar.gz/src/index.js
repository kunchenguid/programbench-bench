#!/usr/bin/env node
'use strict';

const net = require('net');
const crypto = require('crypto');

const VERSION = 'bore-cli 0.6.0';
const CONTROL_PORT = 7835;

function writeMsg(sock, value) {
  if (!sock.destroyed) sock.write(JSON.stringify(value) + '\0');
}

function makeParser(onMsg) {
  let buf = Buffer.alloc(0);
  return function feed(chunk) {
    buf = Buffer.concat([buf, chunk]);
    let idx;
    while ((idx = buf.indexOf(0)) !== -1) {
      const raw = buf.subarray(0, idx).toString();
      buf = buf.subarray(idx + 1);
      if (!raw) continue;
      let msg;
      try {
        msg = JSON.parse(raw);
      } catch {
        continue;
      }
      onMsg(msg, buf);
    }
  };
}

function uuid() {
  return crypto.randomUUID ? crypto.randomUUID() : [4, 2, 2, 2, 6]
    .map(n => crypto.randomBytes(n).toString('hex')).join('-');
}

function authDigest(challenge, secret) {
  return crypto.createHash('sha256').update(String(challenge) + String(secret)).digest('hex');
}

function usage() {
  return `A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls.

Usage: executable <COMMAND>

Commands:
  local   Starts a local proxy to the remote server
  server  Runs the remote proxy server
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version`;
}

function localHelp() {
  return `Starts a local proxy to the remote server

Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>

Arguments:
  <LOCAL_PORT>  The local port to expose [env: BORE_LOCAL_PORT=]

Options:
  -l, --local-host <HOST>  The local host to expose [default: localhost]
  -t, --to <TO>            Address of the remote server to expose local ports to [env: BORE_SERVER=]
  -p, --port <PORT>        Optional port on the remote server to select [default: 0]
  -s, --secret <SECRET>    Optional secret for authentication [env: BORE_SECRET]
  -h, --help               Print help`;
}

function serverHelp() {
  return `Runs the remote proxy server

Usage: executable server [OPTIONS]

Options:
      --min-port <MIN_PORT>          Minimum accepted TCP port number [env: BORE_MIN_PORT=] [default: 1024]
      --max-port <MAX_PORT>          Maximum accepted TCP port number [env: BORE_MAX_PORT=] [default: 65535]
  -s, --secret <SECRET>              Optional secret for authentication [env: BORE_SECRET]
      --bind-addr <BIND_ADDR>        IP address to bind to, clients must reach this [default: 0.0.0.0]
      --bind-tunnels <BIND_TUNNELS>  IP address where tunnels will listen on, defaults to --bind-addr
  -h, --help                         Print help`;
}

function die(msg, code = 1) {
  console.error(msg);
  process.exit(code);
}

function parsePort(value, name) {
  if (value == null || value === '') return null;
  if (!/^\d+$/.test(String(value))) {
    die(`error: invalid value '${value}' for '${name}': invalid digit found in string\n\nFor more information, try '--help'.`);
  }
  const n = Number(value);
  if (n < 0 || n > 65535) {
    die(`error: invalid value '${value}' for '${name}': port number must be between 0 and 65535\n\nFor more information, try '--help'.`);
  }
  return n;
}

function takeOpt(args, i) {
  if (i + 1 >= args.length) die(`error: a value is required for '${args[i]}' but none was supplied`);
  return [args[i + 1], i + 1];
}

function parseTarget(to) {
  if (!to) return null;
  if (to.startsWith('[')) {
    const end = to.indexOf(']');
    if (end !== -1 && to[end + 1] === ':') return { host: to.slice(1, end), port: Number(to.slice(end + 2)) || CONTROL_PORT };
  }
  const parts = to.split(':');
  if (parts.length === 2 && /^\d+$/.test(parts[1])) return { host: parts[0], port: Number(parts[1]) };
  return { host: to, port: CONTROL_PORT };
}

function info(msg) {
  console.error(msg);
}

function connectControl(host, port) {
  return new Promise((resolve, reject) => {
    const s = net.createConnection({ host, port });
    s.once('connect', () => resolve(s));
    s.once('error', reject);
  });
}

function connectLocal(host, port) {
  return new Promise((resolve, reject) => {
    const s = net.createConnection({ host, port });
    s.once('connect', () => resolve(s));
    s.once('error', reject);
  });
}

async function runLocal(args) {
  const opts = {
    localHost: 'localhost',
    to: process.env.BORE_SERVER || null,
    remotePort: 0,
    secret: process.env.BORE_SECRET || null,
    localPort: process.env.BORE_LOCAL_PORT || null,
  };
  const positional = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '-h' || a === '--help') { console.log(localHelp()); return; }
    if (a === '-l' || a === '--local-host') { let v; [v, i] = takeOpt(args, i); opts.localHost = v; continue; }
    if (a === '-t' || a === '--to') { let v; [v, i] = takeOpt(args, i); opts.to = v; continue; }
    if (a === '-p' || a === '--port') { let v; [v, i] = takeOpt(args, i); opts.remotePort = parsePort(v, '--port <PORT>'); continue; }
    if (a === '-s' || a === '--secret') { let v; [v, i] = takeOpt(args, i); opts.secret = v; continue; }
    if (a.startsWith('-')) die(`error: unexpected argument '${a}' found\n\nUsage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>\n\nFor more information, try '--help'.`);
    positional.push(a);
  }
  if (positional.length) opts.localPort = positional[0];
  if (!opts.to || opts.localPort == null) {
    const missing = [];
    if (!opts.to) missing.push('  --to <TO>');
    if (opts.localPort == null) missing.push('  <LOCAL_PORT>');
    die(`error: the following required arguments were not provided:\n${missing.join('\n')}\n\nUsage: executable local --to <TO> <LOCAL_PORT>\n\nFor more information, try '--help'.`);
  }
  opts.localPort = parsePort(opts.localPort, '<LOCAL_PORT>');
  const target = parseTarget(opts.to);
  let control;
  try {
    control = await connectControl(target.host, target.port);
  } catch (e) {
    die(`Error: could not connect to ${opts.to.includes(':') ? opts.to : `${target.host}:${target.port}`}\n\nCaused by:\n    ${e.message}`);
  }

  let authed = !opts.secret;
  let helloSent = false;
  const sendHello = () => {
    if (helloSent) return;
    helloSent = true;
    writeMsg(control, { Hello: opts.remotePort });
  };
  if (!opts.secret) sendHello();

  const parser = makeParser((msg) => {
    if (msg.Challenge !== undefined) {
      if (!opts.secret) {
        die('Error: server requires secret, but no secret was provided');
      }
      writeMsg(control, { Authenticate: authDigest(msg.Challenge, opts.secret) });
      authed = true;
      sendHello();
      return;
    }
    if (!authed && opts.secret) {
      die('Error: expected authentication challenge, but no secret was required');
    }
    if (msg.Hello !== undefined) {
      const p = Number(msg.Hello);
      info(`connected to server remote_port=${p}`);
      info(`listening at ${target.host}:${p}`);
      return;
    }
    if (msg.Connection !== undefined) {
      const id = String(msg.Connection);
      info(`new connection id=${id}`);
      handleProxy(target, opts, id).catch(e => info(`connection exited with error err=${e.message}`));
    }
  });
  control.on('data', parser);
  control.on('error', e => info(`control connection error: ${e.message}`));
  control.on('close', () => process.exit(0));
}

async function handleProxy(target, opts, id) {
  const remote = await connectControl(target.host, target.port);
  let accepted = false;
  const start = async () => {
    if (accepted) return;
    accepted = true;
    writeMsg(remote, { Accept: id });
    const local = await connectLocal(opts.localHost, opts.localPort);
    remote.pipe(local);
    local.pipe(remote);
    remote.resume();
  };
  if (opts.secret) {
    const parser = makeParser((msg) => {
      if (msg.Challenge !== undefined) {
        remote.removeListener('data', parser);
        remote.pause();
        writeMsg(remote, { Authenticate: authDigest(msg.Challenge, opts.secret) });
        start().catch(e => {
          info(`connection exited with error err=${e.message}`);
          remote.destroy();
        });
      }
    });
    remote.on('data', parser);
  } else {
    await start();
  }
}

function choosePort(min, max, requested, used) {
  if (requested) {
    if (requested < min || requested > max) throw new Error(`port ${requested} is outside permitted range`);
    if (used.has(requested)) throw new Error(`port ${requested} is already in use`);
    return requested;
  }
  for (let i = 0; i < 2000; i++) {
    const p = min + Math.floor(Math.random() * (max - min + 1));
    if (!used.has(p)) return p;
  }
  for (let p = min; p <= max; p++) if (!used.has(p)) return p;
  throw new Error('port range is empty');
}

async function listen(server, port, host) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, host, () => {
      server.removeListener('error', reject);
      resolve();
    });
  });
}

async function runServer(args) {
  const opts = {
    minPort: parsePort(process.env.BORE_MIN_PORT || '1024', '--min-port <MIN_PORT>'),
    maxPort: 65535,
    secret: process.env.BORE_SECRET || null,
    bindAddr: '0.0.0.0',
    bindTunnels: null,
  };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '-h' || a === '--help') { console.log(serverHelp()); return; }
    if (a === '--min-port') { let v; [v, i] = takeOpt(args, i); opts.minPort = parsePort(v, '--min-port <MIN_PORT>'); continue; }
    if (a === '--max-port') { let v; [v, i] = takeOpt(args, i); opts.maxPort = parsePort(v, '--max-port <MAX_PORT>'); continue; }
    if (a === '-s' || a === '--secret') { let v; [v, i] = takeOpt(args, i); opts.secret = v; continue; }
    if (a === '--bind-addr') { let v; [v, i] = takeOpt(args, i); opts.bindAddr = v; continue; }
    if (a === '--bind-tunnels') { let v; [v, i] = takeOpt(args, i); opts.bindTunnels = v; continue; }
    die(`error: unexpected argument '${a}' found\n\nUsage: executable server [OPTIONS]\n\nFor more information, try '--help'.`);
  }
  if (opts.minPort > opts.maxPort) die(`error: port range is empty\n\nUsage: bore-cli <COMMAND>\n\nFor more information, try '--help'.`);
  if (!opts.bindTunnels) opts.bindTunnels = opts.bindAddr;

  const clients = new Map();
  const pending = new Map();
  const used = new Set();
  const controlServer = net.createServer(sock => {
    const peer = `${sock.remoteAddress}:${sock.remotePort}`;
    info(`incoming connection addr=${peer}`);
    setupServerSocket(sock, opts, clients, pending, used);
  });
  await listen(controlServer, CONTROL_PORT, opts.bindAddr);
  info(`server listening addr=${opts.bindAddr}`);
}

function setupServerSocket(sock, opts, clients, pending, used) {
  let authed = !opts.secret;
  if (opts.secret) {
    const challenge = uuid();
    sock._challenge = challenge;
    writeMsg(sock, { Challenge: challenge });
  }
  const parser = makeParser((msg, rest) => {
    if (!authed) {
      if (msg.Authenticate !== authDigest(sock._challenge, opts.secret)) {
        sock.destroy();
        return;
      }
      authed = true;
      return;
    }
    if (msg.Hello !== undefined) {
      registerClient(sock, Number(msg.Hello) || 0, opts, clients, pending, used).catch(e => {
        info(`server handshake failed err=${e.message}`);
        sock.destroy();
      });
      return;
    }
    if (msg.Accept !== undefined) {
      const id = String(msg.Accept);
      const remote = pending.get(id);
      if (!remote) {
        sock.destroy();
        return;
      }
      pending.delete(id);
      if (rest && rest.length) remote.write(rest);
      sock.pipe(remote);
      remote.pipe(sock);
      remote.resume();
    }
  });
  sock.on('data', parser);
}

async function registerClient(sock, requested, opts, clients, pending, used) {
  const port = choosePort(opts.minPort, opts.maxPort, requested, used);
  const tunnel = net.createServer(remote => {
    remote.pause();
    const id = uuid();
    pending.set(id, remote);
    writeMsg(sock, { Connection: id });
    const timer = setTimeout(() => {
      if (pending.get(id) === remote) {
        pending.delete(id);
        remote.destroy();
      }
    }, 30000);
    remote.on('close', () => clearTimeout(timer));
  });
  await listen(tunnel, port, opts.bindTunnels);
  used.add(port);
  clients.set(sock, { tunnel, port });
  writeMsg(sock, { Hello: port });
  writeMsg(sock, 'Heartbeat');
  const hb = setInterval(() => writeMsg(sock, 'Heartbeat'), 1000);
  sock.on('close', () => {
    clearInterval(hb);
    const c = clients.get(sock);
    if (c) {
      used.delete(c.port);
      c.tunnel.close();
      clients.delete(sock);
    }
  });
  info(`new client host=${opts.bindTunnels} port=${port}`);
}

async function main() {
  const args = process.argv.slice(2);
  if (args.length === 0 || args[0] === '-h' || args[0] === '--help' || args[0] === 'help') {
    if (args[0] === 'help' && args[1] === 'local') console.log(localHelp());
    else if (args[0] === 'help' && args[1] === 'server') console.log(serverHelp());
    else console.log(usage());
    return;
  }
  if (args[0] === '-V' || args[0] === '--version') { console.log(VERSION); return; }
  if (args[0] === 'local') return runLocal(args.slice(1));
  if (args[0] === 'server') return runServer(args.slice(1));
  die(`error: unrecognized subcommand '${args[0]}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.`);
}

main().catch(e => die(`Error: ${e.message}`));
