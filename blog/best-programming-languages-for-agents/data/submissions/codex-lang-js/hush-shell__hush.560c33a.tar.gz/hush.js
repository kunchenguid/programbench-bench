#!/usr/bin/env node
const fs = require('fs');
const cp = require('child_process');
const path = require('path');

const VERSION = 'Hush 0.1.4';

function usage() {
  console.log(`${VERSION}
gahag <gabriel.s.b@live.com>
Hush is a unix shell scripting language based on the Lua programming language

USAGE:
    executable [FLAGS] [arguments]...

FLAGS:
        --ast        Print the AST
        --check      Perform only static analysis instead of executing.
    -h, --help       Prints help information
        --lex        Print the lexemes
        --program    Print the PROGAM
    -V, --version    Prints version information

ARGS:
    <arguments>...    Script and/or arguments`);
}

class HushError extends Error {
  constructor(msg) { super(msg); this.name = 'Error'; }
}

function tokenize(src, file) {
  const toks = [];
  let i = 0, line = 1, col = 0;
  const add = (type, val, l=line, c=col) => toks.push({type, val, line:l, col:c});
  while (i < src.length) {
    let ch = src[i];
    if (ch === '\r') { i++; continue; }
    if (ch === '\n') { add('sep', '\n'); i++; line++; col = 0; continue; }
    if (/\s/.test(ch)) { i++; col++; continue; }
    if (ch === '#') { while (i < src.length && src[i] !== '\n') { i++; col++; } continue; }
    const l = line, c = col;
    const two = src.slice(i, i + 2);
    if (['==','!=','<=','>=','++','${','&{','>>','<<','->'].includes(two)) { add('sym', two, l, c); i += 2; col += 2; continue; }
    if ('()[]@.,:+-*/%=<>;{}?|~\\'.includes(ch)) { add(ch === ';' ? 'sep' : 'sym', ch, l, c); i++; col++; continue; }
    if (ch === '"' || ch === "'") {
      const q = ch; i++; col++;
      let s = '';
      while (i < src.length && src[i] !== q) {
        if (src[i] === '\\') {
          const n = src[++i];
          const map = {n:'\n', t:'\t', r:'\r', '0':'\0', '"':'"', "'":"'", '\\':'\\', '$':'$'};
          s += map[n] ?? n; i++; col += 2;
        } else { s += src[i++]; col++; }
      }
      if (src[i] === q) { i++; col++; }
      add('string', s, l, c); continue;
    }
    if (/[0-9]/.test(ch)) {
      let s = '';
      while (i < src.length && /[0-9.]/.test(src[i])) { s += src[i++]; col++; }
      if (/[eE]/.test(src[i] || '')) {
        s += src[i++]; col++;
        if (/[+-]/.test(src[i] || '')) { s += src[i++]; col++; }
        while (/[0-9]/.test(src[i] || '')) { s += src[i++]; col++; }
      }
      add('number', s, l, c); continue;
    }
    if (/[A-Za-z_]/.test(ch)) {
      let s = '';
      while (i < src.length && /[A-Za-z0-9_]/.test(src[i])) { s += src[i++]; col++; }
      add('id', s, l, c); continue;
    }
    if (ch === '$') { add('sym', '$', l, c); i++; col++; continue; }
    throw new HushError(`${file} (line ${line}, column ${col}) - invalid token '${ch}'`);
  }
  add('eof', '', line, col);
  return toks;
}

class Parser {
  constructor(toks, src) { this.toks = toks; this.i = 0; this.src = src; }
  peek(n=0) { return this.toks[this.i + n] || this.toks[this.toks.length - 1]; }
  at(v) { const t = this.peek(); return t.val === v || t.type === v; }
  take(v) { if (v && !this.at(v)) return null; return this.toks[this.i++]; }
  expect(v) { const t = this.take(v); if (!t) throw new HushError(`expected '${v}', got '${this.peek().val}'`); return t; }
  seps() { while (this.at('sep')) this.take(); }
  parseProgram(stop=[]) {
    const body = []; this.seps();
    while (!this.at('eof') && !stop.includes(this.peek().val)) {
      body.push(this.statement()); this.seps();
    }
    return {type:'program', body};
  }
  statement() {
    if (this.at('let')) { this.take(); const name = this.expect('id').val; let expr = {type:'lit', value:null}; if (this.at('=')) { this.take(); expr = this.expr(); } return {type:'let', name, expr}; }
    if (this.at('return')) { this.take(); return {type:'return', expr: this.at('sep') || this.at('end') || this.at('eof') ? {type:'lit', value:null} : this.expr()}; }
    if (this.at('if')) return this.ifStmt();
    if (this.at('while')) return this.whileStmt();
    if (this.at('for')) return this.forStmt();
    if (this.at('function') && this.peek(1).type === 'id') return this.funcDecl();
    const e = this.expr();
    if (this.at('=')) { this.take(); return {type:'assign', target:e, expr:this.expr()}; }
    return {type:'expr', expr:e};
  }
  funcDecl() {
    this.expect('function'); const name = this.expect('id').val; const fn = this.funcTail();
    return {type:'let', name, expr:fn};
  }
  ifStmt() {
    this.expect('if'); const cond = this.expr(); this.expect('then'); const then = this.parseProgram(['else','end']);
    let els = {type:'program', body:[]}; if (this.at('else')) { this.take(); els = this.parseProgram(['end']); }
    this.expect('end'); return {type:'ifstmt', cond, then, els};
  }
  whileStmt() { this.expect('while'); const cond = this.expr(); this.expect('do'); const body = this.parseProgram(['end']); this.expect('end'); return {type:'while', cond, body}; }
  forStmt() { this.expect('for'); const name = this.expect('id').val; this.expect('in'); const iter = this.expr(); this.expect('do'); const body = this.parseProgram(['end']); this.expect('end'); return {type:'for', name, iter, body}; }
  expr(p=0) {
    let left = this.prefix();
    while (true) {
      const op = this.peek().val, prec = Parser.prec[op] || 0;
      if (prec <= p) break;
      this.take(); const right = this.expr(prec);
      left = {type:'bin', op, left, right};
    }
    return left;
  }
  prefix() {
    if (this.at('not') || this.at('-')) { const op = this.take().val; return {type:'un', op, expr:this.expr(8)}; }
    if (this.at('if')) return this.ifExpr();
    let e = this.primary();
    while (true) {
      if (this.at('(')) { e = {type:'call', callee:e, args:this.args()}; continue; }
      if (this.at('.')) { this.take(); e = {type:'prop', obj:e, name:this.expect('id').val}; continue; }
      if (this.at('[')) { this.take(); const ix = this.expr(); this.expect(']'); e = {type:'index', obj:e, ix}; continue; }
      break;
    }
    return e;
  }
  primary() {
    const t = this.peek();
    if (t.type === 'number') { this.take(); return {type:'lit', value:Number(t.val)}; }
    if (t.type === 'string') { this.take(); return {type:'lit', value:t.val}; }
    if (this.at('function')) { this.take(); return this.funcTail(); }
    if (t.type === 'id') {
      this.take();
      if (t.val === 'true') return {type:'lit', value:true};
      if (t.val === 'false') return {type:'lit', value:false};
      if (t.val === 'nil') return {type:'lit', value:null};
      return {type:'var', name:t.val};
    }
    if (this.at('(')) { this.take(); const e = this.expr(); this.expect(')'); return e; }
    if (this.at('[')) return this.array();
    if (this.at('@')) return this.dict();
    if (this.at('{') || this.at('${') || this.at('&{')) return this.command();
    throw new HushError(`unexpected '${t.val}'`);
  }
  args() {
    this.expect('('); const a = []; this.seps();
    while (!this.at(')')) { a.push(this.expr()); if (this.at(',')) this.take(); this.seps(); }
    this.expect(')'); return a;
  }
  array() {
    this.expect('['); const vals = []; this.seps();
    while (!this.at(']')) { vals.push(this.expr()); if (this.at(',')) this.take(); this.seps(); }
    this.expect(']'); return {type:'array', vals};
  }
  dict() {
    this.expect('@'); this.expect('['); const pairs = []; this.seps();
    while (!this.at(']')) { const key = this.expect('id').val; this.expect(':'); const val = this.expr(); pairs.push([key,val]); if (this.at(',')) this.take(); this.seps(); }
    this.expect(']'); return {type:'dict', pairs};
  }
  funcTail() {
    const params = this.args().map(x => x.name || '');
    const body = this.parseProgram(['end']); this.expect('end');
    return {type:'func', params, body};
  }
  ifExpr() {
    this.expect('if'); const cond = this.expr(); this.expect('then'); this.seps();
    const yes = this.parseProgram(['else','end']);
    let no = {type:'program', body:[{type:'expr', expr:{type:'lit', value:null}}]};
    if (this.at('else')) { this.take(); this.seps(); no = this.parseProgram(['end']); }
    this.expect('end'); return {type:'ifexpr', cond, yes, no};
  }
  command() {
    const start = this.take().val; let depth = 1, text = '';
    while (!this.at('eof') && depth > 0) {
      const t = this.take();
      if (t.val === '{' || t.val === '${' || t.val === '&{') depth++;
      if (t.val === '}') { depth--; if (depth === 0) break; }
      text += t.val === '\n' ? '\n' : rawToken(t) + ' ';
    }
    return {type:'cmd', capture:start === '${', async:start === '&{', text};
  }
}
Parser.prec = {'or':1,'and':2,'==':3,'!=':3,'<':4,'>':4,'<=':4,'>=':4,'++':5,'+':5,'-':5,'*':6,'/':6,'%':6};

function rawToken(t) {
  if (t.type === 'string') return JSON.stringify(t.val);
  return t.val;
}

class Env {
  constructor(parent=null) { this.parent = parent; this.map = Object.create(null); }
  get(k) { if (k in this.map) return this.map[k]; if (this.parent) return this.parent.get(k); throw new HushError(`undeclared variable '${k}'`); }
  set(k,v) { if (k in this.map) { this.map[k]=v; return; } if (this.parent) return this.parent.set(k,v); this.map[k]=v; }
  let(k,v) { this.map[k]=v; }
}

class Ret { constructor(v) { this.v = v; } }

function truth(v) { return !!v; }
function show(v) {
  if (v === null || v === undefined) return 'nil';
  if (Array.isArray(v)) return '[' + v.map(show).join(', ') + ']';
  if (typeof v === 'object' && v.__hushObj) return '@[' + Object.keys(v).filter(k=>!k.startsWith('__')).map(k=>`${k}: ${show(v[k])}`).join(', ') + ']';
  return String(v);
}
function type(v) {
  if (v === null || v === undefined) return 'nil';
  if (Array.isArray(v)) return 'array';
  if (typeof v === 'number') return Number.isInteger(v) ? 'int' : 'float';
  if (typeof v === 'boolean') return 'bool';
  if (typeof v === 'function' || v.__hushFn) return 'function';
  if (typeof v === 'object') return 'dict';
  return typeof v;
}

function baseEnv(argv, file) {
  const e = new Env();
  const std = {
    __hushObj:true,
    print: (...a) => { process.stdout.write(a.map(show).join('')); return null; },
    println: (...a) => { console.log(a.map(show).join(' ')); return null; },
    len: x => (x == null ? 0 : (x.length ?? Object.keys(x).filter(k=>!k.startsWith('__')).length)),
    push: (a,v) => { a.push(v); return null; },
    pop: a => a.pop(),
    type,
    range: (start, stop, step) => {
      if (stop === undefined || stop === null) { stop = start; start = 0; }
      step = step === undefined || step === null ? 1 : step;
      const out = [];
      if (step > 0) for (let i=start; i<stop; i+=step) out.push(i);
      else for (let i=start; i>stop; i+=step) out.push(i);
      return out;
    },
    import: p => runFile(path.resolve(path.dirname(file || process.cwd()), p), []),
    tostring: show,
    tonumber: x => Number(x),
  };
  e.let('std', std); e.let('args', argv); e.let('self', null);
  return e;
}

function evalProgram(p, env) {
  let last = null;
  for (const s of p.body) { const r = evalStmt(s, env); if (r instanceof Ret) return r; last = r; }
  return last;
}
function evalStmt(s, env) {
  switch (s.type) {
    case 'let': env.let(s.name, evalExpr(s.expr, env)); return null;
    case 'assign': assign(s.target, evalExpr(s.expr, env), env); return null;
    case 'return': return new Ret(evalExpr(s.expr, env));
    case 'expr': return evalExpr(s.expr, env);
    case 'ifstmt': return truth(evalExpr(s.cond, env)) ? evalProgram(s.then, env) : evalProgram(s.els, env);
    case 'while': while (truth(evalExpr(s.cond, env))) { const r = evalProgram(s.body, new Env(env)); if (r instanceof Ret) return r; } return null;
    case 'for': {
      const it = evalExpr(s.iter, env) || [];
      const arr = typeof it === 'function' ? iterFunc(it) : it;
      for (const v of arr) { const child = new Env(env); child.let(s.name, v); const r = evalProgram(s.body, child); if (r instanceof Ret) return r; }
      return null;
    }
  }
}
function iterFunc(f) {
  const a = [];
  for (;;) { const r = f(); if (!r || r.finished) break; a.push(r.value); }
  return a;
}
function assign(t, v, env) {
  if (t.type === 'var') env.set(t.name, v);
  else if (t.type === 'prop') evalExpr(t.obj, env)[t.name] = v;
  else if (t.type === 'index') evalExpr(t.obj, env)[evalExpr(t.ix, env)] = v;
  else throw new HushError('invalid assignment');
}
function evalExpr(x, env) {
  switch (x.type) {
    case 'lit': return x.value;
    case 'var': return env.get(x.name);
    case 'array': return x.vals.map(v => evalExpr(v, env));
    case 'dict': { const o = {__hushObj:true}; for (const [k,v] of x.pairs) o[k] = evalExpr(v, env); return o; }
    case 'prop': return evalExpr(x.obj, env)?.[x.name];
    case 'index': return evalExpr(x.obj, env)?.[evalExpr(x.ix, env)];
    case 'ifexpr': return truth(evalExpr(x.cond, env)) ? evalProgram(x.yes, new Env(env)) : evalProgram(x.no, new Env(env));
    case 'un': { const v = evalExpr(x.expr, env); return x.op === 'not' ? !truth(v) : -v; }
    case 'bin': return bin(x.op, evalExpr(x.left, env), () => evalExpr(x.right, env));
    case 'func': return makeFn(x, env);
    case 'call': return call(x, env);
    case 'cmd': return runCommand(x, env);
  }
}
function bin(op, a, rb) {
  if (op === 'and') return truth(a) ? rb() : a;
  if (op === 'or') return truth(a) ? a : rb();
  const b = rb();
  switch (op) {
    case '+': return a + b; case '-': return a - b; case '*': return a * b; case '/': return Math.trunc(a / b); case '%': return a % b;
    case '++': return show(a) + show(b);
    case '==': return a === b; case '!=': return a !== b; case '<': return a < b; case '>': return a > b; case '<=': return a <= b; case '>=': return a >= b;
  }
}
function makeFn(node, closure) {
  const f = function(...args) {
    const e = new Env(closure);
    if (this && this.__hushObj) e.let('self', this);
    node.params.forEach((p,i) => { if (p) e.let(p, args[i] ?? null); });
    const r = evalProgram(node.body, e);
    return r instanceof Ret ? r.v : r;
  };
  f.__hushFn = true; return f;
}
function call(x, env) {
  let self = null;
  if (x.callee.type === 'prop') self = evalExpr(x.callee.obj, env);
  const fn = evalExpr(x.callee, env);
  const args = x.args.map(a => evalExpr(a, env));
  if (typeof fn !== 'function') throw new HushError('called value is not a function');
  if (self) {
    return fn.apply(self, args);
  }
  return fn(...args);
}
function runCommand(x, env) {
  let script = x.text.replace(/\$([A-Za-z_][A-Za-z0-9_]*)/g, (_, name) => {
    try { return shellQuote(show(env.get(name))); } catch { return '$' + name; }
  });
  const r = cp.spawnSync('/bin/bash', ['-lc', script], {encoding:'utf8', input:''});
  if (x.capture) {
    const obj = {__hushObj:true, stdout:r.stdout || '', stderr:r.stderr || ''};
    if ((r.status ?? 0) !== 0) obj.error = {__hushObj:true, status:r.status ?? 1};
    return obj;
  }
  process.stdout.write(r.stdout || ''); process.stderr.write(r.stderr || '');
  return r.status ?? 0;
}
function shellQuote(s) { return "'" + String(s).replace(/'/g, "'\\''") + "'"; }

function astString(n) {
  if (!n) return '';
  switch(n.type) {
    case 'program': return n.body.map(astString).join('\n');
    case 'let': return `let ${n.name} = ${astString(n.expr)}`;
    case 'assign': return `${astString(n.target)} = ${astString(n.expr)}`;
    case 'expr': return astString(n.expr);
    case 'lit': return typeof n.value === 'string' ? JSON.stringify(n.value) : show(n.value);
    case 'var': return n.name;
    case 'bin': return `(${astString(n.left)} ${n.op} ${astString(n.right)})`;
    case 'un': return `${n.op} ${astString(n.expr)}`;
    case 'call': return `${astString(n.callee)}(${n.args.map(astString).join(', ')})`;
    case 'prop': return `${astString(n.obj)}.${n.name}`;
    case 'index': return `${astString(n.obj)}[${astString(n.ix)}]`;
    case 'array': return `[${n.vals.map(astString).join(', ')}]`;
    case 'dict': return `@[${n.pairs.map(([k,v])=>`${k}: ${astString(v)}`).join(', ')}]`;
    case 'func': return `function(${n.params.join(', ')}) ... end`;
    case 'cmd': return `{ ${n.text.trim()} }`;
    default: return n.type;
  }
}

function runFile(file, argv, flags={}) {
  const src = fs.readFileSync(file, 'utf8');
  const toks = tokenize(src, file);
  if (flags.lex) {
    console.log('--------------------------------------------------');
    for (const t of toks) if (t.type !== 'eof' && t.type !== 'sep') console.log(`${file} (line ${t.line}, column ${t.col}):\t${rawToken(t)}`);
    console.log('--------------------------------------------------');
  }
  const ast = new Parser(toks, src).parseProgram();
  if (flags.ast) { console.log('--------------------------------------------------'); console.log(`AST for ${file}`); console.log(astString(ast)); console.log('--------------------------------------------------'); }
  if (flags.program) { console.log('--------------------------------------------------'); console.log(`Program for ${file}`); console.log(astString(ast)); console.log('--------------------------------------------------'); }
  if (flags.check) return null;
  const r = evalProgram(ast, baseEnv(argv, file));
  return r instanceof Ret ? r.v : r;
}

function main() {
  const args = process.argv.slice(2), flags = {};
  const rest = [];
  for (const a of args) {
    if (a === '-h' || a === '--help') { usage(); return; }
    else if (a === '-V' || a === '--version') { console.log(VERSION); return; }
    else if (a === '--lex') flags.lex = true;
    else if (a === '--ast') flags.ast = true;
    else if (a === '--program') flags.program = true;
    else if (a === '--check') flags.check = true;
    else rest.push(a);
  }
  if (rest.length === 0) return;
  try { runFile(rest[0], rest.slice(1), flags); }
  catch (e) { console.error(`Error: ${e.message}`); process.exit(2); }
}
main();
