#!/usr/bin/env node
"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");

const HELP = `Universal multi-language runner and REPL

Usage: executable [OPTIONS] [ARGS]...

Arguments:
  [ARGS]...  Positional arguments (language, code, or file)

Options:
  -V, --version      Print version information and exit
  -l, --lang <LANG>  Explicitly choose the language to execute
  -f, --file <PATH>  Execute code from the provided file path
  -c, --code <CODE>  Execute the provided code snippet
      --no-detect    Disable heuristic language detection
  -h, --help         Print help`;

const VERSION = `run-kit 0.3.2
Universal multi-language runner and smart REPL
author: Esubalew Chekol <esubalewchekol6@gmail.com>
homepage: https://esubalew.et
repository: https://github.com/Esubaalew/run
license: Apache-2.0
commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)
built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]
rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)`;

const LANGS = new Map([
  ["js", "js"], ["javascript", "js"], ["node", "js"], ["nodejs", "js"], ["mjs", "js"], ["cjs", "js"],
  ["bash", "bash"], ["sh", "bash"], ["shell", "bash"],
  ["py", "python"], ["python", "python"], ["python3", "python"],
  ["ts", "typescript"], ["typescript", "typescript"],
  ["rb", "ruby"], ["ruby", "ruby"],
  ["pl", "perl"], ["perl", "perl"],
  ["php", "php"], ["lua", "lua"],
  ["go", "go"], ["golang", "go"],
  ["rs", "rust"], ["rust", "rust"],
  ["c", "c"], ["h", "c"],
  ["cpp", "cpp"], ["cc", "cpp"], ["cxx", "cpp"], ["hpp", "cpp"],
  ["java", "java"], ["hs", "haskell"], ["haskell", "haskell"],
  ["r", "r"],
]);

const EXT_LANG = new Map([
  [".js", "js"], [".mjs", "js"], [".cjs", "js"],
  [".ts", "typescript"],
  [".sh", "bash"], [".bash", "bash"],
  [".py", "python"],
  [".rb", "ruby"],
  [".pl", "perl"],
  [".php", "php"],
  [".lua", "lua"],
  [".go", "go"],
  [".rs", "rust"],
  [".c", "c"],
  [".cpp", "cpp"], [".cc", "cpp"], [".cxx", "cpp"],
  [".java", "java"], [".hs", "haskell"],
  [".r", "r"], [".R", "r"],
]);

function parserError(msg, usage = false) {
  console.error(`error: ${msg}`);
  if (usage) {
    console.error("");
    console.error("  tip: to pass '--bad' as a value, use '-- --bad'");
    console.error("");
    console.error("Usage: executable [OPTIONS] [ARGS]...");
  }
  console.error("");
  console.error("For more information, try '--help'.");
  process.exit(2);
}

function parse(argv) {
  const opts = { lang: null, file: null, code: null, noDetect: false, args: [] };
  let positionalOnly = false;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (positionalOnly) {
      opts.args.push(a);
    } else if (a === "--") {
      positionalOnly = true;
    } else if (a === "-h" || a === "--help") {
      console.log(HELP);
      process.exit(0);
    } else if (a === "-V" || a === "--version") {
      console.log(VERSION);
      process.exit(0);
    } else if (a === "-l" || a === "--lang") {
      if (i + 1 >= argv.length || argv[i + 1].startsWith("-")) parserError("a value is required for '--lang <LANG>' but none was supplied");
      opts.lang = argv[++i];
    } else if (a === "-f" || a === "--file") {
      if (i + 1 >= argv.length || argv[i + 1].startsWith("-")) parserError("a value is required for '--file <PATH>' but none was supplied");
      opts.file = argv[++i];
    } else if (a === "-c" || a === "--code") {
      if (i + 1 >= argv.length || argv[i + 1].startsWith("-")) parserError("a value is required for '--code <CODE>' but none was supplied");
      opts.code = argv[++i];
    } else if (a === "--no-detect") {
      opts.noDetect = true;
    } else if (a.startsWith("-")) {
      parserError(`unexpected argument '${a}' found`, a === "--bad");
    } else {
      opts.args.push(a);
    }
  }
  return opts;
}

function canon(lang) {
  if (!lang) return null;
  return LANGS.get(String(lang).toLowerCase()) || String(lang).toLowerCase();
}

function detectCode(code) {
  const s = code.trim();
  if (/^(echo|printf|cat|grep|sed|awk|ls|pwd|cd|tr)\b/.test(s) || s.includes("#!/bin/sh") || s.includes("#!/usr/bin/env bash")) return "bash";
  if (/\b(console\.log|require\s*\(|import\s+.*from|let\s+|const\s+|var\s+|=>)\b/.test(s) || s.includes("console.log")) return "js";
  if (/^\s*puts\b/.test(s)) return "ruby";
  if (/^\s*print\s*\(/.test(s)) return "lua";
  return "python";
}

function detectFile(file) {
  return EXT_LANG.get(path.extname(file)) || "python";
}

function run(cmd, args, extra = {}) {
  const r = spawnSync(cmd, args, { stdio: "inherit", ...extra });
  if (r.error) return 127;
  return typeof r.status === "number" ? r.status : 1;
}

function unavailable(lang) {
  const messages = {
    python: "python is not available in the js-mandated arm",
    go: "Error: Go support requires the `go` executable. Install it from https://go.dev/dl/ and ensure it is on your PATH.",
    rust: "Error: Rust support requires the `rustc` executable. Install it via Rustup and ensure it is on your PATH.",
    java: "Error: Java support requires the `javac` compiler. Install the JDK from https://adoptium.net/ or your vendor of choice and ensure it is on your PATH.",
    php: "Error: PHP support requires the `php` CLI executable. Install PHP and ensure it is on your PATH.",
    lua: "Error: Lua support requires the `lua` executable. Install it from https://www.lua.org/download.html and ensure it is on your PATH.",
    r: "Error: R support requires the `Rscript` executable. Install R from https://cran.r-project.org/ and ensure `Rscript` is on your PATH.",
    haskell: "Error: Haskell support requires the `runghc` executable. Install the GHC toolchain from https://www.haskell.org/ghc/ (or via ghcup) and ensure `runghc` is on your PATH.",
  };
  if (messages[lang]) console.error(messages[lang]);
  return lang === "python" || lang === "ruby" || lang === "perl" || lang === "typescript" ? 127 : 1;
}

function tempDir(prefix) {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

function runC(code, isCpp, fromFile) {
  const dir = tempDir(isCpp ? "run-cpp" : "run-c");
  const src = path.join(dir, isCpp ? "main.cpp" : "main.c");
  const bin = path.join(dir, "main");
  let body = code;
  if (!fromFile && !/\bmain\s*\(/.test(code)) {
    body = isCpp
      ? `#include <iostream>\n#include <cstdio>\nint main() {\n${code}\nreturn 0;\n}\n`
      : `#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\nint main() {\n${code}\nreturn 0;\n}\n`;
  }
  fs.writeFileSync(src, body);
  const compiler = isCpp ? "g++" : "gcc";
  const cr = spawnSync(compiler, [src, "-o", bin], { stdio: "inherit" });
  if (cr.status !== 0) return typeof cr.status === "number" ? cr.status : 1;
  return run(bin, []);
}

function execute(lang, mode, payload) {
  switch (lang) {
    case "js":
      return mode === "file" ? run("node", [payload]) : run("node", ["-e", payload]);
    case "bash":
      return mode === "file" ? run("bash", [payload]) : run("bash", ["-c", payload]);
    case "c":
      return runC(mode === "file" ? fs.readFileSync(payload, "utf8") : payload, false, mode === "file");
    case "cpp":
      return runC(mode === "file" ? fs.readFileSync(payload, "utf8") : payload, true, mode === "file");
    default:
      return unavailable(lang);
  }
}

function main() {
  const opts = parse(process.argv.slice(2));
  if (opts.code && opts.file) {
    console.error("Error: --code/--inline cannot be combined with --file");
    process.exit(1);
  }
  if (opts.code && opts.args.length) {
    console.error("Error: Unexpected positional arguments after specifying --code");
    process.exit(1);
  }
  if (opts.file && opts.args.length) {
    console.error("Error: Unexpected positional arguments when --file is present");
    process.exit(1);
  }

  let lang = canon(opts.lang);
  let mode = null;
  let payload = null;

  if (opts.code != null) {
    mode = "code";
    payload = opts.code;
    if (!lang) lang = opts.noDetect ? "python" : detectCode(payload);
  } else if (opts.file != null) {
    mode = "file";
    payload = opts.file;
    if (!lang) lang = opts.noDetect ? "python" : detectFile(payload);
  } else if (opts.args.length === 0) {
    process.exit(unavailable("python"));
  } else {
    const firstLang = canon(opts.args[0]);
    if (opts.lang) {
      mode = "code";
      payload = opts.args.join(" ");
    } else if (LANGS.has(String(opts.args[0]).toLowerCase())) {
      lang = firstLang;
      mode = "code";
      payload = opts.args.slice(1).join(" ");
    } else if (opts.args.length === 1 && fs.existsSync(opts.args[0]) && !opts.noDetect) {
      mode = "file";
      payload = opts.args[0];
      lang = detectFile(payload);
    } else {
      mode = "code";
      payload = opts.args.join(" ");
      lang = opts.noDetect ? "python" : detectCode(payload);
    }
    if (!lang) lang = opts.noDetect ? "python" : detectCode(payload || "");
  }

  process.exit(execute(lang, mode, payload));
}

main();
