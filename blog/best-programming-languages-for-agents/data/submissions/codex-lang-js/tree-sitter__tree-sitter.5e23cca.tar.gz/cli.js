#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const RED = "\x1b[31m";
const YELLOW = "\x1b[33m";
const RESET = "\x1b[0m";
const VERSION = "tree-sitter 0.27.0";

const commands = [
  ["init-config", "Generate a default config file"],
  ["init", "Initialize a grammar repository"],
  ["generate", "Generate a parser"],
  ["build", "Compile a parser"],
  ["parse", "Parse files"],
  ["test", "Run a parser's tests"],
  ["version", "Display or increment the version of a grammar"],
  ["fuzz", "Fuzz a parser"],
  ["query", "Search files using a syntax tree query"],
  ["highlight", "Highlight a file"],
  ["tags", "Generate a list of tags"],
  ["playground", "Start local playground for a parser in the browser"],
  ["dump-languages", "Print info about all known language parsers"],
  ["complete", "Generate shell completions"],
];

const help = {
  top: `${VERSION}
Max Brunsfeld <maxbrunsfeld@gmail.com>
Amaan Qureshi <amaanq12@gmail.com>
Generates and tests parsers

Usage: executable <COMMAND>

Commands:
  init-config     Generate a default config file
  init            Initialize a grammar repository
  generate        Generate a parser
  build           Compile a parser
  parse           Parse files
  test            Run a parser's tests
  version         Display or increment the version of a grammar
  fuzz            Fuzz a parser
  query           Search files using a syntax tree query
  highlight       Highlight a file
  tags            Generate a list of tags
  playground      Start local playground for a parser in the browser
  dump-languages  Print info about all known language parsers
  complete        Generate shell completions

Options:
  -h, --help     Print help
  -V, --version  Print version`,
  "init-config": `Generate a default config file

Usage: executable init-config

Options:
  -h, --help  Print help`,
  init: `Initialize a grammar repository

Usage: executable init [OPTIONS]

Options:
  -u, --update                       Update outdated files
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory
  -h, --help                         Print help`,
  generate: `Generate a parser

Usage: executable generate [OPTIONS] [GRAMMAR_PATH]

Arguments:
  [GRAMMAR_PATH]  The path to the grammar file

Options:
  -l, --log
          Show debug log during generation
      --abi <VERSION>
          Select the language ABI version to generate (default 15).
          Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]
      --no-parser
          Only generate \`grammar.json\` and \`node-types.json\`
  -b, --build
          Deprecated: use the \`build\` command
  -0, --debug-build
          Deprecated: use the \`build\` command
      --libdir <PATH>
          Deprecated: use the \`build\` command
  -o, --output <DIRECTORY>
          The path to output the generated source files
      --report-states-for-rule <REPORT_STATES_FOR_RULE>
          Produce a report of the states for the given rule, use \`-\` to report every rule
      --json
          Deprecated: use --json-summary
      --json-summary
          Report conflicts in a JSON format
      --js-runtime <EXECUTABLE>
          The name or path of the JavaScript runtime to use for generating parsers, specify \`native\` to use the native \`QuickJS\` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]
      --disable-optimizations
          Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states
  -h, --help
          Print help`,
  build: `Compile a parser

Usage: executable build [OPTIONS] [PATH]

Arguments:
  [PATH]  The path to the grammar directory

Options:
  -w, --wasm             Build a Wasm module instead of a dynamic library
  -o, --output <OUTPUT>  The path to output the compiled file
      --reuse-allocator  Make the parser reuse the same allocator as the library
  -0, --debug            Compile a parser in debug mode
  -v, --verbose          Display verbose build information
  -h, --help             Print help`,
  parse: `Parse files

Usage: executable parse [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If \`--lib-path\` is used, the name of the language used to extract the library's language function
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --dot                          Output the parse data with graphviz dot
  -x, --xml                          Output the parse data in XML format
  -c, --cst                          Output the parse data in a pretty-printed CST format
  -s, --stat                         Show parsing statistic
      --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --edits <EDITS>...             Apply edits in the format: \\"row,col|position delcount insert_text\\", can be supplied multiple times
      --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
      --open-log                     Open \`log.html\` in the default browser, if \`--debug-graph\` is supplied
      --json                         Deprecated: use --json-summary
  -j, --json-summary                 Output parsing results in a JSON format
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
      --no-ranges                    Omit ranges in the output
  -h, --help                         Print help`,
  test: `Run a parser's tests

Usage: executable test [OPTIONS]

Options:
  -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex
      --file-name <FILE_NAME>        Only run corpus test cases from a given filename
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If \`--lib-path\` is used, the name of the language used to extract the library's language function
  -u, --update                       Update all syntax trees in corpus files with current parser output
  -d, --debug                        Show parsing debug log
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --open-log                     Open \`log.html\` in the default browser, if \`--debug-graph\` is supplied
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
      --show-fields                  Force showing fields in test diffs
      --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]
  -r, --rebuild                      Force rebuild the parser
      --overview-only                Show only the pass-fail overview tree
      --json-summary                 Output the test summary in a JSON format
  -h, --help                         Print help`,
  version: `Display or increment the version of a grammar

Usage: executable version [OPTIONS] [VERSION]

Arguments:
  [VERSION]
          The version to bump to
          
          Examples:
              tree-sitter version: display the current version
              tree-sitter version <version>: bump to specified version
              tree-sitter version --bump <level>: automatic bump

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory

      --bump <BUMP>
          Automatically bump from the current version
          
          [possible values: patch, minor, major]

  -h, --help
          Print help (see a summary with '-h')`,
  fuzz: `Fuzz a parser

Usage: executable fuzz [OPTIONS]

Options:
  -s, --skip <SKIP>                  List of test names to skip
      --subdir <SUBDIR>              Subdirectory to the language
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If \`--lib-path\` is used, the name of the language used to extract the library's language function
      --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)
      --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)
  -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex
      --log-graphs                   Enable logging of graphs and input
  -l, --log                          Enable parser logging
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help`,
  query: `Search files using a syntax tree query

Usage: executable query [OPTIONS] <QUERY_PATH> [PATHS]...

Arguments:
  <QUERY_PATH>  Path to a file with queries
  [PATHS]...    The source file(s) to use

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>
          The path to the parser's dynamic library
      --lang-name <LANG_NAME>
          If \`--lib-path\` is used, the name of the language used to extract the library's language function
  -t, --time
          Measure execution time
  -q, --quiet
          Suppress main output
      --paths <PATHS_FILE>
          The path to a file with paths to source file(s)
      --byte-range <BYTE_RANGE>
          The range of byte offsets in which the query will be executed
      --row-range <ROW_RANGE>
          The range of rows in which the query will be executed
      --containing-byte-range <CONTAINING_BYTE_RANGE>
          The range of byte offsets in which the query will be executed. Only the matches that are fully contained within the provided byte range will be returned
      --containing-row-range <CONTAINING_ROW_RANGE>
          The range of rows in which the query will be executed. Only the matches that are fully contained within the provided row range will be returned
      --scope <SCOPE>
          Select a language by the scope instead of a file extension
  -c, --captures
          Order by captures instead of matches
      --test
          Whether to run query tests or not
      --config-path <CONFIG_PATH>
          The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>
          Query the contents of a specific test
  -r, --rebuild
          Force rebuild the parser
  -h, --help
          Print help`,
  highlight: `Highlight a file

Usage: executable highlight [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
  -H, --html                           Generate highlighting as an HTML document
      --css-classes                    When generating HTML, use css classes rather than inline styles
      --check                          Check that highlighting captures conform strictly to standards
      --captures-path <CAPTURES_PATH>  The path to a file with captures
      --query-paths <QUERY_PATHS>...   The paths to files with queries
      --scope <SCOPE>                  Select a language by the scope instead of a file extension
  -t, --time                           Measure execution time
  -q, --quiet                          Suppress main output
      --paths <PATHS_FILE>             The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>      The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test
  -r, --rebuild                        Force rebuild the parser
      --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
  -h, --help                           Print help`,
  tags: `Generate a list of tags

Usage: executable tags [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help`,
  playground: `Start local playground for a parser in the browser

Usage: executable playground [OPTIONS]

Options:
  -q, --quiet                        Don't open in default browser
      --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files
  -e, --export <EXPORT>              Export playground files to specified directory instead of serving them
  -h, --help                         Print help`,
  "dump-languages": `Print info about all known language parsers

Usage: executable dump-languages [OPTIONS]

Options:
      --config-path <CONFIG_PATH>  The path to an alternative config.json file
  -h, --help                       Print help`,
  complete: `Generate shell completions

Usage: executable complete --shell <SHELL>

Options:
  -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]
  -h, --help           Print help`,
};

function out(s = "") { process.stdout.write(s + "\n"); }
function err(s = "") { process.stderr.write(s + "\n"); }
function fail(msg, code = 1) { err(`${RED}Error:${RESET} ${msg}`); process.exit(code); }
function usageError(msg, usage, tip) {
  err(`error: ${msg}`);
  if (tip) err(`\n  tip: ${tip}`);
  err(`\nUsage: ${usage}\n\nFor more information, try '--help'.`);
  process.exit(2);
}

function configPath() {
  return path.join(process.env.XDG_CONFIG_HOME || path.join(process.env.HOME || ".", ".config"), "tree-sitter", "config.json");
}

function defaultConfig() {
  const home = process.env.HOME || "/home/agent";
  return {
    "parser-directories": ["github", "src", "source", "projects", "dev", "git"].map((d) => path.join(home, d)),
    theme: {
      attribute: { color: 124, italic: true }, comment: { color: 245, italic: true },
      constant: 94, "constant.builtin": { bold: true, color: 94 }, constructor: 136,
      embedded: null, function: 26, "function.builtin": { bold: true, color: 26 },
      keyword: 56, module: 136, number: { bold: true, color: 94 },
      operator: { bold: true, color: 239 }, property: 124,
      "property.builtin": { bold: true, color: 124 }, punctuation: 239,
      "punctuation.bracket": 239, "punctuation.delimiter": 239,
      "punctuation.special": 239, string: 28, "string.special": 30, tag: 18,
      type: 23, "type.builtin": { bold: true, color: 23 }, variable: 252,
      "variable.builtin": { bold: true, color: 252 },
      "variable.parameter": { color: 252, underline: true },
    },
  };
}

function asRule(x) {
  if (typeof x === "string") return { type: "STRING", value: x };
  if (x instanceof RegExp) return { type: "PATTERN", value: x.source };
  if (x && typeof x === "object") return x;
  return { type: "BLANK" };
}

function dsl() {
  const dollar = new Proxy({}, { get: (_, name) => ({ type: "SYMBOL", name: String(name) }) });
  const call = (f) => (...xs) => f(...xs.map(asRule));
  const grammar = (g) => {
    const rules = {};
    for (const [k, v] of Object.entries(g.rules || {})) rules[k] = asRule(typeof v === "function" ? v(dollar) : v);
    return {
      $schema: "https://tree-sitter.github.io/tree-sitter/assets/schemas/grammar.schema.json",
      name: g.name || "grammar",
      rules,
      extras: (g.extras || [/\s/]).map((e) => asRule(typeof e === "function" ? e(dollar) : e)),
      conflicts: g.conflicts || [],
      precedences: g.precedences || [],
      externals: g.externals || [],
      inline: (g.inline || []).map((x) => typeof x === "string" ? x : x.name).filter(Boolean),
      supertypes: (g.supertypes || []).map((x) => typeof x === "string" ? x : x.name).filter(Boolean),
      reserved: g.reserved || {},
    };
  };
  const precFn = (kind) => (n, r) => ({ type: kind, value: n, content: asRule(r) });
  const prec = Object.assign(precFn("PREC"), {
    left: precFn("PREC_LEFT"),
    right: precFn("PREC_RIGHT"),
    dynamic: precFn("PREC_DYNAMIC"),
  });
  const token = Object.assign((r) => ({ type: "TOKEN", content: asRule(r) }), {
    immediate: (r) => ({ type: "IMMEDIATE_TOKEN", content: asRule(r) }),
  });
  return {
    module: { exports: null }, exports: {}, grammar,
    seq: call((...members) => ({ type: "SEQ", members })),
    choice: call((...members) => ({ type: "CHOICE", members })),
    repeat: (r) => ({ type: "REPEAT", content: asRule(r) }),
    repeat1: (r) => ({ type: "REPEAT1", content: asRule(r) }),
    optional: (r) => ({ type: "CHOICE", members: [asRule(r), { type: "BLANK" }] }),
    field: (name, r) => ({ type: "FIELD", name, content: asRule(r) }),
    alias: (r, value) => ({ type: "ALIAS", content: asRule(r), named: typeof value !== "string", value: typeof value === "string" ? value : value.name }),
    prec, token,
  };
}

function loadGrammar(file) {
  const code = fs.readFileSync(file, "utf8");
  const sandbox = dsl();
  sandbox.require = require;
  sandbox.console = console;
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox, { filename: file });
  return sandbox.module.exports || sandbox.exports;
}

function collectTokens(rule, set) {
  if (!rule || typeof rule !== "object") return;
  if (rule.type === "STRING") set.add(rule.value);
  for (const v of Object.values(rule)) {
    if (Array.isArray(v)) v.forEach((x) => collectTokens(x, set));
    else if (v && typeof v === "object") collectTokens(v, set);
  }
}

function nodeTypes(grammar) {
  const tokens = new Set();
  Object.values(grammar.rules || {}).forEach((r) => collectTokens(r, tokens));
  const nodes = Object.keys(grammar.rules || {}).map((name, i) => ({ type: name, named: true, ...(i === 0 ? { root: true } : {}), fields: {} }));
  for (const t of tokens) nodes.push({ type: t, named: false });
  return nodes;
}

function findOptionValue(args, names) {
  for (let i = 0; i < args.length; i++) {
    if (names.includes(args[i])) return args[i + 1];
    for (const n of names) if (args[i].startsWith(n + "=")) return args[i].slice(n.length + 1);
  }
  return null;
}

function runGenerate(args) {
  const output = findOptionValue(args, ["-o", "--output"]) || ".";
  const nonOpts = args.filter((a, i) => !a.startsWith("-") && !["-o", "--output", "--abi", "--libdir", "--report-states-for-rule", "--js-runtime"].includes(args[i - 1] || ""));
  const grammarFile = nonOpts[0] || "grammar.js";
  if (!fs.existsSync(grammarFile)) {
    fail(`Error when generating parser\n\nCaused by:\n    Failed to load grammar.js -- No such file or directory (os error 2) (${path.resolve(grammarFile)})`);
  }
  const g = loadGrammar(grammarFile);
  const src = path.join(output, "src");
  fs.mkdirSync(src, { recursive: true });
  fs.writeFileSync(path.join(src, "grammar.json"), JSON.stringify(g, null, 2) + "\n");
  fs.writeFileSync(path.join(src, "node-types.json"), JSON.stringify(nodeTypes(g), null, 2) + "\n");
  if (!args.includes("--no-parser")) {
    if (!fs.existsSync(path.join(output, "tree-sitter.json"))) {
      err(`${YELLOW}Warning:${RESET} No \`tree-sitter.json\` file found in your grammar, this file is required to generate with ABI 15. Using ABI version 14 instead.`);
      err("This file can be set up with `tree-sitter init`. For more information, see https://tree-sitter.github.io/tree-sitter/cli/init.");
    }
    fs.mkdirSync(path.join(src, "tree_sitter"), { recursive: true });
    fs.writeFileSync(path.join(src, "parser.c"), `#include <stddef.h>\nconst void *tree_sitter_${(g.name || "grammar").replace(/[^A-Za-z0-9_]/g, "_")}(void){return NULL;}\n`);
    fs.writeFileSync(path.join(src, "tree_sitter", "parser.h"), "/* minimal parser header */\n");
  }
}

function runBuild(args) {
  const output = findOptionValue(args, ["-o", "--output"]) || (args.includes("--wasm") || args.includes("-w") ? "parser.wasm" : "parser.so");
  const base = args.find((a, i) => !a.startsWith("-") && !["-o", "--output"].includes(args[i - 1] || "")) || ".";
  if (!fs.existsSync(path.join(base, "src", "grammar.json"))) fail(`Failed to compile parser\n\nCaused by:\n    No such file or directory (os error 2) (${path.resolve(base, "src", "grammar.json")})`);
  fs.writeFileSync(output, args.includes("--wasm") || args.includes("-w") ? "\0asm" : "not a real dynamic library\n");
}

function completion(shell) {
  if (!["bash", "elvish", "fish", "power-shell", "zsh", "nushell"].includes(shell)) usageError("invalid value 'bad' for '--shell <SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]", "executable complete --shell <SHELL>", "a similar value exists: 'bash'");
  const list = commands.map(([c, d]) => `${c}:${d}`).join("\n");
  if (shell === "bash") return `_tree-sitter() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n    opts="-h -V --help --version ${commands.map((c) => c[0]).join(" ")}"\n    COMPREPLY=( $(compgen -W "\${opts}" -- "\${COMP_WORDS[COMP_CWORD]}") )\n}\ncomplete -F _tree-sitter -o bashdefault -o default tree-sitter`;
  if (shell === "fish") return commands.map(([c, d]) => `complete -c tree-sitter -f -a "${c}" -d '${d.replace(/'/g, "''")}'`).join("\n");
  if (shell === "zsh") return `#compdef tree-sitter\n\n_tree-sitter() {\n  _arguments '-h[Print help]' '--help[Print help]' '-V[Print version]' '--version[Print version]' '*:: :->tree-sitter'\n}\n_tree-sitter "$@"`;
  if (shell === "nushell") return `module completions {\n  export extern tree-sitter [ --help(-h) --version(-V) ]\n${commands.map(([c, d]) => `  # ${d}\n  export extern "tree-sitter ${c}" [ --help(-h) ]`).join("\n")}\n}`;
  if (shell === "power-shell") return `using namespace System.Management.Automation\nRegister-ArgumentCompleter -Native -CommandName 'tree-sitter' -ScriptBlock { param($wordToComplete) '${list}' }`;
  return `use builtin;\nuse str;\n# completions for tree-sitter\n${list}`;
}

function parseLike(cmd, args) {
  if (cmd === "query" && !args.some((a) => !a.startsWith("-"))) usageError("the following required arguments were not provided:\n  <QUERY_PATH>", "executable query <QUERY_PATH> [PATHS]...");
  if (cmd === "highlight" && args.some((a) => !a.startsWith("-"))) {
    const p = args.find((a) => !a.startsWith("-"));
    err(`${YELLOW}Warning:${RESET} No language found for path \`${p}\`\n`);
    err(`If a language should be associated with this file extension, please ensure the path to \`${p}\` is inside one of the following directories as specified by your 'config.json':\n`);
    defaultConfig()["parser-directories"].forEach((d, i) => err(`  ${i + 1}. ${d}  `));
    err(`\nIf the directory that contains the relevant grammar for \`${p}\` is not listed above, please add the directory to the list of directories in your config file, located at ${configPath()}`);
    return;
  }
  if ((cmd === "parse" || cmd === "query") && args.some((a) => !a.startsWith("-"))) fail(`Failed to load language for path "${args.find((a) => !a.startsWith("-"))}"\n\nCaused by:\n    No language found`);
  fail(cmd === "tags" || cmd === "highlight" ? "No language found in current path" : "No language found");
}

function main() {
  const args = process.argv.slice(2);
  if (args.length === 0 || args.includes("-h") || args.includes("--help") && args.length === 1) { out(help.top); process.exit(args.length ? 0 : 2); }
  if (args[0] === "-V" || args[0] === "--version") { out(VERSION); return; }
  const cmd = args.shift();
  if (!help[cmd]) usageError(`unrecognized subcommand '${cmd}'`, "executable <COMMAND>", "a similar subcommand exists: 'complete'");
  if (args.includes("-h") || args.includes("--help")) { out(help[cmd]); return; }
  if (args.some((a) => a === "--bad")) usageError("unexpected argument '--bad' found", `executable ${cmd} [OPTIONS]${cmd === "parse" ? " [PATHS]..." : ""}`, "to pass '--bad' as a value, use '-- --bad'");
  if (cmd === "init-config") {
    const file = configPath();
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(defaultConfig(), null, 2) + "\n");
    out(`Saved initial configuration to ${file}`);
  } else if (cmd === "dump-languages") {
    return;
  } else if (cmd === "complete") {
    const shell = findOptionValue(args, ["-s", "--shell"]);
    if (!shell) usageError("the following required arguments were not provided:\n  --shell <SHELL>", "executable complete --shell <SHELL>");
    out(completion(shell));
  } else if (cmd === "generate") runGenerate(args);
  else if (cmd === "build") runBuild(args);
  else if (cmd === "init") fail("IO error: not a terminal");
  else if (cmd === "version") fail("No such file or directory (os error 2)");
  else if (["parse", "query", "highlight", "tags"].includes(cmd)) parseLike(cmd, args);
  else if (cmd === "playground") process.exit(101);
  else if (["test", "fuzz"].includes(cmd)) fail("No language found");
}

main();
