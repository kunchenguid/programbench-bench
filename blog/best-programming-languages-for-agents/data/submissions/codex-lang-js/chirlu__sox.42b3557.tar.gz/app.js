#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const VERSION = 'SoX v14.4.2';

process.stdout.on('error', e => { if (e.code === 'EPIPE') process.exit(0); throw e; });
process.stderr.on('error', e => { if (e.code === 'EPIPE') process.exit(0); throw e; });

function out(s = '') { process.stdout.write(String(s) + '\n'); }
function err(s = '') { process.stderr.write(String(s) + '\n'); }
function die(msg, code = 1) { err(`./executable FAIL ${msg}`); process.exit(code); }

function showVersion() { out(`./executable:      ${VERSION}`); }

function showHelp(soxi = false) {
  showVersion();
  out('');
  if (soxi) {
    out('Usage: soxi [-V[level]] [-T] [-t|-r|-c|-s|-d|-D|-b|-B|-p|-e|-a] infile1 ...');
    out('');
    out('-V[n]\tIncrement or set verbosity level (default is 2)');
    out('-T\tWith -s, -d or -D, display the total across all given files');
    out('');
    out('-t\tShow detected file-type');
    out('-r\tShow sample-rate');
    out('-c\tShow number of channels');
    out('-s\tShow number of samples (0 if unavailable)');
    out('-d\tShow duration in hours, minutes and seconds (0 if unavailable)');
    out('-D\tShow duration in seconds (0 if unavailable)');
    out('-b\tShow number of bits per sample (0 if not applicable)');
    out('-B\tShow the bitrate averaged over the whole file (0 if unavailable)');
    out('-p\tShow estimated sample precision in bits');
    out('-e\tShow the name of the audio encoding');
    out('-a\tShow file comments (annotations) if available)');
    out('');
    out('With no options, as much information as is available is shown for');
    out('each given file.');
    return;
  }
  out('Usage summary: [gopts] [[fopts] infile]... [fopts] outfile [effect [effopt]]...');
  out('');
  out('SPECIAL FILENAMES (infile, outfile):');
  out('-                        Pipe/redirect input/output (stdin/stdout); may need -t');
  out('-d, --default-device     Use the default audio device (where available)');
  out("-n, --null               Use the `null' file handler; e.g. with synth effect");
  out("-p, --sox-pipe           Alias for `-t sox -'");
  out('');
  out('GLOBAL OPTIONS (gopts) (can be specified at any point before the first effect):');
  out('--buffer BYTES           Set the size of all processing buffers (default 8192)');
  out("--clobber                Don't prompt to overwrite output file (default)");
  out('--combine concatenate    Concatenate all input files (default for sox, rec)');
  out('-D, --no-dither          Don\'t dither automatically');
  out('-h, --help               Display version number and usage information');
  out('--help-effect NAME       Show usage of effect NAME, or NAME=all for all');
  out('--help-format NAME       Show info on format NAME, or NAME=all for all');
  out('--i, --info              Behave as soxi(1)');
  out('-m, --combine mix        Mix multiple input files (instead of concatenating)');
  out('-M, --combine merge      Merge multiple input files (instead of concatenating)');
  out('--norm                   Guard (see --guard) & normalise');
  out('-q, --no-show-progress   Run in quiet mode; opposite of -S');
  out('--version                Display version number of SoX and exit');
  out('-V[LEVEL]                Increment or set verbosity level (default 2)');
  out('FORMAT OPTIONS (fopts):');
  out('-t|--type FILETYPE       File type of audio');
  out('-e|--encoding ENCODING   Set encoding');
  out('-b|--bits BITS           Encoded sample size in bits');
  out('-c|--channels CHANNELS   Number of channels of audio data; e.g. 2 = stereo');
  out('-r|--rate RATE           Sample rate of audio');
  out('');
  out('AUDIO FILE FORMATS: au raw s16 s32 s8 u8 wav wavpcm');
  out('EFFECTS: channels fade gain norm rate remix repeat reverse silence speed stat stats synth trim vol');
  out('EFFECT OPTIONS (effopts): effect dependent; see --help-effect');
}

function showHelpEffect(name) {
  showVersion(); out(''); out('Effect usage:'); out('');
  const map = {
    synth: 'synth [-j KEY] [-n] [length [offset [phase [p1 [p2 [p3]]]]]]] {type [combine] [[%]freq[k][:|+|/|-[%]freq2[k]] [offset [phase [p1 [p2 [p3]]]]]]}',
    trim: 'trim {position}',
    rate: 'rate [-q|-l|-m|-h|-v] [override-options] RATE[k]',
    channels: 'channels CHANNELS',
    gain: 'gain [flags] gain-dB',
    vol: 'vol GAIN [type [limitergain]]',
    stat: 'stat',
    stats: 'stats',
    fade: 'fade [ type ] fade-in-length [ stop-time [ fade-out-length ] ]',
    reverse: 'reverse',
  };
  if (name === 'all') Object.keys(map).sort().forEach(k => out(`${k}: ${map[k]}`));
  else out(map[name] || `${name || ''}`);
}

function showHelpFormat(name) {
  showVersion(); out('');
  name = (name || '').toLowerCase();
  if (name === 'all') {
    out('AUDIO FILE FORMATS: au raw s16 s32 s8 u8 wav wavpcm');
    return;
  }
  const desc = name === 'raw' ? 'Raw audio' : name === 'au' ? 'Sun audio' : 'Microsoft audio format';
  out(`Format: ${name || 'wav'}`);
  out(`Description: ${desc}`);
  if ((name || 'wav') === 'wav') out('Also handles: wavpcm amb');
  out('Reads: yes');
  out('Writes:');
  out('  16-bit Signed Integer PCM (16-bit precision)');
  out('  24-bit Signed Integer PCM (24-bit precision)');
  out('  32-bit Signed Integer PCM (32-bit precision)');
  out('   8-bit Unsigned Integer PCM (8-bit precision)');
  out('  32-bit Floating Point PCM (25-bit precision)');
}

function parseRate(s) {
  if (s == null) return undefined;
  const m = String(s).trim().toLowerCase().match(/^([0-9]*\.?[0-9]+)\s*([km]?)$/);
  if (!m) return Number(s) || 0;
  let n = parseFloat(m[1]);
  if (m[2] === 'k') n *= 1000;
  if (m[2] === 'm') n *= 1000000;
  return Math.round(n);
}

function parseTime(s, rate) {
  if (s == null) return 0;
  s = String(s);
  if (s.includes(':')) {
    const parts = s.split(':').map(Number);
    let sec = 0;
    for (const p of parts) sec = sec * 60 + (isNaN(p) ? 0 : p);
    return Math.max(0, Math.round(sec * rate));
  }
  const n = parseFloat(s);
  return Math.max(0, Math.round((isNaN(n) ? 0 : n) * rate));
}

function readAll(file) {
  if (file === '-') {
    const chunks = [];
    let b = Buffer.alloc(65536), n;
    try { while ((n = fs.readSync(0, b, 0, b.length, null)) > 0) chunks.push(Buffer.from(b.subarray(0, n))); }
    catch {}
    return Buffer.concat(chunks);
  }
  return fs.readFileSync(file);
}

function detectType(file, forced) {
  if (forced) return forced.toLowerCase();
  if (file === '-n' || file === '-d' || file === '-p') return 'null';
  const ext = path.extname(file || '').replace('.', '').toLowerCase();
  if (['wav', 'wave'].includes(ext)) return 'wav';
  if (['raw', 's16', 's32', 's8', 'u8', 'ub', 'sb'].includes(ext)) return ext;
  if (ext === 'au' || ext === 'snd') return 'au';
  if (ext === 'dat') return 'dat';
  return ext || 'wav';
}

function typeDefaults(type) {
  type = (type || '').toLowerCase();
  if (type === 's8' || type === 'sb') return { bits: 8, encoding: 'signed-integer' };
  if (type === 'u8' || type === 'ub') return { bits: 8, encoding: 'unsigned-integer' };
  if (type === 's16' || type === 'sw') return { bits: 16, encoding: 'signed-integer' };
  if (type === 'u16' || type === 'uw') return { bits: 16, encoding: 'unsigned-integer' };
  if (type === 's24' || type === 's3') return { bits: 24, encoding: 'signed-integer' };
  if (type === 'u24' || type === 'u3') return { bits: 24, encoding: 'unsigned-integer' };
  if (type === 's32' || type === 'sl') return { bits: 32, encoding: 'signed-integer' };
  if (type === 'u32' || type === 'ul') return { bits: 32, encoding: 'unsigned-integer' };
  return {};
}

function emptyAudio(rate = 8000, channels = 1, bits = 32) {
  return { rate, channels, bits, encoding: bits === 8 ? 'unsigned-integer' : 'signed-integer', samples: [], comments: [] };
}

function readWav(buf) {
  if (buf.toString('ascii', 0, 4) !== 'RIFF' && buf.toString('ascii', 0, 4) !== 'RIFX') throw new Error('not a WAVE file');
  const be = buf.toString('ascii', 0, 4) === 'RIFX';
  const u16 = o => be ? buf.readUInt16BE(o) : buf.readUInt16LE(o);
  const u32 = o => be ? buf.readUInt32BE(o) : buf.readUInt32LE(o);
  if (buf.toString('ascii', 8, 12) !== 'WAVE') throw new Error('not a WAVE file');
  let fmt = null, data = null;
  for (let p = 12; p + 8 <= buf.length;) {
    const id = buf.toString('ascii', p, p + 4);
    const len = u32(p + 4);
    const start = p + 8;
    if (id === 'fmt ') fmt = { start, len };
    if (id === 'data') data = { start, len: Math.min(len, buf.length - start) };
    p = start + len + (len & 1);
  }
  if (!fmt) throw new Error('WAVE: missing fmt chunk');
  const audioFormat = u16(fmt.start);
  const channels = u16(fmt.start + 2);
  const rate = u32(fmt.start + 4);
  const bits = u16(fmt.start + 14);
  const samples = [];
  if (data) {
    const bytes = Math.ceil(bits / 8);
    const frames = Math.floor(data.len / (bytes * channels));
    for (let i = 0; i < frames * channels; i++) {
      const o = data.start + i * bytes;
      let v = 0;
      if (audioFormat === 3 && bits === 32) v = be ? buf.readFloatBE(o) : buf.readFloatLE(o);
      else if (bits === 8) v = (buf.readUInt8(o) - 128) / 128;
      else if (bits === 16) v = (be ? buf.readInt16BE(o) : buf.readInt16LE(o)) / 32768;
      else if (bits === 24) {
        v = be ? buf.readIntBE(o, 3) : buf.readIntLE(o, 3); v /= 8388608;
      } else if (bits === 32) v = (be ? buf.readInt32BE(o) : buf.readInt32LE(o)) / 2147483648;
      samples.push(Math.max(-1, Math.min(1, v)));
    }
  }
  return { rate, channels, bits, encoding: audioFormat === 3 ? 'floating-point' : (bits === 8 ? 'unsigned-integer' : 'signed-integer'), samples, comments: [] };
}

function readAu(buf) {
  if (buf.toString('ascii', 0, 4) !== '.snd') throw new Error('not an AU file');
  const off = buf.readUInt32BE(4), size = buf.readUInt32BE(8), enc = buf.readUInt32BE(12);
  const rate = buf.readUInt32BE(16), channels = buf.readUInt32BE(20);
  let bits = enc === 2 ? 8 : enc === 3 ? 16 : enc === 5 ? 32 : 8;
  const bytes = bits / 8, end = size === 0xffffffff ? buf.length : Math.min(buf.length, off + size);
  const samples = [];
  for (let p = off; p + bytes <= end; p += bytes) {
    let v = 0;
    if (enc === 2) v = buf.readInt8(p) / 128;
    else if (enc === 3) v = buf.readInt16BE(p) / 32768;
    else if (enc === 5) v = buf.readInt32BE(p) / 2147483648;
    else v = 0;
    samples.push(Math.max(-1, Math.min(1, v)));
  }
  return { rate, channels, bits, encoding: 'signed-integer', samples, comments: [] };
}

function readRaw(buf, opts) {
  const d = typeDefaults(opts.type);
  const rate = opts.rate || 8000, channels = opts.channels || 1, bits = opts.bits || d.bits || 16;
  const enc = opts.encoding || d.encoding || 'signed-integer';
  const samples = [];
  const bytes = Math.ceil(bits / 8);
  for (let p = 0; p + bytes <= buf.length; p += bytes) {
    let v;
    if (bits === 8 && enc.startsWith('unsigned')) v = (buf.readUInt8(p) - 128) / 128;
    else if (bits === 8) v = buf.readInt8(p) / 128;
    else if (bits === 16) v = buf.readInt16LE(p) / 32768;
    else if (bits === 24) v = buf.readIntLE(p, 3) / 8388608;
    else if (bits === 32) v = buf.readInt32LE(p) / 2147483648;
    else v = 0;
    samples.push(Math.max(-1, Math.min(1, v)));
  }
  return { rate, channels, bits, encoding: enc, samples, comments: [] };
}

function readAudio(file, opts = {}) {
  if (file === '-n') return emptyAudio(opts.rate || 8000, opts.channels || 1, opts.bits || 32);
  const type = detectType(file, opts.type);
  const buf = readAll(file);
  if (type === 'wav' || type === 'wavpcm') return readWav(buf);
  if (type === 'au' || type === 'snd') return readAu(buf);
  return readRaw(buf, { ...opts, type });
}

function clamp16(v) { return Math.max(-32768, Math.min(32767, Math.round(v * 32767))); }
function writeWav(audio, file, opts = {}) {
  const channels = opts.channels || audio.channels || 1;
  const rate = opts.rate || audio.rate || 8000;
  const bits = opts.bits || audio.bits || 16;
  const samples = audio.samples || [];
  const bytes = Math.ceil(bits / 8), dataSize = samples.length * bytes;
  const b = Buffer.alloc(44 + dataSize);
  b.write('RIFF', 0); b.writeUInt32LE(36 + dataSize, 4); b.write('WAVE', 8);
  b.write('fmt ', 12); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20);
  b.writeUInt16LE(channels, 22); b.writeUInt32LE(rate, 24);
  b.writeUInt32LE(rate * channels * bytes, 28); b.writeUInt16LE(channels * bytes, 32);
  b.writeUInt16LE(bits, 34); b.write('data', 36); b.writeUInt32LE(dataSize, 40);
  let p = 44;
  for (const s of samples) {
    const v = Math.max(-1, Math.min(1, s || 0));
    if (bits === 8) b.writeUInt8(Math.max(0, Math.min(255, Math.round(v * 127 + 128))), p);
    else if (bits === 16) b.writeInt16LE(clamp16(v), p);
    else if (bits === 24) b.writeIntLE(Math.max(-8388608, Math.min(8388607, Math.round(v * 8388607))), p, 3);
    else if (bits === 32) b.writeInt32LE(Math.max(-2147483648, Math.min(2147483647, Math.round(v * 2147483647))), p);
    p += bytes;
  }
  writeBuf(file, b);
}

function writeRaw(audio, file, opts = {}) {
  const bits = opts.bits || audio.bits || 16, bytes = Math.ceil(bits / 8);
  const b = Buffer.alloc((audio.samples || []).length * bytes);
  let p = 0;
  for (const s of audio.samples || []) {
    const v = Math.max(-1, Math.min(1, s || 0));
    if (bits === 8 && (opts.encoding || audio.encoding || '').startsWith('unsigned')) b.writeUInt8(Math.max(0, Math.min(255, Math.round(v * 127 + 128))), p);
    else if (bits === 8) b.writeInt8(Math.max(-128, Math.min(127, Math.round(v * 127))), p);
    else if (bits === 16) b.writeInt16LE(clamp16(v), p);
    else if (bits === 24) b.writeIntLE(Math.max(-8388608, Math.min(8388607, Math.round(v * 8388607))), p, 3);
    else if (bits === 32) b.writeInt32LE(Math.max(-2147483648, Math.min(2147483647, Math.round(v * 2147483647))), p);
    p += bytes;
  }
  writeBuf(file, b);
}

function writeBuf(file, b) {
  if (file === '-') fs.writeSync(1, b);
  else fs.writeFileSync(file, b);
}

function writeAudio(audio, file, opts = {}) {
  const type = detectType(file, opts.type);
  if (file === '-n' || type === 'null') return;
  const d = typeDefaults(type);
  opts = { ...d, ...opts };
  const a = { ...audio, rate: opts.rate || audio.rate, channels: opts.channels || audio.channels, bits: opts.bits || audio.bits };
  if (type === 'wav' || type === 'wavpcm') writeWav(a, file, opts);
  else if (type === 'dat') writeDat(a, file);
  else writeRaw(a, file, opts);
}

function writeDat(audio, file) {
  const ch = audio.channels || 1, rate = audio.rate || 8000;
  const frames = Math.floor((audio.samples || []).length / ch);
  const lines = ['; Sample Rate ' + rate, '; Channels ' + ch];
  for (let i = 0; i < frames; i++) {
    const vals = [];
    for (let c = 0; c < ch; c++) vals.push((audio.samples[i * ch + c] || 0).toFixed(8));
    lines.push((i / rate).toFixed(8) + ' ' + vals.join(' '));
  }
  writeBuf(file, Buffer.from(lines.join('\n') + '\n'));
}

function durationString(samples, channels, rate) {
  const sec = samples / Math.max(1, channels) / Math.max(1, rate);
  const h = Math.floor(sec / 3600), m = Math.floor(sec / 60) % 60, s = sec - h * 3600 - m * 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${s.toFixed(2).padStart(5, '0')}`;
}

function soxi(args) {
  let opt = null, total = false, files = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '-T') total = true;
    else if (/^-V/.test(a)) {}
    else if (['-t','-r','-c','-s','-d','-D','-b','-B','-p','-e','-a'].includes(a)) opt = a.slice(1);
    else if (a === '--help' || a === '-h') return showHelp(true);
    else files.push(a);
  }
  if (!files.length) return showHelp(true);
  let totSamp = 0, totDur = 0;
  const infos = files.map(f => {
    const au = readAudio(f, {});
    const frames = Math.floor(au.samples.length / Math.max(1, au.channels));
    totSamp += frames; totDur += frames / au.rate;
    return { f, au, frames, type: detectType(f) };
  });
  if (total && opt && ['s','d','D'].includes(opt)) {
    if (opt === 's') out(totSamp);
    if (opt === 'D') out(totDur.toFixed(6).replace(/0+$/, '').replace(/\.$/, ''));
    if (opt === 'd') out(durationString(Math.round(totDur * 1000), 1, 1000));
    return;
  }
  for (const inf of infos) {
    const { f, au, frames, type } = inf;
    const bytes = fs.existsSync(f) ? fs.statSync(f).size : 0;
    const one = {
      t: type === 'wavpcm' ? 'wav' : type,
      r: au.rate,
      c: au.channels,
      s: frames,
      d: durationString(au.samples.length, au.channels, au.rate),
      D: (frames / au.rate).toFixed(6).replace(/0+$/, '').replace(/\.$/, ''),
      b: au.bits || 0,
      B: frames ? Math.round(bytes * 8 * au.rate / frames) : 0,
      p: au.bits || 0,
      e: au.encoding || 'signed-integer',
      a: (au.comments || []).join('\n')
    };
    if (opt) out(one[opt]);
    else {
      out('');
      out(`Input File     : '${f}'`);
      out(`Channels       : ${au.channels}`);
      out(`Sample Rate    : ${au.rate}`);
      out(`Precision      : ${au.bits}-bit`);
      out(`Duration       : ${one.d} = ${frames} samples ~ ${Math.round(frames * 100 / au.rate) / 100} CDDA sectors`);
      out(`File Size      : ${bytes}`);
      out(`Bit Rate       : ${one.B}`);
      out(`Sample Encoding: ${one.e === 'unsigned-integer' ? `${au.bits}-bit Unsigned Integer PCM` : `${au.bits}-bit Signed Integer PCM`}`);
    }
  }
}

const effectNames = new Set('allpass band bandpass bandreject bass bend biquad chorus channels compand contrast dcshift deemph delay dither divide downsample earwax echo echos equalizer fade fir firfit flanger gain highpass hilbert ladspa loudness lowpass mcompand noiseprof noisered norm oops output overdrive pad phaser pitch rate remix repeat reverb reverse riaa silence sinc speed splice stat stats stretch swap synth tempo treble tremolo trim upsample vad vol'.split(' '));

function synth(args, opts) {
  let len = 0, wave = 'sine', freq = 440;
  if (args.length && !isNaN(parseFloat(args[0]))) len = parseFloat(args.shift());
  for (let i = 0; i < args.length; i++) {
    const a = args[i].toLowerCase();
    if (['sin','sine','square','sawtooth','triangle','noise','whitenoise','brownnoise','pinknoise'].includes(a)) {
      wave = a; const f = args[i + 1]; if (f && /^%?-?[0-9.]+k?/.test(f)) { freq = parseRate(f.replace('%','')); i++; }
    }
  }
  if (!len) len = 0;
  const rate = opts.rate || 8000, channels = opts.channels || 1;
  const frames = Math.max(0, Math.round(len * rate));
  const samples = new Array(frames * channels);
  let seed = 1;
  const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x40000000 - 1);
  for (let i = 0; i < frames; i++) {
    const t = i / rate; let v;
    if (wave.includes('noise')) v = rnd() * 0.4;
    else if (wave.startsWith('square')) v = Math.sin(2 * Math.PI * freq * t) >= 0 ? 0.7 : -0.7;
    else if (wave.startsWith('tri')) v = 2 / Math.PI * Math.asin(Math.sin(2 * Math.PI * freq * t)) * 0.7;
    else if (wave.startsWith('saw')) v = (2 * (freq * t - Math.floor(0.5 + freq * t))) * 0.7;
    else v = Math.sin(2 * Math.PI * freq * t) * 0.7;
    for (let c = 0; c < channels; c++) samples[i * channels + c] = v;
  }
  return { rate, channels, bits: opts.bits || 32, encoding: 'signed-integer', samples, comments: [] };
}

function changeChannels(audio, ch) {
  ch = Math.max(1, Math.floor(ch));
  const old = audio.channels || 1;
  if (ch === old) return { ...audio, channels: ch };
  const frames = Math.floor(audio.samples.length / old), res = [];
  for (let i = 0; i < frames; i++) {
    let avg = 0;
    for (let c = 0; c < old; c++) avg += audio.samples[i * old + c] || 0;
    avg /= old;
    for (let c = 0; c < ch; c++) res.push(c < old ? audio.samples[i * old + c] || 0 : avg);
  }
  return { ...audio, channels: ch, samples: res };
}

function resample(audio, newRate) {
  newRate = parseRate(newRate);
  if (!newRate || newRate === audio.rate) return audio;
  const ch = audio.channels || 1, frames = Math.floor(audio.samples.length / ch);
  const outFrames = Math.round(frames * newRate / audio.rate), res = new Array(outFrames * ch);
  for (let i = 0; i < outFrames; i++) {
    const src = i * audio.rate / newRate, j = Math.floor(src), frac = src - j;
    for (let c = 0; c < ch; c++) {
      const a = audio.samples[Math.min(frames - 1, j) * ch + c] || 0;
      const b = audio.samples[Math.min(frames - 1, j + 1) * ch + c] || a;
      res[i * ch + c] = a + (b - a) * frac;
    }
  }
  return { ...audio, rate: newRate, samples: res };
}

function applyEffects(audio, effects, opts) {
  for (const e of effects) {
    const name = e.name, a = e.args.slice();
    if (name === 'synth') audio = synth(a, { ...opts, rate: audio.rate, channels: audio.channels, bits: audio.bits });
    else if (name === 'channels') audio = changeChannels(audio, parseInt(a[0] || '1', 10));
    else if (name === 'rate') audio = resample(audio, a[a.length - 1]);
    else if (name === 'reverse') {
      const ch = audio.channels || 1, frames = Math.floor(audio.samples.length / ch), res = [];
      for (let i = frames - 1; i >= 0; i--) for (let c = 0; c < ch; c++) res.push(audio.samples[i * ch + c] || 0);
      audio = { ...audio, samples: res };
    } else if (name === 'trim') {
      const ch = audio.channels || 1, start = parseTime(a[0] || '0', audio.rate), len = a[1] ? parseTime(a[1], audio.rate) : null;
      audio = { ...audio, samples: audio.samples.slice(start * ch, len == null ? undefined : (start + len) * ch) };
    } else if (name === 'vol') {
      const g = parseFloat(a[0] || '1'); audio = { ...audio, samples: audio.samples.map(v => Math.max(-1, Math.min(1, v * g))) };
    } else if (name === 'gain') {
      const nums = a.filter(x => /^[-+]?[0-9.]+$/.test(x)); const db = parseFloat(nums[nums.length - 1] || '0'); const g = Math.pow(10, db / 20);
      audio = { ...audio, samples: audio.samples.map(v => Math.max(-1, Math.min(1, v * g))) };
    } else if (name === 'norm') {
      const m = Math.max(0, ...audio.samples.map(v => Math.abs(v))); if (m > 0) audio = { ...audio, samples: audio.samples.map(v => v / m * 0.999) };
    } else if (name === 'fade') {
      let vals = a.filter(x => !/^[qhltp]$/i.test(x)); const fi = parseTime(vals[0] || '0', audio.rate), stop = vals[1] ? parseTime(vals[1], audio.rate) : null, fo = vals[2] ? parseTime(vals[2], audio.rate) : 0;
      const ch = audio.channels || 1, frames = Math.floor(audio.samples.length / ch), end = stop ? Math.min(frames, stop) : frames, startFo = Math.max(0, end - fo);
      const res = audio.samples.slice(0, end * ch);
      for (let i = 0; i < end; i++) {
        let g = 1; if (fi && i < fi) g *= i / fi; if (fo && i >= startFo) g *= Math.max(0, (end - i) / fo);
        for (let c = 0; c < ch; c++) res[i * ch + c] *= g;
      }
      audio = { ...audio, samples: res };
    } else if (name === 'stat' || name === 'stats') {
      const n = audio.samples.length, max = Math.max(0, ...audio.samples.map(Math.abs));
      err(`Samples read:            ${n}`);
      err(`Maximum amplitude:     ${max.toFixed(6)}`);
      err(`Minimum amplitude:    ${Math.min(0, ...audio.samples).toFixed(6)}`);
      err(`Mean    amplitude:     ${(audio.samples.reduce((s,v)=>s+Math.abs(v),0)/Math.max(1,n)).toFixed(6)}`);
    }
  }
  return audio;
}

function combineAudios(audios, mode) {
  if (!audios.length) return emptyAudio();
  if (mode === 'mix' || mode === 'mix-power' || mode === 'merge' || mode === 'multiply') {
    const rate = audios[0].rate, channels = mode === 'merge' ? audios.reduce((s,a)=>s+a.channels,0) : audios[0].channels;
    const frames = Math.max(...audios.map(a => Math.floor(a.samples.length / a.channels)));
    const res = [];
    for (let i = 0; i < frames; i++) {
      if (mode === 'merge') for (const a of audios) for (let c = 0; c < a.channels; c++) res.push(a.samples[i*a.channels+c] || 0);
      else for (let c = 0; c < channels; c++) {
        let v = mode === 'multiply' ? 1 : 0;
        for (const a of audios) {
          const x = a.samples[i*a.channels + Math.min(c, a.channels-1)] || 0;
          if (mode === 'multiply') v *= x; else v += x;
        }
        if (mode === 'mix-power') v /= Math.sqrt(audios.length); else if (mode === 'mix') v /= audios.length;
        res.push(Math.max(-1, Math.min(1, v)));
      }
    }
    return { ...audios[0], channels, rate, samples: res };
  }
  const first = audios[0], samples = [];
  for (const a of audios) {
    let b = a.rate !== first.rate ? resample(a, first.rate) : a;
    b = b.channels !== first.channels ? changeChannels(b, first.channels) : b;
    samples.push(...b.samples);
  }
  return { ...first, samples };
}

function parseSox(args) {
  const g = { combine: 'concatenate' }, pending = {}, files = [], effects = [];
  let i = 0;
  function setOpt(k, v) { pending[k] = v; }
  while (i < args.length) {
    const a = args[i];
    if (a === '--') { i++; continue; }
    if (a === '-q' || a === '-S' || a === '-D' || /^-V/.test(a) || a === '--clobber' || a === '--no-clobber' || a === '--norm' || a === '-G' || a === '-R') { if (a === '--norm') effects.push({name:'norm',args:[]}); i++; continue; }
    if (a === '-m') { g.combine = 'mix'; i++; continue; }
    if (a === '-M') { g.combine = 'merge'; i++; continue; }
    if (a === '-T') { g.combine = 'multiply'; i++; continue; }
    if (a === '--combine') { g.combine = args[i+1] || 'concatenate'; i += 2; continue; }
    if (a === '-t' || a === '--type') { const t = args[i+1]; setOpt('type', t); Object.assign(pending, typeDefaults(t)); i += 2; continue; }
    if (a === '-r' || a === '--rate') { setOpt('rate', parseRate(args[i+1])); i += 2; continue; }
    if (a === '-c' || a === '--channels') { setOpt('channels', parseInt(args[i+1],10)); i += 2; continue; }
    if (a === '-b' || a === '--bits') { setOpt('bits', parseInt(args[i+1],10)); i += 2; continue; }
    if (a === '-e' || a === '--encoding') { setOpt('encoding', args[i+1]); i += 2; continue; }
    if (a === '-L' || a === '-B' || a === '-x' || a === '-N' || a === '-X' || a === '--ignore-length' || a === '--no-glob') { i++; continue; }
    if (a === '--endian' || a === '-v' || a === '--volume' || a === '-C' || a === '--compression' || a === '--comment' || a === '--add-comment' || a === '--comment-file' || a === '--buffer' || a === '--input-buffer' || a === '--temp' || a === '--plot' || a === '--replay-gain' || a === '--play-rate-arg') { i += 2; continue; }
    const en = a.replace(/[+#]$/,'');
    if (effectNames.has(en)) {
      i++;
      const ea = [];
      while (i < args.length && !effectNames.has(args[i].replace(/[+#]$/,''))) ea.push(args[i++]);
      effects.push({ name: en, args: ea });
      continue;
    }
    files.push({ name: a, opts: { ...pending } });
    for (const k of Object.keys(pending)) delete pending[k];
    i++;
  }
  if (files.length < 1) return { g, inputs: [], output: null, effects };
  if (files.length === 1 && effects.some(e => e.name === 'synth')) return { g, inputs: [{ name: '-n', opts: pending }], output: files[0], effects };
  return { g, inputs: files.slice(0, -1), output: files[files.length - 1], effects };
}

function sox(args) {
  if (!args.length || args.includes('--help') || args.includes('-h')) return showHelp(false);
  if (args.includes('--version')) return showVersion();
  const hi = args.indexOf('--help-effect'); if (hi >= 0) return showHelpEffect(args[hi + 1]);
  const hf = args.indexOf('--help-format'); if (hf >= 0) return showHelpFormat(args[hf + 1]);
  if (args.includes('--i') || args.includes('--info')) return soxi(args.filter(a => a !== '--i' && a !== '--info'));
  const p = parseSox(args);
  if (!p.output) return showHelp(false);
  let audios = p.inputs.map(f => readAudio(f.name, f.opts));
  if (!audios.length) audios = [emptyAudio(p.output.opts.rate || 8000, p.output.opts.channels || 1, p.output.opts.bits || 32)];
  let audio = combineAudios(audios, p.g.combine);
  audio = { ...audio, ...Object.fromEntries(Object.entries(p.output.opts).filter(([k]) => ['rate','channels','bits','encoding'].includes(k))) };
  audio = applyEffects(audio, p.effects, p.output.opts);
  writeAudio(audio, p.output.name, p.output.opts);
}

function main() {
  const argv = process.argv.slice(2);
  try {
    const base = path.basename(process.argv[1] || '');
    if (base === 'soxi') return soxi(argv);
    return sox(argv);
  } catch (e) {
    die(e.message || String(e));
  }
}

main();
