#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');

const VERSION = 'mdbook v0.5.0-alpha.1';

function main(argv) {
  const cmd = argv[2];
  if (cmd === 'help' && argv[3]) return subHelp(argv[3]);
  if (!cmd || cmd === 'help' || cmd === '--help' || cmd === '-h') return topHelp();
  if (cmd === '--version' || cmd === '-V') return console.log(VERSION);
  const rest = argv.slice(3);
  if (rest.includes('--help') || rest.includes('-h')) return subHelp(cmd);
  if (rest.includes('--version') || rest.includes('-V')) return console.log(VERSION);

  try {
    if (cmd === 'init') return init(rest);
    if (cmd === 'build') return build(rest);
    if (cmd === 'clean') return clean(rest);
    if (cmd === 'test') return test(rest);
    if (cmd === 'completions') return completions(rest);
    if (cmd === 'watch') return watch(rest);
    if (cmd === 'serve') return serve(rest);
    console.error(`error: unrecognized subcommand '${cmd}'`);
    console.error();
    topHelp();
    process.exitCode = 2;
  } catch (e) {
    log('ERROR', 'mdbook_core::utils', 'Error: ' + e.message);
    process.exitCode = e.exitCode || 101;
  }
}

function topHelp() {
  console.log(`Creates a book from markdown files

Usage: executable [COMMAND]

Commands:
  init         Creates the boilerplate structure and files for a new book
  build        Builds a book from its markdown files
  test         Tests that a book's Rust code samples compile
  clean        Deletes a built book
  completions  Generate shell completions for your shell to stdout
  watch        Watches a book's files and rebuilds it on changes
  serve        Serves a book at http://localhost:3000, and rebuilds it on changes
  help         Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version

For more information about a specific command, try \`mdbook <command> --help\`
The source code for mdBook is available at: https://github.com/rust-lang/mdBook`);
}

function subHelp(cmd) {
  const dest = `  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             \`./book\`.`;
  const map = {
    init: `Creates the boilerplate structure and files for a new book

Usage: executable init [OPTIONS] [dir]

Arguments:
  [dir]  Directory to create the book in
         (Defaults to the current directory when omitted)

Options:
      --theme            Copies the default theme into your source folder
      --force            Skips confirmation prompts
      --title <title>    Sets the book title
      --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]
  -h, --help             Print help
  -V, --version          Print version`,
    build: `Builds a book from its markdown files

Usage: executable build [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
${dest}
  -o, --open                 Opens the compiled book in a web browser
  -h, --help                 Print help
  -V, --version              Print version`,
    clean: `Deletes a built book

Usage: executable clean [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
${dest}
  -h, --help                 Print help
  -V, --version              Print version`,
    test: `Tests that a book's Rust code samples compile

Usage: executable test [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
${dest}
  -c, --chapter <chapter>    
  -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path
                             when building tests
  -h, --help                 Print help
  -V, --version              Print version`,
    completions: `Generate shell completions for your shell to stdout

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,
           zsh]

Options:
  -h, --help     Print help
  -V, --version  Print version`,
    watch: `Watches a book's files and rebuilds it on changes

Usage: executable watch [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
${dest}
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version`,
    serve: `Serves a book at http://localhost:3000, and rebuilds it on changes

Usage: executable serve [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
${dest}
  -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]
  -p, --port <port>          Port to use for HTTP connections [default: 3000]
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version`,
  };
  console.log(map[cmd] || '');
}

function parseArgs(args) {
  const opts = { _: [] };
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '-d' || a === '--dest-dir') opts.dest = args[++i];
    else if (a.startsWith('--dest-dir=')) opts.dest = a.slice(11);
    else if (a === '--title') opts.title = args[++i];
    else if (a.startsWith('--title=')) opts.title = a.slice(8);
    else if (a === '--ignore') opts.ignore = args[++i];
    else if (a.startsWith('--ignore=')) opts.ignore = a.slice(9);
    else if (a === '--theme') opts.theme = true;
    else if (a === '--force') opts.force = true;
    else if (a === '-o' || a === '--open') opts.open = true;
    else if (a === '-c' || a === '--chapter') opts.chapter = args[++i];
    else if (a === '-L' || a === '--library-path') opts.lib = args[++i];
    else if (a === '-n' || a === '--hostname') opts.hostname = args[++i];
    else if (a === '-p' || a === '--port') opts.port = args[++i];
    else if (a === '--watcher') opts.watcher = args[++i];
    else opts._.push(a);
  }
  return opts;
}

function init(args) {
  const opts = parseArgs(args);
  const root = path.resolve(opts._[0] || '.');
  const src = path.join(root, 'src');
  fs.mkdirSync(src, { recursive: true });
  const title = opts.title || path.basename(root) || 'My Book';
  log('INFO', 'mdbook_driver::init', 'Creating a new book with stub content');
  const bookToml = path.join(root, 'book.toml');
  if (!fs.existsSync(bookToml)) {
    fs.writeFileSync(bookToml, `[book]\nauthors = []\nlanguage = "en"\nsrc = "src"\ntitle = "${escapeToml(title)}"\n`);
  }
  const summary = path.join(src, 'SUMMARY.md');
  if (!fs.existsSync(summary)) {
    fs.writeFileSync(summary, '# Summary\n\n- [Chapter 1](./chapter_1.md)\n');
    fs.writeFileSync(path.join(src, 'chapter_1.md'), '# Chapter 1\n');
  } else {
    for (const ch of parseSummary(fs.readFileSync(summary, 'utf8')).chapters) {
      if (!ch.path) continue;
      const p = path.join(src, ch.path);
      if (!fs.existsSync(p)) {
        fs.mkdirSync(path.dirname(p), { recursive: true });
        fs.writeFileSync(p, `# ${ch.title}\n`);
      }
    }
  }
  if (opts.ignore === 'git') fs.writeFileSync(path.join(root, '.gitignore'), 'book\n');
  if (opts.theme) writeTheme(path.join(src, 'theme'));
  console.log('\nAll done, no errors...');
}

function build(args, quiet) {
  const opts = parseArgs(args);
  const root = path.resolve(opts._[0] || '.');
  const cfg = loadConfig(root);
  const src = path.resolve(root, cfg.book.src || 'src');
  const dest = path.resolve(root, opts.dest || (cfg.build && cfg.build['build-dir']) || 'book');
  if (!quiet) log('INFO', 'mdbook_driver::mdbook', 'Book building has started');
  const summaryPath = path.join(src, 'SUMMARY.md');
  if (!fs.existsSync(summaryPath)) throw new Error(`Summary file not found, ${summaryPath}`);
  const summary = parseSummary(fs.readFileSync(summaryPath, 'utf8'));
  if (fs.existsSync(dest)) fs.rmSync(dest, { recursive: true, force: true });
  fs.mkdirSync(dest, { recursive: true });
  copyNonMarkdown(src, dest);
  writeAssets(dest, cfg);
  createMissing(src, summary, cfg);
  const pages = summary.chapters.filter(c => c.path);
  const first = pages[0];
  for (let i = 0; i < pages.length; i++) {
    const ch = pages[i];
    const inPath = path.join(src, ch.path);
    const outRel = htmlRel(ch.path);
    const outPath = path.join(dest, outRel);
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    const md = fs.existsSync(inPath) ? fs.readFileSync(inPath, 'utf8') : `# ${ch.title}\n`;
    const html = renderPage(md, ch, pages[i - 1], pages[i + 1], summary, cfg, path.dirname(outRel), src);
    fs.writeFileSync(outPath, html);
  }
  if (first) fs.copyFileSync(path.join(dest, htmlRel(first.path)), path.join(dest, 'index.html'));
  fs.writeFileSync(path.join(dest, 'toc.html'), renderToc(summary, cfg, '.'));
  fs.writeFileSync(path.join(dest, 'print.html'), renderPrint(pages, src, summary, cfg));
  fs.writeFileSync(path.join(dest, '404.html'), render404(cfg));
  if (!quiet) {
    log('INFO', 'mdbook_driver::mdbook', 'Running the html backend');
    log('INFO', 'mdbook_html::html_handlebars::hbs_renderer', `HTML book written to \`${dest}\``);
  }
}

function clean(args) {
  const opts = parseArgs(args);
  const root = path.resolve(opts._[0] || '.');
  const cfg = loadConfig(root);
  const dest = path.resolve(root, opts.dest || (cfg.build && cfg.build['build-dir']) || 'book');
  if (fs.existsSync(dest)) fs.rmSync(dest, { recursive: true, force: true });
}

function test(args) {
  const opts = parseArgs(args);
  build(args, true);
  const root = path.resolve(opts._[0] || '.');
  const cfg = loadConfig(root);
  const src = path.resolve(root, cfg.book.src || 'src');
  const summary = parseSummary(fs.readFileSync(path.join(src, 'SUMMARY.md'), 'utf8'));
  let failures = 0, count = 0;
  for (const ch of summary.chapters.filter(c => c.path && (!opts.chapter || c.title.includes(opts.chapter) || c.path.includes(opts.chapter)))) {
    const text = fs.existsSync(path.join(src, ch.path)) ? fs.readFileSync(path.join(src, ch.path), 'utf8') : '';
    for (const block of rustBlocks(text)) {
      count++;
      const tmp = path.join(root, `.mdbook-test-${process.pid}-${count}.rs`);
      fs.writeFileSync(tmp, block);
      const res = childProcess.spawnSync('rustc', ['--edition', '2021', '--crate-type', 'lib', tmp], { encoding: 'utf8' });
      try { fs.unlinkSync(tmp); fs.rmSync(tmp.replace(/\.rs$/, '.rlib'), { force: true }); } catch {}
      if (res.status !== 0) {
        failures++;
        process.stderr.write(res.stderr || res.stdout || '');
      }
    }
  }
  if (failures) {
    console.error(`${failures} of ${count} tests failed`);
    process.exitCode = 101;
  }
}

function completions(args) {
  const shell = args[0];
  if (!['bash', 'elvish', 'fish', 'powershell', 'zsh'].includes(shell)) {
    console.error('error: invalid value for <SHELL>');
    process.exitCode = 2;
    return;
  }
  console.log(`# ${shell} completion for mdbook
complete -W "init build test clean completions watch serve help" mdbook executable`);
}

function watch(args) {
  build(args, false);
  console.error('Watching for changes...');
}

function serve(args) {
  const opts = parseArgs(args);
  build(args, false);
  const host = opts.hostname || 'localhost';
  const port = Number(opts.port || 3000);
  const root = path.resolve(opts._[0] || '.');
  const cfg = loadConfig(root);
  const dir = path.resolve(root, opts.dest || (cfg.build && cfg.build['build-dir']) || 'book');
  const http = require('http');
  const server = http.createServer((req, res) => {
    let file = decodeURIComponent(req.url.split('?')[0]);
    if (file === '/') file = '/index.html';
    const full = path.resolve(dir, '.' + file);
    if (!full.startsWith(dir)) { res.writeHead(403); return res.end('Forbidden'); }
    fs.readFile(full, (err, data) => {
      if (err) { res.writeHead(404); res.end('Not Found'); }
      else { res.writeHead(200, { 'Content-Type': mime(full) }); res.end(data); }
    });
  });
  server.listen(port, host, () => console.error(`Serving on: http://${host}:${port}`));
}

function loadConfig(root) {
  const cfg = { book: { title: path.basename(root), authors: [], language: 'en', src: 'src' }, build: {} };
  const p = path.join(root, 'book.toml');
  if (fs.existsSync(p)) Object.assign(cfg, parseToml(fs.readFileSync(p, 'utf8'), cfg));
  for (const [k, v] of Object.entries(process.env)) {
    if (!k.startsWith('MDBOOK_')) continue;
    const key = k.slice(7).toLowerCase().replace(/__/g, '.').replace(/_/g, '-');
    setNested(cfg, key.split('.'), parseEnvValue(v));
  }
  cfg.book = cfg.book || {};
  cfg.build = cfg.build || {};
  cfg.output = cfg.output || {};
  return cfg;
}

function parseToml(text, cfg) {
  let cur = cfg;
  for (let raw of text.split(/\r?\n/)) {
    let line = raw.replace(/#.*$/, '').trim();
    if (!line) continue;
    const sec = line.match(/^\[([^\]]+)\]$/);
    if (sec) {
      cur = cfg;
      for (const p of sec[1].split('.')) cur = cur[p] = cur[p] || {};
      continue;
    }
    const m = line.match(/^([\w-]+)\s*=\s*(.*)$/);
    if (m) cur[m[1]] = parseTomlVal(m[2].trim());
  }
  return cfg;
}

function parseTomlVal(v) {
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) return v.slice(1, -1);
  if (v === 'true') return true;
  if (v === 'false') return false;
  if (/^\[.*\]$/.test(v)) {
    const inner = v.slice(1, -1).trim();
    if (!inner) return [];
    return inner.split(',').map(s => parseTomlVal(s.trim()));
  }
  if (/^-?\d+$/.test(v)) return Number(v);
  return v;
}

function parseSummary(text) {
  const items = [];
  let numberedSeen = false;
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    if (/^-{3,}$/.test(trimmed)) { items.push({ type: 'separator' }); continue; }
    const part = trimmed.match(/^#\s+(.+)/);
    if (part && items.length) { items.push({ type: 'part', title: part[1].trim() }); continue; }
    const m = line.match(/^(\s*)([-*]\s*)?\[([^\]]+)\]\(([^)]*)\)/);
    if (m) {
      const depth = Math.floor((m[1] || '').replace(/\t/g, '    ').length / 2) + (m[2] ? 1 : 0);
      if (m[2]) numberedSeen = true;
      items.push({ type: 'chapter', title: m[3].trim(), path: m[4].trim(), depth: Math.max(0, depth), numbered: !!m[2] || numberedSeen });
    }
  }
  return { items, chapters: items.filter(i => i.type === 'chapter') };
}

function createMissing(src, summary, cfg) {
  if (cfg.build && cfg.build['create-missing'] === false) return;
  for (const ch of summary.chapters) {
    if (!ch.path) continue;
    const p = path.join(src, ch.path);
    if (!fs.existsSync(p)) {
      fs.mkdirSync(path.dirname(p), { recursive: true });
      fs.writeFileSync(p, `# ${ch.title}\n`);
    }
  }
}

function copyNonMarkdown(src, dest) {
  if (!fs.existsSync(src)) return;
  for (const ent of fs.readdirSync(src, { withFileTypes: true })) {
    const from = path.join(src, ent.name);
    const to = path.join(dest, ent.name);
    if (ent.isDirectory()) copyNonMarkdown(from, to);
    else if (!/\.md$/i.test(ent.name)) {
      fs.mkdirSync(path.dirname(to), { recursive: true });
      fs.copyFileSync(from, to);
    }
  }
}

function markdown(md, rootDir, curDir) {
  md = expandIncludes(md, rootDir, curDir);
  const lines = md.split(/\r?\n/);
  let out = '', inCode = false, code = [], lang = '';
  for (const line of lines) {
    const fence = line.match(/^```([^`]*)$/);
    if (fence) {
      if (!inCode) { inCode = true; lang = fence[1].split(',')[0].trim(); code = []; }
      else { out += `<pre><code class="language-${esc(lang)}">${esc(code.join('\n'))}\n</code></pre>\n`; inCode = false; }
      continue;
    }
    if (inCode) { code.push(line); continue; }
    const h = line.match(/^(#{1,6})\s+(.+)$/);
    if (h) {
      const level = h[1].length;
      const text = inline(h[2]);
      const id = slug(stripTags(text));
      out += `<h${level} id="${id}"><a class="header" href="#${id}">${text}</a></h${level}>\n`;
    } else if (/^\s*$/.test(line)) {
      out += '\n';
    } else if (/^\s*[-*]\s+/.test(line)) {
      out += `<ul><li>${inline(line.replace(/^\s*[-*]\s+/, ''))}</li></ul>\n`;
    } else {
      out += `<p>${inline(line)}</p>\n`;
    }
  }
  return out;
}

function inline(s) {
  s = esc(s);
  s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
  s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/\*([^*]+)\*/g, '<em>$1</em>');
  s = s.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1">');
  s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, t, href) => `<a href="${rewriteMdHref(href)}">${t}</a>`);
  return s;
}

function expandIncludes(md, rootDir, curDir) {
  return md.replace(/\{\{\s*#(?:include|rustdoc_include|playground)\s+([^}:]+)(?::[^}]*)?\}\}/g, (_, inc) => {
    const p = path.resolve(curDir || rootDir, inc.trim());
    try { return fs.readFileSync(p, 'utf8'); } catch { return ''; }
  });
}

function renderPage(md, ch, prev, next, summary, cfg, outDir, src) {
  const title = cfg.book.title || 'mdBook';
  const chapterTitle = firstHeading(md) || ch.title;
  const root = relRoot(outDir);
  const body = markdown(md, src, path.join(src, path.dirname(ch.path || '.')));
  return htmlShell(`${chapterTitle} - ${title}`, cfg, root, `
<nav id="sidebar" class="sidebar" aria-label="Table of contents">
${renderToc(summary, cfg, root)}
</nav>
<main>
<div class="content">
${body}
</div>
<nav class="nav-wrapper">
${prev ? `<a rel="prev" href="${root}${htmlRel(prev.path)}">Previous</a>` : ''}
${next ? `<a rel="next" href="${root}${htmlRel(next.path)}">Next</a>` : ''}
</nav>
</main>`);
}

function renderToc(summary, cfg, root) {
  let out = '<ol class="chapter">\n';
  for (const it of summary.items) {
    if (it.type === 'separator') out += '<li class="spacer"></li>\n';
    else if (it.type === 'part') out += `<li class="part-title">${esc(it.title)}</li>\n`;
    else if (it.type === 'chapter') {
      const cls = it.path ? 'chapter-item expanded' : 'chapter-item expanded affix';
      const pad = ` style="margin-left:${Math.max(0, it.depth - 1) * 20}px"`;
      const label = esc(it.title);
      out += it.path ? `<li class="${cls}"${pad}><a href="${root}${htmlRel(it.path)}">${label}</a></li>\n` : `<li class="${cls}"${pad}>${label}</li>\n`;
    }
  }
  return out + '</ol>\n';
}

function renderPrint(pages, src, summary, cfg) {
  const title = cfg.book.title || 'mdBook';
  let body = '';
  for (const ch of pages) {
    const p = path.join(src, ch.path);
    if (fs.existsSync(p)) body += markdown(fs.readFileSync(p, 'utf8'), src, path.dirname(p));
  }
  return htmlShell(title, cfg, '', body);
}

function render404(cfg) {
  return htmlShell(`404 - ${cfg.book.title || 'mdBook'}`, cfg, '', '<h1 id="404"><a class="header" href="#404">404</a></h1>\n<p>Page not found.</p>');
}

function htmlShell(title, cfg, root, body) {
  const lang = cfg.book.language || 'en';
  const dir = cfg.book['text-direction'] || (['ar', 'fa', 'he', 'ur'].includes(lang) ? 'rtl' : 'ltr');
  const desc = cfg.book.description ? `<meta name="description" content="${esc(cfg.book.description)}">` : '';
  return `<!DOCTYPE HTML>
<html lang="${esc(lang)}" class="light sidebar-visible" dir="${dir}">
    <head>
        <!-- Book generated using mdBook -->
        <meta charset="UTF-8">
        <title>${esc(title)}</title>
        ${desc}
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="${root}css/variables.css">
        <link rel="stylesheet" href="${root}css/general.css">
        <link rel="stylesheet" href="${root}css/chrome.css">
        <link rel="stylesheet" href="${root}css/print.css" media="print">
        <script>const path_to_root = "${root}";</script>
    </head>
    <body>
${body}
        <script src="${root}book.js"></script>
    </body>
</html>
`;
}

function writeAssets(dest, cfg) {
  fs.mkdirSync(path.join(dest, 'css'), { recursive: true });
  fs.writeFileSync(path.join(dest, '.nojekyll'), '');
  fs.writeFileSync(path.join(dest, 'css/variables.css'), ':root{--bg:#fff;--fg:#222;--links:#20609f}\n');
  fs.writeFileSync(path.join(dest, 'css/general.css'), 'body{font-family:Arial,sans-serif;margin:0;color:var(--fg);background:var(--bg)}main{max-width:900px;margin:auto;padding:2rem}.content{line-height:1.6}pre{background:#f5f5f5;padding:1em;overflow:auto}code{font-family:monospace}a{color:var(--links)}\n');
  fs.writeFileSync(path.join(dest, 'css/chrome.css'), '.sidebar{float:left;width:260px;padding:1rem}.chapter{list-style:none;padding-left:0}.part-title{font-weight:bold;margin-top:1rem}.spacer{border-top:1px solid #ddd;margin:.5rem 0}.nav-wrapper{display:flex;justify-content:space-between;margin-top:2rem}\n');
  fs.writeFileSync(path.join(dest, 'css/print.css'), '.sidebar,.nav-wrapper{display:none}\n');
  fs.writeFileSync(path.join(dest, 'book.js'), '');
  fs.writeFileSync(path.join(dest, 'toc.js'), '');
  fs.writeFileSync(path.join(dest, 'searchindex.js'), 'Object.assign(window,{search:{}});\n');
  if (cfg.output && cfg.output.html && cfg.output.html.cname) fs.writeFileSync(path.join(dest, 'CNAME'), String(cfg.output.html.cname));
}

function writeTheme(dir) {
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'index.hbs'), '{{ content }}\n');
  fs.writeFileSync(path.join(dir, 'book.js'), '');
  fs.mkdirSync(path.join(dir, 'css'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'css/general.css'), '');
}

function rustBlocks(text) {
  const blocks = [];
  const re = /```([^\n`]*)\n([\s\S]*?)```/g;
  let m;
  while ((m = re.exec(text))) {
    const info = m[1].split(',').map(x => x.trim());
    if ((info[0] === 'rust' || info[0] === 'rs' || info[0] === '') && !info.includes('ignore') && !info.includes('text') && !info.includes('no_run')) blocks.push(m[2]);
  }
  return blocks;
}

function firstHeading(md) {
  const m = md.match(/^#\s+(.+)$/m);
  return m ? stripTags(inline(m[1])).trim() : null;
}

function htmlRel(p) {
  let out = p.replace(/\\/g, '/').replace(/\.md$/i, '.html');
  out = out.replace(/(^|\/)README\.html$/i, '$1index.html');
  return out;
}

function rewriteMdHref(href) {
  if (/^[a-z]+:|^#|^\//i.test(href)) return href;
  return href.replace(/\.md(#.*)?$/i, (_, hash) => `.html${hash || ''}`).replace(/(^|\/)README\.html/i, '$1index.html');
}

function relRoot(dir) {
  if (!dir || dir === '.') return '';
  const depth = dir.split(/[\\/]+/).filter(Boolean).length;
  return '../'.repeat(depth);
}

function log(level, target, msg) {
  const d = new Date();
  const stamp = d.toISOString().replace('T', ' ').replace(/\..*/, '');
  console.error(`${stamp} [${level}] (${target}): ${msg}`);
}

function esc(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function stripTags(s) { return String(s).replace(/<[^>]+>/g, ''); }
function slug(s) { return s.toLowerCase().trim().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-'); }
function escapeToml(s) { return String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"'); }
function setNested(o, parts, v) { let c = o; while (parts.length > 1) { const p = parts.shift(); c = c[p] = c[p] || {}; } c[parts[0]] = v; }
function parseEnvValue(v) { try { return JSON.parse(v); } catch { return v; } }
function mime(p) { return p.endsWith('.html') ? 'text/html' : p.endsWith('.css') ? 'text/css' : p.endsWith('.js') ? 'text/javascript' : 'application/octet-stream'; }

main(process.argv);
