#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");

const VERSION = `gotests v0.0.0-20260303205902-f3b63d74369a
Go version: go1.24.5
Git commit: f3b63d74369a8c405a9a3990a656a278a4f9096f
Build time: 2026-03-03T20:59:02Z`;

const help = `Usage of ./executable:
  -ai
    \tgenerate test cases using AI (requires Ollama)
  -ai-endpoint string
    \tOllama API endpoint (default "http://localhost:11434")
  -ai-max-cases int
    \tmaximum number of test cases to generate with AI (default 10)
  -ai-min-cases int
    \tminimum number of test cases to generate with AI (default 3)
  -ai-model string
    \tAI model to use for test generation (default "qwen2.5-coder:0.5b")
  -all
    \tgenerate tests for all functions and methods
  -excl string
    \tregexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all
  -exported
    \tgenerate tests for exported functions and methods. Takes precedence over -only and -all
  -i\tprint test inputs in error messages
  -named
    \tswitch table tests from using slice to map (with test name for the key)
  -nosubtests
    \tdisable generating tests using the Go 1.7 subtests feature
  -only string
    \tregexp. generate tests for functions and methods that match only. Takes precedence over -all
  -parallel
    \tenable generating parallel subtests using the Go 1.7 feature
  -template string
    \toptional. Specify custom test code templates, e.g. testify. This can also be set via environment variable GOTESTS_TEMPLATE
  -template_dir string
    \toptional. Path to a directory containing custom test code templates. Takes precedence over -template. This can also be set via environment variable GOTESTS_TEMPLATE_DIR
  -template_params string
    \tread external parameters to template by json with stdin
  -template_params_file string
    \tread external parameters to template by json with file
  -use_go_cmp
    \tuse cmp.Equal (google/go-cmp) instead of reflect.DeepEqual
  -version
    \tprint version information and exit
  -w\twrite output to (test) files instead of stdout`;

function parseArgs(argv) {
  const flags = {
    ai: false, aiEndpoint: "http://localhost:11434", aiMaxCases: 10, aiMinCases: 3,
    aiModel: "qwen2.5-coder:0.5b", all: false, excl: "", exported: false, i: false,
    named: false, nosubtests: false, only: "", parallel: false, template: process.env.GOTESTS_TEMPLATE || "",
    templateDir: process.env.GOTESTS_TEMPLATE_DIR || "", templateParams: "", templateParamsFile: "",
    useGoCmp: false, version: false, w: false,
  };
  const paths = [];
  const takes = new Set(["-ai-endpoint", "-ai-max-cases", "-ai-min-cases", "-ai-model", "-excl", "-only", "-template", "-template_dir", "-template_params", "-template_params_file"]);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help" || a === "-h") { console.log(help); process.exit(0); }
    if (!a.startsWith("-") || a === "-") { paths.push(a); continue; }
    if (takes.has(a)) {
      if (i + 1 >= argv.length) die(`flag needs an argument: ${a}`, true);
      const v = argv[++i];
      if (a === "-ai-endpoint") flags.aiEndpoint = v;
      else if (a === "-ai-max-cases") flags.aiMaxCases = parseInt(v, 10);
      else if (a === "-ai-min-cases") flags.aiMinCases = parseInt(v, 10);
      else if (a === "-ai-model") flags.aiModel = v;
      else if (a === "-excl") flags.excl = v;
      else if (a === "-only") flags.only = v;
      else if (a === "-template") flags.template = v;
      else if (a === "-template_dir") flags.templateDir = v;
      else if (a === "-template_params") flags.templateParams = v;
      else if (a === "-template_params_file") flags.templateParamsFile = v;
      continue;
    }
    const key = a.slice(1).replace(/-/g, "");
    const map = { ai: "ai", all: "all", exported: "exported", i: "i", named: "named", nosubtests: "nosubtests", parallel: "parallel", use_go_cmp: "useGoCmp", version: "version", w: "w" };
    if (a === "-use_go_cmp") flags.useGoCmp = true;
    else if (map[key]) flags[map[key]] = true;
    else die(`flag provided but not defined: ${a}\n${help}`, false);
  }
  return { flags, paths };
}

function die(msg, usage) {
  console.error(msg);
  if (usage) console.error(help);
  process.exit(1);
}

function removeComments(s) {
  return s.replace(/\/\*[\s\S]*?\*\//g, m => " ".repeat(m.length))
    .replace(/\/\/.*$/gm, m => " ".repeat(m.length));
}

function findMatching(s, start, open, close) {
  let depth = 0, quote = "", esc = false;
  for (let i = start; i < s.length; i++) {
    const c = s[i];
    if (quote) {
      if (esc) esc = false;
      else if (c === "\\") esc = true;
      else if (c === quote || (quote === "`" && c === "`")) quote = "";
      continue;
    }
    if (c === '"' || c === "'" || c === "`") { quote = c; continue; }
    if (c === open) depth++;
    else if (c === close) {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

function skipWs(s, i) { while (i < s.length && /\s/.test(s[i])) i++; return i; }
function readIdent(s, i) {
  const m = /^[A-Za-z_][A-Za-z0-9_]*/.exec(s.slice(i));
  return m ? [m[0], i + m[0].length] : ["", i];
}

function splitTop(s, sep = ",") {
  const out = []; let cur = "", depth = 0, quote = "", esc = false;
  const opens = "([{", closes = ")]}";
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (quote) {
      cur += c;
      if (esc) esc = false;
      else if (c === "\\") esc = true;
      else if (c === quote || (quote === "`" && c === "`")) quote = "";
      continue;
    }
    if (c === '"' || c === "'" || c === "`") { quote = c; cur += c; continue; }
    if (opens.includes(c)) depth++;
    else if (closes.includes(c)) depth--;
    if (c === sep && depth === 0) { out.push(cur.trim()); cur = ""; }
    else cur += c;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function parseFields(s, resultMode = false) {
  s = s.trim();
  if (!s) return [];
  const parts = splitTop(s);
  const fields = [];
  let anon = 0;
  for (let idx = 0; idx < parts.length; idx++) {
    const p = parts[idx].trim();
    const m = /^([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)*)\s+(.+)$/.exec(p);
    const typeStarters = /^(?:\*|\[\]|map\[|chan\b|<-chan\b|func\b|interface\b|struct\b)/;
    if (m && !typeStarters.test(m[1])) {
      for (const name of m[1].split(/\s*,\s*/)) fields.push({ name, type: m[2].trim() });
    } else if (!resultMode && idx < parts.length - 1) {
      const rest = parts.slice(idx + 1).join(", ");
      const rm = /^([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)*)\s+(.+)$/.exec(rest.trim());
      if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(p) && rm) fields.push({ name: p, type: rm[2].trim() });
      else fields.push({ name: `arg${anon++}`, type: p });
    } else {
      fields.push({ name: resultMode ? "" : `arg${anon++}`, type: p });
    }
  }
  return fields;
}

function parsePackage(src) {
  const m = /^\s*package\s+([A-Za-z_][A-Za-z0-9_]*)/m.exec(src);
  return m ? m[1] : "main";
}

function parseFunctions(src) {
  const clean = removeComments(src);
  const funcs = [];
  let i = 0;
  while ((i = clean.indexOf("func", i)) !== -1) {
    if ((i > 0 && /[A-Za-z0-9_]/.test(clean[i - 1])) || /[A-Za-z0-9_]/.test(clean[i + 4] || "")) { i += 4; continue; }
    let j = skipWs(clean, i + 4);
    let recv = null;
    if (clean[j] === "(") {
      const e = findMatching(clean, j, "(", ")");
      if (e < 0) break;
      recv = parseFields(clean.slice(j + 1, e))[0] || null;
      j = skipWs(clean, e + 1);
    }
    const [name, afterName] = readIdent(clean, j);
    if (!name) { i += 4; continue; }
    j = skipWs(clean, afterName);
    let typeParams = "";
    if (clean[j] === "[") {
      const e = findMatching(clean, j, "[", "]");
      typeParams = clean.slice(j + 1, e);
      j = skipWs(clean, e + 1);
    }
    if (clean[j] !== "(") { i = j; continue; }
    const pe = findMatching(clean, j, "(", ")");
    const params = parseFields(clean.slice(j + 1, pe));
    j = skipWs(clean, pe + 1);
    let results = [];
    if (clean[j] === "(") {
      const re = findMatching(clean, j, "(", ")");
      results = parseFields(clean.slice(j + 1, re), true);
      j = skipWs(clean, re + 1);
    } else {
      const m = /^[^\s{]+(?:\s*\[[^\]]+\])?/.exec(clean.slice(j));
      if (m && m[0].trim()) { results = [{ name: "", type: m[0].trim() }]; j += m[0].length; }
    }
    funcs.push({ name, recv, typeParams, params, results });
    i = j;
  }
  return funcs;
}

function isExported(name) { return /^[A-Z]/.test(name); }
function recvBase(recv) {
  if (!recv) return "";
  let t = recv.type.replace(/^\*/, "").trim();
  t = t.replace(/\[.*$/, "");
  return t.split(/[.\s]/).pop();
}
function testName(fn) { return fn.recv ? `Test${recvBase(fn.recv)}_${fn.name}` : `Test${fn.name}`; }
function zeroConcreteForConstraint(c) {
  c = c.trim().replace(/^~\s*/, "");
  if (!c || c === "any" || c === "interface{}") return "int";
  if (c === "comparable") return "string";
  if (c.includes("|")) return c.split("|")[0].trim().replace(/^~/, "").trim();
  return c.split(/\s+/)[0].replace(/^~/, "");
}
function typeArgs(fn) {
  if (!fn.typeParams) return "";
  return "[" + splitTop(fn.typeParams).map(p => {
    const m = /^[A-Za-z_][A-Za-z0-9_]*\s+(.+)$/.exec(p.trim());
    return zeroConcreteForConstraint(m ? m[1] : "any");
  }).join(", ") + "]";
}
function genericMap(fn) {
  const map = new Map();
  if (fn.typeParams) {
    for (const p of splitTop(fn.typeParams)) {
      const m = /^([A-Za-z_][A-Za-z0-9_]*)\s+(.+)$/.exec(p.trim());
      if (m) map.set(m[1], zeroConcreteForConstraint(m[2]));
    }
  }
  if (fn.recv) {
    const m = /\[([^\]]+)\]/.exec(fn.recv.type);
    if (m) {
      for (const item of splitTop(m[1])) {
        const name = item.trim();
        if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) && !map.has(name)) map.set(name, "string");
      }
    }
  }
  return map;
}
function substType(fn, typ) {
  let out = typ;
  for (const [name, concrete] of genericMap(fn)) {
    out = out.replace(new RegExp(`\\b${name}\\b`, "g"), concrete);
  }
  return out;
}
function alignFields(rows) {
  const w = Math.max(0, ...rows.map(r => r[0].length));
  return rows.map(r => `\t\t${r[0]}${" ".repeat(w - r[0].length + 1)}${r[1]}`).join("\n");
}
function needsDeep(results) {
  return results.some(r => r.type !== "error" && !/^(bool|string|error|rune|byte|u?int(8|16|32|64)?|float(32|64)|complex(64|128))$/.test(r.type));
}

function genTest(fn, flags) {
  const lines = [];
  const params = fn.params;
  const nonErr = fn.results.filter(r => r.type !== "error");
  const hasErr = fn.results.some(r => r.type === "error");
  const useCmp = flags.useGoCmp && needsDeep(nonErr);
  const deep = needsDeep(nonErr);
  lines.push(`func ${testName(fn)}(t *testing.T) {`);
  if (params.length) {
    lines.push(`\ttype args struct {`);
    lines.push(alignFields(params.map(p => [p.name, substType(fn, p.type)])));
    lines.push(`\t}`);
  }
  const rows = [["name", "string"]];
  if (fn.recv) rows.push([fn.recv.name || "receiver", substType(fn, fn.recv.type)]);
  if (params.length) rows.push(["args", "args"]);
  nonErr.forEach((r, idx) => rows.push([idx === 0 ? "want" : `want${idx + 1}`, substType(fn, r.type)]));
  if (hasErr) rows.push(["wantErr", "bool"]);
  if (flags.named) {
    lines.push(`\ttests := map[string]struct {`);
    lines.push(alignFields(rows.filter(r => r[0] !== "name")));
    lines.push(`\t}{`);
  } else {
    lines.push(`\ttests := []struct {`);
    lines.push(alignFields(rows));
    lines.push(`\t}{`);
  }
  lines.push(`\t\t// TODO: Add test cases.`);
  lines.push(`\t}`);
  lines.push(`\tfor ${flags.named ? "name, tt" : "_, tt"} := range tests {`);
  if (flags.nosubtests) {
    if (flags.parallel) lines.push(`\t\tt.Parallel()`);
    emitBody(lines, fn, flags, nonErr, hasErr, deep, useCmp, flags.named ? "name" : "tt.name", "\t\t");
  } else {
    lines.push(`\t\tt.Run(${flags.named ? "name" : "tt.name"}, func(t *testing.T) {`);
    if (flags.parallel) lines.push(`\t\t\tt.Parallel()`);
    emitBody(lines, fn, flags, nonErr, hasErr, deep, useCmp, flags.named ? "name" : "tt.name", "\t\t\t");
    lines.push(`\t\t})`);
  }
  lines.push(`\t}`);
  lines.push(`}`);
  return lines.join("\n");
}

function callExpr(fn) {
  const args = fn.params.map(p => `tt.args.${p.name}`).join(", ");
  if (fn.recv) {
    const r = fn.recv.name || "receiver";
    return `tt.${r}.${fn.name}(${args})`;
  }
  return `${fn.name}${typeArgs(fn)}(${args})`;
}
function emitBody(lines, fn, flags, nonErr, hasErr, deep, useCmp, testLabel, ind) {
  const call = callExpr(fn);
  const returns = fn.results.length;
  if (returns === 0) {
    lines.push(`${ind}${call}`);
    return;
  }
  const lhs = [];
  nonErr.forEach((_, idx) => lhs.push(idx === 0 ? "got" : `got${idx + 1}`));
  if (hasErr) lhs.push("err");
  lines.push(`${ind}${lhs.join(", ")} := ${call}`);
  if (hasErr) {
    lines.push(`${ind}if (err != nil) != tt.wantErr {`);
    lines.push(`${ind}\tt.Errorf("${fn.name}() error = %v, wantErr %v", err, tt.wantErr)`);
    lines.push(`${ind}\treturn`);
    lines.push(`${ind}}`);
  }
  nonErr.forEach((r, idx) => {
    const got = idx === 0 ? "got" : `got${idx + 1}`;
    const want = idx === 0 ? "tt.want" : `tt.want${idx + 1}`;
    let cond = `${got} != ${want}`;
    if (deep) cond = useCmp ? `!cmp.Equal(${got}, ${want})` : `!reflect.DeepEqual(${got}, ${want})`;
    lines.push(`${ind}if ${cond} {`);
    const inputs = flags.i && fn.params.length ? `, args %v` : "";
    const vals = flags.i && fn.params.length ? `, tt.args` : "";
    lines.push(`${ind}\tt.Errorf("${fn.name}()${inputs} = %v, want %v"${vals}, ${got}, ${want})`);
    lines.push(`${ind}}`);
  });
}

function importsBlock(flags, tests) {
  let imps = ["testing"];
  if (tests.some(t => needsDeep(t.results.filter(r => r.type !== "error")))) imps.push(flags.useGoCmp ? "github.com/google/go-cmp/cmp" : "reflect");
  if (imps.length === 1) return `import "testing"`;
  return "import (\n" + imps.map(i => `\t"${i}"`).join("\n") + "\n)";
}

function generateForFile(file, flags) {
  const src = fs.readFileSync(file, "utf8");
  const pkg = parsePackage(src);
  let funcs = parseFunctions(src).filter(fn => !fn.name.startsWith("Test") && fn.name !== "init" && fn.name !== "main");
  if (flags.excl) { const re = new RegExp(flags.excl); funcs = funcs.filter(f => !re.test(f.name)); }
  else if (flags.exported) funcs = funcs.filter(f => isExported(f.name));
  else if (flags.only) { const re = new RegExp(flags.only); funcs = funcs.filter(f => re.test(f.name)); }
  else if (!flags.all) return { file, out: "", count: 0 };
  if (!funcs.length) return { file, out: "", count: 0 };
  const body = funcs.map(f => genTest(f, flags)).join("\n\n");
  return { file, out: `package ${pkg}\n\n${importsBlock(flags, funcs)}\n\n${body}\n`, count: funcs.length };
}

function collectFiles(args) {
  const files = [];
  function walk(d) {
    for (const ent of fs.readdirSync(d, { withFileTypes: true })) {
      if (ent.name === ".git" || ent.name === "vendor") continue;
      const p = path.join(d, ent.name);
      if (ent.isDirectory()) walk(p);
      else if (ent.isFile() && ent.name.endsWith(".go") && !ent.name.endsWith("_test.go")) files.push(p);
    }
  }
  for (const a of args.length ? args : ["."]) {
    if (a.endsWith("/...")) walk(a.slice(0, -4) || ".");
    else {
      const st = fs.statSync(a);
      if (st.isDirectory()) {
        for (const n of fs.readdirSync(a)) {
          if (n.endsWith(".go") && !n.endsWith("_test.go")) files.push(path.join(a, n));
        }
      } else {
        files.push(a);
      }
    }
  }
  return files;
}

function main() {
  const { flags, paths } = parseArgs(process.argv.slice(2));
  if (flags.version) { console.log(VERSION); return; }
  if (!flags.only && !flags.excl && !flags.exported && !flags.all) die("Please specify either the -only, -excl, -exported, or -all flag", false);
  const files = collectFiles(paths);
  let any = false, stdout = [];
  for (const f of files) {
    const r = generateForFile(f, flags);
    if (!r.count) { if (!flags.w) console.error(`No tests generated for ${f}`); continue; }
    any = true;
    if (flags.w) {
      const out = f.replace(/\.go$/, "_test.go");
      fs.writeFileSync(out, r.out);
      console.log(`Generated Test${r.count === 1 ? "" : "s"} for ${path.basename(f)}`);
    } else stdout.push(r.out);
  }
  if (!any && flags.w) for (const f of files) console.error(`No tests generated for ${f}`);
  if (!flags.w && stdout.length) process.stdout.write(stdout.join("\n"));
}

main();
