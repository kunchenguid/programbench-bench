#!/usr/bin/env node
'use strict';

const fs = require('fs');

const HELP = `Usage: peco [options] [FILE]

Options:
  -h, --help            show this help message and exit
  --query               initial value for query
  --rcfile              path to the settings file
  --version             print the version and exit
  -b, --buffer-size     number of lines to keep in search buffer
  --null                expect NUL (\\0) as separator for target/output
  --initial-index       position of the initial index of the selection (0 base)
  --initial-filter      specify the default filter
  --prompt              specify the prompt string
  --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'
  --select-1            select first item and immediately exit if the input contains only 1 item
  --exit-0              exit immediately with status 1 if the input is empty
  --select-all          select all items and immediately exit
  --on-cancel           specify action on user cancel. 'success' or 'error'.
                        default is 'success'. This may change in future versions
  --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.
                        default is to use colors. This option is experimental
  --exec                execute command instead of finishing/terminating peco.
                        Please note that this command will receive selected line(s) from stdin,
                        and will be executed via '/bin/sh -c' or 'cmd /c'
  --print-query         print out the current query as first line of output
  --ansi                enable ANSI color code support
  --height              display height in lines or percentage (e.g. '10', '50%')
`;

const VERSION = 'peco version v0.5.11 (built with go1.25.0)\n';

const valueFlags = new Set([
  '--query', '--rcfile', '--buffer-size', '-b', '--initial-index',
  '--initial-filter', '--prompt', '--layout', '--on-cancel',
  '--selection-prefix', '--exec', '--height'
]);

function dieSetup(message) {
  process.stderr.write(`Error: failed to setup peco: ${message}\n`);
  process.exit(1);
}

function printParseError(message) {
  process.stderr.write(`${message}\n\n${HELP}`);
  process.stderr.write(`Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line options: ${message}\n`);
  process.exit(1);
}

function termError(extra) {
  if (process.env.TERM) {
    process.stderr.write('Error: failed to initialize screen: failed to initialize tcell screen: open /dev/tty: no such device or address\n');
  } else {
    process.stderr.write('Error: failed to initialize screen: failed to create tcell screen: terminal entry not found: term not set\n');
  }
  if (extra) process.stderr.write(`${extra}\n`);
  process.exit(1);
}

function parseArgs(argv) {
  const opts = {
    query: null, rcfile: null, bufferSize: null, nullMode: false,
    initialIndex: null, initialFilter: null, prompt: null, layout: null,
    select1: false, exit0: false, selectAll: false, onCancel: null,
    selectionPrefix: null, exec: null, printQuery: false, ansi: false,
    height: null, files: []
  };

  for (let i = 0; i < argv.length; i++) {
    let arg = argv[i];
    if (arg === '-h' || arg === '--help') {
      process.stdout.write(HELP);
      process.exit(0);
    }
    if (arg === '--version') {
      process.stdout.write(VERSION);
      process.exit(0);
    }
    if (arg === '--null') { opts.nullMode = true; continue; }
    if (arg === '--select-1') { opts.select1 = true; continue; }
    if (arg === '--exit-0') { opts.exit0 = true; continue; }
    if (arg === '--select-all') { opts.selectAll = true; continue; }
    if (arg === '--print-query') { opts.printQuery = true; continue; }
    if (arg === '--ansi') { opts.ansi = true; continue; }

    let value = null;
    if (arg.startsWith('--') && arg.includes('=')) {
      const idx = arg.indexOf('=');
      value = arg.slice(idx + 1);
      arg = arg.slice(0, idx);
    }

    if (valueFlags.has(arg)) {
      if (value === null) {
        if (i + 1 >= argv.length) printParseError(`expected argument for flag \`${arg}\``);
        value = argv[++i];
      }
      switch (arg) {
        case '--query': opts.query = value; break;
        case '--rcfile': opts.rcfile = value; break;
        case '--buffer-size':
        case '-b': opts.bufferSize = value; break;
        case '--initial-index': opts.initialIndex = value; break;
        case '--initial-filter': opts.initialFilter = value; break;
        case '--prompt': opts.prompt = value; break;
        case '--layout': opts.layout = value; break;
        case '--on-cancel': opts.onCancel = value; break;
        case '--selection-prefix': opts.selectionPrefix = value; break;
        case '--exec': opts.exec = value; break;
        case '--height': opts.height = value; break;
      }
      continue;
    }

    if (arg.startsWith('-')) {
      const name = arg.replace(/^-+/, '');
      process.stderr.write(`unknown flag \`${name}\`\n\n${HELP}`);
      process.stderr.write(`Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line options: unknown flag \`${name}\`\n`);
      process.exit(1);
    }
    opts.files.push(arg);
  }
  return opts;
}

function validate(opts) {
  if (opts.rcfile && !fs.existsSync(opts.rcfile)) {
    dieSetup(`failed to setup configuration: failed to read config file: failed to open file ${opts.rcfile}: open ${opts.rcfile}: no such file or directory`);
  }
  if (opts.layout && !['top-down', 'bottom-up', 'top-down-query-bottom'].includes(opts.layout)) {
    process.stderr.write(`Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line arguments: unknown layout: '${opts.layout}'\n`);
    process.exit(1);
  }
  if (opts.initialFilter && !['IgnoreCase', 'CaseSensitive', 'SmartCase', 'IRegexp', 'Regexp', 'Fuzzy'].includes(opts.initialFilter)) {
    dieSetup('failed to apply configuration: failed to populate initial filter: failed to set filter: specified filter was not found');
  }
  if (opts.onCancel && !['success', 'error'].includes(opts.onCancel)) {
    termError(`invalid OnCancel value "${opts.onCancel}": must be "success" or "error"`);
  }
  if (opts.height && !/^([0-9]+|[0-9]+%)$/.test(opts.height)) {
    termError(`height specification: "${opts.height}"`);
  }
}

function splitLines(buf) {
  const s = buf.toString('utf8');
  if (s.length === 0) return [];
  const parts = s.split('\n');
  if (parts[parts.length - 1] === '') parts.pop();
  return parts;
}

function outputLine(line) {
  process.stdout.write(line);
  process.stdout.write('\n');
}

function outputNullSelectAll(input) {
  const s = input.toString('utf8');
  if (s.length === 0) return;
  let records = s.split('\n');
  if (records[records.length - 1] === '') records.pop();
  for (const rec of records) {
    const nul = rec.indexOf('\0');
    outputLine(nul >= 0 ? rec.slice(nul + 1) : rec);
  }
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  validate(opts);

  let input = Buffer.alloc(0);
  try {
    input = fs.readFileSync(0);
  } catch (_) {
    input = Buffer.alloc(0);
  }

  if (opts.exit0 && input.length === 0 && opts.files.length === 0) {
    process.exit(1);
  }

  const simpleFast = !opts.query && !opts.printQuery && !opts.bufferSize && !opts.exec && opts.files.length === 0;

  if (opts.selectAll && simpleFast) {
    if (opts.nullMode) {
      outputNullSelectAll(input);
      process.exit(0);
    }
    const s = input.toString('utf8');
    const lines = splitLines(input);
    if (lines.length > 1 && !s.endsWith('\n')) termError();
    for (const line of lines) outputLine(line);
    process.exit(0);
  }

  if (opts.select1 && !opts.query && !opts.bufferSize && !opts.exec && opts.files.length === 0) {
    const lines = splitLines(input);
    if (lines.length === 1) {
      if (opts.printQuery) outputLine(opts.query || '');
      if (opts.nullMode) {
        const nul = lines[0].indexOf('\0');
        outputLine(nul >= 0 ? lines[0].slice(nul + 1) : lines[0]);
      } else {
        outputLine(lines[0]);
      }
      process.exit(0);
    }
  }

  termError();
}

main();
