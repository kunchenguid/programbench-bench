#!/usr/bin/env ruby
# frozen_string_literal: true

require "open3"

USAGE = "Usage: ./executable [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]"

HELP_CATEGORIES = <<~TEXT
Invalid category provided, here is a list of all categories:

 auth        Different types of authentication methods
 connection  Low level networking operations
 curl        The command line tool itself
 dns         General DNS options
 file        FILE protocol options
 ftp         FTP protocol options
 http        HTTP and HTTPS protocol options
 imap        IMAP protocol options
 misc        Options that don't fit into any other category
 output      Filesystem output
 pop3        POP3 protocol options
 post        HTTP Post specific options
 proxy       All options related to proxies
 scp         SCP protocol options
 sftp        SFTP protocol options
 smtp        SMTP protocol options
 ssh         SSH protocol options
 telnet      TELNET protocol options
 tftp        TFTP protocol options
 tls         All TLS/SSL related options
 upload      All options for uploads
 verbose     Options related to any kind of command line output of curl
TEXT

NO_ARG_OPTS = %w[
  --anyauth --append --basic --cert-status --compressed --compressed-ssh --create-dirs
  --crlf --digest --disable --disable-eprt --disable-epsv --disallow-username-in-url
  --doh-cert-status --doh-insecure --fail --fail-early --fail-with-body --false-start
  --form-escape --ftp-create-dirs --ftp-pasv --ftp-pret --ftp-skip-pasv-ip --ftp-ssl-control
  --get --globoff --haproxy-protocol --head --http0.9 --http1.0 --http1.1 --http2
  --http2-prior-knowledge --http3 --ignore-content-length --include --insecure
  --ipv4 --ipv6 --junk-session-cookies --list-only --location --location-trusted
  --manual --netrc --netrc-optional --next --no-alpn --no-buffer --no-keepalive
  --no-npn --no-progress-meter --ntlm --ntlm-wb --parallel --parallel-immediate
  --path-as-is --post301 --post302 --post303 --progress-bar --proxy-anyauth
  --proxy-basic --proxy-digest --proxy-insecure --proxy-negotiate --proxy-ntlm
  --proxy-ssl-allow-beast --proxy-tlsv1 --proxytunnel --raw --remote-header-name
  --remote-name --remote-name-all --remote-time --silent --sasl-ir --show-error
  --ssl --ssl-allow-beast --ssl-reqd --styled-output --suppress-connect-headers
  --tcp-fastopen --tcp-nodelay --tr-encoding --use-ascii --verbose --version --xattr
  -0 -1 -2 -3 -4 -6 -a -B -f -G -g -I -i -j -k -L -l -M -n -N -O -p -q -R -s -S -V -v -Z -#
].freeze

SHORT_WITH_ARG = %w[-A -b -c -C -d -D -e -E -F -H -K -m -o -P -Q -r -T -u -U -w -x -X -Y -y -z].freeze

def option_takes_value?(arg)
  return false if NO_ARG_OPTS.include?(arg)
  return false if arg.start_with?("--no-")
  return false if arg.include?("=")
  return true if arg.start_with?("--")
  return true if SHORT_WITH_ARG.include?(arg)
  arg.start_with?("-") && arg.length == 2 && !NO_ARG_OPTS.include?(arg)
end

def shellish(arg)
  return "\"#{arg.gsub('"', '\"')}\"" if arg =~ /\s/
  arg
end

def json_string(s)
  '"' + s.to_s.gsub("\\", "\\\\\\").gsub('"', '\"').gsub("\n", "\\n").gsub("\r", "\\r").gsub("\t", "\\t") + '"'
end

def valid_json_literal?(s)
  return true if %w[true false null].include?(s)
  return true if s.match?(/\A-?(0|[1-9]\d*)(\.\d+)?([eE][+-]?\d+)?\z/)
  return true if s.start_with?('"') && s.end_with?('"')
  return true if balanced_jsonish?(s, "[", "]")
  return true if balanced_jsonish?(s, "{", "}")
  false
end

def balanced_jsonish?(s, open, close)
  return false unless s.start_with?(open) && s.end_with?(close)
  stack = []
  in_string = false
  escaped = false
  s.each_char do |ch|
    if in_string
      escaped = !escaped && ch == "\\"
      if ch == '"' && !escaped
        in_string = false
      elsif ch != "\\"
        escaped = false
      end
      next
    end
    case ch
    when '"'
      in_string = true
    when "{", "["
      stack << ch
    when "}"
      return false unless stack.pop == "{"
    when "]"
      return false unless stack.pop == "["
    end
  end
  stack.empty? && !in_string
end

def url_encode(s)
  s.bytes.map do |b|
    c = b.chr
    if c.match?(/[A-Za-z0-9_.~-]/)
      c
    elsif c == " "
      "+"
    else
      "%%%02X" % b
    end
  end.join
end

def display_url(url)
  shown = url.sub(/\Alocalhost:/, "http://localhost:")
  return "http://#{shown}" unless shown.match?(/\A[A-Za-z][A-Za-z0-9+.-]*:\/\//)
  shown
end

def append_query(url, pairs)
  return url if pairs.empty?
  joiner = url.include?("?") ? "&" : "?"
  url + joiner + pairs.map { |k, v| "#{url_encode(k)}=#{url_encode(v)}" }.join("&")
end

def print_help(category)
  if category.nil? || category.empty?
    puts USAGE
    puts HELP_CATEGORIES
    return 0
  end

  out, err, status = Open3.capture3("curl", "--help", category)
  if status.success?
    lines = out.lines
    lines.shift if lines.first&.start_with?("Usage:")
    puts USAGE
    print lines.join
    0
  else
    puts USAGE
    puts HELP_CATEGORIES
    warn err unless err.empty?
    0
  end
end

def color_headers(head)
  head.each_line do |line|
    if line.start_with?("HTTP/")
      $stderr.write "\e[34m#{line.sub('/', "\e[37m/").sub(/ (\d+)/, " \e[36m\\1").sub(/ (.+)\r?$/, "\e[33m \\1")}\e[0m"
    elsif line.include?(":")
      k, v = line.split(":", 2)
      $stderr.write "\e[37m#{k}:\e[36m#{v}\e[0m"
    else
      $stderr.write line
    end
  end
  $stderr.write "\n"
end

def naive_pretty_json(s)
  out = +""
  indent = 0
  in_string = false
  esc = false
  s.each_char do |ch|
    if in_string
      out << ch
      if esc
        esc = false
      elsif ch == "\\"
        esc = true
      elsif ch == '"'
        in_string = false
      end
      next
    end
    case ch
    when '"'
      in_string = true
      out << ch
    when "{", "["
      out << ch << "\n"
      indent += 1
      out << ("    " * indent)
    when "}", "]"
      out << "\n"
      indent -= 1
      out << ("    " * indent) << ch
    when ","
      out << ch << "\n" << ("    " * indent)
    when ":"
      out << ": "
    else
      out << ch unless ch.match?(/\s/)
    end
  end
  out
end

def pretty_body(body)
  stripped = body.strip
  if stripped.start_with?("{", "[")
    puts naive_pretty_json(stripped)
  else
    print body
  end
end

args = ARGV.dup

if args.empty?
  exit print_help("all")
end

curl_print = false
pretty = false
if args.delete("--curl")
  curl_print = true
end
if args.delete("--pretty")
  pretty = true
end

if (idx = args.index { |a| a == "--version" || a == "-V" })
  exec "curl", "--version" if args.length == 1 || idx == 0
end

if (idx = args.index { |a| a == "--help" || a == "-h" })
  exit print_help(args[idx + 1])
end

curl_opts = []
i = 0
while i < args.length
  arg = args[i]
  break unless arg.start_with?("-") && arg != "-"
  curl_opts << arg
  if option_takes_value?(arg) && i + 1 < args.length
    i += 1
    curl_opts << args[i]
  end
  i += 1
end

rest = args[i..] || []
method = nil
known_methods = %w[GET POST PUT PATCH DELETE HEAD OPTIONS TRACE CONNECT]
if rest.length >= 2 && rest[0].match?(/\A[A-Z][A-Z0-9_-]*\z/)
  method = rest.shift
elsif rest.length == 1 && known_methods.include?(rest[0])
  method = rest.shift
end

url = rest.shift
if url.nil?
  if method
    exec "curl", *curl_opts, "-X", method
  else
    exec "curl", *curl_opts
  end
end

headers = []
queries = []
fields = []
pass_items = []

rest.each do |item|
  if item.include?("==")
    k, v = item.split("==", 2)
    queries << [k, v]
  elsif item.include?(":=")
    k, v = item.split(":=", 2)
    fields << [k, valid_json_literal?(v) ? v : "null"]
  elsif item.include?("=")
    k, v = item.split("=", 2)
    fields << [k, json_string(v)]
  elsif item.include?(":")
    headers << item
  else
    pass_items << item
  end
end

url_with_query = append_query(url, queries)
shown_url = display_url(url_with_query)
$stderr.puts shown_url

body_json = nil
unless fields.empty?
  body_json = "{" + fields.map { |k, v| "#{json_string(k)}:#{v}" }.join(",") + "}"
end

cmd = ["curl"] + curl_opts
cmd += ["-X", method] if method
headers.each { |h| cmd += ["-H", h] }
pass_items.each { |x| cmd << x }
if body_json
  cmd += ["-d", body_json, url_with_query]
else
  cmd << url_with_query
end
cmd += ["-s", "-S"]
cmd += ["-d@-"] unless body_json
cmd += ["-H", "Content-Type: application/json", "-H", "Accept: application/json, */*"]

if curl_print
  puts cmd.map { |a| shellish(a) }.join(" ")
  exit 0
end

if pretty
  cmd += ["-i"]
  output = +""
  status = nil
  Open3.popen3(*cmd) do |stdin, stdout, stderr, wait_thr|
    stdin.write(STDIN.read)
    stdin.close
    err_thr = Thread.new { stderr.each { |line| $stderr.write(line) } }
    output = stdout.read
    err_thr.join
    status = wait_thr.value
  end
  head, body = output.split(/\r?\n\r?\n/, 2)
  if body
    color_headers(head)
    pretty_body(body)
  else
    pretty_body(output)
  end
  exit(status.exitstatus || 1)
end

exec(*cmd)
