#!/usr/bin/env ruby
# frozen_string_literal: true

require 'cgi'
require 'fileutils'
require 'optparse'
require 'zlib'

VERSION = 'crowbook 0.17.0'

HELP = <<~TXT
  crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>
  Render a Markdown book in EPUB, PDF or HTML.
    
  USAGE:
      executable [OPTIONS] [BOOK]

  OPTIONS:
    -f, --force-emoji
            Force emoji usage even if it might not work on your system
    -s, --single
            Use a single Markdown file instead of a book configuration file
    -n, --no-fancy
            Disably fancy UI
    -v, --verbose
            Print warnings in parsing/rendering
    -a, --autograph
            Prompts for an autograph for this book
    -q, --quiet
            Don't print info/error messages
    -c, --create <files>...
            Create a new book with existing Markdown files
    -o, --output <output>
            Specify output file
    -t, --to <to>
            Generate specific format
        --set <set> <set>...
            Set a list of book options
    -l, --list-options
            List all possible options
    -L, --lang <lang>
            Set the runtime language used by Crowbook
        --print-template <print-template>
            Prints the default content of a template
    -S, --stats
            Print some project statistics
    -h, --help
            Print help
    -V, --version
            Print version

  ARGS:
    [BOOK]  File containing the book configuration file, or a Markdown file when called with --single
TXT

LIST_OPTIONS = <<~TXT
  CROWBOOK 0.17.0
  METADATA
  author
    type: metadata (default: "")
    Author of the book
  title
    type: metadata (default: "")
    Title of the book
  lang
    type: metadata (default: en)
    Language of the book
  subject
    type: metadata (default: not set)
    Subject of the book (used for EPUB metadata)
  description
    type: metadata (default: not set)
    Description of the book (used for EPUB metadata)
  cover
    type: path (default: not set)
    Path to the cover of the book

  ADDITIONAL METADATA
  subtitle
    type: metadata (default: not set)
    Subtitle of the book
  license
    type: metadata (default: not set)
    License of the book
  version
    type: metadata (default: not set)
    Version of the book
  date
    type: metadata (default: not set)
    Date the book was revised
  autograph
    type: metadata (default: not set)
    An autograph

  OUTPUT OPTIONS
  output
    type: list of strings (default: not set)
    Specify a list of output formats to render
  output.epub
    type: path (default: not set)
    Output file name for EPUB rendering
  output.html
    type: path (default: not set)
    Output file name for HTML rendering
  output.html.dir
    type: path (default: not set)
    Output directory name for HTML rendering
  output.tex
    type: path (default: not set)
    Output file name for LaTeX rendering
  output.pdf
    type: path (default: not set)
    Output file name for PDF rendering
  output.base_path
    type: path (default: "")
    Directory where those output files will we written

  RENDERING OPTIONS
  rendering.highlight
    type: string (default: syntect)
    If/how highligh code blocks. Possible values: "syntect" (default, performed at
    runtime), "highlight.js" (HTML-only, uses Javascript), "none"
  rendering.highlight.theme
    type: string (default: InspiredGitHub)
    Theme for syntax highlighting (if rendering.highlight is set to 'syntect')
  rendering.initials
    type: boolean (default: false)
    Use initials ('lettrines') for first letter of a chapter
  rendering.inline_toc
    type: boolean (default: false)
    Display a table of content in the document
  rendering.inline_toc.name
    type: string (default: "{{loc_toc}}")
    Name of the table of contents if it is displayed in document
  rendering.num_depth
    type: integer (default: 1)
    The  maximum heading levels that should be numbered (0: no numbering, 1: only
    chapters, ..., 6: all)
  rendering.chapter
    type: string (default: not set)
    How to call chapters
  rendering.part
    type: string (default: not set)
    How to call parts (or 'books', 'episodes', ...)
  rendering.chapter.roman_numerals
    type: boolean (default: false)
    If set to true, display chapter number with roman numerals
  rendering.part.roman_numerals
    type: boolean (default: true)
    If set to true, display part number with roman numerals
  rendering.part.reset_counter
    type: boolean (default: true)
    If set to true, reset chapter number at each part
  rendering.chapter.template
    type: string (default: "{{number}}. {{chapter_title}}")
    Naming scheme of chapters, for TOC
  rendering.part.template
    type: string (default: "{{number}}. {{part_title}}")
    Naming scheme of parts, for TOC

  SPECIAL OPTIONS
  import
    type: path (default: not set)
    Import another book configuration file

  HTML OPTIONS
  html.icon
    type: path (default: not set)
    Path to an icon to be used for the HTML files(s)
  html.highlight.theme
    type: string (default: not set)
    If set, set theme for syntax highlighting for HTML output (syntect only)
  html.header
    type: string (default: not set)
    Custom header to display at the beginning of html file(s)
  html.footer
    type: string (default: not set)
    Custom footer to display at the end of HTML file(s)
  html.css
    type: template path (default: not set)
    Path of a stylesheet for HTML rendering
  html.css.add
    type: string (default: not set)
    Some inline CSS added to the stylesheet template
  html.css.colors
    type: template path (default: not set)
    Path of a stylesheet for the colors for HTML
  html.js
    type: template path (default: not set)
    Path of a javascript file
  html.css.print
    type: template path (default: not set)
    Path of a media print stylesheet for HTML rendering
  html.chapter.template
    type: string (default: "<h1 id = 'link-{{link}}'>{% if has_number %}<span class = 'chapter-header'>{{header}} {{number}}</span>{% if has_title %}<br />{% endif %}{% endif %}{{title}}</h1>")
    Inline template for HTML chapter formatting
  html.part.template
    type: string (default: "<h2 class = 'part'>{{header}} {{number}}</h2> <h1 id = 'link-{{link}}' class = 'part'>{{title}}</h1>")
    Inline template for HTML part formatting

  STANDALONE HTML OPTIONS
  html.standalone.template
    type: template path (default: not set)
    Path of an HTML template for standalone HTML
  html.standalone.one_chapter
    type: boolean (default: false)
    Display only one chapter at a time (with a button to display all)
  html.standalone.js
    type: template path (default: not set)
    Path of a javascript file

  MULTIFILE HTML OPTIONS
  html.dir.template
    type: template path (default: not set)
    Path of a HTML template for multifile HTML

  EPUB OPTIONS
  epub.version
    type: integer (default: 2)
    EPUB version to generate (2 or 3)
  epub.css
    type: template path (default: not set)
    Path of a stylesheet for EPUB

  LATEX OPTIONS
  tex.cover
    type: boolean (default: false)
    Add cover to the LaTeX/PDF file
  tex.command
    type: string (default: xelatex)
    LaTeX command to use for generating PDF
  tex.template
    type: template path (default: not set)
    Path of a LaTeX template file
  tex.class
    type: string (default: book)
    LaTeX class to use

  RESOURCES OPTIONS
  resources.files
    type: list of strings (default: not set)
    Whitespace-separated list of files to embed in e.g. EPUB file; useful for
    including e.g. fonts

  INPUT OPTIONS    #[SERDE(FLATTEN)]
  input.clean
    type: boolean (default: true)
    Toggle typographic cleaning of input markdown according to lang

  CROWBOOK OPTIONS
  crowbook.html_as_text
    type: boolean (default: true)
    Consider HTML blocks as text. This avoids having <foo> being considered as
    HTML and thus ignored.
  crowbook.zip.command
    type: string (default: zip)
    Command to use to zip files (for EPUB/ODT)
TXT

CSS = <<~CSS
  body {
      font-family: "Linux Libertine", "Georgia", serif;
      text-align: justify;
      font-size: 100%;
  }
  p { text-indent: 1.25em; margin:0; hyphens: auto; }
  code { font-size: 80%; font-family: "Linux Libertine Mono", monospace; background-color: #F0F0F0; }
  h1, h2, h3, h4, h5, h6 { text-align: left; font-family: Linux Biolinum, sans-serif; font-variant: small-caps; }
  h1.title { text-align: center; font-size: 300%; }
  h2.author { text-align: right; font-size:  200%; }
  span.chapter-header { font-size: 75%; }
  #content { text-align: center; }
  #page { display: inline-block; text-align: justify; max-width: 33em; }
  nav { background: #dfcae6; color: black; }
CSS

PRINT_CSS = "#page {\n    display: block;\n}\n\n.chapter {\n    page-break-before: always;\n}\n"
JS = "function on(name) {}\nfunction off(name) {}\nfunction toggle() {}\n"

TEMPLATES = {
  'html.css' => CSS,
  'epub.css' => CSS,
  'html.css.print' => PRINT_CSS,
  'html.js' => JS,
  'html.standalone.js' => JS,
  'html.standalone.template' => <<~HTML,
    <!DOCTYPE html>
    <html lang="{{lang}}">
      <head>
        <meta charset="utf-8">
        <meta name="generator" content="crowbook">
        <meta name="viewport" content="width=device-width">
        <meta name="author" content="{{author_raw}}">
        {{favicon}}
        <title>{{title_raw}}</title>
        <style type = "text/css">
          {{style}}
        </style>
      </head>
      <body>
        {{content}}
      </body>
    </html>
  HTML
  'html.dir.template' => <<~HTML,
    <!DOCTYPE html>
    <html lang="{{lang}}">
      <head>
        <meta charset="utf-8">
        <meta name="generator" content="crowbook">
        <meta name="author" content="{{author_raw}}">
        <title>{{title_raw}}{% if is_chapter %} - {{chapter_title_raw}}{% endif %}</title>
      </head>
      <body>
      {{content}}
      </body>
    </html>
  HTML
  'epub.chapter.xhtml' => <<~HTML,
    <?xml version="1.0" encoding="UTF-8"?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="{{lang}}" lang="{{lang}}">
      <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta http-equiv="Content-Style-Type" content="text/css" />
      <meta name="generator" content="crowbook" />
      <title>{{chapter_title_raw}}</title>
      <link rel="stylesheet" type="text/css" href="stylesheet.css" />
      </head>
      <body xml:lang="{{lang}}" lang="{{lang}}">
        <div id = "page">
          {{content}}
        </div>
      </body>
    </html>
  HTML
  'epub.titlepage.xhtml' => <<~HTML,
    <?xml version="1.0" encoding="UTF-8"?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="{{lang}}">
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="generator" content="crowbook" />
      <title>{{title_raw}}</title>
      <link rel="stylesheet" type="text/css" href="stylesheet.css" />
    </head>
    <body>
      <h2 class="author">{{author}}</h2>
      <h1 class="title">{{title}}</h1>
    </body>
    </html>
  HTML
  'tex.template' => "\\documentclass{<<class>>}\n\\usepackage[utf8]{inputenc}\n\\title{<<title>>}\n\\author{<<author>>}\n\\begin{document}\n\\maketitle\n<<content>>\n\\end{document}\n"
}

def banner(quiet = false)
  warn 'CROWBOOK 0.17.0' unless quiet
end

def die(msg, quiet = false, code = 0)
  banner(quiet)
  warn "ERROR #{msg}" unless quiet
  exit code
end

def html_escape(s) = CGI.escapeHTML(s.to_s)

def inline_html(s)
  x = html_escape(s)
  x.gsub!(/!\[([^\]]*)\]\(([^)]+)\)/, '<img src = "\2" alt = "\1" />')
  x.gsub!(/\[([^\]]+)\]\(([^)]+)\)/, '<a href = "\2">\1</a>')
  x.gsub!(/`([^`]+)`/, '<code>\1</code>')
  x.gsub!(/\*\*([^*]+)\*\*/, '<b>\1</b>')
  x.gsub!(/\*([^*]+)\*/, '<em>\1</em>')
  x.gsub!(/__([^_]+)__/, '<b>\1</b>')
  x.gsub!(/_([^_]+)_/, '<em>\1</em>')
  x
end

def inline_tex(s)
  x = s.to_s.gsub(/[\\{}$&#_%]/) { |m| "\\#{m}" }
  x.gsub!(/\*\*([^*]+)\*\*/, '\\textbf{\1}')
  x.gsub!(/\*([^*]+)\*/, '\\emph{\1}')
  x.gsub!(/`([^`]+)`/, '\\texttt{\1}')
  x.gsub!(/\[([^\]]+)\]\(([^)]+)\)/, '\1')
  x
end

def parse_markdown(md, html: true)
  para = 0
  out = []
  in_ul = false
  in_ol = false
  in_code = false
  code_buf = []
  md.lines.each do |raw|
    line = raw.chomp
    if line.start_with?('```')
      if in_code
        body = html_escape(code_buf.join("\n"))
        out << (html ? "<pre><code>#{body}</code></pre>" : "\\begin{verbatim}\n#{code_buf.join("\n")}\n\\end{verbatim}")
        code_buf = []
        in_code = false
      else
        in_code = true
      end
      next
    end
    if in_code
      code_buf << line
      next
    end
    if line.strip.empty?
      if in_ul then out << (html ? '</ul>' : '\\end{itemize}'); in_ul = false end
      if in_ol then out << (html ? '</ol>' : '\\end{enumerate}'); in_ol = false end
      next
    end
    if (m = line.match(/^(#{'#'}{1,6})\s+(.*)$/))
      lvl = m[1].length
      out << (html ? "<h#{lvl}>#{inline_html(m[2])}</h#{lvl}>" : "\\#{%w[chapter section subsection subsubsection paragraph subparagraph][lvl - 1]}{#{inline_tex(m[2])}}")
    elsif line =~ /^[-*]\s+(.*)$/
      out << (html ? '<ul>' : '\\begin{itemize}') unless in_ul
      in_ul = true
      para += 1
      out << (html ? "<li><p id = \"para-#{para}\">#{inline_html(Regexp.last_match(1))}</p></li>" : "\\item #{inline_tex(Regexp.last_match(1))}")
    elsif line =~ /^\d+\.\s+(.*)$/
      out << (html ? '<ol>' : '\\begin{enumerate}') unless in_ol
      in_ol = true
      para += 1
      out << (html ? "<li><p id = \"para-#{para}\">#{inline_html(Regexp.last_match(1))}</p></li>" : "\\item #{inline_tex(Regexp.last_match(1))}")
    elsif line.strip == '---' || line.strip == '***'
      out << (html ? '<p class = "rule">***</p>' : '\\begin{center}***\\end{center}')
    else
      para += 1
      out << (html ? "<p id = \"para-#{para}\">#{inline_html(line)}</p>" : inline_tex(line) + "\n\n")
    end
  end
  out << (html ? '</ul>' : '\\end{itemize}') if in_ul
  out << (html ? '</ol>' : '\\end{enumerate}') if in_ol
  out.join("\n")
end

def parse_single(path)
  text = File.read(path)
  opts = {}
  if text.start_with?("---\n")
    parts = text.split(/^---\s*$/, 3)
    if parts.size >= 3
      parts[1].lines.each { |l| parse_option_line(l, opts, []) }
      text = parts[2].sub(/\A\n/, '')
    end
  end
  [opts, [{ path: path, text: text }]]
end

def parse_option_line(line, opts, chapters)
  s = line.strip
  return if s.empty? || s.start_with?('#')
  if s.start_with?('+', '-', '!')
    chapters << s.sub(/^[+\-!]\s*/, '')
  elsif (m = s.match(/^([^:]+):\s*(.*)$/))
    val = m[2].strip
    val = val[1..-2] if (val.start_with?('"') && val.end_with?('"')) || (val.start_with?("'") && val.end_with?("'"))
    opts[m[1].strip] = val
  end
end

def parse_book(path)
  die("Could not find file '#{path}' for book") unless File.exist?(path)
  opts = {}
  chapter_paths = []
  File.readlines(path).each { |l| parse_option_line(l, opts, chapter_paths) }
  base = File.dirname(path)
  chapters = chapter_paths.map do |ch|
    p = File.expand_path(ch, base)
    die("Could not find file '#{ch}' for chapter") unless File.exist?(p)
    { path: ch, text: File.read(p) }
  end
  [opts, chapters]
end

def chapter_title(text, fallback)
  text.lines.each { |l| return Regexp.last_match(1).strip if l =~ /^#\s+(.*)$/ }
  fallback
end

def html_document(opts, chapters)
  title = opts['title'].to_s
  author = opts['author'].to_s
  lang = opts['lang'].to_s.empty? ? 'en' : opts['lang']
  body = chapters.each_with_index.map do |ch, i|
    t = chapter_title(ch[:text], "Chapter #{i + 1}")
    content = parse_markdown(ch[:text].sub(/^#\s+.*\n?/, ''), html: true)
    "<div id = \"chapter-#{i}\" class = \"chapter\">\n  <h1 id = 'link-#{i + 1}'><span class = 'chapter-header'>Chapter #{i + 1}</span><br />#{html_escape(t)}</h1>#{content}\n</div>"
  end.join("\n\n")
  nav = chapters.each_with_index.map { |ch, i| "      <li><a href=\"#link-#{i + 1}\">#{i + 1}. #{html_escape(chapter_title(ch[:text], ch[:path]))}</a></li>" }.join("\n")
  <<~HTML
    <!DOCTYPE html>
    <html lang="#{html_escape(lang)}">
      <head>
        <meta charset="utf-8">
        <meta name="generator" content="crowbook">
        <meta name="viewport" content="width=device-width">
        <meta name="author" content="#{html_escape(author)}">
        
        <title>#{html_escape(title)}</title>
        <style type = "text/css">
          #{CSS}
        </style>
        <style type = "text/css" media = "print">
          #{PRINT_CSS}
        </style>
       <script>
        #{JS}
       </script>
      </head>
      <body>
        
    <script type = 'application/ld+json'>
    {
        "@context": "http://schema.org/",
        "@type": "Book",
        "author": "#{html_escape(author)}",
        "name": "#{html_escape(title)}",
        "inLanguage": "#{html_escape(lang)}"
    }
    </script>
        <nav id = "nav">
          <h2><a href = "#link-0">#{html_escape(title)}</a></h2>
          <ul>
    #{nav}
          </ul>
        </nav>
        <div id = "content">
          <div id = "page">
            <header>
    	  <h2 class="author">#{html_escape(author)}</h2>
              <h1 id = "link-0" class="title" >#{html_escape(title)}</h1>
            </header>
    #{body}
          </div>
        </div>
      </body>
    </html>
  HTML
end

def tex_document(opts, chapters)
  title = inline_tex(opts['title'].to_s)
  author = inline_tex(opts['author'].to_s)
  content = chapters.map { |ch| parse_markdown(ch[:text], html: false) }.join("\n")
  "\\documentclass{book}\n\\usepackage[utf8]{inputenc}\n\\title{#{title}}\n\\author{#{author}}\n\\begin{document}\n\\maketitle\n#{content}\n\\end{document}\n"
end

def write_zip(path, entries)
  central = +''
  File.open(path, 'wb') do |f|
    entries.each do |name, data|
      data = data.b
      name = name.b
      crc = Zlib.crc32(data)
      offset = f.pos
      f.write [0x04034b50, 20, 0, 0, 0, 0, crc, data.bytesize, data.bytesize, name.bytesize, 0].pack('VvvvvvVVVvv')
      f.write name
      f.write data
      central << [0x02014b50, 20, 20, 0, 0, 0, 0, crc, data.bytesize, data.bytesize, name.bytesize, 0, 0, 0, 0, 0, offset].pack('VvvvvvvVVVvvvvvVV')
      central << name
    end
    central_offset = f.pos
    f.write central
    f.write [0x06054b50, 0, 0, entries.length, entries.length, central.bytesize, central_offset, 0].pack('VvvvvVVv')
  end
end

def create_epub(path, opts, chapters)
  entries = []
  entries << ['mimetype', 'application/epub+zip']
  entries << ['META-INF/container.xml', %(<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>)]
  entries << ['OEBPS/stylesheet.css', CSS]
  entries << ['OEBPS/title_page.xhtml', "<html xmlns=\"http://www.w3.org/1999/xhtml\"><body><h1>#{html_escape(opts['title'])}</h1><h2>#{html_escape(opts['author'])}</h2></body></html>"]
  chapters.each_with_index do |ch, i|
    entries << ["OEBPS/chapter_#{i + 1}.xhtml", "<html xmlns=\"http://www.w3.org/1999/xhtml\"><body>#{parse_markdown(ch[:text], html: true)}</body></html>"]
  end
  entries << ['OEBPS/content.opf', %(<?xml version="1.0"?><package version="2.0" xmlns="http://www.idpf.org/2007/opf"><metadata><dc:title xmlns:dc="http://purl.org/dc/elements/1.1/">#{html_escape(opts['title'])}</dc:title></metadata><manifest></manifest><spine></spine></package>)]
  write_zip(path, entries)
end

def create_config(files)
  puts '"author: Your name"'
  puts '"title: Your title"'
  puts '"lang: en"'
  puts
  puts '"## Output formats"'
  puts
  puts '"# Uncomment and fill to generate files"'
  puts '"# output.html: some_file.html"'
  puts '"# output.epub: some_file.epub"'
  puts '"# output.pdf: some_file.pdf"'
  puts
  puts '"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file\'s name"'
  puts '"# output: [pdf, epub, html]"'
  puts
  puts '"# Uncomment and fill to set cover image (for EPUB)"'
  puts '"# cover: some_cover.png"'
  puts
  puts '## List of chapters'
  files.each { |f| puts "+ #{f}" }
end

def stats(chapters)
  rows = chapters.map do |ch|
    text = ch[:text].gsub(/^#+\s+.*$/, '').gsub(/[`*_#\[\]()>!-]/, ' ')
    words = text.scan(/[[:alnum:]]+/)
    chars = words.join.length
    [ch[:path], chars, words.length]
  end
  puts 'Chapter    Chars      Words  Chars/Word'
  puts '---------'
  total_c = total_w = 0
  rows.each do |name, c, w|
    total_c += c; total_w += w
    printf "%-9s%7d%11d%12.2f\n", name, c, w, (w.zero? ? 0.0 : c.to_f / w)
  end
  puts '---------'
  printf "TOTAL:%10d%11d%12.2f\n", total_c, total_w, (total_w.zero? ? 0.0 : total_c.to_f / total_w)
end

def render(fmt, output, opts, chapters)
  case fmt
  when 'html'
    content = html_document(opts, chapters)
    output ? File.write(output, content) : puts(content)
  when 'html.dir'
    dir = output || opts['output.html.dir'] || 'html'
    FileUtils.mkdir_p(dir)
    File.write(File.join(dir, 'index.html'), html_document(opts, chapters))
  when 'tex'
    content = tex_document(opts, chapters)
    output ? File.write(output, content) : puts(content)
  when 'epub'
    create_epub(output || opts['output.epub'] || 'book.epub', opts, chapters)
  when 'odt'
    File.write(output || opts['output.odt'] || 'book.odt', chapters.map { |c| c[:text] }.join("\n"))
  when 'pdf'
    File.write(output || opts['output.pdf'] || 'book.pdf', tex_document(opts, chapters))
  else
    warn "error: invalid value '#{fmt}' for '--to <to>'"
    warn '  [possible values: epub, pdf, html, tex, odt, html.dir]'
    exit 2
  end
end

opts = { single: false, quiet: false, sets: [] }
args = ARGV.dup
book = nil

if args.include?('--help') || args.include?('-h')
  puts HELP
  exit 0
end
if args.include?('--version') || args.include?('-V')
  puts VERSION
  exit 0
end

i = 0
while i < args.length
  a = args[i]
  case a
  when '-s', '--single' then opts[:single] = true
  when '-q', '--quiet' then opts[:quiet] = true
  when '-n', '--no-fancy', '-v', '--verbose', '-f', '--force-emoji' then nil
  when '-a', '--autograph' then opts[:autograph] = true
  when '-l', '--list-options' then opts[:list_options] = true
  when '-S', '--stats' then opts[:stats] = true
  when '-c', '--create'
    opts[:create] = args[(i + 1)..] || []
    break
  when '-o', '--output'
    i += 1; opts[:output] = args[i]
  when '-t', '--to'
    i += 1; opts[:to] = args[i]
  when '-L', '--lang'
    i += 1; opts[:lang] = args[i]
  when '--print-template'
    i += 1; opts[:template] = args[i]
  when '--set'
    opts[:sets] = args[(i + 1)..] || []
    break
  when /^-/
    warn "error: unexpected argument '#{a}' found"
    warn "\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'."
    exit 2
  else
    book = a
  end
  i += 1
end

if opts[:list_options]
  puts LIST_OPTIONS
  exit 0
end

if opts[:template]
  banner(opts[:quiet])
  if TEMPLATES.key?(opts[:template])
    puts TEMPLATES[opts[:template]]
  else
    warn "ERROR #{opts[:template]} is not a valid template name" unless opts[:quiet]
  end
  exit 0
end

if opts[:create]
  banner(opts[:quiet])
  create_config(opts[:create])
  exit 0
end

die("You must pass the name of a book configuration file.\nFor more information try --help.", opts[:quiet]) unless book

if opts[:single]
  conf, chapters = parse_single(book)
else
  conf, chapters = parse_book(book)
end
conf['lang'] = opts[:lang] if opts[:lang]
opts[:sets].each_slice(2) { |k, v| conf[k] = v if k && v }

if opts[:stats]
  banner(opts[:quiet])
  stats(chapters)
  exit 0
end

fmt = opts[:to]
out = opts[:output]
if out && !fmt
  warn "error: the following required arguments were not provided:\n  --to <to>\n\nUsage: executable --to <to> --single --output <output> <BOOK>\n\nFor more information, try '--help'."
  exit 2
end

banner(opts[:quiet])
if fmt.nil?
  rendered = false
  [['html', 'output.html'], ['epub', 'output.epub'], ['tex', 'output.tex'],
   ['pdf', 'output.pdf'], ['odt', 'output.odt'], ['html.dir', 'output.html.dir']].each do |format, key|
    next unless conf[key]
    render(format, conf[key], conf, chapters)
    rendered = true
  end
  if !rendered && conf['output']
    base = File.basename(book, File.extname(book))
    conf['output'].scan(/[A-Za-z.]+/).each do |format|
      target = format == 'html.dir' ? "#{base}" : "#{base}.#{format == 'html' ? 'html' : format}"
      render(format, target, conf, chapters)
      rendered = true
    end
  end
  render('html', nil, conf, chapters) unless rendered
else
  render(fmt, out, conf, chapters)
end
