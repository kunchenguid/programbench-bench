#!/usr/bin/env ruby
$stdout.binmode
$stderr.binmode
PROG = File.basename($0)

HELP_TEMPLATE = <<~TXT
Futuristic take on hexdump, made in Rust.


Usage: %{prog} [OPTIONS] [INPUTFILE]

Arguments:
  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin

Options:
  -c, --cols <columns>        Set column length
  -l, --len <len>             Set <len> bytes to read
  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]
  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]
  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]
  -u, --func <func_length>    Set function wave length
  -p, --places <func_places>  Set function wave output decimal places
  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]
  -h, --help                  Print help
  -V, --version               Print version
TXT
HELP = format(HELP_TEMPLATE, prog: PROG)

opts = { cols: 10, len: 0, format: 'x', color: nil, array: nil, func: nil, places: 4, prefix: 1 }
input = nil
args = ARGV.dup

def need_value(args, opt)
  if args.empty?
    warn "error: a value is required for '#{opt} <value>' but none was supplied"
    exit 2
  end
  args.shift
end

def parse_int(s, optname = nil)
  Integer(s, 10)
rescue ArgumentError
  if optname == 'cols'
    warn "-c, --cols <integer> expected. ParseIntError { kind: InvalidDigit }"
    warn "error: invalid digit found in string"
    exit 1
  end
  warn "error: invalid digit found in string"
  exit 1
end

until args.empty?
  a = args.shift
  case a
  when '-h', '--help'
    print HELP
    exit 0
  when '-V', '--version'
    puts 'hx 0.7.0'
    exit 0
  when '-c', '--cols'
    opts[:cols] = parse_int(need_value(args, a), 'cols')
  when /^--cols=(.*)$/
    opts[:cols] = parse_int($1, 'cols')
  when /^-c(.+)$/
    opts[:cols] = parse_int($1, 'cols')
  when '-l', '--len'
    opts[:len] = parse_int(need_value(args, a))
  when /^--len=(.*)$/
    opts[:len] = parse_int($1)
  when /^-l(.+)$/
    opts[:len] = parse_int($1)
  when '-f', '--format'
    opts[:format] = need_value(args, a)
  when /^--format=(.*)$/
    opts[:format] = $1
  when /^-f(.+)$/
    opts[:format] = $1
  when '-t', '--color'
    opts[:color] = parse_int(need_value(args, a))
  when /^--color=(.*)$/
    opts[:color] = parse_int($1)
  when /^-t(.+)$/
    opts[:color] = parse_int($1)
  when '-a', '--array'
    opts[:array] = need_value(args, a)
  when /^--array=(.*)$/
    opts[:array] = $1
  when /^-a(.+)$/
    opts[:array] = $1
  when '-u', '--func'
    opts[:func] = parse_int(need_value(args, a))
  when /^--func=(.*)$/
    opts[:func] = parse_int($1)
  when /^-u(.+)$/
    opts[:func] = parse_int($1)
  when '-p', '--places'
    opts[:places] = parse_int(need_value(args, a))
  when /^--places=(.*)$/
    opts[:places] = parse_int($1)
  when /^-p(.+)$/
    opts[:places] = parse_int($1)
  when '-r', '--prefix'
    opts[:prefix] = parse_int(need_value(args, a))
  when /^--prefix=(.*)$/
    opts[:prefix] = parse_int($1)
  when /^-r(.+)$/
    opts[:prefix] = parse_int($1)
  when '--'
    input = args.shift unless args.empty?
    unless args.empty?
      warn "error: unexpected argument '#{args.first}' found"
      exit 2
    end
  when /^-/
    warn "error: unexpected argument '#{a}' found"
    warn "\n  tip: to pass '#{a}' as a value, use '-- #{a}'"
    warn "\nUsage: #{PROG} [OPTIONS] [INPUTFILE]"
    warn "\nFor more information, try '--help'."
    exit 2
  else
    if input
      warn "error: unexpected argument '#{a}' found"
      exit 2
    end
    input = a
  end
end

unless %w[o x X b].include?(opts[:format])
  warn "error: invalid value '#{opts[:format]}' for '--format <format>'"
  warn "  [possible values: o, x, X, b]"
  warn "\nFor more information, try '--help'."
  exit 2
end
if opts[:array] && !%w[r c g p k j s f].include?(opts[:array])
  warn "error: invalid value '#{opts[:array]}' for '--array <array_format>'"
  warn "  [possible values: r, c, g, p, k, j, s, f]"
  warn "\nFor more information, try '--help'."
  exit 2
end
if ![nil, 0, 1].include?(opts[:color])
  warn "error: invalid value '#{opts[:color]}' for '--color <color>'"
  warn "  [possible values: 0, 1]"
  exit 2
end
if ![0, 1].include?(opts[:prefix])
  warn "error: invalid value '#{opts[:prefix]}' for '--prefix <prefix>'"
  warn "  [possible values: 0, 1]"
  exit 2
end

if opts[:func]
  n = [opts[:func], 0].max
  vals = (0...n).map { |i| Math.sin(i * Math::PI / (2.0 * n)) }
  print vals.map { |v| format("%.#{opts[:places]}f", v) }.join(',')
  print ',' if n > 0
  print "\n"
  exit 0
end

begin
  data = if input
           File.binread(input)
         else
           STDIN.binmode.read || ''.b
         end
rescue SystemCallError => e
  warn "error: #{e.message}"
  exit 1
end
limit = opts[:len]
data = data.byteslice(0, limit) if limit && limit > 0
bytes = data.bytes
cols = opts[:cols] <= 0 ? 1 : opts[:cols]

def byte_repr(b, fmt, prefix = true)
  case fmt
  when 'x'
    s = format('%02x', b); prefix ? "0x#{s}" : s
  when 'X'
    s = format('%02X', b); prefix ? "0x#{s}" : s
  when 'o'
    s = format('%04o', b); prefix ? "0o#{s}" : s
  when 'b'
    s = format('%08b', b); prefix ? "0b#{s}" : s
  end
end

def printable(b)
  (b >= 0x20 && b <= 0x7e) ? b.chr : '.'
end

if opts[:array]
  vals = bytes.map { |b| byte_repr(b, opts[:format], true) }
  lines = vals.each_slice(cols).map do |slice|
    body = slice.join(', ')
    body += ', ' if slice.length == cols && slice != vals.each_slice(cols).to_a.last
    "    #{body}"
  end
  lines = ['    '] if vals.empty?
  case opts[:array]
  when 'r'
    puts "let ARRAY: [u8; #{bytes.length}] = ["
    puts lines
    puts '];'
  when 'c'
    puts "unsigned char ARRAY[#{bytes.length}] = {"
    puts lines
    puts '};'
  when 'g'
    puts "a := [#{bytes.length}]byte{"
    puts lines.map { |l| l.end_with?(', ') ? l : l + ', ' }
    puts '}'
  when 'p'
    puts 'a = ['
    puts lines
    puts ']'
  when 'k'
    puts 'val a = byteArrayOf('
    puts lines
    puts ')'
  when 'j'
    puts 'byte[] a = new byte[]{'
    puts lines
    puts '};'
  when 's'
    puts 'let a: [UInt8] = ['
    puts lines
    puts ']'
  when 'f'
    fvals = bytes.map { |b| byte_repr(b, opts[:format], true) + 'uy' }
    flines = fvals.each_slice(cols).map do |slice|
      body = slice.join('; ')
      body += '; ' if slice.length == cols && slice != fvals.each_slice(cols).to_a.last
      "    #{body}"
    end
    flines = ['    '] if fvals.empty?
    puts 'let a = [|'
    puts flines
    puts '|]'
  end
  exit 0
end

prefix = opts[:prefix] == 1
use_color = opts[:color] == 1 && !ENV.key?('NO_COLOR')
color_code = ->(b) { b == 0 ? 22 : b }
rows = bytes.each_slice(cols).to_a
rows << [] if bytes.empty? || (bytes.length % cols).zero?
rows.each_with_index do |chunk, idx|
  off = idx * cols
  parts = chunk.map do |b|
    s = byte_repr(b, opts[:format], prefix)
    use_color ? "\e[38;5;#{color_code.call(b)}m#{s}\e[0m" : s
  end
  plain = chunk.map { |b| byte_repr(b, opts[:format], prefix) }.join(' ')
  visible_pad = (cols - chunk.length) * 5
  pad_width = (chunk.empty? && opts[:cols] <= 0) ? 0 : [visible_pad, 0].max
  hexes = parts.join(' ') + (' ' * pad_width)
  ascii = chunk.map do |b|
    ch = printable(b)
    use_color ? "\e[38;5;#{color_code.call(b)}m#{ch}\e[0m" : ch
  end.join
  if chunk.empty?
    puts "0x#{format('%06x', off)}: #{hexes}"
  else
    puts "0x#{format('%06x', off)}: #{hexes} #{ascii}"
  end
end
puts format('%8s: %d', 'bytes', bytes.length)
