#!/usr/bin/env ruby
# frozen_string_literal: true

require 'json'

HELP = <<~TEXT
Usage:
    go test ./... -json | tparse [options...]
    go test [packages...] -json | tparse [options...]
    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out

Options:
    -h                 Show help.
    -v                 Show version.
    -all               Display table event for pass and skip. (Failed items always displayed)
    -pass              Display table for passed tests.
    -skip              Display table for skipped tests.
    -notests           Display packages containing no test files or empty test files.
    -smallscreen       Split subtest names vertically to fit on smaller screens.
    -slow              Number of slowest tests to display. Default is 0, display all.
    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.
    -nocolor           Disable all colors. (NO_COLOR also supported)
    -format            The output format for tables [basic, plain, markdown]. Default is basic.
    -file              Read test output from a file.
    -follow            Follow raw output from go test to stdout.
    -follow-output     Write raw output from go test to a file (takes precedence over -follow).
    -include-timestamp Include timestamps in follow output. 
    -progress          Print a single summary line for each package. Useful for long running test suites.
    -compare           Compare against a previous test output file. (experimental)
    -trimpath          Remove path prefix from package names in output, simplifying their display.
TEXT

def die(message, code = 1)
  warn message
  exit code
end

opts = {
  all: false, pass: false, skip: false, notests: false, smallscreen: false,
  slow: 0, sort: 'name', nocolor: false, format: 'basic', file: nil,
  follow: false, follow_output: nil, include_timestamp: false, progress: false,
  compare: nil, trimpath: nil
}

bool_flags = {
  'h' => :help, 'help' => :help, 'v' => :version, 'version' => :version,
  'all' => :all, 'pass' => :pass, 'skip' => :skip,
  'notests' => :notests, 'smallscreen' => :smallscreen, 'nocolor' => :nocolor,
  'follow' => :follow, 'include-timestamp' => :include_timestamp, 'progress' => :progress
}
value_flags = {
  'slow' => :slow, 'sort' => :sort, 'format' => :format, 'file' => :file,
  'follow-output' => :follow_output, 'compare' => :compare, 'trimpath' => :trimpath
}
i = 0
while i < ARGV.length
  arg = ARGV[i]
  break unless arg.start_with?('-')
  name, value = arg.sub(/\A-+/, '').split('=', 2)
  if bool_flags.key?(name)
    key = bool_flags[name]
    if key == :help
      puts HELP
      exit 0
    elsif key == :version
      puts 'tparse version: (devel)'
      exit 0
    else
      opts[key] = true
    end
  elsif value_flags.key?(name)
    if value.nil?
      i += 1
      if i >= ARGV.length
        warn "flag needs an argument: -#{name}"
        exit 2
      end
      value = ARGV[i]
    end
    key = value_flags[name]
    opts[key] = key == :slow ? value.to_i : value
  else
    warn "flag provided but not defined: -#{name}"
    puts HELP
    exit 2
  end
  i += 1
end

die(%(invalid option:"#{opts[:format]}". The -format flag must be one of: basic, plain or markdown)) unless %w[basic plain markdown].include?(opts[:format])
die(%(invalid option:"#{opts[:sort]}". The -sort flag must be one of: name, elapsed or cover)) unless %w[name elapsed cover].include?(opts[:sort])

input =
  if opts[:file]
    begin
      File.read(opts[:file])
    rescue StandardError => e
      die(e.message)
    end
  else
    if STDIN.tty?
      die('stdin must be a pipe, or use -file to open a go test output file')
    end
    STDIN.read
  end
die('stdin must be a pipe, or use -file to open a go test output file') if !opts[:file] && input.empty?

follow_io = nil
if opts[:follow_output]
  follow_io = File.open(opts[:follow_output], 'w')
end

packages = Hash.new do |h, pkg|
  h[pkg] = {
    name: pkg, status: nil, elapsed: 0.0, cover: '--',
    tests: {}, pass: 0, fail: 0, skip: 0, outputs: [], no_tests: false
  }
end

events = []
input.each_line do |line|
  next if line.strip.empty?

  begin
    ev = JSON.parse(line)
  rescue JSON::ParserError => e
    die("failed to parse json: #{e.message}")
  end
  events << ev
  pkg_name = ev['Package'] || ''
  pkg = packages[pkg_name]
  action = ev['Action']
  test = ev['Test']
  output = ev['Output']

  if output
    raw = opts[:include_timestamp] && ev['Time'] ? "#{ev['Time']} #{output}" : output
    if opts[:follow_output]
      follow_io.write(raw)
    elsif opts[:follow]
      print raw
    end
    pkg[:outputs] << [test, output]
    if output =~ /coverage:\s+([0-9.]+%)/
      pkg[:cover] = Regexp.last_match(1)
    end
    pkg[:no_tests] = true if output.include?('[no test files]') || output.include?('[no tests to run]')
  end

  next unless action

  if test && %w[pass fail skip].include?(action)
    pkg[:tests][test] ||= { name: test, package: pkg_name, status: nil, elapsed: 0.0, outputs: [] }
    t = pkg[:tests][test]
    t[:status] = action.upcase
    t[:elapsed] = ev['Elapsed'].to_f
    t[:outputs] = pkg[:outputs].select { |name, _| name == test }.map(&:last)
  elsif !test && %w[pass fail skip].include?(action)
    pkg[:status] = (pkg[:no_tests] && action == 'skip') ? 'NOTEST' : action.upcase
    pkg[:elapsed] = ev['Elapsed'].to_f
    pkg[:pass] = pkg[:tests].values.count { |t| t[:status] == 'PASS' }
    pkg[:fail] = pkg[:tests].values.count { |t| t[:status] == 'FAIL' }
    pkg[:skip] = pkg[:tests].values.count { |t| t[:status] == 'SKIP' }
    if opts[:progress]
      printf("[%s]\t%9.2fs\t%s\n", pkg[:status], pkg[:elapsed], pkg[:name])
    end
  end
end
follow_io&.close

def trim_name(name, prefix)
  return name unless prefix && !prefix.empty?
  name.start_with?(prefix) ? name[prefix.length..] : name
end

packages.each_value do |pkg|
  pkg[:name] = trim_name(pkg[:name], opts[:trimpath])
  pkg[:tests].each_value { |t| t[:package] = trim_name(t[:package], opts[:trimpath]) }
  pkg[:status] ||= pkg[:no_tests] ? 'NOTEST' : 'PASS'
  pkg[:pass] = pkg[:tests].values.count { |t| t[:status] == 'PASS' }
  pkg[:fail] = pkg[:tests].values.count { |t| t[:status] == 'FAIL' }
  pkg[:skip] = pkg[:tests].values.count { |t| t[:status] == 'SKIP' }
end

def visible_width(s)
  s.to_s.each_line.map { |line| line.chomp.length }.max || 0
end

def cell_lines(value)
  value.to_s.split("\n", -1)
end

def format_elapsed(v, suffix: false)
  format('%.2f%s', v.to_f, suffix ? 's' : '')
end

def sort_rows(rows, key)
  case key
  when 'elapsed'
    rows.sort_by { |r| -r[:elapsed].to_f }
  when 'cover'
    rows.sort_by { |r| -(r[:cover].to_s == '--' ? -1.0 : r[:cover].to_f) }
  else
    rows.sort_by { |r| [r[:package].to_s, r[:test].to_s, r[:name].to_s] }
  end
end

def center(text, width)
  text = text.to_s
  pad = [width - text.length, 0].max
  left = pad / 2
  right = pad - left
  (' ' * left) + text + (' ' * right)
end

def render_basic(headers, rows)
  data = rows.map { |r| headers.map { |h| r[h] } }
  widths = headers.each_with_index.map do |h, i|
    ([h.length] + data.map { |row| visible_width(row[i]) }).max
  end
  top = '╭' + widths.map { |w| '─' * (w + 2) }.join('┬') + '╮'
  mid = '├' + widths.map { |w| '─' * (w + 2) }.join('┼') + '┤'
  bot = '╰' + widths.map { |w| '─' * (w + 2) }.join('┴') + '╯'
  out = [top]
  out << '│' + headers.each_with_index.map { |h, i| " #{center(h, widths[i])} " }.join('│') + '│'
  out << mid
  data.each do |row|
    lines = row.map { |c| cell_lines(c) }
    height = lines.map(&:length).max
    height.times do |j|
      out << '│' + lines.each_with_index.map do |ls, i|
        text = ls[j] || ''
        align_center = %w[Status Elapsed Cover Pass Fail Skip].include?(headers[i])
        body = align_center ? center(text, widths[i]) : text.ljust(widths[i])
        " #{body} "
      end.join('│') + '│'
    end
  end
  out << bot
  out.join("\n")
end

def render_plain(headers, rows)
  data = rows.map { |r| headers.map { |h| r[h] } }
  widths = headers.each_with_index.map { |h, i| ([h.length] + data.map { |row| visible_width(row[i]) }).max }
  out = []
  out << '  ' + headers.each_with_index.map { |h, i| center(h, widths[i]) }.join('   ') + '  '
  out << '  ' + widths.map { |w| ' ' * w }.join('   ') + '  '
  data.each do |row|
    out << '  ' + row.each_with_index.map do |c, i|
      %w[Status Elapsed Cover Pass Fail Skip].include?(headers[i]) ? center(c, widths[i]) : c.to_s.ljust(widths[i])
    end.join('   ') + '  '
  end
  out.join("\n")
end

def render_markdown(headers, rows)
  data = rows.map { |r| headers.map { |h| r[h] } }
  widths = headers.each_with_index.map { |h, i| ([h.length] + data.map { |row| visible_width(row[i]) }).max }
  out = []
  out << '| ' + headers.each_with_index.map { |h, i| h.ljust(widths[i]) }.join(' | ') + ' |'
  out << '|-' + widths.map { |w| '-' * w }.join('-|-') + '-|'
  data.each do |row|
    out << '| ' + row.each_with_index.map do |c, i|
      text = c.to_s.gsub("\n", '<br>')
      %w[Status Elapsed Cover Pass Fail Skip].include?(headers[i]) ? center(text, widths[i]) : text.ljust(widths[i])
    end.join(' | ') + ' |'
  end
  out.join("\n")
end

def render_table(headers, rows, format)
  return '' if rows.empty?
  case format
  when 'plain' then render_plain(headers, rows)
  when 'markdown' then render_markdown(headers, rows)
  else render_basic(headers, rows)
  end
end

def fail_output_for(pkg, test)
  detail = []
  header = nil
  test[:outputs].each do |line|
    next if line.start_with?('=== RUN')
    next if line.start_with?('--- PASS:')
    next if line.start_with?('--- SKIP:')
    if line.start_with?('--- FAIL:')
      header = line
    else
      detail << line
    end
  end
  header ||= "--- FAIL: #{test[:name]} (#{format('%.2fs', test[:elapsed])})\n"
  (header + "\n" + detail.join).chomp
end

failed = packages.values.select { |p| p[:status] == 'FAIL' || p[:fail].positive? }
failed.each do |pkg|
  width = "   FAIL  package: #{pkg[:name]}   ".length
  puts '┏' + '━' * width + '┓'
  puts '┃' + center("FAIL  package: #{pkg[:name]}", width) + '┃'
  puts '┗' + '━' * width + '┛'
  puts
  failed_tests = pkg[:tests].values.select { |t| t[:status] == 'FAIL' }
  if failed_tests.empty?
    text = pkg[:outputs].map(&:last).reject { |line| line.start_with?('FAIL\t') || line.start_with?('FAIL ') }.join
    puts text.chomp unless text.empty?
    puts unless text.empty?
  end
  failed_tests.each do |test|
    puts fail_output_for(pkg, test)
    puts
  end
end

test_rows = []
packages.each_value do |pkg|
  pkg[:tests].each_value do |t|
    keep = opts[:all] || (opts[:pass] && t[:status] == 'PASS') || (opts[:skip] && t[:status] == 'SKIP')
    next unless keep
    test_rows << {
      'Status' => t[:status], 'Elapsed' => format_elapsed(t[:elapsed]), 'Test' => t[:name],
      'Package' => t[:package], elapsed: t[:elapsed], test: t[:name], package: t[:package]
    }
  end
end
test_rows = sort_rows(test_rows, opts[:sort])
if opts[:slow].positive?
  grouped = test_rows.group_by { |r| r['Status'] }
  test_rows = grouped.values.flat_map { |rows| rows.sort_by { |r| -r[:elapsed] }.first(opts[:slow]) }
end

pkg_rows = packages.values.map do |p|
  no = p[:status] == 'NOTEST'
  name = no && p[:outputs].any? ? "#{p[:name]}\n#{p[:outputs].map(&:last).join[/\[[^\]]+\]/] || '[no test files]'}" : p[:name]
  {
    'Status' => p[:status], 'Elapsed' => format_elapsed(p[:elapsed], suffix: true), 'Package' => name,
    'Cover' => p[:cover], 'Pass' => no ? '--' : p[:pass].to_s, 'Fail' => no ? '--' : p[:fail].to_s,
    'Skip' => no ? '--' : p[:skip].to_s, elapsed: p[:elapsed], cover: p[:cover], package: p[:name]
  }
end
pkg_rows = sort_rows(pkg_rows, opts[:sort])

if opts[:format] == 'markdown'
  packages.values.each do |pkg|
    rows = test_rows.select { |r| r['Package'] == pkg[:name] }
    next if rows.empty?
    puts "## 📦 Package **`#{pkg[:name]}`**"
    puts
    puts "Tests: ✓ #{pkg[:pass]} passed | #{pkg[:skip]} skipped | #{pkg[:fail]} failed"
    puts
    puts '<details>'
    puts
    puts '<summary>Click for test summary</summary>'
    puts
    puts render_table(%w[Status Elapsed Test], rows, opts[:format])
    puts '</details>'
    puts
    puts
  end
else
  table = render_table(%w[Status Elapsed Test Package], test_rows, opts[:format])
  puts table unless table.empty?
end

pkg_table = render_table(%w[Status Elapsed Package Cover Pass Fail Skip], pkg_rows, opts[:format])
puts pkg_table unless pkg_table.empty?

exit(failed.empty? ? 0 : 1)
