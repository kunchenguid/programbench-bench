#!/usr/bin/env ruby
# frozen_string_literal: true

require "cgi"
require "fileutils"
require "uri"

Node = Struct.new(:type, :name, :attrs, :children, :text, keyword_init: true)

class Parser
  VOID = %w[area base br col embed hr img input link meta param source track wbr].freeze

  def initialize(html)
    @html = html.to_s
  end

  def parse
    root = Node.new(type: :element, name: "root", attrs: {}, children: [])
    stack = [root]
    @html.scan(/<!--.*?-->|<!\[CDATA\[.*?\]\]>|<![^>]*>|<\/?[A-Za-z][^>]*>|[^<]+|</m) do |tok|
      if tok.start_with?("<!--", "<!")
        next
      elsif tok.start_with?("</")
        name = tok[/^<\/\s*([^\s>]+)/, 1].to_s.downcase
        idx = stack.rindex { |n| n.name == name }
        stack.slice!(idx..) if idx && idx.positive?
      elsif tok.start_with?("<") && tok =~ /^<\s*([A-Za-z][^\s\/>]*)/m
        name = Regexp.last_match(1).downcase
        attrs = parse_attrs(tok)
        node = Node.new(type: :element, name: name, attrs: attrs, children: [])
        stack.last.children << node
        stack << node unless tok.end_with?("/>") || VOID.include?(name)
      else
        stack.last.children << Node.new(type: :text, text: CGI.unescapeHTML(tok))
      end
    end
    root
  end

  def parse_attrs(tag)
    attrs = {}
    tag.scan(/([A-Za-z_:][-A-Za-z0-9_:.]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+))/m) do |k, v1, v2, v3|
      attrs[k.downcase] = CGI.unescapeHTML(v1 || v2 || v3 || "")
    end
    tag.scan(/\s([A-Za-z_:][-A-Za-z0-9_:.]*)(?=\s|\/?>)/m) { |k| attrs[k[0].downcase] ||= "" }
    attrs
  end
end

class Renderer
  BLOCKS = %w[p div section article main header footer nav aside figure figcaption address center].freeze
  SKIP = %w[script style noscript template head meta link title svg].freeze

  def initialize(opts)
    @opts = opts
  end

  def render(root)
    apply_selectors!(root)
    out = children(root).gsub(/\A\n+|\n+\z/, "")
    out = out.gsub(/\n{3,}/, "\n\n")
    out.gsub!(/~~([^~]+)~~~~([^~]+)~~/, '~~\1\2~~') while out =~ /~~([^~]+)~~~~([^~]+)~~/
    out + (out.empty? ? "" : "\n")
  end

  def children(node, ctx = {})
    node.children.to_a.map { |c| render_node(c, ctx) }.join
  end

  def render_node(node, ctx = {})
    return escape_text(node.text.to_s, ctx) if node.type == :text
    return "" if SKIP.include?(node.name)

    name = node.name
    case name
    when "html", "body", "root"
      children(node, ctx)
    when *BLOCKS
      block(children(node, ctx))
    when "br"
      "  \n"
    when "hr"
      "\n\n* * *\n\n"
    when /^h([1-6])$/
      level = Regexp.last_match(1).to_i
      "\n\n#{"#" * level} #{inline(children(node, ctx))}\n\n"
    when "strong", "b"
      d = @opts[:strong_delimiter]
      "#{d}#{inline(children(node, ctx.merge(markup: true)))}#{d}"
    when "em", "i"
      "*#{inline(children(node, ctx.merge(markup: true)))}*"
    when "code"
      if ctx[:pre]
        node_text(node)
      else
        "`#{node_text(node).gsub("`", "\\`")}`"
      end
    when "pre"
      code = children(node, ctx.merge(pre: true, no_escape: true)).sub(/\n+\z/, "")
      "\n\n```\n#{code}\n```\n\n"
    when "a"
      href = absolutize(node.attrs["href"].to_s)
      text = inline(children(node, ctx))
      href.empty? ? text : "[#{text}](#{href})"
    when "img"
      alt = escape_text(node.attrs["alt"].to_s, ctx)
      src = absolutize(node.attrs["src"].to_s)
      "![#{alt}](#{src})"
    when "ul"
      list(node, false, ctx)
    when "ol"
      list(node, true, ctx)
    when "li"
      inline(children(node, ctx))
    when "blockquote"
      body = children(node, ctx).strip.gsub(/\n{2,}/, "\n\n")
      "\n\n" + body.split("\n", -1).map { |l| l.empty? ? "> " : "> #{l}" }.join("\n") + "\n\n"
    when "del", "s", "strike"
      @opts[:strike] ? "~~#{inline(children(node, ctx.merge(markup: true)))}~~" : children(node, ctx)
    when "table"
      @opts[:table] ? table(node, ctx) : block(children(node, ctx))
    when "thead", "tbody", "tfoot", "tr", "td", "th"
      children(node, ctx)
    else
      children(node, ctx)
    end
  end

  def block(s)
    t = s.strip
    t.empty? ? "" : "\n\n#{t}\n\n"
  end

  def inline(s)
    s.gsub(/[ \t\r\n]+/, " ").strip
  end

  def list(node, ordered, ctx)
    items = node.children.select { |c| c.type == :element && c.name == "li" }
    lines = []
    items.each_with_index do |li, i|
      nested = li.children.select { |c| c.type == :element && %w[ul ol].include?(c.name) }
      li.children.delete_if { |c| nested.include?(c) }
      first = inline(children(li, ctx))
      marker = ordered ? "#{i + 1}. " : "- "
      lines << "#{marker}#{first}"
      nested.each do |n|
        sub = render_node(n, ctx).strip
        lines << "  " unless sub.empty?
        lines << sub.split("\n").map { |l| "  #{l}" }.join("\n") unless sub.empty?
      end
    end
    "\n\n#{lines.join("\n")}\n\n"
  end

  def table(node, ctx)
    rows = descendants(node, "tr").map do |tr|
      tr.children.select { |c| c.type == :element && %w[td th].include?(c.name) }.map { |cell| inline(children(cell, ctx)) }
    end.reject { |r| r.all?(&:empty?) && @opts[:table_skip_empty] }
    return "" if rows.empty?

    widths = rows.map(&:length).max || 0
    rows.each { |r| r.fill("", r.length...widths) }
    header = rows.shift
    if !node_has_th?(node) && !@opts[:table_promote]
      rows.unshift(header)
      header = Array.new(widths, "")
    end
    out = []
    out << "| #{header.join(" | ")} |"
    out << "|#{Array.new(widths, "---").join("|")}|"
    rows.each { |r| out << "| #{r.join(" | ")} |" }
    "\n\n#{out.join("\n")}\n\n"
  end

  def node_has_th?(node)
    descendants(node, "th").any?
  end

  def descendants(node, name)
    found = []
    node.children.to_a.each do |c|
      next unless c.type == :element
      found << c if c.name == name
      found.concat(descendants(c, name))
    end
    found
  end

  def node_text(node)
    if node.type == :text
      node.text.to_s
    else
      node.children.to_a.map { |c| node_text(c) }.join
    end
  end

  def escape_text(text, ctx)
    return text if ctx[:no_escape]
    parts = []
    rest = text.to_s
    until rest.empty?
      if (m = rest.match(/\*\*(.+?)\*\*/m))
        parts << escape_basic(m.pre_match)
        parts << "\\*\\*#{escape_basic(m[1])}\\**"
        rest = m.post_match
      else
        parts << escape_basic(rest)
        rest = ""
      end
    end
    parts.join
  end

  def escape_basic(text)
    text.gsub(/([\\*_`\[\]])/, '\\\\\1')
  end

  def absolutize(url)
    return "" if url.nil? || url.empty?
    base = @opts[:domain]
    return url if base.nil? || base.empty? || url =~ /^[a-z][a-z0-9+.-]*:/i || url.start_with?("#", "mailto:")
    URI.join(base, url).to_s
  rescue URI::Error
    url
  end

  def apply_selectors!(root)
    if @opts[:include]
      matches = []
      collect(root) { |n| matches << n if match_selector?(n, @opts[:include]) }
      root.children = matches
    end
    if @opts[:exclude]
      prune!(root, @opts[:exclude])
    end
  end

  def collect(node, &blk)
    node.children.to_a.each do |c|
      next unless c.type == :element
      yield c
      collect(c, &blk)
    end
  end

  def prune!(node, selector)
    node.children = node.children.to_a.reject { |c| c.type == :element && match_selector?(c, selector) }
    node.children.each { |c| prune!(c, selector) if c.type == :element }
  end

  def match_selector?(node, selector)
    selector.to_s.split(",").any? do |sel|
      sel = sel.strip
      if sel.start_with?(".")
        node.attrs["class"].to_s.split.include?(sel[1..])
      elsif sel.start_with?("#")
        node.attrs["id"] == sel[1..]
      elsif sel.include?(".")
        tag, cls = sel.split(".", 2)
        node.name == tag.downcase && node.attrs["class"].to_s.split.include?(cls)
      else
        node.name == sel.downcase
      end
    end
  end
end

class CLI
  def self.run(argv)
    opts = { strong_delimiter: "**", table_skip_empty: false }
    i = 0
    while i < argv.length
      arg = argv[i]
      key, val = arg.split("=", 2)
      case key
      when "--help"
        puts HELP
        return 0
      when "-v", "--version"
        puts "html2markdown\n\nGitVersion:  dev\nGitCommit:   none\nBuildDate:   unknown"
        return 0
      when "--input"
        opts[:input] = val || argv[i += 1]
      when "--output"
        opts[:output] = val || argv[i += 1]
      when "--output-overwrite"
        opts[:overwrite] = true
      when "--domain"
        opts[:domain] = val || argv[i += 1]
      when "--exclude-selector"
        opts[:exclude] = val || argv[i += 1]
      when "--include-selector"
        opts[:include] = val || argv[i += 1]
      when "--opt-strong-delimiter"
        opts[:strong_delimiter] = val || argv[i += 1]
      when "--plugin-strikethrough"
        opts[:strike] = true
      when "--plugin-table"
        opts[:table] = true
      when "--opt-table-skip-empty-rows"
        opts[:table_skip_empty] = true
      when "--opt-table-header-promotion"
        opts[:table_promote] = true
      when /\A--opt-table-/
        val || argv[i += 1] if %w[--opt-table-cell-padding-behavior --opt-table-newline-behavior --opt-table-span-cell-behavior --opt-table-presentation-tables].include?(key) && argv[i + 1]&.!~(/\A--/)
      else
        warn "\nerror: unknown flag: #{arg}\n\n"
        return 1
      end
      i += 1
    end

    if opts[:input]
      return convert_paths(opts)
    end
    md = convert($stdin.read, opts)
    write_output(md, opts)
    0
  rescue StandardError => e
    warn "error: #{e.message}"
    1
  end

  def self.convert(html, opts)
    Renderer.new(opts).render(Parser.new(html).parse)
  end

  def self.convert_paths(opts)
    paths = if File.directory?(opts[:input])
              Dir[File.join(opts[:input], "*")]
            else
              Dir[opts[:input]]
            end.select { |p| File.file?(p) }
    if paths.empty?
      warn "\nerror: no files found matching pattern \"#{opts[:input]}\"\n\nHere is how you can use a glob to match multiple files:\n\n    html2markdown --input \"src/*.html\" --output \"dist/\"\n\n"
      return 1
    end
    if paths.length == 1 && (!opts[:output] || !File.directory?(opts[:output]))
      md = convert(File.read(paths[0]), opts)
      write_output(md, opts)
    else
      unless opts[:output] && File.directory?(opts[:output])
        warn "error: if --input is a directory or glob pattern, --output must be a directory"
        return 1
      end
      paths.each do |path|
        out = File.join(opts[:output], File.basename(path).sub(/\.[^.]*\z/, ".md"))
        raise "output file already exists: #{out}" if File.exist?(out) && !opts[:overwrite]
        File.write(out, convert(File.read(path), opts))
      end
    end
    0
  end

  def self.write_output(md, opts)
    if opts[:output]
      raise "output file already exists: #{opts[:output]}" if File.exist?(opts[:output]) && !opts[:overwrite]
      FileUtils.mkdir_p(File.dirname(opts[:output])) unless File.dirname(opts[:output]) == "."
      File.write(opts[:output], md)
    else
      print md
    end
  end

  HELP = <<~TXT

    # html2markdown - convert html to markdown [version dev]

    Convert HTML to Markdown. Even works with entire websites!

    ## Flags

        -v, --version
            show the version of html2markdown and exit

        --help

        --input PATH
            Input file, directory, or glob pattern (instead of stdin)

        --output PATH
            Output file or directory (instead of stdout)

        --output-overwrite
            Replace existing files

        --domain
            The url of the web page, used to convert relative links to absolute links.

        --exclude-selector
            css query selector to exclude parts of the input

        --include-selector
            css query selector to only include parts of the input

        --opt-strong-delimiter
            "**" or "__" (default: "**")

        --plugin-strikethrough
            enable the plugin ~~strikethrough~~

        --plugin-table
            enable the plugin table
  TXT
end

exit CLI.run(ARGV)
