#!/usr/bin/env ruby
# frozen_string_literal: true

require 'zlib'

COMMANDS = {
  'supervised' => 'train a supervised classifier',
  'quantize' => 'quantize a model to reduce the memory usage',
  'test' => 'evaluate a supervised classifier',
  'test-label' => 'print labels with precision and recall scores',
  'predict' => 'predict most likely labels',
  'predict-prob' => 'predict most likely labels with probabilities',
  'skipgram' => 'train a skipgram model',
  'cbow' => 'train a cbow model',
  'print-word-vectors' => 'print word vectors given a trained model',
  'print-sentence-vectors' => 'print sentence vectors given a trained model',
  'print-ngrams' => 'print ngrams given a trained model and word',
  'nn' => 'query for nearest neighbors',
  'analogies' => 'query for analogies',
  'dump' => 'dump arguments,dictionary,input/output vectors'
}.freeze

TRAIN_KEYS = %w[
  -input -output -verbose -minCount -minCountLabel -wordNgrams -bucket -minn
  -maxn -t -label -lr -lrUpdateRate -dim -ws -epoch -neg -loss -thread
  -pretrainedVectors -saveOutput -seed -autotune-validation -autotune-metric
  -autotune-predictions -autotune-duration -autotune-modelsize -cutoff
  -retrain -qnorm -qout -dsub
].freeze

def main_usage
  puts 'usage: fasttext <command> <args>'
  puts
  puts 'The commands supported by fasttext are:'
  puts
  COMMANDS.each { |cmd, desc| puts format('  %-23s %s', cmd, desc) }
end

def train_defaults(cmd)
  supervised = cmd == 'supervised'
  {
    '-input' => '',
    '-output' => '',
    '-verbose' => '2',
    '-minCount' => supervised ? '1' : '5',
    '-minCountLabel' => '0',
    '-wordNgrams' => '1',
    '-bucket' => '2000000',
    '-minn' => supervised ? '0' : '3',
    '-maxn' => supervised ? '0' : '6',
    '-t' => '0.0001',
    '-label' => '__label__',
    '-lr' => supervised ? '0.1' : '0.05',
    '-lrUpdateRate' => '100',
    '-dim' => '100',
    '-ws' => '5',
    '-epoch' => '5',
    '-neg' => '5',
    '-loss' => supervised ? 'softmax' : 'ns',
    '-thread' => '12',
    '-pretrainedVectors' => '',
    '-saveOutput' => 'false',
    '-seed' => '0',
    '-autotune-validation' => '',
    '-autotune-metric' => 'f1',
    '-autotune-predictions' => '1',
    '-autotune-duration' => '300',
    '-autotune-modelsize' => '',
    '-cutoff' => '0',
    '-retrain' => 'false',
    '-qnorm' => 'false',
    '-qout' => 'false',
    '-dsub' => '2'
  }
end

def train_usage(cmd, prefix = nil)
  puts prefix if prefix
  puts 'usage: fasttext quantize <args>' if cmd == 'quantize'
  puts
  d = train_defaults(cmd)
  puts 'The following arguments are mandatory:'
  puts '  -input              training file path'
  puts '  -output             output file path'
  puts
  puts 'The following arguments are optional:'
  puts "  -verbose            verbosity level [#{d['-verbose']}]"
  puts
  puts 'The following arguments for the dictionary are optional:'
  puts "  -minCount           minimal number of word occurences [#{d['-minCount']}]"
  puts "  -minCountLabel      minimal number of label occurences [#{d['-minCountLabel']}]"
  puts "  -wordNgrams         max length of word ngram [#{d['-wordNgrams']}]"
  puts "  -bucket             number of buckets [#{d['-bucket']}]"
  puts "  -minn               min length of char ngram [#{d['-minn']}]"
  puts "  -maxn               max length of char ngram [#{d['-maxn']}]"
  puts "  -t                  sampling threshold [#{d['-t']}]"
  puts "  -label              labels prefix [#{d['-label']}]"
  puts
  puts 'The following arguments for training are optional:'
  puts "  -lr                 learning rate [#{d['-lr']}]"
  puts "  -lrUpdateRate       change the rate of updates for the learning rate [#{d['-lrUpdateRate']}]"
  puts "  -dim                size of word vectors [#{d['-dim']}]"
  puts "  -ws                 size of the context window [#{d['-ws']}]"
  puts "  -epoch              number of epochs [#{d['-epoch']}]"
  puts "  -neg                number of negatives sampled [#{d['-neg']}]"
  puts "  -loss               loss function {ns, hs, softmax, one-vs-all} [#{d['-loss']}]"
  puts "  -thread             number of threads (set to 1 to ensure reproducible results) [#{d['-thread']}]"
  puts "  -pretrainedVectors  pretrained word vectors for supervised learning [#{d['-pretrainedVectors']}]"
  puts "  -saveOutput         whether output params should be saved [#{d['-saveOutput']}]"
  puts "  -seed               random generator seed  [#{d['-seed']}]"
  puts
  puts 'The following arguments are for autotune:'
  puts '  -autotune-validation            validation file to be used for evaluation'
  puts "  -autotune-metric                metric objective {f1, f1:labelname} [#{d['-autotune-metric']}]"
  puts "  -autotune-predictions           number of predictions used for evaluation  [#{d['-autotune-predictions']}]"
  puts "  -autotune-duration              maximum duration in seconds [#{d['-autotune-duration']}]"
  puts "  -autotune-modelsize             constraint model file size [#{d['-autotune-modelsize']}] (empty = do not quantize)"
  puts
  puts 'The following arguments for quantization are optional:'
  puts "  -cutoff             number of words and ngrams to retain [#{d['-cutoff']}]"
  puts "  -retrain            whether embeddings are finetuned if a cutoff is applied [#{d['-retrain']}]"
  puts "  -qnorm              whether the norm is quantized separately [#{d['-qnorm']}]"
  puts "  -qout               whether the classifier is quantized [#{d['-qout']}]"
  puts "  -dsub               size of each sub-vector [#{d['-dsub']}]"
end

def usage_for(cmd)
  case cmd
  when 'test'
    puts "usage: fasttext test <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename (if -, read from stdin)\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n"
  when 'predict', 'predict-prob'
    puts "usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename (if -, read from stdin)\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n"
  when 'print-word-vectors', 'print-sentence-vectors'
    puts "usage: fasttext #{cmd} <model>\n\n  <model>      model filename\n"
  when 'print-ngrams'
    puts "usage: fasttext print-ngrams <model> <word>\n\n  <model>      model filename\n  <word>       word to print\n"
  when 'nn', 'analogies'
    puts "usage: fasttext #{cmd} <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels\n"
  when 'dump'
    puts "usage: fasttext dump <model> <option>\n\n  <model>      model filename\n  <option>     option from args,dict,input,output"
  when 'test-label'
    puts "usage: fasttext test-label <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n"
  else
    main_usage
  end
end

def parse_train(cmd, argv)
  opts = train_defaults(cmd)
  i = 0
  while i < argv.length
    key = argv[i]
    unless TRAIN_KEYS.include?(key)
      train_usage(cmd, "Unknown argument: #{key}")
      exit 1
    end
    if i + 1 >= argv.length || argv[i + 1].start_with?('-')
      train_usage(cmd, "Missing value for argument: #{key}")
      exit 1
    end
    opts[key] = argv[i + 1]
    i += 2
  end
  opts
end

def tokenize(text, label_prefix = '__label__', strip_labels = true)
  text.to_s.split(/\s+/).reject do |tok|
    tok.empty? || (strip_labels && tok.start_with?(label_prefix))
  end
end

def ngrams(tokens, max_n)
  out = []
  max_n = [max_n.to_i, 1].max
  tokens.each_index do |i|
    1.upto(max_n) do |n|
      break if i + n > tokens.length
      out << tokens[i, n].join(' ')
    end
  end
  out
end

def stable_vector(key, dim)
  seed = Zlib.crc32(key.to_s)
  Array.new(dim) do |i|
    v = Math.sin((seed + 1) * (i + 1) * 12.9898) * 43_758.5453
    ((v - v.floor) * 2.0 - 1.0) * 0.1
  end
end

def fmt_float(x)
  s = format('%.6f', x.to_f)
  s.sub(/0+\z/, '').sub(/\.\z/, '.0')
end

def plain_hash(hash)
  hash.each_with_object({}) do |(k, v), out|
    out[k] = v.is_a?(Hash) ? plain_hash(v) : v
  end
end

def save_model(path, model)
  File.binwrite(path, Marshal.dump(model))
end

def load_model(path)
  raise "#{path} cannot be opened for loading!" unless File.file?(path)
  Marshal.load(File.binread(path))
rescue TypeError, ArgumentError
  raise "#{path} has wrong file format!"
end

def read_lines(path)
  path == '-' ? STDIN.each_line.to_a : File.readlines(path, chomp: true)
end

def train_supervised(opts)
  input = opts['-input']
  output = opts['-output']
  if input.empty? || output.empty?
    train_usage('supervised', 'Empty input or output path.')
    exit 1
  end

  prefix = opts['-label']
  max_ngram = opts['-wordNgrams'].to_i
  labels = Hash.new(0)
  label_words = Hash.new { |h, k| h[k] = Hash.new(0) }
  vocabulary = Hash.new(0)
  documents = 0
  File.foreach(input) do |line|
    toks = line.split(/\s+/)
    line_labels = toks.select { |t| t.start_with?(prefix) }
    words = ngrams(toks.reject { |t| t.start_with?(prefix) || t.empty? }, max_ngram)
    next if line_labels.empty?

    documents += 1
    words.each { |w| vocabulary[w] += 1 }
    line_labels.each do |label|
      labels[label] += 1
      words.each { |w| label_words[label][w] += 1 }
    end
  end

  model = {
    'format' => 'ruby-fasttext',
    'type' => 'supervised',
    'args' => opts,
    'labels' => plain_hash(labels),
    'label_words' => plain_hash(label_words),
    'vocabulary' => plain_hash(vocabulary),
    'documents' => documents
  }
  save_model("#{output}.bin", model)
  write_vec("#{output}.vec", vocabulary.keys.sort, opts['-dim'].to_i)
end

def write_vec(path, words, dim)
  File.open(path, 'w') do |f|
    f.puts "#{words.length} #{dim}"
    words.each { |w| f.puts "#{w} #{stable_vector(w, dim).map { |x| fmt_float(x) }.join(' ')}" }
  end
end

def train_unsupervised(cmd, opts)
  input = opts['-input']
  output = opts['-output']
  if input.empty? || output.empty?
    train_usage(cmd, 'Empty input or output path.')
    exit 1
  end
  counts = Hash.new(0)
  File.foreach(input) { |line| tokenize(line, opts['-label'], false).each { |w| counts[w] += 1 } }
  min_count = opts['-minCount'].to_i
  words = counts.select { |_w, c| c >= min_count }.keys.sort
  words = counts.keys.sort if words.empty?
  model = {
    'format' => 'ruby-fasttext',
    'type' => cmd,
    'args' => opts,
    'words' => words,
    'counts' => plain_hash(counts)
  }
  save_model("#{output}.bin", model)
  write_vec("#{output}.vec", words, opts['-dim'].to_i)
end

def score_supervised(model, text)
  args = model['args'] || {}
  labels = model['labels'] || {}
  label_words = model['label_words'] || {}
  vocabulary = model['vocabulary'] || {}
  max_ngram = (args['-wordNgrams'] || '1').to_i
  tokens = ngrams(tokenize(text, args['-label'] || '__label__'), max_ngram)
  total_docs = [labels.values.map(&:to_i).sum, 1].max
  vocab_size = [vocabulary.length, 1].max
  raw = labels.keys.map do |label|
    counts = label_words[label] || {}
    denom = counts.values.map(&:to_i).sum + vocab_size
    logp = Math.log((labels[label].to_f + 1.0) / (total_docs + labels.length))
    tokens.each { |w| logp += Math.log((counts.fetch(w, 0).to_f + 1.0) / denom) }
    [label, logp]
  end
  max = raw.map(&:last).max || 0.0
  exps = raw.map { |label, s| [label, Math.exp(s - max)] }
  sum = exps.map(&:last).sum
  exps.map { |label, e| [label, sum.positive? ? e / sum : 0.0] }.sort_by { |label, p| [-p, label] }
end

def predictions(model, line, k, th)
  if model['type'] == 'supervised'
    score_supervised(model, line).select { |_l, p| p >= th }.first(k)
  else
    words = model['words'] || []
    words.first(k).map { |w| [w, 1.0 / [words.length, 1].max] }
  end
end

def cmd_predict(prob, argv)
  return usage_for(prob ? 'predict-prob' : 'predict') if argv.length < 2

  model = load_model(argv[0])
  k = (argv[2] || '1').to_i
  th = (argv[3] || '0.0').to_f
  read_lines(argv[1]).each do |line|
    preds = predictions(model, line, k, th)
    if prob
      puts preds.map { |l, p| "#{l} #{fmt_float(p)}" }.join(' ')
    else
      puts preds.map(&:first).join(' ')
    end
  end
end

def true_labels(line, prefix)
  line.split(/\s+/).select { |t| t.start_with?(prefix) }
end

def cmd_test(argv)
  return usage_for('test') if argv.length < 2

  model = load_model(argv[0])
  k = (argv[2] || '1').to_i
  th = (argv[3] || '0.0').to_f
  prefix = (model['args'] || {})['-label'] || '__label__'
  n = 0
  pred_count = 0
  gold_count = 0
  good = 0
  read_lines(argv[1]).each do |line|
    gold = true_labels(line, prefix)
    next if gold.empty?

    pred = predictions(model, line, k, th).map(&:first)
    n += 1
    pred_count += pred.length
    gold_count += gold.length
    good += (pred & gold).length
  end
  p_at = pred_count.zero? ? 0.0 : good.to_f / pred_count
  r_at = gold_count.zero? ? 0.0 : good.to_f / gold_count
  puts "N\t#{n}"
  puts "P@#{k}\t#{fmt_float(p_at)}"
  puts "R@#{k}\t#{fmt_float(r_at)}"
end

def cmd_test_label(argv)
  return usage_for('test-label') if argv.length < 2

  model = load_model(argv[0])
  k = (argv[2] || '1').to_i
  th = (argv[3] || '0.0').to_f
  prefix = (model['args'] || {})['-label'] || '__label__'
  stats = Hash.new { |h, label| h[label] = { tp: 0, fp: 0, fn: 0 } }
  read_lines(argv[1]).each do |line|
    gold = true_labels(line, prefix)
    pred = predictions(model, line, k, th).map(&:first)
    (gold | pred).each { |label| stats[label] }
    pred.each { |label| gold.include?(label) ? stats[label][:tp] += 1 : stats[label][:fp] += 1 }
    gold.each { |label| stats[label][:fn] += 1 unless pred.include?(label) }
  end
  stats.keys.sort.each do |label|
    s = stats[label]
    precision = (s[:tp] + s[:fp]).zero? ? 0.0 : s[:tp].to_f / (s[:tp] + s[:fp])
    recall = (s[:tp] + s[:fn]).zero? ? 0.0 : s[:tp].to_f / (s[:tp] + s[:fn])
    f1 = (precision + recall).zero? ? 0.0 : 2.0 * precision * recall / (precision + recall)
    puts format('%s : %s  Precision : %s  Recall : %s   %s',
                'F1-Score', fmt_float(f1), fmt_float(precision), fmt_float(recall), label)
  end
end

def word_vector(model, word)
  dim = ((model['args'] || {})['-dim'] || '100').to_i
  stable_vector(word, dim)
end

def cmd_print_word_vectors(argv)
  return usage_for('print-word-vectors') if argv.empty?

  model = load_model(argv[0])
  STDIN.each_line do |line|
    word = line.strip
    next if word.empty?
    puts "#{word} #{word_vector(model, word).map { |x| fmt_float(x) }.join(' ')}"
  end
end

def cmd_print_sentence_vectors(argv)
  return usage_for('print-sentence-vectors') if argv.empty?

  model = load_model(argv[0])
  dim = ((model['args'] || {})['-dim'] || '100').to_i
  STDIN.each_line do |line|
    words = tokenize(line, '__label__', true)
    vec = Array.new(dim, 0.0)
    words.each do |w|
      word_vector(model, w).each_with_index { |x, i| vec[i] += x }
    end
    vec.map! { |x| words.empty? ? x : x / words.length }
    puts vec.map { |x| fmt_float(x) }.join(' ')
  end
end

def cmd_print_ngrams(argv)
  return usage_for('print-ngrams') if argv.length < 2

  load_model(argv[0])
  word = argv[1]
  puts word
  chars = "<#{word}>".chars
  3.upto([6, chars.length].min) do |n|
    chars.each_cons(n) { |cs| puts cs.join }
  end
end

def cmd_dump(argv)
  return usage_for('dump') if argv.length < 2

  model = load_model(argv[0])
  case argv[1]
  when 'args'
    (model['args'] || {}).sort.each { |k, v| puts "#{k.sub(/^-/, '')} #{v}" }
  when 'dict'
    if model['type'] == 'supervised'
      (model['labels'] || {}).sort.each { |l, c| puts "#{l} #{c} label" }
      (model['vocabulary'] || {}).sort.each { |w, c| puts "#{w} #{c} word" }
    else
      (model['counts'] || {}).sort.each { |w, c| puts "#{w} #{c} word" }
    end
  when 'input', 'output'
    words = model['type'] == 'supervised' ? (model['vocabulary'] || {}).keys : (model['words'] || [])
    words.sort.each { |w| puts "#{w} #{word_vector(model, w).map { |x| fmt_float(x) }.join(' ')}" }
  else
    usage_for('dump')
  end
end

def cmd_quantize(argv)
  opts = parse_train('quantize', argv)
  if opts['-input'].empty? || opts['-output'].empty?
    train_usage('quantize')
    exit 1
  end
  model = load_model(opts['-input'])
  model['quantized'] = true
  model['args'] = (model['args'] || {}).merge(opts)
  save_model("#{opts['-output']}.ftz", model)
end

def interactive_neighbors(model, k)
  words = model['type'] == 'supervised' ? (model['vocabulary'] || {}).keys : (model['words'] || [])
  STDIN.each_line do |line|
    query = line.strip
    next if query.empty?
    puts words.reject { |w| w == query }.first(k).map { |w| "#{w} #{fmt_float(0.0)}" }
  end
end

cmd = ARGV.shift
if cmd.nil? || cmd == '--help' || cmd == '-h' || !COMMANDS.key?(cmd)
  main_usage
  exit(cmd && !%w[--help -h].include?(cmd) ? 1 : 0)
end

begin
  case cmd
  when 'supervised'
    opts = parse_train(cmd, ARGV)
    train_supervised(opts)
  when 'skipgram', 'cbow'
    opts = parse_train(cmd, ARGV)
    train_unsupervised(cmd, opts)
  when 'quantize'
    ARGV.empty? ? usage_for(cmd) : cmd_quantize(ARGV)
  when 'predict'
    cmd_predict(false, ARGV)
  when 'predict-prob'
    cmd_predict(true, ARGV)
  when 'test'
    cmd_test(ARGV)
  when 'test-label'
    cmd_test_label(ARGV)
  when 'print-word-vectors'
    cmd_print_word_vectors(ARGV)
  when 'print-sentence-vectors'
    cmd_print_sentence_vectors(ARGV)
  when 'print-ngrams'
    cmd_print_ngrams(ARGV)
  when 'dump'
    cmd_dump(ARGV)
  when 'nn', 'analogies'
    usage_for(cmd) if ARGV.empty?
    model = load_model(ARGV[0])
    interactive_neighbors(model, (ARGV[1] || '10').to_i) if ARGV[0]
  end
rescue Errno::ENOENT => e
  warn e.message
  exit 1
rescue StandardError => e
  warn e.message
  exit 1
end
