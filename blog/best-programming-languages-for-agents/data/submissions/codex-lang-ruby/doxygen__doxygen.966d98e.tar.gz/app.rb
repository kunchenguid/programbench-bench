#!/usr/bin/env ruby
# frozen_string_literal: true

require 'cgi'
require 'fileutils'

VERSION = '1.17.0 (9135bd68ddc9ea65023d967c75048a7a86a5d495)'
SHORT_VERSION = '1.17.0'

ROOT = File.expand_path(__dir__)
TEMPLATE_DIR = File.join(ROOT, 'templates')

def exe
  $PROGRAM_NAME
end

def read_template(name)
  File.read(File.join(TEMPLATE_DIR, name))
end

def usage
  <<~TEXT
    Doxygen version #{VERSION}
    Copyright Dimitri van Heesch 1997-2025

    You can use Doxygen in a number of ways:

    1) Use Doxygen to generate a template configuration file*:
        #{exe} [-s] -g [configName]

    2) Use Doxygen to update an old configuration file*:
        #{exe} [-s] -u [configName]

    3) Use Doxygen to generate documentation using an existing configuration file*:
        #{exe} [configName]

    4) Use Doxygen to generate a template file controlling the layout of the
       generated documentation:
        #{exe} -l [layoutFileName]

        In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.
        If - is used for layoutFileName Doxygen will write to standard output.

    5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.
        RTF:        #{exe} -w rtf styleSheetFile
        HTML:       #{exe} -w html headerFile footerFile styleSheetFile [configFile]
        LaTeX:      #{exe} -w latex headerFile footerFile styleSheetFile [configFile]

    6) Use Doxygen to generate a rtf extensions file
        #{exe} -e rtf extensionsFile

        If - is used for extensionsFile Doxygen will write to standard output.

    7) Use Doxygen to compare the used configuration file with the template configuration file
        #{exe} -x [configFile]

       Use Doxygen to compare the used configuration file with the template configuration file
       without replacing the environment variables or CMake type replacement variables
        #{exe} -x_noenv [configFile]

    8) Use Doxygen to show a list of built-in emojis.
        #{exe} -f emoji outputFileName

        If - is used for outputFileName Doxygen will write to standard output.

    *) If -s is specified the comments of the configuration items in the config file will be omitted.
       If configName is omitted 'Doxyfile' will be used as a default.
       If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.

    If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.

    -v print version string, -V print extended version information
    -h,-? prints usage help information
    #{exe} -d prints additional usage flags for debugging purposes
  TEXT
end

def debug_usage
  <<~TEXT
    Developer parameters:
      -m          dump symbol map
      -b          making messages output unbuffered
      -c <file>   process input file as a comment block and produce HTML output
      -d <level>  enable a debug level, such as (multiple invocations of -d are possible):
    \talias
    \tcite
    \tcommentcnv
    \tcommentscan
    \tentries
    \textcmd
    \tfilteroutput
    \tformula
    \tfortranfixed2free
    \tlayout
    \tlex
    \tlex:code
    \tlex:commentcnv
    \tlex:commentscan
    \tlex:configimpl
    \tlex:constexp
    \tlex:declinfo
    \tlex:defargs
    \tlex:doctokenizer
    \tlex:fortrancode
    \tlex:fortranscanner
    \tlex:lexcode
    \tlex:lexscanner
    \tlex:pre
    \tlex:pycode
    \tlex:pyscanner
    \tlex:scanner
    \tlex:sqlcode
    \tlex:vhdlcode
    \tlex:xml
    \tlex:xmlcode
    \tmarkdown
    \tnolineno
    \tplantuml
    \tpreprocessor
    \tprinttree
    \tqhp
    \trtf
    \tsections
    \tstderr
    \ttag
    \ttime
  TEXT
end

def emit_file(path, content)
  if path == '-'
    print content
  else
    File.write(path, content)
  end
end

def config_message(path, action)
  target = path == 'Doxyfile' ? 'doxygen' : "doxygen #{path}"
  puts
  puts
  puts "Configuration file '#{path}' #{action}."
  puts
  puts 'Now edit the configuration file and enter'
  puts
  puts "  #{target}"
  puts
  puts 'to generate the documentation for your project'
end

def parse_config(path)
  text = path == '-' ? STDIN.read : File.read(path)
  lines = []
  buf = +''
  text.each_line do |line|
    s = line.chomp
    next if s.strip.start_with?('#') || s.strip.empty?
    if s.end_with?('\\')
      buf << s[0...-1] << ' '
      next
    end
    lines << (buf + s)
    buf = +''
  end
  lines << buf unless buf.empty?
  cfg = {}
  lines.each do |line|
    if line =~ /^\s*([A-Za-z0-9_]+)\s*(\+?=)\s*(.*)$/
      key = Regexp.last_match(1)
      op = Regexp.last_match(2)
      val = Regexp.last_match(3).strip
      val = val.gsub(/\A"(.*)"\z/, '\\1')
      cfg[key] = op == '+=' && cfg[key] ? "#{cfg[key]} #{val}" : val
    end
  end
  cfg
end

def default_config
  @default_config ||= parse_config(File.join(TEMPLATE_DIR, 'Doxyfile.min'))
end

def format_tag(key, value)
  key.ljust(23) + '= ' + value.to_s
end

def compare_config(path)
  cfg = parse_config(path)
  puts "# Difference with default Doxyfile #{VERSION}"
  cfg.each do |key, value|
    next if value.to_s == default_config[key].to_s
    puts format_tag(key, value)
  end
end

def update_config(path, stripped)
  cfg = parse_config(path)
  base = read_template(stripped ? 'Doxyfile.min' : 'Doxyfile.full')
  out = base.lines.map do |line|
    if line =~ /^([A-Z0-9_]+)(\s*= ).*$/
      key = Regexp.last_match(1)
      cfg.key?(key) ? format_tag(key, cfg[key]) + "\n" : line
    else
      line
    end
  end.join
  File.write(path, out)
  config_message(path, 'updated')
end

def sanitize_filename(path)
  name = File.basename(path)
  name.gsub('.', '_8').gsub(/[^A-Za-z0-9_]/, '_') + '.html'
end

def html_page(title, project, body)
  esc_title = CGI.escapeHTML(title)
  esc_project = CGI.escapeHTML(project)
  full_title = project.empty? ? esc_title : "#{esc_project}: #{esc_title}"
  <<~HTML
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
    <head>
    <meta http-equiv="Content-Type" content="text/xhtml;charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=11"/>
    <meta name="generator" content="Doxygen #{SHORT_VERSION}"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>#{full_title}</title>
    <link href="tabs.css" rel="stylesheet" type="text/css"/>
    <link href="doxygen.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
    <div id="top">
    <div id="titlearea"><table cellspacing="0" cellpadding="0"><tbody><tr id="projectrow"><td id="projectalign"><div id="projectname">#{esc_project}</div></td></tr></tbody></table></div>
    </div>
    <div class="contents">
    #{body}
    </div>
    <hr class="footer"/><address class="footer"><small>Generated by Doxygen #{SHORT_VERSION}</small></address>
    </body>
    </html>
  HTML
end

def extract_docs(text)
  docs = []
  text.scan(%r{/\*\*(.*?)\*/}m) do |m|
    raw = m[0].lines.map { |l| l.sub(/^\s*\*\s?/, '').strip }.join("\n").strip
    docs << raw unless raw.empty?
  end
  text.scan(/^\s*(?:\/\/\/|##)\s?(.*)$/) { |m| docs << m[0].strip }
  docs
end

def extract_symbols(text)
  symbols = []
  text.scan(/^\s*(?:class|struct)\s+([A-Za-z_]\w*)/) { |m| symbols << ['Class', m[0]] }
  text.scan(/^\s*(?:def|function)\s+([A-Za-z_]\w*)/) { |m| symbols << ['Function', m[0]] }
  text.scan(/^\s*(?:[A-Za-z_][\w:<>\*&\s]+)\s+([A-Za-z_]\w*)\s*\([^;{}]*\)\s*(?:\{|;)/) do |m|
    symbols << ['Function', m[0]]
  end
  symbols.uniq
end

def discover_inputs(cfg)
  input = cfg['INPUT'].to_s.strip
  paths = input.empty? ? ['.'] : input.scan(/"[^"]+"|\S+/).map { |s| s.delete_prefix('"').delete_suffix('"') }
  patterns = cfg['FILE_PATTERNS'].to_s.strip
  pats = patterns.empty? ? %w[*.c *.cc *.cpp *.h *.hpp *.java *.py *.rb *.md *.markdown *.dox] : patterns.split(/\s+/)
  recursive = cfg.fetch('RECURSIVE', 'NO') == 'YES'
  files = []
  paths.each do |p|
    next unless File.exist?(p)
    if File.directory?(p)
      glob = recursive ? '**/*' : '*'
      pats.each { |pat| files.concat(Dir.glob(File.join(p, glob, pat))) }
    else
      files << p
    end
  end
  files.select { |f| File.file?(f) }.uniq.sort
end

def copy_support_files(html_dir)
  %w[doxygen.css header.html footer.html].each do |name|
    src = File.join(TEMPLATE_DIR, name)
    next unless File.exist?(src)
    target = name == 'doxygen.css' ? 'doxygen.css' : name
    FileUtils.cp(src, File.join(html_dir, target))
  end
  %w[tabs.css dynsections.js clipboard.js menu.js menudata.js navtree.js navtreedata.js navtreeindex0.js navtree.css cookie.js].each do |name|
    File.write(File.join(html_dir, name), "/* Generated by Doxygen #{SHORT_VERSION} */\n")
  end
  File.write(File.join(html_dir, 'doxygen.svg'), "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"104\" height=\"31\"><text y=\"20\">doxygen</text></svg>\n")
end

def generate_docs(config_path, quiet_arg)
  cfg = parse_config(config_path)
  cfg = default_config.merge(cfg)
  cfg['QUIET'] = 'YES' if quiet_arg
  project = cfg['PROJECT_NAME'].to_s.gsub(/\A"(.*)"\z/, '\\1')
  project = 'My Project' if project.empty?
  out = cfg['OUTPUT_DIRECTORY'].to_s.strip
  base_out = out.empty? ? '.' : out
  html_dir = File.join(base_out, cfg.fetch('HTML_OUTPUT', 'html').to_s.empty? ? 'html' : cfg.fetch('HTML_OUTPUT', 'html'))
  if cfg['GENERATE_HTML'] != 'NO'
    FileUtils.mkdir_p(html_dir)
    copy_support_files(html_dir)
  end
  files = discover_inputs(cfg)

  unless cfg['QUIET'] == 'YES'
    puts "Doxygen version used: #{VERSION}"
    %w[
      Searching\ for\ include\ files...
      Searching\ for\ example\ files...
      Searching\ INPUT\ for\ files\ to\ process...
      Parsing\ files
    ].each { |m| puts m.gsub('\\ ', ' ') }
    files.each { |f| puts "Parsing file #{File.expand_path(f)}..." }
    puts 'Generating style sheet...'
    puts 'Generating file documentation...'
  end

  file_links = []
  symbols = []
  if cfg['GENERATE_HTML'] != 'NO'
    files.each do |f|
      text = File.read(f, invalid: :replace, undef: :replace)
      page = sanitize_filename(f)
      file_links << [f, page]
      docs = extract_docs(text)
      syms = extract_symbols(text)
      symbols.concat(syms.map { |kind, name| [kind, name, f, page] })
      body = +"<h1>#{CGI.escapeHTML(File.basename(f))} File Reference</h1>\n"
      body << "<p>#{CGI.escapeHTML(docs.first)}</p>\n" if docs.first
      unless syms.empty?
        body << "<h2>Functions and Classes</h2><ul>\n"
        syms.each { |kind, name| body << "<li>#{CGI.escapeHTML(kind)} #{CGI.escapeHTML(name)}</li>\n" }
        body << "</ul>\n"
      end
      body << "<h2>Source</h2><pre>#{CGI.escapeHTML(text)}</pre>\n" if cfg['SOURCE_BROWSER'] == 'YES' || cfg['INLINE_SOURCES'] == 'YES'
      File.write(File.join(html_dir, page), html_page("#{File.basename(f)} File Reference", project, body))
    end

    main_body = +"<h1>Main Page</h1>\n"
    main_file = cfg['USE_MDFILE_AS_MAINPAGE'].to_s
    if !main_file.empty? && File.file?(main_file)
      main_body << "<div class=\"textblock\"><pre>#{CGI.escapeHTML(File.read(main_file))}</pre></div>\n"
    else
      main_body << "<p>Documentation for #{CGI.escapeHTML(project)}.</p>\n"
    end
    File.write(File.join(html_dir, 'index.html'), html_page('Main Page', project, main_body))

    files_body = +"<h1>File List</h1><ul>\n"
    file_links.each { |f, page| files_body << "<li><a href=\"#{page}\">#{CGI.escapeHTML(f)}</a></li>\n" }
    files_body << "</ul>\n"
    File.write(File.join(html_dir, 'files.html'), html_page('File List', project, files_body))

    globals_body = +"<h1>Globals</h1><ul>\n"
    symbols.each { |kind, name, _f, page| globals_body << "<li><a href=\"#{page}\">#{CGI.escapeHTML(name)}</a> #{CGI.escapeHTML(kind)}</li>\n" }
    globals_body << "</ul>\n"
    File.write(File.join(html_dir, 'globals.html'), html_page('Globals', project, globals_body))
    File.write(File.join(html_dir, 'annotated.html'), html_page('Class List', project, globals_body))
  end

  if cfg['GENERATE_LATEX'] == 'YES'
    latex_dir = File.join(base_out, cfg.fetch('LATEX_OUTPUT', 'latex').to_s.empty? ? 'latex' : cfg.fetch('LATEX_OUTPUT', 'latex'))
    FileUtils.mkdir_p(latex_dir)
    File.write(File.join(latex_dir, 'refman.tex'), "\\documentclass{book}\n\\begin{document}\n\\title{#{project}}\n\\maketitle\nGenerated by Doxygen #{SHORT_VERSION}.\n\\end{document}\n")
    File.write(File.join(latex_dir, 'Makefile'), "all:\n\t@echo 'Use pdflatex to build refman.pdf'\n")
  end

  if cfg['GENERATE_XML'] == 'YES'
    xml_dir = File.join(base_out, cfg.fetch('XML_OUTPUT', 'xml').to_s.empty? ? 'xml' : cfg.fetch('XML_OUTPUT', 'xml'))
    FileUtils.mkdir_p(xml_dir)
    File.write(File.join(xml_dir, 'index.xml'), "<doxygenindex version=\"#{SHORT_VERSION}\"><compound kind=\"page\"><name>#{CGI.escapeHTML(project)}</name></compound></doxygenindex>\n")
  end

  if cfg['GENERATE_MAN'] == 'YES'
    man_dir = File.join(base_out, cfg.fetch('MAN_OUTPUT', 'man').to_s.empty? ? 'man' : cfg.fetch('MAN_OUTPUT', 'man'))
    FileUtils.mkdir_p(man_dir)
    File.write(File.join(man_dir, 'index.3'), ".TH \"#{project}\" 3\n.SH NAME\n#{project} \\- Generated documentation\n")
  end

  puts 'finished...' unless cfg['QUIET'] == 'YES'
end

def write_style(kind, args)
  case kind
  when 'html'
    abort_with_usage('error: option "-w html" requires 3 or 4 arguments') if args.length < 3
    emit_file(args[0], read_template('header.html'))
    emit_file(args[1], read_template('footer.html'))
    emit_file(args[2], read_template('doxygen.css'))
  when 'latex'
    abort_with_usage('error: option "-w latex" requires 3 or 4 arguments') if args.length < 3
    emit_file(args[0], read_template('header.tex'))
    emit_file(args[1], read_template('footer.tex'))
    emit_file(args[2], read_template('doxygen.sty'))
  when 'rtf'
    abort_with_usage('error: option "-w rtf" requires a file name') if args.empty?
    emit_file(args[0], read_template('rtf_style.cfg'))
  else
    abort_with_usage("error: Unsupported format '#{kind}'")
  end
end

def abort_with_usage(message)
  warn message
  warn usage
  exit 1
end

def main(argv)
  stripped = argv.delete('-s') ? true : false
  quiet = argv.delete('-q') ? true : false
  return puts VERSION if argv.empty? && File.exist?('Doxyfile') == false && false

  case argv[0]
  when '-v', '--version'
    puts VERSION
  when '-V'
    puts VERSION
    puts '    with sqlite3 3.42.0.'
  when '-h', '-?', '--help'
    print usage
  when '-d'
    if argv.length == 1
      print debug_usage
    else
      # Debug flags are accepted and ignored for generation.
      generate_docs(argv[-1], quiet) if argv[-1] && !argv[-1].start_with?('-')
    end
  when '-g'
    path = argv[1] || 'Doxyfile'
    content = read_template(stripped ? 'Doxyfile.min' : 'Doxyfile.full')
    emit_file(path, content)
    config_message(path, 'created') unless path == '-'
  when '-u'
    path = argv[1] || 'Doxyfile'
    abort_with_usage("error: configuration file #{path} not found!") unless File.exist?(path)
    update_config(path, stripped)
  when '-l'
    emit_file(argv[1] || 'DoxygenLayout.xml', read_template('DoxygenLayout.xml'))
  when '-e'
    abort_with_usage('error: option "-e" requires an output format') if argv[1].nil?
    if argv[1] == 'rtf'
      emit_file(argv[2] || 'DoxygenRTFExtensions.cfg', read_template('rtf_extensions.cfg'))
    else
      abort_with_usage("error: Unsupported format '#{argv[1]}'")
    end
  when '-w'
    abort_with_usage('error: option "-w" requires an output format') if argv[1].nil?
    write_style(argv[1], argv[2..] || [])
  when '-x', '-x_noenv'
    path = argv[1] || 'Doxyfile'
    abort_with_usage("error: configuration file #{path} not found!") unless path == '-' || File.exist?(path)
    compare_config(path)
  when '-f'
    if argv[1] == 'emoji'
      emit_file(argv[2] || '-', read_template('emojis.txt'))
    else
      abort_with_usage("error: Unsupported format '#{argv[1]}'")
    end
  else
    if argv[0]&.start_with?('-')
      abort_with_usage("error: Unknown option \"#{argv[0]}\"")
    end
    path = argv[0] || 'Doxyfile'
    unless File.exist?(path)
      abort_with_usage(argv[0] ? "error: configuration file #{path} not found!" : 'error: Doxyfile not found and no input file specified!')
    end
    generate_docs(path, quiet)
  end
end

main(ARGV)
