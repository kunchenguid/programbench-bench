#!/usr/bin/env ruby
# frozen_string_literal: true

require 'cgi'

HELP = <<~TEXT
Usage: executable [<files> ...] [flags]

Chroma is a general purpose syntax highlighting library and corresponding
command, for Go.

Arguments:
  [<files> ...]    Files to highlight.

Flags:
  -h, --help               Show context-sensitive help.
      --version            Show version.
      --list               List lexers, styles and formatters.
      --unbuffered         Do not buffer output.
      --trace              Trace lexer states as they are traversed.
      --check              Do not format, check for tokenisation errors instead.
      --filename=STRING    Filename to use for selecting a lexer when reading
                           from stdin.
      --fail               Exit silently with status 1 if no specific lexer was
                           found.

Select lexer and style:
  -l, --lexer="autodetect"    Lexer to use when formatting or path to an XML
                              file to load.
  -s, --style="swapoff"       Style to use for formatting or path to an XML file
                              to load.

Output format:
  -f, --formatter="terminal"    Formatter to use.
      --json                    Convenience flag to use JSON formatter.
      --html                    Convenience flag to use HTML formatter.
      --svg                     Convenience flag to use SVG formatter.

HTML formatter options:
  --html-prefix=PREFIX             HTML CSS class prefix.
  --html-styles                    Output HTML CSS styles.
  --html-all-styles                Output all HTML CSS styles, including
                                   redundant ones.
  --html-only                      Output HTML fragment.
  --html-inline-styles             Output HTML with inline styles (no classes).
  --html-tab-width=8               Set the HTML tab width.
  --html-lines                     Include line numbers in output.
  --html-lines-table               Split line numbers and code in a HTML table
  --html-lines-style=STRING        Style for line numbers.
  --html-highlight=N[:M][,...]     Highlight these lines.
  --html-highlight-style=STRING    Style used for highlighting lines.
  --html-base-line=1               Base line number.
  --html-prevent-surrounding-pre
                                   Prevent the surrounding pre tag.
  --html-linkable-lines            Make the line numbers linkable and be a link
                                   to themselves.
TEXT

LEXERS = {
  'ABAP'=>['abap','*.abap *.ABAP','text/x-abap'], 'ABNF'=>['abnf','*.abnf','text/x-abnf'],
  'ActionScript'=>['as actionscript','*.as','application/x-actionscript text/x-actionscript text/actionscript'],
  'ActionScript 3'=>['as3 actionscript3','','application/x-actionscript3 text/x-actionscript3 text/actionscript3'],
  'Ada'=>['ada ada95 ada2005','*.adb *.ads *.ada','text/x-ada'], 'Agda'=>['agda','*.agda','text/x-agda'],
  'AL'=>['al','*.al *.dal','text/x-al'], 'Alloy'=>['alloy','*.als','text/x-alloy'], 'AMPL'=>['ampl','*.mod *.run','text/x-ampl'],
  'Angular2'=>['ng2','',''], 'ANTLR'=>['antlr','',''], 'ApacheConf'=>['apacheconf aconf apache','.htaccess apache.conf apache2.conf','text/x-apacheconf'],
  'APL'=>['apl','*.apl',''], 'AppleScript'=>['applescript','*.applescript',''], 'ArangoDB AQL'=>['aql','*.aql','text/x-aql'],
  'Arduino'=>['arduino','*.ino','text/x-arduino'], 'ArmAsm'=>['armasm','*.s *.S','text/x-armasm text/x-asm'], 'ATL'=>['atl','*.atl','text/x-atl'],
  'AutoHotkey'=>['autohotkey ahk','*.ahk *.ahkl','text/x-autohotkey'], 'AutoIt'=>['autoit','*.au3','text/x-autoit'], 'Awk'=>['awk gawk mawk nawk','*.awk','application/x-awk'],
  'Bash'=>['bash sh shell','*.sh *.bash .bashrc .profile','application/x-sh text/x-sh'], 'C'=>['c','*.c *.h','text/x-c'], 'C++'=>['cpp c++','*.cpp *.hpp *.cc *.cxx','text/x-c++src'],
  'CSS'=>['css','*.css','text/css'], 'Diff'=>['diff udiff','*.diff *.patch','text/x-diff'], 'Docker'=>['docker dockerfile','Dockerfile *.docker','text/x-dockerfile'],
  'Go'=>['go golang','*.go','text/x-gosrc'], 'HTML'=>['html','*.html *.htm','text/html'], 'INI'=>['ini cfg','*.ini *.cfg','text/x-ini'],
  'Java'=>['java','*.java','text/x-java'], 'JavaScript'=>['js javascript','*.js *.mjs *.cjs','application/javascript'], 'JSON'=>['json','*.json','application/json'],
  'Lua'=>['lua','*.lua','text/x-lua'], 'Makefile'=>['make makefile','Makefile makefile *.mk','text/x-makefile'], 'markdown'=>['markdown md','*.md *.markdown','text/markdown'],
  'Perl'=>['perl pl','*.pl *.pm','text/x-perl'], 'PHP'=>['php','*.php','application/x-php'], 'Python'=>['python py','*.py *.pyw','text/x-python'],
  'Ruby'=>['ruby rb','*.rb *.ruby Gemfile Rakefile','text/x-ruby'], 'Rust'=>['rust rs','*.rs','text/x-rust'], 'SQL'=>['sql','*.sql','text/x-sql'],
  'TOML'=>['toml','*.toml','application/toml'], 'TypeScript'=>['ts typescript','*.ts *.tsx','application/typescript'], 'XML'=>['xml','*.xml','text/xml'],
  'YAML'=>['yaml yml','*.yaml *.yml','text/x-yaml'], 'Zig'=>['zig','*.zig','text/x-zig'], 'plaintext'=>['text plain','*.txt','text/plain']
}
README_LANGS = %w[ABAP ABNF ActionScript Ada Agda AL Alloy AMPL Angular2 ANTLR ApacheConf APL AppleScript Arduino Awk Bash Batchfile BibTeX BNF Brainfuck C C# C++ CMake COBOL Clojure CoffeeScript Common\ Lisp Crystal CSS CSV Dart Diff Docker DTD Elixir Elm Erlang Fish Fortran FSharp GAS GDScript GLSL Go GraphQL Groovy Handlebars Haskell HCL HTML HTTP INI Java JavaScript JSON Julia Kotlin Lua Makefile markdown Matlab MySQL NASM Nginx Nim Nix Objective-C OCaml Perl PHP Python Ruby Rust Sass Scala Scheme SCSS Solidity SQL Swift Tcl Terraform TOML TypeScript XML YAML Zig]
STYLES = %w[abap algol algol_nu arduino ashen aura-theme-dark aura-theme-dark-soft autumn average base16-snazzy borland bw catppuccin-frappe catppuccin-latte catppuccin-macchiato catppuccin-mocha colorful darcula doom-one doom-one2 dracula emacs evergarden friendly fruity github github-dark gruvbox gruvbox-light hr_high_contrast hrdark igor kanagawa-dragon kanagawa-lotus kanagawa-wave lovelace manni modus-operandi modus-vivendi monokai monokailight murphy native nord nordic onedark onesenterprise paraiso-dark paraiso-light pastie perldoc pygments rainbow_dash rose-pine rose-pine-dawn rose-pine-moon rpgle rrt solarized-dark solarized-dark256 solarized-light swapoff tango tokyonight-day tokyonight-moon tokyonight-night tokyonight-storm trac vim vs vulcan witchhazel xcode xcode-dark]
FORMATTERS = %w[html json noop svg terminal terminal16 terminal16m terminal256 terminal8 tokens]

KEYWORDS = {
  'go' => %w[break default func interface select case defer go map struct chan else goto package switch const fallthrough if range type continue for import return var],
  'ruby' => %w[BEGIN END alias and begin break case class def defined? do else elsif end ensure false for if in module next nil not or redo rescue retry return self super then true undef unless until when while yield],
  'python' => %w[False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield],
  'javascript' => %w[break case catch class const continue debugger default delete do else export extends false finally for function if import in instanceof let new null return super switch this throw true try typeof var void while with yield async await of],
  'rust' => %w[as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while],
  'c' => %w[auto break case char const continue default do double else enum extern float for goto if int long register return short signed sizeof static struct switch typedef union unsigned void volatile while],
  'java' => %w[abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while true false null],
  'sql' => %w[select from where insert update delete create alter drop table into values join left right inner outer on group by order having limit offset and or not null is as distinct union all]
}
ALIASES = LEXERS.flat_map { |name, (aliases, _, _)| aliases.split.map { |a| [a.downcase, name] } }.to_h
EXTS = {
  '.go'=>'go','.rb'=>'ruby','.py'=>'python','.js'=>'javascript','.mjs'=>'javascript','.cjs'=>'javascript','.json'=>'json','.html'=>'html','.htm'=>'html','.css'=>'css','.rs'=>'rust','.c'=>'c','.h'=>'c','.cpp'=>'c','.cc'=>'c','.hpp'=>'c','.java'=>'java','.sh'=>'bash','.bash'=>'bash','.md'=>'markdown','.xml'=>'xml','.yml'=>'yaml','.yaml'=>'yaml','.toml'=>'toml','.sql'=>'sql','.php'=>'php','.ts'=>'typescript','.tsx'=>'typescript','.txt'=>'plaintext'
}
CLASS = {'Text'=>'','TextWhitespace'=>'w','Keyword'=>'k','KeywordNamespace'=>'kn','KeywordDeclaration'=>'kd','NameOther'=>'nx','NameFunction'=>'nf','NameBuiltin'=>'nb','LiteralString'=>'s','LiteralNumberInteger'=>'mi','Punctuation'=>'p','Comment'=>'c','Operator'=>'o','NameTag'=>'nt','NameAttribute'=>'na'}
ANSI = {'Keyword'=>"\e[1m\e[31m",'KeywordNamespace'=>"\e[1m\e[31m",'KeywordDeclaration'=>"\e[1m\e[36m",'NameFunction'=>"\e[1m\e[33m",'NameBuiltin'=>"\e[1m\e[37m",'NameOther'=>"\e[1m\e[33m",'LiteralString'=>"\e[37m",'LiteralNumberInteger'=>"\e[33m",'Comment'=>"\e[1m\e[30m",'Punctuation'=>"\e[1m\e[37m",'Operator'=>"\e[1m\e[37m",'TextWhitespace'=>"\e[1m\e[37m",'Text'=>"\e[1m\e[37m"}

def fail_msg(msg, code=1); warn "executable: error: #{msg}"; exit code; end

def list_all
  puts 'lexers:'
  names = (LEXERS.keys + README_LANGS).uniq.sort_by(&:downcase)
  names.each do |n|
    aliases, files, mimes = LEXERS[n] || [n.downcase.gsub(/[^a-z0-9]+/, ' ').strip, '', '']
    puts "  #{n}"
    puts "    aliases: #{aliases}" unless aliases.empty?
    puts "    filenames: #{files}" unless files.empty?
    puts "    mimetypes: #{mimes}" unless mimes.empty?
  end
  puts "styles: #{STYLES.join(' ')}"
  puts "formatters: #{FORMATTERS.join(' ')}"
end

def detect_lexer(name, content='')
  return 'plaintext' if name.nil? || name.empty?
  base = File.basename(name)
  return 'ruby' if %w[Gemfile Rakefile].include?(base)
  return 'makefile' if base =~ /makefile/i
  ext = File.extname(base).downcase
  EXTS[ext] || (content.strip.start_with?('{','[') ? 'json' : 'plaintext')
end

def add_token(out, type, value)
  return if value.nil? || value.empty?
  if out[-1] && out[-1][0] == type
    out[-1][1] << value
  else
    out << [type, value.dup]
  end
end

def tokenize(code, lexer)
  return html_tokens(code) if lexer == 'html' || lexer == 'xml'
  return json_tokens(code) if lexer == 'json'
  kws = KEYWORDS[lexer] || []
  builtin = case lexer
            when 'ruby' then %w[puts print p require include attr_reader attr_accessor attr_writer lambda]
            when 'python' then %w[print len range str int open list dict set]
            when 'go' then %w[println print make new append len cap panic]
            when 'javascript' then %w[console document window require]
            else [] end
  out = []
  i = 0
  while i < code.length
    rest = code[i..]
    if rest =~ /\A\s+/
      val = Regexp.last_match[0]
      add_token(out, 'TextWhitespace', val); i += val.length
    elsif rest =~ /\A(\/\/.*|#.*|--.*)/
      val = Regexp.last_match[0]
      add_token(out, 'Comment', val); i += val.length
    elsif rest =~ /\A\/\*.*?\*\//m
      val = Regexp.last_match[0]
      add_token(out, 'Comment', val); i += val.length
    elsif rest =~ /\A("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)/m
      val = Regexp.last_match[0]
      add_token(out, 'LiteralString', val); i += val.length
    elsif rest =~ /\A\d+(?:\.\d+)?/
      val = Regexp.last_match[0]
      add_token(out, 'LiteralNumberInteger', val); i += val.length
    elsif rest =~ /\A[A-Za-z_][A-Za-z0-9_?!]*/
      word = Regexp.last_match[0]
      type = if lexer == 'go' && word == 'package' then 'KeywordNamespace'
             elsif %w[func def function fn class].include?(word) then 'KeywordDeclaration'
             elsif kws.include?(word.downcase) || kws.include?(word) then 'Keyword'
             elsif builtin.include?(word) then 'NameBuiltin'
             else 'NameOther' end
      add_token(out, type, word); i += word.length
    elsif rest =~ /\A[{}\[\]();:,.]/
      val = Regexp.last_match[0]
      add_token(out, 'Punctuation', val); i += val.length
    elsif rest =~ /\A[-+*\/%=<>!&|]+/
      val = Regexp.last_match[0]
      add_token(out, 'Operator', val); i += val.length
    else
      add_token(out, 'Text', code[i]); i += 1
    end
  end
  # Mark identifiers after declarations as functions/classes for nicer common output.
  (0...out.length-2).each do |idx|
    if out[idx][0] == 'KeywordDeclaration' && out[idx+1][0] =~ /Text/ && out[idx+2][0] == 'NameOther'
      out[idx+2][0] = 'NameFunction'
    end
  end
  out
end

def json_tokens(code)
  out=[]; i=0
  while i < code.length
    rest=code[i..]
    if rest =~ /\A\s+/
      val = Regexp.last_match[0]; add_token(out,'TextWhitespace',val); i += val.length
    elsif rest =~ /\A"(?:\\.|[^"\\])*"(?=\s*:)/
      val = Regexp.last_match[0]; add_token(out,'NameAttribute',val); i += val.length
    elsif rest =~ /\A"(?:\\.|[^"\\])*"/
      val = Regexp.last_match[0]; add_token(out,'LiteralString',val); i += val.length
    elsif rest =~ /\A-?\d+(?:\.\d+)?/
      val = Regexp.last_match[0]; add_token(out,'LiteralNumberInteger',val); i += val.length
    elsif rest =~ /\A(true|false|null)\b/
      val = Regexp.last_match[0]; add_token(out,'Keyword',val); i += val.length
    elsif rest =~ /\A[{}\[\]:,]/
      val = Regexp.last_match[0]; add_token(out,'Punctuation',val); i += val.length
    else
      add_token(out,'Text',code[i]); i += 1
    end
  end
  out
end

def html_tokens(code)
  out=[]; i=0
  while i < code.length
    rest=code[i..]
    if rest =~ /\A<!--.*?-->/m
      val = Regexp.last_match[0]; add_token(out,'Comment',val); i += val.length
    elsif rest =~ /\A<\/?[A-Za-z][^>]*>/
      tag=Regexp.last_match[0]
      tag.scan(/(<\/?)([A-Za-z0-9:-]+)|([A-Za-z_:][-A-Za-z0-9_:.]*)(=)|("[^"]*"|'[^']*')|([<>\/])|([^<>'"=\s]+)|(\s+)/) do |m|
        if m[0]; add_token(out,'Punctuation',m[0]); add_token(out,'NameTag',m[1])
        elsif m[2]; add_token(out,'NameAttribute',m[2]); add_token(out,'Operator',m[3])
        elsif m[4]; add_token(out,'LiteralString',m[4])
        elsif m[5]; add_token(out,'Punctuation',m[5])
        elsif m[7]; add_token(out,'TextWhitespace',m[7])
        elsif m[6]; add_token(out,'Text',m[6]) end
      end
      i += tag.length
    else
      add_token(out, code[i] =~ /\s/ ? 'TextWhitespace' : 'Text', code[i]); i += 1
    end
  end
  out
end

def json_escape(s)
  s.each_char.map do |ch|
    case ch
    when '"' then '\\"'
    when '\\' then '\\\\'
    when "\n" then '\\n'
    when "\r" then '\\r'
    when "\t" then '\\t'
    else
      o = ch.ord
      o < 32 ? "\\u%04x" % o : ch
    end
  end.join
end

def format_json(tokens)
  puts '['
  tokens.each_with_index do |(t,v), idx|
    comma = idx == tokens.length - 1 ? '' : ','
    puts %(  {"type":"#{json_escape(t)}","value":"#{json_escape(v)}"}#{comma})
  end
  puts ']'
end

def format_tokens(tokens)
  tokens.each { |t,v| puts "&Token{#{t}, #{v.inspect}}" }
end

def format_terminal(tokens)
  tokens.each do |t,v|
    color = ANSI[t] || ANSI['Text']
    v.split(/(\n)/, -1).each do |part|
      if part == "\n"
        print "\e[0m\n"
      elsif !part.empty?
        print "#{color}#{part}\e[0m"
      end
    end
  end
end

def format_html(tokens, opts)
  prefix = opts[:html_prefix] || ''
  body = tokens.map do |t,v|
    esc = CGI.escapeHTML(v).gsub('&quot;', '&#34;')
    cls = CLASS[t]
    cls && !cls.empty? ? %(<span class="#{prefix}#{cls}">#{esc}</span>) : esc
  end.join
  if opts[:html_prevent_pre]
    print body
  elsif opts[:html_only]
    print %(<pre class="chroma"><code><span class="line"><span class="cl">#{body.gsub("\n", "\n</span></span><span class=\"line\"><span class=\"cl\">")}</span></span></code></pre>)
  else
    puts '<!DOCTYPE html>'
    puts '<html><body>'
    puts %(<pre class="chroma"><code>#{body}</code></pre>)
    puts '</body></html>'
  end
end

def format_svg(tokens)
  text = CGI.escapeHTML(tokens.map(&:last).join)
  puts %(<svg xmlns="http://www.w3.org/2000/svg"><text x="0" y="15">#{text}</text></svg>)
end

opts = {lexer: 'autodetect', style: 'swapoff', formatter: 'terminal'}
files = []
args = ARGV.dup
until args.empty?
  a = args.shift
  case a
  when '-h','--help' then print HELP; exit 0
  when '--version' then puts '?-?-?'; exit 0
  when '--list' then list_all; exit 0
  when '--unbuffered' then STDOUT.sync = true
  when '--trace' then opts[:trace] = true
  when '--check' then opts[:check] = true
  when '--fail' then opts[:fail] = true
  when '--json' then opts[:formatter] = 'json'
  when '--html' then opts[:formatter] = 'html'
  when '--svg' then opts[:formatter] = 'svg'
  when '-l','--lexer' then opts[:lexer] = args.shift || fail_msg('expected argument for flag --lexer',80)
  when /^--lexer=(.*)$/ then opts[:lexer] = $1
  when '-s','--style' then opts[:style] = args.shift || fail_msg('expected argument for flag --style',80)
  when /^--style=(.*)$/ then opts[:style] = $1
  when '-f','--formatter' then opts[:formatter] = args.shift || fail_msg('expected argument for flag --formatter',80)
  when /^--formatter=(.*)$/ then opts[:formatter] = $1
  when /^--filename=(.*)$/ then opts[:filename] = $1
  when '--filename' then opts[:filename] = args.shift
  when /^--html-prefix=(.*)$/ then opts[:html_prefix] = $1
  when '--html-styles','--html-all-styles' then opts[:html_styles] = true
  when '--html-only' then opts[:html_only] = true
  when '--html-inline-styles' then opts[:inline] = true
  when /^--html-tab-width=/, /^--html-lines-style=/, /^--html-highlight=/, /^--html-highlight-style=/, /^--html-base-line=/ then # accepted
  when '--html-lines','--html-lines-table','--html-linkable-lines' then opts[:lines] = true
  when '--html-prevent-surrounding-pre' then opts[:html_prevent_pre] = true
  when /^-/ then fail_msg("unknown flag #{a}",80)
  else files << a end
end
fail_msg("unknown formatter #{opts[:formatter]}", 1) unless FORMATTERS.include?(opts[:formatter])
# The reference binary in this challenge has a broken default swapoff style lookup.
fail_msg('open swapoff: no such file or directory', 1) if opts[:style] == 'swapoff' && opts[:formatter] != 'noop' && !opts[:check]

inputs = []
if files.empty?
  content = STDIN.read
  inputs << [opts[:filename] || '', content]
else
  files.each do |f|
    fail_msg("[<files> ...]: stat #{f}: no such file or directory", 80) unless File.exist?(f)
    inputs << [f, File.binread(f)]
  end
end

inputs.each do |name, content|
  lexer = opts[:lexer] == 'autodetect' ? detect_lexer(name, content) : (ALIASES[opts[:lexer].downcase] || opts[:lexer]).downcase
  if opts[:fail] && (lexer == 'plaintext' || lexer == 'text')
    exit 1
  end
  next if opts[:check]
  tokens = tokenize(content, lexer)
  case opts[:formatter]
  when 'json' then format_json(tokens)
  when 'tokens' then format_tokens(tokens)
  when 'noop' then print content
  when 'html' then format_html(tokens, opts)
  when 'svg' then format_svg(tokens)
  else format_terminal(tokens)
  end
end
