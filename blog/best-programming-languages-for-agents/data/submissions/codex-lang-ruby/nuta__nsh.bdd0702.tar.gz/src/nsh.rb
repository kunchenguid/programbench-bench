#!/usr/bin/env ruby
# frozen_string_literal: true

require "fileutils"
require "open3"

HELP = <<~HELP
  nsh 0.4.2
  A command-line shell that focuses on performance and productivity.

  USAGE:
      executable [FLAGS] [OPTIONS] [FILE]

  FLAGS:
      -h, --help       Prints help information
      -l, --login      Behave like a login shell
          --norc       Don't load nshrc
          --version    Print the version

  OPTIONS:
      -c <command>        The command to be executed

  ARGS:
      <FILE>    The file to be executed
HELP

VERSION = "0.4.2"

def usage_for(context)
  context == :command ? "executable -c <command>" : "executable [FLAGS] [OPTIONS] [FILE]"
end

def clap_error(message, context = :default)
  warn "error: #{message}"
  warn
  warn "USAGE:"
  warn "    #{usage_for(context)}"
  warn
  warn "For more information try --help"
  exit 1
end

def parse_args(argv)
  opts = { command: nil, file: nil, norc: false, login: false }
  positional = []
  i = 0

  while i < argv.length
    arg = argv[i]
    case arg
    when "-h", "--help"
      puts HELP
      exit 0
    when "--version"
      puts VERSION
      exit 0
    when "-l", "--login"
      opts[:login] = true
    when "--norc"
      opts[:norc] = true
    when "-c"
      if i + 1 >= argv.length || argv[i + 1].start_with?("-")
        clap_error("The argument '-c <command>' requires a value but none was supplied", :command)
      end
      opts[:command] = argv[i + 1]
      i += 1
    when "--"
      positional.concat(argv[(i + 1)..] || [])
      break
    else
      if arg.start_with?("-")
        clap_error("Found argument '#{arg}' which wasn't expected, or isn't valid in this context")
      end
      positional << arg
    end
    i += 1
  end

  if opts[:command]
    clap_error("Found argument '#{positional[1]}' which wasn't expected, or isn't valid in this context", :command) if positional.length > 1
  else
    clap_error("Found argument '#{positional[1]}' which wasn't expected, or isn't valid in this context") if positional.length > 1
    opts[:file] = positional[0]
  end

  opts
end

def rc_paths
  home = ENV["HOME"] || Dir.home
  xdg = ENV["XDG_CONFIG_HOME"]
  paths = []
  paths << File.join(home, ".nshrc") if home && !home.empty?
  paths << if xdg && !xdg.empty?
             File.join(xdg, "nsh", "nshrc")
           elsif home && !home.empty?
             File.join(home, ".config", "nsh", "nshrc")
           end
  paths.compact.uniq
end

def bash_prelude(norc)
  parts = []
  parts << "shopt -s expand_aliases"
  parts << "command_not_found_handle() { printf 'nsh: command not found `%s'\\''\\n' \"$1\" >&2; return 1; }"
  unless norc
    rc_paths.each do |path|
      parts << ". #{Shellwords.escape(path)}" if File.file?(path)
    end
  end
  parts.join("\n")
end

def append_history(command)
  home = ENV["HOME"] || Dir.home
  return if home.nil? || home.empty? || command.nil? || command.empty?

  File.open(File.join(home, ".nsh_history"), "a") do |f|
    f.puts [Time.now.to_i, Dir.pwd, command].join("\t")
  end
rescue StandardError
  nil
end

def run_bash(script, argv0 = "executable")
  append_history(script.lines.last&.chomp)
  exec(["/bin/bash", argv0], "-c", script)
end

def main
  opts = parse_args(ARGV)

  if opts[:command]
    run_bash("#{bash_prelude(opts[:norc])}\n#{opts[:command]}")
  elsif opts[:file]
    begin
      body = File.read(opts[:file])
    rescue SystemCallError => e
      warn "nsh: panicked at src/main.rs:114:34:"
      warn "failed to open the file: #{e.message}"
      exit 101
    end
    run_bash("#{bash_prelude(opts[:norc])}\n#{body}", opts[:file])
  elsif $stdout.tty? && $stdin.tty?
    prelude = bash_prelude(opts[:norc])
    ENV["BASH_ENV"] = nil
    exec(["/bin/bash", "executable"], opts[:login] ? "-l" : "-i", "-c", "#{prelude}\nexec /bin/bash -i")
  else
    warn "nsh: warning: stdout is not a tty"
    exit 0
  end
end

require "shellwords"
main
