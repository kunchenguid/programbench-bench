#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'shellwords'

VERSION = '0.9.9'
APP = 'zoxide'
COMMANDS = %w[add edit import init query remove].freeze
SHELLS = %w[bash elvish fish nushell posix powershell tcsh xonsh zsh].freeze
HOOKS = %w[none prompt pwd].freeze

Entry = Struct.new(:path, :rank, :time)

def env_lines
  <<~TXT.chomp
    Environment variables:
      _ZO_DATA_DIR          Path for zoxide data files
      _ZO_ECHO              Print the matched directory before navigating to it when set to 1
      _ZO_EXCLUDE_DIRS      List of directory globs to be excluded
      _ZO_FZF_OPTS          Custom flags to pass to fzf
      _ZO_MAXAGE            Maximum total age after which entries start getting deleted
      _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths
  TXT
end

def main_help
  <<~TXT
    zoxide #{VERSION}
    Ajeet D'Souza <98ajeet@gmail.com>
    https://github.com/ajeetdsouza/zoxide

    A smarter cd command for your terminal

    Usage:
      executable <COMMAND>

    Commands:
      add     Add a new directory or increment its rank
      edit    Edit the database
      import  Import entries from another application
      init    Generate shell configuration
      query   Search for a directory in the database
      remove  Remove a directory from the database

    Options:
      -h, --help     Print help
      -V, --version  Print version

    #{env_lines}
  TXT
end

def sub_help(cmd)
  case cmd
  when 'add'
    body = "Add a new directory or increment its rank\n\nUsage:\n  executable add [OPTIONS] <PATHS>...\n\nArguments:\n  <PATHS>...  \n\nOptions:\n  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't\n  -h, --help           Print help\n  -V, --version        Print version"
  when 'edit'
    body = "Edit the database\n\nUsage:\n  executable edit\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version"
  when 'import'
    body = "Import entries from another application\n\nUsage:\n  executable import [OPTIONS] --from <FROM> <PATH>\n\nArguments:\n  <PATH>  \n\nOptions:\n      --from <FROM>  Application to import from [possible values: autojump, z]\n      --merge        Merge into existing database\n  -h, --help         Print help\n  -V, --version      Print version"
  when 'init'
    body = "Generate shell configuration\n\nUsage:\n  executable init [OPTIONS] <SHELL>\n\nArguments:\n  <SHELL>  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nOptions:\n      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands\n      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]\n      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]\n  -h, --help         Print help\n  -V, --version      Print version"
  when 'query'
    body = "Search for a directory in the database\n\nUsage:\n  executable query [OPTIONS] [KEYWORDS]...\n\nArguments:\n  [KEYWORDS]...  \n\nOptions:\n  -a, --all              Show unavailable directories\n  -i, --interactive      Use interactive selection\n  -l, --list             List all matching directories\n  -s, --score            Print score with results\n      --exclude <path>   Exclude the current directory\n      --base-dir <path>  Only search within this directory\n  -h, --help             Print help\n  -V, --version          Print version"
  when 'remove'
    body = "Remove a directory from the database\n\nUsage:\n  executable remove [PATHS]...\n\nArguments:\n  [PATHS]...  \n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version"
  end
  "zoxide-#{cmd} #{VERSION}\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\n#{body}\n\n#{env_lines}\n"
end

def die(msg, code = 1)
  warn "zoxide: #{msg}"
  exit code
end

def clap_error(msg)
  warn "error: #{msg}"
  warn
  warn "For more information, try '--help'."
  exit 2
end

def data_dir
  return ENV['_ZO_DATA_DIR'] unless ENV['_ZO_DATA_DIR'].to_s.empty?
  home = ENV['HOME'] || Dir.home rescue '.'
  File.join(ENV['XDG_DATA_HOME'].to_s.empty? ? File.join(home, '.local', 'share') : ENV['XDG_DATA_HOME'], 'zoxide')
end

def db_path
  File.join(data_dir, 'db.zo')
end

def read_u64(s, off)
  [s.byteslice(off, 8).ljust(8, "\0")].pack('a*').unpack1('Q<')
end

def read_db
  path = db_path
  return [] unless File.file?(path)
  s = File.binread(path)
  return [] if s.bytesize < 12
  off = 0
  version = s.byteslice(off, 4).unpack1('L<'); off += 4
  return [] unless version == 3
  count = read_u64(s, off); off += 8
  entries = []
  count.times do
    break if off + 8 > s.bytesize
    len = read_u64(s, off); off += 8
    p = s.byteslice(off, len).to_s; off += len
    rank = s.byteslice(off, 8).unpack1('E') || 0.0; off += 8
    time = read_u64(s, off); off += 8
    entries << Entry.new(p, rank, time)
  end
  entries
rescue
  []
end

def write_db(entries)
  dir = data_dir
  FileUtils.mkdir_p(dir)
  body = [3, entries.length].pack('L<Q<')
  entries.each do |e|
    p = e.path.b
    body << [p.bytesize].pack('Q<') << p << [e.rank.to_f].pack('E') << [e.time.to_i].pack('Q<')
  end
  tmp = File.join(dir, "tmp_#{$$}_#{rand(1_000_000)}")
  File.binwrite(tmp, body)
  File.rename(tmp, db_path)
rescue => e
  die("could not write to database\n\nCaused by:\n    #{e.message}")
end

def canonical(path)
  p = File.expand_path(path)
  p = File.realpath(p) if ENV['_ZO_RESOLVE_SYMLINKS'] == '1'
  p
end

def excluded?(path)
  specs = ENV['_ZO_EXCLUDE_DIRS']
  specs = ENV['HOME'].to_s if specs.nil?
  specs.to_s.split(':').any? { |g| !g.empty? && File.fnmatch?(File.expand_path(g), path, File::FNM_PATHNAME | File::FNM_EXTGLOB) }
end

def age(entries)
  maxage = (ENV['_ZO_MAXAGE'] || '10000').to_f
  total = entries.sum(&:rank)
  return entries if maxage <= 0 || total <= maxage
  factor = maxage * 0.9 / total
  entries.each { |e| e.rank *= factor }
  entries.select { |e| e.rank >= 1.0 }
end

def parse_add(argv)
  score = 1.0
  paths = []
  i = 0
  while i < argv.length
    a = argv[i]
    if a == '--'
      paths.concat(argv[(i + 1)..] || []); break
    elsif a == '-h' || a == '--help'
      puts sub_help('add'); exit 0
    elsif a == '-V' || a == '--version'
      puts "zoxide-add #{VERSION}"; exit 0
    elsif a == '-s' || a == '--score'
      i += 1; clap_error("a value is required for '--score <SCORE>'") if i >= argv.length
      begin score = Float(argv[i]); rescue; clap_error("invalid value '#{argv[i]}' for '--score <SCORE>': invalid float literal"); end
    elsif a.start_with?('--score=')
      begin score = Float(a.split('=', 2)[1]); rescue; clap_error("invalid value '#{a.split('=', 2)[1]}' for '--score <SCORE>': invalid float literal"); end
    else
      paths << a
    end
    i += 1
  end
  clap_error("the following required arguments were not provided:\n  <PATHS>...\n\nUsage: executable add <PATHS>...") if paths.empty?
  [score, paths]
end

def cmd_add(argv)
  score, paths = parse_add(argv)
  entries = read_db
  now = Time.now.to_i
  paths.each do |path|
    p = canonical(path)
    die("not a directory: #{path}") unless File.directory?(p)
    next if excluded?(p)
    e = entries.find { |x| x.path == p }
    if e
      e.rank += score
      e.time = now
    else
      entries << Entry.new(p, [score, 1.0].max, now)
    end
  end
  write_db(age(entries))
end

def available?(e, all)
  all || File.directory?(e.path)
end

def fuzzy?(s, pat)
  return true if pat.empty?
  j = 0
  s.downcase.each_char do |c|
    j += 1 if c == pat.downcase[j]
    return true if j == pat.length
  end
  false
end

def match_entry?(path, kws)
  pos = 0
  low = path.downcase
  kws.all? do |kw|
    k = kw.downcase
    if k.include?('/')
      idx = low.index(k, pos)
      ok = !idx.nil?
      pos = idx + k.length if ok
      ok
    else
      rest = low[pos..] || ''
      idx = rest.index(k)
      if idx
        pos += idx + k.length
        true
      elsif fuzzy?(rest, k)
        true
      else
        false
      end
    end
  end
end

def frecency(e)
  age = Time.now.to_i - e.time.to_i
  weight =
    if age < 3600
      4.0
    elsif age < 86_400
      2.0
    elsif age < 604_800
      0.5
    else
      0.25
    end
  e.rank * weight
end

def parse_query(argv)
  opts = { all: false, interactive: false, list: false, score: false, exclude: nil, base: nil }
  kws = []
  i = 0
  while i < argv.length
    a = argv[i]
    if a == '--'
      kws.concat(argv[(i + 1)..] || []); break
    elsif a == '-h' || a == '--help'
      puts sub_help('query'); exit 0
    elsif a == '-V' || a == '--version'
      puts "zoxide-query #{VERSION}"; exit 0
    elsif a == '-a' || a == '--all'
      opts[:all] = true
    elsif a == '-i' || a == '--interactive'
      opts[:interactive] = true
    elsif a == '-l' || a == '--list'
      opts[:list] = true
    elsif a == '-s' || a == '--score'
      opts[:score] = true
    elsif a =~ /^-[alsi]{2,}$/
      a[1..].each_char { |c| opts[{ 'a'=>:all, 'l'=>:list, 's'=>:score, 'i'=>:interactive }[c]] = true }
    elsif a == '--exclude'
      i += 1; opts[:exclude] = canonical(argv[i])
    elsif a.start_with?('--exclude=')
      opts[:exclude] = canonical(a.split('=', 2)[1])
    elsif a == '--base-dir'
      i += 1; opts[:base] = canonical(argv[i])
    elsif a.start_with?('--base-dir=')
      opts[:base] = canonical(a.split('=', 2)[1])
    elsif a.start_with?('-')
      clap_error("unexpected argument '#{a}' found")
    else
      kws << a
    end
    i += 1
  end
  [opts, kws]
end

def fmt_score(x)
  format('%6.1f', x)
end

def cmd_query(argv)
  opts, kws = parse_query(argv)
  if opts[:interactive]
    warn 'zoxide: fzf returned an unknown error'
    exit 1
  end
  base = opts[:base]
  matches = read_db.select { |e| available?(e, opts[:all]) }
  matches = matches.select { |e| e.path.start_with?(base == '/' ? '/' : base + '/') || e.path == base } if base
  matches = matches.select { |e| match_entry?(e.path, kws) }
  matches.sort_by! { |e| [-frecency(e), e.path] }
  if opts[:exclude]
    only = matches.length == 1 && matches[0].path == opts[:exclude]
    matches = matches.reject { |e| e.path == opts[:exclude] }
    if matches.empty? && only && !opts[:list]
      warn 'zoxide: you are already in the only match'
      exit 1
    end
  end
  if matches.empty?
    warn 'zoxide: no match found' unless opts[:list]
    exit(opts[:list] ? 0 : 1)
  end
  out = opts[:list] ? matches : [matches.first]
  out.each do |e|
    puts(opts[:score] ? "#{fmt_score(frecency(e))} #{e.path}" : e.path)
  end
end

def cmd_remove(argv)
  if argv.delete('-h') || argv.delete('--help')
    puts sub_help('remove'); exit 0
  end
  if argv.delete('-V') || argv.delete('--version')
    puts "zoxide-remove #{VERSION}"; exit 0
  end
  paths = argv.reject { |a| a == '--' }.map { |p| canonical(p) }
  entries = read_db
  entries = paths.empty? ? entries.select { |e| File.directory?(e.path) } : entries.reject { |e| paths.include?(e.path) }
  write_db(entries)
end

def cmd_import(argv)
  from = nil; merge = false; path = nil; i = 0
  while i < argv.length
    a = argv[i]
    if a == '-h' || a == '--help'
      puts sub_help('import'); exit 0
    elsif a == '-V' || a == '--version'
      puts "zoxide-import #{VERSION}"; exit 0
    elsif a == '--merge'
      merge = true
    elsif a == '--from'
      i += 1; from = argv[i]
    elsif a.start_with?('--from=')
      from = a.split('=', 2)[1]
    elsif a != '--'
      path = a
    end
    i += 1
  end
  clap_error("invalid value '#{from}' for '--from <FROM>'\n  [possible values: autojump, z]") unless %w[autojump z].include?(from)
  die("could not open database for importing: #{path}\n\nCaused by:\n    No such file or directory (os error 2)") unless path && File.file?(path)
  entries = merge ? read_db : []
  now = Time.now.to_i
  File.readlines(path, chomp: true).each do |line|
    next if line.empty?
    p = nil; r = 1.0
    t = now
    if from == 'z'
      parts = line.split('|')
      if parts.length >= 2
        p, r = parts[0], parts[1].to_f
        t = parts[2].to_i if parts.length >= 3
      end
    else
      parts = line.split("\t")
      if parts.length >= 2
        r = parts[0].to_f
        p = parts[1]
        t = 0
      end
    end
    next unless p && File.directory?(File.expand_path(p))
    cp = canonical(p)
    e = entries.find { |x| x.path == cp }
    e ? e.rank += r : entries << Entry.new(cp, [r, 1.0].max, t)
  end
  write_db(age(entries))
end

def cmd_edit(argv)
  if argv.include?('-h') || argv.include?('--help')
    puts sub_help('edit'); exit 0
  end
  if argv.include?('-V') || argv.include?('--version')
    puts "zoxide-edit #{VERSION}"; exit 0
  end
  editor = ENV['EDITOR'] || ENV['VISUAL']
  die('EDITOR is not set') if editor.to_s.empty?
  system("#{editor} #{Shellwords.escape(db_path)}")
  exit($?.exitstatus || 0)
end

def init_template(shell, cmd, hook, no_cmd)
  pwd = ENV['_ZO_RESOLVE_SYMLINKS'] == '1' ? 'pwd -P' : 'pwd -L'
  case shell
  when 'bash', 'zsh'
    hook_block = case hook
                 when 'none' then "# Hook configuration for zoxide.\n# -- not configured --"
                 when 'prompt' then "function __zoxide_hook() {\n    \\builtin local -r retval=\"$?\"\n    \\command zoxide add -- \"$(#{pwd})\"\n    return \"${retval}\"\n}\nPROMPT_COMMAND=\"${PROMPT_COMMAND:+${PROMPT_COMMAND};}__zoxide_hook\""
                 else "__zoxide_oldpwd=\"$(#{pwd})\"\nfunction __zoxide_hook() {\n    \\builtin local pwd_tmp\n    pwd_tmp=\"$(#{pwd})\"\n    if [[ ${__zoxide_oldpwd} != \"${pwd_tmp}\" ]]; then\n        __zoxide_oldpwd=\"${pwd_tmp}\"\n        \\command zoxide add -- \"${__zoxide_oldpwd}\"\n    fi\n}\nPROMPT_COMMAND=\"${PROMPT_COMMAND:+${PROMPT_COMMAND};}__zoxide_hook\""
                 end
    command_block = no_cmd ? "# -- not configured --" : "function #{cmd}() { __zoxide_z \"$@\"; }\nfunction #{cmd}i() { __zoxide_zi \"$@\"; }"
    <<~TXT
      # shellcheck shell=bash

      # =============================================================================
      #
      # Utility functions for zoxide.
      #

      function __zoxide_pwd() {
          \\builtin #{pwd}
      }

      function __zoxide_cd() {
          \\builtin cd -- "$@"
      }

      # =============================================================================
      #
      #{hook_block}

      function __zoxide_doctor() { return 0; }

      function __zoxide_z() {
          if [[ $# -eq 0 ]]; then
              __zoxide_cd ~
          elif [[ $# -eq 1 && -d $1 ]]; then
              __zoxide_cd "$1"
          else
              local result
              result="$(\\command zoxide query --exclude "$(__zoxide_pwd)" -- "$@")" && __zoxide_cd "${result}"
          fi
      }

      function __zoxide_zi() {
          local result
          result="$(\\command zoxide query --interactive -- "$@")" && __zoxide_cd "${result}"
      }

      # =============================================================================
      #
      # Commands for zoxide. Disable these using --no-cmd.
      #

      #{command_block}

      # =============================================================================
      #
      # To initialize zoxide, add this to your shell configuration file:
      #
      # eval "$(zoxide init #{shell})"
    TXT
  when 'fish'
    command_block = no_cmd ? "# -- not configured --" : "function #{cmd}\n    __zoxide_z $argv\nend\nfunction #{cmd}i\n    __zoxide_zi $argv\nend"
    <<~TXT
      function __zoxide_pwd
          builtin #{pwd}
      end
      function __zoxide_cd
          builtin cd $argv
      end
      function __zoxide_hook --on-variable PWD
          command zoxide add -- (__zoxide_pwd)
      end
      function __zoxide_z
          set -l result (command zoxide query --exclude (__zoxide_pwd) -- $argv)
          and __zoxide_cd $result
      end
      function __zoxide_zi
          set -l result (command zoxide query --interactive -- $argv)
          and __zoxide_cd $result
      end
      #{command_block}
    TXT
  when 'posix'
    command_block = no_cmd ? "# -- not configured --" : "#{cmd}() { __zoxide_z \"$@\"; }\n#{cmd}i() { __zoxide_zi \"$@\"; }"
    <<~TXT
      # shellcheck shell=sh
      __zoxide_pwd() { command #{pwd}; }
      __zoxide_cd() { command cd "$@"; }
      __zoxide_z() {
          if [ "$#" -eq 0 ]; then __zoxide_cd ~; else
              __zoxide_result="$(command zoxide query --exclude "$(__zoxide_pwd)" -- "$@")" && __zoxide_cd "$__zoxide_result"
          fi
      }
      __zoxide_zi() { __zoxide_result="$(command zoxide query --interactive -- "$@")" && __zoxide_cd "$__zoxide_result"; }
      #{command_block}
    TXT
  else
    "# zoxide #{shell} initialization\n# command: #{cmd}\n# hook: #{hook}\n"
  end
end

def cmd_init(argv)
  cmd = 'z'; hook = 'pwd'; no_cmd = false; shell = nil; i = 0
  while i < argv.length
    a = argv[i]
    if a == '-h' || a == '--help'
      puts sub_help('init'); exit 0
    elsif a == '-V' || a == '--version'
      puts "zoxide-init #{VERSION}"; exit 0
    elsif a == '--no-cmd'
      no_cmd = true
    elsif a == '--cmd'
      i += 1; cmd = argv[i]
    elsif a.start_with?('--cmd=')
      cmd = a.split('=', 2)[1]
    elsif a == '--hook'
      i += 1; hook = argv[i]
    elsif a.start_with?('--hook=')
      hook = a.split('=', 2)[1]
    elsif a != '--'
      shell = a
    end
    i += 1
  end
  clap_error("invalid value '#{hook}' for '--hook <HOOK>'\n  [possible values: none, prompt, pwd]") unless HOOKS.include?(hook)
  clap_error("invalid value '#{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]") unless SHELLS.include?(shell)
  puts init_template(shell, cmd, hook, no_cmd)
end

argv = ARGV.dup
if argv.empty? || argv[0] == '-h' || argv[0] == '--help'
  puts main_help; exit 0
elsif argv[0] == '-V' || argv[0] == '--version'
  puts "zoxide #{VERSION}"; exit 0
end

cmd = argv.shift
unless COMMANDS.include?(cmd)
  warn "error: unrecognized subcommand '#{cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'."
  exit 2
end

case cmd
when 'add' then cmd_add(argv)
when 'query' then cmd_query(argv)
when 'remove' then cmd_remove(argv)
when 'import' then cmd_import(argv)
when 'edit' then cmd_edit(argv)
when 'init' then cmd_init(argv)
end
