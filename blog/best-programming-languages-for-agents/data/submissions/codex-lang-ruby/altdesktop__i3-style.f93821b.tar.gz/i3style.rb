#!/usr/bin/env ruby
# frozen_string_literal: true

require 'yaml'
require 'fileutils'

THEME_DESCRIPTIONS = [
  ['slate', 'Slate theme by Jody Ribton <jody@ribton.me>'],
  ['alphare', 'A beige theme by Alphare'],
  ['ubuntu', 'Ubuntu theme by lasers'],
  ['flat-gray', 'flat gray based theme'],
  ['purple', 'Purple theme by AAlakkad <http://aalakkad.me>'],
  ['archlinux', 'Archlinux theme by okraits <http://okraits.de>'],
  ['default', 'Default theme for i3wm <http://i3wm.org>'],
  ['debian', 'Debian theme by lasers'],
  ['oceanic-next', 'Theme by Valentin Weber inspired by voronianski (https://github.com/voronianski/oceanic-next-color-scheme)'],
  ['base16-tomorrow', 'Base16 Tomorrow, by Chris Kempson (http://chriskempson.com)'],
  ['okraits', 'A simple theme by okraits <http://okraits.de>'],
  ['icelines', 'icelines theme by mbfraga'],
  ['solarized', 'Solarized theme by lasers'],
  ['deep-purple', 'Inspired by the Purple and Default themes. By jcpst <http://jcpst.com>'],
  ['tomorrow-night-80s', 'Tomorrow Night 80s theme by jmfurlott <http://jmfurlott.com>'],
  ['seti', 'seti theme by Jody Ribton - based on the seti Atom theme at https://atom.io/themes/seti-ui'],
  ['lime', 'Lime theme by wei2912 <http://wei2912.github.io>, based on Archlinux theme by okraits <http://okraits.de>'],
  ['gruvbox', 'Made by freeware-preacher <https://github.com/freeware-preacher> to match gruvbox by morhetz <https://github.com/morhetz>'],
  ['mate', 'Theme for blending i3 into MATE']
].freeze

RAW_THEMES = {
  'slate' => ['#586e75', '#002b36', '#aea79f', '#586e75 #586e75 #ffffff', '#073642 #073642 #ffffff', '#002b36 #002b36 #aea79f', '#77216f #77216f #ffffff', '#586e75 #586e75 #fdf6e3 #268bd2', '#073642 #073642 #93a1a1 #002b36', '#002b36 #002b36 #586e75 #002b36', '#dc322f #dc322f #fdf6e3 #dc322f'],
  'alphare' => ['#000000', '#FDF6E3', '#002B36', '#000000 #268BD2 #FFFFFF', '#333333 #222222 #FFFFFF', '#333333 #222222 #888888', '#2F343A #900000 #FFFFFF', '#000000 #FDF6E3 #002B36 #000000', '#000000 #5F676A #FDF6E3 #484E50', '#000000 #000000 #FDF6E3 #000000', '#000000 #DC322F #FDF6E3 #DC322F'],
  'ubuntu' => ['#333333', '#2c001e', '#aea79f', '#dd4814 #dd4814 #ffffff', '#902a07 #902a07 #aea79f', '#902a07 #902a07 #aea79f', '#77216f #77216f #ffffff', '#dd4814 #dd4814 #ffffff #902a07', '#5e2750 #5e2750 #aea79f #5e2750', '#5e2750 #5e2750 #aea79f #5e2750', '#77216f #77216f #ffffff #efb73e'],
  'flat-gray' => [nil, '#333333', '#AAAAAA', '#282828 #282828 #FFFFFF', nil, '#333333 #333333 #AAAAAA', nil, '#000000 #000000 #FFFFFF #000000', '#333333 #333333 #FFFFFF #000000', '#333333 #333333 #FFFFFF #333333', nil],
  'purple' => ['#AAAAAA', '#222133', '#FFFFFF', '#664477 #664477 #cccccc', '#DCCD69 #DCCD69 #181715', '#222133 #222133 #AAAAAA', '#CE4045 #CE4045 #FFFFFF', '#664477 #664477 #cccccc #e7d8b1', '#e7d8b1 #e7d8b1 #181715 #A074C4', '#222133 #222133 #AAAAAA #A074C4', '#CE4045 #CE4045 #e7d8b1 #DCCD69'],
  'archlinux' => ['#666666', '#222222', '#dddddd', '#0088CC #0088CC #ffffff', '#333333 #333333 #ffffff', '#333333 #333333 #888888', '#2f343a #900000 #ffffff', '#0088CC #0088CC #ffffff #dddddd', '#333333 #333333 #888888 #292d2e', '#333333 #333333 #888888 #292d2e', '#2f343a #900000 #ffffff #900000'],
  'default' => ['#666666', '#000000', '#ffffff', '#4c7899 #285577 #ffffff', '#333333 #5f676a #ffffff', '#333333 #222222 #888888', '#2f343a #900000 #ffffff', '#4c7899 #285577 #ffffff #2e9ef4', '#333333 #5f676a #ffffff #484e50', '#333333 #222222 #888888 #292d2e', '#2f343a #900000 #ffffff #900000'],
  'debian' => ['#444444', '#222222', '#666666', '#d70a53 #d70a53 #ffffff', '#333333 #333333 #888888', '#333333 #333333 #888888', '#eb709b #eb709b #ffffff', '#d70a53 #d70a53 #ffffff #8c0333', '#333333 #333333 #888888 #333333', '#333333 #333333 #888888 #333333', '#eb709b #eb709b #ffffff #eb709b'],
  'oceanic-next' => ['#65737E', '#1B2B34', '#D8DEE9', '#6699CC #6699CC #1B2B34', '#5FB3B3 #5FB3B3 #1B2B34', '#343D46 #343D46 #D8DEE9', '#EC5f67 #EC5f67 #1B2B34', '#6699CC #6699CC #1B2B34 #6699CC', '#5FB3B3 #5FB3B3 #D8DEE9 #A7ADBA', '#343D46 #343D46 #D8DEE9 #343D46', '#EC5f67 #EC5f67 #1B2B34 #EC5f67'],
  'base16-tomorrow' => ['#969896', '#1d1f21', '#c5c8c6', '#81a2be #81a2be #1d1f21', '#373b41 #373b41 #ffffff', '#282a2e #282a2e #969896', '#cc6666 #cc6666 #ffffff', '#81a2be #81a2be #1d1f21 #282a2e', '#373b41 #373b41 #969896 #282a2e', '#282a2e #282a2e #969896 #282a2e', '#373b41 #cc6666 #ffffff #cc6666'],
  'okraits' => ['#666666', '#333333', '#bbbbbb', '#888888 #dddddd #222222', '#333333 #555555 #bbbbbb', '#333333 #555555 #bbbbbb', '#2f343a #900000 #ffffff', '#888888 #dddddd #222222 #2e9ef4', '#333333 #555555 #bbbbbb #484e50', '#333333 #333333 #888888 #292d2e', '#2f343a #900000 #ffffff #900000'],
  'icelines' => ['#7d7d7d', '#141414', '#00b0ef', '#00b0ef #141414 #00b0ef', '#141414 #141414 #00b0ef', '#141414 #141414 #7d7d7d', '#ff7066 #141414 #ff7066', '#00b0ef #00b0ef #141414 #ff7066', '#141414 #141414 #00b0ef #472b2a', '#141414 #141414 #7d7d7d #141414', '#ff7066 #ff7066 #141414 #ff7066'],
  'solarized' => ['#dc322f', '#002b36', '#268bd2', '#fdf6e3 #859900 #fdf6e3', '#fdf6e3 #6c71c4 #fdf6e3', '#586e75 #93a1a1 #002b36', '#d33682 #d33682 #fdf6e3', '#859900 #859900 #fdf6e3 #6c71c4', '#073642 #073642 #eee8d5 #6c71c4', '#073642 #073642 #93a1a1 #586e75', '#d33682 #d33682 #fdf6e3 #dc322f'],
  'deep-purple' => ['#666666', '#000000', '#ffffff', '#551a8b #551a8b #ffffff', '#333333 #5f676a #ffffff', '#000000 #000000 #888888', '#2f343a #900000 #ffffff', '#3b1261 #3b1261 #ffffff #662b9c', '#333333 #5f676a #ffffff #484e50', '#222222 #222222 #888888 #292d2e', '#2f343a #900000 #ffffff #900000'],
  'tomorrow-night-80s' => ['#515151', '#2d2d2d', '#cccccc', '#99cc99 #99cc99 #000000', '#333333 #333333 #ffffff', '#2d2d2d #2d2d2d #999999', '#f2777a #f2777a #ffffff', '#99cc99 #99cc99 #000000 #2d2d2d', '#393939 #393939 #888888 #292d2e', '#2d2d2d #2d2d2d #999999 #292d2e', '#2f343a #900000 #ffffff #900000'],
  'seti' => ['#AAAAAA', '#1f2326', '#FFFFFF', '#9FCA56 #9FCA56 #151718', '#DCCD69 #DCCD69 #151718', '#1f2326 #1f2326 #AAAAAA', '#CE4045 #CE4045 #FFFFFF', '#4F99D3 #4F99D3 #151718 #9FCA56', '#9FCA56 #9FCA56 #151718 #A074C4', '#1f2326 #1f2326 #AAAAAA #A074C4', '#CE4045 #CE4045 #FFFFFF #DCCD69'],
  'lime' => ['#888888', '#333333', '#FFFFFF', '#4E9C00 #4E9C00 #FFFFFF', '#333333 #333333 #FFFFFF', '#333333 #333333 #888888', '#C20000 #C20000 #FFFFFF', '#4E9C00 #4E9C00 #FFFFFF #FFFFFF', '#1B3600 #1B3600 #888888 #FFFFFF', '#333333 #333333 #888888 #FFFFFF', '#C20000 #C20000 #FFFFFF #FFFFFF'],
  'gruvbox' => ['#928374', '#282828', '#ebdbb2', '#689d6a #689d6a #282828', '#1d2021 #1d2021 #928374', '#32302f #32302f #928374', '#cc241d #cc241d #ebdbb2', '#689d6a #689d6a #282828 #282828', '#1d2021 #1d2021 #928374 #282828', '#32302f #32302f #928374 #282828', '#cc241d #cc241d #ebdbb2 #282828'],
  'mate' => ['#ffffff', '#3c3b37', '#ffffff', '#526532 #526532 #ffffff', '#aea79f #aea79f #3c3b37', '#3c3b37 #3c3b37 #aea79f', '#FF0000 #FF0000 #ffffff', '#526532 #526532 #ffffff #a4cb64', '#aea79f #aea79f #3c3b37 #aea79f', '#3c3b37 #3c3b37 #aea79f #3c3b37', '#FF0000 #FF0000 #ffffff #FF0000']
}.freeze

BAR_KEYS = %w[separator background statusline focused_workspace active_workspace inactive_workspace urgent_workspace].freeze
CLIENT_KEYS = %w[focused focused_inactive unfocused urgent].freeze

def build_themes
  RAW_THEMES.transform_values do |v|
    {
      'bar' => {
        'separator' => v[0],
        'background' => v[1],
        'statusline' => v[2],
        'focused_workspace' => v[3],
        'active_workspace' => v[4],
        'inactive_workspace' => v[5],
        'urgent_workspace' => v[6]
      },
      'client' => {
        'focused' => v[7],
        'focused_inactive' => v[8],
        'unfocused' => v[9],
        'urgent' => v[10]
      }
    }
  end
end

THEMES = build_themes.freeze

def help
  puts <<~HELP
    i3-style 1.0
    Make your i3 config a bit more stylish

    USAGE:
        executable [FLAGS] [OPTIONS] [theme]

    FLAGS:
        -h, --help        Prints help information
        -l, --list-all    Print a list of all available themes
        -r, --reload      Apply the theme by reloading the config
        -s, --save        Set the output file to the path of the input file
        -V, --version     Prints version information

    OPTIONS:
        -c, --config <file>      The config file the theme should be applied to. Defaults to the default i3 location.
        -o, --output <file>      Apply the theme, attempt to validate the result, and write it to <file>
        -t, --to-theme <file>    Prints an i3-style theme based on the given config suitable for sharing with others
                                 [default: ]

    ARGS:
        <theme>    The theme to use
  HELP
end

def list_all
  puts
  puts 'Available themes:'
  puts
  THEME_DESCRIPTIONS.each { |name, desc| puts "  #{name.ljust(18)} - #{desc}" }
end

def default_config
  home = ENV['HOME'] || Dir.home
  p1 = File.join(home, '.config', 'i3', 'config')
  return p1 if File.exist?(p1)

  File.join(home, '.i3', 'config')
end

def parse_args(argv)
  opts = { config: nil, output: nil, reload: false, save: false, list: false, to_theme: nil, theme: nil }
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-h', '--help'
      help
      exit 0
    when '-V', '--version'
      puts 'i3-style 1.0'
      exit 0
    when '-l', '--list-all'
      opts[:list] = true
    when '-r', '--reload'
      opts[:reload] = true
    when '-s', '--save'
      opts[:save] = true
    when '-c', '--config'
      i += 1
      opts[:config] = argv[i]
    when /\A--config=(.*)\z/
      opts[:config] = Regexp.last_match(1)
    when '-o', '--output'
      i += 1
      opts[:output] = argv[i]
    when /\A--output=(.*)\z/
      opts[:output] = Regexp.last_match(1)
    when '-t', '--to-theme'
      i += 1
      opts[:to_theme] = argv[i] || ''
    when /\A--to-theme=(.*)\z/
      opts[:to_theme] = Regexp.last_match(1)
    else
      opts[:theme] ||= arg
    end
    i += 1
  end
  opts
end

def validate_config(path)
  system('i3', '-C', '-c', path, out: File::NULL, err: File::NULL)
end

def validation_error(path)
  warn 'Could not validate config.'
  warn "Use `i3 -C -c #{path}` to see validation errors."
  exit 1
end

def load_theme(name)
  return THEMES[name] if THEMES.key?(name)

  begin
    data = YAML.load_file(name)
  rescue StandardError => e
    warn "Could not open theme: #{name} - #{e.message}"
    warn ' Use `i3-style --list-all` to see the available themes.'
    exit 1
  end
  yaml_to_theme(data)
end

def resolve_color(colors, value)
  return nil if value.nil?
  return value if value.to_s.start_with?('#')

  colors.fetch(value.to_s, value.to_s)
end

def triple(hash, colors)
  %w[border background text].map { |k| resolve_color(colors, hash[k]) }.join(' ')
end

def quad(hash, colors)
  %w[border background text indicator].map { |k| resolve_color(colors, hash[k]) }.join(' ')
end

def yaml_to_theme(data)
  colors = data.fetch('colors', {})
  wc = data.fetch('window_colors', {})
  bc = data.fetch('bar_colors', {})
  {
    'bar' => {
      'separator' => resolve_color(colors, bc['separator']),
      'background' => resolve_color(colors, bc['background']),
      'statusline' => resolve_color(colors, bc['statusline']),
      'focused_workspace' => bc['focused_workspace'] ? triple(bc['focused_workspace'], colors) : nil,
      'active_workspace' => bc['active_workspace'] ? triple(bc['active_workspace'], colors) : nil,
      'inactive_workspace' => bc['inactive_workspace'] ? triple(bc['inactive_workspace'], colors) : nil,
      'urgent_workspace' => bc['urgent_workspace'] ? triple(bc['urgent_workspace'], colors) : nil
    },
    'client' => {
      'focused' => wc['focused'] ? quad(wc['focused'], colors) : nil,
      'focused_inactive' => wc['focused_inactive'] ? quad(wc['focused_inactive'], colors) : nil,
      'unfocused' => wc['unfocused'] ? quad(wc['unfocused'], colors) : nil,
      'urgent' => wc['urgent'] ? quad(wc['urgent'], colors) : nil
    }
  }
end

def line_indent(line)
  line[/^\s*/] || ''
end

def workspace_line(indent, key, value, old_line, inserted)
  parts = old_line ? old_line.strip.split(/\s+/) : []
  extra = parts.length > 3 ? " #{parts[-1]}" : (inserted ? ' ' : '')
  "#{indent}#{key} #{value}#{extra}\n"
end

def apply_theme(config, theme)
  lines = config.lines
  out = []
  stack = []
  in_colors = false
  colors_indent = '    '
  seen_bar = {}
  seen_client = {}

  lines.each do |line|
    stripped = line.strip
    context = stack.last
    if in_colors && stripped == '}'
      BAR_KEYS.each do |key|
        next if seen_bar[key] || theme['bar'][key].nil?
        out << if key.end_with?('_workspace')
                 workspace_line(colors_indent, key, theme['bar'][key], nil, true)
               else
                 "#{colors_indent}#{key} #{theme['bar'][key]}\n"
               end
      end
      in_colors = false
    end

    if in_colors && (m = line.match(/^(\s*)(separator|background|statusline|focused_workspace|active_workspace|inactive_workspace|urgent_workspace)\b/))
      key = m[2]
      if theme['bar'][key]
        seen_bar[key] = true
        out << if key.end_with?('_workspace')
                 workspace_line(m[1], key, theme['bar'][key], line, false)
               else
                 "#{m[1]}#{key} #{theme['bar'][key]}\n"
               end
      else
        out << line
      end
      next
    end

    if (m = line.match(/^(\s*)client\.(focused|focused_inactive|unfocused|urgent)\b/))
      key = m[2]
      if theme['client'][key]
        seen_client[key] = true
        out << "#{m[1]}client.#{key} #{theme['client'][key]}\n"
      else
        out << line
      end
      next
    end

    out << line

    if (m = stripped.match(/^([A-Za-z0-9_]+)\s*\{$/))
      stack << m[1]
      if m[1] == 'colors' && context == 'bar'
        in_colors = true
        colors_indent = line_indent(line) + '  '
      end
    elsif stripped == '}'
      stack.pop
    end
  end

  CLIENT_KEYS.each do |key|
    next if seen_client[key] || theme['client'][key].nil?
    out << "client.#{key} #{theme['client'][key]}\n"
  end

  out.join
end

def extract_theme(config)
  bar = {}
  client = {}
  in_bar = false
  in_colors = false
  stack = []
  config.each_line do |line|
    stripped = line.strip
    if in_colors && (m = stripped.match(/^(separator|background|statusline)\s+(#\h+)/))
      bar[m[1]] = m[2].upcase
    elsif in_colors && (m = stripped.match(/^(focused_workspace|active_workspace|inactive_workspace|urgent_workspace)\s+(#\h+)\s+(#\h+)\s+(#\h+)/))
      bar[m[1]] = [m[2], m[3], m[4]].map(&:upcase)
    elsif (m = stripped.match(/^client\.(focused|focused_inactive|unfocused|urgent)\s+(#\h+)\s+(#\h+)\s+(#\h+)\s+(#\h+)/))
      client[m[1]] = [m[2], m[3], m[4], m[5]].map(&:upcase)
    end

    if (m = stripped.match(/^([A-Za-z0-9_]+)\s*\{$/))
      in_bar = true if m[1] == 'bar'
      in_colors = true if m[1] == 'colors' && in_bar
      stack << m[1]
    elsif stripped == '}'
      popped = stack.pop
      in_colors = false if popped == 'colors'
      in_bar = false if popped == 'bar'
    end
  end

  all_colors = (bar.values + client.values).flatten.compact.uniq
  names = %w[black red green yellow blue magenta cyan white gray silver maroon olive navy purple teal orange]
  color_names = {}
  all_colors.each_with_index { |c, i| color_names[c] = names[i] || "color#{i}" }
  colors = color_names.invert

  doc = {
    'meta' => { 'description' => 'AUTOMATICALLY GENERATED THEME' },
    'colors' => colors,
    'window_colors' => {},
    'bar_colors' => {}
  }
  client.each { |k, vals| doc['window_colors'][k] = Hash[%w[border background text indicator].zip(vals.map { |v| color_names[v] })] }
  bar.each do |k, vals|
    doc['bar_colors'][k] = vals.is_a?(Array) ? Hash[%w[border background text].zip(vals.map { |v| color_names[v] })] : color_names[vals]
  end
  YAML.dump(doc)
end

opts = parse_args(ARGV)

if opts[:list]
  list_all
  exit 0
end

config_path = opts[:config] || default_config
opts[:output] = config_path if opts[:save]

if opts[:to_theme]
  source = opts[:to_theme].empty? ? config_path : opts[:to_theme]
  validation_error(source) unless validate_config(source)
  result = extract_theme(File.read(source))
  opts[:output] ? File.write(opts[:output], result) : print(result)
  exit 0
end

unless opts[:theme]
  puts 'USAGE:'
  puts '    executable [FLAGS] [OPTIONS] [theme]'
  puts
  puts 'Select a theme as the first argument. Use `--list-all` to see the themes.'
  exit 1
end

validation_error(config_path) unless validate_config(config_path)
theme = load_theme(opts[:theme])
input = File.read(config_path)
output = apply_theme(input, theme)

if opts[:output]
  dir = "/tmp/i3-style/#{rand(1_000_000_000..1_999_999_999)}"
  FileUtils.mkdir_p(dir)
  warn "saving config at #{config_path} to #{dir}/config-input"
  File.write(File.join(dir, 'config-input'), input)
  File.write(opts[:output], output)
else
  print output
end

if opts[:reload]
  system('i3-msg', 'reload', out: File::NULL, err: File::NULL)
end
