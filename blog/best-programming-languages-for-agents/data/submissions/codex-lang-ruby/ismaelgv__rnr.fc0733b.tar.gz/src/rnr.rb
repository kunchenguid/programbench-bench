#!/usr/bin/env ruby
# encoding: UTF-8
# frozen_string_literal: true

require 'fileutils'

VERSION = 'rnr 0.5.1'

MAIN_HELP = <<~HELP
  RnR is a command-line tool to rename multiple files and directories that
  supports regular expressions


  Usage: executable <COMMAND>

  Commands:
    regex      Rename files and directories using a regular expression
    from-file  Read operations from a dump file
    to-ascii   Replace file name UTF-8 chars with ASCII chars representation
    help       Print this message or the help of the given subcommand(s)

  Options:
    -h, --help     Print help
    -V, --version  Print version
HELP

REGEX_HELP = <<~HELP
  Rename files and directories using a regular expression

  Usage: executable regex [OPTIONS] <EXPRESSION> <REPLACEMENT> <PATH(S)>...

  Arguments:
    <EXPRESSION>   Expression to match (can be a regex)
    <REPLACEMENT>  Expression replacement (use single quotes for capture groups)
    <PATH(S)>...   Target paths

  Options:
    -n, --dry-run
            Only show what would be done (default mode)
    -f, --force
            Make actual changes to files
    -b, --backup
            Generate file backups before renaming
    -s, --silent
            Do not print any information
        --color <COLOR>
            Set color output mode [default: auto] [possible values: always, never, auto]
        --dump
            Force dumping operations into a file even in dry-run mode
        --dump-prefix <DUMP_PREFIX>
            Set the dump file prefix [default: rnr-]
        --no-dump
            Do not dump operations into a file
    -l, --replace-limit <LIMIT>
            Limit of replacements, all matches if set to 0
    -t, --replace-transform <REPLACE_TRANSFORM>
            Apply a transformation to replacements including captured groups [possible values: upper, lower, ascii]
    -D, --include-dirs
            Rename matching directories
    -r, --recursive
            Recursive mode
    -d, --max-depth <LEVEL>
            Set max depth in recursive mode
    -x, --hidden
            Include hidden files and directories
    -h, --help
            Print help
HELP

FROM_HELP = <<~HELP
  Read operations from a dump file

  Usage: executable from-file [OPTIONS] <DUMPFILE>

  Arguments:
    <DUMPFILE>  

  Options:
    -n, --dry-run                    Only show what would be done (default mode)
    -f, --force                      Make actual changes to files
    -b, --backup                     Generate file backups before renaming
    -s, --silent                     Do not print any information
        --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
        --dump                       Force dumping operations into a file even in dry-run mode
        --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
        --no-dump                    Do not dump operations into a file
    -u, --undo                       Undo the operations from the dump file
    -h, --help                       Print help
HELP

ASCII_HELP = <<~HELP
  Replace file name UTF-8 chars with ASCII chars representation

  Usage: executable to-ascii [OPTIONS] <PATH(S)>...

  Arguments:
    <PATH(S)>...  Target paths

  Options:
    -n, --dry-run                    Only show what would be done (default mode)
    -f, --force                      Make actual changes to files
    -b, --backup                     Generate file backups before renaming
    -s, --silent                     Do not print any information
        --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
        --dump                       Force dumping operations into a file even in dry-run mode
        --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
        --no-dump                    Do not dump operations into a file
    -D, --include-dirs               Rename matching directories
    -r, --recursive                  Recursive mode
    -d, --max-depth <LEVEL>          Set max depth in recursive mode
    -x, --hidden                     Include hidden files and directories
    -h, --help                       Print help
HELP

def asciiize(str)
  str = str.to_s.dup.force_encoding('UTF-8')
  table = {
    'ß' => 'ss', 'ẞ' => 'SS', 'æ' => 'ae', 'Æ' => 'AE', 'œ' => 'oe', 'Œ' => 'OE',
    'ø' => 'o', 'Ø' => 'O', 'ð' => 'd', 'Ð' => 'D', 'þ' => 'th', 'Þ' => 'Th',
    'ł' => 'l', 'Ł' => 'L', 'đ' => 'd', 'Đ' => 'D'
  }
  s = str.each_char.map { |ch| table.fetch(ch, ch) }.join
  s.unicode_normalize(:nfkd).encode('ASCII', invalid: :replace, undef: :replace, replace: '').gsub(/[^\x00-\x7F]/, '')
end

def default_opts
  {
    dry: true, force: false, backup: false, silent: false, color: 'auto',
    dump: nil, dump_prefix: 'rnr-', no_dump: false, limit: 1, transform: nil,
    include_dirs: false, recursive: false, max_depth: nil, hidden: false, undo: false
  }
end

def parse_common(args, opts, extra = true)
  rest = []
  i = 0
  while i < args.length
    a = args[i]
    case a
    when '-n', '--dry-run' then opts[:dry] = true; opts[:force] = false
    when '-f', '--force' then opts[:force] = true; opts[:dry] = false
    when '-b', '--backup' then opts[:backup] = true
    when '-s', '--silent' then opts[:silent] = true
    when '--dump' then opts[:dump] = true
    when '--no-dump' then opts[:no_dump] = true
    when '--dump-prefix' then i += 1; opts[:dump_prefix] = args[i] || ''
    when '--color' then i += 1; opts[:color] = args[i] || 'auto'
    when '-D', '--include-dirs' then opts[:include_dirs] = true
    when '-r', '--recursive' then opts[:recursive] = true
    when '-x', '--hidden' then opts[:hidden] = true
    when '-d', '--max-depth' then i += 1; opts[:max_depth] = (args[i] || '0').to_i
    when '-l', '--replace-limit' then i += 1; opts[:limit] = (args[i] || '0').to_i
    when '-t', '--replace-transform' then i += 1; opts[:transform] = args[i]
    when '-u', '--undo' then opts[:undo] = true
    when '-h', '--help' then opts[:help] = true
    else
      if a.start_with?('-') && a != '-'
        warn "error: unexpected argument '#{a}' found"
        exit 2
      end
      rest.concat(args[i..])
      break
    end
    i += 1
  end
  extra ? rest : []
end

def hidden_name?(path)
  File.basename(path).start_with?('.') && !['.', '..'].include?(File.basename(path))
end

def collect_paths(paths, opts)
  files = []
  dirs = []
  paths.each do |path|
    next unless File.exist?(path)

    if File.directory?(path)
      if opts[:recursive]
        base_depth = path.to_s.split('/').reject(&:empty?).length
        children = Dir.children(path).reject { |c| !opts[:hidden] && c.start_with?('.') }
        root_dirs, root_files = children.partition { |c| File.directory?(File.join(path, c)) }
        stack = (ordered_files_for_stack(root_files) + root_dirs.sort.reverse).map { |c| File.join(path, c) }
        until stack.empty?
          p = stack.pop
          next if !opts[:hidden] && hidden_name?(p)

          depth = p.split('/').reject(&:empty?).length - base_depth
          next if opts[:max_depth] && depth >= opts[:max_depth]

          if File.directory?(p)
            dirs << p
            children = Dir.children(p).reject { |c| !opts[:hidden] && c.start_with?('.') }
            child_dirs, child_files = children.partition { |c| File.directory?(File.join(p, c)) }
            (ordered_files_for_stack(child_files) + child_dirs.sort.reverse).each { |c| stack << File.join(p, c) }
          else
            files << p
          end
        end
      elsif opts[:include_dirs] && !['.', '..'].include?(File.basename(path))
        dirs << path
      end
    else
      next if !opts[:hidden] && hidden_name?(path)
      files << path
    end
  end
  files + (opts[:include_dirs] ? dirs.reverse : [])
end

def ordered_files_for_stack(files)
  visible, hidden = files.partition { |f| !f.start_with?('.') }
  (hidden.sort + visible.sort).reverse
end

def sibling_path(path, new_base)
  dir = File.dirname(path)
  if dir == '.'
    path.start_with?('./') ? "./#{new_base}" : new_base
  else
    File.join(dir, new_base)
  end
end

def replacement_for(match, template, transform)
  out = template.gsub(/\$\{(\d+)\}/) do
    idx = Regexp.last_match(1).to_i
    idx.zero? ? match[0].to_s : match[idx].to_s
  end
  case transform
  when 'upper' then out.upcase
  when 'lower' then out.downcase
  when 'ascii' then asciiize(out)
  else out
  end
end

def apply_regex_name(name, re, replacement, opts)
  count = 0
  name.gsub(re) do
    if opts[:limit] != 0 && count >= opts[:limit]
      Regexp.last_match[0]
    else
      count += 1
      replacement_for(Regexp.last_match, replacement, opts[:transform])
    end
  end
end

def build_regex_ops(expr, replacement, paths, opts)
  re = Regexp.new(expr)
  ops = collect_paths(paths, opts).filter_map do |path|
    base = File.basename(path)
    new_base = apply_regex_name(base, re, replacement, opts)
    next if new_base == base
    target = sibling_path(path, new_base)
    { 'source' => path, 'target' => target }
  end
  opts[:recursive] ? ops : ops.sort_by { |op| op['target'] }
rescue RegexpError => e
  warn "Error: Bad expression provided\n\nregex parse error:\n    #{expr}\n    ^\nerror: #{e.message.sub(/.*: /, '')}"
  exit 1
end

def build_ascii_ops(paths, opts)
  ops = collect_paths(paths, opts).filter_map do |path|
    base = File.basename(path)
    new_base = asciiize(base)
    next if new_base == base
    { 'source' => path, 'target' => sibling_path(path, new_base) }
  end
  opts[:recursive] ? ops : ops.sort_by { |op| op['target'] }
end

def print_ops(ops, opts)
  return if opts[:silent]
  puts 'This is a DRY-RUN' if opts[:dry]
  ops.each { |op| puts "#{op['source']} -> #{op['target']}" }
end

def dump_ops(ops, opts)
  return if ops.empty? || opts[:no_dump]
  return unless opts[:dump] || opts[:force]

  file = "#{opts[:dump_prefix]}#{Time.now.strftime('%Y-%m-%d_%H%M%S')}.json"
  data = { 'date' => Time.now.strftime('%Y-%m-%d %H:%M:%S'), 'operations' => ops }
  File.write(file, json_dump(data))
end

def json_string(str)
  '"' + str.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
    { '"' => '\"', '\\' => '\\\\', "\b" => '\b', "\f" => '\f', "\n" => '\n', "\r" => '\r', "\t" => '\t' }[ch]
  end + '"'
end

def json_dump(data)
  lines = ["{", "  \"date\": #{json_string(data['date'])},", "  \"operations\": ["]
  data['operations'].each_with_index do |op, idx|
    comma = idx == data['operations'].length - 1 ? '' : ','
    lines << "    {"
    lines << "      \"source\": #{json_string(op['source'])},"
    lines << "      \"target\": #{json_string(op['target'])}"
    lines << "    }#{comma}"
  end
  lines << "  ]"
  lines << "}"
  lines.join("\n")
end

def json_unescape(str)
  str.gsub(/\\(["\\bfnrt])/) do
    { '"' => '"', '\\' => '\\', 'b' => "\b", 'f' => "\f", 'n' => "\n", 'r' => "\r", 't' => "\t" }[Regexp.last_match(1)]
  end
end

def read_ops_file(path)
  text = File.read(path)
  text.scan(/"source"\s*:\s*"((?:\\.|[^"])*)"\s*,\s*"target"\s*:\s*"((?:\\.|[^"])*)"/m).map do |src, dst|
    { 'source' => json_unescape(src), 'target' => json_unescape(dst) }
  end
end

def execute_ops(ops, opts)
  return if opts[:dry]
  ops.each do |op|
    src = op['source']
    dst = op['target']
    unless File.exist?(src)
      warn "Error: Source path does not exist #{src}"
      exit 1
    end
    if File.exist?(dst)
      warn "Error: Conflict with existing path #{src} -> #{dst}"
      exit 1
    end
  end
  ops.each do |op|
    src = op['source']
    dst = op['target']
    if opts[:backup]
      backup = "#{src}.bk"
      FileUtils.cp_r(src, backup)
      puts "Info:  Backup created - #{src} -> #{backup}" unless opts[:silent]
    end
    FileUtils.mv(src, dst)
  end
end

def run_ops(ops, opts)
  print_ops(ops, opts)
  execute_ops(ops, opts)
  dump_ops(ops, opts)
end

cmd = ARGV.shift
case cmd
when nil, '-h', '--help'
  print MAIN_HELP
when '-V', '--version'
  puts VERSION
when 'help'
  sub = ARGV.shift
  print(sub == 'regex' ? REGEX_HELP : sub == 'from-file' ? FROM_HELP : sub == 'to-ascii' ? ASCII_HELP : MAIN_HELP)
when 'regex'
  opts = default_opts
  rest = parse_common(ARGV, opts)
  if opts[:help]
    print REGEX_HELP
    exit
  end
  if rest.length < 3
    warn 'error: the following required arguments were not provided:'
    exit 2
  end
  expr, replacement, *paths = rest
  run_ops(build_regex_ops(expr, replacement, paths, opts), opts)
when 'to-ascii'
  opts = default_opts
  rest = parse_common(ARGV, opts)
  if opts[:help]
    print ASCII_HELP
    exit
  end
  run_ops(build_ascii_ops(rest, opts), opts)
when 'from-file'
  opts = default_opts
  rest = parse_common(ARGV, opts)
  if opts[:help]
    print FROM_HELP
    exit
  end
  dumpfile = rest.first
  ops = read_ops_file(dumpfile)
  ops = ops.map { |op| { 'source' => op['target'], 'target' => op['source'] } }.reverse if opts[:undo]
  run_ops(ops, opts)
else
  warn "error: unrecognized subcommand '#{cmd}'"
  exit 2
end
