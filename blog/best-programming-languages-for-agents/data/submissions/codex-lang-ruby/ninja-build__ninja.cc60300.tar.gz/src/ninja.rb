#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'open3'
require 'shellwords'

VERSION = '1.14.0.git'

HELP = <<~TXT
  usage: ninja [options] [targets...]

  if targets are unspecified, builds the 'default' target (see manual).

  options:
    --version      print ninja version ("1.14.0.git")
    -v, --verbose  show all command lines while building
    --quiet        don't show progress status, just command output

    -C DIR   change to DIR before doing anything else
    -f FILE  specify input build file [default=build.ninja]

    -j N     run N jobs in parallel (0 means infinity) [default=6 on this system]
    -k N     keep going until N jobs fail (0 means infinity) [default=1]
    -l N     do not start new jobs if the load average is greater than N
    -n       dry run (don't run commands but act like they succeeded)

    -d MODE  enable debugging (use '-d list' to list modes)
    -t TOOL  run a subtool (use '-t list' to list subtools)
      terminates toplevel options; further flags are passed to the tool
    -w FLAG  adjust warnings (use '-w list' to list warnings)
TXT

TOOLS = [
  ['browse', 'browse dependency graph in a web browser'],
  ['clean', 'clean built files'],
  ['commands', 'list all commands required to rebuild given targets'],
  ['inputs', 'list all inputs required to rebuild given targets'],
  ['multi-inputs', 'print one or more sets of inputs required to build targets'],
  ['deps', 'show dependencies stored in the deps log'],
  ['missingdeps', 'check deps log dependencies on generated files'],
  ['graph', 'output graphviz dot file for targets'],
  ['query', 'show inputs/outputs for a path'],
  ['targets', 'list targets by their rule or depth in the DAG'],
  ['compdb', 'dump JSON compilation database to stdout'],
  ['compdb-targets', 'dump JSON compilation database for a given list of targets to stdout'],
  ['recompact', 'recompacts ninja-internal data structures'],
  ['restat', 'restats all outputs in the build log'],
  ['rules', 'list all rules'],
  ['cleandead', 'clean built files that are no longer produced by the manifest']
].freeze

class NinjaError < StandardError; end

Rule = Struct.new(:name, :vars)
Edge = Struct.new(:outputs, :implicit_outputs, :rule, :inputs, :implicit_inputs,
                  :order_only, :vars, :line, keyword_init: true)

class Manifest
  attr_reader :rules, :edges, :by_output, :defaults, :vars

  def initialize
    @rules = { 'phony' => Rule.new('phony', {}) }
    @edges = []
    @by_output = {}
    @defaults = []
    @vars = {}
    @included = []
  end

  def parse_file(path, scope = @vars)
    full = File.expand_path(path)
    raise NinjaError, "loading '#{path}': No such file or directory" unless File.exist?(path)
    return if @included.include?(full)

    @included << full
    lines = logical_lines(File.read(path))
    i = 0
    while i < lines.length
      raw, line_no = lines[i]
      stripped = strip_comment(raw).rstrip
      i += 1
      next if stripped.strip.empty?

      if stripped.start_with?(' ')
        raise NinjaError, "#{path}:#{line_no}: unexpected indent"
      elsif (m = stripped.match(/\Arule\s+(\S+)\s*\z/))
        name = expand(m[1], scope)
        body = {}
        while i < lines.length && lines[i][0].start_with?(' ')
          key, val = parse_binding(lines[i][0].strip, path, lines[i][1])
          body[key] = val
          i += 1
        end
        @rules[name] = Rule.new(name, body)
      elsif (m = stripped.match(/\Abuild\s+(.+)\z/))
        edge = parse_build(m[1], scope, path, line_no)
        while i < lines.length && lines[i][0].start_with?(' ')
          key, val = parse_binding(lines[i][0].strip, path, lines[i][1])
          edge.vars[key] = expand(val, scope)
          i += 1
        end
        @edges << edge
        (edge.outputs + edge.implicit_outputs).each do |out|
          raise NinjaError, "multiple rules generate #{out}" if @by_output[out]
          @by_output[out] = edge
        end
      elsif (m = stripped.match(/\Adefault\s+(.+)\z/))
        @defaults.concat(split_words(expand(m[1], scope)))
      elsif (m = stripped.match(/\Ainclude\s+(.+)\z/))
        parse_file(expand(m[1], scope), scope)
      elsif (m = stripped.match(/\Asubninja\s+(.+)\z/))
        parse_file(expand(m[1], scope.dup))
      elsif stripped.include?('=')
        key, val = parse_binding(stripped, path, line_no)
        scope[key] = expand(val, scope)
      elsif stripped.start_with?('pool ')
        while i < lines.length && lines[i][0].start_with?(' ')
          i += 1
        end
      else
        raise NinjaError, "#{path}:#{line_no}: unknown build file statement"
      end
    end
  end

  def logical_lines(text)
    out = []
    buf = +''
    first = 1
    text.each_line.with_index(1) do |line, no|
      line = line.chomp
      if line.end_with?('$')
        buf << line[0...-1]
        first = no if buf == line[0...-1]
      else
        out << [buf + line, first]
        buf = +''
        first = no + 1
      end
    end
    out << [buf, first] unless buf.empty?
    out
  end

  def strip_comment(s)
    escaped = false
    s.each_char.with_index do |ch, idx|
      if escaped
        escaped = false
      elsif ch == '$'
        escaped = true
      elsif ch == '#'
        return s[0...idx]
      end
    end
    s
  end

  def parse_binding(s, path, line_no)
    key, val = s.split('=', 2)
    raise NinjaError, "#{path}:#{line_no}: expected variable = value" unless val
    [key.strip, val.strip]
  end

  def parse_build(rest, scope, path, line_no)
    left, right = split_unescaped(rest, ':')
    raise NinjaError, "#{path}:#{line_no}: expected ':' in build statement" unless right
    out_words = split_words(expand(left, scope))
    outputs = []
    implicit_outputs = []
    dst = outputs
    out_words.each do |w|
      if w == '|'
        dst = implicit_outputs
      else
        dst << w
      end
    end
    words = split_words(expand(right, scope))
    rule_name = words.shift
    raise NinjaError, "#{path}:#{line_no}: expected build command name" unless rule_name
    raise NinjaError, "unknown build rule '#{rule_name}'" unless @rules[rule_name]
    inputs = []
    implicit = []
    order = []
    dst = inputs
    words.each do |w|
      case w
      when '|'
        dst = implicit
      when '||'
        dst = order
      else
        dst << w
      end
    end
    Edge.new(outputs: outputs, implicit_outputs: implicit_outputs, rule: rule_name,
             inputs: inputs, implicit_inputs: implicit, order_only: order, vars: {},
             line: line_no)
  end

  def split_unescaped(s, needle)
    escaped = false
    s.each_char.with_index do |ch, idx|
      if escaped
        escaped = false
      elsif ch == '$'
        escaped = true
      elsif ch == needle
        return [s[0...idx].rstrip, s[(idx + 1)..].lstrip]
      end
    end
    [s, nil]
  end

  def split_words(s)
    words = []
    cur = +''
    escaped = false
    s.each_char do |ch|
      if escaped
        cur << ch
        escaped = false
      elsif ch == '$'
        escaped = true
      elsif ch =~ /\s/
        unless cur.empty?
          words << cur
          cur = +''
        end
      else
        cur << ch
      end
    end
    cur << '$' if escaped
    words << cur unless cur.empty?
    words
  end

  def expand(s, scope, edge = nil, stack = [])
    s.gsub(/\$(\$|[ :#]|\{[A-Za-z0-9_.-]+\}|[A-Za-z0-9_.-]+)/) do
      token = Regexp.last_match(1)
      case token
      when '$' then '$'
      when ' ' then ' '
      when ':' then ':'
      when '#' then '#'
      else
        name = token.start_with?('{') ? token[1...-1] : token
        lookup_var(name, scope, edge, stack)
      end
    end
  end

  def lookup_var(name, scope, edge, stack)
    return edge.inputs.join(' ') if edge && name == 'in'
    return edge.outputs.join(' ') if edge && name == 'out'
    return '' if stack.include?(name)

    if edge && edge.vars.key?(name)
      return expand(edge.vars[name], scope, edge, stack + [name])
    end
    if edge && @rules[edge.rule]&.vars&.key?(name)
      return expand(@rules[edge.rule].vars[name], scope, edge, stack + [name])
    end
    scope[name] || ''
  end

  def edge_var(edge, name)
    expand("$#{name}", @vars, edge)
  end
end

class Runner
  def initialize(manifest, opts)
    @m = manifest
    @opts = opts
    @log_path = File.join(@m.vars['builddir'] || '.', '.ninja_log')
    @log = load_log
    @visiting = {}
    @visited = {}
    @plan = []
  end

  def root_targets(args)
    return args unless args.empty?
    return @m.defaults unless @m.defaults.empty?

    inputs = {}
    @m.edges.each { |e| (e.inputs + e.implicit_inputs + e.order_only).each { |i| inputs[i] = true } }
    roots = @m.edges.flat_map(&:outputs).reject { |o| inputs[o] }
    roots.empty? ? @m.edges.flat_map(&:outputs) : roots
  end

  def plan_for(args)
    targets = root_targets(args)
    raise NinjaError, 'no work to do.' if targets.empty?
    targets.each { |t| visit(target_from_caret(t), nil) }
    @plan.select { |e| dirty?(e) }
  end

  def target_from_caret(t)
    return t unless t.end_with?('^')
    src = t[0...-1]
    edge = @m.edges.find { |e| (e.inputs + e.implicit_inputs).include?(src) }
    edge ? edge.outputs.first : t
  end

  def visit(target, needed_by)
    edge = @m.by_output[target]
    unless edge
      return if File.exist?(target)
      return if needed_by.nil?
      raise NinjaError, "'#{target}', needed by '#{needed_by}', missing and no known rule to make it"
    end
    return if @visited[edge.object_id]
    raise NinjaError, "dependency cycle involving #{target}" if @visiting[edge.object_id]

    @visiting[edge.object_id] = true
    (edge.inputs + edge.implicit_inputs + edge.order_only).each { |i| visit(i, edge.outputs.first) }
    @visiting.delete(edge.object_id)
    @visited[edge.object_id] = true
    @plan << edge unless edge.rule == 'phony'
  end

  def dirty?(edge)
    return false if edge.rule == 'phony'
    return true if edge.outputs.any? { |o| !File.exist?(o) }
    command = @m.edge_var(edge, 'command')
    return true if edge.outputs.any? { |o| @log[o] && @log[o] != command }
    newest_in = (edge.inputs + edge.implicit_inputs).select { |i| File.exist?(i) }.map { |i| File.mtime(i) }.max
    oldest_out = edge.outputs.select { |o| File.exist?(o) }.map { |o| File.mtime(o) }.min
    newest_in && oldest_out && newest_in > oldest_out
  end

  def load_log
    return {} unless File.exist?(@log_path)
    log = {}
    File.readlines(@log_path, chomp: true).each do |line|
      out, cmd = line.split("\t", 2)
      log[out] = cmd if out && cmd
    end
    log
  rescue StandardError
    {}
  end

  def record(edge, command)
    return if @opts[:dry_run] || command.empty?
    dir = File.dirname(@log_path)
    FileUtils.mkdir_p(dir) if dir && dir != '.'
    edge.outputs.each { |o| @log[o] = command }
    File.open(@log_path, 'w') do |f|
      @log.sort.each { |out, cmd| f.puts "#{out}\t#{cmd}" }
    end
  end

  def run(args)
    jobs = plan_for(args)
    if jobs.empty?
      puts 'ninja: no work to do.' unless @opts[:quiet]
      return 0
    end
    total = jobs.length
    jobs.each_with_index do |edge, idx|
      command = @m.edge_var(edge, 'command')
      next if command.empty?
      desc = @opts[:verbose] ? command : @m.edge_var(edge, 'description')
      desc = command if desc.empty?
      puts "[#{idx + 1}/#{total}] #{desc}" unless @opts[:quiet]
      next if @opts[:dry_run]

      edge.outputs.each do |out|
        dir = File.dirname(out)
        FileUtils.mkdir_p(dir) if dir && dir != '.'
      end
      out, status = Open3.capture2e(command)
      unless status.success?
        puts "FAILED: [code=#{status.exitstatus}] #{edge.outputs.join(' ')} "
        puts command
        print out
        puts 'ninja: build stopped: subcommand failed.'
        return status.exitstatus || 1
      end
      print out
      record(edge, command)
    end
    0
  end
end

def parse_options(argv)
  opts = { file: 'build.ninja', verbose: false, quiet: false, dry_run: false, tool: nil, tool_args: [] }
  targets = []
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when '--version'
      puts VERSION
      exit 0
    when '-h', '--help'
      print HELP
      exit 1
    when '-v', '--verbose'
      opts[:verbose] = true
    when '--quiet'
      opts[:quiet] = true
    when '-n', '--dry-run'
      opts[:dry_run] = true
      opts[:verbose] = true if opts[:tool] == 'clean'
    when '-C'
      i += 1
      dir = argv[i] || ''
      puts "ninja: Entering directory `#{dir}'"
      Dir.chdir(dir)
    when /\A-C(.+)/
      dir = Regexp.last_match(1)
      puts "ninja: Entering directory `#{dir}'"
      Dir.chdir(dir)
    when '-f'
      i += 1
      opts[:file] = argv[i] || ''
    when /\A-f(.+)/
      opts[:file] = Regexp.last_match(1)
    when '-t'
      i += 1
      opts[:tool] = argv[i]
      opts[:tool_args] = argv[(i + 1)..] || []
      break
    when '-d'
      i += 1
      if argv[i] == 'list'
        puts "debugging modes:\n  stats        print operation counts/timing info\n  explain      explain what caused a command to execute\n  keepdepfile  don't delete depfiles after they're read by ninja\n  keeprsp      don't delete @response files on success\nmultiple modes can be enabled via -d FOO -d BAR"
        exit 1
      end
    when '-w'
      i += 1
      if argv[i] == 'list'
        puts 'warning flags:'
        puts '  phonycycle={err,warn}  phony build statement references itself'
        exit 1
      end
    when /\A-[jkl]\z/
      i += 1
    when /\A-[jkl].+/
      # ignored
    else
      if a.start_with?('-')
        $stderr.puts "#{File.basename($PROGRAM_NAME)}: invalid option -- '#{a.delete_prefix('-')[0]}'"
        print HELP
        exit 1
      end
      targets << a
    end
    i += 1
  end
  [opts, targets]
end

def load_manifest(file)
  m = Manifest.new
  m.parse_file(file)
  m
end

def collect_edges(m, targets, final_only: false)
  targets = if targets.empty?
              m.defaults.empty? ? default_roots(m) : m.defaults
            else
              targets
            end
  seen = {}
  plan = []
  walk = lambda do |target|
    if target.end_with?('^')
      src = target[0...-1]
      edge = m.edges.find { |e| (e.inputs + e.implicit_inputs).include?(src) }
      target = edge.outputs.first if edge
    end
    edge = m.by_output[target]
    return unless edge
    return if seen[edge.object_id]
    seen[edge.object_id] = true
    (edge.inputs + edge.implicit_inputs + edge.order_only).each { |i| walk.call(i) }
    plan << edge unless edge.rule == 'phony'
  end
  targets.each { |t| walk.call(t) }
  final_only ? plan.last(1) : plan
end

def default_roots(m)
  inputs = {}
  m.edges.each { |e| (e.inputs + e.implicit_inputs + e.order_only).each { |i| inputs[i] = true } }
  roots = m.edges.flat_map(&:outputs).reject { |o| inputs[o] }
  roots.empty? ? m.edges.flat_map(&:outputs) : roots
end

def tool_list
  puts 'ninja subtools:'
  TOOLS.each { |name, desc| puts format('%11s  %s', name, desc) }
end

def tool_rules(m)
  puts((m.rules.keys.sort - ['phony']).join("\n"))
  puts 'phony'
end

def tool_targets(m, args)
  mode = args[0] || 'depth'
  if mode == 'all'
    m.edges.each { |e| e.outputs.each { |o| puts "#{o}: #{e.rule}" } }
  elsif mode == 'rule' && args[1]
    m.edges.select { |e| e.rule == args[1] }.each { |e| e.outputs.each { |o| puts o } }
  else
    m.edges.each { |e| e.outputs.each { |o| puts "#{o}: #{e.rule}" } }
  end
end

def tool_commands(m, args)
  final = args.delete('-s')
  edges = collect_edges(m, args, final_only: final)
  edges.each { |e| puts m.edge_var(e, 'command') unless m.edge_var(e, 'command').empty? }
end

def tool_inputs(m, args)
  args = m.defaults if args.empty? && !m.defaults.empty?
  inputs = collect_edges(m, args).flat_map { |e| e.inputs + e.implicit_inputs }.uniq.sort
  inputs.each { |i| puts i }
end

def tool_multi_inputs(m, args)
  delimiter = "\t"
  print0 = false
  targets = []
  i = 0
  while i < args.length
    if args[i] == '--delimiter'
      i += 1
      delimiter = args[i] || delimiter
    elsif args[i] == '--print0'
      print0 = true
    else
      targets << args[i]
    end
    i += 1
  end
  term = print0 ? "\0" : "\n"
  targets.each do |t|
    collect_edges(m, [t]).flat_map { |e| e.inputs + e.implicit_inputs }.uniq.sort.each do |inp|
      print "#{t}#{delimiter}#{inp}#{term}"
    end
  end
end

def tool_query(m, args)
  raise NinjaError, 'expected a target to query' if args.empty?
  args.each do |t|
    e = m.by_output[t]
    if e
      puts "#{t}:"
      puts "  input: #{e.rule}"
      (e.inputs + e.implicit_inputs + e.order_only).each { |i| puts "    #{i}" }
      puts '  outputs:'
      m.edges.select { |x| (x.inputs + x.implicit_inputs + x.order_only).include?(t) }
       .each { |x| x.outputs.each { |o| puts "    #{o}" } }
    else
      puts "#{t}:"
      puts '  input:'
      puts '  outputs:'
    end
  end
end

def tool_graph(m, args)
  edges = args.empty? ? m.edges : collect_edges(m, args)
  puts 'digraph ninja {'
  puts 'rankdir="LR"'
  puts 'node [fontsize=10, shape=box, height=0.25]'
  puts 'edge [fontsize=10]'
  ids = {}
  getid = ->(x) { ids[x] ||= "n#{ids.length}" }
  edges.each do |e|
    eid = getid.call(e.object_id)
    puts %("#{eid}" [label="#{e.rule}", shape=ellipse])
    e.outputs.each do |o|
      oid = getid.call(o)
      puts %("#{oid}" [label="#{o}"])
      puts %("#{eid}" -> "#{oid}")
    end
    (e.inputs + e.implicit_inputs).each do |inp|
      iid = getid.call(inp)
      puts %("#{iid}" [label="#{inp}"])
      puts %("#{iid}" -> "#{eid}" [arrowhead=none])
    end
  end
  puts '}'
end

def tool_compdb(m, args, by_targets: false)
  if by_targets
    if args.empty? || args.include?('-h') || args.include?('--help')
      raise NinjaError, "compdb-targets expects the name of at least one target\nusage: ninja -t compdb [-hx] target [targets]\n\noptions:\n  -h     display this help message\n  -x     expand @rspfile style response file invocations"
    end
    args.delete('-x')
    edges = collect_edges(m, args)
  else
    args.delete('-x')
    rule_filter = args
    edges = m.edges.select { |e| rule_filter.empty? || rule_filter.include?(e.rule) }
  end
  db = []
  edges.each do |e|
    cmd = m.edge_var(e, 'command')
    next if cmd.empty?
    e.inputs.each do |inp|
      db << { directory: Dir.pwd, command: cmd, file: inp, output: e.outputs.first }
    end
  end
  puts pretty_json(db)
end

def json_escape(s)
  s.to_s.gsub(/["\\\b\f\n\r\t]/) do |c|
    { '"' => '\"', '\\' => '\\\\', "\b" => '\b', "\f" => '\f',
      "\n" => '\n', "\r" => '\r', "\t" => '\t' }[c]
  end
end

def pretty_json(rows)
  return "[]" if rows.empty?
  lines = ["["]
  rows.each_with_index do |row, idx|
    lines << "  {"
    keys = [:directory, :command, :file, :output]
    keys.each_with_index do |key, kidx|
      comma = kidx == keys.length - 1 ? "" : ","
      lines << "    \"#{key}\": \"#{json_escape(row[key])}\"#{comma}"
    end
    lines << "  }#{idx == rows.length - 1 ? '' : ','}"
  end
  lines << "]"
  lines.join("\n")
end

def tool_clean(m, opts, args)
  by_rule = nil
  if args[0] == '-r'
    by_rule = args[1..] || []
    args = []
  end
  edges = if by_rule
            m.edges.select { |e| by_rule.include?(e.rule) }
          elsif args.empty?
            m.edges
          else
            collect_edges(m, args)
          end
  count = 0
  edges.each do |e|
    e.outputs.each do |o|
      next unless File.exist?(o)
      puts "Remove #{o}" if opts[:verbose] || opts[:dry_run]
      FileUtils.rm_f(o) unless opts[:dry_run]
      count += 1
    end
  end
  puts "Cleaning... #{count} files."
end

def run_tool(m, opts)
  tool = opts[:tool]
  args = opts[:tool_args].dup
  case tool
  when 'list', nil then tool_list
  when 'rules' then tool_rules(m)
  when 'targets' then tool_targets(m, args)
  when 'commands' then tool_commands(m, args)
  when 'inputs' then tool_inputs(m, args)
  when 'multi-inputs' then tool_multi_inputs(m, args)
  when 'query' then tool_query(m, args)
  when 'graph' then tool_graph(m, args)
  when 'compdb' then tool_compdb(m, args)
  when 'compdb-targets' then tool_compdb(m, args, by_targets: true)
  when 'clean' then tool_clean(m, opts, args)
  when 'deps' then puts '.ninja_deps: deps log missing'
  when 'missingdeps' then puts 'Processed 0 nodes.'
  when 'recompact', 'restat', 'cleandead' then nil
  else
    raise NinjaError, "unknown tool '#{tool}'"
  end
end

begin
  opts, targets = parse_options(ARGV)
  if opts[:tool] == 'list'
    tool_list
    exit 1
  end
  manifest = load_manifest(opts[:file])
  if opts[:tool]
    run_tool(manifest, opts)
    exit 0
  end
  exit Runner.new(manifest, opts).run(targets)
rescue NinjaError => e
  $stderr.puts "ninja: error: #{e.message}"
  exit 1
rescue Errno::ENOENT => e
  $stderr.puts "ninja: error: #{e.message}"
  exit 1
end
