#!/usr/bin/env ruby
# frozen_string_literal: true

NBSP = "\u00a0"

def parse_datetime(text)
  return nil unless text =~ /\A(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})\z/

  Time.local(Regexp.last_match(1).to_i, Regexp.last_match(2).to_i, Regexp.last_match(3).to_i,
             Regexp.last_match(4).to_i, Regexp.last_match(5).to_i)
rescue ArgumentError
  nil
end

def date_key(t)
  t.year * 10_000 + t.month * 100 + t.day
end

def today_key
  date_key(Time.now)
end

def parse_date_key(text)
  return nil unless text =~ /\A(\d{4})-(\d{2})-(\d{2})\z/

  y = Regexp.last_match(1).to_i
  m = Regexp.last_match(2).to_i
  d = Regexp.last_match(3).to_i
  Time.local(y, m, d)
  y * 10_000 + m * 100 + d
rescue ArgumentError
  nil
end

def time_from_key(key)
  Time.local(key / 10_000, (key / 100) % 100, key % 100)
end

def shift_date_key(key, days)
  date_key(time_from_key(key) + days * 86_400)
end

def cwday(key)
  wday = time_from_key(key).wday
  wday.zero? ? 7 : wday
end

def format_date_key(key)
  format('%04d-%02d-%02d', key / 10_000, (key / 100) % 100, key % 100)
end

def month_start_key
  now = Time.now
  now.year * 10_000 + now.month * 100 + 1
end

class Activity
  attr_accessor :start_time, :end_time, :project, :description, :raw

  def initialize(start_time, end_time, project, description, raw = nil)
    @start_time = start_time
    @end_time = end_time
    @project = project
    @description = description
    @raw = raw
  end

  def running?
    @end_time.nil?
  end

  def duration(now = Time.now)
    ((@end_time || now) - @start_time).to_i
  end

  def to_log
    if running?
      "#{fmt_time(@start_time)} | #{@project} | #{@description}"
    else
      "#{fmt_time(@start_time)} - #{fmt_time(@end_time)} | #{@project} | #{@description}"
    end
  end

  def fmt_time(t)
    t.strftime('%Y-%m-%d %H:%M')
  end
end

def parse_time(text)
  parse_datetime(text)
end

def parse_line(line)
  raw = line.chomp
  case raw
  when /\A(\d{4}-\d{2}-\d{2} \d{2}:\d{2}) - (\d{4}-\d{2}-\d{2} \d{2}:\d{2}) \| (.*?) \| (.*)\z/
    s = parse_time($1)
    e = parse_time($2)
    return nil unless s && e
    Activity.new(s, e, $3, $4, raw)
  when /\A(\d{4}-\d{2}-\d{2} \d{2}:\d{2}) \| (.*?) \| (.*)\z/
    s = parse_time($1)
    return nil unless s
    Activity.new(s, nil, $2, $3, raw)
  else
    nil
  end
end

def file_path(opts)
  opts[:file] || ENV['BARTIB_FILE'] || begin
    warn 'Error: No file given. Use -f or set BARTIB_FILE.'
    exit 1
  end
end

def read_activities(path)
  File.readlines(path, chomp: true).map { |l| parse_line(l) }
rescue Errno::ENOENT => e
  warn "Error: Could not read from file: #{path}"
  warn
  warn 'Caused by:'
  warn "    #{e.message.sub(" @ rb_sysopen - #{path}", '')}"
  exit 1
end

def valid_activities(path)
  read_activities(path).compact
end

def write_activities(path, activities)
  File.open(path, 'w') do |f|
    activities.each { |a| f.puts a.to_log }
  end
end

def today
  today_key
end

def at_time(hhmm)
  if hhmm
    unless hhmm.match?(/\A\d{1,2}:\d{2}\z/)
      warn "Error: Invalid time: #{hhmm}"
      exit 1
    end
    h, m = hhmm.split(':').map(&:to_i)
    now = Time.now
    Time.local(now.year, now.month, now.day, h, m)
  else
    Time.now
  end
rescue ArgumentError
  warn "Error: Invalid time: #{hhmm}"
  exit 1
end

def fmt_time(t)
  t.strftime('%Y-%m-%d %H:%M')
end

def fmt_duration(seconds)
  mins = [(seconds / 60.0).round, 0].max
  h = mins / 60
  m = mins % 60
  h.positive? ? format('%dh %02dm', h, m) : "#{m}m"
end

def stop_running(activities, time, out: true)
  activities.select(&:running?).each do |a|
    a.end_time = time
    puts "Stopped activity: \"#{a.description}\" (#{a.project}) started at #{fmt_time(a.start_time)} (#{fmt_duration(a.duration)})" if out
  end
end

def parse_global(argv)
  opts = {}
  rest = []
  i = 0
  while i < argv.length
    case argv[i]
    when '-f'
      opts[:file] = argv[i + 1]
      i += 2
    when '--help', '-h'
      print_main_help
      exit 0
    when '--version', '-V'
      puts 'bartib 1.1.0'
      exit 0
    else
      rest = argv[i..]
      break
    end
  end
  [opts, rest || []]
end

def option_hash(args, spec = {})
  opts = {}
  rest = []
  i = 0
  while i < args.length
    a = args[i]
    if a == '-h' || a == '--help'
      opts[:help] = true
      i += 1
    elsif %w[-d --date].include?(a) && spec[:date]
      opts[:date] = parse_date_key(args[i + 1])
      i += 2
    elsif a == '--no-quotes' || (a == '-n' && spec[:projects])
      opts[:no_quotes] = true
      i += 1
    elsif %w[-d --description].include?(a)
      opts[:description] = args[i + 1]
      i += 2
    elsif %w[-p --project].include?(a)
      opts[:project] = args[i + 1]
      i += 2
    elsif %w[-t --time].include?(a)
      opts[:time] = args[i + 1]
      i += 2
    elsif %w[-n --number].include?(a)
      opts[:number] = args[i + 1].to_i
      i += 2
    elsif %w[-e --editor].include?(a)
      opts[:editor] = args[i + 1]
      i += 2
    elsif a == '--from'
      opts[:from] = parse_date_key(args[i + 1])
      i += 2
    elsif a == '--to'
      opts[:to] = parse_date_key(args[i + 1])
      i += 2
    elsif a == '--today'
      opts[:from] = opts[:to] = today
      i += 1
    elsif a == '--yesterday'
      opts[:from] = opts[:to] = shift_date_key(today, -1)
      i += 1
    elsif a == '--current_week'
      d = today
      opts[:from] = shift_date_key(d, -(cwday(d) - 1))
      opts[:to] = shift_date_key(opts[:from], 6)
      i += 1
    elsif a == '--last_week'
      d = shift_date_key(today, -7)
      opts[:from] = shift_date_key(d, -(cwday(d) - 1))
      opts[:to] = shift_date_key(opts[:from], 6)
      i += 1
    elsif a == '--no_grouping'
      opts[:no_grouping] = true
      i += 1
    elsif a == '--round'
      opts[:round] = args[i + 1]
      i += 2
    elsif a == '--current' || a == '-c'
      opts[:current] = true
      i += 1
    else
      rest << a
      i += 1
    end
  end
  [opts, rest]
end

def filter_activities(activities, opts)
  from = opts[:date] || opts[:from]
  to = opts[:date] || opts[:to]
  selected = activities
  selected = selected.select { |a| a.project == opts[:project] } if opts[:project]
  selected = selected.select { |a| date_key(a.start_time) >= from } if from
  selected = selected.select { |a| date_key(a.start_time) <= to } if to
  selected
end

def underline(s)
  "\e[4m#{s}\e[0m"
end

def bold(s)
  "\e[1m#{s}\e[0m"
end

def table(rows, headers)
  widths = headers.map.with_index { |h, i| ([h.length] + rows.map { |r| r[i].to_s.length }).max }
  puts
  puts headers.each_with_index.map { |h, i| underline(h.ljust(widths[i]).tr(' ', NBSP)) }.join(' ') + ' '
  rows.each do |r|
    puts r.each_with_index.map { |c, i| c.to_s.ljust(widths[i]).tr(' ', NBSP) }.join(' ') + ' '
  end
  puts
end

def recent_unique(activities)
  seen = {}
  out = []
  activities.reverse_each do |a|
    key = [a.description, a.project]
    next if seen[key]
    seen[key] = true
    out << a
  end
  out
end

def print_last(activities, number = 10, term = nil)
  all = recent_unique(activities).reverse
  all = all.select { |a| a.description.include?(term) || a.project.include?(term) } if term && !term.empty?
  shown = all.last(number)
  offset = all.length - shown.length
  rows = shown.each_with_index.map do |a, idx|
    actual = all.length - 1 - (offset + idx)
    ["[#{actual}]", a.description, a.project]
  end
  table(rows, [' # ', 'Description', 'Project'])
end

def list_rows(activities, full_date: false)
  activities.map do |a|
    s = full_date ? fmt_time(a.start_time) : a.start_time.strftime('%H:%M')
    e = a.end_time ? a.end_time.strftime('%H:%M') : ''
    [s, e, a.description, a.project, fmt_duration(a.duration)]
  end
end

def print_list(activities, opts)
  activities = filter_activities(activities, opts)
  activities = activities.last(opts[:number]) if opts[:number] && opts[:number].positive?
  if activities.empty?
    puts 'No activity to display'
    return
  end
  if opts[:no_grouping]
    table(list_rows(activities, full_date: true), ['Started', 'Stopped', 'Description', 'Project', 'Duration'])
  elsif opts[:from] == opts[:to] || opts[:date]
    table(list_rows(activities), ['Started', 'Stopped', 'Description', 'Project', 'Duration'])
  else
    puts
    puts [underline('Started'), underline('Stopped'), underline('Description'), underline('Project'), underline('Duration')].join(' ') + ' '
    activities.group_by { |a| date_key(a.start_time) }.each do |date, rows|
      puts
      puts bold("#{format_date_key(date)}\t#{fmt_duration(rows.sum(&:duration))}")
      list_rows(rows).each { |r| puts r.map { |c| c.to_s.ljust(10).tr(' ', NBSP) }.join(' ') + ' ' }
    end
    puts
  end
end

def print_report(activities, opts)
  activities = filter_activities(activities, opts).reject(&:running?)
  if activities.empty?
    puts 'No activity to display'
    return
  end
  max_project = (activities.map { |a| a.project.length }.max || 5) + 9
  max_desc = activities.map { |a| a.description.length }.max || 5
  total = 0
  puts
  activities.group_by(&:project).sort.each do |project, acts|
    ptotal = acts.sum(&:duration)
    total += ptotal
    puts bold("#{project.ljust(max_project, '.')} #{fmt_duration(ptotal)}")
    acts.group_by(&:description).sort.each do |desc, ds|
      puts "    #{desc.ljust(max_desc, '.')} #{fmt_duration(ds.sum(&:duration))}"
    end
    puts
  end
  puts bold("#{'Total'.ljust(max_project, '.')} #{fmt_duration(total)}")
  puts
end

def print_main_help
  puts <<~HELP
    bartib 1.1.0
    Nikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>
    A simple timetracker

    USAGE:
        executable [OPTIONS] <SUBCOMMAND>

    FLAGS:
        -h, --help       Prints help information
        -V, --version    Prints version information

    OPTIONS:
        -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]

    SUBCOMMANDS:
        cancel      cancels all currently running activities
        change      changes the current activity
        check       checks file and reports parsing errors
        continue    continues a previous activity
        current     lists all currently running activities
        edit        opens the activity log in an editor
        help        Prints this message or the help of the given subcommand(s)
        last        displays the descriptions and projects of recent activities
        list        list recent activities
        projects    list all projects
        report      reports duration of tracked activities
        sanity      checks sanity of bartib log
        search      search for existing descriptions and projects
        start       starts a new activity
        status      shows current status and time reports for today, current week, and current month
        stop        stops all currently running activities
  HELP
end

def simple_help(cmd)
  texts = {
    'start' => "executable-start \nstarts a new activity\n\nUSAGE:\n    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>\n",
    'stop' => "executable-stop \nstops all currently running activities\n\nUSAGE:\n    executable stop [OPTIONS]\n",
    'list' => "executable-list \nlist recent activities\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]\n",
    'report' => "executable-report \nreports duration of tracked activities\n\nUSAGE:\n    executable report [FLAGS] [OPTIONS]\n"
  }
  puts(texts[cmd] || "executable-#{cmd} \n\nUSAGE:\n    executable #{cmd}")
end

global, argv = parse_global(ARGV)
cmd = argv.shift
if cmd.nil? || cmd == 'help'
  if argv && argv[0]
    simple_help(argv[0])
  else
    print_main_help
  end
  exit 0
end

if argv.include?('-h') || argv.include?('--help')
  simple_help(cmd)
  exit 0
end

path = file_path(global)

case cmd
when 'start'
  opts, = option_hash(argv)
  unless opts[:description] && opts[:project]
    warn 'error: The following required arguments were not provided:'
    warn '    --description <DESCRIPTION>'
    warn '    --project <PROJECT>'
    exit 1
  end
  activities = File.exist?(path) ? valid_activities(path) : []
  t = at_time(opts[:time])
  stop_running(activities, t)
  a = Activity.new(t, nil, opts[:project], opts[:description])
  activities << a
  write_activities(path, activities)
  puts "Started activity: \"#{a.description}\" (#{a.project}) at #{fmt_time(t)}"
when 'stop'
  opts, = option_hash(argv)
  activities = valid_activities(path)
  running = activities.any?(&:running?)
  stop_running(activities, at_time(opts[:time]))
  write_activities(path, activities)
  puts 'No Activity is currently running' unless running
when 'cancel'
  activities = valid_activities(path)
  running = activities.select(&:running?)
  running.each { |a| puts "Canceled activity: \"#{a.description}\" (#{a.project}) started at #{fmt_time(a.start_time)}" }
  write_activities(path, activities.reject(&:running?))
when 'change'
  opts, = option_hash(argv)
  activities = valid_activities(path)
  desc = opts[:description]
  proj = opts[:project]
  time = at_time(opts[:time])
  activities.reject!(&:running?)
  last = activities.last
  desc ||= last&.description || ''
  proj ||= last&.project || ''
  a = Activity.new(time, nil, proj, desc)
  activities << a
  write_activities(path, activities)
  puts "Changed activity: \"#{a.description}\" (#{a.project}) started at #{fmt_time(a.start_time)}"
when 'continue'
  opts, rest = option_hash(argv)
  activities = valid_activities(path)
  choices = recent_unique(activities)
  idx = (rest[0] || '0').to_i
  chosen = choices[idx] || choices[0]
  unless chosen || (opts[:description] && opts[:project])
    warn 'No activity to continue'
    exit 1
  end
  t = at_time(opts[:time])
  stop_running(activities, t)
  desc = opts[:description] || chosen.description
  proj = opts[:project] || chosen.project
  a = Activity.new(t, nil, proj, desc)
  activities << a
  write_activities(path, activities)
  puts "Started activity: \"#{a.description}\" (#{a.project}) at #{fmt_time(t)}"
when 'current'
  running = valid_activities(path).select(&:running?)
  if running.empty?
    puts 'No Activity is currently running'
  else
    table(running.map { |a| [fmt_time(a.start_time), a.description, a.project, fmt_duration(a.duration)] },
          ['Started At', 'Description', 'Project', 'Duration'])
  end
when 'last'
  opts, = option_hash(argv)
  print_last(valid_activities(path), opts[:number] || 10)
when 'search'
  print_last(valid_activities(path), 10_000, argv.join(' '))
when 'projects'
  opts, = option_hash(argv, projects: true)
  acts = valid_activities(path)
  acts = acts.select(&:running?) if opts[:current]
  acts.map(&:project).uniq.sort.each { |p| puts(opts[:no_quotes] ? p : "\"#{p}\"") }
when 'list'
  opts, = option_hash(argv, date: true)
  print_list(valid_activities(path), opts)
when 'report'
  opts, = option_hash(argv, date: true)
  print_report(valid_activities(path), opts)
when 'check'
  lines = File.readlines(path, chomp: true)
  bad = lines.each_with_index.select { |l, _i| parse_line(l).nil? }
  if bad.empty?
    puts 'All lines in the file have been successfully parsed as activities.'
  else
    bad.each { |l, i| puts "Line #{i + 1} could not be parsed: #{l}" }
    exit 1
  end
when 'sanity'
  acts = valid_activities(path)
  bad = acts.select { |a| a.end_time && a.end_time < a.start_time }
  if bad.empty?
    puts 'No unusual activities.'
  else
    bad.each { |a| puts "Unusual activity: #{a.to_log}" }
    exit 1
  end
when 'status'
  opts, = option_hash(argv)
  acts = valid_activities(path)
  acts = acts.select { |a| a.project == opts[:project] } if opts[:project]
  current = acts.select(&:running?)
  d = today
  week_start = shift_date_key(d, -(cwday(d) - 1))
  month_start = month_start_key
  sum = ->(from) { acts.reject(&:running?).select { |a| date_key(a.start_time) >= from && date_key(a.start_time) <= d }.sum(&:duration) }
  puts "\e[2m\n =======\e[0m\e[3m Status for \e[0m\e[1m#{opts[:project] || 'ALL'}\e[0m\e[3m projects \e[0m\e[2m ======= \n\e[0m"
  if current.empty?
    puts "\e[2;3m  NOW: \e[0m\e[1m NO Activity\n\e[0m"
  else
    current.each { |a| puts "\e[2;3m  NOW: \e[0m\e[1m#{a.description} (#{a.project}) #{fmt_duration(a.duration)}\e[0m" }
  end
  puts "\e[2;3m Today......................... \e[0m\e[1m#{fmt_duration(sum.call(d))}\e[0m"
  puts "\e[2;3m Current week.................. \e[0m\e[1m#{fmt_duration(sum.call(week_start))}\e[0m"
  puts "\e[2;3m Current month................. \e[0m\e[1m#{fmt_duration(sum.call(month_start))}\e[0m"
when 'edit'
  opts, = option_hash(argv)
  editor = opts[:editor] || ENV['EDITOR']
  if editor.nil? || editor.empty?
    warn 'Error: No editor configured.'
    exit 1
  end
  system(editor, path)
else
  warn "error: Found argument '#{cmd}' which wasn't expected, or isn't valid in this context"
  warn
  warn 'USAGE:'
  warn '    executable [OPTIONS] <SUBCOMMAND>'
  exit 1
end
