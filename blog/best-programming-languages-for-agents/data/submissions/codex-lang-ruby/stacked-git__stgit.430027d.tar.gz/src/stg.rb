#!/usr/bin/env ruby
# frozen_string_literal: true

require 'yaml'
require 'fileutils'
require 'shellwords'
require 'English'

class Stg
  KNOWN_COMMANDS = %w[
    diff files id log name show edit fold new refresh rename spill sync email export
    next patches prev series top branch clean commit delete float goto hide import init
    pick pop pull push rebase redo repair reset sink squash uncommit undo unhide
    completion version add mv resolved rm status
  ].freeze

  VERSION_TEXT = <<~TXT
    Stacked Git 2.5.5
    Copyright (C) 2005-2025 StGit authors
    This is free software: you are free to change and redistribute it.
    There is NO WARRANTY, to the extent permitted by law.
    SPDX-License-Identifier: GPL-2.0-only
    git version 2.34.1
  TXT

  MAIN_HELP = <<~TXT
    Maintain a stack of patches on top of a Git branch.

    Usage: stg [OPTIONS] <command> [...]
           stg [OPTIONS] <-h|--help>
           stg --version

    Patch inspection commands:
      diff   Show a diff
      files  Show files modified by a patch
      id     Print git hash of a StGit revision
      log    Display or optionally clear the stack changelog
      name   Print patch name of a StGit revision
      show   Show patch commits

    Patch manipulation commands:
      edit     Edit a patch
      fold     Fold diff file into the current patch
      new      Create a new patch at top of the stack
      refresh  Incorporate worktree changes into current patch
      rename   Rename a patch
      spill    Spill changes from the topmost patch
      sync     Synchronize patches with a branch or a series

    Stack inspection commands:
      email    Format and send patches as email
      export   Export patches to a directory
      next     Print the name of the next patch
      patches  Show patches that modify files
      prev     Print the name of the previous patch
      series   Display the patch series
      top      Print the name of the top patch

    Stack manipulation commands:
      branch    Branch operations: switch, list, create, rename, delete, ...
      clean     Delete empty patches from the series
      commit    Finalize patches to the stack base
      delete    Delete patches
      float     Push patches to the top, even if applied
      goto      Go to patch by pushing or popping as necessary
      hide      Hide patches in the series
      import    Import patches to stack
      init      Initialize a StGit stack on a branch
      pick      Import a patch from another branch or a commit object
      pop       Pop (unapply) one or more applied patches
      pull      Pull changes from a remote repository
      push      Push (apply) one or more unapplied patches
      rebase    Move the stack base to another point in history
      redo      Undo the last command
      repair    Repair stack after branch is modified with git commands
      reset     Reset the patch stack to an earlier state
      sink      Move patches deeper in the stack
      squash    Squash two or more patches into one
      uncommit  Convert regular Git commits into StGit patches
      undo      Undo the last command
      unhide    Unhide hidden patches

    Administration commands:
      completion  Support for shell completions
      version     Print version information and exit

    Aliases:
      add       Alias for shell command `git -C "$GIT_PREFIX" add`
      mv        Alias for shell command `git -C "$GIT_PREFIX" mv`
      resolved  Alias for shell command `git -C "$GIT_PREFIX" add`
      rm        Alias for shell command `git -C "$GIT_PREFIX" rm`
      status    Alias for shell command `git status -s`

    Help:
      help  Print this message or the help of the given subcommand(s)

    Options:
          --version       Print version information
      -C <path>           Run as if started in <path>
          --color <when>  When to colorize output: auto, always, ansi, never
      -h, --help          Print help (see more with '--help')
  TXT

  HELP = {
    'version' => "Print version information and exit\n\nUsage: stg version [OPTIONS]\n\nOptions:\n  -s, --short   Show abbreviated version information\n  -h, --help    Print help\n",
    'init' => "Initialize a StGit stack on a branch.\n\nUsage: stg init [OPTIONS]\n\nOptions:\n  -b, --branch <branch>  Use <branch> instead of current branch\n  -h, --help             Print help\n",
    'new' => "Create a new, empty patch on the current stack.\n\nUsage: stg new [OPTIONS] [patchname] [-- <path>...]\n\nOptions:\n  -n, --name <name>       Name for new patch\n  -r, --refresh           Refresh the new patch with work tree changes\n  -i, --index             Use the current contents of the index\n  -m, --message <message> Use message instead of invoking the editor\n  -f, --file <path>       Use the contents of file\n  -h, --help              Print help\n",
    'series' => "Show all the patches in the series.\n\nUsage: stg series [OPTIONS] [patch]...\n\nOptions:\n  -a, --all        Select all patches\n  -A, --applied    Select the applied patches only\n  -U, --unapplied  Select the unapplied patches only\n  -s, --short[=n]  Select patches around the topmost patch only\n  -c, --count      Display the number of selected patches and exit\n  -P, --no-prefix  Do not display the patch status prefix\n  -r, --reverse    Display patches in reverse order\n  -h, --help       Print help\n",
    'top' => "Print the name of the top patch.\n\nUsage: stg top [OPTIONS]\n",
    'next' => "Print the name of the next patch.\n\nUsage: stg next [OPTIONS]\n",
    'prev' => "Print the name of the previous patch.\n\nUsage: stg prev [OPTIONS]\n",
    'push' => "Push one or more unapplied patches from the series onto the stack.\n\nUsage: stg push [OPTIONS] [patch]...\n       stg push [OPTIONS] -n <number>\n       stg push [OPTIONS] --all\n",
    'pop' => "Pop (unapply) one or more applied patches.\n\nUsage: stg pop [OPTIONS] [patch]...\n       stg pop [OPTIONS] --all\n       stg pop [OPTIONS] -n <number>\n",
    'refresh' => "Include the latest work tree and index changes in the current patch.\n\nUsage: stg refresh [OPTIONS] [path]...\n",
    'delete' => "Delete patches\n\nUsage: stg delete [OPTIONS] [<patch>...]\n       stg delete [OPTIONS] --all\n       stg delete [OPTIONS] --top\n",
    'rename' => "Rename [old-patch] to <new-patch>.\n\nUsage: stg rename [OPTIONS] [old-patch] <new-patch>\n",
    'files' => "Show the files modified by a patch.\n\nUsage: stg files [OPTIONS] [revision]\n",
    'diff' => "Show the diff between revisions or the work tree and HEAD.\n\nUsage: stg diff [OPTIONS] [path]...\n",
    'show' => "Show the commit log and diff corresponding to the given patches.\n\nUsage: stg show [OPTIONS] [patch-or-rev]...\n",
    'id' => "Print the hash (object id) of a StGit revision.\n\nUsage: stg id [OPTIONS] [revision]\n",
    'name' => "Print the patch name of a StGit revision.\n\nUsage: stg name [OPTIONS] [revision]\n",
    'branch' => "Create, clone, switch, rename, or delete StGit-enabled branches.\n\nUsage: stg branch\n       stg branch [--merge] <branch>\n       stg branch {--list,-l}\n       stg branch {--create,-c} <new-branch> [committish]\n"
  }.freeze

  def initialize(argv)
    @argv = argv.dup
  end

  def main
    preprocess_global_options
    return puts(MAIN_HELP), exit(0) if @argv == ['--help'] || @argv == ['-h']
    return version(@argv[1..] || []) if @argv.first == '--version'
    return puts(MAIN_HELP), exit(1) if @argv.empty?

    cmd = @argv.shift
    if @argv.include?('--help') || @argv.include?('-h')
      return help(cmd)
    end

    case cmd
    when 'help' then help(@argv.shift)
    when 'version' then version(@argv)
    when 'add' then exec_git(['add'] + @argv)
    when 'resolved' then exec_git(['add'] + @argv)
    when 'rm' then exec_git(['rm'] + @argv)
    when 'mv' then exec_git(['mv'] + @argv)
    when 'status' then exec_git(['status', '-s'] + @argv)
    when 'init' then init_cmd(@argv)
    when 'new' then new_cmd(@argv)
    when 'series' then series_cmd(@argv)
    when 'top' then top_cmd
    when 'next' then next_cmd
    when 'prev' then prev_cmd
    when 'push' then push_cmd(@argv)
    when 'pop' then pop_cmd(@argv)
    when 'refresh' then refresh_cmd(@argv)
    when 'delete' then delete_cmd(@argv)
    when 'rename' then rename_cmd(@argv)
    when 'files' then files_cmd(@argv)
    when 'diff' then diff_cmd(@argv)
    when 'show' then show_cmd(@argv)
    when 'id' then id_cmd(@argv)
    when 'name' then name_cmd(@argv)
    when 'branch' then branch_cmd(@argv)
    when 'patches' then patches_cmd(@argv)
    when 'spill' then pop_cmd(['--spill'])
    when 'clean' then clean_cmd
    when 'commit' then commit_cmd(@argv)
    when 'uncommit' then uncommit_cmd(@argv)
    when 'goto' then goto_cmd(@argv)
    when 'float' then float_cmd(@argv)
    when 'sink' then sink_cmd(@argv)
    when 'pick' then pick_cmd(@argv)
    when 'pull' then exec_git(['pull'] + @argv)
    when 'log' then exec_git(%w[log --oneline --decorate --all])
    when 'hide' then hide_cmd(@argv)
    when 'unhide' then unhide_cmd(@argv)
    when 'undo', 'redo', 'repair', 'rebase', 'reset'
      warn "error: #{cmd} is not available in this reimplementation"
      exit 2
    when 'completion' then exit(0)
    else
      warn "error: unrecognized subcommand '#{cmd}'"
      warn
      warn "Usage: stg [OPTIONS] <command> [...]"
      warn "       stg [OPTIONS] <-h|--help>"
      warn "       stg --version"
      warn
      warn "For more information, try '--help'."
      exit 1
    end
  rescue Interrupt
    exit 130
  rescue RuntimeError => e
    warn e.message
    exit 2
  end

  def preprocess_global_options
    out = []
    i = 0
    while i < @argv.length
      case @argv[i]
      when '-C'
        dir = @argv[i + 1] or raise 'error: a value is required for -C <path>'
        Dir.chdir(dir)
        i += 2
      when /^--color(=|$)/
        i += @argv[i] == '--color' ? 2 : 1
      else
        out += @argv[i..]
        break
      end
    end
    @argv = out
  end

  def help(cmd)
    if cmd.nil?
      puts MAIN_HELP
    elsif HELP[cmd]
      puts HELP[cmd]
    elsif KNOWN_COMMANDS.include?(cmd)
      puts "#{cmd} command\n\nUsage: stg #{cmd} [OPTIONS] [...]\n\nOptions:\n  -h, --help    Print help\n"
    else
      warn "error: unrecognized subcommand '#{cmd}'"
      exit 1
    end
  end

  def version(args)
    if args.include?('-s') || args.include?('--short')
      puts 'stg 2.5.5'
    else
      print VERSION_TEXT
    end
  end

  def git_dir
    @git_dir ||= capture(%w[git rev-parse --git-dir]).strip
  end

  def branch
    capture(%w[git symbolic-ref --quiet --short HEAD]).strip
  rescue RuntimeError
    'HEAD'
  end

  def state_path(br = branch)
    File.join(git_dir, 'stg-ruby', "#{br.gsub(%r{[/.]}, '_')}.json")
  end

  def default_state
    { 'base' => capture(%w[git rev-parse HEAD]).strip, 'applied' => [], 'unapplied' => [], 'hidden' => [] }
  end

  def state
    @state ||= begin
      path = state_path
      File.exist?(path) ? YAML.load_file(path) : default_state
    end
  end

  def save
    path = state_path
    FileUtils.mkdir_p(File.dirname(path))
    File.write(path, YAML.dump(state))
  end

  def init_cmd(args)
    br = option_value(args, '-b', '--branch') || branch
    path = state_path(br)
    return if File.exist?(path)

    FileUtils.mkdir_p(File.dirname(path))
    File.write(path, YAML.dump(default_state))
  end

  def new_cmd(args)
    name = nil
    msg = nil
    file = nil
    refresh = false
    index = false
    paths = []
    i = 0
    while i < args.length
      a = args[i]
      case a
      when '-n', '--name' then name = args[i += 1]
      when '-m', '--message' then msg = args[i += 1]
      when '-f', '--file' then file = args[i += 1]
      when '-r', '--refresh' then refresh = true
      when '-i', '--index' then index = true
      when '--'
        paths = args[(i + 1)..] || []
        refresh = true unless paths.empty?
        break
      when /^-/
      else
        name ||= a
      end
      i += 1
    end
    msg ||= read_message(file) if file
    if msg.nil?
      warn 'hint: Waiting for your editor to close the file...'
      warn 'error: problem with the editor `vi`'
      exit 2
    end
    name ||= sanitize_name(msg.lines.first.to_s.strip)
    validate_patch_name(name)
    ensure_unique(name)

    run_git_add(paths) if refresh && !index
    run(%w[git commit -q --allow-empty] + message_args(msg))
    commit = capture(%w[git rev-parse HEAD]).strip
    state['applied'] << patch(name, commit)
    save
    puts "> #{name} (new)"
  end

  def series_cmd(args)
    sel = all_patches
    prefix = true
    count = false
    reverse = false
    only = nil
    show_commit = false
    show_desc = false
    args.each_with_index do |a, idx|
      case a
      when '-A', '--applied' then only = 'applied'
      when '-U', '--unapplied' then only = 'unapplied'
      when '-H', '--hidden' then only = 'hidden'
      when '-c', '--count' then count = true
      when '-P', '--no-prefix' then prefix = false
      when '-r', '--reverse' then reverse = true
      when /^--commit-id/, '-i' then show_commit = true
      when '-d', '--description' then show_desc = true
      when '--all', '-a' then only = nil
      when /^-/
      else
        sel = sel.select { |p| p['name'] == a }
        raise "error: patch `#{a}` does not exist" if sel.empty?
      end
    end
    sel = state[only] || [] if only
    sel = sel.reverse if reverse
    return puts(sel.length) if count

    sel.each { |p| puts format_patch_line(p, prefix, show_commit, show_desc) }
  end

  def top_cmd
    raise 'error: no patches applied' if state['applied'].empty?
    puts state['applied'].last['name']
  end

  def next_cmd
    raise 'error: no unapplied patches' if state['unapplied'].empty?
    puts state['unapplied'].first['name']
  end

  def prev_cmd
    raise 'error: not enough patches applied' if state['applied'].length < 2
    puts state['applied'][-2]['name']
  end

  def push_cmd(args)
    targets = select_unapplied(args)
    raise 'error: no unapplied patches' if targets.empty?
    targets.each do |p|
      state['unapplied'].delete(p)
      ok = system('git', 'cherry-pick', '--allow-empty', p['commit'], out: File::NULL)
      unless ok
        warn "error: could not push patch `#{p['name']}`"
        save
        exit 2
      end
      p['commit'] = capture(%w[git rev-parse HEAD]).strip
      state['applied'] << p
      puts "> #{p['name']}"
    end
    save
  end

  def pop_cmd(args)
    spill = args.include?('-s') || args.include?('--spill')
    targets = select_applied(args)
    raise 'error: no patches applied' if targets.empty?
    count = targets.length
    unless targets == state['applied'].last(count)
      raise 'error: can only pop topmost patches in this implementation'
    end
    popped = state['applied'].pop(count)
    if spill
      run(%W[git reset --mixed HEAD~#{count}])
    else
      run(%W[git reset --hard -q HEAD~#{count}])
    end
    state['unapplied'] = popped + state['unapplied']
    save
    popped.reverse_each { |p| puts "- #{p['name']}" }
  end

  def refresh_cmd(args)
    raise 'error: no patches applied' if state['applied'].empty?
    msg = nil
    file = nil
    index = false
    paths = []
    i = 0
    while i < args.length
      case args[i]
      when '-m', '--message' then msg = args[i += 1]
      when '-f', '--file' then file = args[i += 1]
      when '-i', '--index' then index = true
      when /^-/
      else paths << args[i]
      end
      i += 1
    end
    msg ||= read_message(file) if file
    run_git_add(paths) unless index
    if clean_index?
      return
    end
    cmd = %w[git commit -q --amend --allow-empty]
    cmd += msg ? message_args(msg) : ['--no-edit']
    run(cmd)
    state['applied'].last['commit'] = capture(%w[git rev-parse HEAD]).strip
    save
  end

  def delete_cmd(args)
    if args.include?('--all') || args.include?('-a')
      n = state['applied'].length
      run(%W[git reset --hard -q HEAD~#{n}]) if n.positive?
      state['applied'] = []
      state['unapplied'] = []
      save
      return
    end
    targets = args.reject { |a| a.start_with?('-') }
    targets = [state['applied'].last&.dig('name')].compact if args.include?('--top') || args.include?('-t') || targets.empty?
    targets.each do |name|
      if state['applied'].last && state['applied'].last['name'] == name
        state['applied'].pop
        run(%w[git reset --hard -q HEAD~1])
      elsif (p = state['unapplied'].find { |x| x['name'] == name })
        state['unapplied'].delete(p)
      else
        raise "error: patch `#{name}` does not exist"
      end
    end
    save
  end

  def rename_cmd(args)
    names = args.reject { |a| a.start_with?('-') }
    raise 'error: too few arguments' if names.empty?
    new_name = names.pop
    old_name = names.pop || state['applied'].last&.dig('name')
    raise 'error: no patches applied' unless old_name
    validate_patch_name(new_name)
    ensure_unique(new_name)
    p = find_patch(old_name) or raise "error: patch `#{old_name}` does not exist"
    p['name'] = new_name
    save
  end

  def files_cmd(args)
    stat = args.delete('--stat') || args.delete('-s')
    bare = args.delete('--bare')
    rev = resolve_rev(args.reject { |a| a.start_with?('-') }.first)
    cmd = %w[git diff-tree --no-commit-id -r]
    cmd << '--stat' if stat
    cmd << '--name-only' unless stat
    cmd << rev
    exec_git_raw(cmd[1..])
  end

  def diff_cmd(args)
    stat = args.delete('--stat') || args.delete('-s')
    range = nil
    paths = []
    i = 0
    while i < args.length
      if ['-r', '--range'].include?(args[i])
        range = args[i += 1]
      elsif args[i] == '--'
        paths += args[(i + 1)..] || []
        break
      elsif args[i].start_with?('-')
      else
        paths << args[i]
      end
      i += 1
    end
    cmd = ['diff']
    cmd << '--stat' if stat
    if range
      a, b = range.split('..', 2)
      cmd << resolve_rev(a) unless a.nil? || a.empty?
      cmd << resolve_rev(b) unless b.nil? || b.empty?
    else
      cmd << 'HEAD'
    end
    cmd << '--' unless paths.empty?
    cmd += paths
    exec_git(cmd)
  end

  def show_cmd(args)
    stat = args.delete('--stat') || args.delete('-s')
    revs = args.reject { |a| a.start_with?('-') }
    revs = [state['applied'].last ? state['applied'].last['name'] : 'HEAD'] if revs.empty?
    cmd = ['show']
    cmd << '--stat' if stat
    cmd += revs.map { |r| resolve_rev(r) }
    exec_git(cmd)
  end

  def id_cmd(args)
    rev = args.reject { |a| a.start_with?('-') }.first
    puts resolve_rev(rev)
  end

  def name_cmd(args)
    showbranch = args.delete('--showbranch')
    rev = args.reject { |a| a.start_with?('-') }.first || 'HEAD'
    oid = capture(['git', 'rev-parse', resolve_rev(rev)]).strip
    p = all_patches.find { |x| x['commit'].start_with?(oid) || capture(['git', 'rev-parse', x['commit']]).strip == oid rescue false }
    raise "error: cannot find patch for #{rev}" unless p
    puts(showbranch ? "#{branch}:#{p['name']}" : p['name'])
  end

  def branch_cmd(args)
    return puts(branch) if args.empty?
    if args.include?('-l') || args.include?('--list')
      current = branch
      branches = capture(%w[git for-each-ref --format=%(refname:short) refs/heads]).lines.map(&:strip)
      branches.each { |b| puts "#{b == current ? '>' : ' '} #{File.exist?(state_path(b)) ? 's' : ' '} \t#{b}  |" }
    elsif (idx = args.index('-c') || args.index('--create'))
      br = args[idx + 1] or raise 'error: branch name required'
      start = args[idx + 2] || 'HEAD'
      run(['git', 'checkout', '-q', '-b', br, start])
      @state = nil
      init_cmd([])
    elsif (idx = args.index('-r') || args.index('--rename'))
      rest = args[(idx + 1)..]
      run(['git', 'branch', '-m'] + rest)
    elsif args.include?('-D') || args.include?('--delete')
      br = args.reject { |a| a.start_with?('-') }.first || branch
      run(['git', 'branch', '-D', br])
    else
      run(['git', 'checkout', '-q', args.last])
    end
  end

  def patches_cmd(args)
    paths = args.reject { |a| a.start_with?('-') }
    state['applied'].each do |p|
      files = capture(%W[git diff-tree --no-commit-id --name-only -r #{p['commit']}]).lines.map(&:strip)
      puts p['name'] if paths.empty? ? !files.empty? : (files & paths).any?
    end
  end

  def hide_cmd(args)
    names = args.reject { |a| a.start_with?('-') }
    names.each do |n|
      p = state['unapplied'].find { |x| x['name'] == n } or raise "error: patch `#{n}` does not exist"
      state['unapplied'].delete(p)
      state['hidden'] << p
    end
    save
  end

  def unhide_cmd(args)
    names = args.reject { |a| a.start_with?('-') }
    names = state['hidden'].map { |p| p['name'] } if names.empty?
    names.each do |n|
      p = state['hidden'].find { |x| x['name'] == n } or raise "error: patch `#{n}` does not exist"
      state['hidden'].delete(p)
      state['unapplied'] << p
    end
    save
  end

  def clean_cmd
    before = state['applied'].length + state['unapplied'].length
    state['applied'].reject! { |p| empty_commit?(p['commit']) }
    state['unapplied'].reject! { |p| empty_commit?(p['commit']) }
    save if before != state['applied'].length + state['unapplied'].length
  end

  def commit_cmd(args)
    n = state['applied'].length
    state['base'] = capture(%w[git rev-parse HEAD]).strip
    state['applied'] = []
    save
    puts "Committed #{n} patches" if n.positive?
  end

  def uncommit_cmd(args)
    count = 1
    if (idx = args.index('-n') || args.index('--number'))
      count = args[idx + 1].to_i
    elsif !args.empty? && args.last =~ /^\d+$/
      count = args.last.to_i
    end
    init_cmd([])
    commits = capture(%W[git rev-list --reverse --max-count=#{count} HEAD]).lines.map(&:strip)
    commits.each do |c|
      name = sanitize_name(capture(%W[git log -1 --format=%s #{c}]).strip)
      name = unique_name(name)
      state['applied'] << patch(name, c)
    end
    save
  end

  def goto_cmd(args)
    target = args.reject { |a| a.start_with?('-') }.first or raise 'error: patch name required'
    return if state['applied'].last&.dig('name') == target
    if (idx = state['applied'].index { |p| p['name'] == target })
      pop_count = state['applied'].length - idx - 1
      pop_cmd(['-n', pop_count.to_s]) if pop_count.positive?
    elsif state['unapplied'].any? { |p| p['name'] == target }
      push_cmd(state['unapplied'].take_while { |p| p['name'] != target }.map { |p| p['name'] } + [target])
    else
      raise "error: patch `#{target}` does not exist"
    end
  end

  def float_cmd(args)
    names = args.reject { |a| a.start_with?('-') }
    names.each do |n|
      p = find_patch(n) or raise "error: patch `#{n}` does not exist"
      state['applied'].delete(p)
      state['unapplied'].delete(p)
      state['unapplied'] << p
    end
    save
    push_cmd(names)
  end

  def sink_cmd(args)
    names = args.reject { |a| a.start_with?('-') }
    names.each do |n|
      p = find_patch(n) or raise "error: patch `#{n}` does not exist"
      state['applied'].delete(p)
      state['unapplied'].delete(p)
      state['applied'].unshift(p)
    end
    save
  end

  def pick_cmd(args)
    rev = args.reject { |a| a.start_with?('-') }.first or raise 'error: commit required'
    name = unique_name(sanitize_name(capture(%W[git log -1 --format=%s #{rev}]).strip))
    run(['git', 'cherry-pick', rev])
    state['applied'] << patch(name, capture(%w[git rev-parse HEAD]).strip)
    save
  end

  def select_unapplied(args)
    return state['unapplied'].dup if args.include?('-a') || args.include?('--all')
    if (idx = args.index('-n') || args.index('--number'))
      return state['unapplied'].first(args[idx + 1].to_i)
    end
    names = args.reject { |a| a.start_with?('-') }
    return [state['unapplied'].first].compact if names.empty?
    names.map { |n| state['unapplied'].find { |p| p['name'] == n } or raise "error: patch `#{n}` does not exist" }
  end

  def select_applied(args)
    return state['applied'].dup if args.include?('-a') || args.include?('--all')
    if (idx = args.index('-n') || args.index('--number'))
      n = args[idx + 1].to_i
      return n.negative? ? state['applied'].last([state['applied'].length + n, 0].max) : state['applied'].last(n)
    end
    names = args.reject { |a| a.start_with?('-') }
    return [state['applied'].last].compact if names.empty?
    names.map { |n| state['applied'].find { |p| p['name'] == n } or raise "error: patch `#{n}` does not exist" }
  end

  def all_patches
    state['applied'] + state['unapplied'] + state['hidden']
  end

  def format_patch_line(p, prefix, show_commit, show_desc)
    parts = []
    if prefix
      parts << if state['applied'].last == p
                 '>'
               elsif state['applied'].include?(p)
                 '+'
               elsif state['hidden'].include?(p)
                 '!'
               else
                 '-'
               end
    end
    parts << p['name']
    parts << p['commit'] if show_commit
    parts << capture(%W[git log -1 --format=%s #{p['commit']}]).strip if show_desc
    parts.join(' ')
  end

  def resolve_rev(rev)
    return capture(%w[git rev-parse HEAD]).strip if rev.nil? || rev.empty?
    return state['base'] if rev == '{base}'
    if rev.end_with?('^')
      return "#{resolve_rev(rev[0...-1])}^"
    end
    patch_name = rev.include?(':') ? rev.split(':', 2).last : rev
    if (p = find_patch(patch_name))
      return p['commit']
    end
    capture(['git', 'rev-parse', rev]).strip
  end

  def find_patch(name)
    all_patches.find { |p| p['name'] == name }
  end

  def ensure_unique(name)
    raise "error: patch `#{name}` already exists" if find_patch(name)
  end

  def validate_patch_name(name)
    raise "error: invalid patch name `#{name}`: patch name may not contain '/'" if name.include?('/')
    raise "error: invalid patch name `#{name}`" if name.empty? || name == '.' || name == '..'
  end

  def sanitize_name(s)
    s = s.downcase.gsub(/[^a-z0-9._-]+/, '-').gsub(/^-+|-+$/, '')
    s.empty? ? 'patch' : s
  end

  def unique_name(base)
    n = base
    i = 2
    while find_patch(n)
      n = "#{base}-#{i}"
      i += 1
    end
    n
  end

  def patch(name, commit)
    { 'name' => name, 'commit' => commit }
  end

  def message_args(msg)
    ['-m', msg]
  end

  def read_message(file)
    file == '-' ? STDIN.read : File.read(file)
  end

  def option_value(args, short, long)
    if (idx = args.index(short) || args.index(long))
      args[idx + 1]
    end
  end

  def run_git_add(paths)
    cmd = ['git', 'add', '-A']
    cmd += ['--'] + paths unless paths.empty?
    run(cmd)
  end

  def clean_index?
    system('git', 'diff', '--cached', '--quiet')
  end

  def empty_commit?(rev)
    system('git', 'diff-tree', '--quiet', '--no-commit-id', '-r', rev)
  end

  def exec_git(args)
    exec('git', *args)
  end

  def exec_git_raw(args)
    exec('git', *args)
  end

  def run(cmd)
    ok = system(*cmd)
    raise "error: command failed: #{cmd.shelljoin}" unless ok
  end

  def capture(cmd)
    out = IO.popen(cmd, err: [:child, :out], &:read)
    raise out.strip unless $CHILD_STATUS.success?
    out
  end
end

Stg.new(ARGV).main
