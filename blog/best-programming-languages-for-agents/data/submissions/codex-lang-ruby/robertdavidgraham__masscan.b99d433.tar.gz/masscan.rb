#!/usr/bin/env ruby
# frozen_string_literal: true

require 'ipaddr'
require 'securerandom'

STDOUT.sync = true
STDERR.sync = true

class MasscanClone
  SHORT_HELP = <<~TEXT
    usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]

    examples:
        masscan -p80,8000-8100 10.0.0.0/8 --rate=10000
            scan some web ports on 10.x.x.x at 10kpps

        masscan --nmap
            list those options that are compatible with nmap

        masscan -p80 10.0.0.0/8 --banners -oB <filename>
            save results of scan in binary format to <filename>

        masscan --open --banners --readscan <filename> -oX <savefile>
            read binary scan results in <filename> and save them as xml in <savefile>
  TEXT

  LONG_HELP = <<~TEXT
    usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]
    MASSCAN is a fast port scanner. The primary input parameters are the
    IP addresses/ranges you want to scan, and the port numbers. An example
    is the following, which scans the 10.x.x.x network for web servers:

        masscan 10.0.0.0/8 -p80

    The program auto-detects network interface/adapter settings. If this
    fails, you'll have to set these manually. The following is an
    example of all the parameters that are needed:

        --adapter-ip 192.168.10.123
        --adapter-mac 00-11-22-33-44-55
        --router-mac 66-55-44-33-22-11

    Parameters can be set either via the command-line or config-file. The
    names are the same for both. Thus, the above adapter settings would
    appear as follows in a configuration file:

        adapter-ip = 192.168.10.123
        adapter-mac = 00-11-22-33-44-55
        router-mac = 66-55-44-33-22-11

    All single-dash parameters have a spelled out double-dash equivalent,
    so '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).
    To use the config file, type:

        masscan -c <filename>

    To generate a config-file from the current settings, use the --echo
    option. This stops the program from actually running, and just echoes
    the current configuration instead. This is a useful way to generate
    your first config file, or see a list of parameters you didn't know
    about. I suggest you try it now:

        masscan -p1234 --echo
  TEXT

  NMAP_HELP = <<~TEXT
    Masscan (https://github.com/robertdavidgraham/masscan)
    Usage: masscan [Options] -p{Target-Ports} {Target-IP-Ranges}
    TARGET SPECIFICATION:
      Can pass only IPv4/IPv6 address, CIDR networks, or ranges (non-nmap style)
      Ex: 10.0.0.0/8, 192.168.0.1, 10.0.0.1-10.0.0.254
      -iL <inputfilename>: Input from list of hosts/networks
      --exclude <host1[,host2][,host3],...>: Exclude hosts/networks
      --excludefile <exclude_file>: Exclude list from file
      --randomize-hosts: Randomize order of hosts (default)
    HOST DISCOVERY:
      -Pn: Treat all hosts as online (default)
      -n: Never do DNS resolution (default)
    SCAN TECHNIQUES:
      -sS: TCP SYN (always on, default)
    SERVICE/VERSION DETECTION:
      --banners: get the banners of the listening service if available. The
        default timeout for waiting to receive data is 30 seconds.
    PORT SPECIFICATION AND SCAN ORDER:
      -p <port ranges>: Only scan specified ports
        Ex: -p22; -p1-65535; -p 111,137,80,139,8080
    TIMING AND PERFORMANCE:
      --max-rate <number>: Send packets no faster than <number> per second
      --connection-timeout <number>: time in seconds a TCP connection will
        timeout while waiting for banner data from a port.
    FIREWALL/IDS EVASION AND SPOOFING:
      -S/--source-ip <IP_Address>: Spoof source address
      -e <iface>: Use specified interface
      -g/--source-port <portnum>: Use given port number
      --ttl <val>: Set IP time-to-live field
      --spoof-mac <mac address/prefix/vendor name>: Spoof your MAC address
    OUTPUT:
      --output-format <format>: Sets output to binary/list/unicornscan/json/ndjson/grepable/xml
      --output-file <file>: Write scan results to file. If --output-format is
         not given default is xml
      -oL/-oJ/-oD/-oG/-oB/-oX/-oU <file>: Output scan in List/JSON/nDjson/Grepable/Binary/XML/Unicornscan format,
         respectively, to the given filename. Shortcut for
         --output-format <format> --output-file <file>
      -v: Increase verbosity level (use -vv or more for greater effect)
      -d: Increase debugging level (use -dd or more for greater effect)
      --open: Only show open (or possibly open) ports
      --packet-trace: Show all packets sent and received
      --iflist: Print host interfaces and routes (for debugging)
      --append-output: Append to rather than clobber specified output files
      --resume <filename>: Resume an aborted scan
    MISC:
      --send-eth: Send using raw ethernet frames (default)
      -V: Print version number
      -h: Print this help summary page.
    EXAMPLES:
      masscan -v -sS 192.168.0.0/16 10.0.0.0/8 -p 80
      masscan 23.0.0.0/0 -p80 --banners -output-format binary --output-filename internet.scan
      masscan --open --banners --readscan internet.scan -oG internet_scan.grepable
    SEE (https://github.com/robertdavidgraham/masscan) FOR MORE HELP
  TEXT

  VERSION = <<~TEXT

    Masscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )
    Compiled on: Apr 17 2026 19:59:25
    Compiler: gcc 11.4.0
    OS: Linux
    CPU: x86 (64 bits)
    GIT version: unknown
  TEXT

  OUTPUT_SHORTCUTS = {
    '-oL' => 'list', '-oJ' => 'json', '-oD' => 'ndjson', '-oG' => 'grepable',
    '-oB' => 'binary', '-oX' => 'xml', '-oU' => 'unicornscan'
  }.freeze

  attr_reader :exit_code

  def initialize(argv)
    @argv = argv.dup
    @ports = []
    @ranges = []
    @excludes = []
    @settings = { 'rate' => '100', 'shard' => '1/1' }
    @flags = {}
    @exit_code = 0
  end

  def run
    return puts(SHORT_HELP) if @argv.empty? && false

    parse(@argv)
    if @flags[:long_help]
      @exit_code = 1
      return puts(LONG_HELP)
    end
    if @flags[:short_help]
      @exit_code = 1
      return puts(SHORT_HELP)
    end
    if @flags[:nmap]
      @exit_code = 1
      return puts(NMAP_HELP)
    end
    if @flags[:version]
      @exit_code = 1
      return puts(VERSION)
    end
    return if @flags[:fatal]

    if @flags[:readscan]
      pcap_fail
      readscan(@flags[:readscan])
      return
    end

    pcap_fail(verbose: @settings['packet-trace'])
    if @flags[:iflist]
      puts 'libpcap not loaded'
      return
    end

    if @flags[:echo]
      echo_config
      return
    end

    unless valid_to_scan?
      @exit_code = 1
      return
    end

    # In the cleanroom the reference binary cannot actually scan because
    # libpcap is absent. Preserve the visible behavior by stopping quietly
    # after validation.
  end

  def parse(argv)
    i = 0
    while i < argv.length
      arg = argv[i]
      if arg == '--help'
        @flags[:long_help] = true
      elsif arg == '-h' || arg == '-?'
        @flags[:short_help] = true
      elsif arg == '--nmap'
        @flags[:nmap] = true
      elsif arg == '--version' || arg == '-V'
        @flags[:version] = true
      elsif arg == '--echo'
        @flags[:echo] = true
      elsif arg == '--iflist' || arg == '--adapter-list'
        @flags[:iflist] = true
      elsif arg == '-c' || arg == '--conf' || arg == '--config'
        i += 1
        load_config(argv[i])
      elsif arg.start_with?('-c') && arg.length > 2
        load_config(arg[2..])
      elsif arg == '-p' || arg == '--ports' || arg == '--port'
        i += 1
        add_ports(argv[i].to_s)
      elsif arg.start_with?('-p') && arg != '-p'
        add_ports(arg[2..])
      elsif arg.start_with?('--ports=')
        add_ports(arg.split('=', 2)[1].to_s)
      elsif arg == '--range'
        i += 1
        add_range(argv[i].to_s)
      elsif arg.start_with?('--range=')
        add_range(arg.split('=', 2)[1].to_s)
      elsif arg == '-iL' || arg == '--include-file' || arg == '--includefile'
        i += 1
        load_include(argv[i].to_s)
      elsif arg == '--exclude'
        i += 1
        @excludes.concat(argv[i].to_s.split(','))
      elsif arg.start_with?('--exclude=')
        @excludes.concat(arg.split('=', 2)[1].to_s.split(','))
      elsif arg == '--excludefile' || arg == '--exclude-file'
        i += 1
        load_exclude(argv[i].to_s)
      elsif arg == '--readscan'
        i += 1
        @flags[:readscan] = argv[i].to_s
      elsif OUTPUT_SHORTCUTS.key?(arg)
        i += 1
        @settings['output-filename'] = argv[i].to_s
        @settings['output-format'] = OUTPUT_SHORTCUTS[arg]
      elsif arg =~ /^-o([LJDGUXB])(.+)/
        fmt = OUTPUT_SHORTCUTS["-o#{Regexp.last_match(1)}"]
        @settings['output-filename'] = Regexp.last_match(2)
        @settings['output-format'] = fmt
      elsif arg == '--output-file' || arg == '--output-filename'
        i += 1
        @settings['output-filename'] = argv[i].to_s
        @settings['output-format'] ||= 'xml'
      elsif arg.start_with?('--output-file=')
        @settings['output-filename'] = arg.split('=', 2)[1].to_s
        @settings['output-format'] ||= 'xml'
      elsif arg == '--output-format'
        i += 1
        @settings['output-format'] = argv[i].to_s
      elsif arg.start_with?('--output-format=')
        @settings['output-format'] = arg.split('=', 2)[1].to_s
      elsif arg == '--rate' || arg == '--max-rate' || arg == '--maxrate'
        i += 1
        @settings['rate'] = argv[i].to_s
      elsif arg.start_with?('--rate=') || arg.start_with?('--max-rate=')
        @settings['rate'] = arg.split('=', 2)[1].to_s
      elsif arg == '--shards' || arg == '--shard'
        i += 1
        @settings['shard'] = argv[i].to_s
      elsif arg == '--banners'
        @settings['banners'] = 'true'
      elsif arg == '--ping'
        add_ports('I:0')
      elsif arg == '--packet-trace'
        @settings['packet-trace'] = 'true'
      elsif arg == '--adapter-ip' || arg == '--source-ip' || arg == '-S'
        i += 1
        @settings['adapter-ip'] = argv[i].to_s
      elsif arg == '--adapter-mac'
        i += 1
        @settings['adapter-mac'] = argv[i].to_s
      elsif arg == '--router-mac'
        i += 1
        @settings['router-mac-ipv4'] = argv[i].to_s
        @settings['router-mac-ipv6'] = argv[i].to_s
      elsif arg == '--router-mac-ipv4' || arg == '--router-mac-ipv6'
        i += 1
        @settings[arg.delete_prefix('--')] = argv[i].to_s
      elsif arg == '--source-port' || arg == '-g'
        i += 1
        @settings['adapter-port'] = argv[i].to_s
      elsif arg == '-v' || arg == '-d' || arg =~ /^-[vd]+$/
        # accepted verbosity/debug spelling
      elsif %w[-n -Pn -sS --send-eth --randomize-hosts --open --append-output --badsum].include?(arg)
        # accepted compatibility no-op
      elsif arg.start_with?('--')
        handle_long_option(arg, argv, i)
        i += 1 if consumes_value?(arg, argv[i + 1])
      elsif arg.start_with?('-') && arg.length > 1
        # Unknown short options are ignored by the reference surprisingly often.
      else
        add_range(arg)
      end
      i += 1
    end
  end

  def handle_long_option(arg, argv, i)
    key, val = arg.delete_prefix('--').split('=', 2)
    if val
      @settings[key] = val
    elsif value_option_name?(key) && argv[i + 1]
      @settings[key] = argv[i + 1].to_s
    else
      warn "#{key}: empty parameter"
    end
  end

  def value_option_name?(key)
    %w[ttl wait connection-timeout max-retries retries seed resume spoof-mac adapter adapter-port].include?(key)
  end

  def consumes_value?(arg, nxt)
    return false if arg.include?('=')
    key = arg.delete_prefix('--')
    value_option_name?(key) && nxt && !nxt.start_with?('-')
  end

  def load_config(path)
    File.readlines(path.to_s, chomp: true).each do |line|
      line = line.sub(/#.*/, '').strip
      next if line.empty?
      key, val = line.split(/\s*=\s*/, 2)
      val ||= ''
      case key
      when 'ports', 'port'
        add_ports(val)
      when 'range'
        add_range(val)
      when 'rate', 'max-rate'
        @settings['rate'] = val
      when 'output-filename', 'output-file'
        @settings['output-filename'] = val
      when 'output-format'
        @settings['output-format'] = val
      when 'adapter-ip', 'adapter-mac', 'adapter-port', 'banners'
        @settings[key] = val
      when 'router-mac'
        @settings['router-mac-ipv4'] = val
        @settings['router-mac-ipv6'] = val
      else
        @settings[key] = val
      end
    end
  rescue Errno::ENOENT
    warn "[-] FAIL: #{path}: No such file or directory"
    @flags[:fatal] = true
    @exit_code = 1
  end

  def load_include(path)
    File.readlines(path, chomp: true).each do |line|
      line = line.sub(/#.*/, '').strip
      add_range(line) unless line.empty?
    end
    apply_excludes!
  rescue Errno::ENOENT
    warn '[-] FAIL: parsing IP addresses'
    warn "[-] #{path}: No such file or directory"
    @flags[:fatal] = true
    @exit_code = 1
  end

  def load_exclude(path)
    lines = File.readlines(path, chomp: true).map { |l| l.sub(/#.*/, '').strip }.reject(&:empty?)
    @excludes.concat(lines)
    puts "#{path}: excluding #{lines.length} ranges from file"
    apply_excludes!
  rescue Errno::ENOENT
    warn "[-] #{path}: No such file or directory"
  end

  def add_ports(text)
    text.to_s.split(',').each do |part|
      part = part.strip
      next if part.empty?
      proto = 'T'
      if part =~ /\A([A-Za-z]):(.+)\z/
        proto = Regexp.last_match(1).upcase
        part = Regexp.last_match(2)
      end
      nums = parse_port_range(part)
      nums.each { |p| @ports << [proto, p] } if nums
    end
  end

  def parse_port_range(part)
    if part =~ /\A-?(\d+)\z/
      n = Regexp.last_match(1).to_i
      bad_port(n, part) and return nil if n > 65_535
      return [n]
    end
    if part =~ /\A(\d+)-(\d+)\z/
      a = Regexp.last_match(1).to_i
      b = Regexp.last_match(2).to_i
      bad_port([a, b].max, part) and return nil if [a, b].max > 65_535
      a, b = b, a if b < a
      return (a..b).to_a
    end
    nil
  end

  def bad_port(n, _part)
    warn "[-] FAIL: bad target port: #{n}"
    warn '    Hint: a port is a number [0..65535]'
    @flags[:fatal] = true
    @exit_code = 1
  end

  def add_range(text)
    text = text.to_s.strip
    return if text.empty?
    @ranges << text
    apply_excludes! unless @excludes.empty?
  end

  def apply_excludes!
    return if @ranges.empty? || @excludes.empty?

    excl = @excludes.map { |e| range_bounds(e) }.compact
    @ranges = @ranges.flat_map do |r|
      pieces = [range_bounds(r)]
      excl.each do |eb|
        pieces = pieces.flat_map { |pb| subtract_range(pb, eb) }
      end
      pieces.map { |b| bounds_to_range(b) }
    end
  end

  def range_bounds(r)
    return nil if r.include?(':')
    if r.include?('/') && r !~ %r{/32\z}
      ip = IPAddr.new(r)
      return [ip.to_range.first.to_i, ip.to_range.last.to_i]
    end
    r = r.sub(%r{/32\z}, '')
    if r.include?('-')
      a, b = r.split('-', 2)
      return [IPAddr.new(a).to_i, IPAddr.new(b).to_i]
    end
    n = IPAddr.new(r).to_i
    [n, n]
  rescue StandardError
    nil
  end

  def subtract_range(a, b)
    return [a] if b[1] < a[0] || b[0] > a[1]
    out = []
    out << [a[0], b[0] - 1] if b[0] > a[0]
    out << [b[1] + 1, a[1]] if b[1] < a[1]
    out
  end

  def bounds_to_range(bounds)
    a, b = bounds
    return IPAddr.new(a, Socket::AF_INET).to_s if a == b
    # Match masscan's compact CIDR rendering for simple aligned remainders.
    size = b - a + 1
    if size > 1 && (size & (size - 1)).zero? && (a % size).zero?
      prefix = 32 - Math.log2(size).to_i
      return "#{IPAddr.new(a, Socket::AF_INET)}/#{prefix}"
    end
    "#{IPAddr.new(a, Socket::AF_INET)}-#{IPAddr.new(b, Socket::AF_INET)}"
  end

  def normalized_ports
    grouped = Hash.new { |h, k| h[k] = [] }
    @ports.each do |proto, port|
      proto = 'I' if proto == 'O'
      port += 256 if proto == 'I' && port.positive?
      grouped[proto] << port
    end
    order = %w[T U S I]
    order.flat_map do |proto|
      nums = grouped[proto].uniq.sort
      compact_ranges(nums).map do |s, e|
        body = s == e ? s.to_s : "#{s}-#{e}"
        proto == 'T' ? body : "#{proto}:#{body}"
      end
    end.join(',')
  end

  def compact_ranges(nums)
    out = []
    nums.each do |n|
      if out.empty? || n != out[-1][1] + 1
        out << [n, n]
      else
        out[-1][1] = n
      end
    end
    out
  end

  def echo_config
    puts "seed = #{SecureRandom.random_number(1 << 64)}"
    puts format('rate = %-10s', @settings['rate'])
    puts "shard = #{@settings['shard']}"
    puts 'banners = true' if @settings['banners'] == 'true'
    puts 'nocapture = servername'
    puts 'nocapture = servername'
    puts
    puts "output-filename = #{@settings['output-filename']}" if @settings['output-filename']
    puts "output-format = #{@settings['output-format']}" if @settings['output-format']
    puts
    %w[adapter-ip adapter-mac adapter-port router-mac-ipv4 router-mac-ipv6].each do |k|
      puts "#{k} = #{@settings[k]}" if @settings[k]
    end
    puts '# TARGET SELECTION (IP, PORTS, EXCLUDES)'
    puts "ports = #{normalized_ports}"
    @ranges.each { |r| puts "range = #{canonical_range(r)}" }
  end

  def canonical_range(r)
    r.sub(%r{/32\z}, '')
  end

  def valid_to_scan?
    if normalized_ports.empty?
      puts 'FAIL: no ports were specified'
      puts ' [hint] try something like "-p80,8000-9000"'
      puts ' [hint] try something like "--ports 0-65535"'
      return false
    end
    if @ranges.empty?
      puts 'FAIL: target IP address list empty'
      puts ' [hint] try something like "--range 10.0.0.0/8"'
      puts ' [hint] try something like "--range 192.168.0.100-192.168.0.200"'
      return false
    end
    true
  end

  def pcap_fail(verbose: nil)
    if verbose
      %w[libpcap.so libpcap.A.dylib libpcap.dylib libpcap.so.1 libpcap.so.0.9.5 libpcap.so.0.9.4 libpcap.so.0.8].each do |lib|
        warn "[-] pcap: failed to load: #{lib}"
      end
    end
    warn '[-] FAIL: failed to load libpcap shared library'
    warn '    [hint]: you must install libpcap or WinPcap'
    return unless verbose

    %w[pcap_close pcap_datalink pcap_dispatch pcap_findalldevs pcap_freealldevs pcap_lib_version pcap_lookupdev pcap_major_version pcap_minor_version pcap_open_live pcap_open_offline pcap_sendpacket pcap_next pcap_setdirection pcap_datalink_val_to_name pcap_perror pcap_geterr pcap_create pcap_set_snaplen pcap_set_promisc pcap_set_timeout pcap_set_immediate_mode pcap_set_buffer_size pcap_set_rfmon pcap_can_set_rfmon pcap_activate].each do |fn|
      warn "pcap: #{fn}: failed"
    end
    warn "pfring: error: dlopen('libpfring.so'): No such file or directory"
  end

  def readscan(path)
    unless File.exist?(path)
      warn '[-] FAIL: --readscan'
      warn "[-] #{path}: No such file or directory"
      return
    end
    puts "[+] --readscan #{path}"
    head = File.open(path, 'rb') { |f| f.read(16).to_s }
    return if head.start_with?('masscan/1.1')

    warn "[-] #{path}: unknown file format (expeced \"masscan/1.1\")"
  end
end

app = MasscanClone.new(ARGV)
app.run
exit app.exit_code
