#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'open3'
require 'shellwords'

VERSION = '5.7'
PROG = File.basename($PROGRAM_NAME)

def usage
  warn "release: #{VERSION}"
  warn 'usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames'
end

def help
  usage
  warn 'summary:'
  warn '    -a  Do not consolidate events'
  warn '    -c  Clear screen before execution'
  warn '    -d  Track files added or removed from directories'
  warn '    -n  Non-interactive mode'
  warn '    -p  Wait for first event'
  warn '    -r  Run as a background process, use signal to restart'
  warn '    -s  Evaluate using a shell'
  warn '    -x  Format exit status'
  warn '    -z  Exit after the utility completes'
  warn 'docs:'
  warn '    man entr'
end

def invalid_option(ch)
  warn "#{PROG}: invalid option -- '#{ch}'"
  usage
  warn 'hint: use -h to display option summary'
  exit 1
end

opts = Hash.new(0)
args = ARGV.dup
while (arg = args.first)
  break unless arg.start_with?('-') && arg != '-'

  args.shift
  if arg == '--'
    break
  elsif arg == '-h'
    help
    exit 1
  elsif arg.start_with?('--')
    invalid_option('-')
  else
    arg[1..].each_char do |ch|
      if 'acdnprsxz'.include?(ch)
        opts[ch] += 1
      else
        invalid_option(ch)
      end
    end
  end
end

if args.empty?
  usage
  warn 'hint: use -h to display option summary'
  exit 1
end

if opts['s'].positive? && args.length != 1
  warn "#{PROG}: -s requires commands to be formatted as a single argument"
  exit 1
end

input_files = STDIN.read.lines.map(&:chomp).reject(&:empty?)
watch_files = []
watch_dirs = {}

def snapshot_dir(path, include_dot)
  entries = Dir.entries(path).reject { |e| e == '.' || e == '..' }
  entries.reject! { |e| e.start_with?('.') } unless include_dot
  entries.sort
rescue SystemCallError
  []
end

input_files.each do |path|
  begin
    st = File.lstat(path)
  rescue SystemCallError
    warn "#{PROG}: unable to stat '#{path}'"
    next
  end

  if st.file? || st.symlink?
    watch_files << path
    if opts['d'].positive?
      dir = File.dirname(path)
      dir = '.' if dir.nil? || dir.empty?
      watch_dirs[dir] = snapshot_dir(dir, opts['d'] > 1)
    end
  elsif st.directory?
    watch_dirs[path] = snapshot_dir(path, opts['d'] > 1)
  end
end

if watch_files.empty? && watch_dirs.empty?
  warn "#{PROG}: No regular files to watch"
  exit 1
end

unless opts['n'].positive? || STDIN.tty?
  warn "#{PROG}: unable to get terminal attributes, use '-n' to run non-interactively"
  exit 1
end

def snapshot_file(path)
  st = File.lstat(path)
  [st.mtime.to_f, st.size, st.ino, st.mode]
rescue SystemCallError
  nil
end

file_state = watch_files.to_h { |f| [f, snapshot_file(f)] }
default_file = watch_files.first || watch_dirs.keys.first

if ENV['EV_TRACE']
  warn "open_max: #{Process.getrlimit(:NOFILE).first}"
end

def clear_screen(level)
  return unless level.positive?

  if level > 1
    print "\e[3J\e[2J\e[H"
  else
    print "\e[2J\e[H"
  end
  STDOUT.flush
end

def status_from_process(status)
  return status.exitstatus if status.exited?
  return 128 + status.termsig if status.signaled?

  1
end

def run_command(args, opts, trigger)
  clear_screen(opts['c'])
  ENV['PAGER'] ||= '/bin/cat'

  if opts['s'].positive?
    shell = ENV['SHELL'] || '/bin/sh'
    system(shell, '-c', args[0], trigger.to_s)
  else
    cmd = args.map { |a| a == '/_' ? trigger.to_s : a }
    system(*cmd)
  end
  status_from_process($?)
rescue Errno::ENOENT
  warn "#{PROG}: exec #{args[0]}: No such file or directory"
  1
end

def changed_file(file_state)
  file_state.each do |path, old|
    now = snapshot_file(path)
    return path if now != old
  end
  nil
end

def changed_dir(watch_dirs, include_dot)
  watch_dirs.each do |path, old|
    now = snapshot_dir(path, include_dot)
    return path if now != old
  end
  nil
end

def refresh_states(file_state, watch_dirs, include_dot)
  file_state.keys.each { |f| file_state[f] = snapshot_file(f) }
  watch_dirs.keys.each { |d| watch_dirs[d] = snapshot_dir(d, include_dot) }
end

trap('INT') { exit 0 }
trap('TERM') { exit 0 }

last_status = 0
child_pid = nil

run_once = lambda do |trigger|
  last_status = run_command(args, opts, trigger || default_file)
  exit last_status if opts['z'].positive?
  refresh_states(file_state, watch_dirs, opts['d'] > 1)
end

unless opts['p'].positive?
  if opts['r'].positive? && opts['z'].zero?
    clear_screen(opts['c'])
    if opts['s'].positive?
      shell = ENV['SHELL'] || '/bin/sh'
      child_pid = Process.spawn(shell, '-c', args[0], default_file.to_s, pgroup: true)
    else
      cmd = args.map { |a| a == '/_' ? default_file.to_s : a }
      child_pid = Process.spawn(*cmd, pgroup: true)
    end
  else
    run_once.call(default_file)
  end
end

loop do
  sleep 0.15

  if child_pid
    begin
      done = Process.waitpid(child_pid, Process::WNOHANG)
      child_pid = nil if done
    rescue Errno::ECHILD
      child_pid = nil
    end
  end

  if (dir = changed_dir(watch_dirs, opts['d'] > 1))
    exit 2
  end

  trigger = changed_file(file_state)
  next unless trigger

  refresh_states(file_state, watch_dirs, opts['d'] > 1)
  if opts['r'].positive?
    if child_pid
      sig = (ENV['ENTR_RESTART_SIGNAL'] || 'TERM').sub(/^SIG/, '')
      begin
        Process.kill("-#{sig}", child_pid)
      rescue SystemCallError, ArgumentError
        begin
          Process.kill('TERM', child_pid)
        rescue SystemCallError
        end
      end
      begin
        Process.waitpid(child_pid)
      rescue SystemCallError
      end
      child_pid = nil
    end
  end

  if opts['r'].positive? && opts['z'].zero?
    clear_screen(opts['c'])
    if opts['s'].positive?
      shell = ENV['SHELL'] || '/bin/sh'
      child_pid = Process.spawn(shell, '-c', args[0], trigger.to_s, pgroup: true)
    else
      cmd = args.map { |a| a == '/_' ? trigger.to_s : a }
      child_pid = Process.spawn(*cmd, pgroup: true)
    end
  else
    run_once.call(trigger)
  end
end
