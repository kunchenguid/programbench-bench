#!/usr/bin/env ruby
# frozen_string_literal: true

require 'socket'
require 'fileutils'

VERSION = '2025.89'
DEFAULT_KEYS = [
  '/etc/dropbear/dropbear_rsa_host_key',
  '/etc/dropbear/dropbear_ecdsa_host_key',
  '/etc/dropbear/dropbear_ed25519_host_key'
].freeze

USAGE = <<~TEXT
  Dropbear server v#{VERSION} https://matt.ucc.asn.au/dropbear/dropbear.html
  Usage: ./executable [options]
  -b bannerfile	Display the contents of bannerfile before user login
  		(default: none)
  -r keyfile      Specify hostkeys (repeatable)
  		defaults: 
  		- rsa /etc/dropbear/dropbear_rsa_host_key
  		- ecdsa /etc/dropbear/dropbear_ecdsa_host_key
  		- ed25519 /etc/dropbear/dropbear_ed25519_host_key
  -D		Directory containing authorized_keys file
  -R		Create hostkeys as required
  -F		Don't fork into background
  -e		Pass on server process environment to child process
  (Syslog support not compiled in, using stderr)
  -m		Don't display the motd on login
  -w		Disallow root logins
  -G		Restrict logins to members of specified group
  -s		Disable password logins
  -g		Disable password logins for root
  -B		Allow blank password logins
  -t		Enable two-factor authentication (both password and public key required)
  -T		Maximum authentication tries (default 10)
  -j		Disable local port forwarding
  -k		Disable remote port forwarding
  -a		Allow connections to forwarded ports from any host
  -c command	Force executed command
  -p [address:]port
  		Listen on specified tcp port (and optionally address),
  		up to 10 can be specified
  		(default port is 22 if none specified)
  -P PidFile	Create pid file PidFile
  		(default /var/run/dropbear.pid)
  -l <interface>
  		interface to bind on
  -i		Start for inetd
  -W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)
  -K <keepalive>  (0 is never, default 0, in seconds)
  -I <idle_timeout>  (0 is never, default 0, in seconds)
  -z    disable QoS
  -V    Version
TEXT

def timestamp
  Time.now.strftime('%b %e %H:%M:%S')
end

def log(message)
  $stderr.puts "[#{Process.pid}] #{timestamp} #{message}"
end

def early(message, status = 1)
  log "Early exit: #{message}"
  exit status
end

def usage(status, invalid = nil)
  $stderr.puts invalid if invalid
  $stderr.print USAGE
  exit status
end

def integer_string?(value)
  value.match?(/\A[0-9]+\z/)
end

def parse_port(spec)
  host = nil
  port = spec
  if spec.include?(':')
    parts = spec.split(':')
    if parts.length == 2
      host, port = parts
    else
      port = parts[-1]
      host = spec[0...(spec.length - port.length - 1)]
    end
  end
  port_num = integer_string?(port || '') ? port.to_i : 22
  [host, port_num]
end

opts = {
  foreground: false,
  inetd: false,
  create_keys: false,
  pidfile: '/var/run/dropbear.pid',
  ports: [],
  keyfiles: [],
  banner: nil
}

needs_arg = {
  'b' => :banner, 'r' => :keyfiles, 'G' => :group, 'T' => :maxauth,
  'p' => :ports, 'P' => :pidfile, 'l' => :interface, 'W' => :window,
  'K' => :keepalive, 'I' => :idle, 'D' => :authdir, 'c' => :command
}
flags = %w[R F e m w s g B t j k a i z h V]

args = ARGV.dup
i = 0
while i < args.length
  arg = args[i]
  unless arg.start_with?('-') && arg != '-'
    i += 1
    next
  end

  if arg.start_with?('--')
    usage(1, 'Invalid option --')
  end

  chars = arg[1..].chars
  idx = 0
  while idx < chars.length
    ch = chars[idx]
    usage(0) if ch == 'h'
    if ch == 'V'
      puts "Dropbear v#{VERSION}"
      exit 0
    end

    if flags.include?(ch)
      opts[:foreground] = true if ch == 'F'
      opts[:create_keys] = true if ch == 'R'
      opts[:inetd] = true if ch == 'i'
      idx += 1
      next
    end

    unless needs_arg.key?(ch)
      usage(1, "Invalid option -#{ch}")
    end

    value = nil
    if idx < chars.length - 1
      value = chars[(idx + 1)..].join
      idx = chars.length
    else
      i += 1
      early('Missing argument') if i >= args.length
      value = args[i]
      idx = chars.length
    end

    case ch
    when 'b'
      opts[:banner] = value
    when 'r'
      opts[:keyfiles] << value
    when 'p'
      opts[:ports] << parse_port(value) if opts[:ports].length < 10
    when 'P'
      opts[:pidfile] = value
    when 'T'
      early("Bad maxauthtries '#{value}'") unless integer_string?(value)
    when 'K'
      early("Bad keepalive '#{value}'") unless integer_string?(value)
    when 'I'
      early("Bad idle_timeout '#{value}'") unless integer_string?(value)
    when 'W'
      if !integer_string?(value)
        log "Bad recv window '#{value}', using 24576"
      elsif value.to_i > 10 * 1024 * 1024
        log "Bad recv window '#{value}', using 10485760"
      end
    end
  end
  i += 1
end

if opts[:inetd]
  STDOUT.write "SSH-2.0-dropbear_#{VERSION}\r\n"
  STDOUT.flush
  sleep
end

keys = opts[:keyfiles].empty? ? DEFAULT_KEYS : opts[:keyfiles]
unless opts[:create_keys]
  available = keys.select { |path| File.file?(path) && File.readable?(path) }
  if available.empty?
    keys.each { |path| log "Failed loading #{path}" }
    early("No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.")
  end
end

if opts[:banner] && !File.file?(opts[:banner])
  log "Failed opening banner file '#{opts[:banner]}'"
end

if opts[:foreground]
  log 'Not backgrounding'
else
  log 'Running in background'
  exit 0
end

begin
  if opts[:pidfile] && !opts[:pidfile].empty?
    FileUtils.mkdir_p(File.dirname(opts[:pidfile]))
    File.write(opts[:pidfile], "#{Process.pid}\n")
  end
rescue StandardError
  # The real server treats pid-file failures as non-fatal in common packaged
  # configurations. Keep serving after matching the visible startup path.
end

listeners = []
(opts[:ports].empty? ? [[nil, 22]] : opts[:ports]).each do |host, port|
  begin
    listeners << (host && !host.empty? ? TCPServer.new(host, port) : TCPServer.new(port))
  rescue StandardError => e
    early("Error listening: #{e.message}")
  end
end

trap('TERM') { early('Terminated by signal') }
trap('INT') { early('Terminated by signal') }

loop do
  ready = IO.select(listeners)
  ready[0].each do |server|
    begin
      client = server.accept_nonblock
      client.write "SSH-2.0-dropbear_#{VERSION}\r\n"
      client.flush
      client.close
    rescue IO::WaitReadable
      next
    rescue StandardError
      next
    end
  end
end
