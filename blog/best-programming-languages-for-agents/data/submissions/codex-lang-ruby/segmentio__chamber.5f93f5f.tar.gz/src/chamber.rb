#!/usr/bin/env ruby
# frozen_string_literal: true

gem 'json', '2.6.1'
require 'json'
require 'yaml'
require 'shellwords'

GLOBAL_FLAGS = <<~TXT.chomp
Global Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                    standard
                                    adaptive (default "standard")
      --verbose                    Print more information to STDERR
TXT

ROOT_HELP = <<~TXT
CLI for storing secrets

Usage:
  chamber [command]

Available Commands:
  completion    Generate the autocompletion script for the specified shell
  delete        Delete a secret, including all versions
  env           Print the secrets from the parameter store in a format to export as environment variables
  exec          Executes a command with secrets loaded into the environment
  export        Exports parameters in the specified format
  find          Find the given secret across all services
  help          Help about any command
  history       View the history of a secret
  import        import secrets from json or yaml
  list          List the secrets set for a service
  list-services List services
  read          Read a specific secret from the parameter store
  tag           work with tags on secrets
  version       print version
  write         write a secret

Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   \tnull: no-op
                                   \tssm: SSM Parameter Store
                                   \tsecretsmanager: Secrets Manager
                                   \ts3: S3; requires --backend-s3-bucket
                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
  -h, --help                       help for chamber
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                    standard
                                    adaptive (default "standard")
      --verbose                    Print more information to STDERR

Use "chamber [command] --help" for more information about a command.
TXT

HELP = {
  'version' => ["print version", "chamber version [flags]", "  -h, --help   help for version"],
  'list' => ["List the secrets set for a service", "chamber list <service> [flags]", "  -e, --expand    Expand parameter list with values\n  -h, --help      help for list\n  -t, --time      Sort by modified time\n  -u, --user      Sort by user\n  -v, --version   Sort by version"],
  'read' => ["Read a specific secret from the parameter store", "chamber read <service> <key> [flags]", "  -h, --help          help for read\n  -q, --quiet         Only print the secret\n  -v, --version int   The version number of the secret. Defaults to latest. (default -1)"],
  'write' => ["write a secret", "chamber write <service> <key> [--] <value|-> [flags]", "  -h, --help                  help for write\n  -s, --singleline            Insert single line parameter (end with \\n)\n      --skip-unchanged        Skip writing secret if value is unchanged\n  -t, --tags stringToString   Add tags to the secret; new secrets only (default [])"],
  'delete' => ["Delete a secret, including all versions", "chamber delete <service> <key> [flags]", "      --exact-key   Prevent normalization of the provided key in order to delete any keys that match the exact provided casing.\n  -h, --help        help for delete"],
  'env' => ["Print the secrets from the parameter store in a format to export as environment variables", "chamber env <service> [flags]", "  -p, --preserve-case    preserve variable name case\n  -e, --escape-strings   escape special characters in values\n  -h, --help             help for env"],
  'export' => ["Exports parameters in the specified format", "chamber export <service...> [flags]", "  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default \"json\")\n  -o, --output-file string   Output file (default is standard output)\n  -h, --help                 help for export"],
  'import' => ["import secrets from json or yaml", "chamber import <service> <file|-> [flags]", "  -h, --help                           help for import\n      --normalize-keys chamber write   Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source."],
  'find' => ["Find the given secret across all services", "chamber find <secret name> [flags]", "  -v, --by-value   Find parameters by value\n  -h, --help       help for find"],
  'history' => ["View the history of a secret", "chamber history <service> <key> [flags]", "  -h, --help   help for history"],
  'list-services' => ["List services", "chamber list-services <service> [flags]", "  -h, --help      help for list-services\n  -s, --secrets   Include secret names in the list"]
}.freeze

STORE_FILE = '.chamber_store.json'

def die(msg, code = 1)
  warn "Error: #{msg}"
  exit code
end

def emit_help(cmd)
  if cmd == 'tag'
    puts <<~TXT
      work with tags on secrets

      Usage:
        chamber tag [command]

      Available Commands:
        delete      Delete tags for a specific secret
        read        Read tags for a specific secret
        write       Write tags for a specific secret

      Flags:
        -h, --help   help for tag

      #{GLOBAL_FLAGS}

      Use "chamber tag [command] --help" for more information about a command.
    TXT
    return
  end
  if cmd == 'completion'
    puts <<~TXT
      Generate the autocompletion script for chamber for the specified shell.
      See each sub-command's help for details on how to use the generated script.

      Usage:
        chamber completion [command]

      Available Commands:
        bash        Generate the autocompletion script for bash
        fish        Generate the autocompletion script for fish
        powershell  Generate the autocompletion script for powershell
        zsh         Generate the autocompletion script for zsh

      Flags:
        -h, --help   help for completion

      #{GLOBAL_FLAGS}

      Use "chamber completion [command] --help" for more information about a command.
    TXT
    return
  end
  data = HELP[cmd] || HELP['version']
  puts data[0]
  puts
  puts "Usage:"
  puts "  #{data[1]}"
  puts
  puts "Flags:"
  puts data[2]
  puts
  puts GLOBAL_FLAGS
end

def split_args(argv)
  global = { backend: ENV.fetch('CHAMBER_SECRET_BACKEND', 'ssm') }
  rest = []
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when '-b', '--backend'
      global[:backend] = argv[i + 1] || ''
      i += 2
    when /^--backend=(.*)/
      global[:backend] = Regexp.last_match(1)
      i += 1
    when '-r', '--retries', '--retry-mode', '--backend-s3-bucket', '--kms-key-alias'
      i += 2
    when /^--(retries|retry-mode|backend-s3-bucket|kms-key-alias)=/
      i += 1
    when '--verbose'
      i += 1
    else
      rest << a
      i += 1
    end
  end
  [global, rest]
end

def parse_flags(args, specs = {})
  flags = {}
  pos = []
  i = 0
  while i < args.length
    a = args[i]
    if a == '--'
      pos.concat(args[(i + 1)..] || [])
      break
    elsif specs.key?(a)
      name, takes = specs[a]
      if takes
        flags[name] = args[i + 1] || ''
        i += 2
      else
        flags[name] = true
        i += 1
      end
    elsif (m = a.match(/\A(--[^=]+)=(.*)\z/)) && specs.key?(m[1])
      flags[specs[m[1]][0]] = m[2]
      i += 1
    elsif a.start_with?('-') && a != '-'
      die "unknown flag: #{a}"
    else
      pos << a
      i += 1
    end
  end
  [flags, pos]
end

def require_n(pos, n, usage_cmd)
  return if pos.length == n
  warn "Error: accepts #{n} arg(s), received #{pos.length}"
  emit_help(usage_cmd)
  exit 1
end

def require_min(pos, n, msg = nil)
  die(msg || "requires at least #{n} arg(s), only received #{pos.length}") if pos.length < n
end

def load_store
  return {} unless File.exist?(STORE_FILE)
  JSON.parse(File.read(STORE_FILE))
rescue JSON::ParserError
  {}
end

def save_store(store)
  File.write(STORE_FILE, JSON.pretty_generate(store))
end

def svc(store, name)
  store[name] ||= {}
end

def entry(store, service, key)
  svc(store, service)[key]
end

def latest_value(e)
  e && e['versions'] && e['versions'].last && e['versions'].last['value']
end

def write_secret(store, service, key, value, tags = {}, skip = false)
  service_hash = svc(store, service)
  e = service_hash[key] ||= { 'versions' => [], 'tags' => tags }
  return false if skip && latest_value(e) == value
  e['tags'] = tags unless tags.empty? || e['versions'].any?
  e['versions'] << { 'value' => value, 'time' => Time.now.utc.strftime('%Y-%m-%dT%H:%M:%SZ'), 'user' => ENV['USER'] || 'agent' }
  true
end

def secrets_for(store, services)
  out = {}
  services.each do |s|
    (store[s] || {}).each { |k, e| out[k] = latest_value(e) }
  end
  out
end

def env_name(key, preserve = false)
  preserve ? key : key.upcase.gsub(/[^A-Z0-9_]/, '_')
end

def parse_tags(s)
  return {} if s.nil? || s.empty?
  s.split(',').each_with_object({}) do |pair, h|
    k, v = pair.split('=', 2)
    h[k] = v || ''
  end
end

def export_text(hash, format)
  case format
  when 'json'
    hash.empty? ? '{}' : JSON.pretty_generate(hash)
  when 'yaml'
    hash.empty? ? "{}\n" : hash.to_yaml
  when 'java-properties'
    hash.map { |k, v| "#{k}=#{v}" }.join("\n") + (hash.empty? ? '' : "\n")
  when 'csv'
    return '' if hash.empty?
    hash.map { |k, v| [k, v].map { |x| x.to_s.include?(',') ? x.to_s.inspect : x }.join(',') }.join("\n") + "\n"
  when 'tsv'
    hash.map { |k, v| "#{k}\t#{v}" }.join("\n") + (hash.empty? ? '' : "\n")
  when 'dotenv'
    hash.map { |k, v| "#{env_name(k)}=#{Shellwords.escape(v.to_s)}" }.join("\n") + (hash.empty? ? '' : "\n")
  when 'tfvars'
    hash.map { |k, v| "#{k} = #{v.to_s.inspect}" }.join("\n") + (hash.empty? ? '' : "\n")
  else
    die "Unable to export parameters: Unsupported export format: #{format}"
  end
end

def read_import(path)
  data = path == '-' ? STDIN.read : File.read(path)
  parsed = JSON.parse(data)
  parsed.is_a?(Hash) ? parsed : {}
rescue Errno::ENOENT
  die "Failed to open file: open #{path}: no such file or directory"
rescue JSON::ParserError
  y = YAML.safe_load(data, permitted_classes: [], aliases: true)
  y.is_a?(Hash) ? y : {}
end

global, argv = split_args(ARGV)
if argv.empty? || %w[-h --help].include?(argv.first)
  puts ROOT_HELP
  exit 0
end

cmd = argv.shift
cmd = argv.shift if cmd == 'help'
die "unknown flag: #{cmd}" if cmd&.start_with?('-')

if argv.include?('-h') || argv.include?('--help')
  if cmd == 'tag' && argv[0] && %w[read write delete].include?(argv[0])
    sub = argv[0]
    usage = { 'read' => 'chamber tag read <service> <key> [flags]', 'write' => 'chamber tag write <service> <key> <tag key=value>... [flags]', 'delete' => 'chamber tag delete <service> <key> <tag key>... [flags]' }[sub]
    desc = { 'read' => 'Read tags for a specific secret', 'write' => 'Write tags for a specific secret', 'delete' => 'Delete tags for a specific secret' }[sub]
    puts "#{desc}\n\nUsage:\n  #{usage}\n\nFlags:\n  -h, --help   help for #{sub}\n\n#{GLOBAL_FLAGS}"
  elsif %w[completion bash fish zsh powershell].include?(cmd) || cmd == 'completion'
    emit_help('completion')
  elsif cmd && (HELP.key?(cmd) || %w[tag completion].include?(cmd))
    emit_help(cmd)
  else
    puts ROOT_HELP
  end
  exit 0
end

backend_null = global[:backend] == 'null'

case cmd
when 'version'
  puts 'chamber dev'
when 'list'
  flags, pos = parse_flags(argv, '-e' => [:expand, false], '--expand' => [:expand, false], '-t' => [:time, false], '--time' => [:time, false], '-u' => [:user, false], '--user' => [:user, false], '-v' => [:version, false], '--version' => [:version, false])
  require_n(pos, 1, 'list')
  puts ['Key', 'Version', '', 'LastModified', 'User', (flags[:expand] ? 'Value' : nil)].compact.join("\t")
  unless backend_null
    (load_store[pos[0]] || {}).sort.each do |k, e|
      v = e['versions'].last || {}
      row = [k, e['versions'].length.to_s, '', v['time'], v['user']]
      row << v['value'] if flags[:expand]
      puts row.join("\t")
    end
  end
when 'read'
  flags, pos = parse_flags(argv, '-q' => [:quiet, false], '--quiet' => [:quiet, false], '-v' => [:version, true], '--version' => [:version, true])
  require_n(pos, 2, 'read')
  die 'Failed to read: Not implemented for Null Store' if backend_null
  e = entry(load_store, pos[0], pos[1])
  die 'Failed to read: secret not found' unless e
  idx = flags[:version] ? flags[:version].to_i - 1 : -1
  val = e['versions'][idx] && e['versions'][idx]['value']
  die 'Failed to read: secret not found' if val.nil?
  puts flags[:quiet] ? val : "#{pos[1]} = #{val}"
when 'write'
  flags, pos = parse_flags(argv, '-s' => [:single, false], '--singleline' => [:single, false], '--skip-unchanged' => [:skip, false], '-t' => [:tags, true], '--tags' => [:tags, true])
  die 'Write is not implemented for Null Store' if backend_null
  require_n(pos, 3, 'write')
  value = pos[2] == '-' ? STDIN.read : pos[2]
  value = value.lines.first.to_s.chomp if flags[:single]
  store = load_store
  wrote = write_secret(store, pos[0], pos[1], value, parse_tags(flags[:tags]), flags[:skip])
  save_store(store)
  puts wrote ? "Wrote #{pos[0]}/#{pos[1]}" : "Skipping #{pos[0]}/#{pos[1]} because it is unchanged"
when 'delete'
  _flags, pos = parse_flags(argv, '--exact-key' => [:exact, false])
  require_n(pos, 2, 'delete')
  die 'Not implemented for Null Store' if backend_null
  store = load_store
  (store[pos[0]] || {}).delete(pos[1])
  save_store(store)
when 'env'
  flags, pos = parse_flags(argv, '-p' => [:preserve, false], '--preserve-case' => [:preserve, false], '-e' => [:escape, false], '--escape-strings' => [:escape, false])
  require_n(pos, 1, 'env')
  secrets_for(load_store, [pos[0]]).sort.each do |k, v|
    val = flags[:escape] ? Shellwords.escape(v.to_s) : v
    puts "export #{env_name(k, flags[:preserve])}=#{val}"
  end unless backend_null
when 'export'
  flags, pos = parse_flags(argv, '-f' => [:format, true], '--format' => [:format, true], '-o' => [:output, true], '--output-file' => [:output, true])
  require_min(pos, 1, 'requires at least 1 arg(s), only received 0')
  text = backend_null ? export_text({}, flags[:format] || 'json') : export_text(secrets_for(load_store, pos), flags[:format] || 'json')
  flags[:output] ? File.write(flags[:output], text) : print(text + (text.end_with?("\n") || text.empty? ? '' : "\n"))
when 'import'
  flags, pos = parse_flags(argv, '--normalize-keys' => [:norm, false])
  require_n(pos, 2, 'import')
  data = read_import(pos[1])
  if backend_null && !data.empty?
    die 'Failed to write secret: Write is not implemented for Null Store'
  end
  unless backend_null
    store = load_store
    data.each { |k, v| write_secret(store, pos[0], flags[:norm] ? env_name(k.to_s).downcase : k.to_s, v.to_s) }
    save_store(store)
  end
  puts "Successfully imported #{data.length} secrets"
when 'exec'
  sep = argv.index('--')
  before = sep ? argv[0...sep] : argv
  command = sep ? argv[(sep + 1)..] : []
  flags, services = parse_flags(before, '--pristine' => [:pristine, false], '--strict' => [:strict, false], '--strict-value' => [:strict_value, true])
  require_min(services, 1)
  require_min(command, 1, 'requires a command to execute')
  secrets = backend_null ? {} : secrets_for(load_store, services)
  base_env = ENV.to_h
  env = flags[:pristine] ? {} : base_env.dup
  strict_value = flags[:strict_value] || 'chamberme'
  if flags[:strict]
    wanted = base_env.select { |_k, v| v == strict_value }.keys
    secrets = secrets.select { |k, _| wanted.include?(env_name(k)) }
    missing = wanted - secrets.keys.map { |k| env_name(k) }
    die "#{missing.first.downcase} unfilled env var #{missing.first}" unless missing.empty?
  end
  secrets.each { |k, v| env[env_name(k)] = v.to_s }
  exec(env, *command)
when 'find'
  flags, pos = parse_flags(argv, '-v' => [:by_value, false], '--by-value' => [:by_value, false])
  require_n(pos, 1, 'find')
  puts(flags[:by_value] ? "Service\t\tKey" : 'Service')
  unless backend_null
    load_store.sort.each do |s, keys|
      keys.sort.each do |k, e|
        if flags[:by_value] ? latest_value(e).to_s.include?(pos[0]) : k.include?(pos[0])
          puts(flags[:by_value] ? "#{s}\t\t#{k}" : s)
        end
      end
    end
  end
when 'history'
  _flags, pos = parse_flags(argv)
  require_n(pos, 2, 'history')
  puts "Event\tVersion\t\tDate\tUser"
  unless backend_null
    e = entry(load_store, pos[0], pos[1])
    (e && e['versions'] || []).each_with_index { |v, i| puts "write\t#{i + 1}\t\t#{v['time']}\t#{v['user']}" }
  end
when 'list-services'
  flags, pos = parse_flags(argv, '-s' => [:secrets, false], '--secrets' => [:secrets, false])
  # The original accepts and ignores a single argument in help text; no arg also works usefully here.
  puts(flags[:secrets] ? "Service\t\tKey" : 'Service')
  unless backend_null
    load_store.sort.each do |s, keys|
      if flags[:secrets]
        keys.keys.sort.each { |k| puts "#{s}\t\t#{k}" }
      else
        puts s
      end
    end
  end
when 'tag'
  sub = argv.shift
  emit_help('tag') && exit(0) unless sub
  case sub
  when 'read'
    _flags, pos = parse_flags(argv)
    require_n(pos, 2, 'read')
    die 'Failed to read tags: Not implemented for Null Store' if backend_null
    e = entry(load_store, pos[0], pos[1])
    (e && e['tags'] || {}).sort.each { |k, v| puts "#{k}=#{v}" }
  when 'write'
    _flags, pos = parse_flags(argv)
    require_min(pos, 3)
    die 'Failed to write tags: Not implemented for Null Store' if backend_null
    store = load_store
    e = entry(store, pos[0], pos[1]) || (svc(store, pos[0])[pos[1]] = { 'versions' => [], 'tags' => {} })
    e['tags'].merge!(parse_tags(pos[2..].join(',')))
    save_store(store)
  when 'delete'
    _flags, pos = parse_flags(argv)
    require_min(pos, 3)
    die 'Failed to delete tags: Not implemented for Null Store' if backend_null
    store = load_store
    e = entry(store, pos[0], pos[1])
    pos[2..].each { |k| e['tags'].delete(k) } if e
    save_store(store)
  else
    die "unknown command #{sub.inspect} for \"chamber tag\""
  end
when 'completion'
  sub = argv.first
  if %w[bash zsh fish powershell].include?(sub)
    puts "# #{sub} completion for chamber"
  else
    emit_help('completion')
  end
else
  die "unknown command #{cmd.inspect} for \"chamber\"\nRun 'chamber --help' for usage."
end
