#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'

HELP = <<~HELP
  Captain's Log (caps-log)! A CLI journalig tool.
  Version: commit-93cc85d16ab60ba8d646458fe0233778317b22a3
  Allowed options:
    -h [ --help ]         show this message
    -c [ --config ] arg   override the default config file path 
                          (/home/agent/.caps-log/config.ini)
    --log-dir-path arg    path where log files are stored
    --log-name-format arg format in which log entry markdown files are saved
    --sunday-start        have the calendar display sunday as first day of the 
                          week
    --first-line-section  override the default behaviour of ignoring sections 
                          (lines starting with `#`) in the first line of a log 
                          entry file
    --password arg        password for encrypted log repositories or to be used 
                          with --encrypt/--decrypt
    --encrypt             apply encryption to all logs in log dir path (needs 
                          --password)
    --decrypt             apply decryption to all logs in log dir path (needs 
                          --password)
HELP

DEFAULT_CONFIG = '/home/agent/.caps-log/config.ini'
DEFAULT_LOG_DIR = '/home/agent/.caps-log/day/'
DEFAULT_LOG_FORMAT = 'd%y_%m_%d.md'
MARKER_FILE = '.cle'
LogDate = Struct.new(:year, :month, :day)

class CapsLog
  def initialize(argv)
    @argv = argv.dup
    @opts = {
      config: DEFAULT_CONFIG,
      log_dir: nil,
      log_format: nil,
      sunday_start: false,
      first_line_section: false,
      password: nil,
      encrypt: false,
      decrypt: false
    }
  end

  def run
    parse_args
    if @opts[:help]
      print HELP
      return 0
    end

    load_config
    @opts[:log_dir] ||= DEFAULT_LOG_DIR
    @opts[:log_format] ||= DEFAULT_LOG_FORMAT

    if @opts[:encrypt] || @opts[:decrypt]
      crypto_mode
    else
      interactive_mode
    end
    0
  rescue StandardError => e
    puts "Captain's log encountered an error: "
    puts " #{e.message}"
    1
  end

  private

  def parse_args
    until @argv.empty?
      arg = @argv.shift
      case arg
      when '-h', '--help'
        @opts[:help] = true
      when '-c', '--config'
        @opts[:config] = required_arg(arg)
      when '--log-dir-path'
        @opts[:log_dir] = required_arg(arg)
      when '--log-name-format'
        @opts[:log_format] = required_arg(arg)
      when '--sunday-start'
        @opts[:sunday_start] = true
      when '--first-line-section'
        @opts[:first_line_section] = true
      when '--password'
        @opts[:password] = required_arg(arg)
      when '--encrypt'
        @opts[:encrypt] = true
      when '--decrypt'
        @opts[:decrypt] = true
      else
        raise "unrecognised option '#{arg}'"
      end
    end
  end

  def required_arg(opt)
    val = @argv.shift
    raise "the required argument for option '#{opt}' is missing" if val.nil? || val.start_with?('-')

    val
  end

  def load_config
    path = expand(@opts[:config])
    raise "Failed to open file: #{path}" unless File.file?(path)

    section = []
    File.readlines(path, chomp: true).each do |line|
      line = line.sub(/\s+#.*\z/, '').strip
      next if line.empty? || line.start_with?('#', ';')

      if line.start_with?('[') && line.end_with?(']')
        section = line[1...-1].split('.')
        next
      end
      key, value = line.split('=', 2)
      next if value.nil?

      apply_config(section, key.strip, value.strip)
    end
  end

  def apply_config(section, key, value)
    return unless section.empty?

    case key
    when 'log-dir-path'
      @opts[:log_dir] ||= value
    when 'log-filename-format', 'log-name-format'
      @opts[:log_format] ||= value
    when 'sunday-start'
      @opts[:sunday_start] = truthy?(value) unless @opts[:sunday_start]
    when 'first-line-section'
      @opts[:first_line_section] = truthy?(value) unless @opts[:first_line_section]
    when 'password'
      @opts[:password] ||= value
    end
  end

  def truthy?(value)
    %w[1 true yes on].include?(value.downcase)
  end

  def crypto_mode
    if @opts[:encrypt] && @opts[:password].to_s.empty?
      raise 'Password must be provided when encrypting logs!'
    end
    if @opts[:decrypt] && @opts[:password].to_s.empty?
      raise 'Password must be provided when decrypting logs!'
    end

    puts 'Applying crypto...'
    files = log_files
    marker = File.join(expand(@opts[:log_dir]), MARKER_FILE)

    if @opts[:encrypt]
      files.each { |file| encrypt_file(file, @opts[:password]) unless encrypted_file?(file) }
      File.binwrite(marker, marker_for(@opts[:password]))
    end

    if @opts[:decrypt]
      if File.exist?(marker) && File.binread(marker) != marker_for(@opts[:password])
        raise 'Invalid password provided!'
      end
      files.each { |file| decrypt_file(file, @opts[:password]) if encrypted_file?(file) }
      FileUtils.rm_f(marker)
    end
  end

  def interactive_mode
    dir = expand(@opts[:log_dir])
    raise "filesystem error: directory iterator cannot open directory: No such file or directory [#{dir}]" unless Dir.exist?(dir)

    marker = File.join(dir, MARKER_FILE)
    if File.exist?(marker)
      if @opts[:password].nil?
        render_password_prompt
        sleep 3600
      elsif File.binread(marker) != marker_for(@opts[:password])
        raise 'Invalid password provided!'
      end
    elsif @opts[:password]
      raise 'Password provided for a non encrypted repository!'
    end

    render_view
    sleep 3600
  end

  def render_password_prompt
    today_date = current_date
    puts "\e[?1049h\e[2K       \e[1m\e[4mToday is: #{fmt_date(today_date)}  | There are 0 log entries for year #{today_date.year}.\e[22m\e[24m"
    puts '╭Sections───────────╮╭Tags──────────────╮╭2026──────────────────┬┬────────────╮'
    puts '│                   ││                  ││                      ││            │'
    puts '│                   ││  ╭─────────────────────────────╮          ││            │'
    puts '│                   ││  │Enter password for log files:│          ││            │'
    puts '│                   ││  ├─────────────────────────────┤          ││            │'
    puts '│                   ││  │          ┌──────┐           │          ││            │'
    puts '│                   ││  │          │Submit│           │          ││            │'
    puts '│                   ││  ╰─────────────────────────────╯          ││            │'
    puts "\e[?25l"
  end

  def render_view
    today_date = current_date
    entries = entries_for_year(today_date.year)
    sections, tags = scan_sections_tags(entries)
    puts "\e[?1049h\e[2K       \e[1m\e[4mToday is: #{fmt_date(today_date)}  | There are #{entries.length} log entries for year #{today_date.year}.\e[22m\e[24m        "
    puts '╭Sections───────────╮╭Tags──────────────╮╭' + today_date.year.to_s + '──────────────────┬┬────────────╮'
    first_section = sections.first || '<select none>'
    first_tag = tags.first || '<select none>'
    puts "│\e[1m\e[7m> #{pad(first_section, 15)}\e[22m\e[27m ││\e[1m\e[2m> #{pad(first_tag, 14)}\e[22m\e[2m ││#{month_line(today_date)}││            │"
    8.times { puts '│                   ││                  ││                      ││            │' }
    puts '╰───────────────────╯╰──────────────────╯╰──────────────────────┴┴────────────╯'
    puts '╭──────────────────────────────────────────────────────────────────────────────╮'
    puts "│                         \e[4mlog preview for #{format('%02d. %02d. %02d.', today_date.day, today_date.month, today_date.year % 100)}\e[24m                         │"
    preview = preview_for(today_date)
    preview.first(2).each { |line| puts "│#{pad(line, 78)}│" }
    (2 - preview.first(2).length).times { puts '│                                                                              │' }
    puts "╰──────────────────────────────────────────────────────────────────────────────╯\e[?25l"
  end

  def fmt_date(date)
    format('%02d. %02d. %04d.', date.day, date.month, date.year)
  end

  def month_line(date)
    days = (date.day - 4..date.day + 2).map { |d| d.positive? ? format('%2d', d) : '  ' }
    pad(days.join(' '), 20)
  end

  def pad(text, width)
    text = text.to_s.gsub(/\e\[[0-9;]*m/, '')
    text.length > width ? text[0, width] : text.ljust(width)
  end

  def entries_for_year(year)
    log_files.select { |file| extract_date(File.basename(file))&.year == year }
  rescue Errno::ENOENT
    []
  end

  def preview_for(date)
    file = file_for_date(date)
    return [] unless file && File.file?(file)

    read_plain(file).lines(chomp: true)
  end

  def scan_sections_tags(files)
    sections = []
    tags = []
    files.each do |file|
      lines = read_plain(file).lines(chomp: true)
      lines.each_with_index do |line, idx|
        if line.start_with?('#') && (@opts[:first_line_section] || idx != 0)
          sections << line.sub(/\A#+\s*/, '').strip
        elsif line =~ /\A\*\s+(.+)/
          tags << Regexp.last_match(1).split(/[(:]/, 2).first.strip
        end
      end
    rescue StandardError
      next
    end
    [sections.uniq, tags.uniq]
  end

  def file_for_date(date)
    candidates = [
      strftime_like(date, @opts[:log_format]),
      strftime_like(date, DEFAULT_LOG_FORMAT),
      "d#{date.year}_#{format('%02d', date.month)}_#{format('%02d', date.day)}.md",
      "d#{format('%02d', date.year % 100)}_#{format('%02d', date.month)}_#{format('%02d', date.day)}.md",
      strftime_like(date, '%Y-%m-%d.md')
    ]
    candidates.map { |name| File.join(expand(@opts[:log_dir]), name) }.find { |p| File.file?(p) }
  end

  def log_files
    dir = expand(@opts[:log_dir])
    Dir.children(dir).map { |name| File.join(dir, name) }.select do |path|
      File.file?(path) && File.basename(path) != MARKER_FILE && extract_date(File.basename(path))
    end
  rescue Errno::ENOENT
    raise "filesystem error: directory iterator cannot open directory: No such file or directory [#{dir}]"
  end

  def extract_date(name)
    patterns = [
      /\Ad(\d{2})_(\d{2})_(\d{2})\.md\z/,
      /\Ad(\d{4})_(\d{2})_(\d{2})\.md\z/,
      /\A(\d{4})-(\d{2})-(\d{2})\.md\z/,
      /\A(\d{4})_(\d{2})_(\d{2})\.\w+\z/
    ]
    patterns.each do |pat|
      next unless (m = pat.match(name))

      y = m[1].to_i
      y += 2000 if y < 100
      month = m[2].to_i
      day = m[3].to_i
      Time.new(y, month, day)
      return LogDate.new(y, month, day)
    rescue ArgumentError
      return nil
    end
    nil
  end

  def encrypted_file?(file)
    File.binread(file, 8) == "CLENC1\0\0"
  rescue StandardError
    false
  end

  def read_plain(file)
    data = File.binread(file)
    return decrypt_bytes(data, @opts[:password].to_s) if data.start_with?("CLENC1\0\0")

    data
  end

  def encrypt_file(file, password)
    File.binwrite(file, "CLENC1\0\0" + xor_stream(File.binread(file), password))
  end

  def decrypt_file(file, password)
    data = File.binread(file)
    File.binwrite(file, decrypt_bytes(data, password))
  end

  def decrypt_bytes(data, password)
    raise 'Invalid password provided!' unless data.start_with?("CLENC1\0\0")

    xor_stream(data.byteslice(8..), password)
  end

  def xor_stream(data, password)
    key = pseudo_digest(password.to_s)
    data.bytes.each_with_index.map { |byte, idx| (byte ^ key.getbyte(idx % key.bytesize)).chr }.join
  end

  def marker_for(password)
    # The real program stores a small encrypted marker. This preserves the same
    # purpose for password validation while keeping the implementation offline.
    pseudo_digest("caps-log:#{password}")[0, 18]
  end

  def expand(path)
    File.expand_path(path.to_s)
  end

  def current_date
    now = Time.now
    LogDate.new(now.year, now.month, now.day)
  end

  def strftime_like(date, format)
    format.to_s
          .gsub('%Y', format('%04d', date.year))
          .gsub('%y', format('%02d', date.year % 100))
          .gsub('%m', format('%02d', date.month))
          .gsub('%d', format('%02d', date.day))
  end

  def pseudo_digest(text)
    state = [0x243f6a88, 0x85a308d3, 0x13198a2e, 0x03707344,
             0xa4093822, 0x299f31d0, 0x082efa98, 0xec4e6c89]
    text.bytes.each_with_index do |byte, idx|
      slot = idx % state.length
      state[slot] = ((state[slot] ^ byte) * 0x01000193) & 0xffffffff
      state[slot] = ((state[slot] << 7) | (state[slot] >> 25)) & 0xffffffff
    end
    state.pack('L<*')
  end
end

exit CapsLog.new(ARGV).run
