#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = '2.6.0-g87c9c25'
NCURSES_VERSION = '6.3.20211021'

HELP = <<~TEXT
  tig #{VERSION} 

  Usage: tig        [options] [revs] [--] [paths]
     or: tig log    [options] [revs] [--] [paths]
     or: tig show   [options] [revs] [--] [paths]
     or: tig reflog [options] [revs]
     or: tig blame  [options] [rev] [--] path
     or: tig grep   [options] [pattern]
     or: tig refs   [options]
     or: tig stash  [options]
     or: tig status
     or: tig <      [git command output]

  Options:
    +<number>       Select line <number> in the first view
    -v, --version   Show version and exit
    -h, --help      Show help message and exit
    -C <path>       Start in <path>
TEXT

COMMANDS = %w[log show reflog blame grep refs stash status].freeze

def say_version
  puts "tig version #{VERSION}"
  puts "ncursesw version #{NCURSES_VERSION}"
end

def say_help
  print HELP
end

def fail_message(message)
  warn "tig: #{message}"
  exit 1
end

def run_git(argv)
  system('git', *argv)
  $?.exitstatus || 1
end

def git_success?(*argv)
  system('git', *argv, out: File::NULL, err: File::NULL)
end

def parse_global_options(args)
  parsed = []
  i = 0
  while i < args.length
    arg = args[i]
    case arg
    when '-C'
      path = args[i + 1]
      fail_message('Failed to open tty for input') if path.nil?
      Dir.chdir(path) rescue fail_message("Failed to change directory to #{path}")
      i += 2
    when /^-C(.+)/
      path = Regexp.last_match(1)
      path = path[1..] if path.start_with?('=')
      Dir.chdir(path) rescue fail_message("Failed to change directory to #{path}")
      i += 1
    else
      parsed << arg
      i += 1
    end
  end
  parsed
end

def tty_available?
  STDIN.tty? && STDOUT.tty?
end

def no_tty!
  fail_message('Failed to open tty for input')
end

def revision_or_path_exists?(arg)
  return true if File.exist?(arg)
  git_success?('rev-parse', '--verify', '--quiet', arg)
end

args = parse_global_options(ARGV.dup)

# Tig honors the first terminal action option it sees during normal option parsing.
args.each do |arg|
  case arg
  when '-v', '--version'
    say_version
    exit 0
  when '-h', '--help'
    say_help
    exit 0
  end
end

cmd = nil
if args.first && COMMANDS.include?(args.first)
  cmd = args.shift
end

if args.first && args.first.start_with?('+') && args.first !~ /^\+\d+$/
  fail_message('No revisions match the given arguments.')
end

if cmd.nil? && args.first && !args.first.start_with?('-') && args.first != '--'
  unless revision_or_path_exists?(args.first)
    fail_message('No revisions match the given arguments.')
  end
end

unless tty_available?
  if cmd == 'status' && !git_success?('rev-parse', '--git-dir')
    say_help
    exit 1
  end
  no_tty!
end

# A lightweight text-mode fallback for interactive use. It is intentionally not a
# curses clone, but it exposes the documented subcommands through Git.
case cmd
when 'log', nil
  exit run_git(['log', '--oneline', '--decorate', *args])
when 'show'
  exit run_git(['show', *args])
when 'reflog'
  exit run_git(['reflog', *args])
when 'blame'
  exit run_git(['blame', *args])
when 'grep'
  exit run_git(['grep', *args])
when 'refs'
  exit run_git(['show-ref', *args])
when 'stash'
  exit run_git(['stash', 'list', *args])
when 'status'
  exit run_git(['status', '--short', *args])
else
  no_tty!
end
