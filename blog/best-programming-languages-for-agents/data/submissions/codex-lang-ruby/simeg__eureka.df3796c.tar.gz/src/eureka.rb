#!/usr/bin/env ruby

require 'fileutils'
require 'shellwords'

GREEN_PROMPT = "\e[0m\e[1m\e[32m"
YELLOW = "\e[0m\e[33m"
RESET = "\e[0m"

def config_dir
  if ENV['XDG_CONFIG_HOME'] && !ENV['XDG_CONFIG_HOME'].empty?
    File.join(ENV['XDG_CONFIG_HOME'], 'eureka')
  else
    File.join(Dir.home, '.config', 'eureka')
  end
end

def config_path
  File.join(config_dir, 'config.json')
end

def ensure_cache
  base = ENV['XDG_CACHE_HOME'] && !ENV['XDG_CACHE_HOME'].empty? ? ENV['XDG_CACHE_HOME'] : File.join(Dir.home, '.cache')
  FileUtils.mkdir_p(File.join(base, 'rosetta'))
rescue StandardError
end

def error(message)
  warn " ERROR eureka > #{message}"
  exit 0
end

def read_config
  ensure_cache
  data = File.read(config_path)
  match = data.match(/\A\s*\{\s*"repo"\s*:\s*"((?:\\.|[^"\\])*)"\s*\}\s*\z/)
  raise 'expected ident at line 1 column 2' unless match
  { 'repo' => match[1].gsub(/\\(["\\\/])/, '\1') }
rescue Errno::ENOENT
  error('No such file or directory (os error 2)')
rescue StandardError => e
  error(e.message)
end

def help
  puts <<~TEXT
    Input and store your ideas without leaving the terminal

    Usage: executable [OPTIONS]

    Options:
          --clear-config  Clear your stored configuration
      -v, --view          View ideas with your $PAGER env variable. If unset use less
      -h, --help          Print help
      -V, --version       Print version
  TEXT
end

def first_time_setup
  ensure_cache
  FileUtils.mkdir_p(config_dir)
  print YELLOW
  puts "############################################################"
  puts "####                  First Time Setup                  ####"
  puts "############################################################"
  puts
  puts "This tool requires you to have a repository with a README.md"
  puts "in the root folder. The markdown file is where your ideas"
  puts "will be stored."
  puts
  puts "Once first time setup has completed, simply run Eureka again"
  puts "to begin writing down ideas."
  puts "        "
  print RESET

  repo = nil
  loop do
    print "#{GREEN_PROMPT}Absolute path to your idea repo\n#{RESET}> "
    STDOUT.flush
    line = STDIN.gets
    repo = line&.chomp
    break if repo && !repo.empty?
  end

  escaped = repo.gsub('\\', '\\\\\\').gsub('"', '\\"')
  File.write(config_path, "{\"repo\":\"#{escaped}\"}")
  puts "First time setup complete. Happy ideation!"
end

def clear_config
  ensure_cache
  FileUtils.rm_f(config_path)
end

def view_ideas
  repo = read_config.fetch('repo')
  readme = File.join(repo, 'README.md')
  pager = ENV['PAGER']
  pager = 'less' if pager.nil? || pager.empty?
  system(pager, readme)
end

def prompt_summary
  summary = nil
  loop do
    print "#{GREEN_PROMPT}>> Idea summary\n#{RESET}> "
    STDOUT.flush
    line = STDIN.gets
    summary = line&.chomp
    break if summary && !summary.empty?
  end
  summary
end

def run_editor(path)
  editor = ENV['EDITOR']
  editor = ENV['VISUAL'] if editor.nil? || editor.empty?
  editor = 'vi' if editor.nil? || editor.empty?
  system("#{editor} #{Shellwords.escape(path)}")
end

def git_output(repo, *args)
  `git -C #{Shellwords.escape(repo)} #{args.map { |a| Shellwords.escape(a) }.join(' ')} 2>&1`
end

def capture_idea
  cfg = read_config
  repo = cfg.fetch('repo')
  readme = File.join(repo, 'README.md')
  summary = prompt_summary

  unless system('git', '-C', repo, 'rev-parse', '--git-dir', out: File::NULL, err: File::NULL)
    error("could not find repository from '#{repo}'; class=Repository (6); code=NotFound (-3)")
  end

  run_editor(readme)
  puts 'Adding and committing your new idea to main..'
  system('git', '-C', repo, 'add', 'README.md', out: File::NULL, err: File::NULL)
  commit_ok = system('git', '-C', repo, 'commit', '--allow-empty', '-m', summary, out: File::NULL, err: File::NULL)
  unless commit_ok
    error("reference 'refs/heads/master' not found; class=Reference (4); code=UnbornBranch (-9)")
  end
  puts 'Added and committed!'
  puts 'Pushing your new idea..'
  push_out = git_output(repo, 'push', 'origin', 'HEAD')
  unless $?.success?
    if push_out.include?("does not appear to be a git repository") || push_out.include?("'origin' does not exist")
      error("remote 'origin' does not exist; class=Config (7); code=NotFound (-3)")
    else
      error(push_out.lines.first.to_s.strip.empty? ? 'failed to push' : push_out.lines.first.strip)
    end
  end
  puts 'Pushed!'
end

args = ARGV.dup

if args.include?('-h') || args.include?('--help')
  help
  exit 0
end

if args.include?('-V') || args.include?('--version')
  puts 'eureka 2.0.0'
  exit 0
end

allowed = ['--clear-config', '-v', '--view']
bad = args.find { |a| !allowed.include?(a) }
if bad
  warn "error: unexpected argument '#{bad}' found"
  warn
  warn 'Usage: executable [OPTIONS]'
  warn
  warn "For more information, try '--help'."
  exit 2
end

if args.include?('--clear-config')
  clear_config
elsif args.include?('-v') || args.include?('--view')
  view_ideas
elsif File.exist?(config_path)
  capture_idea
else
  first_time_setup
end
