#!/usr/bin/env ruby
# frozen_string_literal: true

require "net/http"
require "openssl"
require "set"
require "uri"

VERSION = "2.11.1"

HELP = <<~HELP
  Usage:
    executable [options] <url>

  Application Options:
        --accepted-status-codes=<codes>       Accepted HTTP response status codes
                                              (e.g. '200..300,403') (default:
                                              200..300)
    -b, --buffer-size=<size>                  HTTP response buffer size in bytes
                                              (default: 4096)
    -c, --max-connections=<count>             Maximum number of HTTP connections
                                              (default: 512)
        --max-connections-per-host=<count>    Maximum number of HTTP connections
                                              per host (default: 512)
        --max-response-body-size=<size>       Maximum response body size to read
                                              (default: 10000000)
    -e, --exclude=<pattern>...                Exclude URLs matched with given
                                              regular expressions
    -i, --include=<pattern>...                Include URLs matched with given
                                              regular expressions
        --follow-robots-txt                   Follow robots.txt when scraping
                                              pages
        --follow-sitemap-xml                  Scrape only pages listed in
                                              sitemap.xml (deprecated)
        --header=<header>...                  Custom headers
    -f, --ignore-fragments                    Ignore URL fragments
        --max-retries=<count>                 Maximum retry count for network
                                              errors (default: 0)
        --dns-resolver=<address>              Custom DNS resolver
        --format=[text|json|junit]            Output format (default: text)
        --json                                Output results in JSON (deprecated)
        --experimental-verbose-json           Include successful results in JSON
                                              (deprecated)
        --junit                               Output results as JUnit XML file
                                              (deprecated)
    -r, --max-redirections=<count>            Maximum number of redirections
                                              (default: 64)
        --rate-limit=<rate>                   Max requests per second
    -t, --timeout=<seconds>                   Timeout for HTTP requests in
                                              seconds (default: 10)
    -v, --verbose                             Show successful results too
        --proxy=<host>                        HTTP proxy host
        --skip-tls-verification               Skip TLS certificate verification
        --one-page-only                       Only check links found in the given
                                              URL
        --color=[auto|always|never]           Color output (default: auto)
    -h, --help                                Show this help
        --version                             Show version
HELP

class Options
  attr_accessor :accepted, :excludes, :includes, :headers, :format, :verbose,
                :ignore_fragments, :one_page_only, :timeout, :max_redirects,
                :skip_tls, :proxy, :max_body

  def initialize
    @accepted = [[200, 300]]
    @excludes = []
    @includes = []
    @headers = {}
    @format = "text"
    @verbose = false
    @ignore_fragments = false
    @one_page_only = false
    @timeout = 10
    @max_redirects = 64
    @skip_tls = false
    @proxy = nil
    @max_body = 10_000_000
  end
end

Link = Struct.new(:url, :status, :error, keyword_init: true) do
  def failed?
    !error.nil?
  end

  def to_h
    status ? { "url" => url, "status" => status } : { "url" => url, "error" => error }
  end
end

Page = Struct.new(:url, :links, keyword_init: true)

def parse_accepted(value)
  value.split(",").map do |part|
    if part.include?("..")
      a, b = part.split("..", 2).map(&:to_i)
      [a, b]
    else
      n = part.to_i
      [n, n]
    end
  end
end

def accepted?(code, ranges)
  ranges.any? { |a, b| code >= a && code <= b }
end

def parse_args(argv)
  opts = Options.new
  urls = []
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when "-h", "--help"
      puts HELP
      exit 0
    when "--version"
      puts VERSION
      exit 0
    when "-v", "--verbose"
      opts.verbose = true
    when "-f", "--ignore-fragments"
      opts.ignore_fragments = true
    when "--one-page-only"
      opts.one_page_only = true
    when "--skip-tls-verification"
      opts.skip_tls = true
    when "--json"
      opts.format = "json"
    when "--experimental-verbose-json"
      opts.format = "json"
      opts.verbose = true
    when "--junit"
      opts.format = "junit"
    when /\A--format=(.*)\z/
      value = Regexp.last_match(1)
      unless %w[text json junit].include?(value)
        warn "Invalid value `#{value}' for option `--format'. Allowed values are: text, json or junit"
        exit 1
      end
      opts.format = value
    when "--format"
      value = argv[i += 1]
      unless %w[text json junit].include?(value)
        warn "Invalid value `#{value}' for option `--format'. Allowed values are: text, json or junit"
        exit 1
      end
      opts.format = value
    when /\A--accepted-status-codes=(.*)\z/
      opts.accepted = parse_accepted(Regexp.last_match(1))
    when "--accepted-status-codes"
      opts.accepted = parse_accepted(argv[i += 1])
    when "-e", "--exclude"
      opts.excludes << Regexp.new(argv[i += 1])
    when /\A--exclude=(.*)\z/
      opts.excludes << Regexp.new(Regexp.last_match(1))
    when "-i", "--include"
      opts.includes << Regexp.new(argv[i += 1])
    when /\A--include=(.*)\z/
      opts.includes << Regexp.new(Regexp.last_match(1))
    when /\A--header=(.*)\z/
      add_header(opts, Regexp.last_match(1))
    when "--header"
      add_header(opts, argv[i += 1])
    when "-t", "--timeout"
      opts.timeout = argv[i += 1].to_f
    when /\A--timeout=(.*)\z/
      opts.timeout = Regexp.last_match(1).to_f
    when "-r", "--max-redirections"
      opts.max_redirects = argv[i += 1].to_i
    when /\A--max-redirections=(.*)\z/
      opts.max_redirects = Regexp.last_match(1).to_i
    when /\A--max-response-body-size=(.*)\z/
      opts.max_body = Regexp.last_match(1).to_i
    when "--max-response-body-size"
      opts.max_body = argv[i += 1].to_i
    when /\A--proxy=(.*)\z/
      opts.proxy = Regexp.last_match(1)
    when "--proxy"
      opts.proxy = argv[i += 1]
    when /\A--(buffer-size|max-connections|max-connections-per-host|max-retries|dns-resolver|rate-limit|color)(=.*)?\z/,
         "-b", "-c"
      i += 1 if %w[-b -c].include?(arg) || !arg.include?("=")
    when "--follow-robots-txt", "--follow-sitemap-xml"
      # Accepted for CLI compatibility. The core local-link behavior is unchanged.
    when /\A-/
      warn "unknown flag `#{arg.sub(/\A--?/, "")}'"
      exit 1
    else
      urls << arg
    end
    i += 1
  end
  if urls.length != 1
    warn "invalid number of arguments"
    exit 1
  end
  [opts, normalize_start_url(urls.first)]
end

def add_header(opts, raw)
  key, value = raw.to_s.split(":", 2)
  opts.headers[key.strip] = value.to_s.strip unless key.to_s.empty?
end

def normalize_start_url(raw)
  uri = URI.parse(raw)
  uri.path = "/" if uri.path.nil? || uri.path.empty?
  uri.to_s
rescue URI::InvalidURIError
  raw
end

def allowed_by_filters?(url, opts)
  return false if opts.excludes.any? { |re| re.match?(url) }
  return true if opts.includes.empty?

  opts.includes.any? { |re| re.match?(url) }
end

def same_site?(a, b)
  ua = URI.parse(a)
  ub = URI.parse(b)
  ua.scheme == ub.scheme && ua.host == ub.host && ua.port == ub.port
rescue URI::InvalidURIError
  false
end

def canonical_page_url(url)
  uri = URI.parse(url)
  uri.fragment = nil
  uri.to_s
rescue URI::InvalidURIError
  url
end

def html_like?(content_type, url)
  return true if content_type.to_s.downcase.include?("text/html")
  return true if URI.parse(url).path =~ %r{/(?:index)?$|\.html?\z}i

  false
rescue URI::InvalidURIError
  false
end

def fetch_url(url, opts, redirects = 0)
  uri = URI.parse(url)
  raise "unsupported protocol scheme #{uri.scheme}" unless %w[http https].include?(uri.scheme)

  proxy_uri = opts.proxy && URI.parse(opts.proxy)
  http_class = if proxy_uri
                 Net::HTTP::Proxy(proxy_uri.host, proxy_uri.port, proxy_uri.user, proxy_uri.password)
               else
                 Net::HTTP
               end
  http = http_class.new(uri.host, uri.port)
  http.use_ssl = uri.scheme == "https"
  http.verify_mode = OpenSSL::SSL::VERIFY_NONE if http.use_ssl? && opts.skip_tls
  http.open_timeout = opts.timeout
  http.read_timeout = opts.timeout
  path = uri.request_uri.empty? ? "/" : uri.request_uri
  response = http.start do |h|
    req = Net::HTTP::Get.new(path)
    opts.headers.each { |k, v| req[k] = v }
    h.request(req)
  end
  if response.is_a?(Net::HTTPRedirection) && response["location"] && redirects < opts.max_redirects
    return fetch_url(URI.join(url, response["location"]).to_s, opts, redirects + 1)
  end
  body = response.body.to_s.byteslice(0, opts.max_body).to_s
  [response.code.to_i, response["content-type"].to_s, body]
rescue StandardError => e
  raise e.message
end

def extract_links(html, base)
  links = []
  html.scan(/<\s*(a|link|script|img|iframe|source|video|audio|embed|object|area|form)\b([^>]*)>/im) do |tag, attrs|
    attr = %w[script img iframe source video audio embed].include?(tag.downcase) ? "src" : "href"
    attr = "action" if tag.downcase == "form"
    if attrs =~ /\b#{attr}\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/im
      links << resolve_url(base, Regexp.last_match(1) || Regexp.last_match(2) || Regexp.last_match(3))
    end
    if attrs =~ /\bsrcset\s*=\s*(?:"([^"]*)"|'([^']*)')/im
      (Regexp.last_match(1) || Regexp.last_match(2)).split(",").each do |part|
        links << resolve_url(base, part.strip.split(/\s+/).first)
      end
    end
  end
  links.compact.uniq
end

def resolve_url(base, raw)
  return nil if raw.nil? || raw.empty?
  return nil if raw =~ /\A(?:mailto|tel|javascript|data):/i

  URI.join(base, raw).to_s
rescue URI::InvalidURIError
  raw
end

def fragment_exists?(html, fragment)
  decoded = URI.decode_www_form_component(fragment.to_s)
  html.match?(/\b(?:id|name)\s*=\s*(?:"#{Regexp.escape(decoded)}"|'#{Regexp.escape(decoded)}'|#{Regexp.escape(decoded)})(?:\s|>)/i)
end

def check_link(url, opts, page_cache)
  check_url = opts.ignore_fragments ? canonical_page_url(url) : url
  nofrag = canonical_page_url(check_url)
  begin
    status, type, body = page_cache[nofrag] ||= fetch_url(nofrag, opts)
    if !accepted?(status, opts.accepted)
      Link.new(url: check_url, error: status.to_s)
    elsif !opts.ignore_fragments && URI.parse(check_url).fragment && html_like?(type, nofrag) && !fragment_exists?(body, URI.parse(check_url).fragment)
      Link.new(url: check_url, error: "id ##{URI.parse(check_url).fragment} not found")
    else
      Link.new(url: check_url, status: status)
    end
  rescue StandardError => e
    Link.new(url: check_url, error: e.message)
  end
end

def crawl(start_url, opts)
  queue = [start_url]
  seen_pages = Set.new
  pages = []
  page_cache = {}

  until queue.empty?
    page_url = canonical_page_url(queue.shift)
    next if seen_pages.include?(page_url)
    next unless allowed_by_filters?(page_url, opts)

    seen_pages << page_url
    begin
      status, type, body = page_cache[page_url] ||= fetch_url(page_url, opts)
    rescue StandardError => e
      pages << Page.new(url: page_url, links: [Link.new(url: page_url, error: e.message)])
      next
    end

    unless accepted?(status, opts.accepted) && html_like?(type, page_url)
      pages << Page.new(url: page_url, links: [Link.new(url: page_url, error: status.to_s)])
      next
    end

    links = extract_links(body, page_url).select { |u| allowed_by_filters?(u, opts) }
    checked = links.map { |u| check_link(u, opts, page_cache) }
    pages << Page.new(url: page_url, links: checked)

    unless opts.one_page_only
      links.zip(checked).each do |link, result|
        bare = canonical_page_url(link)
        next if seen_pages.include?(bare)
        next if result.failed?
        next if URI.parse(link).fragment
        next unless same_site?(start_url, bare)
        cached = page_cache[bare]
        if cached
          _status, type, _body = cached
          queue << bare if html_like?(type, bare)
        else
          queue << bare if bare =~ /\.html?\z|\/\z/i
        end
      end
    end
  end
  pages
end

def relevant_pages(pages, verbose)
  verbose ? pages : pages.map { |p| Page.new(url: p.url, links: p.links.select(&:failed?)) }.select { |p| p.links.any? }
end

def output_text(pages, verbose)
  relevant_pages(pages, verbose).each do |page|
    puts page.url
    page.links.each do |link|
      puts "\t#{link.error || link.status}\t#{link.url}"
    end
  end
end

def output_json(pages, verbose)
  puts json_generate(relevant_pages(pages, verbose).map { |p| { "url" => p.url, "links" => p.links.map(&:to_h) } })
end

def json_generate(value)
  case value
  when Array
    "[" + value.map { |v| json_generate(v) }.join(",") + "]"
  when Hash
    "{" + value.map { |k, v| "#{json_generate(k.to_s)}:#{json_generate(v)}" }.join(",") + "}"
  when String
    '"' + value.gsub(/["\\\b\f\n\r\t]/) { |c|
      { '"' => '\"', "\\" => "\\\\", "\b" => "\\b", "\f" => "\\f", "\n" => "\\n", "\r" => "\\r", "\t" => "\\t" }[c]
    }.gsub(/[\x00-\x1f]/) { |c| "\\u%04x" % c.ord } + '"'
  when Numeric
    value.to_s
  when true
    "true"
  when false
    "false"
  when nil
    "null"
  else
    json_generate(value.to_s)
  end
end

def xml_escape(value)
  value.to_s.gsub("&", "&amp;").gsub('"', "&quot;").gsub("<", "&lt;").gsub(">", "&gt;")
end

def output_junit(pages)
  puts %(<?xml version="1.0" encoding="UTF-8"?>)
  puts "<testsuites>"
  pages.each do |page|
    failures = page.links.count(&:failed?)
    if page.links.empty?
      puts %(  <testsuite name="#{xml_escape(page.url)}" tests="0" failures="0" skipped="0"></testsuite>)
      next
    end
    puts %(  <testsuite name="#{xml_escape(page.url)}" tests="#{page.links.length}" failures="#{failures}" skipped="0">)
    page.links.each do |link|
      if link.failed?
        puts %(    <testcase name="#{xml_escape(link.url)}" classname="#{xml_escape(page.url)}">)
        puts %(      <failure message="#{xml_escape(link.error)}"></failure>)
        puts "    </testcase>"
      else
        puts %(    <testcase name="#{xml_escape(link.url)}" classname="#{xml_escape(page.url)}"></testcase>)
      end
    end
    puts "  </testsuite>"
  end
  puts "</testsuites>"
end

opts, url = parse_args(ARGV)
pages = crawl(url, opts)
failed = pages.any? { |p| p.links.any?(&:failed?) }
case opts.format
when "json"
  output_json(pages, opts.verbose)
when "junit"
  output_junit(pages)
else
  output_text(pages, opts.verbose)
end
exit(failed ? 1 : 0)
