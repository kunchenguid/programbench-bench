#!/usr/bin/env ruby
# frozen_string_literal: true

require "net/http"
require "uri"
require "openssl"
require "base64"
require "socket"

VERSION = "oha 1.12.1"

HELP = <<~TXT
  Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.

  Usage: executable [OPTIONS] <URL>

  Arguments:
    <URL>  Target URL or file with multiple URLs.

  Options:
    -n <N_REQUESTS>
            Number of requests to run. Accepts plain numbers or suffixes: k = 1,000, m = 1,000,000 (e.g. 10k, 1m). [default: 200]
    -c <N_CONNECTIONS>
            Number of connections to run concurrently. You may should increase limit to number of open files for larger `-c`. [default: 50]
    -p <N_HTTP2_PARALLEL>
            Number of parallel requests to send on HTTP/2. `oha` will run c * p concurrent workers in total. [default: 1]
    -z <DURATION>
            Duration of application to send requests.
            On HTTP/1, When the duration is reached, ongoing requests are aborted and counted as "aborted due to deadline"
            You can change this behavior with `-w` option.
            Currently, on HTTP/2, When the duration is reached, ongoing requests are waited. `-w` option is ignored.
            Examples: -z 10s -z 3m.
    -w, --wait-ongoing-requests-after-deadline
            When the duration is reached, ongoing requests are waited
    -q <QUERY_PER_SECOND>
            Rate limit for all, in queries per second (QPS)
        --burst-delay <BURST_DURATION>
            Introduce delay between a predefined number of requests.
            Note: If qps is specified, burst will be ignored
        --burst-rate <BURST_REQUESTS>
            Rates of requests for burst. Default is 1
            Note: If qps is specified, burst will be ignored
        --rand-regex-url
            Generate URL by rand_regex crate but dot is disabled for each query e.g. http://127.0.0.1/[a-z][a-z][0-9]. Currently dynamic scheme, host and port with keep-alive do not work well. See https://docs.rs/rand_regex/latest/rand_regex/struct.Regex.html for details of syntax.
        --urls-from-file
            Read the URLs to query from a file
        --max-repeat <MAX_REPEAT>
            A parameter for the '--rand-regex-url'. The max_repeat parameter gives the maximum extra repeat counts the x*, x+ and x{n,} operators will become. [default: 4]
        --dump-urls <DUMP_URLS>
            Dump target Urls <DUMP_URLS> times to debug --rand-regex-url
        --latency-correction
            Correct latency to avoid coordinated omission problem. It's ignored if -q is not set.
        --no-tui
            No realtime tui
        --fps <FPS>
            Frame per second for tui. [default: 16]
    -m, --method <METHOD>
            HTTP method [default: GET]
    -H <HEADERS>
            Custom HTTP header. Examples: -H "foo: bar"
        --proxy-header <PROXY_HEADERS>
            Custom Proxy HTTP header. Examples: --proxy-header "foo: bar"
    -t <TIMEOUT>
            Timeout for each request. Default to infinite.
        --connect-timeout <CONNECT_TIMEOUT>
            Timeout for establishing a new connection. Default to 5s. [default: 5s]
    -A <ACCEPT_HEADER>
            HTTP Accept Header.
    -d <BODY_STRING>
            HTTP request body.
    -D <BODY_PATH>
            HTTP request body from file.
    -Z <BODY_PATH_LINES>
            HTTP request body from file line by line.
    -F, --form <FORM>
            Specify HTTP multipart POST data (curl compatible). Examples: -F 'name=value' -F 'file=@path/to/file'
    -T <CONTENT_TYPE>
            Content-Type.
    -a <BASIC_AUTH>
            Basic authentication (username:password), or AWS credentials (access_key:secret_key)
        --aws-session <AWS_SESSION>
            AWS session token
        --aws-sigv4 <AWS_SIGV4>
            AWS SigV4 signing params (format: aws:amz:region:service)
    -x <PROXY>
            HTTP proxy
        --proxy-http-version <PROXY_HTTP_VERSION>
            HTTP version to connect to proxy. Available values 0.9, 1.0, 1.1, 2.
        --proxy-http2
            Use HTTP/2 to connect to proxy. Shorthand for --proxy-http-version=2
        --http-version <HTTP_VERSION>
            HTTP version. Available values 0.9, 1.0, 1.1, 2, 3
        --http2
            Use HTTP/2. Shorthand for --http-version=2
        --host <HOST>
            HTTP Host header
        --disable-compression
            Disable compression.
    -r, --redirect <REDIRECT>
            Limit for number of Redirect. Set 0 for no redirection. Redirection isn't supported for HTTP/2. [default: 10]
        --disable-keepalive
            Disable keep-alive, prevents re-use of TCP connections between different HTTP requests. This isn't supported for HTTP/2.
        --no-pre-lookup
            *Not* perform a DNS lookup at beginning to cache it
        --ipv6
            Lookup only ipv6.
        --ipv4
            Lookup only ipv4.
        --cacert <CACERT>
            (TLS) Use the specified certificate file to verify the peer. Native certificate store is used even if this argument is specified.
        --cert <CERT>
            (TLS) Use the specified client certificate file. --key must be also specified
        --key <KEY>
            (TLS) Use the specified client key file. --cert must be also specified
        --insecure
            Accept invalid certs.
        --connect-to <CONNECT_TO>
            Override DNS resolution and default port numbers with strings like 'example.org:443:localhost:8443'
            Note: if used several times for the same host:port:target_host:target_port, a random choice is made
        --no-color
            Disable the color scheme. [env: NO_COLOR=]
        --unix-socket <UNIX_SOCKET>
            Connect to a unix socket instead of the domain in the URL. Only for non-HTTPS URLs.
        --stats-success-breakdown
            Include a response status code successful or not successful breakdown for the time histogram and distribution statistics
        --db-url <DB_URL>
            Write succeeded requests to sqlite database url E.G test.db
        --debug
            Perform a single request and dump the request and response
    -o, --output <OUTPUT>
            Output file to write the results to. If not specified, results are written to stdout.
        --output-format <OUTPUT_FORMAT>
            Output format [default: text] [possible values: text, json, csv, quiet]
    -u, --time-unit <TIME_UNIT>
            Time unit to be used. If not specified, the time unit is determined automatically. This option affects only text format. [possible values: ns, us, ms, s, m, h]
    -h, --help
            Print help
    -V, --version
            Print version
TXT

def die_parse(msg)
  warn msg
  warn
  warn "For more information, try '--help'."
  exit 0
end

def parse_count(s, opt)
  mult = 1
  raw = s.to_s
  if raw =~ /[kK]\z/
    mult = 1_000
    raw = raw[0...-1]
  elsif raw =~ /[mM]\z/
    mult = 1_000_000
    raw = raw[0...-1]
  end
  Integer(raw) * mult
rescue ArgumentError => e
  msg = e.message.include?("Integer") ? "invalid digit found in string" : e.message
  die_parse("error: invalid value '#{s}' for '#{opt}': #{msg}")
end

def parse_duration(s)
  raw = s.to_s
  return raw.to_f / 1000.0 if raw.end_with?("ms")
  return raw.to_f / 1_000_000.0 if raw.end_with?("us")
  return raw.to_f * 60.0 if raw.end_with?("m")
  return raw.to_f * 3600.0 if raw.end_with?("h")
  raw.sub(/s\z/, "").to_f
end

def take(args, i, name)
  die_parse("error: a value is required for '#{name} <#{name.sub(/^-+/, '').upcase}>' but none was supplied") if i + 1 >= args.length
  args[i + 1]
end

def parse_args(args)
  o = {
    n: 200, c: 50, p: 1, method: "GET", headers: [], proxy_headers: [],
    timeout: nil, connect_timeout: 5.0, redirect: 10, format: "text",
    body: nil, forms: [], no_tui: false, fps: 16, burst_rate: 1,
    rand_regex: false, urls_from_file: false, max_repeat: 4,
    wait: false, insecure: false, disable_compression: false,
    disable_keepalive: false, ipv4: false, ipv6: false, http_version: nil
  }
  positional = []
  i = 0
  while i < args.length
    a = args[i]
    case a
    when "-h", "--help"
      puts HELP
      exit 0
    when "-V", "--version"
      puts VERSION
      exit 0
    when "-n"
      o[:n] = parse_count(take(args, i, "-n <N_REQUESTS>"), "-n <N_REQUESTS>"); i += 1
    when "-c"
      o[:c] = parse_count(take(args, i, "-c <N_CONNECTIONS>"), "-c <N_CONNECTIONS>"); i += 1
    when "-p"
      o[:p] = parse_count(take(args, i, "-p <N_HTTP2_PARALLEL>"), "-p <N_HTTP2_PARALLEL>"); i += 1
    when "-z"
      o[:duration] = parse_duration(take(args, i, "-z <DURATION>")); i += 1
    when "-w", "--wait-ongoing-requests-after-deadline"
      o[:wait] = true
    when "-q"
      o[:qps] = take(args, i, "-q <QUERY_PER_SECOND>").to_f; i += 1
    when "--burst-delay"
      o[:burst_delay] = parse_duration(take(args, i, "--burst-delay <BURST_DURATION>")); i += 1
    when "--burst-rate"
      o[:burst_rate] = parse_count(take(args, i, "--burst-rate <BURST_REQUESTS>"), "--burst-rate <BURST_REQUESTS>"); i += 1
    when "--rand-regex-url"
      o[:rand_regex] = true
    when "--urls-from-file"
      o[:urls_from_file] = true
    when "--max-repeat"
      o[:max_repeat] = parse_count(take(args, i, "--max-repeat <MAX_REPEAT>"), "--max-repeat <MAX_REPEAT>"); i += 1
    when "--dump-urls"
      o[:dump_urls] = parse_count(take(args, i, "--dump-urls <DUMP_URLS>"), "--dump-urls <DUMP_URLS>"); i += 1
    when "--latency-correction", "--no-pre-lookup", "--no-color", "--stats-success-breakdown", "--proxy-http2", "--http2"
      o[a.delete_prefix("--").tr("-", "_").to_sym] = true
    when "--no-tui"
      o[:no_tui] = true
    when "--fps"
      o[:fps] = take(args, i, "--fps <FPS>").to_i; i += 1
    when "-m", "--method"
      o[:method] = take(args, i, "#{a} <METHOD>").upcase; i += 1
    when "-H"
      o[:headers] << take(args, i, "-H <HEADERS>"); i += 1
    when "--proxy-header"
      o[:proxy_headers] << take(args, i, "--proxy-header <PROXY_HEADERS>"); i += 1
    when "-t"
      o[:timeout] = parse_duration(take(args, i, "-t <TIMEOUT>")); i += 1
    when "--connect-timeout"
      o[:connect_timeout] = parse_duration(take(args, i, "--connect-timeout <CONNECT_TIMEOUT>")); i += 1
    when "-A"
      o[:accept] = take(args, i, "-A <ACCEPT_HEADER>"); i += 1
    when "-d"
      o[:body] = take(args, i, "-d <BODY_STRING>"); i += 1
    when "-D"
      o[:body] = File.binread(take(args, i, "-D <BODY_PATH>")); i += 1
    when "-Z"
      o[:body_lines] = File.readlines(take(args, i, "-Z <BODY_PATH_LINES>"), chomp: true); i += 1
    when "-F", "--form"
      o[:forms] << take(args, i, "#{a} <FORM>"); i += 1
    when "-T"
      o[:content_type] = take(args, i, "-T <CONTENT_TYPE>"); i += 1
    when "-a"
      o[:auth] = take(args, i, "-a <BASIC_AUTH>"); i += 1
    when "--aws-session", "--aws-sigv4", "-x", "--proxy-http-version", "--http-version",
         "--host", "--cacert", "--cert", "--key", "--connect-to", "--unix-socket", "--db-url"
      key = a.sub(/^-+/, "").tr("-", "_").to_sym
      o[key] = take(args, i, "#{a} <VALUE>"); i += 1
    when "--disable-compression"
      o[:disable_compression] = true
    when "-r", "--redirect"
      o[:redirect] = parse_count(take(args, i, "#{a} <REDIRECT>"), "#{a} <REDIRECT>"); i += 1
    when "--disable-keepalive"
      o[:disable_keepalive] = true
    when "--ipv6"
      o[:ipv6] = true
    when "--ipv4"
      o[:ipv4] = true
    when "--insecure"
      o[:insecure] = true
    when "--debug"
      o[:debug] = true
      o[:n] = 1
      o[:no_tui] = true
    when "-o", "--output"
      o[:output] = take(args, i, "#{a} <OUTPUT>"); i += 1
    when "--output-format"
      v = take(args, i, "--output-format <OUTPUT_FORMAT>"); i += 1
      unless %w[text json csv quiet].include?(v)
        die_parse("error: invalid value '#{v}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: text, json, csv, quiet]")
      end
      o[:format] = v
    when "-u", "--time-unit"
      v = take(args, i, "#{a} <TIME_UNIT>"); i += 1
      unless %w[ns us ms s m h].include?(v)
        die_parse("error: invalid value '#{v}' for '--time-unit <TIME_UNIT>'\n  [possible values: ns, us, ms, s, m, h]")
      end
      o[:time_unit] = v
    when "--"
      positional.concat(args[(i + 1)..] || [])
      break
    else
      if a.start_with?("-")
        warn "error: unexpected argument '#{a}' found"
        warn
        warn "  tip: to pass '#{a}' as a value, use '-- #{a}'"
        warn
        warn "Usage: executable [OPTIONS] <URL>"
        warn
        warn "For more information, try '--help'."
        exit 0
      else
        positional << a
      end
    end
    i += 1
  end
  if positional.empty?
    puts HELP
    exit 0
  end
  o[:target] = positional.first
  o
end

def normalize_url(s)
  u = URI.parse(s)
  return s if u.path && !u.path.empty?
  s.end_with?("/") ? s : "#{s}/"
rescue URI::InvalidURIError
  s
end

def rand_url(pattern, max_repeat = 4)
  out = +""
  i = 0
  while i < pattern.length
    if pattern[i] == "[" && (j = pattern.index("]", i))
      cls = pattern[(i + 1)...j]
      chars = []
      k = 0
      while k < cls.length
        if k + 2 < cls.length && cls[k + 1] == "-"
          chars.concat((cls[k]..cls[k + 2]).to_a)
          k += 3
        else
          chars << cls[k]
          k += 1
        end
      end
      out << chars.sample.to_s
      i = j + 1
      if pattern[i] == "*"
        rand(max_repeat + 1).times { out << chars.sample.to_s }
        i += 1
      elsif pattern[i] == "+"
        (1 + rand(max_repeat + 1)).times { out << chars.sample.to_s }
        i += 1
      end
    else
      out << pattern[i]
      i += 1
    end
  end
  normalize_url(out)
end

def fmt_float(x, digits = 4)
  return "NaN" if x.nil? || x.nan?
  return "inf" if x == Float::INFINITY
  return "-inf" if x == -Float::INFINITY
  format("%.#{digits}f", x)
end

def choose_unit(seconds, forced = nil)
  unit = forced
  unit ||= if seconds.nil? || seconds.nan?
             "ns"
           elsif seconds < 0.000001
             "ns"
           elsif seconds < 0.001
             "us"
           elsif seconds < 1
             "ms"
           elsif seconds < 60
             "s"
           elsif seconds < 3600
             "m"
           else
             "h"
           end
  mult = { "ns" => 1_000_000_000.0, "us" => 1_000_000.0, "ms" => 1000.0, "s" => 1.0, "m" => 1.0 / 60, "h" => 1.0 / 3600 }[unit]
  [unit, mult]
end

def fmt_time(seconds, forced = nil, digits = 4)
  unit, mult = choose_unit(seconds, forced)
  "#{fmt_float(seconds.to_f * mult, digits)} #{unit}"
end

def human_bytes(n)
  n = n.to_f
  return "#{n.to_i} B" if n < 1024
  return "#{(n / 1024).round(2)} KiB" if n < 1024 * 1024
  "#{(n / 1024 / 1024).round(2)} MiB"
end

def percentile(sorted, p)
  return nil if sorted.empty?
  sorted[((sorted.length * p).ceil - 1).clamp(0, sorted.length - 1)]
end

def json_escape(s)
  s.to_s.gsub(/["\\\b\f\n\r\t]/) { |c| { "\"" => "\\\"", "\\" => "\\\\", "\n" => "\\n", "\r" => "\\r", "\t" => "\\t", "\b" => "\\b", "\f" => "\\f" }[c] || c }
end

def to_json(obj, indent = 0)
  sp = " " * indent
  case obj
  when Hash
    return "{}" if obj.empty?
    inner = obj.map { |k, v| "#{" " * (indent + 2)}\"#{json_escape(k)}\": #{to_json(v, indent + 2)}" }.join(",\n")
    "{\n#{inner}\n#{sp}}"
  when Array
    "[" + obj.map { |v| to_json(v, indent) }.join(", ") + "]"
  when String
    "\"#{json_escape(obj)}\""
  when NilClass
    "null"
  when TrueClass, FalseClass
    obj.to_s
  when Numeric
    obj.finite? ? obj.to_s : "null"
  else
    "\"#{json_escape(obj)}\""
  end
end

def build_headers(opt, uri)
  headers = {}
  headers["accept"] = opt[:accept] || "*/*"
  headers["accept-encoding"] = "gzip, compress, deflate, br" unless opt[:disable_compression]
  headers["user-agent"] = "oha/1.12.1"
  headers["host"] = opt[:host] || (uri.port == uri.default_port ? uri.host : "#{uri.host}:#{uri.port}")
  opt[:headers].each do |h|
    k, v = h.split(":", 2)
    headers[k.strip.downcase] = v ? v.strip : ""
  end
  headers["content-type"] = opt[:content_type] if opt[:content_type]
  headers["authorization"] = "Basic #{Base64.strict_encode64(opt[:auth])}" if opt[:auth] && !opt[:aws_sigv4]
  headers
end

def body_for(opt, idx)
  if opt[:forms].any?
    boundary = "------------------------oha-ruby-boundary"
    parts = opt[:forms].map do |f|
      name, val = f.split("=", 2)
      val ||= ""
      if val.start_with?("@") && File.file?(val[1..])
        path = val[1..]
        "Content-Disposition: form-data; name=\"#{name}\"; filename=\"#{File.basename(path)}\"\r\n\r\n#{File.binread(path)}"
      else
        "Content-Disposition: form-data; name=\"#{name}\"\r\n\r\n#{val}"
      end
    end
    ["--#{boundary}\r\n" + parts.join("\r\n--#{boundary}\r\n") + "\r\n--#{boundary}--\r\n", "multipart/form-data; boundary=#{boundary}"]
  elsif opt[:body_lines]
    [opt[:body_lines][idx % opt[:body_lines].length].to_s, opt[:content_type]]
  else
    [opt[:body], opt[:content_type]]
  end
end

def request_once(url, opt, idx, debug: false)
  started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  uri = URI.parse(url)
  body, ctype = body_for(opt, idx)
  headers = build_headers(opt, uri)
  headers["content-type"] = ctype if ctype && !headers["content-type"]
  headers["connection"] = "close" if opt[:disable_keepalive]
  path = uri.request_uri
  path = "/" if path.nil? || path.empty?
  if debug
    puts "Request {"
    puts "    method: #{opt[:method]},"
    puts "    uri: #{path},"
    puts "    version: HTTP/1.1,"
    puts "    headers: {"
    headers.each { |k, v| puts "        \"#{k}\": \"#{v}\"," }
    puts "    },"
    puts "    body: Full {"
    puts body.nil? ? "        data: None," : "        data: Some(#{body.bytes.inspect}),"
    puts "    },"
    puts "}"
  end
  dns0 = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  begin
    Addrinfo.getaddrinfo(uri.host, nil)
  rescue StandardError
  end
  dns = Process.clock_gettime(Process::CLOCK_MONOTONIC) - dns0
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = uri.scheme == "https"
  http.open_timeout = opt[:connect_timeout]
  http.read_timeout = opt[:timeout] if opt[:timeout]
  http.verify_mode = OpenSSL::SSL::VERIFY_NONE if opt[:insecure]
  req_class = Net::HTTP.const_get(opt[:method].capitalize) rescue Net::HTTPGenericRequest
  req = if req_class == Net::HTTPGenericRequest
          Net::HTTPGenericRequest.new(opt[:method], !body.nil?, true, path, headers)
        else
          req_class.new(path, headers)
        end
  req.body = body if body
  dial0 = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  res = http.request(req)
  elapsed = Process.clock_gettime(Process::CLOCK_MONOTONIC) - started
  dial = [Process.clock_gettime(Process::CLOCK_MONOTONIC) - dial0, dns].max
  if opt[:redirect].to_i > 0 && res.is_a?(Net::HTTPRedirection) && res["location"]
    opt2 = opt.dup
    opt2[:redirect] = opt[:redirect].to_i - 1
    return request_once(URI.join(uri, res["location"]).to_s, opt2, idx, debug: false)
  end
  data = res.body ? res.body.bytesize : 0
  if debug
    puts "Response {"
    puts "    status: #{res.code},"
    puts "    version: HTTP/1.1,"
    puts "    headers: {"
    res.each_header { |k, v| puts "        \"#{k}\": \"#{v}\"," }
    puts "    },"
    body_repr = (res.body || "").bytes.all? { |b| b >= 32 && b < 127 } ? "b\"#{(res.body || '').gsub('\\', '\\\\\\').gsub('\"', '\\\"')}\"" : (res.body || "").bytes.inspect
    puts "    body: #{body_repr},"
    puts "}"
  end
  { ok: true, status: res.code.to_i, bytes: data, duration: elapsed, dns: dns, dial: dial, response_delay: elapsed, start: started }
rescue StandardError => e
  msg = case e
        when Errno::ECONNREFUSED then "Connection refused (os error 111)"
        when Errno::ENETUNREACH then "Network is unreachable (os error 101)"
        when SocketError then e.message
        when Net::OpenTimeout then "operation timed out"
        else e.message
        end
  puts "Error: #{msg}" if debug
  { ok: false, error: msg, duration: nil, dns: 0.0, dial: 0.0, bytes: 0, start: started }
end

def run_load(opt)
  targets = if opt[:urls_from_file]
              File.readlines(opt[:target], chomp: true).reject(&:empty?)
            else
              [normalize_url(opt[:target])]
            end
  if opt[:dump_urls]
    opt[:dump_urls].times do
      base = targets.sample
      puts(opt[:rand_regex] ? rand_url(base, opt[:max_repeat]) : normalize_url(base))
    end
    exit 0
  end
  return [request_once(targets.first, opt, 0, debug: true), 0.0] if opt[:debug]

  results = []
  mutex = Mutex.new
  deadline = opt[:duration] ? Process.clock_gettime(Process::CLOCK_MONOTONIC) + opt[:duration] : nil
  total = opt[:duration] ? Float::INFINITY : opt[:n]
  next_index = 0
  global_start = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  workers = [opt[:c].to_i, 1].max * [opt[:p].to_i, 1].max
  threads = workers.times.map do
    Thread.new do
      loop do
        idx = nil
        stop = false
        mutex.synchronize do
          now = Process.clock_gettime(Process::CLOCK_MONOTONIC)
          if (deadline && now >= deadline) || next_index >= total
            stop = true
          else
            idx = next_index
            next_index += 1
          end
        end
        break if stop
        if opt[:qps] && opt[:qps] > 0
          target_time = global_start + idx / opt[:qps].to_f
          sleep(target_time - Process.clock_gettime(Process::CLOCK_MONOTONIC)) if target_time > Process.clock_gettime(Process::CLOCK_MONOTONIC)
        elsif opt[:burst_delay] && opt[:burst_rate].to_i > 0 && idx.positive? && (idx % opt[:burst_rate].to_i).zero?
          sleep opt[:burst_delay]
        end
        break if deadline && !opt[:wait] && Process.clock_gettime(Process::CLOCK_MONOTONIC) >= deadline
        url = opt[:rand_regex] ? rand_url(targets.sample, opt[:max_repeat]) : targets.sample
        r = request_once(url, opt, idx)
        mutex.synchronize { results << r }
      end
    end
  end
  threads.each(&:join)
  if deadline && results.empty?
    results << { ok: false, error: "aborted due to deadline", duration: nil, dns: 0.0, dial: 0.0, bytes: 0, start: global_start }
  end
  [results, Process.clock_gettime(Process::CLOCK_MONOTONIC) - global_start]
end

def summarize(results, total_time)
  successes = results.select { |r| r[:ok] }
  durations = successes.map { |r| r[:duration] }.compact.sort
  dials = successes.map { |r| r[:dial] }.compact.sort
  dnses = successes.map { |r| r[:dns] }.compact.sort
  statuses = Hash.new(0)
  errors = Hash.new(0)
  bytes = 0
  results.each do |r|
    if r[:ok]
      statuses[r[:status].to_s] += 1
      bytes += r[:bytes].to_i
    else
      errors[r[:error].to_s] += 1
    end
  end
  avg = durations.empty? ? nil : durations.sum / durations.length
  {
    count: results.length, successes: successes.length, durations: durations,
    total: total_time, slowest: durations.last, fastest: durations.first, average: avg,
    rps: total_time.positive? ? results.length / total_time : 0.0,
    total_data: bytes, size_per_request: successes.empty? ? nil : bytes / successes.length,
    size_sec: total_time.positive? ? bytes / total_time : 0.0,
    statuses: statuses, errors: errors, dials: dials, dnses: dnses
  }
end

def output_csv(results, global_start)
  lines = ["request-start,DNS,DNS+dialup,Response-delay,request-duration,bytes,status"]
  results.select { |r| r[:ok] }.each do |r|
    lines << [r[:start] - global_start, r[:dns], r[:dial], r[:response_delay], r[:duration], r[:bytes], r[:status]].join(",")
  end
  lines.join("\n") + "\n"
end

def output_json(s)
  d = s[:durations]
  hist = {}
  if d.empty?
    hist["NaN"] = 0
  else
    min = d.first
    max = d.last
    step = max == min ? 0 : (max - min) / 10.0
    11.times do |i|
      key = (min + step * i).to_s
      lo = min + step * i
      hi = i == 10 ? Float::INFINITY : min + step * (i + 1)
      hist[key] = d.count { |x| x >= lo && x < hi }
    end
  end
  pct = { "p10" => 0.10, "p25" => 0.25, "p50" => 0.50, "p75" => 0.75, "p90" => 0.90, "p95" => 0.95, "p99" => 0.99, "p99.9" => 0.999, "p99.99" => 0.9999 }
  latency = pct.transform_values { |p| percentile(d, p) }
  dial = s[:dials]
  dns = s[:dnses]
  data = {
    "summary" => {
      "successRate" => s[:count].zero? ? nil : s[:successes].to_f / s[:count],
      "total" => s[:total], "slowest" => s[:slowest], "fastest" => s[:fastest],
      "average" => s[:average], "requestsPerSec" => s[:rps],
      "totalData" => s[:total_data], "sizePerRequest" => s[:size_per_request],
      "sizePerSec" => s[:size_sec]
    },
    "responseTimeHistogram" => hist,
    "latencyPercentiles" => latency,
    "rps" => { "mean" => nil, "stddev" => nil, "max" => nil, "min" => nil, "percentiles" => pct.transform_values { nil } },
    "details" => {
      "DNSDialup" => { "average" => dial.empty? ? nil : dial.sum / dial.length, "fastest" => dial.first, "slowest" => dial.last },
      "DNSLookup" => { "average" => dns.empty? ? nil : dns.sum / dns.length, "fastest" => dns.first, "slowest" => dns.last }
    },
    "statusCodeDistribution" => s[:statuses],
    "errorDistribution" => s[:errors]
  }
  to_json(data) + "\n"
end

def output_text(s, opt)
  d = s[:durations]
  success_rate = s[:count].zero? ? Float::NAN : (s[:successes].to_f / s[:count] * 100.0)
  unit_src = d.empty? ? nil : [s[:total], s[:slowest], s[:fastest], s[:average]].compact.max
  unit, = choose_unit(unit_src || s[:total], opt[:time_unit] || (d.empty? ? "ns" : nil))
  lines = []
  lines << "Summary:"
  lines << "  Success rate:\t#{fmt_float(success_rate, 2)}%"
  lines << "  Total:\t#{fmt_time(s[:total], unit)}"
  lines << "  Slowest:\t#{d.empty? ? '-inf ns' : fmt_time(s[:slowest], unit)}"
  lines << "  Fastest:\t#{d.empty? ? 'inf ns' : fmt_time(s[:fastest], unit)}"
  lines << "  Average:\t#{d.empty? ? 'NaN ns' : fmt_time(s[:average], unit)}"
  lines << "  Requests/sec:\t#{fmt_float(s[:rps], 4)}"
  lines << ""
  lines << "  Total data:\t#{human_bytes(s[:total_data])}"
  lines << "  Size/request:\t#{s[:size_per_request].nil? ? 'NaN' : human_bytes(s[:size_per_request])}"
  lines << "  Size/sec:\t#{human_bytes(s[:size_sec])}"
  lines << ""
  lines << "Response time histogram:"
  if d.empty?
    11.times { lines << "    NaN ns [0] |" }
  else
    min = d.first
    max = d.last
    step = max == min ? 0 : (max - min) / 10.0
    buckets = 11.times.map do |i|
      lo = min + step * i
      hi = i == 10 ? Float::INFINITY : min + step * (i + 1)
      d.count { |x| x >= lo && x < hi }
    end
    max_count = [buckets.max, 1].max
    11.times do |i|
      label = min + step * i
      bar = "■" * (buckets[i] * 32 / max_count)
      lines << "#{format('%8s', fmt_time(label, unit, 3))} [#{buckets[i]}] |#{bar}"
    end
  end
  lines << ""
  lines << "Response time distribution:"
  [["10.00%", 0.10], ["25.00%", 0.25], ["50.00%", 0.50], ["75.00%", 0.75], ["90.00%", 0.90], ["95.00%", 0.95], ["99.00%", 0.99], ["99.90%", 0.999], ["99.99%", 0.9999]].each do |name, p|
    v = percentile(d, p)
    lines << "  #{name} in #{v.nil? ? 'NaN ns' : fmt_time(v, unit)}"
  end
  lines << ""
  lines << ""
  dial = s[:dials]
  dns = s[:dnses]
  lines << "Details (average, fastest, slowest):"
  lines << "  DNS+dialup:\t#{dial.empty? ? 'NaN ns, inf ns, -inf ns' : "#{fmt_time(dial.sum / dial.length, unit)}, #{fmt_time(dial.first, unit)}, #{fmt_time(dial.last, unit)}"}"
  lines << "  DNS-lookup:\t#{dns.empty? ? 'NaN ns, inf ns, -inf ns' : "#{fmt_time(dns.sum / dns.length, unit)}, #{fmt_time(dns.first, unit)}, #{fmt_time(dns.last, unit)}"}"
  lines << ""
  lines << "Status code distribution:"
  s[:statuses].sort.each { |code, count| lines << "  [#{code}] #{count} responses" }
  if s[:errors].any?
    lines << ""
    lines << "Error distribution:"
    s[:errors].sort.each { |err, count| lines << "  [#{count}] #{err}" }
  end
  lines.join("\n") + "\n"
end

opt = parse_args(ARGV.dup)
results, total_time = run_load(opt)
exit 0 if opt[:debug]
summary = summarize(results, total_time)
global_start = results.map { |r| r[:start] }.compact.min || Process.clock_gettime(Process::CLOCK_MONOTONIC)
out = case opt[:format]
      when "json" then output_json(summary)
      when "csv" then output_csv(results, global_start)
      when "quiet" then ""
      else output_text(summary, opt)
      end
if opt[:output]
  File.write(opt[:output], out)
else
  print out
end
