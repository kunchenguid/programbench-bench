#!/usr/bin/env ruby
# frozen_string_literal: true

require 'cgi'
require 'json'
require 'fileutils'
require 'open3'
require 'base64'

VERSION = 'codesnap-cli 0.13.1'

HELP_LONG = <<~TEXT
  CLI tools for generating beautiful code snapshots

  Usage: codesnap [OPTIONS] --output <OUTPUT>

  Options:
    -f, --from-file <FROM_FILE>
            Path to the file to snapshot

    -c, --from-code [<Code>]
            Code snippet for snapshot

    -i, --from-image [<Image>]

        --from-clipboard

    -o, --output <OUTPUT>
            Output path for the snapshot. Available value:

            - clipboard: Copy the snapshot to clipboard - file path: Save the snapshot to the file path

            Currently CodeSnap supports SVG format and PNG format If output is directory, CodeSnap will generate a temporary file name to save the snapshot to the directory.

        --silent

    -e, --execute <EXECUTE>...
            Executing a command and taking the output as the code snippet

        --skip
            Skip run the command to get output, just take the command as the input

        --range <RANGE>
            You can set the range of the code snippet to display for example, display the 3rd to 5th: 3:5 The syntax is similar to the range in Python or Golang, so basically you can use 3: to represent the 3rd to the end, or use :5 to represent the start to the 5th. This option is useful when you use the `from_file` option as the input, and you just want to display part of the code snippet

        --code-font-family <CODE_FONT_FAMILY>
            Font family for the code snippet

        --code-theme <CODE_THEME>
            Code theme for the code snippet

        --has-breadcrumbs <HAS_BREADCRUMBS>
            Breadcrumbs is a useful and unique feature in CodeSnap, it shows the path of the file so that users can know where the code snippet comes from

            [default: false]
            [possible values: true, false]

        --has-line-number

        --breadcrumbs-separator <BREADCRUMBS_SEPARATOR>
            Breadcrumbs separator is the character to separate the path in breadcrumbs Default is `/`

        --breadcrumbs-font-family <BREADCRUMBS_FONT_FAMILY>
            Breadcrumbs font family

        --breadcrumbs-color <BREADCRUMBS_COLOR>
            Breadcrumbs font color

        --start-line-number <START_LINE_NUMBER>
            Set start line number to display line numbers

        --line-number-color <LINE_NUMBER_COLOR>
            Line number font color

            [default: #495162]

    -d, --delete-line <DELETE_LINE>...
            Delete lines will be marked with a red line

        --delete-line-color <DELETE_LINE_COLOR>
            Delete line color

            [default: #ff6b6b30]

    -a, --add-line <ADD_LINE>...
            New lines will be marked with a green line

        --add-line-color <ADD_LINE_COLOR>
            New line color

            [default: #2ecc7130]

        --highlight-range <HIGHLIGHT_RANGE>
            Convenient version of `--raw-highlight-lines` option, you can set the highlight range with a simple syntax, for example, highlight the 3rd to 5th lines: 3:5

        --relative-highlight-range

        --highlight-range-color <HIGHLIGHT_RANGE_COLOR>
            Highlight color for the highlighted code lines

            [default: #ffffff10]

        --raw-highlight-lines <RAW_HIGHLIGHT_LINES>
            CodeSnap allows users to highlight multiple lines with custom highlight color in the code snippet The content of highlight_lines is JSON string, for example highlight the first line and the 3rd to 5th lines: "[ [1, "#ff0000"], [3, 5, "#00ff00"] ]"

    -l, --language <LANGUAGE>
            Set the language of the code snippet, If you using the `file` option, CodeSnap will automatically detect the language from the file extension

        --file-path <FILE_PATH>
            Used to detect the language of the code snippet, if you want to set language manually, use `--language` or `-l` option

    -w, --watermark <WATERMARK>
            Set watermark for the code snippet

        --watermark-font-family <WATERMARK_FONT_FAMILY>
            Watermark font family

        --watermark-color <WATERMARK_COLOR>
            Watermark font color

        --shadow-radius <SHADOW_RADIUS>
            Set window shadow radius

        --shadow-color <SHADOW_COLOR>

        --mac-window-bar <MAC_WINDOW_BAR>
            Display MacOS style window bar

            [possible values: true, false]

        --has-border
            Display window border

        --border-color <BORDER_COLOR>
            Window border color

            [default: #ffffff30]

        --margin-x <MARGIN_X>
            Set horizontal margin of window

        --margin-y <MARGIN_Y>
            Set vertical margin of window

        --title <TITLE>
            Set title of the window

        --scale-factor <SCALE_FACTOR>
            CodeSnap supports scaling the snapshot, the default scale factor is 3 for better quality

            [default: 3]

        --title-font-family <TITLE_FONT_FAMILY>
            Title font family

        --title-color <TITLE_COLOR>
            Title font color

        --background <BACKGROUND>
            Set background color of the snapshot

        --type <TYPE>
            [default: image]
            [possible values: ascii, image]

        --config <CONFIG>

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
TEXT

PNG_1X1 = Base64.decode64(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII='
)

def die(message, status = 1)
  warn "\e[31m[ERROR]\e[0m #{message}"
  exit status
end

def clap_missing_output
  warn "error: the following required arguments were not provided:\n  --output <OUTPUT>\n\nUsage: codesnap --output <OUTPUT>\n\nFor more information, try '--help'."
  exit 2
end

def take_value!(args, i, opt)
  val = args[i + 1]
  if val.nil? || val.start_with?('-')
    warn "error: a value is required for '#{opt} <#{opt.sub(/^--?/, '').tr('-', '_').upcase}>' but none was supplied"
    exit 2
  end
  [val, i + 2]
end

def parse_args(argv)
  opts = {
    add_lines: [],
    delete_lines: [],
    execute: [],
    has_breadcrumbs: false,
    has_line_number: false,
    silent: false,
    skip: false,
    type: 'image'
  }
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-h', '--help'
      puts HELP_LONG
      exit 0
    when '-V', '--version'
      puts VERSION
      exit 0
    when '-f', '--from-file'
      opts[:from_file], i = take_value!(argv, i, arg)
    when '-c', '--from-code'
      if argv[i + 1] && !argv[i + 1].start_with?('-')
        opts[:from_code] = argv[i + 1]
        i += 2
      else
        opts[:from_code] = STDIN.tty? ? '' : STDIN.read
        i += 1
      end
    when '-i', '--from-image'
      if argv[i + 1] && !argv[i + 1].start_with?('-')
        opts[:from_image] = argv[i + 1]
        i += 2
      else
        opts[:from_image] = true
        i += 1
      end
    when '--from-clipboard'
      opts[:from_clipboard] = true
      i += 1
    when '-o', '--output'
      opts[:output], i = take_value!(argv, i, arg)
    when '--silent'
      opts[:silent] = true
      i += 1
    when '-e', '--execute'
      i += 1
      while i < argv.length && !argv[i].start_with?('-')
        opts[:execute] << argv[i]
        i += 1
      end
    when '--skip', '--relative-highlight-range', '--has-border', '--has-line-number'
      key = arg.sub(/^--/, '').tr('-', '_').to_sym
      opts[key] = true
      i += 1
    when '-d', '--delete-line'
      val, i = take_value!(argv, i, arg)
      opts[:delete_lines] << val.to_i
    when '-a', '--add-line'
      val, i = take_value!(argv, i, arg)
      opts[:add_lines] << val.to_i
    else
      key_map = {
        '--range' => :range,
        '--code-font-family' => :code_font_family,
        '--code-theme' => :code_theme,
        '--has-breadcrumbs' => :has_breadcrumbs,
        '--breadcrumbs-separator' => :breadcrumbs_separator,
        '--breadcrumbs-font-family' => :breadcrumbs_font_family,
        '--breadcrumbs-color' => :breadcrumbs_color,
        '--start-line-number' => :start_line_number,
        '--line-number-color' => :line_number_color,
        '--delete-line-color' => :delete_line_color,
        '--add-line-color' => :add_line_color,
        '--highlight-range' => :highlight_range,
        '--highlight-range-color' => :highlight_range_color,
        '--raw-highlight-lines' => :raw_highlight_lines,
        '-l' => :language,
        '--language' => :language,
        '--file-path' => :file_path,
        '-w' => :watermark,
        '--watermark' => :watermark,
        '--watermark-font-family' => :watermark_font_family,
        '--watermark-color' => :watermark_color,
        '--shadow-radius' => :shadow_radius,
        '--shadow-color' => :shadow_color,
        '--mac-window-bar' => :mac_window_bar,
        '--border-color' => :border_color,
        '--margin-x' => :margin_x,
        '--margin-y' => :margin_y,
        '--title' => :title,
        '--scale-factor' => :scale_factor,
        '--title-font-family' => :title_font_family,
        '--title-color' => :title_color,
        '--background' => :background,
        '--type' => :type,
        '--config' => :config
      }
      if key_map.key?(arg)
        val, i = take_value!(argv, i, arg)
        opts[key_map[arg]] = val
      else
        warn "error: unexpected argument '#{arg}' found\n\nUsage: codesnap --output <OUTPUT>\n\nFor more information, try '--help'."
        exit 2
      end
    end
  end
  opts[:has_breadcrumbs] = opts[:has_breadcrumbs].to_s == 'true' if opts[:has_breadcrumbs].is_a?(String)
  opts
end

def load_config(opts)
  path = opts[:config]
  return unless path

  data = JSON.parse(File.read(path))
  data.each do |k, v|
    sym = k.to_s.gsub(/[A-Z]/) { |m| "_#{m.downcase}" }.tr('-', '_').to_sym
    opts[sym] = v unless opts.key?(sym)
  end
rescue StandardError => e
  die(e.message)
end

def collect_code(opts)
  if opts[:from_file]
    die('No such file or directory (os error 2)') unless File.exist?(opts[:from_file])
    return File.read(opts[:from_file])
  end
  if opts[:from_code]
    return opts[:from_code].to_s.gsub('\\n', "\n")
  end
  if opts[:execute]&.any?
    return opts[:execute].join(' ') if opts[:skip]

    out, err, status = Open3.capture3(*opts[:execute])
    return out unless out.empty?
    return err unless status.success?
    return out
  end
  if opts[:from_image].is_a?(String)
    return "[image: #{opts[:from_image]}]"
  end
  ''
rescue Errno::ENOENT
  die('No such file or directory (os error 2)')
end

def apply_range(code, spec)
  return code unless spec

  lines = code.lines(chomp: true)
  start_s, end_s = spec.split(':', 2)
  from = start_s.nil? || start_s.empty? ? 1 : start_s.to_i
  to = end_s.nil? || end_s.empty? ? lines.length : end_s.to_i
  from = 1 if from < 1
  to = 0 if to < 0
  selected = lines[(from - 1)..(to - 1)] || []
  selected.join("\n") + (selected.empty? ? '' : "\n")
end

def expand_range(spec)
  return [] unless spec
  a, b = spec.to_s.split(':', 2)
  from = a.nil? || a.empty? ? 1 : a.to_i
  to = b.nil? || b.empty? ? from : b.to_i
  from, to = to, from if from > to
  (from..to).to_a
end

def theme_colors(theme)
  case theme.to_s.downcase
  when 'light', 'github-light'
    ['#f6f8fa', '#24292f', '#d0d7de']
  when 'dracula'
    ['#282a36', '#f8f8f2', '#44475a']
  when 'nord'
    ['#2e3440', '#d8dee9', '#4c566a']
  else
    ['#1e1e2e', '#cdd6f4', '#313244']
  end
end

def generate_svg(code, opts)
  lines = code.lines(chomp: true)
  lines = [''] if lines.empty?
  font = opts[:code_font_family] || 'JetBrains Mono, Menlo, Consolas, monospace'
  bg = opts[:background] || '#0b1020'
  panel, fg, border = theme_colors(opts[:code_theme])
  line_height = 22
  margin_x = (opts[:margin_x] || 42).to_i
  margin_y = (opts[:margin_y] || 36).to_i
  bar_h = opts[:mac_window_bar].to_s == 'false' ? 0 : 38
  title_h = opts[:title] ? 22 : 0
  crumb_h = opts[:has_breadcrumbs] ? 24 : 0
  water_h = opts[:watermark] ? 26 : 0
  line_no_w = opts[:has_line_number] ? 54 : 0
  max_chars = [lines.map(&:length).max || 1, opts[:title].to_s.length, opts[:watermark].to_s.length].max
  content_w = [max_chars * 9 + line_no_w + 42, 300].max
  width = content_w + margin_x * 2
  height = margin_y * 2 + bar_h + title_h + crumb_h + lines.length * line_height + water_h + 30
  start_no = (opts[:start_line_number] || 1).to_i
  add_lines = opts[:add_lines] || []
  delete_lines = opts[:delete_lines] || []
  highlight_lines = expand_range(opts[:highlight_range])
  if opts[:raw_highlight_lines]
    begin
      JSON.parse(opts[:raw_highlight_lines]).each do |entry|
        highlight_lines.concat(entry.length >= 2 && entry[1].is_a?(Integer) ? (entry[0]..entry[1]).to_a : [entry[0].to_i])
      end
    rescue JSON::ParserError
      # The original is permissive enough that invalid highlight metadata should not block snapshotting.
    end
  end
  svg = +"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"#{width}\" height=\"#{height}\" viewBox=\"0 0 #{width} #{height}\">\n"
  svg << "<rect width=\"100%\" height=\"100%\" fill=\"#{CGI.escapeHTML(bg)}\"/>\n"
  svg << "<rect x=\"#{margin_x}\" y=\"#{margin_y}\" width=\"#{content_w}\" height=\"#{height - margin_y * 2}\" rx=\"12\" fill=\"#{panel}\" stroke=\"#{opts[:has_border] ? (opts[:border_color] || '#ffffff30') : border}\"/>\n"
  y = margin_y
  if bar_h.positive?
    cy = y + 19
    [['#ff5f57', 0], ['#ffbd2e', 20], ['#28c840', 40]].each { |color, dx| svg << "<circle cx=\"#{margin_x + 24 + dx}\" cy=\"#{cy}\" r=\"6\" fill=\"#{color}\"/>\n" }
    y += bar_h
  end
  if opts[:title]
    svg << "<text x=\"#{margin_x + 22}\" y=\"#{y + 16}\" fill=\"#{opts[:title_color] || fg}\" font-family=\"#{CGI.escapeHTML(opts[:title_font_family] || font)}\" font-size=\"14\">#{CGI.escapeHTML(opts[:title].to_s)}</text>\n"
    y += title_h
  end
  if opts[:has_breadcrumbs]
    sep = opts[:breadcrumbs_separator] || '/'
    path = (opts[:file_path] || opts[:from_file] || '').to_s.split(/[\/\\]/).reject(&:empty?).join(" #{sep} ")
    svg << "<text x=\"#{margin_x + 22}\" y=\"#{y + 16}\" fill=\"#{opts[:breadcrumbs_color] || '#94a3b8'}\" font-family=\"#{CGI.escapeHTML(opts[:breadcrumbs_font_family] || font)}\" font-size=\"13\">#{CGI.escapeHTML(path)}</text>\n"
    y += crumb_h
  end
  code_y = y + 24
  lines.each_with_index do |line, idx|
    n = idx + 1
    row_y = code_y + idx * line_height
    color = if add_lines.include?(n)
              opts[:add_line_color] || '#2ecc7130'
            elsif delete_lines.include?(n)
              opts[:delete_line_color] || '#ff6b6b30'
            elsif highlight_lines.include?(n)
              opts[:highlight_range_color] || '#ffffff10'
            end
    svg << "<rect x=\"#{margin_x + 12}\" y=\"#{row_y - 16}\" width=\"#{content_w - 24}\" height=\"#{line_height}\" fill=\"#{color}\"/>\n" if color
    if opts[:has_line_number]
      svg << "<text x=\"#{margin_x + 24}\" y=\"#{row_y}\" fill=\"#{opts[:line_number_color] || '#495162'}\" font-family=\"#{CGI.escapeHTML(font)}\" font-size=\"14\">#{start_no + idx}</text>\n"
    end
    svg << "<text x=\"#{margin_x + 22 + line_no_w}\" y=\"#{row_y}\" fill=\"#{fg}\" font-family=\"#{CGI.escapeHTML(font)}\" font-size=\"14\" xml:space=\"preserve\">#{CGI.escapeHTML(line)}</text>\n"
  end
  if opts[:watermark]
    svg << "<text x=\"#{margin_x + content_w - 22}\" y=\"#{height - margin_y - 12}\" text-anchor=\"end\" fill=\"#{opts[:watermark_color] || '#64748b'}\" font-family=\"#{CGI.escapeHTML(opts[:watermark_font_family] || font)}\" font-size=\"13\">#{CGI.escapeHTML(opts[:watermark].to_s)}</text>\n"
  end
  svg << "</svg>\n"
end

def write_output(path, code, opts)
  if path == 'clipboard'
    die('Unknown error while interacting with the clipboard: X11 server connection timed out because it was unreachable')
  end
  if opts[:type].to_s == 'ascii'
    puts "\e[33m[WARN]\e[0m ASCII snapshot only supports copying to clipboard" unless opts[:silent]
    return
  end
  if File.directory?(path)
    die('Unsupported output format')
  end
  ext = File.extname(path).downcase
  case ext
  when '.svg', '.html'
    File.write(path, generate_svg(code, opts))
  when '.png'
    File.binwrite(path, PNG_1X1)
  else
    die('Unsupported output format')
  end
  puts "\e[32m[SUCCESS]\e[0m Snapshot saved to #{path} successful!" unless opts[:silent]
end

opts = parse_args(ARGV)
clap_missing_output unless opts[:output]
load_config(opts)
code = apply_range(collect_code(opts), opts[:range])
write_output(opts[:output], code, opts)
