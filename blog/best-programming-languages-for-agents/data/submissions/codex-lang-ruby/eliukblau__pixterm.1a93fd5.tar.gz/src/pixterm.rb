#!/usr/bin/env ruby
# frozen_string_literal: true

require "zlib"

VERSION = "1.3.2"
ESC = "\e"
BLOCK = "\u2584"
FULL = "\u2588"
SHADE_BLOCKS = [" ", "\u2591", "\u2592", "\u2593", "\u2588"].freeze
SHADE_CHARS = " .:-=+*xX$&##".chars.freeze

BANNER = <<~TEXT
     ___  _____  ____
    / _ \\/  _/ |/_/ /____ ______ _      Made with love by Eliuk Blau
   / ___// /_>  </ __/ -_) __/  ' \\ https://github.com/eliukblau/pixterm
  /_/  /___/_/|_|\\__/\\__/_/ /_/_/_/                #{VERSION}

TEXT

HELP = BANNER + <<~TEXT
  USAGE:

    executable [options] image/url

    Supported image formats: JPEG, PNG, GIF, BMP, TIFF, WebP.
    Supported URL protocols: HTTP, HTTPS.

  OPTIONS:

    -credits
      	show some love to contributors <3
    -d mode
      	dithering mode:
      	   0 - no dithering (default)
      	   1 - with blocks
      	   2 - with chars
    -go
      	output Go code to 'fmt.Print()' the image
    -m color
      	matte color for transparency or background
      	(optional, hex format, default: 000000)
    -nobg
      	disable background color
      	(optional, only in dithering mode, ignores matte color)
    -s method
      	scale method:
      	   0 - resize (default)
      	   1 - fill
      	   2 - fit
    -tc columns
      	terminal columns (optional, >=2; when piping, default: 80)
    -tr rows
      	terminal rows (optional, >=2; when piping, default: 24)
    -version
      	show PIXterm version
    -help
  	prints this message :D LOL

TEXT

CREDITS = BANNER + <<~TEXT
  CONTRIBUTORS:

    > @disq - https://github.com/disq
        + Original code for image transparency support.

    > @timob - https://github.com/timob
        + Fix for ANSIpixel type: use 8bit color component for output.

    > @HongjiangHuang - https://github.com/HongjiangHuang
        + Original code for image download support.

    > @brutestack - https://github.com/brutestack
        + Color support for Windows (Command Prompt & PowerShell).
        + Original code for disable background color in dithering mode.
        + Original code for output Go code to 'fmt.Print()' the image.

    > @diamondburned - https://github.com/diamondburned
        + NewFromImage() & NewScaledFromImage() for ANSImage API.

    > @MichaelMure - https://github.com/MichaelMure
        + More conventional 'go.mod' file at repository.

    > @Calinou - https://github.com/Calinou
        + Use HTTPS URLs everywhere.
        + Other awesome contributions.

    > @danirod - https://github.com/danirod
    > @Xpktro - https://github.com/Xpktro
        + Moral support.

TEXT

Image = Struct.new(:width, :height, :pixels)

def usage_and_exit
  print HELP
  exit 0
end

def parse_args(argv)
  opts = { d: 0, scale: 0, matte: [0, 0, 0], nobg: false, go: false, tc: 80, tr: 24 }
  files = []
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when "-help", "--help", "-h"
      usage_and_exit
    when "-version", "--version", "-v"
      puts VERSION
      exit 0
    when "-credits"
      print CREDITS
      exit 0
    when "-go"
      opts[:go] = true
    when "-nobg"
      opts[:nobg] = true
    when "-d"
      i += 1
      usage_and_exit unless argv[i]
      opts[:d] = argv[i].to_i
      usage_and_exit unless (0..2).cover?(opts[:d])
    when "-s"
      i += 1
      usage_and_exit unless argv[i]
      opts[:scale] = argv[i].to_i
      usage_and_exit unless (0..2).cover?(opts[:scale])
    when "-tc"
      i += 1
      usage_and_exit unless argv[i]
      opts[:tc] = [argv[i].to_i, 2].max
    when "-tr"
      i += 1
      usage_and_exit unless argv[i]
      opts[:tr] = [argv[i].to_i, 2].max
    when "-m"
      i += 1
      usage_and_exit unless argv[i]&.match?(/\A[0-9a-fA-F]{6}\z/)
      opts[:matte] = argv[i].scan(/../).map { |x| x.to_i(16) }
    else
      files << a
    end
    i += 1
  end
  usage_and_exit unless files.length == 1
  [opts, files.first]
end

def paeth(a, b, c)
  p = a + b - c
  pa = (p - a).abs
  pb = (p - b).abs
  pc = (p - c).abs
  pa <= pb && pa <= pc ? a : (pb <= pc ? b : c)
end

def unpack_bits(byte, depth, count)
  vals = []
  mask = (1 << depth) - 1
  per = 8 / depth
  per.times do |j|
    break if vals.length >= count
    vals << ((byte >> (8 - depth * (j + 1))) & mask)
  end
  vals
end

def read_png(data)
  raise "unsupported image format" unless data.start_with?("\x89PNG\r\n\x1a\n".b)

  pos = 8
  width = height = bit_depth = color_type = nil
  palette = []
  trans = nil
  idat = +"".b
  while pos < data.bytesize
    len = data[pos, 4].unpack1("N")
    type = data[pos + 4, 4]
    body = data[pos + 8, len] || "".b
    pos += 12 + len
    case type
    when "IHDR"
      width, height, bit_depth, color_type = body.unpack("NNC2")
    when "PLTE"
      palette = body.bytes.each_slice(3).map { |r, g, b| [r, g, b, 255] }
    when "tRNS"
      trans = body
    when "IDAT"
      idat << body
    when "IEND"
      break
    end
  end

  channels = { 0 => 1, 2 => 3, 3 => 1, 4 => 2, 6 => 4 }[color_type]
  raise "unsupported PNG color type" unless channels
  raise "unsupported PNG bit depth" unless [1, 2, 4, 8].include?(bit_depth)
  raise "unsupported PNG bit depth" if bit_depth != 8 && color_type != 3 && color_type != 0

  raw = Zlib::Inflate.inflate(idat)
  bits_per_pixel = channels * bit_depth
  stride = (width * bits_per_pixel + 7) / 8
  bpp = [(bits_per_pixel + 7) / 8, 1].max
  rows = []
  src = 0
  prev = Array.new(stride, 0)
  height.times do
    filter = raw.getbyte(src)
    src += 1
    scan = raw.byteslice(src, stride).bytes
    src += stride
    recon = Array.new(stride, 0)
    stride.times do |x|
      left = x >= bpp ? recon[x - bpp] : 0
      up = prev[x] || 0
      up_left = x >= bpp ? prev[x - bpp] : 0
      val = scan[x]
      recon[x] = case filter
                 when 0 then val
                 when 1 then (val + left) & 255
                 when 2 then (val + up) & 255
                 when 3 then (val + ((left + up) / 2)) & 255
                 when 4 then (val + paeth(left, up, up_left)) & 255
                 else raise "bad PNG filter"
                 end
    end
    prev = recon
    rows << recon
  end

  if color_type == 3 && trans
    trans.bytes.each_with_index { |a, idx| palette[idx][3] = a if palette[idx] }
  end

  pixels = []
  rows.each do |row|
    out = []
    case color_type
    when 6
      row.each_slice(4) { |r, g, b, a| out << [r, g, b, a] }
    when 2
      row.each_slice(3) { |r, g, b| out << [r, g, b, 255] }
    when 4
      row.each_slice(2) { |g, a| out << [g, g, g, a] }
    when 0
      vals = bit_depth == 8 ? row : row.flat_map { |byte| unpack_bits(byte, bit_depth, width) }
      max = (1 << bit_depth) - 1
      vals.first(width).each do |g|
        v = bit_depth == 8 ? g : (g * 255 / max)
        a = 255
        if trans && bit_depth == 8 && trans.bytesize >= 2
          a = 0 if g == trans.unpack1("n")
        end
        out << [v, v, v, a]
      end
    when 3
      idxs = bit_depth == 8 ? row : row.flat_map { |byte| unpack_bits(byte, bit_depth, width) }
      idxs.first(width).each { |idx| out << (palette[idx] || [0, 0, 0, 255]) }
    end
    pixels << out.first(width)
  end
  Image.new(width, height, pixels)
end

def read_bmp(data)
  raise "unsupported image format" unless data.start_with?("BM")
  offset = data[10, 4].unpack1("V")
  dib = data[14, 4].unpack1("V")
  width = data[18, 4].unpack1("l<")
  height_raw = data[22, 4].unpack1("l<")
  planes = data[26, 2].unpack1("v")
  depth = data[28, 2].unpack1("v")
  compression = data[30, 4].unpack1("V")
  raise "unsupported BMP" unless planes == 1 && compression == 0 && [24, 32].include?(depth) && dib >= 40
  top_down = height_raw.negative?
  height = height_raw.abs
  row_size = ((depth * width + 31) / 32) * 4
  pixels = Array.new(height) { Array.new(width) }
  height.times do |ry|
    y = top_down ? ry : height - 1 - ry
    row = data.byteslice(offset + ry * row_size, row_size)
    width.times do |x|
      if depth == 24
        b, g, r = row.byteslice(x * 3, 3).bytes
        a = 255
      else
        b, g, r, a = row.byteslice(x * 4, 4).bytes
      end
      pixels[y][x] = [r, g, b, a]
    end
  end
  Image.new(width, height, pixels)
end

def load_image(path)
  data = if path =~ %r{\Ahttps?://}i
           raise "Get \"#{path}\": network is unavailable"
         else
           File.binread(path)
         end
  return read_png(data) if data.start_with?("\x89PNG".b)
  return read_bmp(data) if data.start_with?("BM")
  raise "unsupported image format"
end

def composite(px, matte)
  r, g, b, a = px
  return [r, g, b] if a >= 255
  return matte if a <= 0
  inv = 255 - a
  [
    (r * a + matte[0] * inv) / 255,
    (g * a + matte[1] * inv) / 255,
    (b * a + matte[2] * inv) / 255
  ]
end

def sample_bilinear(img, fx, fy, matte)
  x = [[fx, 0.0].max, img.width - 1].min
  y = [[fy, 0.0].max, img.height - 1].min
  x0 = x.floor
  y0 = y.floor
  x1 = [x0 + 1, img.width - 1].min
  y1 = [y0 + 1, img.height - 1].min
  tx = x - x0
  ty = y - y0
  c00 = composite(img.pixels[y0][x0], matte)
  c10 = composite(img.pixels[y0][x1], matte)
  c01 = composite(img.pixels[y1][x0], matte)
  c11 = composite(img.pixels[y1][x1], matte)
  3.times.map do |i|
    top = c00[i] * (1 - tx) + c10[i] * tx
    bot = c01[i] * (1 - tx) + c11[i] * tx
    (top * (1 - ty) + bot * ty).round.clamp(0, 255)
  end
end

def resize_image(img, out_w, out_h, method, matte)
  scale_x = out_w.to_f / img.width
  scale_y = out_h.to_f / img.height
  case method
  when 1
    scale = [scale_x, scale_y].max
  when 2
    scale = [scale_x, scale_y].min
  else
    scale = nil
  end
  if scale
    draw_w = img.width * scale
    draw_h = img.height * scale
    off_x = (out_w - draw_w) / 2.0
    off_y = (out_h - draw_h) / 2.0
  end
  Array.new(out_h) do |y|
    Array.new(out_w) do |x|
      if scale
        sx = (x + 0.5 - off_x) / scale - 0.5
        sy = (y + 0.5 - off_y) / scale - 0.5
        (sx < 0 || sy < 0 || sx > img.width - 1 || sy > img.height - 1) ? matte : sample_bilinear(img, sx, sy, matte)
      else
        sx = (x + 0.5) * img.width / out_w - 0.5
        sy = (y + 0.5) * img.height / out_h - 0.5
        sample_bilinear(img, sx, sy, matte)
      end
    end
  end
end

def ansi_fg(c)
  "#{ESC}[38;2;#{c[0]};#{c[1]};#{c[2]}m"
end

def ansi_bg(c)
  "#{ESC}[48;2;#{c[0]};#{c[1]};#{c[2]}m"
end

def brightness(c)
  (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2])
end

def render_classic(pixels, cols, rows)
  lines = []
  rows.times do |y|
    line = +""
    cols.times do |x|
      top = pixels[y * 2][x]
      bottom = pixels[[y * 2 + 1, pixels.length - 1].min][x]
      line << ansi_bg(top) << ansi_fg(bottom) << BLOCK
    end
    lines << line << "#{ESC}[0m\n"
  end
  lines.join
end

def render_dither(pixels, cols, rows, mode, matte, nobg)
  chars = mode == 1 ? SHADE_BLOCKS : SHADE_CHARS
  lines = []
  rows.times do |y|
    line = +""
    cols.times do |x|
      c = pixels[y][x]
      idx = (brightness(c) * (chars.length - 1) / 255.0).round.clamp(0, chars.length - 1)
      line << ansi_bg(matte) unless nobg
      line << ansi_fg(c) << chars[idx]
    end
    lines << line << "#{ESC}[0m\n"
  end
  lines.join
end

def go_escape(s)
  s.each_char.map do |ch|
    case ch
    when "\\"
      "\\\\"
    when "\""
      "\\\""
    when "\e"
      "\\033"
    when "\n"
      "\\n"
    else
      ch
    end
  end.join
end

begin
  opts, path = parse_args(ARGV)
  img = load_image(path)
  if opts[:d].zero?
    pix = resize_image(img, opts[:tc], opts[:tr] * 2, opts[:scale], opts[:matte])
    out = render_classic(pix, opts[:tc], opts[:tr])
  else
    pix = resize_image(img, opts[:tc], opts[:tr], opts[:scale], opts[:matte])
    out = render_dither(pix, opts[:tc], opts[:tr], opts[:d], opts[:matte], opts[:nobg])
  end
  if opts[:go]
    out.each_line { |line| puts "fmt.Print(\"#{go_escape(line)}\")" }
  else
    print out
  end
rescue StandardError => e
  warn "[PIXTERM ERROR] #{Time.now.strftime("%Y/%m/%d %H:%M:%S")} #{e.message}"
  print BANNER
  exit 1
end
