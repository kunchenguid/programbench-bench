#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = "code-minimap 0.6.8"
ABOUT = "A high performance code minimap generator"
ENCODINGS = %w[utf8-lossy utf8].freeze
SHELLS = %w[bash elvish fish powershell zsh].freeze

DOTS = [
  [0x01, 0x08],
  [0x02, 0x10],
  [0x04, 0x20],
  [0x40, 0x80]
].freeze

def help_text
  <<~HELP
    #{ABOUT}

    Usage: executable [OPTIONS] [FILE] [COMMAND]

    Commands:
      completion
              Generate shell completion file
      help
              Print this message or the help of the given subcommand(s)

    Arguments:
      [FILE]
              File to read

    Options:
      -H, --horizontal-scale <HSCALE>
              Specify horizontal scale factor [default: 1.0]
      -V, --vertical-scale <VSCALE>
              Specify vertical scale factor [default: 1.0]
          --padding <PADDING>
              Specify padding width
          --encoding <ENCODING>
              Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
          --version
              Print version
      -h, --help
              Print help
  HELP
end

def completion_help
  <<~HELP
    Generate shell completion file

    Usage: executable completion <SHELL>

    Arguments:
      <SHELL>
              Target shell name [possible values: bash, elvish, fish, powershell, zsh]

    Options:
      -h, --help
              Print help
  HELP
end

def fail_usage(message)
  warn message
  warn
  warn "For more information, try '--help'."
  exit 2
end

def invalid_value(value, opt, values)
  warn "error: invalid value '#{value}' for '#{opt}'"
  warn "  [possible values: #{values.join(', ')}]"
  warn
  warn "For more information, try '--help'."
  exit 2
end

def parse_float(value, opt)
  Float(value)
rescue ArgumentError, TypeError
  invalid_value(value, opt, [])
end

def parse_int(value, opt)
  Integer(value, 10)
rescue ArgumentError, TypeError
  invalid_value(value, opt, [])
end

def shell_completion(shell)
  case shell
  when "bash"
    "_executable() { COMPREPLY=( $(compgen -W \"--horizontal-scale --vertical-scale --padding --encoding --version --help completion help\" -- \"${COMP_WORDS[COMP_CWORD]}\") ); }\ncomplete -F _executable executable\n"
  when "fish"
    "complete -c executable -l horizontal-scale -s H -r\ncomplete -c executable -l vertical-scale -s V -r\ncomplete -c executable -l padding -r\ncomplete -c executable -l encoding -r -a 'utf8-lossy utf8'\ncomplete -c executable -l version\ncomplete -c executable -l help -s h\n"
  when "zsh"
    "#compdef executable\n_arguments '*:file:_files' '--horizontal-scale[Specify horizontal scale factor]:HSCALE:' '--vertical-scale[Specify vertical scale factor]:VSCALE:' '--padding[Specify padding width]:PADDING:' '--encoding[Specify input encoding]:(utf8-lossy utf8)' '--version' '--help'\n"
  when "powershell"
    "Register-ArgumentCompleter -Native -CommandName executable -ScriptBlock { param($wordToComplete) '--horizontal-scale','--vertical-scale','--padding','--encoding','--version','--help','completion','help' | Where-Object { $_ -like \"$wordToComplete*\" } }\n"
  when "elvish"
    "set edit:completion:arg-completer[executable] = {|@words| put -- --horizontal-scale --vertical-scale --padding --encoding --version --help completion help }\n"
  else
    ""
  end
end

def parse_args(argv)
  opts = { hscale: 1.0, vscale: 1.0, padding: nil, encoding: "utf8-lossy", file: nil }
  args = argv.dup

  if args[0] == "help"
    if args[1] == "completion"
      puts completion_help
    else
      puts help_text
    end
    exit 0
  end

  if args[0] == "completion"
    if args[1] == "-h" || args[1] == "--help" || args.length < 2
      puts completion_help
      exit(args.length < 2 ? 2 : 0)
    end
    shell = args[1]
    invalid_value(shell, "<SHELL>", SHELLS) unless SHELLS.include?(shell)
    print shell_completion(shell)
    exit 0
  end

  until args.empty?
    arg = args.shift
    case arg
    when "-h", "--help"
      puts help_text
      exit 0
    when "--version"
      puts VERSION
      exit 0
    when "-H", "--horizontal-scale"
      fail_usage("error: a value is required for '#{arg} <HSCALE>' but none was supplied") if args.empty?
      opts[:hscale] = parse_float(args.shift, "#{arg} <HSCALE>")
    when "-V", "--vertical-scale"
      fail_usage("error: a value is required for '#{arg} <VSCALE>' but none was supplied") if args.empty?
      opts[:vscale] = parse_float(args.shift, "#{arg} <VSCALE>")
    when "--padding"
      fail_usage("error: a value is required for '--padding <PADDING>' but none was supplied") if args.empty?
      opts[:padding] = parse_int(args.shift, "--padding <PADDING>")
    when "--encoding"
      fail_usage("error: a value is required for '--encoding <ENCODING>' but none was supplied") if args.empty?
      val = args.shift
      invalid_value(val, "--encoding <ENCODING>", ENCODINGS) unless ENCODINGS.include?(val)
      opts[:encoding] = val
    when /\A-H(.+)/
      opts[:hscale] = parse_float(Regexp.last_match(1), "-H <HSCALE>")
    when /\A-V(.+)/
      opts[:vscale] = parse_float(Regexp.last_match(1), "-V <VSCALE>")
    when /\A-/
      fail_usage("error: unexpected argument '#{arg}' found")
    else
      if opts[:file]
        fail_usage("error: unexpected argument '#{arg}' found")
      else
        opts[:file] = arg
      end
    end
  end
  opts
end

def read_input(path, encoding)
  return "" unless path

  data = File.binread(path)
  if encoding == "utf8"
    str = data.dup.force_encoding("UTF-8")
    unless str.valid_encoding?
      warn "code-minimap: stream did not contain valid UTF-8"
      exit 1
    end
    str
  else
    data.encode("UTF-8", "UTF-8", invalid: :replace, undef: :replace)
  end
rescue SystemCallError => e
  warn "code-minimap: #{e.message}"
  exit 1
end

def lines_for(text)
  return [] if text.empty?

  text.gsub("\r\n", "\n").gsub("\r", "\n").split("\n", -1).tap do |lines|
    lines.pop if lines.last == ""
  end
end

def occupied?(spans, sx, y0, y1)
  ymin = [y0.floor, 0].max
  ymax = [y1.ceil - 1, spans.length - 1].min
  return false if ymax < ymin

  (ymin..ymax).any? do |y|
    span = spans[y]
    span && sx >= span[0] && sx < span[1]
  end
end

def render(text, hscale, vscale, padding)
  raw_lines = lines_for(text)
  return "" if raw_lines.empty?

  spans = raw_lines.map do |line|
    chars = line.rstrip.chars
    first = chars.index { |ch| ch != " " && ch != "\t" }
    first ? [first, chars.length] : nil
  end
  max_width = spans.compact.map(&:last).max || 0
  max_width = 1 if max_width.zero?

  out_w = (max_width * hscale).floor
  yscale = [vscale, 1.0].min
  yscale = 1.0 if yscale <= 0.0
  out_h = [(raw_lines.length * yscale).ceil, 1].max

  rows = []
  (0...out_h).step(4) do |by|
    chars = []
    (0...out_w).step(2) do |bx|
      mask = 0
      4.times do |dy|
        py = by + dy
        next if py >= out_h
        y0 = py / yscale
        y1 = (py + 1) / yscale
        2.times do |dx|
          px = bx + dx
          next if px >= out_w
          sx = (((px + 0.5) * max_width / out_w) - 0.5).round
          mask |= DOTS[dy][dx] if occupied?(spans, sx, y0, y1)
        end
      end
      chars << (0x2800 + mask).chr(Encoding::UTF_8)
    end
    if padding && padding > chars.length
      chars.concat([" "] * (padding - chars.length))
    end
    rows << chars.join
  end
  rows.join("\n") + "\n"
end

opts = parse_args(ARGV)
print render(read_input(opts[:file], opts[:encoding]), opts[:hscale], opts[:vscale], opts[:padding])
