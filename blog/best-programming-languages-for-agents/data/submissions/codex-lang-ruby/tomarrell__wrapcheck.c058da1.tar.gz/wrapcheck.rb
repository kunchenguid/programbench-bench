#!/usr/bin/env ruby
# frozen_string_literal: true

require 'json'
require 'yaml'
require 'find'
require 'fileutils'

HELP = <<~TXT
  wrapcheck: Checks that errors returned from external packages are wrapped

  Usage: wrapcheck [-flag] [package]


  Flags:
    -V	print version and exit
    -all
      	no effect (deprecated)
    -c int
      	display offending line with this many lines of context (default -1)
    -cpuprofile string
      	write CPU profile to this file
    -debug string
      	debug flags, any subset of "fpstv"
    -diff
      	with -fix, don't update the files, but print a unified diff
    -fix
      	apply all suggested fixes
    -flags
      	print analyzer flags in JSON
    -json
      	emit JSON output
    -memprofile string
      	write memory profile to this file
    -source
      	no effect (deprecated)
    -tags string
      	no effect (deprecated)
    -test
      	indicates whether test files should be analyzed, too (default true)
    -trace string
      	write trace log to this file
    -v	no effect (deprecated)
TXT

FLAGS_JSON = [
  { 'Name' => 'V', 'Bool' => true, 'Usage' => 'print version and exit' },
  { 'Name' => 'all', 'Bool' => true, 'Usage' => 'no effect (deprecated)' },
  { 'Name' => 'c', 'Bool' => false, 'Usage' => 'display offending line with this many lines of context' },
  { 'Name' => 'diff', 'Bool' => true, 'Usage' => "with -fix, don't update the files, but print a unified diff" },
  { 'Name' => 'flags', 'Bool' => true, 'Usage' => 'print analyzer flags in JSON' },
  { 'Name' => 'json', 'Bool' => true, 'Usage' => 'emit JSON output' },
  { 'Name' => 'source', 'Bool' => true, 'Usage' => 'no effect (deprecated)' },
  { 'Name' => 'tags', 'Bool' => false, 'Usage' => 'no effect (deprecated)' },
  { 'Name' => 'test', 'Bool' => true, 'Usage' => 'indicates whether test files should be analyzed, too' },
  { 'Name' => 'v', 'Bool' => true, 'Usage' => 'no effect (deprecated)' }
].freeze

DEFAULT_IGNORE_SIGS = [
  '.Errorf(',
  'errors.New(',
  'errors.Unwrap(',
  'errors.Join(',
  '.Wrap(',
  '.Wrapf(',
  '.WithMessage(',
  '.WithMessagef(',
  '.WithStack('
].freeze

IGNORED_DIRS = %w[.git vendor testdata].freeze

def parse_args(argv)
  opts = {
    json: false,
    test: true,
    flags: false,
    context: -1,
    packages: []
  }
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '--help', '-help', '-h'
      puts HELP
      exit 0
    when '-flags'
      opts[:flags] = true
    when '-json'
      opts[:json] = true
    when '-all', '-source', '-v', '-fix', '-diff'
      # accepted for compatibility; this reimplementation only reports.
    when '-test=false'
      opts[:test] = false
    when '-test=true', '-test'
      opts[:test] = true
    when /\A-c=(.*)\z/
      opts[:context] = Regexp.last_match(1).to_i
    when '-c'
      i += 1
      opts[:context] = argv[i].to_i if argv[i]
    when /\A-(?:cpuprofile|memprofile|trace|debug|tags)=/
      # accepted, ignored
    when '-cpuprofile', '-memprofile', '-trace', '-debug', '-tags'
      i += 1
    when /\A-V(?:=(.*))?\z/
      val = Regexp.last_match(1)
      if val == 'full'
        warn 'wrapcheck: open /workspace/executable: permission denied'
      else
        warn "wrapcheck: unsupported flag value: -V=#{val || 'true'} (use -V=full)"
      end
      exit 1
    else
      if arg.start_with?('-')
        warn "wrapcheck: flag provided but not defined: #{arg}"
        puts HELP
        exit 1
      end
      opts[:packages] << arg
    end
    i += 1
  end
  opts
end

def load_config(start_dir)
  paths = [File.join(start_dir, '.wrapcheck.yaml')]
  paths << File.join(Dir.home, '.wrapcheck.yaml') if Dir.home
  path = paths.find { |p| File.file?(p) }
  raw = path ? (YAML.load_file(path) || {}) : {}
  ignore = raw['ignoreSigs'] || raw[:ignoreSigs] || DEFAULT_IGNORE_SIGS
  extra = raw['extraIgnoreSigs'] || raw[:extraIgnoreSigs] || []
  regex = raw['ignoreSigRegexps'] || raw[:ignoreSigRegexps] || []
  iface = raw['ignoreInterfaceRegexps'] || raw[:ignoreInterfaceRegexps] || []
  {
    ignore_sigs: Array(ignore) + Array(extra),
    ignore_regexps: Array(regex).map { |r| Regexp.new(r) rescue nil }.compact,
    ignore_pkg_globs: Array(raw['ignorePackageGlobs'] || raw[:ignorePackageGlobs]),
    ignore_iface_regexps: Array(iface).map { |r| Regexp.new(r) rescue nil }.compact,
    report_internal: raw.key?('reportInternalErrors') ? raw['reportInternalErrors'] : raw[:reportInternalErrors]
  }
rescue StandardError => e
  warn "wrapcheck: failed to read config: #{e.message}"
  {
    ignore_sigs: DEFAULT_IGNORE_SIGS,
    ignore_regexps: [],
    ignore_pkg_globs: [],
    ignore_iface_regexps: [],
    report_internal: false
  }
end

def module_path(dir)
  cur = File.expand_path(dir)
  loop do
    gomod = File.join(cur, 'go.mod')
    if File.file?(gomod)
      File.foreach(gomod) do |line|
        return Regexp.last_match(1).strip if line =~ /^\s*module\s+(\S+)/
      end
    end
    parent = File.dirname(cur)
    break if parent == cur
    cur = parent
  end
  nil
end

def resolve_package_arg(arg)
  if arg.end_with?('/...')
    base = arg[0...-4]
    base = '.' if base.empty?
    dirs = []
    Find.find(File.expand_path(base)) do |path|
      if File.directory?(path)
        name = File.basename(path)
        if IGNORED_DIRS.include?(name)
          Find.prune
        else
          dirs << path if Dir.glob(File.join(path, '*.go')).any?
        end
      end
    end
    dirs
  else
    [File.expand_path(arg)]
  end
end

def go_files_for_packages(packages, include_tests)
  packages.flat_map { |p| resolve_package_arg(p) }.uniq.flat_map do |dir|
    next [] unless File.directory?(dir)
    Dir.glob(File.join(dir, '*.go')).reject { |f| !include_tests && f.end_with?('_test.go') }
  end.sort
end

def parse_imports(lines)
  imports = {}
  in_block = false
  lines.each do |line|
    stripped = line.sub(%r{//.*$}, '').strip
    if in_block
      if stripped == ')'
        in_block = false
        next
      end
      add_import(imports, stripped)
    elsif stripped.start_with?('import (')
      in_block = true
    elsif stripped.start_with?('import ')
      add_import(imports, stripped.sub(/\Aimport\s+/, ''))
    end
  end
  imports
end

def add_import(imports, text)
  return if text.empty?
  if text =~ /\A(?:(\w+|\.)\s+)?"([^"]+)"/
    alias_name = Regexp.last_match(1)
    path = Regexp.last_match(2)
    return if alias_name == '.'
    name = alias_name || File.basename(path)
    imports[name] = path
  end
end

def ignored_signature?(sig, import_path, config)
  return true if config[:ignore_sigs].any? { |s| sig.include?(s) }
  return true if config[:ignore_regexps].any? { |r| sig =~ r }
  config[:ignore_pkg_globs].any? { |g| File.fnmatch?(g, import_path || '') }
end

def external_import?(path, mod, config)
  return true if mod.nil? || mod.empty?
  internal = path == mod || path.start_with?("#{mod}/")
  config[:report_internal] ? true : !internal
end

def call_from_expr(expr, imports)
  expr = expr.strip
  expr = expr[1..-2].strip while expr.start_with?('(') && expr.end_with?(')')
  if expr =~ /\A([A-Za-z_]\w*)\.([A-Za-z_]\w*)\s*\(/
    pkg = Regexp.last_match(1)
    meth = Regexp.last_match(2)
    path = imports[pkg]
    return nil unless path
    { package: pkg, import_path: path, signature: "#{pkg}.#{meth}(" }
  end
  if expr =~ /\.([A-Za-z_]\w*)\s*\(/
    { package: nil, import_path: nil, signature: ".#{Regexp.last_match(1)}(", interface: true }
  end
end

def split_return_exprs(text)
  out = []
  cur = +''
  depth = 0
  text.each_char do |ch|
    case ch
    when '('
      depth += 1
    when ')'
      depth -= 1 if depth.positive?
    when ','
      if depth.zero?
        out << cur.strip
        cur = +''
        next
      end
    end
    cur << ch
  end
  out << cur.strip unless cur.strip.empty?
  out
end

def line_col(line, token)
  idx = line.index(token)
  idx ? idx + 1 : 1
end

def diagnostic(file, idx, col, msg)
  { file: file, line: idx + 1, col: col, message: msg }
end

def analyze_file(file, mod, config)
  lines = File.readlines(file, chomp: true)
  imports = parse_imports(lines)
  diags = []
  origins = {}
  depth = 0
  in_func = false

  lines.each_with_index do |line, idx|
    code = line.sub(%r{//.*$}, '')
    in_func = true if code =~ /^\s*func\b/
    origins.clear if in_func && code =~ /^\s*func\b/

    imports.each do |pkg, path|
      next unless external_import?(path, mod, config)
      next unless code.include?("#{pkg}.")
      code.scan(/(?:\A|[;{])\s*([^;=]+?)(?::=|=).*?\b#{Regexp.escape(pkg)}\.([A-Za-z_]\w*)\s*\(/) do |lhs, meth|
        lhs = lhs.split(/[;{]/).last.to_s
        var = lhs.split(',').map(&:strip).reverse.find { |v| v =~ /\A[A-Za-z_]\w*\z/ && v != '_' }
        next unless var
        sig = "#{pkg}.#{meth}("
        origins[var] = { import_path: path, signature: sig, line: idx, col: line_col(line, var) }
      end
    end

    if code =~ /\breturn\b(.*)/
      rest = Regexp.last_match(1).sub(/\s*}.*\z/, '').strip
      split_return_exprs(rest).each do |expr|
        origin = origins[expr]
        imported_call = nil
        imports.each do |pkg, path|
          if expr =~ /\A#{Regexp.escape(pkg)}\.([A-Za-z_]\w*)\s*\(/
            imported_call = { package: pkg, import_path: path, signature: "#{pkg}.#{Regexp.last_match(1)}(" }
            break
          end
        end
        call = imported_call || call_from_expr(expr, imports)
        item = origin || call
        next unless item
        next if item[:interface] && config[:ignore_iface_regexps].any? { |r| expr =~ r }
        unless item[:interface]
          next unless external_import?(item[:import_path], mod, config)
        end
        sig = item[:signature]
        next if ignored_signature?(sig, item[:import_path], config)
        msg = item[:interface] ? "error returned from interface method is unwrapped" : "error returned from external package is unwrapped"
        msg = "#{msg}: #{sig}"
        diags << diagnostic(file, idx, line_col(line, expr), msg)
      end
    end

    depth += code.count('{')
    depth -= code.count('}')
    if in_func && depth <= 0
      in_func = false
      origins.clear
      depth = 0
    end
  end
  diags
end

def print_text(diags, context)
  diags.each do |d|
    puts "#{d[:file]}:#{d[:line]}:#{d[:col]}: #{d[:message]}"
    next unless context && context >= 0
    lines = File.readlines(d[:file], chomp: true)
    from = [d[:line] - context, 1].max
    to = [d[:line] + context, lines.length].min
    (from..to).each do |ln|
      puts "#{ln.to_s.rjust(5)}\t#{lines[ln - 1]}"
    end
  end
end

opts = parse_args(ARGV)
if opts[:flags]
  puts JSON.pretty_generate(FLAGS_JSON)
  exit 0
end

if opts[:packages].empty?
  puts HELP
  exit 1
end

config = load_config(Dir.pwd)
files = go_files_for_packages(opts[:packages], opts[:test])
mod = module_path(Dir.pwd)
diags = files.flat_map { |f| analyze_file(f, mod, config) }.sort_by { |d| [d[:file], d[:line], d[:col]] }

if opts[:json]
  grouped = {}
  diags.each do |d|
    grouped[d[:file]] ||= []
    grouped[d[:file]] << {
      'posn' => "#{d[:file]}:#{d[:line]}:#{d[:col]}",
      'message' => d[:message]
    }
  end
  puts JSON.pretty_generate('wrapcheck' => grouped)
else
  print_text(diags, opts[:context])
end

exit(diags.empty? ? 0 : 3)
