#!/usr/bin/env ruby
# frozen_string_literal: true

require "find"

VERSION = "igrep 1.3.0"

EDITORS = %w[
  vim neovim nvim nano code vscode code-insiders emacs emacsclient hx helix
  subl sublime-text micro intellij goland pycharm less fresh
].freeze

THEMES = %w[light dark].freeze
CONTEXT_VIEWERS = %w[none vertical horizontal].freeze
SORTS = %w[path modified created accessed].freeze

TYPE_LIST = <<~TYPES
ada: *.adb, *.ads
agda: *.agda, *.lagda
aidl: *.aidl
alire: alire.toml
amake: *.bp, *.mk
asciidoc: *.adoc, *.asc, *.asciidoc
asm: *.S, *.asm, *.s
asp: *.ascx, *.ascx.cs, *.ascx.vb, *.asp, *.aspx, *.aspx.cs, *.aspx.vb
ats: *.ats, *.dats, *.hats, *.sats
avro: *.avdl, *.avpr, *.avsc
awk: *.awk
bat: *.bat
batch: *.bat
bazel: *.BUILD, *.bazel, *.bazelrc, *.bzl, BUILD, MODULE.bazel, WORKSPACE, WORKSPACE.bazel
bitbake: *.bb, *.bbappend, *.bbclass, *.conf, *.inc
brotli: *.br
buildstream: *.bst
bzip2: *.bz2, *.tbz2
c: *.[chH], *.[chH].in, *.cats
cabal: *.cabal
candid: *.did
carp: *.carp
cbor: *.cbor
ceylon: *.ceylon
clojure: *.clj, *.cljc, *.cljs, *.cljx
cmake: *.cmake, CMakeLists.txt
cmd: *.bat, *.cmd
cml: *.cml
coffeescript: *.coffee
config: *.cfg, *.conf, *.config, *.ini
coq: *.v
cpp: *.[ChH], *.[ChH].in, *.[ch]pp, *.[ch]pp.in, *.[ch]xx, *.[ch]xx.in, *.cc, *.cc.in, *.hh, *.hh.in, *.inl
creole: *.creole
crystal: *.cr, *.ecr, Projectfile, shard.yml
cs: *.cs
csharp: *.cs
cshtml: *.cshtml
csproj: *.csproj
css: *.css, *.scss
csv: *.csv
cuda: *.cu, *.cuh
cython: *.pxd, *.pxi, *.pyx
d: *.d
dart: *.dart
devicetree: *.dts, *.dtsi
dhall: *.dhall
diff: *.diff, *.patch
dita: *.dita, *.ditamap, *.ditaval
docker: *Dockerfile*
dockercompose: docker-compose.*.yml, docker-compose.yml
dts: *.dts, *.dtsi
dvc: *.dvc, Dvcfile
ebuild: *.ebuild, *.eclass
edn: *.edn
elisp: *.el
elixir: *.eex, *.ex, *.exs, *.heex, *.leex, *.livemd
elm: *.elm
erb: *.erb
erlang: *.erl, *.hrl
fennel: *.fnl
fidl: *.fidl
fish: *.fish
flatbuffers: *.fbs
fortran: *.F, *.F77, *.F90, *.F95, *.f, *.f77, *.f90, *.f95, *.pfo
fsharp: *.fs, *.fsi, *.fsx
fut: *.fut
gap: *.g, *.gap, *.gd, *.gi, *.tst
gn: *.gn, *.gni
go: *.go
gprbuild: *.gpr
gradle: *.gradle, *.gradle.kts, gradle-wrapper.*, gradle.properties, gradlew, gradlew.bat
graphql: *.graphql, *.graphqls
groovy: *.gradle, *.groovy
gzip: *.gz, *.tgz
h: *.h, *.hh, *.hpp
haml: *.haml
hare: *.ha
haskell: *.c2hs, *.cpphs, *.hs, *.hsc, *.lhs
hbs: *.hbs
hs: *.hs, *.lhs
html: *.ejs, *.htm, *.html
hy: *.hy
idris: *.idr, *.lidr
janet: *.janet
java: *.java, *.jsp, *.jspx, *.properties
jinja: *.j2, *.jinja, *.jinja2
jl: *.jl
js: *.cjs, *.js, *.jsx, *.mjs, *.vue
json: *.json, *.sarif, composer.lock
jsonl: *.jsonl
julia: *.jl
jupyter: *.ipynb, *.jpynb
k: *.k
kotlin: *.kt, *.kts
lean: *.lean
less: *.less
license: *[.-]LICEN[CS]E*, AGPL-*[0-9]*, APACHE-*[0-9]*, BSD-*[0-9]*, CC-BY-*, COPYING, COPYING[.-]*, COPYRIGHT, COPYRIGHT[.-]*, EULA, EULA[.-]*, GFDL-*[0-9]*, GNU-*[0-9]*, GPL-*[0-9]*, LGPL-*[0-9]*, LICEN[CS]E, LICEN[CS]E[.-]*, MIT-*[0-9]*, MPL-*[0-9]*, NOTICE, NOTICE[.-]*, OFL-*[0-9]*, PATENTS, PATENTS[.-]*, UNLICEN[CS]E, UNLICEN[CS]E[.-]*, agpl[.-]*, gpl[.-]*, lgpl[.-]*, licen[cs]e, licen[cs]e.*
lilypond: *.ily, *.ly
lisp: *.el, *.jl, *.lisp, *.lsp, *.sc, *.scm
lock: *.lock, package-lock.json
log: *.log
lua: *.lua
lz4: *.lz4
lzma: *.lzma
m4: *.ac, *.m4
make: *.mak, *.mk, [Gg][Nn][Uu]makefile, [Gg][Nn][Uu]makefile.am, [Gg][Nn][Uu]makefile.in, [Mm]akefile, [Mm]akefile.am, [Mm]akefile.in
mako: *.mako, *.mao
man: *.[0-9][cEFMmpSx], *.[0-9lnpx]
markdown: *.markdown, *.md, *.mdown, *.mdwn, *.mdx, *.mkd, *.mkdn
matlab: *.m
md: *.markdown, *.md, *.mdown, *.mdwn, *.mdx, *.mkd, *.mkdn
meson: meson.build, meson.options, meson_options.txt
minified: *.min.css, *.min.html, *.min.js
mint: *.mint
mk: mkfile
ml: *.ml
motoko: *.mo
msbuild: *.csproj, *.fsproj, *.proj, *.props, *.sln, *.targets, *.vcxproj
nim: *.nim, *.nimble, *.nimf, *.nims
nix: *.nix
objc: *.h, *.m
objcpp: *.h, *.mm
ocaml: *.ml, *.mli, *.mll, *.mly
org: *.org, *.org_archive
pants: BUILD
pascal: *.dpr, *.inc, *.lpr, *.pas, *.pp
pdf: *.pdf
perl: *.PL, *.perl, *.pl, *.plh, *.plx, *.pm, *.t
php: *.php, *.php3, *.php4, *.php5, *.php7, *.php8, *.pht, *.phtml
po: *.po
pod: *.pod
postscript: *.eps, *.ps
prolog: *.P, *.pl, *.pro, *.prolog
protobuf: *.proto
ps: *.cdxml, *.ps1, *.ps1xml, *.psd1, *.psm1
puppet: *.epp, *.erb, *.pp, *.rb
purs: *.purs
py: *.py, *.pyi
python: *.py, *.pyi
qmake: *.prf, *.pri, *.pro
qml: *.qml
r: *.R, *.Rmd, *.Rnw, *.r
racket: *.rkt
raku: *.p6, *.pl6, *.pm6, *.raku, *.rakudoc, *.rakumod, *.rakutest
rdoc: *.rdoc
readme: *README, README*
reasonml: *.re, *.rei
red: *.r, *.red, *.reds
rescript: *.res, *.resi
robot: *.robot
rst: *.rst
ruby: *.gemspec, *.rb, *.rbw, .irbrc, Gemfile, Rakefile, config.ru
rust: *.rs
sass: *.sass, *.scss
scala: *.sbt, *.scala
sh: *.bash, *.bashrc, *.csh, *.cshrc, *.ksh, *.kshrc, *.sh, *.tcsh, *.zsh, .bash_login, .bash_logout, .bash_profile, .bashrc, .cshrc, .kshrc, .login, .logout, .profile, .tcshrc, .zlogin, .zlogout, .zprofile, .zshenv, .zshrc, bash_login, bash_logout, bash_profile, bashrc, profile, zlogin, zlogout, zprofile, zshenv, zshrc
slim: *.skim, *.slim, *.slime
smarty: *.tpl
sml: *.sig, *.sml
solidity: *.sol
soy: *.soy
spark: *.spark
spec: *.spec
sql: *.psql, *.sql
stylus: *.styl
sv: *.h, *.sv, *.svh, *.v, *.vg
svg: *.svg
swift: *.swift
swig: *.def, *.i
systemd: *.automount, *.conf, *.device, *.link, *.mount, *.path, *.scope, *.service, *.slice, *.socket, *.swap, *.target, *.timer
taskpaper: *.taskpaper
tcl: *.tcl
tex: *.bib, *.cls, *.dtx, *.ins, *.ltx, *.sty, *.tex
texinfo: *.texi
textile: *.textile
tf: *.auto.tfvars, *.auto.tfvars.json, *.terraform.lock.hcl, *.terraformrc, *.tf, *.tf.json, *.tfrc, terraform.rc, terraform.tfvars, terraform.tfvars.json
thrift: *.thrift
toml: *.toml, Cargo.lock
ts: *.cts, *.mts, *.ts, *.tsx
twig: *.twig
txt: *.txt
typescript: *.cts, *.mts, *.ts, *.tsx
typoscript: *.ts, *.typoscript
usd: *.usd, *.usda, *.usdc
v: *.v, *.vsh
vala: *.vala
vb: *.vb
vcl: *.vcl
verilog: *.sv, *.svh, *.v, *.vh
vhdl: *.vhd, *.vhdl
vim: *.vim, .gvimrc, .vimrc, _gvimrc, _vimrc, gvimrc, vimrc
vimscript: *.vim, .gvimrc, .vimrc, _gvimrc, _vimrc, gvimrc, vimrc
webidl: *.idl, *.webidl, *.widl
wiki: *.mediawiki, *.wiki
xml: *.dtd, *.rng, *.sch, *.xhtml, *.xjb, *.xml, *.xml.dist, *.xsd, *.xsl, *.xslt
xz: *.txz, *.xz
yacc: *.y
yaml: *.yaml, *.yml
yang: *.yang
z: *.Z
zig: *.zig
zsh: *.zsh, .zlogin, .zlogout, .zprofile, .zshenv, .zshrc, zlogin, zlogout, zprofile, zshenv, zshrc
zstd: *.zst, *.zstd
TYPES

HELP_TEXT = <<~HELP
  Interactive Grep

  Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

  Arguments:
    <PATTERN>   Regular expression used for searching
    [PATHS]...  Files or directories to search. Directories are searched recursively. If not specified, searching starts from current directory

  Options:
        --editor <EDITOR>
            Text editor used to open selected match [possible values: #{EDITORS.join(', ')}]
        --custom-command <CUSTOM_COMMAND>
            Custom command used to open selected match. Must contain {file_name} and {line_number} tokens [env: IGREP_CUSTOM_EDITOR=]
        --theme <THEME>
            UI color theme [default: dark] [possible values: light, dark]
    -i, --ignore-case
            Searches case insensitively
    -S, --smart-case
            Searches case insensitively if the pattern is all lowercase. Search case sensitively otherwise
    -., --hidden
            Search hidden files and directories. By default, hidden files and directories are skipped
    -L, --follow
            Follow symbolic links while traversing directories
    -w, --word-regexp
            Only show matches surrounded by word boundaries
    -F, --fixed-strings
            Exact matches with no regex. Useful when searching for a string full of delimiters
    -U, --multiline
            Search with pattern contains newline character ('\\n')
    -g, --glob <GLOB>
            Include files and directories for searching that match the given glob. Multiple globs may be provided
        --type-list
            Show all supported file types and their corresponding globs
    -t, --type <TYPE_MATCHING>
            Only search files matching TYPE. Multiple types may be provided
    -T, --type-not <TYPE_NOT>
            Do not search files matching TYPE-NOT. Multiple types-not may be provided
        --context-viewer <CONTEXT_VIEWER>
            Context viewer position at startup [default: none] [possible values: none, vertical, horizontal]
        --sort <SORT_BY>
            Sort results, see ripgrep for details [possible values: path, modified, created, accessed]
        --sortr <SORT_BY_REVERSE>
            Sort results reverse, see ripgrep for details [possible values: path, modified, created, accessed]
    -h, --help
            Print help
    -V, --version
            Print version
HELP

def err(message, code = 2)
  warn message
  exit code
end

def clap_invalid_value(value, option, metavar, possible)
  err <<~MSG.chomp
    error: invalid value '#{value}' for '#{option} <#{metavar}>'
      [possible values: #{possible.join(', ')}]

    For more information, try '--help'.
  MSG
end

TYPE_GLOBS = TYPE_LIST.lines.each_with_object({}) do |line, h|
  name, globs = line.chomp.split(": ", 2)
  h[name] = (globs || "").split(", ")
end

opts = {
  ignore_case: false,
  smart_case: false,
  hidden: false,
  follow: false,
  word: false,
  fixed: false,
  multiline: false,
  globs: [],
  types: [],
  type_not: [],
  sort: nil,
  sortr: nil
}

args = ARGV.dup
positionals = []
i = 0
while i < args.length
  a = args[i]
  case a
  when "--help", "-h"
    puts HELP_TEXT
    exit 0
  when "--version", "-V"
    puts VERSION
    exit 0
  when "--type-list"
    opts[:type_list] = true
  when "--editor"
    i += 1
    value = args[i] || ""
    clap_invalid_value(value, "--editor", "EDITOR", EDITORS) unless EDITORS.include?(value)
  when /^--editor=(.*)$/
    value = Regexp.last_match(1)
    clap_invalid_value(value, "--editor", "EDITOR", EDITORS) unless EDITORS.include?(value)
  when "--theme"
    i += 1
    value = args[i] || ""
    clap_invalid_value(value, "--theme", "THEME", THEMES) unless THEMES.include?(value)
  when /^--theme=(.*)$/
    value = Regexp.last_match(1)
    clap_invalid_value(value, "--theme", "THEME", THEMES) unless THEMES.include?(value)
  when "--context-viewer"
    i += 1
    value = args[i] || ""
    clap_invalid_value(value, "--context-viewer", "CONTEXT_VIEWER", CONTEXT_VIEWERS) unless CONTEXT_VIEWERS.include?(value)
  when /^--context-viewer=(.*)$/
    value = Regexp.last_match(1)
    clap_invalid_value(value, "--context-viewer", "CONTEXT_VIEWER", CONTEXT_VIEWERS) unless CONTEXT_VIEWERS.include?(value)
  when "--sort"
    i += 1
    value = args[i] || ""
    clap_invalid_value(value, "--sort", "SORT_BY", SORTS) unless SORTS.include?(value)
    opts[:sort] = value
  when /^--sort=(.*)$/
    value = Regexp.last_match(1)
    clap_invalid_value(value, "--sort", "SORT_BY", SORTS) unless SORTS.include?(value)
    opts[:sort] = value
  when "--sortr"
    i += 1
    value = args[i] || ""
    clap_invalid_value(value, "--sortr", "SORT_BY_REVERSE", SORTS) unless SORTS.include?(value)
    opts[:sortr] = value
  when /^--sortr=(.*)$/
    value = Regexp.last_match(1)
    clap_invalid_value(value, "--sortr", "SORT_BY_REVERSE", SORTS) unless SORTS.include?(value)
    opts[:sortr] = value
  when "--custom-command"
    i += 1
    value = args[i] || ""
    unless value.include?("{file_name}") && value.include?("{line_number}") && value.split.length > 1
      err "Error: Incorrect editor command: '#{value}'\n\nCaused by:\n    Expected program and its arguments", 1
    end
  when /^--custom-command=(.*)$/
    value = Regexp.last_match(1)
    unless value.include?("{file_name}") && value.include?("{line_number}") && value.split.length > 1
      err "Error: Incorrect editor command: '#{value}'\n\nCaused by:\n    Expected program and its arguments", 1
    end
  when "-i", "--ignore-case"
    opts[:ignore_case] = true
  when "-S", "--smart-case"
    opts[:smart_case] = true
  when "-.", "--hidden"
    opts[:hidden] = true
  when "-L", "--follow"
    opts[:follow] = true
  when "-w", "--word-regexp"
    opts[:word] = true
  when "-F", "--fixed-strings"
    opts[:fixed] = true
  when "-U", "--multiline"
    opts[:multiline] = true
  when "-g", "--glob"
    i += 1
    opts[:globs] << (args[i] || "")
  when /^--glob=(.*)$/
    opts[:globs] << Regexp.last_match(1)
  when "-t", "--type"
    i += 1
    opts[:types] << (args[i] || "")
  when /^--type=(.*)$/
    opts[:types] << Regexp.last_match(1)
  when "-T", "--type-not"
    i += 1
    opts[:type_not] << (args[i] || "")
  when /^--type-not=(.*)$/
    opts[:type_not] << Regexp.last_match(1)
  when "--"
    positionals.concat(args[(i + 1)..] || [])
    break
  when /^--/
    err <<~MSG.chomp
      error: unexpected argument '#{a}' found

        tip: to pass '#{a}' as a value, use '-- #{a}'

      Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

      For more information, try '--help'.
    MSG
  else
    positionals << a
  end
  i += 1
end

if opts[:type_list]
  if positionals.any?
    err <<~MSG.chomp
      error: the argument '--type-list' cannot be used with '<PATTERN>'

      Usage: executable --type-list <PATTERN> [PATHS]...

      For more information, try '--help'.
    MSG
  end
  print TYPE_LIST
  exit 0
end

if positionals.empty?
  err <<~MSG.chomp
    error: the following required arguments were not provided:
      --type-list
      <PATTERN>

    Usage: executable --type-list <PATTERN> [PATHS]...

    For more information, try '--help'.
  MSG
end

(opts[:types] + opts[:type_not]).each do |t|
  err "Error: unrecognized file type: #{t}", 1 unless TYPE_GLOBS.key?(t)
end

pattern = positionals.shift
paths = positionals.empty? ? ["."] : positionals

case_insensitive = opts[:ignore_case] || (opts[:smart_case] && pattern == pattern.downcase)
search_pattern = opts[:fixed] ? Regexp.escape(pattern) : pattern
search_pattern = "\\b#{search_pattern}\\b" if opts[:word]
regexp = Regexp.new(search_pattern, case_insensitive ? Regexp::IGNORECASE : 0)

def hidden_path?(path)
  path.split(File::SEPARATOR).any? { |part| part.start_with?(".") && part != "." && part != ".." }
end

def glob_match?(path, glob)
  File.fnmatch?(glob, File.basename(path), File::FNM_PATHNAME | File::FNM_EXTGLOB) ||
    File.fnmatch?(glob, path, File::FNM_PATHNAME | File::FNM_EXTGLOB)
end

def type_match?(path, type, type_globs)
  type_globs.fetch(type, []).any? { |g| glob_match?(path, g) }
end

files = []
paths.each do |p|
  next unless File.exist?(p)

  if File.directory?(p)
    Find.find(p) do |candidate|
      if candidate != p && File.directory?(candidate) && !opts[:hidden] && hidden_path?(candidate)
        Find.prune
      end
      next unless File.file?(candidate)
      next if !opts[:hidden] && hidden_path?(candidate)

      files << candidate
    end
  elsif File.file?(p)
    next if !opts[:hidden] && hidden_path?(p)

    files << p
  end
end

files.select! { |f| opts[:globs].any? { |g| glob_match?(f, g) } } if opts[:globs].any?
files.select! { |f| opts[:types].any? { |t| type_match?(f, t, TYPE_GLOBS) } } if opts[:types].any?
files.reject! { |f| opts[:type_not].any? { |t| type_match?(f, t, TYPE_GLOBS) } } if opts[:type_not].any?

sort_key = opts[:sort] || opts[:sortr]
if sort_key
  files.sort_by! do |f|
    case sort_key
    when "modified" then File.mtime(f)
    when "created" then File.ctime(f)
    when "accessed" then File.atime(f)
    else f
    end
  end
  files.reverse! if opts[:sortr]
else
  files.sort!
end

matched = false
files.each do |file|
  begin
    if opts[:multiline]
      content = File.binread(file).force_encoding("UTF-8")
      next unless content.match?(regexp)

      content.each_line.with_index(1) do |line, line_no|
        if line.match?(regexp) || content.match?(regexp)
          puts "#{file}:#{line_no}:#{line.chomp}"
          matched = true
        end
      end
    else
      File.foreach(file).with_index(1) do |line, line_no|
        next unless line.match?(regexp)

        puts "#{file}:#{line_no}:#{line.chomp}"
        matched = true
      end
    end
  rescue ArgumentError, Encoding::InvalidByteSequenceError, Encoding::UndefinedConversionError
    next
  rescue Errno::EACCES, Errno::ENOENT, Errno::EISDIR
    next
  end
end

exit(matched ? 0 : 1)
