#!/usr/bin/env ruby
# frozen_string_literal: true

class Tuc
  VERSION = "tuc 1.3.0"
  HELP = <<~TXT
    tuc 1.3.0
    Cut text (or bytes) where a delimiter matches, then keep the desired parts.

    USAGE:
        tuc [FLAGS] [OPTIONS] < input
        tuc [FLAGS] [OPTIONS] filepath

    FLAGS:
        -g, --greedy-delimiter        Match consecutive delimiters as if it was one
        -p, --compress-delimiter      Print only the first delimiter of a sequence
        -s, --only-delimited          Print only lines containing the delimiter
        -V, --version                 Print version information
        -z, --zero-terminated         Line delimiter is NUL (\0), not LF (\n)
        -h, --help                    Print this help and exit
        -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
        -j, --(no-)join               Print selected parts with delimiter in between
        --json                        Print fields as a JSON array of strings
        --no-mmap                     Disable memory mapping

    OPTIONS:
        -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated. [default: 1:]
        -b, --bytes <bounds>          Same as --fields, but it keeps bytes
        -c, --characters <bounds>     Same as --fields, but it keeps characters
        -l, --lines <bounds>          Same as --fields, but it keeps lines
        -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text [default: \t]
        -e, --regex <some regex>      Use a regular expression as delimiter
        -r, --replace-delimiter <new> Replace the delimiter with the provided text. Implies --join
        -t, --trim <type>             Trim the delimiter (greedy). Valid values are (l|L)eft, (r|R)ight, (b|B)oth
            --fallback-oob <fallback> Generic fallback output for any field that cannot be found
        -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.
  TXT
  NOARGS = <<~TXT
    tuc 1.3.0 - Created by Riccardo Attilio Galli

    Cut text (or bytes) where a delimiter matches, then keep the desired parts.

    Some examples:

        $ echo "a/b/c" | tuc -d / -f 1,-1
        ac

        $ echo "a/b/c" | tuc -d / -f 2:
        b/c

        $ echo "hello.bak" | tuc -d . -f 'mv {1:} {1}'
        mv hello.bak hello

        $ printf "a\\nb\\nc\\nd\\ne" | tuc -l 2:-2
        b
        c
        d

    Run `tuc --help` for more detailed information.
    Send bug reports to: https://github.com/riquito/tuc/issues
  TXT

  Selector = Struct.new(:a, :b, :fallback, :range, keyword_init: true)

  def initialize(argv)
    @mode = :fields
    @bounds = '1:'
    @delimiter = "\t"
    @regex = nil
    @greedy = false
    @compress = false
    @only_delimited = false
    @zero = false
    @complement = false
    @join = nil
    @replace = nil
    @json = false
    @fallback_oob = nil
    @format = false
    @filepath = nil
    parse_args(argv.dup)
    @join = true if @replace
    @join = true if @mode == :lines && @join.nil?
    @join = false if @join.nil?
    if @json && format_string?(@bounds)
      runtime_error('Cannot format fields when using --json')
    end
    if @regex && @join && !@replace
      runtime_error('Cannot use --regex and --join without --replace-delimiter')
    end
  end

  def parse_args(argv)
    if argv.empty?
      puts NOARGS
      exit 0
    end
    extras = []
    until argv.empty?
      arg = argv.shift
      case arg
      when '-h', '--help'
        puts HELP
        exit 0
      when '-V', '--version'
        puts VERSION
        exit 0
      when '-g', '--greedy-delimiter' then @greedy = true
      when '-p', '--compress-delimiter' then @compress = true
      when '-s', '--only-delimited' then @only_delimited = true
      when '-z', '--zero-terminated' then @zero = true
      when '-m', '--complement' then @complement = true
      when '-j', '--join' then @join = true
      when '--no-join' then @join = false
      when '--json' then @json = true
      when '--no-mmap' then nil
      when '-f', '--fields' then @mode = :fields; @bounds = need_arg(arg, argv)
      when /^--fields=(.*)$/ then @mode = :fields; @bounds = Regexp.last_match(1)
      when /^-f(.+)$/ then @mode = :fields; @bounds = Regexp.last_match(1)
      when '-b', '--bytes' then @mode = :bytes; @bounds = need_arg(arg, argv)
      when /^--bytes=(.*)$/ then @mode = :bytes; @bounds = Regexp.last_match(1)
      when /^-b(.+)$/ then @mode = :bytes; @bounds = Regexp.last_match(1)
      when '-c', '--characters' then @mode = :chars; @bounds = need_arg(arg, argv)
      when /^--characters=(.*)$/ then @mode = :chars; @bounds = Regexp.last_match(1)
      when /^-c(.+)$/ then @mode = :chars; @bounds = Regexp.last_match(1)
      when '-l', '--lines' then @mode = :lines; @bounds = need_arg(arg, argv)
      when /^--lines=(.*)$/ then @mode = :lines; @bounds = Regexp.last_match(1)
      when /^-l(.+)$/ then @mode = :lines; @bounds = Regexp.last_match(1)
      when '-d', '--delimiter' then @delimiter = need_arg(arg, argv)
      when /^--delimiter=(.*)$/ then @delimiter = Regexp.last_match(1)
      when /^-d(.+)$/ then @delimiter = Regexp.last_match(1)
      when '-e', '--regex' then @regex = Regexp.new(need_arg(arg, argv))
      when /^--regex=(.*)$/ then @regex = Regexp.new(Regexp.last_match(1))
      when /^-e(.+)$/ then @regex = Regexp.new(Regexp.last_match(1))
      when '-r', '--replace-delimiter' then @replace = need_arg(arg, argv)
      when /^--replace-delimiter=(.*)$/ then @replace = Regexp.last_match(1)
      when /^-r(.+)$/ then @replace = Regexp.last_match(1)
      when '-t', '--trim' then need_arg(arg, argv)
      when /^--trim=(.*)$/ then nil
      when /^-t(.+)$/ then nil
      when '--fallback-oob' then @fallback_oob = need_arg(arg, argv)
      when /^--fallback-oob=(.*)$/ then @fallback_oob = Regexp.last_match(1)
      when '-M', '--fixed-memory' then need_arg(arg, argv)
      when /^--fixed-memory=(.*)$/ then nil
      when /^-M(.+)$/ then nil
      else
        if arg.start_with?('-') && !File.exist?(arg)
          extras << arg
        elsif @filepath.nil?
          @filepath = arg
        else
          extras << arg
        end
      end
    end
    unless extras.empty?
      warn "tuc: unexpected arguments: #{extras.inspect}"
      warn "Try 'tuc --help' for more information."
      exit 1
    end
  rescue RegexpError => e
    warn e.message
    exit 1
  end

  def need_arg(opt, argv)
    if argv.empty?
      warn "tuc: #{opt} requires an argument"
      exit 1
    end
    argv.shift
  end

  def run
    data = @filepath ? File.binread(@filepath) : STDIN.binmode.read
    case @mode
    when :bytes
      print process_sequence(data.bytes.map(&:chr), '')
    when :chars
      print process_sequence(data.scrub.chars, '')
    when :lines
      print process_lines(data)
    else
      print process_records(data)
    end
  rescue Errno::ENOENT => e
    warn e.message
    exit 1
  end

  def record_sep = @zero ? "\0" : "\n"

  def split_records(data)
    sep = record_sep
    parts = data.split(sep, -1)
    had_final = parts.length > 1 && parts[-1] == ''
    parts.pop if had_final
    [parts, had_final]
  end

  def process_records(data)
    out = +''
    recs, had_final = split_records(data)
    recs.each_with_index do |line, idx|
      res = process_field_line(line)
      next if res.nil?
      out << res
      out << record_sep
    end
    out
  end

  def process_lines(data)
    sep = record_sep
    lines = data.split(sep, -1)
    had_final = lines.length > 1 && lines[-1] == ''
    lines.pop if had_final
    selected = select_from_array(lines, parse_selectors(@bounds), true)
    return json_array(selected) + sep if @json
    if @join
      selected.join(sep) + (selected.empty? ? '' : sep)
    else
      selected.join + (selected.empty? ? '' : sep)
    end
  end

  def process_sequence(arr, delim)
    selected = select_from_array(arr, parse_selectors(@bounds), false)
    return json_array(selected) + record_sep if @json
    selected.join(@join ? (@replace || delim) : '')
  end

  def process_field_line(line)
    pieces, delims = split_fields(line)
    return nil if @only_delimited && delims.empty?
    if format_string?(@bounds)
      return render_format(@bounds, pieces)
    end
    selectors = parse_selectors(@bounds)
    if @complement
      selectors = complement_selectors(selectors, pieces.length)
    end
    selected = []
    selectors.each do |sel|
      a = resolve_index(sel.a, pieces.length)
      b = sel.range ? resolve_index(sel.b, pieces.length) : a
      if a.nil? || b.nil? || a < 1 || b < 1 || a > pieces.length || b > pieces.length
        fb = sel.fallback || @fallback_oob
        if fb
          selected << fb
          next
        end
        warn "Error: Out of bounds: #{sel.a}"
        exit 1
      end
      if sel.range
        lo, hi = [a, b].min, [a, b].max
        if @json
          (lo..hi).each { |n| selected << pieces[n - 1] }
        else
          selected << join_range(pieces, delims, lo, hi)
        end
      else
        selected << pieces[a - 1]
      end
    end
    return json_array(selected) if @json
    if @join
      selected.join(@replace || @delimiter)
    else
      selected.join
    end
  end

  def split_fields(line)
    s = line.dup
    if @compress && !@delimiter.empty? && !@regex
      s = s.gsub(/#{Regexp.escape(@delimiter)}+/, @delimiter)
    end
    if @regex
      pieces = []
      delims = []
      pos = 0
      s.to_enum(:scan, @regex).each do
        m = Regexp.last_match
        pieces << s[pos...m.begin(0)]
        delims << m[0]
        pos = m.end(0)
      end
      pieces << s[pos..] || ''
      return [pieces, delims]
    end
    return [[s], []] if @delimiter.empty?
    pieces = []
    delims = []
    i = 0
    dlen = @delimiter.bytesize
    while (j = s.index(@delimiter, i))
      pieces << s[i...j]
      k = j + dlen
      if @greedy
        k += dlen while dlen > 0 && s[k, dlen] == @delimiter
      end
      delims << s[j...k]
      i = k
    end
    pieces << (s[i..] || '')
    [pieces, delims]
  end

  def join_range(pieces, delims, lo, hi)
    out = +''
    (lo..hi).each do |n|
      out << pieces[n - 1]
      if n < hi
        d = delims[n - 1] || @delimiter
        out << (@replace ? d.gsub(@delimiter, @replace) : d)
      end
    end
    out
  end

  def parse_selectors(spec)
    spec.split(',', -1).map do |part|
      raw, fb = part.split('=', 2)
      if raw.include?(':')
        a, b = raw.split(':', 2)
        a = '1' if a == ''
        b = '-1' if b == ''
        Selector.new(a: parse_num(a, spec), b: parse_num(b, spec), fallback: fb, range: true)
      else
        Selector.new(a: parse_num(raw, spec), b: nil, fallback: fb, range: false)
      end
    end
  end

  def parse_num(s, whole)
    Integer(s, 10)
  rescue ArgumentError
    warn "failed to parse '#{whole}': Not a number `#{s}`"
    exit 1
  end

  def resolve_index(n, len)
    n.negative? ? len + n + 1 : n
  end

  def select_from_array(arr, selectors, allow_ranges)
    sels = @complement ? complement_selectors(selectors, arr.length) : selectors
    out = []
    sels.each do |sel|
      a = resolve_index(sel.a, arr.length)
      b = sel.range ? resolve_index(sel.b, arr.length) : a
      if a.nil? || b.nil? || a < 1 || b < 1 || a > arr.length || b > arr.length
        fb = sel.fallback || @fallback_oob
        if fb
          out << fb
          next
        end
        warn "Error: Out of bounds: #{sel.a}"
        exit 1
      end
      if sel.range && allow_ranges
        range = a <= b ? (a..b) : a.downto(b)
        range.each { |i| out << arr[i - 1] }
      elsif sel.range
        range = a <= b ? (a..b) : a.downto(b)
        range.each { |i| out << arr[i - 1] }
      else
        out << arr[a - 1]
      end
    end
    out
  end

  def complement_selectors(selectors, len)
    keep = Array.new(len + 1, false)
    selectors.each do |sel|
      a = resolve_index(sel.a, len)
      b = sel.range ? resolve_index(sel.b, len) : a
      next unless a && b
      ([a, b].min..[a, b].max).each { |i| keep[i] = true if i >= 1 && i <= len }
    end
    res = []
    i = 1
    while i <= len
      if keep[i]
        i += 1
        next
      end
      start = i
      i += 1 while i <= len && !keep[i]
      stop = i - 1
      res << if start == stop
               Selector.new(a: start, b: nil, range: false)
             else
               Selector.new(a: start, b: stop, range: true)
             end
    end
    res
  end

  def format_string?(s)
    s.include?('{') || s.include?('}')
  end

  def render_format(fmt, pieces)
    out = +''
    i = 0
    while i < fmt.length
      if fmt[i] == '{'
        j = fmt.index('}', i + 1)
        unless j
          warn "failed to parse '#{fmt}': Unclosed format"
          exit 1
        end
        inside = fmt[(i + 1)...j]
        if inside.empty?
          out << '{}'
        else
          sel = parse_selectors(inside).first
          idx = resolve_index(sel.a, pieces.length)
          if idx && idx >= 1 && idx <= pieces.length
            out << pieces[idx - 1]
          else
            out << (sel.fallback || @fallback_oob || '')
          end
        end
        i = j + 1
      elsif fmt[i] == '}' && fmt[i + 1] == '}'
        out << '}'
        i += 2
      elsif fmt[i] == '{' && fmt[i + 1] == '{'
        out << '{'
        i += 2
      else
        out << fmt[i]
        i += 1
      end
    end
    out
  end

  def runtime_error(msg)
    warn "tuc: runtime error. #{msg}"
    exit 1
  end

  def json_array(values)
    '[' + values.map { |v| json_string(v) }.join(',') + ']'
  end

  def json_string(value)
    '"' + value.to_s.each_char.map do |ch|
      case ch
      when '"' then '\\"'
      when '\\' then '\\\\'
      when "\b" then '\\b'
      when "\f" then '\\f'
      when "\n" then '\\n'
      when "\r" then '\\r'
      when "\t" then '\\t'
      else
        ch.ord < 0x20 ? format('\\u%04x', ch.ord) : ch
      end
    end.join + '"'
  end
end

Tuc.new(ARGV).run
