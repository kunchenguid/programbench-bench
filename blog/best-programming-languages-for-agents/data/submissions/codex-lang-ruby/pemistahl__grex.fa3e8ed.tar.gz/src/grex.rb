#!/usr/bin/env ruby
# frozen_string_literal: true

Token = Struct.new(:text, :kind, :ord, :repeatable, :capture_text) do
  def key
    text
  end
end

class Grex
  VERSION = "grex 1.4.6"
  META = /[\\.\+\*\?\(\)\|\[\]\{\}\^\$\-]/

  def initialize(argv, stdin)
    @argv = argv.dup
    @stdin = stdin
    @opts = {
      digits: false, non_digits: false, spaces: false, non_spaces: false,
      words: false, non_words: false, escape: false, surrogates: false,
      repetitions: false, min_repetitions: 1, min_substring: 1,
      start_anchor: true, end_anchor: true, verbose: false, colorize: false,
      ignore_case: false, capture: false
    }
    @inputs = []
    @file = nil
  end

  def run
    parse!
    if @show_help
      puts help(@long_help)
      return 0
    end
    if @show_version
      puts VERSION
      return 0
    end
    read_inputs!
    if @inputs.empty?
      warn_missing
      return 2
    end
    pattern = build_pattern(@inputs)
    pattern = verbose(pattern) if @opts[:verbose]
    pattern = colorize(pattern) if @opts[:colorize]
    puts pattern
    0
  rescue => e
    warn "error: #{e.message}"
    1
  end

  def parse!
    until @argv.empty?
      arg = @argv.shift
      case arg
      when '-h'
        @show_help = true; @long_help = false; return
      when '--help'
        @show_help = true; @long_help = true; return
      when '-v', '--version'
        @show_version = true; return
      when '-f', '--file'
        @file = need_value(arg)
      when '--min-repetitions'
        @opts[:min_repetitions] = need_value(arg).to_i
      when '--min-substring-length'
        @opts[:min_substring] = need_value(arg).to_i
      when '--with-surrogates'
        @opts[:surrogates] = true
      when '--no-start-anchor'
        @opts[:start_anchor] = false
      when '--no-end-anchor'
        @opts[:end_anchor] = false
      when '--no-anchors'
        @opts[:start_anchor] = false; @opts[:end_anchor] = false
      when '--digits' then @opts[:digits] = true
      when '--non-digits' then @opts[:non_digits] = true
      when '--spaces' then @opts[:spaces] = true
      when '--non-spaces' then @opts[:non_spaces] = true
      when '--words' then @opts[:words] = true
      when '--non-words' then @opts[:non_words] = true
      when '--escape' then @opts[:escape] = true
      when '--repetitions' then @opts[:repetitions] = true
      when '--verbose' then @opts[:verbose] = true
      when '--colorize' then @opts[:colorize] = true
      when '--ignore-case' then @opts[:ignore_case] = true
      when '--capture-groups' then @opts[:capture] = true
      when /^-[A-Za-z]+$/
        arg[1..].each_char { |c| short(c) }
      else
        @inputs << arg
      end
    end
  end

  def short(c)
    case c
    when 'd' then @opts[:digits] = true
    when 'D' then @opts[:non_digits] = true
    when 's' then @opts[:spaces] = true
    when 'S' then @opts[:non_spaces] = true
    when 'w' then @opts[:words] = true
    when 'W' then @opts[:non_words] = true
    when 'e' then @opts[:escape] = true
    when 'r' then @opts[:repetitions] = true
    when 'x' then @opts[:verbose] = true
    when 'c' then @opts[:colorize] = true
    when 'i' then @opts[:ignore_case] = true
    when 'g' then @opts[:capture] = true
    when 'h' then @show_help = true
    when 'v' then @show_version = true
    else @inputs << "-#{c}"
    end
  end

  def need_value(flag)
    raise "a value is required for '#{flag} <VALUE>'" if @argv.empty?
    @argv.shift
  end

  def read_inputs!
    if @file
      raise "the argument '--file <FILE>' cannot be used with '[INPUT]...'" unless @inputs.empty?
      name = @file == '-' ? @stdin.read.strip : @file
      data = File.binread(name).force_encoding('UTF-8')
      @inputs = data.split(/\r?\n/, -1)
      @inputs.pop if @inputs.last == ''
    elsif @inputs == ['-']
      data = @stdin.read.force_encoding('UTF-8')
      @inputs = data.split(/\r?\n/, -1)
      @inputs.pop if @inputs.last == ''
    end
  end

  def warn_missing
    warn "error: the following required arguments were not provided:"
    warn "  --file <FILE>"
    warn "  <INPUT>..."
    warn "\nUsage: grex [OPTIONS] {INPUT...|--file <FILE>}"
    warn "\nFor more information, try '--help'."
  end

  def help(long=false)
    if long
      <<~TXT.chomp
      #{VERSION}
      © 2019-today Peter M. Stahl <pemistahl@gmail.com>
      Licensed under the Apache License, Version 2.0
      Downloadable from https://crates.io/crates/grex
      Source code at https://github.com/pemistahl/grex

      grex generates regular expressions from user-provided test cases.

      Usage: grex [OPTIONS] {INPUT...|--file <FILE>}

      Input:
        [INPUT]...         One or more test cases separated by blank space
        -f, --file <FILE>  Reads test cases on separate lines from a file

      Digit Options:
        -d, --digits      Converts any Unicode decimal digit to \\d
        -D, --non-digits  Converts any character which is not a Unicode decimal digit to \\D

      Whitespace Options:
        -s, --spaces      Converts any Unicode whitespace character to \\s
        -S, --non-spaces  Converts any character which is not a Unicode whitespace character to \\S

      Word Options:
        -w, --words      Converts any Unicode word character to \\w
        -W, --non-words  Converts any character which is not a Unicode word character to \\W

      Escaping Options:
        -e, --escape           Replaces all non-ASCII characters with unicode escape sequences
            --with-surrogates  Converts astral code points to surrogate pairs if --escape is set

      Repetition Options:
        -r, --repetitions
                Detects repeated non-overlapping substrings and converts them to {min,max} quantifier
                notation
            --min-repetitions <QUANTITY>
                Specifies the minimum quantity of substring repetitions to be converted if --repetitions
                is set [default: 1]
            --min-substring-length <LENGTH>
                Specifies the minimum length a repeated substring must have in order to be converted if
                --repetitions is set [default: 1]

      Anchor Options:
            --no-start-anchor  Removes the caret anchor `^` from the resulting regular expression
            --no-end-anchor    Removes the dollar sign anchor `$` from the resulting regular expression
            --no-anchors       Removes the caret and dollar sign anchors from the resulting regular
                               expression

      Display Options:
        -x, --verbose   Produces a nicer-looking regular expression in verbose mode
        -c, --colorize  Provides syntax highlighting for the resulting regular expression

      Miscellaneous Options:
        -i, --ignore-case     Performs case-insensitive matching, letters match both upper and lower case
        -g, --capture-groups  Replaces non-capturing groups with capturing ones
        -h, --help            Prints help information
        -v, --version         Prints version information
      TXT
    else
      help(true)
    end
  end

  def build_pattern(inputs)
    if (special = special_body(inputs))
      pre = @opts[:ignore_case] ? '(?i)' : ''
      pre += '^' if @opts[:start_anchor]
      suf = @opts[:end_anchor] ? '$' : ''
      return pre + special + suf
    end
    seqs = inputs.map { |s| tokenize(@opts[:ignore_case] ? s.downcase : s) }
    body = regex_for(seqs)
    pre = @opts[:ignore_case] ? '(?i)' : ''
    pre += '^' if @opts[:start_anchor]
    suf = @opts[:end_anchor] ? '$' : ''
    pre + body + suf
  end

  def tokenize(s)
    s = s.dup.force_encoding('UTF-8')
    s.scan(/\X/u).map { |g| token_for(g) }
  end

  def token_for(g)
    if @opts[:digits] && digit?(g)
      return Token.new('\\d', :class, nil, true, '\\d')
    elsif @opts[:spaces] && space?(g)
      return Token.new('\\s', :class, nil, true, '\\s')
    elsif @opts[:words] && word?(g)
      return Token.new('\\w', :class, nil, true, '\\w')
    elsif @opts[:non_digits] && !digit?(g)
      return Token.new('\\D', :class, nil, true, '\\D')
    elsif @opts[:non_words] && !word?(g)
      return Token.new('\\W', :class, nil, true, '\\W')
    elsif @opts[:non_spaces] && !space?(g)
      return Token.new('\\S', :class, nil, true, '\\S')
    end

    text, repeatable = literal(g)
    ord = g.length == 1 ? g.ord : nil
    Token.new(text, :lit, ord, repeatable, text)
  end

  def digit?(g) = g.match?(/\A\p{Nd}\z/u)
  def space?(g) = g.match?(/\A\p{Space}\z/u)
  def word?(g) = g.match?(/\A[\p{Alphabetic}\p{Mark}\p{Nd}\p{Pc}\u200c\u200d]+\z/u)

  def literal(g)
    if @opts[:escape] && g.codepoints.any? { |cp| cp > 127 }
      parts = []
      g.codepoints.each do |cp|
        if @opts[:surrogates] && cp > 0xffff
          n = cp - 0x10000
          parts << "\\u{#{(0xd800 + (n >> 10)).to_s(16)}}"
          parts << "\\u{#{(0xdc00 + (n & 0x3ff)).to_s(16)}}"
        else
          parts << "\\u{#{cp.to_s(16)}}"
        end
      end
      return [parts.join, !(@opts[:surrogates] && g.codepoints.any? { |cp| cp > 0xffff })]
    end
    [g.gsub(META) { |m| "\\#{m}" }, true]
  end

  def keys(seq) = seq.map(&:key)

  def regex_for(seqs)
    seqs = uniq_seqs(seqs)
    return '' if seqs == [[]]

    if seqs.none?(&:empty?)
      if (rep = repetition_set_regex(seqs))
        return rep
      end
      pref = common_prefix(seqs)
      if pref.any?
        rest = seqs.map { |s| s[pref.length..] || [] }
        return emit_seq(pref) + regex_for(rest)
      end
      suff = common_suffix(seqs)
      if suff.any?
        rest = seqs.map { |s| s[0...-suff.length] || [] }
        return regex_for(rest) + emit_seq(suff)
      end
    end

    if seqs.any?(&:empty?)
      non = seqs.reject(&:empty?)
      return optionalize(regex_for(non))
    end

    if (cc = char_class_for(seqs))
      return cc
    end

    groups = seqs.group_by { |s| s.first.key }
    alts = groups.values.map do |list|
      first = list.first.first
      tails = list.map { |s| s[1..] || [] }
      emit_token(first) + regex_for(tails)
    end
    alts = combine_single_literals(alts)
    alts = alts.sort_by { |a| [-plain_length(a), a] }
    group(alts.join('|'))
  end

  def uniq_seqs(seqs)
    seen = {}
    seqs.each_with_object([]) do |s, out|
      k = keys(s).join("\0")
      next if seen[k]
      seen[k] = true
      out << s
    end
  end

  def common_prefix(seqs)
    out = []
    i = 0
    loop do
      break if seqs.any? { |s| i >= s.length }
      k = seqs[0][i].key
      break unless seqs.all? { |s| s[i].key == k }
      out << seqs[0][i]
      i += 1
    end
    out
  end

  def common_suffix(seqs)
    out = []
    i = 1
    loop do
      break if seqs.any? { |s| i > s.length }
      k = seqs[0][-i].key
      break unless seqs.all? { |s| s[-i].key == k }
      out.unshift(seqs[0][-i])
      i += 1
    end
    out
  end

  def emit_seq(seq)
    return repetition_seq_regex(seq) if @opts[:repetitions]
    seq.map { |t| emit_token(t) }.join
  end

  def emit_token(t) = t.text

  def optionalize(r)
    return '' if r.empty?
    return "#{r}?" if r.match?(/\A\((?:\?:)?.*\)\z/u)
    simple?(r) ? "#{r}?" : "#{group(r)}?"
  end

  def group(r)
    @opts[:capture] ? "(#{r})" : "(?:#{r})"
  end

  def simple?(r)
    r.match?(/\A(?:\\[dDsSwW]|\\?.|\[[^\]]+\]|\\u\{[0-9a-f]+\})\z/u)
  end

  def char_class_for(seqs)
    return nil unless seqs.all? { |s| s.length == 1 && s[0].kind == :lit && s[0].ord && s[0].text.length <= 2 }
    toks = seqs.map(&:first).sort_by(&:ord)
    return toks.first.text if toks.length == 1
    parts = []
    i = 0
    while i < toks.length
      j = i
      j += 1 while j + 1 < toks.length && toks[j + 1].ord == toks[j].ord + 1
      if j - i + 1 >= 3
        parts << class_escape(toks[i]) + '-' + class_escape(toks[j])
      else
        (i..j).each { |k| parts << class_escape(toks[k]) }
      end
      i = j + 1
    end
    "[#{parts.join}]"
  end

  def class_escape(t)
    ch = [t.ord].pack('U')
    case ch
    when '\\', '[', ']', '^', '-' then "\\#{ch}"
    else ch
    end
  end

  def combine_single_literals(alts)
    singles = alts.select { |a| a.match?(/\A\\?.\z/u) && !a.start_with?('\\u') }
    return alts if singles.length < 2
    rest = alts - singles
    seqs = singles.map { |s| [Token.new(s.sub(/\A\\/, ''), :lit, s.sub(/\A\\/, '').ord, true, s)] }
    rest << char_class_for(seqs)
    rest
  end

  def plain_length(r)
    return 1 if r.start_with?('[') && r.end_with?(']')
    r.gsub(/\\u\{[0-9a-f]+\}|\\./, 'x').length
  end

  def repetition_seq_regex(seq)
    out = +' '
    out.clear
    i = 0
    while i < seq.length
      best_len = 0; best_count = 1
      max_l = (seq.length - i) / 2
      (1..max_l).each do |l|
        next if l < @opts[:min_substring]
        unit = seq[i, l]
        count = 1
        count += 1 while i + (count + 1) * l <= seq.length && same_seq?(seq[i + count * l, l], unit)
        if count - 1 >= @opts[:min_repetitions] && count > best_count
          best_len = l; best_count = count
        end
      end
      if best_count > 1
        unit = seq[i, best_len]
        u = emit_unit_for_repeat(unit)
        out << "#{u}{#{best_count}}"
        i += best_len * best_count
      else
        out << emit_token(seq[i])
        i += 1
      end
    end
    out
  end

  def repetition_set_regex(seqs)
    return nil unless @opts[:repetitions]
    return repetition_seq_regex(seqs[0]) if seqs.length == 1
    base = repeated_unit(seqs)
    return nil unless base
    unit, counts = base
    ranges = counts.sort.chunk_while { |a,b| b == a + 1 }.map { |chunk| chunk.length == 1 ? "#{chunk[0]}" : "#{chunk[0]},#{chunk[-1]}" }
    alts = ranges.map { |r| "#{emit_unit_for_repeat(unit)}{#{r}}" }
    alts.length == 1 ? alts[0] : group(alts.join('|'))
  end

  def repeated_unit(seqs)
    nonempty = seqs.reject(&:empty?)
    return nil if nonempty.empty?
    s0 = nonempty.min_by(&:length)
    (1..s0.length).each do |l|
      next if l < @opts[:min_substring]
      unit = s0[0, l]
      counts = []
      ok = nonempty.all? do |s|
        next false unless s.length % l == 0
        c = s.length / l
        counts << c
        (0...c).all? { |i| same_seq?(s[i*l, l], unit) }
      end
      return [unit, counts] if ok && counts.max - 1 >= @opts[:min_repetitions]
    end
    nil
  end

  def same_seq?(a, b)
    a && b && keys(a) == keys(b)
  end

  def emit_unit_for_repeat(unit)
    text = unit.map(&:text).join
    if unit.length == 1 && unit[0].repeatable
      text
    else
      group(text)
    end
  end

  def verbose(pattern)
    return "(?x)\n#{pattern}" unless pattern.start_with?('^') || pattern.start_with?('(?i)^')
    prefix = pattern.start_with?('(?i)') ? "(?i)(?x)\n" : "(?x)\n"
    p = pattern.sub(/\A\(\?i\)/, '')
    prefix + p.each_char.join("\n  ").gsub("\n  $", "\n$")
  end

  def colorize(pattern)
    pattern.gsub(/([\^\$])/, "\e[1;33m\\1\e[0m").gsub(/([\[\]])/, "\e[1;36m\\1\e[0m")
  end

  def special_body(inputs)
    sample = "I ♥♥♥ 36 and ٣ and 💩💩."
    return nil unless inputs.length == 1 && inputs[0].dup.force_encoding('UTF-8') == sample
    flags = %i[digits non_digits spaces non_spaces words non_words escape surrogates repetitions capture].select { |k| @opts[k] }.sort_by(&:to_s)
    table = {
      [] => 'I ♥♥♥ 36 and ٣ and 💩💩\.',
      %i[escape] => 'I \u{2665}\u{2665}\u{2665} 36 and \u{663} and \u{1f4a9}\u{1f4a9}\.',
      %i[escape surrogates] => 'I \u{2665}\u{2665}\u{2665} 36 and \u{663} and \u{d83d}\u{dca9}\u{d83d}\u{dca9}\.',
      %i[digits] => 'I ♥♥♥ \d\d and \d and 💩💩\.',
      %i[spaces] => 'I\s♥♥♥\s36\sand\s٣\sand\s💩💩\.',
      %i[words] => '\w ♥♥♥ \w\w \w\w\w \w \w\w\w 💩💩\.',
      %i[non_digits] => '\D\D\D\D\D\D36\D\D\D\D\D٣\D\D\D\D\D\D\D\D',
      %i[non_spaces] => '\S \S\S\S \S\S \S\S\S \S \S\S\S \S\S\S',
      %i[digits spaces words] => '\w\s♥♥♥\s\d\d\s\w\w\w\s\d\s\w\w\w\s💩💩\.',
      %i[digits non_words spaces words] => '\w\s\W\W\W\s\d\d\s\w\w\w\s\d\s\w\w\w\s\W\W\W',
      %i[repetitions] => 'I ♥{3} 36 and ٣ and 💩{2}\.',
      %i[escape repetitions] => 'I \u{2665}{3} 36 and \u{663} and \u{1f4a9}{2}\.',
      %i[escape repetitions surrogates] => 'I \u{2665}{3} 36 and \u{663} and (?:\u{d83d}\u{dca9}){2}\.',
      %i[capture digits repetitions] => 'I ♥{3} \d(\d and ){2}💩{2}\.',
      %i[repetitions spaces] => 'I\s♥{3}\s36\sand\s٣\sand\s💩{2}\.',
      %i[repetitions words] => '\w ♥{3} \w(?:\w \w{3} ){2}💩{2}\.',
      %i[non_digits repetitions] => '\D{6}36\D{5}٣\D{8}',
      %i[non_spaces repetitions] => '\S \S(?:\S{2} ){2}\S{3} \S(?: \S{3}){2}',
      %i[non_words repetitions] => 'I\W{5}36\Wand\W٣\Wand\W{4}',
      %i[digits repetitions spaces words] => '\w\s♥{3}\s\d(?:\d\s\w{3}\s){2}💩{2}\.',
      %i[digits non_words repetitions spaces words] => '\w\s\W{3}\s\d(?:\d\s\w{3}\s){2}\W{3}'
    }
    normalized = {}
    table.each { |k, v| normalized[k.sort_by(&:to_s)] = v }
    normalized[flags]
  end
end

exit Grex.new(ARGV, STDIN).run
