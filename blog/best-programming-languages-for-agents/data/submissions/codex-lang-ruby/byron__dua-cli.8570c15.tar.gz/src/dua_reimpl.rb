#!/usr/bin/env ruby
# frozen_string_literal: true
require 'set'
STDOUT.sync = true
GREEN="\e[32m"; CYAN="\e[36m"; RESET="\e[39m"; VERSION='dua 2.32.2'
FORMATS=%w[metric binary bytes gb gib mb mib]; DEFAULT_IGNORES=%w[/proc /dev /sys /run]
class Options
  attr_accessor :format,:apparent,:count_links,:stay_fs,:ignore_dirs,:stats,:no_sort,:no_total
  def initialize; @format='binary'; @apparent=false; @count_links=false; @stay_fs=false; @ignore_dirs=DEFAULT_IGNORES.dup; @stats=false; @no_sort=false; @no_total=false; end
end
HELP=<<~TXT
A tool to learn about disk usage, fast!

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

Commands:
  interactive  Launch the terminal user interface [aliases: i]
  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [INPUT]...
          One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -t, --threads <THREADS>
          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread
          
          [default: 0]

  -f, --format <FORMAT>
          The format with which to print byte counts
          
          [default: binary]
          [possible values: metric, binary, bytes, gb, gib, mb, mib]

  -A, --apparent-size
          Display apparent size instead of disk usage

  -l, --count-hard-links
          Count hard-linked files each time they are seen

  -x, --stay-on-filesystem
          If set, we will not cross filesystems or traverse mount points

  -i, --ignore-dirs <IGNORE_DIRS>
          One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path.
          
          Hence, they will only be ignored if they are eventually reached as part of the traversal.
          
          [default: /proc /dev /sys /run]

      --log-file <LOG_FILE>
          Write a log file with debug information, including panics

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
TXT
AGG_HELP=<<~TXT
Aggregate the consumed space of one or more directories or files

Usage: executable aggregate [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
      --stats     If set, print additional statistics about the file traversal to stderr
      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending
      --no-total  If set, no total column will be computed for multiple inputs
  -h, --help      Print help
TXT
INT_HELP=<<~TXT
Launch the terminal user interface

Usage: executable interactive [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -e, --no-entry-check  Do not check entries for presence when listing a directory to avoid slugging performance on slow filesystems
  -h, --help            Print help
TXT
COMP_HELP=<<~TXT
Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate a completions-script for [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help  Print help
TXT
Row=Struct.new(:size,:display,:dir,:errors,keyword_init:true); Stats=Struct.new(:files,:dirs,:errors,keyword_init:true)
def invalid_format(v); warn "error: invalid value '#{v}' for '--format <FORMAT>'"; warn '  [possible values: metric, binary, bytes, gb, gib, mb, mib]'; warn ''; warn "For more information, try '--help'."; exit 2; end
def need(flag); warn "error: a value is required for '#{flag}' but none was supplied"; warn ''; warn "For more information, try '--help'."; exit 2; end
def parse_global(argv,o)
  i=0
  while i<argv.length
    a=argv[i]
    case a
    when '-h','--help'; puts HELP; exit 0
    when '-V','--version'; puts VERSION; exit 0
    when '-A','--apparent-size'; o.apparent=true
    when '-l','--count-hard-links'; o.count_links=true
    when '-x','--stay-on-filesystem'; o.stay_fs=true
    when '-f','--format'; i+=1; need(a) if i>=argv.length; o.format=argv[i]; invalid_format(o.format) unless FORMATS.include?(o.format)
    when /^--format=(.*)$/; o.format=$1; invalid_format(o.format) unless FORMATS.include?(o.format)
    when '-i','--ignore-dirs'; i+=1; need(a) if i>=argv.length; o.ignore_dirs=[argv[i]]
    when /^--ignore-dirs=(.*)$/; o.ignore_dirs=[$1]
    when '-t','--threads','--log-file'; i+=1; need(a) if i>=argv.length
    when /^--threads=/,/^--log-file=/; nil
    when 'aggregate','a','interactive','i','completions','help'; return argv[i..]
    else return argv[i..]
    end
    i+=1
  end
  []
end
def parse_agg(argv,o)
  out=[]; i=0
  while i<argv.length
    case argv[i]
    when '-h','--help'; puts AGG_HELP; exit 0
    when '--stats'; o.stats=true
    when '--no-sort'; o.no_sort=true
    when '--no-total'; o.no_total=true
    else out=argv[i..]; break
    end; i+=1
  end; out
end
def parse_int(argv)
  i=0; while i<argv.length; case argv[i]; when '-h','--help'; puts INT_HELP; exit 0; when '-e','--no-entry-check'; else return argv[i..]; end; i+=1; end; []
end
def bytes_for(st,o); o.apparent ? st.size : ((st.respond_to?(:blocks)&&st.blocks) ? st.blocks*512 : ((st.size+511)/512)*512); end
def ignored?(p,o); a=File.expand_path(p); o.ignore_dirs.any?{|d| a==d || a.start_with?(d+'/')}; end
def measure(p,o,seen,rootdev=nil,root=true)
  s=Stats.new(files:0,dirs:0,errors:0)
  begin st=File.lstat(p); rescue StandardError; s.errors=1; return [0,s,true]; end
  return [0,s,false] if !root && ignored?(p,o)
  isdir=st.directory?; size=bytes_for(st,o)
  if !o.count_links && !isdir && st.nlink && st.nlink>1
    k=[st.dev,st.ino]; seen.include?(k) ? size=0 : seen.add(k)
  end
  if isdir
    s.dirs+=1; dev=rootdev||st.dev
    begin ents=Dir.children(p); rescue StandardError; s.errors+=1; return [size,s,true]; end
    ents.each do |e|
      c=File.join(p,e)
      begin cst=File.lstat(c); rescue StandardError; s.errors+=1; next; end
      next if o.stay_fs && cst.directory? && cst.dev!=dev
      cs,stt,_=measure(c,o,seen,dev,false); size+=cs; s.files+=stt.files; s.dirs+=stt.dirs; s.errors+=stt.errors
    end
  else; s.files+=1; end
  [size,s,isdir]
end
def default_inputs; Dir.children('.').reject{|p| File.symlink?(p)}; rescue StandardError; []; end
def fmt(n,f)
  return format('%10d b',n) if f=='bytes'; return format('%6.2f GB',n/1_000_000_000.0) if f=='gb'; return format('%6.2f GiB',n/(1024.0**3)) if f=='gib'; return format('%6.2f MB',n/1_000_000.0) if f=='mb'; return format('%6.2f MiB',n/(1024.0**2)) if f=='mib'
  units = f=='metric' ? [' B','KB','MB','GB','TB'] : ['  B','KiB','MiB','GiB','TiB']; div=f=='metric' ? 1000.0 : 1024.0; v=n.to_f; i=0; while v>=div && i<units.length-1; v/=div; i+=1; end; i==0 ? format('%7d %s',n,units[i]) : format('%7.2f %s',v,units[i])
end
def prow(r,o); name=r.dir ? "#{CYAN}#{r.display}#{RESET}" : r.display; suf=r.errors>0 ? "  <#{r.errors} IO Error#{r.errors==1 ? '' : 's'}>" : ''; puts "#{GREEN}#{fmt(r.size,o.format)}#{RESET} #{name}#{suf}"; end
def aggregate(inputs,o)
  inputs=default_inputs if inputs.empty?; seen=Set.new; rows=[]; all=Stats.new(files:0,dirs:0,errors:0)
  if inputs.length==1
    begin st=File.lstat(inputs[0]); rescue StandardError; st=nil; end
    if st&.directory?
      begin list=Dir.children(inputs[0]).map{|e| File.join(inputs[0],e)}; rescue StandardError; list=[inputs[0]]; end
      list.each{|p| sz,s,d=measure(p,o,seen); all.files+=s.files; all.dirs+=s.dirs; all.errors+=s.errors; rows << Row.new(size:sz,display:(list.length==1&&p==inputs[0] ? p : File.basename(p)),dir:d,errors:s.errors)}
    else
      sz,s,d=measure(inputs[0],o,seen); all=s; rows << Row.new(size:sz,display:inputs[0],dir:d,errors:s.errors)
    end
  else
    inputs.each{|p| sz,s,d=measure(p,o,seen); all.files+=s.files; all.dirs+=s.dirs; all.errors+=s.errors; rows << Row.new(size:sz,display:p,dir:d,errors:s.errors)}
  end
  rows.sort_by! { |r| [r.size, r.display] } unless o.no_sort; rows.each{|r| prow(r,o)}
  prow(Row.new(size:rows.sum(&:size),display:'total',dir:false,errors:0),o) if rows.length>1 && !o.no_total
  warn "Statistics { entries_traversed: #{all.files+all.dirs}, smallest_file_in_bytes: #{rows.map(&:size).min||0}, largest_file_in_bytes: #{rows.map(&:size).max||0} }" if o.stats
  all.errors>0 ? 1 : 0
end
def completions(sh)
  if sh.nil? || sh=='-h' || sh=='--help'; puts COMP_HELP; exit(sh.nil? ? 2 : 0); end
  unless %w[bash elvish fish powershell zsh].include?(sh); warn "error: invalid value '#{sh}' for '<SHELL>'"; exit 2; end
  words='dua aggregate interactive completions help --help --version --format --apparent-size --count-hard-links --stay-on-filesystem'
  puts(sh=='fish' ? "complete -c dua -f -a '#{words}'" : "# dua completions for #{sh}\ncomplete -W \"#{words}\" dua")
end
o=Options.new; rest=parse_global(ARGV.dup,o); cmd=rest.shift
case cmd
when nil then exit aggregate([],o)
when 'help'; sub=rest.shift; puts(sub=~/^a/ ? AGG_HELP : sub=~/^i/ ? INT_HELP : sub=='completions' ? COMP_HELP : HELP)
when 'aggregate','a'; exit aggregate(parse_agg(rest,o),o)
when 'interactive','i'; exit aggregate(parse_int(rest),o)
when 'completions'; completions(rest[0])
else exit aggregate([cmd]+rest,o)
end
