#!/usr/bin/env ruby

require 'cgi'
require 'uri'
require 'nokogiri'

HELP = <<~HELP
  htmlq 0.4.0
  Michael Maclean <michael@mgdm.net>
  Runs CSS selectors on HTML

  USAGE:
      executable [FLAGS] [OPTIONS] [--] [selector]...

  FLAGS:
      -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to
                                 the value of --base, if supplied
      -h, --help                 Prints help information
      -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace
      -p, --pretty               Pretty-print the serialised output
      -t, --text                 Output only the contents of text nodes inside selected elements
      -V, --version              Prints version information

  OPTIONS:
      -a, --attribute <attribute>         Only return this attribute (if present) from selected elements
      -b, --base <base>                   Use this URL as the base for links
      -f, --filename <FILE>               The input file. Defaults to stdin
      -o, --output <FILE>                 The output file. Defaults to stdout
      -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple
                                          times

  ARGS:
      <selector>...    The CSS expression to select [default: html]
HELP

VERSION = "htmlq 0.4.0\n"

VOID_ELEMENTS = %w[area base br col embed hr img input link meta param source track wbr].freeze
RAW_TEXT = %w[script style].freeze
BOOLEAN_ATTRS = %w[
  allowfullscreen async autofocus autoplay checked compact controls declare default
  defaultchecked defaultmuted defaultselected defer disabled enabled formnovalidate
  hidden indeterminate inert ismap itemscope loop multiple muted nohref nomodule
  noresize noshade novalidate nowrap open pauseonexit readonly required reversed
  scoped seamless selected sortable truespeed typemustmatch visible
].freeze

class CliError < StandardError; end

def parse_args(argv)
  opts = {
    text: false,
    pretty: false,
    ignore_ws: false,
    detect_base: false,
    attribute: nil,
    base: nil,
    filename: nil,
    output: nil,
    remove: [],
    selectors: []
  }

  i = 0
  positional = false
  while i < argv.length
    arg = argv[i]
    if positional
      opts[:selectors] << arg
    elsif arg == '--'
      positional = true
    elsif arg == '--help'
      print HELP
      exit 0
    elsif arg == '--version'
      print VERSION
      exit 0
    elsif arg.start_with?('--')
      case arg
      when '--text' then opts[:text] = true
      when '--pretty' then opts[:pretty] = true
      when '--ignore-whitespace' then opts[:ignore_ws] = true
      when '--detect-base' then opts[:detect_base] = true
      when '--attribute', '--base', '--filename', '--output', '--remove-nodes'
        i += 1
        raise CliError, "The argument '#{arg}' requires a value but none was supplied" if i >= argv.length
        val = argv[i]
        case arg
        when '--attribute' then opts[:attribute] = val
        when '--base' then opts[:base] = val
        when '--filename' then opts[:filename] = val
        when '--output' then opts[:output] = val
        when '--remove-nodes' then opts[:remove] << val
        end
      else
        raise CliError, "Found argument '#{arg}' which wasn't expected, or isn't valid in this context"
      end
    elsif arg.start_with?('-') && arg != '-'
      chars = arg[1..].chars
      until chars.empty?
        ch = chars.shift
        case ch
        when 'h'
          print HELP
          exit 0
        when 'V'
          print VERSION
          exit 0
        when 't' then opts[:text] = true
        when 'p' then opts[:pretty] = true
        when 'w' then opts[:ignore_ws] = true
        when 'B' then opts[:detect_base] = true
        when 'a', 'b', 'f', 'o', 'r'
          val = chars.empty? ? argv[i += 1] : chars.join
          raise CliError, "The argument '-#{ch}' requires a value but none was supplied" if val.nil?
          chars = []
          case ch
          when 'a' then opts[:attribute] = val
          when 'b' then opts[:base] = val
          when 'f' then opts[:filename] = val
          when 'o' then opts[:output] = val
          when 'r' then opts[:remove] << val
          end
        else
          raise CliError, "Found argument '-#{ch}' which wasn't expected, or isn't valid in this context"
        end
      end
    else
      opts[:selectors] << arg
    end
    i += 1
  end

  opts
end

def escape_text(text)
  text.gsub('&', '&amp;').gsub('<', '&lt;')
end

def escape_attr(value)
  value.gsub('&', '&amp;').gsub('"', '&quot;')
end

def attr_value(attr)
  if BOOLEAN_ATTRS.include?(attr.name.downcase) && attr.value.downcase == attr.name.downcase
    ''
  else
    attr.value
  end
end

def resolve_url(base, value)
  return value if base.nil? || base.empty? || value.nil? || value.empty?
  URI.join(base, value).to_s
rescue URI::Error
  value
end

def apply_base!(doc, base)
  return unless base && !base.empty?
  doc.css('[href]').each do |node|
    node['href'] = resolve_url(base, node['href'])
  end
end

def normalize_document!(doc)
  html = doc.at_css('html')
  return unless html

  body = html.at_xpath('./body')
  unless body
    body = Nokogiri::XML::Node.new('body', doc)
    html.add_child(body)
  end

  return if html.at_xpath('./head')

  head = Nokogiri::XML::Node.new('head', doc)
  if body.parent == html
    body.add_previous_sibling(head)
  else
    html.prepend_child(head)
  end
end

def serialize(node)
  case node
  when Nokogiri::XML::Text
    escape_text(node.text)
  when Nokogiri::XML::CDATA
    node.text
  when Nokogiri::XML::Comment
    "<!--#{node.content}-->"
  when Nokogiri::XML::Document, Nokogiri::HTML4::Document
    node.children.map { |child| serialize(child) }.join
  when Nokogiri::XML::Element
    name = node.name.downcase
    attrs = node.attribute_nodes.sort_by { |a| a.name }
    attr_s = attrs.map { |a| %(#{a.name}="#{escape_attr(attr_value(a))}") }.join(' ')
    open = attr_s.empty? ? "<#{name}>" : "<#{name} #{attr_s}>"
    return open if VOID_ELEMENTS.include?(name)

    body = if RAW_TEXT.include?(name)
             node.children.map(&:to_s).join
           else
             node.children.map { |child| serialize(child) }.join
           end
    "#{open}#{body}</#{name}>"
  else
    ''
  end
end

def pretty_lines(node, depth = 0)
  return [] if node.comment?
  return [("#{'  ' * depth}#{node.text}")] if node.text? && !node.text.empty?
  return [("#{'  ' * depth}#{serialize(node)}")] unless node.element? || node.document?

  if node.document?
    return node.children.flat_map { |child| pretty_lines(child, depth) }
  end

  children = node.children.reject { |child| child.text? && child.text.empty? }
  text_only = children.all?(&:text?)
  return [("#{'  ' * depth}#{serialize(node)}")] if text_only && !children.empty?

  name = node.name.downcase
  attrs = node.attribute_nodes.sort_by { |a| a.name }
  attr_s = attrs.map { |a| %(#{a.name}="#{escape_attr(attr_value(a))}") }.join(' ')
  open = attr_s.empty? ? "<#{name}>" : "<#{name} #{attr_s}>"
  return [("#{'  ' * depth}#{open}")] if VOID_ELEMENTS.include?(name)

  lines = [("#{'  ' * depth}#{open}")]
  children.each { |child| lines.concat(pretty_lines(child, depth + 1)) }
  lines << "#{'  ' * depth}</#{name}>"
  lines
end

def pretty(node)
  "\n#{pretty_lines(node).join("\n")}"
end

begin
  opts = parse_args(ARGV)
rescue CliError => e
  warn "error: #{e.message}"
  warn
  warn "USAGE:"
  warn "    executable [FLAGS] [OPTIONS] [--] [selector]..."
  warn
  warn "For more information try --help"
  exit 1
end

input = if opts[:filename]
          File.read(opts[:filename])
        else
          STDIN.read
        end

doc = Nokogiri::HTML(input)
normalize_document!(doc)
base = if opts[:detect_base]
         base_node = doc.at_css('base[href]')
         base_node ? base_node['href'] : opts[:base]
       else
         opts[:base]
       end
apply_base!(doc, base)

opts[:remove].each do |selector|
  doc.css(selector).remove
end

selector = opts[:selectors].empty? ? 'html' : opts[:selectors].join(' ')
nodes = doc.css(selector)

output = +''
if opts[:text]
  nodes.each do |node|
    node.traverse do |child|
      next unless child.text?
      text = child.text
      next if opts[:ignore_ws] && text.strip.empty?
      output << text
    end
  end
  output << "\n"
elsif opts[:attribute]
  nodes.each do |node|
    next unless node.element?
    value = node[opts[:attribute]]
    next if value.nil?
    value = resolve_url(base, value) if opts[:attribute] == 'href'
    output << value << "\n"
  end
else
  nodes.each do |node|
    output << (opts[:pretty] ? pretty(node) : serialize(node)) << "\n"
  end
end

if opts[:output]
  File.write(opts[:output], output)
else
  print output
end
