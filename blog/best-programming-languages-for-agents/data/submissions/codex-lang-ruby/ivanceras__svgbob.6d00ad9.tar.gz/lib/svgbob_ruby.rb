# frozen_string_literal: true

module SvgbobRuby
  VERSION = "svgbob 0.7.6"

  class CLI
    def initialize(argv)
      @argv = argv.dup
      @opts = {
        background: "white",
        fill_color: "black",
        stroke_color: "black",
        font_family: nil,
        font_size: "14",
        stroke_width: "2",
        scale: 1.0,
        output: nil,
        inline: false
      }
    end

    def run
      if @argv.first == "build"
        @argv.shift
        return run_build
      end

      return puts_help if @argv.include?("-h") || @argv.include?("--help")
      return puts VERSION if @argv.include?("-V") || @argv.include?("--version")

      input = parse_options
      text = if @opts[:inline]
               input.to_s.gsub("\\n", "\n")
             elsif input
               File.read(input)
             else
               STDIN.read
             end

      svg = Renderer.new(text, @opts).render
      if @opts[:output] && @opts[:output] != "STDOUT"
        File.write(@opts[:output], svg)
      else
        print svg
      end
    rescue Errno::ENOENT => e
      warn e.message
      exit 1
    end

    def puts_help
      puts <<~HELP.chomp
        svgbob 0.7.6
        SvgBobRus is an ascii to svg converter

        USAGE:
            executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]

        FLAGS:
            -h, --help       Prints help information
            -s               parse an inline string
            -V, --version    Prints version information

        OPTIONS:
                --background <background>        backdrop background will be filled with this color (default: 'white')
                --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')
                --font-family <font-family>      text will be rendered with this font (default: 'arial')
                --font-size <font-size>          text will be rendered with this font size (default: 14)
            -o, --output <output>                where to write svg output [default: STDOUT]
                --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor
                                                 (default: 1)
                --stroke-color <stroke-color>    stroke color for all lines (default: 'black')
                --stroke-width <stroke-width>    stroke width for all lines (default: 2)

        ARGS:
            <input>    svgbob text file or inline string to parse [default: STDIN]

        SUBCOMMANDS:
            build    Batch convert files to svg.
            help     Prints this message or the help of the given subcommand(s)
      HELP
    end

    def build_help
      puts <<~HELP.chomp
        executable-build 0.0.1
        Batch convert files to svg.

        USAGE:
            executable build [OPTIONS]

        FLAGS:
            -h, --help       Prints help information
            -V, --version    Prints version information

        OPTIONS:
            -i, --input <input>      set input file pattern like: *.bob or dir/*.bob
            -o, --outdir <outdir>    set dir of svg files
      HELP
    end

    def run_build
      return build_help if @argv.include?("-h") || @argv.include?("--help")
      return puts "executable-build 0.0.1" if @argv.include?("-V") || @argv.include?("--version")

      pattern = nil
      outdir = "."
      until @argv.empty?
        arg = @argv.shift
        case arg
        when "-i", "--input"
          pattern = @argv.shift
        when "-o", "--outdir"
          outdir = @argv.shift
        end
      end
      pattern ||= "*.bob"
      Dir.mkdir(outdir) unless Dir.exist?(outdir)
      Dir.glob(pattern).sort.each do |path|
        next unless File.file?(path)
        svg = Renderer.new(File.read(path), @opts).render
        base = File.basename(path, File.extname(path)) + ".svg"
        File.write(File.join(outdir, base), svg)
      end
    end

    def parse_options
      input = nil
      until @argv.empty?
        arg = @argv.shift
        case arg
        when "-s"
          @opts[:inline] = true
        when "-o", "--output"
          @opts[:output] = @argv.shift
        when "--background"
          @opts[:background] = @argv.shift
        when "--fill-color"
          @opts[:fill_color] = @argv.shift
        when "--stroke-color"
          @opts[:stroke_color] = @argv.shift
        when "--font-family"
          @opts[:font_family] = @argv.shift
        when "--font-size"
          @opts[:font_size] = @argv.shift
        when "--stroke-width"
          @opts[:stroke_width] = @argv.shift
        when "--scale"
          @opts[:scale] = @argv.shift.to_f
        when "help"
          puts_help
          exit 0
        else
          input ||= arg
        end
      end
      input
    end
  end

  class Renderer
    CELL_W = 8
    CELL_H = 16

    def initialize(text, opts)
      @lines = text.to_s.lines.map { |l| l.chomp("\n").chomp("\r") }
      @lines = [""] if @lines.empty?
      @opts = opts
      @used = {}
      @items = []
      @height = @lines.length
      @width = @lines.map(&:length).max || 0
    end

    def render
      detect_rectangles
      detect_horizontal
      detect_vertical
      detect_diagonal
      detect_text
      svg
    end

    private

    def char(x, y)
      return " " if y.negative? || y >= @lines.length || x.negative?
      @lines[y][x] || " "
    end

    def mark(x, y)
      @used[[x, y]] = true
    end

    def used?(x, y)
      @used[[x, y]]
    end

    def graphic_char?(ch)
      "-=|+/\\<>".include?(ch)
    end

    def detect_rectangles
      @lines.each_with_index do |line, y1|
        (0...line.length).each do |x1|
          next unless char(x1, y1) == "+"
          ((x1 + 2)...line.length).each do |x2|
            next unless char(x2, y1) == "+"
            next unless ((x1 + 1)...x2).all? { |x| ["-", "="].include?(char(x, y1)) }
            ((y1 + 1)...@lines.length).each do |y2|
              next unless char(x1, y2) == "+" && char(x2, y2) == "+"
              next unless ((x1 + 1)...x2).all? { |x| ["-", "="].include?(char(x, y2)) }
              next unless ((y1 + 1)...y2).all? { |y| char(x1, y) == "|" && char(x2, y) == "|" }
              (x1..x2).each { |x| mark(x, y1); mark(x, y2) }
              (y1..y2).each { |y| mark(x1, y); mark(x2, y) }
              @items << [:rect, x1 * 8 + 4, y1 * 16 + 8, (x2 - x1) * 8, (y2 - y1) * 16]
              break
            end
          end
        end
      end
    end

    def detect_horizontal
      @lines.each_with_index do |line, y|
        x = 0
        while x < line.length
          if ["-", "="].include?(char(x, y)) && !used?(x, y)
            x1 = x
            x += 1 while x < line.length && ["-", "="].include?(char(x, y)) && !used?(x, y)
            x2 = x - 1
            left = char(x1 - 1, y)
            right = char(x2 + 1, y)
            ymid = y * 16 + 8
            if left == "<"
              @items << [:poly, [[x1 * 8, ymid - 4], [(x1 - 1) * 8, ymid], [x1 * 8, ymid + 4]], "filled"]
              mark(x1 - 1, y)
            end
            line_start = x1 * 8
            line_start = x1 * 8 if left == "<"
            line_end = (x2 + 1) * 8
            if left == "o" && right == "o"
              center = ((x1 + x2 + 1) * 4)
              @items << [:line, center, ymid, (x1 - 1) * 8 + 4, ymid, "solid end_marked_open_circle"]
              @items << [:line, center, ymid, (x2 + 1) * 8 + 4, ymid, "solid end_marked_open_circle"]
              mark(x1 - 1, y)
              mark(x2 + 1, y)
            elsif right == ">"
              @items << [:line, line_start, ymid, line_end, ymid, "solid"]
              @items << [:poly, [[line_end, ymid - 4], [line_end + 8, ymid], [line_end, ymid + 4]], "filled"]
              mark(x2 + 1, y)
            elsif right == "o"
              @items << [:line, line_start, ymid, line_end + 4, ymid, "solid end_marked_open_circle"]
              mark(x2 + 1, y)
            elsif right == "*"
              @items << [:line, line_start, ymid, line_end + 4, ymid, "solid end_marked_circle"]
              mark(x2 + 1, y)
            elsif left == "o"
              @items << [:line, line_end, ymid, (x1 - 1) * 8 + 4, ymid, "solid end_marked_open_circle"]
            else
              @items << [:line, line_start, ymid, line_end, ymid, "solid"]
            end
            (x1..x2).each { |xx| mark(xx, y) }
          else
            x += 1
          end
        end
      end
    end

    def detect_vertical
      (0...@width).each do |x|
        y = 0
        while y < @lines.length
          if char(x, y) == "|" && !used?(x, y)
            y1 = y
            y += 1 while y < @lines.length && char(x, y) == "|" && !used?(x, y)
            y2 = y - 1
            xmid = x * 8 + 4
            top = char(x, y1 - 1)
            bottom = char(x, y2 + 1)
            if top == "^"
              @items << [:poly, [[xmid - 4, y1 * 16 - 4], [xmid, (y1 - 1) * 16], [xmid + 4, y1 * 16 - 4]], "filled"]
              @items << [:line, xmid, y1 * 16 - 4, xmid, (y2 + 1) * 16, "solid"]
              mark(x, y1 - 1)
            elsif bottom == "v"
              @items << [:line, xmid, y1 * 16, xmid, (y2 + 1) * 16 + 4, "solid"]
              @items << [:poly, [[xmid - 4, (y2 + 1) * 16 + 4], [xmid + 4, (y2 + 1) * 16 + 4], [xmid, (y2 + 2) * 16]], "filled"]
              mark(x, y2 + 1)
            else
              @items << [:line, xmid, y1 * 16, xmid, (y2 + 1) * 16, "solid"]
            end
            (y1..y2).each { |yy| mark(x, yy) }
          else
            y += 1
          end
        end
      end
    end

    def detect_diagonal
      @lines.each_with_index do |line, y|
        (0...line.length).each do |x|
          next if used?(x, y)
          case char(x, y)
          when "/"
            @items << [:line, (x + 1) * 8, y * 16, x * 8, (y + 1) * 16, "solid"]
            mark(x, y)
          when "\\"
            @items << [:line, x * 8, y * 16, (x + 1) * 8, (y + 1) * 16, "solid"]
            mark(x, y)
          end
        end
      end
    end

    def detect_text
      @lines.each_with_index do |line, y|
        x = 0
        while x < line.length
          if !used?(x, y) && char(x, y) != " " && !graphic_char?(char(x, y))
            x1 = x
            s = +""
            while x < line.length && !used?(x, y) && char(x, y) != " " && !graphic_char?(char(x, y))
              s << char(x, y)
              mark(x, y)
              x += 1
            end
            @items << [:text, x1 * 8 + 2, y * 16 + 12, s]
          else
            x += 1
          end
        end
      end
    end

    def svg
      w = (@width + 1) * 8
      h = (@height + 1) * 16
      out = +""
      out << %(<svg xmlns="http://www.w3.org/2000/svg" width="#{num(w)}" height="#{num(h)}" class="svgbob">\n)
      out << style
      out << defs
      out << %(  <rect class="backdrop" x="0" y="0" width="#{num(w)}" height="#{num(h)}"></rect>\n)
      @items.sort_by { |item| item_key(item) }.each { |item| out << emit(item) }
      out << "</svg>\n"
      out
    end

    def style
      font = @opts[:font_family] || "Iosevka Fixed, monospace"
      <<~STYLE
          <style>.svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {
          stroke: #{@opts[:stroke_color]};
          stroke-width: #{@opts[:stroke_width]};
          stroke-opacity: 1;
          fill-opacity: 1;
          stroke-linecap: round;
          stroke-linejoin: miter;
        }

        .svgbob text {
          white-space: pre;
          fill: #{@opts[:stroke_color]};
          font-family: #{font};
          font-size: #{@opts[:font_size]}px;
        }

        .svgbob rect.backdrop {
          stroke: none;
          fill: #{@opts[:background]};
        }

        .svgbob .broken {
          stroke-dasharray: 8;
        }

        .svgbob .filled {
          fill: #{@opts[:fill_color]};
        }

        .svgbob .bg_filled {
          fill: #{@opts[:background]};
          stroke-width: 1;
        }

        .svgbob .nofill {
          fill: #{@opts[:background]};
        }

        .svgbob .end_marked_arrow {
          marker-end: url(#arrow);
        }

        .svgbob .start_marked_arrow {
          marker-start: url(#arrow);
        }

        .svgbob .end_marked_diamond {
          marker-end: url(#diamond);
        }

        .svgbob .start_marked_diamond {
          marker-start: url(#diamond);
        }

        .svgbob .end_marked_circle {
          marker-end: url(#circle);
        }

        .svgbob .start_marked_circle {
          marker-start: url(#circle);
        }

        .svgbob .end_marked_open_circle {
          marker-end: url(#open_circle);
        }

        .svgbob .start_marked_open_circle {
          marker-start: url(#open_circle);
        }

        .svgbob .end_marked_big_open_circle {
          marker-end: url(#big_open_circle);
        }

        .svgbob .start_marked_big_open_circle {
          marker-start: url(#big_open_circle);
        }

        </style>
      STYLE
    end

    def defs
      "  <defs>\n" \
        "    <marker id=\"arrow\" viewBox=\"-2 -2 8 8\" refX=\"4\" refY=\"2\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n" \
        "      <polygon points=\"0,0 0,4 4,2 0,0\"></polygon>\n" \
        "    </marker>\n" \
        "    <marker id=\"diamond\" viewBox=\"-2 -2 8 8\" refX=\"4\" refY=\"2\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n" \
        "      <polygon points=\"0,2 2,0 4,2 2,4 0,2\"></polygon>\n" \
        "    </marker>\n" \
        "    <marker id=\"circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n" \
        "      <circle cx=\"4\" cy=\"4\" r=\"2\" class=\"filled\"></circle>\n" \
        "    </marker>\n" \
        "    <marker id=\"open_circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n" \
        "      <circle cx=\"4\" cy=\"4\" r=\"2\" class=\"bg_filled\"></circle>\n" \
        "    </marker>\n" \
        "    <marker id=\"big_open_circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n" \
        "      <circle cx=\"4\" cy=\"4\" r=\"3\" class=\"bg_filled\"></circle>\n" \
        "    </marker>\n" \
        "  </defs>\n"
    end

    def emit(item)
      case item[0]
      when :rect
        %(  <rect x="#{num(item[1])}" y="#{num(item[2])}" width="#{num(item[3])}" height="#{num(item[4])}" class="solid nofill" rx="0"></rect>\n)
      when :line
        %(  <line x1="#{num(item[1])}" y1="#{num(item[2])}" x2="#{num(item[3])}" y2="#{num(item[4])}" class="#{item[5]}"></line>\n)
      when :poly
        pts = item[1].map { |x, y| "#{num(x)},#{num(y)}" }.join(" ")
        %(  <polygon points="#{pts}" class="#{item[2]}"></polygon>\n)
      when :text
        %(  <text x="#{num(item[1])}" y="#{num(item[2])}" >#{escape(item[3])}</text>\n)
      else
        ""
      end
    end

    def item_key(item)
      case item[0]
      when :rect
        [item[2].to_i / 16, item[1], 0]
      when :line
        [[item[2], item[4]].min.to_i / 16, [item[1], item[3]].min, 1]
      when :poly
        ys = item[1].map(&:last)
        xs = item[1].map(&:first)
        [ys.min.to_i / 16, xs.min, 2]
      when :text
        [item[2].to_i / 16, item[1], 3]
      else
        [0, 0, 9]
      end
    end

    def num(n)
      v = n.to_f * @opts[:scale].to_f
      v.round == v ? v.round.to_s : format("%.3f", v).sub(/0+\z/, "").sub(/\.\z/, "")
    end

    def escape(s)
      s.to_s.gsub("&", "&amp;").gsub("<", "&lt;").gsub(">", "&gt;")
    end
  end
end
