# frozen_string_literal: true

module Delta
  VERSION = '0.18.2'

  VALUE_OPTIONS = %w[
    --blame-code-style --blame-format --blame-palette --blame-separator-format
    --blame-separator-style --blame-timestamp-format --blame-timestamp-output-format
    --config --commit-decoration-style --commit-regex --commit-style
    --default-language --detect-dark-light --diff-args --diff-stat-align-width
    --features --file-added-label --file-copied-label --file-decoration-style
    --file-modified-label --file-removed-label --file-renamed-label --file-style
    --file-transformation --generate-completion --grep-context-line-style
    --grep-file-style --grep-header-decoration-style --grep-header-file-style
    --grep-line-number-style --grep-output-type --grep-match-line-style
    --grep-match-word-style --grep-separator-symbol --hunk-header-decoration-style
    --hunk-header-file-style --hunk-header-line-number-style --hunk-header-style
    --hunk-label --hyperlinks-commit-link-format --hyperlinks-file-link-format
    --inline-hint-style --inspect-raw-lines --line-buffer-size --line-fill-method
    --line-numbers-left-format --line-numbers-left-style --line-numbers-minus-style
    --line-numbers-plus-style --line-numbers-right-format --line-numbers-right-style
    --line-numbers-zero-style --map-styles --max-line-distance
    --max-syntax-highlighting-length --max-line-length --merge-conflict-begin-symbol
    --merge-conflict-end-symbol --merge-conflict-ours-diff-header-decoration-style
    --merge-conflict-ours-diff-header-style
    --merge-conflict-theirs-diff-header-decoration-style
    --merge-conflict-theirs-diff-header-style --minus-empty-line-marker-style
    --minus-emph-style --minus-non-emph-style --minus-style --navigate-regex
    --pager --paging --plus-emph-style --plus-empty-line-marker-style
    --plus-non-emph-style --plus-style --right-arrow --syntax-theme --tabs
    --true-color --whitespace-error-style --width --word-diff-regex
    --wrap-left-symbol --wrap-max-lines --wrap-right-percent
    --wrap-right-prefix-symbol --wrap-right-symbol --zero-style --24-bit-color
  ].freeze

  SHORT_VALUE_OPTIONS = {
    '-w' => '--width',
    '-@' => '--diff-args'
  }.freeze

  BOOL_OPTIONS = %w[
    --color-only --dark --diff-highlight --diff-so-fancy --hyperlinks
    --keep-plus-minus-markers --light --line-numbers --list-languages
    --list-syntax-themes --navigate --no-gitconfig --parse-ansi --raw
    --relative-paths --show-colors --show-config --show-syntax-themes
    --show-themes --side-by-side --help --version
  ].freeze

  SHORT_BOOL_OPTIONS = {
    '-h' => '--help',
    '-V' => '--version',
    '-n' => '--line-numbers',
    '-s' => '--side-by-side'
  }.freeze

  HELP_SHORT = <<~TEXT
    A viewer for git and diff output

    Usage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]

    Arguments:
      [MINUS_FILE]  First file to be compared when delta is being used to diff two files
      [PLUS_FILE]   Second file to be compared when delta is being used to diff two files

    Options:
          --blame-code-style <STYLE>                                    Style string for the code section of a git blame line
          --blame-format <FMT>                                          Format string for git blame commit metadata [default: "{timestamp:<15} {author:<15.14} {commit:<8}"]
          --blame-palette <COLORS>                                      Background colors used for git blame lines (space-separated string)
          --blame-separator-format <FMT>                                Separator between the blame format and the code section of a git blame line [default: │{n:^4}│]
          --blame-separator-style <STYLE>                               Style string for the blame-separator-format
          --blame-timestamp-format <FMT>                                Format of `git blame` timestamp in raw git output received by delta [default: "%Y-%m-%d %H:%M:%S %z"]
          --blame-timestamp-output-format <FMT>                         Format string for git blame timestamp output
          --color-only                                                  Do not alter the input structurally in any way
          --config <PATH>                                               Load the config file at PATH instead of ~/.gitconfig [default: ]
          --commit-decoration-style <STYLE>                             Style string for the commit hash decoration [default: ]
          --commit-regex <REGEX>                                        Regular expression used to identify the commit line when parsing git output [default: "^commit "]
          --commit-style <STYLE>                                        Style string for the commit hash line [default: raw]
          --dark                                                        Use default colors appropriate for a dark terminal background
          --default-language <LANG>                                     Default language used for syntax highlighting [default: txt]
      -@, --diff-args <STRING>                                          Extra arguments to pass to `git diff` when using delta to diff two files [default: ]
          --diff-highlight                                              Emulate diff-highlight
          --diff-so-fancy                                               Emulate diff-so-fancy
          --features <FEATURES>                                         Names of delta features to activate (space-separated)
          --generate-completion <GENERATE_COMPLETION>                   Print completion file for the given shell [possible values: bash, elvish, fish, powershell, zsh]
      -n, --line-numbers                                                Display line numbers next to the diff
          --list-languages                                              List supported languages and associated file extensions
          --list-syntax-themes                                          List available syntax-highlighting color themes
          --no-gitconfig                                                Do not read any settings from git config
          --paging <auto|always|never>                                  Whether to use a pager when displaying output [default: auto] [possible values: auto, always, never]
          --parse-ansi                                                  Display ANSI color escape sequences in human-readable form
          --raw                                                         Do not alter the input in any way
          --show-colors                                                 Show available named colors
          --show-config                                                 Display the active values for all Delta options
          --show-syntax-themes                                          Show example diff for available syntax-highlighting themes
          --show-themes                                                 Show example diff for available delta themes
      -s, --side-by-side                                                Display diffs in side-by-side layout
          --syntax-theme <SYNTAX_THEME>                                 The syntax-highlighting theme to use
          --tabs <N>                                                    The number of spaces to replace tab characters with [default: 8]
          --true-color <auto|always|never>                              Whether to emit 24-bit ("true color") RGB color codes [default: auto] [possible values: auto, always, never]
      -w, --width <N>                                                   The width of underline/overline decorations
      -h, --help                                                        Print help (see more with '--help')
      -V, --version                                                     Print version
  TEXT

  LANGUAGES = {
    'Ruby' => %w[rb builder gemspec podspec rake jbuilder],
    'Rust' => %w[rs],
    'Python' => %w[py pyw],
    'JavaScript' => %w[js jsx mjs cjs],
    'TypeScript' => %w[ts tsx],
    'C' => %w[c h],
    'C++' => %w[cc cpp cxx hpp hxx],
    'Go' => %w[go],
    'JSON' => %w[json],
    'Markdown' => %w[md markdown],
    'Shell' => %w[sh bash zsh fish],
    'YAML' => %w[yml yaml],
    'Diff' => %w[diff patch]
  }.freeze

  THEMES = %w[
    1337 Coldark-Cold Coldark-Dark Dracula GitHub Monokai\ Extended
    Monokai\ Extended\ Bright Nord OneHalfDark OneHalfLight Solarized\ \(dark\)
    Solarized\ \(light\) Sublime\ Snazzy TwoDark ansi base16
  ].freeze

  COLORS = %w[
    black red green yellow blue magenta cyan white brightblack brightred
    brightgreen brightyellow brightblue brightmagenta brightcyan brightwhite
  ].freeze

  class CLI
    def initialize(argv, input, output, error)
      @argv = argv.dup
      @input = input
      @output = output
      @error = error
      @opts = {}
      @files = []
    end

    def run
      parse!
      return print_help if @opts['--help']
      return puts_out("delta #{VERSION}") if @opts['--version']
      return list_languages if @opts['--list-languages']
      return list_themes if @opts['--list-syntax-themes']
      return show_colors if @opts['--show-colors']
      return show_config if @opts['--show-config']
      return generate_completion if @opts['--generate-completion']
      return show_theme_demo if @opts['--show-syntax-themes'] || @opts['--show-themes']

      text = input_text
      text = parse_ansi(text) if @opts['--parse-ansi']
      return write_out(text) if @opts['--raw'] || @opts['--color-only']

      renderer = DiffRenderer.new(@opts)
      write_out(renderer.render(text))
      0
    rescue UsageError => e
      @error.puts "error: #{e.message}"
      @error.puts
      @error.puts "Usage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]"
      2
    rescue Errno::ENOENT => e
      @error.puts "delta: #{e.message}"
      1
    end

    private

    def parse!
      until @argv.empty?
        arg = @argv.shift
        if arg == '--'
          @files.concat(@argv)
          @argv.clear
        elsif SHORT_BOOL_OPTIONS.key?(arg)
          @opts[SHORT_BOOL_OPTIONS[arg]] = true
        elsif SHORT_VALUE_OPTIONS.key?(arg)
          @opts[SHORT_VALUE_OPTIONS[arg]] = take_value(arg)
        elsif arg.start_with?('--')
          name, value = arg.split('=', 2)
          if BOOL_OPTIONS.include?(name)
            @opts[name] = value.nil? ? true : value
          elsif VALUE_OPTIONS.include?(name)
            @opts[name] = value || take_value(name)
          else
            raise UsageError, "unexpected argument '#{arg}' found"
          end
        elsif arg.start_with?('-') && arg.length > 2
          parse_short_cluster(arg)
        else
          @files << arg
        end
      end
      raise UsageError, 'too many arguments' if @files.length > 2
    end

    def parse_short_cluster(arg)
      chars = arg[1..].chars
      until chars.empty?
        short = "-#{chars.shift}"
        if SHORT_BOOL_OPTIONS.key?(short)
          @opts[SHORT_BOOL_OPTIONS[short]] = true
        elsif SHORT_VALUE_OPTIONS.key?(short)
          @opts[SHORT_VALUE_OPTIONS[short]] = chars.empty? ? take_value(short) : chars.join
          chars.clear
        else
          raise UsageError, "unexpected argument '#{short}' found"
        end
      end
    end

    def take_value(opt)
      raise UsageError, "a value is required for '#{opt}'" if @argv.empty?

      @argv.shift
    end

    def input_text
      return @input.read if @files.empty?
      return File.read(@files[0]) if @files.length == 1

      diff_two_files(@files[0], @files[1])
    end

    def diff_two_files(left, right)
      raise Errno::ENOENT, left unless File.exist?(left)
      raise Errno::ENOENT, right unless File.exist?(right)

      out = `diff -u #{ShellwordsLite.escape(left)} #{ShellwordsLite.escape(right)} 2>&1`
      out
    end

    def print_help
      @output.write(HELP_SHORT)
      0
    end

    def list_languages
      LANGUAGES.sort.each do |name, exts|
        @output.puts "#{name}: #{exts.join(', ')}"
      end
      0
    end

    def list_themes
      THEMES.each { |theme| @output.puts theme }
      0
    end

    def show_colors
      COLORS.each { |color| @output.puts color }
      0
    end

    def show_config
      defaults = {
        'blame-format' => '"{timestamp:<15} {author:<15.14} {commit:<8}"',
        'commit-style' => 'raw',
        'dark' => @opts['--dark'] ? 'true' : 'false',
        'file-style' => 'blue',
        'hunk-header-style' => 'line-number syntax',
        'keep-plus-minus-markers' => @opts['--keep-plus-minus-markers'] ? 'true' : 'false',
        'line-numbers' => @opts['--line-numbers'] ? 'true' : 'false',
        'paging' => @opts['--paging'] || 'auto',
        'side-by-side' => @opts['--side-by-side'] ? 'true' : 'false',
        'syntax-theme' => @opts['--syntax-theme'] || 'auto',
        'tabs' => @opts['--tabs'] || '8',
        'width' => @opts['--width'] || 'variable'
      }
      defaults.each { |k, v| @output.puts "#{k}: #{v}" }
      0
    end

    def generate_completion
      shell = @opts['--generate-completion']
      case shell
      when 'bash'
        @output.puts "_delta() { COMPREPLY=( $(compgen -W \"--help --version --raw --color-only --line-numbers --side-by-side\" -- \"${COMP_WORDS[COMP_CWORD]}\") ); }"
        @output.puts 'complete -F _delta delta'
      when 'fish'
        @output.puts 'complete -c delta -l help -d "Print help"'
        @output.puts 'complete -c delta -l version -d "Print version"'
      when 'zsh'
        @output.puts '#compdef delta'
        @output.puts '_arguments "*:file:_files" "--help[Print help]" "--version[Print version]"'
      else
        @output.puts "# completion for #{shell}"
      end
      0
    end

    def show_theme_demo
      sample = @input.read
      sample = "--- a/example.rb\n+++ b/example.rb\n@@ -1,2 +1,2 @@\n-puts 'old'\n+puts 'new'\n" if sample.empty?
      THEMES.each do |theme|
        @output.puts theme
        @output.puts DiffRenderer.new(@opts).render(sample)
      end
      0
    end

    def parse_ansi(text)
      text.gsub(/\e\[/, '<ESC>[')
    end

    def puts_out(text)
      @output.puts text
      0
    end

    def write_out(text)
      @output.write(text)
      0
    end
  end

  class UsageError < StandardError; end

  module ShellwordsLite
    module_function

    def escape(value)
      return "''" if value.empty?

      value.gsub(/[^A-Za-z0-9_\-.,:\/@\n]/, '\\\\\&').gsub("\n", "'\n'")
    end
  end

  class DiffRenderer
    HUNK_RE = /^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@/

    def initialize(opts)
      @opts = opts
      @keep_markers = !!opts['--keep-plus-minus-markers']
      @line_numbers = !!opts['--line-numbers']
      @side_by_side = !!opts['--side-by-side']
      @width = numeric_width(opts['--width']) || 80
      @minus_line = nil
      @plus_line = nil
    end

    def render(text)
      return render_side_by_side(text) if @side_by_side

      out = []
      text.each_line do |line|
        out << render_line(line)
      end
      out.join
    end

    private

    def render_line(line)
      case line
      when HUNK_RE
        @minus_line = Regexp.last_match(1).to_i
        @plus_line = Regexp.last_match(2).to_i
        line
      when /^--- /, /^\+\+\+ /, /^diff --git /, /^index /, /^new file mode /, /^deleted file mode /
        line
      when /^-(?!--)/
        body = @keep_markers ? line : line[1..]
        with_numbers(body, :minus)
      when /^\+(?!\+\+)/
        body = @keep_markers ? line : line[1..]
        with_numbers(body, :plus)
      when /^ /
        body = line[1..]
        with_numbers(body, :zero)
      else
        line
      end
    end

    def with_numbers(body, kind)
      return body unless @line_numbers

      case kind
      when :minus
        prefix = "#{fmt(@minus_line)}⋮    │"
        @minus_line += 1 if @minus_line
      when :plus
        prefix = "    ⋮#{fmt(@plus_line)}│"
        @plus_line += 1 if @plus_line
      else
        prefix = "#{fmt(@minus_line)}⋮#{fmt(@plus_line)}│"
        @minus_line += 1 if @minus_line
        @plus_line += 1 if @plus_line
      end
      "#{prefix} #{body}"
    end

    def fmt(n)
      s = n ? n.to_s : ''
      total = 4 - s.length
      left = total / 2
      right = total - left
      (' ' * left) + s + (' ' * right)
    end

    def render_side_by_side(text)
      out = []
      pending_minus = nil
      text.each_line do |line|
        case line
        when /^-(?!--)/
          pending_minus = line[1..].chomp
        when /^\+(?!\+\+)/
          plus = line[1..].chomp
          if pending_minus
            out << side_row(pending_minus, plus)
            pending_minus = nil
          else
            out << side_row('', plus)
          end
        else
          out << side_row(pending_minus, '') if pending_minus
          pending_minus = nil
          out << line
        end
      end
      out << side_row(pending_minus, '') if pending_minus
      out.join
    end

    def side_row(left, right)
      col = [(@width - 3) / 2, 10].max
      "#{left.to_s[0, col].ljust(col)} │ #{right}\n"
    end

    def numeric_width(value)
      return nil if value.nil? || value == 'variable'

      value.to_s[/\d+/]&.to_i
    end
  end
end
