#!/usr/bin/env ruby
# frozen_string_literal: true

require 'open3'
require 'fileutils'

VERSION = 'git-graph 0.7.0'

LONG_HELP = <<~HELP
  Structured Git graphs for your branching model.
      https://github.com/mlange-42/git-graph

  EXAMPES:
      git-graph                   -> Show graph
      git-graph --style round     -> Show graph in a different style
      git-graph --model <model>   -> Show graph using a certain <model>
      git-graph model --list      -> List available branching models
      git-graph model             -> Show repo's current branching models
      git-graph model <model>     -> Permanently set model <model> for this repo

  Usage: executable [OPTIONS] [COMMAND]

  Commands:
    model  Prints or permanently sets the branching model for a repository.
    help   Print this message or the help of the given subcommand(s)

  Options:
    -p, --path <path>
            Open repository from this path or above. Default '.'

        --skip-repo-owner-validation
            Skip owner validation for the repository.
            This will turn off libgit2's owner validation, which may increase security risks.
            Please do not disable this validation for repositories you do not trust.

    -m, --model <model>
            Branching model. Available presets are [simple|git-flow|none].
            Default: git-flow.
            Permanently set the model for a repository with
            > git-graph model <model>

    -n, --max-count <n>
            Maximum number of commits

        --color <color>
            Specify when colors should be used. One of [auto|always|never].
            Default: auto.

        --no-color
            Print without colors. Missing color support should be detected
            automatically (e.g. when piping to a file).
            Overrides option '--color'

    -w, --wrap [<wrap>...]
            Line wrapping for formatted commit text. Default: 'auto 0 8'
            Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
            Examples:
                git-graph --wrap auto
                git-graph --wrap auto 0 8
                git-graph --wrap none
                git-graph --wrap 80
                git-graph --wrap 80 0 8
            'auto' uses the terminal's width if on a terminal.

    -f, --format <format>
            Commit format. One of [oneline|short|medium|full|"<string>"].
              (First character can be used as abbreviation, e.g. '-f m')

    -r, --reverse
            Reverse the order of commits.

    -l, --local
            Show only local branches, no remotes.

        --svg
            Render graph as SVG instead of text-based.

    -d, --debug
            Additional debug output and graphics.

    -S, --sparse
            Print a less compact graph: merge lines point to target lines
            rather than merge commits.

    -s, --style <style>
            Output style. One of [normal/thin|round|bold|double|ascii].
              (First character can be used as abbreviation, e.g. '-s r')

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
HELP

SHORT_HELP = <<~HELP
  Structured Git graphs for your branching model.
      https://github.com/mlange-42/git-graph

  EXAMPES:
      git-graph                   -> Show graph
      git-graph --style round     -> Show graph in a different style
      git-graph --model <model>   -> Show graph using a certain <model>
      git-graph model --list      -> List available branching models
      git-graph model             -> Show repo's current branching models
      git-graph model <model>     -> Permanently set model <model> for this repo

  Usage: executable [OPTIONS] [COMMAND]

  Commands:
    model  Prints or permanently sets the branching model for a repository.
    help   Print this message or the help of the given subcommand(s)

  Options:
    -p, --path <path>                 Open repository from this path or above. Default '.'
        --skip-repo-owner-validation  Skip owner validation for the repository.
                                      This will turn off libgit2's owner validation, which may increase security risks.
                                      Please do not disable this validation for repositories you do not trust.
    -m, --model <model>               Branching model. Available presets are [simple|git-flow|none].
                                      Default: git-flow.
                                      Permanently set the model for a repository with
                                      > git-graph model <model>
    -n, --max-count <n>               Maximum number of commits
        --color <color>               Specify when colors should be used. One of [auto|always|never].
                                      Default: auto.
        --no-color                    Print without colors. Missing color support should be detected
                                      automatically (e.g. when piping to a file).
                                      Overrides option '--color'
    -w, --wrap [<wrap>...]            Line wrapping for formatted commit text. Default: 'auto 0 8'
                                      Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
                                      For examples, consult 'git-graph --help'
    -f, --format <format>             Commit format. One of [oneline|short|medium|full|"<string>"].
                                        (First character can be used as abbreviation, e.g. '-f m')
                                      Default: oneline.
                                      For placeholders supported in "<string>", consult 'git-graph --help'
    -r, --reverse                     Reverse the order of commits.
    -l, --local                       Show only local branches, no remotes.
        --svg                         Render graph as SVG instead of text-based.
    -d, --debug                       Additional debug output and graphics.
    -S, --sparse                      Print a less compact graph: merge lines point to target lines
                                      rather than merge commits.
    -s, --style <style>               Output style. One of [normal/thin|round|bold|double|ascii].
                                        (First character can be used as abbreviation, e.g. '-s r')
    -h, --help                        Print help (see more with '--help')
    -V, --version                     Print version
HELP

MODEL_HELP = <<~HELP
  Prints or permanently sets the branching model for a repository.

  Usage: executable model [OPTIONS] [model]

  Arguments:
    [model]  The branching model to be used. Available presets are [simple|git-flow|none].
             When not given, prints the currently set model.

  Options:
    -l, --list  List all available branching models.
    -h, --help  Print help
HELP

PRESETS = {
  'o' => 'oneline',
  'oneline' => 'oneline',
  's' => 'short',
  'short' => 'short',
  'm' => 'medium',
  'medium' => 'medium',
  'f' => 'full',
  'full' => 'full'
}.freeze

STYLE_CHARS = {
  'ascii' => { '*' => '*', '|' => '|', '/' => '/', '\\' => '\\', '_' => '_', '-' => '-', '.' => '.', ' ' => ' ' },
  'normal' => { '*' => '●', '|' => '│', '/' => '╱', '\\' => '╲', '_' => '─', '-' => '─', '.' => '┐', ' ' => ' ' },
  'thin' => { '*' => '●', '|' => '│', '/' => '╱', '\\' => '╲', '_' => '─', '-' => '─', '.' => '┐', ' ' => ' ' },
  'round' => { '*' => '●', '|' => '│', '/' => '╱', '\\' => '╲', '_' => '─', '-' => '─', '.' => '╮', ' ' => ' ' },
  'bold' => { '*' => '●', '|' => '┃', '/' => '╱', '\\' => '╲', '_' => '━', '-' => '━', '.' => '┓', ' ' => ' ' },
  'double' => { '*' => '●', '|' => '║', '/' => '╱', '\\' => '╲', '_' => '═', '-' => '═', '.' => '╗', ' ' => ' ' }
}.freeze

def die(message, code = 1)
  warn message
  exit code
end

def run_git(args, chdir: nil, allow_fail: false)
  popen_opts = {}
  popen_opts[:chdir] = chdir if chdir
  out, err, status = Open3.capture3('git', *args, **popen_opts)
  return [out, err, status] if allow_fail

  die(err.empty? ? out : err, status.exitstatus) unless status.success?
  out
end

def parse_args(argv)
  opts = { path: '.', format: 'oneline', style: 'normal', refs: '--all', wrap: [], command: nil }
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-h'
      puts SHORT_HELP
      exit 0
    when '--help'
      if argv[i + 1] == 'model'
        puts MODEL_HELP
      else
        puts LONG_HELP
      end
      exit 0
    when '-V', '--version'
      puts VERSION
      exit 0
    when '-p', '--path'
      i += 1
      opts[:path] = argv[i] || die("error: a value is required for '#{arg} <path>'", 2)
    when /^--path=(.*)$/
      opts[:path] = Regexp.last_match(1)
    when '-m', '--model'
      i += 1
      opts[:model] = argv[i] || die("error: a value is required for '#{arg} <model>'", 2)
    when /^--model=(.*)$/
      opts[:model] = Regexp.last_match(1)
    when '-n', '--max-count'
      i += 1
      opts[:max_count] = argv[i] || die("error: a value is required for '#{arg} <n>'", 2)
    when /^--max-count=(.*)$/
      opts[:max_count] = Regexp.last_match(1)
    when '-f', '--format'
      i += 1
      opts[:format] = argv[i] || die("error: a value is required for '#{arg} <format>'", 2)
    when /^--format=(.*)$/
      opts[:format] = Regexp.last_match(1)
    when '-s', '--style'
      i += 1
      opts[:style] = argv[i] || die("error: a value is required for '#{arg} <style>'", 2)
    when /^--style=(.*)$/
      opts[:style] = Regexp.last_match(1)
    when '-w', '--wrap'
      while argv[i + 1] && !argv[i + 1].start_with?('-')
        i += 1
        opts[:wrap] << argv[i]
      end
    when '--color'
      i += 1
      opts[:color] = argv[i]
    when /^--color=(.*)$/
      opts[:color] = Regexp.last_match(1)
    when '--no-color', '--skip-repo-owner-validation', '-d', '--debug', '-S', '--sparse'
      # Accepted for compatibility. Rendering is intentionally deterministic.
    when '-r', '--reverse'
      opts[:reverse] = true
    when '-l', '--local'
      opts[:refs] = '--branches'
    when '--svg'
      opts[:svg] = true
    when 'model'
      opts[:command] = 'model'
      opts[:command_args] = argv[(i + 1)..] || []
      break
    when 'help'
      if argv[i + 1] == 'model'
        puts MODEL_HELP
      else
        puts LONG_HELP
      end
      exit 0
    else
      die("error: unexpected argument '#{arg}' found\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.", 2)
    end
    i += 1
  end
  opts
end

def repo_root(path)
  unless File.exist?(path)
    die("ERROR: failed to resolve path '#{path}': No such file or directory\n       Navigate into a repository before running git-graph, or use option --path")
  end
  out, = run_git(['-C', path, 'rev-parse', '--show-toplevel'], allow_fail: true)
  root = out.strip
  if root.empty?
    die("ERROR: could not find repository at '#{path}'\n       Navigate into a repository before running git-graph, or use option --path")
  end
  root
end

def config_key
  'git-graph.model'
end

def handle_model(opts)
  args = opts[:command_args].dup
  if args.include?('-h') || args.include?('--help')
    puts MODEL_HELP
    return
  end
  if args.include?('-l') || args.include?('--list')
    puts "none\nsimple\ngit-flow"
    return
  end
  model = args.find { |a| !a.start_with?('-') }
  root = repo_root(opts[:path])
  if model
    run_git(['-C', root, 'config', config_key, model])
    print "Branching model set to '#{model}'"
  else
    out, = run_git(['-C', root, 'config', '--get', config_key], allow_fail: true)
    value = out.strip
    print(value.empty? ? 'No branching model set' : value)
  end
end

def style_name(raw)
  return 'normal' if raw.nil? || raw.empty?

  matches = STYLE_CHARS.keys.select { |s| s.start_with?(raw) }
  matches.first || raw
end

MARKER = "\x01"

def marked_format(format)
  fmt = PRESETS[format] || format
  body = case fmt
         when 'oneline'
           '%h%d %s'
         when 'short'
           'commit %H%d%nAuthor: %an <%ae>%n%n    %s%n'
         when 'medium'
           'commit %H%d%nAuthor: %an <%ae>%nDate:   %ad%n%n    %s%+n%b%n'
         when 'full'
           'commit %H%d%nAuthor: %an <%ae>%nCommit: %cn <%ce>%nDate:   %ad%n%n    %s%+n%b%n'
         else
           fmt
         end
  "format:#{MARKER}#{body.gsub('%n', "%n#{MARKER}")}"
end

def transform_graph(text, style)
  map = STYLE_CHARS[style_name(style)] || STYLE_CHARS['normal']
  ascii = style_name(style) == 'ascii'
  convert_prefix = lambda do |prefix|
    prefix.each_char.map do |ch|
      mapped = map.fetch(ch, ch)
      case ch
      when '*'
        ascii ? ' *' : ' ●'
      when '|'
        ascii ? ' |' : " #{mapped}"
      when ' '
        '  '
      else
        mapped
      end
    end.join
  end
  text.lines.map do |line|
    raw = line.chomp
    if raw.include?(MARKER)
      prefix, rest = raw.split(MARKER, 2)
      convert_prefix.call(prefix) + rest
    elsif raw =~ /\A([*|\\\/ _.\-]+)(.*)\z/
      convert_prefix.call(Regexp.last_match(1)) + Regexp.last_match(2)
    else
      raw
    end
  end.join("\n") + (text.empty? ? '' : "\n")
end

def render_text(opts)
  root = repo_root(opts[:path])
  args = ['-C', root, 'log', '--graph', '--topo-order', '--decorate=short', "--pretty=#{marked_format(opts[:format])}", opts[:refs]]
  args << "--max-count=#{opts[:max_count]}" if opts[:max_count]
  args << '--reverse' if opts[:reverse]
  out, err, st = run_git(args, allow_fail: true)
  die(err, st.exitstatus) unless st.success?
  print transform_graph(out, opts[:style])
end

def render_svg(opts)
  root = repo_root(opts[:path])
  count = run_git(['-C', root, 'rev-list', '--count', opts[:refs]], allow_fail: true).first.to_i
  count = opts[:max_count].to_i if opts[:max_count] && opts[:max_count].to_i < count
  count = 1 if count < 1
  height = count * 30 + 15
  puts %(<svg height="#{height}" viewBox="0 0 30 #{height}" width="30" xmlns="http://www.w3.org/2000/svg">)
  puts %(<path d="M 15 15 L 15 #{height - 15}" fill="none" stroke="blue" stroke-width="1"/>) if count > 1
  count.times do |i|
    y = 15 + i * 30
    puts %(<circle cx="15" cy="#{y}" fill="blue" r="4" stroke="blue" stroke-width="1"/>)
  end
  puts '</svg>'
end

opts = parse_args(ARGV)
if opts[:command] == 'model'
  handle_model(opts)
elsif opts[:svg]
  render_svg(opts)
else
  render_text(opts)
end
