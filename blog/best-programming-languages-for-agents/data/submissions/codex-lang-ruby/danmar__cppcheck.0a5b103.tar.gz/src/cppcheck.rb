#!/usr/bin/env ruby
# frozen_string_literal: true

require 'cgi'
require 'fileutils'

VERSION = 'Cppcheck 2.19 dev'
SOURCE_EXTS = %w[.cpp .cxx .cc .c++ .c .ipp .ixx .tpp .txx .h .hpp .hh .hxx].freeze

HELP = <<~TEXT
  Cppcheck - A tool for static C/C++ code analysis

  Syntax:
      cppcheck [OPTIONS] [files or paths]

  If a directory is given instead of a filename, *.cpp, *.cxx, *.cc, *.c++, *.c, *.ipp,
  *.ixx, *.tpp, and *.txx files are checked recursively from the given directory.

  Options:
      -h, --help           Print this help.
      --version            Print out version number.
      --enable=<severity>  Enable additional checks. Valid severities include
                           warning, performance, portability, information, style,
                           unusedFunction, missingInclude, and all.
      --disable=<severity> Disable checks with the given severity.
      --error-exitcode=<n> If errors are found, integer [n] is returned.
      -q, --quiet          Do not show progress reports.
      -v, --verbose        Output more detailed error information.
      --xml                Write results in xml format to error stream (stderr).
      --output-format=<f>  Specify output format: text, sarif, xml, xmlv2, xmlv3.
      --output-file=<file> Write results to file, rather than standard error.
      --template='<text>'  Format the error messages. Predefined: gcc, cppcheck1, vs, edit.
      --suppress=<spec>    Suppress warnings: [error id]:[filename]:[line]
      --suppressions-list=<file>
                           Read suppressions from file.
      --inline-suppr       Enable inline suppressions.
      -I <dir>             Give path to search for include files.
      -D<ID>               Define preprocessor symbol.
      -U<ID>               Undefine preprocessor symbol.
      -E                   Print preprocessor output on stdout and stop.
      --file-list=<file>   Specify files to check, one per line. Use '-' for stdin.
      --project=<file>     Run Cppcheck on a project/compile_commands.json file.
      --check-config       Check cppcheck configuration.
      --errorlist          Print a list of error messages in XML format.
      --dump               Dump xml data for each translation unit.
      --std=<id>           Set standard.
      --language=<lang>, -x <lang>
                           Forces language: c or c++.

  Example usage:
    cppcheck --enable=all test.cpp
    cppcheck --quiet ../myproject/

  For more information:
      https://cppcheck.sourceforge.io/manual.pdf
TEXT

ERROR_CATALOG = [
  ['arrayIndexOutOfBounds', 'error', "Array 'arr[16]' accessed at index 16, which is out of bounds.", '788'],
  ['negativeIndex', 'error', 'Negative array index', '786'],
  ['zerodiv', 'error', 'Division by zero.', '369'],
  ['memleak', 'error', 'Memory leak: var', '401'],
  ['mismatchAllocDealloc', 'error', 'Mismatching allocation and deallocation: var', '762'],
  ['doubleFree', 'error', 'Memory pointed to by var is freed twice.', '415'],
  ['uninitvar', 'error', 'Uninitialized variable: var', '457'],
  ['nullPointer', 'error', 'Null pointer dereference: var', '476'],
  ['resourceLeak', 'error', 'Resource leak: var', '772'],
  ['memsetZeroBytes', 'warning', 'memset() called to fill 0 bytes.', '687'],
  ['dangerousFunction', 'warning', 'Obsolete function gets() called. It is recommended to use fgets() or gets_s() instead.', '242'],
  ['unusedVariable', 'style', 'Variable var is assigned a value that is never used.', '563'],
  ['missingInclude', 'information', 'Include file: file not found.', ''],
  ['syntaxError', 'error', 'syntax error', '']
].freeze

Diagnostic = Struct.new(:file, :line, :column, :severity, :id, :message, :cwe, :code, keyword_init: true)

class Options
  attr_accessor :quiet, :verbose, :xml, :format, :output_file, :template, :error_exitcode,
                :enabled, :disabled, :inline_suppr, :preprocess, :file_filters, :ignores,
                :includes, :defines, :undefines, :suppressions, :dump, :check_config,
                :checkers_report, :plist_output

  def initialize
    @quiet = false
    @verbose = false
    @xml = false
    @format = 'text'
    @output_file = nil
    @template = 'gcc'
    @error_exitcode = nil
    @enabled = []
    @disabled = []
    @inline_suppr = false
    @preprocess = false
    @file_filters = []
    @ignores = []
    @includes = ['.']
    @defines = {}
    @undefines = []
    @suppressions = []
    @dump = false
    @check_config = false
    @checkers_report = nil
    @plist_output = nil
  end
end

def option_value(arg, argv, idx)
  return [arg.split('=', 2)[1], idx] if arg.include?('=')
  [argv[idx + 1], idx + 1]
end

def parse_args(argv)
  opts = Options.new
  files = []
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-h', '--help'
      puts HELP
      exit 0
    when '--version'
      puts VERSION
      exit 0
    when '--errorlist'
      print_errorlist
      exit 0
    when '-q', '--quiet'
      opts.quiet = true
    when '-v', '--verbose'
      opts.verbose = true
    when '--xml'
      opts.xml = true
      opts.format = 'xmlv2'
    when '-E'
      opts.preprocess = true
    when '--inline-suppr'
      opts.inline_suppr = true
    when '--dump'
      opts.dump = true
    when '--check-config'
      opts.check_config = true
    when /^-D(.+)/
      name, val = Regexp.last_match(1).split('=', 2)
      opts.defines[name] = val || '1'
    when /^-U(.+)/
      opts.undefines << Regexp.last_match(1)
    when '-I'
      i += 1
      opts.includes << argv[i].to_s
    when /^-I(.+)/
      opts.includes << Regexp.last_match(1)
    when '-i'
      i += 1
      opts.ignores << argv[i].to_s
    when '-x', '--language'
      i += 1 unless arg.include?('=')
    when '--file-list'
      val, i = option_value(arg, argv, i)
      files.concat(read_list(val))
    when /^--file-list=/
      files.concat(read_list(arg.split('=', 2)[1]))
    when '--file-filter'
      val, i = option_value(arg, argv, i)
      opts.file_filters << val
    when /^--file-filter=/
      opts.file_filters << arg.split('=', 2)[1]
    when '--output-file'
      opts.output_file, i = option_value(arg, argv, i)
    when /^--output-file=/
      opts.output_file = arg.split('=', 2)[1]
    when /^--output-format=/
      opts.format = arg.split('=', 2)[1]
      opts.xml = true if opts.format.start_with?('xml')
    when /^--xml-version=/
      opts.xml = true
    when /^--template=/
      opts.template = arg.split('=', 2)[1].delete_prefix("'").delete_suffix("'")
    when '--template'
      opts.template = argv[i + 1].to_s
      i += 1
    when /^--error-exitcode=/
      opts.error_exitcode = arg.split('=', 2)[1].to_i
    when '--error-exitcode'
      opts.error_exitcode = argv[i + 1].to_i
      i += 1
    when /^--enable=/
      opts.enabled.concat(arg.split('=', 2)[1].split(','))
    when /^--disable=/
      opts.disabled.concat(arg.split('=', 2)[1].split(','))
    when /^--suppress=/
      opts.suppressions << arg.split('=', 2)[1]
    when '--suppress'
      opts.suppressions << argv[i + 1].to_s
      i += 1
    when /^--suppressions-list=/
      opts.suppressions.concat(read_list(arg.split('=', 2)[1]))
    when '--suppressions-list'
      opts.suppressions.concat(read_list(argv[i + 1]))
      i += 1
    when /^--checkers-report=/
      opts.checkers_report = arg.split('=', 2)[1]
    when /^--plist-output=/
      opts.plist_output = arg.split('=', 2)[1]
    when /^--project=/
      files.concat(project_files(arg.split('=', 2)[1]))
    when '--project'
      files.concat(project_files(argv[i + 1]))
      i += 1
    when /^--/
      if known_ignored_option?(arg)
        i += 1 if option_takes_value_without_equal?(arg, argv[i + 1])
      else
        warn %(cppcheck: error: unrecognized command line option: "#{arg}".)
        exit 1
      end
    when /^-[jfIl]$/
      i += 1
    when /^-[A-Za-z]/
      # Accept common short options such as -f.
    else
      files << arg
    end
    i += 1
  end
  [opts, files]
end

def known_ignored_option?(arg)
  prefixes = %w[
    --addon --addon-python --cppcheck-build-dir --check-level --check-library
    --clang --config-exclude --config-excludes-file --exitcode-suppressions
    --force --fsigned-char --funsigned-char --includes-file --include
    --inconclusive --library --max-configs --max-ctu-depth --platform
    --project-configuration --relative-paths --report-progress --report-type
    --rule --rule-file --safety --showtime --std --template-location
    --suppress-xml --verbose --quiet --plist-output
  ]
  prefixes.any? { |p| arg == p || arg.start_with?("#{p}=") } || arg == '--debug'
end

def option_takes_value_without_equal?(arg, nxt)
  %w[--addon --addon-python --cppcheck-build-dir --check-level --clang --config-exclude
     --config-excludes-file --exitcode-suppressions --includes-file --include --library
     --max-configs --max-ctu-depth --platform --project-configuration --relative-paths
     --report-type --rule --rule-file --showtime --std --template-location --suppress-xml
     --plist-output].include?(arg) && nxt && !nxt.start_with?('-')
end

def read_list(path)
  data = path == '-' ? STDIN.read : File.read(path)
  data.lines.map(&:strip).reject { |l| l.empty? || l.start_with?('#') }
rescue Errno::ENOENT
  warn "cppcheck: error: could not open file #{path}"
  exit 1
end

def project_files(path)
  return [] unless path && File.file?(path)
  if File.basename(path) == 'compile_commands.json'
    File.read(path).scan(/"file"\s*:\s*"((?:\\"|[^"])*)"/).flatten.map { |f| f.gsub('\"', '"') }
  else
    [File.dirname(path)]
  end
rescue StandardError
  []
end

def gather_files(paths, opts)
  paths = ['.'] if paths.empty?
  out = []
  paths.each do |path|
    if File.directory?(path)
      Dir.glob(File.join(path, '**', '*'), File::FNM_DOTMATCH).sort.each do |f|
        next unless File.file?(f)
        out << f if SOURCE_EXTS.include?(File.extname(f).downcase)
      end
    elsif File.file?(path)
      out << path
    else
      warn "cppcheck: error: could not find or open any of the paths given."
      exit 1
    end
  end
  out = out.reject { |f| ignored?(f, opts.ignores) }
  out = out.select { |f| opts.file_filters.any? { |pat| File.fnmatch?(pat, f) || File.fnmatch?(pat, File.basename(f)) } } unless opts.file_filters.empty?
  out.uniq
end

def ignored?(file, patterns)
  patterns.any? { |pat| file.start_with?(pat) || File.fnmatch?(pat, file) || File.fnmatch?(pat, File.basename(file)) }
end

def preprocess_file(file, opts)
  active = [true]
  File.readlines(file, chomp: true).each do |line|
    stripped = line.strip
    if stripped =~ /^#\s*define\s+(\w+)(?:\s+(.*))?/
      opts.defines[Regexp.last_match(1)] = Regexp.last_match(2) || '1'
      next
    elsif stripped =~ /^#\s*undef\s+(\w+)/
      opts.defines.delete(Regexp.last_match(1))
      next
    elsif stripped =~ /^#\s*ifdef\s+(\w+)/
      active << (active[-1] && opts.defines.key?(Regexp.last_match(1)))
      next
    elsif stripped =~ /^#\s*ifndef\s+(\w+)/
      active << (active[-1] && !opts.defines.key?(Regexp.last_match(1)))
      next
    elsif stripped =~ /^#\s*if\s+(.+)/
      expr = Regexp.last_match(1)
      val = expr.gsub(/defined\s*\((\w+)\)/) { opts.defines.key?(Regexp.last_match(1)) ? '1' : '0' }
      active << (active[-1] && val !~ /\A\s*0\s*\z/)
      next
    elsif stripped =~ /^#\s*else/
      prev = active.pop
      active << (!prev && active[-1])
      next
    elsif stripped =~ /^#\s*endif/
      active.pop if active.length > 1
      next
    end
    puts line if active[-1]
  end
end

def strip_comments(line, state)
  s = line.dup
  if state[:block]
    if (idx = s.index('*/'))
      s = s[(idx + 2)..] || ''
      state[:block] = false
    else
      return ''
    end
  end
  loop do
    start = s.index('/*')
    break unless start
    fin = s.index('*/', start + 2)
    if fin
      s = s[0...start] + s[(fin + 2)..].to_s
    else
      s = s[0...start]
      state[:block] = true
      break
    end
  end
  s.sub(%r{//.*}, '')
end

def analyze_file(file, opts)
  diags = []
  arrays = {}
  mallocs = {}
  frees = {}
  vars = {}
  used = Hash.new(0)
  suppress_next = []
  state = { block: false }
  lines = File.readlines(file, chomp: true)
  lines.each_with_index do |raw, idx|
    line_no = idx + 1
    if opts.inline_suppr && raw =~ /cppcheck-suppress\s+([A-Za-z0-9_,*-]+)/
      suppress_next.concat(Regexp.last_match(1).split(','))
    end
    line = strip_comments(raw, state)
    code = line.strip
    next if code.empty?

    if code =~ /^#\s*include\s+[<"]([^>"]+)[>"]/
      inc = Regexp.last_match(1)
      if missing_include_enabled?(opts) && !include_exists?(inc, file, opts.includes)
        diags << diag(file, line_no, line.index('#').to_i + 1, 'information', 'missingInclude', "Include file: #{inc} not found.", '', raw)
      end
      next
    end

    code.scan(/\b(?:char|short|int|long|float|double|bool|size_t|unsigned|signed)(?:\s+\w+)*\s+(\w+)\s*\[\s*(-?\d+)\s*\]/) do |name, size|
      if size.to_i < 0
        diags << diag(file, line_no, 1, 'error', 'negativeArraySize', "Declaration of array '#{name}' with negative size is undefined behaviour", '758', raw)
      else
        arrays[name] = size.to_i
      end
    end

    code.to_enum(:scan, /\b(\w+)\s*\[\s*(-?\d+)\s*\]/).each do
      name = Regexp.last_match(1)
      index = Regexp.last_match(2)
      prefix = code[0...Regexp.last_match.begin(0)]
      next if prefix.split(';').last.to_s =~ /\b(?:char|short|int|long|float|double|bool|size_t|unsigned|signed)\b/
      next unless arrays.key?(name)
      n = index.to_i
      if n < 0
        diags << diag(file, line_no, code.index("#{name}[") + 1, 'error', 'negativeIndex', 'Negative array index', '786', raw)
      elsif n >= arrays[name]
        diags << diag(file, line_no, code.index("#{name}[") + 1, 'error', 'arrayIndexOutOfBounds', "Array '#{name}[#{arrays[name]}]' accessed at index #{n}, which is out of bounds.", '788', raw)
      end
    end

    if code =~ %r{/(?:\s*\(?\s*)0(?:\s*\)?)\b}
      diags << diag(file, line_no, code.index('/') + 1, 'error', 'zerodiv', 'Division by zero.', '369', raw)
    end
    if code =~ /\bmemset\s*\([^,]+,[^,]+,\s*0\s*\)/
      diags << diag(file, line_no, code.index('memset') + 1, 'warning', 'memsetZeroBytes', 'memset() called to fill 0 bytes.', '687', raw)
    end
    if code =~ /\bgets\s*\(/
      diags << diag(file, line_no, code.index('gets') + 1, 'warning', 'dangerousFunction', 'Obsolete function gets() called. It is recommended to use fgets() or gets_s() instead.', '242', raw)
    end

    code.scan(/\b(?:int|char|long|short|float|double|bool|size_t)\s+(\w+)\s*(?:;|,)/) { |m| vars[m[0]] = [line_no, raw, false] }
    code.scan(/\b(\w+)\b/) { |m| used[m[0]] += 1 }
    if code =~ /\b(\w+)\s*=\s*(?:malloc|calloc|realloc)\s*\(/
      mallocs[Regexp.last_match(1)] = [line_no, raw]
    end
    if code =~ /\bfree\s*\(\s*(\w+)\s*\)/
      name = Regexp.last_match(1)
      if frees[name]
        diags << diag(file, line_no, code.index('free') + 1, 'error', 'doubleFree', "Memory pointed to by #{name} is freed twice.", '415', raw)
      end
      frees[name] = true
      mallocs.delete(name)
    end
    if code =~ /\bdelete(?:\s*\[\])?\s+(\w+)/
      frees[Regexp.last_match(1)] = true
      mallocs.delete(Regexp.last_match(1))
    end
  end

  mallocs.each do |name, (line_no, raw)|
    diags << diag(file, line_no, 1, 'error', 'memleak', "Memory leak: #{name}", '401', raw)
  end
  if style_enabled?(opts)
    vars.each do |name, (line_no, raw, _)|
      next if used[name] > 1
      diags << diag(file, line_no, raw.index(name).to_i + 1, 'style', 'unusedVariable', "Variable #{name} is assigned a value that is never used.", '563', raw)
    end
  end
  diags = diags.reject { |d| suppressed?(d, opts.suppressions) }
  if opts.inline_suppr
    diags = diags.reject do |d|
      matched = suppress_next.any? { |s| s == '*' || s == d.id }
      suppress_next.clear if matched
      matched
    end
  end
  write_dump(file, lines) if opts.dump
  diags
rescue Errno::ENOENT, Errno::EACCES => e
  [diag(file, 0, 0, 'error', 'file', e.message, '', '')]
end

def diag(file, line, col, severity, id, message, cwe, code)
  Diagnostic.new(file: file, line: line, column: col, severity: severity, id: id, message: message, cwe: cwe, code: code)
end

def missing_include_enabled?(opts)
  opts.enabled.include?('all') || opts.enabled.include?('missingInclude')
end

def style_enabled?(opts)
  opts.enabled.include?('all') || opts.enabled.include?('style')
end

def include_exists?(inc, source, includes)
  dirs = [File.dirname(source)] + includes
  dirs.any? { |d| File.file?(File.join(d, inc)) }
end

def suppressed?(d, specs)
  specs.any? do |spec|
    id, file, line = spec.split(':', 3)
    (id.nil? || id.empty? || id == '*' || id == d.id) &&
      (file.nil? || file.empty? || File.fnmatch?(file, d.file) || File.basename(d.file) == file) &&
      (line.nil? || line.empty? || line.to_i == d.line)
  end
end

def write_dump(file, lines)
  File.write("#{file}.dump", "<dumps><dump cfg=\"\"><tokenlist size=\"#{lines.length}\"/></dump></dumps>\n")
end

def format_diag(d, template)
  case template
  when 'cppcheck1'
    "[#{d.file}:#{d.line}]: (#{d.severity}) #{d.message} [#{d.id}]"
  when 'vs'
    "#{d.file}(#{d.line}): #{d.severity}: #{d.message} [#{d.id}]"
  when 'edit'
    "#{d.file} +#{d.line}: #{d.message}"
  when 'gcc', nil, ''
    "#{d.file}:#{d.line}:#{d.column}: #{d.severity}: #{d.message} [#{d.id}]"
  else
    template.gsub('\t', "\t").gsub('\n', "\n").gsub('\r', "\r")
            .gsub('{file}', d.file).gsub('{line}', d.line.to_s).gsub('{column}', d.column.to_s)
            .gsub('{severity}', d.severity).gsub('{message}', d.message).gsub('{id}', d.id)
            .gsub('{cwe}', d.cwe.to_s).gsub('{code}', d.code.to_s).gsub('{callstack}', "[#{d.file}:#{d.line}]")
            .gsub(/\{inconclusive:([^}]*)\}/, '')
  end
end

def xml_errors(diags)
  out = +"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<results version=\"2\">\n    <cppcheck version=\"2.19 dev\"/>\n    <errors>\n"
  diags.each do |d|
    attrs = %(id="#{h(d.id)}" severity="#{h(d.severity)}" msg="#{h(d.message)}" verbose="#{h(d.message)}")
    attrs += %( cwe="#{h(d.cwe)}") unless d.cwe.to_s.empty?
    out << "        <error #{attrs}>\n"
    out << %(            <location file="#{h(d.file)}" line="#{d.line}" column="#{d.column}"/>\n)
    out << "        </error>\n"
  end
  out << "    </errors>\n</results>\n"
end

def sarif(diags)
  results = diags.map do |d|
    <<~JSON.chomp
      {
            "ruleId": "#{json_escape(d.id)}",
            "level": "#{d.severity == 'error' ? 'error' : 'warning'}",
            "message": { "text": "#{json_escape(d.message)}" },
            "locations": [
              { "physicalLocation": { "artifactLocation": { "uri": "#{json_escape(d.file)}" }, "region": { "startLine": #{d.line}, "startColumn": #{d.column} } } }
            ]
          }
    JSON
  end
  <<~JSON
    {
      "version": "2.1.0",
      "runs": [
        {
          "tool": { "driver": { "name": "Cppcheck", "version": "2.19 dev" } },
          "results": [
          #{results.join(",\n        ")}
          ]
        }
      ]
    }
  JSON
end

def json_escape(s)
  s.to_s.gsub('\\', '\\\\\\').gsub('"', '\"').gsub("\n", '\\n').gsub("\r", '\\r').gsub("\t", '\\t')
end

def h(s)
  CGI.escapeHTML(s.to_s).gsub('&#39;', '&apos;')
end

def print_errorlist
  puts %(<?xml version="1.0" encoding="UTF-8"?>)
  puts %(<results version="2">)
  puts %(    <cppcheck version="2.19 dev"/>)
  print %(    <errors>)
  ERROR_CATALOG.each do |id, sev, msg, cwe|
    attrs = %(id="#{h(id)}" severity="#{h(sev)}" msg="#{h(msg)}" verbose="#{h(msg)}")
    attrs += %( cwe="#{h(cwe)}") unless cwe.empty?
    puts %(        <error #{attrs}/>)
  end
  puts %(    </errors>)
  puts %(</results>)
end

if ARGV.empty?
  puts HELP
  exit 0
end

opts, paths = parse_args(ARGV)
files = gather_files(paths, opts)
if files.empty?
  warn 'cppcheck: error: no C or C++ source files found.'
  exit 1
end

if opts.preprocess
  files.each { |f| preprocess_file(f, opts) }
  exit 0
end

all = []
files.each_with_index do |f, idx|
  puts "Checking #{f}..." unless opts.quiet || opts.xml || opts.format == 'sarif'
  all.concat(analyze_file(f, opts))
  unless opts.quiet || opts.xml || opts.format == 'sarif' || files.length == 1
    pct = (((idx + 1).to_f / files.length) * 100).round
    puts "#{idx + 1}/#{files.length} files checked #{pct}% done"
  end
end

if opts.checkers_report
  File.write(opts.checkers_report, ERROR_CATALOG.map { |id, sev, msg, _| "#{id}: #{sev}: #{msg}" }.join("\n") + "\n")
end
if opts.plist_output
  FileUtils.mkdir_p(opts.plist_output)
  File.write(File.join(opts.plist_output, 'cppcheck.plist'), "<?xml version=\"1.0\"?><plist version=\"1.0\"><dict/></plist>\n")
end

payload = if opts.format == 'sarif'
            sarif(all)
          elsif opts.xml || opts.format.start_with?('xml')
            xml_errors(all)
          else
            all.map { |d| format_diag(d, opts.template) }.join("\n") + (all.empty? ? '' : "\n")
          end

if opts.output_file
  File.write(opts.output_file, payload)
elsif opts.xml
  warn payload
else
  $stderr.write(payload)
end

exit(all.any? { |d| d.severity == 'error' } && opts.error_exitcode ? opts.error_exitcode : 0)
