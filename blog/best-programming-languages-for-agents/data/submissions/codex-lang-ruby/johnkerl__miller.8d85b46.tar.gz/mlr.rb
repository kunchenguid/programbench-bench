#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = 'mlr 6.16.0'
VERBS = %w[
  altkv bar bootstrap case cat check clean-whitespace count-distinct count
  count-similar cut decimate fill-down fill-empty filter flatten format-values
  fraction gap grep group-by group-like gsub having-fields head histogram
  json-parse json-stringify join label latin1-to-utf8 least-frequent
  merge-fields most-frequent nest nothing put regularize remove-empty-columns
  rename reorder repeat reshape sample sec2gmtdate sec2gmt seqgen shuffle
  skip-trivial-records sort sort-within-records sparsify split ssub stats1
  stats2 step sub summary surv tac tail tee template top utf8-to-latin1
  unflatten uniq unspace unsparsify
].freeze

class MLR
  def initialize(argv)
    @argv = argv.dup
    @iformat = 'dkvp'
    @oformat = 'dkvp'
    @irs = "\n"
    @ofs = ','
    @headerless_in = false
    @headerless_out = false
    @quote_all = false
    @from = nil
    @gen_field = 'i'
    @gen_start = 1
    @gen_stop = 100
    @gen_step = 1
  end

  def run
    if @argv.empty? || @argv == ['--help'] || @argv == ['-h']
      puts usage
      return 0
    end
    return help if @argv[0] == 'help'
    return puts(VERSION) || 0 if @argv[0] == '--version'
    return puts(VERBS.join("\n")) || 0 if @argv[0] == '-l'
    return help_flags if @argv[0] == '-g'

    verbs, files = parse_cli
    records = read_records(files)
    verbs.each { |verb| records = apply_verb(records, verb) }
    write_records(records)
    0
  rescue Errno::ENOENT => e
    warn "mlr: #{e.message}"
    1
  rescue => e
    warn "mlr: #{e.message}"
    1
  end

  def usage
    "Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}\n\n" \
      "If zero file names are provided, standard input is read, e.g.\n" \
      "  mlr --csv sort -f shape example.csv\n\n" \
      "Output of one verb may be chained as input to another using \"then\", e.g.\n" \
      "  mlr --csv stats1 -a min,mean,max -f quantity then sort -f color example.csv\n\n" \
      "Please see 'mlr help topics' for more information.\n" \
      "Please also see https://miller.readthedocs.io"
  end

  def help
    topic = @argv[1]
    case topic
    when nil, 'topics'
      puts "Type 'mlr help {topic}' for any of the following:"
      puts "Essentials:\n  mlr help topics\n  mlr help basic-examples\n  mlr help file-formats"
      puts "Flags:\n  mlr help flags"
      puts "Verbs:\n  mlr help list-verbs\n  mlr help usage-verbs"
    when 'basic-examples'
      puts "mlr --icsv --opprint cat example.csv"
      puts "mlr --icsv --opprint sort -f shape example.csv"
      puts "mlr --icsv --opprint sort -f shape -nr index example.csv"
      puts "mlr --icsv --opprint cut -f flag,shape example.csv"
      puts "mlr --csv filter '$color == \"red\"' example.csv"
      puts "mlr --icsv --ojson put '$ratio = $quantity / $rate' example.csv"
      puts "mlr --icsv --opprint --from example.csv sort -nr index then cut -f shape,quantity"
    when 'list-verbs'
      puts VERBS.join("\n")
    when 'flags', 'flag'
      help_flags
    when 'usage-verbs', 'verb'
      puts VERBS.map { |v| "================================================================\n#{v}\nUsage: mlr #{v} [options]" }.join("\n")
    else
      if VERBS.include?(topic)
        puts "Usage: mlr #{topic} [options]"
      else
        puts "No help found for \"#{topic}\". Please try 'mlr help find #{topic}' for approximate match."
        puts "See also 'mlr help topics'."
      end
    end
    0
  end

  def help_flags
    puts <<~TXT
      FILE-FORMAT FLAGS

      --csv or -c or --c2c     Use CSV format for input and output data.
      --icsv                   Use CSV format for input data.
      --ocsv                   Use CSV format for output data.
      --tsv                    Use TSV format for input and output data.
      --json or -j or --j2j    Use JSON format for input and output data.
      --jsonl or --l2l         Use JSON Lines format for input and output data.
      --nidx or --n2n          Use NIDX format for input and output data.
      --dkvp or --d2d          Use DKVP format for input and output data.
      --opprint                Use PPRINT format for output data.
      --from {filename}        Read from filename.
    TXT
    0
  end

  def parse_cli
    verbs = []
    cur = nil
    files = []
    until @argv.empty?
      a = @argv.shift
      if global_flag(a)
        next
      elsif a == 'then'
        verbs << cur if cur
        cur = nil
      elsif VERBS.include?(a)
        verbs << cur if cur
        cur = { name: a, args: [] }
      elsif cur
        cur[:args] << a
      else
        files << a
      end
    end
    verbs << cur if cur
    files.unshift(@from) if @from
    verbs = [{ name: 'cat', args: [] }] if verbs.empty?
    verbs.each do |v|
      kept = []
      v[:args].each do |x|
        if File.exist?(x)
          files << x
        else
          kept << x
        end
      end
      v[:args] = kept
    end
    [verbs, files]
  end

  def global_flag(a)
    case a
    when '--csv', '-c', '--c2c' then @iformat = @oformat = 'csv'
    when '--tsv', '--t2t' then @iformat = @oformat = 'tsv'
    when '--dkvp', '--d2d' then @iformat = @oformat = 'dkvp'
    when '--json', '-j', '--j2j' then @iformat = @oformat = 'json'
    when '--jsonl', '--l2l' then @iformat = @oformat = 'jsonl'
    when '--nidx', '--n2n' then @iformat = @oformat = 'nidx'
    when '--pprint', '--p2p' then @iformat = @oformat = 'pprint'
    when '--icsv' then @iformat = 'csv'
    when '--itsv' then @iformat = 'tsv'
    when '--idkvp' then @iformat = 'dkvp'
    when '--ijson' then @iformat = 'json'
    when '--ijsonl' then @iformat = 'jsonl'
    when '--inidx' then @iformat = 'nidx'
    when '--ipprint' then @iformat = 'pprint'
    when '--ocsv' then @oformat = 'csv'
    when '--otsv' then @oformat = 'tsv'
    when '--odkvp' then @oformat = 'dkvp'
    when '--ojson' then @oformat = 'json'
    when '--ojsonl' then @oformat = 'jsonl'
    when '--onidx' then @oformat = 'nidx'
    when '--opprint' then @oformat = 'pprint'
    when '--oxtab' then @oformat = 'xtab'
    when '--igen' then @iformat = 'gen'
    when '--gen-field-name' then @gen_field = @argv.shift
    when '--gen-start' then @gen_start = @argv.shift.to_i
    when '--gen-stop' then @gen_stop = @argv.shift.to_i
    when '--gen-step' then @gen_step = @argv.shift.to_i
    when '--from' then @from = @argv.shift
    when '--hi', '--implicit-csv-header', '--headerless-csv-input', '-N' then @headerless_in = true
    when '--ho', '--headerless-csv-output' then @headerless_out = true
    when '--quote-all' then @quote_all = true
    when '--fs', '--ifs', '--ofs'
      @ofs = @argv.shift
    else
      return false
    end
    true
  end

  def read_records(files)
    return gen_records if @iformat == 'gen'
    text = +''
    if files.empty?
      text = STDIN.read
    else
      files.each { |f| text << File.read(f) }
    end
    case @iformat
    when 'csv' then parse_csv(text, ',')
    when 'tsv' then parse_csv(text, "\t")
    when 'json' then parse_json(text)
    when 'jsonl' then text.lines.reject { |l| l.strip.empty? }.map { |l| object_to_record(JsonLite.parse(l)) }
    when 'nidx' then text.lines.reject { |l| l.chomp.empty? }.map { |l| Hash[l.chomp.split(/\s+/).each_with_index.map { |v, i| [(i + 1).to_s, infer(v)] }] }
    when 'pprint' then parse_pprint(text)
    else parse_dkvp(text)
    end
  end

  def gen_records
    out = []
    i = @gen_start
    if @gen_step >= 0
      while i <= @gen_stop
        out << { @gen_field => i }
        break if @gen_step == 0
        i += @gen_step
      end
    else
      while i >= @gen_stop
        out << { @gen_field => i }
        i += @gen_step
      end
    end
    out
  end

  def parse_csv(text, sep)
    rows = parse_delimited(text, sep)
    return [] if rows.empty?
    if @headerless_in
      rows.map { |r| Hash[r.each_with_index.map { |v, i| [(i + 1).to_s, infer(v)] }] }
    else
      header = rows.shift.map(&:to_s)
      rows.map { |r| Hash[header.each_with_index.map { |h, i| [h, infer(r[i] || '')] }] }
    end
  end

  def parse_delimited(text, sep)
    rows = []
    row = []
    field = +''
    inq = false
    i = 0
    while i < text.length
      c = text[i]
      if inq
        if c == '"'
          if text[i + 1] == '"'
            field << '"'
            i += 1
          else
            inq = false
          end
        else
          field << c
        end
      else
        if c == '"'
          inq = true
        elsif c == sep
          row << field
          field = +''
        elsif c == "\n"
          row << field
          rows << row
          row = []
          field = +''
        elsif c == "\r"
          # ignore CR in CRLF
        else
          field << c
        end
      end
      i += 1
    end
    unless field.empty? && row.empty?
      row << field
      rows << row
    end
    rows
  end

  def parse_pprint(text)
    lines = text.lines.map(&:chomp).reject(&:empty?)
    return [] if lines.empty?
    header = lines.shift.split(/\s+/)
    lines.map { |l| vals = l.split(/\s+/); Hash[header.each_with_index.map { |h, i| [h, infer(vals[i] || '')] }] }
  end

  def parse_dkvp(text)
    text.lines.reject { |l| l.chomp.empty? }.map do |line|
      rec = {}
      line.chomp.split(',').each_with_index do |pair, i|
        if pair.include?('=')
          k, v = pair.split('=', 2)
          rec[k] = infer(v)
        else
          rec[(i + 1).to_s] = infer(pair)
        end
      end
      rec
    end
  end

  def parse_json(text)
    data = JsonLite.parse(text)
    arr = data.is_a?(Array) ? data : [data]
    arr.map { |x| object_to_record(x) }
  end

  def object_to_record(obj, prefix = nil, out = {})
    if obj.is_a?(Hash)
      obj.each do |k, v|
        key = prefix ? "#{prefix}.#{k}" : k.to_s
        if v.is_a?(Hash)
          object_to_record(v, key, out)
        else
          out[key] = v
        end
      end
      out
    else
      { 'value' => obj }
    end
  end

  def infer(v)
    return '' if v.nil?
    s = v.to_s
    return true if s == 'true'
    return false if s == 'false'
    return s.to_i if s.match?(/\A[-+]?\d+\z/)
    return s.to_f if s.match?(/\A[-+]?(?:\d+\.\d*|\.\d+|\d+e[-+]?\d+|\d+\.\d*e[-+]?\d+)\z/i)
    s
  end

  def apply_verb(records, verb)
    args = verb[:args].dup
    case verb[:name]
    when 'cat' then verb_cat(records, args)
    when 'cut' then verb_cut(records, args)
    when 'sort' then verb_sort(records, args)
    when 'filter' then verb_filter(records, args)
    when 'put' then verb_put(records, args)
    when 'stats1' then verb_stats1(records, args)
    when 'count' then verb_count(records, args)
    when 'count-distinct', 'uniq' then verb_uniq(records, args)
    when 'head' then records.first(option(args, '-n', '10').to_i)
    when 'tail' then records.last(option(args, '-n', '10').to_i) || []
    when 'tac' then records.reverse
    when 'seqgen' then verb_seqgen(args)
    when 'nothing' then []
    when 'label' then verb_label(records, args)
    when 'rename' then verb_rename(records, args)
    when 'grep' then verb_grep(records, args)
    when 'group-by' then verb_cut(records, ['-f', option(args, '-g', option(args, '-f', ''))])
    when 'group-like' then records
    when 'fill-empty' then verb_fill_empty(records, args)
    when 'clean-whitespace' then verb_clean_ws(records, args)
    else records
    end
  end

  def verb_seqgen(args)
    field = option(args, '-f', option(args, '--field-name', 'i'))
    start = option(args, '--start', option(args, '-s', '1')).to_i
    stop = option(args, '--stop', option(args, '-e', '100')).to_i
    step = option(args, '--step', option(args, '-S', '1')).to_i
    old = [@gen_field, @gen_start, @gen_stop, @gen_step]
    @gen_field, @gen_start, @gen_stop, @gen_step = field, start, stop, step
    gen_records
  ensure
    @gen_field, @gen_start, @gen_stop, @gen_step = old if old
  end

  def option(args, flag, default = nil)
    i = args.index(flag)
    i ? args[i + 1] : default
  end

  def fields_arg(args, flag = '-f')
    s = option(args, flag, '')
    s.to_s.split(',').reject(&:empty?)
  end

  def verb_cat(records, args)
    counter_name = nil
    counter_name = 'n' if args.include?('-n')
    if (i = args.index('-N'))
      counter_name = args[i + 1]
    end
    return records unless counter_name
    records.each_with_index.map { |r, i| { counter_name => i + 1 }.merge(r) }
  end

  def verb_cut(records, args)
    fields = fields_arg(args)
    complement = args.include?('-x') || args.include?('--complement')
    ordered = args.include?('-o')
    records.map do |r|
      keys = if complement
               r.keys - fields
             elsif ordered
               fields.select { |f| r.key?(f) }
             else
               r.keys.select { |k| fields.include?(k) }
             end
      Hash[keys.map { |k| [k, r[k]] }]
    end
  end

  def verb_sort(records, args)
    specs = []
    mode = :lex
    rev = false
    i = 0
    while i < args.length
      case args[i]
      when '-f' then mode = :lex; rev = false; specs += args[i + 1].split(','); i += 1
      when '-r' then mode = :lex; rev = true; specs += args[i + 1].split(','); i += 1
      when '-n' then mode = :num; rev = false; specs += args[i + 1].split(','); i += 1
      when '-nr', '-rn' then mode = :num; rev = true; specs += args[i + 1].split(','); i += 1
      end
      i += 1
    end
    specs = [records.first&.keys&.first].compact if specs.empty?
    records.sort_by do |r|
      specs.map { |f| mode == :num ? r[f].to_f : r[f].to_s }
    end.tap { |a| a.reverse! if rev }
  end

  def verb_filter(records, args)
    invert = args.delete('-x')
    expr = args.reject { |a| a.start_with?('-') }.join(' ')
    records.select do |r|
      ok = eval_expr(expr, r)
      invert ? !ok : ok
    end
  end

  def verb_put(records, args)
    expr = args.reject { |a| a.start_with?('-') }.join(' ')
    records.map do |r|
      nr = r.dup
      expr.split(';').each do |stmt|
        if stmt =~ /\A\s*\$?([A-Za-z_][\w.]*)\s*=\s*(.+)\z/
          nr[$1] = eval_value($2, nr)
        end
      end
      nr
    end
  end

  def eval_expr(expr, r)
    e = expr.strip
    return true if e.empty?
    e = e.gsub(/\btrue\b/, 'true').gsub(/\bfalse\b/, 'false')
    e = e.gsub(/\$([A-Za-z_][\w.]*)/) { value_literal(r[$1]) }
    e = e.gsub('&&', ' and ').gsub('||', ' or ')
    e = e.gsub(/(?<![!<>=])=(?!=)/, '==')
    !!Kernel.eval(e)
  rescue Exception
    false
  end

  def eval_value(expr, r)
    e = expr.strip
    e = e.gsub(/\$([A-Za-z_][\w.]*)/) { value_literal(r[$1]) }
    e = e.gsub(/\s+\.\s+/, ' + ')
    infer(Kernel.eval(e).to_s)
  rescue Exception
    infer(expr.gsub(/\$([A-Za-z_][\w.]*)/) { r[$1].to_s })
  end

  def value_literal(v)
    case v
    when Numeric then v.to_s
    when true then 'true'
    when false then 'false'
    when nil then 'nil'
    else v.to_s.inspect
    end
  end

  def verb_stats1(records, args)
    stats = fields_arg(args, '-a')
    fields = fields_arg(args, '-f')
    out = {}
    fields.each do |f|
      vals = records.map { |r| r[f] }.compact
      nums = vals.map(&:to_f)
      stats.each do |s|
        out["#{f}_#{s}"] = case s
                           when 'count' then vals.length
                           when 'sum' then pretty_num(nums.sum)
                           when 'mean' then pretty_num(nums.empty? ? 0 : nums.sum / nums.length)
                           when 'min' then pretty_num(nums.min || 0)
                           when 'max' then pretty_num(nums.max || 0)
                           else pretty_num(nums.sum)
                           end
      end
    end
    [out]
  end

  def verb_count(records, args)
    groups = fields_arg(args, '-g')
    oname = option(args, '-o', 'count')
    return [{ oname => records.length }] if groups.empty?
    h = Hash.new(0)
    exemplars = {}
    records.each do |r|
      key = groups.map { |g| r[g] }
      h[key] += 1
      exemplars[key] ||= Hash[groups.map { |g| [g, r[g]] }]
    end
    h.map { |k, c| exemplars[k].merge(oname => c) }
  end

  def verb_uniq(records, args)
    count = args.include?('-c') || args.include?('--count')
    fields = fields_arg(args)
    seen = {}
    records.each do |r|
      key_fields = fields.empty? ? r.keys : fields
      key = key_fields.map { |f| [f, r[f]] }
      seen[key] ||= [Hash[key], 0]
      seen[key][1] += 1
    end
    seen.values.map { |rec, c| count ? { 'count' => c }.merge(rec) : rec }
  end

  def verb_label(records, args)
    labels = args.join(',').split(',').reject(&:empty?)
    records.map { |r| Hash[r.values.each_with_index.map { |v, i| [labels[i] || (i + 1).to_s, v] }] }
  end

  def verb_rename(records, args)
    pairs = args.join(',').split(',').map { |p| p.split(',', 2) }
    mapping = {}
    args.join(',').split(',').each_slice(2) { |a, b| mapping[a] = b if b }
    records.map { |r| Hash[r.map { |k, v| [mapping[k] || k, v] }] }
  end

  def verb_grep(records, args)
    pat = args.last || ''
    re = Regexp.new(pat)
    records.select { |r| r.any? { |k, v| k.match?(re) || v.to_s.match?(re) } }
  end

  def verb_fill_empty(records, args)
    fill = option(args, '-v', 'N/A')
    records.map { |r| Hash[r.map { |k, v| [k, v == '' ? fill : v] }] }
  end

  def verb_clean_ws(records, args)
    records.map do |r|
      Hash[r.map { |k, v| [k.to_s.strip.gsub(/\s+/, ' '), v.is_a?(String) ? v.strip.gsub(/\s+/, ' ') : v] }]
    end
  end

  def pretty_num(x)
    x == x.to_i ? x.to_i : x
  end

  def write_records(records)
    case @oformat
    when 'csv' then write_csv(records, ',')
    when 'tsv' then write_csv(records, "\t")
    when 'json' then write_json(records)
    when 'jsonl' then records.each { |r| puts json_object(r) }
    when 'nidx' then records.each { |r| puts r.values.map(&:to_s).join(' ') }
    when 'pprint' then write_pprint(records)
    when 'xtab' then write_xtab(records)
    else records.each { |r| puts r.map { |k, v| "#{k}=#{format_value(v)}" }.join(',') }
    end
  end

  def all_keys(records)
    keys = []
    records.each { |r| r.keys.each { |k| keys << k unless keys.include?(k) } }
    keys
  end

  def write_csv(records, sep)
    return if records.empty?
    keys = all_keys(records)
    puts csv_line(keys, sep) unless @headerless_out
    records.each { |r| puts csv_line(keys.map { |k| format_value(r[k]) }, sep) }
  end

  def csv_line(values, sep)
    values.map do |v|
      s = v.to_s
      if @quote_all || s.include?(sep) || s.include?('"') || s.include?("\n") || s.include?("\r")
        '"' + s.gsub('"', '""') + '"'
      else
        s
      end
    end.join(sep)
  end

  def write_json(records)
    puts '['
    records.each_with_index do |r, idx|
      puts '{'
      r.each_with_index do |(k, v), j|
        comma = j == r.length - 1 ? '' : ','
        puts "  #{json_string(k)}: #{json_value(v)}#{comma}"
      end
      puts idx == records.length - 1 ? '}' : '},'
    end
    puts ']'
  end

  def write_pprint(records)
    return if records.empty?
    keys = all_keys(records)
    widths = keys.map { |k| [k.length, records.map { |r| format_value(r[k]).length }.max || 0].max }
    puts keys.each_with_index.map { |k, i| k.ljust(widths[i]) }.join(' ').rstrip
    records.each do |r|
      puts keys.each_with_index.map { |k, i| format_value(r[k]).ljust(widths[i]) }.join(' ').rstrip
    end
  end

  def write_xtab(records)
    records.each_with_index do |r, idx|
      puts if idx.positive?
      w = r.keys.map(&:length).max || 0
      r.each { |k, v| puts "#{k.ljust(w)} #{format_value(v)}" }
    end
  end

  def format_value(v)
    case v
    when nil then ''
    when true then 'true'
    when false then 'false'
    else v.to_s
    end
  end

  def json_object(r)
    '{' + r.map { |k, v| "#{json_string(k)}: #{json_value(v)}" }.join(', ') + '}'
  end

  def json_value(v)
    case v
    when String then json_string(v)
    when Numeric then v.to_s
    when true then 'true'
    when false then 'false'
    when nil then 'null'
    when Hash then json_object(v)
    when Array then '[' + v.map { |e| json_value(e) }.join(', ') + ']'
    else json_string(v.to_s)
    end
  end

  def json_string(s)
    '"' + s.to_s.gsub('\\', '\\\\\\').gsub('"', '\"').gsub("\n", '\n').gsub("\r", '\r').gsub("\t", '\t') + '"'
  end
end

class JsonLite
  def self.parse(text)
    new(text).parse
  end

  def initialize(text)
    @s = text
    @i = 0
  end

  def parse
    skip
    parse_value
  end

  def parse_value
    skip
    case @s[@i]
    when '{' then parse_object
    when '[' then parse_array
    when '"' then parse_string
    when 't' then @i += 4; true
    when 'f' then @i += 5; false
    when 'n' then @i += 4; nil
    else parse_number
    end
  end

  def parse_object
    @i += 1
    h = {}
    skip
    if @s[@i] == '}'
      @i += 1
      return h
    end
    loop do
      skip
      k = parse_string
      skip
      @i += 1 if @s[@i] == ':'
      h[k] = parse_value
      skip
      if @s[@i] == '}'
        @i += 1
        break
      end
      @i += 1 if @s[@i] == ','
    end
    h
  end

  def parse_array
    @i += 1
    a = []
    skip
    if @s[@i] == ']'
      @i += 1
      return a
    end
    loop do
      a << parse_value
      skip
      if @s[@i] == ']'
        @i += 1
        break
      end
      @i += 1 if @s[@i] == ','
    end
    a
  end

  def parse_string
    @i += 1
    out = +''
    while @i < @s.length
      c = @s[@i]
      if c == '"'
        @i += 1
        break
      elsif c == '\\'
        @i += 1
        esc = @s[@i]
        out << case esc
               when 'n' then "\n"
               when 'r' then "\r"
               when 't' then "\t"
               when '"', '\\', '/' then esc
               else esc
               end
      else
        out << c
      end
      @i += 1
    end
    out
  end

  def parse_number
    j = @i
    @i += 1 while @i < @s.length && @s[@i].match?(/[0-9eE+\-.]/)
    str = @s[j...@i]
    str.include?('.') || str.match?(/[eE]/) ? str.to_f : str.to_i
  end

  def skip
    @i += 1 while @i < @s.length && @s[@i].match?(/\s/)
  end
end

exit MLR.new(ARGV).run
