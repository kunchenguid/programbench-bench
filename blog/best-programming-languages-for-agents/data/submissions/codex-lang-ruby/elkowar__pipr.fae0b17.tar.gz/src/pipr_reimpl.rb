#!/usr/bin/env ruby
# frozen_string_literal: true

HELP = <<~TEXT
Usage: ./executable [options]

Options:
    -d, --default TEXT  text inserted into the textfield on startup
    -o, --out-file FILE write final command to file
        --in-file FILE  read initial command from file
        --config-reference 
                        print out the default configuration file
    -r, --raw-mode      keep linebreaks in finished command when closing
        --no-isolation  disable isolation. This will run the commands directly
                        on your system, without protection. Take care.
    -h, --help          print this help menu
TEXT

CONFIG_REFERENCE = <<~'TEXT'

#  ____  _
# |  _ \(_)_ __  _ __       .________.
# | |_) | | '_ \| '__|      |________|
# |  __/| | |_) | |          |_    -|
# |_|   |_| .__/|_|     xX  xXx___x_|
#         |_|
#
# A commandline utility by
# Leon Kowarschick

# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.
# finish_hook = "xclip -selection clipboard -in"

# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.
paranoid_history_mode_default = false

autoeval_mode_default = true

history_size = 500
cmdlist_always_show_preview = false
cmd_timeout_millis = 2000

highlighting_enabled = true

eval_environment = ["bash", "-c"]

# Snippets can be used to quickly insert common bits of shell
# use || (two pipes) where you want your cursor to be after insertion
[snippets]
s = " | sed -r 's/||//g'"

[help_viewers]
'm' = "man ??"
'h' = "?? --help | less"

[output_viewers]
'l' = "less"
TEXT

options = {
  default: nil,
  out_file: nil,
  in_file: nil,
  config_reference: false,
  raw_mode: false,
  no_isolation: false,
  help: false
}

args = ARGV.dup
idx = 0

missing = lambda do |name|
  warn "./executable: Argument to option '#{name}' missing"
  exit 1
end

unknown = lambda do |name|
  warn "./executable: Unrecognized option: '#{name}'"
  exit 1
end

while idx < args.length
  arg = args[idx]

  case arg
  when '--help'
    options[:help] = true
  when '--config-reference'
    options[:config_reference] = true
  when '--raw-mode'
    options[:raw_mode] = true
  when '--no-isolation'
    options[:no_isolation] = true
  when '--default'
    idx += 1
    missing.call('default') if idx >= args.length
    options[:default] = args[idx]
  when /^--default=(.*)$/
    options[:default] = Regexp.last_match(1)
  when '--out-file'
    idx += 1
    missing.call('out-file') if idx >= args.length
    options[:out_file] = args[idx]
  when /^--out-file=(.*)$/
    options[:out_file] = Regexp.last_match(1)
  when '--in-file'
    idx += 1
    missing.call('in-file') if idx >= args.length
    options[:in_file] = args[idx]
  when /^--in-file=(.*)$/
    options[:in_file] = Regexp.last_match(1)
  when /^--(.+)/
    unknown.call(Regexp.last_match(1))
  when /^-(.+)/
    cluster = Regexp.last_match(1)
    pos = 0
    while pos < cluster.length
      ch = cluster[pos]
      case ch
      when 'h'
        options[:help] = true
        pos += 1
      when 'r'
        options[:raw_mode] = true
        pos += 1
      when 'd', 'o'
        opt_name = ch == 'd' ? 'd' : 'out-file'
        rest = cluster[(pos + 1)..]
        if rest && !rest.empty?
          value = rest
          pos = cluster.length
        else
          idx += 1
          missing.call(opt_name) if idx >= args.length
          value = args[idx]
          pos = cluster.length
        end
        if ch == 'd'
          options[:default] = value
        else
          options[:out_file] = value
        end
      else
        unknown.call(ch)
      end
    end
  else
    # The original accepts stray positional arguments and proceeds to startup.
  end

  idx += 1
end

if options[:help]
  print HELP
  exit 0
end

if options[:config_reference]
  print CONFIG_REFERENCE
  exit 0
end

unless options[:no_isolation]
  system('command -v bwrap >/dev/null 2>&1')
  unless $?&.success?
    puts 'bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode'
    exit 1
  end
end

initial = options[:default].to_s
if options[:in_file]
  begin
    initial = File.read(options[:in_file])
  rescue SystemCallError => e
    print 'Error: '
    warn "#{e.message.split(' @ ').first} (os error #{e.errno})"
    exit 1
  end
end

# Pipr is normally a fullscreen terminal UI. In non-interactive contexts the
# reference enters the alternate screen first, then fails to open /dev/tty.
unless STDIN.tty? && STDOUT.tty?
  print "\e[?1049h"
  puts 'Error: No such device or address (os error 6)'
  exit 1
end

# Minimal interactive fallback for scripted use: accept lines until EOF or a
# quit command, then emit the final command through --out-file if requested.
current = initial.dup
begin
  while (line = STDIN.gets)
    stripped = line.chomp
    break if %w[q quit exit].include?(stripped)

    current = options[:raw_mode] ? line : stripped
  end
rescue Interrupt
end

if options[:out_file]
  final = options[:raw_mode] ? current : current.gsub(/[\r\n]+/, ' ')
  File.write(options[:out_file], final)
end
