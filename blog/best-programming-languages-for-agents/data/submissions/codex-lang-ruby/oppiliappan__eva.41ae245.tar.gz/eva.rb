#!/usr/bin/env ruby

class EvaError < StandardError
  attr_reader :kind
  def initialize(kind, message)
    @kind = kind
    super(message)
  end
end

Token = Struct.new(:type, :value)

class Calculator
  FUNCS1 = %w[sin cos tan csc sec cot sinh cosh tanh asin acos atan acsc asec acot ln log2 log10 sqrt ceil floor abs].freeze
  FUNCS2 = %w[log nroot].freeze
  CONSTANTS = { 'pi' => Math::PI, 'e' => Math::E }.freeze

  def initialize(fix: 10, base: 10, angle: 'degree')
    @fix = fix
    @base = base
    @angle = angle
    @last = read_previous
  end

  def eval_line(input)
    return nil if input.nil? || input.strip.empty?
    tokens = tokenize(input)
    tokens = balance(tokens)
    tokens = insert_implicit_mul(tokens)
    value = parse_expression(tokens)
    @last = value
    value
  end

  def format(value)
    if @base == 10
      s = sprintf("%.#{@fix}f", normalize_zero(value))
      int, frac = s.split('.', 2)
      sign = ''
      if int.start_with?('-')
        sign = '-'
        int = int[1..]
      end
      sign + comma(int) + '.' + frac
    else
      format_base(value)
    end
  end

  private

  def normalize_zero(v)
    v.abs < 0.5 * (10 ** -@fix) ? 0.0 : v
  end

  def comma(int)
    int.reverse.gsub(/(\d{3})(?=\d)/, '\\1,').reverse
  end

  def tokenize(s)
    out = []
    i = 0
    while i < s.length
      c = s[i]
      if c =~ /\s/
        i += 1
      elsif c =~ /[0-9.]/
        j = i
        dot = false
        while j < s.length && s[j] =~ /[0-9.]/
          if s[j] == '.'
            break if dot
            dot = true
          end
          j += 1
        end
        num = s[i...j]
        raise EvaError.new('Syntax Error', 'Invalid number') if num == '.'
        out << Token.new(:num, num.to_f)
        i = j
      elsif c =~ /[A-Za-z_]/
        j = i
        j += 1 while j < s.length && s[j] =~ /[A-Za-z0-9_]/
        name = s[i...j]
        if !(FUNCS1.include?(name) || FUNCS2.include?(name) || CONSTANTS.key?(name) || name == '_') && name =~ /\A([A-Za-z_]+)(\d+(?:\.\d+)?)\z/
          out << Token.new(:ident, Regexp.last_match(1))
          out << Token.new(:num, Regexp.last_match(2).to_f)
        else
          out << Token.new(:ident, name)
        end
        i = j
      elsif c == '*' && s[i + 1] == '*'
        out << Token.new(:op, '^')
        i += 2
      elsif '+-*/^(),'.include?(c)
        out << Token.new(c == ',' ? :comma : c == '(' ? :lpar : c == ')' ? :rpar : :op, c)
        i += 1
      else
        raise EvaError.new('Syntax Error', 'Mismatched parentheses!')
      end
    end
    out
  end

  def balance(tokens)
    depth = 0
    tokens.each do |t|
      depth += 1 if t.type == :lpar
      depth -= 1 if t.type == :rpar
      raise EvaError.new('Syntax Error', 'Mismatched parentheses!') if depth < 0
    end
    tokens + Array.new(depth) { Token.new(:rpar, ')') }
  end

  def value_start?(t)
    t && (t.type == :num || t.type == :ident || t.type == :lpar)
  end

  def value_end?(t)
    t && (t.type == :num || t.type == :ident || t.type == :rpar)
  end

  def insert_implicit_mul(tokens)
    res = []
    tokens.each_with_index do |t, idx|
      prev = res[-1]
      if value_end?(prev) && value_start?(t)
        # Function calls bind to the preceding identifier, not multiplication.
        unless prev.type == :ident && t.type == :lpar && (FUNCS1.include?(prev.value) || FUNCS2.include?(prev.value))
          res << Token.new(:op, '*')
        end
      end
      res << t
    end
    res
  end

  def parse_expression(tokens)
    @tokens = tokens
    @pos = 0
    v = parse_add
    raise EvaError.new('Syntax Error', 'Mismatched parentheses!') if peek&.type == :comma
    raise EvaError.new('Parser Error', 'Too many operators, too few operands') if @pos < @tokens.length
    v
  end

  def peek = @tokens[@pos]
  def take = @tokens[@pos].tap { @pos += 1 }

  def parse_add
    v = parse_mul
    while peek&.type == :op && %w[+ -].include?(peek.value)
      op = take.value
      r = parse_mul
      v = op == '+' ? v + r : v - r
    end
    v
  end

  def parse_mul
    v = parse_power
    while peek&.type == :op && %w[* /].include?(peek.value)
      op = take.value
      r = parse_power
      if op == '/'
        raise EvaError.new('Math Error', 'Divide by zero error!') if r == 0.0
        v /= r
      else
        v *= r
      end
    end
    v
  end

  def parse_power
    v = parse_unary
    if peek&.type == :op && peek.value == '^'
      take
      r = parse_power
      v = v**r
      domain! unless v.finite?
    end
    v
  end

  def parse_unary
    if peek&.type == :op && %w[+ -].include?(peek.value)
      op = take.value
      v = parse_unary
      op == '-' ? -v : v
    else
      parse_primary
    end
  end

  def parse_primary
    t = take
    raise EvaError.new('Parser Error', 'Too many operators, too few operands') unless t
    case t.type
    when :num
      t.value
    when :ident
      name = t.value
      return @last if name == '_'
      return CONSTANTS[name] if CONSTANTS.key?(name)
      if FUNCS1.include?(name) || FUNCS2.include?(name)
        parse_function(name)
      else
        raise EvaError.new('Syntax Error', "Unknown function '#{name}'")
      end
    when :lpar
      v = parse_add
      raise EvaError.new('Syntax Error', 'Mismatched parentheses!') unless peek&.type == :rpar
      take
      v
    else
      raise EvaError.new('Parser Error', 'Too many operators, too few operands')
    end
  end

  def parse_function(name)
    raise EvaError.new('Syntax Error', 'Mismatched parentheses!') unless peek&.type == :lpar
    take
    a = parse_add
    args = [a]
    if peek&.type == :comma
      take
      args << parse_add
    end
    raise EvaError.new('Syntax Error', 'Mismatched parentheses!') unless peek&.type == :rpar
    take
    if FUNCS1.include?(name) && args.length != 1
      raise EvaError.new('Parser Error', 'Too many operators, too few operands')
    end
    if FUNCS2.include?(name) && args.length != 2
      raise EvaError.new('Parser Error', 'Too many operators, too few operands')
    end
    apply_func(name, args)
  end

  def radians(x)
    case @angle
    when 'radian' then x
    when 'gradian' then x * Math::PI / 180.0
    else x * Math::PI / 180.0
    end
  end

  def domain!
    raise EvaError.new('Domain Error', 'Out of bounds!')
  end

  def apply_func(name, a)
    x = a[0]
    v = case name
        when 'sin' then Math.sin(radians(x))
        when 'cos' then Math.cos(radians(x))
        when 'tan' then Math.tan(radians(x))
        when 'csc' then 1.0 / Math.sin(radians(x))
        when 'sec' then 1.0 / Math.cos(radians(x))
        when 'cot' then 1.0 / Math.tan(radians(x))
        when 'sinh' then Math.sinh(x)
        when 'cosh' then Math.cosh(x)
        when 'tanh' then Math.tanh(x)
        when 'asin' then domain! unless (-1.0..1.0).include?(x); Math.asin(x)
        when 'acos' then domain! unless (-1.0..1.0).include?(x); Math.acos(x)
        when 'atan' then Math.atan(x)
        when 'acsc' then domain! if x.abs < 1.0; Math.asin(1.0 / x)
        when 'asec' then domain! if x.abs < 1.0; Math.acos(1.0 / x)
        when 'acot' then Math.atan(1.0 / x)
        when 'ln' then domain! if x <= 0; Math.log(x)
        when 'log2' then domain! if x <= 0; Math.log2(x)
        when 'log10' then domain! if x <= 0; Math.log10(x)
        when 'sqrt' then domain! if x < 0; Math.sqrt(x)
        when 'ceil' then x.ceil.to_f
        when 'floor' then x.floor.to_f
        when 'abs' then x.abs
        when 'log'
          n, base = a
          domain! if n <= 0 || base <= 0 || base == 1.0
          Math.log(n, base)
        when 'nroot'
          n, root = a
          domain! if root == 0.0 || (n < 0 && root % 2 == 0)
          n ** (1.0 / root)
        end
    domain! unless v.finite?
    v
  rescue Math::DomainError, ZeroDivisionError
    domain!
  end

  def format_base(value)
    sign = value < 0 ? '-' : ''
    v = value.abs
    int = v.floor
    frac = v - int
    int_s = int_to_base(int, @base)
    if frac == 0.0
      frac_s = '0'
    else
      digits = []
      @fix.times do
        frac *= @base
        d = frac.floor
        digits << digit(d)
        frac -= d
      end
      frac_s = digits.join
    end
    raw = sign + int_s + '.' + frac_s
    groups = raw.split('.', 2)[0].reverse.scan(/.{1,3}/).map(&:reverse).reverse
    groups = groups.last(4)
    groups.unshift('') while groups.length < 4
    grouped_int = groups.each_with_index.map { |g, i| g.empty? && i == 0 ? ' ' : g.rjust(3) }.join(',')
    grouped_int + '.' + raw.split('.', 2)[1]
  end

  def int_to_base(n, base)
    return '0' if n == 0
    return '1' * n if base <= 1 && n < 10_000
    return '0' if base <= 1
    s = +''
    while n > 0
      s << digit(n % base)
      n /= base
    end
    s.reverse
  end

  def digit(n)
    n < 10 ? n.to_s : (55 + n).chr
  end

  def read_previous
    path = File.join(Dir.home, '.cache', 'eva', 'previous_ans.txt')
    File.exist?(path) ? File.read(path).to_f : 0.0
  rescue
    0.0
  end
end

def help
  <<~TXT
    Calculator REPL similar to bc(1)

    Usage: executable [OPTIONS] [INPUT]

    Arguments:
      [INPUT]  Optional expression string to run eva in command mode

    Options:
      -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]
      -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]
      -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]
      -h, --help                     Print help
      -V, --version                  Print version
  TXT
end

def parse_cli(argv)
  opts = { fix: 10, base: 10, angle: 'degree', input: nil }
  args = argv.dup
  passthrough = false
  while (a = args.shift)
    if passthrough
      opts[:input] = ([a] + args).join(' ')
      break
    elsif a == '--'
      passthrough = true
    elsif a == '-h' || a == '--help'
      puts help
      exit 0
    elsif a == '-V' || a == '--version'
      puts 'eva 0.3.1'
      exit 0
    elsif a == '-f' || a == '--fix'
      val = args.shift
      fix = val.to_i
      if fix < 1 || fix > 64
        warn "error: invalid value '#{val}' for '--fix <FIX>': #{val} is not in 1..=64\n\nFor more information, try '--help'."
        exit 2
      end
      opts[:fix] = fix
    elsif a == '-b' || a == '--base'
      val = args.shift
      base = val.to_i
      if base < 1 || base > 36
        warn "error: invalid value '#{val}' for '--base <RADIX>': #{val} is not in 1..=36\n\nFor more information, try '--help'."
        exit 2
      end
      opts[:base] = base
    elsif a == '-a' || a == '--angle_unit'
      val = args.shift
      unless %w[degree radian gradian].include?(val)
        warn "error: invalid value '#{val}' for '--angle_unit <angle_unit>'"
        exit 2
      end
      opts[:angle] = val
    elsif a.start_with?('-') && a != '-'
      shown = a[0, 2]
      warn "error: unexpected argument '#{shown}' found\n\n  tip: to pass '#{shown}' as a value, use '-- #{shown}'\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'."
      exit 2
    else
      opts[:input] = ([a] + args).join(' ')
      break
    end
  end
  opts
end

opts = parse_cli(ARGV)
calc = Calculator.new(fix: opts[:fix], base: opts[:base], angle: opts[:angle])

def handle(calc, line)
  v = calc.eval_line(line)
  puts calc.format(v) unless v.nil?
  if v
    path = File.join(Dir.home, '.cache', 'eva')
    Dir.mkdir(File.join(Dir.home, '.cache')) unless Dir.exist?(File.join(Dir.home, '.cache'))
    Dir.mkdir(path) unless Dir.exist?(path)
    File.write(File.join(path, 'previous_ans.txt'), "#{v}\n")
  end
  0
rescue EvaError => e
  warn "#{e.kind}: #{e.message}"
  1
end

if opts[:input]
  exit handle(calc, opts[:input])
else
  hist_dir = File.join(Dir.home, '.local', 'share', 'eva')
  hist_file = File.join(hist_dir, 'history.txt')
  warn 'No previous history.' unless File.exist?(hist_file)
  Dir.mkdir(File.join(Dir.home, '.local')) unless Dir.exist?(File.join(Dir.home, '.local'))
  Dir.mkdir(File.join(Dir.home, '.local', 'share')) unless Dir.exist?(File.join(Dir.home, '.local', 'share'))
  Dir.mkdir(hist_dir) unless Dir.exist?(hist_dir)
  File.write(hist_file, "#V2\n") unless File.exist?(hist_file)
  status = 0
  STDIN.each_line do |line|
    line = line.chomp
    File.open(hist_file, 'a') { |f| f.puts line }
    break if %w[quit exit].include?(line.strip)
    status = handle(calc, line)
  end
  exit status
end
