#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = 'thokr 0.4.1'
ABOUT = 'sleek typing tui with visualized results and historical logging'
LANGUAGES = %w[english english1k english10k].freeze

WORDS = %w[
  the be to of and a in that have i it for not on with he as you do at this but
  his by from they we say her she or an will my one all would there their what
  so up out if about who get which go me when make can like time no just him know
  take people into year your good some could them see other than then now look
  only come its over think also back after use two how our work first well way
  even new want because any these give day most us is are was were had did been
  may very where much through before right too means old same tell does set three
  such here why asked went men read need land different home move try kind hand
  picture again change off play spell air away animal house point page letter
  mother answer found study still learn should america world high every near add
  food between own below country plant last school father keep tree never start
  city earth eye light thought head under story saw left don't few while along
  might close something seem next hard open example begin life always those both
  paper together got group often run important until children side feet car mile
  night walk white sea began grow took river four carry state once book hear stop
].freeze

SENTENCES = [
  'The quiet morning light settled over the empty street.',
  'Every small choice can change the shape of a day.',
  'A steady rhythm makes the work feel lighter.',
  'The old notebook waited beside a cup of coffee.',
  'Clear words help ideas travel without confusion.'
].freeze

def help_text(program = File.basename($PROGRAM_NAME))
  <<~HELP
    #{VERSION}
    #{ABOUT}

    USAGE:
        #{program} [OPTIONS]

    OPTIONS:
        -f, --full-sentences <NUMBER_OF_SENTENCES>
                number of sentences to use in test

        -h, --help
                Print help information

        -l, --supported-language <SUPPORTED_LANGUAGE>
                language to pull words from [default: english] [possible values: english, english1k,
                english10k]

        -p, --prompt <PROMPT>
                custom prompt to use

        -s, --number-of-secs <NUMBER_OF_SECS>
                number of seconds to run test

        -V, --version
                Print version information

        -w, --number-of-words <NUMBER_OF_WORDS>
                number of words to use in test [default: 15]
  HELP
end

def usage_for(option = nil, program = File.basename($PROGRAM_NAME))
  if option == :language
    "USAGE:\n    #{program} --supported-language <SUPPORTED_LANGUAGE>\n"
  else
    "USAGE:\n    #{program} [OPTIONS]\n"
  end
end

def die(message, usage: nil)
  $stderr.puts "error: #{message}"
  $stderr.write "\n"
  if usage
    $stderr.puts usage.chomp
    $stderr.write "\n"
  end
  $stderr.puts 'For more information try --help'
  exit 2
end

def parse_positive_integer(value, flag, label)
  if value.nil?
    die("The argument '#{flag} <#{label}>' requires a value but none was supplied", usage: usage_for)
  end
  die("Found argument '#{value}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `#{value}` as a value rather than a flag, use `-- #{value}`", usage: usage_for) if value.start_with?('-')
  Integer(value, 10)
rescue ArgumentError
  die("Invalid value \"#{value}\" for '#{flag} <#{label}>': invalid digit found in string")
end

def parse_args(argv)
  opts = { words: 15, language: 'english', secs: nil, prompt: nil, sentences: nil }
  i = 0
  while i < argv.length
    arg = argv[i]
    inline_value = nil
    if arg.start_with?('--') && arg.include?('=')
      arg, inline_value = arg.split('=', 2)
    end
    case arg
    when '-h', '--help'
      puts help_text
      exit 0
    when '-V', '--version'
      puts VERSION
      exit 0
    when '-w', '--number-of-words'
      i += 1 unless inline_value
      opts[:words] = parse_positive_integer(inline_value || argv[i], '--number-of-words', 'NUMBER_OF_WORDS')
    when '-s', '--number-of-secs'
      i += 1 unless inline_value
      opts[:secs] = parse_positive_integer(inline_value || argv[i], '--number-of-secs', 'NUMBER_OF_SECS')
    when '-f', '--full-sentences'
      i += 1 unless inline_value
      opts[:sentences] = parse_positive_integer(inline_value || argv[i], '--full-sentences', 'NUMBER_OF_SENTENCES')
    when '-l', '--supported-language'
      i += 1 unless inline_value
      value = inline_value || argv[i]
      if value.nil?
        die("The argument '--supported-language <SUPPORTED_LANGUAGE>' requires a value but none was supplied\n\t[possible values: english, english1k, english10k]", usage: usage_for(:language))
      end
      unless LANGUAGES.include?(value)
        die("\"#{value}\" isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'\n\t[possible values: english, english1k, english10k]", usage: usage_for(:language))
      end
      opts[:language] = value
    when '-p', '--prompt'
      i += 1 unless inline_value
      value = inline_value || argv[i]
      die("The argument '--prompt <PROMPT>' requires a value but none was supplied", usage: usage_for) if value.nil?
      opts[:prompt] = value
    else
      if arg.start_with?('-')
        die("Found argument '#{arg}' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `#{arg}` as a value rather than a flag, use `-- #{arg}`", usage: usage_for)
      else
        die("Found argument '#{arg}' which wasn't expected, or isn't valid in this context", usage: usage_for)
      end
    end
    i += 1
  end
  opts
end

def prompt_for(opts)
  return opts[:prompt] if opts[:prompt]

  if opts[:sentences]
    return Array.new(opts[:sentences]) { |idx| SENTENCES[idx % SENTENCES.length] }.join(' ')
  end

  pool = WORDS
  if opts[:language] == 'english1k'
    pool = WORDS + WORDS.map { |w| "#{w}ly" }
  elsif opts[:language] == 'english10k'
    pool = WORDS + WORDS.map { |w| "#{w}ing" } + WORDS.map { |w| "#{w}ed" }
  end
  Array.new(opts[:words]) { pool.sample }.join(' ')
end

def log_result(opts, start_time, typed, target)
  elapsed = Time.now - start_time
  elapsed = 0.0 if elapsed.negative?
  chars = [typed.length, target.length].min
  correct = 0
  chars.times { |idx| correct += 1 if typed[idx] == target[idx] }
  accuracy = typed.empty? ? 0 : ((correct.to_f / typed.length) * 100).round
  wpm = elapsed.zero? ? 'inf' : ((typed.split(/\s+/).reject(&:empty?).length / elapsed) * 60).round(2).to_s
  secs = opts[:secs] ? format('%.2f', opts[:secs].to_f) : nil
  path = File.join(ENV['XDG_CONFIG_HOME'] || File.join(Dir.home, '.config'), 'thokr', 'log.csv')
  mkdir_p(File.dirname(path))
  new_file = !File.exist?(path)
  File.open(path, 'a') do |file|
    file.puts 'date,num_words,num_secs,elapsed_secs,wpm,accuracy,std_dev' if new_file
    row = [Time.now.strftime('%a %b %e %H:%M:%S %Y'), opts[:words], secs, format('%.2f', elapsed), wpm, accuracy, '0.00']
    file.puts row.map { |field| csv_field(field) }.join(',')
  end
end

def mkdir_p(path)
  parts = path.split(File::SEPARATOR)
  current = path.start_with?(File::SEPARATOR) ? File::SEPARATOR : ''
  parts.each do |part|
    next if part.empty?

    current = current == File::SEPARATOR ? File.join(current, part) : File.join(current, part)
    Dir.mkdir(current) unless Dir.exist?(current)
  end
end

def csv_field(value)
  text = value.to_s
  return text unless text.match?(/[",\n]/)

  %("#{text.gsub('"', '""')}")
end

def render(target, typed, start_time, opts)
  elapsed = Time.now - start_time
  cols = 80
  print "\e[H\e[2J"
  puts 'thokr'.center(cols)
  puts
  puts target.scan(/.{1,#{[cols - 4, 20].max}}(?:\s+|$)|\S+/).join("\n").strip
  puts
  puts typed
  puts
  status = "words #{opts[:words]}"
  status += " | seconds #{opts[:secs]}" if opts[:secs]
  status += " | elapsed #{format('%.1f', elapsed)}"
  puts status
  $stdout.flush
end

def interactive(opts)
  target = prompt_for(opts)
  typed = +''
  start = Time.now
  logged = false
  old_stty = nil
  begin
    print "\e[?1049h\e[39m\e[49m\e[0m\e[?25l"
    old_stty = `stty -g 2>/dev/null`.strip
    system('stty raw -echo 2>/dev/null')
    loop do
      render(target, typed, start, opts)
      if typed.length >= target.length || (opts[:secs] && Time.now - start >= opts[:secs])
        log_result(opts, start, typed, target) unless logged
        logged = true
        puts
        puts 'complete'
        $stdout.flush
        sleep 0.05
        break unless IO.select([STDIN], nil, nil, 0)
      end
      ready = IO.select([STDIN], nil, nil, 0.02)
      next unless ready

      char = STDIN.read(1)
      break if char.nil?

      case char
      when "\u0003", "\u0004", "\e"
        break
      when "\r", "\n"
        next
      when "\177", "\b"
        typed.chop!
      else
        typed << char if char.ord >= 32
      end
    end
  ensure
    system("stty #{old_stty} 2>/dev/null") if old_stty && !old_stty.empty?
    log_result(opts, start, typed, target) if !logged && typed.length >= target.length
    print "\e[?25h\e[?1049l\e[0m"
    $stdout.flush
  end
end

opts = parse_args(ARGV)
unless STDIN.tty?
  $stderr.puts 'error: stdin must be a tty'
  $stderr.write "\n"
  $stderr.puts "USAGE:\n    thokr [OPTIONS]"
  $stderr.write "\n"
  $stderr.puts 'For more information try --help'
  exit 2
end

interactive(opts)
