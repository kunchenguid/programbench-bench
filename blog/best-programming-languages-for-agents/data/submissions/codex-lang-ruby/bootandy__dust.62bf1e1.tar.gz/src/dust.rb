#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = "Dust 1.2.3"

HELP = <<~HELP
  Like du but more intuitive

  Usage: executable [OPTIONS] [PATH]...

  Arguments:
    [PATH]...
            Input files or directories

  Options:
    -d, --depth <DEPTH>
            Depth to show

    -T, --threads <THREADS>
            Number of threads to use

        --config <FILE>
            Specify a config file to use

    -n, --number-of-lines <NUMBER>
            Number of lines of output to show. (Default is terminal_height - 10)

    -p, --full-paths
            Subdirectories will not have their path shortened

    -X, --ignore-directory <PATH>
            Exclude any file or directory with this path

    -I, --ignore-all-in-file <FILE>
            Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter

    -L, --dereference-links
            dereference sym links - Treat sym links as directories and go into them

    -x, --limit-filesystem
            Only count the files and directories on the same filesystem as the supplied directory

    -s, --apparent-size
            Use file length instead of blocks

    -r, --reverse
            Print tree upside down (biggest highest)

    -c, --no-colors
            No colors will be printed (Useful for commands like: watch)

    -C, --force-colors
            Force colors print

    -b, --no-percent-bars
            No percent bars or percentages will be displayed

    -B, --bars-on-right
            percent bars moved to right side of screen

    -z, --min-size <MIN_SIZE>
            Minimum size file to include in output

    -R, --screen-reader
            For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)

        --skip-total
            No total row will be displayed

    -f, --filecount
            Directory 'size' is number of child files instead of disk size

    -i, --ignore-hidden
            Do not display hidden files

    -v, --invert-filter <REGEX>
            Exclude filepaths matching this regex. To ignore png files type: -v "\\.png$"

    -e, --filter <REGEX>
            Only include filepaths matching this regex. For png files type: -e "\\.png$"

    -t, --file-types
            show only these file types

    -w, --terminal-width <WIDTH>
            Specify width of output overriding the auto detection of terminal width

    -P, --no-progress
            Disable the progress indication

        --print-errors
            Print path with errors

    -D, --only-dir
            Only directories will be displayed

    -F, --only-file
            Only files will be displayed. (Finds your largest files)

    -o, --output-format <FORMAT>
            Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size

            Possible values:
            - si: SI prefix (powers of 1000)
            - b:  byte (B)
            - k:  kibibyte (KiB)
            - m:  mebibyte (MiB)
            - g:  gibibyte (GiB)
            - t:  tebibyte (TiB)
            - kb: kilobyte (kB)
            - mb: megabyte (MB)
            - gb: gigabyte (GB)
            - tb: terabyte (TB)

    -S, --stack-size <STACK_SIZE>
            Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)

    -j, --output-json
            Output the directory tree as json to the current directory

    -M, --mtime <MTIME>
            +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (−∞, curr−(n+1)), n => [curr−(n+1), curr−n), and -n => (𝑐𝑢𝑟𝑟−𝑛, +∞)

    -A, --atime <ATIME>
            just like -mtime, but based on file access time

    -y, --ctime <CTIME>
            just like -mtime, but based on file change time

        --files0-from <FILES0_FROM>
            Read NUL-terminated paths from FILE (use `-` for stdin)

        --files-from <FILES_FROM>
            Read newline-terminated paths from FILE (use `-` for stdin)

        --collapse <COLLAPSE>
            Keep these directories collapsed

    -m, --filetime <FILETIME>
            Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time

            Possible values:
            - a: last accessed time
            - c: last changed time
            - m: last modified time

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
HELP

Node = Struct.new(:path, :name, :size, :dir, :children, :depth, keyword_init: true)

def die(message)
  warn message
  exit 2
end

def parse_size(text)
  return nil if text.nil?

  s = text.strip
  m = s.match(/\A([+-]?\d+(?:\.\d+)?)([kmgtKMGT]?[iI]?[bB]?)?\z/)
  return s.to_i unless m

  n = m[1].to_f
  unit = (m[2] || "").downcase
  mult = case unit
         when "k", "kb", "kib" then 1024
         when "m", "mb", "mib" then 1024**2
         when "g", "gb", "gib" then 1024**3
         when "t", "tb", "tib" then 1024**4
         else 1
         end
  (n * mult).to_i
end

def parse_age(expr)
  return nil unless expr

  if expr.start_with?("+")
    [:gt, expr[1..].to_i]
  elsif expr.start_with?("-")
    [:lt, expr[1..].to_i]
  else
    [:eq, expr.to_i]
  end
end

def age_match?(time, rule)
  return true unless rule

  kind, days = rule
  age = ((Time.now - time) / 86_400).floor
  case kind
  when :gt then age > days
  when :lt then age < days
  else age == days
  end
end

def parse_args(argv)
  opts = {
    paths: [],
    ignores: [],
    ignore_regexes: [],
    collapses: [],
    output_format: "default",
    width: 80,
    lines: nil,
    depth: nil,
    full_paths: false,
    apparent: false,
    reverse: false,
    no_bars: false,
    screen_reader: false,
    skip_total: false,
    filecount: false,
    ignore_hidden: false,
    only_dir: false,
    only_file: false,
    json: false,
    dereference: false,
    errors: false,
    filetime: nil
  }

  config_path = nil
  argv.each_with_index do |arg, idx|
    if arg == "--config"
      config_path = argv[idx + 1]
    elsif arg.start_with?("--config=")
      config_path = arg.split("=", 2)[1]
    end
  end
  config_path ||= File.expand_path("~/.config/dust/config.toml")
  config_path = File.expand_path("~/.dust.toml") unless File.file?(config_path)
  load_config_defaults(opts, config_path) if File.file?(config_path)

  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when "-h", "--help"
      puts HELP
      exit 0
    when "-V", "--version"
      puts VERSION
      exit 0
    when "-d", "--depth"
      i += 1
      opts[:depth] = argv[i].to_i
    when /^--depth=(.*)/
      opts[:depth] = Regexp.last_match(1).to_i
    when "-n", "--number-of-lines"
      i += 1
      opts[:lines] = argv[i].to_i
    when /^--number-of-lines=(.*)/
      opts[:lines] = Regexp.last_match(1).to_i
    when "-w", "--terminal-width"
      i += 1
      opts[:width] = argv[i].to_i
    when /^--terminal-width=(.*)/
      opts[:width] = Regexp.last_match(1).to_i
    when "-o", "--output-format"
      i += 1
      fmt = argv[i]
      die("error: invalid value '#{fmt}' for '--output-format <FORMAT>'") unless %w[si b k m g t kb mb gb tb].include?(fmt)
      opts[:output_format] = fmt
    when /^--output-format=(.*)/
      fmt = Regexp.last_match(1)
      die("error: invalid value '#{fmt}' for '--output-format <FORMAT>'") unless %w[si b k m g t kb mb gb tb].include?(fmt)
      opts[:output_format] = fmt
    when "-z", "--min-size"
      i += 1
      opts[:min_size] = parse_size(argv[i])
    when /^--min-size=(.*)/
      opts[:min_size] = parse_size(Regexp.last_match(1))
    when "-X", "--ignore-directory"
      i += 1
      opts[:ignores] << argv[i]
    when /^--ignore-directory=(.*)/
      opts[:ignores] << Regexp.last_match(1)
    when "-I", "--ignore-all-in-file"
      i += 1
      file = argv[i]
      File.readlines(file, chomp: true).each { |line| opts[:ignore_regexes] << Regexp.new(line) unless line.empty? }
    when "-e", "--filter"
      i += 1
      opts[:filter] = Regexp.new(argv[i])
    when "-v", "--invert-filter"
      i += 1
      opts[:ignore_regexes] << Regexp.new(argv[i])
    when "-M", "--mtime"
      i += 1
      opts[:mtime] = parse_age(argv[i])
    when "-A", "--atime"
      i += 1
      opts[:atime] = parse_age(argv[i])
    when "-y", "--ctime"
      i += 1
      opts[:ctime] = parse_age(argv[i])
    when "-m", "--filetime"
      i += 1
      opts[:filetime] = argv[i]
    when "--files-from"
      i += 1
      src = argv[i]
      data = src == "-" ? STDIN.read : File.read(src)
      opts[:paths].concat(data.lines.map(&:chomp).reject(&:empty?))
    when /^--files-from=(.*)/
      src = Regexp.last_match(1)
      data = src == "-" ? STDIN.read : File.read(src)
      opts[:paths].concat(data.lines.map(&:chomp).reject(&:empty?))
    when "--files0-from"
      i += 1
      src = argv[i]
      data = src == "-" ? STDIN.read : File.binread(src)
      opts[:paths].concat(data.split("\0").reject(&:empty?))
    when /^--files0-from=(.*)/
      src = Regexp.last_match(1)
      data = src == "-" ? STDIN.read : File.binread(src)
      opts[:paths].concat(data.split("\0").reject(&:empty?))
    when "--collapse"
      i += 1
      opts[:collapses] << argv[i]
    when /^--collapse=(.*)/
      opts[:collapses] << Regexp.last_match(1)
    when "--config", "-T", "--threads", "-S", "--stack-size"
      i += 1
    when /^--config=/
    when "-p", "--full-paths"
      opts[:full_paths] = true
    when "-s", "--apparent-size"
      opts[:apparent] = true
    when "-r", "--reverse"
      opts[:reverse] = true
    when "-b", "--no-percent-bars"
      opts[:no_bars] = true
    when "-B", "--bars-on-right", "-c", "--no-colors", "-C", "--force-colors", "-x", "--limit-filesystem", "-P", "--no-progress", "--print-errors", "-t", "--file-types"
      opts[:errors] = true if a == "--print-errors"
    when "-R", "--screen-reader"
      opts[:screen_reader] = true
    when "--skip-total"
      opts[:skip_total] = true
    when "-f", "--filecount"
      opts[:filecount] = true
    when "-i", "--ignore-hidden"
      opts[:ignore_hidden] = true
    when "-D", "--only-dir"
      opts[:only_dir] = true
    when "-F", "--only-file"
      opts[:only_file] = true
    when "-j", "--output-json"
      opts[:json] = true
    when "-L", "--dereference-links"
      opts[:dereference] = true
    when "--"
      opts[:paths].concat(argv[(i + 1)..] || [])
      break
    else
      if a.start_with?("-")
        die("error: unexpected argument '#{a}' found")
      else
        opts[:paths] << a
      end
    end
    i += 1
  end

  opts[:paths] = ["."] if opts[:paths].empty?
  opts
end

def config_bool(value)
  value.strip.downcase == "true"
end

def config_value(value)
  value = value.split("#", 2)[0].strip
  value = value[1...-1] if value.start_with?('"') && value.end_with?('"')
  value
end

def load_config_defaults(opts, path)
  File.readlines(path, chomp: true).each do |line|
    line = line.strip
    next if line.empty? || line.start_with?("#")
    key, raw = line.split("=", 2)
    next unless key && raw

    key = key.strip
    val = config_value(raw)
    case key
    when "reverse" then opts[:reverse] = config_bool(val)
    when "display-full-paths", "full-paths" then opts[:full_paths] = config_bool(val)
    when "display-apparent-size", "apparent-size" then opts[:apparent] = config_bool(val)
    when "no-colors" then nil
    when "no-bars" then opts[:no_bars] = config_bool(val)
    when "skip-total" then opts[:skip_total] = config_bool(val)
    when "ignore-hidden" then opts[:ignore_hidden] = config_bool(val)
    when "output-format" then opts[:output_format] = val if %w[si b k m g t kb mb gb tb].include?(val)
    when "number-of-lines" then opts[:lines] = val.to_i
    when "depth" then opts[:depth] = val.to_i
    end
  end
rescue SystemCallError
  nil
end

def ignored_path?(path, opts)
  base = File.basename(path)
  return true if opts[:ignore_hidden] && base.start_with?(".") && base != "." && base != ".."
  return true if opts[:ignores].any? { |ig| ig == path || ig == base || path.include?(ig) }
  return true if opts[:ignore_regexes].any? { |rx| path.match?(rx) }

  false
end

def stat_for(path, opts)
  opts[:dereference] ? File.stat(path) : File.lstat(path)
rescue SystemCallError => e
  warn "#{path}: #{e.message}" if opts[:errors]
  nil
end

def own_size(path, st, opts)
  if opts[:filecount]
    st.directory? ? 0 : (st.symlink? ? 0 : 1)
  elsif opts[:filetime]
    t = case opts[:filetime]
        when "a" then st.atime
        when "c" then st.ctime
        else st.mtime
        end
    t.to_i
  elsif opts[:apparent] && !st.directory?
    st.symlink? ? 0 : st.size
  else
    st.blocks.to_i * 512
  end
end

def include_file?(path, st, opts)
  return false if ignored_path?(path, opts)
  return false if opts[:filter] && !path.match?(opts[:filter])
  return false if opts[:min_size] && !st.directory? && own_size(path, st, opts) < opts[:min_size]
  return false unless age_match?(st.mtime, opts[:mtime])
  return false unless age_match?(st.atime, opts[:atime])
  return false unless age_match?(st.ctime, opts[:ctime])

  true
end

def build_node(path, opts, depth = 0)
  st = stat_for(path, opts)
  return nil unless st
  return nil unless include_file?(path, st, opts)

  name = File.basename(path)
  name = path if name.empty?
  node = Node.new(path: path, name: name, size: 0, dir: st.directory?, children: [], depth: depth)
  node.size = own_size(path, st, opts)

  if st.directory? && !opts[:collapses].include?(File.basename(path))
    begin
      entries = Dir.children(path).map { |c| File.join(path, c) }
    rescue SystemCallError => e
      warn "#{path}: #{e.message}" if opts[:errors]
      entries = []
    end
    entries.each do |child|
      next if ignored_path?(child, opts)

      cn = build_node(child, opts, depth + 1)
      next unless cn

      node.children << cn
      node.size = [node.size, cn.size].max if opts[:filetime]
      node.size += cn.size unless opts[:filetime]
    end
  end

  if opts[:filter] && node.dir && node.children.empty? && !path.match?(opts[:filter])
    return nil
  end

  node.children.sort_by! { |c| [c.size, c.name] }
  node
end

def flatten_post(node, opts, out = [])
  node.children.each { |c| flatten_post(c, opts, out) }
  out << node
  out
end

def flatten_pre(node, opts, out = [])
  out << node
  node.children.sort { |a, b| (b.size <=> a.size).nonzero? || (b.name <=> a.name) }.each { |c| flatten_pre(c, opts, out) }
  out
end

def visible_nodes(roots, opts)
  nodes = roots.flat_map { |r| opts[:reverse] ? flatten_pre(r, opts) : flatten_post(r, opts) }
  nodes.select! { |n| n.depth <= opts[:depth] } if opts[:depth]
  nodes.select! { |n| n.dir || n.depth.zero? } if opts[:only_dir]
  nodes.select! { |n| !n.dir || n.depth.zero? } if opts[:only_file]
  nodes.reject! { |n| n.depth.zero? } if opts[:skip_total]

  if opts[:lines] && nodes.length > opts[:lines]
    if opts[:reverse]
      nodes = nodes.first(opts[:lines])
    else
      root_nodes = nodes.select { |n| n.depth.zero? }
      rest = nodes.reject { |n| n.depth.zero? }.last([opts[:lines] - root_nodes.length, 0].max)
      nodes = rest + root_nodes
    end
  end
  nodes
end

def format_size(bytes, fmt)
  return bytes.to_s if fmt == "count"

  case fmt
  when "b"
    "#{bytes.to_i}B"
  when "k", "m", "g", "t"
    pwr = { "k" => 1, "m" => 2, "g" => 3, "t" => 4 }[fmt]
    "#{(bytes.to_f / (1024**pwr)).floor}#{fmt.upcase}"
  when "kb", "mb", "gb", "tb"
    pwr = { "kb" => 1, "mb" => 2, "gb" => 3, "tb" => 4 }[fmt]
    "#{(bytes.to_f / (1000**pwr)).floor}#{fmt.upcase.sub('B', '')}B"
  when "si"
    human(bytes, 1000, %w[B kB MB GB TB])
  else
    human(bytes, 1024, %w[B K M G T])
  end
end

def human(n, base, units)
  n = n.to_f
  idx = 0
  while n >= base && idx < units.length - 1
    n /= base
    idx += 1
  end
  if idx.zero?
    "#{n.to_i}B"
  elsif n < 10
    format("%.1f%s", n, units[idx])
  else
    "#{n.floor}#{units[idx]}"
  end
end

def display_name(node, opts)
  opts[:full_paths] ? node.path : (node.depth.zero? && node.path == "." ? "." : node.name)
end

def percent(node, total)
  total.to_i <= 0 ? 0 : ((node.size.to_f / total) * 100).round
end

def bar(pct, width)
  width = [width, 1].max
  filled = (width * pct / 100.0).round
  filled = 1 if pct.zero?
  ("█" * [filled, width].min) + ("░" * [width - filled, 0].max)
end

def tree_prefix(node, reverse)
  return "└─┬ " if reverse && node.depth.zero?
  return "┌─┴ " if node.depth.zero?

  indent = "│ " * [node.depth - 1, 0].max
  join = node.dir ? (reverse ? "├─┬ " : "├─┴ ") : "├── "
  indent + join
end

def print_screen_reader(nodes, roots, opts)
  total = roots.map(&:size).max || 0
  sizes = nodes.map { |n| format_size(n.size, opts[:filecount] ? "count" : opts[:output_format]) }
  names = nodes.map { |n| display_name(n, opts) }
  nw = names.map(&:length).max || 1
  sw = sizes.map(&:length).max || 1
  nodes.each_with_index do |n, idx|
    puts format("%-#{nw}s %d %#{sw}s %3d%%", names[idx], n.depth, sizes[idx], percent(n, total))
  end
end

def print_tree(nodes, roots, opts)
  total = roots.map(&:size).max || 0
  sizes = nodes.map { |n| format_size(n.size, opts[:filecount] ? "count" : opts[:output_format]) }
  names = nodes.map { |n| display_name(n, opts) }
  sw = sizes.map(&:length).max || 1
  nw = names.map(&:length).max || 1
  nodes.each_with_index do |n, idx|
    left = format("%#{sw}s %s%-#{nw}s", sizes[idx], tree_prefix(n, opts[:reverse]), names[idx])
    if opts[:no_bars]
      puts left
    else
      pct = percent(n, total)
      bw = [opts[:width] - left.length - 9, 8].max
      puts "#{left}│#{bar(pct, bw)} │#{format('%4d%%', pct)}"
    end
  end
end

def node_json(node, opts)
  {
    size: format_size(node.size, opts[:filecount] ? "count" : opts[:output_format]),
    name: File.expand_path(node.path),
    children: node.children.sort { |a, b| (b.size <=> a.size).nonzero? || (b.name <=> a.name) }.map { |c| node_json(c, opts) }
  }
end

def json_escape(s)
  s.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
    case ch
    when '"' then '\"'
    when "\\" then "\\\\"
    when "\b" then "\\b"
    when "\f" then "\\f"
    when "\n" then "\\n"
    when "\r" then "\\r"
    when "\t" then "\\t"
    end
  end
end

def json_generate(obj)
  case obj
  when Hash
    "{" + obj.map { |k, v| "\"#{json_escape(k)}\":#{json_generate(v)}" }.join(",") + "}"
  when Array
    "[" + obj.map { |v| json_generate(v) }.join(",") + "]"
  when String
    "\"#{json_escape(obj)}\""
  when Numeric
    obj.to_s
  when true
    "true"
  when false
    "false"
  when nil
    "null"
  else
    "\"#{json_escape(obj)}\""
  end
end

opts = parse_args(ARGV)
roots = opts[:paths].filter_map { |p| build_node(p, opts, 0) }
exit 1 if roots.empty?

if opts[:json]
  payload = roots.length == 1 ? node_json(roots.first, opts) : roots.map { |r| node_json(r, opts) }
  puts json_generate(payload)
  exit 0
end

nodes = visible_nodes(roots, opts)
if opts[:screen_reader]
  print_screen_reader(nodes, roots, opts)
else
  print_tree(nodes, roots, opts)
end
