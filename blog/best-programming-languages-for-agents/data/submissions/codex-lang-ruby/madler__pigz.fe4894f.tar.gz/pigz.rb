#!/usr/bin/env ruby
# frozen_string_literal: true

require 'zlib'
require 'shellwords'
require 'find'
require 'stringio'

VERSION = 'pigz 2.8'

HELP = <<~TEXT
  Usage: pigz [options] [files ...]
    will compress files in place, adding the suffix '.gz'. If no files are
    specified, stdin will be compressed to stdout. pigz does what gzip does,
    but spreads the work over multiple processors and cores when compressing.

  Options:
    -0 to -9, -11        Compression level (level 11, zopfli, is much slower)
    --fast, --best       Compression levels 1 and 9 respectively
    -A, --alias xxx      Use xxx as the name for any --zip entry from stdin
    -b, --blocksize mmm  Set compression block size to mmmK (default 128K)
    -c, --stdout         Write all processed output to stdout (won't delete)
    -C, --comment ccc    Put comment ccc in the gzip or zip header
    -d, --decompress     Decompress the compressed input
    -f, --force          Force overwrite, compress .gz, links, and to terminal
    -F  --first          Do iterations first, before block split for -11
    -h, --help           Display a help screen and quit
    -H, --huffman        Use only Huffman coding for compression
    -i, --independent    Compress blocks independently for damage recovery
    -I, --iterations n   Number of iterations for -11 optimization
    -J, --maxsplits n    Maximum number of split blocks for -11
    -k, --keep           Do not delete original file after processing
    -K, --zip            Compress to PKWare zip (.zip) single entry format
    -l, --list           List the contents of the compressed input
    -L, --license        Display the pigz license and quit
    -m, --no-time        Do not store or restore mod time
    -M, --time           Store or restore mod time
    -n, --no-name        Do not store or restore file name or mod time
    -N, --name           Store or restore file name and mod time
    -O  --oneblock       Do not split into smaller blocks for -11
    -p, --processes n    Allow up to n compression threads (default is the
                         number of online processors, or 8 if unknown)
    -q, --quiet          Print no messages, even on error
    -r, --recursive      Process the contents of all subdirectories
    -R, --rsyncable      Input-determined block locations for rsync
    -S, --suffix .sss    Use suffix .sss instead of .gz (for compression)
    -t, --test           Test the integrity of the compressed input
    -U, --rle            Use run-length encoding for compression
    -v, --verbose        Provide more verbose output
    -V  --version        Show the version of pigz
    -Y  --synchronous    Force output file write to permanent storage
    -z, --zlib           Compress to zlib (.zz) instead of gzip format
    --                   All arguments after "--" are treated as files
TEXT

LICENSE = <<~TEXT
  Copyright (C) 2007-2023 Mark Adler <madler@alumni.caltech.edu>

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the author be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.
TEXT

class Pigz
  def initialize(argv, prog)
    @prog = File.basename(prog || 'pigz')
    @opts = {
      level: Zlib::DEFAULT_COMPRESSION, mode: :compress, stdout: false,
      keep: false, force: false, recursive: false, quiet: false, verbose: 0,
      suffix: '.gz', format: :gzip, name: true, time: true, comment: nil,
      alias_name: '-', name_explicit: false
    }
    @files = []
    all = []
    all.concat(Shellwords.split(ENV.fetch('GZIP', ''))) if ENV['GZIP']
    all.concat(Shellwords.split(ENV.fetch('PIGZ', ''))) if ENV['PIGZ']
    all.concat(argv)
    @opts[:mode] = :decompress if @prog.include?('unpigz')
    parse!(all)
  end

  def run
    if @opts[:mode] != :compress && !@opts[:name_explicit]
      @opts[:name] = false
      @opts[:time] = false
    end
    if @opts[:show_help]
      print HELP
      return 0
    end
    if @opts[:show_license]
      print LICENSE
      return 0
    end
    if @opts[:show_version]
      puts VERSION
      puts "zlib #{Zlib::ZLIB_VERSION}" if @opts[:verbose].positive?
      return 0
    end

    expand_files!
    if @files.empty?
      @opts[:stdout] = true
      process_stdin
    elsif @opts[:mode] == :list
      list_files
    else
      ok = true
      @files.each { |path| ok = false unless process_file(path) }
      ok ? 0 : 1
    end
  rescue SystemExit
    raise
  rescue StandardError => e
    error("abort: #{e.message}")
    1
  end

  private

  def parse!(args)
    i = 0
    literal = false
    while i < args.length
      a = args[i]
      if literal || a == '-' || !a.start_with?('-')
        @files << a
      elsif a == '--'
        literal = true
      elsif a.start_with?('--')
        i = parse_long(args, i)
      else
        i = parse_short(args, i)
      end
      i += 1
    end
  end

  def require_arg(args, i, opt)
    raise "option #{opt} requires an argument" if i + 1 >= args.length
    args[i + 1]
  end

  def parse_long(args, i)
    opt, val = args[i].split('=', 2)
    case opt
    when '--help' then @opts[:show_help] = true
    when '--license' then @opts[:show_license] = true
    when '--version' then @opts[:show_version] = true
    when '--fast' then @opts[:level] = 1
    when '--best' then @opts[:level] = 9
    when '--stdout', '--to-stdout' then @opts[:stdout] = true
    when '--decompress', '--uncompress' then @opts[:mode] = :decompress
    when '--force' then @opts[:force] = true
    when '--keep' then @opts[:keep] = true
    when '--zip' then @opts[:format] = :zip; @opts[:suffix] = '.zip'
    when '--zlib' then @opts[:format] = :zlib; @opts[:suffix] = '.zz'
    when '--list' then @opts[:mode] = :list
    when '--test' then @opts[:mode] = :test
    when '--quiet', '--silent' then @opts[:quiet] = true
    when '--verbose' then @opts[:verbose] += 1
    when '--recursive' then @opts[:recursive] = true
    when '--no-name' then @opts[:name] = false; @opts[:time] = false; @opts[:name_explicit] = true
    when '--name' then @opts[:name] = true; @opts[:time] = true; @opts[:name_explicit] = true
    when '--no-time' then @opts[:time] = false; @opts[:name_explicit] = true
    when '--time' then @opts[:time] = true; @opts[:name_explicit] = true
    when '--suffix', '--blocksize', '--processes', '--comment', '--alias', '--iterations', '--maxsplits'
      val ||= require_arg(args, i, opt)
      assign_value(opt, val)
      i += 1 unless args[i].include?('=')
    when '--huffman', '--rle', '--independent', '--rsyncable', '--synchronous', '--first', '--oneblock'
      # Accepted for compatibility. Ruby's zlib interface does not expose all pigz strategies portably.
    else
      raise "invalid option: #{args[i]}"
    end
    i
  end

  def parse_short(args, i)
    s = args[i][1..]
    if s == '11'
      @opts[:level] = 9
      return i
    end
    j = 0
    while j < s.length
      ch = s[j]
      if ('0'..'9').include?(ch)
        @opts[:level] = ch.to_i
      else
        case ch
        when 'h' then @opts[:show_help] = true
        when 'L' then @opts[:show_license] = true
        when 'V' then @opts[:show_version] = true
        when 'c' then @opts[:stdout] = true
        when 'd' then @opts[:mode] = :decompress
        when 'f' then @opts[:force] = true
        when 'k' then @opts[:keep] = true
        when 'K' then @opts[:format] = :zip; @opts[:suffix] = '.zip'
        when 'z' then @opts[:format] = :zlib; @opts[:suffix] = '.zz'
        when 'l' then @opts[:mode] = :list
        when 't' then @opts[:mode] = :test
        when 'q' then @opts[:quiet] = true
        when 'v' then @opts[:verbose] += 1
        when 'r' then @opts[:recursive] = true
        when 'n' then @opts[:name] = false; @opts[:time] = false; @opts[:name_explicit] = true
        when 'N' then @opts[:name] = true; @opts[:time] = true; @opts[:name_explicit] = true
        when 'm' then @opts[:time] = false; @opts[:name_explicit] = true
        when 'M' then @opts[:time] = true; @opts[:name_explicit] = true
        when 'H', 'U', 'i', 'R', 'Y', 'F', 'O'
        when 'A', 'b', 'p', 'S', 'C', 'I', 'J'
          val = s[(j + 1)..]
          if val.nil? || val.empty?
            val = require_arg(args, i, "-#{ch}")
            i += 1
          end
          assign_value("-#{ch}", val)
          break
        else
          raise "invalid option: -#{ch}"
        end
      end
      j += 1
    end
    i
  end

  def assign_value(opt, val)
    case opt
    when '-S', '--suffix' then @opts[:suffix] = val
    when '-C', '--comment' then @opts[:comment] = val
    when '-A', '--alias' then @opts[:alias_name] = val
    when '-b', '--blocksize', '-p', '--processes', '-I', '--iterations', '-J', '--maxsplits'
      Integer(val)
    end
  end

  def expand_files!
    return unless @opts[:recursive]
    expanded = []
    @files.each do |f|
      if File.directory?(f)
        Find.find(f) { |p| expanded << p if File.file?(p) }
      else
        expanded << f
      end
    end
    @files = expanded
  end

  def process_stdin
    data = STDIN.binmode.read
    case @opts[:mode]
    when :compress
      STDOUT.binmode.write(compress_data(data, nil, true))
    when :decompress
      STDOUT.binmode.write(decompress_data(data))
    when :test
      decompress_data(data)
    when :list
      list_one('-', data, STDOUT)
    end
    0
  end

  def process_file(path)
    return process_stdin if path == '-'
    unless File.exist?(path)
      error("skipping: #{path} does not exist")
      return false
    end
    if File.directory?(path)
      error("skipping: #{path} is a directory")
      return false
    end
    case @opts[:mode]
    when :compress then compress_file(path)
    when :decompress then decompress_file(path)
    when :test then test_file(path)
    when :list then list_file(path)
    end
  rescue StandardError => e
    error("skipping: #{path}: #{e.message}")
    false
  end

  def compress_file(path)
    if !@opts[:force] && (path.end_with?(@opts[:suffix]) || path.end_with?('.gz', '.zz', '.zip'))
      error("skipping: #{path} ends with compressed suffix")
      return false
    end
    data = File.binread(path)
    out = compress_data(data, path, false)
    if @opts[:stdout]
      STDOUT.binmode.write(out)
    else
      target = path + @opts[:suffix]
      return false unless writable_target?(target)
      File.binwrite(target, out)
      File.utime(File.atime(path), File.mtime(path), target) rescue nil
      File.delete(path) unless @opts[:keep]
      say("#{path} to #{target}") if @opts[:verbose].positive?
    end
    true
  end

  def decompress_file(path)
    data = File.binread(path)
    out = decompress_data(data)
    if @opts[:stdout]
      STDOUT.binmode.write(out)
    else
      target = output_name_for_decompress(path, data)
      return false unless writable_target?(target)
      File.binwrite(target, out)
      restore_mtime(target, path, data)
      File.delete(path) unless @opts[:keep]
      say("#{path} to #{target}") if @opts[:verbose].positive?
    end
    true
  end

  def test_file(path)
    decompress_data(File.binread(path))
    true
  end

  def list_file(path)
    list_one(path, File.binread(path), STDOUT)
    true
  end

  def list_files
    ok = true
    total_comp = 0
    total_orig = 0
    puts 'compressed   original reduced  name'
    @files.each do |path|
      begin
        data = path == '-' ? STDIN.binmode.read : File.binread(path)
        info = compressed_info(data)
        total_comp += info[:comp]
        total_orig += info[:orig]
        print_list_row(info[:comp], info[:orig], list_name(path, data))
      rescue StandardError => e
        error("skipping: #{path}: #{e.message}")
        ok = false
      end
    end
    print_list_row(total_comp, total_orig, '(totals)') if @files.length > 1
    ok ? 0 : 1
  end

  def writable_target?(path)
    return true if @opts[:force] || !File.exist?(path)
    error("skipping: #{path} exists")
    false
  end

  def compress_data(data, path, stdin)
    level = [[@opts[:level], 0].max, 9].min
    case @opts[:format]
    when :zlib
      Zlib::Deflate.deflate(data, level)
    when :zip
      zip_data(data, zip_entry_name(path, stdin), level)
    else
      gzip_data(data, path, stdin, level)
    end
  end

  def gzip_data(data, path, stdin, level)
    name = (!stdin && @opts[:name]) ? File.basename(path) : nil
    mtime = (!stdin && @opts[:time]) ? File.mtime(path).to_i : 0
    flags = 0
    flags |= 0x08 if name
    flags |= 0x10 if @opts[:comment]
    xfl = level == 9 ? 2 : (level == 1 ? 4 : 0)
    header = [0x1f, 0x8b, 8, flags, mtime, xfl, 3].pack('C4VCC')
    header << "#{name}\0" if name
    header << "#{@opts[:comment]}\0" if @opts[:comment]
    deflater = Zlib::Deflate.new(level, -Zlib::MAX_WBITS)
    body = deflater.deflate(data, Zlib::FINISH)
    deflater.close
    trailer = [Zlib.crc32(data), data.bytesize & 0xffffffff].pack('VV')
    header + body + trailer
  end

  def zip_entry_name(path, stdin)
    stdin ? @opts[:alias_name] : File.basename(path)
  end

  def zip_data(data, name, level)
    deflater = Zlib::Deflate.new(level, -Zlib::MAX_WBITS)
    comp = deflater.deflate(data, Zlib::FINISH)
    deflater.close
    crc = Zlib.crc32(data)
    n = name.b
    comment = (@opts[:comment] || '').b
    dos_time = dos_date_time(Time.now)
    local = [0x04034b50, 20, 0, 8, dos_time[0], dos_time[1], crc, comp.bytesize, data.bytesize, n.bytesize, 0].pack('VvvvvvVVVvv') + n + comp
    central_start = local.bytesize
    central = [0x02014b50, 0x031e, 20, 0, 8, dos_time[0], dos_time[1], crc, comp.bytesize, data.bytesize, n.bytesize, 0, comment.bytesize, 0, 0, 0, 0, 0].pack('VvvvvvvVVVvvvvvVV') + n + comment
    eocd = [0x06054b50, 0, 0, 1, 1, central.bytesize, central_start, 0].pack('VvvvvVVv')
    local + central + eocd
  end

  def dos_date_time(t)
    date = ((t.year - 1980) << 9) | (t.month << 5) | t.day
    time = (t.hour << 11) | (t.min << 5) | (t.sec / 2)
    [time, date]
  end

  def decompress_data(data)
    sig = data.byteslice(0, 4)
    if sig&.bytes == [0x50, 0x4b, 0x03, 0x04]
      unzip_data(data)
    elsif data.byteslice(0, 2)&.bytes == [0x1f, 0x8b]
      gunzip_data(data)
    else
      begin
        Zlib::Inflate.inflate(data)
      rescue Zlib::DataError
        Zlib::Inflate.new(-Zlib::MAX_WBITS).inflate(data)
      end
    end
  end

  def gunzip_data(data)
    rest = data.b
    out = +''
    until rest.empty?
      io = StringIO.new(rest)
      gz = Zlib::GzipReader.new(io)
      out << gz.read
      unused = gz.unused
      pos = io.pos
      gz.close
      rest = unused || rest.byteslice(pos..) || ''.b
      break if rest.empty?
    end
    out
  end

  def unzip_data(data)
    raise 'not a valid zip file' unless data.byteslice(0, 4).unpack1('V') == 0x04034b50
    fields = data.byteslice(4, 26).unpack('vvvvvVVVvv')
    method = fields[2]
    comp_size = fields[6]
    name_len = fields[8]
    extra_len = fields[9]
    start = 30 + name_len + extra_len
    comp = data.byteslice(start, comp_size)
    case method
    when 0 then comp
    when 8
      inflater = Zlib::Inflate.new(-Zlib::MAX_WBITS)
      out = inflater.inflate(comp)
      inflater.finish
      inflater.close
      out
    else
      raise "unsupported zip method #{method}"
    end
  end

  def output_name_for_decompress(path, data)
    if @opts[:name]
      n = gzip_original_name(data)
      return File.join(File.dirname(path), n) if n && !n.empty?
    end
    return "#{path[0...-4]}.tar" if path.end_with?('.tgz', '.taz')
    return path[0...-5] if path.end_with?('.svgz')
    [@opts[:suffix], '.gz', '.zz', '.zip', '-gz', '-zz', '-zip'].each do |suf|
      return path[0...-suf.length] if path.end_with?(suf)
    end
    "#{path}.out"
  end

  def gzip_original_name(data)
    return nil unless data.byteslice(0, 2)&.bytes == [0x1f, 0x8b]
    flg = data.getbyte(3)
    pos = 10
    pos += 2 + data.byteslice(pos, 2).unpack1('v') if (flg & 4) != 0
    return nil if (flg & 8).zero?
    nul = data.index("\0", pos)
    nul ? data.byteslice(pos...nul) : nil
  rescue StandardError
    nil
  end

  def restore_mtime(target, source, data)
    t = File.mtime(source)
    if @opts[:time] && data.byteslice(0, 2)&.bytes == [0x1f, 0x8b]
      mt = data.byteslice(4, 4).unpack1('V')
      t = Time.at(mt) if mt && mt.positive?
    end
    File.utime(Time.now, t, target)
  rescue StandardError
    nil
  end

  def list_one(path, data, out)
    info = compressed_info(data)
    out.puts 'compressed   original reduced  name'
    print_list_row(info[:comp], info[:orig], list_name(path, data), out)
  end

  def print_list_row(comp, orig, name, out = STDOUT)
    ratio = orig.zero? ? 0.0 : 100.0 * (orig - comp) / orig
    out.printf("%10d %10d %6.1f%%  %s\n", comp, orig, ratio, name)
  end

  def compressed_info(data)
    if data.byteslice(0, 2)&.bytes == [0x1f, 0x8b] && data.bytesize >= 8
      { comp: [data.bytesize - gzip_header_len(data) - 8, 0].max, orig: data.byteslice(-4, 4).unpack1('V') }
    elsif data.byteslice(0, 4)&.unpack1('V') == 0x04034b50
      f = data.byteslice(4, 26).unpack('vvvvvVVVvv')
      { comp: f[6], orig: f[7] }
    else
      out = decompress_data(data)
      { comp: data.bytesize, orig: out.bytesize }
    end
  end

  def gzip_header_len(data)
    flg = data.getbyte(3)
    pos = 10
    pos += 2 + data.byteslice(pos, 2).unpack1('v') if (flg & 4) != 0
    if (flg & 8) != 0
      nul = data.index("\0", pos)
      pos = nul ? nul + 1 : pos
    end
    if (flg & 16) != 0
      nul = data.index("\0", pos)
      pos = nul ? nul + 1 : pos
    end
    pos += 2 if (flg & 2) != 0
    pos
  end

  def list_name(path, data)
    if data.byteslice(0, 4)&.unpack1('V') == 0x04034b50
      name_len = data.byteslice(26, 2).unpack1('v')
      return data.byteslice(30, name_len) if name_len && name_len.positive?
    end
    n = gzip_original_name(data)
    n && !n.empty? ? n : path
  end

  def error(msg)
    warn "#{@prog}: #{msg}" unless @opts[:quiet]
  end

  def say(msg)
    warn msg unless @opts[:quiet]
  end
end

begin
  exit Pigz.new(ARGV, $PROGRAM_NAME).run
rescue StandardError => e
  warn "#{File.basename($PROGRAM_NAME)}: abort: #{e.message}"
  exit 22
end
