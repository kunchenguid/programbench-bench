#!/usr/bin/env ruby

class MelodyError < StandardError; end

Token = Struct.new(:type, :value, :line, :col)

class Lexer
  KEYWORDS = %w[match either capture ahead behind not some any option of to lazy]

  def initialize(src)
    @src = src
    @i = 0
    @line = 1
    @col = 1
  end

  def tokens
    out = []
    loop do
      skip_ws_comments
      break if eof?
      line = @line; col = @col
      ch = peek
      case ch
      when '"'
        out << Token.new(:string, read_string, line, col)
      when '<'
        out << Token.new(:symbol, read_symbol, line, col)
      when '{'
        advance; out << Token.new(:lbrace, '{', line, col)
      when '}'
        advance; out << Token.new(:rbrace, '}', line, col)
      when ';'
        advance; out << Token.new(:semi, ';', line, col)
      when /[0-9]/
        out << Token.new(:number, read_number, line, col)
      when /[A-Za-z_]/
        word = read_ident
        type = KEYWORDS.include?(word) ? word.to_sym : :ident
        out << Token.new(type, word, line, col)
      else
        raise MelodyError, "unexpected character #{ch.inspect}"
      end
    end
    out << Token.new(:eof, nil, @line, @col)
    out
  end

  private

  def eof? = @i >= @src.length
  def peek(n = 0) = @src[@i + n]

  def advance
    ch = @src[@i]
    @i += 1
    if ch == "\n"
      @line += 1; @col = 1
    else
      @col += 1
    end
    ch
  end

  def skip_ws_comments
    loop do
      while !eof? && peek =~ /\s/
        advance
      end
      if peek == '/' && peek(1) == '/'
        advance; advance
        advance while !eof? && peek != "\n"
      elsif peek == '/' && peek(1) == '*'
        advance; advance
        until eof? || (peek == '*' && peek(1) == '/')
          advance
        end
        advance; advance unless eof?
      else
        break
      end
    end
  end

  def read_string
    advance
    s = +''
    until eof?
      ch = advance
      return s if ch == '"'
      if ch == '\\'
        raise MelodyError, 'unterminated escape' if eof?
        esc = advance
        s << case esc
             when '"' then '"'
             when '\\' then '\\'
             when 'n' then '\n'
             when 't' then '\t'
             when 'r' then '\r'
             when '0' then '\0'
             else esc
             end
      else
        s << ch
      end
    end
    raise MelodyError, 'unterminated string'
  end

  def read_symbol
    advance
    s = +''
    until eof?
      ch = advance
      return s if ch == '>'
      s << ch
    end
    raise MelodyError, 'unterminated symbol'
  end

  def read_number
    s = +''
    s << advance while !eof? && peek =~ /[0-9]/
    s.to_i
  end

  def read_ident
    s = +''
    s << advance while !eof? && peek =~ /[A-Za-z0-9_]/
    s
  end
end

class Parser
  SYMBOLS = {
    'char' => '.', 'space' => ' ', 'whitespace' => '\s', 'digit' => '\d', 'word' => '\w',
    'alphabetic' => '[a-zA-Z]', 'alphanumeric' => '[a-zA-Z0-9]', 'newline' => '\n',
    'tab' => '\t', 'return' => '\r', 'null' => '\0', 'backspace' => '[\b]',
    'boundary' => '\b', 'start' => '^', 'end' => '$'
  }
  NEG_SYMBOLS = {
    'space' => '[^ ]', 'whitespace' => '\S', 'digit' => '\D', 'word' => '\W',
    'alphabetic' => '[^a-zA-Z]', 'alphanumeric' => '[^a-zA-Z0-9]', 'newline' => '[^\n]',
    'tab' => '[^\t]', 'return' => '[^\r]', 'null' => '[^\0]', 'backspace' => '[^\b]',
    'boundary' => '\B'
  }

  def initialize(src)
    @tokens = Lexer.new(src).tokens
    @pos = 0
  end

  def parse
    parts = []
    until check(:eof)
      parts << expr
      match(:semi)
    end
    parts.join
  end

  private

  def current = @tokens[@pos]
  def check(type) = current.type == type
  def advance = (@pos += 1; @tokens[@pos - 1])
  def match(type) = (advance if check(type))

  def expect(type)
    return advance if check(type)
    raise MelodyError, "expected #{type}"
  end

  def expr
    if check(:lazy) || check(:some) || check(:any) || check(:option) || check(:number)
      quantifier
    elsif check(:not)
      not_expr
    else
      atom
    end
  end

  def quantifier
    lazy = !!match(:lazy)
    q = nil
    if match(:some)
      q = '+'
    elsif match(:any)
      q = '*'
    elsif match(:option)
      q = '?'
    elsif check(:number)
      first = advance.value
      if match(:to)
        second = expect(:number).value
        q = "{#{first},#{second}}"
      else
        q = "{#{first}}"
      end
    else
      raise MelodyError, 'expected amount'
    end
    expect(:of)
    body = atom
    body = "(?:#{body})" if needs_group_for_quant?(body)
    body + q + (lazy ? '?' : '')
  end

  def needs_group_for_quant?(s)
    return false if s.start_with?('(?:', '(', '[', '\\') || s.length == 1
    true
  end

  def atom
    if check(:string)
      escape_literal(advance.value)
    elsif check(:symbol)
      sym = advance.value
      unless SYMBOLS.key?(sym)
        raise MelodyError, 'usage of an unrecognized symbol'
      end
      SYMBOLS[sym]
    elsif check(:match)
      advance; "(?:#{block_body})"
    elsif check(:either)
      advance; "(?:#{block_parts.join('|')})"
    elsif check(:capture)
      advance
      name = check(:ident) ? advance.value : nil
      name ? "(?<#{name}>#{block_body})" : "(#{block_body})"
    elsif check(:ahead)
      advance; "(?=#{block_body})"
    elsif check(:behind)
      advance; "(?<=#{block_body})"
    else
      raise MelodyError, 'expected root'
    end
  end

  def not_expr
    expect(:not)
    if check(:ahead)
      advance; return "(?!#{block_body})"
    elsif check(:behind)
      advance; return "(?<!#{block_body})"
    elsif check(:symbol)
      sym = advance.value
      val = NEG_SYMBOLS[sym]
      raise MelodyError, "negative #{sym} not allowed" unless val
      return val
    end
    raise MelodyError, 'expected amount or assertion_type'
  end

  def block_body
    block_parts.join
  end

  def block_parts
    expect(:lbrace)
    parts = []
    until check(:rbrace) || check(:eof)
      parts << expr
      match(:semi)
    end
    expect(:rbrace)
    parts
  end

  def escape_literal(s)
    s.gsub(/([.\\*+?\^$()\[\]{}|])/) { "\\#{$1}" }
  end
end

def compile(src)
  Parser.new(src).parse
end

def help
  <<~TXT.chomp
    A CLI wrapping the Melody language compiler

    Usage: executable [OPTIONS] [INPUT_FILE_PATH]

    Arguments:
      [INPUT_FILE_PATH]  Read from a file
                         Use '-' and or pipe input to read from stdin

    Options:
      -o, --output <OUTPUT_FILE_PATH>           Write to a file
      -n, --no-color                            Print output with no color
      -r, --repl                                Start the Melody REPL
          --generate-completions <completions>  Outputs completions for the selected shell
                                                To use, write the output to the appropriate location for your shell
      -t, --test <test>                         Test the compiled regex against a string
      -f, --test-file <test-file>               Test the compiled regex against the contents of a file
      -h, --help                                Print help
      -V, --version                             Print version
  TXT
end

def read_input(path)
  if path.nil? || path == '-'
    STDIN.read
  else
    begin
      File.read(path)
    rescue
      warn "Error: unable read file at path #{path}"
      exit 65
    end
  end
end

def repl
  loop do
    print '> '
    line = STDIN.gets
    break unless line
    begin
      puts compile(line)
    rescue MelodyError => e
      warn "Error: #{e.message}"
    end
  end
end

args = ARGV.dup
output = nil
test = nil
test_file = nil
input = nil
no_color = false

until args.empty?
  a = args.shift
  case a
  when '-h', '--help'
    puts help
    exit 0
  when '-V', '--version'
    puts 'melody_cli 0.20.0'
    exit 0
  when '-n', '--no-color'
    no_color = true
  when '-r', '--repl'
    repl
    exit 0
  when '-o', '--output'
    output = args.shift or (warn "error: a value is required for '#{a} <OUTPUT_FILE_PATH>' but none was supplied"; exit 2)
  when '-t', '--test'
    test = args.shift or (warn "error: a value is required for '#{a} <test>' but none was supplied"; exit 2)
  when '-f', '--test-file'
    test_file = args.shift or (warn "error: a value is required for '#{a} <test-file>' but none was supplied"; exit 2)
  when '--generate-completions'
    shell = args.shift || ''
    puts "# completion script for #{shell}"
    exit 0
  else
    if a == '-'
      if input.nil?
        input = a
      else
        warn "error: unexpected argument '#{a}' found"
        warn
        warn "Usage: executable [OPTIONS] [INPUT_FILE_PATH]"
        warn
        warn "For more information, try '--help'."
        exit 2
      end
    elsif a.start_with?('-')
      warn "error: unexpected argument '#{a}' found"
      warn
      warn "Usage: executable [OPTIONS] [INPUT_FILE_PATH]"
      warn
      warn "For more information, try '--help'."
      exit 2
    elsif input.nil?
      input = a
    else
      warn "error: unexpected argument '#{a}' found"
      warn
      warn "Usage: executable [OPTIONS] [INPUT_FILE_PATH]"
      warn
      warn "For more information, try '--help'."
      exit 2
    end
  end
end

begin
  regex = compile(read_input(input))
rescue MelodyError => e
  warn "Error: #{e.message}"
  exit 65
end

if output
  File.write(output, regex)
elsif test || test_file
  target = test || begin
    File.read(test_file)
  rescue
    warn "Error: unable read file at path #{test_file}"
    exit 65
  end
  matched = Regexp.new(regex).match?(target)
  label = test ? "'#{target}'" : test_file
  puts "#{label} #{matched ? 'matched' : 'did not match'}"
else
  puts regex
end
