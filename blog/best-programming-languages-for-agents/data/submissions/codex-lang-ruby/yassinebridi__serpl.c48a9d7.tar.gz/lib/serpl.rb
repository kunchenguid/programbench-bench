# frozen_string_literal: true

require "find"

module Serpl
  HELP = <<~TEXT
    A simple terminal UI for search and replace, ala VS Code

    Usage: executable [OPTIONS]

    Options:
      -p, --project-root <PATH>  Path to the project root [default: .]
      -h, --help                 Print help
      -V, --version              Print version
  TEXT

  def self.config_dir
    base = ENV["XDG_CONFIG_HOME"]
    base = File.join(ENV.fetch("HOME", "."), ".config") if base.nil? || base.empty?
    File.join(base, "serpl")
  end

  def self.version_text
    <<~TEXT
      serpl 0.3.4- (2026-04-20)

      Authors: Yassine Bridi <ybridi@gmail.com>

      Config directory: #{config_dir}
    TEXT
  end

  class CLI
    def initialize(argv)
      @argv = argv.dup
      @project_root = "."
    end

    def run
      parse_result = parse
      return parse_result if parse_result.is_a?(Integer)

      unless STDIN.tty? && STDOUT.tty?
        warn_startup_error
        return 1
      end

      TerminalUI.new(@project_root).run
      0
    rescue Interrupt
      0
    rescue StandardError => e
      warn "serpl error: Something went wrong"
      warn "Error: "
      warn "   0: \e[91m#{e.message}\e[0m"
      1
    end

    private

    def parse
      return help if @argv.any? { |arg| arg == "-h" || arg == "--help" || arg.start_with?("-h=") }
      return version if @argv.any? { |arg| arg == "-V" || arg == "--version" || arg.start_with?("-V=") }

      @argv.each do |arg|
        if arg.start_with?("--help=")
          return error("unexpected value '#{arg.split("=", 2)[1]}' for '--help' found; no more were expected\n\nUsage: executable --help")
        elsif arg.start_with?("--version=")
          return error("unexpected value '#{arg.split("=", 2)[1]}' for '--version' found; no more were expected\n\nUsage: executable --version")
        end
      end

      i = 0
      while i < @argv.length
        arg = @argv[i]
        case arg
        when "-p", "--project-root"
          value = @argv[i + 1]
          if value.nil?
            return error("a value is required for '--project-root <PATH>' but none was supplied")
          elsif value.start_with?("-")
            return error("unexpected argument '#{value}' found\n\nUsage: executable [OPTIONS]")
          end
          @project_root = value
          i += 2
        else
          if arg.start_with?("--project-root=")
            @project_root = arg.split("=", 2)[1]
          elsif arg.start_with?("-p=")
            @project_root = arg.split("=", 2)[1]
          elsif arg.start_with?("-p") && arg.length > 2
            @project_root = arg[2..]
          else
            return error("unexpected argument '#{arg}' found\n\nUsage: executable [OPTIONS]")
          end
          i += 1
        end
      end

      true
    end

    def help
      print HELP
      0
    end

    def version
      print Serpl.version_text
      0
    end

    def error(message)
      $stderr.puts "error: #{message}"
      $stderr.puts
      $stderr.puts "For more information, try '--help'."
      2
    end

    def warn_startup_error
      warn "serpl error: Something went wrong"
      warn "Error: "
      warn "   0: \e[91mResource temporarily unavailable (os error 11)\e[0m"
    end
  end

  class TerminalUI
    TEXT_EXTENSIONS = %w[
      .c .cc .conf .cpp .css .csv .go .h .hpp .html .ini .java .js .json .json5
      .md .py .rb .rs .sh .toml .ts .tsx .txt .xml .yaml .yml
    ].freeze

    def initialize(project_root)
      @project_root = File.expand_path(project_root)
      @query = ""
      @replacement = ""
      @mode = :search
      @message = "Ctrl-d/Ctrl-c quit | Tab switch field | Ctrl-r refresh | Ctrl-o replace"
      @matches = []
    end

    def run
      with_raw_terminal do |input|
        enter_alternate_screen
        refresh
        loop do
          render
          key = input.read(1)
          break if key.nil? || key == "\u0003" || key == "\u0004"

          handle_key(key, input)
        end
      ensure
        leave_alternate_screen
      end
    end

    private

    def handle_key(key, input)
      case key
      when "\t"
        @mode = @mode == :search ? :replace : :search
      when "\u0012"
        refresh
      when "\u000f"
        process_replace
      when "\u007f", "\b"
        current.chop!
        refresh
      when "\r", "\n"
        @mode = @mode == :search ? :replace : :search
      when "\e"
        drain_escape(input)
      else
        current << key if key.bytes.all? { |b| b >= 32 && b != 127 }
        refresh if @mode == :search
      end
    end

    def current
      @mode == :search ? @query : @replacement
    end

    def drain_escape(input)
      while IO.select([input], nil, nil, 0.001)
        input.read_nonblock(1)
      end
    rescue IO::WaitReadable
      nil
    end

    def refresh
      @matches = []
      if @query.empty?
        @message = "Type a search string"
        return
      end

      Find.find(@project_root) do |path|
        next if path == @project_root
        if File.directory?(path)
          Find.prune if [".git", "node_modules", "target", "vendor"].include?(File.basename(path))
          next
        end
        next unless text_file?(path)

        File.readlines(path, chomp: true).each_with_index do |line, index|
          @matches << [relative(path), index + 1, line] if line.include?(@query)
          break if @matches.length >= 200
        end
        break if @matches.length >= 200
      rescue StandardError
        next
      end
      @message = "#{@matches.length} match#{@matches.length == 1 ? "" : "es"}"
    end

    def process_replace
      return @message = "No search string" if @query.empty?

      changed = 0
      Find.find(@project_root) do |path|
        next if File.directory?(path)
        next unless text_file?(path)

        content = File.binread(path)
        next unless content.include?(@query)

        File.binwrite(path, content.gsub(@query, @replacement))
        changed += 1
      rescue StandardError
        next
      end
      refresh
      @message = "Replaced in #{changed} file#{changed == 1 ? "" : "s"}"
    end

    def text_file?(path)
      return true if TEXT_EXTENSIONS.include?(File.extname(path))

      sample = File.binread(path, 1024)
      !sample.include?("\x00")
    rescue StandardError
      false
    end

    def relative(path)
      path.delete_prefix(@project_root + File::SEPARATOR)
    end

    def render
      rows, cols = terminal_size
      rows = 24 if rows.nil? || rows < 8
      cols = 80 if cols.nil? || cols < 30
      visible = [rows - 7, 1].max

      out = +""
      out << "\e[H\e[2J"
      out << fit("serpl", cols) << "\n"
      out << fit("Project: #{@project_root}", cols) << "\n"
      out << fit("#{@mode == :search ? ">" : " "} Search: #{@query}", cols) << "\n"
      out << fit("#{@mode == :replace ? ">" : " "} Replace: #{@replacement}", cols) << "\n"
      out << fit(@message, cols) << "\n"
      out << fit("-" * cols, cols) << "\n"
      @matches.first(visible).each do |file, line_no, line|
        out << fit("#{file}:#{line_no}: #{line}", cols) << "\n"
      end
      print out
    end

    def fit(text, cols)
      text = text.to_s
      text.length > cols ? text[0, cols] : text.ljust(cols)
    end

    def enter_alternate_screen
      print "\e[?1049h\e[?25l\e[H"
    end

    def leave_alternate_screen
      print "\e[?25h\e[?1049l"
    end

    def with_raw_terminal
      saved = `stty -g 2>/dev/null`.strip
      system("stty raw -echo 2>/dev/null")
      yield STDIN
    ensure
      system("stty #{saved} 2>/dev/null") unless saved.nil? || saved.empty?
    end

    def terminal_size
      size = `stty size 2>/dev/null`.split.map(&:to_i)
      size.length == 2 ? size : [24, 80]
    end
  end
end
