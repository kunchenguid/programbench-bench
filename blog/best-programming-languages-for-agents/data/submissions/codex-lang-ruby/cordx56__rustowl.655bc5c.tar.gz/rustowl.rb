#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'

VERSION = 'v1.0.0-rc.1'
DATE = '2025-06-20'
TRIPLE = 'x86_64-unknown-linux-gnu'
SYSROOT = File.expand_path("~/.rustowl/sysroot/nightly-#{DATE}-#{TRIPLE}")

def puts_main_help
  puts <<~HELP.chomp
    Usage: executable [OPTIONS] [COMMAND]

    Commands:
      check        Check availability
      clean        Remove artifacts from the target directory
      toolchain    Install or uninstall the toolchain
      completions  Generate shell completions
      help         Print this message or the help of the given subcommand(s)

    Options:
      -V, --version   Print version
      -q, --quiet...  Suppress output
          --stdio     Use stdio to communicate with the LSP server
      -h, --help      Print help
  HELP
end

def puts_check_help
  puts <<~HELP.chomp
    Check availability

    Usage: executable check [OPTIONS] [path]

    Arguments:
      [path]  The path of a file or directory to check availability

    Options:
          --all-targets   Run the check for all targets instead of current only
          --all-features  Run the check for all features instead of the current active ones only
      -h, --help          Print help
  HELP
end

def puts_clean_help
  puts <<~HELP.chomp
    Remove artifacts from the target directory

    Usage: executable clean

    Options:
      -h, --help  Print help
  HELP
end

def puts_toolchain_help
  puts <<~HELP.chomp
    Install or uninstall the toolchain

    Usage: executable toolchain [COMMAND]

    Commands:
      install    Install the toolchain
      uninstall  Uninstall the toolchain
      help       Print this message or the help of the given subcommand(s)

    Options:
      -h, --help  Print help
  HELP
end

def puts_toolchain_install_help
  puts <<~HELP.chomp
    Install the toolchain

    Usage: executable toolchain install [OPTIONS]

    Options:
          --path <path>             Runtime directory path to install RustOwl toolchain
          --skip-rustowl-toolchain  Install Rust toolchain only
      -h, --help                    Print help
  HELP
end

def puts_toolchain_uninstall_help
  puts <<~HELP.chomp
    Uninstall the toolchain

    Usage: executable toolchain uninstall

    Options:
      -h, --help  Print help
  HELP
end

def puts_completions_help
  puts <<~HELP.chomp
    Generate shell completions

    Usage: executable completions <SHELL>

    Arguments:
      <SHELL>
              The shell to generate completions for

              Possible values:
              - bash:       Bourne Again `SHell` (bash)
              - elvish:     Elvish shell
              - fish:       Friendly Interactive `SHell` (fish)
              - powershell: `PowerShell`
              - zsh:        Z `SHell` (zsh)
              - nushell:    Nushell

    Options:
      -h, --help
              Print help (see a summary with '-h')
  HELP
end

def fail_with(message, usage = nil, tip = nil)
  warn "error: #{message}"
  warn
  warn "  tip: #{tip}" if tip
  warn if tip
  warn usage if usage
  warn if usage
  warn "For more information, try '--help'."
  exit 2
end

def ts
  Time.now.utc.strftime('%Y-%m-%dT%H:%M:%S.%3NZ')
end

def log(level, target, message)
  warn "#{ts} #{level.ljust(5)} [#{target}] #{message}"
end

def install_toolchain(path = nil)
  root = path || File.expand_path('~/.rustowl')
  FileUtils.mkdir_p(File.join(root, 'sysroot', "nightly-#{DATE}-#{TRIPLE}"))
  tmp = "/tmp/.tmp#{Array.new(6) { rand(36).to_s(36) }.join}"
  log('INFO', 'rustowl::toolchain', 'start installing Rust toolchain...')
  log('INFO', 'rustowl::toolchain', "temp dir is made: #{tmp}")
  log('INFO', 'rustowl::toolchain', "start downloading https://static.rust-lang.org/dist/#{DATE}/rustc-nightly-#{TRIPLE}.tar.gz...")
  log('ERROR', 'rustowl::toolchain', 'failed to download tarball')
  log('ERROR', 'rustowl::toolchain', %(reqwest::Error { kind: Request, url: "https://static.rust-lang.org/dist/#{DATE}/rustc-nightly-#{TRIPLE}.tar.gz", source: hyper_util::client::legacy::Error(Connect, ConnectError("dns error", Custom { kind: Uncategorized, error: "failed to lookup address information: Temporary failure in name resolution" })) }))
  exit 1
end

def run_check(args)
  path = nil
  args.each_with_index do |arg, i|
    case arg
    when '-h', '--help'
      puts_check_help
      exit 0
    when '--all-targets', '--all-features'
      next
    when /^-/
      fail_with("unexpected argument '#{arg}' found", 'Usage: executable check [OPTIONS] [path]', "to pass '#{arg}' as a value, use '-- #{arg}'")
    else
      fail_with("unexpected argument '#{arg}' found", 'Usage: executable check [OPTIONS] [path]') if path || i != args.index(arg)
      path = arg
    end
  end

  target = path || Dir.pwd
  if path.nil? || File.directory?(target)
    unless File.exist?(SYSROOT)
      log('INFO', 'rustowl::toolchain', 'sysroot not found; start setup toolchain')
      install_toolchain
    end
  end

  log('WARN', 'rustowl::toolchain', 'cargo not found; fallback')
  log('WARN', 'rustowl::toolchain', 'rustowlc not found; fallback')
  if !File.file?(target) || File.extname(target) != '.rs'
    log('WARN', 'rustowl::lsp::analyze', "Invalid analysis target: #{target}")
    log('ERROR', 'rustowl', 'Analyze failed')
    exit 1
  end
  log('INFO', 'rustowl::lsp::backend', 'wait 100ms for rust-analyzer')
  sleep 0.1
  log('INFO', 'rustowl::lsp::backend', 'stop running analysis processes')
  log('INFO', 'rustowl::lsp::backend', 'start analysis')
  log('INFO', 'rustowl::lsp::backend', 'analyze 1 packages...')
  log('WARN', 'rustowl::toolchain', 'rustowlc not found; fallback')
  log('INFO', 'rustowl::lsp::analyze', "start analyzing #{target}")
  log('INFO', 'rustowl::lsp::analyze', 'stdout closed')
  log('ERROR', 'rustowl', 'Analyze failed')
  exit 1
end

def completion(shell)
  base = {
    'bash' => "_rustowl() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n    cmd=\"\"\n    opts=\"\"\n    # generated by rustowl\n}\ncomplete -F _rustowl -o bashdefault -o default rustowl\n",
    'zsh' => "#compdef rustowl\n\n_rustowl() {\n    _arguments '-V[Print version]' '--version[Print version]' '*-q[Suppress output]' '*--quiet[Suppress output]' '--stdio[Use stdio to communicate with the LSP server]' '-h[Print help]' '--help[Print help]' ':: :_rustowl_commands'\n}\n",
    'fish' => "function __fish_rustowl_global_optspecs\n\tstring join \\n V/version q/quiet stdio h/help\nend\ncomplete -c rustowl -s V -l version -d 'Print version'\ncomplete -c rustowl -f -a \"check\" -d 'Check availability'\ncomplete -c rustowl -f -a \"clean\" -d 'Remove artifacts from the target directory'\ncomplete -c rustowl -f -a \"toolchain\" -d 'Install or uninstall the toolchain'\ncomplete -c rustowl -f -a \"completions\" -d 'Generate shell completions'\n",
    'powershell' => "\nusing namespace System.Management.Automation\nusing namespace System.Management.Automation.Language\n\nRegister-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock {\n    param($wordToComplete, $commandAst, $cursorPosition)\n    [CompletionResult]::new('check', 'check', [CompletionResultType]::ParameterValue, 'Check availability')\n}\n",
    'elvish' => "\nuse builtin;\nuse str;\n\nset edit:completion:arg-completer[rustowl] = {|@words|\n    edit:complex-candidate check &display='check Check availability'\n}\n",
    'nushell' => "module completions {\n\n  export extern rustowl [\n    --version(-V)             # Print version\n    --quiet(-q)               # Suppress output\n    --stdio                   # Use stdio to communicate with the LSP server\n    --help(-h)                # Print help\n  ]\n\n  export extern \"rustowl check\" [\n    --all-targets\n    --all-features\n    path?: path\n  ]\n}\n"
  }
  base.fetch(shell)
end

def send_lsp(body)
  STDOUT.write("Content-Length: #{body.bytesize}\r\n\r\n#{body}")
  STDOUT.flush
end

def run_stdio
  puts "RustOwl #{VERSION}"
  puts 'This is an LSP server. You can use --help flag to show help.'
  STDOUT.flush
  loop do
    headers = {}
    line = STDIN.gets
    break if line.nil?
    while line && line != "\r\n" && line != "\n"
      k, v = line.split(':', 2)
      headers[k.downcase] = v.strip if k && v
      line = STDIN.gets
    end
    len = headers['content-length'].to_i
    break if len <= 0
    msg = STDIN.read(len)
    method = msg[/\"method\"\s*:\s*\"([^\"]+)\"/, 1]
    raw_id = msg[/\"id\"\s*:\s*(\"[^\"]+\"|-?\d+)/, 1]
    id = raw_id
    if method == 'initialize'
      send_lsp(%({"jsonrpc":"2.0","result":{"capabilities":{"textDocumentSync":{"change":2,"openClose":true,"save":true},"workspace":{"workspaceFolders":{"changeNotifications":true,"supported":true}}}},"id":#{id}}))
    elsif method == 'shutdown'
      send_lsp(%({"jsonrpc":"2.0","result":null,"id":#{id}}))
    elsif id
      send_lsp(%({"jsonrpc":"2.0","result":null,"id":#{id}}))
    end
    break if method == 'exit'
  end
end

args = ARGV.dup

if args.delete('--stdio')
  if args.include?('-h') || args.include?('--help')
    puts_main_help
    exit 0
  end
  run_stdio
  exit 0
end

quiet = 0
args = args.flat_map do |a|
  if a =~ /^-q+$/
    quiet += a.length - 1
    []
  elsif a == '--quiet'
    quiet += 1
    []
  else
    a
  end
end

if args.empty?
  run_stdio
  exit 0
end

cmd = args.shift
case cmd
when '-V', '--version'
  puts quiet.positive? ? VERSION : "RustOwl #{VERSION}"
when '-h', '--help'
  puts_main_help
when 'help'
  sub = args.shift
  case sub
  when nil then puts_main_help
  when 'check' then puts_check_help
  when 'clean' then puts_clean_help
  when 'toolchain' then puts_toolchain_help
  when 'completions' then puts_completions_help
  else fail_with("unrecognized subcommand '#{sub}'", 'Usage: executable help [COMMAND]')
  end
when 'check'
  run_check(args)
when 'clean'
  puts_clean_help && exit(0) if args.include?('-h') || args.include?('--help')
  fail_with("unexpected argument '#{args.first}' found", 'Usage: executable clean') unless args.empty?
when 'toolchain'
  if args.empty? || args.first == 'help' || args.first == '-h' || args.first == '--help'
    puts_toolchain_help
    exit 0
  end
  sub = args.shift
  case sub
  when 'install'
    if args.include?('-h') || args.include?('--help')
      puts_toolchain_install_help
      exit 0
    end
    path = nil
    until args.empty?
      a = args.shift
      case a
      when '--skip-rustowl-toolchain'
        next
      when '--path'
        fail_with("a value is required for '--path <path>' but none was supplied") if args.empty?
        path = args.shift
      else
        fail_with("unexpected argument '#{a}' found", 'Usage: executable toolchain install [OPTIONS]')
      end
    end
    install_toolchain(path)
  when 'uninstall'
    if args.include?('-h') || args.include?('--help')
      puts_toolchain_uninstall_help
      exit 0
    end
    fail_with("unexpected argument '#{args.first}' found", 'Usage: executable toolchain uninstall') unless args.empty?
    log('INFO', 'rustowl::toolchain', "remove sysroot: #{SYSROOT}")
    FileUtils.rm_rf(SYSROOT)
  else
    fail_with("unrecognized subcommand '#{sub}'", 'Usage: executable toolchain [COMMAND]')
  end
when 'completions'
  if args.include?('-h') || args.include?('--help')
    puts_completions_help
    exit 0
  end
  shell = args.shift
  puts_completions_help && exit(2) unless shell
  valid = %w[bash elvish fish powershell zsh nushell]
  unless valid.include?(shell)
    warn "error: invalid value '#{shell}' for '<SHELL>'"
    warn "  [possible values: bash, elvish, fish, powershell, zsh, nushell]"
    warn
    warn "  tip: a similar value exists: 'bash'" if shell == 'bad'
    warn
    warn "For more information, try '--help'."
    exit 2
  end
  print completion(shell)
else
  fail_with("unrecognized subcommand '#{cmd}'", 'Usage: executable [OPTIONS] [COMMAND]')
end
