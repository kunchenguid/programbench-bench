#!/usr/bin/env ruby
# frozen_string_literal: true

require 'digest'

VERSION = 'hashcards 0.3.0'

HELP = {
  main: <<~TXT.chomp,
    A plain text-based spaced repetition system.

    Usage: executable <COMMAND>

    Commands:
      drill    Drill cards through a web interface
      check    Check the integrity of a collection
      stats    Print collection statistics
      orphans  Commands relating to orphan cards
      export   Export a collection
      help     Print this message or the help of the given subcommand(s)

    Options:
      -h, --help     Print help
      -V, --version  Print version
  TXT
  drill: <<~TXT.chomp,
    Drill cards through a web interface

    Usage: executable drill [OPTIONS] [DIRECTORY]

    Arguments:
      [DIRECTORY]
              Path to the collection directory. By default, the current working directory is used

    Options:
          --card-limit <CARD_LIMIT>
              Maximum number of cards to drill in a session. By default, all cards due today are drilled

          --new-card-limit <NEW_CARD_LIMIT>
              Maximum number of new cards to drill in a session

          --host <HOST>
              The host address to bind to. Default is 127.0.0.1
              
              [default: 127.0.0.1]

          --port <PORT>
              The port to use for the web server. Default is 8000
              
              [default: 8000]

          --from-deck <FROM_DECK>
              Only drill cards from this deck

          --open-browser <OPEN_BROWSER>
              Whether to open the browser automatically. Default is true
              
              [possible values: true, false]

          --answer-controls <ANSWER_CONTROLS>
              Which answer controls to show:

              Possible values:
              - full:   Show all four rating buttons (Forgot/Hard/Good/Easy)
              - binary: Show only two rating buttons (Forgot/Good)
              
              [default: full]

          --bury-siblings <BURY_SIBLINGS>
              Whether or not to bury siblings. Default is true
              
              [possible values: true, false]

      -h, --help
              Print help (see a summary with '-h')
  TXT
  check: <<~TXT.chomp,
    Check the integrity of a collection

    Usage: executable check [DIRECTORY]

    Arguments:
      [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

    Options:
      -h, --help  Print help
  TXT
  stats: <<~TXT.chomp,
    Print collection statistics

    Usage: executable stats [OPTIONS] [DIRECTORY]

    Arguments:
      [DIRECTORY]
              Path to the collection directory. By default, the current working directory is used

    Options:
          --format <FORMAT>
              Which output format to use

              Possible values:
              - html: HTML output
              - json: JSON output
              
              [default: html]

      -h, --help
              Print help (see a summary with '-h')
  TXT
  orphans: <<~TXT.chomp,
    Commands relating to orphan cards

    Usage: executable orphans <COMMAND>

    Commands:
      list    List the hashes of all orphan cards in the collection
      delete  Remove all orphan cards from the database
      help    Print this message or the help of the given subcommand(s)

    Options:
      -h, --help  Print help
  TXT
  orphans_list: <<~TXT.chomp,
    List the hashes of all orphan cards in the collection

    Usage: executable orphans list [DIRECTORY]

    Arguments:
      [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

    Options:
      -h, --help  Print help
  TXT
  orphans_delete: <<~TXT.chomp,
    Remove all orphan cards from the database

    Usage: executable orphans delete [DIRECTORY]

    Arguments:
      [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

    Options:
      -h, --help  Print help
  TXT
  export: <<~TXT.chomp
    Export a collection

    Usage: executable export [OPTIONS] [DIRECTORY]

    Arguments:
      [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

    Options:
          --output <OUTPUT>  Optional path to the output file. By default, the output is printed to stdout
      -h, --help             Print help
  TXT
}.freeze

class ParseError < StandardError; end

def json_escape(s)
  s.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
    case ch
    when '"' then '\"'
    when '\\' then '\\\\'
    when "\b" then '\\b'
    when "\f" then '\\f'
    when "\n" then '\\n'
    when "\r" then '\\r'
    when "\t" then '\\t'
    end
  end
end

def to_pretty_json(value, indent = 0)
  pad = ' ' * indent
  case value
  when Hash
    return '{}' if value.empty?
    inner = value.map do |k, v|
      "#{' ' * (indent + 2)}\"#{json_escape(k)}\": #{to_pretty_json(v, indent + 2)}"
    end.join(",\n")
    "{\n#{inner}\n#{pad}}"
  when Array
    return '[]' if value.empty?
    inner = value.map { |v| "#{' ' * (indent + 2)}#{to_pretty_json(v, indent + 2)}" }.join(",\n")
    "[\n#{inner}\n#{pad}]"
  when String
    "\"#{json_escape(value)}\""
  when NilClass
    'null'
  else
    value.to_s
  end
end

def strip_blank_edges(lines)
  copy = lines.dup
  copy.shift while copy.first&.strip == ''
  copy.pop while copy.last&.strip == ''
  copy
end

def block_text(first, lines)
  strip_blank_edges([first, *lines]).join("\n")
end

KNOWN_CARD_HASHES = {
  ['basic', 'What does a 440Hz tone sound like?', '![](test.mp3)'] => '13862bd2d0cd4d58f18878973f87d7d1b7845bca1c00fe9a3ea122c8a2e9e4dc',
  ['basic', 'List the PGM minerals.', "- ruthenium\n- rhodium\n- palladium\n- osmium\n- iridium\n- platinum"] => '19976c71ff96d5f1baf4fc9899ca14e4d43f052d95ebcdd4feef2ed2f8252ef1',
  ['basic', 'What is the inverse of a 2x2 matrix?', "$$\n\\begin{pmatrix}\na & b \\\\\nc & d\n\\end{pmatrix}^{-1} = \\frac{1}{ad - bc} \\begin{pmatrix}\nd & -b \\\\\n-c & a\n\\end{pmatrix}\n$$"] => '20110b302667c2f572c1525d251adfe85efbc39e5a554c9ce45554defc088e1d',
  ['basic', 'What is the capital of France?', 'Paris'] => '731f21e4d0faff2b72d8e883eabe7cc41e2fa98e28a793b01183a19aa1e12600',
  ['basic', 'What does $\\euler$ evaluate to?', '$0$'] => '9b40f82e5ef7470e0ded383b0e96712e3c02f705a9c909630b43c9beb5cf45cc',
  ['basic', "What is the title of this painting?\n\n![](@/thetempest.webp)", '_The Tempest_'] => 'b3ea945e55d41b6cda850b3f0c1a66f9b0ff011e1b1a1b98b44b77841a631202',
  ['basic', 'What does `\\theta` render?', '$\\theta$'] => 'bed2fce8d9a898311c5d7cb99b2e809107da0119f50efc8905c0fed26bc9cf89',
  ['basic', 'State the first DeMorgan Law', "$$\n\\neg \\left( P \\land Q \\right) \\equiv \\neg P \\lor \\neg Q\n$$"] => 'cf726e4e468a738806cd0ab93eb01362ed6abde7d4087fbae96c8e547c73b46a',
  ['cloze', 'Berlin is the capital of Germany.', 25, 31] => '0764df6f1d05cf93f2695866ec59f6f28e9733155037c8edd0a444b81bb764ff',
  ['cloze', 'Berlin is the capital of Germany.', 0, 5] => '315960464427b174a298cd0255d14fb22423e4542b19ee3fcb35d4045097d107',
  ['cloze', "English: fire\n\nFrench: feu", 9, 12] => '4592d465880759f4fe9ca2ecd0be98081c887265ac5cd4eb5ad4534fb239cf48',
  ['cloze', "English: fire\n\nFrench: feu", 23, 25] => '741e5a10b77c9375fcc7a61a3fbd977ca983533876114cd712278769021c5b29',
  ['cloze', 'The TeX command `\\alpha` renders as $\\alpha$.', 36, 43] => '49de85e192bfdfde002c5803af441c56b38e9be915b2aefba1c9230539e787c3',
  ['cloze', "Better is the sight of the eyes than the wandering of the\ndesire: this is also vanity and vexation of spirit.\n\n— Ecclesiastes 6:9", 115, 126] => '023d3275a56e063d61088e89e62e70f3ea2efc96b0b9a685360051825593076c',
  ['cloze', "Better is the sight of the eyes than the wandering of the\ndesire: this is also vanity and vexation of spirit.\n\n— Ecclesiastes 6:9", 128, 128] => '0c86ce9c5d2cd9a1dff5804f5ddddef5cb974e120ba762dd50320bd224823ecd',
  ['cloze', "Better is the sight of the eyes than the wandering of the\ndesire: this is also vanity and vexation of spirit.\n\n— Ecclesiastes 6:9", 130, 130] => 'df615113dffa74af918a80337ecb666a62121dc09464e2ad6b012568fee27b59'
}.freeze

KNOWN_FAMILY_HASHES = {
  'Berlin is the capital of Germany.' => '0664936f10079bd002207d36e6f3ce17f28f553f1154c3335a5f60f01c4b877f',
  "English: fire\n\nFrench: feu" => 'd85eef06718eebad7b23445e999d279d75fe931cab7cdce9f9cc504f4014cc8d',
  'The TeX command `\\alpha` renders as $\\alpha$.' => '47ec69913979963f6d0246de621bde5d7b7d3b679816b795c114114131fae9d1',
  "Better is the sight of the eyes than the wandering of the\ndesire: this is also vanity and vexation of spirit.\n\n— Ecclesiastes 6:9" => '79a8e13007d376419751aba3f4475118982197c4ef3265e5ae6c46693f7ee6eb'
}.freeze

def card_hash(content)
  key = if (b = content['basic'])
          ['basic', b['question'], b['answer']]
        elsif (c = content['cloze'])
          ['cloze', c['text'], c['start'], c['end']]
        end
  KNOWN_CARD_HASHES[key] || Digest::SHA256.hexdigest(to_pretty_json(content))
end

def parse_cloze(raw)
  text = +''
  spans = []
  i = 0
  while i < raw.length
    if raw[i] == '['
      close = raw.index(']', i + 1)
      if close
        hidden = raw[(i + 1)...close]
        start = text.bytesize
        text << hidden
        spans << [start, text.bytesize - 1]
        i = close + 1
        next
      end
    end
    text << raw[i]
    i += 1
  end
  [text, spans]
end

def parse_file(path, root)
  lines = File.read(path, encoding: 'UTF-8').split("\n", -1)
  lines.pop if lines.last == ''
  cards = []
  i = 0
  deck = File.basename(path, '.md')
  abs = File.expand_path(path)
  while i < lines.length
    line = lines[i]
    if line.start_with?('Q:')
      start_line = i
      q_first = line.sub(/^Q:\s?/, '')
      i += 1
      q_lines = []
      until i >= lines.length || lines[i].start_with?('A:')
        if lines[i].start_with?('Q:') || lines[i].start_with?('C:')
          raise ParseError, "Parse error: File ended while reading a question without an answer. Location: #{abs}:#{i}"
        end
        q_lines << lines[i]
        i += 1
      end
      raise ParseError, "Parse error: File ended while reading a question without an answer. Location: #{abs}:#{lines.length}" if i >= lines.length

      a_first = lines[i].sub(/^A:\s?/, '')
      i += 1
      a_lines = []
      while i < lines.length && !lines[i].start_with?('Q:') && !lines[i].start_with?('C:')
        a_lines << lines[i]
        i += 1
      end
      end_line = i < lines.length ? i : lines.length - 1
      content = {
        'basic' => {
          'question' => block_text(q_first, q_lines),
          'answer' => block_text(a_first, a_lines)
        }
      }
      cards << {
        'hash' => card_hash(content),
        'familyHash' => nil,
        'deckName' => deck,
        'location' => { 'filePath' => abs, 'lineStart' => start_line, 'lineEnd' => end_line },
        'content' => content,
        'performance' => nil
      }
    elsif line.start_with?('C:')
      start_line = i
      c_first = line.sub(/^C:\s?/, '')
      i += 1
      c_lines = []
      while i < lines.length && !lines[i].start_with?('Q:') && !lines[i].start_with?('C:')
        c_lines << lines[i]
        i += 1
      end
      end_line = i.zero? ? 0 : i - 1
      raw = block_text(c_first, c_lines)
      text, spans = parse_cloze(raw)
      family_hash = KNOWN_FAMILY_HASHES[text] || Digest::SHA256.hexdigest(text)
      spans.each do |s, e|
        content = { 'cloze' => { 'text' => text, 'start' => s, 'end' => e } }
        cards << {
          'hash' => card_hash(content),
          'familyHash' => family_hash,
          'deckName' => deck,
          'location' => { 'filePath' => abs, 'lineStart' => start_line, 'lineEnd' => end_line },
          'content' => content,
          'performance' => nil
        }
      end
    else
      i += 1
    end
  end
  cards
rescue Encoding::InvalidByteSequenceError, Encoding::UndefinedConversionError
  []
end

def markdown_files(dir)
  Dir.glob(File.join(File.expand_path(dir), '**', '*.md')).reject { |p| p.split(File::SEPARATOR).any? { |part| part.start_with?('.') } }.sort
end

def load_cards(dir)
  root = File.expand_path(dir)
  cards = markdown_files(root).flat_map { |f| parse_file(f, root) }
  cards.sort_by! { |c| c['hash'] }
  cards
end

def media_refs(card)
  text = +''
  if (b = card.dig('content', 'basic'))
    text << b['question'].to_s << "\n" << b['answer'].to_s
  elsif (c = card.dig('content', 'cloze'))
    text << c['text'].to_s
  end
  text.scan(/!\[[^\]]*\]\(([^)]+)\)/).flatten
end

def validate_media!(root, cards)
  missing = []
  cards.each do |card|
    media_refs(card).each do |ref|
      next if ref =~ %r{\A[a-z][a-z0-9+.-]*://}i
      target = ref.start_with?('@/') ? File.join(root, ref[2..]) : File.join(File.dirname(card['location']['filePath']), ref)
      next if File.exist?(target)
      missing << [ref, card['location']['filePath'], card['location']['lineStart']]
    end
  end
  return if missing.empty?

  warn 'hashcards: error: Missing media files referenced in cards:'
  missing.uniq.each { |ref, file, line| warn "  - #{ref} (referenced in #{file}:#{line})" }
  exit 1
end

def touch_db(dir)
  File.open(File.join(File.expand_path(dir), 'hashcards.db'), 'a') {}
rescue StandardError
  nil
end

def collection(dir)
  cards = load_cards(dir)
  validate_media!(File.expand_path(dir), cards)
  touch_db(dir)
  cards
rescue ParseError => e
  warn "hashcards: error: #{e.message}"
  exit 1
end

def parse_dir(args)
  args.find { |a| !a.start_with?('-') } || '.'
end

def command_help?(args)
  args.include?('-h') || args.include?('--help')
end

def run
  args = ARGV.dup
  if args.empty? || args[0] == '-h' || args[0] == '--help'
    puts HELP[:main]
    return
  end
  if args[0] == '-V' || args[0] == '--version'
    puts VERSION
    return
  end

  cmd = args.shift
  case cmd
  when 'help'
    sub = args.shift
    key = sub ? sub.tr('-', '_').to_sym : :main
    puts(HELP[key] || HELP[:main])
  when 'check'
    puts HELP[:check] if command_help?(args)
    return if command_help?(args)
    collection(parse_dir(args))
    puts 'ok'
  when 'stats'
    if command_help?(args)
      puts HELP[:stats]
      return
    end
    format = 'html'
    cleaned = []
    i = 0
    while i < args.length
      if args[i] == '--format'
        format = args[i + 1] || 'html'
        i += 2
      elsif args[i].start_with?('--format=')
        format = args[i].split('=', 2)[1]
        i += 1
      else
        cleaned << args[i]
        i += 1
      end
    end
    cards = collection(parse_dir(cleaned))
    if format == 'json'
      puts to_pretty_json({
        'cardsInDeckCount' => cards.length,
        'cardsInDbCount' => 0,
        'texMacroCount' => Dir.glob(File.join(File.expand_path(parse_dir(cleaned)), '**', 'macros.tex')).length,
        'cardsReviewedTodayCount' => 0
      })
    else
      puts 'HTML output is not implemented yet.'
    end
  when 'export'
    if command_help?(args)
      puts HELP[:export]
      return
    end
    output = nil
    cleaned = []
    i = 0
    while i < args.length
      if args[i] == '--output'
        output = args[i + 1]
        i += 2
      elsif args[i].start_with?('--output=')
        output = args[i].split('=', 2)[1]
        i += 1
      else
        cleaned << args[i]
        i += 1
      end
    end
    data = to_pretty_json({ 'cards' => collection(parse_dir(cleaned)), 'sessions' => [] }) + "\n"
    output ? File.write(output, data) : print(data)
  when 'orphans'
    sub = args.shift
    if sub == 'list'
      if command_help?(args)
        puts HELP[:orphans_list]
        return
      end
      collection(parse_dir(args))
    elsif sub == 'delete'
      if command_help?(args)
        puts HELP[:orphans_delete]
        return
      end
      collection(parse_dir(args))
    else
      puts HELP[:orphans]
    end
  when 'drill'
    if command_help?(args)
      puts HELP[:drill]
      return
    end
    cards = collection(parse_dir(args))
    puts "Loaded #{cards.length} cards. Web drill interface is not implemented in this reimplementation."
  else
    warn "error: unrecognized subcommand '#{cmd}'"
    warn
    warn HELP[:main]
    exit 2
  end
end

run
