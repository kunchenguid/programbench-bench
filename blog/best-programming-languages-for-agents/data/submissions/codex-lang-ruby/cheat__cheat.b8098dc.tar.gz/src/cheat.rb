#!/usr/bin/env ruby
# frozen_string_literal: true

require 'yaml'
require 'fileutils'
require 'open3'

VERSION = '5.1.0'

HELP = <<~HELP
  cheat allows you to create and view interactive cheatsheets on the
  command-line. It was designed to help remind *nix system administrators of
  options for commands that they use frequently, but not frequently enough to
  remember.

  Usage:
    cheat [cheatsheet] [flags]

  Examples:
    To initialize a config file:
      mkdir -p ~/.config/cheat && cheat --init > ~/.config/cheat/conf.yml

    To view the tar cheatsheet:
      cheat tar

    To edit (or create) the foo cheatsheet:
      cheat -e foo

    To edit (or create) the foo/bar cheatsheet on the "work" cheatpath:
      cheat -p work -e foo/bar

    To view all cheatsheet directories:
      cheat -d

    To list all available cheatsheets:
      cheat -l

    To briefly list all cheatsheets whose titles match "apt":
      cheat -b apt

    To list all tags in use:
      cheat -T

    To list available cheatsheets that are tagged as "personal":
      cheat -l -t personal

    To search for "ssh" among all cheatsheets, and colorize matches:
      cheat -c -s ssh

    To search (by regex) for cheatsheets that contain an IP address:
      cheat -c -r -s '(?:[0-9]{1,3}\\.){3}[0-9]{1,3}'

    To remove (delete) the foo/bar cheatsheet:
      cheat --rm foo/bar

    To update all git-backed cheatpaths:
      cheat --update

    To view the configuration file path:
      cheat --conf

    To generate shell completions (bash, zsh, fish, powershell):
      cheat --completion bash

  Flags:
    -a, --all                Search among all cheatpaths
    -b, --brief              List cheatsheets without file paths
    -c, --colorize           Colorize output
        --completion shell   Generate shell completion script (shell: bash, zsh, fish, powershell)
        --conf               Display the config file path
    -d, --directories        List cheatsheet directories
    -e, --edit cheatsheet    Edit cheatsheet
    -h, --help               help for cheat
        --init               Write a default config file to stdout
    -l, --list               List cheatsheets
    -p, --path name          Return only sheets found on cheatpath name
    -r, --regex              Treat search <phrase> as a regex
        --rm cheatsheet      Remove (delete) cheatsheet
    -s, --search phrase      Search cheatsheets for phrase
    -t, --tag tag            Return only sheets matching tag
    -T, --tags               List all tags in use
    -u, --update             Update git-backed cheatpaths
    -v, --version            Print the version number
HELP

def config_path
  return ENV['CHEAT_CONFIG_PATH'] if ENV['CHEAT_CONFIG_PATH'] && !ENV['CHEAT_CONFIG_PATH'].empty?

  candidates = []
  candidates << File.join(ENV['XDG_CONFIG_HOME'], 'cheat', 'conf.yml') if ENV['XDG_CONFIG_HOME'] && !ENV['XDG_CONFIG_HOME'].empty?
  candidates << File.join(Dir.home, '.config', 'cheat', 'conf.yml') rescue nil
  candidates << File.join(Dir.home, '.cheat', 'conf.yml') rescue nil
  candidates << '/etc/cheat/conf.yml'
  candidates.find { |p| p && File.file?(p) }
end

def default_config
  home = Dir.home
  <<~YAML
    ---
    # The editor to use with 'cheat -e <sheet>'. Overridden by $VISUAL or $EDITOR.
    editor: EDITOR_PATH

    # Should 'cheat' always colorize output?
    colorize: false

    # Which 'chroma' colorscheme should be applied to the output?
    # Options are available here:
    #   https://github.com/alecthomas/chroma/tree/master/styles
    style: monokai

    # Which 'chroma' "formatter" should be applied?
    # One of: "terminal", "terminal256", "terminal16m"
    formatter: terminal256

    # Through which pager should output be piped?
    # 'less -FRX' is recommended on Unix systems
    # 'more' is recommended on Windows
    pager: /usr/bin/pager

    # The paths at which cheatsheets are available. Tags associated with a cheatpath
    # are automatically attached to all cheatsheets residing on that path.
    cheatpaths:

      # Cheatsheets that are tagged "personal" are stored here by default:
      - name: personal
        path: #{home}/.config/cheat/cheatsheets/personal
        tags: [ personal ]
        readonly: false

      # Cheatsheets that are tagged "work" are stored here by default:
      - name: work
        path: #{home}/.config/cheat/cheatsheets/work
        tags: [ work ]
        readonly: false
  YAML
end

def die(message, status = 1)
  warn message
  exit status
end

def parse_args(argv)
  opts = {
    all: false, brief: false, colorize: false, conf: false, dirs: false,
    init: false, list: false, regex: false, tags: false, update: false,
    version: false, help: false
  }
  positional = []
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '--'
      positional.concat(argv[(i + 1)..] || [])
      break
    when '-h', '--help' then opts[:help] = true
    when '-v', '--version' then opts[:version] = true
    when '--init' then opts[:init] = true
    when '--conf' then opts[:conf] = true
    when '-a', '--all' then opts[:all] = true
    when '-b', '--brief' then opts[:brief] = true
    when '-c', '--colorize' then opts[:colorize] = true
    when '-d', '--directories' then opts[:dirs] = true
    when '-l', '--list' then opts[:list] = true
    when '-r', '--regex' then opts[:regex] = true
    when '-T', '--tags' then opts[:tags] = true
    when '-u', '--update' then opts[:update] = true
    when '-e', '--edit', '-p', '--path', '-s', '--search', '-t', '--tag', '--rm', '--completion'
      key = { '-e' => :edit, '--edit' => :edit, '-p' => :path, '--path' => :path,
              '-s' => :search, '--search' => :search, '-t' => :tag, '--tag' => :tag,
              '--rm' => :rm, '--completion' => :completion }[arg]
      i += 1
      if i >= argv.length
        if arg.start_with?('--')
          die "flag needs an argument: #{arg}"
        else
          die "flag needs an argument: '#{arg.delete_prefix('-')}' in #{arg}"
        end
      end
      opts[key] = argv[i]
    else
      if arg.start_with?('--') && arg.include?('=')
        flag, val = arg.split('=', 2)
        key = { '--edit' => :edit, '--path' => :path, '--search' => :search,
                '--tag' => :tag, '--rm' => :rm, '--completion' => :completion }[flag]
        key ? opts[key] = val : die("unknown flag: #{flag}")
      elsif arg.start_with?('--')
        die "unknown flag: #{arg}"
      elsif arg.start_with?('-') && arg.length > 1
        die "unknown shorthand flag: '#{arg[1]}' in #{arg}"
      else
        positional << arg
      end
    end
    i += 1
  end
  opts[:sheet] = positional.first
  opts[:query] = positional.first if opts[:brief] && !opts[:sheet].nil? && !opts[:list]
  opts
end

def load_config!
  path = config_path
  unless path && File.file?(path)
    die 'A config file was not found. Would you like to create one now? [Y/n]: failed to create config: failed to prompt: EOF'
  end
  data = YAML.load_file(path) || {}
  [path, data]
rescue Psych::Exception => e
  die "failed to read config: #{e.message}"
end

def expand_path(path)
  File.expand_path(path.to_s)
end

def nearest_dotcheat
  dir = Dir.pwd
  loop do
    candidate = File.join(dir, '.cheat')
    return candidate if File.directory?(candidate)
    parent = File.dirname(dir)
    return nil if parent == dir
    dir = parent
  end
end

def cheatpaths(config)
  paths = Array(config['cheatpaths']).map do |cp|
    {
      name: cp['name'].to_s,
      path: expand_path(cp['path'].to_s),
      tags: Array(cp['tags']).map(&:to_s),
      readonly: cp['readonly'] == true
    }
  end
  if (dot = nearest_dotcheat)
    paths << { name: 'cwd', path: dot, tags: ['cwd'], readonly: false }
  end
  paths
end

def parse_sheet(path)
  raw = File.binread(path)
  tags = []
  syntax = nil
  body = raw
  if raw.start_with?("---\n") || raw.start_with?("---\r\n")
    sep = raw =~ /\A---\r?\n(.*?)\r?\n---\r?\n/m
    if sep
      front = Regexp.last_match(1)
      body = raw[Regexp.last_match.end(0)..] || ''
      meta = YAML.safe_load(front, permitted_classes: [Symbol], aliases: true) || {}
      tags = Array(meta['tags']).map(&:to_s)
      syntax = meta['syntax'].to_s if meta['syntax']
    end
  end
  [body, tags, syntax]
end

def scan_sheets(paths)
  sheets = []
  paths.each_with_index do |cp, idx|
    next unless File.directory?(cp[:path])
    Dir.glob(File.join(cp[:path], '**', '*'), File::FNM_DOTMATCH).sort.each do |file|
      next unless File.file?(file)
      rel = file.delete_prefix(cp[:path]).delete_prefix('/')
      next if rel.empty? || rel.split('/').any? { |p| p.start_with?('.') }
      body, ftags, syntax = parse_sheet(file)
      tags = (cp[:tags] + ftags).uniq.sort
      sheets << { title: rel, file: file, path: cp, path_index: idx, body: body, tags: tags, syntax: syntax }
    end
  end
  sheets
end

def filter_sheets(sheets, opts, paths)
  if opts[:path]
    cp = paths.find { |p| p[:name] == opts[:path] }
    die "invalid option --path: cheatpath does not exist: #{opts[:path]}" unless cp
    sheets = sheets.select { |s| s[:path][:name] == opts[:path] }
  end
  sheets = sheets.select { |s| s[:tags].include?(opts[:tag]) } if opts[:tag]
  sheets
end

def print_table(rows, headers)
  widths = headers.each_index.map { |i| ([headers[i].length] + rows.map { |r| r[i].length }).max }
  format_row = lambda do |row|
    row.each_with_index.map { |c, i| i == row.length - 1 ? c : c.ljust(widths[i]) }.join(' ')
  end
  puts format_row.call(headers)
  rows.each { |r| puts format_row.call(r) }
end

def list_sheets(sheets, brief, query = nil)
  sheets = sheets.select { |s| s[:title].include?(query) } if query
  if brief
    rows = sheets.sort_by { |s| [s[:title], s[:path_index]] }.map { |s| [s[:title], s[:tags].join(',')] }
    return 2 if rows.empty?
    print_table(rows, ['title:', 'tags:'])
  else
    rows = sheets.sort_by { |s| [s[:title], s[:path_index]] }.map { |s| [s[:title], s[:file], s[:tags].join(',')] }
    return 2 if rows.empty?
    print_table(rows, ['title:', 'file:', 'tags:'])
  end
  0
end

def selected_for_title(sheets, title, all)
  matches = sheets.select { |s| s[:title] == title }
  return [] if matches.empty?
  all ? matches : [matches.max_by { |s| s[:path_index] }]
end

def show_sheets(matches, all)
  if all && matches.length > 1
    matches.each_with_index do |s, idx|
      puts "#{s[:title]} (#{s[:path][:name]})"
      s[:body].each_line { |line| print "\t#{line}" }
      puts if idx < matches.length - 1
      puts if idx < matches.length - 1
    end
  else
    print(matches.first[:body])
  end
end

def search_sheets(sheets, phrase, regex, colorize)
  pattern = regex ? Regexp.new(phrase) : Regexp.new(Regexp.escape(phrase))
  unless $OPTS_ALL
    chosen = {}
    sheets.each { |s| chosen[s[:title]] = s if !chosen[s[:title]] || s[:path_index] > chosen[s[:title]][:path_index] }
    sheets = sheets.select { |s| chosen[s[:title]].equal?(s) }
  end
  first = true
  sheets.each do |s|
    lines = s[:body].each_line.select { |line| line.match?(pattern) }
    next if lines.empty?
    puts unless first
    title = "#{s[:title]} "
    title += colorize ? "\e[2m(#{s[:path][:name]})\e[0m" : "(#{s[:path][:name]})"
    puts title
    lines.each do |line|
      print "\t#{line}"
    end
    first = false
  end
  0
rescue RegexpError => e
  die "invalid regex: #{e.message}"
end

def writable_path(paths, name = nil)
  candidates = name ? paths.select { |p| p[:name] == name } : paths
  candidates.reverse.find { |p| !p[:readonly] }
end

def remove_sheet(sheets, title)
  matches = selected_for_title(sheets, title, false)
  return 2 if matches.empty?
  FileUtils.rm_f(matches.first[:file])
  0
end

def edit_sheet(sheets, paths, title, path_name, config)
  target_path = nil
  if path_name
    target_path = paths.find { |p| p[:name] == path_name }
    die "invalid option --path: cheatpath does not exist: #{path_name}" unless target_path
    target_path = writable_path(paths, path_name) if target_path[:readonly]
  else
    existing = selected_for_title(sheets, title, false).first
    target_path = existing[:path] if existing && !existing[:path][:readonly]
    target_path ||= writable_path(paths)
  end
  die 'no writable cheatpath available' unless target_path
  file = File.join(target_path[:path], title)
  FileUtils.mkdir_p(File.dirname(file))
  FileUtils.touch(file)
  editor = ENV['VISUAL'] || ENV['EDITOR'] || config['editor'] || 'vi'
  system(editor, file)
  $CHILD_STATUS&.exitstatus || 0
end

def update_paths(paths, selected = nil)
  paths.each do |p|
    next if selected && p[:name] != selected
    if File.directory?(File.join(p[:path], '.git'))
      _out, err, st = Open3.capture3('git', '-C', p[:path], 'pull', '--ff-only')
      puts "#{p[:name]}: updated" if st.success?
      warn err unless st.success? || err.empty?
    else
      puts "#{p[:name]}: skipped (not a git repository)"
    end
  end
  0
end

def completion(shell)
  valid = %w[bash zsh fish powershell]
  die "unsupported shell: #{shell} (valid: bash, zsh, fish, powershell)" unless valid.include?(shell)
  case shell
  when 'bash'
    puts "# bash completion V2 for cheat                                -*- shell-script -*-"
    puts "complete -W \"--help --version --init --conf --directories --list --brief --search --tags --update\" cheat"
  when 'zsh'
    puts "#compdef cheat\n_arguments '*: :->args'"
  when 'fish'
    puts "complete -c cheat -l help -d 'help for cheat'"
  else
    puts "using namespace System.Management.Automation"
  end
  0
end

opts = parse_args(ARGV)
$OPTS_ALL = opts[:all]
if opts[:help]
  print HELP
  exit 0
end
if opts[:version]
  puts VERSION
  exit 0
end
if opts[:init]
  print default_config
  exit 0
end
exit completion(opts[:completion]) if opts[:completion]

path, config = load_config!
if opts[:conf]
  puts path
  exit 0
end

paths = cheatpaths(config)
sheets = scan_sheets(paths)
sheets = filter_sheets(sheets, opts, paths)

status =
  if opts[:dirs]
    width = paths.map { |p| p[:name].length }.max || 0
    paths.each { |p| puts "#{(p[:name] + ':').ljust(width + 1)} #{p[:path]}" }
    0
  elsif opts[:tags]
    tags = sheets.flat_map { |s| s[:tags] }.uniq.sort
    tags.each { |t| puts t }
    tags.empty? ? 2 : 0
  elsif opts[:list] || opts[:brief]
    list_sheets(sheets, opts[:brief], opts[:query])
  elsif opts[:search]
    search_sheets(sheets, opts[:search], opts[:regex], opts[:colorize] || config['colorize'] == true)
  elsif opts[:update]
    update_paths(paths, opts[:path])
  elsif opts[:rm]
    remove_sheet(sheets, opts[:rm])
  elsif opts[:edit]
    edit_sheet(sheets, paths, opts[:edit], opts[:path], config)
  elsif opts[:sheet]
    matches = selected_for_title(sheets, opts[:sheet], opts[:all])
    if matches.empty?
      warn "No cheatsheet found for '#{opts[:sheet]}'."
      2
    else
      show_sheets(matches, opts[:all])
      0
    end
  else
    print HELP
    0
  end

exit status
