#!/usr/bin/env ruby
# frozen_string_literal: true

require 'find'
require 'optparse'
require 'zlib'

VERSION = "ag version 2.2.0\n\nFeatures:\n  +jit +lzma +zlib\n"

FILE_TYPES = {
  'actionscript' => %w[.as .mxml],
  'ada' => %w[.ada .adb .ads],
  'asciidoc' => %w[.adoc .ad .asc .asciidoc],
  'apl' => %w[.apl],
  'asm' => %w[.asm .s],
  'asp' => %w[.asp .asa .aspx .asax .ashx .ascx .asmx],
  'aspx' => %w[.asp .asa .aspx .asax .ashx .ascx .asmx],
  'batch' => %w[.bat .cmd],
  'bazel' => %w[.bazel],
  'bitbake' => %w[.bb .bbappend .bbclass .inc],
  'cc' => %w[.c .h .xs],
  'cfmx' => %w[.cfc .cfm .cfml],
  'clojure' => %w[.clj .cljs .cljc .cljx .edn],
  'coffee' => %w[.coffee .cjsx],
  'config' => %w[.config],
  'cpp' => %w[.cpp .cc .C .cxx .m .hpp .hh .h .H .hxx .tpp],
  'csharp' => %w[.cs],
  'css' => %w[.css],
  'elisp' => %w[.el],
  'go' => %w[.go],
  'haskell' => %w[.hs .lhs],
  'html' => %w[.htm .html .shtml .xhtml],
  'java' => %w[.java .properties],
  'js' => %w[.js .jsx .mjs .cjs],
  'json' => %w[.json],
  'lisp' => %w[.lisp .lsp],
  'lua' => %w[.lua],
  'make' => %w[.mk],
  'markdown' => %w[.md .markdown .mkd],
  'objc' => %w[.m .h],
  'perl' => %w[.pl .pm .pod .t],
  'php' => %w[.php .phpt .php3 .php4 .php5 .phtml],
  'python' => %w[.py .pyw],
  'ruby' => %w[.rb .rhtml .rjs .rxml .erb .rake .gemspec],
  'rust' => %w[.rs],
  'scala' => %w[.scala .sbt],
  'shell' => %w[.sh .bash .csh .tcsh .ksh .zsh .fish],
  'sql' => %w[.sql],
  'swift' => %w[.swift],
  'tex' => %w[.tex .cls .sty],
  'text' => %w[.txt],
  'vim' => %w[.vim],
  'xml' => %w[.xml .dtd .xsl .xslt .ent],
  'yaml' => %w[.yaml .yml]
}.freeze

HELP = <<~TXT

  Usage: ag [FILE-TYPE] [OPTIONS] PATTERN [PATH]

    Recursively search for PATTERN in PATH.
    Like grep or ack, but faster.

  Example:
    ag -i foo /bar/

  Output Options:
       --ackmate            Print results in AckMate-parseable format
    -A --after [LINES]      Print lines after match (Default: 2)
    -B --before [LINES]     Print lines before match (Default: 2)
       --[no]break          Print newlines between matches in different files
                            (Enabled by default)
    -c --count              Only print the number of matches in each file.
    -H --[no]heading        Print file names before each file's matches
    -C --context [LINES]    Print lines before and after matches (Default: 2)
       --[no]group          Same as --[no]break --[no]heading
    -g --filename-pattern PATTERN
                            Print filenames matching PATTERN
    -l --files-with-matches Only print filenames that contain matches
    -L --files-without-matches
                            Only print filenames that don't contain matches
    -o --only-matching      Prints only the matching part of the lines
       --vimgrep            Print results like vim's :vimgrep /pattern/g would
    -0 --null --print0      Separate filenames with null (for 'xargs -0')

  Search Options:
    -a --all-types          Search all files
    -f --follow             Follow symlinks
    -F --fixed-strings      Alias for --literal for compatibility with grep
    -G --file-search-regex  PATTERN Limit search to filenames matching PATTERN
       --hidden             Search hidden files
    -i --ignore-case        Match case insensitively
       --ignore PATTERN     Ignore files/directories matching PATTERN
    -Q --literal            Don't parse PATTERN as a regular expression
    -s --case-sensitive     Match case sensitively
    -S --smart-case         Match case insensitively unless PATTERN contains uppercase
    -u --unrestricted       Search all files
    -v --invert-match
    -w --word-regexp        Only match whole words

  For a list of supported file types run:
    ag --list-file-types

  ag was originally created by Geoff Greer. More information (and the latest release)
  can be found at http://geoff.greer.fm/ag
TXT

class Ag
  def initialize(argv)
    @argv = argv.dup
    @opts = {
      after: 0, before: 0, break: true, color: :auto, column: false,
      filename: nil, heading: nil, recurse: true, follow: false, hidden: false,
      ignore_case: nil, smart_case: true, literal: false, unrestricted: false,
      all_types: false, all_text: false, search_binary: false, invert: false,
      word: false, only: false, count: false, files_with: false, files_without: false,
      vimgrep: false, ackmate: false, numbers: nil, null: false, max_count: 10_000,
      width: nil, filename_pattern: nil, file_search_regex: nil, ignores: [],
      skip_vcs_ignores: false, search_zip: false, depth: 25, passthrough: false,
      stats: false, stats_only: false, print_all_files: false, type_exts: nil,
      silent: false
    }
    @files_scanned = 0
    @matches_found = 0
    @files_with_matches = 0
    @bytes_searched = 0
  end

  def run
    parse!
    return 0 if @done

    if @opts[:filename_pattern]
      files = collect_files(@paths)
      re = make_regex(@opts[:filename_pattern], false)
      out = files.select { |f| f.match?(re) }
      print_names(out)
      return out.empty? ? 1 : 0
    end

    @regex = build_search_regex
    if use_stdin?
      res = search_stream($stdin.read)
      return finish(res ? 0 : 1)
    end

    files = collect_files(@paths)
    any = false
    printed = false
    file_results = files.map { |f| [f, search_file(f)] }
    file_results.each { |_, r| any ||= r[:matched] }
    printed = emit_results(file_results)
    success = if @opts[:files_without]
                printed
              else
                any || printed
              end
    finish(success ? 0 : 1)
  rescue OptionParser::InvalidOption, OptionParser::MissingArgument => e
    warn "ERR: #{e.message}" unless @opts[:silent]
    1
  rescue RegexpError => e
    warn "ERR: Error in regex: #{e.message}" unless @opts[:silent]
    1
  end

  private

  def parse!
    expanded = []
    stop = false
    @argv.each do |arg|
      if stop
        expanded << arg
      elsif arg == '--'
        expanded << arg
        stop = true
      elsif arg.start_with?('--no') && %w[--nocolor --nogroup --noheading --nofilename --nonumbers --norecurse --nofollow --nomultiline --noaffinity --nommap --nopager].include?(arg)
        expanded << arg
      elsif arg.start_with?('--') && FILE_TYPES.key?(arg[2..])
        @opts[:type_exts] = FILE_TYPES[arg[2..]]
      else
        expanded << arg
      end
    end

    parser = OptionParser.new do |o|
      o.on('-h', '--help') { puts HELP; @done = true }
      o.on('-V', '--version') { puts VERSION; @done = true }
      o.on('--list-file-types') { list_file_types; @done = true }
      o.on('--ackmate') { @opts[:ackmate] = true }
      o.on('-A', '--after [N]', Integer) { |n| @opts[:after] = n || 2 }
      o.on('-B', '--before [N]', Integer) { |n| @opts[:before] = n || 2 }
      o.on('-C', '--context [N]', Integer) { |n| @opts[:before] = @opts[:after] = n || 2 }
      o.on('--break') { @opts[:break] = true }
      o.on('--nobreak') { @opts[:break] = false }
      o.on('-c', '--count') { @opts[:count] = true }
      o.on('--color [WHEN]') { |v| @opts[:color] = v || :always }
      o.on('--nocolor') { @opts[:color] = :never }
      o.on('--color-line-number X') { |_v| }
      o.on('--color-match X') { |_v| }
      o.on('--color-path X') { |_v| }
      o.on('--column') { @opts[:column] = true }
      o.on('-H', '--heading') { @opts[:heading] = true }
      o.on('--noheading') { @opts[:heading] = false }
      o.on('--group') { @opts[:heading] = true; @opts[:break] = true }
      o.on('--nogroup') { @opts[:heading] = false; @opts[:break] = false }
      o.on('--filename') { @opts[:filename] = true }
      o.on('--nofilename') { @opts[:filename] = false }
      o.on('-g', '--filename-pattern PAT') { |v| @opts[:filename_pattern] = v }
      o.on('-G', '--file-search-regex PAT') { |v| @opts[:file_search_regex] = make_regex(v, false) }
      o.on('-l', '--files-with-matches') { @opts[:files_with] = true }
      o.on('-L', '--files-without-matches') { @opts[:files_without] = true }
      o.on('-o', '--only-matching') { @opts[:only] = true }
      o.on('--print-all-files') { @opts[:print_all_files] = true }
      o.on('--print-long-lines') { @opts[:print_long_lines] = true }
      o.on('--passthrough', '--passthru') { @opts[:passthrough] = true }
      o.on('--stats') { @opts[:stats] = true }
      o.on('--stats-only') { @opts[:stats] = true; @opts[:stats_only] = true }
      o.on('--vimgrep') { @opts[:vimgrep] = true; @opts[:heading] = false; @opts[:column] = true }
      o.on('-0', '--null', '--print0') { @opts[:null] = true }
      o.on('-a', '--all-types') { @opts[:all_types] = true }
      o.on('-D', '--debug') { }
      o.on('--depth N', Integer) { |n| @opts[:depth] = n }
      o.on('-f', '--follow') { @opts[:follow] = true }
      o.on('--nofollow') { @opts[:follow] = false }
      o.on('-F', '--fixed-strings') { @opts[:literal] = true }
      o.on('--hidden') { @opts[:hidden] = true }
      o.on('--ignore PAT') { |v| @opts[:ignores] << v }
      o.on('--ignore-dir PAT') { |v| @opts[:ignores] << v }
      o.on('-i', '--ignore-case') { @opts[:ignore_case] = true; @opts[:smart_case] = false }
      o.on('-m', '--max-count N', Integer) { |n| @opts[:max_count] = n.zero? ? 1 << 60 : n }
      o.on('-n', '--norecurse') { @opts[:recurse] = false }
      o.on('-r', '--recurse') { @opts[:recurse] = true }
      o.on('--numbers') { @opts[:numbers] = true }
      o.on('--nonumbers') { @opts[:numbers] = false }
      o.on('-p', '--path-to-ignore PATH') { |v| read_ignore_file(v) }
      o.on('-Q', '--literal') { @opts[:literal] = true }
      o.on('-s', '--case-sensitive') { @opts[:ignore_case] = false; @opts[:smart_case] = false }
      o.on('-S', '--smart-case') { @opts[:smart_case] = true; @opts[:ignore_case] = nil }
      o.on('--search-binary') { @opts[:search_binary] = true }
      o.on('--silent') { @opts[:silent] = true }
      o.on('-t', '--all-text') { @opts[:all_text] = true }
      o.on('-u', '--unrestricted') { @opts[:unrestricted] = true; @opts[:hidden] = true; @opts[:search_binary] = true; @opts[:all_types] = true }
      o.on('-U', '--skip-vcs-ignores') { @opts[:skip_vcs_ignores] = true }
      o.on('-v', '--invert-match') { @opts[:invert] = true }
      o.on('-w', '--word-regexp') { @opts[:word] = true }
      o.on('-W', '--width N', Integer) { |n| @opts[:width] = n }
      o.on('-z', '--search-zip') { @opts[:search_zip] = true }
      o.on('--workers N') { |_v| }
      o.on('--parallel') { }
      o.on('--pager CMD') { |_v| }
      o.on('--nopager') { }
      o.on('--mmap') { }
      o.on('--nommap') { }
      o.on('--multiline') { }
      o.on('--nomultiline') { }
      o.on('--affinity') { }
      o.on('--noaffinity') { }
      o.on('--one-device') { }
    end
    parser.permute!(expanded)
    @args = expanded
    if @opts[:filename_pattern]
      @explicit_paths = !@args.empty?
      @paths = @explicit_paths ? @args : ['.']
    else
      usage_error if @args.empty? && $stdin.tty?
      @pattern = @args.shift || ''
      @paths = @args.empty? ? ['.'] : @args
    end
  end

  def usage_error
    warn 'ERR: What do you want to search for?' unless @opts[:silent]
    puts HELP
    @done = true
  end

  def list_file_types
    puts 'The following file types are supported:'
    FILE_TYPES.sort.each do |name, exts|
      puts "  --#{name}"
      puts "      #{exts.join('  ')}"
      puts
    end
  end

  def make_regex(pat, search)
    source = @opts[:literal] && search ? Regexp.escape(pat) : pat
    source = "\\b(?:#{source})\\b" if @opts[:word] && search
    flags = 0
    if search
      insensitive = @opts[:ignore_case]
      insensitive = !pat.match?(/[A-Z]/) if @opts[:smart_case] && insensitive.nil?
      flags |= Regexp::IGNORECASE if insensitive
    end
    Regexp.new(source, flags)
  end

  def build_search_regex
    make_regex(@pattern, true)
  end

  def use_stdin?
    !@explicit_paths && !$stdin.tty? && !$stdin.eof?
  end

  def collect_files(paths)
    out = []
    paths.each do |path|
      if File.file?(path) || (@opts[:follow] && File.symlink?(path) && File.file?(File.realpath(path)))
        out << path if searchable_file?(path)
      elsif File.directory?(path)
        root = path.sub(%r{/+\z}, '')
        ignores = load_ignores_for(root)
        if @opts[:recurse]
          Find.find(path) do |p|
            next if p == path
            rel = p.sub(%r{\A#{Regexp.escape(root)}/?}, '')
            if File.directory?(p)
              if should_skip_dir?(p, rel, ignores) || too_deep?(rel)
                Find.prune
              end
              next
            end
            out << p if searchable_file?(p, rel, ignores)
          end
        else
          Dir.children(path).sort.each do |child|
            p = File.join(path, child)
            out << p if File.file?(p) && searchable_file?(p, child, ignores)
          end
        end
      else
        warn "ERR: Error stat()ing: #{path}" unless @opts[:silent]
        warn "ERR: Error opening directory #{path}: No such file or directory" unless @opts[:silent]
        @had_error = true
      end
    end
    out.sort
  end

  def too_deep?(rel)
    @opts[:depth] && @opts[:depth] >= 0 && rel.split('/').length > @opts[:depth]
  end

  def load_ignores_for(root)
    return [] if @opts[:unrestricted] || @opts[:all_types]

    patterns = @opts[:ignores].dup
    %w[.ignore].each { |n| patterns.concat(read_patterns(File.join(root, n))) }
    unless @opts[:skip_vcs_ignores]
      %w[.gitignore .hgignore].each { |n| patterns.concat(read_patterns(File.join(root, n))) }
    end
    home = ENV['HOME']
    patterns.concat(read_patterns(File.join(home, '.agignore'))) if home
    patterns
  end

  def read_ignore_file(path)
    @opts[:ignores].concat(read_patterns(path))
  end

  def read_patterns(path)
    return [] unless path && File.file?(path)

    File.readlines(path, chomp: true).map(&:strip).reject { |l| l.empty? || l.start_with?('#') }
  rescue StandardError
    []
  end

  def should_skip_dir?(path, rel, ignores)
    base = File.basename(path)
    return true if !@opts[:hidden] && base.start_with?('.')
    return false if @opts[:unrestricted] || @opts[:all_types]

    ignored?(rel, base, ignores)
  end

  def searchable_file?(path, rel = path, ignores = [])
    base = File.basename(path)
    return false if !@opts[:hidden] && base.start_with?('.')
    return false if @opts[:file_search_regex] && !path.match?(@opts[:file_search_regex])
    return false if @opts[:type_exts] && !@opts[:type_exts].include?(File.extname(path))
    return false if !(@opts[:unrestricted] || @opts[:all_types]) && ignored?(rel, base, ignores)

    true
  end

  def ignored?(rel, base, ignores)
    ignores.any? do |pat|
      p = pat.sub(%r{\A/}, '')
      p = p[0...-1] if p.end_with?('/')
      base == p || rel == p || File.fnmatch?(p, base, File::FNM_PATHNAME | File::FNM_DOTMATCH) ||
        File.fnmatch?(p, rel, File::FNM_PATHNAME | File::FNM_DOTMATCH) ||
        File.fnmatch?(p, rel, File::FNM_DOTMATCH)
    end
  end

  def binary?(data)
    data.include?("\x00")
  end

  def read_file(path)
    if @opts[:search_zip] && path.end_with?('.gz')
      Zlib::GzipReader.open(path, &:read)
    else
      File.binread(path)
    end
  rescue StandardError => e
    warn "ERR: Error opening file #{path}: #{e.message}" unless @opts[:silent]
    @had_error = true
    nil
  end

  def search_file(path)
    data = read_file(path)
    return empty_result unless data
    return empty_result if binary?(data) && !@opts[:search_binary]

    @files_scanned += 1
    @bytes_searched += data.bytesize
    lines = data.lines
    lines << '' if data.end_with?("\n")
    lines = [''] if lines.empty?
    matches = []
    count = 0
    lines.each_with_index do |line, idx|
      text = line.chomp
      found = match_line(text)
      if found
        line_matches = line_match_positions(text)
        line_matches = [[nil, nil, nil]] if line_matches.empty?
        line_matches.each do |start_col, match_text, _end_col|
          count += 1
          @matches_found += 1
          matches << { line: idx + 1, text: text, col: start_col, match: match_text }
          if @opts[:max_count] && @opts[:max_count] > 0 && count >= @opts[:max_count]
            if line_matches.length > 1 && count < line_matches.length
              next
            end
            if has_more_matches?(lines[(idx + 1)..] || [])
              warn "ERR: Too many matches in #{path}. Skipping the rest of this file." unless @opts[:silent]
            end
            return { matched: true, matches: matches, lines: lines.map(&:chomp), count: count }
          end
        end
      elsif @opts[:passthrough]
        matches << { line: idx + 1, text: text, col: nil, match: nil, passthrough: true }
      end
    end
    @files_with_matches += 1 if count.positive?
    { matched: count.positive?, matches: matches, lines: lines.map(&:chomp), count: count }
  end

  def empty_result
    { matched: false, matches: [], lines: [], count: 0 }
  end

  def match_line(text)
    matched = !!(text =~ @regex)
    @opts[:invert] ? !matched : matched
  end

  def line_match_positions(text)
    if @opts[:invert]
      match_line(text) ? [[1, text, text.length]] : []
    else
      arr = []
      text.to_enum(:scan, @regex).each do
        m = Regexp.last_match
        mt = m[0]
        arr << [m.begin(0) + 1, mt, m.end(0)]
      end
      arr
    end
  end

  def has_more_matches?(remaining)
    remaining.any? { |line| match_line(line.chomp) }
  end

  def search_stream(data)
    lines = data.split(/^/, -1)
    any = false
    lines.each_with_index do |line, idx|
      text = line.chomp
      found = match_line(text)
      any ||= found
      if found || @opts[:passthrough]
        prefix = @opts[:numbers] ? "#{idx + 1}:" : ''
        if @opts[:only] && found && !@opts[:invert]
          line_match_positions(text).each { |_, mt, _| puts "#{prefix}#{mt}" }
        else
          puts "#{prefix}#{text}"
        end
      end
    end
    any
  end

  def emit_results(file_results)
    printed = false
    file_results.each do |path, res|
      if @opts[:files_with]
        if res[:matched]
          print_name(path)
          printed = true
        end
      elsif @opts[:files_without]
        unless res[:matched]
          print_name(path)
          printed = true
        end
      elsif @opts[:count] || @opts[:stats_only]
        if res[:matched] || @opts[:print_all_files] || @opts[:stats_only]
          puts(filename? ? "#{path}:#{res[:count]}" : res[:count].to_s)
          printed = true
        end
      elsif @opts[:ackmate]
        if res[:matched]
          emit_ackmate(path, res)
          printed = true
        end
      elsif @opts[:only]
        if res[:matched]
          emit_only(path, res)
          printed = true
        end
      else
        if res[:matched] || @opts[:print_all_files]
          emit_file(path, res)
          printed = true
        end
      end
    end
    printed
  end

  def print_names(names)
    names.each { |n| print_name(n) }
  end

  def print_name(name)
    if @opts[:null]
      print name
      print "\0"
    else
      puts name
    end
  end

  def heading?
    return @opts[:heading] unless @opts[:heading].nil?
    false
  end

  def filename?
    return @opts[:filename] unless @opts[:filename].nil?
    @paths.length != 1 || !File.file?(@paths.first)
  end

  def emit_file(path, res)
    if @opts[:vimgrep]
      res[:matches].each do |m|
        next if m[:passthrough]
        puts "#{path}:#{m[:line]}:#{m[:col] || 1}:#{truncate(m[:text])}"
      end
      return
    end

    matches = context_matches(res)
    if heading? && filename?
      puts path
      matches.each { |m| puts line_prefix(m, false, nil, m[:col]) + truncate(m[:text]) }
    else
      matches.each { |m| puts line_prefix(m, filename?, path, m[:col]) + truncate(m[:text]) }
    end
  end

  def context_matches(res)
    by_line = {}
    res[:matches].each do |m|
      if m[:passthrough]
        by_line[m[:line]] ||= { line: m[:line], text: m[:text], matched: true }
        next
      end
      from = [1, m[:line] - @opts[:before]].max
      to = [res[:lines].length, m[:line] + @opts[:after]].min
      (from..to).each do |ln|
        text = res[:lines][ln - 1] || ''
        rec = (by_line[ln] ||= { line: ln, text: text, matched: false, col: nil })
        if ln == m[:line]
          rec[:matched] = true
          rec[:col] ||= m[:col]
        end
      end
    end
    by_line.keys.sort.map { |k| by_line[k] }
  end

  def line_prefix(m, include_file, path = nil, col = nil)
    return '' if @opts[:filename] == false
    sep = m[:matched] ? ':' : '-'
    return '' if @opts[:numbers] == false

    prefix = String.new
    prefix << "#{path}:" if include_file && path
    prefix << m[:line].to_s
    prefix << ":#{col}" if col && @opts[:column]
    prefix << sep
    prefix
  end

  def emit_only(path, res)
    res[:matches].each do |m|
      next if m[:passthrough]
      if @opts[:invert]
        puts [filename? ? path : nil, m[:line], @opts[:column] ? 1 : nil, m[:text]].compact.join(':')
      else
        parts = []
        parts << path if filename?
        parts << m[:line]
        parts << m[:col] if @opts[:column]
        parts << m[:match]
        puts parts.join(':')
      end
    end
  end

  def emit_ackmate(path, res)
    puts ":#{path}"
    res[:matches].each do |m|
      ranges = line_match_positions(m[:text]).map { |col, mt, _| "#{col - 1} #{mt.length}" }.join(',')
      puts "#{m[:line]};#{ranges}:#{m[:text]}"
    end
  end

  def truncate(text)
    return text unless @opts[:width] && text.length > @opts[:width]
    text[0, @opts[:width]]
  end

  def finish(code)
    if @opts[:stats]
      puts "#{@matches_found} matches"
      puts "#{@files_with_matches} files contained matches"
      puts "#{@files_scanned} files searched"
      puts "#{@bytes_searched} bytes searched"
      puts "0.000000 seconds"
    end
    @had_error ? 1 : code
  end
end

exit Ag.new(ARGV).run
