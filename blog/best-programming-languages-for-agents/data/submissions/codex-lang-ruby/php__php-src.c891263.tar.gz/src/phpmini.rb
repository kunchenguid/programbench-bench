#!/usr/bin/env ruby
# Minimal PHP CLI reimplementation for ProgramBench.

VERSION_TEXT = "PHP 8.6.0-dev (cli) (built: Apr 17 2026 20:00:58) (NTS)\n" \
  "Copyright (c) The PHP Group\n" \
  "Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies\n" \
  "    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies\n"

HELP_TEXT = <<~TXT
  Usage: executable [options] [-f] <file> [--] [args...]
     executable [options] -r <code> [--] [args...]
     executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]
     executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]
     executable [options] -S <addr>:<port> [-t docroot] [router]
     executable [options] -- [args...]
     executable [options] -a

    -a               Run as interactive shell (requires readline extension)
    -c <path>|<file> Look for php.ini file in this directory
    -n               No configuration (ini) files will be used
    -d foo[=bar]     Define INI entry foo with value 'bar'
    -e               Generate extended information for debugger/profiler
    -f <file>        Parse and execute <file>.
    -h               This help
    -i               PHP information
    -l               Syntax check only (lint)
    -m               Show compiled in modules
    -r <code>        Run PHP <code> without using script tags <?..?>
    -B <begin_code>  Run PHP <begin_code> before processing input lines
    -R <code>        Run PHP <code> for every input line
    -F <file>        Parse and execute <file> for every input line
    -E <end_code>    Run PHP <end_code> after processing all input lines
    -H               Hide any passed arguments from external tools.
    -S <addr>:<port> Run with built-in web server.
    -t <docroot>     Specify document root <docroot> for built-in web server.
    -s               Output HTML syntax highlighted source.
    -v               Version number
    -w               Output source with stripped comments and whitespace.

    args...          Arguments passed to script. Use -- args when first argument
                     starts with - or script is read from stdin

    --ini            Show configuration file names
    --ini=diff       Show INI entries that differ from the built-in default

    --rf <name>      Show information about function <name>.
    --rc <name>      Show information about class <name>.
    --re <name>      Show information about extension <name>.
    --rz <name>      Show information about Zend extension <name>.
    --ri <name>      Show configuration for extension <name>.

    --repeat <count> Repeat script execution <count> times.
                     For internal purposes only.

TXT

MODULES = %w[Core date hash json lexbor pcre random Reflection SPL standard uri Zend\ OPcache]
PHP_VERSION = '8.6.0-dev'
PHP_EOL = "\n"
STDIN_CONST = STDIN

def php_str(v)
  case v
  when nil then ''
  when true then '1'
  when false then ''
  when Array, Hash then 'Array'
  else
    if v.is_a?(Float) && v == v.to_i
      v.to_i.to_s
    else
      v.to_s
    end
  end
end

def php_bool(v)
  !(v.nil? || v == false || v == 0 || v == 0.0 || v == '' || v == '0' || (v.respond_to?(:empty?) && v.empty?))
end

def html_escape(s)
  s.to_s.gsub('&', '&amp;').gsub('<', '&lt;').gsub('>', '&gt;').gsub('"', '&quot;')
end

def php_add(a, b) a.to_f == a.to_i && b.to_f == b.to_i ? a.to_i + b.to_i : a.to_f + b.to_f end
def php_sub(a, b) a.to_f == a.to_i && b.to_f == b.to_i ? a.to_i - b.to_i : a.to_f - b.to_f end
def php_mul(a, b) a.to_f == a.to_i && b.to_f == b.to_i ? a.to_i * b.to_i : a.to_f * b.to_f end
def php_div(a, b) a.to_f / b.to_f end
def php_mod(a, b) a.to_i % b.to_i end

def strlen(s) php_str(s).bytesize end
def count(v) v.respond_to?(:length) ? v.length : (v.nil? ? 0 : 1) end
def sizeof(v) count(v) end
def strtoupper(s) php_str(s).upcase end
def strtolower(s) php_str(s).downcase end
def ucfirst(s) t = php_str(s); t[0] ? t[0].upcase + t[1..].to_s : t end
def trim(s, chars = nil) chars ? php_str(s).delete_prefix(chars).delete_suffix(chars) : php_str(s).strip end
def ltrim(s) php_str(s).lstrip end
def rtrim(s) php_str(s).rstrip end
def substr(s, start, len = nil) len.nil? ? php_str(s)[start.to_i..].to_s : php_str(s)[start.to_i, len.to_i].to_s end
def strpos(h, n, off = 0) i = php_str(h).index(php_str(n), off.to_i); i.nil? ? false : i end
def str_replace(search, repl, subj) php_str(subj).gsub(php_str(search), php_str(repl)) end
def explode(sep, s, limit = nil) limit ? php_str(s).split(php_str(sep), limit.to_i) : php_str(s).split(php_str(sep), -1) end
def implode(sep, arr = nil) arr.nil? ? sep.to_a.join('') : arr.to_a.join(php_str(sep)) end
def join(sep, arr = nil) implode(sep, arr) end
def mini_json_encode(v)
  case v
  when nil then 'null'
  when true then 'true'
  when false then 'false'
  when Numeric then v.to_s
  when String then '"' + v.gsub(/["\\\n\r\t]/, '"' => '\"', '\\' => '\\\\', "\n" => '\n', "\r" => '\r', "\t" => '\t') + '"'
  when Array then '[' + v.map { |x| mini_json_encode(x) }.join(',') + ']'
  when Hash then '{' + v.map { |k, x| mini_json_encode(k.to_s) + ':' + mini_json_encode(x) }.join(',') + '}'
  else mini_json_encode(v.to_s)
  end
end
def json_encode(v, *_) mini_json_encode(v) end
def json_decode(s, assoc = nil, *_)
  txt = php_str(s).strip
  ruby = txt.gsub(/\bnull\b/, 'nil').gsub(/\btrue\b/, 'true').gsub(/\bfalse\b/, 'false')
  ruby = ruby.gsub(/"([^"\\]*(?:\\.[^"\\]*)*)"\s*:/, '"\1"=>')
  eval(ruby)
rescue Exception
  nil
end
def json_validate(s, *_) !json_decode(s).nil? || php_str(s).strip == 'null' end
def json_last_error() 0 end
def json_last_error_msg() 'No error' end
def file_get_contents(path) path == 'php://stdin' ? STDIN.read : File.read(php_str(path)) rescue false end
def file_put_contents(path, data, *_) File.write(php_str(path), php_str(data)) end
def fopen(path, mode = 'r') File.open(php_str(path), php_str(mode)) rescue false end
def fclose(f) f.close; true rescue false end
def fgets(f) f.gets rescue false end
def fread(f, len) f.read(len.to_i) rescue false end
def fwrite(f, data) f.write(php_str(data)) rescue false end
def basename(p) File.basename(php_str(p)) end
def dirname(p) File.dirname(php_str(p)) end
def file_exists(p) File.exist?(php_str(p)) end
def is_file(p) File.file?(php_str(p)) end
def is_dir(p) File.directory?(php_str(p)) end
def preg_match(pattern, subject, matches = nil)
  body = php_str(pattern)
  if body.start_with?('/') && body.rindex('/')&.positive?
    last = body.rindex('/')
    body = body[1...last]
  end
  !!(php_str(subject) =~ Regexp.new(body))
rescue Exception
  false
end
def define(name, value, *_) Object.const_set(php_str(name), value) rescue nil; true end
def time() Time.now.to_i end
def date(fmt, ts = nil)
  t = Time.at(ts || Time.now.to_i).utc
  php_str(fmt).gsub('Y', t.strftime('%Y')).gsub('m', t.strftime('%m')).gsub('d', t.strftime('%d')).gsub('H', t.strftime('%H')).gsub('i', t.strftime('%M')).gsub('s', t.strftime('%S'))
end
def md5(s) require 'digest'; Digest::MD5.hexdigest(php_str(s)) end
def sha1(s) require 'digest'; Digest::SHA1.hexdigest(php_str(s)) end
def abs(v) v.abs end
def max(*a) a.flatten.max end
def min(*a) a.flatten.min end
def round(v, n = 0) v.to_f.round(n.to_i) end
def floor(v) v.to_f.floor end
def ceil(v) v.to_f.ceil end
def rand(min = nil, max = nil) min && max ? Kernel.rand(min.to_i..max.to_i) : Kernel.rand(0..(2**31 - 1)) end
def gettype(v) ({NilClass=>'NULL', TrueClass=>'boolean', FalseClass=>'boolean', Integer=>'integer', Float=>'double', String=>'string', Array=>'array', Hash=>'array'}[v.class] || 'object') end
def is_array(v) v.is_a?(Array) || v.is_a?(Hash) end
def is_string(v) v.is_a?(String) end
def is_int(v) v.is_a?(Integer) end
def is_integer(v) is_int(v) end
def is_numeric(v) v.is_a?(Numeric) || php_str(v).match?(/\A[+-]?\d+(\.\d+)?\z/) end
def empty(v) !php_bool(v) end
def isset(*vals) vals.all? { |v| !v.nil? } end

def var_dump(*vals)
  vals.each { |v| dump_value(v, 0) }
end

def dump_value(v, indent = 0)
  pad = '  ' * indent
  case v
  when nil then puts "#{pad}NULL"
  when true, false then puts "#{pad}bool(#{v ? 'true' : 'false'})"
  when Integer then puts "#{pad}int(#{v})"
  when Float then puts "#{pad}float(#{v})"
  when String then puts "#{pad}string(#{v.bytesize}) \"#{v}\""
  when Array
    puts "#{pad}array(#{v.length}) {"
    v.each_with_index { |x, i| puts "#{pad}  [#{i}]=>"; dump_value(x, indent + 1) }
    puts "#{pad}}"
  when Hash
    puts "#{pad}array(#{v.length}) {"
    v.each { |k, x| puts "#{pad}  [#{k.is_a?(String) ? '"' + k + '"' : k}]=>"; dump_value(x, indent + 1) }
    puts "#{pad}}"
  else puts "#{pad}#{v.inspect}"
  end
end

def print_r(v)
  if v.is_a?(Array) || v.is_a?(Hash)
    puts 'Array'
    puts '('
    enum = v.is_a?(Array) ? v.each_with_index.map { |x, i| [i, x] } : v.to_a
    enum.each { |k, x| puts "    [#{k}] => #{php_str(x)}" }
    puts ')'
  else
    print php_str(v)
  end
  true
end

class MiniPHP
  def initialize(argv0, script_args)
    @argv0 = argv0
    @script_args = script_args
  end

  def run_code(code, tags: false)
    ruby = translate(tags ? extract_php(code) : code)
    warn ruby if ENV['PHPMINI_DEBUG']
    TOPLEVEL_BINDING.eval(setup_code + ruby)
    0
  rescue SystemExit => e
    e.status || 0
  rescue Exception => e
    warn "Parse error: syntax error, #{e.message}"
    255
  end

  def extract_php(src)
    out = +''
    pos = 0
    while (i = src.index(/<\?(?:php|=)?/i, pos))
      out << "echo #{src[pos...i].inspect};\n" if i > pos
      j = src.index('?>', i + 2)
      tag = src[i...(src.index(' ', i) || i + 5)]
      body_start = src[i, 3] == '<?=' ? i + 3 : (src[i, 5].downcase == '<?php' ? i + 5 : i + 2)
      if j
        body = src[body_start...j]
        out << (src[i, 3] == '<?=' ? "echo #{body};\n" : body)
        pos = j + 2
      else
        out << src[body_start..].to_s
        pos = src.length
      end
    end
    out << "echo #{src[pos..].to_s.inspect};\n" if pos < src.length
    out
  end

  def setup_code
    "php_argv=#{([@argv0] + @script_args).inspect}; php_argc=php_argv.length; php__SERVER={'argv'=>php_argv,'argc'=>php_argc};\n"
  end

  def translate(code)
    s = strip_comments(code)
    s = s.gsub(/\b(array)\s*\(/, '[')
    s = balance_array_parens(s)
    stmts = normalize_brace_else(split_statements(s))
    render_lines(stmts.flat_map { |st| translate_stmt(st.strip).split("\n") })
  end

  def render_lines(lines)
    stack = []
    out = []
    lines.each do |line|
      if line.include?('__FOR_INC__')
        inc = line.sub(/.*__FOR_INC__/, '')
        line = line.sub(/\s*__FOR_INC__.*/, '')
        out << line
        stack << inc
      elsif line == 'end' && stack.any?
        out << stack.pop
        out << line
      else
        out << line
      end
    end
    out.join("\n")
  end

  def normalize_brace_else(stmts)
    out = []
    i = 0
    while i < stmts.length
      cur = stmts[i].strip
      nxt = stmts[i + 1]&.strip
      if cur == '}' && nxt&.match?(/\Aelse(?:if\b.*)?\s*\{\z/)
        out << nxt
        i += 2
      else
        out << stmts[i]
        i += 1
      end
    end
    out
  end

  def strip_comments(s)
    s.gsub(%r{/\*.*?\*/}m, '').gsub(%r{//.*$}, '').gsub(/#.*$/, '')
  end

  def balance_array_parens(s)
    # Enough for common array(...) literals: convert array(1,2) to [1,2].
    s
  end

  def split_statements(s)
    out = []
    cur = +''
    quote = nil
    depth = 0
    i = 0
    while i < s.length
      ch = s[i]
      if quote
        cur << ch
        if ch == '\\'
          i += 1; cur << s[i].to_s
        elsif ch == quote
          quote = nil
        end
      else
        case ch
        when "'", '"'
          quote = ch; cur << ch
        when '(', '[', '{'
          if ch == '{' && depth == 0
            out << (cur + ch); cur = +''
          else
            depth += 1; cur << ch
          end
        when ')', ']'
          depth -= 1 if depth > 0; cur << ch
        when '}'
          out << cur unless cur.strip.empty?
          out << '}'; cur = +''
        when ';'
          if depth == 0
            out << cur; cur = +''
          else
            cur << ch
          end
        else
          cur << ch
        end
      end
      i += 1
    end
    out << cur unless cur.strip.empty?
    out
  end

  def translate_stmt(st)
    return '' if st.empty? || st == '<?php'
    return 'end' if st == '}'
    if st =~ /\A}\s*else\s*{\z/ then return 'else' end
    if st =~ /\A}\s*elseif\s*\((.*)\)\s*{\z/ then return "elsif #{expr($1)}" end
    if st =~ /\Aelse\s*{\z/ then return 'else' end
    if st =~ /\Aif\s*\((.*)\)\s*{\z/ then return "if php_bool(#{expr($1)})" end
    if st =~ /\Aelseif\s*\((.*)\)\s*{\z/ then return "elsif php_bool(#{expr($1)})" end
    if st =~ /\Awhile\s*\((.*)\)\s*{\z/ then return "while php_bool(#{expr($1)})" end
    if st =~ /\Afor\s*\((.*);(.*);(.*)\)\s*{\z/
      init = translate_stmt($1)
      cond = expr($2)
      inc = expr($3)
      return "#{init}\nwhile php_bool(#{cond})\n__FOR_INC__#{inc}"
    end
    if st =~ /\Aforeach\s*\((.*)\s+as\s+(?:([^=]+)=>\s*)?(.*)\)\s*{\z/
      arr = expr($1); val = varname($3.strip)
      if $2
        key = varname($2.strip)
        return "(#{arr}.is_a?(Hash) ? #{arr}.to_a : #{arr}.each_with_index.map{|v,i|[i,v]}).each do |#{key}, #{val}|"
      else
        return "#{arr}.each do |#{val}|"
      end
    end
    if st =~ /\Afunction\s+([A-Za-z_]\w*)\s*\((.*?)\)\s*{\z/
      fname = $1
      args = $2.split(',').map { |a| varname(a.strip.sub(/=.*/, '')) }.join(', ')
      return "def #{fname}(#{args})"
    end
    return "return #{expr(st.sub(/\Areturn\s+/, ''))}" if st =~ /\Areturn\b/
    return "exit(#{expr($1)})" if st =~ /\A(?:exit|die)\s*\((.*)\)\z/
    return 'exit(0)' if st =~ /\A(?:exit|die)\z/
    if st =~ /\Aecho\s+(.+)\z/
      return split_args($1).map { |a| "print php_str(#{expr(a)})" }.join("\n")
    end
    if st =~ /\Aprint\s+(.+)\z/
      return "print php_str(#{expr($1)})"
    end
    expr(st)
  end

  def varname(s)
    'php_' + s.gsub(/^\s*\$/, '').gsub(/[^\w]/, '')
  end

  def split_args(s)
    out = []; cur = +''; quote = nil; depth = 0; i = 0
    while i < s.length
      ch = s[i]
      if quote
        cur << ch
        if ch == '\\' then i += 1; cur << s[i].to_s elsif ch == quote then quote = nil end
      else
        case ch
        when "'", '"' then quote = ch; cur << ch
        when '(', '[' then depth += 1; cur << ch
        when ')', ']' then depth -= 1; cur << ch
        when ',' then depth == 0 ? (out << cur; cur = +'') : cur << ch
        else cur << ch
        end
      end
      i += 1
    end
    out << cur unless cur.empty?
    out
  end

  def expr(e)
    x = e.strip
    if (tern = split_ternary(x))
      return "(php_bool(#{expr(tern[0])}) ? #{expr(tern[1])} : #{expr(tern[2])})"
    end
    x = x.gsub(/\btrue\b/i, 'true').gsub(/\bfalse\b/i, 'false').gsub(/\bnull\b/i, 'nil')
    x = x.gsub('!==', '!=').gsub('===', '==')
    x = convert_strings(x)
    x = x.gsub(/\$(\w+)\s*\[\s*([^\]]+)\s*\]/, 'php_\1[\2]')
    x = x.gsub(/\$(\w+)/, 'php_\1')
    x = x.gsub(/(php_\w+)\s*\+\+/, '\1 += 1').gsub(/(php_\w+)\s*--/, '\1 -= 1')
    x = x.gsub(/->/, '.')
    x = x.gsub(/\bAND\b/i, '&&').gsub(/\bOR\b/i, '||')
    x = x.gsub(/(?<![=!<>])!(?!=)/, '!')
    x = x.gsub(/\.=/, '+=')
    x = concat_rewrite(x)
    x = x.gsub(/\barray\s*\(/, '[')
    x = x.gsub(/\)\s*$/, ']') if x.count('[') > x.count(']')
    x = rewrite_php_arrays(x)
    x
  end

  def split_ternary(s)
    quote = nil; depth = 0; qpos = nil; i = 0
    while i < s.length
      ch = s[i]
      if quote
        if ch == '\\' then i += 1 elsif ch == quote then quote = nil end
      else
        if ch == '"' || ch == "'" then quote = ch
        elsif ch == '(' || ch == '[' then depth += 1
        elsif ch == ')' || ch == ']' then depth -= 1
        elsif ch == '?' && depth == 0 then qpos = i
        elsif ch == ':' && depth == 0 && qpos
          return [s[0...qpos], s[(qpos + 1)...i], s[(i + 1)..]]
        end
      end
      i += 1
    end
    nil
  end

  def rewrite_php_arrays(s)
    out = +''
    i = 0
    while i < s.length
      if s[i] == '['
        j = matching_bracket(s, i)
        if j
          inner = s[(i + 1)...j]
          repl = array_literal(inner)
          out << repl
          i = j + 1
          next
        end
      end
      out << s[i]
      i += 1
    end
    out
  end

  def matching_bracket(s, start)
    quote = nil; depth = 0; i = start
    while i < s.length
      ch = s[i]
      if quote
        if ch == '\\' then i += 1 elsif ch == quote then quote = nil end
      else
        if ch == '"' || ch == "'" then quote = ch
        elsif ch == '[' then depth += 1
        elsif ch == ']'
          depth -= 1
          return i if depth == 0
        end
      end
      i += 1
    end
    nil
  end

  def array_literal(inner)
    parts = split_args(inner)
    return '[]' if parts.empty?
    if parts.any? { |p| top_level_arrow?(p) }
      idx = 0
      items = parts.map do |p|
        if top_level_arrow?(p)
          k, v = split_arrow(p)
          "#{k.strip}=>#{v.strip}"
        else
          r = "#{idx}=>#{p.strip}"
          idx += 1
          r
        end
      end
      '{' + items.join(',') + '}'
    else
      '[' + parts.map(&:strip).join(',') + ']'
    end
  end

  def top_level_arrow?(s)
    !!split_arrow(s)
  end

  def split_arrow(s)
    quote = nil; depth = 0; i = 0
    while i < s.length - 1
      ch = s[i]
      if quote
        if ch == '\\' then i += 1 elsif ch == quote then quote = nil end
      else
        if ch == '"' || ch == "'" then quote = ch
        elsif ch == '[' || ch == '(' then depth += 1
        elsif ch == ']' || ch == ')' then depth -= 1
        elsif ch == '=' && s[i + 1] == '>' && depth == 0
          return [s[0...i], s[(i + 2)..]]
        end
      end
      i += 1
    end
    nil
  end

  def convert_strings(s)
    s.gsub(/"((?:\\.|[^"\\])*)"/) do
      body = $1.gsub(/\$(\w+)/, '#{php_\1}')
      '"' + body + '"'
    end
  end

  def concat_rewrite(s)
    parts = []
    cur = +''; quote = nil; depth = 0; i = 0
    while i < s.length
      ch = s[i]
      if quote
        cur << ch
        if ch == '\\' then i += 1; cur << s[i].to_s elsif ch == quote then quote = nil end
      else
        if ch == '"' || ch == "'"
          quote = ch; cur << ch
        elsif ch == '(' || ch == '[' || ch == '{'
          depth += 1; cur << ch
        elsif ch == ')' || ch == ']' || ch == '}'
          depth -= 1; cur << ch
        elsif ch == '.' && depth == 0 && s[i-1] !~ /\d/ && s[i+1] !~ /\d/
          parts << cur; cur = +''
        else
          cur << ch
        end
      end
      i += 1
    end
    parts << cur
    return s if parts.length == 1
    parts.map { |p| "php_str(#{p.strip})" }.join(' + ')
  end
end

def show_modules
  puts "[PHP Modules]"
  MODULES[0..-2].each { |m| puts m }
  puts
  puts "[Zend Modules]"
  puts "Zend OPcache"
end

def show_ini
  puts 'Configuration File (php.ini) Path: "/usr/local/lib"'
  puts 'Loaded Configuration File:         (none)'
  puts 'Scan for additional .ini files in: (none)'
  puts 'Additional .ini files parsed:      (none)'
end

def show_info
  puts 'phpinfo()'
  puts 'PHP Version => 8.6.0-dev'
  puts
  puts 'System => Linux'
  puts 'Build Date => Apr 17 2026 20:00:58'
  puts "Configure Command =>  './configure'  '--disable-all' '--enable-cli' '--enable-debug=no'"
  puts 'Server API => Command Line Interface'
  puts 'Configuration File (php.ini) Path => /usr/local/lib'
  puts 'Loaded Configuration File => (none)'
  puts 'PHP API => 20250926'
  puts 'Zend Extension Build => API420250926,NTS'
  puts
  puts 'This program makes use of the Zend Scripting Language Engine:'
  puts "Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies\n    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies"
  puts
  puts 'Configuration'
  puts 'Core'
  puts 'PHP Version => 8.6.0-dev'
end

def reflection_function(name)
  puts "Function [ <internal:standard> function #{name} ] {\n\n  - Parameters [0] {\n  }\n}\n"
end

def syntax_ok?(code)
  code.count('(') == code.count(')') && code.count('{') == code.count('}') && code.count('[') == code.count(']')
end

args = ARGV.dup
script_args = []
mode = nil
payload = nil
begin_code = end_code = nil

while args.any?
  a = args.shift
  case a
  when '--'
    script_args = args; break
  when '-h', '--help' then print HELP_TEXT; exit 0
  when '-v' then print VERSION_TEXT; exit 0
  when '-m' then show_modules; exit 0
  when '--ini' then show_ini; exit 0
  when '--ini=diff' then puts "Non-default INI settings:\nhtml_errors: \"1\" -> \"0\"\nimplicit_flush: \"0\" -> \"1\"\nmax_execution_time: \"30\" -> \"0\""; exit 0
  when '-i' then show_info; exit 0
  when '-r' then mode = :run; payload = args.shift.to_s
  when '-f' then mode = :file; payload = args.shift.to_s
  when '-l' then mode = :lint; payload = args.shift
  when '-s' then mode = :highlight; payload = args.shift
  when '-w' then mode = :strip; payload = args.shift
  when '-B' then begin_code = args.shift.to_s
  when '-R' then mode = :lines; payload = args.shift.to_s
  when '-F' then mode = :linefile; payload = args.shift.to_s
  when '-E' then end_code = args.shift.to_s
  when '--rf' then reflection_function(args.shift.to_s); exit 0
  when '--rc' then puts "Class [ <internal> class #{args.shift} ] {\n}\n"; exit 0
  when '--re' then puts "Extension [ <persistent> extension #{args.shift} version 8.6.0-dev ] {\n}\n"; exit 0
  when '--ri' then puts "#{args.shift}\n\n#{a} support => enabled"; exit 0
  when '-n', '-e', '-H' then next
  when '-d', '-c', '--repeat', '-t', '-S' then args.shift; next
  else
    if a.start_with?('-')
      warn "Error in argument 1, char 2: option not found #{a[1]}"
      print HELP_TEXT
      exit 1
    else
      mode ||= :file
      payload ||= a
      script_args = args
      break
    end
  end
end

case mode
when :lint
  file = payload || args.shift
  code = file && file != '-' ? File.read(file) : STDIN.read
  if syntax_ok?(code)
    puts "No syntax errors detected in #{file || 'Standard input code'}"
    exit 0
  else
    puts "Errors parsing #{file}"
    exit 255
  end
when :highlight
  src = File.read(payload)
  print %(<pre><code style="color: #000000">#{html_escape(src)}</code></pre>)
  exit 0
when :strip
  print File.read(payload).gsub(%r{/\*.*?\*/}m, '').gsub(%r{//.*$}, '').gsub(/#.*$/, '')
  exit 0
when :file
  code = payload == '-' ? STDIN.read : File.read(payload)
  exit MiniPHP.new(payload, script_args).run_code(code, tags: true)
when :run
  exit MiniPHP.new('Command line code', script_args).run_code(payload, tags: false)
when :lines, :linefile
  interp = MiniPHP.new('Command line code', script_args)
  interp.run_code(begin_code, tags: false) if begin_code
  line_code = mode == :linefile ? File.read(payload) : payload
  STDIN.each_line.with_index(1) do |line, idx|
    TOPLEVEL_BINDING.eval("php_argn=#{line.inspect}; php_argi=#{idx};")
    interp.run_code(line_code, tags: mode == :linefile)
  end
  interp.run_code(end_code, tags: false) if end_code
  exit 0
else
  print HELP_TEXT
  exit 0
end
