#!/usr/bin/env ruby
require 'find'
require 'fileutils'

VERSION = 'deadnix 1.3.1'
IDENT = /[A-Za-z_][A-Za-z0-9_'-]*/

Options = Struct.new(:lambda_arg, :lambda_patterns, :underscore, :warn_used_underscore, :quiet, :edit, :hidden, :fail, :format, :excludes, :paths, keyword_init: true)

class Analyzer
  Decl = Struct.new(:name, :line, :column, :end_column, :message, :kind, :line_index, :name_start0, :name_end0, keyword_init: true)

  def initialize(path, opts)
    @path = path
    @opts = opts
    @text = File.read(path)
    @lines = @text.lines
    @clean = scrub(@text)
    @line_offsets = []
    off = 0
    @lines.each { |l| @line_offsets << off; off += l.bytesize }
  end

  def analyze
    decls = []
    skip_next = {}
    @lines.each_with_index do |line, i|
      skip_next[i + 1] = true if line.include?('deadnix: skip')
    end

    decls.concat(find_attrset_lambdas(skip_next))
    decls.concat(find_simple_lambdas(skip_next)) if @opts.lambda_arg
    decls.concat(find_let_bindings(skip_next))

    results = []
    decls.each do |d|
      next if d.name.start_with?('_') && @opts.underscore && !(d.kind == :lambda_arg)
      used = used?(d)
      if d.name.start_with?('_') && used && @opts.warn_used_underscore && d.kind == :let
        results << result_hash(d, "Used let binding: #{d.name}")
      elsif !used
        results << result_hash(d, d.message)
      end
    end
    results.sort_by { |r| [r[:line], r[:column], r[:message]] }
  end

  def edit!(results)
    return if results.empty?
    new_lines = @lines.dup
    remove_lines = {}
    removals_by_line = Hash.new { |h,k| h[k] = [] }
    results.each do |r|
      if r[:message].start_with?('Unused let binding:')
        idx = r[:line] - 1
        # Remove only simple one-line let declarations ending in semicolon.
        remove_lines[idx] = true if new_lines[idx] && new_lines[idx].include?(';')
      elsif r[:message].start_with?('Unused lambda pattern:') || r[:message].start_with?('Unused lambda argument:')
        removals_by_line[r[:line] - 1] << [r[:column] - 1, r[:endColumn] - 1]
      end
    end
    removals_by_line.each do |idx, spans|
      next if remove_lines[idx] || new_lines[idx].nil?
      line = new_lines[idx].dup
      spans.sort_by { |a| -a[0] }.each do |s,e|
        # Prefer removing surrounding comma/space in attrset patterns.
        left = s
        right = e
        if line[right..]&.match?(/\A\s*,/)
          right += line[right..].match(/\A\s*,\s*/)[0].length
        elsif line[0...left]&.match?(/,\s*\z/)
          m = line[0...left].match(/,\s*\z/)[0]
          left -= m.length
        end
        line[left...right] = ''
      end
      line.gsub!(/@\s*\{/, '{')
      new_lines[idx] = line
    end
    output = new_lines.each_with_index.reject { |_,i| remove_lines[i] }.map(&:first).join
    File.write(@path, output)
  end

  private

  def result_hash(d, msg)
    { column: d.column, endColumn: d.end_column, line: d.line, message: msg }
  end

  def scrub(s)
    out = +''
    i = 0
    while i < s.length
      if s[i] == '#'
        while i < s.length && s[i] != "\n"
          out << ' '
          i += 1
        end
      else
        out << s[i]
        i += 1
      end
    end
    out
  end

  def pos_to_line_col(pos)
    idx = @line_offsets.bsearch_index { |o| o > pos }
    line_idx = idx ? idx - 1 : @line_offsets.length - 1
    [line_idx + 1, pos - @line_offsets[line_idx] + 1, line_idx]
  end

  def in_let_context?(pos)
    prefix = @clean[0...pos]
    last_let = nil
    prefix.to_enum(:scan, /\blet\b/).each { last_let = Regexp.last_match.begin(0) }
    return false unless last_let
    last_in = nil
    prefix.to_enum(:scan, /\bin\b/).each { last_in = Regexp.last_match.begin(0) }
    last_in.nil? || last_let > last_in
  end

  def find_let_bindings(skip_next)
    decls = []
    @clean.to_enum(:scan, /\bin\b|\blet\b|\binherit\s*(?:\([^)]*\)\s*)?([^;]+);|(^|[\n{;])([ \t]*)(#{IDENT})(?:\.[A-Za-z0-9_'-]+)?\s*=/m).each do
      m = Regexp.last_match
      if m[1]
        next unless in_let_context?(m.begin(0))
        names = m[1].scan(IDENT).flatten.reject { |n| %w[inherit rec let in true false null].include?(n) }
        base = m.begin(1)
        names.each do |n|
          p = @clean.index(/\b#{Regexp.escape(n)}\b/, base)
          line, col, li = pos_to_line_col(p)
          next if skip_next[li]
          decls << Decl.new(name: n, line: line, column: col, end_column: col + n.length, message: "Unused let binding: #{n}", kind: :let, line_index: li, name_start0: p, name_end0: p + n.length)
        end
      elsif m[4]
        p = m.begin(4)
        next unless in_let_context?(p)
        line, col, li = pos_to_line_col(p)
        next if skip_next[li]
        name = m[4]
        decls << Decl.new(name: name, line: line, column: col, end_column: col + name.length, message: "Unused let binding: #{name}", kind: :let, line_index: li, name_start0: p, name_end0: p + name.length)
      end
    end
    @clean.to_enum(:scan, /\blet\s+([ \t]*)(#{IDENT})\s*=/m).each do
      m = Regexp.last_match
      name = m[2]
      p = m.begin(2)
      next if decls.any? { |d| d.name_start0 == p }
      line, col, li = pos_to_line_col(p)
      next if skip_next[li]
      decls << Decl.new(name: name, line: line, column: col, end_column: col + name.length, message: "Unused let binding: #{name}", kind: :let, line_index: li, name_start0: p, name_end0: p + name.length)
    end
    decls
  end

  def find_simple_lambdas(skip_next)
    decls = []
    @clean.to_enum(:scan, /(^|[^A-Za-z0-9_'.?])([A-Za-z_][A-Za-z0-9_'-]*)\s*:/m).each do
      m = Regexp.last_match
      name = m[2]
      next if %w[if then else let in inherit rec with assert].include?(name)
      p = m.begin(2)
      line, col, li = pos_to_line_col(p)
      next if skip_next[li] || name.start_with?('_')
      # Avoid alias@{...}: and attr keys like x = { a, ... }:
      before = @clean[[0, p - 3].max...p]
      next if before&.include?('@') && @clean[p, 80]&.include?('{')
      decls << Decl.new(name: name, line: line, column: col, end_column: col + name.length, message: "Unused lambda argument: #{name}", kind: :lambda_arg, line_index: li, name_start0: p, name_end0: p + name.length)
    end
    decls
  end

  def find_attrset_lambdas(skip_next)
    decls = []
    @clean.to_enum(:scan, /(?:(#{IDENT})\s*@\s*)?\{([^{}]*)\}\s*(?:@\s*(#{IDENT}))?\s*:/m).each do
      m = Regexp.last_match
      alias_name = m[1] || m[3]
      if alias_name
        p = m[1] ? m.begin(1) : m.begin(3)
        line, col, li = pos_to_line_col(p)
        unless skip_next[li]
          decls << Decl.new(name: alias_name, line: line, column: col, end_column: col + alias_name.length, message: "Unused lambda pattern: #{alias_name}", kind: :lambda_alias, line_index: li, name_start0: p, name_end0: p + alias_name.length)
        end
      end
      next unless @opts.lambda_patterns
      body = m[2]
      body_start = m.begin(2)
      body.split(',').each do |part|
        next if part.include?('...')
        if part =~ /\b(#{IDENT})\b/
          n = Regexp.last_match(1)
          next if %w[true false null].include?(n)
          p = @clean.index(/\b#{Regexp.escape(n)}\b/, body_start)
          line, col, li = pos_to_line_col(p)
          next if skip_next[li]
          decls << Decl.new(name: n, line: line, column: col, end_column: col + n.length, message: "Unused lambda pattern: #{n}", kind: :lambda_pattern, line_index: li, name_start0: p, name_end0: p + n.length)
        end
        body_start += part.length + 1
      end
    end
    decls
  end

  def used?(decl)
    txt = @clean.dup
    txt[decl.name_start0...decl.name_end0] = ' ' * (decl.name_end0 - decl.name_start0)
    if decl.kind == :let
      line_start = @line_offsets[decl.line_index]
      line_end = line_start + @lines[decl.line_index].bytesize
      eq = txt.index('=', line_start)
      if eq && eq < line_end
        txt[line_start..eq] = ' ' * (eq - line_start + 1)
      end
      txt.gsub!(/\blet\s+#{Regexp.escape(decl.name)}\b.*?\bin\b.*?(?=[;\n}])/, ' ')
    elsif decl.kind == :lambda_arg || decl.kind == :lambda_pattern
      colon = txt.index(':', decl.name_end0) || decl.name_end0
      txt = ' ' * (colon + 1) + txt[(colon + 1)..].to_s
    elsif decl.kind == :lambda_alias
      # aliases are also in scope in default expressions inside the pattern
    end
    txt.to_enum(:scan, /(?<![A-Za-z0-9_'-])#{Regexp.escape(decl.name)}(?![A-Za-z0-9_'-])/).any? do
      m = Regexp.last_match
      after = txt[m.end(0)..]
      !(after && after.match?(/\A\s*:/))
    end
  end

end


def json_escape(s)
  s.to_s.gsub(/[\\"]/){ |c| c == '\\' ? '\\\\' : '\\"' }.gsub("\n", '\\n').gsub("\r", '\\r').gsub("\t", '\\t')
end

def json_value(v)
  case v
  when Hash then json_object(v)
  when Array then '[' + v.map { |x| json_value(x) }.join(',') + ']'
  when String then '"' + json_escape(v) + '"'
  when Symbol then '"' + json_escape(v.to_s) + '"'
  when Numeric then v.to_s
  when true then 'true'
  when false then 'false'
  when nil then 'null'
  else '"' + json_escape(v.to_s) + '"'
  end
end

def json_object(h)
  '{' + h.map { |k,v| '"' + json_escape(k.to_s) + '":' + json_value(v) }.join(',') + '}'
end

def parse_args(argv)
  opts = Options.new(lambda_arg: true, lambda_patterns: true, underscore: false, warn_used_underscore: false, quiet: false, edit: false, hidden: false, fail: false, format: 'human-readable', excludes: [], paths: [])
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when '--help'
      puts HELP; exit 0
    when '-V', '--version'
      puts VERSION; exit 0
    when '-l', '--no-lambda-arg' then opts.lambda_arg = false
    when '-L', '--no-lambda-pattern-names' then opts.lambda_patterns = false
    when '-_', '--no-underscore' then opts.underscore = true
    when '-W', '--warn-used-underscore' then opts.warn_used_underscore = true
    when '-q', '--quiet' then opts.quiet = true
    when '-e', '--edit' then opts.edit = true
    when '-h', '--hidden' then opts.hidden = true
    when '-f', '--fail' then opts.fail = true
    when '-o', '--output-format'
      i += 1; opts.format = argv[i] || ''
      unless %w[human-readable json].include?(opts.format)
        warn "error: invalid value '#{opts.format}' for '--output-format <OUTPUT_FORMAT>'"
        exit 2
      end
    when '--exclude'
      i += 1
      while i < argv.length && argv[i] != '--'
        opts.excludes << argv[i]; i += 1
      end
    when '--'
      # clap treats this as ending option parsing; remaining are paths.
      opts.paths.concat(argv[(i+1)..] || []); break
    else
      if a.start_with?('-') && a.length > 2
        # allow compact short flags such as -eq and -lL
        a[1..].each_char do |c|
          case c
          when 'l' then opts.lambda_arg = false
          when 'L' then opts.lambda_patterns = false
          when '_' then opts.underscore = true
          when 'W' then opts.warn_used_underscore = true
          when 'q' then opts.quiet = true
          when 'e' then opts.edit = true
          when 'h' then opts.hidden = true
          when 'f' then opts.fail = true
          else warn "error: unexpected argument '-#{c}' found"; exit 2 end
        end
      elsif a.start_with?('-')
        warn "error: unexpected argument '#{a}' found"
        exit 2
      else
        opts.paths << a
      end
    end
    i += 1
  end
  opts.paths = ['.'] if opts.paths.empty?
  opts
end

HELP = <<~TXT
Find dead code in .nix files

Usage: executable [OPTIONS] [FILE_PATHS]...

Arguments:
  [FILE_PATHS]...  .nix files, or directories with .nix files inside [default: .]

Options:
  -l, --no-lambda-arg                  Don't check lambda parameter arguments
  -L, --no-lambda-pattern-names        Don't check lambda attrset pattern names (don't break nixpkgs callPackage)
  -_, --no-underscore                  Don't check any bindings that start with a _
  -W, --warn-used-underscore           Warn if bindings are referenced that start with '_'
  -q, --quiet                          Don't print dead code report
  -e, --edit                           Remove unused code and write to source file
  -h, --hidden                         Recurse into hidden subdirectories and process hidden .*.nix files
      --help                           
  -f, --fail                           Exit with 1 if unused code has been found
  -o, --output-format <OUTPUT_FORMAT>  Output format to use [default: human-readable] [possible values: human-readable, json]
      --exclude <EXCLUDES>...          Files to exclude from analysis
  -V, --version                        Print version
TXT

def collect_files(opts)
  ex = opts.excludes.map { |p| File.expand_path(p) }
  files = []
  opts.paths.each do |p|
    unless File.exist?(p)
      warn "Error stating file #{p}: No such file or directory (os error 2)"
      next
    end
    if File.directory?(p)
      Find.find(p) do |f|
        base = File.basename(f)
        if File.directory?(f)
          if !opts.hidden && base.start_with?('.') && File.expand_path(f) != File.expand_path(p)
            Find.prune
          end
          next
        end
        next unless f.end_with?('.nix')
        next if !opts.hidden && base.start_with?('.')
        next if ex.include?(File.expand_path(f))
        files << f
      end
    else
      next unless p.end_with?('.nix')
      next if ex.include?(File.expand_path(p))
      files << p
    end
  end
  files.sort
end

def human(file, results)
  return if results.empty?
  puts 'Warning: Unused declarations were found.'
  first = results.first
  puts "    ╭─[#{file}:#{first[:line]}:#{first[:column]}]"
  byline = results.group_by { |r| r[:line] }
  byline.each do |ln, rs|
    text = File.readlines(file)[ln - 1].to_s.chomp
    puts format('%3d │%s', ln, text)
    rs.each do |r|
      spaces = ' ' * [r[:column] - 1, 0].max
      dashes = '─' * [[r[:endColumn] - r[:column] - 2, 0].max, 3].max
      puts "    │#{spaces}╰#{dashes} #{r[:message]}"
    end
  end
end

opts = parse_args(ARGV)
all = []
collect_files(opts).each do |file|
  begin
    analyzer = Analyzer.new(file, opts)
    res = analyzer.analyze
    analyzer.edit!(res) if opts.edit
    all << [file, res] unless res.empty?
  rescue => e
    warn "Error parsing file #{file}: #{e.message}"
  end
end

unless opts.quiet
  if opts.format == 'json'
    all.each { |file, res| puts(json_object({ file: file, results: res })) }
  else
    all.each { |file, res| human(file, res) }
  end
end
exit(opts.fail && all.any? ? 1 : 0)
