#!/usr/bin/env ruby
# frozen_string_literal: true

require 'shellwords'
require 'tmpdir'

VERSION = '0.9.28rc'
VERSION_LINE = "tcc version #{VERSION} 2026-04-21 build@237d0db* (x86_64 Linux)"

HELP = <<~TEXT
  Tiny C Compiler 0.9.28rc - Copyright (C) 2001-2006 Fabrice Bellard
  Usage: tcc [options...] [-o outfile] [-c] infile(s)...
         tcc [options...] -run infile (or --) [arguments...]
  General options:
    -c           compile only - generate an object file
    -o outfile   set output filename
    -run         run compiled source [with custom stdin: -rstdin FILE]
    -fflag       set or reset (with 'no-' prefix) 'flag' (see tcc -hh)
    -Wwarning    set or reset (with 'no-' prefix) 'warning' (see tcc -hh)
    -w           disable all warnings
    -v --version show version
    -vv          show search paths or loaded files
    -h -hh       show this, show more help
    -bench       show compilation statistics
    -            use stdin pipe as infile
    @listfile    read arguments from listfile
  Preprocessor options:
    -Idir        add include path 'dir'
    -Dsym[=val]  define 'sym' with value 'val'
    -Usym        undefine 'sym'
    -E           preprocess only
    -nostdinc    do not use standard system include paths
  Linker options:
    -Ldir        add library path 'dir'
    -llib        link with dynamic or static library 'lib'
    -nostdlib    do not link with standard crt and libraries
    -r           generate (relocatable) object file
    -rdynamic    export all global symbols to dynamic linker
    -shared      generate a shared library/dll
    -soname      set name for shared library to be used at runtime
    -Wl,-opt[=val]  set linker option (see tcc -hh)
  Debugger options:
    -g           generate stab runtime debug info
    -gdwarf[-x]  generate dwarf runtime debug info
    -b           compile with built-in memory and bounds checker (implies -g)
    -bt[N]       link with backtrace (stack dump) support [show max N callers]
  Misc. options:
    -std=version define __STDC_VERSION__ according to version (c11/gnu11)
    -x[c|a|b|n]  specify type of the next infile (C,ASM,BIN,NONE)
    -Bdir        set tcc's private include/library dir
    -M[M]D       generate make dependency file [ignore system files]
    -M[M]        as above but no other output
    -MF file     specify dependency file name
    -m32/64      defer to i386/x86_64 cross compiler
  Tools:
    create library  : tcc -ar [crstvx] lib [files]
  Discussion & bug reports:
    https://lists.nongnu.org/mailman/listinfo/tinycc-devel
TEXT

MORE_HELP = <<~TEXT
  Tiny C Compiler 0.9.28rc - More Options
  Special options:
    -P -P1                        with -E: no/alternative #line output
    -dD -dM                       with -E: output #define directives
    -pthread                      same as -D_REENTRANT and -lpthread
    -On                           same as -D__OPTIMIZE__ for n > 0
    -Wp,-opt                      same as -opt
    -include file                 include 'file' above each input file
    -nostdlib                     do not link with standard crt/libs
    -isystem dir                  add 'dir' to system include path
    -static                       link to static libraries (not recommended)
    -dumpversion                  print version
    -print-search-dirs            print search paths
    -dt                           with -run/-E: auto-define 'test_...' macros
  Ignored options:
    -arch -C --param -pedantic -pipe -s -traditional
  -W[no-]... warnings:
    all                           turn on some (*) warnings
    error[=warning]               stop after warning (any or specified)
    write-strings                 strings are const
    unsupported                   warn about ignored options, pragmas, etc.
    implicit-function-declaration warn for missing prototype (*)
    discarded-qualifiers          warn when const is dropped (*)
  -f[no-]... flags:
    unsigned-char                 default char is unsigned
    signed-char                   default char is signed
    common                        use common section instead of bss
    leading-underscore            decorate extern symbols
    ms-extensions                 allow anonymous struct in struct
    dollars-in-identifiers        allow '$' in C symbols
    reverse-funcargs              evaluate function arguments right to left
    gnu89-inline                  'extern inline' is like 'static inline'
    asynchronous-unwind-tables    create eh_frame section [on]
    test-coverage                 create code coverage code
  -m... target specific options:
    ms-bitfields                  use MSVC bitfield layout
    no-sse                        disable floats on x86_64
  -Wl,... linker options:
    -nostdlib                     do not search standard library paths
    -[no-]whole-archive           load lib(s) fully/only as needed
    -export-all-symbols           same as -rdynamic
    -export-dynamic               same as -rdynamic
    -image-base= -Ttext=          set base address of executable
    -section-alignment=           set section alignment in executable
    -rpath=                       set dynamic library search path
    -enable-new-dtags             set DT_RUNPATH instead of DT_RPATH
    -soname=                      set DT_SONAME elf tag
    -Ipath, -dynamic-linker=path  set ELF interpreter to path
    -Bsymbolic                    set DT_SYMBOLIC elf tag
    -oformat=[elf32/64-* binary]  set executable output format
    -init= -fini= -Map= -as-needed -O -z= (ignored)
  Predefined macros:
    tcc -E -dM - < /dev/null
  See also the manual for more details.
TEXT

SEARCH_DIRS = <<~TEXT
  install: /usr/local/lib/tcc
  include:
    /usr/local/lib/tcc/include
    /usr/local/include/x86_64-linux-gnu
    /usr/local/include
    /usr/include/x86_64-linux-gnu
    /usr/include
  libraries:
    /usr/local/lib/tcc
    /usr/lib/x86_64-linux-gnu
    /usr/lib
    /lib/x86_64-linux-gnu
    /lib
    /usr/local/lib/x86_64-linux-gnu
    /usr/local/lib
  libtcc1:
    /usr/local/lib/tcc/libtcc1.a
  crt:
    /usr/lib/x86_64-linux-gnu
  elfinterp:
    /lib64/ld-linux-x86-64.so.2
TEXT

def expand_response_files(argv)
  out = []
  argv.each do |arg|
    if arg.start_with?('@') && arg.length > 1
      begin
        out.concat(Shellwords.split(File.read(arg[1..])))
      rescue Errno::ENOENT
        warn "tcc: error: file '#{arg[1..]}' not found"
        exit 1
      end
    else
      out << arg
    end
  end
  out
end

def run_cmd(cmd)
  system(*cmd)
  $?.exitstatus || 1
end

def source_from_stdin(tmpdir)
  path = File.join(tmpdir, 'stdin.c')
  File.binwrite(path, STDIN.read)
  path
end

def translate_options(argv, tmpdir)
  gcc = ['gcc', '-std=gnu99', '-D__TINYC__=928', '-D__TCC_PP__=1']
  gcc.concat(['-isystem', '/usr/local/lib/tcc/include']) unless argv.include?('-nostdinc')
  inputs = []
  output = nil
  compile_only = false
  preprocess = false
  dependency_only = false
  verbose = false
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when '-o'
      i += 1
      output = argv[i]
    when /^-o(.+)/
      output = Regexp.last_match(1)
    when '-c'
      compile_only = true
      gcc << a
    when '-v', '--version'
      verbose = true
    when '-vv'
      verbose = true
    when '-E'
      preprocess = true
      gcc << a
    when '-M', '-MM'
      dependency_only = true
      gcc << a
    when '-MD', '-MMD'
      gcc << a
    when '-MF', '-MT', '-MQ', '-include', '-isystem', '-x', '-Xlinker', '-u'
      gcc << a
      i += 1
      gcc << argv[i] if i < argv.length
    when '-soname'
      i += 1
      gcc << "-Wl,-soname,#{argv[i]}" if i < argv.length
    when '-r'
      gcc << '-r'
    when '-rdynamic'
      gcc << '-rdynamic'
    when '-nostdinc', '-nostdlib', '-shared', '-static', '-pthread', '-g', '-w', '-P', '-dD', '-dM'
      gcc << a
    when '-P1'
      # GCC has no TCC-style alternate line marker mode; use normal preprocessing.
    when '-bench', '-dt'
      # TCC diagnostics/test macro helpers. They are harmless for compatibility.
    when '-b'
      gcc << '-g'
    when /^-bt/
      gcc << '-g'
    when /^-gdwarf/
      gcc << '-g'
    when /^-I.+/, /^-D.+/, /^-U.+/, /^-L.+/, /^-l.+/, /^-Wl,/, /^-Wp,/, /^-W.+/, /^-f.+/, /^-m(32|64|s-bitfields)$/, /^-O\d*$/, /^-std=/
      gcc << a
    when /^-B.+/
      # TCC private directory; GCC -B would change tool lookup, so ignore it.
    when '-B'
      i += 1
    when '-arch', '-C', '--param', '-pedantic', '-pipe', '-s', '-traditional'
      i += 1 if a == '--param' && i + 1 < argv.length
    when '-'
      inputs << source_from_stdin(tmpdir)
    else
      if a.start_with?('-')
        gcc << a
      else
        inputs << a
      end
    end
    i += 1
  end

  if compile_only && output.nil? && inputs.length == 1
    base = File.basename(inputs[0]).sub(/\.[^.]*\z/, '')
    output = "#{base}.o"
  end

  gcc.concat(inputs)
  gcc.concat(['-o', output]) if output && !dependency_only
  [gcc, verbose, preprocess, dependency_only, inputs, output]
end

def print_verbose(inputs, output)
  puts VERSION_LINE
  inputs.each { |input| puts "-> #{input}" }
  puts "<- #{output}" if output
end

def run_source(argv)
  run_index = argv.index('-run')
  before = argv[0...run_index]
  rest = argv[(run_index + 1)..] || []
  stdin_file = nil
  if (idx = before.index('-rstdin'))
    stdin_file = before[idx + 1]
    before = before[0...idx] + before[(idx + 2)..]
  end
  if (idx = rest.index('-rstdin'))
    stdin_file = rest[idx + 1]
    rest = rest[0...idx] + rest[(idx + 2)..]
  end
  if rest.empty?
    warn 'tcc: error: argument to -run is missing'
    exit 1
  end
  src = rest.shift
  rest.shift if rest.first == '--'
  Dir.mktmpdir('ruby-tcc-run') do |dir|
    src = source_from_stdin(dir) if src == '-'
    exe = File.join(dir, 'a.out')
    gcc, verbose, = translate_options(before + ['-o', exe, src], dir)
    print_verbose([src], exe) if verbose
    status = run_cmd(gcc)
    exit status unless status.zero?
    if stdin_file
      File.open(stdin_file, 'rb') { |f| pid = Process.spawn(exe, *rest, in: f); Process.wait(pid) }
    else
      pid = Process.spawn(exe, *rest)
      Process.wait(pid)
    end
    exit($?.exitstatus || 1)
  end
end

argv = expand_response_files(ARGV)

if argv.empty? || argv.include?('-h') || argv.include?('--help')
  print HELP
  exit 0
end

if argv.include?('-hh')
  print MORE_HELP
  exit 0
end

if argv == ['-v'] || argv == ['--version']
  puts VERSION_LINE
  exit 0
end

if argv == ['-vv']
  puts VERSION_LINE
  print SEARCH_DIRS
  exit 0
end

if argv == ['-dumpversion']
  puts VERSION
  exit 0
end

if argv == ['-print-search-dirs']
  print SEARCH_DIRS
  exit 0
end

if argv.first == '-ar'
  exit run_cmd(['ar', *argv[1..]])
end

if argv.include?('-run')
  run_source(argv)
end

if argv.length == 1 && argv.first.start_with?('-') && !%w[- -E -c].include?(argv.first)
  warn "tcc: error: invalid option -- '#{argv.first}'"
  exit 1
end

Dir.mktmpdir('ruby-tcc') do |dir|
  gcc, verbose, _preprocess, _deps, inputs, output = translate_options(argv, dir)
  print_verbose(inputs, output) if verbose
  exit run_cmd(gcc)
end
