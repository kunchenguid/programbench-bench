#!/usr/bin/env ruby
# frozen_string_literal: true

require 'zlib'
require 'fileutils'
require 'stringio'

VERSION_LINE = "*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***\n"
SHORT_HELP = <<~TXT
  Compress or decompress the INPUT file(s); reads from STDIN if INPUT is `-` or not provided.

  Usage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]

  Options:
    -o OUTPUT                     Write output to a single file, OUTPUT.
    -k, --keep                    Preserve INPUT file(s). [Default]
    --rm                          Remove INPUT file(s) after successful (de)compression to file.

    -#                            Desired compression level, where `#` is a number between 1 and 19;
                                  lower numbers provide faster compression, higher numbers yield
                                  better compression ratios. [Default: 3]

    -d, --decompress              Perform decompression.
    -D DICT                       Use DICT as the dictionary for compression or decompression.

    -f, --force                   Disable input and output checks. Allows overwriting existing files,
                                  receiving input from the console, printing output to STDOUT, and
                                  operating on links, block devices, etc. Unrecognized formats will be
                                  passed-through through as-is.

    -h                            Display short usage and exit.
    -H, --help                    Display full help and exit.
    -V, --version                 Display the program version and exit.

TXT
FULL_HELP = VERSION_LINE + "\n" + SHORT_HELP + <<~TXT
  Advanced options:
    -c, --stdout                  Write to STDOUT (even if it is a console) and keep the INPUT file(s).

    -v, --verbose                 Enable verbose output; pass multiple times to increase verbosity.
    -q, --quiet                   Suppress warnings; pass twice to suppress errors.
    --trace LOG                   Log tracing information to LOG.

    --[no-]progress               Forcibly show/hide the progress counter. NOTE: Any (de)compressed
                                  output to terminal will mix with progress counter text.

    -r                            Operate recursively on directories.
    --filelist LIST               Read a list of files to operate on from LIST.
    --output-dir-flat DIR         Store processed files in DIR.
    --output-dir-mirror DIR       Store processed files in DIR, respecting original directory structure.
    --[no-]asyncio                Use asynchronous IO. [Default: Enabled]

    --[no-]check                  Add XXH64 integrity checksums during compression. [Default: Add, Validate]
                                  If `-d` is present, ignore/validate checksums during decompression.

    --                            Treat remaining arguments after `--` as files.

  Advanced compression options:
    --ultra                       Enable levels beyond 19, up to 22; requires more memory.
    --fast[=#]                    Use to very fast compression levels. [Default: 1]
    --adapt                       Dynamically adapt compression level to I/O conditions.
    --long[=#]                    Enable long distance matching with window log #. [Default: 27]
    --format=zstd                 Compress files to the `.zst` format. [Default]
    --format=gzip                 Compress files to the `.gz` format.

  Advanced decompression options:
    -l                            Print information about Zstandard-compressed files.
    --test                        Test compressed file integrity.
    -M#                           Set the memory usage limit to # megabytes.
    --[no-]sparse                 Enable sparse mode. [Default: Enabled for files, disabled for STDOUT.]
    --[no-]pass-through           Pass through uncompressed files as-is. [Default: Disabled]
TXT

class ZstdLite
  MAGIC = [0x28, 0xB5, 0x2F, 0xFD].pack('C*')
  SKIP_MIN = 0x184D2A50
  SKIP_MAX = 0x184D2A5F
  MAX_BLOCK = 128 * 1024

  def self.compress(data)
    out = MAGIC.dup
    out << [0xE0].pack('C')       # single segment, 8-byte frame content size, no checksum
    out << [data.bytesize].pack('Q<')
    pos = 0
    if data.empty?
      out << [1].pack('V')[0, 3]
    else
      while pos < data.bytesize
        chunk = data.byteslice(pos, MAX_BLOCK)
        pos += chunk.bytesize
        last = pos >= data.bytesize ? 1 : 0
        header = (chunk.bytesize << 3) | last
        out << [header].pack('V')[0, 3]
        out << chunk
      end
    end
    out
  end

  def self.decompress(data)
    pos = 0
    result = ''.b
    while pos < data.bytesize
      need(data, pos, 4)
      magic = data.byteslice(pos, 4).unpack1('V')
      if magic >= SKIP_MIN && magic <= SKIP_MAX
        pos += 4
        need(data, pos, 4)
        len = data.byteslice(pos, 4).unpack1('V')
        pos += 4 + len
        next
      end
      raise 'unsupported format' unless data.byteslice(pos, 4) == MAGIC
      pos += 4
      need(data, pos, 1)
      desc = data.getbyte(pos)
      pos += 1
      fcs_flag = desc >> 6
      single = (desc & 0x20) != 0
      checksum = (desc & 0x04) != 0
      dict_flag = desc & 0x03
      unless single
        need(data, pos, 1)
        pos += 1 # window descriptor
      end
      dict_len = [0, 1, 2, 4][dict_flag]
      pos += dict_len
      fcs_len = if single && fcs_flag == 0
                  1
                else
                  [0, 2, 4, 8][fcs_flag]
                end
      pos += fcs_len
      loop do
        need(data, pos, 3)
        bh = data.byteslice(pos, 3).unpack('C*').then { |a| a[0] | (a[1] << 8) | (a[2] << 16) }
        pos += 3
        last = (bh & 1) == 1
        type = (bh >> 1) & 3
        size = bh >> 3
        case type
        when 0
          need(data, pos, size)
          result << data.byteslice(pos, size)
          pos += size
        when 1
          need(data, pos, 1)
          result << (data.getbyte(pos).chr.b * size)
          pos += 1
        when 2
          raise 'unsupported compressed block'
        else
          raise 'reserved block type'
        end
        break if last
      end
      pos += 4 if checksum
    end
    result
  end

  def self.info(data)
    pos = 0
    frames = 0
    decompressed = 0
    while pos < data.bytesize
      raise 'not compressed by zstd' unless data.byteslice(pos, 4) == MAGIC
      pos += 4
      desc = data.getbyte(pos); pos += 1
      fcs_flag = desc >> 6
      single = (desc & 0x20) != 0
      checksum = (desc & 0x04) != 0
      pos += 1 unless single
      pos += [0, 1, 2, 4][desc & 3]
      fcs_len = single && fcs_flag == 0 ? 1 : [0, 2, 4, 8][fcs_flag]
      if fcs_len > 0
        raw = data.byteslice(pos, fcs_len).unpack('C*') || []
        val = raw.each_with_index.sum { |b, i| b << (8 * i) }
        val += 256 if fcs_len == 2
        decompressed += val
      end
      pos += fcs_len
      loop do
        bh = data.byteslice(pos, 3).unpack('C*').then { |a| a[0] | (a[1] << 8) | (a[2] << 16) }
        pos += 3
        last = (bh & 1) == 1
        type = (bh >> 1) & 3
        size = bh >> 3
        pos += (type == 1 ? 1 : size)
        break if last
      end
      pos += 4 if checksum
      frames += 1
    end
    [frames, decompressed]
  end

  def self.need(data, pos, len)
    raise 'reached end of file with incomplete frame' if pos + len > data.bytesize
  end
end

class App
  def initialize(argv)
    @argv = argv.dup
    @decompress = false
    @stdout = false
    @force = false
    @rm = false
    @quiet = 0
    @output = nil
    @format = 'zstd'
    @test = false
    @list = false
    @recursive = false
    @files = []
  end

  def run
    parse!
    if @files.empty?
      @files << '-'
      @stdout = true unless @output
    end
    return list_files if @list
    ok = true
    @files.each { |f| ok &&= process_one(f) }
    ok ? 0 : 1
  rescue => e
    err("zstd: #{e.message}\n") if @quiet < 2
    1
  end

  def parse!
    until @argv.empty?
      a = @argv.shift
      case a
      when '--'
        @files.concat(@argv); @argv.clear
      when '-h'
        print SHORT_HELP; exit 0
      when '-H', '--help'
        print FULL_HELP; exit 0
      when '-V', '--version'
        print VERSION_LINE; exit 0
      when '-d', '--decompress', '--uncompress'
        @decompress = true
      when '-c', '--stdout'
        @stdout = true
      when '-f', '--force'
        @force = true
      when '-k', '--keep'
        @rm = false
      when '--rm'
        @rm = true
      when '-q', '--quiet'
        @quiet += 1
      when '-v', '--verbose'
        # accepted
      when '-t', '--test'
        @test = true; @decompress = true; @stdout = true
      when '-l'
        @list = true
      when '-r'
        @recursive = true
      when '-o'
        @output = @argv.shift or raise 'missing output file'
      when /^-o(.+)/
        @output = Regexp.last_match(1)
      when '-D'
        @argv.shift or raise 'missing dictionary'
      when /^-D.+/
        # accepted, dictionaries are ignored for uncompressed frames
      when /^-[0-9]+$/, '--ultra', '--adapt', '--rsyncable', '--single-thread', '--exclude-compressed'
        # accepted compatibility no-ops
      when /^-T\d+$/, /^-b\d*$/, /^-e\d+$/, /^-i\d+$/, /^-M\d+$/, '-S'
        # accepted compatibility no-ops
      when /^--fast(=.*)?$/, /^--long(=.*)?$/, /^--format=(.+)$/
        @format = Regexp.last_match(1) if a.start_with?('--format=')
      when /^--(?:no-)?(?:progress|asyncio|check|sparse|pass-through|mmap-dict|compress-literals|row-match-finder)$/
        # accepted no-op
      when /^--(?:trace|filelist|output-dir-flat|output-dir-mirror|stream-size|size-hint|target-compressed-block-size|jobsize|split|maxdict|dictID|patch-from)(=.*)?$/
        @argv.shift if !a.include?('=') && !@argv.empty?
      when '--train', /^--train-/, '--patch-apply', /^--auto-threads=/, '--priority=rt', '--no-dictID'
        # accepted no-op
      when '-'
        @files << a
      when /^-/
        raise "Incorrect parameter: #{a}"
      else
        @files << a
      end
    end
  end

  def process_one(path)
    if path != '-' && File.directory?(path)
      return process_dir(path) if @recursive
      err("zstd: #{path} is a directory -- ignored\n")
      return false
    end
    input = path == '-' ? STDIN.binmode.read : File.binread(path)
    output = transform(input)
    return true if @test
    if @stdout || @output == '-'
      STDOUT.binmode.write(output)
      return true
    end
    out_path = @output || default_output(path)
    if File.exist?(out_path) && !@force
      err("zstd: #{out_path} already exists; not overwritten\n")
      return false
    end
    FileUtils.mkdir_p(File.dirname(out_path)) if File.dirname(out_path) != '.'
    File.binwrite(out_path, output)
    File.delete(path) if @rm && path != '-'
    true
  rescue => e
    err("zstd: #{path}: #{e.message}\n") if @quiet < 2
    false
  end

  def process_dir(dir)
    ok = true
    Dir.glob(File.join(dir, '**', '*'), File::FNM_DOTMATCH).sort.each do |p|
      next if File.directory?(p)
      ok &&= process_one(p)
    end
    ok
  end

  def transform(input)
    if @decompress
      if input.start_with?([0x1F, 0x8B].pack('C*'))
        Zlib::GzipReader.new(StringIO.new(input)).read
      else
        ZstdLite.decompress(input)
      end
    else
      case @format
      when 'gzip', 'gz'
        StringIO.open(''.b) { |s| gz = Zlib::GzipWriter.new(s); gz.write(input); gz.close; s.string }
      else
        ZstdLite.compress(input)
      end
    end
  end

  def default_output(path)
    return '-' if path == '-'
    if @decompress
      path.sub(/\.zst\z/, '').sub(/\.gz\z/, '')
    else
      path + (@format == 'gzip' ? '.gz' : '.zst')
    end
  end

  def list_files
    puts "Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename"
    ok = true
    @files.each do |f|
      begin
        data = File.binread(f)
        frames, usize = ZstdLite.info(data)
        csize = data.bytesize
        ratio = usize > 0 ? format('%.3f', csize.to_f / usize) : '0.000'
        puts format('%6d %6d %11d %13d %7s  %5s  %s', frames, 0, csize, usize, ratio, 'XXH64', f)
      rescue => e
        puts "File \"#{f}\" not compressed by zstd"
        err("Error: #{e.message}\n") if @quiet < 2
        ok = false
      end
    end
    ok ? 0 : 1
  end

  def err(s)
    STDERR.write(s)
  end
end

exit App.new(ARGV).run
