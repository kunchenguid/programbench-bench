#!/usr/bin/env ruby
# frozen_string_literal: true

require 'digest'
require 'etc'
require 'fileutils'
require 'find'
require 'rubygems/package'
require 'stringio'
require 'zlib'

VERSION = "7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12"

HELP = <<~TEXT

  #{VERSION}
   64-bit locale=C.UTF-8 Threads:#{Etc.nprocessors} OPEN_MAX:#{Process.getrlimit(:NOFILE)[0]}

  Usage: 7za <command> [<switches>...] <archive_name> [<file_names>...] [@listfile]

  <Commands>
    a : Add files to archive
    b : Benchmark
    d : Delete files from archive
    e : Extract files from archive (without using directory names)
    h : Calculate hash values for files
    i : Show information about supported formats
    l : List contents of archive
    rn : Rename files in archive
    t : Test integrity of archive
    u : Update files to archive
    x : eXtract files with full paths

  <Switches>
    -- : Stop switches and @listfile parsing
    -ao{a|s|t|u} : set Overwrite mode
    -bd : disable progress indicator
    -m{Parameters} : set compression Method
    -mx[N] : set compression level: -mx1 (fastest) ... -mx9 (ultra)
    -o{Directory} : set Output directory
    -p{Password} : set Password
    -r[-|0] : Recurse subdirectories for name search
    -scrc[CRC32|CRC64|SHA256|SHA1|XXH64|*] : set hash function for x, e, h commands
    -si[{name}] : read data from stdin
    -so : write data to stdout
    -slt : show technical information for l (List) command
    -t{Type} : Set type of archive
    -x[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : eXclude filenames
    -y : assume Yes on all queries
TEXT

INFO = <<~TEXT

  #{VERSION}
   64-bit locale=C.UTF-8 Threads:#{Etc.nprocessors} OPEN_MAX:#{Process.getrlimit(:NOFILE)[0]}


  Formats:
     C...F..........c.a.m+..  7z       7z            7 z BC AF ' 1C
     CK.....................  bzip2    bz2 bzip2 tbz2 (.tar) tbz (.tar) B Z h
     CK.................m+..  gzip     gz gzip tgz (.tar) tpz (.tar) apk (.tar) 1F 8B 08
     C......O...LH......m+..  tar      tar ova       offset=257 u s t a r
     CK.....................  xz       xz txz (.tar) FD 7 z X Z 00
     C...FMG........c.a.m+..  zip      zip z01 zipx jar xpi odt ods docx xlsx epub ipa apk appx P K 03 04
     CK.....O.....XC........  Hash     sha256 sha512 sha384 sha224 sha1 sha2 sha md5 xxh64 crc32 crc64 cksum asc

  Codecs:
      ED         0 Copy
      ED     40108 Deflate
      ED     40202 BZip2
      ED        21 LZMA2
      ED     30101 LZMA

  Hashers:
        4        1 CRC32
       20      201 SHA1
       32        A SHA256
        8      211 XXH64
        8        4 CRC64
TEXT

Entry = Struct.new(:name, :data, :mtime, :mode, :dir, :compressed_size, keyword_init: true)

def banner
  puts
  puts VERSION
  puts " 64-bit locale=C.UTF-8 Threads:#{Etc.nprocessors} OPEN_MAX:#{Process.getrlimit(:NOFILE)[0]}"
  puts
end

def human(bytes)
  return "#{bytes} bytes" if bytes < 1024
  kib = (bytes + 1023) / 1024
  "#{bytes} bytes (#{kib} KiB)"
end

def dos_time(t)
  sec = t.sec / 2
  [((t.year - 1980) << 25) | (t.month << 21) | (t.day << 16) | (t.hour << 11) | (t.min << 5) | sec].pack('V')
end

def crc32_hex(data)
  format('%08X', Zlib.crc32(data) & 0xffffffff)
end

CRC64_TABLE = 256.times.map do |i|
  crc = i
  8.times { crc = (crc & 1).zero? ? (crc >> 1) : ((crc >> 1) ^ 0xC96C5795D7870F42) }
  crc & 0xffffffffffffffff
end

def crc64(data)
  crc = 0xffffffffffffffff
  data.each_byte { |b| crc = CRC64_TABLE[(crc ^ b) & 0xff] ^ (crc >> 8) }
  (crc ^ 0xffffffffffffffff) & 0xffffffffffffffff
end

def crc64_hex(data)
  format('%016X', crc64(data))
end

def gather_files(paths, recurse)
  out = []
  paths = ['.'] if paths.empty?
  paths.each do |p|
    next unless File.exist?(p)
    if File.directory?(p)
      out << p.sub(%r{\A\./}, '')
      if recurse || true
        Find.find(p) { |f| out << f.sub(%r{\A\./}, '') unless f == p }
      end
    else
      out << p.sub(%r{\A\./}, '')
    end
  end
  out.uniq
end

def entries_from_paths(paths)
  gather_files(paths, true).map do |p|
    st = File.lstat(p)
    Entry.new(name: p, data: st.directory? ? '' : File.binread(p), mtime: st.mtime, mode: st.mode, dir: st.directory?, compressed_size: st.directory? ? 0 : st.size)
  end
end

def type_for(path, forced = nil)
  return forced.downcase if forced
  ext = File.basename(path).downcase
  return 'tar' if ext.end_with?('.tar')
  return 'gzip' if ext.end_with?('.gz', '.gzip', '.tgz')
  return 'bzip2' if ext.end_with?('.bz2', '.bzip2')
  return 'xz' if ext.end_with?('.xz')
  'zip'
end

def write_zip(path, entries)
  central = +''
  offset = 0
  File.open(path, 'wb') do |f|
    entries.each do |e|
      name = e.dir ? "#{e.name.sub(%r{/+\z}, '')}/" : e.name
      data = e.data || ''
      crc = Zlib.crc32(data) & 0xffffffff
      size = data.bytesize
      time = dos_time(e.mtime || Time.now)
      local = ["PK\x03\x04", 20, 0, 0, time, crc, size, size, name.bytesize, 0].pack('a4vvva4VVVvv') + name
      f.write(local)
      f.write(data)
      central << ["PK\x01\x02", 0x031e, 20, 0, 0, time, crc, size, size, name.bytesize, 0, 0, 0, 0, e.dir ? 0x10 : 0, offset].pack('a4vvvva4VVVvvvvvVV') + name
      offset += local.bytesize + data.bytesize
    end
    cd_offset = offset
    f.write(central)
    f.write(["PK\x05\x06", 0, 0, entries.size, entries.size, central.bytesize, cd_offset, 0].pack('a4vvvvVVv'))
  end
end

def read_zip(path)
  data = File.binread(path)
  pos = data.rindex("PK\x05\x06")
  raise "not a zip archive" unless pos
  _sig, _disk, _sdisk, _n1, n, _cd_size, cd_offset, _clen = data[pos, 22].unpack('a4vvvvVVv')
  entries = []
  p = cd_offset
  n.times do
    vals = data[p, 46].unpack('a4vvvva4VVVvvvvvVV')
    sig = vals[0]
    break unless sig == "PK\x01\x02"
    method = vals[4]
    crc = vals[6]
    csize = vals[7]
    usize = vals[8]
    nlen = vals[9]
    xlen = vals[10]
    clen = vals[11]
    attrs = vals[14]
    off = vals[15]
    name = data[p + 46, nlen]
    lp = off
    lname_len = data[lp + 26, 2].unpack1('v')
    lextra_len = data[lp + 28, 2].unpack1('v')
    start = lp + 30 + lname_len + lextra_len
    comp = data[start, csize]
    body = case method
           when 0 then comp
           when 8 then Zlib::Inflate.new(-Zlib::MAX_WBITS).inflate(comp)
           else ''
           end
    is_dir = name.end_with?('/') || (attrs & 0x10 != 0)
    entries << Entry.new(name: name.sub(%r{/+\z}, ''), data: body, mtime: Time.now, mode: is_dir ? 040755 : 0100644, dir: is_dir, compressed_size: csize)
    p += 46 + nlen + xlen + clen
  end
  entries
end

def write_tar(path, entries)
  File.open(path, 'wb') do |io|
    Gem::Package::TarWriter.new(io) do |tar|
      entries.each do |e|
        if e.dir
          tar.mkdir(e.name.sub(%r{/+\z}, ''), 0755)
        else
          tar.add_file_simple(e.name, 0644, e.data.bytesize) { |out| out.write(e.data) }
        end
      end
    end
  end
end

def read_tar(path)
  entries = []
  File.open(path, 'rb') do |io|
    Gem::Package::TarReader.new(io) do |tar|
      tar.each do |te|
        body = te.directory? ? '' : te.read
        entries << Entry.new(name: te.full_name.sub(%r{/+\z}, ''), data: body, mtime: Time.at(te.header.mtime), mode: te.header.mode, dir: te.directory?, compressed_size: ((body.bytesize + 511) / 512) * 512)
      end
    end
  end
  entries
end

def write_gzip(path, entries)
  e = entries.find { |x| !x.dir } || Entry.new(name: 'stdin', data: '', mtime: Time.now, dir: false)
  Zlib::GzipWriter.open(path) do |gz|
    gz.orig_name = File.basename(e.name)
    gz.mtime = e.mtime || Time.now
    gz.write(e.data)
  end
end

def read_gzip(path)
  data = nil
  name = File.basename(path).sub(/\.t?gz(ip)?\z/i, '')
  Zlib::GzipReader.open(path) { |gz| data = gz.read; name = gz.orig_name unless gz.orig_name.nil? || gz.orig_name.empty? }
  [Entry.new(name: name, data: data, mtime: File.mtime(path), mode: 0100644, dir: false, compressed_size: File.size(path))]
end

def read_archive(path)
  sig = File.binread(path, 8) rescue ''
  return ['zip', read_zip(path)] if sig.start_with?("PK\x03\x04", "PK\x05\x06")
  return ['gzip', read_gzip(path)] if sig.start_with?("\x1F\x8B".b)
  return ['tar', read_tar(path)] if sig.bytesize >= 1
  ['zip', []]
end

def archive_details(path, type, entries)
  puts "--"
  puts "Path = #{path}"
  puts "Type = #{type == 'gzip' ? 'gzip' : type}"
  puts "Physical Size = #{File.size(path)}"
  puts "Headers Size = 2048" if type == 'tar'
  puts "Code Page = UTF-8" if type == 'tar'
  puts "Characteristics = GNU ASCII" if type == 'tar'
  entries
end

def command_add(archive, files, opts)
  entries = opts[:stdin] ? [Entry.new(name: opts[:stdin_name] || 'stdin', data: STDIN.binmode.read, mtime: Time.now, mode: 0100644, dir: false)] : entries_from_paths(files)
  total = entries.reject(&:dir).sum { |e| e.data.bytesize }
  folders = entries.count(&:dir)
  type = type_for(archive, opts[:type])
  banner
  puts "Scanning the drive:"
  puts "#{folders > 0 ? "#{folders} folder#{'s' unless folders == 1}, " : ''}#{entries.count { |e| !e.dir }} file#{'s' unless entries.count { |e| !e.dir } == 1}, #{human(total)}"
  puts
  puts "Creating archive: #{archive}"
  puts
  puts "Add new data to archive: #{entries.count { |e| !e.dir }} file#{'s' unless entries.count { |e| !e.dir } == 1}, #{human(total)}"
  puts
  case type
  when 'tar' then write_tar(archive, entries)
  when 'gzip', 'gz' then write_gzip(archive, entries)
  else write_zip(archive, entries)
  end
  puts
  puts "Files read from disk: #{entries.size}"
  puts "Archive size: #{human(File.size(archive))}"
  puts "Everything is Ok"
end

def command_list(archive, opts)
  type, entries = read_archive(archive)
  total = entries.reject(&:dir).sum { |e| e.data.bytesize }
  banner
  puts "Scanning the drive for archives:"
  puts "1 file, #{human(File.size(archive))}"
  puts
  puts "Listing archive: #{archive}"
  puts
  archive_details(archive, type, entries)
  if opts[:slt]
    puts
    entries.each do |e|
      puts "----------"
      puts "Path = #{e.name}"
      puts "Folder = #{e.dir ? '+' : '-'}"
      puts "Size = #{e.dir ? 0 : e.data.bytesize}"
      puts "Packed Size = #{e.compressed_size || e.data.bytesize}"
      puts "Modified = #{(e.mtime || Time.now).strftime('%Y-%m-%d %H:%M:%S')}"
      puts "Mode = #{e.dir ? 'drwxr-xr-x' : '-rw-r--r--'}"
      puts
    end
  else
    puts
    puts "   Date      Time    Attr         Size   Compressed  Name"
    puts "------------------- ----- ------------ ------------  ------------------------"
    entries.each do |e|
      t = (e.mtime || Time.now).strftime('%Y-%m-%d %H:%M:%S')
      attr = e.dir ? 'D....' : '.....'
      puts format('%s %5s %12d %12d  %s', t, attr, e.dir ? 0 : e.data.bytesize, e.compressed_size || e.data.bytesize, e.name)
    end
    puts "------------------- ----- ------------ ------------  ------------------------"
    puts format('%s %18d %12d  %d files', Time.now.strftime('%Y-%m-%d %H:%M:%S'), total, entries.reject(&:dir).sum { |e| e.compressed_size || e.data.bytesize }, entries.count { |e| !e.dir })
  end
end

def command_extract(archive, opts, flat)
  type, entries = read_archive(archive)
  outdir = opts[:outdir] || '.'
  total = entries.reject(&:dir).sum { |e| e.data.bytesize }
  if opts[:stdout]
    entries.reject(&:dir).each { |e| STDOUT.binmode.write(e.data) }
    return
  end
  banner
  puts "Scanning the drive for archives:"
  puts "1 file, #{human(File.size(archive))}"
  puts
  puts "Extracting archive: #{archive}"
  archive_details(archive, type, entries)
  entries.each do |e|
    dest_name = flat ? File.basename(e.name) : e.name
    dest = File.join(outdir, dest_name)
    if e.dir
      FileUtils.mkdir_p(dest)
    else
      FileUtils.mkdir_p(File.dirname(dest))
      File.binwrite(dest, e.data)
      File.utime(Time.now, e.mtime || Time.now, dest) rescue nil
    end
  end
  puts
  puts "Everything is Ok"
  puts
  puts "Folders: #{entries.count(&:dir)}" if entries.any?(&:dir)
  puts "Files: #{entries.count { |e| !e.dir }}"
  puts "Size:       #{total}"
  puts "Compressed: #{File.size(archive)}"
end

def rewrite_archive(path, type, entries)
  case type
  when 'tar' then write_tar(path, entries)
  when 'gzip' then write_gzip(path, entries)
  else write_zip(path, entries)
  end
end

def command_delete(archive, names)
  type, entries = read_archive(archive)
  before = entries.size
  entries = entries.reject { |e| names.include?(e.name) || names.include?(File.basename(e.name)) }
  rewrite_archive(archive, type, entries)
  banner
  puts "Updating archive: #{archive}"
  puts
  puts "Items to delete: #{before - entries.size}"
  puts
  puts "Files read from disk: 0"
  puts "Archive size: #{human(File.size(archive))}"
  puts "Everything is Ok"
end

def command_rename(archive, pairs)
  type, entries = read_archive(archive)
  pairs.each_slice(2) do |old_name, new_name|
    next unless old_name && new_name
    entries.each { |e| e.name = new_name if e.name == old_name }
  end
  rewrite_archive(archive, type, entries)
  banner
  puts "Updating archive: #{archive}"
  puts
  puts "Everything is Ok"
end

def command_hash(files, opts)
  files = gather_files(files, true).reject { |p| File.directory?(p) }
  algo = (opts[:crc] || 'CRC32').upcase
  widths = { 'CRC32' => 8, 'CRC64' => 16, 'SHA1' => 40, 'SHA256' => 64, 'MD5' => 32 }
  width = widths[algo] || 8
  rows = files.map do |f|
    data = File.binread(f)
    h = case algo
        when 'SHA256' then Digest::SHA256.hexdigest(data)
        when 'SHA1' then Digest::SHA1.hexdigest(data)
        when 'MD5' then Digest::MD5.hexdigest(data)
        when 'CRC64' then crc64_hex(data)
        else crc32_hex(data)
        end
    [h, data.bytesize, f]
  end
  banner
  puts "Scanning"
  puts "#{rows.size} file#{'s' unless rows.size == 1}, #{human(rows.sum { |r| r[1] })}"
  puts
  puts "#{algo.ljust(width)}  #{"Size".rjust(13)}  Name"
  puts "#{'-' * width} -------------  ------------"
  rows.each { |h, s, f| puts "#{h.ljust(width)} #{s.to_s.rjust(13)}  #{f}" }
  puts "#{'-' * width} -------------  ------------"
  combined = rows.map(&:first).join
  summary = rows.size == 1 ? rows[0][0] : (algo == 'CRC32' ? crc32_hex(combined) + '-00000001' : rows[0][0])
  puts "#{summary.ljust(width)} #{rows.sum { |r| r[1] }.to_s.rjust(13)}  "
  puts
  puts "Files: #{rows.size}" if rows.size > 1
  puts "Size: #{rows.sum { |r| r[1] }}"
  puts
  puts "#{algo.ljust(6)}for data:              #{summary}"
  puts
  puts "Everything is Ok"
end

def parse(argv)
  opts = {}
  args = []
  stop = false
  argv.each do |a|
    if !stop && a == '--'
      stop = true
    elsif !stop && a.start_with?('-')
      case a
      when /\A-o(.+)/
        opts[:outdir] = Regexp.last_match(1)
      when /\A-t(.+)/
        opts[:type] = Regexp.last_match(1)
      when /\A-scrc(.+)?\z/i
        opts[:crc] = Regexp.last_match(1) || 'CRC32'
      when /\A-si(.*)\z/
        opts[:stdin] = true
        opts[:stdin_name] = Regexp.last_match(1)
      when '-so'
        opts[:stdout] = true
      when '-slt'
        opts[:slt] = true
      end
    elsif !stop && a.start_with?('@') && File.file?(a[1..])
      args.concat(File.readlines(a[1..], chomp: true))
    else
      args << a
    end
  end
  [opts, args]
end

begin
  if ARGV.empty? || ARGV.include?('--help') || ARGV.include?('-h') || ARGV.include?('/?')
    print HELP
    exit 0
  end
  command = ARGV.shift
  opts, args = parse(ARGV)
  case command
  when 'i'
    print INFO
  when 'a', 'u'
    raise "Command Line Error:\nCannot find archive name" if args.empty?
    command_add(args.shift, args, opts)
  when 'l'
    raise Errno::ENOENT, args[0].to_s if args.empty? || !File.exist?(args[0])
    command_list(args[0], opts)
  when 'x', 'e'
    raise Errno::ENOENT, args[0].to_s if args.empty? || !File.exist?(args[0])
    command_extract(args[0], opts, command == 'e')
  when 't'
    raise Errno::ENOENT, args[0].to_s if args.empty? || !File.exist?(args[0])
    type, entries = read_archive(args[0])
    banner
    puts "Scanning the drive for archives:"
    puts "1 file, #{human(File.size(args[0]))}"
    puts
    puts "Testing archive: #{args[0]}"
    archive_details(args[0], type, entries)
    puts
    puts "Everything is Ok"
  when 'd'
    raise Errno::ENOENT, args[0].to_s if args.empty? || !File.exist?(args[0])
    command_delete(args.shift, args)
  when 'rn'
    raise Errno::ENOENT, args[0].to_s if args.empty? || !File.exist?(args[0])
    command_rename(args.shift, args)
  when 'h'
    command_hash(args, opts)
  when 'b'
    banner
    puts "RAM size:    128000 MB,  # CPU hardware threads:  #{Etc.nprocessors}"
    puts "Benchmark stub"
    puts "Everything is Ok"
  else
    warn
    warn "Command Line Error:"
    warn "Unsupported command:"
    warn command
    warn
    warn VERSION
    warn
    exit 7
  end
rescue Errno::ENOENT => e
  banner
  puts "Scanning the drive for archives:"
  puts
  puts "ERROR: errno=2 : No such file or directory"
  puts e.message.split(' - ').last
  puts
  puts
  puts "System ERROR:"
  puts "errno=2 : No such file or directory"
  exit 2
rescue StandardError => e
  warn
  warn e.message
  exit 2
end
