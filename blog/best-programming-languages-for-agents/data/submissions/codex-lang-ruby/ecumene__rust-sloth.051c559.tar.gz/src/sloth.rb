#!/usr/bin/env ruby

HELP = <<~TXT
  Sloth 0.1
  Mitchell Hynes. <mshynes@mun.ca>
  A toy for rendering 3D objects in the command line

  USAGE:
      executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

  FLAGS:
      -h, --help       Prints help information
      -b               Flags the rasterizer to render without color
      -V, --version    Prints version information

  OPTIONS:
      -x, --yaw <x>      Sets the object's static X rotation (in radians)
      -y, --pitch <y>    Sets the object's static Y rotation (in radians)
      -z, --roll <z>     Sets the object's static Z rotation (in radians)

  ARGS:
      <input filename(s)>...    Sets the input file to render

  SUBCOMMANDS:
      help     Prints this message or the help of the given subcommand(s)
      image    Generates a colorless terminal output as lines of text
TXT

IMAGE_HELP_WITH_INPUT = <<~TXT
  executable-image 
  Mitchell Hynes <mitchell.hynes@ecumene.xyz>
  Generates a colorless terminal output as lines of text

  USAGE:
      executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>

  FLAGS:
          --help       Prints help information
      -b               Flags the rasterizer to render without color
      -V, --version    Prints version information

  OPTIONS:
      -j, --webify <frame count>    Generates a portable JS based render of your object for the web
      -h <height>                   Sets the height of the image to generate
      -w <width>                    Sets the width of the image to generate
      -x, --yaw <x>                 Sets the object's static X rotation (in radians)
      -y, --pitch <y>               Sets the object's static Y rotation (in radians)
      -z, --roll <z>                Sets the object's static Z rotation (in radians)
TXT

IMAGE_HELP = IMAGE_HELP_WITH_INPUT.sub("executable <input filename(s)>... image", "executable image")

Vec = Struct.new(:x, :y, :z)
Face = Struct.new(:indices, :color)

def parse_float(s)
  Float(s)
rescue
  warn "Error: ParseFloatError { kind: Invalid }"
  exit 1
end

def parse_int(s)
  Integer(s)
rescue
  warn "Error: ParseIntError { kind: InvalidDigit }"
  exit 1
end

def load_mtl(path)
  colors = {}
  cur = nil
  return colors unless File.exist?(path)
  File.readlines(path, chomp: true).each do |line|
    parts = line.split
    next if parts.empty?
    cur = parts[1] if parts[0] == "newmtl"
    if parts[0] == "Kd" && cur
      colors[cur] = parts[1, 3].map { |v| (Float(v) * 255).round }
    end
  end
  colors
end

def load_obj(path)
  raise "filename: [#{path}] couldn't load, tobj couldnt load/parse OBJ. open file failed" unless File.exist?(path)
  dir = File.dirname(path)
  verts = []
  faces = []
  mtls = {}
  cur_color = [255, 255, 255]
  File.readlines(path, chomp: true).each do |line|
    parts = line.split
    next if parts.empty? || parts[0].start_with?("#")
    case parts[0]
    when "mtllib"
      mtl_path = File.join(dir, parts[1])
      if File.exist?(mtl_path)
        mtls.merge!(load_mtl(mtl_path))
      elsif path.end_with?(".obj")
        raise "Expected to have materials.: OpenFileFailed"
      end
    when "usemtl"
      cur_color = mtls[parts[1]] || cur_color
    when "v"
      verts << Vec.new(Float(parts[1]), Float(parts[2]), Float(parts[3]))
    when "f"
      ids = parts[1..].map { |p| p.split("/")[0].to_i - 1 }.select { |i| i >= 0 }
      faces << Face.new(ids, cur_color) if ids.length >= 3
    end
  end
  [verts, faces]
end

def load_stl(path)
  raise "filename: [#{path}] couldn't load, tobj couldnt load/parse OBJ. open file failed" unless File.exist?(path)
  verts = []
  faces = []
  cur = []
  File.readlines(path, chomp: true).each do |line|
    parts = line.split
    next unless parts[0] == "vertex"
    verts << Vec.new(Float(parts[1]), Float(parts[2]), Float(parts[3]))
    cur << verts.length - 1
    if cur.length == 3
      faces << Face.new(cur, [255, 255, 0])
      cur = []
    end
  end
  [verts, faces]
end

def rotate(v, rx, ry, rz)
  cx = Math.cos(rx); sx = Math.sin(rx)
  cy = Math.cos(ry); sy = Math.sin(ry)
  cz = Math.cos(rz); sz = Math.sin(rz)
  y = v.y * cx - v.z * sx
  z = v.y * sx + v.z * cx
  x = v.x
  x2 = x * cy + z * sy
  z2 = -x * sy + z * cy
  y2 = y
  Vec.new(x2 * cz - y2 * sz, x2 * sz + y2 * cz, z2)
end

def inside?(x, y, poly)
  inside = false
  j = poly.length - 1
  i = 0
  while i < poly.length
    xi, yi = poly[i]
    xj, yj = poly[j]
    if ((yi > y) != (yj > y)) && (x < (xj - xi) * (y - yi) / ((yj - yi).nonzero? || 1.0) + xi)
      inside = !inside
    end
    j = i
    i += 1
  end
  inside
end

def render(files, width, height, rx, ry, rz, color: true)
  verts = []
  faces = []
  files.each do |file|
    v, f = file.downcase.end_with?(".stl") ? load_stl(file) : load_obj(file)
    off = verts.length
    verts.concat(v)
    f.each { |face| faces << Face.new(face.indices.map { |i| i + off }, face.color) }
  end
  width = [width, 1].max
  height = [height, 1].max
  return ("\n" * height) if verts.empty? || faces.empty?

  rverts = verts.map { |v| rotate(v, rx, ry, rz) }
  minx, maxx = rverts.map(&:x).minmax
  miny, maxy = rverts.map(&:y).minmax
  cx = (minx + maxx) / 2.0
  cy = (miny + maxy) / 2.0
  sx = maxx - minx
  sy = maxy - miny
  scale = 0.82 * [width / (sx.nonzero? || 1.0), height / (sy.nonzero? || 1.0)].min
  pts = rverts.map { |v| [(v.x - cx) * scale + width / 2.0, height / 2.0 - (v.y - cy) * scale, v.z] }
  chars = Array.new(height) { Array.new(width, " ") }
  cols = Array.new(height) { Array.new(width, [0, 0, 0]) }
  zbuf = Array.new(height) { Array.new(width, -Float::INFINITY) }

  faces.each do |face|
    p3 = face.indices.map { |i| rverts[i] }.compact
    p2 = face.indices.map { |i| pts[i] }.compact
    next if p2.length < 3
    ux = p3[1].x - p3[0].x; uy = p3[1].y - p3[0].y; uz = p3[1].z - p3[0].z
    vx = p3[2].x - p3[0].x; vy = p3[2].y - p3[0].y; vz = p3[2].z - p3[0].z
    nz = ux * vy - uy * vx
    shade = [[nz.abs / 2.0, 0.25].max, 1.0].min
    ch = shade > 0.75 ? "@" : shade > 0.5 ? "#" : shade > 0.32 ? "*" : "."
    c = face.color.map { |v| [[(v * (0.45 + shade * 0.35)).round, 0].max, 255].min }
    min_px = [p2.map(&:first).min.floor, 0].max
    max_px = [p2.map(&:first).max.ceil, width - 1].min
    min_py = [p2.map { |p| p[1] }.min.floor, 0].max
    max_py = [p2.map { |p| p[1] }.max.ceil, height - 1].min
    z = p2.map { |p| p[2] }.sum / p2.length
    (min_py..max_py).each do |yy|
      (min_px..max_px).each do |xx|
        next unless inside?(xx + 0.5, yy + 0.5, p2.map { |p| [p[0], p[1]] })
        next if z < zbuf[yy][xx]
        zbuf[yy][xx] = z
        chars[yy][xx] = ch
        cols[yy][xx] = c
      end
    end
  end

  bg = [25, 25, 25]
  chars.each_with_index.map do |row, y|
    row.each_with_index.map do |ch, x|
      c = color ? cols[y][x] : [255, 255, 255]
      "\e[48;2;#{bg.join(";")}m\e[38;2;#{c.join(";")}m#{ch}\e[49m\e[39m"
    end.join
  end.join("\n") + "\n\e[49m\e[39m"
end

def html_frame(ansi)
  ansi.gsub(/\e\[48;2;[0-9;]*m/, "")
      .gsub(/\e\[49m/, "")
      .gsub(/\e\[39m/, "")
      .gsub(/\e\[38;2;([0-9]+);([0-9]+);([0-9]+)m/) { %(<span style="color:rgb(#{$1},#{$2},#{$3})">) }
end

def missing_width!(with_input)
  warn "error: The following required arguments were not provided:"
  warn "    -w <width>"
  warn
  warn "USAGE:"
  warn with_input ? "    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>" : "    executable image [FLAGS] [OPTIONS] -w <width>"
  warn
  warn "For more information try --help"
  exit 1
end

args = ARGV.dup
if args.empty?
  warn "error: The following required arguments were not provided:"
  warn "    <input filename(s)>..."
  warn
  warn "USAGE:"
  warn "    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]"
  warn
  warn "For more information try --help"
  exit 1
end

if args.include?("--help") || args.include?("-h") && !args.include?("image")
  puts HELP
  exit 0
end
if args.include?("--version") || args.include?("-V")
  puts "Sloth 0.1"
  exit 0
end
if args[0] == "help"
  puts(args[1] == "image" ? IMAGE_HELP : HELP)
  exit 0
end

image_idx = args.index("image")
inputs = image_idx ? args[0...image_idx] : args
rest = image_idx ? args[(image_idx + 1)..] : []
rx = ry = rz = 0.0
width = nil
height = 40
webify = nil
color = true

scan = lambda do |arr|
  out = []
  i = 0
  while i < arr.length
    a = arr[i]
    case a
    when "-b"
      color = false
    when "-x", "--yaw"
      i += 1; rx = parse_float(arr[i] || "")
    when "-y", "--pitch"
      i += 1; ry = parse_float(arr[i] || "")
    when "-z", "--roll"
      i += 1; rz = parse_float(arr[i] || "")
    when "-w"
      i += 1; width = parse_int(arr[i] || "")
    when /^-w(.+)/
      width = parse_int($1.sub(/^=/, ""))
    when "-h"
      i += 1; height = parse_int(arr[i] || "")
    when /^-h(.+)/
      height = parse_int($1.sub(/^=/, ""))
    when "-j", "--webify"
      i += 1; webify = parse_int(arr[i] || "")
    when /^-j(.+)/
      webify = parse_int($1.sub(/^=/, ""))
    when "--help"
      puts(inputs.empty? ? IMAGE_HELP : IMAGE_HELP_WITH_INPUT)
      exit 0
    else
      out << a
    end
    i += 1
  end
  out
end

inputs = scan.call(inputs)
rest = scan.call(rest)
inputs += rest.reject { |a| a.start_with?("-") }
inputs = inputs.flat_map { |s| s.include?(" ") ? s.split : [s] }

if image_idx
  missing_width!(!inputs.empty?) unless width
  begin
    if webify
      puts "let frames = ["
      webify.times do |n|
        frame = render(inputs, width, height, rx, ry + n * Math::PI * 2 / [webify, 1].max, rz, color: true)
        puts "`"
        print html_frame(frame)
        puts n == webify - 1 ? "`];" : "`,"
      end
    else
      print render(inputs, width, height, rx, ry, rz, color: color)
    end
  rescue => e
    warn
    warn "thread 'main' panicked at src/inputs.rs:126:39:"
    warn "called `Result::unwrap()` on an `Err` value: \"#{e.message}\""
    warn "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace"
    exit 101
  end
else
  warn 'Error: IoError(Os { code: 25, kind: Uncategorized, message: "Inappropriate ioctl for device" })'
  exit 1
end
