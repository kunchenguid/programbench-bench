#!/usr/bin/env ruby
# frozen_string_literal: true

require 'open3'

ROOT = File.expand_path(File.dirname(__FILE__))

HELP = <<~HELP
  ov is a feature rich pager(such as more/less).
  It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).

  Usage:
    ov [flags] [FILE]...

  Flags:
  Short   Long                                    Purpose
    -l, --align                                   align the output columns for better readability
    -C, --alternate-rows                          alternately change the line color
        --caption string                          custom caption
    -i, --case-sensitive                          case-sensitive in search
    -d, --column-delimiter character              column delimiter character (default ",")
    -c, --column-mode                             column mode
        --column-rainbow                          column mode to rainbow
        --column-width                            column mode for width
        --completion string                       generate completion script [bash|zsh|fish|powershell]
        --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)
        --converter string                        converter [es|raw|align] (default "es")
        --debug                                   debug mode
        --disable-column-cycle                    disable column cycling
        --disable-mouse                           disable mouse support
    -e, --exec                                    command execution result instead of file
    -X, --exit-write                              output the current screen when exiting
    -a, --exit-write-after int                    number after the current lines when exiting
    -b, --exit-write-before int                   number before the current lines when exiting
        --filter string                           filter search pattern
    -A, --follow-all                              follow multiple files and show the most recently updated one
    -f, --follow-mode                             monitor file and display new content as it is written
        --follow-name                             follow mode to monitor by file name
        --follow-section                          section-by-section follow mode
        --force-screen                            display screen even when redirecting output
    -H, --header int                              number of header lines to be displayed constantly
    -Y, --header-column int                       number of columns to display as a vertical header
    -h, --help                                    help for ov
        --help-key                                display key bind information
        --hide-other-section                      hide other section
        --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default "10%")
        --incsearch[=true|false]                  incremental search (default true)
    -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']
    -n, --line-number                             line number mode
        --list-view-modes                         list available view modes defined in the configuration file
        --memory-limit int                        number of chunks to limit in memory (default -1)
        --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)
    -M, --multi-color strings                     comma separated words(regexp) to color .e.g. "ERROR,WARNING"
        --non-match-filter string                 filter non match search pattern
        --notify-eof int                          notify at the end of the file
        --pattern string                          search pattern
    -p, --plain                                   disable original decoration
    -F, --quit-if-one-screen                      quit if the output fits on one screen
    -r, --raw                                     raw escape sequences without processing
        --regexp-search                           regular expression search
        --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)
        --section-delimiter regexp                regexp for section delimiter .e.g. "^#"
        --section-header                          enable section-delimiter line as Header
        --section-header-num int                  number of section header lines (default 1)
        --section-start int                       section start position
        --set-terminal-title                      set terminal title
        --skip-extract                            skip extracting compressed files
        --skip-lines int                          skip the number of lines
        --smart-case-sensitive                    smart case-sensitive in search
        --status-line[=true|false]                status line (default true)
    -x, --tab-width int                           tab stop width (default 8)
    -v, --version                                 display version information
    -y, --vertical-header int                     number of characters to display as a vertical header
    -m, --view-mode string                        apply predefined settings for a specific mode
    -T, --watch seconds                           watch mode interval(seconds)
    -w, --wrap[=true|false]                       wrap mode (default true)
HELP

VERSION = "ov version dev rev:HEAD\n"

BOOL_FLAGS = %w[
  -l --align -C --alternate-rows -i --case-sensitive -c --column-mode
  --column-rainbow --column-width --debug --disable-column-cycle
  --disable-mouse -e --exec -X --exit-write -A --follow-all -f --follow-mode
  --follow-name --follow-section --force-screen --help-key
  --hide-other-section -n --line-number -p --plain -F --quit-if-one-screen
  -r --raw --regexp-search --section-header --set-terminal-title
  --skip-extract --smart-case-sensitive -v --version -h --help
  --list-view-modes
].freeze

VALUE_FLAGS = {
  '-d' => '--column-delimiter',
  '--column-delimiter' => '--column-delimiter',
  '--caption' => '--caption',
  '--completion' => '--completion',
  '--config' => '--config',
  '--converter' => '--converter',
  '-a' => '--exit-write-after',
  '--exit-write-after' => '--exit-write-after',
  '-b' => '--exit-write-before',
  '--exit-write-before' => '--exit-write-before',
  '--filter' => '--filter',
  '-H' => '--header',
  '--header' => '--header',
  '-Y' => '--header-column',
  '--header-column' => '--header-column',
  '--hscroll-width' => '--hscroll-width',
  '-j' => '--jump-target',
  '--jump-target' => '--jump-target',
  '--memory-limit' => '--memory-limit',
  '--memory-limit-file' => '--memory-limit-file',
  '-M' => '--multi-color',
  '--multi-color' => '--multi-color',
  '--non-match-filter' => '--non-match-filter',
  '--notify-eof' => '--notify-eof',
  '--pattern' => '--pattern',
  '--ruler' => '--ruler',
  '--section-delimiter' => '--section-delimiter',
  '--section-header-num' => '--section-header-num',
  '--section-start' => '--section-start',
  '--skip-lines' => '--skip-lines',
  '-x' => '--tab-width',
  '--tab-width' => '--tab-width',
  '-y' => '--vertical-header',
  '--vertical-header' => '--vertical-header',
  '-m' => '--view-mode',
  '--view-mode' => '--view-mode',
  '-T' => '--watch',
  '--watch' => '--watch'
}.freeze

OPTIONAL_BOOL = %w[--incsearch --status-line -w --wrap].freeze
INT_FLAGS = {
  '--exit-write-after' => '-a, --exit-write-after',
  '--exit-write-before' => '-b, --exit-write-before',
  '--header' => '-H, --header',
  '--header-column' => '-Y, --header-column',
  '--memory-limit' => '--memory-limit',
  '--memory-limit-file' => '--memory-limit-file',
  '--notify-eof' => '--notify-eof',
  '--ruler' => '--ruler',
  '--section-header-num' => '--section-header-num',
  '--section-start' => '--section-start',
  '--skip-lines' => '--skip-lines',
  '--tab-width' => '-x, --tab-width',
  '--vertical-header' => '-y, --vertical-header'
}.freeze

def die(message)
  warn "Error: #{message}"
  exit 1
end

def asset(path)
  primary = File.join(ROOT, 'src', path)
  return primary if File.exist?(primary)

  File.join(ROOT, path)
end

def read_asset(path)
  File.read(asset(path))
rescue Errno::ENOENT
  nil
end

def valid_int?(value)
  /\A[-+]?\d+\z/.match?(value.to_s)
end

def parse_args(argv)
  opts = {}
  files = []
  i = 0
  while i < argv.length
    arg = argv[i]
    if arg == '--'
      files.concat(argv[(i + 1)..] || [])
      break
    elsif arg.start_with?('--') && arg.include?('=')
      name, value = arg.split('=', 2)
      if OPTIONAL_BOOL.include?(name)
        opts[name] = value
      elsif VALUE_FLAGS.key?(name)
        canonical = VALUE_FLAGS[name]
        opts[canonical] = value
        if INT_FLAGS.key?(canonical) && !valid_int?(value)
          die(%(invalid argument "#{value}" for "#{INT_FLAGS[canonical]}" flag: strconv.ParseInt: parsing "#{value}": invalid syntax))
        end
      else
        die("unknown flag: #{name}")
      end
    elsif OPTIONAL_BOOL.include?(arg)
      nxt = argv[i + 1]
      if nxt && !nxt.start_with?('-') && %w[true false].include?(nxt)
        opts[arg] = nxt
        i += 1
      else
        opts[arg] = 'true'
      end
    elsif VALUE_FLAGS.key?(arg)
      canonical = VALUE_FLAGS[arg]
      i += 1
      die("flag needs an argument: #{arg}") if i >= argv.length

      value = argv[i]
      opts[canonical] = value
      if INT_FLAGS.key?(canonical) && !valid_int?(value)
        die(%(invalid argument "#{value}" for "#{INT_FLAGS[canonical]}" flag: strconv.ParseInt: parsing "#{value}": invalid syntax))
      end
    elsif BOOL_FLAGS.include?(arg)
      opts[arg] = true
    elsif arg.start_with?('-') && arg != '-'
      short = arg[0, 2]
      if arg.length > 2 && VALUE_FLAGS.key?(short)
        canonical = VALUE_FLAGS[short]
        value = arg[2..]
        opts[canonical] = value
        if INT_FLAGS.key?(canonical) && !valid_int?(value)
          die(%(invalid argument "#{value}" for "#{INT_FLAGS[canonical]}" flag: strconv.ParseInt: parsing "#{value}": invalid syntax))
        end
      else
        die("unknown flag: #{arg}")
      end
    else
      files << arg
    end
    i += 1
  end
  [opts, files]
end

def completion(shell)
  valid = %w[bash zsh fish powershell]
  unless valid.include?(shell)
    die('requires one of the arguments bash/zsh/fish/powershell')
  end
  script = read_asset("completions/#{shell}.txt")
  if script
    print script
  else
    puts "# #{shell} completion for ov"
  end
end

def command_output(command)
  out, err, status = Open3.capture3(command)
  $stderr.write(err)
  print out
  exit(status.exitstatus || 1)
end

def display_file(path)
  File.open(path, 'rb') { |f| IO.copy_stream(f, STDOUT) }
rescue Errno::ENOENT
  die("open #{path}: no such file or directory")
rescue Errno::EACCES
  die("open #{path}: permission denied")
end

opts, files = parse_args(ARGV)

if opts['-h'] || opts['--help']
  print HELP
  exit 0
end

if opts['-v'] || opts['--version']
  print VERSION
  exit 0
end

if opts['--help-key']
  print(read_asset('help_key.txt') || "ov is a feature rich pager\n")
  exit 0
end

if opts['--list-view-modes']
  puts 'general'
  exit 0
end

completion(opts['--completion']) if opts.key?('--completion')

if opts.key?('--config')
  ext = File.extname(opts['--config'])
  if ext.empty?
    warn %(failed to read config file: Unsupported Config Type "#{ext.sub(/^\./, '')}")
  elsif !File.exist?(opts['--config'])
    warn "failed to read config file: open #{opts['--config']}: no such file or directory"
  end
end

if opts['-e'] || opts['--exec']
  if files.empty?
    data = STDIN.read
    print data
    exit 0
  end
  command_output(files.join(' '))
end

if files.empty?
  IO.copy_stream(STDIN, STDOUT)
else
  display_file(files.first)
end
