#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require 'json'
require 'yaml'
require 'strscan'
require 'date'

HELP = <<~TEXT
  Usage: ./executable [-][ytjcrneikhv]

  Convert between YAML, TOML, JSON, and HCL.
  Preserves map order.

  -x[x]  Convert using stdin. Valid options:
            -yj, -y = YAML to JSON (default)
            -yy     = YAML to YAML
            -yt     = YAML to TOML
            -yc     = YAML to HCL
            -tj, -t = TOML to JSON
            -ty     = TOML to YAML
            -tt     = TOML to TOML
            -tc     = TOML to HCL
            -jj     = JSON to JSON
            -jy, -r = JSON to YAML
            -jt     = JSON to TOML
            -jc     = JSON to HCL
            -cy     = HCL to YAML
            -ct     = HCL to TOML
            -cj, -c = HCL to JSON
            -cc     = HCL to HCL
  -n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)
  -e     Escape HTML (JSON out only)
  -i     Indent output (JSON or TOML out only)
  -k     Attempt to parse keys as objects or numeric types (YAML out only)
  -h     Show this help message
  -v     Show version
TEXT

VALID = %w[y t j c r n e i k h v].freeze

class ValueParser
  def initialize(text)
    @s = StringScanner.new(text.strip)
  end

  def parse
    skip
    value = parse_value
    skip
    value
  end

  private

  def skip
    @s.skip(/\s+/)
  end

  def parse_value
    skip
    return parse_string if @s.peek(1) == '"'
    return parse_array if @s.peek(1) == '['
    return parse_object if @s.peek(1) == '{'
    tok = @s.scan(/[^\s,\]\}]+/) || ''
    case tok
    when 'true' then true
    when 'false' then false
    when 'null' then nil
    when 'inf', '+inf', 'Inf', '+Inf' then Float::INFINITY
    when '-inf', '-Inf' then -Float::INFINITY
    when 'nan', 'NaN' then Float::NAN
    when /\A[-+]?\d+\z/ then tok.to_i
    when /\A[-+]?(?:\d+\.\d*|\d*\.\d+)(?:[eE][-+]?\d+)?\z/, /\A[-+]?\d+[eE][-+]?\d+\z/ then tok.to_f
    else tok
    end
  end

  def parse_string
    JSON.parse(@s.scan(/"(?:\\.|[^"\\])*"/))
  rescue JSON::ParserError
    ''
  end

  def parse_array
    arr = []
    @s.getch
    loop do
      skip
      break if @s.peek(1) == ']'
      arr << parse_value
      skip
      @s.getch if @s.peek(1) == ','
    end
    @s.getch
    arr
  end

  def parse_object
    h = {}
    @s.getch
    loop do
      skip
      break if @s.peek(1) == '}'
      key = @s.peek(1) == '"' ? parse_string : (@s.scan(/[A-Za-z0-9_.-]+/) || '')
      skip
      @s.getch if @s.peek(1) == '=' || @s.peek(1) == ':'
      h[key] = parse_value
      skip
      @s.getch if @s.peek(1) == ','
    end
    @s.getch
    h
  end
end

def strip_comment(line)
  in_s = false
  esc = false
  out = +''
  line.each_char do |ch|
    if esc
      out << ch
      esc = false
    elsif ch == '\\' && in_s
      out << ch
      esc = true
    elsif ch == '"'
      out << ch
      in_s = !in_s
    elsif ch == '#' && !in_s
      break
    else
      out << ch
    end
  end
  out.strip
end

def split_key_value(line)
  in_s = false
  esc = false
  line.chars.each_with_index do |ch, i|
    if esc
      esc = false
    elsif ch == '\\' && in_s
      esc = true
    elsif ch == '"'
      in_s = !in_s
    elsif ch == '=' && !in_s
      return [line[0...i].strip, line[(i + 1)..].strip]
    end
  end
  nil
end

def parse_toml(text)
  root = {}
  ctx = root
  text.each_line do |raw|
    line = strip_comment(raw)
    next if line.empty?
    if line =~ /\A\[\[([^\]]+)\]\]\z/
      keys = Regexp.last_match(1).split('.').map(&:strip)
      parent = keys[0...-1].reduce(root) { |h, k| h[k] ||= {} }
      ctx = {}
      (parent[keys[-1]] ||= []) << ctx
    elsif line =~ /\A\[([^\]]+)\]\z/
      keys = Regexp.last_match(1).split('.').map(&:strip)
      ctx = keys.reduce(root) { |h, k| h[k] ||= {} }
    elsif (kv = split_key_value(line))
      key, val = kv
      key = key.gsub(/\A"|"\z/, '')
      ctx[key] = ValueParser.new(val).parse
    end
  end
  root
end

def parse_hcl(text)
  root = {}
  stack = [root]
  text.each_line do |raw|
    line = strip_comment(raw)
    next if line.empty?
    while line.start_with?('}')
      stack.pop if stack.length > 1
      line = line[1..].strip
    end
    next if line.empty?
    if line =~ /\A"?([^"=\s\{]+)"?\s*\{\s*(.*?)\s*\}?\z/ && !line.include?('=')
      key = Regexp.last_match(1)
      h = {}
      (stack[-1][key] ||= []) << h
      stack << h unless line.end_with?('}')
    elsif line =~ /\A"?([^"=\s\{]+)"?\s*\{\s*(.+)\s*\}\z/
      key = Regexp.last_match(1)
      body = Regexp.last_match(2)
      h = {}
      if (kv = split_key_value(body))
        h[kv[0].gsub(/\A"|"\z/, '')] = ValueParser.new(kv[1]).parse
      end
      (stack[-1][key] ||= []) << h
    elsif line =~ /\A"?([^"=\s]+)"?\s*\{\s*\z/
      key = Regexp.last_match(1)
      h = {}
      (stack[-1][key] ||= []) << h
      stack << h
    elsif (kv = split_key_value(line))
      key, val = kv
      stack[-1][key.gsub(/\A"|"\z/, '')] = ValueParser.new(val).parse
    end
  end
  root
end

def json_out(obj, indent, escape)
  s = indent ? JSON.pretty_generate(obj) : JSON.generate(obj)
  s = s.gsub('&', '\\u0026').gsub('<', '\\u003c').gsub('>', '\\u003e') if escape
  s + "\n"
end

def stringify_nonfinite(obj)
  case obj
  when Hash
    obj.transform_values { |v| stringify_nonfinite(v) }
  when Array
    obj.map { |v| stringify_nonfinite(v) }
  when Float
    return 'NaN' if obj.nan?
    return 'inf' if obj.infinite? == 1
    return '-inf' if obj.infinite? == -1
    obj
  else
    obj
  end
end

def ambiguous_yaml_string?(s)
  return true if s.empty?
  return true if s =~ /\A[-+]?\d+(?:\.\d+)?\z/
  %w[y Y yes Yes YES n N no No NO true True TRUE false False FALSE on On ON off Off OFF null Null NULL ~].include?(s) ||
    s =~ /[:\[\]\{\},#&*!|>'"%@`]/
end

def yaml_scalar(v, key: false)
  case v
  when String
    ambiguous_yaml_string?(v) ? JSON.generate(v) : v
  when NilClass then 'null'
  else v.to_s
  end
end

def yaml_lines(obj, indent = 0)
  sp = ' ' * indent
  case obj
  when Hash
    obj.flat_map do |k, v|
      kk = yaml_scalar(k.to_s, key: true)
      if v.is_a?(Hash) || v.is_a?(Array)
        ["#{sp}#{kk}:"] + yaml_lines(v, indent + 2)
      else
        ["#{sp}#{kk}: #{yaml_scalar(v)}"]
      end
    end
  when Array
    obj.flat_map do |v|
      if v.is_a?(Hash)
        if v.empty?
          ["#{sp}- {}"]
        else
          first, *rest = v.to_a
          line = "#{sp}- #{yaml_scalar(first[0].to_s)}:"
          if first[1].is_a?(Hash) || first[1].is_a?(Array)
            [line] + yaml_lines(first[1], indent + 4) + yaml_lines(Hash[rest], indent + 2)
          else
            ["#{line} #{yaml_scalar(first[1])}"] + yaml_lines(Hash[rest], indent + 2)
          end
        end
      elsif v.is_a?(Array)
        ["#{sp}-"] + yaml_lines(v, indent + 2)
      else
        ["#{sp}- #{yaml_scalar(v)}"]
      end
    end
  else
    [yaml_scalar(obj)]
  end
end

def yaml_out(obj, key_parse)
  obj = parse_yaml_keys(obj) if key_parse
  yaml_lines(obj).join("\n") + "\n"
end

def parse_yaml_keys(obj)
  case obj
  when Hash
    obj.each_with_object({}) do |(k, v), h|
      nk = begin
        YAML.safe_load(k.to_s, permitted_classes: [Date, Time], aliases: true)
      rescue StandardError
        k
      end
      h[nk] = parse_yaml_keys(v)
    end
  when Array then obj.map { |v| parse_yaml_keys(v) }
  else obj
  end
end

def toml_scalar(v)
  case v
  when String then JSON.generate(v)
  when TrueClass, FalseClass then v.to_s
  when Numeric then v.to_s
  else JSON.generate(v.to_s)
  end
end

def toml_inline_array(a)
  '[' + a.map { |v| v.is_a?(Array) ? toml_inline_array(v) : toml_scalar(v) }.join(', ') + ']'
end

def emit_toml_hash(h, prefix = nil, indent = false)
  lines = []
  simple = h.reject { |_k, v| v.nil? || v.is_a?(Hash) || (v.is_a?(Array) && v.all? { |x| x.is_a?(Hash) }) }
  simple.each do |k, v|
    lines << "#{'  ' if indent && prefix}#{k} = #{v.is_a?(Array) ? toml_inline_array(v) : toml_scalar(v)}"
  end
  h.each do |k, v|
    next if v.nil? || simple.key?(k)
    if v.is_a?(Hash)
      lines << '' unless lines.empty?
      section = [prefix, k].compact.join('.')
      lines << "[#{section}]"
      lines.concat emit_toml_hash(v, section, indent)
    elsif v.is_a?(Array) && v.all? { |x| x.is_a?(Hash) }
      v.each do |elem|
        lines << '' unless lines.empty?
        section = [prefix, k].compact.join('.')
        lines << "[[#{section}]]"
        lines.concat emit_toml_hash(elem, section, indent)
      end
    end
  end
  lines
end

def toml_out(obj, indent)
  return "#{toml_scalar(obj)}\n" unless obj.is_a?(Hash)
  emit_toml_hash(obj, nil, indent).join("\n") + "\n"
end

def hcl_scalar(v)
  case v
  when String then JSON.generate(v)
  when TrueClass, FalseClass then v.to_s
  when Numeric then v.to_s
  when NilClass then ''
  else JSON.generate(v.to_s)
  end
end

def hcl_inline_array(a)
  vals = a.reject { |v| v == false || v.nil? }
  '[' + vals.map { |v| v.is_a?(Array) ? hcl_inline_array(v) : hcl_scalar(v) }.join(', ') + ']'
end

def emit_hcl(obj, indent = 0)
  return hcl_scalar(obj) unless obj.is_a?(Hash)
  sp = ' ' * indent
  parts = []
  obj.each do |k, v|
    key = JSON.generate(k.to_s)
    if v.is_a?(Hash)
      parts << "#{sp}#{key} = {\n#{emit_hcl(v, indent + 2)}\n#{sp}}"
    elsif v.is_a?(Array) && v.all? { |x| x.is_a?(Hash) }
      v.each { |e| parts << "#{sp}#{key} = {\n#{emit_hcl(e, indent + 2)}\n#{sp}}" }
    elsif v.is_a?(Array)
      parts << "#{sp}#{key} = #{hcl_inline_array(v)}"
    else
      parts << "#{sp}#{key} = #{hcl_scalar(v)}"
    end
  end
  parts.join("\n\n")
end

def hcl_out(obj)
  emit_hcl(obj) + "\n"
end

def parse_flags(argv)
  flags = argv.join.delete_prefix('-').chars
  flags = [] if argv.empty?
  invalid = flags.reject { |f| VALID.include?(f) || f == '-' }
  return [:invalid, invalid] unless invalid.empty?
  return [:version, flags] if flags.include?('v')
  return [:help, flags] if flags.include?('h')
  conv = flags.select { |f| %w[y t j c r].include?(f) }
  if conv.empty?
    %w[y j]
  elsif conv == ['r']
    %w[j y]
  elsif conv.length == 1
    c = conv[0]
    c == 'y' ? %w[y j] : [c, 'j']
  else
    conv[0, 2].map { |c| c == 'r' ? 'y' : c }
  end
end

begin
  parsed = parse_flags(ARGV)
  if parsed[0] == :version
    puts 'v0.0.0'
    exit 0
  elsif parsed[0] == :help
    puts HELP
    exit 0
  elsif parsed[0] == :invalid
    puts HELP
    puts "Error: invalid flags specified: #{parsed[1].join(' ')}"
    exit 1
  end

  input_fmt, output_fmt = parsed
  flags = ARGV.join.delete_prefix('-').chars
  if flags.include?('i') && !%w[j t].include?(output_fmt)
    puts HELP
    puts 'Error: flag -i only valid for JSON or TOML output'
    exit 1
  end
  if flags.include?('k') && output_fmt != 'y'
    puts HELP
    puts 'Error: flag -k only valid for YAML output'
    exit 1
  end

  text = STDIN.read
  data = case input_fmt
         when 'y' then YAML.safe_load(text, permitted_classes: [Date, Time], aliases: true)
         when 'j' then JSON.parse(text)
         when 't' then parse_toml(text)
         when 'c' then parse_hcl(text)
         end
  data = stringify_nonfinite(data) unless flags.include?('n')

  print case output_fmt
        when 'j' then json_out(data, flags.include?('i'), flags.include?('e'))
        when 'y' then yaml_out(data, flags.include?('k'))
        when 't' then toml_out(data, flags.include?('i'))
        when 'c' then hcl_out(data)
        end
rescue JSON::ParserError => e
  warn "Error parsing JSON: #{e.message}"
  exit 1
rescue Psych::Exception => e
  warn "Error parsing YAML: #{e.message}"
  exit 1
rescue StandardError => e
  fmt = { 'y' => 'YAML', 'j' => 'JSON', 't' => 'TOML', 'c' => 'HCL' }[input_fmt] || input_fmt.to_s.upcase
  warn "Error parsing #{fmt}: #{e.message}"
  exit 1
end
