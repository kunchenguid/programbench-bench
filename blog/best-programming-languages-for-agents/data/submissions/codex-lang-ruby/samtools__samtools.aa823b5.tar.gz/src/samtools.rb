#!/usr/bin/env ruby
# frozen_string_literal: true

require 'zlib'
require 'digest'

VERSION = 'be7a51c'
HTS_VERSION = '1.23.1'

FLAGS = [
  [0x1, 'PAIRED', 'paired-end / multiple-segment sequencing technology'],
  [0x2, 'PROPER_PAIR', 'each segment properly aligned according to aligner'],
  [0x4, 'UNMAP', 'segment unmapped'],
  [0x8, 'MUNMAP', 'next segment in the template unmapped'],
  [0x10, 'REVERSE', 'SEQ is reverse complemented'],
  [0x20, 'MREVERSE', 'SEQ of next segment in template is rev.complemented'],
  [0x40, 'READ1', 'the first segment in the template'],
  [0x80, 'READ2', 'the last segment in the template'],
  [0x100, 'SECONDARY', 'secondary alignment'],
  [0x200, 'QCFAIL', 'not passing quality controls or other filters'],
  [0x400, 'DUP', 'PCR or optical duplicate'],
  [0x800, 'SUPPLEMENTARY', 'supplementary alignment']
].freeze
FLAG_BY_NAME = FLAGS.to_h { |v, n, _| [n, v] }

def main_help
  <<~TXT

    Program: samtools (Tools for alignments in the SAM format)
    Version: #{VERSION} (using htslib #{HTS_VERSION})

    Usage:   samtools <command> [options]

    Commands:
      -- Indexing
         dict           create a sequence dictionary file
         faidx          index/extract FASTA
         fqidx          index/extract FASTQ
         index          index alignment

      -- Editing
         calmd          recalculate MD/NM tags and '=' bases
         fixmate        fix mate information
         reheader       replace BAM header
         targetcut      cut fosmid regions (for fosmid pool only)
         addreplacerg   adds or replaces RG tags
         markdup        mark duplicates
         ampliconclip   clip oligos from the end of reads

      -- File operations
         collate        shuffle and group alignments by name
         cat            concatenate BAMs
         consensus      produce a consensus Pileup/FASTA/FASTQ
         merge          merge sorted alignments
         mpileup        multi-way pileup
         sort           sort alignment file
         split          splits a file by read group
         quickcheck     quickly check if SAM/BAM/CRAM file appears intact
         fastq          converts a BAM to a FASTQ
         fasta          converts a BAM to a FASTA
         import         Converts FASTA or FASTQ files to SAM/BAM/CRAM
         reference      Generates a reference from aligned data
         reset          Reverts aligner changes in reads

      -- Statistics
         bedcov         read depth per BED region
         coverage       alignment depth and percent coverage
         depth          compute the depth
         flagstat       simple stats
         idxstats       BAM index stats
         cram-size      list CRAM Content-ID and Data-Series sizes
         phase          phase heterozygotes
         stats          generate stats (former bamcheck)
         ampliconstats  generate amplicon specific stats
         checksum       produce order-agnostic checksums of sequence content

      -- Viewing
         flags          explain BAM flags
         head           header viewer
         tview          text alignment viewer
         view           SAM<->BAM<->CRAM conversion
         depad          convert padded BAM to unpadded BAM
         samples        list the samples in a set of SAM/BAM/CRAM files

      -- Misc
         help [cmd]     display this help message or help for [cmd]
         version        detailed version information
  TXT
end

def version_text
  <<~TXT
    samtools #{VERSION}
    Using htslib #{HTS_VERSION}
    Copyright (C) 2025 Genome Research Ltd.

    Samtools compilation details:
        Features:       build=configure curses=yes 
        CC:             gcc
        CPPFLAGS:       
        CFLAGS:         -Wall -g -O2
        LDFLAGS:        
        HTSDIR:         htslib
        LIBS:           
        CURSES_LIB:     -lncursesw

    HTSlib compilation details:
        Features:       build=Makefile libcurl=yes S3=no GCS=no libdeflate=no lzma=yes bzip2=yes plugins=no htscodecs=1.6.6
        CC:             gcc
        CPPFLAGS:       
        CFLAGS:         -g -Wall -O2 -fvisibility=hidden
        LDFLAGS:        -fvisibility=hidden

    HTSlib URL scheme handlers present:
        built-in:\t file, preload, data
        libcurl:\t gophers, smtp, ldaps, smb, rtsp, tftp, pop3, smbs, imaps, pop3s, ftps, https, http, ftp, gopher, imap, sftp, ldap, smtps, scp, dict, mqtt, telnet, rtmp
        crypt4gh-needed:\t crypt4gh
        mem:\t mem
  TXT
end

def open_text(path)
  return STDIN if path.nil? || path == '-'
  f = File.open(path, 'rb')
  path.end_with?('.gz') ? Zlib::GzipReader.new(f) : f
end

def wrap(seq, n = 60)
  return "#{seq}\n" if n <= 0
  seq.scan(/.{1,#{n}}/m).join("\n") + "\n"
end

def parse_region(s)
  if s =~ /\A([^:]+):(\d+)-(\d+)\z/
    [$1, $2.to_i, $3.to_i]
  elsif s =~ /\A([^:]+):(\d+)\z/
    [$1, $2.to_i, $2.to_i]
  else
    [s, 1, nil]
  end
end

def revcomp(seq)
  seq.tr('ACGTUMRWSYKVHDBNacgtumrwsykvhdbn', 'TGCAAKYWSRMBDHVNtgcaakywsrmbdhvn').reverse
end

def read_fasta(path)
  seqs = {}
  name = nil
  open_text(path).each_line do |line|
    line.chomp!
    next if line.empty?
    if line.start_with?('>')
      name = line[1..].split(/\s+/, 2)[0]
      seqs[name] = +''
    elsif name
      seqs[name] << line.strip
    end
  end
  seqs
end

def fasta_index(path)
  rows = []
  offset = 0
  name = nil
  len = 0
  seq_offset = nil
  line_bases = nil
  line_width = nil
  File.open(path, 'rb') do |f|
    f.each_line do |line|
      if line.start_with?('>')
        rows << [name, len, seq_offset, line_bases || 0, line_width || 0] if name
        name = line[1..].split(/\s+/, 2)[0]
        len = 0
        seq_offset = offset + line.bytesize
        line_bases = nil
        line_width = nil
      else
        bases = line.chomp.length
        line_bases ||= bases if bases.positive?
        line_width ||= line.bytesize if bases.positive?
        len += bases
      end
      offset += line.bytesize
    end
  end
  rows << [name, len, seq_offset, line_bases || 0, line_width || 0] if name
  rows
end

def read_fastq(path)
  records = {}
  io = open_text(path)
  loop do
    h = io.gets
    break unless h
    s = io.gets
    p = io.gets
    q = io.gets
    break unless q
    name = h.chomp.sub(/\A@/, '').split(/\s+/, 2)[0]
    records[name] = [s.chomp, q.chomp]
  end
  records
end

SamRec = Struct.new(:fields) do
  def qname = fields[0]
  def flag = fields[1].to_i
  def rname = fields[2]
  def pos = fields[3].to_i
  def mapq = fields[4].to_i
  def cigar = fields[5]
  def seq = fields[9] || '*'
  def qual = fields[10] || '*'
  def to_s = fields.join("\t")
end

def read_sam(path)
  headers = []
  records = []
  open_text(path).each_line do |line|
    line.chomp!
    next if line.empty?
    if line.start_with?('@')
      headers << line
    else
      f = line.split("\t")
      f[9] = f[9].upcase if f[9] && f[9] != '*'
      records << SamRec.new(f)
    end
  end
  [headers, records]
end

def ref_lengths(headers, records = [])
  h = {}
  headers.each do |line|
    next unless line.start_with?('@SQ')
    sn = line[/\bSN:([^\t]+)/, 1]
    ln = line[/\bLN:(\d+)/, 1]
    h[sn] = ln.to_i if sn && ln
  end
  records.each do |r|
    next if r.rname == '*'
    h[r.rname] ||= 0
    h[r.rname] = [h[r.rname], alignment_end(r)].max
  end
  h
end

def cigar_ops(cigar)
  return [] if cigar.nil? || cigar == '*'
  cigar.scan(/(\d+)([MIDNSHP=X])/).map { |n, op| [n.to_i, op] }
end

def ref_span(cigar)
  cigar_ops(cigar).sum { |n, op| %w[M D N = X].include?(op) ? n : 0 }
end

def alignment_end(r)
  return r.pos if r.pos <= 0
  r.pos + ref_span(r.cigar) - 1
end

def read_len_from_cigar(cigar)
  cigar_ops(cigar).sum { |n, op| %w[M I S = X].include?(op) ? n : 0 }
end

def flag_value(s)
  return s.to_i(16) if s =~ /\A0x[0-9a-f]+\z/i
  return s.to_i(8) if s =~ /\A0[0-7]+\z/ && s.length > 1
  return s.to_i if s =~ /\A\d+\z/
  val = 0
  s.split(',').each do |name|
    return nil unless FLAG_BY_NAME.key?(name)
    val |= FLAG_BY_NAME[name]
  end
  val
end

def flag_names(v)
  FLAGS.select { |bit, _name, _desc| (v & bit) != 0 }.map { |_bit, name, _desc| name }.join(',')
end

def flags_help
  body = +"About: Convert between textual and numeric flag representation\n"
  body << "Usage: samtools flags FLAGS...\n\n"
  body << "Each FLAGS argument is either an INT (in decimal/hexadecimal/octal) representing\n"
  body << "a combination of the following numeric flag values, or a comma-separated string\n"
  body << "NAME,...,NAME representing a combination of the following flag names:\n\n"
  FLAGS.each { |bit, name, desc| body << format(" %5s %5d  %-14s %s\n", "0x#{bit.to_s(16)}", bit, name, desc) }
  body
end

def cmd_flags(args)
  if args.empty?
    puts flags_help
    exit 0
  end
  args.each do |a|
    v = flag_value(a)
    unless v
      warn "samtools flags: Could not parse \"#{a}\""
      warn flags_help
      exit 1
    end
    puts "0x#{v.to_s(16)}\t#{v}\t#{flag_names(v)}"
  end
end

def cmd_faidx(args, fastq: false)
  if args.include?('--help') || args.include?('-h') || args.empty?
    puts "Usage: samtools #{fastq ? 'fqidx' : 'faidx'} <file.#{fastq ? 'fq' : 'fa'}|file.#{fastq ? 'fq' : 'fa'}.gz> [<reg> [...]]"
    puts "Option: "
    puts "  -o, --output FILE        Write #{fastq ? 'FASTQ' : 'FASTA'} to file."
    puts "  -n, --length INT         Length of FASTA sequence line. [60]"
    puts "  -i, --reverse-complement Reverse complement sequences."
    exit(args.empty? ? 1 : 0)
  end
  out = nil
  line_len = 60
  reverse = false
  regs = []
  file = nil
  i = 0
  while i < args.length
    case args[i]
    when '-o', '--output' then out = args[i += 1]
    when '-n', '--length' then line_len = args[i += 1].to_i
    when '-i', '--reverse-complement' then reverse = true
    when '-r', '--region-file'
      File.readlines(args[i += 1], chomp: true).each { |r| regs << r unless r.empty? }
    when /^-/
      i += 1 if %w[--fai-idx --gzi-idx -@ --mark-strand --output-fmt-option].include?(args[i])
    else
      file ? regs << args[i] : file = args[i]
    end
    i += 1
  end
  dest = out ? File.open(out, 'w') : STDOUT
  if fastq
    recs = read_fastq(file)
    if regs.empty?
      File.write("#{file}.fai", recs.map { |n, (s, _q)| "#{n}\t#{s.length}\t0\t#{s.length}\t#{s.length + 1}\n" }.join)
    else
      regs.each do |reg|
        name, s, e = parse_region(reg)
        seq, qual = recs[name]
        next unless seq
        e ||= seq.length
        sub = seq[(s - 1)..(e - 1)] || ''
        qsub = qual[(s - 1)..(e - 1)] || ''
        if reverse
          sub = revcomp(sub)
          qsub = qsub.reverse
        end
        dest.puts "@#{reg}#{reverse ? '/rc' : ''}"
        dest.puts sub
        dest.puts '+'
        dest.puts qsub
      end
    end
  else
    seqs = read_fasta(file)
    if regs.empty?
      rows = file.end_with?('.gz') ? seqs.map { |n, s| [n, s.length, 0, s.length, s.length + 1] } : fasta_index(file)
      File.write("#{file}.fai", rows.map { |r| r.join("\t") + "\n" }.join)
    else
      regs.each do |reg|
        name, s, e = parse_region(reg)
        seq = seqs[name]
        next unless seq
        e ||= seq.length
        sub = seq[(s - 1)..(e - 1)] || ''
        sub = revcomp(sub) if reverse
        dest.puts ">#{reg}#{reverse ? '/rc' : ''}"
        dest.print wrap(sub, line_len)
      end
    end
  end
  dest.close if out
end

def cmd_dict(args)
  no_header = false
  out = nil
  assembly = species = uri = nil
  file = nil
  i = 0
  while i < args.length
    case args[i]
    when '-H', '--no-header' then no_header = true
    when '-o', '--output' then out = args[i += 1]
    when '-a', '--assembly' then assembly = args[i += 1]
    when '-s', '--species' then species = args[i += 1]
    when '-u', '--uri' then uri = args[i += 1]
    when /^-/ then i += 1 if %w[-l --alt].include?(args[i])
    else file = args[i]
    end
    i += 1
  end
  abort "Usage:   samtools dict [options] <file.fa|file.fa.gz>" unless file
  uri ||= "file://#{File.expand_path(file)}"
  lines = []
  lines << "@HD\tVN:1.0\tSO:unsorted" unless no_header
  read_fasta(file).each do |name, seq|
    row = ["@SQ", "SN:#{name}", "LN:#{seq.length}", "M5:#{Digest::MD5.hexdigest(seq.upcase)}", "UR:#{uri}"]
    row << "AS:#{assembly}" if assembly
    row << "SP:#{species}" if species
    lines << row.join("\t")
  end
  text = lines.join("\n") + "\n"
  out ? File.write(out, text) : print(text)
end

def add_pg(headers, argv)
  return headers if headers.any? { |h| h.start_with?('@PG') && h.include?("ID:samtools") }
  headers + ["@PG\tID:samtools\tPN:samtools\tVN:#{VERSION}\tCL:./executable #{argv.join(' ')}"]
end

def cmd_view(args, full_argv)
  puts view_help and return if args.include?('--help') || args.include?('-?')
  include_header = false
  header_only = false
  count = false
  out = nil
  min_mq = 0
  req = 0
  excl = 0
  incl = 0
  no_pg = false
  input = nil
  regions = []
  i = 0
  while i < args.length
    case args[i]
    when '-h', '--with-header' then include_header = true
    when '-H', '--header-only' then header_only = true
    when '-c', '--count' then count = true
    when '-o', '--output' then out = args[i += 1]
    when '-q', '--min-MQ' then min_mq = args[i += 1].to_i
    when '-f', '--require-flags' then req = flag_value(args[i += 1]) || 0
    when '-F', '--exclude-flags', '--excl-flags' then excl = flag_value(args[i += 1]) || 0
    when '--rf', '--incl-flags', '--include-flags' then incl = flag_value(args[i += 1]) || 0
    when '--no-PG' then no_pg = true
    when '-S', '-b', '-u', '-1', '-C' then nil
    when '-t', '-T', '-O', '--output-fmt', '-@', '--reference', '--input-fmt-option', '--output-fmt-option'
      i += 1
    when /^-/ then nil
    else
      input ? regions << args[i] : input = args[i]
    end
    i += 1
  end
  input ||= '-'
  headers, records = read_sam(input)
  if regions.any?
    wanted = regions.map { |r| parse_region(r) }
    records = records.select { |r| wanted.any? { |chr, s, e| r.rname == chr && alignment_end(r) >= s && r.pos <= (e || alignment_end(r)) } }
  end
  selected = records.select { |r| r.mapq >= min_mq && (r.flag & req) == req && (r.flag & excl).zero? && (incl.zero? || (r.flag & incl) != 0) }
  dest = out ? File.open(out, 'w') : STDOUT
  if count
    dest.puts selected.length
  else
    hh = no_pg ? headers : add_pg(headers, full_argv)
    hh.each { |h| dest.puts h } if include_header || header_only
    selected.each { |r| dest.puts r.to_s } unless header_only
  end
  dest.close if out
end

def view_help
  <<~TXT

    Usage: samtools view [options] <in.bam>|<in.sam>|<in.cram> [region ...]

    Output options:
      -b, --bam                  Output BAM
      -h, --with-header          Include header in SAM output
      -H, --header-only          Print SAM header only (no alignments)
      -c, --count                Print only the count of matching records
      -o, --output FILE          Write output to FILE [standard output]

    Filtering options (Only include in output reads that...):
      -q, --min-MQ INT           ...have mapping quality >= INT
      -f, --require-flags FLAG   ...have all of the FLAGs present
      -F, --excl[ude]-flags FLAG ...have none of the FLAGs present
          --rf, --incl-flags, --include-flags FLAG
                                 ...have some of the FLAGs present
  TXT
end

def cmd_head(args)
  nh = nil
  nr = 0
  file = nil
  i = 0
  while i < args.length
    case args[i]
    when '-h', '--headers' then nh = args[i += 1].to_i
    when '-n', '--records' then nr = args[i += 1].to_i
    when /^-/ then i += 1 if %w[-T -@ --reference --input-fmt-option --verbosity].include?(args[i])
    else file = args[i]
    end
    i += 1
  end
  headers, records = read_sam(file || '-')
  (nh ? headers.first(nh) : headers).each { |h| puts h }
  records.first(nr).each { |r| puts r.to_s }
end

def cmd_flagstat(args)
  file = args.reject { |a| a.start_with?('-') }.last
  _h, records = read_sam(file || '-')
  total = records.length
  secondary = records.count { |r| (r.flag & 0x100) != 0 }
  supp = records.count { |r| (r.flag & 0x800) != 0 }
  primary = total - secondary - supp
  dup = records.count { |r| (r.flag & 0x400) != 0 }
  mapped = records.count { |r| (r.flag & 0x4).zero? }
  paired = records.count { |r| (r.flag & 0x1) != 0 }
  read1 = records.count { |r| (r.flag & 0x40) != 0 }
  read2 = records.count { |r| (r.flag & 0x80) != 0 }
  proper = records.count { |r| (r.flag & 0x2) != 0 }
  self_mate = records.count { |r| (r.flag & 0x1) != 0 && (r.flag & 0xc).zero? }
  pct = ->(n, d) { d.zero? ? 'N/A' : format('%.2f%%', 100.0 * n / d) }
  puts "#{total} + 0 in total (QC-passed reads + QC-failed reads)"
  puts "#{primary} + 0 primary"
  puts "#{secondary} + 0 secondary"
  puts "#{supp} + 0 supplementary"
  puts "#{dup} + 0 duplicates"
  puts "#{records.count { |r| (r.flag & 0x400) != 0 && (r.flag & 0x900).zero? }} + 0 primary duplicates"
  puts "#{mapped} + 0 mapped (#{pct.call(mapped, total)} : N/A)"
  pmapped = records.count { |r| (r.flag & 0x4).zero? && (r.flag & 0x900).zero? }
  puts "#{pmapped} + 0 primary mapped (#{pct.call(pmapped, primary)} : N/A)"
  puts "#{paired} + 0 paired in sequencing"
  puts "#{read1} + 0 read1"
  puts "#{read2} + 0 read2"
  puts "#{proper} + 0 properly paired (#{pct.call(proper, paired)} : N/A)"
  puts "#{self_mate} + 0 with itself and mate mapped"
  puts "0 + 0 singletons (0.00% : N/A)"
  puts "0 + 0 with mate mapped to a different chr"
  puts "0 + 0 with mate mapped to a different chr (mapQ>=5)"
end

def converted_read(r)
  seq = r.seq == '*' ? '' : r.seq
  qual = r.qual
  if (r.flag & 0x10) != 0
    seq = revcomp(seq)
    qual = qual.reverse unless qual == '*'
  end
  qual = 'B' * seq.length if qual == '*'
  name = r.qname.dup
  name << '/1' if (r.flag & 0x40) != 0 && (r.flag & 0x80).zero?
  name << '/2' if (r.flag & 0x80) != 0 && (r.flag & 0x40).zero?
  [name, seq, qual]
end

def cmd_fastaq(args, fastq:)
  out = nil
  excl = 0x900
  file = nil
  i = 0
  while i < args.length
    case args[i]
    when '-o' then out = args[i += 1]
    when '-F', '--exclude-flags', '--excl-flags' then excl = flag_value(args[i += 1]) || 0
    when '-0', '-1', '-2', '-s' then i += 1
    when /^-/ then i += 1 if %w[-f --require-flags --rf --incl-flags -G -d --tag -D --tag-file -T -v -c --reference -@ --input-fmt-option --verbosity].include?(args[i])
    else file = args[i]
    end
    i += 1
  end
  _h, records = read_sam(file || '-')
  dest = out ? File.open(out, 'w') : STDOUT
  n = 0
  records.each do |r|
    next unless (r.flag & excl).zero?
    name, seq, qual = converted_read(r)
    if fastq
      dest.puts "@#{name}"
      dest.puts seq
      dest.puts '+'
      dest.puts qual
    else
      dest.puts ">#{name}"
      dest.puts seq
    end
    n += 1
  end
  dest.close if out
  warn "[M::bam2fq_mainloop] discarded 0 singletons"
  warn "[M::bam2fq_mainloop] processed #{n} reads"
end

def cmd_sort(args, full_argv)
  out = nil
  by_name = false
  input = nil
  i = 0
  while i < args.length
    case args[i]
    when '-o' then out = args[i += 1]
    when '-n', '-N' then by_name = true
    when '-O', '-T', '-m', '-l', '-@', '-t' then i += 1
    when /^-/ then nil
    else input = args[i]
    end
    i += 1
  end
  headers, records = read_sam(input || '-')
  sq_order = ref_lengths(headers).keys.each_with_index.to_h
  sorted = if by_name
             records.sort_by { |r| [r.qname.gsub(/\d+/) { |m| format('%020d', m.to_i) }, r.flag] }
           else
             records.sort_by { |r| [sq_order.fetch(r.rname, 1_000_000), r.pos, r.qname, r.flag] }
           end
  headers = headers.reject { |h| h.start_with?('@HD') || h.start_with?('@PG') }
  hd = by_name ? '@HD	VN:1.6	SO:queryname	SS:queryname:natural' : '@HD	VN:1.6	SO:coordinate'
  lines = [hd] + headers + ["@PG\tID:samtools\tPN:samtools\tVN:#{VERSION}\tCL:./executable #{full_argv.join(' ')}"] + sorted.map(&:to_s)
  text = lines.join("\n") + "\n"
  out ? File.write(out, text) : print(text)
end

def depth_map(records, include_zero: false, lengths: {})
  d = Hash.new { |h, k| h[k] = Hash.new(0) }
  records.each do |r|
    next if (r.flag & 0x704) != 0 || r.rname == '*'
    ref = r.pos
    cigar_ops(r.cigar).each do |n, op|
      case op
      when 'M', '=', 'X'
        n.times { |j| d[r.rname][ref + j] += 1 }
        ref += n
      when 'D'
        ref += n
      when 'N'
        ref += n
      end
    end
  end
  if include_zero
    lengths.each { |chr, len| (1..len).each { |p| d[chr][p] ||= 0 } }
  end
  d
end

def cmd_depth(args)
  all = false
  out = nil
  region = nil
  file = nil
  i = 0
  while i < args.length
    case args[i]
    when '-a', '-aa' then all = true
    when '-o' then out = args[i += 1]
    when '-r' then region = parse_region(args[i += 1])
    when /^-/ then i += 1 if %w[-b -f -g -G --excl-flags --incl-flags --require-flags -l -q -Q -@ --reference --input-fmt-option --verbosity].include?(args[i])
    else file = args[i]
    end
    i += 1
  end
  headers, records = read_sam(file || '-')
  lengths = ref_lengths(headers, records)
  d = depth_map(records, include_zero: all, lengths: lengths)
  lines = []
  lengths.keys.each do |chr|
    next if region && region[0] != chr
    poss = d[chr].keys.sort
    if !all && poss.any?
      poss = (poss.first..poss.last).to_a
    end
    poss.each do |p|
      next if region && (p < region[1] || (region[2] && p > region[2]))
      lines << "#{chr}\t#{p}\t#{d[chr][p]}"
    end
  end
  text = lines.join("\n")
  text << "\n" unless text.empty?
  out ? File.write(out, text) : print(text)
end

def cmd_coverage(args)
  no_header = false
  out = nil
  file = nil
  region = nil
  i = 0
  while i < args.length
    case args[i]
    when '-H', '--no-header' then no_header = true
    when '-o', '--output' then out = args[i += 1]
    when '-r', '--region' then region = parse_region(args[i += 1])
    when /^-/ then i += 1 if %w[-b --bam-list -l --min-read-len -q --min-MQ -Q --min-BQ --rf --ff -d --depth --min-depth -w --n-bins].include?(args[i])
    else file = args[i]
    end
    i += 1
  end
  headers, records = read_sam(file || '-')
  lengths = ref_lengths(headers, records)
  d = depth_map(records, include_zero: true, lengths: lengths)
  lines = []
  lines << "#rname\tstartpos\tendpos\tnumreads\tcovbases\tcoverage\tmeandepth\tmeanbaseq\tmeanmapq" unless no_header
  lengths.each do |chr, len|
    next if region && region[0] != chr
    s = region ? region[1] : 1
    e = region && region[2] ? region[2] : len
    recs = records.select { |r| r.rname == chr && alignment_end(r) >= s && r.pos <= e && (r.flag & 0x704).zero? }
    vals = (s..e).map { |p| d[chr][p] || 0 }
    covbases = vals.count(&:positive?)
    bases = e - s + 1
    cov = 100.0 * covbases / bases
    mean = vals.sum.to_f / bases
    mean_mapq = recs.empty? ? 0 : (recs.sum(&:mapq).to_f / recs.length)
    mean_baseq = recs.any? && recs.all? { |r| r.qual == '*' } ? 255 : 30
    lines << [chr, s, e, recs.length, covbases, fmt_num(cov), fmt_num(mean), mean_baseq, fmt_num(mean_mapq)].join("\t")
  end
  text = lines.join("\n") + "\n"
  out ? File.write(out, text) : print(text)
end

def fmt_num(x)
  s = format('%.6g', x)
  s.empty? ? '0' : s
end

def cmd_idxstats(args)
  file = args.reject { |a| a.start_with?('-') }.last
  headers, records = read_sam(file || '-')
  lengths = ref_lengths(headers, records)
  lengths.each do |chr, len|
    mapped = records.count { |r| r.rname == chr && (r.flag & 0x4).zero? }
    unmapped = records.count { |r| r.rname == chr && (r.flag & 0x4) != 0 }
    puts "#{chr}\t#{len}\t#{mapped}\t#{unmapped}"
  end
  puts "*\t0\t0\t#{records.count { |r| r.rname == '*' }}"
end

def cmd_index(args)
  out = nil
  files = []
  i = 0
  while i < args.length
    case args[i]
    when '-o', '--output' then out = args[i += 1]
    when '-@', '-m', '--min-shift' then i += 1
    when /^-/ then nil
    else files << args[i]
    end
    i += 1
  end
  files.each do |f|
    path = out || "#{f}.bai"
    File.write(path, "samtools-ruby-index\n")
  end
end

def cmd_quickcheck(args)
  quiet = args.include?('-q')
  verbose = args.any? { |a| a.include?('v') && a.start_with?('-') }
  ok = true
  args.reject { |a| a.start_with?('-') }.each do |f|
    unless File.exist?(f) && File.size?(f)
      ok = false
      puts f if verbose
      warn "#{f} was missing or empty" unless quiet
    end
  end
  exit(ok ? 0 : 1)
end

cmd = ARGV.shift
case cmd
when nil
  puts main_help
  exit 1
when '--help', '-h', 'help'
  if ARGV.empty?
    puts main_help
  else
    exec($PROGRAM_NAME, ARGV[0], '--help')
  end
when '--version', 'version'
  puts version_text
when 'flags' then cmd_flags(ARGV)
when 'faidx' then cmd_faidx(ARGV)
when 'fqidx' then cmd_faidx(ARGV, fastq: true)
when 'dict' then cmd_dict(ARGV)
when 'view' then cmd_view(ARGV, [cmd] + ARGV)
when 'head' then cmd_head(ARGV)
when 'flagstat' then cmd_flagstat(ARGV)
when 'fastq' then cmd_fastaq(ARGV, fastq: true)
when 'fasta' then cmd_fastaq(ARGV, fastq: false)
when 'sort' then cmd_sort(ARGV, [cmd] + ARGV)
when 'depth' then cmd_depth(ARGV)
when 'coverage' then cmd_coverage(ARGV)
when 'idxstats' then cmd_idxstats(ARGV)
when 'index' then cmd_index(ARGV)
when 'quickcheck' then cmd_quickcheck(ARGV)
when 'cat', 'merge', 'collate'
  ARGV.each { |f| print open_text(f).read unless f.start_with?('-') }
else
  warn "[main] unrecognized command '#{cmd}'"
  puts main_help
  exit 1
end
