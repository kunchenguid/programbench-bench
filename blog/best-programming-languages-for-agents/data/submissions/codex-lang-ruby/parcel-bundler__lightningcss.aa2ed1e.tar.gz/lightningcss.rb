#!/usr/bin/env ruby
# frozen_string_literal: true

require 'digest'
require 'fileutils'

VERSION = "lightningcss 1.0.0-alpha.70"
HELP = <<~TEXT
  lightningcss 1.0.0-alpha.70
  Devon Govett <devongovett@gmail.com>
  A CSS parser, transformer, and minifier

  USAGE:
      executable [OPTIONS] [INPUT_FILE]...

  ARGS:
      <INPUT_FILE>...    Target CSS file (default: stdin)

  OPTIONS:
          --browserslist
              

          --bundle
              

          --css-modules [<CSS_MODULES>]
              Enable CSS modules in output. If no filename is provided, <output_file>.json will be
              used. If no --output-file is specified, code and exports will be printed to stdout as
              JSON

          --css-modules-dashed-idents
              

          --css-modules-pattern <CSS_MODULES_PATTERN>
              

          --custom-media
              Enable parsing custom media queries

      -d, --output-dir <OUTPUT_DIR>
              Destination directory to output into

          --error-recovery
              

      -h, --help
              Print help information

      -m, --minify
              Minify the output

      -o, --output-file <OUTPUT_FILE>
              Destination file for the output

          --sourcemap
              Enable sourcemap, at <output_file>.map

      -t, --targets <TARGETS>
              

      -V, --version
              Print version information
TEXT

class ParserError < StandardError; end

def json_escape(str)
  str.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
    case ch
    when '"' then '\\"'
    when '\\' then '\\\\'
    when "\b" then '\\b'
    when "\f" then '\\f'
    when "\n" then '\\n'
    when "\r" then '\\r'
    when "\t" then '\\t'
    end
  end
end

def json_generate(obj)
  case obj
  when Hash
    '{' + obj.map { |k, v| "#{json_generate(k.to_s)}:#{json_generate(v)}" }.join(',') + '}'
  when Array
    '[' + obj.map { |v| json_generate(v) }.join(',') + ']'
  when String
    '"' + json_escape(obj) + '"'
  when Symbol
    json_generate(obj.to_s)
  when true
    'true'
  when false
    'false'
  when nil
    'null'
  else
    obj.to_s
  end
end

def die(message, status = 1)
  warn message
  exit status
end

def parse_args(argv)
  opts = {
    minify: false, output_file: nil, output_dir: nil, sourcemap: false,
    css_modules: false, css_modules_file: nil, pattern: nil, targets: nil,
    browserslist: false, bundle: false, custom_media: false, error_recovery: false,
    dashed: false, inputs: []
  }

  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-h', '--help'
      puts HELP
      exit 0
    when '-V', '--version'
      puts VERSION
      exit 0
    when '-m', '--minify'
      opts[:minify] = true
    when '-o', '--output-file'
      i += 1
      die("error: The argument '--output-file <OUTPUT_FILE>' requires a value", 2) unless argv[i]
      opts[:output_file] = argv[i]
    when /^--output-file=(.*)$/
      opts[:output_file] = Regexp.last_match(1)
    when '-d', '--output-dir'
      i += 1
      die("error: The argument '--output-dir <OUTPUT_DIR>' requires a value", 2) unless argv[i]
      opts[:output_dir] = argv[i]
    when /^--output-dir=(.*)$/
      opts[:output_dir] = Regexp.last_match(1)
    when '--sourcemap'
      opts[:sourcemap] = true
    when '--css-modules'
      opts[:css_modules] = true
      if argv[i + 1] && !argv[i + 1].start_with?('-')
        i += 1
        opts[:css_modules_file] = argv[i]
      end
    when /^--css-modules=(.*)$/
      opts[:css_modules] = true
      opts[:css_modules_file] = Regexp.last_match(1)
    when '--css-modules-pattern'
      i += 1
      opts[:pattern] = argv[i] || die("error: The argument '--css-modules-pattern <CSS_MODULES_PATTERN>' requires a value", 2)
    when /^--css-modules-pattern=(.*)$/
      opts[:pattern] = Regexp.last_match(1)
    when '--css-modules-dashed-idents'
      opts[:dashed] = true
    when '-t', '--targets'
      i += 1
      opts[:targets] = argv[i] || die("error: The argument '--targets <TARGETS>' requires a value", 2)
    when /^--targets=(.*)$/
      opts[:targets] = Regexp.last_match(1)
    when '--browserslist'
      opts[:browserslist] = true
    when '--bundle'
      opts[:bundle] = true
    when '--custom-media'
      opts[:custom_media] = true
    when '--error-recovery'
      opts[:error_recovery] = true
    when '--'
      opts[:inputs].concat(argv[(i + 1)..] || [])
      break
    else
      if arg.start_with?('-')
        warn "error: Found argument '#{arg}' which wasn't expected, or isn't valid in this context"
        warn ""
        warn "\tIf you tried to supply `#{arg}` as a value rather than a flag, use `-- #{arg}`"
        warn ""
        warn "USAGE:"
        warn "    executable [OPTIONS] [INPUT_FILE]..."
        warn ""
        warn "For more information try --help"
        exit 2
      end
      opts[:inputs] << arg
    end
    i += 1
  end

  if opts[:output_file] && opts[:output_dir]
    warn "error: The argument '--output-dir <OUTPUT_DIR>' cannot be used with '--output-file <OUTPUT_FILE>'"
    warn ""
    warn "USAGE:"
    warn "    executable <--output-file <OUTPUT_FILE>|--output-dir <OUTPUT_DIR>> <INPUT_FILE>..."
    warn ""
    warn "For more information try --help"
    exit 2
  end
  if opts[:output_file] && opts[:inputs].length > 1
    die("Cannot use the --output-file option with multiple inputs. Use --output-dir instead.")
  end
  if opts[:sourcemap] && !opts[:output_file] && !opts[:output_dir]
    warn "error: The following required arguments were not provided:"
    warn "    <--output-file <OUTPUT_FILE>|--output-dir <OUTPUT_DIR>>"
    warn ""
    warn "USAGE:"
    warn "    executable --sourcemap <--output-file <OUTPUT_FILE>|--output-dir <OUTPUT_DIR>>"
    warn ""
    warn "For more information try --help"
    exit 2
  end
  opts
end

def strip_comments(css)
  css.gsub(%r{/\*.*?\*/}m, '')
end

def split_top_level(css)
  rules = []
  i = 0
  while i < css.length
    i += 1 while i < css.length && css[i] =~ /\s/
    break if i >= css.length
    start = i
    depth = 0
    saw_block = false
    in_str = nil
    while i < css.length
      ch = css[i]
      if in_str
        if ch == '\\'
          i += 2
          next
        elsif ch == in_str
          in_str = nil
        end
      else
        in_str = ch if ch == '"' || ch == "'"
        if ch == '{'
          depth += 1
          saw_block = true
        end
        if ch == ';' && !saw_block && depth.zero?
          i += 1
          break
        end
        if ch == '}'
          depth -= 1
          if depth <= 0
            i += 1
            break
          end
        end
      end
      i += 1
    end
    text = css[start...i].to_s.strip
    rules << text unless text.empty?
  end
  rules
end

def split_decls(body)
  out = []
  buf = +''
  depth = 0
  in_str = nil
  body.each_char do |ch|
    if in_str
      buf << ch
      if ch == '\\'
        # The following char, if any, will be appended normally. This is good
        # enough for declaration splitting.
      elsif ch == in_str
        in_str = nil
      end
      next
    end
    case ch
    when '"', "'"
      in_str = ch
      buf << ch
    when '(', '[', '{'
      depth += 1
      buf << ch
    when ')', ']', '}'
      depth -= 1 if depth.positive?
      buf << ch
    when ';'
      if depth.zero?
        out << buf.strip unless buf.strip.empty?
        buf = +''
      else
        buf << ch
      end
    else
      buf << ch
    end
  end
  out << buf.strip unless buf.strip.empty?
  out
end

def split_prop(decl)
  depth = 0
  in_str = nil
  decl.chars.each_with_index do |ch, idx|
    if in_str
      in_str = nil if ch == in_str
      next
    end
    case ch
    when '"', "'"
      in_str = ch
    when '('
      depth += 1
    when ')'
      depth -= 1 if depth.positive?
    when ':'
      return [decl[0...idx].strip, decl[(idx + 1)..].to_s.strip] if depth.zero?
    end
  end
  [decl.strip, '']
end

NAMED_COLORS = {
  'black' => '#000', 'white' => '#fff', 'blue' => '#00f', 'red' => 'red',
  'green' => 'green', 'transparent' => '#0000'
}.freeze

def compress_hex(hex)
  h = hex.downcase
  return NAMED_COLORS.key(h) || h if h.length != 7 && h.length != 9
  if h.length == 7 && h[1] == h[2] && h[3] == h[4] && h[5] == h[6]
    short = "##{h[1]}#{h[3]}#{h[5]}"
    return 'red' if short == '#f00'
    return short
  end
  if h.length == 9 && h[1] == h[2] && h[3] == h[4] && h[5] == h[6] && h[7] == h[8]
    return "##{h[1]}#{h[3]}#{h[5]}#{h[7]}"
  end
  h
end

def byte_hex(n)
  n = [[n.round, 0].max, 255].min
  n.to_s(16).rjust(2, '0')
end

def normalize_value(prop, value, minify, targets)
  v = value.strip.gsub(/\s+/, ' ')
  v = v.gsub(/\binline\s+flex\b/, 'inline-flex')
  v = v.gsub(/\binline\s+grid\b/, 'inline-grid')
  v = v.gsub(/(?<![\d.])0(?:\.0+)?(px|em|rem|vh|vw|vmin|vmax|%|s|ms|deg|rad|turn)\b/i, '0')
  v = v.gsub(/(?<=\d)\.0+(?=(px|em|rem|%|s|ms|deg|rad|turn)\b)/i, '')
  v = v.gsub(/(?<=\d)\.(\d*?)0+(?=(px|em|rem|%|s|ms|deg|rad|turn)\b)/i, '.\1')
  v = v.gsub(/\b0+\.(\d+)/, '.\1') if minify
  v = v.gsub(/\brgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i) do
    compress_hex("##{byte_hex($1.to_i)}#{byte_hex($2.to_i)}#{byte_hex($3.to_i)}")
  end
  v = v.gsub(/\brgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([0-9.]+)\s*\)/i) do
    alpha = $4.to_f
    if targets && !targets.empty?
      "rgba(#{$1},#{$2},#{$3},#{minify ? $4.sub(/^0\./, '.') : $4})"
    else
      compress_hex("##{byte_hex($1.to_i)}#{byte_hex($2.to_i)}#{byte_hex($3.to_i)}#{byte_hex(alpha * 255)}")
    end
  end
  v = v.gsub(/#[0-9a-fA-F]{6,8}\b/) { |m| compress_hex(m) }
  v = NAMED_COLORS[v.downcase] || v if prop =~ /color\z|background-color\z|border-.*color\z/
  v = '700' if minify && prop == 'font-weight' && v == 'bold'
  v = '400' if minify && prop == 'font-weight' && v == 'normal'
  if %w[margin padding].include?(prop)
    parts = v.split(/\s+/)
    v = parts[0] if parts.length == 4 && parts.uniq.length == 1
    v = parts[0] if parts.length == 2 && parts[0] == parts[1]
    v = "#{parts[0]} #{parts[1]}" if parts.length == 4 && parts[0] == parts[2] && parts[1] == parts[3]
    v = "#{parts[0]} #{parts[1]} #{parts[2]}" if parts.length == 4 && parts[1] == parts[3] && parts[0] != parts[2]
  end
  v
end

def normalize_selector(sel, minify)
  s = sel.strip.gsub(/\s+/, ' ')
  s = s.gsub(/\s*,\s*/, minify ? ',' : ', ')
  s = s.gsub(/\s*([>+~])\s*/, minify ? '\1' : ' \1 ')
  s
end

def parse_rule(rule)
  idx = rule.index('{')
  return [rule.strip, nil] unless idx
  [rule[0...idx].strip, rule[(idx + 1)...-1].to_s.strip]
end

def declarations_for(body, minify, targets)
  seen = {}
  order = []
  split_decls(body).each do |decl|
    prop, val = split_prop(decl)
    next if prop.empty?
    prop = prop.downcase
    order << prop unless seen.key?(prop)
    seen[prop] = normalize_value(prop, val, minify, targets)
  end
  order.select { |p| seen.key?(p) }.map { |p| [p, seen[p]] }
end

def transform_media(prelude, minify, targets)
  p = prelude.dup
  if targets && !targets.empty?
    p = p.gsub(/\(\s*width\s*<=\s*([^)]+?)\s*\)/, '(max-width:\1)')
    p = p.gsub(/\(\s*width\s*>=\s*([^)]+?)\s*\)/, '(min-width:\1)')
  end
  p = p.gsub(/\s*:\s*/, ':') if minify
  p = p.gsub(/\s*<=\s*/, '<=') if minify
  p
end

def format_css(css, minify: false, targets: nil, indent: 0)
  css = strip_comments(css)
  chunks = []
  split_top_level(css).each do |rule|
    pre, body = parse_rule(rule)
    unless body
      chunks << (minify ? pre.gsub(/\s+/, ' ') : "#{'  ' * indent}#{pre}")
      next
    end
    if pre.start_with?('@media', '@supports', '@document', '@layer')
      name = pre.sub(/^@media\b/, '@media')
      name = transform_media(name, minify, targets) if name.start_with?('@media')
      inner = format_css(body, minify: minify, targets: targets, indent: indent + 1)
      if minify
        chunks << "#{name.gsub(/\s+/, ' ')}{#{inner}}"
      else
        chunks << "#{'  ' * indent}#{name} {\n#{inner}\n#{'  ' * indent}}"
      end
      next
    end

    if pre.start_with?('@keyframes') || pre =~ /^@-\w+-keyframes/
      inner_chunks = split_top_level(body).map do |r|
        k, b = parse_rule(r)
        decls = declarations_for(b || '', minify, targets)
        if minify
          "#{k}{#{decls.map { |p, v| "#{p}:#{v}" }.join(';')}}"
        else
          lines = decls.map { |p, v| "#{'  ' * (indent + 2)}#{p}: #{v};" }
          "#{'  ' * (indent + 1)}#{k} {\n#{lines.join("\n")}\n#{'  ' * (indent + 1)}}"
        end
      end
      chunks << (minify ? "#{pre}{#{inner_chunks.join}}" : "#{'  ' * indent}#{pre} {\n#{inner_chunks.join("\n\n")}\n#{'  ' * indent}}")
      next
    end

    if pre.start_with?('@')
      chunks << (minify ? "#{pre}{#{body.strip}}" : "#{'  ' * indent}#{pre} {\n#{body.strip}\n#{'  ' * indent}}")
      next
    end

    decls = declarations_for(body, minify, targets)
    selector = normalize_selector(pre, minify)
    if minify
      chunks << "#{selector}{#{decls.map { |p, v| "#{p}:#{v}" }.join(';')}}"
    else
      lines = decls.map { |p, v| "#{'  ' * (indent + 1)}#{p}: #{v};" }
      chunks << "#{'  ' * indent}#{selector} {\n#{lines.join("\n")}\n#{'  ' * indent}}"
    end
  end
  minify ? chunks.join : chunks.join("\n\n") + (chunks.empty? ? '' : "\n")
end

def module_prefix(path)
  Digest::SHA1.base64digest(File.expand_path(path))[0, 6].tr('+/=', 'abc')
end

def css_modules(css, path, opts)
  prefix = module_prefix(path || 'stdin')
  exports = {}
  pattern = opts[:pattern]
  transformed = css.dup
  globals = []
  transformed = transformed.gsub(/:global\(([^)]+)\)/) do
    globals << Regexp.last_match(1)
    "__LCSS_GLOBAL_#{globals.length - 1}__"
  end
  transformed = transformed.gsub(/([.#])([A-Za-z_-][\w-]*)/) do
    sigil = Regexp.last_match(1)
    local = Regexp.last_match(2)
    next Regexp.last_match(0) if local.start_with?('-')
    name = if pattern
             File.basename(path || 'stdin', '.css')
                 .then { |base| pattern.gsub('[name]', base).gsub('[local]', local).gsub('[hash]', prefix) }
           else
             "#{prefix}_#{local}"
           end
    exports[local] ||= { 'name' => name, 'composes' => [], 'isReferenced' => false }
    "#{sigil}#{name}"
  end
  transformed = transformed.gsub(/__LCSS_GLOBAL_(\d+)__/) { globals[Regexp.last_match(1).to_i] }
  transformed = transformed.gsub(/(@(?:-\w+-)?keyframes)\s+([A-Za-z_-][\w-]*)/) do
    local = Regexp.last_match(2)
    name = pattern ? pattern.gsub('[name]', File.basename(path || 'stdin', '.css')).gsub('[local]', local).gsub('[hash]', prefix) : "#{prefix}_#{local}"
    exports[local] ||= { 'name' => name, 'composes' => [], 'isReferenced' => false }
    "#{Regexp.last_match(1)} #{name}"
  end
  [transformed, exports]
end

def write_sourcemap(output_file, input_name, source)
  map = {
    version: 3, mappings: 'AAAA',
    sources: [input_name || '<stdin>'],
    sourcesContent: [source],
    names: []
  }
  File.write("#{output_file}.map", json_generate(map))
end

def process_source(css, input_name, opts, for_file: false)
  exports = nil
  if opts[:css_modules]
    css, exports = css_modules(css, input_name, opts)
  end
  code = format_css(css, minify: opts[:minify], targets: opts[:targets])
  if opts[:css_modules] && !for_file && !opts[:output_file] && !opts[:output_dir]
    return json_generate('code' => code, 'exports' => exports || {})
  end
  [code, exports || {}]
end

opts = parse_args(ARGV)

if opts[:inputs].empty?
  input = STDIN.read
  result = process_source(input, nil, opts)
  puts(result.is_a?(Array) ? result[0] : result)
  exit 0
end

if opts[:output_dir]
  FileUtils.mkdir_p(opts[:output_dir])
  opts[:inputs].each do |path|
    css = File.read(path)
    code, exports = process_source(css, path, opts, for_file: true)
    out = File.join(opts[:output_dir], File.basename(path))
    if opts[:sourcemap]
      code += "\n/*# sourceMappingURL=#{out}.map */\n"
      write_sourcemap(out, path, css)
    end
    File.write(out, code)
    if opts[:css_modules]
      json_path = opts[:css_modules_file] || "#{out}.json"
      File.write(json_path, json_generate(exports))
    end
  rescue Errno::ENOENT => e
    die("Error: #{e.inspect}")
  end
  exit 0
end

path = opts[:inputs].first
begin
  css = File.read(path)
rescue Errno::ENOENT => e
  die("Error: #{e.inspect}")
end

code, exports = process_source(css, path, opts, for_file: !!opts[:output_file])
if opts[:output_file]
  if opts[:sourcemap]
    code += "\n/*# sourceMappingURL=#{opts[:output_file]}.map */\n"
    write_sourcemap(opts[:output_file], path, css)
  end
  File.write(opts[:output_file], code)
  if opts[:css_modules]
    json_path = opts[:css_modules_file] || "#{opts[:output_file]}.json"
    File.write(json_path, json_generate(exports))
  end
else
  if opts[:css_modules]
    puts json_generate('code' => '', 'exports' => {})
  else
    puts code
  end
end
