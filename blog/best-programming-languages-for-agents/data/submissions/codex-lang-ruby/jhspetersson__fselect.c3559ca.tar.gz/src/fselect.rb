#!/usr/bin/env ruby
# frozen_string_literal: true

require 'digest'
require 'base64'
require 'etc'
require 'pathname'

ARCHIVE_EXT = %w[7z bz2 bzip2 gz gzip lz rar tar xz zip].freeze
AUDIO_EXT = %w[aac aiff amr flac gsm m4a m4b m4p mp3 ogg wav wma].freeze
BOOK_EXT = %w[azw3 chm djv djvu epub fb2 mobi pdf].freeze
DOC_EXT = %w[accdb doc docm docx dot dotm dotx mdb odp ods odt pdf potm potx ppt pptm pptx rtf xlm xls xlsm xlsx xlt xltm xltx xps].freeze
FONT_EXT = %w[eot fon otc otf ttc ttf woff woff2].freeze
IMAGE_EXT = %w[bmp exr gif heic jpeg jpg jxl png psb psd svg tga tiff webp].freeze
SOURCE_EXT = %w[asm awk bas c cc ceylon clj coffee cpp cs d dart elm erl go gradle groovy h hh hpp java jl js jsp jsx kt kts lua nim pas php pl pm py rb rs scala sol swift tcl ts tsx vala vb zig].freeze
VIDEO_EXT = %w[3gp avi flv m4p m4v mkv mov mp4 mpeg mpg webm wmv].freeze
COLUMN_NAMES = %w[* name filename fname ext extension path abspath dir directory dirname absdir size fsize hsize uid gid user group created accessed modified is_dir is_file is_symlink is_pipe is_fifo is_char is_character is_block is_socket device rdev inode blocks hardlinks atime mtime ctime mode user_read user_write user_exec user_all user_rwx group_read group_write group_exec group_all group_rwx other_read other_write other_exec other_all other_rwx suid is_suid sgid is_sgid is_sticky sticky is_hidden has_xattrs xattr_count extattrs has_extattrs acl has_acl default_acl has_default_acl has_capabilities has_caps capabilities caps is_shebang is_empty width height duration mp3_bitrate bitrate mp3_freq freq mp3_title title mp3_artist artist mp3_album album mp3_year mp3_genre genre mime line_count is_binary is_text is_archive is_audio is_book is_doc is_font is_image is_source is_video sha1 sha2_256 sha256 sha2_512 sha512 sha3_512 sha3].freeze

Token = Struct.new(:text, :quoted)
Root = Struct.new(:path, :mindepth, :maxdepth, :follow, :order)
Row = Struct.new(:root, :rel, :abs, :stat, :lstat)

def help
  puts "fselect \e[33m0.10.0\e[0m"
  puts 'Find files with SQL-like queries.'
  puts "\e[4;36mhttps://github.com/jhspetersson/fselect\e[0m"
  puts
  puts 'Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]'
end

def json_escape(s)
  s.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
    { '"' => '\"', '\\' => '\\\\', "\b" => '\\b', "\f" => '\\f', "\n" => '\\n', "\r" => '\\r', "\t" => '\\t' }[ch]
  end
end

def json_generate_array(objects)
  '[' + objects.map { |h| '{' + h.map { |k, v| "\"#{json_escape(k)}\":\"#{json_escape(v)}\"" }.join(',') + '}' }.join(',') + ']'
end

def csv_line(values)
  values.map do |v|
    s = v.to_s
    s.match?(/[",\n\r]/) ? '"' + s.gsub('"', '""') + '"' : s
  end.join(',')
end

def tokenize(s)
  out = []
  i = 0
  while i < s.length
    c = s[i]
    if c =~ /\s/
      i += 1
    elsif c == "'" || c == '"' || c == '`'
      q = c
      i += 1
      buf = +''
      while i < s.length
        if s[i] == '\\' && i + 1 < s.length
          buf << s[i + 1]
          i += 2
        elsif s[i] == q
          i += 1
          break
        else
          buf << s[i]
          i += 1
        end
      end
      out << Token.new(buf, true)
    elsif '(),{}'.include?(c)
      out << Token.new(c.tr('{}', '()'), false)
      i += 1
    elsif i + 2 < s.length && %w[!== === !=~ !~=].include?(s[i, 3])
      out << Token.new(s[i, 3], false)
      i += 3
    elsif i + 1 < s.length && %w[>= <= != <> == =~ ~=].include?(s[i, 2])
      out << Token.new(s[i, 2], false)
      i += 2
    elsif %w[> < =].include?(c)
      out << Token.new(c, false)
      i += 1
    else
      j = i
      j += 1 while j < s.length && s[j] !~ /[\s(),{}<>!=~]/
      out << Token.new(s[i...j], false)
      i = j
    end
  end
  out
end

def kw?(tok, word)
  tok && !tok.quoted && tok.text.downcase == word
end

def split_top(tokens, sep = ',')
  parts = [[]]
  depth = 0
  tokens.each do |t|
    depth += 1 if t.text == '('
    depth -= 1 if t.text == ')'
    if depth.zero? && t.text == sep
      parts << []
    else
      parts[-1] << t
    end
  end
  parts.map { |p| trim_tokens(p) }.reject(&:empty?)
end

def trim_tokens(a)
  a = a.dup
  a.shift while a.first&.text == ','
  a.pop while a.last&.text == ','
  a
end

def clause_index(tokens, *words)
  depth = 0
  (0...tokens.length).each do |i|
    t = tokens[i]
    depth += 1 if t.text == '('
    depth -= 1 if t.text == ')'
    next unless depth.zero?
    next unless kw?(t, words[0])
    ok = true
    words[1..].each_with_index { |w, j| ok &&= kw?(tokens[i + j + 1], w) }
    return i if ok
  end
  nil
end

def parse_query(argv)
  opts = { color: true, errors: true }
  args = []
  i = 0
  while i < argv.length
    case argv[i]
    when '--help', '-h', '/?', '/h'
      help
      exit 0
    when '--nocolor', '--no-color', '/nocolor'
      opts[:color] = false
    when '--no-errors'
      opts[:errors] = false
    when '--config', '-c', '/config'
      i += 1
    when '--us-dates'
      opts[:us_dates] = true
    when '--interactive', '-i', '/i'
      opts[:interactive] = true
    else
      args << argv[i]
    end
    i += 1
  end
  return [opts, nil] if opts[:interactive]
  q = args.join(' ')
  tokens = tokenize(q)
  tokens.shift if kw?(tokens.first, 'select')
  into_i = clause_index(tokens, 'into')
  fmt = into_i ? tokens[(into_i + 1)..]&.first&.text&.downcase : 'tabs'
  tokens = tokens[0...into_i] if into_i
  limit_i = clause_index(tokens, 'limit')
  limit = limit_i ? tokens[limit_i + 1]&.text&.to_i : nil
  tokens = tokens[0...limit_i] + (tokens[(limit_i + 2)..] || []) if limit_i
  offset_i = clause_index(tokens, 'offset')
  offset = offset_i ? tokens[offset_i + 1]&.text&.to_i : 0
  tokens = tokens[0...offset_i] + (tokens[(offset_i + 2)..] || []) if offset_i
  order_i = clause_index(tokens, 'order', 'by')
  order_tokens = order_i ? tokens[(order_i + 2)..] : []
  tokens = tokens[0...order_i] if order_i
  group_i = clause_index(tokens, 'group', 'by')
  tokens = tokens[0...group_i] if group_i
  where_i = clause_index(tokens, 'where')
  where_tokens = where_i ? tokens[(where_i + 1)..] : []
  tokens = tokens[0...where_i] if where_i
  from_i = clause_index(tokens, 'from')
  col_tokens = from_i ? tokens[0...from_i] : tokens
  root_tokens = from_i ? tokens[(from_i + 1)..] : [Token.new('.', false)]
  cols = split_top(col_tokens)
  if cols.length == 1 && cols[0].length > 1 && cols[0].none? { |t| %w[( )].include?(t.text) }
    cols = cols[0].map { |t| [t] }
  end
  cols = [[Token.new('path', false)]] if cols.empty? || (cols.length == 1 && cols[0].empty?)
  roots = parse_roots(root_tokens)
  orders = parse_order(order_tokens)
  [opts, { columns: cols, roots: roots, where: where_tokens, order: orders, limit: limit, offset: offset, format: fmt }]
end

def parse_roots(tokens)
  split_top(tokens).map do |part|
    path = part.shift&.text || '.'
    root = Root.new(path, 0, nil, false, :bfs)
    i = 0
    while i < part.length
      word = part[i].text.downcase
      case word
      when 'mindepth'
        i += 1
        root.mindepth = part[i]&.text.to_i
      when 'maxdepth', 'depth'
        i += 1
        root.maxdepth = part[i]&.text.to_i
      when 'symlinks', 'sym'
        root.follow = true
      when 'dfs'
        root.order = :dfs
      when 'bfs'
        root.order = :bfs
      when 'as'
        i += 1
      end
      i += 1
    end
    root
  end
end

def parse_order(tokens)
  split_top(tokens).map do |p|
    dir = 'asc'
    if %w[asc desc].include?(p.last&.text&.downcase)
      dir = p.pop.text.downcase
    end
    [p, dir]
  end
end

def mode_string(st)
  type = if st.directory? then 'd' elsif st.symlink? then 'l' elsif st.file? then '-' elsif st.pipe? then 'p' elsif st.socket? then 's' elsif st.chardev? then 'c' elsif st.blockdev? then 'b' else '?' end
  bits = st.mode
  s = +''
  [[0400, 'r'], [0200, 'w'], [0100, 'x'], [0040, 'r'], [0020, 'w'], [0010, 'x'], [0004, 'r'], [0002, 'w'], [0001, 'x']].each { |b, ch| s << ((bits & b).zero? ? '-' : ch) }
  s[2] = (bits & 04000).zero? ? s[2] : (s[2] == 'x' ? 's' : 'S')
  s[5] = (bits & 02000).zero? ? s[5] : (s[5] == 'x' ? 's' : 'S')
  s[8] = (bits & 01000).zero? ? s[8] : (s[8] == 'x' ? 't' : 'T')
  type + s
end

def format_time(t)
  t.localtime.strftime('%Y-%m-%d %H:%M:%S')
end

def human_size(n)
  n = n.to_i
  return "#{n}B" if n < 1024
  units = %w[KiB MiB GiB TiB]
  val = n.to_f
  unit = 'B'
  units.each do |u|
    val /= 1024.0
    unit = u
    break if val < 1024
  end
  format('%.2f%s', val, unit)
end

def ext_of(name)
  e = File.extname(name)
  e.start_with?('.') ? e[1..] : e
end

def base_of(name)
  e = File.extname(name)
  e.empty? ? name : name[0...-e.length]
end

def empty_dir?(path)
  Dir.children(path).empty?
rescue StandardError
  false
end

def text_file?(path)
  data = File.open(path, 'rb') { |f| f.read(4096) } || ''
  return true if data.empty?
  !data.include?("\x00") && data.valid_encoding?
rescue StandardError
  false
end

def line_count(path)
  return '' unless File.file?(path)
  File.foreach(path).count
rescue StandardError
  ''
end

def mime_for(row)
  ext = ext_of(File.basename(row.abs)).downcase
  return 'text/plain' if %w[txt md rb py c h js json yaml yml toml xml html css].include?(ext)
  return 'image/png' if ext == 'png'
  return 'image/jpeg' if %w[jpg jpeg].include?(ext)
  return 'image/gif' if ext == 'gif'
  return 'application/pdf' if ext == 'pdf'
  return 'application/zip' if ext == 'zip'
  text_file?(row.abs) ? 'text/plain' : 'application/octet-stream'
end

def image_size(path)
  File.open(path, 'rb') do |f|
    sig = f.read(24)
    return [sig[16, 4].unpack1('N'), sig[20, 4].unpack1('N')] if sig&.start_with?("\x89PNG\r\n\x1a\n")
    return [sig[6, 2].unpack1('v'), sig[8, 2].unpack1('v')] if sig&.start_with?('GIF')
    if sig&.start_with?("\xff\xd8".b)
      loop do
        b = f.read(1)
        return ['', ''] unless b
        next unless b == "\xff".b
        marker = f.read(1)&.ord
        len = f.read(2)&.unpack1('n')
        return ['', ''] unless marker && len
        if (0xC0..0xC3).include?(marker)
          data = f.read(5)
          return [data[3, 2].unpack1('n'), data[1, 2].unpack1('n')]
        end
        f.seek(len - 2, IO::SEEK_CUR)
      end
    end
  end
  ['', '']
rescue StandardError
  ['', '']
end

def column(row, name)
  n = name.downcase
  name = File.basename(row.abs)
  ext = ext_of(name)
  st = row.lstat
  case n
  when '*'
    row.rel
  when 'name'
    name
  when 'filename', 'fname'
    base_of(name)
  when 'ext', 'extension'
    ext
  when 'path'
    row.rel
  when 'abspath'
    row.abs
  when 'dir', 'directory', 'dirname'
    d = File.dirname(row.rel)
    d == '.' ? '' : d
  when 'absdir'
    File.dirname(row.abs)
  when 'size'
    st.size
  when 'fsize', 'hsize'
    human_size(st.size)
  when 'uid' then st.uid
  when 'gid' then st.gid
  when 'user' then Etc.getpwuid(st.uid).name rescue st.uid
  when 'group' then Etc.getgrgid(st.gid).name rescue st.gid
  when 'created' then format_time(st.ctime)
  when 'accessed' then format_time(st.atime)
  when 'modified' then format_time(st.mtime)
  when 'atime' then st.atime.to_i
  when 'mtime' then st.mtime.to_i
  when 'ctime' then st.ctime.to_i
  when 'mode' then mode_string(st)
  when 'inode' then st.ino
  when 'device' then st.dev
  when 'rdev' then st.rdev
  when 'blocks' then st.blocks rescue ''
  when 'hardlinks' then st.nlink
  when 'is_dir' then st.directory?
  when 'is_file' then st.file?
  when 'is_symlink' then st.symlink?
  when 'is_pipe', 'is_fifo' then st.pipe?
  when 'is_char', 'is_character' then st.chardev?
  when 'is_block' then st.blockdev?
  when 'is_socket' then st.socket?
  when 'is_hidden' then name.start_with?('.')
  when 'is_empty' then st.directory? ? empty_dir?(row.abs) : st.size.zero?
  when 'user_read' then (st.mode & 0400) != 0
  when 'user_write' then (st.mode & 0200) != 0
  when 'user_exec' then (st.mode & 0100) != 0
  when 'user_all', 'user_rwx' then (st.mode & 0700) == 0700
  when 'group_read' then (st.mode & 0040) != 0
  when 'group_write' then (st.mode & 0020) != 0
  when 'group_exec' then (st.mode & 0010) != 0
  when 'group_all', 'group_rwx' then (st.mode & 0070) == 0070
  when 'other_read' then (st.mode & 0004) != 0
  when 'other_write' then (st.mode & 0002) != 0
  when 'other_exec' then (st.mode & 0001) != 0
  when 'other_all', 'other_rwx' then (st.mode & 0007) == 0007
  when 'suid', 'is_suid' then (st.mode & 04000) != 0
  when 'sgid', 'is_sgid' then (st.mode & 02000) != 0
  when 'sticky', 'is_sticky' then (st.mode & 01000) != 0
  when 'is_archive' then ARCHIVE_EXT.include?(ext.downcase)
  when 'is_audio' then AUDIO_EXT.include?(ext.downcase)
  when 'is_book' then BOOK_EXT.include?(ext.downcase)
  when 'is_doc' then DOC_EXT.include?(ext.downcase)
  when 'is_font' then FONT_EXT.include?(ext.downcase)
  when 'is_image' then IMAGE_EXT.include?(ext.downcase)
  when 'is_source' then SOURCE_EXT.include?(ext.downcase)
  when 'is_video' then VIDEO_EXT.include?(ext.downcase)
  when 'mime' then mime_for(row)
  when 'is_text' then text_file?(row.abs)
  when 'is_binary' then !text_file?(row.abs)
  when 'line_count' then line_count(row.abs)
  when 'is_shebang' then File.file?(row.abs) && File.open(row.abs, 'rb') { |f| f.read(2) } == '#!' rescue false
  when 'sha1' then File.file?(row.abs) ? Digest::SHA1.file(row.abs).hexdigest : ''
  when 'sha2_256', 'sha256' then File.file?(row.abs) ? Digest::SHA256.file(row.abs).hexdigest : ''
  when 'sha2_512', 'sha512' then File.file?(row.abs) ? Digest::SHA512.file(row.abs).hexdigest : ''
  when 'width' then image_size(row.abs)[0]
  when 'height' then image_size(row.abs)[1]
  else
    ''
  end
end

def literal_value(tok)
  s = tok.text
  return s if tok.quoted
  return true if s.downcase == 'true'
  return false if s.downcase == 'false'
  return nil if s.downcase == 'null'
  return s.to_i if s =~ /\A-?\d+\z/
  return s.to_f if s =~ /\A-?\d+\.\d+\z/
  if s =~ /\A(-?\d+)([a-zA-Z]+)\z/
    mult = { 'k' => 1024, 'kib' => 1024, 'kb' => 1000, 'm' => 1024**2, 'mib' => 1024**2, 'mb' => 1000**2, 'g' => 1024**3, 'gib' => 1024**3, 'gb' => 1000**3, 't' => 1024**4, 'tib' => 1024**4, 'tb' => 1000**4 }[$2.downcase]
    return $1.to_i * mult if mult
  end
  s
end

def eval_expr(tokens, row)
  tokens = trim_tokens(tokens)
  return '' if tokens.empty?
  return eval_expr(tokens[1...-1], row) if tokens.first&.text == '(' && tokens.last&.text == ')' && balanced_wrap?(tokens)
  if tokens.length == 1
    t = tokens[0]
    return literal_value(t) if t.quoted || t.text =~ /\A-?\d/ || %w[true false null].include?(t.text.downcase)
    return column(row, t.text)
  end
  if tokens.length >= 3 && tokens[1].text == '(' && tokens.last.text == ')'
    fname = tokens[0].text.downcase
    args = split_top(tokens[2...-1]).map { |a| eval_expr(a, row) }
    return call_func(fname, args, row)
  end
  %w[+ - * / % plus minus mul div mod].each do |op|
    idx = top_op(tokens, op)
    next unless idx
    a = eval_expr(tokens[0...idx], row)
    b = eval_expr(tokens[(idx + 1)..], row)
    return arithmetic(a, tokens[idx].text, b)
  end
  tokens.map { |t| eval_expr([t], row).to_s }.join(' ')
end

def eval_rhs(tokens, row)
  tokens = trim_tokens(tokens)
  if tokens.length == 1
    t = tokens[0]
    return eval_expr(tokens, row) if t.quoted || t.text =~ /\A-?\d/ || %w[true false null].include?(t.text.downcase)
    return eval_expr(tokens, row) if COLUMN_NAMES.include?(t.text.downcase)
    return literal_value(t)
  end
  eval_expr(tokens, row)
end

def balanced_wrap?(tokens)
  d = 0
  tokens.each_with_index do |t, i|
    d += 1 if t.text == '('
    d -= 1 if t.text == ')'
    return false if d.zero? && i < tokens.length - 1
  end
  d.zero?
end

def top_op(tokens, op)
  d = 0
  (tokens.length - 1).downto(0) do |i|
    t = tokens[i]
    d -= 1 if t.text == ')'
    d += 1 if t.text == '('
    return i if d.zero? && t.text.downcase == op
  end
  nil
end

def arithmetic(a, op, b)
  x = a.to_f
  y = b.to_f
  r = case op.downcase
      when '+', 'plus' then x + y
      when '-', 'minus' then x - y
      when '*', 'mul' then x * y
      when '/', 'div' then y.zero? ? 0 : x / y
      when '%', 'mod' then y.zero? ? 0 : x % y
      end
  r == r.to_i ? r.to_i : r
end

def call_func(fname, args, row)
  case fname
  when 'lower', 'lowercase', 'lcase' then args[0].to_s.downcase
  when 'upper', 'uppercase', 'ucase' then args[0].to_s.upcase
  when 'initcap' then args[0].to_s.split(/\b/).map(&:capitalize).join
  when 'length', 'len' then args[0].to_s.length
  when 'to_base64', 'base64' then Base64.strict_encode64(args[0].to_s)
  when 'from_base64' then Base64.decode64(args[0].to_s)
  when 'concat' then args.join
  when 'concat_ws' then args[1..].join(args[0].to_s)
  when 'locate', 'position' then ((args[0].to_s.index(args[1].to_s, (args[2] || 1).to_i - 1) || -1) + 1)
  when 'substr', 'substring'
    s = args[0].to_s
    pos = args[1].to_i
    start = pos.negative? ? s.length + pos : pos - 1
    args[2] ? s[start, args[2].to_i].to_s : s[start..].to_s
  when 'replace' then args[0].to_s.gsub(args[1].to_s, args[2].to_s)
  when 'trim' then args[0].to_s.strip
  when 'ltrim' then args[0].to_s.lstrip
  when 'rtrim' then args[0].to_s.rstrip
  when 'bin' then args[0].to_i.to_s(2)
  when 'hex' then args[0].to_i.to_s(16)
  when 'oct' then args[0].to_i.to_s(8)
  when 'abs' then args[0].to_f.abs
  when 'power', 'pow' then args[0].to_f**args[1].to_f
  when 'sqrt' then Math.sqrt(args[0].to_f)
  when 'log' then args[1] ? Math.log(args[0].to_f, args[1].to_f) : Math.log10(args[0].to_f)
  when 'ln' then Math.log(args[0].to_f)
  when 'exp' then Math.exp(args[0].to_f)
  when 'least' then args.min
  when 'greatest' then args.max
  when 'pi' then Math::PI
  when 'floor' then args[0].to_f.floor
  when 'ceil', 'ceiling' then args[0].to_f.ceil
  when 'round' then args[1] ? args[0].to_f.round(args[1].to_i) : args[0].to_f.round
  when 'current_date', 'cur_date', 'curdate' then Time.now.strftime('%Y-%m-%d')
  when 'current_time', 'cur_time', 'curtime' then Time.now.strftime('%H:%M:%S')
  when 'current_timestamp', 'now' then Time.now.strftime('%Y-%m-%d %H:%M:%S')
  when 'day' then parse_time(args[0])&.day || ''
  when 'month' then parse_time(args[0])&.month || ''
  when 'year' then parse_time(args[0])&.year || ''
  when 'dayofweek', 'dow' then ((parse_time(args[0])&.wday || 0) + 1)
  when 'dayname' then parse_time(args[0])&.strftime('%A') || ''
  when 'dayofyear', 'doy' then parse_time(args[0])&.yday || ''
  when 'from_unixtime' then Time.at(args[0].to_i).strftime('%Y-%m-%d %H:%M:%S')
  when 'format_size', 'format_filesize' then human_size(args[0].to_i)
  when 'format_time', 'pretty_time' then pretty_duration(args[0].to_i)
  when 'current_uid' then Process.uid
  when 'current_gid' then Process.gid
  when 'current_user' then Etc.getpwuid(Process.uid).name
  when 'current_group' then Etc.getgrgid(Process.gid).name
  when 'contains' then File.file?(row.abs) && File.read(row.abs).include?(args[0].to_s) rescue false
  when 'coalesce' then args.find { |a| !a.nil? && a.to_s != '' } || ''
  when 'random', 'rand'
    if args.length >= 2 then rand(args[0].to_i..args[1].to_i)
    elsif args.length == 1 then rand(args[0].to_i)
    else rand(2**31)
    end
  else
    ''
  end
end

def pretty_duration(sec)
  m, s = sec.divmod(60)
  h, m = m.divmod(60)
  d, h = h.divmod(24)
  [[d, 'd'], [h, 'h'], [m, 'min'], [s, 's']].select { |v, _| v.positive? }.map { |v, u| "#{v}#{u}" }.join(' ')
end

def parse_time(v)
  return Time.at(v) if v.is_a?(Numeric)
  s = v.to_s
  if s =~ /\A(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{1,2})(?::(\d{1,2})(?::(\d{1,2}))?)?)?/
    Time.local($1.to_i, $2.to_i, $3.to_i, ($4 || 0).to_i, ($5 || 0).to_i, ($6 || 0).to_i)
  else
    nil
  end
rescue StandardError
  nil
end

def eval_where(tokens, row)
  tokens = trim_tokens(tokens)
  return true if tokens.empty?
  return eval_where(tokens[1...-1], row) if tokens.first&.text == '(' && tokens.last&.text == ')' && balanced_wrap?(tokens)
  idx = top_logic(tokens, 'or')
  return eval_where(tokens[0...idx], row) || eval_where(tokens[(idx + 1)..], row) if idx
  idx = top_logic(tokens, 'and')
  return eval_where(tokens[0...idx], row) && eval_where(tokens[(idx + 1)..], row) if idx
  return truthy(eval_expr(tokens, row)) if tokens.length == 1
  opi = predicate_op(tokens)
  return truthy(eval_expr(tokens, row)) unless opi
  lhs = eval_expr(tokens[0...opi], row)
  op = tokens[opi].text.downcase
  if op == 'not' && tokens[opi + 1]&.text&.downcase == 'like'
    op = 'notlike'
    rhs_tokens = tokens[(opi + 2)..]
  elsif op == 'not' && tokens[opi + 1]&.text&.downcase == 'in'
    vals = split_top(tokens[(opi + 3)...-1] || []).map { |a| eval_rhs(a, row) }
    return !vals.map(&:to_s).include?(lhs.to_s)
  elsif op == 'between'
    and_i = top_logic(tokens[(opi + 1)..], 'and')
    low = eval_rhs(tokens[(opi + 1)...(opi + 1 + and_i)], row)
    high = eval_rhs(tokens[(opi + 2 + and_i)..], row)
    return compare(lhs, '>=', low) && compare(lhs, '<=', high)
  elsif op == 'in'
    vals = split_top(tokens[(opi + 2)...-1] || []).map { |a| eval_rhs(a, row) }
    return vals.map(&:to_s).include?(lhs.to_s)
  else
    rhs_tokens = tokens[(opi + 1)..]
  end
  rhs = eval_rhs(rhs_tokens, row)
  compare(lhs, op, rhs)
end

def top_logic(tokens, word)
  d = 0
  (tokens.length - 1).downto(0) do |i|
    t = tokens[i]
    d -= 1 if t.text == ')'
    d += 1 if t.text == '('
    return i if d.zero? && kw?(t, word)
  end
  nil
end

def predicate_op(tokens)
  ops = %w[= == eq === eeq != <> ne !== ene < lt <= lte le > gt >= gte ge =~ ~= regexp rx !=~ !~= notrx like notlike between in not]
  d = 0
  tokens.each_with_index do |t, i|
    d += 1 if t.text == '('
    d -= 1 if t.text == ')'
    return i if d.zero? && ops.include?(t.text.downcase)
  end
  nil
end

def truthy(v)
  return v if v == true || v == false
  return false if v.nil?
  return false if v.to_s.empty?
  return false if %w[false 0].include?(v.to_s.downcase)
  true
end

def compare(a, op, b)
  case op
  when '=', '==', 'eq'
    wildcard?(b) ? File.fnmatch?(b.to_s, a.to_s, File::FNM_CASEFOLD) : cmp_eq(a, b)
  when '===', 'eeq'
    a.to_s == b.to_s
  when '!=', '<>', 'ne'
    wildcard?(b) ? !File.fnmatch?(b.to_s, a.to_s, File::FNM_CASEFOLD) : !cmp_eq(a, b)
  when '!==', 'ene'
    a.to_s != b.to_s
  when '<', 'lt' then numericish(a, b) ? a.to_f < b.to_f : a.to_s < b.to_s
  when '<=', 'lte', 'le' then numericish(a, b) ? a.to_f <= b.to_f : a.to_s <= b.to_s
  when '>', 'gt' then numericish(a, b) ? a.to_f > b.to_f : a.to_s > b.to_s
  when '>=', 'gte', 'ge' then numericish(a, b) ? a.to_f >= b.to_f : a.to_s >= b.to_s
  when '=~', '~=', 'regexp', 'rx' then !!(a.to_s =~ Regexp.new(b.to_s))
  when '!=~', '!~=', 'notrx' then !(a.to_s =~ Regexp.new(b.to_s))
  when 'like' then like_match?(a.to_s, b.to_s)
  when 'notlike' then !like_match?(a.to_s, b.to_s)
  else false
  end
rescue StandardError
  false
end

def wildcard?(v)
  v.to_s.match?(/[*?\[]/)
end

def cmp_eq(a, b)
  if a == true || a == false || b == true || b == false
    truthy(a) == truthy(b)
  elsif numericish(a, b)
    a.to_f == b.to_f
  else
    a.to_s == b.to_s
  end
end

def numericish(a, b)
  a.is_a?(Numeric) || b.is_a?(Numeric) || (a.to_s =~ /\A-?\d+(\.\d+)?\z/ && b.to_s =~ /\A-?\d+(\.\d+)?\z/)
end

def like_match?(s, pat)
  re = Regexp.escape(pat).gsub('%', '.*').gsub('_', '.')
  !!(s =~ /\A#{re}\z/i)
end

def traverse(root)
  base = File.expand_path(root.path)
  rows = []
  queue = Dir.children(base).sort.map { |c| [File.join(base, c), 1] }
  until queue.empty?
    begin
      path, depth = root.order == :dfs ? queue.pop : queue.shift
      next if root.maxdepth && depth > root.maxdepth
      lstat = File.lstat(path)
      st = root.follow && lstat.symlink? ? File.stat(path) : lstat
      rel = Pathname.new(path).relative_path_from(Pathname.new(base)).to_s
      rows << Row.new(base, rel, path, st, lstat) if depth >= root.mindepth
      if st.directory? && (!lstat.symlink? || root.follow)
        kids = Dir.children(path).sort.map { |c| [File.join(path, c), depth + 1] }
        root.order == :dfs ? queue.concat(kids.reverse) : queue.concat(kids)
      end
    rescue SystemCallError
      next
    end
  end
  rows
rescue SystemCallError
  []
end

def label_for(tokens)
  s = tokens.map(&:text).join
  s = s.gsub(/[^A-Za-z0-9]+/, ' ').split.map(&:capitalize).join
  s.empty? ? 'Value' : s
end

def aggregate?(cols)
  cols.any? { |c| c.first && %w[min max avg sum count stddev_pop stddev std stddev_samp var_pop variance var_samp].include?(c.first.text.downcase) }
end

def compute_aggregates(cols, rows)
  dummy = rows.first
  cols.map do |c|
    fname = c.first.text.downcase
    inner = c[2...-1] || []
    vals = rows.map { |r| eval_expr(inner, r) }.reject { |v| v.nil? || v.to_s.empty? }
    nums = vals.map(&:to_f)
    case fname
    when 'count' then vals.length
    when 'sum' then nums.sum.to_i == nums.sum ? nums.sum.to_i : nums.sum
    when 'min' then vals.min
    when 'max' then vals.max
    when 'avg' then nums.empty? ? '' : nums.sum / nums.length
    when 'stddev_pop', 'stddev', 'std'
      next '' if nums.empty?
      m = nums.sum / nums.length
      Math.sqrt(nums.map { |x| (x - m)**2 }.sum / nums.length)
    when 'stddev_samp'
      next '' if nums.length < 2
      m = nums.sum / nums.length
      Math.sqrt(nums.map { |x| (x - m)**2 }.sum / (nums.length - 1))
    when 'var_pop', 'variance'
      next '' if nums.empty?
      m = nums.sum / nums.length
      nums.map { |x| (x - m)**2 }.sum / nums.length
    when 'var_samp'
      next '' if nums.length < 2
      m = nums.sum / nums.length
      nums.map { |x| (x - m)**2 }.sum / (nums.length - 1)
    else ''
    end
  end
end

def stringify(v)
  case v
  when true then 'true'
  when false then 'false'
  when Float
    v.nan? ? '' : (v == v.to_i ? v.to_i.to_s : v.to_s)
  else v.to_s
  end
end

def output(rows, cols, fmt)
  vals = rows.map { |r| cols.map { |c| stringify(eval_expr(c, r)) } }
  case fmt
  when 'csv'
    vals.each { |v| puts csv_line(v) }
  when 'json'
    labels = cols.map { |c| label_for(c) }
    puts json_generate_array(vals.map { |v| labels.zip(v).sort.to_h })
  when 'html'
    labels = cols.map { |c| label_for(c) }
    puts '<!DOCTYPE html><html><body><table>'
    puts '<tr>' + labels.map { |l| "<th>#{l}</th>" }.join + '</tr>'
    vals.each { |v| puts '<tr>' + v.map { |x| "<td>#{x}</td>" }.join + '</tr>' }
    puts '</table></body></html>'
  when 'lines'
    vals.each { |v| v.each { |x| puts x } }
  when 'list'
    print vals.flatten.join("\0")
    print "\0" unless vals.empty?
  else
    vals.each { |v| puts v.join("\t") }
  end
end

def repl
  loop do
    print '> '
    line = STDIN.gets
    break unless line
    line = line.strip
    break if %w[exit quit].include?(line.downcase)
    if line.downcase == 'pwd'
      puts Dir.pwd
      next
    elsif line.downcase.start_with?('cd ')
      Dir.chdir(line[3..].strip)
      next
    elsif line.downcase == 'help'
      help
      next
    end
    begin
      _opts, q = parse_query([line])
      rows = q[:roots].flat_map { |r| traverse(r) }.select { |row| eval_where(q[:where], row) }
      output(apply_order_limit(rows, q), q[:columns], q[:format])
    rescue StandardError => e
      warn e.message
    end
  end
end

def apply_order_limit(rows, q)
  unless q[:order].empty?
    rows = rows.sort do |a, b|
      result = 0
      q[:order].each do |expr, dir|
        va = expr.length == 1 && expr[0].text =~ /\A\d+\z/ ? eval_expr(q[:columns][expr[0].text.to_i - 1] || q[:columns][0], a) : eval_expr(expr, a)
        vb = expr.length == 1 && expr[0].text =~ /\A\d+\z/ ? eval_expr(q[:columns][expr[0].text.to_i - 1] || q[:columns][0], b) : eval_expr(expr, b)
        result = numericish(va, vb) ? (va.to_f <=> vb.to_f) : (va.to_s <=> vb.to_s)
        result = -result if dir == 'desc'
        break unless result.zero?
      end
      result
    end
  end
  rows = rows.drop(q[:offset] || 0)
  rows = rows.first(q[:limit]) if q[:limit]
  rows
end

begin
  opts, query = parse_query(ARGV)
  if opts[:interactive]
    repl
    exit 0
  end
  rows = query[:roots].flat_map { |r| traverse(r) }
  rows = rows.select { |row| eval_where(query[:where], row) }
  if aggregate?(query[:columns])
    values = compute_aggregates(query[:columns], rows)
    fake = Struct.new(:vals).new(values)
    def fake_value(fake, idx) = fake.vals[idx]
    vals = [values.map { |v| stringify(v) }]
    case query[:format]
    when 'json'
      labels = query[:columns].map { |c| label_for(c) }
      puts json_generate_array([labels.zip(vals[0]).sort.to_h])
    when 'csv'
      puts csv_line(vals[0])
    when 'lines'
      vals[0].each { |x| puts x }
    when 'list'
      print vals[0].join("\0")
      print "\0"
    else
      puts vals[0].join("\t")
    end
  else
    output(apply_order_limit(rows, query), query[:columns], query[:format])
  end
rescue StandardError => e
  warn "Error: #{e.message}"
  exit 2
end
