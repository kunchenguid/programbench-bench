#!/usr/bin/env ruby
# frozen_string_literal: true

RESET = "\e[0m"
VERSION = "diffr 0.1.5"

HELP_LONG = <<~TEXT.chomp
  diffr 0.1.5
  Nathan Moreau <nathan.moreau@m4x.org>

  diffr adds word-level diff on top of unified diffs.
  word-level diff information is displayed using text attributes.

  USAGE:
      diffr reads from standard input and writes to standard output.

      Typical usage is for interactive use of diff:
      diff -u <file1> <file2> | diffr
      git show | diffr

  OPTIONS:
          --colors <COLOR_SPEC>...
              Configure color settings for console ouput.

              There are four faces to customize:
              +----------------+--------------+----------------+
              |  line prefix   |      +       |       -        |
              +----------------+--------------+----------------+
              | common segment |    added     |    removed     |
              | unique segment | refine-added | refine-removed |
              +----------------+--------------+----------------+

              The customization allows
              - to change the foreground or background color;
              - to set or unset the attributes 'bold', 'intense', 'underline';
              - to clear all attributes.

              Customization is done passing a color_spec argument.
              This flag may be provided multiple times.

              The syntax is the following:

              color_spec = face-name + ':' + attributes
              attributes = attribute
                         | attribute + ':' + attributes
              attribute  = ('foreground' | 'background') + ':' + color
                         | (<empty> | 'no') + font-flag
                         | 'none'
              font-flag  = 'italic'
                         | 'bold'
                         | 'intense'
                         | 'underline'
              color      = 'none'
                         | [0-255]
                         | [0-255] + ',' + [0-255] + ',' + [0-255]
                         | ('black', 'blue', 'green', 'red',
                            'cyan', 'magenta', 'yellow', 'white')

              For example, the color_spec

                  'refine-added:background:blue:bold'

              sets the color of unique added segments with
              a blue background, written with a bold font.

          --line-numbers <compact|aligned>
              Display line numbers. Style is optional.
              When style = 'compact', take as little width as possible.
              When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]

      -h, --help
              Prints help information

      -V, --version
              Prints version information
TEXT

HELP_SHORT = <<~TEXT.chomp
  diffr 0.1.5
  Nathan Moreau <nathan.moreau@m4x.org>

  diffr adds word-level diff on top of unified diffs.
  word-level diff information is displayed using text attributes.

  USAGE:
      diffr reads from standard input and writes to standard output.

      Typical usage is for interactive use of diff:
      diff -u <file1> <file2> | diffr
      git show | diffr

  OPTIONS:
          --colors <COLOR_SPEC>...    Configure color settings.
          --line-numbers              Display line numbers.
      -h, --help                      Prints help information
      -V, --version                   Prints version information
TEXT

class Face
  attr_accessor :bold, :intense, :italic, :underline, :fg, :bg

  def initialize(fg: nil, bg: nil, bold: false, intense: false, italic: false, underline: false)
    @fg = fg
    @bg = bg
    @bold = bold
    @intense = intense
    @italic = italic
    @underline = underline
  end

  def ansi
    parts = []
    parts << "1" if @bold || @intense
    parts << "3" if @italic
    parts << "4" if @underline
    parts << color_code(@fg, false) if @fg
    parts << color_code(@bg, true) if @bg
    parts.map { |p| "\e[#{p}m" }.join
  end

  def color_code(value, background)
    return nil if value == :none
    base = background ? 40 : 30
    if value.is_a?(Integer)
      "38;5;#{value}".sub(/^38/, background ? "48" : "38")
    elsif value.is_a?(Array)
      "#{background ? 48 : 38};2;#{value.join(';')}"
    else
      names = { black: 0, red: 1, green: 2, yellow: 3, blue: 4, magenta: 5, cyan: 6, white: 7 }
      (base + names.fetch(value)).to_s
    end
  end

  def clear!
    @fg = @bg = nil
    @bold = @intense = @italic = @underline = false
  end
end

def default_faces
  {
    "removed" => Face.new(fg: :red),
    "added" => Face.new(fg: :green),
    "refine-removed" => Face.new(fg: [255, 255, 255], bg: :red, bold: true),
    "refine-added" => Face.new(fg: [255, 255, 255], bg: :green, bold: true)
  }
end

def die(message)
  warn message
  exit 255
end

def parse_color(v)
  return :none if v == "none"
  names = %w[black blue green red cyan magenta yellow white]
  return v.to_sym if names.include?(v)
  if v =~ /^\d+$/
    n = v.to_i
    return n if n.between?(0, 255)
  end
  if v =~ /^\d+,\d+,\d+$/
    a = v.split(",").map(&:to_i)
    return a if a.all? { |n| n.between?(0, 255) }
  end
  die "unexpected color: #{v}"
end

def apply_color_spec(faces, spec)
  face, rest = spec.split(":", 2)
  unless faces.key?(face)
    die "unexpected face name: got '#{face}', expected added|refine-added|removed|refine-removed"
  end
  die "missing attributes for color spec: #{spec}" if rest.nil? || rest.empty?
  tokens = rest.split(":")
  i = 0
  while i < tokens.length
    tok = tokens[i]
    case tok
    when "none"
      faces[face].clear!
    when "foreground", "background"
      die "missing color for #{tok}" if i + 1 >= tokens.length
      color = parse_color(tokens[i + 1])
      tok == "foreground" ? faces[face].fg = color : faces[face].bg = color
      i += 1
    when "bold", "intense", "italic", "underline"
      faces[face].public_send("#{tok}=", true)
    when "nobold", "nointense", "noitalic", "nounderline"
      faces[face].public_send("#{tok[2..]}=", false)
    else
      die "unexpected attribute: #{tok}"
    end
    i += 1
  end
end

def parse_args(argv, faces)
  opts = { line_numbers: nil }
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when "-h"
      puts HELP_SHORT
      exit 0
    when "--help"
      puts HELP_LONG
      exit 0
    when "-V", "--version"
      puts VERSION
      exit 0
    when "--colors"
      i += 1
      die "missing color spec" if i >= argv.length
      while i < argv.length && !argv[i].start_with?("-")
        apply_color_spec(faces, argv[i])
        break if i + 1 >= argv.length || argv[i + 1].start_with?("-")
        i += 1
      end
    when "--line-numbers"
      style = "compact"
      if i + 1 < argv.length && !argv[i + 1].start_with?("-")
        style = argv[i + 1]
        i += 1
      end
      unless %w[compact aligned fixed].include?(style)
        die "unexpected line number style: got '#{style}', expected aligned|compact|fixed"
      end
      opts[:line_numbers] = style
    else
      warn "bad argument: '#{arg}'"
      puts HELP_SHORT
      exit 2
    end
    i += 1
  end
  opts
end

def tokens(s)
  s.scan(/[[:alnum:]_]+|[[:space:]]+|./m)
end

def lcs_mask(a, b)
  n = a.length
  m = b.length
  dp = Array.new(n + 1) { Array.new(m + 1, 0) }
  (n - 1).downto(0) do |i|
    (m - 1).downto(0) do |j|
      dp[i][j] = if a[i] == b[j]
                   dp[i + 1][j + 1] + 1
                 else
                   [dp[i + 1][j], dp[i][j + 1]].max
                 end
    end
  end
  ma = Array.new(n, false)
  mb = Array.new(m, false)
  i = j = 0
  while i < n && j < m
    if a[i] == b[j]
      ma[i] = mb[j] = true
      i += 1
      j += 1
    elsif dp[i + 1][j] >= dp[i][j + 1]
      i += 1
    else
      j += 1
    end
  end
  [ma, mb]
end

def similarity(a, b)
  ta = tokens(a).reject { |t| t =~ /\A\s+\z/ }
  tb = tokens(b).reject { |t| t =~ /\A\s+\z/ }
  return 0.0 if ta.empty? && tb.empty?
  ma, = lcs_mask(ta, tb)
  (2.0 * ma.count(true)) / (ta.length + tb.length)
end

def align_lines(removed, added)
  n = removed.length
  m = added.length
  dp = Array.new(n + 1) { Array.new(m + 1, 0.0) }
  act = Array.new(n + 1) { Array.new(m + 1) }
  (1..n).each { |i| dp[i][0] = dp[i - 1][0] - 0.45; act[i][0] = :del }
  (1..m).each { |j| dp[0][j] = dp[0][j - 1] - 0.45; act[0][j] = :ins }
  (1..n).each do |i|
    (1..m).each do |j|
      sim = similarity(removed[i - 1][:text], added[j - 1][:text])
      sub = dp[i - 1][j - 1] + (sim > 0.15 ? sim : -0.35)
      del = dp[i - 1][j] - 0.45
      ins = dp[i][j - 1] - 0.45
      best = [[sub, :sub], [del, :del], [ins, :ins]].max_by(&:first)
      dp[i][j], act[i][j] = best
    end
  end
  pairs = []
  i = n
  j = m
  while i > 0 || j > 0
    case act[i][j]
    when :sub
      pairs << [i - 1, j - 1]
      i -= 1
      j -= 1
    when :del
      pairs << [i - 1, nil]
      i -= 1
    else
      pairs << [nil, j - 1]
      j -= 1
    end
  end
  pairs.reverse
end

def emit_segments(text, base_face, refine_face, mask)
  ts = tokens(text)
  out = +""
  current = nil
  ts.each_with_index do |tok, idx|
    refine = mask && !mask[idx]
    face = refine ? refine_face : base_face
    if current != face
      out << RESET unless current.nil?
      out << face.ansi
      current = face
    end
    out << tok
  end
  out << RESET unless current.nil?
  out
end

def render_change(item, sign, faces, pair_text = nil)
  base = sign == "-" ? faces["removed"] : faces["added"]
  refine = sign == "-" ? faces["refine-removed"] : faces["refine-added"]
  if pair_text
    a = tokens(item[:text])
    b = tokens(pair_text)
    ma, mb = lcs_mask(a, b)
    mask = sign == "-" ? ma : mb
  else
    mask = Array.new(tokens(item[:text]).length, false)
  end
  numbered = item[:num_prefix] ? "#{base.ansi}#{item[:num_prefix]}#{RESET}#{item[:num_sep]}" : ""
  RESET + numbered + base.ansi + sign + RESET + RESET +
    emit_segments(item[:text], base, refine, mask)
end

def parse_hunk(line)
  if line =~ /^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/
    [$1.to_i, $3.to_i]
  end
end

def number_prefix(oldn, newn, kind, style, fixed_width = false)
  return nil unless style
  if style == "fixed"
    w = 3
    case kind
    when :removed then "#{oldn.to_s.rjust(w)}    "
    when :added then "#{' ' * w} #{newn.to_s.rjust(w)}"
    else "#{oldn.to_s.rjust(w)} #{newn.to_s.rjust(w)}"
    end
  else
    old_s = oldn ? oldn.to_s : ""
    new_s = newn ? newn.to_s : ""
    w1 = [old_s.length, 2].max
    w2 = [new_s.length, 2].max
    case kind
    when :removed then "#{old_s.rjust(w1)} #{''.rjust(w2)}"
    when :added then "#{''.rjust(w1)} #{new_s.rjust(w2)}"
    else "#{old_s.rjust(w1)} #{new_s.rjust(w2)}"
    end
  end
end

def print_plain(line, opts)
  puts RESET + line + RESET
end

def flush_block(block, faces)
  removed = block.select { |x| x[:kind] == :removed }
  added = block.select { |x| x[:kind] == :added }
  pairs = align_lines(removed, added)
  rmatch = {}
  amatch = {}
  pairs.each do |ri, ai|
    if !ri.nil? && !ai.nil?
      rmatch[removed[ri].object_id] = added[ai][:text]
      amatch[added[ai].object_id] = removed[ri][:text]
    end
  end
  block.each do |entry|
    if entry[:kind] == :removed
      puts render_change(entry, "-", faces, rmatch[entry.object_id])
    else
      puts render_change(entry, "+", faces, amatch[entry.object_id])
    end
  end
end

faces = default_faces
opts = parse_args(ARGV, faces)
line_style = opts[:line_numbers]
old_line = new_line = nil
block = []

STDIN.each_line(chomp: true) do |line|
  hunk = parse_hunk(line)
  if hunk
    flush_block(block, faces)
    block = []
    old_line, new_line = hunk
    print_plain(line, opts)
    next
  end

  if line.start_with?("-") && !line.start_with?("---")
    num = number_prefix(old_line, nil, :removed, line_style)
    block << { kind: :removed, text: line[1..] || "", old: old_line, new: nil, num_prefix: num, num_sep: line_style == "aligned" && num ? "\t" : "" }
    old_line += 1 if old_line
  elsif line.start_with?("+") && !line.start_with?("+++")
    num = number_prefix(nil, new_line, :added, line_style)
    block << { kind: :added, text: line[1..] || "", old: nil, new: new_line, num_prefix: num, num_sep: line_style == "aligned" && num ? "\t" : "" }
    new_line += 1 if new_line
  else
    flush_block(block, faces)
    block = []
    if line.start_with?(" ") && old_line && new_line
      prefix = number_prefix(old_line, new_line, :context, line_style)
      sep = line_style == "aligned" && prefix ? "\t" : ""
      puts "#{prefix}#{sep}#{RESET}#{line}#{RESET}"
      old_line += 1
      new_line += 1
    else
      print_plain(line, opts)
    end
  end
end
flush_block(block, faces)
