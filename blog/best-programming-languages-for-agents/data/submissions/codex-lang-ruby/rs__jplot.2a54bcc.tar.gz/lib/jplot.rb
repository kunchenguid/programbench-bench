#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require 'json'
require 'net/http'
require 'uri'

ESC = "\e"

USAGE = "Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:\n" \
        "\n" \
        "OPTIONS:\n" \
        "  -interval duration\n" \
        "    \tWhen url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)\n" \
        "  -rows int\n" \
        "    \tLimits the height of the graph output.\n" \
        "  -steps int\n" \
        "    \tNumber of values to plot. (default 100)\n" \
        "  -url string\n" \
        "    \tURL to fetch every second. Read JSON objects from stdin if not specified.\n" \
        "\n" \
        "FIELD_SPEC: [<option>[,<option>...]:]path\n" \
        "  option:\n" \
        "    - counter: Computes the difference with the last value. The value must increase monotonically.\n" \
        "    - marker: When the value is none-zero, a vertical line is drawn.\n" \
        "  path:\n" \
        "    JSON field path (eg: field.sub-field).\n"

def duration?(s)
  /\A(?:\d+(?:\.\d+)?(?:ns|us|µs|ms|s|m|h))+\z/.match?(s)
end

def parse_duration_seconds(s)
  total = 0.0
  s.scan(/(\d+(?:\.\d+)?)(ns|us|µs|ms|s|m|h)/) do |num, unit|
    n = num.to_f
    total += case unit
             when 'ns' then n / 1_000_000_000.0
             when 'us', 'µs' then n / 1_000_000.0
             when 'ms' then n / 1_000.0
             when 's' then n
             when 'm' then n * 60.0
             when 'h' then n * 3600.0
             else 0.0
             end
  end
  total
end

def usage_prefix
  ENV['TERM_PROGRAM'] == 'iTerm.app' ? '' : "#{ESC}[c"
end

def print_usage
  $stderr.print usage_prefix
  $stderr.print USAGE
end

def flag_error(message)
  $stderr.print usage_prefix
  $stderr.puts message
  $stderr.print USAGE
  exit 2
end

def parse_flags(argv)
  opts = { interval: '1s', rows: 0, steps: 100, url: nil }
  fields = []
  i = 0
  while i < argv.length
    arg = argv[i]
    if arg == '-h' || arg == '--help'
      print_usage
      exit 0
    elsif arg == '--'
      fields = argv[(i + 1)..] || []
      break
    elsif arg.start_with?('-') && arg != '-'
      name, value = if arg.include?('=')
                      arg.split('=', 2)
                    else
                      [arg, nil]
                    end
      name = name.sub(/\A--/, '-')
      case name
      when '-rows', '-steps', '-interval', '-url'
        if value.nil?
          i += 1
          flag_error("flag needs an argument: #{name}") if i >= argv.length
          value = argv[i]
        end
        case name
        when '-rows'
          flag_error(%(invalid value "#{value}" for flag -rows: parse error)) unless /\A-?\d+\z/.match?(value)
          opts[:rows] = value.to_i
        when '-steps'
          flag_error(%(invalid value "#{value}" for flag -steps: parse error)) unless /\A-?\d+\z/.match?(value)
          opts[:steps] = value.to_i
        when '-interval'
          flag_error(%(invalid value "#{value}" for flag -interval: parse error)) unless duration?(value)
          opts[:interval] = value
        when '-url'
          opts[:url] = value
        end
      else
        flag_error("flag provided but not defined: #{name}")
      end
    else
      fields = argv[i..] || []
      break
    end
    i += 1
  end
  [opts, fields]
end

class SeriesSpec
  attr_reader :path, :counter, :marker, :label

  def initialize(raw)
    opts = []
    path = raw
    if raw.include?(':')
      left, right = raw.split(':', 2)
      opts = left.split(',')
      path = right
    end
    @path = path
    @label = path
    @counter = opts.include?('counter')
    @marker = opts.include?('marker')
  end

  def value_from(obj)
    cur = obj
    @path.split('.').each do |part|
      if cur.is_a?(Hash)
        cur = cur[part] || cur[part.to_sym]
      else
        return nil
      end
    end
    numeric(cur)
  end

  private

  def numeric(v)
    return v.to_f if v.is_a?(Numeric)
    return 1.0 if v == true
    return 0.0 if v == false || v.nil?
    Float(v)
  rescue StandardError
    nil
  end
end

def parse_specs(fields)
  fields.map { |group| group.split('+').map { |part| SeriesSpec.new(part) } }
end

def terminal_ready?
  return true if $stdout.tty? && (ENV['TERM_PROGRAM'] == 'iTerm.app' || ENV['TERM_PROGRAM'] == 'WarpTerminal')
  false
end

def fail_no_graphics
  if ENV['TERM_PROGRAM'] == 'iTerm.app'
    $stderr.puts 'jplot:  Cannot get window size:  inappropriate ioctl for device'
  else
    $stderr.print "#{ESC}[c"
    $stderr.puts 'jplot:  iTerm2, Kitty, or DRCS Sixel graphics required'
  end
  exit 1
end

def read_objects(opts)
  if opts[:url]
    uri = URI(opts[:url])
    interval = parse_duration_seconds(opts[:interval])
    Enumerator.new do |y|
      loop do
        y << JSON.parse(Net::HTTP.get(uri))
        sleep interval
      end
    end
  else
    STDIN.each_line.lazy.map do |line|
      line = line.strip
      next nil if line.empty?
      JSON.parse(line)
    rescue JSON::ParserError => e
      warn "jplot:  #{e.message}"
      nil
    end.reject(&:nil?)
  end
end

def collect_values(objects, specs, steps)
  previous = {}
  rows = []
  objects.each do |obj|
    row = specs.map do |group|
      group.map do |spec|
        val = spec.value_from(obj)
        key = spec.object_id
        if spec.counter
          diff = previous.key?(key) && !val.nil? ? val - previous[key] : 0.0
          previous[key] = val unless val.nil?
          diff
        else
          previous[key] = val unless val.nil?
          val || 0.0
        end
      end
    end
    rows << row
    rows.shift while steps.positive? && rows.length > steps
  end
  rows
end

def render_ascii(rows, specs, max_rows)
  return if rows.empty?
  height = max_rows.positive? ? max_rows : 20
  width = [rows.length, 1].max
  specs.each_with_index do |group, gi|
    labels = group.map(&:label).join('+')
    puts labels
    values = rows.map { |r| r[gi].compact.sum }
    min = [values.min, 0.0].min
    max = [values.max, 1.0].max
    scale = max == min ? 1.0 : max - min
    (height - 1).downto(0) do |level|
      threshold = min + scale * level / [height - 1, 1].max
      line = values.map { |v| v >= threshold ? '#' : ' ' }.join
      puts line[0, width]
    end
  end
end

opts, fields = parse_flags(ARGV)
fail_no_graphics unless terminal_ready?
fail_no_graphics if fields.empty?
specs = parse_specs(fields)
objects = read_objects(opts)
rows = collect_values(objects, specs, opts[:steps])
render_ascii(rows, specs, opts[:rows])
