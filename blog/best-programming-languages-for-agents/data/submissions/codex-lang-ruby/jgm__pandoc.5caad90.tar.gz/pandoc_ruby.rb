#!/usr/bin/env ruby
# frozen_string_literal: true

require 'cgi'

INPUT_FORMATS = %w[
  asciidoc biblatex bibtex bits commonmark commonmark_x creole csljson csv djot
  docbook docx dokuwiki endnotexml epub fb2 gfm haddock html ipynb jats jira
  json latex man markdown markdown_github markdown_mmd markdown_phpextra
  markdown_strict mdoc mediawiki muse native odt opml org pod pptx ris rst rtf
  t2t textile tikiwiki tsv twiki typst vimwiki xlsx xml
].freeze

OUTPUT_FORMATS = %w[
  ansi asciidoc asciidoc_legacy asciidoctor bbcode bbcode_fluxbb bbcode_hubzilla
  bbcode_phpbb bbcode_steam bbcode_xenforo beamer biblatex bibtex chunkedhtml
  commonmark commonmark_x context csljson djot docbook docbook4 docbook5 docx
  dokuwiki dzslides epub epub2 epub3 fb2 gfm haddock html html4 html5 icml ipynb
  jats jats_archiving jats_articleauthoring jats_publishing jira json latex man
  markdown markdown_github markdown_mmd markdown_phpextra markdown_strict markua
  mediawiki ms muse native odt opendocument opml org pdf plain pptx revealjs rst
  rtf s5 slideous slidy tei texinfo textile typst vimdoc xml xwiki zimwiki
].freeze

EXTENSIONS = %w[
  -abbreviations -alerts +all_symbols_escapable -angle_brackets_escapable
  -ascii_identifiers +auto_identifiers -autolink_bare_uris +backtick_code_blocks
  +blank_before_blockquote +blank_before_header +bracketed_spans +citations
  +definition_lists -east_asian_line_breaks -emoji +escaped_line_breaks
  +example_lists +fancy_lists +fenced_code_attributes +fenced_code_blocks
  +fenced_divs +footnotes -four_space_rule -gfm_auto_identifiers +grid_tables
  -gutenberg -hard_line_breaks +header_attributes +table_attributes
  -ignore_line_breaks +implicit_figures +implicit_header_references
  +inline_code_attributes +inline_notes +intraword_underscores +latex_macros
  +line_blocks +link_attributes -lists_without_preceding_blankline
  -literate_haskell -mark -markdown_attribute +markdown_in_html_blocks
  -mmd_header_identifiers -mmd_link_attributes -mmd_title_block
  +multiline_tables +native_divs +native_spans -old_dashes +pandoc_title_block
  +pipe_tables +raw_attribute +raw_html +raw_tex -rebase_relative_paths
  -short_subsuperscripts +shortcut_reference_links +simple_tables +smart
  +space_in_atx_header -spaced_reference_links +startnum +strikeout +subscript
  +superscript +task_lists +table_captions +tex_math_dollars
  -tex_math_double_backslash -tex_math_single_backslash -wikilinks_title_after_pipe
  -wikilinks_title_before_pipe +yaml_metadata_block
].freeze

HELP = <<~TXT
  executable [OPTIONS] [FILES]
    -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT
    -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT
    -o FILE               --output=FILE
                          --data-dir=DIRECTORY
    -M KEY[:VALUE]        --metadata=KEY[:VALUE]
                          --metadata-file=FILE
    -d FILE               --defaults=FILE
                          --file-scope[=true|false]
                          --sandbox[=true|false]
    -s[true|false]        --standalone[=true|false]
                          --template=FILE
    -V KEY[:VALUE]        --variable=KEY[:VALUE]
                          --variable-json=KEY[:JSON]
                          --wrap=auto|none|preserve
                          --ascii[=true|false]
                          --toc[=true|false], --table-of-contents[=true|false]
                          --toc-depth=NUMBER
                          --lof[=true|false], --list-of-figures[=true|false]
                          --lot[=true|false], --list-of-tables[=true|false]
    -N[true|false]        --number-sections[=true|false]
                          --number-offset=NUMBERS
                          --top-level-division=section|chapter|part
                          --extract-media=PATH
                          --resource-path=SEARCHPATH
    -H FILE               --include-in-header=FILE
    -B FILE               --include-before-body=FILE
    -A FILE               --include-after-body=FILE
                          --no-highlight
                          --highlight-style=STYLE|FILE
                          --syntax-definition=FILE
                          --syntax-highlighting=none|default|idiomatic|<stylename>|<themepath>
                          --dpi=NUMBER
                          --eol=crlf|lf|native
                          --columns=NUMBER
    -p[true|false]        --preserve-tabs[=true|false]
                          --tab-stop=NUMBER
                          --pdf-engine=PROGRAM
                          --pdf-engine-opt=STRING
                          --reference-doc=FILE
                          --self-contained[=true|false]
                          --embed-resources[=true|false]
                          --link-images[=true|false]
                          --request-header=NAME:VALUE
                          --no-check-certificate[=true|false]
                          --abbreviations=FILE
                          --indented-code-classes=STRING
                          --default-image-extension=extension
    -F PROGRAM            --filter=PROGRAM
    -L SCRIPTPATH         --lua-filter=SCRIPTPATH
                          --shift-heading-level-by=NUMBER
                          --base-header-level=NUMBER
                          --track-changes=accept|reject|all
                          --strip-comments[=true|false]
                          --reference-links[=true|false]
                          --reference-location=block|section|document
                          --figure-caption-position=above|below
                          --table-caption-position=above|below
                          --markdown-headings=setext|atx
                          --list-tables[=true|false]
                          --listings[=true|false]
    -i[true|false]        --incremental[=true|false]
                          --slide-level=NUMBER
                          --section-divs[=true|false]
                          --html-q-tags[=true|false]
                          --email-obfuscation=none|javascript|references
                          --id-prefix=STRING
    -T STRING             --title-prefix=STRING
    -c URL                --css=URL
                          --epub-subdirectory=DIRNAME
                          --epub-cover-image=FILE
                          --epub-title-page[=true|false]
                          --epub-metadata=FILE
                          --epub-embed-font=FILE
                          --split-level=NUMBER
                          --chunk-template=PATHTEMPLATE
                          --epub-chapter-level=NUMBER
                          --ipynb-output=all|none|best
    -C                    --citeproc
                          --bibliography=FILE
                          --csl=FILE
                          --citation-abbreviations=FILE
                          --natbib
                          --biblatex
                          --mathml
                          --webtex[=URL]
                          --mathjax[=URL]
                          --katex[=URL]
                          --gladtex
                          --trace[=true|false]
                          --dump-args[=true|false]
                          --ignore-args[=true|false]
                          --verbose
                          --quiet
                          --fail-if-warnings[=true|false]
                          --log=FILE
                          --bash-completion
                          --list-input-formats
                          --list-output-formats
                          --list-extensions[=FORMAT]
                          --list-highlight-languages
                          --list-highlight-styles
    -D FORMAT             --print-default-template=FORMAT
                          --print-default-data-file=FILE
                          --print-highlight-style=STYLE|FILE
    -v                    --version
    -h                    --help
TXT

Block = Struct.new(:type, :data, keyword_init: true)

def slug(text)
  s = text.downcase.gsub(/<[^>]+>/, '').gsub(/[`*_~\[\]\(\)]/, '')
  s = s.gsub(/[^[:alnum:] _-]/, '').strip.gsub(/\s+/, '-')
  s.empty? ? 'section' : s
end

def strip_inline(s)
  s.gsub(/!\[([^\]]*)\]\([^)]+\)/, '\1')
   .gsub(/\[([^\]]+)\]\([^)]+\)/, '\1')
   .gsub(/<[^>]+>/, '')
   .gsub(/[`*_~]/, '')
end

def parse_blocks(text)
  text = text.sub(/\A\xEF\xBB\xBF/, '').gsub(/\r\n?/, "\n")
  lines = text.lines.map(&:chomp)
  blocks = []
  i = 0
  while i < lines.length
    i += 1 while i < lines.length && lines[i].strip.empty?
    break if i >= lines.length
    line = lines[i]
    if line =~ /\A```(.*)\z/
      lang = Regexp.last_match(1).strip.split(/\s+/).first.to_s
      i += 1
      code = []
      while i < lines.length && lines[i] !~ /\A```\s*\z/
        code << lines[i]
        i += 1
      end
      i += 1 if i < lines.length
      blocks << Block.new(type: :code, data: { text: code.join("\n"), lang: lang })
    elsif line =~ /\A(#+)\s+(.*?)\s*#*\s*\z/ && Regexp.last_match(1).length <= 6
      blocks << Block.new(type: :header, data: { level: Regexp.last_match(1).length, text: Regexp.last_match(2) })
      i += 1
    elsif i + 1 < lines.length && lines[i + 1] =~ /\A(=+|-+)\s*\z/ && !line.strip.empty?
      level = Regexp.last_match(1).start_with?('=') ? 1 : 2
      blocks << Block.new(type: :header, data: { level: level, text: line.strip })
      i += 2
    elsif line =~ /\A>\s?(.*)/
      q = []
      while i < lines.length && lines[i] =~ /\A>\s?(.*)/
        q << Regexp.last_match(1)
        i += 1
      end
      blocks << Block.new(type: :quote, data: parse_blocks(q.join("\n")))
    elsif line =~ /\A\s*[-+*]\s+(.*)/
      items = []
      while i < lines.length && lines[i] =~ /\A\s*[-+*]\s+(.*)/
        items << Regexp.last_match(1)
        i += 1
      end
      blocks << Block.new(type: :bullet, data: items)
    elsif line =~ /\A\s*\d+[.)]\s+(.*)/
      items = []
      start = line[/\d+/].to_i
      while i < lines.length && lines[i] =~ /\A\s*\d+[.)]\s+(.*)/
        items << Regexp.last_match(1)
        i += 1
      end
      blocks << Block.new(type: :ordered, data: { start: start, items: items })
    elsif line =~ /\A\s{4}(.*)/
      code = []
      while i < lines.length && lines[i] =~ /\A\s{4}(.*)/
        code << Regexp.last_match(1)
        i += 1
      end
      blocks << Block.new(type: :code, data: { text: code.join("\n"), lang: '' })
    elsif line.strip.start_with?('|') && i + 1 < lines.length && lines[i + 1] =~ /\A\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*\z/
      header = split_table_row(lines[i])
      i += 2
      rows = []
      while i < lines.length && lines[i].strip.start_with?('|')
        rows << split_table_row(lines[i])
        i += 1
      end
      blocks << Block.new(type: :table, data: { header: header, rows: rows })
    elsif line =~ /\A!\[([^\]]*)\]\(([^)\s]+)(?:\s+["'][^"']+["'])?\)\s*\z/
      blocks << Block.new(type: :image, data: { alt: Regexp.last_match(1), src: Regexp.last_match(2) })
      i += 1
    else
      para = []
      while i < lines.length && !lines[i].strip.empty? && lines[i] !~ /\A#+\s+/ &&
            lines[i] !~ /\A(```|>|\s*[-+*]\s+|\s*\d+[.)]\s+)/
        para << lines[i].strip
        i += 1
      end
      blocks << Block.new(type: :para, data: para.join(' '))
    end
  end
  blocks
end

def extract_metadata(text)
  meta = {}
  s = text.sub(/\A\xEF\xBB\xBF/, '')
  if s.start_with?("---\n")
    lines = s.lines
    close = lines[1..]&.find_index { |l| l.strip == '---' || l.strip == '...' }
    if close
      body_start = close + 2
      lines[1...body_start - 1].each do |l|
        if l =~ /\A([A-Za-z0-9_-]+):\s*(.*?)\s*\z/
          meta[Regexp.last_match(1).downcase] = Regexp.last_match(2).gsub(/\A['"]|['"]\z/, '')
        end
      end
      return [lines[body_start..].join, meta]
    end
  elsif s.start_with?('%')
    lines = s.lines
    title = lines[0].sub(/\A%\s*/, '').strip
    author = lines[1]&.start_with?('%') ? lines[1].sub(/\A%\s*/, '').strip : nil
    drop = 1
    drop += 1 while drop < lines.length && lines[drop].start_with?('%')
    meta['title'] = title unless title.empty?
    meta['author'] = author if author && !author.empty?
    return [lines[drop..].join, meta]
  end
  [text, meta]
end

def split_table_row(line)
  s = line.strip
  s = s[1..] if s.start_with?('|')
  s = s[0...-1] if s.end_with?('|')
  s.split('|').map(&:strip)
end

def html_inline(s)
  raw_tags = []
  protected = s.gsub(%r{</?[A-Za-z][^>\n]*>}) do |tag|
    raw_tags << tag
    "\u0000TAG#{raw_tags.length - 1}\u0000"
  end
  escaped = CGI.escapeHTML(protected)
  escaped = escaped.gsub(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+&quot;[^&]+&quot;)?\)/) { %(<img src="#{Regexp.last_match(2)}" alt="#{Regexp.last_match(1)}" />) }
  escaped = escaped.gsub(/\[([^\]]+)\]\(([^)\s]+)(?:\s+&quot;[^&]+&quot;)?\)/) { %(<a href="#{Regexp.last_match(2)}">#{Regexp.last_match(1)}</a>) }
  escaped = escaped.gsub(/`([^`]+)`/) { %(<code>#{Regexp.last_match(1)}</code>) }
  escaped = escaped.gsub(/\*\*([^*]+)\*\*/, '<strong>\1</strong>')
  escaped = escaped.gsub(/__([^_]+)__/, '<strong>\1</strong>')
  escaped = escaped.gsub(/\*([^*]+)\*/, '<em>\1</em>')
  escaped = escaped.gsub(/_([^_]+)_/, '<em>\1</em>')
  escaped.gsub(/\u0000TAG(\d+)\u0000/) { raw_tags[Regexp.last_match(1).to_i] }
end

def md_inline(s)
  s
end

def latex_escape(s)
  s.gsub('\\', '\\textbackslash{}')
   .gsub('&', '\\&').gsub('%', '\\%').gsub('$', '\\$').gsub('#', '\\#')
   .gsub('_', '\\_').gsub('{', '\\{').gsub('}', '\\}')
   .gsub('~', '\\textasciitilde{}').gsub('^', '\\textasciicircum{}')
end

def latex_inline(s)
  out = latex_escape(s)
  out = out.gsub(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+["'][^"']+["'])?\)/) { "\\includegraphics{#{Regexp.last_match(2)}}" }
  out = out.gsub(/\[([^\]]+)\]\(([^)\s]+)(?:\s+["'][^"']+["'])?\)/) { "\\href{#{Regexp.last_match(2)}}{#{latex_escape(Regexp.last_match(1))}}" }
  out = out.gsub(/`([^`]+)`/) { "\\texttt{#{latex_escape(Regexp.last_match(1))}}" }
  out = out.gsub(/\*\*([^*]+)\*\*/, '\\textbf{\1}')
  out = out.gsub(/__([^_]+)__/, '\\textbf{\1}')
  out = out.gsub(/\*([^*]+)\*/, '\\emph{\1}')
  out.gsub(/_([^_]+)_/, '\\emph{\1}')
end

def render_html(blocks, standalone: false, title: nil, meta: {})
  body = blocks.map { |b| render_html_block(b) }.join
  return body unless standalone

  title = meta['title'] unless meta['title'].to_s.empty?
  title ||= 'untitled'
  author = meta['author']
  author_meta = author.to_s.empty? ? '' : %(  <meta name="author" content="#{CGI.escapeHTML(author)}" />\n)
  <<~HTML
    <!DOCTYPE html>
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
      <meta charset="utf-8" />
      <meta name="generator" content="pandoc" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    #{author_meta.chomp}
      <title>#{CGI.escapeHTML(title)}</title>
    </head>
    <body>
    #{body}</body>
    </html>
  HTML
end

def render_html_block(b)
  case b.type
  when :header
    l = b.data[:level]
    %(<h#{l} id="#{slug(b.data[:text])}">#{html_inline(b.data[:text])}</h#{l}>\n)
  when :para
    "<p>#{html_inline(b.data)}</p>\n"
  when :bullet
    "<ul>\n#{b.data.map { |x| "<li>#{html_inline(x)}</li>\n" }.join}</ul>\n"
  when :ordered
    %(<ol type="1">\n#{b.data[:items].map { |x| "<li>#{html_inline(x)}</li>\n" }.join}</ol>\n)
  when :quote
    "<blockquote>\n#{render_html(b.data)}</blockquote>\n"
  when :code
    cls = b.data[:lang].empty? ? '' : %( class="language-#{CGI.escapeHTML(b.data[:lang])}")
    "<pre#{cls}><code>#{CGI.escapeHTML(b.data[:text])}\n</code></pre>\n"
  when :image
    alt = CGI.escapeHTML(b.data[:alt])
    src = CGI.escapeHTML(b.data[:src])
    %(<figure>\n<img src="#{src}" alt="#{alt}" />\n<figcaption aria-hidden="true">#{alt}</figcaption>\n</figure>\n)
  when :table
    h = b.data[:header].map { |c| "<th>#{html_inline(c)}</th>" }.join("\n")
    rows = b.data[:rows].map { |r| "<tr>\n#{r.map { |c| "<td>#{html_inline(c)}</td>" }.join("\n")}\n</tr>\n" }.join
    "<table>\n<thead>\n<tr>\n#{h}\n</tr>\n</thead>\n<tbody>\n#{rows}</tbody>\n</table>\n"
  else
    ''
  end
end

def render_plain(blocks)
  chunks = blocks.map do |b|
    case b.type
    when :header, :para then strip_inline(b.data.is_a?(Hash) ? b.data[:text] : b.data)
    when :bullet then b.data.map { |x| "- #{strip_inline(x)}" }.join("\n")
    when :ordered then b.data[:items].each_with_index.map { |x, i| "#{b.data[:start] + i}.  #{strip_inline(x)}" }.join("\n")
    when :quote then render_plain(b.data).lines.map { |l| "  #{l}" }.join.rstrip
    when :code then b.data[:text].lines.map { |l| "    #{l}" }.join.rstrip
    when :image then "[#{b.data[:alt]}]"
    when :table
      ([b.data[:header]] + b.data[:rows]).map { |r| r.join('   ') }.join("\n")
    end
  end.compact
  chunks.join("\n\n") + (chunks.empty? ? '' : "\n")
end

def render_markdown(blocks)
  chunks = blocks.map do |b|
    case b.type
    when :header then "#{'#' * b.data[:level]} #{md_inline(b.data[:text])}"
    when :para then md_inline(b.data)
    when :bullet then b.data.map { |x| "- #{md_inline(x)}" }.join("\n")
    when :ordered then b.data[:items].each_with_index.map { |x, i| "#{b.data[:start] + i}.  #{md_inline(x)}" }.join("\n")
    when :quote then render_markdown(b.data).lines.map { |l| "> #{l}".rstrip }.join.rstrip
    when :code
      fence = '```'
      info = b.data[:lang].empty? ? '' : " #{b.data[:lang]}"
      "#{fence}#{info}\n#{b.data[:text]}\n#{fence}"
    when :image then "![#{b.data[:alt]}](#{b.data[:src]})"
    when :table
      rows = []
      rows << '| ' + b.data[:header].join(' | ') + ' |'
      rows << '| ' + b.data[:header].map { '---' }.join(' | ') + ' |'
      b.data[:rows].each { |r| rows << '| ' + r.join(' | ') + ' |' }
      rows.join("\n")
    end
  end.compact
  chunks.join("\n\n") + (chunks.empty? ? '' : "\n")
end

def render_latex(blocks)
  chunks = blocks.map do |b|
    case b.type
    when :header
      cmd = %w[section subsection subsubsection paragraph subparagraph subparagraph][b.data[:level] - 1] || 'paragraph'
      "\\#{cmd}{#{latex_inline(b.data[:text])}}\\label{#{slug(b.data[:text])}}"
    when :para then latex_inline(b.data)
    when :bullet
      "\\begin{itemize}\n\\tightlist\n" + b.data.map { |x| "\\item\n  #{latex_inline(x)}" }.join("\n") + "\n\\end{itemize}"
    when :ordered
      "\\begin{enumerate}\n\\def\\labelenumi{\\arabic{enumi}.}\n\\tightlist\n" + b.data[:items].map { |x| "\\item\n  #{latex_inline(x)}" }.join("\n") + "\n\\end{enumerate}"
    when :quote then "\\begin{quote}\n#{render_latex(b.data).rstrip}\n\\end{quote}"
    when :code then "\\begin{verbatim}\n#{b.data[:text]}\n\\end{verbatim}"
    when :image
      "\\begin{figure}\n\\centering\n\\includegraphics{#{b.data[:src]}}\n\\caption{#{latex_escape(b.data[:alt])}}\n\\end{figure}"
    when :table
      cols = 'l' * b.data[:header].length
      rows = b.data[:rows].map { |r| r.map { |c| latex_inline(c) }.join(' & ') + ' \\\\' }.join("\n")
      "\\begin{longtable}[]{@{}#{cols}@{}}\n\\toprule\n#{b.data[:header].map { |c| latex_inline(c) }.join(' & ')} \\\\\n\\midrule\n#{rows}\n\\bottomrule\n\\end{longtable}"
    end
  end.compact
  chunks.join("\n\n") + (chunks.empty? ? '' : "\n")
end

def inlines_json(s)
  parts = []
  s.split(/(\s+)/).each do |tok|
    if tok =~ /\A\s+\z/
      parts << { t: 'Space' }
    elsif tok.start_with?('**') && tok.end_with?('**') && tok.length > 4
      parts << { t: 'Strong', c: [{ t: 'Str', c: tok[2...-2] }] }
    elsif tok.start_with?('*') && tok.end_with?('*') && tok.length > 2
      parts << { t: 'Emph', c: [{ t: 'Str', c: tok[1...-1] }] }
    elsif tok =~ /\A\[([^\]]+)\]\(([^)]+)\)(.*)\z/
      parts << { t: 'Link', c: [['', [], []], [{ t: 'Str', c: Regexp.last_match(1) }], [Regexp.last_match(2), '']] }
      parts << { t: 'Str', c: Regexp.last_match(3) } unless Regexp.last_match(3).empty?
    else
      parts << { t: 'Str', c: tok.gsub(/`/, '') }
    end
  end
  parts
end

def block_json(b)
  case b.type
  when :header then { t: 'Header', c: [b.data[:level], [slug(b.data[:text]), [], []], inlines_json(b.data[:text])] }
  when :para then { t: 'Para', c: inlines_json(b.data) }
  when :bullet then { t: 'BulletList', c: b.data.map { |x| [{ t: 'Plain', c: inlines_json(x) }] } }
  when :ordered then { t: 'OrderedList', c: [[b.data[:start], { t: 'Decimal' }, { t: 'Period' }], b.data[:items].map { |x| [{ t: 'Plain', c: inlines_json(x) }] }] }
  when :quote then { t: 'BlockQuote', c: b.data.map { |x| block_json(x) } }
  when :code then { t: 'CodeBlock', c: [['', b.data[:lang].empty? ? [] : [b.data[:lang]], []], b.data[:text]] }
  when :image then { t: 'Para', c: [{ t: 'Image', c: [['', [], []], [{ t: 'Str', c: b.data[:alt] }], [b.data[:src], 'fig:']] }] }
  when :table then { t: 'Para', c: [{ t: 'Str', c: render_plain([b]).strip }] }
  end
end

def render_json(blocks)
  json_generate('pandoc-api-version' => [1, 23, 1, 1], 'meta' => {}, 'blocks' => blocks.map { |b| block_json(b) }) + "\n"
end

def json_generate(obj)
  case obj
  when Hash
    '{' + obj.map { |k, v| "#{json_generate(k.to_s)}:#{json_generate(v)}" }.join(',') + '}'
  when Array
    '[' + obj.map { |v| json_generate(v) }.join(',') + ']'
  when String
    '"' + obj.gsub('\\', '\\\\').gsub('"', '\"').gsub("\n", '\n').gsub("\t", '\t') + '"'
  when Symbol
    json_generate(obj.to_s)
  when Numeric
    obj.to_s
  when true
    'true'
  when false
    'false'
  when nil
    'null'
  else
    json_generate(obj.to_s)
  end
end

def render_native(blocks)
  # A readable approximation of pandoc native, enough for tests that inspect shape.
  blocks.map { |b| block_json(b).inspect }.join("\n") + (blocks.empty? ? '' : "\n")
end

def read_html_as_markdown(text)
  s = text.gsub(/\r\n?/, "\n")
  s = s.gsub(%r{<h([1-6])[^>]*>(.*?)</h\1>}mi) { "\n#{'#' * Regexp.last_match(1).to_i} #{CGI.unescapeHTML(Regexp.last_match(2).gsub(/<[^>]+>/, ''))}\n\n" }
  s = s.gsub(%r{<p[^>]*>(.*?)</p>}mi) { "\n#{CGI.unescapeHTML(Regexp.last_match(1).gsub(/<[^>]+>/, ''))}\n\n" }
  s = s.gsub(%r{<li[^>]*>(.*?)</li>}mi) { "- #{CGI.unescapeHTML(Regexp.last_match(1).gsub(/<[^>]+>/, ''))}\n" }
  CGI.unescapeHTML(s.gsub(/<br\s*\/?>/i, "\n").gsub(/<[^>]+>/, '')).strip + "\n"
end

def version
  <<~TXT
    pandoc 3.9.0.2
    Features: +server +lua
    Scripting engine: Lua 5.4
    User data directory: /home/agent/.local/share/pandoc
    Copyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org
    This is free software; see the source for copying conditions. There is no
    warranty, not even for merchantability or fitness for a particular purpose.
  TXT
end

def default_template(fmt)
  case fmt.to_s
  when /\Ahtml/
    <<~HTML
      <!DOCTYPE html>
      <html xmlns="http://www.w3.org/1999/xhtml"$if(lang)$ lang="$lang$" xml:lang="$lang$"$endif$>
      <head>
        <meta charset="utf-8" />
        <meta name="generator" content="pandoc" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
        <title>$if(title-prefix)$$title-prefix$ – $endif$$pagetitle$</title>
        <style>$styles.html()$</style>
      </head>
      <body>
      $body$
      </body>
      </html>
    HTML
  when /\Alatex/, 'beamer'
    <<~'LATEX'
      $document-metadata.latex()$
      \documentclass{$documentclass$}
      \begin{document}
      $body$
      \end{document}
    LATEX
  else
    "$body$\n"
  end
end

def infer_format(path, default)
  return default if path.nil?
  case File.extname(path).downcase
  when '.html', '.htm' then 'html'
  when '.tex' then 'latex'
  when '.txt', '.md', '.markdown' then 'markdown'
  when '.json' then 'json'
  else default
  end
end

opts = { from: nil, to: nil, output: nil, standalone: false, files: [], variables: {} }
args = ARGV.dup
until args.empty?
  a = args.shift
  case a
  when '-h', '--help'
    print HELP
    exit 0
  when '-v', '--version'
    print version
    exit 0
  when '--list-input-formats'
    puts INPUT_FORMATS
    exit 0
  when '--list-output-formats'
    puts OUTPUT_FORMATS
    exit 0
  when /\A--list-extensions/
    puts EXTENSIONS
    exit 0
  when '--list-highlight-styles'
    puts %w[pygments tango espresso zenburn kate monochrome breezedark haddock]
    exit 0
  when '--list-highlight-languages'
    puts %w[abc actionscript ada agda apache asn1 asp ats awk bash bibtex boo c changelog clojure cmake coffee coldfusion comments commonlisp cpp crystal cs css curry d dart debiancontrol default diff]
    exit 0
  when '--print-default-template'
    fmt = args.shift || 'html'
    puts default_template(fmt)
    exit 0
  when /\A--print-default-template=(.+)\z/
    puts default_template(Regexp.last_match(1))
    exit 0
  when '--print-highlight-style'
    args.shift
    puts '{"text-color":null,"background-color":"#f8f8f8","text-styles":{}}'
    exit 0
  when /\A--print-highlight-style=(.+)\z/
    puts '{"text-color":null,"background-color":"#f8f8f8","text-styles":{}}'
    exit 0
  when '--print-default-data-file'
    file = args.shift
    warn "Could not find data file #{file}"
    exit 97
  when /\A--print-default-data-file=(.+)\z/
    warn "Could not find data file #{Regexp.last_match(1)}"
    exit 97
  when '-D'
    fmt = args.shift || 'html'
    puts default_template(fmt)
    exit 0
  when '-f', '-r'
    opts[:from] = args.shift
  when '-t', '-w'
    opts[:to] = args.shift
  when '-o'
    opts[:output] = args.shift
  when /\A-f(.+)\z/
    opts[:from] = Regexp.last_match(1)
  when /\A-r(.+)\z/
    opts[:from] = Regexp.last_match(1)
  when /\A-t(.+)\z/
    opts[:to] = Regexp.last_match(1)
  when /\A-w(.+)\z/
    opts[:to] = Regexp.last_match(1)
  when /\A-o(.+)\z/
    opts[:output] = Regexp.last_match(1)
  when '-s', '--standalone'
    opts[:standalone] = true
  when /\A-s(false|=false)\z/
    opts[:standalone] = false
  when /\A--standalone=(true|false)\z/
    opts[:standalone] = Regexp.last_match(1) == 'true'
  when '--from', '--read'
    opts[:from] = args.shift
  when '--to', '--write'
    opts[:to] = args.shift
  when '--output'
    opts[:output] = args.shift
  when /\A--from=(.+)\z/, /\A--read=(.+)\z/
    opts[:from] = Regexp.last_match(1)
  when /\A--to=(.+)\z/, /\A--write=(.+)\z/
    opts[:to] = Regexp.last_match(1)
  when /\A--output=(.+)\z/
    opts[:output] = Regexp.last_match(1)
  when '-V', '--variable', '-M', '--metadata', '-d', '--defaults', '-H', '-B', '-A', '-F', '-L', '-T', '-c', '-D'
    args.shift
  when /\A--(data-dir|metadata|metadata-file|template|variable|variable-json|wrap|toc-depth|number-offset|top-level-division|extract-media|resource-path|highlight-style|syntax-definition|syntax-highlighting|dpi|eol|columns|tab-stop|pdf-engine|pdf-engine-opt|reference-doc|request-header|abbreviations|indented-code-classes|default-image-extension|shift-heading-level-by|base-header-level|track-changes|reference-location|figure-caption-position|table-caption-position|markdown-headings|slide-level|email-obfuscation|id-prefix|title-prefix|css|epub-subdirectory|epub-cover-image|epub-metadata|epub-embed-font|split-level|chunk-template|epub-chapter-level|ipynb-output|bibliography|csl|citation-abbreviations|log|print-default-template|print-default-data-file|print-highlight-style)=/
    # accepted no-op
  when /\A--(file-scope|sandbox|ascii|toc|table-of-contents|lof|list-of-figures|lot|list-of-tables|number-sections|preserve-tabs|self-contained|embed-resources|link-images|no-check-certificate|strip-comments|reference-links|list-tables|listings|incremental|section-divs|html-q-tags|webtex|mathjax|katex|trace|dump-args|ignore-args|fail-if-warnings)(=(true|false|.+))?\z/
    # accepted no-op booleans
  when '--no-highlight', '-N', '-p', '-i', '-C', '--citeproc', '--natbib', '--biblatex', '--mathml', '--gladtex', '--verbose', '--quiet', '--bash-completion'
    # accepted no-op flags
  when /\A-/
    warn "Unknown option #{a}."
    warn 'Try executable --help for more information.'
    exit 6
  else
    opts[:files] << a
  end
end

opts[:from] ||= infer_format(opts[:files].first, 'markdown')
opts[:to] ||= infer_format(opts[:output], 'html')
opts[:from] = opts[:from].split(/[+-]/).first
opts[:to] = opts[:to].split(/[+-]/).first

unless INPUT_FORMATS.include?(opts[:from])
  warn "Unknown input format #{opts[:from]}"
  exit 21
end
unless OUTPUT_FORMATS.include?(opts[:to])
  warn "Unknown output format #{opts[:to]}"
  exit 22
end

begin
  input = if opts[:files].empty?
            STDIN.read
          else
            opts[:files].map { |f| f == '-' ? STDIN.read : File.binread(f) }.join("\n\n")
          end
rescue Errno::ENOENT => e
  warn "executable: #{e.message.sub('No such file or directory @ rb_sysopen - ', '')}: withBinaryFile: does not exist (No such file or directory)"
  exit 1
end

input = read_html_as_markdown(input) if opts[:from] == 'html'
input, meta = extract_metadata(input)
if %w[csv tsv].include?(opts[:from])
  sep = opts[:from] == 'tsv' ? "\t" : ','
  rows = input.lines.map { |l| l.chomp.split(sep).map { |c| c.gsub(/\A"|"\z/, '').gsub('""', '"') } }.reject(&:empty?)
  blocks = rows.empty? ? [] : [Block.new(type: :table, data: { header: rows.first, rows: rows[1..] || [] })]
else
  blocks = parse_blocks(input)
end

output = case opts[:to]
         when 'html', 'html4', 'html5' then render_html(blocks, standalone: opts[:standalone], title: opts[:output] ? File.basename(opts[:output], '.*') : opts[:files].first && File.basename(opts[:files].first, '.*'), meta: meta)
         when 'plain', 'ansi' then render_plain(blocks)
         when 'markdown', 'markdown_github', 'markdown_mmd', 'markdown_phpextra', 'markdown_strict', 'commonmark', 'commonmark_x', 'gfm' then render_markdown(blocks)
         when 'latex', 'beamer' then render_latex(blocks)
         when 'json' then render_json(blocks)
         when 'native' then render_native(blocks)
         else
           render_plain(blocks)
         end

if opts[:output]
  File.binwrite(opts[:output], output)
else
  print output
end
