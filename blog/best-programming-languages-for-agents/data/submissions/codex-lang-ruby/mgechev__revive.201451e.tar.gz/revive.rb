#!/usr/bin/env ruby
# frozen_string_literal: true

require 'find'

BANNER = <<~TXT

 _ __ _____   _(_)__  _____
| '__/ _ \\ \\ / / \\ \\ / / _ \\
| | |  __/\\ V /| |\\ V /  __/
|_|  \\___| \\_/ |_| \\_/ \\___|

Example:
  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...

TXT

HELP = <<~TXT
Usage of ./executable:
  -config string
    \tpath to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)
  -exclude value
    \tlist of globs which specify files to be excluded (i.e. -exclude foo/...)
  -formatter string
    \tformatter to be used for the output (i.e. -formatter stylish)
  -max_open_files int
    \tmaximum number of open files at the same time
  -set_exit_status
    \tset exit status to 1 if any issues are found, overwrites errorCode and warningCode in config
  -version
    \tget revive version
TXT

CATEGORIES = {
  'line-length-limit' => 'style',
  'package-comments' => 'comments',
  'exported' => 'comments',
  'unused-parameter' => 'bad practice',
  'unreachable-code' => 'logic',
  'empty-block' => 'style',
  'blank-imports' => 'imports',
  'dot-imports' => 'imports',
  'error-strings' => 'errors',
  'increment-decrement' => 'style',
  'var-naming' => 'naming'
}.freeze

def json_escape(s)
  s.to_s.gsub(/["\\\b\f\n\r\t]/) do |c|
    case c
    when '"' then '\"'
    when '\\' then '\\\\'
    when "\b" then '\b'
    when "\f" then '\f'
    when "\n" then '\n'
    when "\r" then '\r'
    when "\t" then '\t'
    end
  end
end

def json_generate(obj)
  case obj
  when Hash
    '{' + obj.map { |k, v| "#{json_generate(k.to_s)}:#{json_generate(v)}" }.join(',') + '}'
  when Array
    '[' + obj.map { |v| json_generate(v) }.join(',') + ']'
  when String
    '"' + json_escape(obj) + '"'
  when Symbol
    '"' + json_escape(obj.to_s) + '"'
  when Numeric
    obj.to_s
  when true
    'true'
  when false
    'false'
  when nil
    'null'
  else
    '"' + json_escape(obj.to_s) + '"'
  end
end

def json_pretty(obj, indent = 0)
  space = '  ' * indent
  case obj
  when Hash
    return '{}' if obj.empty?
    inner = obj.map { |k, v| "#{'  ' * (indent + 1)}#{json_generate(k.to_s)}: #{json_pretty(v, indent + 1)}" }.join(",\n")
    "{\n#{inner}\n#{space}}"
  when Array
    return '[]' if obj.empty?
    inner = obj.map { |v| "#{'  ' * (indent + 1)}#{json_pretty(v, indent + 1)}" }.join(",\n")
    "[\n#{inner}\n#{space}]"
  else
    json_generate(obj)
  end
end

DEFAULT_RULES = %w[
  package-comments exported blank-imports dot-imports error-strings
  increment-decrement unused-parameter unreachable-code
].freeze

Issue = Struct.new(:filename, :line, :column, :end_line, :end_column, :failure,
                   :rule, :severity, :category, :confidence, :offset, :end_offset,
                   keyword_init: true)

def usage
  BANNER + HELP
end

def parse_args(argv)
  opts = {
    config: nil, formatter: nil, excludes: [], set_exit_status: false,
    version: false, help: false, args: []
  }
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-h', '--help'
      opts[:help] = true
    when '-version', '--version'
      opts[:version] = true
    when '-set_exit_status'
      opts[:set_exit_status] = true
    when '-config'
      i += 1
      opts[:config] = argv[i]
    when /^-config=(.*)/
      opts[:config] = Regexp.last_match(1)
    when '-formatter'
      i += 1
      opts[:formatter] = argv[i]
    when /^-formatter=(.*)/
      opts[:formatter] = Regexp.last_match(1)
    when '-exclude'
      i += 1
      opts[:excludes] << argv[i]
    when /^-exclude=(.*)/
      opts[:excludes] << Regexp.last_match(1)
    when '-max_open_files'
      i += 1
    when /^-max_open_files=/
      # ignored
    else
      if arg.start_with?('-')
        warn "flag provided but not defined: #{arg}"
        warn usage
        exit 2
      end
      opts[:args] << arg
    end
    i += 1
  end
  opts
end

def strip_quotes(s)
  s.to_s.strip.sub(/\A['"]/, '').sub(/['"]\z/, '')
end

def parse_config(path)
  return nil unless path
  unless File.file?(path)
    puts 'cannot read the config file'
    exit 1
  end

  cfg = { severity: 'warning', confidence: 0.8, rules: {}, error_code: nil, warning_code: nil }
  current = nil
  File.readlines(path, chomp: true).each do |line|
    line = line.sub(/#.*/, '').strip
    next if line.empty?
    if line =~ /^\[rule\.([^\]]+)\]$/
      current = Regexp.last_match(1)
      cfg[:rules][current] ||= { disabled: false, arguments: [], severity: nil }
      next
    end
    if line =~ /^([A-Za-z_][\w-]*)\s*=\s*(.+)$/
      key = Regexp.last_match(1)
      val = Regexp.last_match(2).strip
      if current
        case key.downcase
        when 'disabled'
          cfg[:rules][current][:disabled] = val =~ /true/i ? true : false
        when 'arguments'
          inside = val[/\[(.*)\]/, 1].to_s
          cfg[:rules][current][:arguments] = inside.split(',').map { |x| strip_quotes(x) }.reject(&:empty?)
        when 'severity'
          cfg[:rules][current][:severity] = strip_quotes(val)
        end
      else
        case key
        when 'severity'
          cfg[:severity] = strip_quotes(val)
        when 'confidence'
          cfg[:confidence] = val.to_f
        when 'errorCode'
          cfg[:error_code] = val.to_i
        when 'warningCode'
          cfg[:warning_code] = val.to_i
        end
      end
    end
  end
  cfg
end

def default_config_path
  xdg = ENV['XDG_CONFIG_HOME']
  candidates = []
  candidates << File.join(xdg, 'revive.toml') if xdg && !xdg.empty?
  candidates << File.join(ENV['HOME'].to_s, 'revive.toml')
  candidates.find { |p| File.file?(p) }
end

def normalize_path(path)
  path.sub(%r{^\./\./}, '../')
end

def excluded?(file, patterns)
  patterns.any? do |pat|
    next false unless pat
    p = pat.sub(%r{^\./}, '')
    f = file.sub(%r{^\./}, '')
    if p.end_with?('/...')
      prefix = p.sub(%r{/\.\.\.$}, '')
      f == prefix || f.start_with?(prefix + '/')
    else
      File.fnmatch?(p, f, File::FNM_PATHNAME) || File.fnmatch?(pat, file, File::FNM_PATHNAME)
    end
  end
end

def go_files(args, excludes)
  args = ['.'] if args.empty?
  files = []
  args.each do |arg|
    if arg.end_with?('/...')
      base = arg.sub(%r{/\.\.\.$}, '')
      base = '.' if base.empty?
      next unless File.directory?(base)
      Find.find(base) do |path|
        Find.prune if File.basename(path) == '.git'
        files << path if File.file?(path) && path.end_with?('.go')
      end
    elsif File.directory?(arg)
      Dir.glob(File.join(arg, '*.go')).each { |p| files << p if File.file?(p) }
    elsif File.file?(arg) && arg.end_with?('.go')
      files << arg
    end
  end
  files.uniq.sort.reject { |f| excluded?(f, excludes) }
end

def line_offsets(lines)
  offsets = []
  total = 0
  lines.each do |l|
    offsets << total
    total += l.bytesize
  end
  offsets
end

def issue(file, idx, col, msg, rule, severity, lines, offsets, end_col = nil)
  text_len = lines[idx - 1].to_s.chomp.length
  Issue.new(
    filename: file, line: idx, column: col, end_line: idx,
    end_column: end_col || [col + 1, text_len + 1].max,
    failure: msg, rule: rule, severity: severity,
    category: CATEGORIES[rule] || 'style', confidence: 1,
    offset: offsets[idx - 1].to_i + [col - 1, 0].max,
    end_offset: offsets[idx - 1].to_i + (end_col || text_len)
  )
end

def comment_before?(lines, line_no, name = nil)
  i = line_no - 2
  while i >= 0 && lines[i].strip.empty?
    i -= 1
  end
  return false if i < 0
  s = lines[i].strip
  return false unless s.start_with?('//', '/*', '*')
  return true unless name
  s.include?(name)
end

def disabled_lines(lines)
  disabled_all = false
  rule_disabled = Hash.new(false)
  next_line = Hash.new { |h, k| h[k] = {} }
  disabled = Hash.new { |h, k| h[k] = {} }
  lines.each_with_index do |line, i|
    n = i + 1
    text = line.strip
    if text =~ %r{//\s*revive:disable-next-line(?::([\w-]+))?}
      r = Regexp.last_match(1) || '*'
      next_line[n + 1][r] = true
    elsif text =~ %r{//\s*revive:disable(?::([\w-]+))?}
      r = Regexp.last_match(1)
      r ? rule_disabled[r] = true : disabled_all = true
    elsif text =~ %r{//\s*revive:enable(?::([\w-]+))?}
      r = Regexp.last_match(1)
      r ? rule_disabled[r] = false : disabled_all = false
    end
    disabled[n]['*'] = true if disabled_all || next_line[n]['*']
    rule_disabled.each { |r, v| disabled[n][r] = true if v || next_line[n][r] }
  end
  disabled
end

def add_issue(list, disabled, item)
  return if disabled[item.line]['*'] || disabled[item.line][item.rule]
  list << item
end

def lint_file(file, cfg)
  raw = File.read(file)
  lines = raw.lines
  offsets = line_offsets(lines)
  disabled = disabled_lines(lines)
  issues = []
  rules = cfg[:rules].empty? ? DEFAULT_RULES : cfg[:rules].keys
  rules = rules.reject { |r| cfg[:rules].dig(r, :disabled) }
  severity_for = ->(r) { cfg[:rules].dig(r, :severity) || cfg[:severity] || 'warning' }

  if rules.include?('line-length-limit')
    limit = (cfg[:rules].dig('line-length-limit', :arguments)&.first || 80).to_i
    lines.each_with_index do |line, i|
      len = line.chomp.length
      next unless len > limit
      add_issue(issues, disabled, issue(file, i + 1, 0, "line is #{len} characters, out of limit #{limit}",
                                        'line-length-limit', severity_for.call('line-length-limit'), lines, offsets, len))
    end
  end

  if rules.include?('package-comments')
    pkg_idx = lines.index { |l| l =~ /^\s*package\s+(\w+)/ }
    if pkg_idx && Regexp.last_match(1) != 'main' && !comment_before?(lines, pkg_idx + 1, 'Package')
      add_issue(issues, disabled, issue(file, pkg_idx + 1, 1, 'should have a package comment',
                                        'package-comments', severity_for.call('package-comments'), lines, offsets, lines[pkg_idx].chomp.length + 1))
    end
  end

  if rules.include?('exported')
    lines.each_with_index do |line, i|
      if line =~ /^\s*func\s+(?:\([^)]*\)\s*)?([A-Z]\w*)\s*\(/
        name = Regexp.last_match(1)
        unless comment_before?(lines, i + 1, name)
          add_issue(issues, disabled, issue(file, i + 1, line.index('func').to_i + 1,
                                            "exported function #{name} should have comment or be unexported",
                                            'exported', severity_for.call('exported'), lines, offsets))
        end
      elsif line =~ /^\s*type\s+([A-Z]\w*)\b/
        name = Regexp.last_match(1)
        unless comment_before?(lines, i + 1, name)
          add_issue(issues, disabled, issue(file, i + 1, line.index('type').to_i + 1,
                                            "exported type #{name} should have comment or be unexported",
                                            'exported', severity_for.call('exported'), lines, offsets))
        end
      elsif line =~ /^\s*(?:var|const)\s+([A-Z]\w*)\b/
        name = Regexp.last_match(1)
        kind = line.strip.start_with?('var') ? 'var' : 'const'
        unless comment_before?(lines, i + 1, name)
          add_issue(issues, disabled, issue(file, i + 1, line.index(kind).to_i + 1,
                                            "exported #{kind} #{name} should have comment or be unexported",
                                            'exported', severity_for.call('exported'), lines, offsets))
        end
      end
    end
  end

  if rules.include?('unused-parameter')
    text = raw
    text.scan(/func\s+(?:\([^)]*\)\s*)?\w+\s*\(([^)]*)\)\s*(?:[^{]*)\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}/m) do |params, body|
      md = Regexp.last_match
      start_pos = md.begin(0)
      base_line = raw[0...start_pos].count("\n") + 1
      params.split(',').each do |param|
        part = param.strip
        next if part.empty?
        names = part.split(/\s+/).first.to_s.split(',').map(&:strip)
        names.each do |name|
          next if name.empty? || name == '_' || name =~ /^\W/
          next if body =~ /\b#{Regexp.escape(name)}\b/
          pos = raw.index(/\b#{Regexp.escape(name)}\b/, start_pos) || start_pos
          ln = raw[0...pos].count("\n") + 1
          col = pos - (raw.rindex("\n", pos) || -1)
          add_issue(issues, disabled, issue(file, ln, col, "parameter '#{name}' seems to be unused, consider removing or renaming it as _",
                                            'unused-parameter', severity_for.call('unused-parameter'), lines, offsets, col + name.length))
        end
      end
    end
  end

  if rules.include?('unreachable-code')
    lines.each_with_index do |line, i|
      next unless line =~ /^\s*(return|break|continue|fallthrough)\b/
      j = i + 1
      j += 1 while j < lines.length && (lines[j].strip.empty? || lines[j].strip.start_with?('//'))
      next if j >= lines.length || lines[j].strip.start_with?('}')
      add_issue(issues, disabled, issue(file, i + 1, line =~ /\S/ ? Regexp.last_match&.begin(0).to_i + 1 : 1,
                                        'unreachable code after this statement',
                                        'unreachable-code', severity_for.call('unreachable-code'), lines, offsets))
    end
  end

  lines.each_with_index do |line, i|
    if rules.include?('empty-block') && line =~ /\{\s*\}/
      add_issue(issues, disabled, issue(file, i + 1, line.index('{') + 1, 'this block is empty, you can remove it',
                                        'empty-block', severity_for.call('empty-block'), lines, offsets))
    end
    if rules.include?('blank-imports') && line =~ /import\s+(?:\(\s*)?_\s+"([^"]+)"/
      add_issue(issues, disabled, issue(file, i + 1, line.index('_') + 1, "a blank import should be only in a main or test package, or have a comment justifying it",
                                        'blank-imports', severity_for.call('blank-imports'), lines, offsets))
    end
    if rules.include?('dot-imports') && line =~ /import\s+(?:\(\s*)?\.\s+"([^"]+)"/
      add_issue(issues, disabled, issue(file, i + 1, line.index('.') + 1, "should not use dot imports",
                                        'dot-imports', severity_for.call('dot-imports'), lines, offsets))
    end
    if rules.include?('error-strings') && line =~ /errors\.New\("([A-Z][^"]*|[^"]*[.!?])"\)/
      add_issue(issues, disabled, issue(file, i + 1, line.index('errors.New') + 1, 'error strings should not be capitalized or end with punctuation or a newline',
                                        'error-strings', severity_for.call('error-strings'), lines, offsets))
    end
    if rules.include?('increment-decrement') && line =~ /\b(\w+)\s*(\+=\s*1|=\s*\1\s*\+\s*1)\b/
      add_issue(issues, disabled, issue(file, i + 1, line.index(Regexp.last_match(0)) + 1, "should replace #{Regexp.last_match(0).strip} with #{Regexp.last_match(1)}++",
                                        'increment-decrement', severity_for.call('increment-decrement'), lines, offsets))
    end
    if rules.include?('var-naming') && line =~ /\b(?:var|const|func|type)\s+([A-Za-z]\w*_\w*)\b/
      name = Regexp.last_match(1)
      add_issue(issues, disabled, issue(file, i + 1, line.index(name) + 1, "don't use underscores in Go names; #{name} should be #{name.split('_').map.with_index { |p, idx| idx.zero? ? p : p.capitalize }.join}",
                                        'var-naming', severity_for.call('var-naming'), lines, offsets))
    end
  end

  issues
end

def issue_hash(i)
  {
    Severity: i.severity,
    Failure: i.failure,
    RuleName: i.rule,
    Category: i.category,
    Position: {
      Start: { Filename: i.filename, Offset: i.offset, Line: i.line, Column: i.column },
      End: { Filename: i.filename, Offset: i.end_offset, Line: i.end_line, Column: i.end_column }
    },
    Confidence: i.confidence,
    ReplacementLine: ''
  }
end

def xml_escape(s)
  s.to_s.gsub('&', '&amp;').gsub('"', '&quot;').gsub('<', '&lt;').gsub('>', '&gt;')
end

def format_issues(formatter, issues, cfg)
  case formatter
  when nil, '', 'default'
    issues.map do |i|
      loc = i.column.to_i.zero? ? "#{i.filename}:#{i.line}:" : "#{i.filename}:#{i.line}:#{i.column}:"
      "#{loc} #{i.failure}"
    end.join("\n") + (issues.empty? ? '' : "\n")
  when 'plain'
    issues.map { |i| "#{i.filename}:#{i.line}: #{i.failure} https://revive.run/r##{i.rule}" }.join("\n") + (issues.empty? ? '' : "\n")
  when 'unix'
    issues.map { |i| "#{i.filename}:#{i.line}:#{i.column}: [#{i.rule}] #{i.failure}" }.join("\n") + (issues.empty? ? '' : "\n")
  when 'json'
    json_generate(issues.map { |i| issue_hash(i) }) + "\n"
  when 'ndjson'
    issues.map { |i| json_generate(issue_hash(i)) }.join("\n") + (issues.empty? ? '' : "\n\n")
  when 'friendly'
    return '' if issues.empty?
    body = issues.map do |i|
      mark = i.severity == 'error' ? '✘' : '⚠'
      "  #{mark}  https://revive.run/r##{i.rule}  #{i.failure}\n  #{i.filename}:#{i.line}:#{i.column}\n"
    end.join("\n")
    errors = issues.count { |i| i.severity == 'error' }
    warnings = issues.length - errors
    mark = errors.positive? ? '✘' : '⚠'
    counts = issues.group_by(&:rule).map { |r, a| "  #{a.length}  #{r}" }.join("\n")
    label = errors.positive? ? 'Errors' : 'Warnings'
    "#{body}\n#{mark} #{issues.length} problem#{issues.length == 1 ? '' : 's'} (#{errors} errors, #{warnings} warning#{warnings == 1 ? '' : 's'})\n\n#{label}:\n#{counts}\n\n"
  when 'stylish'
    return '' if issues.empty?
    body = issues.group_by(&:filename).map do |file, arr|
      file + "\n" + arr.map { |i| "  (#{i.line}, #{i.column})  https://revive.run/r##{i.rule}  #{i.failure}" }.join("\n") + "\n"
    end.join("\n")
    errors = issues.count { |i| i.severity == 'error' }
    warnings = issues.length - errors
    "#{body}\n ✖ #{issues.length} problem#{issues.length == 1 ? '' : 's'} (#{errors} errors) (#{warnings} warning#{warnings == 1 ? '' : 's'})\n"
  when 'checkstyle'
    grouped = issues.group_by(&:filename)
    out = +"<?xml version='1.0' encoding='UTF-8'?>\n<checkstyle version=\"5.0\">\n"
    grouped.each do |file, arr|
      out << "    <file name=\"#{xml_escape(file)}\">\n"
      arr.each do |i|
        out << "      <error line=\"#{i.line}\" column=\"#{i.column}\" message=\"#{xml_escape(i.failure)} (confidence #{i.confidence})\" severity=\"#{i.severity}\" source=\"revive/#{i.rule}\"/>\n"
      end
      out << "    </file>\n"
    end
    out << "</checkstyle>\n"
  when 'sarif'
    rules = issues.map(&:rule).uniq.map do |r|
      args = cfg[:rules].dig(r, :arguments)&.join(',') || ''
      { id: r, helpUri: "https://revive.run/r##{r}", properties: { arguments: args, severity: cfg[:rules].dig(r, :severity).to_s } }
    end
    results = issues.map do |i|
      { locations: [{ physicalLocation: { artifactLocation: { uri: i.filename }, region: { startLine: i.line } } }],
        message: { text: i.failure }, ruleId: i.rule }
    end
    json_pretty({ runs: [{ results: results, tool: { driver: { informationUri: 'https://revive.run', name: 'revive', rules: rules } } }], version: '2.1.0' }) + "\n"
  else
    puts "formatting - getting formatter: unknown formatter #{formatter}"
    exit 1
  end
end

opts = parse_args(ARGV)
if opts[:help]
  print usage
  exit 0
end
if opts[:version]
  puts "Version:\ta75b67b"
  puts "Commit:\t\ta75b67b73b9edb91dfc9f302dd108fa9d3ea5b05"
  puts "Built\t\t2026-04-17 19:59 UTC by build.sh"
  exit 0
end

config_path = opts[:config] || default_config_path
if config_path.nil?
  puts 'initializing revive - getting lint rules: cannot configure rule: "var-naming": load std packages: err: go command required, not found: exec: "go": executable file not found in $PATH: stderr: '
  exit 1
end

cfg = parse_config(config_path)
files = go_files(opts[:args], opts[:excludes])
issues = files.flat_map { |f| lint_file(f, cfg) }
print format_issues(opts[:formatter] || 'default', issues, cfg)

if opts[:set_exit_status] && !issues.empty?
  exit 1
end
exit 0
