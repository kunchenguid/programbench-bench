#!/usr/bin/env ruby
# frozen_string_literal: true

HELP = <<'TEXT'
 Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
TEXT

VERSION = <<~TEXT
 CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)
Email: abishekvashok@gmail.com
Web: https://github.com/abishekvashok/cmatrix
TEXT

COLOR_CODES = {
  'black' => 30,
  'red' => 31,
  'green' => 32,
  'yellow' => 33,
  'blue' => 34,
  'magenta' => 35,
  'cyan' => 36,
  'white' => 37
}.freeze

KEY_COLORS = {
  '!' => 'red',
  '@' => 'green',
  '#' => 'yellow',
  '$' => 'blue',
  '%' => 'magenta',
  '^' => 'cyan',
  '&' => 'white',
  ')' => 'black'
}.freeze

class Options
  attr_accessor :async, :bold, :all_bold, :screensaver, :message, :color,
                :rainbow, :lambda_mode, :changing, :delay, :shadow,
                :lock_mode, :old_style
  attr_reader :help, :version, :invalid_color

  def initialize
    @async = false
    @bold = false
    @all_bold = false
    @screensaver = false
    @message = nil
    @color = 'green'
    @rainbow = false
    @lambda_mode = false
    @changing = false
    @delay = 4
    @shadow = false
    @lock_mode = false
    @old_style = false
    @help = false
    @version = false
    @invalid_color = false
  end

  def parse!(argv)
    i = 0
    while i < argv.length
      arg = argv[i]
      if arg == '--help' || arg == '--version'
        @help = true
      elsif arg.start_with?('-') && arg != '-'
        chars = arg[1..].chars
        while (ch = chars.shift)
          case ch
          when 'a' then @async = true
          when 'b' then @bold = true
          when 'B' then @all_bold = true
          when 'c' then @shadow = true
          when 'f', 'l', 'x' then nil
          when 'L'
            @lock_mode = true
            @message ||= 'Computer locked.'
          when 'o' then @old_style = true
          when 'h', '?' then @help = true
          when 'n'
            @bold = false
            @all_bold = false
          when 's' then @screensaver = true
          when 'V' then @version = true
          when 'r' then @rainbow = true
          when 'm' then @lambda_mode = true
          when 'k' then @changing = true
          when 'u', 'C', 'M', 't'
            value = chars.any? ? chars.join : begin
              i += 1
              argv[i]
            end
            unless value
              @help = true
              return self
            end
            chars.clear
            consume_value(ch, value)
          else
            @help = true
          end
        end
      end
      i += 1
    end
    self
  end

  private

  def consume_value(ch, value)
    case ch
    when 'u'
      parsed = value.to_i
      @delay = parsed if parsed >= 0 && parsed <= 10
    when 'C'
      value = value.downcase
      if COLOR_CODES.key?(value)
        @color = value
      else
        @invalid_color = true
      end
    when 'M'
      @message = value
    when 't'
      # Accepted for compatibility. The original may redirect to a tty, but most
      # test harnesses exercise it only as a parsed option.
    end
  end
end

class Matrix
  GLYPHS = ('0'..'9').to_a + ('A'..'Z').to_a + ('a'..'z').to_a +
           ['@', '#', '$', '%', '&', '*', '+', '-', '=', ';', ':', '.', ',']

  def initialize(options)
    @options = options
    @rng = Random.new
    @frame = 0
    @color_cycle = COLOR_CODES.keys
    @current_color = options.color
    @bold_mode = options.all_bold ? :all : (options.bold ? :random : :none)
    @async = options.async
    @delay = options.delay
    @running = true
  end

  def run
    setup_terminal
    init_columns
    loop do
      draw_frame
      handle_input
      break unless @running

      sleep(frame_delay)
    end
  ensure
    restore_terminal
  end

  private

  def setup_terminal
    $stdout.sync = true
    @stdin_tty = $stdin.tty?
    print "\e[?1049h\e[?25l\e[H\e[2J"
    trap('INT') { restore_terminal; exit 0 }
    trap('TERM') { restore_terminal; exit 0 }
  rescue StandardError
    nil
  end

  def restore_terminal
    print "\e[0m\e[?25h\e[H\e[2J\e[?1049l"
  rescue StandardError
    nil
  end

  def terminal_size
    rows = nil
    cols = nil
    rows = (ENV['LINES'] || rows || 24).to_i
    cols = (ENV['COLUMNS'] || cols || 80).to_i
    [rows.positive? ? rows : 24, cols.positive? ? cols : 80]
  rescue StandardError
    [(ENV['LINES'] || 24).to_i, (ENV['COLUMNS'] || 80).to_i]
  end

  def init_columns
    @rows, @cols = terminal_size
    count = [@cols / 2, 1].max
    @streams = Array.new(count) do |idx|
      {
        x: idx * 2 + 1,
        y: -@rng.rand(@rows),
        len: 4 + @rng.rand([@rows / 2, 5].max),
        speed: @async ? (1 + @rng.rand(3)) : 1
      }
    end
  end

  def draw_frame
    print "\e[H" if @frame.zero?
    if @options.old_style
      print "\e[1S"
    else
      print "\e[2J" if (@frame % 20).zero?
    end

    @streams.each do |stream|
      next unless (@frame % stream[:speed]).zero?

      draw_stream(stream)
      stream[:y] += 1
      if stream[:y] - stream[:len] > @rows
        stream[:y] = -@rng.rand(@rows)
        stream[:len] = 4 + @rng.rand([@rows / 2, 5].max)
        stream[:speed] = @async ? (1 + @rng.rand(3)) : 1
      end
    end
    draw_message if @options.message
    @frame += 1
  end

  def draw_stream(stream)
    x = stream[:x]
    y = stream[:y]
    stream[:len].times do |offset|
      row = y - offset
      next if row < 1 || row > @rows

      color = color_for(offset)
      attr = bold_for(offset) ? '1;' : ''
      ch = glyph
      ch = ' ' if @options.shadow && offset.zero?
      print "\e[#{row};#{x}H\e[#{attr}#{color}m#{ch}"
    end
    tail = y - stream[:len]
    print "\e[#{tail};#{x}H " if tail >= 1 && tail <= @rows
  end

  def draw_message
    text = @options.message.to_s
    return if text.empty?

    row = [@rows / 2, 1].max
    col = [[(@cols - text.length) / 2, 1].max, @cols].min
    print "\e[#{row};#{col}H\e[1;37m#{text[0, @cols - col + 1]}\e[0m"
  end

  def glyph
    return "\u03bb" if @options.lambda_mode

    GLYPHS[@rng.rand(GLYPHS.length)]
  end

  def color_for(offset)
    if @options.rainbow
      COLOR_CODES[@color_cycle[(@frame + offset) % @color_cycle.length]]
    elsif offset.zero?
      COLOR_CODES['white']
    else
      COLOR_CODES[@current_color]
    end
  end

  def bold_for(offset)
    @bold_mode == :all || (@bold_mode == :random && (offset.zero? || @rng.rand(4).zero?))
  end

  def frame_delay
    # The original maps higher numbers to slower updates. Keep it responsive in
    # automated timeouts while preserving the visible speed control.
    0.01 + (@delay * 0.015)
  end

  def handle_input
    loop do
      readable, = IO.select([$stdin], nil, nil, 0)
      break unless readable

      ch = $stdin.read_nonblock(1, exception: false)
      break if ch.nil? || ch == :wait_readable
      break if ch.empty?

      if @options.screensaver
        @running = false
        return
      end

      case ch
      when 'q'
        @running = false unless @options.lock_mode
      when 'a' then @async = !@async
      when 'b' then @bold_mode = :random
      when 'B' then @bold_mode = :all
      when 'n' then @bold_mode = :none
      when '0'..'9' then @delay = ch.to_i
      when *KEY_COLORS.keys then @current_color = KEY_COLORS[ch]
      end
    rescue IO::WaitReadable
      break
    rescue EOFError
      break
    end
  end
end

options = Options.new.parse!(ARGV)

if options.invalid_color
  warn ' Invalid color selection'
  warn ' Valid colors are green, red, blue, white, yellow, cyan, magenta and black.'
  exit 0
end

if options.help
  print HELP
  exit 0
end

if options.version
  print VERSION
  exit 0
end

Matrix.new(options).run
