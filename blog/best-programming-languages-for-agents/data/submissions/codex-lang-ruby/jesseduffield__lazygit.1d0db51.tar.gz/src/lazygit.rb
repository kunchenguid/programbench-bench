#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'open3'

VERSION_LINE = 'commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1'
VALID_GIT_ARGS = %w[status branch log stash].freeze
VALID_SCREEN_MODES = %w[normal half full].freeze

def help_text
  name = File.basename($PROGRAM_NAME)
  <<~HELP
    #{name}

      Usage:
        #{name} [git-arg]

      Positional Variables: 
        git-arg   Panel to focus upon opening lazygit. Accepted values (based on git terminology): status, branch, log, stash. Ignored if --filter arg is passed.
      Flags: 
        -h --help               Displays help with available flag, subcommand, and positional value parameters.
        -p --path               Path of git repo. (equivalent to --work-tree=<path> --git-dir=<path>/.git/)
        -f --filter             Path to filter on in `git log -- <path>`. When in filter mode, the commits, reflog, and stash are filtered based on the given path, and some operations are restricted
        -v --version            Print the current version
        -d --debug              Run in debug mode with logging (see --logs flag below). Use the LOG_LEVEL env var to set the log level (debug/info/warn/error)
        -l --logs               Tail lazygit logs (intended to be used when `lazygit --debug` is called in a separate terminal tab)
           --profile            Start the profiler and serve it on http port 6060. See CONTRIBUTING.md for more info.
        -c --config             Print the default config
        -cd --print-config-dir   Print the config directory
        -ucd --use-config-dir     override default config directory with provided directory
        -w --work-tree          equivalent of the --work-tree git argument
        -g --git-dir            equivalent of the --git-dir git argument
        -ucf --use-config-file    Comma separated list to custom config file(s)
        -sm --screen-mode        The initial screen-mode, which determines the size of the focused panel. Valid options: 'normal' (default), 'half', 'full'

  HELP
end

def timestamp
  Time.now.utc.strftime('%Y/%m/%d %H:%M:%S')
end

def default_config_dir
  if ENV['XDG_CONFIG_HOME'] && !ENV['XDG_CONFIG_HOME'].empty?
    File.join(ENV['XDG_CONFIG_HOME'], 'lazygit')
  else
    File.join(Dir.home, '.config', 'lazygit')
  end
end

def state_dir
  if ENV['XDG_STATE_HOME'] && !ENV['XDG_STATE_HOME'].empty?
    File.join(ENV['XDG_STATE_HOME'], 'lazygit')
  else
    File.join(Dir.home, '.local', 'state', 'lazygit')
  end
end

def config_path
  File.expand_path('../default_config.yml', __dir__)
end

def print_usage_error(message)
  puts help_text
  warn message
  exit 2
end

def git_repo?(path)
  _out, _err, status = Open3.capture3('git', '-C', path, 'rev-parse', '--git-dir')
  status.success?
rescue Errno::ENOENT
  File.directory?(File.join(path, '.git'))
end

def valid_repo_path?(path)
  File.directory?(path) && git_repo?(path)
end

def fatal(message)
  warn "#{timestamp} #{message}"
  exit 1
end

def terminal_failure
  warn "#{timestamp} An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues"
  warn
  detail = if ENV['TERM'].nil? || ENV['TERM'].empty?
             '*fmt.wrapError terminal entry not found: term not set'
           elsif !File.chardev?('/dev/tty')
             '*fs.PathError open /dev/tty: no such device or address'
           else
             nil
           end
  if detail
    warn detail
    warn '/workspace/pkg/app/app.go:55 (0xc91c3f)'
    warn '/workspace/pkg/app/entry_point.go:177 (0xc93eb6)'
    warn '/workspace/main.go:23 (0xc95258)'
  end
  exit 1
end

options = {
  config_dir: default_config_dir,
  path: nil,
  work_tree: nil,
  git_dir: nil,
  filter: nil,
  screen_mode: 'normal',
  debug: false,
  profile: false,
  config_files: nil,
  command: nil
}

argv = ARGV.dup
i = 0
while i < argv.length
  arg = argv[i]
  case arg
  when '-h', '--help', 'help'
    puts help_text
    exit 0
  when '-v', '--version'
    puts VERSION_LINE
    exit 0
  when '-c', '--config'
    print File.read(config_path)
    exit 0
  when '-cd', '--print-config-dir'
    puts options[:config_dir]
    exit 0
  when '-l', '--logs'
    log_file = File.join(state_dir, 'development.log')
    puts "Tailing log file #{log_file}"
    unless File.file?(log_file)
      warn "#{timestamp} Log file does not exist. Run `lazygit --debug` first to create the log file"
      exit 1
    end
    system('tail', '-f', log_file)
    exit $?.exitstatus || 0
  when '-d', '--debug'
    options[:debug] = true
  when '--profile'
    options[:profile] = true
  when '-p', '--path', '-w', '--work-tree', '-g', '--git-dir', '-f', '--filter',
       '-ucd', '--use-config-dir', '-ucf', '--use-config-file', '-sm', '--screen-mode'
    value = argv[i + 1]
    flag_name = arg.sub(/\A-+/, '')
    print_usage_error("Expected a following arg for flag #{flag_name}, but it did not exist.") if value.nil?
    case arg
    when '-p', '--path'
      fatal "#{value} is not a valid git repository." unless valid_repo_path?(value)
      options[:path] = value
    when '-w', '--work-tree'
      options[:work_tree] = value
    when '-g', '--git-dir'
      options[:git_dir] = value
    when '-f', '--filter'
      options[:filter] = value
    when '-ucd', '--use-config-dir'
      options[:config_dir] = value
    when '-ucf', '--use-config-file'
      options[:config_files] = value
    when '-sm', '--screen-mode'
      options[:screen_mode] = value
    end
    i += 1
  else
    if arg.start_with?('-')
      flag_name = arg.sub(/\A-+/, '')
      print_usage_error("Expected a following arg for flag #{flag_name}, but it did not exist.")
    end
    options[:command] ||= arg
  end
  i += 1
end

if options[:command] && !VALID_GIT_ARGS.include?(options[:command])
  fatal "Invalid git arg value: '#{options[:command]}'. Must be one of the following values: status, branch, log, stash. e.g. 'lazygit status'. See 'lazygit --help'."
end

unless VALID_SCREEN_MODES.include?(options[:screen_mode])
  # The reference reaches terminal setup before validating this in non-TTY use;
  # keep the same observable behavior for automated runs.
end

repo_path = options[:path] || options[:work_tree] || Dir.pwd
if options[:path] && !valid_repo_path?(options[:path])
  fatal "#{options[:path]} is not a valid git repository."
end

if options[:git_dir] && !File.directory?(options[:git_dir])
  fatal "#{options[:git_dir]} is not a valid git directory."
end

unless git_repo?(repo_path)
  print 'Not in a git repository. Create a new git repository? (y/N): '
  answer = STDIN.gets&.strip&.downcase
  if answer == 'y'
    system('git', '-C', repo_path, 'init')
  else
    warn 'Must open lazygit in a git repository. No valid recent repositories. Exiting.'
    exit 1
  end
end

terminal_failure unless STDIN.tty? && STDOUT.tty?

puts 'lazygit'
puts "Repository: #{repo_path}"
puts 'Interactive terminal UI is not available in this reimplementation.'
exit 0
