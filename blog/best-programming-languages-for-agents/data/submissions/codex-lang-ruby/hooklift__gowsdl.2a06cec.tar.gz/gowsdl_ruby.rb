#!/usr/bin/env ruby
# frozen_string_literal: true

require 'rexml/document'
require 'fileutils'

class WsdlGen
  XSD = 'http://www.w3.org/2001/XMLSchema'
  WSDL = 'http://schemas.xmlsoap.org/wsdl/'

  Field = Struct.new(:name, :xml_name, :type, :doc, :array, :attr, :chardata, keyword_init: true)
  TypeDef = Struct.new(:name, :kind, :fields, :base, :enums, :xml_ns, :xml_name, :doc, keyword_init: true)

  def initialize(path, package:, make_public: true)
    @path = path
    @package = package
    @make_public = make_public
    @types = {}
    @messages = {}
    @operations = []
    @soap_actions = {}
    @schema_ns = nil
  end

  def generate
    text = read_input(@path)
    @doc = REXML::Document.new(text)
    parse_schemas
    parse_messages
    parse_bindings
    parse_port_types
    emit
  end

  private

  def read_input(path)
    if path =~ %r{\Ahttps?://}
      raise "network access is unavailable in this build"
    else
      File.read(path)
    end
  end

  def elems(node, name = nil)
    node.elements.to_a.select { |e| name.nil? || e.expanded_name.split(':').last == name || e.name == name }
  end

  def first(node, name)
    elems(node, name).first
  end

  def attr(node, name)
    node.attributes[name]
  end

  def doc_text(node)
    ann = first(node, 'annotation')
    d = first(ann, 'documentation') if ann
    return nil unless d
    s = d.text.to_s.strip.gsub(/\s+/, ' ')
    s.empty? ? nil : s
  end

  def parse_schemas
    all(@doc.root, 'schema').each do |schema|
      @schema_ns = attr(schema, 'targetNamespace') || @schema_ns
      elems(schema).each do |child|
        case local(child)
        when 'simpleType'
          parse_simple_type(child, attr(child, 'name'), @schema_ns)
        when 'complexType'
          parse_complex_type(child, attr(child, 'name'), @schema_ns, nil)
        when 'element'
          parse_top_element(child, @schema_ns)
        end
      end
    end
  end

  def all(node, name)
    out = []
    elems(node).each do |child|
      out << child if local(child) == name
      out.concat(all(child, name))
    end
    out
  end

  def local(node)
    node.expanded_name.split(':').last
  end

  def parse_top_element(el, ns)
    name = attr(el, 'name')
    return unless name
    if (ct = first(el, 'complexType'))
      td = parse_complex_type(ct, name, ns, name)
      td.xml_ns = ns
      td.xml_name = name
      td.doc = doc_text(el) || td.doc
      @types[td.name] = td
    elsif (st = first(el, 'simpleType'))
      parse_simple_type(st, name, ns, doc_text(el))
    elsif attr(el, 'type')
      alias_name = go_name(name)
      base_name = go_type(attr(el, 'type'), false)
      @types[alias_name] = TypeDef.new(name: alias_name, kind: :alias, base: base_name, fields: [], enums: [], xml_ns: ns, xml_name: name, doc: doc_text(el)) unless alias_name == base_name
    end
  end

  def parse_simple_type(st, raw_name, _ns, forced_doc = nil)
    return unless raw_name
    rest = first(st, 'restriction')
    base = rest ? attr(rest, 'base') : 'string'
    enums = []
    elems(rest || st, 'enumeration').each do |en|
      enums << [attr(en, 'value'), doc_text(en)]
    end
    kind = enums.empty? ? :alias : :enum
    @types[go_name(raw_name)] = TypeDef.new(name: go_name(raw_name), kind: kind, base: go_type(base, false), fields: [], enums: enums, doc: forced_doc || doc_text(st))
  end

  def parse_complex_type(ct, raw_name, ns, _xml_name)
    name = go_name(raw_name || 'Anonymous')
    fields = []
    container = first(ct, 'sequence') || first(ct, 'all') || first(ct, 'choice')
    elems(container || ct, 'element').each do |el|
      fields << element_field(el, ns)
    end
    elems(ct, 'attribute').each do |at|
      fields << attribute_field(at, ns)
    end
    if (sc = first(first(ct, 'simpleContent') || ct, 'extension'))
      # no-op fallback; handled by extension below where present
    end
    if (simp = first(ct, 'simpleContent')) && (ext = first(simp, 'extension'))
      fields.unshift(Field.new(name: 'Value', xml_name: '', type: go_type(attr(ext, 'base') || 'string', false), chardata: true))
      elems(ext, 'attribute').each { |at| fields << attribute_field(at, ns) }
    end
    td = TypeDef.new(name: name, kind: :struct, fields: fields, enums: [], xml_ns: ns, doc: doc_text(ct))
    @types[name] = td if raw_name
    td
  end

  def element_field(el, ns)
    raw = attr(el, 'name') || attr(el, 'ref').to_s.split(':').last
    typ = attr(el, 'type')
    doc = doc_text(el)
    array = attr(el, 'maxOccurs') == 'unbounded' || attr(el, 'maxOccurs').to_i > 1
    if !typ && (st = first(el, 'simpleType'))
      rest = first(st, 'restriction')
      enums = elems(rest || st, 'enumeration')
      if enums.empty?
        typ = attr(rest || st, 'base') || 'string'
      else
        typ_name = go_name(raw)
        parse_simple_type(st, raw, ns, doc)
        typ = typ_name
      end
    elsif !typ && (ct = first(el, 'complexType'))
      anon_fields = []
      if (simp = first(ct, 'simpleContent')) && (ext = first(simp, 'extension'))
        anon_fields << Field.new(name: 'Value', xml_name: '', type: go_type(attr(ext, 'base') || 'string', false), chardata: true)
        elems(ext, 'attribute').each { |at| anon_fields << attribute_field(at, ns) }
      else
        cont = first(ct, 'sequence') || first(ct, 'all') || first(ct, 'choice')
        elems(cont || ct, 'element').each { |sub| anon_fields << element_field(sub, ns) }
      end
      typ = "struct {\n#{anon_fields.map { |f| field_line(f, 1) }.join("\n")}\n}"
    end
    ptr = custom_pointer?(typ) && !typ.to_s.start_with?('struct')
    Field.new(name: go_name(raw), xml_name: raw, type: go_type(typ || 'string', ptr), doc: doc, array: array)
  end

  def attribute_field(at, ns)
    raw = attr(at, 'name') || attr(at, 'ref').to_s.split(':').last
    Field.new(name: go_name(raw), xml_name: "#{ns} #{raw},attr,omitempty", type: go_type(attr(at, 'type') || 'string', false), attr: true)
  end

  def parse_messages
    all(@doc.root, 'message').each do |msg|
      part = first(msg, 'part')
      next unless part
      @messages[attr(msg, 'name')] = (attr(part, 'element') || attr(part, 'type')).to_s.split(':').last
    end
  end

  def parse_bindings
    all(@doc.root, 'binding').each do |binding|
      elems(binding, 'operation').each do |op|
        soap_op = elems(op).find { |e| local(e) == 'operation' && e.namespace == 'http://schemas.xmlsoap.org/wsdl/soap/' }
        @soap_actions[attr(op, 'name')] = soap_op ? (attr(soap_op, 'soapAction') || "''") : "''"
      end
    end
  end

  def parse_port_types
    all(@doc.root, 'portType').each do |pt|
      iface = go_name(attr(pt, 'name'))
      elems(pt, 'operation').each do |op|
        input = first(op, 'input')
        output = first(op, 'output')
        @operations << {
          iface: iface,
          op: go_name(attr(op, 'name')),
          req: go_name(@messages[(attr(input, 'message') || '').split(':').last] || 'AnyType'),
          resp: go_name(@messages[(attr(output, 'message') || '').split(':').last] || 'AnyType'),
          action: @soap_actions[attr(op, 'name')] || "''"
        }
      end
    end
  end

  def go_name(s)
    s = s.to_s
    parts = s.gsub(/[^A-Za-z0-9]+/, ' ').split
    out = parts.map do |p|
      p = p.gsub(/\A[0-9]+/, '')
      p.empty? ? '' : p[0].upcase + p[1..]
    end.join
    out.empty? ? 'Value' : out
  end

  def unexport(s)
    s[0].downcase + s[1..]
  end

  def go_type(xsd_type, ptr = false)
    return xsd_type if xsd_type.to_s.start_with?('struct')
    raw = xsd_type.to_s.split(':').last
    t = case raw
        when 'string', 'normalizedString', 'token', 'language' then 'string'
        when 'boolean' then 'bool'
        when 'float' then 'float32'
        when 'double', 'decimal' then 'float64'
        when 'int', 'integer', 'long', 'short', 'byte', 'unsignedInt', 'unsignedLong', 'unsignedShort', 'unsignedByte', 'nonNegativeInteger', 'positiveInteger' then 'int'
        when 'dateTime', 'date', 'time' then 'soap.XSDDateTime'
        when 'base64Binary', 'hexBinary' then '[]byte'
        when 'anyType' then 'AnyType'
        when 'anyURI' then 'AnyURI'
        when 'NCName' then 'NCName'
        when '' then 'string'
        else go_name(raw)
        end
    ptr && custom_pointer?(xsd_type) && !t.start_with?('[]') ? "*#{t}" : t
  end

  def custom_pointer?(typ)
    return false if typ.nil?
    raw = typ.to_s.split(':').last
    return false if %w[string normalizedString token language boolean float double decimal int integer long short byte unsignedInt unsignedLong unsignedShort unsignedByte nonNegativeInteger positiveInteger dateTime date time base64Binary hexBinary anyType anyURI NCName].include?(raw)
    td = @types[go_name(raw)]
    return td.kind == :struct if td
    true
  end

  def emit
    grouped = @operations.group_by { |o| o[:iface] }
    out = +"// Code generated by gowsdl DO NOT EDIT.\n\n"
    out << "package #{@package}\n\n"
    out << "import (\n\t\"context\"\n\t\"encoding/xml\"\n\t\"github.com/hooklift/gowsdl/soap\"\n\t\"time\"\n)\n\n"
    out << "// against \"unused imports\"\nvar _ time.Time\nvar _ xml.Name\n\n"
    out << "type AnyType struct {\n\tInnerXML string `xml:\",innerxml\"`\n}\n\n"
    out << "type AnyURI string\n\n"
    out << "type NCName string\n\n"
    @types.each_value { |td| out << emit_type(td) }
    grouped.each { |iface, ops| out << emit_service(iface, ops) }
    out
  end

  def emit_type(td)
    case td.kind
    when :struct
      s = +"type #{td.name} struct {\n"
      if td.xml_name
        s << "\tXMLName xml.Name `xml:\"#{td.xml_ns} #{td.xml_name}\"`\n"
        s << "\n" unless td.fields.empty?
      end
      td.fields.each { |f| s << field_line(f, 0) << "\n" }
      s << "}\n\n"
    when :enum
      s = +"type #{td.name} #{td.base}\n\nconst (\n"
      td.enums.each do |val, doc|
        s << "\n\t// #{doc}\n" if doc
        s << "\t#{td.name}#{go_name(val)} #{td.name} = #{val.inspect}\n\n"
      end
      s << ")\n\n"
    else
      s = +"type #{td.name} #{td.base}\n\n"
      if td.base == 'soap.XSDDateTime'
        s << "func (xdt #{td.name}) MarshalXML(e *xml.Encoder, start xml.StartElement) error {\n\treturn soap.XSDDateTime(xdt).MarshalXML(e, start)\n}\n\n"
        s << "func (xdt *#{td.name}) UnmarshalXML(d *xml.Decoder, start xml.StartElement) error {\n\treturn (*soap.XSDDateTime)(xdt).UnmarshalXML(d, start)\n}\n\n"
      end
    end
    s
  end

  def field_line(f, extra_tabs)
    tabs = "\t" * (1 + extra_tabs)
    s = +''
    s << "#{tabs}// #{f.doc}\n\n" if f.doc
    typ = f.type
    typ = "[]#{typ.sub(/\A\*/, '')}" if f.array
    tag = if f.chardata
            'xml:",chardata" json:"-,"'
          else
            xml = f.attr ? f.xml_name : "#{f.xml_name},omitempty"
            json_name = f.attr ? f.xml_name.to_s.split(/[ ,]/)[1].to_s.split(',').first : f.xml_name
            json = "#{json_name},omitempty"
            "xml:\"#{xml}\" json:\"#{json}\""
          end
    s << "#{tabs}#{@make_public ? f.name : unexport(f.name)} #{typ} `#{tag}`"
    s
  end

  def emit_service(iface, ops)
    recv_type = unexport(iface)
    s = +"type #{iface} interface {\n"
    ops.each do |o|
      s << "\t#{o[:op]}(request *#{o[:req]}) (*#{o[:resp]}, error)\n\n"
      s << "\t#{o[:op]}Context(ctx context.Context, request *#{o[:req]}) (*#{o[:resp]}, error)\n"
    end
    s << "}\n\n"
    s << "type #{recv_type} struct {\n\tclient *soap.Client\n}\n\n"
    s << "func New#{iface}(client *soap.Client) #{iface} {\n\treturn &#{recv_type}{\n\t\tclient: client,\n\t}\n}\n\n"
    ops.each do |o|
      s << "func (service *#{recv_type}) #{o[:op]}Context(ctx context.Context, request *#{o[:req]}) (*#{o[:resp]}, error) {\n"
      s << "\tresponse := new(#{o[:resp]})\n"
      s << "\terr := service.client.CallContext(ctx, #{o[:action].inspect}, request, response)\n"
      s << "\tif err != nil {\n\t\treturn nil, err\n\t}\n\n\treturn response, nil\n}\n\n"
      s << "func (service *#{recv_type}) #{o[:op]}(request *#{o[:req]}) (*#{o[:resp]}, error) {\n"
      s << "\treturn service.#{o[:op]}Context(\n\t\tcontext.Background(),\n\t\trequest,\n\t)\n}\n\n"
    end
    s
  end
end

def usage
  <<~TXT
    Usage: ./executable [options] myservice.wsdl
      -d string
    \t\tDirectory under which package directory will be created (default "./")
      -i\tSkips TLS Verification
      -make-public
    \t\tMake the generated types public/exported (default true)
      -o string
    \t\tFile where the generated code will be saved (default "myservice.go")
      -p string
    \t\tPackage under which code will be generated (default "myservice")
      -v\tShows gowsdl version
  TXT
end

opts = { d: './', o: 'myservice.go', p: 'myservice', make_public: true }
args = ARGV.dup
files = []
until args.empty?
  a = args.shift
  case a
  when '--help', '-h'
    print usage
    exit 0
  when '-v'
    puts "🍀  v0.5.0"
    exit 0
  when '-i'
  when '-d'
    opts[:d] = args.shift || ''
  when '-o'
    opts[:o] = args.shift || ''
  when '-p'
    opts[:p] = args.shift || ''
  when '-make-public'
    opts[:make_public] = true
  when /\A-make-public=(.*)\z/
    opts[:make_public] = Regexp.last_match(1) != 'false'
  when /\A-/
    warn "flag provided but not defined: #{a}"
    print usage
    exit 2
  else
    files << a
  end
end

if files.empty?
  print usage
  exit 0
end

input = files.first
display = input =~ %r{\A/|https?://} ? input : File.expand_path(input)
puts "🍀  Reading file #{display}"
begin
  code = WsdlGen.new(input, package: opts[:p], make_public: opts[:make_public]).generate
  outdir = File.join(opts[:d], opts[:p])
  FileUtils.mkdir_p(outdir) if File.directory?(opts[:d])
  outfile = File.join(outdir, opts[:o])
  File.write(outfile, code)
  system('gofmt', '-w', outfile, out: File::NULL, err: File::NULL) if File.exist?(outfile)
  puts "🍀  Done 👍"
rescue StandardError => e
  puts "🍀  #{e.message}"
  exit 1
end
