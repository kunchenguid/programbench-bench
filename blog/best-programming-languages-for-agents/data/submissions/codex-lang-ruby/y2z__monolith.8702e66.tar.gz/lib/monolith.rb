#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require 'base64'
require 'cgi'
require 'fileutils'
require 'time'
require 'uri'

VERSION = '2.11.0'
BANNER = <<~TXT
   _____    _____________   __________     ___________________    ___
  |     \\  /             \\ |          |   |                   |  |   |
  |      \\/       __      \\|    __    |   |    ___     ___    |__|   |
  |              |  |          |  |   |   |   |   |   |   |          |
  |   |\\    /|   |__|          |__|   |___|   |   |   |   |    __    |
  |   | \\__/ |          |\\                    |   |   |   |   |  |   |
  |___|      |__________| \\___________________|   |___|   |___|  |___|
TXT

HELP = "#{BANNER}\nmonolith #{VERSION}\n\nCLI tool and library for saving web pages as a single HTML file\n\n" \
       "Usage: executable [OPTIONS] <TARGET>\n\n" \
       "Arguments:\n  <TARGET>  URL or file path, use - for STDIN\n\n" \
       "Options:\n" \
       "  -a, --no-audio                      Remove audio sources\n" \
       "  -b, --base-url <http://localhost/>  Set custom base URL\n" \
       "  -B, --blacklist-domains             Treat specified domains as blacklist\n" \
       "  -c, --no-css                        Remove CSS\n" \
       "  -C, --cookie-file <cookies.txt>     Specify cookie file\n" \
       "  -d, --domain <example.com>          Specify domains to use for white/black-listing\n" \
       "  -e, --ignore-errors                 Ignore network errors\n" \
       "  -E, --encoding <UTF-8>              Enforce custom charset\n" \
       "  -f, --no-frames                     Remove frames and iframes\n" \
       "  -F, --no-fonts                      Remove fonts\n" \
       "  -i, --no-images                     Remove images\n" \
       "  -I, --isolate                       Cut off document from the Internet\n" \
       "  -j, --no-js                         Remove JavaScript\n" \
       "  -k, --insecure                      Allow invalid X.509 (TLS) certificates\n" \
       "  -m, --mhtml                         Use MHTML as output format\n" \
       "  -M, --no-metadata                   Exclude timestamp and source information\n" \
       "  -n, --unwrap-noscript               Replace NOSCRIPT elements with their contents\n" \
       "  -o, --output <result.html>          File to write to, use - for STDOUT\n" \
       "  -q, --quiet                         Suppress verbosity\n" \
       "  -t, --timeout <60>                  Adjust network request timeout\n" \
       "  -u, --user-agent <Firefox>          Set custom User-Agent string\n" \
       "  -v, --no-video                      Remove video sources\n" \
       "  -h, --help                          Print help\n" \
       "  -V, --version                       Print version\n"

PLACEHOLDER_PNG = 'data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%0D%00%00%00%0D%08%04%00%00%00%D8%E2%2C%F7%00%00%00%11IDATx%DAcd%C0%09%18G%A5%28%96%02%00%0A%F8%00%0E%CB%8A%EB%16%00%00%00%00IEND%AEB%60%82'

MIME = {
  '.html' => 'text/html', '.htm' => 'text/html', '.css' => 'text/css',
  '.js' => 'application/javascript', '.mjs' => 'application/javascript',
  '.png' => 'image/png', '.jpg' => 'image/jpeg', '.jpeg' => 'image/jpeg',
  '.gif' => 'image/gif', '.svg' => 'image/svg+xml', '.webp' => 'image/webp',
  '.ico' => 'image/x-icon', '.txt' => 'text/plain', '.woff' => 'font/woff',
  '.woff2' => 'font/woff2', '.ttf' => 'font/ttf', '.otf' => 'font/otf',
  '.mp4' => 'video/mp4', '.webm' => 'video/webm', '.mp3' => 'audio/mpeg',
  '.wav' => 'audio/wav', '.ogg' => 'audio/ogg'
}.freeze

def die(message, code = 1)
  warn message
  exit code
end

def parse_args(argv)
  opts = {
    domains: [], output: nil, base_url: nil, no_audio: false, no_css: false,
    no_frames: false, no_fonts: false, no_images: false, isolate: false,
    no_js: false, no_video: false, mhtml: false, no_metadata: false, unwrap: false, quiet: false,
    ignore_errors: false, blacklist: false, timeout: 60, encoding: nil
  }
  target = nil
  i = 0
  needs = {
    '-b' => [:base_url, '--base-url <http://localhost/>'], '--base-url' => [:base_url, '--base-url <http://localhost/>'],
    '-C' => [:cookie_file, '--cookie-file <cookies.txt>'], '--cookie-file' => [:cookie_file, '--cookie-file <cookies.txt>'],
    '-d' => [:domain, '--domain <example.com>'], '--domain' => [:domain, '--domain <example.com>'],
    '-E' => [:encoding, '--encoding <UTF-8>'], '--encoding' => [:encoding, '--encoding <UTF-8>'],
    '-o' => [:output, '--output <result.html>'], '--output' => [:output, '--output <result.html>'],
    '-t' => [:timeout, '--timeout <60>'], '--timeout' => [:timeout, '--timeout <60>'],
    '-u' => [:user_agent, '--user-agent <Firefox>'], '--user-agent' => [:user_agent, '--user-agent <Firefox>']
  }
  flags = {
    '-a' => :no_audio, '--no-audio' => :no_audio, '-B' => :blacklist, '--blacklist-domains' => :blacklist,
    '-c' => :no_css, '--no-css' => :no_css, '-e' => :ignore_errors, '--ignore-errors' => :ignore_errors,
    '-f' => :no_frames, '--no-frames' => :no_frames, '-F' => :no_fonts, '--no-fonts' => :no_fonts,
    '-i' => :no_images, '--no-images' => :no_images, '-I' => :isolate, '--isolate' => :isolate,
    '-j' => :no_js, '--no-js' => :no_js, '-k' => :insecure, '--insecure' => :insecure,
    '-m' => :mhtml, '--mhtml' => :mhtml, '-M' => :no_metadata, '--no-metadata' => :no_metadata,
    '-n' => :unwrap, '--unwrap-noscript' => :unwrap, '-q' => :quiet, '--quiet' => :quiet,
    '-v' => :no_video, '--no-video' => :no_video
  }

  while i < argv.length
    a = argv[i]
    if a =~ /\A--([^=]+)=(.*)\z/
      candidate = "--#{Regexp.last_match(1)}"
      if needs.key?(candidate)
        argv[i, 1] = [candidate, Regexp.last_match(2)]
        a = argv[i]
      end
    end
    if a == '--'
      i += 1
      target = argv[i] if i < argv.length
    elsif a == '-h' || a == '--help'
      puts HELP
      exit 0
    elsif a == '-V' || a == '--version'
      puts "monolith #{VERSION}"
      exit 0
    elsif a =~ /\A-[A-Za-z]{2,}\z/ && a.chars.drop(1).all? { |ch| flags.key?("-#{ch}") }
      a.chars.drop(1).each { |ch| opts[flags["-#{ch}"]] = true }
    elsif needs.key?(a)
      key, pretty = needs[a]
      i += 1
      die("error: a value is required for '#{pretty}' but none was supplied\n\nFor more information, try '--help'.", 2) if i >= argv.length
      val = argv[i]
      if key == :domain
        opts[:domains] << val
      elsif key == :timeout
        die("error: invalid value '#{val}' for '--timeout <60>': invalid digit found in string\n\nFor more information, try '--help'.", 2) unless val =~ /^\d+$/
        opts[:timeout] = val.to_i
      else
        opts[key] = val
      end
    elsif flags.key?(a)
      opts[flags[a]] = true
    elsif a.start_with?('-') && a != '-'
      die("error: unexpected argument '#{a}' found\n\n  tip: to pass '#{a}' as a value, use '-- #{a}'\n\nUsage: executable [OPTIONS] <TARGET>\n\nFor more information, try '--help'.", 2)
    else
      die("error: unexpected argument '#{a}' found\n\nUsage: executable [OPTIONS] <TARGET>\n\nFor more information, try '--help'.", 2) if target
      target = a
    end
    i += 1
  end
  unless target
    die("error: the following required arguments were not provided:\n  <TARGET>\n\nUsage: executable <TARGET>\n\nFor more information, try '--help'.", 2)
  end
  if opts[:encoding] && opts[:encoding] !~ /\A(?:utf-?8|us-ascii|ascii|iso-8859-1|windows-1252)\z/i
    die(%(Error: unknown encoding "#{opts[:encoding]}"))
  end
  [opts, target]
end

def file_url(path)
  'file://' + File.expand_path(path)
end

def log_url(url, opts)
  warn url unless opts[:quiet]
end

def mime_for(path)
  MIME.fetch(File.extname(path).downcase, 'text/plain')
end

def data_url_for(path, opts, missing_kind = nil)
  if path =~ /\Adata:/i
    return path
  end
  real = path.sub(/\Afile:\/\//, '')
  log_url(file_url(real), opts)
  unless File.file?(real)
    warn "#{file_url(real)} (file not found)" unless opts[:quiet]
    return PLACEHOLDER_PNG if missing_kind == :image
    return 'data:text/plain;base64,'
  end
  data = File.binread(real)
  "data:#{mime_for(real)};base64,#{Base64.strict_encode64(data)}"
end

def resolve_ref(ref, base_dir, base_url = nil)
  return ref if ref.nil? || ref.empty? || ref =~ /\A(?:data|javascript|mailto|tel|about):/i
  return ref if ref =~ %r{\Ahttps?://}i
  return ref.sub(/\Afile:\/\//, '') if ref =~ /\Afile:\/\//i
  if base_url && base_url =~ /\Afile:\/\//i
    return File.expand_path(ref, base_url.sub(/\Afile:\/\//i, ''))
  end
  File.expand_path(CGI.unescape(ref), base_dir)
end

def fetch_text_asset(path, opts, base_dir)
  return '' if path =~ %r{\Ahttps?://}i
  real = path.sub(/\Afile:\/\//, '')
  log_url(file_url(real), opts)
  return '' unless File.file?(real)
  text = File.binread(real).force_encoding('UTF-8')
  process_css(text, File.dirname(real), opts)
end

def process_css(css, base_dir, opts)
  css = css.gsub(/@font-face\s*\{.*?\}/mi, '') if opts[:no_fonts]
  css.gsub(/url\((['"]?)(.*?)\1\)/mi) do
    raw = Regexp.last_match(2).strip
    if opts[:no_images] && raw !~ /\.(?:woff2?|ttf|otf)(?:[?#].*)?\z/i
      "url(\"#{PLACEHOLDER_PNG}\")"
    else
      path = resolve_ref(raw, base_dir)
      "url(\"#{data_url_for(path, opts)}\")"
    end
  end
end

def add_meta(html, opts)
  policies = []
  policies << "default-src 'unsafe-eval' 'unsafe-inline' data:;" if opts[:isolate]
  policies << "style-src 'none';" if opts[:no_css]
  policies << "script-src 'none';" if opts[:no_js] || opts[:mhtml]
  policies << "frame-src 'none'; child-src 'none';" if opts[:no_frames]
  policies << "font-src 'none';" if opts[:no_fonts]
  policies << "img-src data:;" if opts[:no_images]
  insert = +''
  policies.each { |p| insert << %(<meta http-equiv="Content-Security-Policy" content="#{p}"></meta>) }
  insert << '<meta name="robots" content="none"></meta>'
  if html =~ /<head[^>]*>/i
    html.sub(/<head[^>]*>/i) { |h| h + insert }
  elsif html =~ /<html[^>]*>/i
    html.sub(/<html[^>]*>/i) { |h| h + '<head>' + insert + '</head>' }
  else
    '<head>' + insert + '</head>' + html
  end
end

def transform(html, base_dir, opts, source_url)
  html = html.dup
  html.gsub!(/<noscript\b[^>]*>(.*?)<\/noscript>/mi) { "<!--noscript-->#{$1}<!--/noscript-->" } if opts[:unwrap]

  if opts[:no_css]
    html.gsub!(/<style\b([^>]*)>.*?<\/style>/mi, '<style\1></style>')
    html.gsub!(/(<link\b[^>]*rel=["']?stylesheet["']?[^>]*?)\s+href=(["']).*?\2/mi, '\1')
  else
    html.gsub!(/<link\b([^>]*?)href=(["'])(.*?)\2([^>]*)>/mi) do
      pre, q, href, post = Regexp.last_match.captures
      if (pre + post) =~ /rel=(["']?)stylesheet\1/i || href =~ /\.css(?:[?#].*)?$/i
        css = fetch_text_asset(resolve_ref(href, base_dir, opts[:base_url]), opts, base_dir)
        %(<link#{pre}href=#{q}data:text/css;base64,#{Base64.strict_encode64(css)}#{q}#{post}>)
      else
        Regexp.last_match(0)
      end
    end
    html.gsub!(/<style\b([^>]*)>(.*?)<\/style>/mi) { "<style#{$1}>#{opts[:no_fonts] ? $2.gsub(/@font-face\s*\{.*?\}/mi, '') : $2}</style>" }
  end

  html.gsub!(/<script\b([^>]*)\bsrc=(["'])(.*?)\2([^>]*)>\s*<\/script>/mi) do
    if opts[:no_js] || opts[:mhtml]
      "<script#{$1}#{$4}></script>"
    else
      path = resolve_ref($3, base_dir, opts[:base_url])
      body = path =~ %r{\Ahttps?://}i ? '' : (log_url(file_url(path), opts); File.file?(path) ? File.binread(path) : '')
      "<script#{$1}#{$4}>#{body}</script>"
    end
  end
  html.gsub!(/<script\b([^>]*)>.*?<\/script>/mi, '<script\1></script>') if opts[:no_js] || opts[:mhtml]

  html.gsub!(/\s(src|poster|background)=(["'])(.*?)\2/mi) do
    attr, q, val = Regexp.last_match.captures
    before = Regexp.last_match.pre_match[-20, 20] || ''
    tag = before[/<(\w+)[^<]*\z/i, 1].to_s.downcase
    if (opts[:no_images] && %w[img image input body].include?(tag)) ||
       (opts[:no_frames] && %w[iframe frame].include?(tag)) ||
       (opts[:no_video] && tag == 'video') ||
       (opts[:no_audio] && tag == 'audio')
      %( #{attr}=#{q}#{tag == 'img' || attr == 'background' ? PLACEHOLDER_PNG : ''}#{q})
    elsif %w[img input body iframe frame video audio source track].include?(tag)
      kind = %w[img input body source].include?(tag) ? :image : nil
      %( #{attr}=#{q}#{data_url_for(resolve_ref(val, base_dir, opts[:base_url]), opts, kind)}#{q})
    else
      if attr == 'href' && val !~ /\A(?:https?|data|mailto|javascript|#)/i
        %( #{attr}=#{q}#{file_url(resolve_ref(val, base_dir, opts[:base_url]))}#{q})
      else
        Regexp.last_match(0)
      end
    end
  end

  html.gsub!(/\ssrcset=(["'])(.*?)\1/mi) do
    q, val = Regexp.last_match.captures
    parts = val.split(/\s*,\s*/).map do |entry|
      url, desc = entry.split(/\s+/, 2)
      "#{data_url_for(resolve_ref(url, base_dir, opts[:base_url]), opts, :image)}#{desc ? " #{desc}" : ''}"
    end
    %( srcset=#{q}#{parts.join(', ')}#{q})
  end

  html.gsub!(/\shref=(["'])(.*?)\1/mi) do
    q, val = Regexp.last_match.captures
    if val =~ /\A(?:https?|data|mailto|javascript|#)/i
      Regexp.last_match(0)
    else
      %( href=#{q}#{file_url(resolve_ref(val, base_dir, opts[:base_url]))}#{q})
    end
  end

  html = add_meta(html, opts)
  html = html.sub(/<head>/i, %(<head><base href="#{opts[:base_url]}"></base>)) if opts[:base_url] && source_url == 'STDIN' && html !~ /<base\b/i
  unless opts[:no_metadata]
    stamp = Time.now.utc.iso8601
    src = source_url == 'STDIN' ? 'STDIN' : (source_url.start_with?('file://') ? 'local source' : source_url)
    html = "<!-- Saved from #{src} at #{stamp} using monolith v#{VERSION} -->\n" + html
  end
  html
end

def title_for(html)
  CGI.unescapeHTML(html[/<title[^>]*>(.*?)<\/title>/mi, 1].to_s.strip).gsub(/[\/\\:*?"<>|]/, '_')
end

opts, target = parse_args(ARGV)
raw = nil
base_dir = Dir.pwd
source_url = target

if target == '-'
  raw = STDIN.read
  source_url = 'STDIN'
  if opts[:base_url]&.start_with?('file://')
    base_dir = opts[:base_url].sub(/\Afile:\/\//, '')
  end
elsif target =~ %r{\Ahttps?://}i
  die("Error: network access is unavailable in this build")
else
  path = File.expand_path(target)
  die("Error: file not found: #{target}") unless File.file?(path)
  log_url(file_url(path), opts)
  raw = File.binread(path).force_encoding('UTF-8')
  base_dir = File.dirname(path)
  source_url = file_url(path)
end

result = transform(raw, base_dir, opts, source_url)
if opts[:mhtml]
  result = "MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary=\"----=_NextPart_000_0000\"\r\n\r\n" \
           "------=_NextPart_000_0000\r\nContent-Type: text/html; charset=\"utf-8\"\r\nContent-Location: http://example.com/\r\n\r\n" \
           "#{result}\r\n------=_NextPart_000_0000--\r\n"
end

out = opts[:output]
if out && out != '-'
  stamp = Time.now.utc.iso8601.tr(':', '_')
  out = out.gsub('%title%', title_for(raw)).gsub('%timestamp%', stamp)
  File.write(out, result)
else
  STDOUT.write(result)
  STDOUT.write("\n") unless result.end_with?("\n")
end
