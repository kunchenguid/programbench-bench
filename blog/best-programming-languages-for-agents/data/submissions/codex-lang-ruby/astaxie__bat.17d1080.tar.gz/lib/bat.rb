#!/usr/bin/env ruby

require "base64"
require "json"
require "net/http"
require "openssl"
require "socket"
require "uri"

HELP = <<~TXT
  bat is a Go implemented CLI cURL-like tool for humans.

  Usage:

  \tbat [flags] [METHOD] URL [ITEM [ITEM]]

  flags:
    -a, -auth=USER[:PASS]       Pass a username:password pair as the argument
    -b, -bench=false            Sends bench requests to URL
    -b.N=1000                   Number of requests to run
    -b.C=100                    Number of requests to run concurrently
    -body=""                    Send RAW data as body
    -f, -form=false             Submitting the data as a form
    -j, -json=true              Send the data in a JSON object
    -p, -pretty=true            Print Json Pretty Format
    -i, -insecure=false         Allow connections to SSL sites without certs
    -proxy=PROXY_URL            Proxy with host and port
    -print="A"                  String specifying what the output should contain, default will print all information
           "H" request headers
           "B" request body
           "h" response headers
           "b" response body
    -v, -version=true           Show Version Number

  METHOD:
    bat defaults to either GET (if there is no request data) or POST (with request data).

  URL:
    The only information needed to perform a request is a URL. The default scheme is http://,
    which can be omitted from the argument; example.org works just fine.

  ITEM:
    Can be any of:
      Query string   key=value
      Header         key:value
      Post data      key=value
      File upload    key@/path/file

  Example:

  \tbat beego.me

  more help information please refer to https://github.com/astaxie/bat

TXT

METHODS = %w[GET POST PUT DELETE PATCH HEAD OPTIONS].freeze

def usage_exit(prefix = nil)
  warn prefix if prefix
  $stdout.write HELP
  exit 2
end

def log_fatal(file_line, message)
  t = Time.now
  stamp = t.strftime("%Y/%m/%d %H:%M:%S") + format(".%06d", t.usec)
  warn "#{stamp} #{file_line}: #{message}"
  exit 1
end

def take_value(args, i, name)
  arg = args[i]
  return [arg.split("=", 2)[1], i] if arg.include?("=")
  return [args[i + 1], i + 1] if args[i + 1]
  usage_exit("flag needs an argument: #{name}")
end

def bool_value(args, i, default = true)
  arg = args[i]
  return [parse_bool(arg.split("=", 2)[1]), i] if arg.include?("=")
  [default, i]
end

def parse_bool(v)
  return true if v.nil?
  return true if %w[1 t T true TRUE True].include?(v)
  return false if %w[0 f F false FALSE False].include?(v)
  true
end

def shell_json(obj)
  "{" + obj.map { |k, v| "#{k.to_json}:#{v.to_json}" }.join(",") + "}"
end

def add_query(url, pairs)
  return url if pairs.empty?
  uri = URI.parse(url)
  existing = uri.query.to_s
  extra = URI.encode_www_form(pairs)
  uri.query = [existing, extra].reject(&:empty?).join("&")
  uri.to_s
rescue URI::InvalidURIError
  sep = url.include?("?") ? "&" : "?"
  url + sep + URI.encode_www_form(pairs)
end

def request_target(uri)
  path = uri.path
  path = "/" if path.nil? || path.empty?
  uri.query ? "#{path}?#{uri.query}" : path
end

def raw_http_request(uri, method, headers, body)
  port = uri.port || 80
  socket = TCPSocket.new(uri.host, port)
  lines = ["#{method} #{request_target(uri)} HTTP/1.1"]
  lines << "Host: #{uri.host}#{port == 80 ? "" : ":#{port}"}"
  lines << "User-Agent: #{headers.delete("User-Agent") || "bat/0.1.0"}"
  lines << "Content-Length: #{body.bytesize}" unless body.nil?
  lines << "Accept: #{headers.delete("Accept") || "application/json"}"
  lines << "Accept-Encoding: #{headers.delete("Accept-Encoding") || "gzip, deflate"}"
  if (ct = headers.delete("Content-Type"))
    lines << "Content-Type: #{ct}"
  end
  headers.each { |k, v| lines << "#{k}: #{v}" }
  socket.write(lines.join("\r\n"))
  socket.write("\r\n\r\n")
  socket.write(body) unless body.nil?

  status_line = socket.gets("\r\n").to_s
  response_headers = {}
  while (line = socket.gets("\r\n"))
    break if line == "\r\n"
    k, v = line.split(":", 2)
    response_headers[k.downcase] = v.to_s.strip if k
  end

  if response_headers["transfer-encoding"].to_s.downcase.include?("chunked")
    chunks = +""
    loop do
      size_line = socket.gets("\r\n")
      break if size_line.nil?
      size = size_line.to_i(16)
      break if size.zero?
      chunks << socket.read(size).to_s
      socket.read(2)
    end
    response_body = chunks
  elsif response_headers["content-length"]
    response_body = socket.read(response_headers["content-length"].to_i).to_s
  else
    response_body = socket.read.to_s
  end
  socket.close

  code = status_line.split[1].to_i
  [code, response_headers, response_body]
ensure
  socket.close if socket && !socket.closed?
end

opts = {
  auth: nil,
  form: false,
  pretty: true,
  insecure: false,
  proxy: nil,
  body: nil,
  bench: false
}

args = []
i = 0
while i < ARGV.length
  a = ARGV[i]
  case a
  when "-h", "--help"
    usage_exit
  when "-v", "--version", "-version"
    puts "Version: 0.1.0"
    exit 2
  when /\A-auth(=|\z)/, /\A-a(=|\z)/
    opts[:auth], i = take_value(ARGV, i, a.split("=", 2)[0])
  when /\A-body(=|\z)/
    opts[:body], i = take_value(ARGV, i, "-body")
  when /\A-proxy(=|\z)/
    opts[:proxy], i = take_value(ARGV, i, "-proxy")
  when /\A-form(=|\z)/, /\A-f(=|\z)/
    opts[:form], i = bool_value(ARGV, i)
  when /\A-pretty(=|\z)/, /\A-p(=|\z)/
    opts[:pretty], i = bool_value(ARGV, i)
  when /\A-insecure(=|\z)/, /\A-i(=|\z)/
    opts[:insecure], i = bool_value(ARGV, i)
  when /\A-json(=|\z)/, /\A-j(=|\z)/, /\A-print(=|\z)/, /\A-b\.N(=|\z)/, /\A-b\.C(=|\z)/, /\A-download(=|\z)/
    _, i = a.include?("=") ? [nil, i] : [ARGV[i + 1], i + 1]
  when /\A-bench(=|\z)/, /\A-b(=|\z)/
    opts[:bench], i = bool_value(ARGV, i)
  when /\A-/
    usage_exit("flag provided but not defined: #{a.sub(/\A--?/, "-").split("=", 2)[0].sub(/\A-/, "-")}")
  else
    args << a
  end
  i += 1
end

usage_exit if args.empty?

method = nil
if METHODS.include?(args.first.upcase)
  method = args.shift.upcase
end

url = args.shift
log_fatal("filter.go:35", "Miss the URL") if url.nil?
url = "http://#{url}" unless url =~ %r{\Ahttps?://}i

headers = {
  "User-Agent" => "bat/0.1.0",
  "Accept" => "application/json",
  "Accept-Encoding" => "gzip, deflate"
}
data = []
has_file = false

args.each do |item|
  if item.include?("@") && !item.include?("=") && !item.include?(":")
    has_file = true
  elsif item.include?(":")
    k, v = item.split(":", 2)
    headers[k] = v
  elsif item.include?("=")
    k, v = item.split("=", 2)
    data << [k, v]
  end
end

method ||= (data.empty? && opts[:body].nil? && !has_file ? "GET" : "POST")

body = nil
if opts[:body]
  body = opts[:body]
elsif method == "GET"
  url = add_query(url, data)
elsif has_file
  body = ""
elsif !data.empty?
  if opts[:form]
    body = URI.encode_www_form(data)
    headers["Content-Type"] = "application/x-www-form-urlencoded"
  else
    body = shell_json(data.to_h)
    headers["Content-Type"] = "application/json"
  end
end

if opts[:auth]
  headers["Authorization"] = "Basic #{Base64.strict_encode64(opts[:auth])}"
end

uri = URI.parse(url)
klass = Net::HTTP.const_get(method.capitalize) rescue Net::HTTP::Get
req = klass.new(uri)
headers.each { |k, v| req[k] = v }
req.body = body unless body.nil?

begin
  response_headers = {}
  response_body = +""
  current_uri = uri
  5.times do
    if current_uri.scheme == "http" && opts[:proxy].nil?
      code, response_headers, response_body = raw_http_request(current_uri, method, headers.dup, body)
      break unless code.between?(300, 399) && response_headers["location"]
      current_uri = URI.join(current_uri, response_headers["location"])
    else
      http_args = [current_uri.host, current_uri.port]
      if opts[:proxy]
        p_uri = URI.parse(opts[:proxy] =~ %r{\A\w+://} ? opts[:proxy] : "http://#{opts[:proxy]}")
        http_args += [p_uri.host, p_uri.port, p_uri.user, p_uri.password]
      end
      req = klass.new(current_uri)
      headers.each { |k, v| req[k] = v }
      req.body = body unless body.nil?
      http = Net::HTTP.new(*http_args)
      http.use_ssl = current_uri.scheme == "https"
      http.verify_mode = OpenSSL::SSL::VERIFY_NONE if opts[:insecure]
      res = http.request(req)
      response_headers = res.each_header.to_h
      response_body = res.body.to_s
      break unless res.is_a?(Net::HTTPRedirection) && res["location"]
      current_uri = URI.join(current_uri, res["location"])
    end
  end
rescue => e
  verb = method[0] + method[1..].downcase
  shown = url.sub(%r{://([^/:@]+):([^/@]+)@}, '://\1:***@')
  log_fatal("bat.go:215", "can't get the url #{verb} #{shown.inspect}: #{e.message}")
end

out = response_body.to_s
if opts[:pretty] && response_headers["content-type"].to_s.downcase.include?("json")
  begin
    out = JSON.pretty_generate(JSON.parse(out))
  rescue JSON::ParserError
  end
end

puts
puts out
