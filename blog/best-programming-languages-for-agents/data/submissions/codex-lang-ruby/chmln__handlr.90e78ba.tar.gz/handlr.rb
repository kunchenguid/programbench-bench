#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'shellwords'

VERSION = 'handlr 0.6.4'

HELP = <<~TXT
  handlr 0.6.4

  USAGE:
      executable <SUBCOMMAND>

  FLAGS:
      -h, --help       Prints help information
      -V, --version    Prints version information

  SUBCOMMANDS:
      list      List default apps and the associated handlers
      open      Open a path/URL with its default handler
      set       Set the default handler for mime/extension
      unset     Unset the default handler for mime/extension
      launch    Launch the handler for specified extension/mime with optional arguments
      get       Get handler for this mime/extension
      add       Add a handler for given mime/extension Note that the first handler is the default
TXT

SUB_HELP = {
  'list' => ["executable-list \nList default apps and the associated handlers\n\nUSAGE:\n    executable list [FLAGS]\n\nFLAGS:\n    -a, --all        \n    -h, --help       Prints help information\n    -V, --version    Prints version information\n", 0],
  'open' => ["executable-open \nOpen a path/URL with its default handler\n\nUSAGE:\n    executable open <paths>...\n\nARGS:\n    <paths>...    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n", 0],
  'set' => ["executable-set \nSet the default handler for mime/extension\n\nUSAGE:\n    executable set <mime> <handler>\n\nARGS:\n    <mime>       \n    <handler>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n", 0],
  'unset' => ["executable-unset \nUnset the default handler for mime/extension\n\nUSAGE:\n    executable unset <mime>\n\nARGS:\n    <mime>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n", 0],
  'launch' => ["executable-launch \nLaunch the handler for specified extension/mime with optional arguments\n\nUSAGE:\n    executable launch <mime> [args]...\n\nARGS:\n    <mime>       \n    <args>...    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n", 0],
  'get' => ["executable-get \nGet handler for this mime/extension\n\nUSAGE:\n    executable get [FLAGS] <mime>\n\nARGS:\n    <mime>    \n\nFLAGS:\n        --json       \n    -h, --help       Prints help information\n    -V, --version    Prints version information\n", 0],
  'add' => ["executable-add \nAdd a handler for given mime/extension Note that the first handler is the default\n\nUSAGE:\n    executable add <mime> <handler>\n\nARGS:\n    <mime>       \n    <handler>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n", 0]
}

def err(msg, usage = nil)
  warn "error: #{msg}"
  warn ''
  warn usage if usage
  warn 'For more information try --help'
  exit 2
end

def config_home
  ENV['XDG_CONFIG_HOME'] || File.join(ENV['HOME'] || Dir.home, '.config')
end

def data_dirs
  dirs = []
  dirs << File.join(ENV['XDG_DATA_HOME'], 'applications') if ENV['XDG_DATA_HOME']
  dirs << File.join(ENV['HOME'] || Dir.home, '.local', 'share', 'applications')
  (ENV['XDG_DATA_DIRS'] || '/usr/local/share:/usr/share').split(':').each { |d| dirs << File.join(d, 'applications') }
  dirs.uniq
end

def mimeapps_path
  File.join(config_home, 'mimeapps.list')
end

def ensure_defaults
  handlr = File.join(config_home, 'handlr')
  FileUtils.mkdir_p(handlr)
  cfg = File.join(handlr, 'handlr.toml')
  unless File.exist?(cfg)
    File.write(cfg, "enable_selector = false\nselector = \"rofi -dmenu -i -p 'Open With: '\"\n")
  end
  path = mimeapps_path
  FileUtils.mkdir_p(File.dirname(path))
  File.write(path, '') unless File.exist?(path)
end

def read_ini(path)
  sections = Hash.new { |h, k| h[k] = {} }
  sec = nil
  return sections unless File.exist?(path)
  File.readlines(path, chomp: true).each do |line|
    if line =~ /^\[(.+)\]$/
      sec = Regexp.last_match(1)
    elsif sec && line.include?('=')
      k, v = line.split('=', 2)
      sections[sec][k] = v
    end
  end
  sections
end

def write_mimeapps(sections)
  ensure_defaults
  order = ['Added Associations', 'Default Applications']
  out = []
  order.each do |sec|
    out << "[#{sec}]"
    (sections[sec] || {}).each { |k, v| out << "#{k}=#{v}" }
    out << ''
  end
  File.write(mimeapps_path, out.join("\n"))
end

def valid_mime_or_die(s)
  if s.start_with?('.')
    err "Invalid value for '<mime>': could not figure out the mime type of '#{s}'", nil
  end
  unless s.include?('/')
    err "Invalid value for '<mime>': mime parse error: a slash (/) was missing between the type and subtype", nil
  end
  if s =~ /[^A-Za-z0-9!#$&^_.+*-]\/[^A-Za-z0-9!#$&^_.+*-]/
    # Deliberately permissive; detailed diagnostics below catch common path/URL cases.
  end
  if s =~ /([^A-Za-z0-9!#$&^_.+*\/-])/
    code = Regexp.last_match(1).ord.to_s(16).upcase.rjust(2, '0')
    pos = Regexp.last_match.begin(1)
    err "Invalid value for '<mime>': mime parse error: an invalid token was encountered, #{code} at position #{pos}", nil
  end
  s
end

def find_desktop(handler)
  return handler if handler.start_with?('/') && File.exist?(handler)
  data_dirs.each do |dir|
    path = File.join(dir, handler)
    return path if File.exist?(path)
  end
  nil
end

def handler_id(handler)
  handler.start_with?('/') ? handler : File.basename(handler)
end

def require_handler(handler)
  path = find_desktop(handler)
  err "Invalid value for '<handler>': no handlers found for '#{handler}'", nil unless path
  path
end

def parse_desktop(path)
  info = {}
  return info unless path && File.exist?(path)
  File.readlines(path, chomp: true).each do |line|
    next if line.strip.start_with?('#') || !line.include?('=')
    k, v = line.split('=', 2)
    info[k] = v
  end
  info
end

def default_map
  read_ini(mimeapps_path)['Default Applications'] || {}
end

def added_map
  read_ini(mimeapps_path)['Added Associations'] || {}
end

def split_handlers(v)
  (v || '').split(';').reject(&:empty?)
end

def set_handlers(mime, handlers)
  ensure_defaults
  sections = read_ini(mimeapps_path)
  sections['Added Associations'] ||= {}
  sections['Default Applications'] ||= {}
  sections['Default Applications'][mime] = handlers.join(';') + ';'
  write_mimeapps(sections)
end

def lookup(mime)
  defaults = default_map
  hs = split_handlers(defaults[mime])
  if hs.empty? && mime.include?('/')
    type, = mime.split('/', 2)
    hs = split_handlers(defaults["#{type}/*"])
  end
  hs
end

def desktop_apps
  apps = {}
  data_dirs.each do |dir|
    Dir.glob(File.join(dir, '*.desktop')).each do |p|
      id = File.basename(p)
      apps[id] ||= parse_desktop(p).merge('__path' => p)
    end
  end
  apps
end

def system_mime_rows
  rows = []
  desktop_apps.each do |id, info|
    (info['MimeType'] || '').split(';').reject(&:empty?).each { |m| rows << [m, id] }
  end
  rows
end

def print_table(rows)
  if rows.empty?
    puts "┌──┐"
    puts "│  │"
    puts "└──┘"
    return
  end
  w1 = rows.map { |r| r[0].length }.max
  w2 = rows.map { |r| r[1].length }.max
  puts "┌#{'─' * (w1 + 2)}┬#{'─' * (w2 + 2)}┐"
  rows.each { |a, b| puts "│ #{a.ljust(w1)} │ #{b.ljust(w2)} │" }
  puts "└#{'─' * (w1 + 2)}┴#{'─' * (w2 + 2)}┘"
end

def exec_tokens(handler, args)
  path = find_desktop(handler) || handler
  info = parse_desktop(path)
  exec = info['Exec'] || handler
  tokens = Shellwords.split(exec)
  arg_i = 0
  tokens.flat_map do |tok|
    if tok == '%%'
      '%'
    elsif tok =~ /\A%[fFuU]\z/
      if %w[%F %U].include?(tok)
        vals = args[arg_i..] || []
        arg_i = args.length
        vals
      else
        val = args[arg_i] || ''
        arg_i += 1 if arg_i < args.length
        val
      end
    else
      tok.gsub(/%[fFuU]/) do
        if %w[%F %U].include?(Regexp.last_match(0))
          vals = (args[arg_i..] || []).join(' ')
          arg_i = args.length
          vals
        else
          val = args[arg_i] || ''
          arg_i += 1 if arg_i < args.length
          val
        end
      end.gsub(/%[icDdnNickvm]/, '').gsub('%%', '%')
    end
  end.reject(&:empty?)
rescue ArgumentError
  [exec]
end

def command_for(handler, args, display: false)
  toks = exec_tokens(handler, args)
  display ? toks.join(' ') : toks.shelljoin
end

def launch_handler(handler, args)
  tokens = exec_tokens(handler, args)
  system(*tokens)
  $?.respond_to?(:exitstatus) ? $?.exitstatus : 1
end

def json_escape(s)
  s.to_s.gsub(/["\\\b\f\n\r\t]/) do |c|
    case c
    when '"' then '\"'
    when '\\' then '\\\\'
    when "\b" then '\\b'
    when "\f" then '\\f'
    when "\n" then '\\n'
    when "\r" then '\\r'
    when "\t" then '\\t'
    end
  end
end

def mime_for_path(path)
  return 'x-scheme-handler/http' if path =~ %r{\Ahttps?://}
  ext = File.extname(path).downcase
  return 'text/plain' if %w[.txt .text .log].include?(ext)
  return 'text/markdown' if %w[.md .markdown].include?(ext)
  return 'text/x-vim' if ext == '.vim'
  return 'image/png' if ext == '.png'
  return 'application/pdf' if ext == '.pdf'
  nil
end

def cmd_list(args)
  all = args.delete('--all') || args.delete('-a')
  err "Found argument '#{args[0]}' which wasn't expected, or isn't valid in this context\n\nIf you tried to supply `#{args[0]}` as a PATTERN use `-- #{args[0]}`\n\nUSAGE:\n    executable list\n", nil unless args.empty?
  rows = default_map.map { |k, v| [k, split_handlers(v).join(';')] }
  if all
    puts 'Default Apps'
    print_table(rows)
    puts 'System Apps'
    print_table(system_mime_rows)
  else
    print_table(rows)
  end
end

def cmd_get(args)
  json = args.delete('--json')
  err "The following required arguments were not provided:\n    <mime>\n\nUSAGE:\n    executable get [FLAGS] <mime>\n", nil if args.empty?
  mime = valid_mime_or_die(args[0])
  hs = lookup(mime)
  exit 1 if hs.empty?
  h = hs.first
  if json
    path = find_desktop(h)
    info = parse_desktop(path)
    mimes = (info['MimeType'] || '').split(';').reject(&:empty?)
    exit 1 unless mimes.include?(mime)
    cmd = command_for(h, [], display: true)
    puts "{\"handler\":\"#{json_escape(h)}\",\"name\":\"#{json_escape(info['Name'] || h)}\",\"cmd\":\"#{json_escape(cmd)}\"}"
  else
    puts h
  end
end

def cmd_set(args)
  err "The following required arguments were not provided:\n    <mime> <handler>\n\nUSAGE:\n    executable set <mime> <handler>\n", nil if args.length < 2
  mime = valid_mime_or_die(args[0])
  require_handler(args[1])
  set_handlers(mime, [handler_id(args[1])])
end

def cmd_add(args)
  err "The following required arguments were not provided:\n    <mime> <handler>\n\nUSAGE:\n    executable add <mime> <handler>\n", nil if args.length < 2
  mime = valid_mime_or_die(args[0])
  require_handler(args[1])
  h = handler_id(args[1])
  hs = lookup(mime)
  hs << h unless hs.include?(h)
  set_handlers(mime, hs)
end

def cmd_unset(args)
  err "The following required arguments were not provided:\n    <mime>\n\nUSAGE:\n    executable unset <mime>\n", nil if args.empty?
  mime = valid_mime_or_die(args[0])
  ensure_defaults
  sections = read_ini(mimeapps_path)
  sections['Default Applications'] ||= {}
  sections['Default Applications'].delete(mime)
  write_mimeapps(sections)
end

def cmd_launch(args)
  err "The following required arguments were not provided:\n    <mime>\n\nUSAGE:\n    executable launch <mime> [args]...\n", nil if args.empty?
  mime = valid_mime_or_die(args.shift)
  args.shift if args[0] == '--'
  hs = lookup(mime)
  exit 1 if hs.empty?
  exit launch_handler(hs.first, args)
end

def cmd_open(args)
  err "The following required arguments were not provided:\n    <paths>...\n\nUSAGE:\n    executable open <paths>...\n", nil if args.empty?
  status = 0
  args.each do |path|
    mime = mime_for_path(path)
    hs = mime ? lookup(mime) : []
    status = 1 if hs.empty? || launch_handler(hs.first, [path]) != 0
  end
  exit status
end

if ARGV.empty? || ARGV[0] == '-h' || ARGV[0] == '--help'
  puts HELP
  exit 0
end
if ARGV[0] == '-V' || ARGV[0] == '--version'
  puts VERSION
  exit 0
end

sub = ARGV.shift
if SUB_HELP[sub] && (ARGV[0] == '-h' || ARGV[0] == '--help')
  puts SUB_HELP[sub][0]
  exit 0
end

case sub
when 'list' then cmd_list(ARGV)
when 'get' then cmd_get(ARGV)
when 'set' then cmd_set(ARGV)
when 'add' then cmd_add(ARGV)
when 'unset' then cmd_unset(ARGV)
when 'launch' then cmd_launch(ARGV)
when 'open' then cmd_open(ARGV)
else
  err "Found argument '#{sub}' which wasn't expected, or isn't valid in this context\n\nIf you tried to supply `#{sub}` as a PATTERN use `-- #{sub}`\n\nUSAGE:\n    executable <SUBCOMMAND>\n", nil
end
