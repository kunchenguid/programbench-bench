#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require 'csv'
require 'fileutils'
require 'set'

VERSION = '0.13.0'

COMMANDS = {
  'cat' => 'Concatenate by row or column',
  'count' => 'Count records',
  'fixlengths' => 'Makes all records have same length',
  'flatten' => 'Show one field per line',
  'fmt' => 'Format CSV output (change field delimiter)',
  'frequency' => 'Show frequency tables',
  'headers' => 'Show header names',
  'help' => 'Show this usage message.',
  'index' => 'Create CSV index for faster access',
  'input' => 'Read CSV data with special quoting rules',
  'join' => 'Join CSV files',
  'partition' => 'Partition CSV data based on a column value',
  'sample' => 'Randomly sample CSV data',
  'reverse' => 'Reverse rows of CSV data',
  'search' => 'Search CSV data with regexes',
  'select' => 'Select columns from CSV',
  'slice' => 'Slice records from CSV',
  'sort' => 'Sort CSV data',
  'split' => 'Split CSV data into many files',
  'stats' => 'Compute basic statistics',
  'table' => 'Align CSV data into columns'
}.freeze

def usage
  puts <<~USAGE
    Usage:
        xsv <command> [<args>...]
        xsv [options]

    Options:
        --list        List all commands available.
        -h, --help    Display this message
        <command> -h  Display the command help message
        --version     Print version info and exit

    Commands:
  USAGE
  COMMANDS.each { |cmd, desc| puts "    %-11s %s" % [cmd, desc] }
end

def list_commands
  puts 'Installed commands:'
  COMMANDS.each { |cmd, desc| puts "    %-11s %s" % [cmd, desc] }
end

def command_help(cmd)
  puts "#{cmd}: #{COMMANDS[cmd] || 'unknown command'}"
end

def die(msg, code = 1)
  warn msg
  exit code
end

def take(args, names)
  names.each do |name|
    i = args.index(name)
    next unless i
    val = args[i + 1]
    die("Flag #{name} requires a value.") if val.nil?
    args.slice!(i, 2)
    return val
  end
  nil
end

def flag(args, *names)
  found = false
  names.each do |name|
    while (i = args.index(name))
      args.delete_at(i)
      found = true
    end
  end
  found
end

def delimiter(args)
  d = take(args, ['-d', '--delimiter']) || ','
  decode_char(d)
end

def decode_char(s)
  return "\t" if s == '\t' || s == 'tab'
  return "\x1f" if s == '\x1f'
  return "\x1e" if s == '\x1e'
  if s.start_with?('\\x') && s.length == 4
    return s[2, 2].to_i(16).chr
  end
  die("Could not convert '#{s}' to a single ASCII character.") unless s.length == 1
  s
end

def input_text(path)
  path ? File.binread(path) : STDIN.read
end

def parse_csv(path, col_sep: ',', quote_char: '"')
  text = input_text(path)
  return [] if text.empty?
  opts = { col_sep: col_sep, liberal_parsing: true }
  opts[:quote_char] = quote_char if quote_char
  CSV.parse(text, **opts).map { |r| r.map { |v| v.nil? ? '' : v } }
end

def write_csv(rows, out: nil, col_sep: ',', row_sep: "\n", quote_char: '"', force_quotes: false)
  io = out ? File.open(out, 'wb') : STDOUT
  rows.each do |row|
    io.write row.map { |v| csv_field(v, col_sep, quote_char, force_quotes) }.join(col_sep)
    io.write row_sep
  end
ensure
  io.close if out && io
end

def csv_field(value, col_sep, quote_char, force_quotes)
  s = value.nil? ? '' : value.to_s
  return '' if s.empty? && !force_quotes
  needs = force_quotes || s.include?(col_sep) || s.include?(quote_char) || s.include?("\n") || s.include?("\r")
  return s unless needs
  quote_char + s.gsub(quote_char, quote_char * 2) + quote_char
end

def output_path(args)
  take(args, ['-o', '--output'])
end

def split_selection(sel)
  CSV.parse_line(sel, col_sep: ',', quote_char: '"') || []
rescue CSV::MalformedCSVError
  sel.split(',')
end

def column_index(token, headers)
  t = token.to_s.strip
  return nil if t.empty?
  if t =~ /\A(.+)\[(\d+)\]\z/
    name = Regexp.last_match(1)
    nth = Regexp.last_match(2).to_i
    matches = headers.each_index.select { |i| headers[i] == name }
    return matches[nth - 1]
  end
  if t =~ /\A\d+\z/
    idx = t.to_i - 1
    return idx if idx >= 0
  end
  idx = headers.index(t)
  return idx if idx
  nil
end

def range_indices(part, headers, width)
  if part.include?('-') && part !~ /\A".*"\z/
    left, right = part.split('-', 2)
    a = left.empty? ? 0 : column_index(left, headers)
    b = right.nil? || right.empty? ? width - 1 : column_index(right, headers)
    die("Selector '#{part}' did not match any columns.") if a.nil? || b.nil?
    return a <= b ? (a..b).to_a : a.downto(b).to_a
  end
  idx = column_index(part, headers)
  die("Selector '#{part}' did not match any columns.") if idx.nil?
  [idx]
end

def select_indices(sel, headers, width)
  invert = sel.start_with?('!')
  sel = sel[1..] if invert
  picked = split_selection(sel).flat_map { |p| range_indices(p, headers, width) }
  if invert
    picked_set = picked.to_set
    (0...width).reject { |i| picked_set.include?(i) }
  else
    picked
  end
end

def header_and_records(rows, no_headers)
  if !no_headers && rows.any?
    [rows.first, rows[1..] || []]
  else
    [[*(1..(rows.map(&:length).max || 0))].map(&:to_s), rows]
  end
end

def cmd_count(args)
  no_headers = flag(args, '-n', '--no-headers')
  d = delimiter(args)
  path = args.shift
  rows = parse_csv(path, col_sep: d)
  puts [rows.length - (no_headers ? 0 : 1), 0].max
end

def cmd_headers(args)
  just = flag(args, '-j', '--just-names')
  inter = flag(args, '--intersect')
  d = delimiter(args)
  files = args
  files = [nil] if files.empty?
  headers = files.map { |f| (parse_csv(f, col_sep: d).first || []) }
  names = if inter
            headers.reduce(headers.first || []) { |memo, h| memo & h }
          else
            headers.first || []
          end
  just = true if files.length > 1
  names.each_with_index { |h, i| puts(just ? h : "%-4d%s" % [i + 1, h]) }
end

def cmd_select(args)
  no_headers = flag(args, '-n', '--no-headers')
  out = output_path(args)
  d = delimiter(args)
  args.shift if args.first == '--'
  sel = args.shift || die('The following required arguments were not provided: <selection>')
  path = args.shift
  rows = parse_csv(path, col_sep: d)
  headers, records = header_and_records(rows, no_headers)
  width = rows.map(&:length).max || 0
  idxs = select_indices(sel, headers, width)
  result = []
  result << idxs.map { |i| headers[i] || '' } unless no_headers
  records.each { |r| result << idxs.map { |i| r[i] || '' } }
  write_csv(result, out: out)
end

def cmd_slice(args)
  no_headers = flag(args, '-n', '--no-headers')
  out = output_path(args)
  d = delimiter(args)
  idx = take(args, ['-i', '--index'])
  start = take(args, ['-s', '--start'])
  finish = take(args, ['-e', '--end'])
  len = take(args, ['-l', '--len'])
  if idx
    start = idx
    len = '1'
  end
  start_i = (start || 0).to_i
  end_i = len ? start_i + len.to_i : (finish ? finish.to_i : nil)
  rows = parse_csv(args.shift, col_sep: d)
  headers, records = header_and_records(rows, no_headers)
  sliced = end_i ? records[start_i...end_i] : records[start_i..]
  result = []
  result << headers unless no_headers
  result.concat(sliced || [])
  write_csv(result, out: out)
end

def cmd_reverse(args)
  no_headers = flag(args, '-n', '--no-headers')
  out = output_path(args)
  d = delimiter(args)
  rows = parse_csv(args.shift, col_sep: d)
  headers, records = header_and_records(rows, no_headers)
  result = no_headers ? records.reverse : [headers] + records.reverse
  write_csv(result, out: out)
end

def cmd_sort(args)
  no_headers = flag(args, '-n', '--no-headers')
  numeric = flag(args, '-N', '--numeric')
  rev = flag(args, '-R', '--reverse')
  sel = take(args, ['-s', '--select'])
  out = output_path(args)
  d = delimiter(args)
  rows = parse_csv(args.shift, col_sep: d)
  headers, records = header_and_records(rows, no_headers)
  idxs = sel ? select_indices(sel, headers, rows.map(&:length).max || 0) : (0...(rows.map(&:length).max || 0)).to_a
  sorted = records.sort_by do |r|
    vals = idxs.map { |i| r[i] || '' }
    numeric ? vals.map { |v| v == '' ? -Float::INFINITY : v.to_f } : vals
  end
  sorted.reverse! if rev
  write_csv(no_headers ? sorted : [headers] + sorted, out: out)
end

def cmd_search(args)
  no_headers = flag(args, '-n', '--no-headers')
  ignore = flag(args, '-i', '--ignore-case')
  invert = flag(args, '-v', '--invert-match')
  sel = take(args, ['-s', '--select'])
  out = output_path(args)
  d = delimiter(args)
  regex_s = args.shift || die('The following required arguments were not provided: <regex>')
  re = Regexp.new(regex_s, ignore ? Regexp::IGNORECASE : nil)
  rows = parse_csv(args.shift, col_sep: d)
  headers, records = header_and_records(rows, no_headers)
  idxs = sel ? select_indices(sel, headers, rows.map(&:length).max || 0) : (0...(rows.map(&:length).max || 0)).to_a
  result = []
  result << headers unless no_headers
  records.each do |r|
    m = idxs.any? { |i| (r[i] || '').match?(re) }
    result << r if invert ? !m : m
  end
  write_csv(result, out: out)
end

def cmd_frequency(args)
  no_headers = flag(args, '-n', '--no-headers')
  asc = flag(args, '-a', '--asc')
  no_nulls = flag(args, '--no-nulls')
  sel = take(args, ['-s', '--select'])
  limit = (take(args, ['-l', '--limit']) || '10').to_i
  take(args, ['-j', '--jobs'])
  out = output_path(args)
  d = delimiter(args)
  rows = parse_csv(args.shift, col_sep: d)
  headers, records = header_and_records(rows, no_headers)
  width = rows.map(&:length).max || 0
  idxs = sel ? select_indices(sel, headers, width) : (0...width).to_a
  result = [%w[field value count]]
  idxs.each do |i|
    counts = Hash.new(0)
    records.each do |r|
      v = r[i] || ''
      next if no_nulls && v == ''
      counts[v] += 1
    end
    arr = counts.to_a.sort_by { |v, c| asc ? [c, v] : [-c, v] }
    arr = arr.first(limit) if limit.positive?
    arr.each { |v, c| result << [no_headers ? (i + 1).to_s : (headers[i] || ''), v, c.to_s] }
  end
  write_csv(result, out: out)
end

def numeric_string?(s)
  s.to_s.strip != '' && Float(s) && true
rescue ArgumentError
  false
end

def cmd_stats(args)
  no_headers = flag(args, '-n', '--no-headers')
  everything = flag(args, '--everything')
  show_mode = flag(args, '--mode') || everything
  show_card = flag(args, '--cardinality') || everything
  show_median = flag(args, '--median') || everything
  include_nulls = flag(args, '--nulls')
  sel = take(args, ['-s', '--select'])
  take(args, ['-j', '--jobs'])
  out = output_path(args)
  d = delimiter(args)
  rows = parse_csv(args.shift, col_sep: d)
  headers, records = header_and_records(rows, no_headers)
  width = rows.map(&:length).max || 0
  idxs = sel ? select_indices(sel, headers, width) : (0...width).to_a
  cols = %w[field type sum min max min_length max_length mean stddev]
  cols += ['median'] if show_median
  cols += ['mode'] if show_mode
  cols += ['cardinality'] if show_card
  result = [cols]
  idxs.each do |i|
    vals = records.map { |r| r[i] || '' }
    nonnull = vals.reject(&:empty?)
    nums = nonnull.select { |v| numeric_string?(v) }.map(&:to_f)
    all_numeric = nonnull.any? && nums.length == nonnull.length
    type = if all_numeric
             nums.all? { |n| n.to_i == n } ? 'Integer' : 'Float'
           else
             vals.any? { |v| !v.ascii_only? } ? 'Unicode' : 'Unicode'
           end
    pop = include_nulls ? vals.map { |v| v.empty? ? 0.0 : v.to_f } : nums
    sum = all_numeric ? nums.sum : nil
    mean = pop.empty? || !all_numeric ? nil : pop.sum / pop.length
    std = nil
    if mean && pop.length > 1
      std = Math.sqrt(pop.map { |n| (n - mean)**2 }.sum / pop.length)
    elsif mean
      std = 0.0
    end
    row = [
      no_headers ? (i + 1).to_s : (headers[i] || ''),
      type,
      sum ? format_number(sum) : '',
      nonnull.min.to_s,
      nonnull.max.to_s,
      vals.map(&:length).min.to_i.to_s,
      vals.map(&:length).max.to_i.to_s,
      mean ? mean.to_s : '',
      std ? std.to_s : ''
    ]
    if show_median
      if all_numeric && nums.any?
        s = nums.sort
        med = s.length.odd? ? s[s.length / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2.0
        row << format_number(med)
      else
        row << ''
      end
    end
    row << (vals.tally.max_by { |v, c| [c, v] }&.first || '') if show_mode
    row << vals.to_set.length.to_s if show_card
    result << row
  end
  write_csv(result, out: out)
end

def format_number(n)
  n.to_i == n ? n.to_i.to_s : n.to_s
end

def cmd_flatten(args)
  no_headers = flag(args, '-n', '--no-headers')
  condense = take(args, ['-c', '--condense'])
  sep = take(args, ['-s', '--separator'])
  sep = '#' if sep.nil?
  d = delimiter(args)
  rows = parse_csv(args.shift, col_sep: d)
  headers, records = header_and_records(rows, no_headers)
  labels = headers
  width = labels.map(&:length).max || 0
  records.each_with_index do |r, ri|
    r.each_with_index do |v, i|
      v = v[0, condense.to_i] if condense && v.length > condense.to_i
      puts "%-#{width}s  %s" % [labels[i] || (i + 1).to_s, v]
    end
    puts sep if sep != '' && ri != records.length - 1
  end
end

def cmd_table(args)
  width_min = (take(args, ['-w', '--width']) || '2').to_i
  pad = (take(args, ['-p', '--pad']) || '2').to_i
  condense = take(args, ['-c', '--condense'])
  out = output_path(args)
  d = delimiter(args)
  rows = parse_csv(args.shift, col_sep: d)
  rows.each { |r| r.map! { |v| condense && v.length > condense.to_i ? v[0, condense.to_i] : v } }
  widths = []
  rows.each { |r| r.each_with_index { |v, i| widths[i] = [widths[i] || width_min, v.length, width_min].max } }
  lines = rows.map do |r|
    (0...(widths.length)).map { |i| (r[i] || '').ljust(widths[i]) }.join(' ' * pad).rstrip
  end
  if out
    File.write(out, lines.join("\n") + (lines.empty? ? '' : "\n"))
  else
    puts lines
  end
end

def cmd_fmt(args)
  out_delim = take(args, ['-t', '--out-delimiter']) || ','
  crlf = flag(args, '--crlf')
  ascii = flag(args, '--ascii')
  quote = take(args, ['--quote']) || '"'
  force = flag(args, '--quote-always')
  escape = take(args, ['--escape'])
  out = output_path(args)
  d = delimiter(args)
  out_delim = "\x1f" if ascii
  row_sep = ascii ? "\x1e" : (crlf ? "\r\n" : "\n")
  rows = parse_csv(args.shift, col_sep: d)
  write_csv(rows, out: out, col_sep: decode_char(out_delim), row_sep: row_sep, quote_char: decode_char(quote), force_quotes: force)
end

def cmd_input(args)
  quote = take(args, ['--quote']) || '"'
  no_quoting = flag(args, '--no-quoting')
  take(args, ['--escape'])
  out = output_path(args)
  d = delimiter(args)
  rows = parse_csv(args.shift, col_sep: d, quote_char: no_quoting ? nil : decode_char(quote))
  write_csv(rows, out: out)
end

def cmd_fixlengths(args)
  len = take(args, ['-l', '--length'])
  out = output_path(args)
  d = delimiter(args)
  rows = parse_csv(args.shift, col_sep: d)
  target = len ? len.to_i : [rows.map { |r| r.reverse.drop_while(&:empty?).length }.max || 1, 1].max
  rows.each { |r| r.fill('', r.length...target); r.slice!(target, r.length) if r.length > target }
  write_csv(rows, out: out)
end

def cmd_cat(args)
  mode = args.shift
  die('Usage: xsv cat rows|columns [options] [<input>...]') unless %w[rows columns].include?(mode)
  pad = flag(args, '-p', '--pad')
  no_headers = flag(args, '-n', '--no-headers')
  out = output_path(args)
  d = delimiter(args)
  files = args.empty? ? [nil] : args
  datasets = files.map { |f| parse_csv(f, col_sep: d) }
  result = []
  if mode == 'rows'
    datasets.each_with_index do |rows, i|
      result.concat(i.zero? || no_headers ? rows : rows[1..] || [])
    end
  else
    max = pad ? datasets.map(&:length).max.to_i : datasets.map(&:length).min.to_i
    (0...max).each do |ri|
      result << datasets.flat_map { |rows| rows[ri] || Array.new((rows.first || []).length, '') }
    end
  end
  write_csv(result, out: out)
end

def key_for(row, idxs, no_case)
  vals = idxs.map { |i| (row[i] || '').strip }
  return nil if vals.any?(&:empty?)
  no_case ? vals.map(&:downcase) : vals
end

def cmd_join(args)
  no_case = flag(args, '--no-case')
  left = flag(args, '--left')
  right = flag(args, '--right')
  full = flag(args, '--full')
  cross = flag(args, '--cross')
  nulls = flag(args, '--nulls')
  no_headers = flag(args, '-n', '--no-headers')
  out = output_path(args)
  d = delimiter(args)
  c1, f1, c2, f2 = args
  r1 = parse_csv(f1, col_sep: d)
  r2 = parse_csv(f2, col_sep: d)
  h1, a = header_and_records(r1, no_headers)
  h2, b = header_and_records(r2, no_headers)
  result = []
  result << h1 + h2 unless no_headers
  if cross
    a.each { |x| b.each { |y| result << x + y } }
    return write_csv(result, out: out)
  end
  i1 = select_indices(c1, h1, r1.map(&:length).max || 0)
  i2 = select_indices(c2, h2, r2.map(&:length).max || 0)
  index = Hash.new { |h, k| h[k] = [] }
  b.each_with_index do |row, j|
    k = key_for(row, i2, no_case)
    k = i2.map { |i| (row[i] || '').strip } if nulls
    index[k] << [j, row] if k
  end
  matched = Set.new
  a.each do |row|
    k = key_for(row, i1, no_case)
    k = i1.map { |i| (row[i] || '').strip } if nulls
    hits = k ? index[k] : []
    if hits.any?
      hits.each { |j, y| matched << j; result << row + y }
    elsif left || full
      result << row + Array.new(h2.length, '')
    end
  end
  if right || full
    b.each_with_index do |row, j|
      result << Array.new(h1.length, '') + row unless matched.include?(j)
    end
  end
  write_csv(result, out: out)
end

def safe_name(s)
  s.to_s.gsub(/[^A-Za-z0-9_.-]+/, '_')
end

def cmd_split(args)
  size = (take(args, ['-s', '--size']) || '500').to_i
  take(args, ['-j', '--jobs'])
  tmpl = take(args, ['--filename']) || '{}.csv'
  no_headers = flag(args, '-n', '--no-headers')
  d = delimiter(args)
  outdir = args.shift || die('The following required arguments were not provided: <outdir>')
  rows = parse_csv(args.shift, col_sep: d)
  headers, records = header_and_records(rows, no_headers)
  FileUtils.mkdir_p(outdir)
  records.each_slice(size).with_index do |chunk, ci|
    start = ci * size
    name = tmpl.gsub('{}', start.to_s)
    write_csv(no_headers ? chunk : [headers] + chunk, out: File.join(outdir, name))
  end
end

def cmd_partition(args)
  tmpl = take(args, ['--filename']) || '{}.csv'
  prefix = take(args, ['-p', '--prefix-length'])
  drop = flag(args, '--drop')
  no_headers = flag(args, '-n', '--no-headers')
  d = delimiter(args)
  col = args.shift || die('missing column')
  outdir = args.shift || die('missing outdir')
  rows = parse_csv(args.shift, col_sep: d)
  headers, records = header_and_records(rows, no_headers)
  idx = select_indices(col, headers, rows.map(&:length).max || 0).first
  FileUtils.mkdir_p(outdir)
  groups = Hash.new { |h, k| h[k] = [] }
  records.each do |r|
    key = r[idx] || ''
    key = key.byteslice(0, prefix.to_i) if prefix
    row = drop ? r.each_with_index.reject { |_, i| i == idx }.map(&:first) : r
    groups[key] << row
  end
  out_headers = drop ? headers.each_with_index.reject { |_, i| i == idx }.map(&:first) : headers
  groups.each do |k, rs|
    write_csv(no_headers ? rs : [out_headers] + rs, out: File.join(outdir, tmpl.gsub('{}', safe_name(k))))
  end
end

def cmd_sample(args)
  seed = take(args, ['--seed'])
  no_headers = flag(args, '-n', '--no-headers')
  out = output_path(args)
  d = delimiter(args)
  n = (args.shift || '0').to_i
  rows = parse_csv(args.shift, col_sep: d)
  headers, records = header_and_records(rows, no_headers)
  rng = seed ? Random.new(seed.to_i) : Random.new
  sample = records.shuffle(random: rng).first(n)
  write_csv(no_headers ? sample : [headers] + sample, out: out)
end

def cmd_index(args)
  delimiter(args)
  path = args.shift || die('The following required arguments were not provided: <input>')
  rows = parse_csv(path)
  File.binwrite("#{path}.idx", "xsv-ruby-index\n#{[rows.length - 1, 0].max}\n")
end

def dispatch(cmd, args)
  return usage if cmd.nil? || cmd == 'help'
  return list_commands if cmd == '--list'
  return puts VERSION if cmd == '--version'
  return usage if ['-h', '--help'].include?(cmd)
  if args.include?('-h') || args.include?('--help')
    return command_help(cmd)
  end
  method = "cmd_#{cmd}"
  die("Unrecognized command '#{cmd}'.") unless respond_to?(method, true)
  send(method, args)
end

dispatch(ARGV.shift, ARGV)
