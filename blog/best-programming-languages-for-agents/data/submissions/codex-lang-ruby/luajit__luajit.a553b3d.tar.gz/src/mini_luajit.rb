#!/usr/bin/env ruby
# Minimal LuaJIT-compatible command line runner, implemented in Ruby.

class LuaReturn < StandardError
  attr_reader :values
  def initialize(values) = (@values = values)
end

class LuaError < StandardError; end
class LuaBreak < StandardError; end

class LuaTable
  attr_reader :data
  def initialize
    @data = {}
  end
  def [](k) = @data[canon(k)]
  def []=(k, v)
    @data[canon(k)] = v
  end
  def length
    i = 1
    i += 1 while @data.key?(i) && !@data[i].nil?
    i - 1
  end
  def keys = @data.keys
  def values = @data.values
  def method_missing(name, *args)
    key = name.to_s
    if key.end_with?("=")
      self[key[0..-2]] = args[0]
    else
      self[key]
    end
  end
  def respond_to_missing?(_name, _inc=false) = true
  private
  def canon(k)
    k.is_a?(Float) && k == k.to_i ? k.to_i : k
  end
end

class Env
  def initialize(parent=nil)
    @parent = parent
    @vars = {}
  end
  def get(name)
    return @vars[name] if @vars.key?(name)
    return @parent.get(name) if @parent
    nil
  end
  def set(name, value)
    if @vars.key?(name) || @parent.nil?
      @vars[name] = value
    elsif @parent.has?(name)
      @parent.set(name, value)
    else
      @vars[name] = value
    end
  end
  def local_set(name, value) = @vars[name] = value
  def has?(name) = @vars.key?(name) || (@parent && @parent.has?(name))
end

Token = Struct.new(:type, :value)

class Lexer
  KEYWORDS = %w[and break do else elseif end false for function if in local nil not or repeat return then true until while].to_h { |k| [k, k.to_sym] }
  def initialize(src)
    @src = src
    @i = 0
    @tokens = []
  end
  def tokens
    until eof?
      c = peek
      if c =~ /\s/
        @i += 1
      elsif c == "-" && peek(1) == "-"
        @i += 2
        if peek == "[" && peek(1) == "["
          @i += 2
          @i += 1 until eof? || (peek == "]" && peek(1) == "]")
          @i += 2 unless eof?
        else
          @i += 1 until eof? || peek == "\n"
        end
      elsif c =~ /[A-Za-z_]/
        ident
      elsif c =~ /\d/ || (c == "." && peek(1) =~ /\d/)
        number
      elsif c == "'" || c == '"'
        string(c)
      elsif c == "[" && peek(1) == "["
        long_string
      else
        op
      end
    end
    @tokens << Token.new(:eof, nil)
  end
  private
  def eof? = @i >= @src.length
  def peek(n=0) = @src[@i+n]
  def ident
    s = @i
    @i += 1 while !eof? && peek =~ /[A-Za-z0-9_]/
    w = @src[s...@i]
    @tokens << Token.new(KEYWORDS[w] || :ident, w)
  end
  def number
    s = @i
    if peek == "0" && %w[x X].include?(peek(1))
      @i += 2
      @i += 1 while !eof? && peek =~ /[0-9A-Fa-f]/
      @tokens << Token.new(:number, @src[s...@i].to_i(16))
    else
      @i += 1 while !eof? && peek =~ /[0-9.]/
      if !eof? && peek =~ /[eE]/
        @i += 1
        @i += 1 if %w[+ -].include?(peek)
        @i += 1 while !eof? && peek =~ /\d/
      end
      txt = @src[s...@i]
      @tokens << Token.new(:number, txt.include?(".") || txt =~ /[eE]/ ? txt.to_f : txt.to_i)
    end
  end
  def string(q)
    @i += 1
    out = +""
    until eof? || peek == q
      if peek == "\\"
        @i += 1
        ch = peek
        out << case ch
        when "n" then "\n"
        when "t" then "\t"
        when "r" then "\r"
        when "\\" then "\\"
        when "\"" then "\""
        when "'" then "'"
        else ch.to_s
        end
        @i += 1
      else
        out << peek
        @i += 1
      end
    end
    @i += 1 unless eof?
    @tokens << Token.new(:string, out)
  end
  def long_string
    @i += 2
    s = @i
    @i += 1 until eof? || (peek == "]" && peek(1) == "]")
    out = @src[s...@i]
    @i += 2 unless eof?
    @tokens << Token.new(:string, out)
  end
  def op
    two = @src[@i, 2]
    three = @src[@i, 3]
    if three == "..."
      @i += 3; @tokens << Token.new(:vararg, "...")
    elsif %w[== ~= <= >= ..].include?(two)
      @i += 2; @tokens << Token.new(two.to_sym, two)
    else
      @i += 1; @tokens << Token.new(c = peek(-1).to_sym, c.to_s)
    end
  end
end

class Parser
  PRECEDENCE = {
    or: [1, :left], and: [2, :left],
    :== => [3, :left], :"~=" => [3, :left], :< => [3, :left], :> => [3, :left], :<= => [3, :left], :>= => [3, :left],
    :".." => [4, :right], :+ => [5, :left], :- => [5, :left], :* => [6, :left], :/ => [6, :left], :% => [6, :left], :^ => [8, :right]
  }
  def initialize(src)
    @t = Lexer.new(src).tokens
    @i = 0
  end
  def parse(stop=[:eof])
    body = []
    body << statement until stop.include?(cur.type)
    body
  end
  private
  def cur = @t[@i]
  def adv = (@i += 1; @t[@i-1])
  def accept(x) = (cur.type == x ? adv : nil)
  def expect(x)
    return adv if cur.type == x
    raise LuaError, "syntax error near '#{cur.value || cur.type}'"
  end
  def statement
    case cur.type
    when :";" then adv; [:nop]
    when :local
      adv
      if accept(:function)
        name = expect(:ident).value
        args, body = func_body
        [:local, [name], [[:func, args, body]]]
      else
        names = [expect(:ident).value]
        names << (expect(:ident).value) while accept(:",")
        vals = accept(:"=") ? explist : []
        [:local, names, vals]
      end
    when :function
      adv
      target = function_name
      args, body = func_body
      [:assign, [target], [[:func, args, body]]]
    when :return
      adv
      vals = ([:end, :else, :elseif, :until, :eof].include?(cur.type) ? [] : explist)
      accept(:";")
      [:return, vals]
    when :break
      adv
      [:break]
    when :if
      adv
      branches = []
      branches << [expr, (expect(:then); parse([:elseif, :else, :end]))]
      while accept(:elseif)
        branches << [expr, (expect(:then); parse([:elseif, :else, :end]))]
      end
      else_body = accept(:else) ? parse([:end]) : []
      expect(:end)
      [:if, branches, else_body]
    when :while
      adv
      c = expr
      expect(:do)
      body = parse([:end])
      expect(:end)
      [:while, c, body]
    when :for
      adv
      name = expect(:ident).value
      if accept(:"=")
        a = expr; expect(:","); b = expr; step = accept(:",") ? expr : [:num, 1]
        expect(:do)
        body = parse([:end])
        expect(:end)
        [:fornum, name, a, b, step, body]
      else
        names = [name]
        names << (expect(:ident).value) while accept(:",")
        expect(:in)
        iter = explist
        expect(:do)
        body = parse([:end])
        expect(:end)
        [:forin, names, iter, body]
      end
    when :do
      adv; body = parse([:end]); expect(:end); [:do, body]
    when :repeat
      adv; body = parse([:until]); expect(:until); [:repeat, body, expr]
    else
      first = suffixed(primary)
      if [:",", :"="].include?(cur.type)
        vars = [first]
        vars << (adv; suffixed(primary)) while cur.type == :"," 
        expect(:"=")
        [:assign, vars, explist]
      elsif first && first[0] == :call
        [:callstmt, first]
      else
        raise LuaError, "syntax error near '#{cur.value || cur.type}'"
      end
    end
  end
  def func_body
    expect(:"(")
    args = []
    vararg = false
    unless accept(:")")
      loop do
        if accept(:vararg)
          vararg = true
          break
        else
          args << expect(:ident).value
        end
        break unless accept(:",")
      end
      expect(:")")
    end
    body = parse([:end])
    expect(:end)
    [args + (vararg ? ["..."] : []), body]
  end
  def function_name
    node = [:var, expect(:ident).value]
    while accept(:".")
      node = [:index, node, [:str, expect(:ident).value]]
    end
    if accept(:":")
      node = [:index, node, [:str, expect(:ident).value]]
    end
    node
  end
  def variable = suffixed(primary)
  def explist
    xs = [expr]
    xs << (adv; expr) while cur.type == :"," 
    xs
  end
  def expr(min=0)
    left = unary
    while PRECEDENCE.key?(cur.type) && PRECEDENCE[cur.type][0] >= min
      op = adv.type
      prec, assoc = PRECEDENCE[op]
      right = expr(assoc == :right ? prec : prec + 1)
      left = [:bin, op, left, right]
    end
    left
  end
  def unary
    if [:"-", :not, :"#"].include?(cur.type)
      [:un, adv.type, unary]
    else
      suffixed(primary)
    end
  end
  def primary
    tok = adv
    case tok.type
    when :number then [:num, tok.value]
    when :string then [:str, tok.value]
    when :nil then [:nil]
    when :true then [:bool, true]
    when :false then [:bool, false]
    when :ident then [:var, tok.value]
    when :vararg then [:var, "..."]
    when :"(" then x = expr; expect(:")"); x
    when :"{" then table_constructor
    when :function then args, body = func_body; [:func, args, body]
    else raise LuaError, "syntax error near '#{tok.value || tok.type}'"
    end
  end
  def suffixed(node)
    loop do
      case cur.type
      when :"."
        adv; node = [:index, node, [:str, expect(:ident).value]]
      when :"["
        adv; k = expr; expect(:"]"); node = [:index, node, k]
      when :"("
        node = [:call, node, call_args]
      when :":"
        adv
        m = expect(:ident).value
        args = call_args
        node = [:methodcall, node, m, args]
      else
        return node
      end
    end
  end
  def call_args
    expect(:"(")
    xs = cur.type == :")" ? [] : explist
    expect(:")")
    xs
  end
  def table_constructor
    fields = []
    n = 1
    until accept(:"}")
      if accept(:"[")
        k = expr; expect(:"]"); expect(:"="); v = expr
      elsif cur.type == :ident && @t[@i+1].type == :"="
        k = [:str, adv.value]; adv; v = expr
      else
        k = [:num, n]; v = expr; n += 1
      end
      fields << [k, v]
      accept(:",") || accept(:";")
    end
    [:table, fields]
  end
end

class LuaFunc
  def initialize(args, body, env, runtime)
    @args, @body, @env, @runtime = args, body, env, runtime
  end
  def call(*vals)
    child = Env.new(@env)
    variadic = @args.last == "..."
    fixed = variadic ? @args[0...-1] : @args
    fixed.each_with_index { |a, i| child.local_set(a, vals[i]) }
    child.local_set("...", vals[fixed.length..] || []) if variadic
    @runtime.exec_block(@body, child)
    nil
  rescue LuaReturn => r
    r.values
  end
end

class Runtime
  VERSION = "LuaJIT 2.1.1772570160"
  attr_reader :global
  def initialize(argv=[])
    @global = Env.new
    install_builtins(argv)
  end
  def run(src, name="=(command line)")
    ast = Parser.new(src).parse
    exec_block(ast, @global)
  rescue LuaError => e
    warn "./executable: #{name}: #{e.message}"
    exit 1
  end
  def exec_block(body, env)
    body.each { |st| exec(st, env) }
  end
  def truthy(v) = !(v.nil? || v == false)
  def fmt(v)
    v = v.first if v.is_a?(Array)
    case v
    when nil then "nil"
    when true then "true"
    when false then "false"
    when Float then v.nan? ? "nan" : (v == v.to_i ? v.to_i.to_s : v.to_s)
    when LuaTable then "table: 0x#{v.object_id.to_s(16)}"
    when LuaFunc, Proc then "function: 0x#{v.object_id.to_s(16)}"
    else v.to_s
    end
  end
  def eval_expr(e, env)
    case e[0]
    when :num, :str then e[1]
    when :bool then e[1]
    when :nil then nil
    when :var then env.get(e[1])
    when :table
      t = LuaTable.new
      e[1].each { |k, v| t[eval_expr(k, env)] = eval_expr(v, env) }
      t
    when :func then LuaFunc.new(e[1], e[2], env, self)
    when :index
      obj = eval_expr(e[1], env); key = eval_expr(e[2], env)
      obj.is_a?(LuaTable) ? obj[key] : nil
    when :call then call_value(eval_expr(e[1], env), eval_list(e[2], env))
    when :methodcall
      obj = eval_expr(e[1], env)
      fn = if obj.is_a?(LuaTable)
        obj[e[2]]
      elsif obj.is_a?(String)
        @global.get("string")[e[2]]
      elsif obj.is_a?(File)
        file_method(e[2])
      end
      call_value(fn, [obj] + eval_list(e[3], env))
    when :un
      v = eval_expr(e[2], env)
      case e[1]
      when :"-" then -num(v)
      when :not then !truthy(v)
      when :"#" then v.is_a?(LuaTable) ? v.length : v.to_s.length
      end
    when :bin
      op = e[1]
      return (truthy(l = eval_expr(e[2], env)) ? l : eval_expr(e[3], env)) if op == :or
      return (truthy(l = eval_expr(e[2], env)) ? eval_expr(e[3], env) : l) if op == :and
      a = eval_expr(e[2], env); b = eval_expr(e[3], env)
      case op
      when :+ then num(a) + num(b)
      when :- then num(a) - num(b)
      when :* then num(a) * num(b)
      when :/ then num(a).to_f / num(b)
      when :% then num(a) % num(b)
      when :^ then num(a) ** num(b)
      when :".." then fmt(a) + fmt(b)
      when :== then a == b
      when :"~=" then a != b
      when :< then a < b
      when :> then a > b
      when :<= then a <= b
      when :>= then a >= b
      end
    end
  end
  def exec(st, env)
    case st[0]
    when :nop then nil
    when :break then raise LuaBreak
    when :local
      vals = eval_list(st[2], env)
      st[1].each_with_index { |n, i| env.local_set(n, vals[i]) }
    when :assign
      vals = eval_list(st[2], env)
      st[1].each_with_index { |var, i| assign(var, vals[i], env) }
    when :callstmt then eval_expr(st[1], env)
    when :return then raise LuaReturn, eval_list(st[1], env)
    when :if
      done = false
      st[1].each do |cond, body|
        if truthy(eval_expr(cond, env))
          exec_block(body, Env.new(env)); done = true; break
        end
      end
      exec_block(st[2], Env.new(env)) unless done
    when :while
      begin
        exec_block(st[2], Env.new(env)) while truthy(eval_expr(st[1], env))
      rescue LuaBreak
      end
    when :fornum
      a = num(eval_expr(st[2], env)); b = num(eval_expr(st[3], env)); step = num(eval_expr(st[4], env))
      i = a
      begin
        while step >= 0 ? i <= b : i >= b
          child = Env.new(env); child.local_set(st[1], i)
          exec_block(st[5], child)
          i += step
        end
      rescue LuaBreak
      end
    when :forin
      vals = eval_list(st[2], env)
      iter = vals[0]
      state = vals[1]
      control = vals[2]
      begin
        loop do
          got = call_value(iter, [state, control])
          got = [got] unless got.is_a?(Array)
          break if got.empty? || got[0].nil?
          control = got[0]
          child = Env.new(env)
          st[1].each_with_index { |n, i| child.local_set(n, got[i]) }
          exec_block(st[3], child)
        end
      rescue LuaBreak
      end
    when :repeat
      begin
        loop do
          exec_block(st[1], Env.new(env))
          break if truthy(eval_expr(st[2], env))
        end
      rescue LuaBreak
      end
    when :do then exec_block(st[1], Env.new(env))
    end
  end
  def eval_list(exprs, env)
    out = []
    exprs.each_with_index do |x, i|
      v = eval_expr(x, env)
      if i == exprs.length - 1 && v.is_a?(Array)
        out.concat(v)
      else
        out << (v.is_a?(Array) ? v.first : v)
      end
    end
    out
  end
  def assign(var, val, env)
    if var[0] == :var
      env.set(var[1], val)
    elsif var[0] == :index
      obj = eval_expr(var[1], env)
      obj[eval_expr(var[2], env)] = val if obj.is_a?(LuaTable)
    else
      raise LuaError, "bad assignment"
    end
  end
  def call_value(fn, args)
    case fn
    when LuaFunc then fn.call(*args)
    when Proc then fn.call(*args)
    else raise LuaError, "attempt to call a nil value"
    end
  end
  def file_method(name)
    {
      "read" => ->(f, *_a) { f.read },
      "write" => ->(f, *a) { f.write(a.map { |x| fmt(x) }.join); nil },
      "close" => ->(f) { f.close; nil },
      "flush" => ->(f) { f.flush; nil }
    }[name]
  end
  def num(v)
    v = v.first if v.is_a?(Array)
    return v if v.is_a?(Numeric)
    Float(v)
  rescue
    raise LuaError, "attempt to perform arithmetic on a #{v.nil? ? 'nil' : v.class}"
  end
  def table_from_hash(h)
    t = LuaTable.new
    h.each { |k, v| t[k] = v }
    t
  end
  def install_builtins(argv)
    g = @global
    g.local_set("_VERSION", "Lua 5.1")
    argt = LuaTable.new
    argv.each_with_index { |a, i| argt[i] = a }
    g.local_set("arg", argt)
    g.local_set("print", ->(*xs) { puts xs.map { |x| fmt(x) }.join("\t"); nil })
    g.local_set("tonumber", ->(x, base=nil) { base ? x.to_s.to_i(base.to_i) : (x.to_s =~ /\A[-+]?\d+\z/ ? x.to_i : Float(x) rescue nil) })
    g.local_set("tostring", ->(x) { fmt(x) })
    g.local_set("type", ->(x) { x.nil? ? "nil" : x == true || x == false ? "boolean" : x.is_a?(Numeric) ? "number" : x.is_a?(String) ? "string" : x.is_a?(LuaTable) ? "table" : "function" })
    g.local_set("assert", ->(x, msg=nil) { raise LuaError, (msg || "assertion failed!") unless truthy(x); x })
    g.local_set("error", ->(msg="") { raise LuaError, msg.to_s })
    g.local_set("select", ->(what, *a) { what == "#" ? a.length : a[(what.to_i - 1)..] })
    g.local_set("unpack", ->(t, i=1, j=nil) { j ||= t.length; (i.to_i..j.to_i).map { |k| t[k] } })
    g.local_set("next", ->(t, k=nil) {
      keys = t.is_a?(LuaTable) ? t.keys : []
      idx = k.nil? ? 0 : keys.index(k).to_i + 1
      kk = keys[idx]
      kk.nil? ? nil : [kk, t[kk]]
    })
    g.local_set("pcall", ->(fn, *a) {
      begin
        [true, call_value(fn, a)]
      rescue => e
        [false, e.message]
      end
    })
    g.local_set("pairs", ->(t) { enum = t.is_a?(LuaTable) ? t.data.to_a : []; i = -1; ->(_tbl=nil, _key=nil) { i += 1; enum[i] || [nil] } })
    g.local_set("ipairs", ->(t) { i = 0; ->(_tbl=nil, _key=nil) { i += 1; v = t[i]; v.nil? ? [nil] : [i, v] } })
    g.local_set("dofile", ->(path=nil) { run(File.read(path || "-"), path || "-") })
    g.local_set("loadfile", ->(path) { src = File.read(path); LuaFunc.new([], Parser.new(src).parse, g, self) })
    g.local_set("require", ->(name) { require_lua(name.to_s) })
    g.local_set("jit", table_from_hash("version" => VERSION, "version_num" => 20100, "os" => "Linux", "arch" => "x64",
      "on" => ->(){}, "off" => ->(){}, "flush" => ->(){}))
    g.local_set("math", table_from_hash(Math.methods(false).grep_v(/=/).to_h { |m| [m.to_s, ->(*a) { Math.send(m, *a.map(&:to_f)) }] }.merge(
      "pi" => Math::PI, "huge" => Float::INFINITY, "abs" => ->(x){x.to_f.abs}, "floor" => ->(x){x.to_f.floor},
      "ceil" => ->(x){x.to_f.ceil}, "max" => ->(*a){a.max}, "min" => ->(*a){a.min}, "random" => ->(*a){ a.empty? ? rand : rand(a[0].to_i..(a[1]||a[0]).to_i) })))
    g.local_set("string", table_from_hash("len" => ->(s){s.to_s.length}, "lower" => ->(s){s.to_s.downcase}, "upper" => ->(s){s.to_s.upcase},
      "sub" => ->(s,i,j=nil){ s=s.to_s; i=i.to_i; j=(j||-1).to_i; s[(i<0 ? s.length+i : i-1)..(j<0 ? s.length+j : j-1)] || "" },
      "rep" => ->(s,n){s.to_s*n.to_i}, "reverse" => ->(s){s.to_s.reverse}, "format" => ->(fmt,*a){fmt % a},
      "find" => ->(s,p){ idx=s.to_s.index(p.to_s); idx ? [idx+1, idx+p.to_s.length] : nil },
      "match" => ->(s,p){ s.to_s[/#{Regexp.escape(p.to_s)}/] }))
    g.local_set("table", table_from_hash("insert" => ->(t, pos, val=nil){ if val.nil?; t[t.length+1]=pos else t.data.keys.select{|k|k.is_a?(Integer)&&k>=pos}.sort.reverse.each{|k|t[k+1]=t[k]}; t[pos]=val end },
      "concat" => ->(t, sep="", i=1, j=nil){ j ||= t.length; (i.to_i..j.to_i).map{|k|fmt(t[k])}.join(sep.to_s) },
      "sort" => ->(t){ arr=(1..t.length).map{|i|t[i]}.sort; arr.each_with_index{|v,i|t[i+1]=v}; nil },
      "remove" => ->(t,pos=nil){ pos=(pos||t.length).to_i; v=t[pos]; (pos...t.length).each{|i|t[i]=t[i+1]}; t[t.length]=nil; v }))
    g.local_set("os", table_from_hash("clock" => ->(){Process.clock_gettime(Process::CLOCK_MONOTONIC)}, "time" => ->(){Time.now.to_i}, "date" => ->(f=nil,t=nil){Time.at(t||Time.now).strftime(f||"%c")}, "exit" => ->(c=0){exit c.to_i}))
    g.local_set("io", table_from_hash("write" => ->(*a){ STDOUT.write(a.map { |x| fmt(x) }.join); nil },
      "read" => ->(*_a){ STDIN.gets&.chomp },
      "flush" => ->(){ STDOUT.flush; nil },
      "open" => ->(path, mode="r"){ File.open(path.to_s, mode.to_s) }))
  end
  def require_lua(name)
    return @global.get(name) if @global.get(name)
    candidates = ["#{name}.lua", name.tr(".", "/") + ".lua"]
    path = candidates.find { |p| File.file?(p) }
    raise LuaError, "module '#{name}' not found" unless path
    run(File.read(path), path)
    @global.get(name) || true
  end
end

def usage
  puts "usage: ./executable [options]... [script [args]...]."
  puts "Available options are:"
  puts "  -e chunk  Execute string 'chunk'."
  puts "  -l name   Require library 'name'."
  puts "  -b ...    Save or list bytecode."
  puts "  -j cmd    Perform LuaJIT control command."
  puts "  -O[opt]   Control LuaJIT optimizations."
  puts "  -i        Enter interactive mode after executing 'script'."
  puts "  -v        Show version information."
  puts "  -E        Ignore environment variables."
  puts "  --        Stop handling options."
  puts "  -         Execute stdin and stop handling options."
end

chunks = []
libs = []
show_version = false
script = nil
script_args = []
i = 0
while i < ARGV.length
  a = ARGV[i]
  case a
  when "--help", "-h"
    usage; exit 1
  when "-v"
    show_version = true; i += 1
  when "-E", "-i"
    i += 1
  when "--"
    script = ARGV[i+1]; script_args = ARGV[(i+2)..] || []; break
  when "-"
    chunks << STDIN.read; i += 1; break
  when "-e"
    chunks << (ARGV[i+1] || ""); i += 2
  when /^-e(.+)/
    chunks << $1; i += 1
  when "-l"
    libs << (ARGV[i+1] || ""); i += 2
  when /^-l(.+)/
    libs << $1; i += 1
  when /^-j/, /^-O/
    i += 1
  when /^-b/
    warn "./executable: unknown luaJIT command or jit.* modules not installed"; exit 1
  else
    if a.start_with?("-")
      usage; exit 1
    end
    script = a; script_args = ARGV[(i+1)..] || []; break
  end
end

puts "#{Runtime::VERSION} -- Copyright (C) 2005-2026 Mike Pall. https://luajit.org/" if show_version
rt = Runtime.new([script || "=(command line)", *script_args])
libs.each { |l| rt.call_value(rt.global.get("require"), [l]) }
chunks.each { |c| rt.run(c) }
rt.run(File.read(script), script) if script
exit 0 if chunks.empty? && script.nil? && !show_version
