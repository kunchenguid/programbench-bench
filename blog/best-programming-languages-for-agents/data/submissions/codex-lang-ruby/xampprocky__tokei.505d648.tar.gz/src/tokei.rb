#!/usr/bin/env ruby
# frozen_string_literal: true

require "yaml"
require "find"
require "fileutils"

VERSION = "tokei 14.0.0 compiled with serialization support: json"

LANGS = {
  "abap" => "ABAP", "adb" => "Ada", "ads" => "Ada", "ada" => "Ada",
  "asm" => "Assembly", "s" => "GNU Style Assembly",
  "awk" => "AWK", "bash" => "BASH", "bat" => "Batch", "cmd" => "Batch",
  "c" => "C", "h" => "C Header", "cc" => "C++", "cpp" => "C++", "cxx" => "C++",
  "hpp" => "C++ Header", "hh" => "C++ Header", "hxx" => "C++ Header",
  "cs" => "C#", "css" => "CSS", "cu" => "CUDA", "d" => "D", "dart" => "Dart",
  "ex" => "Elixir", "exs" => "Elixir", "erl" => "Erlang", "hrl" => "Erlang",
  "fs" => "F#", "fsi" => "F#", "go" => "Go", "graphql" => "GraphQL",
  "groovy" => "Groovy", "hs" => "Haskell", "html" => "HTML", "htm" => "HTML",
  "java" => "Java", "js" => "JavaScript", "mjs" => "JavaScript", "cjs" => "JavaScript",
  "jsx" => "JSX", "json" => "JSON", "jl" => "Julia", "kt" => "Kotlin", "kts" => "Kotlin",
  "less" => "Less", "lua" => "Lua", "md" => "Markdown", "markdown" => "Markdown",
  "mdx" => "MDX", "ml" => "OCaml", "mli" => "OCaml", "nim" => "Nim",
  "nix" => "Nix", "php" => "PHP", "pl" => "Perl", "pm" => "Perl",
  "proto" => "Protobuf", "ps1" => "PowerShell", "py" => "Python", "pyw" => "Python",
  "r" => "R", "rb" => "Ruby", "rs" => "Rust", "sass" => "Sass", "scss" => "Sass",
  "scala" => "Scala", "scm" => "Scheme", "sh" => "Shell", "sql" => "SQL",
  "svelte" => "Svelte", "swift" => "Swift", "tex" => "TeX", "toml" => "TOML",
  "ts" => "TypeScript", "tsx" => "TSX", "vue" => "Vue", "xml" => "XML",
  "xaml" => "XAML", "yaml" => "YAML", "yml" => "YAML", "zig" => "Zig"
}

BASENAMES = {
  "Makefile" => "Makefile", "makefile" => "Makefile", "GNUmakefile" => "Makefile",
  "Dockerfile" => "Dockerfile", "dockerfile" => "Dockerfile",
  "CMakeLists.txt" => "CMake", "Rakefile" => "Ruby", "Gemfile" => "Ruby",
  "Cargo.toml" => "TOML", "go.mod" => "Go", "go.sum" => "Go"
}

EXTENSIONS_FOR_LIST = {
  "ABAP" => "abap", "AWK" => "awk", "Ada" => "ada, adb, ads", "Assembly" => "asm",
  "BASH" => "bash", "Batch" => "bat, cmd", "C" => "c", "C Header" => "h",
  "C++" => "cc, cpp, cxx", "C++ Header" => "hh, hpp, hxx", "C#" => "cs",
  "CSS" => "css", "D" => "d", "Dart" => "dart", "Dockerfile" => "dockerfile",
  "Elixir" => "ex, exs", "Erlang" => "erl, hrl", "F#" => "fs, fsi",
  "Go" => "go", "GraphQL" => "graphql", "Groovy" => "groovy", "HTML" => "html, htm",
  "Haskell" => "hs", "JSON" => "json", "JSX" => "jsx", "Java" => "java",
  "JavaScript" => "js, mjs, cjs", "Julia" => "jl", "Kotlin" => "kt, kts",
  "Less" => "less", "Lua" => "lua", "Makefile" => "makefile", "Markdown" => "md, markdown",
  "Nim" => "nim", "OCaml" => "ml, mli", "PHP" => "php", "Perl" => "pl, pm",
  "PowerShell" => "ps1", "Protobuf" => "proto", "Python" => "py, pyw",
  "R" => "r", "Ruby" => "rb", "Rust" => "rs", "SQL" => "sql", "Sass" => "sass, scss",
  "Scala" => "scala", "Shell" => "sh", "Swift" => "swift", "TOML" => "toml",
  "TSX" => "tsx", "TypeScript" => "ts", "XML" => "xml", "YAML" => "yaml, yml",
  "Zig" => "zig"
}

SLASH_BLOCK = %w[C C\ Header C++ C++\ Header C# CSS CUDA D Dart Go Java JavaScript JSX Kotlin Less
                 PHP Protobuf Rust Sass Scala Swift TSX TypeScript Zig].freeze
HASH_LINE = %w[AWK BASH Dockerfile Makefile Perl PowerShell Python R Ruby Shell TOML YAML].freeze
HTML_BLOCK = %w[HTML XML Vue Svelte Markdown MDX].freeze

class Stat
  attr_accessor :blanks, :code, :comments

  def initialize(blanks = 0, code = 0, comments = 0)
    @blanks = blanks
    @code = code
    @comments = comments
  end

  def lines
    @blanks + @code + @comments
  end

  def add(other)
    @blanks += other.blanks
    @code += other.code
    @comments += other.comments
  end

  def to_h
    { "blanks" => @blanks, "code" => @code, "comments" => @comments, "blobs" => {} }
  end
end

def usage
  <<~TXT.chomp
    Count your code, quickly.
    Support this project on GitHub Sponsors: https://github.com/sponsors/XAMPPRocky

    Usage: executable [OPTIONS] [input]...

    Arguments:
      [input]...  The path(s) to the file or directory to be counted. (default current directory)

    Options:
      -c, --columns <columns>              Sets a strict column width of the output, only available for
                                           terminal output.
      -e, --exclude <exclude>              Ignore all files & directories matching the pattern.
      -f, --files                          Will print out statistics on individual files.
      -i, --input <file_input>             Gives statistics from a previous tokei run. Can be given a
                                           file path, or "stdin" to read from stdin.
          --hidden                         Count hidden files.
      -l, --languages                      Prints out supported languages and their extensions.
      -o, --output <output>                Outputs Tokei in a specific format. Compile with additional
                                           features for more format support.
          --streaming <streaming>          prints the records as simple lines or as Json
                                           [possible values: simple, json]
      -s, --sort <sort>                    Sort languages based on column [possible values: files,
                                           lines, blanks, code, comments]
      -r, --rsort <rsort>                  Reverse sort languages based on column [possible values:
                                           files, lines, blanks, code, comments]
      -t, --types <types>                  Filters output by language type, separated by a comma.
      -C, --compact                        Do not print statistics about embedded languages.
      -n, --num-format <num_format_style>  Format of printed numbers [possible values: commas, dots,
                                           plain, underscores]
      -v, --verbose...                     Set log output level
      -h, --help                           Print help
      -V, --version                        Print version
  TXT
end

def json_escape(str)
  str.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
    { "\"" => "\\\"", "\\" => "\\\\", "\b" => "\\b", "\f" => "\\f",
      "\n" => "\\n", "\r" => "\\r", "\t" => "\\t" }[ch]
  end
end

def json_generate(obj)
  case obj
  when Hash
    "{" + obj.map { |k, v| "\"#{json_escape(k)}\":#{json_generate(v)}" }.join(",") + "}"
  when Array
    "[" + obj.map { |v| json_generate(v) }.join(",") + "]"
  when String
    "\"#{json_escape(obj)}\""
  when Integer
    obj.to_s
  when TrueClass
    "true"
  when FalseClass
    "false"
  when NilClass
    "null"
  else
    "\"#{json_escape(obj)}\""
  end
end

def parse_args(argv)
  opts = { inputs: [], exclude: [], num: "plain" }
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when "-h", "--help" then opts[:help] = true
    when "-V", "--version" then opts[:version] = true
    when "-f", "--files" then opts[:files] = true
    when "--hidden" then opts[:hidden] = true
    when "-l", "--languages" then opts[:languages] = true
    when "--no-ignore", "--no-ignore-parent", "--no-ignore-dot", "--no-ignore-vcs" then opts[:no_ignore] = true
    when "-C", "--compact" then opts[:compact] = true
    when /^-v+$/ then opts[:verbose] = a.length - 1
    when "--"
      opts[:inputs].concat(argv[(i + 1)..] || [])
      break
    when "-e", "--exclude" then i += 1; opts[:exclude] << argv[i].to_s
    when /^--exclude=(.*)$/ then opts[:exclude] << Regexp.last_match(1)
    when "-o", "--output" then i += 1; opts[:output] = argv[i]
    when /^--output=(.*)$/ then opts[:output] = Regexp.last_match(1)
    when "-i", "--input" then i += 1; opts[:input] = argv[i]
    when /^--input=(.*)$/ then opts[:input] = Regexp.last_match(1)
    when "--streaming" then i += 1; opts[:streaming] = argv[i]
    when /^--streaming=(.*)$/ then opts[:streaming] = Regexp.last_match(1)
    when "-s", "--sort" then i += 1; opts[:sort] = argv[i]
    when /^--sort=(.*)$/ then opts[:sort] = Regexp.last_match(1)
    when "-r", "--rsort" then i += 1; opts[:rsort] = argv[i]
    when /^--rsort=(.*)$/ then opts[:rsort] = Regexp.last_match(1)
    when "-t", "--types", "--type" then i += 1; opts[:types] = argv[i]
    when /^--types?=(.*)$/ then opts[:types] = Regexp.last_match(1)
    when "-c", "--columns" then i += 1; opts[:columns] = argv[i].to_i
    when /^--columns=(.*)$/ then opts[:columns] = Regexp.last_match(1).to_i
    when "-n", "--num-format" then i += 1; opts[:num] = argv[i]
    when /^--num-format=(.*)$/ then opts[:num] = Regexp.last_match(1)
    else
      if a.start_with?("-")
        warn "error: unexpected argument '#{a}' found\n\nUsage: executable [OPTIONS] [input]...\n\nFor more information, try '--help'."
        exit 2
      end
      opts[:inputs] << a
    end
    i += 1
  end
  opts[:inputs] = ["."] if opts[:inputs].empty?
  opts
end

def language_for(path)
  base = File.basename(path)
  return BASENAMES[base] if BASENAMES.key?(base)
  ext = File.extname(path).sub(/^\./, "").downcase
  LANGS[ext]
end

def strip_strings(line)
  out = +""
  quote = nil
  esc = false
  line.each_char do |ch|
    if quote
      if esc
        esc = false
      elsif ch == "\\"
        esc = true
      elsif ch == quote
        quote = nil
      end
      out << " "
    elsif ch == "\"" || ch == "'"
      quote = ch
      out << " "
    else
      out << ch
    end
  end
  out
end

def classify_line(line, lang, state)
  return :blank if line.strip.empty? && !state[:block] && !state[:ruby_block]
  return :comment if %w[Markdown MDX ReStructuredText AsciiDoc Text].include?(lang)

  if state[:ruby_block]
    state[:ruby_block] = false if line.strip == "=end"
    return :comment
  end
  if lang == "Ruby" && line.strip == "=begin"
    state[:ruby_block] = true
    return :comment
  end

  if state[:block]
    if (idx = line.index(state[:block_end]))
      rest = line[(idx + state[:block_end].length)..] || ""
      state[:block] = nil
      return rest.strip.empty? ? :comment : :code
    end
    return :comment
  end

  stripped = line.strip
  return :comment if HASH_LINE.include?(lang) && stripped.start_with?("#") && !(lang == "Ruby" && stripped.start_with?("#!"))
  return :comment if %w[SQL Haskell Lua].include?(lang) && stripped.start_with?("--")
  return :comment if lang == "TeX" && stripped.start_with?("%")
  return :comment if %w[Lisp Scheme Clojure].include?(lang) && stripped.start_with?(";")

  scan = strip_strings(line)
  if SLASH_BLOCK.include?(lang)
    slash = scan.index("//")
    block = scan.index("/*")
    if block && (!slash || block < slash)
      before = scan[0...block].strip
      after_start = scan[(block + 2)..] || ""
      end_idx = after_start.index("*/")
      unless end_idx
        state[:block] = true
        state[:block_end] = "*/"
      end
      return before.empty? ? :comment : :code
    end
    return :comment if slash && scan[0...slash].strip.empty?
  elsif HTML_BLOCK.include?(lang)
    block = scan.index("<!--")
    if block
      before = scan[0...block].strip
      after_start = scan[(block + 4)..] || ""
      unless after_start.include?("-->")
        state[:block] = true
        state[:block_end] = "-->"
      end
      return before.empty? ? :comment : :code
    end
  end
  :code
end

def count_file(path, lang)
  stat = Stat.new
  state = {}
  data = File.binread(path)
  data = data.encode("UTF-8", invalid: :replace, undef: :replace, replace: "")
  lines = data.lines
  lines = [""] if data.empty? && false
  lines.each do |line|
    case classify_line(line.chomp, lang, state)
    when :blank then stat.blanks += 1
    when :comment then stat.comments += 1
    else stat.code += 1
    end
  end
  stat
rescue StandardError
  Stat.new
end

def ignored_by_pattern?(path, patterns)
  base = File.basename(path)
  patterns.any? do |pat|
    File.fnmatch?(pat, path, File::FNM_PATHNAME | File::FNM_DOTMATCH) ||
      File.fnmatch?(pat, base, File::FNM_DOTMATCH) ||
      path.include?(pat)
  end
end

def load_ignore_patterns(dir)
  pats = []
  %w[.gitignore .ignore .tokeignore].each do |name|
    file = File.join(dir, name)
    next unless File.file?(file)
    File.readlines(file, chomp: true).each do |line|
      s = line.strip
      next if s.empty? || s.start_with?("#") || s.start_with?("!")
      pats << s.sub(%r{^/}, "")
    end
  rescue StandardError
  end
  pats
end

def each_source_file(inputs, opts)
  inputs.each do |input|
    unless File.exist?(input)
      warn "Error: '#{input}' not found."
      exit 1
    end
    if File.file?(input)
      yield File.expand_path(input) if language_for(input)
      next
    end
    root = File.expand_path(input)
    root_ignores = opts[:no_ignore] ? [] : load_ignore_patterns(root)
    Find.find(root) do |path|
      base = File.basename(path)
      rel = path.sub(%r{^#{Regexp.escape(root)}/?}, "")
      if File.directory?(path)
        if base == ".git" || (!opts[:hidden] && base.start_with?(".") && path != root) ||
           ignored_by_pattern?(rel, root_ignores + opts[:exclude])
          Find.prune
        end
        next
      end
      next if !opts[:hidden] && base.start_with?(".")
      next if ignored_by_pattern?(rel, root_ignores + opts[:exclude])
      yield path if language_for(path)
    end
  end
end

def empty_groups
  Hash.new { |h, k| h[k] = { stat: Stat.new, reports: [] } }
end

def add_report(groups, lang, name, stat)
  groups[lang][:stat].add(stat)
  groups[lang][:reports] << { name: name, stat: stat }
end

def collect_counts(opts)
  groups = empty_groups
  each_source_file(opts[:inputs], opts) do |path|
    lang = language_for(path)
    stat = count_file(path, lang)
    add_report(groups, lang, path, stat)
    if opts[:streaming]
      if opts[:streaming] == "json"
        puts json_generate({ "language" => lang, "stats" => { "name" => path, "stats" => stat.to_h } })
      elsif opts[:streaming] == "simple"
        @stream_header ||= begin
          puts "# language                                        path                                          lines         code       comments      blanks   "
          puts "########## ################################################################################ ############ ############ ############ ############"
          true
        end
        printf "%10s %-80s %12d %12d %12d %12d\n", lang, path, stat.lines, stat.code, stat.comments, stat.blanks
      end
    end
  end
  groups
end

def merge_input(groups, source)
  text = source == "stdin" ? STDIN.read : File.read(source)
  data = YAML.safe_load(text, permitted_classes: [], aliases: true)
  data.each do |lang, val|
    next if lang == "Total"
    Array(val["reports"]).each do |rep|
      s = rep["stats"] || {}
      stat = Stat.new(s["blanks"].to_i, s["code"].to_i, s["comments"].to_i)
      add_report(groups, lang, rep["name"].to_s, stat)
    end
  end
rescue StandardError => e
  warn "Error: #{e.message}"
  exit 1
end

def filter_and_sort(groups, opts)
  rows = groups.keys
  if opts[:types]
    allowed = opts[:types].split(",").map(&:strip)
    rows.select! { |k| allowed.include?(k) }
  end
  metric = opts[:sort] || opts[:rsort]
  if metric
    rows.sort_by! do |lang|
      g = groups[lang]
      val = metric == "files" ? g[:reports].length : (metric == "lines" ? g[:stat].lines : g[:stat].send(metric))
      opts[:sort] ? [-val, lang] : [val, lang.reverse]
    end
  else
    rows.sort!
  end
  rows
end

def build_json(groups, opts)
  out = {}
  rows = filter_and_sort(groups, opts)
  total = Stat.new
  children = {}
  rows.each do |lang|
    g = groups[lang]
    reports = g[:reports].sort_by { |r| r[:name] }.map { |r| { "stats" => r[:stat].to_h, "name" => r[:name] } }
    out[lang] = { "blanks" => g[:stat].blanks, "code" => g[:stat].code, "comments" => g[:stat].comments,
                  "reports" => reports, "children" => {}, "inaccurate" => false }
    total.add(g[:stat])
    children[lang] = reports
  end
  out["Total"] = { "blanks" => total.blanks, "code" => total.code, "comments" => total.comments,
                   "reports" => [], "children" => children, "inaccurate" => false }
  out
end

def fmt_num(n, style)
  s = n.to_s
  sep = { "commas" => ",", "dots" => ".", "underscores" => "_" }[style]
  return s unless sep
  s.reverse.gsub(/(\d{3})(?=\d)/, "\\1#{sep}").reverse
end

def print_table(groups, opts)
  rows = filter_and_sort(groups, opts)
  width = [opts[:columns].to_i, 81].max
  width = 81 if opts[:columns].to_i <= 0
  heavy = "━" * width
  light = "─" * width
  puts heavy
  puts format(" %-18s %8s %12s %12s %12s %12s", "Language", "Files", "Lines", "Code", "Comments", "Blanks")
  puts heavy
  total = Stat.new
  total_files = 0
  rows.each do |lang|
    g = groups[lang]
    total.add(g[:stat])
    total_files += g[:reports].length
    puts format(" %-18s %8s %12s %12s %12s %12s", lang, fmt_num(g[:reports].length, opts[:num]),
                fmt_num(g[:stat].lines, opts[:num]), fmt_num(g[:stat].code, opts[:num]),
                fmt_num(g[:stat].comments, opts[:num]), fmt_num(g[:stat].blanks, opts[:num]))
    if opts[:files]
      puts light
      g[:reports].sort_by { |r| r[:name] }.each do |r|
        name = r[:name]
        name = name[0, 34] + "..." if name.length > 37
        puts format(" %-37s %12s %12s %12s %12s", name, fmt_num(r[:stat].lines, opts[:num]),
                    fmt_num(r[:stat].code, opts[:num]), fmt_num(r[:stat].comments, opts[:num]),
                    fmt_num(r[:stat].blanks, opts[:num]))
      end
      puts light
    end
  end
  puts heavy
  puts format(" %-18s %8s %12s %12s %12s %12s", "Total", fmt_num(total_files, opts[:num]),
              fmt_num(total.lines, opts[:num]), fmt_num(total.code, opts[:num]),
              fmt_num(total.comments, opts[:num]), fmt_num(total.blanks, opts[:num]))
  puts heavy
end

def print_languages
  width = 72
  puts "━" * width
  puts "┃ #{'Language'.ljust(37)} Extensions#{' ' * 20}┃"
  puts "┃" + "━" * (width - 2) + "┃"
  EXTENSIONS_FOR_LIST.sort.each do |lang, exts|
    shown = exts.length > 30 ? exts[0, 27] + "..." : exts
    puts "┃ #{lang.ljust(37)} #{shown.ljust(30)} ┃"
  end
  puts "━" * width
end

opts = parse_args(ARGV)
if opts[:help]
  puts usage
  exit 0
end
if opts[:version]
  puts VERSION
  exit 0
end
if opts[:languages]
  print_languages
  exit 0
end
if opts[:output] && opts[:output] != "json"
  warn "error: invalid value '#{opts[:output]}' for '--output <output>': This version of tokei was compiled without any '#{opts[:output]}' serialization support, to enable serialization, reinstall tokei with the features flag."
  exit 2
end

groups = collect_counts(opts)
merge_input(groups, opts[:input]) if opts[:input]
exit 0 if opts[:streaming]

if opts[:output] == "json"
  puts json_generate(build_json(groups, opts))
else
  print_table(groups, opts)
end
