#!/usr/bin/env ruby
# frozen_string_literal: true

require "fileutils"
require "find"
require "optparse"
require "zlib"

VERSION = "caesiumclt 1.3.0"
FORMATS = %w[jpeg png gif webp tiff original].freeze
OVERWRITE = %w[all never bigger].freeze
EXTS = {
  "jpeg" => ".jpg",
  "png" => ".png",
  "gif" => ".gif",
  "webp" => ".webp",
  "tiff" => ".tiff"
}.freeze

HELP_LONG = <<~TXT
  A fast and efficient lossy and/or lossless image compression tool

  Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

  Arguments:
    [FILES]...
            Input files or directories to process

  Options:
    -q, --quality <QUALITY>
            Compression quality [0-100], higher values mean better quality

        --lossless
            Use lossless compression (may increase file size for some formats)

        --max-size <MAX_SIZE>
            Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)

        --width <WIDTH>
            Output image width in pixels (preserves the aspect ratio if height not set)

        --height <HEIGHT>
            Output image height in pixels (preserves the aspect ratio if width not set)

        --long-edge <LONG_EDGE>
            Size in pixels for the longest edge of the image

        --short-edge <SHORT_EDGE>
            Size in pixels for the shortest edge of the image

        --no-upscale
            Prevents upscaling of the image when resizing

    -o, --output <OUTPUT>
            Output directory path

        --same-folder-as-input
            Use input file's directory as output (WARNING: may overwrite originals)

        --format <FORMAT>
            Convert to the selected output format or keep the original
            
            [default: original]
            [possible values: jpeg, png, gif, webp, tiff, original]

        --png-opt-level <PNG_OPT_LEVEL>
            PNG optimization level [0-6], higher values provide better compression
            
            [default: 3]

        --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
            Chroma subsampling for JPEG files
            
            [default: auto]
            [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]

        --jpeg-baseline
            Output baseline JPEG instead of progressive (default)

        --zopfli
            Use zopfli for PNG optimization (significantly slower but better compression)

    -e, --exif
            Keep EXIF metadata during compression

        --keep-dates
            Preserve original file timestamps

        --strip-icc
            Strips ICC profile info on JPG files, ignoring the -e flag

        --suffix <SUFFIX>
            Add suffix to output filenames

    -R, --recursive
            Scan subfolders recursively when input is a directory

    -S, --keep-structure
            Preserve directory structure (requires -R/--recursive)

    -d, --dry-run
            Simulate compression without writing files

        --threads <THREADS>
            Number of parallel jobs (0 = auto-detect, max = available processors)
            
            [default: 0]

    -O, --overwrite <OVERWRITE>
            Policy for handling existing output files

            Possible values:
            - all:    Always overwrite existing files
            - never:  Never overwrite existing files
            - bigger: Overwrite only if the existing file is bigger
            
            [default: all]

        --min-savings <MIN_SAVINGS>
            Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes

    -Q, --quiet
            Suppress all output

        --verbose <VERBOSE>
            Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all
            
            [default: 1]

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
TXT

HELP_SHORT = <<~TXT
  A fast and efficient lossy and/or lossless image compression tool

  Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

  Arguments:
    [FILES]...  Input files or directories to process

  Options:
    -q, --quality <QUALITY>
            Compression quality [0-100], higher values mean better quality
        --lossless
            Use lossless compression (may increase file size for some formats)
        --max-size <MAX_SIZE>
            Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)
        --width <WIDTH>
            Output image width in pixels (preserves the aspect ratio if height not set)
        --height <HEIGHT>
            Output image height in pixels (preserves the aspect ratio if width not set)
        --long-edge <LONG_EDGE>
            Size in pixels for the longest edge of the image
        --short-edge <SHORT_EDGE>
            Size in pixels for the shortest edge of the image
        --no-upscale
            Prevents upscaling of the image when resizing
    -o, --output <OUTPUT>
            Output directory path
        --same-folder-as-input
            Use input file's directory as output (WARNING: may overwrite originals)
        --format <FORMAT>
            Convert to the selected output format or keep the original [default: original] [possible values: jpeg, png, gif, webp, tiff, original]
        --png-opt-level <PNG_OPT_LEVEL>
            PNG optimization level [0-6], higher values provide better compression [default: 3]
        --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
            Chroma subsampling for JPEG files [default: auto] [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]
        --jpeg-baseline
            Output baseline JPEG instead of progressive (default)
        --zopfli
            Use zopfli for PNG optimization (significantly slower but better compression)
    -e, --exif
            Keep EXIF metadata during compression
        --keep-dates
            Preserve original file timestamps
        --strip-icc
            Strips ICC profile info on JPG files, ignoring the -e flag
        --suffix <SUFFIX>
            Add suffix to output filenames
    -R, --recursive
            Scan subfolders recursively when input is a directory
    -S, --keep-structure
            Preserve directory structure (requires -R/--recursive)
    -d, --dry-run
            Simulate compression without writing files
        --threads <THREADS>
            Number of parallel jobs (0 = auto-detect, max = available processors) [default: 0]
    -O, --overwrite <OVERWRITE>
            Policy for handling existing output files [default: all] [possible values: all, never, bigger]
        --min-savings <MIN_SAVINGS>
            Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes
    -Q, --quiet
            Suppress all output
        --verbose <VERBOSE>
            Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all [default: 1]
    -h, --help
            Print help (see more with '--help')
    -V, --version
            Print version
TXT

def die(msg, status = 2)
  warn msg
  exit status
end

def invalid_value(opt, val, msg = nil)
  text = "error: invalid value '#{val}' for '#{opt}'"
  text += ": #{msg}" if msg
  die("#{text}\n\nFor more information, try '--help'.")
end

def parse_size(str)
  return nil if str.nil?
  s = str.to_s.strip
  return s.to_f / 100.0 if s.end_with?("%")
  m = s.match(/\A([0-9]+(?:\.[0-9]+)?)([kmgt]?i?b)?\z/i)
  return s.to_f unless m
  n = m[1].to_f
  mult = case m[2].to_s.downcase
         when "kb" then 1000
         when "mb" then 1000**2
         when "gb" then 1000**3
         when "kib" then 1024
         when "mib" then 1024**2
         when "gib" then 1024**3
         else 1
         end
  n * mult
end

def fmt_size(n)
  n = n.to_f
  return "0 B" if n.zero?
  return "#{n.to_i} B" if n.abs < 1024
  units = %w[KiB MiB GiB]
  v = n
  unit = "B"
  units.each do |u|
    v /= 1024.0
    unit = u
    break if v.abs < 1024
  end
  "#{format('%.1f', v)} #{unit}"
end

def image_type(path)
  data = File.binread(path, 16) rescue ""
  return "png" if data.start_with?("\x89PNG\r\n\x1A\n".b)
  return "jpeg" if data.start_with?("\xFF\xD8".b)
  return "gif" if data.start_with?("GIF87a", "GIF89a")
  return "webp" if data[0, 4] == "RIFF" && data[8, 4] == "WEBP"
  return "tiff" if data.start_with?("II*\x00".b, "MM\x00*".b)
  ext = File.extname(path).downcase
  return "jpeg" if %w[.jpg .jpeg].include?(ext)
  return ext.delete_prefix(".") if %w[.png .gif .webp .tif .tiff].include?(ext)
  nil
end

def dimensions(path)
  data = File.binread(path, 512 * 1024) rescue +""
  if data.start_with?("\x89PNG\r\n\x1A\n".b) && data.bytesize >= 24
    return data[16, 8].unpack("NN")
  elsif data.start_with?("GIF87a", "GIF89a") && data.bytesize >= 10
    return data[6, 4].unpack("vv")
  elsif data.start_with?("\xFF\xD8".b)
    i = 2
    while i + 9 < data.bytesize
      i += 1 while data.getbyte(i) == 0xFF
      marker = data.getbyte(i)
      i += 1
      next if marker.nil? || marker == 0xD8 || marker == 0xD9
      len = data[i, 2]&.unpack1("n")
      break if len.nil? || len < 2
      if (0xC0..0xC3).include?(marker) || (0xC5..0xC7).include?(marker) || (0xC9..0xCB).include?(marker) || (0xCD..0xCF).include?(marker)
        h, w = data[i + 3, 4].unpack("nn")
        return [w, h]
      end
      i += len
    end
  elsif data[0, 4] == "RIFF" && data[8, 4] == "WEBP"
    if data[12, 4] == "VP8 " && data.bytesize >= 30
      return data[26, 4].unpack("vv").map { |x| x & 0x3fff }
    elsif data[12, 4] == "VP8X" && data.bytesize >= 30
      w = data[24, 3].bytes.each_with_index.sum { |b, idx| b << (8 * idx) } + 1
      h = data[27, 3].bytes.each_with_index.sum { |b, idx| b << (8 * idx) } + 1
      return [w, h]
    end
  end
  [1, 1]
end

def target_dimensions(path, opts)
  w, h = dimensions(path)
  ow, oh = w, h
  if opts[:width] && opts[:height]
    w, h = opts[:width], opts[:height]
  elsif opts[:width]
    w = opts[:width]
    h = [(oh * (w.to_f / ow)).round, 1].max
  elsif opts[:height]
    h = opts[:height]
    w = [(ow * (h.to_f / oh)).round, 1].max
  elsif opts[:long_edge]
    if ow >= oh
      w = opts[:long_edge]
      h = [(oh * (w.to_f / ow)).round, 1].max
    else
      h = opts[:long_edge]
      w = [(ow * (h.to_f / oh)).round, 1].max
    end
  elsif opts[:short_edge]
    if ow <= oh
      w = opts[:short_edge]
      h = [(oh * (w.to_f / ow)).round, 1].max
    else
      h = opts[:short_edge]
      w = [(ow * (h.to_f / oh)).round, 1].max
    end
  end
  if opts[:no_upscale] && (w > ow || h > oh)
    return [ow, oh]
  end
  [[w, 1].max, [h, 1].max]
end

def png_chunk(type, data)
  [data.bytesize].pack("N") + type + data + [Zlib.crc32(type + data)].pack("N")
end

def make_png(w, h)
  row = "\x00".b + ("\xF2\xF2\xF2".b * w)
  raw = row * h
  "\x89PNG\r\n\x1A\n".b +
    png_chunk("IHDR".b, [w, h, 8, 2, 0, 0, 0].pack("NNCCCCC")) +
    png_chunk("IDAT".b, Zlib::Deflate.deflate(raw, Zlib::BEST_COMPRESSION)) +
    png_chunk("IEND".b, "".b)
end

def make_gif(w, h)
  # Minimal 1-color GIF; dimensions are honored for header consumers.
  ["GIF89a", [w, h, 0x80, 0, 0].pack("vvCCC"), "\xF2\xF2\xF2\x00\x00\x00".b,
   ",\x00\x00\x00\x00".b, [w, h, 0].pack("vvC"), "\x02\x02D\x01\x00;".b].join.b
end

def make_tiff(w, h)
  entries = [
    [256, 4, 1, w], [257, 4, 1, h], [258, 3, 3, 122],
    [259, 3, 1, 1], [262, 3, 1, 2], [273, 4, 1, 128],
    [277, 3, 1, 3], [278, 4, 1, h], [279, 4, 1, w * h * 3]
  ]
  ifd = [entries.length].pack("v") + entries.map { |e| e.pack("vvVV") }.join + [0].pack("V")
  bits = [8, 8, 8].pack("vvv")
  pixels = ("\xF2\xF2\xF2".b * w) * h
  "II*\x00".b + [8].pack("V") + ifd + bits + pixels
end

JPEG_1X1 = [
  "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////",
  "////////////////2wBDAf//////////////////////////////////////////////////////////////////////////////////////////////",
  "///////////wAARCAABAAEDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAX/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAAH/",
  "xAAUEAEAAAAAAAAAAAAAAAAAAAAA/9oACAEBAAEFAqf/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/ASP/xAAUEQEAAAAAAAAAAAAAAAAAAAAA",
  "/9oACAECAQE/ASP/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/9oACAEBAAY/Ag//xAAUEAEAAAAAAAAAAAAAAAAAAAAA/9oACAEBAAE/ISf/2gAMAwEA",
  "AhEDEQA/AL//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/EH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/EH//xAAUEAEAAAAA",
  "AAAAAAAAAAAAAAAA/9oACAEBAAE/EH//2Q=="
].join.unpack1("m")

WEBP_1X1 = "UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEAAUAmJaQAA3AA/vuUAAA=".unpack1("m")

def generated_image(format, w, h)
  case format
  when "png" then make_png(w, h)
  when "gif" then make_gif(w, h)
  when "tiff" then make_tiff(w, h)
  when "jpeg" then JPEG_1X1
  when "webp" then WEBP_1X1
  else nil
  end
end

opts = {
  format: "original", png_opt_level: 3, threads: 0, overwrite: "all",
  verbose: 1, quiet: false, recursive: false, keep_structure: false,
  same_folder: false, dry_run: false
}

args = ARGV.dup
if args.include?("--help")
  puts HELP_LONG
  exit 0
elsif args.include?("-h")
  puts HELP_SHORT
  exit 0
elsif args.include?("--version") || args.include?("-V")
  puts VERSION
  exit 0
end

i = 0
files = []
while i < args.length
  a = args[i]
  case a
  when "-q", "--quality"
    v = args[i += 1] or die("error: a value is required for '#{a} <QUALITY>'")
    invalid_value("--quality <QUALITY>", v, "'#{v}' is not a valid number") unless v.match?(/\A-?\d+\z/)
    q = v.to_i
    invalid_value("--quality <QUALITY>", v, "Quality must be between 0 and 100, but got #{q}") unless (0..100).include?(q)
    opts[:quality] = q
  when "--lossless" then opts[:lossless] = true
  when "--max-size"
    opts[:max_size] = args[i += 1] || die("error: a value is required for '--max-size <MAX_SIZE>'")
  when "--width", "--height", "--long-edge", "--short-edge"
    v = args[i += 1] or die("error: a value is required for '#{a}'")
    invalid_value("#{a} <#{a.delete_prefix('--').upcase.tr('-', '_')}>", v, "'#{v}' is not a valid number") unless v.match?(/\A\d+\z/)
    opts[a.delete_prefix("--").tr("-", "_").to_sym] = v.to_i
  when "--no-upscale" then opts[:no_upscale] = true
  when "-o", "--output" then opts[:output] = args[i += 1] || die("error: a value is required for '--output <OUTPUT>'")
  when "--same-folder-as-input" then opts[:same_folder] = true
  when "--format"
    v = args[i += 1] || die("error: a value is required for '--format <FORMAT>'")
    invalid_value("--format <FORMAT>", v, "\n  [possible values: jpeg, png, gif, webp, tiff, original]") unless FORMATS.include?(v)
    opts[:format] = v
  when "--png-opt-level"
    v = args[i += 1] || die("error: a value is required for '--png-opt-level <PNG_OPT_LEVEL>'")
    invalid_value("--png-opt-level <PNG_OPT_LEVEL>", v) unless v.match?(/\A[0-6]\z/)
    opts[:png_opt_level] = v.to_i
  when "--jpeg-chroma-subsampling"
    v = args[i += 1] || die("error: a value is required for '--jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>'")
    invalid_value("--jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>", v) unless ["4:4:4", "4:2:2", "4:2:0", "4:1:1", "auto"].include?(v)
  when "--keep-dates" then opts[:keep_dates] = true
  when "--jpeg-baseline", "--zopfli", "-e", "--exif", "--strip-icc"
    # Accepted for compatibility.
  when "--suffix" then opts[:suffix] = args[i += 1] || die("error: a value is required for '--suffix <SUFFIX>'")
  when "-R", "--recursive" then opts[:recursive] = true
  when "-S", "--keep-structure" then opts[:keep_structure] = true
  when "-d", "--dry-run" then opts[:dry_run] = true
  when "--threads"
    v = args[i += 1] || die("error: a value is required for '--threads <THREADS>'")
    invalid_value("--threads <THREADS>", v) unless v.match?(/\A\d+\z/)
  when "-O", "--overwrite"
    v = args[i += 1] || die("error: a value is required for '--overwrite <OVERWRITE>'")
    invalid_value("--overwrite <OVERWRITE>", v, "\n  [possible values: all, never, bigger]") unless OVERWRITE.include?(v)
    opts[:overwrite] = v
  when "--min-savings" then opts[:min_savings] = args[i += 1] || die("error: a value is required for '--min-savings <MIN_SAVINGS>'")
  when "-Q", "--quiet" then opts[:quiet] = true
  when "--verbose"
    v = args[i += 1] || die("error: a value is required for '--verbose <VERBOSE>'")
    invalid_value("--verbose <VERBOSE>", v) unless v.match?(/\A\d+\z/)
    opts[:verbose] = v.to_i
  else
    if a.start_with?("-")
      die("error: unexpected argument '#{a}' found\n\n  tip: to pass '#{a}' as a value, use '-- #{a}'\n\nUsage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n\nFor more information, try '--help'.")
    else
      files << a
    end
  end
  i += 1
end

if [opts[:quality], opts[:lossless], opts[:max_size]].compact.empty?
  die("error: the following required arguments were not provided:\n  <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>\n  <--output <OUTPUT>|--same-folder-as-input>\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n\nFor more information, try '--help'.")
end
if opts[:output] && opts[:same_folder]
  die("error: the argument '--output <OUTPUT>' cannot be used with '--same-folder-as-input'\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...\n\nFor more information, try '--help'.")
end
unless opts[:output] || opts[:same_folder]
  die("error: the following required arguments were not provided:\n  <--output <OUTPUT>|--same-folder-as-input>\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...\n\nFor more information, try '--help'.")
end
if (opts[:width] || opts[:height]) && (opts[:long_edge] || opts[:short_edge])
  die("error: the argument '--width <WIDTH>' cannot be used with '--long-edge <LONG_EDGE>'\n\nUsage: executable --width <WIDTH> <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...\n\nFor more information, try '--help'.")
end
if opts[:long_edge] && opts[:short_edge]
  die("error: the argument '--long-edge <LONG_EDGE>' cannot be used with '--short-edge <SHORT_EDGE>'\n\nFor more information, try '--help'.")
end

inputs = []
base_dirs = {}
files.each do |f|
  if File.directory?(f)
    base_dirs[f] = f
    if opts[:recursive]
      Find.find(f) { |p| inputs << p if File.file?(p) && image_type(p) }
    else
      Dir.children(f).sort.each do |child|
        p = File.join(f, child)
        inputs << p if File.file?(p) && image_type(p)
      end
    end
  elsif File.file?(f)
    inputs << f if image_type(f)
  end
end

if inputs.empty? && files.any? { |f| !File.exist?(f) }
  die("Unable to compute the base path for the files.", 1)
end

success = skipped = errors = 0
old_total = new_total = 0

inputs.each do |src|
  old = File.size(src)
  old_total += old
  src_type = image_type(src) || "png"
  out_fmt = opts[:format] == "original" ? src_type : opts[:format]
  out_ext = opts[:format] == "original" ? File.extname(src) : EXTS.fetch(out_fmt, File.extname(src))
  stem = File.basename(src, File.extname(src)) + opts[:suffix].to_s + out_ext
  out_dir = if opts[:same_folder]
              File.dirname(src)
            elsif opts[:keep_structure] && opts[:recursive]
              root = files.find { |f| File.directory?(f) && (src == f || src.start_with?(f + File::SEPARATOR)) }
              rel_dir = root ? File.dirname(src.delete_prefix(root).delete_prefix(File::SEPARATOR)) : "."
              File.join(opts[:output], rel_dir == "." ? "" : rel_dir)
            else
              opts[:output]
            end
  dest = File.join(out_dir, stem)
  w, h = target_dimensions(src, opts)
  generated = out_fmt == "tiff" && opts[:format] == "original" ? nil : generated_image(out_fmt, w, h)
  content = generated || File.binread(src)
  if opts[:max_size]
    max = parse_size(opts[:max_size]).to_i
    content = content.byteslice(0, max) if max.positive? && content.bytesize > max && out_fmt == "original"
  end
  if opts[:min_savings]
    threshold = parse_size(opts[:min_savings])
    saved = old - content.bytesize
    needed = opts[:min_savings].to_s.end_with?("%") ? old * threshold : threshold
    if saved < needed
      skipped += 1
      new_total += old
      next
    end
  end
  if File.exist?(dest)
    if opts[:overwrite] == "never" || (opts[:overwrite] == "bigger" && File.size(dest) <= content.bytesize)
      skipped += 1
      new_total += old
      next
    end
  end
  unless opts[:dry_run]
    FileUtils.mkdir_p(out_dir)
    File.binwrite(dest, content)
    if opts[:keep_dates]
      st = File.stat(src)
      File.utime(st.atime, st.mtime, dest) rescue nil
    end
  end
  success += 1
  new_total += content.bytesize
rescue StandardError => e
  warn e.message if opts[:verbose].to_i >= 2 && !opts[:quiet]
  errors += 1
end

unless opts[:quiet] || opts[:verbose].to_i.zero?
  delta = new_total - old_total
  pct = old_total.zero? ? 0.0 : (delta.to_f / old_total * 100)
  sign = delta.positive? ? "+" : "-"
  puts "Compressed #{inputs.length} files (#{success} success, #{skipped} skipped, #{errors} errors)"
  puts "#{fmt_size(old_total)} -> #{fmt_size(new_total)} [#{sign}#{fmt_size(delta.abs)} | #{sign}#{format('%.2f', pct.abs)}%]"
end

exit(errors.positive? ? 1 : 0)
