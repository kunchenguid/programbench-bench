#!/usr/bin/env ruby
# frozen_string_literal: true

require "open3"
require "shellwords"

VERSION = "Hush 0.1.4"

class HushError < StandardError; end
class ReturnSignal < StandardError
  attr_reader :value
  def initialize(value) = (@value = value)
end

Token = Struct.new(:type, :text, :line, :col)

class Lexer
  KEYWORDS = %w[let function end if then else while do for in return true false nil and or not self].to_h { |k| [k, k.to_sym] }
  TWO = %w[== != <= >= ++ << >> 2> 1> && ||]

  def initialize(src, file)
    @src = src
    @file = file
    @i = 0
    @line = 1
    @col = 0
    @tokens = []
  end

  def tokens
    until eof?
      c = peek
      if c == "\n"
        adv
      elsif c =~ /\s/
        adv
      elsif c == "#"
        adv until eof? || peek == "\n"
      elsif c == '"' || c == "'"
        string
      elsif c =~ /[0-9]/
        number
      elsif c =~ /[A-Za-z_]/
        ident
      else
        punct
      end
    end
    @tokens << Token.new(:eof, "", @line, @col)
  end

  private

  def eof? = @i >= @src.length
  def peek(n = 0) = @src[@i + n]
  def adv
    ch = @src[@i]
    @i += 1
    if ch == "\n"
      @line += 1
      @col = 0
    else
      @col += 1
    end
    ch
  end

  def add(type, text, line, col) = @tokens << Token.new(type, text, line, col)

  def string
    q = adv
    line = @line
    col = @col - 1
    out = +""
    until eof? || peek == q
      ch = adv
      if ch == "\\"
        esc = adv
        out << case esc
               when "n" then "\n"
               when "t" then "\t"
               when "r" then "\r"
               when "0" then "\0"
               when "\\", "\"", "'" then esc
               else esc
               end
      else
        out << ch
      end
    end
    adv unless eof?
    add(:string, out, line, col)
  end

  def number
    line = @line
    col = @col
    s = +""
    s << adv while !eof? && peek =~ /[0-9]/
    if !eof? && peek == "."
      s << adv
      s << adv while !eof? && peek =~ /[0-9]/
    end
    if !eof? && peek =~ /[eE]/
      s << adv
      s << adv if !eof? && peek =~ /[+-]/
      s << adv while !eof? && peek =~ /[0-9]/
    end
    add(:number, s, line, col)
  end

  def ident
    line = @line
    col = @col
    s = +""
    s << adv while !eof? && peek =~ /[A-Za-z0-9_]/
    add(KEYWORDS.fetch(s, :ident), s, line, col)
  end

  def punct
    line = @line
    col = @col
    two = "#{peek}#{peek(1)}"
    if TWO.include?(two)
      2.times { adv }
      add(two.to_sym, two, line, col)
    else
      add(adv.to_sym, @src[@i - 1], line, col)
    end
  end
end

Literal = Struct.new(:value)
Var = Struct.new(:name)
ArrayLit = Struct.new(:items)
ObjLit = Struct.new(:pairs)
Bin = Struct.new(:op, :a, :b)
Unary = Struct.new(:op, :a)
Call = Struct.new(:recv, :args)
Index = Struct.new(:recv, :key)
FuncLit = Struct.new(:params, :body)
IfExpr = Struct.new(:cond, :then_body, :else_body)
CommandExpr = Struct.new(:text, :line, :col)

LetStmt = Struct.new(:name, :expr)
AssignStmt = Struct.new(:target, :expr)
ExprStmt = Struct.new(:expr)
CmdStmt = Struct.new(:text, :line, :col)
IfStmt = Struct.new(:cond, :then_body, :else_body)
WhileStmt = Struct.new(:cond, :body)
ForStmt = Struct.new(:name, :expr, :body)
ReturnStmt = Struct.new(:expr)

class Parser
  PRECEDENCE = {
    or: 1, "||": 1, and: 2, "&&": 2,
    "==": 3, "!=": 3, "<": 4, ">": 4, "<=": 4, ">=": 4,
    "+": 5, "-": 5, "++": 5, "*": 6, "/": 6, "%": 6
  }

  def initialize(tokens, src)
    @t = tokens
    @src = src
    @i = 0
  end

  def parse(stop = [:eof])
    body = []
    body << statement until stop.include?(cur.type)
    body
  end

  private

  def cur = @t[@i]
  def eat(type = nil)
    raise HushError, "expected #{type}, got #{cur.text}" if type && cur.type != type
    tok = cur
    @i += 1
    tok
  end
  def accept(type) = (cur.type == type ? eat : nil)

  def statement
    case cur.type
    when :let
      eat(:let); n = eat(:ident).text; e = accept(:"=") ? expr : nil; LetStmt.new(n, e)
    when :if
      eat(:if); c = expr; eat(:then); tb = parse(%i[else end]); eb = accept(:else) ? parse([:end]) : []; eat(:end); IfStmt.new(c, tb, eb)
    when :while
      eat(:while); c = expr; eat(:do); b = parse([:end]); eat(:end); WhileStmt.new(c, b)
    when :for
      eat(:for); n = eat(:ident).text; eat(:in); e = expr; eat(:do); b = parse([:end]); eat(:end); ForStmt.new(n, e, b)
    when :return
      eat(:return); ReturnStmt.new(%i[end else eof].include?(cur.type) ? nil : expr)
    when :"&"
      eat(:"&")
      command_statement
      if accept(:".")
        eat(:ident)
        if accept(:"(")
          eat(:")")
        end
      end
      ExprStmt.new(Literal.new(nil))
    when :"{"
      command_statement
    else
      e = expr
      if accept(:"=")
        AssignStmt.new(e, expr)
      else
        ExprStmt.new(e)
      end
    end
  end

  def command_statement
    tok = eat(:"{")
    text = collect_balanced("{", "}")
    CmdStmt.new(text, tok.line, tok.col)
  end

  def command_expr
    tok = eat(:"$")
    eat(:"{")
    text = collect_balanced("{", "}")
    CommandExpr.new(text, tok.line, tok.col)
  end

  def collect_balanced(open, close)
    start = @i
    depth = 1
    while depth > 0 && cur.type != :eof
      depth += 1 if cur.text == open
      depth -= 1 if cur.text == close
      @i += 1 if depth > 0
    end
    finish = @i
    eat(close.to_sym)
    parts = []
    toks = @t[start...finish]
    j = 0
    while j < toks.length
      if toks[j].text == "$" && toks[j + 1]&.text == "{" && toks[j + 2]&.type == :ident && toks[j + 3]&.text == "}"
        parts << "${#{toks[j + 2].text}}"
        j += 4
      elsif toks[j].text == "$" && toks[j + 1]&.type == :ident
        parts << "$#{toks[j + 1].text}"
        j += 2
      else
        parts << (toks[j].type == :string ? Shellwords.escape(toks[j].text) : toks[j].text)
        j += 1
      end
    end
    parts.join(" ").gsub(/\s+([;|])\s+/, ' \1 ').gsub(/\s+/, " ").strip
  end

  def expr(min = 0)
    left = prefix
    loop do
      break unless cur
      op = cur.text
      prec = PRECEDENCE[op.to_sym] || PRECEDENCE[op]
      break unless prec && prec >= min
      eat
      right = expr(prec + 1)
      left = Bin.new(op, left, right)
    end
    left
  end

  def prefix
    node = case cur.type
           when :number
             s = eat.text; Literal.new(s =~ /[.eE]/ ? s.to_f : s.to_i)
           when :string
             Literal.new(eat.text)
           when :true
             eat; Literal.new(true)
           when :false
             eat; Literal.new(false)
           when :nil
             eat; Literal.new(nil)
           when :ident, :self
             Var.new(eat.text)
           when :"-", :not
             op = eat.text; Unary.new(op, expr(7))
           when :"("
             eat; e = expr; eat(:")"); e
           when :"["
             array_lit
           when :"@"
             obj_lit
           when :function
             func_lit
           when :if
             if_expr
           when :"$"
             command_expr
           else
             raise HushError, "unexpected token #{cur.text.inspect}"
           end
    postfix(node)
  end

  def postfix(node)
    loop do
      case cur.type
      when :"("
        eat; args = []; args << expr until cur.type == :")" || (accept(:",") && false); while accept(:","); args << expr unless cur.type == :")"; end; eat(:")"); node = Call.new(node, args)
      when :"["
        eat; k = expr; eat(:"]"); node = Index.new(node, k)
      when :"."
        eat; node = Index.new(node, Literal.new(eat(:ident).text))
      else
        return node
      end
    end
  end

  def array_lit
    eat(:"[")
    items = []
    until cur.type == :"]"
      items << expr
      accept(:",")
    end
    eat(:"]")
    ArrayLit.new(items)
  end

  def obj_lit
    eat(:"@"); eat(:"[")
    pairs = []
    until cur.type == :"]"
      key = cur.type == :string ? eat.text : eat(:ident).text
      eat(:":")
      pairs << [key, expr]
      accept(:",")
    end
    eat(:"]")
    ObjLit.new(pairs)
  end

  def func_lit
    eat(:function)
    name = nil
    name = eat(:ident).text if cur.type == :ident
    eat(:"(")
    params = []
    until cur.type == :")"
      params << eat(:ident).text
      accept(:",")
    end
    eat(:")")
    body = parse([:end])
    eat(:end)
    f = FuncLit.new(params, body)
    name ? LetStmt.new(name, f) : f
  end

  def if_expr
    eat(:if); c = expr; eat(:then); t = parse(%i[else end]); e = accept(:else) ? parse([:end]) : []; eat(:end); IfExpr.new(c, t, e)
  end
end

class HushFunc
  def initialize(params, body, env) = (@params, @body, @env = params, body, env)
  def call(interp, args, self_obj = nil)
    env = Env.new(@env)
    @params.each_with_index { |p, i| env.define(p, args[i]) }
    env.define("self", self_obj) if self_obj
    interp.exec_block(@body, env)
  rescue ReturnSignal => r
    r.value
  end
end

class Env
  def initialize(parent = nil)
    @parent = parent
    @vars = {}
  end
  def define(k, v = nil) = (@vars[k] = v)
  def set(k, v)
    return @vars[k] = v if @vars.key?(k)
    return @parent.set(k, v) if @parent
    @vars[k] = v
  end
  def get(k)
    return @vars[k] if @vars.key?(k)
    return @parent.get(k) if @parent
    raise HushError, "undeclared variable '#{k}'"
  end
end

class Interpreter
  def initialize(file, argv = [])
    @file = file
    @env = Env.new
    @env.define("std", stdlib)
    @env.define("args", argv)
  end

  def run(body) = exec_block(body, @env)

  def exec_block(body, env)
    old = @env
    @env = env
    val = nil
    body.each { |s| val = exec(s) }
    val
  ensure
    @env = old
  end

  def exec(s)
    case s
    when LetStmt then @env.define(s.name, s.expr ? eval_expr(s.expr) : nil)
    when AssignStmt then assign(s.target, eval_expr(s.expr))
    when ExprStmt then eval_expr(s.expr)
    when CmdStmt then run_command(s.text, false)
    when IfStmt then truthy(eval_expr(s.cond)) ? exec_block(s.then_body, Env.new(@env)) : exec_block(s.else_body, Env.new(@env))
    when WhileStmt then exec_block(s.body, Env.new(@env)) while truthy(eval_expr(s.cond))
    when ForStmt
      eval_expr(s.expr).to_a.each { |v| e = Env.new(@env); e.define(s.name, v); exec_block(s.body, e) }
    when ReturnStmt then raise ReturnSignal, (s.expr ? eval_expr(s.expr) : nil)
    when LetStmt then @env.define(s.name, eval_expr(s.expr))
    else
      if s.is_a?(LetStmt) then @env.define(s.name, eval_expr(s.expr)) else nil end
    end
  end

  def eval_expr(e)
    case e
    when Literal then e.value
    when Var then @env.get(e.name)
    when ArrayLit then e.items.map { |x| eval_expr(x) }
    when ObjLit then e.pairs.to_h { |k, v| [k, eval_expr(v)] }
    when Unary
      v = eval_expr(e.a); e.op == "not" ? !truthy(v) : -v
    when Bin
      if e.op == "and" || e.op == "&&"
        av = eval_expr(e.a)
        truthy(av) ? truthy(eval_expr(e.b)) : false
      elsif e.op == "or" || e.op == "||"
        av = eval_expr(e.a)
        truthy(av) ? true : truthy(eval_expr(e.b))
      else
        bin(e.op, eval_expr(e.a), eval_expr(e.b))
      end
    when Index
      recv = eval_expr(e.recv); key = eval_expr(e.key)
      recv.is_a?(Array) ? recv[key.to_i] : recv[key.to_s]
    when Call then call(e)
    when FuncLit then HushFunc.new(e.params, e.body, @env)
    when IfExpr then exec_block(truthy(eval_expr(e.cond)) ? e.then_body : e.else_body, Env.new(@env))
    when CommandExpr then run_command(e.text, true)
    when LetStmt
      f = HushFunc.new(e.expr.params, e.expr.body, @env)
      @env.define(e.name, f)
    end
  end

  def call(e)
    recv_node = e.recv
    args = e.args.map { |a| eval_expr(a) }
    if recv_node.is_a?(Index)
      owner = eval_expr(recv_node.recv)
      fn = owner[eval_expr(recv_node.key).to_s]
      return fn.call(self, args, owner) if fn.is_a?(HushFunc)
      return fn.call(*args) if fn.respond_to?(:call)
    end
    fn = eval_expr(recv_node)
    return fn.call(self, args) if fn.is_a?(HushFunc)
    fn.call(*args)
  end

  def assign(t, v)
    case t
    when Var then @env.set(t.name, v)
    when Index
      recv = eval_expr(t.recv); key = eval_expr(t.key)
      recv.is_a?(Array) ? recv[key.to_i] = v : recv[key.to_s] = v
    end
    v
  end

  def bin(op, a, b)
    case op
    when "+" then a + b
    when "-" then a - b
    when "*" then a * b
    when "/" then a / b
    when "%" then a % b
    when "++" then "#{a}#{b}"
    when "==" then a == b
    when "!=" then a != b
    when "<" then a < b
    when ">" then a > b
    when "<=" then a <= b
    when ">=" then a >= b
    when "and", "&&" then truthy(a) && truthy(b)
    when "or", "||" then truthy(a) || truthy(b)
    end
  end

  def truthy(v) = !(v.nil? || v == false)

  def stringify(v)
    case v
    when nil then ""
    when true then "true"
    when false then "false"
    when Array, Hash then v.inspect
    else v.to_s
    end
  end

  def run_command(text, capture)
    script = text.gsub(/\$\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}/) { Shellwords.escape(stringify(@env.get(Regexp.last_match(1)))) }
                 .gsub(/\$([A-Za-z_][A-Za-z0-9_]*)/) { Shellwords.escape(stringify(@env.get(Regexp.last_match(1)))) }
    if capture
      out, err, st = Open3.capture3("bash", "-lc", script)
      h = {}
      h["stdout"] = out if st.success?
      h["stderr"] = err if st.success?
      h["status"] = st.exitstatus unless st.success?
      h
    else
      system("bash", "-lc", script)
    end
  end

  def stdlib
    {
      "len" => ->(x) { x.length },
      "push" => ->(a, v) { a << v; nil },
      "pop" => ->(a) { a.pop },
      "range" => ->(a, b, step = 1) { step > 0 ? (a...b).step(step).to_a : a.step(b + 1, step).to_a },
      "type" => ->(x) { x.nil? ? "nil" : x.class.name.downcase.sub("integer", "int").sub("hash", "object") },
      "import" => ->(path) {
        p = File.expand_path(path, File.dirname(@file))
        src = File.read(p)
        body = Parser.new(Lexer.new(src, p).tokens, src).parse
        Interpreter.new(p).run(body)
      }
    }
  end
end

def usage
  puts VERSION
  puts "gahag <gabriel.s.b@live.com>"
  puts "Hush is a unix shell scripting language based on the Lua programming language"
  puts
  puts "USAGE:"
  puts "    executable [FLAGS] [arguments]..."
  puts
  puts "FLAGS:"
  puts "        --ast        Print the AST"
  puts "        --check      Perform only static analysis instead of executing."
  puts "    -h, --help       Prints help information"
  puts "        --lex        Print the lexemes"
  puts "        --program    Print the PROGAM"
  puts "    -V, --version    Prints version information"
  puts
  puts "ARGS:"
  puts "    <arguments>...    Script and/or arguments"
end

args = ARGV.dup
if args.delete("--help") || args.delete("-h")
  usage; exit 0
end
if args.delete("--version") || args.delete("-V")
  puts VERSION; exit 0
end
lex_flag = args.delete("--lex")
ast_flag = args.delete("--ast")
check = args.delete("--check")
args.delete("--program")

file = args.shift
if file.nil?
  exit 0
end

begin
  src = File.read(file)
  tokens = Lexer.new(src, file).tokens
  if lex_flag
    puts "-" * 50
    tokens[0...-1].each { |t| puts "#{file} (line #{t.line}, column #{t.col}):\t#{t.text}" }
    puts "-" * 50
  end
  body = Parser.new(tokens, src).parse
  if ast_flag
    puts "-" * 50
    puts "AST for #{file}"
    puts src
    puts "-" * 50
  end
  exit 0 if check
  Interpreter.new(File.expand_path(file), args).run(body)
rescue HushError => e
  warn "Error: #{e.message}"
  exit 2
end
