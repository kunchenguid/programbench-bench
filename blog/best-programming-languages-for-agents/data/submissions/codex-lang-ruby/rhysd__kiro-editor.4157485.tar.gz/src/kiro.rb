#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = '0.4.3'

HELP_BODY = <<~TEXT
  %<prog>s: A tiny UTF-8 terminal text editor

  Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.
  Specify file paths to edit as a command argument or run without argument to
  start to write a new text.
  Help can show up with key mapping Ctrl-?.

  Usage:
      %<prog>s [options] [FILES...]

  Mappings:
      Ctrl-Q                        : Quit
      Ctrl-S                        : Save to file
      Ctrl-O                        : Open text buffer
      Ctrl-X                        : Next text buffer
      Alt-X                         : Previous text buffer
      Ctrl-P or UP                  : Move cursor up
      Ctrl-N or DOWN                : Move cursor down
      Ctrl-F or RIGHT               : Move cursor right
      Ctrl-B or LEFT                : Move cursor left
      Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line
      Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line
      Ctrl-[ or Ctrl-V or PAGE DOWN : Next page
      Ctrl-] or Alt-V or PAGE UP    : Previous page
      Alt-F or Ctrl-RIGHT           : Move cursor to next word
      Alt-B or Ctrl-LEFT            : Move cursor to previous word
      Alt-N or Ctrl-DOWN            : Move cursor to next paragraph
      Alt-P or Ctrl-UP              : Move cursor to previous paragraph
      Alt-<                         : Move cursor to top of file
      Alt->                         : Move cursor to bottom of file
      Ctrl-H or BACKSPACE           : Delete character
      Ctrl-D or DELETE              : Delete next character
      Ctrl-W                        : Delete a word
      Ctrl-J                        : Delete until head of line
      Ctrl-K                        : Delete until end of line
      Ctrl-U                        : Undo last change
      Ctrl-R                        : Redo last undo change
      Ctrl-G                        : Search text
      Ctrl-M                        : New line
      Ctrl-L                        : Refresh screen
      Ctrl-?                        : Show this help

  Options:
      -v, --version       Print version
      -h, --help          Print this help
TEXT

def program_name
  $PROGRAM_NAME
end

def print_help
  print format(HELP_BODY, prog: program_name)
  puts
end

def option_error(message)
  warn "Error: #{message}. Please see --help for more details"
  exit 1
end

def parse_args(argv)
  files = []
  i = 0
  while i < argv.length
    arg = argv[i]
    if arg.start_with?('--') && arg.length > 2
      name, value = arg[2..].split('=', 2)
      case name
      when 'help'
        option_error("Option 'help' does not take an argument") unless value.nil?
        print_help
        exit 0
      when 'version'
        option_error("Option 'version' does not take an argument") unless value.nil?
        puts VERSION
        exit 0
      else
        option_error("Unrecognized option: '#{name}'")
      end
    elsif arg.start_with?('-') && arg.length > 1
      arg[1..].each_char do |ch|
        case ch
        when 'h'
          print_help
          exit 0
        when 'v'
          puts VERSION
          exit 0
        else
          option_error("Unrecognized option: '#{ch}'")
        end
      end
    else
      files << arg
    end
    i += 1
  end
  files
end

class Buffer
  attr_accessor :lines, :cx, :cy, :rowoff, :coloff, :dirty, :message
  attr_reader :filename

  def initialize(path = nil)
    @filename = path
    @lines = ['']
    @cx = 0
    @cy = 0
    @rowoff = 0
    @coloff = 0
    @dirty = false
    @message = nil
    load_file(path) if path
  end

  def filename=(path)
    @filename = path
  end

  def load_file(path)
    content = File.exist?(path) ? File.binread(path).force_encoding('UTF-8') : ''
    content = content.encode('UTF-8', invalid: :replace, undef: :replace, replace: "\uFFFD")
    @lines = content.split(/\n/, -1)
    @lines.pop if @lines.length > 1 && @lines[-1].empty?
    @lines = [''] if @lines.empty?
    @dirty = false
  rescue StandardError => e
    @lines = ['']
    @message = "Error opening #{path}: #{e.message}"
  end

  def line
    @lines[@cy] ||= ''
  end

  def insert_text(text)
    text.each_char do |ch|
      ch == "\n" || ch == "\r" ? newline : insert_char(ch)
    end
  end

  def insert_char(ch)
    chars = line.chars
    chars.insert(@cx, ch)
    @lines[@cy] = chars.join
    @cx += 1
    @dirty = true
  end

  def newline
    chars = line.chars
    left = chars[0...@cx].join
    right = chars[@cx..]&.join || ''
    @lines[@cy] = left
    @lines.insert(@cy + 1, right)
    @cy += 1
    @cx = 0
    @dirty = true
  end

  def backspace
    return if @cy.zero? && @cx.zero?

    if @cx.positive?
      chars = line.chars
      chars.delete_at(@cx - 1)
      @lines[@cy] = chars.join
      @cx -= 1
    else
      prev_len = @lines[@cy - 1].chars.length
      @lines[@cy - 1] += @lines.delete_at(@cy)
      @cy -= 1
      @cx = prev_len
    end
    @dirty = true
  end

  def delete_forward
    if @cx < line.chars.length
      chars = line.chars
      chars.delete_at(@cx)
      @lines[@cy] = chars.join
    elsif @cy < @lines.length - 1
      @lines[@cy] += @lines.delete_at(@cy + 1)
    else
      return
    end
    @dirty = true
  end

  def delete_word
    return if @cy.zero? && @cx.zero?

    backspace while @cx.positive? && line.chars[@cx - 1] =~ /\s/
    backspace while @cx.positive? && line.chars[@cx - 1] !~ /\s/
  end

  def kill_to_eol
    chars = line.chars
    if @cx < chars.length
      @lines[@cy] = chars[0...@cx].join
    elsif @cy < @lines.length - 1
      @lines[@cy] += @lines.delete_at(@cy + 1)
    else
      return
    end
    @dirty = true
  end

  def kill_to_bol
    return if @cx.zero?

    chars = line.chars
    @lines[@cy] = chars[@cx..]&.join || ''
    @cx = 0
    @dirty = true
  end

  def move(dx, dy)
    if dy.negative?
      @cy = [@cy + dy, 0].max
    elsif dy.positive?
      @cy = [@cy + dy, @lines.length - 1].min
    end

    if dx.negative?
      if @cx.positive?
        @cx -= 1
      elsif @cy.positive?
        @cy -= 1
        @cx = line.chars.length
      end
    elsif dx.positive?
      if @cx < line.chars.length
        @cx += 1
      elsif @cy < @lines.length - 1
        @cy += 1
        @cx = 0
      end
    end
    @cx = [@cx, line.chars.length].min
  end

  def home
    @cx = 0
  end

  def end_line
    @cx = line.chars.length
  end

  def top
    @cy = 0
    @cx = 0
  end

  def bottom
    @cy = @lines.length - 1
    @cx = line.chars.length
  end

  def save
    return false unless @filename

    File.binwrite(@filename, @lines.join("\n"))
    @dirty = false
    @message = "#{@lines.join("\n").bytesize} bytes written"
    true
  rescue StandardError => e
    @message = "Can't save! #{e.message}"
    false
  end

  def display_name
    @filename || '[No Name]'
  end
end

class Editor
  CTRL = {
    'a' => "\x01", 'b' => "\x02", 'd' => "\x04", 'e' => "\x05",
    'f' => "\x06", 'g' => "\x07", 'h' => "\x08", 'j' => "\x0a",
    'k' => "\x0b", 'l' => "\x0c", 'm' => "\x0d", 'n' => "\x0e",
    'o' => "\x0f", 'p' => "\x10", 'q' => "\x11", 'r' => "\x12",
    's' => "\x13", 'u' => "\x15", 'v' => "\x16", 'w' => "\x17",
    'x' => "\x18", ']' => "\x1d", '?' => "\x7f"
  }.freeze

  def initialize(files)
    @buffers = files.empty? ? [Buffer.new] : files.map { |f| Buffer.new(f) }
    @current = 0
    @screenrows = 24
    @screencols = 80
    @quit_times = 3
    @running = true
  end

  def run
    unless STDIN.tty? && STDOUT.tty?
      warn 'Error: Inappropriate ioctl for device (os error 25)'
      exit 1
    end

    @stty_state = `stty -g`.strip
    system('stty raw -echo min 0 time 1')
    begin
      setup_screen
      refresh
      while @running
        key = read_key
        next unless key

        handle_key(key)
        refresh if @running
      end
    ensure
      system("stty #{@stty_state}") if @stty_state && !@stty_state.empty?
      shutdown_screen
    end
  rescue Interrupt
    system("stty #{@stty_state}") if @stty_state && !@stty_state.empty?
    shutdown_screen
  end

  def buffer
    @buffers[@current]
  end

  def terminal_size
    rows, cols = `stty size 2>/dev/null`.split.map(&:to_i)
    @screenrows = [rows.to_i, 3].max
    @screencols = [cols.to_i, 20].max
  rescue StandardError
    @screenrows = 24
    @screencols = 80
  end

  def setup_screen
    terminal_size
    print "\e[?1049h\e[?25l\e[39;0m"
  end

  def shutdown_screen
    print "\e[?1049l\e[H"
    STDOUT.flush
  rescue StandardError
    nil
  end

  def scroll
    b = buffer
    text_rows = @screenrows - 2
    b.rowoff = b.cy if b.cy < b.rowoff
    b.rowoff = b.cy - text_rows + 1 if b.cy >= b.rowoff + text_rows
    b.coloff = b.cx if b.cx < b.coloff
    b.coloff = b.cx - @screencols + 1 if b.cx >= b.coloff + @screencols
  end

  def refresh
    terminal_size
    scroll
    b = buffer
    print "\e[?25l\e[39;0m\e[H"
    draw_rows
    draw_status
    draw_message
    cx = b.cx - b.coloff + 1
    cy = b.cy - b.rowoff + 1
    print "\e[#{cy};#{cx}H\e[?25h"
    STDOUT.flush
  end

  def draw_rows
    b = buffer
    text_rows = @screenrows - 2
    text_rows.times do |y|
      filerow = y + b.rowoff
      print "\e[#{y + 1}H"
      if filerow >= b.lines.length
        if b.lines.length == 1 && b.lines[0].empty? && y == text_rows / 3
          welcome = "Kiro editor -- version #{VERSION}"
          padding = [(@screencols - welcome.length) / 2, 0].max
          print "\e[37m~" if padding.positive?
          print ' ' * [padding - 1, 0].max
          print "\e[39;0m#{welcome[0, @screencols]}"
        else
          print "\e[37m~"
        end
      else
        segment = b.lines[filerow].chars[b.coloff, @screencols]&.join || ''
        print segment
      end
      print "\e[K"
    end
  end

  def draw_status
    b = buffer
    name = b.display_name
    left = "\"#{name}\"#{b.dirty ? ' (modified)' : ''} - #{b.cy + 1}/#{b.lines.length}"
    right = "plain #{b.cx + 1}/#{b.line.chars.length + 1}"
    room = @screencols - left.length - right.length
    status = room.positive? ? left + (' ' * room) + right : left[0, @screencols]
    print "\e[#{@screenrows - 1}H\e[7m#{status.ljust(@screencols)[0, @screencols]}\e[39;0m"
  end

  def draw_message
    msg = buffer.message || 'Ctrl-? for help'
    print "\e[#{@screenrows}H#{msg[0, @screencols]}\e[K"
    buffer.message = nil unless msg == 'Ctrl-? for help'
  end

  def read_key
    ch = STDIN.read(1)
    return nil if ch.nil? || ch.empty?

    if ch == "\e"
      seq = ch
      begin
        seq << STDIN.read_nonblock(1)
        seq << STDIN.read_nonblock(1) if seq[-1] == '[' || seq[-1] == 'O' || seq[-1] =~ /\d/
        seq << STDIN.read_nonblock(1) if seq[-1] =~ /\d/
      rescue IO::WaitReadable, EOFError
      end
      seq
    else
      ch
    end
  end

  def handle_key(key)
    b = buffer
    case key
    when CTRL['q']
      if b.dirty && @quit_times.positive?
        b.message = "WARNING!!! File has unsaved changes. Press Ctrl-Q #{@quit_times} more times to quit."
        @quit_times -= 1
      else
        @running = false
      end
    when CTRL['s']
      if b.filename
        b.save
      else
        b.message = 'No file name'
      end
    when CTRL['x']
      @current = (@current + 1) % @buffers.length
    when "\eX", "\ex"
      @current = (@current - 1) % @buffers.length
    when CTRL['p'], "\e[A"
      b.move(0, -1)
    when CTRL['n'], "\e[B"
      b.move(0, 1)
    when CTRL['f'], "\e[C"
      b.move(1, 0)
    when CTRL['b'], "\e[D"
      b.move(-1, 0)
    when CTRL['a'], "\e[H", "\e[1~", "\eOH", "\e[1;3D"
      b.home
    when CTRL['e'], "\e[F", "\e[4~", "\eOF", "\e[1;3C"
      b.end_line
    when "\e<"
      b.top
    when "\e>"
      b.bottom
    when CTRL['h'], "\x7f"
      b.backspace
    when CTRL['d'], "\e[3~"
      b.delete_forward
    when CTRL['w']
      b.delete_word
    when CTRL['j']
      b.kill_to_bol
    when CTRL['k']
      b.kill_to_eol
    when CTRL['m'], "\n", "\r"
      b.newline
    when CTRL['l']
      nil
    when CTRL['?']
      b.message = 'Help is available with --help'
    when CTRL['u'], CTRL['r'], CTRL['g'], CTRL['o']
      b.message = 'Not implemented'
    else
      @quit_times = 3
      b.insert_text(key) if key && key.valid_encoding? && key.bytes.all? { |byte| byte >= 32 || byte >= 128 }
    end
  end
end

files = parse_args(ARGV)
Editor.new(files).run
