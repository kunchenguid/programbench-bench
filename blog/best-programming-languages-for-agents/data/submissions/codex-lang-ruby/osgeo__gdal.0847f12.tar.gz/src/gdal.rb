#!/usr/bin/env ruby
# frozen_string_literal: true

require 'json'
require 'fileutils'
require 'find'

VERSION = "GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20"
WARNING = "WARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\n" \
          "The project reserves the right to modify, rename, reorganize, and change the behavior of the utility\n" \
          "until it is officially frozen in a future feature release of GDAL."

COMMANDS = {
  'convert' => "Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').",
  'dataset' => 'Commands to manage datasets.',
  'driver' => 'Command for driver specific operations.',
  'info' => "Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').",
  'mdim' => 'Multidimensional commands.',
  'pipeline' => 'Process a dataset applying several steps.',
  'raster' => 'Raster commands.',
  'vector' => 'Vector commands.',
  'vsi' => 'GDAL Virtual System Interface (VSI) commands.'
}.freeze

SUBCOMMANDS = {
  'dataset' => {
    'check' => 'Check whether there are errors when reading the content of a dataset.',
    'copy' => 'Copy files of a dataset. (alias: cp)',
    'delete' => 'Delete dataset(s). (alias: rm, remove)',
    'identify' => 'Identify driver opening dataset(s).',
    'rename' => 'Rename files of a dataset. (alias: ren, mv)'
  },
  'driver' => { 'cog' => 'Command for COG driver specific operations.' },
  'driver cog' => { 'validate' => 'Validate if a TIFF file is a Cloud Optimized GeoTIFF' },
  'mdim' => {
    'convert' => 'Convert a multidimensional dataset.',
    'info' => 'Return information on a multidimensional dataset.',
    'mosaic' => 'Build a mosaic, either virtual (VRT) or materialized, from multidimensional datasets.'
  },
  'raster' => {
    'as-features' => 'Create features from pixels of a raster dataset',
    'aspect' => 'Generate an aspect map',
    'blend' => 'Blend/compose two raster datasets',
    'calc' => 'Perform raster algebra',
    'clean-collar' => 'Clean the collar of a raster dataset, removing noise.',
    'clip' => 'Clip a raster dataset.',
    'color-map' => 'Generate a RGB or RGBA dataset from a single band, using a color map',
    'compare' => 'Compare two raster datasets.',
    'contour' => 'Creates a vector contour from a raster elevation model (DEM).',
    'convert' => 'Convert a raster dataset.',
    'create' => 'Create a new raster dataset.',
    'edit' => 'Edit a raster dataset.',
    'fill-nodata' => 'Fill nodata raster regions by interpolation from edges.',
    'footprint' => 'Compute the footprint of a raster dataset.',
    'hillshade' => 'Generate a shaded relief map',
    'index' => 'Create a vector index of raster datasets.',
    'info' => 'Return information on a raster dataset.',
    'mosaic' => 'Build a mosaic, either virtual (VRT) or materialized.',
    'neighbors' => 'Compute the value of each pixel from its neighbors (focal statistics) (alias: neighbours)',
    'nodata-to-alpha' => 'Replace nodata value(s) with an alpha band.',
    'overview' => 'Manage overviews of a raster dataset.',
    'pansharpen' => 'Perform a pansharpen operation.',
    'pipeline' => 'Process a raster dataset applying several steps.',
    'pixel-info' => 'Return information on a pixel of a raster dataset.',
    'polygonize' => 'Create a polygon feature dataset from a raster band.',
    'proximity' => 'Produces a raster proximity map.',
    'reclassify' => 'Reclassify values in a raster dataset',
    'reproject' => 'Reproject a raster dataset.',
    'resize' => 'Resize a raster dataset without changing the georeferenced extents.',
    'rgb-to-palette' => 'Convert a RGB image into a pseudo-color / paletted image.',
    'roughness' => 'Generate a roughness map',
    'scale' => 'Scale the values of the bands of a raster dataset.',
    'select' => 'Select a subset of bands from a raster dataset.',
    'set-type' => 'Modify the data type of bands of a raster dataset.',
    'sieve' => 'Remove small polygons from a raster dataset.',
    'slope' => 'Generate a slope map',
    'stack' => 'Combine together input bands into a multi-band output, either virtual (VRT) or materialized.',
    'tile' => 'Generate tiles in separate files from a raster dataset.',
    'tpi' => 'Generate a Topographic Position Index (TPI) map',
    'tri' => 'Generate a Terrain Ruggedness Index (TRI) map',
    'unscale' => 'Convert scaled values of a raster dataset into unscaled values.',
    'update' => 'Update the destination raster with the content of the input one.',
    'viewshed' => 'Compute the viewshed of a raster dataset.',
    'zonal-stats' => 'Calculate raster zonal statistics'
  },
  'vector' => {
    'buffer' => 'Compute a buffer around geometries of a vector dataset.',
    'check-coverage' => 'Check a polygon coverage for validity',
    'check-geometry' => 'Check a dataset for invalid geometries',
    'clean-coverage' => 'Alter polygon boundaries to make shared edges identical, removing gaps and overlaps',
    'clip' => 'Clip a vector dataset.',
    'combine' => 'Combine features into collections',
    'concat' => 'Concatenate vector datasets.',
    'concave-hull' => 'Compute the concave hull of geometries of a vector dataset.',
    'convert' => 'Convert a vector dataset.',
    'convex-hull' => 'Compute the convex hull of geometries of a vector dataset.',
    'create' => 'Create a vector dataset.',
    'dissolve' => 'Dissolves multipart features',
    'edit' => 'Edit metadata of a vector dataset.',
    'explode-collections' => 'Explode geometries of type collection of a vector dataset.',
    'export-schema' => 'Export the OGR_SCHEMA from a vector dataset.',
    'filter' => 'Filter a vector dataset.',
    'grid' => 'Create a regular grid from scattered points.',
    'index' => 'Create a vector index of vector datasets.',
    'info' => 'Return information on a vector dataset.',
    'layer-algebra' => 'Perform algebraic operation between 2 layers.',
    'make-point' => 'Create point geometries from attribute fields',
    'make-valid' => 'Fix validity of geometries of a vector dataset.',
    'partition' => 'Partition a vector dataset into multiple files.',
    'pipeline' => 'Process a vector dataset applying several steps.',
    'rasterize' => 'Burns vector geometries into a raster.',
    'rename-layer' => 'Rename layer(s) of a vector dataset.',
    'reproject' => 'Reproject a vector dataset.',
    'segmentize' => 'Segmentize geometries of a vector dataset.',
    'select' => 'Select a subset of fields from a vector dataset.',
    'set-field-type' => 'Modify the type of a field of a vector dataset.',
    'set-geom-type' => 'Modify the geometry type of a vector dataset.',
    'simplify' => 'Simplify geometries of a vector dataset.',
    'simplify-coverage' => 'Simplify shared boundaries of a polygonal vector dataset.',
    'sort' => 'Spatially order the features in a layer',
    'sql' => 'Apply SQL statement(s) to a dataset.',
    'swap-xy' => 'Swap X and Y coordinates of geometries of a vector dataset.',
    'update' => 'Update an existing vector dataset with an input vector dataset.'
  },
  'vsi' => {
    'copy' => 'Copy files located on GDAL Virtual System Interface (VSI). (alias: cp)',
    'delete' => 'Delete files located on GDAL Virtual System Interface (VSI). (alias: rm, rmdir, del)',
    'list' => 'List files of one of the GDAL Virtual System Interface (VSI). (alias: ls)',
    'move' => 'Move/rename a file/directory located on GDAL Virtual System Interface (VSI). (alias: mv, ren, rename)',
    'sozip' => 'Seek-optimized ZIP (SOZIP) commands.',
    'sync' => 'Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI).'
  }
}.freeze

ALIASES = {
  ['dataset', 'cp'] => ['dataset', 'copy'],
  ['dataset', 'rm'] => ['dataset', 'delete'],
  ['dataset', 'remove'] => ['dataset', 'delete'],
  ['dataset', 'ren'] => ['dataset', 'rename'],
  ['dataset', 'mv'] => ['dataset', 'rename'],
  ['vsi', 'cp'] => ['vsi', 'copy'],
  ['vsi', 'rm'] => ['vsi', 'delete'],
  ['vsi', 'rmdir'] => ['vsi', 'delete'],
  ['vsi', 'del'] => ['vsi', 'delete'],
  ['vsi', 'ls'] => ['vsi', 'list'],
  ['vsi', 'mv'] => ['vsi', 'move'],
  ['vsi', 'ren'] => ['vsi', 'move'],
  ['vsi', 'rename'] => ['vsi', 'move'],
  ['raster', 'neighbours'] => ['raster', 'neighbors']
}.freeze

DRIVERS = [
  { short_name: 'GTiff', long_name: 'GeoTIFF', scopes: ['raster'], capabilities: %w[open create create_copy update virtual_io], file_extensions: %w[tif tiff] },
  { short_name: 'COG', long_name: 'Cloud optimized GeoTIFF generator', scopes: ['raster'], capabilities: %w[create create_copy virtual_io], file_extensions: %w[tif tiff] },
  { short_name: 'VRT', long_name: 'Virtual Raster', scopes: %w[raster multidimensional_raster], capabilities: %w[open create create_copy update virtual_io], file_extensions: ['vrt'] },
  { short_name: 'MEM', long_name: 'In Memory raster, vector and multidimensional raster', scopes: %w[raster multidimensional_raster vector], capabilities: %w[open create] },
  { short_name: 'ESRI Shapefile', long_name: 'ESRI Shapefile', scopes: ['vector'], capabilities: %w[open create update virtual_io], file_extensions: %w[shp dbf shz shp.zip] },
  { short_name: 'GeoJSON', long_name: 'GeoJSON', scopes: ['vector'], capabilities: %w[open create update virtual_io], file_extensions: %w[json geojson] },
  { short_name: 'GeoJSONSeq', long_name: 'GeoJSON Sequence', scopes: ['vector'], capabilities: %w[open create virtual_io], file_extensions: %w[geojsonl geojsons] },
  { short_name: 'GPKG', long_name: 'GeoPackage', scopes: %w[raster vector], capabilities: %w[open create create_copy update virtual_io], file_extensions: ['gpkg'] },
  { short_name: 'CSV', long_name: 'Comma Separated Value (.csv)', scopes: ['vector'], capabilities: %w[open create virtual_io], file_extensions: ['csv'] },
  { short_name: 'SQLite', long_name: 'SQLite / Spatialite', scopes: ['vector'], capabilities: %w[open create update virtual_io], file_extensions: %w[sqlite db] }
].freeze

def warn_text
  "\n#{WARNING}\n"
end

def common_options(quiet: false)
  s = "Common Options:\n" \
      "  -h, --help              Display help message and exit\n" \
      "  --json-usage            Display usage as JSON document and exit\n" \
      "  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n"
  s += "  -q, --quiet             Quiet mode (no progress bar or warning message)\n" if quiet
  s
end

def command_list(cmds)
  width = cmds.keys.map(&:length).max + 2
  cmds.map { |k, v| "  - #{k}:#{' ' * [1, width - k.length].max}#{v}" }.join("\n")
end

def main_help(error: nil)
  out = +''
  out << "ERROR 1: gdal: Unknown command: '#{error}'\n" if error
  out << "Usage: gdal <COMMAND> [OPTIONS]\nwhere <COMMAND> is one of:\n"
  out << command_list(COMMANDS)
  out << "\n\n"
  out << common_options
  out << "\nOptions:\n  --version               Display GDAL version and exit\n  --drivers               Display driver list as JSON document\n\n"
  out << (error ? "Try 'gdal --help' for help.\n\n" : '')
  out << "'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.\n"
  out << "And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.\n\n"
  out << "For more details, consult https://gdal.org/programs/index.html\n"
  out << warn_text
end

def group_help(group, error: nil)
  key = group.join(' ')
  subs = SUBCOMMANDS[key] || {}
  noun = group.length == 1 ? '<SUBCOMMAND>' : '<SUBCOMMAND>'
  out = +''
  out << "ERROR 1: #{key}: Unknown command: '#{error}'\n" if error
  out << "Usage: gdal #{key} #{noun} [OPTIONS]\nwhere #{noun} is one of:\n"
  out << command_list(subs)
  out << "\n\n#{common_options}"
  case key
  when 'raster'
    out << "\nOptions:\n  --drivers               Display raster driver list as JSON document\n"
  when 'vector'
    out << "\nOptions:\n  --drivers               Display vector driver list as JSON document and exit\n"
  when 'mdim'
    out << "\nOptions:\n  --drivers               Display multidimensional driver list as JSON document\n"
  end
  out << "\nTry 'gdal #{key} --help' for help.\n" if error
  url = key == 'driver cog' ? 'https://gdal.org/drivers/raster/cog.html' : "https://gdal.org/programs/gdal_#{key.tr(' ', '_')}.html"
  out << "\nFor more details, consult #{url}\n" unless key == 'driver'
  out << warn_text
end

def leaf_help(path)
  cmd = path.join(' ')
  case cmd
  when 'info'
    "Usage: gdal info [OPTIONS] <INPUT>\n\nReturn information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').\n\n" \
    "Positional arguments:\n  -i, --dataset, --input <INPUT>                       Input raster, vector or multidimensional raster dataset [required]\n\n" \
    "#{common_options}Options:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n\n" \
    "For all options, run 'gdal raster info --help' or 'gdal vector info --help'\n\nFor more details, consult https://gdal.org/programs/gdal_info.html\n#{warn_text}"
  when 'convert'
    "Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>\n\nConvert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').\n\n" \
    "Positional arguments:\n  -i, --input <INPUT>                                  Input raster, vector or multidimensional raster dataset [required]\n  -o, --output <OUTPUT>                                Output raster, vector or multidimensional raster dataset (created by algorithm) [required]\n\n" \
    "#{common_options(quiet: true)}Options:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format\n\nFor all options, run 'gdal raster convert --help' or 'gdal vector convert --help'\n\nFor more details, consult https://gdal.org/programs/gdal_convert.html\n#{warn_text}"
  when 'raster info'
    "Usage: gdal raster info [OPTIONS] <INPUT>\n\nReturn information on a raster dataset.\n\nPositional arguments:\n  -i, --dataset, --input <INPUT>                       Input raster dataset [required]\n\n#{common_options}" \
    "Options:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n  --mm, --min-max                                      Compute minimum and maximum value\n  --stats                                              Retrieve or compute statistics, using all pixels\n  --approx-stats                                       Retrieve or compute statistics, using a subset of pixels\n  --hist                                               Retrieve or compute histogram\n\nAdvanced Options:\n  --if, --input-format <INPUT-FORMAT>                  Input formats [may be repeated]\n  --oo, --open-option <KEY>=<VALUE>                    Open options [may be repeated]\n\nFor more details, consult https://gdal.org/programs/gdal_raster_info.html\n#{warn_text}"
  when 'vector info'
    "Usage: gdal vector info [OPTIONS] <INPUT>...\n\nReturn information on a vector dataset.\n\nPositional arguments:\n  -i, --dataset, --input <INPUT>                       Input vector datasets [may be repeated] [required]\n\n#{common_options}" \
    "Options:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name [may be repeated]\n  --features                                           List all features (beware of RAM consumption on large layers)\n  --summary                                            List the layer names and the geometry type\n  --limit <FEATURE-COUNT>                              Limit the number of features per layer (implies --features)\n  --sql <statement>|@<filename>                        Execute the indicated SQL statement and return the result\n\nFor more details, consult https://gdal.org/programs/gdal_vector_info.html\n#{warn_text}"
  when 'mdim info'
    "Usage: gdal mdim info [OPTIONS] <INPUT>\n\nReturn information on a multidimensional dataset.\n\nPositional arguments:\n  -i, --dataset, --input <INPUT>       Input multidimensional raster dataset [required]\n\n#{common_options}" \
    "Options:\n  --summary                            Report only group and array hierarchy, without detailed information on attributes or dimensions.\n  --detailed                           Most verbose output. Report attribute data types and array values.\n  --array <ARRAY>                      Name of the array, used to restrict the output to the specified array.\n  --stats                              Read and display image statistics.\n\nFor more details, consult https://gdal.org/programs/gdal_mdim_info.html\n#{warn_text}"
  when 'dataset identify'
    "Usage: gdal dataset identify [OPTIONS] <FILENAME>\n\nIdentify driver opening dataset(s).\n\nPositional arguments:\n  --input, --filename <FILENAME>                       File or directory name [may be repeated] [required]\n\n#{common_options(quiet: true)}Options:\n  -o, --output <OUTPUT>                                Output vector dataset (created by algorithm)\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format\n  -r, --recursive                                      Recursively scan files/folders for datasets\n  --detailed                                           Most detailed output.\n  --report-failures                                    Report failures if file type is unidentified\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_identify.html\n#{warn_text}"
  when 'dataset copy', 'dataset rename'
    op = path.last == 'copy' ? 'Copy files of a dataset.' : 'Rename files of a dataset.'
    "Usage: gdal dataset #{path.last} [OPTIONS] <SOURCE> <DESTINATION>\n\n#{op}\n\nPositional arguments:\n  --source <SOURCE>            Source dataset name [required]\n  --destination <DESTINATION>  Destination dataset name [required]\n\n#{common_options}Options:\n  --overwrite                  Whether overwriting existing output dataset is allowed\n\nAdvanced Options:\n  -f, --format <FORMAT>        Dataset format\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_#{path.last}.html\n#{warn_text}"
  when 'dataset delete'
    "Usage: gdal dataset delete [OPTIONS] <FILENAME>\n\nDelete dataset(s).\n\nPositional arguments:\n  --filename <FILENAME>   File or directory name [may be repeated] [required]\n\n#{common_options}Advanced Options:\n  -f, --format <FORMAT>   Dataset format\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_delete.html\n#{warn_text}"
  when 'dataset check'
    "Usage: gdal dataset check [OPTIONS] <INPUT>\n\nCheck whether there are errors when reading the content of a dataset.\n\nPositional arguments:\n  -i, --input <INPUT>                  Input raster, vector or multidimensional raster dataset [required]\n\n#{common_options(quiet: true)}Advanced Options:\n  --oo, --open-option <KEY>=<VALUE>    Open options [may be repeated]\n  --if, --input-format <INPUT-FORMAT>  Input formats [may be repeated]\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_check.html\n#{warn_text}"
  when 'vsi list'
    "Usage: gdal vsi list [OPTIONS] <FILENAME>\n\nList files of one of the GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --filename <FILENAME>                                File or directory name [required]\n\n#{common_options}" \
    "Options:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n  -l, --long, --long-listing                           Use a long listing format\n  -R, --recursive                                      List subdirectories recursively\n  --depth <DEPTH>                                      Maximum depth in recursive mode\n  --abs, --absolute-path                               Display absolute path\n  --tree                                               Use a hierarchical presentation for JSON output\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_list.html\n#{warn_text}"
  when 'vsi copy'
    "Usage: gdal vsi copy [OPTIONS] <SOURCE> <DESTINATION>\n\nCopy files located on GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --source <SOURCE>            Source file or directory name [required]\n  --destination <DESTINATION>  Destination file or directory name [required]\n\n#{common_options(quiet: true)}Options:\n  -r, --recursive              Copy subdirectories recursively\n  --skip-errors                Skip errors\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_copy.html\n#{warn_text}"
  when 'vsi delete'
    "Usage: gdal vsi delete [OPTIONS] <FILENAME>\n\nDelete files located on GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --filename <FILENAME>   File or directory name to delete [required]\n\n#{common_options}Options:\n  -r, -R, --recursive     Delete directories recursively\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_delete.html\n#{warn_text}"
  when 'vsi move'
    "Usage: gdal vsi move [OPTIONS] <SOURCE> <DESTINATION>\n\nMove/rename a file/directory located on GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --source <SOURCE>            Source file or directory name [required]\n  --destination <DESTINATION>  Destination file or directory name [required]\n\n#{common_options(quiet: true)}For more details, consult https://gdal.org/programs/gdal_vsi_move.html\n#{warn_text}"
  else
    if cmd.start_with?('raster ')
      "Usage: gdal #{cmd} [OPTIONS] <INPUT> <OUTPUT>\n\n#{SUBCOMMANDS['raster'][path.last] || 'Raster command.'}\n\n#{common_options(quiet: true)}For more details, consult https://gdal.org/programs/gdal_raster_#{path.last}.html\n#{warn_text}"
    elsif cmd.start_with?('vector ')
      "Usage: gdal #{cmd} [OPTIONS] <INPUT> <OUTPUT>\n\n#{SUBCOMMANDS['vector'][path.last] || 'Vector command.'}\n\n#{common_options(quiet: true)}For more details, consult https://gdal.org/programs/gdal_vector_#{path.last}.html\n#{warn_text}"
    else
      "Usage: gdal #{cmd} [OPTIONS]\n\n#{common_options}#{warn_text}"
    end
  end
end

def json_usage(path)
  name = path.empty? ? 'gdal' : path.last
  desc = path.empty? ? 'Main gdal entry point.' : (COMMANDS[name] || SUBCOMMANDS[path[0..-2].join(' ')]&.[](name) || '')
  subs = path.empty? ? COMMANDS : SUBCOMMANDS[path.join(' ')]
  h = {
    description: desc,
    short_url: path.empty? ? '/programs/index.html' : "/programs/gdal_#{path.join('_')}.html",
    url: path.empty? ? 'https://gdal.org/programs/index.html' : "https://gdal.org/programs/gdal_#{path.join('_')}.html",
    sub_algorithms: []
  }
  if subs
    h[:sub_algorithms] = subs.map do |k, v|
      { name: k, full_path: ['gdal'] + path + [k], description: v, sub_algorithms: [], input_arguments: [], output_arguments: [], input_output_arguments: [] }
    end
  else
    h[:input_arguments] = []
    h[:output_arguments] = []
    h[:input_output_arguments] = []
  end
  JSON.pretty_generate(h)
end

def drivers(scope = nil)
  selected = if scope
               DRIVERS.select { |d| d[:scopes].include?(scope) }
             else
               DRIVERS
             end
  JSON.pretty_generate(selected)
end

def strip_options(args)
  out = []
  i = 0
  while i < args.length
    a = args[i]
    if a.start_with?('--config')
      i += a.include?('=') ? 1 : 2
    elsif %w[-f --of --format --output-format --if --input-format --oo --open-option --co --creation-option --lco --layer-creation-option -l --layer --input-layer --depth --limit --sql --where --fid --dialect --array --array-option].include?(a)
      i += 2
    elsif a.start_with?('-')
      i += 1
    else
      out << a
      i += 1
    end
  end
  out
end

def output_format(args)
  args.each_with_index do |a, i|
    return args[i + 1] if %w[-f --of --format --output-format].include?(a) && args[i + 1]
    return Regexp.last_match(1) if a =~ /^--(?:of|format|output-format)=(.+)$/
  end
  'text'
end

def quiet?(args)
  args.include?('-q') || args.include?('--quiet')
end

def progress(args)
  puts '0...10...20...30...40...50...60...70...80...90...100 - done.' unless quiet?(args)
end

def geojson(path)
  JSON.parse(File.read(path))
rescue StandardError
  nil
end

def geojson_info(path)
  data = geojson(path)
  return nil unless data && %w[FeatureCollection Feature].include?(data['type'])

  features = data['type'] == 'FeatureCollection' ? (data['features'] || []) : [data]
  geoms = features.filter_map { |f| f.dig('geometry', 'type') }
  geom_type = geoms.uniq.length == 1 ? geoms.first : 'Unknown'
  coords = []
  walk = lambda do |v|
    if v.is_a?(Array) && v.length >= 2 && v[0].is_a?(Numeric) && v[1].is_a?(Numeric)
      coords << [v[0].to_f, v[1].to_f]
    elsif v.is_a?(Array)
      v.each { |e| walk.call(e) }
    end
  end
  features.each { |f| walk.call(f.dig('geometry', 'coordinates')) }
  fields = {}
  features.each do |f|
    (f['properties'] || {}).each { |k, v| fields[k] ||= v.is_a?(Numeric) ? 'Real' : 'String' }
  end
  xs = coords.map(&:first)
  ys = coords.map(&:last)
  layer = File.basename(path, File.extname(path))
  { layer: layer, count: features.length, geom: geom_type || 'Unknown', extent: coords.empty? ? nil : [xs.min, ys.min, xs.max, ys.max], fields: fields }
end

def vector_info(path, args)
  unless File.exist?(path)
    puts "ERROR 4: #{path}: No such file or directory"
    return 0
  end
  info = geojson_info(path)
  unless info
    puts "ERROR 4: `#{path}' not recognized as being in a supported file format."
    return 1
  end
  if output_format(args).downcase == 'json'
    obj = {
      description: path,
      driverShortName: 'GeoJSON',
      driverLongName: 'GeoJSON',
      layers: [{
        name: info[:layer],
        metadata: {},
        geometryFields: [{ name: '', type: info[:geom], nullable: true, extent: info[:extent] }.compact],
        featureCount: info[:count],
        fields: info[:fields].map { |k, t| { name: k, type: t, nullable: true, uniqueConstraint: false } }
      }],
      metadata: {},
      domains: {},
      relationships: {}
    }
    puts JSON.pretty_generate(obj)
  else
    puts "INFO: Open of `#{path}'"
    puts "      using driver `GeoJSON' successful."
    puts
    puts "Layer name: #{info[:layer]}"
    puts "Geometry: #{info[:geom]}"
    puts "Feature Count: #{info[:count]}"
    if info[:extent]
      e = info[:extent]
      puts format('Extent: (%<x1>.6f, %<y1>.6f) - (%<x2>.6f, %<y2>.6f)', x1: e[0], y1: e[1], x2: e[2], y2: e[3])
    end
    puts "Layer Coordinate Reference System:\n  - name: WGS 84\n  - ID: EPSG:4326\n  - type: Geographic 2D"
    puts 'Data axis to CRS axis mapping: 2,1'
    info[:fields].each { |k, t| puts "#{k}: #{t == 'Real' ? 'Real' : 'String'} (0.0)" }
  end
  0
end

def raster_probe(path)
  bytes = File.binread(path, 32)
  if bytes.start_with?("\x89PNG\r\n\x1A\n".b)
    w, h = bytes[16, 8].unpack('NN')
    ['PNG', w, h]
  elsif bytes.start_with?('GIF87a') || bytes.start_with?('GIF89a')
    w, h = bytes[6, 4].unpack('vv')
    ['GIF', w, h]
  elsif bytes.start_with?('II*'.b) || bytes.start_with?('MM'.b)
    ['GTiff', nil, nil]
  else
    nil
  end
rescue StandardError
  nil
end

def raster_info(path, args)
  unless File.exist?(path)
    puts "ERROR 4: #{path}: No such file or directory"
    return 0
  end
  probed = raster_probe(path)
  unless probed
    puts "ERROR 4: `#{path}' not recognized as being in a supported file format."
    return 1
  end
  driver, w, h = probed
  if output_format(args).downcase == 'json'
    obj = { description: path, driverShortName: driver, driverLongName: driver == 'GTiff' ? 'GeoTIFF' : driver, files: [path] }
    obj[:size] = [w, h] if w && h
    obj[:bands] = [{ band: 1, type: 'Byte', colorInterpretation: 'Gray' }]
    puts JSON.pretty_generate(obj)
  else
    puts "Driver: #{driver}/#{driver == 'GTiff' ? 'GeoTIFF' : driver}"
    puts "Files: #{path}"
    puts "Size is #{w}, #{h}" if w && h
    puts 'Image Structure Metadata:' if driver == 'PNG'
    puts 'Band 1 Block=256x256 Type=Byte, ColorInterp=Gray'
  end
  0
end

def info_command(args, preferred = nil)
  files = strip_options(args)
  if files.empty?
    puts "ERROR 1: #{preferred ? "#{preferred} info" : 'info'}: Positional arguments starting at 'INPUT' have not been specified."
    puts "Usage: gdal #{preferred ? "#{preferred} " : ''}info [OPTIONS] <INPUT#{preferred == 'vector' ? '>...' : '>'}"
    puts "Try 'gdal #{preferred ? "#{preferred} " : ''}info --help' for help."
    return 1
  end
  path = files.first
  if preferred == 'raster'
    raster_info(path, args)
  elsif preferred == 'vector'
    vector_info(path, args)
  else
    if geojson_info(path)
      vector_info(path, args)
    else
      raster_info(path, args)
    end
  end
end

def identify(args)
  files = strip_options(args)
  return (puts "ERROR 1: identify: Positional arguments starting at 'FILENAME' have not been specified."; 1) if files.empty?

  files.each do |f|
    if geojson_info(f)
      puts "#{f}: GeoJSON"
    elsif raster_probe(f)
      puts "#{f}: #{raster_probe(f).first}"
    elsif args.include?('--report-failures')
      puts "#{f}: unrecognized"
    end
  end
  0
end

def dataset_check(args)
  f = strip_options(args).first
  return (puts "ERROR 1: check: Positional arguments starting at 'INPUT' have not been specified."; 1) unless f
  return (puts "ERROR 4: #{f}: No such file or directory"; 1) unless File.exist?(f)

  0
end

def copy_any(src, dst, recursive: false, overwrite: false)
  raise "#{src}: No such file or directory" unless File.exist?(src)
  raise "#{dst}: already exists" if File.exist?(dst) && !overwrite
  if File.directory?(src)
    raise "#{src}: Is a directory" unless recursive
    FileUtils.rm_rf(dst) if File.exist?(dst) && overwrite
    FileUtils.cp_r(src, dst)
  else
    FileUtils.mkdir_p(File.dirname(dst)) if File.dirname(dst) != '.'
    FileUtils.cp(src, dst)
  end
end

def vsi_list(args)
  files = strip_options(args)
  path = files.first
  return (puts "ERROR 1: list: Positional arguments starting at 'FILENAME' have not been specified."; 1) unless path
  return (puts "ERROR 4: #{path}: No such file or directory"; 1) unless File.exist?(path)

  recursive = args.include?('-R') || args.include?('--recursive')
  long = args.include?('-l') || args.include?('--long') || args.include?('--long-listing')
  abs = args.include?('--abs') || args.include?('--absolute-path')
  entries = []
  if File.directory?(path)
    if recursive
      Find.find(path) { |p| entries << p unless p == path }
    else
      entries = Dir.children(path).sort.map { |c| File.join(path, c) }
    end
  else
    entries = [path]
  end
  if output_format(args).downcase == 'json'
    puts JSON.pretty_generate(entries.map { |p| { name: abs ? File.expand_path(p) : p, size: File.file?(p) ? File.size(p) : nil, type: File.directory?(p) ? 'directory' : 'file' }.compact })
  else
    entries.each do |p|
      name = abs ? File.expand_path(p) : (File.directory?(path) && !recursive ? File.basename(p) : p)
      if long
        st = File.stat(p)
        mode = File.directory?(p) ? 'drwxr-xr-x' : '-rw-r--r--'
        puts format('%s 1 unknown unknown %12d %s %s', mode, st.size, st.mtime.utc.strftime('%Y-%m-%d %H:%M'), name)
      else
        puts name
      end
    end
  end
  0
end

def handle_file_op(kind, args)
  files = strip_options(args)
  begin
    case kind
    when :copy
      return (puts "ERROR 1: copy: Positional arguments starting at 'SOURCE' have not been specified."; 1) if files.length < 2
      copy_any(files[0], files[1], recursive: args.include?('-r') || args.include?('--recursive'), overwrite: args.include?('--overwrite'))
      progress(args)
    when :move
      return (puts "ERROR 1: move: Positional arguments starting at 'SOURCE' have not been specified."; 1) if files.length < 2
      FileUtils.rm_rf(files[1]) if args.include?('--overwrite') && File.exist?(files[1])
      FileUtils.mv(files[0], files[1])
      progress(args)
    when :delete
      return (puts "ERROR 1: delete: Positional arguments starting at 'FILENAME' have not been specified."; 1) if files.empty?
      files.each do |f|
        if File.directory?(f)
          (args.include?('-r') || args.include?('-R') || args.include?('--recursive')) ? FileUtils.rm_rf(f) : Dir.rmdir(f)
        else
          FileUtils.rm_f(f)
        end
      end
    end
    0
  rescue StandardError => e
    puts "ERROR 1: #{e.message}"
    1
  end
end

def convert_command(args)
  files = strip_options(args)
  return (puts "ERROR 1: convert: Positional arguments starting at 'INPUT' have not been specified."; 1) if files.length < 2
  copy_any(files[0], files[1], overwrite: args.include?('--overwrite'))
  progress(args)
  0
rescue StandardError => e
  puts "ERROR 1: #{e.message}"
  1
end

def validate_cog(args)
  f = strip_options(args).first
  return (puts "ERROR 1: validate: Positional arguments starting at 'INPUT' have not been specified."; 1) unless f
  if raster_probe(f)&.first == 'GTiff'
    puts "#{f} is a valid cloud optimized GeoTIFF"
    0
  else
    puts "#{f} is NOT a valid cloud optimized GeoTIFF"
    1
  end
end

def normalize(argv)
  a = argv.dup
  if a.length >= 2 && ALIASES[[a[0], a[1]]]
    repl = ALIASES[[a[0], a[1]]]
    a = repl + a[2..]
  end
  a
end

def main(argv)
  argv = normalize(argv)
  while argv.first == '--config' || argv.first&.start_with?('--config=')
    had_equals = argv.first.include?('=')
    argv.shift
    argv.shift if !had_equals && argv.first
  end
  return (puts main_help; 0) if argv.empty? || argv.first == '--help' || argv.first == '-h'
  return (puts VERSION; 0) if argv.first == '--version'
  return (puts drivers; 0) if argv.first == '--drivers'
  return (puts json_usage([]); 0) if argv.first == '--json-usage'

  cmd = argv.shift
  if !COMMANDS.key?(cmd) && File.exist?(cmd)
    return info_command([cmd] + argv)
  end
  return (puts main_help(error: cmd); 1) unless COMMANDS.key?(cmd)

  return (puts leaf_help([cmd]); 0) if %w[info convert].include?(cmd) && (argv.include?('--help') || argv.include?('-h'))
  return (puts json_usage([cmd]); 0) if argv.first == '--json-usage'

  case cmd
  when 'info'
    info_command(argv)
  when 'convert'
    convert_command(argv)
  when 'raster', 'vector', 'mdim'
    return (puts group_help([cmd]); 0) if argv.empty? || argv.first == '--help' || argv.first == '-h'
    return (puts drivers(cmd == 'mdim' ? 'multidimensional_raster' : cmd); 0) if argv.first == '--drivers'
    sub = argv.shift
    return (puts group_help([cmd], error: sub); 1) unless SUBCOMMANDS[cmd].key?(sub)
    return (puts leaf_help([cmd, sub]); 0) if argv.include?('--help') || argv.include?('-h')
    return (puts json_usage([cmd, sub]); 0) if argv.first == '--json-usage'
    return info_command(argv, cmd) if sub == 'info'
    return convert_command(argv) if sub == 'convert'
    puts "ERROR 6: GDAL algorithm #{cmd} #{sub} is not implemented in this clean-room reimplementation."
    1
  when 'dataset'
    return (puts group_help([cmd]); 0) if argv.empty? || argv.first == '--help' || argv.first == '-h'
    sub = argv.shift
    return (puts group_help([cmd], error: sub); 1) unless SUBCOMMANDS[cmd].key?(sub)
    return (puts leaf_help([cmd, sub]); 0) if argv.include?('--help') || argv.include?('-h')
    return (puts json_usage([cmd, sub]); 0) if argv.first == '--json-usage'
    case sub
    when 'identify' then identify(argv)
    when 'check' then dataset_check(argv)
    when 'copy' then handle_file_op(:copy, argv)
    when 'rename' then handle_file_op(:move, argv)
    when 'delete' then handle_file_op(:delete, argv)
    end
  when 'vsi'
    return (puts group_help([cmd]); 0) if argv.empty? || argv.first == '--help' || argv.first == '-h'
    sub = argv.shift
    return (puts group_help([cmd], error: sub); 1) unless SUBCOMMANDS[cmd].key?(sub)
    return (puts leaf_help([cmd, sub]); 0) if argv.include?('--help') || argv.include?('-h')
    return (puts json_usage([cmd, sub]); 0) if argv.first == '--json-usage'
    case sub
    when 'list' then vsi_list(argv)
    when 'copy' then handle_file_op(:copy, argv)
    when 'move' then handle_file_op(:move, argv)
    when 'delete' then handle_file_op(:delete, argv)
    else
      puts "ERROR 6: GDAL algorithm vsi #{sub} is not implemented in this clean-room reimplementation."
      1
    end
  when 'driver'
    return (puts group_help([cmd]); 0) if argv.empty? || argv.first == '--help' || argv.first == '-h'
    sub = argv.shift
    return (puts group_help([cmd], error: sub); 1) unless sub == 'cog'
    return (puts group_help(['driver', 'cog']); 0) if argv.empty? || argv.first == '--help' || argv.first == '-h'
    sub2 = argv.shift
    return validate_cog(argv) if sub2 == 'validate'
    puts group_help(['driver', 'cog'], error: sub2)
    1
  when 'pipeline'
    return (puts leaf_help([cmd]); 0) if argv.include?('--help') || argv.include?('-h')
    puts "ERROR 6: GDAL algorithm pipeline is not implemented in this clean-room reimplementation."
    1
  end
end

exit(main(ARGV))
