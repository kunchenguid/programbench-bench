#!/usr/bin/env ruby
# A compact QuickJS command-compatible runner for ProgramBench.

JS_UNDEFINED = Object.new
def JS_UNDEFINED.to_s = "undefined"
def JS_UNDEFINED.inspect = "undefined"

class JSConsole
  def log(*args)
    puts args.map { |v| js_format(v) }.join(" ")
  end

  def error(*args)
    warn args.map { |v| js_format(v) }.join(" ")
  end

  def warn(*args) = error(*args)
end

def js_format(v)
  case v
  when JS_UNDEFINED then "undefined"
  when nil then "null"
  when true then "true"
  when false then "false"
  when Array then v.map { |x| js_format(x) }.join(",")
  when Hash
    "[object Object]"
  else
    if v.is_a?(Float) && v.finite? && v == v.to_i
      v.to_i.to_s
    else
      v.to_s
    end
  end
end

class StdModule
  SEEK_SET = IO::SEEK_SET
  SEEK_CUR = IO::SEEK_CUR
  SEEK_END = IO::SEEK_END

  def printf(fmt, *args)
    print(fmt % args)
    nil
  end

  def sprintf(fmt, *args) = fmt % args
  def puts(*args) = (STDOUT.puts(*args.map { |a| js_format(a) }); nil)
  def getenv(name) = ENV[name.to_s]
  def setenv(name, value) = (ENV[name.to_s] = value.to_s; nil)
  def unsetenv(name) = (ENV.delete(name.to_s); nil)
  def getenviron = ENV.to_h
  def exit(code = 0) = Kernel.exit(code.to_i)
  def gc = GC.start
  def strerror(errno) = SystemCallError.new(errno.to_i).message rescue "Error #{errno}"
  def loadFile(path) = File.read(path.to_s)
  def readFile(path, mode = "utf-8") = File.binread(path.to_s)
  def parseExtJSON(str) = MiniJSON.parse(str.to_s)

  def open(path, flags = "r")
    File.open(path.to_s, flags.to_s)
  end
end

class OSModule
  def platform = "linux"
  def getcwd = Dir.pwd
  def chdir(path) = (Dir.chdir(path.to_s); nil)
  def mkdir(path, mode = 0o777) = (Dir.mkdir(path.to_s, mode.to_i); nil)
  def remove(path) = (File.delete(path.to_s); nil)
  def rename(a, b) = (File.rename(a.to_s, b.to_s); nil)
  def realpath(path) = File.realpath(path.to_s)
  def readdir(path) = Dir.children(path.to_s)
  def readlink(path) = File.readlink(path.to_s)
  def symlink(target, path) = (File.symlink(target.to_s, path.to_s); nil)
  def sleep(ms) = (Kernel.sleep(ms.to_f / 1000.0); nil)
  def stat(path) = file_stat(path, false)
  def lstat(path) = file_stat(path, true)

  def file_stat(path, link)
    s = link ? File.lstat(path.to_s) : File.stat(path.to_s)
    [s.dev, s.ino, s.mode, s.nlink, s.uid, s.gid, s.rdev, s.size,
     s.blksize || 0, s.blocks || 0, s.atime.to_f, s.mtime.to_f, s.ctime.to_f]
  rescue Errno::ENOENT
    nil
  end
end

module MiniJSON
  module_function

  def stringify(obj)
    case obj
    when nil then "null"
    when true then "true"
    when false then "false"
    when Numeric then obj.to_s
    when String then '"' + obj.gsub(/["\\\n\r\t]/, { '"' => '\"', "\\" => "\\\\", "\n" => "\\n", "\r" => "\\r", "\t" => "\\t" }) + '"'
    when Array then "[" + obj.map { |x| stringify(x) }.join(",") + "]"
    when Hash then "{" + obj.map { |k, v| stringify(k.to_s) + ":" + stringify(v) }.join(",") + "}"
    else stringify(obj.to_s)
    end
  end

  def parse(str)
    s = str.strip
    return nil if s == "null"
    return true if s == "true"
    return false if s == "false"
    return s[1...-1].gsub(/\\"/, '"').gsub(/\\n/, "\n") if s.start_with?('"') && s.end_with?('"')
    return s.to_i if s.match?(/\A-?\d+\z/)
    return s.to_f if s.match?(/\A-?\d+\.\d+/)
    raise "unsupported JSON"
  end
end

class MathJS
  class << self
    def abs(x) = x.abs
    def floor(x) = x.floor
    def ceil(x) = x.ceil
    def round(x) = x.round
    def trunc(x) = x.to_i
    def max(*xs) = xs.max
    def min(*xs) = xs.min
    def pow(a, b) = a**b
    def sqrt(x) = Math.sqrt(x)
    def sin(x) = Math.sin(x)
    def cos(x) = Math.cos(x)
    def tan(x) = Math.tan(x)
    def log(x) = Math.log(x)
    def exp(x) = Math.exp(x)
    def random = rand
  end
end

class JSONJS
  class << self
    def stringify(obj) = MiniJSON.stringify(obj)
    def parse(str) = MiniJSON.parse(str)
  end
end

class Runner
  HELP = <<~HELP
    QuickJS version 2025-09-13
    usage: qjs [options] [file [args]]
    -h  --help         list options
    -e  --eval EXPR    evaluate EXPR
    -i  --interactive  go to interactive mode
    -m  --module       load as ES6 module (default=autodetect)
        --script       load as ES6 script (default=autodetect)
        --strict       force strict mode
    -I  --include file include an additional file
        --std          make 'std' and 'os' available to the loaded script
    -T  --trace        trace memory allocation
    -d  --dump         dump the memory usage stats
        --memory-limit n  limit the memory usage to 'n' bytes (SI suffixes allowed)
        --stack-size n    limit the stack size to 'n' bytes (SI suffixes allowed)
        --no-unhandled-rejection  ignore unhandled promise rejections
    -s                    strip all the debug info
        --strip-source    strip the source code
    -q  --quit         just instantiate the interpreter and quit
  HELP

  attr_reader :scriptArgs

  def initialize
    @console = JSConsole.new
    @std = nil
    @os = nil
    @scriptArgs = []
    @vars = {}
    @funcs = {}
  end

  def run(argv)
    evals = []
    includes = []
    file = nil
    interactive = false
    i = 0
    while i < argv.length
      a = argv[i]
      case a
      when "-h", "--help"
        STDERR.write(HELP)
        return 1
      when "-q", "--quit"
        return 0
      when "-e", "--eval"
        i += 1
        return usage_error("missing expression for #{a}") unless argv[i]
        evals << argv[i]
      when "-I", "--include"
        i += 1
        return usage_error("missing filename for #{a}") unless argv[i]
        includes << argv[i]
      when "--std"
        enable_std
      when "-i", "--interactive"
        interactive = true
      when "-m", "--module", "--script", "--strict", "-T", "-d", "-s", "--strip-source", "--no-unhandled-rejection"
        # Accepted for compatibility; most affect the real compiler/runtime only.
      when "--memory-limit", "--stack-size"
        i += 1
      else
        if a.start_with?("-")
          return usage_error("unknown option '#{a}'")
        end
        if evals.empty?
          file = a
          @scriptArgs = argv[i..] || []
        else
          @scriptArgs = argv[i..] || []
        end
        break
      end
      i += 1
    end

    includes.each { |path| execute(File.read(path), path) }
    evals.each { |src| execute(src, "<cmdline>") }
    execute(File.read(file), file) if file
    repl if interactive || (evals.empty? && file.nil?)
    0
  rescue SystemExit
    raise
  rescue Exception => e
    warn format_error(e)
    1
  end

  def enable_std
    @std = StdModule.new
    @os = OSModule.new
  end

  def repl
    while (line = STDIN.gets)
      begin
        v = eval_expr(line.strip)
        puts js_format(v) unless v.equal?(JS_UNDEFINED) || v.nil?
      rescue Exception => e
        warn format_error(e)
      end
    end
  end

  def execute(src, filename)
    src = strip_comments(src)
    src = expand_imports(src)
    run_block(src, filename)
  end

  def expand_imports(src)
    src.gsub(/import\s+\*\s+as\s+(std|os)\s+from\s+['"]\1['"]\s*;?/) do
      enable_std
      ""
    end.gsub(/import\s+\{([^}]+)\}\s+from\s+['"](std|os)['"]\s*;?/) do
      enable_std
      names = Regexp.last_match(1).split(",").map { |x| x.strip.split(/\s+as\s+/).last }
      names.map { |n| "var #{n}=#{Regexp.last_match(2)}.#{n};" }.join("\n")
    end
  end

  def run_block(src, filename = "<eval>")
    src = src.gsub(/}\s+(?!(?:else)\b)(?=(?:console|print|let|var|const|function|if|for|while|return|[A-Za-z_$][\w$]*\s*\())/, "}; ")
    statements(src).each { |st| run_statement(st.strip, filename) unless st.strip.empty? }
  end

  def run_statement(st, filename)
    return if st.empty?
    return run_block($1, filename) if st =~ /^\{(.*)\}$/m

    if st =~ /\Athrow\s+new\s+Error\s*\((.*)\)\z/m
      raise RuntimeError, eval_expr($1).to_s
    elsif st =~ /\A(?:let|var|const)\s+([A-Za-z_$][\w$]*)\s*=\s*(.*)\z/m
      @vars[$1] = eval_expr($2)
    elsif st =~ /\A(?:let|var|const)\s+([A-Za-z_$][\w$]*)\z/
      @vars[$1] = JS_UNDEFINED
    elsif st =~ /\Afunction\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)\s*\{(.*)\}\z/m
      @funcs[$1] = [$2.split(",").map(&:strip).reject(&:empty?), $3]
    elsif st =~ /\Areturn(?:\s+(.*))?\z/m
      throw :return, ($1 ? eval_expr($1) : JS_UNDEFINED)
    elsif st =~ /\A([A-Za-z_$][\w$]*)\s*=\s*(.*)\z/m
      @vars[$1] = eval_expr($2)
    elsif st =~ /\A([A-Za-z_$][\w$]*)\+\+\z/
      @vars[$1] = (@vars[$1] || 0) + 1
    elsif st =~ /\Aif\s*\((.*?)\)\s*\{(.*?)\}(?:\s*else\s*\{(.*)\})?\z/m
      truthy(eval_expr($1)) ? run_block($2, filename) : run_block($3.to_s, filename)
    elsif st =~ /\Afor\s*\(\s*(?:let|var)?\s*([A-Za-z_$][\w$]*)\s*=\s*(.*?);\s*(.*?);\s*(.*?)\s*\)\s*\{(.*)\}\z/m
      @vars[$1] = eval_expr($2)
      guard = 0
      while truthy(eval_expr($3))
        run_block($5, filename)
        run_statement($4, filename)
        guard += 1
        raise "loop limit exceeded" if guard > 1_000_000
      end
    elsif st =~ /\Awhile\s*\((.*)\)\s*\{(.*)\}\z/m
      guard = 0
      while truthy(eval_expr($1))
        run_block($2, filename)
        guard += 1
        raise "loop limit exceeded" if guard > 1_000_000
      end
    else
      eval_expr(st)
    end
  end

  def statements(src)
    out = []
    cur = +""
    depth = 0
    quote = nil
    esc = false
    src.each_char do |ch|
      cur << ch
      if quote
        if esc
          esc = false
        elsif ch == "\\"
          esc = true
        elsif ch == quote
          quote = nil
        end
        next
      end
      case ch
      when "'", '"', "`" then quote = ch
      when "{", "(", "[" then depth += 1
      when "}", ")", "]" then depth -= 1 if depth > 0
      when ";", "\n"
        if depth == 0
          cur.chop!
          out << cur
          cur = +""
        end
      end
    end
    out << cur unless cur.strip.empty?
    out
  end

  def eval_expr(expr)
    expr = expr.strip
    return JS_UNDEFINED if expr.empty?
    return @console.log(*split_args($1).map { |a| eval_expr(a) }) if expr =~ /\Aconsole\.log\s*\((.*)\)\z/m
    return @console.error(*split_args($1).map { |a| eval_expr(a) }) if expr =~ /\Aconsole\.(?:error|warn)\s*\((.*)\)\z/m
    return @console.log(*split_args($1).map { |a| eval_expr(a) }) if expr =~ /\Aprint\s*\((.*)\)\z/m
    return call_std($1, $2) if expr =~ /\Astd\.([A-Za-z_]\w*)\s*\((.*)\)\z/m
    return call_os($1, $2) if expr =~ /\Aos\.([A-Za-z_]\w*)\s*\((.*)\)\z/m
    return call_func($1, $2) if expr =~ /\A([A-Za-z_$][\w$]*)\s*\((.*)\)\z/m && @funcs.key?($1)
    return typeof($1.strip) if expr =~ /\Atypeof\s+(.+)\z/m
    return eval_expr($1) if expr =~ /^\((.*)\)$/m && balanced?($1)

    ruby = translate_expr(expr)
    binding.eval(ruby)
  rescue NameError
    JS_UNDEFINED
  end

  def call_std(name, args)
    enable_std unless @std
    @std.public_send(name, *split_args(args).map { |a| eval_expr(a) })
  end

  def call_os(name, args)
    enable_std unless @os
    @os.public_send(name, *split_args(args).map { |a| eval_expr(a) })
  end

  def call_func(name, args)
    params, body = @funcs.fetch(name)
    old = @vars.dup
    params.zip(split_args(args).map { |a| eval_expr(a) }).each { |k, v| @vars[k] = v }
    catch(:return) do
      run_block(body)
      JS_UNDEFINED
    end
  ensure
    @vars = old if old
  end

  def translate_expr(expr)
    s = expr.dup
    s.gsub!(/`([^`]*)`/) { '"' + Regexp.last_match(1).gsub(/\$\{([^}]+)\}/) { '#{' + translate_expr(Regexp.last_match(1)) + '}' } + '"' }
    s.gsub!(/\bundefined\b/, "JS_UNDEFINED")
    s.gsub!(/\bnull\b/, "nil")
    s.gsub!(/\btrue\b/, "true")
    s.gsub!(/\bfalse\b/, "false")
    s.gsub!(/(\d+)n\b/, '\1')
    s.gsub!(/===/, "==")
    s.gsub!(/!==/, "!=")
    s.gsub!(/&&/, " && ")
    s.gsub!(/\|\|/, " || ")
    s.gsub!(/\bMath\./, "MathJS.")
    s.gsub!(/\bJSON\./, "JSONJS.")
    s.gsub!(/\bscriptArgs\b/, "@scriptArgs")
    s.gsub!(/\bconsole\b/, "@console")
    s.gsub!(/\bstd\b/, "@std")
    s.gsub!(/\bos\b/, "@os")
    s.gsub!(/([A-Za-z_$][\w$]*|@[A-Za-z_]\w*|\))\.length\b/, '\1.length')
    s.gsub!(/\.toString\s*\(\s*\)/, ".to_s")
    s.gsub!(/\.charCodeAt\s*\(([^)]*)\)/, ".ord")
    @vars.each_key do |k|
      s.gsub!(/\b#{Regexp.escape(k)}\b/, "@vars[#{k.inspect}]")
    end
    s
  end

  def split_args(s)
    parts = []
    cur = +""
    depth = 0
    quote = nil
    esc = false
    s.each_char do |ch|
      if quote
        cur << ch
        if esc
          esc = false
        elsif ch == "\\"
          esc = true
        elsif ch == quote
          quote = nil
        end
        next
      end
      case ch
      when "'", '"', "`"
        quote = ch
        cur << ch
      when "(", "[", "{"
        depth += 1
        cur << ch
      when ")", "]", "}"
        depth -= 1
        cur << ch
      when ","
        if depth == 0
          parts << cur.strip
          cur = +""
        else
          cur << ch
        end
      else
        cur << ch
      end
    end
    parts << cur.strip unless cur.strip.empty?
    parts
  end

  def typeof(name)
    return "object" if name == "std" && @std
    return "object" if name == "os" && @os
    return "undefined" if %w[std os].include?(name)
    v = eval_expr(name)
    case v
    when JS_UNDEFINED then "undefined"
    when nil then "object"
    when true, false then "boolean"
    when Numeric then "number"
    when String then "string"
    else "object"
    end
  end

  def truthy(v) = !(v.nil? || v == false || v.equal?(JS_UNDEFINED) || v == 0 || v == "")

  def strip_comments(src)
    src.gsub(%r{//.*$}, "").gsub(%r{/\*.*?\*/}m, "")
  end

  def balanced?(s)
    d = 0
    s.each_char { |c| d += 1 if c == "("; d -= 1 if c == ")" }
    d == 0
  end

  def usage_error(msg)
    warn msg
    warn "qjs: use -h for help"
    1
  end

  def format_error(e)
    if e.is_a?(RuntimeError)
      "Error: #{e.message}\n    at <eval> (<cmdline>:1:1)"
    else
      "#{e.class}: #{e.message}"
    end
  end
end

exit Runner.new.run(ARGV)
