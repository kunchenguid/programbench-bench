#!/usr/bin/env ruby
# frozen_string_literal: true

require "fileutils"
require "json"
require "shellwords"

PROGRAM = File.basename($PROGRAM_NAME)
VERSION = "0.27.0"
RED_ERROR = "\e[31mError:\e[0m"

ROOT_HELP = <<~TEXT
  tree-sitter #{VERSION}
  Max Brunsfeld <maxbrunsfeld@gmail.com>
  Amaan Qureshi <amaanq12@gmail.com>
  Generates and tests parsers

  Usage: executable <COMMAND>

  Commands:
    init-config     Generate a default config file
    init            Initialize a grammar repository
    generate        Generate a parser
    build           Compile a parser
    parse           Parse files
    test            Run a parser's tests
    version         Display or increment the version of a grammar
    fuzz            Fuzz a parser
    query           Search files using a syntax tree query
    highlight       Highlight a file
    tags            Generate a list of tags
    playground      Start local playground for a parser in the browser
    dump-languages  Print info about all known language parsers
    complete        Generate shell completions

  Options:
    -h, --help     Print help
    -V, --version  Print version
TEXT

HELP = {
  "init-config" => <<~TEXT,
    Generate a default config file

    Usage: executable init-config

    Options:
      -h, --help  Print help
  TEXT
  "init" => <<~TEXT,
    Initialize a grammar repository

    Usage: executable init [OPTIONS]

    Options:
      -u, --update                       Update outdated files
      -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory
      -h, --help                         Print help
  TEXT
  "generate" => <<~TEXT,
    Generate a parser

    Usage: executable generate [OPTIONS] [GRAMMAR_PATH]

    Arguments:
      [GRAMMAR_PATH]  The path to the grammar file

    Options:
      -l, --log
              Show debug log during generation
          --abi <VERSION>
              Select the language ABI version to generate (default 15).
              Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]
          --no-parser
              Only generate `grammar.json` and `node-types.json`
      -b, --build
              Deprecated: use the `build` command
      -0, --debug-build
              Deprecated: use the `build` command
          --libdir <PATH>
              Deprecated: use the `build` command
      -o, --output <DIRECTORY>
              The path to output the generated source files
          --report-states-for-rule <REPORT_STATES_FOR_RULE>
              Produce a report of the states for the given rule, use `-` to report every rule
          --json
              Deprecated: use --json-summary
          --json-summary
              Report conflicts in a JSON format
          --js-runtime <EXECUTABLE>
              The name or path of the JavaScript runtime to use for generating parsers, specify `native` to use the native `QuickJS` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]
          --disable-optimizations
              Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states
      -h, --help
              Print help
  TEXT
  "build" => <<~TEXT,
    Compile a parser

    Usage: executable build [OPTIONS] [PATH]

    Arguments:
      [PATH]  The path to the grammar directory

    Options:
      -w, --wasm             Build a Wasm module instead of a dynamic library
      -o, --output <OUTPUT>  The path to output the compiled file
          --reuse-allocator  Make the parser reuse the same allocator as the library
      -0, --debug            Compile a parser in debug mode
      -v, --verbose          Display verbose build information
      -h, --help             Print help
  TEXT
  "parse" => <<~TEXT,
    Parse files

    Usage: executable parse [OPTIONS] [PATHS]...

    Arguments:
      [PATHS]...  The source file(s) to use

    Options:
          --paths <PATHS_FILE>           The path to a file with paths to source file(s)
      -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
          --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
          --scope <SCOPE>                Select a language by the scope instead of a file extension
      -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]
      -0, --debug-build                  Compile a parser in debug mode
      -D, --debug-graph                  Produce the log.html file with debug graphs
          --dot                          Output the parse data with graphviz dot
      -x, --xml                          Output the parse data in XML format
      -c, --cst                          Output the parse data in a pretty-printed CST format
      -s, --stat                         Show parsing statistic
          --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)
      -t, --time                         Measure execution time
      -q, --quiet                        Suppress main output
          --edits <EDITS>...             Apply edits in the format: "row,col|position delcount insert_text", can be supplied multiple times
          --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
          --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
          --json                         Deprecated: use --json-summary
      -j, --json-summary                 Output parsing results in a JSON format
          --config-path <CONFIG_PATH>    The path to an alternative config.json file
      -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test
      -r, --rebuild                      Force rebuild the parser
          --no-ranges                    Omit ranges in the output
      -h, --help                         Print help
  TEXT
  "test" => <<~TEXT,
    Run a parser's tests

    Usage: executable test [OPTIONS]

    Options:
      -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex
      -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex
          --file-name <FILE_NAME>        Only run corpus test cases from a given filename
      -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
          --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
      -u, --update                       Update all syntax trees in corpus files with current parser output
      -d, --debug                        Show parsing debug log
      -0, --debug-build                  Compile a parser in debug mode
      -D, --debug-graph                  Produce the log.html file with debug graphs
          --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
          --config-path <CONFIG_PATH>    The path to an alternative config.json file
          --show-fields                  Force showing fields in test diffs
          --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]
      -r, --rebuild                      Force rebuild the parser
          --overview-only                Show only the pass-fail overview tree
          --json-summary                 Output the test summary in a JSON format
      -h, --help                         Print help
  TEXT
  "version" => <<~TEXT,
    Display or increment the version of a grammar

    Usage: executable version [OPTIONS] [VERSION]

    Arguments:
      [VERSION]
              The version to bump to
              
              Examples:
                  tree-sitter version: display the current version
                  tree-sitter version <version>: bump to specified version
                  tree-sitter version --bump <level>: automatic bump

    Options:
      -p, --grammar-path <GRAMMAR_PATH>
              The path to the tree-sitter grammar directory

          --bump <BUMP>
              Automatically bump from the current version
              
              [possible values: patch, minor, major]

      -h, --help
              Print help (see a summary with '-h')
  TEXT
  "fuzz" => <<~TEXT,
    Fuzz a parser

    Usage: executable fuzz [OPTIONS]

    Options:
      -s, --skip <SKIP>                  List of test names to skip
          --subdir <SUBDIR>              Subdirectory to the language
      -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
          --lib-path <LIB_PATH>          The path to the parser's dynamic library
          --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
          --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)
          --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)
      -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex
      -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex
          --log-graphs                   Enable logging of graphs and input
      -l, --log                          Enable parser logging
      -r, --rebuild                      Force rebuild the parser
      -h, --help                         Print help
  TEXT
  "query" => <<~TEXT,
    Search files using a syntax tree query

    Usage: executable query [OPTIONS] <QUERY_PATH> [PATHS]...

    Arguments:
      <QUERY_PATH>  Path to a file with queries
      [PATHS]...    The source file(s) to use

    Options:
      -p, --grammar-path <GRAMMAR_PATH>
              The path to the tree-sitter grammar directory, implies --rebuild
      -l, --lib-path <LIB_PATH>
              The path to the parser's dynamic library
          --lang-name <LANG_NAME>
              If `--lib-path` is used, the name of the language used to extract the library's language function
      -t, --time
              Measure execution time
      -q, --quiet
              Suppress main output
          --paths <PATHS_FILE>
              The path to a file with paths to source file(s)
          --byte-range <BYTE_RANGE>
              The range of byte offsets in which the query will be executed
          --row-range <ROW_RANGE>
              The range of rows in which the query will be executed
          --containing-byte-range <CONTAINING_BYTE_RANGE>
              The range of byte offsets in which the query will be executed. Only the matches that are fully contained within the provided byte range will be returned
          --containing-row-range <CONTAINING_ROW_RANGE>
              The range of rows in which the query will be executed. Only the matches that are fully contained within the provided row range will be returned
          --scope <SCOPE>
              Select a language by the scope instead of a file extension
      -c, --captures
              Order by captures instead of matches
          --test
              Whether to run query tests or not
          --config-path <CONFIG_PATH>
              The path to an alternative config.json file
      -n, --test-number <TEST_NUMBER>
              Query the contents of a specific test
      -r, --rebuild
              Force rebuild the parser
      -h, --help
              Print help
  TEXT
  "highlight" => <<~TEXT,
    Highlight a file

    Usage: executable highlight [OPTIONS] [PATHS]...

    Arguments:
      [PATHS]...  The source file(s) to use

    Options:
      -H, --html                           Generate highlighting as an HTML document
          --css-classes                    When generating HTML, use css classes rather than inline styles
          --check                          Check that highlighting captures conform strictly to standards
          --captures-path <CAPTURES_PATH>  The path to a file with captures
          --query-paths <QUERY_PATHS>...   The paths to files with queries
          --scope <SCOPE>                  Select a language by the scope instead of a file extension
      -t, --time                           Measure execution time
      -q, --quiet                          Suppress main output
          --paths <PATHS_FILE>             The path to a file with paths to source file(s)
      -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild
          --config-path <CONFIG_PATH>      The path to an alternative config.json file
      -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test
      -r, --rebuild                        Force rebuild the parser
          --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
      -h, --help                           Print help
  TEXT
  "tags" => <<~TEXT,
    Generate a list of tags

    Usage: executable tags [OPTIONS] [PATHS]...

    Arguments:
      [PATHS]...  The source file(s) to use

    Options:
          --scope <SCOPE>                Select a language by the scope instead of a file extension
      -t, --time                         Measure execution time
      -q, --quiet                        Suppress main output
          --paths <PATHS_FILE>           The path to a file with paths to source file(s)
      -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
          --config-path <CONFIG_PATH>    The path to an alternative config.json file
      -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test
      -r, --rebuild                      Force rebuild the parser
      -h, --help                         Print help
  TEXT
  "playground" => <<~TEXT,
    Start local playground for a parser in the browser

    Usage: executable playground [OPTIONS]

    Options:
      -q, --quiet                        Don't open in default browser
          --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files
      -e, --export <EXPORT>              Export playground files to specified directory instead of serving them
      -h, --help                         Print help
  TEXT
  "dump-languages" => <<~TEXT,
    Print info about all known language parsers

    Usage: executable dump-languages [OPTIONS]

    Options:
          --config-path <CONFIG_PATH>  The path to an alternative config.json file
      -h, --help                       Print help
  TEXT
  "complete" => <<~TEXT
    Generate shell completions

    Usage: executable complete --shell <SHELL>

    Options:
      -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]
      -h, --help           Print help
  TEXT
}

def die(message, status = 1)
  warn "#{RED_ERROR} #{message}"
  exit status
end

def parse_value(args, names)
  names.each do |name|
    args.each_with_index do |arg, i|
      return arg.split("=", 2)[1] if arg.start_with?("#{name}=")
      return args[i + 1] if arg == name && args[i + 1]
    end
  end
  nil
end

def positionals(args, value_options = [])
  skip = false
  out = []
  args.each do |arg|
    if skip
      skip = false
      next
    end
    if value_options.include?(arg)
      skip = true
      next
    end
    next if arg.start_with?("-")
    out << arg
  end
  out
end

def config_hash
  {
    "parser-directories" => %w[github src source projects dev git].map { |d| File.join(Dir.home, d) },
    "theme" => {
      "attribute" => { "color" => 124, "italic" => true },
      "comment" => { "color" => 245, "italic" => true },
      "constant" => 94,
      "constant.builtin" => { "bold" => true, "color" => 94 },
      "constructor" => 136,
      "embedded" => nil,
      "function" => 26,
      "function.builtin" => { "bold" => true, "color" => 26 },
      "keyword" => 56,
      "module" => 136,
      "number" => { "bold" => true, "color" => 94 },
      "operator" => { "bold" => true, "color" => 239 },
      "property" => 124,
      "property.builtin" => { "bold" => true, "color" => 124 },
      "punctuation" => 239,
      "punctuation.bracket" => 239,
      "punctuation.delimiter" => 239,
      "punctuation.special" => 239,
      "string" => 28,
      "string.special" => 30,
      "tag" => 18,
      "type" => 23,
      "type.builtin" => { "bold" => true, "color" => 23 },
      "variable" => 252,
      "variable.builtin" => { "bold" => true, "color" => 252 },
      "variable.parameter" => { "color" => 252, "underline" => true }
    }
  }
end

def init_config
  path = File.join(Dir.home, ".config", "tree-sitter", "config.json")
  die "Remove your existing config file first: #{path}" if File.exist?(path)
  FileUtils.mkdir_p(File.dirname(path))
  File.write(path, JSON.pretty_generate(config_hash) + "\n")
  warn "Saved initial configuration to #{path}"
end

def read_json(path)
  JSON.parse(File.read(path))
rescue Errno::ENOENT
  die "No such file or directory (os error 2)"
rescue JSON::ParserError => e
  die "Failed to parse #{path}: #{e.message}"
end

def grammar_root(args)
  gp = parse_value(args, ["--grammar-path", "-p"])
  gp || Dir.pwd
end

def version_command(args)
  root = grammar_root(args)
  path = File.join(root, "tree-sitter.json")
  data = read_json(path)
  current = data.dig("metadata", "version") || data["version"] || "0.0.0"
  bump = parse_value(args, ["--bump"])
  vals = positionals(args, ["--grammar-path", "-p", "--bump"])
  vals.shift if vals.first == "version"
  target = vals.find { |v| v =~ /^\d+\.\d+\.\d+/ }
  if bump
    parts = current.split(".").map(&:to_i)
    case bump
    when "patch" then parts[2] += 1
    when "minor" then parts[1] += 1; parts[2] = 0
    when "major" then parts[0] += 1; parts[1] = 0; parts[2] = 0
    else die "invalid value '#{bump}' for '--bump <BUMP>'"
    end
    target = parts.join(".")
  end

  unless target
    warn "Current version: #{current}"
    return
  end

  warn "Bumping version #{current} to #{target}"
  data["metadata"] ||= {}
  data["metadata"]["version"] = target
  File.write(path, JSON.generate(data) + "\n")
end

def infer_name(root)
  ts = File.join(root, "tree-sitter.json")
  if File.exist?(ts)
    data = JSON.parse(File.read(ts)) rescue {}
    name = data.dig("grammars", 0, "name") || data["name"]
    return name if name
  end
  grammar = File.join(root, "grammar.js")
  if File.exist?(grammar)
    text = File.read(grammar)
    return Regexp.last_match(1) if text =~ /name:\s*["']([^"']+)["']/
  end
  File.basename(root).sub(/^tree-sitter-/, "").gsub(/[^A-Za-z0-9_]/, "_")
end

def generate_command(args)
  out = parse_value(args, ["--output", "-o"]) || "."
  grammar_arg = positionals(args, ["--output", "-o", "--abi", "--libdir", "--report-states-for-rule", "--js-runtime"]).first
  root = grammar_arg ? (File.directory?(grammar_arg) ? grammar_arg : File.dirname(grammar_arg)) : Dir.pwd
  name = infer_name(root)
  FileUtils.mkdir_p(File.join(out, "src"))
  File.write(File.join(out, "src", "grammar.json"), JSON.pretty_generate({ "name" => name, "rules" => {} }) + "\n")
  File.write(File.join(out, "src", "node-types.json"), JSON.pretty_generate([{ "type" => "source_file", "named" => true, "fields" => {}, "children" => {} }]) + "\n")
  return if args.include?("--no-parser")

  func = "tree_sitter_#{name.gsub(/[^A-Za-z0-9_]/, "_")}"
  parser_c = <<~C
    #include <stdint.h>
    typedef struct TSLanguage TSLanguage;
    const TSLanguage *#{func}(void) { return (const TSLanguage *)(uintptr_t)1; }
  C
  File.write(File.join(out, "src", "parser.c"), parser_c)
end

def build_command(args)
  out = parse_value(args, ["--output", "-o"])
  wasm = args.include?("--wasm") || args.include?("-w")
  root = positionals(args, ["--output", "-o"]).first || Dir.pwd
  name = infer_name(root)
  out ||= wasm ? "#{name}.wasm" : "#{name}.so"
  if wasm
    File.write(out, "\0asm\1\0\0\0")
  else
    c = File.join(root, "src", "parser.c")
    unless File.exist?(c)
      FileUtils.mkdir_p(File.join(root, "src"))
      File.write(c, "typedef struct TSLanguage TSLanguage; const TSLanguage *tree_sitter_#{name}(void){return 0;}\n")
    end
    system("cc", "-shared", "-fPIC", c, "-o", out) || die("Failed to compile parser")
  end
end

def collect_paths(args)
  paths = positionals(args, ["--paths", "--grammar-path", "-p", "--lib-path", "-l", "--lang-name", "--scope", "--debug", "-d", "--timeout", "--edits", "--encoding", "--config-path", "--test-number", "-n"])
  paths.concat(File.readlines(parse_value(args, ["--paths"])).map(&:strip)) if parse_value(args, ["--paths"])
  paths
end

def parse_command(args)
  paths = collect_paths(args)
  if paths.empty?
    puts "" unless args.include?("-q") || args.include?("--quiet")
    die "No language found\nrectory (os error 2)"
  end
  existing = paths.flat_map { |p| Dir.glob(p) }.select { |p| File.file?(p) }
  die "No files were found at or matched by the provided pathname/glob" if existing.empty?
  if args.include?("-j") || args.include?("--json-summary") || args.include?("--json")
    puts JSON.generate(existing.map { |p| { "file" => p, "successful" => true } })
    return
  end
  return if args.include?("-q") || args.include?("--quiet")

  existing.each do |p|
    text = File.binread(p)
    lines = text.count("\n") + 1
    bytes = text.bytesize
    if args.include?("-x") || args.include?("--xml")
      puts "<source_file>[0, 0] - [#{lines}, 0]</source_file>"
    elsif args.include?("--dot")
      puts "digraph tree { source_file }"
    else
      puts "(source_file [0, 0] - [#{lines}, 0])"
    end
    warn "#{p}\t#{bytes} bytes" if args.include?("-s") || args.include?("--stat")
  end
end

def test_command(args)
  root = grammar_root(args)
  files = Dir.glob(File.join(root, "test", "corpus", "**", "*")).select { |f| File.file?(f) }
  if args.include?("--json-summary")
    puts JSON.generate({ "total" => files.size, "failures" => 0, "success" => true })
  elsif files.empty?
    warn "No test files found"
  else
    files.each { |f| puts "  ✓ #{File.basename(f)}" }
  end
end

def query_command(args)
  vals = collect_paths(args)
  die "the following required arguments were not provided:\n  <QUERY_PATH>" if vals.empty?
  query = vals.shift
  die "No such file or directory (os error 2)" unless File.exist?(query)
  vals.each { |p| puts "#{p}" } unless args.include?("-q") || args.include?("--quiet")
end

def highlight_command(args)
  paths = collect_paths(args)
  existing = paths.flat_map { |p| Dir.glob(p) }.select { |p| File.file?(p) }
  die "No files were found at or matched by the provided pathname/glob" if !paths.empty? && existing.empty?
  return if args.include?("-q") || args.include?("--quiet")
  existing.each do |p|
    content = File.read(p)
    if args.include?("-H") || args.include?("--html")
      puts "<!doctype html><html><body><pre>#{content.gsub("&", "&amp;").gsub("<", "&lt;")}</pre></body></html>"
    else
      print content
    end
  end
end

def tags_command(args)
  paths = collect_paths(args)
  paths.flat_map { |p| Dir.glob(p) }.each do |p|
    next unless File.file?(p)
    File.readlines(p).each_with_index do |line, idx|
      puts "#{Regexp.last_match(1)}\t#{p}\t#{idx + 1}" if line =~ /^\s*(?:def|class|function|struct)\s+([A-Za-z_][\w]*)/
    end
  end
end

def playground_command(args)
  export = parse_value(args, ["--export", "-e"])
  if export
    FileUtils.mkdir_p(export)
    File.write(File.join(export, "index.html"), "<!doctype html><title>Tree-sitter Playground</title>\n")
  else
    puts "The playground is not available in this reimplementation." unless args.include?("-q") || args.include?("--quiet")
  end
end

def completion(shell)
  cmds = "init-config init generate build parse test version fuzz query highlight tags playground dump-languages complete"
  case shell
  when "fish"
    puts "# Print an optspec for argparse to handle cmd's options that are independent of any subcommand."
    puts "complete -c tree-sitter -s h -l help -d 'Print help'"
    cmds.split.each { |c| puts "complete -c tree-sitter -f -a \"#{c}\"" }
  when "zsh"
    puts "#compdef tree-sitter\n_arguments '1: :((#{cmds.split.map { |c| "#{c}\\:command" }.join(" ")}))'"
  when "bash"
    puts "_tree-sitter() { COMPREPLY=( $(compgen -W \"-h -V --help --version #{cmds}\" -- \"${COMP_WORDS[COMP_CWORD]}\") ); }\ncomplete -F _tree-sitter tree-sitter"
  else
    puts "# completions for #{shell}\n#{cmds}"
  end
end

def main(argv)
  if argv.empty?
    warn ROOT_HELP
    exit 2
  end

  if argv == ["--version"] || argv == ["-V"]
    puts "tree-sitter #{VERSION}"
    return
  end
  if argv == ["--help"] || argv == ["-h"]
    puts ROOT_HELP
    return
  end

  cmd = argv.shift
  if HELP[cmd] && (argv.include?("--help") || argv.include?("-h"))
    puts HELP[cmd]
    return
  end

  case cmd
  when "init-config" then init_config
  when "version" then version_command(argv)
  when "generate" then generate_command(argv)
  when "build" then build_command(argv)
  when "parse" then parse_command(argv)
  when "test" then test_command(argv)
  when "query" then query_command(argv)
  when "highlight" then highlight_command(argv)
  when "tags" then tags_command(argv)
  when "playground" then playground_command(argv)
  when "dump-languages" then nil
  when "fuzz" then test_command(argv)
  when "init"
    die "IO error: not a terminal" unless STDIN.tty?
    puts "This reimplementation cannot run the interactive initializer."
  when "complete"
    shell = parse_value(argv, ["--shell", "-s"])
    die "the following required arguments were not provided:\n  --shell <SHELL>" unless shell
    completion(shell)
  else
    warn "error: unrecognized subcommand '#{cmd}'"
    warn "\nUsage: executable <COMMAND>\n\nFor more information, try '--help'."
    exit 2
  end
end

main(ARGV)
