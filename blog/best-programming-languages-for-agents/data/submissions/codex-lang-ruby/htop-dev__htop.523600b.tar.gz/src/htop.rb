#!/usr/bin/env ruby
# frozen_string_literal: true

require 'etc'

VERSION = 'htop 3.5.0-dev-878e0ce'

HELP = <<~TEXT
  htop 3.5.0-dev-878e0ce
  (C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.
  Released under the GNU GPLv2+.

  -C --no-color                   Use a monochrome color scheme
  -d --delay=DELAY                Set the delay between updates, in tenths of seconds
  -F --filter=FILTER              Show only the commands matching the given filter
     --no-function-bar             Hide the function bar
  -h --help                       Print this help screen
  -H --highlight-changes[=DELAY]  Highlight new and old processes
  -M --no-mouse                   Disable the mouse
     --no-meters                  Hide meters
  -n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates
  -p --pid=PID[,PID,PID...]       Show only the given PIDs
     --readonly                   Disable all system and process changing features
  -s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)
  -t --tree                       Show the tree view (can be combined with -s)
  -u --user[=USERNAME]            Show only processes for a given user (or $USER)
  -U --no-unicode                 Do not use unicode but plain ASCII
  -V --version                    Print version info

  Press F1 inside htop for online help.
  See 'man htop' for more information.
TEXT

SORT_KEYS = [
  ['PID', 'Process/thread ID'],
  ['Command', 'Command line (insert as last column only)'],
  ['STATE', 'Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)'],
  ['PPID', 'Parent process ID'],
  ['PGRP', 'Process group ID'],
  ['SESSION', "Process's session ID"],
  ['TTY', 'Controlling terminal'],
  ['TPGID', 'Process ID of the fg process group of the controlling terminal'],
  ['MINFLT', 'Number of minor faults which have not required loading a memory page from disk'],
  ['CMINFLT', "Children processes' minor faults"],
  ['MAJFLT', 'Number of major faults which have required loading a memory page from disk'],
  ['CMAJFLT', "Children processes' major faults"],
  ['UTIME', 'User CPU time - time the process spent executing in user mode'],
  ['STIME', 'System CPU time - time the kernel spent running system calls for this process'],
  ['CUTIME', "Children processes' user CPU time"],
  ['CSTIME', "Children processes' system CPU time"],
  ['PRIORITY', "Kernel's internal priority for the process"],
  ['NICE', 'Nice value (the higher the value, the more it lets other processes take priority)'],
  ['STARTTIME', 'Time the process was started'],
  ['PROCESSOR', 'Id of the CPU the process last executed on'],
  ['M_VIRT', 'Total program size in virtual memory'],
  ['M_RESIDENT', 'Resident set size, size of the text and data sections, plus stack usage'],
  ['M_SHARE', "Size of the process's shared pages"],
  ['M_TRS', 'Size of the .text segment of the process (CODE)'],
  ['M_DRS', 'Size of the .data segment plus stack usage of the process (DATA)'],
  ['M_LRS', 'The library size of the process (calculated from memory maps)'],
  ['ST_UID', 'User ID of the process owner'],
  ['PERCENT_CPU', 'Percentage of the CPU time the process used in the last sampling'],
  ['PERCENT_MEM', 'Percentage of the memory the process is using, based on resident memory size'],
  ['USER', 'Username of the process owner (or user ID if name cannot be determined)'],
  ['TIME', 'Total time the process has spent in user and system time'],
  ['NLWP', 'Number of threads in the process'],
  ['TGID', 'Thread group ID (i.e. process ID)'],
  ['PERCENT_NORM_CPU', 'Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)'],
  ['ELAPSED', 'Time since the process was started'],
  ['SCHEDULERPOLICY', 'Current scheduling policy of the process'],
  ['RCHAR', 'Number of bytes the process has read'],
  ['WCHAR', 'Number of bytes the process has written'],
  ['SYSCR', 'Number of read(2) syscalls for the process'],
  ['SYSCW', 'Number of write(2) syscalls for the process'],
  ['RBYTES', 'Bytes of read(2) I/O for the process'],
  ['WBYTES', 'Bytes of write(2) I/O for the process'],
  ['CNCLWB', 'Bytes of cancelled write(2) I/O'],
  ['IO_READ_RATE', 'The I/O rate of read(2) in bytes per second for the process'],
  ['IO_WRITE_RATE', 'The I/O rate of write(2) in bytes per second for the process'],
  ['IO_RATE', 'Total I/O rate in bytes per second'],
  ['CGROUP', 'Which cgroup the process is in'],
  ['OOM', 'OOM (Out-of-Memory) killer score'],
  ['IO_PRIORITY', 'I/O priority'],
  ['M_PSS', 'proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it'],
  ['M_SWAP', "Size of the process's swapped pages"],
  ['M_PSSWP', 'shows proportional swap share of this mapping, unlike "Swap", this does not take into account swapped out page of underlying shmem objects'],
  ['CTXT', 'Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)'],
  ['SECATTR', 'Security attribute of the process (e.g. SELinux or AppArmor)'],
  ['COMM', 'comm string of the process from /proc/[pid]/comm'],
  ['EXE', 'Basename of exe of the process from /proc/[pid]/exe'],
  ['CWD', 'The current working directory of the process'],
  ['AUTOGROUP_ID', 'The autogroup identifier of the process'],
  ['AUTOGROUP_NICE', 'Nice value (the higher the value, the more other processes take priority) associated with the process autogroup'],
  ['CCGROUP', 'Which cgroup the process is in (condensed to essentials)'],
  ['CONTAINER', 'Name of the container the process is in (guessed by heuristics)'],
  ['M_PRIV', 'The private memory size of the process - resident set size minus shared memory'],
  ['GPU_TIME', 'Total GPU time'],
  ['GPU_PERCENT', 'Percentage of the GPU time the process used in the last sampling'],
  ['ISCONTAINER', 'Whether the process is running inside a child container']
].freeze

VALID_SORT_KEYS = SORT_KEYS.map(&:first).freeze

Options = Struct.new(:delay, :filter, :iterations, :pids, :sort_key, :user, :no_meters, keyword_init: true)

def die(message)
  warn message
  exit 1
end

def need_arg(argv, i, opt)
  return argv[i + 1] if i + 1 < argv.length

  if opt.start_with?('--')
    die("./executable: option '#{opt}' requires an argument")
  else
    die("./executable: option requires an argument -- '#{opt.delete_prefix('-')}'")
  end
end

def valid_integer?(value)
  value.match?(/\A[+-]?\d+\z/)
end

def parse_user(value)
  value = ENV['USER'] if value.nil? || value.empty?
  Etc.getpwnam(value)
  value
rescue ArgumentError
  if valid_integer?(value)
    begin
      Etc.getpwuid(value.to_i)
      return value
    rescue ArgumentError
      # fall through
    end
  end
  die(%(Error: invalid user "#{value}".))
end

def normalize_argv(argv)
  out = []
  takes_arg = %w[d F n p s u]
  argv.each do |arg|
    if arg.start_with?('-') && !arg.start_with?('--') && arg.length > 2
      chars = arg[1..].chars
      until chars.empty?
        flag = chars.shift
        out << "-#{flag}"
        if takes_arg.include?(flag)
          out << chars.join unless chars.empty?
          break
        end
      end
    else
      out << arg
    end
  end
  out
end

def parse_options(argv)
  argv = normalize_argv(argv)
  opts = Options.new(delay: 15, iterations: nil, pids: nil, sort_key: nil, no_meters: false)
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-h', '--help'
      print HELP
      exit 0
    when '-V', '--version'
      puts VERSION
      exit 0
    when '--sort-key=help'
      SORT_KEYS.each { |key, desc| puts format('%19s %s', key, desc) }
      exit 0
    when '-C', '--no-color', '--no-colour', '-M', '--no-mouse', '-U', '--no-unicode',
         '-t', '--tree', '--readonly', '--no-function-bar'
      # Display-only flags accepted for compatibility.
    when '--no-meters'
      opts.no_meters = true
    when '-d', '--delay'
      value = need_arg(argv, i, arg)
      die(%(Error: invalid delay value "#{value}".)) unless valid_integer?(value)
      opts.delay = [[value.to_i, 1].max, 100].min
      i += 1
    when /\A--delay=(.*)\z/
      value = Regexp.last_match(1)
      die(%(Error: invalid delay value "#{value}".)) unless valid_integer?(value)
      opts.delay = [[value.to_i, 1].max, 100].min
    when '-F', '--filter'
      opts.filter = need_arg(argv, i, arg)
      i += 1
    when /\A--filter=(.*)\z/
      opts.filter = Regexp.last_match(1)
    when '-n', '--max-iterations'
      value = need_arg(argv, i, arg)
      die(%(Error: invalid maximum iteration count "#{value}".)) unless valid_integer?(value)
      die('Error: maximum iteration count must be positive.') if value.to_i <= 0
      opts.iterations = value.to_i
      i += 1
    when /\A--max-iterations=(.*)\z/
      value = Regexp.last_match(1)
      die(%(Error: invalid maximum iteration count "#{value}".)) unless valid_integer?(value)
      die('Error: maximum iteration count must be positive.') if value.to_i <= 0
      opts.iterations = value.to_i
    when '-p', '--pid'
      opts.pids = need_arg(argv, i, arg).split(',')
      i += 1
    when /\A--pid=(.*)\z/
      opts.pids = Regexp.last_match(1).split(',')
    when '-s', '--sort-key'
      value = need_arg(argv, i, arg)
      if value == 'help'
        SORT_KEYS.each { |key, desc| puts format('%19s %s', key, desc) }
        exit 0
      end
      die(%(Error: invalid column "#{value}".)) unless VALID_SORT_KEYS.include?(value)
      opts.sort_key = value
      i += 1
    when /\A--sort-key=(.*)\z/
      value = Regexp.last_match(1)
      die(%(Error: invalid column "#{value}".)) unless VALID_SORT_KEYS.include?(value)
      opts.sort_key = value
    when '-u', '--user'
      if i + 1 < argv.length && !argv[i + 1].start_with?('-')
        opts.user = parse_user(argv[i + 1])
        i += 1
      else
        opts.user = parse_user(nil)
      end
    when /\A--user=(.*)\z/
      opts.user = parse_user(Regexp.last_match(1))
    when '-H', '--highlight-changes'
      # Optional delay; absent is accepted.
    when /\A--highlight-changes=(.*)\z/
      value = Regexp.last_match(1)
      die(%(Error: invalid highlight delay value "#{value}".)) unless valid_integer?(value)
    else
      if arg.start_with?('--')
        die("./executable: unrecognized option '#{arg.split('=', 2).first}'")
      elsif arg.start_with?('-') && arg.length > 1
        die("./executable: invalid option -- '#{arg[1]}'")
      end
    end
    i += 1
  end
  opts
end

def read_meminfo
  info = {}
  File.readlines('/proc/meminfo', chomp: true).each do |line|
    key, value = line.split(':', 2)
    info[key] = value.to_s.strip.split.first.to_i
  end
  info
rescue StandardError
  {}
end

def fmt_kb(kb)
  return '0K' if kb <= 0

  units = %w[K M G T]
  value = kb.to_f
  unit = units.shift
  while value >= 1024 && !units.empty?
    value /= 1024.0
    unit = units.shift
  end
  value >= 10 ? "#{value.round}#{unit}" : format('%.2g%s', value, unit)
end

def process_rows(opts)
  rows = []
  Dir.glob('/proc/[0-9]*').each do |dir|
    pid = File.basename(dir)
    next if opts.pids && !opts.pids.include?(pid)

    stat = File.read(File.join(dir, 'stat')).split
    status = File.readlines(File.join(dir, 'status'), chomp: true)
    uid = status.find { |l| l.start_with?('Uid:') }.to_s.split[1].to_i
    user = Etc.getpwuid(uid).name rescue uid.to_s
    next if opts.user && opts.user != user && opts.user != uid.to_s

    cmd = File.read(File.join(dir, 'cmdline')).tr("\0", ' ').strip
    cmd = File.read(File.join(dir, 'comm')).strip if cmd.empty?
    if opts.filter
      terms = opts.filter.downcase.split('|')
      next unless terms.any? { |term| cmd.downcase.include?(term) }
    end

    rows << {
      pid: pid.to_i,
      user: user[0, 10],
      pri: stat[17].to_i,
      nice: stat[18].to_i,
      virt: stat[22].to_i / 1024,
      res: status.find { |l| l.start_with?('VmRSS:') }.to_s.split[1].to_i,
      shr: status.find { |l| l.start_with?('RssFile:') }.to_s.split[1].to_i,
      state: stat[2],
      time: ((stat[13].to_i + stat[14].to_i) / 100).to_i,
      cmd: cmd
    }
  rescue StandardError
    next
  end
  rows.sort_by! { |r| opts.sort_key == 'PID' ? r[:pid] : -r[:res] }
  rows
end

def draw_frame(opts)
  mem = read_meminfo
  total = mem['MemTotal'].to_i
  available = mem['MemAvailable'].to_i
  used = [total - available, 0].max
  loadavg = File.read('/proc/loadavg').split.first(3).join(' ') rescue '0.00 0.00 0.00'
  uptime = File.read('/proc/uptime').split.first.to_f.to_i rescue 0
  rows = process_rows(opts)

  puts "htop 3.5.0-dev-878e0ce"
  unless opts.no_meters
    puts "  0[          0.0%]   1[          0.0%]"
    puts "Mem[#{fmt_kb(used)}/#{fmt_kb(total)}] Tasks: #{rows.length}, 0 thr, 0 kthr; #{rows.count { |r| r[:state] == 'R' }} running"
    puts "Swp[0K/0K] Load average: #{loadavg} Uptime: #{uptime / 86_400} days, #{Time.at(uptime).utc.strftime('%H:%M:%S')}"
    puts
  end
  puts '  PID USER       PRI  NI  VIRT   RES   SHR S  CPU%-MEM%   TIME+  Command'
  rows.first(20).each do |r|
    minutes = r[:time] / 60
    seconds = r[:time] % 60
    puts format('%5d %-10s %3d %3d %5s %5s %5s %s %5.1f %4.1f %2d:%05.2f %s',
                r[:pid], r[:user], r[:pri], r[:nice], fmt_kb(r[:virt]), fmt_kb(r[:res]),
                fmt_kb(r[:shr]), r[:state], 0.0, total.positive? ? (r[:res] * 100.0 / total) : 0.0,
                minutes, seconds.to_f, r[:cmd])
  end
  puts 'F1Help  F2Setup F3Search F4Filter F5Tree F6SortBy F7Nice - F8Nice + F9Kill F10Quit'
end

opts = parse_options(ARGV)

term = ENV['TERM']
if term.nil? || term.empty? || term == 'unknown'
  warn 'Error opening terminal: unknown.'
  exit 1
end

iterations = opts.iterations
count = 0
loop do
  draw_frame(opts)
  count += 1
  break if iterations && count >= iterations

  sleep(opts.delay / 10.0)
end
