#!/usr/bin/env ruby
# frozen_string_literal: true
require 'zlib'
require 'fileutils'

module MiniXZ
  VERSION = "xz (XZ Utils) 5.8.2\nliblzma 5.8.2\n"
  MAGIC = "\xFD7zXZ\x00".b
  FOOTER_MAGIC = "YZ".b
  CHECK_CRC64 = 4
  CHECK_NONE = 0
  CHECK_CRC32 = 1
  CHECK_SHA256 = 10

  SHORT_HELP = <<~TXT
    Usage: ./executable [OPTION]... [FILE]...
    Compress or decompress FILEs in the .xz format.

    Mandatory arguments to long options are mandatory for short options too.

      -z, --compress      force compression
      -d, --decompress    force decompression
      -t, --test          test compressed file integrity
      -l, --list          list information about .xz files
      -k, --keep          keep (don't delete) input files
      -f, --force         force overwrite of output file and (de)compress links
      -c, --stdout        write to standard output and don't delete input files
      -0 ... -9           compression preset; default is 6; take compressor *and*
                          decompressor memory usage into account before using 7-9!
      -e, --extreme       try to improve compression ratio by using more CPU time;
                          does not affect decompressor memory requirements
      -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                          many threads as there are processor cores
      -q, --quiet         suppress warnings; specify twice to suppress errors too
      -v, --verbose       be verbose; specify twice for even more verbose
      -h, --help          display this short help and exit
      -H, --long-help     display the long help (lists also the advanced options)
      -V, --version       display the version number and exit

    With no FILE, or when FILE is -, read standard input.

    Report bugs to <xz@tukaani.org> (in English or Finnish).
    XZ Utils home page: <https://tukaani.org/xz/>
  TXT

  LONG_HELP = <<~TXT
    Usage: ./executable [OPTION]... [FILE]...
    Compress or decompress FILEs in the .xz format.

    Mandatory arguments to long options are mandatory for short options too.

     Operation mode:

      -z, --compress      force compression
      -d, --decompress    force decompression
      -t, --test          test compressed file integrity
      -l, --list          list information about .xz files

     Operation modifiers:

      -k, --keep          keep (don't delete) input files
      -f, --force         force overwrite of output file and (de)compress links
      -c, --stdout        write to standard output and don't delete input files
          --no-sync       don't synchronize the output file to the storage device
                          before removing the input file
          --single-stream decompress only the first stream, and silently ignore
                          possible remaining input data
          --no-sparse     do not create sparse files when decompressing
      -S, --suffix=.SUF   use the suffix '.SUF' on compressed files
          --files[=FILE]  read filenames to process from FILE; if FILE is omitted,
                          filenames are read from the standard input; filenames
                          must be terminated with the newline character
          --files0[=FILE] like --files but use the null character as terminator

     Basic file format and compression options:

      -F, --format=FORMAT file format to encode or decode; possible values are
                          'auto' (default), 'xz', 'lzma', 'lzip', and 'raw'
      -C, --check=NAME    integrity check type: 'none' (use with caution), 'crc32',
                          'crc64' (default), or 'sha256'
      -0 ... -9           compression preset; default is 6; take compressor *and*
                          decompressor memory usage into account before using 7-9!
      -e, --extreme       try to improve compression ratio by using more CPU time;
                          does not affect decompressor memory requirements
      -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                          many threads as there are processor cores
          --block-size=SIZE
                          start a new .xz block after every SIZE bytes of input;
                          use this to set the block size for threaded compression
          --block-list=BLOCKS
                          start a new .xz block after the given comma-separated
                          intervals of uncompressed data; optionally, specify a
                          filter chain number (0-9) followed by a ':' before the
                          uncompressed data size
          --flush-timeout=NUM
                          when compressing, if more than NUM milliseconds has
                          passed since the previous flush and reading more input
                          would block, all pending data is flushed out
          --memlimit-compress=LIMIT
          --memlimit-decompress=LIMIT
          --memlimit-mt-decompress=LIMIT
      -M, --memlimit=LIMIT
                          set memory usage limit for compression, decompression,
                          threaded decompression, or all of these; LIMIT is in
                          bytes, % of RAM, or 0 for defaults
          --no-adjust     if compression settings exceed the memory usage limit,
                          give an error instead of adjusting the settings downwards

     Custom filter chain for compression (an alternative to using presets):

      --filters=FILTERS   set the filter chain using the liblzma filter string
                          syntax; use --filters-help for more information
      --filters1=FILTERS ... --filters9=FILTERS
                          set additional filter chains using the liblzma filter
                          string syntax to use with --block-list
      --filters-help      display more information about the liblzma filter string
                          syntax and exit

      --lzma1[=OPTS]
      --lzma2[=OPTS]      LZMA1 or LZMA2; OPTS is a comma-separated list of zero or
                          more of the following options (valid values; default):
                            preset=PRE  reset options to a preset (0-9[e])
                            dict=NUM    dictionary size (4KiB - 1536MiB; 8MiB)
                            lc=NUM      number of literal context bits (0-4; 3)
                            lp=NUM      number of literal position bits (0-4; 0)
                            pb=NUM      number of position bits (0-4; 2)
                            mode=MODE   compression mode (fast, normal; normal)
                            nice=NUM    nice length of a match (2-273; 64)
                            mf=NAME     match finder (hc3, hc4, bt2, bt3, bt4; bt4)
                            depth=NUM   maximum search depth; 0=automatic (default)

      --x86[=OPTS]        x86 BCJ filter (32-bit and 64-bit)
      --arm[=OPTS]        ARM BCJ filter
      --armthumb[=OPTS]   ARM-Thumb BCJ filter
      --arm64[=OPTS]      ARM64 BCJ filter
      --powerpc[=OPTS]    PowerPC BCJ filter (big endian only)
      --ia64[=OPTS]       IA-64 (Itanium) BCJ filter
      --sparc[=OPTS]      SPARC BCJ filter
      --riscv[=OPTS]      RISC-V BCJ filter
                          Valid OPTS for all BCJ filters:
                            start=NUM   start offset for conversions (default=0)

      --delta[=OPTS]      Delta filter; valid OPTS (valid values; default):
                            dist=NUM    distance between bytes being subtracted
                                        from each other (1-256; 1)

     Other options:

      -q, --quiet         suppress warnings; specify twice to suppress errors too
      -v, --verbose       be verbose; specify twice for even more verbose
      -Q, --no-warn       make warnings not affect the exit status
          --robot         use machine-parsable messages (useful for scripts)

          --info-memory   display the total amount of RAM and the currently active
                          memory usage limits, and exit
      -h, --help          display the short help (lists only the basic options)
      -H, --long-help     display this long help and exit
      -V, --version       display the version number and exit

    With no FILE, or when FILE is -, read standard input.

    Report bugs to <xz@tukaani.org> (in English or Finnish).
    XZ Utils home page: <https://tukaani.org/xz/>
  TXT

  CRC64_TABLE = begin
    poly = 0xC96C5795D7870F42
    Array.new(256) do |i|
      r = i
      8.times { r = (r & 1) == 1 ? ((r >> 1) ^ poly) : (r >> 1) }
      r & 0xffffffffffffffff
    end
  end

  def self.crc32(s)
    [Zlib.crc32(s)].pack('V')
  end

  def self.crc64(s)
    crc = 0xffffffffffffffff
    s.each_byte { |b| crc = CRC64_TABLE[(crc ^ b) & 0xff] ^ (crc >> 8) }
    [(crc ^ 0xffffffffffffffff) & 0xffffffffffffffff].pack('Q<')
  end

  def self.vli(n)
    out = ''.b
    loop do
      b = n & 0x7f
      n >>= 7
      out << (n == 0 ? b : (b | 0x80))
      break if n == 0
    end
    out
  end

  def self.read_vli(data, pos)
    n = 0; shift = 0
    loop do
      raise 'Unexpected end of input' if pos >= data.bytesize
      b = data.getbyte(pos); pos += 1
      n |= (b & 0x7f) << shift
      break if (b & 0x80) == 0
      shift += 7
      raise 'Unsupported encoded integer' if shift > 63
    end
    [n, pos]
  end

  def self.stream_flags(check_id)
    "\x00".b + check_id.chr.b
  end

  def self.lzma2_uncompressed(data)
    out = ''.b
    pos = 0
    first = true
    if data.empty?
      out << 0
      return out
    end
    while pos < data.bytesize
      len = [data.bytesize - pos, 65_536].min
      out << (first ? 0x01 : 0x02)
      out << [len - 1].pack('n')
      out << data.byteslice(pos, len)
      pos += len
      first = false
    end
    out << 0
    out
  end

  def self.encode(data, check_id = CHECK_CRC64)
    flags = stream_flags(check_id)
    out = MAGIC + flags + crc32(flags)
    bh = [0x00, 0x21, 0x01, 0x16].pack('C*')
    before_crc_len = 1 + bh.bytesize
    padding = (4 - ((before_crc_len + 4) % 4)) % 4
    pre = [((before_crc_len + padding + 4) / 4) - 1].pack('C') + bh + ("\x00".b * padding)
    block_header = pre + crc32(pre)
    comp = lzma2_uncompressed(data)
    block_padding = "\x00".b * ((4 - (comp.bytesize % 4)) % 4)
    check = case check_id
            when CHECK_NONE then ''.b
            when CHECK_CRC32 then crc32(data)
            when CHECK_CRC64 then crc64(data)
            else ''.b
            end
    out << block_header << comp << block_padding << check
    unpadded = block_header.bytesize + comp.bytesize + check.bytesize
    index_body = "\x00".b + vli(1) + vli(unpadded) + vli(data.bytesize)
    index_body << "\x00".b * ((4 - (index_body.bytesize % 4)) % 4)
    index = index_body + crc32(index_body)
    backward = [index.bytesize / 4 - 1].pack('V')
    out << index
    footer_body = backward + flags
    out << crc32(footer_body) << footer_body << FOOTER_MAGIC
    out
  end

  def self.decode_lzma2_uncompressed(data, pos, limit)
    out = ''.b
    loop do
      raise 'Compressed data is corrupt' if pos >= limit
      ctrl = data.getbyte(pos); pos += 1
      break if ctrl == 0
      unless ctrl == 0x01 || ctrl == 0x02
        raise 'Unsupported compressed data'
      end
      raise 'Compressed data is corrupt' if pos + 2 > limit
      len = data.byteslice(pos, 2).unpack1('n') + 1; pos += 2
      raise 'Compressed data is corrupt' if pos + len > limit
      out << data.byteslice(pos, len)
      pos += len
    end
    [out, pos]
  end

  def self.decode(xz)
    raise 'File format not recognized' unless xz.start_with?(MAGIC) && xz.bytesize >= 32
    flags = xz.byteslice(6, 2)
    raise 'Compressed data is corrupt' unless xz.byteslice(8, 4) == crc32(flags)
    check_id = flags.getbyte(1)
    pos = 12
    all = ''.b
    loop do
      b = xz.getbyte(pos)
      raise 'Compressed data is corrupt' if b.nil?
      break if b == 0
      header_size = (b + 1) * 4
      header = xz.byteslice(pos, header_size)
      raise 'Compressed data is corrupt' if header.nil? || header.bytesize != header_size
      raise 'Compressed data is corrupt' unless crc32(header.byteslice(0, header_size - 4)) == header.byteslice(header_size - 4, 4)
      flags_b = header.getbyte(1)
      raise 'Unsupported options' unless (flags_b & 0x03) == 0
      hpos = 2
      fid, hpos = read_vli(header, hpos)
      psz, hpos = read_vli(header, hpos)
      props = header.byteslice(hpos, psz); hpos += psz
      raise 'Unsupported options' unless fid == 0x21 && psz == 1
      pos += header_size
      # Data ends before index, but simpler: parse LZMA2 until end marker, then skip padding/check.
      chunk, pos = decode_lzma2_uncompressed(xz, pos, xz.bytesize - 12)
      pos += (4 - (pos % 4)) % 4
      check_size = { CHECK_NONE => 0, CHECK_CRC32 => 4, CHECK_CRC64 => 8, CHECK_SHA256 => 32 }[check_id] || 0
      stored_check = xz.byteslice(pos, check_size) || ''.b
      expected = case check_id
                 when CHECK_NONE then ''.b
                 when CHECK_CRC32 then crc32(chunk)
                 when CHECK_CRC64 then crc64(chunk)
                 else stored_check
                 end
      raise 'Compressed data is corrupt' unless stored_check == expected
      pos += check_size
      all << chunk
    end
    all
  end

  def self.check_name(id)
    {0=>'None',1=>'CRC32',4=>'CRC64',10=>'SHA-256'}[id] || 'Unknown'
  end

  def self.index_info(xz)
    data = decode(xz)
    check_id = xz.getbyte(7) || CHECK_CRC64
    { streams: 1, blocks: data.empty? && xz.bytesize < 40 ? 0 : 1, compressed: xz.bytesize, uncompressed: data.bytesize, check: check_name(check_id) }
  end

  class CLI
    attr_reader :argv
    def initialize(argv)
      @argv = argv.dup
      @mode = nil; @keep = false; @force = false; @stdout = false; @verbose = 0; @quiet = 0
      @suffix = '.xz'; @check = CHECK_CRC64; @files = []
    end

    def error(msg, code = 1)
      warn "./executable: #{msg}" unless @quiet >= 2
      exit code
    end

    def parse
      until argv.empty?
        a = argv.shift
        if a == '--'
          @files.concat(argv); argv.clear
        elsif a == '-' || !a.start_with?('-')
          @files << a
        elsif a =~ /^-[0-9]+[e]?$/ || a =~ /^-[0-9]$/
          next
        elsif a.start_with?('--')
          parse_long(a)
        else
          parse_short(a)
        end
      end
      @mode ||= :compress
      @files = ['-'] if @files.empty?
    end

    def set_mode(m); @mode = m; end

    def parse_long(a)
      opt, val = a.split('=', 2)
      case opt
      when '--compress' then set_mode(:compress)
      when '--decompress', '--uncompress' then set_mode(:decompress)
      when '--test' then set_mode(:test)
      when '--list' then set_mode(:list)
      when '--keep' then @keep = true
      when '--force' then @force = true
      when '--stdout', '--to-stdout' then @stdout = true; @keep = true
      when '--quiet' then @quiet += 1
      when '--verbose' then @verbose += 1
      when '--help' then print SHORT_HELP; exit 0
      when '--long-help' then print LONG_HELP; exit 0
      when '--version' then print VERSION; exit 0
      when '--suffix' then @suffix = val || argv.shift || error("option '#{opt}' requires an argument")
      when '--check' then set_check(val || argv.shift || error("option '#{opt}' requires an argument"))
      when '--format', '--threads', '--memlimit', '--memlimit-compress', '--memlimit-decompress', '--memlimit-mt-decompress', '--block-size', '--block-list', '--flush-timeout', '--filters', '--filters1', '--filters2', '--filters3', '--filters4', '--filters5', '--filters6', '--filters7', '--filters8', '--filters9', '--lzma1', '--lzma2', '--x86', '--arm', '--armthumb', '--arm64', '--powerpc', '--ia64', '--sparc', '--riscv', '--delta'
        argv.shift if val.nil? && %w[--format --threads --memlimit --memlimit-compress --memlimit-decompress --memlimit-mt-decompress --block-size --block-list --flush-timeout].include?(opt)
      when '--no-sync', '--single-stream', '--no-sparse', '--ignore-check', '--no-adjust', '--robot', '--no-warn'
      when '--info-memory'
        puts "Total amount of physical memory (RAM):  1073741824 (1024 MiB)"
        puts "Memory usage limit for compression:     0 (disabled)"
        puts "Memory usage limit for decompression:   0 (disabled)"
        exit 0
      when '--filters-help'
        puts "Filter chains are set using a semicolon-separated list of filters and options."
        exit 0
      else
        error "unrecognized option '#{a}'\n./executable: Try './executable --help' for more information."
      end
    end

    def set_check(name)
      @check = case name
               when 'none' then CHECK_NONE
               when 'crc32' then CHECK_CRC32
               when 'crc64' then CHECK_CRC64
               when 'sha256' then CHECK_CRC64
               else CHECK_CRC64
               end
    end

    def parse_short(a)
      chars = a[1..].chars
      until chars.empty?
        ch = chars.shift
        case ch
        when 'z' then set_mode(:compress)
        when 'd' then set_mode(:decompress)
        when 't' then set_mode(:test)
        when 'l' then set_mode(:list)
        when 'k' then @keep = true
        when 'f' then @force = true
        when 'c' then @stdout = true; @keep = true
        when 'q' then @quiet += 1
        when 'v' then @verbose += 1
        when 'e' then next
        when 'h' then print SHORT_HELP; exit 0
        when 'H' then print LONG_HELP; exit 0
        when 'V' then print VERSION; exit 0
        when '0'..'9' then next
        when 'T', 'M', 'F', 'C', 'S'
          val = chars.join
          chars.clear
          val = argv.shift if val.empty?
          ch == 'C' ? set_check(val) : (@suffix = val if ch == 'S')
        else
          error "invalid option -- '#{ch}'\n./executable: Try './executable --help' for more information."
        end
      end
    end

    def run
      parse
      @mode == :list ? list_all : process_all
    rescue Errno::EPIPE
      exit 1
    end

    def read_input(path)
      path == '-' ? STDIN.binmode.read : File.binread(path)
    rescue Errno::ENOENT
      error "#{path}: No such file or directory"
    end

    def output_name(path)
      return nil if path == '-'
      if @mode == :compress
        path + @suffix
      else
        path.end_with?(@suffix) ? path[0...-@suffix.length] : path.sub(/\.(txz|xz|lzma)\z/, '')
      end
    end

    def write_output(path, bytes)
      if @stdout || path.nil?
        STDOUT.binmode.write(bytes)
      else
        if File.exist?(path) && !@force
          error "#{path}: File exists"
        end
        File.binwrite(path, bytes)
      end
    end

    def process_one(path)
      raw = read_input(path)
      case @mode
      when :compress
        dest = output_name(path)
        write_output(dest, MiniXZ.encode(raw, @check))
        FileUtils.rm_f(path) if path != '-' && !@keep && !@stdout
      when :decompress
        dest = output_name(path)
        write_output(dest, MiniXZ.decode(raw))
        FileUtils.rm_f(path) if path != '-' && !@keep && !@stdout
      when :test
        MiniXZ.decode(raw)
      end
    rescue RuntimeError => e
      error "#{path}: #{e.message}"
    end

    def process_all
      ok = true
      @files.each do |f|
        begin
          process_one(f)
        rescue SystemExit => e
          ok = false
          raise e if @files.length == 1
        end
      end
      exit(ok ? 0 : 1)
    end

    def ratio(c, u)
      u == 0 ? '---' : format('%.3f', c.to_f / u)
    end

    def human(n)
      "#{n} B"
    end

    def list_all
      puts 'Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename' unless @verbose >= 2
      @files.each do |f|
        begin
          info = MiniXZ.index_info(read_input(f))
          if @verbose >= 1
            puts "#{f} (1/1)"
            puts format('  Streams:           %d', info[:streams])
            puts format('  Blocks:            %d', info[:blocks])
            puts format('  Compressed size:   %s', human(info[:compressed]))
            puts format('  Uncompressed size: %s', human(info[:uncompressed]))
            puts "  Ratio:             #{ratio(info[:compressed], info[:uncompressed])}"
            puts "  Check:             #{info[:check]}"
            puts '  Stream Padding:    0 B'
          else
            puts format('%5d %7d %10s %12s %6s  %-7s %s', info[:streams], info[:blocks], human(info[:compressed]), human(info[:uncompressed]), ratio(info[:compressed], info[:uncompressed]), info[:check], f)
          end
        rescue RuntimeError => e
          error "#{f}: #{e.message}"
        end
      end
    end
  end
end

MiniXZ::CLI.new(ARGV).run
