#!/usr/bin/env ruby
# frozen_string_literal: true

require 'open3'

HELP = <<~TEXT
  loop 0.6.1
  Rich Jones <miserlou@gmail.com>
  UNIX's missing `loop` command

  USAGE:
      executable [FLAGS] [OPTIONS] [input]...

  FLAGS:
      -D, --error-duration    Exit with timeout error code on duration
      -h, --help              Prints help information
      -l, --only-last         Only print the output of the last execution of the command
      -i, --stdin             Read from standard input
          --summary           Provide a summary
      -C, --until-changes     Keep going until the output changes
      -f, --until-fail        Keep going until the command exit status is non-zero
      -S, --until-same        Keep going until the output changes
      -s, --until-success     Keep going until the command exit status is zero
      -V, --version           Prints version information

  OPTIONS:
      -b, --count-by <count_by>                Amount to increment the counter by [default: 1]
      -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]
          --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue
      -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)
      -n, --num <num>                          Number of iterations to execute
      -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]
      -c, --until-contains <until_contains>    Keep going until the output contains this string
      -r, --until-error <until_error>          Keep going until the command exit status is the value given
      -m, --until-match <until_match>          Keep going until the output matches this regular expression
      -t, --until-time <until_time>            Keep going until a future time, ex. "2018-04-20 04:20:00" (Times in UTC.)

  ARGS:
      <input>...    The command to be looped
TEXT

VERSION = "loop 0.6.1\n"

def fail_parse(message)
  warn "error: #{message}"
  exit 1
end

def invalid_value(opt, val, reason)
  fail_parse("Invalid value for '#{opt} <#{val}>': #{reason}")
end

def require_value(args, i, opt, name)
  value = args[i + 1]
  fail_parse("The argument '#{opt} <#{name}>' requires a value but none was supplied") if value.nil?
  if value.start_with?('-')
    long = {
      '-b' => '--count-by', '-e' => '--every', '-d' => '--for-duration',
      '-n' => '--num', '-o' => '--offset', '-c' => '--until-contains',
      '-r' => '--until-error', '-m' => '--until-match', '-t' => '--until-time'
    }.fetch(opt, opt)
    fail_parse("Found argument '#{value}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable #{long} <#{name}>\n\nFor more information try --help")
  end
  value
end

def parse_int(value, opt, name)
  Integer(value)
rescue ArgumentError
  invalid_value(opt, name, 'invalid float literal')
end

def parse_duration(str, opt = nil, name = nil)
  i = 0
  total = 0.0
  units = {
    'h' => 3600.0,
    'm' => 60.0,
    's' => 1.0,
    'ms' => 0.001,
    'us' => 0.000001
  }
  while i < str.length
    start = i
    i += 1 while i < str.length && str[i] =~ /[0-9.]/
    if start == i
      reason = "expected number at #{i}"
      opt ? invalid_value(opt, name, reason) : raise(ArgumentError, reason)
    end
    number = str[start...i]
    begin
      amount = Float(number)
    rescue ArgumentError
      reason = "invalid float literal"
      opt ? invalid_value(opt, name, reason) : raise(ArgumentError, reason)
    end

    unit = nil
    %w[ms us h m s].each do |candidate|
      if str[i, candidate.length] == candidate
        unit = candidate
        i += candidate.length
        break
      end
    end
    unless unit
      reason = "expected unit at #{i}"
      opt ? invalid_value(opt, name, reason) : raise(ArgumentError, reason)
    end
    total += amount * units.fetch(unit)
  end
  total
end

def parse_utc_time(value)
  match = value.match(/\A(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})\z/)
  raise ArgumentError, 'invalid time' unless match

  Time.utc(*match.captures.map(&:to_i))
end

def normalize_argv(argv)
  takes_value = %w[b e d n o c r m t]
  out = []
  passthrough = false
  argv.each do |arg|
    if passthrough
      out << arg
    elsif arg == '--'
      out << arg
      passthrough = true
    elsif arg.start_with?('--') && arg.include?('=')
      key, value = arg.split('=', 2)
      out << key << value
    elsif arg.start_with?('-') && !arg.start_with?('--') && arg.length > 2
      chars = arg[1..].chars
      until chars.empty?
        ch = chars.shift
        out << "-#{ch}"
        if takes_value.include?(ch)
          out << chars.join unless chars.empty?
          chars.clear
        end
      end
    else
      out << arg
    end
  end
  out
end

opts = {
  count_by: 1,
  every: 0.000001,
  offset: 0,
  stdin: false,
  only_last: false,
  summary: false,
  error_duration: false
}

input = []
args = normalize_argv(ARGV)
i = 0
while i < args.length
  arg = args[i]
  if arg == '--'
    input = args[(i + 1)..] || []
    break
  elsif arg == '-h' || arg == '--help'
    print HELP
    exit 0
  elsif arg == '-V' || arg == '--version'
    print VERSION
    exit 0
  elsif arg == '-D' || arg == '--error-duration'
    opts[:error_duration] = true
  elsif arg == '-l' || arg == '--only-last'
    opts[:only_last] = true
  elsif arg == '-i' || arg == '--stdin'
    opts[:stdin] = true
  elsif arg == '--summary'
    opts[:summary] = true
  elsif arg == '-C' || arg == '--until-changes'
    opts[:until_changes] = true
  elsif arg == '-S' || arg == '--until-same'
    opts[:until_same] = true
  elsif arg == '-f' || arg == '--until-fail'
    opts[:until_fail] = true
  elsif arg == '-s' || arg == '--until-success'
    opts[:until_success] = true
  elsif arg == '-b' || arg == '--count-by'
    value = require_value(args, i, arg, 'count_by')
    opts[:count_by] = parse_int(value, arg, 'count_by')
    i += 1
  elsif arg == '-e' || arg == '--every'
    value = require_value(args, i, arg, 'every')
    opts[:every] = parse_duration(value, arg, 'every')
    i += 1
  elsif arg == '--for'
    value = require_value(args, i, arg, 'ffor')
    opts[:for] = value.empty? ? [''] : value.split(',', -1)
    i += 1
  elsif arg == '-d' || arg == '--for-duration'
    value = require_value(args, i, arg, 'for_duration')
    opts[:for_duration] = parse_duration(value, arg, 'for_duration')
    i += 1
  elsif arg == '-n' || arg == '--num'
    value = require_value(args, i, arg, 'num')
    opts[:num] = parse_int(value, arg, 'num')
    i += 1
  elsif arg == '-o' || arg == '--offset'
    value = require_value(args, i, arg, 'offset')
    opts[:offset] = parse_int(value, arg, 'offset')
    i += 1
  elsif arg == '-c' || arg == '--until-contains'
    opts[:until_contains] = require_value(args, i, arg, 'until_contains')
    i += 1
  elsif arg == '-r' || arg == '--until-error'
    value = require_value(args, i, arg, 'until_error')
    opts[:until_error] = parse_int(value, arg, 'until_error')
    i += 1
  elsif arg == '-m' || arg == '--until-match'
    value = require_value(args, i, arg, 'until_match')
    begin
      opts[:until_match] = Regexp.new(value)
    rescue RegexpError => e
      invalid_value(arg, 'until_match', e.message)
    end
    i += 1
  elsif arg == '-t' || arg == '--until-time'
    value = require_value(args, i, arg, 'until_time')
    begin
      opts[:until_time] = parse_utc_time(value)
    rescue ArgumentError
      invalid_value(arg, 'until_time', 'timestamp format is invalid')
    end
    i += 1
  elsif arg.start_with?('-')
    fail_parse("Found argument '#{arg}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input]...\n\nFor more information try --help")
  else
    input = args[i..]
    break
  end
  i += 1
end

if input.empty?
  puts 'No command supplied, exiting.'
  exit 0
end

command = input.join(' ')

items = nil
if opts[:for]
  items = opts[:for]
elsif !STDIN.tty?
  data = STDIN.read
  items = data.lines.map { |line| line.chomp } unless data.empty?
end

start_time = Time.now
count = opts[:offset]
runs = 0
successes = 0
failures = []
last_output = nil
previous_output = nil
exit_code = 0

loop do
  if opts[:num] && runs >= opts[:num]
    break
  end
  if opts[:for_duration] && runs.positive? && (Time.now - start_time) >= opts[:for_duration]
    exit_code = 124 if opts[:error_duration]
    break
  end
  break if opts[:until_time] && Time.now.utc >= opts[:until_time]
  break if items && !opts[:num] && runs >= items.length

  item = if items
           index = [runs, items.length - 1].min
           items[index] || ''
         else
           ''
         end

  env = { 'COUNT' => count.to_s, 'ITEM' => item.to_s }
  output, status = Open3.capture2e(env, command)
  code = status.exitstatus || 1

  runs += 1
  successes += 1 if code.zero?
  failures << code unless code.zero?
  last_output = output
  print output unless opts[:only_last] || opts[:summary]

  should_stop = false
  should_stop ||= code.zero? if opts[:until_success]
  should_stop ||= !code.zero? if opts[:until_fail]
  should_stop ||= code == opts[:until_error] if opts.key?(:until_error)
  should_stop ||= output.include?(opts[:until_contains]) if opts[:until_contains]
  should_stop ||= !!(output =~ opts[:until_match]) if opts[:until_match]
  should_stop ||= !previous_output.nil? && output != previous_output if opts[:until_changes]
  should_stop ||= !previous_output.nil? && output == previous_output if opts[:until_same]

  previous_output = output
  count += opts[:count_by]

  break if should_stop

  if opts[:for_duration] && (Time.now - start_time) >= opts[:for_duration]
    exit_code = 124 if opts[:error_duration]
    break
  end
  sleep opts[:every] if opts[:every].positive?
end

print last_output if opts[:only_last] && last_output

if opts[:summary]
  puts "Total runs:\t#{runs}"
  puts "Successes:\t#{successes}"
  print "Failures:\t#{failures.length}"
  print " (#{failures.join(', ')})" unless failures.empty?
  print "\n"
end

exit exit_code
