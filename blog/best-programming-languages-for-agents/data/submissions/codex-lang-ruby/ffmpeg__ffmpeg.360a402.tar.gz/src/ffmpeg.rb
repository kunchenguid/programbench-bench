#!/usr/bin/env ruby
# frozen_string_literal: true

require "digest"

VERSION = "ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers"
BUILD = [
  "  built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)",
  "  configuration: --disable-ffplay --disable-ffprobe",
  "  libavutil      60. 25.100 / 60. 25.100",
  "  libavcodec     62. 23.103 / 62. 23.103",
  "  libavformat    62.  9.101 / 62.  9.101",
  "  libavdevice    62.  2.100 / 62.  2.100",
  "  libavfilter    11. 12.100 / 11. 12.100",
  "  libswscale      9.  3.100 /  9.  3.100",
  "  libswresample   6.  2.100 /  6.  2.100"
].freeze
BUILD_NO_INDENT = BUILD.map { |s| s.sub(/^  /, "") }.freeze

HELP = <<~TEXT
  Universal media converter
  usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...

  Getting help:
      -h      -- print basic options
      -h long -- print more options
      -h full -- print all options (including all format and codec specific options, very long)
      -h type=name -- print all options for the named decoder/encoder/demuxer/muxer/filter/bsf/protocol
      See man ffmpeg for detailed description of the options.

  Per-stream options can be followed by :<stream_spec> to apply that option to specific streams only. <stream_spec> can be a stream index, or v/a/s for video/audio/subtitle (see manual for full syntax).

  Print help / information / capabilities:
  -L                  show license
  -license            show license
  -h <topic>          show help
  -version            show version
  -muxers             show available muxers
  -demuxers           show available demuxers
  -devices            show available devices
  -decoders           show available decoders
  -encoders           show available encoders
  -filters            show available filters
  -pix_fmts           show available pixel formats
  -layouts            show standard channel layouts
  -sample_fmts        show available audio sample formats

  Global options (affect whole program instead of just one file):
  -v <loglevel>       set logging level
  -y                  overwrite output files
  -n                  never overwrite output files
  -print_graphs       print execution graph data to stderr
  -print_graphs_file <filename>  write execution graph data to the specified file
  -print_graphs_format <format>  set the output printing format (available formats are: default, compact, csv, flat, ini, json, xml, mermaid, mermaidhtml)
  -stats              print progress report during encoding

  Per-file options (input and output):
  -f <fmt>            force container format (auto-detected otherwise)
  -t <duration>       stop transcoding after specified duration
  -to <time_stop>     stop transcoding after specified time is reached
  -ss <time_off>      start transcoding at specified time


  Per-file options (output-only):
  -metadata[:<spec>] <key=value>  add metadata

  Per-stream options:
  -c[:<stream_spec>] <codec>  select encoder/decoder ('copy' to copy stream without reencoding)
  -filter[:<stream_spec>] <filter_graph>  apply specified filters to audio/video

  Video options:
  -r[:<stream_spec>] <rate>  override input framerate/convert to given output framerate (Hz value, fraction or abbreviation)
  -aspect[:<stream_spec>] <aspect>  set aspect ratio (4:3, 16:9 or 1.3333, 1.7777)
  -vn                 disable video
  -vcodec <codec>     alias for -c:v (select encoder/decoder for video streams)
  -vf <filter_graph>  alias for -filter:v (apply filters to video streams)
  -b <bitrate>        video bitrate (please use -b:v)

  Audio options:
  -aq <quality>       set audio quality (codec-specific)
  -ar[:<stream_spec>] <rate>  set audio sampling rate (in Hz)
  -ac[:<stream_spec>] <channels>  set number of audio channels
  -an                 disable audio
  -acodec <codec>     alias for -c:a (select encoder/decoder for audio streams)
  -ab <bitrate>       alias for -b:a (select bitrate for audio streams)
  -af <filter_graph>  alias for -filter:a (apply filters to audio streams)

  Subtitle options:
  -sn                 disable subtitle
  -scodec <codec>     alias for -c:s (select encoder/decoder for subtitle streams)


TEXT

FORMATS = [
  ["D  ", "3dostr", "3DO STR"], [" E ", "3g2", "3GP2 (3GPP2 file format)"],
  [" E ", "3gp", "3GP (3GPP file format)"], ["D  ", "aac", "raw ADTS AAC (Advanced Audio Coding)"],
  ["DE ", "ac3", "raw AC-3"], ["DE ", "aiff", "Audio IFF"], ["DE ", "apng", "Animated Portable Network Graphics"],
  ["DE ", "ass", "SSA (SubStation Alpha) subtitle"], ["DE ", "au", "Sun AU"], ["DE ", "avi", "AVI (Audio Video Interleaved)"],
  ["DE ", "caf", "Apple CAF (Core Audio Format)"], ["DE ", "flac", "raw FLAC"], ["DE ", "flv", "FLV (Flash Video)"],
  ["DE ", "gif", "CompuServe Graphics Interchange Format (GIF)"], ["DE ", "h264", "raw H.264 video"],
  ["DE ", "image2", "image2 sequence"], ["D  ", "lavfi", "Libavfilter virtual input device"],
  ["DE ", "matroska,webm", "Matroska / WebM"], [" E ", "md5", "MD5 testing"], [" E ", "null", "raw null video"],
  ["DE ", "mp3", "MP2/3 (MPEG audio layer 2/3)"], [" E ", "mp4", "MP4 (MPEG-4 Part 14)"],
  ["DE ", "mpeg", "MPEG-PS (MPEG-2 Program Stream)"], ["DE ", "ogg", "Ogg"], ["DE ", "s16le", "PCM signed 16-bit little-endian"],
  ["DE ", "wav", "WAV / WAVE (Waveform Audio)"], ["DE ", "yuv4mpegpipe", "YUV4MPEG pipe"]
].freeze

ENCODERS = [
  ["V....D", "bmp", "BMP (Windows and OS/2 bitmap)"], ["V....D", "gif", "GIF (Graphics Interchange Format)"],
  ["V....D", "mjpeg", "MJPEG (Motion JPEG)"], ["V....D", "png", "PNG (Portable Network Graphics) image"],
  ["V....D", "ppm", "PPM (Portable PixelMap) image"], ["A....D", "flac", "FLAC (Free Lossless Audio Codec)"],
  ["A....D", "mp3", "MP3 (MPEG audio layer 3)"], ["A....D", "pcm_s16le", "PCM signed 16-bit little-endian"],
  ["A....D", "pcm_u8", "PCM unsigned 8-bit"], ["S.....", "ass", "ASS (Advanced SSA) subtitle"]
].freeze
DECODERS = ENCODERS + [["V....D", "h264", "H.264 / AVC / MPEG-4 AVC / MPEG-4 part 10"], ["A....D", "aac", "AAC (Advanced Audio Coding)"]]
FILTERS = [
  ["TS", "aap", "A->A", "Apply Affine Projection algorithm to first audio stream."],
  ["..", "acopy", "A->A", "Copy the input audio unchanged to the output."],
  ["T.", "adelay", "A->A", "Delay one or more audio channels."],
  ["..", "anull", "A->A", "Pass the source unchanged to the output."],
  ["..", "anullsrc", "|->A", "Null audio source, return empty audio frames."],
  ["..", "sine", "|->A", "Generate sine wave audio signal."],
  ["..", "testsrc", "|->V", "Generate test pattern."],
  ["..", "scale", "V->V", "Scale the input video size and/or convert the image format."],
  ["..", "null", "V->V", "Pass the source unchanged to the output."]
].freeze

def banner(io = $stdout, no_indent: false)
  io.puts VERSION
  (no_indent ? BUILD_NO_INDENT : BUILD).each { |l| io.puts l }
end

def license_text
  <<~TEXT
    ffmpeg is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    ffmpeg is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with ffmpeg; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
  TEXT
end

def parse_duration(v)
  return 0.0 if v.nil? || v.empty?
  return v.to_f if v =~ /\A\d+(\.\d+)?\z/
  if v =~ /\A(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)\z/
    (($1 || 0).to_f * 3600) + ($2.to_f * 60) + $3.to_f
  else
    v.to_f
  end
end

def lavfi_params(s)
  name, rest = s.split("=", 2)
  params = {}
  (rest || "").split(":").each do |part|
    k, v = part.split("=", 2)
    if v
      params[k] = v
    elsif part.include?("x")
      params["size"] = part
    end
  end
  [name, params]
end

def wav_bytes(samples, rate, channels)
  data_size = samples.bytesize
  +"RIFF".b +
    [36 + data_size].pack("V") +
    "WAVEfmt ".b +
    [16, 1, channels, rate, rate * channels * 2, channels * 2, 16].pack("VvvVVvv") +
    "data".b +
    [data_size].pack("V") +
    samples
end

def write_wav(path, samples, rate, channels)
  write_bytes(path, wav_bytes(samples, rate, channels))
end

def write_bytes(path, bytes)
  if path == "-"
    $stdout.binmode
    $stdout.write(bytes)
  else
    File.binwrite(path, bytes)
  end
end

def write_muxed(path, fmt, bytes, rate = 44_100, channels = 1)
  case fmt
  when "wav"
    write_bytes(path, wav_bytes(bytes, rate, channels))
  when "md5"
    line = "MD5=#{Digest::MD5.hexdigest(bytes)}\n"
    write_bytes(path, line)
  else
    write_bytes(path, bytes)
  end
end

def sine_samples(duration, rate, channels, freq)
  frames = (duration * rate).round
  amp = 4095
  out = +"".b
  frames.times do |i|
    sample = (Math.sin(2.0 * Math::PI * freq * i / rate) * amp).round
    channels.times { out << [sample].pack("s<") }
  end
  out
end

def silence_samples(duration, rate, channels)
  "\x00\x00".b * (duration * rate).round * channels
end

def write_ppm(path, width, height)
  data = +"P6\n#{width} #{height}\n255\n".b
  height.times do |y|
    width.times do |x|
      r = (255 * x / [width - 1, 1].max)
      g = (255 * y / [height - 1, 1].max)
      b = ((x / 8 + y / 8).even? ? 255 : 0)
      data << r.chr << g.chr << b.chr
    end
  end
  File.binwrite(path, data)
end

def wav_info(path)
  bytes = File.binread(path, 64)
  return nil unless bytes&.start_with?("RIFF") && bytes[8, 4] == "WAVE"
  idx = File.binread(path).index("data")
  size = idx ? File.binread(path)[idx + 4, 4].unpack1("V") : [File.size(path) - 44, 0].max
  rate = bytes[24, 4]&.unpack1("V") || 44_100
  channels = bytes[22, 2]&.unpack1("v") || 1
  bits = bytes[34, 2]&.unpack1("v") || 16
  duration = size.to_f / (rate * channels * (bits / 8.0))
  [duration, rate, channels, bits, size]
rescue StandardError
  nil
end

def show_formats(mode)
  puts "Formats:"
  puts " D.. = Demuxing supported"
  puts " .E. = Muxing supported"
  puts " ..d = Is a device"
  puts " ---"
  FORMATS.each do |flags, name, desc|
    next if mode == :muxers && flags[1] != "E"
    next if mode == :demuxers && flags[0] != "D"
    puts " #{flags} #{name.ljust(15)} #{desc}"
  end
end

def show_codecs(kind)
  rows = kind == :decoders ? DECODERS : ENCODERS
  puts(kind == :decoders ? "Decoders:" : "Encoders:")
  puts " V..... = Video"
  puts " A..... = Audio"
  puts " S..... = Subtitle"
  puts " .F.... = Frame-level multithreading"
  puts " ..S... = Slice-level multithreading"
  puts " ...X.. = Codec is experimental"
  puts " ....B. = Supports draw_horiz_band"
  puts " .....D = Supports direct rendering method 1"
  puts " ------"
  rows.each { |f, n, d| puts " #{f} #{n.ljust(20)} #{d}" }
end

def show_filters
  puts "Filters:"
  puts "  T.. = Timeline support"
  puts "  .S. = Slice threading"
  puts "  A = Audio input/output"
  puts "  V = Video input/output"
  puts "  N = Dynamic number and/or type of input/output"
  puts "  | = Source or sink filter"
  puts "  ------"
  FILTERS.each { |f, n, io, d| puts " #{f} #{n.ljust(17)} #{io.ljust(10)} #{d}" }
end

def info_command(args)
  return :none if args.empty?
  flag = args.find { |a| a.start_with?("-") && !%w[-hide_banner -y -n -stats].include?(a) }
  case flag
  when "-version"
    banner($stdout, no_indent: true)
    puts
    puts "Exiting with exit code 0"
  when "-L", "-license"
    banner
    print license_text
  when "-h", "--help", "-help", "-?"
    topic = args[args.index(flag) + 1]
    if topic&.include?("muxer=wav")
      puts "Muxer wav [WAV / WAVE (Waveform Audio)]:"
      puts "    Common extensions: wav."
      puts "    Mime type: audio/x-wav."
      puts "    Default audio codec: pcm_s16le."
      puts "WAV muxer AVOptions:"
      puts "  -write_bext        <boolean>    E.......... Write BEXT chunk. (default false)"
      puts "  -rf64              <int>        E.......... Use RF64 header rather than RIFF for large files. (from -1 to 1) (default never)"
      puts
      puts "Exiting with exit code 0"
    else
      banner unless args.include?("-hide_banner")
      print HELP
      puts
      puts "Exiting with exit code 0"
    end
  when "-formats" then show_formats(:all)
  when "-muxers" then show_formats(:muxers)
  when "-demuxers" then show_formats(:demuxers)
  when "-encoders" then show_codecs(:encoders)
  when "-decoders" then show_codecs(:decoders)
  when "-codecs" then show_codecs(:decoders)
  when "-filters" then show_filters
  when "-pix_fmts"
    puts "Pixel formats:"
    puts "I.... = Supported Input  format for conversion"
    puts ".O... = Supported Output format for conversion"
    puts "FLAGS NAME            NB_COMPONENTS BITS_PER_PIXEL BIT_DEPTHS"
    puts "-----"
    %w[yuv420p yuyv422 rgb24 bgr24 yuv422p yuv444p gray pal8 rgba bgra].each_with_index { |n, i| puts "IO... #{n.ljust(20)} #{i == 6 ? 1 : 3}             #{i == 6 ? 8 : 24}      8" }
  when "-sample_fmts"
    puts "name   depth"
    %w[u8:8 s16:16 s32:32 flt:32 dbl:64 u8p:8 s16p:16 s32p:32 fltp:32 dblp:64 s64:64 s64p:64].each { |x| n, d = x.split(":"); puts "#{n.ljust(6)} #{d.rjust(5)} " }
  when "-layouts"
    puts "Individual channels:"
    puts "NAME           DESCRIPTION"
    [["FL", "front left"], ["FR", "front right"], ["FC", "front center"], ["LFE", "low frequency"], ["BL", "back left"], ["BR", "back right"], ["SL", "side left"], ["SR", "side right"]].each { |n, d| puts "#{n.ljust(14)} #{d}" }
    puts "\nStandard channel layouts:"
    [["mono", "FC"], ["stereo", "FL+FR"], ["2.1", "FL+FR+LFE"], ["5.1", "FL+FR+FC+LFE+BL+BR"]].each { |n, d| puts "#{n.ljust(14)} #{d}" }
  when "-devices"
    puts "Devices:"
    puts " D. = Demuxing supported"
    puts " .E = Muxing supported"
    puts " ---"
    puts " DE fbdev           Linux framebuffer"
    puts " D  lavfi           Libavfilter virtual input device"
    puts " DE oss             OSS (Open Sound System) playback"
    puts " DE video4linux2,v4l2 Video4Linux2 output device"
  else
    return :none
  end
  :handled
end

def known_option_with_value?(opt)
  base = opt.sub(/:.*/, "")
  %w[-v -loglevel -f -i -t -to -ss -ar -ac -r -aspect -vcodec -acodec -scodec -ab -b -aq -c -codec -filter -vf -af -metadata -map -frames -frames:v -frames:a -print_graphs_file -print_graphs_format].include?(base) ||
    base.start_with?("-c") || base.start_with?("-filter") || base.start_with?("-metadata")
end

def parse_cli(args)
  opts = { y: false, n: false, fmt: nil, inputs: [], outputs: [], duration: nil, rate: nil, channels: nil, codec: nil, frames: nil }
  i = 0
  while i < args.length
    a = args[i]
    case a
    when "-hide_banner", "-stats", "-nostats", "-vn", "-an", "-sn"
    when "-y" then opts[:y] = true
    when "-n" then opts[:n] = true
    when "-f" then i += 1; opts[:fmt] = args[i]
    when "-i" then i += 1; opts[:inputs] << { fmt: opts[:fmt], src: args[i] }; opts[:fmt] = nil
    when "-t", "-to" then i += 1; opts[:duration] = parse_duration(args[i])
    when "-ar" then i += 1; opts[:rate] = args[i].to_i
    when "-ac" then i += 1; opts[:channels] = args[i].to_i
    when "-c", "-codec", "-acodec", "-vcodec" then i += 1; opts[:codec] = args[i]
    when "-frames:v", "-frames" then i += 1; opts[:frames] = args[i].to_i
    else
      if a == "-"
        opts[:outputs] << a
      elsif a.start_with?("-")
        if known_option_with_value?(a)
          i += 1
        else
          raise ArgumentError, a.sub(/^-+/, "")
        end
      else
        opts[:outputs] << a
      end
    end
    i += 1
  end
  opts
end

def output_format(path, forced)
  return forced if forced
  ext = File.extname(path).downcase.delete_prefix(".")
  return "image2" if %w[ppm pgm pbm].include?(ext)
  return "wav" if ext == "wav"
  return "md5" if ext == "md5"
  ext.empty? ? "unknown" : ext
end

def run_transcode(args)
  opts = parse_cli(args)
  if opts[:outputs].empty?
    warn "At least one output file must be specified"
    return 1
  end
  out = opts[:outputs].last
  input = opts[:inputs].first
  if input && input[:src] && input[:fmt] != "lavfi" && !File.exist?(input[:src])
    warn "#{input[:src]}: No such file or directory"
    return 1
  end

  if out != "-" && File.exist?(out) && !opts[:y]
    warn "File '#{out}' already exists. Exiting."
    return 1
  end

  fmt = output_format(out, opts[:fmt])
  duration = opts[:duration] || 1.0
  rate = opts[:rate] || 44_100
  channels = opts[:channels] || 1

  if fmt == "null" || (out == "-" && opts[:fmt].nil?)
    return 0
  end

  if input && input[:fmt] == "lavfi"
    name, params = lavfi_params(input[:src])
    duration = parse_duration(params["duration"] || params["d"]) if params["duration"] || params["d"]
    if name == "sine"
      rate = (params["sample_rate"] || params["r"] || rate).to_i
      freq = (params["frequency"] || params["f"] || 440).to_f
      write_muxed(out, fmt, sine_samples(duration, rate, channels, freq), rate, channels)
    elsif name == "anullsrc" || name == "aevalsrc"
      rate = (params["r"] || params["sample_rate"] || rate).to_i
      channels = 2 if params["cl"] == "stereo"
      write_muxed(out, fmt, silence_samples(duration, rate, channels), rate, channels)
    elsif name == "testsrc" || name == "testsrc2" || name == "color"
      size = params["size"] || params["s"] || "320x240"
      w, h = size.split("x").map(&:to_i)
      write_ppm(out, w.positive? ? w : 320, h.positive? ? h : 240)
    else
      warn "No such filter: '#{name}'"
      return 1
    end
    return 0
  end

  if input && input[:src] && input[:fmt] != "lavfi" && !File.exist?(input[:src])
    warn "#{input[:src]}: No such file or directory"
    return 1
  end

  if input && input[:src] && File.file?(input[:src])
    if opts[:codec] == "copy" || fmt != "wav"
      bytes = File.binread(input[:src])
      fmt == "md5" ? write_muxed(out, fmt, bytes) : write_bytes(out, bytes)
      return 0
    end
    info = wav_info(input[:src])
    if info && fmt == "wav"
      data = File.binread(input[:src])
      idx = data.index("data")
      pcm = idx ? data[(idx + 8)..] : data
      write_wav(out, pcm, opts[:rate] || info[1], opts[:channels] || info[2])
      return 0
    end
  end

  warn "#{input ? input[:src] : out}: Invalid data found when processing input"
  1
rescue ArgumentError => e
  banner($stderr) unless ARGV.include?("-hide_banner")
  warn "Unrecognized option '#{e.message}'."
  warn "Error splitting the argument list: Option not found"
  8
end

args = ARGV.dup
quiet = args.each_with_index.any? { |a, i| %w[-v -loglevel].include?(a) && %w[quiet -8].include?(args[i + 1]) }

if args.empty?
  banner
  puts HELP.lines.first(2).join
  puts "Use -h to get full help or, even better, run 'man ffmpeg'"
  exit 0
end

handled = info_command(args)
exit 0 if handled == :handled

code = run_transcode(args)
exit code if quiet
exit code
