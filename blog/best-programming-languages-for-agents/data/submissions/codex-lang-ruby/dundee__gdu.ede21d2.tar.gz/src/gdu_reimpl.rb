#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require 'yaml'
require 'time'
require 'shellwords'

NPROC = begin
  n = `nproc 2>/dev/null`.to_i
  n > 0 ? n : 8
rescue
  8
end

HELP = <<~TEXT
Pretty fast disk usage analyzer written in Go.

Gdu is intended primarily for SSD disks where it can fully utilize parallel processing.
However HDDs work as well, but the performance gain is not so huge.

Usage:
  gdu [directory_to_scan] [flags]

Flags:
      --archive-browsing              Enable browsing of zip/jar archives
      --collapse-path                 Collapse single-child directory chains
      --config-file string            Read config from file (default is $HOME/.gdu.yaml)
  -D, --db string                     Store analysis in database (*.sqlite for SQLite, *.badger for BadgerDB)
      --depth int                     Show directory structure up to specified depth in non-interactive mode (0 means the flag is ignored)
      --enable-profiling              Enable collection of profiling data and provide it on http://localhost:6060/debug/pprof/
  -E, --exclude-type strings          File types to exclude (e.g., --exclude-type yaml,json)
  -L, --follow-symlinks               Follow symlinks for files, i.e. show the size of the file to which symlink points to (symlinks to directories are not followed)
  -h, --help                          help for gdu
  -i, --ignore-dirs strings           Paths to ignore (separated by comma). Can be absolute or relative to current directory (default [/proc,/dev,/sys,/run])
  -I, --ignore-dirs-pattern strings   Path patterns to ignore (separated by comma)
  -X, --ignore-from string            Read path patterns to ignore from file
  -f, --input-file string             Import analysis from JSON file
  -l, --log-file string               Path to a logfile (default "/dev/null")
      --max-age string                Include files with mtime no older than DURATION (e.g., 7d, 2h30m, 1y2mo)
  -m, --max-cores int                 Set max cores that Gdu will use. #{NPROC} cores available (default #{NPROC})
      --min-age string                Include files with mtime at least DURATION old (e.g., 30d, 1w)
      --mouse                         Use mouse
  -c, --no-color                      Do not use colorized output
  -x, --no-cross                      Do not cross filesystem boundaries
      --no-delete                     Do not allow deletions
  -H, --no-hidden                     Ignore hidden directories (beginning with dot)
      --no-prefix                     Show sizes as raw numbers without any prefixes (SI or binary) in non-interactive mode
  -p, --no-progress                   Do not show progress in non-interactive mode
      --no-spawn-shell                Do not allow spawning shell
  -u, --no-unicode                    Do not use Unicode symbols (for size bar)
  -n, --non-interactive               Do not run in interactive mode
  -o, --output-file string            Export all info into file as JSON
  -r, --read-from-storage             Use existing database instead of re-scanning
      --reverse-sort                  Reverse sorting order (smallest to largest) in non-interactive mode
      --sequential                    Use sequential scanning (intended for rotating HDDs)
  -A, --show-annexed-size             Use apparent size of git-annex'ed files in case files are not present locally (real usage is zero)
  -a, --show-apparent-size            Show apparent size
  -d, --show-disks                    Show all mounted disks
  -k, --show-in-kib                   Show sizes in KiB (or kB with --si) in non-interactive mode
  -C, --show-item-count               Show number of items in directory
  -M, --show-mtime                    Show latest mtime of items in directory
  -B, --show-relative-size            Show relative size
      --si                            Show sizes with decimal SI prefixes (kB, MB, GB) instead of binary prefixes (KiB, MiB, GiB)
      --since string                  Include files with mtime >= WHEN. WHEN accepts RFC3339 timestamp (e.g., 2025-08-11T01:00:00-07:00) or date only YYYY-MM-DD (calendar-day compare; includes the whole day)
  -s, --summarize                     Show only a total in non-interactive mode
  -t, --top int                       Show only top X largest files in non-interactive mode
  -T, --type strings                  File types to include (e.g., --type yaml,json)
      --until string                  Include files with mtime <= WHEN. WHEN accepts RFC3339 timestamp or date only YYYY-MM-DD
  -v, --version                       Print version
      --write-config                  Write current configuration to file (default is $HOME/.gdu.yaml)
TEXT

VERSION = "Version:\t dev\nBuilt time:\t Fri Apr 17 19:59:35 UTC 2026\nBuilt user:\t root\n"

Node = Struct.new(:name, :path, :asize, :dsize, :mtime, :children, :flag, :items, keyword_init: true) do
  def dir? = !children.nil?
  def size(apparent) = apparent ? asize : dsize
end

DEFAULTS = {
  non_interactive: false, summarize: false, apparent: false, no_prefix: false, kib: false, si: false,
  reverse: false, depth: 0, top: nil, show_disks: false, output_file: nil, input_file: nil,
  ignore_dirs: ['/proc', '/dev', '/sys', '/run'], ignore_patterns: [], include_types: nil,
  exclude_types: [], no_hidden: false, follow_symlinks: false, write_config: false, config_file: nil
}

TAKES = {
  '--config-file' => :config_file, '--db' => :db, '-D' => :db, '--depth' => :depth,
  '--exclude-type' => :exclude_types, '-E' => :exclude_types, '--ignore-dirs' => :ignore_dirs, '-i' => :ignore_dirs,
  '--ignore-dirs-pattern' => :ignore_patterns, '-I' => :ignore_patterns, '--ignore-from' => :ignore_from, '-X' => :ignore_from,
  '--input-file' => :input_file, '-f' => :input_file, '--log-file' => :log_file, '-l' => :log_file,
  '--max-age' => :max_age, '--max-cores' => :max_cores, '-m' => :max_cores, '--min-age' => :min_age,
  '--output-file' => :output_file, '-o' => :output_file, '--storage' => :storage, '--style' => :style,
  '--since' => :since, '--until' => :until, '--top' => :top, '-t' => :top, '--type' => :include_types, '-T' => :include_types
}
BOOLS = {
  '--archive-browsing' => :archive, '--collapse-path' => :collapse_path, '--enable-profiling' => :profiling,
  '--follow-symlinks' => :follow_symlinks, '-L' => :follow_symlinks, '--help' => :help, '-h' => :help,
  '--mouse' => :mouse, '--no-color' => :no_color, '-c' => :no_color, '--no-cross' => :no_cross, '-x' => :no_cross,
  '--no-delete' => :no_delete, '--no-hidden' => :no_hidden, '-H' => :no_hidden, '--no-prefix' => :no_prefix,
  '--no-progress' => :no_progress, '-p' => :no_progress, '--no-spawn-shell' => :no_spawn_shell, '--no-unicode' => :no_unicode,
  '-u' => :no_unicode, '--non-interactive' => :non_interactive, '-n' => :non_interactive, '--read-from-storage' => :read_storage,
  '-r' => :read_storage, '--reverse-sort' => :reverse, '--sequential' => :sequential, '--show-annexed-size' => :annexed,
  '-A' => :annexed, '--show-apparent-size' => :apparent, '-a' => :apparent, '--show-disks' => :show_disks, '-d' => :show_disks,
  '--show-in-kib' => :kib, '-k' => :kib, '--show-item-count' => :show_count, '-C' => :show_count, '--show-mtime' => :show_mtime,
  '-M' => :show_mtime, '--show-relative-size' => :relative, '-B' => :relative, '--shared' => :shared, '-S' => :shared,
  '--summarize' => :summarize, '-s' => :summarize, '--si' => :si, '--use-git-ignore' => :gitignore, '-g' => :gitignore,
  '--version' => :version, '-v' => :version, '--write-config' => :write_config, '-w' => :write_config
}
SHORT_ARG = { 'D' => :db, 'E' => :exclude_types, 'i' => :ignore_dirs, 'I' => :ignore_patterns, 'X' => :ignore_from,
              'f' => :input_file, 'l' => :log_file, 'm' => :max_cores, 'o' => :output_file, 't' => :top, 'T' => :include_types }
SHORT_BOOL = { 'L' => :follow_symlinks, 'h' => :help, 'c' => :no_color, 'x' => :no_cross, 'H' => :no_hidden,
               'p' => :no_progress, 'u' => :no_unicode, 'n' => :non_interactive, 'r' => :read_storage, 'A' => :annexed,
               'a' => :apparent, 'd' => :show_disks, 'k' => :kib, 'C' => :show_count, 'M' => :show_mtime, 'B' => :relative,
               'S' => :shared, 's' => :summarize, 'g' => :gitignore, 'v' => :version, 'w' => :write_config }

def coerce(key, value)
  case key
  when :depth, :top, :max_cores then value.to_i
  when :ignore_dirs, :ignore_patterns, :exclude_types, :include_types then value.to_s.split(',').reject(&:empty?)
  else value
  end
end

def parse_args(argv)
  opts = DEFAULTS.dup
  paths = []
  i = 0
  while i < argv.length
    arg = argv[i]
    if arg == '--'
      paths.concat(argv[(i + 1)..] || [])
      break
    elsif arg.start_with?('--')
      key, val = arg.split('=', 2)
      if TAKES[key]
        i += 1 if val.nil?
        val ||= argv[i]
        raise "flag needs an argument: #{key}" if val.nil?
        opts[TAKES[key]] = coerce(TAKES[key], val)
      elsif BOOLS[key]
        opts[BOOLS[key]] = true
      else
        raise "unknown flag: #{key}"
      end
    elsif arg.start_with?('-') && arg != '-'
      chars = arg[1..].chars
      chars.each_with_index do |ch, idx|
        if SHORT_ARG[ch]
          val = chars[(idx + 1)..].join
          if val.empty?
            i += 1
            val = argv[i]
          end
          raise "flag needs an argument: -#{ch}" if val.nil?
          opts[SHORT_ARG[ch]] = coerce(SHORT_ARG[ch], val)
          break
        elsif SHORT_BOOL[ch]
          opts[SHORT_BOOL[ch]] = true
        else
          raise "unknown shorthand flag: '#{ch}' in -#{ch}"
        end
      end
    else
      paths << arg
    end
    i += 1
  end
  [opts, paths]
end

def parse_when(text, end_of_day = false)
  return nil unless text
  if text =~ /^\d{4}-\d{2}-\d{2}$/
    t = Time.parse(text)
    end_of_day ? t + 86_399 : t
  else
    Time.parse(text)
  end
rescue ArgumentError
  nil
end

def duration_seconds(text)
  return nil unless text
  total = 0
  text.scan(/(\d+)(y|mo|w|d|h|m|s)/).each do |num, unit|
    total += num.to_i * { 'y' => 31_536_000, 'mo' => 2_592_000, 'w' => 604_800, 'd' => 86_400, 'h' => 3600, 'm' => 60, 's' => 1 }[unit]
  end
  total.positive? ? total : nil
end

def type_of(path)
  ext = File.extname(path).sub(/^\./, '')
  ext.empty? ? File.basename(path) : ext
end

def disk_size(stat)
  bytes = stat.respond_to?(:blocks) ? stat.blocks.to_i * 512 : stat.size.to_i
  bytes <= 0 && stat.directory? ? 4096 : bytes
end

def ignored_path?(path, name, opts)
  return true if opts[:no_hidden] && name.start_with?('.') && name != '.' && name != '..'
  expanded = File.expand_path(path)
  opts[:ignore_dirs].any? { |p| File.expand_path(p) == expanded || p == path } ||
    opts[:ignore_patterns].any? { |pat| expanded.match?(Regexp.new(pat)) rescue false }
end

def include_file?(path, stat, opts)
  typ = type_of(path)
  return false if opts[:include_types] && !opts[:include_types].include?(typ)
  return false if opts[:exclude_types]&.include?(typ)
  since = parse_when(opts[:since])
  until_t = parse_when(opts[:until], true)
  now = Time.now
  min_age = duration_seconds(opts[:min_age])
  max_age = duration_seconds(opts[:max_age])
  return false if since && stat.mtime < since
  return false if until_t && stat.mtime > until_t
  return false if min_age && stat.mtime > now - min_age
  return false if max_age && stat.mtime < now - max_age
  true
end

def scan_node(path, opts, root = false)
  stat = opts[:follow_symlinks] ? File.stat(path) : File.lstat(path)
  name = root ? File.expand_path(path) : File.basename(path)
  if stat.directory? && !(File.symlink?(path) && !root)
    return nil if !root && ignored_path?(path, File.basename(path), opts)
    own = disk_size(stat)
    children = []
    latest = stat.mtime.to_i
    items = 0
    Dir.children(path).each do |child|
      node = scan_node(File.join(path, child), opts, false)
      next unless node
      children << node
      latest = [latest, node.mtime].max
      items += 1 + (node.items || 0)
    rescue SystemCallError
      next
    end
    Node.new(name: name, path: path, asize: own + children.sum(&:asize), dsize: own + children.sum(&:dsize),
             mtime: latest, children: children, flag: children.empty? ? 'e' : nil, items: items)
  else
    return nil unless include_file?(path, stat, opts)
    dsize = (File.symlink?(path) && !opts[:follow_symlinks]) ? 0 : disk_size(stat)
    Node.new(name: name, path: path, asize: stat.size.to_i, dsize: dsize, mtime: stat.mtime.to_i,
             children: nil, flag: (File.symlink?(path) || stat.socket?) ? '@' : nil, items: 0)
  end
end

def fmt_size(bytes, opts)
  return bytes.to_i.to_s if opts[:no_prefix]
  base = opts[:si] ? 1000.0 : 1024.0
  units = opts[:si] ? %w[B kB MB GB TB PB] : %w[B KiB MiB GiB TiB PiB]
  if opts[:kib]
    return format('%.1f %s', bytes / base, opts[:si] ? 'kB' : 'KiB')
  end
  value = bytes.to_f
  unit = 0
  while value >= base && unit < units.length - 1
    value /= base
    unit += 1
  end
  unit.zero? ? format('%d B', bytes) : format('%.1f %s', value, units[unit])
end

def line_for(node, label, opts, hide_flag = false)
  size = fmt_size(node.size(opts[:apparent]), opts)
  flag = hide_flag ? nil : node.flag
  size_field = if hide_flag
                 format('%9s', size)
               elsif flag
                 "#{flag}#{format('%10s', size)}"
               else
                 " #{format('%10s', size)}"
               end
  format('%s %s', size_field, label)
end

def sorted(nodes, opts)
  arr = nodes.each_with_index.sort_by { |node, idx| [-node.size(opts[:apparent]), idx] }.map(&:first)
  opts[:reverse] ? arr.reverse : arr
end

def walk(node, &block)
  yield node
  (node.children || []).each { |child| walk(child, &block) }
end

def print_listing(root, opts)
  if opts[:summarize]
    puts line_for(root, File.basename(root.name), opts, true)
    return
  end
  if opts[:top].to_i.positive?
    files = []
    walk(root) { |node| files << node unless node.dir? }
    sorted(files, opts).first(opts[:top]).each { |node| puts line_for(node, File.expand_path(node.path), opts, true) }
    return
  end
  if opts[:depth].to_i.positive?
    rec = lambda do |node, depth|
      puts line_for(node, File.expand_path(node.path), opts, true)
      sorted(node.children || [], opts).each { |child| rec.call(child, depth + 1) if depth < opts[:depth] }
    end
    rec.call(root, 0)
  else
    sorted(root.children || [], opts).each do |node|
      puts line_for(node, node.dir? ? "/#{node.name}" : node.name, opts)
    end
  end
end

def node_to_json_obj(node, root = false)
  h = { 'name' => root ? File.expand_path(node.path) : node.name, 'mtime' => node.mtime }
  unless node.dir?
    h['asize'] = node.asize
    h['dsize'] = node.dsize
  end
  return h unless node.dir?
  [h, *(node.children || []).map { |child| node_to_json_obj(child, false) }]
end

def json_generate(value)
  case value
  when Array
    '[' + value.map { |item| json_generate(item) }.join(',') + ']'
  when Hash
    '{' + value.map { |key, item| json_generate(key.to_s) + ':' + json_generate(item) }.join(',') + '}'
  when String
    value.inspect
  when Integer
    value.to_s
  when NilClass
    'null'
  when TrueClass, FalseClass
    value ? 'true' : 'false'
  else
    json_generate(value.to_s)
  end
end

def node_from_json(obj)
  if obj.is_a?(Array)
    h = obj[0]
    kids = obj[1..].map { |child| node_from_json(child) }
    own = 4096
    Node.new(name: h['name'], path: h['name'], asize: own + kids.sum(&:asize), dsize: own + kids.sum(&:dsize),
             mtime: h['mtime'].to_i, children: kids, flag: kids.empty? ? 'e' : nil,
             items: kids.length + kids.sum { |k| k.items || 0 })
  else
    Node.new(name: obj['name'], path: obj['name'], asize: (obj['asize'] || 0).to_i, dsize: (obj['dsize'] || 0).to_i,
             mtime: obj['mtime'].to_i, children: nil, flag: nil, items: 0)
  end
end

def show_disks
  puts '   Device      Size      Used      Free Used% Mount point'
  File.readlines('/proc/mounts').each do |line|
    dev, mnt, fs = line.split[0, 3]
    next if dev.nil? || mnt.nil? || fs =~ /^(proc|sysfs|tmpfs|devpts|cgroup|overlay|mqueue|shm)$/
    row = `df -P -B1 #{Shellwords.escape(mnt)} 2>/dev/null`.lines[1]
    next unless row
    parts = row.split
    puts format('%-8s %8s %8s %8s %5s %s', dev, fmt_size(parts[1].to_i, {}), fmt_size(parts[2].to_i, {}),
                fmt_size(parts[3].to_i, {}), parts[4], mnt)
  end
end

begin
  opts, paths = parse_args(ARGV)
  if opts[:help]
    print HELP
    exit 0
  end
  if opts[:version]
    print VERSION
    exit 0
  end
  if opts[:write_config]
    File.write(opts[:config_file] || File.join(Dir.home, '.gdu.yaml'), "no-color: false\nno-progress: false\n")
    exit 0
  end
  if opts[:show_disks]
    show_disks
    exit 0
  end
  if opts[:ignore_from] && File.file?(opts[:ignore_from])
    opts[:ignore_patterns] += File.readlines(opts[:ignore_from], chomp: true).reject(&:empty?)
  end
  root = if opts[:input_file]
           node_from_json(YAML.load_file(opts[:input_file])[3])
         else
           scan_node(paths.first || '.', opts, true)
         end
  if opts[:output_file]
    payload = [1, 2, { 'progname' => 'gdu', 'progver' => 'dev', 'timestamp' => Time.now.to_i }, node_to_json_obj(root, true)]
    File.write(opts[:output_file], json_generate(payload))
  else
    print_listing(root, opts)
  end
rescue SystemCallError => e
  warn "Error: #{e.message}"
  exit 1
rescue StandardError => e
  warn "Error: #{e.message}"
  exit 1
end
