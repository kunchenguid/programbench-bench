#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = 'SoX v14.4.2'

EFFECTS = %w[
  allpass band bandpass bandreject bass bend biquad chorus channels compand
  contrast dcshift deemph delay dither divide downsample earwax echo echos
  equalizer fade fir firfit flanger gain highpass hilbert input ladspa loudness
  lowpass mcompand noiseprof noisered norm oops output overdrive pad phaser
  pitch rate remix repeat reverb reverse riaa silence sinc speed splice stat
  stats stretch swap synth tempo treble tremolo trim upsample vad vol
].freeze

FORMATS = %w[
  8svx aif aifc aiff aiffc al amb au avr cdda cdr cvs cvsd cvu dat dvms f32 f4
  f64 f8 fssd gsrt hcom htk ima ircam la lpc lpc10 lu maud nist prc raw s1 s16
  s2 s24 s3 s32 s4 s8 sb sf sl sln smp snd sndr sndt sou sox sph sw txw u1 u16
  u2 u24 u3 u32 u4 u8 ub ul uw vms voc vox wav wavpcm wve xa
].freeze

class Audio
  attr_accessor :rate, :channels, :bits, :encoding, :samples, :comments

  def initialize(rate: 44_100, channels: 1, bits: 16, encoding: 'signed-integer', samples: [], comments: [])
    @rate = rate.to_i
    @channels = channels.to_i
    @bits = bits.to_i
    @encoding = encoding
    @samples = samples
    @comments = comments
  end

  def frames
    @channels <= 0 ? 0 : @samples.length / @channels
  end

  def duration
    @rate <= 0 ? 0.0 : frames.to_f / @rate
  end
end

def failx(msg, code = 1)
  warn "#{File.basename($PROGRAM_NAME)} FAIL #{msg}"
  exit code
end

def parse_rate(s)
  str = s.to_s.strip.downcase
  mult = str.end_with?('k') ? 1000 : 1
  str = str[0...-1] if mult == 1000
  (Float(str) * mult).round
rescue StandardError
  failx("sox: invalid rate `#{s}'")
end

def parse_time(s, rate = 44_100)
  str = s.to_s
  if str.include?(':')
    parts = str.split(':').map(&:to_f)
    seconds = 0.0
    parts.each { |p| seconds = seconds * 60 + p }
    seconds
  elsif str.end_with?('s') && str[0...-1] =~ /\A\d+\z/
    str[0...-1].to_i.to_f / rate
  else
    Float(str)
  end
rescue StandardError
  0.0
end

def sample_max(bits)
  bits == 8 ? 127.0 : ((1 << (bits - 1)) - 1).to_f
end

def clamp(v)
  [[v, -1.0].max, 1.0].min
end

def ext_type(path)
  return 'raw' if path == '-' || path.nil?
  e = File.extname(path).downcase.delete_prefix('.')
  e.empty? ? 'raw' : e
end

def read_u16le(s, off) = s.byteslice(off, 2).unpack1('v')
def read_u32le(s, off) = s.byteslice(off, 4).unpack1('V')

def read_wav(path)
  data = path == '-' ? STDIN.binmode.read : File.binread(path)
  failx("formats: can't open input file `#{path}': WAVE: RIFF header not found") unless data&.bytesize&.>= 12
  failx("formats: can't open input file `#{path}': WAVE: RIFF header not found") unless data[0, 4] == 'RIFF' && data[8, 4] == 'WAVE'

  off = 12
  fmt = nil
  pcm = nil
  comments = []
  while off + 8 <= data.bytesize
    id = data[off, 4]
    size = read_u32le(data, off + 4)
    body = data.byteslice(off + 8, size) || ''.b
    case id
    when 'fmt '
      fmt = body
    when 'data'
      pcm = body
    when 'LIST'
      comments << body.gsub(/\x00/, "\n").scrub.strip unless body.empty?
    end
    off += 8 + size + (size.odd? ? 1 : 0)
  end
  failx("formats: can't open input file `#{path}': WAVE file has no fmt chunk") unless fmt
  failx("formats: can't open input file `#{path}': WAVE file has no data chunk") unless pcm

  code, channels, rate, = fmt.unpack('v v V V v v')
  bits = fmt.unpack1('@14v')
  encoding = code == 3 ? 'floating-point' : (bits == 8 ? 'unsigned-integer' : 'signed-integer')
  Audio.new(rate: rate, channels: channels, bits: bits, encoding: encoding,
            samples: decode_samples(pcm, bits, encoding, :little), comments: comments)
end

def decode_samples(data, bits, encoding, endian)
  bytes = [bits / 8, 1].max
  out = []
  return out if data.nil?
  max = sample_max(bits)
  if encoding == 'floating-point'
    if bits == 64
      data.scan(/.{8}/m) { |b| out << clamp(b.unpack1(endian == :big ? 'G' : 'E')) }
    else
      data.scan(/.{4}/m) { |b| out << clamp(b.unpack1(endian == :big ? 'g' : 'e')) }
    end
    return out
  end
  data.bytes.each { |b| out << ((b - 128) / 128.0) } and return out if bits == 8 && encoding.start_with?('unsigned')

  data.scan(/.{#{bytes}}/m) do |b|
    next unless b.bytesize == bytes
    val = case bits
          when 8
            b.unpack1('c')
          when 16
            b.unpack1(endian == :big ? 's>' : 's<')
          when 24
            a = b.bytes
            n = endian == :big ? (a[0] << 16 | a[1] << 8 | a[2]) : (a[2] << 16 | a[1] << 8 | a[0])
            n -= 1 << 24 if n & 0x800000 != 0
            n
          when 32
            b.unpack1(endian == :big ? 'l>' : 'l<')
          else
            0
          end
    out << clamp(val / max)
  end
  out
end

def encode_samples(samples, bits, encoding, endian = :little)
  out = +''
  max = sample_max(bits)
  if encoding == 'floating-point'
    samples.each { |v| out << [clamp(v)].pack(bits == 64 ? (endian == :big ? 'G' : 'E') : (endian == :big ? 'g' : 'e')) }
    return out
  end
  samples.each do |v|
    v = clamp(v)
    if bits == 8 && encoding.start_with?('unsigned')
      out << [[(v * 127.0 + 128).round, 0].max, 255].min.chr
    elsif bits == 8
      out << [(v * 127.0).round].pack('c')
    elsif bits == 16
      out << [(v * max).round].pack(endian == :big ? 's>' : 's<')
    elsif bits == 24
      n = (v * max).round
      n += 1 << 24 if n.negative?
      bytes = [n & 0xff, (n >> 8) & 0xff, (n >> 16) & 0xff]
      out << (endian == :big ? bytes.reverse : bytes).pack('C*')
    else
      out << [(v * ((1 << 31) - 1)).round].pack(endian == :big ? 'l>' : 'l<')
    end
  end
  out
end

def read_raw(path, opts)
  data = path == '-' ? STDIN.binmode.read : File.binread(path)
  bits = (opts[:bits] || 16).to_i
  enc = opts[:encoding] || (bits == 8 ? 'unsigned-integer' : 'signed-integer')
  endian = opts[:endian] == 'big' ? :big : :little
  Audio.new(rate: opts[:rate] || 8000, channels: opts[:channels] || 1, bits: bits, encoding: enc,
            samples: decode_samples(data, bits, enc, endian))
end

def read_audio(path, opts = {})
  type = (opts[:type] || ext_type(path)).downcase
  case type
  when 'wav', 'wavpcm'
    read_wav(path)
  when 'raw', 's16', 's8', 'u8', 's24', 's32'
    bits = type[/\d+/]&.to_i || opts[:bits]
    enc = type.start_with?('u') ? 'unsigned-integer' : opts[:encoding]
    read_raw(path, opts.merge(bits: bits || opts[:bits], encoding: enc || opts[:encoding]))
  when 'dat'
    read_dat(path, opts)
  else
    read_wav(path)
  end
rescue Errno::ENOENT
  failx("formats: can't open input file `#{path}': No such file or directory")
end

def read_dat(path, opts)
  lines = path == '-' ? STDIN.read.lines : File.readlines(path)
  rate = opts[:rate] || 44_100
  channels = opts[:channels] || 1
  samples = []
  lines.each do |line|
    next if line.strip.empty? || line.start_with?(';', '#')
    nums = line.split.map { |x| Float(x) rescue nil }.compact
    next if nums.empty?
    vals = nums.length > 1 ? nums[1..] : nums
    vals.each { |v| samples << clamp(v) }
  end
  Audio.new(rate: rate, channels: channels, bits: opts[:bits] || 32, encoding: 'floating-point', samples: samples)
end

def write_wav(path, audio, opts = {})
  bits = (opts[:bits] || audio.bits || 16).to_i
  enc = opts[:encoding] || (bits == 8 ? 'unsigned-integer' : 'signed-integer')
  fmt_code = enc == 'floating-point' ? 3 : 1
  data = encode_samples(audio.samples, bits, enc, :little)
  byte_rate = audio.rate * audio.channels * bits / 8
  block_align = audio.channels * bits / 8
  fmt = [fmt_code, audio.channels, audio.rate, byte_rate, block_align, bits].pack('v v V V v v')
  riff_size = 4 + (8 + fmt.bytesize) + (8 + data.bytesize)
  out = +'RIFF' << [riff_size].pack('V') << 'WAVE'
  out << 'fmt ' << [fmt.bytesize].pack('V') << fmt
  out << 'data' << [data.bytesize].pack('V') << data
  if path == '-'
    STDOUT.binmode.write(out)
  else
    File.binwrite(path, out)
  end
end

def write_raw(path, audio, opts = {})
  bits = (opts[:bits] || audio.bits || 16).to_i
  enc = opts[:encoding] || (bits == 8 ? 'unsigned-integer' : 'signed-integer')
  data = encode_samples(audio.samples, bits, enc, opts[:endian] == 'big' ? :big : :little)
  path == '-' ? STDOUT.binmode.write(data) : File.binwrite(path, data)
end

def write_dat(path, audio)
  out = +"# Sample Rate #{audio.rate}\n"
  audio.frames.times do |i|
    vals = audio.samples[i * audio.channels, audio.channels] || []
    out << format("%14.8g", i.to_f / audio.rate)
    vals.each { |v| out << ' ' << format("%14.8g", v) }
    out << "\n"
  end
  path == '-' ? STDOUT.write(out) : File.write(path, out)
end

def write_audio(path, audio, opts = {})
  type = (opts[:type] || ext_type(path)).downcase
  case type
  when 'raw', 's16', 's8', 'u8', 's24', 's32'
    write_raw(path, audio, opts)
  when 'dat'
    write_dat(path, audio)
  else
    write_wav(path, audio, opts)
  end
end

def usage
  puts "#{File.basename($PROGRAM_NAME)}:      #{VERSION}"
  puts
  puts 'Usage summary: [gopts] [[fopts] infile]... [fopts] outfile [effect [effopt]]...'
  puts
  puts 'SPECIAL FILENAMES (infile, outfile):'
  puts "-                        Pipe/redirect input/output (stdin/stdout); may need -t"
  puts "-n, --null               Use the `null' file handler; e.g. with synth effect"
  puts
  puts 'GLOBAL OPTIONS (gopts) (can be specified at any point before the first effect):'
  puts '-h, --help               Display version number and usage information'
  puts '--help-effect NAME       Show usage of effect NAME, or NAME=all for all'
  puts '--help-format NAME       Show info on format NAME, or NAME=all for all'
  puts '--i, --info              Behave as soxi(1)'
  puts '--version                Display version number of SoX and exit'
  puts '-V[LEVEL]                Increment or set verbosity level (default 2)'
  puts 'FORMAT OPTIONS (fopts):'
  puts '-t|--type FILETYPE       File type of audio'
  puts '-e|--encoding ENCODING   Set encoding'
  puts '-b|--bits BITS           Encoded sample size in bits'
  puts '-c|--channels CHANNELS   Number of channels of audio'
  puts '-r|--rate RATE           Sample rate of audio'
  puts
  puts "AUDIO FILE FORMATS: #{FORMATS.join(' ')}"
  puts 'PLAYLIST FORMATS: m3u pls'
  puts 'AUDIO DEVICE DRIVERS: oss ossdsp'
  puts
  puts "EFFECTS: #{EFFECTS.join(' ')}"
  puts 'EFFECT OPTIONS (effopts): effect dependent; see --help-effect'
end

def help_effect(name)
  puts "#{File.basename($PROGRAM_NAME)}:      #{VERSION}"
  puts "\nEffect usage:\n\n"
  text = case name
         when 'synth'
           'synth [-j KEY] [-n] [length [offset [phase [p1 [p2 [p3]]]]]]] {type [combine] [[%]freq[k][:|+|/|-[%]freq2[k]] [offset [phase [p1 [p2 [p3]]]]]]}'
         when 'trim' then 'trim {position}'
         when 'channels' then 'channels number'
         when 'rate' then 'rate [-q|-l|-m|-h|-v] [override-options] RATE[k]'
         when 'gain' then "gain [-e|-b|-B|-r] [-n] [-l|-h] [gain-dB]\ngain-dB\t Apply gain in dB"
         when 'vol' then 'vol gain [type [limitergain]]'
         when 'stat' then 'stat [ -s N ] [ -rms ] [-freq] [ -v ] [ -d ]'
         else "#{name} [options]"
         end
  puts text
end

def help_format(name)
  puts "#{File.basename($PROGRAM_NAME)}:      #{VERSION}"
  puts
  puts "Format: #{name}"
  if %w[wav wavpcm].include?(name)
    puts 'Description: Microsoft audio format'
    puts 'Also handles: wavpcm amb'
    puts 'Reads: yes'
    puts "Writes:\n  16-bit Signed Integer PCM (16-bit precision)\n  24-bit Signed Integer PCM (24-bit precision)\n  32-bit Signed Integer PCM (32-bit precision)\n   8-bit Unsigned Integer PCM (8-bit precision)"
  elsif name == 'raw'
    puts 'Description: Raw PCM, mu-law, or A-law'
    puts 'Reads: yes'
    puts 'Writes: yes'
  else
    puts 'Description: audio file format'
    puts 'Reads: yes'
    puts 'Writes: yes'
  end
end

def parse_cli(argv)
  info = false
  combine = :concat
  files = []
  cur = {}
  i = 0
  while i < argv.length
    a = argv[i]
    break if EFFECTS.include?(a.sub(/\+.*/, '').sub(/#.*/, '')) && !files.empty?
    case a
    when '-h', '--help'
      usage
      exit 0
    when '--version'
      puts "#{File.basename($PROGRAM_NAME)}:      #{VERSION}"
      exit 0
    when '--help-effect'
      help_effect(argv[i + 1] || 'all')
      exit 0
    when '--help-format'
      help_format(argv[i + 1] || 'all')
      exit 0
    when '--info'
      info = true
    when '--i'
      cur[:ignore_length] = true
    when '-m'
      combine = :mix
    when '-M'
      combine = :merge
    when '-T'
      combine = :multiply
    when '--combine'
      combine = (argv[i + 1] || 'concatenate').to_sym
      i += 1
    when '-q', '--no-show-progress', '-S', '--show-progress', '-D', '--no-dither', '-G', '--guard', '--norm', '--clobber', '--no-clobber', '-R'
      # accepted compatibility no-op
    when /\A-V/
      # verbosity no-op
    when '-n', '--null'
      files << { path: '-n', opts: cur }
      cur = {}
    when '-p', '--sox-pipe'
      cur = cur.merge(type: 'sox')
      files << { path: '-', opts: cur }
      cur = {}
    when '-t', '--type'
      cur[:type] = argv[i + 1]
      i += 1
    when '-e', '--encoding'
      cur[:encoding] = normalize_encoding(argv[i + 1])
      i += 1
    when '-b', '--bits'
      cur[:bits] = argv[i + 1].to_i
      i += 1
    when '-c', '--channels'
      cur[:channels] = argv[i + 1].to_i
      i += 1
    when '-r', '--rate'
      cur[:rate] = parse_rate(argv[i + 1])
      i += 1
    when '-L'
      cur[:endian] = 'little'
    when '-B'
      cur[:endian] = 'big'
    when '--endian'
      cur[:endian] = argv[i + 1]
      i += 1
    when '-v', '--volume'
      cur[:volume] = Float(argv[i + 1]) rescue 1.0
      i += 1
    when '--ignore-length', '-N', '-X', '--no-glob'
      # no-op
    when '-C', '--compression', '--add-comment', '--comment', '--comment-file', '--buffer', '--input-buffer', '--temp', '--play-rate-arg', '--plot', '--replay-gain', '--dft-min', '--effects-file'
      i += 1
    else
      files << { path: a, opts: cur }
      cur = {}
    end
    i += 1
  end
  [info, combine, files, argv[i..] || []]
end

def normalize_encoding(e)
  case e.to_s
  when 'signed', 'signed-integer' then 'signed-integer'
  when 'unsigned', 'unsigned-integer' then 'unsigned-integer'
  when 'float', 'floating-point' then 'floating-point'
  else e.to_s
  end
end

def format_duration(sec)
  total = sec.floor
  h = total / 3600
  m = (total / 60) % 60
  s = total % 60
  frac = sec - total
  format('%02d:%02d:%05.2f', h, m, s + frac)
end

def info_output(files, opts)
  opt = opts.find { |x| %w[-t -r -c -s -d -D -b -B -p -e -a].include?(x) }
  files.each do |f|
    a = read_audio(f[:path], f[:opts])
    case opt
    when '-t' then puts((f[:opts][:type] || ext_type(f[:path])).downcase)
    when '-r' then puts a.rate
    when '-c' then puts a.channels
    when '-s' then puts a.frames
    when '-d' then puts format_duration(a.duration)
    when '-D' then puts format('%.6f', a.duration)
    when '-b', '-p' then puts a.bits
    when '-B' then puts bitrate(a, f[:path])
    when '-e' then puts encoding_name(a)
    when '-a' then puts a.comments.join("\n")
    else
      puts
      puts "Input File     : '#{f[:path]}'"
      puts "Channels       : #{a.channels}"
      puts "Sample Rate    : #{a.rate}"
      puts "Precision      : #{a.bits}-bit"
      puts "Duration       : #{format_duration(a.duration)} = #{a.frames} samples ~ #{format('%.2g', a.frames / 588.0)} CDDA sectors"
      size = (File.size(f[:path]) rescue a.samples.length * a.bits / 8)
      puts "File Size      : #{human_size(size)}"
      puts "Bit Rate       : #{bitrate(a, f[:path])}"
      puts "Sample Encoding: #{encoding_name(a)}"
      puts
    end
  end
end

def human_size(n)
  return n.to_s if n < 1000
  units = %w[k M G]
  val = n.to_f
  unit = ''
  units.each do |u|
    val /= 1000.0
    unit = u
    break if val < 1000
  end
  format('%.3g%s', val, unit)
end

def bitrate(a, path)
  size = File.size(path) rescue (a.samples.length * a.bits / 8)
  br = a.duration.positive? ? (size * 8 / a.duration) : 0
  br >= 1000 ? "#{(br / 1000.0).round}k" : br.round.to_s
end

def encoding_name(a)
  if a.encoding == 'floating-point'
    "#{a.bits}-bit Floating Point PCM"
  elsif a.bits == 8 && a.encoding.start_with?('unsigned')
    '8-bit Unsigned Integer PCM'
  else
    "#{a.bits}-bit Signed Integer PCM"
  end
end

def synth_audio(opts, args)
  len = 0.0
  len = parse_time(args.shift, opts[:rate] || 44_100) if args[0] && args[0] =~ /\A[\d:.]+s?\z/
  len = 1.0 if len <= 0
  rate = opts[:rate] || 44_100
  channels = opts[:channels] || 1
  frames = (len * rate).round
  waves = []
  until args.empty?
    typ = args.shift || 'sine'
    break if EFFECTS.include?(typ)
    _combine = nil
    _combine = args.shift if %w[create mix amod fmod].include?(args[0])
    freq = args.shift || '440'
    waves << [typ, parse_freq(freq)]
    args.shift while args[0] && args[0] =~ /\A[-+]?\d+(\.\d+)?\z/ && waves.length > 1
  end
  waves = [['sine', 440.0]] if waves.empty?
  samples = []
  frames.times do |i|
    t = i.to_f / rate
    channels.times do |ch|
      val = waves.map { |typ, fr| wave_value(typ, fr, t, i, ch) }.sum / waves.length
      samples << (val * 0.7)
    end
  end
  Audio.new(rate: rate, channels: channels, bits: opts[:bits] || 32, encoding: opts[:encoding] || 'signed-integer', samples: samples)
end

def parse_freq(s)
  str = s.to_s.sub(/^%/, '').split(/[:+\/-]/).first
  parse_rate(str)
end

def wave_value(typ, freq, t, i, ch)
  phase = 2.0 * Math::PI * freq * t
  case typ
  when 'sin', 'sine' then Math.sin(phase)
  when 'square' then Math.sin(phase) >= 0 ? 1.0 : -1.0
  when 'tri', 'triangle' then 2.0 / Math::PI * Math.asin(Math.sin(phase))
  when 'saw', 'sawtooth' then 2.0 * (freq * t - (0.5 + freq * t).floor)
  when 'noise', 'whitenoise' then rand * 2 - 1
  else Math.sin(phase)
  end
end

def combine_audios(audios, mode)
  return audios.first if audios.length == 1
  base = audios.first
  audios[1..].each { |a| a = convert_rate(a, base.rate) if a.rate != base.rate }
  case mode
  when :mix, :multiply, :merge, :'mix-power'
    max_len = audios.map { |a| a.samples.length }.max || 0
    out = Array.new(max_len, mode == :multiply ? 1.0 : 0.0)
    audios.each do |a|
      max_len.times do |i|
        v = a.samples[i] || 0.0
        out[i] = mode == :multiply ? out[i] * v : out[i] + v / audios.length
      end
    end
    Audio.new(rate: base.rate, channels: base.channels, bits: base.bits, encoding: base.encoding, samples: out.map { |v| clamp(v) })
  else
    Audio.new(rate: base.rate, channels: base.channels, bits: base.bits, encoding: base.encoding,
              samples: audios.flat_map(&:samples))
  end
end

def convert_channels(a, n)
  return a if n == a.channels
  frames = a.frames
  out = []
  frames.times do |i|
    frame = a.samples[i * a.channels, a.channels] || []
    if n == 1
      out << (frame.sum / [frame.length, 1].max)
    else
      n.times { |ch| out << (frame[ch] || frame[ch % frame.length] || 0.0) }
    end
  end
  a.channels = n
  a.samples = out
  a
end

def convert_rate(a, new_rate)
  new_rate = new_rate.to_i
  return a if new_rate <= 0 || new_rate == a.rate
  new_frames = (a.frames * new_rate.to_f / a.rate).round
  out = []
  new_frames.times do |i|
    src = i * a.rate.to_f / new_rate
    j = src.floor
    frac = src - j
    a.channels.times do |ch|
      v1 = a.samples[j * a.channels + ch] || 0.0
      v2 = a.samples[[j + 1, a.frames - 1].min * a.channels + ch] || v1
      out << (v1 * (1 - frac) + v2 * frac)
    end
  end
  a.rate = new_rate
  a.samples = out
  a
end

def apply_effects(audio, effects)
  i = 0
  while i < effects.length
    e = effects[i]
    case e
    when 'channels'
      audio = convert_channels(audio, effects[i + 1].to_i)
      i += 2
    when 'rate'
      j = i + 1
      j += 1 while effects[j]&.start_with?('-')
      audio = convert_rate(audio, parse_rate(effects[j] || audio.rate.to_s))
      i = j + 1
    when 'trim'
      start = parse_time(effects[i + 1] || '0', audio.rate)
      dur = effects[i + 2] && !EFFECTS.include?(effects[i + 2]) ? parse_time(effects[i + 2], audio.rate) : nil
      sframe = (start * audio.rate).round
      eframe = dur ? sframe + (dur * audio.rate).round : audio.frames
      audio.samples = audio.samples[sframe * audio.channels...eframe * audio.channels] || []
      i += dur ? 3 : 2
    when 'gain'
      j = i + 1
      norm = false
      while effects[j]&.start_with?('-')
        norm ||= effects[j].include?('n')
        j += 1
      end
      db = 0.0
      if effects[j] && !EFFECTS.include?(effects[j])
        begin
          db = Float(effects[j])
        rescue StandardError
          db = 0.0
        end
      end
      factor = 10**(db / 20.0)
      factor = norm_factor(audio) * factor if norm
      audio.samples.map! { |v| clamp(v * factor) }
      i = (effects[j] && !EFFECTS.include?(effects[j])) ? j + 1 : j
    when 'norm'
      audio.samples.map! { |v| clamp(v * norm_factor(audio)) }
      i += 1
    when 'vol'
      factor = Float(effects[i + 1]) rescue 1.0
      audio.samples.map! { |v| clamp(v * factor) }
      i += 2
    when 'reverse'
      frames = audio.samples.each_slice(audio.channels).to_a.reverse.flatten
      audio.samples = frames
      i += 1
    when 'repeat'
      n = (effects[i + 1] || '1').to_i
      orig = audio.samples.dup
      audio.samples = orig * (n + 1)
      i += 2
    when 'pad'
      before = parse_time(effects[i + 1] || '0', audio.rate)
      after = parse_time(effects[i + 2] || '0', audio.rate)
      audio.samples = Array.new((before * audio.rate).round * audio.channels, 0.0) + audio.samples +
                      Array.new((after * audio.rate).round * audio.channels, 0.0)
      i += 3
    when 'speed', 'tempo'
      factor = Float(effects[i + 1]) rescue 1.0
      audio = convert_rate(audio, (audio.rate / factor).round)
      audio.rate = (audio.rate * factor).round
      i += 2
    when 'stat', 'stats'
      print_stats(audio)
      i += 1
    else
      i += 1
    end
  end
  audio
end

def norm_factor(audio)
  peak = audio.samples.map(&:abs).max || 0.0
  peak.positive? ? 0.999 / peak : 1.0
end

def print_stats(audio)
  samples = audio.samples
  max = samples.max || 0.0
  min = samples.min || 0.0
  mean = samples.empty? ? 0.0 : samples.sum / samples.length
  rms = samples.empty? ? 0.0 : Math.sqrt(samples.map { |x| x * x }.sum / samples.length)
  warn format('Samples read:           %12d', audio.frames)
  warn format('Length (seconds):      %12.6f', audio.duration)
  warn format('Maximum amplitude:     %12.6f', max)
  warn format('Minimum amplitude:     %12.6f', min)
  warn format('Midline amplitude:     %12.6f', (max + min) / 2.0)
  warn format('Mean    norm:          %12.6f', mean.abs)
  warn format('Mean    amplitude:     %12.6f', mean)
  warn format('RMS     amplitude:     %12.6f', rms)
end

if ARGV.empty?
  usage
  exit 0
end

if ARGV.include?('--info') || File.basename($PROGRAM_NAME) == 'soxi'
  info_args = ARGV.reject { |a| a == '--info' || a =~ /\A-V/ || a == '-T' }
  selector = info_args.find { |x| %w[-t -r -c -s -d -D -b -B -p -e -a].include?(x) }
  paths = info_args.reject { |x| %w[-t -r -c -s -d -D -b -B -p -e -a].include?(x) }
  paths = ['-'] if paths.empty?
  info_output(paths.map { |p| { path: p, opts: {} } }, selector ? [selector] : [])
  exit 0
end

info, combine, files, effects = parse_cli(ARGV.dup)
if info || File.basename($PROGRAM_NAME) == 'soxi'
  info_files = files.empty? ? effects.map { |p| { path: p, opts: {} } } : files
  info_output(info_files, ARGV)
  exit 0
end

failx('sox: Not enough input filenames specified') if files.empty?
output = files.pop
inputs = files
if inputs.empty? && output[:path] == '-n'
  inputs = [output]
  output = { path: '-', opts: {} }
end

audio =
  if inputs.any? { |f| f[:path] == '-n' } && effects.include?('synth')
    idx = effects.index('synth')
    synth_audio(inputs.find { |f| f[:path] == '-n' }[:opts].merge(output[:opts]), effects[(idx + 1)..] || [])
  elsif inputs.any? { |f| f[:path] == '-n' }
    Audio.new(rate: output[:opts][:rate] || inputs[0][:opts][:rate] || 44_100,
              channels: output[:opts][:channels] || inputs[0][:opts][:channels] || 1,
              bits: output[:opts][:bits] || inputs[0][:opts][:bits] || 16,
              samples: [])
  else
    audios = inputs.map do |f|
      a = read_audio(f[:path], f[:opts])
      a.samples.map! { |v| clamp(v * f[:opts][:volume].to_f) } if f[:opts][:volume]
      a
    end
    combine_audios(audios, combine)
  end

effects = effects.drop(effects.index('synth') ? effects.index('synth') + 1 : 0) if false
audio = apply_effects(audio, effects.reject { |x| x == 'synth' })
audio.bits = output[:opts][:bits] if output[:opts][:bits]
audio.encoding = output[:opts][:encoding] if output[:opts][:encoding]
audio.rate = output[:opts][:rate] if output[:opts][:rate] && effects.none? { |e| e == 'rate' }
audio = convert_channels(audio, output[:opts][:channels]) if output[:opts][:channels]
write_audio(output[:path], audio, output[:opts]) unless output[:path] == '-n'
