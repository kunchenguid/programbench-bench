#!/usr/bin/env ruby
# frozen_string_literal: true

require 'zlib'

VERSION = "hck git:23bebe8-modified"

HELP_SHORT = <<~HELP
  * `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`

  Usage: executable [OPTIONS] [INPUT]...

  Arguments:
    [INPUT]...  Input files to parse, defaults to stdin

  Options:
    -o, --output <OUTPUT>
            Output file to write to, defaults to stdout
    -d, --delimiter <DELIMITER>
            Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag [default: \\s+]
    -L, --delim-is-literal
            Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters
    -I, --use-input-delim
            Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set
    -D, --output-delimiter <OUTPUT_DELIMITER>
            Delimiter string to use on outputs [default: "\\t"]
    -f, --fields <FIELDS>
            Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive
    -e, --exclude <EXCLUDE>
            Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`
    -E, --exclude-header <EXCLUDE_HEADER>
            Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex
    -F, --header-field <HEADER_FIELD>
            A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex
    -r, --header-is-regex
            Treat the header_fields as regexs instead of string literals
    -z, --try-decompress
            Try to find the correct decompression method based on the file extensions
    -Z, --try-compress
            Try to gzip compress the output
    -t, --compression-threads <COMPRESSION_THREADS>
            Threads to use for compression, 0 will result in `hck` staying single threaded [default: 4]
    -l, --compression-level <COMPRESSION_LEVEL>
            Compression level [default: 6]
        --no-mmap
            Disallow the possibility of using mmap
        --crlf
            Support CRLF newlines
    -h, --help
            Print help (see more with '--help')
    -V, --version
            Print version
HELP

HELP_LONG = HELP_SHORT.sub("Print help (see more with '--help')", "Print help (see a summary with '-h')")

class HckError < StandardError
  attr_reader :status

  def initialize(message, status = 1)
    super(message)
    @status = status
  end
end

def error(message, status = 1)
  raise HckError.new(message, status)
end

def parse_args(argv)
  opts = {
    delimiter: '\s+',
    literal: false,
    use_input_delim: false,
    output_delim: "\t",
    output_delim_set: false,
    fields: nil,
    exclude: nil,
    header_fields: [],
    exclude_headers: [],
    header_regex: false,
    decompress: false,
    compress: false,
    output: nil,
    inputs: []
  }

  i = 0
  while i < argv.length
    arg = argv[i]
    if arg == '--'
      opts[:inputs].concat(argv[(i + 1)..] || [])
      break
    elsif arg == '-h'
      puts HELP_SHORT
      exit 0
    elsif arg == '--help'
      puts HELP_LONG
      exit 0
    elsif arg == '-V' || arg == '--version'
      puts VERSION
      exit 0
    elsif arg.start_with?('--')
      name, value = arg[2..].split('=', 2)
      need = lambda do
        if value.nil?
          i += 1
          error("a value is required for '--#{name}' but none was supplied", 2) if i >= argv.length
          argv[i]
        else
          value
        end
      end
      case name
      when 'output' then opts[:output] = need.call
      when 'delimiter' then opts[:delimiter] = need.call
      when 'output-delimiter'
        opts[:output_delim] = need.call
        opts[:output_delim_set] = true
      when 'fields' then opts[:fields] = need.call
      when 'exclude' then opts[:exclude] = need.call
      when 'exclude-header' then opts[:exclude_headers] << need.call
      when 'header-field' then opts[:header_fields] << need.call
      when 'compression-threads', 'compression-level' then need.call
      when 'delim-is-literal' then opts[:literal] = true
      when 'use-input-delim' then opts[:use_input_delim] = true
      when 'header-is-regex' then opts[:header_regex] = true
      when 'try-decompress' then opts[:decompress] = true
      when 'try-compress' then opts[:compress] = true
      when 'no-mmap', 'crlf'
        # Accepted for compatibility.
      else
        warn "error: unexpected argument '--#{name}' found"
        warn
        warn "Usage: executable [OPTIONS] [INPUT]..."
        exit 2
      end
    elsif arg.start_with?('-') && arg != '-'
      j = 1
      while j < arg.length
        ch = arg[j]
        if %w[o d D f e E F t l].include?(ch)
          val = arg[(j + 1)..]
          if val.nil? || val.empty?
            i += 1
            error("a value is required for '-#{ch}' but none was supplied", 2) if i >= argv.length
            val = argv[i]
          end
          case ch
          when 'o' then opts[:output] = val
          when 'd' then opts[:delimiter] = val
          when 'D'
            opts[:output_delim] = val
            opts[:output_delim_set] = true
          when 'f' then opts[:fields] = val
          when 'e' then opts[:exclude] = val
          when 'E' then opts[:exclude_headers] << val
          when 'F' then opts[:header_fields] << val
          when 't', 'l'
            # Ignored.
          end
          break
        else
          case ch
          when 'L' then opts[:literal] = true
          when 'I' then opts[:use_input_delim] = true
          when 'r' then opts[:header_regex] = true
          when 'z' then opts[:decompress] = true
          when 'Z' then opts[:compress] = true
          when 'h'
            puts HELP_SHORT
            exit 0
          when 'V'
            puts VERSION
            exit 0
          else
            warn "error: unexpected argument '-#{ch}' found"
            warn
            warn "Usage: executable [OPTIONS] [INPUT]..."
            exit 2
          end
          j += 1
        end
      end
    else
      opts[:inputs] << arg
    end
    i += 1
  end
  opts[:output_delim] = opts[:delimiter] if opts[:use_input_delim] && opts[:literal] && !opts[:output_delim_set]
  opts
end

def parse_ranges(spec, count = nil)
  return nil if spec.nil?

  out = []
  spec.split(',').each do |part|
    error("Fields and positions are numbered from 1: 0") if part == '0'
    if part.include?('-')
      lo_s, hi_s = part.split('-', 2)
      lo = lo_s.empty? ? 1 : lo_s.to_i
      hi = hi_s.empty? ? count : hi_s.to_i
      error("Fields and positions are numbered from 1: 0") if lo <= 0 || (!hi.nil? && hi <= 0)
      error("High end of range less than low end of range: #{part}") if !hi.nil? && hi < lo
      if hi.nil?
        out << [:open, lo]
      else
        (lo..hi).each { |n| out << n - 1 }
      end
    else
      n = part.to_i
      error("Fields and positions are numbered from 1: 0") if n <= 0
      out << n - 1
    end
  end
  out
end

def expand_ranges(parsed, count)
  return nil if parsed.nil?

  parsed.flat_map do |x|
    if x.is_a?(Array) && x[0] == :open
      start = x[1] - 1
      start < count ? (start...count).to_a : []
    else
      x < count ? [x] : []
    end
  end
end

def split_record(record, opts)
  if opts[:literal]
    record.split(opts[:delimiter], -1)
  else
    record.split(Regexp.new(opts[:delimiter]), -1)
  end
end

def matching_headers(headers, selectors, regex_mode)
  result = []
  any = false
  missing = []
  selectors.each do |sel|
    matches = if regex_mode
                re = Regexp.new(sel)
                headers.each_index.select { |idx| headers[idx] =~ re }
              else
                headers.each_index.select { |idx| headers[idx] == sel }
              end
    missing << sel if matches.empty?
    any ||= !matches.empty?
    result.concat(matches)
  end
  [result, any, missing]
end

def unique_order(indices)
  seen = {}
  indices.each_with_object([]) do |idx, ary|
    next if seen[idx]
    seen[idx] = true
    ary << idx
  end
end

def open_input(path, decompress)
  if path.nil?
    return [$stdin.read, 'stdin']
  end
  error("No such file or directory (os error 2)") unless File.exist?(path)
  data = if decompress && path.end_with?('.gz')
           Zlib::GzipReader.open(path, &:read)
         else
           File.binread(path)
         end
  [data, path]
end

def process_data(data, opts, out)
  return true if data.empty?
  error('invalid data') unless data.end_with?("\n")

  lines = data.scan(/.*?\n/m)
  header_indices = nil
  explicit = opts[:fields] || !opts[:header_fields].empty?
  parsed_fields = parse_ranges(opts[:fields])
  parsed_exclude = parse_ranges(opts[:exclude])
  exclude_header_indices = []

  lines.each_with_index do |line, line_no|
    ending = line.end_with?("\r\n") ? "\r\n" : "\n"
    record = line[0...(line.length - ending.length)]
    fields = split_record(record, opts)

    if line_no == 0
      selected = []
      if opts[:header_fields].empty?
        selected = if parsed_fields
                     expand_ranges(parsed_fields, fields.length)
                   else
                     (0...fields.length).to_a
                   end
      else
        selected, any, missing = matching_headers(fields, opts[:header_fields], opts[:header_regex])
        error('No headers matched') unless any
        error(%(Header not found: "#{missing.first}")) unless missing.empty?
        selected.concat(expand_ranges(parsed_fields, fields.length) || [])
      end

      unless opts[:exclude_headers].empty?
        exclude_header_indices, = matching_headers(fields, opts[:exclude_headers], opts[:header_regex])
      end

      exclusions = (expand_ranges(parsed_exclude, fields.length) || []) + exclude_header_indices
      header_indices = unique_order(selected).reject { |idx| exclusions.include?(idx) }
    end

    if header_indices.empty? && explicit
      next
    end

    vals = header_indices.map { |idx| fields[idx] || '' }
    out.write(vals.join(opts[:output_delim]))
    out.write(ending)
  end
  true
end

begin
  opts = parse_args(ARGV)
  output_io = if opts[:output]
                File.open(opts[:output], 'wb')
              else
                $stdout
              end
  writer = opts[:compress] ? Zlib::GzipWriter.new(output_io, opts[:compression_level] || Zlib::DEFAULT_COMPRESSION) : output_io
  paths = opts[:inputs].empty? ? [nil] : opts[:inputs]
  paths.each do |path|
    data, = open_input(path, opts[:decompress])
    process_data(data, opts, writer)
  end
  writer.close if opts[:compress]
  output_io.close if opts[:output] && !output_io.closed?
rescue HckError => e
  warn "[#{Time.now.utc.strftime('%Y-%m-%dT%H:%M:%SZ')} ERROR hck] #{e.message}" if e.status == 1
  warn e.message if e.status != 1
  exit e.status
rescue RegexpError => e
  warn "[#{Time.now.utc.strftime('%Y-%m-%dT%H:%M:%SZ')} ERROR hck] #{e.message}"
  exit 1
rescue Errno::ENOENT
  warn "[#{Time.now.utc.strftime('%Y-%m-%dT%H:%M:%SZ')} ERROR hck] No such file or directory (os error 2)"
  exit 1
end
