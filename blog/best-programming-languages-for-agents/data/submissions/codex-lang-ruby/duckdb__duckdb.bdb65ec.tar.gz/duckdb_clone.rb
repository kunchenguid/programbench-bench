#!/usr/bin/env ruby
# frozen_string_literal: true

require 'yaml'
require 'shellwords'

VERSION = "v0.0.1 (Unknown Version) 780a7396"

class TokenStream
  def initialize(s)
    @tokens = s.scan(/'(?:''|[^'])*'|"(?:[^"]|"")*"|>=|<=|<>|!=|\|\||[(),*+\-\/%=<>]|\bAND\b|\bOR\b|\bNOT\b|\bIS\b|\bNULL\b|[A-Za-z_][A-Za-z0-9_]*|\d+\.\d+|\d+/i)
    @i = 0
  end
  def peek = @tokens[@i]
  def get = @tokens[@i].tap { @i += 1 }
  def eat(x)
    return false unless peek && peek.downcase == x.downcase
    @i += 1
    true
  end
end

class ExprParser
  def initialize(text)
    @ts = TokenStream.new(text.to_s.strip)
  end
  def parse = parse_or
  def parse_or
    left = parse_and
    while @ts.eat('or')
      right = parse_and
      left = [:or, left, right]
    end
    left
  end
  def parse_and
    left = parse_cmp
    while @ts.eat('and')
      right = parse_cmp
      left = [:and, left, right]
    end
    left
  end
  def parse_cmp
    left = parse_add
    if @ts.eat('is')
      @ts.eat('not') ? [:notnull, left] : (@ts.eat('null'); [:isnull, left])
    elsif %w[= <> != < > <= >=].include?(@ts.peek.to_s)
      op = @ts.get
      [:cmp, op, left, parse_add]
    else
      left
    end
  end
  def parse_add
    left = parse_mul
    while %w[+ - ||].include?(@ts.peek.to_s)
      op = @ts.get
      left = [:bin, op, left, parse_mul]
    end
    left
  end
  def parse_mul
    left = parse_unary
    while %w[* / %].include?(@ts.peek.to_s)
      op = @ts.get
      left = [:bin, op, left, parse_unary]
    end
    left
  end
  def parse_unary
    return [:neg, parse_unary] if @ts.eat('-')
    return [:not, parse_unary] if @ts.eat('not')
    parse_primary
  end
  def parse_primary
    tok = @ts.get
    return [:lit, nil] if tok.nil? || tok.downcase == 'null'
    return [:lit, true] if tok.downcase == 'true'
    return [:lit, false] if tok.downcase == 'false'
    if tok == '('
      e = parse_or
      @ts.eat(')')
      return e
    end
    if tok.start_with?("'")
      return [:lit, tok[1...-1].gsub("''", "'")]
    end
    return [:lit, tok.to_f] if tok =~ /^\d+\.\d+$/
    return [:lit, tok.to_i] if tok =~ /^\d+$/
    if @ts.peek == '('
      @ts.get
      args = []
      unless @ts.peek == ')'
        loop do
          args << parse_or
          break unless @ts.eat(',')
        end
      end
      @ts.eat(')')
      return [:func, tok.downcase, args]
    end
    [:col, tok.gsub(/^"|"$/, '')]
  end
end

class MiniDuck
  attr_accessor :mode, :headers, :separator, :newline, :nullvalue, :bail, :echo

  def initialize(dbfile)
    @dbfile = dbfile || ':memory:'
    @mode = 'duckbox'
    @headers = true
    @separator = '|'
    @newline = "\n"
    @nullvalue = 'NULL'
    @bail = false
    @echo = false
    @tables = {}
    load_db
  end

  def load_db
    return if @dbfile == ':memory:' || !File.exist?(@dbfile) || File.size(@dbfile).zero?
    data = YAML.load_file(@dbfile)
    @tables = data['tables'] || {}
  rescue StandardError
    @tables = {}
  end

  def save_db
    return if @dbfile == ':memory:'
    File.write(@dbfile, { 'tables' => @tables }.to_yaml)
  end

  def execute_script(script)
    rc = 0
    split_statements(script).each do |stmt|
      next if stmt.strip.empty?
      puts stmt if @echo
      begin
        if stmt.lstrip.start_with?('.')
          handle_meta(stmt.strip)
        else
          res = execute_sql(stmt.strip)
          render(res) if res
        end
      rescue SystemExit
        raise
      rescue StandardError => e
        warn e.message
        rc = 1
        break if @bail
      end
    end
    save_db
    rc
  end

  def split_statements(s)
    out = []
    cur = +''
    quote = false
    s.to_s.each_char do |ch|
      if ch == "'"
        quote = !quote
        cur << ch
      elsif ch == ';' && !quote
        out << cur
        cur = +''
      elsif ch == "\n" && !quote && cur.lstrip.start_with?('.')
        out << cur
        cur = +''
      else
        cur << ch
      end
    end
    out << cur unless cur.strip.empty?
    out
  end

  def handle_meta(line)
    parts = Shellwords.split(line) rescue line.split(/\s+/)
    cmd = parts.shift.to_s.sub(/^\./, '')
    case cmd
    when 'help'
      puts HELP_TEXT
    when 'version'
      puts VERSION
    when 'quit', 'exit'
      exit((parts[0] || 0).to_i)
    when 'mode'
      @mode = normalize_mode(parts[0]) if parts[0]
    when 'headers', 'header'
      @headers = parts[0].to_s.downcase != 'off'
    when 'separator'
      @separator = parts[0] if parts[0]
      @newline = parts[1] if parts[1]
    when 'nullvalue'
      @nullvalue = parts.join(' ')
    when 'tables'
      names = @tables.keys.sort
      puts names.join('  ') unless names.empty?
    when 'schema'
      pat = parts[0]
      @tables.keys.sort.each do |name|
        next if pat && name !~ /#{Regexp.escape(pat).gsub('%', '.*')}/
        t = @tables[name]
        cols = t['columns'].map.with_index { |c, i| "#{c} #{(t['types'][i] || 'VARCHAR').upcase}" }.join(', ')
        puts "CREATE TABLE #{name}(#{cols});"
      end
    when 'print'
      puts parts.join(' ')
    when 'read'
      execute_script(File.read(parts[0])) if parts[0]
    when 'show'
      puts "        echo: #{@echo ? 'on' : 'off'}"
      puts "     headers: #{@headers ? 'on' : 'off'}"
      puts "        mode: #{@mode}"
      puts "   separator: #{@separator.inspect}"
      puts "   nullvalue: #{@nullvalue.inspect}"
    else
      warn "Unknown command or invalid arguments:  \"#{line}\". Enter \".help\" for help"
    end
  end

  def execute_sql(sql)
    sql = sql.sub(/;+\s*\z/, '')
    case sql
    when /\Acreate\s+(?:or\s+replace\s+)?table\s+(?:if\s+not\s+exists\s+)?([A-Za-z_][\w]*)\s+as\s+(select\s+.+)\z/im
      name = Regexp.last_match(1)
      res = select(Regexp.last_match(2))
      @tables[name] = {
        'columns' => res[:cols],
        'types' => res[:types].map { |t| t == 'int32' ? 'integer' : t },
        'rows' => res[:rows].map { |r| res[:cols].zip(r).to_h }
      }
      nil
    when /\Acreate\s+(?:or\s+replace\s+)?table\s+(?:if\s+not\s+exists\s+)?([A-Za-z_][\w]*)\s*\((.*)\)\z/im
      name = Regexp.last_match(1)
      defs = split_commas(Regexp.last_match(2))
      cols = []
      types = []
      defs.each do |d|
        bits = d.strip.split(/\s+/, 3)
        cols << bits[0].gsub(/"/, '')
        types << (bits[1] || 'varchar').downcase
      end
      @tables[name] = { 'columns' => cols, 'types' => types, 'rows' => [] }
      nil
    when /\Adrop\s+table\s+(?:if\s+exists\s+)?([A-Za-z_][\w]*)\z/im
      @tables.delete(Regexp.last_match(1)); nil
    when /\Adelete\s+from\s+([A-Za-z_][\w]*)(?:\s+where\s+(.+))?\z/im
      delete_rows(Regexp.last_match(1), Regexp.last_match(2)); nil
    when /\Ainsert\s+into\s+([A-Za-z_][\w]*)(?:\s*\(([^)]*)\))?\s+values\s+(.+)\z/im
      insert_values(Regexp.last_match(1), Regexp.last_match(2), Regexp.last_match(3)); nil
    when /\Ashow\s+tables\z/im
      { cols: ['name'], rows: @tables.keys.sort.map { |n| [n] }, types: ['varchar'] }
    when /\A(?:describe|desc)\s+([A-Za-z_][\w]*)\z/im
      t = table!(Regexp.last_match(1))
      rows = t['columns'].each_with_index.map { |c, i| [c, (t['types'][i] || 'varchar').upcase, 'YES', nil, nil, nil] }
      { cols: %w[column_name column_type null key default extra], rows: rows, types: Array.new(6, 'varchar') }
    when /\Aselect\s+/im
      select(sql)
    else
      nil
    end
  end

  def delete_rows(name, where)
    t = table!(name)
    return t['rows'].clear unless where
    ast = ExprParser.new(where).parse
    t['rows'].reject! { |row| truthy(eval_expr(ast, row)) }
  end

  def insert_values(name, col_list, values)
    t = table!(name)
    target = col_list ? col_list.split(',').map { |c| c.strip.gsub(/"/, '') } : t['columns']
    tuple_strings(values).each do |tuple|
      vals = split_commas(tuple).map { |v| eval_expr(ExprParser.new(v).parse, {}) }
      row = {}
      t['columns'].each { |c| row[c] = nil }
      target.each_with_index { |c, i| row[c] = vals[i] }
      t['rows'] << row
    end
  end

  def select(sql)
    m = /\Aselect\s+(.+?)(?:\s+from\s+(.+?))?(?:\s+where\s+(.+?))?(?:\s+order\s+by\s+(.+?))?(?:\s+limit\s+(\d+))?\z/im.match(sql)
    raise "Parser Error: syntax error at or near \"#{sql.split(/\s+/)[0]}\"" unless m
    select_part, from_part, where_part, order_part, limit_part = m.captures
    rows, src_cols, src_types = source_rows(from_part)
    if where_part
      ast = ExprParser.new(where_part).parse
      rows = rows.select { |r| truthy(eval_expr(ast, r)) }
    end
    items = split_commas(select_part)
    if items.length == 1 && items[0].strip == '*'
      out_cols = src_cols
      out_rows = rows.map { |r| out_cols.map { |c| r[c] } }
      out_types = src_types
    elsif aggregate_items?(items)
      out_cols, out_rows, out_types = aggregate_result(items, rows)
    else
      parsed = items.map { |it| parse_select_item(it) }
      out_cols = parsed.map(&:first)
      out_rows = rows.map { |r| parsed.map { |_, ast| eval_expr(ast, r) } }
      out_types = infer_types(out_rows, out_cols)
    end
    if order_part
      ord = order_part.strip
      desc = ord.sub!(/\s+desc\z/i, '')
      ord.sub!(/\s+asc\z/i, '')
      idx = out_cols.index(ord.strip.gsub(/"/, '')) || 0
      out_rows = out_rows.sort_by { |r| r[idx] || '' }
      out_rows.reverse! if desc
    end
    out_rows = out_rows.first(limit_part.to_i) if limit_part
    { cols: out_cols, rows: out_rows, types: out_types }
  end

  def source_rows(from)
    return [[{}], [], []] unless from
    f = from.strip
    if f =~ /\Arange\s*\((\d+)\)\z/i
      n = Regexp.last_match(1).to_i
      return [(0...n).map { |i| { 'range' => i } }, ['range'], ['int64']]
    end
    if f =~ /\A\(values\s+(.+)\)\s+(?:as\s+)?[A-Za-z_][\w]*\s*\(([^)]*)\)\z/im
      cols = Regexp.last_match(2).split(',').map { |c| c.strip }
      rows = tuple_strings(Regexp.last_match(1)).map do |tuple|
        vals = split_commas(tuple).map { |v| eval_expr(ExprParser.new(v).parse, {}) }
        cols.zip(vals).to_h
      end
      return [rows, cols, infer_types(rows.map { |r| cols.map { |c| r[c] } }, cols)]
    end
    if f =~ /\A(?:read_csv_auto|read_csv)\s*\(\s*'([^']+)'\s*\)\z/i
      return csv_source(Regexp.last_match(1))
    end
    if f =~ /\A'([^']+\.(?:csv|tsv))'\z/i
      return csv_source(Regexp.last_match(1))
    end
    name = f.split(/\s+/).first.gsub(/"/, '')
    t = table!(name)
    [t['rows'].map(&:dup), t['columns'], t['types']]
  end

  def csv_source(path)
    lines = File.read(path).split(/\r?\n/)
    cols = parse_csv_line(lines.shift || '')
    rows = lines.reject(&:empty?).map do |line|
      vals = parse_csv_line(line)
      cols.each_with_index.to_h { |c, i| [c, cast_literal(vals[i])] }
    end
    [rows, cols, infer_types(rows.map { |r| cols.map { |c| r[c] } }, cols)]
  end

  def parse_select_item(item)
    if item =~ /\A(.+?)\s+as\s+("?[\w\s]+"?)\z/im
      expr = Regexp.last_match(1)
      label = Regexp.last_match(2).gsub(/"/, '')
      [label, ExprParser.new(expr).parse]
    else
      label = item.strip
      [label.gsub(/"/, ''), ExprParser.new(label).parse]
    end
  end

  def aggregate_items?(items)
    items.all? { |i| i =~ /\A(?:count|sum|avg|min|max)\s*\(/i || i =~ /\bas\s+/i && i =~ /\A(?:count|sum|avg|min|max)\s*\(/i }
  end

  def aggregate_result(items, rows)
    cols = []
    vals = []
    items.each do |item|
      label, _ = parse_select_item(item)
      body = item.sub(/\s+as\s+.+\z/i, '').strip
      func, arg = body.match(/\A(\w+)\s*\((.*)\)\z/i).captures
      xs = arg.strip == '*' ? rows : rows.map { |r| eval_expr(ExprParser.new(arg).parse, r) }.compact
      val = case func.downcase
            when 'count' then xs.length
            when 'sum' then xs.reduce(0) { |a, b| a + b.to_f }.then { |x| x == x.to_i ? x.to_i : x }
            when 'avg' then xs.empty? ? nil : xs.reduce(0) { |a, b| a + b.to_f } / xs.length
            when 'min' then xs.min
            when 'max' then xs.max
            end
      cols << label
      vals << val
    end
    [cols, [vals], infer_types([vals], cols)]
  end

  def eval_expr(ast, row)
    case ast[0]
    when :lit then ast[1]
    when :col
      row.fetch(ast[1]) { row.fetch(ast[1].downcase, nil) }
    when :neg then (eval_expr(ast[1], row) || 0) * -1
    when :not then !truthy(eval_expr(ast[1], row))
    when :and then truthy(eval_expr(ast[1], row)) && truthy(eval_expr(ast[2], row))
    when :or then truthy(eval_expr(ast[1], row)) || truthy(eval_expr(ast[2], row))
    when :isnull then eval_expr(ast[1], row).nil?
    when :notnull then !eval_expr(ast[1], row).nil?
    when :cmp
      a = eval_expr(ast[2], row); b = eval_expr(ast[3], row)
      return false if a.nil? || b.nil?
      { '=' => a == b, '!=' => a != b, '<>' => a != b, '<' => a < b, '>' => a > b, '<=' => a <= b, '>=' => a >= b }[ast[1]]
    when :bin
      a = eval_expr(ast[2], row); b = eval_expr(ast[3], row)
      return nil if a.nil? || b.nil?
      case ast[1]
      when '+' then a + b
      when '-' then a - b
      when '*' then a * b
      when '/' then b.to_f.zero? ? Float::INFINITY : a.to_f / b.to_f
      when '%' then a % b
      when '||' then a.to_s + b.to_s
      end
    when :func
      args = ast[2].map { |x| eval_expr(x, row) }
      case ast[1]
      when 'lower' then args[0].to_s.downcase
      when 'upper' then args[0].to_s.upcase
      when 'length', 'len' then args[0].to_s.length
      when 'abs' then args[0].to_f.abs
      when 'round' then args[0].to_f.round(args[1] || 0)
      when 'coalesce' then args.find { |x| !x.nil? }
      when 'sqrt' then Math.sqrt(args[0].to_f)
      else nil
      end
    end
  end

  def render(res)
    cols, rows = res.values_at(:cols, :rows)
    case @mode
    when 'csv' then render_csv(cols, rows)
    when 'json' then puts '[' + rows.map { |r| json_obj(cols.zip(r).to_h) }.join(',') + ']'
    when 'jsonlines' then rows.each { |r| puts json_obj(cols.zip(r).to_h) }
    when 'line' then rows.each { |r| cols.each_with_index { |c, i| puts "#{c.rjust(cols.map(&:length).max)} = #{fmt(r[i])}" }; puts if rows.length > 1 }
    when 'quote' then render_delimited(cols, rows, true)
    when 'list' then render_delimited(cols, rows, false)
    when 'html' then render_html(cols, rows)
    when 'ascii' then (cols + rows.flatten.map { |v| fmt(v) }).each { |x| puts x }
    when 'column' then render_grid(cols, rows, ascii: false, border: false)
    when 'table', 'markdown', 'box' then render_grid(cols, rows, style: @mode)
    else render_duckbox(cols, rows, res[:types])
    end
  end

  def render_csv(cols, rows)
    puts csv_line(cols) if @headers
    rows.each { |r| puts csv_line(r.map { |v| v.nil? ? @nullvalue : v }) }
  end

  def render_delimited(cols, rows, quote)
    q = ->(v) { quote && v.is_a?(String) ? "'#{v.gsub("'", "''")}'" : fmt(v) }
    puts cols.map { |c| quote ? "'#{c}'" : c }.join(@separator) if @headers
    rows.each { |r| puts r.map { |v| q.call(v) }.join(@separator) }
  end

  def render_html(cols, rows)
    if @headers
      puts '<tr>' + cols.map { |c| "<th>#{c}</th>" }.join("\n") + "\n</tr>"
    end
    rows.each { |r| puts '<tr>' + r.map { |v| "<td>#{fmt(v)}</td>" }.join("\n") + "\n</tr>" }
  end

  def render_grid(cols, rows, style: 'table', ascii: true, border: true)
    data = (@headers ? [cols] : []) + rows.map { |r| r.map { |v| fmt(v) } }
    widths = cols.each_index.map { |i| ([cols[i].length] + rows.map { |r| fmt(r[i]).length }).max }
    if style == 'markdown'
      puts '| ' + cols.each_with_index.map { |c, i| c.rjust(widths[i]) }.join(' | ') + ' |'
      puts '|' + widths.map { |w| '-' * [2, w].max + ':' }.join('|') + '|'
      rows.each { |r| puts '| ' + r.each_with_index.map { |v, i| fmt(v).rjust(widths[i]) }.join(' | ') + ' |' }
      return
    end
    chars = style == 'box' ? %w[┌ ┬ ┐ ├ ┼ ┤ └ ┴ ┘ │ ─] : %w[+ + + + + + + + + | -]
    line = ->(l, m, r) { l + widths.map { |w| chars[10] * (w + 2) }.join(m) + r }
    if border
      puts line.call(chars[0], chars[1], chars[2])
      puts chars[9] + cols.each_with_index.map { |c, i| " #{c.center(widths[i])} " }.join(chars[9]) + chars[9] if @headers
      puts line.call(chars[3], chars[4], chars[5]) if @headers
      rows.each { |r| puts chars[9] + r.each_with_index.map { |v, i| " #{fmt(v).rjust(widths[i])} " }.join(chars[9]) + chars[9] }
      puts line.call(chars[6], chars[7], chars[8])
    else
      data.each { |r| puts r.each_with_index.map { |v, i| fmt(v).ljust(widths[i]) }.join('  ') }
    end
  end

  def render_duckbox(cols, rows, types)
    types = types.map { |t| display_type(t) }
    widths = cols.each_index.map { |i| ([cols[i].length, (types[i] || 'varchar').length] + rows.map { |r| fmt(r[i]).length }).max }
    line = ->(l, m, r) { l + widths.map { |w| '─' * (w + 2) }.join(m) + r }
    puts line.call('┌', '┬', '┐')
    puts '│' + cols.each_with_index.map { |c, i| " #{c.center(widths[i])} " }.join('│') + '│'
    puts '│' + types.each_with_index.map { |t, i| " #{(t || 'varchar').center(widths[i])} " }.join('│') + '│'
    puts line.call('├', '┼', '┤')
    rows.each { |r| puts '│' + r.each_with_index.map { |v, i| " #{fmt(v).rjust(widths[i])} " }.join('│') + '│' }
    puts line.call('└', '┴', '┘')
  end

  def fmt(v)
    return @nullvalue if v.nil?
    return 'true' if v == true
    return 'false' if v == false
    return 'inf' if v.is_a?(Float) && v.infinite?
    v.to_s
  end

  def infer_types(rows, cols)
    cols.each_index.map do |i|
      v = rows.map { |r| r[i] }.find { |x| !x.nil? }
      case v
      when Integer then 'int32'
      when Float then 'double'
      when TrueClass, FalseClass then 'boolean'
      else 'varchar'
      end
    end
  end

  def display_type(t)
    case t.to_s.downcase
    when 'int', 'integer' then 'int32'
    when 'bigint' then 'int64'
    when 'bool' then 'boolean'
    when 'string', 'text' then 'varchar'
    else t || 'varchar'
    end
  end

  def table!(name)
    @tables[name] || @tables[name.downcase] || raise("Catalog Error: Table with name #{name} does not exist!")
  end

  def split_commas(s)
    out = []; cur = +''; depth = 0; quote = false
    s.each_char do |ch|
      quote = !quote if ch == "'"
      depth += 1 if ch == '(' && !quote
      depth -= 1 if ch == ')' && !quote
      if ch == ',' && depth.zero? && !quote
        out << cur.strip; cur = +''
      else
        cur << ch
      end
    end
    out << cur.strip
  end

  def tuple_strings(s)
    split_commas(s).map { |x| x.strip.sub(/\A\(/, '').sub(/\)\z/, '') }
  end

  def cast_literal(s)
    return nil if s.nil? || s.upcase == 'NULL'
    return s.to_i if s =~ /\A-?\d+\z/
    return s.to_f if s =~ /\A-?\d+\.\d+\z/
    s
  end

  def parse_csv_line(line)
    out = []
    cur = +''
    quote = false
    i = 0
    while i < line.length
      ch = line[i]
      if ch == '"'
        if quote && line[i + 1] == '"'
          cur << '"'
          i += 1
        else
          quote = !quote
        end
      elsif ch == ',' && !quote
        out << cur
        cur = +''
      else
        cur << ch
      end
      i += 1
    end
    out << cur
  end

  def csv_line(vals)
    vals.map do |v|
      s = v.to_s
      s =~ /[",\n]/ ? '"' + s.gsub('"', '""') + '"' : s
    end.join(',')
  end

  def json_obj(h)
    '{' + h.map { |k, v| json_value(k.to_s) + ':' + json_value(v) }.join(',') + '}'
  end

  def json_value(v)
    case v
    when nil then 'null'
    when Integer, Float then v.infinite? ? '"inf"' : v.to_s
    when TrueClass then 'true'
    when FalseClass then 'false'
    else '"' + v.to_s.gsub('\\', '\\\\\\').gsub('"', '\"').gsub("\n", '\n') + '"'
    end
  end

  def truthy(v) = !(v.nil? || v == false || v == 0)
  def normalize_mode(m) = ({ 'duckbox' => 'duckbox', 'box' => 'box', 'table' => 'table' }[m.to_s] || m.to_s)
end

HELP_TEXT = <<~TXT
  .about                                  Show information about DuckDB
  .bail on|off                            Stop after hitting an error.  Default OFF
  .echo on|off                            Turn command echo on or off
  .exit ?CODE?                            Exit this program with return-code CODE
  .headers on|off                         Turn display of headers on or off
  .help ?-all? ?PATTERN?                  Show help text for PATTERN
  .mode MODE ?TABLE?                      Set output mode
  .nullvalue STRING                       Use STRING in place of NULL values
  .print STRING...                        Print literal STRING
  .quit                                   Exit this program
  .read FILE                              Read input from FILE
  .schema ?PATTERN?                       Show the CREATE statements matching PATTERN
  .separator COL ?ROW?                    Change the column and row separators
  .show                                   Show the current values for various settings
  .tables ?TABLE?                         List names of tables matching LIKE pattern TABLE
  .version                                Show the version
TXT

def usage
  puts <<~TXT
    Usage: ./executable [OPTIONS] FILENAME [SQL]

    FILENAME is the name of a DuckDB database. A new database is created
    if the file does not previously exist.

    OPTIONS:
      -csv                     set output mode to 'csv'
      -json                    set output mode to 'json'
      -jsonlines               set output mode to 'jsonlines'
      -list                    set output mode to 'list'
      -table                   set output mode to 'table'
      -box                     set output mode to 'box'
      -markdown                set output mode to 'markdown'
      -column                  set output mode to 'column'
      -line                    set output mode to 'line'
      -quote                   set output mode to 'quote'
      -html                    set output mode to HTML
      -c COMMAND               run "COMMAND" and exit
      -s COMMAND               run "COMMAND" and exit
      -cmd COMMAND             run "COMMAND" before reading stdin
      -f FILENAME              read/process named file and exit
      -header                  turn headers on
      -noheader                turn headers off
      -separator SEP           set output column separator. Default: '|'
      -nullvalue TEXT          set text string for NULL values. Default 'NULL'
      -version                 show DuckDB version
      -help                    show help message
  TXT
end

args = ARGV.dup
dbfile = nil
sql = nil
pre = []
file_to_run = nil
format_mode = false
format_file = nil
no_stdin = false
cli = MiniDuck.new(':memory:')
until args.empty?
  a = args.shift
  case a
  when '-h', '-help', '--help' then usage; exit 0
  when '-version' then puts VERSION; exit 0
  when '-csv','-json','-jsonlines','-list','-table','-box','-markdown','-column','-line','-quote','-html','-ascii'
    cli.mode = a.sub(/^-/, '')
  when '-header' then cli.headers = true
  when '-noheader' then cli.headers = false
  when '-separator' then cli.separator = args.shift || '|'
  when '-newline' then cli.newline = args.shift || "\n"
  when '-nullvalue' then cli.nullvalue = args.shift || 'NULL'
  when '-bail' then cli.bail = true
  when '-echo' then cli.echo = true
  when '-c', '-s' then sql = args.shift || ''; break
  when '-cmd' then pre << (args.shift || '')
  when '-init' then pre << File.read(args.shift || '')
  when '-f' then file_to_run = args.shift
  when '-format' then format_mode = true
  when '-format-file' then format_file = args.shift; format_mode = true
  when '-no-stdin' then no_stdin = true
  when '-batch','-interactive','-no-init','-readonly','-safe','-unsigned','-unredacted'
    next
  else
    if a.start_with?('-')
      warn "Unknown Option Error: Unrecognized option '#{a}'"
      exit 1
    elsif dbfile.nil?
      dbfile = a
    else
      sql = ([a] + args).join(' ')
      break
    end
  end
end

if format_mode
  text = format_file ? File.read(format_file) : STDIN.read
  puts text.strip.gsub(/\s+/, ' ').gsub(/\s*,\s*/, ', ').gsub(/\s*;\s*$/, ';')
  exit 0
end

cli.instance_variable_set(:@dbfile, dbfile || ':memory:')
cli.load_db
pre.each { |p| cli.execute_script(p) }
if no_stdin
  cli.save_db
  exit 0
elsif file_to_run
  exit cli.execute_script(File.read(file_to_run))
elsif sql
  exit cli.execute_script(sql)
elsif !STDIN.tty?
  exit cli.execute_script(STDIN.read)
else
  print "D "
  exit cli.execute_script(STDIN.read)
end
