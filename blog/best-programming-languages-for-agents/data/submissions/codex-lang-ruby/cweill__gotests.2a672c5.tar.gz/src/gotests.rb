#!/usr/bin/env ruby
# frozen_string_literal: true

require "optparse"
require "fileutils"

Func = Struct.new(:name, :recv_name, :recv_type, :type_params, :params, :returns, keyword_init: true)
Param = Struct.new(:name, :type, keyword_init: true)

HELP = <<~TXT
  Usage of ./executable:
    -ai
      \tgenerate test cases using AI (requires Ollama)
    -ai-endpoint string
      \tOllama API endpoint (default "http://localhost:11434")
    -ai-max-cases int
      \tmaximum number of test cases to generate with AI (default 10)
    -ai-min-cases int
      \tminimum number of test cases to generate with AI (default 3)
    -ai-model string
      \tAI model to use for test generation (default "qwen2.5-coder:0.5b")
    -all
      \tgenerate tests for all functions and methods
    -excl string
      \tregexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all
    -exported
      \tgenerate tests for exported functions and methods. Takes precedence over -only and -all
    -i\tprint test inputs in error messages
    -named
      \tswitch table tests from using slice to map (with test name for the key)
    -nosubtests
      \tdisable generating tests using the Go 1.7 subtests feature
    -only string
      \tregexp. generate tests for functions and methods that match only. Takes precedence over -all
    -parallel
      \tenable generating parallel subtests using the Go 1.7 feature
    -template string
      \toptional. Specify custom test code templates, e.g. testify. This can also be set via environment variable GOTESTS_TEMPLATE
    -template_dir string
      \toptional. Path to a directory containing custom test code templates. Takes precedence over -template. This can also be set via environment variable GOTESTS_TEMPLATE_DIR
    -template_params string
      \tread external parameters to template by json with stdin
    -template_params_file string
      \tread external parameters to template by json with file
    -use_go_cmp
      \tuse cmp.Equal (google/go-cmp) instead of reflect.DeepEqual
    -version
      \tprint version information and exit
    -w\twrite output to (test) files instead of stdout
TXT

def usage_error(msg, code = 2)
  puts msg
  exit code
end

def parse_args(argv)
  opts = {
    all: false, exported: false, only: nil, excl: nil, write: false,
    named: false, nosubtests: false, parallel: false, inputs: false,
    use_go_cmp: false
  }
  i = 0
  paths = []
  while i < argv.length
    a = argv[i]
    case a
    when "--help", "-h"
      print HELP
      exit 0
    when "-version"
      puts "gotests v0.0.0-20260303205902-f3b63d74369a"
      puts "Go version: go1.24.5"
      puts "Git commit: f3b63d74369a8c405a9a3990a656a278a4f9096f"
      puts "Build time: 2026-03-03T20:59:02Z"
      exit 0
    when "-all" then opts[:all] = true
    when "-exported" then opts[:exported] = true
    when "-w" then opts[:write] = true
    when "-named" then opts[:named] = true
    when "-nosubtests" then opts[:nosubtests] = true
    when "-parallel" then opts[:parallel] = true
    when "-i" then opts[:inputs] = true
    when "-use_go_cmp" then opts[:use_go_cmp] = true
    when "-ai" then opts[:ai] = true
    when "-only", "-excl", "-template", "-template_dir", "-template_params", "-template_params_file", "-ai-model", "-ai-endpoint", "-ai-min-cases", "-ai-max-cases"
      usage_error("flag needs an argument: #{a}") if i + 1 >= argv.length
      key = a.delete_prefix("-").tr("-", "_").to_sym
      opts[key] = argv[i + 1]
      i += 1
    else
      if a.start_with?("-")
        puts "flag provided but not defined: #{a}"
        print HELP
        exit 2
      end
      paths << a
    end
    i += 1
  end
  [opts, paths]
end

def strip_comments(src)
  src.gsub(%r{//.*$}, "").gsub(%r{/\*.*?\*/}m, "")
end

def split_top(s, sep = ",")
  out = []
  cur = +""
  stack = []
  s.each_char do |ch|
    case ch
    when "(", "[", "{"
      stack << ch
    when ")"
      stack.pop if stack[-1] == "("
    when "]"
      stack.pop if stack[-1] == "["
    when "}"
      stack.pop if stack[-1] == "{"
    end
    if ch == sep && stack.empty?
      out << cur.strip
      cur = +""
    else
      cur << ch
    end
  end
  out << cur.strip unless cur.strip.empty?
  out
end

def find_balanced(src, start, open_ch, close_ch)
  depth = 0
  i = start
  while i < src.length
    ch = src[i]
    depth += 1 if ch == open_ch
    depth -= 1 if ch == close_ch
    return i if depth.zero?
    i += 1
  end
  nil
end

def parse_params(s, type_map = {})
  parts = split_top(s)
  params = []
  anon = 0
  pending = []
  parts.each do |part|
    next if part.empty?
    if part =~ /\A[A-Za-z_]\w*\z/
      pending << part
      next
    end
    toks = part.split(/\s+/)
    if toks.length >= 2 && toks[0] !~ /^[\*\[\]<>~]/
      names = pending + toks[0..-2].join(" ").split(/\s*,\s*/)
      pending = []
      typ = toks[-1]
      names.each { |n| params << Param.new(name: n.gsub(/\W/, ""), type: concrete_type(typ, type_map)) unless n.empty? }
    else
      pending.each do |n|
        anon += 1
        params << Param.new(name: n, type: concrete_type(part, type_map))
      end
      pending = []
      anon += 1
      params << Param.new(name: "arg#{anon}", type: concrete_type(part, type_map))
    end
  end
  pending.each do |n|
    anon += 1
    params << Param.new(name: n, type: "interface{}")
  end
  params
end

def parse_returns(s, type_map = {})
  s = s.to_s.strip
  return [] if s.empty?
  s = s[1...-1] if s.start_with?("(") && s.end_with?(")")
  returns = []
  pending = []
  split_top(s).each do |part|
    toks = part.split(/\s+/)
    if part =~ /\A[A-Za-z_]\w*\z/
      pending << part
      next
    end
    if toks.length >= 2 && toks[0] =~ /^[A-Za-z_]\w*$/
      count = pending.length + toks[0..-2].length
      typ = toks[-1]
      count.times { returns << concrete_type(typ, type_map) }
      pending = []
    else
      pending = []
      returns << concrete_type(part, type_map)
    end
  end
  pending.each { |p| returns << concrete_type(p, type_map) }
  returns
end

def parse_type_params(s)
  map = {}
  return map if s.to_s.empty?
  body = s[1...-1]
  split_top(body).each do |decl|
    toks = decl.split(/\s+/, 2)
    next unless toks.length == 2
    names = toks[0].split(/\s*,\s*/)
    concrete = case toks[1]
               when /comparable/ then "string"
               when /\bany\b/ then "int"
               when /\|/ then toks[1].split("|").first.strip.delete_prefix("~")
               else toks[1].strip.delete_prefix("~")
               end
    names.each { |n| map[n] = concrete }
  end
  map
end

def concrete_type(type, type_map)
  return nil if type.nil?
  t = type.to_s.strip
  type_map.each { |k, v| t = t.gsub(/\b#{Regexp.escape(k)}\b/, v) }
  t
end

def parse_structs(src, type_maps = {})
  structs = {}
  src.scan(/type\s+([A-Za-z_]\w*)(\[[^\]]+\])?\s+struct\s*\{(.*?)\}/m) do |name, tp, body|
    tm = parse_type_params(tp)
    fields = []
    body.gsub(";", "\n").lines.each do |line|
      line = line.strip
      next if line.empty?
      if line.include?(",")
        toks = line.split(/\s+/)
        typ = toks[-1]
        left = toks[0..-2].join(" ")
        left.split(/\s*,\s*/).each { |n| fields << Param.new(name: n, type: concrete_type(typ, tm)) }
      else
        toks = line.split(/\s+/)
        if toks.length >= 2
          fields << Param.new(name: toks[0], type: concrete_type(toks[1..].join(" "), tm))
        else
          fields << Param.new(name: toks[0].split(".").last.gsub(/^\*/, ""), type: concrete_type(toks[0], tm))
        end
      end
    end
    structs[name] = fields
  end
  structs
end

def parse_funcs(src)
  funcs = []
  i = 0
  while (m = src.index(/\bfunc\s+/, i))
    j = m + src[m..].match(/\bfunc\s+/)[0].length
    j += 1 while src[j] =~ /\s/
    recv_name = recv_type = nil
    if src[j] == "("
      k = find_balanced(src, j, "(", ")")
      recv = src[(j + 1)...k].strip
      rtoks = recv.split(/\s+/, 2)
      recv_name = rtoks.length == 2 ? rtoks[0] : rtoks[0].downcase[0]
      recv_type = rtoks.length == 2 ? rtoks[1] : rtoks[0]
      j = k + 1
      j += 1 while src[j] =~ /\s/
    end
    nm = src[j..].match(/\A([A-Za-z_]\w*)/)
    unless nm
      i = j + 1
      next
    end
    name = nm[1]
    j += name.length
    j += 1 while src[j] =~ /\s/
    tp = ""
    if src[j] == "["
      k = find_balanced(src, j, "[", "]")
      tp = src[j..k]
      j = k + 1
      j += 1 while src[j] =~ /\s/
    end
    next_i = j + 1
    if src[j] == "("
      k = find_balanced(src, j, "(", ")")
      params_s = src[(j + 1)...k]
      j = k + 1
      j += 1 while src[j] =~ /\s/
      ret = +""
      if src[j] == "("
        rk = find_balanced(src, j, "(", ")")
        ret = src[j..rk]
        j = rk + 1
      else
        while j < src.length && src[j] != "{" && src[j] != "\n"
          ret << src[j]
          j += 1
        end
      end
      tm = parse_type_params(tp)
      if recv_type && (recv_generics = recv_type[/\[(.*?)\]/, 1])
        recv_generics.split(/\s*,\s*/).each { |name| tm[name] ||= "string" }
      end
      funcs << Func.new(name: name, recv_name: recv_name, recv_type: concrete_type(recv_type, tm), type_params: tm,
                        params: parse_params(params_s, tm), returns: parse_returns(ret, tm))
      next_i = j + 1
    end
    i = next_i
  end
  funcs
end

def base_recv_type(t)
  t.to_s.gsub(/^\*/, "").sub(/\[.*\]/, "")
end

def recv_var(f)
  f.recv_name || base_recv_type(f.recv_type).downcase[0]
end

def exported?(name)
  name[0] =~ /[A-Z]/
end

def comparable?(typ)
  t = typ.strip
  return false if t.start_with?("[]", "map[", "func(")
  return false if t.include?("struct{")
  true
end

def err_type?(typ)
  typ.strip == "error"
end

def test_name(f)
  f.recv_type ? "Test#{base_recv_type(f.recv_type)}_#{f.name}" : "Test#{f.name}"
end

def display_name(f)
  f.recv_type ? "#{base_recv_type(f.recv_type)}.#{f.name}" : f.name
end

def call_name(f)
  gen = f.type_params.empty? ? "" : "[#{f.type_params.values.join(", ")}]"
  if f.recv_type
    "#{recv_var(f)}.#{f.name}"
  else
    "#{f.name}#{gen}"
  end
end

def arg_exprs(f)
  f.params.map { |p| p.type.start_with?("...") ? "tt.args.#{p.name}..." : "tt.args.#{p.name}" }
end

def fmt_args(f)
  return ["()", ""] unless @opts[:inputs] && !arg_exprs(f).empty?
  ["(#{Array.new(arg_exprs(f).length, "%v").join(", ")})", "#{arg_exprs(f).join(", ")}, "]
end

def field_lines(fields, indent)
  return [] if fields.empty?
  width = fields.map(&:name).map(&:length).max
  fields.map do |p|
    typ = p.type.start_with?("...") ? "[]#{p.type.delete_prefix("...")}" : p.type
    "#{"\t" * indent}#{p.name.ljust(width)} #{typ}"
  end
end

def generate_func(f, structs)
  lines = []
  lines << "func #{test_name(f)}(t *testing.T) {"
  lines << "\tt.Parallel()" if @opts[:parallel]
  recv_base = base_recv_type(f.recv_type)
  recv_fields = f.recv_type && structs[recv_base] ? structs[recv_base] : []
  if f.recv_type && !recv_fields.empty?
    lines << "\ttype fields struct {"
    lines.concat field_lines(recv_fields, 2)
    lines << "\t}"
  end
  unless f.params.empty?
    lines << "\ttype args struct {"
    lines.concat field_lines(f.params, 2)
    lines << "\t}"
  end
  returns = f.returns
  nonerr = returns.reject { |r| err_type?(r) }
  has_err = returns.any? { |r| err_type?(r) }
  fields = []
  fields << Param.new(name: "name", type: "string") unless @opts[:named]
  fields << Param.new(name: recv_var(f), type: f.recv_type) if f.recv_type && recv_fields.empty?
  fields << Param.new(name: "fields", type: "fields") if f.recv_type && !recv_fields.empty?
  fields << Param.new(name: "args", type: "args") unless f.params.empty?
  nonerr.each_with_index { |r, idx| fields << Param.new(name: idx.zero? ? "want" : "want#{idx}", type: r) }
  fields << Param.new(name: "wantErr", type: "bool") if has_err
  lines << if @opts[:named]
             "\ttests := map[string]struct {"
           else
             "\ttests := []struct {"
           end
  lines.concat field_lines(fields, 2)
  lines << "\t}{"
  lines << "\t\t// TODO: Add test cases."
  lines << "\t}"
  if @opts[:nosubtests]
    lines << (@opts[:named] ? "\tfor name, tt := range tests {" : (fields.length == 1 && fields[0].name == "name" ? "\tfor range tests {" : "\tfor _, tt := range tests {"))
    body_indent = 2
  else
    lines << (@opts[:named] ? "\tfor name, tt := range tests {" : "\tfor _, tt := range tests {")
    lines << (@opts[:named] ? "\t\tt.Run(name, func(t *testing.T) {" : "\t\tt.Run(tt.name, func(t *testing.T) {")
    lines << "\t\t\tt.Parallel()" if @opts[:parallel]
    body_indent = 3
  end
  emit_body(lines, f, recv_fields, returns, body_indent)
  unless @opts[:nosubtests]
    lines << "\t\t})"
  end
  lines << "\t}"
  lines << "}"
  lines.join("\n")
end

def emit_body(lines, f, recv_fields, returns, ind)
  t = "\t" * ind
  if f.recv_type
    rb = base_recv_type(f.recv_type)
    rv = recv_var(f)
    if !recv_fields.empty?
      lines << "#{t}#{rv} := #{rb}{"
      recv_fields.each { |fld| lines << "#{t}\t#{fld.name}: tt.fields.#{fld.name}," }
      lines << "#{t}}"
    elsif f.recv_type.start_with?("*")
      lines << "#{t}#{rv} := &#{f.recv_type.delete_prefix("*")}{}"
    else
      lines << "#{t}#{rv} := #{rb}{}"
    end
  end
  call = "#{call_name(f)}(#{arg_exprs(f).join(", ")})"
  if returns.empty?
    lines << "#{t}#{call}"
    return
  end
  has_err = returns.any? { |r| err_type?(r) }
  nonerr_indices = returns.each_index.reject { |idx| err_type?(returns[idx]) }
  vars = returns.each_index.map { |idx| err_type?(returns[idx]) ? "err" : (idx.zero? ? "got" : "got#{idx}") }
  if returns.length == 1 && !has_err
    r = returns[0]
    if comparable?(r)
      lines << "#{t}if got := #{call}; got != tt.want {"
      emit_error(lines, f, t, "", "got", "tt.want", 0)
      lines << "#{t}}"
    else
      cmp = @opts[:use_go_cmp] ? "!cmp.Equal(tt.want, got)" : "!reflect.DeepEqual(got, tt.want)"
      lines << "#{t}if got := #{call}; #{cmp} {"
      emit_error(lines, f, t, "", "got", "tt.want", 0, deep: true)
      lines << "#{t}}"
    end
    return
  end
  lines << "#{t}#{vars.join(", ")} := #{call}"
  if has_err
    lines << "#{t}if (err != nil) != tt.wantErr {"
    fmt, vals = fmt_args(f)
    if @opts[:nosubtests]
      lines << "#{t}\tt.Errorf(\"%q. #{display_name(f)}#{fmt} error = %v, wantErr %v\", tt.name, #{vals}err, tt.wantErr)"
      lines << "#{t}\tcontinue"
    else
      lines << "#{t}\tt.Fatalf(\"#{display_name(f)}#{fmt} error = %v, wantErr %v\", #{vals}err, tt.wantErr)"
    end
    lines << "#{t}}"
    lines << "#{t}if tt.wantErr {"
    lines << "#{t}\treturn"
    lines << "#{t}}"
  end
  nonerr_indices.each_with_index do |ret_idx, want_idx|
    r = returns[ret_idx]
    got = vars[ret_idx]
    want = want_idx.zero? ? "tt.want" : "tt.want#{want_idx}"
    label = if nonerr_indices.length > 1
              want_idx.zero? ? " got" : " got#{want_idx}"
            else
              ""
            end
    if comparable?(r)
      lines << "#{t}if #{got} != #{want} {"
      emit_error(lines, f, t, label, got, want, want_idx)
      lines << "#{t}}"
    else
      cmp = @opts[:use_go_cmp] ? "!cmp.Equal(#{want}, #{got})" : "!reflect.DeepEqual(#{got}, #{want})"
      lines << "#{t}if #{cmp} {"
      emit_error(lines, f, t, label, got, want, want_idx, deep: true)
      lines << "#{t}}"
    end
  end
end

def emit_error(lines, f, t, label, got, want, idx, deep: false)
  fmt, vals = fmt_args(f)
  name = display_name(f)
  prefix = @opts[:nosubtests] ? "%q. " : ""
  first_arg = @opts[:nosubtests] ? "tt.name, " : ""
  if deep && @opts[:use_go_cmp]
    lines << "#{t}\tt.Errorf(\"#{prefix}#{name}#{fmt}#{label} = %v, want %v\\ndiff=%s\", #{first_arg}#{vals}#{got}, #{want}, cmp.Diff(#{want}, #{got}))"
  else
    lines << "#{t}\tt.Errorf(\"#{prefix}#{name}#{fmt}#{label} = %v, want %v\", #{first_arg}#{vals}#{got}, #{want})"
  end
end

def render_file(pkg, funcs, structs)
  need_reflect = !@opts[:use_go_cmp] && funcs.any? { |f| f.returns.any? { |r| !err_type?(r) && !comparable?(r) } }
  need_cmp = @opts[:use_go_cmp] && funcs.any? { |f| f.returns.any? { |r| !err_type?(r) && !comparable?(r) } }
  out = +"package #{pkg}\n\n"
  imports = ["testing"]
  imports.unshift("reflect") if need_reflect
  if need_cmp
    out << "import (\n\t\"testing\"\n\n\t\"github.com/google/go-cmp/cmp\"\n)\n\n"
  elsif imports.length == 1
    out << "import \"testing\"\n\n"
  else
    out << "import (\n"
    imports.each { |im| out << "\t\"#{im}\"\n" }
    out << ")\n\n"
  end
  out << funcs.map { |f| generate_func(f, structs) }.join("\n\n")
  out << "\n"
  out
end

def output_path(path)
  path.sub(/\.go$/, "_test.go")
end

@opts, paths = parse_args(ARGV)
unless @opts[:all] || @opts[:exported] || @opts[:only] || @opts[:excl]
  usage_error("Please specify either the -only, -excl, -exported, or -all flag", 1)
end
begin
  only_re = @opts[:only] && Regexp.new(@opts[:only])
rescue RegexpError => e
  usage_error("Invalid -only regex: #{e.message}: `#{@opts[:only]}`", 1)
end
begin
  excl_re = @opts[:excl] && Regexp.new(@opts[:excl])
rescue RegexpError => e
  usage_error("Invalid -excl regex: #{e.message}: `#{@opts[:excl]}`", 1)
end

paths = ["."] if paths.empty?
paths.each do |path|
  files = if path.end_with?("/...")
            Dir.glob(File.join(path.delete_suffix("/..."), "**", "*.go")).reject { |f| f.end_with?("_test.go") }
          elsif File.directory?(path)
            Dir.glob(File.join(path, "*.go")).reject { |f| f.end_with?("_test.go") }
          else
            [path]
          end
  files.each do |file|
    next unless File.file?(file)
    src = strip_comments(File.read(file))
    pkg = src[/^\s*package\s+([A-Za-z_]\w*)/, 1] || "main"
    funcs = parse_funcs(src)
    structs = parse_structs(src)
    selected = funcs.select do |f|
      tn = f.name
      full = f.recv_type ? "#{base_recv_type(f.recv_type)}_#{f.name}" : f.name
      if excl_re
        !(tn =~ excl_re || full =~ excl_re)
      elsif @opts[:exported]
        exported?(tn)
      elsif only_re
        tn =~ only_re || full =~ only_re || test_name(f) =~ only_re
      else
        @opts[:all]
      end
    end
    selected.each { |f| puts "Generated #{test_name(f)}" }
    next if selected.empty?
    rendered = render_file(pkg, selected, structs)
    if @opts[:write]
      File.write(output_path(file), rendered)
    else
      print rendered
    end
  end
end
