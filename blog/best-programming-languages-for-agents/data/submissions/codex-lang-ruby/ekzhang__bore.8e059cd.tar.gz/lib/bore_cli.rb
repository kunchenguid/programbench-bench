#!/usr/bin/env ruby
# frozen_string_literal: true

require 'socket'
require 'securerandom'
require 'digest'
require 'thread'

CONTROL_PORT = 7835
VERSION = 'bore-cli 0.6.0'
DESC = 'A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls.'

def out(s = '')
  STDOUT.write(s)
  STDOUT.write("\n") unless s.end_with?("\n")
end

def err(s = '')
  STDERR.write(s)
  STDERR.write("\n") unless s.end_with?("\n")
end

def root_help
  out <<~TXT.chomp
    #{DESC}

    Usage: executable <COMMAND>

    Commands:
      local   Starts a local proxy to the remote server
      server  Runs the remote proxy server
      help    Print this message or the help of the given subcommand(s)

    Options:
      -h, --help     Print help
      -V, --version  Print version
  TXT
end

def local_help
  out <<~TXT.chomp
    Starts a local proxy to the remote server

    Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>

    Arguments:
      <LOCAL_PORT>  The local port to expose [env: BORE_LOCAL_PORT=]

    Options:
      -l, --local-host <HOST>  The local host to expose [default: localhost]
      -t, --to <TO>            Address of the remote server to expose local ports to [env: BORE_SERVER=]
      -p, --port <PORT>        Optional port on the remote server to select [default: 0]
      -s, --secret <SECRET>    Optional secret for authentication [env: BORE_SECRET]
      -h, --help               Print help
  TXT
end

def server_help
  out <<~TXT.chomp
    Runs the remote proxy server

    Usage: executable server [OPTIONS]

    Options:
          --min-port <MIN_PORT>          Minimum accepted TCP port number [env: BORE_MIN_PORT=] [default: 1024]
          --max-port <MAX_PORT>          Maximum accepted TCP port number [env: BORE_MAX_PORT=] [default: 65535]
      -s, --secret <SECRET>              Optional secret for authentication [env: BORE_SECRET]
          --bind-addr <BIND_ADDR>        IP address to bind to, clients must reach this [default: 0.0.0.0]
          --bind-tunnels <BIND_TUNNELS>  IP address where tunnels will listen on, defaults to --bind-addr
      -h, --help                         Print help
  TXT
end

def die_usage(msg, usage)
  err "error: #{msg}"
  err
  err usage
  err
  err "For more information, try '--help'."
  exit 2
end

def parse_int(value, name)
  Integer(value)
rescue ArgumentError
  err "error: invalid value '#{value}' for '#{name}': invalid digit found in string"
  err
  err "For more information, try '--help'."
  exit 2
end

def read_frame(io)
  buf = +''
  loop do
    c = io.read(1)
    raise EOFError, 'unexpected EOF' if c.nil?
    break if c == "\0"
    buf << c
  end
  parse_json_frame(buf)
end

def write_frame(io, obj)
  io.write(json_frame(obj))
  io.write("\0")
  io.flush
end

def json_escape(s)
  s.to_s.gsub('\\', '\\\\\\').gsub('"', '\\"')
end

def json_frame(obj)
  case obj
  when String
    %("#{json_escape(obj)}")
  when Integer
    obj.to_s
  when Hash
    k, v = obj.first
    %("#{json_escape(k)}":#{json_frame(v)})
  else
    obj.to_s
  end.then { |body| obj.is_a?(Hash) ? "{#{body}}" : body }
end

def parse_json_string(s)
  s.gsub(/\\(["\\])/, '\1')
end

def parse_json_frame(s)
  s = s.strip
  return parse_json_string(s[1...-1]) if s.start_with?('"') && s.end_with?('"')
  if s.start_with?('{') && s.end_with?('}')
    inner = s[1...-1]
    if inner =~ /\A"((?:\\.|[^"\\])*)":(.*)\z/m
      key = parse_json_string(Regexp.last_match(1))
      raw = Regexp.last_match(2).strip
      value = if raw.start_with?('"') && raw.end_with?('"')
                parse_json_string(raw[1...-1])
              else
                raw.to_i
              end
      return { key => value }
    end
  end
  s
end

def copy_pair(a, b)
  threads = []
  [[a, b], [b, a]].each do |src, dst|
    threads << Thread.new do
      begin
        loop do
          data = src.readpartial(16 * 1024)
          dst.write(data)
        end
      rescue EOFError, IOError, SystemCallError
      ensure
        begin
          dst.close_write
        rescue StandardError
          begin
            dst.close
          rescue StandardError
          end
        end
      end
    end
  end
  threads.each(&:join)
ensure
  [a, b].each { |s| s.close rescue nil }
end

def log_info(message)
  err message if ENV['RUST_LOG'] || ENV['BORE_LOG'] || true
end

def authenticate_server(sock, secret)
  return unless secret
  challenge = SecureRandom.uuid
  write_frame(sock, { 'Challenge' => challenge })
  msg = read_frame(sock)
  unless msg.is_a?(Hash) && msg['Authenticate'] == Digest::SHA256.hexdigest("#{challenge}:#{secret}")
    write_frame(sock, { 'Error' => 'invalid secret' }) rescue nil
    raise 'invalid secret'
  end
end

def authenticate_client(sock, secret)
  return nil unless IO.select([sock], nil, nil, 0.2)
  first = read_frame(sock)
  if first.is_a?(Hash) && first.key?('Challenge')
    if secret.nil? || secret.empty?
      write_frame(sock, { 'Hello' => 0 })
      raise 'server requires secret, but no secret was provided'
    end
    write_frame(sock, { 'Authenticate' => Digest::SHA256.hexdigest("#{first['Challenge']}:#{secret}") })
    return nil
  end
  first
end

class BoreServer
  def initialize(min_port:, max_port:, secret:, bind_addr:, bind_tunnels:)
    @min_port = min_port
    @max_port = max_port
    @secret = secret
    @bind_addr = bind_addr
    @bind_tunnels = bind_tunnels || bind_addr
    @pending = {}
    @pending_mutex = Mutex.new
    @pending_cv = ConditionVariable.new
  end

  def run
    server = TCPServer.new(@bind_addr, CONTROL_PORT)
    log_info "server listening addr=#{@bind_addr}"
    loop do
      sock = server.accept
      Thread.new(sock) { |s| handle_control(s) }
    end
  rescue Errno::EADDRINUSE => e
    err "Error: #{e.message}"
    exit 1
  end

  def handle_control(sock)
    authenticate_server(sock, @secret)
    msg = read_frame(sock)
    if msg.is_a?(Hash) && msg.key?('Connection')
      register_proxy(msg['Connection'], sock)
      return
    end
    unless msg.is_a?(Hash) && msg.key?('Hello')
      write_frame(sock, { 'Error' => 'expected hello' }) rescue nil
      sock.close
      return
    end
    start_client(sock, msg['Hello'].to_i)
  rescue StandardError => e
    err "Error: #{e.message}" if ENV['BORE_DEBUG']
    sock.close rescue nil
  end

  def register_proxy(id, sock)
    @pending_mutex.synchronize do
      @pending[id] = sock
      @pending_cv.broadcast
    end
    sleep
  ensure
    @pending_mutex.synchronize { @pending.delete(id) if @pending[id] == sock }
  end

  def start_client(control, requested)
    tunnel = open_tunnel(requested)
    port = tunnel.addr[1]
    write_frame(control, { 'Hello' => port })
    Thread.new do
      loop do
        sleep 1
        write_frame(control, 'Heartbeat')
      rescue StandardError
        break
      end
    end
    loop do
      incoming = tunnel.accept
      id = SecureRandom.uuid
      write_frame(control, { 'Connection' => id })
      proxy = wait_proxy(id)
      if proxy
        Thread.new(incoming, proxy) { |a, b| copy_pair(a, b) }
      else
        incoming.close rescue nil
      end
    end
  ensure
    tunnel.close rescue nil
    control.close rescue nil
  end

  def open_tunnel(requested)
    if requested && requested != 0
      raise "port #{requested} outside allowed range" if requested < @min_port || requested > @max_port
      return TCPServer.new(@bind_tunnels, requested)
    end
    (@min_port..@max_port).each do |p|
      begin
        return TCPServer.new(@bind_tunnels, p)
      rescue Errno::EADDRINUSE, Errno::EACCES
      end
    end
    raise 'no available ports'
  end

  def wait_proxy(id)
    deadline = Time.now + 10
    @pending_mutex.synchronize do
      loop do
        sock = @pending.delete(id)
        return sock if sock
        left = deadline - Time.now
        return nil if left <= 0
        @pending_cv.wait(@pending_mutex, left)
      end
    end
  end
end

class BoreLocal
  def initialize(local_port:, local_host:, to:, remote_port:, secret:)
    @local_port = local_port
    @local_host = local_host
    @to = to
    @remote_port = remote_port
    @secret = secret
  end

  def run
    control = TCPSocket.new(@to, CONTROL_PORT)
    first = authenticate_client(control, @secret)
    write_frame(control, { 'Hello' => @remote_port }) unless first
    msg = first || read_frame(control)
    if msg.is_a?(Hash) && msg.key?('Error')
      err "Error: #{msg['Error']}"
      exit 1
    end
    remote = msg['Hello']
    log_info "connected to server remote_port=#{remote}"
    log_info "listening at #{@to}:#{remote}"
    loop do
      frame = read_frame(control)
      next if frame == 'Heartbeat'
      next unless frame.is_a?(Hash) && frame.key?('Connection')
      id = frame['Connection']
      Thread.new(id) { |conn_id| proxy_connection(conn_id) }
    end
  rescue Errno::ECONNREFUSED => e
    err "Error: could not connect to #{@to}:#{CONTROL_PORT}"
    err
    err "Caused by:"
    err "    #{e.message}"
    exit 1
  rescue EOFError
    err 'Error: unexpected EOF'
    exit 1
  rescue StandardError => e
    err "Error: #{e.message}"
    exit 1
  end

  def proxy_connection(id)
    remote = TCPSocket.new(@to, CONTROL_PORT)
    first = authenticate_client(remote, @secret)
    raise 'unexpected server frame' if first
    write_frame(remote, { 'Connection' => id })
    local = TCPSocket.new(@local_host, @local_port)
    copy_pair(local, remote)
  rescue StandardError => e
    err "Error: #{e.message}" if ENV['BORE_DEBUG']
  end
end

def parse_local(argv)
  local_host = 'localhost'
  to = ENV['BORE_SERVER']
  remote_port = 0
  secret = ENV['BORE_SECRET']
  positional = []
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when '-h', '--help'
      local_help
      exit 0
    when '-l', '--local-host'
      i += 1; local_host = argv[i]
    when '-t', '--to'
      i += 1; to = argv[i]
    when '-p', '--port'
      i += 1; remote_port = parse_int(argv[i], '--port <PORT>')
    when '-s', '--secret'
      i += 1; secret = argv[i]
    else
      positional << a
    end
    i += 1
  end
  positional << ENV['BORE_LOCAL_PORT'] if positional.empty? && ENV['BORE_LOCAL_PORT']
  unless to
    die_usage('the following required arguments were not provided:' + "\n  --to <TO>", 'Usage: executable local --to <TO> <LOCAL_PORT>')
  end
  if positional.empty?
    die_usage('the following required arguments were not provided:' + "\n  <LOCAL_PORT>", 'Usage: executable local --to <TO> <LOCAL_PORT>')
  end
  local_port = parse_int(positional[0], '<LOCAL_PORT>')
  BoreLocal.new(local_port: local_port, local_host: local_host, to: to, remote_port: remote_port, secret: secret).run
end

def parse_server(argv)
  min_port = (ENV['BORE_MIN_PORT'] || '1024').to_i
  max_port = (ENV['BORE_MAX_PORT'] || '65535').to_i
  secret = ENV['BORE_SECRET']
  bind_addr = '0.0.0.0'
  bind_tunnels = nil
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when '-h', '--help'
      server_help
      exit 0
    when '--min-port'
      i += 1; min_port = parse_int(argv[i], '--min-port <MIN_PORT>')
    when '--max-port'
      i += 1; max_port = parse_int(argv[i], '--max-port <MAX_PORT>')
    when '-s', '--secret'
      i += 1; secret = argv[i]
    when '--bind-addr'
      i += 1; bind_addr = argv[i]
    when '--bind-tunnels'
      i += 1; bind_tunnels = argv[i]
    else
      die_usage("unexpected argument '#{a}' found", 'Usage: executable server [OPTIONS]')
    end
    i += 1
  end
  BoreServer.new(min_port: min_port, max_port: max_port, secret: secret, bind_addr: bind_addr, bind_tunnels: bind_tunnels).run
end

cmd = ARGV.shift
case cmd
when nil
  root_help
when '-h', '--help', 'help'
  if ARGV[0] == 'local'
    local_help
  elsif ARGV[0] == 'server'
    server_help
  else
    root_help
  end
when '-V', '--version'
  out VERSION
when 'local'
  parse_local(ARGV)
when 'server'
  parse_server(ARGV)
else
  err "error: unrecognized subcommand '#{cmd}'"
  err
  err 'Usage: executable <COMMAND>'
  err
  err "For more information, try '--help'."
  exit 2
end
