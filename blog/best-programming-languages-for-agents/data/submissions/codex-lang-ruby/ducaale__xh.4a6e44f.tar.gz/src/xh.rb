#!/usr/bin/env ruby
# frozen_string_literal: true

require 'uri'
require 'net/http'
require 'openssl'
require 'base64'

VERSION = "0.25.3"

HELP = <<~TXT
  xh is a friendly and fast tool for sending HTTP requests

  Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...

  Arguments:
    <[METHOD] URL>     The request URL, preceded by an optional HTTP method
    [REQUEST_ITEM]...  Optional key-value pairs to be included in the request.

  Options:
    -j, --json
            (default) Serialize data items from the command line as a JSON object
    -f, --form
            Serialize data items from the command line as form fields
        --multipart
            Like --form, but force a multipart/form-data request even without files
        --raw <RAW>
            Pass raw request data without extra processing
        --pretty <STYLE>
            Controls output processing [possible values: all, colors, format, none]
        --format-options <FORMAT_OPTIONS>
            Set output formatting options
    -s, --style <THEME>
            Output coloring style [possible values: auto, solarized, monokai, fruity]
        --response-charset <ENCODING>
            Override the response encoding for terminal display purposes
        --response-mime <MIME_TYPE>
            Override the response mime type for coloring and formatting for the terminal
    -p, --print <FORMAT>
            String specifying what the output should contain
    -h, --headers
            Print only the response headers. Shortcut for --print=h
    -b, --body
            Print only the response body. Shortcut for --print=b
    -m, --meta
            Print only the response metadata. Shortcut for --print=m
    -v, --verbose...
            Print the whole request as well as the response
        --debug
            Print full error stack traces and debug log messages
        --all
            Show any intermediary requests/responses while following redirects with --follow
    -P, --history-print <FORMAT>
            The same as --print but applies only to intermediary requests/responses
    -q, --quiet...
            Do not print to stdout or stderr
    -S, --stream
            Always stream the response body
    -x, --compress...
            Content compressed (encoded) with Deflate algorithm
    -o, --output <FILE>
            Save output to FILE instead of stdout
    -d, --download
            Download the body to a file instead of printing it
    -c, --continue
            Resume an interrupted download. Requires --download and --output
        --session <FILE>
            Create, or reuse and update a session
        --session-read-only <FILE>
            Create or read a session without updating it from the request/response exchange
    -A, --auth-type <AUTH_TYPE>
            Specify the auth mechanism [possible values: basic, bearer, digest]
    -a, --auth <USER[:PASS] | TOKEN>
            Authenticate as USER with PASS (-A basic|digest) or with TOKEN (-A bearer)
        --ignore-netrc
            Do not use credentials from .netrc
        --offline
            Construct HTTP requests without sending them anywhere
        --check-status
            (default) Exit with an error status code if the server replies with an error
    -F, --follow
            Do follow redirects
        --max-redirects <NUM>
            Number of redirects to follow. Only respected if --follow is used
        --timeout <SEC>
            Connection timeout of the request
        --proxy <PROTOCOL:URL>
            Use a proxy for a protocol. For example: --proxy https:http://proxy.host:8080
        --verify <VERIFY>
            If "no", skip SSL verification. If a file path, use it as a CA bundle
        --cert <FILE>
            Use a client side certificate for SSL
        --cert-key <FILE>
            A private key file to use with --cert
        --ssl <VERSION>
            Force a particular TLS version [possible values: auto, tls1, tls1.1, tls1.2, tls1.3]
        --https
            Make HTTPS requests if not specified in the URL
        --http-version <VERSION>
            HTTP version to use [possible values: 1.0, 1.1, 2, 2-prior-knowledge, 3-prior-knowledge]
        --resolve <HOST:ADDRESS>
            Override DNS resolution for specific domain to a custom IP
        --interface <NAME>
            Bind to a network interface or local IP address
    -4, --ipv4
            Resolve hostname to ipv4 addresses only
    -6, --ipv6
            Resolve hostname to ipv6 addresses only
        --unix-socket <FILE>
            Connect using a Unix domain socket
    -I, --ignore-stdin
            Do not attempt to read stdin
        --curl
            Print a translation to a curl command
        --curl-long
            Use the long versions of curl's flags
        --generate <KIND>
            Generate shell completions or man pages
        --help
            Print help
    -V, --version
            Print version

  Each option can be reset with a --no-OPTION argument.

  Run "xh help" for more complete documentation.
TXT

def die(msg, code = 2)
  warn msg
  exit code
end

def shell_quote(s)
  s = s.to_s
  return "''" if s.empty?
  return s if s.match?(/\A[A-Za-z0-9_\/:.,=+-]+\z/)
  "'" + s.gsub("'", "'\"'\"'") + "'"
end

def shell_single(s)
  "'" + s.to_s.gsub("'", "'\"'\"'") + "'"
end

def json_escape(s)
  s.to_s.gsub(/["\\\b\f\n\r\t]/) do |c|
    { '"' => '\"', '\\' => '\\\\', "\b" => '\\b', "\f" => '\\f', "\n" => '\\n', "\r" => '\\r', "\t" => '\\t' }[c]
  end
end

def to_json(v)
  case v
  when Hash
    "{" + v.map { |k, val| "\"#{json_escape(k)}\":#{to_json(val)}" }.join(",") + "}"
  when Array
    "[" + v.map { |x| to_json(x) }.join(",") + "]"
  when String
    "\"#{json_escape(v)}\""
  when Numeric
    v.to_s
  when TrueClass
    "true"
  when FalseClass
    "false"
  when NilClass
    "null"
  else
    "\"#{json_escape(v)}\""
  end
end

def parse_literal(s)
  t = s.strip
  return true if t == 'true'
  return false if t == 'false'
  return nil if t == 'null'
  return t.to_i if t.match?(/\A-?\d+\z/)
  return t.to_f if t.match?(/\A-?\d+\.\d+([eE][+-]?\d+)?\z/)
  return t[1...-1] if t.start_with?('"') && t.end_with?('"')
  return t.split(',').map { |x| parse_literal(x) } if t.start_with?('[') && t.end_with?(']') && !t.include?('{')
  t
end

def form_encode(pairs)
  pairs.map { |k, v| "#{URI.encode_www_form_component(k)}=#{URI.encode_www_form_component(v.to_s)}" }.join('&')
end

def find_sep(item)
  esc = false
  (0...item.length).each do |i|
    ch = item[i]
    if esc
      esc = false
      next
    end
    if ch == "\\"
      esc = true
      next
    end
    return [i, '=='] if item[i, 2] == '=='
    return [i, ':='] if item[i, 2] == ':='
    return [i, '='] if ch == '='
    return [i, ':'] if ch == ':'
    return [i, ';'] if ch == ';' && i == item.length - 1
    return [i, '@'] if ch == '@' && i > 0
  end
  nil
end

def unescape_key(s)
  s.gsub(/\\([:=@;])/, '\1')
end

def normalize_url(raw, https_default = false)
  s = raw.dup
  s = "localhost#{s}" if s.start_with?(':')
  scheme = https_default ? 'https://' : 'http://'
  s = scheme + s unless s.match?(/\A[A-Za-z][A-Za-z0-9+.-]*:\/\//)
  u = URI.parse(s)
  u.path = '/' if u.path.nil? || u.path.empty?
  u
rescue URI::InvalidURIError
  die "error: invalid value '#{raw}' for '<[METHOD] URL>'"
end

opts = {
  mode: :json, raw: nil, print: nil, verbose: 0, offline: false, curl: false,
  curl_long: false, ignore_stdin: false, output: nil, download: false,
  follow: false, check_status: true, auth_type: 'basic', auth: nil,
  timeout: nil, verify: true, quiet: 0, https: false
}

args = ARGV.dup
if args == ['help']
  puts HELP.sub("xh is a friendly and fast tool", "xh is a friendly and fast tool")
  exit 0
end

pos = []
i = 0
while i < args.length
  a = args[i]
  case a
  when '--help'
    puts HELP
    exit 0
  when '-V', '--version'
    puts "xh #{VERSION}"
    puts "-native-tls +rustls"
    exit 0
  when /\A--generate(?:=(.+))?\z/
    kind = Regexp.last_match(1) || args[i += 1]
    if kind == 'man'
      path = File.join(__dir__, '..', 'doc', 'xh.1')
      if File.exist?(path)
        print File.read(path).sub(/0\.25\.\d+/, VERSION)
      else
        puts ".TH XH 1 2026-05-28 #{VERSION} \"User Commands\"\n.SH NAME\nxh \\- Friendly and fast tool for sending HTTP requests"
      end
    else
      puts "# completion for executable (#{kind})"
    end
    exit 0
  when '-j', '--json'
    opts[:mode] = :json
  when '-f', '--form'
    opts[:mode] = :form
  when '--multipart'
    opts[:mode] = :multipart
  when /\A--raw(?:=(.*))?\z/
    opts[:raw] = Regexp.last_match(1) || args[i += 1]
  when '-p', '--print'
    opts[:print] = args[i += 1]
  when /\A--print=(.*)\z/
    opts[:print] = Regexp.last_match(1)
  when '-h', '--headers'
    opts[:print] = 'h'
  when '-b', '--body'
    opts[:print] = 'b'
  when '-m', '--meta'
    opts[:print] = 'm'
  when '-v', '--verbose'
    opts[:verbose] += 1
  when /\A-vv+\z/
    opts[:verbose] += a.length - 1
  when '--offline'
    opts[:offline] = true
  when '--curl'
    opts[:curl] = true
  when '--curl-long'
    opts[:curl] = true
    opts[:curl_long] = true
  when '-I', '--ignore-stdin'
    opts[:ignore_stdin] = true
  when '-o', '--output'
    opts[:output] = args[i += 1]
  when /\A--output=(.*)\z/
    opts[:output] = Regexp.last_match(1)
  when '-d', '--download'
    opts[:download] = true
    opts[:follow] = true
  when '-F', '--follow'
    opts[:follow] = true
  when '-a', '--auth'
    opts[:auth] = args[i += 1]
  when /\A--auth=(.*)\z/
    opts[:auth] = Regexp.last_match(1)
  when '-A', '--auth-type'
    opts[:auth_type] = args[i += 1]
  when /\A--auth-type=(.*)\z/
    opts[:auth_type] = Regexp.last_match(1)
  when '--https'
    opts[:https] = true
  when '-q', '--quiet'
    opts[:quiet] += 1
  when /\A-q+\z/
    opts[:quiet] += a.length - 1
  when /\A--pretty(?:=(.*))?\z/
    val = Regexp.last_match(1) || args[i += 1]
    die "error: invalid value '#{val}' for '--pretty <STYLE>'\n  [possible values: all, colors, format, none]\n\nFor more information, try '--help'." unless %w[all colors format none].include?(val)
  when /\A--(format-options|style|response-charset|response-mime|history-print|max-redirects|timeout|proxy|verify|cert|cert-key|ssl|http-version|resolve|interface|unix-socket)(?:=.*)?\z/
    i += 1 unless a.include?('=')
  when '-S', '-x', '--stream', '--compress', '--all', '--debug', '--check-status', '--ignore-netrc', '-c', '--continue', '-4', '--ipv4', '-6', '--ipv6'
    # accepted, mostly cosmetic for this reimplementation
  when /\A--no-/
    # reset options are accepted for compatibility
  when /\A-/
    die "error: unexpected argument '#{a}' found\n\nFor more information, try '--help'."
  else
    pos << a
  end
  i += 1
end

die "error: the following required arguments were not provided:\n  <[METHOD] URL>\n\nUsage: executable <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'." if pos.empty?

method = nil
explicit_method = false
url_s = nil
if pos.length >= 2 && pos[0].match?(/\A[A-Za-z]+\z/) && !pos[0].include?('.') && !pos[0].include?(':')
  method = pos.shift.upcase
  explicit_method = true
  url_s = pos.shift
else
  url_s = pos.shift
end
if url_s && pos.empty? && method.nil? && url_s.match?(/\A[A-Za-z]+\z/) && !url_s.include?('.') && !url_s.include?(':')
  die "error: Missing <URL>\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'."
end
die "error: Missing <URL>\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'." if url_s.nil?

headers = []
query = []
fields = []
files = []
body_file = nil
pos.each do |item|
  if item.start_with?('@') && item.length > 1
    body_file = item[1..]
    next
  end
  sep = find_sep(item)
  die "error: Invalid value for '[REQUEST_ITEM]...': \"#{item}\"\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'." unless sep
  idx, op = sep
  key = unescape_key(item[0...idx])
  val = item[(idx + op.length)..] || ''
  val = File.read(val[1..]).strip if val.start_with?('@') && File.file?(val[1..].to_s)
  case op
  when '=='
    query << [key, val]
  when '=', ':='
    fields << [key, op == ':=' ? parse_literal(val) : val]
  when ':'
    headers << [key.split('-').map(&:capitalize).join('-'), val]
  when ';'
    headers << [key.split('-').map(&:capitalize).join('-'), '']
  when '@'
    files << [key, val]
  end
end

stdin_body = nil
unless opts[:ignore_stdin] || STDIN.tty?
  stdin_body = STDIN.read
end
if stdin_body && !stdin_body.empty? && (!fields.empty? || opts[:raw])
  if opts[:raw]
    die "executable: error: Request body from stdin and --raw cannot be mixed. Pass --ignore-stdin to ignore standard input.", 1
  else
    die "executable: error: Request body (from stdin) and request data (key=value) cannot be mixed. Pass --ignore-stdin to ignore standard input.", 1
  end
end

body = nil
content_type = nil
if opts[:raw]
  body = opts[:raw]
  content_type = 'application/json'
elsif body_file
  body = File.binread(body_file)
elsif stdin_body && !stdin_body.empty?
  body = stdin_body
elsif !fields.empty? || !files.empty? || opts[:mode] == :multipart
  if opts[:mode] == :form
    body = form_encode(fields)
    content_type = 'application/x-www-form-urlencoded'
  elsif opts[:mode] == :multipart || !files.empty?
    boundary = Array.new(4) { rand(0xffffffffffffffff).to_s(16) }.join('-')
    body = fields.map { |k, v| "--#{boundary}\r\nContent-Disposition: form-data; name=\"#{k}\"\r\n\r\n#{v}\r\n" }.join
    files.each do |k, path|
      data = File.file?(path) ? File.binread(path) : ''
      body << "--#{boundary}\r\nContent-Disposition: form-data; name=\"#{k}\"; filename=\"#{File.basename(path)}\"\r\n\r\n#{data}\r\n"
    end
    body << "--#{boundary}--\r\n"
    content_type = "multipart/form-data; boundary=#{boundary}"
  else
    h = {}
    fields.each { |k, v| h[k] = v }
    body = to_json(h)
    content_type = 'application/json'
  end
end
method ||= body.nil? ? 'GET' : 'POST'

uri = normalize_url(url_s, opts[:https])
unless query.empty?
  existing = uri.query.to_s
  add = form_encode(query)
  uri.query = existing.empty? ? add : "#{existing}&#{add}"
end

default_headers = []
default_headers << ['Accept-Encoding', 'gzip, deflate, br, zstd']
default_headers << ['User-Agent', "xh/#{VERSION}"]
default_headers << ['Connection', 'keep-alive']
if content_type == 'application/json'
  default_headers << ['Accept', 'application/json, */*;q=0.5']
  default_headers << ['Content-Type', content_type]
elsif content_type
  default_headers << ['Content-Type', content_type]
  default_headers << ['Accept', '*/*']
else
  default_headers << ['Accept', '*/*']
end
all_headers = default_headers + headers
all_headers << ['Content-Length', body.bytesize.to_s] if body
host = uri.host.dup
host += ":#{uri.port}" if uri.port && uri.port != uri.default_port
all_headers << ['Host', host]

pathq = uri.path.empty? ? '/' : uri.path
pathq += "?#{uri.query}" if uri.query

def request_text(method, pathq, headers, body)
  s = "#{method} #{pathq} HTTP/1.1\n"
  headers.each { |k, v| s << "#{k}: #{v}\n" }
  s << "\n"
  s << body.to_s << "\n\n" if body
  s
end

if opts[:curl]
  parts = ['curl']
  parts << (opts[:curl_long] ? '--request' : '-X') << method if explicit_method || (!%w[GET POST].include?(method))
  parts << shell_quote(uri.to_s)
  curl_headers = headers.dup
  if body && content_type == 'application/json'
    curl_headers.unshift ['content-type', 'application/json']
    curl_headers << ['accept', 'application/json, */*;q=0.5']
  end
  curl_headers.each { |k, v| parts << (opts[:curl_long] ? '--header' : '-H') << shell_quote("#{k.downcase}: #{v}") }
  if opts[:auth]
    if opts[:auth_type] == 'bearer'
      parts << '--oauth2-bearer' << shell_quote(opts[:auth])
    else
      parts << '--basic' << '-u' << shell_quote(opts[:auth])
    end
  end
  if body
    if opts[:mode] == :form
      fields.each { |k, v| parts << '--data-urlencode' << shell_single("#{k}=#{v}") }
    else
      parts << (opts[:curl_long] ? '--data' : '-d') << shell_quote(body)
    end
  end
  puts parts.join(' ')
  exit 0
end

if opts[:offline]
  print request_text(method, pathq, all_headers, body) unless opts[:quiet] > 0
  exit 0
end

if opts[:verbose] > 0
  print request_text(method, pathq, all_headers, body)
end

begin
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = uri.scheme == 'https'
  http.verify_mode = OpenSSL::SSL::VERIFY_NONE unless opts[:verify]
  klass = Net::HTTP.const_get(method.capitalize) rescue Net::HTTPGenericRequest
  req = klass == Net::HTTPGenericRequest ? klass.new(method, !body.nil?, true, uri.request_uri) : klass.new(uri.request_uri)
  all_headers.each { |k, v| req[k] = v unless k == 'Host' || k == 'Content-Length' }
  req.body = body if body
  if opts[:auth]
    if opts[:auth_type] == 'bearer'
      req['Authorization'] = "Bearer #{opts[:auth]}"
    else
      user, pass = opts[:auth].split(':', 2)
      req.basic_auth(user, pass.to_s)
    end
  end
  res = http.request(req)
rescue StandardError => e
  warn "executable: error: #{e.message}"
  exit 1
end

format = opts[:print] || (opts[:verbose] > 0 ? 'hb' : 'b')
out = +''
if format.include?('h')
  out << "HTTP/#{res.http_version} #{res.code} #{res.message}\n"
  res.each_header { |k, v| out << "#{k.split('-').map(&:capitalize).join('-')}: #{v}\n" }
  out << "\n"
end
out << res.body.to_s if format.include?('b')
out << "\n" if format.include?('b') && !out.end_with?("\n")

if opts[:output]
  File.binwrite(opts[:output], out)
else
  print out unless opts[:quiet] > 0
end

code = res.code.to_i
exit 4 if opts[:check_status] && code >= 400 && code < 500
exit 5 if opts[:check_status] && code >= 500
exit 3 if opts[:check_status] && code >= 300 && code < 400 && !opts[:follow]
exit 0
