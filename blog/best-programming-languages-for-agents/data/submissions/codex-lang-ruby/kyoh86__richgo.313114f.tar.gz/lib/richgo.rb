#!/usr/bin/env ruby
# frozen_string_literal: true

require "open3"
require "yaml"

Style = Struct.new(:hide, :bold, :faint, :italic, :underline, :blink_slow,
                   :blink_rapid, :inverse, :conceal, :cross_out, :frame,
                   :encircle, :overline, :foreground, :background,
                   keyword_init: true) do
  def merge(hash)
    return self unless hash.is_a?(Hash)

    dup.tap do |s|
      hash.each do |k, v|
        key = k.to_s.gsub(/([a-z])([A-Z])/, '\1_\2').downcase
        key = "cross_out" if key == "crossout"
        key = "blink_slow" if key == "blinkslow"
        key = "blink_rapid" if key == "blinkrapid"
        s[key] = v if members.include?(key.to_sym)
      end
    end
  end

  def ansi_prefix
    codes = []
    codes << color_code(foreground, false) if foreground
    codes << color_code(background, true) if background
    codes << "1" if bold
    codes << "2" if faint
    codes << "3" if italic
    codes << "4" if underline
    codes << "5" if blink_slow
    codes << "6" if blink_rapid
    codes << "7" if inverse
    codes << "8" if conceal
    codes << "9" if cross_out
    codes << "51" if frame
    codes << "52" if encircle
    codes << "53" if overline
    codes.compact.map { |c| "\e[#{c}m" }.join
  end

  def paint(text, color: true)
    return "" if hide
    return text unless color

    "#{ansi_prefix}#{text}\e[0m"
  end

  private

  COLOR_CODES = {
    "black" => 30, "red" => 31, "green" => 32, "yellow" => 33,
    "blue" => 34, "magenta" => 35, "cyan" => 36, "white" => 37,
    "lightblack" => 90, "lightred" => 91, "lightgreen" => 92,
    "lightyellow" => 93, "lightblue" => 94, "lightmagenta" => 95,
    "lightcyan" => 96, "lightwhite" => 97,
    "gray" => 90, "grey" => 90
  }.freeze

  def color_code(value, background)
    raw = value.to_s.strip
    key = raw.downcase.gsub(/[-_\s]/, "")
    if COLOR_CODES[key]
      code = COLOR_CODES[key]
      return (background ? code + 10 : code).to_s
    end

    rgb = parse_rgb(raw)
    return nil unless rgb

    base = background ? 48 : 38
    "#{base};2;#{rgb.join(";")}"
  end

  def parse_rgb(raw)
    if raw =~ /\A#?([0-9a-fA-F]{6})\z/
      hex = Regexp.last_match(1)
      return [hex[0, 2], hex[2, 2], hex[4, 2]].map { |v| v.to_i(16) }
    end
    return nil unless raw =~ /\Argb\(([^)]+)\)\z/i

    Regexp.last_match(1).split(/\s*,\s*/).map do |part|
      part.start_with?("0x", "0X") ? part.to_i(16) : part.to_i
    end
  end
end

class RichGo
  RESET = "\e[0m"

  DEFAULTS = {
    "labelType" => "long",
    "buildStyle" => Style.new(bold: true, foreground: "yellow"),
    "startStyle" => Style.new(foreground: "lightBlack"),
    "passStyle" => Style.new(foreground: "green"),
    "failStyle" => Style.new(bold: true, foreground: "red"),
    "skipStyle" => Style.new(foreground: "lightBlack"),
    "passPackageStyle" => Style.new(foreground: "green", hide: true),
    "failPackageStyle" => Style.new(bold: true, foreground: "red", hide: true),
    "coverThreshold" => 50,
    "coveredStyle" => Style.new(foreground: "green"),
    "uncoveredStyle" => Style.new(bold: true, foreground: "yellow"),
    "fileStyle" => Style.new(foreground: "cyan"),
    "lineStyle" => Style.new(foreground: "magenta"),
    "removals" => [],
    "leaveTestPrefix" => false
  }.freeze

  LABELS = {
    long: {
      build: "BUILD| ", start: "START| ", pass: "PASS | ", fail: "FAIL | ",
      skip: "SKIP | ", cover: "COVER| ", plain: "     | "
    },
    short: {
      build: "!! ", start: ">  ", pass: "o  ", fail: "x  ",
      skip: "-  ", cover: "%  ", plain: "   "
    },
    none: Hash.new("")
  }.freeze

  def initialize
    @config = load_config
    @labels = LABELS.fetch(@config["labelType"].to_s.downcase.to_sym, LABELS[:long])
    @current_style = style("startStyle")
  end

  def run(argv)
    if argv.first == "testfilter"
      filter($stdin, $stdout)
    elsif argv.first == "test"
      run_go_test(argv)
    else
      exec_go(argv)
    end
  end

  def filter(input, output)
    color = colorize?
    unless color
      input.each_line { |line| output.write(line) }
      return
    end

    input.each_line do |line|
      rendered = render_line(line.chomp)
      output.write(rendered)
      output.write("\n") unless rendered.empty?
    end
  end

  private

  def run_go_test(argv)
    color = colorize?
    unless color
      exec_go(argv)
    end

    begin
      Open3.popen2e("go", *argv) do |_stdin, stream, wait_thr|
        filter(stream, $stdout)
        exit(wait_thr.value.exitstatus || 1)
      end
    rescue Errno::ENOENT
      panic_missing_go
    end
  end

  def exec_go(argv)
    exec("go", *argv)
  rescue Errno::ENOENT
    panic_missing_go
  end

  def panic_missing_go
    warn 'panic: exec: "go": executable file not found in $PATH'
    warn
    warn "goroutine 1 [running]:"
    warn "main.main()"
    warn "\t/workspace/main.go:74 +0x465"
    exit 2
  end

  def colorize?
    ENV["RICHGO_FORCE_COLOR"] == "1" || $stdout.tty?
  end

  def load_config
    cfg = DEFAULTS.dup
    data = {}
    config_paths.each do |path|
      next unless File.file?(path)

      begin
        data = YAML.load_file(path) || {}
      rescue StandardError
        data = {}
      end
      break
    end

    data.each do |k, v|
      key = k.to_s
      if cfg[key].is_a?(Style)
        cfg[key] = cfg[key].merge(v)
      else
        cfg[key] = v
      end
    end
    cfg
  end

  def config_paths
    names = [".richstyle", ".richstyle.yaml", ".richstyle.yml"]
    roots = [Dir.pwd]
    unless ENV["RICHGO_LOCAL"] == "1"
      roots << ENV["GOPATH"] if ENV["GOPATH"] && !ENV["GOPATH"].empty?
      roots << ENV["GOROOT"] if ENV["GOROOT"] && !ENV["GOROOT"].empty?
      roots << ENV["HOME"] if ENV["HOME"] && !ENV["HOME"].empty?
    end
    roots.flat_map { |root| names.map { |name| File.join(root, name) } }
  end

  def style(name)
    @config[name]
  end

  def render_line(line)
    line = apply_removals(line)

    case line
    when /\A=== RUN\s+(Test.+)\z/
      @current_style = style("startStyle")
      test_line(:start, style("startStyle"), Regexp.last_match(1))
    when /\A--- PASS: (Test.+)\z/
      @current_style = style("passStyle")
      test_line(:pass, style("passStyle"), Regexp.last_match(1))
    when /\A--- FAIL: (Test.+)\z/
      @current_style = style("failStyle")
      test_line(:fail, style("failStyle"), Regexp.last_match(1))
    when /\A--- SKIP: (Test.+)\z/
      @current_style = style("skipStyle")
      test_line(:skip, style("skipStyle"), Regexp.last_match(1))
    when /\APASS\z/
      ""
    when /\AFAIL\z/
      ""
    when /\Acoverage:\s+([0-9]+(?:\.[0-9]+)?)% of statements\z/
      coverage_line(Regexp.last_match(1))
    when /\Aok\s+\t([^\t]+)\t[^\t]*(?:\t(.*))?\z/
      @current_style = style("passStyle")
      package_line(:pass, style("passStyle"), Regexp.last_match(1), Regexp.last_match(2))
    when /\A\?\s+\t([^\t]+)\t(.*)\z/
      @current_style = style("skipStyle")
      package_line(:skip, style("skipStyle"), Regexp.last_match(1), Regexp.last_match(2), tab: true)
    when /\AFAIL(.*)\z/
      @current_style = style("failStyle")
      package_line(:fail, style("failStyle"), Regexp.last_match(1), nil)
    when /\A#\s+(.+)\z/
      @current_style = style("buildStyle")
      style("buildStyle").paint("#{@labels[:build]}#{Regexp.last_match(1)}")
    else
      continuation(line)
    end
  end

  def apply_removals(line)
    Array(@config["removals"]).reduce(line) do |memo, pat|
      begin
        memo.gsub(Regexp.new(pat.to_s), "")
      rescue RegexpError
        memo
      end
    end
  end

  def test_line(kind, sty, value)
    name, rest = value.split(/\s+/, 2)
    name = clean_test_name(name)
    name = "#{"  " * name.count("/")}#{name}"
    name = "#{name} #{rest}" if rest
    sty.paint("#{@labels[kind]}#{name}")
  end

  def clean_test_name(name)
    return name if @config["leaveTestPrefix"]

    parts = name.split("/")
    parts[0] = parts[0].sub(/\ATest/, "")
    parts.join("/")
  end

  def coverage_line(percent)
    value = percent.to_f
    bars = (value / 10).floor
    graph = "[#{"#" * bars}#{"_" * (10 - bars)}]"
    sty = value >= @config["coverThreshold"].to_f ? style("coveredStyle") : style("uncoveredStyle")
    @current_style = sty
    sty.paint("#{@labels[:cover]}#{percent}% #{graph}")
  end

  def package_line(kind, sty, pkg, extra, tab: false)
    text = if kind == :fail
             pkg
           elsif tab
             "#{pkg}\t#{extra}"
           else
             "#{pkg} #{extra}"
           end
    sty.paint("#{@labels[kind]}#{text}")
  end

  def continuation(line)
    sty = @current_style || style("buildStyle")
    sty.paint("#{@labels[:plain]}#{decorate_file_refs(line, sty)}")
  end

  def decorate_file_refs(line, outer_style)
    line.sub(/([A-Za-z0-9_.\/-]+\.go)(:[0-9]+(?::[0-9]+)?)(?=:)/) do
      "#{style("fileStyle").ansi_prefix}#{$1}#{RESET}" \
        "#{style("lineStyle").ansi_prefix}#{$2}#{RESET}" \
        "#{outer_style.ansi_prefix}"
    end
  end
end

RichGo.new.run(ARGV)
