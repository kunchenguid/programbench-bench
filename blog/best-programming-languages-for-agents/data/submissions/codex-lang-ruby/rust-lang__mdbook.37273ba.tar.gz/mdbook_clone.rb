#!/usr/bin/env ruby
# frozen_string_literal: true

require 'cgi'
require 'fileutils'
require 'open3'
require 'pathname'
require 'shellwords'

VERSION = '0.5.0-alpha.1'

MAIN_HELP = <<~TXT.chomp
  Creates a book from markdown files

  Usage: executable [COMMAND]

  Commands:
    init         Creates the boilerplate structure and files for a new book
    build        Builds a book from its markdown files
    test         Tests that a book's Rust code samples compile
    clean        Deletes a built book
    completions  Generate shell completions for your shell to stdout
    watch        Watches a book's files and rebuilds it on changes
    serve        Serves a book at http://localhost:3000, and rebuilds it on changes
    help         Print this message or the help of the given subcommand(s)

  Options:
    -h, --help     Print help
    -V, --version  Print version

  For more information about a specific command, try `mdbook <command> --help`
  The source code for mdBook is available at: https://github.com/rust-lang/mdBook
TXT

HELP = {
  'init' => <<~TXT.chomp,
    Creates the boilerplate structure and files for a new book

    Usage: executable init [OPTIONS] [dir]

    Arguments:
      [dir]  Directory to create the book in
             (Defaults to the current directory when omitted)

    Options:
          --theme            Copies the default theme into your source folder
          --force            Skips confirmation prompts
          --title <title>    Sets the book title
          --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]
      -h, --help             Print help
      -V, --version          Print version
  TXT
  'build' => <<~TXT.chomp,
    Builds a book from its markdown files

    Usage: executable build [OPTIONS] [dir]

    Arguments:
      [dir]  Root directory for the book
             (Defaults to the current directory when omitted)

    Options:
      -d, --dest-dir <dest-dir>  Output directory for the book
                                 Relative paths are interpreted relative to the book's root directory.
                                 If omitted, mdBook uses build.build-dir from book.toml or defaults to
                                 `./book`.
      -o, --open                 Opens the compiled book in a web browser
      -h, --help                 Print help
      -V, --version              Print version
  TXT
  'clean' => <<~TXT.chomp,
    Deletes a built book

    Usage: executable clean [OPTIONS] [dir]

    Arguments:
      [dir]  Root directory for the book
             (Defaults to the current directory when omitted)

    Options:
      -d, --dest-dir <dest-dir>  Output directory for the book
                                 Relative paths are interpreted relative to the book's root directory.
                                 If omitted, mdBook uses build.build-dir from book.toml or defaults to
                                 `./book`.
      -h, --help                 Print help
      -V, --version              Print version
  TXT
  'test' => <<~TXT.chomp,
    Tests that a book's Rust code samples compile

    Usage: executable test [OPTIONS] [dir]

    Arguments:
      [dir]  Root directory for the book
             (Defaults to the current directory when omitted)

    Options:
      -d, --dest-dir <dest-dir>  Output directory for the book
                                 Relative paths are interpreted relative to the book's root directory.
                                 If omitted, mdBook uses build.build-dir from book.toml or defaults to
                                 `./book`.
      -c, --chapter <chapter>    
      -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path
                                 when building tests
      -h, --help                 Print help
      -V, --version              Print version
  TXT
  'completions' => <<~TXT.chomp,
    Generate shell completions for your shell to stdout

    Usage: executable completions <SHELL>

    Arguments:
      <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,
               zsh]

    Options:
      -h, --help     Print help
      -V, --version  Print version
  TXT
  'watch' => <<~TXT.chomp,
    Watches a book's files and rebuilds it on changes

    Usage: executable watch [OPTIONS] [dir]

    Arguments:
      [dir]  Root directory for the book
             (Defaults to the current directory when omitted)

    Options:
      -d, --dest-dir <dest-dir>  Output directory for the book
                                 Relative paths are interpreted relative to the book's root directory.
                                 If omitted, mdBook uses build.build-dir from book.toml or defaults to
                                 `./book`.
      -o, --open                 Opens the compiled book in a web browser
          --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                                 poll, native]
      -h, --help                 Print help
      -V, --version              Print version
  TXT
  'serve' => <<~TXT.chomp
    Serves a book at http://localhost:3000, and rebuilds it on changes

    Usage: executable serve [OPTIONS] [dir]

    Arguments:
      [dir]  Root directory for the book
             (Defaults to the current directory when omitted)

    Options:
      -d, --dest-dir <dest-dir>  Output directory for the book
                                 Relative paths are interpreted relative to the book's root directory.
                                 If omitted, mdBook uses build.build-dir from book.toml or defaults to
                                 `./book`.
      -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]
      -p, --port <port>          Port to use for HTTP connections [default: 3000]
      -o, --open                 Opens the compiled book in a web browser
          --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                                 poll, native]
      -h, --help                 Print help
      -V, --version              Print version
  TXT
}

def info(mod, msg)
  puts "#{Time.now.utc.strftime('%Y-%m-%d %H:%M:%S')} [INFO] (#{mod}): #{msg}"
end

def error(mod, msg)
  warn "#{Time.now.utc.strftime('%Y-%m-%d %H:%M:%S')} [ERROR] (#{mod}): #{msg}"
end

def die(msg, code = 1)
  warn msg
  exit code
end

def option_value(args, i)
  arg = args[i]
  return arg.split('=', 2)[1] if arg.include?('=')
  [args[i + 1], 1]
end

def parse_common(args)
  opts = {}
  rest = []
  i = 0
  while i < args.length
    a = args[i]
    case a
    when '-h', '--help'
      opts[:help] = true
    when '-V', '--version'
      opts[:version] = true
    when '-d', '--dest-dir'
      opts[:dest] = args[i + 1]
      i += 1
    when /\A--dest-dir=/
      opts[:dest] = a.split('=', 2)[1]
    when '-o', '--open'
      opts[:open] = true
    when '-c', '--chapter'
      opts[:chapter] = args[i + 1]
      i += 1
    when /\A--chapter=/
      opts[:chapter] = a.split('=', 2)[1]
    when '-L', '--library-path'
      opts[:library_path] = args[i + 1]
      i += 1
    when /\A--library-path=/
      opts[:library_path] = a.split('=', 2)[1]
    when '--watcher', /\A--watcher=/
      opts[:watcher] = a.include?('=') ? a.split('=', 2)[1] : args[i + 1]
      i += 1 unless a.include?('=')
    when '-n', '--hostname'
      opts[:hostname] = args[i + 1]
      i += 1
    when /\A--hostname=/
      opts[:hostname] = a.split('=', 2)[1]
    when '-p', '--port'
      opts[:port] = args[i + 1]
      i += 1
    when /\A--port=/
      opts[:port] = a.split('=', 2)[1]
    else
      rest << a
    end
    i += 1
  end
  [opts, rest]
end

def parse_config(root)
  cfg = { 'book' => { 'src' => 'src', 'language' => 'en' }, 'build' => { 'build-dir' => 'book' } }
  path = File.join(root, 'book.toml')
  return cfg unless File.file?(path)
  section = nil
  File.readlines(path, chomp: true).each do |line|
    s = line.strip
    next if s.empty? || s.start_with?('#')
    if s =~ /\A\[([^\]]+)\]\z/
      section = Regexp.last_match(1)
      cfg[section] ||= {}
      next
    end
    next unless section && s =~ /\A([A-Za-z0-9_.-]+)\s*=\s*(.+)\z/
    key = Regexp.last_match(1)
    raw = Regexp.last_match(2).split(/\s+#/, 2)[0].strip
    val = if raw.start_with?('"') && raw.end_with?('"')
            raw[1..-2].gsub('\"', '"')
          elsif raw.start_with?('[')
            raw.scan(/"([^"]*)"/).flatten
          elsif raw == 'true'
            true
          elsif raw == 'false'
            false
          else
            raw
          end
    cfg[section][key] = val
  end
  cfg
end

Chapter = Struct.new(:title, :path, :level, :numbered, keyword_init: true)

def parse_summary(src_dir)
  file = File.join(src_dir, 'SUMMARY.md')
  unless File.file?(file)
    error('mdbook_core::utils', "Error: Couldn't open SUMMARY.md in \"#{File.expand_path(src_dir)}\" directory")
    error('mdbook_core::utils', "\tCaused By: No such file or directory (os error 2)")
    exit 1
  end
  chapters = []
  File.readlines(file, chomp: true).each do |line|
    next if line.strip.empty? || line.strip =~ /\A#/
    next if line.strip =~ /\A-{3,}\z/
    if (m = line.match(/\A(\s*)(?:[-*]\s*)?\[([^\]]+)\]\(([^)]*)\)/))
      indent = m[1].gsub("\t", '    ').length
      title = m[2]
      path = m[3].strip
      next if path.empty?
      chapters << Chapter.new(title: title, path: path.sub(%r{\A\./}, ''), level: indent / 2, numbered: line.strip.start_with?('-', '*'))
    end
  end
  chapters
end

def html_path(md_path, first = false)
  return 'index.html' if first || File.basename(md_path).casecmp('README.md').zero?
  md_path.sub(/\.md\z/i, '.html')
end

def rel_root(path)
  depth = path.split('/').length - 1
  depth.zero? ? '' : ('../' * depth)
end

def slug(text)
  text.downcase.gsub(/<[^>]+>/, '').gsub(/&[a-z]+;/, '').gsub(/[^a-z0-9 _-]/, '').strip.gsub(/\s+/, '-')
end

def inline_md(text, current_html)
  escaped = CGI.escapeHTML(text)
  escaped.gsub!(/`([^`]+)`/) { "<code>#{Regexp.last_match(1)}</code>" }
  escaped.gsub!(/\*\*([^*]+)\*\*/) { "<strong>#{Regexp.last_match(1)}</strong>" }
  escaped.gsub!(/\*([^*]+)\*/) { "<em>#{Regexp.last_match(1)}</em>" }
  escaped.gsub!(/\[([^\]]+)\]\(([^)]+)\)/) do
    label = Regexp.last_match(1)
    href = Regexp.last_match(2)
    href = href.sub(/\.md(#.*)?\z/i) { ".html#{Regexp.last_match(1)}" }
    href = 'index.html' if href.casecmp('README.html').zero?
    "<a href=\"#{CGI.escapeHTML(href)}\">#{label}</a>"
  end
  escaped
end

def extract_include(spec, base_dir, rustdoc: false)
  file, a, b = spec.strip.split(':', 3)
  path = File.expand_path(file, base_dir)
  return '' unless File.file?(path)
  lines = File.readlines(path, chomp: false)
  selected = lines
  if a && !a.empty?
    if a =~ /\A\d+\z/
      start = a.to_i
      finish = b && !b.empty? ? b.to_i : start
      selected = lines[(start - 1)..(finish - 1)] || []
    else
      inside = false
      selected = []
      lines.each do |line|
        if line =~ /ANCHOR:\s*#{Regexp.escape(a)}\b/
          inside = true
          next
        elsif line =~ /ANCHOR_END:\s*#{Regexp.escape(a)}\b/
          inside = false
          next
        end
        selected << line if inside && line !~ /ANCHOR(?:_END)?:/
      end
    end
  elsif a == '' && b && b =~ /\A\d+\z/
    selected = lines[0...b.to_i] || []
  end
  return selected.join unless rustdoc
  keep = selected
  lines.map { |line| keep.include?(line) ? line : "# #{line}" }.join
end

def preprocess_markdown(text, base_dir)
  text.gsub(/\{\{#(include|rustdoc_include)\s+([^}]+)\}\}/) do
    extract_include(Regexp.last_match(2), base_dir, rustdoc: Regexp.last_match(1) == 'rustdoc_include')
  end.gsub(/\{\{#playground\s+([^}\s]+)([^}]*)\}\}/) do
    file = Regexp.last_match(1)
    attrs = Regexp.last_match(2).strip
    code = extract_include(file, base_dir)
    "```rust#{attrs.empty? ? '' : ",#{attrs}"}\n#{code}```"
  end.gsub(/\{\{#title\s+([^}]+)\}\}/, '')
end

def markdown_to_html(text, base_dir, current_html)
  text = preprocess_markdown(text, base_dir)
  lines = text.lines(chomp: true)
  out = []
  para = []
  in_code = false
  code_lang = ''
  code = []
  in_ul = false
  flush_para = lambda do
    unless para.empty?
      out << "<p>#{inline_md(para.join(' '), current_html)}</p>"
      para.clear
    end
  end
  lines.each do |line|
    if in_code
      if line.start_with?('```', '~~~')
        klass = code_lang.empty? ? '' : " class=\"language-#{CGI.escapeHTML(code_lang.split(/[,\s]/).first)}\""
        out << "<pre><code#{klass}>#{CGI.escapeHTML(code.join("\n"))}</code></pre>"
        code.clear
        in_code = false
      else
        code << line
      end
      next
    end
    if line.start_with?('```', '~~~')
      flush_para.call
      out << '</ul>' if in_ul
      in_ul = false
      in_code = true
      code_lang = line.sub(/\A(```|~~~)/, '').strip
      next
    end
    if line.strip.empty?
      flush_para.call
      out << '</ul>' if in_ul
      in_ul = false
      next
    end
    if line =~ /\A(#{'#'}{1,6})\s+(.+)\z/
      flush_para.call
      out << '</ul>' if in_ul
      in_ul = false
      level = Regexp.last_match(1).length
      body = inline_md(Regexp.last_match(2), current_html)
      id = slug(body)
      out << "<h#{level} id=\"#{id}\"><a class=\"header\" href=\"##{id}\">#{body}</a></h#{level}>"
    elsif line =~ /\A\s*[-*]\s+(.+)\z/
      flush_para.call
      unless in_ul
        out << '<ul>'
        in_ul = true
      end
      out << "<li>#{inline_md(Regexp.last_match(1), current_html)}</li>"
    else
      para << line.strip
    end
  end
  flush_para.call
  out << '</ul>' if in_ul
  out.join("\n")
end

def page_template(title, book_title, content, root, prev_link, next_link)
  full_title = book_title && !book_title.empty? ? "#{title} - #{book_title}" : title
  <<~HTML
    <!DOCTYPE HTML>
    <html lang="en" class="light sidebar-visible" dir="ltr">
    <head>
      <!-- Book generated using mdBook -->
      <meta charset="UTF-8">
      <title>#{CGI.escapeHTML(full_title)}</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="#{root}css/variables.css">
      <link rel="stylesheet" href="#{root}css/general.css">
      <link rel="stylesheet" href="#{root}css/chrome.css">
      <link rel="stylesheet" href="#{root}css/print.css" media="print">
      <script>const path_to_root = "#{root}"; window.path_to_searchindex_js = "#{root}searchindex.js";</script>
    </head>
    <body>
      <div id="body-container">
        <nav id="sidebar" class="sidebar" aria-label="Table of contents"><iframe class="sidebar-iframe-outer" src="#{root}toc.html"></iframe></nav>
        <div id="page-wrapper" class="page-wrapper">
          <div class="page">
            <div id="menu-bar" class="menu-bar sticky"><h1 class="menu-title">#{CGI.escapeHTML(book_title.to_s)}</h1></div>
            <div id="content" class="content">
              <main>
    #{content}
              </main>
              <nav class="nav-wrapper" aria-label="Page navigation">
                #{prev_link ? "<a rel=\"prev\" href=\"#{prev_link}\" class=\"mobile-nav-chapters previous\" title=\"Previous chapter\" aria-label=\"Previous chapter\">&lt;</a>" : ''}
                #{next_link ? "<a rel=\"next prefetch\" href=\"#{next_link}\" class=\"mobile-nav-chapters next\" title=\"Next chapter\" aria-label=\"Next chapter\">&gt;</a>" : ''}
                <div style="clear: both"></div>
              </nav>
            </div>
          </div>
          <nav class="nav-wide-wrapper" aria-label="Page navigation">
            #{prev_link ? "<a rel=\"prev\" href=\"#{prev_link}\" class=\"nav-chapters previous\" title=\"Previous chapter\" aria-label=\"Previous chapter\">&lt;</a>" : ''}
            #{next_link ? "<a rel=\"next prefetch\" href=\"#{next_link}\" class=\"nav-chapters next\" title=\"Next chapter\" aria-label=\"Next chapter\">&gt;</a>" : ''}
          </nav>
        </div>
      </div>
      <script src="#{root}book.js"></script>
    </body>
    </html>
  HTML
end

def write_theme(dest)
  files = {
    '.nojekyll' => '',
    '404.html' => '<!doctype html><title>404</title><h1>404</h1>',
    'book.js' => '',
    'toc.js' => '',
    'searcher.js' => '',
    'searchindex.js' => 'Object.assign(window, {search: {doc_urls: [], docs: []}});',
    'highlight.js' => '',
    'clipboard.min.js' => '',
    'elasticlunr.min.js' => '',
    'mark.min.js' => '',
    'highlight.css' => '',
    'tomorrow-night.css' => '',
    'ayu-highlight.css' => '',
    'favicon.svg' => '<svg xmlns="http://www.w3.org/2000/svg"></svg>',
    'favicon.png' => '',
    'css/variables.css' => ':root{--bg:#fff;--fg:#111}',
    'css/general.css' => 'body{font-family:sans-serif;margin:0}.content{max-width:900px;margin:auto;padding:2rem}pre{padding:1rem;overflow:auto;background:#f6f6f6}',
    'css/chrome.css' => '.sidebar{display:none}.menu-bar{border-bottom:1px solid #ddd;padding:.5rem 1rem}.nav-chapters{padding:1rem}',
    'css/print.css' => '',
    'fonts/fonts.css' => ''
  }
  files.each do |name, body|
    path = File.join(dest, name)
    FileUtils.mkdir_p(File.dirname(path))
    File.binwrite(path, body)
  end
end

def copy_assets(src, dest)
  Dir.glob(File.join(src, '**', '*'), File::FNM_DOTMATCH).each do |path|
    next if File.directory?(path)
    rel = Pathname.new(path).relative_path_from(Pathname.new(src)).to_s
    next if rel == 'SUMMARY.md' || rel.downcase.end_with?('.md')
    target = File.join(dest, rel)
    FileUtils.mkdir_p(File.dirname(target))
    FileUtils.cp(path, target)
  end
end

def build_book(root, dest_opt = nil)
  cfg = parse_config(root)
  src_rel = cfg.dig('book', 'src') || 'src'
  src = File.expand_path(src_rel, root)
  chapters = parse_summary(src)
  dest_rel = dest_opt || cfg.dig('build', 'build-dir') || 'book'
  dest = Pathname.new(dest_rel).absolute? ? dest_rel : File.join(root, dest_rel)
  info('mdbook_driver::mdbook', 'Book building has started')
  chapters.each do |ch|
    file = File.join(src, ch.path)
    next if File.file?(file)
    FileUtils.mkdir_p(File.dirname(file))
    File.write(file, "# #{ch.title}\n")
  end
  FileUtils.rm_rf(dest)
  FileUtils.mkdir_p(dest)
  write_theme(dest)
  copy_assets(src, dest)
  book_title = cfg.dig('book', 'title')
  title_for = ->(ch) { ch.title }
  htmls = chapters.map.with_index { |ch, i| html_path(ch.path, i.zero?) }
  chapters.each_with_index do |ch, i|
    source = File.join(src, ch.path)
    out_rel = htmls[i]
    content = markdown_to_html(File.read(source), File.dirname(source), out_rel)
    root_prefix = rel_root(out_rel)
    prev_link = i.positive? ? Pathname.new(htmls[i - 1]).relative_path_from(Pathname.new(File.dirname(out_rel) == '.' ? '' : File.dirname(out_rel))).to_s : nil
    next_link = i < htmls.length - 1 ? Pathname.new(htmls[i + 1]).relative_path_from(Pathname.new(File.dirname(out_rel) == '.' ? '' : File.dirname(out_rel))).to_s : nil
    target = File.join(dest, out_rel)
    FileUtils.mkdir_p(File.dirname(target))
    html = page_template(title_for.call(ch), book_title, content, root_prefix, prev_link, next_link)
    File.write(target, html)
    if i.zero? && out_rel != html_path(ch.path, false)
      alt = File.join(dest, html_path(ch.path, false))
      FileUtils.mkdir_p(File.dirname(alt))
      File.write(alt, html)
    end
  end
  toc = chapters.map { |ch| "<li><a href=\"#{html_path(ch.path, chapters.index(ch).zero?)}\">#{CGI.escapeHTML(ch.title)}</a></li>" }.join("\n")
  File.write(File.join(dest, 'toc.html'), "<ol class=\"chapter\">\n#{toc}\n</ol>\n")
  print_body = chapters.map { |ch| markdown_to_html(File.read(File.join(src, ch.path)), File.dirname(File.join(src, ch.path)), 'print.html') }.join("\n")
  File.write(File.join(dest, 'print.html'), page_template('Print this book', book_title, print_body, '', nil, nil))
  info('mdbook_driver::mdbook', 'Running the html backend')
  info('mdbook_html::html_handlebars::hbs_renderer', "HTML book written to `#{File.expand_path(dest)}`")
end

def init_book(args)
  opts = { ignore: nil, force: false, title: nil, theme: false }
  rest = []
  i = 0
  while i < args.length
    a = args[i]
    case a
    when '-h', '--help'
      puts HELP['init']
      return
    when '-V', '--version'
      puts "mdbook-init v#{VERSION}"
      return
    when '--force'
      opts[:force] = true
    when '--theme'
      opts[:theme] = true
    when '--title'
      opts[:title] = args[i + 1]
      i += 1
    when /\A--title=/
      opts[:title] = a.split('=', 2)[1]
    when '--ignore'
      opts[:ignore] = args[i + 1]
      i += 1
    when /\A--ignore=/
      opts[:ignore] = a.split('=', 2)[1]
    else
      rest << a
    end
    i += 1
  end
  root = rest[0] || '.'
  src = File.join(root, 'src')
  FileUtils.mkdir_p(src)
  summary = File.join(src, 'SUMMARY.md')
  unless File.file?(summary)
    File.write(summary, "# Summary\n\n- [Chapter 1](./chapter_1.md)\n")
  end
  chapters = parse_summary(src)
  chapters.each do |ch|
    path = File.join(src, ch.path)
    next if File.exist?(path)
    FileUtils.mkdir_p(File.dirname(path))
    File.write(path, "# #{ch.title}\n")
  end
  toml = +"[book]\nauthors = []\nlanguage = \"en\"\nsrc = \"src\"\n"
  toml << "title = \"#{opts[:title]}\"\n" if opts[:title] && !opts[:title].empty?
  File.write(File.join(root, 'book.toml'), toml)
  File.write(File.join(root, '.gitignore'), "book\n") if opts[:ignore] == 'git'
  if opts[:theme]
    theme = File.join(src, 'theme')
    FileUtils.mkdir_p(theme)
    File.write(File.join(theme, 'index.hbs'), '')
  end
  info('mdbook_driver::init', 'Creating a new book with stub content')
  puts "\nAll done, no errors..."
end

def command_build(args)
  opts, rest = parse_common(args)
  return puts HELP['build'] if opts[:help]
  return puts "mdbook-build v#{VERSION}" if opts[:version]
  build_book(File.expand_path(rest[0] || '.'), opts[:dest])
end

def command_clean(args)
  opts, rest = parse_common(args)
  return puts HELP['clean'] if opts[:help]
  return puts "mdbook-clean v#{VERSION}" if opts[:version]
  root = File.expand_path(rest[0] || '.')
  cfg = parse_config(root)
  dest_rel = opts[:dest] || cfg.dig('build', 'build-dir') || 'book'
  dest = Pathname.new(dest_rel).absolute? ? dest_rel : File.join(root, dest_rel)
  count = File.exist?(dest) ? Dir.glob(File.join(dest, '**', '*'), File::FNM_DOTMATCH).reject { |p| ['.', '..'].include?(File.basename(p)) }.length : 0
  FileUtils.rm_rf(dest)
  puts "Removed #{count} files"
end

def rust_blocks(markdown)
  blocks = []
  in_code = false
  lang = ''
  buf = []
  markdown.each_line do |line|
    if in_code
      if line.start_with?('```', '~~~')
        attrs = lang.split(/[,\s]+/)
        blocks << [attrs, buf.join] if attrs.include?('rust') || attrs.first == 'rust' || lang.empty?
        in_code = false
        buf = []
      else
        buf << line
      end
    elsif line.start_with?('```', '~~~')
      in_code = true
      lang = line.sub(/\A(```|~~~)/, '').strip
    end
  end
  blocks
end

def command_test(args)
  opts, rest = parse_common(args)
  return puts HELP['test'] if opts[:help]
  return puts "mdbook-test v#{VERSION}" if opts[:version]
  unless system('command -v rustc >/dev/null 2>&1')
    warn 'rustc not found; skipping Rust code sample tests'
    return
  end
  root = File.expand_path(rest[0] || '.')
  cfg = parse_config(root)
  src = File.expand_path(cfg.dig('book', 'src') || 'src', root)
  chapters = parse_summary(src)
  failures = 0
  chapters.each do |ch|
    next if opts[:chapter] && ch.title != opts[:chapter] && ch.path != opts[:chapter]
    md = File.read(File.join(src, ch.path))
    rust_blocks(md).each_with_index do |(attrs, code), idx|
      next if attrs.include?('ignore')
      wrapped = code.include?('fn main') ? code : "fn main() {\n#{code}\n}\n"
      tmp = File.join(Dir.pwd, "mdbook_test_#{$$}_#{idx}.rs")
      File.write(tmp, wrapped)
      flags = []
      flags += opts[:library_path].to_s.split(',').flat_map { |p| ['-L', p] } if opts[:library_path]
      cmd = ['rustc', '--edition=2021', '--crate-type', 'bin', tmp, '-o', "#{tmp}.bin"] + flags
      _out, err, st = Open3.capture3(*cmd)
      failures += 1 unless st.success? || attrs.include?('compile_fail')
      warn err unless st.success? || attrs.include?('compile_fail')
      FileUtils.rm_f([tmp, "#{tmp}.bin"])
    end
  end
  exit(failures.zero? ? 0 : 101)
end

def command_completions(args)
  return puts HELP['completions'] if args.include?('-h') || args.include?('--help') || args.empty?
  return puts "mdbook-completions v#{VERSION}" if args.include?('-V') || args.include?('--version')
  shell = args[0]
  die("error: invalid value '#{shell}' for '<SHELL>'") unless %w[bash elvish fish powershell zsh].include?(shell)
  puts "# shell completions for mdbook (#{shell})"
  puts "complete -W 'init build test clean completions watch serve help' mdbook" if shell == 'bash'
end

def command_watch(args)
  opts, rest = parse_common(args)
  return puts HELP['watch'] if opts[:help]
  return puts "mdbook-watch v#{VERSION}" if opts[:version]
  build_book(File.expand_path(rest[0] || '.'), opts[:dest])
end

def command_serve(args)
  opts, rest = parse_common(args)
  return puts HELP['serve'] if opts[:help]
  return puts "mdbook-serve v#{VERSION}" if opts[:version]
  build_book(File.expand_path(rest[0] || '.'), opts[:dest])
  host = opts[:hostname] || 'localhost'
  port = opts[:port] || '3000'
  puts "Serving on: http://#{host}:#{port}"
end

if ARGV.empty? || ARGV.include?('-h') || ARGV.include?('--help')
  puts MAIN_HELP
  exit 0
end
if ARGV.include?('-V') || ARGV.include?('--version')
  puts "mdbook v#{VERSION}"
  exit 0
end

cmd = ARGV.shift
case cmd
when 'help'
  sub = ARGV.shift
  puts(sub && HELP[sub] ? HELP[sub] : MAIN_HELP)
when 'init' then init_book(ARGV)
when 'build' then command_build(ARGV)
when 'clean' then command_clean(ARGV)
when 'test' then command_test(ARGV)
when 'completions' then command_completions(ARGV)
when 'watch' then command_watch(ARGV)
when 'serve' then command_serve(ARGV)
else
  warn "error: unrecognized subcommand '#{cmd}'"
  warn
  warn 'Usage: executable [COMMAND]'
  warn
  warn "For more information, try '--help'."
  exit 2
end
