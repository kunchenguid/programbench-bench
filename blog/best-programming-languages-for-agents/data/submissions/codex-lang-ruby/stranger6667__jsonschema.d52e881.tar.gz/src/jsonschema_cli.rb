#!/usr/bin/env ruby
# frozen_string_literal: true

require 'yaml'
require 'optparse'
require 'uri'
require 'set'
require 'ipaddr'


module MiniJSON
  module_function

  def generate(value)
    case value
    when nil then 'null'
    when true then 'true'
    when false then 'false'
    when Numeric
      value.to_s
    when String
      '"' + value.each_char.map { |c| escape(c) }.join + '"'
    when Array
      '[' + value.map { |v| generate(v) }.join(',') + ']'
    when Hash
      '{' + value.map { |k, v| generate(k.to_s) + ':' + generate(v) }.join(',') + '}'
    else
      generate(value.to_s)
    end
  end

  def escape(c)
    case c
    when '"' then '\\"'
    when '\\' then '\\\\'
    when "\b" then '\\b'
    when "\f" then '\\f'
    when "\n" then '\\n'
    when "\r" then '\\r'
    when "\t" then '\\t'
    else
      c.ord < 0x20 ? "\\u%04x" % c.ord : c
    end
  end
end

class ValidationError < Struct.new(:path, :schema_path, :keyword, :message); end

class Validator
  attr_reader :schema_uri

  def initialize(root_schema, schema_path)
    @root = root_schema
    @schema_path = schema_path
    @schema_uri = 'file://' + File.expand_path(schema_path)
  end

  def validate(instance, schema = @root, path = [], spath = [])
    errors = []
    schema = resolve_ref(schema) if schema.is_a?(Hash) && schema.key?('$ref')
    return errors if schema == true || schema.nil?
    if schema == false
      errors << err(path, spath, '', "false schema does not allow #{fmt(instance)}")
      return errors
    end
    return errors unless schema.is_a?(Hash)

    if schema.key?('type') && !type_ok?(instance, schema['type'])
      errors << err(path, spath + ['type'], 'type', "#{fmt(instance)} is not of type #{type_desc(schema['type'])}")
    end

    if schema.key?('enum') && !schema['enum'].any? { |v| v == instance }
      errors << err(path, spath + ['enum'], 'enum', "#{fmt(instance)} is not one of #{join_values(schema['enum'])}")
    end
    if schema.key?('const') && schema['const'] != instance
      errors << err(path, spath + ['const'], 'const', "#{fmt(instance)} was expected to be constant #{fmt(schema['const'])}")
    end

    if numeric?(instance)
      errors.concat(validate_number(instance, schema, path, spath))
    end
    if instance.is_a?(String)
      errors.concat(validate_string(instance, schema, path, spath))
    end
    if instance.is_a?(Array)
      errors.concat(validate_array(instance, schema, path, spath))
    end
    if object?(instance)
      errors.concat(validate_object(instance, schema, path, spath))
    end

    errors.concat(validate_combiners(instance, schema, path, spath))
    errors
  end

  private

  def validate_number(n, schema, path, spath)
    e = []
    if schema.key?('minimum') && n < schema['minimum']
      e << err(path, spath + ['minimum'], 'minimum', "#{fmt(n)} is less than the minimum of #{fmt(schema['minimum'])}")
    end
    if schema.key?('maximum') && n > schema['maximum']
      e << err(path, spath + ['maximum'], 'maximum', "#{fmt(n)} is greater than the maximum of #{fmt(schema['maximum'])}")
    end
    if schema.key?('exclusiveMinimum')
      v = schema['exclusiveMinimum']
      if v == true && schema.key?('minimum') && n <= schema['minimum']
        e << err(path, spath + ['exclusiveMinimum'], 'exclusiveMinimum', "#{fmt(n)} is less than or equal to the minimum of #{fmt(schema['minimum'])}")
      elsif numeric?(v) && n <= v
        e << err(path, spath + ['exclusiveMinimum'], 'exclusiveMinimum', "#{fmt(n)} is less than or equal to the minimum of #{fmt(v)}")
      end
    end
    if schema.key?('exclusiveMaximum')
      v = schema['exclusiveMaximum']
      if v == true && schema.key?('maximum') && n >= schema['maximum']
        e << err(path, spath + ['exclusiveMaximum'], 'exclusiveMaximum', "#{fmt(n)} is greater than or equal to the maximum of #{fmt(schema['maximum'])}")
      elsif numeric?(v) && n >= v
        e << err(path, spath + ['exclusiveMaximum'], 'exclusiveMaximum', "#{fmt(n)} is greater than or equal to the maximum of #{fmt(v)}")
      end
    end
    if schema.key?('multipleOf') && schema['multipleOf'].to_f != 0.0
      q = n.to_f / schema['multipleOf'].to_f
      unless (q - q.round).abs < 1e-10
        e << err(path, spath + ['multipleOf'], 'multipleOf', "#{fmt(n)} is not a multiple of #{fmt(schema['multipleOf'])}")
      end
    end
    e
  end

  def validate_string(s, schema, path, spath)
    e = []
    if schema.key?('minLength') && s.length < schema['minLength']
      e << err(path, spath + ['minLength'], 'minLength', "#{fmt(s)} is shorter than #{schema['minLength']} characters")
    end
    if schema.key?('maxLength') && s.length > schema['maxLength']
      e << err(path, spath + ['maxLength'], 'maxLength', "#{fmt(s)} is longer than #{schema['maxLength']} characters")
    end
    if schema.key?('pattern')
      begin
        re = Regexp.new(schema['pattern'])
        e << err(path, spath + ['pattern'], 'pattern', "#{fmt(s)} does not match #{fmt(schema['pattern'])}") unless s.match?(re)
      rescue RegexpError
      end
    end
    if schema['__assert_format'] && schema.key?('format') && !format_ok?(schema['format'], s)
      e << err(path, spath + ['format'], 'format', "#{fmt(s)} is not a #{fmt(schema['format'])}")
    end
    e
  end

  def validate_array(a, schema, path, spath)
    e = []
    e << err(path, spath + ['minItems'], 'minItems', "#{fmt(a)} has fewer than #{schema['minItems']} items") if schema.key?('minItems') && a.length < schema['minItems']
    e << err(path, spath + ['maxItems'], 'maxItems', "#{fmt(a)} has more than #{schema['maxItems']} items") if schema.key?('maxItems') && a.length > schema['maxItems']
    if schema['uniqueItems']
      seen = Set.new
      unique = a.all? { |x| key = MiniJSON.generate(x); seen.add?(key) }
      e << err(path, spath + ['uniqueItems'], 'uniqueItems', "#{fmt(a)} has non-unique elements") unless unique
    end
    if schema['prefixItems'].is_a?(Array)
      schema['prefixItems'].each_with_index { |sub, i| e.concat(validate(a[i], sub, path + [i], spath + ['prefixItems', i])) if i < a.length }
      if schema['items'].is_a?(Hash)
        (schema['prefixItems'].length...a.length).each { |i| e.concat(validate(a[i], schema['items'], path + [i], spath + ['items'])) }
      elsif schema['items'] == false && a.length > schema['prefixItems'].length
        e << err(path, spath + ['items'], 'items', "Additional items are not allowed")
      end
    elsif schema['items'].is_a?(Hash)
      a.each_with_index { |item, i| e.concat(validate(item, schema['items'], path + [i], spath + ['items'])) }
    elsif schema['items'].is_a?(Array)
      schema['items'].each_with_index { |sub, i| e.concat(validate(a[i], sub, path + [i], spath + ['items', i])) if i < a.length }
      if schema.key?('additionalItems') && schema['additionalItems'] == false && a.length > schema['items'].length
        e << err(path, spath + ['additionalItems'], 'additionalItems', "Additional items are not allowed")
      elsif schema['additionalItems'].is_a?(Hash)
        (schema['items'].length...a.length).each { |i| e.concat(validate(a[i], schema['additionalItems'], path + [i], spath + ['additionalItems'])) }
      end
    end
    if schema['contains'].is_a?(Hash)
      matches = a.count { |item| validate(item, schema['contains'], path, spath).empty? }
      min = schema.key?('minContains') ? schema['minContains'] : 1
      max = schema['maxContains']
      if matches < min
        e << err(path, spath + ['contains'], 'contains', "#{fmt(a)} does not contain items matching the given schema")
      elsif max && matches > max
        e << err(path, spath + ['maxContains'], 'maxContains', "#{fmt(a)} contains too many items matching the given schema")
      end
    end
    e
  end

  def validate_object(o, schema, path, spath)
    e = []
    e << err(path, spath + ['minProperties'], 'minProperties', "#{fmt(o)} has fewer than #{schema['minProperties']} properties") if schema.key?('minProperties') && o.length < schema['minProperties']
    e << err(path, spath + ['maxProperties'], 'maxProperties', "#{fmt(o)} has more than #{schema['maxProperties']} properties") if schema.key?('maxProperties') && o.length > schema['maxProperties']

    props = schema['properties'].is_a?(Hash) ? schema['properties'] : {}
    pat_props = schema['patternProperties'].is_a?(Hash) ? schema['patternProperties'] : {}
    covered = Set.new
    props.each do |name, sub|
      next unless o.key?(name)
      covered << name
      e.concat(validate(o[name], sub, path + [name], spath + ['properties', name]))
    end
    pat_props.each do |pat, sub|
      re = Regexp.new(pat) rescue nil
      next unless re
      o.each do |name, val|
        next unless name.match?(re)
        covered << name
        e.concat(validate(val, sub, path + [name], spath + ['patternProperties', pat]))
      end
    end

    if schema.key?('additionalProperties')
      extras = o.keys.reject { |k| covered.include?(k) }
      ap = schema['additionalProperties']
      if ap == false && extras.any?
        msg = if extras.length == 1
                "Additional properties are not allowed ('#{extras[0]}' was unexpected)"
              else
                "Additional properties are not allowed (#{extras.map { |x| "'#{x}'" }.join(', ')} were unexpected)"
              end
        e << err(path, spath + ['additionalProperties'], 'additionalProperties', msg)
      elsif ap.is_a?(Hash)
        extras.each { |name| e.concat(validate(o[name], ap, path + [name], spath + ['additionalProperties'])) }
      end
    end

    if schema['required'].is_a?(Array)
      schema['required'].each do |name|
        e << err(path, spath + ['required'], 'required', "#{fmt(name)} is a required property") unless o.key?(name)
      end
    end

    if schema['propertyNames'].is_a?(Hash)
      o.keys.each { |name| e.concat(validate(name, schema['propertyNames'], path, spath + ['propertyNames'])) }
    end
    if schema['dependencies'].is_a?(Hash)
      schema['dependencies'].each do |name, dep|
        next unless o.key?(name)
        if dep.is_a?(Array)
          dep.each { |d| e << err(path, spath + ['dependencies'], 'dependencies', "#{fmt(d)} is a dependency of #{fmt(name)}") unless o.key?(d) }
        elsif dep.is_a?(Hash)
          e.concat(validate(o, dep, path, spath + ['dependencies', name]))
        end
      end
    end
    if schema['dependentRequired'].is_a?(Hash)
      schema['dependentRequired'].each do |name, dep|
        next unless o.key?(name) && dep.is_a?(Array)
        dep.each { |d| e << err(path, spath + ['dependentRequired'], 'dependentRequired', "#{fmt(d)} is a dependency of #{fmt(name)}") unless o.key?(d) }
      end
    end
    if schema['dependentSchemas'].is_a?(Hash)
      schema['dependentSchemas'].each do |name, dep|
        e.concat(validate(o, dep, path, spath + ['dependentSchemas', name])) if o.key?(name) && dep.is_a?(Hash)
      end
    end
    e
  end

  def validate_combiners(instance, schema, path, spath)
    e = []
    if schema['allOf'].is_a?(Array)
      schema['allOf'].each_with_index { |sub, i| e.concat(validate(instance, sub, path, spath + ['allOf', i])) }
    end
    if schema['anyOf'].is_a?(Array)
      ok = schema['anyOf'].any? { |sub| validate(instance, sub, path, spath).empty? }
      e << err(path, spath + ['anyOf'], 'anyOf', "#{fmt(instance)} is not valid under any of the schemas listed in the 'anyOf' keyword") unless ok
    end
    if schema['oneOf'].is_a?(Array)
      count = schema['oneOf'].count { |sub| validate(instance, sub, path, spath).empty? }
      if count == 0
        e << err(path, spath + ['oneOf'], 'oneOf', "#{fmt(instance)} is not valid under any of the schemas listed in the 'oneOf' keyword")
      elsif count > 1
        e << err(path, spath + ['oneOf'], 'oneOf', "#{fmt(instance)} is valid under more than one of the schemas listed in the 'oneOf' keyword")
      end
    end
    if schema['not'].is_a?(Hash) && validate(instance, schema['not'], path, spath).empty?
      e << err(path, spath + ['not'], 'not', "#{fmt(schema['not'])} is not allowed for #{fmt(instance)}")
    end
    if schema['if'].is_a?(Hash)
      if validate(instance, schema['if'], path, spath).empty?
        e.concat(validate(instance, schema['then'], path, spath + ['then'])) if schema['then'].is_a?(Hash)
      elsif schema['else'].is_a?(Hash)
        e.concat(validate(instance, schema['else'], path, spath + ['else']))
      end
    end
    e
  end

  def err(path, spath, kw, msg)
    ValidationError.new(path, spath, kw, msg)
  end

  def resolve_ref(schema)
    ref = schema['$ref']
    return schema unless ref.is_a?(String)
    target = nil
    if ref.start_with?('#')
      target = pointer(@root, ref[1..])
    elsif ref.include?('#')
      file, frag = ref.split('#', 2)
      begin
        doc = YAML.safe_load(File.read(file), permitted_classes: [], aliases: false)
        target = pointer(doc, frag || '')
      rescue StandardError
        target = nil
      end
    end
    return schema unless target
    merged = schema.reject { |k, _| k == '$ref' }
    target.is_a?(Hash) ? target.merge(merged) : target
  end

  def pointer(doc, ptr)
    return doc if ptr.nil? || ptr.empty?
    ptr = ptr[1..] if ptr.start_with?('/')
    ptr.split('/').reduce(doc) do |cur, part|
      key = part.gsub('~1', '/').gsub('~0', '~')
      cur.is_a?(Array) ? cur[key.to_i] : cur[key]
    end
  rescue StandardError
    nil
  end

  def type_ok?(v, type)
    Array(type).any? do |t|
      case t
      when 'null' then v.nil?
      when 'boolean' then v == true || v == false
      when 'object' then object?(v)
      when 'array' then v.is_a?(Array)
      when 'number' then numeric?(v)
      when 'integer' then v.is_a?(Integer) || (v.is_a?(Float) && v.finite? && v == v.to_i)
      when 'string' then v.is_a?(String)
      else true
      end
    end
  end

  def type_desc(type)
    Array(type).map { |t| fmt(t) }.join(' or ')
  end

  def numeric?(v)
    v.is_a?(Numeric) && !(v == true || v == false)
  end

  def object?(v)
    v.is_a?(Hash)
  end

  def fmt(v)
    MiniJSON.generate(v)
  end

  def join_values(vals)
    vals = vals.map { |v| fmt(v) }
    return '' if vals.empty?
    return vals[0] if vals.length == 1
    return vals.join(' or ') if vals.length == 2
    vals[0...-1].join(', ') + ', or ' + vals[-1]
  end

  def format_ok?(format, s)
    case format
    when 'email' then s.match?(/\A[^@\s]+@[^@\s]+\.[^@\s]+\z/)
    when 'uri' then (u = URI.parse(s); !!u.scheme rescue false)
    when 'date-time' then s.match?(/\A\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})\z/)
    when 'date' then s.match?(/\A\d{4}-\d{2}-\d{2}\z/)
    when 'ipv4' then (IPAddr.new(s).ipv4? rescue false)
    when 'ipv6' then (IPAddr.new(s).ipv6? rescue false)
    when 'hostname' then s.match?(/\A(?=.{1,253}\z)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)*[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\z/)
    else true
    end
  end
end

class CLI
  HELP = <<~TXT
    Usage: executable [OPTIONS] [SCHEMA]

    Arguments:
      [SCHEMA]  The JSON Schema to validate with (i.e. schema.json)

    Options:
      -i, --instance <INSTANCES>       A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)
      -d, --draft <DRAFT>              Enforce a specific JSON Schema draft [possible values: 4, 6, 7, 2019, 2020]
          --assert-format              Turn ON format validation
          --no-assert-format           Turn OFF format validation
          --output <OUTPUT>            Select output style: text (default), flag, list, hierarchical [default: text] [possible values: text, flag, list, hierarchical]
      -v, --version                    Show program's version number and exit
          --errors-only                Only show validation errors
          --connect-timeout <SECONDS>  Timeout for establishing connections (in seconds)
          --timeout <SECONDS>          Total timeout for HTTP requests (in seconds)
      -k, --insecure                   Skip TLS certificate verification (dangerous!)
          --cacert <FILE>              Path to a custom CA certificate file (PEM format)
      -h, --help                       Print help
  TXT

  def initialize(argv)
    @argv = argv.dup
    @instances = []
    @output = 'text'
    @assert_format = false
    @errors_only = false
  end

  def run
    parse!
    schema_path = @argv.shift
    unless schema_path
      warn 'Error: Missing argument SCHEMA'
      return 2
    end
    schema = load_json(schema_path)
    mark_format!(schema) if @assert_format
    validator = Validator.new(schema, schema_path)

    if @instances.empty?
      puts 'Schema is valid'
      return 0
    end

    any_invalid = false
    @instances.each do |inst_path|
      instance = load_json(inst_path)
      errors = validator.validate(instance)
      any_invalid ||= !errors.empty?
      emit(schema_path, inst_path, validator, errors)
    end
    any_invalid ? 1 : 0
  rescue SystemExit => e
    e.status
  rescue OptionParser::InvalidOption, OptionParser::MissingArgument => e
    warn "error: #{e.message}"
    2
  rescue Errno::ENOENT
    warn 'Error: No such file or directory (os error 2)'
    1
  rescue Psych::Exception => e
    warn "Error: #{json_error(e.message)}"
    1
  rescue StandardError => e
    warn "Error: #{e.message}"
    1
  end

  private

  def parse!
    OptionParser.new do |o|
      o.on('-i', '--instance PATH') { |v| @instances << v }
      o.on('-d', '--draft DRAFT') { |_v| }
      o.on('--assert-format') { @assert_format = true }
      o.on('--no-assert-format') { @assert_format = false }
      o.on('--output OUTPUT') { |v| @output = v }
      o.on('-v', '--version') { puts 'Version: 0.41.0'; exit 0 }
      o.on('--errors-only') { @errors_only = true }
      o.on('--connect-timeout SECONDS') { |_v| }
      o.on('--timeout SECONDS') { |_v| }
      o.on('-k', '--insecure') { }
      o.on('--cacert FILE') { |_v| }
      o.on('-h', '--help') { print HELP; exit 0 }
    end.parse!(@argv)
  end

  def load_json(path)
    YAML.safe_load(File.read(path), permitted_classes: [], aliases: false)
  end

  def mark_format!(obj)
    case obj
    when Hash
      obj['__assert_format'] = true if obj.key?('format')
      obj.each_value { |v| mark_format!(v) }
    when Array
      obj.each { |v| mark_format!(v) }
    end
  end

  def json_error(msg)
    if msg =~ /unexpected token at/
      'expected value at line 1 column 1'
    else
      msg.sub(/\A\d+: /, '')
    end
  end

  def emit(schema_path, inst_path, validator, errors)
    valid = errors.empty?
    case @output
    when 'flag'
      puts MiniJSON.generate({ instance: inst_path, output: 'flag', payload: { valid: valid }, schema: schema_path })
    when 'list'
      puts MiniJSON.generate({ instance: inst_path, output: 'list', payload: list_payload(validator, errors), schema: schema_path })
    when 'hierarchical'
      puts MiniJSON.generate({ instance: inst_path, output: 'hierarchical', payload: hierarchical_payload(validator, errors), schema: schema_path })
    else
      if valid
        puts "#{inst_path} - VALID" unless @errors_only
      else
        puts "#{inst_path} - INVALID. Errors:"
        errors.each_with_index { |er, i| puts "#{i + 1}. #{er.message}" }
      end
    end
  end

  def list_payload(validator, errors)
    if errors.empty?
      { valid: true, details: [{ valid: true, evaluationPath: '', schemaLocation: validator.schema_uri + '#', instanceLocation: '' }] }
    else
      details = [{ valid: false, evaluationPath: '', schemaLocation: validator.schema_uri + '#', instanceLocation: '' }]
      errors.each do |er|
        details << detail_hash(validator, er)
      end
      { valid: false, details: details }
    end
  end

  def hierarchical_payload(validator, errors)
    if errors.empty?
      { valid: true, evaluationPath: '', schemaLocation: validator.schema_uri + '#', instanceLocation: '' }
    else
      root = { valid: false, evaluationPath: '', schemaLocation: validator.schema_uri + '#', instanceLocation: '', details: [] }
      errors.each { |er| root[:details] << detail_hash(validator, er) }
      root
    end
  end

  def detail_hash(validator, er)
    h = { valid: false, evaluationPath: ptr(er.schema_path), schemaLocation: validator.schema_uri + '#' + ptr(er.schema_path), instanceLocation: ptr(er.path) }
    h[:errors] = { er.keyword => er.message } unless er.keyword.to_s.empty?
    h
  end

  def ptr(parts)
    return '' if parts.empty?
    '/' + parts.map { |p| p.to_s.gsub('~', '~0').gsub('/', '~1') }.join('/')
  end
end

exit CLI.new(ARGV).run
