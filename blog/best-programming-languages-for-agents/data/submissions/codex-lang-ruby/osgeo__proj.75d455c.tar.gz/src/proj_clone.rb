#!/usr/bin/env ruby
# A compact cleanroom reimplementation of the classic PROJ "proj" utility.

STDOUT.sync = true
STDERR.sync = true

RAD = Math::PI / 180.0
DEG = 180.0 / Math::PI

ELLIPSOIDS = {
  'GRS80' => [6378137.0, 298.257222101],
  'WGS84' => [6378137.0, 298.257223563],
  'clrk66' => [6378206.4, nil, 6356583.8],
  'intl' => [6378388.0, 297.0],
  'sphere' => [6370997.0, nil, 6370997.0]
}

PROJ_LIST = [
  ['aea', 'Albers Equal Area'], ['aeqd', 'Azimuthal Equidistant'],
  ['cass', 'Cassini'], ['cea', 'Equal Area Cylindrical'],
  ['eqc', 'Equidistant Cylindrical (Plate Carree)'],
  ['laea', 'Lambert Azimuthal Equal Area'], ['lcc', 'Lambert Conformal Conic'],
  ['lonlat', 'Lat/long (Geodetic)'], ['longlat', 'Lat/long (Geodetic alias)'],
  ['merc', 'Mercator'], ['moll', 'Mollweide'], ['robin', 'Robinson'],
  ['sinu', 'Sinusoidal'], ['stere', 'Stereographic'],
  ['tmerc', 'Transverse Mercator'], ['utm', 'Universal Transverse Mercator'],
  ['webmerc', 'Web Mercator / Pseudo Mercator']
]

ELLPS_LIST = [
  ['MERIT', 'a=6378137.0', 'rf=298.257', 'MERIT 1983'],
  ['GRS80', 'a=6378137.0', 'rf=298.257222101', 'GRS 1980(IUGG, 1980)'],
  ['airy', 'a=6377563.396', 'rf=299.3249646', 'Airy 1830'],
  ['intl', 'a=6378388.0', 'rf=297.', 'International 1924 (Hayford 1909, 1910)'],
  ['clrk66', 'a=6378206.4', 'b=6356583.8', 'Clarke 1866'],
  ['WGS72', 'a=6378135.0', 'rf=298.26', 'WGS 72'],
  ['WGS84', 'a=6378137.0', 'rf=298.257223563', 'WGS 84'],
  ['sphere', 'a=6370997.0', 'b=6370997.0', 'Normal Sphere (r=6370997)']
]

UNITS_LIST = [
  ['mm', '0.001', 'millimetre'], ['cm', '0.01', 'centimetre'],
  ['m', '1', 'metre'], ['ft', '0.3048', 'foot'],
  ['us-ft', '0.304800609601219', 'US survey foot'],
  ['km', '1000', 'kilometre'], ['mi', '1609.344', 'Statute mile'],
  ['yd', '0.9144', 'yard'], ['in', '0.0254', 'inch']
]
UNIT_FACTORS = {
  'm' => 1.0, 'km' => 1000.0, 'cm' => 0.01, 'mm' => 0.001,
  'ft' => 0.3048, 'us-ft' => 0.304800609601219,
  'mi' => 1609.344, 'yd' => 0.9144, 'in' => 0.0254
}

def usage
  puts 'Rel. 9.9.0, September 15th, 2026'
  puts 'usage: executable [-bdeEfiIlmorsStTvVwW [args]] [+opt[=arg] ...] [file ...]'
end

def parse_args(argv)
  st = {
    inverse: false, echo: false, reverse_in: false, reverse_out: false,
    fmt: '%.2f', dms: true, multiplier: 1.0, opts: {}, files: [],
    list: nil, verbose: false
  }
  i = 0
  while i < argv.length
    a = argv[i]
    if a.start_with?('+')
      k, v = a[1..].split('=', 2)
      st[:opts][k] = v.nil? ? true : v
    elsif a.start_with?('-') && a != '-'
      cluster = a[1..]
      if cluster == '-help' || cluster == '-'
        abort_invalid('--')
      elsif cluster.start_with?('l') && cluster.length > 1
        st[:list] = cluster[1..]
      else
        j = 0
        while j < cluster.length
          ch = cluster[j]
          case ch
          when 'I' then st[:inverse] = true
          when 'E' then st[:echo] = true
          when 'r' then st[:reverse_in] = true
          when 's' then st[:reverse_out] = true
          when 'V' then st[:verbose] = true
          when 'l' then st[:list] = ''
          when 'f'
            if j + 1 < cluster.length
              st[:fmt] = cluster[(j + 1)..]
              j = cluster.length
            else
              i += 1
              st[:fmt] = argv[i] || st[:fmt]
            end
          when 'd', 'w', 'W'
            val = nil
            if j + 1 < cluster.length
              val = cluster[(j + 1)..]
              j = cluster.length
            else
              i += 1
              val = argv[i]
            end
            st[:fmt] = "% .#{val.to_i}f".sub('% ', '%') if ch == 'd' && val
          when 'm'
            if j + 1 < cluster.length
              st[:multiplier] = cluster[(j + 1)..].to_f
              j = cluster.length
            else
              i += 1
              st[:multiplier] = (argv[i] || '1').to_f
            end
          else
            # Accepted but behavior is not relevant for the common text modes.
          end
          j += 1
        end
      end
    else
      st[:files] << a
    end
    i += 1
  end
  st
end

def abort_invalid(opt)
  puts 'Rel. 9.9.0, September 15th, 2026'
  shown = opt == '--' ? '--' : opt.sub(/^-/, '')
  warn "<executable>: \ninvalid option: #{shown}\nprogram abnormally terminated"
  exit 3
end

def show_list(kind)
  case kind
  when '', nil
    PROJ_LIST.each { |n, d| puts "#{n} : #{d}" }
  when 'e'
    ELLPS_LIST.each { |r| printf("%9s %-16s %-18s %s\n", *r) }
  when 'u'
    UNITS_LIST.each { |r| printf("%12s %-20s %s\n", *r) }
  else
    PROJ_LIST.each { |n, d| puts "#{n} : #{d}" }
  end
end

def num(opt, key, default)
  opt.key?(key) ? opt[key].to_f : default
end

def ellipsoid(opt)
  if opt['R']
    a = opt['R'].to_f
    return [a, a, 0.0, 0.0]
  end
  if opt['a']
    a = opt['a'].to_f
    b = opt['b'] ? opt['b'].to_f : a * (1.0 - 1.0 / (opt['rf'] || 298.257222101).to_f)
  else
    name = opt['ellps'] || (opt['datum'] == 'WGS84' ? 'WGS84' : 'GRS80')
    rec = ELLIPSOIDS[name] || ELLIPSOIDS['GRS80']
    a = rec[0]
    b = rec[2] || a * (1.0 - 1.0 / rec[1])
  end
  es = 1.0 - (b * b) / (a * a)
  [a, b, es, Math.sqrt(es.abs)]
end

def setup(opt)
  a, _b, es, e = ellipsoid(opt)
  proj = (opt['proj'] || '').downcase
  if proj == 'utm'
    zone = (opt['zone'] || 31).to_i
    opt['lon_0'] ||= ((zone - 1) * 6 - 180 + 3).to_s
    opt['x_0'] ||= '500000'
    opt['y_0'] ||= opt['south'] ? '10000000' : '0'
    opt['k_0'] ||= '0.9996'
    proj = 'tmerc'
  end
  lat_ts = num(opt, 'lat_ts', 0.0) * RAD
  k0 = num(opt, 'k_0', num(opt, 'k', 1.0))
  if proj == 'merc' && opt['lat_ts']
    k0 = Math.cos(lat_ts) / Math.sqrt(1 - es * Math.sin(lat_ts)**2)
  end
  {
    proj: proj, a: a, es: es, e: e,
    lon0: num(opt, 'lon_0', 0.0) * RAD,
    lat0: num(opt, 'lat_0', 0.0) * RAD,
    lat_ts: lat_ts,
    lat1: num(opt, 'lat_1', 0.0) * RAD,
    lat2: num(opt, 'lat_2', num(opt, 'lat_1', num(opt, 'lat_ts', 0.0))) * RAD,
    x0: num(opt, 'x_0', 0.0), y0: num(opt, 'y_0', 0.0),
    k0: k0,
    unit: UNIT_FACTORS[opt['units']] || (opt['to_meter'] ? opt['to_meter'].to_f : 1.0)
  }
end

def tsfn(phi, e)
  t = Math.tan(Math::PI / 4 - phi / 2)
  e == 0.0 ? t : t / ((1 - e * Math.sin(phi)) / (1 + e * Math.sin(phi)))**(e / 2)
end

def mlfn(phi, es, a)
  e2 = es; e4 = e2 * e2; e6 = e4 * e2
  a * ((1 - e2 / 4 - 3 * e4 / 64 - 5 * e6 / 256) * phi -
       (3 * e2 / 8 + 3 * e4 / 32 + 45 * e6 / 1024) * Math.sin(2 * phi) +
       (15 * e4 / 256 + 45 * e6 / 1024) * Math.sin(4 * phi) -
       (35 * e6 / 3072) * Math.sin(6 * phi))
end

def inv_mlfn(m, es, a)
  phi = m / a
  8.times do
    d = (mlfn(phi, es, a) - m) / (a * (1 - es) / ((1 - es * Math.sin(phi)**2)**1.5))
    phi -= d
    break if d.abs < 1e-12
  end
  phi
end

def forward(lon_deg, lat_deg, p)
  lam = lon_deg * RAD
  phi = lat_deg * RAD
  a = p[:a]; es = p[:es]; e = p[:e]; dl = lam - p[:lon0]
  x = y = nil
  case p[:proj]
  when 'merc'
    x = a * p[:k0] * dl
    y = -a * p[:k0] * Math.log(tsfn(phi, e))
  when 'webmerc'
    x = a * dl
    y = a * Math.log(Math.tan(Math::PI / 4 + phi / 2))
  when 'eqc', 'latlong'
    x = a * dl * Math.cos(p[:lat_ts])
    y = mlfn(phi, es, a) - mlfn(p[:lat0], es, a)
  when 'sinu'
    n = a / Math.sqrt(1 - es * Math.sin(phi)**2)
    x = n * dl * Math.cos(phi)
    y = mlfn(phi, es, a) - mlfn(p[:lat0], es, a)
  when 'moll'
    th = phi
    12.times do
      d = -(2 * th + Math.sin(2 * th) - Math::PI * Math.sin(phi)) / (2 + 2 * Math.cos(2 * th))
      th += d
      break if d.abs < 1e-12
    end
    x = 2 * Math.sqrt(2) / Math::PI * a * dl * Math.cos(th)
    y = Math.sqrt(2) * a * Math.sin(th)
  when 'laea'
    s0 = Math.sin(p[:lat0]); c0 = Math.cos(p[:lat0])
    s = Math.sin(phi); c = Math.cos(phi)
    k = Math.sqrt(2 / (1 + s0 * s + c0 * c * Math.cos(dl)))
    x = a * k * c * Math.sin(dl)
    y = a * k * (c0 * s - s0 * c * Math.cos(dl))
  when 'aeqd'
    s0 = Math.sin(p[:lat0]); c0 = Math.cos(p[:lat0])
    s = Math.sin(phi); c = Math.cos(phi)
    cosc = s0 * s + c0 * c * Math.cos(dl)
    cc = Math.acos([[cosc, -1].max, 1].min)
    k = cc.abs < 1e-12 ? 1 : cc / Math.sin(cc)
    x = a * k * c * Math.sin(dl)
    y = a * k * (c0 * s - s0 * c * Math.cos(dl))
  when 'stere'
    s0 = Math.sin(p[:lat0]); c0 = Math.cos(p[:lat0])
    s = Math.sin(phi); c = Math.cos(phi)
    k = 2 * a * p[:k0] / (1 + s0 * s + c0 * c * Math.cos(dl))
    x = k * c * Math.sin(dl)
    y = k * (c0 * s - s0 * c * Math.cos(dl))
  when 'lcc'
    lcc = lcc_params(p)
    rho = a * lcc[:f] * tsfn(phi, e)**lcc[:n]
    th = lcc[:n] * dl
    x = rho * Math.sin(th)
    y = lcc[:rho0] - rho * Math.cos(th)
  when 'tmerc', 'etmerc'
    x, y = tmerc_forward(lam, phi, p)
  else
    x = a * dl
    y = a * phi
  end
  [(x + p[:x0]) / p[:unit], (y + p[:y0]) / p[:unit]]
end

def lcc_params(p)
  e = p[:e]; a = p[:a]
  phi1 = p[:lat1] == 0.0 ? p[:lat0] : p[:lat1]
  phi2 = p[:lat2] == 0.0 ? phi1 : p[:lat2]
  m1 = Math.cos(phi1) / Math.sqrt(1 - p[:es] * Math.sin(phi1)**2)
  t1 = tsfn(phi1, e)
  if (phi1 - phi2).abs < 1e-12
    n = Math.sin(phi1)
  else
    m2 = Math.cos(phi2) / Math.sqrt(1 - p[:es] * Math.sin(phi2)**2)
    t2 = tsfn(phi2, e)
    n = Math.log(m1 / m2) / Math.log(t1 / t2)
  end
  f = m1 / (n * t1**n)
  rho0 = a * f * tsfn(p[:lat0], e)**n
  { n: n, f: f, rho0: rho0 }
end

def tmerc_forward(lam, phi, p)
  a = p[:a]; es = p[:es]; ep2 = es / (1 - es); k0 = p[:k0]
  n = a / Math.sqrt(1 - es * Math.sin(phi)**2)
  t = Math.tan(phi)**2
  c = ep2 * Math.cos(phi)**2
  aa = Math.cos(phi) * (lam - p[:lon0])
  m = mlfn(phi, es, a)
  m0 = mlfn(p[:lat0], es, a)
  x = k0 * n * (aa + (1 - t + c) * aa**3 / 6 +
      (5 - 18 * t + t**2 + 72 * c - 58 * ep2) * aa**5 / 120)
  y = k0 * (m - m0 + n * Math.tan(phi) * (aa**2 / 2 +
      (5 - t + 9 * c + 4 * c**2) * aa**4 / 24 +
      (61 - 58 * t + t**2 + 600 * c - 330 * ep2) * aa**6 / 720))
  [x, y]
end

def inverse(x, y, p)
  x *= p[:unit]; y *= p[:unit]
  x -= p[:x0]; y -= p[:y0]
  a = p[:a]; es = p[:es]; e = p[:e]
  case p[:proj]
  when 'merc'
    lon = p[:lon0] + x / (a * p[:k0])
    t = Math.exp(-y / (a * p[:k0]))
    phi = Math::PI / 2 - 2 * Math.atan(t)
    8.times do
      phi2 = Math::PI / 2 - 2 * Math.atan(t * ((1 - e * Math.sin(phi)) / (1 + e * Math.sin(phi)))**(e / 2))
      break if (phi2 - phi).abs < 1e-13
      phi = phi2
    end
    [lon * DEG, phi * DEG]
  when 'webmerc'
    [(p[:lon0] + x / a) * DEG, (Math::PI / 2 - 2 * Math.atan(Math.exp(-y / a))) * DEG]
  when 'eqc'
    [(p[:lon0] + x / (a * Math.cos(p[:lat_ts]))) * DEG,
     inv_mlfn(y + mlfn(p[:lat0], es, a), es, a) * DEG]
  when 'tmerc', 'etmerc'
    tmerc_inverse(x, y, p)
  else
    # Generic Newton inverse for forward-only projections.
    lon = p[:lon0] * DEG + x / a * DEG
    lat = y / a * DEG
    12.times do
      fx, fy = forward(lon, lat, p)
      fx -= p[:x0]; fy -= p[:y0]
      ex = fx - x; ey = fy - y
      break if ex.abs + ey.abs < 1e-7
      h = 1e-6
      fx1, fy1 = forward(lon + h, lat, p); fx2, fy2 = forward(lon, lat + h, p)
      j11 = (fx1 - p[:x0] - fx) / h; j12 = (fx2 - p[:x0] - fx) / h
      j21 = (fy1 - p[:y0] - fy) / h; j22 = (fy2 - p[:y0] - fy) / h
      det = j11 * j22 - j12 * j21
      break if det.abs < 1e-20
      lon -= ( ex * j22 - j12 * ey) / det
      lat -= (-ex * j21 + j11 * ey) / det
    end
    [lon, lat]
  end
end

def tmerc_inverse(x, y, p)
  a = p[:a]; es = p[:es]; ep2 = es / (1 - es); k0 = p[:k0]
  m0 = mlfn(p[:lat0], es, a)
  m = m0 + y / k0
  mu = inv_mlfn(m, es, a)
  n1 = a / Math.sqrt(1 - es * Math.sin(mu)**2)
  r1 = a * (1 - es) / ((1 - es * Math.sin(mu)**2)**1.5)
  t1 = Math.tan(mu)**2
  c1 = ep2 * Math.cos(mu)**2
  d = x / (n1 * k0)
  lat = mu - (n1 * Math.tan(mu) / r1) * (d**2 / 2 -
        (5 + 3 * t1 + 10 * c1 - 4 * c1**2 - 9 * ep2) * d**4 / 24 +
        (61 + 90 * t1 + 298 * c1 + 45 * t1**2 - 252 * ep2 - 3 * c1**2) * d**6 / 720)
  lon = p[:lon0] + (d - (1 + 2 * t1 + c1) * d**3 / 6 +
        (5 - 2 * c1 + 28 * t1 - 3 * c1**2 + 8 * ep2 + 24 * t1**2) * d**5 / 120) / Math.cos(mu)
  [lon * DEG, lat * DEG]
end

def parse_coord(s)
  str = s.to_s.strip
  sign = 1.0
  sign = -1.0 if str =~ /[WwSs]/
  m = str.match(/[-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?/)
  return 0.0 unless m
  nums = str.scan(/[-+]?\d+(?:\.\d*)?(?:[eE][-+]?\d+)?/).map(&:to_f)
  sign *= -1 if nums[0] < 0
  nums[0] = nums[0].abs
  val = nums[0] + (nums[1] || 0) / 60.0 + (nums[2] || 0) / 3600.0
  sign * val
end

def dms(v, pos, neg)
  hemi = v < 0 ? neg : pos
  val = v.abs
  deg = val.round(10)
  if (deg - deg.round).abs < 5e-5
    "#{deg.round}d#{hemi}"
  else
    format('%.6f', v)
  end
end

def fmt_num(v, fmt)
  begin
    format(fmt, v)
  rescue StandardError
    format('%.2f', v)
  end
end

state = parse_args(ARGV)
if state[:list]
  show_list(state[:list])
  exit 0
end
if state[:opts].empty?
  usage
  exit 0
end

p = setup(state[:opts])
if state[:verbose]
  puts "##{p[:proj] == 'merc' ? 'Mercator' : p[:proj]}"
  puts "# +proj=#{p[:proj]} +ellps=GRS80"
  puts '#Final Earth figure: ellipsoid'
  printf("#  Major axis (a): %.3f\n", p[:a])
end

inputs = state[:files].empty? ? [$stdin] : state[:files].map { |f| File.open(f, 'r') }
inputs.each do |io|
  io.each_line do |line|
    if line.start_with?('#')
      print line
      next
    end
    stripped = line.chomp
    toks = stripped.split(/\s+/, 3)
    if toks.length < 2
      puts state[:inverse] ? "0dE\t0dN" : "0.00\t0.00"
      next
    end
    a = parse_coord(toks[0]); b = parse_coord(toks[1])
    a, b = b, a if state[:reverse_in]
    if state[:inverse]
      lon, lat = inverse(a, b, p)
      out1 = state[:dms] && state[:fmt] == '%.2f' ? dms(lon, 'E', 'W') : fmt_num(lon, state[:fmt])
      out2 = state[:dms] && state[:fmt] == '%.2f' ? dms(lat, 'N', 'S') : fmt_num(lat, state[:fmt])
    else
      x, y = forward(a, b, p)
      x *= state[:multiplier]; y *= state[:multiplier]
      out1 = fmt_num(x, state[:fmt]); out2 = fmt_num(y, state[:fmt])
    end
    out1, out2 = out2, out1 if state[:reverse_out]
    suffix = toks[2] ? " #{toks[2]}" : ''
    prefix = state[:echo] ? "#{toks[0]} #{toks[1]}\t" : ''
    puts "#{prefix}#{out1}\t#{out2}#{suffix}"
  end
end
