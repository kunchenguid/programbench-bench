#!/usr/bin/env ruby
# frozen_string_literal: true

require "cgi"
require "fileutils"
require "socket"

VERSION = "0.6.5"

def puts_main_help(long: true)
  if long
    puts <<~HELP.chomp
      🎁 generate beautiful landing pages for your projects

      Usage: executable [OPTIONS] <COMMAND>

      Commands:
        build     Build an oranda site
        dev       Start a local development server that recompiles your oranda site if a file changes
        serve     Start a file server to access your oranda site in a browser
        generate  Generate infrastructure files for oranda sites
        help      Print this message or the help of the given subcommand(s)

      Options:
        -h, --help
                Print help (see a summary with '-h')

        -V, --version
                Print version

      GLOBAL OPTIONS:
        -v, --verbose
                Whether to output more detailed debug information

            --output-format <OUTPUT_FORMAT>
                The format of the output
                
                [default: human]

                Possible values:
                - human: Human-readable output
                - json:  Machine-readable JSON output
    HELP
  else
    puts <<~HELP.chomp
      🎁 generate beautiful landing pages for your projects

      Usage: executable [OPTIONS] <COMMAND>

      Commands:
        build     Build an oranda site
        dev       Start a local development server that recompiles your oranda site if a file changes
        serve     Start a file server to access your oranda site in a browser
        generate  Generate infrastructure files for oranda sites
        help      Print this message or the help of the given subcommand(s)

      Options:
        -h, --help     Print help (see more with '--help')
        -V, --version  Print version

      GLOBAL OPTIONS:
        -v, --verbose                        Whether to output more detailed debug information
            --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                             human, json]
    HELP
  end
end

def global_options
  <<~TXT.chomp
    GLOBAL OPTIONS:
      -v, --verbose
              Whether to output more detailed debug information

          --output-format <OUTPUT_FORMAT>
              The format of the output
              
              [default: human]

              Possible values:
              - human: Human-readable output
              - json:  Machine-readable JSON output
  TXT
end

def build_help
  puts <<~HELP.chomp
    Build an oranda site

    Usage: executable build [OPTIONS]

    Options:
          --json-only
              Only build the artifacts JSON file (if applicable) and other files that may be used to
              support it, such as installer source files

      -h, --help
              Print help (see a summary with '-h')

    #{global_options}
  HELP
end

def dev_help
  puts <<~HELP.chomp
    Start a local development server that recompiles your oranda site if a file changes

    Usage: executable dev [OPTIONS]

    Options:
          --port <PORT>
              The port for the file server to be launched on

          --no-first-build
              Skip the first build before starting to watch for changes

      -i, --include-paths <INCLUDE_PATHS>
              List of extra paths to watch

      -h, --help
              Print help (see a summary with '-h')

    #{global_options}
  HELP
end

def serve_help
  puts <<~HELP.chomp
    Start a file server to access your oranda site in a browser

    Usage: executable serve [OPTIONS]

    Options:
          --port <PORT>
              [default: 7979]

      -h, --help
              Print help (see a summary with '-h')

    #{global_options}
  HELP
end

def generate_help
  puts <<~HELP.chomp
    Generate infrastructure files for oranda sites

    Usage: executable generate [OPTIONS] <COMMAND>

    Commands:
      ci    Generates a CI file that can be used to deploy your site
      help  Print this message or the help of the given subcommand(s)

    Options:
      -o, --output-path <OUTPUT_PATH>
              Path to the output file

      -s, --site-path <SITE_PATH>
              Path to your oranda site

      -h, --help
              Print help (see a summary with '-h')

    #{global_options}
  HELP
end

def generate_ci_help
  puts <<~HELP.chomp
    Generates a CI file that can be used to deploy your site

    Usage: executable generate ci [OPTIONS]

    Options:
          --ci <CI>
              What CI to generate a file for
              
              [default: github]

              Possible values:
              - github: Deploy to GitHub Pages using GitHub Actions

      -o, --output-path <OUTPUT_PATH>
              Path to the output file

      -s, --site-path <SITE_PATH>
              Path to your oranda site

      -h, --help
              Print help (see a summary with '-h')

    #{global_options}
  HELP
end

def clap_error(msg, usage = nil)
  warn "error: #{msg}"
  warn ""
  warn usage if usage
  warn "For more information, try '--help'."
  exit 2
end

def parse_globals(argv)
  globals = { output_format: "human", verbose: false }
  rest = []
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when "-v", "--verbose"
      globals[:verbose] = true
    when "--output-format"
      val = argv[i + 1]
      clap_error("a value is required for '--output-format <OUTPUT_FORMAT>'") unless val
      unless %w[human json].include?(val)
        clap_error("invalid value '#{val}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]\n")
      end
      globals[:output_format] = val
      i += 1
    when /\A--output-format=(.*)\z/
      val = Regexp.last_match(1)
      unless %w[human json].include?(val)
        clap_error("invalid value '#{val}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]\n")
      end
      globals[:output_format] = val
    else
      rest << a
    end
    i += 1
  end
  [globals, rest]
end

def config
  return @config if defined?(@config)

  @config = {}
  %w[oranda.json oranda.json5].each do |file|
    next unless File.file?(file)
    txt = File.read(file)
    @config = {
      "name" => txt[/"name"\s*:\s*"([^"]+)"/, 1],
      "title" => txt[/"title"\s*:\s*"([^"]+)"/, 1],
      "description" => txt[/"description"\s*:\s*"([^"]+)"/, 1]
    }.compact
    break
  end
  @config
end

def project_name
  cfg = config
  candidates = [
    cfg["name"], cfg["title"]
  ].compact
  return candidates.first.to_s unless candidates.empty?

  if File.file?("package.json")
    File.read("package.json")[/"name"\s*:\s*"([^"]+)"/, 1]
  elsif File.file?("Cargo.toml")
    txt = File.read("Cargo.toml")
    txt[/^\s*name\s*=\s*"([^"]+)"/, 1]
  elsif File.file?("README.md")
    File.read("README.md")[/^\s*#\s+(.+?)\s*$/, 1]
  else
    File.basename(Dir.pwd)
  end || "oranda site"
end

def description
  cfg = config
  cfg["description"] ||
    begin
      if File.file?("README.md")
        File.read("README.md").lines.map(&:strip).reject { |l| l.empty? || l.start_with?("#") }.first
      end
    end || "A project website generated by oranda."
end

def markdown_to_html(markdown)
  html = []
  in_code = false
  markdown.each_line do |line|
    s = line.chomp
    if s.start_with?("```")
      html << (in_code ? "</code></pre>" : "<pre><code>")
      in_code = !in_code
      next
    end
    if in_code
      html << CGI.escapeHTML(s)
    elsif s =~ /\A# (.+)/
      html << "<h1>#{CGI.escapeHTML(Regexp.last_match(1))}</h1>"
    elsif s =~ /\A## (.+)/
      html << "<h2>#{CGI.escapeHTML(Regexp.last_match(1))}</h2>"
    elsif s =~ /\A### (.+)/
      html << "<h3>#{CGI.escapeHTML(Regexp.last_match(1))}</h3>"
    elsif s.strip.empty?
      html << ""
    else
      esc = CGI.escapeHTML(s)
      esc = esc.gsub(/\*\*(.+?)\*\*/, '<strong>\1</strong>').gsub(/`([^`]+)`/, '<code>\1</code>')
      html << "<p>#{esc}</p>"
    end
  end
  html.join("\n")
end

def build_site(json_only: false, output_format: "human")
  FileUtils.mkdir_p("public")
  artifacts_json = <<~JSON
    {
      "schema_version": "1.0.0",
      "project": {
        "name": "#{json_escape(project_name)}",
        "description": "#{json_escape(description)}"
      },
      "artifacts": []
    }
  JSON
  File.write("public/artifacts.json", artifacts_json)
  return if json_only

  readme = File.file?("README.md") ? File.read("README.md") : "# #{project_name}\n\n#{description}\n"
  body = markdown_to_html(readme)
  css = <<~CSS
    :root { color-scheme: light dark; font-family: Inter, ui-sans-serif, system-ui, sans-serif; }
    body { margin: 0; background: #f7f7f5; color: #202124; line-height: 1.55; }
    main { max-width: 880px; margin: 0 auto; padding: 56px 24px; }
    h1 { font-size: 3rem; line-height: 1.05; margin: 0 0 16px; }
    h2 { margin-top: 40px; }
    a { color: #0b65c2; }
    pre { overflow: auto; padding: 16px; background: #202124; color: #f7f7f5; border-radius: 6px; }
    code { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
    .tagline { font-size: 1.2rem; color: #555; margin-bottom: 32px; }
    @media (prefers-color-scheme: dark) {
      body { background: #171717; color: #eeeeee; }
      .tagline { color: #bbbbbb; }
    }
  CSS
  File.write("public/oranda.css", css)
  html = <<~HTML
    <!doctype html>
    <html lang="en">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>#{CGI.escapeHTML(project_name)}</title>
      <meta name="description" content="#{CGI.escapeHTML(description)}">
      <link rel="stylesheet" href="oranda.css">
    </head>
    <body>
      <main>
        <p class="tagline">#{CGI.escapeHTML(description)}</p>
        #{body}
      </main>
    </body>
    </html>
  HTML
  File.write("public/index.html", html)
  File.write("public/favicon.ico", "") unless File.exist?("public/favicon.ico")
  if output_format == "json"
    puts "{\"level\":\"info\",\"message\":\"site built\",\"output_dir\":\"public\"}"
  end
end

def json_escape(str)
  str.to_s.gsub("\\", "\\\\\\").gsub('"', '\"').gsub("\n", "\\n")
end

def serve_public(port)
  unless Dir.exist?("public")
    warn "  × Could not find a build in public"
    warn "  help: Did you remember to run `oranda build`?"
    exit 255
  end
  server = TCPServer.new("0.0.0.0", port)
  puts "Serving public on http://localhost:#{port}"
  loop do
    client = server.accept
    request = client.gets.to_s
    path = request.split[1] || "/"
    path = "/" if path.include?("..")
    path = "/index.html" if path == "/"
    full = File.join("public", path.sub(%r{\A/+}, ""))
    if File.file?(full)
      data = File.binread(full)
      type = case File.extname(full)
             when ".html" then "text/html; charset=utf-8"
             when ".css" then "text/css; charset=utf-8"
             when ".json" then "application/json; charset=utf-8"
             else "application/octet-stream"
             end
      client.write "HTTP/1.1 200 OK\r\nContent-Length: #{data.bytesize}\r\nContent-Type: #{type}\r\n\r\n"
      client.write data
    else
      data = "Not Found\n"
      client.write "HTTP/1.1 404 Not Found\r\nContent-Length: #{data.bytesize}\r\nContent-Type: text/plain\r\n\r\n#{data}"
    end
    client.close
  end
end

def github_workflow(site_path)
  pages_url = "${{ steps.deployment.outputs.page_url }}"
  <<~YAML
    name: Web

    on:
      push:
        branches: [main]
      workflow_dispatch:

    permissions:
      contents: read
      pages: write
      id-token: write

    concurrency:
      group: pages
      cancel-in-progress: false

    jobs:
      build:
        runs-on: ubuntu-latest
        steps:
          - uses: actions/checkout@v4
          - name: Install oranda
            run: curl --proto '=https' --tlsv1.2 -LsSf https://github.com/axodotdev/oranda/releases/latest/download/oranda-installer.sh | sh
          - name: Build
            run: oranda build
            working-directory: #{site_path}
          - uses: actions/upload-pages-artifact@v3
            with:
              path: #{File.join(site_path, "public")}
      deploy:
        environment:
          name: github-pages
          url: #{pages_url}
        runs-on: ubuntu-latest
        needs: build
        steps:
          - name: Deploy to GitHub Pages
            id: deployment
            uses: actions/deploy-pages@v4
  YAML
end

def parse_keyed(argv, keys)
  opts = {}
  rest = []
  i = 0
  while i < argv.length
    a = argv[i]
    matched = false
    keys.each do |short, long, name|
      if a == short || a == long
        opts[name] = argv[i + 1]
        i += 1
        matched = true
        break
      elsif a.start_with?("#{long}=")
        opts[name] = a.split("=", 2)[1]
        matched = true
        break
      end
    end
    rest << a unless matched
    i += 1
  end
  [opts, rest]
end

globals, argv = parse_globals(ARGV)

if argv.empty?
  puts_main_help(long: false)
  exit 2
end

case argv[0]
when "-h", "--help"
  puts_main_help(long: argv[0] == "--help")
when "-V", "--version"
  puts "oranda #{VERSION}"
when "help"
  case argv[1]
  when nil then puts_main_help(long: true)
  when "build" then build_help
  when "dev" then dev_help
  when "serve" then serve_help
  when "generate" then generate_help
  else clap_error("unrecognized subcommand '#{argv[1]}'", "Usage: executable [OPTIONS] <COMMAND>\n")
  end
when "build"
  rest = argv[1..] || []
  if rest.include?("-h") || rest.include?("--help")
    build_help
  else
    unknown = rest.find { |a| a.start_with?("-") && a != "--json-only" }
    clap_error("unexpected argument '#{unknown}' found", "Usage: executable build [OPTIONS]\n") if unknown
    build_site(json_only: rest.include?("--json-only"), output_format: globals[:output_format])
  end
when "serve"
  rest = argv[1..] || []
  if rest.include?("-h") || rest.include?("--help")
    serve_help
  else
    opts, others = parse_keyed(rest, [[nil, "--port", :port]])
    unknown = others.find { |a| a.start_with?("-") }
    clap_error("unexpected argument '#{unknown}' found", "Usage: executable serve [OPTIONS]\n") if unknown
    serve_public((opts[:port] || "7979").to_i)
  end
when "dev"
  rest = argv[1..] || []
  if rest.include?("-h") || rest.include?("--help")
    dev_help
  else
    opts, others = parse_keyed(rest, [["-i", "--include-paths", :include], [nil, "--port", :port]])
    others.delete("--no-first-build")
    unknown = others.find { |a| a.start_with?("-") }
    clap_error("unexpected argument '#{unknown}' found", "Usage: executable dev [OPTIONS]\n") if unknown
    build_site(output_format: globals[:output_format]) unless rest.include?("--no-first-build")
    serve_public((opts[:port] || "7979").to_i)
  end
when "generate"
  rest = argv[1..] || []
  if rest.include?("-h") || rest.include?("--help")
    rest[0] == "ci" ? generate_ci_help : generate_help
  else
    opts, others = parse_keyed(rest, [["-o", "--output-path", :output], ["-s", "--site-path", :site], [nil, "--ci", :ci]])
    cmd = others.first
    if cmd.nil?
      clap_error("a subcommand is required", "Usage: executable generate [OPTIONS] <COMMAND>\n")
    elsif cmd != "ci"
      clap_error("unrecognized subcommand '#{cmd}'", "Usage: executable generate [OPTIONS] <COMMAND>\n")
    end
    ci = opts[:ci] || "github"
    unless ci == "github"
      clap_error("invalid value '#{ci}' for '--ci <CI>'\n  [possible values: github]\n\n  tip: a similar value exists: 'github'\n")
    end
    path = opts[:output] || ".github/workflows/web.yml"
    FileUtils.mkdir_p(File.dirname(path))
    File.write(path, github_workflow(opts[:site] || "."))
    puts "↪ >o_o< INFO: Generating a CI deploy workflow for your site..." if globals[:output_format] == "human"
  end
else
  if argv[0].start_with?("-")
    clap_error("unexpected argument '#{argv[0]}' found", "Usage: executable [OPTIONS] <COMMAND>\n")
  else
    clap_error("unrecognized subcommand '#{argv[0]}'", "Usage: executable [OPTIONS] <COMMAND>\n")
  end
end
