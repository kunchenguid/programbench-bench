#!/usr/bin/env ruby
# frozen_string_literal: true

require "fileutils"
require "open3"

BLUE = "\e[0;34m"
RED = "\e[0;31m"
RESET = "\e[0m"

def blue(s) = "#{BLUE}#{s}#{RESET}"
def err(s) = puts("#{RED}error#{RESET}: #{s}")

def home = ENV["HOME"] || Dir.home
def data_dir = File.join(home, ".local", "share", "jot")
def vaults_file = File.join(data_dir, "vaults")
def config_dir = File.join(home, ".config", "jot")
def config_file = File.join(config_dir, "config")

def ensure_files
  FileUtils.mkdir_p(data_dir)
  FileUtils.mkdir_p(config_dir)
  unless File.exist?(vaults_file)
    File.write(vaults_file, "[vaults]\n")
  end
  unless File.exist?(config_file)
    File.write(config_file, "editor = 'nvim'\nconflict = true\n")
  end
end

def parse_state
  ensure_files
  current = nil
  vaults = {}
  in_vaults = false
  File.readlines(vaults_file, chomp: true).each do |line|
    line = line.strip
    next if line.empty?
    if line == "[vaults]"
      in_vaults = true
      next
    end
    if line =~ /^current\s*=\s*'(.*)'/
      current = Regexp.last_match(1)
    elsif in_vaults && line =~ /^([^=]+?)\s*=\s*'(.*)'/
      vaults[Regexp.last_match(1).strip] = Regexp.last_match(2)
    end
  end
  [current, vaults]
end

def write_state(current, vaults)
  ensure_files
  out = +""
  out << "current = '#{current}'\n\n" if current
  out << "[vaults]\n"
  vaults.each { |k, v| out << "#{k} = '#{v}'\n" }
  File.write(vaults_file, out)
end

def config
  ensure_files
  h = {}
  File.readlines(config_file, chomp: true).each do |line|
    if line =~ /^([^=]+?)\s*=\s*'(.*)'/
      h[Regexp.last_match(1).strip] = Regexp.last_match(2)
    elsif line =~ /^([^=]+?)\s*=\s*(true|false)/
      h[Regexp.last_match(1).strip] = Regexp.last_match(2)
    end
  end
  h["editor"] ||= "nvim"
  h["conflict"] ||= "true"
  h
end

def write_config(h)
  ensure_files
  File.write(config_file, "editor = '#{h["editor"]}'\nconflict = #{h["conflict"]}\n")
end

def vault_root(name, vaults)
  base = vaults[name]
  base && File.join(base, name)
end

def read_vdata(root)
  path = File.join(root, ".jot", "data")
  data = { "folder" => "" }
  return data unless File.exist?(path)
  File.readlines(path, chomp: true).each do |line|
    data["folder"] = Regexp.last_match(1) if line =~ /^folder\s*=\s*'(.*)'/
  end
  data
end

def write_vdata(root, name, location, folder)
  FileUtils.mkdir_p(File.join(root, ".jot"))
  File.write(File.join(root, ".jot", "data"),
             "name = '#{name}'\nlocation = '#{location}'\nfolder = '#{folder}'\nhistory = []\n")
end

def current_context
  current, vaults = parse_state
  unless current && vaults[current]
    err("not inside a vault")
    return nil
  end
  root = vault_root(current, vaults)
  data = read_vdata(root)
  folder = data["folder"] || ""
  [current, vaults, root, folder, File.expand_path(folder, root)]
end

def normalize_dest(root, current_dir, dest)
  base = dest.start_with?("/") ? root : current_dir
  File.expand_path(dest, base)
end

def inside?(root, path)
  r = File.expand_path(root)
  p = File.expand_path(path)
  p == r || p.start_with?(r + File::SEPARATOR)
end

def note_path(dir, name) = File.join(dir, "#{name}.md")
def folder_path(dir, name) = File.join(dir, name)

def item_path(type, dir, name)
  case type
  when "note", "nt" then note_path(dir, name)
  when "folder", "fd" then folder_path(dir, name)
  else nil
  end
end

def item_label(type)
  { "nt" => "note", "note" => "note", "fd" => "folder", "folder" => "folder", "vl" => "vault", "vault" => "vault" }[type] || type
end

def banner
  puts "#{BLUE}________      _____ "
  puts "______(_)_______  /_"
  puts "_____  /_  __ \\  __/"
  puts "____  / / /_/ / /_  "
  puts "___  /  \\____/\\__/  "
  puts "/___/         ᵥ₀.₁.₂  "
  puts "#{RESET}         "
  puts
  puts "usage: jt <command>"
  puts
  puts "#{BLUE}commands:#{RESET}"
  puts
  puts "create items"
  puts "    #{blue("vault")}, #{blue("vl")}       create a vault or list vaults"
  puts "    create items in current folder"
  puts "        #{blue("note")}, #{blue("nt")}        create a note "
  puts "        #{blue("folder")}, #{blue("fd")}      create a folder"
  puts
  puts "interact with items"
  puts "    #{blue("enter")}, #{blue("en")}       enter a vault"
  puts "    #{blue("open")}, #{blue("op")}        open a note from current folder"
  puts "    #{blue("opdir")}, #{blue("od")}       open current folder in file explorer"
  puts "    #{blue("chdir")}, #{blue("cd")}       change folder within current vault"
  puts "    #{blue("list")}, #{blue("ls")}        list items in current folder"
  puts
  puts "perform fs operations on items"
  puts "    #{blue("remove")}, #{blue("rm")}      remove an item "
  puts "    #{blue("rename")}, #{blue("rn")}      rename an item "
  puts "    #{blue("move")}, #{blue("mv")}        move an item to a new location"
  puts "    #{blue("vmove")}, #{blue("vm")}       move an item to a different vault"
  puts
  puts "config"
  puts "    #{blue("config")}, #{blue("cf")}      display, set or open config"
  puts
  puts "get help "
  puts "    use #{blue("help")} or #{blue("-h")} and #{blue("--help")} flags along with a command to get corresponding help"
end

HELP = {
  "vault" => "executable-vault \ncreate a vault or list vaults\n\nUSAGE:\n    jt vault\n    jt vault -l\n    jt vault <vault name> <vault location>\n\nARGS:\n    <vault name>        name for new vault\n    <vault location>    absolute path to location of new vault\n\nOPTIONS:\n    -l            show vaults' location\n    -h, --help    Print help information",
  "note" => "executable-note \ncreate a note\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nARGS:\n    <note name>    name for new note (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information",
  "folder" => "executable-folder \ncreate a folder\n\nUSAGE:\n    jt folder\n    jt folder [folder name]\n\nARGS:\n    <folder name>    name for new folder (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information",
  "enter" => "executable-enter \nenter a vault\n\nUSAGE:\n    executable enter <vault name>\n\nARGS:\n    <vault name>    name of the vault to enter\n\nOPTIONS:\n    -h, --help    Print help information",
  "open" => "executable-open \nopen a note (from the current folder)\n\nUSAGE:\n    executable open <note name>\n\nARGS:\n    <note name>    name of note to be opened\n\nOPTIONS:\n    -h, --help    Print help information",
  "opdir" => "executable-opdir \nopen current folder in file explorer\n\nUSAGE:\n    executable opdir\n\nOPTIONS:\n    -h, --help    Print help information",
  "chdir" => "executable-chdir \nchange folder within current vault\n\nUSAGE:\n    executable chdir <folder path>\n\nARGS:\n    <folder path>    path to folder to switch to (from current folder)\n\nOPTIONS:\n    -h, --help    Print help information",
  "list" => "executable-list \nlist items in current folder\n\nUSAGE:\n    executable list [item type]\n\nARGS:\n    <item type>    \n\nOPTIONS:\n    -h, --help    Print help information",
  "remove" => "executable-remove \nremove an item\n\nUSAGE:\n    executable remove <item type> <name>\n\nARGS:\n    <item type>    remove a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be removed\n\nOPTIONS:\n    -h, --help    Print help information",
  "rename" => "executable-rename \nrename an item\n\nUSAGE:\n    executable rename <item type> <name> <new name>\n\nARGS:\n    <item type>    rename a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be renamed\n    <new name>     new name of item\n\nOPTIONS:\n    -h, --help    Print help information",
  "move" => "executable-move \nmove an item\n\nUSAGE:\n    executable move <item type> <name> <new location>\n\nARGS:\n    <item type>       move a vault (or vl) | note (or nt) | folder (or fd)\n    <name>            name of item to be moved\n    <new location>    path to new location of item (current folder as root in case of note or\n                      folder)\n\nOPTIONS:\n    -h, --help    Print help information",
  "vmove" => "executable-vmove \nmove notes and folders to a different vault\n\nUSAGE:\n    executable vmove <item type> <name> <vault name>\n\nARGS:\n    <item type>     move a note (or nt) | folder (or fd)\n    <name>          name of item to be moved\n    <vault name>    name of vault to move the item to\n\nOPTIONS:\n    -h, --help    Print help information",
  "config" => "executable-config \ndisplay, set or open config\n\nUSAGE:\n    jt config <config type>\n    jt config <config type> [config value]\n\nARGS:\n    <config type>     name of config item to display or set\n    <config value>    pass a value if config needs to be updated\n\nOPTIONS:\n    -h, --help    Print help information"
}

ALIASES = {
  "vl" => "vault", "nt" => "note", "fd" => "folder", "en" => "enter",
  "op" => "open", "od" => "opdir", "cd" => "chdir", "ls" => "list",
  "rm" => "remove", "rn" => "rename", "mv" => "move", "vm" => "vmove", "cf" => "config"
}

def clap_missing(name, usage)
  puts "error: The following required arguments were not provided:"
  puts "    <#{name}>"
  puts
  puts "USAGE:"
  puts "    #{usage}"
  puts
  puts "For more information try --help"
  exit 2
end

def invalid_arg(arg)
  puts "error: Found argument '#{arg}' which wasn't expected, or isn't valid in this context"
  puts
  puts "USAGE:"
  puts "    executable <SUBCOMMAND>"
  puts
  puts "For more information try --help"
  exit 2
end

def tree_entries(dir, filter = nil, prefix = "", lines = [])
  entries = Dir.children(dir).sort_by do |e|
    path = File.join(dir, e)
    hidden = e.start_with?(".") ? 1 : 0
    if filter == "folder"
      [hidden, e.downcase]
    else
      [File.file?(path) ? 0 : 1, hidden, e.downcase]
    end
  end
  entries = entries.reject { |e| e == ".jot" } unless filter == "folder"
  entries.select! { |e| File.directory?(File.join(dir, e)) } if filter == "folder"
  entries.select! { |e| File.file?(File.join(dir, e)) && e.end_with?(".md") } if filter == "note"
  entries.each_with_index do |e, idx|
    path = File.join(dir, e)
    last = idx == entries.length - 1
    conn = last ? "└── " : "├── "
    name = File.file?(path) && e.end_with?(".md") ? blue(File.basename(e, ".md")) : e
    lines << "#{prefix}#{conn}#{name}"
    if File.directory?(path) && filter.nil?
      child_prefix = prefix + (last ? "    " : "│   ")
      tree_entries(path, nil, child_prefix, lines)
    end
  end
  lines
end

def valid_item_type?(type, vault_ok: false)
  %w[note nt folder fd].include?(type) || (vault_ok && %w[vault vl].include?(type))
end

args = ARGV.dup
if args.empty?
  banner
  exit 2
end
if %w[-h --help help].include?(args[0]) && args.length == 1
  banner
  exit 0
end

cmd = ALIASES[args.shift] || ARGV[0]
if args.include?("-h") || args.include?("--help")
  if HELP[cmd]
    puts HELP[cmd]
    exit 0
  end
end
invalid_arg(ARGV[0]) unless HELP.key?(cmd)

case cmd
when "vault"
  current, vaults = parse_state
  if args[0] == "-l"
    vaults.each { |k, v| puts "   #{k} \t #{v}" }
  elsif args.empty?
    vaults.each_key { |k| puts "   #{k}" }
  elsif args.length >= 2
    name, loc = args[0], args[1]
    if vaults.key?(name)
      err("vault #{name} already exists")
    else
      vaults[name] = loc
      root = File.join(loc, name)
      FileUtils.mkdir_p(root)
      write_vdata(root, name, loc, "")
      write_state(current, vaults)
      puts "vault #{blue(name)} created"
    end
  else
    clap_missing("vault location", "jt vault <vault name> <vault location>")
  end
when "enter"
  clap_missing("vault name", "executable enter <vault name>") if args.empty?
  name = args[0]
  _current, vaults = parse_state
  if vaults[name]
    write_state(name, vaults)
    root = vault_root(name, vaults)
    write_vdata(root, name, vaults[name], read_vdata(root)["folder"] || "")
    puts "entered #{blue(name)}"
  else
    err("vault #{name} doesn't exist")
  end
when "note", "folder"
  argname = cmd == "note" ? "note name" : "folder name"
  clap_missing(argname, "jt #{cmd}\n    jt #{cmd} [#{argname}]") if args.empty?
  ctx = current_context or exit 0
  _cur, _vaults, _root, _folder, dir = ctx
  name = args[0]
  path = cmd == "note" ? note_path(dir, name) : folder_path(dir, name)
  if File.exist?(path)
    err("#{cmd} #{name} already exists")
  else
    cmd == "note" ? FileUtils.touch(path) : FileUtils.mkdir_p(path)
    puts "#{cmd} #{blue(name)} created"
  end
when "list"
  filter = args[0]
  if filter && !%w[note nt folder fd].include?(filter)
    puts "error: \"#{filter}\" isn't a valid value for '<item type>'"
    puts "\t[possible values: note, nt, folder, fd]"
    puts
    puts "For more information try --help"
    exit 2
  end
  ctx = current_context or exit 0
  current, _vaults, root, folder, dir = ctx
  title = folder.empty? ? current : "#{current} > #{folder.split(File::SEPARATOR).reject(&:empty?).join(" > ")}"
  puts title
  f = { "nt" => "note", "fd" => "folder" }[filter] || filter
  puts tree_entries(dir, f)
when "chdir"
  clap_missing("folder path", "executable chdir <folder path>") if args.empty?
  ctx = current_context or exit 0
  current, vaults, root, _folder, dir = ctx
  dest = normalize_dest(root, dir, args[0])
  if !inside?(root, dest)
    err("path crosses the bounds of vault")
  elsif !File.directory?(dest)
    err("couldn't find the path specified")
  else
    rel = dest == File.expand_path(root) ? "" : dest.sub(File.expand_path(root) + File::SEPARATOR, "")
    write_vdata(root, current, vaults[current], rel)
    puts "folder changed"
  end
when "open"
  clap_missing("note name", "executable open <note name>") if args.empty?
  ctx = current_context or exit 0
  path = note_path(ctx[4], args[0])
  if File.file?(path)
    system(config["editor"], path, out: $stdout, err: $stderr)
  else
    err("note #{args[0]} not found")
  end
when "opdir"
  ctx = current_context or exit 0
  system("xdg-open", ctx[4], out: File::NULL, err: File::NULL)
when "remove"
  clap_missing("item type", "executable remove <item type> <name>") if args.empty?
  clap_missing("name", "executable remove <item type> <name>") if args.length < 2
  type, name = args[0], args[1]
  unless valid_item_type?(type, vault_ok: true)
    invalid_arg(type)
  end
  current, vaults = parse_state
  label = item_label(type)
  if label == "vault"
    if vaults.delete(name)
      current = nil if current == name
      write_state(current, vaults)
      puts "vault #{blue(name)} removed"
    else
      err("vault #{name} doesn't exist")
    end
  else
    ctx = current_context or exit 0
    path = item_path(type, ctx[4], name)
    if File.exist?(path)
      FileUtils.rm_rf(path)
      puts "#{label} #{blue(name)} removed"
    else
      err("#{label} #{name} not found")
    end
  end
when "rename"
  clap_missing("item type", "executable rename <item type> <name> <new name>") if args.empty?
  clap_missing("name", "executable rename <item type> <name> <new name>") if args.length < 2
  clap_missing("new name", "executable rename <item type> <name> <new name>") if args.length < 3
  type, name, new_name = args[0], args[1], args[2]
  label = item_label(type)
  if label == "vault"
    current, vaults = parse_state
    if vaults[name]
      loc = vaults.delete(name)
      vaults[new_name] = loc
      FileUtils.mv(File.join(loc, name), File.join(loc, new_name)) if File.exist?(File.join(loc, name))
      current = new_name if current == name
      write_state(current, vaults)
      write_vdata(File.join(loc, new_name), new_name, loc, "")
      puts "vault #{blue(name)} renamed to #{blue(new_name)}"
    else
      err("vault #{name} doesn't exist")
    end
  else
    ctx = current_context or exit 0
    path = item_path(type, ctx[4], name)
    dest = item_path(type, ctx[4], new_name)
    if File.exist?(path)
      FileUtils.mv(path, dest)
      puts "#{label} #{blue(name)} renamed to #{blue(new_name)}"
    else
      err("#{label} #{name} not found")
    end
  end
when "move"
  clap_missing("item type", "executable move <item type> <name> <new location>") if args.empty?
  clap_missing("name", "executable move <item type> <name> <new location>") if args.length < 2
  clap_missing("new location", "executable move <item type> <name> <new location>") if args.length < 3
  type, name, newloc = args[0], args[1], args[2]
  label = item_label(type)
  if label == "vault"
    current, vaults = parse_state
    if vaults[name]
      oldroot = File.join(vaults[name], name)
      FileUtils.mkdir_p(newloc)
      FileUtils.mv(oldroot, File.join(newloc, name)) if File.exist?(oldroot)
      vaults[name] = newloc
      write_state(current, vaults)
      write_vdata(File.join(newloc, name), name, newloc, "")
      puts "vault #{blue(name)} moved"
    else
      err("vault #{name} doesn't exist")
    end
  else
    ctx = current_context or exit 0
    root, dir = ctx[2], ctx[4]
    src = item_path(type, dir, name)
    destdir = normalize_dest(root, dir, newloc)
    if !inside?(root, destdir)
      err("path crosses the bounds of vault")
    elsif !File.directory?(destdir)
      err("couldn't find the path specified")
    elsif !File.exist?(src)
      err("#{label} #{name} not found")
    else
      dest = File.join(destdir, File.basename(src))
      if File.exist?(dest)
        err("a #{label} named #{name} already exists in this location")
      else
        FileUtils.mv(src, dest)
        puts "#{label} #{blue(name)} moved"
      end
    end
  end
when "vmove"
  clap_missing("item type", "executable vmove <item type> <name> <vault name>") if args.empty?
  clap_missing("name", "executable vmove <item type> <name> <vault name>") if args.length < 2
  clap_missing("vault name", "executable vmove <item type> <name> <vault name>") if args.length < 3
  type, name, target = args[0], args[1], args[2]
  label = item_label(type)
  ctx = current_context or exit 0
  _current, vaults, _root, _folder, dir = ctx
  unless vaults[target]
    err("vault #{target} doesn't exist")
    exit 0
  end
  src = item_path(type, dir, name)
  dest = File.join(vault_root(target, vaults), File.basename(src))
  if !File.exist?(src)
    err("#{label} #{name} not found")
  elsif File.exist?(dest)
    err("a #{label} named #{name} already exists in this location")
  else
    FileUtils.mv(src, dest)
    puts "#{label} #{blue(name)} moved to vault #{blue(target)}"
  end
when "config"
  if args.empty?
    system(config["editor"], config_file, out: $stdout, err: $stderr)
  else
    key = args[0]
    unless %w[editor conflict].include?(key)
      puts "error: \"#{key}\" isn't a valid value for '<config type>'"
      puts "\t[possible values: editor, conflict]"
      puts
      puts "For more information try --help"
      exit 2
    end
    h = config
    if args.length == 1
      puts "#{key}: #{blue(h[key])}"
    else
      h[key] = args[1]
      write_config(h)
      puts "set #{blue(key)} to #{blue(args[1])}"
    end
  end
end
