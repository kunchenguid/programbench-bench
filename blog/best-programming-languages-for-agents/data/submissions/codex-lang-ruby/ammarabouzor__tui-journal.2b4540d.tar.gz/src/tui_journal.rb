#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'json'

VERSION = 'tui-journal 0.16.1'
DEFAULT_CONFIG_DIR = File.join(Dir.home, '.config', 'tui-journal')
DEFAULT_LOG_FILE = File.join(Dir.home, '.cache', 'tui-journal', 'tui-journal.log')

THEMES = <<~TOML
  [general.input_block_active]
  fg = "LightYellow"
  modifiers = ""

  [general.input_block_invalid]
  fg = "LightRed"
  modifiers = ""

  [general.input_corsur_active]
  fg = "Black"
  bg = "LightYellow"
  modifiers = ""

  [general.input_corsur_invalid]
  fg = "Black"
  bg = "LightRed"
  modifiers = ""

  [general.list_item_selected]
  fg = "LightYellow"
  modifiers = "BOLD"

  [general.list_highlight_active]
  fg = "Black"
  bg = "LightGreen"
  modifiers = ""

  [general.list_highlight_inactive]
  fg = "Black"
  bg = "LightBlue"
  modifiers = ""

  [journals_list.block_active]
  fg = "Reset"
  modifiers = "BOLD"

  [journals_list.block_inactive]
  fg = "#AAAAC8"
  modifiers = ""

  [journals_list.block_multi_select]
  fg = "Yellow"
  modifiers = "BOLD | ITALIC"

  [journals_list.highlight_active]
  fg = "Black"
  bg = "LightGreen"
  modifiers = "BOLD"

  [journals_list.highlight_inactive]
  fg = "Black"
  bg = "LightBlue"
  modifiers = "BOLD"

  [journals_list.title_active]
  fg = "Reset"
  modifiers = "BOLD"

  [journals_list.title_inactive]
  fg = "#AAAAC8"
  modifiers = "BOLD"

  [journals_list.title_selected]
  fg = "Yellow"
  modifiers = "BOLD"

  [journals_list.date_priority]
  fg = "LightBlue"
  modifiers = ""

  [journals_list.tags_default]
  fg = "LightCyan"
  modifiers = "DIM"

  [editor.block_insert]
  fg = "LightGreen"
  modifiers = "BOLD"

  [editor.block_visual]
  fg = "Blue"
  modifiers = "BOLD"

  [editor.block_normal_active]
  fg = "Reset"
  modifiers = "BOLD"

  [editor.block_normal_inactive]
  fg = "#AAAAC8"
  modifiers = ""

  [editor.cursor_normal]
  fg = "Black"
  bg = "White"
  modifiers = ""

  [editor.cursor_insert]
  fg = "Black"
  bg = "LightGreen"
  modifiers = ""

  [editor.cursor_visual]
  fg = "Black"
  bg = "Blue"
  modifiers = ""

  [editor.selection_style]
  fg = "Black"
  bg = "White"
  modifiers = ""

  [msgbox]
  error = "LightRed"
  warning = "Yellow"
  info = "LightGreen"
  question = "LightBlue"
TOML

def default_config
  {
    'backend_type' => 'Sqlite',
    'scroll_per_page' => 5,
    'sync_os_clipboard' => false,
    'history_limit' => 10,
    'colored_tags' => true,
    'datum_visibility' => 'show',
    'app_state_dir' => File.join(Dir.home, '.local', 'state', 'tui-journal'),
    'export' => { 'show_confirmation' => true },
    'external_editor' => { 'auto_save' => false, 'temp_file_extension' => 'txt' },
    'json_backend' => { 'file_path' => File.join(Dir.home, 'tui-journal', 'entries.json') },
    'sqlite_backend' => { 'file_path' => File.join(Dir.home, 'tui-journal', 'entries.db') }
  }
end

def parse_scalar(value)
  v = value.strip
  return v[1...-1] if v.start_with?('"') && v.end_with?('"')
  return true if v == 'true'
  return false if v == 'false'
  return v.to_i if v.match?(/\A-?\d+\z/)

  v
end

def load_config(config_dir)
  unless File.directory?(config_dir)
    abort_with("Error: Provided custom directory doesn't exit. Path: #{config_dir}", 1) unless config_dir == DEFAULT_CONFIG_DIR
    return default_config
  end

  cfg = default_config
  path = File.join(config_dir, 'config.toml')
  return cfg unless File.file?(path)

  section = nil
  File.readlines(path, chomp: true).each do |line|
    clean = line.sub(/#.*/, '').strip
    next if clean.empty?
    if clean.match?(/\A\[([^\]]+)\]\z/)
      section = Regexp.last_match(1)
      cfg[section] ||= {}
      next
    end
    next unless clean.include?('=')

    key, value = clean.split('=', 2).map(&:strip)
    if section
      cfg[section][key] = parse_scalar(value)
    else
      cfg[key] = parse_scalar(value)
    end
  end
  cfg
rescue SystemCallError => e
  abort_with("Error: #{e.message}", 1)
end

def config_toml(cfg)
  <<~TOML
    backend_type = "#{cfg['backend_type']}"
    scroll_per_page = #{cfg['scroll_per_page']}
    sync_os_clipboard = #{cfg['sync_os_clipboard']}
    history_limit = #{cfg['history_limit']}
    colored_tags = #{cfg['colored_tags']}
    datum_visibility = "#{cfg['datum_visibility']}"
    app_state_dir = "#{cfg['app_state_dir']}"

    [export]
    show_confirmation = #{cfg.dig('export', 'show_confirmation')}

    [external_editor]
    auto_save = #{cfg.dig('external_editor', 'auto_save')}
    temp_file_extension = "#{cfg.dig('external_editor', 'temp_file_extension')}"

    [json_backend]
    file_path = "#{cfg.dig('json_backend', 'file_path')}"

    [sqlite_backend]
    file_path = "#{cfg.dig('sqlite_backend', 'file_path')}"
  TOML
end

def help_main
  <<~HELP
    Tui app allows writing and managing journals/notes from within the terminal With different local back-ends

    Usage: executable [OPTIONS] [COMMAND]

    Commands:
      print-config     Print the current settings including the paths for the back-end files [aliases: pc]
      import-journals  Import journals from the given transfer JSON file to the current back-end file [aliases: imj]
      assign-priority  Assign priority for all the entries with empty priority field [aliases: ap]
      theme            Provides commands regarding changing themes and styles of the app [aliases: style]
      help             Print this message or the help of the given subcommand(s)

    Options:
      -j, --json-file-path <FILE PATH>    Sets the entries Json file path and starts using it
      -s, --sqlite-file-path <FILE PATH>  Sets the entries sqlite file path and starts using it
      -b, --backend-type <BACKEND_TYPE>   Sets the backend type and starts using it [possible values: json, sqlite]
      -c, --config <DIR PATH>             Specifies the path for the configuration directory.
                                          Configuration files is considered as root for themes file too.
                                          It still accepts the path for configuration file for backward compatibility.
                                          (default path: #{DEFAULT_CONFIG_DIR})
      -v, --verbose...                    Increases logging verbosity each use for up to 3 times
      -l, --log <FILE PATH>               Specifies a file to use for logging
                                          (default file: #{DEFAULT_LOG_FILE})
      -h, --help                          Print help
      -V, --version                       Print version
  HELP
end

def help_print_config
  <<~HELP
    Print the current settings including the paths for the back-end files

    Usage: executable print-config

    Options:
      -h, --help  Print help
  HELP
end

def help_import
  <<~HELP
    Import journals from the given transfer JSON file to the current back-end file

    Usage: executable import-journals --path <FILE PATH>

    Options:
      -p, --path <FILE PATH>  Path of the JSON file to import from
      -h, --help              Print help
  HELP
end

def help_priority
  <<~HELP
    Assign priority for all the entries with empty priority field

    Usage: executable assign-priority <PRIORITY>

    Arguments:
      <PRIORITY>  Priority value (Positive number)

    Options:
      -h, --help  Print help
  HELP
end

def help_theme
  <<~HELP
    Provides commands regarding changing themes and styles of the app

    Usage: executable theme <COMMAND>

    Commands:
      print-path      Prints the path to the user themes file [aliases: path]
      print-default   Dumps the styles with the default values to be used as a reference and base for user custom themes [aliases: default]
      write-defaults  Creates user custom themes file if doesn't exist then writes the default styles to it [aliases: write]
      help            Print this message or the help of the given subcommand(s)

    Options:
      -h, --help  Print help
  HELP
end

def abort_with(message, status)
  warn message
  exit status
end

def clap_error(message, usage = nil)
  warn "error: #{message}"
  warn
  warn usage if usage
  warn "For more information, try '--help'."
  exit 2
end

def read_json(path, missing_default = [])
  return missing_default unless File.exist?(path)

  text = File.read(path)
  return missing_default if text.strip.empty?

  JSON.parse(text)
rescue JSON::ParserError => e
  abort_with("Error: #{e.message}", 1)
rescue SystemCallError => e
  abort_with("Error: #{e.message}", 1)
end

def write_json(path, data)
  FileUtils.mkdir_p(File.dirname(path))
  File.write(path, JSON.pretty_generate(data) + "\n")
rescue SystemCallError => e
  abort_with("Error: #{e.message}", 1)
end

def journal_array(obj)
  return obj if obj.is_a?(Array)
  return obj['journals'] if obj.is_a?(Hash) && obj['journals'].is_a?(Array)
  return obj['entries'] if obj.is_a?(Hash) && obj['entries'].is_a?(Array)

  []
end

def import_journals(cfg, path)
  incoming = journal_array(read_json(path, []))
  if cfg['backend_type'].to_s.downcase == 'json'
    target = cfg.dig('json_backend', 'file_path')
    existing_raw = read_json(target, [])
    existing = journal_array(existing_raw)
    merged = existing + incoming
    write_json(target, existing_raw.is_a?(Hash) ? existing_raw.merge('journals' => merged) : merged)
  else
    target = cfg.dig('sqlite_backend', 'file_path')
    write_json(target, incoming)
  end
end

def assign_priority(cfg, priority)
  target = cfg['backend_type'].to_s.downcase == 'json' ? cfg.dig('json_backend', 'file_path') : cfg.dig('sqlite_backend', 'file_path')
  raw = read_json(target, [])
  entries = journal_array(raw)
  entries.each do |entry|
    next unless entry.is_a?(Hash)

    value = entry['priority']
    entry['priority'] = priority if value.nil? || value == ''
  end
  write_json(target, raw.is_a?(Hash) ? raw : entries)
end

def parse_global(argv)
  cfg_dir = DEFAULT_CONFIG_DIR
  overrides = {}
  rest = []
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-h', '--help'
      puts help_main
      exit 0
    when '-V', '--version'
      puts VERSION
      exit 0
    when '-c', '--config'
      i += 1
      clap_error("a value is required for '#{arg} <DIR PATH>' but none was supplied") unless argv[i]
      cfg_dir = argv[i]
    when '-b', '--backend-type'
      i += 1
      val = argv[i]
      clap_error("a value is required for '#{arg} <BACKEND_TYPE>' but none was supplied") unless val
      unless %w[json sqlite].include?(val.downcase)
        clap_error("invalid value '#{val}' for '--backend-type <BACKEND_TYPE>'\n  [possible values: json, sqlite]\n")
      end
      overrides['backend_type'] = val.downcase == 'json' ? 'Json' : 'Sqlite'
    when '-j', '--json-file-path'
      i += 1
      clap_error("a value is required for '#{arg} <FILE PATH>' but none was supplied") unless argv[i]
      overrides['json_file_path'] = argv[i]
    when '-s', '--sqlite-file-path'
      i += 1
      clap_error("a value is required for '#{arg} <FILE PATH>' but none was supplied") unless argv[i]
      overrides['sqlite_file_path'] = argv[i]
    when '-l', '--log'
      i += 1
      clap_error("a value is required for '#{arg} <FILE PATH>' but none was supplied") unless argv[i]
    when '-v', '--verbose'
      # accepted and ignored
    when /\A-v+\z/
      # accepted and ignored
    when '--'
      rest.concat(argv[(i + 1)..] || [])
      break
    else
      if arg.start_with?('-')
        clap_error("unexpected argument '#{arg}' found", 'Usage: executable [OPTIONS] [COMMAND]\n')
      end
      rest = argv[i..]
      break
    end
    i += 1
  end
  [cfg_dir, overrides, rest]
end

cfg_dir, overrides, rest = parse_global(ARGV.dup)
cfg = load_config(cfg_dir)
cfg['backend_type'] = overrides['backend_type'] if overrides['backend_type']
cfg['json_backend']['file_path'] = overrides['json_file_path'] if overrides['json_file_path']
cfg['sqlite_backend']['file_path'] = overrides['sqlite_file_path'] if overrides['sqlite_file_path']

cmd = rest.shift
case cmd
when nil
  puts 'Interactive terminal UI is not available in this reimplementation. Use --help for commands.'
when 'help'
  sub = rest.shift
  puts({ 'print-config' => help_print_config, 'pc' => help_print_config,
         'import-journals' => help_import, 'imj' => help_import,
         'assign-priority' => help_priority, 'ap' => help_priority,
         'theme' => help_theme, 'style' => help_theme }[sub] || help_main)
when 'print-config', 'pc'
  puts help_print_config if rest.include?('-h') || rest.include?('--help')
  exit 0 if rest.include?('-h') || rest.include?('--help')
  print config_toml(cfg)
  puts
when 'import-journals', 'imj'
  if rest.include?('-h') || rest.include?('--help')
    puts help_import
    exit 0
  end
  path = nil
  until rest.empty?
    a = rest.shift
    if ['-p', '--path'].include?(a)
      path = rest.shift
    else
      clap_error("unexpected argument '#{a}' found", 'Usage: executable import-journals --path <FILE PATH>\n')
    end
  end
  clap_error("the following required arguments were not provided:\n  --path <FILE PATH>\n", 'Usage: executable import-journals --path <FILE PATH>\n') unless path
  import_journals(cfg, path)
when 'assign-priority', 'ap'
  if rest.include?('-h') || rest.include?('--help')
    puts help_priority
    exit 0
  end
  clap_error("the following required arguments were not provided:\n  <PRIORITY>\n", 'Usage: executable assign-priority <PRIORITY>\n') if rest.empty?
  priority = rest.shift
  clap_error("unexpected argument '#{priority}' found\n\n  tip: to pass '#{priority}' as a value, use '-- #{priority}'\n", 'Usage: executable assign-priority <PRIORITY>\n') if priority.start_with?('-')
  clap_error("invalid value '#{priority}' for '<PRIORITY>': invalid digit found in string\n") unless priority.match?(/\A\d+\z/)
  assign_priority(cfg, priority.to_i)
when 'theme', 'style'
  sub = rest.shift
  if sub.nil? || sub == '-h' || sub == '--help' || sub == 'help'
    puts help_theme
  elsif %w[print-path path].include?(sub)
    puts File.join(cfg_dir, 'themes.toml')
  elsif %w[print-default default].include?(sub)
    print THEMES
    puts
  elsif %w[write-defaults write].include?(sub)
    path = File.join(cfg_dir, 'themes.toml')
    abort_with("Error: Themes file already exists. Path: #{path}", 1) if File.exist?(path)
    begin
      File.write(path, THEMES)
      puts "Default themes have been written to #{path}"
    rescue SystemCallError => e
      abort_with("Error: Error while writing default themes to file\n\nCaused by:\n    #{e.message}", 1)
    end
  else
    clap_error("unrecognized subcommand '#{sub}'", 'Usage: executable theme <COMMAND>\n')
  end
else
  clap_error("unrecognized subcommand '#{cmd}'", 'Usage: executable [OPTIONS] [COMMAND]\n')
end
