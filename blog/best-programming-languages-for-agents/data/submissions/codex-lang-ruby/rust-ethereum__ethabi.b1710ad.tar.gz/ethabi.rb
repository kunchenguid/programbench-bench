#!/usr/bin/env ruby
# frozen_string_literal: true

require 'json'

MASK64 = (1 << 64) - 1

ROT = [
  [0, 36, 3, 41, 18],
  [1, 44, 10, 45, 2],
  [62, 6, 43, 15, 61],
  [28, 55, 25, 21, 56],
  [27, 20, 39, 8, 14]
].freeze

RC = [
  0x0000000000000001, 0x0000000000008082, 0x800000000000808a,
  0x8000000080008000, 0x000000000000808b, 0x0000000080000001,
  0x8000000080008081, 0x8000000000008009, 0x000000000000008a,
  0x0000000000000088, 0x0000000080008009, 0x000000008000000a,
  0x000000008000808b, 0x800000000000008b, 0x8000000000008089,
  0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
  0x000000000000800a, 0x800000008000000a, 0x8000000080008081,
  0x8000000000008080, 0x0000000080000001, 0x8000000080008008
].freeze

def rol(x, n)
  n %= 64
  return x & MASK64 if n.zero?

  (((x << n) | (x >> (64 - n))) & MASK64)
end

def keccak_f(a)
  24.times do |round|
    c = Array.new(5, 0)
    5.times { |x| c[x] = a[x] ^ a[x + 5] ^ a[x + 10] ^ a[x + 15] ^ a[x + 20] }
    d = Array.new(5, 0)
    5.times { |x| d[x] = c[(x + 4) % 5] ^ rol(c[(x + 1) % 5], 1) }
    5.times { |x| 5.times { |y| a[x + 5 * y] = (a[x + 5 * y] ^ d[x]) & MASK64 } }

    b = Array.new(25, 0)
    5.times do |x|
      5.times do |y|
        b[y + 5 * ((2 * x + 3 * y) % 5)] = rol(a[x + 5 * y], ROT[x][y])
      end
    end

    5.times do |y|
      5.times do |x|
        a[x + 5 * y] = (b[x + 5 * y] ^ ((~b[((x + 1) % 5) + 5 * y]) & b[((x + 2) % 5) + 5 * y])) & MASK64
      end
    end
    a[0] = (a[0] ^ RC[round]) & MASK64
  end
end

def keccak256(data)
  rate = 136
  bytes = data.bytes
  bytes << 0x01
  bytes << 0 while (bytes.length % rate) != rate - 1
  bytes << 0x80
  st = Array.new(25, 0)
  bytes.each_slice(rate) do |block|
    (rate / 8).times do |i|
      lane = 0
      8.times { |j| lane |= (block[i * 8 + j] || 0) << (8 * j) }
      st[i] ^= lane
    end
    keccak_f(st)
  end
  out = +''
  while out.bytesize < 32
    (rate / 8).times { |i| out << [st[i]].pack('Q<') }
    keccak_f(st) if out.bytesize < 32
  end
  out.byteslice(0, 32).unpack1('H*')
end

class AbiType
  attr_reader :kind, :bits, :size, :sub

  def initialize(kind, bits: nil, size: nil, sub: nil)
    @kind = kind
    @bits = bits
    @size = size
    @sub = sub
  end

  def self.parse(str)
    s = str.strip
    if s.end_with?(']')
      m = s.match(/\A(.+)\[([0-9]*)\]\z/) or raise "Invalid type"
      len = m[2].empty? ? nil : m[2].to_i
      return new(:array, size: len, sub: parse(m[1]))
    end
    case s
    when 'bool' then new(:bool)
    when 'address' then new(:address)
    when 'string' then new(:string)
    when 'bytes' then new(:bytes)
    when /\Abytes([1-9]|[12][0-9]|3[0-2])\z/ then new(:fixed_bytes, size: Regexp.last_match(1).to_i)
    when /\Auint([0-9]*)\z/ then new(:uint, bits: (Regexp.last_match(1).empty? ? 256 : Regexp.last_match(1).to_i))
    when /\Aint([0-9]*)\z/ then new(:int, bits: (Regexp.last_match(1).empty? ? 256 : Regexp.last_match(1).to_i))
    else
      raise "Invalid type"
    end
  end

  def canonical
    case kind
    when :uint then "uint#{bits}"
    when :int then "int#{bits}"
    when :fixed_bytes then "bytes#{size}"
    when :array then "#{sub.canonical}[#{size || ''}]"
    else kind.to_s
    end
  end

  def dynamic?
    return true if %i[string bytes].include?(kind)
    return size.nil? || sub.dynamic? if kind == :array

    false
  end
end

def clean_hex(s)
  x = s.to_s.strip
  x = x[2..] if x.start_with?('0x') || x.start_with?('0X')
  raise 'Hex parsing error: Odd number of digits' if x.length.odd?
  raise 'Invalid data' unless x.match?(/\A[0-9a-fA-F]*\z/)

  x.downcase
end

def word(n)
  raise 'Invalid data' if n.negative? || n >= (1 << 256)
  n.to_s(16).rjust(64, '0')
end

def twos_word(n)
  n %= (1 << 256)
  word(n)
end

def pad_right(hex)
  hex + ('0' * ((64 - hex.length % 64) % 64))
end

def split_array_value(s)
  v = s.strip
  raise 'Invalid data' unless v.start_with?('[') && v.end_with?(']')
  inner = v[1...-1].strip
  return [] if inner.empty?

  out = []
  cur = +''
  depth = 0
  inner.each_char do |ch|
    if ch == '['
      depth += 1
      cur << ch
    elsif ch == ']'
      depth -= 1
      cur << ch
    elsif ch == ',' && depth.zero?
      out << cur.strip
      cur = +''
    else
      cur << ch
    end
  end
  out << cur.strip
  out
end

def encode_single(type, val, lenient)
  case type.kind
  when :bool
    v = val.to_s
    b = %w[1 true].include?(v) ? 1 : (%w[0 false].include?(v) ? 0 : (raise 'Invalid data'))
    word(b)
  when :uint
    n = lenient ? Integer(val, 10) : Integer(clean_hex(val), 16)
    max = 1 << type.bits
    raise 'Invalid data' if n.negative? || n >= max
    word(n)
  when :int
    n = lenient ? Integer(val, 10) : Integer(clean_hex(val), 16)
    min = -(1 << (type.bits - 1))
    max = (1 << (type.bits - 1)) - 1
    raise 'Invalid data' if n < min || n > max
    twos_word(n)
  when :address
    h = clean_hex(val)
    raise 'Invalid data' unless h.length == 40
    word(h.to_i(16))
  when :fixed_bytes
    h = clean_hex(val)
    raise 'Invalid data' unless h.length == type.size * 2
    h.ljust(64, '0')
  when :bytes
    h = clean_hex(val)
    word(h.length / 2) + pad_right(h)
  when :string
    h = val.to_s.b.unpack1('H*')
    word(h.length / 2) + pad_right(h)
  when :array
    vals = split_array_value(val)
    raise 'Invalid data' if type.size && vals.length != type.size
    body = encode_sequence(Array.new(vals.length, type.sub), vals, lenient)
    type.size.nil? ? word(vals.length) + body : body
  else
    raise 'Invalid type'
  end
rescue ArgumentError
  raise 'Invalid data'
end

def encode_sequence(types, values, lenient)
  raise 'Invalid data' unless types.length == values.length
  heads = []
  tails = []
  head_size = types.length * 32
  types.zip(values).each do |t, v|
    enc = encode_single(t, v, lenient)
    if t.dynamic?
      heads << word(head_size + tails.join.length / 2)
      tails << enc
    else
      heads << enc
    end
  end
  heads.join + tails.join
end

def bytes_from_hex(data)
  [clean_hex(data)].pack('H*')
end

def read_word(hex, off)
  part = hex[off * 2, 64]
  raise 'Invalid data' unless part && part.length == 64
  part.to_i(16)
end

def decode_dynamic_payload(type, hex, ptr)
  case type.kind
  when :bytes
    len = read_word(hex, ptr)
    hex[(ptr + 32) * 2, len * 2] || ''
  when :string
    len = read_word(hex, ptr)
    [hex[(ptr + 32) * 2, len * 2] || ''].pack('H*').force_encoding('UTF-8')
  when :array
    len = type.size || read_word(hex, ptr)
    base = type.size.nil? ? ptr + 32 : ptr
    vals = []
    len.times do |i|
      slot = base + i * 32
      vals << if type.sub.dynamic?
                rel = read_word(hex, slot)
                decode_dynamic_payload(type.sub, hex, base + rel)
              else
                decode_at(type.sub, hex, slot)
              end
    end
    "[#{vals.join(',')}]"
  else
    raise 'Invalid type'
  end
end

def decode_at(type, hex, off)
  case type.kind
  when :bool
    read_word(hex, off) != 0 ? 'true' : 'false'
  when :uint
    read_word(hex, off).to_s(16)
  when :int
    n = read_word(hex, off)
    n -= (1 << 256) if n >= (1 << 255)
    n.negative? ? "-#{(-n).to_s(16)}" : n.to_s(16)
  when :address
    read_word(hex, off).to_s(16).rjust(40, '0')[-40, 40]
  when :fixed_bytes
    hex[off * 2, type.size * 2]
  when :bytes
    ptr = read_word(hex, off)
    decode_dynamic_payload(type, hex, ptr)
  when :string
    ptr = read_word(hex, off)
    decode_dynamic_payload(type, hex, ptr)
  when :array
    ptr = type.size.nil? ? read_word(hex, off) : off
    decode_dynamic_payload(type, hex, ptr)
  else
    raise 'Invalid type'
  end
end

def decode_sequence(types, data)
  hex = clean_hex(data)
  types.each_with_index.map { |t, i| "#{t.canonical} #{decode_at(t, hex, i * 32)}" }
end

def load_abi(path)
  JSON.parse(File.read(path))
end

def sig_inputs(sig)
  m = sig.match(/\A([A-Za-z_][A-Za-z0-9_]*)\(([^)]*)\)(?::\(([^)]*)\))?\z/) or return nil
  [m[1], (m[2].empty? ? [] : m[2].split(',')), (m[3] && !m[3].empty? ? m[3].split(',') : nil)]
end

def canonical_function(f)
  "#{f['name']}(#{(f['inputs'] || []).map { |i| AbiType.parse(i['type']).canonical }.join(',')})"
end

def find_item(abi, name_or_sig, kind)
  items = abi.select { |x| x['type'] == kind }
  parsed = sig_inputs(name_or_sig)
  if parsed
    name, inputs, _outs = parsed
    found = items.find { |f| f['name'] == name && (f['inputs'] || []).map { |i| AbiType.parse(i['type']).canonical } == inputs.map { |x| AbiType.parse(x).canonical } }
  else
    matches = items.select { |f| f['name'] == name_or_sig }
    raise "More than one #{kind} found for name `#{name_or_sig}`, try providing the full signature" if matches.length > 1
    found = matches.first
  end
  raise "#{kind.capitalize} not found" unless found
  found
end

def parse_opts(args, topic_l = false)
  opts = { params: [], types: [], topics: [], lenient: false }
  rest = []
  i = 0
  while i < args.length
    case args[i]
    when '-l', '--lenient'
      if topic_l && args[i + 1]
        opts[:topics] << args[i + 1]
        i += 2
      else
        opts[:lenient] = true
        i += 1
      end
    when '-p'
      opts[:params] << args[i + 1]
      i += 2
    when '-v'
      opts[:types] << args[i + 1]
      opts[:params] << args[i + 2]
      i += 3
    when '-t'
      opts[:types] << args[i + 1]
      i += 2
    else
      rest << args[i]
      i += 1
    end
  end
  [opts, rest]
end

def help
  puts "ethabi-cli 18.0.0\nEthereum ABI coder\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nSUBCOMMANDS:\n    decode    Decode ABI call result\n    encode    Encode ABI call\n    help      Prints this message or the help of the given subcommand(s)"
end

begin
  if ARGV.empty? || %w[-h --help help].include?(ARGV[0])
    help
    exit 0
  end
  if %w[-V --version].include?(ARGV[0])
    puts 'ethabi-cli 18.0.0'
    exit 0
  end
  mode = ARGV.shift
  sub = ARGV.shift
  opts, rest = parse_opts(ARGV, mode == 'decode' && sub == 'log')
  case [mode, sub]
  when ['encode', 'params']
    types = opts[:types].map { |t| AbiType.parse(t) }
    puts encode_sequence(types, opts[:params], opts[:lenient])
  when ['decode', 'params']
    data = rest.pop
    types = opts[:types].map { |t| AbiType.parse(t) }
    puts decode_sequence(types, data)
  when ['encode', 'function']
    abi_path, fname = rest
    fun = find_item(load_abi(abi_path), fname, 'function')
    types = (fun['inputs'] || []).map { |i| AbiType.parse(i['type']) }
    sig = canonical_function(fun)
    puts keccak256(sig)[0, 8] + encode_sequence(types, opts[:params], opts[:lenient])
  when ['decode', 'function']
    abi_path, fname, data = rest
    fun = find_item(load_abi(abi_path), fname, 'function')
    types = (fun['outputs'] || []).map { |i| AbiType.parse(i['type']) }
    puts decode_sequence(types, data)
  when ['decode', 'log']
    abi_path, ename, data = rest
    ev = find_item(load_abi(abi_path), ename, 'event')
    indexed = (ev['inputs'] || []).select { |i| i['indexed'] }
    plain = (ev['inputs'] || []).reject { |i| i['indexed'] }
    out = []
    indexed.zip(opts[:topics]).each do |inp, topic|
      t = AbiType.parse(inp['type'])
      out << "#{t.canonical} #{decode_at(t, clean_hex(topic), 0)}"
    end
    out.concat(decode_sequence(plain.map { |i| AbiType.parse(i['type']) }, data))
    puts out
  else
    help
  end
rescue StandardError => e
  warn "Error: #{e.message}"
  exit 1
end
