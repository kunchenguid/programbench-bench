#!/usr/bin/env ruby
# frozen_string_literal: true

require 'shellwords'

VERSION = 'hyperfine 1.20.0'

HELP = <<~TEXT
  A command-line benchmarking tool.

  Usage: executable [OPTIONS] <command>...

  Arguments:
    <command>...
            The command to benchmark. This can be the name of an executable, a
            command line like "grep -i todo" or a shell command like "sleep 0.5 &&
            echo test". The latter is only available if the shell is not
            explicitly disabled via '--shell=none'. If multiple commands are
            given, hyperfine will show a comparison of the respective runtimes.

  Options:
    -w, --warmup <NUM>
            Perform NUM warmup runs before the actual benchmark. This can be used
            to fill (disk) caches for I/O-heavy programs.
    -m, --min-runs <NUM>
            Perform at least NUM runs for each command (default: 10).
    -M, --max-runs <NUM>
            Perform at most NUM runs for each command. By default, there is no
            limit.
    -r, --runs <NUM>
            Perform exactly NUM runs for each command. If this option is not
            specified, hyperfine automatically determines the number of runs.
    -s, --setup <CMD>
            Execute CMD before each set of timing runs.
        --reference <CMD>
            The reference command for the relative comparison of results.
        --reference-name <CMD>
            Give a meaningful name to the reference command.
    -p, --prepare <CMD>
            Execute CMD before each timing run.
    -C, --conclude <CMD>
            Execute CMD after each timing run.
    -c, --cleanup <CMD>
            Execute CMD after the completion of all benchmarking runs.
    -P, --parameter-scan <VAR> <MIN> <MAX>
            Perform benchmark runs for each value in the range MIN..MAX.
    -D, --parameter-step-size <DELTA>
            This argument requires --parameter-scan to be specified as well.
    -L, --parameter-list <VAR> <VALUES>
            Perform benchmark runs for each value in the comma-separated list VALUES.
    -S, --shell <SHELL>
            Set the shell to use for executing benchmarked commands.
    -N
            An alias for '--shell=none'.
    -i, --ignore-failure[=<MODE>]
            Ignore failures of the benchmarked programs.
        --style <TYPE>
            Set output style type (default: auto).
        --sort <METHOD>
            Specify the sort order of the speed comparison summary and tables.
    -u, --time-unit <UNIT>
            Set the time unit to be used. Possible values: microsecond,
            millisecond, second.
        --export-asciidoc <FILE>
            Export the timing summary statistics as an AsciiDoc table.
        --export-csv <FILE>
            Export the timing summary statistics as CSV.
        --export-json <FILE>
            Export the timing summary statistics and timings as JSON.
        --export-markdown <FILE>
            Export the timing summary statistics as a Markdown table.
        --export-orgmode <FILE>
            Export the timing summary statistics as an Emacs org-mode table.
        --show-output
            Print the stdout and stderr of the benchmark instead of suppressing it.
        --output <WHERE>
            Control where the output of the benchmark is redirected.
        --input <WHERE>
            Control where the input of the benchmark comes from.
    -n, --command-name <NAME>
            Give a meaningful name to a command.
    -h, --help
            Print help
    -V, --version
            Print version
TEXT

class CliError < StandardError; end

def take_arg(args, i, opt)
  raise CliError, "error: a value is required for '#{opt}' but none was supplied" if i + 1 >= args.length

  [args[i + 1], i + 1]
end

def parse_int(value, name)
  Integer(value)
rescue ArgumentError
  raise CliError, "error: invalid value '#{value}' for '#{name}': invalid digit found in string"
end

def parse_float(value, name)
  Float(value)
rescue ArgumentError
  raise CliError, "error: invalid value '#{value}' for '#{name}'"
end

def split_long(arg)
  return [arg, nil] unless arg.start_with?('--') && arg.include?('=')

  arg.split('=', 2)
end

def parse_args(argv)
  opts = {
    warmup: 0, min_runs: 10, max_runs: nil, runs: nil, setup: nil, prepare: [],
    conclude: [], cleanup: nil, param_scan: nil, param_step: nil, param_lists: [],
    shell: 'default', ignore_failure: nil, style: 'auto', sort: 'auto',
    time_unit: nil, exports: {}, show_output: false, outputs: [], input: 'null',
    names: [], reference: nil, reference_name: nil
  }
  commands = []
  i = 0
  while i < argv.length
    raw = argv[i]
    if raw == '--'
      commands.concat(argv[(i + 1)..] || [])
      break
    end
    opt, inline = split_long(raw)
    case opt
    when '-h', '--help'
      puts HELP
      exit 0
    when '-V', '--version'
      puts VERSION
      exit 0
    when '-w', '--warmup'
      v, i = inline ? [inline, i] : take_arg(argv, i, opt)
      opts[:warmup] = parse_int(v, opt)
    when '-m', '--min-runs'
      v, i = inline ? [inline, i] : take_arg(argv, i, opt)
      opts[:min_runs] = parse_int(v, opt)
    when '-M', '--max-runs'
      v, i = inline ? [inline, i] : take_arg(argv, i, opt)
      opts[:max_runs] = parse_int(v, opt)
    when '-r', '--runs'
      v, i = inline ? [inline, i] : take_arg(argv, i, opt)
      opts[:runs] = parse_int(v, opt)
    when '-s', '--setup'
      opts[:setup], i = inline ? [inline, i] : take_arg(argv, i, opt)
    when '--reference'
      opts[:reference], i = inline ? [inline, i] : take_arg(argv, i, opt)
    when '--reference-name'
      opts[:reference_name], i = inline ? [inline, i] : take_arg(argv, i, opt)
    when '-p', '--prepare'
      v, i = inline ? [inline, i] : take_arg(argv, i, opt)
      opts[:prepare] << v
    when '-C', '--conclude'
      v, i = inline ? [inline, i] : take_arg(argv, i, opt)
      opts[:conclude] << v
    when '-c', '--cleanup'
      opts[:cleanup], i = inline ? [inline, i] : take_arg(argv, i, opt)
    when '-P', '--parameter-scan'
      raise CliError, "error: a value is required for '#{opt}' but none was supplied" if i + 3 >= argv.length
      opts[:param_scan] = [argv[i + 1], argv[i + 2], argv[i + 3]]
      i += 3
    when '-D', '--parameter-step-size'
      v, i = inline ? [inline, i] : take_arg(argv, i, opt)
      opts[:param_step] = v
    when '-L', '--parameter-list'
      raise CliError, "error: a value is required for '#{opt}' but none was supplied" if i + 2 >= argv.length
      opts[:param_lists] << [argv[i + 1], argv[i + 2].split(',', -1)]
      i += 2
    when '-S', '--shell'
      opts[:shell], i = inline ? [inline, i] : take_arg(argv, i, opt)
    when '-N'
      opts[:shell] = 'none'
    when '-i', '--ignore-failure'
      opts[:ignore_failure] = inline || 'all-non-zero'
    when '--style'
      opts[:style], i = inline ? [inline, i] : take_arg(argv, i, opt)
    when '--sort'
      opts[:sort], i = inline ? [inline, i] : take_arg(argv, i, opt)
    when '-u', '--time-unit'
      opts[:time_unit], i = inline ? [inline, i] : take_arg(argv, i, opt)
    when '--export-asciidoc', '--export-csv', '--export-json', '--export-markdown', '--export-orgmode'
      v, i = inline ? [inline, i] : take_arg(argv, i, opt)
      opts[:exports][opt.sub('--export-', '').to_sym] = v
    when '--show-output'
      opts[:show_output] = true
    when '--output'
      v, i = inline ? [inline, i] : take_arg(argv, i, opt)
      opts[:outputs] << v
    when '--input'
      opts[:input], i = inline ? [inline, i] : take_arg(argv, i, opt)
    when '-n', '--command-name'
      v, i = inline ? [inline, i] : take_arg(argv, i, opt)
      opts[:names] << v
    else
      if raw.start_with?('-') && commands.empty?
        raise CliError, "error: unexpected argument '#{raw}' found\n\n  tip: to pass '#{raw}' as a value, use '-- #{raw}'\n\nUsage: executable [OPTIONS] <command>...\n\nFor more information, try '--help'."
      end
      commands << raw
    end
    i += 1
  end
  [opts, commands]
end

def validate!(opts, commands)
  if commands.empty?
    raise CliError, "error: the following required arguments were not provided:\n  <command>...\n\nUsage: executable <command>...\n\nFor more information, try '--help'."
  end
  raise CliError, "error: the argument '--style <TYPE>' cannot be used with '--show-output'\n\nUsage: executable --style <TYPE> <command>...\n\nFor more information, try '--help'." if opts[:show_output] && opts[:style] != 'auto'

  %w[auto basic full nocolor color none].include?(opts[:style]) || raise(CliError, "error: invalid value '#{opts[:style]}' for '--style <TYPE>'")
  %w[auto command mean-time].include?(opts[:sort]) || raise(CliError, "error: invalid value '#{opts[:sort]}' for '--sort <METHOD>'")
  if opts[:time_unit] && !%w[microsecond millisecond second].include?(opts[:time_unit])
    raise CliError, "error: invalid value '#{opts[:time_unit]}' for '--time-unit <UNIT>'"
  end
  raise CliError, "error: the following required arguments were not provided:\n  --parameter-scan <VAR> <MIN> <MAX>" if opts[:param_step] && !opts[:param_scan]
  raise CliError, 'error: number of command names has to match the number of commands' if !opts[:names].empty? && opts[:names].length != commands.length
end

def values_for_scan(var, min_s, max_s, step_s)
  min = parse_float(min_s, '--parameter-scan')
  max = parse_float(max_s, '--parameter-scan')
  step = step_s ? parse_float(step_s, '--parameter-step-size') : 1.0
  raise CliError, 'error: The step size can not be zero' if step.zero?

  vals = []
  x = min
  if step.positive?
    while x <= max + 1e-12
      vals << format_number(x, min_s, max_s, step_s)
      x += step
    end
  else
    while x >= max - 1e-12
      vals << format_number(x, min_s, max_s, step_s)
      x += step
    end
  end
  [var, vals]
end

def format_number(x, *samples)
  decimal = samples.compact.any? { |s| s.include?('.') || s.downcase.include?('e') }
  decimal ? ('%.12g' % x) : x.to_i.to_s
end

def cartesian(params)
  return [{}] if params.empty?

  first, *rest = params
  var, vals = first
  cartesian(rest).flat_map { |h| vals.map { |v| h.merge(var => v) } }
end

def expand_text(text, mapping)
  return nil if text.nil?

  mapping.reduce(text) { |s, (k, v)| s.gsub("{#{k}}", v) }
end

def expand_commands(commands, opts)
  params = []
  params << values_for_scan(*opts[:param_scan], opts[:param_step]) if opts[:param_scan]
  opts[:param_lists].each { |var, vals| params << [var, vals] }
  combos = cartesian(params)
  expanded = []
  combos.each do |mapping|
    commands.each_with_index do |cmd, idx|
      expanded << {
        command: expand_text(cmd, mapping),
        display: opts[:names][idx] ? expand_text(opts[:names][idx], mapping) : expand_text(cmd, mapping),
        setup: expand_text(opts[:setup], mapping),
        cleanup: expand_text(opts[:cleanup], mapping),
        prepare: opts[:prepare].map { |p| expand_text(p, mapping) },
        conclude: opts[:conclude].map { |c| expand_text(c, mapping) },
        output: opts[:outputs][idx] || opts[:outputs][0],
        input: opts[:input],
        command_index: idx,
        command_count: commands.length,
        mapping: mapping
      }
    end
  end
  expanded
end

def command_argv(cmd, shell_mode)
  if shell_mode == 'none'
    Shellwords.split(cmd)
  elsif shell_mode == 'default'
    ['/bin/sh', '-c', cmd]
  else
    Shellwords.split(shell_mode) + ['-c', cmd]
  end
end

def allowed_failure?(code, mode)
  return false unless mode
  return code != 0 if mode == 'all-non-zero' || mode == ''

  mode.split(',').map(&:to_i).include?(code)
end

def run_command(cmd, opts, bench, iteration: nil, measured: false)
  env = {}
  env['HYPERFINE_ITERATION'] = iteration.to_s if iteration
  argv = command_argv(cmd, opts[:shell])
  out_mode = bench && bench[:output]
  out_mode = 'inherit' if opts[:show_output]
  input = bench ? bench[:input] : 'null'

  start = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  status = nil
  inf = File.open(input == 'null' ? File::NULL : input, 'r')
  if out_mode == 'inherit'
    status = system(env, *argv, in: inf)
    code = status ? 0 : ($?&.exitstatus || 1)
  elsif out_mode && !%w[null pipe].include?(out_mode)
    File.open(out_mode, 'w') { |outf| status = system(env, *argv, in: inf, out: outf, err: outf) }
    code = status ? 0 : ($?&.exitstatus || 1)
  elsif out_mode == 'pipe'
    reader, writer = IO.pipe
    pid = Process.spawn(env, *argv, in: inf, out: writer, err: writer)
    writer.close
    reader.read
    reader.close
    _, st = Process.wait2(pid)
    code = st.exitstatus || 1
  else
    status = system(env, *argv, in: inf, out: File::NULL, err: File::NULL)
    code = status ? 0 : ($?&.exitstatus || 1)
  end
  elapsed = Process.clock_gettime(Process::CLOCK_MONOTONIC) - start
  [elapsed, code]
rescue Errno::ENOENT
  warn "Error: No such file or directory (os error 2)"
  exit 1 if measured
  [0.0, 127]
ensure
  inf&.close
end

def mean(xs)
  xs.sum / xs.length
end

def median(xs)
  s = xs.sort
  n = s.length
  n.odd? ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2.0
end

def stddev(xs)
  return 0.0 if xs.length < 2

  m = mean(xs)
  Math.sqrt(xs.map { |x| (x - m)**2 }.sum / (xs.length - 1))
end

def unit_for(results, requested)
  return requested if requested

  m = results.map { |r| r[:mean] }.min || 0
  return 'microsecond' if m < 0.001
  return 'millisecond' if m < 1.0

  'second'
end

def unit_info(unit)
  case unit
  when 'microsecond' then [1_000_000.0, 'us']
  when 'millisecond' then [1_000.0, 'ms']
  else [1.0, 's']
  end
end

def fmt_time(x, factor)
  v = x * factor
  if v >= 100
    format('%.0f', v)
  elsif v >= 10
    format('%.1f', v)
  else
    format('%.2f', v)
  end
end

def rel_stats(results, reference = nil)
  ref = if reference
          results.find { |r| r[:command] == reference || r[:display] == reference } || results.min_by { |r| r[:mean] }
        else
          results.min_by { |r| r[:mean] }
        end
  results.each do |r|
    r[:relative] = r[:mean] / ref[:mean]
    r[:relative_stddev] = r[:relative] * Math.sqrt((r[:stddev] / [r[:mean], 1e-12].max)**2 + (ref[:stddev] / [ref[:mean], 1e-12].max)**2)
  end
end

def markdown_table(results, unit, sort)
  factor, label = unit_info(unit)
  rows = sort == 'mean-time' ? results.sort_by { |r| r[:mean] } : results
  out = +"| Command | Mean [#{label}] | Min [#{label}] | Max [#{label}] | Relative |\n"
  out << "|:---|---:|---:|---:|---:|\n"
  rows.each do |r|
    rel = r[:relative_stddev].zero? ? format('%.2f', r[:relative]) : format('%.2f ± %.2f', r[:relative], r[:relative_stddev])
    out << "| `#{r[:display]}` | #{fmt_time(r[:mean], factor)} ± #{fmt_time(r[:stddev], factor)} | #{fmt_time(r[:min], factor)} | #{fmt_time(r[:max], factor)} | #{rel} |\n"
  end
  out
end

def asciidoc_table(results, unit, sort)
  factor, label = unit_info(unit)
  rows = sort == 'mean-time' ? results.sort_by { |r| r[:mean] } : results
  out = +"[cols=\"<,>,>,>,>\"]\n|===\n| Command \n| Mean [#{label}] \n| Min [#{label}] \n| Max [#{label}] \n| Relative \n\n"
  rows.each do |r|
    rel = r[:relative_stddev].zero? ? format('%.2f', r[:relative]) : format('%.2f ± %.2f', r[:relative], r[:relative_stddev])
    out << "| `#{r[:display]}` \n| #{fmt_time(r[:mean], factor)} ± #{fmt_time(r[:stddev], factor)} \n| #{fmt_time(r[:min], factor)} \n| #{fmt_time(r[:max], factor)} \n| #{rel} \n"
  end
  out << "|===\n"
end

def org_table(results, unit, sort)
  factor, label = unit_info(unit)
  rows = sort == 'mean-time' ? results.sort_by { |r| r[:mean] } : results
  out = +"| Command  |  Mean [#{label}] |  Min [#{label}] |  Max [#{label}] |  Relative |\n|--+--+--+--+--|\n"
  rows.each do |r|
    rel = r[:relative_stddev].zero? ? format('%.2f', r[:relative]) : format('%.2f ± %.2f', r[:relative], r[:relative_stddev])
    out << "| =#{r[:display]}=  |  #{fmt_time(r[:mean], factor)} ± #{fmt_time(r[:stddev], factor)} |  #{fmt_time(r[:min], factor)} |  #{fmt_time(r[:max], factor)} |  #{rel} |\n"
  end
  out
end

def write_exports(results, opts)
  rel_stats(results, opts[:reference])
  unit = unit_for(results, opts[:time_unit])
  opts[:exports].each do |kind, path|
    case kind
    when :json
      payload = { 'results' => results.map { |r|
        {
          'command' => r[:display], 'mean' => r[:mean], 'stddev' => r[:stddev], 'median' => r[:median],
          'user' => r[:user], 'system' => r[:system], 'min' => r[:min], 'max' => r[:max],
          'times' => r[:times], 'memory_usage_byte' => r[:memory], 'exit_codes' => r[:exit_codes]
        }
      } }
      File.write(path, json_pretty(payload) + "\n")
    when :csv
      lines = ["command,mean,stddev,median,user,system,min,max"]
      results.each do |r|
        fields = [r[:display], r[:mean], r[:stddev], r[:median], r[:user], r[:system], r[:min], r[:max]]
        lines << fields.map { |v| csv_escape(v.to_s) }.join(',')
      end
      File.write(path, lines.join("\n") + "\n")
    when :markdown
      File.write(path, markdown_table(results, unit, opts[:sort]))
    when :asciidoc
      File.write(path, asciidoc_table(results, unit, opts[:sort]))
    when :orgmode
      File.write(path, org_table(results, unit, opts[:sort]))
    end
  end
end

def csv_escape(s)
  return s unless s.match?(/[",\n\r]/)

  '"' + s.gsub('"', '""') + '"'
end

def json_pretty(value, indent = 0)
  sp = ' ' * indent
  case value
  when Hash
    return '{}' if value.empty?
    inner = value.map { |k, v| "#{' ' * (indent + 2)}#{json_string(k.to_s)}: #{json_pretty(v, indent + 2)}" }
    "{\n#{inner.join(",\n")}\n#{sp}}"
  when Array
    return '[]' if value.empty?
    if value.all? { |v| v.is_a?(Numeric) || v == true || v == false || v.nil? }
      "[\n#{value.map { |v| "#{' ' * (indent + 2)}#{json_pretty(v, indent + 2)}" }.join(",\n")}\n#{sp}]"
    else
      "[\n#{value.map { |v| "#{' ' * (indent + 2)}#{json_pretty(v, indent + 2)}" }.join(",\n")}\n#{sp}]"
    end
  when String
    json_string(value)
  when Numeric
    value.finite? ? value.to_s : 'null'
  when true then 'true'
  when false then 'false'
  when nil then 'null'
  else
    json_string(value.to_s)
  end
end

def json_string(s)
  '"' + s.gsub(/["\\\b\f\n\r\t]/) { |c|
    case c
    when '"' then '\"'
    when '\\' then '\\\\'
    when "\b" then '\\b'
    when "\f" then '\\f'
    when "\n" then '\\n'
    when "\r" then '\\r'
    when "\t" then '\\t'
    end
  } + '"'
end

begin
  opts, raw_commands = parse_args(ARGV)
  validate!(opts, raw_commands)
  benches = expand_commands(raw_commands, opts)
  run_count = opts[:runs] || opts[:min_runs]
  run_count = [run_count, opts[:max_runs]].min if opts[:max_runs]
  run_count = 1 if run_count < 1

  visible = opts[:style] != 'none'
  results = []
  benches.each_with_index do |bench, idx|
    puts "Benchmark #{idx + 1}: #{bench[:display]}" if visible
    run_command(bench[:setup], opts, bench) if bench[:setup]
    opts[:warmup].times do
      elapsed, code = run_command(bench[:command], opts, bench)
      if code != 0 && !allowed_failure?(code, opts[:ignore_failure])
        warn "Error: Command terminated with non-zero exit code #{code} during warmup."
        exit 1
      end
    end

    times = []
    codes = []
    run_count.times do |n|
      prep = bench[:prepare]
      prep = [prep[bench[:command_index]]] if prep.length == bench[:command_count]
      prep = [prep[0]] if prep.length > 1 && prep.length != bench[:command_count]
      prep.compact.each { |p| run_command(p, opts, bench) }
      elapsed, code = run_command(bench[:command], opts, bench, iteration: n + 1, measured: true)
      concl = bench[:conclude]
      concl = [concl[bench[:command_index]]] if concl.length == bench[:command_count]
      concl = [concl[0]] if concl.length > 1 && concl.length != bench[:command_count]
      concl.compact.each { |c| run_command(c, opts, bench) }
      codes << code
      if code != 0 && !allowed_failure?(code, opts[:ignore_failure])
        warn "Error: Command terminated with non-zero exit code #{code} in the #{n + 1 == 1 ? 'first' : (n + 1).to_s} benchmark run. Use the '-i'/'--ignore-failure' option if you want to ignore this. Alternatively, use the '--show-output' option to debug what went wrong."
        exit 1
      end
      times << elapsed
    end
    r = {
      command: bench[:command], display: bench[:display], times: times, exit_codes: codes,
      mean: mean(times), stddev: stddev(times), median: median(times),
      min: times.min, max: times.max, user: 0.0, system: 0.0, memory: Array.new(times.length, 0)
    }
    results << r

    if visible
      factor, label = unit_info(unit_for([r], opts[:time_unit]))
      if run_count == 1
        puts "  Time (abs ≡):          #{fmt_time(r[:mean], factor)} #{label}               [User: 0.0 ms, System: 0.0 ms]"
      else
        puts "  Time (mean ± σ):       #{fmt_time(r[:mean], factor)} #{label} ±   #{fmt_time(r[:stddev], factor)} #{label}    [User: 0.0 ms, System: 0.0 ms]"
        puts "  Range (min … max):     #{fmt_time(r[:min], factor)} #{label} …   #{fmt_time(r[:max], factor)} #{label}    #{run_count} runs"
      end
    end
    warn "  Warning: Command took less than 5 ms to complete. Note that the results might be inaccurate because hyperfine can not calibrate the shell startup time much more precise than this limit. You can try to use the `-N`/`--shell=none` option to disable the shell completely." if r[:mean] < 0.005 && opts[:shell] != 'none'
    warn '  Warning: Ignoring non-zero exit code.' if codes.any? { |c| c != 0 } && opts[:ignore_failure]
    run_command(bench[:cleanup], opts, bench) if bench[:cleanup]
  end

  if visible && results.length > 1
    rel_stats(results, opts[:reference])
    fastest = results.min_by { |r| r[:mean] }
    puts "Summary"
    results.sort_by { |r| r[:mean] }.reject { |r| r.equal?(fastest) }.each do |r|
      puts "  #{fastest[:display]} ran"
      puts "    #{format('%.2f', r[:mean] / fastest[:mean])} ± #{format('%.2f', r[:relative_stddev])} times faster than #{r[:display]}"
    end
  end
  write_exports(results, opts)
rescue CliError => e
  warn e.message
  exit 2
end
