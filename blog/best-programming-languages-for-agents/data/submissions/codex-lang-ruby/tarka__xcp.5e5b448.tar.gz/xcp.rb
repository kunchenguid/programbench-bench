#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'etc'

VERSION = "xcp 0.24.3"

HELP_SHORT = <<~TXT
  A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

  Usage: executable [OPTIONS] [PATHS]...

  Arguments:
    [PATHS]...  Path list

  Options:
    -v, --verbose...
            Verbosity
    -r, --recursive
            Copy directories recursively
    -L, --dereference
            Dereference symlinks in source
    -w, --workers <WORKERS>
            Number of parallel workers [default: 4]
        --block-size <BLOCK_SIZE>
            Block size for operations [default: 1MB]
    -n, --no-clobber
            Do not overwrite an existing file
    -f, --force
            Force (compatability only)
        --gitignore
            Use .gitignore if present
    -g, --glob
            Expand file patterns
        --no-progress
            Disable progress bar
        --no-perms
            Do not copy the file permissions
        --no-timestamps
            Do not copy the file timestamps
    -o, --ownership
            Copy ownership
        --driver <DRIVER>
            Driver to use, defaults to 'file-parallel' [default: parfile]
    -T, --no-target-directory
            Target should not be a directory
        --target-directory <TARGET_DIRECTORY>
            Copy into a subdirectory of the target
        --fsync
            Sync each file to disk after writing
        --reflink <REFLINK>
            Reflink options [default: auto]
        --backup <BACKUP>
            Backup options [default: none]
    -h, --help
            Print help (see more with '--help')
    -V, --version
            Print version
TXT

HELP_LONG = <<~TXT
  A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

  Usage: executable [OPTIONS] [PATHS]...

  Arguments:
    [PATHS]...
            Path list.
            
            Source and destination files, or multiple source(s) to a directory.

  Options:
    -v, --verbose...
            Verbosity.
            
            Can be specified multiple times to increase logging.

    -r, --recursive
            Copy directories recursively

    -L, --dereference
            Dereference symlinks in source
            
            Follow symlinks, possibly recursively, when copying source files.

    -w, --workers <WORKERS>
            Number of parallel workers.
            
            Default is 4; if the value is negative or 0 it uses the number of logical CPUs.
            
            [default: 4]

        --block-size <BLOCK_SIZE>
            Block size for operations.
            
            Accepts standard size modifiers like "M" and "GB". Actual usage internally depends on the driver.
            
            [default: 1MB]

    -n, --no-clobber
            Do not overwrite an existing file

    -f, --force
            Force (compatability only)
            
            Overwrite files; this is the default behaviour, this flag is for compatibility with `cp` only. See `--no-clobber` for the inverse flag. Using this in conjunction with `--no-clobber` will cause an error.

        --gitignore
            Use .gitignore if present.
            
            NOTE: This is fairly basic at the moment, and only honours a .gitignore in the directory root for directory copies; global or sub-directory ignores are skipped.

    -g, --glob
            Expand file patterns.
            
            Glob (expand) filename patterns natively (note; the shell may still do its own expansion first)

        --no-progress
            Disable progress bar

        --no-perms
            Do not copy the file permissions

        --no-timestamps
            Do not copy the file timestamps

    -o, --ownership
            Copy ownership.
            
            Whether to copy ownship (user/group).  This option requires root permissions or appropriate capabilities; if the attempt to copy ownership fails a warning is issued but the operation continues.

        --driver <DRIVER>
            Driver to use, defaults to 'file-parallel'.
            
            Currently there are 2; the default "parfile", which parallelises copies across workers at the file level, and an experimental "parblock" driver, which parellelises at the block level. See also '--block-size'.
            
            [default: parfile]

    -T, --no-target-directory
            Target should not be a directory.
            
            Analogous to cp's no-target-directory. Expected behavior is that when copying a directory to another directory, instead of creating a sub-folder in target, overwrite target.

        --target-directory <TARGET_DIRECTORY>
            Copy into a subdirectory of the target

        --fsync
            Sync each file to disk after writing

        --reflink <REFLINK>
            Reflink options.
            
            Whether and how to use reflinks. 'auto' (the default) will attempt to reflink and fallback to a copy if it is not possible, 'always' will return an error if it cannot reflink, and 'never' will always perform a full data copy.
            
            Note: when using Linux accelerated copy operations (the default when available) the kernel may choose to reflink rather than perform a fully copy regardless of this setting.
            
            [default: auto]

        --backup <BACKUP>
            Backup options
            
            Whether to create backups of overwritten files. Current options are 'none'/'off', or 'numbered', or 'auto'. Numbered backups follow the semantics of `cp` numbered backups (e.g. `file.txt.~123~`). 'auto' will only create a numbered backup if a previous backups exists. Default is 'none'.
            
            [default: none]

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
TXT

class Xcp
  def initialize(argv)
    @opts = {
      recursive: false, dereference: false, no_clobber: false, force: false,
      gitignore: false, glob: false, no_perms: false, no_timestamps: false,
      ownership: false, fsync: false, no_target_directory: false,
      backup: 'none', target_directory: nil, verbose: 0
    }
    @argv = argv.dup
    @paths = []
  end

  def run
    parse!
    validate!
    expand_globs! if @opts[:glob]
    execute
    0
  rescue SystemExit
    raise
  rescue StandardError => e
    $stderr.puts "Error: #{e.message}"
    1
  end

  private

  def parse!
    until @argv.empty?
      arg = @argv.shift
      case arg
      when '--'
        @paths.concat(@argv)
        @argv.clear
      when '-h'
        puts HELP_SHORT
        exit 0
      when '--help'
        puts HELP_LONG
        exit 0
      when '-V', '--version'
        puts VERSION
        exit 0
      when '-r', '--recursive'
        @opts[:recursive] = true
      when '-L', '--dereference'
        @opts[:dereference] = true
      when '-n', '--no-clobber'
        @opts[:no_clobber] = true
      when '-f', '--force'
        @opts[:force] = true
      when '--gitignore'
        @opts[:gitignore] = true
      when '-g', '--glob'
        @opts[:glob] = true
      when '--no-progress'
        # Accepted for compatibility. This implementation is always quiet.
      when '--no-perms'
        @opts[:no_perms] = true
      when '--no-timestamps'
        @opts[:no_timestamps] = true
      when '-o', '--ownership'
        @opts[:ownership] = true
      when '--fsync'
        @opts[:fsync] = true
      when '-T', '--no-target-directory'
        @opts[:no_target_directory] = true
      when '-v', '--verbose'
        @opts[:verbose] += 1
      when /^-v+$/
        @opts[:verbose] += arg.length - 1
      when /^-[A-Za-z]+/
        parse_short_cluster(arg)
      when '-w', '--workers'
        Integer(next_value(arg))
      when /^--workers=(.*)$/
        Integer($1)
      when '--block-size'
        parse_size(next_value(arg))
      when /^--block-size=(.*)$/
        parse_size($1)
      when '--driver'
        validate_driver(next_value(arg))
      when /^--driver=(.*)$/
        validate_driver($1)
      when '--reflink'
        validate_reflink(next_value(arg))
      when /^--reflink=(.*)$/
        validate_reflink($1)
      when '--backup'
        @opts[:backup] = validate_backup(next_value(arg))
      when /^--backup=(.*)$/
        @opts[:backup] = validate_backup($1)
      when '--target-directory'
        @opts[:target_directory] = next_value(arg)
      when /^--target-directory=(.*)$/
        @opts[:target_directory] = $1
      when /^-/
        raise "unexpected argument '#{arg}' found"
      else
        @paths << arg
      end
    end
  end

  def next_value(flag)
    raise "a value is required for '#{flag}' but none was supplied" if @argv.empty?

    @argv.shift
  end

  def parse_short_cluster(arg)
    chars = arg[1..].chars
    until chars.empty?
      ch = chars.shift
      case ch
      when 'h'
        puts HELP_SHORT
        exit 0
      when 'V'
        puts VERSION
        exit 0
      when 'v'
        @opts[:verbose] += 1
      when 'r'
        @opts[:recursive] = true
      when 'L'
        @opts[:dereference] = true
      when 'n'
        @opts[:no_clobber] = true
      when 'f'
        @opts[:force] = true
      when 'g'
        @opts[:glob] = true
      when 'o'
        @opts[:ownership] = true
      when 'T'
        @opts[:no_target_directory] = true
      when 'w'
        value = chars.empty? ? next_value('-w') : chars.join
        Integer(value)
        return
      else
        raise "unexpected argument '-#{ch}' found"
      end
    end
  end

  def validate_driver(value)
    return if %w[parfile parblock file-parallel block-parallel].include?(value)

    $stderr.puts "error: invalid value '#{value}' for '--driver <DRIVER>': Unknown driver: #{value}"
    $stderr.puts
    $stderr.puts "For more information, try '--help'."
    exit 2
  end

  def validate_reflink(value)
    return if %w[auto always never].include?(value)

    $stderr.puts "error: invalid value '#{value}' for '--reflink <REFLINK>': Invalid arguments: Unexpected value for 'reflink': #{value}"
    $stderr.puts
    $stderr.puts "For more information, try '--help'."
    exit 2
  end

  def validate_backup(value)
    return 'none' if %w[none off].include?(value)
    return value if %w[numbered auto].include?(value)

    $stderr.puts "error: invalid value '#{value}' for '--backup <BACKUP>': Invalid arguments: Unexpected value for 'backup': #{value}"
    $stderr.puts
    $stderr.puts "For more information, try '--help'."
    exit 2
  end

  def parse_size(value)
    return Integer(value) if value =~ /^\d+$/

    units = {
      'k' => 1_000, 'kb' => 1_000, 'kib' => 1024,
      'm' => 1_000_000, 'mb' => 1_000_000, 'mib' => 1024**2,
      'g' => 1_000_000_000, 'gb' => 1_000_000_000, 'gib' => 1024**3
    }
    if value =~ /^(\d+)([A-Za-z]+)$/ && units[$2.downcase]
      return $1.to_i * units[$2.downcase]
    end

    $stderr.puts "error: invalid value '#{value}' for '--block-size <BLOCK_SIZE>': could not interpret string as byte size"
    $stderr.puts
    $stderr.puts "For more information, try '--help'."
    exit 2
  end

  def validate!
    raise 'Invalid arguments: --force and --noclobber cannot be set at the same time.' if @opts[:force] && @opts[:no_clobber]
    raise 'Invalid arguments: Insufficient arguments' if @paths.empty?
  end

  def expand_globs!
    expanded = []
    @paths.each do |path|
      matches = Dir.glob(path, File::FNM_DOTMATCH).reject { |p| ['.', '..'].include?(File.basename(p)) }
      expanded.concat(matches.empty? ? [path] : matches.sort)
    end
    @paths = expanded
  end

  def execute
    if @opts[:target_directory]
      sources = @paths
      dest = @opts[:target_directory]
    else
      if @paths.length < 2
        if @paths.any? && @paths.none? { |p| source_exists?(p) }
          raise 'Invalid source: No source files found.'
        end
        raise 'Invalid arguments: Insufficient arguments'
      end

      dest = @paths[-1]
      sources = @paths[0...-1]
    end

    sources.select! { |s| source_exists?(s) }
    raise 'Invalid source: No source files found.' if sources.empty?
    if sources.length > 1 && !File.directory?(dest)
      raise 'Invalid destination: Multiple sources and destination is not a directory.'
    end

    sources.each do |src|
      target = destination_for(src, dest, sources.length)
      copy_entry(src, target, root: true, ignore_root: src)
    end
  end

  def source_exists?(path)
    @opts[:dereference] ? File.exist?(path) : (File.exist?(path) || File.symlink?(path))
  end

  def destination_for(src, dest, source_count)
    if source_count > 1 || (File.directory?(dest) && !@opts[:no_target_directory])
      File.join(dest, File.basename(src))
    else
      dest
    end
  end

  def copy_entry(src, dest, root: false, ignore_root: nil)
    if ignored?(src, ignore_root)
      return
    end

    if File.symlink?(src) && !@opts[:dereference]
      copy_symlink(src, dest)
    elsif File.directory?(src)
      raise 'Invalid source: Source is directory and --recursive not specified.' if root && !@opts[:recursive]

      copy_directory(src, dest, ignore_root)
    elsif File.file?(src) || (File.symlink?(src) && @opts[:dereference])
      copy_file(src, dest)
    else
      copy_special(src, dest)
    end
  end

  def copy_directory(src, dest, ignore_root)
    backup_existing(dest) if File.exist?(dest) && !File.directory?(dest)
    if File.exist?(dest) && !File.directory?(dest)
      FileUtils.rm_f(dest)
    end
    FileUtils.mkdir_p(dest)
    apply_metadata(src, dest)
    Dir.each_child(src) do |child|
      copy_entry(File.join(src, child), File.join(dest, child), ignore_root: ignore_root)
    end
  end

  def copy_file(src, dest)
    if File.directory?(dest)
      raise 'Error during copy: Is a directory (os error 21)'
    end
    ensure_parent(dest)
    prepare_destination(dest)
    File.open(src, 'rb') do |input|
      File.open(dest, 'wb') do |output|
        IO.copy_stream(input, output)
        output.fsync if @opts[:fsync]
      end
    end
    apply_metadata(src, dest)
  rescue Errno::EISDIR
    raise 'Error during copy: Is a directory (os error 21)'
  end

  def copy_symlink(src, dest)
    ensure_parent(dest)
    prepare_destination(dest, remove: true)
    File.symlink(File.readlink(src), dest)
  end

  def copy_special(src, dest)
    copy_file(src, dest)
  rescue StandardError
    raise "Invalid source: Unsupported file type: #{src}"
  end

  def prepare_destination(dest, remove: false)
    if File.exist?(dest) || File.symlink?(dest)
      if @opts[:no_clobber]
        raise "Destination Exists: Destination file exists and --no-clobber is set., #{dest}"
      end
      backup_existing(dest)
      FileUtils.rm_rf(dest) if remove || File.directory?(dest)
    end
  end

  def backup_existing(dest)
    return unless File.exist?(dest) || File.symlink?(dest)
    return if @opts[:backup] == 'none'
    return if @opts[:backup] == 'auto' && next_backup_number(dest) == 1

    FileUtils.mv(dest, "#{dest}.~#{next_backup_number(dest)}~")
  end

  def next_backup_number(dest)
    dir = File.dirname(dest)
    base = File.basename(dest)
    nums = Dir.glob(File.join(dir, "#{base}.~*~")).filter_map do |p|
      File.basename(p)[/^#{Regexp.escape(base)}\.~(\d+)~$/, 1]&.to_i
    end
    (nums.max || 0) + 1
  end

  def ensure_parent(dest)
    parent = File.dirname(dest)
    FileUtils.mkdir_p(parent) unless parent == '.' || File.directory?(parent)
  end

  def apply_metadata(src, dest)
    st = (@opts[:dereference] && File.symlink?(src)) ? File.stat(src) : File.lstat(src)
    unless @opts[:no_perms]
      File.chmod(st.mode & 0o7777, dest)
    end
    unless @opts[:no_timestamps]
      File.utime(st.atime, st.mtime, dest)
    end
    if @opts[:ownership]
      begin
        File.chown(st.uid, st.gid, dest)
      rescue StandardError => e
        warn "Warning: could not set ownership: #{e.message}"
      end
    end
  rescue StandardError
    nil
  end

  def ignored?(path, root)
    return false unless @opts[:gitignore] && root
    return false if File.expand_path(path) == File.expand_path(root)

    @ignore_cache ||= {}
    patterns = (@ignore_cache[root] ||= read_gitignore(root))
    return false if patterns.empty?

    rel = path.sub(/\A#{Regexp.escape(root)}\/?/, '')
    patterns.any? do |pat|
      pat = pat.sub(%r{\A/}, '')
      if pat.end_with?('/')
        rel == pat.delete_suffix('/') || rel.start_with?(pat)
      else
        File.fnmatch?(pat, rel, File::FNM_PATHNAME | File::FNM_DOTMATCH) ||
          File.fnmatch?(pat, File.basename(rel), File::FNM_DOTMATCH) ||
          rel.start_with?("#{pat}/")
      end
    end
  end

  def read_gitignore(root)
    file = File.join(root, '.gitignore')
    return [] unless File.file?(file)

    File.readlines(file, chomp: true).map(&:strip).reject { |l| l.empty? || l.start_with?('#') || l.start_with?('!') }
  rescue StandardError
    []
  end
end

exit Xcp.new(ARGV).run
