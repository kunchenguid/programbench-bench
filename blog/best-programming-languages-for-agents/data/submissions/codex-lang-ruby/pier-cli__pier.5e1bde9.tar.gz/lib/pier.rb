#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = '0.1.6'

class PierError < StandardError; end

Script = Struct.new(:alias_name, :command, :description, :tags, keyword_init: true)

def main_help
  <<~TXT
    pier #{VERSION}
    Benjamin Scholtz, Isak Johansson
    A simple script management CLI

    USAGE:
        executable [FLAGS] [OPTIONS] <alias> [args]...
        executable [FLAGS] [OPTIONS] <SUBCOMMAND>

    FLAGS:
        -h, --help       
                Prints help information

        -V, --version    
                Prints version information

        -v, --verbose    
                The level of verbosity


    OPTIONS:
        -c, --config-file <path>    
                Sets a custom config file.
                
                DEFAULT PATH is otherwise determined in this order:
                
                - $PIER_CONFIG_PATH (environment variable if set)
                
                - pier.toml (in the current directory)
                
                - $XDG_CONFIG_HOME/pier/config.toml
                
                - $XDG_CONFIG_HOME/pier/config
                
                - $XDG_CONFIG_HOME/pier.toml
                
                - $HOME/.pier.toml
                
                - $HOME/.pier
                
                 [env: PIER_CONFIG_PATH=]

    ARGS:
        <alias>      
                The alias or name for the script.

        <args>...    
                The positional arguments to send to script.


    SUBCOMMANDS:
        add            Add a new script to config.
        config-init    alias: init - Add a config file.
        copy           alias: cp - Copy existing alias to the new one
        edit           Edit a script matching alias.
        help           Prints this message or the help of the given subcommand(s)
        list           alias: ls - List scripts
        move           alias: mv, rename - Move/rename existing alias to the new one
        remove         alias: rm - Remove a script matching alias.
        run            Run a script matching alias.
        show           Show a script matching alias.
  TXT
end

def sub_help(cmd)
  case cmd
  when 'list', 'ls'
    <<~TXT
      executable-list #{VERSION}
      alias: ls - List scripts

      Display options are determined by priority in this order:

      1. List only aliases

      2. Show full command

      3. Command display with (cli option)

      4. Command display with (config option)

      USAGE:
          executable list [FLAGS] [OPTIONS]

      FLAGS:
          -l, --cmd_full        Display the full command.
          -h, --help            Prints help information
          -q, --list_aliases    Only displays aliases of the scripts.
          -V, --version         Prints version information

      OPTIONS:
          -c, --cmd_width <cmd-width>    The max number of characters to display from the command.
          -t, --tag <tags>...            Filter based on tags.
    TXT
  when 'add'
    <<~TXT
      executable-add #{VERSION}
      Add a new script to config.

      USAGE:
          executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]

      FLAGS:
          -f, --force      Allows to overwrite the existing script
          -h, --help       Prints help information
          -V, --version    Prints version information

      OPTIONS:
          -a, --alias <alias>                The alias or name for the script.
          -d, --description <description>    The description for the script.
          -t, --tag <tags>...                Set which tags the script belongs to.

      ARGS:
          <command>    The command/script content to be executed. If this argument is not found it will open your $EDITOR
                       for you to enter the script into.
    TXT
  when 'config-init', 'init'
    "executable-config-init #{VERSION}\nalias: init - Add a config file.\n\nUSAGE:\n    executable config-init\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n"
  when 'run'
    "executable-run #{VERSION}\nRun a script matching alias.\n\nUSAGE:\n    executable run <alias> [args]...\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>      The alias or name for the script.\n    <args>...    The positional arguments to send to script.\n"
  when 'show'
    "executable-show #{VERSION}\nShow a script matching alias.\n\nUSAGE:\n    executable show <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n"
  when 'edit'
    "executable-edit #{VERSION}\nEdit a script matching alias.\n\nUSAGE:\n    executable edit <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n"
  when 'remove', 'rm'
    "executable-remove #{VERSION}\nalias: rm - Remove a script matching alias.\n\nUSAGE:\n    executable remove <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n"
  when 'move', 'mv', 'rename'
    "executable-move #{VERSION}\nalias: mv, rename - Move/rename existing alias to the new one\n\nUSAGE:\n    executable move [FLAGS] <from-alias> <to-alias>\n\nFLAGS:\n    -f, --force      Allows to overwrite the existing script\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be moved.\n    <to-alias>      The new alias of the script.\n"
  when 'copy', 'cp'
    "executable-copy #{VERSION}\nalias: cp - Copy existing alias to the new one\n\nUSAGE:\n    executable copy <from-alias> <to-alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be copied.\n    <to-alias>      The new alias of the copy of the script.\n"
  else
    main_help
  end
end

def unquote(v)
  v = v.strip
  if (v.start_with?("'") && v.end_with?("'")) || (v.start_with?('"') && v.end_with?('"'))
    body = v[1..-2]
    v.start_with?('"') ? body.gsub('\\"', '"').gsub('\\\\', '\\') : body
  else
    v
  end
end

def parse_config(path)
  scripts = {}
  cur = nil
  arr_key = nil
  File.readlines(path, chomp: true).each do |line|
    s = line.strip
    next if s.empty? || s.start_with?('#')
    if arr_key
      if s == ']'
        arr_key = nil
      else
        val = s.sub(/,\s*$/, '')
        scripts[cur].tags << unquote(val) if cur && !val.empty?
      end
      next
    end
    if s =~ /^\[scripts\.([^\]]+)\]$/
      cur = Regexp.last_match(1)
      scripts[cur] ||= Script.new(alias_name: cur, command: '', description: nil, tags: [])
    elsif s =~ /^\[/
      cur = nil
    elsif cur && s =~ /^([A-Za-z0-9_-]+)\s*=\s*(.*)$/
      key = Regexp.last_match(1)
      val = Regexp.last_match(2).strip
      case key
      when 'command'
        scripts[cur].command = unquote(val)
      when 'description'
        scripts[cur].description = unquote(val)
      when 'tags'
        scripts[cur].tags = []
        if val == '['
          arr_key = key
        elsif val.start_with?('[')
          val[1..-2].to_s.split(',').each { |x| scripts[cur].tags << unquote(x.strip) unless x.strip.empty? }
        end
      end
    end
  end
  scripts
rescue Errno::ENOENT => e
  raise PierError, "Unable to read config from file #{path}: #{e.message} "
end

def sq(s)
  "'#{s.to_s.gsub("'", "\\\\'")}'"
end

def write_config(path, scripts)
  File.open(path, 'w') do |f|
    scripts.keys.sort.each do |name|
      sc = scripts[name]
      f.puts "[scripts.#{name}]"
      f.puts "command = #{sq(sc.command)}"
      f.puts "description = #{sq(sc.description)}" if sc.description && sc.description != ''
      unless sc.tags.nil? || sc.tags.empty?
        f.puts 'tags = ['
        sc.tags.each { |t| f.puts "    #{sq(t)}," }
        f.puts ']'
      end
      f.puts
    end
    f.puts '[default]'
  end
end

def default_paths
  xdg = ENV['XDG_CONFIG_HOME']
  home = ENV['HOME']
  paths = []
  paths << ENV['PIER_CONFIG_PATH'] if ENV['PIER_CONFIG_PATH'] && ENV['PIER_CONFIG_PATH'] != ''
  paths << 'pier.toml'
  if xdg && xdg != ''
    paths << File.join(xdg, 'pier', 'config.toml')
    paths << File.join(xdg, 'pier', 'config')
    paths << File.join(xdg, 'pier.toml')
  end
  if home && home != ''
    paths << File.join(home, '.pier.toml')
    paths << File.join(home, '.pier')
  end
  paths
end

def find_config(explicit, allow_missing: false)
  return explicit if explicit
  found = default_paths.find { |p| File.file?(p) }
  return found if found
  return default_paths.first if allow_missing
  raise PierError, 'No default config file found. See help for more info.'
end

def require_alias!(scripts, name)
  sc = scripts[name]
  raise PierError, "AliasNotFound: No script found by alias #{name}" unless sc
  sc
end

def truncate_cmd(s, width)
  return s unless width && width > 0
  s[0, width]
end

def print_table(scripts, width: nil, tags: [])
  rows = scripts.keys.sort.map { |k| scripts[k] }
  rows = rows.select { |s| tags.all? { |t| s.tags.include?(t) } } unless tags.empty?
  data = rows.map { |s| [s.alias_name, s.tags.join(','), truncate_cmd(s.command, width), s.description.to_s] }
  headers = ['Alias', 'Tags', 'Command', 'Description']
  widths = headers.each_index.map { |i| ([headers[i].length] + data.map { |r| r[i].length }).max }
  line_len = widths.sum + 13
  bar = '≖' * line_len
  puts bar
  puts "⋮ #{headers.each_with_index.map { |h, i| h.ljust(widths[i]) }.join(' ⋮ ')} ⋮"
  puts bar
  data.each do |r|
    puts "⋮ #{r.each_with_index.map { |v, i| v.ljust(widths[i]) }.join(' ⋮ ')} ⋮"
  end
  puts bar
end

def open_editor(initial = '')
  editor = ENV['EDITOR'] || ENV['VISUAL']
  raise PierError, 'EditorError: Failed when trying to get input from editor No editor set.' if editor.nil? || editor.empty?
  require 'tempfile'
  Tempfile.create('pier') do |tf|
    tf.write(initial)
    tf.flush
    ok = system("#{editor} #{tf.path}")
    raise PierError, "EditorError: Failed when trying to get input from editor Failed to open `#{editor}` as a text editor or editor was terminated with errors." unless ok
    tf.rewind
    tf.read
  end
end

def consume_global(argv)
  explicit = nil
  out = []
  until argv.empty?
    a = argv.shift
    case a
    when '-c', '--config-file'
      explicit = argv.shift
    when /^--config-file=(.*)$/
      explicit = Regexp.last_match(1)
    when '-v', '--verbose'
      next
    else
      out << a
      out.concat(argv)
      break
    end
  end
  [explicit, out]
end

def run_script(sc, args)
  system('/bin/sh', '-c', sc.command, sc.alias_name, *args)
  exit($CHILD_STATUS ? $CHILD_STATUS.exitstatus : 1)
end

def handle(argv)
  explicit, argv = consume_global(argv)
  if argv.empty? || argv.include?('--help') || argv.include?('-h')
    if argv[0] == 'help'
      puts(argv[1] ? sub_help(argv[1]) : main_help)
    elsif argv[0] && argv[0] != '--help' && argv[0] != '-h'
      puts sub_help(argv[0])
    else
      puts main_help
    end
    return
  end
  if argv[0] == '--version' || argv[0] == '-V'
    puts "pier #{VERSION}"
    return
  end
  if argv.include?('--version') || argv.include?('-V')
    name = { 'ls' => 'list', 'rm' => 'remove', 'mv' => 'move', 'rename' => 'move',
             'cp' => 'copy', 'init' => 'config-init' }[argv[0]] || argv[0]
    puts "executable-#{name} #{VERSION}"
    return
  end
  if argv[0] == 'help'
    puts(argv[1] ? sub_help(argv[1]) : main_help)
    return
  end

  cmd = argv.shift
  case cmd
  when 'config-init', 'init'
    path = find_config(explicit, allow_missing: true)
    dir = File.dirname(path)
    if dir != '.' && !Dir.exist?(dir)
      require 'fileutils'
      FileUtils.mkdir_p(dir)
    end
    scripts = { 'hello-pier' => Script.new(alias_name: 'hello-pier', command: 'echo Hello, Pier!', description: 'This is an example command.', tags: []) }
    write_config(path, scripts)
    puts 'Added hello-pier'
  when 'add'
    path = find_config(explicit)
    scripts = parse_config(path)
    force = false
    alias_name = nil
    desc = nil
    tags = []
    command_parts = []
    until argv.empty?
      a = argv.shift
      case a
      when '-f', '--force'
        force = true
      when '-a', '--alias'
        alias_name = argv.shift
      when /^--alias=(.*)$/
        alias_name = Regexp.last_match(1)
      when '-d', '--description'
        desc = argv.shift
      when '-t', '--tag'
        while argv[0] && argv[0] != '--' && !argv[0].start_with?('-')
          tags << argv.shift
        end
      when '--'
        command_parts = argv
        argv = []
      else
        command_parts << a
        command_parts.concat(argv)
        argv = []
      end
    end
    raise PierError, "AliasAlreadyExists:  #{alias_name}" if scripts[alias_name] && !force
    command = command_parts.empty? ? open_editor : command_parts.join(' ')
    scripts[alias_name] = Script.new(alias_name: alias_name, command: command, description: desc, tags: tags.compact)
    write_config(path, scripts)
    puts "Added #{alias_name}"
  when 'list', 'ls'
    path = find_config(explicit)
    scripts = parse_config(path)
    quiet = false
    full = false
    width = nil
    tags = []
    until argv.empty?
      a = argv.shift
      case a
      when '-q', '--list_aliases'
        quiet = true
      when '-l', '--cmd_full'
        full = true
      when '-c', '--cmd_width'
        width = argv.shift.to_i
      when '-t', '--tag'
        while argv[0] && !argv[0].start_with?('-')
          tags << argv.shift
        end
      end
    end
    rows = scripts.keys.sort.map { |k| scripts[k] }
    rows = rows.select { |s| tags.all? { |t| s.tags.include?(t) } } unless tags.empty?
    if quiet
      rows.each { |s| puts s.alias_name }
    else
      print_table(scripts.select { |k, _| rows.map(&:alias_name).include?(k) }, width: (full ? nil : width), tags: [])
    end
  when 'show'
    path = find_config(explicit)
    puts require_alias!(parse_config(path), argv[0]).command
  when 'run'
    path = find_config(explicit)
    sc = require_alias!(parse_config(path), argv.shift)
    run_script(sc, argv)
  when 'remove', 'rm'
    path = find_config(explicit)
    scripts = parse_config(path)
    require_alias!(scripts, argv[0])
    scripts.delete(argv[0])
    write_config(path, scripts)
    puts "Removed #{argv[0]}"
  when 'move', 'mv', 'rename'
    path = find_config(explicit)
    force = argv.delete('-f') || argv.delete('--force')
    from, to = argv
    scripts = parse_config(path)
    sc = require_alias!(scripts, from)
    raise PierError, "AliasAlreadyExists:  #{to}" if scripts[to] && !force
    scripts.delete(from)
    scripts[to] = Script.new(alias_name: to, command: sc.command, description: sc.description, tags: sc.tags)
    write_config(path, scripts)
    puts "Move from alias #{from} to new alias #{to}"
  when 'copy', 'cp'
    path = find_config(explicit)
    from, to = argv
    scripts = parse_config(path)
    sc = require_alias!(scripts, from)
    raise PierError, "AliasAlreadyExists:  #{to}" if scripts[to]
    scripts[to] = Script.new(alias_name: to, command: sc.command, description: sc.description, tags: sc.tags.dup)
    write_config(path, scripts)
    puts "Copy from alias #{from} to new alias #{to}"
  when 'edit'
    path = find_config(explicit)
    scripts = parse_config(path)
    sc = require_alias!(scripts, argv[0])
    sc.command = open_editor(sc.command)
    write_config(path, scripts)
  else
    path = find_config(explicit)
    sc = require_alias!(parse_config(path), cmd)
    run_script(sc, argv)
  end
end

begin
  require 'English'
  handle(ARGV.dup)
rescue PierError => e
  warn "error: #{e.message}"
  exit 1
end
