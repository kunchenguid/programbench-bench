#!/usr/bin/env ruby
# frozen_string_literal: true

require "zlib"

module Rhit
  MONTHS = {
    "Jan" => 1, "Feb" => 2, "Mar" => 3, "Apr" => 4, "May" => 5, "Jun" => 6,
    "Jul" => 7, "Aug" => 8, "Sep" => 9, "Oct" => 10, "Nov" => 11, "Dec" => 12
  }.freeze
  DEFAULT_FIELDS = %i[date status referer path].freeze
  ALL_FIELDS = %i[date time method status ip referer path].freeze
  FIELD_ALIASES = {
    "d" => :date, "date" => :date,
    "t" => :time, "time" => :time,
    "m" => :method, "method" => :method,
    "s" => :status, "status" => :status,
    "i" => :ip, "ip" => :ip,
    "r" => :referer, "ref" => :referer, "referer" => :referer, "referrer" => :referer,
    "p" => :path, "path" => :path
  }.freeze
  RESOURCE_RE = /\.(?:png|jpe?g|gif|webp|svg|ico|css|js|map|woff2?|ttf|eot|mp4|mp3|avi|mov|pdf|zip|gz|tgz|tar|rar|7z)(?:[?#].*)?\z/i

  Hit = Struct.new(:raw, :remote_addr, :date, :time, :method, :path, :status, :bytes_sent, :referer, :stamp, keyword_init: true) do
    def to_h
      {
        date: date,
        time: time,
        remote_addr: remote_addr,
        method: method,
        path: path,
        status: status,
        bytes_sent: bytes_sent,
        referer: referer
      }
    end
  end

  class CLI
    def initialize(argv)
      @argv = argv.dup
      @opts = {
        color: "auto", key: "hits", length: 1, fields: DEFAULT_FIELDS.dup,
        changes: false, all: false, no_name_check: false, output: "tables",
        silent_load: false, filters: {}
      }
      @paths = []
    end

    def run
      parse_args
      if @show_help
        puts help_text
        return
      end
      if @show_version
        puts "rhit 2.0.4"
        return
      end

      files = collect_files
      hits = []
      files.each { |file| read_file(file) { |line| (hit = parse_line(line)) && hits << hit } }
      hits = apply_filters(hits)
      case @opts[:output]
      when "raw" then puts hits.map(&:raw)
      when "csv" then output_csv(hits)
      when "json" then puts json_pretty(hits)
      else output_tables(hits)
      end
    rescue Error => e
      warn e.message
      exit 1
    rescue Errno::ENOENT => e
      warn %(Error: PathNotFound("#{e.message.split(" - ").last || e.message}"))
      exit 1
    rescue Errno::EACCES => e
      warn %(Error: PermissionDenied("#{e.message.split(" - ").last || e.message}"))
      exit 1
    end

    private

    Error = Class.new(StandardError)

    def parse_args
      until @argv.empty?
        arg = @argv.shift
        case arg
        when "--help" then @show_help = true
        when "--version" then @show_version = true
        when "--changes", "-c" then @opts[:changes] = true
        when "--all", "-a" then @opts[:all] = true
        when "--no-name-check" then @opts[:no_name_check] = true
        when "--silent-load" then @opts[:silent_load] = true
        when "-k", "--key" then @opts[:key] = parse_key(take_value(arg))
        when "-l", "--length" then @opts[:length] = take_value(arg).to_i
        when "-f", "--fields", "--field" then @opts[:fields] = parse_fields(take_value(arg))
        when "-d", "--date" then @opts[:filters][:date] = take_value(arg)
        when "-t", "--time" then @opts[:filters][:time] = take_value(arg)
        when "-i", "--ip" then @opts[:filters][:ip] = take_value(arg)
        when "-m", "--method" then @opts[:filters][:method] = take_value(arg)
        when "-p", "--path" then @opts[:filters][:path] = take_value(arg)
        when "-r", "--referer", "--referrer" then @opts[:filters][:referer] = take_value(arg)
        when "-s", "--status" then @opts[:filters][:status] = take_value(arg)
        when "-o", "--output" then @opts[:output] = parse_output(take_value(arg))
        when "--color" then @opts[:color] = take_value(arg)
        when /\A--color=(.*)\z/ then @opts[:color] = Regexp.last_match(1)
        when /\A--([^=]+)=(.*)\z/
          @argv.unshift(Regexp.last_match(2))
          @argv.unshift("--#{Regexp.last_match(1)}")
        when /\A-[^-].+/
          expand_short(arg)
        else
          @paths << arg
        end
      end
    end

    def expand_short(arg)
      chars = arg[1..].chars
      first = "-#{chars.shift}"
      if %w[-k -l -f -d -t -i -m -p -r -s -o].include?(first)
        @argv.unshift(chars.join) unless chars.empty?
        @argv.unshift(first)
      else
        chars.reverse_each { |c| @argv.unshift("-#{c}") }
        @argv.unshift(first)
      end
    end

    def take_value(opt)
      raise Error, "error: a value is required for '#{opt}'" if @argv.empty?
      @argv.shift
    end

    def parse_key(value)
      case value
      when "h", "hits" then "hits"
      when "b", "bytes" then "bytes"
      else raise Error, "error: invalid value '#{value}' for '--key <KEY>': unrecognized key \"#{value}\""
      end
    end

    def parse_output(value)
      case value
      when "t", "tables" then "tables"
      when "r", "raw" then "raw"
      when "c", "csv" then "csv"
      when "j", "json" then "json"
      else raise Error, "error: invalid value '#{value}' for '--output <OUTPUT>': unrecognized output \"#{value}\""
      end
    end

    def parse_fields(value)
      fields = value.start_with?("+", "-") ? DEFAULT_FIELDS.dup : []
      value = value.gsub(",", "+")
      value.scan(/[+-]?[^+-]+/).each do |part|
        op = part[0] == "-" ? "-" : "+"
        name = part.sub(/\A[+-]/, "")
        list = if %w[a all].include?(name)
          ALL_FIELDS
        else
          field = FIELD_ALIASES[name]
          raise Error, "error: invalid value '#{value}' for '--fields <FIELDS>': unrecognized field start '#{name[0]}'" unless field
          [field]
        end
        list.each do |field|
          fields.delete(field)
          fields << field if op == "+"
        end
      end
      fields
    end

    def collect_files
      paths = @paths.empty? ? ["/var/log/nginx"] : @paths
      files = []
      paths.each do |path|
        raise Error, %(Error: PathNotFound("#{path}")) unless File.exist?(path)
        if File.directory?(path)
          Dir.glob(File.join(path, "**", "*")).sort.each do |f|
            next unless File.file?(f)
            files << f if @opts[:no_name_check] || File.basename(f).match?(/\Aaccess\.log(?:[.\d-].*)?\z|\.log(?:\.gz)?\z/)
          end
        else
          files << path
        end
      end
      files
    end

    def read_file(path)
      if path.end_with?(".gz")
        Zlib::GzipReader.open(path) { |gz| gz.each_line { |line| yield line.chomp } }
      else
        File.foreach(path) { |line| yield line.chomp }
      end
    end

    def parse_line(line)
      re = /\A(\S+) \S+ \S+ \[([^\]]+)\] "([^"]*)" (\d{3}) (\S+) "([^"]*)" "([^"]*)"/
      m = re.match(line)
      return nil unless m
      remote, datetime, request, status, bytes, referer = m[1], m[2], m[3], m[4], m[5], m[6]
      dt = parse_nginx_time(datetime)
      method, path = parse_request(request)
      Hit.new(
        raw: line, remote_addr: remote, date: dt.strftime("%Y/%m/%d"), time: dt.strftime("%H:%M:%S"),
        method: method, path: path, status: status, bytes_sent: bytes == "-" ? 0 : bytes.to_i,
        referer: referer, stamp: dt
      )
    end

    def parse_nginx_time(s)
      if s =~ %r{\A(\d{1,2})/([A-Z][a-z]{2})/(\d{4}):(\d{2}):(\d{2}):(\d{2}) ([+-]\d{4})\z}
        Time.new($3.to_i, MONTHS.fetch($2), $1.to_i, $4.to_i, $5.to_i, $6.to_i, $7)
      else
        raise Error, "Error: Unrecognized log date #{s.inspect}"
      end
    end

    def parse_request(request)
      parts = request.split(/\s+/, 3)
      if parts.length >= 2 && parts[0].match?(/\A[A-Z]+\z/)
        [parts[0], parts[1]]
      else
        ["none", request]
      end
    end

    def apply_filters(hits)
      hits.select do |h|
        f = @opts[:filters]
        (!f[:status] || status_match?(h.status.to_i, f[:status])) &&
          (!f[:date] || date_match?(h, f[:date], hits)) &&
          (!f[:time] || time_match?(h.time, f[:time])) &&
          (!f[:ip] || text_match?(h.remote_addr, f[:ip])) &&
          (!f[:method] || method_match?(h.method, f[:method])) &&
          (!f[:path] || expr_match?(h.path, f[:path])) &&
          (!f[:referer] || expr_match?(h.referer, f[:referer]))
      end
    end

    def text_match?(value, spec)
      neg = spec.start_with?("!")
      pat = neg ? spec[1..] : spec
      ok = regex(pat).match?(value)
      neg ? !ok : ok
    end

    def method_match?(value, spec)
      return value == "none" if spec == "none"
      return !%w[GET POST PUT DELETE HEAD OPTIONS PATCH CONNECT TRACE none].include?(value) if spec == "other"
      text_match?(value, spec)
    end

    def status_match?(status, spec)
      positives = []
      negatives = []
      spec.split(",").each do |raw|
        raw = raw.strip
        next if raw.empty?
        if raw.start_with?("!")
          negatives << raw[1..]
        else
          positives << raw
        end
      end
      ok = positives.empty? || positives.any? { |p| status_piece?(status, p) }
      ok && negatives.none? { |n| status_piece?(status, n) }
    end

    def status_piece?(status, piece)
      case piece
      when /\A(\d)xx\z/i then status / 100 == $1.to_i
      when /\A(\d+)-(\d+)\z/ then status.between?($1.to_i, $2.to_i)
      else status == piece.to_i
      end
    end

    def date_match?(hit, spec, all_hits)
      neg = spec.start_with?("!")
      spec = spec[1..] if neg
      ok = if spec.match?(%r{\A\d{1,2}/\d{1,2}\z})
        m, d = spec.split("/").map(&:to_i)
        hit.stamp.month == m && hit.stamp.day == d
      elsif spec.start_with?(">", "<")
        op = spec[0]
        target = date_bounds(spec[1..], all_hits).first
        op == ">" ? hit.stamp > target : hit.stamp < target
      elsif spec.include?("-")
        a, b = spec.split("-", 2)
        lo = date_bounds(a, all_hits).first
        hi = date_bounds(b, all_hits).last
        hit.stamp >= lo && hit.stamp <= hi
      else
        lo, hi = date_bounds(spec, all_hits)
        hit.stamp >= lo && hit.stamp <= hi
      end
      neg ? !ok : ok
    end

    def date_bounds(spec, hits)
      date, time = spec.split(/[T ]/, 2)
      nums = date.split("/").map(&:to_i)
      y = m = d = nil
      if nums.length == 1
        y = nums[0]
      elsif nums.length == 2
        if nums[0] > 31
          y, m = nums
        else
          years = hits.map { |h| h.stamp.year }.uniq
          y = years.length == 1 ? years.first : nil
          m, d = nums
        end
      else
        y, m, d = nums
      end
      hms = time ? time.split(":").map(&:to_i) : []
      h, mi, s = hms
      lo = Time.new(y || 0, m || 1, d || 1, h || 0, mi || 0, s || 0, "+00:00")
      hi = Time.new(y || 9999, m || 12, d || days_in_month(y || 2024, m || 12), h || 23, mi || 59, s || 59, "+00:00")
      [lo, hi]
    end

    def days_in_month(y, m)
      return 31 if [1, 3, 5, 7, 8, 10, 12].include?(m)
      return 30 if [4, 6, 9, 11].include?(m)
      ((y % 4).zero? && (!(y % 100).zero? || (y % 400).zero?)) ? 29 : 28
    end

    def time_match?(time, spec)
      sec = hms_seconds(time)
      neg = spec.start_with?("!")
      spec = spec[1..] if neg
      ok = if spec.start_with?(">", "<")
        op = spec[0]
        target = hms_seconds(normalize_time(spec[1..]))
        op == ">" ? sec > target : sec < target
      elsif spec.include?("-")
        a, b = spec.split("-", 2).map { |x| hms_seconds(normalize_time(x)) }
        sec >= a && sec <= b
      else
        sec == hms_seconds(normalize_time(spec))
      end
      neg ? !ok : ok
    end

    def normalize_time(s)
      parts = s.split(":")
      parts << "00" while parts.length < 3
      parts.map { |p| p.rjust(2, "0") }.join(":")
    end

    def hms_seconds(s)
      h, m, sec = s.split(":").map(&:to_i)
      h * 3600 + m * 60 + sec
    end

    def expr_match?(value, spec)
      # Rhit's common shorthand: comma means all conditions must match.
      if spec.include?(",")
        return spec.split(",").all? { |part| expr_match?(value, part.strip) }
      end
      stripped = spec.strip
      return true if stripped.empty?
      if stripped.start_with?("!") && !stripped.start_with?("!(")
        return !regex(stripped[1..].strip).match?(value)
      end
      if stripped.match?(/[()&|]/)
        return eval_expr(tokenize_expr(stripped), value)
      end
      regex(stripped).match?(value)
    rescue RegexpError
      value.include?(spec)
    end

    def regex(pattern)
      Regexp.new(pattern)
    rescue RegexpError
      Regexp.new(Regexp.escape(pattern))
    end

    def tokenize_expr(s)
      tokens = []
      i = 0
      while i < s.length
        if s[i] =~ /\s/
          i += 1
        elsif "()&|!".include?(s[i])
          tokens << s[i]
          i += 1
        else
          j = i
          j += 1 while j < s.length && !"()&|!".include?(s[j])
          tokens << s[i...j].strip
          i = j
        end
      end
      tokens.reject(&:empty?)
    end

    def eval_expr(tokens, value)
      parse_or = lambda do
        left = parse_and.call
        while tokens.first == "|"
          tokens.shift
          left = left || parse_and.call
        end
        left
      end
      parse_and = lambda do
        left = parse_not.call
        while tokens.first == "&"
          tokens.shift
          left = left && parse_not.call
        end
        left
      end
      parse_not = lambda do
        if tokens.first == "!"
          tokens.shift
          !parse_not.call
        elsif tokens.first == "("
          tokens.shift
          v = parse_or.call
          tokens.shift if tokens.first == ")"
          v
        else
          regex(tokens.shift.to_s).match?(value)
        end
      end
      parse_or.call
    end

    def output_csv(hits)
      puts "date,time,remote address,method,path,status,bytes sent,referer"
      hits.each do |h|
        puts [
          csv_cell(h.date), csv_cell(h.time), csv_cell(h.remote_addr), csv_cell(h.method),
          csv_cell(h.path, always: true), csv_cell(h.status), csv_cell(h.bytes_sent),
          csv_cell(h.referer, always: true)
        ].join(",")
      end
    end

    def json_pretty(hits)
      lines = ["["]
      hits.each_with_index do |h, idx|
        comma = idx == hits.length - 1 ? "" : ","
        lines << "  {"
        fields = [
          ["date", h.date],
          ["time", h.time],
          ["remote_addr", h.remote_addr],
          ["method", h.method],
          ["path", h.path],
          ["status", h.status],
          ["bytes_sent", h.bytes_sent],
          ["referer", h.referer]
        ]
        fields.each_with_index do |(k, v), fidx|
          tail = fidx == fields.length - 1 ? "" : ","
          rendered = v.is_a?(Integer) ? v.to_s : %("#{json_escape(v)}")
          lines << %(    "#{k}": #{rendered}#{tail})
        end
        lines << "  }#{comma}"
      end
      lines << "]"
      lines.join("\n")
    end

    def json_escape(value)
      value.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
        case ch
        when '"' then '\"'
        when "\\" then "\\\\"
        when "\b" then "\\b"
        when "\f" then "\\f"
        when "\n" then "\\n"
        when "\r" then "\\r"
        when "\t" then "\\t"
        end
      end
    end

    def csv_cell(value, always: false, quote_slash: false)
      s = value.to_s
      if always || s.empty? || s.match?(/[",\n\r]/) || s.start_with?(" ") || s.end_with?(" ") || (quote_slash && s.start_with?("/"))
        %("#{s.gsub('"', '""')}")
      else
        s
      end
    end

    def output_tables(hits)
      if hits.empty?
        puts "0 hit"
        return
      end
      total_bytes = hits.sum(&:bytes_sent)
      dates = hits.map(&:date)
      puts "#{hits.length} #{hits.length == 1 ? "hit" : "hits"} and #{total_bytes} from #{dates.min} to #{dates.max}"
      @opts[:fields].each do |field|
        case field
        when :date then table_for(hits, :date, "date")
        when :time then table_for(hits, ->(h) { h.time[0, 2] }, "hour")
        when :method then table_for(hits, :method, "method")
        when :status then table_for(hits, :status, "status", "HTTP status codes")
        when :ip then table_for(hits, :remote_addr, "remote address")
        when :referer then table_for(hits.reject { |h| h.referer == "-" }, :referer, "referrer")
        when :path
          rows = @opts[:all] ? hits : hits.reject { |h| h.path.match?(RESOURCE_RE) }
          table_for(rows, :path, "path")
        end
      end
    end

    def table_for(hits, getter, label, title = nil)
      groups = Hash.new { |h, k| h[k] = { hits: 0, bytes: 0 } }
      hits.each do |hit|
        key = getter.respond_to?(:call) ? getter.call(hit) : hit.public_send(getter)
        groups[key][:hits] += 1
        groups[key][:bytes] += hit.bytes_sent
      end
      return if groups.empty?
      noun = title || "#{groups.length} #{label}#{groups.length == 1 ? "" : "s"}"
      puts "#{noun}. "
      rows = groups.map { |k, v| [k, v[:hits], v[:bytes]] }
      metric = @opts[:key] == "bytes" ? 2 : 1
      rows.sort_by! { |r| [-r[metric], r[0].to_s] }
      limit = [5 + @opts[:length].to_i * 5, rows.length].min
      rows = rows.first(limit)
      width = [label.length, *rows.map { |r| r[0].to_s.length }].max
      puts " #  #{label.ljust(width)} hits   % bytes"
      rows.each_with_index do |(key, count, bytes), idx|
        pct = hits.empty? ? 0 : (count * 100.0 / hits.length)
        puts format("%2d  %-#{width}s %4d %5.1f%% %5d", idx + 1, key, count, pct, bytes)
      end
    end

    def help_text
      <<~TEXT
        rhit 2.0.4

        Rhit analyzes your nginx logs.

        Usage: rhit [options] [FILES]

        Options:
            --help                 Print help information
            --version              Print the version
            --color COLOR          Whether to have styles and colors
        -k, --key KEY              Key used in sorting and histogram, either hits or bytes
        -l, --length LENGTH        Detail level, from 0 to 6
        -f, --fields FIELDS        Comma separated list of hit fields to display
        -c, --changes              Add tables with more popular and less popular entries
        -d, --date DATE            Filter dates
        -i, --ip IP                Ip address to filter by
        -m, --method METHOD        HTTP method to filter by
        -p, --path PATH            Pattern for path filtering
        -r, --referer REFERER      Referrer filter
        -s, --status STATUS        Status filter
        -t, --time TIME            Filter the time of the day
        -a, --all                  Show all paths, including resources
            --no-name-check        Try to open all files, whatever their names
        -o, --output OUTPUT        tables, csv, json, or raw
            --silent-load          Don't print anything during load
      TEXT
    end
  end
end
