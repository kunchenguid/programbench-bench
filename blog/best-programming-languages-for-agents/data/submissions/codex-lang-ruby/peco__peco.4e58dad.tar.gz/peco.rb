#!/usr/bin/env ruby
# frozen_string_literal: true

HELP = <<~HELP

  Usage: peco [options] [FILE]

  Options:
    -h, --help            show this help message and exit
    --query               initial value for query
    --rcfile              path to the settings file
    --version             print the version and exit
    -b, --buffer-size     number of lines to keep in search buffer
    --null                expect NUL (\\0) as separator for target/output
    --initial-index       position of the initial index of the selection (0 base)
    --initial-filter      specify the default filter
    --prompt              specify the prompt string
    --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'
    --select-1            select first item and immediately exit if the input contains only 1 item
    --exit-0              exit immediately with status 1 if the input is empty
    --select-all          select all items and immediately exit
    --on-cancel           specify action on user cancel. 'success' or 'error'.
                          default is 'success'. This may change in future versions
    --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.
                          default is to use colors. This option is experimental
    --exec                execute command instead of finishing/terminating peco.
                          Please note that this command will receive selected line(s) from stdin,
                          and will be executed via '/bin/sh -c' or 'cmd /c'
    --print-query         print out the current query as first line of output
    --ansi                enable ANSI color code support
    --height              display height in lines or percentage (e.g. '10', '50%')
HELP

VALUE_FLAGS = {
  '--query' => :query,
  '--rcfile' => :rcfile,
  '--initial-index' => :initial_index,
  '--initial-filter' => :initial_filter,
  '--prompt' => :prompt,
  '--layout' => :layout,
  '--on-cancel' => :on_cancel,
  '--selection-prefix' => :selection_prefix,
  '--exec' => :exec_cmd,
  '--height' => :height,
  '--buffer-size' => :buffer_size,
  '-b' => :buffer_size
}.freeze

BOOL_FLAGS = {
  '-h' => :help,
  '--help' => :help,
  '--version' => :version,
  '--null' => :null,
  '--select-1' => :select_1,
  '--exit-0' => :exit_0,
  '--select-all' => :select_all,
  '--print-query' => :print_query,
  '--ansi' => :ansi
}.freeze

def die(msg = nil, status = 1, usage: false)
  $stderr.puts(msg) if msg && !msg.empty?
  $stderr.print(HELP) if usage
  exit(status)
end

def parse_args(argv)
  opts = {
    query: '',
    initial_filter: 'IgnoreCase',
    prompt: 'QUERY>',
    layout: 'top-down',
    on_cancel: 'success',
    initial_index: 0,
    files: []
  }

  argv.each do |arg|
    if BOOL_FLAGS.key?(arg)
      opts[BOOL_FLAGS[arg]] = true
    elsif arg.start_with?('--') || arg.start_with?('-b')
      name, val = arg.split('=', 2)
      if VALUE_FLAGS.key?(name)
        if val.nil?
          die("expected argument for flag `#{name}'", 1, usage: true)
        end
        opts[VALUE_FLAGS[name]] = val
      elsif name == '--bogus'
        exit(1)
      else
        # The original is terse for several unknown flags; keep the failure simple.
        exit(1)
      end
    else
      opts[:files] << arg
    end
  end

  opts
end

def load_config(opts)
  paths = []
  paths << opts[:rcfile] if opts[:rcfile]
  unless opts[:rcfile]
    home = ENV['HOME']
    xdg_home = ENV['XDG_CONFIG_HOME']
    xdg_dirs = ENV['XDG_CONFIG_DIRS']
    paths << File.join(xdg_home, 'peco', 'config.json') if xdg_home
    paths << File.join(xdg_home, 'peco', 'config.yaml') if xdg_home
    if home
      paths << File.join(home, '.config', 'peco', 'config.json')
      paths << File.join(home, '.config', 'peco', 'config.yaml')
      xdg_dirs.to_s.split(':').each do |dir|
        next if dir.empty?
        paths << File.join(dir, 'peco', 'config.json')
        paths << File.join(dir, 'peco', 'config.yaml')
      end
      paths << File.join(home, '.peco', 'config.json')
      paths << File.join(home, '.peco', 'config.yaml')
    end
  end

  path = paths.find { |p| p && File.file?(p) }
  if opts[:rcfile] && !path
    die("#{File.basename(opts[:rcfile])}: open #{opts[:rcfile]}: no such file or directory")
  end
  return opts unless path

  begin
    data = parse_config_file(path)
  rescue StandardError => e
    die("Error: failed to setup peco: failed to apply configuration: #{e.message}")
  end
  data = {} unless data.is_a?(Hash)

  opts[:prompt] = data['Prompt'] if data.key?('Prompt') && opts[:prompt] == 'QUERY>'
  opts[:initial_filter] = data['InitialFilter'] if data.key?('InitialFilter') && opts[:initial_filter] == 'IgnoreCase'
  opts[:on_cancel] = data['OnCancel'] if data.key?('OnCancel') && opts[:on_cancel] == 'success'
  opts[:ansi] = true if data['ANSI'] == true && !opts.key?(:ansi)
  opts[:height] = data['Height'] if data.key?('Height') && !opts[:height]
  opts
end

def parse_config_file(path)
  text = File.read(path)
  data = {}
  %w[Prompt InitialFilter OnCancel Height].each do |key|
    if text =~ /["']?#{Regexp.escape(key)}["']?\s*[:=]\s*["']([^"']*)["']/
      data[key] = Regexp.last_match(1)
    end
  end
  %w[ANSI].each do |key|
    if text =~ /["']?#{Regexp.escape(key)}["']?\s*[:=]\s*(true|false)/i
      data[key] = Regexp.last_match(1).downcase == 'true'
    end
  end
  data
end

def validate!(opts)
  begin
    Integer(opts[:initial_index]) if opts[:initial_index]
  rescue ArgumentError
    die("invalid argument for flag `--initial-index' (expected int): strconv.ParseInt: parsing \"#{opts[:initial_index]}\": invalid syntax")
  end
  if opts[:buffer_size]
    begin
      Integer(opts[:buffer_size])
    rescue ArgumentError
      die("invalid argument for flag `-b, --buffer-size' (expected int): strconv.ParseInt: parsing \"#{opts[:buffer_size]}\": invalid syntax", 1, usage: true)
    end
  end
  layouts = %w[top-down bottom-up top-down-query-bottom]
  die("Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line arguments: unknown layout: '#{opts[:layout]}'") unless layouts.include?(opts[:layout])
  filters = %w[IgnoreCase CaseSensitive SmartCase Regexp IRegexp Fuzzy]
  die("ter: specified filter was not found") unless filters.include?(opts[:initial_filter])
  unless %w[success error].include?(opts[:on_cancel])
    die("Error: failed to setup peco: failed to apply configuration: invalid --on-cancel value: invalid OnCancel value \"#{opts[:on_cancel]}\": must be \"success\" or \"error\"")
  end
  if opts[:height] && opts[:height].to_s !~ /\A[0-9]+%?\z/
    die("Error: failed to setup peco: failed to apply configuration: failed to parse height specification: invalid height specification: \"#{opts[:height]}\"")
  end
end

def strip_ansi(s)
  s.gsub(/\e\[[0-9;?]*[ -\/]*[@-~]/, '')
end

def read_records(opts)
  raw = +''
  if opts[:files].empty?
    raw = $stdin.read || ''
  else
    opts[:files].each do |file|
      begin
        raw << File.binread(file)
      rescue StandardError => e
        die("Error: failed to setup input source: failed to open file for input: open #{file}: #{e.message.split(' - ').first}")
      end
    end
  end

  parts = raw.split("\n", -1)
  parts.pop if parts.last == ''
  parts.map do |line|
    if opts[:null]
      display, target = line.split("\0", 2)
      { display: display || '', target: target || display || '', plain: strip_ansi(display || '') }
    else
      { display: line, target: line, plain: strip_ansi(line) }
    end
  end
end

def parse_terms(query)
  query.to_s.split(/\s+/).reject(&:empty?).map do |term|
    neg = false
    if term.start_with?('\\-')
      term = term[1..]
    elsif term.start_with?('-') && term != '-'
      neg = true
      term = term[1..]
    end
    [neg, term]
  end
end

def fuzzy_match?(text, pat, sensitive)
  src = sensitive ? text : text.downcase
  ptn = sensitive ? pat : pat.downcase
  pos = 0
  ptn.each_char do |ch|
    idx = src.index(ch, pos)
    return false unless idx
    pos = idx + 1
  end
  true
end

def matches?(line, query, filter)
  terms = parse_terms(query)
  return true if terms.empty?
  smart_sensitive = terms.any? { |_, t| t =~ /[A-Z]/ }
  terms.all? do |neg, term|
    ok =
      case filter
      when 'CaseSensitive'
        line.include?(term)
      when 'SmartCase'
        smart_sensitive ? line.include?(term) : line.downcase.include?(term.downcase)
      when 'Regexp'
        begin
          !!(line =~ Regexp.new(term))
        rescue RegexpError
          false
        end
      when 'IRegexp'
        begin
          !!(line =~ Regexp.new(term, Regexp::IGNORECASE))
        rescue RegexpError
          false
        end
      when 'Fuzzy'
        neg ? !!(line =~ Regexp.new(term)) : fuzzy_match?(line, term, smart_sensitive)
      else
        line.downcase.include?(term.downcase)
      end
    neg ? !ok : ok
  end
end

def filtered(records, opts)
  records.select { |r| matches?(r[:plain], opts[:query], opts[:initial_filter]) }
end

def print_records(records, opts)
  $stdout.write("#{opts[:query]}\n") if opts[:print_query]
  records.each { |r| $stdout.write("#{r[:target]}\n") }
end

opts = parse_args(ARGV)
if opts[:help]
  $stdout.print(HELP)
  exit(0)
end
if opts[:version]
  puts 'peco version v0.5.11 (built with go1.25.0)'
  exit(0)
end

opts = load_config(opts)
validate!(opts)
records = read_records(opts)
records = records.last(Integer(opts[:buffer_size])) if opts[:buffer_size] && Integer(opts[:buffer_size]).positive?

if opts[:exit_0] && records.empty?
  exit(1)
end

current = filtered(records, opts)
if opts[:select_1] && records.length == 1
  print_records(records, opts)
  exit(0)
end

if opts[:select_all]
  # peco's no-query path exits immediately; matching the filtered result is more useful for scripts.
  print_records(current, opts)
  exit(0)
end

if ENV['TERM'].to_s.empty?
  die('Error: failed to initialize screen: failed to create tcell screen: terminal entry not found: term not set')
end
unless File.exist?('/dev/tty')
  die('Error: failed to initialize screen: failed to initialize tcell screen: open /dev/tty: no such device or address')
end

begin
  require 'io/console'
  tty = File.open('/dev/tty', 'r+')
  selected = [[Integer(opts[:initial_index] || 0), current.length - 1].min, 0].max
  tty.raw do
    loop do
      tty.write("\r\e[2K#{opts[:prompt]}#{opts[:query]} [#{current.length}]")
      ch = tty.getch
      case ch
      when "\r", "\n"
        print_records(current[selected] ? [current[selected]] : [], opts)
        exit(0)
      when "\e", "\u0003"
        exit(opts[:on_cancel] == 'error' ? 1 : 0)
      when "\u007F", "\b"
        opts[:query] = opts[:query][0...-1]
      else
        opts[:query] += ch if ch && ch >= ' '
      end
      current = filtered(records, opts)
      selected = 0
    end
  end
rescue StandardError => e
  die("Error: failed to initialize screen: #{e.message}")
end
