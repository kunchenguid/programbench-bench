#!/usr/bin/env ruby
# frozen_string_literal: true

require 'open3'
require 'tempfile'
require 'cgi'

VERSION_TEXT = "jp2a 1.0.8\nCopyright 2006-2016 Christian Stigen Larsen\nDistributed under the GNU General Public License (GPL) v2.\n"
HELP_TEXT = <<~TXT
  jp2a 1.0.8
  Copyright 2006-2016 Christian Stigen Larsen
  Distributed under the GNU General Public License (GPL) v2.

  Usage: jp2a [ options ] [ file(s) | URL(s) ]

  Convert files or URLs from JPEG format to ASCII.

  OPTIONS
    -                 Read images from standard input.
        --blue=N.N    Set RGB to grayscale conversion weight, default is 0.1145
    -b, --border      Print a border around the output image.
        --chars=...   Select character palette used to paint the image.
                      Leftmost character corresponds to black pixel, right-
                      most to white.  Minimum two characters must be specified.
        --clear       Clears screen before drawing each output image.
        --colors      Use ANSI colors in output.
    -d, --debug       Print additional debug information.
        --fill        When used with --color and/or --html, color each character's
                      background color.
    -x, --flipx       Flip image in X direction.
    -y, --flipy       Flip image in Y direction.
    -f, --term-fit    Use the largest image dimension that fits in your terminal
                      display with correct aspect ratio.
        --term-height Use terminal display height.
        --term-width  Use terminal display width.
    -z, --term-zoom   Use terminal display dimension for output.
        --grayscale   Convert image to grayscale when using --html or --colors
        --green=N.N   Set RGB to grayscale conversion weight, default is 0.5866
        --height=N    Set output height, calculate width from aspect ratio.
    -h, --help        Print program help.
        --html        Produce strict XHTML 1.0 output.
        --html-fill   Same as --fill (will be phased out)
        --html-fontsize=N   Set fontsize to N pt, default is 4.
        --html-no-bold      Do not use bold characters with HTML output
        --html-raw    Output raw HTML codes, i.e. without the <head> section etc.
        --html-title=...  Set HTML output title
    -i, --invert      Invert output image.  Use if your display has a dark
                      background.
        --background=dark   These are just mnemonics whether to use --invert
        --background=light  or not.  If your console has light characters on
                      a dark background, use --background=dark.
        --output=...  Write output to file.
        --red=N.N     Set RGB to grayscale conversion weight, default 0.2989f.
        --size=WxH    Set output width and height.
    -v, --verbose     Verbose output.
    -V, --version     Print program version.
        --width=N     Set output width, calculate height from ratio.

    The default mode is `jp2a --term-fit --background=dark'.
    See the man-page for jp2a for more detailed help text.

  Project homepage on https://github.com/cslarsen/jp2a
  Report bugs to <csl@csl.name>
TXT

DEFAULT_CHARS = "   ...',;:clodxkO0KXNWM"

class Options
  attr_accessor :width, :height, :chars, :invert, :border, :flipx, :flipy,
                :html, :html_raw, :html_title, :html_fontsize, :html_bold,
                :colors, :fill, :grayscale, :output, :clear, :verbose,
                :term_fit, :term_width, :term_height, :term_zoom,
                :red, :green, :blue
  def initialize
    @chars = DEFAULT_CHARS.dup
    @invert = false
    @border = false
    @flipx = false
    @flipy = false
    @html = false
    @html_raw = false
    @html_title = 'jp2a converted image'
    @html_fontsize = 8
    @html_bold = true
    @colors = false
    @fill = false
    @grayscale = false
    @clear = false
    @verbose = false
    @term_fit = false
    @term_width = false
    @term_height = false
    @term_zoom = false
    @red = 0.2989
    @green = 0.5866
    @blue = 0.1145
  end
end

def help_and_exit(code, prefix = nil)
  warn prefix if prefix
  warn '' if prefix
  $stderr.write HELP_TEXT
  exit code
end

def parse_args(argv)
  opt = Options.new
  files = []
  argv.each do |arg|
    case arg
    when '-'
      files << '-'
    when '-h', '--help'
      puts HELP_TEXT
      exit 0
    when '-V', '--version'
      puts VERSION_TEXT
      exit 0
    when '-b', '--border' then opt.border = true
    when '-i', '--invert' then opt.invert = true
    when '-x', '--flipx' then opt.flipx = true
    when '-y', '--flipy' then opt.flipy = true
    when '-f', '--term-fit' then opt.term_fit = true
    when '-z', '--term-zoom', '--zoom' then opt.term_zoom = true
    when '-d', '--debug' then # accepted, no-op for local files
    when '-v', '--verbose' then opt.verbose = true
    when '--clear' then opt.clear = true
    when '--colors', '--color' then opt.colors = true
    when '--fill', '--html-fill' then opt.fill = true
    when '--grayscale' then opt.grayscale = true
    when '--html' then opt.html = true
    when '--html-raw' then opt.html_raw = true
    when '--html-no-bold' then opt.html_bold = false
    when '--term-width' then opt.term_width = true
    when '--term-height' then opt.term_height = true
    when /^--width=(\d+)$/ then opt.width = Regexp.last_match(1).to_i
    when /^--height=(\d+)$/ then opt.height = Regexp.last_match(1).to_i
    when /^--size=(\d+)x(\d+)$/
      opt.width = Regexp.last_match(1).to_i
      opt.height = Regexp.last_match(2).to_i
    when /^--chars=(.*)$/ then opt.chars = Regexp.last_match(1)
    when /^--output=(.*)$/ then opt.output = Regexp.last_match(1)
    when /^--html-title=(.*)$/ then opt.html_title = Regexp.last_match(1)
    when /^--html-fontsize=(\d+)$/ then opt.html_fontsize = Regexp.last_match(1).to_i
    when /^--red=([+-]?[0-9.]+)$/ then opt.red = Regexp.last_match(1).to_f
    when /^--green=([+-]?[0-9.]+)$/ then opt.green = Regexp.last_match(1).to_f
    when /^--blue=([+-]?[0-9.]+)$/ then opt.blue = Regexp.last_match(1).to_f
    when '--background=dark' then opt.invert = false
    when '--background=light' then opt.invert = true
    when /^-/
      help_and_exit(1, "Unknown option #{arg}")
    else
      files << arg
    end
  end
  [opt, files]
end

def decode_jpeg(path)
  helper = File.expand_path('jpegdump', __dir__)
  stdout, stderr, status = Open3.capture3(helper, path)
  unless status.success?
    raise stderr.empty? ? 'Cannot decode JPEG image.' : stderr.strip
  end
  nl = stdout.index("\n") or raise 'Invalid decoder output.'
  w, h = stdout[0...nl].split.map(&:to_i)
  [w, h, stdout.byteslice(nl + 1, stdout.bytesize - nl - 1)]
end

def terminal_size
  raise 'Environment variable TERM not set.' if ENV['TERM'].to_s.empty?

  if ENV['COLUMNS'].to_i.positive? && ENV['LINES'].to_i.positive?
    return [ENV['COLUMNS'].to_i, ENV['LINES'].to_i]
  end
  size = `stty size 2>/dev/null`.split.map(&:to_i)
  return [size[1], size[0]] if size.length == 2 && size[0].positive? && size[1].positive?

  [80, 24]
end

def dimensions(opt, iw, ih)
  if opt.term_zoom
    tw, th = terminal_size
    return [tw, th]
  elsif opt.term_width
    tw, = terminal_size
    return [tw, [(tw * ih / iw.to_f) / 2.0, 1].max.floor]
  elsif opt.term_height
    _, th = terminal_size
    return [[th * iw / ih.to_f * 2.0, 1].max.floor, th]
  elsif opt.term_fit || (!opt.width && !opt.height)
    tw, th = terminal_size
    w = tw
    h = [(w * ih / iw.to_f) / 2.0, 1].max.floor
    if h > th
      h = th
      w = [h * iw / ih.to_f * 2.0, 1].max.floor
    end
    return [w, h]
  elsif opt.width && opt.height
    return [opt.width, opt.height]
  elsif opt.width
    return [opt.width, [(opt.width * ih / iw.to_f) / 2.0, 1].max.floor]
  elsif opt.height
    return [[opt.height * iw / ih.to_f * 2.0, 1].max.floor, opt.height]
  end
end

def pixel_at(rgb, iw, x, y)
  off = (y * iw + x) * 3
  [rgb.getbyte(off), rgb.getbyte(off + 1), rgb.getbyte(off + 2)]
end

def pixel_area(rgb, iw, ih, col, row, ow, oh)
  x0 = [(col * iw / ow.to_f).floor, iw - 1].min
  x1 = [(((col + 1) * iw / ow.to_f).ceil - 1), iw - 1].min
  y0 = [(row * ih / oh.to_f).floor, ih - 1].min
  y1 = [(((row + 1) * ih / oh.to_f).ceil - 1), ih - 1].min
  sr = sg = sb = count = 0
  y0.upto(y1) do |y|
    x0.upto(x1) do |x|
      off = (y * iw + x) * 3
      sr += rgb.getbyte(off)
      sg += rgb.getbyte(off + 1)
      sb += rgb.getbyte(off + 2)
      count += 1
    end
  end
  [sr / count, sg / count, sb / count]
end

def ansi_color(r, g, b, background: false)
  "\e[#{background ? 48 : 38};2;#{r};#{g};#{b}m"
end

def render_plain(opt, iw, ih, rgb)
  ow, oh = dimensions(opt, iw, ih)
  chars = opt.chars
  raise 'You must specify at least two characters in --chars.' if chars.length < 2
  rows = []
  ys = (0...oh).to_a
  xs = (0...ow).to_a
  ys.reverse! if opt.flipy
  xs.reverse! if opt.flipx
  ys.each do |row|
      line = +''
      xs.each do |col|
      r, g, b = pixel_area(rgb, iw, ih, col, row, ow, oh)
      lum = r * opt.red + g * opt.green + b * opt.blue
      lum = 255.0 - lum if opt.invert
      idx = (lum * (chars.length - 1) / 255.0).round
      ch = chars[[[idx, 0].max, chars.length - 1].min]
      if opt.colors && !opt.html
        cr, cg, cb = opt.grayscale ? [lum.to_i] * 3 : [r, g, b]
        line << ansi_color(cr, cg, cb)
        line << ansi_color(cr, cg, cb, background: true) if opt.fill
        line << ch
      else
        line << ch
      end
    end
    line << "\e[0m" if opt.colors && !opt.html
    rows << line
  end
  if opt.border
    plain_width = ow
    rows = ["+#{'-' * plain_width}+"] + rows.map { |r| "|#{r}|" } + ["+#{'-' * plain_width}+"]
  end
  rows.join("\n") + "\n"
end

def html_wrap(opt, body)
  return body if opt.html_raw
  bg = opt.invert ? 'white' : 'black'
  fg = opt.invert ? 'black' : 'white'
  weight = opt.html_bold ? "   font-weight: bold;\n" : ''
  <<~HTML
    <?xml version='1.0' encoding='ISO-8859-1'?>
    <!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'  'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
    <html xmlns='http://www.w3.org/1999/xhtml' lang='en' xml:lang='en'>
    <head>
    <title>#{CGI.escapeHTML(opt.html_title)}</title>
    <style type='text/css'>
    body {
    background-color: #{bg};
    }
    .ascii {
       font-family: Courier;
       color: #{fg};
       font-size:#{opt.html_fontsize}pt;
    #{weight}}
    </style>
    </head>
    <body>
    <div class='ascii'><pre>
    #{body}</pre>
    </div>
    </body>
    </html>
  HTML
end

def render(opt, iw, ih, rgb)
  art = render_plain(opt, iw, ih, rgb)
  return art unless opt.html
  return html_wrap(opt, CGI.escapeHTML(art)) unless opt.colors

  # Color HTML output keeps the same sampling as text output, adding spans.
  ow, oh = dimensions(opt, iw, ih)
  xs_base = (0...ow).to_a
  ys_base = (0...oh).to_a
  xs_base.reverse! if opt.flipx
  ys_base.reverse! if opt.flipy
  rows = []
  ys_base.each do |row|
    line = +''
    xs_base.each do |col|
      r, g, b = pixel_area(rgb, iw, ih, col, row, ow, oh)
      lum = r * opt.red + g * opt.green + b * opt.blue
      lum = 255.0 - lum if opt.invert
      idx = (lum * (opt.chars.length - 1) / 255.0).round
      ch = CGI.escapeHTML(opt.chars[[[idx, 0].max, opt.chars.length - 1].min])
      cr, cg, cb = opt.grayscale ? [lum.to_i] * 3 : [r, g, b]
      style = "color: rgb(#{cr},#{cg},#{cb})"
      style << "; background-color: rgb(#{cr},#{cg},#{cb})" if opt.fill
      line << "<span style='#{style}'>#{ch}</span>"
    end
    rows << line
  end
  html_wrap(opt, rows.join("\n") + "\n")
end

begin
  opt, files = parse_args(ARGV)
  if files.empty?
    warn 'No files specified.'
    warn ''
    $stderr.write HELP_TEXT
    exit 1
  end
  if opt.chars.length < 2
    warn 'You must specify at least two characters in --chars.'
    exit 1
  end

  out = +''
  files.each do |file|
    path = file
    tmp = nil
    if file == '-'
      tmp = Tempfile.new(['jp2a-stdin', '.jpg'])
      tmp.binmode
      tmp.write STDIN.binmode.read
      tmp.close
      path = tmp.path
    elsif file =~ %r{\A[a-z]+://}i
      warn "Could not download #{file}: URL support unavailable in this build."
      exit 1
    end
    warn "Reading #{file}" if opt.verbose
    iw, ih, rgb = decode_jpeg(path)
    out << "\e[H\e[J" if opt.clear
    out << render(opt, iw, ih, rgb)
    tmp&.unlink
  end
  if opt.output && opt.output != '-'
    File.binwrite(opt.output, out)
  else
    STDOUT.binmode.write(out)
  end
rescue => e
  warn e.message
  exit 1
end
