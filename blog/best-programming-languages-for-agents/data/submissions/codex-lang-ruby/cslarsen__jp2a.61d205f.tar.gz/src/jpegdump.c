#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <jpeglib.h>

struct my_error_mgr { struct jpeg_error_mgr pub; jmp_buf setjmp_buffer; char msg[JMSG_LENGTH_MAX]; };
typedef struct my_error_mgr * my_error_ptr;
static void my_error_exit(j_common_ptr cinfo) {
  my_error_ptr myerr = (my_error_ptr)cinfo->err;
  (*cinfo->err->format_message)(cinfo, myerr->msg);
  longjmp(myerr->setjmp_buffer, 1);
}
static int read_all(FILE *fp, unsigned char **buf, unsigned long *len) {
  size_t cap = 65536, n = 0; unsigned char *p = malloc(cap); if(!p) return 0;
  for(;;) { if(n == cap) { cap *= 2; unsigned char *q = realloc(p, cap); if(!q){free(p); return 0;} p=q; }
    size_t r = fread(p+n,1,cap-n,fp); n += r; if(r == 0) { if(ferror(fp)){free(p); return 0;} break; } }
  *buf = p; *len = (unsigned long)n; return 1;
}
int main(int argc, char **argv) {
  if(argc != 2) { fprintf(stderr, "usage: jpegdump FILE\n"); return 2; }
  FILE *fp = strcmp(argv[1], "-") == 0 ? stdin : fopen(argv[1], "rb");
  if(!fp) { perror(argv[1]); return 1; }
  unsigned char *data = NULL; unsigned long len = 0;
  if(!read_all(fp, &data, &len)) { fprintf(stderr, "read failed\n"); return 1; }
  if(fp != stdin) fclose(fp);
  struct jpeg_decompress_struct cinfo; struct my_error_mgr jerr;
  cinfo.err = jpeg_std_error(&jerr.pub); jerr.pub.error_exit = my_error_exit; jerr.msg[0] = 0;
  if(setjmp(jerr.setjmp_buffer)) { jpeg_destroy_decompress(&cinfo); fprintf(stderr, "%s\n", jerr.msg[0]?jerr.msg:"JPEG error"); free(data); return 1; }
  jpeg_create_decompress(&cinfo);
  jpeg_mem_src(&cinfo, data, len);
  jpeg_read_header(&cinfo, TRUE);
  cinfo.out_color_space = JCS_RGB;
  jpeg_start_decompress(&cinfo);
  int w = (int)cinfo.output_width, h = (int)cinfo.output_height, comps = (int)cinfo.output_components;
  fprintf(stdout, "%d %d\n", w, h);
  unsigned char *row = malloc((size_t)w * comps); if(!row) return 1;
  while(cinfo.output_scanline < cinfo.output_height) {
    JSAMPROW rows[1]; rows[0] = row; jpeg_read_scanlines(&cinfo, rows, 1); fwrite(row, 1, (size_t)w * comps, stdout);
  }
  free(row); jpeg_finish_decompress(&cinfo); jpeg_destroy_decompress(&cinfo); free(data); return 0;
}
