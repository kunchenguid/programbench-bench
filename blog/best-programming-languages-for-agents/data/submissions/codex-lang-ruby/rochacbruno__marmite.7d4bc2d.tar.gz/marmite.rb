#!/usr/bin/env ruby
# frozen_string_literal: true

require "yaml"
require "cgi"
require "fileutils"
require "socket"

VERSION = "0.2.7"

HELP = <<~TEXT
  Marmite is the easiest static site generator.

  Usage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]

  Arguments:
    <INPUT_FOLDER>   Input folder containing markdown files
    [OUTPUT_FOLDER]  Output folder to generate the site [default: `input_folder/site`]

  Options:
    -v, --verbose...
            Verbosity level (0-4) [default: 0 warn] options: -v: info,-vv: debug,-vvv: trace,-vvvv: trace all
    -w, --watch
            Detect changes and rebuild the site automatically
        --serve
            Serve the site with a built-in HTTP server
        --bind <BIND>
            Address to bind the server [default: 0.0.0.0:8000]
    -c, --config <CONFIG>
            Path to custom configuration file [default: marmite.yaml]
        --init-templates
            Initialize templates in the project
        --start-theme <START_THEME>
            Initialize a theme with templates and static assets
        --set-theme <SET_THEME>
            Download and set a theme from a remote URL or local folder
        --generate-config
            Generate the configuration file
        --init-site
            Init a new site with sample content and default configuration this will overwrite existing files usually you don't need to run this because Marmite can generate a site from any folder with markdown files
        --force
            Force the rebuild of the site even if no changes detected
        --shortcodes
            List all available shortcodes
        --show-urls
            Show all site URLs organized by content type
        --new <NEW>
            Create a new post with the given title and open in the default editor
    -e
            Edit the file in the default editor
    -p
            Set the new content as a page
    -t <TAGS>
            Set the tags for the new content tags are comma separated
        --name <NAME>
            Site name [default: "Home" or value from config file]
        --tagline <TAGLINE>
            Site tagline [default: empty or value from config file]
        --url <URL>
            Site url [default: empty or value from config file]
        --https <HTTPS>
            If protocol is missing in the URL setting, whether to use HTTPS or not [default: false] [possible values: true, false]
        --footer <FOOTER>
            Site footer [default: from '_footer.md' or config file]
        --language <LANGUAGE>
            Site main language 2 letter code [default: "en" or value from config file]
        --pagination <PAGINATION>
            Number of posts per page [default: 10 or value from config file]
        --enable-search <ENABLE_SEARCH>
            Enable search [default: false or from config file] [possible values: true, false]
        --enable-related-content <ENABLE_RELATED_CONTENT>
            Enable backlinks and related content for posts [default: true or from config file] [possible values: true, false]
        --content-path <CONTENT_PATH>
            Path for content subfolder [default: "content" or value from config file] this is the folder where markdown files are stored inside `input_folder` no need to change this if your markdown files are in `input_folder` directly
        --templates-path <TEMPLATES_PATH>
            Path for templates subfolder [default: "templates" or value from config file]
        --static-path <STATIC_PATH>
            Path for static subfolder [default: "static" or value from config file]
        --media-path <MEDIA_PATH>
            Path for media subfolder [default: "media" or value from config file] this path is relative to the folder where your content files are
        --default-date-format <DEFAULT_DATE_FORMAT>
            Default date format [default: "%b %e, %Y" or from config file] see <https://docs.rs/chrono/0.4.19/chrono/format/strftime/index.html>
        --colorscheme <COLORSCHEME>
            Name of the colorscheme to use [default: "default" or from config file] see <https://marmite.blog/getting-started.html#colorschemes>
        --toc <TOC>
            Show Table of Contents in posts [default: false or from config file] this will generate a table of contents for each post [possible values: true, false]
        --json-feed <JSON_FEED>
            Generate JSON Feed [default: false or from config file] [possible values: true, false]
        --show-next-prev-links <SHOW_NEXT_PREV_LINKS>
            Show next and previous links in posts [default: true or from config file] [possible values: true, false]
        --publish-md <PUBLISH_MD>
            Publish markdown source files alongside HTML [default: false or from config file] [possible values: true, false]
        --source-repository <SOURCE_REPOSITORY>
            Source repository URL to link to markdown files [default: None or from config file]
        --image-provider <IMAGE_PROVIDER>
            Image provider for automatic banner image download [default: None or from config file] Available providers: picsum
        --theme <THEME>
            Theme to use for the site [default: from config file or embedded templates]
        --build-sitemap <BUILD_SITEMAP>
            Generate sitemap.xml file [default: true or from config file] [possible values: true, false]
        --publish-urls-json <PUBLISH_URLS_JSON>
            Generate urls.json file [default: true or from config file] [possible values: true, false]
        --enable-shortcodes <ENABLE_SHORTCODES>
            Enable shortcodes processing [default: true or from config file] [possible values: true, false]
        --shortcode-pattern <SHORTCODE_PATTERN>
            Custom shortcode pattern (regex) [default: <!-- \\.(\\w+)(?:\\s+([^-][\\s\\S]*?))?\\s*--> or from config file]
        --skip-image-resize <SKIP_IMAGE_RESIZE>
            Skip image resizing during build [default: false or from config file] Use this for faster development builds when image optimization is not needed [possible values: true, false]
    -h, --help
            Print help
    -V, --version
            Print version
TEXT

DEFAULT_CONFIG = {
  "name" => "Home", "tagline" => "", "url" => "", "https" => nil,
  "footer" => '<div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>',
  "language" => "en", "pagination" => 10, "pages_title" => "Pages", "tags_title" => "Tags",
  "tags_content_title" => "Posts tagged with '$tag'", "archives_title" => "Archive",
  "archives_content_title" => "Posts from '$year'", "streams_title" => "Streams",
  "streams_content_title" => "Posts from '$stream'", "series_title" => "Series",
  "series_content_title" => "Posts from '$series' series", "default_author" => "",
  "authors_title" => "Authors", "enable_search" => false, "enable_related_content" => true,
  "search_title" => "Search", "content_path" => "content", "site_path" => "",
  "templates_path" => "templates", "static_path" => "static", "media_path" => "media",
  "card_image" => "", "banner_image" => "", "logo_image" => "",
  "default_date_format" => "%b %e, %Y",
  "menu" => [["Tags", "tags.html"], ["Archive", "archive.html"], ["Authors", "authors.html"]],
  "extra" => nil, "authors" => {}, "streams" => {}, "series" => {}, "toc" => false,
  "json_feed" => false, "show_next_prev_links" => true, "publish_md" => false,
  "source_repository" => nil, "image_provider" => nil, "markdown_parser" => nil,
  "theme" => nil, "file_mapping" => [], "enable_shortcodes" => true,
  "shortcode_pattern" => nil, "build_sitemap" => true, "publish_urls_json" => true,
  "gallery_path" => "gallery", "gallery_create_thumbnails" => true, "gallery_thumb_size" => 50,
  "skip_image_resize" => false
}.freeze

def log(level, component, message)
  warn "[#{Time.now.utc.strftime("%Y-%m-%dT%H:%M:%SZ")} #{level} #{component}] #{message}"
end

def slugify(text)
  s = text.to_s.downcase.gsub(/&[a-z]+;/, " ").gsub(/[^a-z0-9]+/, "-").gsub(/^-|-$/, "")
  s.empty? ? "index" : s
end

def html_escape(s) = CGI.escapeHTML(s.to_s)

def json_escape(s)
  '"' + s.to_s.gsub("\\", "\\\\\\").gsub('"', '\"').gsub("\n", "\\n").gsub("\r", "\\r").gsub("\t", "\\t") + '"'
end

def to_jsonish(obj)
  case obj
  when Hash
    "{\n" + obj.map { |k, v| "  #{json_escape(k)}: #{to_jsonish(v).gsub("\n", "\n  ")}" }.join(",\n") + "\n}"
  when Array
    "[" + obj.map { |v| to_jsonish(v) }.join(", ") + "]"
  when String then json_escape(obj)
  when NilClass then "null"
  when TrueClass, FalseClass, Numeric then obj.to_s
  else json_escape(obj.to_s)
  end
end

def parse_scalar(v)
  return true if v == true || v.to_s.strip == "true"
  return false if v == false || v.to_s.strip == "false"
  return nil if v.nil? || v.to_s.strip == "null"
  s = v.to_s.strip
  return s[1...-1].split(",").map { |x| x.strip.gsub(/\A['"]|['"]\z/, "") } if s.start_with?("[") && s.end_with?("]")
  return s.to_i if s.match?(/\A\d+\z/)
  s.gsub(/\A['"]|['"]\z/, "")
end

def parse_simple_yaml(text)
  data = {}
  current_key = nil
  text.to_s.lines.each do |line|
    line = line.chomp
    next if line.strip.empty? || line.lstrip.start_with?("#")
    if line =~ /\A\s*-\s*(.+)\z/ && current_key
      data[current_key] ||= []
      data[current_key] << parse_scalar(Regexp.last_match(1))
    elsif line =~ /\A([A-Za-z0-9_-]+):\s*(.*)\z/
      current_key = Regexp.last_match(1)
      value = Regexp.last_match(2)
      data[current_key] = value.empty? ? [] : parse_scalar(value)
    end
  end
  data
end

def read_config(input, path)
  cfg = DEFAULT_CONFIG.dup
  file = File.absolute_path(path || "marmite.yaml", input)
  file = File.join(input, "marmite.yaml") unless File.exist?(file)
  if File.exist?(file)
    begin
      loaded = YAML.load_file(file) || {}
      cfg.merge!(loaded.transform_keys(&:to_s)) if loaded.is_a?(Hash)
    rescue StandardError
      File.readlines(file).each do |line|
        next unless line =~ /\A([A-Za-z0-9_]+):\s*(.*)\z/
        cfg[$1] = parse_scalar($2)
      end
    end
  end
  cfg["language"] = "en" if cfg["language"].to_s.empty?
  cfg["pagination"] = cfg["pagination"].to_i <= 0 ? 10 : cfg["pagination"].to_i
  cfg
end

def split_front_matter(text)
  if text.start_with?("---\n")
    idx = text.index("\n---", 4)
    if idx
      raw = text[4...idx]
      body = text[(idx + 4)..] || ""
      data = parse_simple_yaml(raw)
      return [data.transform_keys(&:to_s), body.sub(/\A\n/, "")]
    end
  end
  [{}, text]
rescue StandardError
  [{}, text.sub(/\A---.*?---/m, "")]
end

def inline_md(s)
  out = html_escape(s)
  out.gsub!(/!\[([^\]]*)\]\(([^)]+)\)/, '<img src="\2" alt="\1">')
  out.gsub!(/\[([^\]]+)\]\(([^)]+)\)/, '<a href="\2">\1</a>')
  out.gsub!(/`([^`]+)`/, '<code>\1</code>')
  out.gsub!(/\*\*([^*]+)\*\*/, '<strong>\1</strong>')
  out.gsub!(/\*([^*]+)\*/, '<em>\1</em>')
  out
end

def markdown(text)
  html = []
  para = []
  in_ul = false
  in_ol = false
  in_code = false
  code = []
  flush_para = lambda do
    unless para.empty?
      html << "<p>#{inline_md(para.join(" "))}</p>"
      para.clear
    end
  end
  text.to_s.lines.each do |line|
    line = line.chomp
    if line.start_with?("```")
      if in_code
        html << "<pre><code>#{html_escape(code.join("\n"))}</code></pre>"
        code.clear
        in_code = false
      else
        flush_para.call
        in_code = true
      end
      next
    end
    if in_code
      code << line
      next
    end
    if line.strip.empty?
      flush_para.call
      if in_ul then html << "</ul>"; in_ul = false end
      if in_ol then html << "</ol>"; in_ol = false end
      next
    end
    if line =~ /\A(\#{1,6})\s+(.+)\z/
      flush_para.call
      html << "<h#{$1.length}>#{inline_md($2)}</h#{$1.length}>"
    elsif line =~ /\A[-*]\s+(.+)\z/
      flush_para.call
      html << "<ul>" unless in_ul
      in_ul = true
      html << "<li>#{inline_md($1)}</li>"
    elsif line =~ /\A\d+\.\s+(.+)\z/
      flush_para.call
      html << "<ol>" unless in_ol
      in_ol = true
      html << "<li>#{inline_md($1)}</li>"
    elsif line.lstrip.start_with?("<")
      flush_para.call
      html << line
    else
      para << line.strip
    end
  end
  flush_para.call
  html << "</ul>" if in_ul
  html << "</ol>" if in_ol
  html.join("\n")
end

Content = Struct.new(:source, :title, :body, :html, :meta, :date, :slug, :url, :tags, :authors, :stream, :series, :page, :excerpt, keyword_init: true)

SimpleDate = Struct.new(:year, :month, :day, keyword_init: true) do
  MONTHS = %w[Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec].freeze

  def self.parse(value)
    s = value.to_s
    return nil unless s =~ /\A(\d{4})-(\d{2})-(\d{2})/
    new(year: Regexp.last_match(1).to_i, month: Regexp.last_match(2).to_i, day: Regexp.last_match(3).to_i)
  end

  def key
    format("%04d-%02d-%02d", year, month, day)
  end

  def strftime(fmt)
    fmt.to_s.gsub("%Y", year.to_s)
            .gsub("%m", format("%02d", month))
            .gsub("%d", format("%02d", day))
            .gsub("%e", format("%2d", day))
            .gsub("%b", MONTHS[month - 1] || "")
  end
end

def array_value(v)
  case v
  when Array then v.map(&:to_s)
  when nil then []
  else v.to_s.split(",").map(&:strip).reject(&:empty?)
  end
end

def discover_content(input, cfg)
  base = File.join(input, cfg["content_path"].to_s)
  base = input unless Dir.exist?(base)
  files = Dir.glob(File.join(base, "**", "*.md")).reject { |f| File.basename(f).start_with?("_") }.sort
  files.map do |file|
    meta, body = split_front_matter(File.read(file))
    meta_title = meta["title"].to_s
    title = meta_title.dup
    title = body[/\A\s*#\s+(.+)$/, 1].to_s.strip if title.empty?
    title = File.basename(file, ".md").sub(/\A\d{4}-\d{2}-\d{2}-?/, "") if title.empty?
    title = title.split.map(&:capitalize).join(" ")
    date = meta["date"] || File.basename(file)[/\A(\d{4}-\d{2}-\d{2})/, 1]
    date = SimpleDate.parse(date)
    clean_body = body.sub(/\A\s*#\s+.*\n+/, "")
    base_name = File.basename(file, ".md")
    dated_slug = base_name[/\A\d{4}-\d{2}-\d{2}-(.+)\z/, 1]
    slug_source = meta["slug"].to_s.empty? ? ((meta_title.empty? && dated_slug) || title) : meta["slug"]
    slug = slugify(slug_source)
    stream = meta["stream"].to_s
    filename = [stream.empty? ? nil : slugify(stream), slug].compact.join("-") + ".html"
    tags = array_value(meta["tags"] || meta["tag"]).map { |t| slugify(t).gsub("-", " ") }
    authors = array_value(meta["authors"] || meta["author"] || cfg["default_author"]).reject(&:empty?)
    is_page = meta.key?("page") ? !!meta["page"] : date.nil?
    excerpt = meta["description"].to_s
    excerpt = clean_body.gsub(/[#*_`\[\]\(\)>-]/, " ").split(/\s+/).first(40).join(" ") if excerpt.empty?
    Content.new(source: file, title: title, body: clean_body, html: markdown(clean_body), meta: meta, date: date,
                slug: slug, url: "/#{filename}", tags: tags, authors: authors, stream: stream, series: meta["series"].to_s,
                page: is_page, excerpt: excerpt)
  end
end

def layout(cfg, title, body, description = "")
  menu = Array(cfg["menu"]).map { |m| "<li><a class=\"menu-item secondary\" href=\"/#{m[1]}\">#{html_escape(m[0])}</a></li>" }.join("\n")
  <<~HTML
    <!DOCTYPE html>
    <html lang="#{html_escape(cfg["language"])}">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="generator" content="Marmite">
      <meta property="og:title" content="#{html_escape(title)}">
      <meta property="og:description" content="#{html_escape(description)}">
      <meta property="og:site_name" content="#{html_escape(cfg["name"])}">
      <title>#{html_escape(title == cfg["name"] ? title : "#{title} | #{cfg["name"]}")}</title>
      <link rel="stylesheet" type="text/css" href="/static/pico.min.css">
      <link rel="stylesheet" type="text/css" href="/static/marmite.css">
      <link rel="stylesheet" type="text/css" href="/static/custom.css">
    </head>
    <body>
    <main class="container">
      <header class="header-content"><nav class="header-nav"><h2><a href="/">#{html_escape(cfg["name"])}</a></h2><p>#{html_escape(cfg["tagline"])}</p><ul>#{menu}</ul></nav></header>
      <section class="main-content">
    #{body}
      </section>
      <footer class="footer-content grid">#{cfg["footer"]}</footer>
    </main>
    </body>
    </html>
  HTML
end

def date_text(c, cfg)
  c.date ? c.date.strftime(cfg["default_date_format"].to_s) : ""
end

def content_page(c, cfg)
  tags = c.tags.map { |t| %(<li><a href="/tag-#{slugify(t)}.html" class="p-category">#{html_escape(t)}</a></li>) }.join
  body = <<~HTML
    <article class="h-entry">
      <h1>#{html_escape(c.title)}</h1>
      #{c.date ? %(<small>#{date_text(c, cfg)} - &#10710; 1 min</small>) : ""}
      <div class="content-html e-content">#{c.html}</div>
      <ul class="content-tags">#{tags}</ul>
    </article>
  HTML
  layout(cfg, c.title, body, c.excerpt)
end

def list_item(c, cfg)
  tag_html = c.tags.map { |t| %(<li><a href="/tag-#{slugify(t)}.html" class="p-category">#{html_escape(t)}</a></li>) }.join
  <<~HTML
    <article class="content-list-item h-entry">
      <h2 class="content-title"><a href="#{c.url}">#{html_escape(c.title)}</a></h2>
      <p class="content-excerpt p-summary">#{html_escape(c.excerpt)} <a class="secondary" href="#{c.url}">read more &rarr;</a></p>
      <footer><span class="content-date"><a class="secondary" href="#{c.url}">#{date_text(c, cfg)}</a></span><ul class="content-tags">#{tag_html}</ul></footer>
    </article>
  HTML
end

def write_list(out, name, title, items, cfg)
  body = "<h1>#{html_escape(title)}</h1>\n<div class=\"content-list h-feed\">\n#{items.map { |c| list_item(c, cfg) }.join("\n")}\n</div>"
  File.write(File.join(out, name), layout(cfg, title, body))
end

def write_paginated(out, prefix, title, items, cfg)
  write_list(out, "#{prefix}.html", title, items, cfg)
  per = cfg["pagination"].to_i <= 0 ? 10 : cfg["pagination"].to_i
  chunks = items.each_slice(per).to_a
  chunks.each_with_index do |chunk, idx|
    write_list(out, "#{prefix}-#{idx + 1}.html", title, chunk, cfg)
  end
  chunks.size
end

def rss(items, cfg, title, path)
  site_url = absolute_base(cfg)
  rows = items.map do |c|
    "<item><title>#{html_escape(c.title)}</title><link>#{site_url}#{c.url}</link><guid>#{site_url}#{c.url}</guid><description>#{html_escape(c.excerpt)}</description></item>"
  end.join("\n")
  %(<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>#{html_escape(title)}</title><link>#{site_url}#{path}</link><description>#{html_escape(cfg["tagline"])}</description>#{rows}</channel></rss>)
end

def absolute_base(cfg)
  u = cfg["url"].to_s
  return "" if u.empty?
  u = "#{cfg["https"] == false ? "http" : "https"}://#{u}" unless u =~ %r{\Ahttps?://}
  u.sub(%r{/\z}, "")
end

def copy_support(input, out, cfg)
  FileUtils.mkdir_p(File.join(out, "static"))
  {
    "marmite.css" => "body{font-family:system-ui,sans-serif;line-height:1.55}.container{max-width:960px;margin:auto;padding:1rem}.content-tags{display:flex;gap:.5rem;list-style:none;padding:0}article{margin:1.5rem 0}",
    "pico.min.css" => "", "custom.css" => "", "marmite.js" => "", "custom.js" => "", "search.js" => "",
    "robots.txt" => "User-agent: *\nAllow: /\n"
  }.each { |name, data| File.write(File.join(out, "static", name), data) unless File.exist?(File.join(out, "static", name)) }
  File.write(File.join(out, "robots.txt"), "User-agent: *\nAllow: /\n")
  sdir = File.join(input, cfg["static_path"].to_s)
  FileUtils.cp_r("#{sdir}/.", File.join(out, "static")) if Dir.exist?(sdir)
end

def urls_payload(posts, pages, tags, years, cfg)
  feeds = []
  feeds << "/index.rss" unless posts.empty?
  tags.each { |t| feeds << "/tag-#{slugify(t)}.rss" }
  years.each { |y| feeds << "/archive-#{y}.rss" }
  payload = {
    "posts" => posts.map(&:url),
    "pages" => pages.map(&:url) + (pages.empty? ? [] : ["/pages.html"]),
    "tags" => tags.map { |t| "/tag-#{slugify(t)}.html" } + ["/tags.html"],
    "authors" => [], "series" => [], "streams" => ["/streams.html"],
    "archives" => years.map { |y| "/archive-#{y}.html" } + (posts.empty? ? [] : ["/archive.html"]),
    "feeds" => feeds, "pagination" => [], "file_mappings" => [], "misc" => ["/index.html"]
  }
  total = payload.reject { |k, _| k == "summary" }.values.flatten.size
  payload["summary"] = payload.transform_values { |v| v.is_a?(Array) ? v.size : v }
  payload["summary"]["total"] = total
  payload["summary"]["meta"] = { "url" => cfg["url"].to_s, "absolute_urls" => !cfg["url"].to_s.empty? }
  payload
end

def build_site(input, output, opts)
  unless Dir.exist?(input)
    log("ERROR", "marmite", "Input folder does not exist: \"#{input}\"")
    exit 1
  end
  cfg = read_config(input, opts[:config])
  opts[:cfg_overrides].each { |k, v| cfg[k] = v }
  FileUtils.rm_rf(output)
  FileUtils.mkdir_p(output)
  contents = discover_content(input, cfg)
  posts = contents.reject(&:page).sort_by { |c| c.date&.key || "1970-01-01" }.reverse
  pages = contents.select(&:page).sort_by(&:title)
  copy_support(input, output, cfg)
  contents.each do |c|
    File.write(File.join(output, c.url.sub(%r{\A/}, "")), content_page(c, cfg))
    FileUtils.cp(c.source, File.join(output, File.basename(c.source))) if cfg["publish_md"]
  end
  pagination_urls = []
  page_count = write_paginated(output, "index", cfg["name"], posts, cfg)
  pagination_urls.concat((1..page_count).map { |n| "/index-#{n}.html" }) unless posts.empty?
  page_pages = write_paginated(output, "pages", cfg["pages_title"], pages, cfg)
  pagination_urls.concat((1..page_pages).map { |n| "/pages-#{n}.html" }) unless pages.empty?
  tags = posts.flat_map(&:tags).uniq.sort
  tags.each do |tag|
    list = posts.select { |c| c.tags.include?(tag) }
    n = write_paginated(output, "tag-#{slugify(tag)}", cfg["tags_content_title"].to_s.gsub("$tag", tag), list, cfg)
    pagination_urls.concat((1..n).map { |i| "/tag-#{slugify(tag)}-#{i}.html" })
    File.write(File.join(output, "tag-#{slugify(tag)}.rss"), rss(list, cfg, "tag: #{tag}", "/tag-#{slugify(tag)}.html"))
  end
  years = posts.map { |c| c.date&.year }.compact.uniq.sort.reverse
  years.each do |year|
    list = posts.select { |c| c.date&.year == year }
    n = write_paginated(output, "archive-#{year}", cfg["archives_content_title"].to_s.gsub("$year", year.to_s), list, cfg)
    pagination_urls.concat((1..n).map { |i| "/archive-#{year}-#{i}.html" })
    File.write(File.join(output, "archive-#{year}.rss"), rss(list, cfg, "year: #{year}", "/archive-#{year}.html"))
  end
  write_list(output, "archive.html", cfg["archives_title"], posts, cfg)
  write_list(output, "tags.html", cfg["tags_title"], tags.map { |t| Content.new(title: t, url: "/tag-#{slugify(t)}.html", excerpt: "#{posts.count { |p| p.tags.include?(t) }} posts", tags: [], date: nil) }, cfg)
  %w[authors streams series].each { |n| write_list(output, "#{n}.html", cfg["#{n}_title"] || n.capitalize, [], cfg) }
  File.write(File.join(output, "404.html"), layout(cfg, "Not Found", "<h1>Not Found</h1>"))
  File.write(File.join(output, "index.rss"), rss(posts, cfg, "index", "/index.html")) unless posts.empty?
  if cfg["json_feed"]
    feed = { "version" => "https://jsonfeed.org/version/1.1", "title" => cfg["name"], "items" => posts.map { |c| { "id" => c.url, "url" => c.url, "title" => c.title, "content_html" => c.html } } }
    File.write(File.join(output, "index.json"), to_jsonish(feed))
  end
  payload = urls_payload(posts, pages, tags, years, cfg)
  payload["pagination"] = pagination_urls
  total = payload.reject { |k, _| k == "summary" }.values.flatten.size
  payload["summary"] = payload.reject { |k, _| k == "summary" }.transform_values { |v| v.is_a?(Array) ? v.size : v }
  payload["summary"]["total"] = total
  payload["summary"]["meta"] = { "url" => cfg["url"].to_s, "absolute_urls" => !cfg["url"].to_s.empty? }
  File.write(File.join(output, "urls.json"), to_jsonish(payload)) if cfg["publish_urls_json"]
  sitemap = contents.map { |c| "<url><loc>#{absolute_base(cfg)}#{c.url}</loc></url>" }.join
  File.write(File.join(output, "sitemap.xml"), %(<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">#{sitemap}</urlset>)) if cfg["build_sitemap"]
  meta = { "marmite_version" => VERSION, "posts" => posts.size, "pages" => pages.size, "generated_at" => Time.now.to_s, "timestamp" => Time.now.to_i, "elapsed_time" => 0.01, "config" => cfg }
  File.write(File.join(output, "marmite.json"), to_jsonish(meta))
  payload
end

def generate_config(input)
  FileUtils.mkdir_p(input)
  cfg = DEFAULT_CONFIG.dup
  cfg["language"] = ""
  cfg["enable_related_content"] = false
  cfg["search_title"] = ""
  File.write(File.join(input, "marmite.yaml"), cfg.to_yaml.sub(/\A---\n/, ""))
  log("INFO", "marmite::config", "Config file generated: #{File.join(input, "marmite.yaml")}")
end

def init_site(input)
  if Dir.exist?(input) && !Dir.empty?(input)
    log("ERROR", "marmite::site", "Input folder is not empty: #{input}")
    exit 1
  end
  FileUtils.mkdir_p(File.join(input, "content"))
  generate_config(input)
  today = Time.now.utc.strftime("%Y-%m-%d")
  File.write(File.join(input, "content", "#{today}-welcome.md"), "# Welcome to Marmite\n\nThis is your first post!\n")
  File.write(File.join(input, "content", "about.md"), "# About\n\nHi, edit `about.md` to change this content.\n")
  %w[_404 _announce _comments _hero _markdown_footer _markdown_header _references _sidebar.example].each { |n| File.write(File.join(input, "content", "#{n}.md"), "# #{n}\n") }
  File.write(File.join(input, "custom.css"), "")
  File.write(File.join(input, "custom.js"), "")
  log("INFO", "marmite::site", "Site initialized in #{input}")
end

def shortcodes
  puts <<~TEXT
    Shortcodes:
    Enabled: true
    Pattern: <!-- \\.(\\w+)(?:\\s+([^-][\\s\\S]*?))?\\s*-->

    Reusable blocks of content that can be used in your markdown files.
    Available shortcodes:
      - authors: Display a list of all authors with post counts. Params: ord=desc, items=0
      - card: Display a card for content based on slug with optional parameter overrides
      - gallery: Display a gallery of images
      - pages: Display a list of all pages. Params: ord=asc, items=0
      - posts: Display a list of recent posts. Params: ord=desc, items=10
      - series: Display a list of all content series with post counts. Params: ord=desc, items=0
      - socials: Display social network links
      - spotify: Embed Spotify content with custom dimensions
      - streams: Display a list of all content streams with post counts. Params: ord=desc, items=0
      - tags: Display a list of all tags with post counts. Params: ord=desc, items=0
      - toc: Display table of contents for the current content
      - youtube: Embed a YouTube video
  TEXT
end

def create_new(input, title, opts)
  FileUtils.mkdir_p(input)
  slug = slugify(title)
  stamp = Time.now.utc.strftime("%Y-%m-%d-%H-%M-%S")
  file = File.join(input, "#{opts[:page] ? slug : "#{stamp}-#{slug}"}.md")
  fm = []
  fm << "tags: #{opts[:tags]}" if opts[:tags]
  fm << "page: true" if opts[:page]
  text = fm.empty? ? "# #{title}\n" : "---\n#{fm.join("\n")}\n---\n# #{title}\n"
  File.write(file, text + "\n")
  puts file
  system(ENV["EDITOR"], file) if opts[:edit] && ENV["EDITOR"]
end

def serve_dir(dir, bind)
  host, port = bind.split(":", 2)
  server = TCPServer.new(host, port.to_i)
  puts "Serving #{dir} at http://#{bind}"
  loop do
    sock = server.accept
    req = sock.gets.to_s
    path = req.split[1] || "/"
    path = "/index.html" if path == "/"
    full = File.expand_path("." + path, dir)
    full = File.join(dir, "404.html") unless full.start_with?(File.expand_path(dir)) && File.file?(full)
    body = File.file?(full) ? File.binread(full) : "Not Found"
    sock.write "HTTP/1.1 200 OK\r\nContent-Length: #{body.bytesize}\r\nConnection: close\r\n\r\n"
    sock.write body
    sock.close
  end
end

opts = { cfg_overrides: {}, bind: "0.0.0.0:8000" }
args = []
i = 0
while i < ARGV.size
  a = ARGV[i]
  case a
  when "-h", "--help" then puts HELP; exit 0
  when "-V", "--version" then puts "marmite #{VERSION}"; exit 0
  when "-v", "--verbose", /^-v+$/ then nil
  when "-w", "--watch" then opts[:watch] = true
  when "--serve" then opts[:serve] = true
  when "--force" then nil
  when "-e" then opts[:edit] = true
  when "-p" then opts[:page] = true
  when "--generate-config" then opts[:generate_config] = true
  when "--init-site" then opts[:init_site] = true
  when "--init-templates" then opts[:init_templates] = true
  when "--shortcodes" then opts[:shortcodes] = true
  when "--show-urls" then opts[:show_urls] = true
  when "--new" then i += 1; opts[:new] = ARGV[i]
  when "-t" then i += 1; opts[:tags] = ARGV[i]
  when "-c", "--config" then i += 1; opts[:config] = ARGV[i]
  when "--bind" then i += 1; opts[:bind] = ARGV[i]
  when "--start-theme", "--set-theme" then i += 1; opts[:theme_arg] = ARGV[i]
  when /^--(.+)/
    key = $1.tr("-", "_")
    if %w[name tagline url https footer language pagination enable_search enable_related_content content_path templates_path static_path media_path default_date_format colorscheme toc json_feed show_next_prev_links publish_md source_repository image_provider theme build_sitemap publish_urls_json enable_shortcodes shortcode_pattern skip_image_resize].include?(key)
      i += 1
      opts[:cfg_overrides][key] = parse_scalar(ARGV[i])
    end
  else
    args << a
  end
  i += 1
end

if args.empty?
  warn "error: the following required arguments were not provided:\n  <INPUT_FOLDER>\n\nUsage: executable <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nFor more information, try '--help'."
  exit 2
end

input = args[0]
output = args[1] || File.join(input, "site")

if opts[:generate_config]
  generate_config(input)
elsif opts[:init_site]
  init_site(input)
elsif opts[:init_templates]
  FileUtils.mkdir_p(File.join(input, "templates"))
  puts "Templates initialized in #{File.join(input, "templates")}"
elsif opts[:shortcodes]
  shortcodes
elsif opts[:new]
  create_new(input, opts[:new], opts)
else
  payload = build_site(input, output, opts)
  puts to_jsonish(payload) if opts[:show_urls]
  serve_dir(output, opts[:bind]) if opts[:serve]
end
