#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require 'json'
require 'yaml'
require 'optparse'
require 'open3'
require 'fileutils'
require 'time'

VERSION = 'onefetch 2.25.0'

LANGS = [
  'ABNF', 'ABAP', 'Ada', 'Agda', 'Arduino C++', 'Assembly', 'ATS', 'AutoHotKey',
  'BASH', 'C', 'CMake', 'C#', 'Ceylon', 'Clojure', 'CoffeeScript', 'ColdFusion',
  'Coq', 'C++', 'Crystal', 'CSS', 'CUDA', 'D', 'Dart', 'Dockerfile',
  'Emacs Lisp', 'Elixir', 'Elm', 'Emojicode', 'Erlang', 'F#', 'Fish', 'Forth',
  'FORTRAN Legacy', 'FORTRAN Modern', 'GDScript', 'GLSL', 'Go', 'GraphQL',
  'Groovy', 'Haskell', 'Haxe', 'HCL', 'HLSL', 'HolyC', 'HTML', 'Idris', 'Java',
  'JavaScript', 'JSON', 'Jsonnet', 'JSX', 'Julia', 'Jupyter Notebooks', 'Kotlin',
  'LLVM', 'Lean', 'Common Lisp', 'Lua', 'Makefile', 'Markdown', 'Modelica', 'Nim',
  'Nix', 'OCaml', 'Objective-C', 'Odin', 'OpenSCAD', 'Org', 'Oz', 'Pascal',
  'Perl', 'PHP', 'PowerShell', 'Processing', 'Prolog', 'Protocol Buffers',
  'PureScript', 'Python', 'QML', 'R', 'Racket', 'Raku', 'ReScript', 'Ruby',
  'Rust', 'Sass', 'Scala', 'Scheme', 'Svelte', 'Swift', 'Tcl', 'TeX', 'TOML',
  'TSX', 'Twig', 'TypeScript', 'Vala', 'Vim Script', 'Vue', 'XML', 'YAML', 'Zig'
].freeze

EXT_LANG = {
  '.rb' => 'Ruby', '.gemspec' => 'Ruby',
  '.rs' => 'Rust', '.go' => 'Go', '.py' => 'Python', '.js' => 'JavaScript',
  '.jsx' => 'JSX', '.ts' => 'TypeScript', '.tsx' => 'TSX', '.java' => 'Java',
  '.c' => 'C', '.h' => 'C', '.cpp' => 'C++', '.cc' => 'C++', '.cxx' => 'C++',
  '.hpp' => 'C++', '.cs' => 'C#', '.php' => 'PHP', '.swift' => 'Swift',
  '.kt' => 'Kotlin', '.kts' => 'Kotlin', '.scala' => 'Scala', '.sh' => 'BASH',
  '.bash' => 'BASH', '.zsh' => 'BASH', '.fish' => 'Fish', '.pl' => 'Perl',
  '.pm' => 'Perl', '.r' => 'R', '.R' => 'R', '.lua' => 'Lua', '.ex' => 'Elixir',
  '.exs' => 'Elixir', '.erl' => 'Erlang', '.hrl' => 'Erlang', '.hs' => 'Haskell',
  '.ml' => 'OCaml', '.mli' => 'OCaml', '.clj' => 'Clojure', '.cljs' => 'Clojure',
  '.dart' => 'Dart', '.nim' => 'Nim', '.zig' => 'Zig', '.md' => 'Markdown',
  '.markdown' => 'Markdown', '.html' => 'HTML', '.htm' => 'HTML', '.css' => 'CSS',
  '.scss' => 'Sass', '.sass' => 'Sass', '.json' => 'JSON', '.jsonnet' => 'Jsonnet',
  '.yaml' => 'YAML', '.yml' => 'YAML', '.toml' => 'TOML', '.xml' => 'XML',
  '.proto' => 'Protocol Buffers', '.graphql' => 'GraphQL', '.gql' => 'GraphQL',
  '.vue' => 'Vue', '.svelte' => 'Svelte', '.tex' => 'TeX', '.org' => 'Org'
}.freeze

HELP = <<~HELP
  Command-line Git information tool

  Usage: executable [OPTIONS] [INPUT]

  Arguments:
    [INPUT]
            Run as if onefetch was started in <input> instead of the current working directory

  Options:
    -h, --help          Print help (see a summary with '-h')
    -V, --version       Print version

  INFO:
    -d, --disabled-fields <FIELD>...
            Allows you to disable FIELD(s) from appearing in the output
        --no-title      Hides the title
        --number-of-authors <NUM>
            Maximum NUM of authors to be shown
        --number-of-languages <NUM>
            Maximum NUM of languages to be shown
        --number-of-file-churns <NUM>
            Maximum NUM of file churns to be shown
    -e, --exclude <EXCLUDE>...
            Ignore all files & directories matching EXCLUDE
        --no-bots[=<REGEX>]  Exclude [bot] commits
        --no-merges     Ignores merge commits
    -E, --email         Show the email address of each author
        --include-hidden
            Count hidden files and directories
    -T, --type <TYPE>...
            Filters output by language type

  DEVELOPER:
    -o, --output <FORMAT>
            Outputs Onefetch in a specific format
            [possible values: json, yaml]
        --generate <SHELL>
            If provided, outputs the completion file for given SHELL
    -l, --languages     Prints out supported languages
    -p, --package-managers
            Prints out supported package managers
HELP

def run(cmd, dir, ok: true)
  out, err, status = cmd.is_a?(Array) ? Open3.capture3(*cmd, chdir: dir) : Open3.capture3(cmd, chdir: dir)
  raise err unless status.success? || !ok

  [out, status.success?]
end

def git(dir, args, ok: true)
  run(['git', *args], dir, ok: ok)
end

def human_bytes(bytes)
  units = ['B', 'KiB', 'MiB', 'GiB']
  val = bytes.to_f
  unit = units.shift
  while val >= 1024 && !units.empty?
    val /= 1024
    unit = units.shift
  end
  unit == 'B' ? "#{bytes} B" : "#{format('%.2f', val)} #{unit}"
end

def relative_time(epoch)
  return '' unless epoch

  diff = Time.now.to_i - epoch.to_i
  return 'now' if diff < 60

  table = [
    [31_536_000, 'year'], [2_592_000, 'month'], [604_800, 'week'],
    [86_400, 'day'], [3_600, 'hour'], [60, 'minute']
  ]
  seconds, name = table.find { |s, _| diff >= s }
  n = [1, (diff / seconds).floor].max
  "#{n == 1 ? 'a' : n} #{name}#{'s' if n != 1} ago"
end

def tracked_files(dir, include_hidden, excludes)
  out, = git(dir, ['ls-files'], ok: false)
  files = out.lines.map(&:chomp).reject(&:empty?)
  files.reject! { |f| f.split('/').any? { |part| part.start_with?('.') } } unless include_hidden
  files.reject! do |f|
    excludes.any? { |pat| File.fnmatch?(pat, f, File::FNM_PATHNAME | File::FNM_EXTGLOB) || f.include?(pat) }
  end
  files.select { |f| File.file?(File.join(dir, f)) }
end

def language_for(path)
  base = File.basename(path)
  return 'Dockerfile' if base == 'Dockerfile'
  return 'Makefile' if base == 'Makefile'

  EXT_LANG[File.extname(path)]
end

def comment_line?(line, lang)
  s = line.strip
  return true if s.empty?
  return true if s.start_with?('#') && !%w[CSS HTML XML JSON YAML TOML].include?(lang)
  return true if s.start_with?('//')
  return true if s.start_with?('/*') || s.start_with?('*') || s.start_with?('*/')
  return true if s.start_with?('<!--')

  false
end

def analyze_files(dir, files)
  bytes = 0
  lang_units = Hash.new(0)
  loc = 0
  files.each do |file|
    full = File.join(dir, file)
    size = File.size(full) rescue 0
    bytes += size
    lang = language_for(file)
    next unless lang

    code_lines = 0

    begin
      File.foreach(full) { |line| code_lines += 1 unless comment_line?(line, lang) }
    rescue StandardError
      next
    end
    next if code_lines.zero?

    unless %w[Markdown JSON YAML TOML XML].include?(lang)
      lang_units[lang] += code_lines
      loc += code_lines unless %w[HTML CSS].include?(lang)
    end
  end
  [bytes, lang_units, loc]
end

def authors(dir, show_email, limit, no_bots)
  fmt = show_email ? '%aN%x09%aE' : '%aN'
  args = ['log', "--format=#{fmt}"]
  args << '--no-merges' if $opts[:no_merges]
  out, = git(dir, args, ok: false)
  counts = Hash.new(0)
  out.lines.map(&:chomp).reject(&:empty?).each do |line|
    name, email = line.split("\t", 2)
    next if no_bots && name =~ /\[bot\]|bot$/i

    counts[[name, email]] += 1
  end
  total = counts.values.sum
  counts.sort_by { |(_, v)| [-v, _[0].to_s] }.first(limit).map do |(name, email), n|
    h = { 'name' => name, 'email' => (show_email ? email : nil), 'nbrOfCommits' => n,
          'contribution' => total.zero? ? 0 : ((n * 100.0 / total).round) }
    h
  end
end

def churn(dir, files, limit)
  result = files.map do |file|
    out, = git(dir, ['log', '--follow', '--format=%H', '--', file], ok: false)
    [file, out.lines.count]
  end
  result.sort_by { |file, n| [-n, file] }.first(limit).map do |file, n|
    { 'filePath' => file, 'nbrOfCommits' => n }
  end
end

def license_name(dir)
  file = Dir.children(dir).find { |f| f =~ /\A(license|licence)(\..*)?\z/i }
  return '' unless file

  text = File.read(File.join(dir, file), 4096) rescue ''
  return 'MIT' if text =~ /MIT License|Permission is hereby granted/i
  return 'Apache-2.0' if text =~ /Apache License/i
  return 'GPL' if text =~ /GNU GENERAL PUBLIC LICENSE/i
  return 'BSD' if text =~ /Redistribution and use in source and binary forms/i

  ''
end

def package_version(dir)
  [['package.json', /"version"\s*:\s*"([^"]+)"/],
   ['Cargo.toml', /^version\s*=\s*"([^"]+)"/],
   ['pyproject.toml', /^version\s*=\s*"([^"]+)"/],
   ['*.gemspec', /\.version\s*=\s*["']([^"']+)/]].each do |glob, rx|
    Dir.glob(File.join(dir, glob)).each do |path|
      m = File.read(path).match(rx) rescue nil
      return m[1] if m
    end
  end
  ''
end

def dependencies(dir)
  deps = []
  deps << 'Npm' if File.exist?(File.join(dir, 'package.json'))
  deps << 'Cargo' if File.exist?(File.join(dir, 'Cargo.toml'))
  deps.join(', ')
end

def remote_url(dir, http, hide_token)
  out, ok = git(dir, ['remote', 'get-url', 'origin'], ok: false)
  return '' unless ok

  url = out.strip
  url = url.sub(%r{\A(?:git@)([^:]+):(.+?)(?:\.git)?\z}, 'https://\1/\2') if http
  url = url.sub(%r{(https?://)[^/@]+@}, '\1') if hide_token
  url
end

def build_info(dir)
  files = tracked_files(dir, $opts[:include_hidden], $opts[:exclude])
  bytes, lang_bytes, loc = analyze_files(dir, files)
  git_ver, = run(['git', '--version'], dir, ok: false)
  user, = git(dir, ['config', 'user.name'], ok: false)
  head, = git(dir, ['rev-parse', '--short=7', 'HEAD'], ok: false)
  branch, = git(dir, ['branch', '--show-current'], ok: false)
  first, = git(dir, ['log', '--reverse', '--format=%ct', '-1'], ok: false)
  last, = git(dir, ['log', '--format=%ct', '-1'], ok: false)
  commit_count_s, = git(dir, ['rev-list', '--count', 'HEAD'], ok: false)
  shallow_s, = git(dir, ['rev-parse', '--is-shallow-repository'], ok: false)
  status, = git(dir, ['status', '--porcelain'], ok: false)

  added = modified = deleted = 0
  status.lines.each do |line|
    xy = line[0, 2]
    added += 1 if xy.include?('A') || xy.include?('?')
    modified += 1 if xy.include?('M')
    deleted += 1 if xy.include?('D')
  end

  lang_total = lang_bytes.values.sum
  lang_list = lang_bytes.sort_by { |_, v| -v }.first($opts[:num_langs]).map do |lang, b|
    pct = lang_total.zero? ? 0.0 : (b * 100.0 / lang_total).round(1)
    { 'language' => lang, 'percentage' => pct }
  end

  title = { 'gitUsername' => user.strip, 'gitVersion' => git_ver.strip }
  fields = []
  add = lambda do |name, value, key|
    fields << { name => value } unless $opts[:disabled].include?(key)
  end
  add.call('ProjectInfo', { 'repoName' => '', 'numberOfBranches' => 0, 'numberOfTags' => 0 }, 'project')
  add.call('DescriptionInfo', { 'description' => nil }, 'description')
  add.call('HeadInfo', { 'headRefs' => { 'shortCommitId' => head.strip, 'refs' => [branch.strip.empty? ? 'HEAD' : branch.strip] } }, 'head')
  add.call('PendingInfo', { 'added' => added, 'deleted' => deleted, 'modified' => modified }, 'pending')
  add.call('VersionInfo', { 'version' => package_version(dir) }, 'version')
  add.call('CreatedInfo', { 'creationDate' => $opts[:iso] ? Time.at(first.to_i).utc.iso8601 : relative_time(first.to_i) }, 'created')
  add.call('LanguagesInfo', { 'languagesWithPercentage' => lang_list }, 'languages') unless lang_list.empty?
  add.call('DependenciesInfo', { 'dependencies' => dependencies(dir) }, 'dependencies')
  add.call('AuthorsInfo', { 'authors' => authors(dir, $opts[:email], $opts[:num_authors], $opts[:no_bots]) }, 'authors')
  add.call('LastChangeInfo', { 'lastChange' => $opts[:iso] ? Time.at(last.to_i).utc.iso8601 : relative_time(last.to_i) }, 'last-change')
  add.call('ContributorsInfo', { 'totalNumberOfAuthors' => authors(dir, false, 10_000, $opts[:no_bots]).size }, 'contributors')
  add.call('UrlInfo', { 'repoUrl' => remote_url(dir, $opts[:http], $opts[:hide_token]) }, 'url')
  add.call('CommitsInfo', { 'numberOfCommits' => commit_count_s.to_i, 'isShallow' => shallow_s.strip == 'true' }, 'commits')
  add.call('ChurnInfo', { 'file_churns' => churn(dir, files, $opts[:num_churn]), 'churn_pool_size' => commit_count_s.to_i }, 'churn')
  add.call('LocInfo', { 'linesOfCode' => loc }, 'lines-of-code') if loc.positive?
  add.call('SizeInfo', { 'repoSize' => human_bytes(bytes), 'fileCount' => files.size }, 'size')
  add.call('LicenseInfo', { 'license' => license_name(dir) }, 'license')
  { 'title' => title, 'infoFields' => fields }
end

def print_text(info)
  title = info['title']
  puts "#{title['gitUsername']} ~ #{title['gitVersion']}" unless $opts[:no_title]
  puts '-' * [10, "#{title['gitUsername']} ~ #{title['gitVersion']}".length].max unless $opts[:no_title]
  info['infoFields'].each do |field|
    name, val = field.first
    case name
    when 'HeadInfo'
      h = val['headRefs']
      puts "HEAD: #{h['shortCommitId']} (#{h['refs'].join(', ')})"
    when 'CreatedInfo' then puts "Created: #{val['creationDate']}"
    when 'LanguagesInfo'
      vals = val['languagesWithPercentage'].map { |l| "#{l['language']} (#{format('%.1f', l['percentage'])} %)" }
      puts "Language: #{vals.join(', ')}"
    when 'AuthorsInfo'
      val['authors'].each { |a| puts "Author: #{a['contribution']}% #{a['name']} #{a['nbrOfCommits']}" }
    when 'LastChangeInfo' then puts "Last change: #{val['lastChange']}"
    when 'CommitsInfo' then puts "Commits: #{val['numberOfCommits']}"
    when 'ChurnInfo'
      val['file_churns'].each_with_index do |c, i|
        puts "#{i.zero? ? "Churn (#{val['churn_pool_size']}):" : ' ' * 10} #{c['filePath']} #{c['nbrOfCommits']}"
      end
    when 'LocInfo' then puts "Lines of code: #{val['linesOfCode']}"
    when 'SizeInfo' then puts "Size: #{val['repoSize']} (#{val['fileCount']} files)"
    when 'LicenseInfo' then puts "License: #{val['license']}" unless val['license'].empty?
    end
  end
end

$opts = {
  output: nil, disabled: [], num_authors: 3, num_langs: 6, num_churn: 3,
  exclude: [], email: false, include_hidden: false, no_bots: false,
  no_merges: false, no_title: false, iso: false, http: false, hide_token: false
}

args = ARGV.dup
if args.include?('-h') || args.include?('--help')
  puts HELP
  exit 0
end
if args.include?('-V') || args.include?('--version')
  puts VERSION
  exit 0
end
if args.include?('-l') || args.include?('--languages')
  puts LANGS
  exit 0
end
if args.include?('-p') || args.include?('--package-managers')
  puts "Npm\nCargo"
  exit 0
end

input = nil
i = 0
while i < args.length
  a = args[i]
  case a
  when '-o', '--output' then i += 1; $opts[:output] = args[i]
  when '-d', '--disabled-fields'
    i += 1
    while i < args.length && !args[i].start_with?('-')
      $opts[:disabled] << args[i].downcase
      i += 1
    end
    i -= 1
  when '--number-of-authors' then i += 1; $opts[:num_authors] = args[i].to_i
  when '--number-of-languages' then i += 1; $opts[:num_langs] = args[i].to_i
  when '--number-of-file-churns' then i += 1; $opts[:num_churn] = args[i].to_i
  when '--churn-pool-size' then i += 1
  when '-e', '--exclude'
    i += 1
    while i < args.length && !args[i].start_with?('-')
      $opts[:exclude] << args[i]
      i += 1
    end
    i -= 1
  when '-E', '--email' then $opts[:email] = true
  when '--include-hidden' then $opts[:include_hidden] = true
  when '--no-bots' then $opts[:no_bots] = true
  when /\A--no-bots=/ then $opts[:no_bots] = true
  when '--no-merges' then $opts[:no_merges] = true
  when '--no-title' then $opts[:no_title] = true
  when '-z', '--iso-time' then $opts[:iso] = true
  when '--http-url' then $opts[:http] = true
  when '--hide-token' then $opts[:hide_token] = true
  when '--generate'
    shell = args[i + 1] || ''
    puts "# completion for executable (#{shell})"
    exit 0
  when '--no-color-palette', '--no-art', '--nerd-fonts', '--no-bold'
  when '--number-separator', '--true-color', '--image', '--image-protocol', '--color-resolution',
       '--ascii-input', '--ascii-language', '--type', '-T', '--text-colors', '-t', '--ascii-colors', '-c'
    i += 1
    i += 1 while %w[-T --type -t --text-colors -c --ascii-colors].include?(a) && i + 1 < args.length && !args[i + 1].start_with?('-')
  else
    input = a unless a.start_with?('-')
  end
  i += 1
end

dir = File.expand_path(input || Dir.pwd)
unless File.directory?(dir)
  warn "Error: Failed to access a directory, or path is not a directory: '#{input || dir}'"
  exit 1
end

inside, ok = git(dir, ['rev-parse', '--is-inside-work-tree'], ok: false)
unless ok && inside.strip == 'true'
  warn 'Error: This directory is not managed by git'
  exit 1
end
root, = git(dir, ['rev-parse', '--show-toplevel'], ok: false)
dir = root.strip unless root.strip.empty?

begin
  info = build_info(dir)
  case $opts[:output]
  when 'json' then puts JSON.pretty_generate(info)
  when 'yaml' then puts info.to_yaml.sub(/\A---\n/, '').gsub(/: \n/, ": null\n")
  when nil then print_text(info)
  else
    warn "error: invalid value '#{$opts[:output]}' for '--output <FORMAT>'"
    exit 2
  end
rescue StandardError => e
  warn "Error: #{e.message.lines.first&.strip || e.class}"
  exit 1
end
