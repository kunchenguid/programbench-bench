#!/usr/bin/env ruby
# frozen_string_literal: true

require 'json'
require 'io/console'

STDOUT.sync = true
STDERR.sync = true

VERSION = "1.4.1"

HELP = <<~HELP
    json-tui {OPTIONS} [file]

      A JSON terminal UI

    OPTIONS:

        file                              A JSON file. Omit to read from stdin.
        -h, --help                        Display this help menu.
        -v, --version                     Print version.
        -k, --key, --keybinding           Display key binding.
        -f, --fullscreen                  Display the JSON in fullscreen, in an
                                          alternate buffer
        "--" can be used to terminate flag options and force all following
        arguments to be treated as positional options

      If no file is given, json-tui reads JSON from the standard input
      Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues
HELP

KEYS = "┌───────────┬────────────────┐\r\n" \
       "│\e[36m\e[49mkeys       \e[39m\e[49m│\e[36m\e[49maction          \e[39m\e[49m│\r\n" \
       "├───────────┼────────────────┤\r\n" \
       "│Navigate   │← ↑ ↓ →         │\r\n" \
       "│           │h j k l         │\r\n" \
       "│           │Mouse::WheelUp  │\r\n" \
       "│           │Mouse::WheelDown│\r\n" \
       "├───────────┼────────────────┤\r\n" \
       "│Toggle     │enter           │\r\n" \
       "│           │Mouse::Left     │\r\n" \
       "├───────────┼────────────────┤\r\n" \
       "│Deep       │                │\r\n" \
       "│ - Expand  │+               │\r\n" \
       "│ - Collapse│-               │\r\n" \
       "├───────────┼────────────────┤\r\n" \
       "│Exit       │Escape          │\r\n" \
       "│           │q               │\r\n" \
       "├───────────┼────────────────┤\r\n" \
       "│Navigate   │                │\r\n" \
       "│ - first   │page-up         │\r\n" \
       "│ - last    │page-down       │\r\n" \
       "│ - top     │gg              │\r\n" \
       "│ - bottom  │G               │\r\n" \
       "└───────────┴────────────────┘\0\n"

def color(code, text)
  "\e[#{code}m\e[49m#{text}\e[39m\e[49m"
end

def bold(text)
  "\e[1m#{text}\e[22m"
end

def plain_width(s)
  s.gsub(/\e\[[0-9;]*[A-Za-z]/, '').length
end

def scalar(v)
  case v
  when String
    color(92, JSON.generate(v))
  when Numeric
    color(96, v.to_s)
  when true, false
    color(93, v.to_s)
  when nil
    color(91, 'null')
  else
    v.to_s
  end
end

def primitive?(v)
  !v.is_a?(Array) && !v.is_a?(Hash)
end

def render_value(v, indent = 0, root: false)
  pad = ' ' * indent
  case v
  when Hash
    keys = v.keys.sort_by(&:to_s)
    return ["#{pad}{}"] if keys.empty?

    open = root ? "\e[7m{\e[27m" : bold('{')
    lines = ["#{pad}#{open}"]
    keys.each_with_index do |k, i|
      val = v[k]
      comma = (i == keys.length - 1) ? '' : ','
      key = color(94, JSON.generate(k.to_s))
      if primitive?(val)
        lines << "#{' ' * (indent + 2)}#{key}: #{scalar(val)}#{comma}"
      elsif val.is_a?(Array)
        lines << "#{' ' * (indent + 2)}#{key}: #{bold('[...]')}#{comma}"
      else
        nested = render_value(val, indent + 2)
        lines << "#{' ' * (indent + 2)}#{key}: #{nested.first.lstrip}#{comma if nested.length == 1}"
        if nested.length > 1
          body = nested[1..]
          body[-1] += comma
          lines.concat(body)
        end
      end
    end
    lines << "#{pad}}"
    lines
  when Array
    return ["#{pad}[]"] if v.empty?

    table = v.all? { |x| x.is_a?(Hash) } ? "   #{color(90, '(table view)')}" : ''
    open = root ? "\e[7m[\e[27m" : bold('[')
    lines = ["#{pad}#{open}#{table}"]
    v.each_with_index do |item, i|
      comma = (i == v.length - 1) ? '' : ','
      if primitive?(item)
        lines << "#{' ' * (indent + 2)}#{scalar(item)}#{comma}"
      elsif item.is_a?(Array)
        lines << "#{' ' * (indent + 2)}#{bold('[...]')}#{comma}"
      else
        nested = render_value(item, indent + 2)
        lines << nested.first
        if nested.length > 1
          body = nested[1..]
          body[-1] += comma
          lines.concat(body)
        else
          lines[-1] += comma
        end
      end
    end
    lines << "#{pad}]"
    lines
  else
    ["#{pad}#{scalar(v)}"]
  end
end

def parse_args(argv)
  fullscreen = false
  positional = []
  flags_done = false
  argv.each do |arg|
    if flags_done
      positional << arg
    elsif arg == '--'
      flags_done = true
    elsif ['-h', '--help'].include?(arg)
      puts HELP
      exit 0
    elsif ['-v', '--version'].include?(arg)
      puts VERSION
      exit 0
    elsif ['-k', '--key', '--keybinding'].include?(arg)
      print KEYS
      exit 0
    elsif ['-f', '--fullscreen'].include?(arg)
      fullscreen = true
    elsif arg.start_with?('-')
      warn 'Invalid arguments'
      exit 1
    else
      positional << arg
    end
  end
  if positional.length > 1
    warn 'Invalid arguments'
    exit 1
  end
  [fullscreen, positional.first]
end

def read_json_text(file)
  if file
    begin
      File.read(file)
    rescue StandardError
      warn "Could not open file #{file}"
      exit 1
    end
  else
    puts 'Reading from stdin...'
    STDOUT.flush
    STDIN.read
  end
end

def nlohmannish_error(text, error)
  line = 1
  col = 1
  if error.message =~ /line (\d+), column (\d+)/
    line = Regexp.last_match(1).to_i
    col = Regexp.last_match(2).to_i
  end
  col = 2 if col == 1 && text =~ /\A[a-zA-Z]{2}/
  prefix = text.lines[0].to_s[0, [col, 1].max]
  prefix = text[0, 2].to_s if prefix.empty?
  "[json.exception.parse_error.101] parse error at line #{line}, column #{col}: syntax error while parsing value - invalid literal; last read: '#{prefix}'"
end

def terminal_size
  rows, cols = STDOUT.winsize
  [rows.zero? ? 24 : rows, cols.zero? ? 80 : cols]
rescue StandardError
  [24, 80]
end

def display(lines, fullscreen)
  rows, cols = terminal_size
  width = fullscreen ? cols : [lines.map { |l| plain_width(l) }.max || 0, 1].max
  height = fullscreen ? rows : lines.length
  padded = lines.first(height).map { |l| l + (' ' * [width - plain_width(l), 0].max) }
  padded += [' ' * width] * (height - padded.length)
  $last_height = height
  $last_width = width

  print "\0\eP$q q\e\\"
  print "\e[?1049h" if fullscreen
  print "\e[?7l\e[?1000h\e[?1003h\e[?1015h\e[?1006h\0\r\e[2K"
  print padded.join("\r\n")
  print "\e[#{[height - 1, 0].max}A\e[#{[width - 1, 0].max}D\e[?25l\0"
  STDOUT.flush
end

def cleanup(fullscreen)
  height = $last_height || terminal_size.first
  width = $last_width || terminal_size.last
  print "\e[#{[height - 1, 0].max}B\e[#{[width - 1, 0].max}C"
  print "\e[?1006l\e[?1015l\e[?1003l\e[?1000l\e[?7h"
  print "\e[?1049l" if fullscreen
  print "\e[?25h\e[1 q\0\r\n"
rescue StandardError
  nil
end

fullscreen, file = parse_args(ARGV)
text = read_json_text(file)
begin
  data = JSON.parse(text)
rescue JSON::ParserError => e
  warn nlohmannish_error(text, e)
  exit 1
end

display(render_value(data, 0, root: true), fullscreen)
trap('TERM') { cleanup(fullscreen); exit 124 }
trap('INT') { cleanup(fullscreen); exit 130 }

begin
  STDIN.raw do |io|
    loop do
      char = io.read_nonblock(1, exception: false)
      break if ['q', "\e"].include?(char)
      sleep 0.05
    end
  end
rescue StandardError
  sleep
end
cleanup(fullscreen)
