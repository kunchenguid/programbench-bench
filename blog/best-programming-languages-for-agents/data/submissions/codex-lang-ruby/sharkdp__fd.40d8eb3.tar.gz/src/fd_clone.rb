#!/usr/bin/env ruby
# frozen_string_literal: true

require 'find'
require 'fileutils'
require 'etc'

VERSION = "fd 10.3.0"

HELP_SHORT = <<~TEXT
  A program to find entries in your filesystem

  Usage: executable [OPTIONS] [pattern] [path]...

  Arguments:
    [pattern]  the search pattern (a regular expression, unless '--glob' is used; optional)
    [path]...  the root directories for the filesystem search (optional)

  Options:
    -H, --hidden                     Search hidden files and directories
    -I, --no-ignore                  Do not respect .(git|fd)ignore files
    -s, --case-sensitive             Case-sensitive search (default: smart case)
    -i, --ignore-case                Case-insensitive search (default: smart case)
    -g, --glob                       Glob-based search (default: regular expression)
    -a, --absolute-path              Show absolute instead of relative paths
    -l, --list-details               Use a long listing format with file metadata
    -L, --follow                     Follow symbolic links
    -p, --full-path                  Search full abs. path (default: filename only)
    -d, --max-depth <depth>          Set maximum search depth (default: none)
    -E, --exclude <pattern>          Exclude entries that match the given glob pattern
    -t, --type <filetype>            Filter by type: file (f), directory (d/dir), symlink (l),
                                     executable (x), empty (e), socket (s), pipe (p), char-device
                                     (c), block-device (b)
    -e, --extension <ext>            Filter by file extension
    -S, --size <size>                Limit results based on the size of files
        --changed-within <date|dur>  Filter by file modification time (newer than)
        --changed-before <date|dur>  Filter by file modification time (older than)
    -o, --owner <user:group>         Filter by owning user and/or group
        --format <fmt>               Print results according to template
    -x, --exec <cmd>...              Execute a command for each search result
    -X, --exec-batch <cmd>...        Execute a command with all search results at once
    -c, --color <when>               When to use colors [default: auto] [possible values: auto,
                                     always, never]
        --hyperlink[=<when>]         Add hyperlinks to output paths [default: never] [possible
                                     values: auto, always, never]
        --ignore-contain <name>      Ignore directories containing the named entry
    -h, --help                       Print help (see more with '--help')
    -V, --version                    Print version
TEXT

OPTS = {
  hidden: false, ignore: true, case: :smart, glob: false, fixed: false,
  absolute: false, full_path: false, print0: false, follow: false,
  min_depth: 1, max_depth: nil, exact_depth: nil, excludes: [], types: [],
  extensions: [], size: nil, newer: nil, older: nil, owner: nil, format: nil,
  execs: [], batches: [], batch_size: 0, quiet: false, max_results: nil,
  search_paths: [], base_directory: nil, path_separator: '/', color: 'auto',
  strip_cwd_prefix: :auto, prune: false, and_patterns: [], ignore_files: [],
  ignore_contain: [], show_errors: false
}

def die(msg, code = 1)
  warn "error: #{msg}"
  exit code
end

def take_value(args, i, opt, attached = nil)
  return [attached, i] if attached && !attached.empty?
  die("a value is required for '#{opt}'") if i + 1 >= args.length
  [args[i + 1], i + 1]
end

def parse_args(argv)
  opts = Marshal.load(Marshal.dump(OPTS))
  pos = []
  i = 0
  stop = false
  while i < argv.length
    a = argv[i]
    if stop || a == '-' || !a.start_with?('-')
      pos << a
    elsif a == '--'
      stop = true
    elsif a.start_with?('--')
      name, val = a[2..].split('=', 2)
      case name
      when 'help' then puts HELP_SHORT; exit 0
      when 'version' then puts VERSION; exit 0
      when 'hidden' then opts[:hidden] = true
      when 'no-hidden' then opts[:hidden] = false
      when 'no-ignore', 'no-ignore-vcs', 'no-ignore-parent' then opts[:ignore] = false
      when 'ignore', 'ignore-vcs' then opts[:ignore] = true
      when 'unrestricted' then opts[:hidden] = true; opts[:ignore] = false
      when 'case-sensitive' then opts[:case] = :sensitive
      when 'ignore-case' then opts[:case] = :insensitive
      when 'glob' then opts[:glob] = true
      when 'regex' then opts[:glob] = false
      when 'fixed-strings' then opts[:fixed] = true
      when 'absolute-path' then opts[:absolute] = true
      when 'relative-path' then opts[:absolute] = false
      when 'list-details' then opts[:list_details] = true
      when 'follow' then opts[:follow] = true
      when 'no-follow' then opts[:follow] = false
      when 'full-path' then opts[:full_path] = true
      when 'print0' then opts[:print0] = true
      when 'max-depth' then v, i = take_value(argv, i, a, val); opts[:max_depth] = v.to_i
      when 'min-depth' then v, i = take_value(argv, i, a, val); opts[:min_depth] = v.to_i
      when 'exact-depth'
        v, i = take_value(argv, i, a, val); opts[:min_depth] = v.to_i; opts[:max_depth] = v.to_i
      when 'exclude' then v, i = take_value(argv, i, a, val); opts[:excludes] << v
      when 'prune' then opts[:prune] = true
      when 'type' then v, i = take_value(argv, i, a, val); opts[:types] << v
      when 'extension' then v, i = take_value(argv, i, a, val); opts[:extensions] << v.sub(/^\./, '')
      when 'size' then v, i = take_value(argv, i, a, val); opts[:size] = parse_size(v)
      when 'changed-within', 'change-newer-than', 'newer', 'changed-after'
        v, i = take_value(argv, i, a, val); opts[:newer] = parse_time_arg(v)
      when 'changed-before', 'change-older-than', 'older'
        v, i = take_value(argv, i, a, val); opts[:older] = parse_time_arg(v)
      when 'owner' then v, i = take_value(argv, i, a, val); opts[:owner] = parse_owner(v)
      when 'format' then v, i = take_value(argv, i, a, val); opts[:format] = v
      when 'exec', 'exec-batch'
        cmd = []
        j = i + 1
        while j < argv.length && argv[j] != ';'
          cmd << argv[j]; j += 1
        end
        die("a command is required for '#{a}'") if cmd.empty?
        name == 'exec' ? opts[:execs] << cmd : opts[:batches] << cmd
        i = (j < argv.length && argv[j] == ';') ? j : argv.length
      when 'batch-size' then v, i = take_value(argv, i, a, val); opts[:batch_size] = v.to_i
      when 'color' then v, i = take_value(argv, i, a, val); opts[:color] = v
      when 'hyperlink' then opts[:hyperlink] = val || 'auto'
      when 'threads' then _v, i = take_value(argv, i, a, val)
      when 'max-results' then v, i = take_value(argv, i, a, val); opts[:max_results] = v.to_i
      when 'quiet', 'has-results' then opts[:quiet] = true
      when 'show-errors' then opts[:show_errors] = true
      when 'base-directory' then v, i = take_value(argv, i, a, val); opts[:base_directory] = v
      when 'path-separator' then v, i = take_value(argv, i, a, val); opts[:path_separator] = v
      when 'search-path' then v, i = take_value(argv, i, a, val); opts[:search_paths] << v
      when 'strip-cwd-prefix' then opts[:strip_cwd_prefix] = (val || 'always').to_sym
      when 'one-file-system', 'mount', 'xdev' then opts[:one_file_system] = true
      when 'and' then v, i = take_value(argv, i, a, val); opts[:and_patterns] << v
      when 'ignore-file' then v, i = take_value(argv, i, a, val); opts[:ignore_files] << v
      when 'ignore-contain' then v, i = take_value(argv, i, a, val); opts[:ignore_contain] << v
      when 'require-git', 'no-require-git' then nil
      else die("unexpected argument '--#{name}'")
      end
    else
      chars = a[1..].chars
      k = 0
      while k < chars.length
        c = chars[k]
        rest = chars[(k + 1)..]&.join
        case c
        when 'h' then puts HELP_SHORT; exit 0
        when 'V' then puts VERSION; exit 0
        when 'H' then opts[:hidden] = true
        when 'I' then opts[:ignore] = false
        when 'u' then opts[:hidden] = true; opts[:ignore] = false
        when 's' then opts[:case] = :sensitive
        when 'i' then opts[:case] = :insensitive
        when 'g' then opts[:glob] = true
        when 'F' then opts[:fixed] = true
        when 'a' then opts[:absolute] = true
        when 'l' then opts[:list_details] = true
        when 'L' then opts[:follow] = true
        when 'p' then opts[:full_path] = true
        when '0' then opts[:print0] = true
        when '1' then opts[:max_results] = 1
        when 'q' then opts[:quiet] = true
        when 'd', 'E', 't', 'e', 'S', 'o', 'c', 'j', 'x', 'X', 'C'
          optname = "-#{c}"
          v = nil
          if %w[x X].include?(c)
            cmd = []
            j = i + 1
            while j < argv.length && argv[j] != ';'
              cmd << argv[j]; j += 1
            end
            die("a command is required for '#{optname}'") if cmd.empty?
            c == 'x' ? opts[:execs] << cmd : opts[:batches] << cmd
            i = (j < argv.length && argv[j] == ';') ? j : argv.length
          else
            v, i = take_value(argv, i, optname, rest)
            k = chars.length
            case c
            when 'd' then opts[:max_depth] = v.to_i
            when 'E' then opts[:excludes] << v
            when 't' then opts[:types] << v
            when 'e' then opts[:extensions] << v.sub(/^\./, '')
            when 'S' then opts[:size] = parse_size(v)
            when 'o' then opts[:owner] = parse_owner(v)
            when 'c' then opts[:color] = v
            when 'C' then opts[:base_directory] = v
            end
          end
        else die("unexpected argument '-#{c}'")
        end
        k += 1
      end
    end
    i += 1
  end
  [opts, pos]
end

def parse_size(s)
  m = /\A([+-]?)(\d+)([a-zA-Z]+)\z/.match(s) or die("invalid value '#{s}' for '--size <size>': '#{s}' is not a valid size constraint. See 'fd --help'.")
  mult = { '' => 1, 'b' => 1, 'k' => 1000, 'm' => 1_000_000, 'g' => 1_000_000_000,
           't' => 1_000_000_000_000, 'ki' => 1024, 'mi' => 1024**2, 'gi' => 1024**3,
           'ti' => 1024**4 }[m[3].downcase] or die("invalid size unit: #{m[3]}")
  [m[1], m[2].to_i * mult]
end

def parse_time_arg(s)
  return Time.at(s[1..].to_i) if s.start_with?('@')
  if (m = /\A(\d+)\s*(s|sec|secs|second|seconds|min|mins|minute|minutes|h|hour|hours|d|day|days|w|week|weeks)\z/i.match(s))
    n = m[1].to_i
    unit = m[2].downcase
    seconds = case unit
              when /^s/ then n
              when /^min/ then n * 60
              when 'h', /^hour/ then n * 3600
              when 'd', /^day/ then n * 86_400
              else n * 604_800
              end
    return Time.now - seconds
  end
  if (m = /\A(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}):(\d{2})(?:[+-]\d{2}:?\d{2}|Z)?)?\z/.match(s))
    return Time.local(m[1].to_i, m[2].to_i, m[3].to_i, (m[4] || 0).to_i, (m[5] || 0).to_i, (m[6] || 0).to_i)
  end
  raise ArgumentError
rescue StandardError
  die("invalid date or duration: #{s}")
end

def parse_owner(s)
  user, group = s.split(':', 2)
  [user, group]
end

def canonical_type(t)
  { 'f' => :file, 'file' => :file, 'd' => :dir, 'dir' => :dir, 'directory' => :dir,
    'l' => :symlink, 'symlink' => :symlink, 'x' => :exec, 'executable' => :exec,
    'e' => :empty, 'empty' => :empty, 's' => :socket, 'socket' => :socket,
    'p' => :pipe, 'pipe' => :pipe, 'b' => :block, 'block-device' => :block,
    'c' => :char, 'char-device' => :char }[t] || die("invalid file type: #{t}")
end

def hidden_name?(path)
  File.basename(path).start_with?('.')
end

def glob_match?(pattern, text)
  flags = File::FNM_PATHNAME | File::FNM_EXTGLOB
  File.fnmatch?(pattern, text, flags) || File.fnmatch?("**/#{pattern}", text, flags) ||
    File.fnmatch?(pattern, File.basename(text), File::FNM_EXTGLOB)
end

def load_ignore_file(path)
  return [] unless File.file?(path)
  File.readlines(path, chomp: true).filter_map do |line|
    line = line.strip
    next if line.empty? || line.start_with?('#')
    line
  end
rescue StandardError
  []
end

def ignored_by_patterns?(patterns, rel)
  ignored = false
  patterns.each do |pat|
    neg = pat.start_with?('!')
    p = neg ? pat[1..] : pat
    p = p[1..] if p.start_with?('/')
    p = p.chomp('/')
    matched = if p.include?('/')
                glob_match?(p, rel)
              else
                glob_match?(p, File.basename(rel)) || rel.split('/').include?(p)
              end
    ignored = !neg if matched
  end
  ignored
end

def relative_from_cwd(path)
  Pathname.new(path).relative_path_from(Pathname.new(Dir.pwd)).to_s
rescue StandardError
  path
end

require 'pathname'

def display_path(path, is_dir, opts)
  out = opts[:absolute] ? File.expand_path(path) : relative_from_cwd(path)
  out = "." if out.empty?
  out += "/" if is_dir && !out.end_with?("/")
  out = out.tr('/', opts[:path_separator]) if opts[:path_separator] != '/'
  out
end

def match_text_for(path, opts)
  opts[:full_path] ? File.expand_path(path) : File.basename(path)
end

def compile_matcher(pattern, opts)
  pattern = '' if pattern.nil?
  insensitive = opts[:case] == :insensitive || (opts[:case] == :smart && pattern !~ /[A-Z]/)
  if opts[:fixed]
    needle = insensitive ? pattern.downcase : pattern
    lambda { |text| (insensitive ? text.downcase : text).include?(needle) }
  elsif opts[:glob]
    p = insensitive ? pattern.downcase : pattern
    lambda do |text|
      t = insensitive ? text.downcase : text
      glob_match?(p, t)
    end
  else
    flags = insensitive ? Regexp::IGNORECASE : nil
    re = Regexp.new(pattern, flags)
    lambda { |text| !!(re =~ text) }
  end
rescue RegexpError => e
  die("regex parse error: #{e.message}")
end

def empty_dir?(path)
  Dir.children(path).empty?
rescue StandardError
  false
end

def type_ok?(path, stat, opts)
  types = opts[:types].map { |t| canonical_type(t) }
  return true if types.empty?
  regular_types = types - [:empty, :exec]
  base = []
  base << :file if stat.file?
  base << :dir if stat.directory?
  base << :symlink if stat.symlink?
  base << :socket if stat.socket?
  base << :pipe if stat.pipe?
  base << :block if stat.blockdev?
  base << :char if stat.chardev?
  ok = regular_types.empty? ? true : (base & regular_types).any?
  ok &&= stat.file? && File.executable?(path) if types.include?(:exec)
  if types.include?(:empty)
    ok &&= (stat.file? && stat.size.zero?) || (stat.directory? && empty_dir?(path))
  end
  ok
end

def ext_ok?(path, opts)
  return true if opts[:extensions].empty?
  ext = File.extname(path)
  ext = ext[1..] if ext.start_with?('.')
  opts[:extensions].any? { |e| e.casecmp?(ext) }
end

def size_ok?(stat, opts)
  return true unless opts[:size]
  op, size = opts[:size]
  return false unless stat.file?
  op == '+' ? stat.size >= size : op == '-' ? stat.size <= size : stat.size == size
end

def owner_ok?(stat, opts)
  return true unless opts[:owner]
  user, group = opts[:owner]
  checks = []
  if user && !user.empty?
    neg = user.start_with?('!')
    u = neg ? user[1..] : user
    val = (u =~ /^\d+$/ ? stat.uid == u.to_i : (Etc.getpwuid(stat.uid).name == u rescue false))
    checks << (neg ? !val : val)
  end
  if group && !group.empty?
    neg = group.start_with?('!')
    g = neg ? group[1..] : group
    val = (g =~ /^\d+$/ ? stat.gid == g.to_i : (Etc.getgrgid(stat.gid).name == g rescue false))
    checks << (neg ? !val : val)
  end
  checks.all?
end

def substitute(fmt, disp)
  raw = disp.end_with?('/') ? disp.chomp('/') : disp
  base = File.basename(raw)
  dir = File.dirname(raw)
  noext = raw.sub(/(\.[^\/.]*)\z/, '')
  baseno = base.sub(/(\.[^.]*)\z/, '')
  fmt.gsub('{{', "\0L").gsub('}}', "\0R")
     .gsub('{//}', dir).gsub('{/.}', baseno).gsub('{/}', base)
     .gsub('{.}', noext).gsub('{}', disp)
     .gsub("\0L", '{').gsub("\0R", '}')
end

def substitute_exec(fmt, disp, opts)
  raw = disp.end_with?('/') ? disp.chomp('/') : disp
  base = File.basename(raw)
  dir = File.dirname(raw)
  noext = raw.sub(/(\.[^\/.]*)\z/, '')
  baseno = base.sub(/(\.[^.]*)\z/, '')
  fmt.gsub('{{', "\0L").gsub('}}', "\0R")
     .gsub('{//}', dir).gsub('{/.}', baseno).gsub('{/}', base)
     .gsub('{.}', noext).gsub('{}', prefixed_for_exec(disp, opts))
     .gsub("\0L", '{').gsub("\0R", '}')
end

def colorize(out, path, stat, opts)
  return out unless opts[:color] == 'always'
  code = stat.directory? ? '34' : (File.executable?(path) ? '32' : '0')
  "\e[#{code}m#{out}\e[0m"
end

def collect(paths, pattern, opts)
  matcher = compile_matcher(pattern || '', opts)
  and_matchers = opts[:and_patterns].map { |p| compile_matcher(p, opts) }
  results = []
  global_ignores = opts[:ignore_files].flat_map { |f| load_ignore_file(f) }
  paths.each do |root|
    root = File.expand_path(root)
    next unless File.exist?(root)
    walk = lambda do |dir, depth, inherited_ignores|
      current_ignores = inherited_ignores
      if opts[:ignore]
        current_ignores = inherited_ignores + load_ignore_file(File.join(dir, '.ignore')) +
                          load_ignore_file(File.join(dir, '.fdignore')) +
                          load_ignore_file(File.join(dir, '.gitignore'))
      end
      entries = Dir.children(dir).map { |e| File.join(dir, e) }
      entries.sort_by! { |p| [(File.directory?(p) && !File.symlink?(p)) ? 0 : 1, File.basename(p)] }
      entries.each do |path|
        begin
          stat = opts[:follow] ? File.stat(path) : File.lstat(path)
        rescue StandardError => e
          warn e.message if opts[:show_errors]
          next
        end
        is_dir = stat.directory?
        rel_to_root = Pathname.new(path).relative_path_from(Pathname.new(root)).to_s
        hidden = hidden_name?(path)
        next if hidden && !opts[:hidden]
        ignored = opts[:ignore] && ignored_by_patterns?(current_ignores, rel_to_root)
        excluded = opts[:excludes].any? { |p| glob_match?(p, rel_to_root) || glob_match?(p, File.basename(path)) }
        contains_ignored = is_dir && opts[:ignore_contain].any? { |n| File.exist?(File.join(path, n)) }
        next if ignored || excluded || contains_ignored

        depth_ok = depth + 1 >= opts[:min_depth]
        within_max = opts[:max_depth].nil? || depth + 1 <= opts[:max_depth]
        text = match_text_for(path, opts)
        matched = depth_ok && matcher.call(text) && and_matchers.all? { |m| m.call(text) }
        matched &&= type_ok?(path, stat, opts)
        matched &&= ext_ok?(path, opts)
        matched &&= size_ok?(stat, opts)
        matched &&= owner_ok?(stat, opts)
        matched &&= stat.mtime > opts[:newer] if opts[:newer]
        matched &&= stat.mtime < opts[:older] if opts[:older]
        if matched && within_max
          disp = display_path(path, is_dir, opts)
          results << [disp, path, stat]
          return results if opts[:max_results] && results.length >= opts[:max_results]
        end
        should_descend = is_dir && within_max && !(opts[:prune] && matched)
        should_descend &&= !(stat.symlink? && !opts[:follow])
        if should_descend
          r = walk.call(path, depth + 1, current_ignores)
          return r if opts[:max_results] && results.length >= opts[:max_results]
        end
      end
      results
    end
    r = walk.call(root, 0, global_ignores)
    return r if opts[:max_results] && results.length >= opts[:max_results]
  end
  results
end

def command_args(cmd, disp, opts)
  has_placeholder = cmd.any? { |a| a.include?('{') }
  cmd = cmd + ['{}'] unless has_placeholder
  cmd.flat_map { |a| substitute_exec(a, disp, opts) }
end

def prefixed_for_exec(disp, opts)
  return disp if opts[:absolute]
  strip = opts[:strip_cwd_prefix] == :always
  need = opts[:strip_cwd_prefix] == :never || (opts[:strip_cwd_prefix] == :auto && (opts[:print0] || !opts[:execs].empty? || !opts[:batches].empty?))
  need && !strip && !disp.start_with?('./') ? "./#{disp}" : disp
end

opts, pos = parse_args(ARGV)
Dir.chdir(opts[:base_directory]) if opts[:base_directory]
if opts[:search_paths].any?
  pattern = pos.shift || ''
  paths = opts[:search_paths]
else
  pattern = pos.shift
  paths = pos.empty? ? ['.'] : pos
end
pattern ||= ''

results = collect(paths, pattern, opts)

if opts[:quiet]
  exit(results.empty? ? 1 : 0)
end

if opts[:list_details]
  args = results.map { |d, _p, _s| prefixed_for_exec(d, opts) }
  exec('ls', '-ld', '--color=always', *args) unless args.empty?
  exit 0
end

unless opts[:execs].empty? && opts[:batches].empty?
  results.each do |disp, _path, _stat|
    opts[:execs].each { |cmd| system(*command_args(cmd, disp, opts)) }
  end
  opts[:batches].each do |cmd|
    disps = results.map { |d, _p, _s| d }
    has_placeholder = cmd.any? { |a| a.include?('{') }
    args = if has_placeholder
             cmd.flat_map { |a| a.include?('{') ? disps.map { |d| substitute_exec(a, d, opts) } : [a] }
           else
             cmd + disps.map { |d| prefixed_for_exec(d, opts) }
           end
    next if args.empty?
    if opts[:batch_size].positive?
      fixed = has_placeholder ? cmd.reject { |a| a.include?('{') } : cmd
      disps.each_slice(opts[:batch_size]) { |slice| system(*(fixed + slice.map { |d| prefixed_for_exec(d, opts) })) }
    else
      system(*args)
    end
  end
  exit 0
end

sep = opts[:print0] ? "\0" : "\n"
results.each do |disp, path, stat|
  out = opts[:format] ? substitute(opts[:format], disp) : disp
  out = prefixed_for_exec(out, opts) if opts[:print0] && !opts[:format]
  print colorize(out, path, stat, opts)
  print sep
end
