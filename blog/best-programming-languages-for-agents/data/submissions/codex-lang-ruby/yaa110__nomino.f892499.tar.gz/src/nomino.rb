#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'

VERSION = 'nomino 1.6.4'

HELP_SHORT = <<~TXT
  Batch rename utility for developers

  Usage: executable [OPTIONS] [[SOURCE] OUTPUT]...

  Arguments:
    [[SOURCE] OUTPUT]...  OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option

  Options:
    -d, --dir <PATH>         Sets the working directory
        --depth <DEPTH>      Optional value to overwrite inferred subdirectory depth value in 'regex' mode
    -E, --no-extension       Does not preserve the extension of input files in 'sort' and 'regex' options
    -g, --generate <PATH>    Stores a JSON map file in '<PATH>' after renaming files
    -h, --help               Print help (see more with '--help')
    -k, --mkdir              Recursively creates all parent directories of '<OUTPUT>' if they are missing
    -m, --map <PATH>         Sets the path of map file to be used for renaming files [aliases: --from-file]
        --max-depth <DEPTH>  Optional value to set the maximum of subdirectory depth value in 'regex' mode
    -q, --quiet              Does not print the map table to stdout
    -r, --regex <PATTERN>    Regex pattern to match by filenames
    -s, --sort <ORDER>       Sets the order of natural sorting (by name) to rename files using enumerator [possible values: asc, desc]
    -t, --test               Runs in test mode without renaming actual files [aliases: --dry-run]
    -V, --version            Print version
    -w, --overwrite          Overwrites output files, otherwise, a '_' is prepended to filename

  OUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information.
TXT

HELP_LONG = <<~TXT
  Batch rename utility for developers

  Usage: executable [OPTIONS] [[SOURCE] OUTPUT]...

  Arguments:
    [[SOURCE] OUTPUT]...
            OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option

  Options:
    -d, --dir <PATH>
            Sets the working directory

        --depth <DEPTH>
            Optional value to overwrite inferred subdirectory depth value in 'regex' mode

    -E, --no-extension
            Does not preserve the extension of input files in 'sort' and 'regex' options

    -g, --generate <PATH>
            Stores a JSON map file in '<PATH>' after renaming files

    -h, --help
            Print help (see a summary with '-h')

    -k, --mkdir
            Recursively creates all parent directories of '<OUTPUT>' if they are missing

    -m, --map <PATH>
            Sets the path of map file to be used for renaming files
            
            [aliases: --from-file]

        --max-depth <DEPTH>
            Optional value to set the maximum of subdirectory depth value in 'regex' mode

    -q, --quiet
            Does not print the map table to stdout

    -r, --regex <PATTERN>
            Regex pattern to match by filenames

    -s, --sort <ORDER>
            Sets the order of natural sorting (by name) to rename files using enumerator

            Possible values:
            - asc:  Sort in ascending order
            - desc: Sort in descending order

    -t, --test
            Runs in test mode without renaming actual files
            
            [aliases: --dry-run]

    -V, --version
            Print version

    -w, --overwrite
            Overwrites output files, otherwise, a '_' is prepended to filename

  OUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information.
TXT

def die(message, code = 1)
  warn message
  exit code
end

def parse_args(argv)
  opts = {
    dir: Dir.pwd, depth: nil, max_depth: nil, preserve_ext: true, mkdir: false,
    quiet: false, test: false, overwrite: false, generate: nil, map: nil,
    regex: nil, sort: nil, positional: []
  }
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when '-h'
      puts HELP_SHORT
      exit 0
    when '--help'
      puts HELP_LONG
      exit 0
    when '-V', '--version'
      puts VERSION
      exit 0
    when '-d', '--dir'
      i += 1
      die("error: a value is required for '#{a} <PATH>' but none was supplied", 2) if i >= argv.length
      opts[:dir] = argv[i]
    when '--depth'
      i += 1
      opts[:depth] = Integer(argv[i] || '', exception: false)
      die("error: invalid value for '--depth <DEPTH>'", 2) unless opts[:depth]
    when '--max-depth'
      i += 1
      opts[:max_depth] = Integer(argv[i] || '', exception: false)
      die("error: invalid value for '--max-depth <DEPTH>'", 2) unless opts[:max_depth]
    when '-E', '--no-extension'
      opts[:preserve_ext] = false
    when '-g', '--generate'
      i += 1
      die("error: a value is required for '#{a} <PATH>' but none was supplied", 2) if i >= argv.length
      opts[:generate] = argv[i]
    when '-k', '--mkdir'
      opts[:mkdir] = true
    when '-m', '--map', '--from-file'
      i += 1
      die("error: a value is required for '#{a} <PATH>' but none was supplied", 2) if i >= argv.length
      opts[:map] = argv[i]
    when '-q', '--quiet'
      opts[:quiet] = true
    when '-r', '--regex'
      i += 1
      die("error: a value is required for '#{a} <PATTERN>' but none was supplied", 2) if i >= argv.length
      opts[:regex] = argv[i]
    when '-s', '--sort'
      i += 1
      val = argv[i]
      unless %w[asc desc].include?(val)
        die("error: invalid value '#{val}' for '--sort <ORDER>'\n  [possible values: asc, desc]\n\nFor more information, try '--help'.", 2)
      end
      opts[:sort] = val
    when '-t', '--test', '--dry-run'
      opts[:test] = true
    when '-w', '--overwrite'
      opts[:overwrite] = true
    else
      if a.start_with?('-')
        die("error: unexpected argument '#{a}' found\n\nUsage: executable [OPTIONS] [[SOURCE] OUTPUT]...\n\nFor more information, try '--help'.", 2)
      end
      opts[:positional] << a
    end
    i += 1
  end
  opts
end

def natural_key(str)
  str.to_s.downcase.scan(/\d+|\D+/).map { |p| p =~ /\A\d+\z/ ? [0, p.to_i, p.length] : [1, p] }
end

def component_depth(rel)
  rel.empty? ? 0 : rel.count('/') + 1
end

def entries(dir, max_depth = nil, exact_depth = nil, include_root = false)
  base = File.expand_path(dir)
  out = []
  out << '' if include_root
  Dir.glob(File.join(base, '**', '*'), File::FNM_DOTMATCH).each do |p|
    name = File.basename(p)
    next if name == '.' || name == '..'
    rel = p.sub(%r{\A#{Regexp.escape(base)}/?}, '')
    depth = component_depth(rel)
    next if exact_depth && depth != exact_depth
    next if max_depth && depth > max_depth
    out << rel
  end
  out.sort_by { |x| natural_key(x) }
end

def split_ext(path)
  base = File.basename(path)
  return [path, ''] if File.directory?(path)
  ext = File.extname(base)
  return [path, ''] if ext.empty?
  [path[0...-ext.length], ext]
end

def pad_value(val, pad)
  s = val.to_s
  return s unless pad && s =~ /\A\d+\z/
  s.rjust(pad.to_i, '0')
end

def translate_regex(pattern)
  pattern.gsub(/\(\?P<([A-Za-z_][A-Za-z0-9_]*)>/, '(?<\1>')
end

def format_pattern(pattern, groups, names = {})
  auto = 1
  out = +''
  i = 0
  while i < pattern.length
    ch = pattern[i]
    if ch == '\\' && i + 1 < pattern.length && ['{', '}'].include?(pattern[i + 1])
      out << pattern[i + 1]
      i += 2
    elsif ch == '{'
      j = pattern.index('}', i + 1)
      die("error: [output-format] an opened placeholder could not be closed by '}'") unless j
      spec = pattern[(i + 1)...j]
      key, pad = spec.split(':', 2)
      if key.nil? || key.empty?
        idx = auto
        auto += 1
        val = groups[idx] || ''
      elsif key =~ /\A\d+\z/
        val = groups[key.to_i] || ''
      else
        val = names[key] || ''
      end
      out << pad_value(val, pad)
      i = j + 1
    elsif ch == '}'
      die("error: [output-format] an unopened placeholder could not be closed by '}'")
    else
      out << ch
      i += 1
    end
  end
  out
end

def preserve_extension(input_rel, output, opts)
  return output unless opts[:preserve_ext]
  full = File.join(opts[:dir], input_rel)
  return output if File.directory?(full)
  ext = File.extname(input_rel)
  ext.empty? ? output : output + ext
end

def make_unique(output, existing, used, overwrite)
  return output if overwrite
  candidate = output
  while existing.include?(candidate) || used.include?(candidate)
    dir = File.dirname(candidate)
    base = File.basename(candidate)
    prefixed = "_#{base}"
    candidate = dir == '.' ? prefixed : File.join(dir, prefixed)
  end
  candidate
end

def build_sort_map(opts, pattern)
  list = entries(opts[:dir], nil, 1)
  list.reverse! if opts[:sort] == 'desc'
  existing = list.to_h { |x| [x, true] }
  used = {}
  list.each_with_index.map do |rel, idx|
    groups = [rel, idx + 1]
    out = format_pattern(pattern, groups)
    out = preserve_extension(rel, out, opts)
    out = make_unique(out, existing, used, opts[:overwrite])
    used[out] = true
    [rel, out]
  end
end

def build_regex_map(opts, pattern, output)
  re = Regexp.new(translate_regex(pattern))
  if opts[:depth]
    list = entries(opts[:dir], nil, opts[:depth], opts[:depth].zero?)
  elsif opts[:max_depth]
    list = entries(opts[:dir], opts[:max_depth], nil, opts[:max_depth].zero?)
  else
    list = entries(opts[:dir], nil, 1)
  end
  existing = list.to_h { |x| [x, true] }
  used = {}
  list.filter_map do |rel|
    next if File.basename(rel).start_with?('.') && !rel.empty?
    m = re.match(rel)
    next unless m
    names = {}
    m.names.each { |n| names[n] = m[n] }
    out = format_pattern(output, m.to_a, names)
    out = preserve_extension(rel, out, opts)
    out = make_unique(out, existing, used, opts[:overwrite])
    used[out] = true
    [rel, out]
  end
rescue RegexpError => e
  die("error: regex parse error:\n    #{pattern}\nerror: #{e.message}")
end

def build_file_map(opts)
  data = parse_json_string_map(File.read(File.join(opts[:dir], opts[:map])))
  data.map { |input, output| [input, output] }
rescue StandardError => e
  die("[error] unable to read map file: #{e.message}")
end

def json_unescape(str)
  str.gsub(/\\(["\\\/bfnrt])|\\u([0-9a-fA-F]{4})/) do
    case Regexp.last_match(1)
    when '"' then '"'
    when '\\' then '\\'
    when '/' then '/'
    when 'b' then "\b"
    when 'f' then "\f"
    when 'n' then "\n"
    when 'r' then "\r"
    when 't' then "\t"
    else [Regexp.last_match(2).to_i(16)].pack('U')
    end
  end
end

def json_escape(str)
  str.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
    case ch
    when '"' then '\"'
    when '\\' then '\\\\'
    when "\b" then '\b'
    when "\f" then '\f'
    when "\n" then '\n'
    when "\r" then '\r'
    when "\t" then '\t'
    end
  end
end

def parse_json_string_map(text)
  s = text.strip
  raise 'expected JSON object' unless s.start_with?('{') && s.end_with?('}')
  inner = s[1...-1].strip
  return {} if inner.empty?

  pairs = []
  i = 0
  while i < inner.length
    i += 1 while inner[i] =~ /\s/
    raise 'expected string key' unless inner[i] == '"'
    j = i + 1
    j += 1 while j < inner.length && !(inner[j] == '"' && inner[j - 1] != '\\')
    key = json_unescape(inner[(i + 1)...j])
    i = j + 1
    i += 1 while inner[i] =~ /\s/
    raise 'expected colon' unless inner[i] == ':'
    i += 1
    i += 1 while inner[i] =~ /\s/
    raise 'expected string value' unless inner[i] == '"'
    j = i + 1
    j += 1 while j < inner.length && !(inner[j] == '"' && inner[j - 1] != '\\')
    val = json_unescape(inner[(i + 1)...j])
    pairs << [key, val]
    i = j + 1
    i += 1 while i < inner.length && inner[i] =~ /\s/
    if i < inner.length
      raise 'expected comma' unless inner[i] == ','
      i += 1
    end
  end
  pairs.to_h
end

def generate_json_string_map(hash)
  lines = hash.map { |k, v| "  \"#{json_escape(k)}\": \"#{json_escape(v)}\"" }
  "{\n#{lines.join(",\n")}\n}"
end

def print_table(rows)
  widths = ['Input', 'Output']
  rows.each do |a, b|
    widths[0] = a if a.length > widths[0].length
    widths[1] = b if b.length > widths[1].length
  end
  w1 = widths[0].length
  w2 = widths[1].length
  border = "+-#{'-' * w1}-+-#{'-' * w2}-+"
  puts border
  puts "| #{'Input'.ljust(w1)} | #{'Output'.ljust(w2)} |"
  puts border
  rows.each { |a, b| puts "| #{a.ljust(w1)} | #{b.ljust(w2)} |" }
  puts border
end

def apply_map(rows, opts)
  rows.each do |input, output|
    src = File.join(opts[:dir], input)
    dst = File.join(opts[:dir], output)
    FileUtils.mkdir_p(File.dirname(dst)) if opts[:mkdir]
    begin
      File.rename(src, dst)
    rescue SystemCallError => e
      die("[error] unable to rename '#{input}': #{e.message}")
    end
  end
end

opts = parse_args(ARGV)
opts[:dir] = File.expand_path(opts[:dir])
Dir.chdir(opts[:dir]) rescue die("[error] unable to access directory '#{opts[:dir]}'")

rows = nil
if opts[:map]
  rows = build_file_map(opts)
elsif opts[:sort]
  die("error: one output argument is required for sort mode.", 1) if opts[:positional].empty?
  rows = build_sort_map(opts, opts[:positional].last)
else
  if opts[:regex]
    die("error: one output argument is required for regex mode.", 1) if opts[:positional].empty?
    rows = build_regex_map(opts, opts[:regex], opts[:positional].last)
  elsif opts[:positional].length >= 2
    rows = build_regex_map(opts, opts[:positional][-2], opts[:positional][-1])
  else
    die("error: one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.\nusage: run './executable --help' for more information.")
  end
end

apply_map(rows, opts) unless opts[:test]
unless opts[:quiet]
  print_table(rows)
end
if opts[:generate]
  generated = {}
  rows.each { |input, output| generated[output] = input }
  File.write(File.join(opts[:dir], opts[:generate]), generate_json_string_map(generated) + "\n")
end
