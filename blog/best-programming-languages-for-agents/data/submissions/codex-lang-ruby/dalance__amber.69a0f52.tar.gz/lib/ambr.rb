#!/usr/bin/env ruby
# frozen_string_literal: true

require 'find'
require 'fileutils'

VERSION = 'ambr 0.6.0'

DEFAULTS = {
  regex: false,
  column: false,
  row: false,
  binary: false,
  statistics: false,
  skipped: false,
  interactive: true,
  recursive: true,
  symlink: true,
  color: true,
  file: true,
  skip_vcs: true,
  skip_gitignore: true,
  fixed_order: true,
  parent_ignore: true,
  key_from_file: false,
  rep_from_file: false,
  verbose: false,
  bin_check_bytes: 256
}.freeze

HELP = <<~TEXT
  ambr 0.6.0

  USAGE:
      executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...

  FLAGS:
          --key-from-file        Use file contents of KEYWORD as keyword for search
          --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement
          --verbose              Verbose message
      -r, --regex                Enable regular expression search
          --column               Enable column output
          --row                  Enable row output
          --binary               Enable binary file search
          --statistics           Enable statistics output
          --skipped              Enable skipped file output
          --preserve-time        Enable timestamp preserve
          --no-interactive       Disable interactive replace
          --no-recursive         Disable recursive directory search
          --no-symlink           Disable symbolic link follow
          --no-color             Disable colored output
          --no-file              Disable filename output
          --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip
          --no-skip-gitignore    Disable .gitignore skip
          --no-fixed-order       Disable output order guarantee
          --no-parent-ignore     Disable .*ignore file search at parent directories
          --tbm                  [Experimental] Enable TBM matcher
          --sse                  [Experimental] Enable SSE 4.2
      -h, --help                 Prints help information
      -V, --version              Prints version information

  OPTIONS:
          --max-threads <NUM>          Number of max threads [default: 4]
          --size-per-thread <BYTES>    File size per one thread [default: 1048576]
          --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]
          --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]

  ARGS:
      <KEYWORD>        Keyword for search
      <REPLACEMENT>    Keyword for replace
      <PATHS>...       Search paths
TEXT

class PatternSet
  def initialize
    @patterns = []
  end

  def add(pattern)
    @patterns << pattern
  end

  def ignored?(rel)
    rel = rel.sub(%r{\A\./}, '')
    @patterns.any? do |pat|
      next false if pat.empty?
      neg = pat.start_with?('!')
      body = neg ? pat[1..] : pat
      next false if neg
      match_pattern?(body, rel)
    end
  end

  private

  def match_pattern?(pat, rel)
    dir_only = pat.end_with?('/')
    pat = pat.chomp('/')
    base = File.basename(rel)
    if pat.include?('/')
      File.fnmatch?(pat, rel, File::FNM_PATHNAME | File::FNM_DOTMATCH) ||
        rel.start_with?(pat + '/')
    else
      base == pat ||
        File.fnmatch?(pat, base, File::FNM_DOTMATCH) ||
        (!dir_only && rel.split('/').any? { |part| File.fnmatch?(pat, part, File::FNM_DOTMATCH) })
    end
  end
end

def fail_usage(message)
  warn message
  exit 1
end

def parse_args(argv)
  opts = DEFAULTS.dup
  positional = []
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-h', '--help'
      puts HELP
      exit 0
    when '-V', '--version'
      puts VERSION
      exit 0
    when '-r', '--regex' then opts[:regex] = true
    when '--key-from-file' then opts[:key_from_file] = true
    when '--rep-from-file' then opts[:rep_from_file] = true
    when '--verbose' then opts[:verbose] = true
    when '--column' then opts[:column] = true
    when '--row' then opts[:row] = true
    when '--binary' then opts[:binary] = true
    when '--statistics' then opts[:statistics] = true
    when '--skipped' then opts[:skipped] = true
    when '--preserve-time' then opts[:preserve_time] = true
    when '--no-interactive' then opts[:interactive] = false
    when '--no-recursive' then opts[:recursive] = false
    when '--no-symlink' then opts[:symlink] = false
    when '--no-color' then opts[:color] = false
    when '--no-file' then opts[:file] = false
    when '--no-skip-vcs' then opts[:skip_vcs] = false
    when '--no-skip-gitignore' then opts[:skip_gitignore] = false
    when '--no-fixed-order' then opts[:fixed_order] = false
    when '--no-parent-ignore' then opts[:parent_ignore] = false
    when '--tbm', '--sse'
      # Accepted for compatibility; the matcher is selected internally.
    when '--max-threads', '--size-per-thread', '--bin-check-bytes', '--mmap-bytes'
      fail_usage("error: The argument '#{arg}' requires a value") if i + 1 >= argv.length
      opts[:bin_check_bytes] = argv[i + 1].to_i if arg == '--bin-check-bytes'
      i += 1
    else
      if arg.start_with?('--')
        warn "error: Found argument '#{arg}' which wasn't expected, or isn't valid in this context"
        warn
        warn 'USAGE:'
        warn '    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...'
        warn
        warn 'For more information try --help'
        exit 1
      end
      positional << arg
    end
    i += 1
  end

  missing = []
  missing << '    <KEYWORD>' if positional.length < 1
  missing << '    <REPLACEMENT>' if positional.length < 2
  unless missing.empty?
    warn 'error: The following required arguments were not provided:'
    warn missing.join("\n")
    warn
    warn 'USAGE:'
    warn '    executable <KEYWORD> <REPLACEMENT> --bin-check-bytes <BYTES> --max-threads <NUM> --mmap-bytes <BYTES> --size-per-thread <BYTES>'
    warn
    warn 'For more information try --help'
    exit 1
  end

  key = positional[0]
  rep = positional[1]
  key = File.binread(key) if opts[:key_from_file]
  rep = File.binread(rep) if opts[:rep_from_file]
  paths = positional[2..] || []
  paths = ['.'] if paths.empty?
  [opts, key, rep, paths]
end

def load_ignore_file(path, set)
  return unless File.file?(path)

  File.readlines(path, chomp: true).each do |line|
    line = line.strip
    next if line.empty? || line.start_with?('#')

    set.add(line)
  end
rescue SystemCallError
end

def parent_ignores(start)
  dirs = []
  cur = File.expand_path(start)
  cur = File.dirname(cur) unless File.directory?(cur)
  loop do
    dirs << cur
    parent = File.dirname(cur)
    break if parent == cur

    cur = parent
  end
  dirs.reverse
end

def binary_file?(path, bytes)
  data = File.open(path, 'rb') { |f| f.read(bytes) } || ''
  data.include?("\x00")
rescue SystemCallError
  false
end

def collect_files(paths, opts)
  files = []
  skipped = []
  vcs = %w[.git .hg .svn .bzr]

  paths.each do |raw|
    path = raw
    unless File.exist?(path) || File.symlink?(path)
      skipped << [path, 'No such file or directory']
      next
    end

    ignore = PatternSet.new
    if opts[:skip_gitignore]
      if opts[:parent_ignore]
        parent_ignores(path).each do |dir|
          load_ignore_file(File.join(dir, '.gitignore'), ignore)
          load_ignore_file(File.join(dir, '.ignore'), ignore)
        end
      elsif File.directory?(path)
        load_ignore_file(File.join(path, '.gitignore'), ignore)
        load_ignore_file(File.join(path, '.ignore'), ignore)
      end
    end

    if File.file?(path) || File.symlink?(path)
      files << path if opts[:symlink] || !File.symlink?(path)
      next
    end

    if opts[:recursive]
      Find.find(path) do |entry|
        base = File.basename(entry)
        if entry != path && File.directory?(entry)
          if (!opts[:symlink] && File.symlink?(entry)) || (opts[:skip_vcs] && vcs.include?(base))
            skipped << [entry, 'Skipped directory']
            Find.prune
          end
          rel = entry.sub(%r{\A#{Regexp.escape(path)}/?}, '')
          if opts[:skip_gitignore] && ignore.ignored?(rel)
            skipped << [entry, 'Skipped by ignore file']
            Find.prune
          end
          next
        end
        next unless File.file?(entry)

        rel = entry.sub(%r{\A#{Regexp.escape(path)}/?}, '')
        if opts[:skip_gitignore] && ignore.ignored?(rel)
          skipped << [entry, 'Skipped by ignore file']
          next
        end
        files << entry
      end
    else
      Dir.children(path).sort.each do |child|
        entry = File.join(path, child)
        next unless File.file?(entry)

        files << entry
      end
    end
  end

  files.uniq!
  files.sort! if opts[:fixed_order]
  [files, skipped]
end

def make_regex(key, regex)
  regex ? Regexp.new(key) : Regexp.new(Regexp.escape(key))
rescue RegexpError => e
  warn "regex parse error: #{e.message}"
  exit 1
end

def expand_replacement(template, match)
  template.gsub(/\$\{?([A-Za-z_][A-Za-z0-9_]*|\d+)\}?/) do
    token = Regexp.last_match(1)
    if token =~ /\A\d+\z/
      match[token.to_i] || ''
    else
      begin
        match[token] || ''
      rescue IndexError
        ''
      end
    end
  end
end

def line_col(text, offset)
  prefix = text.byteslice(0, offset) || ''
  row = prefix.count("\n") + 1
  last_nl = prefix.rindex("\n")
  col = last_nl ? prefix.bytesize - last_nl : prefix.bytesize + 1
  [row, col]
end

def colorize(text, code, enabled)
  enabled ? "\e[#{code}m#{text}\e[0m" : text
end

def print_match(path, row, col, line, keyword_re, opts)
  parts = []
  parts << colorize(path, '32', opts[:color]) if opts[:file]
  parts << colorize(row.to_s, '33', opts[:color]) if opts[:row]
  parts << colorize(col.to_s, '33', opts[:color]) if opts[:column]
  if parts.empty?
    puts line
  else
    puts "#{parts.join(':')}:#{line}"
  end
end

def ask_replace
  $stdout.print 'Replace keyword? ( Yes[Y], No[N], All[A], Quit[Q] ): '
  $stdout.flush
  answer = $stdin.gets
  return :quit if answer.nil?

  case answer.strip.downcase
  when 'y', 'yes' then :yes
  when 'a', 'all' then :all
  when 'q', 'quit' then :quit
  else :no
  end
end

opts, key, replacement, paths = parse_args(ARGV)
regex = make_regex(key, opts[:regex])
files, skipped = collect_files(paths, opts)

total_matches = 0
changed_files = 0
all = !opts[:interactive]

skipped.each { |path, reason| warn "#{path}: #{reason}" } if opts[:skipped]

files.each do |path|
  if !opts[:binary] && binary_file?(path, opts[:bin_check_bytes])
    warn "#{path}: Binary file skipped" if opts[:skipped]
    next
  end

  original_stat = File.stat(path)
  data = File.binread(path)
  matches = data.to_enum(:scan, regex).map { Regexp.last_match }
  next if matches.empty?

  replace_file = all
  matches.each do |m|
    row, col = line_col(data, m.begin(0))
    line_start = m.begin(0).zero? ? -1 : (data.rindex("\n", m.begin(0) - 1) || -1)
    line_end = data.index("\n", m.end(0)) || data.length
    line = data[(line_start + 1)...line_end]
    print_match(path, row, col, line, regex, opts)
  end

  if opts[:interactive] && !all
    case ask_replace
    when :yes then replace_file = true
    when :all
      all = true
      replace_file = true
    when :quit then break
    end
  end

  next unless replace_file

  new_data = data.gsub(regex) { |m| expand_replacement(replacement, Regexp.last_match) }
  next if new_data == data

  File.binwrite(path, new_data)
  File.utime(original_stat.atime, original_stat.mtime, path) if opts[:preserve_time]
  total_matches += matches.length
  changed_files += 1
end

if opts[:statistics]
  puts "#{changed_files} files replaced"
  puts "#{total_matches} matches replaced"
end

exit(total_matches.positive? ? 0 : 1)
