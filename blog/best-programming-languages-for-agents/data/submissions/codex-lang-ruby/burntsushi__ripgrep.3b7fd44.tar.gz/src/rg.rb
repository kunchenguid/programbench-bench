#!/usr/bin/env ruby
# frozen_string_literal: true

require 'find'
require 'fileutils'

VERSION = <<~TEXT
  ripgrep 14.1.1 (rev 719e15af5e)

  features:-pcre2
  simd(compile):+SSE2,-SSSE3,-AVX2
  simd(runtime):+SSE2,+SSSE3,+AVX2

  PCRE2 is not available in this build of ripgrep.
TEXT

SHORT_HELP = <<~TEXT
  ripgrep 14.1.1 (rev 719e15af5e)
  Andrew Gallant <jamslam@gmail.com>

  ripgrep (rg) recursively searches the current directory for lines matching
  a regex pattern. By default, ripgrep will respect gitignore rules and
  automatically skip hidden files/directories and binary files.

  Use -h for short descriptions and --help for more details.

  Project home page: https://github.com/BurntSushi/ripgrep

  USAGE:
    rg [OPTIONS] PATTERN [PATH ...]
TEXT

TYPE_GLOBS = {
  'c' => ['*.c', '*.h', '*.H'],
  'cpp' => ['*.cc', '*.cpp', '*.cxx', '*.hpp', '*.hh', '*.hxx', '*.C', '*.H'],
  'h' => ['*.h', '*.hh', '*.hpp'],
  'ruby' => ['*.rb', 'Rakefile', 'Gemfile', '*.gemspec'],
  'rb' => ['*.rb', 'Rakefile', 'Gemfile', '*.gemspec'],
  'python' => ['*.py', '*.pyw'],
  'py' => ['*.py', '*.pyw'],
  'javascript' => ['*.js', '*.jsx', '*.mjs', '*.cjs'],
  'js' => ['*.js', '*.jsx', '*.mjs', '*.cjs'],
  'typescript' => ['*.ts', '*.tsx'],
  'ts' => ['*.ts', '*.tsx'],
  'rust' => ['*.rs'],
  'rs' => ['*.rs'],
  'go' => ['*.go'],
  'java' => ['*.java'],
  'json' => ['*.json'],
  'yaml' => ['*.yaml', '*.yml'],
  'yml' => ['*.yaml', '*.yml'],
  'toml' => ['*.toml'],
  'markdown' => ['*.md', '*.markdown'],
  'md' => ['*.md', '*.markdown'],
  'html' => ['*.html', '*.htm'],
  'css' => ['*.css', '*.scss'],
  'shell' => ['*.sh', '*.bash', '*.zsh', '*.fish'],
  'sh' => ['*.sh', '*.bash', '*.zsh', '*.fish'],
  'make' => ['Makefile', '*.mk'],
  'docker' => ['*Dockerfile*'],
  'xml' => ['*.xml'],
  'txt' => ['*.txt']
}.freeze

class Opts
  attr_accessor :patterns, :pattern_files, :paths, :ignore_case, :smart_case,
                :fixed, :word, :line, :invert, :max_count, :text, :hidden,
                :no_ignore, :files, :type_list, :line_number, :with_filename,
                :no_filename, :count, :count_matches, :files_with_matches,
                :files_without_match, :only_matching, :replace, :after,
                :before, :context_separator, :heading, :quiet, :null,
                :json, :passthru, :globs, :iglob_case, :types, :not_types,
                :max_depth, :max_filesize, :sort, :sort_reverse, :column,
                :byte_offset, :trim, :include_zero, :vimgrep, :unrestricted

  def initialize
    @patterns = []
    @pattern_files = []
    @paths = []
    @ignore_case = false
    @smart_case = false
    @fixed = false
    @word = false
    @line = false
    @invert = false
    @max_count = nil
    @text = false
    @hidden = false
    @no_ignore = false
    @files = false
    @type_list = false
    @line_number = false
    @with_filename = false
    @no_filename = false
    @count = false
    @count_matches = false
    @files_with_matches = false
    @files_without_match = false
    @only_matching = false
    @replace = nil
    @after = 0
    @before = 0
    @context_separator = '--'
    @heading = false
    @quiet = false
    @null = false
    @json = false
    @passthru = false
    @globs = []
    @iglob_case = false
    @types = []
    @not_types = []
    @max_depth = nil
    @max_filesize = nil
    @sort = nil
    @sort_reverse = false
    @column = false
    @byte_offset = false
    @trim = false
    @include_zero = false
    @vimgrep = false
    @unrestricted = 0
  end
end

def die(msg)
  warn "rg: #{msg}"
  exit 2
end

def need_arg(args, i, flag)
  return [args[i + 1], i + 1] if i + 1 < args.length
  die "missing value for flag #{flag}: missing argument for option '#{flag}'"
end

def parse_size(s)
  m = s.to_s.match(/\A(\d+)([KMGTP]?)(?:B)?\z/i) or die "invalid size: #{s}"
  n = m[1].to_i
  mult = { '' => 1, 'K' => 1024, 'M' => 1024**2, 'G' => 1024**3, 'T' => 1024**4, 'P' => 1024**5 }[m[2].upcase]
  n * mult
end

def parse_args(argv)
  opts = Opts.new
  positional = []
  i = 0
  literal = false
  while i < argv.length
    a = argv[i]
    if literal
      positional << a
    elsif a == '--'
      literal = true
    elsif a == '-h' || a == '--help'
      puts SHORT_HELP
      exit 0
    elsif a == '-V' || a == '--version'
      puts VERSION
      exit 0
    elsif a == '--pcre2-version'
      puts 'PCRE2 is not available in this build of ripgrep.'
      exit 0
    elsif a == '--type-list'
      opts.type_list = true
    elsif a == '--files'
      opts.files = true
    elsif a.start_with?('--')
      name, val = a.split('=', 2)
      case name
      when '--regexp' then val, i = need_arg(argv, i, '--regexp') if val.nil?; opts.patterns << val
      when '--file' then val, i = need_arg(argv, i, '--file') if val.nil?; opts.pattern_files << val
      when '--ignore-case' then opts.ignore_case = true
      when '--case-sensitive' then opts.ignore_case = false; opts.smart_case = false
      when '--smart-case' then opts.smart_case = true
      when '--fixed-strings' then opts.fixed = true
      when '--word-regexp' then opts.word = true
      when '--line-regexp' then opts.line = true
      when '--invert-match' then opts.invert = true
      when '--max-count' then val, i = need_arg(argv, i, '--max-count') if val.nil?; opts.max_count = val.to_i
      when '--text', '--binary' then opts.text = true
      when '--hidden' then opts.hidden = true
      when '--no-ignore' then opts.no_ignore = true
      when '--glob', '--iglob' then val, i = need_arg(argv, i, name) if val.nil?; opts.globs << val; opts.iglob_case ||= (name == '--iglob')
      when '--type' then val, i = need_arg(argv, i, '--type') if val.nil?; opts.types << val
      when '--type-not' then val, i = need_arg(argv, i, '--type-not') if val.nil?; opts.not_types << val
      when '--max-depth' then val, i = need_arg(argv, i, '--max-depth') if val.nil?; opts.max_depth = val.to_i
      when '--max-filesize' then val, i = need_arg(argv, i, '--max-filesize') if val.nil?; opts.max_filesize = parse_size(val)
      when '--line-number' then opts.line_number = true
      when '--no-line-number' then opts.line_number = false
      when '--with-filename' then opts.with_filename = true
      when '--no-filename' then opts.no_filename = true
      when '--count' then opts.count = true
      when '--count-matches' then opts.count_matches = true
      when '--files-with-matches' then opts.files_with_matches = true
      when '--files-without-match' then opts.files_without_match = true
      when '--only-matching' then opts.only_matching = true
      when '--replace' then val, i = need_arg(argv, i, '--replace') if val.nil?; opts.replace = val
      when '--after-context' then val, i = need_arg(argv, i, '--after-context') if val.nil?; opts.after = val.to_i
      when '--before-context' then val, i = need_arg(argv, i, '--before-context') if val.nil?; opts.before = val.to_i
      when '--context' then val, i = need_arg(argv, i, '--context') if val.nil?; opts.after = opts.before = val.to_i
      when '--context-separator' then val, i = need_arg(argv, i, '--context-separator') if val.nil?; opts.context_separator = val
      when '--heading' then opts.heading = true
      when '--quiet' then opts.quiet = true
      when '--null' then opts.null = true
      when '--json' then opts.json = true
      when '--passthru' then opts.passthru = true
      when '--sort' then val, i = need_arg(argv, i, '--sort') if val.nil?; opts.sort = val
      when '--sortr' then val, i = need_arg(argv, i, '--sortr') if val.nil?; opts.sort = val; opts.sort_reverse = true
      when '--sort-files' then opts.sort = 'path'
      when '--column' then opts.column = true
      when '--byte-offset' then opts.byte_offset = true
      when '--trim' then opts.trim = true
      when '--include-zero' then opts.include_zero = true
      when '--vimgrep' then opts.vimgrep = true; opts.line_number = true; opts.column = true; opts.with_filename = true
      when '--pcre2', '--auto-hybrid-regex'
        die 'PCRE2 is not available in this build of ripgrep'
      when '--color', '--colors', '--engine', '--encoding', '--pre', '--pre-glob',
           '--dfa-size-limit', '--regex-size-limit', '--threads', '--mmap',
           '--no-mmap', '--multiline', '--multiline-dotall', '--no-unicode',
           '--null-data', '--crlf', '--search-zip', '--no-search-zip',
           '--glob-case-insensitive', '--ignore-file', '--ignore-file-case-insensitive',
           '--no-ignore-dot', '--no-ignore-exclude', '--no-ignore-files',
           '--no-ignore-global', '--no-ignore-parent', '--no-ignore-vcs',
           '--no-require-git', '--one-file-system', '--type-add', '--type-clear',
           '--block-buffered', '--line-buffered', '--field-context-separator',
           '--field-match-separator', '--path-separator', '--pretty',
           '--max-columns', '--max-columns-preview', '--hostname-bin',
           '--hyperlink-format', '--debug', '--trace', '--stats', '--no-messages',
           '--no-ignore-messages', '--generate', '--stop-on-nonmatch',
           '--no-pcre2-unicode'
        val, i = need_arg(argv, i, name) if val.nil? && %w[--color --colors --engine --encoding --pre --pre-glob --dfa-size-limit --regex-size-limit --threads --ignore-file --type-add --type-clear --field-context-separator --field-match-separator --path-separator --max-columns --hostname-bin --hyperlink-format --generate].include?(name)
      else
        die "unrecognized flag #{a}"
      end
    elsif a.start_with?('-') && a != '-'
      chars = a[1..]
      j = 0
      while j < chars.length
        c = chars[j]
        rest = chars[(j + 1)..]
        case c
        when 'e' then val = rest.empty? ? (i += 1; argv[i]) : rest; die "missing value for flag -e: missing argument for option '-e'" if val.nil?; opts.patterns << val; break
        when 'f' then val = rest.empty? ? (i += 1; argv[i]) : rest; die "missing value for flag -f: missing argument for option '-f'" if val.nil?; opts.pattern_files << val; break
        when 'i' then opts.ignore_case = true
        when 's' then opts.ignore_case = false; opts.smart_case = false
        when 'S' then opts.smart_case = true
        when 'F' then opts.fixed = true
        when 'w' then opts.word = true
        when 'x' then opts.line = true
        when 'v' then opts.invert = true
        when 'm' then val = rest.empty? ? (i += 1; argv[i]) : rest; opts.max_count = val.to_i; break
        when 'a' then opts.text = true
        when 'u' then opts.unrestricted += 1
        when '.' then opts.hidden = true
        when 'L' then nil
        when 'g' then val = rest.empty? ? (i += 1; argv[i]) : rest; opts.globs << val; break
        when 't' then val = rest.empty? ? (i += 1; argv[i]) : rest; opts.types << val; break
        when 'T' then val = rest.empty? ? (i += 1; argv[i]) : rest; opts.not_types << val; break
        when 'd' then val = rest.empty? ? (i += 1; argv[i]) : rest; opts.max_depth = val.to_i; break
        when 'n' then opts.line_number = true
        when 'N' then opts.line_number = false
        when 'H' then opts.with_filename = true
        when 'I' then opts.no_filename = true
        when 'c' then opts.count = true
        when 'l' then opts.files_with_matches = true
        when 'o' then opts.only_matching = true
        when 'r' then val = rest.empty? ? (i += 1; argv[i]) : rest; opts.replace = val; break
        when 'A' then val = rest.empty? ? (i += 1; argv[i]) : rest; opts.after = val.to_i; break
        when 'B' then val = rest.empty? ? (i += 1; argv[i]) : rest; opts.before = val.to_i; break
        when 'C' then val = rest.empty? ? (i += 1; argv[i]) : rest; opts.after = opts.before = val.to_i; break
        when 'q' then opts.quiet = true
        when '0' then opts.null = true
        when 'b' then opts.byte_offset = true
        when 'P' then die 'PCRE2 is not available in this build of ripgrep'
        when 'p' then opts.heading = true; opts.line_number = true
        when 'z', 'U', 'j', 'M', 'E' then break if %w[j M E].include?(c) && !rest.empty?
        else die "unrecognized flag -#{c}"
        end
        j += 1
      end
    else
      positional << a
    end
    i += 1
  end
  opts.no_ignore = true if opts.unrestricted >= 1
  opts.hidden = true if opts.unrestricted >= 2
  opts.text = true if opts.unrestricted >= 3
  if opts.patterns.empty? && opts.pattern_files.empty? && !opts.files && !opts.type_list
    die 'ripgrep requires at least one pattern to execute a search' if positional.empty?
    opts.patterns << positional.shift
  end
  opts.paths = positional
  opts
end

def type_list
  TYPE_GLOBS.keys.sort.each { |k| puts "#{k}: #{TYPE_GLOBS[k].join(', ')}" }
end

def load_patterns(opts)
  pats = opts.patterns.dup
  opts.pattern_files.each do |pf|
    src = pf == '-' ? STDIN.read : File.read(pf)
    src.each_line { |l| pats << l.chomp }
  rescue Errno::ENOENT
    die "#{pf}: IO error for operation on #{pf}: No such file or directory (os error 2)"
  end
  pats
end

def build_regex(opts, pats)
  flags = 0
  smart = opts.smart_case && pats.none? { |p| p =~ /[[:upper:]]/ }
  flags |= Regexp::IGNORECASE if opts.ignore_case || smart
  bodies = pats.map { |p| opts.fixed ? Regexp.escape(p) : p }
  body = bodies.empty? ? '(?!)' : bodies.join('|')
  body = "(?:#{body})"
  body = "(?<![[:word:]])#{body}(?![[:word:]])" if opts.word
  body = "\\A#{body}\\z" if opts.line
  Regexp.new(body, flags)
rescue RegexpError => e
  die "regex parse error:\n    #{e.message}"
end

def basename_hidden?(path)
  File.basename(path).start_with?('.') && !%w[. ..].include?(File.basename(path))
end

def read_ignore_patterns(root)
  pats = []
  return pats unless File.directory?(root)
  %w[.gitignore .ignore .rgignore].each do |f|
    p = File.join(root, f)
    next unless File.file?(p)
    File.readlines(p, chomp: true).each do |line|
      line = line.strip
      next if line.empty? || line.start_with?('#')
      pats << line
    end
  rescue StandardError
  end
  pats
end

def glob_match?(glob, path)
  neg = glob.start_with?('!')
  g = neg ? glob[1..] : glob
  base = File.basename(path)
  matched = File.fnmatch?(g, path, File::FNM_PATHNAME | File::FNM_EXTGLOB) || File.fnmatch?(g, base, File::FNM_EXTGLOB)
  [matched, neg]
end

def ignored_by_patterns?(patterns, path)
  ignored = false
  patterns.each do |pat|
    matched, neg = glob_match?(pat, path)
    ignored = !neg if matched
  end
  ignored
end

def matches_type?(path, type)
  globs = TYPE_GLOBS[type] || []
  globs.any? { |g| File.fnmatch?(g, File.basename(path), File::FNM_EXTGLOB) || File.fnmatch?(g, path, File::FNM_EXTGLOB) }
end

def selected_by_globs?(opts, path)
  return true if opts.globs.empty?
  include_seen = opts.globs.any? { |g| !g.start_with?('!') }
  ok = !include_seen
  opts.globs.each do |g|
    gp = opts.iglob_case ? g.downcase : g
    pp = opts.iglob_case ? path.downcase : path
    matched, neg = glob_match?(gp, pp)
    ok = !neg if matched
  end
  ok
end

def collect_files(paths, opts)
  paths = ['.'] if paths.empty?
  out = []
  errors = 0
  roots_ignores = {}
  paths.each do |root|
    unless File.exist?(root)
      warn "rg: #{root}: IO error for operation on #{root}: No such file or directory (os error 2)"
      errors += 1
      next
    end
    if File.file?(root) || File.symlink?(root)
      out << root
      next
    end
    roots_ignores[root] = opts.no_ignore ? [] : read_ignore_patterns(root)
    base_depth = root.split(File::SEPARATOR).reject(&:empty?).length
    Find.find(root) do |p|
      next if p == root
      rel_depth = p.split(File::SEPARATOR).reject(&:empty?).length - base_depth
      if opts.max_depth && rel_depth > opts.max_depth
        Find.prune if File.directory?(p)
        next
      end
      if !opts.hidden && basename_hidden?(p)
        Find.prune if File.directory?(p)
        next
      end
      if !opts.no_ignore && ignored_by_patterns?(roots_ignores[root], p)
        Find.prune if File.directory?(p)
        next
      end
      next unless File.file?(p)
      out << p
    end
  end
  out = out.select { |p| selected_by_globs?(opts, p) }
  out = out.select { |p| opts.types.empty? || opts.types.any? { |t| matches_type?(p, t) } }
  out = out.reject { |p| opts.not_types.any? { |t| matches_type?(p, t) } }
  out = out.reject { |p| opts.max_filesize && File.size?(p).to_i > opts.max_filesize }
  out.sort!
  out.reverse! if opts.sort_reverse
  [out, errors]
end

def binary_file?(path)
  File.open(path, 'rb') { |f| f.read(8192).to_s.include?("\0") }
rescue StandardError
  false
end

def prefix_for(path, line_no, byte_off, col, opts, show_filename, sep = ':')
  parts = []
  parts << path if show_filename
  parts << line_no.to_s if opts.line_number
  parts << col.to_s if opts.column && col
  parts << byte_off.to_s if opts.byte_offset && byte_off
  return '' if parts.empty?
  parts.join(sep) + sep
end

def display_path(path)
  path.sub(%r{\A\./}, '')
end

def json_escape(s)
  s.to_s.gsub(/["\\\b\f\n\r\t]/) do |c|
    { '"' => '\"', '\\' => '\\\\', "\b" => '\\b', "\f" => '\\f',
      "\n" => '\\n', "\r" => '\\r', "\t" => '\\t' }[c]
  end.gsub(/[\x00-\x1f]/) { |c| '\\u%04x' % c.ord }
end

def json_generate(obj)
  case obj
  when Hash
    '{' + obj.map { |k, v| "#{json_generate(k.to_s)}:#{json_generate(v)}" }.join(',') + '}'
  when Array
    '[' + obj.map { |v| json_generate(v) }.join(',') + ']'
  when String
    '"' + json_escape(obj) + '"'
  when Integer, Float
    obj.to_s
  when TrueClass
    'true'
  when FalseClass
    'false'
  when NilClass
    'null'
  else
    '"' + json_escape(obj.to_s) + '"'
  end
end

def emit_json(obj)
  puts json_generate(obj)
end

def search_file(path, re, opts, show_filename)
  dpath = display_path(path)
  return [false, 0] if !opts.text && binary_file?(path)
  raw = File.binread(path)
  lines = raw.lines
  matches = []
  offset = 0
  lines.each_with_index do |line, idx|
    text = line.chomp("\n")
    text = text.chomp("\r")
    m = !!(text =~ re)
    m = !m if opts.invert
    if opts.passthru || m
      matches << [idx, line, offset, m]
      break if opts.max_count && matches.count { |x| x[3] } >= opts.max_count
    end
    offset += line.bytesize
  end
  matched_lines = matches.count { |x| x[3] }
  match_count = matches.sum { |_, line, _, m| m ? line.scan(re).length : 0 }
  has_match = matched_lines.positive?
  return [has_match, matched_lines] if opts.quiet

  if opts.count || opts.count_matches
    n = opts.count_matches ? match_count : matched_lines
    puts "#{show_filename ? "#{dpath}:" : ''}#{n}" if n.positive? || opts.include_zero || show_filename
    return [has_match, matched_lines]
  end
  if opts.files_with_matches || opts.files_without_match
    want = opts.files_with_matches ? has_match : !has_match
    if want
      print dpath
      print(opts.null ? "\0" : "\n")
    end
    return [has_match, matched_lines]
  end

  if opts.json
    emit_json(type: 'begin', data: { path: { text: dpath } })
  elsif opts.heading && show_filename && has_match
    puts dpath
  end

  printed = {}
  matches.each do |idx, line, off, is_match|
    next unless opts.passthru || is_match
    from = [idx - opts.before, 0].max
    to = [idx + opts.after, lines.length - 1].min
    (from..to).each do |j|
      next if printed[j]
      printed[j] = true
      l = lines[j]
      txt = l.chomp("\n").chomp("\r")
      context_match = (j == idx && is_match)
      if opts.json
        subs = []
        txt.to_enum(:scan, re).each do
          md = Regexp.last_match
          subs << { match: { text: md[0] }, start: md.begin(0), end: md.end(0) }
        end
        emit_json(type: context_match ? 'match' : 'context',
                  data: { path: { text: dpath }, lines: { text: l },
                          line_number: j + 1, absolute_offset: off,
                          submatches: subs })
        next
      end
      body = opts.trim ? txt.sub(/\A\s+/, '') : txt
      if opts.replace && context_match
        body = body.gsub(re, opts.replace)
      end
      if opts.only_matching && context_match
        txt.scan(re) do
          md = Regexp.last_match
          col = md.begin(0) + 1
          puts prefix_for(dpath, j + 1, off + md.begin(0), col, opts, show_filename) + (opts.replace ? md[0].gsub(re, opts.replace) : md[0])
        end
      else
        sep = context_match ? ':' : '-'
        puts prefix_for(dpath, j + 1, off, nil, opts, show_filename, sep) + body
      end
    end
  end
  if opts.json
    emit_json(type: 'end', data: { path: { text: dpath }, binary_offset: nil,
                                   stats: { elapsed: { secs: 0, nanos: 0, human: '0.000000s' },
                                            searches: 1, searches_with_match: has_match ? 1 : 0,
                                            bytes_searched: raw.bytesize, bytes_printed: 0,
                                            matched_lines: matched_lines, matches: match_count } })
  elsif opts.heading && show_filename && has_match
    puts
  end
  [has_match, matched_lines]
rescue Errno::ENOENT
  warn "rg: #{path}: IO error for operation on #{path}: No such file or directory (os error 2)"
  [false, 0, true]
rescue Errno::EACCES
  warn "rg: #{path}: Permission denied (os error 13)"
  [false, 0, true]
end

def search_stdin(re, opts, initial = nil)
  data = initial.nil? ? STDIN.read : initial + STDIN.read
  any = false
  data.lines.each_with_index do |line, idx|
    txt = line.chomp("\n").chomp("\r")
    m = !!(txt =~ re)
    m = !m if opts.invert
    next unless m || opts.passthru
    any ||= m
    next if opts.quiet
    if opts.only_matching && m
      txt.scan(re) { puts Regexp.last_match[0] }
    elsif opts.replace && m
      puts txt.gsub(re, opts.replace)
    else
      puts "#{opts.line_number ? "#{idx + 1}:" : ''}#{txt}"
    end
  end
  any
end

opts = parse_args(ARGV)
if opts.type_list
  type_list
  exit 0
end

patterns = load_patterns(opts)
re = build_regex(opts, patterns)

stdin_chunk = nil
if opts.paths.empty? && !STDIN.tty? && !opts.files && IO.select([STDIN], nil, nil, 0)
  chunk = STDIN.read_nonblock(4096, exception: false)
  stdin_chunk = chunk if chunk && chunk != :wait_readable && !chunk.empty?
end
if stdin_chunk
  exit(search_stdin(re, opts, stdin_chunk) ? 0 : 1)
end

files, errors = collect_files(opts.paths, opts)
if opts.files
  files.each { |f| print display_path(f); print(opts.null ? "\0" : "\n") }
  exit(errors.positive? ? 2 : 0)
end

show_filename = opts.with_filename || (!opts.no_filename && files.length > 1)
any = false
files.each do |f|
  res = search_file(f, re, opts, show_filename)
  has = res[0]
  err = res[2]
  errors += 1 if err
  any ||= has
  break if opts.quiet && any
end
if opts.json
  emit_json(type: 'summary', data: { elapsed_total: { human: '0.000000s', nanos: 0, secs: 0 },
                                    stats: { bytes_printed: 0, bytes_searched: 0,
                                             elapsed: { human: '0.000000s', nanos: 0, secs: 0 },
                                             matched_lines: 0, matches: 0,
                                             searches: files.length, searches_with_match: any ? 1 : 0 } })
end
exit(errors.positive? ? 2 : (any ? 0 : 1))
