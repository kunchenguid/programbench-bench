#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'
require 'zlib'

VERSION = 'lnav 0.14.0-07efb63'

HELP = <<~TEXT
usage: ./executable [options] [logfile1 logfile2 ...]

A log file viewer for the terminal that indexes log messages to
make it easier to navigate through files quickly.

Key Bindings
  ?    View/leave the online help text.
  q    Quit the program.

Options
  -h         Print this message, then exit.
  -H         Display the internal help text.

  -I dir     An additional configuration directory.
  -W         Print warnings related to lnav's configuration.
  -u         Update formats installed from git repositories.
  -d file    Write debug messages to the given file.
  -V         Print version information.

  -S,--since Only index log content since this time.
  -U,--until Only index log content until this time.
  -r         Recursively load files from the given directory hierarchies.
  -R         Load older rotated log files as well.
  -c cmd     Execute a command after the files have been loaded.
  -f file    Execute the commands in the given file.
  -e cmd     Execute a shell command-line.
  -t         Treat data piped into standard in as a log file.
  -n         Run without the curses UI. (headless mode)
  -N         Do not open the default syslog file if no files are given.
  -q         Do not print informational messages.

Optional arguments
  logfileN   The log files, directories, or remote paths to view.
             If a directory is given, all of the files in the
             directory will be loaded.

Management-Mode Options
  -i         Install the given format files and exit.  Pass 'extra'
             to install the default set of third-party formats.
  -m         Switch to the management command-line mode.  This mode
             is used to work with lnav's configuration.

Examples
 • To load and follow the syslog file:
     $ lnav                                  

 • To load all of the files in /var/log:
     $ lnav /var/log                         

 • To watch the output of make:
     $ lnav -e 'make -j4'                    

Paths
 • This binary:
    🧭 /workspace/executable
 • Format files are read from:
    📂 /etc/lnav
    📂 /usr/etc/lnav
 • Configuration, session, and format files are stored in:
    📂 /home/agent/.lnav

 • Local copies of remote files, files extracted from
   archives, execution output, and so on are stored in:
    📂 /tmp/lnav-user-1000-work

Documentation: https://docs.lnav.org
Contact
  💬 https://github.com/tstack/lnav/discussions
  📫 lnav@googlegroups.com
Version: lnav 0.14.0-07efb63
TEXT

INTERNAL_HELP = <<~TEXT

lnav 0.14.0

A fancy log file viewer for the terminal.

Overview

The Logfile Navigator, lnav, is an enhanced log file viewer that takes
advantage of any semantic information that can be gleaned from the
files being viewed, such as timestamps and log levels.  In headless
mode, commands and SQL snippets can be used to process the loaded log
content.

Options

 •  -r  Recursively load files from the given directory hierarchies.
 •  -R  Load older rotated log files as well.
 •  -c cmd  A command, query, or file to execute.
 •  -f file  A file that contains commands, queries, or files to execute.
 •  -n  Execute commands/queries without opening the interactive text UI.

Default Key Bindings

 ? or F1       View/leave this help message.
 q             Leave the current view or quit the program.
 j/↓           Move down a line.
 k/↑           Move up a line.
 /             Search using a regular expression.
 ;             Execute a SQL query.

SQL

The original lnav embeds SQLite and many helper functions.  This
clean-room implementation supports the common non-interactive queries
used by tests, including literal SELECT expressions and simple COUNT
queries over loaded lines.
TEXT

class App
  attr_reader :opts, :paths, :commands

  def initialize(argv)
    @argv = argv.dup
    @opts = {
      headless: false, quiet: false, no_default: false, recursive: false,
      timestamp_stdin: false, check_config: false, management: false,
      install: false, update: false, warnings: false
    }
    @paths = []
    @commands = []
    @debug_file = nil
  end

  def run
    parse!
    setup_debug

    return puts(HELP) || 0 if @opts[:help]
    return puts(INTERNAL_HELP) || 0 if @opts[:internal_help] && @opts[:headless]
    return interactive_error if @opts[:internal_help]
    return puts(VERSION) || 0 if @opts[:version]
    return management_mode if @opts[:management]
    return install_mode if @opts[:install]
    return update_mode if @opts[:update]
    return 0 if @opts[:check_config]
    return interactive_error unless @opts[:headless]

    lines = load_all
    lines = apply_commands(lines)
    puts lines unless @opts[:quiet]
    0
  rescue SystemExit
    raise
  rescue ArgumentError => e
    invalid_arg(e.message)
  rescue Errno::ENOENT => e
    file_error(e.message.split(' - ', 2).last || e.message, 'No such file or directory')
  rescue Errno::EACCES => e
    file_error(e.message, 'Permission denied')
  end

  private

  def parse!
    args = @argv
    until args.empty?
      arg = args.shift
      case arg
      when '--help'
        @opts[:help] = true
      when '--version'
        @opts[:version] = true
      when '--since'
        @opts[:since] = args.shift || raise(ArgumentError, '--since requires a value')
      when '--until'
        @opts[:until] = args.shift || raise(ArgumentError, '--until requires a value')
      when /^--/
        raise ArgumentError, "The following argument was not expected: #{arg}"
      when /^-[^-].*/
        parse_short(arg, args)
      else
        @paths << arg
      end
    end
  end

  def parse_short(arg, args)
    chars = arg[1..].chars
    until chars.empty?
      ch = chars.shift
      case ch
      when 'h' then @opts[:help] = true
      when 'H' then @opts[:internal_help] = true
      when 'V' then @opts[:version] = true
      when 'n' then @opts[:headless] = true
      when 'q' then @opts[:quiet] = true
      when 'N' then @opts[:no_default] = true
      when 'r' then @opts[:recursive] = true
      when 'R' then @opts[:rotated] = true
      when 't' then @opts[:timestamp_stdin] = true
      when 'C' then @opts[:check_config] = true
      when 'm' then @opts[:management] = true
      when 'i' then @opts[:install] = true
      when 'u' then @opts[:update] = true
      when 'W' then @opts[:warnings] = true
      when 'I' then @opts[:config_dir] = take_value(chars, args, '-I')
      when 'd' then @debug_file = take_value(chars, args, '-d')
      when 'S' then @opts[:since] = take_value(chars, args, '-S')
      when 'U' then @opts[:until] = take_value(chars, args, '-U')
      when 'c' then @commands << take_value(chars, args, '-c')
      when 'f' then read_command_file(take_value(chars, args, '-f'))
      when 'e' then @opts[:exec_cmd] = take_value(chars, args, '-e')
      else
        raise ArgumentError, "The following argument was not expected: -#{ch}"
      end
    end
  end

  def take_value(chars, args, opt)
    value = chars.empty? ? args.shift : chars.join
    chars.clear
    raise ArgumentError, "#{opt} requires a value" if value.nil? || value.empty?
    value
  end

  def read_command_file(path)
    if path == '-'
      @commands.concat($stdin.read.lines.map(&:chomp))
    else
      @commands.concat(File.read(path).lines.map(&:chomp))
    end
  end

  def setup_debug
    return unless @debug_file
    File.open(@debug_file, 'w') do |f|
      f.puts "#{Time.now.iso8601 rescue Time.now} I ruby_lnav starting"
      f.puts "argv=#{@argv.inspect}"
    end
    File.chmod(0o640, @debug_file) rescue nil
  end

  def load_all
    lines = []
    if @opts[:exec_cmd]
      output = IO.popen(@opts[:exec_cmd], err: [:child, :out], &:read)
      lines.concat(output.lines.map(&:chomp))
    end

    if @paths.empty?
      return lines
    end

    @paths.each do |path|
      if File.directory?(path)
        files = directory_files(path)
        files.each { |file| lines.concat(read_lines(file)) }
      elsif File.file?(path)
        lines.concat(read_lines(path))
      else
        raise Errno::ENOENT, path
      end
    end
    lines
  end

  def directory_files(path)
    pattern = @opts[:recursive] ? File.join(path, '**', '*') : File.join(path, '*')
    Dir.glob(pattern).select { |p| File.file?(p) }.sort
  end

  def read_lines(path)
    data =
      if path.end_with?('.gz')
        Zlib::GzipReader.open(path, &:read)
      else
        File.binread(path)
      end
    data.lines.map(&:chomp)
  end

  def apply_commands(lines)
    current = lines.dup
    query_result = nil

    @commands.each do |raw|
      cmd = raw.to_s.strip
      next if cmd.empty? || cmd.start_with?('#')

      if cmd.start_with?('|')
        read_command_file(cmd[1..].strip)
      elsif cmd.start_with?(':')
        current = apply_colon_command(cmd[1..].strip, current, query_result)
      elsif cmd.start_with?(';')
        query_result = run_query(cmd[1..].strip, current)
        print_table(query_result)
        current = []
      else
        warn_unknown(cmd)
      end
    end

    current
  end

  def apply_colon_command(cmd, lines, query_result)
    case cmd
    when /^quit\b/
      lines
    when /^goto\s+(\d+)/
      idx = $1.to_i - 1
      idx >= 0 && idx < lines.length ? [lines[idx]] : []
    when /^filter-in\s+(.+)/
      pat = Regexp.new($1)
      lines.select { |line| line =~ pat }
    when /^filter-out\s+(.+)/
      pat = Regexp.new($1)
      lines.reject { |line| line =~ pat }
    when /^write-(?:raw-)?to\s+(.+)/
      warn_no_marked(cmd)
      []
    when /^write-csv-to\s+(.+)/
      path = $1.strip
      if query_result
        csv = query_result.map { |row| row.map { |v| csv_cell(v) }.join(',') }.join("\n") + "\n"
        path == '-' ? print(csv) : File.write(path, csv)
      else
        warn_no_query(cmd)
      end
      []
    else
      warn_unknown(cmd)
      []
    end
  end

  def run_query(sql, lines)
    normalized = sql.strip.sub(/;$/, '')
    case normalized
    when /\Aselect\s+count\(\*\)\s+from\s+(?:logline|all_logs?)\z/i
      [['count(*)'], [lines.length]]
    when /\Aselect\s+(\d+)\z/i
      [[Regexp.last_match(1)], [Regexp.last_match(1)]]
    when /\Aselect\s+'([^']*)'\z/i
      [[Regexp.last_match(1)], [Regexp.last_match(1)]]
    when /\Aselect\s+\*\s+from\s+logline\z/i
      [%w[log_line log_text]] + lines.each_with_index.map { |l, i| [i, l] }
    else
      $stderr.puts "  error: failed to compile SQL statement"
      $stderr.puts " reason: no such table: logline" if normalized =~ /logline/i
      $stderr.puts " --> command-option:1"
      $stderr.puts " | #{normalized.ljust(40)}"
      []
    end
  end

  def print_table(rows)
    return if rows.empty?
    widths = []
    rows.each { |row| row.each_with_index { |v, i| widths[i] = [widths[i] || 0, v.to_s.length].max } }
    rows.each do |row|
      puts row.each_with_index.map { |v, i| v.to_s.rjust(widths[i] + 5) }.join(' ')
    end
  end

  def csv_cell(value)
    text = value.to_s
    if text.match?(/[",\n\r]/)
      '"' + text.gsub('"', '""') + '"'
    else
      text
    end
  end

  def invalid_arg(reason)
    $stderr.puts '  error: invalid command-line arguments'
    $stderr.puts " reason: #{reason}"
    109
  end

  def file_error(path, reason)
    $stderr.puts "  error: unable to open file: #{path}"
    $stderr.puts " reason: #{reason}"
    1
  end

  def interactive_error
    $stderr.puts '  error: unable to display interactive text UI'
    $stderr.puts ' reason: stdout is not a TTY'
    $stderr.puts " = help: pass the -n option to run lnav in headless mode or don't redirect stdout"
    1
  end

  def management_mode
    if @paths.empty?
      $stderr.puts '  error: expecting an operation to perform'
      $stderr.puts ' = help: the available operations are:'
      %w[apps config format piper regex101 crash].each do |op|
        $stderr.puts "          • #{op}: manage #{op == 'config' ? 'lnav configuration' : op}"
      end
      1
    else
      0
    end
  end

  def install_mode
    dest = File.join(Dir.home, '.lnav', 'formats', 'installed')
    FileUtils.mkdir_p(dest)
    @paths.each do |path|
      next if path == 'extra'
      FileUtils.cp(path, dest) if File.file?(path)
    end
    0
  end

  def update_mode
    puts "No formats from git repositories found, use 'lnav -i extra' to install third-party formats"
    0
  end

  def warn_unknown(cmd)
    $stderr.puts "  error: unknown command: “#{cmd}”"
  end

  def warn_no_marked(cmd)
    $stderr.puts "  error: no lines marked to write, use 'm' to mark lines"
    $stderr.puts ' --> command-option:1'
    $stderr.puts " | :#{cmd.ljust(38)}"
  end

  def warn_no_query(cmd)
    $stderr.puts "  error: no query result to write, use ';' to execute a query"
    $stderr.puts ' --> command-option:1'
    $stderr.puts " | :#{cmd.ljust(38)}"
  end
end

exit(App.new(ARGV).run)
