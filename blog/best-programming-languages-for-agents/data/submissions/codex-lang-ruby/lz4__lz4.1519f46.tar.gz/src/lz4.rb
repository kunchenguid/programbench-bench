#!/usr/bin/env ruby
# frozen_string_literal: true

module MiniLZ4
  MAGIC = 0x184D2204
  LEGACY_MAGIC = 0x184C2102
  SKIPPABLE_BASE = 0x184D2A50
  BLOCK_MAX = 4 * 1024 * 1024

  PRIME1 = 2_654_435_761
  PRIME2 = 2_246_822_519
  PRIME3 = 3_266_489_917
  PRIME4 = 668_265_263
  PRIME5 = 374_761_393
  MASK32 = 0xffffffff

  class Error < StandardError; end

  module_function

  def u32le(s, i)
    raise Error, 'unexpected end of file' if i + 4 > s.bytesize
    s.getbyte(i) | (s.getbyte(i + 1) << 8) | (s.getbyte(i + 2) << 16) | (s.getbyte(i + 3) << 24)
  end

  def u64le(s, i)
    lo = u32le(s, i)
    hi = u32le(s, i + 4)
    lo | (hi << 32)
  end

  def pack32(n)
    [n & MASK32].pack('V')
  end

  def rotl32(x, r)
    (((x << r) & MASK32) | (x >> (32 - r))) & MASK32
  end

  def xx_round(acc, input)
    acc = (acc + input * PRIME2) & MASK32
    acc = rotl32(acc, 13)
    (acc * PRIME1) & MASK32
  end

  def xxh32(data, seed = 0)
    data = data.b
    i = 0
    len = data.bytesize
    if len >= 16
      v1 = (seed + PRIME1 + PRIME2) & MASK32
      v2 = (seed + PRIME2) & MASK32
      v3 = seed & MASK32
      v4 = (seed - PRIME1) & MASK32
      limit = len - 16
      while i <= limit
        v1 = xx_round(v1, u32le(data, i)); i += 4
        v2 = xx_round(v2, u32le(data, i)); i += 4
        v3 = xx_round(v3, u32le(data, i)); i += 4
        v4 = xx_round(v4, u32le(data, i)); i += 4
      end
      h = (rotl32(v1, 1) + rotl32(v2, 7) + rotl32(v3, 12) + rotl32(v4, 18)) & MASK32
    else
      h = (seed + PRIME5) & MASK32
    end
    h = (h + len) & MASK32
    while i + 4 <= len
      h = (h + u32le(data, i) * PRIME3) & MASK32
      h = (rotl32(h, 17) * PRIME4) & MASK32
      i += 4
    end
    while i < len
      h = (h + data.getbyte(i) * PRIME5) & MASK32
      h = (rotl32(h, 11) * PRIME1) & MASK32
      i += 1
    end
    h ^= h >> 15
    h = (h * PRIME2) & MASK32
    h ^= h >> 13
    h = (h * PRIME3) & MASK32
    (h ^ (h >> 16)) & MASK32
  end

  def encode_frame(data, content_checksum: true)
    data = data.b
    flg = 0x60
    flg |= 0x04 if content_checksum
    bd = 0x70
    desc = [flg, bd].pack('C*')
    header_checksum = (xxh32(desc) >> 8) & 0xff
    out = String.new.b
    out << pack32(MAGIC) << desc << header_checksum.chr
    pos = 0
    while pos < data.bytesize
      chunk = data.byteslice(pos, BLOCK_MAX)
      out << pack32(chunk.bytesize | 0x80000000)
      out << chunk
      pos += chunk.bytesize
    end
    out << pack32(0)
    out << pack32(xxh32(data)) if content_checksum
    out
  end

  def decode_all(data, test_only: false)
    data = data.b
    pos = 0
    out = String.new.b
    while pos < data.bytesize
      magic = u32le(data, pos)
      pos += 4
      if (magic & 0xfffffff0) == SKIPPABLE_BASE
        skip = u32le(data, pos)
        pos += 4 + skip
        next
      end
      raise Error, 'unsupported legacy format' if magic == LEGACY_MAGIC
      raise Error, 'unrecognized lz4 frame magic' unless magic == MAGIC
      decoded, pos = decode_frame_at(data, pos)
      out << decoded unless test_only
    end
    out
  end

  def decode_frame_at(data, pos)
    flg = data.getbyte(pos)
    bd = data.getbyte(pos + 1)
    raise Error, 'bad frame descriptor' if flg.nil? || bd.nil?
    pos += 2
    raise Error, 'unsupported frame version' unless (flg & 0xc0) == 0x40
    has_block_checksum = (flg & 0x10) != 0
    has_content_size = (flg & 0x08) != 0
    has_content_checksum = (flg & 0x04) != 0
    has_dict_id = (flg & 0x01) != 0
    content_size = nil
    if has_content_size
      content_size = u64le(data, pos)
      pos += 8
    end
    pos += 4 if has_dict_id
    pos += 1 # header checksum
    out = String.new.b
    loop do
      block_size = u32le(data, pos)
      pos += 4
      break if block_size.zero?
      raw = (block_size & 0x80000000) != 0
      size = block_size & 0x7fffffff
      raise Error, 'truncated block' if pos + size > data.bytesize
      block = data.byteslice(pos, size)
      pos += size
      out << (raw ? block : decode_block(block))
      pos += 4 if has_block_checksum
    end
    if has_content_checksum
      expected = u32le(data, pos)
      pos += 4
      actual = xxh32(out)
      raise Error, 'content checksum mismatch' unless expected == actual
    end
    raise Error, 'content size mismatch' if content_size && content_size != out.bytesize
    [out, pos]
  end

  def read_len(input, idx, base)
    len = base
    if base == 15
      loop do
        raise Error, 'malformed lz4 block' if idx >= input.bytesize
        b = input.getbyte(idx)
        idx += 1
        len += b
        break unless b == 255
      end
    end
    [len, idx]
  end

  def decode_block(input)
    input = input.b
    ip = 0
    out = String.new.b
    while ip < input.bytesize
      token = input.getbyte(ip)
      ip += 1
      lit_len, ip = read_len(input, ip, token >> 4)
      raise Error, 'literal run exceeds block' if ip + lit_len > input.bytesize
      out << input.byteslice(ip, lit_len)
      ip += lit_len
      break if ip >= input.bytesize
      raise Error, 'missing match offset' if ip + 2 > input.bytesize
      offset = input.getbyte(ip) | (input.getbyte(ip + 1) << 8)
      ip += 2
      raise Error, 'invalid match offset' if offset <= 0 || offset > out.bytesize
      match_len, ip = read_len(input, ip, token & 0x0f)
      match_len += 4
      ref = out.bytesize - offset
      match_len.times do |i|
        out << out.getbyte(ref + i).chr
      end
    end
    out
  end
end

class LZ4CLI
  HELP = <<~HELP
    *** lz4 v1.10.0 64-bit multithread, by Yann Collet ***
    Usage : 
          executable [arg] [input] [output] 

    input   : a filename 
              with no FILE, or when FILE is - or stdin, read standard input
    Arguments : 
     -1     : fast compression (default) 
     -12    : slowest compression level 
     -T#    : use # threads for compression (default:0==auto) 
     -d     : decompression (default for .lz4 extension)
     -f     : overwrite output without prompting 
     -k     : preserve source files(s)  (default) 
    --rm    : remove source file(s) after successful de/compression 
     -h/-H  : display help/long help and exit 

    Advanced arguments :
     -V     : display Version number and exit 
     -v     : verbose mode 
     -q     : suppress warnings; specify twice to suppress errors too
     -c     : force write to standard output, even if it is the console
     -t     : test compressed file integrity
     -m     : multiple input files (implies automatic output filenames)
     -r     : operate recursively on directories (sets also -m) 
     -l     : compress using Legacy format (Linux kernel compression)
     -z     : force compression 
     -D FILE: use FILE as dictionary (compression & decompression)
     -B#    : cut file into blocks of size # bytes [32+] 
                         or predefined block size [4-7] (default: 7) 
    --list FILE : lists information about .lz4 files (useful for files compressed with --content-size flag)
    --fast[=#]: switch to ultra fast compression level (default: 1)
    --best  : same as -12
  HELP

  def initialize(argv)
    @argv = argv.dup
    @mode = nil
    @stdout = false
    @force = false
    @test = false
    @multiple = false
    @recursive = false
    @quiet = 0
    @remove = false
    @list = false
    @files = []
  end

  def run
    parse
    return list_files if @list
    if !@stdout && !@test && !@multiple && @files.length == 2
      process_file(@files[0], @files[1])
      return 0
    end
    inputs = expand_inputs(@files)
    if inputs.empty?
      data = STDIN.binmode.read
      write_stdout(process_data(data, nil))
      return 0
    end
    if @stdout || @test
      inputs.each { |path| process_to_stdout_or_test(path) }
    elsif @multiple || inputs.length > 1
      inputs.each { |path| process_file(path, nil) }
    else
      process_file(inputs[0], @files[1])
    end
    0
  rescue MiniLZ4::Error, SystemCallError, ArgumentError => e
    warn "executable: #{e.message}" if @quiet < 2
    1
  end

  def parse
    until @argv.empty?
      arg = @argv.shift
      if arg == '--'
        @files.concat(@argv)
        break
      elsif arg.start_with?('--')
        parse_long(arg)
      elsif arg.start_with?('-') && arg != '-'
        parse_short(arg[1..])
      else
        @files << arg
      end
    end
  end

  def parse_long(arg)
    case arg
    when '--help' then puts HELP; exit 0
    when '--version' then puts '*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***'; exit 0
    when '--compress' then @mode = :compress
    when '--decompress' then @mode = :decompress
    when '--rm' then @remove = true
    when '--keep' then @remove = false
    when '--force' then @force = true
    when '--quiet' then @quiet += 1
    when '--list' then @list = true; @files << @argv.shift if @argv[0]
    when /^--list=(.+)$/ then @list = true; @files << Regexp.last_match(1)
    when '--best', /^--fast(=.*)?$/, '--content-size', '--no-frame-crc',
         '--sparse', '--no-sparse', '--favor-decSpeed'
      # Compatibility options accepted; this compact implementation uses one frame layout.
    else
      raise ArgumentError, "unknown option #{arg}"
    end
  end

  def parse_short(s)
    i = 0
    while i < s.length
      ch = s[i]
      case ch
      when 'h', 'H' then puts HELP; exit 0
      when 'V' then puts '*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***'; exit 0
      when 'd' then @mode = :decompress
      when 'z' then @mode = :compress
      when 't' then @test = true; @mode = :decompress
      when 'c' then @stdout = true
      when 'f' then @force = true
      when 'k' then @remove = false
      when 'm' then @multiple = true
      when 'r' then @recursive = true; @multiple = true
      when 'q' then @quiet += 1
      when 'v', 'l', 'B', 'T', 'b', 'e', 'i'
        break
      when 'D'
        @argv.shift if i == s.length - 1
        break
      when /\d/
        # Compression level, accepted for compatibility.
      else
        raise ArgumentError, "unknown option -#{ch}"
      end
      i += 1
    end
  end

  def expand_inputs(paths)
    paths = ['-'] if paths == ['stdin']
    return paths unless @recursive
    paths.flat_map do |p|
      if File.directory?(p)
        Dir.glob(File.join(p, '**', '*')).select { |x| File.file?(x) }
      else
        p
      end
    end
  end

  def mode_for(path)
    return @mode if @mode
    path && path.end_with?('.lz4') ? :decompress : :compress
  end

  def process_data(data, path)
    case mode_for(path)
    when :decompress then MiniLZ4.decode_all(data)
    else MiniLZ4.encode_frame(data)
    end
  end

  def process_to_stdout_or_test(path)
    data = read_input(path)
    result = process_data(data, path)
    write_stdout(result) unless @test
    File.unlink(path) if @remove && path != '-'
  end

  def process_file(input, explicit_output)
    if input == '-'
      write_stdout(process_data(STDIN.binmode.read, nil))
      return
    end
    output = explicit_output || default_output(input)
    raise ArgumentError, "#{output}: already exists; use -f to overwrite" if File.exist?(output) && !@force
    result = process_data(File.binread(input), input)
    File.binwrite(output, result)
    File.unlink(input) if @remove
  end

  def read_input(path)
    path == '-' ? STDIN.binmode.read : File.binread(path)
  end

  def write_stdout(data)
    STDOUT.binmode.write(data)
  end

  def default_output(input)
    if mode_for(input) == :decompress
      raise ArgumentError, "#{input}: unknown suffix -- ignored" unless input.end_with?('.lz4')
      input.sub(/\.lz4\z/, '')
    else
      "#{input}.lz4"
    end
  end

  def list_files
    puts '    Frames           Type Block  Compressed  Uncompressed    Ratio   Filename'
    @files.each do |path|
      data = File.binread(path)
      size = data.bytesize
      frames = count_frames(data)
      printf "%10d       LZ4Frame   B4I  %10.2f             -        -   %s\n",
             frames, size.to_f, File.basename(path)
    end
    0
  end

  def count_frames(data)
    pos = 0
    frames = 0
    while pos + 4 <= data.bytesize
      magic = MiniLZ4.u32le(data, pos)
      pos += 4
      if (magic & 0xfffffff0) == MiniLZ4::SKIPPABLE_BASE
        skip = MiniLZ4.u32le(data, pos)
        pos += 4 + skip
        next
      end
      break unless magic == MiniLZ4::MAGIC
      frames += 1
      flg = data.getbyte(pos)
      pos += 2
      pos += 8 if (flg & 0x08) != 0
      pos += 4 if (flg & 0x01) != 0
      pos += 1
      loop do
        bsz = MiniLZ4.u32le(data, pos)
        pos += 4
        break if bsz.zero?
        pos += (bsz & 0x7fffffff)
        pos += 4 if (flg & 0x10) != 0
      end
      pos += 4 if (flg & 0x04) != 0
    end
    frames
  rescue MiniLZ4::Error
    frames.zero? ? 1 : frames
  end
end

exit LZ4CLI.new(ARGV).run
