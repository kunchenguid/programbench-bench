#!/usr/bin/env ruby
# frozen_string_literal: true

class LuaReturn < StandardError
  attr_reader :values
  def initialize(values) = (@values = values)
end
class LuaBreak < StandardError; end

class LuaTable
  attr_reader :h
  def initialize; @h = {}; end
  def [](k); @h[norm(k)]; end
  def []=(k, v); @h[norm(k)] = v; end
  def norm(k); k.is_a?(Float) && k.to_i == k ? k.to_i : k; end
  def len
    i = 1
    i += 1 while @h.key?(i) && !@h[i].nil?
    i - 1
  end
  def keys; @h.keys; end
  def to_s; "table: 0x#{object_id.to_s(16)}"; end
end

class Env
  attr_reader :vars
  def initialize(parent=nil); @parent = parent; @vars = {}; end
  def define(k,v); @vars[k]=v; end
  def set(k,v)
    if @vars.key?(k) || @parent.nil? then @vars[k]=v else @parent.set(k,v) end
  end
  def get(k); @vars.key?(k) ? @vars[k] : (@parent&.get(k)); end
end

Token = Struct.new(:type, :val, :pos)
class Lexer
  KEY = %w[and break do else elseif end false for function if in local nil not or repeat return then true until while]
  def initialize(s); @s=s; @i=0; @n=s.length; end
  def tokens
    out=[]
    loop do
      skip
      break if eof?
      p=@i; c=peek
      if c =~ /[A-Za-z_]/
        w=read_while(/[A-Za-z0-9_]/); out << Token.new(KEY.include?(w) ? w.to_sym : :id, w, p)
      elsif c =~ /\d/ || (c=='.' && peek(1)=~ /\d/)
        out << Token.new(:num, read_num, p)
      elsif c == '"' || c == "'"
        out << Token.new(:str, read_str, p)
      else
        two=@s[@i,2]; three=@s[@i,3]
        if %w[...].include?(three); @i+=3; out << Token.new(three.to_sym, three, p)
        elsif %w[== ~= <= >= .. //].include?(two); @i+=2; out << Token.new(two.to_sym, two, p)
        else @i+=1; out << Token.new(c.to_sym, c, p) end
      end
    end
    out << Token.new(:eof,nil,@i)
  end
  def eof? = @i >= @n
  def peek(o=0) = @s[@i+o]
  def skip
    loop do
      @i += 1 while !eof? && @s[@i] =~ /\s/
      if @s[@i,2] == '--'
        if @s[@i,4] == '--[['
          j=@s.index(']]', @i+4); @i = j ? j+2 : @n
        else
          @i += 2; @i += 1 while !eof? && @s[@i] != "\n"
        end
      else; break end
    end
  end
  def read_while(re); j=@i; @i+=1 while !eof? && @s[@i] =~ re; @s[j...@i]; end
  def read_num
    j=@i
    if @s[@i,2].downcase == '0x'
      @i += 2; @i += 1 while !eof? && @s[@i] =~ /[0-9a-fA-F]/; @s[j...@i].to_i(16)
    else
      @i += 1 while !eof? && @s[@i] =~ /[0-9.]/
      if !eof? && @s[@i] =~ /[eE]/
        @i += 1; @i += 1 if @s[@i] =~ /[+-]/; @i += 1 while !eof? && @s[@i] =~ /\d/
      end
      text=@s[j...@i]; text.include?('.') || text =~ /[eE]/ ? text.to_f : text.to_i
    end
  end
  def read_str
    q=@s[@i]; @i+=1; r=+''
    until eof? || @s[@i] == q
      if @s[@i] == '\\'
        @i+=1; ch=@s[@i]
        r << ({'n'=>"\n", 't'=>"\t", 'r'=>"\r", '"'=>'"', "'"=>"'", '\\'=>'\\'}[ch] || ch.to_s); @i+=1
      else r << @s[@i]; @i+=1 end
    end
    @i+=1 if @s[@i] == q; r
  end
end

class Parser
  BIN_PREC = {'or'=>1,'and'=>2,'=='=>3,'~='=>3,'<'=>3,'>'=>3,'<='=>3,'>='=>3,'..'=>4,'+'=>5,'-'=>5,'*'=>6,'/'=>6,'//'=>6,'%'=>6,'^'=>8}
  RIGHT = {'..'=>true,'^'=>true}
  def initialize(src); @t=Lexer.new(src).tokens; @i=0; end
  def parse; block_until(:eof); end
  def cur = @t[@i]
  def eat(type=nil); raise "expected #{type}, got #{cur.type}" if type && cur.type != type; x=cur; @i+=1; x; end
  def accept(type); cur.type==type && eat end
  def block_until(*terms)
    a=[]; a << stat until terms.include?(cur.type) || cur.type==:eof; [:block,a]
  end
  def stat
    accept(:';') and return [:nop]
    case cur.type
    when :local
      eat; if accept(:function); name=eat(:id).val; body=func_body; [:local, [name], [[:function, *body]]]
      else names=[eat(:id).val]; names << eat(:id).val while accept(:','); vals=accept(:"=") ? explist : []; [:local,names,vals] end
    when :function
      eat; path=[eat(:id).val]; path << eat(:id).val while accept(:'.'); body=func_body; [:funcdef,path,body]
    when :return then eat; vals = ([:end,:else,:elseif,:until,:eof].include?(cur.type) ? [] : explist); [:return,vals]
    when :break then eat; [:break]
    when :do then eat; b=block_until(:end); eat(:end); b
    when :while then eat; c=expr; eat(:do); b=block_until(:end); eat(:end); [:while,c,b]
    when :repeat then eat; b=block_until(:until); eat(:until); [:repeat,b,expr]
    when :if
      eat; parts=[]; parts << [expr, (eat(:then); block_until(:elseif,:else,:end))]
      while accept(:elseif); parts << [expr, (eat(:then); block_until(:elseif,:else,:end))] end
      els = accept(:else) ? block_until(:end) : nil; eat(:end); [:if,parts,els]
    when :for
      eat; name=eat(:id).val
      if accept(:"=")
        vals=explist; eat(:do); b=block_until(:end); eat(:end); [:fornum,name,vals,b]
      else
        names=[name]; names << eat(:id).val while accept(:','); eat(:in); vals=explist; eat(:do); b=block_until(:end); eat(:end); [:forin,names,vals,b]
      end
    else
      first=prefix
      if [:'=',:','].include?(cur.type)
        vars=[first]; vars << prefix while accept(:','); eat(:"="); [:assign,vars,explist]
      else [:expr, first] end
    end
  end
  def func_body
    eat(:'('); params=[]; vararg=false
    unless accept(:')')
      loop do
        if accept(:'...'); vararg=true; break end
        params << eat(:id).val
        break unless accept(:',')
      end
      eat(:')')
    end
    b=block_until(:end); eat(:end); [params,vararg,b]
  end
  def explist; a=[expr]; a << expr while accept(:','); a; end
  def expr(min=1)
    left=unary
    while cur.val && (p=BIN_PREC[cur.val]) && p >= min
      op=eat.val; right=expr(p + (RIGHT[op] ? 0 : 1)); left=[:bin,op,left,right]
    end
    left
  end
  def unary
    if [:not, :'-', :'#'].include?(cur.type); op=eat.val || @t[@i-1].type.to_s; [:un,op,unary] else simple end
  end
  def simple
    case cur.type
    when :num then [:lit,eat.val]
    when :str then [:lit,eat.val]
    when :nil then eat; [:lit,nil]
    when :true then eat; [:lit,true]
    when :false then eat; [:lit,false]
    when :function then eat; [:function,*func_body]
    when :'...' then eat; [:vararg]
    when :'{' then table
    else prefix end
  end
  def table
    eat(:'{'); fields=[]; idx=1
    until accept(:'}')
      if accept(:'['); k=expr; eat(:']'); eat(:"="); fields << [k,expr]
      elsif cur.type==:id && @t[@i+1].type==:'='; k=[:lit,eat(:id).val]; eat(:"="); fields << [k,expr]
      else fields << [[:lit,idx],expr]; idx+=1 end
      accept(:',') || accept(:';')
    end
    [:table,fields]
  end
  def prefix
    node = if accept(:'('); e=expr; eat(:')'); e else [:var,eat(:id).val] end
    loop do
      if accept(:'.'); node=[:index,node,[:lit,eat(:id).val]]
      elsif accept(:'['); k=expr; eat(:']'); node=[:index,node,k]
      elsif accept(:':'); m=eat(:id).val; recv=node; node=[:call,[:index,recv,[:lit,m]],[recv]+args]
      elsif cur.type==:'(' || cur.type==:str || cur.type==:'{'; node=[:call,node,args]
      else break end
    end
    node
  end
  def args
    if accept(:'('); a = accept(:')') ? [] : explist.tap{eat(:')')}; a
    elsif cur.type==:str; [[:lit,eat.val]]
    else [table] end
  end
end

class LuaFunc
  def initialize(params,vararg,body,env,interp); @params=params; @vararg=vararg; @body=body; @env=env; @interp=interp; end
  def call(args)
    e=Env.new(@env); @params.each_with_index{|p,i| e.define(p,args[i])}; e.define('...', args[@params.length..] || []) if @vararg
    begin
      @interp.exec(@body,e)
      []
    rescue LuaReturn => r
      r.values
    end
  end
  def to_s; "function: 0x#{object_id.to_s(16)}"; end
end

class Interpreter
  def initialize(argv=[])
    @g=Env.new; install(argv)
  end
  def run(src, name='(command)')
    exec(Parser.new(src).parse, @g)
  rescue RuntimeError => e
    warn "#{name}: #{e.message}"; exit 1
  rescue LuaReturn
  end
  def truth(v)= !(v.nil? || v == false)
  def values(nodes,e)= nodes.flat_map{|n| n[0]==:call ? call(evalx(n[1],e), values(n[2],e)) : (n[0]==:vararg ? (e.get('...') || []) : [evalx(n,e)]) }
  def exec(n,e)
    case n[0]
    when :block then n[1].each{|s| exec(s,e)}
    when :nop then nil
    when :local then vals=values(n[2],e); n[1].each_with_index{|name,i| e.define(name, vals[i])}
    when :assign then vals=values(n[2],e); n[1].each_with_index{|v,i| assign(v, vals[i], e)}
    when :expr then evalx(n[1],e)
    when :return then raise LuaReturn.new(values(n[1],e))
    when :break then raise LuaBreak
    when :funcdef
      f=LuaFunc.new(*n[2], e, self); target=n[1][0...-1].reduce(e.get(n[1][0])){|o,k| o[k]}; n[1].length==1 ? e.set(n[1][0],f) : target[n[1][-1]]=f
    when :while
      while truth(evalx(n[1],e)); begin exec(n[2],Env.new(e)); rescue LuaBreak; break end end
    when :repeat
      loop do begin exec(n[1],Env.new(e)); rescue LuaBreak; break end; break if truth(evalx(n[2],e)) end
    when :if
      done=false; n[1].each{|c,b| if truth(evalx(c,e)); exec(b,Env.new(e)); done=true; break end}; exec(n[2],Env.new(e)) if !done && n[2]
    when :fornum
      vals=values(n[2],e); i=(vals[0]||0); limit=(vals[1]||0); step=(vals[2]||1)
      cmp = step.to_f >= 0 ? ->(x){x<=limit} : ->(x){x>=limit}
      while cmp.call(i); le=Env.new(e); le.define(n[1],i); begin exec(n[3],le); rescue LuaBreak; break end; i += step end
    when :forin
      iter,state,ctrl = values(n[2],e); loop do r=call(iter,[state,ctrl]); break if r.empty? || r[0].nil?; ctrl=r[0]; le=Env.new(e); n[1].each_with_index{|name,i| le.define(name,r[i])}; begin exec(n[3],le); rescue LuaBreak; break end end
    end
  end
  def assign(v,val,e)
    v[0]==:var ? e.set(v[1],val) : (evalx(v[1],e)[evalx(v[2],e)] = val)
  end
  def evalx(n,e)
    case n[0]
    when :lit then n[1]
    when :var then e.get(n[1])
    when :vararg then (e.get('...') || [])[0]
    when :index then o=evalx(n[1],e); k=evalx(n[2],e); o.is_a?(LuaTable) ? o[k] : (o.is_a?(String) ? @g.get('string')[k] : nil)
    when :table then t=LuaTable.new; n[1].each{|k,v| t[evalx(k,e)] = evalx(v,e)}; t
    when :function then LuaFunc.new(n[1],n[2],n[3],e,self)
    when :call then r=call(evalx(n[1],e), values(n[2],e)); r[0]
    when :un
      v=evalx(n[2],e); return !truth(v) if n[1]=='not'; return -num(v) if n[1]=='-'; v.is_a?(LuaTable) ? v.len : v.to_s.length
    when :bin then bin(n[1], evalx(n[2],e), (n[1]=='and' && !truth(evalx(n[2],e))) ? nil : evalx(n[3],e))
    end
  end
  def num(v)= v.is_a?(String) ? v.to_f : v
  def fmt(v)
    return 'nil' if v.nil?; return 'true' if v==true; return 'false' if v==false
    v.is_a?(Float) && v.to_i==v ? v.to_i.to_s : v.to_s
  end
  def bin(op,a,b)
    case op
    when 'or' then truth(a) ? a : b
    when 'and' then truth(a) ? b : a
    when '+' then num(a)+num(b); when '-' then num(a)-num(b); when '*' then num(a)*num(b)
    when '/' then num(a).to_f/num(b); when '//' then (num(a).to_f/num(b)).floor; when '%' then num(a)%num(b); when '^' then num(a)**num(b)
    when '..' then fmt(a)+fmt(b)
    when '==' then a==b; when '~=' then a!=b; when '<' then a<b; when '>' then a>b; when '<=' then a<=b; when '>=' then a>=b
    end
  end
  def call(f,args)
    return f.call(args) if f.is_a?(LuaFunc)
    return Array(f.call(*args)) if f.respond_to?(:call)
    raise "attempt to call a #{type(f)} value"
  end
  def type(v); return 'nil' if v.nil?; return 'boolean' if v==true || v==false; return 'number' if v.is_a?(Numeric); return 'string' if v.is_a?(String); return 'table' if v.is_a?(LuaTable); 'function'; end
  def install(argv)
    @g.define('_VERSION','Lua 5.5')
    argt=LuaTable.new; argv.each_with_index{|a,i| argt[i]=a}; @g.define('arg',argt)
    @g.define('print', ->(*xs){ puts xs.map{|x| fmt(x)}.join("\t"); [] })
    @g.define('type', ->(x){ type(x) }); @g.define('tostring', ->(x){ fmt(x) }); @g.define('tonumber', ->(x){ x.nil? ? nil : (x.to_s.include?('.') ? x.to_f : x.to_i) })
    @g.define('assert', ->(x,msg=nil){ raise(msg || 'assertion failed!') unless truth(x); x })
    @g.define('error', ->(msg='error'){ raise msg.to_s })
    @g.define('pairs', ->(t){ ks=t.keys; i=-1; iter=->(_s,_c){ i+=1; k=ks[i]; k.nil? ? [nil] : [k,t[k]]}; [iter,t,nil] })
    @g.define('ipairs', ->(t){ iter=->(tab,i){ i=(i||0)+1; v=tab[i]; v.nil? ? [nil] : [i,v]}; [iter,t,0] })
    math=LuaTable.new; %i[abs floor ceil sqrt sin cos tan].each{|m| math[m.to_s]=->(x){ Math.send(m,x) rescue x.send(m) }}; math['max']=->(*x){x.max}; math['min']=->(*x){x.min}; math['pi']=Math::PI; @g.define('math',math)
    string=LuaTable.new; string['len']=->(s){s.to_s.length}; string['upper']=->(s){s.to_s.upcase}; string['lower']=->(s){s.to_s.downcase}; string['reverse']=->(s){s.to_s.reverse}; string['rep']=->(s,n){s.to_s*n.to_i}; string['sub']=->(s,i,j=nil){s=s.to_s; i=i.to_i; j=(j||-1).to_i; s[(i<0 ? s.length+i : i-1)..(j<0 ? s.length+j : j-1)] || ''}; string['find']=->(s,pat,init=nil){idx=s.to_s.index(pat.to_s,(init||1).to_i-1); idx ? [idx+1,idx+pat.to_s.length] : nil}; @g.define('string',string)
    table=LuaTable.new; table['insert']=->(t,v){ t[t.len+1]=v; []}; table['concat']=->(t,sep=''){ (1..t.len).map{|i|fmt(t[i])}.join(sep)}; @g.define('table',table)
    io=LuaTable.new; io['write']=->(*xs){ STDOUT.write(xs.map{|x|fmt(x)}.join); STDOUT.flush; []}; io['read']=->(what='*l'){ what=='*a' ? STDIN.read : STDIN.gets&.chomp }; @g.define('io',io)
    os=LuaTable.new; os['clock']=->(){ Process.clock_gettime(Process::CLOCK_MONOTONIC) }; os['time']=->(){ Time.now.to_i }; os['date']=->(fmt=nil,t=nil){ Time.at(t||Time.now).strftime(fmt || '%c') }; os['exit']=->(code=0){ exit(code.to_i) }; @g.define('os',os)
    @g.define('require', ->(name){ @g.get(name.to_s) || true })
    @g.define('dofile', ->(path){ run(File.read(path.to_s), path.to_s); [] })
    @g.define('load', ->(src){ LuaFunc.new([],false,Parser.new(src.to_s).parse,@g,self) })
    @g.define('loadfile', ->(path){ LuaFunc.new([],false,Parser.new(File.read(path.to_s)).parse,@g,self) })
    @g.define('pcall', ->(fn,*a){ begin [true]+call(fn,a); rescue => ex; [false, ex.message]; end })
    @g.define('select', ->(what,*a){ what == '#' ? a.length : a[(what.to_i-1)..] })
    gt=LuaTable.new; @g.vars.each{|k,v| gt[k]=v}; @g.define('_G', gt); gt['_G']=gt
  end
end

USAGE = "usage: ./executable [options] [script [args]]\nAvailable options are:\n  -e stat   execute string 'stat'\n  -i        enter interactive mode after executing 'script'\n  -l mod    require library 'mod' into global 'mod'\n  -l g=mod  require library 'mod' into global 'g'\n  -v        show version information\n  -E        ignore environment variables\n  -W        turn warnings on\n  --        stop handling options\n  -         stop handling options and execute stdin\n"

def main
  args=ARGV.dup; chunks=[]; version=false; script=nil; script_i=nil; i=0
  while i < args.length
    a=args[i]
    case a
    when '-v' then version=true; i+=1
    when '-E','-W','-i' then i+=1
    when '-e' then i+=1; chunks << (args[i] || ''); i+=1
    when /^-e(.+)/ then chunks << $1; i+=1
    when '-l' then i+=2
    when /^-l/ then i+=1
    when '--' then script_i=i+1; script=args[script_i]; break
    when '-' then script_i=i; script='-'; break
    else
      if a.start_with?('-')
        warn "./executable: unrecognized option '#{a}'"; warn USAGE.chomp; exit 1
      else script_i=i; script=a; break end
    end
  end
  puts 'Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio' if version
  interp=Interpreter.new(script_i ? args[script_i..] : args)
  chunks.each{|c| interp.run(c)}
  if script
    src = script == '-' ? STDIN.read : (File.read(script) rescue (warn "./executable: cannot open #{script}: No such file or directory"; exit 1))
    interp.run(src, script)
  end
end
main if $PROGRAM_NAME == __FILE__
