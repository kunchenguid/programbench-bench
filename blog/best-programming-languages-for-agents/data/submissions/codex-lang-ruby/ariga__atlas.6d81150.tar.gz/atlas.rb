#!/usr/bin/env ruby
# frozen_string_literal: true

require "base64"
require "digest"
require "fileutils"

class AtlasClone
  ROOT_HELP = <<~TXT
    Manage your database schema as code

    Usage:
      atlas [command]

    Available Commands:
      completion  Generate the autocompletion script for the specified shell
      help        Help about any command
      license     Display license information
      migrate     Manage versioned migration files
      schema      Work with atlas schemas.
      version     Prints this Atlas CLI version information.

    Flags:
      -h, --help   help for atlas

    Use "atlas [command] --help" for more information about a command.
  TXT

  SCHEMA_HELP = <<~TXT
    The `atlas schema` command groups subcommands working with declarative Atlas schemas.

    Usage:
      atlas schema [command]

    Available Commands:
      apply       Apply an atlas schema to a target database.
      clean       Removes all objects from the connected database.
      diff        Calculate and print the diff between two schemas.
      fmt         Formats Atlas HCL files
      inspect     Inspect a database and print its schema in Atlas DDL syntax.

    Flags:
      -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
          --env string           set which env from the config file to use
      -h, --help                 help for schema
          --var <name>=<value>   input variables (default [])

    Use "atlas schema [command] --help" for more information about a command.
  TXT

  MIGRATE_HELP = <<~TXT
    'atlas migrate' wraps several sub-commands for migration management.

    Usage:
      atlas migrate [command]

    Available Commands:
      apply       Applies pending migration files on the connected database.
      diff        Compute the diff between the migration directory and a desired state and create a new migration file.
      hash        Hash (re-)creates an integrity hash file for the migration directory.
      import      Import a migration directory from another migration management tool to the Atlas format.
      lint        Run analysis on the migration directory
      new         Creates a new empty migration file in the migration directory.
      set         Set the current version of the migration history table.
      status      Get information about the current migration status.
      validate    Validates the migration directories checksum and SQL statements.

    Flags:
      -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
          --env string           set which env from the config file to use
      -h, --help                 help for migrate
          --var <name>=<value>   input variables (default [])

    Use "atlas migrate [command] --help" for more information about a command.
  TXT

  HELP = {
    %w[version] => <<~TXT,
      Prints this Atlas CLI version information.

      Usage:
        atlas version [flags]

      Flags:
        -h, --help   help for version
    TXT
    %w[license] => <<~TXT,
      Display license information

      Usage:
        atlas license [flags]

      Flags:
        -h, --help   help for license
    TXT
    %w[schema fmt] => <<~TXT,
      'atlas schema fmt' formats all ".hcl" files under the given paths using
      canonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.
      Unless stated otherwise, the fmt command will use the current directory.

      After running, the command will print the names of the files it has formatted. If all
      files in the directory are formatted, no input will be printed out.

      Usage:
        atlas schema fmt [path ...] [flags]

      Flags:
        -h, --help   help for fmt

      Global Flags:
        -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
            --env string           set which env from the config file to use
            --var <name>=<value>   input variables (default [])
    TXT
    %w[schema inspect] => <<~TXT,
      'atlas schema inspect' connects to the given database and inspects its schema.
      It then prints to the screen the schema of that database in Atlas DDL syntax.

      Usage:
        atlas schema inspect [flags]

      Flags:
        -u, --url string        [driver://username:password@address/dbname?param=value] select a resource using the URL format
            --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
        -s, --schema strings    set schema names
            --exclude strings   list of glob patterns used to filter resources from applying
            --format string     Go template to use to format the output
        -h, --help              help for inspect

      Global Flags:
        -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
            --env string           set which env from the config file to use
            --var <name>=<value>   input variables (default [])
    TXT
    %w[schema diff] => "Usage:\n  atlas schema diff [flags]\n\nFlags:\n  -f, --from strings      [driver://username:password@address/dbname?param=value] select a resource using the URL format\n      --to strings        [driver://username:password@address/dbname?param=value] select a desired state using the URL format\n  -h, --help              help for diff\n",
    %w[schema apply] => "Usage:\n  atlas schema apply [flags]\n\nFlags:\n  -u, --url string              [driver://username:password@address/dbname?param=value] select a resource using the URL format\n      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format\n      --dry-run                 print SQL without executing it\n      --auto-approve            apply changes without prompting for approval\n  -h, --help                    help for apply\n",
    %w[schema clean] => "Usage:\n  atlas schema clean [flags]\n\nFlags:\n  -u, --url string      [driver://username:password@address/dbname?param=value] select a resource using the URL format\n      --dry-run         print SQL without executing it\n      --auto-approve    apply changes without prompting for approval\n  -h, --help            help for clean\n",
    %w[migrate new] => <<~TXT,
      'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.

      Usage:
        atlas migrate new [flags] [name]

      Examples:
        atlas migrate new my-new-migration

      Flags:
            --dir string          select migration directory using URL format (default "file://migrations")
            --dir-format string   select migration file format (default "atlas")
            --edit                edit the created migration file(s)
        -h, --help                help for new
    TXT
    %w[migrate hash] => "Usage:\n  atlas migrate hash [flags]\n\nFlags:\n      --dir string          select migration directory using URL format (default \"file://migrations\")\n      --dir-format string   select migration file format (default \"atlas\")\n  -h, --help                help for hash\n",
    %w[migrate validate] => "Usage:\n  atlas migrate validate [flags]\n\nFlags:\n      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format\n      --dir string          select migration directory using URL format (default \"file://migrations\")\n  -h, --help                help for validate\n",
    %w[migrate status] => "Usage:\n  atlas migrate status [flags]\n\nFlags:\n  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format\n      --dir string                select migration directory using URL format (default \"file://migrations\")\n  -h, --help                      help for status\n",
    %w[migrate apply] => "Usage:\n  atlas migrate apply [flags] [amount]\n\nFlags:\n  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format\n      --dir string                select migration directory using URL format (default \"file://migrations\")\n      --dry-run                   print SQL without executing it\n  -h, --help                      help for apply\n",
    %w[migrate diff] => "Usage:\n  atlas migrate diff [flags] [name]\n\nFlags:\n      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format\n      --dev-url string          [driver://username:password@address/dbname?param=value] select a dev database using the URL format\n      --dir string              select migration directory using URL format (default \"file://migrations\")\n  -h, --help                    help for diff\n",
    %w[migrate lint] => "Run analysis on the migration directory\n\nUsage:\n  atlas migrate lint [flags]\n",
    %w[migrate import] => "Import a migration directory from another migration management tool to the Atlas format.\n\nUsage:\n  atlas migrate import [flags]\n",
    %w[migrate set] => "Usage:\n  atlas migrate set [flags] [version]\n"
  }

  def run(argv)
    return puts(ROOT_HELP) if argv.empty? || argv == ["--help"] || argv == ["-h"]
    return puts(help_for(argv[1..])) if argv[0] == "help"
    case argv[0]
    when "version" then version
    when "license" then license
    when "schema" then schema(argv[1..])
    when "migrate" then migrate(argv[1..])
    when "completion" then completion(argv[1])
    else
      err_unknown(argv[0])
    end
  end

  def help_for(path)
    return ROOT_HELP if path.nil? || path.empty?
    return SCHEMA_HELP if path == ["schema"]
    return MIGRATE_HELP if path == ["migrate"]
    HELP[path] || ROOT_HELP
  end

  def help_flag?(argv)
    argv.include?("-h") || argv.include?("--help")
  end

  def version
    puts "atlas unofficial version - development"
    puts "https://github.com/ariga/atlas/releases/latest"
    puts "To download an official version, visit: https://atlasgo.io/getting-started#installation"
  end

  def license
    puts "LICENSE"
    puts "Atlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE."
  end

  def schema(argv)
    return puts(SCHEMA_HELP) if argv.empty? || !%w[inspect fmt diff apply clean].include?(argv[0])
    return puts(HELP[["schema", argv[0]]]) if help_flag?(argv)
    case argv[0]
    when "fmt" then schema_fmt(argv[1..])
    when "inspect" then schema_inspect(argv[1..])
    when "diff" then require_flags(argv, %w[--from -f], "from") && require_flags(argv, %w[--to], "to")
    when "clean" then require_flags(argv, %w[--url -u], "url")
    when "apply" then schema_apply(argv)
    end
  end

  def migrate(argv)
    return puts(MIGRATE_HELP) if argv.empty? || !%w[new hash validate status apply diff lint import set].include?(argv[0])
    return puts(HELP[["migrate", argv[0]]]) if help_flag?(argv)
    case argv[0]
    when "new" then migrate_new(argv[1..])
    when "hash" then migrate_hash(argv[1..])
    when "validate" then migrate_validate(argv[1..])
    when "status", "apply", "lint" then check_dir(argv[1..])
    when "diff" then require_flags(argv, %w[--dev-url], "dev-url")
    else
      # Minimal no-op for rarely used commands once flags parse.
    end
  end

  def schema_apply(argv)
    return unless require_flags(argv, %w[--to -t], "file\" or \"to")
    return unless require_flags(argv, %w[--url -u], "url")
    puts "-- Planned Changes:"
  end

  def require_flags(argv, names, label)
    return true if argv.each_with_index.any? { |a, i| names.include?(a) || names.any? { |n| a.start_with?("#{n}=") } }
    warn %(Error: required flag(s) "#{label}" not set)
    exit 1
  end

  def schema_fmt(args)
    paths = args.reject { |a| a.start_with?("-") }
    paths = ["."] if paths.empty?
    files = paths.flat_map do |p|
      unless File.exist?(p)
        warn "Error: stat #{p}: no such file or directory"
        exit 1
      end
      File.directory?(p) ? Dir.glob(File.join(p, "**", "*.hcl")) : [p]
    end
    files.each do |f|
      original = File.read(f)
      formatted = format_hcl(original)
      next if formatted == original
      File.write(f, formatted)
      puts f
    end
  end

  def format_hcl(src)
    out = []
    indent = 0
    src.each_line do |line|
      s = line.strip
      if s.empty?
        out << "" unless out.last == ""
        next
      end
      indent -= 1 if s.start_with?("}")
      s = s.gsub(/\s+/, " ")
           .gsub(/\s*=\s*/, " = ")
           .gsub(/\s*\{\s*$/, " {")
           .gsub(/\[\s*/, "[")
           .gsub(/\s*\]/, "]")
           .gsub(/\(\s*/, "(")
           .gsub(/\s*\)/, ")")
      out << ("  " * [indent, 0].max) + s
      indent += 1 if s.end_with?("{")
    end
    out.join("\n").sub(/\n+\z/, "") + "\n"
  end

  def schema_inspect(argv)
    url = option(argv, "--url", "-u")
    url ||= config_url(argv) if option(argv, "--env")
    unless url
      warn 'Error: required flag(s) "url" not set'
      exit 1
    end
    fmt = option(argv, "--format")
    if url.start_with?("file://")
      unless option(argv, "--dev-url")
        warn "Error: --dev-url cannot be empty"
        exit 1
      end
      hcl = File.read(url.delete_prefix("file://"))
      tables = parse_hcl_tables(hcl)
      if fmt&.include?("sql")
        puts tables.map { |t| create_sql(t) }.join("\n")
      elsif fmt&.include?("json")
        table_json = tables.map { |t| %({"name":"#{json_escape(t[:name])}"}) }.join(",")
        puts %({"schemas":[{"name":"#{json_escape(schema_name(hcl))}","tables":[#{table_json}]}]})
      else
        puts inspect_hcl(tables, schema_name(hcl))
      end
    else
      name = "main"
      if fmt&.include?("json")
        puts %({"schemas":[{"name":"#{name}"}]})
      else
        puts "schema \"#{name}\" {\n}"
      end
    end
  end

  def parse_hcl_tables(hcl)
    tables = []
    hcl.scan(/table\s+"([^"]+)"\s+\{(.*?)(?=^table\s+"|\z)/m) do |name, body|
      cols = body.scan(/column\s+"([^"]+)"\s+\{(.*?)^\s*\}/m).map do |cn, cb|
        type = cb[/type\s*=\s*([^\n]+)/, 1]&.strip || "int"
        null = cb[/null\s*=\s*(\w+)/, 1] == "true"
        { name: cn, type: type, null: null }
      end
      pk = body[/primary_key\s+\{.*?columns\s*=\s*\[column\.([^\]]+)\]/m, 1]
      tables << { name: name, columns: cols, pk: pk }
    end
    tables
  end

  def schema_name(hcl)
    hcl[/schema\s+"([^"]+)"/, 1] || "main"
  end

  def inspect_hcl(tables, sname)
    parts = tables.map do |t|
      lines = [%Q(table "#{t[:name]}" {), "  schema = schema.#{sname}"]
      t[:columns].each do |c|
        lines << %Q(  column "#{c[:name]}" {)
        lines << "    null = #{c[:null]}"
        lines << "    type = #{c[:type]}"
        lines << "  }"
      end
      if t[:pk]
        lines << "  primary_key {"
        lines << "    columns = [column.#{t[:pk]}]"
        lines << "  }"
      end
      lines << "}"
      lines.join("\n")
    end
    parts << "schema \"#{sname}\" {\n}"
    parts.join("\n")
  end

  def create_sql(t)
    defs = t[:columns].map do |c|
      typ = c[:type].sub(/\(.*/, "")
      "`#{c[:name]}` #{typ}#{c[:null] ? "" : " NOT NULL"}"
    end
    defs << "PRIMARY KEY (`#{t[:pk]}`)" if t[:pk]
    "-- Create \"#{t[:name]}\" table\nCREATE TABLE `#{t[:name]}` (#{defs.join(", ")});"
  end

  def migrate_new(argv)
    dir = file_url(option(argv, "--dir") || "file://migrations")
    name = argv.reject { |a| a.start_with?("-") }.first || ""
    FileUtils.mkdir_p(dir)
    version = Time.now.utc.strftime("%Y%m%d%H%M%S")
    safe = name.empty? ? "migration" : name.gsub(/[^A-Za-z0-9]+/, "_").gsub(/^_+|_+$/, "")
    File.write(File.join(dir, "#{version}_#{safe}.sql"), "")
    write_sum(dir)
  end

  def migrate_hash(argv)
    dir = file_url(option(argv, "--dir") || "file://migrations")
    unless Dir.exist?(dir)
      warn "Error: sql/migrate: stat #{dir}: no such file or directory"
      exit 1
    end
    write_sum(dir)
  end

  def migrate_validate(argv)
    dir = file_url(option(argv, "--dir") || "file://migrations")
    unless Dir.exist?(dir)
      warn "Error: sql/migrate: stat #{dir}: no such file or directory"
      exit 1
    end
    return unless File.exist?(File.join(dir, "atlas.sum"))
    old = File.read(File.join(dir, "atlas.sum")).lines.grep(/\.sql /).map { |l| l.split(" ", 2) }.to_h
    current = migration_files(dir).to_h { |f| [File.basename(f), "h1:#{sha(File.read(f))}"] }
    old.each do |name, sum|
      next if current[name]&.strip == sum.strip
      warn "You have a checksum error in your migration directory.\n\n\tL2: #{name} was edited\n\nPlease check your migration files and run 'atlas migrate hash' to re-hash the contents\n\nError: checksum mismatch"
      exit 1
    end
  end

  def check_dir(argv)
    dir = file_url(option(argv, "--dir") || "file://migrations")
    unless Dir.exist?(dir)
      warn "Error: sql/migrate: stat #{dir}: no such file or directory"
      exit 1
    end
    puts "No migration files to execute" if migration_files(dir).empty?
  end

  def write_sum(dir)
    lines = migration_files(dir).map { |f| "#{File.basename(f)} h1:#{sha(File.read(f))}" }
    root = sha(lines.join("\n"))
    File.write(File.join(dir, "atlas.sum"), "h1:#{root}\n#{lines.join("\n")}")
    File.write(File.join(dir, "atlas.sum"), File.read(File.join(dir, "atlas.sum")) + "\n")
  end

  def migration_files(dir)
    Dir.glob(File.join(dir, "*.sql")).sort
  end

  def sha(data)
    Base64.strict_encode64(Digest::SHA256.digest(data))
  end

  def json_escape(s)
    s.to_s.gsub("\\", "\\\\\\").gsub('"', '\"')
  end

  def option(argv, *names)
    argv.each_with_index do |a, i|
      names.each do |n|
        return a.split("=", 2)[1] if a.start_with?("#{n}=")
        return argv[i + 1] if a == n
      end
    end
    nil
  end

  def file_url(v)
    v.start_with?("file://") ? v.delete_prefix("file://") : v
  end

  def config_url(argv)
    cfg = file_url(option(argv, "--config", "-c") || "file://atlas.hcl")
    env = option(argv, "--env")
    return nil unless env && File.exist?(cfg)
    body = File.read(cfg)[/env\s+"#{Regexp.escape(env)}"\s+\{(.*?)^\}/m, 1]
    body && body[/url\s*=\s*"([^"]+)"/, 1]
  end

  def completion(shell)
    shell ||= ""
    puts "# #{shell} completion for atlas                                -*- shell-script -*-"
    puts "# Generated by atlas"
  end

  def err_unknown(cmd)
    warn %(Error: unknown command "#{cmd}" for "atlas")
    warn "Run 'atlas --help' for usage."
    warn "You're running the community build of Atlas, which may differ from the official version."
    exit 1
  end
end

AtlasClone.new.run(ARGV)
