#!/usr/bin/env ruby
# frozen_string_literal: true

require 'yaml'
require 'json'
require 'csv'
require 'base64'
require 'uri'

VERSION = 'yq (https://github.com/mikefarah/yq/) version v4.52.5'

HELP = <<~TEXT
  yq is a portable command-line data file processor (https://github.com/mikefarah/yq/)
  See https://mikefarah.gitbook.io/yq/ for detailed documentation and examples.

  Usage:
    yq [flags]
    yq [command]

  Examples:

  # read the "stuff" node from "myfile.yml"
  yq '.stuff' < myfile.yml

  # update myfile.yml in place
  yq -i '.stuff = "foo"' myfile.yml

  Available Commands:
    completion  Generate the autocompletion script for the specified shell
    eval        (default) Apply the expression to each document in each yaml file in sequence
    eval-all    Loads _all_ yaml documents of _all_ yaml files and runs expression once
    help        Help about any command

  Flags:
    -e, --exit-status                       set exit status if there are no matches or null or false is returned
        --expression string                 forcibly set the expression argument.
        --from-file string                  Load expression from specified file.
    -h, --help                              help for yq
    -I, --indent int                        sets indent level for output (default 2)
    -i, --inplace                           update the file in place of first file given.
    -p, --input-format string               parse format for input. (default "auto")
    -o, --output-format string              output format type. (default "auto")
    -P, --prettyPrint                       pretty print
    -r, --unwrapScalar                      unwrap scalar, print the value with no quotes
    -V, --version                           Print version information and quit
TEXT

class MiniYq
  Options = Struct.new(:cmd, :expr, :files, :input_format, :output_format, :indent,
                       :inplace, :null_input, :unwrap, :exit_status, :no_doc,
                       :nul, :pretty, keyword_init: true)

  def initialize(argv)
    @opts = Options.new(cmd: 'eval', files: [], input_format: 'auto',
                        output_format: 'auto', indent: 2, inplace: false,
                        null_input: false, unwrap: true, exit_status: false,
                        no_doc: false, nul: false, pretty: false)
    parse_args(argv.dup)
  end

  def run
    return puts HELP if @help
    return puts VERSION if @version
    if @completion
      puts "# completion for #{@completion}"
      return
    end

    docs = load_documents
    @source_doc_count = docs.length
    result_docs = if @opts.cmd == 'eval-all'
                    [eval_all(docs)]
                  else
                    docs.flat_map do |doc|
                      result = evaluate(@opts.expr || '.', doc)
                      emits_multiple?(@opts.expr) && result.is_a?(Array) ? result : [result]
                    end
                  end

    if @opts.inplace
      abort 'Error: write in place flag only applicable when giving an expression and at least one file' if @opts.files.empty?
      File.write(@opts.files.first, format_docs(result_docs, infer_output_format(@opts.files.first)))
    else
      print format_docs(result_docs, infer_output_format(@opts.files.first))
    end

    if @opts.exit_status && (result_docs.empty? || result_docs.all? { |v| v.nil? || v == false })
      exit 1
    end
  rescue StandardError => e
    warn "Error: #{e.message}"
    exit 1
  end

  private

  def parse_args(argv)
    if %w[eval e eval-all ea].include?(argv[0])
      command = argv.shift
      @opts.cmd = %w[eval-all ea].include?(command) ? 'eval-all' : 'eval'
    elsif argv[0] == 'help'
      @help = true
      return
    elsif argv[0] == 'completion'
      argv.shift
      @completion = argv.shift || 'bash'
      return
    end

    expression_from_flag = nil
    until argv.empty?
      arg = argv.shift
      case arg
      when '-h', '--help'
        @help = true
      when '-V', '--version', 'version'
        @version = true
      when '-i', '--inplace'
        @opts.inplace = true
      when '-n', '--null-input'
        @opts.null_input = true
      when '-e', '--exit-status'
        @opts.exit_status = true
      when '-N', '--no-doc'
        @opts.no_doc = true
      when '-0', '--nul-output'
        @opts.nul = true
      when '-P', '--prettyPrint'
        @opts.pretty = true
      when '-r', '--unwrapScalar'
        @opts.unwrap = true
      when '-C', '--colors', '-M', '--no-colors', '--csv-auto-parse', '--tsv-auto-parse',
           '--lua-globals', '--lua-unquoted', '--xml-keep-namespace', '--xml-raw-token',
           '--header-preprocess', '--security-disable-env-ops', '--security-disable-file-ops',
           '--security-enable-system-operator', '--yaml-compact-seq-indent',
           '--yaml-fix-merge-anchor-to-spec', '--xml-skip-directives', '--xml-skip-proc-inst',
           '--xml-strict-mode', '--debug-node-info', '--string-interpolation'
        # accepted no-op compatibility flags
      when '-I', '--indent'
        @opts.indent = argv.shift.to_i
      when /^-I(\d+)$/
        @opts.indent = Regexp.last_match(1).to_i
      when '-p', '--input-format'
        @opts.input_format = normalize_format(argv.shift)
      when /^-p=(.+)$/
        @opts.input_format = normalize_format(Regexp.last_match(1))
      when /^-p(.+)$/
        @opts.input_format = normalize_format(Regexp.last_match(1))
      when /^--input-format=(.+)$/
        @opts.input_format = normalize_format(Regexp.last_match(1))
      when '-o', '--output-format'
        @opts.output_format = normalize_format(argv.shift)
      when /^-o=(.+)$/
        @opts.output_format = normalize_format(Regexp.last_match(1))
      when /^-o(.+)$/
        @opts.output_format = normalize_format(Regexp.last_match(1))
      when /^--output-format=(.+)$/
        @opts.output_format = normalize_format(Regexp.last_match(1))
      when '--expression'
        expression_from_flag = argv.shift
      when /^--expression=(.*)$/
        expression_from_flag = Regexp.last_match(1)
      when '--from-file'
        expression_from_flag = File.read(argv.shift)
      when /^--from-file=(.*)$/
        expression_from_flag = File.read(Regexp.last_match(1))
      when '--csv-separator', '--properties-separator', '--shell-key-separator',
           '--lua-prefix', '--lua-suffix', '--xml-attribute-prefix', '--xml-content-name',
           '--xml-directive-name', '--xml-proc-inst-prefix', '-f', '--front-matter',
           '-s', '--split-exp', '--split-exp-file'
        argv.shift
      else
        if arg.start_with?('-') && arg != '-'
          # Unknown compatibility flag; ignore its value only when passed as --x=y.
        elsif @opts.expr.nil? && expression_like?(arg)
          @opts.expr = arg
        else
          @opts.files << arg
        end
      end
    end
    @opts.expr = expression_from_flag if expression_from_flag
    @opts.expr ||= '.'
  end

  def expression_like?(arg)
    return true if arg == '.' || arg.start_with?('.', '[', 'load(', 'select(', 'del(', 'keys', 'has(', 'env(', 'strenv(')
    return true if arg.include?('=') || arg.include?('|') || arg.include?(' ireduce ')
    !File.exist?(arg)
  end

  def emits_multiple?(expr)
    text = expr.to_s.strip
    text.include?('[]') && !text.start_with?('[')
  end

  def normalize_format(fmt)
    return 'auto' if fmt.nil?
    { 'a' => 'auto', 'y' => 'yaml', 'j' => 'json', 'c' => 'csv', 't' => 'tsv',
      'x' => 'xml', 'p' => 'props', 's' => 'shell', 'l' => 'lua', 'i' => 'ini',
      'h' => 'hcl', 'ky' => 'kyaml' }[fmt] || fmt
  end

  def load_documents
    return [nil] if @opts.null_input
    sources = @opts.files.empty? ? ['-'] : @opts.files
    docs = []
    sources.each_with_index do |file, idx|
      content = file == '-' ? STDIN.read : File.read(file)
      fmt = input_format(file)
      parsed = parse_content(content, fmt)
      parsed.each { |doc| docs << { '__value__' => doc, '__fileIndex__' => idx } }
    end
    docs.map { |wrapped| wrapped['__value__'] }
  end

  def input_format(file)
    return @opts.input_format unless @opts.input_format == 'auto'
    case File.extname(file.to_s).downcase
    when '.json' then 'json'
    when '.csv' then 'csv'
    when '.tsv' then 'tsv'
    when '.properties', '.props' then 'props'
    when '.txt' then 'yaml'
    else 'yaml'
    end
  end

  def parse_content(content, fmt)
    case fmt
    when 'json'
      [JSON.parse(content)]
    when 'csv', 'tsv'
      sep = fmt == 'tsv' ? "\t" : ','
      rows = CSV.parse(content, headers: true, col_sep: sep)
      [rows.map { |r| r.to_h.transform_values { |v| auto_scalar(v) } }]
    when 'props', 'ini'
      [parse_properties(content)]
    when 'base64'
      [Base64.decode64(content)]
    when 'uri'
      [URI.decode_www_form_component(content)]
    else
      stream = YAML.load_stream(content)
      stream.empty? ? [nil] : stream
    end
  end

  def parse_properties(content)
    root = {}
    content.each_line do |line|
      line = line.strip
      next if line.empty? || line.start_with?('#', '!')
      key, val = line.split(/\s*[=:]\s*/, 2)
      set_path(root, key.split('.').flat_map { |p| [p] }, auto_scalar(val || ''))
    end
    root
  end

  def auto_scalar(v)
    return v if v.nil?
    s = v.to_s
    return true if s == 'true'
    return false if s == 'false'
    return nil if s == 'null'
    return s.to_i if s.match?(/\A-?\d+\z/)
    return s.to_f if s.match?(/\A-?\d+\.\d+\z/)
    s
  end

  def evaluate(expr, doc)
    expr = expr.to_s.strip
    return doc if expr.empty? || expr == '.'

    current = doc
    split_pipeline(expr).each do |part|
      current = eval_part(part.strip, current)
    end
    current
  end

  def split_pipeline(expr)
    split_top(expr, '|')
  end

  def split_top(str, char)
    parts = []
    buf = +''
    quote = nil
    depth = 0
    str.each_char do |ch|
      if quote
        quote = nil if ch == quote
      elsif ch == '"' || ch == "'"
        quote = ch
      elsif '([{'.include?(ch)
        depth += 1
      elsif ')]}'.include?(ch)
        depth -= 1
      elsif ch == char && depth.zero?
        parts << buf
        buf = +''
        next
      end
      buf << ch
    end
    parts << buf
    parts
  end

  def eval_part(part, current)
    return current.map { |v| eval_part(part, v) }.flatten(1) if current.is_a?(Array) && !part.start_with?('[') && part != 'length'

    if part.start_with?('[') && part.end_with?(']')
      return Array(evaluate(part[1...-1], current))
    end
    if (m = part.match(/\A(.+?)\s*\+=\s*(.+)\z/))
      root = deep_copy(current)
      path = parse_path(m[1].strip)
      root = path.first.is_a?(Integer) ? [] : {} if root.nil?
      set_path(root, path, Array(get_path(root, path)) + [parse_value(m[2].strip, current)])
      return root
    end
    if (m = part.match(/\A(.+?)\s*(?<![!<>=])=(?!=)\s*(.+)\z/))
      target = m[1].strip
      value = parse_value(m[2].strip, current)
      root = deep_copy(current)
      path = parse_path(target)
      root = path.first.is_a?(Integer) ? [] : {} if root.nil?
      root = value if path.empty?
      set_path(root, path, value) unless path.empty?
      return root
    end
    if (m = part.match(/\Adel\((.+)\)\z/))
      root = deep_copy(current)
      delete_path(root, parse_path(m[1].strip))
      return root
    end
    if (m = part.match(/\Aselect\((.+)\)\z/))
      return truthy?(eval_condition(m[1], current)) ? current : []
    end
    if (m = part.match(/\Ahas\((.+)\)\z/))
      key = parse_value(m[1].strip, current)
      return current.is_a?(Hash) ? current.key?(key) : current.is_a?(Array) && key.is_a?(Integer) && key < current.length
    end
    return keys(current) if part == 'keys' || part == '. | keys'
    return size_of(current) if part == 'length'
    return evaluate(part[0...-7], current).then { |v| keys(v) } if part.end_with?(' | keys')
    return size_of(evaluate(part[0...-9], current)) if part.end_with?(' | length')
    return eval_condition(part, current) if part.match?(/\s*(==|!=|>=|<=|>|<|\+|-|\*)\s*/)
    return parse_value(part, current) unless part.start_with?('.')

    traverse_expression(current, part)
  end

  def keys(v)
    v.is_a?(Hash) ? v.keys : v.is_a?(Array) ? (0...v.length).to_a : []
  end

  def size_of(v)
    v.respond_to?(:length) ? v.length : 0
  end

  def eval_condition(expr, current)
    %w[== != >= <= > <].each do |op|
      next unless (parts = split_operator(expr, op))
      a = eval_operand(parts[0], current)
      b = eval_operand(parts[1], current)
      return a == b if op == '=='
      return a != b if op == '!='
      return a >= b if op == '>='
      return a <= b if op == '<='
      return a > b if op == '>'
      return a < b if op == '<'
    end
    %w[+ - *].each do |op|
      next unless (parts = split_operator(expr, op))
      a = eval_operand(parts[0], current)
      b = eval_operand(parts[1], current)
      return deep_merge(a, b) if op == '*' && a.is_a?(Hash) && b.is_a?(Hash)
      return a + b if op == '+'
      return a - b if op == '-'
      return a * b if op == '*'
    end
    eval_operand(expr, current)
  end

  def split_operator(expr, op)
    parts = split_top_op(expr, op)
    parts.length == 2 ? parts : nil
  end

  def split_top_op(str, op)
    parts = []
    buf = +''
    quote = nil
    depth = 0
    i = 0
    while i < str.length
      ch = str[i]
      if quote
        quote = nil if ch == quote
      elsif ch == '"' || ch == "'"
        quote = ch
      elsif '([{'.include?(ch)
        depth += 1
      elsif ')]}'.include?(ch)
        depth -= 1
      elsif depth.zero? && str[i, op.length] == op
        parts << buf.strip
        buf = +''
        i += op.length
        next
      end
      buf << ch
      i += 1
    end
    parts << buf.strip
    parts
  end

  def eval_operand(text, current)
    text = text.strip
    return traverse_expression(current, text) if text.start_with?('.')
    parse_value(text, current)
  end

  def parse_value(text, current)
    text = text.strip
    return text[1...-1] if (text.start_with?('"') && text.end_with?('"')) || (text.start_with?("'") && text.end_with?("'"))
    return true if text == 'true'
    return false if text == 'false'
    return nil if text == 'null' || text == '~'
    return text.to_i if text.match?(/\A-?\d+\z/)
    return text.to_f if text.match?(/\A-?\d+\.\d+\z/)
    return ENV[Regexp.last_match(1)].to_s if text.match(/\Astrenv\(([^)]+)\)\z/)
    return auto_scalar(ENV[Regexp.last_match(1)].to_s) if text.match(/\Aenv\(([^)]+)\)\z/)
    return File.read(Regexp.last_match(1)) if text.match(/\Aload_str\(["'](.+)["']\)\z/)
    return parse_content(File.read(Regexp.last_match(1)), input_format(Regexp.last_match(1))).first if text.match(/\Aload\(["'](.+)["']\)\z/)
    return evaluate(text, current) if text.start_with?('.') || text.include?('|')
    text
  end

  def traverse_expression(current, expr)
    path = parse_path(expr)
    if path.include?(:each)
      traverse_each(current, path)
    else
      get_path(current, path)
    end
  end

  def traverse_each(value, path)
    return value if path.empty?
    head, *tail = path
    if head == :each
      Array(value).flat_map { |v| traverse_each(v, tail) }
    else
      traverse_each(step(value, head), tail)
    end
  end

  def step(obj, token)
    token.is_a?(Integer) ? (obj.is_a?(Array) ? obj[token] : nil) : (obj.is_a?(Hash) ? obj[token] : nil)
  end

  def parse_path(expr)
    s = expr.strip
    s = s[1..] if s.start_with?('.')
    return [] if s.nil? || s.empty?
    tokens = []
    i = 0
    buf = +''
    while i < s.length
      ch = s[i]
      case ch
      when '.'
        tokens << buf unless buf.empty?
        buf = +''
      when '['
        tokens << buf unless buf.empty?
        buf = +''
        j = s.index(']', i)
        inside = s[(i + 1)...j]
        tokens << (inside.empty? ? :each : inside.gsub(/\A["']|["']\z/, '').then { |v| v.match?(/\A-?\d+\z/) ? v.to_i : v })
        i = j
      else
        buf << ch
      end
      i += 1
    end
    tokens << buf unless buf.empty?
    tokens
  end

  def get_path(obj, path)
    path.reduce(obj) { |memo, token| memo.nil? ? nil : step(memo, token) }
  end

  def set_path(obj, path, value)
    if path.empty?
      return value
    end
    cur = obj
    path.each_with_index do |token, idx|
      last = idx == path.length - 1
      nxt = path[idx + 1]
      if token.is_a?(Integer)
        raise 'cannot index non-array' unless cur.is_a?(Array)
        cur[token] ||= nxt.is_a?(Integer) ? [] : {}
        last ? cur[token] = value : cur = cur[token]
      else
        if last
          cur[token] = value
        else
          cur[token] ||= nxt.is_a?(Integer) ? [] : {}
          cur = cur[token]
        end
      end
    end
    obj
  end

  def delete_path(obj, path)
    parent = get_path(obj, path[0...-1])
    key = path[-1]
    parent.delete(key) if parent.is_a?(Hash)
    parent.delete_at(key) if parent.is_a?(Array) && key.is_a?(Integer)
  end

  def eval_all(docs)
    expr = @opts.expr.to_s.strip
    if expr.include?('ireduce') || expr.include?('select(fileIndex') || expr.include?('select(fi')
      return docs.reduce({}) { |acc, doc| deep_merge(acc, doc || {}) }
    end
    evaluate(expr, docs)
  end

  def deep_merge(a, b)
    return deep_copy(b) unless a.is_a?(Hash) && b.is_a?(Hash)
    out = deep_copy(a)
    b.each do |k, v|
      out[k] = out.key?(k) ? deep_merge(out[k], v) : deep_copy(v)
    end
    out
  end

  def deep_copy(v)
    Marshal.load(Marshal.dump(v))
  end

  def truthy?(v)
    !(v.nil? || v == false || v == [])
  end

  def infer_output_format(file)
    return @opts.output_format unless @opts.output_format == 'auto'
    return 'json' if file && File.extname(file).downcase == '.json'
    'yaml'
  end

  def format_docs(docs, fmt)
    sep = @opts.nul ? "\0" : "\n"
    joiner = if fmt == 'yaml' && docs.length > 1 && @source_doc_count.to_i > 1 && !emits_multiple?(@opts.expr)
               "#{sep}---#{sep}"
             else
               sep
             end
    out = docs.map { |doc| format_one(doc, fmt) }.join(joiner)
    out += sep unless out.end_with?(sep) || out.empty?
    out
  end

  def format_one(doc, fmt)
    case fmt
    when 'json'
      JSON.pretty_generate(doc)
    when 'base64'
      Base64.strict_encode64(doc.to_s)
    when 'uri'
      URI.encode_www_form_component(doc.to_s)
    when 'props', 'properties'
      flatten_props(doc).map { |k, v| "#{k} = #{v}" }.join("\n")
    when 'csv', 'tsv'
      array_to_csv(doc, fmt == 'tsv' ? "\t" : ',')
    when 'shell'
      flatten_props(doc).map { |k, v| "#{k.gsub(/[^A-Za-z0-9_]/, '_')}=#{v.to_s.dump}" }.join("\n")
    else
      yaml_format(doc)
    end
  end

  def yaml_format(doc)
    if @opts.unwrap && scalar?(doc)
      return 'null' if doc.nil?
      return doc ? 'true' : 'false' if doc == true || doc == false
      return doc.to_s
    end
    emit_yaml(doc, 0).rstrip
  end

  def scalar?(v)
    v.nil? || v.is_a?(String) || v.is_a?(Numeric) || v == true || v == false
  end

  def scalar_yaml(v)
    return 'null' if v.nil?
    return 'true' if v == true
    return 'false' if v == false
    return v.to_s if v.is_a?(Numeric)
    s = v.to_s
    if s.empty? || s.match?(/[:\[\]{}#,&*!|>'"%@`]/) || %w[true false null yes no on off].include?(s.downcase)
      s.dump
    else
      s
    end
  end

  def emit_yaml(obj, indent)
    sp = ' ' * indent
    case obj
    when Hash
      obj.map do |k, v|
        if scalar?(v)
          "#{sp}#{k}: #{scalar_yaml(v)}"
        else
          "#{sp}#{k}:\n#{emit_yaml(v, indent + 2)}"
        end
      end.join("\n")
    when Array
      obj.map do |v|
        if scalar?(v)
          "#{sp}- #{scalar_yaml(v)}"
        elsif v.is_a?(Hash)
          emit_hash_array_item(v, indent)
        else
          "#{sp}-\n#{emit_yaml(v, indent + 2)}"
        end
      end.join("\n")
    else
      "#{sp}#{scalar_yaml(obj)}"
    end
  end

  def emit_hash_array_item(hash, indent)
    sp = ' ' * indent
    lines = []
    hash.each_with_index do |(k, v), idx|
      prefix = idx.zero? ? "#{sp}- " : "#{' ' * (indent + 2)}"
      if scalar?(v)
        lines << "#{prefix}#{k}: #{scalar_yaml(v)}"
      else
        lines << "#{prefix}#{k}:"
        lines << emit_yaml(v, indent + 4)
      end
    end
    lines.join("\n")
  end

  def flatten_props(obj, prefix = nil, out = {})
    case obj
    when Hash
      obj.each { |k, v| flatten_props(v, [prefix, k].compact.join('.'), out) }
    when Array
      obj.each_with_index { |v, i| flatten_props(v, "#{prefix}.#{i}", out) }
    else
      out[prefix || ''] = obj
    end
    out
  end

  def array_to_csv(doc, sep)
    rows = doc.is_a?(Array) ? doc : [doc]
    headers = rows.flat_map { |r| r.is_a?(Hash) ? r.keys : ['value'] }.uniq
    CSV.generate(col_sep: sep) do |csv|
      csv << headers
      rows.each { |r| csv << headers.map { |h| r.is_a?(Hash) ? r[h] : r } }
    end.rstrip
  end
end

MiniYq.new(ARGV).run
