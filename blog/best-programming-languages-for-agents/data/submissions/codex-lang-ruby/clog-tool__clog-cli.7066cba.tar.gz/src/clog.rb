#!/usr/bin/env ruby
# frozen_string_literal: true

require 'open3'

HELP = <<~TXT
  a conventional changelog for the rest of us

  Usage: executable [OPTIONS]

  Options:
    -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,
                            e.g. https://github.com/thoughtram/clog)
    -f, --from <COMMIT>     e.g. 12a8546
    -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible
                            values: markdown, json]
    -M, --major             Increment major version by one (Sets minor and patch to 0)
    -g, --git-dir <PATH>    Local .git directory (defaults to "$(pwd)/.git")
    -w, --work-tree <PATH>  Local working tree of the git project (defaults to "$(pwd)")
    -m, --minor             Increment minor version by one (Sets patch to 0)
    -p, --patch             Increment patch version by one
    -s, --subtitle <STR>    
    -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]
    -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)
    -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]
    -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with
                            --outfile)
        --setversion <VER>  e.g. 1.0.1
    -F, --from-latest-tag   use latest tag as start (instead of --from)
    -l, --link-style <STR>  The style of repository link to generate [default: github] [possible
                            values: github, gitlab, stash, cgit]
    -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the
                            same file for both --infile and --outfile and should not be used in
                            conjunction with either)
    -h, --help              Print help
    -V, --version           Print version


  If your .git directory is a child of your project directory (most common, such as /myproject/.git)
  AND not in the current working directory (i.e you need to use --work-tree or --git-dir) you only
  need to specify either the --work-tree (i.e. /myproject) OR --git-dir (i.e. /myproject/.git), you
  don't need to use both.

  If using the --config to specify a clog configuration TOML file NOT in the current working directory
  (meaning you need to use --work-tree or --git-dir) AND the TOML file is inside your project
  directory (i.e. /myproject/.clog.toml) you do not need to use --work-tree or --git-dir.
TXT

def fail_msg(message)
  warn "\e[1;31merror:\e[0m #{message}"
  exit 1
end

def j(value)
  case value
  when nil
    'null'
  when String
    '"' + value.gsub(/["\\\n\r\t]/) { |c| { '"' => '\"', '\\' => '\\\\', "\n" => '\n', "\r" => '\r', "\t" => '\t' }[c] } + '"'
  when Integer
    value.to_s
  when Array
    '[' + value.map { |v| j(v) }.join(',') + ']'
  when Hash
    '{' + value.map { |k, v| "#{j(k.to_s)}:#{j(v)}" }.join(',') + '}'
  else
    value.to_s
  end
end

def parse_args(argv)
  opts = {
    config: '.clog.toml',
    format: 'markdown',
    to: 'HEAD',
    link_style: 'github'
  }
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-h', '--help'
      puts HELP
      exit 0
    when '-V', '--version'
      puts 'clog 0.10.0'
      exit 0
    when '-r', '--repository'
      opts[:repository] = argv[i += 1]
    when '-f', '--from'
      opts[:from] = argv[i += 1]
    when '-T', '--format'
      opts[:format] = argv[i += 1]
    when '-M', '--major'
      opts[:bump] = :major
    when '-m', '--minor'
      opts[:bump] = :minor
    when '-p', '--patch'
      opts[:bump] = :patch
    when '-g', '--git-dir'
      opts[:git_dir] = argv[i += 1]
    when '-w', '--work-tree'
      opts[:work_tree] = argv[i += 1]
    when '-s', '--subtitle'
      opts[:subtitle] = argv[i += 1]
    when '-t', '--to'
      opts[:to] = argv[i += 1]
    when '-o', '--outfile'
      opts[:outfile] = argv[i += 1]
    when '-c', '--config'
      opts[:config] = argv[i += 1]
    when '-i', '--infile'
      opts[:infile] = argv[i += 1]
    when '--setversion'
      opts[:setversion] = argv[i += 1]
    when '-F', '--from-latest-tag'
      opts[:from_latest_tag] = true
    when '-l', '--link-style'
      opts[:link_style] = argv[i += 1]
    when '-C', '--changelog'
      opts[:changelog] = argv[i += 1]
    else
      if arg.start_with?('--') && arg.include?('=')
        k, v = arg.split('=', 2)
        argv[i, 1] = [k, v]
        i -= 1
      else
        fail_msg("unexpected argument '#{arg}'")
      end
    end
    i += 1
  end
  opts
end

def parse_config(path)
  cfg = { clog: {}, sections: {} }
  return cfg unless path && File.file?(path)

  current = nil
  File.readlines(path, chomp: true).each do |raw|
    line = raw.sub(/#.*/, '').strip
    next if line.empty?
    if line =~ /^\[([^\]]+)\]$/
      current = Regexp.last_match(1)
      next
    end
    next unless current && line.include?('=')
    key, val = line.split('=', 2).map(&:strip)
    key = key.gsub(/\A["']|["']\z/, '')
    case val
    when /\A"(.*)"\z/, /\A'(.*)'\z/
      value = Regexp.last_match(1)
    when /\Atrue\z/i
      value = true
    when /\Afalse\z/i
      value = false
    when /\A\[(.*)\]\z/
      value = Regexp.last_match(1).split(',').map { |x| x.strip.gsub(/\A["']|["']\z/, '') }.reject(&:empty?)
    else
      value = val
    end
    if current == 'clog'
      cfg[:clog][key] = value
    elsif current == 'sections'
      cfg[:sections][key] = Array(value)
    end
  end
  cfg
rescue StandardError
  fail_msg('Failed to parse TOML configuration file')
end

def git_base_args(opts)
  args = []
  args += ["--git-dir=#{opts[:git_dir]}"] if opts[:git_dir]
  args += ["--work-tree=#{opts[:work_tree]}"] if opts[:work_tree]
  args
end

def git(opts, *args)
  out, err, st = Open3.capture3('git', *(git_base_args(opts) + args))
  fail_msg((err.empty? ? out : err).strip) unless st.success?
  out
end

def try_git(opts, *args)
  out, _err, st = Open3.capture3('git', *(git_base_args(opts) + args))
  st.success? ? out.strip : nil
end

def latest_tag(opts)
  try_git(opts, 'describe', '--tags', '--abbrev=0')
end

def version_from_changelog(path)
  return nil unless path && File.file?(path)
  File.read(path).each_line do |line|
    return Regexp.last_match(1) if line =~ /^##+ v?([0-9]+\.[0-9]+\.[0-9]+)/
    return Regexp.last_match(1) if line =~ /<a name="v?([0-9]+\.[0-9]+\.[0-9]+)">/
  end
  nil
end

def bump_version(ver, bump)
  m = ver&.match(/\A([0-9]+)\.([0-9]+)\.([0-9]+)\z/)
  fail_msg('Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.') unless m
  major, minor, patch = m.captures.map(&:to_i)
  case bump
  when :major then [major + 1, 0, 0].join('.')
  when :minor then [major, minor + 1, 0].join('.')
  when :patch then [major, minor, patch + 1].join('.')
  end
end

def commit_url(repo, style, sha)
  return sha[0, 8] if repo.nil? || repo.empty?
  base = repo.sub(%r{\.git\z}, '')
  case style
  when 'stash'
    "#{base}/commits/#{sha}"
  when 'cgit'
    "#{base}/commit/?id=#{sha}"
  else
    "#{base}/commit/#{sha}"
  end
end

def issue_url(repo, style, num)
  return num.to_s if repo.nil? || repo.empty?
  base = repo.sub(%r{\.git\z}, '')
  case style
  when 'stash'
    "#{base}/browse/#{num}"
  when 'cgit'
    "#{base}/issues/#{num}"
  else
    "#{base}/issues/#{num}"
  end
end

def parse_commit(raw, sections, repo, style)
  parts = raw.split("\x1e", 3)
  sha = parts[0]
  subject = parts[1] || ''
  body = parts[2] || ''
  m = subject.match(/\A([A-Za-z0-9_-]+)(?:\(([^)]*)\))?!?:(.*)\z/)
  return nil unless m
  ctype, component, desc = m.captures
  section_title = sections.find { |_title, aliases| aliases.include?(ctype) }&.first
  return nil unless section_title
  text = "#{subject}\n#{body}"
  closes = text.scan(/(?:close[sd]?)\s+#([0-9]+)/i).flatten.map do |n|
    { issue: n.to_i, issue_link: issue_url(repo, style, n) }
  end
  breaking = subject.include?('!:') || body =~ /BREAKING(?: CHANGE)?:/i
  breaks = breaking ? (closes.empty? ? [{ issue: nil, issue_link: issue_url(repo, style, '') }] : closes.map(&:dup)) : nil
  {
    section: section_title,
    component: component,
    subject: desc,
    sha: sha,
    commit_link: commit_url(repo, style, sha),
    closes: closes.empty? ? nil : closes,
    breaks: breaks
  }
end

def collect_commits(opts, sections, repo, style)
  range = opts[:from] ? "#{opts[:from]}..#{opts[:to]}" : opts[:to]
  fmt = '%H%x1e%s%x1e%b%x1f'
  raw = git(opts, 'log', '--no-merges', "--format=#{fmt}", range)
  grouped = Hash.new { |h, k| h[k] = [] }
  raw.split("\x1f").each do |entry|
    entry = entry.strip
    next if entry.empty?
    commit = parse_commit(entry, sections, repo, style)
    grouped[commit[:section]] << commit if commit
  end
  grouped
rescue SystemExit
  raise
rescue StandardError
  {}
end

def render_markdown(header, sections_order, grouped)
  version = header[:version]
  date = header[:date]
  subtitle = header[:subtitle]
  s = +"<a name=\"#{version}\"></a>\n"
  s << "## #{version}"
  s << " #{subtitle}" if subtitle
  s << "  (#{date})\n\n\n"
  sections_order.each do |title|
    commits = grouped[title]
    next if commits.nil? || commits.empty?
    s << "#### #{title}\n\n"
    commits.each do |c|
      if c[:component] && !c[:component].empty?
        s << "* **#{c[:component]}:** #{c[:subject]}"
      else
        s << "*  #{c[:subject]}"
      end
      extras = ["[#{c[:sha][0, 8]}](#{c[:commit_link]})"]
      Array(c[:closes]).each { |cl| extras << "closes [##{cl[:issue]}](#{cl[:issue_link]})" }
      Array(c[:breaks]).each { |br| extras << "breaks [##{br[:issue]}](#{br[:issue_link]})" }
      s << " (#{extras.join(', ')})\n"
    end
    s << "\n"
  end
  s << "\n"
  s
end

def rustish_json(header, sections_order, grouped)
  h = +'{"header":{'
  h << '"version":' << (header[:version] ? "Some(#{j(header[:version])})" : 'None')
  h << ',"patch_version":false'
  h << ',"subtitle":' << (header[:subtitle] ? j(header[:subtitle]) : 'null')
  h << ',"date":' << j(header[:date]) << '}'
  sec = sections_order.filter_map do |title|
    commits = grouped[title]
    next if commits.nil? || commits.empty?
    body = commits.map do |c|
      j({
        component: c[:component],
        subject: c[:subject],
        commit_link: c[:commit_link],
        closes: c[:closes],
        breaks: c[:breaks]
      })
    end.join(',')
    "{\"title\":#{j(title)},\"commits\":[#{body}]}"
  end
  h << ',"sections":' << (sec.empty? ? 'null' : "[#{sec.join(',')}]") << '}'
  h
end

started = Time.now
opts = parse_args(ARGV)
cfg = parse_config(opts[:config])
opts[:repository] ||= cfg[:clog]['repository']
opts[:subtitle] ||= cfg[:clog]['subtitle']
opts[:from_latest_tag] ||= cfg[:clog]['from-latest-tag']

if opts[:from_latest_tag] && !opts[:from]
  opts[:from] = latest_tag(opts)
end

if opts[:changelog]
  opts[:infile] = opts[:changelog]
  opts[:outfile] = opts[:changelog]
end

version = opts[:setversion]
if version.nil? && opts[:bump]
  base = version_from_changelog(opts[:infile] || opts[:outfile] || opts[:changelog])
  base ||= opts[:from].to_s.sub(/\Av/, '')
  version = bump_version(base, opts[:bump])
end
version ||= version_from_changelog(opts[:infile] || opts[:outfile] || opts[:changelog])

sections = cfg[:sections]
grouped = sections.empty? ? {} : collect_commits(opts, sections, opts[:repository], opts[:link_style])
header = { version: version, subtitle: opts[:subtitle], date: Time.now.strftime('%Y-%m-%d') }

output = if opts[:format] == 'json'
           rustish_json(header, sections.keys, grouped)
         else
           render_markdown(header, sections.keys, grouped)
         end

old = ''
old = File.read(opts[:infile]) if opts[:infile] && File.file?(opts[:infile])
old = File.read(opts[:outfile]) if opts[:outfile] && !opts[:infile] && File.file?(opts[:outfile])

if opts[:outfile]
  File.write(opts[:outfile], output + old)
else
  print output
end

elapsed = ((Time.now - started) * 1000).round
puts "changelog written. (took #{elapsed} ms)"
