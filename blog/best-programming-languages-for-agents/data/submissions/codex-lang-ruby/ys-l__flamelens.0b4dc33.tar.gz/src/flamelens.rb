#!/usr/bin/env ruby
# frozen_string_literal: true

HELP = <<~HELP
  Usage: executable [OPTIONS] [FILENAME]

  Arguments:
    [FILENAME]  Profile data filename

  Options:
        --sorted   Whether to sort the stacks by time spent
        --echo     Print data to stdout on exit. Useful when piping to other tools
        --debug    Show debug info
    -h, --help     Print help
    -V, --version  Print version
HELP

VERSION = "flamelens 0.3.1\n"

def usage_for_error(args)
  if args.length == 1 && args.first.include?("=")
    opt = args.first.split("=", 2).first
    "Usage: executable #{opt} [FILENAME]\n"
  else
    "Usage: executable [OPTIONS] [FILENAME]\n"
  end
end

def unexpected_arg(arg, args)
  $stderr.puts "error: unexpected argument '#{arg}' found"
  $stderr.puts
  $stderr.puts "  tip: to pass '#{arg}' as a value, use '-- #{arg}'" if arg.start_with?("-")
  $stderr.puts if arg.start_with?("-")
  $stderr.print usage_for_error(args)
  $stderr.puts
  $stderr.puts "For more information, try '--help'."
  exit 2
end

def unexpected_value(arg, args)
  opt, val = arg.split("=", 2)
  $stderr.puts "error: unexpected value '#{val}' for '#{opt}' found; no more were expected"
  $stderr.puts
  $stderr.print usage_for_error(args)
  $stderr.puts
  $stderr.puts "For more information, try '--help'."
  exit 2
end

def panic_read_file
  $stderr.puts
  $stderr.puts "thread 'main' (1) panicked at src/main.rs:44:47:"
  $stderr.puts 'Could not read file: Os { code: 2, kind: NotFound, message: "No such file or directory" }'
  $stderr.puts 'note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace'
  exit 101
end

def read_input(filename)
  if filename
    begin
      File.binread(filename)
    rescue Errno::ENOENT
      panic_read_file
    end
  else
    STDIN.binmode
    STDIN.read || +""
  end
end

def parse_folded(data)
  stacks = []
  data.each_line do |line|
    stripped = line.strip
    next if stripped.empty?

    stack, count = stripped.rpartition(" ").values_at(0, 2)
    value = count.to_f
    value = 1.0 if value <= 0.0
    frames = stack.split(";").reject(&:empty?)
    stacks << [frames, value] unless frames.empty?
  end
  stacks
end

def build_tree(stacks)
  root = { name: "all", value: 0.0, children: {} }
  stacks.each do |frames, value|
    root[:value] += value
    node = root
    frames.each do |frame|
      node[:children][frame] ||= { name: frame, value: 0.0, children: {} }
      node = node[:children][frame]
      node[:value] += value
    end
  end
  root
end

def render_node(node, depth, total, rows, sorted)
  return if node[:name] != "all" && rows.length >= 200

  if node[:name] != "all"
    pct = total.positive? ? (node[:value] * 100.0 / total) : 0.0
    rows << "#{'  ' * depth}#{node[:name]} #{node[:value].to_i} (#{format('%.1f', pct)}%)"
  end
  children = node[:children].values
  children = children.sort_by { |child| [-child[:value], child[:name]] } if sorted
  children.each { |child| render_node(child, depth + 1, total, rows, sorted) }
end

def run_viewer(data, sorted)
  unless STDOUT.tty? && STDIN.tty?
    $stderr.puts 'Error: Os { code: 11, kind: WouldBlock, message: "Resource temporarily unavailable" }'
    exit 1
  end

  rows = []
  tree = build_tree(parse_folded(data))
  render_node(tree, -1, tree[:value], rows, sorted)
  rows = ["No profile data"] if rows.empty?

  print "\e[?1049h\e[?25l\e[2J"
  begin
    loop do
      print "\e[H"
      puts "flamelens"
      puts "Total samples: #{tree[:value].to_i}"
      puts "q: quit  r: reset  /: search"
      puts
      rows.first(20).each { |row| puts row[0, 120] }
      STDOUT.flush
      ch = STDIN.read(1)
      break if ch == "q" || ch == "\u0003"
    end
  ensure
    print "\e[?25h\e[?1049l"
  end
  exit 0
end

args = ARGV.dup
sorted = false
echo = false
filename = nil
literal = false

args.each_with_index do |arg, idx|
  if literal
    if filename.nil?
      filename = arg
    else
      unexpected_arg(arg, args)
    end
    next
  end

  case arg
  when "--"
    literal = true
  when "-h", "--help"
    print HELP
    exit 0
  when "-V", "--version"
    print VERSION
    exit 0
  when "--sorted"
    sorted = true
  when "--echo"
    echo = true
  when "--debug"
    # Accepted for compatibility. The reference does not emit debug text before
    # initializing the terminal UI in the observable non-TTY path.
  else
    unexpected_value(arg, args) if arg.start_with?("--") && arg.include?("=")
    if arg.start_with?("-")
      unexpected_arg(arg, args)
    elsif filename.nil?
      filename = arg
    else
      unexpected_arg(arg, args)
    end
  end
end

data = read_input(filename)
if echo
  print data
  print "\n"
end

run_viewer(data, sorted)
