#!/usr/bin/env ruby
# frozen_string_literal: true

require "open3"
require "shellwords"

RESET = "\e[0m"
COLORS = {
  "red" => "31",
  "green" => "32",
  "yellow" => "33",
  "blue" => "34",
  "magenta" => "35",
  "cyan" => "36"
}.freeze
GROUPS = %w[numbers urls pointers dates paths quotes key-value-pairs uuids ip-addresses processes json].freeze

def c(code, text)
  "\e[#{code}m#{text}#{RESET}"
end

HELP_LONG = <<~HELP
  A log file highlighter

  Usage: executable [OPTIONS] [FILE]

  Arguments:
    [FILE]
            Filepath

  Options:
    -f, --follow
            Follow the contents of a file

    -p, --print
            Print the output to stdout

        --config-path <CONFIG_PATH>
            Provide a custom path to a configuration file

    -e, --exec <EXEC>
            Run command and view the output in a pager

        --highlight <COLOR_WORD>
            Highlights in the form color:word1,word2
            
            [possible values: red, green, yellow, blue, magenta, cyan]

        --enable <ENABLED_HIGHLIGHTERS>
            Enable specific highlighters
            
            [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
            ip-addresses, processes, json]

        --disable <DISABLED_HIGHLIGHTERS>
            Disable specific highlighters
            
            [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
            ip-addresses, processes, json]

        --disable-builtin-keywords
            Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
            and common REST verbs)

        --pager <PAGER>
            Override the default pager command used by tspin. (e.g. `--pager="ov -f [FILE]"`)
            
            [env: TAILSPIN_PAGER=]

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
HELP

HELP_SHORT = <<~HELP
  A log file highlighter

  Usage: executable [OPTIONS] [FILE]

  Arguments:
    [FILE]  Filepath

  Options:
    -f, --follow
            Follow the contents of a file
    -p, --print
            Print the output to stdout
        --config-path <CONFIG_PATH>
            Provide a custom path to a configuration file
    -e, --exec <EXEC>
            Run command and view the output in a pager
        --highlight <COLOR_WORD>
            Highlights in the form color:word1,word2
        --enable <ENABLED_HIGHLIGHTERS>
            Enable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
            quotes, key-value-pairs, uuids, ip-addresses, processes, json]
        --disable <DISABLED_HIGHLIGHTERS>
            Disable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
            quotes, key-value-pairs, uuids, ip-addresses, processes, json]
        --disable-builtin-keywords
            Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
            and common REST verbs)
        --pager <PAGER>
            Override the default pager command used by tspin. (e.g. `--pager="ov -f [FILE]"`) [env:
            TAILSPIN_PAGER=]
    -h, --help
            Print help (see more with '--help')
    -V, --version
            Print version
HELP

def die_usage(message, usage = "Usage: executable [OPTIONS] [FILE]")
  warn "error: #{message}"
  warn
  warn usage
  warn
  warn "For more information, try '--help'."
  exit 2
end

def parse_group_list(value, flag)
  value.split(",").each do |group|
    next if GROUPS.include?(group)

    warn "error: invalid value '#{group}' for '#{flag} <#{flag == "--enable" ? "ENABLED" : "DISABLED"}_HIGHLIGHTERS>'"
    warn "  [possible values: #{GROUPS.join(", ")}]"
    warn
    warn "For more information, try '--help'."
    exit 2
  end
end

def parse_args(argv)
  opts = {
    follow: false, print: false, exec: nil, file: nil, enable: nil, disable: [],
    disable_builtin: false, highlights: [], pager: nil, config_path: nil
  }
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when "-h"
      puts HELP_SHORT
      exit 0
    when "--help"
      puts HELP_LONG
      exit 0
    when "-V", "--version"
      puts "tspin 5.6.0"
      exit 0
    when "-f", "--follow"
      opts[:follow] = true
    when "-p", "--print"
      opts[:print] = true
    when "--disable-builtin-keywords"
      opts[:disable_builtin] = true
    when "-e", "--exec", "--config-path", "--pager", "--highlight", "--enable", "--disable"
      i += 1
      die_usage("a value is required for '#{arg} <#{arg.delete_prefix("--").tr("-", "_").upcase}>'") if i >= argv.length
      value = argv[i]
      case arg
      when "-e", "--exec" then opts[:exec] = value
      when "--config-path" then opts[:config_path] = value
      when "--pager" then opts[:pager] = value
      when "--highlight"
        color, words = value.split(":", 2)
        unless COLORS.key?(color) && words && !words.empty?
          die_usage("invalid value '#{value}' for '--highlight <COLOR_WORD>': invalid variant: #{color}")
        end
        opts[:highlights] << [COLORS[color], words.split(",").reject(&:empty?)]
      when "--enable"
        parse_group_list(value, "--enable")
        opts[:enable] ||= []
        opts[:enable].concat(value.split(","))
      when "--disable"
        parse_group_list(value, "--disable")
        opts[:disable].concat(value.split(","))
      end
    else
      if arg.start_with?("--enable=")
        value = arg.split("=", 2)[1]
        parse_group_list(value, "--enable")
        opts[:enable] ||= []
        opts[:enable].concat(value.split(","))
      elsif arg.start_with?("--disable=")
        value = arg.split("=", 2)[1]
        parse_group_list(value, "--disable")
        opts[:disable].concat(value.split(","))
      elsif arg.start_with?("--highlight=")
        argv.insert(i + 1, arg.split("=", 2)[1])
        argv[i] = "--highlight"
        redo
      elsif arg.start_with?("--")
        die_usage("unexpected argument '#{arg}' found\n\n  tip: to pass '#{arg}' as a value, use '-- #{arg}'")
      elsif opts[:file]
        die_usage("unexpected argument '#{arg}' found")
      else
        opts[:file] = arg
      end
    end
    i += 1
  end

  if opts[:enable] && !opts[:disable].empty?
    warn "Error:   × cannot both enable and disable highlighters"
    warn
    exit 1
  end
  opts
end

def enabled?(opts, group)
  return opts[:enable].include?(group) if opts[:enable]

  !opts[:disable].include?(group)
end

def split_path(path)
  path.split(/(\/)/).map { |part| part == "/" ? c("33", part) : (part.empty? ? "" : c("32", part)) }.join
end

def highlight_token(token, opts)
  unless opts[:disable_builtin]
    return c("31", token) if token =~ /\A(?:ERROR|ERR|FATAL|FAIL(?:ED)?|PANIC)\b/i
    return c("33", token) if token =~ /\A(?:WARN|WARNING)\b/i
    return c("37", token) if token =~ /\AINFO\b/i
    return c("32", token) if token =~ /\ADEBUG\b/i
    return c("34", token) if token =~ /\ATRACE\b/i
    return c("3;31", token) if token =~ /\A(?:true|false|null|nil)\z/i
    rest = { "GET" => "42;30", "POST" => "43;30", "PUT" => "45;30", "PATCH" => "45;30", "DELETE" => "41;30" }
    return c(rest[token.upcase], " #{token} ") if rest.key?(token.upcase)
  end

  opts[:highlights].each do |code, words|
    words.each { |word| return c(code, token) if token.downcase.include?(word.downcase) }
  end

  if enabled?(opts, "dates")
    return token.gsub(/\A(\d{4})-(\d{2})-(\d{2})([ T])(\d{2}):(\d{2}):(\d{2})([,.]\d+)?/) do
      "#{c("35", Regexp.last_match(1))}#{c("2", "-")}#{c("35", Regexp.last_match(2))}#{c("2", "-")}#{c("35", Regexp.last_match(3))}#{c("31", Regexp.last_match(4))}#{c("34", Regexp.last_match(5))}#{c("2", ":")}#{c("34", Regexp.last_match(6))}#{c("2", ":")}#{c("34", Regexp.last_match(7))}#{Regexp.last_match(8) ? c("2", Regexp.last_match(8)) : ""}"
    end if token =~ /\A\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}/
    return token.gsub(/\A(\d{4})-(\d{2})-(\d{2})/) { "#{c("35", Regexp.last_match(1))}#{c("2", "-")}#{c("35", Regexp.last_match(2))}#{c("2", "-")}#{c("35", Regexp.last_match(3))}" } if token =~ /\A\d{4}-\d{2}-\d{2}\z/
  end

  return c("33", token) if enabled?(opts, "quotes") && token =~ /\A(['"]).*\1\z/m
  return c("3;34", token.gsub(".", c("31", "."))) if enabled?(opts, "ip-addresses") && token =~ /\A\d{1,3}(?:\.\d{1,3}){3}\z/
  return c("3;35", token) if enabled?(opts, "uuids") && token =~ /\A[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\z/i
  return c("3;35", token) if enabled?(opts, "pointers") && token =~ /\A0x[0-9a-f]+\z/i
  return highlight_url(token, opts) if enabled?(opts, "urls") && token =~ %r{\Ahttps?://}
  return split_path(token) if enabled?(opts, "paths") && token =~ %r{\A/(?:[\w.\-]+/)*[\w.\-]+\z}
  return c("36", token) if enabled?(opts, "numbers") && token =~ /\A[-+]?\d+(?:\.\d+)?\z/

  if enabled?(opts, "key-value-pairs") && token =~ /\A([^=\s]+)(=)(.+)\z/
    key = Regexp.last_match(1)
    value = Regexp.last_match(3)
    return "#{c("2", key)}#{c("37", "=")}#{highlight_token(value, opts)}"
  end

  token
end

def highlight_url(token, opts)
  token.sub(%r{\A(https?)://([^/?#]+)(.*)\z}) do
    scheme = Regexp.last_match(1)
    domain = Regexp.last_match(2)
    rest = Regexp.last_match(3)
    rest = rest.gsub(%r{/[^\s?&#]*}) { |m| c("34", m) }
    rest = rest.gsub(/[?&=]/) { |m| c("31", m) }
    rest = rest.gsub(/\b\d+\b/) { |m| enabled?(opts, "numbers") ? c("36", m) : m }
    "#{c("2;32", scheme)}://#{c("2;34", domain)}#{rest}"
  end
end

def highlight_line(line, opts)
  out = +""
  line.scan(/(\s+|[A-Za-z_][\w.-]*=(?:"[^"]*"|'[^']*'|[^\s]+)|"[^"]*"|'[^']*'|https?:\/\/[^\s]+|\/[\w.\/-]+|\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:[,.]\d+)?|\d{4}-\d{2}-\d{2}|[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|0x[0-9a-f]+|\d{1,3}(?:\.\d{1,3}){3}|[-+]?\d+(?:\.\d+)?|[A-Za-z_][\w.-]*|.)/i) do |m|
    tok = m[0]
    out << (tok =~ /\A\s+\z/ ? tok : highlight_token(tok, opts))
  end
  out
end

def emit_io(io, opts)
  io.each_line { |line| print highlight_line(line.chomp, opts); print "\n" }
end

opts = parse_args(ARGV.dup)

if opts[:exec]
  Open3.popen2e(opts[:exec]) do |_stdin, out, wait_thr|
    emit_io(out, opts)
    exit wait_thr.value.exitstatus || 0
  end
elsif opts[:file]
  unless File.exist?(opts[:file])
    warn "Error:   ⚠ #{c("33", opts[:file])}: No such file or directory"
    warn
    exit 1
  end
  File.open(opts[:file], "r") do |f|
    emit_io(f, opts)
    if opts[:follow]
      loop do
        sleep 0.2
        emit_io(f, opts)
      end
    end
  end
else
  emit_io($stdin, opts)
end
