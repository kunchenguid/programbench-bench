#!/usr/bin/env ruby
# frozen_string_literal: true

HELP = <<~HELP
  Usage: executable [OPTIONS]

  Options:
    -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]
    -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]
    -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]
    -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]
    -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]
    -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]
        --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
        --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
        --show-ortho        show keyboard in ortholinear format
        --nokb              pass this flag to disable the keyboard layout display.
        --cat               the most important flag. don't practice alone.
    -h, --help              Print help
HELP

OPTIONS = {
  '-n' => ['--n', '<2|3|4|w|file>', true],
  '--n' => ['--n', '<2|3|4|w|file>', true],
  '-t' => ['--top', '<1-200>', true],
  '--top' => ['--top', '<1-200>', true],
  '-c' => ['--combi', '<1-200>', true],
  '--combi' => ['--combi', '<1-200>', true],
  '-r' => ['--rep', '<number>', true],
  '--rep' => ['--rep', '<number>', true],
  '-w' => ['--wpm', '<number>', true],
  '--wpm' => ['--wpm', '<number>', true],
  '-a' => ['--acc', '<0-100>', true],
  '--acc' => ['--acc', '<0-100>', true],
  '--emu-in' => ['--emu-in', '<layout>', true],
  '--emu-out' => ['--emu-out', '<layout>', true],
  '--show-ortho' => ['--show-ortho', nil, false],
  '--nokb' => ['--nokb', nil, false],
  '--cat' => ['--cat', nil, false],
  '-h' => ['--help', nil, false],
  '--help' => ['--help', nil, false]
}.freeze

NUMERIC = {
  '--top' => 'top',
  '--combi' => 'combi',
  '--rep' => 'rep',
  '--wpm' => 'wpm',
  '--acc' => 'acc'
}.freeze

def clap_error(message)
  warn "error: #{message}"
  warn ''
  warn 'Usage: executable [OPTIONS]'
  warn ''
  warn "For more information, try '--help'."
  exit 2
end

def missing_value(name, value_name)
  warn "error: a value is required for '#{name} #{value_name}' but none was supplied"
  warn ''
  warn "For more information, try '--help'."
  exit 2
end

def invalid_digit(value, name, value_name)
  warn "error: invalid value '#{value}' for '#{name} #{value_name}': invalid digit found in string"
  warn ''
  warn "For more information, try '--help'."
  exit 2
end

def parse_positive_int(value, name, value_name)
  invalid_digit(value, name, value_name) unless value.match?(/\A[0-9]+\z/)
  value.to_i
end

def startup_error
  $stdout.write "\e[?1049h"
  $stdout.flush
  warn 'Error: Os { code: 6, kind: Uncategorized, message: "No such device or address" }'
  exit 1
end

config = {
  '--n' => '2',
  '--top' => 50,
  '--combi' => 2,
  '--rep' => 3,
  '--wpm' => 40,
  '--acc' => 94,
  '--emu-in' => '',
  '--emu-out' => ''
}

argv = ARGV.dup
i = 0
while i < argv.length
  arg = argv[i]

  if arg.start_with?('--') && arg.include?('=')
    opt, value = arg.split('=', 2)
    spec = OPTIONS[opt]
    clap_error("unexpected argument '#{arg}' found") if spec.nil?
    if spec[2]
      argv[i, 1] = [opt, value]
      next
    end
  end

  spec = OPTIONS[arg]
  clap_error("unexpected argument '#{arg}' found") if spec.nil?

  canonical, value_name, takes_value = spec
  if canonical == '--help'
    print HELP
    exit 0
  end

  if takes_value
    value = argv[i + 1]
    missing_value(canonical, value_name) if value.nil?
    if value.start_with?('-')
      clap_error("unexpected argument '#{value}' found")
    end
    if NUMERIC.key?(canonical)
      config[canonical] = parse_positive_int(value, canonical, value_name)
    else
      config[canonical] = value
    end
    i += 2
  else
    config[canonical] = true
    i += 1
  end
end

if config['--top'] < 1 || config['--top'] > 200
  puts 'Invalid argument for top. Use a number between 1 and 200.'
  exit 1
end

if config['--combi'] < 1 || config['--combi'] > 200
  puts 'Invalid argument for combi. Use a number between 1 and 200.'
  exit 1
end

if config['--acc'] < 0 || config['--acc'] > 100
  puts 'Invalid argument for acc. Use a number between 0 and 100.'
  exit 1
end

if (config['--emu-in'].empty? && !config['--emu-out'].empty?) ||
   (!config['--emu-in'].empty? && config['--emu-out'].empty?)
  puts 'You need to specify both emu_in and emu_out.'
  exit 1
end

n_value = config['--n']
unless %w[2 3 4 w].include?(n_value) || File.file?(n_value)
  puts "File not found: #{n_value}"
  exit 1
end

# The reference program tries to enter its terminal UI after validation. In this
# cleanroom it cannot open the input device and reports the OS error below.
startup_error unless STDIN.tty? && STDOUT.tty?

words = if File.file?(n_value)
          File.read(n_value).split(/[,\s]+/).reject(&:empty?)
        elsif n_value == 'w'
          %w[the and you that was for are with his they]
        else
          %w[th he in er an re on at en nd ti es or te of ed is it al ar st to nt ng se ha as ou io le ve co me de hi ri ro ic ne ea ra ce li ch ll be ma si om ur ca el ta la ns di fo ho pe ec pr no ct us ac ot il tr ly nc et ut ss so rs un lo wa ge ie wh ee wi em ad ol rt po]
        end

lesson = words.first([config['--combi'], words.length].min)
puts "ngrrram"
puts
puts lesson.map { |w| ([w] * config['--rep']).join(' ') }.join(' ')
puts
puts 'Press Ctrl-C to quit.'
