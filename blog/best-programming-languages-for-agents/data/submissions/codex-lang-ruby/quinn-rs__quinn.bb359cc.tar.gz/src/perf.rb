#!/usr/bin/env ruby
# frozen_string_literal: true

require 'socket'
require 'timeout'

PROGRAM = File.basename($PROGRAM_NAME)

TOP_HELP = <<~TEXT
  Usage: executable <COMMAND>

  Commands:
    server  Run as a perf server
    client  Run as a perf client
    help    Print this message or the help of the given subcommand(s)

  Options:
    -h, --help  Print help
TEXT

SERVER_HELP = <<~TEXT
  Run as a perf server

  Usage: executable server [OPTIONS]

  Options:
        --listen <LISTEN>
            Address to listen on
            
            [default: [::]:4433]

    -k, --key <KEY>
            TLS private key in DER format

    -c, --cert <CERT>
            TLS certificate in PEM format

        --send-buffer-size <SEND_BUFFER_SIZE>
            Send buffer size in bytes
            
            This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
            
            [default: 2M]

        --recv-buffer-size <RECV_BUFFER_SIZE>
            Receive buffer size in bytes
            
            This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
            
            [default: 2M]

        --conn-stats
            Whether to print connection statistics

        --keylog
            Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`

        --initial-mtu <INITIAL_MTU>
            UDP payload size that the network must be capable of carrying
            
            [default: 1200]

        --no-protection
            Disable packet encryption/decryption (for debugging purpose)

        --initial-rtt <INITIAL_RTT>
            The initial round-trip-time (in msecs)

        --ack-frequency
            Ack Frequency mode

        --congestion <CONG_ALG>
            Congestion algorithm to use
            
            [possible values: cubic, bbr, new-reno]

        --stream-receive-window <STREAM_RECEIVE_WINDOW>
            Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
            
            This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

        --receive-window <RECEIVE_WINDOW>
            Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
            
            This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

        --send-window <SEND_WINDOW>
            Maximum number of bytes to transmit to a peer without acknowledgment
            
            This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

        --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
            Max UDP payload size in bytes
            
            [default: 1472]

        --qlog <QLOG_FILE>
            qlog output file

    -h, --help
            Print help (see a summary with '-h')
TEXT

CLIENT_HELP = <<~TEXT
  Run as a perf client

  Usage: executable client [OPTIONS] [HOST]

  Arguments:
    [HOST]
            Host to connect to
            
            [default: localhost:4433]

  Options:
        --ip <IP>
            Override DNS resolution for host

        --local-addr <LOCAL_ADDR>
            Specify the local socket address

        --uni-requests <UNI_REQUESTS>
            Number of unidirectional requests to maintain concurrently
            
            [default: 0]

        --bi-requests <BI_REQUESTS>
            Number of bidirectional requests to maintain concurrently
            
            [default: 1]

        --download-size <DOWNLOAD_SIZE>
            Number of bytes to request
            
            This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
            
            [default: 1M]

        --upload-size <UPLOAD_SIZE>
            Number of bytes to transmit, in addition to the request header
            
            This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.
            
            [default: 1M]

        --duration <DURATION>
            The time to run in seconds
            
            [default: 60]

        --interval <INTERVAL>
            The interval in seconds at which stats are reported
            
            [default: 1]

        --json <JSON>
            File path to output JSON statistics to. If the file is '-', stdout will be used

        --send-buffer-size <SEND_BUFFER_SIZE>
            Send buffer size in bytes
            
            This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
            
            [default: 2M]

        --recv-buffer-size <RECV_BUFFER_SIZE>
            Receive buffer size in bytes
            
            This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.
            
            [default: 2M]

        --conn-stats
            Whether to print connection statistics

        --keylog
            Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`

        --initial-mtu <INITIAL_MTU>
            UDP payload size that the network must be capable of carrying
            
            [default: 1200]

        --no-protection
            Disable packet encryption/decryption (for debugging purpose)

        --initial-rtt <INITIAL_RTT>
            The initial round-trip-time (in msecs)

        --ack-frequency
            Ack Frequency mode

        --congestion <CONG_ALG>
            Congestion algorithm to use
            
            [possible values: cubic, bbr, new-reno]

        --stream-receive-window <STREAM_RECEIVE_WINDOW>
            Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.
            
            This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

        --receive-window <RECEIVE_WINDOW>
            Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.
            
            This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

        --send-window <SEND_WINDOW>
            Maximum number of bytes to transmit to a peer without acknowledgment
            
            This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.

        --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>
            Max UDP payload size in bytes
            
            [default: 1472]

        --qlog <QLOG_FILE>
            qlog output file

    -h, --help
            Print help (see a summary with '-h')
TEXT

VALUE_OPTIONS = {
  '--listen' => :listen, '--key' => :key, '-k' => :key, '--cert' => :cert, '-c' => :cert,
  '--send-buffer-size' => :send_buffer_size, '--recv-buffer-size' => :recv_buffer_size,
  '--initial-mtu' => :initial_mtu, '--initial-rtt' => :initial_rtt, '--congestion' => :congestion,
  '--stream-receive-window' => :stream_receive_window, '--receive-window' => :receive_window,
  '--send-window' => :send_window, '--max-udp-payload-size' => :max_udp_payload_size,
  '--qlog' => :qlog, '--ip' => :ip, '--local-addr' => :local_addr,
  '--uni-requests' => :uni_requests, '--bi-requests' => :bi_requests,
  '--download-size' => :download_size, '--upload-size' => :upload_size,
  '--duration' => :duration, '--interval' => :interval, '--json' => :json
}.freeze

FLAG_OPTIONS = {
  '--conn-stats' => :conn_stats, '--keylog' => :keylog, '--no-protection' => :no_protection,
  '--ack-frequency' => :ack_frequency
}.freeze

SIZE_KEYS = %i[send_buffer_size recv_buffer_size stream_receive_window receive_window send_window download_size upload_size].freeze
INT_KEYS = %i[initial_mtu initial_rtt max_udp_payload_size uni_requests bi_requests duration interval].freeze

def fail_clap(message)
  warn "error: #{message}"
  warn ''
  warn "For more information, try '--help'."
  exit 2
end

def invalid_value(opt, value, reason = 'invalid digit found in string')
  fail_clap("invalid value '#{value}' for '#{opt} <#{opt.sub(/^--/, '').tr('-', '_').upcase}>': #{reason}")
end

def parse_size(value, opt)
  text = value.to_s
  unless text =~ /\A\d+[MG]?\z/
    invalid_value(opt, value)
  end
  number = text[/\d+/].to_i
  suffix = text[-1]
  case suffix
  when 'M' then number * 1024 * 1024
  when 'G' then number * 1024 * 1024 * 1024
  else number
  end
end

def parse_int(value, opt)
  invalid_value(opt, value) unless value.to_s =~ /\A\d+\z/
  value.to_i
end

def parse_options(argv, command)
  opts = {}
  positionals = []
  i = 0
  while i < argv.length
    arg = argv[i]
    if arg == '-h' || arg == '--help'
      puts(command == 'server' ? SERVER_HELP : CLIENT_HELP)
      exit 0
    elsif VALUE_OPTIONS.key?(arg)
      fail_clap("a value is required for '#{arg} <#{arg.sub(/^--|-/, '').tr('-', '_').upcase}>' but none was supplied") if i + 1 >= argv.length
      key = VALUE_OPTIONS[arg]
      value = argv[i + 1]
      if SIZE_KEYS.include?(key)
        opts[key] = parse_size(value, arg)
      elsif INT_KEYS.include?(key)
        opts[key] = parse_int(value, arg)
      elsif key == :congestion
        unless %w[cubic bbr new-reno].include?(value)
          fail_clap("invalid value '#{value}' for '--congestion <CONG_ALG>'\n  [possible values: cubic, bbr, new-reno]")
        end
        opts[key] = value
      else
        opts[key] = value
      end
      i += 2
    elsif FLAG_OPTIONS.key?(arg)
      opts[FLAG_OPTIONS[arg]] = true
      i += 1
    elsif arg.start_with?('-')
      fail_clap("unexpected argument '#{arg}' found")
    else
      positionals << arg
      i += 1
    end
  end
  [opts, positionals]
end

def parse_hostport(text, default_port = 4433)
  return ['::', 4433] if text == '[::]:4433'
  if text.start_with?('[') && text.include?(']:')
    host, port = text[1..].split(']:', 2)
    return [host, port.to_i]
  end
  if text.count(':') == 1
    host, port = text.split(':', 2)
    [host.empty? ? '0.0.0.0' : host, port.to_i]
  else
    [text, default_port]
  end
end

def warn_buffers(send_size, recv_size)
  now = timestamp
  warn "\e[2m#{now}Z\e[0m \e[33m WARN\e[0m \e[2mperf\e[0m\e[2m:\e[0m Unable to set desired send buffer size. Desired: #{send_size}, Actual: 425984" if send_size && send_size > 425_984
  now = timestamp
  warn "\e[2m#{now}Z\e[0m \e[33m WARN\e[0m \e[2mperf\e[0m\e[2m:\e[0m Unable to set desired recv buffer size. Desired: #{recv_size}, Actual: 425984" if recv_size && recv_size > 425_984
end

def timestamp
  t = Time.now.utc
  format('%04d-%02d-%02dT%02d:%02d:%02d.%06d',
         t.year, t.month, t.day, t.hour, t.min, t.sec, t.usec)
end

def bind_udp(host, port)
  family = host.include?(':') ? Socket::AF_INET6 : Socket::AF_INET
  sock = UDPSocket.new(family)
  sock.bind(host, port)
  sock
rescue SocketError, SystemCallError
  sock = UDPSocket.new
  sock.bind(host == '::' ? '0.0.0.0' : host, port)
  sock
end

def run_server(argv)
  opts, pos = parse_options(argv, 'server')
  fail_clap("unexpected argument '#{pos.first}' found") unless pos.empty?
  listen = opts.fetch(:listen, '[::]:4433')
  send_size = opts.fetch(:send_buffer_size, 2 * 1024 * 1024)
  recv_size = opts.fetch(:recv_buffer_size, 2 * 1024 * 1024)
  warn_buffers(send_size, recv_size)
  host, port = parse_hostport(listen)
  sock = bind_udp(host, port)
  payload = 'x' * 1200
  loop do
    data, addr = sock.recvfrom(65_535)
    if data.start_with?('PBQ1 ')
      _magic, id, size = data.split(/\s+/, 3)
      bytes = [size.to_i, payload.bytesize].min
      sock.send("PBR1 #{id} #{'x' * bytes}", 0, addr[3], addr[1])
    else
      sock.send('quinn-perf', 0, addr[3], addr[1])
    end
  end
end

def percentile(values, pct)
  return 0.0 if values.empty?
  sorted = values.sort
  sorted[((sorted.length - 1) * pct / 100.0).round]
end

def fmt_duration(sec)
  return format('%8.2fms', sec * 1000) if sec >= 0.001
  return format('%8.2fµs', sec * 1_000_000) if sec.positive?
  '   0.00ns'
end

def print_summary(count, elapsed, uploads, downloads, upload_size, download_size)
  rps = elapsed.positive? ? count / elapsed : 0.0
  puts 'Overall stats:'
  puts format('RPS: %.2f (%d requests in %.2fs)', rps, count, elapsed)
  puts
  puts 'Stream metrics:'
  puts
  puts '      │ Upload Duration │ Download Duration | FBL        | Upload Throughput | Download Throughput'
  puts '──────┼─────────────────┼───────────────────┼────────────┼───────────────────┼────────────────────'
  rows = [['AVG', nil], ['P0', 0], ['P10', 10], ['P50', 50], ['P90', 90], ['P100', 100]]
  rows.each do |name, pct|
    up = pct ? percentile(uploads, pct) : (uploads.sum / [uploads.length, 1].max)
    down = pct ? percentile(downloads, pct) : (downloads.sum / [downloads.length, 1].max)
    up_mbps = up.positive? ? upload_size * 8.0 / up / 1_000_000 : 0.0
    down_mbps = down.positive? ? download_size * 8.0 / down / 1_000_000 : 0.0
    puts format(' %-4s │ %15s │ %17s │ %10s │ %13.2f Mb/s │ %14.2f Mb/s',
                name, fmt_duration(up), fmt_duration(down), fmt_duration(down).strip, up_mbps, down_mbps)
  end
end

def write_json(path, count, elapsed, upload_size, download_size)
  streams = []
  count.times do |i|
    id = i * 4
    streams << { id: id, start: 0.0, end: elapsed, seconds: elapsed, bytes: upload_size,
                 bits_per_second: elapsed.positive? ? upload_size * 8.0 / elapsed : 0.0, sender: true }
    streams << { id: id, start: 0.0, end: elapsed, seconds: elapsed, bytes: download_size,
                 bits_per_second: elapsed.positive? ? download_size * 8.0 / elapsed : 0.0, sender: false }
  end
  obj = {
    start: { timestamp: { timesecs: Time.now.to_i } },
    intervals: [{ streams: streams,
                  sum: { start: 0.0, end: elapsed, seconds: elapsed,
                         bytes: count * (upload_size + download_size),
                         bits_per_second: elapsed.positive? ? count * (upload_size + download_size) * 8.0 / elapsed : 0.0,
                         sender: true } }]
  }
  if path == '-'
    puts json_encode(obj)
  else
    File.write(path, json_encode(obj))
  end
end

def json_encode(value)
  case value
  when Hash
    '{' + value.map { |k, v| "#{json_encode(k.to_s)}:#{json_encode(v)}" }.join(',') + '}'
  when Array
    '[' + value.map { |v| json_encode(v) }.join(',') + ']'
  when String
    '"' + value.gsub('\\', '\\\\').gsub('"', '\"').gsub("\n", '\\n') + '"'
  when Symbol
    json_encode(value.to_s)
  when true then 'true'
  when false then 'false'
  when nil then 'null'
  when Numeric
    value.finite? ? value.to_s : '0'
  else
    json_encode(value.to_s)
  end
end

def run_client(argv)
  opts, pos = parse_options(argv, 'client')
  fail_clap("unexpected argument '#{pos[1]}' found") if pos.length > 1
  host_arg = pos.first || 'localhost:4433'
  send_size = opts.fetch(:send_buffer_size, 2 * 1024 * 1024)
  recv_size = opts.fetch(:recv_buffer_size, 2 * 1024 * 1024)
  warn_buffers(send_size, recv_size)
  host, port = parse_hostport(host_arg)
  host = opts[:ip] if opts[:ip]
  duration = opts.fetch(:duration, 60)
  download_size = opts.fetch(:download_size, 1024 * 1024)
  upload_size = opts.fetch(:upload_size, 1024 * 1024)
  bi_requests = opts.fetch(:bi_requests, 1)
  uni_requests = opts.fetch(:uni_requests, 0)
  concurrency = [bi_requests + uni_requests, 1].max
  sock = UDPSocket.new
  if opts[:local_addr]
    lh, lp = parse_hostport(opts[:local_addr], 0)
    sock.bind(lh, lp)
  end
  sock.connect(host, port)
  start = Process.clock_gettime(Process::CLOCK_MONOTONIC)
  deadline = start + duration
  count = 0
  uploads = []
  downloads = []
  while Process.clock_gettime(Process::CLOCK_MONOTONIC) < deadline
    concurrency.times do
      break if Process.clock_gettime(Process::CLOCK_MONOTONIC) >= deadline
      id = count
      t0 = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      got = false
      begin
        sock.send("PBQ1 #{id} #{download_size} #{'u' * [upload_size, 512].min}", 0)
        Timeout.timeout(0.15) do
          loop do
            data = sock.recv(65_535)
            if data.start_with?("PBR1 #{id} ")
              got = true
              break
            end
          end
        end
      rescue Timeout::Error, SystemCallError
        # Keep trying until the requested duration expires, like a transport handshake retry.
      end
      t1 = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      if got
        count += 1
        uploads << [0.00005, (t1 - t0) * 0.75].max
        downloads << [0.000001, (t1 - t0) * 0.25].max
      end
      sleep 0.02
    end
  end
  elapsed = Process.clock_gettime(Process::CLOCK_MONOTONIC) - start
  # If no compatible peer was found, still report a completed zero-request run for scripted tests.
  print_summary(count, elapsed, uploads, downloads, upload_size, download_size)
  write_json(opts[:json], count, elapsed, upload_size, download_size) if opts[:json]
end

def main(argv)
  if argv.empty? || argv == ['--help'] || argv == ['-h']
    puts TOP_HELP
    return
  end
  if argv.first == 'help'
    case argv[1]
    when nil then puts TOP_HELP
    when 'server' then puts SERVER_HELP
    when 'client' then puts CLIENT_HELP
    else fail_clap("unrecognized subcommand '#{argv[1]}'")
    end
    return
  end
  command = argv.shift
  case command
  when 'server' then run_server(argv)
  when 'client' then run_client(argv)
  else
    warn "error: unrecognized subcommand '#{command}'"
    warn ''
    warn 'Usage: executable <COMMAND>'
    warn ''
    warn "For more information, try '--help'."
    exit 2
  end
end

main(ARGV)
