#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require 'json'
require 'yaml'

VERSION = '39.2.0'
MISSING = Object.new
HELP = (<<'TXT'

  fx #{VERSION}
    Terminal JSON viewer

  Usage
    fx data.json
    fx data.json .field
    curl ... | fx

  Flags
    -h, --help            print help
    -v, --version         print version
    --themes              print themes
    --comp <shell>        print completion script
    -r, --raw             treat input as a raw string
    -s, --slurp           read all inputs into an array
    --yaml                parse input as YAML
    --toml                parse input as TOML
    --strict              strict mode
    --no-inline           disable inlining in output
    --game-of-life        play the game of life

  More info
    https://fx.wtf

  Author
    Anton Medvedev <anton@medv.io>
TXT
).gsub('#{VERSION}', VERSION)

BASH_COMP = "complete -o filenames -C fx fx\n"
ZSH_COMP = <<~'TXT'
#compdef fx

_fx() {
    local -a reply
    reply=("${(@f)$(COMP_ZSH="${LBUFFER}" fx)}")
    if (( ${#reply} )); then
        local -a insert_files display_files insert_other display_other
        local line display rest value typ
        
        for line in "${reply[@]}"; do
            display="${line%%$'\t'*}"
            rest="${line#*$'\t'}"
            value="${rest%%$'\t'*}"
            typ="${rest#*$'\t'}"

            if [[ "$typ" == "file" ]]; then
                display_files+=("$display")
                insert_files+=("$value")
            else
                display_other+=("$display")
                insert_other+=("$value")
            fi
        done

        if (( ${#insert_files} )); then
            compadd -f -d display_files -a insert_files
        fi
        if (( ${#insert_other} )); then
            compadd -S '' -d display_other -a insert_other
        fi
    fi
}

if [ "$funcstack[1]" = "_fx" ]; then
    _fx "$@"
else
    compdef _fx fx
fi
TXT
FISH_COMP = "complete --command fx --arguments '(COMP_FISH=(commandline -cp) fx)'\n"

class MiniFx
  def initialize(argv)
    @argv = argv.dup
    @raw = false
    @slurp = false
    @yaml = false
    @toml = false
    @no_inline = false
  end

  def run
    exprs = parse_flags(@argv)
    input, exprs = extract_input(exprs)
    values = parse_input(input)
    value = @slurp ? values : values.last
    if exprs.empty?
      # The real program opens an interactive viewer. In clean non-TTY use, a
      # deterministic rendering is more useful and keeps documented piping sane.
      puts format_value(value, 0, true)
      return 0
    end
    exprs.each { |expr| value = apply_expr(value, expr.strip) }
    puts format_value(value, 0, true)
    0
  rescue JSON::ParserError => e
    warn e.message
    1
  rescue Psych::SyntaxError => e
    warn e.message
    1
  rescue StandardError => e
    warn e.message
    1
  end

  def parse_flags(args)
    out = []
    until args.empty?
      a = args.shift
      case a
      when '-h', '--help' then print HELP; exit 0
      when '-v', '--version' then puts VERSION; exit 0
      when '--themes' then print_themes; exit 0
      when '--comp'
        shell = args.shift.to_s
        case shell
        when 'bash' then print BASH_COMP
        when 'zsh' then print ZSH_COMP
        when 'fish' then print FISH_COMP
        else warn 'unknown shell type'; exit 1
        end
        exit 0
      when '-r', '--raw' then @raw = true
      when '-s', '--slurp' then @slurp = true
      when '--yaml' then @yaml = true
      when '--toml' then @toml = true
      when '--strict' then # Ruby's parser is already strict enough for this reimplementation.
      when '--no-inline' then @no_inline = true
      when '--game-of-life' then puts 'Game of Life is available only in the interactive viewer.'; exit 0
      else out << a
      end
    end
    out
  end

  def print_themes
    10.times do |i|
      puts %(export FX_THEME="#{i}")
      puts %({)
      puts %(  "string": "Fox jumps over the lazy dog",)
      puts %(  "number": 1234567890,)
      puts %(  "boolean": true,)
      puts %(  "null": null,)
      puts %(  "collapsed": {"preview":…})
      puts %(})
    end
  end

  def extract_input(args)
    return [$stdin.read, args] if args.empty?
    first = args.first
    if File.file?(first)
      [File.read(first), args[1..] || []]
    else
      [$stdin.read, args]
    end
  end

  def parse_input(input)
    return [input] if @raw
    input = input.to_s
    return [nil] if input.empty?
    if @yaml
      docs = YAML.load_stream(input)
      return docs.empty? ? [nil] : docs
    end
    if @toml
      return [parse_toml(input)]
    end
    parse_json_stream(input)
  end

  def parse_json_stream(input)
    begin
      return [JSON.parse(input)]
    rescue JSON::ParserError
      lines = input.lines.map(&:strip).reject(&:empty?)
      if lines.length > 1
        return lines.map { |line| JSON.parse(line) }
      end
      raise
    end
  end

  def parse_toml(input)
    root = {}
    current = root
    input.each_line do |line|
      line = line.sub(/#.*/, '').strip
      next if line.empty?
      if line =~ /^\[(.+)\]$/
        current = root
        Regexp.last_match(1).split('.').each { |k| current = (current[k] ||= {}) }
        next
      end
      k, v = line.split('=', 2)
      next unless v
      current[k.strip] = parse_scalar(v.strip)
    end
    root
  end

  def parse_scalar(v)
    return v[1...-1] if (v.start_with?('"') && v.end_with?('"')) || (v.start_with?("'") && v.end_with?("'"))
    return true if v == 'true'
    return false if v == 'false'
    return nil if v == 'null'
    if v.start_with?('[') || v.start_with?('{')
      JSON.parse(v.gsub(/([A-Za-z_][A-Za-z0-9_]*)\s*=/, '"\1":')) rescue v
    elsif v =~ /^-?\d+$/
      v.to_i
    elsif v =~ /^-?\d+\.\d+$/
      v.to_f
    else
      v
    end
  end

  def apply_expr(value, expr)
    return value if expr.empty? || expr == '.' || expr == 'x'
    if expr.include?('=>')
      return apply_arrow(value, expr)
    end
    return value.keys if expr == 'Object.keys(x)' || expr == 'Object.keys(.)' || expr == '. | keys' || expr == 'keys'
    if expr.start_with?('.') || expr.start_with?('[')
      return eval_path(value, expr)
    end
    raise "ReferenceError: #{expr} is not defined"
  end

  def eval_path(value, path)
    s = path.dup
    s = s[1..] if s.start_with?('.')
    cur = value
    until s.nil? || s.empty?
      if s.start_with?('.')
        s = s[1..]
        next
      elsif s.start_with?('[')
        j = s.index(']') or raise 'Unexpected end of input'
        token = s[1...j]
        key = if token.start_with?('"', "'")
                token[1...-1]
              elsif token =~ /^-?\d+$/
                token.to_i
              else
                token
              end
        cur = dig_value(cur, key)
        s = s[(j + 1)..]
      else
        m = s.match(/\A([A-Za-z_$][\w$-]*|\d+)/) or raise "Unexpected token #{s[0]}"
        key = m[1]
        cur = key == 'length' ? length_of(cur) : dig_value(cur, key)
        s = s[m[0].length..]
      end
    end
    cur
  end

  def dig_value(obj, key)
    if obj.is_a?(Array)
      key = key.to_i if key.to_s =~ /^-?\d+$/
      return obj[key] if key.is_a?(Integer) && key >= -obj.length && key < obj.length
      MISSING
    elsif obj.is_a?(Hash)
      obj.key?(key.to_s) ? obj[key.to_s] : MISSING
    else
      MISSING
    end
  end

  def length_of(v)
    v.respond_to?(:length) ? v.length : nil
  end

  def apply_arrow(value, expr)
    body = expr.split('=>', 2)[1].strip
    body = body[1..-2].strip if body.start_with?('{') && body.end_with?('}')
    case body
    when /\Ax\.map\(\s*(\w+)\s*=>\s*(.+)\)\z/
      var = Regexp.last_match(1); b = Regexp.last_match(2)
      return Array(value).map { |item| eval_simple(b, var => item, 'x' => value) }
    when /\Ax\.filter\(\s*(\w+)\s*=>\s*(.+)\)\z/
      var = Regexp.last_match(1); b = Regexp.last_match(2)
      return Array(value).select { |item| eval_simple(b, var => item, 'x' => value) }
    when /\Ax\.reduce\(\s*\(?\s*(\w+)\s*,\s*(\w+)\s*\)?\s*=>\s*(.+),\s*(.+)\)\z/
      av = Regexp.last_match(1); bv = Regexp.last_match(2); b = Regexp.last_match(3); init = eval_simple(Regexp.last_match(4), 'x' => value)
      return Array(value).reduce(init) { |acc, item| eval_simple(b, av => acc, bv => item, 'x' => value) }
    when /\A\(?\s*\{(.+)\}\s*\)?\z/
      h = {}
      Regexp.last_match(1).split(/\s*,\s*/).each do |pair|
        k, v = pair.split(':', 2)
        h[k.strip.gsub(/\A['"]|['"]\z/, '')] = eval_simple(v.strip, 'x' => value)
      end
      return h
    else
      return eval_simple(body, 'x' => value)
    end
  end

  def eval_simple(expr, vars)
    expr = expr.strip
    return vars[expr] if vars.key?(expr)
    return expr[1...-1] if (expr.start_with?('"') && expr.end_with?('"')) || (expr.start_with?("'") && expr.end_with?("'"))
    return expr.to_i if expr =~ /^-?\d+$/
    return expr.to_f if expr =~ /^-?\d+\.\d+$/
    return true if expr == 'true'
    return false if expr == 'false'
    return nil if expr == 'null' || expr == 'undefined'
    if expr =~ /\A(.+?)\s*(===|==|!=|>=|<=|>|<)\s*(.+)\z/
      a = eval_simple(Regexp.last_match(1), vars); op = Regexp.last_match(2); b = eval_simple(Regexp.last_match(3), vars)
      return a == b if op == '===' || op == '=='
      return a != b if op == '!='
      return a > b if op == '>'
      return a < b if op == '<'
      return a >= b if op == '>='
      return a <= b if op == '<='
    end
    if expr =~ /\A(.+)\s*([+*\/-])\s*(.+)\z/
      a = eval_simple(Regexp.last_match(1), vars); op = Regexp.last_match(2); b = eval_simple(Regexp.last_match(3), vars)
      return a + b if op == '+'
      return a * b if op == '*'
      return a / b if op == '/'
      return a - b if op == '-'
    end
    if expr.start_with?('x.', 'x[')
      return eval_path(vars['x'], expr.sub(/\Ax/, '.'))
    end
    if expr =~ /\A(\w+)\.(.+)\z/ && vars.key?(Regexp.last_match(1))
      return eval_path(vars[Regexp.last_match(1)], '.' + Regexp.last_match(2))
    end
    raise "ReferenceError: #{expr} is not defined"
  end

  def format_value(v, indent = 0, top = false)
    return 'undefined' if v.equal?(MISSING)
    case v
    when Hash
      return '{}' if v.empty?
      if !top && !@no_inline && inline_hash?(v)
        return '{ ' + v.map { |k, val| JSON.generate(k) + ': ' + format_value(val, indent, false) }.join(', ') + ' }'
      end
      pad = ' ' * indent
      inner = v.map do |k, val|
        force_block = val.is_a?(Hash)
        ' ' * (indent + 2) + JSON.generate(k) + ': ' + format_value(val, indent + 2, force_block)
      end.join(",\n")
      "{\n#{inner}\n#{pad}}"
    when Array
      return '[]' if v.empty?
      if !top && !@no_inline && inline_array?(v)
        return '[ ' + v.map { |e| format_value(e, indent, false) }.join(', ') + ' ]'
      end
      pad = ' ' * indent
      inner = v.map { |e| ' ' * (indent + 2) + format_value(e, indent + 2, false) }.join(",\n")
      "[\n#{inner}\n#{pad}]"
    when String then top ? v : JSON.generate(v)
    when NilClass then 'null'
    else JSON.generate(v)
    end
  end

  def inline_array?(a)
    a.all? { |e| scalar?(e) || inline_hash?(e) } && a.map { |e| format_value(e, 0, false).length }.sum + a.length * 2 < 100
  end

  def inline_hash?(h)
    h.all? { |_k, v| scalar?(v) } && h.length <= 3
  end

  def scalar?(v)
    !v.is_a?(Array) && !v.is_a?(Hash)
  end
end

exit MiniFx.new(ARGV).run
