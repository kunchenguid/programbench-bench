#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = "tex-fmt 0.5.6"

DEFAULTS = {
  check: false,
  print: false,
  fail_on_change: false,
  wrap: true,
  wraplen: 80,
  wrapmin: 70,
  tabsize: 2,
  tabchar: "space",
  stdin: false,
  config: nil,
  verbosity: "warn",
  lists: %w[itemize enumerate description inlineroman inventory],
  verbatims: %w[verbatim Verbatim lstlisting minted comment],
  no_indent_envs: %w[document],
  wrap_chars: [],
  recursive: false
}.freeze

HELP = <<~HELP
  tex-fmt 0.5.6

  LaTeX formatter written in Rust

  Usage: executable [OPTIONS] [files]...

  Arguments:
    [files]...  List of files to be formatted

  Options:
    -c, --check               Check formatting, do not modify files
    -p, --print               Print to stdout, do not modify files
    -f, --fail-on-change      Format files and return non-zero exit code if files are modified
    -n, --nowrap              Do not wrap long lines
    -l, --wraplen <N>         Line length for wrapping [default: 80]
    -t, --tabsize <N>         Number of characters to use as tab size [default: 2]
        --usetabs             Use tabs instead of spaces for indentation
    -s, --stdin               Process stdin as a single file, output to stdout
        --config <PATH>       Path to config file
        --noconfig            Do not read any config file
    -v, --verbose             Show info messages
    -q, --quiet               Hide warning messages
        --trace               Show trace messages
        --completion <SHELL>  Generate shell completion script [possible values: bash, elvish, fish, powershell, zsh]
        --man                 Generate a man page
        --args                Print arguments passed to tex-fmt and exit
    -r, --recursive           Recursively search for files to format
    -h, --help                Print help
    -V, --version             Print version
HELP

class TexFmt
  EXTENSIONS = %w[.tex .bib .cls .sty].freeze

  def initialize(options)
    @options = options
  end

  def format(text, name = "<stdin>")
    lines = text.lines(chomp: true)
    had_final_newline = text.end_with?("\n")
    out = []
    indent = 0
    list_stack = []
    fmt_off = false
    verbatim = nil

    lines.each do |raw|
      line = raw.sub(/\r\z/, "")
      stripped = line.strip

      if fmt_off
        out << line
        fmt_off = false if stripped.include?("% tex-fmt: on")
        next
      end
      if stripped.include?("% tex-fmt: off")
        out << line
        fmt_off = true
        next
      end
      if stripped.end_with?("% tex-fmt: skip")
        out << line
        next
      end

      if verbatim
        out << line
        verbatim = nil if stripped =~ /^\\end\{#{Regexp.escape(verbatim)}\}/
        next
      end

      if (env = begin_env(stripped)) && @options[:verbatims].include?(env)
        out << indent_string(indent) + stripped
        verbatim = env
        next
      end

      if stripped.empty?
        out << ""
        next
      end

      before_dedent = dedent_before?(stripped)
      if before_dedent
        if (env = end_env(stripped)) && @options[:lists].include?(env) && !list_stack.empty?
          indent = [list_stack.pop[:base] - 1, 0].max
        else
          indent = [indent - 1, 0].max
        end
      end

      line_indent = indent
      if item_line?(stripped) && !list_stack.empty?
        line_indent = list_stack.last[:base]
        indent = line_indent
      elsif !list_stack.empty? && !begin_env(stripped) && !end_env(stripped)
        line_indent = [indent, list_stack.last[:base] + 1].max
      end

      emit_wrapped(out, stripped, line_indent)

      if item_line?(stripped) && !list_stack.empty?
        list_stack.last[:after_item] = true
        indent = list_stack.last[:base] + 1
        next
      end

      unless before_dedent
        if (env = begin_env(stripped))
          unless @options[:no_indent_envs].include?(env)
            indent += 1
            if @options[:lists].include?(env)
              list_stack << { env: env, base: indent, after_item: false }
              indent += 1
            end
          end
        elsif stripped.start_with?("@") && stripped.include?("{") && stripped.end_with?(",")
          indent += 1
        elsif opens_math?(stripped) || stripped == "{"
          indent += 1
        end
      end
    end

    result = out.join("\n")
    result += "\n" if had_final_newline || !lines.empty?
    result
  end

  private

  def indent_string(level)
    char = @options[:tabchar] == "tab" ? "\t" : " " * @options[:tabsize]
    char * [level, 0].max
  end

  def begin_env(line)
    line[/^\\begin\{([^}]+)\}/, 1]
  end

  def end_env(line)
    line[/^\\end\{([^}]+)\}/, 1]
  end

  def item_line?(line)
    line.start_with?("\\item") || line.start_with?("\\bibitem")
  end

  def opens_math?(line)
    line == "\\[" || line == "\\(" || line.start_with?("\\left")
  end

  def closes_math?(line)
    line == "\\]" || line == "\\)" || line.start_with?("\\right")
  end

  def dedent_before?(line)
    end_env(line) || closes_math?(line) || line == "}"
  end

  def emit_wrapped(out, stripped, level)
    prefix = indent_string(level)
    if !@options[:wrap] || stripped.length + prefix.length <= @options[:wraplen] || unwrappable?(stripped)
      out << prefix + stripped
      return
    end

    if stripped.start_with?("%")
      words = stripped.sub(/^%\s*/, "").split(/\s+/)
      wrap_words(words, wrap_width, prefix + "% ", prefix + "% ").each { |l| out << l }
      return
    end

    if (m = stripped.match(/^(\\[A-Za-z]+\*?(?:\[[^\]]*\])?\{)(.*)(\})$/))
      first = prefix + m[1]
      rest_prefix = indent_string(level + 1)
      lines = wrap_words(m[2].split(/\s+/), wrap_width, first, rest_prefix)
      lines[-1] += m[3]
      lines.each { |l| out << l }
      return
    end

    wrap_words(stripped.split(/\s+/), wrap_width, prefix, prefix).each { |l| out << l }
  end

  def wrap_width
    [@options[:wrapmin], 20].max
  end

  def unwrappable?(line)
    line.start_with?("\\begin", "\\end", "\\item", "\\[", "\\]", "\\(", "\\)") ||
      line.start_with?("@") || line.include?("&") || line.end_with?("\\")
  end

  def wrap_words(words, width, first_prefix, next_prefix)
    return [first_prefix.rstrip] if words.empty?
    lines = []
    cur = first_prefix.dup
    prefix = first_prefix
    words.each do |word|
      sep = cur == prefix ? "" : " "
      if cur.length + sep.length + word.length > width && cur != prefix
        lines << cur.rstrip
        prefix = next_prefix
        cur = prefix + word
      else
        cur += sep + word
      end
    end
    lines << cur.rstrip
    lines
  end
end

def parse_config(path, opts)
  return opts unless path && File.file?(path)

  File.readlines(path, chomp: true).each do |line|
    line = line.sub(/#.*/, "").strip
    next if line.empty? || !line.include?("=")
    key, val = line.split("=", 2).map(&:strip)
    sym = key.tr("-", "_").to_sym
    case sym
    when :check, :print, :stdin
      opts[sym] = val == "true"
    when :fail_on_change
      opts[:fail_on_change] = val == "true"
    when :wrap
      opts[:wrap] = val == "true"
    when :wraplen, :wrapmin, :tabsize
      opts[sym] = val.to_i
    when :tabchar, :verbosity
      opts[sym] = val.gsub(/\A["']|["']\z/, "")
    when :lists, :verbatims, :no_indent_envs, :wrap_chars
      arr = val.scan(/"([^"]*)"|'([^']*)'/).map { |a, b| a || b }
      if sym == :lists
        opts[:lists] = (arr + DEFAULTS[:lists]).uniq
      elsif sym == :verbatims
        opts[:verbatims] = (arr + DEFAULTS[:verbatims]).uniq
      elsif sym == :no_indent_envs
        opts[:no_indent_envs] = (arr + DEFAULTS[:no_indent_envs]).uniq
      else
        opts[:wrap_chars] = arr
      end
    end
  end
  opts[:config] = path
  opts
end

def discover_config
  cwd = Dir.pwd
  local = File.join(cwd, "tex-fmt.toml")
  return local if File.file?(local)

  dir = cwd
  loop do
    return File.join(dir, "tex-fmt.toml") if File.directory?(File.join(dir, ".git")) && File.file?(File.join(dir, "tex-fmt.toml"))
    parent = File.dirname(dir)
    break if parent == dir
    dir = parent
  end
  home = ENV["HOME"]
  cfg = home && File.join(home, ".config", "tex-fmt", "tex-fmt.toml")
  File.file?(cfg) ? cfg : nil
end

def parse_args(argv)
  opts = DEFAULTS.dup
  files = []
  explicit_config = nil
  noconfig = false
  print_args = false
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when "-h", "--help" then puts HELP; exit 0
    when "-V", "--version" then puts VERSION; exit 0
    when "-c", "--check" then opts[:check] = true
    when "-p", "--print" then opts[:print] = true
    when "-f", "--fail-on-change" then opts[:fail_on_change] = true
    when "-n", "--nowrap" then opts[:wrap] = false
    when "-s", "--stdin" then opts[:stdin] = true
    when "-r", "--recursive" then opts[:recursive] = true
    when "-v", "--verbose" then opts[:verbosity] = "info"
    when "-q", "--quiet" then opts[:verbosity] = "error"
    when "--trace" then opts[:verbosity] = "trace"
    when "--usetabs" then opts[:tabchar] = "tab"
    when "--noconfig" then noconfig = true
    when "--args" then print_args = true
    when "--man" then puts man_page; exit 0
    when "--completion"
      i += 1
      puts completion(argv[i] || "bash")
      exit 0
    when "-l", "--wraplen"
      i += 1
      opts[:wraplen] = parse_integer(argv[i])
      opts[:wrapmin] = opts[:wraplen] > 10 ? opts[:wraplen] - 10 : opts[:wraplen]
    when "-t", "--tabsize"
      i += 1
      opts[:tabsize] = parse_integer(argv[i])
    when "--config"
      i += 1
      explicit_config = argv[i]
    else
      if a.start_with?("-") && a.length > 2 && !a.start_with?("--")
        a[1..].chars.each do |ch|
          case ch
          when "c" then opts[:check] = true
          when "p" then opts[:print] = true
          when "f" then opts[:fail_on_change] = true
          when "n" then opts[:wrap] = false
          when "s" then opts[:stdin] = true
          when "r" then opts[:recursive] = true
          when "v" then opts[:verbosity] = "info"
          when "q" then opts[:verbosity] = "error"
          else files << a
          end
        end
      elsif a.start_with?("-")
        warn "error: unexpected argument '#{a}' found"
        exit 2
      else
        files << a
      end
    end
    i += 1
  end

  config_path = noconfig ? nil : (explicit_config || discover_config)
  opts = parse_config(config_path, opts) if config_path
  # Re-apply command line overrides after config.
  parse_cli_overrides!(opts, argv)
  [opts, files, print_args]
end

def parse_integer(value)
  Integer(value)
rescue StandardError
  warn "error: invalid value '#{value}'"
  exit 2
end

def parse_cli_overrides!(opts, argv)
  i = 0
  while i < argv.length
    case argv[i]
    when "-c", "--check" then opts[:check] = true
    when "-p", "--print" then opts[:print] = true
    when "-f", "--fail-on-change" then opts[:fail_on_change] = true
    when "-n", "--nowrap" then opts[:wrap] = false
    when "-s", "--stdin" then opts[:stdin] = true
    when "-r", "--recursive" then opts[:recursive] = true
    when "-v", "--verbose" then opts[:verbosity] = "info"
    when "-q", "--quiet" then opts[:verbosity] = "error"
    when "--trace" then opts[:verbosity] = "trace"
    when "--usetabs" then opts[:tabchar] = "tab"
    when "-l", "--wraplen"
      i += 1
      opts[:wraplen] = argv[i].to_i
      opts[:wrapmin] = opts[:wraplen] > 10 ? opts[:wraplen] - 10 : opts[:wraplen]
    when "-t", "--tabsize"
      i += 1
      opts[:tabsize] = argv[i].to_i
    else
      if argv[i].start_with?("-") && !argv[i].start_with?("--")
        argv[i][1..].chars.each do |ch|
          opts[:check] = true if ch == "c"
          opts[:print] = true if ch == "p"
          opts[:fail_on_change] = true if ch == "f"
          opts[:wrap] = false if ch == "n"
          opts[:stdin] = true if ch == "s"
          opts[:recursive] = true if ch == "r"
          opts[:verbosity] = "info" if ch == "v"
          opts[:verbosity] = "error" if ch == "q"
        end
      end
    end
    i += 1
  end
end

def print_args(opts, files)
  puts "tex-fmt"
  rows = [
    ["check", opts[:check]], ["print", opts[:print]], ["fail-on-change", opts[:fail_on_change]],
    ["wrap", opts[:wrap]], ["wraplen", opts[:wraplen]], ["wrapmin", opts[:wrapmin]],
    ["tabsize", opts[:tabsize]], ["tabchar", opts[:tabchar]], ["stdin", opts[:stdin]],
    ["config", opts[:config] || "None"], ["verbosity", opts[:verbosity]]
  ]
  rows.each { |k, v| printf("  %-24s %s\n", "#{k}:", v) }
  { "lists" => opts[:lists], "verbatims" => opts[:verbatims], "no-indent-envs" => opts[:no_indent_envs], "wrap-chars" => opts[:wrap_chars], "files" => files }.each do |k, arr|
    printf("  %-24s %s\n", "#{k}:", arr.first || "")
    arr[1..]&.each { |x| printf("  %-24s %s\n", "", x) }
  end
end

def log(level, opts, file, msg)
  order = { "error" => 0, "warn" => 1, "info" => 2, "trace" => 3 }
  return if order[opts[:verbosity]] < order[level]
  $stderr.puts "#{level.upcase}: tex-fmt #{file}: #{msg} "
end

def recursive_files(paths)
  paths = ["."] if paths.empty?
  ignored = []
  %w[.ignore .gitignore].each do |f|
    next unless File.file?(f)
    ignored.concat(File.readlines(f, chomp: true).map(&:strip).reject { |l| l.empty? || l.start_with?("#") })
  end
  files = []
  paths.each do |p|
    if File.directory?(p)
      Dir.glob(File.join(p, "**", "*"), File::FNM_DOTMATCH).each do |f|
        next unless File.file?(f)
        rel = f.sub(%r{\A\./}, "")
        next if rel.split("/").include?(".git")
        next unless TexFmt::EXTENSIONS.include?(File.extname(f))
        next if ignored.any? { |pat| File.fnmatch?(pat, File.basename(f)) || File.fnmatch?(pat, rel) }
        files << f
      end
    else
      files << p
    end
  end
  files.sort
end

def man_page
  ".TH tex-fmt 1  \"tex-fmt 0.5.6\"\n.SH NAME\ntex\\-fmt \\- LaTeX formatter written in Rust\n.SH SYNOPSIS\ntex\\-fmt [OPTIONS] [files]\n"
end

def completion(shell)
  case shell
  when "bash"
    "_tex-fmt() {\n    COMPREPLY=()\n}\ncomplete -F _tex-fmt tex-fmt\n"
  else
    ""
  end
end

opts, files, wants_args = parse_args(ARGV)
if wants_args
  print_args(opts, files)
  exit 0
end

formatter = TexFmt.new(opts)

if opts[:stdin]
  print formatter.format($stdin.read, "<stdin>")
  exit 0
end

files = recursive_files(files) if opts[:recursive]
if files.empty?
  log("error", opts, "", "No files specified. Provide filenames, or pass --recursive or --stdin.")
  exit 1
end

status = 0
files.each do |file|
  next unless TexFmt::EXTENSIONS.include?(File.extname(file))
  begin
    input = File.read(file)
  rescue StandardError
    log("error", opts, file, "Could not open file.")
    status = 1
    next
  end
  log("info", opts, file, "Formatting started.")
  output = formatter.format(input, file)
  changed = output != input
  if opts[:print]
    print output
  elsif opts[:check]
    if changed
      log("error", opts, file, "Incorrect formatting.")
      status = 1
    end
  else
    File.write(file, output) if changed
    status = 1 if changed && opts[:fail_on_change]
  end
  log("info", opts, file, "Formatting complete.")
end

exit status
