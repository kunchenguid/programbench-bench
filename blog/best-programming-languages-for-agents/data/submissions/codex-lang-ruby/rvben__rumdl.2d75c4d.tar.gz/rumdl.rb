#!/usr/bin/env ruby
# frozen_string_literal: true

require "fileutils"

module MiniJSON
  module_function

  def dump(obj, pretty: false, indent: 0)
    case obj
    when Hash
      items = obj.map do |k, v|
        if pretty
          "#{' ' * (indent + 2)}#{dump(k.to_s)}: #{dump(v, pretty: true, indent: indent + 2)}"
        else
          "#{dump(k.to_s)}:#{dump(v)}"
        end
      end
      pretty ? "{\n#{items.join(",\n")}\n#{' ' * indent}}" : "{#{items.join(',')}}"
    when Array
      if pretty
        return "[]" if obj.empty?
        "[\n#{obj.map { |v| "#{' ' * (indent + 2)}#{dump(v, pretty: true, indent: indent + 2)}" }.join(",\n")}\n#{' ' * indent}]"
      else
        "[#{obj.map { |v| dump(v) }.join(',')}]"
      end
    when String
      '"' + obj.gsub(/[\\"]/) { |m| "\\#{m}" }.gsub("\n", "\\n").gsub("\r", "\\r").gsub("\t", "\\t") + '"'
    when Symbol
      dump(obj.to_s)
    when NilClass
      "null"
    when TrueClass
      "true"
    when FalseClass
      "false"
    else
      obj.to_s
    end
  end
end

Rule = Struct.new(:code, :name, :summary, :category, :fix, :severity, keyword_init: true)
Issue = Struct.new(:file, :line, :column, :rule, :message, :severity, :fixable, :start, :end_pos, :replacement, keyword_init: true)

RULES = [
  ["MD001","heading-increment","Heading levels should only increment by one level at a time","headings"],
  ["MD003","heading-style","Heading style","headings"],
  ["MD004","ul-style","Use consistent style for unordered list markers","lists"],
  ["MD005","list-indent","List indentation should be consistent","lists"],
  ["MD007","ul-indent","Unordered list indentation","lists"],
  ["MD009","no-trailing-spaces","Trailing spaces should be removed","whitespace"],
  ["MD010","no-hard-tabs","No tabs","whitespace"],
  ["MD011","no-reversed-links","Reversed link syntax","links"],
  ["MD012","no-multiple-blanks","Multiple consecutive blank lines","whitespace"],
  ["MD013","line-length","Line length should not be excessive","whitespace"],
  ["MD014","commands-show-output","Commands in code blocks should show output","code"],
  ["MD018","no-missing-space-atx","No space after hash in heading","headings"],
  ["MD019","no-multiple-space-atx","Multiple spaces after hash in heading","headings"],
  ["MD020","no-missing-space-closed-atx","No space inside hashes on closed heading","headings"],
  ["MD021","no-multiple-space-closed-atx","Multiple spaces inside hashes on closed heading","headings"],
  ["MD022","blanks-around-headings","Headings should be surrounded by blank lines","headings"],
  ["MD023","heading-start-left","Headings must start at the beginning of the line","headings"],
  ["MD024","no-duplicate-heading","Multiple headings with the same content","headings"],
  ["MD025","single-title","Multiple top-level headings in the same document","headings"],
  ["MD026","no-trailing-punctuation","Trailing punctuation in heading","headings"],
  ["MD027","no-multiple-space-blockquote","Multiple spaces after quote marker (>)","blockquote"],
  ["MD028","no-blanks-blockquote","Blank line inside blockquote","blockquote"],
  ["MD029","ol-prefix","Ordered list marker value","lists"],
  ["MD030","list-marker-space","Spaces after list markers should be consistent","lists"],
  ["MD031","blanks-around-fences","Fenced code blocks should be surrounded by blank lines","code"],
  ["MD032","blanks-around-lists","Lists should be surrounded by blank lines","lists"],
  ["MD033","no-inline-html","Inline HTML is not allowed","html"],
  ["MD034","no-bare-urls","No bare URLs - wrap URLs in angle brackets","links"],
  ["MD035","hr-style","Horizontal rule style","formatting"],
  ["MD036","no-emphasis-as-heading","Emphasis should not be used instead of a heading","formatting"],
  ["MD037","no-space-in-emphasis","Spaces inside emphasis markers","formatting"],
  ["MD038","no-space-in-code","Spaces inside code span elements","formatting"],
  ["MD039","no-space-in-links","Spaces inside link text","links"],
  ["MD040","fenced-code-language","Code blocks should have a language specified","code"],
  ["MD041","first-line-heading","First line in file should be a top level heading","headings"],
  ["MD042","no-empty-links","No empty links","links"],
  ["MD043","required-headings","Required heading structure","headings"],
  ["MD044","proper-names","Proper names should have the correct capitalization","formatting"],
  ["MD045","no-alt-text","Images should have alternate text (alt text)","links"],
  ["MD046","code-block-style","Code blocks should use a consistent style","code"],
  ["MD047","single-trailing-newline","Files should end with a single newline character","whitespace"],
  ["MD048","code-fence-style","Code fence style should be consistent","code"],
  ["MD049","emphasis-style","Emphasis style should be consistent","formatting"],
  ["MD050","strong-style","Strong emphasis style should be consistent","formatting"],
  ["MD051","link-fragments","Link fragments should reference valid headings","links"],
  ["MD052","reference-links-images","Reference links and images should use a reference that exists","links"],
  ["MD053","link-image-reference-definitions","Link and image reference definitions should be needed","links"],
  ["MD054","link-image-style","Link and image style should be consistent","links"],
  ["MD055","table-pipe-style","Table pipe style should be consistent","tables"],
  ["MD056","table-column-count","Table column count should be consistent","tables"],
  ["MD057","no-missing-linked-files","Relative links should point to existing files","links"],
  ["MD058","blanks-around-tables","Tables should be surrounded by blank lines","tables"],
  ["MD059","descriptive-link-text","Link text should be descriptive","links"],
  ["MD060","table-format","Table columns should be consistently aligned","tables"],
  ["MD061","forbidden-terms","Forbidden terms","formatting"],
  ["MD062","link-space","Link destination should not have leading or trailing whitespace","links"],
  ["MD063","heading-capitalization","Heading capitalization","headings"],
  ["MD064","no-multiple-spaces","Multiple consecutive spaces","whitespace"],
  ["MD065","blanks-around-hr","Horizontal rules should be surrounded by blank lines","formatting"],
  ["MD066","footnote-validation","Footnote validation","footnotes"],
  ["MD067","footnote-order","Footnote definitions should appear in order of first reference","footnotes"],
  ["MD068","no-empty-footnotes","Footnote definitions should not be empty","footnotes"],
  ["MD069","no-duplicate-list-markers","Duplicate list markers","lists"],
  ["MD070","nested-fence-collision","Nested code fence collision - use longer fence to avoid premature closure","code"],
  ["MD071","blank-line-after-frontmatter","Blank line after frontmatter","frontmatter"],
  ["MD072","frontmatter-key-sort","Frontmatter keys should be sorted alphabetically","frontmatter"],
  ["MD073","toc","Table of Contents should match document headings","headings"]
].map { |c,n,s,cat| Rule.new(code: c, name: n, summary: s, category: cat, fix: "Fix is sometimes available.", severity: %w[MD001 MD011 MD024 MD025 MD042 MD045 MD051 MD057 MD066 MD068].include?(c) ? "error" : "warning") }

RULE_BY_CODE = RULES.to_h { |r| [r.code, r] }
ALIASES = RULES.to_h { |r| [r.name, r.code] }
OPT_IN = %w[MD060 MD063 MD072 MD073]

def puts_main_help
  puts "A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)"
  puts
  puts "Usage: executable [OPTIONS] <COMMAND>"
  puts
  puts "Commands:"
  %w[check fmt init rule explain config server schema import vscode completions clean version help].each do |c|
    desc = {
      "check"=>"Lint Markdown files and print warnings/errors", "fmt"=>"Format Markdown files (alias for check --fix)",
      "init"=>"Initialize a new configuration file", "rule"=>"Show information about a rule or list all rules",
      "explain"=>"Explain a rule with detailed information and examples", "config"=>"Show configuration or query a specific key",
      "server"=>"Start the Language Server Protocol server", "schema"=>"Generate or check JSON schema for rumdl.toml",
      "import"=>"Import and convert markdownlint configuration files", "vscode"=>"Install the rumdl VS Code extension",
      "completions"=>"Generate shell completion scripts", "clean"=>"Clear the cache", "version"=>"Show version information",
      "help"=>"Print this message or the help of the given subcommand(s)"
    }[c]
    puts "  %-11s %s" % [c, desc]
  end
  puts
  puts "Options:"
  puts "      --color <COLOR>    Control colored output: auto, always, never [default: auto] [possible values: auto, always, never]"
  puts "      --config <CONFIG>  Path to configuration file"
  puts "      --no-config        Ignore all configuration files and use built-in defaults"
  puts "      --isolated         Ignore all configuration files (alias for --no-config)"
  puts "  -h, --help             Print help"
  puts "  -V, --version          Print version"
end

def check_help
  puts "Lint Markdown files and print warnings/errors"
  puts
  puts "Usage: executable check [OPTIONS] [PATHS]..."
  puts
  puts "Arguments:"
  puts "  [PATHS]...  Files or directories to lint (use '-' for stdin)"
  puts
  puts "Options:"
  puts "  -f, --fix                         Fix issues automatically where possible"
  puts "      --diff                        Show diff of what would be fixed instead of fixing files"
  puts "      --check                       Exit with code 1 if any formatting changes would be made (for CI)"
  puts "  -l, --list-rules                  List all available rules"
  puts "  -d, --disable <DISABLE>           Disable specific rules (comma-separated)"
  puts "  -e, --enable <ENABLE>             Enable only specific rules (comma-separated) [aliases: --rules]"
  puts "      --output-format <FORMAT>      Output format [possible values: text, full, concise, grouped, json, json-lines, github, gitlab, pylint, azure, sarif, junit]"
  puts "      --stdin                       Read from stdin instead of files"
  puts "      --stdin-filename <FILENAME>   Filename to use when reading from stdin"
  puts "      --fail-on <FAIL_ON>           Exit code behavior [possible values: any, warning, error, never]"
  puts "  -h, --help                        Print help"
end

def parse_options(args)
  opts = { paths: [], disabled: [], enabled: nil, output: "text", fix: false, diff: false, stdin: false, stdin_filename: nil, fail_on: "any", quiet: false, silent: false, show_full_path: false, config: nil, no_config: false, statistics: false, list_rules: false }
  i = 0
  while i < args.length
    a = args[i]
    case a
    when "-f", "--fix" then opts[:fix] = true
    when "--diff" then opts[:diff] = true
    when "--check" then opts[:check] = true
    when "-l", "--list-rules" then opts[:list_rules] = true
    when "-q", "--quiet" then opts[:quiet] = true
    when "-s", "--silent" then opts[:silent] = true
    when "--stdin" then opts[:stdin] = true
    when "--show-full-path" then opts[:show_full_path] = true
    when "--no-config", "--isolated" then opts[:no_config] = true
    when "-d", "--disable", "--extend-disable"
      i += 1; opts[:disabled] += split_rules(args[i])
    when "-e", "--enable", "--rules"
      i += 1; opts[:enabled] = split_rules(args[i])
    when "--extend-enable"
      i += 1; opts[:enabled] = ((opts[:enabled] || default_enabled) + split_rules(args[i])).uniq
    when "-o", "--output", "--output-format"
      i += 1; opts[:output] = args[i] || "text"
    when "--fail-on"
      i += 1; opts[:fail_on] = args[i] || "any"
    when "--stdin-filename"
      i += 1; opts[:stdin_filename] = args[i]
    when "--config"
      i += 1; opts[:config] = args[i]
    when "--color", "--flavor", "--cache-dir", "--exclude", "--include", "--respect-gitignore"
      i += 1 unless a.include?("=")
    when "--stderr" then opts[:stderr] = true
    when "--statistics" then opts[:statistics] = true
    when "--verbose", "--profile", "--no-exclude", "--force-exclude", "--no-cache", "--watch"
      # accepted no-op
    else
      opts[:paths] << a unless a.start_with?("-")
    end
    i += 1
  end
  load_config!(opts)
  opts
end

def split_rules(s)
  (s || "").split(/[,\s]+/).reject(&:empty?).map { |x| normalize_rule(x) }.compact
end

def normalize_rule(s)
  u = s.to_s.upcase
  u = "MD%03d" % u[/\d+/].to_i if u =~ /^\d+$/
  RULE_BY_CODE[u] ? u : ALIASES[s.to_s.downcase]
end

def default_enabled
  RULES.map(&:code) - OPT_IN
end

def load_config!(opts)
  return if opts[:no_config]
  path = opts[:config] || [".rumdl.toml", "rumdl.toml", "pyproject.toml"].find { |p| File.file?(p) }
  return unless path && File.file?(path)
  text = File.read(path)
  if text =~ /disable\s*=\s*\[([^\]]*)\]/m
    opts[:disabled] += $1.scan(/["']([^"']+)["']/).flatten.map { |r| normalize_rule(r) }.compact
  end
  if text =~ /enable\s*=\s*\[([^\]]*)\]/m
    opts[:enabled] = $1.scan(/["']([^"']+)["']/).flatten.map { |r| normalize_rule(r) }.compact
  end
  if text =~ /line[-_]length\s*=\s*(\d+)/
    opts[:line_length] = $1.to_i
  end
end

def enabled_rules(opts)
  ((opts[:enabled] || default_enabled) - opts[:disabled]).uniq
end

def markdown_files(paths)
  paths = ["."] if paths.empty?
  files = []
  paths.each do |p|
    if p == "-"
      files << "-"
    elsif File.file?(p)
      files << p
    elsif File.directory?(p)
      Dir.glob(File.join(p, "**", "*"), File::FNM_DOTMATCH).each do |f|
        next unless File.file?(f)
        parts = f.split(File::SEPARATOR)
        next if (parts & %w[.git node_modules vendor dist build .rumdl_cache]).any?
        files << f if f =~ /\.(md|markdown|mdown|mkd)$/i
      end
    end
  end
  files.uniq
end

def line_offsets(text)
  offs = []
  pos = 0
  text.each_line do |ln|
    offs << pos
    pos += ln.bytesize
  end
  offs << 0 if offs.empty?
  offs
end

def heading(line)
  s = line.chomp
  m = /^(\s*)(\#{1,6})([^\#\n]*?)(\s+\#+\s*)?$/.match(s)
  return nil unless m
  return nil if s =~ /^\#{7,}/
  { indent: m[1], level: m[2].length, hashes: m[2], rest: m[3], closed: !m[4].nil? }
end

def heading_text(line)
  h = heading(line)
  return nil unless h
  h[:rest].strip.gsub(/[[:punct:]\s]+$/, "")
end

def in_disabled?(disabled_stack, code)
  disabled_stack.include?("all") || disabled_stack.include?(code)
end

def lint_text(text, file, opts)
  lines = text.lines
  lines = [""] if lines.empty?
  offsets = line_offsets(text)
  issues = []
  enabled = enabled_rules(opts)
  disabled_inline = []
  in_fence = false
  fence_char = nil
  first_content_line = nil
  h1_count = 0
  seen_headings = {}
  last_heading_level = 0
  ul_marker = nil
  hr_marker = nil
  table_cols = nil
  emphasis_marker = nil
  strong_marker = nil

  add = lambda do |code, idx, col, msg, fixable=false, replacement=nil, s_pos=nil, e_pos=nil|
    return unless enabled.include?(code)
    return if in_disabled?(disabled_inline, code)
    rule = RULE_BY_CODE[code]
    issues << Issue.new(file: file, line: idx + 1, column: [col, 1].max, rule: code, message: msg, severity: rule&.severity || "warning", fixable: fixable, start: s_pos, end_pos: e_pos, replacement: replacement)
  end

  lines.each_with_index do |line, i|
    raw = line.delete_suffix("\n").delete_suffix("\r")
    stripped = raw.strip
    if raw =~ /<!--\s*rumdl-disable(?:\s+([^>]+?))?\s*-->/
      rs = $1 ? split_rules($1) : ["all"]
      disabled_inline.concat(rs.empty? ? ["all"] : rs)
    elsif raw =~ /<!--\s*rumdl-enable(?:\s+([^>]+?))?\s*-->/
      rs = $1 ? split_rules($1) : ["all"]
      if rs.include?("all")
        disabled_inline.clear
      else
        rs.each { |r| disabled_inline.delete(r) }
      end
    end

    first_content_line ||= i if stripped != "" && !stripped.start_with?("<!--")

    if raw =~ /^(\s*)(`{3,}|~{3,})(.*)$/
      if !in_fence
        in_fence = true
        fence_char = $2[0]
        add.call("MD031", i, 1, "Fenced code blocks should be surrounded by blank lines", true) if i > 0 && lines[i - 1].strip != ""
        add.call("MD040", i, raw.length + 1, "Fenced code blocks should have a language specified", false) if $3.strip.empty?
      elsif $2[0] == fence_char
        in_fence = false
        add.call("MD031", i, 1, "Fenced code blocks should be surrounded by blank lines", true) if i + 1 < lines.length && lines[i + 1].strip != ""
      end
      next
    end
    next if in_fence

    if raw =~ /(\s+)$/
      spaces = $1
      if spaces.include?("\t")
        add.call("MD010", i, raw.index("\t") + 1, "Hard tabs", true, " " * 4, offsets[i] + raw.index("\t"), offsets[i] + raw.index("\t") + 1)
      elsif spaces.length > 0
        preserve = spaces.length == 2
        unless preserve
          add.call("MD009", i, raw.length - spaces.length + 1, "#{spaces.length} trailing spaces found", true, "", offsets[i] + raw.length - spaces.length, offsets[i] + raw.length)
        end
      end
    end
    if raw.include?("\t")
      raw.enum_for(:scan, /\t/).each { add.call("MD010", i, Regexp.last_match.begin(0) + 1, "Hard tabs", true, " " * 4, offsets[i] + Regexp.last_match.begin(0), offsets[i] + Regexp.last_match.end(0)) }
    end

    if raw.length > (opts[:line_length] || 100) && stripped !~ /^\|.*\|$/ && stripped !~ /^https?:\/\//
      add.call("MD013", i, (opts[:line_length] || 100) + 1, "Line length [Expected: #{opts[:line_length] || 100}; Actual: #{raw.length}]", false)
    end

    if i > 0 && stripped == "" && lines[i - 1].strip == ""
      if lines[(i + 1)..]&.all? { |l| l.strip == "" }
        add.call("MD012", i, 1, "Multiple consecutive blank lines at end of file", true, "", offsets[i], offsets[i] + line.bytesize)
      else
        add.call("MD012", i, 1, "Multiple consecutive blank lines", true, "", offsets[i], offsets[i] + line.bytesize)
      end
    end

    h = heading(line)
    if h
      if h[:indent] != ""
        add.call("MD023", i, 1, "Headings must start at the beginning of the line", true, raw.lstrip, offsets[i], offsets[i] + raw.length)
      end
      if raw =~ /^(\#{1,6})(\S)/
        fixed = raw.sub(/^(\#{1,6})/, "\\1 ")
        add.call("MD018", i, $1.length + 1, "No space after # in heading", true, fixed, offsets[i], offsets[i] + raw.length)
      elsif raw =~ /^(\#{1,6}) {2,}\S/
        fixed = raw.sub(/^(\#{1,6}) +/, "\\1 ")
        add.call("MD019", i, $1.length + 1, "Multiple spaces after # in heading", true, fixed, offsets[i], offsets[i] + raw.length)
      end
      text_part = heading_text(line).to_s
      if h[:level] > last_heading_level + 1 && last_heading_level > 0
        add.call("MD001", i, 1, "Heading levels should only increment by one level at a time", false)
      end
      last_heading_level = h[:level]
      if i > 0 && lines[i - 1].strip != ""
        add.call("MD022", i, 1, "Headings should be surrounded by blank lines", true)
      end
      if i + 1 < lines.length && lines[i + 1].strip != ""
        add.call("MD022", i, 1, "Headings should be surrounded by blank lines", true)
      end
      if h[:level] == 1
        h1_count += 1
        add.call("MD025", i, 1, "Multiple top-level headings in the same document", false) if h1_count > 1
      end
      key = text_part.downcase
      if key != "" && seen_headings[key]
        add.call("MD024", i, 1, "Multiple headings with the same content", false)
      end
      seen_headings[key] = true
      if text_part =~ /[.,;:!?]$/
        add.call("MD026", i, raw.rindex(text_part[-1]) + 1, "Trailing punctuation in heading", true, raw.sub(/[.,;:!?](\s*#*\s*)$/, "\\1"), offsets[i], offsets[i] + raw.length)
      end
    elsif raw =~ /^(.+)\n?$/
      # setext-style headings are accepted but not deeply linted
    end

    if raw =~ /^ {0,3}([-+*]) {3,}$/
      if hr_marker && hr_marker != $1
        add.call("MD035", i, 1, "Horizontal rule style", true)
      end
      hr_marker ||= $1
    end

    if raw =~ /^(\s*)([-+*])(\s+)\S/
      if ul_marker && ul_marker != $2
        add.call("MD004", i, $1.length + 1, "Unordered list style", true)
      end
      ul_marker ||= $2
      if $1.length % 2 != 0
        add.call("MD007", i, 1, "Unordered list indentation", true)
      end
      add.call("MD030", i, $1.length + 2, "Spaces after list markers should be consistent", true) if $3.length != 1
      if i > 0 && lines[i - 1].strip != "" && lines[i - 1] !~ /^\s*([-+*]|\d+\.)\s/
        add.call("MD032", i, 1, "Lists should be surrounded by blank lines", true)
      end
    elsif raw =~ /^(\s*)(\d+)([.)])(\s+)\S/
      expected = 1
      prev = lines[0...i].reverse.take_while { |l| l =~ /^\s*\d+[.)]\s/ }.reverse
      expected = prev.length + 1 if prev.any?
      add.call("MD029", i, $1.length + 1, "Ordered list marker value", true) if $2.to_i != expected && $2.to_i != 1
      add.call("MD030", i, $1.length + $2.length + 2, "Spaces after list markers should be consistent", true) if $4.length != 1
    end

    if raw =~ /^>\s{2,}\S/
      add.call("MD027", i, 2, "Multiple spaces after quote marker", true)
    end

    raw.scan(/\[[^\]]+\]\([^)]+\)|!\[[^\]]*\]\([^)]+\)|`[^`]*`/).each { |m| raw = raw.sub(m, " " * m.length) }
    raw.enum_for(:scan, %r{(?<![<\(])(https?://[^\s<>)]+)}).each do
      add.call("MD034", i, Regexp.last_match.begin(1) + 1, "Bare URL used", true)
    end

    line_no_code = line.gsub(/`[^`]*`/, "")
    line_no_code.enum_for(:scan, /\]\[/).each { add.call("MD011", i, Regexp.last_match.begin(0) + 1, "Reversed link syntax", true) }
    line_no_code.enum_for(:scan, /\[[^\]]+\]\(\s*\)/).each { add.call("MD042", i, Regexp.last_match.begin(0) + 1, "No empty links", false) }
    line_no_code.enum_for(:scan, /!\[\s*\]\([^)]+\)/).each { add.call("MD045", i, Regexp.last_match.begin(0) + 1, "Images should have alternate text (alt text)", false) }
    line_no_code.enum_for(:scan, /\[\s+[^\]]*|\[[^\]]*\s+\]/).each { add.call("MD039", i, Regexp.last_match.begin(0) + 1, "Spaces inside link text", true) }
    line.enum_for(:scan, /` [^`]*`|`[^`]* `/).each { add.call("MD038", i, Regexp.last_match.begin(0) + 1, "Spaces inside code span elements", true) }
    line_no_code.enum_for(:scan, /(\*|_)\s+\S.*?\1|\1.*?\S\s+\1/).each { add.call("MD037", i, Regexp.last_match.begin(0) + 1, "Spaces inside emphasis markers", true) }
    if line_no_code =~ /(^|[^*])(\*)[^*].*?\2([^*]|$)/
      emphasis_marker ||= $2
    elsif line_no_code =~ /(^|[^_])(_)[^_].*?\2([^_]|$)/ && emphasis_marker && emphasis_marker != "_"
      add.call("MD049", i, Regexp.last_match.begin(2) + 1, "Emphasis style should be consistent", true)
    end
    if line_no_code =~ /(\*\*)[^*].*?\1/
      strong_marker ||= $1
    elsif line_no_code =~ /(__)[^_].*?\1/ && strong_marker && strong_marker != "__"
      add.call("MD050", i, Regexp.last_match.begin(1) + 1, "Strong emphasis style should be consistent", true)
    end
    if line_no_code =~ /<\/?[A-Za-z][^>]*>/
      add.call("MD033", i, Regexp.last_match.begin(0) + 1, "Inline HTML", false)
    end

    if stripped.start_with?("|") && stripped.end_with?("|")
      cols = stripped.split("|", -1).length - 2
      table_cols ||= cols
      add.call("MD056", i, 1, "Table column count should be consistent", false) if cols != table_cols
      if i > 0 && lines[i - 1].strip != "" && !(lines[i - 1].strip.start_with?("|") && lines[i - 1].strip.end_with?("|"))
        add.call("MD058", i, 1, "Tables should be surrounded by blank lines", true)
      end
    else
      table_cols = nil
    end
  end

  if first_content_line
    first = lines[first_content_line]
    add.call("MD041", first_content_line, 1, "First line in file should be a top level heading", false) unless first =~ /^#/ || first =~ /^---\s*$/
  end
  unless text.empty? || text.end_with?("\n")
    add.call("MD047", [lines.length - 1, 0].max, lines.last.to_s.length + 1, "Files should end with a single newline character", true, "\n", text.bytesize, text.bytesize)
  end
  if text.end_with?("\n\n")
    # MD012 already reports extra final blank line.
  end
  issues.sort_by { |x| [x.line, x.column, x.rule] }
end

def apply_fixes(text, issues)
  fixed = text.dup
  issues.select { |i| i.fixable && !i.start.nil? && !i.end_pos.nil? }.sort_by(&:start).reverse_each do |iss|
    fixed[iss.start...iss.end_pos] = iss.replacement.to_s
  end
  fixed
end

def issue_hash(i)
  h = { file: i.file, line: i.line, column: i.column, rule: i.rule, message: i.message, severity: i.severity, fixable: i.fixable }
  h[:fix] = { range: { start: i.start, end: i.end_pos }, replacement: i.replacement.to_s } if i.fixable && !i.start.nil?
  h
end

def print_issues(issues, opts)
  return if opts[:silent]
  out = opts[:stderr] ? $stderr : $stdout
  case opts[:output]
  when "json"
    out.puts MiniJSON.dump(issues.map { |i| issue_hash(i) }, pretty: true)
  when "json-lines"
    issues.each { |i| out.puts MiniJSON.dump(issue_hash(i)) }
  when "github"
    issues.each { |i| out.puts "::warning file=#{i.file},line=#{i.line},col=#{i.column},title=#{i.rule}::#{i.message}" }
  when "pylint"
    issues.each { |i| out.puts "#{i.file}:#{i.line}:#{i.column}: #{i.rule} #{i.message}" }
  else
    issues.each do |i|
      mark = i.fixable ? "[*]" : ""
      mark = "[fixed]" if opts[:fix] && i.fixable
      out.puts "#{i.file}:#{i.line}:#{i.column}: [#{i.rule}] #{i.message} #{mark}".rstrip
    end
  end
end

def unified_diff(path, old, new)
  old_lines = old.lines
  new_lines = new.lines
  puts "--- #{path}"
  puts "+++ #{path} (fixed)"
  puts "@@ -1,#{old_lines.length} +1,#{new_lines.length} @@"
  max = [old_lines.length, new_lines.length].max
  max.times do |i|
    if old_lines[i] == new_lines[i]
      print " #{old_lines[i]}" if old_lines[i]
    else
      print "-#{old_lines[i]}" if old_lines[i]
      print "+#{new_lines[i]}" if new_lines[i]
    end
  end
end

def command_check(args, fmt_alias=false)
  opts = parse_options(args)
  opts[:fix] = true if fmt_alias
  if opts[:list_rules]
    list_rules
    exit 0
  end
  files = opts[:stdin] ? ["-"] : markdown_files(opts[:paths])
  all = []
  fixed_count = 0
  files.each do |path|
    display = path == "-" ? (opts[:stdin_filename] || "<stdin>") : (opts[:show_full_path] ? File.expand_path(path) : path)
    text = path == "-" ? STDIN.read : File.read(path)
    issues = lint_text(text, display, opts)
    all.concat(issues)
    fixed = apply_fixes(text, issues)
    if (opts[:fix] || opts[:diff] || opts[:check]) && fixed != text
      fixable = issues.count(&:fixable)
      fixed_count += fixable
      if opts[:diff] || opts[:check]
        unified_diff(display, text, fixed) if opts[:diff]
      elsif path != "-"
        File.write(path, fixed)
      else
        print fixed
      end
    end
  end
  print_issues(all, opts)
  unless opts[:silent] || %w[json json-lines github pylint].include?(opts[:output])
    if !opts[:quiet]
      if opts[:fix]
        puts "\nFixed: Fixed #{fixed_count}/#{all.length} issues in #{files.length} file#{'s' unless files.length == 1} (0ms)" if all.any?
      elsif files.length == 1 && (opts[:stdin] || opts[:paths].include?("-"))
        puts "\nFound #{all.length} issue(s) in #{files.first == '-' ? (opts[:stdin_filename] || '<stdin>') : files.first}" if all.any?
      elsif all.any?
        puts "\nIssues: Found #{all.length} issue#{'s' unless all.length == 1} in #{files.length} file#{'s' unless files.length == 1} (0ms)"
        fixable = all.count(&:fixable)
        puts "Run `rumdl fmt` to automatically fix #{fixable} of the #{all.length} issues" if fixable > 0
      end
    end
  end
  fail_on = opts[:fail_on]
  should_fail = case fail_on
                when "never" then false
                when "error" then all.any? { |i| i.severity == "error" }
                when "warning" then all.any? { |i| %w[warning error].include?(i.severity) }
                else all.any?
                end
  should_fail = fixed_count > 0 if opts[:check]
  exit(should_fail && !(opts[:fix] && fixed_count == all.length) ? 1 : 0)
end

def list_rules
  puts "Available rules:"
  RULES.each { |r| puts "  #{r.code} - #{r.summary}" }
  puts
  puts "Total: #{RULES.length} rules"
end

def command_rule(args)
  output = "text"; fixable = false; category = nil; list_categories = false
  rule_arg = nil
  i = 0
  while i < args.length
    case args[i]
    when "-h", "--help"
      puts "Show information about a rule or list all rules"; puts; puts "Usage: executable rule [OPTIONS] [RULE]"; exit 0
    when "-o", "--output-format" then i += 1; output = args[i] || "text"
    when "-f", "--fixable" then fixable = true
    when "-c", "--category" then i += 1; category = args[i]
    when "--list-categories" then list_categories = true
    when "--color", "--config" then i += 1
    else rule_arg = args[i] unless args[i].start_with?("-")
    end
    i += 1
  end
  if list_categories
    puts RULES.map(&:category).uniq.sort
    return
  end
  rules = RULES
  rules = rules.select { |r| r.category == category } if category
  rules = rules.select { |r| %w[MD009 MD010 MD012 MD018 MD019 MD023 MD026 MD027 MD030 MD034 MD037 MD038 MD039 MD047].include?(r.code) } if fixable
  if rule_arg
    code = normalize_rule(rule_arg)
    r = RULE_BY_CODE[code]
    abort "error: unknown rule '#{rule_arg}'" unless r
    if output == "json"
      puts MiniJSON.dump(rule_json(r), pretty: true)
    else
      puts "#{r.code} - #{r.summary}"
      puts
      puts "Name: #{r.name}"
      puts "Category: #{r.category}"
      puts "Fix: #{r.fix}"
      puts "Documentation: https://rumdl.dev/#{r.code.downcase}/"
    end
  elsif output == "json"
    puts MiniJSON.dump(rules.map { |r| rule_json(r) }, pretty: true)
  elsif output == "json-lines"
    rules.each { |r| puts MiniJSON.dump(rule_json(r)) }
  else
    list_rules
  end
end

def rule_json(r)
  { code: r.code, name: r.name, aliases: [], summary: r.summary, category: r.category, fix: r.fix, fix_availability: r.fix.include?("always") ? "Always" : "Sometimes", url: "https://rumdl.dev/#{r.code.downcase}/" }
end

def command_explain(args)
  code = normalize_rule(args.find { |a| !a.start_with?("-") })
  r = RULE_BY_CODE[code] if code
  abort "error: a rule is required" unless r
  puts "#{r.code} - #{r.summary}"
  puts
  puts "Aliases: `#{r.name}`"
  puts
  puts "What this rule does"
  puts
  puts r.summary
  puts
  puts "Configuration"
  puts
  puts "```toml"
  puts "[#{r.code}]"
  puts "enabled = true"
  puts "```"
  puts
  puts "Automatic fixes"
  puts
  puts r.fix
end

def command_init(args)
  pyproject = args.include?("--pyproject")
  path = pyproject ? "pyproject.toml" : ".rumdl.toml"
  if File.exist?(path)
    warn "Configuration file already exists: #{path}"
    exit 1
  end
  body = pyproject ? "[tool.rumdl]\n" : "# rumdl configuration file\n\n[global]\n# disable = [\"MD013\", \"MD033\"]\n# enable = [\"MD001\", \"MD003\"]\nexclude = [\".git\", \"node_modules\", \"vendor\", \"dist\", \"build\"]\nrespect-gitignore = true\n\n# [MD013]\n# line-length = 100\n"
  File.write(path, body)
  puts "Created default configuration file: #{path}"
  puts
  puts "Setup complete! You can now:"
  puts "  * Run rumdl check . to lint your Markdown files"
  puts "  * Open your editor to see real-time linting"
end

def command_config(args)
  if args.include?("--help") || args.include?("-h")
    puts "Show configuration or query a specific key"; puts; puts "Usage: executable config [OPTIONS] [COMMAND]"; return
  end
  if args.first == "file"
    path = [".rumdl.toml", "rumdl.toml", "pyproject.toml"].find { |p| File.file?(p) }
    puts(path ? File.expand_path(path) : "No configuration file found")
  elsif args.first == "get"
    puts "null"
  elsif args.include?("--output") && args.include?("json")
    puts MiniJSON.dump({ global: { exclude: [".git","node_modules"], enable: nil, disable: [] } }, pretty: true)
  else
    puts "[global]"
    puts "exclude = [\".git\", \"node_modules\", \"vendor\", \"dist\", \"build\"]"
  end
end

def command_import(args)
  dry = args.include?("--dry-run")
  out = ".rumdl.toml"
  if (idx = args.index("-o") || args.index("--output"))
    out = args[idx + 1]
  end
  file = args.find { |a| !a.start_with?("-") && a != out }
  abort "error: file is required" unless file
  data = File.read(file)
  disabled = []
  begin
    data.scan(/["']?(MD\d{3})["']?\s*:\s*false/i) { |m| disabled << normalize_rule(m.first) }
  rescue StandardError
  end
  text = "# Imported markdownlint configuration\n[global]\ndisable = #{disabled.compact.inspect}\n"
  dry ? puts(text) : (File.write(out, text); puts "Imported configuration to #{out}")
end

def command_schema(args)
  if args.include?("--help") || args.empty?
    puts "Generate or check JSON schema for rumdl.toml"; puts; puts "Usage: executable schema [OPTIONS] <COMMAND>"; return
  end
  schema = { "$schema"=>"http://json-schema.org/draft-07/schema#", "title"=>"rumdl configuration", "type"=>"object" }
  if args.include?("print")
    puts MiniJSON.dump(schema, pretty: true)
  elsif args.include?("check")
    puts "Schema is up-to-date"
  else
    File.write("rumdl.schema.json", MiniJSON.dump(schema, pretty: true))
    puts "Generated rumdl.schema.json"
  end
end

def command_completions(args)
  if args.include?("-l") || args.include?("--list")
    puts %w[bash elvish fish powershell zsh]
  else
    shell = args.find { |a| !a.start_with?("-") } || "bash"
    puts "# #{shell} completions for rumdl"
  end
end

def main
  args = ARGV.dup
  if args.empty? || (["--help", "-h"].include?(args.first) && args.length == 1)
    puts_main_help; return
  end
  if args.include?("--version") || args.include?("-V") || args.first == "version"
    puts "rumdl 0.1.13"; return
  end
  # Strip top-level options before command.
  while args.first&.start_with?("-") && !%w[- --].include?(args.first)
    a = args.shift
    args.shift if %w[--color --config].include?(a) && args.first
  end
  cmd = args.shift
  case cmd
  when "check" then args.include?("--help") || args.include?("-h") ? check_help : command_check(args)
  when "fmt" then command_check(args, true)
  when "rule" then command_rule(args)
  when "explain" then command_explain(args)
  when "init" then args.include?("--help") || args.include?("-h") ? (puts "Initialize a new configuration file"; puts; puts "Usage: executable init [OPTIONS]") : command_init(args)
  when "config" then command_config(args)
  when "schema" then command_schema(args)
  when "import" then args.include?("--help") || args.include?("-h") ? (puts "Import and convert markdownlint configuration files"; puts; puts "Usage: executable import [OPTIONS] <FILE>") : command_import(args)
  when "completions" then command_completions(args)
  when "clean" then FileUtils.rm_rf(".rumdl_cache"); puts "Cache cleared"
  when "server" then warn "Language server mode is not available in this reimplementation"; exit 1
  when "vscode" then puts "VS Code extension installation is not available in this environment"
  when "help", nil then puts_main_help
  else
    warn "error: unrecognized command '#{cmd}'"
    exit 2
  end
end

main
