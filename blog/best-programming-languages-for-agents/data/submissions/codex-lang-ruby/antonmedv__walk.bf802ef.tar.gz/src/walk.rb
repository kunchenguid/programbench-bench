#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = "v1.13.0"
HELP = <<'HELP'

  walk v1.13.0

  Usage: walk [path]

    arrows, hjkl  Move cursor
    enter         Enter directory
    backspace     Exit directory
    space         Toggle preview
    esc, q        Exit with cd
    ctrl+c        Exit without cd
    /             Fuzzy search
    d, delete     Delete file or dir
    y             Copy to clipboard
    .             Hide hidden files
    ?             Show help

  Flags:

    --icons        display icons
    --dir-only     show dirs only
    --hide-hidden  hide hidden files
    --preview      display preview
    --with-border  preview with border
    --fuzzy        fuzzy mode

HELP

class WalkApp
  Entry = Struct.new(:name, :path, :dir, :hidden, :size, :mtime, keyword_init: true)

  def initialize(argv)
    @icons = argv.delete("--icons")
    @dir_only = argv.delete("--dir-only")
    @hide_hidden = argv.delete("--hide-hidden")
    @preview = argv.delete("--preview")
    @border = argv.delete("--with-border")
    @fuzzy = argv.delete("--fuzzy")
    @start_path = argv.find { |a| !a.start_with?("-") } || "."
    @cwd = File.expand_path(@start_path)
    @cwd = File.dirname(@cwd) unless File.directory?(@cwd)
    @cursor = 0
    @top = 0
    @query = String.new
    @message = nil
    @show_help = false
  end

  def run
    unless File.exist?("/dev/tty") && File.readable?("/dev/tty")
      panic_no_tty
    end

    @tty = File.open("/dev/tty", "r+")
    @old_stty = `stty -g < /dev/tty 2>/dev/null`.strip
    system("stty raw -echo < /dev/tty")
    @tty.sync = true
    @tty.write("\e[?25l\e[?2004h")
    refresh
    loop do
      key = read_key
      break handle_exit(true) if key == "q" || key == "ESC"
      return handle_exit(false) if key == "CTRL_C"
      handle_key(key)
      refresh
    end
  rescue Errno::ENOENT, Errno::EACCES, Errno::ENXIO
    panic_no_tty
  ensure
    cleanup_tty
  end

  private

  def panic_no_tty
    warn "panic: could not open a new TTY: open /dev/tty: no such device or address"
    warn ""
    warn "goroutine 1 [running]:"
    warn "main.main()"
    warn "\t/workspace/main.go:135 +0x87d"
    exit 2
  end

  def handle_exit(with_cd)
    path = selected_cd_path if with_cd
    cleanup_tty
    if with_cd
      puts path
    end
    exit(with_cd ? 0 : 130)
  end

  def cleanup_tty
    return unless @tty
    @tty.write("\e[?2004l\e[?25h\e[?1002l\e[?1003l\e[?1006l") rescue nil
    @tty.write("\e[0m\e[2J\e[H") rescue nil
    system("stty #{@old_stty} < /dev/tty 2>/dev/null") if @old_stty && !@old_stty.empty?
    @tty.close rescue nil
    @tty = nil
  end

  def selected_cd_path
    e = entries[@cursor]
    e&.dir ? e.path : @cwd
  end

  def handle_key(key)
    @message = nil
    case key
    when "UP", "k"
      @cursor -= 1 if @cursor > 0
    when "DOWN", "j"
      @cursor += 1 if @cursor < entries.length - 1
    when "HOME", "H", "LEFT"
      @cursor = 0
    when "END", "L", "RIGHT"
      @cursor = [entries.length - 1, 0].max
    when "ENTER", "l"
      enter_selected
    when "BACKSPACE", "h"
      go_parent
    when "SPACE"
      @preview = !@preview
    when "."
      @hide_hidden = !@hide_hidden
      @cursor = 0
    when "/"
      @fuzzy = true
      @query = String.new
    when "?"
      @show_help = !@show_help
    when "d", "DELETE"
      delete_selected
    when "u"
      @message = "undo is unavailable"
    when "y"
      @message = @cwd
    else
      if @fuzzy
        if key == "BACKSPACE"
          @query = @query[0...-1] || String.new
        elsif key.length == 1 && key.ord >= 32 && key.ord < 127
          @query << key
        end
        @cursor = 0
      end
    end
    keep_cursor_visible
  end

  def enter_selected
    e = entries[@cursor]
    return unless e
    if e.dir
      @cwd = e.path
      @cursor = 0
      @top = 0
      @query = String.new
    else
      editor = ENV["WALK_EDITOR"] || ENV["EDITOR"]
      if editor && !editor.empty?
        restore_temporarily { system(editor, e.path) }
      else
        @message = e.name
      end
    end
  end

  def go_parent
    parent = File.dirname(@cwd)
    return if parent == @cwd
    old = File.basename(@cwd)
    @cwd = parent
    @cursor = [entries.index { |e| e.name == old } || 0, 0].max
    @top = 0
  end

  def delete_selected
    e = entries[@cursor]
    return unless e
    cmd = ENV["WALK_REMOVE_CMD"]
    ok = if cmd && !cmd.empty?
           restore_temporarily { system(cmd, e.path) }
         elsif e.dir
           Dir.rmdir(e.path) rescue false
         else
           File.delete(e.path) rescue false
         end
    @message = ok ? "deleted #{e.name}" : "could not delete #{e.name}"
    @cursor = [@cursor, entries.length - 1].min
  end

  def restore_temporarily
    @tty.write("\e[?2004l\e[?25h") rescue nil
    system("stty #{@old_stty} < /dev/tty 2>/dev/null") if @old_stty && !@old_stty.empty?
    result = yield
    system("stty raw -echo < /dev/tty")
    @tty.write("\e[?25l\e[?2004h") rescue nil
    result
  end

  def entries
    names = Dir.children(@cwd) rescue []
    list = names.filter_map do |name|
      hidden = name.start_with?(".")
      next if @hide_hidden && hidden
      path = File.join(@cwd, name)
      dir = File.directory?(path)
      next if @dir_only && !dir
      next if @fuzzy && !@query.empty? && !fuzzy_match?(name.downcase, @query.downcase)
      st = File.lstat(path) rescue nil
      Entry.new(name: name, path: path, dir: dir, hidden: hidden, size: st&.size || 0, mtime: st&.mtime || Time.at(0))
    end
    list.sort_by { |e| [e.dir ? 0 : 1, e.name.downcase, e.name] }
  end

  def fuzzy_match?(name, query)
    pos = 0
    query.each_char do |ch|
      found = name.index(ch, pos)
      return false unless found
      pos = found + 1
    end
    true
  end

  def refresh
    rows, cols = terminal_size
    list_width = @preview ? [cols / 2, 24].max : cols
    visible_rows = [rows - 2, 1].max
    keep_cursor_visible(visible_rows)
    @tty.write("\e[H\e[2J")
    if @show_help
      draw_help(rows, cols)
      return
    end
    slice = entries[@top, visible_rows] || []
    slice.each_with_index do |entry, i|
      idx = @top + i
      selected = idx == @cursor
      line = format_entry(entry, list_width - 1)
      @tty.write(selected ? "\e[38;5;231;48;5;99m" : "")
      @tty.write(line.ljust(list_width)[0, list_width])
      @tty.write("\e[0m") if selected
      if @preview
        @tty.write(" ")
        draw_preview_line(entry, i, cols - list_width - 1, selected)
      end
      @tty.write("\r\n")
    end
    (visible_rows - slice.length).times { @tty.write("\r\n") }
    status = status_line(cols)
    @tty.write("\e[7m#{status.ljust(cols)[0, cols]}\e[0m")
  end

  def draw_help(rows, cols)
    HELP.lines.first(rows).each { |line| @tty.write(line.chomp[0, cols].ljust(cols) + "\r\n") }
  end

  def format_entry(entry, width)
    suffix = entry.dir ? "/" : ""
    icon = @icons ? icon_for(entry) + " " : ""
    text = "#{icon}#{entry.name}#{suffix}"
    text.length > width ? text[0, width - 1] + "…" : text
  end

  def icon_for(entry)
    return "" if entry.dir
    case File.extname(entry.name).downcase
    when ".rb" then ""
    when ".go" then ""
    when ".md" then ""
    when ".json" then ""
    when ".sh" then ""
    else ""
    end
  end

  def draw_preview_line(entry, line_no, width, selected)
    return if width <= 0 || !selected
    lines = preview_lines(entry)
    text = lines[line_no] || ""
    @tty.write(text.gsub(/[[:cntrl:]]/, "")[0, width].ljust(width))
  end

  def preview_lines(entry)
    if entry.dir
      Dir.children(entry.path).sort.first(50).map { |n| n + (File.directory?(File.join(entry.path, n)) ? "/" : "") } rescue []
    else
      File.open(entry.path, "rb") { |f| f.read(4096) }.to_s.lines.first(50) || []
    end
  rescue
    []
  end

  def status_line(cols)
    if @fuzzy
      "/#{@query}"
    elsif @message
      @message
    else
      "#{@cwd}  #{entries.length}"
    end
  end

  def keep_cursor_visible(visible_rows = nil)
    len = entries.length
    @cursor = 0 if len.zero?
    @cursor = len - 1 if len.positive? && @cursor >= len
    @cursor = 0 if @cursor.negative?
    visible_rows ||= [terminal_size[0] - 2, 1].max
    @top = @cursor if @cursor < @top
    @top = @cursor - visible_rows + 1 if @cursor >= @top + visible_rows
    @top = 0 if @top.negative?
  end

  def terminal_size
    out = `stty size < /dev/tty 2>/dev/null`.split.map(&:to_i)
    rows, cols = out.length == 2 ? out : [24, 80]
    [rows > 0 ? rows : 24, cols > 0 ? cols : 80]
  end

  def read_key
    ch = @tty.read(1)
    return "CTRL_C" if ch == "\x03"
    return "ENTER" if ch == "\r" || ch == "\n"
    return "BACKSPACE" if ch == "\x7f" || ch == "\b"
    return "SPACE" if ch == " "
    if ch == "\e"
      seq = String.new
      while IO.select([@tty], nil, nil, 0.01)
        seq << @tty.read(1)
        break if seq.length > 8
      end
      return "UP" if seq == "[A"
      return "DOWN" if seq == "[B"
      return "RIGHT" if seq == "[C"
      return "LEFT" if seq == "[D"
      return "HOME" if seq.start_with?("[H", "[1~")
      return "END" if seq.start_with?("[F", "[4~")
      return "DELETE" if seq.start_with?("[3~")
      return "ESC"
    end
    ch
  end
end

argv = ARGV.dup
if argv.include?("--version")
  puts VERSION
  exit 0
end
if argv.include?("--help") || argv.include?("-h")
  print HELP
  exit 1
end

WalkApp.new(argv).run
