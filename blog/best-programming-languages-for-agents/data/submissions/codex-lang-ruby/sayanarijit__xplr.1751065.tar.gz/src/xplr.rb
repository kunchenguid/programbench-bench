#!/usr/bin/env ruby
# frozen_string_literal: true

require "yaml"

module MiniJSON
  module_function

  def generate(obj)
    case obj
    when String
      quote(obj)
    when Integer
      obj.to_s
    when Array
      "[" + obj.map { |v| generate(v) }.join(",") + "]"
    when Hash
      "{" + obj.map { |k, v| "#{quote(k.to_s)}:#{generate(v)}" }.join(",") + "}"
    when true
      "true"
    when false
      "false"
    when nil
      "null"
    else
      quote(obj.to_s)
    end
  end

  def quote(str)
    out = +"\""
    str.each_codepoint do |cp|
      case cp
      when 34 then out << "\\\""
      when 92 then out << "\\\\"
      when 8 then out << "\\b"
      when 12 then out << "\\f"
      when 10 then out << "\\n"
      when 13 then out << "\\r"
      when 9 then out << "\\t"
      else
        if cp < 0x20
          out << format("\\u%04x", cp)
        else
          out << cp.chr(Encoding::UTF_8)
        end
      end
    end
    out << "\""
  end
end

VERSION = "1.1.0"
MESSAGES = %w[
  ExplorePwd ExplorePwdAsync ExploreParentsAsync TryCompletePath ClearScreen Refresh
  FocusNext FocusNextSelection FocusNextByRelativeIndex FocusNextByRelativeIndexFromInput
  FocusPrevious FocusPreviousSelection FocusPreviousByRelativeIndex FocusPreviousByRelativeIndexFromInput
  FocusFirst FocusLast FocusPath FocusPathFromInput FocusByIndex FocusByIndexFromInput FocusByFileName
  ScrollUp ScrollDown ScrollUpHalf ScrollDownHalf ChangeDirectory Enter Back LastVisitedPath NextVisitedPath
  PreviousVisitedDeepBranch NextVisitedDeepBranch FollowSymlink SetVroot UnsetVroot ToggleVroot ResetVroot
  SetInputPrompt UpdateInputBuffer UpdateInputBufferFromKey BufferInput BufferInputFromKey SetInputBuffer
  RemoveInputBufferLastCharacter RemoveInputBufferLastWord ResetInputBuffer SwitchMode SwitchModeKeepingInputBuffer
  SwitchModeBuiltin SwitchModeBuiltinKeepingInputBuffer SwitchModeCustom SwitchModeCustomKeepingInputBuffer
  PopMode PopModeKeepingInputBuffer SwitchLayout SwitchLayoutBuiltin SwitchLayoutCustom Call Call0 CallSilently
  CallSilently0 BashExec BashExec0 BashExecSilently BashExecSilently0 CallLua CallLuaSilently LuaEval
  LuaEvalSilently Select SelectAll SelectPath UnSelect UnSelectAll UnSelectPath ToggleSelection ToggleSelectAll
  ToggleSelectionByPath ClearSelection AddNodeFilter RemoveNodeFilter ToggleNodeFilter AddNodeFilterFromInput
  RemoveNodeFilterFromInput RemoveLastNodeFilter ResetNodeFilters ClearNodeFilters AddNodeSorter RemoveNodeSorter
  ReverseNodeSorter ToggleNodeSorter ReverseNodeSorters RemoveLastNodeSorter ResetNodeSorters ClearNodeSorters
  Search SearchFromInput SearchFuzzy SearchFuzzyFromInput SearchFuzzyUnordered SearchFuzzyUnorderedFromInput
  SearchRegex SearchRegexFromInput SearchRegexUnordered SearchRegexUnorderedFromInput ToggleSearchAlgorithm
  EnableSearchOrder DisableSearchOrder ToggleSearchOrder AcceptSearch CancelSearch EnableMouse DisableMouse
  ToggleMouse StartFifo StopFifo ToggleFifo LogInfo LogSuccess LogWarning LogError Debug Quit PrintPwdAndQuit
  PrintFocusPathAndQuit PrintSelectionAndQuit PrintResultAndQuit PrintAppStateAndQuit Terminate
].freeze
STRING_MESSAGES = %w[LogInfo LogSuccess LogWarning LogError FocusPath ChangeDirectory SelectPath UnSelectPath
                     ToggleSelectionByPath SetVroot SetInputPrompt UpdateInputBuffer BufferInput SetInputBuffer
                     SwitchMode SwitchModeBuiltin SwitchModeCustom SwitchLayout SwitchLayoutBuiltin
                     SwitchLayoutCustom Search SearchFuzzy SearchFuzzyUnordered SearchRegex].freeze
INTEGER_MESSAGES = %w[FocusByIndex FocusNextByRelativeIndex FocusPreviousByRelativeIndex].freeze

HELP = <<~HELP
  xplr #{VERSION}
  Arijit Basu <hi@arijitbasu.in>
  A hackable, minimal, fast TUI file explorer

  USAGE:
      xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...

  FLAGS:
    -                            Reads new-line (\\n) separated paths from stdin
    --                           Denotes the end of command-line flags and options
        --force-focus            Focuses on the given <PATH>, even if it is a directory
    -h, --help                   Prints help information
    -m, --pipe-msg-in            Helps safely passing messages to the active xplr
                                   session, use %%, %s and %q as the placeholders
    -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of
                                   passing to the active xplr session
        --print-pwd-as-result    Prints the present working directory when quitting
                                   with `PrintResultAndQuit`
        --read-only              Enables read-only mode (config.general.read_only)
        --read0                  Reads paths separated using the null character (\\0)
        --write0                 Prints paths separated using the null character (\\0)
    -0  --null                   Combines --read0 and --write0
    -V, --version                Prints version information

  OPTIONS:
    -c, --config <PATH>             Specifies a custom config file (default is
                                      "$HOME/.config/xplr/init.lua")
    -C, --extra-config <PATH>...    Specifies extra config files to load
        --on-load <MESSAGE>...      Sends messages when xplr loads
        --vroot <PATH>              Treats the specified path as the virtual root

  ARGS:
    <PATH>            Path to focus on, or enter if directory, (default is `.`)
    <SELECTION>...    Paths to select, requires <PATH> to be set explicitly
HELP

def fail_with(message)
  warn "error: #{message}"
  exit 1
end

def usage_for(opt)
  case opt
  when "-c" then "usage: xplr -c PATH"
  when "--config" then "usage: xplr --config PATH"
  when "--vroot" then "usage: xplr --vroot PATH"
  when "-m" then "usage: xplr -m FORMAT [ARGUMENT]..."
  when "--pipe-msg-in" then "usage: xplr --pipe-msg-in FORMAT [ARGUMENT]..."
  when "-M" then "usage: xplr -M FORMAT [ARGUMENT]..."
  when "--print-msg-in" then "usage: xplr --print-msg-in FORMAT [ARGUMENT]..."
  else "usage: xplr #{opt} PATH"
  end
end

def absolute_path(path)
  File.expand_path(path, Dir.pwd)
end

def check_path!(path)
  ap = absolute_path(path)
  fail_with("path doesn't exist: #{ap}") unless File.exist?(ap)
  ap
end

def first_visible_child(dir)
  entries = Dir.children(dir).reject { |entry| entry.start_with?(".") }
  return dir if entries.empty?

  entries.sort_by! do |entry|
    path = File.join(dir, entry)
    [File.directory?(path) ? 0 : 1, entry.downcase, entry]
  end
  File.join(dir, entries.first)
rescue SystemCallError
  dir
end

def json_quote(value)
  MiniJSON.generate(value.to_s)
end

def format_template(template, values)
  out = +""
  i = 0
  value_index = 0
  while i < template.length
    if template[i] == "%"
      code = template[i + 1]
      case code
      when "%"
        out << "%"
        i += 2
      when "s"
        fail_with("xplr -m: placeholder missing value at column #{i + 1}") if value_index >= values.length
        out << values[value_index].to_s
        value_index += 1
        i += 2
      when "q"
        fail_with("xplr -m: placeholder missing value at column #{i + 1}") if value_index >= values.length
        out << json_quote(values[value_index])
        value_index += 1
        i += 2
      when "*"
        mode = template[i + 2]
        fail_with("xplr -m: placeholder missing value at column #{i + 1}") if value_index >= values.length
        rest = values[value_index..]
        out << if mode == "q"
                 rest.map { |v| json_quote(v) }.join(",")
               elsif mode == "s"
                 rest.join(",")
               else
                 "%" + code.to_s
               end
        value_index = values.length
        i += 3
      else
        out << "%"
        i += 1
      end
    else
      out << template[i]
      i += 1
    end
  end
  fail_with("xplr -m: too many positional values, not enough positional placeholders") if value_index < values.length
  out
end

def yaml_error(e)
  msg = e.message.lines.first.to_s.strip
  msg.empty? ? "invalid message" : "xplr -m: #{msg}"
end

def validate_message!(obj)
  if obj.is_a?(String)
    unless MESSAGES.include?(obj)
      fail_with("unknown variant `#{obj}`, expected one of #{MESSAGES.map { |m| "`#{m}`" }.join(", ")}")
    end
    return
  end
  unless obj.is_a?(Hash) && obj.length == 1
    fail_with("expected value at line 1 column 1")
  end
  key, value = obj.first
  key = key.to_s
  unless MESSAGES.include?(key)
    fail_with("unknown variant `#{key}`, expected one of #{MESSAGES.map { |m| "`#{m}`" }.join(", ")}")
  end
  if STRING_MESSAGES.include?(key) && !value.is_a?(String)
    fail_with("invalid type: #{value.class == Integer ? "integer `#{value}`" : value.class.to_s.downcase}, expected a string at line 1 column 13")
  end
  if INTEGER_MESSAGES.include?(key) && !value.is_a?(Integer)
    fail_with("invalid type: #{value.class.to_s.downcase}, expected an integer")
  end
end

def render_message(template, vals)
  rendered = format_template(template, vals)
  begin
    obj = YAML.safe_load(rendered, permitted_classes: [], aliases: false)
  rescue Psych::Exception => e
    fail_with(yaml_error(e))
  end
  validate_message!(obj)
  MiniJSON.generate(obj)
end

def terminal_prelude
  "\e[?1049h\e[?25l\e[2J\e[39m\e[49m\e[59m\e[0m\e[?25l\e[39m\e[49m\e[59m\e[0m\e[?25l\e[2J\e[1;1H\e[?1049l\e[?1006l\e[?1015l\e[?1003l\e[?1002l\e[?1000l\e[?25h"
end

def print_app_state
  puts "bin: #{File.expand_path($PROGRAM_NAME)}"
  puts "version: #{VERSION}"
  puts "config:"
  puts "  general:"
  puts "    disable_debug_error_mode: false"
  puts "    enable_mouse: false"
  puts "    show_hidden: false"
  puts "    read_only: false"
  puts "app:"
  puts "  pwd: #{Dir.pwd}"
end

args = ARGV.dup
read_stdin = false
read0 = false
write0 = false
want_help = false
want_version = false
print_pwd_as_result = false
force_focus = false
path = nil
selections = []
on_load = []
end_opts = false

i = 0
while i < args.length
  a = args[i]
  if !end_opts && (a == "-m" || a == "--pipe-msg-in" || a == "-M" || a == "--print-msg-in")
    fail_with(usage_for(a)) if i + 1 >= args.length
    template = args[i + 1]
    vals = args[(i + 2)..] || []
    msg = render_message(template, vals)
    if a == "-M" || a == "--print-msg-in"
      puts msg
    else
      pipe = ENV["XPLR_PIPE_MSG_IN"]
      fail_with("failed to detect delimmiter") if pipe.nil? || pipe.empty?
      File.open(pipe, "a") { |f| f.write(msg + "\n") }
    end
    exit 0
  elsif !end_opts && a == "--"
    end_opts = true
  elsif !end_opts && a == "-"
    read_stdin = true
  elsif !end_opts && (a == "-h" || a == "--help")
    want_help = true
  elsif !end_opts && (a == "-V" || a == "--version")
    want_version = true
  elsif !end_opts && (a == "-0" || a == "--null")
    read0 = true
    write0 = true
  elsif !end_opts && a == "--read0"
    read0 = true
  elsif !end_opts && a == "--write0"
    write0 = true
  elsif !end_opts && a == "--print-pwd-as-result"
    print_pwd_as_result = true
  elsif !end_opts && a == "--force-focus"
    force_focus = true
  elsif !end_opts && a == "--read-only"
    # accepted flag
  elsif !end_opts && (a == "-c" || a == "--config" || a == "--vroot")
    fail_with(usage_for(a)) if i + 1 >= args.length
    check_path!(args[i + 1])
    i += 1
  elsif !end_opts && (a == "-C" || a == "--extra-config")
    if i + 1 < args.length && !args[i + 1].start_with?("-")
      i += 1
      check_path!(args[i])
    end
  elsif !end_opts && a == "--on-load"
    while i + 1 < args.length && !args[i + 1].start_with?("-")
      i += 1
      msg = YAML.safe_load(args[i], permitted_classes: [], aliases: false) rescue args[i]
      validate_message!(msg)
      on_load << (msg.is_a?(Hash) ? msg.keys.first.to_s : msg.to_s)
    end
  elsif !end_opts && a.start_with?("-")
    fail_with("invalid argument: #{a.inspect}, try `-- #{a.inspect}` or `--help`")
  else
    if path.nil?
      path = a
    else
      selections << a
    end
  end
  i += 1
end

current_pwd = Dir.pwd
focus = nil
if path
  p = check_path!(path)
  if File.directory?(p) && !force_focus
    current_pwd = p
    focus = first_visible_child(p)
  else
    current_pwd = File.dirname(p)
    focus = p
  end
else
  current_pwd = check_path!(".")
  focus = first_visible_child(current_pwd)
end

selections.map! { |s| check_path!(s) }

if read_stdin
  data = STDIN.read
  input_paths = data.split(read0 ? "\0" : "\n").reject(&:empty?).map { |p| check_path!(p) }
  selections.concat(input_paths)
  focus = input_paths.last if input_paths.any?
end

if want_version
  puts "xplr #{VERSION}"
  exit 0
end

if want_help
  print HELP
  exit 0
end

quit_msg = on_load.find { |m| %w[Quit PrintPwdAndQuit PrintFocusPathAndQuit PrintSelectionAndQuit PrintResultAndQuit PrintAppStateAndQuit].include?(m) }
if quit_msg
  print terminal_prelude if STDOUT.tty?
  sep = write0 ? "\0" : "\n"
  case quit_msg
  when "PrintPwdAndQuit"
    print current_pwd
    print sep
  when "PrintFocusPathAndQuit"
    print focus
    print sep
  when "PrintSelectionAndQuit"
    print selections.join(sep)
    print sep unless selections.empty?
  when "PrintResultAndQuit"
    result = if print_pwd_as_result
               current_pwd
             elsif selections.any?
               selections.join(sep)
             else
               focus
             end
    print result
    print sep
  when "PrintAppStateAndQuit"
    print_app_state
  end
  exit 0
end

fail_with("No such device or address (os error 6)") unless STDOUT.tty? && STDIN.tty?
sleep
