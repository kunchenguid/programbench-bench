#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require 'json'
require 'yaml'
require 'base64'
require 'time'
require 'pathname'
require 'fileutils'
require 'resolv'
require 'securerandom'
require 'digest'
require 'openssl'
require 'uri'

class MissingValue
  def to_s = '<no value>'
end

MISSING = MissingValue.new

class GoTime
  LAYOUTS = {
    'Mon Jan _2 15:04:05 2006' => '%a %b %e %H:%M:%S %Y',
    'Mon Jan _2 15:04:05 MST 2006' => '%a %b %e %H:%M:%S %Z %Y',
    'Mon Jan 02 15:04:05 -0700 2006' => '%a %b %d %H:%M:%S %z %Y',
    '02 Jan 06 15:04 MST' => '%d %b %y %H:%M %Z',
    '02 Jan 06 15:04 -0700' => '%d %b %y %H:%M %z',
    'Monday, 02-Jan-06 15:04:05 MST' => '%A, %d-%b-%y %H:%M:%S %Z',
    'Mon, 02 Jan 2006 15:04:05 MST' => '%a, %d %b %Y %H:%M:%S %Z',
    'Mon, 02 Jan 2006 15:04:05 -0700' => '%a, %d %b %Y %H:%M:%S %z',
    '2006-01-02T15:04:05Z07:00' => '%Y-%m-%dT%H:%M:%S%:z',
    '3:04PM' => '%-l:%M%p',
    'Jan _2 15:04:05' => '%b %e %H:%M:%S'
  }.freeze

  def initialize(time)
    @time = time
  end

  def Format(layout)
    ruby = LAYOUTS[layout] || layout.gsub('2006', '%Y').gsub('06', '%y').gsub('January', '%B')
                            .gsub('Jan', '%b').gsub('Monday', '%A').gsub('Mon', '%a')
                            .gsub('02', '%d').gsub('_2', '%e').gsub('2', '%-d')
                            .gsub('15', '%H').gsub('03', '%I').gsub('3', '%-I')
                            .gsub('04', '%M').gsub('05', '%S').gsub('PM', '%p')
                            .gsub('MST', '%Z').gsub('-0700', '%z').gsub('Z07:00', '%:z')
    @time.strftime(ruby)
  end

  def UTC = GoTime.new(@time.utc)
  def Local = GoTime.new(@time.localtime)
  def Add(sec) = GoTime.new(@time + sec.to_f)
  def AddDate(y, m, d) = GoTime.new(Time.new(@time.year + y.to_i, @time.month + m.to_i, @time.day + d.to_i, @time.hour, @time.min, @time.sec, @time.utc_offset))
  def Round(sec) = GoTime.new(Time.at((@time.to_f / sec.to_f).round * sec.to_f).localtime)
  def IsDST = @time.isdst
  def to_s = @time.to_s
end

class Renderer
  attr_reader :datasources

  def initialize(opts = {})
    @datasources = opts[:datasources] || {}
    @context = opts[:context] || { 'Env' => ENV.to_h }
    @vars = {}
    @templates = {}
    @left = opts[:left] || ENV['GOMPLATE_LEFT_DELIM'] || '{{'
    @right = opts[:right] || ENV['GOMPLATE_RIGHT_DELIM'] || '}}'
    @missing_key = opts[:missing_key] || 'error'
  end

  def render(template, ctx = @context)
    toks = tokenize(template)
    render_tokens(toks, ctx, 0, nil)[0]
  end

  def tokenize(template)
    out = []
    i = 0
    while (s = template.index(@left, i))
      out << [:text, template[i...s]] if s > i
      trim_left = template[s + @left.length] == '-'
      a = s + @left.length + (trim_left ? 1 : 0)
      e = template.index(@right, a)
      break unless e
      trim_right = template[e - 1] == '-'
      body_end = e - (trim_right ? 1 : 0)
      out[-1][1].sub!(/[ \t]*\n?\z/, '') if trim_left && out[-1]&.first == :text
      out << [:action, template[a...body_end].strip]
      i = e + @right.length
      i += 1 while trim_right && template[i] =~ /[ \t\r\n]/
    end
    out << [:text, template[i..] || '']
    out
  end

  def render_tokens(toks, ctx, idx, stop)
    out = +''
    while idx < toks.length
      kind, val = toks[idx]
      if kind == :text
        out << val
        idx += 1
        next
      end
      return [out, idx, val] if stop&.include?(val.split(/\s+/, 2)[0])
      case val
      when /\A\/\*/ then idx += 1
      when /\Adefine\s+"([^"]+)"/
        name = Regexp.last_match(1)
        inner, ni = collect_block(toks, idx + 1)
        @templates[name] = inner
        idx = ni + 1
      when /\Atemplate\s+/
        parts = split_words(val)
        name = eval_expr(parts[1], ctx).to_s
        tctx = parts[2] ? eval_expr(parts[2..].join(' '), ctx) : ctx
        out << render_tokens(@templates[name] || [], tctx, 0, nil)[0]
        idx += 1
      when /\Aif\s+(.+)/
        cond = truthy?(eval_expr(Regexp.last_match(1), ctx))
        yes, next_i, stop_word = render_tokens(toks, ctx, idx + 1, %w[else end])
        if cond
          out << yes
          idx = skip_to_end(toks, next_i)
        elsif stop_word&.start_with?('else')
          no, end_i = render_tokens(toks, ctx, next_i + 1, ['end'])
          out << no
          idx = end_i + 1
        else
          idx = next_i + 1
        end
      when /\Arange(?:\s+(.+))?/
        expr = Regexp.last_match(1)
        list = expr ? eval_expr(expr, ctx) : ctx
        block, ni = collect_block(toks, idx + 1)
        arr = list.is_a?(Hash) ? list.keys.sort.map { |k| list[k] } : Array(list)
        if arr.empty?
          else_block = split_else(block)[1]
          out << render_tokens(else_block, ctx, 0, nil)[0] if else_block
        else
          main_block = split_else(block)[0]
          arr.each { |item| out << render_tokens(main_block, item, 0, nil)[0] }
        end
        idx = ni + 1
      when /\Awith\s+(.+)/
        val2 = eval_expr(Regexp.last_match(1), ctx)
        block, ni = collect_block(toks, idx + 1)
        out << render_tokens(block, val2, 0, nil)[0] if truthy?(val2)
        idx = ni + 1
      when /\A\$(\w+)\s*:=\s*(.+)/
        @vars[Regexp.last_match(1)] = eval_expr(Regexp.last_match(2), ctx)
        idx += 1
      else
        v = eval_expr(val, ctx)
        out << stringify(v)
        idx += 1
      end
    end
    [out, idx, nil]
  end

  def collect_block(toks, idx)
    depth = 1
    start = idx
    while idx < toks.length
      if toks[idx][0] == :action
        w = toks[idx][1].split(/\s+/, 2)[0]
        depth += 1 if %w[if range with define].include?(w)
        depth -= 1 if w == 'end'
        return [toks[start...idx], idx] if depth.zero?
      end
      idx += 1
    end
    [toks[start..] || [], idx]
  end

  def split_else(block)
    depth = 0
    block.each_with_index do |t, i|
      next unless t[0] == :action
      w = t[1].split(/\s+/, 2)[0]
      depth += 1 if %w[if range with define].include?(w)
      depth -= 1 if w == 'end'
      return [block[0...i], block[(i + 1)..]] if depth.zero? && w == 'else'
    end
    [block, nil]
  end

  def skip_to_end(toks, idx)
    depth = 0
    while idx < toks.length
      if toks[idx][0] == :action
        w = toks[idx][1].split(/\s+/, 2)[0]
        depth += 1 if %w[if range with define].include?(w)
        return idx + 1 if w == 'end' && depth.zero?
        depth -= 1 if w == 'end'
      end
      idx += 1
    end
    idx
  end

  def eval_expr(expr, ctx)
    expr = expr.strip
    return nil if expr.empty?
    parts = split_top(expr, '|')
    val = eval_command(parts.shift, ctx)
    parts.each { |p| val = eval_command(p, ctx, val) }
    val
  end

  def eval_command(cmd, ctx, pipe = :none)
    cmd = cmd.strip
    return eval_atom(cmd, ctx) if pipe == :none && cmd.start_with?('(')
    words = split_words(cmd)
    return nil if words.empty?
    if pipe != :none
      words << '__PIPE__'
      @vars['__PIPE__'] = pipe
    end
    if words.length == 1
      eval_atom(words[0], ctx)
    else
      fn = words.shift
      args = words.map { |w| eval_atom(w, ctx) }
      call_func(fn, args, ctx)
    end
  end

  def eval_atom(tok, ctx)
    tok = tok.strip
    return @vars['__PIPE__'] if tok == '__PIPE__'
    if tok.start_with?('(')
      close = matching_paren(tok, 0)
      base = eval_expr(tok[1...close], ctx)
      return apply_suffix(base, tok[(close + 1)..].to_s)
    end
    case tok
    when /\A"(.*)"\z/m then unescape(Regexp.last_match(1))
    when /\A`(.*)`\z/m then Regexp.last_match(1)
    when /\A'(.*)'\z/m then Regexp.last_match(1)
    when /\Atrue\z/ then true
    when /\Afalse\z/ then false
    when /\Anil|null\z/ then nil
    when /\A-?(?:0x[0-9a-fA-F]+|0[0-7]+|\d+)\z/ then parse_int(tok)
    when /\A-?(?:\d+\.\d*|\d*\.\d+|\d+e[+-]?\d+|\d+\.\d*e[+-]?\d+|NaN|Inf)\z/i then tok =~ /nan/i ? Float::NAN : (tok =~ /inf/i ? (tok.start_with?('-') ? -Float::INFINITY : Float::INFINITY) : tok.to_f)
    when /\A\.(.*)\z/m then apply_suffix(ctx, tok)
    when /\A\$(\w+)(.*)\z/m then apply_suffix(@vars[Regexp.last_match(1)], Regexp.last_match(2))
    else
      if tok.include?('.')
        prefix = longest_func_prefix(tok)
        return apply_suffix(call_func(prefix, [], ctx), tok[prefix.length..].to_s) if prefix
      end
      return call_func(tok, [], ctx) if function_name?(tok)
      tok
    end
  end

  def longest_func_prefix(tok)
    @funcs ||= nil
    function_name?('print') unless @funcs
    @funcs.select { |f| tok == f || tok.start_with?("#{f}.") }.max_by(&:length)
  end

  def apply_suffix(obj, suffix)
    s = suffix.to_s
    s = s[1..] if s.start_with?('.')
    return obj if s.nil? || s.empty?
    cur = obj
    s.split('.').each do |part|
      next if part.empty?
      if part =~ /\A(\w+)\s+(.*)\z/
        cur = call_method(cur, Regexp.last_match(1), split_words(Regexp.last_match(2)).map { |w| eval_atom(w, cur) })
      else
        cur = access(cur, part)
      end
    end
    cur
  end

  def access(obj, key)
    return MISSING if obj.equal?(MISSING) || obj.nil?
    return obj[key] || obj[key.to_sym] || missing(key) if obj.is_a?(Hash)
    return obj[key.to_i] if obj.is_a?(Array) && key =~ /\A\d+\z/
    return obj.public_send(key) if obj.respond_to?(key)
    return call_method(obj, key, []) if obj.is_a?(GoTime)
    missing(key)
  end

  def missing(key)
    @missing_key == 'error' ? MISSING : MISSING
  end

  def call_method(obj, name, args)
    obj.respond_to?(name) ? obj.public_send(name, *args) : MISSING
  end

  def call_func(name, args, ctx)
    n = name.tr('-', '_')
    case n
    when 'env.Env' then ENV.to_h
    when 'env.Getenv', 'getenv' then getenv(args[0].to_s, args[1].to_s)
    when 'env.HasEnv' then ENV.key?(args[0].to_s)
    when 'env.ExpandEnv' then args[0].to_s.gsub(/\$\{?([A-Za-z_][A-Za-z0-9_]*)\}?/) { getenv(Regexp.last_match(1), '') }
    when 'add', 'math.Add' then numeric_reduce(args, 0, :+)
    when 'mul', 'math.Mul' then numeric_reduce(args, 1, :*)
    when 'sub', 'math.Sub' then nums(args).then { |a| a[1..].reduce(a[0]) { |x, y| x - y } }
    when 'div', 'math.Div' then to_num(args[0]).to_f / to_num(args[1]).to_f
    when 'mod', 'math.Mod' then to_num(args[0]).to_i % to_num(args[1]).to_i
    when 'math.Abs' then v = to_num(args[0]); v.respond_to?(:abs) ? v.abs : v
    when 'math.Ceil' then to_num(args[0]).ceil
    when 'math.Floor' then to_num(args[0]).floor
    when 'math.Round' then to_num(args[0]).round
    when 'math.Max' then nums(args).max
    when 'math.Min' then nums(args).min
    when 'math.Pow' then to_num(args[0])**to_num(args[1])
    when 'math.Seq', 'seq' then seq(*args)
    when 'math.IsInt' then intish?(args[0])
    when 'math.IsFloat' then floatish?(args[0])
    when 'coll.Slice', 'slice' then args
    when 'coll.Dict', 'dict' then Hash[*args.each_slice(2).flat_map { |k, v| [k.to_s, v.nil? ? '' : v] }]
    when 'coll.Has', 'has' then args[0].is_a?(Hash) ? args[0].key?(args[1].to_s) : Array(args[0]).include?(args[1])
    when 'coll.Keys' then args[0].is_a?(Hash) ? args[0].keys.sort : []
    when 'coll.Values' then args[0].is_a?(Hash) ? args[0].keys.sort.map { |k| args[0][k] } : []
    when 'default', 'conv.Default' then empty?(args[1]) ? args[0] : args[1]
    when 'required' then empty?(args[0]) ? raise('required value was not set') : args[0]
    when 'join', 'conv.Join' then Array(args[0]).map { |x| stringify(x) }.join(args[1].to_s)
    when 'bool', 'conv.Bool', 'conv.ToBool' then %w[1 t true y yes on].include?(args[0].to_s.downcase)
    when 'conv.ToString', 'toString' then args[0].is_a?(Array) ? args[0].map(&:chr).join : args[0].to_s
    when 'conv.ToInt', 'conv.ToInt64', 'atoi' then to_num(args[0]).to_i
    when 'conv.ToFloat', 'conv.ToFloat64' then to_num(args[0]).to_f
    when 'data.JSON', 'json' then JSON.parse(args[0].to_s)
    when 'data.YAML', 'yaml' then YAML.safe_load(args[0].to_s, aliases: true)
    when 'data.ToJSON', 'toJSON' then JSON.generate(args[0])
    when 'data.ToJSONPretty', 'toJSONPretty' then JSON.pretty_generate(args.length > 1 ? args[1] : args[0])
    when 'data.ToYAML', 'toYAML' then YAML.dump(sort_hash(args[0])).sub(/\A---\n/, '')
    when 'datasource', 'ds' then datasource(args[0].to_s)
    when 'include' then raw_datasource(args[0].to_s)
    when 'datasourceExists' then @datasources.key?(args[0].to_s)
    when 'listDatasources' then @datasources.keys.sort
    when 'defineDatasource' then @datasources[args[0].to_s] ||= args[1].to_s; ''
    when 'base64.Encode' then Base64.strict_encode64(args[0].to_s)
    when 'base64.Decode' then Base64.decode64(args[0].to_s)
    when 'base64.DecodeBytes' then Base64.decode64(args[0].to_s).bytes
    when 'strings.Contains' then args[1].to_s.include?(args[0].to_s)
    when 'strings.HasPrefix' then args[1].to_s.start_with?(args[0].to_s)
    when 'strings.HasSuffix' then args[1].to_s.end_with?(args[0].to_s)
    when 'strings.ToUpper', 'upper' then args[0].to_s.upcase
    when 'strings.ToLower', 'lower' then args[0].to_s.downcase
    when 'strings.Title', 'title' then args[0].to_s.split(/(\s+)/).map(&:capitalize).join
    when 'strings.Trim', 'trim' then args[0].to_s.strip
    when 'strings.TrimSpace' then args[0].to_s.strip
    when 'strings.TrimPrefix' then args[1].to_s.delete_prefix(args[0].to_s)
    when 'strings.TrimSuffix' then args[1].to_s.delete_suffix(args[0].to_s)
    when 'strings.ReplaceAll' then args[2].to_s.gsub(args[0].to_s, args[1].to_s)
    when 'strings.Replace' then args[2].to_s.sub(args[0].to_s, args[1].to_s)
    when 'strings.Split' then args[1].to_s.split(args[0].to_s)
    when 'strings.Repeat' then args[1].to_s * args[0].to_i
    when 'strings.Indent', 'indent' then args[-1].to_s.lines.map { |l| (' ' * args[0].to_i) + l }.join
    when 'strings.Quote' then args[0].to_s.inspect
    when 'strings.Abbrev' then abbrev(args)
    when 'regexp.Match' then !!(args[1].to_s =~ Regexp.new(args[0].to_s))
    when 'regexp.Find' then args[1].to_s[Regexp.new(args[0].to_s)].to_s
    when 'regexp.FindAll' then re_find_all(args)
    when 'regexp.Replace' then args[2].to_s.gsub(Regexp.new(args[0].to_s), args[1].to_s)
    when 'regexp.QuoteMeta' then Regexp.escape(args[0].to_s)
    when 'file.Exists' then File.exist?(args[0].to_s)
    when 'file.IsDir' then File.directory?(args[0].to_s)
    when 'file.Read' then File.read(args[0].to_s)
    when 'file.ReadDir' then Dir.children(args[0].to_s).sort
    when 'filepath.Base', 'path.Base' then File.basename(args[0].to_s)
    when 'filepath.Dir', 'path.Dir' then File.dirname(args[0].to_s)
    when 'filepath.Ext', 'path.Ext' then File.extname(args[0].to_s)
    when 'filepath.Clean', 'path.Clean' then Pathname.new(args[0].to_s).cleanpath.to_s
    when 'filepath.IsAbs', 'path.IsAbs' then Pathname.new(args[0].to_s).absolute?
    when 'filepath.Join', 'path.Join' then File.join(*args.map(&:to_s))
    when 'net.LookupIP' then Resolv.getaddress(args[0].to_s) rescue ''
    when 'net.LookupIPs' then Resolv.getaddresses(args[0].to_s).select { |x| x.include?('.') }.uniq rescue []
    when 'net.LookupCNAME' then Resolv::DNS.open { |d| d.getresource(args[0].to_s, Resolv::DNS::Resource::IN::CNAME).name.to_s } rescue "#{args[0]}."
    when 'uuid.New', 'uuid' then SecureRandom.uuid
    when 'crypto.SHA1' then Digest::SHA1.hexdigest(args[0].to_s)
    when 'crypto.SHA256' then Digest::SHA256.hexdigest(args[0].to_s)
    when 'crypto.MD5' then Digest::MD5.hexdigest(args[0].to_s)
    when 'time.Now' then GoTime.new(Time.now)
    when 'time.Parse' then GoTime.new(Time.parse(args[1].to_s))
    when 'time.RFC3339' then '2006-01-02T15:04:05Z07:00'
    when 'time.Kitchen' then '3:04PM'
    when 'time.Second' then args[0].to_f
    when 'time.Minute' then args[0].to_f * 60
    when 'time.Hour' then args[0].to_f * 3600
    when 'not' then !truthy?(args[0])
    when 'and' then args.all? { |a| truthy?(a) }
    when 'or' then args.find { |a| truthy?(a) } || args[-1]
    when 'eq' then args.uniq.length == 1
    when 'ne' then args[0] != args[1]
    when 'lt' then args[0] < args[1]
    when 'le' then args[0] <= args[1]
    when 'gt' then args[0] > args[1]
    when 'ge' then args[0] >= args[1]
    when 'printf' then sprintf(args[0].to_s.gsub('%#v', '%p'), *args[1..])
    when 'print' then args.map { |a| stringify(a) }.join
    when 'println' then args.map { |a| stringify(a) }.join(' ') + "\n"
    when 'index' then args[1..].reduce(args[0]) { |o, k| access(o, k.to_s) }
    when 'len' then args[0].respond_to?(:length) ? args[0].length : 0
    else
      MISSING
    end
  end

  def function_name?(name)
    @funcs ||= %w[env.Env env.Getenv getenv env.HasEnv env.ExpandEnv add mul sub div mod math.Add math.Mul math.Sub math.Div math.Mod math.Abs math.Ceil math.Floor math.Round math.Max math.Min math.Pow math.Seq seq math.IsInt math.IsFloat coll.Slice slice coll.Dict dict coll.Has has coll.Keys coll.Values default conv.Default required join conv.Join bool conv.Bool conv.ToBool conv.ToString toString conv.ToInt conv.ToInt64 atoi conv.ToFloat conv.ToFloat64 data.JSON json data.YAML yaml data.ToJSON toJSON data.ToJSONPretty toJSONPretty data.ToYAML toYAML datasource ds include datasourceExists listDatasources defineDatasource base64.Encode base64.Decode base64.DecodeBytes strings.Contains strings.HasPrefix strings.HasSuffix strings.ToUpper upper strings.ToLower lower strings.Title title strings.Trim trim strings.TrimSpace strings.TrimPrefix strings.TrimSuffix strings.ReplaceAll strings.Replace strings.Split strings.Repeat strings.Indent indent strings.Quote strings.Abbrev regexp.Match regexp.Find regexp.FindAll regexp.Replace regexp.QuoteMeta file.Exists file.IsDir file.Read file.ReadDir filepath.Base path.Base filepath.Dir path.Dir filepath.Ext path.Ext filepath.Clean path.Clean filepath.IsAbs path.IsAbs filepath.Join path.Join net.LookupIP net.LookupIPs net.LookupCNAME uuid.New uuid crypto.SHA1 crypto.SHA256 crypto.MD5 time.Now time.Parse time.RFC3339 time.Kitchen time.Second time.Minute time.Hour not and or eq ne lt le gt ge printf print println index len]
    @funcs.include?(name)
  end

  def datasource(alias_name)
    target = @datasources[alias_name] || alias_name
    parse_data(raw_target(target), target)
  end

  def raw_datasource(alias_name)
    raw_target(@datasources[alias_name] || alias_name)
  end

  def raw_target(target)
    t = target.to_s
    return ENV[t.delete_prefix('env:///')].to_s if t.start_with?('env:///')
    path = t.start_with?('file://') ? URI(t).path : t
    File.read(path)
  end

  def parse_data(raw, target)
    case target
    when /\.(ya?ml)\z/i then YAML.safe_load(raw, aliases: true)
    when /\.json\z/i then JSON.parse(raw)
    else
      s = raw.strip
      return JSON.parse(s) if s.start_with?('{', '[')
      YAML.safe_load(raw, aliases: true)
    end
  rescue StandardError
    raw
  end

  def split_words(s)
    out = []
    cur = +''
    quote = nil
    depth = 0
    esc = false
    s.each_char do |ch|
      if quote
        cur << ch
        if esc
          esc = false
        elsif ch == '\\' && quote == '"'
          esc = true
        elsif ch == quote
          quote = nil
        end
      elsif ['"', "'", '`'].include?(ch)
        quote = ch
        cur << ch
      elsif ch == '('
        depth += 1
        cur << ch
      elsif ch == ')'
        depth -= 1
        cur << ch
      elsif ch =~ /\s/ && depth.zero?
        out << cur unless cur.empty?
        cur = +''
      else
        cur << ch
      end
    end
    out << cur unless cur.empty?
    out
  end

  def split_top(s, sep)
    out = []
    cur = +''
    quote = nil
    depth = 0
    s.each_char do |ch|
      if quote
        cur << ch
        quote = nil if ch == quote
      elsif ['"', "'", '`'].include?(ch)
        quote = ch
        cur << ch
      elsif ch == '('
        depth += 1
        cur << ch
      elsif ch == ')'
        depth -= 1
        cur << ch
      elsif ch == sep && depth.zero?
        out << cur.strip
        cur = +''
      else
        cur << ch
      end
    end
    out << cur.strip
  end

  def matching_paren(s, start)
    depth = 0
    quote = nil
    s.chars.each_with_index do |ch, i|
      next if i < start
      if quote
        quote = nil if ch == quote
      elsif ['"', "'", '`'].include?(ch)
        quote = ch
      elsif ch == '('
        depth += 1
      elsif ch == ')'
        depth -= 1
        return i if depth.zero?
      end
    end
    s.length - 1
  end

  def unescape(s)
    s.gsub(/\\n/, "\n").gsub(/\\"/, '"').gsub(/\\t/, "\t").gsub(/\\\\/, '\\')
  end

  def stringify(v)
    case v
    when MissingValue then v.to_s
    when nil then '<no value>'
    when true then 'true'
    when false then 'false'
    when Array then '[' + v.map { |x| stringify(x) }.join(' ') + ']'
    when Hash then 'map[' + v.map { |k, val| "#{k}:#{stringify(val)}" }.join(' ') + ']'
    when Float
      return '+Inf' if v.infinite? == 1
      return '-Inf' if v.infinite? == -1
      return 'NaN' if v.nan?
      v == v.to_i ? v.to_i.to_s : v.to_s
    else v.to_s
    end
  end

  def truthy?(v) = !(v.nil? || v == false || v == '' || v == [] || v == {} || v.equal?(MISSING))
  def empty?(v) = v.nil? || v.equal?(MISSING) || v == false || v == 0 || v == '' || v == [] || v == {}
  def getenv(k, d = '') = ENV.key?(k) ? ENV[k] : (ENV.key?("#{k}_FILE") && File.exist?(ENV["#{k}_FILE"]) ? File.read(ENV["#{k}_FILE"]).strip : d.to_s)
  def parse_int(s) = s =~ /\A-?0x/i ? s.to_i(16) : (s =~ /\A-?0[0-7]+\z/ ? s.to_i(8) : s.to_i)
  def to_num(v) = v.is_a?(Numeric) ? v : (v.to_s =~ /\A-?0x/i ? v.to_s.to_i(16) : v.to_s.to_f)
  def nums(a) = a.map { |x| to_num(x) }
  def numeric_reduce(a, init, op) = nums(a).then { |ns| ns.any? { |x| x.is_a?(Float) && x != x.to_i } ? ns.reduce(init.to_f, op) : ns.reduce(init, op).to_i }
  def sort_hash(v) = v.is_a?(Hash) ? v.keys.sort.to_h { |k| [k, sort_hash(v[k])] } : (v.is_a?(Array) ? v.map { |x| sort_hash(x) } : v)
  def intish?(v) = v.is_a?(Integer) || v.to_s =~ /\A-?(?:0x[0-9a-fA-F]+|0[0-7]+|\d+)\z/
  def floatish?(v) = v.is_a?(Float) || v.to_s =~ /(?:\.|e|NaN|Inf)/i

  def seq(start, finish = nil, step = nil)
    if finish.nil?
      finish = start
      start = 1
    end
    step ||= 1
    start = start.to_i
    finish = finish.to_i
    step = step.to_i
    return [] if step.zero?
    step = -step if finish < start && step.positive?
    step = -step if finish > start && step.negative?
    a = []
    i = start
    if step.positive?
      while i <= finish
        a << i
        i += step
      end
    else
      while i >= finish
        a << i
        i += step
      end
    end
    a
  end

  def abbrev(args)
    input = args[-1].to_s
    width = args[-2].to_i
    offset = args.length == 3 ? args[0].to_i : 0
    return input if input.length <= width
    return input[0, width - 3] + '...' if offset < 4
    '...' + input[offset, width - 6].to_s + '...'
  end

  def re_find_all(args)
    re = Regexp.new(args[0].to_s)
    input = args[-1].to_s
    n = args.length == 3 ? args[1].to_i : -1
    m = input.scan(re).map { |x| x.is_a?(Array) ? x[0] : x }
    n.negative? ? m : m.first(n)
  end
end

class CLI
  HELP = <<~HELP
    Process text files with Go templates

    Usage:
      gomplate [flags]

    Flags:
      -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.
      -H, --datasource-header header     HTTP header field in 'alias=Name: value' form to be provided on HTTP-based data sources. Multiples can be set.
      -c, --context datasource           pre-load a datasource into the context, in alias=URL form. Use the special alias `.` to set the root context.
          --plugin strings               plug in an external command as a function in name=path form. Can be specified multiple times
      -f, --file file                    Template file to process. Omit to use standard input, or use --in or --input-dir (default [-])
      -i, --in string                    Template string to process (alternative to --file and --input-dir)
          --input-dir directory          directory which is examined recursively for templates (alternative to --file and --in)
          --exclude strings              glob of files to not parse
          --exclude-processing strings   glob of files to be copied without parsing
          --include strings              glob of files to parse
      -o, --out file                     output file name. Omit to use standard output. (default [-])
      -t, --template strings             Additional template file(s)
          --output-dir directory         directory to store the processed templates. Only used for --input-dir (default ".")
          --output-map string            Template string to map the input file to an output path
          --chmod string                 set the mode for output file(s). Omit to inherit from input file(s)
          --exec-pipe                    pipe the output to the post-run exec command
          --left-delim delimiter         override the default left-delimiter [$GOMPLATE_LEFT_DELIM] (default "{{")
          --right-delim delimiter        override the default right-delimiter [$GOMPLATE_RIGHT_DELIM] (default "}}")
          --missing-key string           Control the behavior during execution if a map is indexed with a key that is not present in the map. error (default) - return an error, zero - fallback to zero value, default/invalid - print <no value> (default "error")
          --experimental                 enable experimental features [$GOMPLATE_EXPERIMENTAL]
      -V, --verbose                      output extra information about what gomplate is doing
          --config string                config file (overridden by commandline flags) (default ".gomplate.yaml")
      -h, --help                         help for gomplate
      -v, --version                      version for gomplate
  HELP

  def self.run(argv)
    opts = { files: [], outs: [], datasources: {}, contexts: [], templates: {}, output_dir: '.', includes: [], excludes: [], exclude_processing: [] }
    i = 0
    while i < argv.length
      a = argv[i]
      val = nil
      if a.include?('=') && a.start_with?('--')
        a, val = a.split('=', 2)
      end
      case a
      when '-h', '--help' then puts HELP; return 0
      when '-v', '--version' then puts 'gomplate version 0.0.0'; return 0
      when '-i', '--in' then opts[:in] = val || argv[i += 1]
      when '-f', '--file' then opts[:files] << (val || argv[i += 1])
      when '-o', '--out' then opts[:outs] << (val || argv[i += 1])
      when '-d', '--datasource' then add_ds(opts[:datasources], val || argv[i += 1])
      when '-H', '--datasource-header', '--plugin' then i += 1 unless val
      when '-c', '--context' then opts[:contexts] << (val || argv[i += 1])
      when '-t', '--template' then add_template(opts[:templates], val || argv[i += 1])
      when '--input-dir' then opts[:input_dir] = val || argv[i += 1]
      when '--output-dir' then opts[:output_dir] = val || argv[i += 1]
      when '--output-map' then opts[:output_map] = val || argv[i += 1]
      when '--include' then opts[:includes] << (val || argv[i += 1])
      when '--exclude' then opts[:excludes] << (val || argv[i += 1])
      when '--exclude-processing' then opts[:exclude_processing] << (val || argv[i += 1])
      when '--left-delim' then opts[:left] = val || argv[i += 1]
      when '--right-delim' then opts[:right] = val || argv[i += 1]
      when '--missing-key' then opts[:missing_key] = val || argv[i += 1]
      when '--chmod' then opts[:chmod] = (val || argv[i += 1]).to_i(8)
      when '--exec-pipe', '--experimental', '-V', '--verbose' then nil
      when '--config' then opts[:config] = val || argv[i += 1]
      else
        opts[:files] << a unless a.start_with?('-')
      end
      i += 1
    end
    load_config(opts)
    ctx = { 'Env' => ENV.to_h }
    r = Renderer.new(datasources: opts[:datasources], context: ctx, left: opts[:left], right: opts[:right], missing_key: opts[:missing_key])
    opts[:templates].each { |name, text| r.instance_variable_get(:@templates)[name] = r.tokenize(text) }
    opts[:contexts].each { |c| apply_context(r, ctx, c) }
    if opts[:input_dir]
      process_dir(r, opts)
    else
      inputs = opts[:in] ? [opts[:in]] : (opts[:files].empty? ? [STDIN.read] : opts[:files].map { |f| f == '-' ? STDIN.read : File.read(f) })
      inputs.each_with_index do |tmpl, idx|
        rendered = r.render(tmpl, ctx)
        out = opts[:outs][idx] || opts[:outs][0]
        if out && out != '-'
          FileUtils.mkdir_p(File.dirname(out))
          File.write(out, rendered)
          File.chmod(opts[:chmod], out) if opts[:chmod]
        else
          print rendered
        end
      end
    end
    0
  rescue StandardError => e
    warn e.message
    1
  end

  def self.add_ds(h, spec)
    if spec.include?('=')
      k, v = spec.split('=', 2)
      h[k] = v
    else
      base = File.basename(spec).sub(/\.[^.]+\z/, '')
      h[base] = spec
    end
  end

  def self.add_template(h, spec)
    k, v = spec.include?('=') ? spec.split('=', 2) : [File.basename(spec), spec]
    h[k] = File.directory?(v) ? Dir[File.join(v, '**/*')].select { |f| File.file?(f) }.map { |f| File.read(f) }.join("\n") : File.read(v)
  end

  def self.apply_context(renderer, ctx, spec)
    k, v = spec.include?('=') ? spec.split('=', 2) : [File.basename(spec).sub(/\.[^.]+\z/, ''), spec]
    renderer.datasources[k] = v
    data = renderer.datasource(k)
    if k == '.'
      ctx.replace(data.is_a?(Hash) ? data : { '.' => data })
    else
      ctx[k] = data
    end
  end

  def self.load_config(opts)
    path = opts[:config] || ENV['GOMPLATE_CONFIG'] || '.gomplate.yaml'
    return if path.nil? || path.empty? || !File.exist?(path)
    c = YAML.safe_load(File.read(path), aliases: true) || {}
    opts[:in] ||= c['in']
    opts[:input_dir] ||= c['inputDir'] || c['input-dir']
    opts[:output_dir] = c['outputDir'] || c['output-dir'] || opts[:output_dir]
    opts[:outs] << c['out'] if c['out'] && opts[:outs].empty?
    (c['datasources'] || {}).each { |k, v| opts[:datasources][k.to_s] = v.is_a?(Hash) ? v['url'].to_s : v.to_s }
    (c['context'] || {}).each { |k, v| opts[:contexts] << "#{k}=#{v.is_a?(Hash) ? v['url'] : v}" }
  rescue StandardError
    nil
  end

  def self.process_dir(renderer, opts)
    Dir.glob(File.join(opts[:input_dir], '**/*'), File::FNM_DOTMATCH).each do |path|
      next if File.directory?(path)
      rel = path.sub(%r{\A#{Regexp.escape(opts[:input_dir])}/?}, '')
      next if rel == '.' || excluded?(rel, opts[:excludes])
      next if !opts[:includes].empty? && !opts[:includes].any? { |p| File.fnmatch?(p, rel, File::FNM_PATHNAME) }
      out_rel = rel
      if opts[:output_map]
        map_ctx = renderer.instance_variable_get(:@context).merge('in' => rel, 'ctx' => renderer.instance_variable_get(:@context))
        out_rel = renderer.render(opts[:output_map], map_ctx).strip
        out_path = out_rel
      else
        out_path = File.join(opts[:output_dir], out_rel)
      end
      FileUtils.mkdir_p(File.dirname(out_path))
      if excluded?(rel, opts[:exclude_processing])
        FileUtils.cp(path, out_path)
      else
        File.write(out_path, renderer.render(File.read(path)))
      end
      File.chmod(opts[:chmod], out_path) if opts[:chmod]
    end
  end

  def self.excluded?(rel, pats)
    pats.any? { |p| File.fnmatch?(p, rel, File::FNM_PATHNAME) || File.fnmatch?(p, File.basename(rel)) }
  end
end

exit CLI.run(ARGV)
