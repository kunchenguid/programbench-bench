#!/usr/bin/env ruby
# frozen_string_literal: true

require 'fileutils'

HEADER = [
  '##################################################################',
  '# Content under this line is handled by hostctl. DO NOT EDIT.',
  '##################################################################'
].freeze

HELP = {
  nil => <<~TXT,

    hostctl is a CLI tool to manage your hosts file with ease.
    You can have multiple profiles, enable/disable exactly what
    you need each time with a simple interface.

    Usage:
      hostctl [command]

    Available Commands:
      add         Add content to a profile in your hosts file.
      backup      Creates a backup copy of your hosts file
      disable     Disable a profile from your hosts file.
      enable      Enable a profile on your hosts file.
      help        Help about any command
      list        Shows a detailed list of profiles on your hosts file.
      remove      Remove a profile from your hosts file.
      replace     Replace content to a profile in your hosts file.
      restore     Restore hosts file content from a backup file.
      status      Shows a list of profile names and statuses on your hosts file.
      sync        Sync some system IPs with a profile.
      toggle      Change status of a profile on your hosts file.

    Flags:
      -c, --column strings     Column names to show on lists. comma separated
      -h, --help               help for hostctl
          --host-file string   Hosts file path (default "/etc/hosts")
          --no-color           force colorless output
      -o, --out string         Output type (table|raw|markdown|json) (default "table")
      -q, --quiet              Run command without output
          --raw                Output without borders (same as -o raw)
      -v, --version            version for hostctl

    Use "hostctl [command] --help" for more information about a command.
  TXT
  'add' => <<~TXT,

    Reads from a file and set content to a profile in your hosts file.
    If the profile already exists it will be added to it.

    Usage:
      hostctl add [profiles] [flags]
      hostctl add [command]

    Available Commands:
      domains     Add content in your hosts file.

    Flags:
      -f, --from string     file to read
      -h, --help            help for add
      -w, --wait duration   Enables a profile for a specific amount of time. (example: 5m, 1h) (default -1ns)

    Global Flags:
      -c, --column strings     Column names to show on lists. comma separated
          --host-file string   Hosts file path (default "/etc/hosts")
          --no-color           force colorless output
      -o, --out string         Output type (table|raw|markdown|json) (default "table")
      -q, --quiet              Run command without output
          --raw                Output without borders (same as -o raw)
  TXT
  'status' => <<~TXT,

    Shows a list of unique profile names on your hosts file with its status.

    The "default" profile is always on and will be skipped.

    Usage:
      hostctl status [profiles] [flags]
  TXT
}

class HostsFile
  Entry = Struct.new(:profile, :status, :ip, :host, keyword_init: true)
  Profile = Struct.new(:name, :status, :entries, keyword_init: true)

  attr_reader :path, :prefix, :profiles

  def initialize(path)
    @path = path
    @prefix = []
    @profiles = []
    parse
  end

  def default_entries
    self.class.parse_entries_static(@prefix.join("\n"), 'default', 'on', first_only: true)
  end

  def status_rows(names = [])
    rows = @profiles.map { |p| Entry.new(profile: p.name, status: p.status, ip: '', host: '') }
    names.empty? ? rows : rows.select { |r| names.include?(r.profile) }
  end

  def list_rows(names = [], state = nil)
    rows = default_entries
    profs = @profiles
    profs = profs.select { |p| p.status == state } if state
    profs = profs.select { |p| names.include?(p.name) } unless names.empty?
    profs.each { |p| rows.concat(p.entries.map { |e| Entry.new(profile: p.name, status: p.status, ip: e.ip, host: e.host) }) }
    rows
  end

  def add_profile(name, entries, replace: false)
    p = @profiles.find { |x| x.name == name }
    if p && !replace
      p.entries.concat(entries)
      p.status = 'on'
    elsif p
      p.entries = entries
      p.status = 'on'
    else
      @profiles << Profile.new(name: name, status: 'on', entries: entries)
    end
  end

  def remove_profiles(names)
    if names == :all
      @profiles.clear
    else
      @profiles.reject! { |p| names.include?(p.name) }
    end
  end

  def set_status(names, status, all: false, only: false)
    @profiles.each do |p|
      if all || names.include?(p.name)
        p.status = status
      elsif only
        p.status = status == 'on' ? 'off' : 'on'
      end
    end
  end

  def toggle(names)
    @profiles.each { |p| p.status = (p.status == 'on' ? 'off' : 'on') if names.include?(p.name) }
  end

  def remove_domains(profile, domains)
    removed = []
    if (p = @profiles.find { |x| x.name == profile })
      before = p.entries.length
      p.entries.reject! { |e| domains.include?(e.host) && removed << e.host }
      @profiles.delete(p) if p.entries.empty? && before.positive?
    end
    removed.uniq
  end

  def save
    out = []
    out.concat(trim_trailing_blank(@prefix))
    out << '' unless out.empty? && @profiles.empty?
    out.concat(HEADER)
    out << '' unless @profiles.empty?
    @profiles.each_with_index do |p, idx|
      out << '' if idx.positive?
      out << "# profile.#{p.status} #{p.name}"
      p.entries.each do |e|
        line = "#{e.ip} #{e.host}"
        line = "# #{line}" if p.status == 'off'
        out << line
      end
      out << '# end'
    end
    File.write(@path, out.join("\n") + "\n")
  end

  def self.entries_from_file(path)
    text = File.read(path)
    parse_entries_static(text, nil, 'on')
  end

  def self.entries_from_domains(domains, ip)
    domains.map { |d| Entry.new(profile: nil, status: 'on', ip: ip, host: d) }
  end

  private

  def parse
    lines = File.exist?(@path) ? File.read(@path).split(/\n/, -1) : []
    lines.pop if lines.last == ''
    idx = lines.index(HEADER[0])
    if idx && lines[idx, 3] == HEADER
      @prefix = lines[0...idx]
      parse_managed(lines[(idx + 3)..] || [])
    else
      @prefix = lines
    end
  end

  def parse_managed(lines)
    cur = nil
    lines.each do |line|
      if line =~ /^# profile\.(on|off)\s+(.+)$/
        cur = Profile.new(name: Regexp.last_match(2).strip, status: Regexp.last_match(1), entries: [])
        @profiles << cur
      elsif line == '# end'
        cur = nil
      elsif cur
        clean = line.sub(/^#\s*/, '')
        fields = clean.split(/\s+/)
        next if fields.length < 2
        fields[1..].each { |h| cur.entries << Entry.new(profile: cur.name, status: cur.status, ip: fields[0], host: h) }
      end
    end
  end

  def self.parse_entries_static(text, profile, status, first_only: false)
    entries = []
    text.each_line do |line|
      s = line.strip
      next if s.empty? || s.start_with?('#')
      s = s.sub(/\s+#.*$/, '')
      fields = s.split(/\s+/)
      next if fields.length < 2
      hosts = first_only ? [fields[1]] : fields[1..]
      hosts.each { |h| entries << Entry.new(profile: profile, status: status, ip: fields[0], host: h) }
    end
    entries
  end

  def trim_trailing_blank(lines)
    a = lines.dup
    a.pop while a.last == ''
    a
  end
end

class App
  def initialize(argv)
    @argv = argv.dup
    @opts = { host_file: '/etc/hosts', out: 'table', quiet: false, columns: nil }
    @cmd_opts = {}
    @args = []
    parse_args
  end

  def run
    if @opts[:version]
      puts 'hostctl version dev'
      return
    end
    if @opts[:help] || @command == 'help'
      puts HELP[@args.first] || HELP[@command] || HELP[nil]
      return
    end
    unless %w[add backup disable enable list remove replace restore status sync toggle rm].include?(@command.to_s)
      err %(unknown command "#{@command}" for "hostctl")
      return
    end
    @command = 'remove' if @command == 'rm'
    @hosts = HostsFile.new(@opts[:host_file])
    dispatch
  rescue Errno::ENOENT => e
    info
    err e.message
  rescue StandardError => e
    err e.message
  end

  private

  def dispatch
    case @command
    when 'add' then cmd_add
    when 'replace' then cmd_replace
    when 'status' then output(@hosts.status_rows(@args))
    when 'list' then cmd_list
    when 'enable' then cmd_enable_disable('on')
    when 'disable' then cmd_enable_disable('off')
    when 'toggle' then cmd_toggle
    when 'remove' then cmd_remove
    when 'backup' then cmd_backup
    when 'restore' then cmd_restore
    when 'sync' then cmd_sync
    end
  end

  def cmd_add
    if @args.first == 'domains' || @args.first == 'domain'
      @args.shift
      profile = @args.shift
      entries = HostsFile.entries_from_domains(@args, @cmd_opts[:ip] || '127.0.0.1')
    else
      profile = @args.shift
      entries = HostsFile.entries_from_file(@cmd_opts[:from])
    end
    @hosts.add_profile(profile, entries)
    @hosts.save
    output(@hosts.list_rows([profile]).reject { |r| r.profile == 'default' })
  end

  def cmd_replace
    profile = @args.shift
    entries = HostsFile.entries_from_file(@cmd_opts[:from])
    @hosts.add_profile(profile, entries, replace: true)
    @hosts.save
    output(@hosts.list_rows([profile]).reject { |r| r.profile == 'default' })
  end

  def cmd_list
    state = nil
    if @args.first == 'enabled'
      @args.shift
      state = 'on'
    elsif @args.first == 'disabled'
      @args.shift
      state = 'off'
    end
    output(@hosts.list_rows(@args, state))
  end

  def cmd_enable_disable(status)
    names = @args
    @hosts.set_status(names, status, all: @cmd_opts[:all], only: @cmd_opts[:only])
    @hosts.save
    rows = @cmd_opts[:all] ? @hosts.list_rows([], status) : @hosts.list_rows(names).reject { |r| r.profile == 'default' }
    output(rows)
  end

  def cmd_toggle
    @hosts.toggle(@args)
    @hosts.save
    output(@hosts.list_rows(@args).reject { |r| r.profile == 'default' })
  end

  def cmd_remove
    if @args.first == 'domains' || @args.first == 'domain'
      @args.shift
      profile = @args.shift
      removed = @hosts.remove_domains(profile, @args)
      @hosts.save
      info
      say "[✔] Domains '#{removed.join(',')}' removed." unless removed.empty?
      rows = @hosts.list_rows([profile]).reject { |r| r.profile == 'default' }
      render(rows) unless rows.empty?
    else
      targets = @cmd_opts[:all] ? :all : @args
      @hosts.remove_profiles(targets)
      @hosts.save
      info
      say "[✔] Profile(s) '#{@cmd_opts[:all] ? 'all' : @args.join(',')}' removed."
      puts unless @opts[:quiet] || json?
    end
  end

  def cmd_backup
    info
    path = @cmd_opts[:path] || Dir.pwd
    FileUtils.mkdir_p(path)
    dest = File.join(path, "#{File.basename(@opts[:host_file])}.#{Time.now.strftime('%Y%m%d')}")
    FileUtils.cp(@opts[:host_file], dest)
    say "[✔] Backup '#{dest}' created."
    puts unless @opts[:quiet] || json?
    render(@hosts.list_rows)
  end

  def cmd_restore
    src = @cmd_opts[:from]
    FileUtils.cp(src, @opts[:host_file])
    @hosts = HostsFile.new(@opts[:host_file])
    output(@hosts.list_rows)
  end

  def cmd_sync
    sub = @args.shift
    profile = @args.shift || sub || 'default'
    entries = []
    if sub == 'docker-compose'
      file = @cmd_opts[:compose_file] || 'docker-compose.yml'
      domain = @cmd_opts[:domain] || 'loc'
      in_services = false
      File.readlines(file).each do |line|
        if line =~ /^services:\s*$/
          in_services = true
          next
        end
        next unless in_services
        break if line =~ /^\S/ && line !~ /^services:/
        entries << HostsFile::Entry.new(ip: '127.0.0.1', host: "#{Regexp.last_match(1)}.#{domain}") if line =~ /^\s{2}([A-Za-z0-9_.-]+):\s*$/
      end
    end
    @hosts.add_profile(profile, entries, replace: true)
    @hosts.save
    output(@hosts.list_rows([profile]).reject { |r| r.profile == 'default' })
  end

  def parse_args
    while (tok = @argv.shift)
      case tok
      when '-h', '--help' then @opts[:help] = true
      when '-v', '--version' then @opts[:version] = true
      when '--host-file' then @opts[:host_file] = @argv.shift
      when /^--host-file=(.*)$/ then @opts[:host_file] = Regexp.last_match(1)
      when '-o', '--out' then @opts[:out] = @argv.shift
      when /^--out=(.*)$/ then @opts[:out] = Regexp.last_match(1)
      when '--raw' then @opts[:out] = 'raw'
      when '-q', '--quiet' then @opts[:quiet] = true
      when '--no-color' then next
      when '-c', '--column' then @opts[:columns] = (@argv.shift || '').split(',')
      when /^--column=(.*)$/ then @opts[:columns] = Regexp.last_match(1).split(',')
      when '-f', '--from' then @cmd_opts[:from] = @argv.shift
      when /^--from=(.*)$/ then @cmd_opts[:from] = Regexp.last_match(1)
      when '--path' then @cmd_opts[:path] = @argv.shift
      when /^--path=(.*)$/ then @cmd_opts[:path] = Regexp.last_match(1)
      when '--ip' then @cmd_opts[:ip] = @argv.shift
      when /^--ip=(.*)$/ then @cmd_opts[:ip] = Regexp.last_match(1)
      when '--all' then @cmd_opts[:all] = true
      when '--only' then @cmd_opts[:only] = true
      when '-w', '--wait' then @argv.shift
      when '-d', '--domain' then @cmd_opts[:domain] = @argv.shift
      when '--compose-file' then @cmd_opts[:compose_file] = @argv.shift
      when '--network', '--project-name' then @argv.shift
      when '--prefix' then next
      when /^-/ then raise "unknown flag: #{tok}"
      else
        if @command.nil?
          @command = tok
        else
          @args << tok
        end
      end
    end
  end

  def output(rows)
    info
    render(rows)
  end

  def info
    return if @opts[:quiet] || json?
    puts "[ℹ] Using hosts file: #{@opts[:host_file]}"
    puts
  end

  def say(msg)
    puts msg unless @opts[:quiet] || json?
  end

  def err(msg)
    puts "[✖] error: #{msg}" unless @opts[:quiet]
  end

  def json?
    @opts[:out] == 'json'
  end

  def render(rows)
    return if @opts[:quiet]
    cols = columns_for(rows)
    case @opts[:out]
    when 'json'
      puts '[' + rows.map { |r|
        '{"Profile":"' + json_escape(r.profile) + '","Status":"' + json_escape(r.status) +
          '","IP":"' + json_escape(r.ip.to_s) + '","Host":"' + json_escape(r.host.to_s) + '"}'
      }.join(',') + ']'
    when 'raw'
      render_raw(rows, cols)
    when 'markdown'
      render_markdown(rows, cols)
    else
      render_table(rows, cols)
    end
  end

  def columns_for(rows)
    wanted = @opts[:columns]&.map(&:downcase)
    base = rows.any? { |r| !r.ip.to_s.empty? || !r.host.to_s.empty? } ? %w[profile status ip domain] : %w[profile status]
    base = base.select { |c| wanted.include?(c) || (c == 'domain' && wanted.include?('host')) } if wanted
    base
  end

  def value(row, col)
    case col
    when 'profile' then row.profile
    when 'status' then row.status
    when 'ip' then row.ip
    when 'domain' then row.host
    end.to_s
  end

  def widths(rows, cols)
    cols.map do |c|
      ([header(c).length] + rows.map { |r| value(r, c).length }).max
    end
  end

  def header(col)
    col == 'ip' ? 'IP' : col.upcase
  end

  def render_table(rows, cols)
    w = widths(rows, cols)
    sep = '+' + w.map { |n| '-' * (n + 2) }.join('+') + '+'
    puts sep
    puts '|' + cols.each_with_index.map { |c, i| cell(header(c), w[i], center: true) }.join('|') + '|'
    puts sep
    last = nil
    rows.each do |r|
      puts sep if last && last != r.profile
      puts '|' + cols.each_with_index.map { |c, i| cell(value(r, c), w[i]) }.join('|') + '|'
      last = r.profile
    end
    puts sep
  end

  def cell(s, width, center: false)
    if center
      l = (width - s.length) / 2
      r = width - s.length - l
      ' ' + (' ' * l) + s + (' ' * r) + ' '
    else
      ' ' + s.ljust(width) + ' '
    end
  end

  def render_raw(rows, cols)
    w = widths(rows, cols)
    puts cols.each_with_index.map { |c, i| header(c).ljust(w[i]) }.join("\t") + ' '
    rows.each { |r| puts cols.each_with_index.map { |c, i| value(r, c).ljust(w[i]) }.join("\t") + "\t" }
  end

  def render_markdown(rows, cols)
    w = widths(rows, cols)
    puts '|' + cols.each_with_index.map { |c, i| cell(header(c), w[i], center: true).strip.center(w[i] + 2) }.join('|') + '|'
    sep = '|' + w.map { |n| '-' * (n + 2) }.join('|') + '|'
    puts sep
    last = nil
    rows.each do |r|
      puts sep if last && last != r.profile
      puts '|' + cols.each_with_index.map { |c, i| cell(value(r, c), w[i]).strip.ljust(w[i] + 2) }.join('|') + '|'
      last = r.profile
    end
  end

  def json_escape(str)
    str.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
      { '"' => '\"', '\\' => '\\\\', "\b" => '\b', "\f" => '\f', "\n" => '\n', "\r" => '\r', "\t" => '\t' }[ch]
    end
  end
end

App.new(ARGV).run
