#!/usr/bin/env ruby
# frozen_string_literal: true

Node = Struct.new(:name, :path, :size, :directory, :children)

HELP = <<~TEXT
  Usage: ./executable [options] <path> [<path>..]

  Options:
      -d, --depth [DEPTH] show directories up to depth N (def 1)
      -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)
      -s, --summary       equivalent to -da, or -d1 -a1M
      -u, --usage         report real disk usage instead of file size
      -b, --bytes         print sizes in bytes
      -f, --files-only    skip directories for a fast local overview
      -x, --exclude NAME  exclude matching files or directories
      -H, --no-hidden     exclude hidden files
      -A, --ascii         ASCII characters only, no colors
      -h, --help          show help
      -v, --version       print version number
TEXT

class Dutree
  attr_reader :opts, :paths

  def initialize(argv)
    @opts = {
      depth: nil,
      aggr: nil,
      usage: false,
      bytes: false,
      files_only: false,
      excludes: [],
      no_hidden: false,
      ascii: false
    }
    @paths = []
    parse(argv)
  end

  def parse(argv)
    i = 0
    while i < argv.length
      arg = argv[i]
      case arg
      when '-h', '--help'
        puts HELP
        exit 0
      when '-v', '--version'
        puts 'dutree version 0.2.18'
        exit 0
      when '-s', '--summary'
        @opts[:depth] = 1
        @opts[:aggr] = 1024 * 1024
      when '-u', '--usage'
        @opts[:usage] = true
      when '-b', '--bytes'
        @opts[:bytes] = true
      when '-f', '--files-only'
        @opts[:files_only] = true
      when '-H', '--no-hidden'
        @opts[:no_hidden] = true
      when '-A', '--ascii'
        @opts[:ascii] = true
      when '-d', '--depth'
        if argv[i + 1] && argv[i + 1] !~ /^-/
          i += 1
          @opts[:depth] = argv[i].to_i
        else
          @opts[:depth] = 1
        end
      when /\A-d(.+)/
        @opts[:depth] = Regexp.last_match(1).to_i
      when /\A--depth=(.*)/
        @opts[:depth] = Regexp.last_match(1).to_i
      when '-a', '--aggr'
        if argv[i + 1] && argv[i + 1] !~ /^-/
          i += 1
          val = parse_size(argv[i])
          invalid(argv[i]) if val.nil?
          @opts[:aggr] = val
        else
          @opts[:aggr] = 1024 * 1024
        end
      when /\A-a(.+)/
        val = parse_size(Regexp.last_match(1))
        invalid(Regexp.last_match(1)) if val.nil?
        @opts[:aggr] = val
      when /\A--aggr=(.*)/
        val = parse_size(Regexp.last_match(1))
        invalid(Regexp.last_match(1)) if val.nil?
        @opts[:aggr] = val
      when '-x', '--exclude'
        i += 1
        @opts[:excludes] << argv[i].to_s
      when /\A--exclude=(.*)/
        @opts[:excludes] << Regexp.last_match(1)
      else
        if arg.start_with?('--')
          puts HELP
          puts "Unrecognized option: '#{arg.sub(/\A--/, '')}'"
        elsif arg.start_with?('-') && arg.length > 1
          arg[1..].chars.each do |ch|
            case ch
            when 'u' then @opts[:usage] = true
            when 'b' then @opts[:bytes] = true
            when 'f' then @opts[:files_only] = true
            when 'H' then @opts[:no_hidden] = true
            when 'A' then @opts[:ascii] = true
            when 'd' then @opts[:depth] = 1
            when 'a' then @opts[:aggr] = 1024 * 1024
            when 's'
              @opts[:depth] = 1
              @opts[:aggr] = 1024 * 1024
            end
          end
        else
          @paths << arg
        end
      end
      i += 1
    end
    @paths = ['.'] if @paths.empty?
  end

  def invalid(value)
    puts "invalid argument '#{value}'"
    exit 0
  end

  def parse_size(s)
    return nil unless s =~ /\A(\d+)([KMGkmg]?)\z/

    n = Regexp.last_match(1).to_i
    case Regexp.last_match(2).upcase
    when 'K' then n * 1024
    when 'M' then n * 1024 * 1024
    when 'G' then n * 1024 * 1024 * 1024
    else n
    end
  end

  def run
    roots = @paths.filter_map do |path|
      unless File.exist?(path)
        puts "path #{path} doesn't exist"
        next
      end
      scan(path)
    end
    return if roots.empty?

    root = if roots.length == 1
             roots.first
           else
             Node.new('<collection>', nil, roots.sum(&:size), true, roots.sort_by { |n| [-n.size, n.name] })
           end
    puts "[ #{root.name} #{format_size(root.size)} ]"
    print_children(root, '', root.size, @opts[:depth], nil)
  end

  def excluded_name?(name)
    @opts[:excludes].include?(name) || (@opts[:no_hidden] && name.start_with?('.'))
  end

  def scan(path)
    st = File.lstat(path)
    name = File.basename(path)
    if st.directory?
      children = []
      Dir.children(path).each do |child|
        next if excluded_name?(child)

        child_path = File.join(path, child)
        begin
          child_st = File.lstat(child_path)
          next if @opts[:files_only] && child_st.directory?

          children << scan(child_path)
        rescue SystemCallError
          nil
        end
      end
      own = size_of(st)
      total = own + children.sum(&:size)
      Node.new(name, path, total, true, children.sort_by { |n| [-n.size, n.name] })
    else
      Node.new(name, path, size_of(st), false, [])
    end
  rescue SystemCallError
    Node.new(File.basename(path), path, 0, false, [])
  end

  def size_of(st)
    @opts[:usage] ? st.blocks.to_i * 512 : st.size.to_i
  end

  def visible_children(node, depth_left)
    return [] if depth_left == 0

    items = node.children || []
    threshold = @opts[:aggr]
    if threshold
      kept = []
      aggr = 0
      items.each do |child|
        if child.size < threshold
          aggr += child.size
        else
          kept << child
        end
      end
      kept << Node.new('<aggregated>', nil, aggr, false, []) if aggr.positive?
      items = kept.sort_by { |n| [-n.size, n.name] }
    end
    items
  end

  def print_children(node, prefix, parent_size, depth_left, parent_bar)
    items = visible_children(node, depth_left)
    return if items.empty?

    max_size = items.map(&:size).max.to_f
    items.each_with_index do |child, idx|
      last = idx == items.length - 1
      line_prefix = prefix + (last ? '└─ ' : '├─ ')
      bar_hashes = bar_hash_count(child, parent_size, max_size)
      bar_hashes = parent_bar if items.length == 1 && !parent_bar.nil?
      puts row(line_prefix, child, parent_size, bar_hashes)
      next_depth = depth_left.nil? ? nil : depth_left - 1
      next if next_depth == 0

      child_prefix = prefix + (last ? '   ' : '│  ')
      print_children(child, child_prefix, child.size, next_depth, bar_hashes)
    end
  end

  def bar_hash_count(node, parent_size, max_size)
    ratio = max_size.zero? ? 0.0 : node.size.to_f / max_size
    hashes = [(ratio * 32).floor, 32].min
    hashes = 32 if node.size.positive? && hashes.zero? && max_size == node.size
    hashes = 0 if node.size < 1024 && parent_size > 1024
    hashes
  end

  def row(prefix, node, parent_size, hashes)
    label_width = [26 - prefix.length, 1].max
    name = node.name[0, label_width]
    label = prefix + name.ljust(label_width)
    pct = parent_size.to_i.zero? ? 0 : ((node.size.to_f * 100.0) / parent_size).floor
    bar = ' ' * (32 - hashes) + '#' * hashes
    "#{label}│ #{bar}│ #{pct.to_s.rjust(3)}% #{format_size(node.size).rjust(13)}"
  end

  def format_size(n)
    return "#{n} B" if @opts[:bytes]
    return "#{n} B" if n < 1024

    units = [%w[GiB 1073741824], %w[MiB 1048576], %w[KiB 1024]]
    unit, div = units.find { |_u, d| n >= d.to_i }
    format('%.2f %s', n.to_f / div.to_i, unit)
  end
end

Dutree.new(ARGV).run
