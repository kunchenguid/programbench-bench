#!/usr/bin/env ruby
# frozen_string_literal: true

USAGE = <<~TEXT
  usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] 
      -s            Show seconds                                   
      -S            Screensaver mode                               
      -x            Show box                                       
      -c            Set the clock at the center of the terminal    
      -C [0-7]      Set the clock color                            
      -b            Use bold colors                                
      -t            Set the hour in 12h format                     
      -u            Use UTC time                                   
      -T tty        Display the clock on the specified terminal    
      -r            Do rebound the clock                           
      -f format     Set the date format                            
      -n            Don't quit on keypress                         
      -v            Show tty-clock version                         
      -i            Show some info about tty-clock                 
      -h            Show this page                                 
      -D            Hide date                                      
      -B            Enable blinking colon                          
      -d delay      Set the delay between two redraws of the clock. Default 1s. 
      -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns.
TEXT

VERSION = "TTY-Clock 2 © devel version"
INFO = "TTY-Clock 2 © by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)"

GLYPHS = {
  "0" => [" #### ", "##  ##", "##  ##", "##  ##", " #### "],
  "1" => ["  ##  ", " ###  ", "  ##  ", "  ##  ", "######"],
  "2" => [" #### ", "##  ##", "   ## ", "  ##  ", "######"],
  "3" => [" #### ", "    ##", "  ### ", "    ##", " #### "],
  "4" => ["##  ##", "##  ##", "######", "    ##", "    ##"],
  "5" => ["######", "##    ", "##### ", "    ##", "##### "],
  "6" => [" #### ", "##    ", "##### ", "##  ##", " #### "],
  "7" => ["######", "    ##", "   ## ", "  ##  ", " ##   "],
  "8" => [" #### ", "##  ##", " #### ", "##  ##", " #### "],
  "9" => [" #### ", "##  ##", " #####", "    ##", " #### "],
  ":" => ["      ", "  ##  ", "      ", "  ##  ", "      "],
  " " => ["      ", "      ", "      ", "      ", "      "],
  "A" => [" #### ", "##  ##", "######", "##  ##", "##  ##"],
  "P" => ["##### ", "##  ##", "##### ", "##    ", "##    "],
  "M" => ["##  ##", "######", "######", "##  ##", "##  ##"]
}.freeze

class TtyClock
  attr_reader :opts

  def initialize(argv, out = $stdout, err = $stderr)
    @argv = argv.dup
    @out = out
    @err = err
    @opts = {
      seconds: false, screensaver: false, box: false, center: false,
      color: 2, bold: false, twelve: false, utc: false, rebound: false,
      format: "%F", noquit: false, version: false, info: false, help: false,
      hide_date: false, blink: false, delay: 1.0, nsdelay: 0, tty: nil
    }
  end

  def run
    return 0 unless parse
    return print_and_exit(VERSION) if opts[:version]
    return print_and_exit(INFO) if opts[:info]
    return print_and_exit(USAGE, raw: true) if opts[:help]

    if opts[:tty]
      begin
        st = File.stat(opts[:tty])
        unless st.chardev?
          @err.puts "tty-clock: error: '#{opts[:tty]}' doesn't appear to be a character device."
          return 1
        end
      rescue SystemCallError => e
        @err.puts "tty-clock: error: couldn't stat '#{opts[:tty]}': #{e.class::Errno == 2 ? 'No such file or directory' : e.message.split(' - ').first}."
        return 1
      end
    end

    if ENV.fetch("TERM", nil).to_s.empty? || ENV["TERM"] == "unknown"
      @err.puts "Error opening terminal: unknown."
      return 1
    end

    display_loop
    0
  end

  private

  def print_and_exit(text, raw: false)
    raw ? @out.print(text) : @out.puts(text)
    0
  end

  def parse
    i = 0
    while i < @argv.length
      arg = @argv[i]
      if arg.start_with?("--")
        invalid("-")
        return false
      elsif arg.start_with?("-") && arg.length > 1
        chars = arg[1..].chars
        until chars.empty?
          c = chars.shift
          case c
          when "s" then opts[:seconds] = true
          when "S" then opts[:screensaver] = true
          when "x" then opts[:box] = true
          when "c" then opts[:center] = true
          when "b" then opts[:bold] = true
          when "t" then opts[:twelve] = true
          when "u" then opts[:utc] = true
          when "r" then opts[:rebound] = true
          when "n" then opts[:noquit] = true
          when "v" then opts[:version] = true
          when "i" then opts[:info] = true
          when "h" then opts[:help] = true
          when "D" then opts[:hide_date] = true
          when "B" then opts[:blink] = true
          when "C", "f", "d", "a", "T"
            val = chars.empty? ? @argv[i += 1] : chars.join
            if val.nil?
              @err.puts "./executable: option requires an argument -- '#{c}'"
              @out.print USAGE
              return false
            end
            chars.clear
            assign_option(c, val)
          else
            invalid(c)
            return false
          end
        end
      end
      i += 1
    end
    true
  end

  def invalid(c)
    @err.puts "./executable: invalid option -- '#{c}'"
    @out.print USAGE
  end

  def assign_option(c, val)
    case c
    when "C" then opts[:color] = val.to_i
    when "f" then opts[:format] = val
    when "d" then opts[:delay] = val.to_f
    when "a" then opts[:nsdelay] = val.to_i
    when "T" then opts[:tty] = val
    end
  end

  def display_loop
    target = opts[:tty] ? File.open(opts[:tty], "w") : @out
    @out = target
    trap_signals
    enter_screen
    x = 1
    y = 1
    dx = 1
    dy = 1
    loop do
      rows, cols = terminal_size
      frame = build_frame
      height = frame.length
      width = frame.map(&:length).max || 0
      if opts[:center]
        y = [(rows - height) / 2 + 1, 1].max
        x = [(cols - width) / 2 + 1, 1].max
      elsif opts[:rebound]
        x += dx
        y += dy
        if x <= 1 || x + width >= cols
          dx *= -1
          x = [[x, 1].max, [cols - width, 1].max].min
        end
        if y <= 1 || y + height >= rows
          dy *= -1
          y = [[y, 1].max, [rows - height, 1].max].min
        end
      end
      draw(frame, x, y)
      sleep_time = opts[:delay].to_f + (opts[:nsdelay].to_f / 1_000_000_000.0)
      sleep(sleep_time.positive? ? sleep_time : 0.1)
    end
  ensure
    leave_screen
    target&.close if opts[:tty] && target && !target.closed?
  end

  def trap_signals
    %w[INT TERM HUP].each do |sig|
      Signal.trap(sig) { leave_screen; exit 0 }
    rescue ArgumentError
      next
    end
  end

  def terminal_size
    size = `stty size 2>/dev/null`.split.map(&:to_i)
    return size if size.length == 2 && size.all?(&:positive?)

    [24, 80]
  end

  def now
    t = Time.now
    opts[:utc] ? t.getutc : t
  end

  def time_text(t)
    if opts[:twelve]
      text = t.strftime(opts[:seconds] ? "%I:%M:%S" : "%I:%M")
      suffix = t.hour >= 12 ? " PM" : " AM"
      text.sub(/^0/, " ") + suffix
    else
      t.strftime(opts[:seconds] ? "%H:%M:%S" : "%H:%M")
    end
  end

  def build_frame
    t = now
    rows = Array.new(5) { "" }
    time_text(t).each_char do |ch|
      glyph = GLYPHS.fetch(ch, GLYPHS[" "])
      5.times { |i| rows[i] += glyph[i] + " " }
    end

    date = opts[:hide_date] ? nil : safe_strftime(t, opts[:format])
    lines = colorize_rows(rows)
    lines << colorize(date, 2) if date && !date.empty?
    opts[:box] ? boxed(lines) : lines
  end

  def safe_strftime(t, fmt)
    t.strftime(fmt)
  rescue ArgumentError
    fmt
  end

  def colorize_rows(rows)
    rows.map do |row|
      rendered = row.each_char.map do |ch|
        ch == "#" ? "\e[4#{color_code}m  \e[49m" : "  "
      end.join
      colorize(rendered, opts[:color], wrap: false)
    end
  end

  def color_code
    opts[:color].between?(0, 7) ? opts[:color] : 2
  end

  def colorize(text, color, wrap: true)
    prefix = opts[:bold] ? "\e[1m" : ""
    prefix += "\e[5m" if opts[:blink]
    prefix += "\e[3#{color.between?(0, 7) ? color : 2}m" if wrap
    "#{prefix}#{text}\e[0m"
  end

  def boxed(lines)
    plain_width = lines.map { |l| strip_ansi(l).length }.max || 0
    top = "\e(0l#{"q" * (plain_width + 2)}k\e(B"
    bottom = "\e(0m#{"q" * (plain_width + 2)}j\e(B"
    body = lines.map { |line| "\e(0x\e(B #{line}#{' ' * (plain_width - strip_ansi(line).length)} \e(0x\e(B" }
    [top, *body, bottom]
  end

  def strip_ansi(s)
    s.gsub(/\e\[[0-9;?]*[A-Za-z]/, "").gsub(/\e\([A-Za-z0-9]/, "")
  end

  def enter_screen
    @out.print "\e[?1049h\e[?25l\e[H\e[2J"
    @out.flush
  end

  def leave_screen
    return if @left

    @left = true
    @out.print "\e[0m\e[?25h\e[?1049l"
    @out.flush
  rescue IOError
    nil
  end

  def draw(lines, x, y)
    @out.print "\e[H\e[2J"
    lines.each_with_index do |line, idx|
      @out.print "\e[#{y + idx};#{x}H#{line}"
    end
    @out.flush
  end
end

exit TtyClock.new(ARGV).run
