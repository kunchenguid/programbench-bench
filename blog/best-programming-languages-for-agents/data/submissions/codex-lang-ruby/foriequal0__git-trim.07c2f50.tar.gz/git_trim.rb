#!/usr/bin/env ruby
# frozen_string_literal: true

require "English"

HELP_LONG = <<~HELP
  Automatically trims your tracking branches whose upstream branches are merged or stray.
  `git-trim` is a missing companion to the `git fetch --prune` and a proper, safer, faster alternative to your `<bash oneliner HERE>`.

  Usage: executable [OPTIONS]

  Options:
    -b, --bases <BASES>
            Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]
            
            The default value is a branch that tracks `git symbolic-ref refs/remotes/*/HEAD`. They might not be reflected correctly when the HEAD branch of your remote repository is changed. You can see the changed HEAD branch name with `git remote show <remote>` and apply it to your local repository with `git remote set-head <remote> --auto`.

    -p, --protected <PROTECTED>
            Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]

        --no-update
            Do not update remotes [config: trim.update]

        --update-interval <UPDATE_INTERVAL>
            Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]

        --no-confirm
            Do not ask confirm [config: trim.confirm]

        --no-detach
            Do not detach when HEAD is about to be deleted [config: trim.detach]

    -d, --delete <DELETE>
            Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]
            
            `merged` implies `merged-local,merged-remote`.
            
            `merged-local` will delete merged tracking local branches. `merged-remote:<remote>` will delete merged upstream branches from `<remote>`. `stray` will delete tracking local branches, which is not merged, but the upstream is gone. `diverged:<remote>` will delete merged tracking local branches, and their upstreams from `<remote>` even if the upstreams are not merged and diverged from local ones. `local` will delete non-tracking merged local branches. `remote:<remote>` will delete non-upstream merged remote tracking branches. Use with caution when you are using other than `merged`. It might lose changes, and even nuke repositories.

        --dry-run
            Do not delete branches, show what branches will be deleted

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version
HELP

HELP_SHORT = <<~HELP
  Automatically trims your tracking branches whose upstream branches are merged or stray.

  Usage: executable [OPTIONS]

  Options:
    -b, --bases <BASES>
            Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]
    -p, --protected <PROTECTED>
            Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]
        --no-update
            Do not update remotes [config: trim.update]
        --update-interval <UPDATE_INTERVAL>
            Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]
        --no-confirm
            Do not ask confirm [config: trim.confirm]
        --no-detach
            Do not detach when HEAD is about to be deleted [config: trim.detach]
    -d, --delete <DELETE>
            Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]
        --dry-run
            Do not delete branches, show what branches will be deleted
    -h, --help
            Print help (see more with '--help')
    -V, --version
            Print version
HELP

Ref = Struct.new(:name, :sha, :upstream, :remote, :gone, keyword_init: true)

def run_git(*args, capture: true, ok: true)
  if capture
    out = IO.popen(["git", *args], err: [:child, :out], &:read)
    st = $CHILD_STATUS.exitstatus
    raise out.strip if ok && st != 0
    [out, st]
  else
    system("git", *args)
    st = $CHILD_STATUS.exitstatus
    raise "git #{args.join(' ')} failed" if ok && st != 0
    st
  end
end

def git_out(*args)
  run_git(*args).first
end

def config(name)
  out, st = run_git("config", "--get", name, ok: false)
  st.zero? ? out.strip : nil
end

def bool_config(name)
  v = config(name)
  return nil if v.nil? || v.empty?
  %w[true yes on 1].include?(v.downcase)
end

def split_csv(value)
  return [] if value.nil? || value.empty?
  value.split(",").map(&:strip).reject(&:empty?)
end

def die_cli(msg)
  warn msg
  warn ""
  warn "For more information, try '--help'."
  exit 2
end

def parse_args(argv)
  opts = {
    bases: nil, protected: nil, update: nil, interval: nil,
    confirm: nil, detach: nil, delete: nil, dry_run: false
  }
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when "-h"
      puts HELP_SHORT
      exit 0
    when "--help"
      puts HELP_LONG
      exit 0
    when "-V", "--version"
      puts "git-trim 0.4.4"
      exit 0
    when "-b", "--bases"
      i += 1
      die_cli("error: a value is required for '#{a} <BASES>' but none was supplied") if i >= argv.length
      opts[:bases] = argv[i]
    when /\A--bases=(.*)\z/
      opts[:bases] = Regexp.last_match(1)
    when "-p", "--protected"
      i += 1
      die_cli("error: a value is required for '#{a} <PROTECTED>' but none was supplied") if i >= argv.length
      opts[:protected] = argv[i]
    when /\A--protected=(.*)\z/
      opts[:protected] = Regexp.last_match(1)
    when "--no-update"
      opts[:update] = false
    when "--update-interval"
      i += 1
      die_cli("error: a value is required for '--update-interval <UPDATE_INTERVAL>' but none was supplied") if i >= argv.length
      opts[:interval] = argv[i].to_i
    when /\A--update-interval=(.*)\z/
      opts[:interval] = Regexp.last_match(1).to_i
    when "--no-confirm"
      opts[:confirm] = false
    when "--no-detach"
      opts[:detach] = false
    when "-d", "--delete"
      i += 1
      die_cli("error: a value is required for '#{a} <DELETE>' but none was supplied") if i >= argv.length
      opts[:delete] = argv[i]
    when /\A--delete=(.*)\z/
      opts[:delete] = Regexp.last_match(1)
    when "--dry-run"
      opts[:dry_run] = true
    else
      die_cli("error: unexpected argument '#{a}' found\n\nUsage: executable [OPTIONS]")
    end
    i += 1
  end
  opts
end

def parse_delete(value)
  ranges = {
    merged_local: false, stray: false, local: false,
    merged_remote: [], diverged: [], remote: []
  }
  split_csv(value).each do |part|
    range, remote = part.split(":", 2)
    case range
    when "merged"
      die_cli("error: invalid value '#{part}' for '--delete <DELETE>': Invalid delete range format `#{part}`") if remote.nil?
      ranges[:merged_local] = true
      ranges[:merged_remote] << remote
    when "merged-local"
      ranges[:merged_local] = true
    when "merged-remote"
      die_cli("error: invalid value '#{part}' for '--delete <DELETE>': Invalid delete range format `#{part}`") if remote.nil?
      ranges[:merged_remote] << remote
    when "stray"
      ranges[:stray] = true
    when "diverged"
      die_cli("error: invalid value '#{part}' for '--delete <DELETE>': Invalid delete range format `#{part}`") if remote.nil?
      ranges[:diverged] << remote
      ranges[:merged_local] = true
    when "local"
      ranges[:local] = true
    when "remote"
      die_cli("error: invalid value '#{part}' for '--delete <DELETE>': Invalid delete range format `#{part}`") if remote.nil?
      ranges[:remote] << remote
    else
      die_cli("error: invalid value '#{part}' for '--delete <DELETE>': Invalid delete range format `#{part}`")
    end
  end
  ranges.each { |k, v| ranges[k] = v.uniq if v.is_a?(Array) }
  ranges
end

def inside_repo!
  _out, st = run_git("rev-parse", "--git-dir", ok: false)
  return if st.zero?
  warn "Error: could not find repository at '.'; class=Repository (6); code=NotFound (-3)"
  exit 1
end

def local_refs
  fmt = "%(refname:short)%00%(objectname)%00%(upstream:short)%00%(upstream:track)"
  git_out("for-each-ref", "--format=#{fmt}", "refs/heads").lines.map do |line|
    name, sha, up, track = line.chomp.split("\0", 4)
    Ref.new(name: name, sha: sha, upstream: up.to_s.empty? ? nil : up, gone: track.to_s.include?("gone"))
  end.sort_by(&:name)
end

def remote_refs
  fmt = "%(refname:short)%00%(objectname)"
  git_out("for-each-ref", "--format=#{fmt}", "refs/remotes").lines.filter_map do |line|
    name, sha = line.chomp.split("\0", 2)
    next if name.end_with?("/HEAD")
    remote = name.split("/", 2).first
    Ref.new(name: name, sha: sha, remote: remote)
  end.sort_by(&:name)
end

def branch_merged?(branch, base)
  _out, st = run_git("merge-base", "--is-ancestor", branch, base, capture: true, ok: false)
  st.zero?
end

def current_branch
  out, st = run_git("symbolic-ref", "--quiet", "--short", "HEAD", ok: false)
  st.zero? ? out.strip : nil
end

def default_bases(locals)
  bases = []
  git_out("for-each-ref", "--format=%(refname:short)%00%(symref:short)", "refs/remotes").lines.each do |line|
    name, sym = line.chomp.split("\0", 2)
    next unless name.end_with?("/HEAD") && sym && !sym.empty?
    local = locals.find { |l| l.upstream == sym }
    bases << local.name if local
  end
  bases = [current_branch].compact if bases.empty?
  bases.uniq
end

def remote_allowed?(patterns, remote)
  patterns.include?("*") || patterns.include?(remote)
end

def protected?(name, patterns)
  patterns.any? { |p| File.fnmatch?(p, name, File::FNM_PATHNAME | File::FNM_EXTGLOB) }
end

def print_list(title, items)
  return if items.empty?
  puts title
  items.each { |i| puts "  - #{i}" }
end

opts = parse_args(ARGV)
inside_repo!
if git_out("remote").lines.map(&:strip).reject(&:empty?).empty?
  warn "Error: git-trim requires at least one remote"
  exit 1
end

opts[:bases] = config("trim.bases") if opts[:bases].nil?
opts[:protected] = config("trim.protected") if opts[:protected].nil?
opts[:delete] = config("trim.delete") if opts[:delete].nil?
opts[:delete] ||= "merged:origin"
opts[:update] = bool_config("trim.update") if opts[:update].nil?
opts[:update] = true if opts[:update].nil?
opts[:confirm] = bool_config("trim.confirm") if opts[:confirm].nil?
opts[:confirm] = true if opts[:confirm].nil?
opts[:detach] = bool_config("trim.detach") if opts[:detach].nil?
opts[:detach] = true if opts[:detach].nil?
opts[:interval] = (config("trim.updateInterval") || "5").to_i if opts[:interval].nil?

delete = parse_delete(opts[:delete])

if opts[:update]
  # The original rate-limits fetches. A lightweight approximation keeps normal use current.
  run_git("fetch", "--all", "--prune", capture: false, ok: false)
end

locals = local_refs
remotes = remote_refs
bases = split_csv(opts[:bases])
bases = default_bases(locals) if bases.empty?
base_refs = bases.to_h { |b| [b, true] }
base_upstreams = locals.select { |l| base_refs[l.name] && l.upstream }.map(&:upstream)
protected_patterns = split_csv(opts[:protected])
current = current_branch

delete_local_merged = []
delete_local_stray = []
delete_local_nontracking = []
delete_remote_merged = []
delete_remote_nonupstream = []
remain_local = []
remain_remote = []
skip_notes = {}

locals.each do |l|
  if base_refs[l.name]
    remain_local << "#{l.name} [base]"
    next
  end
  if protected?(l.name, protected_patterns)
    pat = protected_patterns.find { |p| File.fnmatch?(p, l.name, File::FNM_PATHNAME | File::FNM_EXTGLOB) }
    remain_local << "#{l.name} [merged, but: protected by a pattern `#{pat}`]"
    next
  end
  merged = bases.any? { |b| branch_merged?(l.name, b) }
  if l.upstream
    if l.gone
      if delete[:stray]
        delete_local_stray << l.name
      else
        remain_local << "#{l.name} [stray, but: delete range `stray` was not given]"
      end
    elsif merged
      if delete[:merged_local]
        delete_local_merged << l.name
      else
        remain_local << "#{l.name} [merged, but: delete range `merged-local` was not given]"
      end
    else
      remain_local << l.name
    end
  elsif merged && delete[:local]
    delete_local_nontracking << "#{l.name} (non-tracking)"
  else
    note = merged ? "*2" : "*2"
    skip_notes[note] = "Set an upstream to make it a tracking branch or add `--delete 'local'` flag."
    remain_local << "#{l.name} #{note}"
  end
end

upstreams = locals.map(&:upstream).compact.to_h { |u| [u, true] }
remotes.each do |r|
  if base_upstreams.include?(r.name)
    remain_remote << "#{r.name} [base]"
    next
  end
  short = r.name.split("/", 2).last
  merged = base_upstreams.any? { |b| branch_merged?(r.name, b) } || bases.any? { |b| branch_merged?(r.name, b) }
  if merged && remote_allowed?(delete[:merged_remote] + delete[:diverged], r.remote)
    delete_remote_merged << "#{r.remote}, refs/heads/#{short}"
  elsif merged && !upstreams[r.name] && remote_allowed?(delete[:remote], r.remote)
    delete_remote_nonupstream << "#{r.remote}, refs/heads/#{short}"
  elsif merged
    if delete[:merged_local] || delete[:stray] || !delete[:merged_remote].empty? || !delete[:diverged].empty?
      remain_remote << "#{r.name} [merged, but: delete range `merged-remote:#{r.remote}` was not given]"
    else
      skip_notes["*1"] = "Add `--delete 'merged:*'` flag."
      remain_remote << "#{r.name} *1"
    end
  else
    remain_remote << r.name
  end
end

puts "Branches that will remain:"
puts "  local branches:"
remain_local.each { |s| puts "    #{s}" }
puts "  remote references:"
remain_remote.each { |s| puts "    #{s}" }
unless skip_notes.empty?
  puts "  Some branches are skipped. Consider following to scan them:"
  skip_notes.sort.each { |k, v| puts "    #{k}: #{v}" }
end
puts

print_list("Delete merged local branches:", delete_local_merged)
print_list("Delete stray local branches:", delete_local_stray)
print_list("Delete merged local branches:", delete_local_nontracking)
print_list("Delete merged remote refs:", delete_remote_merged)
print_list("Delete merged remote refs:", delete_remote_nonupstream)

all_local = (delete_local_merged + delete_local_stray + delete_local_nontracking.map { |s| s.sub(/ \(non-tracking\)\z/, "") })
all_remote = (delete_remote_merged + delete_remote_nonupstream)

if !opts[:dry_run] && opts[:confirm] && (!all_local.empty? || !all_remote.empty?)
  unless STDIN.tty?
    warn "Error: IO error: not a terminal"
    warn
    warn "Caused by:"
    warn "    not a terminal"
    exit 1
  end
  print "Delete branches? [y/N] "
  ans = STDIN.gets.to_s.strip
  exit 0 unless ans =~ /\Ay/i
end

if opts[:detach] && current && all_local.include?(current) && !opts[:dry_run]
  run_git("checkout", "--detach", capture: false, ok: false)
end

all_remote.each do |entry|
  remote, ref = entry.split(", ", 2)
  branch = ref.sub(%r{\Arefs/heads/}, "")
  if opts[:dry_run]
    run_git("push", "--dry-run", remote, "--delete", branch, capture: false, ok: false)
  else
    run_git("push", remote, "--delete", branch, capture: false, ok: false)
  end
end

all_local.each do |name|
  if opts[:dry_run]
    puts "Delete branch #{name} (dry run)."
  else
    run_git("branch", "-D", name, capture: false, ok: false)
  end
end
