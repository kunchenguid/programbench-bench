#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = "0.1.8"
FULL_HELP = <<~TEXT
  Blazingly fast Solidity compiler

  Usage: executable [OPTIONS] [INPUT]...

  Arguments:
    [INPUT]...
            Files to compile, or import remappings.
            
            `-` specifies standard input.
            
            Import remappings are specified as `[context:]prefix=path`. See <https://docs.soliditylang.org/en/latest/path-resolution.html#import-remapping>.

  Options:
    -j, --threads <THREADS>
            Number of threads to use. Zero specifies the number of logical cores
            
            [default: 4]
            [aliases: --jobs]

        --evm-version <EVM_VERSION>
            EVM version
            
            [default: prague]
            [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]

        --stop-after <STOP_AFTER>
            Stop execution after the given compiler stage
            
            [possible values: parsing, lowering, analysis]

        --out-dir <OUT_DIR>
            Directory to write output files

        --emit <EMIT>
            Comma separated list of types of output for the compiler to emit
            
            [possible values: abi, hashes]

    -Z <FLAG>
            Unstable flags. WARNING: these are completely unstable, and may change at any time.
            
            See `-Zhelp` for more details.

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version

  Input options:
        --base-path <BASE_PATH>
            Use the given path as the root of the source tree

    -I, --include-path <INCLUDE_PATH>
            Directory to search for files.
            
            Can be used multiple times.

        --allow-paths <ALLOW_PATHS>
            Allow a given path for imports

  Display options:
        --color <COLOR>
            Coloring
            
            [default: auto]
            [possible values: auto, always, never]

    -v, --verbose
            Use verbose output

        --pretty-json
            Pretty-print JSON output.
            
            Does not include errors. See `--pretty-json-err`.

        --pretty-json-err
            Pretty-print error JSON output

        --error-format <ERROR_FORMAT>
            How errors and other messages are produced
            
            [default: human]
            [possible values: human, json, rustc-json]

        --error-format-human <VALUE>
            Human-readable error message style
            
            [default: unicode]
            [possible values: ascii, unicode, short]

        --diagnostic-width <WIDTH>
            Terminal width for error message formatting

        --no-warnings
            Whether to disable warnings
TEXT

SHORT_HELP = <<~TEXT
  Blazingly fast Solidity compiler

  Usage: executable [OPTIONS] [INPUT]...

  Arguments:
    [INPUT]...  Files to compile, or import remappings

  Options:
    -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]
        --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]
        --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: parsing, lowering, analysis]
        --out-dir <OUT_DIR>          Directory to write output files
        --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]
    -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time
    -h, --help                       Print help (see more with '--help')
    -V, --version                    Print version

  Input options:
        --base-path <BASE_PATH>        Use the given path as the root of the source tree
    -I, --include-path <INCLUDE_PATH>  Directory to search for files
        --allow-paths <ALLOW_PATHS>    Allow a given path for imports

  Display options:
        --color <COLOR>                Coloring [default: auto] [possible values: auto, always, never]
    -v, --verbose                      Use verbose output
        --pretty-json                  Pretty-print JSON output
        --pretty-json-err              Pretty-print error JSON output
        --error-format <ERROR_FORMAT>  How errors and other messages are produced [default: human] [possible values: human, json, rustc-json]
        --error-format-human <VALUE>   Human-readable error message style [default: unicode] [possible values: ascii, unicode, short]
        --diagnostic-width <WIDTH>     Terminal width for error message formatting
        --no-warnings                  Whether to disable warnings
TEXT

Z_HELP = <<~TEXT
  error: List of all unstable flags.
  WARNING: these are completely unstable, and may change at any time!

  Options:
        -Zui-testing
            Enables UI testing mode

        -Ztrack-diagnostics
            Prints a note for every diagnostic that is emitted with the creation and emission location.
            
            This is enabled by default on debug builds.

        -Zparse-yul
            Enables parsing Yul files for testing

        -Zno-resolve-imports
            Disables import resolution

        -Zdump=<KIND[=PATHS...]>
            Print additional information about the compiler's internal state.
            
            Valid kinds are `ast` and `hir`.

        -Zast-stats
            Print AST stats

        -Zspan-visitor
            Run the span visitor after parsing

        -Zprint-max-storage-sizes
            Print contracts' max storage sizes

        -Ztypeck
            Type check the program. WIP

        -Zhelp
            Print help

  Usage: solar [OPTIONS] [INPUT]...

  For more information, try '--help'.
TEXT

EVM_VALUES = %w[homestead tangerineWhistle spuriousDragon byzantium constantinople petersburg istanbul berlin london paris shanghai cancun prague osaka].freeze
STOP_VALUES = %w[parsing lowering analysis].freeze
EMIT_VALUES = %w[abi hashes].freeze

def die_cli(message, status = 2)
  warn message
  exit status
end

def need_value(args, idx, opt)
  val = args[idx + 1]
  die_cli("error: a value is required for '#{opt} <#{opt.sub(/^--?/, '').tr('-', '_').upcase}>' but none was supplied\n\nFor more information, try '--help'.") if val.nil?
  val
end

def parse_args(argv)
  opts = { emit: [], pretty: false, out_dir: nil, error_format: "human", inputs: [] }
  i = 0
  while i < argv.length
    a = argv[i]
    case a
    when "-h"
      puts SHORT_HELP
      exit 0
    when "--help"
      puts FULL_HELP
      exit 0
    when "-V", "--version"
      puts "solar Version: #{VERSION}"
      puts "Commit SHA: 8f228ae9f0bd90ad4ec81fb1ef4fbba29748b8d5"
      puts "Build Timestamp: 2026-04-17T19:59:51.519973035Z"
      puts "Build Features: mimalloc,tracing"
      puts "Build Profile: release"
      exit 0
    when "-Zhelp"
      puts Z_HELP
      exit 0
    when /\A--emit=(.*)\z/
      val = Regexp.last_match(1)
      vals = val.split(",")
      bad = vals.find { |v| !EMIT_VALUES.include?(v) }
      die_cli("error: invalid value '#{bad}' for '--emit <EMIT>'\n  [possible values: abi, hashes]\n\nFor more information, try '--help'.") if bad
      opts[:emit].concat(vals)
    when /\A--out-dir=(.*)\z/
      opts[:out_dir] = Regexp.last_match(1)
    when /\A--error-format=(.*)\z/
      val = Regexp.last_match(1)
      unless %w[human json rustc-json].include?(val)
        die_cli("error: invalid value '#{val}' for '--error-format <ERROR_FORMAT>'\n  [possible values: human, json, rustc-json]\n\nFor more information, try '--help'.")
      end
      opts[:error_format] = val
    when /\A--evm-version=(.*)\z/
      val = Regexp.last_match(1)
      unless EVM_VALUES.include?(val)
        die_cli("error: invalid value '#{val}' for '--evm-version <EVM_VERSION>'\n  [possible values: #{EVM_VALUES.join(', ')}]\n\nFor more information, try '--help'.")
      end
    when /\A--stop-after=(.*)\z/
      val = Regexp.last_match(1)
      unless STOP_VALUES.include?(val)
        die_cli("error: invalid value '#{val}' for '--stop-after <STOP_AFTER>'\n  [possible values: #{STOP_VALUES.join(', ')}]\n\nFor more information, try '--help'.")
      end
    when /\A--color=(.*)\z/
      val = Regexp.last_match(1)
      unless %w[auto always never].include?(val)
        die_cli("error: invalid value '#{val}' for '--color <COLOR>'\n  [possible values: auto, always, never]\n\nFor more information, try '--help'.")
      end
    when /\A--(threads|jobs|base-path|include-path|allow-paths|diagnostic-width|error-format-human)=/
    when "-Z"
      need_value(argv, i, "-Z")
      i += 1
    when /\A-Z/
      # Other unstable flags are accepted for compatibility.
    when "-j", "--threads", "--jobs", "--base-path", "-I", "--include-path", "--allow-paths", "--diagnostic-width", "--error-format-human", "--color"
      val = need_value(argv, i, a)
      if a == "--color" && !%w[auto always never].include?(val)
        die_cli("error: invalid value '#{val}' for '--color <COLOR>'\n  [possible values: auto, always, never]\n\nFor more information, try '--help'.")
      end
      i += 1
    when "--evm-version"
      val = need_value(argv, i, a)
      unless EVM_VALUES.include?(val)
        die_cli("error: invalid value '#{val}' for '--evm-version <EVM_VERSION>'\n  [possible values: #{EVM_VALUES.join(', ')}]\n\nFor more information, try '--help'.")
      end
      i += 1
    when "--stop-after"
      val = need_value(argv, i, a)
      unless STOP_VALUES.include?(val)
        die_cli("error: invalid value '#{val}' for '--stop-after <STOP_AFTER>'\n  [possible values: #{STOP_VALUES.join(', ')}]\n\nFor more information, try '--help'.")
      end
      i += 1
    when "--out-dir"
      opts[:out_dir] = need_value(argv, i, a)
      i += 1
    when "--emit"
      val = need_value(argv, i, a)
      vals = val.split(",")
      bad = vals.find { |v| !EMIT_VALUES.include?(v) }
      die_cli("error: invalid value '#{bad}' for '--emit <EMIT>'\n  [possible values: abi, hashes]\n\nFor more information, try '--help'.") if bad
      opts[:emit].concat(vals)
      i += 1
    when "--pretty-json"
      opts[:pretty] = true
    when "--pretty-json-err", "--no-warnings", "-v", "--verbose"
    when "--error-format"
      val = need_value(argv, i, a)
      unless %w[human json rustc-json].include?(val)
        die_cli("error: invalid value '#{val}' for '--error-format <ERROR_FORMAT>'\n  [possible values: human, json, rustc-json]\n\nFor more information, try '--help'.")
      end
      opts[:error_format] = val
      i += 1
    when "--"
      opts[:inputs].concat(argv[(i + 1)..] || [])
      break
    else
      if a.start_with?("-") && a != "-"
        die_cli("error: unexpected argument '#{a}' found\n\n  tip: to pass '#{a}' as a value, use '-- #{a}'\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.")
      end
      opts[:inputs] << a
    end
    i += 1
  end
  opts[:emit].uniq!
  opts
end

def canonical_type(type)
  t = type.to_s.strip
  t = t.gsub(/\b(memory|calldata|storage|payable)\b/, "").gsub(/\s+/, " ").strip
  t = t.sub(/\Auint\z/, "uint256").sub(/\Aint\z/, "int256")
  t = t.gsub(/\s*\[\s*\]/, "[]")
  t
end

def parse_params(text, event: false)
  text.to_s.split(",").map(&:strip).reject(&:empty?).map do |raw|
    indexed = false
    parts = raw.split(/\s+/)
    if event && (idx = parts.index("indexed"))
      indexed = true
      parts.delete_at(idx)
    end
    parts.delete("memory")
    parts.delete("calldata")
    parts.delete("storage")
    name = ""
    if parts.length > 1 && parts[-1] =~ /\A[A-Za-z_]\w*\z/
      name = parts.pop
    end
    typ = canonical_type(parts.join(" "))
    item = { "name" => name, "type" => typ }
    item["indexed"] = indexed if event
    item["internalType"] = typ
    item
  end
end

def strip_comments(src)
  src.gsub(%r{//.*?$}, "").gsub(%r{/\*.*?\*/}m, "")
end

def find_body(src, open_idx)
  depth = 0
  i = open_idx
  while i < src.length
    ch = src[i]
    depth += 1 if ch == "{"
    if ch == "}"
      depth -= 1
      return src[(open_idx + 1)...i] if depth.zero?
    end
    i += 1
  end
  src[(open_idx + 1)..] || ""
end

def state_mutability(decl)
  return "pure" if decl =~ /\bpure\b/
  return "view" if decl =~ /\bview\b/
  return "payable" if decl =~ /\bpayable\b/
  "nonpayable"
end

def parse_contracts(source, filename)
  src = strip_comments(source)
  contracts = {}
  src.to_enum(:scan, /\b(contract|interface|library)\s+([A-Za-z_]\w*)[^{;]*\{/).each do
    kind = Regexp.last_match(1)
    name = Regexp.last_match(2)
    open_idx = Regexp.last_match.end(0) - 1
    body = find_body(src, open_idx)
    abi = []

    body.scan(/\bconstructor\s*\(([^)]*)\)\s*([^;{]*)/) do |params, tail|
      abi << { "type" => "constructor", "inputs" => parse_params(params), "stateMutability" => state_mutability(tail) }
    end
    body.scan(/\berror\s+([A-Za-z_]\w*)\s*\(([^)]*)\)\s*;/) do |ename, params|
      abi << { "type" => "error", "name" => ename, "inputs" => parse_params(params) }
    end
    body.scan(/\bevent\s+([A-Za-z_]\w*)\s*\(([^)]*)\)\s*(anonymous)?\s*;/) do |ename, params, anon|
      abi << { "type" => "event", "name" => ename, "inputs" => parse_params(params, event: true), "anonymous" => !anon.nil? }
    end
    body.scan(/\bfunction\s+([A-Za-z_]\w*)\s*\(([^)]*)\)\s*([^;{]*)(?:[;{])/) do |fname, params, tail|
      next if tail =~ /\b(internal|private)\b/
      outputs = []
      if tail =~ /\breturns\s*\(([^)]*)\)/
        outputs = parse_params(Regexp.last_match(1))
      end
      abi << { "type" => "function", "name" => fname, "inputs" => parse_params(params), "outputs" => outputs, "stateMutability" => state_mutability(tail) }
    end
    body.scan(/\b([A-Za-z_]\w*(?:\s*\[\s*\])?)\s+public\s+([A-Za-z_]\w*)\s*(?:[=;])/) do |typ, vname|
      ctyp = canonical_type(typ)
      abi << { "type" => "function", "name" => vname, "inputs" => [], "outputs" => [{ "name" => "", "type" => ctyp, "internalType" => ctyp }], "stateMutability" => "view" }
    end
    order = { "constructor" => 0, "error" => 1, "event" => 2, "function" => 3 }
    abi.sort_by! { |e| [order[e["type"]] || 9, e["name"].to_s] }
    contracts["#{filename}:#{name}"] = { kind: kind, abi: abi }
  end
  contracts
end

ROT = [1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 2, 14, 27, 41, 56, 8, 25, 43, 62, 18, 39, 61, 20, 44].freeze
PILN = [10, 7, 11, 17, 18, 3, 5, 16, 8, 21, 24, 4, 15, 23, 19, 13, 12, 2, 20, 14, 22, 9, 6, 1].freeze
RC = [0x0000000000000001, 0x0000000000008082, 0x800000000000808a, 0x8000000080008000,
      0x000000000000808b, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
      0x000000000000008a, 0x0000000000000088, 0x0000000080008009, 0x000000008000000a,
      0x000000008000808b, 0x800000000000008b, 0x8000000000008089, 0x8000000000008003,
      0x8000000000008002, 0x8000000000000080, 0x000000000000800a, 0x800000008000000a,
      0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008].freeze
MASK = (1 << 64) - 1

def rol(x, n)
  ((x << n) | (x >> (64 - n))) & MASK
end

def keccak_f(st)
  24.times do |round|
    bc = Array.new(5, 0)
    5.times { |i| bc[i] = st[i] ^ st[i + 5] ^ st[i + 10] ^ st[i + 15] ^ st[i + 20] }
    5.times do |i|
      t = bc[(i + 4) % 5] ^ rol(bc[(i + 1) % 5], 1)
      j = i
      while j < 25
        st[j] ^= t
        j += 5
      end
    end
    t = st[1]
    24.times do |i|
      j = PILN[i]
      bc[0] = st[j]
      st[j] = rol(t, ROT[i])
      t = bc[0]
    end
    0.step(20, 5) do |j|
      5.times { |i| bc[i] = st[j + i] }
      5.times { |i| st[j + i] ^= ((~bc[(i + 1) % 5]) & bc[(i + 2) % 5]) & MASK }
    end
    st[0] ^= RC[round]
  end
end

def keccak256_hex(str)
  rate = 136
  bytes = str.bytes
  bytes << 0x01
  bytes << 0 while (bytes.length % rate) != rate - 1
  bytes << 0x80
  st = Array.new(25, 0)
  bytes.each_slice(rate) do |block|
    (rate / 8).times do |i|
      lane = 0
      8.times { |b| lane |= (block[i * 8 + b] || 0) << (8 * b) }
      st[i] ^= lane
    end
    keccak_f(st)
  end
  out = +""
  4.times { |i| out << (st[i] & MASK).to_s(16).rjust(16, "0").scan(/../).reverse.join }
  out[0, 64]
end

def signature(entry)
  types = entry["inputs"].map { |p| p["type"] }.join(",")
  "#{entry["name"]}(#{types})"
end

def json_escape(str)
  str.to_s.gsub(/["\\\b\f\n\r\t]/) do |c|
    case c
    when '"' then '\"'
    when "\\" then "\\\\"
    when "\b" then "\\b"
    when "\f" then "\\f"
    when "\n" then "\\n"
    when "\r" then "\\r"
    when "\t" then "\\t"
    end
  end
end

def json_generate(obj)
  case obj
  when Hash
    "{" + obj.map { |k, v| "\"#{json_escape(k)}\":#{json_generate(v)}" }.join(",") + "}"
  when Array
    "[" + obj.map { |v| json_generate(v) }.join(",") + "]"
  when String
    "\"#{json_escape(obj)}\""
  when true
    "true"
  when false
    "false"
  when nil
    "null"
  else
    obj.to_s
  end
end

def json_pretty(obj, level = 0)
  indent = "  " * level
  child = "  " * (level + 1)
  case obj
  when Hash
    return "{}" if obj.empty?
    body = obj.map { |k, v| "#{child}\"#{json_escape(k)}\": #{json_pretty(v, level + 1)}" }.join(",\n")
    "{\n#{body}\n#{indent}}"
  when Array
    return "[]" if obj.empty?
    body = obj.map { |v| "#{child}#{json_pretty(v, level + 1)}" }.join(",\n")
    "[\n#{body}\n#{indent}]"
  else
    json_generate(obj)
  end
end

def syntax_error?(source)
  source =~ /function\s+\w*\s*\([^)]*\}/
end

def report_error(message, file: nil, source: nil, error_format: "human")
  if error_format == "json"
    loc = file ? { "file" => file, "start" => 0, "end" => 0 } : nil
    puts json_generate({ "sourceLocation" => loc, "secondarySourceLocations" => [], "type" => "Exception", "component" => "general", "severity" => "error", "errorCode" => nil, "message" => message, "formattedMessage" => "error: #{message}\n\n" })
    puts json_generate({ "sourceLocation" => nil, "secondarySourceLocations" => [], "type" => "Exception", "component" => "general", "severity" => "error", "errorCode" => nil, "message" => "aborting due to 1 previous error", "formattedMessage" => "error: aborting due to 1 previous error\n\n" })
  else
    warn "error: #{message}"
    warn ""
    warn "error: aborting due to 1 previous error"
    warn ""
  end
  exit 1
end

opts = parse_args(ARGV)
if opts[:inputs].empty?
  puts SHORT_HELP
  exit 2
end

all = {}
opts[:inputs].each do |input|
  next if input.include?("=") && input != "-"
  if input == "-"
    label = "<stdin>"
    content = STDIN.read
  else
    unless File.file?(input)
      report_error("file #{input} not found", error_format: opts[:error_format])
    end
    label = input
    content = File.read(input)
  end
  if syntax_error?(content)
    report_error("expected one of `)`, `function`, `mapping`, elementary type name, or path, found `}`", file: label, source: content, error_format: opts[:error_format])
  end
  all.merge!(parse_contracts(content, label))
end

exit 0 if opts[:emit].empty?

contracts_json = {}
all.each do |key, data|
  obj = {}
  obj["abi"] = data[:abi] if opts[:emit].include?("abi")
  if opts[:emit].include?("hashes")
    hashes = {}
    data[:abi].each do |entry|
      next unless entry["type"] == "function"
      sig = signature(entry)
      hashes[sig] = keccak256_hex(sig)[0, 8]
    end
    obj["hashes"] = hashes
  end
  contracts_json[key] = obj
end
result = { "contracts" => contracts_json, "version" => VERSION }
json = opts[:pretty] ? json_pretty(result) : json_generate(result)

if opts[:out_dir]
  system("mkdir", "-p", opts[:out_dir])
  File.write(File.join(opts[:out_dir], "combined.json"), json)
else
  puts json
end
