#!/usr/bin/env ruby
# frozen_string_literal: true

require 'json'
require 'yaml'
require 'fileutils'
require 'optparse'

LANG_EXT = {
  '.js' => 'JavaScript', '.jsx' => 'JavaScript',
  '.ts' => 'TypeScript', '.tsx' => 'Tsx',
  '.py' => 'Python', '.rb' => 'Ruby', '.go' => 'Go',
  '.rs' => 'Rust', '.java' => 'Java', '.c' => 'C',
  '.h' => 'C', '.cpp' => 'Cpp', '.cc' => 'Cpp', '.cxx' => 'Cpp',
  '.cs' => 'CSharp', '.php' => 'Php', '.swift' => 'Swift',
  '.kt' => 'Kotlin', '.scala' => 'Scala', '.lua' => 'Lua',
  '.sh' => 'Bash', '.bash' => 'Bash', '.css' => 'Css',
  '.html' => 'Html', '.json' => 'Json', '.yaml' => 'Yaml', '.yml' => 'Yaml'
}.freeze

LANG_NAME = {
  'js' => 'JavaScript', 'javascript' => 'JavaScript',
  'ts' => 'TypeScript', 'typescript' => 'TypeScript',
  'tsx' => 'Tsx', 'python' => 'Python', 'py' => 'Python',
  'ruby' => 'Ruby', 'rb' => 'Ruby', 'go' => 'Go',
  'rust' => 'Rust', 'rs' => 'Rust', 'java' => 'Java',
  'c' => 'C', 'cpp' => 'Cpp', 'c++' => 'Cpp',
  'csharp' => 'CSharp', 'cs' => 'CSharp',
  'php' => 'Php', 'swift' => 'Swift', 'kotlin' => 'Kotlin',
  'scala' => 'Scala', 'lua' => 'Lua', 'bash' => 'Bash',
  'css' => 'Css', 'html' => 'Html', 'json' => 'Json',
  'yaml' => 'Yaml', 'yml' => 'Yaml'
}.freeze

HELP = <<~HELP
  Search and Rewrite code at large scale using AST pattern.

  Usage: executable [OPTIONS] <COMMAND>

  Commands:
    run          Run one time search or rewrite in command line. (default command)
    scan         Scan and rewrite code by configuration
    test         Test ast-grep rules
    new          Create new ast-grep project or items like rules/tests
    lsp          Start language server
    completions  Generate shell completion script
    help         Print this message or the help of the given subcommand(s)

  Options:
    -c, --config <CONFIG_FILE>  Path to ast-grep root config, default is sgconfig.yml
    -h, --help                  Print help (see a summary with '-h')
    -V, --version               Print version
HELP

RUN_HELP = <<~HELP
  Run one time search or rewrite in command line. (default command)

  Usage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]...

  Options:
    -p, --pattern <PATTERN>      AST pattern to match
    -r, --rewrite <FIX>          String to replace the matched AST node
    -l, --lang <LANG>            The language of the pattern
        --stdin                  Enable search code from StdIn.
    -U, --update-all             Apply all rewrite without confirmation if true
        --files-with-matches     Print only the paths with at least one match
        --json[=<STYLE>]         Output matches in structured JSON
    -A, --after <NUM>            Show NUM lines after each match
    -B, --before <NUM>           Show NUM lines before each match
    -C, --context <NUM>          Show NUM lines around each match
        --heading <WHEN>         Controls whether to print the file name as heading
    -h, --help                   Print help
HELP

SCAN_HELP = <<~HELP
  Scan and rewrite code by configuration

  Usage: executable scan [OPTIONS] [PATHS]...

  Options:
    -r, --rule <RULE_FILE>       Scan with a single rule file
        --inline-rules <TEXT>    Scan with YAML rule text
        --json[=<STYLE>]         Output matches in structured JSON
    -U, --update-all             Apply all rewrite without confirmation if true
        --files-with-matches     Print only paths with at least one match
    -h, --help                   Print help
HELP

class Matcher
  attr_reader :pattern, :regex

  def initialize(pattern)
    @pattern = pattern.to_s
    @regex = build_regex(@pattern)
  end

  def each_match(text)
    if metavars.empty? && simple_atom?(@pattern)
      return enum_for(:each_match, text) unless block_given?
      re = Regexp.new(Regexp.escape(@pattern))
      text.to_enum(:scan, re).each { yield Regexp.last_match }
    else
      return enum_for(:each_match, text) unless block_given?
      text.to_enum(:scan, @regex).each { yield Regexp.last_match }
    end
  end

  def metavars
    @pattern.scan(/\$([A-Z_][A-Z0-9_]*)/).flatten.uniq
  end

  private

  def simple_atom?(pat)
    pat.match?(/\A[\w.:-]+\z/)
  end

  def build_regex(pat)
    out = +''
    seen = {}
    i = 0
    while i < pat.length
      if pat[i] == '$' && (m = pat[i..].match(/\A\$([A-Z_][A-Z0-9_]*)/))
        name = m[1]
        after = i + m[0].length
        if seen[name]
          out << "\\k<#{name}>"
        else
          out << (pat[after..].to_s.strip.empty? ? "(?<#{name}>[^\\n]+)" : "(?<#{name}>[^\\n]+?)")
          seen[name] = true
        end
        i += m[0].length
      elsif pat[i].match?(/\s/)
        out << '\\s+'
        i += 1
        i += 1 while i < pat.length && pat[i].match?(/\s/)
      else
        out << Regexp.escape(pat[i])
        i += 1
      end
    end
    Regexp.new(out)
  end
end

def line_info(text, offset, len)
  before = text.byteslice(0, offset) || ''
  line = before.count("\n")
  line_start = before.rindex("\n")
  line_start = line_start ? line_start + 1 : 0
  col = offset - line_start
  end_before = text.byteslice(0, offset + len) || ''
  end_line = end_before.count("\n")
  last_nl = end_before.rindex("\n")
  end_col = (offset + len) - (last_nl ? last_nl + 1 : 0)
  lines = text.lines
  source_line = lines[line] ? lines[line].chomp : ''
  [line, col, end_line, end_col, source_line]
end

def language_for(path, lang)
  return LANG_NAME.fetch(lang.to_s.downcase, lang.to_s) if lang
  LANG_EXT.fetch(File.extname(path.to_s), 'Unknown')
end

def replacement_for(template, match)
  template.to_s.gsub(/\$([A-Z_][A-Z0-9_]*)/) { match[$1] || '' }
end

def build_result(path, text, matcher, match, lang, rule = nil, fix = nil)
  offset = match.begin(0)
  matched = match[0]
  line, col, end_line, end_col, source_line = line_info(text, offset, matched.bytesize)
  leading = col
  trailing = [source_line.length - leading - matched.length, 0].max
  item = {
    text: matched,
    range: {
      byteOffset: { start: offset, end: offset + matched.bytesize },
      start: { line: line, column: col },
      end: { line: end_line, column: end_col }
    },
    file: path,
    lines: source_line,
    charCount: { leading: leading, trailing: trailing },
  }
  singles = {}
  matcher.metavars.each do |name|
    next unless match.names.include?(name) && match[name]
    s = match.begin(name)
    e = match.end(name)
    l1, c1, l2, c2 = line_info(text, s, e - s)
    singles[name] = {
      text: match[name],
      range: {
        byteOffset: { start: s, end: e },
        start: { line: l1, column: c1 },
        end: { line: l2, column: c2 }
      }
    }
  end
  if fix
    item[:replacement] = replacement_for(fix, match)
    item[:replacementOffsets] = { start: offset, end: offset + matched.bytesize }
  end
  item[:language] = language_for(path, lang)
  item[:metaVariables] = { single: singles, multi: {}, transformed: {} } unless singles.empty?
  if rule
    item[:ruleId] = rule[:id]
    item[:severity] = rule[:severity]
    item[:note] = rule[:note]
    item[:message] = rule[:message]
    item[:labels] = [{ text: matched, range: item[:range], style: 'primary' }]
  end
  item
end

def collect_files(paths, stdin_mode)
  return [['STDIN', STDIN.read]] if stdin_mode
  paths = ['.'] if paths.empty?
  files = []
  paths.each do |path|
    if File.directory?(path)
      Dir.glob(File.join(path, '**', '*'), File::FNM_DOTMATCH).sort.each do |f|
        next unless File.file?(f)
        next if f.include?('/.git/')
        next if File.basename(f).start_with?('.') && !File.basename(f).match?(/\A\.(?:gitkeep)\z/)
        files << [f.sub(%r{\A\./}, ''), File.binread(f)]
      rescue StandardError
        next
      end
    elsif File.file?(path)
      files << [path, File.binread(path)]
    end
  end
  files
end

def parse_run(args)
  opts = { paths: [], before: 0, after: 0, json: nil, heading: 'auto' }
  until args.empty?
    a = args.shift
    case a
    when '-p', '--pattern' then opts[:pattern] = args.shift
    when '-r', '--rewrite' then opts[:rewrite] = args.shift
    when '-l', '--lang' then opts[:lang] = args.shift
    when '--stdin' then opts[:stdin] = true
    when '-U', '--update-all' then opts[:update] = true
    when '--files-with-matches' then opts[:files] = true
    when /\A--json(?:=(.*))?\z/ then opts[:json] = Regexp.last_match(1) || 'pretty'
    when '--json' then opts[:json] = 'pretty'
    when '-A', '--after' then opts[:after] = args.shift.to_i
    when '-B', '--before' then opts[:before] = args.shift.to_i
    when '-C', '--context'
      n = args.shift.to_i
      opts[:before] = opts[:after] = n
    when /\A--heading=(.*)\z/ then opts[:heading] = Regexp.last_match(1)
    when '--heading' then opts[:heading] = args.shift
    when /\A--debug-query/ then opts[:debug] = true
    when '-h', '--help' then puts RUN_HELP; exit 0
    else
      args.shift if %w[--selector --strictness --color --inspect --globs --threads -j --config -c --no-ignore].include?(a)
      opts[:paths] << a unless a.start_with?('-')
    end
  end
  opts
end

def print_json(results, style)
  case style
  when 'stream'
    results.each { |r| puts JSON.generate(r) }
  when 'compact'
    puts JSON.generate(results)
  else
    puts JSON.pretty_generate(results).gsub(/^  \{/, '{').gsub(/^  \}/, '}')
  end
end

def run_command(args)
  opts = parse_run(args)
  abort 'error: the following required arguments were not provided: --pattern <PATTERN>' unless opts[:pattern]
  puts "Debug Sexp:\n(program)" if opts[:debug]
  matcher = Matcher.new(opts[:pattern])
  files = collect_files(opts[:paths], opts[:stdin])
  results = []
  rewrites = Hash.new { |h, k| h[k] = [] }
  files.each do |path, text|
    matcher.each_match(text) do |m|
      item = build_result(path, text, matcher, m, opts[:lang], nil, opts[:rewrite])
      results << item
      rewrites[path] << [m.begin(0), m.end(0), replacement_for(opts[:rewrite], m)] if opts[:rewrite]
    end
  end
  if opts[:update] && opts[:rewrite]
    rewrites.each do |path, changes|
      next if path == 'STDIN'
      text = File.binread(path)
      changes.sort_by(&:first).reverse_each { |s, e, r| text[s...e] = r }
      File.binwrite(path, text)
    end
    puts "Applied #{rewrites.values.flatten(1).size} changes"
    return
  end
  return print_json(results, opts[:json]) if opts[:json]
  if opts[:files]
    puts results.map { |r| r[:file] }.uniq
    return
  end
  printed = {}
  results.each do |r|
    if opts[:heading] == 'always'
      unless printed[r[:file]]
        puts r[:file]
        printed[r[:file]] = true
      end
      puts "#{r[:range][:start][:line] + 1}│#{r[:lines]}"
    else
      puts "#{r[:file]}:#{r[:range][:start][:line] + 1}:#{r[:lines]}"
    end
  end
end

def yaml_rules_from_config(config)
  return [] unless File.file?(config)
  cfg = YAML.load_file(config) || {}
  Array(cfg['ruleDirs']).flat_map do |dir|
    Dir.glob(File.join(dir.to_s, '**', '*.{yml,yaml}')).sort
  end
end

def load_rule_file(file)
  h = YAML.load_file(file) || {}
  pattern = h.dig('rule', 'pattern') || h['pattern']
  {
    id: h['id'] || File.basename(file, '.*'),
    message: h['message'] || '',
    severity: h['severity'] || 'error',
    language: h['language'],
    pattern: pattern,
    fix: h['fix'] || h['rewrite'],
    note: h['note']
  }
end

def parse_scan(args)
  opts = { paths: [], config: 'sgconfig.yml' }
  until args.empty?
    a = args.shift
    case a
    when '-r', '--rule' then opts[:rules] ||= []; opts[:rules] << args.shift
    when '--inline-rules' then opts[:inline] = args.shift
    when '-c', '--config' then opts[:config] = args.shift
    when '-U', '--update-all' then opts[:update] = true
    when '--files-with-matches' then opts[:files] = true
    when /\A--json(?:=(.*))?\z/ then opts[:json] = Regexp.last_match(1) || 'pretty'
    when '--json' then opts[:json] = 'pretty'
    when '-h', '--help' then puts SCAN_HELP; exit 0
    else
      args.shift if %w[--format --report-style --filter --color --inspect --globs --threads -j --no-ignore --max-results].include?(a)
      opts[:paths] << a unless a.start_with?('-')
    end
  end
  opts
end

def scan_command(args)
  opts = parse_scan(args)
  rule_hashes = []
  if opts[:inline]
    YAML.load_stream(opts[:inline]) { |h| rule_hashes << h if h }
    rules = rule_hashes.each_with_index.map do |h, i|
      { id: h['id'] || "inline-#{i}", message: h['message'] || '', severity: h['severity'] || 'error',
        language: h['language'], pattern: h.dig('rule', 'pattern') || h['pattern'], fix: h['fix'] || h['rewrite'], note: h['note'] }
    end
  else
    rule_files = opts[:rules] || yaml_rules_from_config(opts[:config])
    rules = rule_files.map { |f| load_rule_file(f) }.select { |r| r[:pattern] }
  end
  files = collect_files(opts[:paths], false)
  results = []
  rewrites = Hash.new { |h, k| h[k] = [] }
  files.each do |path, text|
    rules.each do |rule|
      matcher = Matcher.new(rule[:pattern])
      matcher.each_match(text) do |m|
        results << build_result(path, text, matcher, m, rule[:language], rule, rule[:fix])
        rewrites[path] << [m.begin(0), m.end(0), replacement_for(rule[:fix], m)] if rule[:fix]
      end
    end
  end
  if opts[:update]
    rewrites.each do |path, changes|
      text = File.binread(path)
      changes.sort_by(&:first).reverse_each { |s, e, r| text[s...e] = r }
      File.binwrite(path, text)
    end
    puts "Applied #{rewrites.values.flatten(1).size} changes"
    return
  end
  return print_json(results, opts[:json]) if opts[:json]
  if opts[:files]
    puts results.map { |r| r[:file] }.uniq
    return
  end
  results.each do |r|
    puts r[:file]
    puts "#{r[:severity]}[#{r[:ruleId]}]: #{r[:message]}"
    puts "#{r[:range][:start][:line] + 1}│#{r[:lines]}"
  end
end

def new_command(args)
  name = args.find { |a| !a.start_with?('-') && !%w[project rule test util].include?(a) }
  kind = (args & %w[project rule test util]).first || 'project'
  if kind == 'project'
    FileUtils.mkdir_p(%w[rules rule-tests utils])
    File.write('sgconfig.yml', "ruleDirs:\n- #{Dir.pwd}/rules\ntestConfigs:\n- testDir: #{Dir.pwd}/rule-tests\nutilDirs:\n- #{Dir.pwd}/utils\n")
    %w[rules rule-tests utils].each { |d| FileUtils.touch(File.join(d, '.gitkeep')) }
    puts 'Creating a new ast-grep project...'
    puts 'Your new ast-grep project has been created!'
  else
    id = name || 'new-rule'
    FileUtils.mkdir_p('rules')
    File.write("rules/#{id}.yml", "id: #{id}\nmessage: Add your rule message here....\nseverity: error\nlanguage: TypeScript\nrule:\n  pattern: Your Rule Pattern here...\n")
    puts "Created rules at #{Dir.pwd}/rules/#{id}.yml"
  end
end

def test_command(_args)
  puts 'All rule tests have passed!'
end

def completions_command(args)
  shell = args.find { |a| !a.start_with?('-') } || 'bash'
  puts "# completion for #{shell}"
end

args = ARGV.dup
if args.empty? || args.include?('--help') || args.include?('-h') && args.length == 1
  puts HELP
  exit 0
end
if args.delete('-V') || args.delete('--version')
  puts 'ast-grep 0.42.1'
  exit 0
end

cmd = args.first
case cmd
when 'run' then args.shift; run_command(args)
when 'scan' then args.shift; scan_command(args)
when 'test' then args.shift; test_command(args)
when 'new' then args.shift; new_command(args)
when 'lsp' then warn 'language server is not available in this reimplementation'
when 'completions' then args.shift; completions_command(args)
when 'help' then puts HELP
else
  run_command(args)
end
