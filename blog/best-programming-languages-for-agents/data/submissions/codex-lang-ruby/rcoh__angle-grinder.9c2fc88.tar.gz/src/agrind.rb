#!/usr/bin/env ruby
# frozen_string_literal: true

require 'time'
require 'set'

VERSION = 'ag 0.19.6'

module MiniJSON
  class Parser
    def initialize(s); @s = s; @i = 0; end
    def parse
      v = value
      ws
      raise 'trailing data' unless @i == @s.length
      v
    end
    def ws; @i += 1 while @i < @s.length && @s[@i] =~ /\s/; end
    def value
      ws
      c = @s[@i]
      case c
      when '"' then string
      when '{' then object
      when '[' then array
      when 't' then literal('true', true)
      when 'f' then literal('false', false)
      when 'n' then literal('null', nil)
      else number
      end
    end
    def literal(t, v)
      raise 'bad literal' unless @s[@i, t.length] == t
      @i += t.length
      v
    end
    def string
      raise 'bad string' unless @s[@i] == '"'
      @i += 1; out = +''
      while @i < @s.length
        c = @s[@i]; @i += 1
        return out if c == '"'
        if c == '\\'
          e = @s[@i]; @i += 1
          out << case e
                 when '"' then '"'
                 when '\\' then '\\'
                 when '/' then '/'
                 when 'b' then "\b"
                 when 'f' then "\f"
                 when 'n' then "\n"
                 when 'r' then "\r"
                 when 't' then "\t"
                 when 'u'
                   cp = @s[@i, 4].to_i(16); @i += 4; [cp].pack('U')
                 else e.to_s
                 end
        else
          out << c
        end
      end
      raise 'unterminated string'
    end
    def number
      m = /-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/.match(@s[@i..] || '')
      raise 'bad value' unless m && m.begin(0) == 0
      t = m[0]; @i += t.length
      t =~ /[\.eE]/ ? t.to_f : t.to_i
    end
    def array
      @i += 1; out = []; ws
      if @s[@i] == ']'; @i += 1; return out; end
      loop do
        out << value; ws
        c = @s[@i]; @i += 1
        return out if c == ']'
        raise 'bad array' unless c == ','
      end
    end
    def object
      @i += 1; out = {}; ws
      if @s[@i] == '}'; @i += 1; return out; end
      loop do
        ws; k = string; ws
        raise 'bad object' unless @s[@i] == ':'
        @i += 1
        out[k] = value; ws
        c = @s[@i]; @i += 1
        return out if c == '}'
        raise 'bad object' unless c == ','
      end
    end
  end
  def self.parse(s); Parser.new(s).parse; end
  def self.generate(v)
    case v
    when Hash
      '{' + v.map { |k, val| generate(k.to_s) + ':' + generate(val) }.join(',') + '}'
    when Array
      '[' + v.map { |x| generate(x) }.join(',') + ']'
    when String
      '"' + v.gsub(/["]|\\|[\x00-\x1f]/) { |c|
        case c
        when '"' then '\\"'
        when '\\' then '\\\\'
        when "\n" then '\\n'
        when "\r" then '\\r'
        when "\t" then '\\t'
        else '\\u%04x' % c.ord
        end
      } + '"'
    when NilClass then 'null'
    when TrueClass then 'true'
    when FalseClass then 'false'
    when Time then generate(v.utc.iso8601)
    else v.to_s
    end
  end
end

class Row
  attr_accessor :fields, :raw
  def initialize(raw, fields = {})
    @raw = raw
    @fields = fields
  end
end

class Engine
  def initialize(query, output, alias_dir = nil, no_alias = false)
    @query = query || '*'
    @output = output || 'legacy'
    @alias_dir = alias_dir
    @no_alias = no_alias
  end

  def run(lines)
    rows = lines.map { |l| Row.new(l.chomp, {}) }
    parts = split_pipeline(@query).map(&:strip).reject(&:empty?)
    parts = expand_aliases(parts) unless @no_alias
    if parts.empty?
      parts = ['*']
    end
    filter = parts.shift
    rows = rows.select { |r| match_filter?(filter, r.raw) }
    aggregate_rows = false

    parts.each do |op|
      next if op.empty?
      if aggregate_op?(op)
        rows = aggregate(rows, op)
        aggregate_rows = true
      elsif op =~ /^sort\s+by\s+(.+?)(?:\s+(asc|desc))?$/i
        exprs = split_commas($1)
        desc = ($2 || '').downcase == 'desc'
        rows = rows.sort_by { |r| exprs.map { |e| comparable(eval_expr(e, r.fields, r.raw)) } }
        rows.reverse! if desc
      elsif op =~ /^limit\s+(-?\d+)$/i
        n = $1.to_i
        rows = n >= 0 ? rows.first(n) : rows.last(-n)
      elsif op =~ /^json(?:\s+from\s+(.+))?$/i
        src = $1&.strip
        out = []
        rows.each do |r|
          text = src ? value_to_s(get_field(r.fields, src)) : r.raw
          begin
            obj = MiniJSON.parse(text)
            if obj.is_a?(Hash)
              r.fields.merge!(flatten_json(obj))
              out << r
            else
              warn "error: Expected JSON object, found #{text}"
            end
          rescue StandardError
            warn "error: Expected JSON, found #{text}"
          end
        end
        rows = out
      elsif op =~ /^logfmt(?:\s+from\s+(.+))?$/i
        src = $1&.strip
        out = []
        rows.each do |r|
          text = src ? value_to_s(get_field(r.fields, src)) : r.raw
          parsed = parse_logfmt(text)
          if parsed.empty? && !text.strip.empty?
            warn "error: Expected logfmt, found #{text}"
          else
            r.fields.merge!(parsed)
            out << r
          end
        end
        rows = out
      elsif op =~ /^split(?:\(([^)]*)\))?(?:\s+on\s+(.+?))?(?:\s+as\s+(.+))?$/i
        input_field = $1&.strip
        sep = $2 ? strip_quotes($2.strip) : ','
        new_field = $3&.strip
        rows.each do |r|
          text = input_field && !input_field.empty? ? value_to_s(get_field(r.fields, input_field)) : r.raw
          key = new_field || (input_field && !input_field.empty? ? input_field : '_split')
          r.fields[key] = text.split(sep, -1).map { |v| convert(v.strip) }
        end
      elsif op =~ /^parse\s+regex\s+"((?:\\.|[^"])*)"(?:\s+from\s+(\S+))?(.*)$/i
        regex = Regexp.new(unescape($1))
        src = $2&.strip
        flags = $3 || ''
        nodrop = flags.include?('nodrop')
        out = []
        rows.each do |r|
          text = src ? value_to_s(get_field(r.fields, src)) : r.raw
          m = regex.match(text)
          if m
            m.names.each { |name| r.fields[name] = convert(m[name]) }
            out << r
          elsif nodrop
            out << r
          end
        end
        rows = out
      elsif op =~ /^parse\s+"((?:\\.|[^"])*)"(?:\s+from\s+(\S+))?\s+as\s+(.+)$/i
        pattern = unescape($1)
        src = $2&.strip
        rest = $3.strip
        nodrop = rest.sub!(/\s+nodrop\b/i, '')
        noconvert = rest.sub!(/\s+noconvert\b/i, '')
        names = split_commas(rest).map(&:strip)
        regex = parse_pattern_to_regex(pattern, names.length)
        out = []
        rows.each do |r|
          text = src ? value_to_s(get_field(r.fields, src)) : r.raw
          m = regex.match(text)
          if m
            names.each_with_index { |name, i| r.fields[name] = noconvert ? m[i + 1] : convert(m[i + 1]) }
            out << r
          elsif nodrop
            out << r
          end
        end
        rows = out
      elsif op =~ /^fields\s+(.+)$/i
        spec = $1.strip
        mode = :except
        if spec =~ /^(only|\+)\s+(.+)$/i
          mode = :only; spec = $2
        elsif spec =~ /^(except|-)\s+(.+)$/i
          mode = :except; spec = $2
        end
        keys = split_commas(spec).map { |x| field_name(x.strip) }
        rows.each do |r|
          if mode == :only
            r.fields.select! { |k, _| keys.include?(k) }
          else
            keys.each { |k| r.fields.delete(k) }
          end
        end
      elsif op =~ /^where\s+(.+)$/i
        expr = $1.strip
        rows = rows.select { |r| truthy?(eval_expr(expr, r.fields, r.raw)) }
      elsif op =~ /^total\((.+)\)(?:\s+as\s+(\S+))?$/i
        expr = $1.strip; name = $2 || '_total'; total = 0
        rows.each do |r|
          total += to_num(eval_expr(expr, r.fields, r.raw)).to_f
          r.fields[name] = normalize_num(total)
        end
      elsif op =~ /^timeslice\((.+)\)\s+(\d+)(ns|us|ms|s|m|h|d|w)(?:\s+as\s+(\S+))?$/i
        expr, amount, unit, name = $1.strip, $2.to_i, $3, ($4 || '_timeslice')
        seconds = amount * {'ns'=>1e-9,'us'=>1e-6,'ms'=>1e-3,'s'=>1,'m'=>60,'h'=>3600,'d'=>86400,'w'=>604800}[unit]
        rows.each do |r|
          t = eval_expr(expr, r.fields, r.raw)
          time = t.is_a?(Time) ? t : Time.parse(value_to_s(t)) rescue nil
          r.fields[name] = time ? Time.at((time.to_f / seconds).floor * seconds).utc.iso8601 : nil
        end
      elsif op =~ /^(.+)\s+as\s+([A-Za-z_][A-Za-z0-9_\.\[\]]*)$/i
        expr = $1.strip; name = field_name($2.strip)
        rows.each { |r| r.fields[name] = eval_expr(expr, r.fields, r.raw) }
      end
    end

    render(rows, aggregate_rows)
  end



  def expand_aliases(parts)
    aliases = load_aliases
    out = []
    parts.each do |part|
      if aliases.key?(part)
        out.concat(split_pipeline(aliases[part]).map(&:strip).reject(&:empty?))
      else
        out << part
      end
    end
    out
  end

  def load_aliases
    dirs = []
    if @alias_dir
      dirs << @alias_dir
    else
      d = Dir.pwd
      loop do
        dirs << File.join(d, '.agrind-aliases')
        parent = File.dirname(d)
        break if parent == d
        d = parent
      end
    end
    aliases = {}
    dirs.each do |dir|
      next unless Dir.exist?(dir)
      Dir.children(dir).sort.each do |fn|
        path = File.join(dir, fn)
        next unless File.file?(path)
        txt = File.read(path)
        key = txt[/keyword\s*=\s*"([^"]+)"/, 1]
        tmpl = txt[/template\s*=\s*"""(.*?)"""/m, 1] || txt[/template\s*=\s*"((?:\\.|[^"])*)"/m, 1]
        aliases[key] = tmpl.strip if key && tmpl
      rescue StandardError => e
        warn "Warning: could not load alias #{path}: #{e.message}"
      end
    end
    aliases
  end

  def split_pipeline(s)
    out = []; cur = +''; quote = false; depth = 0; i = 0
    while i < s.length
      c = s[i]
      if c == '"' && (i.zero? || s[i - 1] != '\\')
        quote = !quote
      elsif !quote
        depth += 1 if c == '(' || c == '['
        depth -= 1 if c == ')' || c == ']'
      end
      if c == '|' && !quote && depth.zero? && s[i + 1] != '|' && s[i - 1] != '|'
        out << cur; cur = +''
      else
        cur << c
      end
      i += 1
    end
    out << cur
    out
  end

  def aggregate_op?(op)
    op =~ /^(count(?:\(|\b)|sum\(|average\(|avg\(|min\(|max\(|p\d+\(|pct\d+\(|count_distinct\()/i
  end

  def aggregate(rows, op)
    agg_part, by_part = op.split(/\s+by\s+/i, 2)
    aggs = split_commas(agg_part).map(&:strip)
    bys = by_part ? split_commas(by_part).map(&:strip) : []
    groups = {}
    rows.each do |r|
      key_vals = bys.map { |b| eval_expr(b, r.fields, r.raw) }
      key = MiniJSON.generate(key_vals.map { |v| v.nil? ? nil : v })
      groups[key] ||= { values: key_vals, aggs: init_aggs(aggs) }
      update_aggs(groups[key][:aggs], aggs, r)
    end
    groups.values.map do |g|
      fields = {}
      bys.each_with_index { |b, i| fields[agg_key_name(b)] = g[:values][i] }
      finalize_aggs(g[:aggs], aggs).each { |k, v| fields[k] = v }
      Row.new('', fields)
    end
  end

  def init_aggs(aggs)
    aggs.map { |a| [agg_name(a), { count: 0, sum: 0.0, vals: [], set: Set.new }] }.to_h
  end

  def update_aggs(states, aggs, row)
    aggs.each do |a|
      name = agg_name(a); st = states[name]
      case a
      when /^count_distinct\((.+)\)/i
        st[:set] << eval_expr($1, row.fields, row.raw)
      when /^count(?:\((.*)\))?(?:\s+as\s+\S+)?$/i
        cond = $1
        st[:count] += 1 if cond.nil? || cond.empty? || truthy?(eval_expr(cond, row.fields, row.raw))
      when /^(sum|average|avg|min|max|p\d+|pct\d+)\((.+)\)/i
        v = to_num(eval_expr($2, row.fields, row.raw))
        if v
          st[:count] += 1
          st[:sum] += v
          st[:vals] << v
        end
      end
    end
  end

  def finalize_aggs(states, aggs)
    result = {}
    aggs.each do |a|
      name = agg_name(a); st = states[name]
      val = case a
            when /^count_distinct/i then st[:set].length
            when /^count/i then st[:count]
            when /^sum/i then normalize_num(st[:sum])
            when /^(average|avg)/i
              if st[:count].zero?
                nil
              else
                avg = st[:sum] / st[:count].to_f
                avg == avg.to_i ? avg.to_i : format('%.2f', avg)
              end
            when /^min/i then st[:vals].empty? ? nil : normalize_num(st[:vals].min)
            when /^max/i then st[:vals].empty? ? nil : normalize_num(st[:vals].max)
            when /^(?:p|pct)(\d+)/i
              percentile(st[:vals], $1.to_i)
            end
      result[name] = val
    end
    result
  end

  def agg_name(a)
    return $1 if a =~ /\s+as\s+([A-Za-z_][A-Za-z0-9_]*)\s*$/i
    case a
    when /^count_distinct/i then '_countDistinct'
    when /^count/i then '_count'
    when /^sum/i then '_sum'
    when /^(average|avg)/i then '_average'
    when /^min/i then '_min'
    when /^max/i then '_max'
    when /^(p\d+|pct\d+)/i then $1.sub(/^pct/i, 'p')
    else a
    end
  end

  def agg_key_name(expr)
    e = expr.strip
    field_name(e)
  end

  def percentile(vals, pct)
    return nil if vals.empty?
    arr = vals.sort
    idx = ((pct / 100.0) * (arr.length - 1)).floor
    normalize_num(arr[idx])
  end

  def render(rows, aggregate_rows)
    case @output
    when 'json'
      if aggregate_rows
        puts MiniJSON.generate(rows.map { |r| r.fields })
      else
        rows.each { |r| puts MiniJSON.generate(sorted_hash(r.fields)) }
      end
    when 'logfmt'
      rows.each { |r| puts sorted_hash(r.fields).map { |k, v| "#{k}=#{logfmt_val(v)}" }.join(' ') }
    when /^format=(.*)$/
      fmt = $1
      rows.each { |r| puts apply_format(fmt, r.fields) }
    else
      if aggregate_rows
        render_table(rows)
      else
        rows.each { |r| puts legacy_row(r.fields) }
      end
    end
  end

  def render_table(rows)
    return if rows.empty?
    keys = rows.flat_map { |r| r.fields.keys }.uniq
    widths = keys.map { |k| [k.length, *rows.map { |r| value_to_s(r.fields[k]).length }].max }
    header = keys.each_with_index.map { |k, i| k.ljust(widths[i]) }.join('        ')
    puts header
    puts '-' * [14, header.length + 8].max
    rows.each do |r|
      puts keys.each_with_index.map { |k, i| value_to_s(r.fields[k]).ljust(widths[i]) }.join('        ').rstrip
    end
  end

  def legacy_row(fields)
    sorted_hash(fields).map { |k, v| "[#{k}=#{display_val(v)}]" }.join('        ')
  end

  def sorted_hash(h)
    h.keys.sort.map { |k| [k, h[k]] }.to_h
  end

  def display_val(v)
    if v.is_a?(Array)
      '[' + v.map { |x| display_val(x) }.join(', ') + ']'
    elsif v.is_a?(Hash)
      '{' + v.map { |kk, vv| "#{kk}:#{display_val(vv)}" }.join(', ') + '}'
    else
      value_to_s(v)
    end
  end

  def logfmt_val(v)
    s = display_val(v)
    s =~ /\s/ ? s : s
  end

  def apply_format(fmt, fields)
    fmt.gsub(/\{([^{}]+)\}/) { value_to_s(get_field(fields, Regexp.last_match(1))) }
  end

  def match_filter?(filter, text)
    f = filter.to_s.strip
    return true if f.empty? || f == '*'
    expr = f.gsub(/\bAND\b/i, '&&').gsub(/\bOR\b/i, '||').gsub(/\bNOT\b/i, '!')
    tokens = expr.scan(/"(?:\\.|[^"])*"|\(|\)|&&|\|\||!|[^\s()]+/)
    ruby = tokens.map do |t|
      case t
      when '&&', '||', '!', '(', ')' then t
      when /^"(.*)"$/m
        "text.include?(#{t})"
      else
        pat = t.downcase.gsub('*', '.*')
        "!!(text.downcase =~ /#{Regexp.escape(pat).gsub('\\.\\*', '.*')}/)"
      end
    end.join(' ')
    !!eval(ruby)
  rescue StandardError
    true
  end

  def eval_expr(expr, fields, raw = '')
    e = expr.strip
    return nil if e.empty?
    return strip_quotes(e) if quoted?(e)
    return e.to_i if e =~ /^-?\d+$/
    return e.to_f if e =~ /^-?\d+\.\d+$/
    return true if e.downcase == 'true'
    return false if e.downcase == 'false'
    return nil if e.downcase == 'null' || e.downcase == 'none'

    if balanced_outer_parens?(e)
      return eval_expr(e[1...-1], fields, raw)
    end
    if e =~ /^if\((.*)\)$/i
      args = split_commas($1)
      return truthy?(eval_expr(args[0], fields, raw)) ? eval_expr(args[1], fields, raw) : eval_expr(args[2], fields, raw)
    end

    [[' or ', '||'], [' and ', '&&'], ['||', '||'], ['&&', '&&']].each do |needle, op|
      idx = find_top_op(e, needle)
      next unless idx
      left = e[0...idx]; right = e[(idx + needle.length)..]
      return op == '&&' ? (truthy?(eval_expr(left, fields, raw)) && truthy?(eval_expr(right, fields, raw))) : (truthy?(eval_expr(left, fields, raw)) || truthy?(eval_expr(right, fields, raw)))
    end
    if e.start_with?('!')
      return !truthy?(eval_expr(e[1..], fields, raw))
    end
    ['==', '!=', '<>', '<=', '>=', '<', '>'].each do |op|
      idx = find_top_op(e, op)
      next unless idx
      a = eval_expr(e[0...idx], fields, raw); b = eval_expr(e[(idx + op.length)..], fields, raw)
      return compare(a, b, op)
    end
    [['+', '-'], ['*', '/']].each do |ops|
      idx_op = find_top_arith(e, ops)
      if idx_op
        idx, op = idx_op
        a = eval_expr(e[0...idx], fields, raw); b = eval_expr(e[(idx + 1)..], fields, raw)
        return arith(a, b, op)
      end
    end
    if e =~ /^([A-Za-z_][A-Za-z0-9_]*)\((.*)\)$/
      fn = $1; args = split_commas($2).map { |a| eval_expr(a, fields, raw) }
      return call_fn(fn, args)
    end
    v = get_field(fields, e)
    return v unless v.nil?
    e == '_raw' ? raw : nil
  end

  def call_fn(fn, args)
    case fn
    when 'abs' then to_num(args[0])&.abs
    when 'ceil' then to_num(args[0])&.ceil
    when 'floor' then to_num(args[0])&.floor
    when 'round' then to_num(args[0])&.round
    when 'sqrt' then Math.sqrt(to_num(args[0]))
    when 'sin' then Math.sin(to_num(args[0]))
    when 'cos' then Math.cos(to_num(args[0]))
    when 'tan' then Math.tan(to_num(args[0]))
    when 'asin' then Math.asin(to_num(args[0]))
    when 'acos' then Math.acos(to_num(args[0]))
    when 'atan' then Math.atan(to_num(args[0]))
    when 'atan2' then Math.atan2(to_num(args[0]), to_num(args[1]))
    when 'exp' then Math.exp(to_num(args[0]))
    when 'log' then Math.log(to_num(args[0]))
    when 'log10' then Math.log10(to_num(args[0]))
    when 'cbrt' then Math.cbrt(to_num(args[0])) rescue to_num(args[0]) ** (1.0 / 3)
    when 'hypot' then Math.hypot(to_num(args[0]), to_num(args[1]))
    when 'toDegrees' then to_num(args[0]) * 180.0 / Math::PI
    when 'toRadians' then to_num(args[0]) * Math::PI / 180.0
    when 'concat' then args.map { |x| value_to_s(x) }.join
    when 'contains' then value_to_s(args[0]).include?(value_to_s(args[1]))
    when 'length' then value_to_s(args[0]).length
    when 'num' then to_num(args[0])
    when 'parseHex' then value_to_s(args[0]).to_i(16)
    when 'substring'
      s = value_to_s(args[0]); a = to_num(args[1]).to_i; b = args[2] ? to_num(args[2]).to_i : s.length; s[a...b]
    when 'toLowerCase' then value_to_s(args[0]).downcase
    when 'toUpperCase' then value_to_s(args[0]).upcase
    when 'isNull' then args[0].nil?
    when 'isEmpty' then args[0].nil? || value_to_s(args[0]).empty?
    when 'isBlank' then args[0].nil? || value_to_s(args[0]).strip.empty?
    when 'isNumeric' then !to_num(args[0]).nil?
    when 'parseDate' then Time.parse(value_to_s(args[0])) rescue nil
    when 'now' then Time.now
    else nil
    end
  rescue StandardError
    nil
  end

  def compare(a, b, op)
    aa = to_num(a); bb = to_num(b)
    if aa && bb
      a = aa; b = bb
    end
    c = a <=> b
    case op
    when '==' then a == b
    when '!=', '<>' then a != b
    when '<' then c && c < 0
    when '>' then c && c > 0
    when '<=' then c && c <= 0
    when '>=' then c && c >= 0
    end
  end

  def arith(a, b, op)
    if op == '+' && (a.is_a?(String) || b.is_a?(String))
      return value_to_s(a) + value_to_s(b)
    end
    x = to_num(a); y = to_num(b)
    return nil unless x && y
    normalize_num({ '+' => x + y, '-' => x - y, '*' => x * y, '/' => y.zero? ? nil : x / y.to_f }[op])
  end

  def find_top_op(s, op)
    depth = 0; quote = false; i = 0
    while i <= s.length - op.length
      c = s[i]
      quote = !quote if c == '"' && s[i - 1] != '\\'
      unless quote
        depth += 1 if c == '('
        depth -= 1 if c == ')'
        return i if depth.zero? && s[i, op.length].downcase == op.downcase
      end
      i += 1
    end
    nil
  end

  def find_top_arith(s, ops)
    depth = 0; quote = false
    (s.length - 1).downto(0) do |i|
      c = s[i]
      quote = !quote if c == '"' && (i.zero? || s[i - 1] != '\\')
      next if quote
      depth += 1 if c == ')'
      depth -= 1 if c == '('
      next unless depth.zero? && ops.include?(c)
      next if c == '-' && (i.zero? || '+-*/(<>=!&|,'.include?(s[i - 1]))
      return [i, c]
    end
    nil
  end

  def balanced_outer_parens?(s)
    return false unless s.start_with?('(') && s.end_with?(')')
    depth = 0; quote = false
    s.chars.each_with_index do |c, i|
      quote = !quote if c == '"' && s[i - 1] != '\\'
      next if quote
      depth += 1 if c == '('
      depth -= 1 if c == ')'
      return false if depth.zero? && i < s.length - 1
    end
    depth.zero?
  end

  def split_commas(s)
    out = []; cur = +''; depth = 0; quote = false
    s.to_s.each_char.with_index do |c, i|
      if c == '"' && s[i - 1] != '\\'
        quote = !quote
      elsif !quote
        depth += 1 if c == '(' || c == '['
        depth -= 1 if c == ')' || c == ']'
      end
      if c == ',' && depth.zero? && !quote
        out << cur.strip; cur = +''
      else
        cur << c
      end
    end
    out << cur.strip unless cur.strip.empty?
    out
  end

  def parse_pattern_to_regex(pattern, captures)
    parts = pattern.split('*', -1).map { |p| Regexp.escape(p).gsub(/\\\s+/, '\\s+') }
    rx = +'\A'
    captures.times do |i|
      rx << parts[i].to_s
      rx << (i == captures - 1 ? '(.*?)' : '(.*)')
    end
    rx << parts[captures..].join('.*') if parts.length > captures
    rx << '\z'
    Regexp.new(rx)
  end

  def parse_logfmt(text)
    h = {}
    text.scan(/([A-Za-z0-9_.\-]+)=((?:"(?:\\.|[^"])*")|\S*)/) do |k, v|
      h[k] = convert(strip_quotes(v))
    end
    h
  end

  def flatten_json(obj, prefix = nil, out = {})
    obj.each { |k, v| out[k.to_s] = v }
    out
  end

  def get_field(fields, name)
    n = field_name(name.to_s.strip)
    return fields[n] if fields.key?(n)
    cur = fields
    n.scan(/[^.\[\]]+|\[-?\d+\]/).each do |part|
      if part =~ /^\[(-?\d+)\]$/
        return nil unless cur.is_a?(Array)
        cur = cur[$1.to_i]
      else
        if cur.is_a?(Hash)
          cur = cur[part] || cur[part.to_sym]
        else
          return fields[n] if fields.key?(n)
          return nil
        end
      end
    end
    cur
  end

  def field_name(s)
    s =~ /^\["((?:\\.|[^"])*)"\]$/ ? unescape($1) : s
  end

  def convert(v)
    return nil if v.nil?
    s = v.to_s
    return true if s == 'true'
    return false if s == 'false'
    return nil if s == 'null'
    return s.to_i if s =~ /^-?\d+$/ && !(s =~ /^-?0\d+/)
    return s.to_f if s =~ /^-?\d+\.\d+$/
    s
  end

  def to_num(v)
    return v if v.is_a?(Numeric)
    return nil if v.nil?
    s = v.to_s
    return s.to_i if s =~ /^-?\d+$/
    return s.to_f if s =~ /^-?\d+(?:\.\d+)?$/
    nil
  end

  def normalize_num(v, fixed = nil)
    return nil if v.nil?
    return v if v.is_a?(Integer)
    return v.to_i if fixed.nil? && v.to_f == v.to_i
    fixed ? format("%.#{fixed}f", v) : v
  end

  def comparable(v)
    v.nil? ? '' : v
  end

  def truthy?(v)
    !(v.nil? || v == false || v == 0 || v == '')
  end

  def quoted?(s)
    s.length >= 2 && s[0] == '"' && s[-1] == '"'
  end

  def strip_quotes(s)
    quoted?(s) ? unescape(s[1...-1]) : s
  end

  def unescape(s)
    s.gsub(/\\(["\\nrt])/) { { 'n' => "\n", 'r' => "\r", 't' => "\t", '"' => '"', '\\' => '\\' }[$1] || $1 }
  end

  def value_to_s(v)
    case v
    when nil then ''
    when Time then v.utc.iso8601
    when Float then v == v.to_i ? v.to_i.to_s : v.to_s
    else v.to_s
    end
  end
end

def usage(long = false)
  if long
    <<~TXT
      Usage: executable [OPTIONS] [QUERY]

      Arguments:
        [QUERY]
                The query

      Options:
        -f, --file <FILE>
                Optionally reads from a file instead of Stdin

        -m, --format <FORMAT>
                DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output

        -o, --output <OUTPUT>
                Set output format. Options: 
                - `json`,
                - `logfmt`
                - `format=<rust format string>` (eg. -o format='{src} => {dst}'
                - `legacy` The original output format, auto aligning [k=v]

        -a, --alias-dir <ALIAS_DIR>
                Specifies an alternative directory to use for aliases. Defaults to `.agrind-aliases` in all parent directories.

            --no-alias
                Disables aliases

        -h, --help
                Print help (see a summary with '-h')

        -V, --version
                Print version

      For more details + docs, see https://github.com/rcoh/angle-grinder
    TXT
  else
    <<~TXT
      Usage: executable [OPTIONS] [QUERY]

      Arguments:
        [QUERY]  The query

      Options:
        -f, --file <FILE>            Optionally reads from a file instead of Stdin
        -m, --format <FORMAT>        DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output
        -o, --output <OUTPUT>        Set output format. One of (json|legacy|format=<rust fmt str>|logfmt)
        -a, --alias-dir <ALIAS_DIR>  Specifies an alternative directory to use for aliases. Defaults to `.agrind-aliases` in all parent directories.
            --no-alias               Disables aliases
        -h, --help                   Print help (see more with '--help')
        -V, --version                Print version

      For more details + docs, see https://github.com/rcoh/angle-grinder
    TXT
  end
end

args = ARGV.dup
file = nil
output = 'legacy'
query = nil
alias_dir = nil
no_alias = false
until args.empty?
  a = args.shift
  case a
  when '-h'
    print usage(false); exit 0
  when '--help'
    print usage(true); exit 0
  when '-V', '--version'
    puts VERSION; exit 0
  when '-f', '--file'
    file = args.shift
  when '-o', '--output'
    output = args.shift || 'legacy'
  when '-m', '--format'
    output = 'format=' + (args.shift || '')
  when '-a', '--alias-dir'
    alias_dir = args.shift
  when '--no-alias'
    no_alias = true
  else
    query = a
    query += ' ' + args.join(' ') unless args.empty?
    break
  end
end

input = file ? File.readlines(file) : STDIN.readlines
Engine.new(query, output, alias_dir, no_alias).run(input)
