#!/usr/bin/env ruby
# frozen_string_literal: true

module Blake3
  MASK = 0xffffffff
  IV = [
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
    0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19
  ].freeze
  MSG = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
    [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8],
    [3, 4, 10, 12, 13, 2, 7, 14, 6, 5, 9, 0, 11, 15, 8, 1],
    [10, 7, 12, 9, 14, 3, 13, 15, 4, 0, 11, 2, 5, 8, 1, 6],
    [12, 13, 9, 11, 15, 10, 14, 8, 7, 2, 5, 3, 0, 1, 6, 4],
    [9, 14, 11, 5, 8, 12, 15, 1, 13, 3, 0, 10, 2, 6, 4, 7],
    [11, 15, 5, 0, 1, 9, 8, 6, 14, 10, 2, 12, 3, 4, 7, 13]
  ].freeze

  CHUNK_LEN = 1024
  BLOCK_LEN = 64
  OUT_LEN = 32
  CHUNK_START = 1
  CHUNK_END = 2
  PARENT = 4
  ROOT = 8
  KEYED_HASH = 16
  DERIVE_KEY_CONTEXT = 32
  DERIVE_KEY_MATERIAL = 64

  Output = Struct.new(:input_cv, :block_words, :counter, :block_len, :flags, keyword_init: true)

  module_function

  def rotr(x, n)
    (((x & MASK) >> n) | ((x << (32 - n)) & MASK)) & MASK
  end

  def g(s, a, b, c, d, mx, my)
    s[a] = (s[a] + s[b] + mx) & MASK
    s[d] = rotr(s[d] ^ s[a], 16)
    s[c] = (s[c] + s[d]) & MASK
    s[b] = rotr(s[b] ^ s[c], 12)
    s[a] = (s[a] + s[b] + my) & MASK
    s[d] = rotr(s[d] ^ s[a], 8)
    s[c] = (s[c] + s[d]) & MASK
    s[b] = rotr(s[b] ^ s[c], 7)
  end

  def round(s, m, p)
    g(s, 0, 4, 8, 12, m[p[0]], m[p[1]])
    g(s, 1, 5, 9, 13, m[p[2]], m[p[3]])
    g(s, 2, 6, 10, 14, m[p[4]], m[p[5]])
    g(s, 3, 7, 11, 15, m[p[6]], m[p[7]])
    g(s, 0, 5, 10, 15, m[p[8]], m[p[9]])
    g(s, 1, 6, 11, 12, m[p[10]], m[p[11]])
    g(s, 2, 7, 8, 13, m[p[12]], m[p[13]])
    g(s, 3, 4, 9, 14, m[p[14]], m[p[15]])
  end

  def words_from_bytes(bytes, count = nil)
    padded = bytes.b.ljust(count ? count * 4 : bytes.bytesize, "\0")
    padded.unpack('V*')
  end

  def block_words(block)
    words_from_bytes(block, 16)
  end

  def compress(cv, block, counter, block_len, flags)
    m = block.is_a?(Array) ? block : block_words(block)
    s = cv + IV[0, 4] + [counter & MASK, (counter >> 32) & MASK, block_len, flags]
    MSG.each { |p| round(s, m, p) }
    s
  end

  def chaining_value(out)
    s = compress(out.input_cv, out.block_words, out.counter, out.block_len, out.flags)
    8.times.map { |i| (s[i] ^ s[i + 8]) & MASK }
  end

  def output_block(out, block_counter)
    s = compress(out.input_cv, out.block_words, block_counter, out.block_len, out.flags | ROOT)
    words = []
    8.times { |i| words << ((s[i] ^ s[i + 8]) & MASK) }
    8.times { |i| words << ((s[i + 8] ^ out.input_cv[i]) & MASK) }
    words.pack('V*')
  end

  def parent_output(left_cv, right_cv, key_words, flags)
    Output.new(
      input_cv: key_words,
      block_words: left_cv + right_cv,
      counter: 0,
      block_len: BLOCK_LEN,
      flags: flags | PARENT
    )
  end

  def parent_cv(left_cv, right_cv, key_words, flags)
    chaining_value(parent_output(left_cv, right_cv, key_words, flags))
  end

  def chunk_output(chunk, chunk_counter, key_words, flags)
    cv = key_words.dup
    blocks = []
    offset = 0
    if chunk.empty?
      blocks << ''.b
    else
      while offset < chunk.bytesize
        blocks << chunk.byteslice(offset, BLOCK_LEN)
        offset += BLOCK_LEN
      end
    end
    blocks.each_with_index do |block, i|
      block_flags = flags
      block_flags |= CHUNK_START if i.zero?
      block_flags |= CHUNK_END if i == blocks.length - 1
      words = block_words(block)
      if i == blocks.length - 1
        return Output.new(
          input_cv: cv,
          block_words: words,
          counter: chunk_counter,
          block_len: block.bytesize,
          flags: block_flags
        )
      end
      cv = chaining_value(Output.new(
        input_cv: cv,
        block_words: words,
        counter: chunk_counter,
        block_len: BLOCK_LEN,
        flags: block_flags
      ))
    end
  end

  def root_output(data, key_words, flags)
    cvs = []
    offset = 0
    chunk_counter = 0
    if data.empty?
      return chunk_output(''.b, 0, key_words, flags)
    end
    while offset < data.bytesize
      chunk = data.byteslice(offset, CHUNK_LEN)
      out = chunk_output(chunk, chunk_counter, key_words, flags)
      cvs << chaining_value(out)
      offset += CHUNK_LEN
      chunk_counter += 1
    end
    return chunk_output(data, 0, key_words, flags) if cvs.length == 1

    level = cvs
    while level.length > 1
      next_level = []
      i = 0
      while i < level.length
        if i + 1 < level.length
          next_level << parent_cv(level[i], level[i + 1], key_words, flags)
          i += 2
        else
          next_level << level[i]
          i += 1
        end
      end
      level = next_level
    end

    # Reconstruct the final parent output for correct ROOT/XOF handling.
    roots = cvs
    while roots.length > 2
      next_roots = []
      i = 0
      while i < roots.length
        if i + 1 < roots.length
          next_roots << parent_cv(roots[i], roots[i + 1], key_words, flags)
          i += 2
        else
          next_roots << roots[i]
          i += 1
        end
      end
      roots = next_roots
    end
    parent_output(roots[0], roots[1], key_words, flags)
  end

  def digest(data, length: OUT_LEN, seek: 0, key: nil, derive_context: nil)
    data = data.b
    if derive_context
      context_key = digest(derive_context.b, length: OUT_LEN, seek: 0, flags_override: DERIVE_KEY_CONTEXT)
      key_words = words_from_bytes(context_key, 8)
      flags = DERIVE_KEY_MATERIAL
    elsif key
      key_words = words_from_bytes(key.b, 8)
      flags = KEYED_HASH
    else
      key_words = IV.dup
      flags = 0
    end
    xof(data, key_words, flags, length, seek)
  end

  def digest_with_flags(data, length:, seek:, flags_override:)
    xof(data.b, IV.dup, flags_override, length, seek)
  end

  def xof(data, key_words, flags, length, seek)
    out = root_output(data, key_words, flags)
    result = ''.b
    counter = seek / BLOCK_LEN
    skip = seek % BLOCK_LEN
    while result.bytesize < length
      block = output_block(out, counter)
      block = block.byteslice(skip, block.bytesize - skip) if skip.positive?
      result << block
      counter += 1
      skip = 0
    end
    result.byteslice(0, length)
  end

  class << self
    alias digest_original digest
  end

  def digest(data, length: OUT_LEN, seek: 0, key: nil, derive_context: nil, flags_override: nil)
    return digest_with_flags(data, length: length, seek: seek, flags_override: flags_override) if flags_override

    digest_original(data, length: length, seek: seek, key: key, derive_context: derive_context)
  end
end

class B3Sum
  HELP_LONG = <<~HELP
    Usage: executable [OPTIONS] [FILE]...

    Arguments:
      [FILE]...
              Files to hash, or checkfiles to check
              
              When no file is given, or when - is given, read standard input.

    Options:
          --keyed
              Use the keyed mode, reading the 32-byte key from stdin

          --derive-key <CONTEXT>
              Use the key derivation mode, with the given context string
              
              Cannot be used with --keyed.

      -l, --length <LEN>
              The number of output bytes, before hex encoding
              
              [default: 32]

          --seek <SEEK>
              The starting output byte offset, before hex encoding
              
              [default: 0]

          --num-threads <NUM>
              The maximum number of threads to use
              
              By default, this is the number of logical cores. If this flag is omitted, or if its value
              is 0, RAYON_NUM_THREADS is also respected.

          --no-mmap
              Disable memory mapping
              
              Currently this also disables multithreading.

          --no-names
              Omit filenames in the output

          --raw
              Write raw output bytes to stdout, rather than hex
              
              --no-names is implied. In this case, only a single input is allowed.

          --tag
              Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]

      -c, --check
              Read BLAKE3 sums from the [FILE]s and check them

          --quiet
              Skip printing OK for each checked file
              
              Must be used with --check.

      -h, --help
              Print help (see a summary with '-h')

      -V, --version
              Print version
  HELP

  HELP_SHORT = <<~HELP
    Usage: executable [OPTIONS] [FILE]...

    Arguments:
      [FILE]...  Files to hash, or checkfiles to check

    Options:
          --keyed                 Use the keyed mode, reading the 32-byte key from stdin
          --derive-key <CONTEXT>  Use the key derivation mode, with the given context string
      -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]
          --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]
          --num-threads <NUM>     The maximum number of threads to use
          --no-mmap               Disable memory mapping
          --no-names              Omit filenames in the output
          --raw                   Write raw output bytes to stdout, rather than hex
          --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]
      -c, --check                 Read BLAKE3 sums from the [FILE]s and check them
          --quiet                 Skip printing OK for each checked file
      -h, --help                  Print help (see more with '--help')
      -V, --version               Print version
  HELP

  def initialize(argv)
    @argv = argv.dup
    @length = 32
    @seek = 0
    @files = []
    @keyed = false
    @derive_context = nil
    @no_names = false
    @raw = false
    @tag = false
    @check = false
    @quiet = false
  end

  def run
    parse!
    validate!
    @check ? run_check : run_hash
  rescue Errno::ENOENT => e
    warn "executable: #{e.message}"
    exit 1
  rescue ArgumentError => e
    warn "error: #{e.message}"
    exit 2
  end

  def parse!
    until @argv.empty?
      arg = @argv.shift
      case arg
      when '--help'
        print HELP_LONG
        exit 0
      when '-h'
        print HELP_SHORT
        exit 0
      when '--version', '-V'
        puts 'b3sum 1.8.4'
        exit 0
      when '--keyed'
        @keyed = true
      when '--derive-key'
        @derive_context = take_value(arg)
      when /^--derive-key=(.*)/
        @derive_context = Regexp.last_match(1)
      when '-l', '--length'
        @length = parse_u64(take_value(arg), 'length')
      when /^--length=(.*)/
        @length = parse_u64(Regexp.last_match(1), 'length')
      when '--seek'
        @seek = parse_u64(take_value(arg), 'seek')
      when /^--seek=(.*)/
        @seek = parse_u64(Regexp.last_match(1), 'seek')
      when '--num-threads'
        parse_u64(take_value(arg), 'num-threads')
      when /^--num-threads=(.*)/
        parse_u64(Regexp.last_match(1), 'num-threads')
      when '--no-mmap'
      when '--no-names'
        @no_names = true
      when '--raw'
        @raw = true
        @no_names = true
      when '--tag'
        @tag = true
      when '-c', '--check'
        @check = true
      when '--quiet'
        @quiet = true
      when '--'
        @files.concat(@argv)
        @argv.clear
      when /^-./
        # Support compact -l32; other compact flags are uncommon but harmless.
        if arg.start_with?('-l') && arg.length > 2
          @length = parse_u64(arg[2..], 'length')
        else
          raise ArgumentError, "unexpected argument '#{arg}' found"
        end
      else
        @files << arg
      end
    end
  end

  def take_value(flag)
    raise ArgumentError, "a value is required for '#{flag}' but none was supplied" if @argv.empty?

    @argv.shift
  end

  def parse_u64(value, name)
    Integer(value, 10).tap do |n|
      raise ArgumentError, "#{name} must be non-negative" if n.negative?
    end
  rescue ArgumentError
    raise ArgumentError, "invalid value '#{value}' for '#{name}'"
  end

  def validate!
    raise ArgumentError, 'the argument --derive-key <CONTEXT> cannot be used with --keyed' if @keyed && @derive_context
    raise ArgumentError, 'the argument --quiet can only be used with --check' if @quiet && !@check
    raise ArgumentError, 'the argument --raw cannot be used with --check' if @raw && @check
    raise ArgumentError, 'the argument --raw cannot be used with multiple inputs' if @raw && @files.length > 1
  end

  def key
    return nil unless @keyed

    k = STDIN.binmode.read(32)
    raise ArgumentError, 'expected 32 key bytes from stdin' unless k && k.bytesize == 32

    k
  end

  def run_hash
    k = key
    inputs = @files.empty? ? ['-'] : @files
    inputs.each do |path|
      data = path == '-' ? STDIN.binmode.read : File.binread(path)
      bytes = Blake3.digest(data, length: @length, seek: @seek, key: k, derive_context: @derive_context)
      if @raw
        STDOUT.binmode.write(bytes)
      elsif @no_names
        puts bytes.unpack1('H*')
      elsif @tag
        name, escaped = escape_name(path)
        prefix = escaped ? '\\' : ''
        puts "#{prefix}BLAKE3 (#{name}) = #{bytes.unpack1('H*')}"
      else
        name, escaped = escape_name(path)
        prefix = escaped ? '\\' : ''
        puts "#{prefix}#{bytes.unpack1('H*')}  #{name}"
      end
    end
  end

  def escape_name(name)
    escaped = false
    out = name.each_char.map do |ch|
      case ch
      when "\\"
        escaped = true
        "\\\\"
      when "\n"
        escaped = true
        "\\n"
      when "\r"
        escaped = true
        "\\r"
      else
        ch
      end
    end.join
    [out, escaped]
  end

  def unescape_name(name)
    name.gsub(/\\[\\nr]/) do |m|
      case m
      when '\\\\' then "\\"
      when '\\n' then "\n"
      when '\\r' then "\r"
      end
    end
  end

  def parse_check_line(line)
    s = line.chomp
    escaped = s.start_with?('\\')
    s = s[1..] if escaped
    if (m = /\ABLAKE3 \((.*)\) = ([0-9a-fA-F]+)\z/.match(s))
      [m[2].downcase, escaped ? unescape_name(m[1]) : m[1]]
    elsif (m = /\A([0-9a-fA-F]+) [ *](.+)\z/.match(s))
      [m[1].downcase, escaped ? unescape_name(m[2]) : m[2]]
    end
  end

  def run_check
    k = key
    checkfiles = @files.empty? ? ['-'] : @files
    failed = false
    malformed = 0
    checked = 0
    checkfiles.each do |checkfile|
      content = checkfile == '-' ? STDIN.read : File.read(checkfile)
      content.each_line.with_index(1) do |line, lineno|
        parsed = parse_check_line(line)
        unless parsed
          malformed += 1
          warn "#{checkfile}:#{lineno}: improperly formatted BLAKE3 checksum line"
          next
        end
        expected, name = parsed
        actual = Blake3.digest(File.binread(name), length: expected.length / 2, key: k, derive_context: @derive_context).unpack1('H*')
        checked += 1
        if actual == expected
          puts "#{name}: OK" unless @quiet
        else
          failed = true
          puts "#{name}: FAILED"
        end
      rescue Errno::ENOENT => e
        failed = true
        warn "executable: #{name}: #{e.message}"
        puts "#{name}: FAILED open or read"
      end
    end
    warn "executable: WARNING: #{malformed} line is improperly formatted" if malformed == 1
    warn "executable: WARNING: #{malformed} lines are improperly formatted" if malformed > 1
    warn 'executable: no properly formatted checksum lines found' if checked.zero?
    exit((failed || malformed.positive? || checked.zero?) ? 1 : 0)
  end
end

B3Sum.new(ARGV).run
