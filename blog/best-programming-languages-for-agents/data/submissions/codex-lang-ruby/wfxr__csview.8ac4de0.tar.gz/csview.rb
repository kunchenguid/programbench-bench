#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = 'csview 1.3.4'

Encoding.default_external = Encoding::UTF_8
Encoding.default_internal = Encoding::UTF_8

HELP = <<~TEXT
  A high performance csv viewer with cjk/emoji support.

  Usage: executable [OPTIONS] [FILE]

  Arguments:
    [FILE]
            File to view

  Options:
    -H, --no-headers
            Specify that the input has no header row
    -n, --number
            Prepend a column of line numbers to the table
    -t, --tsv
            Use '\\t' as delimiter for tsv
    -d, --delimiter <DELIMITER>
            Specify the field delimiter [default: ,]
    -s, --style <STYLE>
            Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
            rounded, reinforced, markdown, grid]
    -p, --padding <PADDING>
            Specify padding for table cell [default: 1]
    -i, --indent <INDENT>
            Specify global indent for table [default: 0]
        --sniff <LIMIT>
            Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
            [default: 1000]
        --header-align <HEADER_ALIGN>
            Specify the alignment of the table header [default: center] [possible values: left,
            center, right]
        --body-align <BODY_ALIGN>
            Specify the alignment of the table body [default: left] [possible values: left, center,
            right]
    -P, --disable-pager
            Disable pager
    -h, --help
            Print help
    -V, --version
            Print version
TEXT

VALID_STYLES = %w[none ascii ascii2 sharp rounded reinforced markdown grid].freeze
VALID_ALIGNS = %w[left center right].freeze

STYLE_CHARS = {
  'ascii' => { tl: '+', tm: '+', tr: '+', ml: '+', mm: '+', mr: '+', bl: '+', bm: '+', br: '+', h: '-', v: '|' },
  'sharp' => { tl: '┌', tm: '┬', tr: '┐', ml: '├', mm: '┼', mr: '┤', bl: '└', bm: '┴', br: '┘', h: '─', v: '│' },
  'rounded' => { tl: '╭', tm: '┬', tr: '╮', ml: '├', mm: '┼', mr: '┤', bl: '╰', bm: '┴', br: '╯', h: '─', v: '│' },
  'reinforced' => { tl: '┏', tm: '┬', tr: '┓', ml: '├', mm: '┼', mr: '┤', bl: '┗', bm: '┴', br: '┛', h: '─', v: '│' },
  'grid' => { tl: '┌', tm: '┬', tr: '┐', ml: '├', mm: '┼', mr: '┤', bl: '└', bm: '┴', br: '┘', h: '─', v: '│' }
}.freeze

def die_arg(message)
  warn message
  warn
  warn "For more information, try '--help'."
  exit 2
end

def parse_uint(value, option)
  parsed = Integer(value)
  raise ArgumentError if parsed.negative?
  parsed
rescue ArgumentError
  die_arg("error: invalid value '#{value}' for '#{option}': invalid digit found in string")
end

def take_arg(args, i, option)
  if i + 1 >= args.length
    die_arg("error: a value is required for '#{option} <#{option.sub(/^--?/, '').upcase}>' but none was supplied")
  end
  [args[i + 1], i + 1]
end

def parse_args(argv)
  opts = {
    headers: true,
    number: false,
    delimiter: ',',
    style: 'sharp',
    padding: 1,
    indent: 0,
    sniff: 1000,
    header_align: 'center',
    body_align: 'left',
    file: nil
  }

  i = 0
  while i < argv.length
    arg = argv[i]
    if arg == '--'
      rest = argv[(i + 1)..] || []
      if rest.length > 1 || (opts[:file] && !rest.empty?)
        die_arg("error: unexpected argument '#{rest.last}' found\n\nUsage: executable [OPTIONS] [FILE]")
      end
      opts[:file] ||= rest.first
      break
    end
    if arg.start_with?('--') && arg.include?('=')
      arg, value = arg.split('=', 2)
      argv.insert(i + 1, value)
    end
    case arg
    when '-H', '--no-headers'
      opts[:headers] = false
    when '-n', '--number'
      opts[:number] = true
    when '-t', '--tsv'
      opts[:delimiter] = "\t"
    when '-P', '--disable-pager'
      # Output is direct in this implementation.
    when '-h', '--help'
      print HELP
      exit 0
    when '-V', '--version'
      puts VERSION
      exit 0
    when '-d', '--delimiter'
      value, i = take_arg(argv, i, '--delimiter')
      die_arg("error: invalid value '#{value}' for '--delimiter <DELIMITER>': too many characters in string") if value.length != 1
      opts[:delimiter] = value
    when '-s', '--style'
      value, i = take_arg(argv, i, '--style')
      unless VALID_STYLES.include?(value)
        die_arg("error: invalid value '#{value}' for '--style <STYLE>'\n  [possible values: none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid]")
      end
      opts[:style] = value
    when '-p', '--padding'
      value, i = take_arg(argv, i, '--padding')
      opts[:padding] = parse_uint(value, '--padding <PADDING>')
    when '-i', '--indent'
      value, i = take_arg(argv, i, '--indent')
      opts[:indent] = parse_uint(value, '--indent <INDENT>')
    when '--sniff'
      value, i = take_arg(argv, i, '--sniff')
      opts[:sniff] = parse_uint(value, '--sniff <LIMIT>')
    when '--header-align'
      value, i = take_arg(argv, i, '--header-align')
      die_arg("error: invalid value '#{value}' for '--header-align <HEADER_ALIGN>'\n  [possible values: left, center, right]") unless VALID_ALIGNS.include?(value)
      opts[:header_align] = value
    when '--body-align'
      value, i = take_arg(argv, i, '--body-align')
      die_arg("error: invalid value '#{value}' for '--body-align <BODY_ALIGN>'\n  [possible values: left, center, right]") unless VALID_ALIGNS.include?(value)
      opts[:body_align] = value
    else
      if arg.start_with?('-')
        die_arg("error: unexpected argument '#{arg}' found\n\n  tip: to pass '#{arg}' as a value, use '-- #{arg}'\n\nUsage: executable [OPTIONS] [FILE]")
      elsif opts[:file]
        die_arg("error: unexpected argument '#{arg}' found\n\nUsage: executable [OPTIONS] [FILE]")
      else
        opts[:file] = arg
      end
    end
    i += 1
  end

  opts
end

def char_width(ch)
  cp = ch.ord
  return 0 if cp == 0
  return 0 if cp < 32 || (cp >= 0x7f && cp < 0xa0)
  return 0 if (0x300..0x36f).cover?(cp) || (0x1ab0..0x1aff).cover?(cp) || (0x1dc0..0x1dff).cover?(cp) ||
              (0x20d0..0x20ff).cover?(cp) || (0xfe20..0xfe2f).cover?(cp) || cp == 0xfe0f
  return 2 if (0x1100..0x115f).cover?(cp) || cp == 0x2329 || cp == 0x232a ||
              (0x2e80..0xa4cf).cover?(cp) || (0xac00..0xd7a3).cover?(cp) ||
              (0xf900..0xfaff).cover?(cp) || (0xfe10..0xfe19).cover?(cp) ||
              (0xfe30..0xfe6f).cover?(cp) || (0xff00..0xff60).cover?(cp) ||
              (0xffe0..0xffe6).cover?(cp) || (0x1f300..0x1faff).cover?(cp) ||
              (0x20000..0x3fffd).cover?(cp)

  1
end

def display_width(str)
  str.to_s.each_char.sum { |ch| char_width(ch) }
end

def truncate_display(str, limit)
  out = +''
  width = 0
  str.to_s.each_char do |ch|
    w = char_width(ch)
    break if width + w > limit
    out << ch
    width += w
  end
  out
end

def align_cell(value, width, align, padding)
  text = truncate_display(value.to_s, width)
  text_width = display_width(text)
  extra = width - text_width
  left_extra, right_extra =
    case align
    when 'right'
      [extra, 0]
    when 'center'
      [extra / 2, extra - (extra / 2)]
    else
      [0, extra]
    end
  (' ' * (padding + left_extra)) + text + (' ' * (padding + right_extra))
end

def parse_csv(text, delimiter)
  rows = []
  row = []
  field = +''
  in_quotes = false
  quoted = false
  i = 0

  while i < text.length
    ch = text[i]
    if in_quotes
      if ch == '"'
        if text[i + 1] == '"'
          field << '"'
          i += 1
        else
          in_quotes = false
        end
      else
        field << ch
      end
    elsif ch == delimiter
      row << field
      field = +''
      quoted = false
    elsif ch == "\n"
      row << field
      rows << row
      row = []
      field = +''
      quoted = false
    elsif ch == "\r"
      if text[i + 1] == "\n"
        i += 1
      end
      row << field
      rows << row
      row = []
      field = +''
      quoted = false
    elsif ch == '"' && field.empty? && !quoted
      in_quotes = true
      quoted = true
    else
      field << ch
    end
    i += 1
  end

  if in_quotes
    warn 'csview: CSV error: unterminated quoted field'
    exit 1
  end

  unless row.empty? && field.empty? && text.end_with?("\n", "\r")
    row << field
    rows << row
  end

  rows
end

def read_records(opts)
  input = if opts[:file]
            begin
              File.read(opts[:file]).force_encoding(Encoding::UTF_8)
            rescue SystemCallError => e
              message = e.is_a?(Errno::ENOENT) ? 'No such file or directory (os error 2)' : e.message.sub(/ @ rb_sysopen - .*/, '')
              warn "csview: #{message}"
              exit 1
            end
          else
            STDIN.read.force_encoding(Encoding::UTF_8)
          end
  rows = parse_csv(input, opts[:delimiter]).reject { |row| row.length == 1 && row[0].empty? }
  if rows.empty?
    [[]]
  else
    expected = rows.first.length
    rows.each_with_index do |row, idx|
      next if row.length == expected
      warn "csview: CSV error: record #{idx} has #{row.length} fields, but the previous record has #{expected} fields"
      exit 1
    end
    rows
  end
end

def split_table(rows, opts)
  if opts[:headers]
    header = rows.first || []
    body = rows[1..] || []
  else
    header = nil
    body = rows
  end

  if opts[:number]
    if header
      header = ['#'] + header
      body = body.each_with_index.map { |row, i| [(i + 1).to_s] + row }
    else
      body = body.each_with_index.map { |row, i| [(i + 1).to_s] + row }
    end
  end

  [header, body]
end

def compute_widths(header, body, opts)
  col_count = [header&.length || 0, *body.map(&:length)].max || 0
  widths = Array.new(col_count, 0)
  sample = []
  sample << header if header
  sample.concat(opts[:sniff].zero? ? body : body.first(opts[:sniff]))
  sample = [[]] if sample.empty? && col_count.zero?
  sample.each do |row|
    col_count.times do |i|
      widths[i] = [widths[i], display_width(row[i].to_s)].max
    end
  end
  widths
end

def line_for(row, widths, align, opts, sep)
  cells = widths.each_with_index.map { |w, i| align_cell(row[i].to_s, w, align, opts[:padding]) }
  sep + cells.join(sep) + sep
end

def border(widths, opts, left, mid, right)
  chars = STYLE_CHARS.fetch(opts[:style])
  parts = widths.map { |w| chars[:h] * (w + opts[:padding] * 2) }
  left + parts.join(mid) + right
end

def render_none(header, body, widths, opts)
  rows = []
  rows << widths.each_with_index.map { |w, i| align_cell(header[i].to_s, w, opts[:header_align], opts[:padding]) }.join('') if header
  body.each { |row| rows << widths.each_with_index.map { |w, i| align_cell(row[i].to_s, w, opts[:body_align], opts[:padding]) }.join('') }
  rows
end

def render_ascii2(header, body, widths, opts)
  rows = []
  if header
    rows << ' ' + widths.each_with_index.map { |w, i| align_cell(header[i].to_s, w, opts[:header_align], opts[:padding]) }.join('|') + ' '
    rows << (' ' + widths.map { |w| '-' * (w + opts[:padding] * 2) }.join('+') + ' ')
  end
  body.each do |row|
    rows << ' ' + widths.each_with_index.map { |w, i| align_cell(row[i].to_s, w, opts[:body_align], opts[:padding]) }.join('|') + ' '
  end
  rows
end

def render_markdown(header, body, widths, opts)
  rows = []
  if header
    rows << line_for(header, widths, opts[:header_align], opts, '|')
    rows << '|' + widths.map { |w| '-' * (w + opts[:padding] * 2) }.join('|') + '|'
  end
  body.each { |row| rows << line_for(row, widths, opts[:body_align], opts, '|') }
  rows
end

def render_box(header, body, widths, opts)
  chars = STYLE_CHARS.fetch(opts[:style])
  rows = []
  rows << border(widths, opts, chars[:tl], chars[:tm], chars[:tr])
  if header
    rows << line_for(header, widths, opts[:header_align], opts, chars[:v])
    rows << border(widths, opts, chars[:ml], chars[:mm], chars[:mr]) unless body.empty?
  end
  body.each_with_index do |row, idx|
    rows << line_for(row, widths, opts[:body_align], opts, chars[:v])
    rows << border(widths, opts, chars[:ml], chars[:mm], chars[:mr]) if opts[:style] == 'grid' && idx < body.length - 1
  end
  rows << border(widths, opts, chars[:bl], chars[:bm], chars[:br])
  rows
end

def render(header, body, widths, opts)
  rows = case opts[:style]
         when 'none'
           render_none(header, body, widths, opts)
         when 'ascii2'
           render_ascii2(header, body, widths, opts)
         when 'markdown'
           render_markdown(header, body, widths, opts)
         else
           render_box(header, body, widths, opts)
         end
  indent = ' ' * opts[:indent]
  rows.map { |line| indent + line }
end

opts = parse_args(ARGV)
records = read_records(opts)
header, body = split_table(records, opts)
widths = compute_widths(header, body, opts)
puts render(header, body, widths, opts)
