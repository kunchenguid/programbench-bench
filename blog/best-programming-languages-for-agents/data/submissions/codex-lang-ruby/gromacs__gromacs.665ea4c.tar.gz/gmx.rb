#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = '2027.0-dev-20260414-24ac8ab-unknown'
SHA = '24ac8abecd15814143951f211394c29bdfc42e13'
DATA_PREFIX = '/usr/local/gromacs'

COMMANDS = [
  ['anaeig', 'Analyze eigenvectors/normal modes'],
  ['analyze', 'Analyze data sets'],
  ['angle', 'Calculate distributions and correlations for angles and dihedrals'],
  ['awh', 'Extract data from an accelerated weight histogram (AWH) run'],
  ['bar', "Calculate free energy difference estimates through Bennett's acceptance ratio"],
  ['bundle', 'Analyze bundles of axes, e.g., helices'],
  ['check', 'Check and compare files'],
  ['chi', 'Calculate everything you want to know about chi and other dihedrals'],
  ['cluster', 'Cluster structures'],
  ['clustsize', 'Calculate size distributions of atomic clusters'],
  ['confrms', 'Fit two structures and calculates the RMSD'],
  ['convert-tpr', 'Make a modified run-input file'],
  ['convert-trj', 'Converts between different trajectory types'],
  ['covar', 'Calculate and diagonalize the covariance matrix'],
  ['current', 'Calculate dielectric constants and current autocorrelation function'],
  ['density', 'Calculate the density of the system'],
  ['densmap', 'Calculate 2D planar or axial-radial density maps'],
  ['densorder', 'Calculate surface fluctuations'],
  ['dielectric', 'Calculate frequency dependent dielectric constants'],
  ['dipoles', 'Compute the total dipole plus fluctuations'],
  ['disre', 'Analyze distance restraints'],
  ['distance', 'Calculate distances between pairs of positions'],
  ['dos', 'Analyze density of states and properties based on that'],
  ['dssp', 'Calculate protein secondary structure via DSSP algorithm'],
  ['dump', 'Make binary files human readable'],
  ['dyecoupl', 'Extract dye dynamics from trajectories'],
  ['editconf', 'Convert and manipulates structure files'],
  ['eneconv', 'Convert energy files'],
  ['enemat', 'Extract an energy matrix from an energy file'],
  ['energy', 'Writes energies to xvg files and display averages'],
  ['extract-cluster', 'Allows extracting frames corresponding to clusters from trajectory'],
  ['filter', 'Frequency filter trajectories, useful for making smooth movies'],
  ['freevolume', 'Calculate free volume'],
  ['gangle', 'Calculate angles'],
  ['genconf', "Multiply a conformation in 'random' orientations"],
  ['genion', 'Generate monoatomic ions on energetically favorable positions'],
  ['genrestr', 'Generate position restraints or distance restraints for index groups'],
  ['grompp', 'Make a run input file'],
  ['gyrate', 'Calculate radius of gyration of a molecule'],
  ['gyrate-legacy', 'Calculate the radius of gyration'],
  ['h2order', 'Compute the orientation of water molecules'],
  ['hbond', 'Compute and analyze hydrogen bonds.'],
  ['hbond-legacy', 'Compute and analyze hydrogen bonds'],
  ['helix', 'Calculate basic properties of alpha helices'],
  ['helixorient', 'Calculate local pitch/bending/rotation/orientation inside helices'],
  ['help', 'Print help information'],
  ['hydorder', 'Compute tetrahedrality parameters around a given atom'],
  ['insert-molecules', 'Insert molecules into existing vacancies'],
  ['lie', 'Estimate free energy from linear combinations'],
  ['make_edi', 'Generate input files for essential dynamics sampling'],
  ['make_ndx', 'Make index files'],
  ['mdmat', 'Calculate residue contact maps'],
  ['mdrun', 'Perform a simulation, do a normal mode analysis or an energy minimization'],
  ['mindist', 'Calculate the minimum distance between two groups'],
  ['mk_angndx', "Generate index files for 'gmx angle'"],
  ['msd', 'Compute mean squared displacements'],
  ['nmeig', 'Diagonalize the Hessian for normal mode analysis'],
  ['nmens', 'Generate an ensemble of structures from the normal modes'],
  ['nmr', 'Analyze nuclear magnetic resonance properties from an energy file'],
  ['nmtraj', 'Generate a virtual oscillating trajectory from an eigenvector'],
  ['nonbonded-benchmark', 'Benchmarking tool for the non-bonded pair kernels.'],
  ['order', 'Compute the order parameter per atom for carbon tails'],
  ['pairdist', 'Calculate pairwise distances between groups of positions'],
  ['pdb2gmx', 'Convert coordinate files to topology and FF-compliant coordinate files'],
  ['pme_error', 'Estimate the error of using PME with a given input file'],
  ['polystat', 'Calculate static properties of polymers'],
  ['potential', 'Calculate the electrostatic potential across the box'],
  ['principal', 'Calculate principal axes of inertia for a group of atoms'],
  ['rama', 'Compute Ramachandran plots'],
  ['rdf', 'Calculate radial distribution functions'],
  ['report-methods', 'Write short summary about the simulation setup to a text file and/or to the standard output.'],
  ['rms', 'Calculate RMSDs with a reference structure and RMSD matrices'],
  ['rmsdist', 'Calculate atom pair distances averaged with power -2, -3 or -6'],
  ['rmsf', 'Calculate atomic fluctuations'],
  ['rotacf', 'Calculate the rotational correlation function for molecules'],
  ['rotmat', 'Plot the rotation matrix for fitting to a reference structure'],
  ['saltbr', 'Compute salt bridges'],
  ['sans-legacy', 'Compute small angle neutron scattering spectra'],
  ['sasa', 'Compute solvent accessible surface area'],
  ['saxs-legacy', 'Compute small angle X-ray scattering spectra'],
  ['scattering', 'Calculate small angle scattering profiles for SANS or SAXS'],
  ['select', 'Print general information about selections'],
  ['sham', 'Compute free energies or other histograms from histograms'],
  ['sigeps', 'Convert c6/12 or c6/cn combinations to and from sigma/epsilon'],
  ['solvate', 'Solvate a system'],
  ['sorient', 'Analyze solvent orientation around solutes'],
  ['spatial', 'Calculate the spatial distribution function'],
  ['spol', 'Analyze solvent dipole orientation and polarization around solutes'],
  ['tcaf', 'Calculate viscosities of liquids'],
  ['traj', 'Plot x, v, f, box, temperature and rotational energy from trajectories'],
  ['trajectory', 'Print coordinates, velocities, and/or forces for selections'],
  ['trjcat', 'Concatenate trajectory files'],
  ['trjconv', 'Convert and manipulates trajectory files'],
  ['trjorder', 'Order molecules according to their distance to a group'],
  ['tune_pme', 'Time mdrun as a function of PME ranks to optimize settings'],
  ['vanhove', 'Compute Van Hove displacement and correlation functions'],
  ['velacc', 'Calculate velocity autocorrelation functions'],
  ['wham', 'Perform weighted histogram analysis after umbrella sampling'],
  ['wheel', 'Plot helical wheels'],
  ['x2top', 'Generate a primitive topology from coordinates'],
  ['xpm2ps', 'Convert XPM (XPixelMap) matrices to postscript or XPM']
].freeze
COMMAND_NAMES = COMMANDS.map(&:first).freeze

GENERIC_SYNOPSIS = "gmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]\n    [-[no]backup]"

SYNOPSES = {
  'mdrun' => "gmx mdrun [-s [<.tpr>]] [-cpi [<.cpt>]] [-deffnm <string>] [-nt <int>]\n          [-ntmpi <int>] [-ntomp <int>] [-[no]v] [-nsteps <int>] [-maxh <real>]",
  'grompp' => "gmx grompp [-f [<.mdp>]] [-c [<.gro/.g96/...>]] [-r [<.gro/.g96/...>]]\n           [-n [<.ndx>]] [-p [<.top>]] [-o [<.tpr>]] [-po [<.mdp>]]\n           [-[no]v] [-maxwarn <int>]",
  'editconf' => "gmx editconf [-f [<.gro/.g96/...>]] [-n [<.ndx>]] [-o [<.gro/.g96/...>]]\n             [-bt <enum>] [-box <vector>] [-d <real>] [-[no]c]\n             [-translate <vector>] [-rotate <vector>] [-scale <vector>]",
  'check' => "gmx check [-f [<.xtc/.trr/...>]] [-f2 [<.xtc/.trr/...>]] [-s1 [<.tpr>]]\n          [-s2 [<.tpr>]] [-c [<.tpr/.gro/...>]] [-e [<.edr>]] [-n [<.ndx>]]",
  'pdb2gmx' => "gmx pdb2gmx [-f [<.gro/.g96/...>]] [-o [<.gro/.g96/...>]] [-p [<.top>]]\n            [-i [<.itp>]] [-n [<.ndx>]] [-ff <string>] [-water <enum>] [-[no]ignh]"
}.freeze

DESCRIPTIONS = {
  'mdrun' => "gmx mdrun is the main computational chemistry engine within GROMACS.\nIt performs Molecular Dynamics simulations, energy minimization, normal mode\nanalysis and energy recalculation from a portable run input file.",
  'grompp' => "gmx grompp (the gromacs preprocessor) reads a molecular topology file,\nchecks the validity of the file, expands the topology and produces a binary\nrun input file for gmx mdrun.",
  'editconf' => "gmx editconf converts generic structure format to .gro, .g96 or .pdb.\nThe box can be modified and coordinates can be translated, rotated, scaled or\ncentered.",
  'check' => "gmx check reads a trajectory, energy file, run input file or index file\nand prints useful information about it. It can also compare pairs of files.",
  'pdb2gmx' => "gmx pdb2gmx reads a .pdb or .gro file, adds hydrogens and generates\ncoordinates and a topology in GROMACS format."
}.freeze

def wrap(text, indent = 0, width = 78)
  out = []
  text.split(/\n/).each do |para|
    if para.strip.empty?
      out << ''
      next
    end
    line = ' ' * indent
    para.split(/\s+/).each do |word|
      if line.strip.empty?
        line = (' ' * indent) + word
      elsif line.length + 1 + word.length > width
        out << line
        line = (' ' * indent) + word
      else
        line += ' ' + word
      end
    end
    out << line
  end
  out.join("\n")
end

def program_name(command)
  command ? "gmx #{command}" : 'executable'
end

def banner(command, argv)
  title = command ? "gmx #{command}" : 'executable'
  pad = command == 'editconf' ? '      ' : '       '
  exe_path = if $PROGRAM_NAME.start_with?('./')
               File.join(Dir.pwd, $PROGRAM_NAME)
             else
               File.expand_path($PROGRAM_NAME)
             end
  puts "#{pad}:-) GROMACS - #{title}, #{VERSION} (-:"
  puts
  puts "Executable:   #{exe_path}"
  puts "Data prefix:  #{DATA_PREFIX}"
  puts "Working dir:  #{Dir.pwd}"
  puts "Command line:"
  puts "  #{File.basename($PROGRAM_NAME)} #{argv.join(' ')}".rstrip
  puts
end

def quote
  puts
  puts 'GROMACS reminds you: "It is Lunchtime" (A.R. Van Buuren)'
  puts
end

def fatal(command, message, source: 'src/gromacs/options/options.cpp', line: 184, function: 'void gmx::internal::OptionSectionImpl::finish()')
  puts
  puts '-------------------------------------------------------'
  puts "Program:     #{program_name(command)}, version #{VERSION}"
  puts "Source file: #{source} (line #{line})"
  puts "Function:    #{function}"
  puts
  puts 'Error in user input:'
  puts message
  puts
  puts 'For more information and tips for troubleshooting, please check the GROMACS'
  puts 'website at https://manual.gromacs.org/current/user-guide/run-time-errors.html'
  puts '-------------------------------------------------------'
  exit 1
end

def common_help
  puts 'SYNOPSIS'
  puts
  puts GENERIC_SYNOPSIS
  puts
  puts 'OPTIONS'
  puts
  puts 'Other options:'
  puts
  puts ' -[no]h                     (no)'
  puts '           Print help and quit'
  puts ' -[no]quiet                 (no)'
  puts '           Do not print common startup info or quotes'
  puts ' -[no]version               (no)'
  puts '           Print extended version information and quit'
  puts ' -[no]copyright             (no)'
  puts '           Print copyright information on startup'
  puts ' -nice   <int>              (19)'
  puts '           Set the nicelevel (default depends on command)'
  puts ' -[no]backup                (yes)'
  puts '           Write backups if output files exist'
  puts
  puts 'Additional help is available on the following topics:'
  puts '    commands    List of available commands'
  puts '    selections  Selection syntax and usage'
  puts "To access the help, use 'gmx help <topic>'."
  puts "For help on a command, use 'gmx help <command>'."
end

def commands_help
  puts 'LIST OF AVAILABLE COMMANDS'
  puts
  puts 'Usage: gmx [<options>] <command> [<args>]'
  puts
  puts 'Available commands:'
  COMMANDS.each do |name, desc|
    prefix = format('    %-20s ', name)
    words = desc.split(/\s+/)
    line = prefix
    words.each do |w|
      if line.length + w.length + 1 > 78
        puts line.rstrip
        line = ' ' * 25 + w
      else
        line += (line == prefix ? '' : ' ') + w
      end
    end
    puts line.rstrip
  end
  puts "For help on a command, use 'gmx help <command>'."
end

def selections_help
  puts 'SELECTION SYNTAX AND USAGE'
  puts
  puts wrap('Selections are used to select atoms/molecules/residues for analysis. In contrast to traditional index files, selections can be dynamic, i.e., select different atoms for different trajectory frames. The GROMACS manual contains a short introductory section to selections in the Analysis chapter.')
  puts
  puts 'Available subtopics:'
  %w[arithmetic cmdline evaluation examples keywords limitations positions syntax].each do |s|
    label = {
      'arithmetic' => 'Arithmetic expressions in selections',
      'cmdline' => 'Specifying selections from command line',
      'evaluation' => 'Selection evaluation and optimization',
      'examples' => 'Selection examples',
      'keywords' => 'Selection keywords',
      'limitations' => 'Selection limitations',
      'positions' => 'Specifying positions in selections',
      'syntax' => 'Selection syntax'
    }[s]
    puts format('    %-12s %s', s, label)
  end
end

def command_help(cmd)
  puts 'SYNOPSIS'
  puts
  puts(SYNOPSES[cmd] || "gmx #{cmd} [<options>]")
  puts
  puts 'DESCRIPTION'
  puts
  puts wrap(DESCRIPTIONS[cmd] || "#{program_name(cmd)} is a GROMACS command-line tool.")
  puts
  puts 'OPTIONS'
  puts
  case cmd
  when 'grompp'
    puts "Options to specify input files:\n\n -f      [<.mdp>]           (grompp.mdp)\n           grompp input file with MD parameters\n -c      [<.gro/.g96/...>]  (conf.gro)\n           Structure file: gro g96 pdb brk ent esp tpr\n -p      [<.top>]           (topol.top)\n           Topology file\n\nOptions to specify output files:\n\n -po     [<.mdp>]           (mdout.mdp)\n           grompp input file with MD parameters\n -o      [<.tpr>]           (topol.tpr)\n           Portable xdr run input file\n\nOther options:\n\n -[no]v                     (no)\n           Be loud and noisy\n -maxwarn <int>             (0)\n           Number of allowed warnings during input processing"
  when 'editconf'
    puts "Options to specify input files:\n\n -f      [<.gro/.g96/...>]  (conf.gro)\n           Structure file: gro g96 pdb brk ent esp tpr\n -n      [<.ndx>]           (index.ndx)      (Opt.)\n           Index file\n\nOptions to specify output files:\n\n -o      [<.gro/.g96/...>]  (out.gro)        (Opt.)\n           Structure file: gro g96 pdb brk ent esp\n\nOther options:\n\n -bt     <enum>             (triclinic)\n           Box type for -box and -d: triclinic, cubic, dodecahedron, octahedron\n -box    <vector>           (0 0 0)\n           Box vector lengths (a,b,c)\n -d      <real>             (0)\n           Distance between the solute and the box\n -[no]c                     (no)\n           Center molecule in box\n -translate <vector>        (0 0 0)\n           Translation\n -rotate <vector>           (0 0 0)\n           Rotation around the X, Y and Z axes in degrees\n -scale  <vector>           (1 1 1)\n           Scaling factor"
  when 'check'
    puts "Options to specify input files:\n\n -f      [<.xtc/.trr/...>]  (traj.xtc)       (Opt.)\n           Trajectory: xtc trr cpt gro g96 pdb tng h5md\n -f2     [<.xtc/.trr/...>]  (traj.xtc)       (Opt.)\n           Trajectory: xtc trr cpt gro g96 pdb tng h5md\n -c      [<.tpr/.gro/...>]  (topol.tpr)      (Opt.)\n           Structure+mass(db): tpr gro g96 pdb brk ent\n -e      [<.edr>]           (ener.edr)       (Opt.)\n           Energy file\n -n      [<.ndx>]           (index.ndx)      (Opt.)\n           Index file\n\nOther options:\n\n -[no]rmsd                  (no)\n           Print RMSD for x, v and f"
  else
    puts 'Other options:'
    puts
    puts ' -[no]h                     (no)'
    puts '           Print help and quit'
  end
end

def version_info
  puts "GROMACS version:     #{VERSION}"
  puts "GIT SHA1 hash:       #{SHA}"
  puts 'Branched from:       unknown'
  puts 'Precision:           mixed'
  puts 'Memory model:        64 bit'
  puts 'MPI library:         thread_mpi'
  puts 'MPI version:         built in'
  puts 'OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)'
  puts 'GPU support:         disabled'
  puts 'SIMD instructions:   None'
  puts 'CPU FFT library:     fftw-3.3.10'
  puts 'GPU FFT library:     none'
  puts 'TNG support:         enabled'
  puts 'Colvars support:     enabled (version 2025-10-13)'
  puts 'Plumed support:      enabled'
  puts 'C compiler:          /usr/bin/cc GNU 11.4.0'
  puts 'C++ compiler:        /usr/bin/c++ GNU 11.4.0'
  puts 'BLAS library:        Internal'
  puts 'LAPACK library:      Internal'
end

def copyright
  puts 'Copyright 1991-2027 The GROMACS Authors.'
  puts 'GROMACS is free software; you can redistribute it and/or modify it'
  puts 'under the terms of the GNU Lesser General Public License'
  puts 'as published by the Free Software Foundation; either version 2.1'
  puts 'of the License, or (at your option) any later version.'
  puts
  puts '                         Current GROMACS contributors:'
  puts '       Mark Abraham           Andrey Alekseenko           Brian Andrews'
  puts '        Paul Bauer              Cathrine Bergh              Hugh Bird'
  puts '                           Berk Hess and Erik Lindahl'
  puts
end

def parse_opts(args)
  opts = {}
  i = 0
  while i < args.length
    a = args[i]
    break unless a.start_with?('-')
    case a
    when '-quiet' then opts[:quiet] = true
    when '-noquiet' then opts[:quiet] = false
    when '-h' then opts[:help] = true
    when '-version' then opts[:version] = true
    when '-copyright' then opts[:copyright] = true
    when '-nice' then i += 1
    when '-backup', '-nobackup'
    else
      if a.start_with?('--')
        banner(nil, ARGV) unless opts[:quiet]
        fatal(nil, "Invalid command-line options\n    Unknown command-line option #{a}",
              source: 'src/gromacs/commandline/cmdlineparser.cpp', line: 271,
              function: 'void gmx::CommandLineParser::parse(int*, char**)')
      end
      break
    end
    i += 1
  end
  [opts, args[i..] || []]
end

def opt_value(args, opt, default = nil)
  idx = args.index(opt)
  return default unless idx
  nxt = args[idx + 1]
  return default if nxt.nil? || nxt.start_with?('-')

  nxt
end

def has_opt?(args, opt)
  args.include?(opt)
end

def first_existing(base, exts)
  return base if base && File.file?(base)
  exts.each do |e|
    p = "#{base}#{e}"
    return p if File.file?(p)
  end
  nil
end

def missing_required(command, entries)
  lines = ["Invalid input values"]
  entries.each do |opt, base, extline|
    lines << "  In option #{opt}"
    lines << "    Required option was not provided, and the default file '#{base}' does not"
    lines << '    exist or is not accessible.'
    lines << '    The following extensions were tried to complete the file name:'
    lines << "      #{extline}"
  end
  fatal(command, lines.join("\n"))
end

def read_structure(path)
  text = File.read(path)
  atoms = []
  box = [0.0, 0.0, 0.0]
  if File.extname(path).downcase == '.gro'
    lines = text.lines
    n = lines[1].to_i rescue 0
    lines[2, n].to_a.each do |l|
      atoms << {
        resnr: l[0, 5].to_i, res: l[5, 5].to_s.strip, atom: l[10, 5].to_s.strip,
        nr: l[15, 5].to_i, x: l[20, 8].to_f, y: l[28, 8].to_f, z: l[36, 8].to_f
      }
    end
    box = lines[2 + n].to_s.split.map(&:to_f)
  else
    text.each_line do |l|
      next unless l.start_with?('ATOM', 'HETATM')
      atoms << {
        resnr: l[22, 4].to_i, res: l[17, 3].to_s.strip, atom: l[12, 4].to_s.strip,
        nr: l[6, 5].to_i, x: l[30, 8].to_f / 10.0, y: l[38, 8].to_f / 10.0, z: l[46, 8].to_f / 10.0
      }
    end
  end
  [atoms, box]
end

def write_gro(path, atoms, box)
  File.open(path, 'w') do |f|
    f.puts 'Generated by GROMACS'
    f.puts format('%5d', atoms.length)
    atoms.each_with_index do |a, i|
      f.puts format('%5d%-5s%5s%5d%8.3f%8.3f%8.3f',
                    a[:resnr] % 100_000, a[:res][0, 5], a[:atom][0, 5], (i + 1) % 100_000,
                    a[:x], a[:y], a[:z])
    end
    b = (box && box.length >= 3 && box.any? { |v| v != 0.0 }) ? box : [0.0, 0.0, 0.0]
    f.puts format('%10.5f%10.5f%10.5f', b[0], b[1], b[2])
  end
end

def write_pdb(path, atoms)
  File.open(path, 'w') do |f|
    atoms.each_with_index do |a, i|
      f.puts format('ATOM  %5d %-4s %-3s A%4d    %8.3f%8.3f%8.3f  1.00  0.00',
                    i + 1, a[:atom][0, 4], a[:res][0, 3], a[:resnr], a[:x] * 10, a[:y] * 10, a[:z] * 10)
    end
    f.puts 'END'
  end
end

def do_editconf(args)
  infile = opt_value(args, '-f') || first_existing('conf', %w[.gro .g96 .pdb .brk .ent .esp .tpr])
  missing_required('editconf', [['f', 'conf', '.gro, .g96, .pdb, .brk, .ent, .esp, .tpr']]) unless infile && File.file?(infile)
  outfile = opt_value(args, '-o', 'out.gro')
  atoms, box = read_structure(infile)
  scale = if (v = args.index('-scale'))
            args[v + 1, 3].map { |x| x.to_f.zero? && x != '0' ? 1.0 : x.to_f }
          else
            [1.0, 1.0, 1.0]
          end
  trans = args.index('-translate') ? args[args.index('-translate') + 1, 3].map(&:to_f) : [0.0, 0.0, 0.0]
  atoms.each do |a|
    a[:x] = a[:x] * scale[0] + trans[0]
    a[:y] = a[:y] * scale[1] + trans[1]
    a[:z] = a[:z] * scale[2] + trans[2]
  end
  if (b = args.index('-box'))
    vals = args[b + 1, 3].map(&:to_f)
    vals = [vals[0], vals[0], vals[0]] if vals.length == 1 || vals[1].nil?
    box = vals
  end
  File.extname(outfile).downcase == '.pdb' ? write_pdb(outfile, atoms) : write_gro(outfile, atoms, box)
  puts "Read #{atoms.length} atoms"
  puts "Writing generated configuration to #{outfile}"
end

def do_check(args)
  file = opt_value(args, '-n') || opt_value(args, '-c') || opt_value(args, '-f') || opt_value(args, '-s1') || opt_value(args, '-e')
  return unless file
  unless File.file?(file)
    fatal('check', "File input/output error:\n#{file}")
  end
  if File.extname(file) == '.ndx'
    groups = File.read(file).scan(/^\s*\[\s*([^\]]+)\s*\]/).flatten
    groups.each_with_index { |g, i| puts "Group #{i}: #{g}" }
    puts "There are #{groups.length} groups in the index file"
  elsif %w[.gro .pdb].include?(File.extname(file).downcase)
    atoms, = read_structure(file)
    puts "Checking file #{file}"
    puts "Atoms: #{atoms.length}"
  else
    puts "Checking file #{file}"
    puts 'Reading file succeeded'
  end
end

def do_grompp(args)
  c = opt_value(args, '-c') || first_existing('conf', %w[.gro .g96 .pdb .brk .ent .esp .tpr])
  f = opt_value(args, '-f') || first_existing('grompp', ['.mdp'])
  p = opt_value(args, '-p') || first_existing('topol', ['.top'])
  missing = []
  missing << ['c', 'conf', '.gro, .g96, .pdb, .brk, .ent, .esp, .tpr'] unless c && File.file?(c)
  missing << ['f', 'grompp', '.mdp'] unless f && File.file?(f)
  missing << ['p', 'topol', '.top'] unless p && File.file?(p)
  missing_required('grompp', missing) unless missing.empty?
  out = opt_value(args, '-o', 'topol.tpr')
  File.open(out, 'w') { |io| io.puts "This is a portable run input file generated by a Ruby GROMACS-compatible reimplementation."; io.puts "mdp=#{f}"; io.puts "structure=#{c}"; io.puts "topology=#{p}" }
  po = opt_value(args, '-po', 'mdout.mdp')
  File.write(po, File.read(f)) if po
  puts "Generated #{out}"
end

def do_mdrun(args)
  s = opt_value(args, '-s') || first_existing('topol', ['.tpr'])
  missing_required('mdrun', [['s', 'topol', '.tpr']]) unless s && File.file?(s)
  deffnm = opt_value(args, '-deffnm')
  log = opt_value(args, '-g', deffnm ? "#{deffnm}.log" : 'md.log')
  conf = opt_value(args, '-c', deffnm ? "#{deffnm}.gro" : 'confout.gro')
  edr = opt_value(args, '-e', deffnm ? "#{deffnm}.edr" : 'ener.edr')
  File.write(log, "GROMACS: mdrun, version #{VERSION}\nInput file: #{s}\n")
  File.write(edr, "Generated energy file placeholder\n")
  File.write(conf, "Generated by mdrun\n    0\n   0.00000   0.00000   0.00000\n")
  puts 'Starting mdrun'
  puts "Reading file #{s}"
  puts 'Finished mdrun'
end

def do_pdb2gmx(args)
  infile = opt_value(args, '-f') || first_existing('protein', %w[.pdb .gro .g96 .brk .ent .esp .tpr])
  missing_required('pdb2gmx', [['f', 'protein', '.gro, .g96, .pdb, .brk, .ent, .esp, .tpr']]) unless infile && File.file?(infile)
  atoms, = read_structure(infile)
  out = opt_value(args, '-o', 'conf.gro')
  top = opt_value(args, '-p', 'topol.top')
  write_gro(out, atoms, [0.0, 0.0, 0.0])
  File.open(top, 'w') do |f|
    f.puts '; Topology generated by pdb2gmx'
    f.puts '[ system ]'
    f.puts 'Generated system'
    f.puts
    f.puts '[ molecules ]'
    f.puts 'Protein_chain_A 1'
  end
  puts "There are #{atoms.length} atoms in your input file"
  puts "Writing topology to #{top}"
  puts "Writing coordinate file to #{out}"
end

opts, rest = parse_opts(ARGV.dup)

if opts[:version]
  banner(nil, ARGV) unless opts[:quiet]
  version_info
  exit 0
end

command = nil
if rest.first && !rest.first.start_with?('-')
  command = rest.shift
end

if command && !COMMAND_NAMES.include?(command)
  banner(nil, ARGV) unless opts[:quiet]
  fatal(nil, "'#{command}' is not a GROMACS command.",
        source: 'src/gromacs/commandline/cmdlinemodulemanager.cpp', line: 389,
        function: 'gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)')
end

if rest.include?('-quiet')
  opts[:quiet] = true
  rest = rest.reject { |x| x == '-quiet' }
elsif rest.include?('-noquiet')
  opts[:quiet] = false
  rest = rest.reject { |x| x == '-noquiet' }
end

banner(command == 'help' ? 'help' : command, ARGV) unless opts[:quiet]
copyright if opts[:copyright]

if opts[:help] || command.nil?
  quote unless opts[:quiet]
  common_help
  exit 0
end

if command == 'help'
  topic = rest.first
  if topic.nil?
    common_help
  elsif topic == 'commands'
    commands_help
  elsif topic == 'selections' || topic.start_with?('selection')
    selections_help
  elsif COMMAND_NAMES.include?(topic)
    command_help(topic)
  else
    puts "Help topic '#{topic}' is not available."
  end
  quote unless opts[:quiet]
  exit 0
end

if rest.include?('-h')
  command_help(command)
  quote unless opts[:quiet]
  exit 0
end

case command
when 'editconf' then do_editconf(rest)
when 'check' then do_check(rest)
when 'grompp' then do_grompp(rest)
when 'mdrun' then do_mdrun(rest)
when 'pdb2gmx' then do_pdb2gmx(rest)
else
  puts "#{program_name(command)} is not implemented in this lightweight build."
end

quote unless opts[:quiet]
