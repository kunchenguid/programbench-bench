#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = "bat 0.26.1 (610b77c)"
ROOT = File.expand_path('..', __dir__)
DATA_DIR = File.expand_path(__dir__)

SHORT_HELP = <<~TXT
  A cat(1) clone with wings.

  Usage: bat [OPTIONS] [FILE]...
         bat <COMMAND>

  Arguments:
    [FILE]...  File(s) to print / concatenate. Use '-' for standard input.

  Options:
    -A, --show-all
            Show non-printable characters (space, tab, newline, ..).
        --nonprintable-notation <notation>
            Set notation for non-printable characters.
        --binary <behavior>
            How to treat binary content. (default: no-printing)
    -p, --plain...
            Show plain style (alias for '--style=plain').
    -l, --language <language>
            Set the language for syntax highlighting.
        --fallback-syntax <fallback-syntax>
            Set a fallback language for undetected syntaxes. [aliases: --fallback-language]
    -H, --highlight-line <N:M>
            Highlight lines N through M.
        --file-name <name>
            Specify the name to display for a file.
    -d, --diff
            Only show lines that have been added/removed/modified.
        --tabs <T>
            Set the tab width to T spaces.
        --wrap <mode>
            Specify the text-wrapping mode (*auto*, never, character, word).
    -S, --chop-long-lines
            Truncate all lines longer than screen width. Alias for '--wrap=never'.
    -n, --number
            Show line numbers (alias for '--style=numbers').
        --color <when>
            When to use colors (*auto*, never, always).
        --italic-text <when>
            Use italics in output (always, *never*)
        --decorations <when>
            When to show the decorations (*auto*, never, always).
        --paging <when>
            Specify when to use the pager, or use `-P` to disable (*auto*, never, always).
    -m, --map-syntax <glob:syntax>
            Use the specified syntax for files matching the glob pattern ('*.cpp:C++').
        --theme <theme>
            Set the color theme for syntax highlighting.
        --theme-light <theme>
            Sets the color theme for syntax highlighting used for light backgrounds.
        --theme-dark <theme>
            Sets the color theme for syntax highlighting used for dark backgrounds.
        --list-themes
            Display all supported highlighting themes.
    -s, --squeeze-blank
            Squeeze consecutive empty lines.
        --style <components>
            Comma-separated list of style elements to display (*default*, auto, full, plain, changes,
            header, header-filename, header-filesize, grid, rule, numbers, snip).
    -r, --line-range <N:M>
            Only print the lines from N to M.
    -L, --list-languages
            Display all supported languages.
    -u, --unbuffered
            Enable unbuffered input reading for streaming use cases.
        --completion <SHELL>
            Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]
    -E, --quiet-empty
            Produce no output when the input is empty.
    -h, --help
            Print help (see more with '--help')
    -V, --version
            Print version
TXT

LONG_HELP = <<~TXT
  A cat(1) clone with syntax highlighting and Git integration.

  Usage: bat [OPTIONS] [FILE]...
         bat <COMMAND>

  Arguments:
    [FILE]...
            File(s) to print / concatenate. Use a dash ('-') or no argument at all to read from
            standard input.

  Options:
    -A, --show-all
            Show non-printable characters like space, tab or newline. This option can also be used to
            print binary files. Use '--tabs' to control the width of the tab-placeholders.

        --nonprintable-notation <notation>
            Set notation for non-printable characters.
            Possible values: unicode, caret

        --binary <behavior>
            How to treat binary content. (default: no-printing)
            Possible values: no-printing, as-text

    -p, --plain...
            Only show plain style, no decorations. This is an alias for '--style=plain'.

    -l, --language <language>
            Explicitly set the language for syntax highlighting.

    -H, --highlight-line <N:M>
            Highlight the specified line ranges with a different background color

        --file-name <name>
            Specify the name to display for a file.

    -d, --diff
            Only show lines that have been added/removed/modified with respect to the Git index.

        --tabs <T>
            Set the tab width to T spaces. Use a width of 0 to pass tabs through directly

        --wrap <mode>
            Specify the text-wrapping mode (*auto*, never, character, word).

    -S, --chop-long-lines
            Truncate all lines longer than screen width. Alias for '--wrap=never'.

    -n, --number
            Only show line numbers, no other decorations. This is an alias for '--style=numbers'

        --color <when>
            Specify when to use colored output. Possible values: *auto*, never, always.

        --decorations <when>
            Specify when to use the decorations that have been specified via '--style'.
            Possible values: *auto*, never, always.

        --paging <when>
            Specify when to use the pager. Possible values: *auto*, never, always.

        --theme <theme>
            Set the theme for syntax highlighting. Use '--list-themes' to see all available themes.

        --list-themes
            Display a list of supported themes for syntax highlighting.

    -s, --squeeze-blank
            Squeeze consecutive empty lines into a single empty line.

        --squeeze-limit <squeeze-limit>
            Set the maximum number of consecutive empty lines to be printed.

        --style <components>
            Configure which elements (line numbers, file headers, grid borders, Git modifications, ..)
            to display in addition to the file contents.

    -r, --line-range <N:M>
            Only print the specified range of lines for each file.

    -L, --list-languages
            Display a list of supported languages for syntax highlighting.

    -u, --unbuffered
            Enable unbuffered input reading.

        --completion <SHELL>
            Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]

        --diagnostic
            Show diagnostic information for bug reports.

    -E, --quiet-empty
            When this flag is set, bat will produce no output at all when the input is empty.

        --acknowledgements
            Show acknowledgements.

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version

  You can use 'bat cache' to customize syntaxes and themes. See 'bat cache --help' for more
  information
TXT

CACHE_HELP = <<~TXT
  Modify the syntax-definition and theme cache

  Usage: executable cache [OPTIONS]

  Options:
    -h, --help
            Print help

    -b, --build
            Initialize (or update) the syntax/theme cache by loading from the source directory
            (default: the configuration directory).

    -c, --clear
            Remove the cached syntax definitions and themes.

        --source <dir>
            Use a different directory to load syntaxes and themes from.

        --target <dir>
            Use a different directory to store the cached syntax and theme set.

        --blank
            Create completely new syntax and theme sets (instead of appending to the default sets).

        --acknowledgements
            Build acknowledgements.bin.
TXT

COMPLETION_BASH = <<~'TXT'
  # shellcheck disable=SC2207

  _bat() {
      local cur
      COMPREPLY=()
      cur="${COMP_WORDS[COMP_CWORD]}"
      COMPREPLY=($(compgen -W "--help --version --plain --number --show-all --language --list-languages --list-themes --style --paging --color --decorations --line-range --squeeze-blank --completion cache" -- "$cur"))
  } && complete -F _bat bat
TXT

Options = Struct.new(:show_all, :notation, :plain_count, :number, :tabs, :squeeze, :squeeze_limit,
                     :line_ranges, :quiet_empty, :decorations, :color, :style, :file_name,
                     :strip_ansi, keyword_init: true)

def die_usage(msg, code = 2)
  warn msg
  exit code
end

def bat_error(msg)
  warn "\e[31m[bat error]\e[0m: #{msg}"
end

def value_for(args, i, opt)
  a = args[i]
  return [a.split('=', 2)[1], i] if a.include?('=')
  die_usage("error: a value is required for '#{opt} <value>'") if i + 1 >= args.length
  [args[i + 1], i + 1]
end

def validate_choice(opt, val, choices)
  return if choices.include?(val)
  warn "error: invalid value '#{val}' for '#{opt} <when>'"
  warn "  [possible values: #{choices.join(', ')}]"
  exit 2
end

def parse_args(argv)
  opts = Options.new(show_all: false, notation: 'unicode', plain_count: 0, number: false, tabs: 4,
                     squeeze: false, squeeze_limit: nil, line_ranges: [], quiet_empty: false,
                     decorations: 'auto', color: 'auto', style: nil, file_name: nil, strip_ansi: 'never')
  files = []
  i = 0
  while i < argv.length
    arg = argv[i]
    if arg == '--'
      files.concat(argv[(i + 1)..] || [])
      break
    elsif arg == 'cache' && files.empty?
      puts CACHE_HELP
      exit 0
    elsif arg == '-h'
      puts SHORT_HELP
      exit 0
    elsif arg == '--help'
      puts LONG_HELP
      exit 0
    elsif arg == '-V' || arg == '--version'
      puts VERSION
      exit 0
    elsif arg == '--list-themes'
      print File.read(File.join(DATA_DIR, 'list-themes.txt'))
      exit 0
    elsif arg == '-L' || arg == '--list-languages'
      print File.read(File.join(DATA_DIR, 'list-languages.txt'))
      exit 0
    elsif arg == '--acknowledgements'
      puts "Copyright (c) 2018-2021 bat-developers (https://github.com/sharkdp/bat)."
      puts
      puts "bat is made available under the terms of either the MIT License or the Apache License 2.0, at your option."
      exit 0
    elsif arg == '--diagnostic'
      puts "#### Software version"
      puts
      puts VERSION
      puts
      puts "#### Operating system"
      puts
      puts "- OS: Linux (Ubuntu 22.04)"
      puts
      puts "#### Command-line"
      puts
      puts "```bash"
      puts "#{File.basename($PROGRAM_NAME)} --diagnostic "
      puts "```"
      exit 0
    elsif arg == '--completion' || arg.start_with?('--completion=')
      val, i = value_for(argv, i, '--completion')
      case val
      when 'bash' then puts COMPLETION_BASH
      when 'fish' then puts "complete -c bat -f"
      when 'zsh' then puts "#compdef bat\n_arguments '*:file:_files'"
      when 'ps1' then puts "Register-ArgumentCompleter -Native -CommandName bat -ScriptBlock { }"
      else
        warn "error: invalid value '#{val}' for '--completion <SHELL>'"
        warn "  [possible values: bash, fish, zsh, ps1]"
        exit 2
      end
      exit 0
    elsif arg.start_with?('--')
      name = arg.split('=', 2)[0]
      case name
      when '--show-all' then opts.show_all = true
      when '--plain' then opts.plain_count += 1; opts.style = 'plain'
      when '--number' then opts.number = true
      when '--squeeze-blank' then opts.squeeze = true
      when '--quiet-empty' then opts.quiet_empty = true
      when '--set-terminal-title', '--diff', '--unbuffered' then nil
      when '--chop-long-lines' then nil
      when '--force-colorization' then opts.decorations = 'always'; opts.color = 'always'
      when '--no-paging' then nil
      when '--language', '--fallback-syntax', '--fallback-language', '--highlight-line', '--file-name',
           '--diff-context', '--tabs', '--wrap', '--terminal-width', '--color', '--italic-text',
           '--decorations', '--paging', '--pager', '--map-syntax', '--ignored-suffix', '--theme',
           '--theme-light', '--theme-dark', '--squeeze-limit', '--strip-ansi', '--style', '--line-range',
           '--binary', '--nonprintable-notation', '--cache-dir', '--config-dir', '--config-file'
        val, i = value_for(argv, i, name)
        case name
        when '--file-name' then opts.file_name = val
        when '--tabs' then opts.tabs = Integer(val) rescue 4
        when '--color'
          validate_choice('--color', val, %w[auto never always]); opts.color = val
        when '--decorations'
          validate_choice('--decorations', val, %w[auto never always]); opts.decorations = val
        when '--paging', '--italic-text', '--wrap', '--strip-ansi'
          # Accepted for compatibility.
          opts.strip_ansi = val if name == '--strip-ansi'
        when '--style' then opts.style = val; opts.number = true if val.split(',').include?('numbers') && opts.decorations == 'always'
        when '--line-range' then opts.line_ranges << val
        when '--squeeze-limit' then opts.squeeze_limit = Integer(val) rescue nil
        when '--nonprintable-notation' then opts.notation = val
        end
      else
        warn "error: unexpected argument '#{arg}' found"
        warn
        warn "  tip: to pass '#{arg}' as a value, use '-- #{arg}'"
        warn
        warn "Usage: executable [OPTIONS] [FILE]..."
        warn "       executable <COMMAND>"
        exit 2
      end
    elsif arg.start_with?('-') && arg != '-'
      chars = arg[1..].chars
      chars.each_with_index do |ch, idx|
        case ch
        when 'A' then opts.show_all = true
        when 'p' then opts.plain_count += 1; opts.style = 'plain'
        when 'n' then opts.number = true
        when 's' then opts.squeeze = true
        when 'u', 'd', 'S', 'f', 'P' then nil
        when 'h' then puts SHORT_HELP; exit 0
        when 'V' then puts VERSION; exit 0
        when 'L' then print File.read(File.join(DATA_DIR, 'list-languages.txt')); exit 0
        when 'l', 'H', 'm', 'r'
          if idx != chars.length - 1
            val = chars[(idx + 1)..].join
            opts.line_ranges << val if ch == 'r'
            break
          else
            die_usage("error: a value is required for '-#{ch} <value>'") if i + 1 >= argv.length
            i += 1
            opts.line_ranges << argv[i] if ch == 'r'
          end
        else
          warn "error: unexpected argument '-#{ch}' found"
          exit 2
        end
      end
    else
      files << arg
    end
    i += 1
  end
  [opts, files]
end

def read_sources(files)
  files = ['-'] if files.empty?
  had_error = false
  sources = []
  files.each do |f|
    if f == '-'
      sources << [f, STDIN.binmode.read]
    elsif File.directory?(f)
      bat_error("'#{f}': Is a directory (os error 21)")
      had_error = true
    else
      begin
        sources << [f, File.binread(f)]
      rescue Errno::ENOENT
        bat_error("'#{f}': No such file or directory (os error 2)")
        had_error = true
      rescue SystemCallError => e
        bat_error("'#{f}': #{e.message}")
        had_error = true
      end
    end
  end
  [sources, had_error]
end

def split_lines_preserve(s)
  return [] if s.empty?
  s.lines
end

def blank_line?(line)
  line == "\n" || line == "\r\n" || line.empty?
end

def squeeze_lines(lines, limit)
  max_blank = limit || 1
  out = []
  run = 0
  lines.each do |line|
    if blank_line?(line)
      run += 1
      out << line if run <= max_blank
    else
      run = 0
      out << line
    end
  end
  out
end

def parse_positive_int(s)
  Integer(s)
rescue ArgumentError
  raise ArgumentError, 'invalid digit found in string'
end

def apply_range(lines, spec)
  if spec =~ /\A(-?\d+)\z/
    n = parse_positive_int($1)
    return n.negative? ? lines[n.abs * -1, n.abs] || [] : (n >= 1 ? [lines[n - 1]].compact : [])
  end
  parts = spec.split(':', -1)
  raise ArgumentError, 'invalid digit found in string' if parts.length < 2 || parts.length > 3
  if parts.length == 3 && parts[1].empty?
    center = parse_positive_int(parts[0])
    ctx = parse_positive_int(parts[2])
    from = [1, center - ctx].max
    to = [lines.length, center + ctx].min
  elsif parts.length == 3
    from = parts[0].empty? ? 1 : parse_positive_int(parts[0])
    to = parts[1].empty? ? lines.length : parse_positive_int(parts[1])
    ctx = parse_positive_int(parts[2])
    from = [1, from - ctx].max
    to = [lines.length, to + ctx].min
  elsif parts[1].start_with?('+')
    from = parse_positive_int(parts[0])
    to = from + parse_positive_int(parts[1][1..])
  else
    if parts[0].start_with?('-') && parts[1].empty?
      count = parse_positive_int(parts[0]).abs
      return lines.last(count) || []
    end
    from = parts[0].empty? ? 1 : parse_positive_int(parts[0])
    to = parts[1].empty? ? lines.length : parse_positive_int(parts[1])
  end
  return [] if to < from || from > lines.length
  lines[(from - 1)..(to - 1)] || []
end

def expand_tabs_text(text, width)
  return text if width == 0
  col = 0
  out = +''
  text.each_char do |c|
    if c == "\t"
      spaces = width - (col % width)
      out << (' ' * spaces)
      col += spaces
    else
      out << c
      col = c == "\n" ? 0 : col + 1
    end
  end
  out
end

def visible_nonprint(line, opts)
  newline = line.end_with?("\n")
  body = newline ? line[0...-1] : line.dup
  body = body.delete_suffix("\r")
  col = 0
  out = +''
  body.each_char do |c|
    case c
    when ' '
      out << (opts.notation == 'caret' ? ' ' : '·')
      col += 1
    when "\t"
      if opts.notation == 'caret'
        out << '^I'
        col += 2
      else
        width = opts.tabs || 4
        spaces = width == 0 ? 1 : width - (col % width)
        if spaces <= 1
          out << '├┤'
          col += 2
        else
          out << '├' << ('─' * [spaces - 2, 0].max) << '┤'
          col += spaces
        end
      end
    else
      code = c.ord
      if code < 32 && opts.notation == 'caret'
        out << '^' << (code + 64).chr
        col += 2
      elsif code == 127 && opts.notation == 'caret'
        out << '^?'
        col += 2
      else
        out << c
        col += 1
      end
    end
  end
  out << (opts.notation == 'caret' ? '$' : '␊') if newline
  out << "\n" if newline
  out
end

def strip_ansi(text)
  text.gsub(/\e\[[0-9;?]*[ -\/]*[@-~]/, '')
end

def format_plain(lines, opts, start_no = 1)
  out = +''
  lines.each_with_index do |line, idx|
    line = strip_ansi(line) if opts.strip_ansi == 'always'
    rendered = opts.show_all ? visible_nonprint(line, opts) : line
    if opts.number
      rendered = expand_tabs_text(rendered, opts.tabs || 4) unless opts.show_all
      out << format('%4d ', start_no + idx) << rendered
    else
      out << rendered
    end
  end
  out
end

def decorate(name, lines, opts)
  width = 80
  out = +''
  rule_top = '─' * 5 + '┬' + '─' * (width - 6)
  rule_mid = '─' * 5 + '┼' + '─' * (width - 6)
  rule_bot = '─' * 5 + '┴' + '─' * (width - 6)
  out << rule_top << "\n"
  out << "     │ File: #{name}\n"
  out << rule_mid << "\n"
  lines.each_with_index do |line, idx|
    rendered = opts.show_all ? visible_nonprint(line, opts) : expand_tabs_text(line, opts.tabs || 4)
    out << format('%4d │ ', idx + 1) << rendered
  end
  out << rule_bot << "\n"
  out
end

def process_source(name, content, opts)
  lines = split_lines_preserve(content.force_encoding('UTF-8').scrub)
  lines = squeeze_lines(lines, opts.squeeze_limit) if opts.squeeze
  opts.line_ranges.each do |spec|
    lines = apply_range(lines, spec)
  end
  return '' if opts.quiet_empty && lines.empty?
  decorated = opts.decorations == 'always' && opts.style != 'plain' && !opts.number
  if decorated
    decorate(opts.file_name || name, lines, opts)
  else
    format_plain(lines, opts)
  end
rescue ArgumentError => e
  bat_error(e.message)
  exit 1
end

opts, files = parse_args(ARGV)
sources, had_error = read_sources(files)
result = +''
sources.each do |name, content|
  result << process_source(name, content, opts)
end
print result
exit(had_error ? 1 : 0)
