#!/usr/bin/env ruby
# frozen_string_literal: true

VERSION = "0.68.0 (5676da4a)"

HELP = <<~TEXT
  fzf is an interactive filter program for any kind of list.

  It implements a "fuzzy" matching algorithm, so you can quickly type in patterns
  with omitted characters and still get the results you want.

  Project URL: https://github.com/junegunn/fzf
  Author: Junegunn Choi <junegunn.c@gmail.com>

  * See man page for more information: fzf --man

  Usage: fzf [options]

    SEARCH
      -e, --exact              Enable exact-match
      +x, --no-extended        Disable extended-search mode
      -i, --ignore-case        Case-insensitive match
      +i, --no-ignore-case     Case-sensitive match
          --smart-case         Smart-case match (default)
      --scheme=SCHEME          Scoring scheme [default|path|history]
      -n, --nth=N[,..]         Comma-separated list of field index expressions
      --with-nth=N[,..]        Transform the presentation of each line using field expressions
      --accept-nth=N[,..]      Define which fields to print on accept
      -d, --delimiter=STR      Field delimiter regex (default: AWK-style)
      +s, --no-sort            Do not sort the result
      --literal                Do not normalize latin script letters
      --tail=NUM               Maximum number of items to keep in memory
      --disabled               Do not perform search
      --tiebreak=CRI[,..]      Comma-separated list of sort criteria

    INPUT/OUTPUT
      --read0                  Read input delimited by ASCII NUL characters
      --print0                 Print output delimited by ASCII NUL characters
      --ansi                   Enable processing of ANSI color codes
      --sync                   Synchronous search for multi-staged filtering

    SCRIPTING
      -q, --query=STR          Start the finder with the given query
      -1, --select-1           Automatically select the only match
      -0, --exit-0             Exit immediately when there's no match
      -f, --filter=STR         Print matches for the initial query and exit
      --print-query            Print query as the first line
      --expect=KEYS            Comma-separated list of keys to complete fzf

    HELP
      --version                Display version information and exit
      --help                   Show this message
      --man                    Show man page
TEXT

class Options
  attr_accessor :filter, :query, :case_mode, :exact, :extended, :sort, :read0,
                :print0, :print_query, :expect, :nth, :with_nth, :accept_nth,
                :delimiter, :select_1, :exit_0, :tail, :scheme, :tiebreak,
                :disabled, :tac, :shell_integration

  def initialize
    @filter = nil
    @query = ""
    @case_mode = :smart
    @exact = false
    @extended = true
    @sort = true
    @read0 = false
    @print0 = false
    @print_query = false
    @expect = []
    @nth = nil
    @with_nth = nil
    @accept_nth = nil
    @delimiter = nil
    @select_1 = false
    @exit_0 = false
    @tail = nil
    @scheme = "default"
    @tiebreak = %w[length index]
    @disabled = false
    @tac = false
    @shell_integration = nil
  end
end

def die(msg)
  warn msg
  exit 2
end

def option_value(argv, i, arg, name)
  prefix = "#{name}="
  return [arg[prefix.length..], i] if arg.start_with?(prefix)
  die "missing argument: #{name}" if i + 1 >= argv.length
  [argv[i + 1], i + 1]
end

def shell_words(str)
  words = []
  cur = +""
  quote = nil
  esc = false
  str.each_char do |ch|
    if esc
      cur << ch
      esc = false
    elsif ch == "\\" && quote != "'"
      esc = true
    elsif quote
      ch == quote ? quote = nil : cur << ch
    elsif ch == "'" || ch == '"'
      quote = ch
    elsif ch =~ /\s/
      unless cur.empty?
        words << cur
        cur = +""
      end
    else
      cur << ch
    end
  end
  cur << "\\" if esc
  words << cur unless cur.empty?
  words
end

def parse_options(argv)
  opts = Options.new
  defaults = []
  if ENV["FZF_DEFAULT_OPTS_FILE"] && File.readable?(ENV["FZF_DEFAULT_OPTS_FILE"])
    defaults.concat(shell_words(File.read(ENV["FZF_DEFAULT_OPTS_FILE"])))
  end
  defaults.concat(shell_words(ENV["FZF_DEFAULT_OPTS"].to_s))
  argv = defaults + argv
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when "--help"
      puts HELP
      exit 0
    when "--version"
      puts VERSION
      exit 0
    when "--man"
      man = "/workspace/man/man1/fzf.1"
      puts(File.readable?(man) ? File.read(man) : HELP)
      exit 0
    when "-f", /^--filter(=|$)/
      opts.filter, i = option_value(argv, i, arg, "--filter")
    when "-q", /^--query(=|$)/
      opts.query, i = option_value(argv, i, arg, "--query")
    when "-e", "--exact"
      opts.exact = true
    when "-i", "--ignore-case"
      opts.case_mode = :ignore
    when "+i", "--no-ignore-case"
      opts.case_mode = :respect
    when "--smart-case"
      opts.case_mode = :smart
    when "+x", "--no-extended"
      opts.extended = false
    when "-x", "--extended"
      opts.extended = true
    when "+s", "--no-sort"
      opts.sort = false
    when "--no-sort"
      opts.sort = false
    when "--read0"
      opts.read0 = true
    when "--print0"
      opts.print0 = true
    when "--print-query"
      opts.print_query = true
    when /^--expect(=|$)/
      val, i = option_value(argv, i, arg, "--expect")
      opts.expect.concat(val.split(","))
    when "-1", "--select-1"
      opts.select_1 = true
    when "-0", "--exit-0"
      opts.exit_0 = true
    when "--disabled"
      opts.disabled = true
    when "--tac"
      opts.tac = true
    when "--bash", "--zsh", "--fish"
      opts.shell_integration = arg[2..]
    when "-n", /^--nth(=|$)/
      opts.nth, i = option_value(argv, i, arg, "--nth")
    when /^--with-nth(=|$)/
      opts.with_nth, i = option_value(argv, i, arg, "--with-nth")
    when /^--accept-nth(=|$)/
      opts.accept_nth, i = option_value(argv, i, arg, "--accept-nth")
    when "-d", /^--delimiter(=|$)/
      opts.delimiter, i = option_value(argv, i, arg, "--delimiter")
    when /^--tail(=|$)/
      val, i = option_value(argv, i, arg, "--tail")
      opts.tail = val.to_i
    when /^--scheme(=|$)/
      opts.scheme, i = option_value(argv, i, arg, "--scheme")
      die "invalid scoring scheme: #{opts.scheme} (expected: default|path|history)" unless %w[default path history].include?(opts.scheme)
      opts.tiebreak = %w[pathname length index] if opts.scheme == "path"
      opts.tiebreak = %w[index] if opts.scheme == "history"
    when /^--tiebreak(=|$)/
      val, i = option_value(argv, i, arg, "--tiebreak")
      allowed = %w[length chunk pathname begin end index]
      opts.tiebreak = val.split(",")
      bad = opts.tiebreak.find { |x| !allowed.include?(x) }
      die "invalid sort criterion: #{bad}" if bad
      opts.tiebreak << "index" unless opts.tiebreak.include?("index")
    else
      # TUI/style/binding options are accepted for compatibility. Unknown
      # options are rejected like fzf, but options with arguments are consumed.
      if arg.start_with?("--")
        known_with_value = %w[
          --algo --color --height --min-height --tmux --layout --margin --padding
          --border --border-label --border-label-pos --preview --preview-window
          --preview-border --preview-label --preview-label-pos --header
          --header-lines --footer --bind --prompt --info --info-command
          --separator --ghost --pointer --marker --marker-multi-line --ellipsis
          --tabstop --scrollbar --list-border --list-label --list-label-pos
          --input-border --input-label --input-label-pos --walker --walker-root
          --walker-skip --history --history-size --style --gap --gap-line
          --freeze-left --freeze-right --scroll-off --hscroll-off --jump-labels
          --gutter --gutter-raw --border-label --header-label --header-label-pos
          --footer-border --footer-label --footer-label-pos --listen --with-shell
        ]
        bare = arg.split("=", 2).first
        flags = %w[
          --ansi --sync --no-color --no-bold --border --multi --cycle --wrap
          --no-multi-line --raw --track --keep-right --no-hscroll --no-scrollbar
          --no-input --filepath-word --header-first --bash --zsh --fish
          --literal --no-clear --highlight-line --no-separator
        ]
        if known_with_value.include?(bare)
          i += 1 unless arg.include?("=")
        elsif flags.include?(arg)
          # ignored
        else
          die "unknown option: #{arg}"
        end
      elsif arg =~ /\A-[mx0-9]+\z/ || arg.start_with?("+")
        # Accept +m/+c-like inverse flags often used by fzf.
      else
        die "unknown option: #{arg}"
      end
    end
    i += 1
  end
  opts
end

def strip_ansi(str)
  str.gsub(/\e\[[0-?]*[ -\/]*[@-~]/, "")
end

Field = Struct.new(:text, :delim)

def split_fields(line, delimiter)
  if delimiter.nil?
    parts = line.scan(/\S+\s*/)
    return [Field.new(line, "")] if parts.empty?
    parts.map do |p|
      m = p.match(/\A(.*?)(\s*)\z/m)
      Field.new(m[1], m[2])
    end
  else
    re = Regexp.new(delimiter)
    out = []
    pos = 0
    line.to_enum(:scan, re).each do
      md = Regexp.last_match
      out << Field.new(line[pos...md.begin(0)].to_s, md[0])
      pos = md.end(0)
    end
    out << Field.new(line[pos..].to_s, "")
    out
  end
end

def idx_to_pos(idx, len)
  idx.positive? ? idx - 1 : len + idx
end

def range_for_expr(expr, len)
  if expr.include?("..")
    a, b = expr.split("..", 2)
    s = a.empty? ? 0 : idx_to_pos(a.to_i, len)
    e = b.empty? ? len - 1 : idx_to_pos(b.to_i, len)
    s = [[s, 0].max, len].min
    e = [[e, -1].max, len - 1].min
    return [] if e < s
    (s..e).to_a
  else
    p = idx_to_pos(expr.to_i, len)
    p >= 0 && p < len ? [p] : []
  end
end

def render_expr(line, exprs, delimiter, strip_last)
  fields = split_fields(line, delimiter)
  chunks = []
  exprs.split(",").each do |expr|
    range_for_expr(expr.strip, fields.length).each { |p| chunks << fields[p].text + fields[p].delim }
  end
  result = chunks.join
  result = result.sub(/#{Regexp.escape(chunks[-1]&.match(/(\s*)\z/).to_s)}\z/, "") if strip_last && delimiter.nil? && !chunks.empty?
  result = result.sub(/#{Regexp.escape(fields[range_for_expr(exprs.split(",").last.strip, fields.length).last]&.delim.to_s)}\z/, "") if strip_last && delimiter && !chunks.empty?
  result
end

def transform_template(line, tmpl, delimiter, ordinal)
  tmpl.gsub(/\{([^{}]+)\}/) do
    expr = Regexp.last_match(1)
    if expr == "n"
      ordinal.to_s
    else
      render_expr(line, expr, delimiter, true)
    end
  end
end

def transform_line(line, spec, delimiter, ordinal)
  return line unless spec
  if spec.include?("{")
    transform_template(line, spec, delimiter, ordinal)
  else
    render_expr(line, spec, delimiter, false)
  end
end

def accept_line(line, spec, delimiter, ordinal)
  return line unless spec
  if spec.include?("{")
    transform_template(line, spec, delimiter, ordinal)
  else
    render_expr(line, spec, delimiter, true)
  end
end

def case_sensitive?(query, mode)
  return false if mode == :ignore
  return true if mode == :respect
  query.match?(/[A-Z]/)
end

def normalize(str, sensitive)
  sensitive ? str : str.downcase
end

Token = Struct.new(:alts, :inverse)

def parse_query(query, opts)
  return [] if query.nil? || query.empty?
  return [Token.new([query], false)] unless opts.extended
  groups = [[]]
  query.scan(/(?:[^\s"']+|"[^"]*"|'[^']*')+/).each do |raw|
    if raw == "|"
      groups << []
    else
      groups[-1] << raw
    end
  end
  [Token.new(groups.reject(&:empty?), false)]
end

def exact_match?(text, pat)
  text.include?(pat)
end

def fuzzy_positions(text, pat)
  return [] if pat.empty?
  positions = []
  j = 0
  pat.each_char do |pc|
    found = nil
    while j < text.length
      if text[j] == pc
        found = j
        j += 1
        break
      end
      j += 1
    end
    return nil unless found
    positions << found
  end
  positions
end

def term_match(text, raw, opts, sensitive)
  inv = raw.start_with?("!")
  term = inv ? raw[1..] : raw
  quoted = term.start_with?("'")
  term = term[1..] if quoted
  prefix = term.start_with?("^")
  suffix = term.end_with?("$") && term.length > 1
  term = term[1..] if prefix
  term = term[0...-1] if suffix
  t = normalize(text, sensitive)
  p = normalize(term, sensitive)
  ok =
    if prefix && suffix
      t == p
    elsif prefix
      t.start_with?(p)
    elsif suffix
      t.end_with?(p)
    elsif opts.exact || quoted || inv
      exact_match?(t, p)
    else
      !fuzzy_positions(t, p).nil?
    end
  inv ? !ok : ok
end

def matches_query?(text, query, opts)
  return false if opts.disabled
  return true if query.nil? || query.empty?
  sensitive = case_sensitive?(query, opts.case_mode)
  if opts.extended
    alternatives = query.split(/\s+\|\s+/)
    alternatives.any? do |alt|
      alt.scan(/(?:[^\s"']+|"[^"]*"|'[^']*')+/).all? { |term| term_match(text, term, opts, sensitive) }
    end
  else
    term_match(text, query, opts, sensitive)
  end
end

def score(text, query, opts)
  return [0, 0, text.length] if query.nil? || query.empty?
  sensitive = case_sensitive?(query, opts.case_mode)
  pattern = normalize(query.gsub(/[!^$'"]/, "").split(/\s+\|\s+/).first.to_s.split(/\s+/).find { |x| !x.empty? }.to_s, sensitive)
  hay = normalize(text, sensitive)
  pos = fuzzy_positions(hay, pattern) || []
  return [-1_000_000, text.length, 0] if pos.empty? && !pattern.empty?
  span = pos.empty? ? text.length : pos[-1] - pos[0] + 1
  bonus = 0
  pos.each do |p|
    prev = p.zero? ? "/" : hay[p - 1]
    bonus += 8 if p.zero? || prev =~ /[\/\s_\-.]/
  end
  contiguous = pos.each_cons(2).count { |a, b| b == a + 1 }
  [bonus + contiguous * 4 - span, pos[0] || 0, span]
end

def sort_matches(matches, query, opts)
  return matches unless opts.sort
  matches.sort_by do |m|
    sc, begin_pos, span = score(m[:search], query, opts)
    keys = [-sc]
    opts.tiebreak.each do |tb|
      case tb
      when "length" then keys << m[:search].length
      when "chunk" then keys << span
      when "begin" then keys << begin_pos
      when "end" then keys << -begin_pos
      when "pathname"
        slash = m[:search].rindex("/") || -1
        keys << (begin_pos > slash ? 0 : 1)
      when "index" then keys << m[:index]
      end
    end
    keys
  end
end

def read_items(opts)
  data = STDIN.binmode.read || ""
  sep = opts.read0 ? "\0" : "\n"
  items = data.split(sep, -1)
  items.pop if items.last == ""
  items = items.last(opts.tail) if opts.filter.nil? && opts.tail && opts.tail.positive?
  items.reverse! if opts.tac
  items
end

opts = parse_options(ARGV)
if opts.shell_integration
  puts "# fzf #{opts.shell_integration} integration"
  puts "# This reimplementation supports fzf's batch filtering interface."
  exit 0
end
query = opts.filter || opts.query
items = read_items(opts)
records = items.each_with_index.map do |line, idx|
  display = transform_line(strip_ansi(line), opts.with_nth, opts.delimiter, idx)
  search_base = opts.nth ? transform_line(display, opts.nth, opts.delimiter, idx) : display
  { original: line, display: display, search: search_base, index: idx }
end
matches = records.select { |r| matches_query?(r[:search], query, opts) }
matches = sort_matches(matches, query, opts)

if opts.filter.nil?
  if opts.exit_0 && matches.empty?
    exit 1
  elsif opts.select_1 && matches.length == 1
    # continue to print below
  elsif !STDIN.tty?
    # In batch environments, behave usefully instead of trying to open /dev/tty.
  else
    exit 130
  end
end

out_sep = opts.print0 ? "\0" : "\n"
output = []
output << query.to_s if opts.print_query
output << "" if !opts.expect.empty? && opts.filter.nil?
matches.each do |r|
  line = if opts.accept_nth
           accept_line(strip_ansi(r[:original]), opts.accept_nth, opts.delimiter, r[:index])
        elsif opts.with_nth && opts.filter.nil?
           r[:display]
         else
           r[:original]
         end
  output << line
end
STDOUT.binmode.write(output.join(out_sep))
STDOUT.binmode.write(out_sep) unless output.empty?
exit(matches.empty? ? 1 : 0)
