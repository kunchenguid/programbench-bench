#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require 'json'
require 'time'

HEADERS = ['MODULE', 'VERSION', 'NEW VERSION', 'DIRECT', 'VALID TIMESTAMPS'].freeze

def log_error(message)
  warn "#{Time.now.strftime('%Y/%m/%d %H:%M:%S')} #{message}"
end

def usage(io = $stderr)
  io.puts 'Usage of ./executable:'
  io.puts "  -ci\n    \tNon-zero exit code when at least one outdated dependency was found"
  io.puts "  -direct\n    \tList only direct modules"
  io.puts "  -style string\n    \tOutput style, pass 'markdown' for a Markdown table (default \"default\")"
  io.puts "  -update\n    \tList only modules with updates"
end

def parse_flags(argv)
  opts = { direct: false, update: false, ci: false, style: 'default' }
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when '-direct', '--direct'
      opts[:direct] = true
    when /^--?direct=(.*)$/
      opts[:direct] = parse_bool_flag('direct', Regexp.last_match(1))
    when '-update', '--update'
      opts[:update] = true
    when /^--?update=(.*)$/
      opts[:update] = parse_bool_flag('update', Regexp.last_match(1))
    when '-ci', '--ci'
      opts[:ci] = true
    when /^--?ci=(.*)$/
      opts[:ci] = parse_bool_flag('ci', Regexp.last_match(1))
    when '-style', '--style'
      i += 1
      if i >= argv.length
        warn 'flag needs an argument: -style'
        usage
        exit 2
      end
      opts[:style] = argv[i]
    when /^--?style=(.*)$/
      opts[:style] = Regexp.last_match(1)
    when '-h', '-help', '--help'
      usage($stdout)
      exit 0
    else
      break unless arg.start_with?('-')

      warn "flag provided but not defined: #{arg}"
      usage
      exit 2
    end
    i += 1
  end
  opts
end

def parse_bool_flag(name, value)
  case value
  when '1', 't', 'T', 'TRUE', 'true', 'True'
    true
  when '0', 'f', 'F', 'FALSE', 'false', 'False'
    false
  else
    warn "invalid boolean value #{value.inspect} for -#{name}: parse error"
    usage
    exit 2
  end
end

def json_values(input)
  values = []
  i = 0
  n = input.length

  while i < n
    i += 1 while i < n && input.getbyte(i).chr.match?(/\s/)
    break if i >= n

    start = i
    opener = input[i]
    closer = opener == '{' ? '}' : (opener == '[' ? ']' : nil)
    raise JSON::ParserError, "invalid character #{opener.inspect} looking for beginning of value" unless closer

    depth = 0
    in_string = false
    escape = false

    while i < n
      ch = input[i]
      if in_string
        if escape
          escape = false
        elsif ch == '\\'
          escape = true
        elsif ch == '"'
          in_string = false
        end
      else
        case ch
        when '"'
          in_string = true
        when opener
          depth += 1
        when closer
          depth -= 1
          if depth.zero?
            i += 1
            parsed = JSON.parse(input[start...i])
            parsed.is_a?(Array) ? values.concat(parsed) : values << parsed
            break
          end
        end
      end
      i += 1
    end

    raise JSON::ParserError, 'unexpected EOF' if depth.positive?
  end

  values
end

def has_update?(mod)
  mod.key?('Update') && !mod['Update'].nil?
end

def direct?(mod)
  !mod['Indirect']
end

def valid_timestamps?(mod)
  update = mod['Update']
  return true unless update
  return true if mod['Time'].nil? || update['Time'].nil?

  current = Time.iso8601(mod['Time'])
  newer = Time.iso8601(update['Time'])
  newer >= current
end

def row_for(mod)
  update = mod['Update'] || {}
  [
    mod['Path'].to_s,
    mod['Version'].to_s,
    update['Version'].to_s,
    direct?(mod).to_s,
    valid_timestamps?(mod).to_s
  ]
end

def center(text, width)
  padding = width - text.length
  (' ' * (padding / 2)) + text + (' ' * (padding - (padding / 2)))
end

def render_table(rows, style)
  return if rows.empty?

  widths = HEADERS.map(&:length)
  rows.each do |row|
    row.each_with_index { |cell, idx| widths[idx] = [widths[idx], cell.length].max }
  end

  border = '+' + widths.map { |w| '-' * (w + 2) }.join('+') + '+'
  header = '|' + HEADERS.each_with_index.map { |h, idx| " #{center(h, widths[idx])} " }.join('|') + '|'
  separator = '|' + widths.map { |w| '-' * (w + 2) }.join('|') + '|'

  if style == 'markdown'
    puts header
    puts separator
  else
    puts border
    puts header
    puts border
  end

  rows.each do |row|
    puts '|' + row.each_with_index.map { |cell, idx| " #{cell.ljust(widths[idx])} " }.join('|') + '|'
  end

  puts border unless style == 'markdown'
end

opts = parse_flags(ARGV)

begin
  modules = json_values($stdin.read)
  modules.select! { |mod| has_update?(mod) } if opts[:update]
  modules.select! { |mod| direct?(mod) } if opts[:direct]

  rows = modules.map { |mod| row_for(mod) }
  render_table(rows, opts[:style])
  exit(opts[:ci] && modules.any? { |mod| has_update?(mod) } ? 1 : 0)
rescue JSON::ParserError, ArgumentError => e
  log_error(e.message)
  exit 0
end
