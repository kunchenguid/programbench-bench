#!/usr/bin/env ruby
# frozen_string_literal: true

require 'open3'
require 'digest'
require 'fileutils'
require 'shellwords'
require 'base64'
require 'zlib'

VERSION = '2.37.1'
SHELLS = %w[bash elvish gha murex vim zsh systemd fish gzenv json tcsh pwsh].freeze

def config_home
  ENV['DIRENV_CONFIG'] || File.join(ENV['XDG_CONFIG_HOME'] || File.join(Dir.home, '.config'), 'direnv')
end

def data_home
  File.join(ENV['XDG_DATA_HOME'] || File.join(Dir.home, '.local', 'share'), 'direnv')
end

def self_path
  File.expand_path($PROGRAM_NAME)
end

def err(msg)
  warn "\e[31mdirenv: error #{msg}\e[0m"
end

def log(msg)
  warn "\e[0mdirenv: #{msg}"
end

def bash_escape(v)
  "$'#{v.to_s.gsub("\\", "\\\\\\").gsub("'", "\\\\'").gsub("\n", "\\n")}'"
end

def sq(v)
  "'#{v.to_s.gsub("'", "'\\\\''")}'"
end

def find_rc(start = Dir.pwd)
  dir = File.expand_path(start)
  loop do
    envrc = File.join(dir, '.envrc')
    return envrc if File.file?(envrc)
    env = File.join(dir, '.env')
    return env if File.file?(env) && load_dotenv?
    parent = File.dirname(dir)
    return nil if parent == dir
    dir = parent
  end
end

def load_dotenv?
  toml = File.join(config_home, 'direnv.toml')
  return false unless File.file?(toml)
  in_global = false
  File.readlines(toml).any? do |line|
    s = line.sub(/#.*/, '').strip
    in_global = (s == '[global]') if s.start_with?('[')
    in_global && s =~ /\Aload_dotenv\s*=\s*true\b/
  end
end

def allow_key(path)
  real = File.realpath(path)
  "#{Digest::SHA256.hexdigest(real)}-#{Digest::SHA256.hexdigest(File.read(real))}"
end

def allow_dir
  File.join(data_home, 'allow')
end

def allowed?(path)
  File.file?(File.join(allow_dir, allow_key(path)))
rescue Errno::ENOENT
  false
end

def resolve_rc(arg)
  p = arg || Dir.pwd
  p = File.expand_path(p)
  if File.directory?(p)
    envrc = File.join(p, '.envrc')
    env = File.join(p, '.env')
    return envrc if File.exist?(envrc)
    return env if File.exist?(env)
    raise "#{File.basename(envrc)} file not found"
  end
  raise "lstat #{p}: no such file or directory" unless File.exist?(p)
  p
end

def fake_blob(obj)
  Base64.urlsafe_encode64(Zlib::Deflate.deflate(obj.inspect)).delete("\n")
rescue StandardError
  Digest::SHA256.hexdigest(obj.inspect)
end

def json_escape(s)
  s.to_s.gsub(/["\\\b\f\n\r\t]/) do |c|
    { '"' => '\"', '\\' => '\\\\', "\b" => '\b', "\f" => '\f', "\n" => '\n', "\r" => '\r', "\t" => '\t' }[c]
  end.gsub(/[\x00-\x1f]/) { |c| format('\u%04x', c.ord) }
end

def json_value(v, indent = 0)
  case v
  when Hash
    return '{}' if v.empty?
    inner = v.map { |k, val| "#{' ' * (indent + 2)}\"#{json_escape(k)}\": #{json_value(val, indent + 2)}" }.join(",\n")
    "{\n#{inner}\n#{' ' * indent}}"
  when Array
    '[' + v.map { |x| json_value(x, indent) }.join(', ') + ']'
  when NilClass
    'null'
  when TrueClass, FalseClass
    v ? 'true' : 'false'
  when Numeric
    v.to_s
  else
    "\"#{json_escape(v)}\""
  end
end

def stdlib
  <<~'BASH'
    has() { type "$1" >/dev/null 2>&1; }
    expand_path() {
      local p="$1" base="${2:-$PWD}"
      case "$p" in
        ~*) eval "p=$p" ;;
        /*) ;;
        *) p="$base/$p" ;;
      esac
      (cd "$(dirname "$p")" 2>/dev/null && printf '%s/%s\n' "$PWD" "$(basename "$p")")
    }
    user_rel_path() { case "$1" in "$HOME"/*) printf '~/%s\n' "${1#$HOME/}";; "$HOME") echo "~";; *) echo "$1";; esac; }
    find_up() {
      local name="${1:-.envrc}" d="$PWD"
      while true; do
        [[ -e "$d/$name" ]] && { echo "$d/$name"; return 0; }
        [[ "$d" = / ]] && return 1
        d="$(dirname "$d")"
      done
    }
    path_add() { local var="$1" p; p="$(expand_path "$2")"; eval "export $var=\"$p:\${$var:-}\""; }
    PATH_add() { path_add PATH "$1"; }
    MANPATH_add() { path_add MANPATH "$1"; }
    PATH_rm() {
      local out="" part pat keep
      IFS=: read -ra parts <<<"${PATH:-}"
      for part in "${parts[@]}"; do
        keep=1
        for pat in "$@"; do [[ "$part" == $pat ]] && keep=0; done
        [[ $keep = 1 ]] && out="${out:+$out:}$part"
      done
      export PATH="$out"
    }
    dotenv() {
      local f="${1:-.env}"
      [[ -f "$f" ]] || return 1
      set -a
      source "$f"
      set +a
    }
    dotenv_if_exists() { local f="${1:-.env}"; [[ -f "$f" ]] && dotenv "$f" || true; }
    source_env() { local f="$1"; [[ -d "$f" ]] && f="$f/.envrc"; source "$f"; }
    source_env_if_exists() { [[ -f "$1" ]] && source "$1" || true; }
    source_up() { local f; f="$(find_up "${1:-.envrc}")" || return 1; source "$f"; }
    source_up_if_exists() { source_up "${1:-.envrc}" || true; }
    watch_file() { :; }
    watch_dir() { :; }
    env_vars_required() { local v ok=0; for v in "$@"; do [[ -n "${!v:-}" ]] || { echo "direnv: error $v is required" >&2; ok=1; }; done; return $ok; }
    direnv_layout_dir() { local h; h="$(printf '%s' "$PWD" | sha1sum | cut -d' ' -f1)"; echo "${XDG_CACHE_HOME:-$HOME/.cache}/direnv/layouts/$h"; }
    load_prefix() { local p; p="$(expand_path "$1")"; PATH_add "$p/bin"; path_add CPATH "$p/include"; path_add LD_LIBRARY_PATH "$p/lib"; path_add LIBRARY_PATH "$p/lib"; path_add PKG_CONFIG_PATH "$p/lib/pkgconfig"; MANPATH_add "$p/share/man"; }
    layout() { local f="layout_$1"; shift; "$f" "$@"; }
    layout_go() { export GOPATH="$(direnv_layout_dir)/go"; PATH_add bin; }
    layout_node() { PATH_add node_modules/.bin; }
    layout_php() { PATH_add vendor/bin; }
    layout_julia() { export JULIA_PROJECT="$PWD"; }
    layout_python() { local py="${1:-python}"; local d="$PWD/.direnv/python-${py##*/}"; export VIRTUAL_ENV="$d"; PATH_add "$d/bin"; }
    layout_python3() { layout_python python3; }
    layout_ruby() { local ruby_version; ruby_version="$(ruby -e 'print RUBY_VERSION' 2>/dev/null || echo ruby)"; export GEM_HOME="$PWD/.direnv/ruby/$ruby_version"; PATH_add "$GEM_HOME/bin"; }
    use() { local f="use_$1"; shift; "$f" "$@"; }
    use_vim() { export DIRENV_EXTRA_VIMRC="${1:-.vimrc.local}${DIRENV_EXTRA_VIMRC:+:$DIRENV_EXTRA_VIMRC}"; }
    strict_env() { set -euo pipefail; (($#)) && "$@"; }
    unstrict_env() { set +e +u +o pipefail; (($#)) && "$@"; }
    direnv_version() { "$direnv" version "$1"; }
    on_git_branch() { git rev-parse --is-inside-work-tree >/dev/null 2>&1 || return 1; local b; b="$(git branch --show-current 2>/dev/null)"; [[ $# = 0 || "$b" = "$1" ]]; }
  BASH
end

def evaluate_rc(path)
  script = <<~BASH
    set +e
    direnv=#{Shellwords.escape(self_path)}
    export DIRENV_IN_ENVRC=1
    #{stdlib}
    cd #{Shellwords.escape(File.dirname(path))} || exit 1
    printf '__DIRENV_BEFORE__\\0'
    env -0
    printf '__DIRENV_AFTER__\\0'
    source #{Shellwords.escape(path)}
    env -0
  BASH
  out, stderr, status = Open3.capture3('/usr/bin/bash', '-lc', script)
  return [nil, stderr, status.exitstatus] unless status.success?
  parts = out.split("\0")
  before = {}
  after = {}
  target = nil
  parts.each do |entry|
    if entry == '__DIRENV_BEFORE__'
      target = before
      next
    elsif entry == '__DIRENV_AFTER__'
      target = after
      next
    end
    next unless target
    next if entry.empty?
    k, v = entry.split('=', 2)
    target[k] = v || ''
  end
  after.delete('DIRENV_IN_ENVRC')
  before.delete('DIRENV_IN_ENVRC')
  diff = {}
  after.each { |k, v| diff[k] = v if before[k] != v }
  before.each_key { |k| diff[k] = nil unless after.key?(k) }
  diff.delete_if { |k, _| k == '_' || k == 'SHLVL' || k.start_with?('BASH_FUNC_') }
  diff['DIRENV_DIR'] = "-#{File.dirname(path)}"
  diff['DIRENV_FILE'] = path
  diff['DIRENV_DIFF'] = fake_blob(diff)
  diff['DIRENV_WATCHES'] = fake_blob([path, File.mtime(path).to_i])
  [diff, stderr, 0]
end

def render(shell, diff)
  keys = diff.keys
  case shell
  when 'bash', 'zsh'
    keys.map { |k| diff[k].nil? ? "unset #{k};" : "export #{k}=#{bash_escape(diff[k])};" }.join
  when 'fish'
    keys.map { |k| diff[k].nil? ? "set -e #{sq(k)};" : "set -x -g #{sq(k)} #{sq(diff[k])};" }.join
  when 'tcsh'
    keys.map { |k| diff[k].nil? ? "unsetenv #{k} ;" : "setenv #{k} #{diff[k]} ;" }.join
  when 'pwsh'
    keys.map { |k| diff[k].nil? ? "Remove-Item Env:\\#{k} -ErrorAction SilentlyContinue;" : "${env:#{k}}=#{sq(diff[k])};" }.join
  when 'json'
    json_value(diff.reject { |_, v| v.nil? })
  when 'murex', 'elvish'
    json_value(diff)
  when 'systemd'
    diff.reject { |_, v| v.nil? }.map { |k, v| "#{k}=#{v}" }.join("\n")
  when 'vim'
    diff.map { |k, v| v.nil? ? "call #{sq('')}" : "call setenv(#{sq(k)},#{sq(v)})" }.join("\n")
  when 'gha'
    diff.reject { |_, v| v.nil? }.map { |k, v| d = "ghadelimiter_#{Digest::MD5.hexdigest(k + v.to_s)}"; "#{k}<<#{d}\n#{v}\n#{d}" }.join("\n")
  when 'gzenv'
    fake_blob(diff)
  else
    raise "unknown target shell '#{shell}'"
  end
end

def help_text
  <<~TEXT
    direnv v#{VERSION}
    Usage: direnv COMMAND [...ARGS]

    Available commands
    ------------------
    allow [PATH_TO_RC]:
      aliases: permit, grant
      Grants direnv permission to load the given .envrc or .env file.
    block [PATH_TO_RC]:
      aliases: deny, disallow, revoke
      Revokes the authorization of a given .envrc or .env file.
    edit [PATH_TO_RC]:
      Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow
      the file to be loaded afterwards.
    exec DIR COMMAND [...ARGS]:
      Executes a command after loading the first .envrc or .env found in DIR
    export SHELL:
      Loads an .envrc or .env and prints the diff in terms of exports.
      Supported SHELL values are: [#{SHELLS.join(', ')}]
    fetchurl <url> [<integrity-hash>]:
      Fetches a given URL into direnv's CAS
    help [SHOW_PRIVATE]:
      Shows this help
    hook SHELL:
      Used to setup the shell hook
    prune:
      Removes old allowed and required files
    reload:
      Triggers an env reload
    status [--json]:
      Prints some debug status information
    stdlib:
      Displays the stdlib available in the .envrc execution context
    version [VERSION_AT_LEAST]:
      prints the version or checks that direnv is older than VERSION_AT_LEAST.
    log [--status | --error] <message>:
      Logs a given message
  TEXT
end

def hook(shell)
  case shell
  when 'bash'
    %Q{\n_direnv_hook() {\n  local previous_exit_status=$?;\n  vars=("#{self_path}" export bash);\n  vars="$("${vars[@]}")";\n  trap -- '' SIGINT;\n  eval "$vars";\n  trap - SIGINT;\n  return $previous_exit_status;\n};\nif [[ ";${PROMPT_COMMAND[*]:-};" != *";_direnv_hook;"* ]]; then\n  if [[ "$(declare -p PROMPT_COMMAND 2>&1)" == "declare -a"* ]]; then\n    PROMPT_COMMAND=(_direnv_hook "${PROMPT_COMMAND[@]}")\n  else\n    PROMPT_COMMAND="_direnv_hook${PROMPT_COMMAND:+;$PROMPT_COMMAND}"\n  fi\nfi}
  when 'zsh'
    %Q{\n_direnv_hook() {\n  vars="$("#{self_path}" export zsh)"\n  trap -- '' SIGINT\n  eval "$vars"\n  trap - SIGINT\n}\ntypeset -ag precmd_functions\nif (( ! ${precmd_functions[(I)_direnv_hook]} )); then\n  precmd_functions=(_direnv_hook $precmd_functions)\nfi\ntypeset -ag chpwd_functions\nif (( ! ${chpwd_functions[(I)_direnv_hook]} )); then\n  chpwd_functions=(_direnv_hook $chpwd_functions)\nfi}
  when 'fish'
    %Q{\n    function __direnv_export_eval --on-event fish_prompt;\n        "#{self_path}" export fish | source;\n    end;\n}
  when 'tcsh'
    "alias precmd 'eval `#{self_path} export tcsh`'"
  when 'pwsh'
    "$ExecutionContext.SessionState.InvokeCommand.LocationChangedAction = { #{self_path} export pwsh | Invoke-Expression }"
  when 'murex'
    "event: onPrompt direnv_hook=before {\n\t\"#{self_path}\" export murex -> set exports\n}"
  when 'elvish'
    "## hook for direnv\nset @edit:before-readline = $@edit:before-readline { #{self_path} export elvish }"
  when 'gha'
    raise 'Hook not implemented for GitHub Actions shell'
  when 'gzenv'
    raise "the gzenv shell doesn't support hooking"
  when 'json', 'systemd'
    raise 'this feature is not supported'
  when 'vim'
    raise 'this feature is not supported. Install the direnv.vim plugin instead'
  else
    raise "unknown target shell '#{shell}'"
  end
end

def semver(s)
  raise "v#{s} is not a valid semver version" unless s =~ /\A\d+\.\d+\.\d+\z/
  s.split('.').map(&:to_i)
end

begin
  cmd = ARGV.shift || 'help'
  case cmd
  when 'help', '--help', '-h'
    puts help_text
  when 'version'
    if ARGV.empty?
      puts VERSION
    else
      desired = semver(ARGV[0])
      if (semver(VERSION) <=> desired) < 0
        raise "current version v#{VERSION} is older than the desired version v#{ARGV[0]}"
      end
    end
  when 'allow', 'permit', 'grant'
    path = resolve_rc(ARGV[0])
    FileUtils.mkdir_p(allow_dir)
    File.write(File.join(allow_dir, allow_key(path)), path)
  when 'deny', 'disallow', 'revoke', 'block'
    path = resolve_rc(ARGV[0])
    FileUtils.rm_f(File.join(allow_dir, allow_key(path)))
  when 'export'
    shell = ARGV.shift || raise('not enough arguments')
    raise "unknown target shell '#{shell}'" unless SHELLS.include?(shell)
    path = find_rc
    exit 0 unless path
    unless allowed?(path)
      diff = { 'DIRENV_DIR' => "-#{File.dirname(path)}", 'DIRENV_FILE' => path }
      diff['DIRENV_DIFF'] = fake_blob(diff)
      diff['DIRENV_WATCHES'] = fake_blob([path, File.mtime(path).to_i])
      puts render(shell, diff)
      err "#{path} is blocked. Run `direnv allow` to approve its content"
      exit 1
    end
    diff, stderr, st = evaluate_rc(path)
    unless st.zero?
      warn stderr unless stderr.empty?
      exit st
    end
    puts render(shell, diff)
    log "loading #{path}"
    changed = diff.keys.reject { |k| k.start_with?('DIRENV_') }
    log "export #{changed.map { |k| diff[k].nil? ? '-' + k : '+' + k }.join(' ')}" unless changed.empty?
  when 'exec'
    dir = ARGV.shift || raise('not enough arguments')
    raise 'not enough arguments' if ARGV.empty?
    path = find_rc(dir)
    env = ENV.to_h
    if path
      raise "#{path} is blocked. Run `direnv allow` to approve its content" unless allowed?(path)
      diff, stderr, st = evaluate_rc(path)
      warn stderr unless stderr.empty?
      exit st unless st.zero?
      diff.each { |k, v| v.nil? ? env.delete(k) : env[k] = v }
      log "loading #{path}"
    end
    exec(env, *ARGV)
  when 'hook'
    shell = ARGV.shift || raise('not enough arguments')
    puts hook(shell)
  when 'stdlib'
    puts "#!/usr/bin/env bash"
    puts "#"
    puts "# These are the commands available in an .envrc context"
    puts "direnv=#{Shellwords.escape(self_path)}"
    puts stdlib
  when 'status'
    path = find_rc
    if ARGV[0] == '--json'
      puts json_value({ config: { ConfigDir: config_home, SelfPath: self_path }, state: { foundRC: path ? { allowed: allowed?(path) ? 0 : 2, path: path } : nil, loadedRC: nil } })
    else
      puts "direnv exec path #{self_path}"
      puts "DIRENV_CONFIG #{config_home}"
      puts "bash_path /usr/bin/bash"
      puts "disable_stdin false"
      puts "warn_timeout 5s"
      puts "whitelist.prefix []"
      puts "whitelist.exact map[]"
      puts path ? "Found RC path #{path}" : 'No .envrc or .env found'
    end
  when 'reload'
    raise '.envrc not found' unless find_rc
  when 'prune'
    raise "open #{File.join(data_home, 'allow')}: no such file or directory" unless Dir.exist?(allow_dir)
  when 'log'
    mode = ARGV.shift
    raise 'invalid arguments' unless mode && ARGV.any?
    msg = ARGV.join(' ')
    mode == '--error' ? err(msg) : log(msg)
  when 'edit'
    editor = ENV['EDITOR']
    unless editor && !editor.empty?
      warn "\e[31mdirenv: $EDITOR not found.\e[0m"
      raise 'could not find a default editor in the PATH'
    end
    path = resolve_rc(ARGV[0])
    system(editor, path)
    FileUtils.mkdir_p(allow_dir)
    File.write(File.join(allow_dir, allow_key(path)), path)
  when 'fetchurl'
    raise 'Get "' + (ARGV[0] || '') + '": unsupported protocol scheme ""'
  else
    raise "unknown command #{cmd}"
  end
rescue StandardError => e
  err e.message
  exit 1
end
