#!/usr/bin/env ruby
# frozen_string_literal: true

require 'base64'
require 'zlib'

VERSION_TEXT = <<~TEXT
  Chafa version 1.19.0

  Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD
  Features: mmx sse4.1 popcnt avx2
  Applying: mmx sse4.1 popcnt avx2

  Copyright (C) 2018-2025 Hans Petter Jansson et al.
  Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox
  Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne
  Incl. QOI decoder copyright (C) 2021 Dominic Szablewski

  This is free software; see the source for copying conditions. There is NO
  warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
TEXT

HELP_TEXT = <<~TEXT
  Usage:
    ./executable [OPTION...] [FILE...]

    Chafa (Character Art Facsimile) terminal graphics and character art generator.

  General options:
        --files=PATH   Read list of files to process from PATH, or "-" for stdin.
        --files0=PATH  Similar to --files, using NUL separator instead of newline.
    -h, --help         Show help.
        --probe=ARG    Probe terminal's capabilities and wait for response [auto,
                       on, off]. A positive real number denotes the maximum time
                       to wait for a response, in seconds. Defaults to 5.0.
        --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].
        --version      Show version.
    -v, --verbose      Be verbose.

  Output encoding:
    -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,
                       symbols]. Iterm, kitty and sixels yield much higher
                       quality but enjoy limited support. Symbols mode yields
                       beautiful character art.
    -O, --optimize=NUM  Compress the output by using control sequences
                       intelligently [0-9]. 0 disables, 9 enables every
                       available optimization. Defaults to 5, except for when
                       used with "-c none", where it defaults to 0.
        --relative=BOOL  Use relative cursor positioning [on, off]. When on,
                       control sequences will be used to position images relative
                       to the cursor. When off, newlines will be used to separate
                       rows instead for e.g. 'less -R' interop. Defaults to off.
        --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,
                       tmux]. Used to show pixel graphics through multiplexers.
        --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may
                       confuse other programs. Defaults to off.

  Size and layout:
        --align=ALIGN  Horizontal and vertical alignment (e.g. "top,left").
        --clear        Clear screen before processing each file.
        --exact-size=MODE  Try to match the input's size exactly [auto, on, off].
        --fit-width    Fit images to view's width, possibly exceeding its height.
        --font-ratio=W/H  Target font's width/height ratio. Can be specified as
                       a real number or a fraction. Defaults to 1/2.
        --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.
                       C or R may be omitted, e.g. "--grid 4". Can be "auto".
    -g                 Alias for "--grid auto".
        --label=BOOL   Labeling [on, off]. Filenames below images. Default off.
    -l                 Alias for "--label on".
        --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable
                       hyperlinks. Use with "--label on". Defaults to auto.
        --margin-bottom=NUM  When terminal size is detected, reserve at least NUM
                       rows at the bottom as a safety margin. Can be used to
                       prevent images from scrolling out. Defaults to 1.
        --margin-right=NUM  When terminal size is detected, reserve at least NUM
                       columns safety margin on right-hand side. Defaults to 0.
        --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates
                       image's pixel dimensions. Specify "max" to fit view.
                       Defaults to 1.0 for pixel graphics and 4.0 for symbols.
    -s, --size=WxH     Set maximum image dimensions in columns and rows. By
                       default this will be equal to the view size.
        --stretch      Stretch image to fit output dimensions; ignore aspect.
                       Implies --scale max.
        --view-size=WxH  Set the view size in columns and rows. By default this
                       will be the size of your terminal, or 80x25 if size
                       detection fails. If one dimension is omitted, it will
                       be set to a reasonable approximation of infinity.

  Animation and timing:
        --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.
                       When off, will show a still frame from each animation.
    -d, --duration=SECONDS  How long to show each file. If showing a single file,
                       defaults to zero for a still image and infinite for an
                       animation. For multiple files, defaults to zero. Animations
                       will always be played through at least once.
        --speed=SPEED  Animation speed. Either a unitless multiplier, or a real
                       number followed by "fps" to apply a specific framerate.
        --watch        Watch a single input file, redisplaying it whenever its
                       contents change. Will run until manually interrupted
                       or, if --duration is set, until it expires.

  Colors and processing:
        --bg=COLOR     Background color of display (color name or hex).
    -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,
                       256, full]. Defaults to best guess.
        --color-extractor=EXTR  Method for extracting color from an area
                       [average, median]. Average is the default.
        --color-space=CS  Color space used for quantization; one of [rgb, din99d].
                       Defaults to rgb, which is faster but less accurate.
        --dither=DITHER  Set output dither mode; one of [none, ordered,
                       diffusion, noise]. No effect with 24-bit color. Defaults to
                       noise for sixels, none otherwise.
        --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a
                       character cell [1, 2, 4, 8]. Defaults to 4x4.
        --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].
                       Defaults to 1.0.
        --fg=COLOR     Foreground color of display (color name or hex).
        --invert       Swaps --fg and --bg. Useful with light terminal background.
    -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16
                       colors or lower, off otherwise.
    -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].

  Resource allocation:
        --threads=NUM  Maximum number of CPU threads to use. If left unspecified
                       or negative, this will equal available CPU cores.
    -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the
                       cheapest, 9 is the most accurate. Defaults to 5.

  Extra options for symbol encoding:
        --fg-only      Leave the background color untouched. This produces
                       character-cell output using foreground colors only.
        --fill=SYMS    Specify character symbols to use for fill/gradients.
                       Defaults to none. See below for full usage.
        --glyph-file=FILE  Load glyph information from FILE, which can be any
                       font file supported by FreeType (TTF, PCF, etc).
        --symbols=SYMS  Specify character symbols to employ in final output.
                       See below for full usage and a list of symbol classes.

  Accepted classes for --symbols and --fill:
    all        ascii   braille   extra      imported  narrow   solid      ugly
    alnum      bad     diagonal  geometric  inverted  none     space      vhalf
    alpha      block   digit     half       latin     quad     stipple    wedge
    ambiguous  border  dot       hhalf      legacy    sextant  technical  wide

    These can be combined with + and -, e.g. block+border-diagonal or all-wide.

  Examples:
    $ chafa --scale max in.jpg                           # As big as will fit
    $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow
    $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art
    $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)

  If your OS comes with manual pages, you can type 'man chafa' for more.
TEXT

class CliError < StandardError; end

class PngImage
  attr_reader :width, :height, :pixels

  def initialize(data)
    raise CliError, 'Unknown file format' unless data.start_with?("\x89PNG\r\n\x1a\n".b)

    pos = 8
    idat = +''
    @palette = nil
    @transparency = nil
    while pos < data.bytesize
      len = data[pos, 4].unpack1('N')
      type = data[pos + 4, 4]
      chunk = data[pos + 8, len]
      pos += 12 + len
      case type
      when 'IHDR'
        @width, @height, @bit_depth, @color_type, @compression, @filter, @interlace = chunk.unpack('NNCCCCC')
      when 'PLTE'
        @palette = chunk.bytes.each_slice(3).map { |r, g, b| [r, g, b, 255] }
      when 'tRNS'
        @transparency = chunk.bytes
      when 'IDAT'
        idat << chunk
      when 'IEND'
        break
      end
    end
    validate_png
    raw = Zlib::Inflate.inflate(idat)
    decode_scanlines(raw)
  rescue Zlib::Error
    raise CliError, 'Could not decode PNG data'
  end

  private

  def validate_png
    raise CliError, 'Unsupported PNG compression method' unless @compression == 0 && @filter == 0
    raise CliError, 'Interlaced PNG files are not supported' unless @interlace == 0
    supported = [[8, 0], [8, 2], [8, 3], [8, 4], [8, 6], [16, 0], [16, 2], [16, 4], [16, 6]]
    raise CliError, 'Unsupported PNG color format' unless supported.include?([@bit_depth, @color_type])
  end

  def channels
    { 0 => 1, 2 => 3, 3 => 1, 4 => 2, 6 => 4 }[@color_type]
  end

  def decode_scanlines(raw)
    bytes_per_sample = @bit_depth == 16 ? 2 : 1
    bpp = channels * bytes_per_sample
    row_len = @width * bpp
    prev = Array.new(row_len, 0)
    offset = 0
    @pixels = []
    @height.times do
      filter = raw.getbyte(offset)
      offset += 1
      row = raw.byteslice(offset, row_len).bytes
      offset += row_len
      unfilter!(row, prev, filter, bpp)
      @pixels << pixels_from_row(row, bytes_per_sample)
      prev = row
    end
  end

  def unfilter!(row, prev, filter, bpp)
    row.each_index do |i|
      left = i >= bpp ? row[i - bpp] : 0
      up = prev[i] || 0
      ul = i >= bpp ? prev[i - bpp] : 0
      row[i] = (row[i] + case filter
                         when 0 then 0
                         when 1 then left
                         when 2 then up
                         when 3 then (left + up) / 2
                         when 4 then paeth(left, up, ul)
                         else raise CliError, 'Unsupported PNG filter'
                         end) & 0xff
    end
  end

  def paeth(a, b, c)
    p = a + b - c
    pa = (p - a).abs
    pb = (p - b).abs
    pc = (p - c).abs
    return a if pa <= pb && pa <= pc
    return b if pb <= pc

    c
  end

  def sample(row, idx, bytes_per_sample)
    bytes_per_sample == 1 ? row[idx] : row[idx]
  end

  def pixels_from_row(row, bytes_per_sample)
    out = []
    stride = channels * bytes_per_sample
    @width.times do |x|
      i = x * stride
      out << case @color_type
             when 0
               g = sample(row, i, bytes_per_sample)
               [g, g, g, 255]
             when 2
               [sample(row, i, bytes_per_sample), sample(row, i + bytes_per_sample, bytes_per_sample),
                sample(row, i + 2 * bytes_per_sample, bytes_per_sample), 255]
             when 3
               px = (@palette || [])[row[i]] || [0, 0, 0, 255]
               alpha = @transparency && @transparency[row[i]] ? @transparency[row[i]] : px[3]
               [px[0], px[1], px[2], alpha]
             when 4
               g = sample(row, i, bytes_per_sample)
               [g, g, g, sample(row, i + bytes_per_sample, bytes_per_sample)]
             when 6
               [sample(row, i, bytes_per_sample), sample(row, i + bytes_per_sample, bytes_per_sample),
                sample(row, i + 2 * bytes_per_sample, bytes_per_sample), sample(row, i + 3 * bytes_per_sample, bytes_per_sample)]
             end
    end
    out
  end
end

def parse_size(text)
  raise CliError, 'Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.' unless text =~ /\A(\d*)x(\d*)\z/i

  w = Regexp.last_match(1).empty? ? nil : Regexp.last_match(1).to_i
  h = Regexp.last_match(2).empty? ? nil : Regexp.last_match(2).to_i
  raise CliError, 'Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.' if !w && !h

  [w, h]
end

def parse_bool(text, name)
  return text if %w[on off auto].include?(text)

  raise CliError, "#{name} must be one of [auto, on, off]."
end

def parse_args(argv)
  opts = {
    format: 'symbols', colors: 'auto', symbols: 'default', size: [80, 25],
    label: false, clear: false, files: [], files0: []
  }
  files = []
  i = 0
  need = lambda do |opt|
    i += 1
    raise CliError, "Option #{opt} requires an argument" if i >= argv.length

    argv[i]
  end
  while i < argv.length
    arg = argv[i]
    if arg == '--'
      files.concat(argv[(i + 1)..] || [])
      break
    elsif arg == '-h' || arg == '--help'
      puts HELP_TEXT
      exit 0
    elsif arg == '--version'
      puts VERSION_TEXT
      exit 0
    elsif arg == '-v' || arg == '--verbose'
      opts[:verbose] = true
    elsif arg == '-g'
      opts[:grid] = 'auto'
    elsif arg == '-l'
      opts[:label] = true
    elsif arg == '--clear'
      opts[:clear] = true
    elsif arg == '--stretch' || arg == '--fit-width' || arg == '--fg-only' || arg == '--watch' || arg == '--invert'
      opts[arg.delete_prefix('--').tr('-', '_').to_sym] = true
    elsif arg == '-s' || arg == '--size'
      opts[:size] = parse_size(need.call(arg))
    elsif arg.start_with?('--size=')
      opts[:size] = parse_size(arg.split('=', 2)[1])
    elsif arg == '-f' || arg == '--format'
      opts[:format] = need.call(arg)
    elsif arg.start_with?('--format=')
      opts[:format] = arg.split('=', 2)[1]
    elsif arg == '-c' || arg == '--colors'
      opts[:colors] = need.call(arg)
    elsif arg.start_with?('--colors=')
      opts[:colors] = arg.split('=', 2)[1]
    elsif arg == '--symbols'
      opts[:symbols] = need.call(arg)
    elsif arg.start_with?('--symbols=')
      opts[:symbols] = arg.split('=', 2)[1]
    elsif arg == '--files'
      opts[:files] << need.call(arg)
    elsif arg.start_with?('--files=')
      opts[:files] << arg.split('=', 2)[1]
    elsif arg == '--files0'
      opts[:files0] << need.call(arg)
    elsif arg.start_with?('--files0=')
      opts[:files0] << arg.split('=', 2)[1]
    elsif arg.start_with?('--')
      key, val = arg.split('=', 2)
      known_with_arg = %w[--probe --probe-mode --optimize --relative --passthrough --polite --align --exact-size --font-ratio --grid --label --link --margin-bottom --margin-right --scale --view-size --animate --duration --speed --bg --color-extractor --color-space --dither --dither-grain --dither-intensity --fg --preprocess --threshold --threads --work --fill --glyph-file]
      if known_with_arg.include?(key)
        val ||= need.call(key)
        sym = key.delete_prefix('--').tr('-', '_').to_sym
        opts[sym] = sym == :label ? (val == 'on') : val
      else
        raise CliError, "Unknown option #{key}"
      end
    elsif arg.start_with?('-') && arg.length > 1
      if arg.start_with?('-s') && arg.length > 2
        opts[:size] = parse_size(arg[2..])
      elsif arg.start_with?('-c') && arg.length > 2
        opts[:colors] = arg[2..]
      elsif arg.start_with?('-f') && arg.length > 2
        opts[:format] = arg[2..]
      elsif arg == '-d' || arg == '-O' || arg == '-p' || arg == '-t' || arg == '-w'
        opts[arg[1].to_sym] = need.call(arg)
      else
        raise CliError, "Unknown option #{arg}"
      end
    else
      files << arg
    end
    i += 1
  end

  formats = %w[iterm kitty sixels symbols]
  raise CliError, "Output format given as '#{opts[:format]}'. Must be one of [iterm, kitty, sixels, symbols]." unless formats.include?(opts[:format])

  colors = %w[auto none 2 8 16/8 16 240 256 full]
  raise CliError, 'Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].' unless colors.include?(opts[:colors])

  opts[:files].each { |path| files.concat(read_file_list(path, "\n")) }
  opts[:files0].each { |path| files.concat(read_file_list(path, "\0")) }
  files << '-' if files.empty?
  [opts, files]
end

def read_file_list(path, sep)
  data = path == '-' ? STDIN.read : File.binread(path)
  data.split(sep).reject(&:empty?)
rescue Errno::ENOENT
  raise CliError, "Failed to open '#{path}': No such file or directory"
end

def load_image(path)
  data = path == '-' ? STDIN.binmode.read : File.binread(path)
  raise CliError, "Failed to open '#{path}': Could not cache input stream" if path == '-' && data.empty?

  PngImage.new(data)
rescue Errno::ENOENT
  raise CliError, "Failed to open '#{path}': No such file or directory"
rescue Errno::EACCES
  raise CliError, "Failed to open '#{path}': Permission denied"
rescue CliError => e
  raise if e.message.start_with?('Failed to open')

  raise CliError, "Failed to open '#{path}': #{e.message}"
end

def dimensions_for(image, opts)
  max_w, max_h = opts[:size]
  max_w ||= 80
  max_h ||= 25
  if opts[:stretch]
    return [max_w, max_h]
  end
  aspect_h = [(image.height * 0.5 * max_w / image.width.to_f).round, 1].max
  if aspect_h <= max_h
    [max_w, aspect_h]
  else
    w = [(image.width * max_h / (image.height * 0.5).to_f).round, 1].max
    [[w, max_w].min, max_h]
  end
end

def average_pixel(image, x0, y0, x1, y1)
  sx0 = [[x0.floor, 0].max, image.width - 1].min
  sx1 = [[x1.ceil, 1].max, image.width].min
  sy0 = [[y0.floor, 0].max, image.height - 1].min
  sy1 = [[y1.ceil, 1].max, image.height].min
  r = g = b = a = n = 0
  (sy0...sy1).each do |y|
    row = image.pixels[y]
    (sx0...sx1).each do |x|
      px = row[x]
      alpha = px[3] / 255.0
      r += (px[0] * alpha).round
      g += (px[1] * alpha).round
      b += (px[2] * alpha).round
      a += px[3]
      n += 1
    end
  end
  n = 1 if n.zero?
  [r / n, g / n, b / n, a / n]
end

def luminance(px)
  return 255 if px[3] < 16

  (0.2126 * px[0] + 0.7152 * px[1] + 0.0722 * px[2]).round
end

def palette_for(symbols)
  s = symbols.to_s
  if s.include?('block')
    [' ', '▁', '▂', '▃', '▄', '▅', '▆', '▇', '█']
  elsif s.include?('ascii')
    [' ', '.', ':', '-', '=', '+', '*', '#', '%', '@']
  else
    [' ', '░', '▒', '▓', '█']
  end
end

def ansi_color(px, bg = false)
  code = bg ? 48 : 38
  "\e[#{code};2;#{px[0]};#{px[1]};#{px[2]}m"
end

def render_symbols(image, opts)
  w, h = dimensions_for(image, opts)
  chars = palette_for(opts[:symbols])
  color = opts[:colors] != 'none' && opts[:colors] != 'auto'
  out = +''
  h.times do |y|
    w.times do |x|
      px = average_pixel(image, x * image.width.to_f / w, y * image.height.to_f / h,
                         (x + 1) * image.width.to_f / w, (y + 1) * image.height.to_f / h)
      idx = (luminance(px) * (chars.length - 1) / 255.0).round
      out << ansi_color(px) if color
      out << chars[idx]
    end
    out << "\e[0m" if color
    out << "\n"
  end
  out
end

def render_protocol(image, opts, path)
  data = path == '-' ? '' : File.binread(path)
  case opts[:format]
  when 'iterm'
    "\e]1337;File=inline=1;width=#{image.width}px;height=#{image.height}px:#{Base64.strict_encode64(data)}\a\n"
  when 'kitty'
    b64 = Base64.strict_encode64(data)
    "\e_Gf=100,a=T,s=#{image.width},v=#{image.height},m=0;#{b64}\e\\\n"
  when 'sixels'
    "\ePq\"1;1;#{image.width};#{image.height}#0;2;0;0;0#0~~\e\\\n"
  else
    render_symbols(image, opts)
  end
end

begin
  opts, files = parse_args(ARGV)
  files.each_with_index do |path, idx|
    print "\e[H\e[2J" if opts[:clear]
    image = load_image(path)
    print render_protocol(image, opts, path)
    puts path if opts[:label]
    puts if idx < files.length - 1
  end
rescue CliError => e
  warn "./executable: #{e.message}"
  exit 2
end
