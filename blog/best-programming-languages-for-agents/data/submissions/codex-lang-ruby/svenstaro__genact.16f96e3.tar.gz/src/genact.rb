#!/usr/bin/env ruby
# frozen_string_literal: true

MODULES = %w[
  ansible bootlog botnet bruteforce cargo cc composer cryptomining docker_build
  docker_image_rm download julia kernel_compile memdump mkinitcpio rkhunter
  simcity terraform uv weblog wpt
].freeze

VERSION = "genact 1.5.1"

HELP = <<~HELP
  A nonsense activity generator

  Usage: executable [OPTIONS]

  Options:
    -l, --list-modules
            List available modules
    -m, --modules <MODULES>
            Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,
            composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,
            memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]
    -s, --speed-factor <SPEED_FACTOR>
            Global speed factor [default: 1]
    -i, --instant-print-lines <INSTANT_PRINT_LINES>
            Instantly print this many lines [default: 0]
        --inhibit
            Keep the computer awake and the display on while genact is running
        --exit-after-time <EXIT_AFTER_TIME>
            Exit after running for this long (format example: 2h10min)
        --exit-after-modules <EXIT_AFTER_MODULES>
            Exit after running this many modules
        --print-completions <shell>
            Generate completion file for a shell [possible values: bash, elvish, fish, powershell,
            zsh]
        --print-manpage
            Generate man page
    -h, --help
            Print help
    -V, --version
            Print version
HELP

WORDS = %w[
  ab accusamus adipisci alias amet animi architecto aspernatur assumenda at aut autem
  beatae blanditiis commodi consequatur corrupti cupiditate debitis dicta dolorem
  doloremque dolores ducimus ea eaque enim eos error est et exercitationem explicabo
  facere fugiat fugit hic id impedit in inventore ipsa ipsam ipsum iste iure iusto
  laboriosam libero magnam maxime minima modi molestiae mollitia nam natus nemo neque
  nesciunt nihil nisi nulla occaecati officia officiis omnis optio perspiciatis
  praesentium provident quam qui quia quibusdam quisquam ratione recusandae
  reiciendis repellat repudiandae sed sequi similique sint sit sunt suscipit tempora
  tempore tenetur ullam ut velit veniam voluptate voluptates voluptatibus
].freeze

CRATES = %w[
  serde rand tokio clap anyhow libc regex log futures syn quote parking_lot
  openssl-sys bindgen reqwest hyper axum bevy nalgebra image chrono nom rayon
  rustls tempfile thiserror tracing proc-macro2 wgpu git2 nix gix toml
].freeze

FILES = %w[
  init.c main.c parser.c arena.c vnode.c device.c scheduler.c sysctl.c mmu.c
  irq.c dma.c socket.c tcp.c ext4.c btree.c crypto.c display.c firmware.c
].freeze

def color(code, text)
  $stdout.tty? ? "\e[#{code}m#{text}\e[0m" : text
end

def puts_flush(line = "")
  puts line
  STDOUT.flush
end

def usage_error(message, tip = nil)
  warn "error: #{message}"
  warn "  [possible values: #{MODULES.join(", ")}]" if message.include?("--modules")
  warn
  warn "  tip: #{tip}" if tip
  warn "For more information, try '--help'."
  exit 2
end

def parse_duration(text)
  return Float(text) if text =~ /\A\d+(\.\d+)?\z/

  total = 0.0
  rest = text.dup
  matched = false
  while rest.sub!(/\A(\d+(?:\.\d+)?)(h|hr|hrs|hour|hours|min|mins|minute|minutes|s|sec|secs|second|seconds)/, "")
    matched = true
    n = Regexp.last_match(1).to_f
    unit = Regexp.last_match(2)
    total += if unit.start_with?("h")
               n * 3600
             elsif unit.start_with?("min")
               n * 60
             else
               n
             end
  end
  raise ArgumentError if !matched || !rest.empty?

  total
end

def parse_args(argv)
  opts = {
    modules: [],
    speed: 1.0,
    instant: 0,
    exit_after_modules: nil,
    exit_after_time: nil,
    inhibit: false
  }
  i = 0
  while i < argv.length
    arg = argv[i]
    case arg
    when "-h", "--help"
      puts HELP
      exit 0
    when "-V", "--version"
      puts VERSION
      exit 0
    when "-l", "--list-modules"
      puts "Available modules:"
      MODULES.each { |m| puts "  #{m}" }
      exit 0
    when "-m", "--modules"
      value = argv[i += 1] || usage_error("a value is required for '--modules <MODULES>'")
      unless MODULES.include?(value)
        tip = value.include?(",") ? "a similar value exists: '#{value.split(",").first}'" : "a similar value exists: 'composer'"
        usage_error("invalid value '#{value}' for '--modules <MODULES>'", tip)
      end
      opts[:modules] << value
    when "-s", "--speed-factor"
      value = argv[i += 1] || usage_error("a value is required for '--speed-factor <SPEED_FACTOR>'")
      begin
        opts[:speed] = Float(value)
      rescue ArgumentError
        usage_error("invalid value '#{value}' for '--speed-factor <SPEED_FACTOR>': invalid float literal")
      end
    when "-i", "--instant-print-lines"
      value = argv[i += 1] || usage_error("a value is required for '--instant-print-lines <INSTANT_PRINT_LINES>'")
      begin
        opts[:instant] = Integer(value)
      rescue ArgumentError
        usage_error("invalid value '#{value}' for '--instant-print-lines <INSTANT_PRINT_LINES>': invalid digit found in string")
      end
    when "--exit-after-modules"
      value = argv[i += 1] || usage_error("a value is required for '--exit-after-modules <EXIT_AFTER_MODULES>'")
      begin
        opts[:exit_after_modules] = Integer(value)
      rescue ArgumentError
        usage_error("invalid value '#{value}' for '--exit-after-modules <EXIT_AFTER_MODULES>': invalid digit found in string")
      end
    when "--exit-after-time"
      value = argv[i += 1] || usage_error("a value is required for '--exit-after-time <EXIT_AFTER_TIME>'")
      begin
        opts[:exit_after_time] = parse_duration(value)
      rescue ArgumentError
        usage_error("invalid value '#{value}' for '--exit-after-time <EXIT_AFTER_TIME>'")
      end
    when "--inhibit"
      opts[:inhibit] = true
    when "--print-manpage"
      print_manpage
      exit 0
    when "--print-completions"
      shell = argv[i += 1] || usage_error("a value is required for '--print-completions <shell>'")
      print_completion(shell)
      exit 0
    else
      usage_error("unexpected argument '#{arg}' found")
    end
    i += 1
  end
  opts[:modules] = MODULES if opts[:modules].empty?
  opts
end

def print_manpage
  puts <<~MAN
    .ie \\n(.g .ds Aq \\(aq
    .el .ds Aq '
    .TH genact 1  "genact 1.5.1"
    .SH NAME
    genact \\- A nonsense activity generator
    .SH SYNOPSIS
    \\fBgenact\\fR [OPTIONS]
    .SH DESCRIPTION
    A nonsense activity generator
    .SH OPTIONS
    .TP
    \\fB-l\\fR, \\fB--list-modules\\fR
    List available modules
    .TP
    \\fB-m\\fR, \\fB--modules\\fR \\fI<MODULES>\\fR
    Run only these modules
    .br
    Possible values: #{MODULES.join(", ")}
    .TP
    \\fB-s\\fR, \\fB--speed-factor\\fR \\fI<SPEED_FACTOR>\\fR [default: 1]
    Global speed factor
    .TP
    \\fB-i\\fR, \\fB--instant-print-lines\\fR \\fI<INSTANT_PRINT_LINES>\\fR [default: 0]
    Instantly print this many lines
    .TP
    \\fB--exit-after-time\\fR \\fI<EXIT_AFTER_TIME>\\fR
    Exit after running for this long (format example: 2h10min)
    .TP
    \\fB--exit-after-modules\\fR \\fI<EXIT_AFTER_MODULES>\\fR
    Exit after running this many modules
  MAN
end

def print_completion(shell)
  unless %w[bash elvish fish powershell zsh].include?(shell)
    usage_error("invalid value '#{shell}' for '--print-completions <shell>': [possible values: bash, elvish, fish, powershell, zsh]")
  end
  case shell
  when "bash"
    puts "_genact() { COMPREPLY=( $(compgen -W \"-l -m -s -i -h -V --list-modules --modules --speed-factor --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage --help --version #{MODULES.join(" ")}\" -- \"${COMP_WORDS[COMP_CWORD]}\") ); }"
    puts "complete -F _genact -o bashdefault -o default genact"
  when "fish"
    MODULES.each { |m| puts "complete -c genact -l modules -a #{m}" }
  else
    puts "# completion for genact (#{shell})"
    puts MODULES.join("\n")
  end
end

def delay(opts, index)
  return if index < opts[:instant]

  factor = opts[:speed].positive? ? opts[:speed] : 1.0
  sleep([0.04 / factor, 0.0].max)
end

def rand_hex(n)
  Array.new(n) { rand(16).to_s(16) }.join
end

def path(bits = 3)
  "/" + Array.new(bits) { WORDS.sample }.join("/") + "/" + CRATES.sample.tr("_", "-") + %w[.tar.gz .tar.xz .deb .rpm .png .jpg .html .mp4 .iso].sample
end

def ip
  rand < 0.25 ? Array.new(8) { rand(0x10000).to_s(16) }.join(":") : Array.new(4) { rand(1..245) }.join(".")
end

def line_for(mod, n)
  case mod
  when "cargo"
    action = n < 50 ? "Downloading" : ["Compiling", "Checking", "Building"].sample
    "#{color("1;32", action.rjust(12))} #{CRATES.sample} v#{rand(0..3)}.#{rand(0..50)}.#{rand(0..40)}"
  when "cc", "kernel_compile"
    "clang -c -O#{rand(0..3)} -Wall -Wno-sign-compare -march=x86-64 -pipe -I#{%w[drivers/net arch/x86/kernel fs/ext4 sound/pci security/selinux kernel/sched].sample} -DDEBUG -DMODULE_NAME=#{%w[core net lib mm ipc].sample} -o #{%w[arch/x86/kernel drivers/net/ethernet fs/ext4 kernel/sched mm].sample}/#{FILES.sample.sub(".c", ".o")}"
  when "weblog"
    ua = [
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/42.0 Safari/537.36",
      "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/33.0 Safari/537.36",
      "Opera/9.80 (Macintosh; Intel Mac OS X 10.6.8) Presto/2.9.168 Version/11.52"
    ].sample
    "#{ip} - - [#{Time.now.strftime("%d/%b/%Y:%H:%M:%S %z")}] \"GET #{path(rand(1..4))} HTTP/1.0\" #{[200, 201, 400, 401, 403, 404, 500, 502, 503].sample} #{rand(30_000..5_000_000)} \"-\" \"#{ua}\""
  when "bootlog"
    [
      "ACPI: Preparing to enter system sleep state S3",
      "CPU#{rand(0..15)} is up",
      "DMAR-IR: Enabled IRQ remapping in xapic mode",
      "Memory: #{rand(2_000_000..16_777_216)}K/#{rand(16_777_217..32_000_000)}K available",
      "clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff"
    ].sample
  when "bruteforce"
    " :: #{color(32, rand_hex(rand(0..8)))}#{color(31, rand_hex(64))} ::"
  when "memdump"
    "#{format("0x%08x", n * 16)}  #{Array.new(16) { rand(256).to_s(16).rjust(2, "0") }.join(" ")}  |#{Array.new(16) { rand(32..126).chr }.join}|"
  when "docker_build"
    ["Step #{rand(1..12)}/12 : RUN apt-get update", " ---> #{rand_hex(12)}", "Successfully built #{rand_hex(12)}", "Sending build context to Docker daemon  #{rand(1..900)}.#{rand(0..9)}MB"].sample
  when "docker_image_rm"
    "Untagged: #{%w[ubuntu alpine postgres redis nginx rust node].sample}:#{%w[latest 22.04 slim 1.0 dev].sample}"
  when "download"
    "Downloading #{path(1).delete_prefix("/")} #{rand(1..99)}% [#{("=" * rand(1..25)).ljust(25)}] #{rand(20..900)} KiB/s"
  when "terraform"
    "#{%w[aws_instance.web module.vpc.aws_subnet.public random_id.server].sample}: #{%w[Refreshing Creating Modifying Destroying].sample}... [id=#{rand_hex(8)}]"
  when "ansible"
    "#{%w[TASK PLAY RUNNING HANDLER].sample} [#{WORDS.sample} #{WORDS.sample}] #{color(32, "ok")}: [#{%w[web db cache worker].sample}#{rand(1..9)}]"
  when "composer"
    "  - #{%w[Installing Updating Downloading].sample} #{WORDS.sample}/#{WORDS.sample} (#{rand(0..5)}.#{rand(0..20)}.#{rand(0..9)})"
  when "cryptomining"
    "[#{Time.now.strftime("%H:%M:%S")}] accepted: #{rand(1..999)}/#{rand(1000..9999)} (diff #{rand(1..128)}), #{rand(10..300)}.#{rand(0..9)} MH/s"
  when "julia"
    "#{color(32, "Precompiling")} #{CRATES.sample.capitalize} [#{rand_hex(8)}]"
  when "mkinitcpio"
    "==> #{%w[Starting Building Generating Adding].sample}: #{%w[base udev autodetect modconf block filesystems keyboard fsck].sample}"
  when "rkhunter"
    "[#{color(32, " OK ")}] Checking #{%w[/usr/bin/ssh /usr/bin/sudo /etc/passwd hidden files rootkits network interfaces].sample}"
  when "simcity"
    "#{%w[Residential Commercial Industrial Police Fire Transit Power Water].sample} demand #{rand(-100..100)}; population #{rand(1000..9_000_000)}"
  when "uv"
    "#{%w[Resolved Prepared Installed Downloaded].sample} #{rand(1..200)} packages in #{rand(10..900)}ms"
  when "wpt"
    "#{%w[PASS FAIL TIMEOUT CRASH].sample} #{%w[html css dom webgpu fetch xhr encoding].sample}/#{WORDS.sample}-#{WORDS.sample}.html"
  when "botnet"
    "[#{ip}] #{%w[CONNECT SYN_SENT AUTH_OK PAYLOAD_SENT HEARTBEAT RETRY].sample} #{rand_hex(8)}"
  else
    "#{mod}: #{WORDS.sample} #{WORDS.sample} #{rand_hex(12)}"
  end
end

def run_module(mod, opts, started)
  limit = [opts[:instant], 60].max
  limit = 200 if opts[:exit_after_modules].nil? && opts[:exit_after_time].nil?
  n = 0
  loop do
    break if opts[:exit_after_time] && Time.now - started >= opts[:exit_after_time]
    break if n >= limit && opts[:exit_after_modules]

    puts_flush(line_for(mod, n))
    delay(opts, n)
    n += 1
    break if n >= limit && opts[:exit_after_time]
  end
end

opts = parse_args(ARGV)
started = Time.now
completed = 0

Signal.trap("INT") { exit 130 }

loop do
  opts[:modules].shuffle.each do |mod|
    run_module(mod, opts, started)
    completed += 1
    exit 0 if opts[:exit_after_modules] && completed >= opts[:exit_after_modules]
    exit 0 if opts[:exit_after_time] && Time.now - started >= opts[:exit_after_time]
  end
  break if opts[:exit_after_modules] || opts[:exit_after_time]
end
