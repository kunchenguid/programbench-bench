#!/usr/bin/env ruby
# frozen_string_literal: true

require 'yaml'

VERSION = '0.21.1'
SCHEMA = '2024-11-02'

HELP_LONG = <<~TXT
  Summarize disk usage of the set of files, recursively for directories.

  Copyright: Apache-2.0 © 2021 Hoàng Văn Khải <https://github.com/KSXGitHub/>
  Sponsor: https://github.com/sponsors/KSXGitHub

  Usage: executable [OPTIONS] [FILES]...

  Arguments:
    [FILES]...
            List of files and/or directories

  Options:
        --json-input
            Read JSON data from stdin

        --json-output
            Print JSON data instead of an ASCII chart

    -b, --bytes-format <BYTES_FORMAT>
            How to display the numbers of bytes

            Possible values:
            - plain:  Display plain number of bytes without units
            - metric: Use metric scale, i.e. 1K = 1000B, 1M = 1000K, and so on
            - binary: Use binary scale, i.e. 1K = 1024B, 1M = 1024K, and so on
            
            [default: metric]

    -H, --deduplicate-hardlinks
            Detect and subtract the sizes of hardlinks from their parent directory totals
            
            [aliases: --detect-links, --dedupe-links]

        --top-down
            Print the tree top-down instead of bottom-up

        --align-right
            Set the root of the bars to the right

    -q, --quantity <QUANTITY>
            Aspect of the files/directories to be measured

            Possible values:
            - apparent-size: Measure apparent sizes
            - block-size:    Measure block sizes (block-count * 512B)
            - block-count:   Count numbers of blocks
            
            [default: block-size]

    -d, --max-depth <MAX_DEPTH>
            Maximum depth to display the data. Could be either "inf" or a positive integer
            
            [default: 10]
            [aliases: --depth]

    -w, --total-width <TOTAL_WIDTH>
            Width of the visualization
            
            [aliases: --width]

        --column-width <TREE_WIDTH> <BAR_WIDTH>
            Maximum widths of the tree column and width of the bar column

    -m, --min-ratio <MIN_RATIO>
            Minimal size proportion required to appear
            
            [default: 0.01]

        --no-sort
            Do not sort the branches in the tree

    -s, --silent-errors
            Prevent filesystem error messages from appearing in stderr
            
            [aliases: --no-errors]

    -p, --progress
            Report progress being made at the expense of performance

        --threads <THREADS>
            Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer
            
            [default: auto]

        --omit-json-shared-details
            Do not output `.shared.details` in the JSON output

        --omit-json-shared-summary
            Do not output `.shared.summary` in the JSON output

    -h, --help
            Print help (see a summary with '-h')

    -V, --version
            Print version

  Examples:
      Show disk usage chart of current working directory
      $ pdu

      Show disk usage chart of a single file or directory
      $ pdu path/to/file/or/directory

      Compare disk usages of multiple files and/or directories
      $ pdu file.txt dir/

      Show chart in apparent sizes instead of block sizes
      $ pdu --quantity=apparent-size

      Detect and subtract the sizes of hardlinks from their parent nodes
      $ pdu --deduplicate-hardlinks

      Show sizes in plain numbers instead of metric units
      $ pdu --bytes-format=plain

      Show sizes in base 2¹⁰ units (binary) instead of base 10³ units (metric)
      $ pdu --bytes-format=binary

      Show disk usage chart of all entries regardless of size
      $ pdu --min-ratio=0

      Only show disk usage chart of entries whose size is at least 5% of total
      $ pdu --min-ratio=0.05

      Show disk usage data as JSON instead of chart
      $ pdu --min-ratio=0 --max-depth=inf --json-output | jq

      Visualize existing JSON representation of disk usage data
      $ pdu --json-input < disk-usage.json
TXT

HELP_SHORT = <<~TXT
  Summarize disk usage of the set of files, recursively for directories.

  Usage: executable [OPTIONS] [FILES]...

  Arguments:
    [FILES]...  List of files and/or directories

  Options:
        --json-input
            Read JSON data from stdin
        --json-output
            Print JSON data instead of an ASCII chart
    -b, --bytes-format <BYTES_FORMAT>
            How to display the numbers of bytes [default: metric] [possible values: plain, metric, binary]
    -H, --deduplicate-hardlinks
            Detect and subtract the sizes of hardlinks from their parent directory totals [aliases: --detect-links, --dedupe-links]
        --top-down
            Print the tree top-down instead of bottom-up
        --align-right
            Set the root of the bars to the right
    -q, --quantity <QUANTITY>
            Aspect of the files/directories to be measured [default: block-size] [possible values: apparent-size, block-size, block-count]
    -d, --max-depth <MAX_DEPTH>
            Maximum depth to display the data. Could be either "inf" or a positive integer [default: 10] [aliases: --depth]
    -w, --total-width <TOTAL_WIDTH>
            Width of the visualization [aliases: --width]
        --column-width <TREE_WIDTH> <BAR_WIDTH>
            Maximum widths of the tree column and width of the bar column
    -m, --min-ratio <MIN_RATIO>
            Minimal size proportion required to appear [default: 0.01]
        --no-sort
            Do not sort the branches in the tree
    -s, --silent-errors
            Prevent filesystem error messages from appearing in stderr [aliases: --no-errors]
    -p, --progress
            Report progress being made at the expense of performance
        --threads <THREADS>
            Set the maximum number of threads to spawn. Could be either "auto", "max", or a positive integer [default: auto]
        --omit-json-shared-details
            Do not output `.shared.details` in the JSON output
        --omit-json-shared-summary
            Do not output `.shared.summary` in the JSON output
    -h, --help
            Print help (see more with '--help')
    -V, --version
            Print version

  Examples:
      $ pdu
      $ pdu path/to/file/or/directory
      $ pdu file.txt dir/
      $ pdu --quantity=apparent-size
      $ pdu --deduplicate-hardlinks
      $ pdu --bytes-format=plain
      $ pdu --bytes-format=binary
      $ pdu --min-ratio=0
      $ pdu --min-ratio=0.05
      $ pdu --min-ratio=0 --max-depth=inf --json-output | jq
      $ pdu --json-input < disk-usage.json
TXT

class Node
  attr_accessor :name, :size, :children
  def initialize(name, size = 0, children = [])
    @name = name
    @size = size
    @children = children
  end

  def to_h
    { 'name' => @name, 'size' => @size, 'children' => @children.map(&:to_h) }
  end

  def self.from_h(h)
    new(h['name'].to_s, h['size'].to_i, Array(h['children']).map { |c| from_h(c) })
  end
end

class App
  def initialize(argv)
    @args = argv.dup
    @json_input = false
    @json_output = false
    @bytes_format = 'metric'
    @quantity = 'block-size'
    @dedupe = false
    @top_down = false
    @align_right = false
    @max_depth = 10
    @min_ratio = 0.01
    @no_sort = false
    @silent = false
    @omit_details = false
    @omit_summary = false
    @total_width = nil
    @tree_width = nil
    @bar_width = nil
    @files = []
    @hardlinks = Hash.new { |h, k| h[k] = [] }
  end

  def run
    parse!
    if @json_input
      input = YAML.safe_load($stdin.read, permitted_classes: [], aliases: false)
      @unit = input['unit'] || 'bytes'
      root = Node.from_h(input['tree'] || input)
      filter!(root, root.size, 1)
      @json_output ? print(json_generate(output_hash(root, input['shared']))) : print_chart(root)
      return 0
    end

    @unit = @quantity == 'block-count' ? 'blocks' : 'bytes'
    paths = @files.empty? ? ['.'] : @files
    nodes = paths.map { |p| scan_path(p, display_name(p)) }
    root = nodes.length == 1 ? nodes[0] : Node.new('(total)', nodes.sum(&:size), nodes)
    shared = build_shared
    if @dedupe && shared && shared['summary']
      root.size = [root.size - shared['summary']['shared_size'].to_i, 0].max
    end
    sort_tree!(root) unless @no_sort
    filter!(root, root.size, 1)
    if @json_output
      print json_generate(output_hash(root, shared))
    else
      print_chart(root)
    end
    0
  rescue Psych::Exception => e
    warn "[error] parse JSON from stdin: #{e.message}"
    1
  rescue OptionError => e
    warn e.message
    2
  end

  private

  class OptionError < StandardError; end

  def json_generate(value)
    case value
    when Hash
      '{' + value.map { |k, v| json_generate(k.to_s) + ':' + json_generate(v) }.join(',') + '}'
    when Array
      '[' + value.map { |v| json_generate(v) }.join(',') + ']'
    when String
      '"' + value.gsub(/["\\\b\f\n\r\t]/) { |c|
        { '"' => '\\"', '\\' => '\\\\', "\b" => '\\b', "\f" => '\\f', "\n" => '\\n', "\r" => '\\r', "\t" => '\\t' }[c]
      } + '"'
    when Integer
      value.to_s
    when Float
      value.finite? ? value.to_s : 'null'
    when true then 'true'
    when false then 'false'
    when nil then 'null'
    else
      json_generate(value.to_s)
    end
  end

  def parse!
    until @args.empty?
      a = @args.shift
      case a
      when '--json-input' then @json_input = true
      when '--json-output' then @json_output = true
      when '-H', '--deduplicate-hardlinks', '--detect-links', '--dedupe-links' then @dedupe = true
      when '--top-down' then @top_down = true
      when '--align-right' then @align_right = true
      when '--no-sort' then @no_sort = true
      when '-s', '--silent-errors', '--no-errors' then @silent = true
      when '-p', '--progress' then nil
      when '--omit-json-shared-details' then @omit_details = true
      when '--omit-json-shared-summary' then @omit_summary = true
      when '-h'
        print HELP_SHORT
        exit 0
      when '--help'
        print HELP_LONG
        exit 0
      when '-V', '--version'
        puts "pdu #{VERSION}"
        exit 0
      when '-b', '--bytes-format'
        @bytes_format = need_value(a)
        validate_enum!(a, @bytes_format, %w[plain metric binary])
      when /^--bytes-format=(.*)$/
        @bytes_format = Regexp.last_match(1)
        validate_enum!('--bytes-format', @bytes_format, %w[plain metric binary])
      when '-q', '--quantity'
        @quantity = need_value(a)
        validate_enum!(a, @quantity, %w[apparent-size block-size block-count])
      when /^--quantity=(.*)$/
        @quantity = Regexp.last_match(1)
        validate_enum!('--quantity', @quantity, %w[apparent-size block-size block-count])
      when '-d', '--max-depth', '--depth'
        @max_depth = parse_positive_or_inf(need_value(a), a)
      when /^--(?:max-depth|depth)=(.*)$/
        @max_depth = parse_positive_or_inf(Regexp.last_match(1), '--max-depth')
      when '-w', '--total-width', '--width'
        @total_width = need_value(a).to_i
      when /^--(?:total-width|width)=(.*)$/
        @total_width = Regexp.last_match(1).to_i
      when '--column-width'
        @tree_width = need_value(a).to_i
        @bar_width = need_value(a).to_i
      when /^--column-width=(.*)$/
        @tree_width = Regexp.last_match(1).to_i
        @bar_width = need_value(a).to_i
      when '-m', '--min-ratio'
        @min_ratio = need_value(a).to_f
      when /^--min-ratio=(.*)$/
        @min_ratio = Regexp.last_match(1).to_f
      when '--threads'
        parse_threads(need_value(a))
      when /^--threads=(.*)$/
        parse_threads(Regexp.last_match(1))
      when '--'
        @files.concat(@args)
        @args.clear
      else
        if a.start_with?('-')
          raise OptionError, "error: unexpected argument '#{a}' found\n\nUsage: executable [OPTIONS] [FILES]...\n\nFor more information, try '--help'."
        end
        @files << a
      end
    end
    raise OptionError, 'error: the argument --json-input cannot be used with --quantity or --deduplicate-hardlinks' if @json_input && @dedupe
  end

  def need_value(opt)
    v = @args.shift
    raise OptionError, "error: a value is required for '#{opt}' but none was supplied" if v.nil?
    v
  end

  def validate_enum!(opt, value, choices)
    return if choices.include?(value)
    long = opt.start_with?('--') ? opt.split('=').first : opt
    argname = long.include?('bytes') || opt == '-b' ? 'BYTES_FORMAT' : 'QUANTITY'
    raise OptionError, "error: invalid value '#{value}' for '#{long} <#{argname}>'\n  [possible values: #{choices.join(', ')}]\n\nFor more information, try '--help'."
  end

  def parse_positive_or_inf(v, opt)
    return Float::INFINITY if v == 'inf'
    n = Integer(v)
    raise ArgumentError if n <= 0
    n
  rescue ArgumentError
    msg = v == '0' ? 'number would be zero for non-zero type' : 'invalid digit found in string'
    raise OptionError, "error: invalid value '#{v}' for '#{opt} <MAX_DEPTH>': Value is neither \"inf\" nor a positive integer: #{msg}\n\nFor more information, try '--help'."
  end

  def parse_threads(v)
    return if %w[auto max].include?(v)
    n = Integer(v)
    raise ArgumentError if n <= 0
  rescue ArgumentError
    msg = v == '0' ? 'number would be zero for non-zero type' : 'invalid digit found in string'
    raise OptionError, "error: invalid value '#{v}' for '--threads <THREADS>': Value is neither \"auto\", \"max\", nor a number: #{msg}\n\nFor more information, try '--help'."
  end

  def display_name(path)
    @files.length > 1 ? path : (path.sub(%r{/+$}, '').split('/').last || path)
  end

  def unit_size(st)
    case @quantity
    when 'apparent-size' then st.size
    when 'block-count' then st.blocks || 0
    else (st.blocks || 0) * 512
    end
  end

  def scan_path(path, name)
    begin
      st = File.lstat(path)
    rescue SystemCallError => e
      warn "[error] symlink_metadata #{path.inspect}: #{e.message}" unless @silent
      return Node.new(name, 0, [])
    end
    self_size = unit_size(st)
    track_hardlink(path, st, self_size) if @dedupe && st.file? && st.nlink && st.nlink > 1
    children = []
    if st.directory? && !st.symlink?
      begin
        Dir.foreach(path) do |entry|
          next if entry == '.' || entry == '..'
          child_path = File.join(path, entry)
          children << scan_path(child_path, entry)
        end
      rescue SystemCallError => e
        warn "[error] read_dir #{path.inspect}: #{e.message}" unless @silent
      end
    end
    Node.new(name, self_size + children.sum(&:size), children)
  end

  def track_hardlink(path, st, size)
    key = [st.dev, st.ino]
    @hardlinks[key] << { 'ino' => st.ino, 'size' => size, 'path' => path }
  end

  def build_shared
    groups = @hardlinks.values.select { |g| g.length > 1 }
    return nil if groups.empty?
    details = groups.map do |g|
      { 'ino' => g[0]['ino'], 'size' => g[0]['size'], 'links' => g.length, 'paths' => g.map { |x| x['path'] }.sort }
    end
    shared_size = details.sum { |d| d['size'] * (d['links'] - 1) }
    summary = {
      'inodes' => details.length,
      'exclusive_inodes' => details.length,
      'all_links' => details.sum { |d| d['links'] },
      'detected_links' => details.sum { |d| d['links'] },
      'exclusive_links' => details.sum { |d| d['links'] },
      'shared_size' => shared_size,
      'exclusive_shared_size' => shared_size
    }
    h = {}
    h['details'] = details unless @omit_details
    h['summary'] = summary unless @omit_summary
    h
  end

  def sort_tree!(node)
    node.children.each { |c| sort_tree!(c) }
    node.children.sort_by! { |c| [-c.size, c.name] }
  end

  def filter!(node, total, depth)
    if depth >= @max_depth
      node.children = []
      return
    end
    node.children = node.children.select { |c| total.zero? || (c.size.to_f / total) >= @min_ratio }
    node.children.each { |c| filter!(c, total, depth + 1) }
  end

  def output_hash(root, shared = nil)
    h = { 'schema-version' => SCHEMA, 'pdu' => VERSION, 'unit' => @unit || 'bytes', 'tree' => root.to_h }
    h['shared'] = shared if shared && !shared.empty?
    h
  end

  def format_size(n)
    return n.to_i.to_s if @bytes_format == 'plain' || @unit == 'blocks'
    base = @bytes_format == 'binary' ? 1024.0 : 1000.0
    units = ['', 'K', 'M', 'G', 'T', 'P', 'E']
    v = n.to_f
    idx = 0
    while v.abs >= base && idx < units.length - 1
      v /= base
      idx += 1
    end
    idx.zero? ? n.to_i.to_s : format('%.1f%s', v, units[idx])
  end

  def flatten_bottom(node, prefix = '', last = true, root = true, rows = [])
    kids = node.children
    rev = kids.reverse
    rev.each_with_index do |ch, i|
      orig_last = kids.index(ch) == kids.length - 1
      flatten_bottom(ch, prefix + (root ? '' : (last ? '  ' : '│ ')), orig_last, false, rows)
    end
    branch = root ? '┌─┴' : (kids.empty? ? (last ? '┌──' : '├──') : (last ? '┌─┴' : '├─┴'))
    rows << [node, prefix + branch]
    rows
  end

  def flatten_top(node, prefix = '', last = true, root = true, rows = [])
    branch = root ? '└─┬' : (node.children.empty? ? (last ? '└──' : '├──') : (last ? '└─┬' : '├─┬'))
    rows << [node, prefix + branch]
    node.children.each_with_index do |ch, i|
      flatten_top(ch, prefix + (root ? '' : (last ? '  ' : '│ ')), i == node.children.length - 1, false, rows)
    end
    rows
  end

  def print_chart(root)
    rows = @top_down ? flatten_top(root) : flatten_bottom(root)
    size_w = rows.map { |n, _| format_size(n.size).length }.max || 1
    tree_w = @tree_width || rows.map { |n, br| (br + n.name).length }.max || 1
    if @bar_width
      bar_w = @bar_width
    else
      total_w = @total_width || 150
      bar_w = [total_w - size_w - tree_w - 10, 1].max
    end
    total = root.size.to_f
    rows.each do |node, branch|
      s = format_size(node.size).rjust(size_w)
      tree = (branch + node.name).ljust(tree_w)
      ratio = total <= 0 ? 0.0 : node.size / total
      fill = (ratio * bar_w).round
      fill = bar_w if node.equal?(root) && node.size.positive?
      bar = '█' * fill
      bar = bar.rjust(bar_w) if @align_right
      bar = bar.ljust(bar_w)
      pct = total <= 0 ? 0 : (ratio * 100).round
      puts "#{s} #{tree}│#{bar}│#{format('%3d%%', pct)}"
    end
  end
end

exit App.new(ARGV).run
