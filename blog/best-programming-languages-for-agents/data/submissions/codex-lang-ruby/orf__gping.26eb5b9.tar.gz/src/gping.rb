#!/usr/bin/env ruby
# frozen_string_literal: true

require 'open3'
require 'ipaddr'
require 'resolv'
require 'shellwords'
require 'socket'

HELP = <<~TEXT
  Ping, but with a graph.

  Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...

  Arguments:
    [HOSTS_OR_COMMANDS]...  Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1

  Options:
        --cmd
            Graph the execution time for a list of commands rather than pinging hosts
    -n, --watch-interval <WATCH_INTERVAL>
            Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5
    -b, --buffer <BUFFER>
            Determines the number of seconds to display in the graph [default: 30]
    -4
            Resolve ping targets to IPv4 address
    -6
            Resolve ping targets to IPv6 address
    -i, --interface <INTERFACE>
            Interface to use when pinging
    -s, --simple-graphics
            
        --vertical-margin <VERTICAL_MARGIN>
            Vertical margin around the graph (top and bottom) [default: 1]
        --horizontal-margin <HORIZONTAL_MARGIN>
            Horizontal margin around the graph (left and right) [default: 0]
    -c, --color <color>
            Assign color to a graph entry.
            
            This option can be defined more than once as a comma separated string, and the
            order which the colors are provided will be matched against the hosts or
            commands passed to gping.
            
            Hexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the
            following color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',
            'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',
            'light-blue', 'light-magenta', 'light-cyan', and 'white'
        --clear
            Clear the graph from the terminal after closing the program
        --ping-args [<PING_ARGS>...]
            Extra arguments to pass to `ping`. These are platform dependent
    -h, --help
            Print help
    -V, --version
            Print version
TEXT

LONG_VERSION = <<~TEXT
  gping 1.20.1
  commit_hash: d67d2aeb
  build_time: 2026-04-17 19:59:37 +00:00
  build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu
TEXT

COLOR_NAMES = %w[
  black red green yellow blue magenta cyan gray grey dark-gray dark-grey
  light-red light-green light-yellow light-blue light-magenta light-cyan white
].freeze

AWS_REGIONS = %w[
  af-south-1 ap-east-1 ap-south-1 ap-south-2 ap-southeast-1 ap-southeast-2
  ap-southeast-3 ap-southeast-4 ap-northeast-1 ap-northeast-2 ap-northeast-3
  ca-central-1 ca-west-1 eu-central-1 eu-central-2 eu-west-1 eu-west-2 eu-west-3
  eu-south-1 eu-south-2 eu-north-1 il-central-1 me-central-1 me-south-1
  sa-east-1 us-east-1 us-east-2 us-west-1 us-west-2
].freeze

class CliError < StandardError
  attr_reader :status

  def initialize(message, status = 2)
    super(message)
    @status = status
  end
end

def usage_for(opts)
  bits = []
  bits << '--cmd' if opts[:cmd]
  bits << '-4' if opts[:ipv4]
  bits << '-6' if opts[:ipv6]
  bits.empty? ? 'executable [OPTIONS] [HOSTS_OR_COMMANDS]...' : "executable #{bits.join(' ')} [HOSTS_OR_COMMANDS]..."
end

def clap_error(message, opts = {})
  <<~TEXT
    error: #{message}

    Usage: #{usage_for(opts)}#{opts[:requires_host] ? '' : ''}

    For more information, try '--help'.
  TEXT
end

def unexpected_arg(arg, opts = {})
  tip = "\n  tip: to pass '#{arg}' as a value, use '-- #{arg}'\n"
  "error: unexpected argument '#{arg}' found\n#{tip}\nUsage: #{usage_for(opts)}\n\nFor more information, try '--help'.\n"
end

def value_required(name, metavar)
  "error: a value is required for '#{name} <#{metavar}>' but none was supplied\n\nFor more information, try '--help'.\n"
end

def invalid_value(value, name, metavar, why)
  "error: invalid value '#{value}' for '#{name} <#{metavar}>': #{why}\n\nFor more information, try '--help'.\n"
end

def parse_uint(value, name, metavar)
  raise CliError, value_required(name, metavar) if value.nil?
  raise CliError, unexpected_arg(value) if value.start_with?('-')
  unless value.match?(/\A\d+\z/)
    raise CliError, invalid_value(value, name, metavar, 'invalid digit found in string')
  end
  value.to_i
end

def parse_float(value, name, metavar)
  raise CliError, value_required(name, metavar) if value.nil?
  raise CliError, unexpected_arg(value) if value.start_with?('-')
  Float(value)
rescue ArgumentError
  raise CliError, invalid_value(value, name, metavar, 'invalid float literal')
end

def validate_colors(raw_colors, host_count)
  raw_colors.flat_map { |c| c.split(',') }.first(host_count).each do |color|
    next if COLOR_NAMES.include?(color)
    next if color.match?(/\A#[0-9a-fA-F]{6}\z/)

    raise CliError.new("Error: Invalid color code: `#{color}`\n\nCaused by:\n    Failed to parse Colors\n", 1)
  end
end

def parse_args(argv)
  opts = {
    cmd: false, ipv4: false, ipv6: false, colors: [], ping_args: [],
    buffer: 30, vertical_margin: 1, horizontal_margin: 0, watch_interval: nil
  }
  hosts = []
  i = 0
  positional = false
  while i < argv.length
    arg = argv[i]
    if positional
      hosts << arg
    elsif arg == '--'
      positional = true
    elsif arg == '--help' || arg == '-h'
      puts HELP
      exit 0
    elsif arg == '-V'
      puts 'gping 1.20.1'
      exit 0
    elsif arg == '--version'
      print LONG_VERSION
      exit 0
    elsif arg == '--cmd'
      opts[:cmd] = true
    elsif arg == '-4'
      raise CliError, "error: the argument '-6' cannot be used with '-4'\n\nUsage: executable -6 <HOSTS_OR_COMMANDS>...\n\nFor more information, try '--help'.\n" if opts[:ipv6]
      opts[:ipv4] = true
    elsif arg == '-6'
      raise CliError, "error: the argument '-4' cannot be used with '-6'\n\nUsage: executable -4 <HOSTS_OR_COMMANDS>...\n\nFor more information, try '--help'.\n" if opts[:ipv4]
      opts[:ipv6] = true
    elsif arg.match?(/\A-[46]{2,}\z/)
      chars = arg[1..].chars
      seen = chars.first
      other = chars.find { |c| c != seen }
      if other
        raise CliError, "error: the argument '-#{seen}' cannot be used with '-#{other}'\n\nUsage: executable -#{seen} <HOSTS_OR_COMMANDS>...\n\nFor more information, try '--help'.\n"
      end
    elsif arg == '-s' || arg == '--simple-graphics' || arg == '--clear'
      # accepted flags
    elsif arg == '-b' || arg == '--buffer'
      i += 1
      opts[:buffer] = parse_uint(argv[i], '--buffer', 'BUFFER')
    elsif arg.start_with?('--buffer=')
      opts[:buffer] = parse_uint(arg.split('=', 2)[1], '--buffer', 'BUFFER')
    elsif arg == '-n' || arg == '--watch-interval'
      i += 1
      opts[:watch_interval] = parse_float(argv[i], '--watch-interval', 'WATCH_INTERVAL')
    elsif arg.start_with?('--watch-interval=')
      opts[:watch_interval] = parse_float(arg.split('=', 2)[1], '--watch-interval', 'WATCH_INTERVAL')
    elsif arg == '-i' || arg == '--interface'
      i += 1
      val = argv[i]
      raise CliError, value_required('--interface', 'INTERFACE') if val.nil?
      raise CliError, unexpected_arg(val, opts) if val.start_with?('-')
      opts[:interface] = val
    elsif arg.start_with?('--interface=')
      opts[:interface] = arg.split('=', 2)[1]
    elsif arg == '-c' || arg == '--color'
      i += 1
      val = argv[i]
      raise CliError, value_required('--color', 'color') if val.nil?
      raise CliError, unexpected_arg(val, opts) if val.start_with?('-')
      opts[:colors] << val
    elsif arg.start_with?('--color=')
      opts[:colors] << arg.split('=', 2)[1]
    elsif arg == '--vertical-margin'
      i += 1
      opts[:vertical_margin] = parse_uint(argv[i], '--vertical-margin', 'VERTICAL_MARGIN')
    elsif arg.start_with?('--vertical-margin=')
      opts[:vertical_margin] = parse_uint(arg.split('=', 2)[1], '--vertical-margin', 'VERTICAL_MARGIN')
    elsif arg == '--horizontal-margin'
      i += 1
      opts[:horizontal_margin] = parse_uint(argv[i], '--horizontal-margin', 'HORIZONTAL_MARGIN')
    elsif arg.start_with?('--horizontal-margin=')
      opts[:horizontal_margin] = parse_uint(arg.split('=', 2)[1], '--horizontal-margin', 'HORIZONTAL_MARGIN')
    elsif arg == '--ping-args'
      opts[:ping_args] = argv[(i + 1)..] || []
      i = argv.length
    elsif arg.start_with?('--ping-args=')
      opts[:ping_args] << arg.split('=', 2)[1]
    elsif arg.start_with?('-')
      raise CliError, unexpected_arg(arg, opts)
    else
      hosts << arg
    end
    i += 1
  end
  [opts, hosts]
end

def expand_cloud(host)
  return host unless host.start_with?('aws:')
  region = host.split(':', 2)[1]
  return "ec2.#{region}.amazonaws.com" if AWS_REGIONS.include?(region)

  host
end

def ip_literal?(host)
  IPAddr.new(host)
  true
rescue StandardError
  false
end

def resolve_host(host)
  expanded = expand_cloud(host)
  return expanded if ip_literal?(expanded)

  begin
    Socket.getaddrinfo(expanded, nil)
  rescue SocketError => e
    raise CliError.new("Error: Resolving #{expanded}\n\nCaused by:\n    failed to lookup address information: #{e.message.sub(/\Agetaddrinfo: /, '')}\n", 1)
  end
  expanded
end

def ping_available?
  _out, _err, status = Open3.capture3('sh', '-c', 'command -v ping >/dev/null 2>&1')
  status.success?
end

def run_minimal_cmd_mode(commands, interval)
  if !STDIN.tty? || !STDOUT.tty?
    raise CliError.new("Error: No such device or address (os error 6)\n", 1)
  end

  loop do
    system('clear')
    commands.each do |cmd|
      started = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      system(cmd)
      elapsed = ((Process.clock_gettime(Process::CLOCK_MONOTONIC) - started) * 1000).round(1)
      puts "#{cmd}: #{elapsed} ms"
    end
    sleep(interval || 0.5)
  end
end

begin
  options, targets = parse_args(ARGV)
  if targets.empty?
    warn 'Error: At least one host or command must be given (i.e gping google.com). Use --help for a full list of arguments.'
    exit 1
  end

  validate_colors(options[:colors], targets.length)

  if options[:cmd]
    run_minimal_cmd_mode(targets, options[:watch_interval])
  else
    targets.each { |target| resolve_host(target) }
    unless ping_available?
      warn 'Error: Could not detect ping. Stderr: []'
      warn 'Stdout: []'
      exit 1
    end
    interval = options[:watch_interval] || 0.2
    loop do
      targets.each { |target| system('ping', '-c', '1', target) }
      sleep(interval)
    end
  end
rescue CliError => e
  $stderr.print e.message
  exit e.status
rescue Interrupt
  exit 0
end
