#!/usr/bin/env ruby
# frozen_string_literal: true

require 'rexml/document'
require 'rexml/xpath'
require 'optparse'
require 'cgi'

VERSION = 'xq version 1.4.0'

HELP = <<~HELP.chomp
  Command-line XML and HTML beautifier and content extractor

  Usage:
    xq [flags]

  Flags:
    -a, --attr string      Extract an attribute value instead of node content for provided CSS query
    -c, --color            Force colorful output
        --compact          Compact JSON output (no indentation)
    -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)
    -e, --extract string   Extract a single node from XML
    -h, --help             Print this help message
    -m, --html             Use HTML formatter
    -i, --in-place         Format file in place
        --indent int       Use the given number of spaces for indentation (default 2)
    -j, --json             Output the result as JSON
        --no-color         Disable colorful output
    -n, --node             Return the node content instead of text
    -q, --query string     Extract the node(s) using CSS selector
        --tab              Use tabs for indentation
    -v, --version          Print version information
    -x, --xpath string     Extract the node(s) from XML
HELP

VOID_TAGS = %w[area base br col embed hr img input link meta param source track wbr].freeze

def cobra_error(message)
  warn "Error: #{message}"
  exit 1
end

def parse_args(argv)
  opts = {
    indent: 2, tab: false, color: false, no_color: false, html: false,
    in_place: false, json: false, node: false, compact: false, depth: -1
  }
  i = 0
  files = []
  while i < argv.length
    arg = argv[i]
    case arg
    when '-h', '--help'
      puts HELP
      exit 0
    when '-v', '--version'
      puts VERSION
      exit 0
    when '-c', '--color' then opts[:color] = true
    when '--no-color' then opts[:no_color] = true
    when '--tab' then opts[:tab] = true
    when '-m', '--html' then opts[:html] = true
    when '-i', '--in-place' then opts[:in_place] = true
    when '-j', '--json' then opts[:json] = true
    when '-n', '--node' then opts[:node] = true
    when '--compact' then opts[:compact] = true
    when '--indent', '-d', '--depth', '-x', '--xpath', '-e', '--extract', '-q', '--query', '-a', '--attr'
      cobra_error("flag needs an argument: '#{arg.sub(/^-+/, '')}' in #{arg}") if i + 1 >= argv.length
      val = argv[i + 1]
      case arg
      when '--indent'
        begin
          opts[:indent] = Integer(val)
        rescue ArgumentError
          cobra_error(%(invalid argument "#{val}" for "--indent" flag: strconv.ParseInt: parsing "#{val}": invalid syntax))
        end
      when '-d', '--depth'
        begin
          opts[:depth] = Integer(val)
        rescue ArgumentError
          cobra_error(%(invalid argument "#{val}" for "--depth" flag: strconv.ParseInt: parsing "#{val}": invalid syntax))
        end
      when '-x', '--xpath' then opts[:xpath] = val
      when '-e', '--extract' then opts[:extract] = val
      when '-q', '--query' then opts[:query] = val
      when '-a', '--attr' then opts[:attr] = val
      end
      i += 1
    else
      if arg.start_with?('-')
        cobra_error("unknown flag: #{arg}")
      else
        files << arg
      end
    end
    i += 1
  end
  [opts, files]
end

def read_file_or_die(file)
  File.read(file)
rescue Errno::ENOENT
  cobra_error("open #{file}: no such file or directory")
end

def read_input(files, in_place)
  if in_place && files.length != 1
    cobra_error('in-place formatting requires a file path (and only one file path)')
  end
  if files.empty?
    STDIN.read
  else
    files.map { |file| read_file_or_die(file) }.join
  end
end

def html_preprocess(input)
  input.gsub(/<\s*(#{VOID_TAGS.join('|')})(\b[^<>]*?)(?<!\/)>/i, '<\1\2/>')
end

def parse_doc(input, html: false)
  text = html ? html_preprocess(input) : input
  REXML::Document.new(text, ignore_whitespace_nodes: :all)
rescue REXML::ParseException => e
  cobra_error(e.message.lines.first.to_s.strip)
end

def step(opts, level)
  opts[:tab] ? "\t" * level : ' ' * (opts[:indent] * level)
end

def attr_string(element)
  element.attributes.map { |k, v| %( #{k}="#{CGI.escapeHTML(v)}") }.join
end

def text_value(node)
  if node.is_a?(REXML::Attribute)
    node.value.to_s.strip
  elsif node.respond_to?(:texts)
    node.texts.map { |t| t.value.to_s.strip }.reject(&:empty?).join("\n")
  else
    node.to_s.strip
  end
end

def element_text_deep(element)
  chunks = []
  element.texts.each { |node| chunks << node.value }
  element.each_recursive do |node|
    node.texts.each { |text| chunks << text.value } if node.is_a?(REXML::Element)
  end
  chunks.join(' ').split(/\s+/).reject(&:empty?).join(' ')
end

def format_node(node, opts, level = 0)
  case node
  when REXML::XMLDecl
    %(<?xml version="#{node.version}"?>)
  when REXML::Comment
    "#{step(opts, level)}<!--#{node.string}-->"
  when REXML::CData
    "#{step(opts, level)}<![CDATA[#{node.value}]]>"
  when REXML::Text
    txt = node.value.to_s.strip
    txt.empty? ? nil : "#{step(opts, level)}#{CGI.escapeHTML(txt)}"
  when REXML::Element
    attrs = attr_string(node)
    significant = node.children.reject { |c| c.is_a?(REXML::Text) && c.value.to_s.strip.empty? }
    if significant.empty?
      if opts[:html] && %w[script textarea title].include?(node.name.downcase)
        "#{step(opts, level)}<#{node.name}#{attrs}></#{node.name}>"
      else
        "#{step(opts, level)}<#{node.name}#{attrs}/>"
      end
    elsif significant.length == 1 && significant.first.is_a?(REXML::CData)
      "#{step(opts, level)}<#{node.name}#{attrs}><![CDATA[#{significant.first.value}]]></#{node.name}>"
    elsif significant.length == 1 && significant.first.is_a?(REXML::Text)
      "#{step(opts, level)}<#{node.name}#{attrs}>#{CGI.escapeHTML(significant.first.value.to_s.strip)}</#{node.name}>"
    else
      out = "#{step(opts, level)}<#{node.name}#{attrs}>"
      significant.each_with_index do |child, idx|
        if child.is_a?(REXML::CData) && idx.zero?
          out << "<![CDATA[#{child.value}]]>"
        elsif child.is_a?(REXML::Text)
          txt = child.value.to_s.strip
          out << CGI.escapeHTML(txt) unless txt.empty?
        else
          out << "\n"
          out << format_node(child, opts, level + 1).to_s
        end
      end
      out << "\n#{step(opts, level)}</#{node.name}>"
      out
    end
  end
end

def format_doc(doc, opts, include_decl)
  parts = []
  parts << format_node(doc.xml_decl, opts, 0) if include_decl && doc.xml_decl
  doc.children.each do |child|
    next if child.is_a?(REXML::XMLDecl)
    s = format_node(child, opts, 0)
    parts << s if s && !s.empty?
  end
  parts.join("\n") + "\n"
end

def colorize(xml)
  xml.gsub(/(<\/?[\w:.-]+|<\?|\?>|\/?>)/) { "\e[33m#{$1}\e[0m" }
     .gsub(/( [\w:.-]+)(="[^"]*")/) { "#{$1}\e[32m#{$2}\e[0m" }
end

def to_json_value(element, depth, level = 0)
  if depth >= 0 && level >= depth
    txt = element_text_deep(element)
    return txt unless txt.empty?
  end
  attrs = {}
  element.attributes.each { |k, v| attrs["@#{k}"] = v }
  child_elements = element.elements.to_a
  texts = element.texts.map { |t| t.value.to_s.strip }.reject(&:empty?)
  if attrs.empty? && child_elements.empty?
    return texts.empty? ? {} : texts.join("\n")
  end
  obj = {}
  obj['#text'] = texts.join("\n") unless texts.empty?
  attrs.each { |k, v| obj[k] = v }
  child_elements.each do |child|
    val = to_json_value(child, depth, level + 1)
    if obj.key?(child.name)
      obj[child.name] = [obj[child.name]] unless obj[child.name].is_a?(Array)
      obj[child.name] << val
    else
      obj[child.name] = val
    end
  end
  obj
end

def json_escape(str)
  str.to_s.gsub(/["\\\b\f\n\r\t]/) do |ch|
    case ch
    when '"' then '\"'
    when '\\' then '\\\\'
    when "\b" then '\b'
    when "\f" then '\f'
    when "\n" then '\n'
    when "\r" then '\r'
    when "\t" then '\t'
    end
  end
end

def json_compact_value(obj)
  case obj
  when Hash
    '{' + obj.map { |k, v| %("#{json_escape(k)}": #{json_compact_value(v)}) }.join(',') + '}'
  when Array
    '[' + obj.map { |v| json_compact_value(v) }.join(',') + ']'
  when String
    %("#{json_escape(obj)}")
  when NilClass
    'null'
  else
    obj.to_s
  end
end

def json_pretty_value(obj, level = 0)
  indent = '  ' * level
  child_indent = '  ' * (level + 1)
  case obj
  when Hash
    return "{}" if obj.empty?
    body = obj.map { |k, v| %(#{child_indent}"#{json_escape(k)}": #{json_pretty_value(v, level + 1)}) }.join(",\n")
    "{\n#{body}\n#{indent}}"
  when Array
    return "[]" if obj.empty?
    body = obj.map { |v| "#{child_indent}#{json_pretty_value(v, level + 1)}" }.join(",\n")
    "[\n#{body}\n#{indent}]"
  when String
    %("#{json_escape(obj)}")
  when NilClass
    'null'
  else
    obj.to_s
  end
end

def selector_match?(el, simple)
  tag = simple[/\A[\w:-]+/]
  return false if tag && el.name.downcase != tag.downcase
  if simple =~ /#([\w:-]+)/
    return false unless el.attributes['id'] == Regexp.last_match(1)
  end
  simple.scan(/\.([\w:-]+)/).each do |m|
    classes = el.attributes['class'].to_s.split(/\s+/)
    return false unless classes.include?(m[0])
  end
  true
end

def css_query(doc, selector)
  parts = selector.split('>').map(&:strip)
  current = [doc.root]
  parts.each_with_index do |part, idx|
    pool = []
    current.each do |node|
      if idx.zero?
        node.each_recursive { |e| pool << e if e.is_a?(REXML::Element) && selector_match?(e, part) }
      else
        node.elements.each { |e| pool << e if selector_match?(e, part) }
      end
    end
    current = pool
  end
  current
end

def output_nodes(nodes, opts)
  nodes = [nodes].compact unless nodes.is_a?(Array)
  lines = nodes.map do |node|
    if opts[:node]
      node.is_a?(REXML::Element) ? format_node(node, opts, 0) : text_value(node)
    else
      node.is_a?(REXML::Element) ? element_text_deep(node) : text_value(node)
    end
  end
  lines.reject(&:empty?).join("\n") + (lines.empty? ? '' : "\n")
end

def process_input(input, opts)
  include_decl = input.lstrip.start_with?('<?xml')
  doc = parse_doc(input, html: opts[:html])
  if opts[:json]
    obj = { doc.root.name => to_json_value(doc.root, opts[:depth]) }
    opts[:compact] ? json_compact_value(obj) + "\n" : json_pretty_value(obj) + "\n"
  elsif opts[:query]
    nodes = css_query(doc, opts[:query])
    if opts[:attr]
      nodes.map { |n| n.attributes[opts[:attr]].to_s }.reject(&:empty?).join("\n") + (nodes.empty? ? '' : "\n")
    else
      output_nodes(nodes, opts)
    end
  elsif opts[:xpath] || opts[:extract]
    expr = opts[:xpath] || opts[:extract]
    nodes = REXML::XPath.match(doc, expr)
    nodes = [nodes.first].compact if opts[:extract]
    output_nodes(nodes, opts)
  else
    formatted = format_doc(doc, opts, include_decl)
    opts[:color] && !opts[:no_color] ? colorize(formatted) : formatted
  end
end

opts, files = parse_args(ARGV)

result =
  if !opts[:in_place] && files.length > 1
    files.map { |file| process_input(read_file_or_die(file), opts) }.join
  else
    process_input(read_input(files, opts[:in_place]), opts)
  end

if opts[:in_place]
  File.write(files.first, result)
else
  print result
end
