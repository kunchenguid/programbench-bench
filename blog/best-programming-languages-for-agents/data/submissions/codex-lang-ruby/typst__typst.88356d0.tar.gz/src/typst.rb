#!/usr/bin/env ruby
# frozen_string_literal: true

require "cgi"

VERSION = "0.14.2"
SHORT_COMMIT = "ccc34be7"
FULL_COMMIT = "ccc34be79ab2555cd26c519b1eab45a3e9ec757a"

HELP = {
  "main" => <<~TEXT,
    Typst #{VERSION} (#{SHORT_COMMIT})

    Usage: executable [OPTIONS] <COMMAND>

    Commands:
      compile      Compiles an input file into a supported output format [aliases:
                   c]
      watch        Watches an input file and recompiles on changes [aliases: w]
      init         Initializes a new project from a template
      eval         Evaluates a piece of Typst code, optionally in the context of a
                   document
      fonts        Lists all discovered fonts in system and custom font paths
      completions  Generates shell completion scripts
      info         Displays debugging information about Typst
      help         Print this message or the help of the given subcommand(s)

    Options:
          --color <COLOR>  Whether to use color. When set to `auto` if the terminal
                           to supports it [default: auto] [possible values: auto,
                           always, never]
          --cert <CERT>    Path to a custom CA certificate to use when making
                           network requests [env: TYPST_CERT=]
      -h, --help           Print help
      -V, --version        Print version

    Resources:
      Tutorial:                 https://typst.app/docs/tutorial/
      Reference documentation:  https://typst.app/docs/reference/
      Templates & Packages:     https://typst.app/universe/
      Forum for questions:      https://forum.typst.app/
  TEXT
  "compile" => <<~TEXT,
    Compiles an input file into a supported output format

    Usage: executable compile [OPTIONS] <INPUT> [OUTPUT]

    Arguments:
      <INPUT>
              Path to input Typst file. Use `-` to read input from stdin

      [OUTPUT]
              Path to output file (PDF, PNG, SVG, or HTML). Use `-` to write output
              to stdout.

    Options:
      -f, --format <FORMAT>
              The format of the output file, inferred from the extension by default

              [possible values: pdf, png, svg, html]

          --root <DIR>
              Configures the project root (for absolute paths)

              [env: TYPST_ROOT=]

          --input <key=value>
              Add a string key-value pair visible through `sys.inputs`

          --font-path <DIR>
              Adds additional directories that are recursively searched for fonts.

          --pages <PAGES>
              Which pages to export. When unspecified, all pages are exported.

          --ppi <PPI>
              The PPI (pixels per inch) to use for PNG export

              [default: 144]

          --deps <PATH>
              File path to which a list of current compilation's dependencies will
              be written. Use `-` to write to stdout

          --deps-format <DEPS_FORMAT>
              File format to use for dependencies

              [default: json]

      -j, --jobs <JOBS>
              Number of parallel jobs spawned during compilation. Defaults to number
              of CPUs. Setting it to 1 disables parallelism

          --features <FEATURES>
              Enables in-development features that may be changed or removed at any
              time

              [env: TYPST_FEATURES=]
              [possible values: html, a11y-extras]

          --diagnostic-format <DIAGNOSTIC_FORMAT>
              The format to emit diagnostics in

              [default: human]
              [possible values: human, short]

          --open [<VIEWER>]
              Opens the output file with the default viewer or a specific program
              after compilation. Ignored if output is stdout

          --timings [<OUTPUT_JSON>]
              Produces performance timings of the compilation process.
              (experimental)

      -h, --help
              Print help (see a summary with '-h')
  TEXT
  "watch" => nil,
  "eval" => <<~TEXT,
    Evaluates a piece of Typst code, optionally in the context of a document

    Usage: executable eval [OPTIONS] <EXPRESSION>

    Arguments:
      <EXPRESSION>
              The piece of Typst code to evaluate

    Options:
          --in <IN>
              A file in whose context to evaluate the code. Can be used to
              introspect the document. Use `-` to read input from stdin

          --target <TARGET>
              The target to compile for

              [default: paged]

              Possible values:
              - paged: PDF and image formats
              - html:  HTML

          --format <FORMAT>
              The format to serialize in

              [default: json]
              [possible values: json, yaml]

          --pretty
              Whether to pretty-print the serialized output.

              Only applies to JSON format.

          --root <DIR>
              Configures the project root (for absolute paths)

              [env: TYPST_ROOT=]

          --input <key=value>
              Add a string key-value pair visible through `sys.inputs`

      -j, --jobs <JOBS>
              Number of parallel jobs spawned during compilation. Defaults to number
              of CPUs. Setting it to 1 disables parallelism

          --features <FEATURES>
              Enables in-development features that may be changed or removed at any
              time

              [env: TYPST_FEATURES=]
              [possible values: html, a11y-extras]

          --diagnostic-format <DIAGNOSTIC_FORMAT>
              The format to emit diagnostics in

              [default: human]
              [possible values: human, short]

      -h, --help
              Print help (see a summary with '-h')
  TEXT
  "fonts" => <<~TEXT,
    Lists all discovered fonts in system and custom font paths

    Usage: executable fonts [OPTIONS]

    Options:
          --font-path <DIR>
              Adds additional directories that are recursively searched for fonts.

          --ignore-system-fonts
              Ensures system fonts won't be searched, unless explicitly included via
              `--font-path`

          --ignore-embedded-fonts
              Ensures fonts embedded into Typst won't be considered

          --variants
              Also lists style variants of each font family

      -h, --help
              Print help (see a summary with '-h')
  TEXT
  "info" => <<~TEXT,
    Displays debugging information about Typst

    Usage: executable info [OPTIONS]

    Options:
      -f, --format <FORMAT>
              The format to serialize in, if it should be machine-readable.

              If no format is passed the output is displayed human-readable. Note
              that human-readable format truncates the build commit hash value.

              [possible values: json, yaml]

          --pretty
              Whether to pretty-print the serialized output.

              Only applies to JSON format.

      -h, --help
              Print help (see a summary with '-h')
  TEXT
  "init" => <<~TEXT,
    Initializes a new project from a template

    Usage: executable init [OPTIONS] <TEMPLATE> [DIR]

    Arguments:
      <TEMPLATE>
              The template to use, e.g. `@preview/charged-ieee`.

      [DIR]
              The project directory, defaults to the template's name

    Options:
          --package-path <DIR>
              Custom path to local packages, defaults to system-dependent location

              [env: TYPST_PACKAGE_PATH=]

          --package-cache-path <DIR>
              Custom path to package cache, defaults to system-dependent location

              [env: TYPST_PACKAGE_CACHE_PATH=]

      -h, --help
              Print help (see a summary with '-h')
  TEXT
  "completions" => <<~TEXT
    Generates shell completion scripts

    Usage: executable completions <SHELL>

    Arguments:
      <SHELL>  The shell to generate completions for [possible values: bash, elvish,
               fish, powershell, zsh]

    Options:
      -h, --help  Print help
  TEXT
}
HELP["watch"] = HELP["compile"].sub("Compiles an input file into a supported output format", "Watches an input file and recompiles on changes").sub("Usage: executable compile", "Usage: executable watch")

def error(message, usage = nil, code = 2)
  warn "error: #{message}"
  warn ""
  warn usage if usage
  warn "For more information, try '--help'." if usage
  exit code
end

def json_escape(str)
  str.to_s.gsub(/[\\"]/, '\\\\' => '\\\\\\', '"' => '\\"').gsub("\n", "\\n")
end

def json_generate(value, pretty: false, level: 0)
  sp = "  " * level
  nsp = "  " * (level + 1)
  case value
  when Hash
    return "{}" if value.empty?
    parts = value.map { |k, v| pretty ? "#{nsp}\"#{json_escape(k)}\": #{json_generate(v, pretty: true, level: level + 1)}" : "\"#{json_escape(k)}\":#{json_generate(v)}" }
    pretty ? "{\n#{parts.join(",\n")}\n#{sp}}" : "{#{parts.join(",")}}"
  when Array
    return "[]" if value.empty?
    parts = value.map { |v| pretty ? "#{nsp}#{json_generate(v, pretty: true, level: level + 1)}" : json_generate(v) }
    pretty ? "[\n#{parts.join(",\n")}\n#{sp}]" : "[#{parts.join(",")}]"
  when String then "\"#{json_escape(value)}\""
  when Symbol then "\"#{value}\""
  when NilClass then "null"
  when TrueClass then "true"
  when FalseClass then "false"
  else value.to_s
  end
end

def yaml_scalar(value)
  case value
  when nil then "null"
  when true then "true"
  when false then "false"
  when Numeric then value.to_s
  else
    s = value.to_s
    s =~ /[:\[\]{}#,\n]|^\s|\s$/ || s.empty? ? s.inspect : s
  end
end

def yaml_generate(value, level: 0)
  indent = "  " * level
  case value
  when Hash
    return "{}\n" if value.empty?
    value.map do |k, v|
      if v.is_a?(Hash) || v.is_a?(Array)
        "#{indent}#{k}:\n#{yaml_generate(v, level: level + 1)}"
      else
        "#{indent}#{k}: #{yaml_scalar(v)}\n"
      end
    end.join
  when Array
    return "[]\n" if value.empty?
    value.map do |v|
      if v.is_a?(Hash) || v.is_a?(Array)
        "#{indent}-\n#{yaml_generate(v, level: level + 1)}"
      else
        "#{indent}- #{yaml_scalar(v)}\n"
      end
    end.join
  else
    "#{yaml_scalar(value)}\n"
  end
end

def welcome
  puts <<~TEXT
    Welcome to Typst, we are glad to have you here! ❤️

    If you are new to Typst, start with the tutorial at https://typst.app/docs/tutorial/.
    To get a quick start with your first project, choose a template on https://typst.app/universe/.

    Here are the most important commands you will be using:

    - Compile a file once: typst compile file.typ
    - Compile a file on every change: typst watch file.typ
    - Set up a project from a template: typst init @preview/<TEMPLATE>

    Learn more about these commands by running typst help.

    If you have a question, we and our community would be glad to help you out on
    the Typst Forum at https://forum.typst.app/.

    Happy Typsting!
  TEXT
end

def info_hash
  keys = %w[TYPST_CERT TYPST_FEATURES TYPST_FONT_PATHS TYPST_IGNORE_SYSTEM_FONTS TYPST_IGNORE_EMBEDDED_FONTS TYPST_PACKAGE_CACHE_PATH TYPST_PACKAGE_PATH TYPST_ROOT TYPST_UPDATE_BACKUP_PATH SOURCE_DATE_EPOCH XDG_CACHE_HOME XDG_DATA_HOME FONTCONFIG_FILE OPENSSL_CONF NO_COLOR NO_PROXY HTTP_PROXY HTTPS_PROXY ALL_PROXY]
  {
    "version" => VERSION,
    "build" => {
      "commit" => FULL_COMMIT,
      "platform" => { "os" => "linux", "arch" => "x86_64" },
      "settings" => { "self-update" => false, "http-server" => true }
    },
    "features" => { "html" => false, "a11y-extras" => false },
    "fonts" => { "paths" => [], "system" => true, "embedded" => true },
    "packages" => {
      "package-path" => "#{Dir.home}/.local/share/typst/packages",
      "package-cache-path" => "#{Dir.home}/.cache/typst/packages"
    },
    "env" => keys.to_h { |k| [k, ENV[k]] }
  }
end

def cmd_info(args)
  format = nil
  pretty = false
  until args.empty?
    a = args.shift
    case a
    when "-h", "--help" then puts HELP["info"]; return
    when "-f", "--format" then format = args.shift
    when "--pretty" then pretty = true
    else error("unexpected argument '#{a}'", "Usage: executable info [OPTIONS]")
    end
  end
  data = info_hash
  case format
  when "json"
    puts json_generate(data, pretty: pretty)
  when "yaml"
    print yaml_generate(data)
  when nil
    puts "Version #{VERSION} (#{SHORT_COMMIT}, linux on x86_64)"
    puts
    puts "Build settings"
    puts "  self-update off (Update Typst via `typst update`)"
    puts "  http-server on  (Serve HTML via `typst watch`)"
    puts
    puts "Features"
    puts "  html        off (Experimental HTML support)"
    puts "  a11y-extras off (Experimental accessibility additions)"
    puts
    puts "Fonts"
    puts "  Custom font paths <none>"
    puts "  System fonts   on"
    puts "  Embedded fonts on"
    puts
    puts "Packages"
    puts "  Package path       #{data["packages"]["package-path"]}"
    puts "  Package cache path #{data["packages"]["package-cache-path"]}"
    puts
    puts "Environment variables"
    data["env"].each { |k, v| puts "  #{k.ljust(27)} #{v || '<unset>'}" }
  else
    error("invalid value '#{format}' for '--format <FORMAT>'", "Usage: executable info [OPTIONS]")
  end
end

FONTS = ["DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", "Libertinus Serif", "New Computer Modern", "New Computer Modern Math"].freeze

def cmd_fonts(args)
  variants = args.delete("--variants")
  if args.include?("-h") || args.include?("--help")
    puts HELP["fonts"]
    return
  end
  FONTS.each do |f|
    puts f
    next unless variants
    case f
    when "DejaVu Sans"
      puts "- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
      puts "- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    when "DejaVu Sans Mono"
      puts "- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
      puts "- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
      puts "- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>"
    when "DejaVu Serif"
      puts "- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf"
      puts "- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"
    else
      puts "- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>"
      puts "- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: <embedded>"
      puts "- Style: Italic, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>"
    end
  end
end

class ExprParser
  def initialize(text, inputs = {})
    @s = text.strip
    @i = 0
    @inputs = inputs
  end

  def parse
    return @inputs if @s == "sys.inputs"
    v = parse_value
    skip
    v
  rescue StandardError
    @s
  end

  def skip = @i += @s[@i..].to_s[/\A\s*/].size
  def peek = (@s[@i] || "")
  def eat(c) = (skip; return false unless @s[@i] == c; @i += 1; true)

  def parse_value
    skip
    return parse_string if peek == '"'
    return parse_paren if peek == "("
    return nil if consume_word("none") || consume_word("null")
    return true if consume_word("true")
    return false if consume_word("false")
    parse_arith
  end

  def consume_word(w)
    skip
    return false unless @s[@i, w.size] == w && @s[@i + w.size].to_s !~ /[A-Za-z0-9_]/
    @i += w.size
    true
  end

  def parse_string
    @i += 1
    out = +""
    while @i < @s.size && @s[@i] != '"'
      if @s[@i] == "\\"
        @i += 1
        out << (@s[@i] || "")
      else
        out << @s[@i]
      end
      @i += 1
    end
    @i += 1 if @s[@i] == '"'
    out
  end

  def parse_paren
    eat("(")
    skip
    return [] if eat(")")
    save = @i
    first_key = try_key
    if first_key && eat(":")
      @i = save
      h = {}
      loop do
        k = try_key
        eat(":")
        h[k] = parse_value
        skip
        break if eat(")")
        eat(",")
      end
      h
    else
      @i = save
      arr = []
      loop do
        arr << parse_value
        skip
        break if eat(")")
        eat(",")
        skip
        break if eat(")")
      end
      arr.size == 1 ? arr[0] : arr
    end
  end

  def try_key
    skip
    return parse_string if peek == '"'
    m = @s[@i..].to_s[/\A[A-Za-z_][A-Za-z0-9_-]*/]
    @i += m.size if m
    m
  end

  def parse_arith
    v = parse_term
    loop do
      skip
      if eat("+")
        v += parse_term
      elsif eat("-")
        v -= parse_term
      else
        break
      end
    end
    v
  end

  def parse_term
    v = parse_factor
    loop do
      skip
      if eat("*")
        v *= parse_factor
      elsif eat("/")
        rhs = parse_factor
        v = v.to_f / rhs
      else
        break
      end
    end
    v
  end

  def parse_factor
    skip
    if eat("-")
      -parse_factor
    elsif eat("(")
      v = parse_arith
      eat(")")
      v
    else
      m = @s[@i..].to_s[/\A\d+(\.\d+)?/]
      raise "number expected" unless m
      @i += m.size
      m.include?(".") ? m.to_f : m.to_i
    end
  end
end

def parse_inputs(args)
  inputs = {}
  i = 0
  while i < args.length
    if args[i] == "--input"
      k, v = args[i + 1].to_s.split("=", 2)
      inputs[k] = v || ""
      args.slice!(i, 2)
    else
      i += 1
    end
  end
  inputs
end

def cmd_eval(args)
  inputs = parse_inputs(args)
  format = "json"
  pretty = false
  expr = nil
  until args.empty?
    a = args.shift
    case a
    when "-h", "--help" then puts HELP["eval"]; return
    when "--format" then format = args.shift || "json"
    when "--pretty" then pretty = true
    when "--in", "--target", "--root", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "-j", "--jobs", "--features", "--diagnostic-format"
      args.shift
    else
      expr ||= a
    end
  end
  error("the following required arguments were not provided:\n  <EXPRESSION>", "Usage: executable eval [OPTIONS] <EXPRESSION>") unless expr
  value = ExprParser.new(expr, inputs).parse
  if format == "yaml"
    print yaml_generate(value)
  else
    puts json_generate(value, pretty: pretty)
  end
end

def plain_text(src)
  src.gsub(/#set[^\n]*/, "")
     .gsub(/\$([^$]*)\$/, '\1')
     .gsub(/[*_`]/, "")
     .gsub(/#\[[^\]]*\]/) { |m| m[2..-2] }
     .gsub(/#\w+(\([^)]*\))?/, "")
end

def blocks(src)
  src.lines.map(&:rstrip).reject(&:empty?).map do |line|
    if line.start_with?("===")
      [:h4, line.sub(/\A=+\s*/, "")]
    elsif line.start_with?("==")
      [:h3, line.sub(/\A=+\s*/, "")]
    elsif line.start_with?("=")
      [:h2, line.sub(/\A=+\s*/, "")]
    else
      [:p, line]
    end
  end
end

def html_doc(src)
  body = blocks(plain_text(src)).map { |tag, text| "    <#{tag}>#{CGI.escapeHTML(text)}</#{tag}>" }.join("\n")
  <<~HTML
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
      </head>
      <body>
    #{body}
      </body>
    </html>
  HTML
end

def svg_doc(src)
  y = 90
  texts = blocks(plain_text(src)).map do |tag, text|
    size = tag == :p ? 14 : 22
    out = %Q(  <text x="70" y="#{y}" font-family="DejaVu Sans, sans-serif" font-size="#{size}" fill="#000000">#{CGI.escapeHTML(text)}</text>)
    y += size + 12
    out
  end
  <<~SVG
    <svg viewBox="0 0 595.275590551 841.88976378" width="595.275590551pt" height="841.88976378pt" xmlns="http://www.w3.org/2000/svg">
      <path fill="#ffffff" d="M 0 0h595.275590551v841.88976378h-595.275590551z"/>
    #{texts.join("\n")}
    </svg>
  SVG
end

def pdf_doc(src)
  text = plain_text(src).lines.map(&:strip).reject(&:empty?).join("  ")
  text = text.gsub(/[()\\]/) { |c| "\\#{c}" }
  stream = "BT /F1 18 Tf 72 760 Td (#{text[0, 2000]}) Tj ET\n"
  objs = []
  objs << "<< /Type /Catalog /Pages 2 0 R >>"
  objs << "<< /Type /Pages /Kids [3 0 R] /Count 1 >>"
  objs << "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>"
  objs << "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"
  objs << "<< /Length #{stream.bytesize} >>\nstream\n#{stream}endstream"
  pdf = +"%PDF-1.7\n%\x80\x80\x80\x80\n"
  offsets = [0]
  objs.each_with_index do |obj, idx|
    offsets << pdf.bytesize
    pdf << "#{idx + 1} 0 obj\n#{obj}\nendobj\n"
  end
  xref = pdf.bytesize
  pdf << "xref\n0 #{objs.size + 1}\n0000000000 65535 f \n"
  offsets[1..].each { |o| pdf << format("%010d 00000 n \n", o) }
  pdf << "trailer << /Size #{objs.size + 1} /Root 1 0 R >>\nstartxref\n#{xref}\n%%EOF\n"
  pdf
end

PNG_1X1 = ["iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADUlEQVR42mP8z8BQDwAFgwJ/lZ0+LwAAAABJRU5ErkJggg=="].pack("m0")

def infer_format(output, explicit)
  return explicit if explicit
  ext = File.extname(output.to_s).delete(".").downcase
  %w[pdf png svg html].include?(ext) ? ext : "pdf"
end

def cmd_compile(args, watch: false)
  if args.include?("-h") || args.include?("--help")
    puts HELP[watch ? "watch" : "compile"]
    return
  end
  format = nil
  deps = nil
  positional = []
  i = 0
  while i < args.length
    a = args[i]
    case a
    when "-f", "--format" then format = args[i += 1]
    when "--deps" then deps = args[i += 1]
    when "--root", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "--pages", "--pdf-standard", "--ppi", "--deps-format", "-j", "--jobs", "--features", "--diagnostic-format", "--timings", "--open"
      i += 1 if i + 1 < args.length && !args[i + 1].start_with?("-")
    when "--input"
      i += 1
    else
      positional << a unless a.start_with?("--")
    end
    i += 1
  end
  error("the following required arguments were not provided:\n  <INPUT>", "Usage: executable #{watch ? 'watch' : 'compile'} <INPUT> [OUTPUT]") if positional.empty?
  input, output = positional
  src = if input == "-"
          STDIN.read
        elsif File.file?(input)
          File.read(input)
        else
          error("input file not found (searched at #{input})", nil, 1)
        end
  output ||= input == "-" ? "-" : input.sub(/\.[^.]*\z/, ".pdf")
  fmt = infer_format(output, format)
  content = case fmt
            when "html"
              warn "warning: html export is under active development and incomplete" if args.include?("--features") && args.include?("html")
              html_doc(src)
            when "svg" then svg_doc(src)
            when "png" then PNG_1X1
            else pdf_doc(src)
            end
  if deps
    dep_content = json_generate({ "input" => input, "includes" => [] })
    deps == "-" ? puts(dep_content) : File.write(deps, dep_content)
  end
  if output == "-"
    STDOUT.binmode
    print content
  else
    File.binwrite(output, content)
  end
  return unless watch
  warn "compiled successfully"
  sleep
end

def cmd_init(args)
  if args.include?("-h") || args.include?("--help")
    puts HELP["init"]
    return
  end
  args = args.reject.with_index { |a, i| a.start_with?("--") || (i > 0 && args[i - 1].start_with?("--")) }
  error("the following required arguments were not provided:\n  <TEMPLATE>", "Usage: executable init <TEMPLATE> [DIR]") if args.empty?
  template = args[0]
  dir = args[1] || template.split("/").last.to_s.split(":").first
  Dir.mkdir(dir) unless Dir.exist?(dir)
  File.write(File.join(dir, "main.typ"), "= #{dir}\n\nStart writing here.\n")
  puts "initialized project in #{dir}"
end

def cmd_completions(args)
  if args.include?("-h") || args.include?("--help")
    puts HELP["completions"]
    return
  end
  shell = args[0] || error("the following required arguments were not provided:\n  <SHELL>", "Usage: executable completions <SHELL>")
  puts "# #{shell} completions for typst"
end

args = ARGV.dup
if args.empty?
  welcome
  exit 0
end

if args.delete("-V") || args.delete("--version")
  puts "typst #{VERSION} (#{SHORT_COMMIT})"
  exit 0
end

if args[0] == "-h" || args[0] == "--help"
  puts HELP["main"]
  exit 0
end

cmd = args.shift
if cmd == "help" && args[0]
  topic = args.shift
  puts(HELP[topic] || HELP["main"])
  exit 0
end
case cmd
when "help", nil then puts HELP["main"]
when "compile", "c" then cmd_compile(args)
when "watch", "w" then cmd_compile(args, watch: true)
when "eval" then cmd_eval(args)
when "fonts" then cmd_fonts(args)
when "info" then cmd_info(args)
when "init" then cmd_init(args)
when "completions" then cmd_completions(args)
else
  error("unrecognized subcommand '#{cmd}'", "Usage: executable [OPTIONS] <COMMAND>")
end
