#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require 'date'
require 'digest/sha1'
require 'fileutils'
require 'time'

HELP = <<~TXT
  Usage:
  calcurse [-D <directory>] [-C <directory>] [-c <calendar file>]
  calcurse -Q [--from <date>] [--to <date>] [--days <number>]
  calcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]
  calcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon

  Operations in command line mode:
    -Q, --query   Print items in a given query range
    -G, --grep    Grep items from the data files
    -P, --purge   Read items and write them back
  Query short forms:
  -a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>

  Note that filter, format and day-range options affect input or output:
    --filter-*              Filter items loaded by -Q, -G, -P and -x
    --format-*              Rewrite output from -Q, -G and --dump-imported
    --from <date>           Limit day range of -Q.
    --to <date>             Limit day range of -Q.
    --days <number>         Limit day range of -Q.

    --limit, -l <number>    Limit number of query results
    --search, -S <regexp>   Match regular expression in queries
  Consult the man page for details.

  Miscellaneous:
    -c, --calendar <file>   The calendar data file to use
    -C, --confdir <dir>     The configuration directory to use
    --daemon                Run notification daemon in the background
    -D, --datadir <dir>     The data directory to use
    -g, --gc                Run the garbage collector
    -h, --help              Show this help text
    -i, --import <file>     Import iCal data from file
    -q, --quiet             Suppress import/export result message
    --read-only             Do not save configuration or data files
    --status                Display status of running instances
    -v, --version           Show version information
    -x, --export[<format>]  Export to stdout in ical (default) or pcal format

  For more information, type '?' from within calcurse, or read the manpage.
  Submit feature requests and suggestions to <misc@calcurse.org>.
  Submit bug reports to <bugs@calcurse.org>.
TXT

VERSION = <<~TXT
  calcurse 4.8.2 -- text-based organizer

  Copyright (c) 2004-2023 calcurse Development Team.
  This is free software; see the source for copying conditions.
TXT

class CalDate
  WEEKDAYS = { 'sun' => 0, 'mon' => 1, 'tue' => 2, 'wed' => 3, 'thu' => 4, 'fri' => 5, 'sat' => 6 }.freeze

  def initialize(input_fmt = 1)
    @input_fmt = input_fmt.to_i
  end

  def parse(str)
    s = str.to_s.strip.downcase
    today = Date.today
    return today if %w[today now].include?(s)
    return today + 1 if s == 'tomorrow'
    return today - 1 if s == 'yesterday'
    if WEEKDAYS.key?(s[0, 3])
      target = WEEKDAYS[s[0, 3]]
      delta = (target - today.wday) % 7
      delta = 7 if delta.zero?
      return today + delta
    end
    nums = s.scan(/\d+/).map(&:to_i)
    raise ArgumentError if nums.length < 3
    case @input_fmt
    when 2 then Date.new(nums[2], nums[1], nums[0])
    when 3, 4 then Date.new(nums[0], nums[1], nums[2])
    else Date.new(nums[2], nums[0], nums[1])
    end
  end

  def out(date, fmt)
    fmt ? date.strftime(fmt) : date.strftime('%m/%d/%y')
  end
end

Item = Struct.new(:kind, :start_dt, :end_dt, :date, :duration_days, :text, :priority, :done,
                  :recur, :exdates, :raw, :idx, keyword_init: true)

class App
  def initialize(argv)
    @argv = argv.dup
    @input_fmt = 1
    @output_fmt = nil
    @quiet = false
    @read_only = false
    @filters = {}
    @formats = {}
    @limit = nil
    @search = nil
    @datadir = nil
    @confdir = nil
    @calendar = nil
    @op = nil
    @op_arg = nil
    parse_args
    @date_parser = CalDate.new(@input_fmt)
    resolve_dirs
  end

  def run
    ensure_dirs
    case @op
    when :help then print HELP
    when :version then print VERSION
    when :status then puts 'calcurse is not running'
    when :gc then nil
    when :daemon then nil
    when :import then import_file(@op_arg)
    when :export then export(@op_arg || 'ical')
    when :grep then grep
    when :purge then save_all(filtered_items(invert: true))
    when :query then query
    when :todo then todo(@op_arg)
    when :next then query_next
    else
      warn 'Interactive mode is not implemented in this clean-room Ruby build.'
      exit 0
    end
  rescue ArgumentError => e
    warn e.message.empty? ? 'args.c: 797: invalid date' : e.message
    exit 1
  end

  def parse_args
    until @argv.empty?
      a = @argv.shift
      case a
      when '-h', '--help' then @op = :help
      when '-v', '--version' then @op = :version
      when '--status' then @op = :status
      when '-g', '--gc' then @op = :gc
      when '--daemon' then @op = :daemon
      when '-q', '--quiet' then @quiet = true
      when '--read-only' then @read_only = true
      when '-D', '--datadir' then @datadir = need(a)
      when '-C', '--confdir' then @confdir = need(a)
      when '-c', '--calendar' then @calendar = need(a)
      when '--input-datefmt' then @input_fmt = need(a).to_i
      when '--output-datefmt' then @output_fmt = need(a)
      when '-Q', '--query' then @op = :query
      when '-G', '--grep' then @op = :grep
      when '-P', '--purge' then @op = :purge
      when '-a', '--appointment' then @op = :query; @filters[:type] = 'cal'
      when '-n', '--next' then @op = :next
      when '-i', '--import' then @op = :import; @op_arg = need(a)
      when /^-i(.+)/ then @op = :import; @op_arg = Regexp.last_match(1)
      when '-x', '--export' then @op = :export
      when /^-x(.+)/ then @op = :export; @op_arg = Regexp.last_match(1)
      when /^--export=(.+)$/ then @op = :export; @op_arg = Regexp.last_match(1)
      when '-d', '--day'
        @op = :query
        val = need(a)
        if val =~ /^-?\d+$/
          @filters[:type] = 'cal'
          @days = val.to_i
        else
          @filters[:type] = 'cal'
          @from = val
          @to = val
        end
      when /^-d(.+)/
        @argv.unshift(Regexp.last_match(1)); @argv.unshift('-d')
      when /^-r(-?\d*)$/
        @op = :query; @filters[:type] = 'cal'; @days = (Regexp.last_match(1).empty? ? 1 : Regexp.last_match(1).to_i)
      when '--range'
        @op = :query; @filters[:type] = 'cal'; @days = need(a).to_i
      when /^--range=(.*)$/
        @op = :query; @filters[:type] = 'cal'; @days = (Regexp.last_match(1).empty? ? 1 : Regexp.last_match(1).to_i)
      when /^-s(.*)$/
        @op = :query; @filters[:type] = 'cal'; @from = (Regexp.last_match(1).empty? ? 'today' : Regexp.last_match(1))
      when /^--startday(?:=(.*))?$/
        @op = :query; @filters[:type] = 'cal'; @from = Regexp.last_match(1) || 'today'
      when /^-t(\d*)$/
        @op = :todo; @op_arg = (Regexp.last_match(1).empty? ? nil : Regexp.last_match(1).to_i)
      when /^--todo(?:=(\d+))?$/
        @op = :todo; @op_arg = (Regexp.last_match(1)&.to_i)
      when '--from' then @from = need(a)
      when '--to' then @to = need(a)
      when '--days' then @days = need(a).to_i
      when '-l', '--limit' then @limit = need(a).to_i
      when '-S', '--search', '--filter-pattern' then @search = need(a)
      when '--filter-type' then @filters[:type] = need(a)
      when '--filter-priority' then @filters[:priority] = need(a).to_i
      when '--filter-completed' then @filters[:completed] = true
      when '--filter-uncompleted' then @filters[:uncompleted] = true
      when '--filter-invert' then @filters[:invert] = true
      when '--format-apt' then @formats[:apt] = need(a)
      when '--format-recur-apt' then @formats[:recur_apt] = need(a)
      when '--format-event' then @formats[:event] = need(a)
      when '--format-recur-event' then @formats[:recur_event] = need(a)
      when '--format-todo' then @formats[:todo] = need(a)
      when '--dump-imported', '--export-uid'
        # Accepted for compatibility; dump-imported uses normal import storage here.
      else
        if a.start_with?('--format-')
          @formats[a.sub('--format-', '').tr('-', '_').to_sym] = need(a)
        elsif a.start_with?('--filter-')
          @filters[a.sub('--filter-', '').tr('-', '_').to_sym] = need(a)
        else
          warn "./executable: unrecognized option '#{a}'"
          print HELP.lines.first(5).join
          warn "Try `calcurse -h' for more information."
          exit 1
        end
      end
    end
  end

  def need(opt)
    raise ArgumentError, "missing argument for #{opt}" if @argv.empty?
    @argv.shift
  end

  def resolve_dirs
    home = ENV['HOME'] || Dir.home
    @datadir ||= File.join(ENV['XDG_DATA_HOME'] || File.join(home, '.local', 'share'), 'calcurse')
    @confdir ||= File.join(ENV['XDG_CONFIG_HOME'] || File.join(home, '.config'), 'calcurse')
    @apts_path = @calendar || File.join(@datadir, 'apts')
    @todo_path = File.join(@datadir, 'todo')
  end

  def ensure_dirs
    FileUtils.mkdir_p(@datadir) unless @read_only
    FileUtils.mkdir_p(@confdir) unless @read_only
    conf = File.join(@confdir, 'conf')
    File.write(conf, '') if !@read_only && !File.exist?(conf)
  end

  def load_items
    items = []
    if File.exist?(@apts_path)
      File.readlines(@apts_path, chomp: true).each { |line| parse_apt_line(line)&.then { |i| items << i } }
    end
    if File.exist?(@todo_path)
      File.readlines(@todo_path, chomp: true).each { |line| parse_todo_line(line)&.then { |i| items << i } }
    end
    items.each_with_index { |it, idx| it.idx = idx }
  end

  def parse_todo_line(line)
    return nil if line.strip.empty?
    if line =~ /^\[(-?\d+)\]\s*(.*)$/
      pr = Regexp.last_match(1).to_i
      Item.new(kind: :todo, priority: pr.abs, done: pr < 0, text: Regexp.last_match(2), raw: line)
    end
  end

  def parse_apt_line(line)
    raw = line.dup
    if line =~ %r!^(\d{2})/(\d{2})/(\d{4}) @ (\d{2}):(\d{2}) -> (\d{2})/(\d{2})/(\d{4}) @ (\d{2}):(\d{2})(?: \{([^}]*)\})?(?: >[0-9a-f]+)?\s*\|(.*)$!
      sd = Date.new($3.to_i, $1.to_i, $2.to_i); ed = Date.new($8.to_i, $6.to_i, $7.to_i)
      st = Time.local(sd.year, sd.month, sd.day, $4.to_i, $5.to_i, 0)
      en = Time.local(ed.year, ed.month, ed.day, $9.to_i, $10.to_i, 0)
      rec = parse_recur($11)
      Item.new(kind: rec ? :recur_apt : :apt, start_dt: st, end_dt: en, text: $12, recur: rec, exdates: rec&.delete(:exdates) || [], raw: raw)
    elsif line =~ %r!^(\d{2})/(\d{2})/(\d{4}) \[(\d+)\](?: \{([^}]*)\})?(?: >[0-9a-f]+)? (.*)$!
      d = Date.new($3.to_i, $1.to_i, $2.to_i)
      rec = parse_recur($5)
      Item.new(kind: rec ? :recur_event : :event, date: d, duration_days: $4.to_i, text: $6, recur: rec, exdates: rec&.delete(:exdates) || [], raw: raw)
    end
  end

  def parse_recur(s)
    return nil unless s
    parts = s.split
    m = parts.shift&.match(/^(\d+)([DWMY])$/)
    return nil unless m
    parts.shift if parts[0] == '->'
    until_s = parts.shift
    ex = parts.select { |p| p.start_with?('!') }.map { |p| parse_storage_date(p[1..]) }
    { interval: m[1].to_i, freq: m[2], until: (parse_storage_date(until_s) if until_s && until_s != '0'), exdates: ex }
  end

  def parse_storage_date(s)
    a = s.scan(/\d+/).map(&:to_i)
    Date.new(a[2], a[0], a[1])
  end

  def date_range
    if @from
      from = @date_parser.parse(@from)
    else
      from = Date.today
    end
    if @to
      to = @date_parser.parse(@to)
    elsif @days
      if @days.negative?
        to = from
        from = from + @days + 1
      else
        to = from + @days - 1
      end
    else
      to = from
    end
    from, to = to, from if from > to
    [from, to]
  end

  def query
    from, to = date_range
    items = filtered_items
    todos = items.select { |i| i.kind == :todo }
    cals = items.reject { |i| i.kind == :todo }
    printed = false
    unless type_filter_cal_only?
      open_todos = todos
      if open_todos.any?
        puts 'to do:'
        open_todos.each { |t| print format_item(t, @formats[:todo] || "%p. %m\n") }
        printed = true
      end
    end
    day = from
    while day <= to
      occ = occurrences_for_day(cals, day)
      unless occ.empty?
        puts if printed
        puts "#{@date_parser.out(day, @output_fmt)}:"
        occ.each { |item, os, oe| print format_calendar_default(item, day, os, oe) }
        printed = true
      end
      day += 1
    end
  end

  def todo(priority = nil)
    todos = load_items.select { |i| i.kind == :todo }
    if priority == 0
      todos = todos.select(&:done)
      puts 'completed tasks:' if todos.any?
    else
      todos = todos.reject(&:done)
      todos = todos.select { |t| t.priority == priority } if priority
      puts 'to do:' if todos.any?
    end
    todos.each { |t| puts "#{t.priority}. #{t.text}" }
  end

  def query_next
    now = Time.now
    items = filtered_items.select { |i| [:apt, :recur_apt].include?(i.kind) }
    occs = []
    (Date.today..(Date.today + 1)).each do |d|
      occurrences_for_day(items, d).each { |i, s, _e| occs << [s, i] if s && s > now && s <= now + 86_400 }
    end
    occ = occs.min_by(&:first)
    return unless occ
    mins = ((occ[0] - now) / 60).floor
    puts format('%02d:%02d %s', mins / 60, mins % 60, occ[1].text)
  end

  def grep
    order = { todo: 0, apt: 1, recur_apt: 1, event: 2, recur_event: 2 }
    filtered_items.sort_by { |i| [order[i.kind] || 9, i.start_dt || Time.at(0), i.date || Date.new(1), i.idx || 0] }
                  .each { |i| print format_item(i, @formats[format_key(i)] || "%(raw)") }
  end

  def filtered_items(invert: false)
    rx = @search ? Regexp.new(@search) : nil
    types = expand_types(@filters[:type])
    arr = load_items.select do |i|
      ok = true
      ok &&= types.include?(i.kind) if types
      ok &&= i.text =~ rx if rx
      ok &&= i.priority == @filters[:priority] if @filters[:priority] && i.kind == :todo
      ok &&= i.done if @filters[:completed] && i.kind == :todo
      ok &&= !i.done if @filters[:uncompleted] && i.kind == :todo
      (@filters[:invert] || invert) ? !ok : ok
    end
    @limit ? arr.first(@limit) : arr
  end

  def expand_types(s)
    return nil unless s
    map = {
      'event' => [:event], 'apt' => [:apt], 'recur-event' => [:recur_event],
      'recur-apt' => [:recur_apt], 'todo' => [:todo],
      'recur' => [:recur_event, :recur_apt], 'cal' => [:event, :apt, :recur_event, :recur_apt]
    }
    s.split(',').flat_map { |x| map[x] || [] }
  end

  def type_filter_cal_only?
    expand_types(@filters[:type])&.none? { |t| t == :todo }
  end

  def occurrences_for_day(items, day)
    out = []
    items.each do |i|
      if i.kind == :event
        out << [i, nil, nil] if day >= i.date && day < i.date + i.duration_days
      elsif i.kind == :recur_event
        recur_dates(i, day, day).each { out << [i, nil, nil] }
      elsif i.kind == :apt
        out << [i, i.start_dt, i.end_dt] if day_overlaps?(i.start_dt, i.end_dt, day)
      elsif i.kind == :recur_apt
        recur_dates(i, day - 370, day).each do |od|
          delta = (od - i.start_dt.to_date).to_i
          s = i.start_dt + delta * 86_400
          e = i.end_dt + delta * 86_400
          out << [i, s, e] if day_overlaps?(s, e, day)
        end
      end
    end
    out.sort_by do |i, s, e|
      rank = { event: 0, recur_event: 1, apt: 2, recur_apt: 2 }[i.kind] || 3
      recur_until = i.recur && i.recur[:until] ? i.recur[:until].jd : 0
      [rank, s || Time.local(day.year, day.month, day.day), e || Time.local(day.year, day.month, day.day), recur_until, i.idx || 0]
    end
  end

  def day_overlaps?(s, e, day)
    ds = Time.local(day.year, day.month, day.day)
    de = ds + 86_400
    s < de && e >= ds && !(e == ds && s.to_date != day)
  end

  def recur_dates(item, from, to)
    base = item.kind == :recur_event ? item.date : item.start_dt.to_date
    rec = item.recur
    until_d = rec[:until] || to
    max = [to, until_d].min
    dates = []
    d = base
    while d <= max
      if d >= from && !item.exdates.include?(d)
        dates << d
      end
      d = case rec[:freq]
          when 'D' then d + rec[:interval]
          when 'W' then d + 7 * rec[:interval]
          when 'M' then add_months(d, rec[:interval])
          when 'Y' then add_months(d, 12 * rec[:interval])
          else d + 1
          end
      break if dates.length > 10_000
    end
    dates
  end

  def add_months(d, n)
    y = d.year + (d.month - 1 + n) / 12
    m = (d.month - 1 + n) % 12 + 1
    Date.new(y, m, [d.day, Date.new(y, m, -1).day].min)
  end

  def format_calendar_default(item, day, s, e)
    fmt = @formats[format_key(item)]
    return format_item(item, fmt, s, e, day) if fmt
    if [:event, :recur_event].include?(item.kind)
      " * #{item.text}\n"
    else
      ds = Time.local(day.year, day.month, day.day)
      de = ds + 86_400
      ss = s < ds ? '..:..' : s.strftime('%H:%M')
      ee = e > de ? '..:..' : e.strftime('%H:%M')
      " - #{ss} -> #{ee}\n\t#{item.text}\n"
    end
  end

  def format_key(i)
    i.kind
  end

  def format_item(item, fmt, s = nil, e = nil, _day = nil)
    raw = item.raw || serialize_item(item)
    h = Digest::SHA1.hexdigest(raw)
    out = fmt.dup
    out = out.gsub('%(raw)', raw + "\n").gsub('%(hash)', h)
    out = out.gsub('%p', item.priority.to_s).gsub('%m', item.text.to_s)
    if s && e
      out = out.gsub('%S', s.strftime('%H:%M')).gsub('%E', e.strftime('%H:%M'))
      out = out.gsub('%s', s.to_i.to_s).gsub('%e', e.to_i.to_s).gsub('%d', (e - s).to_i.to_s)
    end
    out.gsub('\n', "\n").gsub('\t', "\t")
  end

  def save_all(items)
    return if @read_only
    File.write(@apts_path, items.reject { |i| i.kind == :todo }.map { |i| serialize_item(i) }.join("\n") + "\n")
    File.write(@todo_path, items.select { |i| i.kind == :todo }.map { |i| serialize_item(i) }.join("\n") + "\n")
  end

  def serialize_item(i)
    case i.kind
    when :todo then "[#{i.done ? -i.priority : i.priority}] #{i.text}"
    when :event then "#{i.date.strftime('%m/%d/%Y')} [#{i.duration_days || 1}] #{i.text}"
    when :recur_event
      "#{i.date.strftime('%m/%d/%Y')} [#{i.duration_days || 1}] #{recur_string(i)} #{i.text}"
    when :apt then "#{i.start_dt.strftime('%m/%d/%Y @ %H:%M')} -> #{i.end_dt.strftime('%m/%d/%Y @ %H:%M')}|#{i.text}"
    when :recur_apt then "#{i.start_dt.strftime('%m/%d/%Y @ %H:%M')} -> #{i.end_dt.strftime('%m/%d/%Y @ %H:%M')} #{recur_string(i)} |#{i.text}"
    end
  end

  def recur_string(i)
    r = i.recur
    ex = i.exdates.map { |d| " !#{d.strftime('%m/%d/%Y')}" }.join
    "{#{r[:interval]}#{r[:freq]} -> #{(r[:until] || Date.new(0)).strftime('%m/%d/%Y')}#{ex}}"
  end

  def import_file(path)
    lines = File.readlines(path, chomp: true)
    unfolded = []
    lines.each do |l|
      if l.start_with?(' ', "\t") && unfolded.any?
        unfolded[-1] += l[1..]
      else
        unfolded << l.sub(/\r$/, '')
      end
    end
    items = []
    comp = nil
    unfolded.each do |line|
      if line == 'BEGIN:VEVENT' || line == 'BEGIN:VTODO'
        comp = { type: line.split(':').last, props: [] }
      elsif line.start_with?('END:') && comp
        items << item_from_ical(comp)
        comp = nil
      elsif comp
        comp[:props] << line
      end
    end
    items.compact!
    old = load_items
    save_all(old + items)
    unless @quiet
      apps = items.count { |i| [:apt, :recur_apt].include?(i.kind) }
      evs = items.count { |i| [:event, :recur_event].include?(i.kind) }
      todos = items.count { |i| i.kind == :todo }
      puts format('Import process report: %04d lines read', lines.length)
      puts "#{apps} app / #{evs} events / #{todos} todo / 0 skipped"
    end
  end

  def item_from_ical(comp)
    props = {}
    comp[:props].each do |l|
      k, v = l.split(':', 2)
      next unless v
      props[k] ||= []
      props[k] << v
    end
    summary = unescape((props.find { |k, _| k.start_with?('SUMMARY') }&.last || ['']).last)
    if comp[:type] == 'VTODO'
      pr = (props['PRIORITY'] || ['0']).last.to_i
      done = (props['STATUS'] || []).last == 'COMPLETED'
      return Item.new(kind: :todo, priority: pr, done: done, text: summary)
    end
    dtkey, dtval = props.find { |k, _| k.start_with?('DTSTART') }
    return nil unless dtval
    all_day = dtkey.include?('VALUE=DATE')
    if all_day
      start = Date.strptime(dtval.last[0, 8], '%Y%m%d')
      dtend = props.find { |k, _| k.start_with?('DTEND') }&.last&.last
      len = dtend ? [(Date.strptime(dtend[0, 8], '%Y%m%d') - start).to_i, 1].max : 1
      rr = rrule_hash((props['RRULE'] || []).last, start, props['EXDATE'])
      if rr
        Item.new(kind: :recur_event, date: start, duration_days: len, text: summary, recur: rr, exdates: rr.delete(:exdates) || [])
      elsif len > 1
        Item.new(kind: :recur_event, date: start, duration_days: 1, text: summary,
                 recur: { interval: 1, freq: 'D', until: start + len - 1 }, exdates: [])
      else
        Item.new(kind: :event, date: start, duration_days: 1, text: summary)
      end
    else
      st = parse_ical_time(dtval.last)
      en = if (dtend = props.find { |k, _| k.start_with?('DTEND') }&.last&.last)
             parse_ical_time(dtend)
           else
             st + parse_duration((props['DURATION'] || ['PT0S']).last)
           end
      rr = rrule_hash((props['RRULE'] || []).last, st, props['EXDATE'])
      if rr
        Item.new(kind: :recur_apt, start_dt: st, end_dt: en, text: summary, recur: rr, exdates: rr.delete(:exdates) || [])
      else
        Item.new(kind: :apt, start_dt: st, end_dt: en, text: summary)
      end
    end
  end

  def parse_ical_time(s)
    s = s.delete_suffix('Z')
    Time.local(s[0, 4].to_i, s[4, 2].to_i, s[6, 2].to_i, s[9, 2].to_i, s[11, 2].to_i, s[13, 2].to_i)
  end

  def parse_duration(s)
    m = s.match(/P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/)
    (((m[1] || 0).to_i * 24 + (m[2] || 0).to_i) * 3600) + (m[3] || 0).to_i * 60 + (m[4] || 0).to_i
  end

  def rrule_hash(rule, start_date, exprops)
    return nil unless rule
    vals = rule.split(';').map { |p| p.split('=', 2) }.to_h
    freq = { 'DAILY' => 'D', 'WEEKLY' => 'W', 'MONTHLY' => 'M', 'YEARLY' => 'Y' }[vals['FREQ']] || 'D'
    int = (vals['INTERVAL'] || '1').to_i
    until_d = nil
    if vals['UNTIL']
      until_d = Date.strptime(vals['UNTIL'][0, 8], '%Y%m%d')
      if vals['UNTIL'].include?('T') && start_date.is_a?(Time)
        ut = parse_ical_time(vals['UNTIL'])
        day_start = Time.local(ut.year, ut.month, ut.day, start_date.hour, start_date.min, start_date.sec)
        until_d -= 1 if ut < day_start
      end
    end
    start_date = start_date.to_date if start_date.is_a?(Time)
    if vals['COUNT'] && !until_d
      d = start_date
      (vals['COUNT'].to_i - 1).times { d = advance_recur_date(d, freq, int) }
      until_d = d
    end
    ex = Array(exprops).flat_map { |xs| xs.split(',').map { |x| Date.strptime(x[0, 8], '%Y%m%d') } }
    { interval: int, freq: freq, until: until_d, exdates: ex }
  end

  def advance_recur_date(d, freq, int)
    case freq
    when 'D' then d + int
    when 'W' then d + 7 * int
    when 'M' then add_months(d, int)
    when 'Y' then add_months(d, 12 * int)
    end
  end

  def unescape(s)
    s.to_s.gsub('\\n', "\n").gsub('\\,', ',').gsub('\\;', ';').gsub('\\\\', '\\')
  end

  def escape(s)
    s.to_s.gsub('\\', '\\\\').gsub(',', '\\,').gsub(';', '\\;').gsub("\n", '\\n')
  end

  def export(fmt)
    if fmt != 'ical'
      warn "args.c: 631: invalid export format: #{fmt}"
      exit 1
    end
    puts 'BEGIN:VCALENDAR'
    puts 'VERSION:2.0'
    puts 'PRODID:-//calcurse//NONSGML v4.8.2//EN'
    load_items.reject { |i| i.kind == :todo }.each { |i| export_cal(i) }
    load_items.select { |i| i.kind == :todo }.each { |i| export_todo(i) }
    puts 'END:VCALENDAR'
  end

  def export_cal(i)
    puts 'BEGIN:VEVENT'
    if [:event, :recur_event].include?(i.kind)
      puts "DTSTART;VALUE=DATE:#{i.date.strftime('%Y%m%d')}"
      if i.kind == :recur_event
        puts "RRULE:FREQ=#{freq_name(i.recur[:freq])};UNTIL=#{i.recur[:until].strftime('%Y%m%d')}" if i.recur[:until]
      end
    else
      dur = (i.end_dt - i.start_dt).to_i
      puts "DTSTART:#{i.start_dt.strftime('%Y%m%dT%H%M%S')}"
      puts "DURATION:P#{dur / 86_400}DT#{dur % 86_400 / 3600}H#{dur % 3600 / 60}M0S" if dur.positive?
      if i.kind == :recur_apt && i.recur[:until]
        puts "RRULE:FREQ=#{freq_name(i.recur[:freq])};INTERVAL=#{i.recur[:interval]};UNTIL=#{i.recur[:until].strftime('%Y%m%dT000000')}"
      end
    end
    puts "SUMMARY:#{escape(i.text)}"
    puts 'END:VEVENT'
  end

  def export_todo(i)
    puts 'BEGIN:VTODO'
    puts "PRIORITY:#{i.priority}"
    puts "SUMMARY:#{escape(i.text)}"
    puts 'STATUS:COMPLETED' if i.done
    puts 'END:VTODO'
  end

  def freq_name(f)
    { 'D' => 'DAILY', 'W' => 'WEEKLY', 'M' => 'MONTHLY', 'Y' => 'YEARLY' }[f] || 'DAILY'
  end
end

App.new(ARGV).run
