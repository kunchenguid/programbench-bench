#!/usr/bin/env ruby
# frozen_string_literal: true

require "fileutils"

HELP = <<~HELP
  # felix v2.16.1
  A simple TUI file manager with vim-like keymapping.

  ## Usage
  `fx` => Show items in the current directory.
  `fx <directory path>` => Show items in the path.
  Both relative and absolute path available.

  ## Options
  `--help` | `-h`   => Print help.
  `--log`  | `-l`   => Launch the app, automatically generating a log file.
  `--init`          => Returns a shell script that can be sourcedfor
                       for shell integration.

  ## Manual
  j / <Down>         :Go down.
  k / <Up>           :Go up.
  <C-d>              :Go down 1/2 page.
  <C-u>>             :Go up 1/2 page.
  h / <Left>         :Go to the parent directory if exists.
  l / <Right> / <CR> :Open item or change directory.
  gg                 :Go to the top.
  G                  :Go to the bottom.
  z<CR>              :Go to the home directory.
  z {keyword}<CR>    :Jump to a directory that matches the keyword.
                      (zoxide required)
  <C-o>              :Jump backward.
  <C-i>              :Jump forward.
  i{file name}<CR>   :Create a new empty file.
  I{dir name}<CR>    :Create a new empty directory.
  o                  :Open item in a new window.
  e                  :Unpack archive/compressed file.
  dd                 :Delete and yank item.
  yy                 :Yank item.
  p                  :Put yanked item(s) from register zero
                      in the current directory.
  :reg               :Show registers. To hide it, press v.
  "ayy               :Yank item to register a.
  "add               :Delete and yank item to register a.
  "Ayy               :Append item to register a.
  "Add               :Delete and append item to register a.
  "ap                :Put item(s) from register a.
  V                  :Switch to the linewise visual mode.
    - y              :In the visual mode, yank selected item(s).
    - d              :In the visual mode, delete and yank selected item(s).
    - "ay            :In the visual mode, yank items to register a.
    - "ad            :In the visual mode, delete and yank items to register a.
    - "Ay            :In the visual mode, append items to register a.
    - "Ad            :In the visual mode, delete and append items to register a.
    - c              :Rename selected items in default editor.
  u                  :Undo put/delete/rename.
  <C-r>              :Redo put/delete/rename.
  v                  :Toggle whether to show the preview.
  s                  :Toggle between vertical / horizontal split in the preview mode.
  <Alt-j>
   / <Alt-<Down>>    :Scroll down the preview text.
  <Alt-k> 
   / <Alt-<Up>>      :Scroll up the preview text.
  <BS>               :Toggle whether to show hidden items.
  t                  :Toggle the sort order (name <-> modified time).
  c                  :Switch to the rename mode.
  /{keyword}         :Search items by a keyword.
  n                  :Go forward to the item that matches the keyword.
  N                  :Go backward to the item that matches the keyword.
  :                  :Switch to the command line.
    - <C-r>a         :In the command line, paste item name in register a.
  :cd<CR>            :Go to the home directory.
  :cd {path}<CR>     :Go to the path.
  :e<CR>             :Reload the current directory.
  :config<CR>        :Go to the directory that contains the config file if exists.
  :trash<CR>         :Go to the trash directory.
  :empty<CR>         :Empty the trash directory.
  :h<CR>             :Show help.
  :q<CR>             :Exit.
  :{command}         :Execute a command e.g. :zip test *.md
  <Esc>              :Return to the normal mode.
  <C-h>              :Works as Backspace after `i`, `I`, `c`, `/`, `:` and `z`.
  ZZ                 :Exit without cd to last working directory
                      (if `match_vim_exit_behavior` is `false`).
  ZQ                 :cd into the last working directory and exit
                      (if shell setting is ready and `match_vim_exit_behavior is `false`).

  ## Preview feature
  By default, text files and directories can be previewed.
  To preview images, you need to install chafa (>= v1.10.0).
  Please see https://hpjansson.org/chafa/

  ## Configuration

  *Both `config.yaml` and `config.yml` work.*

  ### Linux
  config file    : $XDG_CONFIG_HOME/felix/config.yaml(config.yml)
  trash directory: $XDG_DATA_HOME/felix/trash
  log files      : $XDG_DATA_HOME/felix/log

  ### macOS
  On macOS, felix looks for the config file in the following locations:

  1. `$HOME/Library/Application Support/felix/config.yaml(config.yml)`
  2. `$HOME/.config/felix/config.yaml`

  trash directory: $HOME/Library/Application Support/felix/trash
  log files      : $HOME/Library/Application Support/felix/log

  ### Windows
  config file     : $PROFILE\\\\AppData\\\\Roaming\\\\felix\\\\config.yaml(config.yml)
  trash directory : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\trash
  log files       : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\log

  For more details, visit https://github.com/kyoheiu/felix
HELP

INIT_SNIPPET = <<~SH
  # To be eval'ed in the calling shell
    eval "$(
      if [ -n "$XDG_RUNTIME_DIR" ]; then
        runtime_dir="$XDG_RUNTIME_DIR/felix"
      elif [ -n "$TMPDIR" ]; then
        runtime_dir="$TMPDIR/felix"
      else
        runtime_dir=/tmp/felix
      fi

      mkdir -p "$runtime_dir"

      # Clean up leftover LWD files
      find "$runtime_dir" -type f -and -mmin +1 -delete

      cat << EOF
  fx() {
    local RUNTIME_DIR="$runtime_dir"
    SHELL_PID=\\$\\$ command fx "\\$@"

    if [ -f "\\$RUNTIME_DIR/\\$\\$" ]; then
      cd "\\$(cat "\\$RUNTIME_DIR/\\$\\$")"
      rm "\\$RUNTIME_DIR/\\$\\$"
    fi
  }
  EOF
    )"
SH

def data_home
  ENV["XDG_DATA_HOME"].to_s.empty? ? File.join(Dir.home, ".local", "share") : ENV["XDG_DATA_HOME"]
end

def create_log
  dir = File.join(data_home, "felix", "log")
  FileUtils.mkdir_p(dir)
  path = File.join(dir, "#{Time.now.strftime("%Y-%m-%d-%H-%M-%S")}.log")
  File.open(path, "a") { |f| f.puts "#{Time.now.strftime("%H:%M:%S")} [INFO] ===START===" }
end

def show_arg_error(message)
  puts
  puts message
  puts "`fx -h` shows help."
end

def validate_path(path)
  unless File.exist?(path)
    show_arg_error("Invalid path: #{path}")
    return false
  end
  unless File.directory?(path)
    show_arg_error("Path should be directory.")
    return false
  end
  true
end

def entries(path, show_hidden: false, sort_time: false)
  list = Dir.children(path).select { |name| show_hidden || !name.start_with?(".") }
  list.sort_by! { |name| sort_time ? [File.mtime(File.join(path, name)).to_i * -1, name.downcase] : name.downcase }
  list
rescue SystemCallError
  []
end

def terminal_size
  return [nil, nil] unless STDIN.tty?

  size = `stty size 2>/dev/null`.split.map(&:to_i)
  return [nil, nil] unless size.length == 2 && size.all?(&:positive?)

  size
rescue StandardError
  [nil, nil]
end

def read_key
  first = STDIN.getc
  return nil unless first

  if first == "\e"
    rest = +""
    begin
      while IO.select([STDIN], nil, nil, 0.001)
        c = STDIN.getc
        break unless c
        rest << c
        break if rest.length >= 5
      end
    rescue StandardError
      nil
    end
    first + rest
  else
    first
  end
end

def draw(path, selected, show_hidden, sort_time)
  rows, cols = terminal_size
  print "\e[?25l\e[2J\e[H"
  header = " #{File.expand_path(path)} "
  puts header[0, cols]
  puts ("-" * [cols, 1].max)
  visible_rows = [rows - 3, 1].max
  list = entries(path, show_hidden: show_hidden, sort_time: sort_time)
  start = selected >= visible_rows ? selected - visible_rows + 1 : 0
  list[start, visible_rows].to_a.each_with_index do |name, idx|
    actual = start + idx
    full = File.join(path, name)
    mark = actual == selected ? ">" : " "
    suffix = File.directory?(full) ? "/" : ""
    line = "#{mark} #{name}#{suffix}"
    print(actual == selected ? "\e[7m" : "")
    puts line[0, cols]
    print "\e[0m" if actual == selected
  end
  puts "NORMAL  #{list.length} items" if rows > 2
end

def run_tui(start_path)
  rows, cols = terminal_size
  unless rows && cols
    puts "Error: Cannot detect terminal size"
    return
  end
  if rows < 10 || cols < 40
    puts "Error: Too small window size"
    return
  end

  path = File.expand_path(start_path)
  selected = 0
  show_hidden = false
  sort_time = false
  command = +""
  begin
    system("stty raw -echo 2>/dev/null")
    loop do
      list = entries(path, show_hidden: show_hidden, sort_time: sort_time)
      selected = [[selected, 0].max, [list.length - 1, 0].max].min
      draw(path, selected, show_hidden, sort_time)
      char = read_key
      case char
      when "\u0003", "\u001b"
        break
      when "j", "\e[B"
        selected += 1 if selected < list.length - 1
      when "k", "\e[A"
        selected -= 1 if selected.positive?
      when "G"
        selected = list.length - 1
      when "g"
        nxt = read_key
        selected = 0 if nxt == "g"
      when "\r", "l", "\e[C"
        target = list[selected] && File.join(path, list[selected])
        if target && File.directory?(target)
          path = target
          selected = 0
        end
      when "h", "\e[D"
        parent = File.dirname(path)
        if parent != path
          path = parent
          selected = 0
        end
      when "\177", "\b"
        show_hidden = !show_hidden
      when "t"
        sort_time = !sort_time
      when ":"
        command.clear
        loop do
          draw(path, selected, show_hidden, sort_time)
          print ":#{command}"
          c = read_key
          break if c == "\e"
          if c == "\r"
            case command.strip
            when "q"
              print "\e[?25h\e[0m\e[2J\e[H"
              return
            when "h"
              print "\e[?25h\e[0m\e[2J\e[H"
              puts HELP
              return
            when "e"
              selected = 0
            when "cd"
              path = Dir.home
              selected = 0
            else
              if command.start_with?("cd ")
                dest = File.expand_path(command[3..], path)
                path = dest if File.directory?(dest)
                selected = 0
              end
            end
            break
          elsif c == "\177" || c == "\b" || c == "\u0008"
            command.chop!
          else
            command << c if c && c.ord >= 32
          end
        end
      when "Z"
        nxt = read_key
        break if %w[Z Q].include?(nxt)
      end
    end
  ensure
    system("stty sane 2>/dev/null")
    print "\e[?25h\e[0m\e[2J\e[H"
  end
end

args = ARGV.dup

if args.first == "--help" || args.first == "-h"
  puts HELP
  exit 0
end

if args.first == "--init" && args.length == 1
  print INIT_SNIPPET
  exit 0
end

log = false
if args.first == "--log" || args.first == "-l"
  log = true
  args.shift
end

if args.length > 1
  puts HELP
  exit 0
end

path = args.first || "."
unless validate_path(path)
  exit 0
end

create_log if log
run_tui(path)
