#!/usr/bin/env ruby
# frozen_string_literal: true

require 'find'
require 'fileutils'

VERSION = '3.0.0-20260303205914-9926ea38658f'
STD_PKGS = %w[
  archive/tar archive/zip bufio bytes cmp compress/bzip2 compress/flate compress/gzip compress/lzw compress/zlib
  container/heap container/list container/ring context crypto crypto/aes crypto/cipher crypto/des crypto/dsa crypto/ecdh
  crypto/ecdsa crypto/ed25519 crypto/elliptic crypto/hmac crypto/md5 crypto/rand crypto/rc4 crypto/rsa crypto/sha1
  crypto/sha256 crypto/sha512 crypto/subtle crypto/tls crypto/x509 crypto/x509/pkix database/sql database/sql/driver
  debug/buildinfo debug/dwarf debug/elf debug/gosym debug/macho debug/pe debug/plan9obj embed encoding encoding/ascii85
  encoding/asn1 encoding/base32 encoding/base64 encoding/binary encoding/csv encoding/gob encoding/hex encoding/json
  encoding/pem encoding/xml errors expvar flag fmt go/ast go/build go/constant go/doc go/format go/importer go/parser
  go/printer go/scanner go/token go/types hash hash/adler32 hash/crc32 hash/crc64 hash/fnv hash/maphash html html/template
  image image/color image/color/palette image/draw image/gif image/jpeg image/png index/suffixarray io io/fs io/ioutil
  iter log log/slog math math/big math/bits math/cmplx math/rand mime mime/multipart mime/quotedprintable net net/http
  net/http/cgi net/http/cookiejar net/http/fcgi net/http/httptest net/http/httptrace net/http/httputil net/http/pprof
  net/mail net/netip net/rpc net/rpc/jsonrpc net/smtp net/textproto net/url os os/exec os/signal os/user path path/filepath
  plugin reflect regexp regexp/syntax runtime runtime/cgo runtime/coverage runtime/debug runtime/metrics runtime/pprof runtime/race
  runtime/trace slices sort strconv strings struct s sync sync/atomic syscall testing testing/fstest testing/iotest testing/quick
  text/scanner text/tabwriter text/template text/template/parse time unicode unicode/utf16 unicode/utf8 unsafe weak
].freeze

HELP = <<~TEXT
  Usage of ./executable:
    -apply-to-generated-files
    	Apply imports sorting and formatting(if the option is set) to generated files. Generated file is a file with first comment which starts with comment '// Code generated'. Optional parameter.
    -company-prefixes string
    	Company package prefixes which will be placed after 3rd-party group by default(if defined). Values should be comma-separated. Optional parameters.
    -excludes string
    	Exclude files or dirs, example: '.git/,proto/*.go'.
    -file-path string
    	Deprecated. Put file name as an argument(last item) of command line.
    -format
    	Option will perform additional formatting. Optional parameter.
    -imports-order string
    	Your imports groups can be sorted in your way. 
    	std - std import group; 
    	general - libs for general purpose; 
    	company - inter-org or your company libs(if you set '-company-prefixes'-option, then 4th group will be split separately. In other case, it will be the part of general purpose libs); 
    	project - your local project dependencies;
    	blanked - imports with "_" alias;
    	dotted - imports with "." alias.
    	Optional parameter. (default "std,general,company,project")
    -list-diff
    	Option will list files whose formatting differs from goimports-reviser. Optional parameter.
    -local string
    	Deprecated
    -output string
    	Can be "file", "write" or "stdout". Whether to write the formatted content back to the file or to stdout. When "write" together with "-list-diff" will list the file name and write back to the file. Optional parameter. (default "file")
    -project-name string
    	Your project name(ex.: github.com/incu6us/goimports-reviser). Optional parameter.
    -recursive
    	Apply rules recursively if target is a directory. In case of ./... execution will be recursively applied by default. Optional parameter.
    -rm-unused
    	Remove unused imports. Optional parameter.
    -separate-named
    	Option will separate named imports from the rest of the imports, per group. Optional parameter.
    -set-alias
    	Set alias for versioned package names, like 'github.com/go-pg/pg/v9'. In this case import will be set as 'pg "github.com/go-pg/pg/v9"'. Optional parameter.
    -set-exit-status
    	set the exit status to 1 if a change is needed/made. Optional parameter.
    -use-cache
    	Use cache to improve performance. Optional parameter.
    -version
    	Show version information
    -version-only
    	Show only the version string
TEXT

Import = Struct.new(:alias_name, :path, :comment, keyword_init: true)

class App
  def initialize(argv)
    @opts = {
      'imports-order' => 'std,general,company,project',
      'output' => 'file'
    }
    @bools = %w[apply-to-generated-files format list-diff recursive rm-unused separate-named set-alias set-exit-status use-cache version version-only]
    @strings = %w[company-prefixes excludes file-path imports-order local output project-name]
    @paths = parse(argv)
  end

  def run
    if @opts['version-only']
      puts VERSION
      return 0
    end
    if @opts['version']
      puts "version: #{VERSION}"
      puts 'built with: go1.26.0'
      puts "tag: v#{VERSION}"
      puts 'commit: n/a'
      puts 'source: github.com/incu6us/goimports-reviser/v3'
      return 0
    end

    if @paths.empty?
      warn HELP
      log 'no file(s) or directory(ies) specified on input'
      return 1
    end

    files = expand_paths(@paths)
    log "Paths: [#{files.join(' ')}]"
    changed_any = false
    files.each do |file|
      log "Processing #{file}"
      original = File.read(file)
      project = project_name_for(file)
      if project.nil? || project.empty?
        warn HELP
        log "Could not determine project name for path #{file}: open go.mod: no such file or directory"
        return 1
      end
      formatted = process_content(original, project)
      changed = formatted != original
      changed_any ||= changed
      handle_output(file, formatted, changed)
    rescue => e
      log "Failed to fix file: #{e.message}"
      return 1
    end
    changed_any && @opts['set-exit-status'] ? 1 : 0
  end

  private

  def parse(argv)
    paths = []
    i = 0
    while i < argv.length
      arg = argv[i]
      if arg == '--help' || arg == '-h'
        puts HELP
        exit 0
      elsif arg.start_with?('-')
        name, value = arg.sub(/^-+/, '').split('=', 2)
        if @bools.include?(name)
          @opts[name] = true
        elsif @strings.include?(name)
          if value.nil?
            i += 1
            value = argv[i] || ''
          end
          @opts[name] = value
        else
          warn "flag provided but not defined: -#{name}"
          warn HELP
          exit 2
        end
      else
        paths << arg
      end
      i += 1
    end
    paths << @opts['file-path'] if @opts['file-path'] && !@opts['file-path'].empty?
    paths
  end

  def log(msg)
    $stderr.puts "#{Time.now.strftime('%Y/%m/%d %H:%M:%S')} #{msg}"
  end

  def project_name_for(file)
    return @opts['project-name'] if @opts['project-name'] && !@opts['project-name'].empty?
    dir = File.directory?(file) ? file : File.dirname(file)
    loop do
      gm = File.join(dir, 'go.mod')
      if File.file?(gm)
        line = File.readlines(gm).find { |l| l =~ /^\s*module\s+(.+)\s*$/ }
        return Regexp.last_match(1).strip if line
      end
      parent = File.dirname(dir)
      break if parent == dir
      dir = parent
    end
    nil
  end

  def expand_paths(paths)
    out = []
    paths.each do |p|
      if p.end_with?('/...') || p == './...'
        base = p == './...' ? '.' : p.sub(%r{/\.\.\.$}, '')
        out.concat(find_go_files(base))
      elsif File.directory?(p)
        if @opts['recursive']
          out.concat(find_go_files(p))
        else
          out.concat(Dir.children(p).sort.map { |c| File.join(p, c) }.select { |f| f.end_with?('.go') && File.file?(f) })
        end
      else
        out << p
      end
    end
    excludes = (@opts['excludes'] || '').split(',').map(&:strip).reject(&:empty?)
    out.select { |f| f.end_with?('.go') && File.file?(f) && !excluded?(f, excludes) }.uniq
  end

  def find_go_files(base)
    files = []
    excludes = (@opts['excludes'] || '').split(',').map(&:strip).reject(&:empty?)
    Find.find(base) do |path|
      if File.directory?(path)
        if File.basename(path).start_with?('.') || excluded?(path + '/', excludes)
          Find.prune unless path == base
        end
        next
      end
      files << path if path.end_with?('.go') && !excluded?(path, excludes)
    end
    files.sort
  end

  def excluded?(path, patterns)
    patterns.any? do |pat|
      pat = pat.sub(%r{^\./}, '')
      rel = path.sub(%r{^\./}, '')
      if pat.end_with?('/')
        rel.start_with?(pat) || rel.include?("/#{pat}")
      else
        File.fnmatch?(pat, rel, File::FNM_PATHNAME | File::FNM_EXTGLOB) || rel.include?(pat)
      end
    end
  end

  def generated?(text)
    first_comment = text.lines.find { |l| l.strip.start_with?('//') || !l.strip.empty? }
    first_comment && first_comment.strip.start_with?('// Code generated')
  end

  def process_content(text, project)
    return text if generated?(text) && !@opts['apply-to-generated-files']
    out = rewrite_imports(text, project)
    light_format(out)
  end

  def rewrite_imports(text, project)
    if text =~ /^import\s*\((.*?)^\)/m
      before = Regexp.last_match.pre_match
      body = Regexp.last_match(1)
      after = Regexp.last_match.post_match
      imports = parse_imports(body)
      imports = filter_unused(imports, before + after) if @opts['rm-unused']
      imports = apply_aliases(imports) if @opts['set-alias']
      block = build_import_block(imports, project, multiline: true)
      before.rstrip + "\n\n" + block + after
    elsif text =~ /^import\s+((?:\w+|[_.])\s+)?"([^"]+)"([^\n]*)$/
      imp = Import.new(alias_name: Regexp.last_match(1)&.strip, path: Regexp.last_match(2), comment: Regexp.last_match(3).to_s.strip)
      imports = @opts['rm-unused'] ? filter_unused([imp], text.sub(Regexp.last_match(0), '')) : [imp]
      block = build_import_block(imports, project, multiline: imports.length != 1)
      text.sub(Regexp.last_match(0), block)
    else
      text
    end
  end

  def parse_imports(body)
    imports = []
    pending = []
    body.lines.each do |line|
      stripped = line.strip
      next if stripped.empty?
      if stripped.start_with?('//') || stripped.start_with?('/*')
        pending << stripped
        next
      end
      if stripped =~ /^(?:(\w+|[_.])\s+)?"([^"]+)"\s*(.*)$/
        comment = Regexp.last_match(3).to_s.strip
        # Block comments that stood alone are hard to anchor after sorting; the reference often drops them.
        imports << Import.new(alias_name: Regexp.last_match(1), path: Regexp.last_match(2), comment: comment)
        pending.clear
      end
    end
    imports
  end

  def filter_unused(imports, code)
    stripped = code.gsub(%r{//.*$}, '').gsub(%r{/\*.*?\*/}m, '')
    imports.select do |imp|
      next true if imp.alias_name == '_' || imp.alias_name == '.'
      name = imp.alias_name || package_name(imp.path)
      stripped.match?(/\b#{Regexp.escape(name)}\s*\./) || stripped.match?(/\b#{Regexp.escape(name)}\b/)
    end
  end

  def apply_aliases(imports)
    imports.map do |imp|
      if imp.alias_name.nil? && imp.path =~ %r{/v[0-9]+$}
        imp = imp.dup
        imp.alias_name = package_name(File.dirname(imp.path))
      end
      imp
    end
  end

  def build_import_block(imports, project, multiline: true)
    return 'import ()' if imports.empty?
    if imports.length == 1 && !multiline
      imp = imports.first
      prefix = imp.alias_name ? "#{imp.alias_name} " : ''
      suffix = imp.comment.empty? ? '' : " #{imp.comment}"
      return "import #{prefix}\"#{imp.path}\"#{suffix}"
    end
    groups = grouped_imports(imports, project)
    lines = ["import ("]
    first_group = true
    groups.each do |group|
      next if group.empty?
      lines << '' unless first_group
      first_group = false
      group.each { |imp| lines << "\t#{format_import(imp)}" }
    end
    lines << ')'
    lines.join("\n")
  end

  def grouped_imports(imports, project)
    order = (@opts['imports-order'] || 'std,general,company,project').split(',').map(&:strip)
    buckets = Hash.new { |h, k| h[k] = [] }
    imports.each { |imp| buckets[classify(imp, project)] << imp }
    buckets.each_value { |arr| arr.sort_by! { |i| [i.path, i.alias_name.to_s] } }
    result = []
    order.each do |name|
      arr = buckets[name]
      next if arr.empty?
      if @opts['separate-named'] && !%w[blanked dotted].include?(name)
        unnamed, named = arr.partition { |i| i.alias_name.nil? }
        result << unnamed unless unnamed.empty?
        result << named unless named.empty?
      else
        result << arr
      end
    end
    leftovers = buckets.keys.reject { |k| order.include?(k) }.sort.flat_map { |k| [buckets[k]] }
    result + leftovers
  end

  def classify(imp, project)
    return 'blanked' if imp.alias_name == '_'
    return 'dotted' if imp.alias_name == '.'
    return 'std' if STD_PKGS.include?(imp.path)
    return 'project' if !project.to_s.empty? && (imp.path == project || imp.path.start_with?(project + '/'))
    prefixes = (@opts['company-prefixes'] || '').split(',').map(&:strip).reject(&:empty?)
    return 'company' if prefixes.any? { |p| imp.path == p || imp.path.start_with?(p + '/') }
    'general'
  end

  def format_import(imp)
    prefix = imp.alias_name ? "#{imp.alias_name} " : ''
    suffix = imp.comment.empty? ? '' : " #{imp.comment}"
    "#{prefix}\"#{imp.path}\"#{suffix}"
  end

  def package_name(path)
    base = path.split('/').last.to_s
    base = path.split('/')[-2].to_s if base =~ /^v\d+$/ && path.split('/').length > 1
    base.gsub(/[^A-Za-z0-9_]/, '')
  end

  def light_format(text)
    lines = text.lines.map { |l| l.gsub(/[ \t]+$/, '') }
    text = lines.join
    text = text.gsub(/\n{3,}/, "\n\n")
    text = text.gsub(/^package ([^\n]+)\n(?!\n)/, "package \\1\n\n")
    text = text.gsub(/\)\n(?!\n)(func\s)/, ")\n\n\\1")
    text = text.gsub(/func\s+([^\n{]+)\{/, 'func \\1 {')
    text = text.gsub(/^(func[^\n{]+)\{\s*([^\n{};]+?)\s*\}$/) do
      "#{Regexp.last_match(1)}{ #{Regexp.last_match(2).strip} }"
    end
    text.end_with?("\n") ? text : text + "\n"
  end

  def handle_output(file, formatted, changed)
    if @opts['list-diff']
      puts file if changed
      File.write(file, formatted) if changed && @opts['output'] == 'write'
      return
    end
    case @opts['output']
    when 'stdout'
      print formatted
    else
      File.write(file, formatted) if changed
    end
  end
end

exit App.new(ARGV).run
