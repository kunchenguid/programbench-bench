#!/usr/bin/env ruby
# frozen_string_literal: true

require "open3"
require "fileutils"
require "timeout"

HELP = <<~TEXT

  USAGE: 

     ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                   string containing two space-seprated positive integers>]
                   [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                   [-h] <Array of strings> ...


  Where: 

     -i <path to directory>,  --replaydirectory <path to directory>
       The path to directory for replay output.

     -s <positive integer>,  --seed <positive integer>
       The seed for the map generator.

     -d <a string containing two space-seprated positive integers>, 
        --dimensions <a string containing two space-seprated positive
        integers>
       The dimensions of the map.

     -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>
       Create a map that will accommodate n players [SINGLE PLAYER MODE
       ONLY].

     -r,  --noreplay
       Turns off the replay generation.

     -t,  --timeout
       Causes game environment to ignore timeouts (give all bots infinite
       time).

     -o,  --override
       Overrides player-sent names using cmd args [SERVER ONLY].

     -q,  --quiet
       Runs game in quiet mode, producing machine-parsable output.

     --,  --ignore_rest
       Ignores the rest of the labeled arguments following this flag.

     --version
       Displays version information and exits.

     -h,  --help
       Displays usage information and exits.

     <Array of strings>  (accepted multiple times)
       Start commands for bots.


     Halite Game Environment
TEXT

BRIEF = <<~TEXT
  Brief USAGE: 
     ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                   string containing two space-seprated positive integers>]
                   [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                   [-h] <Array of strings> ...

  For complete USAGE and HELP type: 
     ./executable --help
TEXT

class Lcg
  def initialize(seed)
    @state = seed.to_i & 0x7fffffff
    @state = 1 if @state.zero?
  end

  def next_int(max)
    @state = (1103515245 * @state + 12345) & 0x7fffffff
    @state % max
  end
end

class Bot
  attr_reader :id, :command, :log_path
  attr_accessor :name, :alive, :last_alive

  def initialize(id, command, quiet, override)
    @id = id
    @command = command
    @quiet = quiet
    @override = override
    @name = command
    @alive = true
    @last_alive = 0
    @log_path = "#{id}-#{Time.now.to_i}.log"
    @stdin = @stdout = @stderr = @wait_thr = nil
    @log = nil
  end

  def start
    @stdin, @stdout, @stderr, @wait_thr = Open3.popen3(@command)
    @log = File.open(@log_path, "w")
    @log.puts " --- Init ---"
  rescue StandardError => e
    @alive = false
    @name = e.message
  end

  def send_line(line)
    return unless @alive

    @stdin.puts line
    @stdin.flush
  rescue StandardError
    mark_dead(0)
  end

  def read_line(limit_seconds)
    return nil unless @alive

    line = nil
    if limit_seconds
      Timeout.timeout(limit_seconds) { line = @stdout.gets }
    else
      line = @stdout.gets
    end
    line&.chomp
  rescue StandardError
    nil
  end

  def init_name(limit_seconds, override_name = nil)
    got = read_line(limit_seconds)
    @name = @override && override_name ? override_name : (got.nil? || got.empty? ? @command : got)
    @log.puts @name if @log
    got
  end

  def log_frame(frame)
    return unless @log

    @log.puts " --- Bot used 0 milliseconds ---"
    @log.puts "-----------------------------------------------------------------------------"
    @log.puts " --- Frame ##{frame} ---"
    @log.puts
  end

  def log_error(message = "No response received.")
    return unless @log

    @log.puts
    @log.puts "ERRORED!"
    @log.puts message
  end

  def drain_stderr
    return "" unless @stderr

    out = +""
    begin
      loop do
        r, = IO.select([@stderr], nil, nil, 0)
        break unless r
        chunk = @stderr.read_nonblock(4096, exception: false)
        break if chunk.nil? || chunk == :wait_readable
        out << chunk
      end
    rescue StandardError
      nil
    end
    out
  end

  def mark_dead(frame)
    @alive = false
    @last_alive = frame
  end

  def close
    [@stdin, @stdout, @stderr].each { |io| io&.close rescue nil }
    if @wait_thr&.alive?
      Process.kill("TERM", @wait_thr.pid) rescue nil
    end
    @log&.close
  end
end

class Game
  MAX_TURNS = 250
  DIRS = [[0, 0], [0, -1], [1, 0], [0, 1], [-1, 0]].freeze

  def initialize(opts, commands)
    @opts = opts
    @commands = commands
    @seed = opts[:seed] || rand(2_147_483_647)
    @rng = Lcg.new(@seed)
    @width, @height = opts[:dimensions] || default_dimensions
    @area = @width * @height
    @production = []
    @owners = Array.new(@area, 0)
    @strengths = []
    @frames = []
    @moves = []
    @bots = []
  end

  def default_dimensions
    return [35, 35] unless @opts[:nplayers]

    case @opts[:nplayers]
    when 1 then [40, 40]
    when 2 then [50, 50]
    when 3 then [48, 48]
    when 4 then [40, 40]
    when 5 then [30, 30]
    when 6 then [20, 20]
    else [35, 35]
    end
  end

  def run
    generate_map
    puts @commands
    puts "#{@width} #{@height}"
    init_bots
    turns = play
    write_replay(turns) unless @opts[:noreplay]
    print_results(turns)
    @bots.each(&:close)
  end

  def generate_map
    cy = (@height - 1) / 2.0
    cx = (@width - 1) / 2.0
    @height.times do |y|
      @width.times do |x|
        dist = ((x - cx).abs + (y - cy).abs).to_i
        noise = @rng.next_int(5)
        @production << [[1, 10 - dist / 3 + noise].max, 20].min
        base = 15 + @rng.next_int(55) + ((@production[-1] - 1) * 12)
        @strengths << [base, 255].min
      end
    end

    starts = starting_positions(@commands.length)
    starts.each_with_index do |(x, y), idx|
      pos = index(x, y)
      @owners[pos] = idx + 1
      @strengths[pos] = 255
    end
  end

  def starting_positions(n)
    case n
    when 1
      [[@width / 2, @height / 2]]
    when 2
      [[@width / 2, @height / 4], [@width / 2, (3 * @height) / 4]]
    else
      n.times.map do |i|
        angle = (2.0 * Math::PI * i / n) - Math::PI / 2
        [((@width / 2.0) + Math.cos(angle) * @width * 0.28).round % @width,
         ((@height / 2.0) + Math.sin(angle) * @height * 0.28).round % @height]
      end
    end
  end

  def init_bots
    @bots = @commands.each_with_index.map { |cmd, i| Bot.new(i + 1, cmd, @opts[:quiet], @opts[:override]) }
    @bots.each(&:start)
    @bots.each { |bot| bot.send_line(bot.id.to_s) }
    @bots.each { |bot| puts "Init Message sent to player #{bot.id}." unless @opts[:quiet] }
    init_payload = ["#{@width} #{@height} ", @production.join(" ") + " ", frame_line]
    @bots.each do |bot|
      name = bot.init_name(@opts[:timeout] ? nil : 2.0, @commands[bot.id - 1])
      puts "Init Message received from player #{bot.id}, #{bot.name}." unless @opts[:quiet]
      if name.nil?
        bot.log_error
        bot.mark_dead(0)
      end
      init_payload.each { |line| bot.send_line(line) }
    end
    save_frame
  end

  def play
    turns_played = MAX_TURNS
    1.upto(MAX_TURNS) do |turn|
      puts "Turn #{turn}" unless @opts[:quiet]
      current_moves = {}
      @bots.each do |bot|
        next unless bot.alive

        bot.log_frame(turn)
        response = bot.read_line(@opts[:timeout] ? nil : 1.0)
        if response.nil?
          bot.log_error
          bot.mark_dead(turn - 1)
          puts "Bot ##{bot.id} timeout or error (Unix) 0" unless @opts[:quiet]
          next
        end
        current_moves[bot.id] = parse_moves(response)
      end
      @moves << current_moves
      step(current_moves)
      save_frame
      @bots.each { |bot| bot.send_line(frame_line) if bot.alive }
      @bots.each { |bot| bot.last_alive = turn if bot.alive }
      if @bots.count(&:alive) <= 1 && @commands.length > 1
        turns_played = turn
        break
      end
    end
    turns_played
  end

  def parse_moves(line)
    vals = line.to_s.split.map { |v| Integer(v) rescue nil }.compact
    moves = []
    vals.each_slice(3) do |x, y, dir|
      next if x.nil? || y.nil? || dir.nil?
      moves << [x % @width, y % @height, dir % 5]
    end
    moves
  end

  def step(all_moves)
    new_owners = @owners.dup
    new_strengths = @strengths.dup

    @area.times do |i|
      if @owners[i].positive?
        new_strengths[i] = [255, new_strengths[i] + @production[i]].min
      end
    end

    all_moves.each do |pid, moves|
      moves.each do |x, y, dir|
        from = index(x, y)
        next unless @owners[from] == pid
        next if dir.zero?

        dx, dy = DIRS[dir] || DIRS[0]
        to = index(x + dx, y + dy)
        power = @strengths[from]
        new_strengths[from] = 0
        if new_owners[to] == pid
          new_strengths[to] = [255, new_strengths[to] + power].min
        elsif power > new_strengths[to]
          new_owners[to] = pid
          new_strengths[to] = [0, power - new_strengths[to]].max
        else
          new_strengths[to] -= power
        end
      end
    end

    @owners = new_owners
    @strengths = new_strengths
  end

  def frame_line
    parts = []
    last = @owners[0]
    count = 0
    @owners.each do |owner|
      if owner == last
        count += 1
      else
        parts << count << last
        last = owner
        count = 1
      end
    end
    parts << count << last
    (parts + @strengths).join(" ") + " "
  end

  def save_frame
    @frames << @owners.each_with_index.map { |owner, i| [owner, @strengths[i]] }
  end

  def write_replay(turns)
    dir = @opts[:replay_dir] || "."
    FileUtils.mkdir_p(dir)
    path = File.join(dir, "#{Time.now.to_i}-#{@seed}.hlt")
    data = {
      "frames" => @frames.map { |f| f.each_slice(@width).to_a },
      "moves" => @moves,
      "productions" => @production.each_slice(@width).to_a,
      "width" => @width,
      "height" => @height,
      "num_players" => @commands.length,
      "player_names" => @bots.map(&:name),
      "seed" => @seed,
      "turns" => turns
    }
    File.write(path, json(data))
    puts "Map seed was #{@seed}" unless @opts[:quiet]
    puts "Opening a file at #{path.start_with?("/") ? path : "./#{path.sub(%r{^\./}, "")}"}" unless @opts[:quiet]
  rescue StandardError => e
    warn "Failed to write replay: #{e.message}" unless @opts[:quiet]
  end

  def print_results(_turns)
    scores = @bots.map do |bot|
      cells = @owners.count(bot.id)
      strength = @strengths.each_with_index.sum { |s, i| @owners[i] == bot.id ? s : 0 }
      [bot, cells, strength]
    end
    ranked = scores.sort_by { |bot, cells, strength| [-cells, -strength, bot.id] }
    ranks = {}
    ranked.each_with_index { |entry, i| ranks[entry[0].id] = i + 1 }

    if @opts[:quiet]
      @bots.each { |bot| puts "#{bot.id} #{ranks[bot.id]} #{bot.last_alive}" }
      puts @bots.map(&:id).join(" ") + " "
      puts @bots.map(&:log_path).join(" ")
    else
      @bots.each do |bot|
        puts "Player ##{bot.id}, #{bot.name}, came in rank ##{ranks[bot.id]} and was last alive on frame ##{bot.last_alive}!"
      end
    end
  end

  def index(x, y)
    (y % @height) * @width + (x % @width)
  end

  def json(value)
    case value
    when Hash
      "{" + value.map { |k, v| "#{json(k.to_s)}:#{json(v)}" }.join(",") + "}"
    when Array
      "[" + value.map { |v| json(v) }.join(",") + "]"
    when String
      '"' + value.gsub("\\", "\\\\\\").gsub('"', '\"').gsub("\n", "\\n") + '"'
    when Numeric
      value.to_s
    when true then "true"
    when false then "false"
    when nil then "null"
    else
      json(value.to_s)
    end
  end
end

def parse_args(argv)
  opts = { noreplay: false, timeout: false, override: false, quiet: false }
  commands = []
  i = 0
  ignore_flags = false
  while i < argv.length
    arg = argv[i]
    if ignore_flags || !arg.start_with?("-") || arg == "-"
      commands << arg
      i += 1
      next
    end
    case arg
    when "-h", "--help"
      puts HELP
      exit 0
    when "--version"
      puts
      puts "./executable  version: 1.2"
      puts
      exit 0
    when "--", "--ignore_rest"
      ignore_flags = true
      i += 1
    when "-r", "--noreplay"
      opts[:noreplay] = true
      i += 1
    when "-t", "--timeout"
      opts[:timeout] = true
      i += 1
    when "-o", "--override"
      opts[:override] = true
      i += 1
    when "-q", "--quiet"
      opts[:quiet] = true
      i += 1
    when "-i", "--replaydirectory"
      opts[:replay_dir] = argv[i + 1]
      i += 2
    when "-s", "--seed"
      val = argv[i + 1]
      unless val&.match?(/\A[0-9]+\z/) && val.to_i.positive?
        warn_parse(arg, val)
      end
      opts[:seed] = val.to_i
      i += 2
    when "-n", "--nplayers"
      val = argv[i + 1]
      unless val&.match?(/\A[1-6]\z/)
        warn_parse(arg, val)
      end
      opts[:nplayers] = val.to_i
      i += 2
    when "-d", "--dimensions"
      val = argv[i + 1]
      unless val && val.match?(/\A\s*\d+\s+\d+\s*\z/)
        puts "PARSE ERROR: Argument: #{arg} (--dimensions)"
        puts "             Couldn't read argument value from string '#{val}'"
        puts
        puts BRIEF
        exit 1
      end
      w, h = val.split.map(&:to_i)
      opts[:dimensions] = [w, h]
      i += 2
    else
      commands << arg
      i += 1
    end
  end
  [opts, commands]
end

def warn_parse(arg, val)
  puts "PARSE ERROR: Argument: #{arg}"
  puts "             Couldn't read argument value from string '#{val}'"
  puts
  puts BRIEF
  exit 1
end

opts, commands = parse_args(ARGV)
if commands.empty?
  puts "Please provide the launch command string for at least one bot."
  puts "Use the --help flag for usage details."
  exit 1
end

Game.new(opts, commands).run
