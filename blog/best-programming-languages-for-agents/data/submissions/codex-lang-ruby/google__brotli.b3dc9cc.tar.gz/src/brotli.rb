#!/usr/bin/env ruby
# frozen_string_literal: true

require 'base64'
require 'fileutils'

HELP = <<~TEXT
  Usage: executable [OPTION]... [FILE]...
  Options:
    -#                          compression level (0-9)
    -c, --stdout                write on standard output
    -d, --decompress            decompress
    -f, --force                 force output file overwrite
    -h, --help                  display this help and exit
    -j, --rm                    remove source file(s)
    -s, --squash                remove destination file if larger than source
    -k, --keep                  keep source file(s) (default)
    -n, --no-copy-stat          do not copy source file(s) attributes
    -o FILE, --output=FILE      output file (only if 1 input file)
    -q NUM, --quality=NUM       compression level (0-11)
    -t, --test                  test compressed file integrity
    -v, --verbose               verbose mode
    -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                                window size = 2**NUM - 16
                                0 lets compressor choose the optimal value
    --large_window=NUM          use incompatible large-window brotli
                                bitstream with window size (0, 10-30)
                                WARNING: this format is not compatible
                                with brotli RFC 7932 and may not be
                                decodable with regular brotli decoders
    -C B64, --comment=B64       set comment; argument is base64-decoded first;
                                (maximal decoded length: 80)
                                when decoding: check stream comment;
                                when encoding: embed comment (fingerprint)
    -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
    -K, --concatenated          allows concatenated brotli streams as input
    -S SUF, --suffix=SUF        output file suffix (default:'.br')
    -V, --version               display version and exit
    -Z, --best                  use best compression level (11) (default)
  Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
  With no FILE, or when FILE is -, read standard input.
  All arguments after '--' are treated as files.
TEXT

class BitWriter
  def initialize
    @bytes = +''
    @acc = 0
    @used = 0
  end

  def bit(v)
    @acc |= (v & 1) << @used
    @used += 1
    flush_byte if @used == 8
  end

  def bits(value, count)
    count.times { |i| bit((value >> i) & 1) }
  end

  def align
    flush_byte if @used.positive?
  end

  def write(data)
    align
    @bytes << data
  end

  def string
    align
    @bytes
  end

  private

  def flush_byte
    @bytes << @acc.chr
    @acc = 0
    @used = 0
  end
end

class BitReader
  def initialize(data, offset = 0)
    @data = data
    @pos = offset
    @used = 0
  end

  attr_reader :pos

  def bit
    raise EOFError if @pos >= @data.bytesize

    b = @data.getbyte(@pos)
    v = (b >> @used) & 1
    @used += 1
    if @used == 8
      @used = 0
      @pos += 1
    end
    v
  end

  def bits(count)
    v = 0
    count.times { |i| v |= bit << i }
    v
  end

  def align
    if @used.positive?
      @used = 0
      @pos += 1
    end
  end
end

def stored_brotli(data)
  w = BitWriter.new
  if data.empty?
    write_window_22(w)
    w.bit(1)
    w.bit(1)
    return w.string
  end

  write_window_22(w)
  offset = 0
  while offset < data.bytesize
    chunk = data.byteslice(offset, 65_536)
    w.bit(0)          # not last; terminate with an empty final meta-block
    w.bits(0, 2)      # four nibbles of meta-block length
    w.bits(chunk.bytesize - 1, 16)
    w.bit(1)          # uncompressed
    w.write(chunk)
    offset += chunk.bytesize
  end
  w.bit(1)
  w.bit(1)
  w.string
end

def write_window_22(w)
  # RFC 7932 window-size code for lgwin 22: bits 1,1,0,0.
  w.bit(1)
  w.bit(1)
  w.bit(0)
  w.bit(0)
end

def decode_stored_brotli_one(data, offset = 0)
  r = BitReader.new(data, offset)
  first = r.bit
  if first == 0
    # lgwin 16
  else
    n = r.bits(3)
    if n.zero?
      m = r.bits(3)
      raise 'unsupported input' unless m.zero? || (1..7).cover?(m)
    end
  end

  out = +''
  loop do
    islast = r.bit
    if islast == 1 && r.bit == 1
      r.align
      break
    elsif islast == 1
      # The bit consumed above is the first MNIBBLES bit. This implementation
      # only decodes the stored streams it writes, which use a final empty block.
      raise 'unsupported input'
    end

    mnibbles = r.bits(2)
    raise 'unsupported input' unless mnibbles.zero?

    len = r.bits(16) + 1
    uncomp = r.bit
    raise 'unsupported input' unless uncomp == 1

    r.align
    raise EOFError if r.pos + len > data.bytesize

    out << data.byteslice(r.pos, len)
    r.instance_variable_set(:@pos, r.pos + len)
  end
  [out, r.pos]
rescue EOFError
  raise 'corrupt input'
end

def decode_stored_brotli(data, concatenated: false)
  out = +''
  offset = 0
  loop do
    chunk, offset = decode_stored_brotli_one(data, offset)
    out << chunk
    break if offset >= data.bytesize
    raise 'unsupported input' unless concatenated
  end
  out
end

def fail_usage(msg)
  warn msg
  warn HELP
  exit 1
end

opts = {
  stdout: false, decompress: false, force: false, keep: true, test: false,
  no_copy_stat: false, output: nil, quality: 11, lgwin: 22, suffix: '.br',
  verbose: 0, squash: false, concatenated: false, comment: nil, dictionary: nil
}
files = []
args = ARGV.dup
literal = false

take_value = lambda do |name, current, rest|
  return current unless current.nil? || current.empty?
  fail_usage("missing parameter for #{name}") if rest.empty?

  rest.shift
end

until args.empty?
  a = args.shift
  if literal
    files << a
  elsif a == '--'
    literal = true
  elsif a == '--help'
    print HELP
    exit 0
  elsif a == '--version'
    puts 'brotli 1.2.0'
    exit 0
  elsif a.start_with?('--')
    name, value = a[2..].split('=', 2)
    case name
    when 'stdout' then opts[:stdout] = true
    when 'decompress' then opts[:decompress] = true
    when 'force' then opts[:force] = true
    when 'rm' then opts[:keep] = false
    when 'keep' then opts[:keep] = true
    when 'squash' then opts[:squash] = true
    when 'no-copy-stat' then opts[:no_copy_stat] = true
    when 'test'
      opts[:test] = true
      opts[:decompress] = true
      opts[:stdout] = true
    when 'verbose' then opts[:verbose] += 1
    when 'best' then opts[:quality] = 11
    when 'output' then opts[:output] = take_value.call('--output', value, args)
    when 'quality'
      v = take_value.call('--quality', value, args)
      fail_usage("error parsing quality value [#{v}]") unless v =~ /\A\d+\z/ && (0..11).cover?(v.to_i)
      opts[:quality] = v.to_i
    when 'lgwin'
      v = take_value.call('--lgwin', value, args)
      fail_usage("error parsing lgwin value [#{v}]") unless v =~ /\A\d+\z/
      lg = v.to_i
      fail_usage("lgwin parameter (#{lg}) smaller than the minimum (10)") unless lg.zero? || lg >= 10
      fail_usage("lgwin parameter (#{lg}) larger than the maximum (24)") if lg > 24
      opts[:lgwin] = lg
    when 'large_window'
      v = take_value.call('--large_window', value, args)
      fail_usage("error parsing large_window value [#{v}]") unless v =~ /\A\d+\z/
    when 'suffix' then opts[:suffix] = take_value.call('--suffix', value, args)
    when 'comment'
      raw = take_value.call('--comment', value, args)
      begin
        opts[:comment] = Base64.strict_decode64(raw)
      rescue ArgumentError
        fail_usage("error parsing comment value [#{raw}]")
      end
      fail_usage('decoded comment is longer than 80 bytes') if opts[:comment].bytesize > 80
    when 'dictionary'
      opts[:dictionary] = take_value.call('--dictionary', value, args)
      begin
        File.binread(opts[:dictionary])
      rescue SystemCallError
        warn "failed to open dictionary file [#{opts[:dictionary]}]"
        exit 1
      end
    else
      fail_usage("must pass the parameter as --#{name}=value")
    end
  elsif a.start_with?('-') && a != '-'
    chars = a[1..].chars
    until chars.empty?
      ch = chars.shift
      if ch =~ /\A[0-9]\z/
        opts[:quality] = ch.to_i
      else
        case ch
        when 'c' then opts[:stdout] = true
        when 'd' then opts[:decompress] = true
        when 'f' then opts[:force] = true
        when 'h'
          print HELP
          exit 0
        when 'j' then opts[:keep] = false
        when 's' then opts[:squash] = true
        when 'k' then opts[:keep] = true
        when 'n' then opts[:no_copy_stat] = true
        when 't'
          opts[:test] = true
          opts[:decompress] = true
          opts[:stdout] = true
        when 'v' then opts[:verbose] += 1
        when 'K' then opts[:concatenated] = true
        when 'V'
          puts 'brotli 1.2.0'
          exit 0
        when 'Z' then opts[:quality] = 11
        when 'o', 'q', 'w', 'C', 'D', 'S'
          val = chars.join
          val = args.shift if val.empty?
          fail_usage("missing parameter for -#{ch}") if val.nil?
          chars = []
          case ch
          when 'o' then opts[:output] = val
          when 'q'
            fail_usage("error parsing quality value [#{val}]") unless val =~ /\A\d+\z/ && (0..11).cover?(val.to_i)
            opts[:quality] = val.to_i
          when 'w'
            fail_usage("error parsing lgwin value [#{val}]") unless val =~ /\A\d+\z/
            lg = val.to_i
            fail_usage("lgwin parameter (#{lg}) smaller than the minimum (10)") unless lg.zero? || lg >= 10
            fail_usage("lgwin parameter (#{lg}) larger than the maximum (24)") if lg > 24
            opts[:lgwin] = lg
          when 'C'
            begin
              opts[:comment] = Base64.strict_decode64(val)
            rescue ArgumentError
              fail_usage("error parsing comment value [#{val}]")
            end
            fail_usage('decoded comment is longer than 80 bytes') if opts[:comment].bytesize > 80
          when 'D'
            opts[:dictionary] = val
            begin
              File.binread(val)
            rescue SystemCallError
              warn "failed to open dictionary file [#{val}]"
              exit 1
            end
          when 'S' then opts[:suffix] = val
          end
        else
          fail_usage("unknown option [-#{ch}]")
        end
      end
    end
  else
    files << a
  end
end

files = ['-'] if files.empty?
fail_usage('write to standard output is disabled for multiple input files') if opts[:output] && files.length != 1

status = 0
files.each do |path|
  begin
    input = path == '-' ? STDIN.binmode.read : File.binread(path)
    output = if opts[:decompress]
               decode_stored_brotli(input, concatenated: opts[:concatenated])
             else
               stored_brotli(input)
             end

    next if opts[:test]

    if opts[:stdout] || path == '-'
      STDOUT.binmode.write(output)
    else
      out_path = opts[:output]
      out_path ||= if opts[:decompress]
                     if path.end_with?(opts[:suffix])
                       path[0...(path.bytesize - opts[:suffix].bytesize)]
                     else
                       "#{path}.out"
                     end
                   else
                     "#{path}#{opts[:suffix]}"
                   end
      if File.exist?(out_path) && !opts[:force]
        warn "failed to open output file [#{out_path}]: File exists"
        status = 1
        next
      end
      File.binwrite(out_path, output)
      if path != '-' && !opts[:no_copy_stat]
        st = File.stat(path)
        File.utime(st.atime, st.mtime, out_path)
      end
      FileUtils.rm_f(path) if path != '-' && !opts[:keep]
      FileUtils.rm_f(out_path) if opts[:squash] && File.exist?(path) && File.size(out_path) > File.size(path)
    end
  rescue SystemCallError
    warn "failed to open input file [#{path}]"
    status = 1
  rescue StandardError => e
    warn e.message == 'unsupported input' ? "corrupt input [#{path}]" : "#{e.message} [#{path}]"
    status = 1
  end
end

exit status
