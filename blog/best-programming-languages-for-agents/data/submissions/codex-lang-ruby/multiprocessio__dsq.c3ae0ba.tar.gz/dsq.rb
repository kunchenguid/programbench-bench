#!/usr/bin/env -S ruby --disable-gems
# frozen_string_literal: true

require "csv"
require "cgi"
require "json"
require "optparse"
require "stringio"
require "zlib"
require "fiddle/import"

module SQLite
  extend Fiddle::Importer
  dlload "/lib/x86_64-linux-gnu/libsqlite3.so.0"
  extern "int sqlite3_open(const char*, void*)"
  extern "int sqlite3_close(void*)"
  extern "int sqlite3_exec(void*, const char*, void*, void*, void*)"
  extern "char* sqlite3_errmsg(void*)"
  extern "int sqlite3_prepare_v2(void*, const char*, int, void*, void*)"
  extern "int sqlite3_step(void*)"
  extern "int sqlite3_finalize(void*)"
  extern "int sqlite3_column_count(void*)"
  extern "char* sqlite3_column_name(void*, int)"
  extern "int sqlite3_column_type(void*, int)"
  extern "char* sqlite3_column_text(void*, int)"
  extern "long long sqlite3_column_int64(void*, int)"
  extern "double sqlite3_column_double(void*, int)"
end

class DB
  SQLITE_ROW = 100
  SQLITE_DONE = 101
  SQLITE_INTEGER = 1
  SQLITE_FLOAT = 2
  SQLITE_TEXT = 3
  SQLITE_NULL = 5

  def initialize
    pp = Fiddle::Pointer.malloc(Fiddle::SIZEOF_VOIDP)
    rc = SQLite.sqlite3_open(":memory:", pp)
    @db = Fiddle::Pointer.new(pp[0, Fiddle::SIZEOF_VOIDP].unpack1("J"))
    raise error if rc != 0
  end

  def close
    SQLite.sqlite3_close(@db) if @db
    @db = nil
  end

  def exec(sql)
    rc = SQLite.sqlite3_exec(@db, sql, nil, nil, nil)
    raise error if rc != 0
  end

  def query(sql)
    pp = Fiddle::Pointer.malloc(Fiddle::SIZEOF_VOIDP)
    rc = SQLite.sqlite3_prepare_v2(@db, sql, -1, pp, nil)
    raise error if rc != 0
    stmt = Fiddle::Pointer.new(pp[0, Fiddle::SIZEOF_VOIDP].unpack1("J"))
    columns = (0...SQLite.sqlite3_column_count(stmt)).map { |i| SQLite.sqlite3_column_name(stmt, i).to_s }
    rows = []
    loop do
      step = SQLite.sqlite3_step(stmt)
      break if step == SQLITE_DONE
      raise error unless step == SQLITE_ROW

      row = {}
      columns.each_with_index do |name, i|
        row[name] = column_value(stmt, i)
      end
      rows << row
    end
    rows
  ensure
    SQLite.sqlite3_finalize(stmt) if stmt
  end

  def error
    SQLite.sqlite3_errmsg(@db).to_s
  end

  private

  def column_value(stmt, i)
    case SQLite.sqlite3_column_type(stmt, i)
    when SQLITE_INTEGER then SQLite.sqlite3_column_int64(stmt, i)
    when SQLITE_FLOAT then SQLite.sqlite3_column_double(stmt, i)
    when SQLITE_TEXT then SQLite.sqlite3_column_text(stmt, i).to_s
    when SQLITE_NULL then nil
    else SQLite.sqlite3_column_text(stmt, i)&.to_s
    end
  end
end

class ZipReader
  EOCD = "PK\x05\x06".b
  CEN = "PK\x01\x02".b
  LOC = "PK\x03\x04".b

  def initialize(path)
    @data = File.binread(path)
    @entries = {}
    parse
  end

  def read(name)
    meta = @entries[name]
    return nil unless meta

    off = meta[:local]
    raise "bad zip" unless @data.byteslice(off, 4) == LOC
    fields = @data.byteslice(off + 26, 4).unpack("vv")
    name_len, extra_len = fields
    start = off + 30 + name_len + extra_len
    compressed = @data.byteslice(start, meta[:compressed_size])
    case meta[:method]
    when 0 then compressed
    when 8
      inflater = Zlib::Inflate.new(-Zlib::MAX_WBITS)
      begin
        inflater.inflate(compressed) + inflater.finish
      ensure
        inflater.close
      end
    else nil
    end
  end

  def names
    @entries.keys
  end

  private

  def parse
    eocd = @data.rindex(EOCD)
    raise "not a zip file" unless eocd
    cd_size, cd_offset = @data.byteslice(eocd + 12, 8).unpack("VV")
    pos = cd_offset
    finish = cd_offset + cd_size
    while pos < finish
      raise "bad central directory" unless @data.byteslice(pos, 4) == CEN
      vals = @data.byteslice(pos + 10, 36).unpack("vvvVVVvvvvvVV")
      method = vals[0]
      compressed_size = vals[4]
      name_len = vals[6]
      extra_len = vals[7]
      comment_len = vals[8]
      local = vals[12]
      name = @data.byteslice(pos + 46, name_len)
      @entries[name] = { method: method, compressed_size: compressed_size, local: local }
      pos += 46 + name_len + extra_len + comment_len
    end
  end
end

def usage
  <<~TXT
    dsq (Version latest) - commandline SQL engine for data files

    Usage:  dsq [file...] $query
            dsq $file [query]
            cat $file | dsq -s $filetype [query]
            dsq $file -f $queryfile

    dsq is a tool for running SQL on one or more data files. It uses
    SQLite's SQL dialect. Files as tables are accessible via "{N}" where N
    is the 0-based index of the file in the commandline.

    The shorthand "{}" is replaced with "{0}".
  TXT
end

def sql_quote_ident(s)
  %("#{s.to_s.gsub('"', '""')}")
end

def sql_literal(v)
  case v
  when nil then "NULL"
  when Integer, Float then v.to_s
  when TrueClass then "1"
  when FalseClass then "0"
  else "'#{v.to_s.gsub("'", "''")}'"
  end
end

def scalar_kind(v)
  case v
  when nil then "null"
  when TrueClass, FalseClass then "boolean"
  when Integer, Float then "number"
  else "string"
  end
end

def infer_schema(rows)
  return { "kind" => "array", "array" => { "kind" => "scalar", "scalar" => "null" } } if rows.empty?
  if rows.all? { |r| r.is_a?(Hash) }
    keys = rows.flat_map(&:keys).uniq
    obj = {}
    keys.each do |k|
      kinds = rows.map { |r| scalar_kind(r[k]) }.uniq
      obj[k] = if kinds.length == 1
        { "kind" => "scalar", "scalar" => kinds.first }
      else
        { "kind" => "varied", "varied" => kinds.map { |kind| { "kind" => "scalar", "scalar" => kind } } }
      end
    end
    { "kind" => "array", "array" => { "kind" => "object", "object" => obj } }
  else
    kinds = rows.map { |r| scalar_kind(r) }.uniq
    inner = kinds.length == 1 ? { "kind" => "scalar", "scalar" => kinds.first } :
      { "kind" => "varied", "varied" => kinds.map { |kind| { "kind" => "scalar", "scalar" => kind } } }
    { "kind" => "array", "array" => inner }
  end
end

def parse_csv_text(text, col_sep)
  parsed = CSV.parse(text, headers: true, col_sep: col_sep, return_headers: false)
  parsed.map { |row| row.headers.each_with_object({}) { |h, acc| acc[h] = row[h] || "" } }
end

def parse_json_text(text)
  stripped = text.strip
  return [] if stripped.empty?
  begin
    value = JSON.parse(stripped)
    return value if value.is_a?(Array)
    return value
  rescue JSON::ParserError
    rows = []
    text.each_line do |line|
      next if line.strip.empty?
      rows << JSON.parse(line)
    end
    rows
  end
end

def parse_logfmt_text(text)
  text.lines.filter_map do |line|
    line = line.strip
    next if line.empty?
    row = {}
    until line.empty?
      line.sub!(/\A\s+/, "")
      break unless line.sub!(/\A([^=\s]+)=/, "")
      key = Regexp.last_match(1)
      val = if line.start_with?('"')
        line = line[1..]
        buf = +""
        escaped = false
        idx = 0
        line.each_char do |ch|
          if escaped
            buf << ch
            escaped = false
          elsif ch == "\\"
            escaped = true
          elsif ch == '"'
            break
          else
            buf << ch
          end
          idx += 1
        end
        line = line[(idx + 1)..].to_s
        buf
      else
        if line =~ /\A(\S+)(.*)\z/m
          line = Regexp.last_match(2).to_s
          Regexp.last_match(1)
        else
          v = line
          line = ""
          v
        end
      end
      row[key] = val
    end
    row
  end
end

def xml_text_fragment(xml)
  xml.to_s.scan(%r{<[^:>/]*:?t\b[^>]*>(.*?)</[^:>]*:?t>}m).flatten.map { |s| CGI.unescapeHTML(s) }.join
end

def xml_attr(attrs, name)
  attrs.to_s[/\b#{Regexp.escape(name)}="([^"]*)"/, 1]
end

def xlsx_rows(path)
  zip = ZipReader.new(path)
  shared = []
  if (ss = zip.read("xl/sharedStrings.xml"))
    ss.scan(%r{<si\b[^>]*>(.*?)</si>}m) { |m| shared << xml_text_fragment(m.first) }
  end
  sheet_name = zip.names.find { |n| n =~ %r{\Axl/worksheets/sheet\d+\.xml\z} }
  return [] unless sheet_name
  rows = []
  zip.read(sheet_name).scan(%r{<row\b[^>]*>(.*?)</row>}m) do |row_match|
    row_xml = row_match.first
    cells = []
    row_xml.scan(%r{<c\b([^>]*)>(.*?)</c>}m) do |attrs, cell_xml|
      ref = xml_attr(attrs, "r").to_s[/[A-Z]+/]
      idx = ref ? ref.chars.reduce(0) { |a, ch| a * 26 + ch.ord - 64 } - 1 : cells.length
      t = xml_attr(attrs, "t")
      val = if cell_xml =~ %r{<v[^>]*>(.*?)</v>}m
        CGI.unescapeHTML(Regexp.last_match(1))
      else
        xml_text_fragment(cell_xml)
      end
      val = shared[val.to_i].to_s if t == "s"
      cells[idx] = val
    end
    rows << cells
  end
  headers = rows.shift || []
  rows.map { |r| headers.each_with_index.each_with_object({}) { |(h, i), acc| acc[h.to_s] = (r[i] || "") } }
end

def ods_rows(path)
  xml = ZipReader.new(path).read("content.xml")
  return [] unless xml
  table = xml[%r{<table:table\b[^>]*>(.*?)</table:table>}m, 1] || xml
  rows = []
  table.scan(%r{<table:table-row\b[^>]*>(.*?)</table:table-row>}m) do |row_match|
    row = []
    row_match.first.scan(%r{<table:table-cell\b([^>]*)>(.*?)</table:table-cell>}m) do |attrs, cell_xml|
      repeat = (xml_attr(attrs, "table:number-columns-repeated") || "1").to_i
      val = xml_attr(attrs, "office:value") || xml_text_fragment(cell_xml)
      repeat.times { row << val.to_s }
    end
    rows << row unless row.all?(&:empty?)
  end
  headers = rows.shift || []
  rows.map { |r| headers.each_with_index.each_with_object({}) { |(h, i), acc| acc[h.to_s] = (r[i] || "") } }
end

def read_input(path, forced_format = nil, stdin_text = nil)
  fmt = (forced_format || File.extname(path.to_s).delete_prefix(".")).downcase
  if stdin_text.nil? && %w[xlsx ods].include?(fmt)
    return fmt == "xlsx" ? xlsx_rows(path) : ods_rows(path)
  end
  text = stdin_text || File.read(path)
  case fmt
  when "csv" then parse_csv_text(text, ",")
  when "tsv", "tab" then parse_csv_text(text, "\t")
  when "json", "ndjson", "jsonl" then parse_json_text(text)
  when "logfmt" then parse_logfmt_text(text)
  when "xlsx" then xlsx_rows(path)
  when "ods" then ods_rows(path)
  else
    if text.lstrip.start_with?("{", "[")
      parse_json_text(text)
    elsif text.include?("\t") && !text.lines.first.to_s.include?(",")
      parse_csv_text(text, "\t")
    else
      parse_csv_text(text, ",")
    end
  end
end

def normalize_rows(data)
  case data
  when Array
    data.map { |v| v.is_a?(Hash) ? v : { "value" => v } }
  when Hash
    [data]
  else
    [{ "value" => data }]
  end
end

def import_table(db, table, rows)
  rows = normalize_rows(rows)
  columns = rows.flat_map(&:keys).map(&:to_s).uniq
  columns = ["value"] if columns.empty?
  db.exec("CREATE TABLE #{sql_quote_ident(table)} (#{columns.map { |c| "#{sql_quote_ident(c)}" }.join(", ")})")
  rows.each do |row|
    vals = columns.map { |c| sql_literal(row[c] || row[c.to_sym]) }
    db.exec("INSERT INTO #{sql_quote_ident(table)} (#{columns.map { |c| sql_quote_ident(c) }.join(", ")}) VALUES (#{vals.join(", ")})")
  end
end

def transform_query(sql)
  out = sql.gsub(/\{\}/, "t0").gsub(/\{(\d+)\}/) { "t#{Regexp.last_match(1)}" }
  out.gsub(/(?<!["'])\b([A-Za-z_][A-Za-z0-9_\.]*)\s*(<=|>=|<>|!=|=|<|>)\s*(-?\d+(?:\.\d+)?)\b/) do
    "CAST(#{Regexp.last_match(1)} AS NUMERIC) #{Regexp.last_match(2)} #{Regexp.last_match(3)}"
  end
end

def json_print(value)
  if value.is_a?(Array)
    puts "[" + value.map { |v| JSON.generate(v) }.join(",\n") + "]"
  else
    puts JSON.generate(value)
  end
end

def pretty_print(rows)
  cols = rows.flat_map(&:keys).uniq
  widths = cols.map do |c|
    [c.length, *rows.map { |r| r[c].nil? ? 0 : r[c].to_s.length }].max
  end
  sep = "+" + widths.map { |w| "-" * (w + 2) }.join("+") + "+"
  puts sep
  puts "| " + cols.each_with_index.map { |c, i| c.ljust(widths[i]) }.join(" | ") + " |"
  puts sep
  rows.each do |r|
    puts "| " + cols.each_with_index.map { |c, i|
      value = r[c].to_s
      value.match?(/\A-?\d+(?:\.\d+)?\z/) ? value.rjust(widths[i]) : value.ljust(widths[i])
    }.join(" | ") + " |"
  end
  puts sep
  puts "(#{rows.length} rows)"
end

options = { pretty: false, schema: false, stream_format: nil, query_file: nil }
parser = OptionParser.new do |opts|
  opts.on("-p", "--pretty") { options[:pretty] = true }
  opts.on("-s FORMAT") { |v| options[:stream_format] = v }
  opts.on("-f", "--file FILE") { |v| options[:query_file] = v }
  opts.on("--schema") { options[:schema] = true }
  opts.on("-C", "--cache") {}
  opts.on("-i", "--interactive") { warn "interactive mode is not supported"; exit 1 }
  opts.on("--version") { puts "dsq latest"; exit 0 }
  opts.on("-h", "--help") { puts usage; exit 0 }
end

begin
  argv = parser.permute!(ARGV)
  if argv.empty? && !options[:stream_format]
    warn "No input files."
    exit 1
  end

  query = options[:query_file] ? File.read(options[:query_file]).strip : nil
  files = []
  if options[:stream_format]
    files << ["-", options[:stream_format], STDIN.read]
    query ||= argv.shift
  else
    if argv.length >= 2 || (argv.length == 1 && argv[0].match?(/\bselect\b/i))
      query = argv.pop unless query
    end
    files = argv.map { |f| [f, nil, nil] }
  end

  data_sets = files.map { |path, fmt, text| read_input(path, fmt, text) }
  if options[:schema]
    puts JSON.pretty_generate(infer_schema(normalize_rows(data_sets.first || [])))
    exit 0
  end

  unless query
    if data_sets.length == 1
      direct = data_sets.first
      if options[:pretty]
        pretty_print(normalize_rows(direct))
      else
        json_print(direct)
      end
      exit 0
    end
    query = "select * from {}"
  end

  db = DB.new
  data_sets.each_with_index { |rows, i| import_table(db, "t#{i}", rows) }
  result = db.query(transform_query(query))
  options[:pretty] ? pretty_print(result) : json_print(result)
rescue StandardError => e
  warn e.message
  exit 1
ensure
  db&.close
end
